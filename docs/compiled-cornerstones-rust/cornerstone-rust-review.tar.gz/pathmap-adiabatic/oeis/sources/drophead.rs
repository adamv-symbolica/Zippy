#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1]));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[2]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[3]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[5]));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[6]));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[7]));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[8]));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[9]));
static CONSTANT_10: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[10]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_3: Space = wrap(&(descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0))),&(*CONSTANT_0));
  let v0_4: Space = routine_1(c, &(descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0))));
  let v0_6: Space = wrap(&(v0_4),&(*CONSTANT_1));
  let v0_7: Space = unite(&(v0_3),&(v0_6));
  drop(v0_3);
  let v0_8: Space = routine_1(c, &((v0_4).read_zipper()));
  let v0_10: Space = wrap(&(v0_8),&(*CONSTANT_2));
  let v0_11: Space = unite(&(v0_7),&(v0_10));
  let v0_12: Space = routine_1(c, &((v0_8).read_zipper()));
  let v0_14: Space = wrap(&(v0_12),&(*CONSTANT_3));
  let v0_15: Space = unite(&(v0_11),&(v0_14));
  let v0_16: Space = routine_1(c, &((v0_12).read_zipper()));
  let v0_18: Space = wrap(&(v0_16),&(*CONSTANT_4));
  let v0_19: Space = unite(&(v0_15),&(v0_18));
  let v0_20: Space = routine_1(c, &((v0_16).read_zipper()));
  let v0_22: Space = wrap(&(v0_20),&(*CONSTANT_5));
  let v0_23: Space = unite(&(v0_19),&(v0_22));
  let v0_24: Space = routine_1(c, &((v0_20).read_zipper()));
  let v0_26: Space = wrap(&(v0_24),&(*CONSTANT_6));
  let v0_27: Space = unite(&(v0_23),&(v0_26));
  let v0_28: Space = routine_1(c, &((v0_24).read_zipper()));
  let v0_30: Space = wrap(&(v0_28),&(*CONSTANT_7));
  let v0_31: Space = unite(&(v0_27),&(v0_30));
  let v0_32: Space = routine_1(c, &((v0_28).read_zipper()));
  let v0_34: Space = wrap(&(v0_32),&(*CONSTANT_8));
  let v0_35: Space = unite(&(v0_31),&(v0_34));
  let v0_36: Space = routine_1(c, &((v0_32).read_zipper()));
  let v0_38: Space = wrap(&(v0_36),&(*CONSTANT_9));
  let v0_39: Space = unite(&(v0_35),&(v0_38));
  let v0_40: Space = routine_1(c, &((v0_36).read_zipper()));
  let v0_42: Space = wrap(&(v0_40),&(*CONSTANT_10));
  let v0_43: Space = unite(&(v0_39),&(v0_42));
  (v0_43).clone()
}

fn routine_1(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v1_766: Space = drop_length_prefixes(&(*s0));
  (v1_766).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
