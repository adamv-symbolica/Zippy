#![allow(unused_imports, unused_variables, unused_mut, unused_parens, dead_code)]
// Zippy programs are inserted by exportOEISRust. The native comparison follows
// Adam-Vandervorst/PathMap benches/oeis.rs (MIT), including usize terminal IDs.
use num_bigint::BigInt;
use std::io::{BufRead, BufReader};
use std::time::Instant;
use zippy_pathmap::*;

mod stage_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_1 = Space::new();
  let mut v0_1_write = v0_1.write_zipper();
  let mut v0_1_cursor = (*s0.expect("unbound native input")).read_zipper();
  let v0_1_origin = v0_1_cursor.path().len();
  for v0_1_byte in v0_1_cursor.child_mask().iter() {
    v0_1_cursor.descend_to_existing_byte(v0_1_byte);
    {
    for v1_2_byte in v0_1_cursor.child_mask().iter() {
      v0_1_cursor.descend_to_existing_byte(v1_2_byte);
      {
      for v2_2_byte in v0_1_cursor.child_mask().iter() {
        v0_1_cursor.descend_to_existing_byte(v2_2_byte);
        {
        join_tails_into(&mut v0_1_write,&mut v0_1_cursor);
        }
        v0_1_cursor.ascend(1);
      }
      }
      v0_1_cursor.ascend(1);
    }
    }
    v0_1_cursor.ascend(1);
  }
  drop(v0_1_cursor);
  drop(v0_1_write);
  let v0_3: Space = wrap(&(v0_1),&(*CONSTANT_0));
  drop(v0_1);
  (v0_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }
}
mod stage_1 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1]));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[2]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[3]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[5]));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[6]));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[7]));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[8]));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[9]));
static CONSTANT_10: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[10]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_3: Space = wrap(&(descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0))),&(*CONSTANT_0));
  let v0_4: Space = routine_1(c, &(descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0))));
  let v0_6: Space = wrap(&(v0_4),&(*CONSTANT_1));
  let v0_7: Space = unite(&(v0_3),&(v0_6));
  drop(v0_3);
  let v0_8: Space = routine_1(c, &((v0_4).read_zipper()));
  let v0_10: Space = wrap(&(v0_8),&(*CONSTANT_2));
  let v0_11: Space = unite(&(v0_7),&(v0_10));
  let v0_12: Space = routine_1(c, &((v0_8).read_zipper()));
  let v0_14: Space = wrap(&(v0_12),&(*CONSTANT_3));
  let v0_15: Space = unite(&(v0_11),&(v0_14));
  let v0_16: Space = routine_1(c, &((v0_12).read_zipper()));
  let v0_18: Space = wrap(&(v0_16),&(*CONSTANT_4));
  let v0_19: Space = unite(&(v0_15),&(v0_18));
  let v0_20: Space = routine_1(c, &((v0_16).read_zipper()));
  let v0_22: Space = wrap(&(v0_20),&(*CONSTANT_5));
  let v0_23: Space = unite(&(v0_19),&(v0_22));
  let v0_24: Space = routine_1(c, &((v0_20).read_zipper()));
  let v0_26: Space = wrap(&(v0_24),&(*CONSTANT_6));
  let v0_27: Space = unite(&(v0_23),&(v0_26));
  let v0_28: Space = routine_1(c, &((v0_24).read_zipper()));
  let v0_30: Space = wrap(&(v0_28),&(*CONSTANT_7));
  let v0_31: Space = unite(&(v0_27),&(v0_30));
  let v0_32: Space = routine_1(c, &((v0_28).read_zipper()));
  let v0_34: Space = wrap(&(v0_32),&(*CONSTANT_8));
  let v0_35: Space = unite(&(v0_31),&(v0_34));
  let v0_36: Space = routine_1(c, &((v0_32).read_zipper()));
  let v0_38: Space = wrap(&(v0_36),&(*CONSTANT_9));
  let v0_39: Space = unite(&(v0_35),&(v0_38));
  let v0_40: Space = routine_1(c, &((v0_36).read_zipper()));
  let v0_42: Space = wrap(&(v0_40),&(*CONSTANT_10));
  let v0_43: Space = unite(&(v0_39),&(v0_42));
  (v0_43).clone()
}

fn routine_1(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v1_766: Space = drop_length_prefixes(&(*s0));
  (v1_766).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }
}
mod stage_2 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("11 13 0 1 1 1 2 1 3 1 5 1 8 1 13 13 1 1 1 1 2 1 3 1 5 1 8 1 13 13 2 1 1 1 2 1 3 1 5 1 8 1 13 13 3 1 1 1 2 1 3 1 5 1 8 1 13 13 4 1 1 1 2 1 3 1 5 1 8 1 13 13 5 1 1 1 2 1 3 1 5 1 8 1 13 13 6 1 1 1 2 1 3 1 5 1 8 1 13 13 7 1 1 1 2 1 3 1 5 1 8 1 13 13 8 1 1 1 2 1 3 1 5 1 8 1 13 13 9 1 1 1 2 1 3 1 5 1 8 1 13 13 10 1 1 1 2 1 3 1 5 1 8 1 13"));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = restrict_to(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  (v0_2).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }
}
mod stage_3 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  (&(descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0)))).make_map()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }
}
mod stage_4 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  (&(descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0)))).make_map()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }
}
mod stage_5 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[2]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  (&(descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0)))).make_map()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }
}
mod stage_6 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[3]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  (&(descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0)))).make_map()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }
}
mod stage_7 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  (&(descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0)))).make_map()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }
}
mod stage_8 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[5]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  (&(descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0)))).make_map()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }
}
mod stage_9 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[6]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  (&(descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0)))).make_map()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }
}
mod stage_10 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[7]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  (&(descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0)))).make_map()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }
}
mod stage_11 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[8]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  (&(descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0)))).make_map()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }
}
mod stage_12 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[9]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  (&(descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0)))).make_map()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }
}
mod stage_13 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[10]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  (&(descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0)))).make_map()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }
}

fn execute(id: usize, c: &mut Context, e: &Env) -> Space {
    match id {
        0 => stage_0::entry(c,e),
1 => stage_1::entry(c,e),
2 => stage_2::entry(c,e),
3 => stage_3::entry(c,e),
4 => stage_4::entry(c,e),
5 => stage_5::entry(c,e),
6 => stage_6::entry(c,e),
7 => stage_7::entry(c,e),
8 => stage_8::entry(c,e),
9 => stage_9::entry(c,e),
10 => stage_10::entry(c,e),
11 => stage_11::entry(c,e),
12 => stage_12::entry(c,e),
13 => stage_13::entry(c,e),
        _ => unreachable!(),
    }
}

fn sequences(file: &str) -> Vec<(usize, Vec<u8>)> {
    let input = BufReader::new(std::fs::File::open(file).unwrap());
    input.lines().filter_map(|line| {
        let line = line.unwrap();
        if line.starts_with('#') || line.trim().is_empty() { return None; }
        let mut fields = line.split(',').map(str::trim);
        let id = fields.next().unwrap().strip_prefix('A').unwrap().parse().unwrap();
        let mut bytes = Vec::new();
        for number in fields.filter(|s| !s.is_empty()) {
            let payload = number.parse::<BigInt>().unwrap().to_signed_bytes_be();
            assert!(payload.len() <= 255);
            bytes.push(payload.len() as u8);
            bytes.extend_from_slice(&payload);
        }
        Some((id, bytes))
    }).collect()
}

fn native_build(seqs: &[(usize, Vec<u8>)]) -> pathmap::PathMap<usize> {
    let mut out = pathmap::PathMap::new();
    let mut z = out.write_zipper_at_path(&[0]);
    for (id, bytes) in seqs {
        if bytes.is_empty() { continue; }
        z.descend_to(bytes);
        if !z.is_val() { z.set_val(*id); }
        z.ascend(bytes.len());
    }
    drop(z);
    out
}

fn native_drop(map: &mut pathmap::PathMap<usize>) {
    let head = map.zipper_head();
    for offset in 1u8..=10 {
        let root = [offset];
        // These offsets are disjoint, exactly as in the upstream benchmark.
        let mut z = unsafe { head.write_zipper_at_exclusive_path_unchecked(&root) };
        z.graft(&unsafe { head.read_zipper_at_path_unchecked(&[offset-1]) });
        let origin = z.path().to_vec();
        for len in z.child_mask().iter() {
            if len == 0 { continue; }
            z.descend_to_existing_byte(len);
            z.join_k_path_into(len as usize, true);
            assert_eq!(z.ascend(1), 1);
        }
        z.reset();
        z.descend_to(&origin);
        z.join_k_path_into(1, true);
    }
}

fn query_mask() -> pathmap::PathMap<usize> {
    let mut result = pathmap::PathMap::new();
    for offset in 0u8..=10 {
        let mut p = vec![offset];
        for value in [1u8, 2, 3, 5, 8, 13] { p.extend([1, value]); }
        result.set_val_at(p, 0);
    }
    result
}

fn same_keys(actual: &Space, expected: &pathmap::PathMap<usize>) {
    let (mut a, mut b) = (actual.read_zipper(), expected.read_zipper());
    assert_eq!(a.is_val(), b.is_val());
    loop {
        let (am, bm) = (a.to_next_val(), b.to_next_val());
        assert_eq!(am, bm);
        if !am { break; }
        assert_eq!(a.path(), b.path());
    }
}

fn env(map: &Space) -> Env { Env { paths: vec![], spaces: vec![Some(map.clone())] } }
fn native_samples<F: FnMut() -> pathmap::PathMap<usize>>(stage: &str, samples: usize, mut f: F) -> pathmap::PathMap<usize> {
    let mut result = None;
    for sample in 0..samples {
        drop(result.take());
        let start = Instant::now();
        let map = std::hint::black_box(f());
        let elapsed = start.elapsed().as_nanos();
        let start = Instant::now();
        let paths = std::hint::black_box(map.val_count());
        let counting = start.elapsed().as_nanos();
        println!("PathMap,{stage},{sample},{elapsed},{counting},{paths}");
        result = Some(map);
    }
    result.unwrap()
}
fn zippy_samples(id: usize, stage: &str, samples: usize, c: &mut Context, e: &Env, expected: &pathmap::PathMap<usize>) -> Space {
    let mut result = None;
    for sample in 0..samples {
        drop(result.take());
        let start = Instant::now();
        let map = std::hint::black_box(execute(id,c,e));
        let elapsed = start.elapsed().as_nanos();
        let start = Instant::now();
        let paths = std::hint::black_box(count(&map));
        let counting = start.elapsed().as_nanos();
        assert_eq!(paths.to_string(), expected.val_count().to_string());
        println!("Zippy,{stage},{sample},{elapsed},{counting},{paths}");
        result = Some(map);
    }
    let result = result.unwrap(); same_keys(&result,expected); result
}

fn benchmark() {
    let args: Vec<String> = std::env::args().collect();
    let samples: usize = args.get(2).map_or(3,|n| n.parse().unwrap());
    assert!(samples>0);
    let seqs = sequences(&args[1]);
    eprintln!("OEIS records={}, nonempty={}",seqs.len(),seqs.iter().filter(|(_,s)| !s.is_empty()).count());
    let mut records = Space::new();
    let start = Instant::now();
    {
        let mut w = records.write_zipper();
        for (id, seq) in &seqs {
            if seq.is_empty() { continue; }
            w.descend_to((*id as u32).to_be_bytes()); w.descend_to(seq); w.set_val(()); w.reset();
        }
    }
    eprintln!("Record-trie ingestion_ns={} (outside Zippy execution)",start.elapsed().as_nanos());
    println!("engine,stage,sample,exec_ns,count_ns,paths");
    let mut c = Context::default();
    let built = native_samples("build_map",samples,|| native_build(&seqs));
    let zippy_built = zippy_samples(0,"build_map",samples,&mut c,&env(&records),&built);
    let indexed = native_samples("drophead_cold",samples,|| { let mut m=built.clone();native_drop(&mut m);m });
    let zippy_index = zippy_samples(1,"drophead_cold",samples,&mut c,&env(&zippy_built),&indexed);
    let mut steady = indexed.clone();
    for sample in 0..samples {
        let start=Instant::now();native_drop(&mut steady);let elapsed=start.elapsed().as_nanos();
        println!("PathMap,drophead_steady,{sample},{elapsed},0,{}",steady.val_count());
    }
    let _ = zippy_samples(1,"drophead_steady",samples,&mut c,&env(&zippy_index),&steady);
    let mask=query_mask();
    let found=native_samples("query",samples,|| indexed.restrict(&mask));
    let _=zippy_samples(2,"query",samples,&mut c,&env(&zippy_index),&found);
    let e=env(&zippy_index);
    for offset in 0u8..=10 {
        for sample in 0..samples {
            let start=Instant::now();let paths=std::hint::black_box(indexed.read_zipper_at_path(&[offset]).val_count());let elapsed=start.elapsed().as_nanos();
            println!("PathMap,contents_{offset},{sample},{elapsed},0,{paths}");
            let start=Instant::now();let sub=execute(3+offset as usize,&mut c,&e);let got=std::hint::black_box(count(&sub));let elapsed=start.elapsed().as_nanos();
            assert_eq!(got.to_string(),paths.to_string());
            println!("Zippy,contents_{offset},{sample},{elapsed},0,{got}");
        }
    }
    eprintln!("OEIS exact key-set checks passed for build, all ten offsets, and query");
}
fn main() {
    std::thread::Builder::new().stack_size(1024*1024*1024).spawn(benchmark).unwrap().join().unwrap();
}
