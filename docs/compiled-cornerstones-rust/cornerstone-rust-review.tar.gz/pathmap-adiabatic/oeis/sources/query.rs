#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("11 13 0 1 1 1 2 1 3 1 5 1 8 1 13 13 1 1 1 1 2 1 3 1 5 1 8 1 13 13 2 1 1 1 2 1 3 1 5 1 8 1 13 13 3 1 1 1 2 1 3 1 5 1 8 1 13 13 4 1 1 1 2 1 3 1 5 1 8 1 13 13 5 1 1 1 2 1 3 1 5 1 8 1 13 13 6 1 1 1 2 1 3 1 5 1 8 1 13 13 7 1 1 1 2 1 3 1 5 1 8 1 13 13 8 1 1 1 2 1 3 1 5 1 8 1 13 13 9 1 1 1 2 1 3 1 5 1 8 1 13 13 10 1 1 1 2 1 3 1 5 1 8 1 13"));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = restrict_to(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  (v0_2).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
