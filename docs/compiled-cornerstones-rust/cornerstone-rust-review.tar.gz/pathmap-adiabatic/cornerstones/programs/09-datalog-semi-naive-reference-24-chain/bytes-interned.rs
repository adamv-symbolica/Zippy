#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,2]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,3]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,4]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,5]));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,24]));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,25]));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,6]));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,7]));
static CONSTANT_10: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,8]));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,9]));
static CONSTANT_12: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,10]));
static CONSTANT_13: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,11]));
static CONSTANT_14: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,12]));
static CONSTANT_15: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,13]));
static CONSTANT_16: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,14]));
static CONSTANT_17: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,15]));
static CONSTANT_18: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,16]));
static CONSTANT_19: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,17]));
static CONSTANT_20: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,18]));
static CONSTANT_21: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,19]));
static CONSTANT_22: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,20]));
static CONSTANT_23: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,21]));
static CONSTANT_24: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,22]));
static CONSTANT_25: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,23]));
static CONSTANT_26: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,27]));
static CONSTANT_27: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("47 16 0 0 0 28 0 0 0 0 0 0 0 1 0 0 0 2 16 0 0 0 28 0 0 0 0 0 0 0 1 0 0 0 3 16 0 0 0 28 0 0 0 0 0 0 0 2 0 0 0 3 16 0 0 0 28 0 0 0 0 0 0 0 2 0 0 0 4 16 0 0 0 28 0 0 0 0 0 0 0 3 0 0 0 4 16 0 0 0 28 0 0 0 0 0 0 0 3 0 0 0 17 16 0 0 0 28 0 0 0 0 0 0 0 4 0 0 0 17 16 0 0 0 28 0 0 0 0 0 0 0 4 0 0 0 21 16 0 0 0 28 0 0 0 0 0 0 0 5 0 0 0 6 16 0 0 0 28 0 0 0 0 0 0 0 5 0 0 0 7 16 0 0 0 28 0 0 0 0 0 0 0 6 0 0 0 7 16 0 0 0 28 0 0 0 0 0 0 0 6 0 0 0 8 16 0 0 0 28 0 0 0 0 0 0 0 7 0 0 0 8 16 0 0 0 28 0 0 0 0 0 0 0 7 0 0 0 9 16 0 0 0 28 0 0 0 0 0 0 0 8 0 0 0 9 16 0 0 0 28 0 0 0 0 0 0 0 8 0 0 0 10 16 0 0 0 28 0 0 0 0 0 0 0 9 0 0 0 10 16 0 0 0 28 0 0 0 0 0 0 0 9 0 0 0 11 16 0 0 0 28 0 0 0 0 0 0 0 10 0 0 0 11 16 0 0 0 28 0 0 0 0 0 0 0 10 0 0 0 12 16 0 0 0 28 0 0 0 0 0 0 0 11 0 0 0 12 16 0 0 0 28 0 0 0 0 0 0 0 11 0 0 0 13 16 0 0 0 28 0 0 0 0 0 0 0 12 0 0 0 13 16 0 0 0 28 0 0 0 0 0 0 0 12 0 0 0 14 16 0 0 0 28 0 0 0 0 0 0 0 13 0 0 0 14 16 0 0 0 28 0 0 0 0 0 0 0 13 0 0 0 15 16 0 0 0 28 0 0 0 0 0 0 0 14 0 0 0 15 16 0 0 0 28 0 0 0 0 0 0 0 14 0 0 0 16 16 0 0 0 28 0 0 0 0 0 0 0 15 0 0 0 16 16 0 0 0 28 0 0 0 0 0 0 0 15 0 0 0 18 16 0 0 0 28 0 0 0 0 0 0 0 16 0 0 0 18 16 0 0 0 28 0 0 0 0 0 0 0 16 0 0 0 19 16 0 0 0 28 0 0 0 0 0 0 0 17 0 0 0 21 16 0 0 0 28 0 0 0 0 0 0 0 17 0 0 0 22 16 0 0 0 28 0 0 0 0 0 0 0 18 0 0 0 19 16 0 0 0 28 0 0 0 0 0 0 0 18 0 0 0 20 16 0 0 0 28 0 0 0 0 0 0 0 19 0 0 0 20 16 0 0 0 28 0 0 0 0 0 0 0 21 0 0 0 22 16 0 0 0 28 0 0 0 0 0 0 0 21 0 0 0 23 16 0 0 0 28 0 0 0 0 0 0 0 22 0 0 0 23 16 0 0 0 28 0 0 0 0 0 0 0 22 0 0 0 24 16 0 0 0 28 0 0 0 0 0 0 0 23 0 0 0 24 16 0 0 0 28 0 0 0 0 0 0 0 23 0 0 0 25 16 0 0 0 28 0 0 0 0 0 0 0 24 0 0 0 5 16 0 0 0 28 0 0 0 0 0 0 0 24 0 0 0 25 16 0 0 0 28 0 0 0 0 0 0 0 25 0 0 0 5 16 0 0 0 28 0 0 0 0 0 0 0 25 0 0 0 6"));
static CONSTANT_28: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,26]));
static CONSTANT_29: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,28]));
static CONSTANT_30: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_31: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,27,0,0,0,26]));
static CONSTANT_32: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,28,0,0,0,26]));
fn routine_0(c: &mut Context) -> Space {
  let v0_3: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
  let v0_6: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
  let v0_7: Space = unite(&(v0_3),&(v0_6));
  let v0_9: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_0), &((*CONSTANT_2).read_zipper()));
  let v0_10: Space = unite(&(v0_7),&(v0_9));
  let v0_13: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_0), &((*CONSTANT_2).read_zipper()));
  let v0_14: Space = unite(&(v0_10),&(v0_13));
  let v0_16: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_3), &((*CONSTANT_2).read_zipper()));
  let v0_17: Space = unite(&(v0_14),&(v0_16));
  let v0_21: Space = routine_1(c, &(*CONSTANT_5), &(*CONSTANT_6), &((*CONSTANT_2).read_zipper()));
  let v0_22: Space = unite(&(v0_17),&(v0_21));
  let v0_25: Space = routine_1(c, &(*CONSTANT_5), &(*CONSTANT_7), &((*CONSTANT_2).read_zipper()));
  let v0_26: Space = unite(&(v0_22),&(v0_25));
  let v0_29: Space = routine_1(c, &(*CONSTANT_8), &(*CONSTANT_5), &((*CONSTANT_2).read_zipper()));
  let v0_30: Space = unite(&(v0_26),&(v0_29));
  let v0_32: Space = routine_1(c, &(*CONSTANT_8), &(*CONSTANT_7), &((*CONSTANT_2).read_zipper()));
  let v0_33: Space = unite(&(v0_30),&(v0_32));
  let v0_36: Space = routine_1(c, &(*CONSTANT_9), &(*CONSTANT_5), &((*CONSTANT_2).read_zipper()));
  let v0_37: Space = unite(&(v0_33),&(v0_36));
  let v0_39: Space = routine_1(c, &(*CONSTANT_9), &(*CONSTANT_8), &((*CONSTANT_2).read_zipper()));
  let v0_40: Space = unite(&(v0_37),&(v0_39));
  let v0_43: Space = routine_1(c, &(*CONSTANT_10), &(*CONSTANT_8), &((*CONSTANT_2).read_zipper()));
  let v0_44: Space = unite(&(v0_40),&(v0_43));
  let v0_46: Space = routine_1(c, &(*CONSTANT_10), &(*CONSTANT_9), &((*CONSTANT_2).read_zipper()));
  let v0_47: Space = unite(&(v0_44),&(v0_46));
  let v0_50: Space = routine_1(c, &(*CONSTANT_11), &(*CONSTANT_9), &((*CONSTANT_2).read_zipper()));
  let v0_51: Space = unite(&(v0_47),&(v0_50));
  let v0_53: Space = routine_1(c, &(*CONSTANT_11), &(*CONSTANT_10), &((*CONSTANT_2).read_zipper()));
  let v0_54: Space = unite(&(v0_51),&(v0_53));
  let v0_57: Space = routine_1(c, &(*CONSTANT_12), &(*CONSTANT_10), &((*CONSTANT_2).read_zipper()));
  let v0_58: Space = unite(&(v0_54),&(v0_57));
  let v0_60: Space = routine_1(c, &(*CONSTANT_12), &(*CONSTANT_11), &((*CONSTANT_2).read_zipper()));
  let v0_61: Space = unite(&(v0_58),&(v0_60));
  let v0_64: Space = routine_1(c, &(*CONSTANT_13), &(*CONSTANT_11), &((*CONSTANT_2).read_zipper()));
  let v0_65: Space = unite(&(v0_61),&(v0_64));
  let v0_67: Space = routine_1(c, &(*CONSTANT_13), &(*CONSTANT_12), &((*CONSTANT_2).read_zipper()));
  let v0_68: Space = unite(&(v0_65),&(v0_67));
  let v0_71: Space = routine_1(c, &(*CONSTANT_14), &(*CONSTANT_12), &((*CONSTANT_2).read_zipper()));
  let v0_72: Space = unite(&(v0_68),&(v0_71));
  let v0_74: Space = routine_1(c, &(*CONSTANT_14), &(*CONSTANT_13), &((*CONSTANT_2).read_zipper()));
  let v0_75: Space = unite(&(v0_72),&(v0_74));
  let v0_78: Space = routine_1(c, &(*CONSTANT_15), &(*CONSTANT_13), &((*CONSTANT_2).read_zipper()));
  let v0_79: Space = unite(&(v0_75),&(v0_78));
  let v0_81: Space = routine_1(c, &(*CONSTANT_15), &(*CONSTANT_14), &((*CONSTANT_2).read_zipper()));
  let v0_82: Space = unite(&(v0_79),&(v0_81));
  let v0_85: Space = routine_1(c, &(*CONSTANT_16), &(*CONSTANT_14), &((*CONSTANT_2).read_zipper()));
  let v0_86: Space = unite(&(v0_82),&(v0_85));
  let v0_88: Space = routine_1(c, &(*CONSTANT_16), &(*CONSTANT_15), &((*CONSTANT_2).read_zipper()));
  let v0_89: Space = unite(&(v0_86),&(v0_88));
  let v0_92: Space = routine_1(c, &(*CONSTANT_17), &(*CONSTANT_15), &((*CONSTANT_2).read_zipper()));
  let v0_93: Space = unite(&(v0_89),&(v0_92));
  let v0_95: Space = routine_1(c, &(*CONSTANT_17), &(*CONSTANT_16), &((*CONSTANT_2).read_zipper()));
  let v0_96: Space = unite(&(v0_93),&(v0_95));
  let v0_99: Space = routine_1(c, &(*CONSTANT_18), &(*CONSTANT_16), &((*CONSTANT_2).read_zipper()));
  let v0_100: Space = unite(&(v0_96),&(v0_99));
  let v0_102: Space = routine_1(c, &(*CONSTANT_18), &(*CONSTANT_17), &((*CONSTANT_2).read_zipper()));
  let v0_103: Space = unite(&(v0_100),&(v0_102));
  let v0_106: Space = routine_1(c, &(*CONSTANT_19), &(*CONSTANT_3), &((*CONSTANT_2).read_zipper()));
  let v0_107: Space = unite(&(v0_103),&(v0_106));
  let v0_109: Space = routine_1(c, &(*CONSTANT_19), &(*CONSTANT_4), &((*CONSTANT_2).read_zipper()));
  let v0_110: Space = unite(&(v0_107),&(v0_109));
  let v0_113: Space = routine_1(c, &(*CONSTANT_20), &(*CONSTANT_17), &((*CONSTANT_2).read_zipper()));
  let v0_114: Space = unite(&(v0_110),&(v0_113));
  let v0_116: Space = routine_1(c, &(*CONSTANT_20), &(*CONSTANT_18), &((*CONSTANT_2).read_zipper()));
  let v0_117: Space = unite(&(v0_114),&(v0_116));
  let v0_120: Space = routine_1(c, &(*CONSTANT_21), &(*CONSTANT_18), &((*CONSTANT_2).read_zipper()));
  let v0_121: Space = unite(&(v0_117),&(v0_120));
  let v0_123: Space = routine_1(c, &(*CONSTANT_21), &(*CONSTANT_20), &((*CONSTANT_2).read_zipper()));
  let v0_124: Space = unite(&(v0_121),&(v0_123));
  let v0_127: Space = routine_1(c, &(*CONSTANT_22), &(*CONSTANT_20), &((*CONSTANT_2).read_zipper()));
  let v0_128: Space = unite(&(v0_124),&(v0_127));
  let v0_130: Space = routine_1(c, &(*CONSTANT_22), &(*CONSTANT_21), &((*CONSTANT_2).read_zipper()));
  let v0_131: Space = unite(&(v0_128),&(v0_130));
  let v0_134: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_4), &((*CONSTANT_2).read_zipper()));
  let v0_135: Space = unite(&(v0_131),&(v0_134));
  let v0_137: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_19), &((*CONSTANT_2).read_zipper()));
  let v0_138: Space = unite(&(v0_135),&(v0_137));
  let v0_141: Space = routine_1(c, &(*CONSTANT_24), &(*CONSTANT_19), &((*CONSTANT_2).read_zipper()));
  let v0_142: Space = unite(&(v0_138),&(v0_141));
  let v0_144: Space = routine_1(c, &(*CONSTANT_24), &(*CONSTANT_23), &((*CONSTANT_2).read_zipper()));
  let v0_145: Space = unite(&(v0_142),&(v0_144));
  let v0_148: Space = routine_1(c, &(*CONSTANT_25), &(*CONSTANT_23), &((*CONSTANT_2).read_zipper()));
  let v0_149: Space = unite(&(v0_145),&(v0_148));
  let v0_151: Space = routine_1(c, &(*CONSTANT_25), &(*CONSTANT_24), &((*CONSTANT_2).read_zipper()));
  let v0_152: Space = unite(&(v0_149),&(v0_151));
  let v0_154: Space = routine_1(c, &(*CONSTANT_6), &(*CONSTANT_24), &((*CONSTANT_2).read_zipper()));
  let v0_155: Space = unite(&(v0_152),&(v0_154));
  let v0_157: Space = routine_1(c, &(*CONSTANT_6), &(*CONSTANT_25), &((*CONSTANT_2).read_zipper()));
  let v0_158: Space = unite(&(v0_155),&(v0_157));
  let v0_160: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_25), &((*CONSTANT_2).read_zipper()));
  let v0_161: Space = unite(&(v0_158),&(v0_160));
  let v0_163: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_6), &((*CONSTANT_2).read_zipper()));
  let v0_164: Space = unite(&(v0_161),&(v0_163));
  let v0_166: Space = wrap(&(v0_164),&(*CONSTANT_26));
  let v0_168: Space = unite(&(v0_166),&(*CONSTANT_27));
  let mut v0_174: Space = (v0_168).clone();
  loop {
    let mut v1_3 = Space::new();
    let mut v1_3_write = v1_3.write_zipper();
    let mut v1_3_cursor = descend_cursor(descend_cursor((v0_174).read_zipper(),&(*CONSTANT_26)),&(*CONSTANT_28));
    let v1_3_origin = v1_3_cursor.path().len();
    for v1_3_byte in v1_3_cursor.child_mask().iter() {
      v1_3_cursor.descend_to_existing_byte(v1_3_byte);
      {
      for v2_2_byte in v1_3_cursor.child_mask().iter() {
        v1_3_cursor.descend_to_existing_byte(v2_2_byte);
        {
        for v3_3_byte in v1_3_cursor.child_mask().iter() {
          v1_3_cursor.descend_to_existing_byte(v3_3_byte);
          {
          for v4_3_byte in v1_3_cursor.child_mask().iter() {
            v1_3_cursor.descend_to_existing_byte(v4_3_byte);
            {
            for v5_3_byte in v1_3_cursor.child_mask().iter() {
              v1_3_cursor.descend_to_existing_byte(v5_3_byte);
              {
              for v6_2_byte in v1_3_cursor.child_mask().iter() {
                v1_3_cursor.descend_to_existing_byte(v6_2_byte);
                {
                for v7_3_byte in v1_3_cursor.child_mask().iter() {
                  v1_3_cursor.descend_to_existing_byte(v7_3_byte);
                  {
                  for v8_3_byte in v1_3_cursor.child_mask().iter() {
                    v1_3_cursor.descend_to_existing_byte(v8_3_byte);
                    {
                    let v9_3: Space = routine_2(c, &v1_3_cursor.path()[(v1_3_origin + 4)..(v1_3_origin + 8)], &v1_3_cursor.path()[v1_3_origin..(v1_3_origin + 4)], &v1_3_cursor, &((v0_174).read_zipper()));
                    join_wrapped_into(&mut v1_3_write,&((v9_3).read_zipper()),&[]);
                    }
                    v1_3_cursor.ascend(1);
                  }
                  }
                  v1_3_cursor.ascend(1);
                }
                }
                v1_3_cursor.ascend(1);
              }
              }
              v1_3_cursor.ascend(1);
            }
            }
            v1_3_cursor.ascend(1);
          }
          }
          v1_3_cursor.ascend(1);
        }
        }
        v1_3_cursor.ascend(1);
      }
      }
      v1_3_cursor.ascend(1);
    }
    drop(v1_3_cursor);
    drop(v1_3_write);
    let mut v1_4 = Space::new();
    let mut v1_4_write = v1_4.write_zipper();
    let mut v1_4_cursor = descend_cursor(descend_cursor((v0_174).read_zipper(),&(*CONSTANT_26)),&(*CONSTANT_28));
    let v1_4_origin = v1_4_cursor.path().len();
    for v1_4_byte in v1_4_cursor.child_mask().iter() {
      v1_4_cursor.descend_to_existing_byte(v1_4_byte);
      {
      for v10_2_byte in v1_4_cursor.child_mask().iter() {
        v1_4_cursor.descend_to_existing_byte(v10_2_byte);
        {
        for v11_3_byte in v1_4_cursor.child_mask().iter() {
          v1_4_cursor.descend_to_existing_byte(v11_3_byte);
          {
          for v12_3_byte in v1_4_cursor.child_mask().iter() {
            v1_4_cursor.descend_to_existing_byte(v12_3_byte);
            {
            for v13_3_byte in v1_4_cursor.child_mask().iter() {
              v1_4_cursor.descend_to_existing_byte(v13_3_byte);
              {
              for v14_2_byte in v1_4_cursor.child_mask().iter() {
                v1_4_cursor.descend_to_existing_byte(v14_2_byte);
                {
                for v15_3_byte in v1_4_cursor.child_mask().iter() {
                  v1_4_cursor.descend_to_existing_byte(v15_3_byte);
                  {
                  for v16_3_byte in v1_4_cursor.child_mask().iter() {
                    v1_4_cursor.descend_to_existing_byte(v16_3_byte);
                    {
                    let v17_3: Space = routine_3(c, &v1_4_cursor.path()[(v1_4_origin + 4)..(v1_4_origin + 8)], &v1_4_cursor.path()[v1_4_origin..(v1_4_origin + 4)], &v1_4_cursor, &((v0_174).read_zipper()));
                    join_wrapped_into(&mut v1_4_write,&((v17_3).read_zipper()),&[]);
                    }
                    v1_4_cursor.ascend(1);
                  }
                  }
                  v1_4_cursor.ascend(1);
                }
                }
                v1_4_cursor.ascend(1);
              }
              }
              v1_4_cursor.ascend(1);
            }
            }
            v1_4_cursor.ascend(1);
          }
          }
          v1_4_cursor.ascend(1);
        }
        }
        v1_4_cursor.ascend(1);
      }
      }
      v1_4_cursor.ascend(1);
    }
    drop(v1_4_cursor);
    drop(v1_4_write);
    let v1_5: Space = unite(&(v1_3),&(v1_4));
    let mut v1_8 = Space::new();
    let mut v1_8_write = v1_8.write_zipper();
    let mut v1_8_cursor = descend_cursor(descend_cursor((v0_174).read_zipper(),&(*CONSTANT_29)),&(*CONSTANT_30));
    let v1_8_origin = v1_8_cursor.path().len();
    for v1_8_byte in v1_8_cursor.child_mask().iter() {
      v1_8_cursor.descend_to_existing_byte(v1_8_byte);
      {
      for v18_2_byte in v1_8_cursor.child_mask().iter() {
        v1_8_cursor.descend_to_existing_byte(v18_2_byte);
        {
        for v19_3_byte in v1_8_cursor.child_mask().iter() {
          v1_8_cursor.descend_to_existing_byte(v19_3_byte);
          {
          for v20_3_byte in v1_8_cursor.child_mask().iter() {
            v1_8_cursor.descend_to_existing_byte(v20_3_byte);
            {
            for v21_3_byte in v1_8_cursor.child_mask().iter() {
              v1_8_cursor.descend_to_existing_byte(v21_3_byte);
              {
              for v22_2_byte in v1_8_cursor.child_mask().iter() {
                v1_8_cursor.descend_to_existing_byte(v22_2_byte);
                {
                for v23_3_byte in v1_8_cursor.child_mask().iter() {
                  v1_8_cursor.descend_to_existing_byte(v23_3_byte);
                  {
                  for v24_3_byte in v1_8_cursor.child_mask().iter() {
                    v1_8_cursor.descend_to_existing_byte(v24_3_byte);
                    {
                    let v25_3: Space = routine_4(c, &v1_8_cursor.path()[(v1_8_origin + 4)..(v1_8_origin + 8)], &v1_8_cursor.path()[v1_8_origin..(v1_8_origin + 4)], &v1_8_cursor);
                    join_wrapped_into(&mut v1_8_write,&((v25_3).read_zipper()),&[]);
                    }
                    v1_8_cursor.ascend(1);
                  }
                  }
                  v1_8_cursor.ascend(1);
                }
                }
                v1_8_cursor.ascend(1);
              }
              }
              v1_8_cursor.ascend(1);
            }
            }
            v1_8_cursor.ascend(1);
          }
          }
          v1_8_cursor.ascend(1);
        }
        }
        v1_8_cursor.ascend(1);
      }
      }
      v1_8_cursor.ascend(1);
    }
    drop(v1_8_cursor);
    drop(v1_8_write);
    let v1_9: Space = unite(&(v1_5),&(v1_8));
    let mut v1_11 = Space::new();
    let mut v1_11_write = v1_11.write_zipper();
    let mut v1_11_cursor = descend_cursor(descend_cursor((v0_174).read_zipper(),&(*CONSTANT_29)),&(*CONSTANT_28));
    let v1_11_origin = v1_11_cursor.path().len();
    for v1_11_byte in v1_11_cursor.child_mask().iter() {
      v1_11_cursor.descend_to_existing_byte(v1_11_byte);
      {
      for v26_2_byte in v1_11_cursor.child_mask().iter() {
        v1_11_cursor.descend_to_existing_byte(v26_2_byte);
        {
        for v27_3_byte in v1_11_cursor.child_mask().iter() {
          v1_11_cursor.descend_to_existing_byte(v27_3_byte);
          {
          for v28_3_byte in v1_11_cursor.child_mask().iter() {
            v1_11_cursor.descend_to_existing_byte(v28_3_byte);
            {
            for v29_3_byte in v1_11_cursor.child_mask().iter() {
              v1_11_cursor.descend_to_existing_byte(v29_3_byte);
              {
              for v30_2_byte in v1_11_cursor.child_mask().iter() {
                v1_11_cursor.descend_to_existing_byte(v30_2_byte);
                {
                for v31_3_byte in v1_11_cursor.child_mask().iter() {
                  v1_11_cursor.descend_to_existing_byte(v31_3_byte);
                  {
                  for v32_3_byte in v1_11_cursor.child_mask().iter() {
                    v1_11_cursor.descend_to_existing_byte(v32_3_byte);
                    {
                    let v33_3: Space = routine_5(c, &v1_11_cursor.path()[(v1_11_origin + 4)..(v1_11_origin + 8)], &v1_11_cursor.path()[v1_11_origin..(v1_11_origin + 4)], &v1_11_cursor, &((v0_174).read_zipper()));
                    join_wrapped_into(&mut v1_11_write,&((v33_3).read_zipper()),&[]);
                    }
                    v1_11_cursor.ascend(1);
                  }
                  }
                  v1_11_cursor.ascend(1);
                }
                }
                v1_11_cursor.ascend(1);
              }
              }
              v1_11_cursor.ascend(1);
            }
            }
            v1_11_cursor.ascend(1);
          }
          }
          v1_11_cursor.ascend(1);
        }
        }
        v1_11_cursor.ascend(1);
      }
      }
      v1_11_cursor.ascend(1);
    }
    drop(v1_11_cursor);
    drop(v1_11_write);
    let v1_12: Space = unite(&(v1_9),&(v1_11));
    let v1_14: Space = subtract(&(v1_12),&(descend_cursor((v0_174).read_zipper(),&(*CONSTANT_31))));
    let v1_16: Space = subtract(&(v1_14),&(descend_cursor((v0_174).read_zipper(),&(*CONSTANT_32))));
    let v1_17: Space = wrap(&(v1_16),&(*CONSTANT_31));
    let v1_18: Space = unite(&(descend_cursor((v0_174).read_zipper(),&(*CONSTANT_26))),&(descend_cursor((v0_174).read_zipper(),&(*CONSTANT_29))));
    let v1_19: Space = wrap(&(v1_18),&(*CONSTANT_29));
    drop(v1_18);
    let v1_20: Space = unite(&(v1_17),&(v1_19));
    drop(v1_19);
    let v1_21: Space = unite(&(v1_20),&(v0_174));
    if !v0_174.join_into((v1_21).clone()).is_element() { break; }
  }
  (&(descend_cursor((v0_174).read_zipper(),&(*CONSTANT_32)))).make_map()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v34_3: Space = wrap(&(*s0),&(*p0));
  let v34_4: Space = wrap(&(v34_3),&(*p1));
  drop(v34_3);
  let v34_6: Space = wrap(&(v34_4),&(*CONSTANT_28));
  drop(v34_4);
  (v34_6).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v35_10 = Space::new();
  let mut v35_10_write = v35_10.write_zipper();
  let mut v35_10_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_29)),&(*CONSTANT_28)),&(*p0));
  let v35_10_origin = v35_10_cursor.path().len();
  for v35_10_byte in v35_10_cursor.child_mask().iter() {
    v35_10_cursor.descend_to_existing_byte(v35_10_byte);
    {
    for v36_2_byte in v35_10_cursor.child_mask().iter() {
      v35_10_cursor.descend_to_existing_byte(v36_2_byte);
      {
      for v37_3_byte in v35_10_cursor.child_mask().iter() {
        v35_10_cursor.descend_to_existing_byte(v37_3_byte);
        {
        v35_10_write.descend_to(&v35_10_cursor.path()[v35_10_origin..(v35_10_origin + 3)]);
        join_branches(&mut v35_10_write,&mut v35_10_cursor);
        v35_10_write.ascend((&v35_10_cursor.path()[v35_10_origin..(v35_10_origin + 3)]).len());
        }
        v35_10_cursor.ascend(1);
      }
      }
      v35_10_cursor.ascend(1);
    }
    }
    v35_10_cursor.ascend(1);
  }
  drop(v35_10_cursor);
  drop(v35_10_write);
  let v35_11: Space = wrap(&(v35_10),&(*p1));
  drop(v35_10);
  (v35_11).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v39_10 = Space::new();
  let mut v39_10_write = v39_10.write_zipper();
  let mut v39_10_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_26)),&(*CONSTANT_28)),&(*p0));
  let v39_10_origin = v39_10_cursor.path().len();
  for v39_10_byte in v39_10_cursor.child_mask().iter() {
    v39_10_cursor.descend_to_existing_byte(v39_10_byte);
    {
    for v40_2_byte in v39_10_cursor.child_mask().iter() {
      v39_10_cursor.descend_to_existing_byte(v40_2_byte);
      {
      for v41_3_byte in v39_10_cursor.child_mask().iter() {
        v39_10_cursor.descend_to_existing_byte(v41_3_byte);
        {
        v39_10_write.descend_to(&v39_10_cursor.path()[v39_10_origin..(v39_10_origin + 3)]);
        join_branches(&mut v39_10_write,&mut v39_10_cursor);
        v39_10_write.ascend((&v39_10_cursor.path()[v39_10_origin..(v39_10_origin + 3)]).len());
        }
        v39_10_cursor.ascend(1);
      }
      }
      v39_10_cursor.ascend(1);
    }
    }
    v39_10_cursor.ascend(1);
  }
  drop(v39_10_cursor);
  drop(v39_10_write);
  let v39_11: Space = wrap(&(v39_10),&(*p1));
  drop(v39_10);
  (v39_11).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v43_3: Space = wrap(&(*s0),&(*p0));
  let v43_4: Space = wrap(&(v43_3),&(*p1));
  drop(v43_3);
  (v43_4).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v44_10 = Space::new();
  let mut v44_10_write = v44_10.write_zipper();
  let mut v44_10_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_26)),&(*CONSTANT_28)),&(*p0));
  let v44_10_origin = v44_10_cursor.path().len();
  for v44_10_byte in v44_10_cursor.child_mask().iter() {
    v44_10_cursor.descend_to_existing_byte(v44_10_byte);
    {
    for v45_2_byte in v44_10_cursor.child_mask().iter() {
      v44_10_cursor.descend_to_existing_byte(v45_2_byte);
      {
      for v46_3_byte in v44_10_cursor.child_mask().iter() {
        v44_10_cursor.descend_to_existing_byte(v46_3_byte);
        {
        v44_10_write.descend_to(&v44_10_cursor.path()[v44_10_origin..(v44_10_origin + 3)]);
        join_branches(&mut v44_10_write,&mut v44_10_cursor);
        v44_10_write.ascend((&v44_10_cursor.path()[v44_10_origin..(v44_10_origin + 3)]).len());
        }
        v44_10_cursor.ascend(1);
      }
      }
      v44_10_cursor.ascend(1);
    }
    }
    v44_10_cursor.ascend(1);
  }
  drop(v44_10_cursor);
  drop(v44_10_write);
  let v44_11: Space = wrap(&(v44_10),&(*p1));
  drop(v44_10);
  (v44_11).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
