#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[2]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("20 5 110 48 2 110 49 5 110 48 2 110 50 5 110 49 2 110 50 5 110 49 2 110 51 5 110 50 2 110 51 5 110 50 2 110 52 5 110 51 2 110 52 5 110 51 2 110 53 5 110 52 2 110 53 5 110 52 2 110 54 5 110 53 2 110 54 5 110 53 2 110 55 5 110 54 2 110 55 5 110 54 2 110 56 5 110 55 2 110 56 5 110 55 2 110 57 5 110 56 2 110 57 6 110 56 3 110 49 48 6 110 57 3 110 49 48 6 110 57 3 110 49 49"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[3]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 2"));
static CONSTANT_7: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("27 7 110 49 48 3 110 49 49 7 110 49 48 3 110 49 50 7 110 49 49 3 110 49 50 7 110 49 49 3 110 49 51 7 110 49 50 3 110 49 51 7 110 49 50 3 110 49 52 7 110 49 51 3 110 49 52 7 110 49 51 3 110 49 53 7 110 49 52 3 110 49 53 7 110 49 52 3 110 49 54 7 110 49 53 3 110 49 54 7 110 49 53 3 110 49 55 7 110 49 54 3 110 49 55 7 110 49 54 3 110 49 56 7 110 49 55 3 110 49 56 7 110 49 55 3 110 49 57 7 110 49 56 3 110 49 57 7 110 49 56 3 110 50 48 7 110 49 57 3 110 50 48 7 110 49 57 3 110 50 49 7 110 50 48 3 110 50 49 7 110 50 48 3 110 50 50 7 110 50 49 3 110 50 50 7 110 50 49 3 110 50 51 7 110 50 50 3 110 50 51 7 110 50 50 3 110 50 52 7 110 50 51 3 110 50 52"));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[5,100,101,108,116,97]));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("47 20 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 48 2 110 49 20 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 48 2 110 50 20 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 49 2 110 50 20 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 49 2 110 51 20 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 50 2 110 51 20 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 50 2 110 52 20 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 51 2 110 52 20 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 51 2 110 53 20 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 52 2 110 53 20 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 52 2 110 54 20 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 53 2 110 54 20 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 53 2 110 55 20 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 54 2 110 55 20 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 54 2 110 56 20 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 55 2 110 56 20 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 55 2 110 57 20 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 56 2 110 57 21 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 56 3 110 49 48 21 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 57 3 110 49 48 21 8 99 111 109 112 108 101 116 101 4 101 100 103 101 2 110 57 3 110 49 49 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 48 3 110 49 49 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 48 3 110 49 50 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 49 3 110 49 50 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 49 3 110 49 51 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 50 3 110 49 51 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 50 3 110 49 52 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 51 3 110 49 52 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 51 3 110 49 53 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 52 3 110 49 53 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 52 3 110 49 54 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 53 3 110 49 54 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 53 3 110 49 55 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 54 3 110 49 55 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 54 3 110 49 56 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 55 3 110 49 56 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 55 3 110 49 57 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 56 3 110 49 57 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 56 3 110 50 48 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 57 3 110 50 48 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 49 57 3 110 50 49 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 50 48 3 110 50 49 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 50 48 3 110 50 50 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 50 49 3 110 50 50 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 50 49 3 110 50 51 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 50 50 3 110 50 51 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 50 50 3 110 50 52 22 8 99 111 109 112 108 101 116 101 4 101 100 103 101 3 110 50 51 3 110 50 52"));
static CONSTANT_10: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4,112,97,116,104]));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[8,99,111,109,112,108,101,116,101]));
static CONSTANT_12: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4,101,100,103,101]));
static CONSTANT_13: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[5,100,101,108,116,97,4,112,97,116,104]));
static CONSTANT_14: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[8,99,111,109,112,108,101,116,101,4,112,97,116,104]));
static CONSTANT_15: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_16: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("255 2 1 0 2 2 1 2 3 2 2 4 3 2 5 4 2 6 5 2 7 6 2 8 7 2 9 8 2 10 9 2 11 10 2 12 11 2 13 12 2 14 13 2 15 14 2 16 15 2 17 16 2 18 17 2 19 18 2 20 19 2 21 20 2 22 21 2 23 22 2 24 23 2 25 24 2 26 25 2 27 26 2 28 27 2 29 28 2 30 29 2 31 30 2 32 31 2 33 32 2 34 33 2 35 34 2 36 35 2 37 36 2 38 37 2 39 38 2 40 39 2 41 40 2 42 41 2 43 42 2 44 43 2 45 44 2 46 45 2 47 46 2 48 47 2 49 48 2 50 49 2 51 50 2 52 51 2 53 52 2 54 53 2 55 54 2 56 55 2 57 56 2 58 57 2 59 58 2 60 59 2 61 60 2 62 61 2 63 62 2 64 63 2 65 64 2 66 65 2 67 66 2 68 67 2 69 68 2 70 69 2 71 70 2 72 71 2 73 72 2 74 73 2 75 74 2 76 75 2 77 76 2 78 77 2 79 78 2 80 79 2 81 80 2 82 81 2 83 82 2 84 83 2 85 84 2 86 85 2 87 86 2 88 87 2 89 88 2 90 89 2 91 90 2 92 91 2 93 92 2 94 93 2 95 94 2 96 95 2 97 96 2 98 97 2 99 98 2 100 99 2 101 100 2 102 101 2 103 102 2 104 103 2 105 104 2 106 105 2 107 106 2 108 107 2 109 108 2 110 109 2 111 110 2 112 111 2 113 112 2 114 113 2 115 114 2 116 115 2 117 116 2 118 117 2 119 118 2 120 119 2 121 120 2 122 121 2 123 122 2 124 123 2 125 124 2 126 125 2 127 126 2 128 127 2 129 128 2 130 129 2 131 130 2 132 131 2 133 132 2 134 133 2 135 134 2 136 135 2 137 136 2 138 137 2 139 138 2 140 139 2 141 140 2 142 141 2 143 142 2 144 143 2 145 144 2 146 145 2 147 146 2 148 147 2 149 148 2 150 149 2 151 150 2 152 151 2 153 152 2 154 153 2 155 154 2 156 155 2 157 156 2 158 157 2 159 158 2 160 159 2 161 160 2 162 161 2 163 162 2 164 163 2 165 164 2 166 165 2 167 166 2 168 167 2 169 168 2 170 169 2 171 170 2 172 171 2 173 172 2 174 173 2 175 174 2 176 175 2 177 176 2 178 177 2 179 178 2 180 179 2 181 180 2 182 181 2 183 182 2 184 183 2 185 184 2 186 185 2 187 186 2 188 187 2 189 188 2 190 189 2 191 190 2 192 191 2 193 192 2 194 193 2 195 194 2 196 195 2 197 196 2 198 197 2 199 198 2 200 199 2 201 200 2 202 201 2 203 202 2 204 203 2 205 204 2 206 205 2 207 206 2 208 207 2 209 208 2 210 209 2 211 210 2 212 211 2 213 212 2 214 213 2 215 214 2 216 215 2 217 216 2 218 217 2 219 218 2 220 219 2 221 220 2 222 221 2 223 222 2 224 223 2 225 224 2 226 225 2 227 226 2 228 227 2 229 228 2 230 229 2 231 230 2 232 231 2 233 232 2 234 233 2 235 234 2 236 235 2 237 236 2 238 237 2 239 238 2 240 239 2 241 240 2 242 241 2 243 242 2 244 243 2 245 244 2 246 245 2 247 246 2 248 247 2 249 248 2 250 249 2 251 250 2 252 251 2 253 252 2 254 253 2 255 254"));
fn routine_0(c: &mut Context) -> Space {
  let v0_11: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let mut v1_5 = Space::new();
    let mut v1_5_write = v1_5.write_zipper();
    let v1_5_arg_0: &[u8] = &(*CONSTANT_1);
    let v1_5_arg_1: &[u8] = &(*CONSTANT_2);
    let v1_5_arg_3: &Space = &(*CONSTANT_4);
    let mut v1_5_cursor = (*CONSTANT_3).read_zipper();
    let v1_5_origin = v1_5_cursor.path().len();
    let mut v1_5_more = v1_5_cursor.is_val() || next_value_within(&mut v1_5_cursor,v1_5_origin);
    while v1_5_more {
      {
      let v1_5_depth = v1_5_cursor.path().len();
      let mut v2_4_cursor = (*v1_5_arg_3).read_zipper();
      let v2_4_origin = v2_4_cursor.path().len();
      for v2_4_byte in v2_4_cursor.child_mask().iter() {
        v2_4_cursor.descend_to_existing_byte(v2_4_byte);
        {
        let v3_2: Path = concat_path(&(*v1_5_arg_1),&v2_4_cursor.path()[v2_4_origin..(v2_4_origin + 1)]);
        let v3_3: Space = routine_1(c, &(v3_2), &v1_5_cursor.path()[v1_5_origin..v1_5_depth], &v2_4_cursor);
        drop(v3_2);
        join_wrapped_into(&mut v1_5_write,&((v3_3).read_zipper()),&[]);
        }
        v2_4_cursor.ascend(1);
      }
      drop(v2_4_cursor);
      }
      v1_5_more = next_value_within(&mut v1_5_cursor,v1_5_origin);
    }
    drop(v1_5_cursor);
    drop(v1_5_write);
    let mut v1_9 = Space::new();
    let mut v1_9_write = v1_9.write_zipper();
    let v1_9_arg_0: &[u8] = &(*CONSTANT_1);
    let v1_9_arg_1: &[u8] = &(*CONSTANT_5);
    let v1_9_arg_3: &Space = &(*CONSTANT_7);
    let mut v1_9_cursor = (*CONSTANT_6).read_zipper();
    let v1_9_origin = v1_9_cursor.path().len();
    let mut v1_9_more = v1_9_cursor.is_val() || next_value_within(&mut v1_9_cursor,v1_9_origin);
    while v1_9_more {
      {
      let v1_9_depth = v1_9_cursor.path().len();
      let mut v4_4_cursor = (*v1_9_arg_3).read_zipper();
      let v4_4_origin = v4_4_cursor.path().len();
      for v4_4_byte in v4_4_cursor.child_mask().iter() {
        v4_4_cursor.descend_to_existing_byte(v4_4_byte);
        {
        let v5_2: Path = concat_path(&(*v1_9_arg_1),&v4_4_cursor.path()[v4_4_origin..(v4_4_origin + 1)]);
        let v5_3: Space = routine_1(c, &(v5_2), &v1_9_cursor.path()[v1_9_origin..v1_9_depth], &v4_4_cursor);
        drop(v5_2);
        join_wrapped_into(&mut v1_9_write,&((v5_3).read_zipper()),&[]);
        }
        v4_4_cursor.ascend(1);
      }
      drop(v4_4_cursor);
      }
      v1_9_more = next_value_within(&mut v1_9_cursor,v1_9_origin);
    }
    drop(v1_9_cursor);
    drop(v1_9_write);
    let v1_10: Space = unite(&(v1_5),&(v1_9));
    compose(&(*CONSTANT_0),&(v1_10))
  };
  let v0_13: Space = wrap(&(v0_11),&(*CONSTANT_8));
  let v0_15: Space = unite(&(v0_13),&(*CONSTANT_9));
  let mut v0_37: Space = (v0_15).clone();
  loop {
    let mut v6_3 = Space::new();
    let mut v6_3_write = v6_3.write_zipper();
    let mut v6_3_cursor = descend_cursor(descend_cursor((v0_37).read_zipper(),&(*CONSTANT_8)),&(*CONSTANT_10));
    let v6_3_origin = v6_3_cursor.path().len();
    for v6_3_byte in v6_3_cursor.child_mask().iter() {
      v6_3_cursor.descend_to_existing_byte(v6_3_byte);
      {
      let v7_2: Space = singleton(&v6_3_cursor.path()[v6_3_origin..(v6_3_origin + 1)]);
      let v7_3: Space = intersect(&(*CONSTANT_15),&(v7_2));
      let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
      drop(v7_3);
      let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
      drop(v7_4);
      let v7_8: Space = if (&(v7_5)).is_empty() { Space::new() } else {
        let mut v8_7 = Space::new();
        let mut v8_7_write = v8_7.write_zipper();
        let v8_7_arg_0: &[u8] = &(*CONSTANT_1);
        let v8_7_arg_1: &[u8] = &v6_3_cursor.path()[v6_3_origin..(v6_3_origin + 1)];
        let v8_7_arg_3: &Space = &(&v6_3_cursor).make_map();
        let v8_7_arg_4: &Space = &(v0_37);
        let mut v8_7_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&v6_3_cursor.path()[v6_3_origin..(v6_3_origin + 1)]);
        let v8_7_origin = v8_7_cursor.path().len();
        let mut v8_7_more = v8_7_cursor.is_val() || next_value_within(&mut v8_7_cursor,v8_7_origin);
        while v8_7_more {
          {
          let v8_7_depth = v8_7_cursor.path().len();
          let mut v9_5_cursor = (*v8_7_arg_3).read_zipper();
          let v9_5_origin = v9_5_cursor.path().len();
          for v9_5_byte in v9_5_cursor.child_mask().iter() {
            v9_5_cursor.descend_to_existing_byte(v9_5_byte);
            {
            let v10_2: Path = concat_path(&(*v8_7_arg_1),&v9_5_cursor.path()[v9_5_origin..(v9_5_origin + 1)]);
            let v10_3: Space = routine_2(c, &(v10_2), &v8_7_cursor.path()[v8_7_origin..v8_7_depth], &v9_5_cursor, &((*v8_7_arg_4).read_zipper()));
            drop(v10_2);
            join_wrapped_into(&mut v8_7_write,&((v10_3).read_zipper()),&[]);
            }
            v9_5_cursor.ascend(1);
          }
          drop(v9_5_cursor);
          }
          v8_7_more = next_value_within(&mut v8_7_cursor,v8_7_origin);
        }
        drop(v8_7_cursor);
        drop(v8_7_write);
        compose(&(v7_5),&(v8_7))
      };
      drop(v7_5);
      let v7_9: Space = intersect(&(*CONSTANT_15),&(v7_2));
      drop(v7_2);
      let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
      drop(v7_9);
      let v7_12: Space = if (&(v7_10)).is_empty() { Space::new() } else {
        let mut v11_11 = Space::new();
        let mut v11_11_write = v11_11.write_zipper();
        for v11_11_byte in v6_3_cursor.child_mask().iter() {
          v6_3_cursor.descend_to_existing_byte(v11_11_byte);
          {
          let v12_2: Space = routine_3(c, &v6_3_cursor.path()[(v6_3_origin + 1)..(v6_3_origin + 2)], &v6_3_cursor.path()[(v6_3_origin + 1)..(v6_3_origin + 2)], &v6_3_cursor.path()[v6_3_origin..(v6_3_origin + 1)], &v6_3_cursor, &((v0_37).read_zipper()));
          join_wrapped_into(&mut v11_11_write,&((v12_2).read_zipper()),&[]);
          }
          v6_3_cursor.ascend(1);
        }
        drop(v11_11_write);
        compose(&(v7_10),&(v11_11))
      };
      drop(v7_10);
      let v7_13: Space = unite(&(v7_8),&(v7_12));
      join_wrapped_into(&mut v6_3_write,&((v7_13).read_zipper()),&[]);
      }
      v6_3_cursor.ascend(1);
    }
    drop(v6_3_cursor);
    drop(v6_3_write);
    let mut v6_4 = Space::new();
    let mut v6_4_write = v6_4.write_zipper();
    let mut v6_4_cursor = descend_cursor(descend_cursor((v0_37).read_zipper(),&(*CONSTANT_8)),&(*CONSTANT_10));
    let v6_4_origin = v6_4_cursor.path().len();
    for v6_4_byte in v6_4_cursor.child_mask().iter() {
      v6_4_cursor.descend_to_existing_byte(v6_4_byte);
      {
      let v13_2: Space = singleton(&v6_4_cursor.path()[v6_4_origin..(v6_4_origin + 1)]);
      let v13_3: Space = intersect(&(*CONSTANT_15),&(v13_2));
      let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
      drop(v13_3);
      let v13_5: Space = subtract(&(*CONSTANT_0),&(v13_4));
      drop(v13_4);
      let v13_8: Space = if (&(v13_5)).is_empty() { Space::new() } else {
        let mut v14_7 = Space::new();
        let mut v14_7_write = v14_7.write_zipper();
        let v14_7_arg_0: &[u8] = &(*CONSTANT_1);
        let v14_7_arg_1: &[u8] = &v6_4_cursor.path()[v6_4_origin..(v6_4_origin + 1)];
        let v14_7_arg_3: &Space = &(&v6_4_cursor).make_map();
        let v14_7_arg_4: &Space = &(v0_37);
        let mut v14_7_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&v6_4_cursor.path()[v6_4_origin..(v6_4_origin + 1)]);
        let v14_7_origin = v14_7_cursor.path().len();
        let mut v14_7_more = v14_7_cursor.is_val() || next_value_within(&mut v14_7_cursor,v14_7_origin);
        while v14_7_more {
          {
          let v14_7_depth = v14_7_cursor.path().len();
          let mut v15_5_cursor = (*v14_7_arg_3).read_zipper();
          let v15_5_origin = v15_5_cursor.path().len();
          for v15_5_byte in v15_5_cursor.child_mask().iter() {
            v15_5_cursor.descend_to_existing_byte(v15_5_byte);
            {
            let v16_2: Path = concat_path(&(*v14_7_arg_1),&v15_5_cursor.path()[v15_5_origin..(v15_5_origin + 1)]);
            let v16_3: Space = routine_4(c, &(v16_2), &v14_7_cursor.path()[v14_7_origin..v14_7_depth], &v15_5_cursor, &((*v14_7_arg_4).read_zipper()));
            drop(v16_2);
            join_wrapped_into(&mut v14_7_write,&((v16_3).read_zipper()),&[]);
            }
            v15_5_cursor.ascend(1);
          }
          drop(v15_5_cursor);
          }
          v14_7_more = next_value_within(&mut v14_7_cursor,v14_7_origin);
        }
        drop(v14_7_cursor);
        drop(v14_7_write);
        compose(&(v13_5),&(v14_7))
      };
      drop(v13_5);
      let v13_9: Space = intersect(&(*CONSTANT_15),&(v13_2));
      drop(v13_2);
      let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
      drop(v13_9);
      let v13_12: Space = if (&(v13_10)).is_empty() { Space::new() } else {
        let mut v17_11 = Space::new();
        let mut v17_11_write = v17_11.write_zipper();
        for v17_11_byte in v6_4_cursor.child_mask().iter() {
          v6_4_cursor.descend_to_existing_byte(v17_11_byte);
          {
          let v18_2: Space = routine_5(c, &v6_4_cursor.path()[(v6_4_origin + 1)..(v6_4_origin + 2)], &v6_4_cursor.path()[(v6_4_origin + 1)..(v6_4_origin + 2)], &v6_4_cursor.path()[v6_4_origin..(v6_4_origin + 1)], &v6_4_cursor, &((v0_37).read_zipper()));
          join_wrapped_into(&mut v17_11_write,&((v18_2).read_zipper()),&[]);
          }
          v6_4_cursor.ascend(1);
        }
        drop(v17_11_write);
        compose(&(v13_10),&(v17_11))
      };
      drop(v13_10);
      let v13_13: Space = unite(&(v13_8),&(v13_12));
      join_wrapped_into(&mut v6_4_write,&((v13_13).read_zipper()),&[]);
      }
      v6_4_cursor.ascend(1);
    }
    drop(v6_4_cursor);
    drop(v6_4_write);
    let v6_5: Space = unite(&(v6_3),&(v6_4));
    let mut v6_8 = Space::new();
    let mut v6_8_write = v6_8.write_zipper();
    let mut v6_8_cursor = descend_cursor(descend_cursor((v0_37).read_zipper(),&(*CONSTANT_11)),&(*CONSTANT_12));
    let v6_8_origin = v6_8_cursor.path().len();
    for v6_8_byte in v6_8_cursor.child_mask().iter() {
      v6_8_cursor.descend_to_existing_byte(v6_8_byte);
      {
      let v19_2: Space = singleton(&v6_8_cursor.path()[v6_8_origin..(v6_8_origin + 1)]);
      let v19_3: Space = intersect(&(*CONSTANT_15),&(v19_2));
      let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
      drop(v19_3);
      let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
      drop(v19_4);
      let v19_8: Space = if (&(v19_5)).is_empty() { Space::new() } else {
        let mut v20_7 = Space::new();
        let mut v20_7_write = v20_7.write_zipper();
        let v20_7_arg_0: &[u8] = &(*CONSTANT_1);
        let v20_7_arg_1: &[u8] = &v6_8_cursor.path()[v6_8_origin..(v6_8_origin + 1)];
        let v20_7_arg_3: &Space = &(&v6_8_cursor).make_map();
        let mut v20_7_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&v6_8_cursor.path()[v6_8_origin..(v6_8_origin + 1)]);
        let v20_7_origin = v20_7_cursor.path().len();
        let mut v20_7_more = v20_7_cursor.is_val() || next_value_within(&mut v20_7_cursor,v20_7_origin);
        while v20_7_more {
          {
          let v20_7_depth = v20_7_cursor.path().len();
          let mut v21_4_cursor = (*v20_7_arg_3).read_zipper();
          let v21_4_origin = v21_4_cursor.path().len();
          for v21_4_byte in v21_4_cursor.child_mask().iter() {
            v21_4_cursor.descend_to_existing_byte(v21_4_byte);
            {
            let v22_2: Path = concat_path(&(*v20_7_arg_1),&v21_4_cursor.path()[v21_4_origin..(v21_4_origin + 1)]);
            let v22_3: Space = routine_6(c, &(v22_2), &v20_7_cursor.path()[v20_7_origin..v20_7_depth], &v21_4_cursor);
            drop(v22_2);
            join_wrapped_into(&mut v20_7_write,&((v22_3).read_zipper()),&[]);
            }
            v21_4_cursor.ascend(1);
          }
          drop(v21_4_cursor);
          }
          v20_7_more = next_value_within(&mut v20_7_cursor,v20_7_origin);
        }
        drop(v20_7_cursor);
        drop(v20_7_write);
        compose(&(v19_5),&(v20_7))
      };
      drop(v19_5);
      let v19_9: Space = intersect(&(*CONSTANT_15),&(v19_2));
      drop(v19_2);
      let v19_10: Space = if has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
      drop(v19_9);
      let v19_12: Space = if (&(v19_10)).is_empty() { Space::new() } else {
        let mut v23_11 = Space::new();
        let mut v23_11_write = v23_11.write_zipper();
        for v23_11_byte in v6_8_cursor.child_mask().iter() {
          v6_8_cursor.descend_to_existing_byte(v23_11_byte);
          {
          let v24_2: Space = routine_7(c, &v6_8_cursor.path()[(v6_8_origin + 1)..(v6_8_origin + 2)], &v6_8_cursor.path()[(v6_8_origin + 1)..(v6_8_origin + 2)], &v6_8_cursor.path()[v6_8_origin..(v6_8_origin + 1)], &v6_8_cursor);
          join_wrapped_into(&mut v23_11_write,&((v24_2).read_zipper()),&[]);
          }
          v6_8_cursor.ascend(1);
        }
        drop(v23_11_write);
        compose(&(v19_10),&(v23_11))
      };
      drop(v19_10);
      let v19_13: Space = unite(&(v19_8),&(v19_12));
      join_wrapped_into(&mut v6_8_write,&((v19_13).read_zipper()),&[]);
      }
      v6_8_cursor.ascend(1);
    }
    drop(v6_8_cursor);
    drop(v6_8_write);
    let v6_9: Space = unite(&(v6_5),&(v6_8));
    let mut v6_11 = Space::new();
    let mut v6_11_write = v6_11.write_zipper();
    let mut v6_11_cursor = descend_cursor(descend_cursor((v0_37).read_zipper(),&(*CONSTANT_11)),&(*CONSTANT_10));
    let v6_11_origin = v6_11_cursor.path().len();
    for v6_11_byte in v6_11_cursor.child_mask().iter() {
      v6_11_cursor.descend_to_existing_byte(v6_11_byte);
      {
      let v25_2: Space = singleton(&v6_11_cursor.path()[v6_11_origin..(v6_11_origin + 1)]);
      let v25_3: Space = intersect(&(*CONSTANT_15),&(v25_2));
      let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
      drop(v25_3);
      let v25_5: Space = subtract(&(*CONSTANT_0),&(v25_4));
      drop(v25_4);
      let v25_8: Space = if (&(v25_5)).is_empty() { Space::new() } else {
        let mut v26_7 = Space::new();
        let mut v26_7_write = v26_7.write_zipper();
        let v26_7_arg_0: &[u8] = &(*CONSTANT_1);
        let v26_7_arg_1: &[u8] = &v6_11_cursor.path()[v6_11_origin..(v6_11_origin + 1)];
        let v26_7_arg_3: &Space = &(&v6_11_cursor).make_map();
        let v26_7_arg_4: &Space = &(v0_37);
        let mut v26_7_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&v6_11_cursor.path()[v6_11_origin..(v6_11_origin + 1)]);
        let v26_7_origin = v26_7_cursor.path().len();
        let mut v26_7_more = v26_7_cursor.is_val() || next_value_within(&mut v26_7_cursor,v26_7_origin);
        while v26_7_more {
          {
          let v26_7_depth = v26_7_cursor.path().len();
          let mut v27_5_cursor = (*v26_7_arg_3).read_zipper();
          let v27_5_origin = v27_5_cursor.path().len();
          for v27_5_byte in v27_5_cursor.child_mask().iter() {
            v27_5_cursor.descend_to_existing_byte(v27_5_byte);
            {
            let v28_2: Path = concat_path(&(*v26_7_arg_1),&v27_5_cursor.path()[v27_5_origin..(v27_5_origin + 1)]);
            let v28_3: Space = routine_8(c, &(v28_2), &v26_7_cursor.path()[v26_7_origin..v26_7_depth], &v27_5_cursor, &((*v26_7_arg_4).read_zipper()));
            drop(v28_2);
            join_wrapped_into(&mut v26_7_write,&((v28_3).read_zipper()),&[]);
            }
            v27_5_cursor.ascend(1);
          }
          drop(v27_5_cursor);
          }
          v26_7_more = next_value_within(&mut v26_7_cursor,v26_7_origin);
        }
        drop(v26_7_cursor);
        drop(v26_7_write);
        compose(&(v25_5),&(v26_7))
      };
      drop(v25_5);
      let v25_9: Space = intersect(&(*CONSTANT_15),&(v25_2));
      drop(v25_2);
      let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
      drop(v25_9);
      let v25_12: Space = if (&(v25_10)).is_empty() { Space::new() } else {
        let mut v29_11 = Space::new();
        let mut v29_11_write = v29_11.write_zipper();
        for v29_11_byte in v6_11_cursor.child_mask().iter() {
          v6_11_cursor.descend_to_existing_byte(v29_11_byte);
          {
          let v30_2: Space = routine_9(c, &v6_11_cursor.path()[(v6_11_origin + 1)..(v6_11_origin + 2)], &v6_11_cursor.path()[(v6_11_origin + 1)..(v6_11_origin + 2)], &v6_11_cursor.path()[v6_11_origin..(v6_11_origin + 1)], &v6_11_cursor, &((v0_37).read_zipper()));
          join_wrapped_into(&mut v29_11_write,&((v30_2).read_zipper()),&[]);
          }
          v6_11_cursor.ascend(1);
        }
        drop(v29_11_write);
        compose(&(v25_10),&(v29_11))
      };
      drop(v25_10);
      let v25_13: Space = unite(&(v25_8),&(v25_12));
      join_wrapped_into(&mut v6_11_write,&((v25_13).read_zipper()),&[]);
      }
      v6_11_cursor.ascend(1);
    }
    drop(v6_11_cursor);
    drop(v6_11_write);
    let v6_12: Space = unite(&(v6_9),&(v6_11));
    let v6_14: Space = subtract(&(v6_12),&(descend_cursor((v0_37).read_zipper(),&(*CONSTANT_13))));
    let v6_16: Space = subtract(&(v6_14),&(descend_cursor((v0_37).read_zipper(),&(*CONSTANT_14))));
    let v6_17: Space = wrap(&(v6_16),&(*CONSTANT_13));
    let v6_18: Space = unite(&(descend_cursor((v0_37).read_zipper(),&(*CONSTANT_8))),&(descend_cursor((v0_37).read_zipper(),&(*CONSTANT_11))));
    let v6_19: Space = wrap(&(v6_18),&(*CONSTANT_11));
    drop(v6_18);
    let v6_20: Space = unite(&(v6_17),&(v6_19));
    drop(v6_19);
    let v6_21: Space = unite(&(v6_20),&(v0_37));
    if !v0_37.join_into((v6_21).clone()).is_element() { break; }
  }
  (&(descend_cursor((v0_37).read_zipper(),&(*CONSTANT_14)))).make_map()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v31_5: Space = singleton(&(*p1));
  let v31_6: Space = intersect(&(*CONSTANT_15),&(v31_5));
  let v31_7: Space = if has_head(&(v31_6)) { singleton(&[]) } else { Space::new() };
  drop(v31_6);
  let v31_8: Space = subtract(&(*CONSTANT_0),&(v31_7));
  drop(v31_7);
  let v31_19: Space = if (&(v31_8)).is_empty() { Space::new() } else {
    let v32_11: Space = first_matching(&(descend_cursor((*CONSTANT_16).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v32_14: Space = if (&(v32_11)).is_empty() { Space::new() } else {
      let v33_13: Space = routine_10(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v32_11),&(v33_13))
    };
    drop(v32_11);
    let mut v32_17 = Space::new();
    let mut v32_17_write = v32_17.write_zipper();
    let mut v32_17_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p1));
    let v32_17_origin = v32_17_cursor.path().len();
    for v32_17_byte in v32_17_cursor.child_mask().iter() {
      v32_17_cursor.descend_to_existing_byte(v32_17_byte);
      {
      let v34_2_arg_0: &[u8] = &v32_17_cursor.path()[v32_17_origin..(v32_17_origin + 1)];
      let v34_2_arg_1: &[u8] = &(*p0);
      let v34_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v34_2_more = v32_17_cursor.is_val() || next_value_within(&mut v32_17_cursor,(v32_17_origin + 1));
      while v34_2_more {
        {
        let v34_2_depth = v32_17_cursor.path().len();
        let mut v35_4_cursor = (*v34_2_arg_3).read_zipper();
        let v35_4_origin = v35_4_cursor.path().len();
        for v35_4_byte in v35_4_cursor.child_mask().iter() {
          v35_4_cursor.descend_to_existing_byte(v35_4_byte);
          {
          let v36_2: Path = concat_path(&(*v34_2_arg_1),&v35_4_cursor.path()[v35_4_origin..(v35_4_origin + 1)]);
          let v36_3: Space = routine_1(c, &(v36_2), &v32_17_cursor.path()[v32_17_origin..v34_2_depth], &v35_4_cursor);
          drop(v36_2);
          join_wrapped_into(&mut v32_17_write,&((v36_3).read_zipper()),&[]);
          }
          v35_4_cursor.ascend(1);
        }
        drop(v35_4_cursor);
        }
        v34_2_more = next_value_within(&mut v32_17_cursor,(v32_17_origin + 1));
      }
      }
      v32_17_cursor.ascend(1);
    }
    drop(v32_17_cursor);
    drop(v32_17_write);
    let v32_18: Space = unite(&(v32_14),&(v32_17));
    compose(&(v31_8),&(v32_18))
  };
  drop(v31_8);
  let v31_21: Space = intersect(&(*CONSTANT_15),&(v31_5));
  drop(v31_5);
  let v31_22: Space = if has_head(&(v31_21)) { singleton(&[]) } else { Space::new() };
  drop(v31_21);
  let v31_24: Space = if (&(v31_22)).is_empty() { Space::new() } else {
    let mut v37_23 = Space::new();
    let mut v37_23_write = v37_23.write_zipper();
    let mut v37_23_cursor = (*s0).read_zipper();
    let v37_23_origin = v37_23_cursor.path().len();
    for v37_23_byte in v37_23_cursor.child_mask().iter() {
      v37_23_cursor.descend_to_existing_byte(v37_23_byte);
      {
      let v38_2: Space = routine_11(c, &v37_23_cursor.path()[v37_23_origin..(v37_23_origin + 1)], &v37_23_cursor.path()[v37_23_origin..(v37_23_origin + 1)], &(*p0), &v37_23_cursor);
      join_wrapped_into(&mut v37_23_write,&((v38_2).read_zipper()),&[]);
      }
      v37_23_cursor.ascend(1);
    }
    drop(v37_23_cursor);
    drop(v37_23_write);
    compose(&(v31_22),&(v37_23))
  };
  drop(v31_22);
  let v31_25: Space = unite(&(v31_19),&(v31_24));
  (v31_25).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v39_6: Space = singleton(&(*p1));
  let v39_7: Space = intersect(&(*CONSTANT_15),&(v39_6));
  let v39_8: Space = if has_head(&(v39_7)) { singleton(&[]) } else { Space::new() };
  drop(v39_7);
  let v39_9: Space = subtract(&(*CONSTANT_0),&(v39_8));
  drop(v39_8);
  let v39_20: Space = if (&(v39_9)).is_empty() { Space::new() } else {
    let v40_12: Space = first_matching(&(descend_cursor((*CONSTANT_16).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v40_15: Space = if (&(v40_12)).is_empty() { Space::new() } else {
      let v41_14: Space = routine_12(c, &(*CONSTANT_1), &(*p0), &(*s0), &(*s1));
      compose(&(v40_12),&(v41_14))
    };
    drop(v40_12);
    let mut v40_18 = Space::new();
    let mut v40_18_write = v40_18.write_zipper();
    let mut v40_18_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p1));
    let v40_18_origin = v40_18_cursor.path().len();
    for v40_18_byte in v40_18_cursor.child_mask().iter() {
      v40_18_cursor.descend_to_existing_byte(v40_18_byte);
      {
      let v42_2_arg_0: &[u8] = &v40_18_cursor.path()[v40_18_origin..(v40_18_origin + 1)];
      let v42_2_arg_1: &[u8] = &(*p0);
      let v42_2_arg_3: &Space = &(&(*s0)).make_map();
      let v42_2_arg_4: &Space = &(&(*s1)).make_map();
      let mut v42_2_more = v40_18_cursor.is_val() || next_value_within(&mut v40_18_cursor,(v40_18_origin + 1));
      while v42_2_more {
        {
        let v42_2_depth = v40_18_cursor.path().len();
        let mut v43_5_cursor = (*v42_2_arg_3).read_zipper();
        let v43_5_origin = v43_5_cursor.path().len();
        for v43_5_byte in v43_5_cursor.child_mask().iter() {
          v43_5_cursor.descend_to_existing_byte(v43_5_byte);
          {
          let v44_2: Path = concat_path(&(*v42_2_arg_1),&v43_5_cursor.path()[v43_5_origin..(v43_5_origin + 1)]);
          let v44_3: Space = routine_2(c, &(v44_2), &v40_18_cursor.path()[v40_18_origin..v42_2_depth], &v43_5_cursor, &((*v42_2_arg_4).read_zipper()));
          drop(v44_2);
          join_wrapped_into(&mut v40_18_write,&((v44_3).read_zipper()),&[]);
          }
          v43_5_cursor.ascend(1);
        }
        drop(v43_5_cursor);
        }
        v42_2_more = next_value_within(&mut v40_18_cursor,(v40_18_origin + 1));
      }
      }
      v40_18_cursor.ascend(1);
    }
    drop(v40_18_cursor);
    drop(v40_18_write);
    let v40_19: Space = unite(&(v40_15),&(v40_18));
    compose(&(v39_9),&(v40_19))
  };
  drop(v39_9);
  let v39_22: Space = intersect(&(*CONSTANT_15),&(v39_6));
  drop(v39_6);
  let v39_23: Space = if has_head(&(v39_22)) { singleton(&[]) } else { Space::new() };
  drop(v39_22);
  let v39_25: Space = if (&(v39_23)).is_empty() { Space::new() } else {
    let mut v45_24 = Space::new();
    let mut v45_24_write = v45_24.write_zipper();
    let mut v45_24_cursor = (*s0).read_zipper();
    let v45_24_origin = v45_24_cursor.path().len();
    for v45_24_byte in v45_24_cursor.child_mask().iter() {
      v45_24_cursor.descend_to_existing_byte(v45_24_byte);
      {
      let v46_2: Space = routine_3(c, &v45_24_cursor.path()[v45_24_origin..(v45_24_origin + 1)], &v45_24_cursor.path()[v45_24_origin..(v45_24_origin + 1)], &(*p0), &v45_24_cursor, &(*s1));
      join_wrapped_into(&mut v45_24_write,&((v46_2).read_zipper()),&[]);
      }
      v45_24_cursor.ascend(1);
    }
    drop(v45_24_cursor);
    drop(v45_24_write);
    compose(&(v39_23),&(v45_24))
  };
  drop(v39_23);
  let v39_26: Space = unite(&(v39_20),&(v39_25));
  (v39_26).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v47_7: Space = singleton(&(*p1));
  let v47_8: Space = intersect(&(*CONSTANT_15),&(v47_7));
  let v47_9: Space = if has_head(&(v47_8)) { singleton(&[]) } else { Space::new() };
  drop(v47_8);
  let v47_10: Space = subtract(&(*CONSTANT_0),&(v47_9));
  drop(v47_9);
  let v47_21: Space = if (&(v47_10)).is_empty() { Space::new() } else {
    let v48_13: Space = first_matching(&(descend_cursor((*CONSTANT_16).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v48_16: Space = if (&(v48_13)).is_empty() { Space::new() } else {
      let v49_15: Space = routine_13(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0), &(*s1));
      compose(&(v48_13),&(v49_15))
    };
    drop(v48_13);
    let mut v48_19 = Space::new();
    let mut v48_19_write = v48_19.write_zipper();
    let mut v48_19_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p1));
    let v48_19_origin = v48_19_cursor.path().len();
    for v48_19_byte in v48_19_cursor.child_mask().iter() {
      v48_19_cursor.descend_to_existing_byte(v48_19_byte);
      {
      let v50_2_arg_0: &[u8] = &v48_19_cursor.path()[v48_19_origin..(v48_19_origin + 1)];
      let v50_2_arg_1: &[u8] = &(*p0);
      let v50_2_arg_2: &[u8] = &(*p2);
      let v50_2_arg_4: &Space = &(&(*s0)).make_map();
      let v50_2_arg_5: &Space = &(&(*s1)).make_map();
      let mut v50_2_more = v48_19_cursor.is_val() || next_value_within(&mut v48_19_cursor,(v48_19_origin + 1));
      while v50_2_more {
        {
        let v50_2_depth = v48_19_cursor.path().len();
        let mut v51_6_cursor = (*v50_2_arg_4).read_zipper();
        let v51_6_origin = v51_6_cursor.path().len();
        for v51_6_byte in v51_6_cursor.child_mask().iter() {
          v51_6_cursor.descend_to_existing_byte(v51_6_byte);
          {
          let v52_2: Path = concat_path(&(*v50_2_arg_1),&v51_6_cursor.path()[v51_6_origin..(v51_6_origin + 1)]);
          let v52_3: Space = routine_3(c, &(v52_2), &v48_19_cursor.path()[v48_19_origin..v50_2_depth], &(*v50_2_arg_2), &v51_6_cursor, &((*v50_2_arg_5).read_zipper()));
          drop(v52_2);
          join_wrapped_into(&mut v48_19_write,&((v52_3).read_zipper()),&[]);
          }
          v51_6_cursor.ascend(1);
        }
        drop(v51_6_cursor);
        }
        v50_2_more = next_value_within(&mut v48_19_cursor,(v48_19_origin + 1));
      }
      }
      v48_19_cursor.ascend(1);
    }
    drop(v48_19_cursor);
    drop(v48_19_write);
    let v48_20: Space = unite(&(v48_16),&(v48_19));
    compose(&(v47_10),&(v48_20))
  };
  drop(v47_10);
  let v47_23: Space = intersect(&(*CONSTANT_15),&(v47_7));
  drop(v47_7);
  let v47_24: Space = if has_head(&(v47_23)) { singleton(&[]) } else { Space::new() };
  drop(v47_23);
  let v47_31: Space = if (&(v47_24)).is_empty() { Space::new() } else {
    let mut v53_30 = Space::new();
    let mut v53_30_write = v53_30.write_zipper();
    let mut v53_30_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_11)),&(*CONSTANT_10)),&(*p0));
    let v53_30_origin = v53_30_cursor.path().len();
    for v53_30_byte in v53_30_cursor.child_mask().iter() {
      v53_30_cursor.descend_to_existing_byte(v53_30_byte);
      {
      let v54_2: Space = routine_14(c, &v53_30_cursor.path()[v53_30_origin..(v53_30_origin + 1)], &v53_30_cursor.path()[v53_30_origin..(v53_30_origin + 1)], &(*p2), &v53_30_cursor);
      join_wrapped_into(&mut v53_30_write,&((v54_2).read_zipper()),&[]);
      }
      v53_30_cursor.ascend(1);
    }
    drop(v53_30_cursor);
    drop(v53_30_write);
    compose(&(v47_24),&(v53_30))
  };
  drop(v47_24);
  let v47_32: Space = unite(&(v47_21),&(v47_31));
  (v47_32).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v55_6: Space = singleton(&(*p1));
  let v55_7: Space = intersect(&(*CONSTANT_15),&(v55_6));
  let v55_8: Space = if has_head(&(v55_7)) { singleton(&[]) } else { Space::new() };
  drop(v55_7);
  let v55_9: Space = subtract(&(*CONSTANT_0),&(v55_8));
  drop(v55_8);
  let v55_20: Space = if (&(v55_9)).is_empty() { Space::new() } else {
    let v56_12: Space = first_matching(&(descend_cursor((*CONSTANT_16).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v56_15: Space = if (&(v56_12)).is_empty() { Space::new() } else {
      let v57_14: Space = routine_15(c, &(*CONSTANT_1), &(*p0), &(*s0), &(*s1));
      compose(&(v56_12),&(v57_14))
    };
    drop(v56_12);
    let mut v56_18 = Space::new();
    let mut v56_18_write = v56_18.write_zipper();
    let mut v56_18_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p1));
    let v56_18_origin = v56_18_cursor.path().len();
    for v56_18_byte in v56_18_cursor.child_mask().iter() {
      v56_18_cursor.descend_to_existing_byte(v56_18_byte);
      {
      let v58_2_arg_0: &[u8] = &v56_18_cursor.path()[v56_18_origin..(v56_18_origin + 1)];
      let v58_2_arg_1: &[u8] = &(*p0);
      let v58_2_arg_3: &Space = &(&(*s0)).make_map();
      let v58_2_arg_4: &Space = &(&(*s1)).make_map();
      let mut v58_2_more = v56_18_cursor.is_val() || next_value_within(&mut v56_18_cursor,(v56_18_origin + 1));
      while v58_2_more {
        {
        let v58_2_depth = v56_18_cursor.path().len();
        let mut v59_5_cursor = (*v58_2_arg_3).read_zipper();
        let v59_5_origin = v59_5_cursor.path().len();
        for v59_5_byte in v59_5_cursor.child_mask().iter() {
          v59_5_cursor.descend_to_existing_byte(v59_5_byte);
          {
          let v60_2: Path = concat_path(&(*v58_2_arg_1),&v59_5_cursor.path()[v59_5_origin..(v59_5_origin + 1)]);
          let v60_3: Space = routine_4(c, &(v60_2), &v56_18_cursor.path()[v56_18_origin..v58_2_depth], &v59_5_cursor, &((*v58_2_arg_4).read_zipper()));
          drop(v60_2);
          join_wrapped_into(&mut v56_18_write,&((v60_3).read_zipper()),&[]);
          }
          v59_5_cursor.ascend(1);
        }
        drop(v59_5_cursor);
        }
        v58_2_more = next_value_within(&mut v56_18_cursor,(v56_18_origin + 1));
      }
      }
      v56_18_cursor.ascend(1);
    }
    drop(v56_18_cursor);
    drop(v56_18_write);
    let v56_19: Space = unite(&(v56_15),&(v56_18));
    compose(&(v55_9),&(v56_19))
  };
  drop(v55_9);
  let v55_22: Space = intersect(&(*CONSTANT_15),&(v55_6));
  drop(v55_6);
  let v55_23: Space = if has_head(&(v55_22)) { singleton(&[]) } else { Space::new() };
  drop(v55_22);
  let v55_25: Space = if (&(v55_23)).is_empty() { Space::new() } else {
    let mut v61_24 = Space::new();
    let mut v61_24_write = v61_24.write_zipper();
    let mut v61_24_cursor = (*s0).read_zipper();
    let v61_24_origin = v61_24_cursor.path().len();
    for v61_24_byte in v61_24_cursor.child_mask().iter() {
      v61_24_cursor.descend_to_existing_byte(v61_24_byte);
      {
      let v62_2: Space = routine_5(c, &v61_24_cursor.path()[v61_24_origin..(v61_24_origin + 1)], &v61_24_cursor.path()[v61_24_origin..(v61_24_origin + 1)], &(*p0), &v61_24_cursor, &(*s1));
      join_wrapped_into(&mut v61_24_write,&((v62_2).read_zipper()),&[]);
      }
      v61_24_cursor.ascend(1);
    }
    drop(v61_24_cursor);
    drop(v61_24_write);
    compose(&(v55_23),&(v61_24))
  };
  drop(v55_23);
  let v55_26: Space = unite(&(v55_20),&(v55_25));
  (v55_26).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v63_7: Space = singleton(&(*p1));
  let v63_8: Space = intersect(&(*CONSTANT_15),&(v63_7));
  let v63_9: Space = if has_head(&(v63_8)) { singleton(&[]) } else { Space::new() };
  drop(v63_8);
  let v63_10: Space = subtract(&(*CONSTANT_0),&(v63_9));
  drop(v63_9);
  let v63_21: Space = if (&(v63_10)).is_empty() { Space::new() } else {
    let v64_13: Space = first_matching(&(descend_cursor((*CONSTANT_16).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v64_16: Space = if (&(v64_13)).is_empty() { Space::new() } else {
      let v65_15: Space = routine_16(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0), &(*s1));
      compose(&(v64_13),&(v65_15))
    };
    drop(v64_13);
    let mut v64_19 = Space::new();
    let mut v64_19_write = v64_19.write_zipper();
    let mut v64_19_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p1));
    let v64_19_origin = v64_19_cursor.path().len();
    for v64_19_byte in v64_19_cursor.child_mask().iter() {
      v64_19_cursor.descend_to_existing_byte(v64_19_byte);
      {
      let v66_2_arg_0: &[u8] = &v64_19_cursor.path()[v64_19_origin..(v64_19_origin + 1)];
      let v66_2_arg_1: &[u8] = &(*p0);
      let v66_2_arg_2: &[u8] = &(*p2);
      let v66_2_arg_4: &Space = &(&(*s0)).make_map();
      let v66_2_arg_5: &Space = &(&(*s1)).make_map();
      let mut v66_2_more = v64_19_cursor.is_val() || next_value_within(&mut v64_19_cursor,(v64_19_origin + 1));
      while v66_2_more {
        {
        let v66_2_depth = v64_19_cursor.path().len();
        let mut v67_6_cursor = (*v66_2_arg_4).read_zipper();
        let v67_6_origin = v67_6_cursor.path().len();
        for v67_6_byte in v67_6_cursor.child_mask().iter() {
          v67_6_cursor.descend_to_existing_byte(v67_6_byte);
          {
          let v68_2: Path = concat_path(&(*v66_2_arg_1),&v67_6_cursor.path()[v67_6_origin..(v67_6_origin + 1)]);
          let v68_3: Space = routine_5(c, &(v68_2), &v64_19_cursor.path()[v64_19_origin..v66_2_depth], &(*v66_2_arg_2), &v67_6_cursor, &((*v66_2_arg_5).read_zipper()));
          drop(v68_2);
          join_wrapped_into(&mut v64_19_write,&((v68_3).read_zipper()),&[]);
          }
          v67_6_cursor.ascend(1);
        }
        drop(v67_6_cursor);
        }
        v66_2_more = next_value_within(&mut v64_19_cursor,(v64_19_origin + 1));
      }
      }
      v64_19_cursor.ascend(1);
    }
    drop(v64_19_cursor);
    drop(v64_19_write);
    let v64_20: Space = unite(&(v64_16),&(v64_19));
    compose(&(v63_10),&(v64_20))
  };
  drop(v63_10);
  let v63_23: Space = intersect(&(*CONSTANT_15),&(v63_7));
  drop(v63_7);
  let v63_24: Space = if has_head(&(v63_23)) { singleton(&[]) } else { Space::new() };
  drop(v63_23);
  let v63_31: Space = if (&(v63_24)).is_empty() { Space::new() } else {
    let mut v69_30 = Space::new();
    let mut v69_30_write = v69_30.write_zipper();
    let mut v69_30_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_8)),&(*CONSTANT_10)),&(*p0));
    let v69_30_origin = v69_30_cursor.path().len();
    for v69_30_byte in v69_30_cursor.child_mask().iter() {
      v69_30_cursor.descend_to_existing_byte(v69_30_byte);
      {
      let v70_2: Space = routine_17(c, &v69_30_cursor.path()[v69_30_origin..(v69_30_origin + 1)], &v69_30_cursor.path()[v69_30_origin..(v69_30_origin + 1)], &(*p2), &v69_30_cursor);
      join_wrapped_into(&mut v69_30_write,&((v70_2).read_zipper()),&[]);
      }
      v69_30_cursor.ascend(1);
    }
    drop(v69_30_cursor);
    drop(v69_30_write);
    compose(&(v63_24),&(v69_30))
  };
  drop(v63_24);
  let v63_32: Space = unite(&(v63_21),&(v63_31));
  (v63_32).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v71_5: Space = singleton(&(*p1));
  let v71_6: Space = intersect(&(*CONSTANT_15),&(v71_5));
  let v71_7: Space = if has_head(&(v71_6)) { singleton(&[]) } else { Space::new() };
  drop(v71_6);
  let v71_8: Space = subtract(&(*CONSTANT_0),&(v71_7));
  drop(v71_7);
  let v71_19: Space = if (&(v71_8)).is_empty() { Space::new() } else {
    let v72_11: Space = first_matching(&(descend_cursor((*CONSTANT_16).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v72_14: Space = if (&(v72_11)).is_empty() { Space::new() } else {
      let v73_13: Space = routine_18(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v72_11),&(v73_13))
    };
    drop(v72_11);
    let mut v72_17 = Space::new();
    let mut v72_17_write = v72_17.write_zipper();
    let mut v72_17_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p1));
    let v72_17_origin = v72_17_cursor.path().len();
    for v72_17_byte in v72_17_cursor.child_mask().iter() {
      v72_17_cursor.descend_to_existing_byte(v72_17_byte);
      {
      let v74_2_arg_0: &[u8] = &v72_17_cursor.path()[v72_17_origin..(v72_17_origin + 1)];
      let v74_2_arg_1: &[u8] = &(*p0);
      let v74_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v74_2_more = v72_17_cursor.is_val() || next_value_within(&mut v72_17_cursor,(v72_17_origin + 1));
      while v74_2_more {
        {
        let v74_2_depth = v72_17_cursor.path().len();
        let mut v75_4_cursor = (*v74_2_arg_3).read_zipper();
        let v75_4_origin = v75_4_cursor.path().len();
        for v75_4_byte in v75_4_cursor.child_mask().iter() {
          v75_4_cursor.descend_to_existing_byte(v75_4_byte);
          {
          let v76_2: Path = concat_path(&(*v74_2_arg_1),&v75_4_cursor.path()[v75_4_origin..(v75_4_origin + 1)]);
          let v76_3: Space = routine_6(c, &(v76_2), &v72_17_cursor.path()[v72_17_origin..v74_2_depth], &v75_4_cursor);
          drop(v76_2);
          join_wrapped_into(&mut v72_17_write,&((v76_3).read_zipper()),&[]);
          }
          v75_4_cursor.ascend(1);
        }
        drop(v75_4_cursor);
        }
        v74_2_more = next_value_within(&mut v72_17_cursor,(v72_17_origin + 1));
      }
      }
      v72_17_cursor.ascend(1);
    }
    drop(v72_17_cursor);
    drop(v72_17_write);
    let v72_18: Space = unite(&(v72_14),&(v72_17));
    compose(&(v71_8),&(v72_18))
  };
  drop(v71_8);
  let v71_21: Space = intersect(&(*CONSTANT_15),&(v71_5));
  drop(v71_5);
  let v71_22: Space = if has_head(&(v71_21)) { singleton(&[]) } else { Space::new() };
  drop(v71_21);
  let v71_24: Space = if (&(v71_22)).is_empty() { Space::new() } else {
    let mut v77_23 = Space::new();
    let mut v77_23_write = v77_23.write_zipper();
    let mut v77_23_cursor = (*s0).read_zipper();
    let v77_23_origin = v77_23_cursor.path().len();
    for v77_23_byte in v77_23_cursor.child_mask().iter() {
      v77_23_cursor.descend_to_existing_byte(v77_23_byte);
      {
      let v78_2: Space = routine_7(c, &v77_23_cursor.path()[v77_23_origin..(v77_23_origin + 1)], &v77_23_cursor.path()[v77_23_origin..(v77_23_origin + 1)], &(*p0), &v77_23_cursor);
      join_wrapped_into(&mut v77_23_write,&((v78_2).read_zipper()),&[]);
      }
      v77_23_cursor.ascend(1);
    }
    drop(v77_23_cursor);
    drop(v77_23_write);
    compose(&(v71_22),&(v77_23))
  };
  drop(v71_22);
  let v71_25: Space = unite(&(v71_19),&(v71_24));
  (v71_25).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v79_6: Space = singleton(&(*p1));
  let v79_7: Space = intersect(&(*CONSTANT_15),&(v79_6));
  let v79_8: Space = if has_head(&(v79_7)) { singleton(&[]) } else { Space::new() };
  drop(v79_7);
  let v79_9: Space = subtract(&(*CONSTANT_0),&(v79_8));
  drop(v79_8);
  let v79_20: Space = if (&(v79_9)).is_empty() { Space::new() } else {
    let v80_12: Space = first_matching(&(descend_cursor((*CONSTANT_16).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v80_15: Space = if (&(v80_12)).is_empty() { Space::new() } else {
      let v81_14: Space = routine_19(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v80_12),&(v81_14))
    };
    drop(v80_12);
    let mut v80_18 = Space::new();
    let mut v80_18_write = v80_18.write_zipper();
    let mut v80_18_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p1));
    let v80_18_origin = v80_18_cursor.path().len();
    for v80_18_byte in v80_18_cursor.child_mask().iter() {
      v80_18_cursor.descend_to_existing_byte(v80_18_byte);
      {
      let v82_2_arg_0: &[u8] = &v80_18_cursor.path()[v80_18_origin..(v80_18_origin + 1)];
      let v82_2_arg_1: &[u8] = &(*p0);
      let v82_2_arg_2: &[u8] = &(*p2);
      let v82_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v82_2_more = v80_18_cursor.is_val() || next_value_within(&mut v80_18_cursor,(v80_18_origin + 1));
      while v82_2_more {
        {
        let v82_2_depth = v80_18_cursor.path().len();
        let mut v83_5_cursor = (*v82_2_arg_4).read_zipper();
        let v83_5_origin = v83_5_cursor.path().len();
        for v83_5_byte in v83_5_cursor.child_mask().iter() {
          v83_5_cursor.descend_to_existing_byte(v83_5_byte);
          {
          let v84_2: Path = concat_path(&(*v82_2_arg_1),&v83_5_cursor.path()[v83_5_origin..(v83_5_origin + 1)]);
          let v84_3: Space = routine_7(c, &(v84_2), &v80_18_cursor.path()[v80_18_origin..v82_2_depth], &(*v82_2_arg_2), &v83_5_cursor);
          drop(v84_2);
          join_wrapped_into(&mut v80_18_write,&((v84_3).read_zipper()),&[]);
          }
          v83_5_cursor.ascend(1);
        }
        drop(v83_5_cursor);
        }
        v82_2_more = next_value_within(&mut v80_18_cursor,(v80_18_origin + 1));
      }
      }
      v80_18_cursor.ascend(1);
    }
    drop(v80_18_cursor);
    drop(v80_18_write);
    let v80_19: Space = unite(&(v80_15),&(v80_18));
    compose(&(v79_9),&(v80_19))
  };
  drop(v79_9);
  let v79_22: Space = intersect(&(*CONSTANT_15),&(v79_6));
  drop(v79_6);
  let v79_23: Space = if has_head(&(v79_22)) { singleton(&[]) } else { Space::new() };
  drop(v79_22);
  let v79_24: Space = if (&(v79_23)).is_empty() { Space::new() } else {
    compose(&(v79_23),&(*s0))
  };
  drop(v79_23);
  let v79_25: Space = wrap(&(v79_24),&(*p0));
  drop(v79_24);
  let v79_26: Space = wrap(&(v79_25),&(*p2));
  drop(v79_25);
  let v79_27: Space = unite(&(v79_20),&(v79_26));
  drop(v79_26);
  (v79_27).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v86_6: Space = singleton(&(*p1));
  let v86_7: Space = intersect(&(*CONSTANT_15),&(v86_6));
  let v86_8: Space = if has_head(&(v86_7)) { singleton(&[]) } else { Space::new() };
  drop(v86_7);
  let v86_9: Space = subtract(&(*CONSTANT_0),&(v86_8));
  drop(v86_8);
  let v86_20: Space = if (&(v86_9)).is_empty() { Space::new() } else {
    let v87_12: Space = first_matching(&(descend_cursor((*CONSTANT_16).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v87_15: Space = if (&(v87_12)).is_empty() { Space::new() } else {
      let v88_14: Space = routine_20(c, &(*CONSTANT_1), &(*p0), &(*s0), &(*s1));
      compose(&(v87_12),&(v88_14))
    };
    drop(v87_12);
    let mut v87_18 = Space::new();
    let mut v87_18_write = v87_18.write_zipper();
    let mut v87_18_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p1));
    let v87_18_origin = v87_18_cursor.path().len();
    for v87_18_byte in v87_18_cursor.child_mask().iter() {
      v87_18_cursor.descend_to_existing_byte(v87_18_byte);
      {
      let v89_2_arg_0: &[u8] = &v87_18_cursor.path()[v87_18_origin..(v87_18_origin + 1)];
      let v89_2_arg_1: &[u8] = &(*p0);
      let v89_2_arg_3: &Space = &(&(*s0)).make_map();
      let v89_2_arg_4: &Space = &(&(*s1)).make_map();
      let mut v89_2_more = v87_18_cursor.is_val() || next_value_within(&mut v87_18_cursor,(v87_18_origin + 1));
      while v89_2_more {
        {
        let v89_2_depth = v87_18_cursor.path().len();
        let mut v90_5_cursor = (*v89_2_arg_3).read_zipper();
        let v90_5_origin = v90_5_cursor.path().len();
        for v90_5_byte in v90_5_cursor.child_mask().iter() {
          v90_5_cursor.descend_to_existing_byte(v90_5_byte);
          {
          let v91_2: Path = concat_path(&(*v89_2_arg_1),&v90_5_cursor.path()[v90_5_origin..(v90_5_origin + 1)]);
          let v91_3: Space = routine_8(c, &(v91_2), &v87_18_cursor.path()[v87_18_origin..v89_2_depth], &v90_5_cursor, &((*v89_2_arg_4).read_zipper()));
          drop(v91_2);
          join_wrapped_into(&mut v87_18_write,&((v91_3).read_zipper()),&[]);
          }
          v90_5_cursor.ascend(1);
        }
        drop(v90_5_cursor);
        }
        v89_2_more = next_value_within(&mut v87_18_cursor,(v87_18_origin + 1));
      }
      }
      v87_18_cursor.ascend(1);
    }
    drop(v87_18_cursor);
    drop(v87_18_write);
    let v87_19: Space = unite(&(v87_15),&(v87_18));
    compose(&(v86_9),&(v87_19))
  };
  drop(v86_9);
  let v86_22: Space = intersect(&(*CONSTANT_15),&(v86_6));
  drop(v86_6);
  let v86_23: Space = if has_head(&(v86_22)) { singleton(&[]) } else { Space::new() };
  drop(v86_22);
  let v86_25: Space = if (&(v86_23)).is_empty() { Space::new() } else {
    let mut v92_24 = Space::new();
    let mut v92_24_write = v92_24.write_zipper();
    let mut v92_24_cursor = (*s0).read_zipper();
    let v92_24_origin = v92_24_cursor.path().len();
    for v92_24_byte in v92_24_cursor.child_mask().iter() {
      v92_24_cursor.descend_to_existing_byte(v92_24_byte);
      {
      let v93_2: Space = routine_9(c, &v92_24_cursor.path()[v92_24_origin..(v92_24_origin + 1)], &v92_24_cursor.path()[v92_24_origin..(v92_24_origin + 1)], &(*p0), &v92_24_cursor, &(*s1));
      join_wrapped_into(&mut v92_24_write,&((v93_2).read_zipper()),&[]);
      }
      v92_24_cursor.ascend(1);
    }
    drop(v92_24_cursor);
    drop(v92_24_write);
    compose(&(v86_23),&(v92_24))
  };
  drop(v86_23);
  let v86_26: Space = unite(&(v86_20),&(v86_25));
  (v86_26).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v94_7: Space = singleton(&(*p1));
  let v94_8: Space = intersect(&(*CONSTANT_15),&(v94_7));
  let v94_9: Space = if has_head(&(v94_8)) { singleton(&[]) } else { Space::new() };
  drop(v94_8);
  let v94_10: Space = subtract(&(*CONSTANT_0),&(v94_9));
  drop(v94_9);
  let v94_21: Space = if (&(v94_10)).is_empty() { Space::new() } else {
    let v95_13: Space = first_matching(&(descend_cursor((*CONSTANT_16).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v95_16: Space = if (&(v95_13)).is_empty() { Space::new() } else {
      let v96_15: Space = routine_21(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0), &(*s1));
      compose(&(v95_13),&(v96_15))
    };
    drop(v95_13);
    let mut v95_19 = Space::new();
    let mut v95_19_write = v95_19.write_zipper();
    let mut v95_19_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p1));
    let v95_19_origin = v95_19_cursor.path().len();
    for v95_19_byte in v95_19_cursor.child_mask().iter() {
      v95_19_cursor.descend_to_existing_byte(v95_19_byte);
      {
      let v97_2_arg_0: &[u8] = &v95_19_cursor.path()[v95_19_origin..(v95_19_origin + 1)];
      let v97_2_arg_1: &[u8] = &(*p0);
      let v97_2_arg_2: &[u8] = &(*p2);
      let v97_2_arg_4: &Space = &(&(*s0)).make_map();
      let v97_2_arg_5: &Space = &(&(*s1)).make_map();
      let mut v97_2_more = v95_19_cursor.is_val() || next_value_within(&mut v95_19_cursor,(v95_19_origin + 1));
      while v97_2_more {
        {
        let v97_2_depth = v95_19_cursor.path().len();
        let mut v98_6_cursor = (*v97_2_arg_4).read_zipper();
        let v98_6_origin = v98_6_cursor.path().len();
        for v98_6_byte in v98_6_cursor.child_mask().iter() {
          v98_6_cursor.descend_to_existing_byte(v98_6_byte);
          {
          let v99_2: Path = concat_path(&(*v97_2_arg_1),&v98_6_cursor.path()[v98_6_origin..(v98_6_origin + 1)]);
          let v99_3: Space = routine_9(c, &(v99_2), &v95_19_cursor.path()[v95_19_origin..v97_2_depth], &(*v97_2_arg_2), &v98_6_cursor, &((*v97_2_arg_5).read_zipper()));
          drop(v99_2);
          join_wrapped_into(&mut v95_19_write,&((v99_3).read_zipper()),&[]);
          }
          v98_6_cursor.ascend(1);
        }
        drop(v98_6_cursor);
        }
        v97_2_more = next_value_within(&mut v95_19_cursor,(v95_19_origin + 1));
      }
      }
      v95_19_cursor.ascend(1);
    }
    drop(v95_19_cursor);
    drop(v95_19_write);
    let v95_20: Space = unite(&(v95_16),&(v95_19));
    compose(&(v94_10),&(v95_20))
  };
  drop(v94_10);
  let v94_23: Space = intersect(&(*CONSTANT_15),&(v94_7));
  drop(v94_7);
  let v94_24: Space = if has_head(&(v94_23)) { singleton(&[]) } else { Space::new() };
  drop(v94_23);
  let v94_31: Space = if (&(v94_24)).is_empty() { Space::new() } else {
    let mut v100_30 = Space::new();
    let mut v100_30_write = v100_30.write_zipper();
    let mut v100_30_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_8)),&(*CONSTANT_10)),&(*p0));
    let v100_30_origin = v100_30_cursor.path().len();
    for v100_30_byte in v100_30_cursor.child_mask().iter() {
      v100_30_cursor.descend_to_existing_byte(v100_30_byte);
      {
      let v101_2: Space = routine_22(c, &v100_30_cursor.path()[v100_30_origin..(v100_30_origin + 1)], &v100_30_cursor.path()[v100_30_origin..(v100_30_origin + 1)], &(*p2), &v100_30_cursor);
      join_wrapped_into(&mut v100_30_write,&((v101_2).read_zipper()),&[]);
      }
      v100_30_cursor.ascend(1);
    }
    drop(v100_30_cursor);
    drop(v100_30_write);
    compose(&(v94_24),&(v100_30))
  };
  drop(v94_24);
  let v94_32: Space = unite(&(v94_21),&(v94_31));
  (v94_32).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v102_5: Space = singleton(&(*p0));
  let v102_6: Space = intersect(&(*CONSTANT_15),&(v102_5));
  let v102_7: Space = if has_head(&(v102_6)) { singleton(&[]) } else { Space::new() };
  drop(v102_6);
  let v102_8: Space = subtract(&(*CONSTANT_0),&(v102_7));
  drop(v102_7);
  let v102_13: Space = intersect(&(*CONSTANT_15),&(v102_5));
  drop(v102_5);
  let v102_14: Space = if has_head(&(v102_13)) { singleton(&[]) } else { Space::new() };
  drop(v102_13);
  let mut v102_15 = Space::new();
  let mut v102_15_write = v102_15.write_zipper();
  let mut v102_15_cursor = (*s0).read_zipper();
  let v102_15_origin = v102_15_cursor.path().len();
  for v102_15_byte in v102_15_cursor.child_mask().iter() {
    v102_15_cursor.descend_to_existing_byte(v102_15_byte);
    {
    let v103_4: Space = if (&(v102_8)).is_empty() { Space::new() } else {
      let v104_2: Path = concat_path(&(*p1),&v102_15_cursor.path()[v102_15_origin..(v102_15_origin + 1)]);
      let mut v104_3 = Space::new();
      let mut v104_3_write = v104_3.write_zipper();
      let v104_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v104_3_arg_1: &[u8] = &(v104_2);
      let v104_3_arg_3: &Space = &(&v102_15_cursor).make_map();
      let mut v104_3_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p0));
      let v104_3_origin = v104_3_cursor.path().len();
      let mut v104_3_more = v104_3_cursor.is_val() || next_value_within(&mut v104_3_cursor,v104_3_origin);
      while v104_3_more {
        {
        let v104_3_depth = v104_3_cursor.path().len();
        let v105_4: Space = routine_10(c, &v104_3_cursor.path()[v104_3_origin..v104_3_depth], &(*v104_3_arg_1), &((*v104_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v104_3_write,&((v105_4).read_zipper()),&[]);
        }
        v104_3_more = next_value_within(&mut v104_3_cursor,v104_3_origin);
      }
      drop(v104_3_cursor);
      drop(v104_3_write);
      compose(&(v102_8),&(v104_3))
    };
    let v103_6: Space = if (&(v102_14)).is_empty() { Space::new() } else {
      let v106_2: Path = concat_path(&(*p1),&v102_15_cursor.path()[v102_15_origin..(v102_15_origin + 1)]);
      let mut v106_5 = Space::new();
      let mut v106_5_write = v106_5.write_zipper();
      for v106_5_byte in v102_15_cursor.child_mask().iter() {
        v102_15_cursor.descend_to_existing_byte(v106_5_byte);
        {
        let v107_2: Space = routine_11(c, &v102_15_cursor.path()[(v102_15_origin + 1)..(v102_15_origin + 2)], &v102_15_cursor.path()[(v102_15_origin + 1)..(v102_15_origin + 2)], &(v106_2), &v102_15_cursor);
        join_wrapped_into(&mut v106_5_write,&((v107_2).read_zipper()),&[]);
        }
        v102_15_cursor.ascend(1);
      }
      drop(v106_5_write);
      drop(v106_2);
      compose(&(v102_14),&(v106_5))
    };
    let v103_7: Space = unite(&(v103_4),&(v103_6));
    join_wrapped_into(&mut v102_15_write,&((v103_7).read_zipper()),&[]);
    }
    v102_15_cursor.ascend(1);
  }
  drop(v102_15_cursor);
  drop(v102_15_write);
  drop(v102_8);
  drop(v102_14);
  (v102_15).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v108_5: Space = singleton(&(*p1));
  let v108_6: Space = intersect(&(*CONSTANT_15),&(v108_5));
  let v108_7: Space = if has_head(&(v108_6)) { singleton(&[]) } else { Space::new() };
  drop(v108_6);
  let v108_8: Space = if (&(v108_7)).is_empty() { Space::new() } else {
    compose(&(v108_7),&(*s0))
  };
  drop(v108_7);
  let v108_9: Space = wrap(&(v108_8),&(*p0));
  drop(v108_8);
  let v108_10: Space = wrap(&(v108_9),&(*p2));
  drop(v108_9);
  let v108_12: Space = wrap(&(v108_10),&(*CONSTANT_10));
  drop(v108_10);
  let v108_15: Space = intersect(&(*CONSTANT_15),&(v108_5));
  drop(v108_5);
  let v108_16: Space = if has_head(&(v108_15)) { singleton(&[]) } else { Space::new() };
  drop(v108_15);
  let v108_17: Space = subtract(&(*CONSTANT_0),&(v108_16));
  drop(v108_16);
  let v108_28: Space = if (&(v108_17)).is_empty() { Space::new() } else {
    let v110_20: Space = first_matching(&(descend_cursor((*CONSTANT_16).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v110_23: Space = if (&(v110_20)).is_empty() { Space::new() } else {
      let v111_22: Space = routine_23(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v110_20),&(v111_22))
    };
    drop(v110_20);
    let mut v110_26 = Space::new();
    let mut v110_26_write = v110_26.write_zipper();
    let mut v110_26_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p1));
    let v110_26_origin = v110_26_cursor.path().len();
    for v110_26_byte in v110_26_cursor.child_mask().iter() {
      v110_26_cursor.descend_to_existing_byte(v110_26_byte);
      {
      let v112_2_arg_0: &[u8] = &v110_26_cursor.path()[v110_26_origin..(v110_26_origin + 1)];
      let v112_2_arg_1: &[u8] = &(*p0);
      let v112_2_arg_2: &[u8] = &(*p2);
      let v112_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v112_2_more = v110_26_cursor.is_val() || next_value_within(&mut v110_26_cursor,(v110_26_origin + 1));
      while v112_2_more {
        {
        let v112_2_depth = v110_26_cursor.path().len();
        let mut v113_5_cursor = (*v112_2_arg_4).read_zipper();
        let v113_5_origin = v113_5_cursor.path().len();
        for v113_5_byte in v113_5_cursor.child_mask().iter() {
          v113_5_cursor.descend_to_existing_byte(v113_5_byte);
          {
          let v114_2: Path = concat_path(&(*v112_2_arg_1),&v113_5_cursor.path()[v113_5_origin..(v113_5_origin + 1)]);
          let v114_3: Space = routine_11(c, &(v114_2), &v110_26_cursor.path()[v110_26_origin..v112_2_depth], &(*v112_2_arg_2), &v113_5_cursor);
          drop(v114_2);
          join_wrapped_into(&mut v110_26_write,&((v114_3).read_zipper()),&[]);
          }
          v113_5_cursor.ascend(1);
        }
        drop(v113_5_cursor);
        }
        v112_2_more = next_value_within(&mut v110_26_cursor,(v110_26_origin + 1));
      }
      }
      v110_26_cursor.ascend(1);
    }
    drop(v110_26_cursor);
    drop(v110_26_write);
    let v110_27: Space = unite(&(v110_23),&(v110_26));
    compose(&(v108_17),&(v110_27))
  };
  drop(v108_17);
  let v108_29: Space = unite(&(v108_12),&(v108_28));
  drop(v108_12);
  (v108_29).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v115_6: Space = singleton(&(*p0));
  let v115_7: Space = intersect(&(*CONSTANT_15),&(v115_6));
  let v115_8: Space = if has_head(&(v115_7)) { singleton(&[]) } else { Space::new() };
  drop(v115_7);
  let v115_9: Space = subtract(&(*CONSTANT_0),&(v115_8));
  drop(v115_8);
  let v115_14: Space = intersect(&(*CONSTANT_15),&(v115_6));
  drop(v115_6);
  let v115_15: Space = if has_head(&(v115_14)) { singleton(&[]) } else { Space::new() };
  drop(v115_14);
  let mut v115_16 = Space::new();
  let mut v115_16_write = v115_16.write_zipper();
  let mut v115_16_cursor = (*s0).read_zipper();
  let v115_16_origin = v115_16_cursor.path().len();
  for v115_16_byte in v115_16_cursor.child_mask().iter() {
    v115_16_cursor.descend_to_existing_byte(v115_16_byte);
    {
    let v116_4: Space = if (&(v115_9)).is_empty() { Space::new() } else {
      let v117_2: Path = concat_path(&(*p1),&v115_16_cursor.path()[v115_16_origin..(v115_16_origin + 1)]);
      let mut v117_3 = Space::new();
      let mut v117_3_write = v117_3.write_zipper();
      let v117_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v117_3_arg_1: &[u8] = &(v117_2);
      let v117_3_arg_3: &Space = &(&v115_16_cursor).make_map();
      let v117_3_arg_4: &Space = &(&(*s1)).make_map();
      let mut v117_3_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p0));
      let v117_3_origin = v117_3_cursor.path().len();
      let mut v117_3_more = v117_3_cursor.is_val() || next_value_within(&mut v117_3_cursor,v117_3_origin);
      while v117_3_more {
        {
        let v117_3_depth = v117_3_cursor.path().len();
        let v118_5: Space = routine_12(c, &v117_3_cursor.path()[v117_3_origin..v117_3_depth], &(*v117_3_arg_1), &((*v117_3_arg_3).read_zipper()), &((*v117_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v117_3_write,&((v118_5).read_zipper()),&[]);
        }
        v117_3_more = next_value_within(&mut v117_3_cursor,v117_3_origin);
      }
      drop(v117_3_cursor);
      drop(v117_3_write);
      compose(&(v115_9),&(v117_3))
    };
    let v116_6: Space = if (&(v115_15)).is_empty() { Space::new() } else {
      let v119_2: Path = concat_path(&(*p1),&v115_16_cursor.path()[v115_16_origin..(v115_16_origin + 1)]);
      let mut v119_5 = Space::new();
      let mut v119_5_write = v119_5.write_zipper();
      for v119_5_byte in v115_16_cursor.child_mask().iter() {
        v115_16_cursor.descend_to_existing_byte(v119_5_byte);
        {
        let v120_2: Space = routine_3(c, &v115_16_cursor.path()[(v115_16_origin + 1)..(v115_16_origin + 2)], &v115_16_cursor.path()[(v115_16_origin + 1)..(v115_16_origin + 2)], &(v119_2), &v115_16_cursor, &(*s1));
        join_wrapped_into(&mut v119_5_write,&((v120_2).read_zipper()),&[]);
        }
        v115_16_cursor.ascend(1);
      }
      drop(v119_5_write);
      drop(v119_2);
      compose(&(v115_15),&(v119_5))
    };
    let v116_7: Space = unite(&(v116_4),&(v116_6));
    join_wrapped_into(&mut v115_16_write,&((v116_7).read_zipper()),&[]);
    }
    v115_16_cursor.ascend(1);
  }
  drop(v115_16_cursor);
  drop(v115_16_write);
  drop(v115_9);
  drop(v115_15);
  (v115_16).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v121_7: Space = singleton(&(*p0));
  let v121_8: Space = intersect(&(*CONSTANT_15),&(v121_7));
  let v121_9: Space = if has_head(&(v121_8)) { singleton(&[]) } else { Space::new() };
  drop(v121_8);
  let v121_10: Space = subtract(&(*CONSTANT_0),&(v121_9));
  drop(v121_9);
  let v121_15: Space = intersect(&(*CONSTANT_15),&(v121_7));
  drop(v121_7);
  let v121_16: Space = if has_head(&(v121_15)) { singleton(&[]) } else { Space::new() };
  drop(v121_15);
  let mut v121_22 = Space::new();
  let mut v121_22_write = v121_22.write_zipper();
  let mut v121_22_cursor = (*s0).read_zipper();
  let v121_22_origin = v121_22_cursor.path().len();
  for v121_22_byte in v121_22_cursor.child_mask().iter() {
    v121_22_cursor.descend_to_existing_byte(v121_22_byte);
    {
    let v122_4: Space = if (&(v121_10)).is_empty() { Space::new() } else {
      let v123_2: Path = concat_path(&(*p1),&v121_22_cursor.path()[v121_22_origin..(v121_22_origin + 1)]);
      let mut v123_3 = Space::new();
      let mut v123_3_write = v123_3.write_zipper();
      let v123_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v123_3_arg_1: &[u8] = &(v123_2);
      let v123_3_arg_2: &[u8] = &(*p2);
      let v123_3_arg_4: &Space = &(&v121_22_cursor).make_map();
      let v123_3_arg_5: &Space = &(&(*s1)).make_map();
      let mut v123_3_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p0));
      let v123_3_origin = v123_3_cursor.path().len();
      let mut v123_3_more = v123_3_cursor.is_val() || next_value_within(&mut v123_3_cursor,v123_3_origin);
      while v123_3_more {
        {
        let v123_3_depth = v123_3_cursor.path().len();
        let v124_6: Space = routine_13(c, &v123_3_cursor.path()[v123_3_origin..v123_3_depth], &(*v123_3_arg_1), &(*v123_3_arg_2), &((*v123_3_arg_4).read_zipper()), &((*v123_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v123_3_write,&((v124_6).read_zipper()),&[]);
        }
        v123_3_more = next_value_within(&mut v123_3_cursor,v123_3_origin);
      }
      drop(v123_3_cursor);
      drop(v123_3_write);
      drop(v123_2);
      compose(&(v121_10),&(v123_3))
    };
    let v122_7: Space = if (&(v121_16)).is_empty() { Space::new() } else {
      let mut v125_6 = Space::new();
      let mut v125_6_write = v125_6.write_zipper();
      let mut v125_6_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_11)),&(*CONSTANT_10)),&(*p1)),&v121_22_cursor.path()[v121_22_origin..(v121_22_origin + 1)]);
      let v125_6_origin = v125_6_cursor.path().len();
      for v125_6_byte in v125_6_cursor.child_mask().iter() {
        v125_6_cursor.descend_to_existing_byte(v125_6_byte);
        {
        let v126_2: Space = routine_14(c, &v125_6_cursor.path()[v125_6_origin..(v125_6_origin + 1)], &v125_6_cursor.path()[v125_6_origin..(v125_6_origin + 1)], &(*p2), &v125_6_cursor);
        join_wrapped_into(&mut v125_6_write,&((v126_2).read_zipper()),&[]);
        }
        v125_6_cursor.ascend(1);
      }
      drop(v125_6_cursor);
      drop(v125_6_write);
      compose(&(v121_16),&(v125_6))
    };
    let v122_8: Space = unite(&(v122_4),&(v122_7));
    join_wrapped_into(&mut v121_22_write,&((v122_8).read_zipper()),&[]);
    }
    v121_22_cursor.ascend(1);
  }
  drop(v121_22_cursor);
  drop(v121_22_write);
  drop(v121_10);
  drop(v121_16);
  (v121_22).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v127_6: Space = singleton(&(*p1));
  let v127_7: Space = intersect(&(*CONSTANT_15),&(v127_6));
  let v127_8: Space = if has_head(&(v127_7)) { singleton(&[]) } else { Space::new() };
  drop(v127_7);
  let v127_9: Space = subtract(&(*CONSTANT_0),&(v127_8));
  drop(v127_8);
  let v127_20: Space = if (&(v127_9)).is_empty() { Space::new() } else {
    let v128_12: Space = first_matching(&(descend_cursor((*CONSTANT_16).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v128_15: Space = if (&(v128_12)).is_empty() { Space::new() } else {
      let v129_14: Space = routine_24(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v128_12),&(v129_14))
    };
    drop(v128_12);
    let mut v128_18 = Space::new();
    let mut v128_18_write = v128_18.write_zipper();
    let mut v128_18_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p1));
    let v128_18_origin = v128_18_cursor.path().len();
    for v128_18_byte in v128_18_cursor.child_mask().iter() {
      v128_18_cursor.descend_to_existing_byte(v128_18_byte);
      {
      let v130_2_arg_0: &[u8] = &v128_18_cursor.path()[v128_18_origin..(v128_18_origin + 1)];
      let v130_2_arg_1: &[u8] = &(*p0);
      let v130_2_arg_2: &[u8] = &(*p2);
      let v130_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v130_2_more = v128_18_cursor.is_val() || next_value_within(&mut v128_18_cursor,(v128_18_origin + 1));
      while v130_2_more {
        {
        let v130_2_depth = v128_18_cursor.path().len();
        let mut v131_5_cursor = (*v130_2_arg_4).read_zipper();
        let v131_5_origin = v131_5_cursor.path().len();
        for v131_5_byte in v131_5_cursor.child_mask().iter() {
          v131_5_cursor.descend_to_existing_byte(v131_5_byte);
          {
          let v132_2: Path = concat_path(&(*v130_2_arg_1),&v131_5_cursor.path()[v131_5_origin..(v131_5_origin + 1)]);
          let v132_3: Space = routine_14(c, &(v132_2), &v128_18_cursor.path()[v128_18_origin..v130_2_depth], &(*v130_2_arg_2), &v131_5_cursor);
          drop(v132_2);
          join_wrapped_into(&mut v128_18_write,&((v132_3).read_zipper()),&[]);
          }
          v131_5_cursor.ascend(1);
        }
        drop(v131_5_cursor);
        }
        v130_2_more = next_value_within(&mut v128_18_cursor,(v128_18_origin + 1));
      }
      }
      v128_18_cursor.ascend(1);
    }
    drop(v128_18_cursor);
    drop(v128_18_write);
    let v128_19: Space = unite(&(v128_15),&(v128_18));
    compose(&(v127_9),&(v128_19))
  };
  drop(v127_9);
  let v127_22: Space = intersect(&(*CONSTANT_15),&(v127_6));
  drop(v127_6);
  let v127_23: Space = if has_head(&(v127_22)) { singleton(&[]) } else { Space::new() };
  drop(v127_22);
  let v127_24: Space = if (&(v127_23)).is_empty() { Space::new() } else {
    compose(&(v127_23),&(*s0))
  };
  drop(v127_23);
  let v127_25: Space = wrap(&(v127_24),&(*p0));
  drop(v127_24);
  let v127_26: Space = wrap(&(v127_25),&(*p2));
  drop(v127_25);
  let v127_27: Space = unite(&(v127_20),&(v127_26));
  drop(v127_26);
  (v127_27).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v134_6: Space = singleton(&(*p0));
  let v134_7: Space = intersect(&(*CONSTANT_15),&(v134_6));
  let v134_8: Space = if has_head(&(v134_7)) { singleton(&[]) } else { Space::new() };
  drop(v134_7);
  let v134_9: Space = subtract(&(*CONSTANT_0),&(v134_8));
  drop(v134_8);
  let v134_14: Space = intersect(&(*CONSTANT_15),&(v134_6));
  drop(v134_6);
  let v134_15: Space = if has_head(&(v134_14)) { singleton(&[]) } else { Space::new() };
  drop(v134_14);
  let mut v134_16 = Space::new();
  let mut v134_16_write = v134_16.write_zipper();
  let mut v134_16_cursor = (*s0).read_zipper();
  let v134_16_origin = v134_16_cursor.path().len();
  for v134_16_byte in v134_16_cursor.child_mask().iter() {
    v134_16_cursor.descend_to_existing_byte(v134_16_byte);
    {
    let v135_4: Space = if (&(v134_9)).is_empty() { Space::new() } else {
      let v136_2: Path = concat_path(&(*p1),&v134_16_cursor.path()[v134_16_origin..(v134_16_origin + 1)]);
      let mut v136_3 = Space::new();
      let mut v136_3_write = v136_3.write_zipper();
      let v136_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v136_3_arg_1: &[u8] = &(v136_2);
      let v136_3_arg_3: &Space = &(&v134_16_cursor).make_map();
      let v136_3_arg_4: &Space = &(&(*s1)).make_map();
      let mut v136_3_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p0));
      let v136_3_origin = v136_3_cursor.path().len();
      let mut v136_3_more = v136_3_cursor.is_val() || next_value_within(&mut v136_3_cursor,v136_3_origin);
      while v136_3_more {
        {
        let v136_3_depth = v136_3_cursor.path().len();
        let v137_5: Space = routine_15(c, &v136_3_cursor.path()[v136_3_origin..v136_3_depth], &(*v136_3_arg_1), &((*v136_3_arg_3).read_zipper()), &((*v136_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v136_3_write,&((v137_5).read_zipper()),&[]);
        }
        v136_3_more = next_value_within(&mut v136_3_cursor,v136_3_origin);
      }
      drop(v136_3_cursor);
      drop(v136_3_write);
      compose(&(v134_9),&(v136_3))
    };
    let v135_6: Space = if (&(v134_15)).is_empty() { Space::new() } else {
      let v138_2: Path = concat_path(&(*p1),&v134_16_cursor.path()[v134_16_origin..(v134_16_origin + 1)]);
      let mut v138_5 = Space::new();
      let mut v138_5_write = v138_5.write_zipper();
      for v138_5_byte in v134_16_cursor.child_mask().iter() {
        v134_16_cursor.descend_to_existing_byte(v138_5_byte);
        {
        let v139_2: Space = routine_5(c, &v134_16_cursor.path()[(v134_16_origin + 1)..(v134_16_origin + 2)], &v134_16_cursor.path()[(v134_16_origin + 1)..(v134_16_origin + 2)], &(v138_2), &v134_16_cursor, &(*s1));
        join_wrapped_into(&mut v138_5_write,&((v139_2).read_zipper()),&[]);
        }
        v134_16_cursor.ascend(1);
      }
      drop(v138_5_write);
      drop(v138_2);
      compose(&(v134_15),&(v138_5))
    };
    let v135_7: Space = unite(&(v135_4),&(v135_6));
    join_wrapped_into(&mut v134_16_write,&((v135_7).read_zipper()),&[]);
    }
    v134_16_cursor.ascend(1);
  }
  drop(v134_16_cursor);
  drop(v134_16_write);
  drop(v134_9);
  drop(v134_15);
  (v134_16).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v140_7: Space = singleton(&(*p0));
  let v140_8: Space = intersect(&(*CONSTANT_15),&(v140_7));
  let v140_9: Space = if has_head(&(v140_8)) { singleton(&[]) } else { Space::new() };
  drop(v140_8);
  let v140_10: Space = subtract(&(*CONSTANT_0),&(v140_9));
  drop(v140_9);
  let v140_15: Space = intersect(&(*CONSTANT_15),&(v140_7));
  drop(v140_7);
  let v140_16: Space = if has_head(&(v140_15)) { singleton(&[]) } else { Space::new() };
  drop(v140_15);
  let mut v140_22 = Space::new();
  let mut v140_22_write = v140_22.write_zipper();
  let mut v140_22_cursor = (*s0).read_zipper();
  let v140_22_origin = v140_22_cursor.path().len();
  for v140_22_byte in v140_22_cursor.child_mask().iter() {
    v140_22_cursor.descend_to_existing_byte(v140_22_byte);
    {
    let v141_4: Space = if (&(v140_10)).is_empty() { Space::new() } else {
      let v142_2: Path = concat_path(&(*p1),&v140_22_cursor.path()[v140_22_origin..(v140_22_origin + 1)]);
      let mut v142_3 = Space::new();
      let mut v142_3_write = v142_3.write_zipper();
      let v142_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v142_3_arg_1: &[u8] = &(v142_2);
      let v142_3_arg_2: &[u8] = &(*p2);
      let v142_3_arg_4: &Space = &(&v140_22_cursor).make_map();
      let v142_3_arg_5: &Space = &(&(*s1)).make_map();
      let mut v142_3_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p0));
      let v142_3_origin = v142_3_cursor.path().len();
      let mut v142_3_more = v142_3_cursor.is_val() || next_value_within(&mut v142_3_cursor,v142_3_origin);
      while v142_3_more {
        {
        let v142_3_depth = v142_3_cursor.path().len();
        let v143_6: Space = routine_16(c, &v142_3_cursor.path()[v142_3_origin..v142_3_depth], &(*v142_3_arg_1), &(*v142_3_arg_2), &((*v142_3_arg_4).read_zipper()), &((*v142_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v142_3_write,&((v143_6).read_zipper()),&[]);
        }
        v142_3_more = next_value_within(&mut v142_3_cursor,v142_3_origin);
      }
      drop(v142_3_cursor);
      drop(v142_3_write);
      drop(v142_2);
      compose(&(v140_10),&(v142_3))
    };
    let v141_7: Space = if (&(v140_16)).is_empty() { Space::new() } else {
      let mut v144_6 = Space::new();
      let mut v144_6_write = v144_6.write_zipper();
      let mut v144_6_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_8)),&(*CONSTANT_10)),&(*p1)),&v140_22_cursor.path()[v140_22_origin..(v140_22_origin + 1)]);
      let v144_6_origin = v144_6_cursor.path().len();
      for v144_6_byte in v144_6_cursor.child_mask().iter() {
        v144_6_cursor.descend_to_existing_byte(v144_6_byte);
        {
        let v145_2: Space = routine_17(c, &v144_6_cursor.path()[v144_6_origin..(v144_6_origin + 1)], &v144_6_cursor.path()[v144_6_origin..(v144_6_origin + 1)], &(*p2), &v144_6_cursor);
        join_wrapped_into(&mut v144_6_write,&((v145_2).read_zipper()),&[]);
        }
        v144_6_cursor.ascend(1);
      }
      drop(v144_6_cursor);
      drop(v144_6_write);
      compose(&(v140_16),&(v144_6))
    };
    let v141_8: Space = unite(&(v141_4),&(v141_7));
    join_wrapped_into(&mut v140_22_write,&((v141_8).read_zipper()),&[]);
    }
    v140_22_cursor.ascend(1);
  }
  drop(v140_22_cursor);
  drop(v140_22_write);
  drop(v140_10);
  drop(v140_16);
  (v140_22).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v146_6: Space = singleton(&(*p1));
  let v146_7: Space = intersect(&(*CONSTANT_15),&(v146_6));
  let v146_8: Space = if has_head(&(v146_7)) { singleton(&[]) } else { Space::new() };
  drop(v146_7);
  let v146_9: Space = subtract(&(*CONSTANT_0),&(v146_8));
  drop(v146_8);
  let v146_20: Space = if (&(v146_9)).is_empty() { Space::new() } else {
    let v147_12: Space = first_matching(&(descend_cursor((*CONSTANT_16).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v147_15: Space = if (&(v147_12)).is_empty() { Space::new() } else {
      let v148_14: Space = routine_25(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v147_12),&(v148_14))
    };
    drop(v147_12);
    let mut v147_18 = Space::new();
    let mut v147_18_write = v147_18.write_zipper();
    let mut v147_18_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p1));
    let v147_18_origin = v147_18_cursor.path().len();
    for v147_18_byte in v147_18_cursor.child_mask().iter() {
      v147_18_cursor.descend_to_existing_byte(v147_18_byte);
      {
      let v149_2_arg_0: &[u8] = &v147_18_cursor.path()[v147_18_origin..(v147_18_origin + 1)];
      let v149_2_arg_1: &[u8] = &(*p0);
      let v149_2_arg_2: &[u8] = &(*p2);
      let v149_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v149_2_more = v147_18_cursor.is_val() || next_value_within(&mut v147_18_cursor,(v147_18_origin + 1));
      while v149_2_more {
        {
        let v149_2_depth = v147_18_cursor.path().len();
        let mut v150_5_cursor = (*v149_2_arg_4).read_zipper();
        let v150_5_origin = v150_5_cursor.path().len();
        for v150_5_byte in v150_5_cursor.child_mask().iter() {
          v150_5_cursor.descend_to_existing_byte(v150_5_byte);
          {
          let v151_2: Path = concat_path(&(*v149_2_arg_1),&v150_5_cursor.path()[v150_5_origin..(v150_5_origin + 1)]);
          let v151_3: Space = routine_17(c, &(v151_2), &v147_18_cursor.path()[v147_18_origin..v149_2_depth], &(*v149_2_arg_2), &v150_5_cursor);
          drop(v151_2);
          join_wrapped_into(&mut v147_18_write,&((v151_3).read_zipper()),&[]);
          }
          v150_5_cursor.ascend(1);
        }
        drop(v150_5_cursor);
        }
        v149_2_more = next_value_within(&mut v147_18_cursor,(v147_18_origin + 1));
      }
      }
      v147_18_cursor.ascend(1);
    }
    drop(v147_18_cursor);
    drop(v147_18_write);
    let v147_19: Space = unite(&(v147_15),&(v147_18));
    compose(&(v146_9),&(v147_19))
  };
  drop(v146_9);
  let v146_22: Space = intersect(&(*CONSTANT_15),&(v146_6));
  drop(v146_6);
  let v146_23: Space = if has_head(&(v146_22)) { singleton(&[]) } else { Space::new() };
  drop(v146_22);
  let v146_24: Space = if (&(v146_23)).is_empty() { Space::new() } else {
    compose(&(v146_23),&(*s0))
  };
  drop(v146_23);
  let v146_25: Space = wrap(&(v146_24),&(*p0));
  drop(v146_24);
  let v146_26: Space = wrap(&(v146_25),&(*p2));
  drop(v146_25);
  let v146_27: Space = unite(&(v146_20),&(v146_26));
  drop(v146_26);
  (v146_27).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v153_5: Space = singleton(&(*p0));
  let v153_6: Space = intersect(&(*CONSTANT_15),&(v153_5));
  let v153_7: Space = if has_head(&(v153_6)) { singleton(&[]) } else { Space::new() };
  drop(v153_6);
  let v153_8: Space = subtract(&(*CONSTANT_0),&(v153_7));
  drop(v153_7);
  let v153_13: Space = intersect(&(*CONSTANT_15),&(v153_5));
  drop(v153_5);
  let v153_14: Space = if has_head(&(v153_13)) { singleton(&[]) } else { Space::new() };
  drop(v153_13);
  let mut v153_15 = Space::new();
  let mut v153_15_write = v153_15.write_zipper();
  let mut v153_15_cursor = (*s0).read_zipper();
  let v153_15_origin = v153_15_cursor.path().len();
  for v153_15_byte in v153_15_cursor.child_mask().iter() {
    v153_15_cursor.descend_to_existing_byte(v153_15_byte);
    {
    let v154_4: Space = if (&(v153_8)).is_empty() { Space::new() } else {
      let v155_2: Path = concat_path(&(*p1),&v153_15_cursor.path()[v153_15_origin..(v153_15_origin + 1)]);
      let mut v155_3 = Space::new();
      let mut v155_3_write = v155_3.write_zipper();
      let v155_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v155_3_arg_1: &[u8] = &(v155_2);
      let v155_3_arg_3: &Space = &(&v153_15_cursor).make_map();
      let mut v155_3_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p0));
      let v155_3_origin = v155_3_cursor.path().len();
      let mut v155_3_more = v155_3_cursor.is_val() || next_value_within(&mut v155_3_cursor,v155_3_origin);
      while v155_3_more {
        {
        let v155_3_depth = v155_3_cursor.path().len();
        let v156_4: Space = routine_18(c, &v155_3_cursor.path()[v155_3_origin..v155_3_depth], &(*v155_3_arg_1), &((*v155_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v155_3_write,&((v156_4).read_zipper()),&[]);
        }
        v155_3_more = next_value_within(&mut v155_3_cursor,v155_3_origin);
      }
      drop(v155_3_cursor);
      drop(v155_3_write);
      compose(&(v153_8),&(v155_3))
    };
    let v154_6: Space = if (&(v153_14)).is_empty() { Space::new() } else {
      let v157_2: Path = concat_path(&(*p1),&v153_15_cursor.path()[v153_15_origin..(v153_15_origin + 1)]);
      let mut v157_5 = Space::new();
      let mut v157_5_write = v157_5.write_zipper();
      for v157_5_byte in v153_15_cursor.child_mask().iter() {
        v153_15_cursor.descend_to_existing_byte(v157_5_byte);
        {
        let v158_2: Space = routine_7(c, &v153_15_cursor.path()[(v153_15_origin + 1)..(v153_15_origin + 2)], &v153_15_cursor.path()[(v153_15_origin + 1)..(v153_15_origin + 2)], &(v157_2), &v153_15_cursor);
        join_wrapped_into(&mut v157_5_write,&((v158_2).read_zipper()),&[]);
        }
        v153_15_cursor.ascend(1);
      }
      drop(v157_5_write);
      drop(v157_2);
      compose(&(v153_14),&(v157_5))
    };
    let v154_7: Space = unite(&(v154_4),&(v154_6));
    join_wrapped_into(&mut v153_15_write,&((v154_7).read_zipper()),&[]);
    }
    v153_15_cursor.ascend(1);
  }
  drop(v153_15_cursor);
  drop(v153_15_write);
  drop(v153_8);
  drop(v153_14);
  (v153_15).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v159_6: Space = singleton(&(*p0));
  let v159_7: Space = intersect(&(*CONSTANT_15),&(v159_6));
  let v159_8: Space = if has_head(&(v159_7)) { singleton(&[]) } else { Space::new() };
  drop(v159_7);
  let v159_9: Space = subtract(&(*CONSTANT_0),&(v159_8));
  drop(v159_8);
  let v159_14: Space = intersect(&(*CONSTANT_15),&(v159_6));
  drop(v159_6);
  let v159_15: Space = if has_head(&(v159_14)) { singleton(&[]) } else { Space::new() };
  drop(v159_14);
  let mut v159_16 = Space::new();
  let mut v159_16_write = v159_16.write_zipper();
  let mut v159_16_cursor = (*s0).read_zipper();
  let v159_16_origin = v159_16_cursor.path().len();
  for v159_16_byte in v159_16_cursor.child_mask().iter() {
    v159_16_cursor.descend_to_existing_byte(v159_16_byte);
    {
    let v160_4: Space = if (&(v159_9)).is_empty() { Space::new() } else {
      let v161_2: Path = concat_path(&(*p1),&v159_16_cursor.path()[v159_16_origin..(v159_16_origin + 1)]);
      let mut v161_3 = Space::new();
      let mut v161_3_write = v161_3.write_zipper();
      let v161_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v161_3_arg_1: &[u8] = &(v161_2);
      let v161_3_arg_2: &[u8] = &(*p2);
      let v161_3_arg_4: &Space = &(&v159_16_cursor).make_map();
      let mut v161_3_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p0));
      let v161_3_origin = v161_3_cursor.path().len();
      let mut v161_3_more = v161_3_cursor.is_val() || next_value_within(&mut v161_3_cursor,v161_3_origin);
      while v161_3_more {
        {
        let v161_3_depth = v161_3_cursor.path().len();
        let v162_5: Space = routine_19(c, &v161_3_cursor.path()[v161_3_origin..v161_3_depth], &(*v161_3_arg_1), &(*v161_3_arg_2), &((*v161_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v161_3_write,&((v162_5).read_zipper()),&[]);
        }
        v161_3_more = next_value_within(&mut v161_3_cursor,v161_3_origin);
      }
      drop(v161_3_cursor);
      drop(v161_3_write);
      compose(&(v159_9),&(v161_3))
    };
    let v160_5: Space = compose(&(v159_15),&v159_16_cursor);
    let v163_2: Path = concat_path(&(*p1),&v159_16_cursor.path()[v159_16_origin..(v159_16_origin + 1)]);
    let v160_6: Space = wrap(&(v160_5),&(v163_2));
    drop(v160_5);
    let v160_7: Space = wrap(&(v160_6),&(*p2));
    drop(v160_6);
    let v160_8: Space = unite(&(v160_4),&(v160_7));
    drop(v160_7);
    join_wrapped_into(&mut v159_16_write,&((v160_8).read_zipper()),&[]);
    }
    v159_16_cursor.ascend(1);
  }
  drop(v159_16_cursor);
  drop(v159_16_write);
  drop(v159_9);
  drop(v159_15);
  (v159_16).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v164_6: Space = singleton(&(*p0));
  let v164_7: Space = intersect(&(*CONSTANT_15),&(v164_6));
  let v164_8: Space = if has_head(&(v164_7)) { singleton(&[]) } else { Space::new() };
  drop(v164_7);
  let v164_9: Space = subtract(&(*CONSTANT_0),&(v164_8));
  drop(v164_8);
  let v164_14: Space = intersect(&(*CONSTANT_15),&(v164_6));
  drop(v164_6);
  let v164_15: Space = if has_head(&(v164_14)) { singleton(&[]) } else { Space::new() };
  drop(v164_14);
  let mut v164_16 = Space::new();
  let mut v164_16_write = v164_16.write_zipper();
  let mut v164_16_cursor = (*s0).read_zipper();
  let v164_16_origin = v164_16_cursor.path().len();
  for v164_16_byte in v164_16_cursor.child_mask().iter() {
    v164_16_cursor.descend_to_existing_byte(v164_16_byte);
    {
    let v165_4: Space = if (&(v164_9)).is_empty() { Space::new() } else {
      let v166_2: Path = concat_path(&(*p1),&v164_16_cursor.path()[v164_16_origin..(v164_16_origin + 1)]);
      let mut v166_3 = Space::new();
      let mut v166_3_write = v166_3.write_zipper();
      let v166_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v166_3_arg_1: &[u8] = &(v166_2);
      let v166_3_arg_3: &Space = &(&v164_16_cursor).make_map();
      let v166_3_arg_4: &Space = &(&(*s1)).make_map();
      let mut v166_3_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p0));
      let v166_3_origin = v166_3_cursor.path().len();
      let mut v166_3_more = v166_3_cursor.is_val() || next_value_within(&mut v166_3_cursor,v166_3_origin);
      while v166_3_more {
        {
        let v166_3_depth = v166_3_cursor.path().len();
        let v167_5: Space = routine_20(c, &v166_3_cursor.path()[v166_3_origin..v166_3_depth], &(*v166_3_arg_1), &((*v166_3_arg_3).read_zipper()), &((*v166_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v166_3_write,&((v167_5).read_zipper()),&[]);
        }
        v166_3_more = next_value_within(&mut v166_3_cursor,v166_3_origin);
      }
      drop(v166_3_cursor);
      drop(v166_3_write);
      compose(&(v164_9),&(v166_3))
    };
    let v165_6: Space = if (&(v164_15)).is_empty() { Space::new() } else {
      let v168_2: Path = concat_path(&(*p1),&v164_16_cursor.path()[v164_16_origin..(v164_16_origin + 1)]);
      let mut v168_5 = Space::new();
      let mut v168_5_write = v168_5.write_zipper();
      for v168_5_byte in v164_16_cursor.child_mask().iter() {
        v164_16_cursor.descend_to_existing_byte(v168_5_byte);
        {
        let v169_2: Space = routine_9(c, &v164_16_cursor.path()[(v164_16_origin + 1)..(v164_16_origin + 2)], &v164_16_cursor.path()[(v164_16_origin + 1)..(v164_16_origin + 2)], &(v168_2), &v164_16_cursor, &(*s1));
        join_wrapped_into(&mut v168_5_write,&((v169_2).read_zipper()),&[]);
        }
        v164_16_cursor.ascend(1);
      }
      drop(v168_5_write);
      drop(v168_2);
      compose(&(v164_15),&(v168_5))
    };
    let v165_7: Space = unite(&(v165_4),&(v165_6));
    join_wrapped_into(&mut v164_16_write,&((v165_7).read_zipper()),&[]);
    }
    v164_16_cursor.ascend(1);
  }
  drop(v164_16_cursor);
  drop(v164_16_write);
  drop(v164_9);
  drop(v164_15);
  (v164_16).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v170_7: Space = singleton(&(*p0));
  let v170_8: Space = intersect(&(*CONSTANT_15),&(v170_7));
  let v170_9: Space = if has_head(&(v170_8)) { singleton(&[]) } else { Space::new() };
  drop(v170_8);
  let v170_10: Space = subtract(&(*CONSTANT_0),&(v170_9));
  drop(v170_9);
  let v170_15: Space = intersect(&(*CONSTANT_15),&(v170_7));
  drop(v170_7);
  let v170_16: Space = if has_head(&(v170_15)) { singleton(&[]) } else { Space::new() };
  drop(v170_15);
  let mut v170_22 = Space::new();
  let mut v170_22_write = v170_22.write_zipper();
  let mut v170_22_cursor = (*s0).read_zipper();
  let v170_22_origin = v170_22_cursor.path().len();
  for v170_22_byte in v170_22_cursor.child_mask().iter() {
    v170_22_cursor.descend_to_existing_byte(v170_22_byte);
    {
    let v171_4: Space = if (&(v170_10)).is_empty() { Space::new() } else {
      let v172_2: Path = concat_path(&(*p1),&v170_22_cursor.path()[v170_22_origin..(v170_22_origin + 1)]);
      let mut v172_3 = Space::new();
      let mut v172_3_write = v172_3.write_zipper();
      let v172_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v172_3_arg_1: &[u8] = &(v172_2);
      let v172_3_arg_2: &[u8] = &(*p2);
      let v172_3_arg_4: &Space = &(&v170_22_cursor).make_map();
      let v172_3_arg_5: &Space = &(&(*s1)).make_map();
      let mut v172_3_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p0));
      let v172_3_origin = v172_3_cursor.path().len();
      let mut v172_3_more = v172_3_cursor.is_val() || next_value_within(&mut v172_3_cursor,v172_3_origin);
      while v172_3_more {
        {
        let v172_3_depth = v172_3_cursor.path().len();
        let v173_6: Space = routine_21(c, &v172_3_cursor.path()[v172_3_origin..v172_3_depth], &(*v172_3_arg_1), &(*v172_3_arg_2), &((*v172_3_arg_4).read_zipper()), &((*v172_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v172_3_write,&((v173_6).read_zipper()),&[]);
        }
        v172_3_more = next_value_within(&mut v172_3_cursor,v172_3_origin);
      }
      drop(v172_3_cursor);
      drop(v172_3_write);
      drop(v172_2);
      compose(&(v170_10),&(v172_3))
    };
    let v171_7: Space = if (&(v170_16)).is_empty() { Space::new() } else {
      let mut v174_6 = Space::new();
      let mut v174_6_write = v174_6.write_zipper();
      let mut v174_6_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_8)),&(*CONSTANT_10)),&(*p1)),&v170_22_cursor.path()[v170_22_origin..(v170_22_origin + 1)]);
      let v174_6_origin = v174_6_cursor.path().len();
      for v174_6_byte in v174_6_cursor.child_mask().iter() {
        v174_6_cursor.descend_to_existing_byte(v174_6_byte);
        {
        let v175_2: Space = routine_22(c, &v174_6_cursor.path()[v174_6_origin..(v174_6_origin + 1)], &v174_6_cursor.path()[v174_6_origin..(v174_6_origin + 1)], &(*p2), &v174_6_cursor);
        join_wrapped_into(&mut v174_6_write,&((v175_2).read_zipper()),&[]);
        }
        v174_6_cursor.ascend(1);
      }
      drop(v174_6_cursor);
      drop(v174_6_write);
      compose(&(v170_16),&(v174_6))
    };
    let v171_8: Space = unite(&(v171_4),&(v171_7));
    join_wrapped_into(&mut v170_22_write,&((v171_8).read_zipper()),&[]);
    }
    v170_22_cursor.ascend(1);
  }
  drop(v170_22_cursor);
  drop(v170_22_write);
  drop(v170_10);
  drop(v170_16);
  (v170_22).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v176_6: Space = singleton(&(*p1));
  let v176_7: Space = intersect(&(*CONSTANT_15),&(v176_6));
  let v176_8: Space = if has_head(&(v176_7)) { singleton(&[]) } else { Space::new() };
  drop(v176_7);
  let v176_9: Space = subtract(&(*CONSTANT_0),&(v176_8));
  drop(v176_8);
  let v176_20: Space = if (&(v176_9)).is_empty() { Space::new() } else {
    let v177_12: Space = first_matching(&(descend_cursor((*CONSTANT_16).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v177_15: Space = if (&(v177_12)).is_empty() { Space::new() } else {
      let v178_14: Space = routine_26(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v177_12),&(v178_14))
    };
    drop(v177_12);
    let mut v177_18 = Space::new();
    let mut v177_18_write = v177_18.write_zipper();
    let mut v177_18_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p1));
    let v177_18_origin = v177_18_cursor.path().len();
    for v177_18_byte in v177_18_cursor.child_mask().iter() {
      v177_18_cursor.descend_to_existing_byte(v177_18_byte);
      {
      let v179_2_arg_0: &[u8] = &v177_18_cursor.path()[v177_18_origin..(v177_18_origin + 1)];
      let v179_2_arg_1: &[u8] = &(*p0);
      let v179_2_arg_2: &[u8] = &(*p2);
      let v179_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v179_2_more = v177_18_cursor.is_val() || next_value_within(&mut v177_18_cursor,(v177_18_origin + 1));
      while v179_2_more {
        {
        let v179_2_depth = v177_18_cursor.path().len();
        let mut v180_5_cursor = (*v179_2_arg_4).read_zipper();
        let v180_5_origin = v180_5_cursor.path().len();
        for v180_5_byte in v180_5_cursor.child_mask().iter() {
          v180_5_cursor.descend_to_existing_byte(v180_5_byte);
          {
          let v181_2: Path = concat_path(&(*v179_2_arg_1),&v180_5_cursor.path()[v180_5_origin..(v180_5_origin + 1)]);
          let v181_3: Space = routine_22(c, &(v181_2), &v177_18_cursor.path()[v177_18_origin..v179_2_depth], &(*v179_2_arg_2), &v180_5_cursor);
          drop(v181_2);
          join_wrapped_into(&mut v177_18_write,&((v181_3).read_zipper()),&[]);
          }
          v180_5_cursor.ascend(1);
        }
        drop(v180_5_cursor);
        }
        v179_2_more = next_value_within(&mut v177_18_cursor,(v177_18_origin + 1));
      }
      }
      v177_18_cursor.ascend(1);
    }
    drop(v177_18_cursor);
    drop(v177_18_write);
    let v177_19: Space = unite(&(v177_15),&(v177_18));
    compose(&(v176_9),&(v177_19))
  };
  drop(v176_9);
  let v176_22: Space = intersect(&(*CONSTANT_15),&(v176_6));
  drop(v176_6);
  let v176_23: Space = if has_head(&(v176_22)) { singleton(&[]) } else { Space::new() };
  drop(v176_22);
  let v176_24: Space = if (&(v176_23)).is_empty() { Space::new() } else {
    compose(&(v176_23),&(*s0))
  };
  drop(v176_23);
  let v176_25: Space = wrap(&(v176_24),&(*p0));
  drop(v176_24);
  let v176_26: Space = wrap(&(v176_25),&(*p2));
  drop(v176_25);
  let v176_27: Space = unite(&(v176_20),&(v176_26));
  drop(v176_26);
  (v176_27).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v183_5: Space = singleton(&(*p0));
  let v183_6: Space = intersect(&(*CONSTANT_15),&(v183_5));
  let v183_7: Space = if has_head(&(v183_6)) { singleton(&[]) } else { Space::new() };
  drop(v183_6);
  let v183_11: Space = intersect(&(*CONSTANT_15),&(v183_5));
  drop(v183_5);
  let v183_12: Space = if has_head(&(v183_11)) { singleton(&[]) } else { Space::new() };
  drop(v183_11);
  let v183_13: Space = subtract(&(*CONSTANT_0),&(v183_12));
  drop(v183_12);
  let mut v183_17 = Space::new();
  let mut v183_17_write = v183_17.write_zipper();
  let mut v183_17_cursor = (*s0).read_zipper();
  let v183_17_origin = v183_17_cursor.path().len();
  for v183_17_byte in v183_17_cursor.child_mask().iter() {
    v183_17_cursor.descend_to_existing_byte(v183_17_byte);
    {
    let v184_2: Space = compose(&(v183_7),&v183_17_cursor);
    let v185_3: Path = concat_path(&(*p1),&v183_17_cursor.path()[v183_17_origin..(v183_17_origin + 1)]);
    let v184_4: Space = wrap(&(v184_2),&(v185_3));
    drop(v184_2);
    let v184_5: Space = wrap(&(v184_4),&(*p2));
    drop(v184_4);
    let v184_6: Space = wrap(&(v184_5),&(*CONSTANT_10));
    drop(v184_5);
    let v184_8: Space = if (&(v183_13)).is_empty() { Space::new() } else {
      let mut v186_7 = Space::new();
      let mut v186_7_write = v186_7.write_zipper();
      let v186_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v186_7_arg_1: &[u8] = &(v185_3);
      let v186_7_arg_2: &[u8] = &(*p2);
      let v186_7_arg_4: &Space = &(&v183_17_cursor).make_map();
      let mut v186_7_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p0));
      let v186_7_origin = v186_7_cursor.path().len();
      let mut v186_7_more = v186_7_cursor.is_val() || next_value_within(&mut v186_7_cursor,v186_7_origin);
      while v186_7_more {
        {
        let v186_7_depth = v186_7_cursor.path().len();
        let v187_5: Space = routine_23(c, &v186_7_cursor.path()[v186_7_origin..v186_7_depth], &(*v186_7_arg_1), &(*v186_7_arg_2), &((*v186_7_arg_4).read_zipper()));
        join_wrapped_into(&mut v186_7_write,&((v187_5).read_zipper()),&[]);
        }
        v186_7_more = next_value_within(&mut v186_7_cursor,v186_7_origin);
      }
      drop(v186_7_cursor);
      drop(v186_7_write);
      compose(&(v183_13),&(v186_7))
    };
    let v184_9: Space = unite(&(v184_6),&(v184_8));
    drop(v184_6);
    join_wrapped_into(&mut v183_17_write,&((v184_9).read_zipper()),&[]);
    }
    v183_17_cursor.ascend(1);
  }
  drop(v183_17_cursor);
  drop(v183_17_write);
  drop(v183_7);
  drop(v183_13);
  (v183_17).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v188_6: Space = singleton(&(*p0));
  let v188_7: Space = intersect(&(*CONSTANT_15),&(v188_6));
  let v188_8: Space = if has_head(&(v188_7)) { singleton(&[]) } else { Space::new() };
  drop(v188_7);
  let v188_9: Space = subtract(&(*CONSTANT_0),&(v188_8));
  drop(v188_8);
  let v188_14: Space = intersect(&(*CONSTANT_15),&(v188_6));
  drop(v188_6);
  let v188_15: Space = if has_head(&(v188_14)) { singleton(&[]) } else { Space::new() };
  drop(v188_14);
  let mut v188_16 = Space::new();
  let mut v188_16_write = v188_16.write_zipper();
  let mut v188_16_cursor = (*s0).read_zipper();
  let v188_16_origin = v188_16_cursor.path().len();
  for v188_16_byte in v188_16_cursor.child_mask().iter() {
    v188_16_cursor.descend_to_existing_byte(v188_16_byte);
    {
    let v189_4: Space = if (&(v188_9)).is_empty() { Space::new() } else {
      let v190_2: Path = concat_path(&(*p1),&v188_16_cursor.path()[v188_16_origin..(v188_16_origin + 1)]);
      let mut v190_3 = Space::new();
      let mut v190_3_write = v190_3.write_zipper();
      let v190_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v190_3_arg_1: &[u8] = &(v190_2);
      let v190_3_arg_2: &[u8] = &(*p2);
      let v190_3_arg_4: &Space = &(&v188_16_cursor).make_map();
      let mut v190_3_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p0));
      let v190_3_origin = v190_3_cursor.path().len();
      let mut v190_3_more = v190_3_cursor.is_val() || next_value_within(&mut v190_3_cursor,v190_3_origin);
      while v190_3_more {
        {
        let v190_3_depth = v190_3_cursor.path().len();
        let v191_5: Space = routine_24(c, &v190_3_cursor.path()[v190_3_origin..v190_3_depth], &(*v190_3_arg_1), &(*v190_3_arg_2), &((*v190_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v190_3_write,&((v191_5).read_zipper()),&[]);
        }
        v190_3_more = next_value_within(&mut v190_3_cursor,v190_3_origin);
      }
      drop(v190_3_cursor);
      drop(v190_3_write);
      compose(&(v188_9),&(v190_3))
    };
    let v189_5: Space = compose(&(v188_15),&v188_16_cursor);
    let v192_2: Path = concat_path(&(*p1),&v188_16_cursor.path()[v188_16_origin..(v188_16_origin + 1)]);
    let v189_6: Space = wrap(&(v189_5),&(v192_2));
    drop(v189_5);
    let v189_7: Space = wrap(&(v189_6),&(*p2));
    drop(v189_6);
    let v189_8: Space = unite(&(v189_4),&(v189_7));
    drop(v189_7);
    join_wrapped_into(&mut v188_16_write,&((v189_8).read_zipper()),&[]);
    }
    v188_16_cursor.ascend(1);
  }
  drop(v188_16_cursor);
  drop(v188_16_write);
  drop(v188_9);
  drop(v188_15);
  (v188_16).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v193_6: Space = singleton(&(*p0));
  let v193_7: Space = intersect(&(*CONSTANT_15),&(v193_6));
  let v193_8: Space = if has_head(&(v193_7)) { singleton(&[]) } else { Space::new() };
  drop(v193_7);
  let v193_9: Space = subtract(&(*CONSTANT_0),&(v193_8));
  drop(v193_8);
  let v193_14: Space = intersect(&(*CONSTANT_15),&(v193_6));
  drop(v193_6);
  let v193_15: Space = if has_head(&(v193_14)) { singleton(&[]) } else { Space::new() };
  drop(v193_14);
  let mut v193_16 = Space::new();
  let mut v193_16_write = v193_16.write_zipper();
  let mut v193_16_cursor = (*s0).read_zipper();
  let v193_16_origin = v193_16_cursor.path().len();
  for v193_16_byte in v193_16_cursor.child_mask().iter() {
    v193_16_cursor.descend_to_existing_byte(v193_16_byte);
    {
    let v194_4: Space = if (&(v193_9)).is_empty() { Space::new() } else {
      let v195_2: Path = concat_path(&(*p1),&v193_16_cursor.path()[v193_16_origin..(v193_16_origin + 1)]);
      let mut v195_3 = Space::new();
      let mut v195_3_write = v195_3.write_zipper();
      let v195_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v195_3_arg_1: &[u8] = &(v195_2);
      let v195_3_arg_2: &[u8] = &(*p2);
      let v195_3_arg_4: &Space = &(&v193_16_cursor).make_map();
      let mut v195_3_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p0));
      let v195_3_origin = v195_3_cursor.path().len();
      let mut v195_3_more = v195_3_cursor.is_val() || next_value_within(&mut v195_3_cursor,v195_3_origin);
      while v195_3_more {
        {
        let v195_3_depth = v195_3_cursor.path().len();
        let v196_5: Space = routine_25(c, &v195_3_cursor.path()[v195_3_origin..v195_3_depth], &(*v195_3_arg_1), &(*v195_3_arg_2), &((*v195_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v195_3_write,&((v196_5).read_zipper()),&[]);
        }
        v195_3_more = next_value_within(&mut v195_3_cursor,v195_3_origin);
      }
      drop(v195_3_cursor);
      drop(v195_3_write);
      compose(&(v193_9),&(v195_3))
    };
    let v194_5: Space = compose(&(v193_15),&v193_16_cursor);
    let v197_2: Path = concat_path(&(*p1),&v193_16_cursor.path()[v193_16_origin..(v193_16_origin + 1)]);
    let v194_6: Space = wrap(&(v194_5),&(v197_2));
    drop(v194_5);
    let v194_7: Space = wrap(&(v194_6),&(*p2));
    drop(v194_6);
    let v194_8: Space = unite(&(v194_4),&(v194_7));
    drop(v194_7);
    join_wrapped_into(&mut v193_16_write,&((v194_8).read_zipper()),&[]);
    }
    v193_16_cursor.ascend(1);
  }
  drop(v193_16_cursor);
  drop(v193_16_write);
  drop(v193_9);
  drop(v193_15);
  (v193_16).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v198_6: Space = singleton(&(*p0));
  let v198_7: Space = intersect(&(*CONSTANT_15),&(v198_6));
  let v198_8: Space = if has_head(&(v198_7)) { singleton(&[]) } else { Space::new() };
  drop(v198_7);
  let v198_9: Space = subtract(&(*CONSTANT_0),&(v198_8));
  drop(v198_8);
  let v198_14: Space = intersect(&(*CONSTANT_15),&(v198_6));
  drop(v198_6);
  let v198_15: Space = if has_head(&(v198_14)) { singleton(&[]) } else { Space::new() };
  drop(v198_14);
  let mut v198_16 = Space::new();
  let mut v198_16_write = v198_16.write_zipper();
  let mut v198_16_cursor = (*s0).read_zipper();
  let v198_16_origin = v198_16_cursor.path().len();
  for v198_16_byte in v198_16_cursor.child_mask().iter() {
    v198_16_cursor.descend_to_existing_byte(v198_16_byte);
    {
    let v199_4: Space = if (&(v198_9)).is_empty() { Space::new() } else {
      let v200_2: Path = concat_path(&(*p1),&v198_16_cursor.path()[v198_16_origin..(v198_16_origin + 1)]);
      let mut v200_3 = Space::new();
      let mut v200_3_write = v200_3.write_zipper();
      let v200_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v200_3_arg_1: &[u8] = &(v200_2);
      let v200_3_arg_2: &[u8] = &(*p2);
      let v200_3_arg_4: &Space = &(&v198_16_cursor).make_map();
      let mut v200_3_cursor = descend_cursor((*CONSTANT_16).read_zipper(),&(*p0));
      let v200_3_origin = v200_3_cursor.path().len();
      let mut v200_3_more = v200_3_cursor.is_val() || next_value_within(&mut v200_3_cursor,v200_3_origin);
      while v200_3_more {
        {
        let v200_3_depth = v200_3_cursor.path().len();
        let v201_5: Space = routine_26(c, &v200_3_cursor.path()[v200_3_origin..v200_3_depth], &(*v200_3_arg_1), &(*v200_3_arg_2), &((*v200_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v200_3_write,&((v201_5).read_zipper()),&[]);
        }
        v200_3_more = next_value_within(&mut v200_3_cursor,v200_3_origin);
      }
      drop(v200_3_cursor);
      drop(v200_3_write);
      compose(&(v198_9),&(v200_3))
    };
    let v199_5: Space = compose(&(v198_15),&v198_16_cursor);
    let v202_2: Path = concat_path(&(*p1),&v198_16_cursor.path()[v198_16_origin..(v198_16_origin + 1)]);
    let v199_6: Space = wrap(&(v199_5),&(v202_2));
    drop(v199_5);
    let v199_7: Space = wrap(&(v199_6),&(*p2));
    drop(v199_6);
    let v199_8: Space = unite(&(v199_4),&(v199_7));
    drop(v199_7);
    join_wrapped_into(&mut v198_16_write,&((v199_8).read_zipper()),&[]);
    }
    v198_16_cursor.ascend(1);
  }
  drop(v198_16_cursor);
  drop(v198_16_write);
  drop(v198_9);
  drop(v198_15);
  (v198_16).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
