#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,48]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 110 49 0 4 0 110 50 0"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,49]));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("22 4 0 110 50 0 4 0 110 51 0 6 48 0 110 49 49 0 6 48 0 110 49 50 0 6 49 0 110 49 50 0 6 49 0 110 49 51 0 6 50 0 110 49 51 0 6 50 0 110 49 52 0 6 51 0 110 49 52 0 6 51 0 110 49 53 0 6 52 0 110 49 53 0 6 52 0 110 49 54 0 6 53 0 110 49 54 0 6 53 0 110 49 55 0 6 54 0 110 49 55 0 6 54 0 110 49 56 0 6 55 0 110 49 56 0 6 55 0 110 49 57 0 6 56 0 110 49 57 0 6 56 0 110 50 48 0 6 57 0 110 50 48 0 6 57 0 110 50 49 0"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,50]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("9 4 0 110 51 0 4 0 110 52 0 6 48 0 110 50 49 0 6 48 0 110 50 50 0 6 49 0 110 50 50 0 6 49 0 110 50 51 0 6 50 0 110 50 51 0 6 50 0 110 50 52 0 6 51 0 110 50 52 0"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,51]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 110 52 0 4 0 110 53 0"));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,52]));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 110 53 0 4 0 110 54 0"));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,53]));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 110 54 0 4 0 110 55 0"));
static CONSTANT_13: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,54]));
static CONSTANT_14: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 110 55 0 4 0 110 56 0"));
static CONSTANT_15: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,55]));
static CONSTANT_16: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 110 56 0 4 0 110 57 0"));
static CONSTANT_17: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,56]));
static CONSTANT_18: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 5 0 110 49 48 0 4 0 110 57 0"));
static CONSTANT_19: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,57]));
static CONSTANT_20: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 5 0 110 49 48 0 5 0 110 49 49 0"));
static CONSTANT_21: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[100,101,108,116,97,0]));
static CONSTANT_22: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("47 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 48 0 110 49 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 48 0 110 50 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 0 110 50 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 0 110 51 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 48 0 110 49 49 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 48 0 110 49 50 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 49 0 110 49 50 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 49 0 110 49 51 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 50 0 110 49 51 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 50 0 110 49 52 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 51 0 110 49 52 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 51 0 110 49 53 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 52 0 110 49 53 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 52 0 110 49 54 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 53 0 110 49 54 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 53 0 110 49 55 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 54 0 110 49 55 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 54 0 110 49 56 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 55 0 110 49 56 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 55 0 110 49 57 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 56 0 110 49 57 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 56 0 110 50 48 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 57 0 110 50 48 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 57 0 110 50 49 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 50 0 110 51 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 50 0 110 52 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 50 48 0 110 50 49 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 50 48 0 110 50 50 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 50 49 0 110 50 50 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 50 49 0 110 50 51 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 50 50 0 110 50 51 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 50 50 0 110 50 52 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 50 51 0 110 50 52 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 51 0 110 52 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 51 0 110 53 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 52 0 110 53 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 52 0 110 54 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 53 0 110 54 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 53 0 110 55 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 54 0 110 55 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 54 0 110 56 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 55 0 110 56 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 55 0 110 57 0 21 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 56 0 110 49 48 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 56 0 110 57 0 21 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 57 0 110 49 48 0 21 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 57 0 110 49 49 0"));
static CONSTANT_23: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[99,111,109,112,108,101,116,101,0]));
static CONSTANT_24: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[101,100,103,101,0]));
static CONSTANT_25: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[112,97,116,104,0]));
static CONSTANT_26: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[99,111,109,112,108,101,116,101,0,112,97,116,104,0]));
static CONSTANT_27: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[100,101,108,116,97,0,112,97,116,104,0]));
static CONSTANT_28: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
#[inline(never)]
fn native_block_0(c: &mut Context,capture_0: &Space) -> (Space,Space,Space,Space,Space,Space,Space,) {
    let v3_3: Space = unite(&(descend_cursor(((*capture_0)).read_zipper(),&(*CONSTANT_23))),&(descend_cursor(((*capture_0)).read_zipper(),&(*CONSTANT_21))));
    let v3_4: Space = wrap(&(v3_3),&(*CONSTANT_23));
    drop(v3_3);
    let mut v3_6 = Space::new();
    let mut v3_6_write = v3_6.write_zipper();
    let mut v3_6_cursor = descend_cursor(descend_cursor(((*capture_0)).read_zipper(),&(*CONSTANT_23)),&(*CONSTANT_24));
    let v3_6_origin = v3_6_cursor.path().len();
    for v3_6_byte in v3_6_cursor.child_mask().iter() {
      v3_6_cursor.descend_to_existing_byte(v3_6_byte);
      {
      let v4_2: Space = singleton(&v3_6_cursor.path()[v3_6_origin..(v3_6_origin + 1)]);
      let v4_3: Space = intersect(&(*CONSTANT_28),&(v4_2));
      let v4_4: Space = if has_head(&(v4_3)) { singleton(&[]) } else { Space::new() };
      drop(v4_3);
      let v4_5: Space = subtract(&(*CONSTANT_0),&(v4_4));
      drop(v4_4);
      let v4_7: Space = if (&(v4_5)).is_empty() { Space::new() } else {
        let mut v5_6 = Space::new();
        let mut v5_6_write = v5_6.write_zipper();
        for v5_6_byte in v3_6_cursor.child_mask().iter() {
          v3_6_cursor.descend_to_existing_byte(v5_6_byte);
          {
          let v6_2: Space = singleton(&v3_6_cursor.path()[(v3_6_origin + 1)..(v3_6_origin + 2)]);
          let v6_3: Space = intersect(&(*CONSTANT_28),&(v6_2));
          let v6_4: Space = if has_head(&(v6_3)) { singleton(&[]) } else { Space::new() };
          drop(v6_3);
          let v6_5: Space = subtract(&(*CONSTANT_0),&(v6_4));
          drop(v6_4);
          let v6_8: Space = if (&(v6_5)).is_empty() { Space::new() } else {
            let v7_7: Space = routine_2(c, &v3_6_cursor.path()[v3_6_origin..(v3_6_origin + 2)], &v3_6_cursor);
            compose(&(v6_5),&(v7_7))
          };
          drop(v6_5);
          let v6_9: Space = intersect(&(*CONSTANT_28),&(v6_2));
          drop(v6_2);
          let v6_10: Space = if has_head(&(v6_9)) { singleton(&[]) } else { Space::new() };
          drop(v6_9);
          let v6_12: Space = if (&(v6_10)).is_empty() { Space::new() } else {
            let mut v8_11 = Space::new();
            let mut v8_11_write = v8_11.write_zipper();
            for v8_11_byte in v3_6_cursor.child_mask().iter() {
              v3_6_cursor.descend_to_existing_byte(v8_11_byte);
              {
              let v9_2: Space = singleton(&v3_6_cursor.path()[(v3_6_origin + 2)..(v3_6_origin + 3)]);
              let v9_3: Space = intersect(&(*CONSTANT_28),&(v9_2));
              let v9_4: Space = if has_head(&(v9_3)) { singleton(&[]) } else { Space::new() };
              drop(v9_3);
              let v9_5: Space = subtract(&(*CONSTANT_0),&(v9_4));
              drop(v9_4);
              let v9_7: Space = if (&(v9_5)).is_empty() { Space::new() } else {
                let v10_6: Space = routine_3(c, &v3_6_cursor.path()[(v3_6_origin + 2)..(v3_6_origin + 3)], &v3_6_cursor.path()[v3_6_origin..(v3_6_origin + 2)], &v3_6_cursor);
                compose(&(v9_5),&(v10_6))
              };
              drop(v9_5);
              let v9_8: Space = intersect(&(*CONSTANT_28),&(v9_2));
              drop(v9_2);
              let v9_9: Space = if has_head(&(v9_8)) { singleton(&[]) } else { Space::new() };
              drop(v9_8);
              let v9_11: Space = if (&(v9_9)).is_empty() { Space::new() } else {
                let v11_10: Space = routine_4(c, &v3_6_cursor.path()[(v3_6_origin + 2)..(v3_6_origin + 3)], &v3_6_cursor.path()[v3_6_origin..(v3_6_origin + 2)], &v3_6_cursor);
                compose(&(v9_9),&(v11_10))
              };
              drop(v9_9);
              let v9_12: Space = unite(&(v9_7),&(v9_11));
              join_wrapped_into(&mut v8_11_write,&((v9_12).read_zipper()),&[]);
              }
              v3_6_cursor.ascend(1);
            }
            drop(v8_11_write);
            compose(&(v6_10),&(v8_11))
          };
          drop(v6_10);
          let v6_13: Space = unite(&(v6_8),&(v6_12));
          join_wrapped_into(&mut v5_6_write,&((v6_13).read_zipper()),&[]);
          }
          v3_6_cursor.ascend(1);
        }
        drop(v5_6_write);
        compose(&(v4_5),&(v5_6))
      };
      drop(v4_5);
      let v4_8: Space = intersect(&(*CONSTANT_28),&(v4_2));
      drop(v4_2);
      let v4_9: Space = if has_head(&(v4_8)) { singleton(&[]) } else { Space::new() };
      drop(v4_8);
      let v4_11: Space = if (&(v4_9)).is_empty() { Space::new() } else {
        let mut v12_10 = Space::new();
        let mut v12_10_write = v12_10.write_zipper();
        for v12_10_byte in v3_6_cursor.child_mask().iter() {
          v3_6_cursor.descend_to_existing_byte(v12_10_byte);
          {
          let v13_2: Space = singleton(&v3_6_cursor.path()[(v3_6_origin + 1)..(v3_6_origin + 2)]);
          let v13_3: Space = intersect(&(*CONSTANT_28),&(v13_2));
          let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
          drop(v13_3);
          let v13_5: Space = subtract(&(*CONSTANT_0),&(v13_4));
          drop(v13_4);
          let v13_7: Space = if (&(v13_5)).is_empty() { Space::new() } else {
            let v14_6: Space = routine_3(c, &v3_6_cursor.path()[(v3_6_origin + 1)..(v3_6_origin + 2)], &v3_6_cursor.path()[v3_6_origin..(v3_6_origin + 1)], &v3_6_cursor);
            compose(&(v13_5),&(v14_6))
          };
          drop(v13_5);
          let v13_8: Space = intersect(&(*CONSTANT_28),&(v13_2));
          drop(v13_2);
          let v13_9: Space = if has_head(&(v13_8)) { singleton(&[]) } else { Space::new() };
          drop(v13_8);
          let v13_10: Space = compose(&(v13_9),&v3_6_cursor);
          drop(v13_9);
          let v13_11: Space = wrap(&(v13_10),&v3_6_cursor.path()[(v3_6_origin + 1)..(v3_6_origin + 2)]);
          drop(v13_10);
          let v13_12: Space = wrap(&(v13_11),&v3_6_cursor.path()[v3_6_origin..(v3_6_origin + 1)]);
          drop(v13_11);
          let v13_13: Space = unite(&(v13_7),&(v13_12));
          drop(v13_12);
          join_wrapped_into(&mut v12_10_write,&((v13_13).read_zipper()),&[]);
          }
          v3_6_cursor.ascend(1);
        }
        drop(v12_10_write);
        compose(&(v4_9),&(v12_10))
      };
      drop(v4_9);
      let v4_12: Space = unite(&(v4_7),&(v4_11));
      join_wrapped_into(&mut v3_6_write,&((v4_12).read_zipper()),&[]);
      }
      v3_6_cursor.ascend(1);
    }
    drop(v3_6_cursor);
    drop(v3_6_write);
    let mut v3_9 = Space::new();
    let mut v3_9_write = v3_9.write_zipper();
    let mut v3_9_cursor = descend_cursor(descend_cursor(((*capture_0)).read_zipper(),&(*CONSTANT_23)),&(*CONSTANT_25));
    let v3_9_origin = v3_9_cursor.path().len();
    for v3_9_byte in v3_9_cursor.child_mask().iter() {
      v3_9_cursor.descend_to_existing_byte(v3_9_byte);
      {
      let v15_2: Space = singleton(&v3_9_cursor.path()[v3_9_origin..(v3_9_origin + 1)]);
      let v15_3: Space = intersect(&(*CONSTANT_28),&(v15_2));
      let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
      drop(v15_3);
      let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
      drop(v15_4);
      let v15_7: Space = if (&(v15_5)).is_empty() { Space::new() } else {
        let mut v16_6 = Space::new();
        let mut v16_6_write = v16_6.write_zipper();
        for v16_6_byte in v3_9_cursor.child_mask().iter() {
          v3_9_cursor.descend_to_existing_byte(v16_6_byte);
          {
          let v17_2: Space = singleton(&v3_9_cursor.path()[(v3_9_origin + 1)..(v3_9_origin + 2)]);
          let v17_3: Space = intersect(&(*CONSTANT_28),&(v17_2));
          let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
          drop(v17_3);
          let v17_5: Space = subtract(&(*CONSTANT_0),&(v17_4));
          drop(v17_4);
          let v17_8: Space = if (&(v17_5)).is_empty() { Space::new() } else {
            let v18_7: Space = routine_5(c, &v3_9_cursor.path()[v3_9_origin..(v3_9_origin + 2)], &v3_9_cursor, &(((*capture_0)).read_zipper()));
            compose(&(v17_5),&(v18_7))
          };
          drop(v17_5);
          let v17_9: Space = intersect(&(*CONSTANT_28),&(v17_2));
          drop(v17_2);
          let v17_10: Space = if has_head(&(v17_9)) { singleton(&[]) } else { Space::new() };
          drop(v17_9);
          let v17_12: Space = if (&(v17_10)).is_empty() { Space::new() } else {
            let mut v19_11 = Space::new();
            let mut v19_11_write = v19_11.write_zipper();
            for v19_11_byte in v3_9_cursor.child_mask().iter() {
              v3_9_cursor.descend_to_existing_byte(v19_11_byte);
              {
              let v20_2: Space = singleton(&v3_9_cursor.path()[(v3_9_origin + 2)..(v3_9_origin + 3)]);
              let v20_3: Space = intersect(&(*CONSTANT_28),&(v20_2));
              let v20_4: Space = if has_head(&(v20_3)) { singleton(&[]) } else { Space::new() };
              drop(v20_3);
              let v20_5: Space = subtract(&(*CONSTANT_0),&(v20_4));
              drop(v20_4);
              let v20_7: Space = if (&(v20_5)).is_empty() { Space::new() } else {
                let v21_6: Space = routine_6(c, &v3_9_cursor.path()[(v3_9_origin + 2)..(v3_9_origin + 3)], &v3_9_cursor.path()[v3_9_origin..(v3_9_origin + 2)], &v3_9_cursor, &(((*capture_0)).read_zipper()));
                compose(&(v20_5),&(v21_6))
              };
              drop(v20_5);
              let v20_8: Space = intersect(&(*CONSTANT_28),&(v20_2));
              drop(v20_2);
              let v20_9: Space = if has_head(&(v20_8)) { singleton(&[]) } else { Space::new() };
              drop(v20_8);
              let v20_11: Space = if (&(v20_9)).is_empty() { Space::new() } else {
                let v22_10: Space = routine_7(c, &v3_9_cursor.path()[(v3_9_origin + 2)..(v3_9_origin + 3)], &v3_9_cursor.path()[v3_9_origin..(v3_9_origin + 2)], &v3_9_cursor, &(((*capture_0)).read_zipper()));
                compose(&(v20_9),&(v22_10))
              };
              drop(v20_9);
              let v20_12: Space = unite(&(v20_7),&(v20_11));
              join_wrapped_into(&mut v19_11_write,&((v20_12).read_zipper()),&[]);
              }
              v3_9_cursor.ascend(1);
            }
            drop(v19_11_write);
            compose(&(v17_10),&(v19_11))
          };
          drop(v17_10);
          let v17_13: Space = unite(&(v17_8),&(v17_12));
          join_wrapped_into(&mut v16_6_write,&((v17_13).read_zipper()),&[]);
          }
          v3_9_cursor.ascend(1);
        }
        drop(v16_6_write);
        compose(&(v15_5),&(v16_6))
      };
      drop(v15_5);
      let v15_8: Space = intersect(&(*CONSTANT_28),&(v15_2));
      drop(v15_2);
      let v15_9: Space = if has_head(&(v15_8)) { singleton(&[]) } else { Space::new() };
      drop(v15_8);
      let v15_11: Space = if (&(v15_9)).is_empty() { Space::new() } else {
        let mut v23_10 = Space::new();
        let mut v23_10_write = v23_10.write_zipper();
        for v23_10_byte in v3_9_cursor.child_mask().iter() {
          v3_9_cursor.descend_to_existing_byte(v23_10_byte);
          {
          let v24_2: Space = singleton(&v3_9_cursor.path()[(v3_9_origin + 1)..(v3_9_origin + 2)]);
          let v24_3: Space = intersect(&(*CONSTANT_28),&(v24_2));
          let v24_4: Space = if has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
          drop(v24_3);
          let v24_5: Space = subtract(&(*CONSTANT_0),&(v24_4));
          drop(v24_4);
          let v24_7: Space = if (&(v24_5)).is_empty() { Space::new() } else {
            let v25_6: Space = routine_6(c, &v3_9_cursor.path()[(v3_9_origin + 1)..(v3_9_origin + 2)], &v3_9_cursor.path()[v3_9_origin..(v3_9_origin + 1)], &v3_9_cursor, &(((*capture_0)).read_zipper()));
            compose(&(v24_5),&(v25_6))
          };
          drop(v24_5);
          let v24_8: Space = intersect(&(*CONSTANT_28),&(v24_2));
          drop(v24_2);
          let v24_9: Space = if has_head(&(v24_8)) { singleton(&[]) } else { Space::new() };
          drop(v24_8);
          let v24_12: Space = if (&(v24_9)).is_empty() { Space::new() } else {
            let mut v26_11 = Space::new();
            let mut v26_11_write = v26_11.write_zipper();
            let mut v26_11_cursor = descend_cursor(descend_cursor(descend_cursor(((*capture_0)).read_zipper(),&(*CONSTANT_21)),&(*CONSTANT_25)),&v3_9_cursor.path()[(v3_9_origin + 1)..(v3_9_origin + 2)]);
            let v26_11_origin = v26_11_cursor.path().len();
            for v26_11_byte in v26_11_cursor.child_mask().iter() {
              v26_11_cursor.descend_to_existing_byte(v26_11_byte);
              {
              let v27_2: Space = singleton(&v26_11_cursor.path()[v26_11_origin..(v26_11_origin + 1)]);
              let v27_3: Space = intersect(&(*CONSTANT_28),&(v27_2));
              let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
              drop(v27_3);
              let v27_5: Space = subtract(&(*CONSTANT_0),&(v27_4));
              drop(v27_4);
              let v27_7: Space = if (&(v27_5)).is_empty() { Space::new() } else {
                let v28_6: Space = routine_8(c, &v26_11_cursor.path()[v26_11_origin..(v26_11_origin + 1)], &v3_9_cursor.path()[v3_9_origin..(v3_9_origin + 1)], &v26_11_cursor);
                compose(&(v27_5),&(v28_6))
              };
              drop(v27_5);
              let v27_8: Space = intersect(&(*CONSTANT_28),&(v27_2));
              drop(v27_2);
              let v27_9: Space = if has_head(&(v27_8)) { singleton(&[]) } else { Space::new() };
              drop(v27_8);
              let v27_11: Space = if (&(v27_9)).is_empty() { Space::new() } else {
                let v29_10: Space = routine_9(c, &v26_11_cursor.path()[v26_11_origin..(v26_11_origin + 1)], &v3_9_cursor.path()[v3_9_origin..(v3_9_origin + 1)], &v26_11_cursor);
                compose(&(v27_9),&(v29_10))
              };
              drop(v27_9);
              let v27_12: Space = unite(&(v27_7),&(v27_11));
              join_wrapped_into(&mut v26_11_write,&((v27_12).read_zipper()),&[]);
              }
              v26_11_cursor.ascend(1);
            }
            drop(v26_11_cursor);
            drop(v26_11_write);
            compose(&(v24_9),&(v26_11))
          };
          drop(v24_9);
          let v24_13: Space = unite(&(v24_7),&(v24_12));
          join_wrapped_into(&mut v23_10_write,&((v24_13).read_zipper()),&[]);
          }
          v3_9_cursor.ascend(1);
        }
        drop(v23_10_write);
        compose(&(v15_9),&(v23_10))
      };
      drop(v15_9);
      let v15_12: Space = unite(&(v15_7),&(v15_11));
      join_wrapped_into(&mut v3_9_write,&((v15_12).read_zipper()),&[]);
      }
      v3_9_cursor.ascend(1);
    }
    drop(v3_9_cursor);
    drop(v3_9_write);
    let v3_10: Space = unite(&(v3_6),&(v3_9));
    let mut v3_11 = Space::new();
    let mut v3_11_write = v3_11.write_zipper();
    let mut v3_11_cursor = descend_cursor(descend_cursor(((*capture_0)).read_zipper(),&(*CONSTANT_21)),&(*CONSTANT_25));
    let v3_11_origin = v3_11_cursor.path().len();
    for v3_11_byte in v3_11_cursor.child_mask().iter() {
      v3_11_cursor.descend_to_existing_byte(v3_11_byte);
      {
      let v30_2: Space = singleton(&v3_11_cursor.path()[v3_11_origin..(v3_11_origin + 1)]);
      let v30_3: Space = intersect(&(*CONSTANT_28),&(v30_2));
      let v30_4: Space = if has_head(&(v30_3)) { singleton(&[]) } else { Space::new() };
      drop(v30_3);
      let v30_5: Space = subtract(&(*CONSTANT_0),&(v30_4));
      drop(v30_4);
      let v30_7: Space = if (&(v30_5)).is_empty() { Space::new() } else {
        let mut v31_6 = Space::new();
        let mut v31_6_write = v31_6.write_zipper();
        for v31_6_byte in v3_11_cursor.child_mask().iter() {
          v3_11_cursor.descend_to_existing_byte(v31_6_byte);
          {
          let v32_2: Space = singleton(&v3_11_cursor.path()[(v3_11_origin + 1)..(v3_11_origin + 2)]);
          let v32_3: Space = intersect(&(*CONSTANT_28),&(v32_2));
          let v32_4: Space = if has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
          drop(v32_3);
          let v32_5: Space = subtract(&(*CONSTANT_0),&(v32_4));
          drop(v32_4);
          let v32_8: Space = if (&(v32_5)).is_empty() { Space::new() } else {
            let v33_7: Space = routine_10(c, &v3_11_cursor.path()[v3_11_origin..(v3_11_origin + 2)], &v3_11_cursor, &(((*capture_0)).read_zipper()));
            compose(&(v32_5),&(v33_7))
          };
          drop(v32_5);
          let v32_9: Space = intersect(&(*CONSTANT_28),&(v32_2));
          drop(v32_2);
          let v32_10: Space = if has_head(&(v32_9)) { singleton(&[]) } else { Space::new() };
          drop(v32_9);
          let v32_12: Space = if (&(v32_10)).is_empty() { Space::new() } else {
            let mut v34_11 = Space::new();
            let mut v34_11_write = v34_11.write_zipper();
            for v34_11_byte in v3_11_cursor.child_mask().iter() {
              v3_11_cursor.descend_to_existing_byte(v34_11_byte);
              {
              let v35_2: Space = singleton(&v3_11_cursor.path()[(v3_11_origin + 2)..(v3_11_origin + 3)]);
              let v35_3: Space = intersect(&(*CONSTANT_28),&(v35_2));
              let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
              drop(v35_3);
              let v35_5: Space = subtract(&(*CONSTANT_0),&(v35_4));
              drop(v35_4);
              let v35_7: Space = if (&(v35_5)).is_empty() { Space::new() } else {
                let v36_6: Space = routine_11(c, &v3_11_cursor.path()[(v3_11_origin + 2)..(v3_11_origin + 3)], &v3_11_cursor.path()[v3_11_origin..(v3_11_origin + 2)], &v3_11_cursor, &(((*capture_0)).read_zipper()));
                compose(&(v35_5),&(v36_6))
              };
              drop(v35_5);
              let v35_8: Space = intersect(&(*CONSTANT_28),&(v35_2));
              drop(v35_2);
              let v35_9: Space = if has_head(&(v35_8)) { singleton(&[]) } else { Space::new() };
              drop(v35_8);
              let v35_11: Space = if (&(v35_9)).is_empty() { Space::new() } else {
                let v37_10: Space = routine_12(c, &v3_11_cursor.path()[(v3_11_origin + 2)..(v3_11_origin + 3)], &v3_11_cursor.path()[v3_11_origin..(v3_11_origin + 2)], &v3_11_cursor, &(((*capture_0)).read_zipper()));
                compose(&(v35_9),&(v37_10))
              };
              drop(v35_9);
              let v35_12: Space = unite(&(v35_7),&(v35_11));
              join_wrapped_into(&mut v34_11_write,&((v35_12).read_zipper()),&[]);
              }
              v3_11_cursor.ascend(1);
            }
            drop(v34_11_write);
            compose(&(v32_10),&(v34_11))
          };
          drop(v32_10);
          let v32_13: Space = unite(&(v32_8),&(v32_12));
          join_wrapped_into(&mut v31_6_write,&((v32_13).read_zipper()),&[]);
          }
          v3_11_cursor.ascend(1);
        }
        drop(v31_6_write);
        compose(&(v30_5),&(v31_6))
      };
      drop(v30_5);
      let v30_8: Space = intersect(&(*CONSTANT_28),&(v30_2));
      drop(v30_2);
      let v30_9: Space = if has_head(&(v30_8)) { singleton(&[]) } else { Space::new() };
      drop(v30_8);
      let v30_11: Space = if (&(v30_9)).is_empty() { Space::new() } else {
        let mut v38_10 = Space::new();
        let mut v38_10_write = v38_10.write_zipper();
        for v38_10_byte in v3_11_cursor.child_mask().iter() {
          v3_11_cursor.descend_to_existing_byte(v38_10_byte);
          {
          let v39_2: Space = singleton(&v3_11_cursor.path()[(v3_11_origin + 1)..(v3_11_origin + 2)]);
          let v39_3: Space = intersect(&(*CONSTANT_28),&(v39_2));
          let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
          drop(v39_3);
          let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
          drop(v39_4);
          let v39_7: Space = if (&(v39_5)).is_empty() { Space::new() } else {
            let v40_6: Space = routine_11(c, &v3_11_cursor.path()[(v3_11_origin + 1)..(v3_11_origin + 2)], &v3_11_cursor.path()[v3_11_origin..(v3_11_origin + 1)], &v3_11_cursor, &(((*capture_0)).read_zipper()));
            compose(&(v39_5),&(v40_6))
          };
          drop(v39_5);
          let v39_8: Space = intersect(&(*CONSTANT_28),&(v39_2));
          drop(v39_2);
          let v39_9: Space = if has_head(&(v39_8)) { singleton(&[]) } else { Space::new() };
          drop(v39_8);
          let v39_12: Space = if (&(v39_9)).is_empty() { Space::new() } else {
            let mut v41_11 = Space::new();
            let mut v41_11_write = v41_11.write_zipper();
            let mut v41_11_cursor = descend_cursor(descend_cursor(descend_cursor(((*capture_0)).read_zipper(),&(*CONSTANT_23)),&(*CONSTANT_25)),&v3_11_cursor.path()[(v3_11_origin + 1)..(v3_11_origin + 2)]);
            let v41_11_origin = v41_11_cursor.path().len();
            for v41_11_byte in v41_11_cursor.child_mask().iter() {
              v41_11_cursor.descend_to_existing_byte(v41_11_byte);
              {
              let v42_2: Space = singleton(&v41_11_cursor.path()[v41_11_origin..(v41_11_origin + 1)]);
              let v42_3: Space = intersect(&(*CONSTANT_28),&(v42_2));
              let v42_4: Space = if has_head(&(v42_3)) { singleton(&[]) } else { Space::new() };
              drop(v42_3);
              let v42_5: Space = subtract(&(*CONSTANT_0),&(v42_4));
              drop(v42_4);
              let v42_7: Space = if (&(v42_5)).is_empty() { Space::new() } else {
                let v43_6: Space = routine_13(c, &v41_11_cursor.path()[v41_11_origin..(v41_11_origin + 1)], &v3_11_cursor.path()[v3_11_origin..(v3_11_origin + 1)], &v41_11_cursor);
                compose(&(v42_5),&(v43_6))
              };
              drop(v42_5);
              let v42_8: Space = intersect(&(*CONSTANT_28),&(v42_2));
              drop(v42_2);
              let v42_9: Space = if has_head(&(v42_8)) { singleton(&[]) } else { Space::new() };
              drop(v42_8);
              let v42_11: Space = if (&(v42_9)).is_empty() { Space::new() } else {
                let v44_10: Space = routine_14(c, &v41_11_cursor.path()[v41_11_origin..(v41_11_origin + 1)], &v3_11_cursor.path()[v3_11_origin..(v3_11_origin + 1)], &v41_11_cursor);
                compose(&(v42_9),&(v44_10))
              };
              drop(v42_9);
              let v42_12: Space = unite(&(v42_7),&(v42_11));
              join_wrapped_into(&mut v41_11_write,&((v42_12).read_zipper()),&[]);
              }
              v41_11_cursor.ascend(1);
            }
            drop(v41_11_cursor);
            drop(v41_11_write);
            compose(&(v39_9),&(v41_11))
          };
          drop(v39_9);
          let v39_13: Space = unite(&(v39_7),&(v39_12));
          join_wrapped_into(&mut v38_10_write,&((v39_13).read_zipper()),&[]);
          }
          v3_11_cursor.ascend(1);
        }
        drop(v38_10_write);
        compose(&(v30_9),&(v38_10))
      };
      drop(v30_9);
      let v30_12: Space = unite(&(v30_7),&(v30_11));
      join_wrapped_into(&mut v3_11_write,&((v30_12).read_zipper()),&[]);
      }
      v3_11_cursor.ascend(1);
    }
    drop(v3_11_cursor);
    drop(v3_11_write);
    let v3_12: Space = unite(&(v3_10),&(v3_11));
    let mut v3_13 = Space::new();
    let mut v3_13_write = v3_13.write_zipper();
    let mut v3_13_cursor = descend_cursor(descend_cursor(((*capture_0)).read_zipper(),&(*CONSTANT_21)),&(*CONSTANT_25));
    let v3_13_origin = v3_13_cursor.path().len();
    for v3_13_byte in v3_13_cursor.child_mask().iter() {
      v3_13_cursor.descend_to_existing_byte(v3_13_byte);
      {
      let v45_2: Space = singleton(&v3_13_cursor.path()[v3_13_origin..(v3_13_origin + 1)]);
      let v45_3: Space = intersect(&(*CONSTANT_28),&(v45_2));
      let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
      drop(v45_3);
      let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
      drop(v45_4);
      let v45_7: Space = if (&(v45_5)).is_empty() { Space::new() } else {
        let mut v46_6 = Space::new();
        let mut v46_6_write = v46_6.write_zipper();
        for v46_6_byte in v3_13_cursor.child_mask().iter() {
          v3_13_cursor.descend_to_existing_byte(v46_6_byte);
          {
          let v47_2: Space = singleton(&v3_13_cursor.path()[(v3_13_origin + 1)..(v3_13_origin + 2)]);
          let v47_3: Space = intersect(&(*CONSTANT_28),&(v47_2));
          let v47_4: Space = if has_head(&(v47_3)) { singleton(&[]) } else { Space::new() };
          drop(v47_3);
          let v47_5: Space = subtract(&(*CONSTANT_0),&(v47_4));
          drop(v47_4);
          let v47_8: Space = if (&(v47_5)).is_empty() { Space::new() } else {
            let v48_7: Space = routine_15(c, &v3_13_cursor.path()[v3_13_origin..(v3_13_origin + 2)], &v3_13_cursor, &(((*capture_0)).read_zipper()));
            compose(&(v47_5),&(v48_7))
          };
          drop(v47_5);
          let v47_9: Space = intersect(&(*CONSTANT_28),&(v47_2));
          drop(v47_2);
          let v47_10: Space = if has_head(&(v47_9)) { singleton(&[]) } else { Space::new() };
          drop(v47_9);
          let v47_12: Space = if (&(v47_10)).is_empty() { Space::new() } else {
            let mut v49_11 = Space::new();
            let mut v49_11_write = v49_11.write_zipper();
            for v49_11_byte in v3_13_cursor.child_mask().iter() {
              v3_13_cursor.descend_to_existing_byte(v49_11_byte);
              {
              let v50_2: Space = singleton(&v3_13_cursor.path()[(v3_13_origin + 2)..(v3_13_origin + 3)]);
              let v50_3: Space = intersect(&(*CONSTANT_28),&(v50_2));
              let v50_4: Space = if has_head(&(v50_3)) { singleton(&[]) } else { Space::new() };
              drop(v50_3);
              let v50_5: Space = subtract(&(*CONSTANT_0),&(v50_4));
              drop(v50_4);
              let v50_7: Space = if (&(v50_5)).is_empty() { Space::new() } else {
                let v51_6: Space = routine_16(c, &v3_13_cursor.path()[(v3_13_origin + 2)..(v3_13_origin + 3)], &v3_13_cursor.path()[v3_13_origin..(v3_13_origin + 2)], &v3_13_cursor, &(((*capture_0)).read_zipper()));
                compose(&(v50_5),&(v51_6))
              };
              drop(v50_5);
              let v50_8: Space = intersect(&(*CONSTANT_28),&(v50_2));
              drop(v50_2);
              let v50_9: Space = if has_head(&(v50_8)) { singleton(&[]) } else { Space::new() };
              drop(v50_8);
              let v50_11: Space = if (&(v50_9)).is_empty() { Space::new() } else {
                let v52_10: Space = routine_17(c, &v3_13_cursor.path()[(v3_13_origin + 2)..(v3_13_origin + 3)], &v3_13_cursor.path()[v3_13_origin..(v3_13_origin + 2)], &v3_13_cursor, &(((*capture_0)).read_zipper()));
                compose(&(v50_9),&(v52_10))
              };
              drop(v50_9);
              let v50_12: Space = unite(&(v50_7),&(v50_11));
              join_wrapped_into(&mut v49_11_write,&((v50_12).read_zipper()),&[]);
              }
              v3_13_cursor.ascend(1);
            }
            drop(v49_11_write);
            compose(&(v47_10),&(v49_11))
          };
          drop(v47_10);
          let v47_13: Space = unite(&(v47_8),&(v47_12));
          join_wrapped_into(&mut v46_6_write,&((v47_13).read_zipper()),&[]);
          }
          v3_13_cursor.ascend(1);
        }
        drop(v46_6_write);
        compose(&(v45_5),&(v46_6))
      };
      drop(v45_5);
      let v45_8: Space = intersect(&(*CONSTANT_28),&(v45_2));
      drop(v45_2);
      let v45_9: Space = if has_head(&(v45_8)) { singleton(&[]) } else { Space::new() };
      drop(v45_8);
      let v45_11: Space = if (&(v45_9)).is_empty() { Space::new() } else {
        let mut v53_10 = Space::new();
        let mut v53_10_write = v53_10.write_zipper();
        for v53_10_byte in v3_13_cursor.child_mask().iter() {
          v3_13_cursor.descend_to_existing_byte(v53_10_byte);
          {
          let v54_2: Space = singleton(&v3_13_cursor.path()[(v3_13_origin + 1)..(v3_13_origin + 2)]);
          let v54_3: Space = intersect(&(*CONSTANT_28),&(v54_2));
          let v54_4: Space = if has_head(&(v54_3)) { singleton(&[]) } else { Space::new() };
          drop(v54_3);
          let v54_5: Space = subtract(&(*CONSTANT_0),&(v54_4));
          drop(v54_4);
          let v54_7: Space = if (&(v54_5)).is_empty() { Space::new() } else {
            let v55_6: Space = routine_16(c, &v3_13_cursor.path()[(v3_13_origin + 1)..(v3_13_origin + 2)], &v3_13_cursor.path()[v3_13_origin..(v3_13_origin + 1)], &v3_13_cursor, &(((*capture_0)).read_zipper()));
            compose(&(v54_5),&(v55_6))
          };
          drop(v54_5);
          let v54_8: Space = intersect(&(*CONSTANT_28),&(v54_2));
          drop(v54_2);
          let v54_9: Space = if has_head(&(v54_8)) { singleton(&[]) } else { Space::new() };
          drop(v54_8);
          let v54_12: Space = if (&(v54_9)).is_empty() { Space::new() } else {
            let mut v56_11 = Space::new();
            let mut v56_11_write = v56_11.write_zipper();
            let mut v56_11_cursor = descend_cursor(descend_cursor(descend_cursor(((*capture_0)).read_zipper(),&(*CONSTANT_21)),&(*CONSTANT_25)),&v3_13_cursor.path()[(v3_13_origin + 1)..(v3_13_origin + 2)]);
            let v56_11_origin = v56_11_cursor.path().len();
            for v56_11_byte in v56_11_cursor.child_mask().iter() {
              v56_11_cursor.descend_to_existing_byte(v56_11_byte);
              {
              let v57_2: Space = singleton(&v56_11_cursor.path()[v56_11_origin..(v56_11_origin + 1)]);
              let v57_3: Space = intersect(&(*CONSTANT_28),&(v57_2));
              let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
              drop(v57_3);
              let v57_5: Space = subtract(&(*CONSTANT_0),&(v57_4));
              drop(v57_4);
              let v57_7: Space = if (&(v57_5)).is_empty() { Space::new() } else {
                let v58_6: Space = routine_18(c, &v56_11_cursor.path()[v56_11_origin..(v56_11_origin + 1)], &v3_13_cursor.path()[v3_13_origin..(v3_13_origin + 1)], &v56_11_cursor);
                compose(&(v57_5),&(v58_6))
              };
              drop(v57_5);
              let v57_8: Space = intersect(&(*CONSTANT_28),&(v57_2));
              drop(v57_2);
              let v57_9: Space = if has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
              drop(v57_8);
              let v57_11: Space = if (&(v57_9)).is_empty() { Space::new() } else {
                let v59_10: Space = routine_19(c, &v56_11_cursor.path()[v56_11_origin..(v56_11_origin + 1)], &v3_13_cursor.path()[v3_13_origin..(v3_13_origin + 1)], &v56_11_cursor);
                compose(&(v57_9),&(v59_10))
              };
              drop(v57_9);
              let v57_12: Space = unite(&(v57_7),&(v57_11));
              join_wrapped_into(&mut v56_11_write,&((v57_12).read_zipper()),&[]);
              }
              v56_11_cursor.ascend(1);
            }
            drop(v56_11_cursor);
            drop(v56_11_write);
            compose(&(v54_9),&(v56_11))
          };
          drop(v54_9);
          let v54_13: Space = unite(&(v54_7),&(v54_12));
          join_wrapped_into(&mut v53_10_write,&((v54_13).read_zipper()),&[]);
          }
          v3_13_cursor.ascend(1);
        }
        drop(v53_10_write);
        compose(&(v45_9),&(v53_10))
      };
      drop(v45_9);
      let v45_12: Space = unite(&(v45_7),&(v45_11));
      join_wrapped_into(&mut v3_13_write,&((v45_12).read_zipper()),&[]);
      }
      v3_13_cursor.ascend(1);
    }
    drop(v3_13_cursor);
    drop(v3_13_write);

((v3_10).clone(),(v3_11).clone(),(v3_12).clone(),(v3_13).clone(),(v3_4).clone(),(v3_6).clone(),(v3_9).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let v0_42: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v1_41: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
      let v2_4: Space = routine_1(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
      let v2_7: Space = routine_1(c, &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
      let v2_8: Space = unite(&(v2_4),&(v2_7));
      let v2_11: Space = routine_1(c, &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
      let v2_12: Space = unite(&(v2_8),&(v2_11));
      let v2_15: Space = routine_1(c, &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
      let v2_16: Space = unite(&(v2_12),&(v2_15));
      let v2_19: Space = routine_1(c, &(*CONSTANT_9), &((*CONSTANT_10).read_zipper()));
      let v2_20: Space = unite(&(v2_16),&(v2_19));
      let v2_23: Space = routine_1(c, &(*CONSTANT_11), &((*CONSTANT_12).read_zipper()));
      let v2_24: Space = unite(&(v2_20),&(v2_23));
      let v2_27: Space = routine_1(c, &(*CONSTANT_13), &((*CONSTANT_14).read_zipper()));
      let v2_28: Space = unite(&(v2_24),&(v2_27));
      let v2_31: Space = routine_1(c, &(*CONSTANT_15), &((*CONSTANT_16).read_zipper()));
      let v2_32: Space = unite(&(v2_28),&(v2_31));
      let v2_35: Space = routine_1(c, &(*CONSTANT_17), &((*CONSTANT_18).read_zipper()));
      let v2_36: Space = unite(&(v2_32),&(v2_35));
      let v2_39: Space = routine_1(c, &(*CONSTANT_19), &((*CONSTANT_20).read_zipper()));
      let v2_40: Space = unite(&(v2_36),&(v2_39));
      compose(&(*CONSTANT_0),&(v2_40))
    };
    compose(&(*CONSTANT_0),&(v1_41))
  };
  let v0_44: Space = wrap(&(v0_42),&(*CONSTANT_21));
  let v0_46: Space = unite(&(v0_44),&(*CONSTANT_22));
  let mut v0_109: Space = (v0_46).clone();
  loop {
    let (mut v3_10,mut v3_11,mut v3_12,mut v3_13,mut v3_4,mut v3_6,mut v3_9,) = native_block_0(c, &v0_109);
    let v3_14: Space = unite(&(v3_12),&(v3_13));
    let v3_16: Space = subtract(&(v3_14),&(descend_cursor((v0_109).read_zipper(),&(*CONSTANT_26))));
    let v3_18: Space = subtract(&(v3_16),&(descend_cursor((v0_109).read_zipper(),&(*CONSTANT_27))));
    let v3_19: Space = wrap(&(v3_18),&(*CONSTANT_27));
    let v3_20: Space = unite(&(v3_4),&(v3_19));
    drop(v3_4);
    let v3_21: Space = unite(&(v3_20),&(v0_109));
    if !v0_109.join_into((v3_21).clone()).is_element() { break; }
  }
  (&(descend_cursor((v0_109).read_zipper(),&(*CONSTANT_26)))).make_map()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v60_9 = Space::new();
  let mut v60_9_write = v60_9.write_zipper();
  let mut v60_9_cursor = (*s0).read_zipper();
  let v60_9_origin = v60_9_cursor.path().len();
  for v60_9_byte in v60_9_cursor.child_mask().iter() {
    v60_9_cursor.descend_to_existing_byte(v60_9_byte);
    {
    let v61_2: Space = singleton(&v60_9_cursor.path()[v60_9_origin..(v60_9_origin + 1)]);
    let v61_3: Space = intersect(&(*CONSTANT_28),&(v61_2));
    let v61_4: Space = if has_head(&(v61_3)) { singleton(&[]) } else { Space::new() };
    drop(v61_3);
    let v61_5: Space = subtract(&(*CONSTANT_0),&(v61_4));
    drop(v61_4);
    let v61_8: Space = if (&(v61_5)).is_empty() { Space::new() } else {
      let v62_6: Path = concat_path(&(*p0),&v60_9_cursor.path()[v60_9_origin..(v60_9_origin + 1)]);
      let v62_7: Space = routine_1(c, &(v62_6), &v60_9_cursor);
      compose(&(v61_5),&(v62_7))
    };
    drop(v61_5);
    let v61_9: Space = intersect(&(*CONSTANT_28),&(v61_2));
    drop(v61_2);
    let v61_10: Space = if has_head(&(v61_9)) { singleton(&[]) } else { Space::new() };
    drop(v61_9);
    let v61_12: Space = if (&(v61_10)).is_empty() { Space::new() } else {
      let v63_6: Path = concat_path(&(*p0),&v60_9_cursor.path()[v60_9_origin..(v60_9_origin + 1)]);
      let mut v63_11 = Space::new();
      let mut v63_11_write = v63_11.write_zipper();
      for v63_11_byte in v60_9_cursor.child_mask().iter() {
        v60_9_cursor.descend_to_existing_byte(v63_11_byte);
        {
        let v64_2: Space = singleton(&v60_9_cursor.path()[(v60_9_origin + 1)..(v60_9_origin + 2)]);
        let v64_3: Space = intersect(&(*CONSTANT_28),&(v64_2));
        let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
        drop(v64_3);
        let v64_5: Space = compose(&(v64_4),&v60_9_cursor);
        drop(v64_4);
        let v64_6: Space = wrap(&(v64_5),&v60_9_cursor.path()[(v60_9_origin + 1)..(v60_9_origin + 2)]);
        drop(v64_5);
        let v64_7: Space = wrap(&(v64_6),&(v63_6));
        drop(v64_6);
        let v64_8: Space = wrap(&(v64_7),&(*CONSTANT_25));
        drop(v64_7);
        let v64_9: Space = intersect(&(*CONSTANT_28),&(v64_2));
        drop(v64_2);
        let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
        drop(v64_9);
        let v64_11: Space = subtract(&(*CONSTANT_0),&(v64_10));
        drop(v64_10);
        let v64_13: Space = if (&(v64_11)).is_empty() { Space::new() } else {
          let v65_12: Space = routine_20(c, &v60_9_cursor.path()[(v60_9_origin + 1)..(v60_9_origin + 2)], &(v63_6), &v60_9_cursor);
          compose(&(v64_11),&(v65_12))
        };
        drop(v64_11);
        let v64_14: Space = unite(&(v64_8),&(v64_13));
        drop(v64_8);
        join_wrapped_into(&mut v63_11_write,&((v64_14).read_zipper()),&[]);
        }
        v60_9_cursor.ascend(1);
      }
      drop(v63_11_write);
      drop(v63_6);
      compose(&(v61_10),&(v63_11))
    };
    drop(v61_10);
    let v61_13: Space = unite(&(v61_8),&(v61_12));
    join_wrapped_into(&mut v60_9_write,&((v61_13).read_zipper()),&[]);
    }
    v60_9_cursor.ascend(1);
  }
  drop(v60_9_cursor);
  drop(v60_9_write);
  (v60_9).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v66_8 = Space::new();
  let mut v66_8_write = v66_8.write_zipper();
  let mut v66_8_cursor = (*s0).read_zipper();
  let v66_8_origin = v66_8_cursor.path().len();
  for v66_8_byte in v66_8_cursor.child_mask().iter() {
    v66_8_cursor.descend_to_existing_byte(v66_8_byte);
    {
    let v67_2: Space = singleton(&v66_8_cursor.path()[v66_8_origin..(v66_8_origin + 1)]);
    let v67_3: Space = intersect(&(*CONSTANT_28),&(v67_2));
    let v67_4: Space = if has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
    drop(v67_3);
    let v67_5: Space = subtract(&(*CONSTANT_0),&(v67_4));
    drop(v67_4);
    let v67_8: Space = if (&(v67_5)).is_empty() { Space::new() } else {
      let v68_6: Path = concat_path(&(*p0),&v66_8_cursor.path()[v66_8_origin..(v66_8_origin + 1)]);
      let v68_7: Space = routine_2(c, &(v68_6), &v66_8_cursor);
      compose(&(v67_5),&(v68_7))
    };
    drop(v67_5);
    let v67_9: Space = intersect(&(*CONSTANT_28),&(v67_2));
    drop(v67_2);
    let v67_10: Space = if has_head(&(v67_9)) { singleton(&[]) } else { Space::new() };
    drop(v67_9);
    let v67_12: Space = if (&(v67_10)).is_empty() { Space::new() } else {
      let v69_6: Path = concat_path(&(*p0),&v66_8_cursor.path()[v66_8_origin..(v66_8_origin + 1)]);
      let mut v69_11 = Space::new();
      let mut v69_11_write = v69_11.write_zipper();
      for v69_11_byte in v66_8_cursor.child_mask().iter() {
        v66_8_cursor.descend_to_existing_byte(v69_11_byte);
        {
        let v70_2: Space = singleton(&v66_8_cursor.path()[(v66_8_origin + 1)..(v66_8_origin + 2)]);
        let v70_3: Space = intersect(&(*CONSTANT_28),&(v70_2));
        let v70_4: Space = if has_head(&(v70_3)) { singleton(&[]) } else { Space::new() };
        drop(v70_3);
        let v70_5: Space = subtract(&(*CONSTANT_0),&(v70_4));
        drop(v70_4);
        let v70_7: Space = if (&(v70_5)).is_empty() { Space::new() } else {
          let v71_6: Space = routine_3(c, &v66_8_cursor.path()[(v66_8_origin + 1)..(v66_8_origin + 2)], &(v69_6), &v66_8_cursor);
          compose(&(v70_5),&(v71_6))
        };
        drop(v70_5);
        let v70_8: Space = intersect(&(*CONSTANT_28),&(v70_2));
        drop(v70_2);
        let v70_9: Space = if has_head(&(v70_8)) { singleton(&[]) } else { Space::new() };
        drop(v70_8);
        let v70_10: Space = compose(&(v70_9),&v66_8_cursor);
        drop(v70_9);
        let v70_11: Space = wrap(&(v70_10),&v66_8_cursor.path()[(v66_8_origin + 1)..(v66_8_origin + 2)]);
        drop(v70_10);
        let v70_12: Space = wrap(&(v70_11),&(v69_6));
        drop(v70_11);
        let v70_13: Space = unite(&(v70_7),&(v70_12));
        drop(v70_12);
        join_wrapped_into(&mut v69_11_write,&((v70_13).read_zipper()),&[]);
        }
        v66_8_cursor.ascend(1);
      }
      drop(v69_11_write);
      drop(v69_6);
      compose(&(v67_10),&(v69_11))
    };
    drop(v67_10);
    let v67_13: Space = unite(&(v67_8),&(v67_12));
    join_wrapped_into(&mut v66_8_write,&((v67_13).read_zipper()),&[]);
    }
    v66_8_cursor.ascend(1);
  }
  drop(v66_8_cursor);
  drop(v66_8_write);
  (v66_8).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v72_6 = Space::new();
  let mut v72_6_write = v72_6.write_zipper();
  let mut v72_6_cursor = (*s0).read_zipper();
  let v72_6_origin = v72_6_cursor.path().len();
  for v72_6_byte in v72_6_cursor.child_mask().iter() {
    v72_6_cursor.descend_to_existing_byte(v72_6_byte);
    {
    let v73_2: Space = singleton(&v72_6_cursor.path()[v72_6_origin..(v72_6_origin + 1)]);
    let v73_3: Space = intersect(&(*CONSTANT_28),&(v73_2));
    let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
    drop(v73_3);
    let v73_5: Space = subtract(&(*CONSTANT_0),&(v73_4));
    drop(v73_4);
    let v73_8: Space = if (&(v73_5)).is_empty() { Space::new() } else {
      let v74_6: Path = concat_path(&(*p0),&v72_6_cursor.path()[v72_6_origin..(v72_6_origin + 1)]);
      let v74_7: Space = routine_3(c, &(v74_6), &(*p1), &v72_6_cursor);
      compose(&(v73_5),&(v74_7))
    };
    drop(v73_5);
    let v73_9: Space = intersect(&(*CONSTANT_28),&(v73_2));
    drop(v73_2);
    let v73_10: Space = if has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
    drop(v73_9);
    let v73_11: Space = compose(&(v73_10),&v72_6_cursor);
    drop(v73_10);
    let v75_6: Path = concat_path(&(*p0),&v72_6_cursor.path()[v72_6_origin..(v72_6_origin + 1)]);
    let v73_12: Space = wrap(&(v73_11),&(v75_6));
    drop(v73_11);
    let v73_13: Space = wrap(&(v73_12),&(*p1));
    drop(v73_12);
    let v73_14: Space = unite(&(v73_8),&(v73_13));
    drop(v73_13);
    join_wrapped_into(&mut v72_6_write,&((v73_14).read_zipper()),&[]);
    }
    v72_6_cursor.ascend(1);
  }
  drop(v72_6_cursor);
  drop(v72_6_write);
  (v72_6).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v76_3: Space = wrap(&(*s0),&(*p0));
  let v76_4: Space = wrap(&(v76_3),&(*p1));
  drop(v76_3);
  (v76_4).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v77_16 = Space::new();
  let mut v77_16_write = v77_16.write_zipper();
  let mut v77_16_cursor = (*s0).read_zipper();
  let v77_16_origin = v77_16_cursor.path().len();
  for v77_16_byte in v77_16_cursor.child_mask().iter() {
    v77_16_cursor.descend_to_existing_byte(v77_16_byte);
    {
    let v78_2: Space = singleton(&v77_16_cursor.path()[v77_16_origin..(v77_16_origin + 1)]);
    let v78_3: Space = intersect(&(*CONSTANT_28),&(v78_2));
    let v78_4: Space = if has_head(&(v78_3)) { singleton(&[]) } else { Space::new() };
    drop(v78_3);
    let v78_5: Space = subtract(&(*CONSTANT_0),&(v78_4));
    drop(v78_4);
    let v78_8: Space = if (&(v78_5)).is_empty() { Space::new() } else {
      let v79_6: Path = concat_path(&(*p0),&v77_16_cursor.path()[v77_16_origin..(v77_16_origin + 1)]);
      let v79_7: Space = routine_5(c, &(v79_6), &v77_16_cursor, &(*s1));
      compose(&(v78_5),&(v79_7))
    };
    drop(v78_5);
    let v78_9: Space = intersect(&(*CONSTANT_28),&(v78_2));
    drop(v78_2);
    let v78_10: Space = if has_head(&(v78_9)) { singleton(&[]) } else { Space::new() };
    drop(v78_9);
    let v78_12: Space = if (&(v78_10)).is_empty() { Space::new() } else {
      let v80_6: Path = concat_path(&(*p0),&v77_16_cursor.path()[v77_16_origin..(v77_16_origin + 1)]);
      let mut v80_11 = Space::new();
      let mut v80_11_write = v80_11.write_zipper();
      for v80_11_byte in v77_16_cursor.child_mask().iter() {
        v77_16_cursor.descend_to_existing_byte(v80_11_byte);
        {
        let v81_2: Space = singleton(&v77_16_cursor.path()[(v77_16_origin + 1)..(v77_16_origin + 2)]);
        let v81_3: Space = intersect(&(*CONSTANT_28),&(v81_2));
        let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
        drop(v81_3);
        let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
        drop(v81_4);
        let v81_7: Space = if (&(v81_5)).is_empty() { Space::new() } else {
          let v82_6: Space = routine_6(c, &v77_16_cursor.path()[(v77_16_origin + 1)..(v77_16_origin + 2)], &(v80_6), &v77_16_cursor, &(*s1));
          compose(&(v81_5),&(v82_6))
        };
        drop(v81_5);
        let v81_8: Space = intersect(&(*CONSTANT_28),&(v81_2));
        drop(v81_2);
        let v81_9: Space = if has_head(&(v81_8)) { singleton(&[]) } else { Space::new() };
        drop(v81_8);
        let v81_12: Space = if (&(v81_9)).is_empty() { Space::new() } else {
          let mut v83_11 = Space::new();
          let mut v83_11_write = v83_11.write_zipper();
          let mut v83_11_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_21)),&(*CONSTANT_25)),&v77_16_cursor.path()[(v77_16_origin + 1)..(v77_16_origin + 2)]);
          let v83_11_origin = v83_11_cursor.path().len();
          for v83_11_byte in v83_11_cursor.child_mask().iter() {
            v83_11_cursor.descend_to_existing_byte(v83_11_byte);
            {
            let v84_2: Space = singleton(&v83_11_cursor.path()[v83_11_origin..(v83_11_origin + 1)]);
            let v84_3: Space = intersect(&(*CONSTANT_28),&(v84_2));
            let v84_4: Space = if has_head(&(v84_3)) { singleton(&[]) } else { Space::new() };
            drop(v84_3);
            let v84_5: Space = subtract(&(*CONSTANT_0),&(v84_4));
            drop(v84_4);
            let v84_7: Space = if (&(v84_5)).is_empty() { Space::new() } else {
              let v85_6: Space = routine_8(c, &v83_11_cursor.path()[v83_11_origin..(v83_11_origin + 1)], &(v80_6), &v83_11_cursor);
              compose(&(v84_5),&(v85_6))
            };
            drop(v84_5);
            let v84_8: Space = intersect(&(*CONSTANT_28),&(v84_2));
            drop(v84_2);
            let v84_9: Space = if has_head(&(v84_8)) { singleton(&[]) } else { Space::new() };
            drop(v84_8);
            let v84_11: Space = if (&(v84_9)).is_empty() { Space::new() } else {
              let v86_10: Space = routine_9(c, &v83_11_cursor.path()[v83_11_origin..(v83_11_origin + 1)], &(v80_6), &v83_11_cursor);
              compose(&(v84_9),&(v86_10))
            };
            drop(v84_9);
            let v84_12: Space = unite(&(v84_7),&(v84_11));
            join_wrapped_into(&mut v83_11_write,&((v84_12).read_zipper()),&[]);
            }
            v83_11_cursor.ascend(1);
          }
          drop(v83_11_cursor);
          drop(v83_11_write);
          compose(&(v81_9),&(v83_11))
        };
        drop(v81_9);
        let v81_13: Space = unite(&(v81_7),&(v81_12));
        join_wrapped_into(&mut v80_11_write,&((v81_13).read_zipper()),&[]);
        }
        v77_16_cursor.ascend(1);
      }
      drop(v80_11_write);
      drop(v80_6);
      compose(&(v78_10),&(v80_11))
    };
    drop(v78_10);
    let v78_13: Space = unite(&(v78_8),&(v78_12));
    join_wrapped_into(&mut v77_16_write,&((v78_13).read_zipper()),&[]);
    }
    v77_16_cursor.ascend(1);
  }
  drop(v77_16_cursor);
  drop(v77_16_write);
  (v77_16).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v87_15 = Space::new();
  let mut v87_15_write = v87_15.write_zipper();
  let mut v87_15_cursor = (*s0).read_zipper();
  let v87_15_origin = v87_15_cursor.path().len();
  for v87_15_byte in v87_15_cursor.child_mask().iter() {
    v87_15_cursor.descend_to_existing_byte(v87_15_byte);
    {
    let v88_2: Space = singleton(&v87_15_cursor.path()[v87_15_origin..(v87_15_origin + 1)]);
    let v88_3: Space = intersect(&(*CONSTANT_28),&(v88_2));
    let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
    drop(v88_3);
    let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
    drop(v88_4);
    let v88_8: Space = if (&(v88_5)).is_empty() { Space::new() } else {
      let v89_6: Path = concat_path(&(*p0),&v87_15_cursor.path()[v87_15_origin..(v87_15_origin + 1)]);
      let v89_7: Space = routine_6(c, &(v89_6), &(*p1), &v87_15_cursor, &(*s1));
      drop(v89_6);
      compose(&(v88_5),&(v89_7))
    };
    drop(v88_5);
    let v88_9: Space = intersect(&(*CONSTANT_28),&(v88_2));
    drop(v88_2);
    let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
    drop(v88_9);
    let v88_13: Space = if (&(v88_10)).is_empty() { Space::new() } else {
      let mut v90_12 = Space::new();
      let mut v90_12_write = v90_12.write_zipper();
      let mut v90_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_21)),&(*CONSTANT_25)),&(*p0)),&v87_15_cursor.path()[v87_15_origin..(v87_15_origin + 1)]);
      let v90_12_origin = v90_12_cursor.path().len();
      for v90_12_byte in v90_12_cursor.child_mask().iter() {
        v90_12_cursor.descend_to_existing_byte(v90_12_byte);
        {
        let v91_2: Space = singleton(&v90_12_cursor.path()[v90_12_origin..(v90_12_origin + 1)]);
        let v91_3: Space = intersect(&(*CONSTANT_28),&(v91_2));
        let v91_4: Space = if has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
        drop(v91_3);
        let v91_5: Space = subtract(&(*CONSTANT_0),&(v91_4));
        drop(v91_4);
        let v91_7: Space = if (&(v91_5)).is_empty() { Space::new() } else {
          let v92_6: Space = routine_8(c, &v90_12_cursor.path()[v90_12_origin..(v90_12_origin + 1)], &(*p1), &v90_12_cursor);
          compose(&(v91_5),&(v92_6))
        };
        drop(v91_5);
        let v91_8: Space = intersect(&(*CONSTANT_28),&(v91_2));
        drop(v91_2);
        let v91_9: Space = if has_head(&(v91_8)) { singleton(&[]) } else { Space::new() };
        drop(v91_8);
        let v91_10: Space = compose(&(v91_9),&v90_12_cursor);
        drop(v91_9);
        let v91_11: Space = wrap(&(v91_10),&v90_12_cursor.path()[v90_12_origin..(v90_12_origin + 1)]);
        drop(v91_10);
        let v91_12: Space = wrap(&(v91_11),&(*p1));
        drop(v91_11);
        let v91_13: Space = unite(&(v91_7),&(v91_12));
        drop(v91_12);
        join_wrapped_into(&mut v90_12_write,&((v91_13).read_zipper()),&[]);
        }
        v90_12_cursor.ascend(1);
      }
      drop(v90_12_cursor);
      drop(v90_12_write);
      compose(&(v88_10),&(v90_12))
    };
    drop(v88_10);
    let v88_14: Space = unite(&(v88_8),&(v88_13));
    join_wrapped_into(&mut v87_15_write,&((v88_14).read_zipper()),&[]);
    }
    v87_15_cursor.ascend(1);
  }
  drop(v87_15_cursor);
  drop(v87_15_write);
  (v87_15).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v93_15 = Space::new();
  let mut v93_15_write = v93_15.write_zipper();
  let mut v93_15_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_21)),&(*CONSTANT_25)),&(*p0));
  let v93_15_origin = v93_15_cursor.path().len();
  for v93_15_byte in v93_15_cursor.child_mask().iter() {
    v93_15_cursor.descend_to_existing_byte(v93_15_byte);
    {
    let v94_2: Space = singleton(&v93_15_cursor.path()[v93_15_origin..(v93_15_origin + 1)]);
    let v94_3: Space = intersect(&(*CONSTANT_28),&(v94_2));
    let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
    drop(v94_3);
    let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
    drop(v94_4);
    let v94_7: Space = if (&(v94_5)).is_empty() { Space::new() } else {
      let mut v95_6 = Space::new();
      let mut v95_6_write = v95_6.write_zipper();
      for v95_6_byte in v93_15_cursor.child_mask().iter() {
        v93_15_cursor.descend_to_existing_byte(v95_6_byte);
        {
        let v96_2: Space = singleton(&v93_15_cursor.path()[(v93_15_origin + 1)..(v93_15_origin + 2)]);
        let v96_3: Space = intersect(&(*CONSTANT_28),&(v96_2));
        let v96_4: Space = if has_head(&(v96_3)) { singleton(&[]) } else { Space::new() };
        drop(v96_3);
        let v96_5: Space = subtract(&(*CONSTANT_0),&(v96_4));
        drop(v96_4);
        let v96_8: Space = if (&(v96_5)).is_empty() { Space::new() } else {
          let v97_7: Space = routine_8(c, &v93_15_cursor.path()[v93_15_origin..(v93_15_origin + 2)], &(*p1), &v93_15_cursor);
          compose(&(v96_5),&(v97_7))
        };
        drop(v96_5);
        let v96_9: Space = intersect(&(*CONSTANT_28),&(v96_2));
        drop(v96_2);
        let v96_10: Space = if has_head(&(v96_9)) { singleton(&[]) } else { Space::new() };
        drop(v96_9);
        let v96_11: Space = compose(&(v96_10),&v93_15_cursor);
        drop(v96_10);
        let v96_12: Space = wrap(&(v96_11),&v93_15_cursor.path()[v93_15_origin..(v93_15_origin + 2)]);
        drop(v96_11);
        let v96_13: Space = wrap(&(v96_12),&(*p1));
        drop(v96_12);
        let v96_14: Space = unite(&(v96_8),&(v96_13));
        drop(v96_13);
        join_wrapped_into(&mut v95_6_write,&((v96_14).read_zipper()),&[]);
        }
        v93_15_cursor.ascend(1);
      }
      drop(v95_6_write);
      compose(&(v94_5),&(v95_6))
    };
    drop(v94_5);
    let v94_8: Space = intersect(&(*CONSTANT_28),&(v94_2));
    drop(v94_2);
    let v94_9: Space = if has_head(&(v94_8)) { singleton(&[]) } else { Space::new() };
    drop(v94_8);
    let v94_10: Space = compose(&(v94_9),&v93_15_cursor);
    drop(v94_9);
    let v94_11: Space = wrap(&(v94_10),&v93_15_cursor.path()[v93_15_origin..(v93_15_origin + 1)]);
    drop(v94_10);
    let v94_12: Space = wrap(&(v94_11),&(*p1));
    drop(v94_11);
    let v94_13: Space = unite(&(v94_7),&(v94_12));
    drop(v94_12);
    join_wrapped_into(&mut v93_15_write,&((v94_13).read_zipper()),&[]);
    }
    v93_15_cursor.ascend(1);
  }
  drop(v93_15_cursor);
  drop(v93_15_write);
  (v93_15).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v99_6 = Space::new();
  let mut v99_6_write = v99_6.write_zipper();
  let mut v99_6_cursor = (*s0).read_zipper();
  let v99_6_origin = v99_6_cursor.path().len();
  for v99_6_byte in v99_6_cursor.child_mask().iter() {
    v99_6_cursor.descend_to_existing_byte(v99_6_byte);
    {
    let v100_2: Space = singleton(&v99_6_cursor.path()[v99_6_origin..(v99_6_origin + 1)]);
    let v100_3: Space = intersect(&(*CONSTANT_28),&(v100_2));
    let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
    drop(v100_3);
    let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
    drop(v100_4);
    let v100_8: Space = if (&(v100_5)).is_empty() { Space::new() } else {
      let v101_6: Path = concat_path(&(*p0),&v99_6_cursor.path()[v99_6_origin..(v99_6_origin + 1)]);
      let v101_7: Space = routine_8(c, &(v101_6), &(*p1), &v99_6_cursor);
      compose(&(v100_5),&(v101_7))
    };
    drop(v100_5);
    let v100_9: Space = intersect(&(*CONSTANT_28),&(v100_2));
    drop(v100_2);
    let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
    drop(v100_9);
    let v100_11: Space = compose(&(v100_10),&v99_6_cursor);
    drop(v100_10);
    let v102_6: Path = concat_path(&(*p0),&v99_6_cursor.path()[v99_6_origin..(v99_6_origin + 1)]);
    let v100_12: Space = wrap(&(v100_11),&(v102_6));
    drop(v100_11);
    let v100_13: Space = wrap(&(v100_12),&(*p1));
    drop(v100_12);
    let v100_14: Space = unite(&(v100_8),&(v100_13));
    drop(v100_13);
    join_wrapped_into(&mut v99_6_write,&((v100_14).read_zipper()),&[]);
    }
    v99_6_cursor.ascend(1);
  }
  drop(v99_6_cursor);
  drop(v99_6_write);
  (v99_6).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v103_3: Space = wrap(&(*s0),&(*p0));
  let v103_4: Space = wrap(&(v103_3),&(*p1));
  drop(v103_3);
  (v103_4).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v104_16 = Space::new();
  let mut v104_16_write = v104_16.write_zipper();
  let mut v104_16_cursor = (*s0).read_zipper();
  let v104_16_origin = v104_16_cursor.path().len();
  for v104_16_byte in v104_16_cursor.child_mask().iter() {
    v104_16_cursor.descend_to_existing_byte(v104_16_byte);
    {
    let v105_2: Space = singleton(&v104_16_cursor.path()[v104_16_origin..(v104_16_origin + 1)]);
    let v105_3: Space = intersect(&(*CONSTANT_28),&(v105_2));
    let v105_4: Space = if has_head(&(v105_3)) { singleton(&[]) } else { Space::new() };
    drop(v105_3);
    let v105_5: Space = subtract(&(*CONSTANT_0),&(v105_4));
    drop(v105_4);
    let v105_8: Space = if (&(v105_5)).is_empty() { Space::new() } else {
      let v106_6: Path = concat_path(&(*p0),&v104_16_cursor.path()[v104_16_origin..(v104_16_origin + 1)]);
      let v106_7: Space = routine_10(c, &(v106_6), &v104_16_cursor, &(*s1));
      compose(&(v105_5),&(v106_7))
    };
    drop(v105_5);
    let v105_9: Space = intersect(&(*CONSTANT_28),&(v105_2));
    drop(v105_2);
    let v105_10: Space = if has_head(&(v105_9)) { singleton(&[]) } else { Space::new() };
    drop(v105_9);
    let v105_12: Space = if (&(v105_10)).is_empty() { Space::new() } else {
      let v107_6: Path = concat_path(&(*p0),&v104_16_cursor.path()[v104_16_origin..(v104_16_origin + 1)]);
      let mut v107_11 = Space::new();
      let mut v107_11_write = v107_11.write_zipper();
      for v107_11_byte in v104_16_cursor.child_mask().iter() {
        v104_16_cursor.descend_to_existing_byte(v107_11_byte);
        {
        let v108_2: Space = singleton(&v104_16_cursor.path()[(v104_16_origin + 1)..(v104_16_origin + 2)]);
        let v108_3: Space = intersect(&(*CONSTANT_28),&(v108_2));
        let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
        drop(v108_3);
        let v108_5: Space = subtract(&(*CONSTANT_0),&(v108_4));
        drop(v108_4);
        let v108_7: Space = if (&(v108_5)).is_empty() { Space::new() } else {
          let v109_6: Space = routine_11(c, &v104_16_cursor.path()[(v104_16_origin + 1)..(v104_16_origin + 2)], &(v107_6), &v104_16_cursor, &(*s1));
          compose(&(v108_5),&(v109_6))
        };
        drop(v108_5);
        let v108_8: Space = intersect(&(*CONSTANT_28),&(v108_2));
        drop(v108_2);
        let v108_9: Space = if has_head(&(v108_8)) { singleton(&[]) } else { Space::new() };
        drop(v108_8);
        let v108_12: Space = if (&(v108_9)).is_empty() { Space::new() } else {
          let mut v110_11 = Space::new();
          let mut v110_11_write = v110_11.write_zipper();
          let mut v110_11_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23)),&(*CONSTANT_25)),&v104_16_cursor.path()[(v104_16_origin + 1)..(v104_16_origin + 2)]);
          let v110_11_origin = v110_11_cursor.path().len();
          for v110_11_byte in v110_11_cursor.child_mask().iter() {
            v110_11_cursor.descend_to_existing_byte(v110_11_byte);
            {
            let v111_2: Space = singleton(&v110_11_cursor.path()[v110_11_origin..(v110_11_origin + 1)]);
            let v111_3: Space = intersect(&(*CONSTANT_28),&(v111_2));
            let v111_4: Space = if has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
            drop(v111_3);
            let v111_5: Space = subtract(&(*CONSTANT_0),&(v111_4));
            drop(v111_4);
            let v111_7: Space = if (&(v111_5)).is_empty() { Space::new() } else {
              let v112_6: Space = routine_13(c, &v110_11_cursor.path()[v110_11_origin..(v110_11_origin + 1)], &(v107_6), &v110_11_cursor);
              compose(&(v111_5),&(v112_6))
            };
            drop(v111_5);
            let v111_8: Space = intersect(&(*CONSTANT_28),&(v111_2));
            drop(v111_2);
            let v111_9: Space = if has_head(&(v111_8)) { singleton(&[]) } else { Space::new() };
            drop(v111_8);
            let v111_11: Space = if (&(v111_9)).is_empty() { Space::new() } else {
              let v113_10: Space = routine_14(c, &v110_11_cursor.path()[v110_11_origin..(v110_11_origin + 1)], &(v107_6), &v110_11_cursor);
              compose(&(v111_9),&(v113_10))
            };
            drop(v111_9);
            let v111_12: Space = unite(&(v111_7),&(v111_11));
            join_wrapped_into(&mut v110_11_write,&((v111_12).read_zipper()),&[]);
            }
            v110_11_cursor.ascend(1);
          }
          drop(v110_11_cursor);
          drop(v110_11_write);
          compose(&(v108_9),&(v110_11))
        };
        drop(v108_9);
        let v108_13: Space = unite(&(v108_7),&(v108_12));
        join_wrapped_into(&mut v107_11_write,&((v108_13).read_zipper()),&[]);
        }
        v104_16_cursor.ascend(1);
      }
      drop(v107_11_write);
      drop(v107_6);
      compose(&(v105_10),&(v107_11))
    };
    drop(v105_10);
    let v105_13: Space = unite(&(v105_8),&(v105_12));
    join_wrapped_into(&mut v104_16_write,&((v105_13).read_zipper()),&[]);
    }
    v104_16_cursor.ascend(1);
  }
  drop(v104_16_cursor);
  drop(v104_16_write);
  (v104_16).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v114_15 = Space::new();
  let mut v114_15_write = v114_15.write_zipper();
  let mut v114_15_cursor = (*s0).read_zipper();
  let v114_15_origin = v114_15_cursor.path().len();
  for v114_15_byte in v114_15_cursor.child_mask().iter() {
    v114_15_cursor.descend_to_existing_byte(v114_15_byte);
    {
    let v115_2: Space = singleton(&v114_15_cursor.path()[v114_15_origin..(v114_15_origin + 1)]);
    let v115_3: Space = intersect(&(*CONSTANT_28),&(v115_2));
    let v115_4: Space = if has_head(&(v115_3)) { singleton(&[]) } else { Space::new() };
    drop(v115_3);
    let v115_5: Space = subtract(&(*CONSTANT_0),&(v115_4));
    drop(v115_4);
    let v115_8: Space = if (&(v115_5)).is_empty() { Space::new() } else {
      let v116_6: Path = concat_path(&(*p0),&v114_15_cursor.path()[v114_15_origin..(v114_15_origin + 1)]);
      let v116_7: Space = routine_11(c, &(v116_6), &(*p1), &v114_15_cursor, &(*s1));
      drop(v116_6);
      compose(&(v115_5),&(v116_7))
    };
    drop(v115_5);
    let v115_9: Space = intersect(&(*CONSTANT_28),&(v115_2));
    drop(v115_2);
    let v115_10: Space = if has_head(&(v115_9)) { singleton(&[]) } else { Space::new() };
    drop(v115_9);
    let v115_13: Space = if (&(v115_10)).is_empty() { Space::new() } else {
      let mut v117_12 = Space::new();
      let mut v117_12_write = v117_12.write_zipper();
      let mut v117_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23)),&(*CONSTANT_25)),&(*p0)),&v114_15_cursor.path()[v114_15_origin..(v114_15_origin + 1)]);
      let v117_12_origin = v117_12_cursor.path().len();
      for v117_12_byte in v117_12_cursor.child_mask().iter() {
        v117_12_cursor.descend_to_existing_byte(v117_12_byte);
        {
        let v118_2: Space = singleton(&v117_12_cursor.path()[v117_12_origin..(v117_12_origin + 1)]);
        let v118_3: Space = intersect(&(*CONSTANT_28),&(v118_2));
        let v118_4: Space = if has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
        drop(v118_3);
        let v118_5: Space = subtract(&(*CONSTANT_0),&(v118_4));
        drop(v118_4);
        let v118_7: Space = if (&(v118_5)).is_empty() { Space::new() } else {
          let v119_6: Space = routine_13(c, &v117_12_cursor.path()[v117_12_origin..(v117_12_origin + 1)], &(*p1), &v117_12_cursor);
          compose(&(v118_5),&(v119_6))
        };
        drop(v118_5);
        let v118_8: Space = intersect(&(*CONSTANT_28),&(v118_2));
        drop(v118_2);
        let v118_9: Space = if has_head(&(v118_8)) { singleton(&[]) } else { Space::new() };
        drop(v118_8);
        let v118_10: Space = compose(&(v118_9),&v117_12_cursor);
        drop(v118_9);
        let v118_11: Space = wrap(&(v118_10),&v117_12_cursor.path()[v117_12_origin..(v117_12_origin + 1)]);
        drop(v118_10);
        let v118_12: Space = wrap(&(v118_11),&(*p1));
        drop(v118_11);
        let v118_13: Space = unite(&(v118_7),&(v118_12));
        drop(v118_12);
        join_wrapped_into(&mut v117_12_write,&((v118_13).read_zipper()),&[]);
        }
        v117_12_cursor.ascend(1);
      }
      drop(v117_12_cursor);
      drop(v117_12_write);
      compose(&(v115_10),&(v117_12))
    };
    drop(v115_10);
    let v115_14: Space = unite(&(v115_8),&(v115_13));
    join_wrapped_into(&mut v114_15_write,&((v115_14).read_zipper()),&[]);
    }
    v114_15_cursor.ascend(1);
  }
  drop(v114_15_cursor);
  drop(v114_15_write);
  (v114_15).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v120_15 = Space::new();
  let mut v120_15_write = v120_15.write_zipper();
  let mut v120_15_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23)),&(*CONSTANT_25)),&(*p0));
  let v120_15_origin = v120_15_cursor.path().len();
  for v120_15_byte in v120_15_cursor.child_mask().iter() {
    v120_15_cursor.descend_to_existing_byte(v120_15_byte);
    {
    let v121_2: Space = singleton(&v120_15_cursor.path()[v120_15_origin..(v120_15_origin + 1)]);
    let v121_3: Space = intersect(&(*CONSTANT_28),&(v121_2));
    let v121_4: Space = if has_head(&(v121_3)) { singleton(&[]) } else { Space::new() };
    drop(v121_3);
    let v121_5: Space = subtract(&(*CONSTANT_0),&(v121_4));
    drop(v121_4);
    let v121_7: Space = if (&(v121_5)).is_empty() { Space::new() } else {
      let mut v122_6 = Space::new();
      let mut v122_6_write = v122_6.write_zipper();
      for v122_6_byte in v120_15_cursor.child_mask().iter() {
        v120_15_cursor.descend_to_existing_byte(v122_6_byte);
        {
        let v123_2: Space = singleton(&v120_15_cursor.path()[(v120_15_origin + 1)..(v120_15_origin + 2)]);
        let v123_3: Space = intersect(&(*CONSTANT_28),&(v123_2));
        let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = subtract(&(*CONSTANT_0),&(v123_4));
        drop(v123_4);
        let v123_8: Space = if (&(v123_5)).is_empty() { Space::new() } else {
          let v124_7: Space = routine_13(c, &v120_15_cursor.path()[v120_15_origin..(v120_15_origin + 2)], &(*p1), &v120_15_cursor);
          compose(&(v123_5),&(v124_7))
        };
        drop(v123_5);
        let v123_9: Space = intersect(&(*CONSTANT_28),&(v123_2));
        drop(v123_2);
        let v123_10: Space = if has_head(&(v123_9)) { singleton(&[]) } else { Space::new() };
        drop(v123_9);
        let v123_11: Space = compose(&(v123_10),&v120_15_cursor);
        drop(v123_10);
        let v123_12: Space = wrap(&(v123_11),&v120_15_cursor.path()[v120_15_origin..(v120_15_origin + 2)]);
        drop(v123_11);
        let v123_13: Space = wrap(&(v123_12),&(*p1));
        drop(v123_12);
        let v123_14: Space = unite(&(v123_8),&(v123_13));
        drop(v123_13);
        join_wrapped_into(&mut v122_6_write,&((v123_14).read_zipper()),&[]);
        }
        v120_15_cursor.ascend(1);
      }
      drop(v122_6_write);
      compose(&(v121_5),&(v122_6))
    };
    drop(v121_5);
    let v121_8: Space = intersect(&(*CONSTANT_28),&(v121_2));
    drop(v121_2);
    let v121_9: Space = if has_head(&(v121_8)) { singleton(&[]) } else { Space::new() };
    drop(v121_8);
    let v121_10: Space = compose(&(v121_9),&v120_15_cursor);
    drop(v121_9);
    let v121_11: Space = wrap(&(v121_10),&v120_15_cursor.path()[v120_15_origin..(v120_15_origin + 1)]);
    drop(v121_10);
    let v121_12: Space = wrap(&(v121_11),&(*p1));
    drop(v121_11);
    let v121_13: Space = unite(&(v121_7),&(v121_12));
    drop(v121_12);
    join_wrapped_into(&mut v120_15_write,&((v121_13).read_zipper()),&[]);
    }
    v120_15_cursor.ascend(1);
  }
  drop(v120_15_cursor);
  drop(v120_15_write);
  (v120_15).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v126_6 = Space::new();
  let mut v126_6_write = v126_6.write_zipper();
  let mut v126_6_cursor = (*s0).read_zipper();
  let v126_6_origin = v126_6_cursor.path().len();
  for v126_6_byte in v126_6_cursor.child_mask().iter() {
    v126_6_cursor.descend_to_existing_byte(v126_6_byte);
    {
    let v127_2: Space = singleton(&v126_6_cursor.path()[v126_6_origin..(v126_6_origin + 1)]);
    let v127_3: Space = intersect(&(*CONSTANT_28),&(v127_2));
    let v127_4: Space = if has_head(&(v127_3)) { singleton(&[]) } else { Space::new() };
    drop(v127_3);
    let v127_5: Space = subtract(&(*CONSTANT_0),&(v127_4));
    drop(v127_4);
    let v127_8: Space = if (&(v127_5)).is_empty() { Space::new() } else {
      let v128_6: Path = concat_path(&(*p0),&v126_6_cursor.path()[v126_6_origin..(v126_6_origin + 1)]);
      let v128_7: Space = routine_13(c, &(v128_6), &(*p1), &v126_6_cursor);
      compose(&(v127_5),&(v128_7))
    };
    drop(v127_5);
    let v127_9: Space = intersect(&(*CONSTANT_28),&(v127_2));
    drop(v127_2);
    let v127_10: Space = if has_head(&(v127_9)) { singleton(&[]) } else { Space::new() };
    drop(v127_9);
    let v127_11: Space = compose(&(v127_10),&v126_6_cursor);
    drop(v127_10);
    let v129_6: Path = concat_path(&(*p0),&v126_6_cursor.path()[v126_6_origin..(v126_6_origin + 1)]);
    let v127_12: Space = wrap(&(v127_11),&(v129_6));
    drop(v127_11);
    let v127_13: Space = wrap(&(v127_12),&(*p1));
    drop(v127_12);
    let v127_14: Space = unite(&(v127_8),&(v127_13));
    drop(v127_13);
    join_wrapped_into(&mut v126_6_write,&((v127_14).read_zipper()),&[]);
    }
    v126_6_cursor.ascend(1);
  }
  drop(v126_6_cursor);
  drop(v126_6_write);
  (v126_6).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v130_3: Space = wrap(&(*s0),&(*p0));
  let v130_4: Space = wrap(&(v130_3),&(*p1));
  drop(v130_3);
  (v130_4).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v131_16 = Space::new();
  let mut v131_16_write = v131_16.write_zipper();
  let mut v131_16_cursor = (*s0).read_zipper();
  let v131_16_origin = v131_16_cursor.path().len();
  for v131_16_byte in v131_16_cursor.child_mask().iter() {
    v131_16_cursor.descend_to_existing_byte(v131_16_byte);
    {
    let v132_2: Space = singleton(&v131_16_cursor.path()[v131_16_origin..(v131_16_origin + 1)]);
    let v132_3: Space = intersect(&(*CONSTANT_28),&(v132_2));
    let v132_4: Space = if has_head(&(v132_3)) { singleton(&[]) } else { Space::new() };
    drop(v132_3);
    let v132_5: Space = subtract(&(*CONSTANT_0),&(v132_4));
    drop(v132_4);
    let v132_8: Space = if (&(v132_5)).is_empty() { Space::new() } else {
      let v133_6: Path = concat_path(&(*p0),&v131_16_cursor.path()[v131_16_origin..(v131_16_origin + 1)]);
      let v133_7: Space = routine_15(c, &(v133_6), &v131_16_cursor, &(*s1));
      compose(&(v132_5),&(v133_7))
    };
    drop(v132_5);
    let v132_9: Space = intersect(&(*CONSTANT_28),&(v132_2));
    drop(v132_2);
    let v132_10: Space = if has_head(&(v132_9)) { singleton(&[]) } else { Space::new() };
    drop(v132_9);
    let v132_12: Space = if (&(v132_10)).is_empty() { Space::new() } else {
      let v134_6: Path = concat_path(&(*p0),&v131_16_cursor.path()[v131_16_origin..(v131_16_origin + 1)]);
      let mut v134_11 = Space::new();
      let mut v134_11_write = v134_11.write_zipper();
      for v134_11_byte in v131_16_cursor.child_mask().iter() {
        v131_16_cursor.descend_to_existing_byte(v134_11_byte);
        {
        let v135_2: Space = singleton(&v131_16_cursor.path()[(v131_16_origin + 1)..(v131_16_origin + 2)]);
        let v135_3: Space = intersect(&(*CONSTANT_28),&(v135_2));
        let v135_4: Space = if has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
        drop(v135_3);
        let v135_5: Space = subtract(&(*CONSTANT_0),&(v135_4));
        drop(v135_4);
        let v135_7: Space = if (&(v135_5)).is_empty() { Space::new() } else {
          let v136_6: Space = routine_16(c, &v131_16_cursor.path()[(v131_16_origin + 1)..(v131_16_origin + 2)], &(v134_6), &v131_16_cursor, &(*s1));
          compose(&(v135_5),&(v136_6))
        };
        drop(v135_5);
        let v135_8: Space = intersect(&(*CONSTANT_28),&(v135_2));
        drop(v135_2);
        let v135_9: Space = if has_head(&(v135_8)) { singleton(&[]) } else { Space::new() };
        drop(v135_8);
        let v135_12: Space = if (&(v135_9)).is_empty() { Space::new() } else {
          let mut v137_11 = Space::new();
          let mut v137_11_write = v137_11.write_zipper();
          let mut v137_11_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_21)),&(*CONSTANT_25)),&v131_16_cursor.path()[(v131_16_origin + 1)..(v131_16_origin + 2)]);
          let v137_11_origin = v137_11_cursor.path().len();
          for v137_11_byte in v137_11_cursor.child_mask().iter() {
            v137_11_cursor.descend_to_existing_byte(v137_11_byte);
            {
            let v138_2: Space = singleton(&v137_11_cursor.path()[v137_11_origin..(v137_11_origin + 1)]);
            let v138_3: Space = intersect(&(*CONSTANT_28),&(v138_2));
            let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
            drop(v138_3);
            let v138_5: Space = subtract(&(*CONSTANT_0),&(v138_4));
            drop(v138_4);
            let v138_7: Space = if (&(v138_5)).is_empty() { Space::new() } else {
              let v139_6: Space = routine_18(c, &v137_11_cursor.path()[v137_11_origin..(v137_11_origin + 1)], &(v134_6), &v137_11_cursor);
              compose(&(v138_5),&(v139_6))
            };
            drop(v138_5);
            let v138_8: Space = intersect(&(*CONSTANT_28),&(v138_2));
            drop(v138_2);
            let v138_9: Space = if has_head(&(v138_8)) { singleton(&[]) } else { Space::new() };
            drop(v138_8);
            let v138_11: Space = if (&(v138_9)).is_empty() { Space::new() } else {
              let v140_10: Space = routine_19(c, &v137_11_cursor.path()[v137_11_origin..(v137_11_origin + 1)], &(v134_6), &v137_11_cursor);
              compose(&(v138_9),&(v140_10))
            };
            drop(v138_9);
            let v138_12: Space = unite(&(v138_7),&(v138_11));
            join_wrapped_into(&mut v137_11_write,&((v138_12).read_zipper()),&[]);
            }
            v137_11_cursor.ascend(1);
          }
          drop(v137_11_cursor);
          drop(v137_11_write);
          compose(&(v135_9),&(v137_11))
        };
        drop(v135_9);
        let v135_13: Space = unite(&(v135_7),&(v135_12));
        join_wrapped_into(&mut v134_11_write,&((v135_13).read_zipper()),&[]);
        }
        v131_16_cursor.ascend(1);
      }
      drop(v134_11_write);
      drop(v134_6);
      compose(&(v132_10),&(v134_11))
    };
    drop(v132_10);
    let v132_13: Space = unite(&(v132_8),&(v132_12));
    join_wrapped_into(&mut v131_16_write,&((v132_13).read_zipper()),&[]);
    }
    v131_16_cursor.ascend(1);
  }
  drop(v131_16_cursor);
  drop(v131_16_write);
  (v131_16).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v141_15 = Space::new();
  let mut v141_15_write = v141_15.write_zipper();
  let mut v141_15_cursor = (*s0).read_zipper();
  let v141_15_origin = v141_15_cursor.path().len();
  for v141_15_byte in v141_15_cursor.child_mask().iter() {
    v141_15_cursor.descend_to_existing_byte(v141_15_byte);
    {
    let v142_2: Space = singleton(&v141_15_cursor.path()[v141_15_origin..(v141_15_origin + 1)]);
    let v142_3: Space = intersect(&(*CONSTANT_28),&(v142_2));
    let v142_4: Space = if has_head(&(v142_3)) { singleton(&[]) } else { Space::new() };
    drop(v142_3);
    let v142_5: Space = subtract(&(*CONSTANT_0),&(v142_4));
    drop(v142_4);
    let v142_8: Space = if (&(v142_5)).is_empty() { Space::new() } else {
      let v143_6: Path = concat_path(&(*p0),&v141_15_cursor.path()[v141_15_origin..(v141_15_origin + 1)]);
      let v143_7: Space = routine_16(c, &(v143_6), &(*p1), &v141_15_cursor, &(*s1));
      drop(v143_6);
      compose(&(v142_5),&(v143_7))
    };
    drop(v142_5);
    let v142_9: Space = intersect(&(*CONSTANT_28),&(v142_2));
    drop(v142_2);
    let v142_10: Space = if has_head(&(v142_9)) { singleton(&[]) } else { Space::new() };
    drop(v142_9);
    let v142_13: Space = if (&(v142_10)).is_empty() { Space::new() } else {
      let mut v144_12 = Space::new();
      let mut v144_12_write = v144_12.write_zipper();
      let mut v144_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_21)),&(*CONSTANT_25)),&(*p0)),&v141_15_cursor.path()[v141_15_origin..(v141_15_origin + 1)]);
      let v144_12_origin = v144_12_cursor.path().len();
      for v144_12_byte in v144_12_cursor.child_mask().iter() {
        v144_12_cursor.descend_to_existing_byte(v144_12_byte);
        {
        let v145_2: Space = singleton(&v144_12_cursor.path()[v144_12_origin..(v144_12_origin + 1)]);
        let v145_3: Space = intersect(&(*CONSTANT_28),&(v145_2));
        let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
        drop(v145_3);
        let v145_5: Space = subtract(&(*CONSTANT_0),&(v145_4));
        drop(v145_4);
        let v145_7: Space = if (&(v145_5)).is_empty() { Space::new() } else {
          let v146_6: Space = routine_18(c, &v144_12_cursor.path()[v144_12_origin..(v144_12_origin + 1)], &(*p1), &v144_12_cursor);
          compose(&(v145_5),&(v146_6))
        };
        drop(v145_5);
        let v145_8: Space = intersect(&(*CONSTANT_28),&(v145_2));
        drop(v145_2);
        let v145_9: Space = if has_head(&(v145_8)) { singleton(&[]) } else { Space::new() };
        drop(v145_8);
        let v145_10: Space = compose(&(v145_9),&v144_12_cursor);
        drop(v145_9);
        let v145_11: Space = wrap(&(v145_10),&v144_12_cursor.path()[v144_12_origin..(v144_12_origin + 1)]);
        drop(v145_10);
        let v145_12: Space = wrap(&(v145_11),&(*p1));
        drop(v145_11);
        let v145_13: Space = unite(&(v145_7),&(v145_12));
        drop(v145_12);
        join_wrapped_into(&mut v144_12_write,&((v145_13).read_zipper()),&[]);
        }
        v144_12_cursor.ascend(1);
      }
      drop(v144_12_cursor);
      drop(v144_12_write);
      compose(&(v142_10),&(v144_12))
    };
    drop(v142_10);
    let v142_14: Space = unite(&(v142_8),&(v142_13));
    join_wrapped_into(&mut v141_15_write,&((v142_14).read_zipper()),&[]);
    }
    v141_15_cursor.ascend(1);
  }
  drop(v141_15_cursor);
  drop(v141_15_write);
  (v141_15).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v147_15 = Space::new();
  let mut v147_15_write = v147_15.write_zipper();
  let mut v147_15_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_21)),&(*CONSTANT_25)),&(*p0));
  let v147_15_origin = v147_15_cursor.path().len();
  for v147_15_byte in v147_15_cursor.child_mask().iter() {
    v147_15_cursor.descend_to_existing_byte(v147_15_byte);
    {
    let v148_2: Space = singleton(&v147_15_cursor.path()[v147_15_origin..(v147_15_origin + 1)]);
    let v148_3: Space = intersect(&(*CONSTANT_28),&(v148_2));
    let v148_4: Space = if has_head(&(v148_3)) { singleton(&[]) } else { Space::new() };
    drop(v148_3);
    let v148_5: Space = subtract(&(*CONSTANT_0),&(v148_4));
    drop(v148_4);
    let v148_7: Space = if (&(v148_5)).is_empty() { Space::new() } else {
      let mut v149_6 = Space::new();
      let mut v149_6_write = v149_6.write_zipper();
      for v149_6_byte in v147_15_cursor.child_mask().iter() {
        v147_15_cursor.descend_to_existing_byte(v149_6_byte);
        {
        let v150_2: Space = singleton(&v147_15_cursor.path()[(v147_15_origin + 1)..(v147_15_origin + 2)]);
        let v150_3: Space = intersect(&(*CONSTANT_28),&(v150_2));
        let v150_4: Space = if has_head(&(v150_3)) { singleton(&[]) } else { Space::new() };
        drop(v150_3);
        let v150_5: Space = subtract(&(*CONSTANT_0),&(v150_4));
        drop(v150_4);
        let v150_8: Space = if (&(v150_5)).is_empty() { Space::new() } else {
          let v151_7: Space = routine_18(c, &v147_15_cursor.path()[v147_15_origin..(v147_15_origin + 2)], &(*p1), &v147_15_cursor);
          compose(&(v150_5),&(v151_7))
        };
        drop(v150_5);
        let v150_9: Space = intersect(&(*CONSTANT_28),&(v150_2));
        drop(v150_2);
        let v150_10: Space = if has_head(&(v150_9)) { singleton(&[]) } else { Space::new() };
        drop(v150_9);
        let v150_11: Space = compose(&(v150_10),&v147_15_cursor);
        drop(v150_10);
        let v150_12: Space = wrap(&(v150_11),&v147_15_cursor.path()[v147_15_origin..(v147_15_origin + 2)]);
        drop(v150_11);
        let v150_13: Space = wrap(&(v150_12),&(*p1));
        drop(v150_12);
        let v150_14: Space = unite(&(v150_8),&(v150_13));
        drop(v150_13);
        join_wrapped_into(&mut v149_6_write,&((v150_14).read_zipper()),&[]);
        }
        v147_15_cursor.ascend(1);
      }
      drop(v149_6_write);
      compose(&(v148_5),&(v149_6))
    };
    drop(v148_5);
    let v148_8: Space = intersect(&(*CONSTANT_28),&(v148_2));
    drop(v148_2);
    let v148_9: Space = if has_head(&(v148_8)) { singleton(&[]) } else { Space::new() };
    drop(v148_8);
    let v148_10: Space = compose(&(v148_9),&v147_15_cursor);
    drop(v148_9);
    let v148_11: Space = wrap(&(v148_10),&v147_15_cursor.path()[v147_15_origin..(v147_15_origin + 1)]);
    drop(v148_10);
    let v148_12: Space = wrap(&(v148_11),&(*p1));
    drop(v148_11);
    let v148_13: Space = unite(&(v148_7),&(v148_12));
    drop(v148_12);
    join_wrapped_into(&mut v147_15_write,&((v148_13).read_zipper()),&[]);
    }
    v147_15_cursor.ascend(1);
  }
  drop(v147_15_cursor);
  drop(v147_15_write);
  (v147_15).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v153_6 = Space::new();
  let mut v153_6_write = v153_6.write_zipper();
  let mut v153_6_cursor = (*s0).read_zipper();
  let v153_6_origin = v153_6_cursor.path().len();
  for v153_6_byte in v153_6_cursor.child_mask().iter() {
    v153_6_cursor.descend_to_existing_byte(v153_6_byte);
    {
    let v154_2: Space = singleton(&v153_6_cursor.path()[v153_6_origin..(v153_6_origin + 1)]);
    let v154_3: Space = intersect(&(*CONSTANT_28),&(v154_2));
    let v154_4: Space = if has_head(&(v154_3)) { singleton(&[]) } else { Space::new() };
    drop(v154_3);
    let v154_5: Space = subtract(&(*CONSTANT_0),&(v154_4));
    drop(v154_4);
    let v154_8: Space = if (&(v154_5)).is_empty() { Space::new() } else {
      let v155_6: Path = concat_path(&(*p0),&v153_6_cursor.path()[v153_6_origin..(v153_6_origin + 1)]);
      let v155_7: Space = routine_18(c, &(v155_6), &(*p1), &v153_6_cursor);
      compose(&(v154_5),&(v155_7))
    };
    drop(v154_5);
    let v154_9: Space = intersect(&(*CONSTANT_28),&(v154_2));
    drop(v154_2);
    let v154_10: Space = if has_head(&(v154_9)) { singleton(&[]) } else { Space::new() };
    drop(v154_9);
    let v154_11: Space = compose(&(v154_10),&v153_6_cursor);
    drop(v154_10);
    let v156_6: Path = concat_path(&(*p0),&v153_6_cursor.path()[v153_6_origin..(v153_6_origin + 1)]);
    let v154_12: Space = wrap(&(v154_11),&(v156_6));
    drop(v154_11);
    let v154_13: Space = wrap(&(v154_12),&(*p1));
    drop(v154_12);
    let v154_14: Space = unite(&(v154_8),&(v154_13));
    drop(v154_13);
    join_wrapped_into(&mut v153_6_write,&((v154_14).read_zipper()),&[]);
    }
    v153_6_cursor.ascend(1);
  }
  drop(v153_6_cursor);
  drop(v153_6_write);
  (v153_6).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v157_3: Space = wrap(&(*s0),&(*p0));
  let v157_4: Space = wrap(&(v157_3),&(*p1));
  drop(v157_3);
  (v157_4).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v158_7 = Space::new();
  let mut v158_7_write = v158_7.write_zipper();
  let mut v158_7_cursor = (*s0).read_zipper();
  let v158_7_origin = v158_7_cursor.path().len();
  for v158_7_byte in v158_7_cursor.child_mask().iter() {
    v158_7_cursor.descend_to_existing_byte(v158_7_byte);
    {
    let v159_2: Space = singleton(&v158_7_cursor.path()[v158_7_origin..(v158_7_origin + 1)]);
    let v159_3: Space = intersect(&(*CONSTANT_28),&(v159_2));
    let v159_4: Space = if has_head(&(v159_3)) { singleton(&[]) } else { Space::new() };
    drop(v159_3);
    let v159_5: Space = compose(&(v159_4),&v158_7_cursor);
    drop(v159_4);
    let v160_6: Path = concat_path(&(*p0),&v158_7_cursor.path()[v158_7_origin..(v158_7_origin + 1)]);
    let v159_7: Space = wrap(&(v159_5),&(v160_6));
    drop(v159_5);
    let v159_8: Space = wrap(&(v159_7),&(*p1));
    drop(v159_7);
    let v159_9: Space = wrap(&(v159_8),&(*CONSTANT_25));
    drop(v159_8);
    let v159_10: Space = intersect(&(*CONSTANT_28),&(v159_2));
    drop(v159_2);
    let v159_11: Space = if has_head(&(v159_10)) { singleton(&[]) } else { Space::new() };
    drop(v159_10);
    let v159_12: Space = subtract(&(*CONSTANT_0),&(v159_11));
    drop(v159_11);
    let v159_14: Space = if (&(v159_12)).is_empty() { Space::new() } else {
      let v161_13: Space = routine_20(c, &(v160_6), &(*p1), &v158_7_cursor);
      compose(&(v159_12),&(v161_13))
    };
    drop(v159_12);
    let v159_15: Space = unite(&(v159_9),&(v159_14));
    drop(v159_9);
    join_wrapped_into(&mut v158_7_write,&((v159_15).read_zipper()),&[]);
    }
    v158_7_cursor.ascend(1);
  }
  drop(v158_7_cursor);
  drop(v158_7_write);
  (v158_7).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
