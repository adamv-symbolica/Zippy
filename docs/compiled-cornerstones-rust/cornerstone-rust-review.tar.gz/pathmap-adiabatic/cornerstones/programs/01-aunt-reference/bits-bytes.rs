#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1,0,1,1]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,1]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,0,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>, s1: Option<&Space>) -> Space {
  let mut v0_11 = Space::new();
  let mut v0_11_write = v0_11.write_zipper();
  let mut v0_11_cursor = (*s1.expect("unbound native input")).read_zipper();
  let v0_11_origin = v0_11_cursor.path().len();
  for v0_11_byte in v0_11_cursor.child_mask().iter() {
    v0_11_cursor.descend_to_existing_byte(v0_11_byte);
    {
    let v1_2: Space = singleton(&v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 1)]);
    let v1_3: Space = intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (&(v1_5)).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_write = v2_6.write_zipper();
      for v2_6_byte in v0_11_cursor.child_mask().iter() {
        v0_11_cursor.descend_to_existing_byte(v2_6_byte);
        {
        let v3_2: Space = singleton(&v0_11_cursor.path()[(v0_11_origin + 1)..(v0_11_origin + 2)]);
        let v3_3: Space = intersect(&(*CONSTANT_1),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_0),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (&(v3_5)).is_empty() { Space::new() } else {
          let v4_7: Space = routine_1(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_1),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (&(v3_10)).is_empty() { Space::new() } else {
          let v5_11: Space = routine_2(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        join_wrapped_into(&mut v2_6_write,&((v3_13).read_zipper()),&[]);
        }
        v0_11_cursor.ascend(1);
      }
      drop(v2_6_write);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (&(v1_9)).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_write = v6_10.write_zipper();
      for v6_10_byte in v0_11_cursor.child_mask().iter() {
        v0_11_cursor.descend_to_existing_byte(v6_10_byte);
        {
        let v7_2: Space = singleton(&v0_11_cursor.path()[(v0_11_origin + 1)..(v0_11_origin + 2)]);
        let v7_3: Space = intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (&(v7_5)).is_empty() { Space::new() } else {
          let v8_7: Space = routine_1(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (&(v7_10)).is_empty() { Space::new() } else {
          let v9_11: Space = routine_3(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        join_wrapped_into(&mut v6_10_write,&((v7_13).read_zipper()),&[]);
        }
        v0_11_cursor.ascend(1);
      }
      drop(v6_10_write);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    join_wrapped_into(&mut v0_11_write,&((v1_12).read_zipper()),&[]);
    }
    v0_11_cursor.ascend(1);
  }
  drop(v0_11_cursor);
  drop(v0_11_write);
  let v0_13: Space = wrap(&(v0_11),&(*CONSTANT_2));
  (v0_13).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v10_34 = Space::new();
  let mut v10_34_write = v10_34.write_zipper();
  let mut v10_34_cursor = (*s0).read_zipper();
  let v10_34_origin = v10_34_cursor.path().len();
  for v10_34_byte in v10_34_cursor.child_mask().iter() {
    v10_34_cursor.descend_to_existing_byte(v10_34_byte);
    {
    let v11_2: Space = singleton(&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]);
    let v11_3: Space = intersect(&(*CONSTANT_1),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (&(v11_5)).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]);
      let mut v12_7 = Space::new();
      let mut v12_7_write = v12_7.write_zipper();
      for v12_7_byte in v10_34_cursor.child_mask().iter() {
        v10_34_cursor.descend_to_existing_byte(v12_7_byte);
        {
        let v13_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
        let v13_3: Space = intersect(&(*CONSTANT_1),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_0),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (&(v13_5)).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v12_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
          let mut v14_7 = Space::new();
          let mut v14_7_write = v14_7.write_zipper();
          for v14_7_byte in v10_34_cursor.child_mask().iter() {
            v10_34_cursor.descend_to_existing_byte(v14_7_byte);
            {
            let v15_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
            let v15_3: Space = intersect(&(*CONSTANT_1),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (&(v15_5)).is_empty() { Space::new() } else {
              let v16_6: Path = concat_path(&(v14_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v16_7: Space = routine_4(c, &(v16_6), &v10_34_cursor, &(*s1));
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_1),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (&(v15_10)).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v14_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v17_11: Space = routine_5(c, &(v17_6), &v10_34_cursor, &(*s1));
              drop(v17_6);
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            join_wrapped_into(&mut v14_7_write,&((v15_13).read_zipper()),&[]);
            }
            v10_34_cursor.ascend(1);
          }
          drop(v14_7_write);
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_1),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (&(v13_10)).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v12_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
          let mut v18_11 = Space::new();
          let mut v18_11_write = v18_11.write_zipper();
          for v18_11_byte in v10_34_cursor.child_mask().iter() {
            v10_34_cursor.descend_to_existing_byte(v18_11_byte);
            {
            let v19_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
            let v19_3: Space = intersect(&(*CONSTANT_1),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
            drop(v19_4);
            let v19_8: Space = if (&(v19_5)).is_empty() { Space::new() } else {
              let v20_6: Path = concat_path(&(v18_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v20_7: Space = routine_4(c, &(v20_6), &v10_34_cursor, &(*s1));
              compose(&(v19_5),&(v20_7))
            };
            drop(v19_5);
            let v19_9: Space = intersect(&(*CONSTANT_1),&(v19_2));
            drop(v19_2);
            let v19_10: Space = if has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
            drop(v19_9);
            let v19_12: Space = if (&(v19_10)).is_empty() { Space::new() } else {
              let v21_6: Path = concat_path(&(v18_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v21_11: Space = routine_3(c, &(v21_6), &v10_34_cursor, &(*s1));
              drop(v21_6);
              compose(&(v19_10),&(v21_11))
            };
            drop(v19_10);
            let v19_13: Space = unite(&(v19_8),&(v19_12));
            join_wrapped_into(&mut v18_11_write,&((v19_13).read_zipper()),&[]);
            }
            v10_34_cursor.ascend(1);
          }
          drop(v18_11_write);
          drop(v18_6);
          compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        join_wrapped_into(&mut v12_7_write,&((v13_13).read_zipper()),&[]);
        }
        v10_34_cursor.ascend(1);
      }
      drop(v12_7_write);
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_1),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_13: Space = if (&(v11_10)).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]);
      let mut v22_12 = Space::new();
      let mut v22_12_write = v22_12.write_zipper();
      for v22_12_byte in v10_34_cursor.child_mask().iter() {
        v10_34_cursor.descend_to_existing_byte(v22_12_byte);
        {
        let v23_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
        let v23_3: Space = intersect(&(*CONSTANT_1),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_0),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (&(v23_5)).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v22_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
          let mut v24_7 = Space::new();
          let mut v24_7_write = v24_7.write_zipper();
          for v24_7_byte in v10_34_cursor.child_mask().iter() {
            v10_34_cursor.descend_to_existing_byte(v24_7_byte);
            {
            let v25_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
            let v25_3: Space = intersect(&(*CONSTANT_1),&(v25_2));
            let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
            drop(v25_3);
            let v25_5: Space = subtract(&(*CONSTANT_0),&(v25_4));
            drop(v25_4);
            let v25_8: Space = if (&(v25_5)).is_empty() { Space::new() } else {
              let v26_6: Path = concat_path(&(v24_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v26_7: Space = routine_4(c, &(v26_6), &v10_34_cursor, &(*s1));
              compose(&(v25_5),&(v26_7))
            };
            drop(v25_5);
            let v25_9: Space = intersect(&(*CONSTANT_1),&(v25_2));
            drop(v25_2);
            let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
            drop(v25_9);
            let v25_12: Space = if (&(v25_10)).is_empty() { Space::new() } else {
              let v27_6: Path = concat_path(&(v24_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v27_11: Space = routine_5(c, &(v27_6), &v10_34_cursor, &(*s1));
              drop(v27_6);
              compose(&(v25_10),&(v27_11))
            };
            drop(v25_10);
            let v25_13: Space = unite(&(v25_8),&(v25_12));
            join_wrapped_into(&mut v24_7_write,&((v25_13).read_zipper()),&[]);
            }
            v10_34_cursor.ascend(1);
          }
          drop(v24_7_write);
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_1),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_18: Space = if (&(v23_10)).is_empty() { Space::new() } else {
          let v28_12: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)])));
          let mut v28_13 = Space::new();
          let mut v28_13_write = v28_13.write_zipper();
          let mut v28_13_cursor = (v28_12).read_zipper();
          let v28_13_origin = v28_13_cursor.path().len();
          for v28_13_byte in v28_13_cursor.child_mask().iter() {
            v28_13_cursor.descend_to_existing_byte(v28_13_byte);
            {
            let v29_2: Space = singleton(&v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)]);
            let v29_3: Space = intersect(&(*CONSTANT_1),&(v29_2));
            let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
            drop(v29_3);
            let v29_5: Space = subtract(&(*CONSTANT_0),&(v29_4));
            drop(v29_4);
            let v29_7: Space = if (&(v29_5)).is_empty() { Space::new() } else {
              let v30_6: Space = routine_6(c, &v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)], &v28_13_cursor);
              compose(&(v29_5),&(v30_6))
            };
            drop(v29_5);
            let v29_8: Space = intersect(&(*CONSTANT_1),&(v29_2));
            drop(v29_2);
            let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
            drop(v29_8);
            let v29_11: Space = if (&(v29_9)).is_empty() { Space::new() } else {
              let v31_10: Space = routine_7(c, &v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)], &v28_13_cursor);
              compose(&(v29_9),&(v31_10))
            };
            drop(v29_9);
            let v29_12: Space = unite(&(v29_7),&(v29_11));
            join_wrapped_into(&mut v28_13_write,&((v29_12).read_zipper()),&[]);
            }
            v28_13_cursor.ascend(1);
          }
          drop(v28_13_cursor);
          drop(v28_13_write);
          drop(v28_12);
          let v28_14: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v28_13));
          let mut v28_15 = Space::new();
          let mut v28_15_write = v28_15.write_zipper();
          let mut v28_15_cursor = (v28_14).read_zipper();
          let v28_15_origin = v28_15_cursor.path().len();
          for v28_15_byte in v28_15_cursor.child_mask().iter() {
            v28_15_cursor.descend_to_existing_byte(v28_15_byte);
            {
            let v32_2: Space = singleton(&v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)]);
            let v32_3: Space = intersect(&(*CONSTANT_1),&(v32_2));
            let v32_4: Space = if has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
            drop(v32_3);
            let v32_5: Space = subtract(&(*CONSTANT_0),&(v32_4));
            drop(v32_4);
            let v32_7: Space = if (&(v32_5)).is_empty() { Space::new() } else {
              let v33_6: Space = routine_8(c, &v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)], &v28_15_cursor);
              compose(&(v32_5),&(v33_6))
            };
            drop(v32_5);
            let v32_8: Space = intersect(&(*CONSTANT_1),&(v32_2));
            drop(v32_2);
            let v32_9: Space = if has_head(&(v32_8)) { singleton(&[]) } else { Space::new() };
            drop(v32_8);
            let v32_11: Space = if (&(v32_9)).is_empty() { Space::new() } else {
              let v34_10: Space = routine_9(c, &v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)], &v28_15_cursor);
              compose(&(v32_9),&(v34_10))
            };
            drop(v32_9);
            let v32_12: Space = unite(&(v32_7),&(v32_11));
            join_wrapped_into(&mut v28_15_write,&((v32_12).read_zipper()),&[]);
            }
            v28_15_cursor.ascend(1);
          }
          drop(v28_15_cursor);
          drop(v28_15_write);
          let v28_16: Space = subtract(&(v28_15),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)])));
          let v28_17: Space = intersect(&(v28_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
          compose(&(v23_10),&(v28_17))
        };
        drop(v23_10);
        let v35_6: Path = concat_path(&(v22_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
        let v23_19: Space = wrap(&(v23_18),&(v35_6));
        let v23_20: Space = unite(&(v23_8),&(v23_19));
        join_wrapped_into(&mut v22_12_write,&((v23_20).read_zipper()),&[]);
        }
        v10_34_cursor.ascend(1);
      }
      drop(v22_12_write);
      drop(v22_6);
      compose(&(v11_10),&(v22_12))
    };
    drop(v11_10);
    let v11_14: Space = unite(&(v11_8),&(v11_13));
    join_wrapped_into(&mut v10_34_write,&((v11_14).read_zipper()),&[]);
    }
    v10_34_cursor.ascend(1);
  }
  drop(v10_34_cursor);
  drop(v10_34_write);
  (v10_34).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v36_40 = Space::new();
  let mut v36_40_write = v36_40.write_zipper();
  let mut v36_40_cursor = (*s0).read_zipper();
  let v36_40_origin = v36_40_cursor.path().len();
  for v36_40_byte in v36_40_cursor.child_mask().iter() {
    v36_40_cursor.descend_to_existing_byte(v36_40_byte);
    {
    let v37_2: Space = singleton(&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)]);
    let v37_3: Space = intersect(&(*CONSTANT_1),&(v37_2));
    let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
    drop(v37_3);
    let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
    drop(v37_4);
    let v37_8: Space = if (&(v37_5)).is_empty() { Space::new() } else {
      let v38_6: Path = concat_path(&(*p0),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)]);
      let mut v38_7 = Space::new();
      let mut v38_7_write = v38_7.write_zipper();
      for v38_7_byte in v36_40_cursor.child_mask().iter() {
        v36_40_cursor.descend_to_existing_byte(v38_7_byte);
        {
        let v39_2: Space = singleton(&v36_40_cursor.path()[(v36_40_origin + 1)..(v36_40_origin + 2)]);
        let v39_3: Space = intersect(&(*CONSTANT_1),&(v39_2));
        let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_8: Space = if (&(v39_5)).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v38_6),&v36_40_cursor.path()[(v36_40_origin + 1)..(v36_40_origin + 2)]);
          let mut v40_7 = Space::new();
          let mut v40_7_write = v40_7.write_zipper();
          for v40_7_byte in v36_40_cursor.child_mask().iter() {
            v36_40_cursor.descend_to_existing_byte(v40_7_byte);
            {
            let v41_2: Space = singleton(&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
            let v41_3: Space = intersect(&(*CONSTANT_1),&(v41_2));
            let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
            drop(v41_4);
            let v41_8: Space = if (&(v41_5)).is_empty() { Space::new() } else {
              let v42_6: Path = concat_path(&(v40_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v42_7: Space = routine_4(c, &(v42_6), &v36_40_cursor, &(*s1));
              compose(&(v41_5),&(v42_7))
            };
            drop(v41_5);
            let v41_9: Space = intersect(&(*CONSTANT_1),&(v41_2));
            drop(v41_2);
            let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
            drop(v41_9);
            let v41_12: Space = if (&(v41_10)).is_empty() { Space::new() } else {
              let v43_6: Path = concat_path(&(v40_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v43_11: Space = routine_5(c, &(v43_6), &v36_40_cursor, &(*s1));
              drop(v43_6);
              compose(&(v41_10),&(v43_11))
            };
            drop(v41_10);
            let v41_13: Space = unite(&(v41_8),&(v41_12));
            join_wrapped_into(&mut v40_7_write,&((v41_13).read_zipper()),&[]);
            }
            v36_40_cursor.ascend(1);
          }
          drop(v40_7_write);
          compose(&(v39_5),&(v40_7))
        };
        drop(v39_5);
        let v39_9: Space = intersect(&(*CONSTANT_1),&(v39_2));
        drop(v39_2);
        let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
        drop(v39_9);
        let v39_12: Space = if (&(v39_10)).is_empty() { Space::new() } else {
          let v44_6: Path = concat_path(&(v38_6),&v36_40_cursor.path()[(v36_40_origin + 1)..(v36_40_origin + 2)]);
          let mut v44_11 = Space::new();
          let mut v44_11_write = v44_11.write_zipper();
          for v44_11_byte in v36_40_cursor.child_mask().iter() {
            v36_40_cursor.descend_to_existing_byte(v44_11_byte);
            {
            let v45_2: Space = singleton(&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
            let v45_3: Space = intersect(&(*CONSTANT_1),&(v45_2));
            let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
            drop(v45_3);
            let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
            drop(v45_4);
            let v45_8: Space = if (&(v45_5)).is_empty() { Space::new() } else {
              let v46_6: Path = concat_path(&(v44_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v46_7: Space = routine_4(c, &(v46_6), &v36_40_cursor, &(*s1));
              compose(&(v45_5),&(v46_7))
            };
            drop(v45_5);
            let v45_9: Space = intersect(&(*CONSTANT_1),&(v45_2));
            drop(v45_2);
            let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
            drop(v45_9);
            let v45_12: Space = if (&(v45_10)).is_empty() { Space::new() } else {
              let v47_6: Path = concat_path(&(v44_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v47_11: Space = routine_3(c, &(v47_6), &v36_40_cursor, &(*s1));
              drop(v47_6);
              compose(&(v45_10),&(v47_11))
            };
            drop(v45_10);
            let v45_13: Space = unite(&(v45_8),&(v45_12));
            join_wrapped_into(&mut v44_11_write,&((v45_13).read_zipper()),&[]);
            }
            v36_40_cursor.ascend(1);
          }
          drop(v44_11_write);
          drop(v44_6);
          compose(&(v39_10),&(v44_11))
        };
        drop(v39_10);
        let v39_13: Space = unite(&(v39_8),&(v39_12));
        join_wrapped_into(&mut v38_7_write,&((v39_13).read_zipper()),&[]);
        }
        v36_40_cursor.ascend(1);
      }
      drop(v38_7_write);
      compose(&(v37_5),&(v38_7))
    };
    drop(v37_5);
    let v37_9: Space = intersect(&(*CONSTANT_1),&(v37_2));
    drop(v37_2);
    let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
    drop(v37_9);
    let v37_18: Space = if (&(v37_10)).is_empty() { Space::new() } else {
      let v48_12: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)])));
      let mut v48_13 = Space::new();
      let mut v48_13_write = v48_13.write_zipper();
      let mut v48_13_cursor = (v48_12).read_zipper();
      let v48_13_origin = v48_13_cursor.path().len();
      for v48_13_byte in v48_13_cursor.child_mask().iter() {
        v48_13_cursor.descend_to_existing_byte(v48_13_byte);
        {
        let v49_2: Space = singleton(&v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 1)]);
        let v49_3: Space = intersect(&(*CONSTANT_1),&(v49_2));
        let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
        drop(v49_3);
        let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
        drop(v49_4);
        let v49_7: Space = if (&(v49_5)).is_empty() { Space::new() } else {
          let mut v50_6 = Space::new();
          let mut v50_6_write = v50_6.write_zipper();
          for v50_6_byte in v48_13_cursor.child_mask().iter() {
            v48_13_cursor.descend_to_existing_byte(v50_6_byte);
            {
            let v51_2: Space = singleton(&v48_13_cursor.path()[(v48_13_origin + 1)..(v48_13_origin + 2)]);
            let v51_3: Space = intersect(&(*CONSTANT_1),&(v51_2));
            let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
            drop(v51_3);
            let v51_5: Space = subtract(&(*CONSTANT_0),&(v51_4));
            drop(v51_4);
            let v51_8: Space = if (&(v51_5)).is_empty() { Space::new() } else {
              let v52_7: Space = routine_10(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v51_5),&(v52_7))
            };
            drop(v51_5);
            let v51_9: Space = intersect(&(*CONSTANT_1),&(v51_2));
            drop(v51_2);
            let v51_10: Space = if has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
            drop(v51_9);
            let v51_12: Space = if (&(v51_10)).is_empty() { Space::new() } else {
              let v53_11: Space = routine_11(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v51_10),&(v53_11))
            };
            drop(v51_10);
            let v51_13: Space = unite(&(v51_8),&(v51_12));
            join_wrapped_into(&mut v50_6_write,&((v51_13).read_zipper()),&[]);
            }
            v48_13_cursor.ascend(1);
          }
          drop(v50_6_write);
          compose(&(v49_5),&(v50_6))
        };
        drop(v49_5);
        let v49_8: Space = intersect(&(*CONSTANT_1),&(v49_2));
        drop(v49_2);
        let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
        drop(v49_8);
        let v49_11: Space = if (&(v49_9)).is_empty() { Space::new() } else {
          let mut v54_10 = Space::new();
          let mut v54_10_write = v54_10.write_zipper();
          for v54_10_byte in v48_13_cursor.child_mask().iter() {
            v48_13_cursor.descend_to_existing_byte(v54_10_byte);
            {
            let v55_2: Space = singleton(&v48_13_cursor.path()[(v48_13_origin + 1)..(v48_13_origin + 2)]);
            let v55_3: Space = intersect(&(*CONSTANT_1),&(v55_2));
            let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
            drop(v55_3);
            let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
            drop(v55_4);
            let v55_8: Space = if (&(v55_5)).is_empty() { Space::new() } else {
              let v56_7: Space = routine_10(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v55_5),&(v56_7))
            };
            drop(v55_5);
            let v55_9: Space = intersect(&(*CONSTANT_1),&(v55_2));
            drop(v55_2);
            let v55_10: Space = if has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
            drop(v55_9);
            let v55_12: Space = if (&(v55_10)).is_empty() { Space::new() } else {
              let v57_11: Space = routine_12(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v55_10),&(v57_11))
            };
            drop(v55_10);
            let v55_13: Space = unite(&(v55_8),&(v55_12));
            join_wrapped_into(&mut v54_10_write,&((v55_13).read_zipper()),&[]);
            }
            v48_13_cursor.ascend(1);
          }
          drop(v54_10_write);
          compose(&(v49_9),&(v54_10))
        };
        drop(v49_9);
        let v49_12: Space = unite(&(v49_7),&(v49_11));
        join_wrapped_into(&mut v48_13_write,&((v49_12).read_zipper()),&[]);
        }
        v48_13_cursor.ascend(1);
      }
      drop(v48_13_cursor);
      drop(v48_13_write);
      drop(v48_12);
      let v48_14: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v48_13));
      let mut v48_15 = Space::new();
      let mut v48_15_write = v48_15.write_zipper();
      let mut v48_15_cursor = (v48_14).read_zipper();
      let v48_15_origin = v48_15_cursor.path().len();
      for v48_15_byte in v48_15_cursor.child_mask().iter() {
        v48_15_cursor.descend_to_existing_byte(v48_15_byte);
        {
        let v58_2: Space = singleton(&v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 1)]);
        let v58_3: Space = intersect(&(*CONSTANT_1),&(v58_2));
        let v58_4: Space = if has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
        drop(v58_3);
        let v58_5: Space = subtract(&(*CONSTANT_0),&(v58_4));
        drop(v58_4);
        let v58_7: Space = if (&(v58_5)).is_empty() { Space::new() } else {
          let mut v59_6 = Space::new();
          let mut v59_6_write = v59_6.write_zipper();
          for v59_6_byte in v48_15_cursor.child_mask().iter() {
            v48_15_cursor.descend_to_existing_byte(v59_6_byte);
            {
            let v60_2: Space = singleton(&v48_15_cursor.path()[(v48_15_origin + 1)..(v48_15_origin + 2)]);
            let v60_3: Space = intersect(&(*CONSTANT_1),&(v60_2));
            let v60_4: Space = if has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
            drop(v60_3);
            let v60_5: Space = subtract(&(*CONSTANT_0),&(v60_4));
            drop(v60_4);
            let v60_8: Space = if (&(v60_5)).is_empty() { Space::new() } else {
              let v61_7: Space = routine_13(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v60_5),&(v61_7))
            };
            drop(v60_5);
            let v60_9: Space = intersect(&(*CONSTANT_1),&(v60_2));
            drop(v60_2);
            let v60_10: Space = if has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
            drop(v60_9);
            let v60_12: Space = if (&(v60_10)).is_empty() { Space::new() } else {
              let v62_11: Space = routine_14(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v60_10),&(v62_11))
            };
            drop(v60_10);
            let v60_13: Space = unite(&(v60_8),&(v60_12));
            join_wrapped_into(&mut v59_6_write,&((v60_13).read_zipper()),&[]);
            }
            v48_15_cursor.ascend(1);
          }
          drop(v59_6_write);
          compose(&(v58_5),&(v59_6))
        };
        drop(v58_5);
        let v58_8: Space = intersect(&(*CONSTANT_1),&(v58_2));
        drop(v58_2);
        let v58_9: Space = if has_head(&(v58_8)) { singleton(&[]) } else { Space::new() };
        drop(v58_8);
        let v58_11: Space = if (&(v58_9)).is_empty() { Space::new() } else {
          let mut v63_10 = Space::new();
          let mut v63_10_write = v63_10.write_zipper();
          for v63_10_byte in v48_15_cursor.child_mask().iter() {
            v48_15_cursor.descend_to_existing_byte(v63_10_byte);
            {
            let v64_2: Space = singleton(&v48_15_cursor.path()[(v48_15_origin + 1)..(v48_15_origin + 2)]);
            let v64_3: Space = intersect(&(*CONSTANT_1),&(v64_2));
            let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
            drop(v64_3);
            let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
            drop(v64_4);
            let v64_8: Space = if (&(v64_5)).is_empty() { Space::new() } else {
              let v65_7: Space = routine_13(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v64_5),&(v65_7))
            };
            drop(v64_5);
            let v64_9: Space = intersect(&(*CONSTANT_1),&(v64_2));
            drop(v64_2);
            let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
            drop(v64_9);
            let v64_12: Space = if (&(v64_10)).is_empty() { Space::new() } else {
              let v66_11: Space = routine_15(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v64_10),&(v66_11))
            };
            drop(v64_10);
            let v64_13: Space = unite(&(v64_8),&(v64_12));
            join_wrapped_into(&mut v63_10_write,&((v64_13).read_zipper()),&[]);
            }
            v48_15_cursor.ascend(1);
          }
          drop(v63_10_write);
          compose(&(v58_9),&(v63_10))
        };
        drop(v58_9);
        let v58_12: Space = unite(&(v58_7),&(v58_11));
        join_wrapped_into(&mut v48_15_write,&((v58_12).read_zipper()),&[]);
        }
        v48_15_cursor.ascend(1);
      }
      drop(v48_15_cursor);
      drop(v48_15_write);
      let v48_16: Space = subtract(&(v48_15),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)])));
      let v48_17: Space = intersect(&(v48_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
      compose(&(v37_10),&(v48_17))
    };
    drop(v37_10);
    let v67_6: Path = concat_path(&(*p0),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)]);
    let v37_19: Space = wrap(&(v37_18),&(v67_6));
    let v37_20: Space = unite(&(v37_8),&(v37_19));
    join_wrapped_into(&mut v36_40_write,&((v37_20).read_zipper()),&[]);
    }
    v36_40_cursor.ascend(1);
  }
  drop(v36_40_cursor);
  drop(v36_40_write);
  (v36_40).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v68_8: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0))));
  let mut v68_27 = Space::new();
  let mut v68_27_write = v68_27.write_zipper();
  let mut v68_27_cursor = (v68_8).read_zipper();
  let v68_27_origin = v68_27_cursor.path().len();
  for v68_27_byte in v68_27_cursor.child_mask().iter() {
    v68_27_cursor.descend_to_existing_byte(v68_27_byte);
    {
    let v69_2: Space = singleton(&v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 1)]);
    let v69_3: Space = intersect(&(*CONSTANT_1),&(v69_2));
    let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
    drop(v69_3);
    let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
    drop(v69_4);
    let v69_7: Space = if (&(v69_5)).is_empty() { Space::new() } else {
      let mut v70_6 = Space::new();
      let mut v70_6_write = v70_6.write_zipper();
      for v70_6_byte in v68_27_cursor.child_mask().iter() {
        v68_27_cursor.descend_to_existing_byte(v70_6_byte);
        {
        let v71_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 1)..(v68_27_origin + 2)]);
        let v71_3: Space = intersect(&(*CONSTANT_1),&(v71_2));
        let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
        drop(v71_3);
        let v71_5: Space = subtract(&(*CONSTANT_0),&(v71_4));
        drop(v71_4);
        let v71_8: Space = if (&(v71_5)).is_empty() { Space::new() } else {
          let mut v72_7 = Space::new();
          let mut v72_7_write = v72_7.write_zipper();
          for v72_7_byte in v68_27_cursor.child_mask().iter() {
            v68_27_cursor.descend_to_existing_byte(v72_7_byte);
            {
            let v73_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 2)..(v68_27_origin + 3)]);
            let v73_3: Space = intersect(&(*CONSTANT_1),&(v73_2));
            let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
            drop(v73_3);
            let v73_5: Space = subtract(&(*CONSTANT_0),&(v73_4));
            drop(v73_4);
            let v73_8: Space = if (&(v73_5)).is_empty() { Space::new() } else {
              let v74_7: Space = routine_16(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v73_5),&(v74_7))
            };
            drop(v73_5);
            let v73_9: Space = intersect(&(*CONSTANT_1),&(v73_2));
            drop(v73_2);
            let v73_10: Space = if has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
            drop(v73_9);
            let v73_12: Space = if (&(v73_10)).is_empty() { Space::new() } else {
              let v75_11: Space = routine_17(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v73_10),&(v75_11))
            };
            drop(v73_10);
            let v73_13: Space = unite(&(v73_8),&(v73_12));
            join_wrapped_into(&mut v72_7_write,&((v73_13).read_zipper()),&[]);
            }
            v68_27_cursor.ascend(1);
          }
          drop(v72_7_write);
          compose(&(v71_5),&(v72_7))
        };
        drop(v71_5);
        let v71_9: Space = intersect(&(*CONSTANT_1),&(v71_2));
        drop(v71_2);
        let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
        drop(v71_9);
        let v71_12: Space = if (&(v71_10)).is_empty() { Space::new() } else {
          let mut v76_11 = Space::new();
          let mut v76_11_write = v76_11.write_zipper();
          for v76_11_byte in v68_27_cursor.child_mask().iter() {
            v68_27_cursor.descend_to_existing_byte(v76_11_byte);
            {
            let v77_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 2)..(v68_27_origin + 3)]);
            let v77_3: Space = intersect(&(*CONSTANT_1),&(v77_2));
            let v77_4: Space = if has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
            drop(v77_3);
            let v77_5: Space = subtract(&(*CONSTANT_0),&(v77_4));
            drop(v77_4);
            let v77_8: Space = if (&(v77_5)).is_empty() { Space::new() } else {
              let v78_7: Space = routine_16(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v77_5),&(v78_7))
            };
            drop(v77_5);
            let v77_9: Space = intersect(&(*CONSTANT_1),&(v77_2));
            drop(v77_2);
            let v77_10: Space = if has_head(&(v77_9)) { singleton(&[]) } else { Space::new() };
            drop(v77_9);
            let v77_12: Space = if (&(v77_10)).is_empty() { Space::new() } else {
              let v79_11: Space = routine_12(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v77_10),&(v79_11))
            };
            drop(v77_10);
            let v77_13: Space = unite(&(v77_8),&(v77_12));
            join_wrapped_into(&mut v76_11_write,&((v77_13).read_zipper()),&[]);
            }
            v68_27_cursor.ascend(1);
          }
          drop(v76_11_write);
          compose(&(v71_10),&(v76_11))
        };
        drop(v71_10);
        let v71_13: Space = unite(&(v71_8),&(v71_12));
        join_wrapped_into(&mut v70_6_write,&((v71_13).read_zipper()),&[]);
        }
        v68_27_cursor.ascend(1);
      }
      drop(v70_6_write);
      compose(&(v69_5),&(v70_6))
    };
    drop(v69_5);
    let v69_8: Space = intersect(&(*CONSTANT_1),&(v69_2));
    drop(v69_2);
    let v69_9: Space = if has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
    drop(v69_8);
    let v69_11: Space = if (&(v69_9)).is_empty() { Space::new() } else {
      let mut v80_10 = Space::new();
      let mut v80_10_write = v80_10.write_zipper();
      for v80_10_byte in v68_27_cursor.child_mask().iter() {
        v68_27_cursor.descend_to_existing_byte(v80_10_byte);
        {
        let v81_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 1)..(v68_27_origin + 2)]);
        let v81_3: Space = intersect(&(*CONSTANT_1),&(v81_2));
        let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
        drop(v81_3);
        let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
        drop(v81_4);
        let v81_8: Space = if (&(v81_5)).is_empty() { Space::new() } else {
          let mut v82_7 = Space::new();
          let mut v82_7_write = v82_7.write_zipper();
          for v82_7_byte in v68_27_cursor.child_mask().iter() {
            v68_27_cursor.descend_to_existing_byte(v82_7_byte);
            {
            let v83_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 2)..(v68_27_origin + 3)]);
            let v83_3: Space = intersect(&(*CONSTANT_1),&(v83_2));
            let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
            drop(v83_3);
            let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
            drop(v83_4);
            let v83_8: Space = if (&(v83_5)).is_empty() { Space::new() } else {
              let v84_7: Space = routine_16(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v83_5),&(v84_7))
            };
            drop(v83_5);
            let v83_9: Space = intersect(&(*CONSTANT_1),&(v83_2));
            drop(v83_2);
            let v83_10: Space = if has_head(&(v83_9)) { singleton(&[]) } else { Space::new() };
            drop(v83_9);
            let v83_12: Space = if (&(v83_10)).is_empty() { Space::new() } else {
              let v85_11: Space = routine_17(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v83_10),&(v85_11))
            };
            drop(v83_10);
            let v83_13: Space = unite(&(v83_8),&(v83_12));
            join_wrapped_into(&mut v82_7_write,&((v83_13).read_zipper()),&[]);
            }
            v68_27_cursor.ascend(1);
          }
          drop(v82_7_write);
          compose(&(v81_5),&(v82_7))
        };
        drop(v81_5);
        let v81_9: Space = intersect(&(*CONSTANT_1),&(v81_2));
        drop(v81_2);
        let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
        drop(v81_9);
        let v81_11: Space = compose(&(v81_10),&v68_27_cursor);
        drop(v81_10);
        let v81_12: Space = unite(&(v81_8),&(v81_11));
        drop(v81_11);
        join_wrapped_into(&mut v80_10_write,&((v81_12).read_zipper()),&[]);
        }
        v68_27_cursor.ascend(1);
      }
      drop(v80_10_write);
      compose(&(v69_9),&(v80_10))
    };
    drop(v69_9);
    let v69_12: Space = unite(&(v69_7),&(v69_11));
    join_wrapped_into(&mut v68_27_write,&((v69_12).read_zipper()),&[]);
    }
    v68_27_cursor.ascend(1);
  }
  drop(v68_27_cursor);
  drop(v68_27_write);
  drop(v68_8);
  let v68_28: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v68_27));
  let mut v68_47 = Space::new();
  let mut v68_47_write = v68_47.write_zipper();
  let mut v68_47_cursor = (v68_28).read_zipper();
  let v68_47_origin = v68_47_cursor.path().len();
  for v68_47_byte in v68_47_cursor.child_mask().iter() {
    v68_47_cursor.descend_to_existing_byte(v68_47_byte);
    {
    let v86_2: Space = singleton(&v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 1)]);
    let v86_3: Space = intersect(&(*CONSTANT_1),&(v86_2));
    let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
    drop(v86_3);
    let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
    drop(v86_4);
    let v86_7: Space = if (&(v86_5)).is_empty() { Space::new() } else {
      let mut v87_6 = Space::new();
      let mut v87_6_write = v87_6.write_zipper();
      for v87_6_byte in v68_47_cursor.child_mask().iter() {
        v68_47_cursor.descend_to_existing_byte(v87_6_byte);
        {
        let v88_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 1)..(v68_47_origin + 2)]);
        let v88_3: Space = intersect(&(*CONSTANT_1),&(v88_2));
        let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
        drop(v88_3);
        let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
        drop(v88_4);
        let v88_8: Space = if (&(v88_5)).is_empty() { Space::new() } else {
          let mut v89_7 = Space::new();
          let mut v89_7_write = v89_7.write_zipper();
          for v89_7_byte in v68_47_cursor.child_mask().iter() {
            v68_47_cursor.descend_to_existing_byte(v89_7_byte);
            {
            let v90_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 2)..(v68_47_origin + 3)]);
            let v90_3: Space = intersect(&(*CONSTANT_1),&(v90_2));
            let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
            drop(v90_3);
            let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
            drop(v90_4);
            let v90_8: Space = if (&(v90_5)).is_empty() { Space::new() } else {
              let v91_7: Space = routine_18(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v90_5),&(v91_7))
            };
            drop(v90_5);
            let v90_9: Space = intersect(&(*CONSTANT_1),&(v90_2));
            drop(v90_2);
            let v90_10: Space = if has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
            drop(v90_9);
            let v90_12: Space = if (&(v90_10)).is_empty() { Space::new() } else {
              let v92_11: Space = routine_19(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v90_10),&(v92_11))
            };
            drop(v90_10);
            let v90_13: Space = unite(&(v90_8),&(v90_12));
            join_wrapped_into(&mut v89_7_write,&((v90_13).read_zipper()),&[]);
            }
            v68_47_cursor.ascend(1);
          }
          drop(v89_7_write);
          compose(&(v88_5),&(v89_7))
        };
        drop(v88_5);
        let v88_9: Space = intersect(&(*CONSTANT_1),&(v88_2));
        drop(v88_2);
        let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
        drop(v88_9);
        let v88_12: Space = if (&(v88_10)).is_empty() { Space::new() } else {
          let mut v93_11 = Space::new();
          let mut v93_11_write = v93_11.write_zipper();
          for v93_11_byte in v68_47_cursor.child_mask().iter() {
            v68_47_cursor.descend_to_existing_byte(v93_11_byte);
            {
            let v94_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 2)..(v68_47_origin + 3)]);
            let v94_3: Space = intersect(&(*CONSTANT_1),&(v94_2));
            let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
            drop(v94_3);
            let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
            drop(v94_4);
            let v94_8: Space = if (&(v94_5)).is_empty() { Space::new() } else {
              let v95_7: Space = routine_18(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v94_5),&(v95_7))
            };
            drop(v94_5);
            let v94_9: Space = intersect(&(*CONSTANT_1),&(v94_2));
            drop(v94_2);
            let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
            drop(v94_9);
            let v94_12: Space = if (&(v94_10)).is_empty() { Space::new() } else {
              let v96_11: Space = routine_15(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v94_10),&(v96_11))
            };
            drop(v94_10);
            let v94_13: Space = unite(&(v94_8),&(v94_12));
            join_wrapped_into(&mut v93_11_write,&((v94_13).read_zipper()),&[]);
            }
            v68_47_cursor.ascend(1);
          }
          drop(v93_11_write);
          compose(&(v88_10),&(v93_11))
        };
        drop(v88_10);
        let v88_13: Space = unite(&(v88_8),&(v88_12));
        join_wrapped_into(&mut v87_6_write,&((v88_13).read_zipper()),&[]);
        }
        v68_47_cursor.ascend(1);
      }
      drop(v87_6_write);
      compose(&(v86_5),&(v87_6))
    };
    drop(v86_5);
    let v86_8: Space = intersect(&(*CONSTANT_1),&(v86_2));
    drop(v86_2);
    let v86_9: Space = if has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
    drop(v86_8);
    let v86_11: Space = if (&(v86_9)).is_empty() { Space::new() } else {
      let mut v97_10 = Space::new();
      let mut v97_10_write = v97_10.write_zipper();
      for v97_10_byte in v68_47_cursor.child_mask().iter() {
        v68_47_cursor.descend_to_existing_byte(v97_10_byte);
        {
        let v98_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 1)..(v68_47_origin + 2)]);
        let v98_3: Space = intersect(&(*CONSTANT_1),&(v98_2));
        let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
        drop(v98_3);
        let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
        drop(v98_4);
        let v98_8: Space = if (&(v98_5)).is_empty() { Space::new() } else {
          let mut v99_7 = Space::new();
          let mut v99_7_write = v99_7.write_zipper();
          for v99_7_byte in v68_47_cursor.child_mask().iter() {
            v68_47_cursor.descend_to_existing_byte(v99_7_byte);
            {
            let v100_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 2)..(v68_47_origin + 3)]);
            let v100_3: Space = intersect(&(*CONSTANT_1),&(v100_2));
            let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
            drop(v100_3);
            let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
            drop(v100_4);
            let v100_8: Space = if (&(v100_5)).is_empty() { Space::new() } else {
              let v101_7: Space = routine_18(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v100_5),&(v101_7))
            };
            drop(v100_5);
            let v100_9: Space = intersect(&(*CONSTANT_1),&(v100_2));
            drop(v100_2);
            let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
            drop(v100_9);
            let v100_12: Space = if (&(v100_10)).is_empty() { Space::new() } else {
              let v102_11: Space = routine_19(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v100_10),&(v102_11))
            };
            drop(v100_10);
            let v100_13: Space = unite(&(v100_8),&(v100_12));
            join_wrapped_into(&mut v99_7_write,&((v100_13).read_zipper()),&[]);
            }
            v68_47_cursor.ascend(1);
          }
          drop(v99_7_write);
          compose(&(v98_5),&(v99_7))
        };
        drop(v98_5);
        let v98_9: Space = intersect(&(*CONSTANT_1),&(v98_2));
        drop(v98_2);
        let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
        drop(v98_9);
        let v98_11: Space = compose(&(v98_10),&v68_47_cursor);
        drop(v98_10);
        let v98_12: Space = unite(&(v98_8),&(v98_11));
        drop(v98_11);
        join_wrapped_into(&mut v97_10_write,&((v98_12).read_zipper()),&[]);
        }
        v68_47_cursor.ascend(1);
      }
      drop(v97_10_write);
      compose(&(v86_9),&(v97_10))
    };
    drop(v86_9);
    let v86_12: Space = unite(&(v86_7),&(v86_11));
    join_wrapped_into(&mut v68_47_write,&((v86_12).read_zipper()),&[]);
    }
    v68_47_cursor.ascend(1);
  }
  drop(v68_47_cursor);
  drop(v68_47_write);
  let v68_48: Space = subtract(&(v68_47),&(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0))));
  let v68_51: Space = intersect(&(v68_48),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
  let v68_52: Space = wrap(&(v68_51),&(*p0));
  (v68_52).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v103_18 = Space::new();
  let mut v103_18_write = v103_18.write_zipper();
  let mut v103_18_cursor = (*s0).read_zipper();
  let v103_18_origin = v103_18_cursor.path().len();
  for v103_18_byte in v103_18_cursor.child_mask().iter() {
    v103_18_cursor.descend_to_existing_byte(v103_18_byte);
    {
    let v104_2: Space = singleton(&v103_18_cursor.path()[v103_18_origin..(v103_18_origin + 1)]);
    let v104_3: Space = intersect(&(*CONSTANT_1),&(v104_2));
    drop(v104_2);
    let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
    drop(v104_3);
    let v104_8: Space = if (&(v104_4)).is_empty() { Space::new() } else {
      let v105_6: Path = concat_path(&(*p0),&v103_18_cursor.path()[v103_18_origin..(v103_18_origin + 1)]);
      let mut v105_7 = Space::new();
      let mut v105_7_write = v105_7.write_zipper();
      for v105_7_byte in v103_18_cursor.child_mask().iter() {
        v103_18_cursor.descend_to_existing_byte(v105_7_byte);
        {
        let v106_2: Space = singleton(&v103_18_cursor.path()[(v103_18_origin + 1)..(v103_18_origin + 2)]);
        let v106_3: Space = intersect(&(*CONSTANT_1),&(v106_2));
        drop(v106_2);
        let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
        drop(v106_3);
        let v106_12: Space = if (&(v106_4)).is_empty() { Space::new() } else {
          let v107_6: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v103_18_cursor.path()[v103_18_origin..(v103_18_origin + 1)]),&v103_18_cursor.path()[(v103_18_origin + 1)..(v103_18_origin + 2)])));
          let mut v107_7 = Space::new();
          let mut v107_7_write = v107_7.write_zipper();
          let mut v107_7_cursor = (v107_6).read_zipper();
          let v107_7_origin = v107_7_cursor.path().len();
          for v107_7_byte in v107_7_cursor.child_mask().iter() {
            v107_7_cursor.descend_to_existing_byte(v107_7_byte);
            {
            let v108_2: Space = singleton(&v107_7_cursor.path()[v107_7_origin..(v107_7_origin + 1)]);
            let v108_3: Space = intersect(&(*CONSTANT_1),&(v108_2));
            let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
            drop(v108_3);
            let v108_5: Space = subtract(&(*CONSTANT_0),&(v108_4));
            drop(v108_4);
            let v108_7: Space = if (&(v108_5)).is_empty() { Space::new() } else {
              let v109_6: Space = routine_6(c, &v107_7_cursor.path()[v107_7_origin..(v107_7_origin + 1)], &v107_7_cursor);
              compose(&(v108_5),&(v109_6))
            };
            drop(v108_5);
            let v108_8: Space = intersect(&(*CONSTANT_1),&(v108_2));
            drop(v108_2);
            let v108_9: Space = if has_head(&(v108_8)) { singleton(&[]) } else { Space::new() };
            drop(v108_8);
            let v108_11: Space = if (&(v108_9)).is_empty() { Space::new() } else {
              let v110_10: Space = routine_7(c, &v107_7_cursor.path()[v107_7_origin..(v107_7_origin + 1)], &v107_7_cursor);
              compose(&(v108_9),&(v110_10))
            };
            drop(v108_9);
            let v108_12: Space = unite(&(v108_7),&(v108_11));
            join_wrapped_into(&mut v107_7_write,&((v108_12).read_zipper()),&[]);
            }
            v107_7_cursor.ascend(1);
          }
          drop(v107_7_cursor);
          drop(v107_7_write);
          drop(v107_6);
          let v107_8: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v107_7));
          let mut v107_9 = Space::new();
          let mut v107_9_write = v107_9.write_zipper();
          let mut v107_9_cursor = (v107_8).read_zipper();
          let v107_9_origin = v107_9_cursor.path().len();
          for v107_9_byte in v107_9_cursor.child_mask().iter() {
            v107_9_cursor.descend_to_existing_byte(v107_9_byte);
            {
            let v111_2: Space = singleton(&v107_9_cursor.path()[v107_9_origin..(v107_9_origin + 1)]);
            let v111_3: Space = intersect(&(*CONSTANT_1),&(v111_2));
            let v111_4: Space = if has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
            drop(v111_3);
            let v111_5: Space = subtract(&(*CONSTANT_0),&(v111_4));
            drop(v111_4);
            let v111_7: Space = if (&(v111_5)).is_empty() { Space::new() } else {
              let v112_6: Space = routine_8(c, &v107_9_cursor.path()[v107_9_origin..(v107_9_origin + 1)], &v107_9_cursor);
              compose(&(v111_5),&(v112_6))
            };
            drop(v111_5);
            let v111_8: Space = intersect(&(*CONSTANT_1),&(v111_2));
            drop(v111_2);
            let v111_9: Space = if has_head(&(v111_8)) { singleton(&[]) } else { Space::new() };
            drop(v111_8);
            let v111_11: Space = if (&(v111_9)).is_empty() { Space::new() } else {
              let v113_10: Space = routine_9(c, &v107_9_cursor.path()[v107_9_origin..(v107_9_origin + 1)], &v107_9_cursor);
              compose(&(v111_9),&(v113_10))
            };
            drop(v111_9);
            let v111_12: Space = unite(&(v111_7),&(v111_11));
            join_wrapped_into(&mut v107_9_write,&((v111_12).read_zipper()),&[]);
            }
            v107_9_cursor.ascend(1);
          }
          drop(v107_9_cursor);
          drop(v107_9_write);
          let v107_10: Space = subtract(&(v107_9),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v103_18_cursor.path()[v103_18_origin..(v103_18_origin + 1)]),&v103_18_cursor.path()[(v103_18_origin + 1)..(v103_18_origin + 2)])));
          let v107_11: Space = intersect(&(v107_10),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
          compose(&(v106_4),&(v107_11))
        };
        drop(v106_4);
        let v106_13: Path = concat_path(&(v105_6),&v103_18_cursor.path()[(v103_18_origin + 1)..(v103_18_origin + 2)]);
        join_wrapped_into(&mut v105_7_write,&((v106_12).read_zipper()),&(v106_13));
        drop(v106_13);
        }
        v103_18_cursor.ascend(1);
      }
      drop(v105_7_write);
      drop(v105_6);
      compose(&(v104_4),&(v105_7))
    };
    drop(v104_4);
    join_wrapped_into(&mut v103_18_write,&((v104_8).read_zipper()),&[]);
    }
    v103_18_cursor.ascend(1);
  }
  drop(v103_18_cursor);
  drop(v103_18_write);
  (v103_18).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v114_29 = Space::new();
  let mut v114_29_write = v114_29.write_zipper();
  let mut v114_29_cursor = (*s0).read_zipper();
  let v114_29_origin = v114_29_cursor.path().len();
  for v114_29_byte in v114_29_cursor.child_mask().iter() {
    v114_29_cursor.descend_to_existing_byte(v114_29_byte);
    {
    let v115_2: Space = singleton(&v114_29_cursor.path()[v114_29_origin..(v114_29_origin + 1)]);
    let v115_3: Space = intersect(&(*CONSTANT_1),&(v115_2));
    drop(v115_2);
    let v115_4: Space = if has_head(&(v115_3)) { singleton(&[]) } else { Space::new() };
    drop(v115_3);
    let v115_12: Space = if (&(v115_4)).is_empty() { Space::new() } else {
      let v116_6: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v114_29_cursor.path()[v114_29_origin..(v114_29_origin + 1)])));
      let mut v116_7 = Space::new();
      let mut v116_7_write = v116_7.write_zipper();
      let mut v116_7_cursor = (v116_6).read_zipper();
      let v116_7_origin = v116_7_cursor.path().len();
      for v116_7_byte in v116_7_cursor.child_mask().iter() {
        v116_7_cursor.descend_to_existing_byte(v116_7_byte);
        {
        let v117_2: Space = singleton(&v116_7_cursor.path()[v116_7_origin..(v116_7_origin + 1)]);
        let v117_3: Space = intersect(&(*CONSTANT_1),&(v117_2));
        let v117_4: Space = if has_head(&(v117_3)) { singleton(&[]) } else { Space::new() };
        drop(v117_3);
        let v117_5: Space = subtract(&(*CONSTANT_0),&(v117_4));
        drop(v117_4);
        let v117_7: Space = if (&(v117_5)).is_empty() { Space::new() } else {
          let mut v118_6 = Space::new();
          let mut v118_6_write = v118_6.write_zipper();
          for v118_6_byte in v116_7_cursor.child_mask().iter() {
            v116_7_cursor.descend_to_existing_byte(v118_6_byte);
            {
            let v119_2: Space = singleton(&v116_7_cursor.path()[(v116_7_origin + 1)..(v116_7_origin + 2)]);
            let v119_3: Space = intersect(&(*CONSTANT_1),&(v119_2));
            let v119_4: Space = if has_head(&(v119_3)) { singleton(&[]) } else { Space::new() };
            drop(v119_3);
            let v119_5: Space = subtract(&(*CONSTANT_0),&(v119_4));
            drop(v119_4);
            let v119_8: Space = if (&(v119_5)).is_empty() { Space::new() } else {
              let v120_7: Space = routine_10(c, &v116_7_cursor.path()[v116_7_origin..(v116_7_origin + 2)], &v116_7_cursor);
              compose(&(v119_5),&(v120_7))
            };
            drop(v119_5);
            let v119_9: Space = intersect(&(*CONSTANT_1),&(v119_2));
            drop(v119_2);
            let v119_10: Space = if has_head(&(v119_9)) { singleton(&[]) } else { Space::new() };
            drop(v119_9);
            let v119_12: Space = if (&(v119_10)).is_empty() { Space::new() } else {
              let v121_11: Space = routine_11(c, &v116_7_cursor.path()[v116_7_origin..(v116_7_origin + 2)], &v116_7_cursor);
              compose(&(v119_10),&(v121_11))
            };
            drop(v119_10);
            let v119_13: Space = unite(&(v119_8),&(v119_12));
            join_wrapped_into(&mut v118_6_write,&((v119_13).read_zipper()),&[]);
            }
            v116_7_cursor.ascend(1);
          }
          drop(v118_6_write);
          compose(&(v117_5),&(v118_6))
        };
        drop(v117_5);
        let v117_8: Space = intersect(&(*CONSTANT_1),&(v117_2));
        drop(v117_2);
        let v117_9: Space = if has_head(&(v117_8)) { singleton(&[]) } else { Space::new() };
        drop(v117_8);
        let v117_11: Space = if (&(v117_9)).is_empty() { Space::new() } else {
          let mut v122_10 = Space::new();
          let mut v122_10_write = v122_10.write_zipper();
          for v122_10_byte in v116_7_cursor.child_mask().iter() {
            v116_7_cursor.descend_to_existing_byte(v122_10_byte);
            {
            let v123_2: Space = singleton(&v116_7_cursor.path()[(v116_7_origin + 1)..(v116_7_origin + 2)]);
            let v123_3: Space = intersect(&(*CONSTANT_1),&(v123_2));
            let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
            drop(v123_3);
            let v123_5: Space = subtract(&(*CONSTANT_0),&(v123_4));
            drop(v123_4);
            let v123_8: Space = if (&(v123_5)).is_empty() { Space::new() } else {
              let v124_7: Space = routine_10(c, &v116_7_cursor.path()[v116_7_origin..(v116_7_origin + 2)], &v116_7_cursor);
              compose(&(v123_5),&(v124_7))
            };
            drop(v123_5);
            let v123_9: Space = intersect(&(*CONSTANT_1),&(v123_2));
            drop(v123_2);
            let v123_10: Space = if has_head(&(v123_9)) { singleton(&[]) } else { Space::new() };
            drop(v123_9);
            let v123_12: Space = if (&(v123_10)).is_empty() { Space::new() } else {
              let v125_11: Space = routine_12(c, &v116_7_cursor.path()[v116_7_origin..(v116_7_origin + 2)], &v116_7_cursor);
              compose(&(v123_10),&(v125_11))
            };
            drop(v123_10);
            let v123_13: Space = unite(&(v123_8),&(v123_12));
            join_wrapped_into(&mut v122_10_write,&((v123_13).read_zipper()),&[]);
            }
            v116_7_cursor.ascend(1);
          }
          drop(v122_10_write);
          compose(&(v117_9),&(v122_10))
        };
        drop(v117_9);
        let v117_12: Space = unite(&(v117_7),&(v117_11));
        join_wrapped_into(&mut v116_7_write,&((v117_12).read_zipper()),&[]);
        }
        v116_7_cursor.ascend(1);
      }
      drop(v116_7_cursor);
      drop(v116_7_write);
      drop(v116_6);
      let v116_8: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v116_7));
      let mut v116_9 = Space::new();
      let mut v116_9_write = v116_9.write_zipper();
      let mut v116_9_cursor = (v116_8).read_zipper();
      let v116_9_origin = v116_9_cursor.path().len();
      for v116_9_byte in v116_9_cursor.child_mask().iter() {
        v116_9_cursor.descend_to_existing_byte(v116_9_byte);
        {
        let v126_2: Space = singleton(&v116_9_cursor.path()[v116_9_origin..(v116_9_origin + 1)]);
        let v126_3: Space = intersect(&(*CONSTANT_1),&(v126_2));
        let v126_4: Space = if has_head(&(v126_3)) { singleton(&[]) } else { Space::new() };
        drop(v126_3);
        let v126_5: Space = subtract(&(*CONSTANT_0),&(v126_4));
        drop(v126_4);
        let v126_7: Space = if (&(v126_5)).is_empty() { Space::new() } else {
          let mut v127_6 = Space::new();
          let mut v127_6_write = v127_6.write_zipper();
          for v127_6_byte in v116_9_cursor.child_mask().iter() {
            v116_9_cursor.descend_to_existing_byte(v127_6_byte);
            {
            let v128_2: Space = singleton(&v116_9_cursor.path()[(v116_9_origin + 1)..(v116_9_origin + 2)]);
            let v128_3: Space = intersect(&(*CONSTANT_1),&(v128_2));
            let v128_4: Space = if has_head(&(v128_3)) { singleton(&[]) } else { Space::new() };
            drop(v128_3);
            let v128_5: Space = subtract(&(*CONSTANT_0),&(v128_4));
            drop(v128_4);
            let v128_8: Space = if (&(v128_5)).is_empty() { Space::new() } else {
              let v129_7: Space = routine_13(c, &v116_9_cursor.path()[v116_9_origin..(v116_9_origin + 2)], &v116_9_cursor);
              compose(&(v128_5),&(v129_7))
            };
            drop(v128_5);
            let v128_9: Space = intersect(&(*CONSTANT_1),&(v128_2));
            drop(v128_2);
            let v128_10: Space = if has_head(&(v128_9)) { singleton(&[]) } else { Space::new() };
            drop(v128_9);
            let v128_12: Space = if (&(v128_10)).is_empty() { Space::new() } else {
              let v130_11: Space = routine_14(c, &v116_9_cursor.path()[v116_9_origin..(v116_9_origin + 2)], &v116_9_cursor);
              compose(&(v128_10),&(v130_11))
            };
            drop(v128_10);
            let v128_13: Space = unite(&(v128_8),&(v128_12));
            join_wrapped_into(&mut v127_6_write,&((v128_13).read_zipper()),&[]);
            }
            v116_9_cursor.ascend(1);
          }
          drop(v127_6_write);
          compose(&(v126_5),&(v127_6))
        };
        drop(v126_5);
        let v126_8: Space = intersect(&(*CONSTANT_1),&(v126_2));
        drop(v126_2);
        let v126_9: Space = if has_head(&(v126_8)) { singleton(&[]) } else { Space::new() };
        drop(v126_8);
        let v126_11: Space = if (&(v126_9)).is_empty() { Space::new() } else {
          let mut v131_10 = Space::new();
          let mut v131_10_write = v131_10.write_zipper();
          for v131_10_byte in v116_9_cursor.child_mask().iter() {
            v116_9_cursor.descend_to_existing_byte(v131_10_byte);
            {
            let v132_2: Space = singleton(&v116_9_cursor.path()[(v116_9_origin + 1)..(v116_9_origin + 2)]);
            let v132_3: Space = intersect(&(*CONSTANT_1),&(v132_2));
            let v132_4: Space = if has_head(&(v132_3)) { singleton(&[]) } else { Space::new() };
            drop(v132_3);
            let v132_5: Space = subtract(&(*CONSTANT_0),&(v132_4));
            drop(v132_4);
            let v132_8: Space = if (&(v132_5)).is_empty() { Space::new() } else {
              let v133_7: Space = routine_13(c, &v116_9_cursor.path()[v116_9_origin..(v116_9_origin + 2)], &v116_9_cursor);
              compose(&(v132_5),&(v133_7))
            };
            drop(v132_5);
            let v132_9: Space = intersect(&(*CONSTANT_1),&(v132_2));
            drop(v132_2);
            let v132_10: Space = if has_head(&(v132_9)) { singleton(&[]) } else { Space::new() };
            drop(v132_9);
            let v132_12: Space = if (&(v132_10)).is_empty() { Space::new() } else {
              let v134_11: Space = routine_15(c, &v116_9_cursor.path()[v116_9_origin..(v116_9_origin + 2)], &v116_9_cursor);
              compose(&(v132_10),&(v134_11))
            };
            drop(v132_10);
            let v132_13: Space = unite(&(v132_8),&(v132_12));
            join_wrapped_into(&mut v131_10_write,&((v132_13).read_zipper()),&[]);
            }
            v116_9_cursor.ascend(1);
          }
          drop(v131_10_write);
          compose(&(v126_9),&(v131_10))
        };
        drop(v126_9);
        let v126_12: Space = unite(&(v126_7),&(v126_11));
        join_wrapped_into(&mut v116_9_write,&((v126_12).read_zipper()),&[]);
        }
        v116_9_cursor.ascend(1);
      }
      drop(v116_9_cursor);
      drop(v116_9_write);
      let v116_10: Space = subtract(&(v116_9),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v114_29_cursor.path()[v114_29_origin..(v114_29_origin + 1)])));
      let v116_11: Space = intersect(&(v116_10),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
      compose(&(v115_4),&(v116_11))
    };
    drop(v115_4);
    let v115_13: Path = concat_path(&(*p0),&v114_29_cursor.path()[v114_29_origin..(v114_29_origin + 1)]);
    join_wrapped_into(&mut v114_29_write,&((v115_12).read_zipper()),&(v115_13));
    drop(v115_13);
    }
    v114_29_cursor.ascend(1);
  }
  drop(v114_29_cursor);
  drop(v114_29_write);
  (v114_29).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v135_20 = Space::new();
  let mut v135_20_write = v135_20.write_zipper();
  let mut v135_20_cursor = (*s0).read_zipper();
  let v135_20_origin = v135_20_cursor.path().len();
  for v135_20_byte in v135_20_cursor.child_mask().iter() {
    v135_20_cursor.descend_to_existing_byte(v135_20_byte);
    {
    let v136_2: Space = singleton(&v135_20_cursor.path()[v135_20_origin..(v135_20_origin + 1)]);
    let v136_3: Space = intersect(&(*CONSTANT_1),&(v136_2));
    let v136_4: Space = if has_head(&(v136_3)) { singleton(&[]) } else { Space::new() };
    drop(v136_3);
    let v136_5: Space = subtract(&(*CONSTANT_0),&(v136_4));
    drop(v136_4);
    let v136_8: Space = if (&(v136_5)).is_empty() { Space::new() } else {
      let v137_6: Path = concat_path(&(*p0),&v135_20_cursor.path()[v135_20_origin..(v135_20_origin + 1)]);
      let mut v137_7 = Space::new();
      let mut v137_7_write = v137_7.write_zipper();
      for v137_7_byte in v135_20_cursor.child_mask().iter() {
        v135_20_cursor.descend_to_existing_byte(v137_7_byte);
        {
        let v138_2: Space = singleton(&v135_20_cursor.path()[(v135_20_origin + 1)..(v135_20_origin + 2)]);
        let v138_3: Space = intersect(&(*CONSTANT_1),&(v138_2));
        let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
        drop(v138_3);
        let v138_5: Space = subtract(&(*CONSTANT_0),&(v138_4));
        drop(v138_4);
        let v138_8: Space = if (&(v138_5)).is_empty() { Space::new() } else {
          let v139_6: Path = concat_path(&(v137_6),&v135_20_cursor.path()[(v135_20_origin + 1)..(v135_20_origin + 2)]);
          let mut v139_7 = Space::new();
          let mut v139_7_write = v139_7.write_zipper();
          for v139_7_byte in v135_20_cursor.child_mask().iter() {
            v135_20_cursor.descend_to_existing_byte(v139_7_byte);
            {
            let v140_2: Space = singleton(&v135_20_cursor.path()[(v135_20_origin + 2)..(v135_20_origin + 3)]);
            let v140_3: Space = intersect(&(*CONSTANT_1),&(v140_2));
            let v140_4: Space = if has_head(&(v140_3)) { singleton(&[]) } else { Space::new() };
            drop(v140_3);
            let v140_5: Space = subtract(&(*CONSTANT_0),&(v140_4));
            drop(v140_4);
            let v140_8: Space = if (&(v140_5)).is_empty() { Space::new() } else {
              let v141_6: Path = concat_path(&(v139_6),&v135_20_cursor.path()[(v135_20_origin + 2)..(v135_20_origin + 3)]);
              let v141_7: Space = routine_20(c, &(v141_6), &v135_20_cursor);
              compose(&(v140_5),&(v141_7))
            };
            drop(v140_5);
            let v140_9: Space = intersect(&(*CONSTANT_1),&(v140_2));
            drop(v140_2);
            let v140_10: Space = if has_head(&(v140_9)) { singleton(&[]) } else { Space::new() };
            drop(v140_9);
            let v140_12: Space = if (&(v140_10)).is_empty() { Space::new() } else {
              let v142_6: Path = concat_path(&(v139_6),&v135_20_cursor.path()[(v135_20_origin + 2)..(v135_20_origin + 3)]);
              let v142_11: Space = routine_21(c, &(v142_6), &v135_20_cursor);
              drop(v142_6);
              compose(&(v140_10),&(v142_11))
            };
            drop(v140_10);
            let v140_13: Space = unite(&(v140_8),&(v140_12));
            join_wrapped_into(&mut v139_7_write,&((v140_13).read_zipper()),&[]);
            }
            v135_20_cursor.ascend(1);
          }
          drop(v139_7_write);
          compose(&(v138_5),&(v139_7))
        };
        drop(v138_5);
        let v138_9: Space = intersect(&(*CONSTANT_1),&(v138_2));
        drop(v138_2);
        let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
        drop(v138_9);
        let v138_12: Space = if (&(v138_10)).is_empty() { Space::new() } else {
          let v143_6: Path = concat_path(&(v137_6),&v135_20_cursor.path()[(v135_20_origin + 1)..(v135_20_origin + 2)]);
          let mut v143_11 = Space::new();
          let mut v143_11_write = v143_11.write_zipper();
          for v143_11_byte in v135_20_cursor.child_mask().iter() {
            v135_20_cursor.descend_to_existing_byte(v143_11_byte);
            {
            let v144_2: Space = singleton(&v135_20_cursor.path()[(v135_20_origin + 2)..(v135_20_origin + 3)]);
            let v144_3: Space = intersect(&(*CONSTANT_1),&(v144_2));
            let v144_4: Space = if has_head(&(v144_3)) { singleton(&[]) } else { Space::new() };
            drop(v144_3);
            let v144_5: Space = subtract(&(*CONSTANT_0),&(v144_4));
            drop(v144_4);
            let v144_8: Space = if (&(v144_5)).is_empty() { Space::new() } else {
              let v145_6: Path = concat_path(&(v143_6),&v135_20_cursor.path()[(v135_20_origin + 2)..(v135_20_origin + 3)]);
              let v145_7: Space = routine_20(c, &(v145_6), &v135_20_cursor);
              compose(&(v144_5),&(v145_7))
            };
            drop(v144_5);
            let v144_9: Space = intersect(&(*CONSTANT_1),&(v144_2));
            drop(v144_2);
            let v144_10: Space = if has_head(&(v144_9)) { singleton(&[]) } else { Space::new() };
            drop(v144_9);
            let v144_12: Space = if (&(v144_10)).is_empty() { Space::new() } else {
              let v146_6: Path = concat_path(&(v143_6),&v135_20_cursor.path()[(v135_20_origin + 2)..(v135_20_origin + 3)]);
              let v146_11: Space = routine_12(c, &(v146_6), &v135_20_cursor);
              drop(v146_6);
              compose(&(v144_10),&(v146_11))
            };
            drop(v144_10);
            let v144_13: Space = unite(&(v144_8),&(v144_12));
            join_wrapped_into(&mut v143_11_write,&((v144_13).read_zipper()),&[]);
            }
            v135_20_cursor.ascend(1);
          }
          drop(v143_11_write);
          drop(v143_6);
          compose(&(v138_10),&(v143_11))
        };
        drop(v138_10);
        let v138_13: Space = unite(&(v138_8),&(v138_12));
        join_wrapped_into(&mut v137_7_write,&((v138_13).read_zipper()),&[]);
        }
        v135_20_cursor.ascend(1);
      }
      drop(v137_7_write);
      compose(&(v136_5),&(v137_7))
    };
    drop(v136_5);
    let v136_9: Space = intersect(&(*CONSTANT_1),&(v136_2));
    drop(v136_2);
    let v136_10: Space = if has_head(&(v136_9)) { singleton(&[]) } else { Space::new() };
    drop(v136_9);
    let v136_12: Space = if (&(v136_10)).is_empty() { Space::new() } else {
      let v147_6: Path = concat_path(&(*p0),&v135_20_cursor.path()[v135_20_origin..(v135_20_origin + 1)]);
      let mut v147_11 = Space::new();
      let mut v147_11_write = v147_11.write_zipper();
      for v147_11_byte in v135_20_cursor.child_mask().iter() {
        v135_20_cursor.descend_to_existing_byte(v147_11_byte);
        {
        let v148_2: Space = singleton(&v135_20_cursor.path()[(v135_20_origin + 1)..(v135_20_origin + 2)]);
        let v148_3: Space = intersect(&(*CONSTANT_1),&(v148_2));
        let v148_4: Space = if has_head(&(v148_3)) { singleton(&[]) } else { Space::new() };
        drop(v148_3);
        let v148_5: Space = subtract(&(*CONSTANT_0),&(v148_4));
        drop(v148_4);
        let v148_8: Space = if (&(v148_5)).is_empty() { Space::new() } else {
          let v149_6: Path = concat_path(&(v147_6),&v135_20_cursor.path()[(v135_20_origin + 1)..(v135_20_origin + 2)]);
          let mut v149_7 = Space::new();
          let mut v149_7_write = v149_7.write_zipper();
          for v149_7_byte in v135_20_cursor.child_mask().iter() {
            v135_20_cursor.descend_to_existing_byte(v149_7_byte);
            {
            let v150_2: Space = singleton(&v135_20_cursor.path()[(v135_20_origin + 2)..(v135_20_origin + 3)]);
            let v150_3: Space = intersect(&(*CONSTANT_1),&(v150_2));
            let v150_4: Space = if has_head(&(v150_3)) { singleton(&[]) } else { Space::new() };
            drop(v150_3);
            let v150_5: Space = subtract(&(*CONSTANT_0),&(v150_4));
            drop(v150_4);
            let v150_8: Space = if (&(v150_5)).is_empty() { Space::new() } else {
              let v151_6: Path = concat_path(&(v149_6),&v135_20_cursor.path()[(v135_20_origin + 2)..(v135_20_origin + 3)]);
              let v151_7: Space = routine_20(c, &(v151_6), &v135_20_cursor);
              compose(&(v150_5),&(v151_7))
            };
            drop(v150_5);
            let v150_9: Space = intersect(&(*CONSTANT_1),&(v150_2));
            drop(v150_2);
            let v150_10: Space = if has_head(&(v150_9)) { singleton(&[]) } else { Space::new() };
            drop(v150_9);
            let v150_12: Space = if (&(v150_10)).is_empty() { Space::new() } else {
              let v152_6: Path = concat_path(&(v149_6),&v135_20_cursor.path()[(v135_20_origin + 2)..(v135_20_origin + 3)]);
              let v152_11: Space = routine_21(c, &(v152_6), &v135_20_cursor);
              drop(v152_6);
              compose(&(v150_10),&(v152_11))
            };
            drop(v150_10);
            let v150_13: Space = unite(&(v150_8),&(v150_12));
            join_wrapped_into(&mut v149_7_write,&((v150_13).read_zipper()),&[]);
            }
            v135_20_cursor.ascend(1);
          }
          drop(v149_7_write);
          drop(v149_6);
          compose(&(v148_5),&(v149_7))
        };
        drop(v148_5);
        let v148_9: Space = intersect(&(*CONSTANT_1),&(v148_2));
        drop(v148_2);
        let v148_10: Space = if has_head(&(v148_9)) { singleton(&[]) } else { Space::new() };
        drop(v148_9);
        let v148_11: Space = compose(&(v148_10),&v135_20_cursor);
        drop(v148_10);
        let v148_12: Space = unite(&(v148_8),&(v148_11));
        drop(v148_11);
        join_wrapped_into(&mut v147_11_write,&((v148_12).read_zipper()),&[]);
        }
        v135_20_cursor.ascend(1);
      }
      drop(v147_11_write);
      drop(v147_6);
      compose(&(v136_10),&(v147_11))
    };
    drop(v136_10);
    let v136_13: Space = unite(&(v136_8),&(v136_12));
    join_wrapped_into(&mut v135_20_write,&((v136_13).read_zipper()),&[]);
    }
    v135_20_cursor.ascend(1);
  }
  drop(v135_20_cursor);
  drop(v135_20_write);
  (v135_20).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v153_14 = Space::new();
  let mut v153_14_write = v153_14.write_zipper();
  let mut v153_14_cursor = (*s0).read_zipper();
  let v153_14_origin = v153_14_cursor.path().len();
  for v153_14_byte in v153_14_cursor.child_mask().iter() {
    v153_14_cursor.descend_to_existing_byte(v153_14_byte);
    {
    let v154_2: Space = singleton(&v153_14_cursor.path()[v153_14_origin..(v153_14_origin + 1)]);
    let v154_3: Space = intersect(&(*CONSTANT_1),&(v154_2));
    let v154_4: Space = if has_head(&(v154_3)) { singleton(&[]) } else { Space::new() };
    drop(v154_3);
    let v154_5: Space = subtract(&(*CONSTANT_0),&(v154_4));
    drop(v154_4);
    let v154_8: Space = if (&(v154_5)).is_empty() { Space::new() } else {
      let v155_6: Path = concat_path(&(*p0),&v153_14_cursor.path()[v153_14_origin..(v153_14_origin + 1)]);
      let mut v155_7 = Space::new();
      let mut v155_7_write = v155_7.write_zipper();
      for v155_7_byte in v153_14_cursor.child_mask().iter() {
        v153_14_cursor.descend_to_existing_byte(v155_7_byte);
        {
        let v156_2: Space = singleton(&v153_14_cursor.path()[(v153_14_origin + 1)..(v153_14_origin + 2)]);
        let v156_3: Space = intersect(&(*CONSTANT_1),&(v156_2));
        let v156_4: Space = if has_head(&(v156_3)) { singleton(&[]) } else { Space::new() };
        drop(v156_3);
        let v156_5: Space = subtract(&(*CONSTANT_0),&(v156_4));
        drop(v156_4);
        let v156_8: Space = if (&(v156_5)).is_empty() { Space::new() } else {
          let v157_6: Path = concat_path(&(v155_6),&v153_14_cursor.path()[(v153_14_origin + 1)..(v153_14_origin + 2)]);
          let mut v157_7 = Space::new();
          let mut v157_7_write = v157_7.write_zipper();
          for v157_7_byte in v153_14_cursor.child_mask().iter() {
            v153_14_cursor.descend_to_existing_byte(v157_7_byte);
            {
            let v158_2: Space = singleton(&v153_14_cursor.path()[(v153_14_origin + 2)..(v153_14_origin + 3)]);
            let v158_3: Space = intersect(&(*CONSTANT_1),&(v158_2));
            let v158_4: Space = if has_head(&(v158_3)) { singleton(&[]) } else { Space::new() };
            drop(v158_3);
            let v158_5: Space = subtract(&(*CONSTANT_0),&(v158_4));
            drop(v158_4);
            let v158_8: Space = if (&(v158_5)).is_empty() { Space::new() } else {
              let v159_6: Path = concat_path(&(v157_6),&v153_14_cursor.path()[(v153_14_origin + 2)..(v153_14_origin + 3)]);
              let v159_7: Space = routine_20(c, &(v159_6), &v153_14_cursor);
              compose(&(v158_5),&(v159_7))
            };
            drop(v158_5);
            let v158_9: Space = intersect(&(*CONSTANT_1),&(v158_2));
            drop(v158_2);
            let v158_10: Space = if has_head(&(v158_9)) { singleton(&[]) } else { Space::new() };
            drop(v158_9);
            let v158_12: Space = if (&(v158_10)).is_empty() { Space::new() } else {
              let v160_6: Path = concat_path(&(v157_6),&v153_14_cursor.path()[(v153_14_origin + 2)..(v153_14_origin + 3)]);
              let v160_11: Space = routine_21(c, &(v160_6), &v153_14_cursor);
              drop(v160_6);
              compose(&(v158_10),&(v160_11))
            };
            drop(v158_10);
            let v158_13: Space = unite(&(v158_8),&(v158_12));
            join_wrapped_into(&mut v157_7_write,&((v158_13).read_zipper()),&[]);
            }
            v153_14_cursor.ascend(1);
          }
          drop(v157_7_write);
          compose(&(v156_5),&(v157_7))
        };
        drop(v156_5);
        let v156_9: Space = intersect(&(*CONSTANT_1),&(v156_2));
        drop(v156_2);
        let v156_10: Space = if has_head(&(v156_9)) { singleton(&[]) } else { Space::new() };
        drop(v156_9);
        let v156_12: Space = if (&(v156_10)).is_empty() { Space::new() } else {
          let v161_6: Path = concat_path(&(v155_6),&v153_14_cursor.path()[(v153_14_origin + 1)..(v153_14_origin + 2)]);
          let mut v161_11 = Space::new();
          let mut v161_11_write = v161_11.write_zipper();
          for v161_11_byte in v153_14_cursor.child_mask().iter() {
            v153_14_cursor.descend_to_existing_byte(v161_11_byte);
            {
            let v162_2: Space = singleton(&v153_14_cursor.path()[(v153_14_origin + 2)..(v153_14_origin + 3)]);
            let v162_3: Space = intersect(&(*CONSTANT_1),&(v162_2));
            let v162_4: Space = if has_head(&(v162_3)) { singleton(&[]) } else { Space::new() };
            drop(v162_3);
            let v162_5: Space = subtract(&(*CONSTANT_0),&(v162_4));
            drop(v162_4);
            let v162_8: Space = if (&(v162_5)).is_empty() { Space::new() } else {
              let v163_6: Path = concat_path(&(v161_6),&v153_14_cursor.path()[(v153_14_origin + 2)..(v153_14_origin + 3)]);
              let v163_7: Space = routine_20(c, &(v163_6), &v153_14_cursor);
              compose(&(v162_5),&(v163_7))
            };
            drop(v162_5);
            let v162_9: Space = intersect(&(*CONSTANT_1),&(v162_2));
            drop(v162_2);
            let v162_10: Space = if has_head(&(v162_9)) { singleton(&[]) } else { Space::new() };
            drop(v162_9);
            let v162_12: Space = if (&(v162_10)).is_empty() { Space::new() } else {
              let v164_6: Path = concat_path(&(v161_6),&v153_14_cursor.path()[(v153_14_origin + 2)..(v153_14_origin + 3)]);
              let v164_11: Space = routine_12(c, &(v164_6), &v153_14_cursor);
              drop(v164_6);
              compose(&(v162_10),&(v164_11))
            };
            drop(v162_10);
            let v162_13: Space = unite(&(v162_8),&(v162_12));
            join_wrapped_into(&mut v161_11_write,&((v162_13).read_zipper()),&[]);
            }
            v153_14_cursor.ascend(1);
          }
          drop(v161_11_write);
          drop(v161_6);
          compose(&(v156_10),&(v161_11))
        };
        drop(v156_10);
        let v156_13: Space = unite(&(v156_8),&(v156_12));
        join_wrapped_into(&mut v155_7_write,&((v156_13).read_zipper()),&[]);
        }
        v153_14_cursor.ascend(1);
      }
      drop(v155_7_write);
      drop(v155_6);
      compose(&(v154_5),&(v155_7))
    };
    drop(v154_5);
    let v154_9: Space = intersect(&(*CONSTANT_1),&(v154_2));
    drop(v154_2);
    let v154_10: Space = if has_head(&(v154_9)) { singleton(&[]) } else { Space::new() };
    drop(v154_9);
    let v154_11: Space = compose(&(v154_10),&v153_14_cursor);
    drop(v154_10);
    let v154_12: Space = unite(&(v154_8),&(v154_11));
    drop(v154_11);
    join_wrapped_into(&mut v153_14_write,&((v154_12).read_zipper()),&[]);
    }
    v153_14_cursor.ascend(1);
  }
  drop(v153_14_cursor);
  drop(v153_14_write);
  (v153_14).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v165_20 = Space::new();
  let mut v165_20_write = v165_20.write_zipper();
  let mut v165_20_cursor = (*s0).read_zipper();
  let v165_20_origin = v165_20_cursor.path().len();
  for v165_20_byte in v165_20_cursor.child_mask().iter() {
    v165_20_cursor.descend_to_existing_byte(v165_20_byte);
    {
    let v166_2: Space = singleton(&v165_20_cursor.path()[v165_20_origin..(v165_20_origin + 1)]);
    let v166_3: Space = intersect(&(*CONSTANT_1),&(v166_2));
    let v166_4: Space = if has_head(&(v166_3)) { singleton(&[]) } else { Space::new() };
    drop(v166_3);
    let v166_5: Space = subtract(&(*CONSTANT_0),&(v166_4));
    drop(v166_4);
    let v166_8: Space = if (&(v166_5)).is_empty() { Space::new() } else {
      let v167_6: Path = concat_path(&(*p0),&v165_20_cursor.path()[v165_20_origin..(v165_20_origin + 1)]);
      let mut v167_7 = Space::new();
      let mut v167_7_write = v167_7.write_zipper();
      for v167_7_byte in v165_20_cursor.child_mask().iter() {
        v165_20_cursor.descend_to_existing_byte(v167_7_byte);
        {
        let v168_2: Space = singleton(&v165_20_cursor.path()[(v165_20_origin + 1)..(v165_20_origin + 2)]);
        let v168_3: Space = intersect(&(*CONSTANT_1),&(v168_2));
        let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
        drop(v168_3);
        let v168_5: Space = subtract(&(*CONSTANT_0),&(v168_4));
        drop(v168_4);
        let v168_8: Space = if (&(v168_5)).is_empty() { Space::new() } else {
          let v169_6: Path = concat_path(&(v167_6),&v165_20_cursor.path()[(v165_20_origin + 1)..(v165_20_origin + 2)]);
          let mut v169_7 = Space::new();
          let mut v169_7_write = v169_7.write_zipper();
          for v169_7_byte in v165_20_cursor.child_mask().iter() {
            v165_20_cursor.descend_to_existing_byte(v169_7_byte);
            {
            let v170_2: Space = singleton(&v165_20_cursor.path()[(v165_20_origin + 2)..(v165_20_origin + 3)]);
            let v170_3: Space = intersect(&(*CONSTANT_1),&(v170_2));
            let v170_4: Space = if has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
            drop(v170_3);
            let v170_5: Space = subtract(&(*CONSTANT_0),&(v170_4));
            drop(v170_4);
            let v170_8: Space = if (&(v170_5)).is_empty() { Space::new() } else {
              let v171_6: Path = concat_path(&(v169_6),&v165_20_cursor.path()[(v165_20_origin + 2)..(v165_20_origin + 3)]);
              let v171_7: Space = routine_22(c, &(v171_6), &v165_20_cursor);
              compose(&(v170_5),&(v171_7))
            };
            drop(v170_5);
            let v170_9: Space = intersect(&(*CONSTANT_1),&(v170_2));
            drop(v170_2);
            let v170_10: Space = if has_head(&(v170_9)) { singleton(&[]) } else { Space::new() };
            drop(v170_9);
            let v170_12: Space = if (&(v170_10)).is_empty() { Space::new() } else {
              let v172_6: Path = concat_path(&(v169_6),&v165_20_cursor.path()[(v165_20_origin + 2)..(v165_20_origin + 3)]);
              let v172_11: Space = routine_23(c, &(v172_6), &v165_20_cursor);
              drop(v172_6);
              compose(&(v170_10),&(v172_11))
            };
            drop(v170_10);
            let v170_13: Space = unite(&(v170_8),&(v170_12));
            join_wrapped_into(&mut v169_7_write,&((v170_13).read_zipper()),&[]);
            }
            v165_20_cursor.ascend(1);
          }
          drop(v169_7_write);
          compose(&(v168_5),&(v169_7))
        };
        drop(v168_5);
        let v168_9: Space = intersect(&(*CONSTANT_1),&(v168_2));
        drop(v168_2);
        let v168_10: Space = if has_head(&(v168_9)) { singleton(&[]) } else { Space::new() };
        drop(v168_9);
        let v168_12: Space = if (&(v168_10)).is_empty() { Space::new() } else {
          let v173_6: Path = concat_path(&(v167_6),&v165_20_cursor.path()[(v165_20_origin + 1)..(v165_20_origin + 2)]);
          let mut v173_11 = Space::new();
          let mut v173_11_write = v173_11.write_zipper();
          for v173_11_byte in v165_20_cursor.child_mask().iter() {
            v165_20_cursor.descend_to_existing_byte(v173_11_byte);
            {
            let v174_2: Space = singleton(&v165_20_cursor.path()[(v165_20_origin + 2)..(v165_20_origin + 3)]);
            let v174_3: Space = intersect(&(*CONSTANT_1),&(v174_2));
            let v174_4: Space = if has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
            drop(v174_3);
            let v174_5: Space = subtract(&(*CONSTANT_0),&(v174_4));
            drop(v174_4);
            let v174_8: Space = if (&(v174_5)).is_empty() { Space::new() } else {
              let v175_6: Path = concat_path(&(v173_6),&v165_20_cursor.path()[(v165_20_origin + 2)..(v165_20_origin + 3)]);
              let v175_7: Space = routine_22(c, &(v175_6), &v165_20_cursor);
              compose(&(v174_5),&(v175_7))
            };
            drop(v174_5);
            let v174_9: Space = intersect(&(*CONSTANT_1),&(v174_2));
            drop(v174_2);
            let v174_10: Space = if has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
            drop(v174_9);
            let v174_12: Space = if (&(v174_10)).is_empty() { Space::new() } else {
              let v176_6: Path = concat_path(&(v173_6),&v165_20_cursor.path()[(v165_20_origin + 2)..(v165_20_origin + 3)]);
              let v176_11: Space = routine_15(c, &(v176_6), &v165_20_cursor);
              drop(v176_6);
              compose(&(v174_10),&(v176_11))
            };
            drop(v174_10);
            let v174_13: Space = unite(&(v174_8),&(v174_12));
            join_wrapped_into(&mut v173_11_write,&((v174_13).read_zipper()),&[]);
            }
            v165_20_cursor.ascend(1);
          }
          drop(v173_11_write);
          drop(v173_6);
          compose(&(v168_10),&(v173_11))
        };
        drop(v168_10);
        let v168_13: Space = unite(&(v168_8),&(v168_12));
        join_wrapped_into(&mut v167_7_write,&((v168_13).read_zipper()),&[]);
        }
        v165_20_cursor.ascend(1);
      }
      drop(v167_7_write);
      compose(&(v166_5),&(v167_7))
    };
    drop(v166_5);
    let v166_9: Space = intersect(&(*CONSTANT_1),&(v166_2));
    drop(v166_2);
    let v166_10: Space = if has_head(&(v166_9)) { singleton(&[]) } else { Space::new() };
    drop(v166_9);
    let v166_12: Space = if (&(v166_10)).is_empty() { Space::new() } else {
      let v177_6: Path = concat_path(&(*p0),&v165_20_cursor.path()[v165_20_origin..(v165_20_origin + 1)]);
      let mut v177_11 = Space::new();
      let mut v177_11_write = v177_11.write_zipper();
      for v177_11_byte in v165_20_cursor.child_mask().iter() {
        v165_20_cursor.descend_to_existing_byte(v177_11_byte);
        {
        let v178_2: Space = singleton(&v165_20_cursor.path()[(v165_20_origin + 1)..(v165_20_origin + 2)]);
        let v178_3: Space = intersect(&(*CONSTANT_1),&(v178_2));
        let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
        drop(v178_3);
        let v178_5: Space = subtract(&(*CONSTANT_0),&(v178_4));
        drop(v178_4);
        let v178_8: Space = if (&(v178_5)).is_empty() { Space::new() } else {
          let v179_6: Path = concat_path(&(v177_6),&v165_20_cursor.path()[(v165_20_origin + 1)..(v165_20_origin + 2)]);
          let mut v179_7 = Space::new();
          let mut v179_7_write = v179_7.write_zipper();
          for v179_7_byte in v165_20_cursor.child_mask().iter() {
            v165_20_cursor.descend_to_existing_byte(v179_7_byte);
            {
            let v180_2: Space = singleton(&v165_20_cursor.path()[(v165_20_origin + 2)..(v165_20_origin + 3)]);
            let v180_3: Space = intersect(&(*CONSTANT_1),&(v180_2));
            let v180_4: Space = if has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
            drop(v180_3);
            let v180_5: Space = subtract(&(*CONSTANT_0),&(v180_4));
            drop(v180_4);
            let v180_8: Space = if (&(v180_5)).is_empty() { Space::new() } else {
              let v181_6: Path = concat_path(&(v179_6),&v165_20_cursor.path()[(v165_20_origin + 2)..(v165_20_origin + 3)]);
              let v181_7: Space = routine_22(c, &(v181_6), &v165_20_cursor);
              compose(&(v180_5),&(v181_7))
            };
            drop(v180_5);
            let v180_9: Space = intersect(&(*CONSTANT_1),&(v180_2));
            drop(v180_2);
            let v180_10: Space = if has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
            drop(v180_9);
            let v180_12: Space = if (&(v180_10)).is_empty() { Space::new() } else {
              let v182_6: Path = concat_path(&(v179_6),&v165_20_cursor.path()[(v165_20_origin + 2)..(v165_20_origin + 3)]);
              let v182_11: Space = routine_23(c, &(v182_6), &v165_20_cursor);
              drop(v182_6);
              compose(&(v180_10),&(v182_11))
            };
            drop(v180_10);
            let v180_13: Space = unite(&(v180_8),&(v180_12));
            join_wrapped_into(&mut v179_7_write,&((v180_13).read_zipper()),&[]);
            }
            v165_20_cursor.ascend(1);
          }
          drop(v179_7_write);
          drop(v179_6);
          compose(&(v178_5),&(v179_7))
        };
        drop(v178_5);
        let v178_9: Space = intersect(&(*CONSTANT_1),&(v178_2));
        drop(v178_2);
        let v178_10: Space = if has_head(&(v178_9)) { singleton(&[]) } else { Space::new() };
        drop(v178_9);
        let v178_11: Space = compose(&(v178_10),&v165_20_cursor);
        drop(v178_10);
        let v178_12: Space = unite(&(v178_8),&(v178_11));
        drop(v178_11);
        join_wrapped_into(&mut v177_11_write,&((v178_12).read_zipper()),&[]);
        }
        v165_20_cursor.ascend(1);
      }
      drop(v177_11_write);
      drop(v177_6);
      compose(&(v166_10),&(v177_11))
    };
    drop(v166_10);
    let v166_13: Space = unite(&(v166_8),&(v166_12));
    join_wrapped_into(&mut v165_20_write,&((v166_13).read_zipper()),&[]);
    }
    v165_20_cursor.ascend(1);
  }
  drop(v165_20_cursor);
  drop(v165_20_write);
  (v165_20).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v183_14 = Space::new();
  let mut v183_14_write = v183_14.write_zipper();
  let mut v183_14_cursor = (*s0).read_zipper();
  let v183_14_origin = v183_14_cursor.path().len();
  for v183_14_byte in v183_14_cursor.child_mask().iter() {
    v183_14_cursor.descend_to_existing_byte(v183_14_byte);
    {
    let v184_2: Space = singleton(&v183_14_cursor.path()[v183_14_origin..(v183_14_origin + 1)]);
    let v184_3: Space = intersect(&(*CONSTANT_1),&(v184_2));
    let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
    drop(v184_3);
    let v184_5: Space = subtract(&(*CONSTANT_0),&(v184_4));
    drop(v184_4);
    let v184_8: Space = if (&(v184_5)).is_empty() { Space::new() } else {
      let v185_6: Path = concat_path(&(*p0),&v183_14_cursor.path()[v183_14_origin..(v183_14_origin + 1)]);
      let mut v185_7 = Space::new();
      let mut v185_7_write = v185_7.write_zipper();
      for v185_7_byte in v183_14_cursor.child_mask().iter() {
        v183_14_cursor.descend_to_existing_byte(v185_7_byte);
        {
        let v186_2: Space = singleton(&v183_14_cursor.path()[(v183_14_origin + 1)..(v183_14_origin + 2)]);
        let v186_3: Space = intersect(&(*CONSTANT_1),&(v186_2));
        let v186_4: Space = if has_head(&(v186_3)) { singleton(&[]) } else { Space::new() };
        drop(v186_3);
        let v186_5: Space = subtract(&(*CONSTANT_0),&(v186_4));
        drop(v186_4);
        let v186_8: Space = if (&(v186_5)).is_empty() { Space::new() } else {
          let v187_6: Path = concat_path(&(v185_6),&v183_14_cursor.path()[(v183_14_origin + 1)..(v183_14_origin + 2)]);
          let mut v187_7 = Space::new();
          let mut v187_7_write = v187_7.write_zipper();
          for v187_7_byte in v183_14_cursor.child_mask().iter() {
            v183_14_cursor.descend_to_existing_byte(v187_7_byte);
            {
            let v188_2: Space = singleton(&v183_14_cursor.path()[(v183_14_origin + 2)..(v183_14_origin + 3)]);
            let v188_3: Space = intersect(&(*CONSTANT_1),&(v188_2));
            let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
            drop(v188_3);
            let v188_5: Space = subtract(&(*CONSTANT_0),&(v188_4));
            drop(v188_4);
            let v188_8: Space = if (&(v188_5)).is_empty() { Space::new() } else {
              let v189_6: Path = concat_path(&(v187_6),&v183_14_cursor.path()[(v183_14_origin + 2)..(v183_14_origin + 3)]);
              let v189_7: Space = routine_22(c, &(v189_6), &v183_14_cursor);
              compose(&(v188_5),&(v189_7))
            };
            drop(v188_5);
            let v188_9: Space = intersect(&(*CONSTANT_1),&(v188_2));
            drop(v188_2);
            let v188_10: Space = if has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
            drop(v188_9);
            let v188_12: Space = if (&(v188_10)).is_empty() { Space::new() } else {
              let v190_6: Path = concat_path(&(v187_6),&v183_14_cursor.path()[(v183_14_origin + 2)..(v183_14_origin + 3)]);
              let v190_11: Space = routine_23(c, &(v190_6), &v183_14_cursor);
              drop(v190_6);
              compose(&(v188_10),&(v190_11))
            };
            drop(v188_10);
            let v188_13: Space = unite(&(v188_8),&(v188_12));
            join_wrapped_into(&mut v187_7_write,&((v188_13).read_zipper()),&[]);
            }
            v183_14_cursor.ascend(1);
          }
          drop(v187_7_write);
          compose(&(v186_5),&(v187_7))
        };
        drop(v186_5);
        let v186_9: Space = intersect(&(*CONSTANT_1),&(v186_2));
        drop(v186_2);
        let v186_10: Space = if has_head(&(v186_9)) { singleton(&[]) } else { Space::new() };
        drop(v186_9);
        let v186_12: Space = if (&(v186_10)).is_empty() { Space::new() } else {
          let v191_6: Path = concat_path(&(v185_6),&v183_14_cursor.path()[(v183_14_origin + 1)..(v183_14_origin + 2)]);
          let mut v191_11 = Space::new();
          let mut v191_11_write = v191_11.write_zipper();
          for v191_11_byte in v183_14_cursor.child_mask().iter() {
            v183_14_cursor.descend_to_existing_byte(v191_11_byte);
            {
            let v192_2: Space = singleton(&v183_14_cursor.path()[(v183_14_origin + 2)..(v183_14_origin + 3)]);
            let v192_3: Space = intersect(&(*CONSTANT_1),&(v192_2));
            let v192_4: Space = if has_head(&(v192_3)) { singleton(&[]) } else { Space::new() };
            drop(v192_3);
            let v192_5: Space = subtract(&(*CONSTANT_0),&(v192_4));
            drop(v192_4);
            let v192_8: Space = if (&(v192_5)).is_empty() { Space::new() } else {
              let v193_6: Path = concat_path(&(v191_6),&v183_14_cursor.path()[(v183_14_origin + 2)..(v183_14_origin + 3)]);
              let v193_7: Space = routine_22(c, &(v193_6), &v183_14_cursor);
              compose(&(v192_5),&(v193_7))
            };
            drop(v192_5);
            let v192_9: Space = intersect(&(*CONSTANT_1),&(v192_2));
            drop(v192_2);
            let v192_10: Space = if has_head(&(v192_9)) { singleton(&[]) } else { Space::new() };
            drop(v192_9);
            let v192_12: Space = if (&(v192_10)).is_empty() { Space::new() } else {
              let v194_6: Path = concat_path(&(v191_6),&v183_14_cursor.path()[(v183_14_origin + 2)..(v183_14_origin + 3)]);
              let v194_11: Space = routine_15(c, &(v194_6), &v183_14_cursor);
              drop(v194_6);
              compose(&(v192_10),&(v194_11))
            };
            drop(v192_10);
            let v192_13: Space = unite(&(v192_8),&(v192_12));
            join_wrapped_into(&mut v191_11_write,&((v192_13).read_zipper()),&[]);
            }
            v183_14_cursor.ascend(1);
          }
          drop(v191_11_write);
          drop(v191_6);
          compose(&(v186_10),&(v191_11))
        };
        drop(v186_10);
        let v186_13: Space = unite(&(v186_8),&(v186_12));
        join_wrapped_into(&mut v185_7_write,&((v186_13).read_zipper()),&[]);
        }
        v183_14_cursor.ascend(1);
      }
      drop(v185_7_write);
      drop(v185_6);
      compose(&(v184_5),&(v185_7))
    };
    drop(v184_5);
    let v184_9: Space = intersect(&(*CONSTANT_1),&(v184_2));
    drop(v184_2);
    let v184_10: Space = if has_head(&(v184_9)) { singleton(&[]) } else { Space::new() };
    drop(v184_9);
    let v184_11: Space = compose(&(v184_10),&v183_14_cursor);
    drop(v184_10);
    let v184_12: Space = unite(&(v184_8),&(v184_11));
    drop(v184_11);
    join_wrapped_into(&mut v183_14_write,&((v184_12).read_zipper()),&[]);
    }
    v183_14_cursor.ascend(1);
  }
  drop(v183_14_cursor);
  drop(v183_14_write);
  (v183_14).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v195_20 = Space::new();
  let mut v195_20_write = v195_20.write_zipper();
  let mut v195_20_cursor = (*s0).read_zipper();
  let v195_20_origin = v195_20_cursor.path().len();
  for v195_20_byte in v195_20_cursor.child_mask().iter() {
    v195_20_cursor.descend_to_existing_byte(v195_20_byte);
    {
    let v196_2: Space = singleton(&v195_20_cursor.path()[v195_20_origin..(v195_20_origin + 1)]);
    let v196_3: Space = intersect(&(*CONSTANT_1),&(v196_2));
    let v196_4: Space = if has_head(&(v196_3)) { singleton(&[]) } else { Space::new() };
    drop(v196_3);
    let v196_5: Space = subtract(&(*CONSTANT_0),&(v196_4));
    drop(v196_4);
    let v196_8: Space = if (&(v196_5)).is_empty() { Space::new() } else {
      let v197_6: Path = concat_path(&(*p0),&v195_20_cursor.path()[v195_20_origin..(v195_20_origin + 1)]);
      let mut v197_7 = Space::new();
      let mut v197_7_write = v197_7.write_zipper();
      for v197_7_byte in v195_20_cursor.child_mask().iter() {
        v195_20_cursor.descend_to_existing_byte(v197_7_byte);
        {
        let v198_2: Space = singleton(&v195_20_cursor.path()[(v195_20_origin + 1)..(v195_20_origin + 2)]);
        let v198_3: Space = intersect(&(*CONSTANT_1),&(v198_2));
        let v198_4: Space = if has_head(&(v198_3)) { singleton(&[]) } else { Space::new() };
        drop(v198_3);
        let v198_5: Space = subtract(&(*CONSTANT_0),&(v198_4));
        drop(v198_4);
        let v198_8: Space = if (&(v198_5)).is_empty() { Space::new() } else {
          let v199_6: Path = concat_path(&(v197_6),&v195_20_cursor.path()[(v195_20_origin + 1)..(v195_20_origin + 2)]);
          let mut v199_7 = Space::new();
          let mut v199_7_write = v199_7.write_zipper();
          for v199_7_byte in v195_20_cursor.child_mask().iter() {
            v195_20_cursor.descend_to_existing_byte(v199_7_byte);
            {
            let v200_2: Space = singleton(&v195_20_cursor.path()[(v195_20_origin + 2)..(v195_20_origin + 3)]);
            let v200_3: Space = intersect(&(*CONSTANT_1),&(v200_2));
            let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
            drop(v200_3);
            let v200_5: Space = subtract(&(*CONSTANT_0),&(v200_4));
            drop(v200_4);
            let v200_8: Space = if (&(v200_5)).is_empty() { Space::new() } else {
              let v201_6: Path = concat_path(&(v199_6),&v195_20_cursor.path()[(v195_20_origin + 2)..(v195_20_origin + 3)]);
              let v201_7: Space = routine_24(c, &(v201_6), &v195_20_cursor);
              compose(&(v200_5),&(v201_7))
            };
            drop(v200_5);
            let v200_9: Space = intersect(&(*CONSTANT_1),&(v200_2));
            drop(v200_2);
            let v200_10: Space = if has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
            drop(v200_9);
            let v200_12: Space = if (&(v200_10)).is_empty() { Space::new() } else {
              let v202_6: Path = concat_path(&(v199_6),&v195_20_cursor.path()[(v195_20_origin + 2)..(v195_20_origin + 3)]);
              let v202_11: Space = routine_25(c, &(v202_6), &v195_20_cursor);
              drop(v202_6);
              compose(&(v200_10),&(v202_11))
            };
            drop(v200_10);
            let v200_13: Space = unite(&(v200_8),&(v200_12));
            join_wrapped_into(&mut v199_7_write,&((v200_13).read_zipper()),&[]);
            }
            v195_20_cursor.ascend(1);
          }
          drop(v199_7_write);
          compose(&(v198_5),&(v199_7))
        };
        drop(v198_5);
        let v198_9: Space = intersect(&(*CONSTANT_1),&(v198_2));
        drop(v198_2);
        let v198_10: Space = if has_head(&(v198_9)) { singleton(&[]) } else { Space::new() };
        drop(v198_9);
        let v198_12: Space = if (&(v198_10)).is_empty() { Space::new() } else {
          let v203_6: Path = concat_path(&(v197_6),&v195_20_cursor.path()[(v195_20_origin + 1)..(v195_20_origin + 2)]);
          let mut v203_11 = Space::new();
          let mut v203_11_write = v203_11.write_zipper();
          for v203_11_byte in v195_20_cursor.child_mask().iter() {
            v195_20_cursor.descend_to_existing_byte(v203_11_byte);
            {
            let v204_2: Space = singleton(&v195_20_cursor.path()[(v195_20_origin + 2)..(v195_20_origin + 3)]);
            let v204_3: Space = intersect(&(*CONSTANT_1),&(v204_2));
            let v204_4: Space = if has_head(&(v204_3)) { singleton(&[]) } else { Space::new() };
            drop(v204_3);
            let v204_5: Space = subtract(&(*CONSTANT_0),&(v204_4));
            drop(v204_4);
            let v204_8: Space = if (&(v204_5)).is_empty() { Space::new() } else {
              let v205_6: Path = concat_path(&(v203_6),&v195_20_cursor.path()[(v195_20_origin + 2)..(v195_20_origin + 3)]);
              let v205_7: Space = routine_24(c, &(v205_6), &v195_20_cursor);
              compose(&(v204_5),&(v205_7))
            };
            drop(v204_5);
            let v204_9: Space = intersect(&(*CONSTANT_1),&(v204_2));
            drop(v204_2);
            let v204_10: Space = if has_head(&(v204_9)) { singleton(&[]) } else { Space::new() };
            drop(v204_9);
            let v204_12: Space = if (&(v204_10)).is_empty() { Space::new() } else {
              let v206_6: Path = concat_path(&(v203_6),&v195_20_cursor.path()[(v195_20_origin + 2)..(v195_20_origin + 3)]);
              let v206_11: Space = routine_12(c, &(v206_6), &v195_20_cursor);
              drop(v206_6);
              compose(&(v204_10),&(v206_11))
            };
            drop(v204_10);
            let v204_13: Space = unite(&(v204_8),&(v204_12));
            join_wrapped_into(&mut v203_11_write,&((v204_13).read_zipper()),&[]);
            }
            v195_20_cursor.ascend(1);
          }
          drop(v203_11_write);
          drop(v203_6);
          compose(&(v198_10),&(v203_11))
        };
        drop(v198_10);
        let v198_13: Space = unite(&(v198_8),&(v198_12));
        join_wrapped_into(&mut v197_7_write,&((v198_13).read_zipper()),&[]);
        }
        v195_20_cursor.ascend(1);
      }
      drop(v197_7_write);
      compose(&(v196_5),&(v197_7))
    };
    drop(v196_5);
    let v196_9: Space = intersect(&(*CONSTANT_1),&(v196_2));
    drop(v196_2);
    let v196_10: Space = if has_head(&(v196_9)) { singleton(&[]) } else { Space::new() };
    drop(v196_9);
    let v196_12: Space = if (&(v196_10)).is_empty() { Space::new() } else {
      let v207_6: Path = concat_path(&(*p0),&v195_20_cursor.path()[v195_20_origin..(v195_20_origin + 1)]);
      let mut v207_11 = Space::new();
      let mut v207_11_write = v207_11.write_zipper();
      for v207_11_byte in v195_20_cursor.child_mask().iter() {
        v195_20_cursor.descend_to_existing_byte(v207_11_byte);
        {
        let v208_2: Space = singleton(&v195_20_cursor.path()[(v195_20_origin + 1)..(v195_20_origin + 2)]);
        let v208_3: Space = intersect(&(*CONSTANT_1),&(v208_2));
        let v208_4: Space = if has_head(&(v208_3)) { singleton(&[]) } else { Space::new() };
        drop(v208_3);
        let v208_5: Space = subtract(&(*CONSTANT_0),&(v208_4));
        drop(v208_4);
        let v208_8: Space = if (&(v208_5)).is_empty() { Space::new() } else {
          let v209_6: Path = concat_path(&(v207_6),&v195_20_cursor.path()[(v195_20_origin + 1)..(v195_20_origin + 2)]);
          let mut v209_7 = Space::new();
          let mut v209_7_write = v209_7.write_zipper();
          for v209_7_byte in v195_20_cursor.child_mask().iter() {
            v195_20_cursor.descend_to_existing_byte(v209_7_byte);
            {
            let v210_2: Space = singleton(&v195_20_cursor.path()[(v195_20_origin + 2)..(v195_20_origin + 3)]);
            let v210_3: Space = intersect(&(*CONSTANT_1),&(v210_2));
            let v210_4: Space = if has_head(&(v210_3)) { singleton(&[]) } else { Space::new() };
            drop(v210_3);
            let v210_5: Space = subtract(&(*CONSTANT_0),&(v210_4));
            drop(v210_4);
            let v210_8: Space = if (&(v210_5)).is_empty() { Space::new() } else {
              let v211_6: Path = concat_path(&(v209_6),&v195_20_cursor.path()[(v195_20_origin + 2)..(v195_20_origin + 3)]);
              let v211_7: Space = routine_24(c, &(v211_6), &v195_20_cursor);
              compose(&(v210_5),&(v211_7))
            };
            drop(v210_5);
            let v210_9: Space = intersect(&(*CONSTANT_1),&(v210_2));
            drop(v210_2);
            let v210_10: Space = if has_head(&(v210_9)) { singleton(&[]) } else { Space::new() };
            drop(v210_9);
            let v210_12: Space = if (&(v210_10)).is_empty() { Space::new() } else {
              let v212_6: Path = concat_path(&(v209_6),&v195_20_cursor.path()[(v195_20_origin + 2)..(v195_20_origin + 3)]);
              let v212_11: Space = routine_25(c, &(v212_6), &v195_20_cursor);
              drop(v212_6);
              compose(&(v210_10),&(v212_11))
            };
            drop(v210_10);
            let v210_13: Space = unite(&(v210_8),&(v210_12));
            join_wrapped_into(&mut v209_7_write,&((v210_13).read_zipper()),&[]);
            }
            v195_20_cursor.ascend(1);
          }
          drop(v209_7_write);
          drop(v209_6);
          compose(&(v208_5),&(v209_7))
        };
        drop(v208_5);
        let v208_9: Space = intersect(&(*CONSTANT_1),&(v208_2));
        drop(v208_2);
        let v208_10: Space = if has_head(&(v208_9)) { singleton(&[]) } else { Space::new() };
        drop(v208_9);
        let v208_11: Space = compose(&(v208_10),&v195_20_cursor);
        drop(v208_10);
        let v208_12: Space = unite(&(v208_8),&(v208_11));
        drop(v208_11);
        join_wrapped_into(&mut v207_11_write,&((v208_12).read_zipper()),&[]);
        }
        v195_20_cursor.ascend(1);
      }
      drop(v207_11_write);
      drop(v207_6);
      compose(&(v196_10),&(v207_11))
    };
    drop(v196_10);
    let v196_13: Space = unite(&(v196_8),&(v196_12));
    join_wrapped_into(&mut v195_20_write,&((v196_13).read_zipper()),&[]);
    }
    v195_20_cursor.ascend(1);
  }
  drop(v195_20_cursor);
  drop(v195_20_write);
  (v195_20).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v213_14 = Space::new();
  let mut v213_14_write = v213_14.write_zipper();
  let mut v213_14_cursor = (*s0).read_zipper();
  let v213_14_origin = v213_14_cursor.path().len();
  for v213_14_byte in v213_14_cursor.child_mask().iter() {
    v213_14_cursor.descend_to_existing_byte(v213_14_byte);
    {
    let v214_2: Space = singleton(&v213_14_cursor.path()[v213_14_origin..(v213_14_origin + 1)]);
    let v214_3: Space = intersect(&(*CONSTANT_1),&(v214_2));
    let v214_4: Space = if has_head(&(v214_3)) { singleton(&[]) } else { Space::new() };
    drop(v214_3);
    let v214_5: Space = subtract(&(*CONSTANT_0),&(v214_4));
    drop(v214_4);
    let v214_8: Space = if (&(v214_5)).is_empty() { Space::new() } else {
      let v215_6: Path = concat_path(&(*p0),&v213_14_cursor.path()[v213_14_origin..(v213_14_origin + 1)]);
      let mut v215_7 = Space::new();
      let mut v215_7_write = v215_7.write_zipper();
      for v215_7_byte in v213_14_cursor.child_mask().iter() {
        v213_14_cursor.descend_to_existing_byte(v215_7_byte);
        {
        let v216_2: Space = singleton(&v213_14_cursor.path()[(v213_14_origin + 1)..(v213_14_origin + 2)]);
        let v216_3: Space = intersect(&(*CONSTANT_1),&(v216_2));
        let v216_4: Space = if has_head(&(v216_3)) { singleton(&[]) } else { Space::new() };
        drop(v216_3);
        let v216_5: Space = subtract(&(*CONSTANT_0),&(v216_4));
        drop(v216_4);
        let v216_8: Space = if (&(v216_5)).is_empty() { Space::new() } else {
          let v217_6: Path = concat_path(&(v215_6),&v213_14_cursor.path()[(v213_14_origin + 1)..(v213_14_origin + 2)]);
          let mut v217_7 = Space::new();
          let mut v217_7_write = v217_7.write_zipper();
          for v217_7_byte in v213_14_cursor.child_mask().iter() {
            v213_14_cursor.descend_to_existing_byte(v217_7_byte);
            {
            let v218_2: Space = singleton(&v213_14_cursor.path()[(v213_14_origin + 2)..(v213_14_origin + 3)]);
            let v218_3: Space = intersect(&(*CONSTANT_1),&(v218_2));
            let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
            drop(v218_3);
            let v218_5: Space = subtract(&(*CONSTANT_0),&(v218_4));
            drop(v218_4);
            let v218_8: Space = if (&(v218_5)).is_empty() { Space::new() } else {
              let v219_6: Path = concat_path(&(v217_6),&v213_14_cursor.path()[(v213_14_origin + 2)..(v213_14_origin + 3)]);
              let v219_7: Space = routine_24(c, &(v219_6), &v213_14_cursor);
              compose(&(v218_5),&(v219_7))
            };
            drop(v218_5);
            let v218_9: Space = intersect(&(*CONSTANT_1),&(v218_2));
            drop(v218_2);
            let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
            drop(v218_9);
            let v218_12: Space = if (&(v218_10)).is_empty() { Space::new() } else {
              let v220_6: Path = concat_path(&(v217_6),&v213_14_cursor.path()[(v213_14_origin + 2)..(v213_14_origin + 3)]);
              let v220_11: Space = routine_25(c, &(v220_6), &v213_14_cursor);
              drop(v220_6);
              compose(&(v218_10),&(v220_11))
            };
            drop(v218_10);
            let v218_13: Space = unite(&(v218_8),&(v218_12));
            join_wrapped_into(&mut v217_7_write,&((v218_13).read_zipper()),&[]);
            }
            v213_14_cursor.ascend(1);
          }
          drop(v217_7_write);
          compose(&(v216_5),&(v217_7))
        };
        drop(v216_5);
        let v216_9: Space = intersect(&(*CONSTANT_1),&(v216_2));
        drop(v216_2);
        let v216_10: Space = if has_head(&(v216_9)) { singleton(&[]) } else { Space::new() };
        drop(v216_9);
        let v216_12: Space = if (&(v216_10)).is_empty() { Space::new() } else {
          let v221_6: Path = concat_path(&(v215_6),&v213_14_cursor.path()[(v213_14_origin + 1)..(v213_14_origin + 2)]);
          let mut v221_11 = Space::new();
          let mut v221_11_write = v221_11.write_zipper();
          for v221_11_byte in v213_14_cursor.child_mask().iter() {
            v213_14_cursor.descend_to_existing_byte(v221_11_byte);
            {
            let v222_2: Space = singleton(&v213_14_cursor.path()[(v213_14_origin + 2)..(v213_14_origin + 3)]);
            let v222_3: Space = intersect(&(*CONSTANT_1),&(v222_2));
            let v222_4: Space = if has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
            drop(v222_3);
            let v222_5: Space = subtract(&(*CONSTANT_0),&(v222_4));
            drop(v222_4);
            let v222_8: Space = if (&(v222_5)).is_empty() { Space::new() } else {
              let v223_6: Path = concat_path(&(v221_6),&v213_14_cursor.path()[(v213_14_origin + 2)..(v213_14_origin + 3)]);
              let v223_7: Space = routine_24(c, &(v223_6), &v213_14_cursor);
              compose(&(v222_5),&(v223_7))
            };
            drop(v222_5);
            let v222_9: Space = intersect(&(*CONSTANT_1),&(v222_2));
            drop(v222_2);
            let v222_10: Space = if has_head(&(v222_9)) { singleton(&[]) } else { Space::new() };
            drop(v222_9);
            let v222_12: Space = if (&(v222_10)).is_empty() { Space::new() } else {
              let v224_6: Path = concat_path(&(v221_6),&v213_14_cursor.path()[(v213_14_origin + 2)..(v213_14_origin + 3)]);
              let v224_11: Space = routine_12(c, &(v224_6), &v213_14_cursor);
              drop(v224_6);
              compose(&(v222_10),&(v224_11))
            };
            drop(v222_10);
            let v222_13: Space = unite(&(v222_8),&(v222_12));
            join_wrapped_into(&mut v221_11_write,&((v222_13).read_zipper()),&[]);
            }
            v213_14_cursor.ascend(1);
          }
          drop(v221_11_write);
          drop(v221_6);
          compose(&(v216_10),&(v221_11))
        };
        drop(v216_10);
        let v216_13: Space = unite(&(v216_8),&(v216_12));
        join_wrapped_into(&mut v215_7_write,&((v216_13).read_zipper()),&[]);
        }
        v213_14_cursor.ascend(1);
      }
      drop(v215_7_write);
      drop(v215_6);
      compose(&(v214_5),&(v215_7))
    };
    drop(v214_5);
    let v214_9: Space = intersect(&(*CONSTANT_1),&(v214_2));
    drop(v214_2);
    let v214_10: Space = if has_head(&(v214_9)) { singleton(&[]) } else { Space::new() };
    drop(v214_9);
    let v214_11: Space = compose(&(v214_10),&v213_14_cursor);
    drop(v214_10);
    let v214_12: Space = unite(&(v214_8),&(v214_11));
    drop(v214_11);
    join_wrapped_into(&mut v213_14_write,&((v214_12).read_zipper()),&[]);
    }
    v213_14_cursor.ascend(1);
  }
  drop(v213_14_cursor);
  drop(v213_14_write);
  (v213_14).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v226_20 = Space::new();
  let mut v226_20_write = v226_20.write_zipper();
  let mut v226_20_cursor = (*s0).read_zipper();
  let v226_20_origin = v226_20_cursor.path().len();
  for v226_20_byte in v226_20_cursor.child_mask().iter() {
    v226_20_cursor.descend_to_existing_byte(v226_20_byte);
    {
    let v227_2: Space = singleton(&v226_20_cursor.path()[v226_20_origin..(v226_20_origin + 1)]);
    let v227_3: Space = intersect(&(*CONSTANT_1),&(v227_2));
    let v227_4: Space = if has_head(&(v227_3)) { singleton(&[]) } else { Space::new() };
    drop(v227_3);
    let v227_5: Space = subtract(&(*CONSTANT_0),&(v227_4));
    drop(v227_4);
    let v227_8: Space = if (&(v227_5)).is_empty() { Space::new() } else {
      let v228_6: Path = concat_path(&(*p0),&v226_20_cursor.path()[v226_20_origin..(v226_20_origin + 1)]);
      let mut v228_7 = Space::new();
      let mut v228_7_write = v228_7.write_zipper();
      for v228_7_byte in v226_20_cursor.child_mask().iter() {
        v226_20_cursor.descend_to_existing_byte(v228_7_byte);
        {
        let v229_2: Space = singleton(&v226_20_cursor.path()[(v226_20_origin + 1)..(v226_20_origin + 2)]);
        let v229_3: Space = intersect(&(*CONSTANT_1),&(v229_2));
        let v229_4: Space = if has_head(&(v229_3)) { singleton(&[]) } else { Space::new() };
        drop(v229_3);
        let v229_5: Space = subtract(&(*CONSTANT_0),&(v229_4));
        drop(v229_4);
        let v229_8: Space = if (&(v229_5)).is_empty() { Space::new() } else {
          let v230_6: Path = concat_path(&(v228_6),&v226_20_cursor.path()[(v226_20_origin + 1)..(v226_20_origin + 2)]);
          let mut v230_7 = Space::new();
          let mut v230_7_write = v230_7.write_zipper();
          for v230_7_byte in v226_20_cursor.child_mask().iter() {
            v226_20_cursor.descend_to_existing_byte(v230_7_byte);
            {
            let v231_2: Space = singleton(&v226_20_cursor.path()[(v226_20_origin + 2)..(v226_20_origin + 3)]);
            let v231_3: Space = intersect(&(*CONSTANT_1),&(v231_2));
            let v231_4: Space = if has_head(&(v231_3)) { singleton(&[]) } else { Space::new() };
            drop(v231_3);
            let v231_5: Space = subtract(&(*CONSTANT_0),&(v231_4));
            drop(v231_4);
            let v231_8: Space = if (&(v231_5)).is_empty() { Space::new() } else {
              let v232_6: Path = concat_path(&(v230_6),&v226_20_cursor.path()[(v226_20_origin + 2)..(v226_20_origin + 3)]);
              let v232_7: Space = routine_26(c, &(v232_6), &v226_20_cursor);
              compose(&(v231_5),&(v232_7))
            };
            drop(v231_5);
            let v231_9: Space = intersect(&(*CONSTANT_1),&(v231_2));
            drop(v231_2);
            let v231_10: Space = if has_head(&(v231_9)) { singleton(&[]) } else { Space::new() };
            drop(v231_9);
            let v231_12: Space = if (&(v231_10)).is_empty() { Space::new() } else {
              let v233_6: Path = concat_path(&(v230_6),&v226_20_cursor.path()[(v226_20_origin + 2)..(v226_20_origin + 3)]);
              let v233_11: Space = routine_27(c, &(v233_6), &v226_20_cursor);
              drop(v233_6);
              compose(&(v231_10),&(v233_11))
            };
            drop(v231_10);
            let v231_13: Space = unite(&(v231_8),&(v231_12));
            join_wrapped_into(&mut v230_7_write,&((v231_13).read_zipper()),&[]);
            }
            v226_20_cursor.ascend(1);
          }
          drop(v230_7_write);
          compose(&(v229_5),&(v230_7))
        };
        drop(v229_5);
        let v229_9: Space = intersect(&(*CONSTANT_1),&(v229_2));
        drop(v229_2);
        let v229_10: Space = if has_head(&(v229_9)) { singleton(&[]) } else { Space::new() };
        drop(v229_9);
        let v229_12: Space = if (&(v229_10)).is_empty() { Space::new() } else {
          let v234_6: Path = concat_path(&(v228_6),&v226_20_cursor.path()[(v226_20_origin + 1)..(v226_20_origin + 2)]);
          let mut v234_11 = Space::new();
          let mut v234_11_write = v234_11.write_zipper();
          for v234_11_byte in v226_20_cursor.child_mask().iter() {
            v226_20_cursor.descend_to_existing_byte(v234_11_byte);
            {
            let v235_2: Space = singleton(&v226_20_cursor.path()[(v226_20_origin + 2)..(v226_20_origin + 3)]);
            let v235_3: Space = intersect(&(*CONSTANT_1),&(v235_2));
            let v235_4: Space = if has_head(&(v235_3)) { singleton(&[]) } else { Space::new() };
            drop(v235_3);
            let v235_5: Space = subtract(&(*CONSTANT_0),&(v235_4));
            drop(v235_4);
            let v235_8: Space = if (&(v235_5)).is_empty() { Space::new() } else {
              let v236_6: Path = concat_path(&(v234_6),&v226_20_cursor.path()[(v226_20_origin + 2)..(v226_20_origin + 3)]);
              let v236_7: Space = routine_26(c, &(v236_6), &v226_20_cursor);
              compose(&(v235_5),&(v236_7))
            };
            drop(v235_5);
            let v235_9: Space = intersect(&(*CONSTANT_1),&(v235_2));
            drop(v235_2);
            let v235_10: Space = if has_head(&(v235_9)) { singleton(&[]) } else { Space::new() };
            drop(v235_9);
            let v235_12: Space = if (&(v235_10)).is_empty() { Space::new() } else {
              let v237_6: Path = concat_path(&(v234_6),&v226_20_cursor.path()[(v226_20_origin + 2)..(v226_20_origin + 3)]);
              let v237_11: Space = routine_15(c, &(v237_6), &v226_20_cursor);
              drop(v237_6);
              compose(&(v235_10),&(v237_11))
            };
            drop(v235_10);
            let v235_13: Space = unite(&(v235_8),&(v235_12));
            join_wrapped_into(&mut v234_11_write,&((v235_13).read_zipper()),&[]);
            }
            v226_20_cursor.ascend(1);
          }
          drop(v234_11_write);
          drop(v234_6);
          compose(&(v229_10),&(v234_11))
        };
        drop(v229_10);
        let v229_13: Space = unite(&(v229_8),&(v229_12));
        join_wrapped_into(&mut v228_7_write,&((v229_13).read_zipper()),&[]);
        }
        v226_20_cursor.ascend(1);
      }
      drop(v228_7_write);
      compose(&(v227_5),&(v228_7))
    };
    drop(v227_5);
    let v227_9: Space = intersect(&(*CONSTANT_1),&(v227_2));
    drop(v227_2);
    let v227_10: Space = if has_head(&(v227_9)) { singleton(&[]) } else { Space::new() };
    drop(v227_9);
    let v227_12: Space = if (&(v227_10)).is_empty() { Space::new() } else {
      let v238_6: Path = concat_path(&(*p0),&v226_20_cursor.path()[v226_20_origin..(v226_20_origin + 1)]);
      let mut v238_11 = Space::new();
      let mut v238_11_write = v238_11.write_zipper();
      for v238_11_byte in v226_20_cursor.child_mask().iter() {
        v226_20_cursor.descend_to_existing_byte(v238_11_byte);
        {
        let v239_2: Space = singleton(&v226_20_cursor.path()[(v226_20_origin + 1)..(v226_20_origin + 2)]);
        let v239_3: Space = intersect(&(*CONSTANT_1),&(v239_2));
        let v239_4: Space = if has_head(&(v239_3)) { singleton(&[]) } else { Space::new() };
        drop(v239_3);
        let v239_5: Space = subtract(&(*CONSTANT_0),&(v239_4));
        drop(v239_4);
        let v239_8: Space = if (&(v239_5)).is_empty() { Space::new() } else {
          let v240_6: Path = concat_path(&(v238_6),&v226_20_cursor.path()[(v226_20_origin + 1)..(v226_20_origin + 2)]);
          let mut v240_7 = Space::new();
          let mut v240_7_write = v240_7.write_zipper();
          for v240_7_byte in v226_20_cursor.child_mask().iter() {
            v226_20_cursor.descend_to_existing_byte(v240_7_byte);
            {
            let v241_2: Space = singleton(&v226_20_cursor.path()[(v226_20_origin + 2)..(v226_20_origin + 3)]);
            let v241_3: Space = intersect(&(*CONSTANT_1),&(v241_2));
            let v241_4: Space = if has_head(&(v241_3)) { singleton(&[]) } else { Space::new() };
            drop(v241_3);
            let v241_5: Space = subtract(&(*CONSTANT_0),&(v241_4));
            drop(v241_4);
            let v241_8: Space = if (&(v241_5)).is_empty() { Space::new() } else {
              let v242_6: Path = concat_path(&(v240_6),&v226_20_cursor.path()[(v226_20_origin + 2)..(v226_20_origin + 3)]);
              let v242_7: Space = routine_26(c, &(v242_6), &v226_20_cursor);
              compose(&(v241_5),&(v242_7))
            };
            drop(v241_5);
            let v241_9: Space = intersect(&(*CONSTANT_1),&(v241_2));
            drop(v241_2);
            let v241_10: Space = if has_head(&(v241_9)) { singleton(&[]) } else { Space::new() };
            drop(v241_9);
            let v241_12: Space = if (&(v241_10)).is_empty() { Space::new() } else {
              let v243_6: Path = concat_path(&(v240_6),&v226_20_cursor.path()[(v226_20_origin + 2)..(v226_20_origin + 3)]);
              let v243_11: Space = routine_27(c, &(v243_6), &v226_20_cursor);
              drop(v243_6);
              compose(&(v241_10),&(v243_11))
            };
            drop(v241_10);
            let v241_13: Space = unite(&(v241_8),&(v241_12));
            join_wrapped_into(&mut v240_7_write,&((v241_13).read_zipper()),&[]);
            }
            v226_20_cursor.ascend(1);
          }
          drop(v240_7_write);
          drop(v240_6);
          compose(&(v239_5),&(v240_7))
        };
        drop(v239_5);
        let v239_9: Space = intersect(&(*CONSTANT_1),&(v239_2));
        drop(v239_2);
        let v239_10: Space = if has_head(&(v239_9)) { singleton(&[]) } else { Space::new() };
        drop(v239_9);
        let v239_11: Space = compose(&(v239_10),&v226_20_cursor);
        drop(v239_10);
        let v239_12: Space = unite(&(v239_8),&(v239_11));
        drop(v239_11);
        join_wrapped_into(&mut v238_11_write,&((v239_12).read_zipper()),&[]);
        }
        v226_20_cursor.ascend(1);
      }
      drop(v238_11_write);
      drop(v238_6);
      compose(&(v227_10),&(v238_11))
    };
    drop(v227_10);
    let v227_13: Space = unite(&(v227_8),&(v227_12));
    join_wrapped_into(&mut v226_20_write,&((v227_13).read_zipper()),&[]);
    }
    v226_20_cursor.ascend(1);
  }
  drop(v226_20_cursor);
  drop(v226_20_write);
  (v226_20).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v244_14 = Space::new();
  let mut v244_14_write = v244_14.write_zipper();
  let mut v244_14_cursor = (*s0).read_zipper();
  let v244_14_origin = v244_14_cursor.path().len();
  for v244_14_byte in v244_14_cursor.child_mask().iter() {
    v244_14_cursor.descend_to_existing_byte(v244_14_byte);
    {
    let v245_2: Space = singleton(&v244_14_cursor.path()[v244_14_origin..(v244_14_origin + 1)]);
    let v245_3: Space = intersect(&(*CONSTANT_1),&(v245_2));
    let v245_4: Space = if has_head(&(v245_3)) { singleton(&[]) } else { Space::new() };
    drop(v245_3);
    let v245_5: Space = subtract(&(*CONSTANT_0),&(v245_4));
    drop(v245_4);
    let v245_8: Space = if (&(v245_5)).is_empty() { Space::new() } else {
      let v246_6: Path = concat_path(&(*p0),&v244_14_cursor.path()[v244_14_origin..(v244_14_origin + 1)]);
      let mut v246_7 = Space::new();
      let mut v246_7_write = v246_7.write_zipper();
      for v246_7_byte in v244_14_cursor.child_mask().iter() {
        v244_14_cursor.descend_to_existing_byte(v246_7_byte);
        {
        let v247_2: Space = singleton(&v244_14_cursor.path()[(v244_14_origin + 1)..(v244_14_origin + 2)]);
        let v247_3: Space = intersect(&(*CONSTANT_1),&(v247_2));
        let v247_4: Space = if has_head(&(v247_3)) { singleton(&[]) } else { Space::new() };
        drop(v247_3);
        let v247_5: Space = subtract(&(*CONSTANT_0),&(v247_4));
        drop(v247_4);
        let v247_8: Space = if (&(v247_5)).is_empty() { Space::new() } else {
          let v248_6: Path = concat_path(&(v246_6),&v244_14_cursor.path()[(v244_14_origin + 1)..(v244_14_origin + 2)]);
          let mut v248_7 = Space::new();
          let mut v248_7_write = v248_7.write_zipper();
          for v248_7_byte in v244_14_cursor.child_mask().iter() {
            v244_14_cursor.descend_to_existing_byte(v248_7_byte);
            {
            let v249_2: Space = singleton(&v244_14_cursor.path()[(v244_14_origin + 2)..(v244_14_origin + 3)]);
            let v249_3: Space = intersect(&(*CONSTANT_1),&(v249_2));
            let v249_4: Space = if has_head(&(v249_3)) { singleton(&[]) } else { Space::new() };
            drop(v249_3);
            let v249_5: Space = subtract(&(*CONSTANT_0),&(v249_4));
            drop(v249_4);
            let v249_8: Space = if (&(v249_5)).is_empty() { Space::new() } else {
              let v250_6: Path = concat_path(&(v248_6),&v244_14_cursor.path()[(v244_14_origin + 2)..(v244_14_origin + 3)]);
              let v250_7: Space = routine_26(c, &(v250_6), &v244_14_cursor);
              compose(&(v249_5),&(v250_7))
            };
            drop(v249_5);
            let v249_9: Space = intersect(&(*CONSTANT_1),&(v249_2));
            drop(v249_2);
            let v249_10: Space = if has_head(&(v249_9)) { singleton(&[]) } else { Space::new() };
            drop(v249_9);
            let v249_12: Space = if (&(v249_10)).is_empty() { Space::new() } else {
              let v251_6: Path = concat_path(&(v248_6),&v244_14_cursor.path()[(v244_14_origin + 2)..(v244_14_origin + 3)]);
              let v251_11: Space = routine_27(c, &(v251_6), &v244_14_cursor);
              drop(v251_6);
              compose(&(v249_10),&(v251_11))
            };
            drop(v249_10);
            let v249_13: Space = unite(&(v249_8),&(v249_12));
            join_wrapped_into(&mut v248_7_write,&((v249_13).read_zipper()),&[]);
            }
            v244_14_cursor.ascend(1);
          }
          drop(v248_7_write);
          compose(&(v247_5),&(v248_7))
        };
        drop(v247_5);
        let v247_9: Space = intersect(&(*CONSTANT_1),&(v247_2));
        drop(v247_2);
        let v247_10: Space = if has_head(&(v247_9)) { singleton(&[]) } else { Space::new() };
        drop(v247_9);
        let v247_12: Space = if (&(v247_10)).is_empty() { Space::new() } else {
          let v252_6: Path = concat_path(&(v246_6),&v244_14_cursor.path()[(v244_14_origin + 1)..(v244_14_origin + 2)]);
          let mut v252_11 = Space::new();
          let mut v252_11_write = v252_11.write_zipper();
          for v252_11_byte in v244_14_cursor.child_mask().iter() {
            v244_14_cursor.descend_to_existing_byte(v252_11_byte);
            {
            let v253_2: Space = singleton(&v244_14_cursor.path()[(v244_14_origin + 2)..(v244_14_origin + 3)]);
            let v253_3: Space = intersect(&(*CONSTANT_1),&(v253_2));
            let v253_4: Space = if has_head(&(v253_3)) { singleton(&[]) } else { Space::new() };
            drop(v253_3);
            let v253_5: Space = subtract(&(*CONSTANT_0),&(v253_4));
            drop(v253_4);
            let v253_8: Space = if (&(v253_5)).is_empty() { Space::new() } else {
              let v254_6: Path = concat_path(&(v252_6),&v244_14_cursor.path()[(v244_14_origin + 2)..(v244_14_origin + 3)]);
              let v254_7: Space = routine_26(c, &(v254_6), &v244_14_cursor);
              compose(&(v253_5),&(v254_7))
            };
            drop(v253_5);
            let v253_9: Space = intersect(&(*CONSTANT_1),&(v253_2));
            drop(v253_2);
            let v253_10: Space = if has_head(&(v253_9)) { singleton(&[]) } else { Space::new() };
            drop(v253_9);
            let v253_12: Space = if (&(v253_10)).is_empty() { Space::new() } else {
              let v255_6: Path = concat_path(&(v252_6),&v244_14_cursor.path()[(v244_14_origin + 2)..(v244_14_origin + 3)]);
              let v255_11: Space = routine_15(c, &(v255_6), &v244_14_cursor);
              drop(v255_6);
              compose(&(v253_10),&(v255_11))
            };
            drop(v253_10);
            let v253_13: Space = unite(&(v253_8),&(v253_12));
            join_wrapped_into(&mut v252_11_write,&((v253_13).read_zipper()),&[]);
            }
            v244_14_cursor.ascend(1);
          }
          drop(v252_11_write);
          drop(v252_6);
          compose(&(v247_10),&(v252_11))
        };
        drop(v247_10);
        let v247_13: Space = unite(&(v247_8),&(v247_12));
        join_wrapped_into(&mut v246_7_write,&((v247_13).read_zipper()),&[]);
        }
        v244_14_cursor.ascend(1);
      }
      drop(v246_7_write);
      drop(v246_6);
      compose(&(v245_5),&(v246_7))
    };
    drop(v245_5);
    let v245_9: Space = intersect(&(*CONSTANT_1),&(v245_2));
    drop(v245_2);
    let v245_10: Space = if has_head(&(v245_9)) { singleton(&[]) } else { Space::new() };
    drop(v245_9);
    let v245_11: Space = compose(&(v245_10),&v244_14_cursor);
    drop(v245_10);
    let v245_12: Space = unite(&(v245_8),&(v245_11));
    drop(v245_11);
    join_wrapped_into(&mut v244_14_write,&((v245_12).read_zipper()),&[]);
    }
    v244_14_cursor.ascend(1);
  }
  drop(v244_14_cursor);
  drop(v244_14_write);
  (v244_14).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_16(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v257_20 = Space::new();
  let mut v257_20_write = v257_20.write_zipper();
  let mut v257_20_cursor = (*s0).read_zipper();
  let v257_20_origin = v257_20_cursor.path().len();
  for v257_20_byte in v257_20_cursor.child_mask().iter() {
    v257_20_cursor.descend_to_existing_byte(v257_20_byte);
    {
    let v258_2: Space = singleton(&v257_20_cursor.path()[v257_20_origin..(v257_20_origin + 1)]);
    let v258_3: Space = intersect(&(*CONSTANT_1),&(v258_2));
    let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
    drop(v258_3);
    let v258_5: Space = subtract(&(*CONSTANT_0),&(v258_4));
    drop(v258_4);
    let v258_8: Space = if (&(v258_5)).is_empty() { Space::new() } else {
      let v259_6: Path = concat_path(&(*p0),&v257_20_cursor.path()[v257_20_origin..(v257_20_origin + 1)]);
      let mut v259_7 = Space::new();
      let mut v259_7_write = v259_7.write_zipper();
      for v259_7_byte in v257_20_cursor.child_mask().iter() {
        v257_20_cursor.descend_to_existing_byte(v259_7_byte);
        {
        let v260_2: Space = singleton(&v257_20_cursor.path()[(v257_20_origin + 1)..(v257_20_origin + 2)]);
        let v260_3: Space = intersect(&(*CONSTANT_1),&(v260_2));
        let v260_4: Space = if has_head(&(v260_3)) { singleton(&[]) } else { Space::new() };
        drop(v260_3);
        let v260_5: Space = subtract(&(*CONSTANT_0),&(v260_4));
        drop(v260_4);
        let v260_8: Space = if (&(v260_5)).is_empty() { Space::new() } else {
          let v261_6: Path = concat_path(&(v259_6),&v257_20_cursor.path()[(v257_20_origin + 1)..(v257_20_origin + 2)]);
          let mut v261_7 = Space::new();
          let mut v261_7_write = v261_7.write_zipper();
          for v261_7_byte in v257_20_cursor.child_mask().iter() {
            v257_20_cursor.descend_to_existing_byte(v261_7_byte);
            {
            let v262_2: Space = singleton(&v257_20_cursor.path()[(v257_20_origin + 2)..(v257_20_origin + 3)]);
            let v262_3: Space = intersect(&(*CONSTANT_1),&(v262_2));
            let v262_4: Space = if has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
            drop(v262_3);
            let v262_5: Space = subtract(&(*CONSTANT_0),&(v262_4));
            drop(v262_4);
            let v262_8: Space = if (&(v262_5)).is_empty() { Space::new() } else {
              let v263_6: Path = concat_path(&(v261_6),&v257_20_cursor.path()[(v257_20_origin + 2)..(v257_20_origin + 3)]);
              let v263_7: Space = routine_28(c, &(v263_6), &v257_20_cursor);
              compose(&(v262_5),&(v263_7))
            };
            drop(v262_5);
            let v262_9: Space = intersect(&(*CONSTANT_1),&(v262_2));
            drop(v262_2);
            let v262_10: Space = if has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
            drop(v262_9);
            let v262_12: Space = if (&(v262_10)).is_empty() { Space::new() } else {
              let v264_6: Path = concat_path(&(v261_6),&v257_20_cursor.path()[(v257_20_origin + 2)..(v257_20_origin + 3)]);
              let v264_11: Space = routine_29(c, &(v264_6), &v257_20_cursor);
              drop(v264_6);
              compose(&(v262_10),&(v264_11))
            };
            drop(v262_10);
            let v262_13: Space = unite(&(v262_8),&(v262_12));
            join_wrapped_into(&mut v261_7_write,&((v262_13).read_zipper()),&[]);
            }
            v257_20_cursor.ascend(1);
          }
          drop(v261_7_write);
          compose(&(v260_5),&(v261_7))
        };
        drop(v260_5);
        let v260_9: Space = intersect(&(*CONSTANT_1),&(v260_2));
        drop(v260_2);
        let v260_10: Space = if has_head(&(v260_9)) { singleton(&[]) } else { Space::new() };
        drop(v260_9);
        let v260_12: Space = if (&(v260_10)).is_empty() { Space::new() } else {
          let v265_6: Path = concat_path(&(v259_6),&v257_20_cursor.path()[(v257_20_origin + 1)..(v257_20_origin + 2)]);
          let mut v265_11 = Space::new();
          let mut v265_11_write = v265_11.write_zipper();
          for v265_11_byte in v257_20_cursor.child_mask().iter() {
            v257_20_cursor.descend_to_existing_byte(v265_11_byte);
            {
            let v266_2: Space = singleton(&v257_20_cursor.path()[(v257_20_origin + 2)..(v257_20_origin + 3)]);
            let v266_3: Space = intersect(&(*CONSTANT_1),&(v266_2));
            let v266_4: Space = if has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
            drop(v266_3);
            let v266_5: Space = subtract(&(*CONSTANT_0),&(v266_4));
            drop(v266_4);
            let v266_8: Space = if (&(v266_5)).is_empty() { Space::new() } else {
              let v267_6: Path = concat_path(&(v265_6),&v257_20_cursor.path()[(v257_20_origin + 2)..(v257_20_origin + 3)]);
              let v267_7: Space = routine_28(c, &(v267_6), &v257_20_cursor);
              compose(&(v266_5),&(v267_7))
            };
            drop(v266_5);
            let v266_9: Space = intersect(&(*CONSTANT_1),&(v266_2));
            drop(v266_2);
            let v266_10: Space = if has_head(&(v266_9)) { singleton(&[]) } else { Space::new() };
            drop(v266_9);
            let v266_12: Space = if (&(v266_10)).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v265_6),&v257_20_cursor.path()[(v257_20_origin + 2)..(v257_20_origin + 3)]);
              let v268_11: Space = routine_12(c, &(v268_6), &v257_20_cursor);
              drop(v268_6);
              compose(&(v266_10),&(v268_11))
            };
            drop(v266_10);
            let v266_13: Space = unite(&(v266_8),&(v266_12));
            join_wrapped_into(&mut v265_11_write,&((v266_13).read_zipper()),&[]);
            }
            v257_20_cursor.ascend(1);
          }
          drop(v265_11_write);
          drop(v265_6);
          compose(&(v260_10),&(v265_11))
        };
        drop(v260_10);
        let v260_13: Space = unite(&(v260_8),&(v260_12));
        join_wrapped_into(&mut v259_7_write,&((v260_13).read_zipper()),&[]);
        }
        v257_20_cursor.ascend(1);
      }
      drop(v259_7_write);
      compose(&(v258_5),&(v259_7))
    };
    drop(v258_5);
    let v258_9: Space = intersect(&(*CONSTANT_1),&(v258_2));
    drop(v258_2);
    let v258_10: Space = if has_head(&(v258_9)) { singleton(&[]) } else { Space::new() };
    drop(v258_9);
    let v258_12: Space = if (&(v258_10)).is_empty() { Space::new() } else {
      let v269_6: Path = concat_path(&(*p0),&v257_20_cursor.path()[v257_20_origin..(v257_20_origin + 1)]);
      let mut v269_11 = Space::new();
      let mut v269_11_write = v269_11.write_zipper();
      for v269_11_byte in v257_20_cursor.child_mask().iter() {
        v257_20_cursor.descend_to_existing_byte(v269_11_byte);
        {
        let v270_2: Space = singleton(&v257_20_cursor.path()[(v257_20_origin + 1)..(v257_20_origin + 2)]);
        let v270_3: Space = intersect(&(*CONSTANT_1),&(v270_2));
        let v270_4: Space = if has_head(&(v270_3)) { singleton(&[]) } else { Space::new() };
        drop(v270_3);
        let v270_5: Space = subtract(&(*CONSTANT_0),&(v270_4));
        drop(v270_4);
        let v270_8: Space = if (&(v270_5)).is_empty() { Space::new() } else {
          let v271_6: Path = concat_path(&(v269_6),&v257_20_cursor.path()[(v257_20_origin + 1)..(v257_20_origin + 2)]);
          let mut v271_7 = Space::new();
          let mut v271_7_write = v271_7.write_zipper();
          for v271_7_byte in v257_20_cursor.child_mask().iter() {
            v257_20_cursor.descend_to_existing_byte(v271_7_byte);
            {
            let v272_2: Space = singleton(&v257_20_cursor.path()[(v257_20_origin + 2)..(v257_20_origin + 3)]);
            let v272_3: Space = intersect(&(*CONSTANT_1),&(v272_2));
            let v272_4: Space = if has_head(&(v272_3)) { singleton(&[]) } else { Space::new() };
            drop(v272_3);
            let v272_5: Space = subtract(&(*CONSTANT_0),&(v272_4));
            drop(v272_4);
            let v272_8: Space = if (&(v272_5)).is_empty() { Space::new() } else {
              let v273_6: Path = concat_path(&(v271_6),&v257_20_cursor.path()[(v257_20_origin + 2)..(v257_20_origin + 3)]);
              let v273_7: Space = routine_28(c, &(v273_6), &v257_20_cursor);
              compose(&(v272_5),&(v273_7))
            };
            drop(v272_5);
            let v272_9: Space = intersect(&(*CONSTANT_1),&(v272_2));
            drop(v272_2);
            let v272_10: Space = if has_head(&(v272_9)) { singleton(&[]) } else { Space::new() };
            drop(v272_9);
            let v272_12: Space = if (&(v272_10)).is_empty() { Space::new() } else {
              let v274_6: Path = concat_path(&(v271_6),&v257_20_cursor.path()[(v257_20_origin + 2)..(v257_20_origin + 3)]);
              let v274_11: Space = routine_29(c, &(v274_6), &v257_20_cursor);
              drop(v274_6);
              compose(&(v272_10),&(v274_11))
            };
            drop(v272_10);
            let v272_13: Space = unite(&(v272_8),&(v272_12));
            join_wrapped_into(&mut v271_7_write,&((v272_13).read_zipper()),&[]);
            }
            v257_20_cursor.ascend(1);
          }
          drop(v271_7_write);
          drop(v271_6);
          compose(&(v270_5),&(v271_7))
        };
        drop(v270_5);
        let v270_9: Space = intersect(&(*CONSTANT_1),&(v270_2));
        drop(v270_2);
        let v270_10: Space = if has_head(&(v270_9)) { singleton(&[]) } else { Space::new() };
        drop(v270_9);
        let v270_11: Space = compose(&(v270_10),&v257_20_cursor);
        drop(v270_10);
        let v270_12: Space = unite(&(v270_8),&(v270_11));
        drop(v270_11);
        join_wrapped_into(&mut v269_11_write,&((v270_12).read_zipper()),&[]);
        }
        v257_20_cursor.ascend(1);
      }
      drop(v269_11_write);
      drop(v269_6);
      compose(&(v258_10),&(v269_11))
    };
    drop(v258_10);
    let v258_13: Space = unite(&(v258_8),&(v258_12));
    join_wrapped_into(&mut v257_20_write,&((v258_13).read_zipper()),&[]);
    }
    v257_20_cursor.ascend(1);
  }
  drop(v257_20_cursor);
  drop(v257_20_write);
  (v257_20).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v275_14 = Space::new();
  let mut v275_14_write = v275_14.write_zipper();
  let mut v275_14_cursor = (*s0).read_zipper();
  let v275_14_origin = v275_14_cursor.path().len();
  for v275_14_byte in v275_14_cursor.child_mask().iter() {
    v275_14_cursor.descend_to_existing_byte(v275_14_byte);
    {
    let v276_2: Space = singleton(&v275_14_cursor.path()[v275_14_origin..(v275_14_origin + 1)]);
    let v276_3: Space = intersect(&(*CONSTANT_1),&(v276_2));
    let v276_4: Space = if has_head(&(v276_3)) { singleton(&[]) } else { Space::new() };
    drop(v276_3);
    let v276_5: Space = subtract(&(*CONSTANT_0),&(v276_4));
    drop(v276_4);
    let v276_8: Space = if (&(v276_5)).is_empty() { Space::new() } else {
      let v277_6: Path = concat_path(&(*p0),&v275_14_cursor.path()[v275_14_origin..(v275_14_origin + 1)]);
      let mut v277_7 = Space::new();
      let mut v277_7_write = v277_7.write_zipper();
      for v277_7_byte in v275_14_cursor.child_mask().iter() {
        v275_14_cursor.descend_to_existing_byte(v277_7_byte);
        {
        let v278_2: Space = singleton(&v275_14_cursor.path()[(v275_14_origin + 1)..(v275_14_origin + 2)]);
        let v278_3: Space = intersect(&(*CONSTANT_1),&(v278_2));
        let v278_4: Space = if has_head(&(v278_3)) { singleton(&[]) } else { Space::new() };
        drop(v278_3);
        let v278_5: Space = subtract(&(*CONSTANT_0),&(v278_4));
        drop(v278_4);
        let v278_8: Space = if (&(v278_5)).is_empty() { Space::new() } else {
          let v279_6: Path = concat_path(&(v277_6),&v275_14_cursor.path()[(v275_14_origin + 1)..(v275_14_origin + 2)]);
          let mut v279_7 = Space::new();
          let mut v279_7_write = v279_7.write_zipper();
          for v279_7_byte in v275_14_cursor.child_mask().iter() {
            v275_14_cursor.descend_to_existing_byte(v279_7_byte);
            {
            let v280_2: Space = singleton(&v275_14_cursor.path()[(v275_14_origin + 2)..(v275_14_origin + 3)]);
            let v280_3: Space = intersect(&(*CONSTANT_1),&(v280_2));
            let v280_4: Space = if has_head(&(v280_3)) { singleton(&[]) } else { Space::new() };
            drop(v280_3);
            let v280_5: Space = subtract(&(*CONSTANT_0),&(v280_4));
            drop(v280_4);
            let v280_8: Space = if (&(v280_5)).is_empty() { Space::new() } else {
              let v281_6: Path = concat_path(&(v279_6),&v275_14_cursor.path()[(v275_14_origin + 2)..(v275_14_origin + 3)]);
              let v281_7: Space = routine_28(c, &(v281_6), &v275_14_cursor);
              compose(&(v280_5),&(v281_7))
            };
            drop(v280_5);
            let v280_9: Space = intersect(&(*CONSTANT_1),&(v280_2));
            drop(v280_2);
            let v280_10: Space = if has_head(&(v280_9)) { singleton(&[]) } else { Space::new() };
            drop(v280_9);
            let v280_12: Space = if (&(v280_10)).is_empty() { Space::new() } else {
              let v282_6: Path = concat_path(&(v279_6),&v275_14_cursor.path()[(v275_14_origin + 2)..(v275_14_origin + 3)]);
              let v282_11: Space = routine_29(c, &(v282_6), &v275_14_cursor);
              drop(v282_6);
              compose(&(v280_10),&(v282_11))
            };
            drop(v280_10);
            let v280_13: Space = unite(&(v280_8),&(v280_12));
            join_wrapped_into(&mut v279_7_write,&((v280_13).read_zipper()),&[]);
            }
            v275_14_cursor.ascend(1);
          }
          drop(v279_7_write);
          compose(&(v278_5),&(v279_7))
        };
        drop(v278_5);
        let v278_9: Space = intersect(&(*CONSTANT_1),&(v278_2));
        drop(v278_2);
        let v278_10: Space = if has_head(&(v278_9)) { singleton(&[]) } else { Space::new() };
        drop(v278_9);
        let v278_12: Space = if (&(v278_10)).is_empty() { Space::new() } else {
          let v283_6: Path = concat_path(&(v277_6),&v275_14_cursor.path()[(v275_14_origin + 1)..(v275_14_origin + 2)]);
          let mut v283_11 = Space::new();
          let mut v283_11_write = v283_11.write_zipper();
          for v283_11_byte in v275_14_cursor.child_mask().iter() {
            v275_14_cursor.descend_to_existing_byte(v283_11_byte);
            {
            let v284_2: Space = singleton(&v275_14_cursor.path()[(v275_14_origin + 2)..(v275_14_origin + 3)]);
            let v284_3: Space = intersect(&(*CONSTANT_1),&(v284_2));
            let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
            drop(v284_3);
            let v284_5: Space = subtract(&(*CONSTANT_0),&(v284_4));
            drop(v284_4);
            let v284_8: Space = if (&(v284_5)).is_empty() { Space::new() } else {
              let v285_6: Path = concat_path(&(v283_6),&v275_14_cursor.path()[(v275_14_origin + 2)..(v275_14_origin + 3)]);
              let v285_7: Space = routine_28(c, &(v285_6), &v275_14_cursor);
              compose(&(v284_5),&(v285_7))
            };
            drop(v284_5);
            let v284_9: Space = intersect(&(*CONSTANT_1),&(v284_2));
            drop(v284_2);
            let v284_10: Space = if has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
            drop(v284_9);
            let v284_12: Space = if (&(v284_10)).is_empty() { Space::new() } else {
              let v286_6: Path = concat_path(&(v283_6),&v275_14_cursor.path()[(v275_14_origin + 2)..(v275_14_origin + 3)]);
              let v286_11: Space = routine_12(c, &(v286_6), &v275_14_cursor);
              drop(v286_6);
              compose(&(v284_10),&(v286_11))
            };
            drop(v284_10);
            let v284_13: Space = unite(&(v284_8),&(v284_12));
            join_wrapped_into(&mut v283_11_write,&((v284_13).read_zipper()),&[]);
            }
            v275_14_cursor.ascend(1);
          }
          drop(v283_11_write);
          drop(v283_6);
          compose(&(v278_10),&(v283_11))
        };
        drop(v278_10);
        let v278_13: Space = unite(&(v278_8),&(v278_12));
        join_wrapped_into(&mut v277_7_write,&((v278_13).read_zipper()),&[]);
        }
        v275_14_cursor.ascend(1);
      }
      drop(v277_7_write);
      drop(v277_6);
      compose(&(v276_5),&(v277_7))
    };
    drop(v276_5);
    let v276_9: Space = intersect(&(*CONSTANT_1),&(v276_2));
    drop(v276_2);
    let v276_10: Space = if has_head(&(v276_9)) { singleton(&[]) } else { Space::new() };
    drop(v276_9);
    let v276_11: Space = compose(&(v276_10),&v275_14_cursor);
    drop(v276_10);
    let v276_12: Space = unite(&(v276_8),&(v276_11));
    drop(v276_11);
    join_wrapped_into(&mut v275_14_write,&((v276_12).read_zipper()),&[]);
    }
    v275_14_cursor.ascend(1);
  }
  drop(v275_14_cursor);
  drop(v275_14_write);
  (v275_14).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v287_20 = Space::new();
  let mut v287_20_write = v287_20.write_zipper();
  let mut v287_20_cursor = (*s0).read_zipper();
  let v287_20_origin = v287_20_cursor.path().len();
  for v287_20_byte in v287_20_cursor.child_mask().iter() {
    v287_20_cursor.descend_to_existing_byte(v287_20_byte);
    {
    let v288_2: Space = singleton(&v287_20_cursor.path()[v287_20_origin..(v287_20_origin + 1)]);
    let v288_3: Space = intersect(&(*CONSTANT_1),&(v288_2));
    let v288_4: Space = if has_head(&(v288_3)) { singleton(&[]) } else { Space::new() };
    drop(v288_3);
    let v288_5: Space = subtract(&(*CONSTANT_0),&(v288_4));
    drop(v288_4);
    let v288_8: Space = if (&(v288_5)).is_empty() { Space::new() } else {
      let v289_6: Path = concat_path(&(*p0),&v287_20_cursor.path()[v287_20_origin..(v287_20_origin + 1)]);
      let mut v289_7 = Space::new();
      let mut v289_7_write = v289_7.write_zipper();
      for v289_7_byte in v287_20_cursor.child_mask().iter() {
        v287_20_cursor.descend_to_existing_byte(v289_7_byte);
        {
        let v290_2: Space = singleton(&v287_20_cursor.path()[(v287_20_origin + 1)..(v287_20_origin + 2)]);
        let v290_3: Space = intersect(&(*CONSTANT_1),&(v290_2));
        let v290_4: Space = if has_head(&(v290_3)) { singleton(&[]) } else { Space::new() };
        drop(v290_3);
        let v290_5: Space = subtract(&(*CONSTANT_0),&(v290_4));
        drop(v290_4);
        let v290_8: Space = if (&(v290_5)).is_empty() { Space::new() } else {
          let v291_6: Path = concat_path(&(v289_6),&v287_20_cursor.path()[(v287_20_origin + 1)..(v287_20_origin + 2)]);
          let mut v291_7 = Space::new();
          let mut v291_7_write = v291_7.write_zipper();
          for v291_7_byte in v287_20_cursor.child_mask().iter() {
            v287_20_cursor.descend_to_existing_byte(v291_7_byte);
            {
            let v292_2: Space = singleton(&v287_20_cursor.path()[(v287_20_origin + 2)..(v287_20_origin + 3)]);
            let v292_3: Space = intersect(&(*CONSTANT_1),&(v292_2));
            let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
            drop(v292_3);
            let v292_5: Space = subtract(&(*CONSTANT_0),&(v292_4));
            drop(v292_4);
            let v292_8: Space = if (&(v292_5)).is_empty() { Space::new() } else {
              let v293_6: Path = concat_path(&(v291_6),&v287_20_cursor.path()[(v287_20_origin + 2)..(v287_20_origin + 3)]);
              let v293_7: Space = routine_30(c, &(v293_6), &v287_20_cursor);
              compose(&(v292_5),&(v293_7))
            };
            drop(v292_5);
            let v292_9: Space = intersect(&(*CONSTANT_1),&(v292_2));
            drop(v292_2);
            let v292_10: Space = if has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
            drop(v292_9);
            let v292_12: Space = if (&(v292_10)).is_empty() { Space::new() } else {
              let v294_6: Path = concat_path(&(v291_6),&v287_20_cursor.path()[(v287_20_origin + 2)..(v287_20_origin + 3)]);
              let v294_11: Space = routine_31(c, &(v294_6), &v287_20_cursor);
              drop(v294_6);
              compose(&(v292_10),&(v294_11))
            };
            drop(v292_10);
            let v292_13: Space = unite(&(v292_8),&(v292_12));
            join_wrapped_into(&mut v291_7_write,&((v292_13).read_zipper()),&[]);
            }
            v287_20_cursor.ascend(1);
          }
          drop(v291_7_write);
          compose(&(v290_5),&(v291_7))
        };
        drop(v290_5);
        let v290_9: Space = intersect(&(*CONSTANT_1),&(v290_2));
        drop(v290_2);
        let v290_10: Space = if has_head(&(v290_9)) { singleton(&[]) } else { Space::new() };
        drop(v290_9);
        let v290_12: Space = if (&(v290_10)).is_empty() { Space::new() } else {
          let v295_6: Path = concat_path(&(v289_6),&v287_20_cursor.path()[(v287_20_origin + 1)..(v287_20_origin + 2)]);
          let mut v295_11 = Space::new();
          let mut v295_11_write = v295_11.write_zipper();
          for v295_11_byte in v287_20_cursor.child_mask().iter() {
            v287_20_cursor.descend_to_existing_byte(v295_11_byte);
            {
            let v296_2: Space = singleton(&v287_20_cursor.path()[(v287_20_origin + 2)..(v287_20_origin + 3)]);
            let v296_3: Space = intersect(&(*CONSTANT_1),&(v296_2));
            let v296_4: Space = if has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
            drop(v296_3);
            let v296_5: Space = subtract(&(*CONSTANT_0),&(v296_4));
            drop(v296_4);
            let v296_8: Space = if (&(v296_5)).is_empty() { Space::new() } else {
              let v297_6: Path = concat_path(&(v295_6),&v287_20_cursor.path()[(v287_20_origin + 2)..(v287_20_origin + 3)]);
              let v297_7: Space = routine_30(c, &(v297_6), &v287_20_cursor);
              compose(&(v296_5),&(v297_7))
            };
            drop(v296_5);
            let v296_9: Space = intersect(&(*CONSTANT_1),&(v296_2));
            drop(v296_2);
            let v296_10: Space = if has_head(&(v296_9)) { singleton(&[]) } else { Space::new() };
            drop(v296_9);
            let v296_12: Space = if (&(v296_10)).is_empty() { Space::new() } else {
              let v298_6: Path = concat_path(&(v295_6),&v287_20_cursor.path()[(v287_20_origin + 2)..(v287_20_origin + 3)]);
              let v298_11: Space = routine_15(c, &(v298_6), &v287_20_cursor);
              drop(v298_6);
              compose(&(v296_10),&(v298_11))
            };
            drop(v296_10);
            let v296_13: Space = unite(&(v296_8),&(v296_12));
            join_wrapped_into(&mut v295_11_write,&((v296_13).read_zipper()),&[]);
            }
            v287_20_cursor.ascend(1);
          }
          drop(v295_11_write);
          drop(v295_6);
          compose(&(v290_10),&(v295_11))
        };
        drop(v290_10);
        let v290_13: Space = unite(&(v290_8),&(v290_12));
        join_wrapped_into(&mut v289_7_write,&((v290_13).read_zipper()),&[]);
        }
        v287_20_cursor.ascend(1);
      }
      drop(v289_7_write);
      compose(&(v288_5),&(v289_7))
    };
    drop(v288_5);
    let v288_9: Space = intersect(&(*CONSTANT_1),&(v288_2));
    drop(v288_2);
    let v288_10: Space = if has_head(&(v288_9)) { singleton(&[]) } else { Space::new() };
    drop(v288_9);
    let v288_12: Space = if (&(v288_10)).is_empty() { Space::new() } else {
      let v299_6: Path = concat_path(&(*p0),&v287_20_cursor.path()[v287_20_origin..(v287_20_origin + 1)]);
      let mut v299_11 = Space::new();
      let mut v299_11_write = v299_11.write_zipper();
      for v299_11_byte in v287_20_cursor.child_mask().iter() {
        v287_20_cursor.descend_to_existing_byte(v299_11_byte);
        {
        let v300_2: Space = singleton(&v287_20_cursor.path()[(v287_20_origin + 1)..(v287_20_origin + 2)]);
        let v300_3: Space = intersect(&(*CONSTANT_1),&(v300_2));
        let v300_4: Space = if has_head(&(v300_3)) { singleton(&[]) } else { Space::new() };
        drop(v300_3);
        let v300_5: Space = subtract(&(*CONSTANT_0),&(v300_4));
        drop(v300_4);
        let v300_8: Space = if (&(v300_5)).is_empty() { Space::new() } else {
          let v301_6: Path = concat_path(&(v299_6),&v287_20_cursor.path()[(v287_20_origin + 1)..(v287_20_origin + 2)]);
          let mut v301_7 = Space::new();
          let mut v301_7_write = v301_7.write_zipper();
          for v301_7_byte in v287_20_cursor.child_mask().iter() {
            v287_20_cursor.descend_to_existing_byte(v301_7_byte);
            {
            let v302_2: Space = singleton(&v287_20_cursor.path()[(v287_20_origin + 2)..(v287_20_origin + 3)]);
            let v302_3: Space = intersect(&(*CONSTANT_1),&(v302_2));
            let v302_4: Space = if has_head(&(v302_3)) { singleton(&[]) } else { Space::new() };
            drop(v302_3);
            let v302_5: Space = subtract(&(*CONSTANT_0),&(v302_4));
            drop(v302_4);
            let v302_8: Space = if (&(v302_5)).is_empty() { Space::new() } else {
              let v303_6: Path = concat_path(&(v301_6),&v287_20_cursor.path()[(v287_20_origin + 2)..(v287_20_origin + 3)]);
              let v303_7: Space = routine_30(c, &(v303_6), &v287_20_cursor);
              compose(&(v302_5),&(v303_7))
            };
            drop(v302_5);
            let v302_9: Space = intersect(&(*CONSTANT_1),&(v302_2));
            drop(v302_2);
            let v302_10: Space = if has_head(&(v302_9)) { singleton(&[]) } else { Space::new() };
            drop(v302_9);
            let v302_12: Space = if (&(v302_10)).is_empty() { Space::new() } else {
              let v304_6: Path = concat_path(&(v301_6),&v287_20_cursor.path()[(v287_20_origin + 2)..(v287_20_origin + 3)]);
              let v304_11: Space = routine_31(c, &(v304_6), &v287_20_cursor);
              drop(v304_6);
              compose(&(v302_10),&(v304_11))
            };
            drop(v302_10);
            let v302_13: Space = unite(&(v302_8),&(v302_12));
            join_wrapped_into(&mut v301_7_write,&((v302_13).read_zipper()),&[]);
            }
            v287_20_cursor.ascend(1);
          }
          drop(v301_7_write);
          drop(v301_6);
          compose(&(v300_5),&(v301_7))
        };
        drop(v300_5);
        let v300_9: Space = intersect(&(*CONSTANT_1),&(v300_2));
        drop(v300_2);
        let v300_10: Space = if has_head(&(v300_9)) { singleton(&[]) } else { Space::new() };
        drop(v300_9);
        let v300_11: Space = compose(&(v300_10),&v287_20_cursor);
        drop(v300_10);
        let v300_12: Space = unite(&(v300_8),&(v300_11));
        drop(v300_11);
        join_wrapped_into(&mut v299_11_write,&((v300_12).read_zipper()),&[]);
        }
        v287_20_cursor.ascend(1);
      }
      drop(v299_11_write);
      drop(v299_6);
      compose(&(v288_10),&(v299_11))
    };
    drop(v288_10);
    let v288_13: Space = unite(&(v288_8),&(v288_12));
    join_wrapped_into(&mut v287_20_write,&((v288_13).read_zipper()),&[]);
    }
    v287_20_cursor.ascend(1);
  }
  drop(v287_20_cursor);
  drop(v287_20_write);
  (v287_20).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v305_14 = Space::new();
  let mut v305_14_write = v305_14.write_zipper();
  let mut v305_14_cursor = (*s0).read_zipper();
  let v305_14_origin = v305_14_cursor.path().len();
  for v305_14_byte in v305_14_cursor.child_mask().iter() {
    v305_14_cursor.descend_to_existing_byte(v305_14_byte);
    {
    let v306_2: Space = singleton(&v305_14_cursor.path()[v305_14_origin..(v305_14_origin + 1)]);
    let v306_3: Space = intersect(&(*CONSTANT_1),&(v306_2));
    let v306_4: Space = if has_head(&(v306_3)) { singleton(&[]) } else { Space::new() };
    drop(v306_3);
    let v306_5: Space = subtract(&(*CONSTANT_0),&(v306_4));
    drop(v306_4);
    let v306_8: Space = if (&(v306_5)).is_empty() { Space::new() } else {
      let v307_6: Path = concat_path(&(*p0),&v305_14_cursor.path()[v305_14_origin..(v305_14_origin + 1)]);
      let mut v307_7 = Space::new();
      let mut v307_7_write = v307_7.write_zipper();
      for v307_7_byte in v305_14_cursor.child_mask().iter() {
        v305_14_cursor.descend_to_existing_byte(v307_7_byte);
        {
        let v308_2: Space = singleton(&v305_14_cursor.path()[(v305_14_origin + 1)..(v305_14_origin + 2)]);
        let v308_3: Space = intersect(&(*CONSTANT_1),&(v308_2));
        let v308_4: Space = if has_head(&(v308_3)) { singleton(&[]) } else { Space::new() };
        drop(v308_3);
        let v308_5: Space = subtract(&(*CONSTANT_0),&(v308_4));
        drop(v308_4);
        let v308_8: Space = if (&(v308_5)).is_empty() { Space::new() } else {
          let v309_6: Path = concat_path(&(v307_6),&v305_14_cursor.path()[(v305_14_origin + 1)..(v305_14_origin + 2)]);
          let mut v309_7 = Space::new();
          let mut v309_7_write = v309_7.write_zipper();
          for v309_7_byte in v305_14_cursor.child_mask().iter() {
            v305_14_cursor.descend_to_existing_byte(v309_7_byte);
            {
            let v310_2: Space = singleton(&v305_14_cursor.path()[(v305_14_origin + 2)..(v305_14_origin + 3)]);
            let v310_3: Space = intersect(&(*CONSTANT_1),&(v310_2));
            let v310_4: Space = if has_head(&(v310_3)) { singleton(&[]) } else { Space::new() };
            drop(v310_3);
            let v310_5: Space = subtract(&(*CONSTANT_0),&(v310_4));
            drop(v310_4);
            let v310_8: Space = if (&(v310_5)).is_empty() { Space::new() } else {
              let v311_6: Path = concat_path(&(v309_6),&v305_14_cursor.path()[(v305_14_origin + 2)..(v305_14_origin + 3)]);
              let v311_7: Space = routine_30(c, &(v311_6), &v305_14_cursor);
              compose(&(v310_5),&(v311_7))
            };
            drop(v310_5);
            let v310_9: Space = intersect(&(*CONSTANT_1),&(v310_2));
            drop(v310_2);
            let v310_10: Space = if has_head(&(v310_9)) { singleton(&[]) } else { Space::new() };
            drop(v310_9);
            let v310_12: Space = if (&(v310_10)).is_empty() { Space::new() } else {
              let v312_6: Path = concat_path(&(v309_6),&v305_14_cursor.path()[(v305_14_origin + 2)..(v305_14_origin + 3)]);
              let v312_11: Space = routine_31(c, &(v312_6), &v305_14_cursor);
              drop(v312_6);
              compose(&(v310_10),&(v312_11))
            };
            drop(v310_10);
            let v310_13: Space = unite(&(v310_8),&(v310_12));
            join_wrapped_into(&mut v309_7_write,&((v310_13).read_zipper()),&[]);
            }
            v305_14_cursor.ascend(1);
          }
          drop(v309_7_write);
          compose(&(v308_5),&(v309_7))
        };
        drop(v308_5);
        let v308_9: Space = intersect(&(*CONSTANT_1),&(v308_2));
        drop(v308_2);
        let v308_10: Space = if has_head(&(v308_9)) { singleton(&[]) } else { Space::new() };
        drop(v308_9);
        let v308_12: Space = if (&(v308_10)).is_empty() { Space::new() } else {
          let v313_6: Path = concat_path(&(v307_6),&v305_14_cursor.path()[(v305_14_origin + 1)..(v305_14_origin + 2)]);
          let mut v313_11 = Space::new();
          let mut v313_11_write = v313_11.write_zipper();
          for v313_11_byte in v305_14_cursor.child_mask().iter() {
            v305_14_cursor.descend_to_existing_byte(v313_11_byte);
            {
            let v314_2: Space = singleton(&v305_14_cursor.path()[(v305_14_origin + 2)..(v305_14_origin + 3)]);
            let v314_3: Space = intersect(&(*CONSTANT_1),&(v314_2));
            let v314_4: Space = if has_head(&(v314_3)) { singleton(&[]) } else { Space::new() };
            drop(v314_3);
            let v314_5: Space = subtract(&(*CONSTANT_0),&(v314_4));
            drop(v314_4);
            let v314_8: Space = if (&(v314_5)).is_empty() { Space::new() } else {
              let v315_6: Path = concat_path(&(v313_6),&v305_14_cursor.path()[(v305_14_origin + 2)..(v305_14_origin + 3)]);
              let v315_7: Space = routine_30(c, &(v315_6), &v305_14_cursor);
              compose(&(v314_5),&(v315_7))
            };
            drop(v314_5);
            let v314_9: Space = intersect(&(*CONSTANT_1),&(v314_2));
            drop(v314_2);
            let v314_10: Space = if has_head(&(v314_9)) { singleton(&[]) } else { Space::new() };
            drop(v314_9);
            let v314_12: Space = if (&(v314_10)).is_empty() { Space::new() } else {
              let v316_6: Path = concat_path(&(v313_6),&v305_14_cursor.path()[(v305_14_origin + 2)..(v305_14_origin + 3)]);
              let v316_11: Space = routine_15(c, &(v316_6), &v305_14_cursor);
              drop(v316_6);
              compose(&(v314_10),&(v316_11))
            };
            drop(v314_10);
            let v314_13: Space = unite(&(v314_8),&(v314_12));
            join_wrapped_into(&mut v313_11_write,&((v314_13).read_zipper()),&[]);
            }
            v305_14_cursor.ascend(1);
          }
          drop(v313_11_write);
          drop(v313_6);
          compose(&(v308_10),&(v313_11))
        };
        drop(v308_10);
        let v308_13: Space = unite(&(v308_8),&(v308_12));
        join_wrapped_into(&mut v307_7_write,&((v308_13).read_zipper()),&[]);
        }
        v305_14_cursor.ascend(1);
      }
      drop(v307_7_write);
      drop(v307_6);
      compose(&(v306_5),&(v307_7))
    };
    drop(v306_5);
    let v306_9: Space = intersect(&(*CONSTANT_1),&(v306_2));
    drop(v306_2);
    let v306_10: Space = if has_head(&(v306_9)) { singleton(&[]) } else { Space::new() };
    drop(v306_9);
    let v306_11: Space = compose(&(v306_10),&v305_14_cursor);
    drop(v306_10);
    let v306_12: Space = unite(&(v306_8),&(v306_11));
    drop(v306_11);
    join_wrapped_into(&mut v305_14_write,&((v306_12).read_zipper()),&[]);
    }
    v305_14_cursor.ascend(1);
  }
  drop(v305_14_cursor);
  drop(v305_14_write);
  (v305_14).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v317_8 = Space::new();
  let mut v317_8_write = v317_8.write_zipper();
  let mut v317_8_cursor = (*s0).read_zipper();
  let v317_8_origin = v317_8_cursor.path().len();
  for v317_8_byte in v317_8_cursor.child_mask().iter() {
    v317_8_cursor.descend_to_existing_byte(v317_8_byte);
    {
    let v318_2: Space = singleton(&v317_8_cursor.path()[v317_8_origin..(v317_8_origin + 1)]);
    let v318_3: Space = intersect(&(*CONSTANT_1),&(v318_2));
    let v318_4: Space = if has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
    drop(v318_3);
    let v318_5: Space = subtract(&(*CONSTANT_0),&(v318_4));
    drop(v318_4);
    let v318_8: Space = if (&(v318_5)).is_empty() { Space::new() } else {
      let v319_6: Path = concat_path(&(*p0),&v317_8_cursor.path()[v317_8_origin..(v317_8_origin + 1)]);
      let mut v319_7 = Space::new();
      let mut v319_7_write = v319_7.write_zipper();
      for v319_7_byte in v317_8_cursor.child_mask().iter() {
        v317_8_cursor.descend_to_existing_byte(v319_7_byte);
        {
        let v320_2: Space = singleton(&v317_8_cursor.path()[(v317_8_origin + 1)..(v317_8_origin + 2)]);
        let v320_3: Space = intersect(&(*CONSTANT_1),&(v320_2));
        drop(v320_2);
        let v320_4: Space = if has_head(&(v320_3)) { singleton(&[]) } else { Space::new() };
        drop(v320_3);
        let v320_7: Space = if (&(v320_4)).is_empty() { Space::new() } else {
          let v321_5: Path = concat_path(&(v319_6),&v317_8_cursor.path()[(v317_8_origin + 1)..(v317_8_origin + 2)]);
          let mut v321_6 = Space::new();
          let mut v321_6_write = v321_6.write_zipper();
          for v321_6_byte in v317_8_cursor.child_mask().iter() {
            v317_8_cursor.descend_to_existing_byte(v321_6_byte);
            {
            let v322_2: Space = singleton(&v317_8_cursor.path()[(v317_8_origin + 2)..(v317_8_origin + 3)]);
            let v322_3: Space = intersect(&(*CONSTANT_1),&(v322_2));
            drop(v322_2);
            let v322_4: Space = if has_head(&(v322_3)) { singleton(&[]) } else { Space::new() };
            drop(v322_3);
            let v322_7: Space = if (&(v322_4)).is_empty() { Space::new() } else {
              let v323_5: Path = concat_path(&(v321_5),&v317_8_cursor.path()[(v317_8_origin + 2)..(v317_8_origin + 3)]);
              let v323_6: Space = routine_12(c, &(v323_5), &v317_8_cursor);
              drop(v323_5);
              compose(&(v322_4),&(v323_6))
            };
            drop(v322_4);
            join_wrapped_into(&mut v321_6_write,&((v322_7).read_zipper()),&[]);
            }
            v317_8_cursor.ascend(1);
          }
          drop(v321_6_write);
          drop(v321_5);
          compose(&(v320_4),&(v321_6))
        };
        drop(v320_4);
        join_wrapped_into(&mut v319_7_write,&((v320_7).read_zipper()),&[]);
        }
        v317_8_cursor.ascend(1);
      }
      drop(v319_7_write);
      drop(v319_6);
      compose(&(v318_5),&(v319_7))
    };
    drop(v318_5);
    let v318_9: Space = intersect(&(*CONSTANT_1),&(v318_2));
    drop(v318_2);
    let v318_10: Space = if has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
    drop(v318_9);
    let v318_12: Space = if (&(v318_10)).is_empty() { Space::new() } else {
      let mut v324_11 = Space::new();
      let mut v324_11_write = v324_11.write_zipper();
      for v324_11_byte in v317_8_cursor.child_mask().iter() {
        v317_8_cursor.descend_to_existing_byte(v324_11_byte);
        {
        let v325_2: Space = singleton(&v317_8_cursor.path()[(v317_8_origin + 1)..(v317_8_origin + 2)]);
        let v325_3: Space = intersect(&(*CONSTANT_1),&(v325_2));
        drop(v325_2);
        let v325_4: Space = if has_head(&(v325_3)) { singleton(&[]) } else { Space::new() };
        drop(v325_3);
        let v325_5: Space = compose(&(v325_4),&v317_8_cursor);
        drop(v325_4);
        join_wrapped_into(&mut v324_11_write,&((v325_5).read_zipper()),&[]);
        }
        v317_8_cursor.ascend(1);
      }
      drop(v324_11_write);
      compose(&(v318_10),&(v324_11))
    };
    drop(v318_10);
    let v318_13: Space = unite(&(v318_8),&(v318_12));
    drop(v318_12);
    join_wrapped_into(&mut v317_8_write,&((v318_13).read_zipper()),&[]);
    }
    v317_8_cursor.ascend(1);
  }
  drop(v317_8_cursor);
  drop(v317_8_write);
  (v317_8).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v326_7 = Space::new();
  let mut v326_7_write = v326_7.write_zipper();
  let mut v326_7_cursor = (*s0).read_zipper();
  let v326_7_origin = v326_7_cursor.path().len();
  for v326_7_byte in v326_7_cursor.child_mask().iter() {
    v326_7_cursor.descend_to_existing_byte(v326_7_byte);
    {
    let v327_2: Space = singleton(&v326_7_cursor.path()[v326_7_origin..(v326_7_origin + 1)]);
    let v327_3: Space = intersect(&(*CONSTANT_1),&(v327_2));
    let v327_4: Space = if has_head(&(v327_3)) { singleton(&[]) } else { Space::new() };
    drop(v327_3);
    let v327_5: Space = subtract(&(*CONSTANT_0),&(v327_4));
    drop(v327_4);
    let v327_8: Space = if (&(v327_5)).is_empty() { Space::new() } else {
      let v328_6: Path = concat_path(&(*p0),&v326_7_cursor.path()[v326_7_origin..(v326_7_origin + 1)]);
      let mut v328_7 = Space::new();
      let mut v328_7_write = v328_7.write_zipper();
      for v328_7_byte in v326_7_cursor.child_mask().iter() {
        v326_7_cursor.descend_to_existing_byte(v328_7_byte);
        {
        let v329_2: Space = singleton(&v326_7_cursor.path()[(v326_7_origin + 1)..(v326_7_origin + 2)]);
        let v329_3: Space = intersect(&(*CONSTANT_1),&(v329_2));
        drop(v329_2);
        let v329_4: Space = if has_head(&(v329_3)) { singleton(&[]) } else { Space::new() };
        drop(v329_3);
        let v329_7: Space = if (&(v329_4)).is_empty() { Space::new() } else {
          let v330_5: Path = concat_path(&(v328_6),&v326_7_cursor.path()[(v326_7_origin + 1)..(v326_7_origin + 2)]);
          let mut v330_6 = Space::new();
          let mut v330_6_write = v330_6.write_zipper();
          for v330_6_byte in v326_7_cursor.child_mask().iter() {
            v326_7_cursor.descend_to_existing_byte(v330_6_byte);
            {
            let v331_2: Space = singleton(&v326_7_cursor.path()[(v326_7_origin + 2)..(v326_7_origin + 3)]);
            let v331_3: Space = intersect(&(*CONSTANT_1),&(v331_2));
            drop(v331_2);
            let v331_4: Space = if has_head(&(v331_3)) { singleton(&[]) } else { Space::new() };
            drop(v331_3);
            let v331_7: Space = if (&(v331_4)).is_empty() { Space::new() } else {
              let v332_5: Path = concat_path(&(v330_5),&v326_7_cursor.path()[(v326_7_origin + 2)..(v326_7_origin + 3)]);
              let v332_6: Space = routine_12(c, &(v332_5), &v326_7_cursor);
              drop(v332_5);
              compose(&(v331_4),&(v332_6))
            };
            drop(v331_4);
            join_wrapped_into(&mut v330_6_write,&((v331_7).read_zipper()),&[]);
            }
            v326_7_cursor.ascend(1);
          }
          drop(v330_6_write);
          drop(v330_5);
          compose(&(v329_4),&(v330_6))
        };
        drop(v329_4);
        join_wrapped_into(&mut v328_7_write,&((v329_7).read_zipper()),&[]);
        }
        v326_7_cursor.ascend(1);
      }
      drop(v328_7_write);
      drop(v328_6);
      compose(&(v327_5),&(v328_7))
    };
    drop(v327_5);
    let v327_9: Space = intersect(&(*CONSTANT_1),&(v327_2));
    drop(v327_2);
    let v327_10: Space = if has_head(&(v327_9)) { singleton(&[]) } else { Space::new() };
    drop(v327_9);
    let v327_11: Space = compose(&(v327_10),&v326_7_cursor);
    drop(v327_10);
    let v327_12: Space = unite(&(v327_8),&(v327_11));
    drop(v327_11);
    join_wrapped_into(&mut v326_7_write,&((v327_12).read_zipper()),&[]);
    }
    v326_7_cursor.ascend(1);
  }
  drop(v326_7_cursor);
  drop(v326_7_write);
  (v326_7).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v333_8 = Space::new();
  let mut v333_8_write = v333_8.write_zipper();
  let mut v333_8_cursor = (*s0).read_zipper();
  let v333_8_origin = v333_8_cursor.path().len();
  for v333_8_byte in v333_8_cursor.child_mask().iter() {
    v333_8_cursor.descend_to_existing_byte(v333_8_byte);
    {
    let v334_2: Space = singleton(&v333_8_cursor.path()[v333_8_origin..(v333_8_origin + 1)]);
    let v334_3: Space = intersect(&(*CONSTANT_1),&(v334_2));
    let v334_4: Space = if has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
    drop(v334_3);
    let v334_5: Space = subtract(&(*CONSTANT_0),&(v334_4));
    drop(v334_4);
    let v334_8: Space = if (&(v334_5)).is_empty() { Space::new() } else {
      let v335_6: Path = concat_path(&(*p0),&v333_8_cursor.path()[v333_8_origin..(v333_8_origin + 1)]);
      let mut v335_7 = Space::new();
      let mut v335_7_write = v335_7.write_zipper();
      for v335_7_byte in v333_8_cursor.child_mask().iter() {
        v333_8_cursor.descend_to_existing_byte(v335_7_byte);
        {
        let v336_2: Space = singleton(&v333_8_cursor.path()[(v333_8_origin + 1)..(v333_8_origin + 2)]);
        let v336_3: Space = intersect(&(*CONSTANT_1),&(v336_2));
        drop(v336_2);
        let v336_4: Space = if has_head(&(v336_3)) { singleton(&[]) } else { Space::new() };
        drop(v336_3);
        let v336_7: Space = if (&(v336_4)).is_empty() { Space::new() } else {
          let v337_5: Path = concat_path(&(v335_6),&v333_8_cursor.path()[(v333_8_origin + 1)..(v333_8_origin + 2)]);
          let mut v337_6 = Space::new();
          let mut v337_6_write = v337_6.write_zipper();
          for v337_6_byte in v333_8_cursor.child_mask().iter() {
            v333_8_cursor.descend_to_existing_byte(v337_6_byte);
            {
            let v338_2: Space = singleton(&v333_8_cursor.path()[(v333_8_origin + 2)..(v333_8_origin + 3)]);
            let v338_3: Space = intersect(&(*CONSTANT_1),&(v338_2));
            drop(v338_2);
            let v338_4: Space = if has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
            drop(v338_3);
            let v338_7: Space = if (&(v338_4)).is_empty() { Space::new() } else {
              let v339_5: Path = concat_path(&(v337_5),&v333_8_cursor.path()[(v333_8_origin + 2)..(v333_8_origin + 3)]);
              let v339_6: Space = routine_15(c, &(v339_5), &v333_8_cursor);
              drop(v339_5);
              compose(&(v338_4),&(v339_6))
            };
            drop(v338_4);
            join_wrapped_into(&mut v337_6_write,&((v338_7).read_zipper()),&[]);
            }
            v333_8_cursor.ascend(1);
          }
          drop(v337_6_write);
          drop(v337_5);
          compose(&(v336_4),&(v337_6))
        };
        drop(v336_4);
        join_wrapped_into(&mut v335_7_write,&((v336_7).read_zipper()),&[]);
        }
        v333_8_cursor.ascend(1);
      }
      drop(v335_7_write);
      drop(v335_6);
      compose(&(v334_5),&(v335_7))
    };
    drop(v334_5);
    let v334_9: Space = intersect(&(*CONSTANT_1),&(v334_2));
    drop(v334_2);
    let v334_10: Space = if has_head(&(v334_9)) { singleton(&[]) } else { Space::new() };
    drop(v334_9);
    let v334_12: Space = if (&(v334_10)).is_empty() { Space::new() } else {
      let mut v340_11 = Space::new();
      let mut v340_11_write = v340_11.write_zipper();
      for v340_11_byte in v333_8_cursor.child_mask().iter() {
        v333_8_cursor.descend_to_existing_byte(v340_11_byte);
        {
        let v341_2: Space = singleton(&v333_8_cursor.path()[(v333_8_origin + 1)..(v333_8_origin + 2)]);
        let v341_3: Space = intersect(&(*CONSTANT_1),&(v341_2));
        drop(v341_2);
        let v341_4: Space = if has_head(&(v341_3)) { singleton(&[]) } else { Space::new() };
        drop(v341_3);
        let v341_5: Space = compose(&(v341_4),&v333_8_cursor);
        drop(v341_4);
        join_wrapped_into(&mut v340_11_write,&((v341_5).read_zipper()),&[]);
        }
        v333_8_cursor.ascend(1);
      }
      drop(v340_11_write);
      compose(&(v334_10),&(v340_11))
    };
    drop(v334_10);
    let v334_13: Space = unite(&(v334_8),&(v334_12));
    drop(v334_12);
    join_wrapped_into(&mut v333_8_write,&((v334_13).read_zipper()),&[]);
    }
    v333_8_cursor.ascend(1);
  }
  drop(v333_8_cursor);
  drop(v333_8_write);
  (v333_8).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v342_7 = Space::new();
  let mut v342_7_write = v342_7.write_zipper();
  let mut v342_7_cursor = (*s0).read_zipper();
  let v342_7_origin = v342_7_cursor.path().len();
  for v342_7_byte in v342_7_cursor.child_mask().iter() {
    v342_7_cursor.descend_to_existing_byte(v342_7_byte);
    {
    let v343_2: Space = singleton(&v342_7_cursor.path()[v342_7_origin..(v342_7_origin + 1)]);
    let v343_3: Space = intersect(&(*CONSTANT_1),&(v343_2));
    let v343_4: Space = if has_head(&(v343_3)) { singleton(&[]) } else { Space::new() };
    drop(v343_3);
    let v343_5: Space = subtract(&(*CONSTANT_0),&(v343_4));
    drop(v343_4);
    let v343_8: Space = if (&(v343_5)).is_empty() { Space::new() } else {
      let v344_6: Path = concat_path(&(*p0),&v342_7_cursor.path()[v342_7_origin..(v342_7_origin + 1)]);
      let mut v344_7 = Space::new();
      let mut v344_7_write = v344_7.write_zipper();
      for v344_7_byte in v342_7_cursor.child_mask().iter() {
        v342_7_cursor.descend_to_existing_byte(v344_7_byte);
        {
        let v345_2: Space = singleton(&v342_7_cursor.path()[(v342_7_origin + 1)..(v342_7_origin + 2)]);
        let v345_3: Space = intersect(&(*CONSTANT_1),&(v345_2));
        drop(v345_2);
        let v345_4: Space = if has_head(&(v345_3)) { singleton(&[]) } else { Space::new() };
        drop(v345_3);
        let v345_7: Space = if (&(v345_4)).is_empty() { Space::new() } else {
          let v346_5: Path = concat_path(&(v344_6),&v342_7_cursor.path()[(v342_7_origin + 1)..(v342_7_origin + 2)]);
          let mut v346_6 = Space::new();
          let mut v346_6_write = v346_6.write_zipper();
          for v346_6_byte in v342_7_cursor.child_mask().iter() {
            v342_7_cursor.descend_to_existing_byte(v346_6_byte);
            {
            let v347_2: Space = singleton(&v342_7_cursor.path()[(v342_7_origin + 2)..(v342_7_origin + 3)]);
            let v347_3: Space = intersect(&(*CONSTANT_1),&(v347_2));
            drop(v347_2);
            let v347_4: Space = if has_head(&(v347_3)) { singleton(&[]) } else { Space::new() };
            drop(v347_3);
            let v347_7: Space = if (&(v347_4)).is_empty() { Space::new() } else {
              let v348_5: Path = concat_path(&(v346_5),&v342_7_cursor.path()[(v342_7_origin + 2)..(v342_7_origin + 3)]);
              let v348_6: Space = routine_15(c, &(v348_5), &v342_7_cursor);
              drop(v348_5);
              compose(&(v347_4),&(v348_6))
            };
            drop(v347_4);
            join_wrapped_into(&mut v346_6_write,&((v347_7).read_zipper()),&[]);
            }
            v342_7_cursor.ascend(1);
          }
          drop(v346_6_write);
          drop(v346_5);
          compose(&(v345_4),&(v346_6))
        };
        drop(v345_4);
        join_wrapped_into(&mut v344_7_write,&((v345_7).read_zipper()),&[]);
        }
        v342_7_cursor.ascend(1);
      }
      drop(v344_7_write);
      drop(v344_6);
      compose(&(v343_5),&(v344_7))
    };
    drop(v343_5);
    let v343_9: Space = intersect(&(*CONSTANT_1),&(v343_2));
    drop(v343_2);
    let v343_10: Space = if has_head(&(v343_9)) { singleton(&[]) } else { Space::new() };
    drop(v343_9);
    let v343_11: Space = compose(&(v343_10),&v342_7_cursor);
    drop(v343_10);
    let v343_12: Space = unite(&(v343_8),&(v343_11));
    drop(v343_11);
    join_wrapped_into(&mut v342_7_write,&((v343_12).read_zipper()),&[]);
    }
    v342_7_cursor.ascend(1);
  }
  drop(v342_7_cursor);
  drop(v342_7_write);
  (v342_7).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v349_4 = Space::new();
  let mut v349_4_write = v349_4.write_zipper();
  let mut v349_4_cursor = (*s0).read_zipper();
  let v349_4_origin = v349_4_cursor.path().len();
  for v349_4_byte in v349_4_cursor.child_mask().iter() {
    v349_4_cursor.descend_to_existing_byte(v349_4_byte);
    {
    let v350_2: Space = singleton(&v349_4_cursor.path()[v349_4_origin..(v349_4_origin + 1)]);
    let v350_3: Space = intersect(&(*CONSTANT_1),&(v350_2));
    drop(v350_2);
    let v350_4: Space = if has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
    drop(v350_3);
    let v350_6: Space = if (&(v350_4)).is_empty() { Space::new() } else {
      let mut v351_5 = Space::new();
      let mut v351_5_write = v351_5.write_zipper();
      for v351_5_byte in v349_4_cursor.child_mask().iter() {
        v349_4_cursor.descend_to_existing_byte(v351_5_byte);
        {
        let v352_2: Space = singleton(&v349_4_cursor.path()[(v349_4_origin + 1)..(v349_4_origin + 2)]);
        let v352_3: Space = intersect(&(*CONSTANT_1),&(v352_2));
        drop(v352_2);
        let v352_4: Space = if has_head(&(v352_3)) { singleton(&[]) } else { Space::new() };
        drop(v352_3);
        let v352_5: Space = compose(&(v352_4),&v349_4_cursor);
        drop(v352_4);
        join_wrapped_into(&mut v351_5_write,&((v352_5).read_zipper()),&[]);
        }
        v349_4_cursor.ascend(1);
      }
      drop(v351_5_write);
      compose(&(v350_4),&(v351_5))
    };
    drop(v350_4);
    join_wrapped_into(&mut v349_4_write,&((v350_6).read_zipper()),&[]);
    }
    v349_4_cursor.ascend(1);
  }
  drop(v349_4_cursor);
  drop(v349_4_write);
  (v349_4).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v353_3 = Space::new();
  let mut v353_3_write = v353_3.write_zipper();
  let mut v353_3_cursor = (*s0).read_zipper();
  let v353_3_origin = v353_3_cursor.path().len();
  for v353_3_byte in v353_3_cursor.child_mask().iter() {
    v353_3_cursor.descend_to_existing_byte(v353_3_byte);
    {
    let v354_2: Space = singleton(&v353_3_cursor.path()[v353_3_origin..(v353_3_origin + 1)]);
    let v354_3: Space = intersect(&(*CONSTANT_1),&(v354_2));
    drop(v354_2);
    let v354_4: Space = if has_head(&(v354_3)) { singleton(&[]) } else { Space::new() };
    drop(v354_3);
    let v354_5: Space = compose(&(v354_4),&v353_3_cursor);
    drop(v354_4);
    join_wrapped_into(&mut v353_3_write,&((v354_5).read_zipper()),&[]);
    }
    v353_3_cursor.ascend(1);
  }
  drop(v353_3_cursor);
  drop(v353_3_write);
  (v353_3).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v355_4 = Space::new();
  let mut v355_4_write = v355_4.write_zipper();
  let mut v355_4_cursor = (*s0).read_zipper();
  let v355_4_origin = v355_4_cursor.path().len();
  for v355_4_byte in v355_4_cursor.child_mask().iter() {
    v355_4_cursor.descend_to_existing_byte(v355_4_byte);
    {
    let v356_2: Space = singleton(&v355_4_cursor.path()[v355_4_origin..(v355_4_origin + 1)]);
    let v356_3: Space = intersect(&(*CONSTANT_1),&(v356_2));
    drop(v356_2);
    let v356_4: Space = if has_head(&(v356_3)) { singleton(&[]) } else { Space::new() };
    drop(v356_3);
    let v356_6: Space = if (&(v356_4)).is_empty() { Space::new() } else {
      let mut v357_5 = Space::new();
      let mut v357_5_write = v357_5.write_zipper();
      for v357_5_byte in v355_4_cursor.child_mask().iter() {
        v355_4_cursor.descend_to_existing_byte(v357_5_byte);
        {
        let v358_2: Space = singleton(&v355_4_cursor.path()[(v355_4_origin + 1)..(v355_4_origin + 2)]);
        let v358_3: Space = intersect(&(*CONSTANT_1),&(v358_2));
        drop(v358_2);
        let v358_4: Space = if has_head(&(v358_3)) { singleton(&[]) } else { Space::new() };
        drop(v358_3);
        let v358_5: Space = compose(&(v358_4),&v355_4_cursor);
        drop(v358_4);
        join_wrapped_into(&mut v357_5_write,&((v358_5).read_zipper()),&[]);
        }
        v355_4_cursor.ascend(1);
      }
      drop(v357_5_write);
      compose(&(v356_4),&(v357_5))
    };
    drop(v356_4);
    join_wrapped_into(&mut v355_4_write,&((v356_6).read_zipper()),&[]);
    }
    v355_4_cursor.ascend(1);
  }
  drop(v355_4_cursor);
  drop(v355_4_write);
  (v355_4).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v359_3 = Space::new();
  let mut v359_3_write = v359_3.write_zipper();
  let mut v359_3_cursor = (*s0).read_zipper();
  let v359_3_origin = v359_3_cursor.path().len();
  for v359_3_byte in v359_3_cursor.child_mask().iter() {
    v359_3_cursor.descend_to_existing_byte(v359_3_byte);
    {
    let v360_2: Space = singleton(&v359_3_cursor.path()[v359_3_origin..(v359_3_origin + 1)]);
    let v360_3: Space = intersect(&(*CONSTANT_1),&(v360_2));
    drop(v360_2);
    let v360_4: Space = if has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
    drop(v360_3);
    let v360_5: Space = compose(&(v360_4),&v359_3_cursor);
    drop(v360_4);
    join_wrapped_into(&mut v359_3_write,&((v360_5).read_zipper()),&[]);
    }
    v359_3_cursor.ascend(1);
  }
  drop(v359_3_cursor);
  drop(v359_3_write);
  (v359_3).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v361_2: Space = Space::new();
  (v361_2).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v362_3 = Space::new();
  let mut v362_3_write = v362_3.write_zipper();
  let mut v362_3_cursor = (*s0).read_zipper();
  let v362_3_origin = v362_3_cursor.path().len();
  for v362_3_byte in v362_3_cursor.child_mask().iter() {
    v362_3_cursor.descend_to_existing_byte(v362_3_byte);
    {
    let v363_2: Space = singleton(&v362_3_cursor.path()[v362_3_origin..(v362_3_origin + 1)]);
    let v363_3: Space = intersect(&(*CONSTANT_1),&(v363_2));
    drop(v363_2);
    let v363_4: Space = if has_head(&(v363_3)) { singleton(&[]) } else { Space::new() };
    drop(v363_3);
    let v363_5: Space = compose(&(v363_4),&v362_3_cursor);
    drop(v363_4);
    join_wrapped_into(&mut v362_3_write,&((v363_5).read_zipper()),&[]);
    }
    v362_3_cursor.ascend(1);
  }
  drop(v362_3_cursor);
  drop(v362_3_write);
  (v362_3).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v364_2: Space = Space::new();
  (v364_2).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v365_3 = Space::new();
  let mut v365_3_write = v365_3.write_zipper();
  let mut v365_3_cursor = (*s0).read_zipper();
  let v365_3_origin = v365_3_cursor.path().len();
  for v365_3_byte in v365_3_cursor.child_mask().iter() {
    v365_3_cursor.descend_to_existing_byte(v365_3_byte);
    {
    let v366_2: Space = singleton(&v365_3_cursor.path()[v365_3_origin..(v365_3_origin + 1)]);
    let v366_3: Space = intersect(&(*CONSTANT_1),&(v366_2));
    drop(v366_2);
    let v366_4: Space = if has_head(&(v366_3)) { singleton(&[]) } else { Space::new() };
    drop(v366_3);
    let v366_5: Space = compose(&(v366_4),&v365_3_cursor);
    drop(v366_4);
    join_wrapped_into(&mut v365_3_write,&((v366_5).read_zipper()),&[]);
    }
    v365_3_cursor.ascend(1);
  }
  drop(v365_3_cursor);
  drop(v365_3_write);
  (v365_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0),e.space(1)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
