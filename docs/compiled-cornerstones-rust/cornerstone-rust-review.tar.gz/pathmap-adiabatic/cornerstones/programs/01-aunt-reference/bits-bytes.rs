#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1,0,1,1]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,1]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,0,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>, s1: Option<&Space>) -> Space {
  let mut v0_11 = Space::new();
  let mut v0_11_write = v0_11.write_zipper();
  let mut v0_11_cursor = (*s1.expect("unbound native input")).read_zipper();
  let v0_11_origin = v0_11_cursor.path().len();
  for v0_11_byte in v0_11_cursor.child_mask().iter() {
    v0_11_cursor.descend_to_existing_byte(v0_11_byte);
    {
    let v1_2: Space = singleton(&v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 1)]);
    let v1_3: Space = intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (&(v1_5)).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_write = v2_6.write_zipper();
      for v2_6_byte in v0_11_cursor.child_mask().iter() {
        v0_11_cursor.descend_to_existing_byte(v2_6_byte);
        {
        let v3_2: Space = singleton(&v0_11_cursor.path()[(v0_11_origin + 1)..(v0_11_origin + 2)]);
        let v3_3: Space = intersect(&(*CONSTANT_1),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_0),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (&(v3_5)).is_empty() { Space::new() } else {
          let v4_7: Space = routine_1(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_1),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (&(v3_10)).is_empty() { Space::new() } else {
          let v5_11: Space = routine_2(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        join_wrapped_into(&mut v2_6_write,&((v3_13).read_zipper()),&[]);
        }
        v0_11_cursor.ascend(1);
      }
      drop(v2_6_write);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (&(v1_9)).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_write = v6_10.write_zipper();
      for v6_10_byte in v0_11_cursor.child_mask().iter() {
        v0_11_cursor.descend_to_existing_byte(v6_10_byte);
        {
        let v7_2: Space = singleton(&v0_11_cursor.path()[(v0_11_origin + 1)..(v0_11_origin + 2)]);
        let v7_3: Space = intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (&(v7_5)).is_empty() { Space::new() } else {
          let v8_7: Space = routine_1(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (&(v7_10)).is_empty() { Space::new() } else {
          let v9_11: Space = routine_3(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        join_wrapped_into(&mut v6_10_write,&((v7_13).read_zipper()),&[]);
        }
        v0_11_cursor.ascend(1);
      }
      drop(v6_10_write);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    join_wrapped_into(&mut v0_11_write,&((v1_12).read_zipper()),&[]);
    }
    v0_11_cursor.ascend(1);
  }
  drop(v0_11_cursor);
  drop(v0_11_write);
  let v0_13: Space = wrap(&(v0_11),&(*CONSTANT_2));
  (v0_13).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v10_34 = Space::new();
  let mut v10_34_write = v10_34.write_zipper();
  let mut v10_34_cursor = (*s0).read_zipper();
  let v10_34_origin = v10_34_cursor.path().len();
  for v10_34_byte in v10_34_cursor.child_mask().iter() {
    v10_34_cursor.descend_to_existing_byte(v10_34_byte);
    {
    let v11_2: Space = singleton(&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]);
    let v11_3: Space = intersect(&(*CONSTANT_1),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (&(v11_5)).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]);
      let mut v12_7 = Space::new();
      let mut v12_7_write = v12_7.write_zipper();
      for v12_7_byte in v10_34_cursor.child_mask().iter() {
        v10_34_cursor.descend_to_existing_byte(v12_7_byte);
        {
        let v13_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
        let v13_3: Space = intersect(&(*CONSTANT_1),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_0),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (&(v13_5)).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v12_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
          let mut v14_7 = Space::new();
          let mut v14_7_write = v14_7.write_zipper();
          for v14_7_byte in v10_34_cursor.child_mask().iter() {
            v10_34_cursor.descend_to_existing_byte(v14_7_byte);
            {
            let v15_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
            let v15_3: Space = intersect(&(*CONSTANT_1),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (&(v15_5)).is_empty() { Space::new() } else {
              let v16_6: Path = concat_path(&(v14_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v16_7: Space = routine_4(c, &(v16_6), &v10_34_cursor, &(*s1));
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_1),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (&(v15_10)).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v14_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v17_11: Space = routine_5(c, &(v17_6), &v10_34_cursor, &(*s1));
              drop(v17_6);
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            join_wrapped_into(&mut v14_7_write,&((v15_13).read_zipper()),&[]);
            }
            v10_34_cursor.ascend(1);
          }
          drop(v14_7_write);
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_1),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (&(v13_10)).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v12_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
          let mut v18_11 = Space::new();
          let mut v18_11_write = v18_11.write_zipper();
          for v18_11_byte in v10_34_cursor.child_mask().iter() {
            v10_34_cursor.descend_to_existing_byte(v18_11_byte);
            {
            let v19_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
            let v19_3: Space = intersect(&(*CONSTANT_1),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
            drop(v19_4);
            let v19_8: Space = if (&(v19_5)).is_empty() { Space::new() } else {
              let v20_6: Path = concat_path(&(v18_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v20_7: Space = routine_4(c, &(v20_6), &v10_34_cursor, &(*s1));
              compose(&(v19_5),&(v20_7))
            };
            drop(v19_5);
            let v19_9: Space = intersect(&(*CONSTANT_1),&(v19_2));
            drop(v19_2);
            let v19_10: Space = if has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
            drop(v19_9);
            let v19_12: Space = if (&(v19_10)).is_empty() { Space::new() } else {
              let v21_6: Path = concat_path(&(v18_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v21_11: Space = routine_3(c, &(v21_6), &v10_34_cursor, &(*s1));
              drop(v21_6);
              compose(&(v19_10),&(v21_11))
            };
            drop(v19_10);
            let v19_13: Space = unite(&(v19_8),&(v19_12));
            join_wrapped_into(&mut v18_11_write,&((v19_13).read_zipper()),&[]);
            }
            v10_34_cursor.ascend(1);
          }
          drop(v18_11_write);
          drop(v18_6);
          compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        join_wrapped_into(&mut v12_7_write,&((v13_13).read_zipper()),&[]);
        }
        v10_34_cursor.ascend(1);
      }
      drop(v12_7_write);
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_1),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_13: Space = if (&(v11_10)).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]);
      let mut v22_12 = Space::new();
      let mut v22_12_write = v22_12.write_zipper();
      for v22_12_byte in v10_34_cursor.child_mask().iter() {
        v10_34_cursor.descend_to_existing_byte(v22_12_byte);
        {
        let v23_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
        let v23_3: Space = intersect(&(*CONSTANT_1),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_0),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (&(v23_5)).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v22_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
          let mut v24_7 = Space::new();
          let mut v24_7_write = v24_7.write_zipper();
          for v24_7_byte in v10_34_cursor.child_mask().iter() {
            v10_34_cursor.descend_to_existing_byte(v24_7_byte);
            {
            let v25_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
            let v25_3: Space = intersect(&(*CONSTANT_1),&(v25_2));
            let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
            drop(v25_3);
            let v25_5: Space = subtract(&(*CONSTANT_0),&(v25_4));
            drop(v25_4);
            let v25_8: Space = if (&(v25_5)).is_empty() { Space::new() } else {
              let v26_6: Path = concat_path(&(v24_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v26_7: Space = routine_4(c, &(v26_6), &v10_34_cursor, &(*s1));
              compose(&(v25_5),&(v26_7))
            };
            drop(v25_5);
            let v25_9: Space = intersect(&(*CONSTANT_1),&(v25_2));
            drop(v25_2);
            let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
            drop(v25_9);
            let v25_12: Space = if (&(v25_10)).is_empty() { Space::new() } else {
              let v27_6: Path = concat_path(&(v24_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v27_11: Space = routine_5(c, &(v27_6), &v10_34_cursor, &(*s1));
              drop(v27_6);
              compose(&(v25_10),&(v27_11))
            };
            drop(v25_10);
            let v25_13: Space = unite(&(v25_8),&(v25_12));
            join_wrapped_into(&mut v24_7_write,&((v25_13).read_zipper()),&[]);
            }
            v10_34_cursor.ascend(1);
          }
          drop(v24_7_write);
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_1),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_18: Space = if (&(v23_10)).is_empty() { Space::new() } else {
          let v28_12: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)])));
          let mut v28_13 = Space::new();
          let mut v28_13_write = v28_13.write_zipper();
          let mut v28_13_cursor = (v28_12).read_zipper();
          let v28_13_origin = v28_13_cursor.path().len();
          for v28_13_byte in v28_13_cursor.child_mask().iter() {
            v28_13_cursor.descend_to_existing_byte(v28_13_byte);
            {
            let v29_2: Space = singleton(&v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)]);
            let v29_3: Space = intersect(&(*CONSTANT_1),&(v29_2));
            let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
            drop(v29_3);
            let v29_5: Space = subtract(&(*CONSTANT_0),&(v29_4));
            drop(v29_4);
            let v29_7: Space = if (&(v29_5)).is_empty() { Space::new() } else {
              let v30_6: Space = routine_6(c, &v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)], &v28_13_cursor);
              compose(&(v29_5),&(v30_6))
            };
            drop(v29_5);
            let v29_8: Space = intersect(&(*CONSTANT_1),&(v29_2));
            drop(v29_2);
            let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
            drop(v29_8);
            let v29_11: Space = if (&(v29_9)).is_empty() { Space::new() } else {
              let v31_10: Space = routine_7(c, &v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)], &v28_13_cursor);
              compose(&(v29_9),&(v31_10))
            };
            drop(v29_9);
            let v29_12: Space = unite(&(v29_7),&(v29_11));
            join_wrapped_into(&mut v28_13_write,&((v29_12).read_zipper()),&[]);
            }
            v28_13_cursor.ascend(1);
          }
          drop(v28_13_cursor);
          drop(v28_13_write);
          drop(v28_12);
          let v28_14: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v28_13));
          let mut v28_15 = Space::new();
          let mut v28_15_write = v28_15.write_zipper();
          let mut v28_15_cursor = (v28_14).read_zipper();
          let v28_15_origin = v28_15_cursor.path().len();
          for v28_15_byte in v28_15_cursor.child_mask().iter() {
            v28_15_cursor.descend_to_existing_byte(v28_15_byte);
            {
            let v32_2: Space = singleton(&v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)]);
            let v32_3: Space = intersect(&(*CONSTANT_1),&(v32_2));
            let v32_4: Space = if has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
            drop(v32_3);
            let v32_5: Space = subtract(&(*CONSTANT_0),&(v32_4));
            drop(v32_4);
            let v32_7: Space = if (&(v32_5)).is_empty() { Space::new() } else {
              let v33_6: Space = routine_8(c, &v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)], &v28_15_cursor);
              compose(&(v32_5),&(v33_6))
            };
            drop(v32_5);
            let v32_8: Space = intersect(&(*CONSTANT_1),&(v32_2));
            drop(v32_2);
            let v32_9: Space = if has_head(&(v32_8)) { singleton(&[]) } else { Space::new() };
            drop(v32_8);
            let v32_11: Space = if (&(v32_9)).is_empty() { Space::new() } else {
              let v34_10: Space = routine_9(c, &v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)], &v28_15_cursor);
              compose(&(v32_9),&(v34_10))
            };
            drop(v32_9);
            let v32_12: Space = unite(&(v32_7),&(v32_11));
            join_wrapped_into(&mut v28_15_write,&((v32_12).read_zipper()),&[]);
            }
            v28_15_cursor.ascend(1);
          }
          drop(v28_15_cursor);
          drop(v28_15_write);
          let v28_16: Space = subtract(&(v28_15),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)])));
          let v28_17: Space = intersect(&(v28_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
          compose(&(v23_10),&(v28_17))
        };
        drop(v23_10);
        let v35_6: Path = concat_path(&(v22_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
        let v23_19: Space = wrap(&(v23_18),&(v35_6));
        let v23_20: Space = unite(&(v23_8),&(v23_19));
        join_wrapped_into(&mut v22_12_write,&((v23_20).read_zipper()),&[]);
        }
        v10_34_cursor.ascend(1);
      }
      drop(v22_12_write);
      drop(v22_6);
      compose(&(v11_10),&(v22_12))
    };
    drop(v11_10);
    let v11_14: Space = unite(&(v11_8),&(v11_13));
    join_wrapped_into(&mut v10_34_write,&((v11_14).read_zipper()),&[]);
    }
    v10_34_cursor.ascend(1);
  }
  drop(v10_34_cursor);
  drop(v10_34_write);
  (v10_34).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v36_40 = Space::new();
  let mut v36_40_write = v36_40.write_zipper();
  let mut v36_40_cursor = (*s0).read_zipper();
  let v36_40_origin = v36_40_cursor.path().len();
  for v36_40_byte in v36_40_cursor.child_mask().iter() {
    v36_40_cursor.descend_to_existing_byte(v36_40_byte);
    {
    let v37_2: Space = singleton(&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)]);
    let v37_3: Space = intersect(&(*CONSTANT_1),&(v37_2));
    let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
    drop(v37_3);
    let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
    drop(v37_4);
    let v37_8: Space = if (&(v37_5)).is_empty() { Space::new() } else {
      let v38_6: Path = concat_path(&(*p0),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)]);
      let mut v38_7 = Space::new();
      let mut v38_7_write = v38_7.write_zipper();
      for v38_7_byte in v36_40_cursor.child_mask().iter() {
        v36_40_cursor.descend_to_existing_byte(v38_7_byte);
        {
        let v39_2: Space = singleton(&v36_40_cursor.path()[(v36_40_origin + 1)..(v36_40_origin + 2)]);
        let v39_3: Space = intersect(&(*CONSTANT_1),&(v39_2));
        let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_8: Space = if (&(v39_5)).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v38_6),&v36_40_cursor.path()[(v36_40_origin + 1)..(v36_40_origin + 2)]);
          let mut v40_7 = Space::new();
          let mut v40_7_write = v40_7.write_zipper();
          for v40_7_byte in v36_40_cursor.child_mask().iter() {
            v36_40_cursor.descend_to_existing_byte(v40_7_byte);
            {
            let v41_2: Space = singleton(&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
            let v41_3: Space = intersect(&(*CONSTANT_1),&(v41_2));
            let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
            drop(v41_4);
            let v41_8: Space = if (&(v41_5)).is_empty() { Space::new() } else {
              let v42_6: Path = concat_path(&(v40_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v42_7: Space = routine_4(c, &(v42_6), &v36_40_cursor, &(*s1));
              compose(&(v41_5),&(v42_7))
            };
            drop(v41_5);
            let v41_9: Space = intersect(&(*CONSTANT_1),&(v41_2));
            drop(v41_2);
            let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
            drop(v41_9);
            let v41_12: Space = if (&(v41_10)).is_empty() { Space::new() } else {
              let v43_6: Path = concat_path(&(v40_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v43_11: Space = routine_5(c, &(v43_6), &v36_40_cursor, &(*s1));
              drop(v43_6);
              compose(&(v41_10),&(v43_11))
            };
            drop(v41_10);
            let v41_13: Space = unite(&(v41_8),&(v41_12));
            join_wrapped_into(&mut v40_7_write,&((v41_13).read_zipper()),&[]);
            }
            v36_40_cursor.ascend(1);
          }
          drop(v40_7_write);
          compose(&(v39_5),&(v40_7))
        };
        drop(v39_5);
        let v39_9: Space = intersect(&(*CONSTANT_1),&(v39_2));
        drop(v39_2);
        let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
        drop(v39_9);
        let v39_12: Space = if (&(v39_10)).is_empty() { Space::new() } else {
          let v44_6: Path = concat_path(&(v38_6),&v36_40_cursor.path()[(v36_40_origin + 1)..(v36_40_origin + 2)]);
          let mut v44_11 = Space::new();
          let mut v44_11_write = v44_11.write_zipper();
          for v44_11_byte in v36_40_cursor.child_mask().iter() {
            v36_40_cursor.descend_to_existing_byte(v44_11_byte);
            {
            let v45_2: Space = singleton(&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
            let v45_3: Space = intersect(&(*CONSTANT_1),&(v45_2));
            let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
            drop(v45_3);
            let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
            drop(v45_4);
            let v45_8: Space = if (&(v45_5)).is_empty() { Space::new() } else {
              let v46_6: Path = concat_path(&(v44_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v46_7: Space = routine_4(c, &(v46_6), &v36_40_cursor, &(*s1));
              compose(&(v45_5),&(v46_7))
            };
            drop(v45_5);
            let v45_9: Space = intersect(&(*CONSTANT_1),&(v45_2));
            drop(v45_2);
            let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
            drop(v45_9);
            let v45_12: Space = if (&(v45_10)).is_empty() { Space::new() } else {
              let v47_6: Path = concat_path(&(v44_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v47_11: Space = routine_3(c, &(v47_6), &v36_40_cursor, &(*s1));
              drop(v47_6);
              compose(&(v45_10),&(v47_11))
            };
            drop(v45_10);
            let v45_13: Space = unite(&(v45_8),&(v45_12));
            join_wrapped_into(&mut v44_11_write,&((v45_13).read_zipper()),&[]);
            }
            v36_40_cursor.ascend(1);
          }
          drop(v44_11_write);
          drop(v44_6);
          compose(&(v39_10),&(v44_11))
        };
        drop(v39_10);
        let v39_13: Space = unite(&(v39_8),&(v39_12));
        join_wrapped_into(&mut v38_7_write,&((v39_13).read_zipper()),&[]);
        }
        v36_40_cursor.ascend(1);
      }
      drop(v38_7_write);
      compose(&(v37_5),&(v38_7))
    };
    drop(v37_5);
    let v37_9: Space = intersect(&(*CONSTANT_1),&(v37_2));
    drop(v37_2);
    let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
    drop(v37_9);
    let v37_18: Space = if (&(v37_10)).is_empty() { Space::new() } else {
      let v48_12: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)])));
      let mut v48_13 = Space::new();
      let mut v48_13_write = v48_13.write_zipper();
      let mut v48_13_cursor = (v48_12).read_zipper();
      let v48_13_origin = v48_13_cursor.path().len();
      for v48_13_byte in v48_13_cursor.child_mask().iter() {
        v48_13_cursor.descend_to_existing_byte(v48_13_byte);
        {
        let v49_2: Space = singleton(&v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 1)]);
        let v49_3: Space = intersect(&(*CONSTANT_1),&(v49_2));
        let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
        drop(v49_3);
        let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
        drop(v49_4);
        let v49_7: Space = if (&(v49_5)).is_empty() { Space::new() } else {
          let mut v50_6 = Space::new();
          let mut v50_6_write = v50_6.write_zipper();
          for v50_6_byte in v48_13_cursor.child_mask().iter() {
            v48_13_cursor.descend_to_existing_byte(v50_6_byte);
            {
            let v51_2: Space = singleton(&v48_13_cursor.path()[(v48_13_origin + 1)..(v48_13_origin + 2)]);
            let v51_3: Space = intersect(&(*CONSTANT_1),&(v51_2));
            let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
            drop(v51_3);
            let v51_5: Space = subtract(&(*CONSTANT_0),&(v51_4));
            drop(v51_4);
            let v51_8: Space = if (&(v51_5)).is_empty() { Space::new() } else {
              let v52_7: Space = routine_10(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v51_5),&(v52_7))
            };
            drop(v51_5);
            let v51_9: Space = intersect(&(*CONSTANT_1),&(v51_2));
            drop(v51_2);
            let v51_10: Space = if has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
            drop(v51_9);
            let v51_12: Space = if (&(v51_10)).is_empty() { Space::new() } else {
              let v53_11: Space = routine_11(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v51_10),&(v53_11))
            };
            drop(v51_10);
            let v51_13: Space = unite(&(v51_8),&(v51_12));
            join_wrapped_into(&mut v50_6_write,&((v51_13).read_zipper()),&[]);
            }
            v48_13_cursor.ascend(1);
          }
          drop(v50_6_write);
          compose(&(v49_5),&(v50_6))
        };
        drop(v49_5);
        let v49_8: Space = intersect(&(*CONSTANT_1),&(v49_2));
        drop(v49_2);
        let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
        drop(v49_8);
        let v49_11: Space = if (&(v49_9)).is_empty() { Space::new() } else {
          let mut v54_10 = Space::new();
          let mut v54_10_write = v54_10.write_zipper();
          for v54_10_byte in v48_13_cursor.child_mask().iter() {
            v48_13_cursor.descend_to_existing_byte(v54_10_byte);
            {
            let v55_2: Space = singleton(&v48_13_cursor.path()[(v48_13_origin + 1)..(v48_13_origin + 2)]);
            let v55_3: Space = intersect(&(*CONSTANT_1),&(v55_2));
            let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
            drop(v55_3);
            let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
            drop(v55_4);
            let v55_8: Space = if (&(v55_5)).is_empty() { Space::new() } else {
              let v56_7: Space = routine_10(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v55_5),&(v56_7))
            };
            drop(v55_5);
            let v55_9: Space = intersect(&(*CONSTANT_1),&(v55_2));
            drop(v55_2);
            let v55_10: Space = if has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
            drop(v55_9);
            let v55_12: Space = if (&(v55_10)).is_empty() { Space::new() } else {
              let v57_11: Space = routine_12(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v55_10),&(v57_11))
            };
            drop(v55_10);
            let v55_13: Space = unite(&(v55_8),&(v55_12));
            join_wrapped_into(&mut v54_10_write,&((v55_13).read_zipper()),&[]);
            }
            v48_13_cursor.ascend(1);
          }
          drop(v54_10_write);
          compose(&(v49_9),&(v54_10))
        };
        drop(v49_9);
        let v49_12: Space = unite(&(v49_7),&(v49_11));
        join_wrapped_into(&mut v48_13_write,&((v49_12).read_zipper()),&[]);
        }
        v48_13_cursor.ascend(1);
      }
      drop(v48_13_cursor);
      drop(v48_13_write);
      drop(v48_12);
      let v48_14: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v48_13));
      let mut v48_15 = Space::new();
      let mut v48_15_write = v48_15.write_zipper();
      let mut v48_15_cursor = (v48_14).read_zipper();
      let v48_15_origin = v48_15_cursor.path().len();
      for v48_15_byte in v48_15_cursor.child_mask().iter() {
        v48_15_cursor.descend_to_existing_byte(v48_15_byte);
        {
        let v58_2: Space = singleton(&v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 1)]);
        let v58_3: Space = intersect(&(*CONSTANT_1),&(v58_2));
        let v58_4: Space = if has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
        drop(v58_3);
        let v58_5: Space = subtract(&(*CONSTANT_0),&(v58_4));
        drop(v58_4);
        let v58_7: Space = if (&(v58_5)).is_empty() { Space::new() } else {
          let mut v59_6 = Space::new();
          let mut v59_6_write = v59_6.write_zipper();
          for v59_6_byte in v48_15_cursor.child_mask().iter() {
            v48_15_cursor.descend_to_existing_byte(v59_6_byte);
            {
            let v60_2: Space = singleton(&v48_15_cursor.path()[(v48_15_origin + 1)..(v48_15_origin + 2)]);
            let v60_3: Space = intersect(&(*CONSTANT_1),&(v60_2));
            let v60_4: Space = if has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
            drop(v60_3);
            let v60_5: Space = subtract(&(*CONSTANT_0),&(v60_4));
            drop(v60_4);
            let v60_8: Space = if (&(v60_5)).is_empty() { Space::new() } else {
              let v61_7: Space = routine_13(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v60_5),&(v61_7))
            };
            drop(v60_5);
            let v60_9: Space = intersect(&(*CONSTANT_1),&(v60_2));
            drop(v60_2);
            let v60_10: Space = if has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
            drop(v60_9);
            let v60_12: Space = if (&(v60_10)).is_empty() { Space::new() } else {
              let v62_11: Space = routine_14(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v60_10),&(v62_11))
            };
            drop(v60_10);
            let v60_13: Space = unite(&(v60_8),&(v60_12));
            join_wrapped_into(&mut v59_6_write,&((v60_13).read_zipper()),&[]);
            }
            v48_15_cursor.ascend(1);
          }
          drop(v59_6_write);
          compose(&(v58_5),&(v59_6))
        };
        drop(v58_5);
        let v58_8: Space = intersect(&(*CONSTANT_1),&(v58_2));
        drop(v58_2);
        let v58_9: Space = if has_head(&(v58_8)) { singleton(&[]) } else { Space::new() };
        drop(v58_8);
        let v58_11: Space = if (&(v58_9)).is_empty() { Space::new() } else {
          let mut v63_10 = Space::new();
          let mut v63_10_write = v63_10.write_zipper();
          for v63_10_byte in v48_15_cursor.child_mask().iter() {
            v48_15_cursor.descend_to_existing_byte(v63_10_byte);
            {
            let v64_2: Space = singleton(&v48_15_cursor.path()[(v48_15_origin + 1)..(v48_15_origin + 2)]);
            let v64_3: Space = intersect(&(*CONSTANT_1),&(v64_2));
            let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
            drop(v64_3);
            let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
            drop(v64_4);
            let v64_8: Space = if (&(v64_5)).is_empty() { Space::new() } else {
              let v65_7: Space = routine_13(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v64_5),&(v65_7))
            };
            drop(v64_5);
            let v64_9: Space = intersect(&(*CONSTANT_1),&(v64_2));
            drop(v64_2);
            let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
            drop(v64_9);
            let v64_12: Space = if (&(v64_10)).is_empty() { Space::new() } else {
              let v66_11: Space = routine_15(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v64_10),&(v66_11))
            };
            drop(v64_10);
            let v64_13: Space = unite(&(v64_8),&(v64_12));
            join_wrapped_into(&mut v63_10_write,&((v64_13).read_zipper()),&[]);
            }
            v48_15_cursor.ascend(1);
          }
          drop(v63_10_write);
          compose(&(v58_9),&(v63_10))
        };
        drop(v58_9);
        let v58_12: Space = unite(&(v58_7),&(v58_11));
        join_wrapped_into(&mut v48_15_write,&((v58_12).read_zipper()),&[]);
        }
        v48_15_cursor.ascend(1);
      }
      drop(v48_15_cursor);
      drop(v48_15_write);
      let v48_16: Space = subtract(&(v48_15),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)])));
      let v48_17: Space = intersect(&(v48_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
      compose(&(v37_10),&(v48_17))
    };
    drop(v37_10);
    let v67_6: Path = concat_path(&(*p0),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)]);
    let v37_19: Space = wrap(&(v37_18),&(v67_6));
    let v37_20: Space = unite(&(v37_8),&(v37_19));
    join_wrapped_into(&mut v36_40_write,&((v37_20).read_zipper()),&[]);
    }
    v36_40_cursor.ascend(1);
  }
  drop(v36_40_cursor);
  drop(v36_40_write);
  (v36_40).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v68_8: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0))));
  let mut v68_27 = Space::new();
  let mut v68_27_write = v68_27.write_zipper();
  let mut v68_27_cursor = (v68_8).read_zipper();
  let v68_27_origin = v68_27_cursor.path().len();
  for v68_27_byte in v68_27_cursor.child_mask().iter() {
    v68_27_cursor.descend_to_existing_byte(v68_27_byte);
    {
    let v69_2: Space = singleton(&v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 1)]);
    let v69_3: Space = intersect(&(*CONSTANT_1),&(v69_2));
    let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
    drop(v69_3);
    let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
    drop(v69_4);
    let v69_7: Space = if (&(v69_5)).is_empty() { Space::new() } else {
      let mut v70_6 = Space::new();
      let mut v70_6_write = v70_6.write_zipper();
      for v70_6_byte in v68_27_cursor.child_mask().iter() {
        v68_27_cursor.descend_to_existing_byte(v70_6_byte);
        {
        let v71_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 1)..(v68_27_origin + 2)]);
        let v71_3: Space = intersect(&(*CONSTANT_1),&(v71_2));
        let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
        drop(v71_3);
        let v71_5: Space = subtract(&(*CONSTANT_0),&(v71_4));
        drop(v71_4);
        let v71_8: Space = if (&(v71_5)).is_empty() { Space::new() } else {
          let mut v72_7 = Space::new();
          let mut v72_7_write = v72_7.write_zipper();
          for v72_7_byte in v68_27_cursor.child_mask().iter() {
            v68_27_cursor.descend_to_existing_byte(v72_7_byte);
            {
            let v73_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 2)..(v68_27_origin + 3)]);
            let v73_3: Space = intersect(&(*CONSTANT_1),&(v73_2));
            let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
            drop(v73_3);
            let v73_5: Space = subtract(&(*CONSTANT_0),&(v73_4));
            drop(v73_4);
            let v73_8: Space = if (&(v73_5)).is_empty() { Space::new() } else {
              let v74_7: Space = routine_16(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v73_5),&(v74_7))
            };
            drop(v73_5);
            let v73_9: Space = intersect(&(*CONSTANT_1),&(v73_2));
            drop(v73_2);
            let v73_10: Space = if has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
            drop(v73_9);
            let v73_12: Space = if (&(v73_10)).is_empty() { Space::new() } else {
              let v75_11: Space = routine_17(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v73_10),&(v75_11))
            };
            drop(v73_10);
            let v73_13: Space = unite(&(v73_8),&(v73_12));
            join_wrapped_into(&mut v72_7_write,&((v73_13).read_zipper()),&[]);
            }
            v68_27_cursor.ascend(1);
          }
          drop(v72_7_write);
          compose(&(v71_5),&(v72_7))
        };
        drop(v71_5);
        let v71_9: Space = intersect(&(*CONSTANT_1),&(v71_2));
        drop(v71_2);
        let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
        drop(v71_9);
        let v71_12: Space = if (&(v71_10)).is_empty() { Space::new() } else {
          let mut v76_11 = Space::new();
          let mut v76_11_write = v76_11.write_zipper();
          for v76_11_byte in v68_27_cursor.child_mask().iter() {
            v68_27_cursor.descend_to_existing_byte(v76_11_byte);
            {
            let v77_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 2)..(v68_27_origin + 3)]);
            let v77_3: Space = intersect(&(*CONSTANT_1),&(v77_2));
            let v77_4: Space = if has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
            drop(v77_3);
            let v77_5: Space = subtract(&(*CONSTANT_0),&(v77_4));
            drop(v77_4);
            let v77_8: Space = if (&(v77_5)).is_empty() { Space::new() } else {
              let v78_7: Space = routine_16(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v77_5),&(v78_7))
            };
            drop(v77_5);
            let v77_9: Space = intersect(&(*CONSTANT_1),&(v77_2));
            drop(v77_2);
            let v77_10: Space = if has_head(&(v77_9)) { singleton(&[]) } else { Space::new() };
            drop(v77_9);
            let v77_12: Space = if (&(v77_10)).is_empty() { Space::new() } else {
              let v79_11: Space = routine_12(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v77_10),&(v79_11))
            };
            drop(v77_10);
            let v77_13: Space = unite(&(v77_8),&(v77_12));
            join_wrapped_into(&mut v76_11_write,&((v77_13).read_zipper()),&[]);
            }
            v68_27_cursor.ascend(1);
          }
          drop(v76_11_write);
          compose(&(v71_10),&(v76_11))
        };
        drop(v71_10);
        let v71_13: Space = unite(&(v71_8),&(v71_12));
        join_wrapped_into(&mut v70_6_write,&((v71_13).read_zipper()),&[]);
        }
        v68_27_cursor.ascend(1);
      }
      drop(v70_6_write);
      compose(&(v69_5),&(v70_6))
    };
    drop(v69_5);
    let v69_8: Space = intersect(&(*CONSTANT_1),&(v69_2));
    drop(v69_2);
    let v69_9: Space = if has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
    drop(v69_8);
    let v69_11: Space = if (&(v69_9)).is_empty() { Space::new() } else {
      let mut v80_10 = Space::new();
      let mut v80_10_write = v80_10.write_zipper();
      for v80_10_byte in v68_27_cursor.child_mask().iter() {
        v68_27_cursor.descend_to_existing_byte(v80_10_byte);
        {
        let v81_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 1)..(v68_27_origin + 2)]);
        let v81_3: Space = intersect(&(*CONSTANT_1),&(v81_2));
        let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
        drop(v81_3);
        let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
        drop(v81_4);
        let v81_8: Space = if (&(v81_5)).is_empty() { Space::new() } else {
          let mut v82_7 = Space::new();
          let mut v82_7_write = v82_7.write_zipper();
          for v82_7_byte in v68_27_cursor.child_mask().iter() {
            v68_27_cursor.descend_to_existing_byte(v82_7_byte);
            {
            let v83_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 2)..(v68_27_origin + 3)]);
            let v83_3: Space = intersect(&(*CONSTANT_1),&(v83_2));
            let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
            drop(v83_3);
            let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
            drop(v83_4);
            let v83_8: Space = if (&(v83_5)).is_empty() { Space::new() } else {
              let v84_7: Space = routine_16(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v83_5),&(v84_7))
            };
            drop(v83_5);
            let v83_9: Space = intersect(&(*CONSTANT_1),&(v83_2));
            drop(v83_2);
            let v83_10: Space = if has_head(&(v83_9)) { singleton(&[]) } else { Space::new() };
            drop(v83_9);
            let v83_12: Space = if (&(v83_10)).is_empty() { Space::new() } else {
              let v85_11: Space = routine_17(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v83_10),&(v85_11))
            };
            drop(v83_10);
            let v83_13: Space = unite(&(v83_8),&(v83_12));
            join_wrapped_into(&mut v82_7_write,&((v83_13).read_zipper()),&[]);
            }
            v68_27_cursor.ascend(1);
          }
          drop(v82_7_write);
          compose(&(v81_5),&(v82_7))
        };
        drop(v81_5);
        let v81_9: Space = intersect(&(*CONSTANT_1),&(v81_2));
        drop(v81_2);
        let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
        drop(v81_9);
        let v81_11: Space = compose(&(v81_10),&v68_27_cursor);
        drop(v81_10);
        let v81_12: Space = unite(&(v81_8),&(v81_11));
        drop(v81_11);
        join_wrapped_into(&mut v80_10_write,&((v81_12).read_zipper()),&[]);
        }
        v68_27_cursor.ascend(1);
      }
      drop(v80_10_write);
      compose(&(v69_9),&(v80_10))
    };
    drop(v69_9);
    let v69_12: Space = unite(&(v69_7),&(v69_11));
    join_wrapped_into(&mut v68_27_write,&((v69_12).read_zipper()),&[]);
    }
    v68_27_cursor.ascend(1);
  }
  drop(v68_27_cursor);
  drop(v68_27_write);
  drop(v68_8);
  let v68_28: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v68_27));
  let mut v68_47 = Space::new();
  let mut v68_47_write = v68_47.write_zipper();
  let mut v68_47_cursor = (v68_28).read_zipper();
  let v68_47_origin = v68_47_cursor.path().len();
  for v68_47_byte in v68_47_cursor.child_mask().iter() {
    v68_47_cursor.descend_to_existing_byte(v68_47_byte);
    {
    let v86_2: Space = singleton(&v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 1)]);
    let v86_3: Space = intersect(&(*CONSTANT_1),&(v86_2));
    let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
    drop(v86_3);
    let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
    drop(v86_4);
    let v86_7: Space = if (&(v86_5)).is_empty() { Space::new() } else {
      let mut v87_6 = Space::new();
      let mut v87_6_write = v87_6.write_zipper();
      for v87_6_byte in v68_47_cursor.child_mask().iter() {
        v68_47_cursor.descend_to_existing_byte(v87_6_byte);
        {
        let v88_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 1)..(v68_47_origin + 2)]);
        let v88_3: Space = intersect(&(*CONSTANT_1),&(v88_2));
        let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
        drop(v88_3);
        let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
        drop(v88_4);
        let v88_8: Space = if (&(v88_5)).is_empty() { Space::new() } else {
          let mut v89_7 = Space::new();
          let mut v89_7_write = v89_7.write_zipper();
          for v89_7_byte in v68_47_cursor.child_mask().iter() {
            v68_47_cursor.descend_to_existing_byte(v89_7_byte);
            {
            let v90_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 2)..(v68_47_origin + 3)]);
            let v90_3: Space = intersect(&(*CONSTANT_1),&(v90_2));
            let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
            drop(v90_3);
            let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
            drop(v90_4);
            let v90_8: Space = if (&(v90_5)).is_empty() { Space::new() } else {
              let v91_7: Space = routine_18(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v90_5),&(v91_7))
            };
            drop(v90_5);
            let v90_9: Space = intersect(&(*CONSTANT_1),&(v90_2));
            drop(v90_2);
            let v90_10: Space = if has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
            drop(v90_9);
            let v90_12: Space = if (&(v90_10)).is_empty() { Space::new() } else {
              let v92_11: Space = routine_19(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v90_10),&(v92_11))
            };
            drop(v90_10);
            let v90_13: Space = unite(&(v90_8),&(v90_12));
            join_wrapped_into(&mut v89_7_write,&((v90_13).read_zipper()),&[]);
            }
            v68_47_cursor.ascend(1);
          }
          drop(v89_7_write);
          compose(&(v88_5),&(v89_7))
        };
        drop(v88_5);
        let v88_9: Space = intersect(&(*CONSTANT_1),&(v88_2));
        drop(v88_2);
        let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
        drop(v88_9);
        let v88_12: Space = if (&(v88_10)).is_empty() { Space::new() } else {
          let mut v93_11 = Space::new();
          let mut v93_11_write = v93_11.write_zipper();
          for v93_11_byte in v68_47_cursor.child_mask().iter() {
            v68_47_cursor.descend_to_existing_byte(v93_11_byte);
            {
            let v94_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 2)..(v68_47_origin + 3)]);
            let v94_3: Space = intersect(&(*CONSTANT_1),&(v94_2));
            let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
            drop(v94_3);
            let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
            drop(v94_4);
            let v94_8: Space = if (&(v94_5)).is_empty() { Space::new() } else {
              let v95_7: Space = routine_18(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v94_5),&(v95_7))
            };
            drop(v94_5);
            let v94_9: Space = intersect(&(*CONSTANT_1),&(v94_2));
            drop(v94_2);
            let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
            drop(v94_9);
            let v94_12: Space = if (&(v94_10)).is_empty() { Space::new() } else {
              let v96_11: Space = routine_15(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v94_10),&(v96_11))
            };
            drop(v94_10);
            let v94_13: Space = unite(&(v94_8),&(v94_12));
            join_wrapped_into(&mut v93_11_write,&((v94_13).read_zipper()),&[]);
            }
            v68_47_cursor.ascend(1);
          }
          drop(v93_11_write);
          compose(&(v88_10),&(v93_11))
        };
        drop(v88_10);
        let v88_13: Space = unite(&(v88_8),&(v88_12));
        join_wrapped_into(&mut v87_6_write,&((v88_13).read_zipper()),&[]);
        }
        v68_47_cursor.ascend(1);
      }
      drop(v87_6_write);
      compose(&(v86_5),&(v87_6))
    };
    drop(v86_5);
    let v86_8: Space = intersect(&(*CONSTANT_1),&(v86_2));
    drop(v86_2);
    let v86_9: Space = if has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
    drop(v86_8);
    let v86_11: Space = if (&(v86_9)).is_empty() { Space::new() } else {
      let mut v97_10 = Space::new();
      let mut v97_10_write = v97_10.write_zipper();
      for v97_10_byte in v68_47_cursor.child_mask().iter() {
        v68_47_cursor.descend_to_existing_byte(v97_10_byte);
        {
        let v98_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 1)..(v68_47_origin + 2)]);
        let v98_3: Space = intersect(&(*CONSTANT_1),&(v98_2));
        let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
        drop(v98_3);
        let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
        drop(v98_4);
        let v98_8: Space = if (&(v98_5)).is_empty() { Space::new() } else {
          let mut v99_7 = Space::new();
          let mut v99_7_write = v99_7.write_zipper();
          for v99_7_byte in v68_47_cursor.child_mask().iter() {
            v68_47_cursor.descend_to_existing_byte(v99_7_byte);
            {
            let v100_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 2)..(v68_47_origin + 3)]);
            let v100_3: Space = intersect(&(*CONSTANT_1),&(v100_2));
            let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
            drop(v100_3);
            let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
            drop(v100_4);
            let v100_8: Space = if (&(v100_5)).is_empty() { Space::new() } else {
              let v101_7: Space = routine_18(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v100_5),&(v101_7))
            };
            drop(v100_5);
            let v100_9: Space = intersect(&(*CONSTANT_1),&(v100_2));
            drop(v100_2);
            let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
            drop(v100_9);
            let v100_12: Space = if (&(v100_10)).is_empty() { Space::new() } else {
              let v102_11: Space = routine_19(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v100_10),&(v102_11))
            };
            drop(v100_10);
            let v100_13: Space = unite(&(v100_8),&(v100_12));
            join_wrapped_into(&mut v99_7_write,&((v100_13).read_zipper()),&[]);
            }
            v68_47_cursor.ascend(1);
          }
          drop(v99_7_write);
          compose(&(v98_5),&(v99_7))
        };
        drop(v98_5);
        let v98_9: Space = intersect(&(*CONSTANT_1),&(v98_2));
        drop(v98_2);
        let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
        drop(v98_9);
        let v98_11: Space = compose(&(v98_10),&v68_47_cursor);
        drop(v98_10);
        let v98_12: Space = unite(&(v98_8),&(v98_11));
        drop(v98_11);
        join_wrapped_into(&mut v97_10_write,&((v98_12).read_zipper()),&[]);
        }
        v68_47_cursor.ascend(1);
      }
      drop(v97_10_write);
      compose(&(v86_9),&(v97_10))
    };
    drop(v86_9);
    let v86_12: Space = unite(&(v86_7),&(v86_11));
    join_wrapped_into(&mut v68_47_write,&((v86_12).read_zipper()),&[]);
    }
    v68_47_cursor.ascend(1);
  }
  drop(v68_47_cursor);
  drop(v68_47_write);
  let v68_48: Space = subtract(&(v68_47),&(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0))));
  let v68_51: Space = intersect(&(v68_48),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
  let v68_52: Space = wrap(&(v68_51),&(*p0));
  (v68_52).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v103_20 = Space::new();
  let mut v103_20_write = v103_20.write_zipper();
  let mut v103_20_cursor = (*s0).read_zipper();
  let v103_20_origin = v103_20_cursor.path().len();
  for v103_20_byte in v103_20_cursor.child_mask().iter() {
    v103_20_cursor.descend_to_existing_byte(v103_20_byte);
    {
    let v104_2: Space = singleton(&v103_20_cursor.path()[v103_20_origin..(v103_20_origin + 1)]);
    let v104_3: Space = intersect(&(*CONSTANT_1),&(v104_2));
    let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
    drop(v104_3);
    let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
    drop(v104_4);
    let v104_7: Space = if (&(v104_5)).is_empty() { Space::new() } else {
      let mut v105_6 = Space::new();
      let mut v105_6_write = v105_6.write_zipper();
      for v105_6_byte in v103_20_cursor.child_mask().iter() {
        v103_20_cursor.descend_to_existing_byte(v105_6_byte);
        {
        let v106_2: Space = Space::new();
        join_wrapped_into(&mut v105_6_write,&((v106_2).read_zipper()),&[]);
        }
        v103_20_cursor.ascend(1);
      }
      drop(v105_6_write);
      compose(&(v104_5),&(v105_6))
    };
    drop(v104_5);
    let v104_8: Space = intersect(&(*CONSTANT_1),&(v104_2));
    drop(v104_2);
    let v104_9: Space = if has_head(&(v104_8)) { singleton(&[]) } else { Space::new() };
    drop(v104_8);
    let v104_13: Space = if (&(v104_9)).is_empty() { Space::new() } else {
      let v107_11: Path = concat_path(&(*p0),&v103_20_cursor.path()[v103_20_origin..(v103_20_origin + 1)]);
      let mut v107_12 = Space::new();
      let mut v107_12_write = v107_12.write_zipper();
      for v107_12_byte in v103_20_cursor.child_mask().iter() {
        v103_20_cursor.descend_to_existing_byte(v107_12_byte);
        {
        let v108_2: Space = singleton(&v103_20_cursor.path()[(v103_20_origin + 1)..(v103_20_origin + 2)]);
        let v108_3: Space = intersect(&(*CONSTANT_1),&(v108_2));
        drop(v108_2);
        let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
        drop(v108_3);
        let v108_12: Space = if (&(v108_4)).is_empty() { Space::new() } else {
          let v109_6: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v103_20_cursor.path()[v103_20_origin..(v103_20_origin + 1)]),&v103_20_cursor.path()[(v103_20_origin + 1)..(v103_20_origin + 2)])));
          let mut v109_7 = Space::new();
          let mut v109_7_write = v109_7.write_zipper();
          let mut v109_7_cursor = (v109_6).read_zipper();
          let v109_7_origin = v109_7_cursor.path().len();
          for v109_7_byte in v109_7_cursor.child_mask().iter() {
            v109_7_cursor.descend_to_existing_byte(v109_7_byte);
            {
            let v110_2: Space = singleton(&v109_7_cursor.path()[v109_7_origin..(v109_7_origin + 1)]);
            let v110_3: Space = intersect(&(*CONSTANT_1),&(v110_2));
            let v110_4: Space = if has_head(&(v110_3)) { singleton(&[]) } else { Space::new() };
            drop(v110_3);
            let v110_5: Space = subtract(&(*CONSTANT_0),&(v110_4));
            drop(v110_4);
            let v110_7: Space = if (&(v110_5)).is_empty() { Space::new() } else {
              let v111_6: Space = routine_6(c, &v109_7_cursor.path()[v109_7_origin..(v109_7_origin + 1)], &v109_7_cursor);
              compose(&(v110_5),&(v111_6))
            };
            drop(v110_5);
            let v110_8: Space = intersect(&(*CONSTANT_1),&(v110_2));
            drop(v110_2);
            let v110_9: Space = if has_head(&(v110_8)) { singleton(&[]) } else { Space::new() };
            drop(v110_8);
            let v110_11: Space = if (&(v110_9)).is_empty() { Space::new() } else {
              let v112_10: Space = routine_7(c, &v109_7_cursor.path()[v109_7_origin..(v109_7_origin + 1)], &v109_7_cursor);
              compose(&(v110_9),&(v112_10))
            };
            drop(v110_9);
            let v110_12: Space = unite(&(v110_7),&(v110_11));
            join_wrapped_into(&mut v109_7_write,&((v110_12).read_zipper()),&[]);
            }
            v109_7_cursor.ascend(1);
          }
          drop(v109_7_cursor);
          drop(v109_7_write);
          drop(v109_6);
          let v109_8: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v109_7));
          let mut v109_9 = Space::new();
          let mut v109_9_write = v109_9.write_zipper();
          let mut v109_9_cursor = (v109_8).read_zipper();
          let v109_9_origin = v109_9_cursor.path().len();
          for v109_9_byte in v109_9_cursor.child_mask().iter() {
            v109_9_cursor.descend_to_existing_byte(v109_9_byte);
            {
            let v113_2: Space = singleton(&v109_9_cursor.path()[v109_9_origin..(v109_9_origin + 1)]);
            let v113_3: Space = intersect(&(*CONSTANT_1),&(v113_2));
            let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
            drop(v113_3);
            let v113_5: Space = subtract(&(*CONSTANT_0),&(v113_4));
            drop(v113_4);
            let v113_7: Space = if (&(v113_5)).is_empty() { Space::new() } else {
              let v114_6: Space = routine_8(c, &v109_9_cursor.path()[v109_9_origin..(v109_9_origin + 1)], &v109_9_cursor);
              compose(&(v113_5),&(v114_6))
            };
            drop(v113_5);
            let v113_8: Space = intersect(&(*CONSTANT_1),&(v113_2));
            drop(v113_2);
            let v113_9: Space = if has_head(&(v113_8)) { singleton(&[]) } else { Space::new() };
            drop(v113_8);
            let v113_11: Space = if (&(v113_9)).is_empty() { Space::new() } else {
              let v115_10: Space = routine_9(c, &v109_9_cursor.path()[v109_9_origin..(v109_9_origin + 1)], &v109_9_cursor);
              compose(&(v113_9),&(v115_10))
            };
            drop(v113_9);
            let v113_12: Space = unite(&(v113_7),&(v113_11));
            join_wrapped_into(&mut v109_9_write,&((v113_12).read_zipper()),&[]);
            }
            v109_9_cursor.ascend(1);
          }
          drop(v109_9_cursor);
          drop(v109_9_write);
          let v109_10: Space = subtract(&(v109_9),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v103_20_cursor.path()[v103_20_origin..(v103_20_origin + 1)]),&v103_20_cursor.path()[(v103_20_origin + 1)..(v103_20_origin + 2)])));
          let v109_11: Space = intersect(&(v109_10),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
          compose(&(v108_4),&(v109_11))
        };
        drop(v108_4);
        let v108_13: Path = concat_path(&(v107_11),&v103_20_cursor.path()[(v103_20_origin + 1)..(v103_20_origin + 2)]);
        join_wrapped_into(&mut v107_12_write,&((v108_12).read_zipper()),&(v108_13));
        drop(v108_13);
        }
        v103_20_cursor.ascend(1);
      }
      drop(v107_12_write);
      drop(v107_11);
      compose(&(v104_9),&(v107_12))
    };
    drop(v104_9);
    let v104_14: Space = unite(&(v104_7),&(v104_13));
    drop(v104_7);
    join_wrapped_into(&mut v103_20_write,&((v104_14).read_zipper()),&[]);
    }
    v103_20_cursor.ascend(1);
  }
  drop(v103_20_cursor);
  drop(v103_20_write);
  (v103_20).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v116_31 = Space::new();
  let mut v116_31_write = v116_31.write_zipper();
  let mut v116_31_cursor = (*s0).read_zipper();
  let v116_31_origin = v116_31_cursor.path().len();
  for v116_31_byte in v116_31_cursor.child_mask().iter() {
    v116_31_cursor.descend_to_existing_byte(v116_31_byte);
    {
    let v117_2: Space = singleton(&v116_31_cursor.path()[v116_31_origin..(v116_31_origin + 1)]);
    let v117_3: Space = intersect(&(*CONSTANT_1),&(v117_2));
    let v117_4: Space = if has_head(&(v117_3)) { singleton(&[]) } else { Space::new() };
    drop(v117_3);
    let v117_5: Space = subtract(&(*CONSTANT_0),&(v117_4));
    drop(v117_4);
    let v117_7: Space = if (&(v117_5)).is_empty() { Space::new() } else {
      let mut v118_6 = Space::new();
      let mut v118_6_write = v118_6.write_zipper();
      for v118_6_byte in v116_31_cursor.child_mask().iter() {
        v116_31_cursor.descend_to_existing_byte(v118_6_byte);
        {
        let v119_2: Space = Space::new();
        join_wrapped_into(&mut v118_6_write,&((v119_2).read_zipper()),&[]);
        }
        v116_31_cursor.ascend(1);
      }
      drop(v118_6_write);
      compose(&(v117_5),&(v118_6))
    };
    drop(v117_5);
    let v117_8: Space = intersect(&(*CONSTANT_1),&(v117_2));
    drop(v117_2);
    let v117_9: Space = if has_head(&(v117_8)) { singleton(&[]) } else { Space::new() };
    drop(v117_8);
    let v117_17: Space = if (&(v117_9)).is_empty() { Space::new() } else {
      let v120_11: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v116_31_cursor.path()[v116_31_origin..(v116_31_origin + 1)])));
      let mut v120_12 = Space::new();
      let mut v120_12_write = v120_12.write_zipper();
      let mut v120_12_cursor = (v120_11).read_zipper();
      let v120_12_origin = v120_12_cursor.path().len();
      for v120_12_byte in v120_12_cursor.child_mask().iter() {
        v120_12_cursor.descend_to_existing_byte(v120_12_byte);
        {
        let v121_2: Space = singleton(&v120_12_cursor.path()[v120_12_origin..(v120_12_origin + 1)]);
        let v121_3: Space = intersect(&(*CONSTANT_1),&(v121_2));
        let v121_4: Space = if has_head(&(v121_3)) { singleton(&[]) } else { Space::new() };
        drop(v121_3);
        let v121_5: Space = subtract(&(*CONSTANT_0),&(v121_4));
        drop(v121_4);
        let v121_7: Space = if (&(v121_5)).is_empty() { Space::new() } else {
          let mut v122_6 = Space::new();
          let mut v122_6_write = v122_6.write_zipper();
          for v122_6_byte in v120_12_cursor.child_mask().iter() {
            v120_12_cursor.descend_to_existing_byte(v122_6_byte);
            {
            let v123_2: Space = singleton(&v120_12_cursor.path()[(v120_12_origin + 1)..(v120_12_origin + 2)]);
            let v123_3: Space = intersect(&(*CONSTANT_1),&(v123_2));
            let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
            drop(v123_3);
            let v123_5: Space = subtract(&(*CONSTANT_0),&(v123_4));
            drop(v123_4);
            let v123_8: Space = if (&(v123_5)).is_empty() { Space::new() } else {
              let v124_7: Space = routine_10(c, &v120_12_cursor.path()[v120_12_origin..(v120_12_origin + 2)], &v120_12_cursor);
              compose(&(v123_5),&(v124_7))
            };
            drop(v123_5);
            let v123_9: Space = intersect(&(*CONSTANT_1),&(v123_2));
            drop(v123_2);
            let v123_10: Space = if has_head(&(v123_9)) { singleton(&[]) } else { Space::new() };
            drop(v123_9);
            let v123_12: Space = if (&(v123_10)).is_empty() { Space::new() } else {
              let v125_11: Space = routine_11(c, &v120_12_cursor.path()[v120_12_origin..(v120_12_origin + 2)], &v120_12_cursor);
              compose(&(v123_10),&(v125_11))
            };
            drop(v123_10);
            let v123_13: Space = unite(&(v123_8),&(v123_12));
            join_wrapped_into(&mut v122_6_write,&((v123_13).read_zipper()),&[]);
            }
            v120_12_cursor.ascend(1);
          }
          drop(v122_6_write);
          compose(&(v121_5),&(v122_6))
        };
        drop(v121_5);
        let v121_8: Space = intersect(&(*CONSTANT_1),&(v121_2));
        drop(v121_2);
        let v121_9: Space = if has_head(&(v121_8)) { singleton(&[]) } else { Space::new() };
        drop(v121_8);
        let v121_11: Space = if (&(v121_9)).is_empty() { Space::new() } else {
          let mut v126_10 = Space::new();
          let mut v126_10_write = v126_10.write_zipper();
          for v126_10_byte in v120_12_cursor.child_mask().iter() {
            v120_12_cursor.descend_to_existing_byte(v126_10_byte);
            {
            let v127_2: Space = singleton(&v120_12_cursor.path()[(v120_12_origin + 1)..(v120_12_origin + 2)]);
            let v127_3: Space = intersect(&(*CONSTANT_1),&(v127_2));
            let v127_4: Space = if has_head(&(v127_3)) { singleton(&[]) } else { Space::new() };
            drop(v127_3);
            let v127_5: Space = subtract(&(*CONSTANT_0),&(v127_4));
            drop(v127_4);
            let v127_8: Space = if (&(v127_5)).is_empty() { Space::new() } else {
              let v128_7: Space = routine_10(c, &v120_12_cursor.path()[v120_12_origin..(v120_12_origin + 2)], &v120_12_cursor);
              compose(&(v127_5),&(v128_7))
            };
            drop(v127_5);
            let v127_9: Space = intersect(&(*CONSTANT_1),&(v127_2));
            drop(v127_2);
            let v127_10: Space = if has_head(&(v127_9)) { singleton(&[]) } else { Space::new() };
            drop(v127_9);
            let v127_12: Space = if (&(v127_10)).is_empty() { Space::new() } else {
              let v129_11: Space = routine_12(c, &v120_12_cursor.path()[v120_12_origin..(v120_12_origin + 2)], &v120_12_cursor);
              compose(&(v127_10),&(v129_11))
            };
            drop(v127_10);
            let v127_13: Space = unite(&(v127_8),&(v127_12));
            join_wrapped_into(&mut v126_10_write,&((v127_13).read_zipper()),&[]);
            }
            v120_12_cursor.ascend(1);
          }
          drop(v126_10_write);
          compose(&(v121_9),&(v126_10))
        };
        drop(v121_9);
        let v121_12: Space = unite(&(v121_7),&(v121_11));
        join_wrapped_into(&mut v120_12_write,&((v121_12).read_zipper()),&[]);
        }
        v120_12_cursor.ascend(1);
      }
      drop(v120_12_cursor);
      drop(v120_12_write);
      drop(v120_11);
      let v120_13: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v120_12));
      let mut v120_14 = Space::new();
      let mut v120_14_write = v120_14.write_zipper();
      let mut v120_14_cursor = (v120_13).read_zipper();
      let v120_14_origin = v120_14_cursor.path().len();
      for v120_14_byte in v120_14_cursor.child_mask().iter() {
        v120_14_cursor.descend_to_existing_byte(v120_14_byte);
        {
        let v130_2: Space = singleton(&v120_14_cursor.path()[v120_14_origin..(v120_14_origin + 1)]);
        let v130_3: Space = intersect(&(*CONSTANT_1),&(v130_2));
        let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
        drop(v130_3);
        let v130_5: Space = subtract(&(*CONSTANT_0),&(v130_4));
        drop(v130_4);
        let v130_7: Space = if (&(v130_5)).is_empty() { Space::new() } else {
          let mut v131_6 = Space::new();
          let mut v131_6_write = v131_6.write_zipper();
          for v131_6_byte in v120_14_cursor.child_mask().iter() {
            v120_14_cursor.descend_to_existing_byte(v131_6_byte);
            {
            let v132_2: Space = singleton(&v120_14_cursor.path()[(v120_14_origin + 1)..(v120_14_origin + 2)]);
            let v132_3: Space = intersect(&(*CONSTANT_1),&(v132_2));
            let v132_4: Space = if has_head(&(v132_3)) { singleton(&[]) } else { Space::new() };
            drop(v132_3);
            let v132_5: Space = subtract(&(*CONSTANT_0),&(v132_4));
            drop(v132_4);
            let v132_8: Space = if (&(v132_5)).is_empty() { Space::new() } else {
              let v133_7: Space = routine_13(c, &v120_14_cursor.path()[v120_14_origin..(v120_14_origin + 2)], &v120_14_cursor);
              compose(&(v132_5),&(v133_7))
            };
            drop(v132_5);
            let v132_9: Space = intersect(&(*CONSTANT_1),&(v132_2));
            drop(v132_2);
            let v132_10: Space = if has_head(&(v132_9)) { singleton(&[]) } else { Space::new() };
            drop(v132_9);
            let v132_12: Space = if (&(v132_10)).is_empty() { Space::new() } else {
              let v134_11: Space = routine_14(c, &v120_14_cursor.path()[v120_14_origin..(v120_14_origin + 2)], &v120_14_cursor);
              compose(&(v132_10),&(v134_11))
            };
            drop(v132_10);
            let v132_13: Space = unite(&(v132_8),&(v132_12));
            join_wrapped_into(&mut v131_6_write,&((v132_13).read_zipper()),&[]);
            }
            v120_14_cursor.ascend(1);
          }
          drop(v131_6_write);
          compose(&(v130_5),&(v131_6))
        };
        drop(v130_5);
        let v130_8: Space = intersect(&(*CONSTANT_1),&(v130_2));
        drop(v130_2);
        let v130_9: Space = if has_head(&(v130_8)) { singleton(&[]) } else { Space::new() };
        drop(v130_8);
        let v130_11: Space = if (&(v130_9)).is_empty() { Space::new() } else {
          let mut v135_10 = Space::new();
          let mut v135_10_write = v135_10.write_zipper();
          for v135_10_byte in v120_14_cursor.child_mask().iter() {
            v120_14_cursor.descend_to_existing_byte(v135_10_byte);
            {
            let v136_2: Space = singleton(&v120_14_cursor.path()[(v120_14_origin + 1)..(v120_14_origin + 2)]);
            let v136_3: Space = intersect(&(*CONSTANT_1),&(v136_2));
            let v136_4: Space = if has_head(&(v136_3)) { singleton(&[]) } else { Space::new() };
            drop(v136_3);
            let v136_5: Space = subtract(&(*CONSTANT_0),&(v136_4));
            drop(v136_4);
            let v136_8: Space = if (&(v136_5)).is_empty() { Space::new() } else {
              let v137_7: Space = routine_13(c, &v120_14_cursor.path()[v120_14_origin..(v120_14_origin + 2)], &v120_14_cursor);
              compose(&(v136_5),&(v137_7))
            };
            drop(v136_5);
            let v136_9: Space = intersect(&(*CONSTANT_1),&(v136_2));
            drop(v136_2);
            let v136_10: Space = if has_head(&(v136_9)) { singleton(&[]) } else { Space::new() };
            drop(v136_9);
            let v136_12: Space = if (&(v136_10)).is_empty() { Space::new() } else {
              let v138_11: Space = routine_15(c, &v120_14_cursor.path()[v120_14_origin..(v120_14_origin + 2)], &v120_14_cursor);
              compose(&(v136_10),&(v138_11))
            };
            drop(v136_10);
            let v136_13: Space = unite(&(v136_8),&(v136_12));
            join_wrapped_into(&mut v135_10_write,&((v136_13).read_zipper()),&[]);
            }
            v120_14_cursor.ascend(1);
          }
          drop(v135_10_write);
          compose(&(v130_9),&(v135_10))
        };
        drop(v130_9);
        let v130_12: Space = unite(&(v130_7),&(v130_11));
        join_wrapped_into(&mut v120_14_write,&((v130_12).read_zipper()),&[]);
        }
        v120_14_cursor.ascend(1);
      }
      drop(v120_14_cursor);
      drop(v120_14_write);
      let v120_15: Space = subtract(&(v120_14),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v116_31_cursor.path()[v116_31_origin..(v116_31_origin + 1)])));
      let v120_16: Space = intersect(&(v120_15),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
      compose(&(v117_9),&(v120_16))
    };
    drop(v117_9);
    let v117_18: Path = concat_path(&(*p0),&v116_31_cursor.path()[v116_31_origin..(v116_31_origin + 1)]);
    let v117_19: Space = wrap(&(v117_17),&(v117_18));
    drop(v117_18);
    let v117_20: Space = unite(&(v117_7),&(v117_19));
    drop(v117_7);
    join_wrapped_into(&mut v116_31_write,&((v117_20).read_zipper()),&[]);
    }
    v116_31_cursor.ascend(1);
  }
  drop(v116_31_cursor);
  drop(v116_31_write);
  (v116_31).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v139_20 = Space::new();
  let mut v139_20_write = v139_20.write_zipper();
  let mut v139_20_cursor = (*s0).read_zipper();
  let v139_20_origin = v139_20_cursor.path().len();
  for v139_20_byte in v139_20_cursor.child_mask().iter() {
    v139_20_cursor.descend_to_existing_byte(v139_20_byte);
    {
    let v140_2: Space = singleton(&v139_20_cursor.path()[v139_20_origin..(v139_20_origin + 1)]);
    let v140_3: Space = intersect(&(*CONSTANT_1),&(v140_2));
    let v140_4: Space = if has_head(&(v140_3)) { singleton(&[]) } else { Space::new() };
    drop(v140_3);
    let v140_5: Space = subtract(&(*CONSTANT_0),&(v140_4));
    drop(v140_4);
    let v140_8: Space = if (&(v140_5)).is_empty() { Space::new() } else {
      let v141_6: Path = concat_path(&(*p0),&v139_20_cursor.path()[v139_20_origin..(v139_20_origin + 1)]);
      let mut v141_7 = Space::new();
      let mut v141_7_write = v141_7.write_zipper();
      for v141_7_byte in v139_20_cursor.child_mask().iter() {
        v139_20_cursor.descend_to_existing_byte(v141_7_byte);
        {
        let v142_2: Space = singleton(&v139_20_cursor.path()[(v139_20_origin + 1)..(v139_20_origin + 2)]);
        let v142_3: Space = intersect(&(*CONSTANT_1),&(v142_2));
        let v142_4: Space = if has_head(&(v142_3)) { singleton(&[]) } else { Space::new() };
        drop(v142_3);
        let v142_5: Space = subtract(&(*CONSTANT_0),&(v142_4));
        drop(v142_4);
        let v142_8: Space = if (&(v142_5)).is_empty() { Space::new() } else {
          let v143_6: Path = concat_path(&(v141_6),&v139_20_cursor.path()[(v139_20_origin + 1)..(v139_20_origin + 2)]);
          let mut v143_7 = Space::new();
          let mut v143_7_write = v143_7.write_zipper();
          for v143_7_byte in v139_20_cursor.child_mask().iter() {
            v139_20_cursor.descend_to_existing_byte(v143_7_byte);
            {
            let v144_2: Space = singleton(&v139_20_cursor.path()[(v139_20_origin + 2)..(v139_20_origin + 3)]);
            let v144_3: Space = intersect(&(*CONSTANT_1),&(v144_2));
            let v144_4: Space = if has_head(&(v144_3)) { singleton(&[]) } else { Space::new() };
            drop(v144_3);
            let v144_5: Space = subtract(&(*CONSTANT_0),&(v144_4));
            drop(v144_4);
            let v144_8: Space = if (&(v144_5)).is_empty() { Space::new() } else {
              let v145_6: Path = concat_path(&(v143_6),&v139_20_cursor.path()[(v139_20_origin + 2)..(v139_20_origin + 3)]);
              let v145_7: Space = routine_20(c, &(v145_6), &v139_20_cursor);
              compose(&(v144_5),&(v145_7))
            };
            drop(v144_5);
            let v144_9: Space = intersect(&(*CONSTANT_1),&(v144_2));
            drop(v144_2);
            let v144_10: Space = if has_head(&(v144_9)) { singleton(&[]) } else { Space::new() };
            drop(v144_9);
            let v144_12: Space = if (&(v144_10)).is_empty() { Space::new() } else {
              let v146_6: Path = concat_path(&(v143_6),&v139_20_cursor.path()[(v139_20_origin + 2)..(v139_20_origin + 3)]);
              let v146_11: Space = routine_21(c, &(v146_6), &v139_20_cursor);
              drop(v146_6);
              compose(&(v144_10),&(v146_11))
            };
            drop(v144_10);
            let v144_13: Space = unite(&(v144_8),&(v144_12));
            join_wrapped_into(&mut v143_7_write,&((v144_13).read_zipper()),&[]);
            }
            v139_20_cursor.ascend(1);
          }
          drop(v143_7_write);
          compose(&(v142_5),&(v143_7))
        };
        drop(v142_5);
        let v142_9: Space = intersect(&(*CONSTANT_1),&(v142_2));
        drop(v142_2);
        let v142_10: Space = if has_head(&(v142_9)) { singleton(&[]) } else { Space::new() };
        drop(v142_9);
        let v142_12: Space = if (&(v142_10)).is_empty() { Space::new() } else {
          let v147_6: Path = concat_path(&(v141_6),&v139_20_cursor.path()[(v139_20_origin + 1)..(v139_20_origin + 2)]);
          let mut v147_11 = Space::new();
          let mut v147_11_write = v147_11.write_zipper();
          for v147_11_byte in v139_20_cursor.child_mask().iter() {
            v139_20_cursor.descend_to_existing_byte(v147_11_byte);
            {
            let v148_2: Space = singleton(&v139_20_cursor.path()[(v139_20_origin + 2)..(v139_20_origin + 3)]);
            let v148_3: Space = intersect(&(*CONSTANT_1),&(v148_2));
            let v148_4: Space = if has_head(&(v148_3)) { singleton(&[]) } else { Space::new() };
            drop(v148_3);
            let v148_5: Space = subtract(&(*CONSTANT_0),&(v148_4));
            drop(v148_4);
            let v148_8: Space = if (&(v148_5)).is_empty() { Space::new() } else {
              let v149_6: Path = concat_path(&(v147_6),&v139_20_cursor.path()[(v139_20_origin + 2)..(v139_20_origin + 3)]);
              let v149_7: Space = routine_20(c, &(v149_6), &v139_20_cursor);
              compose(&(v148_5),&(v149_7))
            };
            drop(v148_5);
            let v148_9: Space = intersect(&(*CONSTANT_1),&(v148_2));
            drop(v148_2);
            let v148_10: Space = if has_head(&(v148_9)) { singleton(&[]) } else { Space::new() };
            drop(v148_9);
            let v148_12: Space = if (&(v148_10)).is_empty() { Space::new() } else {
              let v150_6: Path = concat_path(&(v147_6),&v139_20_cursor.path()[(v139_20_origin + 2)..(v139_20_origin + 3)]);
              let v150_11: Space = routine_12(c, &(v150_6), &v139_20_cursor);
              drop(v150_6);
              compose(&(v148_10),&(v150_11))
            };
            drop(v148_10);
            let v148_13: Space = unite(&(v148_8),&(v148_12));
            join_wrapped_into(&mut v147_11_write,&((v148_13).read_zipper()),&[]);
            }
            v139_20_cursor.ascend(1);
          }
          drop(v147_11_write);
          drop(v147_6);
          compose(&(v142_10),&(v147_11))
        };
        drop(v142_10);
        let v142_13: Space = unite(&(v142_8),&(v142_12));
        join_wrapped_into(&mut v141_7_write,&((v142_13).read_zipper()),&[]);
        }
        v139_20_cursor.ascend(1);
      }
      drop(v141_7_write);
      compose(&(v140_5),&(v141_7))
    };
    drop(v140_5);
    let v140_9: Space = intersect(&(*CONSTANT_1),&(v140_2));
    drop(v140_2);
    let v140_10: Space = if has_head(&(v140_9)) { singleton(&[]) } else { Space::new() };
    drop(v140_9);
    let v140_12: Space = if (&(v140_10)).is_empty() { Space::new() } else {
      let v151_6: Path = concat_path(&(*p0),&v139_20_cursor.path()[v139_20_origin..(v139_20_origin + 1)]);
      let mut v151_11 = Space::new();
      let mut v151_11_write = v151_11.write_zipper();
      for v151_11_byte in v139_20_cursor.child_mask().iter() {
        v139_20_cursor.descend_to_existing_byte(v151_11_byte);
        {
        let v152_2: Space = singleton(&v139_20_cursor.path()[(v139_20_origin + 1)..(v139_20_origin + 2)]);
        let v152_3: Space = intersect(&(*CONSTANT_1),&(v152_2));
        let v152_4: Space = if has_head(&(v152_3)) { singleton(&[]) } else { Space::new() };
        drop(v152_3);
        let v152_5: Space = subtract(&(*CONSTANT_0),&(v152_4));
        drop(v152_4);
        let v152_8: Space = if (&(v152_5)).is_empty() { Space::new() } else {
          let v153_6: Path = concat_path(&(v151_6),&v139_20_cursor.path()[(v139_20_origin + 1)..(v139_20_origin + 2)]);
          let mut v153_7 = Space::new();
          let mut v153_7_write = v153_7.write_zipper();
          for v153_7_byte in v139_20_cursor.child_mask().iter() {
            v139_20_cursor.descend_to_existing_byte(v153_7_byte);
            {
            let v154_2: Space = singleton(&v139_20_cursor.path()[(v139_20_origin + 2)..(v139_20_origin + 3)]);
            let v154_3: Space = intersect(&(*CONSTANT_1),&(v154_2));
            let v154_4: Space = if has_head(&(v154_3)) { singleton(&[]) } else { Space::new() };
            drop(v154_3);
            let v154_5: Space = subtract(&(*CONSTANT_0),&(v154_4));
            drop(v154_4);
            let v154_8: Space = if (&(v154_5)).is_empty() { Space::new() } else {
              let v155_6: Path = concat_path(&(v153_6),&v139_20_cursor.path()[(v139_20_origin + 2)..(v139_20_origin + 3)]);
              let v155_7: Space = routine_20(c, &(v155_6), &v139_20_cursor);
              compose(&(v154_5),&(v155_7))
            };
            drop(v154_5);
            let v154_9: Space = intersect(&(*CONSTANT_1),&(v154_2));
            drop(v154_2);
            let v154_10: Space = if has_head(&(v154_9)) { singleton(&[]) } else { Space::new() };
            drop(v154_9);
            let v154_12: Space = if (&(v154_10)).is_empty() { Space::new() } else {
              let v156_6: Path = concat_path(&(v153_6),&v139_20_cursor.path()[(v139_20_origin + 2)..(v139_20_origin + 3)]);
              let v156_11: Space = routine_21(c, &(v156_6), &v139_20_cursor);
              drop(v156_6);
              compose(&(v154_10),&(v156_11))
            };
            drop(v154_10);
            let v154_13: Space = unite(&(v154_8),&(v154_12));
            join_wrapped_into(&mut v153_7_write,&((v154_13).read_zipper()),&[]);
            }
            v139_20_cursor.ascend(1);
          }
          drop(v153_7_write);
          drop(v153_6);
          compose(&(v152_5),&(v153_7))
        };
        drop(v152_5);
        let v152_9: Space = intersect(&(*CONSTANT_1),&(v152_2));
        drop(v152_2);
        let v152_10: Space = if has_head(&(v152_9)) { singleton(&[]) } else { Space::new() };
        drop(v152_9);
        let v152_11: Space = compose(&(v152_10),&v139_20_cursor);
        drop(v152_10);
        let v152_12: Space = unite(&(v152_8),&(v152_11));
        drop(v152_11);
        join_wrapped_into(&mut v151_11_write,&((v152_12).read_zipper()),&[]);
        }
        v139_20_cursor.ascend(1);
      }
      drop(v151_11_write);
      drop(v151_6);
      compose(&(v140_10),&(v151_11))
    };
    drop(v140_10);
    let v140_13: Space = unite(&(v140_8),&(v140_12));
    join_wrapped_into(&mut v139_20_write,&((v140_13).read_zipper()),&[]);
    }
    v139_20_cursor.ascend(1);
  }
  drop(v139_20_cursor);
  drop(v139_20_write);
  (v139_20).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v157_14 = Space::new();
  let mut v157_14_write = v157_14.write_zipper();
  let mut v157_14_cursor = (*s0).read_zipper();
  let v157_14_origin = v157_14_cursor.path().len();
  for v157_14_byte in v157_14_cursor.child_mask().iter() {
    v157_14_cursor.descend_to_existing_byte(v157_14_byte);
    {
    let v158_2: Space = singleton(&v157_14_cursor.path()[v157_14_origin..(v157_14_origin + 1)]);
    let v158_3: Space = intersect(&(*CONSTANT_1),&(v158_2));
    let v158_4: Space = if has_head(&(v158_3)) { singleton(&[]) } else { Space::new() };
    drop(v158_3);
    let v158_5: Space = subtract(&(*CONSTANT_0),&(v158_4));
    drop(v158_4);
    let v158_8: Space = if (&(v158_5)).is_empty() { Space::new() } else {
      let v159_6: Path = concat_path(&(*p0),&v157_14_cursor.path()[v157_14_origin..(v157_14_origin + 1)]);
      let mut v159_7 = Space::new();
      let mut v159_7_write = v159_7.write_zipper();
      for v159_7_byte in v157_14_cursor.child_mask().iter() {
        v157_14_cursor.descend_to_existing_byte(v159_7_byte);
        {
        let v160_2: Space = singleton(&v157_14_cursor.path()[(v157_14_origin + 1)..(v157_14_origin + 2)]);
        let v160_3: Space = intersect(&(*CONSTANT_1),&(v160_2));
        let v160_4: Space = if has_head(&(v160_3)) { singleton(&[]) } else { Space::new() };
        drop(v160_3);
        let v160_5: Space = subtract(&(*CONSTANT_0),&(v160_4));
        drop(v160_4);
        let v160_8: Space = if (&(v160_5)).is_empty() { Space::new() } else {
          let v161_6: Path = concat_path(&(v159_6),&v157_14_cursor.path()[(v157_14_origin + 1)..(v157_14_origin + 2)]);
          let mut v161_7 = Space::new();
          let mut v161_7_write = v161_7.write_zipper();
          for v161_7_byte in v157_14_cursor.child_mask().iter() {
            v157_14_cursor.descend_to_existing_byte(v161_7_byte);
            {
            let v162_2: Space = singleton(&v157_14_cursor.path()[(v157_14_origin + 2)..(v157_14_origin + 3)]);
            let v162_3: Space = intersect(&(*CONSTANT_1),&(v162_2));
            let v162_4: Space = if has_head(&(v162_3)) { singleton(&[]) } else { Space::new() };
            drop(v162_3);
            let v162_5: Space = subtract(&(*CONSTANT_0),&(v162_4));
            drop(v162_4);
            let v162_8: Space = if (&(v162_5)).is_empty() { Space::new() } else {
              let v163_6: Path = concat_path(&(v161_6),&v157_14_cursor.path()[(v157_14_origin + 2)..(v157_14_origin + 3)]);
              let v163_7: Space = routine_20(c, &(v163_6), &v157_14_cursor);
              compose(&(v162_5),&(v163_7))
            };
            drop(v162_5);
            let v162_9: Space = intersect(&(*CONSTANT_1),&(v162_2));
            drop(v162_2);
            let v162_10: Space = if has_head(&(v162_9)) { singleton(&[]) } else { Space::new() };
            drop(v162_9);
            let v162_12: Space = if (&(v162_10)).is_empty() { Space::new() } else {
              let v164_6: Path = concat_path(&(v161_6),&v157_14_cursor.path()[(v157_14_origin + 2)..(v157_14_origin + 3)]);
              let v164_11: Space = routine_21(c, &(v164_6), &v157_14_cursor);
              drop(v164_6);
              compose(&(v162_10),&(v164_11))
            };
            drop(v162_10);
            let v162_13: Space = unite(&(v162_8),&(v162_12));
            join_wrapped_into(&mut v161_7_write,&((v162_13).read_zipper()),&[]);
            }
            v157_14_cursor.ascend(1);
          }
          drop(v161_7_write);
          compose(&(v160_5),&(v161_7))
        };
        drop(v160_5);
        let v160_9: Space = intersect(&(*CONSTANT_1),&(v160_2));
        drop(v160_2);
        let v160_10: Space = if has_head(&(v160_9)) { singleton(&[]) } else { Space::new() };
        drop(v160_9);
        let v160_12: Space = if (&(v160_10)).is_empty() { Space::new() } else {
          let v165_6: Path = concat_path(&(v159_6),&v157_14_cursor.path()[(v157_14_origin + 1)..(v157_14_origin + 2)]);
          let mut v165_11 = Space::new();
          let mut v165_11_write = v165_11.write_zipper();
          for v165_11_byte in v157_14_cursor.child_mask().iter() {
            v157_14_cursor.descend_to_existing_byte(v165_11_byte);
            {
            let v166_2: Space = singleton(&v157_14_cursor.path()[(v157_14_origin + 2)..(v157_14_origin + 3)]);
            let v166_3: Space = intersect(&(*CONSTANT_1),&(v166_2));
            let v166_4: Space = if has_head(&(v166_3)) { singleton(&[]) } else { Space::new() };
            drop(v166_3);
            let v166_5: Space = subtract(&(*CONSTANT_0),&(v166_4));
            drop(v166_4);
            let v166_8: Space = if (&(v166_5)).is_empty() { Space::new() } else {
              let v167_6: Path = concat_path(&(v165_6),&v157_14_cursor.path()[(v157_14_origin + 2)..(v157_14_origin + 3)]);
              let v167_7: Space = routine_20(c, &(v167_6), &v157_14_cursor);
              compose(&(v166_5),&(v167_7))
            };
            drop(v166_5);
            let v166_9: Space = intersect(&(*CONSTANT_1),&(v166_2));
            drop(v166_2);
            let v166_10: Space = if has_head(&(v166_9)) { singleton(&[]) } else { Space::new() };
            drop(v166_9);
            let v166_12: Space = if (&(v166_10)).is_empty() { Space::new() } else {
              let v168_6: Path = concat_path(&(v165_6),&v157_14_cursor.path()[(v157_14_origin + 2)..(v157_14_origin + 3)]);
              let v168_11: Space = routine_12(c, &(v168_6), &v157_14_cursor);
              drop(v168_6);
              compose(&(v166_10),&(v168_11))
            };
            drop(v166_10);
            let v166_13: Space = unite(&(v166_8),&(v166_12));
            join_wrapped_into(&mut v165_11_write,&((v166_13).read_zipper()),&[]);
            }
            v157_14_cursor.ascend(1);
          }
          drop(v165_11_write);
          drop(v165_6);
          compose(&(v160_10),&(v165_11))
        };
        drop(v160_10);
        let v160_13: Space = unite(&(v160_8),&(v160_12));
        join_wrapped_into(&mut v159_7_write,&((v160_13).read_zipper()),&[]);
        }
        v157_14_cursor.ascend(1);
      }
      drop(v159_7_write);
      drop(v159_6);
      compose(&(v158_5),&(v159_7))
    };
    drop(v158_5);
    let v158_9: Space = intersect(&(*CONSTANT_1),&(v158_2));
    drop(v158_2);
    let v158_10: Space = if has_head(&(v158_9)) { singleton(&[]) } else { Space::new() };
    drop(v158_9);
    let v158_11: Space = compose(&(v158_10),&v157_14_cursor);
    drop(v158_10);
    let v158_12: Space = unite(&(v158_8),&(v158_11));
    drop(v158_11);
    join_wrapped_into(&mut v157_14_write,&((v158_12).read_zipper()),&[]);
    }
    v157_14_cursor.ascend(1);
  }
  drop(v157_14_cursor);
  drop(v157_14_write);
  (v157_14).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v169_20 = Space::new();
  let mut v169_20_write = v169_20.write_zipper();
  let mut v169_20_cursor = (*s0).read_zipper();
  let v169_20_origin = v169_20_cursor.path().len();
  for v169_20_byte in v169_20_cursor.child_mask().iter() {
    v169_20_cursor.descend_to_existing_byte(v169_20_byte);
    {
    let v170_2: Space = singleton(&v169_20_cursor.path()[v169_20_origin..(v169_20_origin + 1)]);
    let v170_3: Space = intersect(&(*CONSTANT_1),&(v170_2));
    let v170_4: Space = if has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
    drop(v170_3);
    let v170_5: Space = subtract(&(*CONSTANT_0),&(v170_4));
    drop(v170_4);
    let v170_8: Space = if (&(v170_5)).is_empty() { Space::new() } else {
      let v171_6: Path = concat_path(&(*p0),&v169_20_cursor.path()[v169_20_origin..(v169_20_origin + 1)]);
      let mut v171_7 = Space::new();
      let mut v171_7_write = v171_7.write_zipper();
      for v171_7_byte in v169_20_cursor.child_mask().iter() {
        v169_20_cursor.descend_to_existing_byte(v171_7_byte);
        {
        let v172_2: Space = singleton(&v169_20_cursor.path()[(v169_20_origin + 1)..(v169_20_origin + 2)]);
        let v172_3: Space = intersect(&(*CONSTANT_1),&(v172_2));
        let v172_4: Space = if has_head(&(v172_3)) { singleton(&[]) } else { Space::new() };
        drop(v172_3);
        let v172_5: Space = subtract(&(*CONSTANT_0),&(v172_4));
        drop(v172_4);
        let v172_8: Space = if (&(v172_5)).is_empty() { Space::new() } else {
          let v173_6: Path = concat_path(&(v171_6),&v169_20_cursor.path()[(v169_20_origin + 1)..(v169_20_origin + 2)]);
          let mut v173_7 = Space::new();
          let mut v173_7_write = v173_7.write_zipper();
          for v173_7_byte in v169_20_cursor.child_mask().iter() {
            v169_20_cursor.descend_to_existing_byte(v173_7_byte);
            {
            let v174_2: Space = singleton(&v169_20_cursor.path()[(v169_20_origin + 2)..(v169_20_origin + 3)]);
            let v174_3: Space = intersect(&(*CONSTANT_1),&(v174_2));
            let v174_4: Space = if has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
            drop(v174_3);
            let v174_5: Space = subtract(&(*CONSTANT_0),&(v174_4));
            drop(v174_4);
            let v174_8: Space = if (&(v174_5)).is_empty() { Space::new() } else {
              let v175_6: Path = concat_path(&(v173_6),&v169_20_cursor.path()[(v169_20_origin + 2)..(v169_20_origin + 3)]);
              let v175_7: Space = routine_22(c, &(v175_6), &v169_20_cursor);
              compose(&(v174_5),&(v175_7))
            };
            drop(v174_5);
            let v174_9: Space = intersect(&(*CONSTANT_1),&(v174_2));
            drop(v174_2);
            let v174_10: Space = if has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
            drop(v174_9);
            let v174_12: Space = if (&(v174_10)).is_empty() { Space::new() } else {
              let v176_6: Path = concat_path(&(v173_6),&v169_20_cursor.path()[(v169_20_origin + 2)..(v169_20_origin + 3)]);
              let v176_11: Space = routine_23(c, &(v176_6), &v169_20_cursor);
              drop(v176_6);
              compose(&(v174_10),&(v176_11))
            };
            drop(v174_10);
            let v174_13: Space = unite(&(v174_8),&(v174_12));
            join_wrapped_into(&mut v173_7_write,&((v174_13).read_zipper()),&[]);
            }
            v169_20_cursor.ascend(1);
          }
          drop(v173_7_write);
          compose(&(v172_5),&(v173_7))
        };
        drop(v172_5);
        let v172_9: Space = intersect(&(*CONSTANT_1),&(v172_2));
        drop(v172_2);
        let v172_10: Space = if has_head(&(v172_9)) { singleton(&[]) } else { Space::new() };
        drop(v172_9);
        let v172_12: Space = if (&(v172_10)).is_empty() { Space::new() } else {
          let v177_6: Path = concat_path(&(v171_6),&v169_20_cursor.path()[(v169_20_origin + 1)..(v169_20_origin + 2)]);
          let mut v177_11 = Space::new();
          let mut v177_11_write = v177_11.write_zipper();
          for v177_11_byte in v169_20_cursor.child_mask().iter() {
            v169_20_cursor.descend_to_existing_byte(v177_11_byte);
            {
            let v178_2: Space = singleton(&v169_20_cursor.path()[(v169_20_origin + 2)..(v169_20_origin + 3)]);
            let v178_3: Space = intersect(&(*CONSTANT_1),&(v178_2));
            let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
            drop(v178_3);
            let v178_5: Space = subtract(&(*CONSTANT_0),&(v178_4));
            drop(v178_4);
            let v178_8: Space = if (&(v178_5)).is_empty() { Space::new() } else {
              let v179_6: Path = concat_path(&(v177_6),&v169_20_cursor.path()[(v169_20_origin + 2)..(v169_20_origin + 3)]);
              let v179_7: Space = routine_22(c, &(v179_6), &v169_20_cursor);
              compose(&(v178_5),&(v179_7))
            };
            drop(v178_5);
            let v178_9: Space = intersect(&(*CONSTANT_1),&(v178_2));
            drop(v178_2);
            let v178_10: Space = if has_head(&(v178_9)) { singleton(&[]) } else { Space::new() };
            drop(v178_9);
            let v178_12: Space = if (&(v178_10)).is_empty() { Space::new() } else {
              let v180_6: Path = concat_path(&(v177_6),&v169_20_cursor.path()[(v169_20_origin + 2)..(v169_20_origin + 3)]);
              let v180_11: Space = routine_15(c, &(v180_6), &v169_20_cursor);
              drop(v180_6);
              compose(&(v178_10),&(v180_11))
            };
            drop(v178_10);
            let v178_13: Space = unite(&(v178_8),&(v178_12));
            join_wrapped_into(&mut v177_11_write,&((v178_13).read_zipper()),&[]);
            }
            v169_20_cursor.ascend(1);
          }
          drop(v177_11_write);
          drop(v177_6);
          compose(&(v172_10),&(v177_11))
        };
        drop(v172_10);
        let v172_13: Space = unite(&(v172_8),&(v172_12));
        join_wrapped_into(&mut v171_7_write,&((v172_13).read_zipper()),&[]);
        }
        v169_20_cursor.ascend(1);
      }
      drop(v171_7_write);
      compose(&(v170_5),&(v171_7))
    };
    drop(v170_5);
    let v170_9: Space = intersect(&(*CONSTANT_1),&(v170_2));
    drop(v170_2);
    let v170_10: Space = if has_head(&(v170_9)) { singleton(&[]) } else { Space::new() };
    drop(v170_9);
    let v170_12: Space = if (&(v170_10)).is_empty() { Space::new() } else {
      let v181_6: Path = concat_path(&(*p0),&v169_20_cursor.path()[v169_20_origin..(v169_20_origin + 1)]);
      let mut v181_11 = Space::new();
      let mut v181_11_write = v181_11.write_zipper();
      for v181_11_byte in v169_20_cursor.child_mask().iter() {
        v169_20_cursor.descend_to_existing_byte(v181_11_byte);
        {
        let v182_2: Space = singleton(&v169_20_cursor.path()[(v169_20_origin + 1)..(v169_20_origin + 2)]);
        let v182_3: Space = intersect(&(*CONSTANT_1),&(v182_2));
        let v182_4: Space = if has_head(&(v182_3)) { singleton(&[]) } else { Space::new() };
        drop(v182_3);
        let v182_5: Space = subtract(&(*CONSTANT_0),&(v182_4));
        drop(v182_4);
        let v182_8: Space = if (&(v182_5)).is_empty() { Space::new() } else {
          let v183_6: Path = concat_path(&(v181_6),&v169_20_cursor.path()[(v169_20_origin + 1)..(v169_20_origin + 2)]);
          let mut v183_7 = Space::new();
          let mut v183_7_write = v183_7.write_zipper();
          for v183_7_byte in v169_20_cursor.child_mask().iter() {
            v169_20_cursor.descend_to_existing_byte(v183_7_byte);
            {
            let v184_2: Space = singleton(&v169_20_cursor.path()[(v169_20_origin + 2)..(v169_20_origin + 3)]);
            let v184_3: Space = intersect(&(*CONSTANT_1),&(v184_2));
            let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
            drop(v184_3);
            let v184_5: Space = subtract(&(*CONSTANT_0),&(v184_4));
            drop(v184_4);
            let v184_8: Space = if (&(v184_5)).is_empty() { Space::new() } else {
              let v185_6: Path = concat_path(&(v183_6),&v169_20_cursor.path()[(v169_20_origin + 2)..(v169_20_origin + 3)]);
              let v185_7: Space = routine_22(c, &(v185_6), &v169_20_cursor);
              compose(&(v184_5),&(v185_7))
            };
            drop(v184_5);
            let v184_9: Space = intersect(&(*CONSTANT_1),&(v184_2));
            drop(v184_2);
            let v184_10: Space = if has_head(&(v184_9)) { singleton(&[]) } else { Space::new() };
            drop(v184_9);
            let v184_12: Space = if (&(v184_10)).is_empty() { Space::new() } else {
              let v186_6: Path = concat_path(&(v183_6),&v169_20_cursor.path()[(v169_20_origin + 2)..(v169_20_origin + 3)]);
              let v186_11: Space = routine_23(c, &(v186_6), &v169_20_cursor);
              drop(v186_6);
              compose(&(v184_10),&(v186_11))
            };
            drop(v184_10);
            let v184_13: Space = unite(&(v184_8),&(v184_12));
            join_wrapped_into(&mut v183_7_write,&((v184_13).read_zipper()),&[]);
            }
            v169_20_cursor.ascend(1);
          }
          drop(v183_7_write);
          drop(v183_6);
          compose(&(v182_5),&(v183_7))
        };
        drop(v182_5);
        let v182_9: Space = intersect(&(*CONSTANT_1),&(v182_2));
        drop(v182_2);
        let v182_10: Space = if has_head(&(v182_9)) { singleton(&[]) } else { Space::new() };
        drop(v182_9);
        let v182_11: Space = compose(&(v182_10),&v169_20_cursor);
        drop(v182_10);
        let v182_12: Space = unite(&(v182_8),&(v182_11));
        drop(v182_11);
        join_wrapped_into(&mut v181_11_write,&((v182_12).read_zipper()),&[]);
        }
        v169_20_cursor.ascend(1);
      }
      drop(v181_11_write);
      drop(v181_6);
      compose(&(v170_10),&(v181_11))
    };
    drop(v170_10);
    let v170_13: Space = unite(&(v170_8),&(v170_12));
    join_wrapped_into(&mut v169_20_write,&((v170_13).read_zipper()),&[]);
    }
    v169_20_cursor.ascend(1);
  }
  drop(v169_20_cursor);
  drop(v169_20_write);
  (v169_20).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v187_14 = Space::new();
  let mut v187_14_write = v187_14.write_zipper();
  let mut v187_14_cursor = (*s0).read_zipper();
  let v187_14_origin = v187_14_cursor.path().len();
  for v187_14_byte in v187_14_cursor.child_mask().iter() {
    v187_14_cursor.descend_to_existing_byte(v187_14_byte);
    {
    let v188_2: Space = singleton(&v187_14_cursor.path()[v187_14_origin..(v187_14_origin + 1)]);
    let v188_3: Space = intersect(&(*CONSTANT_1),&(v188_2));
    let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
    drop(v188_3);
    let v188_5: Space = subtract(&(*CONSTANT_0),&(v188_4));
    drop(v188_4);
    let v188_8: Space = if (&(v188_5)).is_empty() { Space::new() } else {
      let v189_6: Path = concat_path(&(*p0),&v187_14_cursor.path()[v187_14_origin..(v187_14_origin + 1)]);
      let mut v189_7 = Space::new();
      let mut v189_7_write = v189_7.write_zipper();
      for v189_7_byte in v187_14_cursor.child_mask().iter() {
        v187_14_cursor.descend_to_existing_byte(v189_7_byte);
        {
        let v190_2: Space = singleton(&v187_14_cursor.path()[(v187_14_origin + 1)..(v187_14_origin + 2)]);
        let v190_3: Space = intersect(&(*CONSTANT_1),&(v190_2));
        let v190_4: Space = if has_head(&(v190_3)) { singleton(&[]) } else { Space::new() };
        drop(v190_3);
        let v190_5: Space = subtract(&(*CONSTANT_0),&(v190_4));
        drop(v190_4);
        let v190_8: Space = if (&(v190_5)).is_empty() { Space::new() } else {
          let v191_6: Path = concat_path(&(v189_6),&v187_14_cursor.path()[(v187_14_origin + 1)..(v187_14_origin + 2)]);
          let mut v191_7 = Space::new();
          let mut v191_7_write = v191_7.write_zipper();
          for v191_7_byte in v187_14_cursor.child_mask().iter() {
            v187_14_cursor.descend_to_existing_byte(v191_7_byte);
            {
            let v192_2: Space = singleton(&v187_14_cursor.path()[(v187_14_origin + 2)..(v187_14_origin + 3)]);
            let v192_3: Space = intersect(&(*CONSTANT_1),&(v192_2));
            let v192_4: Space = if has_head(&(v192_3)) { singleton(&[]) } else { Space::new() };
            drop(v192_3);
            let v192_5: Space = subtract(&(*CONSTANT_0),&(v192_4));
            drop(v192_4);
            let v192_8: Space = if (&(v192_5)).is_empty() { Space::new() } else {
              let v193_6: Path = concat_path(&(v191_6),&v187_14_cursor.path()[(v187_14_origin + 2)..(v187_14_origin + 3)]);
              let v193_7: Space = routine_22(c, &(v193_6), &v187_14_cursor);
              compose(&(v192_5),&(v193_7))
            };
            drop(v192_5);
            let v192_9: Space = intersect(&(*CONSTANT_1),&(v192_2));
            drop(v192_2);
            let v192_10: Space = if has_head(&(v192_9)) { singleton(&[]) } else { Space::new() };
            drop(v192_9);
            let v192_12: Space = if (&(v192_10)).is_empty() { Space::new() } else {
              let v194_6: Path = concat_path(&(v191_6),&v187_14_cursor.path()[(v187_14_origin + 2)..(v187_14_origin + 3)]);
              let v194_11: Space = routine_23(c, &(v194_6), &v187_14_cursor);
              drop(v194_6);
              compose(&(v192_10),&(v194_11))
            };
            drop(v192_10);
            let v192_13: Space = unite(&(v192_8),&(v192_12));
            join_wrapped_into(&mut v191_7_write,&((v192_13).read_zipper()),&[]);
            }
            v187_14_cursor.ascend(1);
          }
          drop(v191_7_write);
          compose(&(v190_5),&(v191_7))
        };
        drop(v190_5);
        let v190_9: Space = intersect(&(*CONSTANT_1),&(v190_2));
        drop(v190_2);
        let v190_10: Space = if has_head(&(v190_9)) { singleton(&[]) } else { Space::new() };
        drop(v190_9);
        let v190_12: Space = if (&(v190_10)).is_empty() { Space::new() } else {
          let v195_6: Path = concat_path(&(v189_6),&v187_14_cursor.path()[(v187_14_origin + 1)..(v187_14_origin + 2)]);
          let mut v195_11 = Space::new();
          let mut v195_11_write = v195_11.write_zipper();
          for v195_11_byte in v187_14_cursor.child_mask().iter() {
            v187_14_cursor.descend_to_existing_byte(v195_11_byte);
            {
            let v196_2: Space = singleton(&v187_14_cursor.path()[(v187_14_origin + 2)..(v187_14_origin + 3)]);
            let v196_3: Space = intersect(&(*CONSTANT_1),&(v196_2));
            let v196_4: Space = if has_head(&(v196_3)) { singleton(&[]) } else { Space::new() };
            drop(v196_3);
            let v196_5: Space = subtract(&(*CONSTANT_0),&(v196_4));
            drop(v196_4);
            let v196_8: Space = if (&(v196_5)).is_empty() { Space::new() } else {
              let v197_6: Path = concat_path(&(v195_6),&v187_14_cursor.path()[(v187_14_origin + 2)..(v187_14_origin + 3)]);
              let v197_7: Space = routine_22(c, &(v197_6), &v187_14_cursor);
              compose(&(v196_5),&(v197_7))
            };
            drop(v196_5);
            let v196_9: Space = intersect(&(*CONSTANT_1),&(v196_2));
            drop(v196_2);
            let v196_10: Space = if has_head(&(v196_9)) { singleton(&[]) } else { Space::new() };
            drop(v196_9);
            let v196_12: Space = if (&(v196_10)).is_empty() { Space::new() } else {
              let v198_6: Path = concat_path(&(v195_6),&v187_14_cursor.path()[(v187_14_origin + 2)..(v187_14_origin + 3)]);
              let v198_11: Space = routine_15(c, &(v198_6), &v187_14_cursor);
              drop(v198_6);
              compose(&(v196_10),&(v198_11))
            };
            drop(v196_10);
            let v196_13: Space = unite(&(v196_8),&(v196_12));
            join_wrapped_into(&mut v195_11_write,&((v196_13).read_zipper()),&[]);
            }
            v187_14_cursor.ascend(1);
          }
          drop(v195_11_write);
          drop(v195_6);
          compose(&(v190_10),&(v195_11))
        };
        drop(v190_10);
        let v190_13: Space = unite(&(v190_8),&(v190_12));
        join_wrapped_into(&mut v189_7_write,&((v190_13).read_zipper()),&[]);
        }
        v187_14_cursor.ascend(1);
      }
      drop(v189_7_write);
      drop(v189_6);
      compose(&(v188_5),&(v189_7))
    };
    drop(v188_5);
    let v188_9: Space = intersect(&(*CONSTANT_1),&(v188_2));
    drop(v188_2);
    let v188_10: Space = if has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
    drop(v188_9);
    let v188_11: Space = compose(&(v188_10),&v187_14_cursor);
    drop(v188_10);
    let v188_12: Space = unite(&(v188_8),&(v188_11));
    drop(v188_11);
    join_wrapped_into(&mut v187_14_write,&((v188_12).read_zipper()),&[]);
    }
    v187_14_cursor.ascend(1);
  }
  drop(v187_14_cursor);
  drop(v187_14_write);
  (v187_14).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v199_20 = Space::new();
  let mut v199_20_write = v199_20.write_zipper();
  let mut v199_20_cursor = (*s0).read_zipper();
  let v199_20_origin = v199_20_cursor.path().len();
  for v199_20_byte in v199_20_cursor.child_mask().iter() {
    v199_20_cursor.descend_to_existing_byte(v199_20_byte);
    {
    let v200_2: Space = singleton(&v199_20_cursor.path()[v199_20_origin..(v199_20_origin + 1)]);
    let v200_3: Space = intersect(&(*CONSTANT_1),&(v200_2));
    let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
    drop(v200_3);
    let v200_5: Space = subtract(&(*CONSTANT_0),&(v200_4));
    drop(v200_4);
    let v200_8: Space = if (&(v200_5)).is_empty() { Space::new() } else {
      let v201_6: Path = concat_path(&(*p0),&v199_20_cursor.path()[v199_20_origin..(v199_20_origin + 1)]);
      let mut v201_7 = Space::new();
      let mut v201_7_write = v201_7.write_zipper();
      for v201_7_byte in v199_20_cursor.child_mask().iter() {
        v199_20_cursor.descend_to_existing_byte(v201_7_byte);
        {
        let v202_2: Space = singleton(&v199_20_cursor.path()[(v199_20_origin + 1)..(v199_20_origin + 2)]);
        let v202_3: Space = intersect(&(*CONSTANT_1),&(v202_2));
        let v202_4: Space = if has_head(&(v202_3)) { singleton(&[]) } else { Space::new() };
        drop(v202_3);
        let v202_5: Space = subtract(&(*CONSTANT_0),&(v202_4));
        drop(v202_4);
        let v202_8: Space = if (&(v202_5)).is_empty() { Space::new() } else {
          let v203_6: Path = concat_path(&(v201_6),&v199_20_cursor.path()[(v199_20_origin + 1)..(v199_20_origin + 2)]);
          let mut v203_7 = Space::new();
          let mut v203_7_write = v203_7.write_zipper();
          for v203_7_byte in v199_20_cursor.child_mask().iter() {
            v199_20_cursor.descend_to_existing_byte(v203_7_byte);
            {
            let v204_2: Space = singleton(&v199_20_cursor.path()[(v199_20_origin + 2)..(v199_20_origin + 3)]);
            let v204_3: Space = intersect(&(*CONSTANT_1),&(v204_2));
            let v204_4: Space = if has_head(&(v204_3)) { singleton(&[]) } else { Space::new() };
            drop(v204_3);
            let v204_5: Space = subtract(&(*CONSTANT_0),&(v204_4));
            drop(v204_4);
            let v204_8: Space = if (&(v204_5)).is_empty() { Space::new() } else {
              let v205_6: Path = concat_path(&(v203_6),&v199_20_cursor.path()[(v199_20_origin + 2)..(v199_20_origin + 3)]);
              let v205_7: Space = routine_24(c, &(v205_6), &v199_20_cursor);
              compose(&(v204_5),&(v205_7))
            };
            drop(v204_5);
            let v204_9: Space = intersect(&(*CONSTANT_1),&(v204_2));
            drop(v204_2);
            let v204_10: Space = if has_head(&(v204_9)) { singleton(&[]) } else { Space::new() };
            drop(v204_9);
            let v204_12: Space = if (&(v204_10)).is_empty() { Space::new() } else {
              let v206_6: Path = concat_path(&(v203_6),&v199_20_cursor.path()[(v199_20_origin + 2)..(v199_20_origin + 3)]);
              let v206_11: Space = routine_25(c, &(v206_6), &v199_20_cursor);
              drop(v206_6);
              compose(&(v204_10),&(v206_11))
            };
            drop(v204_10);
            let v204_13: Space = unite(&(v204_8),&(v204_12));
            join_wrapped_into(&mut v203_7_write,&((v204_13).read_zipper()),&[]);
            }
            v199_20_cursor.ascend(1);
          }
          drop(v203_7_write);
          compose(&(v202_5),&(v203_7))
        };
        drop(v202_5);
        let v202_9: Space = intersect(&(*CONSTANT_1),&(v202_2));
        drop(v202_2);
        let v202_10: Space = if has_head(&(v202_9)) { singleton(&[]) } else { Space::new() };
        drop(v202_9);
        let v202_12: Space = if (&(v202_10)).is_empty() { Space::new() } else {
          let v207_6: Path = concat_path(&(v201_6),&v199_20_cursor.path()[(v199_20_origin + 1)..(v199_20_origin + 2)]);
          let mut v207_11 = Space::new();
          let mut v207_11_write = v207_11.write_zipper();
          for v207_11_byte in v199_20_cursor.child_mask().iter() {
            v199_20_cursor.descend_to_existing_byte(v207_11_byte);
            {
            let v208_2: Space = singleton(&v199_20_cursor.path()[(v199_20_origin + 2)..(v199_20_origin + 3)]);
            let v208_3: Space = intersect(&(*CONSTANT_1),&(v208_2));
            let v208_4: Space = if has_head(&(v208_3)) { singleton(&[]) } else { Space::new() };
            drop(v208_3);
            let v208_5: Space = subtract(&(*CONSTANT_0),&(v208_4));
            drop(v208_4);
            let v208_8: Space = if (&(v208_5)).is_empty() { Space::new() } else {
              let v209_6: Path = concat_path(&(v207_6),&v199_20_cursor.path()[(v199_20_origin + 2)..(v199_20_origin + 3)]);
              let v209_7: Space = routine_24(c, &(v209_6), &v199_20_cursor);
              compose(&(v208_5),&(v209_7))
            };
            drop(v208_5);
            let v208_9: Space = intersect(&(*CONSTANT_1),&(v208_2));
            drop(v208_2);
            let v208_10: Space = if has_head(&(v208_9)) { singleton(&[]) } else { Space::new() };
            drop(v208_9);
            let v208_12: Space = if (&(v208_10)).is_empty() { Space::new() } else {
              let v210_6: Path = concat_path(&(v207_6),&v199_20_cursor.path()[(v199_20_origin + 2)..(v199_20_origin + 3)]);
              let v210_11: Space = routine_12(c, &(v210_6), &v199_20_cursor);
              drop(v210_6);
              compose(&(v208_10),&(v210_11))
            };
            drop(v208_10);
            let v208_13: Space = unite(&(v208_8),&(v208_12));
            join_wrapped_into(&mut v207_11_write,&((v208_13).read_zipper()),&[]);
            }
            v199_20_cursor.ascend(1);
          }
          drop(v207_11_write);
          drop(v207_6);
          compose(&(v202_10),&(v207_11))
        };
        drop(v202_10);
        let v202_13: Space = unite(&(v202_8),&(v202_12));
        join_wrapped_into(&mut v201_7_write,&((v202_13).read_zipper()),&[]);
        }
        v199_20_cursor.ascend(1);
      }
      drop(v201_7_write);
      compose(&(v200_5),&(v201_7))
    };
    drop(v200_5);
    let v200_9: Space = intersect(&(*CONSTANT_1),&(v200_2));
    drop(v200_2);
    let v200_10: Space = if has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
    drop(v200_9);
    let v200_12: Space = if (&(v200_10)).is_empty() { Space::new() } else {
      let v211_6: Path = concat_path(&(*p0),&v199_20_cursor.path()[v199_20_origin..(v199_20_origin + 1)]);
      let mut v211_11 = Space::new();
      let mut v211_11_write = v211_11.write_zipper();
      for v211_11_byte in v199_20_cursor.child_mask().iter() {
        v199_20_cursor.descend_to_existing_byte(v211_11_byte);
        {
        let v212_2: Space = singleton(&v199_20_cursor.path()[(v199_20_origin + 1)..(v199_20_origin + 2)]);
        let v212_3: Space = intersect(&(*CONSTANT_1),&(v212_2));
        let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
        drop(v212_3);
        let v212_5: Space = subtract(&(*CONSTANT_0),&(v212_4));
        drop(v212_4);
        let v212_8: Space = if (&(v212_5)).is_empty() { Space::new() } else {
          let v213_6: Path = concat_path(&(v211_6),&v199_20_cursor.path()[(v199_20_origin + 1)..(v199_20_origin + 2)]);
          let mut v213_7 = Space::new();
          let mut v213_7_write = v213_7.write_zipper();
          for v213_7_byte in v199_20_cursor.child_mask().iter() {
            v199_20_cursor.descend_to_existing_byte(v213_7_byte);
            {
            let v214_2: Space = singleton(&v199_20_cursor.path()[(v199_20_origin + 2)..(v199_20_origin + 3)]);
            let v214_3: Space = intersect(&(*CONSTANT_1),&(v214_2));
            let v214_4: Space = if has_head(&(v214_3)) { singleton(&[]) } else { Space::new() };
            drop(v214_3);
            let v214_5: Space = subtract(&(*CONSTANT_0),&(v214_4));
            drop(v214_4);
            let v214_8: Space = if (&(v214_5)).is_empty() { Space::new() } else {
              let v215_6: Path = concat_path(&(v213_6),&v199_20_cursor.path()[(v199_20_origin + 2)..(v199_20_origin + 3)]);
              let v215_7: Space = routine_24(c, &(v215_6), &v199_20_cursor);
              compose(&(v214_5),&(v215_7))
            };
            drop(v214_5);
            let v214_9: Space = intersect(&(*CONSTANT_1),&(v214_2));
            drop(v214_2);
            let v214_10: Space = if has_head(&(v214_9)) { singleton(&[]) } else { Space::new() };
            drop(v214_9);
            let v214_12: Space = if (&(v214_10)).is_empty() { Space::new() } else {
              let v216_6: Path = concat_path(&(v213_6),&v199_20_cursor.path()[(v199_20_origin + 2)..(v199_20_origin + 3)]);
              let v216_11: Space = routine_25(c, &(v216_6), &v199_20_cursor);
              drop(v216_6);
              compose(&(v214_10),&(v216_11))
            };
            drop(v214_10);
            let v214_13: Space = unite(&(v214_8),&(v214_12));
            join_wrapped_into(&mut v213_7_write,&((v214_13).read_zipper()),&[]);
            }
            v199_20_cursor.ascend(1);
          }
          drop(v213_7_write);
          drop(v213_6);
          compose(&(v212_5),&(v213_7))
        };
        drop(v212_5);
        let v212_9: Space = intersect(&(*CONSTANT_1),&(v212_2));
        drop(v212_2);
        let v212_10: Space = if has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
        drop(v212_9);
        let v212_11: Space = compose(&(v212_10),&v199_20_cursor);
        drop(v212_10);
        let v212_12: Space = unite(&(v212_8),&(v212_11));
        drop(v212_11);
        join_wrapped_into(&mut v211_11_write,&((v212_12).read_zipper()),&[]);
        }
        v199_20_cursor.ascend(1);
      }
      drop(v211_11_write);
      drop(v211_6);
      compose(&(v200_10),&(v211_11))
    };
    drop(v200_10);
    let v200_13: Space = unite(&(v200_8),&(v200_12));
    join_wrapped_into(&mut v199_20_write,&((v200_13).read_zipper()),&[]);
    }
    v199_20_cursor.ascend(1);
  }
  drop(v199_20_cursor);
  drop(v199_20_write);
  (v199_20).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v217_14 = Space::new();
  let mut v217_14_write = v217_14.write_zipper();
  let mut v217_14_cursor = (*s0).read_zipper();
  let v217_14_origin = v217_14_cursor.path().len();
  for v217_14_byte in v217_14_cursor.child_mask().iter() {
    v217_14_cursor.descend_to_existing_byte(v217_14_byte);
    {
    let v218_2: Space = singleton(&v217_14_cursor.path()[v217_14_origin..(v217_14_origin + 1)]);
    let v218_3: Space = intersect(&(*CONSTANT_1),&(v218_2));
    let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
    drop(v218_3);
    let v218_5: Space = subtract(&(*CONSTANT_0),&(v218_4));
    drop(v218_4);
    let v218_8: Space = if (&(v218_5)).is_empty() { Space::new() } else {
      let v219_6: Path = concat_path(&(*p0),&v217_14_cursor.path()[v217_14_origin..(v217_14_origin + 1)]);
      let mut v219_7 = Space::new();
      let mut v219_7_write = v219_7.write_zipper();
      for v219_7_byte in v217_14_cursor.child_mask().iter() {
        v217_14_cursor.descend_to_existing_byte(v219_7_byte);
        {
        let v220_2: Space = singleton(&v217_14_cursor.path()[(v217_14_origin + 1)..(v217_14_origin + 2)]);
        let v220_3: Space = intersect(&(*CONSTANT_1),&(v220_2));
        let v220_4: Space = if has_head(&(v220_3)) { singleton(&[]) } else { Space::new() };
        drop(v220_3);
        let v220_5: Space = subtract(&(*CONSTANT_0),&(v220_4));
        drop(v220_4);
        let v220_8: Space = if (&(v220_5)).is_empty() { Space::new() } else {
          let v221_6: Path = concat_path(&(v219_6),&v217_14_cursor.path()[(v217_14_origin + 1)..(v217_14_origin + 2)]);
          let mut v221_7 = Space::new();
          let mut v221_7_write = v221_7.write_zipper();
          for v221_7_byte in v217_14_cursor.child_mask().iter() {
            v217_14_cursor.descend_to_existing_byte(v221_7_byte);
            {
            let v222_2: Space = singleton(&v217_14_cursor.path()[(v217_14_origin + 2)..(v217_14_origin + 3)]);
            let v222_3: Space = intersect(&(*CONSTANT_1),&(v222_2));
            let v222_4: Space = if has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
            drop(v222_3);
            let v222_5: Space = subtract(&(*CONSTANT_0),&(v222_4));
            drop(v222_4);
            let v222_8: Space = if (&(v222_5)).is_empty() { Space::new() } else {
              let v223_6: Path = concat_path(&(v221_6),&v217_14_cursor.path()[(v217_14_origin + 2)..(v217_14_origin + 3)]);
              let v223_7: Space = routine_24(c, &(v223_6), &v217_14_cursor);
              compose(&(v222_5),&(v223_7))
            };
            drop(v222_5);
            let v222_9: Space = intersect(&(*CONSTANT_1),&(v222_2));
            drop(v222_2);
            let v222_10: Space = if has_head(&(v222_9)) { singleton(&[]) } else { Space::new() };
            drop(v222_9);
            let v222_12: Space = if (&(v222_10)).is_empty() { Space::new() } else {
              let v224_6: Path = concat_path(&(v221_6),&v217_14_cursor.path()[(v217_14_origin + 2)..(v217_14_origin + 3)]);
              let v224_11: Space = routine_25(c, &(v224_6), &v217_14_cursor);
              drop(v224_6);
              compose(&(v222_10),&(v224_11))
            };
            drop(v222_10);
            let v222_13: Space = unite(&(v222_8),&(v222_12));
            join_wrapped_into(&mut v221_7_write,&((v222_13).read_zipper()),&[]);
            }
            v217_14_cursor.ascend(1);
          }
          drop(v221_7_write);
          compose(&(v220_5),&(v221_7))
        };
        drop(v220_5);
        let v220_9: Space = intersect(&(*CONSTANT_1),&(v220_2));
        drop(v220_2);
        let v220_10: Space = if has_head(&(v220_9)) { singleton(&[]) } else { Space::new() };
        drop(v220_9);
        let v220_12: Space = if (&(v220_10)).is_empty() { Space::new() } else {
          let v225_6: Path = concat_path(&(v219_6),&v217_14_cursor.path()[(v217_14_origin + 1)..(v217_14_origin + 2)]);
          let mut v225_11 = Space::new();
          let mut v225_11_write = v225_11.write_zipper();
          for v225_11_byte in v217_14_cursor.child_mask().iter() {
            v217_14_cursor.descend_to_existing_byte(v225_11_byte);
            {
            let v226_2: Space = singleton(&v217_14_cursor.path()[(v217_14_origin + 2)..(v217_14_origin + 3)]);
            let v226_3: Space = intersect(&(*CONSTANT_1),&(v226_2));
            let v226_4: Space = if has_head(&(v226_3)) { singleton(&[]) } else { Space::new() };
            drop(v226_3);
            let v226_5: Space = subtract(&(*CONSTANT_0),&(v226_4));
            drop(v226_4);
            let v226_8: Space = if (&(v226_5)).is_empty() { Space::new() } else {
              let v227_6: Path = concat_path(&(v225_6),&v217_14_cursor.path()[(v217_14_origin + 2)..(v217_14_origin + 3)]);
              let v227_7: Space = routine_24(c, &(v227_6), &v217_14_cursor);
              compose(&(v226_5),&(v227_7))
            };
            drop(v226_5);
            let v226_9: Space = intersect(&(*CONSTANT_1),&(v226_2));
            drop(v226_2);
            let v226_10: Space = if has_head(&(v226_9)) { singleton(&[]) } else { Space::new() };
            drop(v226_9);
            let v226_12: Space = if (&(v226_10)).is_empty() { Space::new() } else {
              let v228_6: Path = concat_path(&(v225_6),&v217_14_cursor.path()[(v217_14_origin + 2)..(v217_14_origin + 3)]);
              let v228_11: Space = routine_12(c, &(v228_6), &v217_14_cursor);
              drop(v228_6);
              compose(&(v226_10),&(v228_11))
            };
            drop(v226_10);
            let v226_13: Space = unite(&(v226_8),&(v226_12));
            join_wrapped_into(&mut v225_11_write,&((v226_13).read_zipper()),&[]);
            }
            v217_14_cursor.ascend(1);
          }
          drop(v225_11_write);
          drop(v225_6);
          compose(&(v220_10),&(v225_11))
        };
        drop(v220_10);
        let v220_13: Space = unite(&(v220_8),&(v220_12));
        join_wrapped_into(&mut v219_7_write,&((v220_13).read_zipper()),&[]);
        }
        v217_14_cursor.ascend(1);
      }
      drop(v219_7_write);
      drop(v219_6);
      compose(&(v218_5),&(v219_7))
    };
    drop(v218_5);
    let v218_9: Space = intersect(&(*CONSTANT_1),&(v218_2));
    drop(v218_2);
    let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
    drop(v218_9);
    let v218_11: Space = compose(&(v218_10),&v217_14_cursor);
    drop(v218_10);
    let v218_12: Space = unite(&(v218_8),&(v218_11));
    drop(v218_11);
    join_wrapped_into(&mut v217_14_write,&((v218_12).read_zipper()),&[]);
    }
    v217_14_cursor.ascend(1);
  }
  drop(v217_14_cursor);
  drop(v217_14_write);
  (v217_14).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v230_20 = Space::new();
  let mut v230_20_write = v230_20.write_zipper();
  let mut v230_20_cursor = (*s0).read_zipper();
  let v230_20_origin = v230_20_cursor.path().len();
  for v230_20_byte in v230_20_cursor.child_mask().iter() {
    v230_20_cursor.descend_to_existing_byte(v230_20_byte);
    {
    let v231_2: Space = singleton(&v230_20_cursor.path()[v230_20_origin..(v230_20_origin + 1)]);
    let v231_3: Space = intersect(&(*CONSTANT_1),&(v231_2));
    let v231_4: Space = if has_head(&(v231_3)) { singleton(&[]) } else { Space::new() };
    drop(v231_3);
    let v231_5: Space = subtract(&(*CONSTANT_0),&(v231_4));
    drop(v231_4);
    let v231_8: Space = if (&(v231_5)).is_empty() { Space::new() } else {
      let v232_6: Path = concat_path(&(*p0),&v230_20_cursor.path()[v230_20_origin..(v230_20_origin + 1)]);
      let mut v232_7 = Space::new();
      let mut v232_7_write = v232_7.write_zipper();
      for v232_7_byte in v230_20_cursor.child_mask().iter() {
        v230_20_cursor.descend_to_existing_byte(v232_7_byte);
        {
        let v233_2: Space = singleton(&v230_20_cursor.path()[(v230_20_origin + 1)..(v230_20_origin + 2)]);
        let v233_3: Space = intersect(&(*CONSTANT_1),&(v233_2));
        let v233_4: Space = if has_head(&(v233_3)) { singleton(&[]) } else { Space::new() };
        drop(v233_3);
        let v233_5: Space = subtract(&(*CONSTANT_0),&(v233_4));
        drop(v233_4);
        let v233_8: Space = if (&(v233_5)).is_empty() { Space::new() } else {
          let v234_6: Path = concat_path(&(v232_6),&v230_20_cursor.path()[(v230_20_origin + 1)..(v230_20_origin + 2)]);
          let mut v234_7 = Space::new();
          let mut v234_7_write = v234_7.write_zipper();
          for v234_7_byte in v230_20_cursor.child_mask().iter() {
            v230_20_cursor.descend_to_existing_byte(v234_7_byte);
            {
            let v235_2: Space = singleton(&v230_20_cursor.path()[(v230_20_origin + 2)..(v230_20_origin + 3)]);
            let v235_3: Space = intersect(&(*CONSTANT_1),&(v235_2));
            let v235_4: Space = if has_head(&(v235_3)) { singleton(&[]) } else { Space::new() };
            drop(v235_3);
            let v235_5: Space = subtract(&(*CONSTANT_0),&(v235_4));
            drop(v235_4);
            let v235_8: Space = if (&(v235_5)).is_empty() { Space::new() } else {
              let v236_6: Path = concat_path(&(v234_6),&v230_20_cursor.path()[(v230_20_origin + 2)..(v230_20_origin + 3)]);
              let v236_7: Space = routine_26(c, &(v236_6), &v230_20_cursor);
              compose(&(v235_5),&(v236_7))
            };
            drop(v235_5);
            let v235_9: Space = intersect(&(*CONSTANT_1),&(v235_2));
            drop(v235_2);
            let v235_10: Space = if has_head(&(v235_9)) { singleton(&[]) } else { Space::new() };
            drop(v235_9);
            let v235_12: Space = if (&(v235_10)).is_empty() { Space::new() } else {
              let v237_6: Path = concat_path(&(v234_6),&v230_20_cursor.path()[(v230_20_origin + 2)..(v230_20_origin + 3)]);
              let v237_11: Space = routine_27(c, &(v237_6), &v230_20_cursor);
              drop(v237_6);
              compose(&(v235_10),&(v237_11))
            };
            drop(v235_10);
            let v235_13: Space = unite(&(v235_8),&(v235_12));
            join_wrapped_into(&mut v234_7_write,&((v235_13).read_zipper()),&[]);
            }
            v230_20_cursor.ascend(1);
          }
          drop(v234_7_write);
          compose(&(v233_5),&(v234_7))
        };
        drop(v233_5);
        let v233_9: Space = intersect(&(*CONSTANT_1),&(v233_2));
        drop(v233_2);
        let v233_10: Space = if has_head(&(v233_9)) { singleton(&[]) } else { Space::new() };
        drop(v233_9);
        let v233_12: Space = if (&(v233_10)).is_empty() { Space::new() } else {
          let v238_6: Path = concat_path(&(v232_6),&v230_20_cursor.path()[(v230_20_origin + 1)..(v230_20_origin + 2)]);
          let mut v238_11 = Space::new();
          let mut v238_11_write = v238_11.write_zipper();
          for v238_11_byte in v230_20_cursor.child_mask().iter() {
            v230_20_cursor.descend_to_existing_byte(v238_11_byte);
            {
            let v239_2: Space = singleton(&v230_20_cursor.path()[(v230_20_origin + 2)..(v230_20_origin + 3)]);
            let v239_3: Space = intersect(&(*CONSTANT_1),&(v239_2));
            let v239_4: Space = if has_head(&(v239_3)) { singleton(&[]) } else { Space::new() };
            drop(v239_3);
            let v239_5: Space = subtract(&(*CONSTANT_0),&(v239_4));
            drop(v239_4);
            let v239_8: Space = if (&(v239_5)).is_empty() { Space::new() } else {
              let v240_6: Path = concat_path(&(v238_6),&v230_20_cursor.path()[(v230_20_origin + 2)..(v230_20_origin + 3)]);
              let v240_7: Space = routine_26(c, &(v240_6), &v230_20_cursor);
              compose(&(v239_5),&(v240_7))
            };
            drop(v239_5);
            let v239_9: Space = intersect(&(*CONSTANT_1),&(v239_2));
            drop(v239_2);
            let v239_10: Space = if has_head(&(v239_9)) { singleton(&[]) } else { Space::new() };
            drop(v239_9);
            let v239_12: Space = if (&(v239_10)).is_empty() { Space::new() } else {
              let v241_6: Path = concat_path(&(v238_6),&v230_20_cursor.path()[(v230_20_origin + 2)..(v230_20_origin + 3)]);
              let v241_11: Space = routine_15(c, &(v241_6), &v230_20_cursor);
              drop(v241_6);
              compose(&(v239_10),&(v241_11))
            };
            drop(v239_10);
            let v239_13: Space = unite(&(v239_8),&(v239_12));
            join_wrapped_into(&mut v238_11_write,&((v239_13).read_zipper()),&[]);
            }
            v230_20_cursor.ascend(1);
          }
          drop(v238_11_write);
          drop(v238_6);
          compose(&(v233_10),&(v238_11))
        };
        drop(v233_10);
        let v233_13: Space = unite(&(v233_8),&(v233_12));
        join_wrapped_into(&mut v232_7_write,&((v233_13).read_zipper()),&[]);
        }
        v230_20_cursor.ascend(1);
      }
      drop(v232_7_write);
      compose(&(v231_5),&(v232_7))
    };
    drop(v231_5);
    let v231_9: Space = intersect(&(*CONSTANT_1),&(v231_2));
    drop(v231_2);
    let v231_10: Space = if has_head(&(v231_9)) { singleton(&[]) } else { Space::new() };
    drop(v231_9);
    let v231_12: Space = if (&(v231_10)).is_empty() { Space::new() } else {
      let v242_6: Path = concat_path(&(*p0),&v230_20_cursor.path()[v230_20_origin..(v230_20_origin + 1)]);
      let mut v242_11 = Space::new();
      let mut v242_11_write = v242_11.write_zipper();
      for v242_11_byte in v230_20_cursor.child_mask().iter() {
        v230_20_cursor.descend_to_existing_byte(v242_11_byte);
        {
        let v243_2: Space = singleton(&v230_20_cursor.path()[(v230_20_origin + 1)..(v230_20_origin + 2)]);
        let v243_3: Space = intersect(&(*CONSTANT_1),&(v243_2));
        let v243_4: Space = if has_head(&(v243_3)) { singleton(&[]) } else { Space::new() };
        drop(v243_3);
        let v243_5: Space = subtract(&(*CONSTANT_0),&(v243_4));
        drop(v243_4);
        let v243_8: Space = if (&(v243_5)).is_empty() { Space::new() } else {
          let v244_6: Path = concat_path(&(v242_6),&v230_20_cursor.path()[(v230_20_origin + 1)..(v230_20_origin + 2)]);
          let mut v244_7 = Space::new();
          let mut v244_7_write = v244_7.write_zipper();
          for v244_7_byte in v230_20_cursor.child_mask().iter() {
            v230_20_cursor.descend_to_existing_byte(v244_7_byte);
            {
            let v245_2: Space = singleton(&v230_20_cursor.path()[(v230_20_origin + 2)..(v230_20_origin + 3)]);
            let v245_3: Space = intersect(&(*CONSTANT_1),&(v245_2));
            let v245_4: Space = if has_head(&(v245_3)) { singleton(&[]) } else { Space::new() };
            drop(v245_3);
            let v245_5: Space = subtract(&(*CONSTANT_0),&(v245_4));
            drop(v245_4);
            let v245_8: Space = if (&(v245_5)).is_empty() { Space::new() } else {
              let v246_6: Path = concat_path(&(v244_6),&v230_20_cursor.path()[(v230_20_origin + 2)..(v230_20_origin + 3)]);
              let v246_7: Space = routine_26(c, &(v246_6), &v230_20_cursor);
              compose(&(v245_5),&(v246_7))
            };
            drop(v245_5);
            let v245_9: Space = intersect(&(*CONSTANT_1),&(v245_2));
            drop(v245_2);
            let v245_10: Space = if has_head(&(v245_9)) { singleton(&[]) } else { Space::new() };
            drop(v245_9);
            let v245_12: Space = if (&(v245_10)).is_empty() { Space::new() } else {
              let v247_6: Path = concat_path(&(v244_6),&v230_20_cursor.path()[(v230_20_origin + 2)..(v230_20_origin + 3)]);
              let v247_11: Space = routine_27(c, &(v247_6), &v230_20_cursor);
              drop(v247_6);
              compose(&(v245_10),&(v247_11))
            };
            drop(v245_10);
            let v245_13: Space = unite(&(v245_8),&(v245_12));
            join_wrapped_into(&mut v244_7_write,&((v245_13).read_zipper()),&[]);
            }
            v230_20_cursor.ascend(1);
          }
          drop(v244_7_write);
          drop(v244_6);
          compose(&(v243_5),&(v244_7))
        };
        drop(v243_5);
        let v243_9: Space = intersect(&(*CONSTANT_1),&(v243_2));
        drop(v243_2);
        let v243_10: Space = if has_head(&(v243_9)) { singleton(&[]) } else { Space::new() };
        drop(v243_9);
        let v243_11: Space = compose(&(v243_10),&v230_20_cursor);
        drop(v243_10);
        let v243_12: Space = unite(&(v243_8),&(v243_11));
        drop(v243_11);
        join_wrapped_into(&mut v242_11_write,&((v243_12).read_zipper()),&[]);
        }
        v230_20_cursor.ascend(1);
      }
      drop(v242_11_write);
      drop(v242_6);
      compose(&(v231_10),&(v242_11))
    };
    drop(v231_10);
    let v231_13: Space = unite(&(v231_8),&(v231_12));
    join_wrapped_into(&mut v230_20_write,&((v231_13).read_zipper()),&[]);
    }
    v230_20_cursor.ascend(1);
  }
  drop(v230_20_cursor);
  drop(v230_20_write);
  (v230_20).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v248_14 = Space::new();
  let mut v248_14_write = v248_14.write_zipper();
  let mut v248_14_cursor = (*s0).read_zipper();
  let v248_14_origin = v248_14_cursor.path().len();
  for v248_14_byte in v248_14_cursor.child_mask().iter() {
    v248_14_cursor.descend_to_existing_byte(v248_14_byte);
    {
    let v249_2: Space = singleton(&v248_14_cursor.path()[v248_14_origin..(v248_14_origin + 1)]);
    let v249_3: Space = intersect(&(*CONSTANT_1),&(v249_2));
    let v249_4: Space = if has_head(&(v249_3)) { singleton(&[]) } else { Space::new() };
    drop(v249_3);
    let v249_5: Space = subtract(&(*CONSTANT_0),&(v249_4));
    drop(v249_4);
    let v249_8: Space = if (&(v249_5)).is_empty() { Space::new() } else {
      let v250_6: Path = concat_path(&(*p0),&v248_14_cursor.path()[v248_14_origin..(v248_14_origin + 1)]);
      let mut v250_7 = Space::new();
      let mut v250_7_write = v250_7.write_zipper();
      for v250_7_byte in v248_14_cursor.child_mask().iter() {
        v248_14_cursor.descend_to_existing_byte(v250_7_byte);
        {
        let v251_2: Space = singleton(&v248_14_cursor.path()[(v248_14_origin + 1)..(v248_14_origin + 2)]);
        let v251_3: Space = intersect(&(*CONSTANT_1),&(v251_2));
        let v251_4: Space = if has_head(&(v251_3)) { singleton(&[]) } else { Space::new() };
        drop(v251_3);
        let v251_5: Space = subtract(&(*CONSTANT_0),&(v251_4));
        drop(v251_4);
        let v251_8: Space = if (&(v251_5)).is_empty() { Space::new() } else {
          let v252_6: Path = concat_path(&(v250_6),&v248_14_cursor.path()[(v248_14_origin + 1)..(v248_14_origin + 2)]);
          let mut v252_7 = Space::new();
          let mut v252_7_write = v252_7.write_zipper();
          for v252_7_byte in v248_14_cursor.child_mask().iter() {
            v248_14_cursor.descend_to_existing_byte(v252_7_byte);
            {
            let v253_2: Space = singleton(&v248_14_cursor.path()[(v248_14_origin + 2)..(v248_14_origin + 3)]);
            let v253_3: Space = intersect(&(*CONSTANT_1),&(v253_2));
            let v253_4: Space = if has_head(&(v253_3)) { singleton(&[]) } else { Space::new() };
            drop(v253_3);
            let v253_5: Space = subtract(&(*CONSTANT_0),&(v253_4));
            drop(v253_4);
            let v253_8: Space = if (&(v253_5)).is_empty() { Space::new() } else {
              let v254_6: Path = concat_path(&(v252_6),&v248_14_cursor.path()[(v248_14_origin + 2)..(v248_14_origin + 3)]);
              let v254_7: Space = routine_26(c, &(v254_6), &v248_14_cursor);
              compose(&(v253_5),&(v254_7))
            };
            drop(v253_5);
            let v253_9: Space = intersect(&(*CONSTANT_1),&(v253_2));
            drop(v253_2);
            let v253_10: Space = if has_head(&(v253_9)) { singleton(&[]) } else { Space::new() };
            drop(v253_9);
            let v253_12: Space = if (&(v253_10)).is_empty() { Space::new() } else {
              let v255_6: Path = concat_path(&(v252_6),&v248_14_cursor.path()[(v248_14_origin + 2)..(v248_14_origin + 3)]);
              let v255_11: Space = routine_27(c, &(v255_6), &v248_14_cursor);
              drop(v255_6);
              compose(&(v253_10),&(v255_11))
            };
            drop(v253_10);
            let v253_13: Space = unite(&(v253_8),&(v253_12));
            join_wrapped_into(&mut v252_7_write,&((v253_13).read_zipper()),&[]);
            }
            v248_14_cursor.ascend(1);
          }
          drop(v252_7_write);
          compose(&(v251_5),&(v252_7))
        };
        drop(v251_5);
        let v251_9: Space = intersect(&(*CONSTANT_1),&(v251_2));
        drop(v251_2);
        let v251_10: Space = if has_head(&(v251_9)) { singleton(&[]) } else { Space::new() };
        drop(v251_9);
        let v251_12: Space = if (&(v251_10)).is_empty() { Space::new() } else {
          let v256_6: Path = concat_path(&(v250_6),&v248_14_cursor.path()[(v248_14_origin + 1)..(v248_14_origin + 2)]);
          let mut v256_11 = Space::new();
          let mut v256_11_write = v256_11.write_zipper();
          for v256_11_byte in v248_14_cursor.child_mask().iter() {
            v248_14_cursor.descend_to_existing_byte(v256_11_byte);
            {
            let v257_2: Space = singleton(&v248_14_cursor.path()[(v248_14_origin + 2)..(v248_14_origin + 3)]);
            let v257_3: Space = intersect(&(*CONSTANT_1),&(v257_2));
            let v257_4: Space = if has_head(&(v257_3)) { singleton(&[]) } else { Space::new() };
            drop(v257_3);
            let v257_5: Space = subtract(&(*CONSTANT_0),&(v257_4));
            drop(v257_4);
            let v257_8: Space = if (&(v257_5)).is_empty() { Space::new() } else {
              let v258_6: Path = concat_path(&(v256_6),&v248_14_cursor.path()[(v248_14_origin + 2)..(v248_14_origin + 3)]);
              let v258_7: Space = routine_26(c, &(v258_6), &v248_14_cursor);
              compose(&(v257_5),&(v258_7))
            };
            drop(v257_5);
            let v257_9: Space = intersect(&(*CONSTANT_1),&(v257_2));
            drop(v257_2);
            let v257_10: Space = if has_head(&(v257_9)) { singleton(&[]) } else { Space::new() };
            drop(v257_9);
            let v257_12: Space = if (&(v257_10)).is_empty() { Space::new() } else {
              let v259_6: Path = concat_path(&(v256_6),&v248_14_cursor.path()[(v248_14_origin + 2)..(v248_14_origin + 3)]);
              let v259_11: Space = routine_15(c, &(v259_6), &v248_14_cursor);
              drop(v259_6);
              compose(&(v257_10),&(v259_11))
            };
            drop(v257_10);
            let v257_13: Space = unite(&(v257_8),&(v257_12));
            join_wrapped_into(&mut v256_11_write,&((v257_13).read_zipper()),&[]);
            }
            v248_14_cursor.ascend(1);
          }
          drop(v256_11_write);
          drop(v256_6);
          compose(&(v251_10),&(v256_11))
        };
        drop(v251_10);
        let v251_13: Space = unite(&(v251_8),&(v251_12));
        join_wrapped_into(&mut v250_7_write,&((v251_13).read_zipper()),&[]);
        }
        v248_14_cursor.ascend(1);
      }
      drop(v250_7_write);
      drop(v250_6);
      compose(&(v249_5),&(v250_7))
    };
    drop(v249_5);
    let v249_9: Space = intersect(&(*CONSTANT_1),&(v249_2));
    drop(v249_2);
    let v249_10: Space = if has_head(&(v249_9)) { singleton(&[]) } else { Space::new() };
    drop(v249_9);
    let v249_11: Space = compose(&(v249_10),&v248_14_cursor);
    drop(v249_10);
    let v249_12: Space = unite(&(v249_8),&(v249_11));
    drop(v249_11);
    join_wrapped_into(&mut v248_14_write,&((v249_12).read_zipper()),&[]);
    }
    v248_14_cursor.ascend(1);
  }
  drop(v248_14_cursor);
  drop(v248_14_write);
  (v248_14).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_16(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v261_20 = Space::new();
  let mut v261_20_write = v261_20.write_zipper();
  let mut v261_20_cursor = (*s0).read_zipper();
  let v261_20_origin = v261_20_cursor.path().len();
  for v261_20_byte in v261_20_cursor.child_mask().iter() {
    v261_20_cursor.descend_to_existing_byte(v261_20_byte);
    {
    let v262_2: Space = singleton(&v261_20_cursor.path()[v261_20_origin..(v261_20_origin + 1)]);
    let v262_3: Space = intersect(&(*CONSTANT_1),&(v262_2));
    let v262_4: Space = if has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
    drop(v262_3);
    let v262_5: Space = subtract(&(*CONSTANT_0),&(v262_4));
    drop(v262_4);
    let v262_8: Space = if (&(v262_5)).is_empty() { Space::new() } else {
      let v263_6: Path = concat_path(&(*p0),&v261_20_cursor.path()[v261_20_origin..(v261_20_origin + 1)]);
      let mut v263_7 = Space::new();
      let mut v263_7_write = v263_7.write_zipper();
      for v263_7_byte in v261_20_cursor.child_mask().iter() {
        v261_20_cursor.descend_to_existing_byte(v263_7_byte);
        {
        let v264_2: Space = singleton(&v261_20_cursor.path()[(v261_20_origin + 1)..(v261_20_origin + 2)]);
        let v264_3: Space = intersect(&(*CONSTANT_1),&(v264_2));
        let v264_4: Space = if has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
        drop(v264_3);
        let v264_5: Space = subtract(&(*CONSTANT_0),&(v264_4));
        drop(v264_4);
        let v264_8: Space = if (&(v264_5)).is_empty() { Space::new() } else {
          let v265_6: Path = concat_path(&(v263_6),&v261_20_cursor.path()[(v261_20_origin + 1)..(v261_20_origin + 2)]);
          let mut v265_7 = Space::new();
          let mut v265_7_write = v265_7.write_zipper();
          for v265_7_byte in v261_20_cursor.child_mask().iter() {
            v261_20_cursor.descend_to_existing_byte(v265_7_byte);
            {
            let v266_2: Space = singleton(&v261_20_cursor.path()[(v261_20_origin + 2)..(v261_20_origin + 3)]);
            let v266_3: Space = intersect(&(*CONSTANT_1),&(v266_2));
            let v266_4: Space = if has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
            drop(v266_3);
            let v266_5: Space = subtract(&(*CONSTANT_0),&(v266_4));
            drop(v266_4);
            let v266_8: Space = if (&(v266_5)).is_empty() { Space::new() } else {
              let v267_6: Path = concat_path(&(v265_6),&v261_20_cursor.path()[(v261_20_origin + 2)..(v261_20_origin + 3)]);
              let v267_7: Space = routine_28(c, &(v267_6), &v261_20_cursor);
              compose(&(v266_5),&(v267_7))
            };
            drop(v266_5);
            let v266_9: Space = intersect(&(*CONSTANT_1),&(v266_2));
            drop(v266_2);
            let v266_10: Space = if has_head(&(v266_9)) { singleton(&[]) } else { Space::new() };
            drop(v266_9);
            let v266_12: Space = if (&(v266_10)).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v265_6),&v261_20_cursor.path()[(v261_20_origin + 2)..(v261_20_origin + 3)]);
              let v268_11: Space = routine_29(c, &(v268_6), &v261_20_cursor);
              drop(v268_6);
              compose(&(v266_10),&(v268_11))
            };
            drop(v266_10);
            let v266_13: Space = unite(&(v266_8),&(v266_12));
            join_wrapped_into(&mut v265_7_write,&((v266_13).read_zipper()),&[]);
            }
            v261_20_cursor.ascend(1);
          }
          drop(v265_7_write);
          compose(&(v264_5),&(v265_7))
        };
        drop(v264_5);
        let v264_9: Space = intersect(&(*CONSTANT_1),&(v264_2));
        drop(v264_2);
        let v264_10: Space = if has_head(&(v264_9)) { singleton(&[]) } else { Space::new() };
        drop(v264_9);
        let v264_12: Space = if (&(v264_10)).is_empty() { Space::new() } else {
          let v269_6: Path = concat_path(&(v263_6),&v261_20_cursor.path()[(v261_20_origin + 1)..(v261_20_origin + 2)]);
          let mut v269_11 = Space::new();
          let mut v269_11_write = v269_11.write_zipper();
          for v269_11_byte in v261_20_cursor.child_mask().iter() {
            v261_20_cursor.descend_to_existing_byte(v269_11_byte);
            {
            let v270_2: Space = singleton(&v261_20_cursor.path()[(v261_20_origin + 2)..(v261_20_origin + 3)]);
            let v270_3: Space = intersect(&(*CONSTANT_1),&(v270_2));
            let v270_4: Space = if has_head(&(v270_3)) { singleton(&[]) } else { Space::new() };
            drop(v270_3);
            let v270_5: Space = subtract(&(*CONSTANT_0),&(v270_4));
            drop(v270_4);
            let v270_8: Space = if (&(v270_5)).is_empty() { Space::new() } else {
              let v271_6: Path = concat_path(&(v269_6),&v261_20_cursor.path()[(v261_20_origin + 2)..(v261_20_origin + 3)]);
              let v271_7: Space = routine_28(c, &(v271_6), &v261_20_cursor);
              compose(&(v270_5),&(v271_7))
            };
            drop(v270_5);
            let v270_9: Space = intersect(&(*CONSTANT_1),&(v270_2));
            drop(v270_2);
            let v270_10: Space = if has_head(&(v270_9)) { singleton(&[]) } else { Space::new() };
            drop(v270_9);
            let v270_12: Space = if (&(v270_10)).is_empty() { Space::new() } else {
              let v272_6: Path = concat_path(&(v269_6),&v261_20_cursor.path()[(v261_20_origin + 2)..(v261_20_origin + 3)]);
              let v272_11: Space = routine_12(c, &(v272_6), &v261_20_cursor);
              drop(v272_6);
              compose(&(v270_10),&(v272_11))
            };
            drop(v270_10);
            let v270_13: Space = unite(&(v270_8),&(v270_12));
            join_wrapped_into(&mut v269_11_write,&((v270_13).read_zipper()),&[]);
            }
            v261_20_cursor.ascend(1);
          }
          drop(v269_11_write);
          drop(v269_6);
          compose(&(v264_10),&(v269_11))
        };
        drop(v264_10);
        let v264_13: Space = unite(&(v264_8),&(v264_12));
        join_wrapped_into(&mut v263_7_write,&((v264_13).read_zipper()),&[]);
        }
        v261_20_cursor.ascend(1);
      }
      drop(v263_7_write);
      compose(&(v262_5),&(v263_7))
    };
    drop(v262_5);
    let v262_9: Space = intersect(&(*CONSTANT_1),&(v262_2));
    drop(v262_2);
    let v262_10: Space = if has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
    drop(v262_9);
    let v262_12: Space = if (&(v262_10)).is_empty() { Space::new() } else {
      let v273_6: Path = concat_path(&(*p0),&v261_20_cursor.path()[v261_20_origin..(v261_20_origin + 1)]);
      let mut v273_11 = Space::new();
      let mut v273_11_write = v273_11.write_zipper();
      for v273_11_byte in v261_20_cursor.child_mask().iter() {
        v261_20_cursor.descend_to_existing_byte(v273_11_byte);
        {
        let v274_2: Space = singleton(&v261_20_cursor.path()[(v261_20_origin + 1)..(v261_20_origin + 2)]);
        let v274_3: Space = intersect(&(*CONSTANT_1),&(v274_2));
        let v274_4: Space = if has_head(&(v274_3)) { singleton(&[]) } else { Space::new() };
        drop(v274_3);
        let v274_5: Space = subtract(&(*CONSTANT_0),&(v274_4));
        drop(v274_4);
        let v274_8: Space = if (&(v274_5)).is_empty() { Space::new() } else {
          let v275_6: Path = concat_path(&(v273_6),&v261_20_cursor.path()[(v261_20_origin + 1)..(v261_20_origin + 2)]);
          let mut v275_7 = Space::new();
          let mut v275_7_write = v275_7.write_zipper();
          for v275_7_byte in v261_20_cursor.child_mask().iter() {
            v261_20_cursor.descend_to_existing_byte(v275_7_byte);
            {
            let v276_2: Space = singleton(&v261_20_cursor.path()[(v261_20_origin + 2)..(v261_20_origin + 3)]);
            let v276_3: Space = intersect(&(*CONSTANT_1),&(v276_2));
            let v276_4: Space = if has_head(&(v276_3)) { singleton(&[]) } else { Space::new() };
            drop(v276_3);
            let v276_5: Space = subtract(&(*CONSTANT_0),&(v276_4));
            drop(v276_4);
            let v276_8: Space = if (&(v276_5)).is_empty() { Space::new() } else {
              let v277_6: Path = concat_path(&(v275_6),&v261_20_cursor.path()[(v261_20_origin + 2)..(v261_20_origin + 3)]);
              let v277_7: Space = routine_28(c, &(v277_6), &v261_20_cursor);
              compose(&(v276_5),&(v277_7))
            };
            drop(v276_5);
            let v276_9: Space = intersect(&(*CONSTANT_1),&(v276_2));
            drop(v276_2);
            let v276_10: Space = if has_head(&(v276_9)) { singleton(&[]) } else { Space::new() };
            drop(v276_9);
            let v276_12: Space = if (&(v276_10)).is_empty() { Space::new() } else {
              let v278_6: Path = concat_path(&(v275_6),&v261_20_cursor.path()[(v261_20_origin + 2)..(v261_20_origin + 3)]);
              let v278_11: Space = routine_29(c, &(v278_6), &v261_20_cursor);
              drop(v278_6);
              compose(&(v276_10),&(v278_11))
            };
            drop(v276_10);
            let v276_13: Space = unite(&(v276_8),&(v276_12));
            join_wrapped_into(&mut v275_7_write,&((v276_13).read_zipper()),&[]);
            }
            v261_20_cursor.ascend(1);
          }
          drop(v275_7_write);
          drop(v275_6);
          compose(&(v274_5),&(v275_7))
        };
        drop(v274_5);
        let v274_9: Space = intersect(&(*CONSTANT_1),&(v274_2));
        drop(v274_2);
        let v274_10: Space = if has_head(&(v274_9)) { singleton(&[]) } else { Space::new() };
        drop(v274_9);
        let v274_11: Space = compose(&(v274_10),&v261_20_cursor);
        drop(v274_10);
        let v274_12: Space = unite(&(v274_8),&(v274_11));
        drop(v274_11);
        join_wrapped_into(&mut v273_11_write,&((v274_12).read_zipper()),&[]);
        }
        v261_20_cursor.ascend(1);
      }
      drop(v273_11_write);
      drop(v273_6);
      compose(&(v262_10),&(v273_11))
    };
    drop(v262_10);
    let v262_13: Space = unite(&(v262_8),&(v262_12));
    join_wrapped_into(&mut v261_20_write,&((v262_13).read_zipper()),&[]);
    }
    v261_20_cursor.ascend(1);
  }
  drop(v261_20_cursor);
  drop(v261_20_write);
  (v261_20).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v279_14 = Space::new();
  let mut v279_14_write = v279_14.write_zipper();
  let mut v279_14_cursor = (*s0).read_zipper();
  let v279_14_origin = v279_14_cursor.path().len();
  for v279_14_byte in v279_14_cursor.child_mask().iter() {
    v279_14_cursor.descend_to_existing_byte(v279_14_byte);
    {
    let v280_2: Space = singleton(&v279_14_cursor.path()[v279_14_origin..(v279_14_origin + 1)]);
    let v280_3: Space = intersect(&(*CONSTANT_1),&(v280_2));
    let v280_4: Space = if has_head(&(v280_3)) { singleton(&[]) } else { Space::new() };
    drop(v280_3);
    let v280_5: Space = subtract(&(*CONSTANT_0),&(v280_4));
    drop(v280_4);
    let v280_8: Space = if (&(v280_5)).is_empty() { Space::new() } else {
      let v281_6: Path = concat_path(&(*p0),&v279_14_cursor.path()[v279_14_origin..(v279_14_origin + 1)]);
      let mut v281_7 = Space::new();
      let mut v281_7_write = v281_7.write_zipper();
      for v281_7_byte in v279_14_cursor.child_mask().iter() {
        v279_14_cursor.descend_to_existing_byte(v281_7_byte);
        {
        let v282_2: Space = singleton(&v279_14_cursor.path()[(v279_14_origin + 1)..(v279_14_origin + 2)]);
        let v282_3: Space = intersect(&(*CONSTANT_1),&(v282_2));
        let v282_4: Space = if has_head(&(v282_3)) { singleton(&[]) } else { Space::new() };
        drop(v282_3);
        let v282_5: Space = subtract(&(*CONSTANT_0),&(v282_4));
        drop(v282_4);
        let v282_8: Space = if (&(v282_5)).is_empty() { Space::new() } else {
          let v283_6: Path = concat_path(&(v281_6),&v279_14_cursor.path()[(v279_14_origin + 1)..(v279_14_origin + 2)]);
          let mut v283_7 = Space::new();
          let mut v283_7_write = v283_7.write_zipper();
          for v283_7_byte in v279_14_cursor.child_mask().iter() {
            v279_14_cursor.descend_to_existing_byte(v283_7_byte);
            {
            let v284_2: Space = singleton(&v279_14_cursor.path()[(v279_14_origin + 2)..(v279_14_origin + 3)]);
            let v284_3: Space = intersect(&(*CONSTANT_1),&(v284_2));
            let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
            drop(v284_3);
            let v284_5: Space = subtract(&(*CONSTANT_0),&(v284_4));
            drop(v284_4);
            let v284_8: Space = if (&(v284_5)).is_empty() { Space::new() } else {
              let v285_6: Path = concat_path(&(v283_6),&v279_14_cursor.path()[(v279_14_origin + 2)..(v279_14_origin + 3)]);
              let v285_7: Space = routine_28(c, &(v285_6), &v279_14_cursor);
              compose(&(v284_5),&(v285_7))
            };
            drop(v284_5);
            let v284_9: Space = intersect(&(*CONSTANT_1),&(v284_2));
            drop(v284_2);
            let v284_10: Space = if has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
            drop(v284_9);
            let v284_12: Space = if (&(v284_10)).is_empty() { Space::new() } else {
              let v286_6: Path = concat_path(&(v283_6),&v279_14_cursor.path()[(v279_14_origin + 2)..(v279_14_origin + 3)]);
              let v286_11: Space = routine_29(c, &(v286_6), &v279_14_cursor);
              drop(v286_6);
              compose(&(v284_10),&(v286_11))
            };
            drop(v284_10);
            let v284_13: Space = unite(&(v284_8),&(v284_12));
            join_wrapped_into(&mut v283_7_write,&((v284_13).read_zipper()),&[]);
            }
            v279_14_cursor.ascend(1);
          }
          drop(v283_7_write);
          compose(&(v282_5),&(v283_7))
        };
        drop(v282_5);
        let v282_9: Space = intersect(&(*CONSTANT_1),&(v282_2));
        drop(v282_2);
        let v282_10: Space = if has_head(&(v282_9)) { singleton(&[]) } else { Space::new() };
        drop(v282_9);
        let v282_12: Space = if (&(v282_10)).is_empty() { Space::new() } else {
          let v287_6: Path = concat_path(&(v281_6),&v279_14_cursor.path()[(v279_14_origin + 1)..(v279_14_origin + 2)]);
          let mut v287_11 = Space::new();
          let mut v287_11_write = v287_11.write_zipper();
          for v287_11_byte in v279_14_cursor.child_mask().iter() {
            v279_14_cursor.descend_to_existing_byte(v287_11_byte);
            {
            let v288_2: Space = singleton(&v279_14_cursor.path()[(v279_14_origin + 2)..(v279_14_origin + 3)]);
            let v288_3: Space = intersect(&(*CONSTANT_1),&(v288_2));
            let v288_4: Space = if has_head(&(v288_3)) { singleton(&[]) } else { Space::new() };
            drop(v288_3);
            let v288_5: Space = subtract(&(*CONSTANT_0),&(v288_4));
            drop(v288_4);
            let v288_8: Space = if (&(v288_5)).is_empty() { Space::new() } else {
              let v289_6: Path = concat_path(&(v287_6),&v279_14_cursor.path()[(v279_14_origin + 2)..(v279_14_origin + 3)]);
              let v289_7: Space = routine_28(c, &(v289_6), &v279_14_cursor);
              compose(&(v288_5),&(v289_7))
            };
            drop(v288_5);
            let v288_9: Space = intersect(&(*CONSTANT_1),&(v288_2));
            drop(v288_2);
            let v288_10: Space = if has_head(&(v288_9)) { singleton(&[]) } else { Space::new() };
            drop(v288_9);
            let v288_12: Space = if (&(v288_10)).is_empty() { Space::new() } else {
              let v290_6: Path = concat_path(&(v287_6),&v279_14_cursor.path()[(v279_14_origin + 2)..(v279_14_origin + 3)]);
              let v290_11: Space = routine_12(c, &(v290_6), &v279_14_cursor);
              drop(v290_6);
              compose(&(v288_10),&(v290_11))
            };
            drop(v288_10);
            let v288_13: Space = unite(&(v288_8),&(v288_12));
            join_wrapped_into(&mut v287_11_write,&((v288_13).read_zipper()),&[]);
            }
            v279_14_cursor.ascend(1);
          }
          drop(v287_11_write);
          drop(v287_6);
          compose(&(v282_10),&(v287_11))
        };
        drop(v282_10);
        let v282_13: Space = unite(&(v282_8),&(v282_12));
        join_wrapped_into(&mut v281_7_write,&((v282_13).read_zipper()),&[]);
        }
        v279_14_cursor.ascend(1);
      }
      drop(v281_7_write);
      drop(v281_6);
      compose(&(v280_5),&(v281_7))
    };
    drop(v280_5);
    let v280_9: Space = intersect(&(*CONSTANT_1),&(v280_2));
    drop(v280_2);
    let v280_10: Space = if has_head(&(v280_9)) { singleton(&[]) } else { Space::new() };
    drop(v280_9);
    let v280_11: Space = compose(&(v280_10),&v279_14_cursor);
    drop(v280_10);
    let v280_12: Space = unite(&(v280_8),&(v280_11));
    drop(v280_11);
    join_wrapped_into(&mut v279_14_write,&((v280_12).read_zipper()),&[]);
    }
    v279_14_cursor.ascend(1);
  }
  drop(v279_14_cursor);
  drop(v279_14_write);
  (v279_14).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v291_20 = Space::new();
  let mut v291_20_write = v291_20.write_zipper();
  let mut v291_20_cursor = (*s0).read_zipper();
  let v291_20_origin = v291_20_cursor.path().len();
  for v291_20_byte in v291_20_cursor.child_mask().iter() {
    v291_20_cursor.descend_to_existing_byte(v291_20_byte);
    {
    let v292_2: Space = singleton(&v291_20_cursor.path()[v291_20_origin..(v291_20_origin + 1)]);
    let v292_3: Space = intersect(&(*CONSTANT_1),&(v292_2));
    let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
    drop(v292_3);
    let v292_5: Space = subtract(&(*CONSTANT_0),&(v292_4));
    drop(v292_4);
    let v292_8: Space = if (&(v292_5)).is_empty() { Space::new() } else {
      let v293_6: Path = concat_path(&(*p0),&v291_20_cursor.path()[v291_20_origin..(v291_20_origin + 1)]);
      let mut v293_7 = Space::new();
      let mut v293_7_write = v293_7.write_zipper();
      for v293_7_byte in v291_20_cursor.child_mask().iter() {
        v291_20_cursor.descend_to_existing_byte(v293_7_byte);
        {
        let v294_2: Space = singleton(&v291_20_cursor.path()[(v291_20_origin + 1)..(v291_20_origin + 2)]);
        let v294_3: Space = intersect(&(*CONSTANT_1),&(v294_2));
        let v294_4: Space = if has_head(&(v294_3)) { singleton(&[]) } else { Space::new() };
        drop(v294_3);
        let v294_5: Space = subtract(&(*CONSTANT_0),&(v294_4));
        drop(v294_4);
        let v294_8: Space = if (&(v294_5)).is_empty() { Space::new() } else {
          let v295_6: Path = concat_path(&(v293_6),&v291_20_cursor.path()[(v291_20_origin + 1)..(v291_20_origin + 2)]);
          let mut v295_7 = Space::new();
          let mut v295_7_write = v295_7.write_zipper();
          for v295_7_byte in v291_20_cursor.child_mask().iter() {
            v291_20_cursor.descend_to_existing_byte(v295_7_byte);
            {
            let v296_2: Space = singleton(&v291_20_cursor.path()[(v291_20_origin + 2)..(v291_20_origin + 3)]);
            let v296_3: Space = intersect(&(*CONSTANT_1),&(v296_2));
            let v296_4: Space = if has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
            drop(v296_3);
            let v296_5: Space = subtract(&(*CONSTANT_0),&(v296_4));
            drop(v296_4);
            let v296_8: Space = if (&(v296_5)).is_empty() { Space::new() } else {
              let v297_6: Path = concat_path(&(v295_6),&v291_20_cursor.path()[(v291_20_origin + 2)..(v291_20_origin + 3)]);
              let v297_7: Space = routine_30(c, &(v297_6), &v291_20_cursor);
              compose(&(v296_5),&(v297_7))
            };
            drop(v296_5);
            let v296_9: Space = intersect(&(*CONSTANT_1),&(v296_2));
            drop(v296_2);
            let v296_10: Space = if has_head(&(v296_9)) { singleton(&[]) } else { Space::new() };
            drop(v296_9);
            let v296_12: Space = if (&(v296_10)).is_empty() { Space::new() } else {
              let v298_6: Path = concat_path(&(v295_6),&v291_20_cursor.path()[(v291_20_origin + 2)..(v291_20_origin + 3)]);
              let v298_11: Space = routine_31(c, &(v298_6), &v291_20_cursor);
              drop(v298_6);
              compose(&(v296_10),&(v298_11))
            };
            drop(v296_10);
            let v296_13: Space = unite(&(v296_8),&(v296_12));
            join_wrapped_into(&mut v295_7_write,&((v296_13).read_zipper()),&[]);
            }
            v291_20_cursor.ascend(1);
          }
          drop(v295_7_write);
          compose(&(v294_5),&(v295_7))
        };
        drop(v294_5);
        let v294_9: Space = intersect(&(*CONSTANT_1),&(v294_2));
        drop(v294_2);
        let v294_10: Space = if has_head(&(v294_9)) { singleton(&[]) } else { Space::new() };
        drop(v294_9);
        let v294_12: Space = if (&(v294_10)).is_empty() { Space::new() } else {
          let v299_6: Path = concat_path(&(v293_6),&v291_20_cursor.path()[(v291_20_origin + 1)..(v291_20_origin + 2)]);
          let mut v299_11 = Space::new();
          let mut v299_11_write = v299_11.write_zipper();
          for v299_11_byte in v291_20_cursor.child_mask().iter() {
            v291_20_cursor.descend_to_existing_byte(v299_11_byte);
            {
            let v300_2: Space = singleton(&v291_20_cursor.path()[(v291_20_origin + 2)..(v291_20_origin + 3)]);
            let v300_3: Space = intersect(&(*CONSTANT_1),&(v300_2));
            let v300_4: Space = if has_head(&(v300_3)) { singleton(&[]) } else { Space::new() };
            drop(v300_3);
            let v300_5: Space = subtract(&(*CONSTANT_0),&(v300_4));
            drop(v300_4);
            let v300_8: Space = if (&(v300_5)).is_empty() { Space::new() } else {
              let v301_6: Path = concat_path(&(v299_6),&v291_20_cursor.path()[(v291_20_origin + 2)..(v291_20_origin + 3)]);
              let v301_7: Space = routine_30(c, &(v301_6), &v291_20_cursor);
              compose(&(v300_5),&(v301_7))
            };
            drop(v300_5);
            let v300_9: Space = intersect(&(*CONSTANT_1),&(v300_2));
            drop(v300_2);
            let v300_10: Space = if has_head(&(v300_9)) { singleton(&[]) } else { Space::new() };
            drop(v300_9);
            let v300_12: Space = if (&(v300_10)).is_empty() { Space::new() } else {
              let v302_6: Path = concat_path(&(v299_6),&v291_20_cursor.path()[(v291_20_origin + 2)..(v291_20_origin + 3)]);
              let v302_11: Space = routine_15(c, &(v302_6), &v291_20_cursor);
              drop(v302_6);
              compose(&(v300_10),&(v302_11))
            };
            drop(v300_10);
            let v300_13: Space = unite(&(v300_8),&(v300_12));
            join_wrapped_into(&mut v299_11_write,&((v300_13).read_zipper()),&[]);
            }
            v291_20_cursor.ascend(1);
          }
          drop(v299_11_write);
          drop(v299_6);
          compose(&(v294_10),&(v299_11))
        };
        drop(v294_10);
        let v294_13: Space = unite(&(v294_8),&(v294_12));
        join_wrapped_into(&mut v293_7_write,&((v294_13).read_zipper()),&[]);
        }
        v291_20_cursor.ascend(1);
      }
      drop(v293_7_write);
      compose(&(v292_5),&(v293_7))
    };
    drop(v292_5);
    let v292_9: Space = intersect(&(*CONSTANT_1),&(v292_2));
    drop(v292_2);
    let v292_10: Space = if has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
    drop(v292_9);
    let v292_12: Space = if (&(v292_10)).is_empty() { Space::new() } else {
      let v303_6: Path = concat_path(&(*p0),&v291_20_cursor.path()[v291_20_origin..(v291_20_origin + 1)]);
      let mut v303_11 = Space::new();
      let mut v303_11_write = v303_11.write_zipper();
      for v303_11_byte in v291_20_cursor.child_mask().iter() {
        v291_20_cursor.descend_to_existing_byte(v303_11_byte);
        {
        let v304_2: Space = singleton(&v291_20_cursor.path()[(v291_20_origin + 1)..(v291_20_origin + 2)]);
        let v304_3: Space = intersect(&(*CONSTANT_1),&(v304_2));
        let v304_4: Space = if has_head(&(v304_3)) { singleton(&[]) } else { Space::new() };
        drop(v304_3);
        let v304_5: Space = subtract(&(*CONSTANT_0),&(v304_4));
        drop(v304_4);
        let v304_8: Space = if (&(v304_5)).is_empty() { Space::new() } else {
          let v305_6: Path = concat_path(&(v303_6),&v291_20_cursor.path()[(v291_20_origin + 1)..(v291_20_origin + 2)]);
          let mut v305_7 = Space::new();
          let mut v305_7_write = v305_7.write_zipper();
          for v305_7_byte in v291_20_cursor.child_mask().iter() {
            v291_20_cursor.descend_to_existing_byte(v305_7_byte);
            {
            let v306_2: Space = singleton(&v291_20_cursor.path()[(v291_20_origin + 2)..(v291_20_origin + 3)]);
            let v306_3: Space = intersect(&(*CONSTANT_1),&(v306_2));
            let v306_4: Space = if has_head(&(v306_3)) { singleton(&[]) } else { Space::new() };
            drop(v306_3);
            let v306_5: Space = subtract(&(*CONSTANT_0),&(v306_4));
            drop(v306_4);
            let v306_8: Space = if (&(v306_5)).is_empty() { Space::new() } else {
              let v307_6: Path = concat_path(&(v305_6),&v291_20_cursor.path()[(v291_20_origin + 2)..(v291_20_origin + 3)]);
              let v307_7: Space = routine_30(c, &(v307_6), &v291_20_cursor);
              compose(&(v306_5),&(v307_7))
            };
            drop(v306_5);
            let v306_9: Space = intersect(&(*CONSTANT_1),&(v306_2));
            drop(v306_2);
            let v306_10: Space = if has_head(&(v306_9)) { singleton(&[]) } else { Space::new() };
            drop(v306_9);
            let v306_12: Space = if (&(v306_10)).is_empty() { Space::new() } else {
              let v308_6: Path = concat_path(&(v305_6),&v291_20_cursor.path()[(v291_20_origin + 2)..(v291_20_origin + 3)]);
              let v308_11: Space = routine_31(c, &(v308_6), &v291_20_cursor);
              drop(v308_6);
              compose(&(v306_10),&(v308_11))
            };
            drop(v306_10);
            let v306_13: Space = unite(&(v306_8),&(v306_12));
            join_wrapped_into(&mut v305_7_write,&((v306_13).read_zipper()),&[]);
            }
            v291_20_cursor.ascend(1);
          }
          drop(v305_7_write);
          drop(v305_6);
          compose(&(v304_5),&(v305_7))
        };
        drop(v304_5);
        let v304_9: Space = intersect(&(*CONSTANT_1),&(v304_2));
        drop(v304_2);
        let v304_10: Space = if has_head(&(v304_9)) { singleton(&[]) } else { Space::new() };
        drop(v304_9);
        let v304_11: Space = compose(&(v304_10),&v291_20_cursor);
        drop(v304_10);
        let v304_12: Space = unite(&(v304_8),&(v304_11));
        drop(v304_11);
        join_wrapped_into(&mut v303_11_write,&((v304_12).read_zipper()),&[]);
        }
        v291_20_cursor.ascend(1);
      }
      drop(v303_11_write);
      drop(v303_6);
      compose(&(v292_10),&(v303_11))
    };
    drop(v292_10);
    let v292_13: Space = unite(&(v292_8),&(v292_12));
    join_wrapped_into(&mut v291_20_write,&((v292_13).read_zipper()),&[]);
    }
    v291_20_cursor.ascend(1);
  }
  drop(v291_20_cursor);
  drop(v291_20_write);
  (v291_20).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v309_14 = Space::new();
  let mut v309_14_write = v309_14.write_zipper();
  let mut v309_14_cursor = (*s0).read_zipper();
  let v309_14_origin = v309_14_cursor.path().len();
  for v309_14_byte in v309_14_cursor.child_mask().iter() {
    v309_14_cursor.descend_to_existing_byte(v309_14_byte);
    {
    let v310_2: Space = singleton(&v309_14_cursor.path()[v309_14_origin..(v309_14_origin + 1)]);
    let v310_3: Space = intersect(&(*CONSTANT_1),&(v310_2));
    let v310_4: Space = if has_head(&(v310_3)) { singleton(&[]) } else { Space::new() };
    drop(v310_3);
    let v310_5: Space = subtract(&(*CONSTANT_0),&(v310_4));
    drop(v310_4);
    let v310_8: Space = if (&(v310_5)).is_empty() { Space::new() } else {
      let v311_6: Path = concat_path(&(*p0),&v309_14_cursor.path()[v309_14_origin..(v309_14_origin + 1)]);
      let mut v311_7 = Space::new();
      let mut v311_7_write = v311_7.write_zipper();
      for v311_7_byte in v309_14_cursor.child_mask().iter() {
        v309_14_cursor.descend_to_existing_byte(v311_7_byte);
        {
        let v312_2: Space = singleton(&v309_14_cursor.path()[(v309_14_origin + 1)..(v309_14_origin + 2)]);
        let v312_3: Space = intersect(&(*CONSTANT_1),&(v312_2));
        let v312_4: Space = if has_head(&(v312_3)) { singleton(&[]) } else { Space::new() };
        drop(v312_3);
        let v312_5: Space = subtract(&(*CONSTANT_0),&(v312_4));
        drop(v312_4);
        let v312_8: Space = if (&(v312_5)).is_empty() { Space::new() } else {
          let v313_6: Path = concat_path(&(v311_6),&v309_14_cursor.path()[(v309_14_origin + 1)..(v309_14_origin + 2)]);
          let mut v313_7 = Space::new();
          let mut v313_7_write = v313_7.write_zipper();
          for v313_7_byte in v309_14_cursor.child_mask().iter() {
            v309_14_cursor.descend_to_existing_byte(v313_7_byte);
            {
            let v314_2: Space = singleton(&v309_14_cursor.path()[(v309_14_origin + 2)..(v309_14_origin + 3)]);
            let v314_3: Space = intersect(&(*CONSTANT_1),&(v314_2));
            let v314_4: Space = if has_head(&(v314_3)) { singleton(&[]) } else { Space::new() };
            drop(v314_3);
            let v314_5: Space = subtract(&(*CONSTANT_0),&(v314_4));
            drop(v314_4);
            let v314_8: Space = if (&(v314_5)).is_empty() { Space::new() } else {
              let v315_6: Path = concat_path(&(v313_6),&v309_14_cursor.path()[(v309_14_origin + 2)..(v309_14_origin + 3)]);
              let v315_7: Space = routine_30(c, &(v315_6), &v309_14_cursor);
              compose(&(v314_5),&(v315_7))
            };
            drop(v314_5);
            let v314_9: Space = intersect(&(*CONSTANT_1),&(v314_2));
            drop(v314_2);
            let v314_10: Space = if has_head(&(v314_9)) { singleton(&[]) } else { Space::new() };
            drop(v314_9);
            let v314_12: Space = if (&(v314_10)).is_empty() { Space::new() } else {
              let v316_6: Path = concat_path(&(v313_6),&v309_14_cursor.path()[(v309_14_origin + 2)..(v309_14_origin + 3)]);
              let v316_11: Space = routine_31(c, &(v316_6), &v309_14_cursor);
              drop(v316_6);
              compose(&(v314_10),&(v316_11))
            };
            drop(v314_10);
            let v314_13: Space = unite(&(v314_8),&(v314_12));
            join_wrapped_into(&mut v313_7_write,&((v314_13).read_zipper()),&[]);
            }
            v309_14_cursor.ascend(1);
          }
          drop(v313_7_write);
          compose(&(v312_5),&(v313_7))
        };
        drop(v312_5);
        let v312_9: Space = intersect(&(*CONSTANT_1),&(v312_2));
        drop(v312_2);
        let v312_10: Space = if has_head(&(v312_9)) { singleton(&[]) } else { Space::new() };
        drop(v312_9);
        let v312_12: Space = if (&(v312_10)).is_empty() { Space::new() } else {
          let v317_6: Path = concat_path(&(v311_6),&v309_14_cursor.path()[(v309_14_origin + 1)..(v309_14_origin + 2)]);
          let mut v317_11 = Space::new();
          let mut v317_11_write = v317_11.write_zipper();
          for v317_11_byte in v309_14_cursor.child_mask().iter() {
            v309_14_cursor.descend_to_existing_byte(v317_11_byte);
            {
            let v318_2: Space = singleton(&v309_14_cursor.path()[(v309_14_origin + 2)..(v309_14_origin + 3)]);
            let v318_3: Space = intersect(&(*CONSTANT_1),&(v318_2));
            let v318_4: Space = if has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
            drop(v318_3);
            let v318_5: Space = subtract(&(*CONSTANT_0),&(v318_4));
            drop(v318_4);
            let v318_8: Space = if (&(v318_5)).is_empty() { Space::new() } else {
              let v319_6: Path = concat_path(&(v317_6),&v309_14_cursor.path()[(v309_14_origin + 2)..(v309_14_origin + 3)]);
              let v319_7: Space = routine_30(c, &(v319_6), &v309_14_cursor);
              compose(&(v318_5),&(v319_7))
            };
            drop(v318_5);
            let v318_9: Space = intersect(&(*CONSTANT_1),&(v318_2));
            drop(v318_2);
            let v318_10: Space = if has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
            drop(v318_9);
            let v318_12: Space = if (&(v318_10)).is_empty() { Space::new() } else {
              let v320_6: Path = concat_path(&(v317_6),&v309_14_cursor.path()[(v309_14_origin + 2)..(v309_14_origin + 3)]);
              let v320_11: Space = routine_15(c, &(v320_6), &v309_14_cursor);
              drop(v320_6);
              compose(&(v318_10),&(v320_11))
            };
            drop(v318_10);
            let v318_13: Space = unite(&(v318_8),&(v318_12));
            join_wrapped_into(&mut v317_11_write,&((v318_13).read_zipper()),&[]);
            }
            v309_14_cursor.ascend(1);
          }
          drop(v317_11_write);
          drop(v317_6);
          compose(&(v312_10),&(v317_11))
        };
        drop(v312_10);
        let v312_13: Space = unite(&(v312_8),&(v312_12));
        join_wrapped_into(&mut v311_7_write,&((v312_13).read_zipper()),&[]);
        }
        v309_14_cursor.ascend(1);
      }
      drop(v311_7_write);
      drop(v311_6);
      compose(&(v310_5),&(v311_7))
    };
    drop(v310_5);
    let v310_9: Space = intersect(&(*CONSTANT_1),&(v310_2));
    drop(v310_2);
    let v310_10: Space = if has_head(&(v310_9)) { singleton(&[]) } else { Space::new() };
    drop(v310_9);
    let v310_11: Space = compose(&(v310_10),&v309_14_cursor);
    drop(v310_10);
    let v310_12: Space = unite(&(v310_8),&(v310_11));
    drop(v310_11);
    join_wrapped_into(&mut v309_14_write,&((v310_12).read_zipper()),&[]);
    }
    v309_14_cursor.ascend(1);
  }
  drop(v309_14_cursor);
  drop(v309_14_write);
  (v309_14).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v321_12 = Space::new();
  let mut v321_12_write = v321_12.write_zipper();
  let mut v321_12_cursor = (*s0).read_zipper();
  let v321_12_origin = v321_12_cursor.path().len();
  for v321_12_byte in v321_12_cursor.child_mask().iter() {
    v321_12_cursor.descend_to_existing_byte(v321_12_byte);
    {
    let v322_2: Space = singleton(&v321_12_cursor.path()[v321_12_origin..(v321_12_origin + 1)]);
    let v322_3: Space = intersect(&(*CONSTANT_1),&(v322_2));
    let v322_4: Space = if has_head(&(v322_3)) { singleton(&[]) } else { Space::new() };
    drop(v322_3);
    let v322_5: Space = subtract(&(*CONSTANT_0),&(v322_4));
    drop(v322_4);
    let v322_8: Space = if (&(v322_5)).is_empty() { Space::new() } else {
      let v323_6: Path = concat_path(&(*p0),&v321_12_cursor.path()[v321_12_origin..(v321_12_origin + 1)]);
      let mut v323_7 = Space::new();
      let mut v323_7_write = v323_7.write_zipper();
      for v323_7_byte in v321_12_cursor.child_mask().iter() {
        v321_12_cursor.descend_to_existing_byte(v323_7_byte);
        {
        let v324_2: Space = singleton(&v321_12_cursor.path()[(v321_12_origin + 1)..(v321_12_origin + 2)]);
        let v324_3: Space = intersect(&(*CONSTANT_1),&(v324_2));
        let v324_4: Space = if has_head(&(v324_3)) { singleton(&[]) } else { Space::new() };
        drop(v324_3);
        let v324_5: Space = subtract(&(*CONSTANT_0),&(v324_4));
        drop(v324_4);
        let v324_7: Space = if (&(v324_5)).is_empty() { Space::new() } else {
          let mut v325_6 = Space::new();
          let mut v325_6_write = v325_6.write_zipper();
          for v325_6_byte in v321_12_cursor.child_mask().iter() {
            v321_12_cursor.descend_to_existing_byte(v325_6_byte);
            {
            let v326_2: Space = Space::new();
            join_wrapped_into(&mut v325_6_write,&((v326_2).read_zipper()),&[]);
            }
            v321_12_cursor.ascend(1);
          }
          drop(v325_6_write);
          compose(&(v324_5),&(v325_6))
        };
        drop(v324_5);
        let v324_8: Space = intersect(&(*CONSTANT_1),&(v324_2));
        drop(v324_2);
        let v324_9: Space = if has_head(&(v324_8)) { singleton(&[]) } else { Space::new() };
        drop(v324_8);
        let v324_12: Space = if (&(v324_9)).is_empty() { Space::new() } else {
          let v327_10: Path = concat_path(&(v323_6),&v321_12_cursor.path()[(v321_12_origin + 1)..(v321_12_origin + 2)]);
          let mut v327_11 = Space::new();
          let mut v327_11_write = v327_11.write_zipper();
          for v327_11_byte in v321_12_cursor.child_mask().iter() {
            v321_12_cursor.descend_to_existing_byte(v327_11_byte);
            {
            let v328_2: Space = singleton(&v321_12_cursor.path()[(v321_12_origin + 2)..(v321_12_origin + 3)]);
            let v328_3: Space = intersect(&(*CONSTANT_1),&(v328_2));
            drop(v328_2);
            let v328_4: Space = if has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
            drop(v328_3);
            let v328_7: Space = if (&(v328_4)).is_empty() { Space::new() } else {
              let v329_5: Path = concat_path(&(v327_10),&v321_12_cursor.path()[(v321_12_origin + 2)..(v321_12_origin + 3)]);
              let v329_6: Space = routine_12(c, &(v329_5), &v321_12_cursor);
              drop(v329_5);
              compose(&(v328_4),&(v329_6))
            };
            drop(v328_4);
            join_wrapped_into(&mut v327_11_write,&((v328_7).read_zipper()),&[]);
            }
            v321_12_cursor.ascend(1);
          }
          drop(v327_11_write);
          drop(v327_10);
          compose(&(v324_9),&(v327_11))
        };
        drop(v324_9);
        let v324_13: Space = unite(&(v324_7),&(v324_12));
        drop(v324_7);
        join_wrapped_into(&mut v323_7_write,&((v324_13).read_zipper()),&[]);
        }
        v321_12_cursor.ascend(1);
      }
      drop(v323_7_write);
      drop(v323_6);
      compose(&(v322_5),&(v323_7))
    };
    drop(v322_5);
    let v322_9: Space = intersect(&(*CONSTANT_1),&(v322_2));
    drop(v322_2);
    let v322_10: Space = if has_head(&(v322_9)) { singleton(&[]) } else { Space::new() };
    drop(v322_9);
    let v322_12: Space = if (&(v322_10)).is_empty() { Space::new() } else {
      let mut v330_11 = Space::new();
      let mut v330_11_write = v330_11.write_zipper();
      for v330_11_byte in v321_12_cursor.child_mask().iter() {
        v321_12_cursor.descend_to_existing_byte(v330_11_byte);
        {
        let v331_2: Space = singleton(&v321_12_cursor.path()[(v321_12_origin + 1)..(v321_12_origin + 2)]);
        let v331_3: Space = intersect(&(*CONSTANT_1),&(v331_2));
        let v331_4: Space = if has_head(&(v331_3)) { singleton(&[]) } else { Space::new() };
        drop(v331_3);
        let v331_5: Space = subtract(&(*CONSTANT_0),&(v331_4));
        drop(v331_4);
        let v331_7: Space = if (&(v331_5)).is_empty() { Space::new() } else {
          let mut v332_6 = Space::new();
          let mut v332_6_write = v332_6.write_zipper();
          for v332_6_byte in v321_12_cursor.child_mask().iter() {
            v321_12_cursor.descend_to_existing_byte(v332_6_byte);
            {
            let v333_2: Space = Space::new();
            join_wrapped_into(&mut v332_6_write,&((v333_2).read_zipper()),&[]);
            }
            v321_12_cursor.ascend(1);
          }
          drop(v332_6_write);
          compose(&(v331_5),&(v332_6))
        };
        drop(v331_5);
        let v331_8: Space = intersect(&(*CONSTANT_1),&(v331_2));
        drop(v331_2);
        let v331_9: Space = if has_head(&(v331_8)) { singleton(&[]) } else { Space::new() };
        drop(v331_8);
        let v331_10: Space = compose(&(v331_9),&v321_12_cursor);
        drop(v331_9);
        let v331_11: Space = unite(&(v331_7),&(v331_10));
        drop(v331_7);
        drop(v331_10);
        join_wrapped_into(&mut v330_11_write,&((v331_11).read_zipper()),&[]);
        }
        v321_12_cursor.ascend(1);
      }
      drop(v330_11_write);
      compose(&(v322_10),&(v330_11))
    };
    drop(v322_10);
    let v322_13: Space = unite(&(v322_8),&(v322_12));
    drop(v322_12);
    join_wrapped_into(&mut v321_12_write,&((v322_13).read_zipper()),&[]);
    }
    v321_12_cursor.ascend(1);
  }
  drop(v321_12_cursor);
  drop(v321_12_write);
  (v321_12).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v334_9 = Space::new();
  let mut v334_9_write = v334_9.write_zipper();
  let mut v334_9_cursor = (*s0).read_zipper();
  let v334_9_origin = v334_9_cursor.path().len();
  for v334_9_byte in v334_9_cursor.child_mask().iter() {
    v334_9_cursor.descend_to_existing_byte(v334_9_byte);
    {
    let v335_2: Space = singleton(&v334_9_cursor.path()[v334_9_origin..(v334_9_origin + 1)]);
    let v335_3: Space = intersect(&(*CONSTANT_1),&(v335_2));
    let v335_4: Space = if has_head(&(v335_3)) { singleton(&[]) } else { Space::new() };
    drop(v335_3);
    let v335_5: Space = subtract(&(*CONSTANT_0),&(v335_4));
    drop(v335_4);
    let v335_8: Space = if (&(v335_5)).is_empty() { Space::new() } else {
      let v336_6: Path = concat_path(&(*p0),&v334_9_cursor.path()[v334_9_origin..(v334_9_origin + 1)]);
      let mut v336_7 = Space::new();
      let mut v336_7_write = v336_7.write_zipper();
      for v336_7_byte in v334_9_cursor.child_mask().iter() {
        v334_9_cursor.descend_to_existing_byte(v336_7_byte);
        {
        let v337_2: Space = singleton(&v334_9_cursor.path()[(v334_9_origin + 1)..(v334_9_origin + 2)]);
        let v337_3: Space = intersect(&(*CONSTANT_1),&(v337_2));
        let v337_4: Space = if has_head(&(v337_3)) { singleton(&[]) } else { Space::new() };
        drop(v337_3);
        let v337_5: Space = subtract(&(*CONSTANT_0),&(v337_4));
        drop(v337_4);
        let v337_7: Space = if (&(v337_5)).is_empty() { Space::new() } else {
          let mut v338_6 = Space::new();
          let mut v338_6_write = v338_6.write_zipper();
          for v338_6_byte in v334_9_cursor.child_mask().iter() {
            v334_9_cursor.descend_to_existing_byte(v338_6_byte);
            {
            let v339_2: Space = Space::new();
            join_wrapped_into(&mut v338_6_write,&((v339_2).read_zipper()),&[]);
            }
            v334_9_cursor.ascend(1);
          }
          drop(v338_6_write);
          compose(&(v337_5),&(v338_6))
        };
        drop(v337_5);
        let v337_8: Space = intersect(&(*CONSTANT_1),&(v337_2));
        drop(v337_2);
        let v337_9: Space = if has_head(&(v337_8)) { singleton(&[]) } else { Space::new() };
        drop(v337_8);
        let v337_12: Space = if (&(v337_9)).is_empty() { Space::new() } else {
          let v340_10: Path = concat_path(&(v336_6),&v334_9_cursor.path()[(v334_9_origin + 1)..(v334_9_origin + 2)]);
          let mut v340_11 = Space::new();
          let mut v340_11_write = v340_11.write_zipper();
          for v340_11_byte in v334_9_cursor.child_mask().iter() {
            v334_9_cursor.descend_to_existing_byte(v340_11_byte);
            {
            let v341_2: Space = singleton(&v334_9_cursor.path()[(v334_9_origin + 2)..(v334_9_origin + 3)]);
            let v341_3: Space = intersect(&(*CONSTANT_1),&(v341_2));
            drop(v341_2);
            let v341_4: Space = if has_head(&(v341_3)) { singleton(&[]) } else { Space::new() };
            drop(v341_3);
            let v341_7: Space = if (&(v341_4)).is_empty() { Space::new() } else {
              let v342_5: Path = concat_path(&(v340_10),&v334_9_cursor.path()[(v334_9_origin + 2)..(v334_9_origin + 3)]);
              let v342_6: Space = routine_12(c, &(v342_5), &v334_9_cursor);
              drop(v342_5);
              compose(&(v341_4),&(v342_6))
            };
            drop(v341_4);
            join_wrapped_into(&mut v340_11_write,&((v341_7).read_zipper()),&[]);
            }
            v334_9_cursor.ascend(1);
          }
          drop(v340_11_write);
          drop(v340_10);
          compose(&(v337_9),&(v340_11))
        };
        drop(v337_9);
        let v337_13: Space = unite(&(v337_7),&(v337_12));
        drop(v337_7);
        join_wrapped_into(&mut v336_7_write,&((v337_13).read_zipper()),&[]);
        }
        v334_9_cursor.ascend(1);
      }
      drop(v336_7_write);
      drop(v336_6);
      compose(&(v335_5),&(v336_7))
    };
    drop(v335_5);
    let v335_9: Space = intersect(&(*CONSTANT_1),&(v335_2));
    drop(v335_2);
    let v335_10: Space = if has_head(&(v335_9)) { singleton(&[]) } else { Space::new() };
    drop(v335_9);
    let v335_11: Space = compose(&(v335_10),&v334_9_cursor);
    drop(v335_10);
    let v335_12: Space = unite(&(v335_8),&(v335_11));
    drop(v335_11);
    join_wrapped_into(&mut v334_9_write,&((v335_12).read_zipper()),&[]);
    }
    v334_9_cursor.ascend(1);
  }
  drop(v334_9_cursor);
  drop(v334_9_write);
  (v334_9).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v343_12 = Space::new();
  let mut v343_12_write = v343_12.write_zipper();
  let mut v343_12_cursor = (*s0).read_zipper();
  let v343_12_origin = v343_12_cursor.path().len();
  for v343_12_byte in v343_12_cursor.child_mask().iter() {
    v343_12_cursor.descend_to_existing_byte(v343_12_byte);
    {
    let v344_2: Space = singleton(&v343_12_cursor.path()[v343_12_origin..(v343_12_origin + 1)]);
    let v344_3: Space = intersect(&(*CONSTANT_1),&(v344_2));
    let v344_4: Space = if has_head(&(v344_3)) { singleton(&[]) } else { Space::new() };
    drop(v344_3);
    let v344_5: Space = subtract(&(*CONSTANT_0),&(v344_4));
    drop(v344_4);
    let v344_8: Space = if (&(v344_5)).is_empty() { Space::new() } else {
      let v345_6: Path = concat_path(&(*p0),&v343_12_cursor.path()[v343_12_origin..(v343_12_origin + 1)]);
      let mut v345_7 = Space::new();
      let mut v345_7_write = v345_7.write_zipper();
      for v345_7_byte in v343_12_cursor.child_mask().iter() {
        v343_12_cursor.descend_to_existing_byte(v345_7_byte);
        {
        let v346_2: Space = singleton(&v343_12_cursor.path()[(v343_12_origin + 1)..(v343_12_origin + 2)]);
        let v346_3: Space = intersect(&(*CONSTANT_1),&(v346_2));
        let v346_4: Space = if has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
        drop(v346_3);
        let v346_5: Space = subtract(&(*CONSTANT_0),&(v346_4));
        drop(v346_4);
        let v346_7: Space = if (&(v346_5)).is_empty() { Space::new() } else {
          let mut v347_6 = Space::new();
          let mut v347_6_write = v347_6.write_zipper();
          for v347_6_byte in v343_12_cursor.child_mask().iter() {
            v343_12_cursor.descend_to_existing_byte(v347_6_byte);
            {
            let v348_2: Space = Space::new();
            join_wrapped_into(&mut v347_6_write,&((v348_2).read_zipper()),&[]);
            }
            v343_12_cursor.ascend(1);
          }
          drop(v347_6_write);
          compose(&(v346_5),&(v347_6))
        };
        drop(v346_5);
        let v346_8: Space = intersect(&(*CONSTANT_1),&(v346_2));
        drop(v346_2);
        let v346_9: Space = if has_head(&(v346_8)) { singleton(&[]) } else { Space::new() };
        drop(v346_8);
        let v346_12: Space = if (&(v346_9)).is_empty() { Space::new() } else {
          let v349_10: Path = concat_path(&(v345_6),&v343_12_cursor.path()[(v343_12_origin + 1)..(v343_12_origin + 2)]);
          let mut v349_11 = Space::new();
          let mut v349_11_write = v349_11.write_zipper();
          for v349_11_byte in v343_12_cursor.child_mask().iter() {
            v343_12_cursor.descend_to_existing_byte(v349_11_byte);
            {
            let v350_2: Space = singleton(&v343_12_cursor.path()[(v343_12_origin + 2)..(v343_12_origin + 3)]);
            let v350_3: Space = intersect(&(*CONSTANT_1),&(v350_2));
            drop(v350_2);
            let v350_4: Space = if has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
            drop(v350_3);
            let v350_7: Space = if (&(v350_4)).is_empty() { Space::new() } else {
              let v351_5: Path = concat_path(&(v349_10),&v343_12_cursor.path()[(v343_12_origin + 2)..(v343_12_origin + 3)]);
              let v351_6: Space = routine_15(c, &(v351_5), &v343_12_cursor);
              drop(v351_5);
              compose(&(v350_4),&(v351_6))
            };
            drop(v350_4);
            join_wrapped_into(&mut v349_11_write,&((v350_7).read_zipper()),&[]);
            }
            v343_12_cursor.ascend(1);
          }
          drop(v349_11_write);
          drop(v349_10);
          compose(&(v346_9),&(v349_11))
        };
        drop(v346_9);
        let v346_13: Space = unite(&(v346_7),&(v346_12));
        drop(v346_7);
        join_wrapped_into(&mut v345_7_write,&((v346_13).read_zipper()),&[]);
        }
        v343_12_cursor.ascend(1);
      }
      drop(v345_7_write);
      drop(v345_6);
      compose(&(v344_5),&(v345_7))
    };
    drop(v344_5);
    let v344_9: Space = intersect(&(*CONSTANT_1),&(v344_2));
    drop(v344_2);
    let v344_10: Space = if has_head(&(v344_9)) { singleton(&[]) } else { Space::new() };
    drop(v344_9);
    let v344_12: Space = if (&(v344_10)).is_empty() { Space::new() } else {
      let mut v352_11 = Space::new();
      let mut v352_11_write = v352_11.write_zipper();
      for v352_11_byte in v343_12_cursor.child_mask().iter() {
        v343_12_cursor.descend_to_existing_byte(v352_11_byte);
        {
        let v353_2: Space = singleton(&v343_12_cursor.path()[(v343_12_origin + 1)..(v343_12_origin + 2)]);
        let v353_3: Space = intersect(&(*CONSTANT_1),&(v353_2));
        let v353_4: Space = if has_head(&(v353_3)) { singleton(&[]) } else { Space::new() };
        drop(v353_3);
        let v353_5: Space = subtract(&(*CONSTANT_0),&(v353_4));
        drop(v353_4);
        let v353_7: Space = if (&(v353_5)).is_empty() { Space::new() } else {
          let mut v354_6 = Space::new();
          let mut v354_6_write = v354_6.write_zipper();
          for v354_6_byte in v343_12_cursor.child_mask().iter() {
            v343_12_cursor.descend_to_existing_byte(v354_6_byte);
            {
            let v355_2: Space = Space::new();
            join_wrapped_into(&mut v354_6_write,&((v355_2).read_zipper()),&[]);
            }
            v343_12_cursor.ascend(1);
          }
          drop(v354_6_write);
          compose(&(v353_5),&(v354_6))
        };
        drop(v353_5);
        let v353_8: Space = intersect(&(*CONSTANT_1),&(v353_2));
        drop(v353_2);
        let v353_9: Space = if has_head(&(v353_8)) { singleton(&[]) } else { Space::new() };
        drop(v353_8);
        let v353_10: Space = compose(&(v353_9),&v343_12_cursor);
        drop(v353_9);
        let v353_11: Space = unite(&(v353_7),&(v353_10));
        drop(v353_7);
        drop(v353_10);
        join_wrapped_into(&mut v352_11_write,&((v353_11).read_zipper()),&[]);
        }
        v343_12_cursor.ascend(1);
      }
      drop(v352_11_write);
      compose(&(v344_10),&(v352_11))
    };
    drop(v344_10);
    let v344_13: Space = unite(&(v344_8),&(v344_12));
    drop(v344_12);
    join_wrapped_into(&mut v343_12_write,&((v344_13).read_zipper()),&[]);
    }
    v343_12_cursor.ascend(1);
  }
  drop(v343_12_cursor);
  drop(v343_12_write);
  (v343_12).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v356_9 = Space::new();
  let mut v356_9_write = v356_9.write_zipper();
  let mut v356_9_cursor = (*s0).read_zipper();
  let v356_9_origin = v356_9_cursor.path().len();
  for v356_9_byte in v356_9_cursor.child_mask().iter() {
    v356_9_cursor.descend_to_existing_byte(v356_9_byte);
    {
    let v357_2: Space = singleton(&v356_9_cursor.path()[v356_9_origin..(v356_9_origin + 1)]);
    let v357_3: Space = intersect(&(*CONSTANT_1),&(v357_2));
    let v357_4: Space = if has_head(&(v357_3)) { singleton(&[]) } else { Space::new() };
    drop(v357_3);
    let v357_5: Space = subtract(&(*CONSTANT_0),&(v357_4));
    drop(v357_4);
    let v357_8: Space = if (&(v357_5)).is_empty() { Space::new() } else {
      let v358_6: Path = concat_path(&(*p0),&v356_9_cursor.path()[v356_9_origin..(v356_9_origin + 1)]);
      let mut v358_7 = Space::new();
      let mut v358_7_write = v358_7.write_zipper();
      for v358_7_byte in v356_9_cursor.child_mask().iter() {
        v356_9_cursor.descend_to_existing_byte(v358_7_byte);
        {
        let v359_2: Space = singleton(&v356_9_cursor.path()[(v356_9_origin + 1)..(v356_9_origin + 2)]);
        let v359_3: Space = intersect(&(*CONSTANT_1),&(v359_2));
        let v359_4: Space = if has_head(&(v359_3)) { singleton(&[]) } else { Space::new() };
        drop(v359_3);
        let v359_5: Space = subtract(&(*CONSTANT_0),&(v359_4));
        drop(v359_4);
        let v359_7: Space = if (&(v359_5)).is_empty() { Space::new() } else {
          let mut v360_6 = Space::new();
          let mut v360_6_write = v360_6.write_zipper();
          for v360_6_byte in v356_9_cursor.child_mask().iter() {
            v356_9_cursor.descend_to_existing_byte(v360_6_byte);
            {
            let v361_2: Space = Space::new();
            join_wrapped_into(&mut v360_6_write,&((v361_2).read_zipper()),&[]);
            }
            v356_9_cursor.ascend(1);
          }
          drop(v360_6_write);
          compose(&(v359_5),&(v360_6))
        };
        drop(v359_5);
        let v359_8: Space = intersect(&(*CONSTANT_1),&(v359_2));
        drop(v359_2);
        let v359_9: Space = if has_head(&(v359_8)) { singleton(&[]) } else { Space::new() };
        drop(v359_8);
        let v359_12: Space = if (&(v359_9)).is_empty() { Space::new() } else {
          let v362_10: Path = concat_path(&(v358_6),&v356_9_cursor.path()[(v356_9_origin + 1)..(v356_9_origin + 2)]);
          let mut v362_11 = Space::new();
          let mut v362_11_write = v362_11.write_zipper();
          for v362_11_byte in v356_9_cursor.child_mask().iter() {
            v356_9_cursor.descend_to_existing_byte(v362_11_byte);
            {
            let v363_2: Space = singleton(&v356_9_cursor.path()[(v356_9_origin + 2)..(v356_9_origin + 3)]);
            let v363_3: Space = intersect(&(*CONSTANT_1),&(v363_2));
            drop(v363_2);
            let v363_4: Space = if has_head(&(v363_3)) { singleton(&[]) } else { Space::new() };
            drop(v363_3);
            let v363_7: Space = if (&(v363_4)).is_empty() { Space::new() } else {
              let v364_5: Path = concat_path(&(v362_10),&v356_9_cursor.path()[(v356_9_origin + 2)..(v356_9_origin + 3)]);
              let v364_6: Space = routine_15(c, &(v364_5), &v356_9_cursor);
              drop(v364_5);
              compose(&(v363_4),&(v364_6))
            };
            drop(v363_4);
            join_wrapped_into(&mut v362_11_write,&((v363_7).read_zipper()),&[]);
            }
            v356_9_cursor.ascend(1);
          }
          drop(v362_11_write);
          drop(v362_10);
          compose(&(v359_9),&(v362_11))
        };
        drop(v359_9);
        let v359_13: Space = unite(&(v359_7),&(v359_12));
        drop(v359_7);
        join_wrapped_into(&mut v358_7_write,&((v359_13).read_zipper()),&[]);
        }
        v356_9_cursor.ascend(1);
      }
      drop(v358_7_write);
      drop(v358_6);
      compose(&(v357_5),&(v358_7))
    };
    drop(v357_5);
    let v357_9: Space = intersect(&(*CONSTANT_1),&(v357_2));
    drop(v357_2);
    let v357_10: Space = if has_head(&(v357_9)) { singleton(&[]) } else { Space::new() };
    drop(v357_9);
    let v357_11: Space = compose(&(v357_10),&v356_9_cursor);
    drop(v357_10);
    let v357_12: Space = unite(&(v357_8),&(v357_11));
    drop(v357_11);
    join_wrapped_into(&mut v356_9_write,&((v357_12).read_zipper()),&[]);
    }
    v356_9_cursor.ascend(1);
  }
  drop(v356_9_cursor);
  drop(v356_9_write);
  (v356_9).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v365_6 = Space::new();
  let mut v365_6_write = v365_6.write_zipper();
  let mut v365_6_cursor = (*s0).read_zipper();
  let v365_6_origin = v365_6_cursor.path().len();
  for v365_6_byte in v365_6_cursor.child_mask().iter() {
    v365_6_cursor.descend_to_existing_byte(v365_6_byte);
    {
    let v366_2: Space = singleton(&v365_6_cursor.path()[v365_6_origin..(v365_6_origin + 1)]);
    let v366_3: Space = intersect(&(*CONSTANT_1),&(v366_2));
    let v366_4: Space = if has_head(&(v366_3)) { singleton(&[]) } else { Space::new() };
    drop(v366_3);
    let v366_5: Space = subtract(&(*CONSTANT_0),&(v366_4));
    drop(v366_4);
    let v366_7: Space = if (&(v366_5)).is_empty() { Space::new() } else {
      let mut v367_6 = Space::new();
      let mut v367_6_write = v367_6.write_zipper();
      for v367_6_byte in v365_6_cursor.child_mask().iter() {
        v365_6_cursor.descend_to_existing_byte(v367_6_byte);
        {
        let v368_2: Space = Space::new();
        join_wrapped_into(&mut v367_6_write,&((v368_2).read_zipper()),&[]);
        }
        v365_6_cursor.ascend(1);
      }
      drop(v367_6_write);
      compose(&(v366_5),&(v367_6))
    };
    drop(v366_5);
    let v366_8: Space = intersect(&(*CONSTANT_1),&(v366_2));
    drop(v366_2);
    let v366_9: Space = if has_head(&(v366_8)) { singleton(&[]) } else { Space::new() };
    drop(v366_8);
    let v366_11: Space = if (&(v366_9)).is_empty() { Space::new() } else {
      let mut v369_10 = Space::new();
      let mut v369_10_write = v369_10.write_zipper();
      for v369_10_byte in v365_6_cursor.child_mask().iter() {
        v365_6_cursor.descend_to_existing_byte(v369_10_byte);
        {
        let v370_2: Space = singleton(&v365_6_cursor.path()[(v365_6_origin + 1)..(v365_6_origin + 2)]);
        let v370_3: Space = intersect(&(*CONSTANT_1),&(v370_2));
        drop(v370_2);
        let v370_4: Space = if has_head(&(v370_3)) { singleton(&[]) } else { Space::new() };
        drop(v370_3);
        let v370_5: Space = compose(&(v370_4),&v365_6_cursor);
        drop(v370_4);
        join_wrapped_into(&mut v369_10_write,&((v370_5).read_zipper()),&[]);
        }
        v365_6_cursor.ascend(1);
      }
      drop(v369_10_write);
      compose(&(v366_9),&(v369_10))
    };
    drop(v366_9);
    let v366_12: Space = unite(&(v366_7),&(v366_11));
    drop(v366_7);
    drop(v366_11);
    join_wrapped_into(&mut v365_6_write,&((v366_12).read_zipper()),&[]);
    }
    v365_6_cursor.ascend(1);
  }
  drop(v365_6_cursor);
  drop(v365_6_write);
  (v365_6).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v371_5 = Space::new();
  let mut v371_5_write = v371_5.write_zipper();
  let mut v371_5_cursor = (*s0).read_zipper();
  let v371_5_origin = v371_5_cursor.path().len();
  for v371_5_byte in v371_5_cursor.child_mask().iter() {
    v371_5_cursor.descend_to_existing_byte(v371_5_byte);
    {
    let v372_2: Space = singleton(&v371_5_cursor.path()[v371_5_origin..(v371_5_origin + 1)]);
    let v372_3: Space = intersect(&(*CONSTANT_1),&(v372_2));
    let v372_4: Space = if has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
    drop(v372_3);
    let v372_5: Space = subtract(&(*CONSTANT_0),&(v372_4));
    drop(v372_4);
    let v372_7: Space = if (&(v372_5)).is_empty() { Space::new() } else {
      let mut v373_6 = Space::new();
      let mut v373_6_write = v373_6.write_zipper();
      for v373_6_byte in v371_5_cursor.child_mask().iter() {
        v371_5_cursor.descend_to_existing_byte(v373_6_byte);
        {
        let v374_2: Space = Space::new();
        join_wrapped_into(&mut v373_6_write,&((v374_2).read_zipper()),&[]);
        }
        v371_5_cursor.ascend(1);
      }
      drop(v373_6_write);
      compose(&(v372_5),&(v373_6))
    };
    drop(v372_5);
    let v372_8: Space = intersect(&(*CONSTANT_1),&(v372_2));
    drop(v372_2);
    let v372_9: Space = if has_head(&(v372_8)) { singleton(&[]) } else { Space::new() };
    drop(v372_8);
    let v372_10: Space = compose(&(v372_9),&v371_5_cursor);
    drop(v372_9);
    let v372_11: Space = unite(&(v372_7),&(v372_10));
    drop(v372_7);
    drop(v372_10);
    join_wrapped_into(&mut v371_5_write,&((v372_11).read_zipper()),&[]);
    }
    v371_5_cursor.ascend(1);
  }
  drop(v371_5_cursor);
  drop(v371_5_write);
  (v371_5).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v375_6 = Space::new();
  let mut v375_6_write = v375_6.write_zipper();
  let mut v375_6_cursor = (*s0).read_zipper();
  let v375_6_origin = v375_6_cursor.path().len();
  for v375_6_byte in v375_6_cursor.child_mask().iter() {
    v375_6_cursor.descend_to_existing_byte(v375_6_byte);
    {
    let v376_2: Space = singleton(&v375_6_cursor.path()[v375_6_origin..(v375_6_origin + 1)]);
    let v376_3: Space = intersect(&(*CONSTANT_1),&(v376_2));
    let v376_4: Space = if has_head(&(v376_3)) { singleton(&[]) } else { Space::new() };
    drop(v376_3);
    let v376_5: Space = subtract(&(*CONSTANT_0),&(v376_4));
    drop(v376_4);
    let v376_7: Space = if (&(v376_5)).is_empty() { Space::new() } else {
      let mut v377_6 = Space::new();
      let mut v377_6_write = v377_6.write_zipper();
      for v377_6_byte in v375_6_cursor.child_mask().iter() {
        v375_6_cursor.descend_to_existing_byte(v377_6_byte);
        {
        let v378_2: Space = Space::new();
        join_wrapped_into(&mut v377_6_write,&((v378_2).read_zipper()),&[]);
        }
        v375_6_cursor.ascend(1);
      }
      drop(v377_6_write);
      compose(&(v376_5),&(v377_6))
    };
    drop(v376_5);
    let v376_8: Space = intersect(&(*CONSTANT_1),&(v376_2));
    drop(v376_2);
    let v376_9: Space = if has_head(&(v376_8)) { singleton(&[]) } else { Space::new() };
    drop(v376_8);
    let v376_11: Space = if (&(v376_9)).is_empty() { Space::new() } else {
      let mut v379_10 = Space::new();
      let mut v379_10_write = v379_10.write_zipper();
      for v379_10_byte in v375_6_cursor.child_mask().iter() {
        v375_6_cursor.descend_to_existing_byte(v379_10_byte);
        {
        let v380_2: Space = singleton(&v375_6_cursor.path()[(v375_6_origin + 1)..(v375_6_origin + 2)]);
        let v380_3: Space = intersect(&(*CONSTANT_1),&(v380_2));
        drop(v380_2);
        let v380_4: Space = if has_head(&(v380_3)) { singleton(&[]) } else { Space::new() };
        drop(v380_3);
        let v380_5: Space = compose(&(v380_4),&v375_6_cursor);
        drop(v380_4);
        join_wrapped_into(&mut v379_10_write,&((v380_5).read_zipper()),&[]);
        }
        v375_6_cursor.ascend(1);
      }
      drop(v379_10_write);
      compose(&(v376_9),&(v379_10))
    };
    drop(v376_9);
    let v376_12: Space = unite(&(v376_7),&(v376_11));
    drop(v376_7);
    drop(v376_11);
    join_wrapped_into(&mut v375_6_write,&((v376_12).read_zipper()),&[]);
    }
    v375_6_cursor.ascend(1);
  }
  drop(v375_6_cursor);
  drop(v375_6_write);
  (v375_6).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v381_5 = Space::new();
  let mut v381_5_write = v381_5.write_zipper();
  let mut v381_5_cursor = (*s0).read_zipper();
  let v381_5_origin = v381_5_cursor.path().len();
  for v381_5_byte in v381_5_cursor.child_mask().iter() {
    v381_5_cursor.descend_to_existing_byte(v381_5_byte);
    {
    let v382_2: Space = singleton(&v381_5_cursor.path()[v381_5_origin..(v381_5_origin + 1)]);
    let v382_3: Space = intersect(&(*CONSTANT_1),&(v382_2));
    let v382_4: Space = if has_head(&(v382_3)) { singleton(&[]) } else { Space::new() };
    drop(v382_3);
    let v382_5: Space = subtract(&(*CONSTANT_0),&(v382_4));
    drop(v382_4);
    let v382_7: Space = if (&(v382_5)).is_empty() { Space::new() } else {
      let mut v383_6 = Space::new();
      let mut v383_6_write = v383_6.write_zipper();
      for v383_6_byte in v381_5_cursor.child_mask().iter() {
        v381_5_cursor.descend_to_existing_byte(v383_6_byte);
        {
        let v384_2: Space = Space::new();
        join_wrapped_into(&mut v383_6_write,&((v384_2).read_zipper()),&[]);
        }
        v381_5_cursor.ascend(1);
      }
      drop(v383_6_write);
      compose(&(v382_5),&(v383_6))
    };
    drop(v382_5);
    let v382_8: Space = intersect(&(*CONSTANT_1),&(v382_2));
    drop(v382_2);
    let v382_9: Space = if has_head(&(v382_8)) { singleton(&[]) } else { Space::new() };
    drop(v382_8);
    let v382_10: Space = compose(&(v382_9),&v381_5_cursor);
    drop(v382_9);
    let v382_11: Space = unite(&(v382_7),&(v382_10));
    drop(v382_7);
    drop(v382_10);
    join_wrapped_into(&mut v381_5_write,&((v382_11).read_zipper()),&[]);
    }
    v381_5_cursor.ascend(1);
  }
  drop(v381_5_cursor);
  drop(v381_5_write);
  (v381_5).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v385_2 = Space::new();
  let mut v385_2_write = v385_2.write_zipper();
  let mut v385_2_cursor = (*s0).read_zipper();
  let v385_2_origin = v385_2_cursor.path().len();
  for v385_2_byte in v385_2_cursor.child_mask().iter() {
    v385_2_cursor.descend_to_existing_byte(v385_2_byte);
    {
    let v386_2: Space = Space::new();
    join_wrapped_into(&mut v385_2_write,&((v386_2).read_zipper()),&[]);
    }
    v385_2_cursor.ascend(1);
  }
  drop(v385_2_cursor);
  drop(v385_2_write);
  (v385_2).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v387_3 = Space::new();
  let mut v387_3_write = v387_3.write_zipper();
  let mut v387_3_cursor = (*s0).read_zipper();
  let v387_3_origin = v387_3_cursor.path().len();
  for v387_3_byte in v387_3_cursor.child_mask().iter() {
    v387_3_cursor.descend_to_existing_byte(v387_3_byte);
    {
    let v388_2: Space = singleton(&v387_3_cursor.path()[v387_3_origin..(v387_3_origin + 1)]);
    let v388_3: Space = intersect(&(*CONSTANT_1),&(v388_2));
    drop(v388_2);
    let v388_4: Space = if has_head(&(v388_3)) { singleton(&[]) } else { Space::new() };
    drop(v388_3);
    let v388_5: Space = compose(&(v388_4),&v387_3_cursor);
    drop(v388_4);
    join_wrapped_into(&mut v387_3_write,&((v388_5).read_zipper()),&[]);
    }
    v387_3_cursor.ascend(1);
  }
  drop(v387_3_cursor);
  drop(v387_3_write);
  (v387_3).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v389_2 = Space::new();
  let mut v389_2_write = v389_2.write_zipper();
  let mut v389_2_cursor = (*s0).read_zipper();
  let v389_2_origin = v389_2_cursor.path().len();
  for v389_2_byte in v389_2_cursor.child_mask().iter() {
    v389_2_cursor.descend_to_existing_byte(v389_2_byte);
    {
    let v390_2: Space = Space::new();
    join_wrapped_into(&mut v389_2_write,&((v390_2).read_zipper()),&[]);
    }
    v389_2_cursor.ascend(1);
  }
  drop(v389_2_cursor);
  drop(v389_2_write);
  (v389_2).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v391_3 = Space::new();
  let mut v391_3_write = v391_3.write_zipper();
  let mut v391_3_cursor = (*s0).read_zipper();
  let v391_3_origin = v391_3_cursor.path().len();
  for v391_3_byte in v391_3_cursor.child_mask().iter() {
    v391_3_cursor.descend_to_existing_byte(v391_3_byte);
    {
    let v392_2: Space = singleton(&v391_3_cursor.path()[v391_3_origin..(v391_3_origin + 1)]);
    let v392_3: Space = intersect(&(*CONSTANT_1),&(v392_2));
    drop(v392_2);
    let v392_4: Space = if has_head(&(v392_3)) { singleton(&[]) } else { Space::new() };
    drop(v392_3);
    let v392_5: Space = compose(&(v392_4),&v391_3_cursor);
    drop(v392_4);
    join_wrapped_into(&mut v391_3_write,&((v392_5).read_zipper()),&[]);
    }
    v391_3_cursor.ascend(1);
  }
  drop(v391_3_cursor);
  drop(v391_3_write);
  (v391_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0),e.space(1)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
