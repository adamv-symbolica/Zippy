#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("94 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 1 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 0 0 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 1 0 0 1 1 22 1 1 0 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 22 1 1 0 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 18 1 1 0 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 18 1 1 0 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 22 1 1 0 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 22 1 1 0 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 21 1 1 0 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 16 1 1 0 0 1 1 0 0 0 1 1 0 1 0 1 1 16 1 1 0 0 1 1 0 0 0 1 1 1 0 0 1 1 22 1 1 0 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 22 1 1 0 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 20 1 1 0 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 20 1 1 0 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 19 1 1 0 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 18 1 1 0 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 20 1 1 0 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 18 1 1 0 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 18 1 1 0 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 20 1 1 0 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 20 1 1 0 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 21 1 1 0 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 21 1 1 0 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 19 1 1 0 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 18 1 1 0 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 22 1 1 0 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 20 1 1 0 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 18 1 1 0 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 18 1 1 0 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 22 1 1 0 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 21 1 1 0 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 21 1 1 0 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 18 1 1 0 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 16 1 1 0 0 1 1 1 0 0 1 1 0 1 0 1 1 22 1 1 0 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 22 1 1 0 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 20 1 1 0 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 19 1 1 0 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 19 1 1 0 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 15 1 1 0 0 1 1 1 0 1 1 0 0 0 1 1 15 1 1 0 0 1 1 1 0 1 1 1 0 0 1 1"));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("184 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 0 0 1 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 1 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 0 1 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 1 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 0 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 0 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 0 1 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 0 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 1 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 0 1 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 1 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 1 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 0 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 1 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 0 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 1 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 0 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 1 0 1 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 1 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 0 1 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 0 1 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 0 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 1 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 0 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 0 1 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 0 0 0 1 1 22 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 0 1 0 1 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 0 1 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 1 0 0 1 1 22 1 1 0 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 22 1 1 0 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 18 1 1 0 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 18 1 1 0 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 22 1 1 0 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 22 1 1 0 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 21 1 1 0 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 16 1 1 0 0 1 1 0 0 0 1 1 0 1 0 1 1 16 1 1 0 0 1 1 0 0 0 1 1 1 0 0 1 1 22 1 1 0 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 22 1 1 0 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 20 1 1 0 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 20 1 1 0 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 19 1 1 0 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 18 1 1 0 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 20 1 1 0 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 18 1 1 0 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 18 1 1 0 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 20 1 1 0 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 20 1 1 0 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 21 1 1 0 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 21 1 1 0 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 19 1 1 0 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 18 1 1 0 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 22 1 1 0 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 20 1 1 0 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 18 1 1 0 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 18 1 1 0 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 22 1 1 0 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 21 1 1 0 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 21 1 1 0 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 18 1 1 0 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 16 1 1 0 0 1 1 1 0 0 1 1 0 1 0 1 1 22 1 1 0 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 22 1 1 0 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 20 1 1 0 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 19 1 1 0 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 19 1 1 0 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 15 1 1 0 0 1 1 1 0 1 1 0 0 0 1 1 15 1 1 0 0 1 1 1 0 1 1 1 0 0 1 1 21 1 1 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 21 1 1 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 19 1 1 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 19 1 1 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 17 1 1 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 17 1 1 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 21 1 1 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 21 1 1 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 20 1 1 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 19 1 1 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 15 1 1 0 1 1 0 0 0 1 1 0 1 0 1 1 15 1 1 0 1 1 0 0 0 1 1 1 0 0 1 1 21 1 1 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 21 1 1 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 19 1 1 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 19 1 1 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 18 1 1 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 17 1 1 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 19 1 1 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 19 1 1 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 17 1 1 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 17 1 1 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 19 1 1 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 19 1 1 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 20 1 1 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 20 1 1 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 18 1 1 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 17 1 1 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 21 1 1 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 19 1 1 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 19 1 1 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 17 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 17 1 1 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 19 1 1 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 21 1 1 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 20 1 1 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 20 1 1 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 17 1 1 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 15 1 1 0 1 1 1 0 0 1 1 0 1 0 1 1 21 1 1 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 21 1 1 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 19 1 1 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 19 1 1 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 18 1 1 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 18 1 1 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 14 1 1 0 1 1 1 0 1 1 0 0 0 1 1 14 1 1 0 1 1 1 0 1 1 1 0 0 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,0,1,1]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1,1]));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1,1]));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,0,1,1,0,1,1]));
#[inline(never)]
fn native_block_0(c: &mut Context,capture_0: &View<'_, '_>) -> (Space,Space,Space,Space,) {
  let mut v1_26 = Space::new();
  let mut v1_26_write = v1_26.write_zipper();
  let mut v1_26_cursor = descend_cursor(descend_cursor((*capture_0).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4));
  let v1_26_origin = v1_26_cursor.path().len();
  for v1_26_byte in v1_26_cursor.child_mask().iter() {
    v1_26_cursor.descend_to_existing_byte(v1_26_byte);
    {
    let v2_2: Space = singleton(&v1_26_cursor.path()[v1_26_origin..(v1_26_origin + 1)]);
    let v2_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v2_2));
    let v2_4: Space = if map_kernels::has_head(&(v2_3)) { singleton(&[]) } else { Space::new() };
    drop(v2_3);
    let v2_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v2_4));
    drop(v2_4);
    let v2_7: Space = if (&(v2_5)).is_empty() { Space::new() } else {
      let mut v3_6 = Space::new();
      let mut v3_6_write = v3_6.write_zipper();
      for v3_6_byte in v1_26_cursor.child_mask().iter() {
        v1_26_cursor.descend_to_existing_byte(v3_6_byte);
        {
        let v4_2: Space = singleton(&v1_26_cursor.path()[(v1_26_origin + 1)..(v1_26_origin + 2)]);
        let v4_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v4_2));
        let v4_4: Space = if map_kernels::has_head(&(v4_3)) { singleton(&[]) } else { Space::new() };
        drop(v4_3);
        let v4_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v4_4));
        drop(v4_4);
        let v4_8: Space = if (&(v4_5)).is_empty() { Space::new() } else {
          let mut v5_7 = Space::new();
          let mut v5_7_write = v5_7.write_zipper();
          for v5_7_byte in v1_26_cursor.child_mask().iter() {
            v1_26_cursor.descend_to_existing_byte(v5_7_byte);
            {
            let v6_2: Space = singleton(&v1_26_cursor.path()[(v1_26_origin + 2)..(v1_26_origin + 3)]);
            let v6_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v6_2));
            let v6_4: Space = if map_kernels::has_head(&(v6_3)) { singleton(&[]) } else { Space::new() };
            drop(v6_3);
            let v6_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v6_4));
            drop(v6_4);
            let v6_8: Space = if (&(v6_5)).is_empty() { Space::new() } else {
              let v7_7: Space = routine_2(c, &v1_26_cursor.path()[v1_26_origin..(v1_26_origin + 3)], &v1_26_cursor, &(*capture_0));
              map_map_kernels::compose(&(v6_5),&(v7_7))
            };
            drop(v6_5);
            let v6_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v6_2));
            drop(v6_2);
            let v6_10: Space = if map_kernels::has_head(&(v6_9)) { singleton(&[]) } else { Space::new() };
            drop(v6_9);
            let v6_12: Space = if (&(v6_10)).is_empty() { Space::new() } else {
              let v8_11: Space = routine_3(c, &v1_26_cursor.path()[v1_26_origin..(v1_26_origin + 3)], &v1_26_cursor, &(*capture_0));
              map_map_kernels::compose(&(v6_10),&(v8_11))
            };
            drop(v6_10);
            let v6_13: Space = map_map_kernels::unite(&(v6_8),&(v6_12));
            join_wrapped_into(&mut v5_7_write,&((v6_13).read_zipper()),&[]);
            }
            v1_26_cursor.ascend(1);
          }
          drop(v5_7_write);
          map_map_kernels::compose(&(v4_5),&(v5_7))
        };
        drop(v4_5);
        let v4_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v4_2));
        drop(v4_2);
        let v4_10: Space = if map_kernels::has_head(&(v4_9)) { singleton(&[]) } else { Space::new() };
        drop(v4_9);
        let v4_12: Space = if (&(v4_10)).is_empty() { Space::new() } else {
          let mut v9_11 = Space::new();
          let mut v9_11_write = v9_11.write_zipper();
          for v9_11_byte in v1_26_cursor.child_mask().iter() {
            v1_26_cursor.descend_to_existing_byte(v9_11_byte);
            {
            let v10_2: Space = singleton(&v1_26_cursor.path()[(v1_26_origin + 2)..(v1_26_origin + 3)]);
            let v10_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v10_2));
            let v10_4: Space = if map_kernels::has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
            drop(v10_3);
            let v10_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v10_4));
            drop(v10_4);
            let v10_8: Space = if (&(v10_5)).is_empty() { Space::new() } else {
              let v11_7: Space = routine_2(c, &v1_26_cursor.path()[v1_26_origin..(v1_26_origin + 3)], &v1_26_cursor, &(*capture_0));
              map_map_kernels::compose(&(v10_5),&(v11_7))
            };
            drop(v10_5);
            let v10_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v10_2));
            drop(v10_2);
            let v10_10: Space = if map_kernels::has_head(&(v10_9)) { singleton(&[]) } else { Space::new() };
            drop(v10_9);
            let v10_12: Space = if (&(v10_10)).is_empty() { Space::new() } else {
              let v12_11: Space = routine_4(c, &v1_26_cursor.path()[v1_26_origin..(v1_26_origin + 3)], &v1_26_cursor, &(*capture_0));
              map_map_kernels::compose(&(v10_10),&(v12_11))
            };
            drop(v10_10);
            let v10_13: Space = map_map_kernels::unite(&(v10_8),&(v10_12));
            join_wrapped_into(&mut v9_11_write,&((v10_13).read_zipper()),&[]);
            }
            v1_26_cursor.ascend(1);
          }
          drop(v9_11_write);
          map_map_kernels::compose(&(v4_10),&(v9_11))
        };
        drop(v4_10);
        let v4_13: Space = map_map_kernels::unite(&(v4_8),&(v4_12));
        join_wrapped_into(&mut v3_6_write,&((v4_13).read_zipper()),&[]);
        }
        v1_26_cursor.ascend(1);
      }
      drop(v3_6_write);
      map_map_kernels::compose(&(v2_5),&(v3_6))
    };
    drop(v2_5);
    let v2_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v2_2));
    drop(v2_2);
    let v2_9: Space = if map_kernels::has_head(&(v2_8)) { singleton(&[]) } else { Space::new() };
    drop(v2_8);
    let v2_11: Space = if (&(v2_9)).is_empty() { Space::new() } else {
      let mut v13_10 = Space::new();
      let mut v13_10_write = v13_10.write_zipper();
      for v13_10_byte in v1_26_cursor.child_mask().iter() {
        v1_26_cursor.descend_to_existing_byte(v13_10_byte);
        {
        let v14_2: Space = singleton(&v1_26_cursor.path()[(v1_26_origin + 1)..(v1_26_origin + 2)]);
        let v14_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v14_2));
        let v14_4: Space = if map_kernels::has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
        drop(v14_3);
        let v14_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v14_4));
        drop(v14_4);
        let v14_8: Space = if (&(v14_5)).is_empty() { Space::new() } else {
          let mut v15_7 = Space::new();
          let mut v15_7_write = v15_7.write_zipper();
          for v15_7_byte in v1_26_cursor.child_mask().iter() {
            v1_26_cursor.descend_to_existing_byte(v15_7_byte);
            {
            let v16_2: Space = singleton(&v1_26_cursor.path()[(v1_26_origin + 2)..(v1_26_origin + 3)]);
            let v16_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v16_2));
            let v16_4: Space = if map_kernels::has_head(&(v16_3)) { singleton(&[]) } else { Space::new() };
            drop(v16_3);
            let v16_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v16_4));
            drop(v16_4);
            let v16_8: Space = if (&(v16_5)).is_empty() { Space::new() } else {
              let v17_7: Space = routine_2(c, &v1_26_cursor.path()[v1_26_origin..(v1_26_origin + 3)], &v1_26_cursor, &(*capture_0));
              map_map_kernels::compose(&(v16_5),&(v17_7))
            };
            drop(v16_5);
            let v16_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v16_2));
            drop(v16_2);
            let v16_10: Space = if map_kernels::has_head(&(v16_9)) { singleton(&[]) } else { Space::new() };
            drop(v16_9);
            let v16_12: Space = if (&(v16_10)).is_empty() { Space::new() } else {
              let v18_11: Space = routine_3(c, &v1_26_cursor.path()[v1_26_origin..(v1_26_origin + 3)], &v1_26_cursor, &(*capture_0));
              map_map_kernels::compose(&(v16_10),&(v18_11))
            };
            drop(v16_10);
            let v16_13: Space = map_map_kernels::unite(&(v16_8),&(v16_12));
            join_wrapped_into(&mut v15_7_write,&((v16_13).read_zipper()),&[]);
            }
            v1_26_cursor.ascend(1);
          }
          drop(v15_7_write);
          map_map_kernels::compose(&(v14_5),&(v15_7))
        };
        drop(v14_5);
        let v14_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v14_2));
        drop(v14_2);
        let v14_10: Space = if map_kernels::has_head(&(v14_9)) { singleton(&[]) } else { Space::new() };
        drop(v14_9);
        let v14_12: Space = if (&(v14_10)).is_empty() { Space::new() } else {
          let mut v19_11 = Space::new();
          let mut v19_11_write = v19_11.write_zipper();
          for v19_11_byte in v1_26_cursor.child_mask().iter() {
            v1_26_cursor.descend_to_existing_byte(v19_11_byte);
            {
            let v20_2: Space = singleton(&v1_26_cursor.path()[(v1_26_origin + 2)..(v1_26_origin + 3)]);
            let v20_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v20_2));
            let v20_4: Space = if map_kernels::has_head(&(v20_3)) { singleton(&[]) } else { Space::new() };
            drop(v20_3);
            let v20_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v20_4));
            drop(v20_4);
            let v20_7: Space = if (&(v20_5)).is_empty() { Space::new() } else {
              let v21_6: Space = routine_5(c, &v1_26_cursor.path()[(v1_26_origin + 2)..(v1_26_origin + 3)], &v1_26_cursor, &(*capture_0));
              map_map_kernels::compose(&(v20_5),&(v21_6))
            };
            drop(v20_5);
            let v20_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v20_2));
            drop(v20_2);
            let v20_9: Space = if map_kernels::has_head(&(v20_8)) { singleton(&[]) } else { Space::new() };
            drop(v20_8);
            let v20_11: Space = if (&(v20_9)).is_empty() { Space::new() } else {
              let v22_10: Space = routine_6(c, &v1_26_cursor.path()[(v1_26_origin + 2)..(v1_26_origin + 3)], &v1_26_cursor, &(*capture_0));
              map_map_kernels::compose(&(v20_9),&(v22_10))
            };
            drop(v20_9);
            let v20_12: Space = map_map_kernels::unite(&(v20_7),&(v20_11));
            join_wrapped_into(&mut v19_11_write,&((v20_12).read_zipper()),&[]);
            }
            v1_26_cursor.ascend(1);
          }
          drop(v19_11_write);
          map_map_kernels::compose(&(v14_10),&(v19_11))
        };
        drop(v14_10);
        let v14_13: Space = map_kernels::wrap(&(v14_12),&v1_26_cursor.path()[v1_26_origin..(v1_26_origin + 2)]);
        let v14_14: Space = map_map_kernels::unite(&(v14_8),&(v14_13));
        join_wrapped_into(&mut v13_10_write,&((v14_14).read_zipper()),&[]);
        }
        v1_26_cursor.ascend(1);
      }
      drop(v13_10_write);
      map_map_kernels::compose(&(v2_9),&(v13_10))
    };
    drop(v2_9);
    let v2_12: Space = map_map_kernels::unite(&(v2_7),&(v2_11));
    join_wrapped_into(&mut v1_26_write,&((v2_12).read_zipper()),&[]);
    }
    v1_26_cursor.ascend(1);
  }
  drop(v1_26_cursor);
  drop(v1_26_write);
  let mut v1_48 = Space::new();
  let mut v1_48_write = v1_48.write_zipper();
  let mut v1_48_cursor = descend_cursor(descend_cursor((*capture_0).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4));
  let v1_48_origin = v1_48_cursor.path().len();
  for v1_48_byte in v1_48_cursor.child_mask().iter() {
    v1_48_cursor.descend_to_existing_byte(v1_48_byte);
    {
    let v24_2: Space = singleton(&v1_48_cursor.path()[v1_48_origin..(v1_48_origin + 1)]);
    let v24_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v24_2));
    let v24_4: Space = if map_kernels::has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
    drop(v24_3);
    let v24_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v24_4));
    drop(v24_4);
    let v24_7: Space = if (&(v24_5)).is_empty() { Space::new() } else {
      let mut v25_6 = Space::new();
      let mut v25_6_write = v25_6.write_zipper();
      for v25_6_byte in v1_48_cursor.child_mask().iter() {
        v1_48_cursor.descend_to_existing_byte(v25_6_byte);
        {
        let v26_2: Space = singleton(&v1_48_cursor.path()[(v1_48_origin + 1)..(v1_48_origin + 2)]);
        let v26_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v26_2));
        let v26_4: Space = if map_kernels::has_head(&(v26_3)) { singleton(&[]) } else { Space::new() };
        drop(v26_3);
        let v26_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v26_4));
        drop(v26_4);
        let v26_8: Space = if (&(v26_5)).is_empty() { Space::new() } else {
          let mut v27_7 = Space::new();
          let mut v27_7_write = v27_7.write_zipper();
          for v27_7_byte in v1_48_cursor.child_mask().iter() {
            v1_48_cursor.descend_to_existing_byte(v27_7_byte);
            {
            let v28_2: Space = singleton(&v1_48_cursor.path()[(v1_48_origin + 2)..(v1_48_origin + 3)]);
            let v28_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v28_2));
            let v28_4: Space = if map_kernels::has_head(&(v28_3)) { singleton(&[]) } else { Space::new() };
            drop(v28_3);
            let v28_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v28_4));
            drop(v28_4);
            let v28_8: Space = if (&(v28_5)).is_empty() { Space::new() } else {
              let v29_7: Space = routine_7(c, &v1_48_cursor.path()[v1_48_origin..(v1_48_origin + 3)], &v1_48_cursor, &(*capture_0));
              map_map_kernels::compose(&(v28_5),&(v29_7))
            };
            drop(v28_5);
            let v28_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v28_2));
            drop(v28_2);
            let v28_10: Space = if map_kernels::has_head(&(v28_9)) { singleton(&[]) } else { Space::new() };
            drop(v28_9);
            let v28_12: Space = if (&(v28_10)).is_empty() { Space::new() } else {
              let v30_11: Space = routine_8(c, &v1_48_cursor.path()[v1_48_origin..(v1_48_origin + 3)], &v1_48_cursor, &(*capture_0));
              map_map_kernels::compose(&(v28_10),&(v30_11))
            };
            drop(v28_10);
            let v28_13: Space = map_map_kernels::unite(&(v28_8),&(v28_12));
            join_wrapped_into(&mut v27_7_write,&((v28_13).read_zipper()),&[]);
            }
            v1_48_cursor.ascend(1);
          }
          drop(v27_7_write);
          map_map_kernels::compose(&(v26_5),&(v27_7))
        };
        drop(v26_5);
        let v26_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v26_2));
        drop(v26_2);
        let v26_10: Space = if map_kernels::has_head(&(v26_9)) { singleton(&[]) } else { Space::new() };
        drop(v26_9);
        let v26_12: Space = if (&(v26_10)).is_empty() { Space::new() } else {
          let mut v31_11 = Space::new();
          let mut v31_11_write = v31_11.write_zipper();
          for v31_11_byte in v1_48_cursor.child_mask().iter() {
            v1_48_cursor.descend_to_existing_byte(v31_11_byte);
            {
            let v32_2: Space = singleton(&v1_48_cursor.path()[(v1_48_origin + 2)..(v1_48_origin + 3)]);
            let v32_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v32_2));
            let v32_4: Space = if map_kernels::has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
            drop(v32_3);
            let v32_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v32_4));
            drop(v32_4);
            let v32_8: Space = if (&(v32_5)).is_empty() { Space::new() } else {
              let v33_7: Space = routine_7(c, &v1_48_cursor.path()[v1_48_origin..(v1_48_origin + 3)], &v1_48_cursor, &(*capture_0));
              map_map_kernels::compose(&(v32_5),&(v33_7))
            };
            drop(v32_5);
            let v32_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v32_2));
            drop(v32_2);
            let v32_10: Space = if map_kernels::has_head(&(v32_9)) { singleton(&[]) } else { Space::new() };
            drop(v32_9);
            let v32_12: Space = if (&(v32_10)).is_empty() { Space::new() } else {
              let v34_11: Space = routine_9(c, &v1_48_cursor.path()[v1_48_origin..(v1_48_origin + 3)], &v1_48_cursor, &(*capture_0));
              map_map_kernels::compose(&(v32_10),&(v34_11))
            };
            drop(v32_10);
            let v32_13: Space = map_map_kernels::unite(&(v32_8),&(v32_12));
            join_wrapped_into(&mut v31_11_write,&((v32_13).read_zipper()),&[]);
            }
            v1_48_cursor.ascend(1);
          }
          drop(v31_11_write);
          map_map_kernels::compose(&(v26_10),&(v31_11))
        };
        drop(v26_10);
        let v26_13: Space = map_map_kernels::unite(&(v26_8),&(v26_12));
        join_wrapped_into(&mut v25_6_write,&((v26_13).read_zipper()),&[]);
        }
        v1_48_cursor.ascend(1);
      }
      drop(v25_6_write);
      map_map_kernels::compose(&(v24_5),&(v25_6))
    };
    drop(v24_5);
    let v24_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v24_2));
    drop(v24_2);
    let v24_9: Space = if map_kernels::has_head(&(v24_8)) { singleton(&[]) } else { Space::new() };
    drop(v24_8);
    let v24_11: Space = if (&(v24_9)).is_empty() { Space::new() } else {
      let mut v35_10 = Space::new();
      let mut v35_10_write = v35_10.write_zipper();
      for v35_10_byte in v1_48_cursor.child_mask().iter() {
        v1_48_cursor.descend_to_existing_byte(v35_10_byte);
        {
        let v36_2: Space = singleton(&v1_48_cursor.path()[(v1_48_origin + 1)..(v1_48_origin + 2)]);
        let v36_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v36_2));
        let v36_4: Space = if map_kernels::has_head(&(v36_3)) { singleton(&[]) } else { Space::new() };
        drop(v36_3);
        let v36_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v36_4));
        drop(v36_4);
        let v36_8: Space = if (&(v36_5)).is_empty() { Space::new() } else {
          let mut v37_7 = Space::new();
          let mut v37_7_write = v37_7.write_zipper();
          for v37_7_byte in v1_48_cursor.child_mask().iter() {
            v1_48_cursor.descend_to_existing_byte(v37_7_byte);
            {
            let v38_2: Space = singleton(&v1_48_cursor.path()[(v1_48_origin + 2)..(v1_48_origin + 3)]);
            let v38_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v38_2));
            let v38_4: Space = if map_kernels::has_head(&(v38_3)) { singleton(&[]) } else { Space::new() };
            drop(v38_3);
            let v38_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v38_4));
            drop(v38_4);
            let v38_8: Space = if (&(v38_5)).is_empty() { Space::new() } else {
              let v39_7: Space = routine_7(c, &v1_48_cursor.path()[v1_48_origin..(v1_48_origin + 3)], &v1_48_cursor, &(*capture_0));
              map_map_kernels::compose(&(v38_5),&(v39_7))
            };
            drop(v38_5);
            let v38_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v38_2));
            drop(v38_2);
            let v38_10: Space = if map_kernels::has_head(&(v38_9)) { singleton(&[]) } else { Space::new() };
            drop(v38_9);
            let v38_12: Space = if (&(v38_10)).is_empty() { Space::new() } else {
              let v40_11: Space = routine_8(c, &v1_48_cursor.path()[v1_48_origin..(v1_48_origin + 3)], &v1_48_cursor, &(*capture_0));
              map_map_kernels::compose(&(v38_10),&(v40_11))
            };
            drop(v38_10);
            let v38_13: Space = map_map_kernels::unite(&(v38_8),&(v38_12));
            join_wrapped_into(&mut v37_7_write,&((v38_13).read_zipper()),&[]);
            }
            v1_48_cursor.ascend(1);
          }
          drop(v37_7_write);
          map_map_kernels::compose(&(v36_5),&(v37_7))
        };
        drop(v36_5);
        let v36_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v36_2));
        drop(v36_2);
        let v36_10: Space = if map_kernels::has_head(&(v36_9)) { singleton(&[]) } else { Space::new() };
        drop(v36_9);
        let v36_12: Space = if (&(v36_10)).is_empty() { Space::new() } else {
          let mut v41_11 = Space::new();
          let mut v41_11_write = v41_11.write_zipper();
          for v41_11_byte in v1_48_cursor.child_mask().iter() {
            v1_48_cursor.descend_to_existing_byte(v41_11_byte);
            {
            let v42_2: Space = singleton(&v1_48_cursor.path()[(v1_48_origin + 2)..(v1_48_origin + 3)]);
            let v42_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v42_2));
            let v42_4: Space = if map_kernels::has_head(&(v42_3)) { singleton(&[]) } else { Space::new() };
            drop(v42_3);
            let v42_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v42_4));
            drop(v42_4);
            let v42_7: Space = if (&(v42_5)).is_empty() { Space::new() } else {
              let v43_6: Space = routine_10(c, &v1_48_cursor.path()[(v1_48_origin + 2)..(v1_48_origin + 3)], &v1_48_cursor, &(*capture_0));
              map_map_kernels::compose(&(v42_5),&(v43_6))
            };
            drop(v42_5);
            let v42_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v42_2));
            drop(v42_2);
            let v42_9: Space = if map_kernels::has_head(&(v42_8)) { singleton(&[]) } else { Space::new() };
            drop(v42_8);
            let v42_11: Space = if (&(v42_9)).is_empty() { Space::new() } else {
              let v44_10: Space = routine_11(c, &v1_48_cursor.path()[(v1_48_origin + 2)..(v1_48_origin + 3)], &v1_48_cursor, &(*capture_0));
              map_map_kernels::compose(&(v42_9),&(v44_10))
            };
            drop(v42_9);
            let v42_12: Space = map_map_kernels::unite(&(v42_7),&(v42_11));
            join_wrapped_into(&mut v41_11_write,&((v42_12).read_zipper()),&[]);
            }
            v1_48_cursor.ascend(1);
          }
          drop(v41_11_write);
          map_map_kernels::compose(&(v36_10),&(v41_11))
        };
        drop(v36_10);
        let v36_13: Space = map_kernels::wrap(&(v36_12),&v1_48_cursor.path()[v1_48_origin..(v1_48_origin + 2)]);
        let v36_14: Space = map_map_kernels::unite(&(v36_8),&(v36_13));
        join_wrapped_into(&mut v35_10_write,&((v36_14).read_zipper()),&[]);
        }
        v1_48_cursor.ascend(1);
      }
      drop(v35_10_write);
      map_map_kernels::compose(&(v24_9),&(v35_10))
    };
    drop(v24_9);
    let v24_12: Space = map_map_kernels::unite(&(v24_7),&(v24_11));
    join_wrapped_into(&mut v1_48_write,&((v24_12).read_zipper()),&[]);
    }
    v1_48_cursor.ascend(1);
  }
  drop(v1_48_cursor);
  drop(v1_48_write);
  let v1_49: Space = map_map_kernels::unite(&(v1_26),&(v1_48));
  let mut v1_73 = Space::new();
  let mut v1_73_write = v1_73.write_zipper();
  let mut v1_73_cursor = descend_cursor(descend_cursor((*capture_0).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_8));
  let v1_73_origin = v1_73_cursor.path().len();
  for v1_73_byte in v1_73_cursor.child_mask().iter() {
    v1_73_cursor.descend_to_existing_byte(v1_73_byte);
    {
    let v46_2: Space = singleton(&v1_73_cursor.path()[v1_73_origin..(v1_73_origin + 1)]);
    let v46_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v46_2));
    let v46_4: Space = if map_kernels::has_head(&(v46_3)) { singleton(&[]) } else { Space::new() };
    drop(v46_3);
    let v46_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v46_4));
    drop(v46_4);
    let v46_7: Space = if (&(v46_5)).is_empty() { Space::new() } else {
      let mut v47_6 = Space::new();
      let mut v47_6_write = v47_6.write_zipper();
      for v47_6_byte in v1_73_cursor.child_mask().iter() {
        v1_73_cursor.descend_to_existing_byte(v47_6_byte);
        {
        let v48_2: Space = singleton(&v1_73_cursor.path()[(v1_73_origin + 1)..(v1_73_origin + 2)]);
        let v48_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v48_2));
        let v48_4: Space = if map_kernels::has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
        drop(v48_3);
        let v48_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v48_4));
        drop(v48_4);
        let v48_8: Space = if (&(v48_5)).is_empty() { Space::new() } else {
          let mut v49_7 = Space::new();
          let mut v49_7_write = v49_7.write_zipper();
          for v49_7_byte in v1_73_cursor.child_mask().iter() {
            v1_73_cursor.descend_to_existing_byte(v49_7_byte);
            {
            let v50_2: Space = singleton(&v1_73_cursor.path()[(v1_73_origin + 2)..(v1_73_origin + 3)]);
            let v50_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v50_2));
            let v50_4: Space = if map_kernels::has_head(&(v50_3)) { singleton(&[]) } else { Space::new() };
            drop(v50_3);
            let v50_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v50_4));
            drop(v50_4);
            let v50_8: Space = if (&(v50_5)).is_empty() { Space::new() } else {
              let v51_7: Space = routine_12(c, &v1_73_cursor.path()[v1_73_origin..(v1_73_origin + 3)], &v1_73_cursor);
              map_map_kernels::compose(&(v50_5),&(v51_7))
            };
            drop(v50_5);
            let v50_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v50_2));
            drop(v50_2);
            let v50_10: Space = if map_kernels::has_head(&(v50_9)) { singleton(&[]) } else { Space::new() };
            drop(v50_9);
            let v50_12: Space = if (&(v50_10)).is_empty() { Space::new() } else {
              let v52_11: Space = routine_13(c, &v1_73_cursor.path()[v1_73_origin..(v1_73_origin + 3)], &v1_73_cursor);
              map_map_kernels::compose(&(v50_10),&(v52_11))
            };
            drop(v50_10);
            let v50_13: Space = map_map_kernels::unite(&(v50_8),&(v50_12));
            join_wrapped_into(&mut v49_7_write,&((v50_13).read_zipper()),&[]);
            }
            v1_73_cursor.ascend(1);
          }
          drop(v49_7_write);
          map_map_kernels::compose(&(v48_5),&(v49_7))
        };
        drop(v48_5);
        let v48_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v48_2));
        drop(v48_2);
        let v48_10: Space = if map_kernels::has_head(&(v48_9)) { singleton(&[]) } else { Space::new() };
        drop(v48_9);
        let v48_12: Space = if (&(v48_10)).is_empty() { Space::new() } else {
          let mut v53_11 = Space::new();
          let mut v53_11_write = v53_11.write_zipper();
          for v53_11_byte in v1_73_cursor.child_mask().iter() {
            v1_73_cursor.descend_to_existing_byte(v53_11_byte);
            {
            let v54_2: Space = singleton(&v1_73_cursor.path()[(v1_73_origin + 2)..(v1_73_origin + 3)]);
            let v54_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v54_2));
            let v54_4: Space = if map_kernels::has_head(&(v54_3)) { singleton(&[]) } else { Space::new() };
            drop(v54_3);
            let v54_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v54_4));
            drop(v54_4);
            let v54_8: Space = if (&(v54_5)).is_empty() { Space::new() } else {
              let v55_7: Space = routine_12(c, &v1_73_cursor.path()[v1_73_origin..(v1_73_origin + 3)], &v1_73_cursor);
              map_map_kernels::compose(&(v54_5),&(v55_7))
            };
            drop(v54_5);
            let v54_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v54_2));
            drop(v54_2);
            let v54_10: Space = if map_kernels::has_head(&(v54_9)) { singleton(&[]) } else { Space::new() };
            drop(v54_9);
            let v54_12: Space = if (&(v54_10)).is_empty() { Space::new() } else {
              let v56_11: Space = routine_14(c, &v1_73_cursor.path()[v1_73_origin..(v1_73_origin + 3)], &v1_73_cursor);
              map_map_kernels::compose(&(v54_10),&(v56_11))
            };
            drop(v54_10);
            let v54_13: Space = map_map_kernels::unite(&(v54_8),&(v54_12));
            join_wrapped_into(&mut v53_11_write,&((v54_13).read_zipper()),&[]);
            }
            v1_73_cursor.ascend(1);
          }
          drop(v53_11_write);
          map_map_kernels::compose(&(v48_10),&(v53_11))
        };
        drop(v48_10);
        let v48_13: Space = map_map_kernels::unite(&(v48_8),&(v48_12));
        join_wrapped_into(&mut v47_6_write,&((v48_13).read_zipper()),&[]);
        }
        v1_73_cursor.ascend(1);
      }
      drop(v47_6_write);
      map_map_kernels::compose(&(v46_5),&(v47_6))
    };
    drop(v46_5);
    let v46_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v46_2));
    drop(v46_2);
    let v46_9: Space = if map_kernels::has_head(&(v46_8)) { singleton(&[]) } else { Space::new() };
    drop(v46_8);
    let v46_11: Space = if (&(v46_9)).is_empty() { Space::new() } else {
      let mut v57_10 = Space::new();
      let mut v57_10_write = v57_10.write_zipper();
      for v57_10_byte in v1_73_cursor.child_mask().iter() {
        v1_73_cursor.descend_to_existing_byte(v57_10_byte);
        {
        let v58_2: Space = singleton(&v1_73_cursor.path()[(v1_73_origin + 1)..(v1_73_origin + 2)]);
        let v58_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v58_2));
        let v58_4: Space = if map_kernels::has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
        drop(v58_3);
        let v58_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v58_4));
        drop(v58_4);
        let v58_8: Space = if (&(v58_5)).is_empty() { Space::new() } else {
          let mut v59_7 = Space::new();
          let mut v59_7_write = v59_7.write_zipper();
          for v59_7_byte in v1_73_cursor.child_mask().iter() {
            v1_73_cursor.descend_to_existing_byte(v59_7_byte);
            {
            let v60_2: Space = singleton(&v1_73_cursor.path()[(v1_73_origin + 2)..(v1_73_origin + 3)]);
            let v60_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v60_2));
            let v60_4: Space = if map_kernels::has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
            drop(v60_3);
            let v60_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v60_4));
            drop(v60_4);
            let v60_8: Space = if (&(v60_5)).is_empty() { Space::new() } else {
              let v61_7: Space = routine_12(c, &v1_73_cursor.path()[v1_73_origin..(v1_73_origin + 3)], &v1_73_cursor);
              map_map_kernels::compose(&(v60_5),&(v61_7))
            };
            drop(v60_5);
            let v60_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v60_2));
            drop(v60_2);
            let v60_10: Space = if map_kernels::has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
            drop(v60_9);
            let v60_12: Space = if (&(v60_10)).is_empty() { Space::new() } else {
              let v62_11: Space = routine_13(c, &v1_73_cursor.path()[v1_73_origin..(v1_73_origin + 3)], &v1_73_cursor);
              map_map_kernels::compose(&(v60_10),&(v62_11))
            };
            drop(v60_10);
            let v60_13: Space = map_map_kernels::unite(&(v60_8),&(v60_12));
            join_wrapped_into(&mut v59_7_write,&((v60_13).read_zipper()),&[]);
            }
            v1_73_cursor.ascend(1);
          }
          drop(v59_7_write);
          map_map_kernels::compose(&(v58_5),&(v59_7))
        };
        drop(v58_5);
        let v58_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v58_2));
        drop(v58_2);
        let v58_10: Space = if map_kernels::has_head(&(v58_9)) { singleton(&[]) } else { Space::new() };
        drop(v58_9);
        let v58_12: Space = if (&(v58_10)).is_empty() { Space::new() } else {
          let v63_11: Space = view_map_kernels::subtract(&v1_73_cursor,&(*CONSTANT_5));
          map_map_kernels::compose(&(v58_10),&(v63_11))
        };
        drop(v58_10);
        let v58_13: Space = map_kernels::wrap(&(v58_12),&v1_73_cursor.path()[v1_73_origin..(v1_73_origin + 2)]);
        drop(v58_12);
        let v58_14: Space = map_map_kernels::unite(&(v58_8),&(v58_13));
        drop(v58_13);
        join_wrapped_into(&mut v57_10_write,&((v58_14).read_zipper()),&[]);
        }
        v1_73_cursor.ascend(1);
      }
      drop(v57_10_write);
      map_map_kernels::compose(&(v46_9),&(v57_10))
    };
    drop(v46_9);
    let v46_12: Space = map_map_kernels::unite(&(v46_7),&(v46_11));
    join_wrapped_into(&mut v1_73_write,&((v46_12).read_zipper()),&[]);
    }
    v1_73_cursor.ascend(1);
  }
  drop(v1_73_cursor);
  drop(v1_73_write);

((v1_26).clone(),(v1_48).clone(),(v1_49).clone(),(v1_73).clone(),)
}

#[inline(never)]
fn native_block_1(c: &mut Context,capture_0: &Space) -> (Space,Space,Space,Space,) {
    let mut v87_3 = Space::new();
    let mut v87_3_write = v87_3.write_zipper();
    let mut v87_3_cursor = descend_cursor(descend_cursor(((*capture_0)).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4));
    let v87_3_origin = v87_3_cursor.path().len();
    for v87_3_byte in v87_3_cursor.child_mask().iter() {
      v87_3_cursor.descend_to_existing_byte(v87_3_byte);
      {
      let v88_2: Space = singleton(&v87_3_cursor.path()[v87_3_origin..(v87_3_origin + 1)]);
      let v88_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v88_2));
      let v88_4: Space = if map_kernels::has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
      drop(v88_3);
      let v88_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v88_4));
      drop(v88_4);
      let v88_7: Space = if (&(v88_5)).is_empty() { Space::new() } else {
        let mut v89_6 = Space::new();
        let mut v89_6_write = v89_6.write_zipper();
        for v89_6_byte in v87_3_cursor.child_mask().iter() {
          v87_3_cursor.descend_to_existing_byte(v89_6_byte);
          {
          let v90_2: Space = singleton(&v87_3_cursor.path()[(v87_3_origin + 1)..(v87_3_origin + 2)]);
          let v90_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v90_2));
          let v90_4: Space = if map_kernels::has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
          drop(v90_3);
          let v90_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v90_4));
          drop(v90_4);
          let v90_8: Space = if (&(v90_5)).is_empty() { Space::new() } else {
            let mut v91_7 = Space::new();
            let mut v91_7_write = v91_7.write_zipper();
            for v91_7_byte in v87_3_cursor.child_mask().iter() {
              v87_3_cursor.descend_to_existing_byte(v91_7_byte);
              {
              let v92_2: Space = singleton(&v87_3_cursor.path()[(v87_3_origin + 2)..(v87_3_origin + 3)]);
              let v92_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v92_2));
              let v92_4: Space = if map_kernels::has_head(&(v92_3)) { singleton(&[]) } else { Space::new() };
              drop(v92_3);
              let v92_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v92_4));
              drop(v92_4);
              let v92_8: Space = if (&(v92_5)).is_empty() { Space::new() } else {
                let v93_7: Space = routine_2(c, &v87_3_cursor.path()[v87_3_origin..(v87_3_origin + 3)], &v87_3_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v92_5),&(v93_7))
              };
              drop(v92_5);
              let v92_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v92_2));
              drop(v92_2);
              let v92_10: Space = if map_kernels::has_head(&(v92_9)) { singleton(&[]) } else { Space::new() };
              drop(v92_9);
              let v92_12: Space = if (&(v92_10)).is_empty() { Space::new() } else {
                let v94_11: Space = routine_3(c, &v87_3_cursor.path()[v87_3_origin..(v87_3_origin + 3)], &v87_3_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v92_10),&(v94_11))
              };
              drop(v92_10);
              let v92_13: Space = map_map_kernels::unite(&(v92_8),&(v92_12));
              join_wrapped_into(&mut v91_7_write,&((v92_13).read_zipper()),&[]);
              }
              v87_3_cursor.ascend(1);
            }
            drop(v91_7_write);
            map_map_kernels::compose(&(v90_5),&(v91_7))
          };
          drop(v90_5);
          let v90_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v90_2));
          drop(v90_2);
          let v90_10: Space = if map_kernels::has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
          drop(v90_9);
          let v90_12: Space = if (&(v90_10)).is_empty() { Space::new() } else {
            let mut v95_11 = Space::new();
            let mut v95_11_write = v95_11.write_zipper();
            for v95_11_byte in v87_3_cursor.child_mask().iter() {
              v87_3_cursor.descend_to_existing_byte(v95_11_byte);
              {
              let v96_2: Space = singleton(&v87_3_cursor.path()[(v87_3_origin + 2)..(v87_3_origin + 3)]);
              let v96_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v96_2));
              let v96_4: Space = if map_kernels::has_head(&(v96_3)) { singleton(&[]) } else { Space::new() };
              drop(v96_3);
              let v96_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v96_4));
              drop(v96_4);
              let v96_8: Space = if (&(v96_5)).is_empty() { Space::new() } else {
                let v97_7: Space = routine_2(c, &v87_3_cursor.path()[v87_3_origin..(v87_3_origin + 3)], &v87_3_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v96_5),&(v97_7))
              };
              drop(v96_5);
              let v96_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v96_2));
              drop(v96_2);
              let v96_10: Space = if map_kernels::has_head(&(v96_9)) { singleton(&[]) } else { Space::new() };
              drop(v96_9);
              let v96_12: Space = if (&(v96_10)).is_empty() { Space::new() } else {
                let v98_11: Space = routine_4(c, &v87_3_cursor.path()[v87_3_origin..(v87_3_origin + 3)], &v87_3_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v96_10),&(v98_11))
              };
              drop(v96_10);
              let v96_13: Space = map_map_kernels::unite(&(v96_8),&(v96_12));
              join_wrapped_into(&mut v95_11_write,&((v96_13).read_zipper()),&[]);
              }
              v87_3_cursor.ascend(1);
            }
            drop(v95_11_write);
            map_map_kernels::compose(&(v90_10),&(v95_11))
          };
          drop(v90_10);
          let v90_13: Space = map_map_kernels::unite(&(v90_8),&(v90_12));
          join_wrapped_into(&mut v89_6_write,&((v90_13).read_zipper()),&[]);
          }
          v87_3_cursor.ascend(1);
        }
        drop(v89_6_write);
        map_map_kernels::compose(&(v88_5),&(v89_6))
      };
      drop(v88_5);
      let v88_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v88_2));
      drop(v88_2);
      let v88_9: Space = if map_kernels::has_head(&(v88_8)) { singleton(&[]) } else { Space::new() };
      drop(v88_8);
      let v88_11: Space = if (&(v88_9)).is_empty() { Space::new() } else {
        let mut v99_10 = Space::new();
        let mut v99_10_write = v99_10.write_zipper();
        for v99_10_byte in v87_3_cursor.child_mask().iter() {
          v87_3_cursor.descend_to_existing_byte(v99_10_byte);
          {
          let v100_2: Space = singleton(&v87_3_cursor.path()[(v87_3_origin + 1)..(v87_3_origin + 2)]);
          let v100_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v100_2));
          let v100_4: Space = if map_kernels::has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
          drop(v100_3);
          let v100_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v100_4));
          drop(v100_4);
          let v100_8: Space = if (&(v100_5)).is_empty() { Space::new() } else {
            let mut v101_7 = Space::new();
            let mut v101_7_write = v101_7.write_zipper();
            for v101_7_byte in v87_3_cursor.child_mask().iter() {
              v87_3_cursor.descend_to_existing_byte(v101_7_byte);
              {
              let v102_2: Space = singleton(&v87_3_cursor.path()[(v87_3_origin + 2)..(v87_3_origin + 3)]);
              let v102_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v102_2));
              let v102_4: Space = if map_kernels::has_head(&(v102_3)) { singleton(&[]) } else { Space::new() };
              drop(v102_3);
              let v102_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v102_4));
              drop(v102_4);
              let v102_8: Space = if (&(v102_5)).is_empty() { Space::new() } else {
                let v103_7: Space = routine_2(c, &v87_3_cursor.path()[v87_3_origin..(v87_3_origin + 3)], &v87_3_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v102_5),&(v103_7))
              };
              drop(v102_5);
              let v102_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v102_2));
              drop(v102_2);
              let v102_10: Space = if map_kernels::has_head(&(v102_9)) { singleton(&[]) } else { Space::new() };
              drop(v102_9);
              let v102_12: Space = if (&(v102_10)).is_empty() { Space::new() } else {
                let v104_11: Space = routine_3(c, &v87_3_cursor.path()[v87_3_origin..(v87_3_origin + 3)], &v87_3_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v102_10),&(v104_11))
              };
              drop(v102_10);
              let v102_13: Space = map_map_kernels::unite(&(v102_8),&(v102_12));
              join_wrapped_into(&mut v101_7_write,&((v102_13).read_zipper()),&[]);
              }
              v87_3_cursor.ascend(1);
            }
            drop(v101_7_write);
            map_map_kernels::compose(&(v100_5),&(v101_7))
          };
          drop(v100_5);
          let v100_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v100_2));
          drop(v100_2);
          let v100_10: Space = if map_kernels::has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
          drop(v100_9);
          let v100_12: Space = if (&(v100_10)).is_empty() { Space::new() } else {
            let mut v105_11 = Space::new();
            let mut v105_11_write = v105_11.write_zipper();
            for v105_11_byte in v87_3_cursor.child_mask().iter() {
              v87_3_cursor.descend_to_existing_byte(v105_11_byte);
              {
              let v106_2: Space = singleton(&v87_3_cursor.path()[(v87_3_origin + 2)..(v87_3_origin + 3)]);
              let v106_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v106_2));
              let v106_4: Space = if map_kernels::has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
              drop(v106_3);
              let v106_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v106_4));
              drop(v106_4);
              let v106_7: Space = if (&(v106_5)).is_empty() { Space::new() } else {
                let v107_6: Space = routine_5(c, &v87_3_cursor.path()[(v87_3_origin + 2)..(v87_3_origin + 3)], &v87_3_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v106_5),&(v107_6))
              };
              drop(v106_5);
              let v106_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v106_2));
              drop(v106_2);
              let v106_9: Space = if map_kernels::has_head(&(v106_8)) { singleton(&[]) } else { Space::new() };
              drop(v106_8);
              let v106_11: Space = if (&(v106_9)).is_empty() { Space::new() } else {
                let v108_10: Space = routine_6(c, &v87_3_cursor.path()[(v87_3_origin + 2)..(v87_3_origin + 3)], &v87_3_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v106_9),&(v108_10))
              };
              drop(v106_9);
              let v106_12: Space = map_map_kernels::unite(&(v106_7),&(v106_11));
              join_wrapped_into(&mut v105_11_write,&((v106_12).read_zipper()),&[]);
              }
              v87_3_cursor.ascend(1);
            }
            drop(v105_11_write);
            map_map_kernels::compose(&(v100_10),&(v105_11))
          };
          drop(v100_10);
          let v100_13: Space = map_kernels::wrap(&(v100_12),&v87_3_cursor.path()[v87_3_origin..(v87_3_origin + 2)]);
          let v100_14: Space = map_map_kernels::unite(&(v100_8),&(v100_13));
          join_wrapped_into(&mut v99_10_write,&((v100_14).read_zipper()),&[]);
          }
          v87_3_cursor.ascend(1);
        }
        drop(v99_10_write);
        map_map_kernels::compose(&(v88_9),&(v99_10))
      };
      drop(v88_9);
      let v88_12: Space = map_map_kernels::unite(&(v88_7),&(v88_11));
      join_wrapped_into(&mut v87_3_write,&((v88_12).read_zipper()),&[]);
      }
      v87_3_cursor.ascend(1);
    }
    drop(v87_3_cursor);
    drop(v87_3_write);
    let mut v87_4 = Space::new();
    let mut v87_4_write = v87_4.write_zipper();
    let mut v87_4_cursor = descend_cursor(descend_cursor(((*capture_0)).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4));
    let v87_4_origin = v87_4_cursor.path().len();
    for v87_4_byte in v87_4_cursor.child_mask().iter() {
      v87_4_cursor.descend_to_existing_byte(v87_4_byte);
      {
      let v110_2: Space = singleton(&v87_4_cursor.path()[v87_4_origin..(v87_4_origin + 1)]);
      let v110_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v110_2));
      let v110_4: Space = if map_kernels::has_head(&(v110_3)) { singleton(&[]) } else { Space::new() };
      drop(v110_3);
      let v110_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v110_4));
      drop(v110_4);
      let v110_7: Space = if (&(v110_5)).is_empty() { Space::new() } else {
        let mut v111_6 = Space::new();
        let mut v111_6_write = v111_6.write_zipper();
        for v111_6_byte in v87_4_cursor.child_mask().iter() {
          v87_4_cursor.descend_to_existing_byte(v111_6_byte);
          {
          let v112_2: Space = singleton(&v87_4_cursor.path()[(v87_4_origin + 1)..(v87_4_origin + 2)]);
          let v112_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v112_2));
          let v112_4: Space = if map_kernels::has_head(&(v112_3)) { singleton(&[]) } else { Space::new() };
          drop(v112_3);
          let v112_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v112_4));
          drop(v112_4);
          let v112_8: Space = if (&(v112_5)).is_empty() { Space::new() } else {
            let mut v113_7 = Space::new();
            let mut v113_7_write = v113_7.write_zipper();
            for v113_7_byte in v87_4_cursor.child_mask().iter() {
              v87_4_cursor.descend_to_existing_byte(v113_7_byte);
              {
              let v114_2: Space = singleton(&v87_4_cursor.path()[(v87_4_origin + 2)..(v87_4_origin + 3)]);
              let v114_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v114_2));
              let v114_4: Space = if map_kernels::has_head(&(v114_3)) { singleton(&[]) } else { Space::new() };
              drop(v114_3);
              let v114_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v114_4));
              drop(v114_4);
              let v114_8: Space = if (&(v114_5)).is_empty() { Space::new() } else {
                let v115_7: Space = routine_7(c, &v87_4_cursor.path()[v87_4_origin..(v87_4_origin + 3)], &v87_4_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v114_5),&(v115_7))
              };
              drop(v114_5);
              let v114_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v114_2));
              drop(v114_2);
              let v114_10: Space = if map_kernels::has_head(&(v114_9)) { singleton(&[]) } else { Space::new() };
              drop(v114_9);
              let v114_12: Space = if (&(v114_10)).is_empty() { Space::new() } else {
                let v116_11: Space = routine_8(c, &v87_4_cursor.path()[v87_4_origin..(v87_4_origin + 3)], &v87_4_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v114_10),&(v116_11))
              };
              drop(v114_10);
              let v114_13: Space = map_map_kernels::unite(&(v114_8),&(v114_12));
              join_wrapped_into(&mut v113_7_write,&((v114_13).read_zipper()),&[]);
              }
              v87_4_cursor.ascend(1);
            }
            drop(v113_7_write);
            map_map_kernels::compose(&(v112_5),&(v113_7))
          };
          drop(v112_5);
          let v112_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v112_2));
          drop(v112_2);
          let v112_10: Space = if map_kernels::has_head(&(v112_9)) { singleton(&[]) } else { Space::new() };
          drop(v112_9);
          let v112_12: Space = if (&(v112_10)).is_empty() { Space::new() } else {
            let mut v117_11 = Space::new();
            let mut v117_11_write = v117_11.write_zipper();
            for v117_11_byte in v87_4_cursor.child_mask().iter() {
              v87_4_cursor.descend_to_existing_byte(v117_11_byte);
              {
              let v118_2: Space = singleton(&v87_4_cursor.path()[(v87_4_origin + 2)..(v87_4_origin + 3)]);
              let v118_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v118_2));
              let v118_4: Space = if map_kernels::has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
              drop(v118_3);
              let v118_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v118_4));
              drop(v118_4);
              let v118_8: Space = if (&(v118_5)).is_empty() { Space::new() } else {
                let v119_7: Space = routine_7(c, &v87_4_cursor.path()[v87_4_origin..(v87_4_origin + 3)], &v87_4_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v118_5),&(v119_7))
              };
              drop(v118_5);
              let v118_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v118_2));
              drop(v118_2);
              let v118_10: Space = if map_kernels::has_head(&(v118_9)) { singleton(&[]) } else { Space::new() };
              drop(v118_9);
              let v118_12: Space = if (&(v118_10)).is_empty() { Space::new() } else {
                let v120_11: Space = routine_9(c, &v87_4_cursor.path()[v87_4_origin..(v87_4_origin + 3)], &v87_4_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v118_10),&(v120_11))
              };
              drop(v118_10);
              let v118_13: Space = map_map_kernels::unite(&(v118_8),&(v118_12));
              join_wrapped_into(&mut v117_11_write,&((v118_13).read_zipper()),&[]);
              }
              v87_4_cursor.ascend(1);
            }
            drop(v117_11_write);
            map_map_kernels::compose(&(v112_10),&(v117_11))
          };
          drop(v112_10);
          let v112_13: Space = map_map_kernels::unite(&(v112_8),&(v112_12));
          join_wrapped_into(&mut v111_6_write,&((v112_13).read_zipper()),&[]);
          }
          v87_4_cursor.ascend(1);
        }
        drop(v111_6_write);
        map_map_kernels::compose(&(v110_5),&(v111_6))
      };
      drop(v110_5);
      let v110_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v110_2));
      drop(v110_2);
      let v110_9: Space = if map_kernels::has_head(&(v110_8)) { singleton(&[]) } else { Space::new() };
      drop(v110_8);
      let v110_11: Space = if (&(v110_9)).is_empty() { Space::new() } else {
        let mut v121_10 = Space::new();
        let mut v121_10_write = v121_10.write_zipper();
        for v121_10_byte in v87_4_cursor.child_mask().iter() {
          v87_4_cursor.descend_to_existing_byte(v121_10_byte);
          {
          let v122_2: Space = singleton(&v87_4_cursor.path()[(v87_4_origin + 1)..(v87_4_origin + 2)]);
          let v122_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v122_2));
          let v122_4: Space = if map_kernels::has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
          drop(v122_3);
          let v122_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v122_4));
          drop(v122_4);
          let v122_8: Space = if (&(v122_5)).is_empty() { Space::new() } else {
            let mut v123_7 = Space::new();
            let mut v123_7_write = v123_7.write_zipper();
            for v123_7_byte in v87_4_cursor.child_mask().iter() {
              v87_4_cursor.descend_to_existing_byte(v123_7_byte);
              {
              let v124_2: Space = singleton(&v87_4_cursor.path()[(v87_4_origin + 2)..(v87_4_origin + 3)]);
              let v124_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v124_2));
              let v124_4: Space = if map_kernels::has_head(&(v124_3)) { singleton(&[]) } else { Space::new() };
              drop(v124_3);
              let v124_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v124_4));
              drop(v124_4);
              let v124_8: Space = if (&(v124_5)).is_empty() { Space::new() } else {
                let v125_7: Space = routine_7(c, &v87_4_cursor.path()[v87_4_origin..(v87_4_origin + 3)], &v87_4_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v124_5),&(v125_7))
              };
              drop(v124_5);
              let v124_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v124_2));
              drop(v124_2);
              let v124_10: Space = if map_kernels::has_head(&(v124_9)) { singleton(&[]) } else { Space::new() };
              drop(v124_9);
              let v124_12: Space = if (&(v124_10)).is_empty() { Space::new() } else {
                let v126_11: Space = routine_8(c, &v87_4_cursor.path()[v87_4_origin..(v87_4_origin + 3)], &v87_4_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v124_10),&(v126_11))
              };
              drop(v124_10);
              let v124_13: Space = map_map_kernels::unite(&(v124_8),&(v124_12));
              join_wrapped_into(&mut v123_7_write,&((v124_13).read_zipper()),&[]);
              }
              v87_4_cursor.ascend(1);
            }
            drop(v123_7_write);
            map_map_kernels::compose(&(v122_5),&(v123_7))
          };
          drop(v122_5);
          let v122_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v122_2));
          drop(v122_2);
          let v122_10: Space = if map_kernels::has_head(&(v122_9)) { singleton(&[]) } else { Space::new() };
          drop(v122_9);
          let v122_12: Space = if (&(v122_10)).is_empty() { Space::new() } else {
            let mut v127_11 = Space::new();
            let mut v127_11_write = v127_11.write_zipper();
            for v127_11_byte in v87_4_cursor.child_mask().iter() {
              v87_4_cursor.descend_to_existing_byte(v127_11_byte);
              {
              let v128_2: Space = singleton(&v87_4_cursor.path()[(v87_4_origin + 2)..(v87_4_origin + 3)]);
              let v128_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v128_2));
              let v128_4: Space = if map_kernels::has_head(&(v128_3)) { singleton(&[]) } else { Space::new() };
              drop(v128_3);
              let v128_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v128_4));
              drop(v128_4);
              let v128_7: Space = if (&(v128_5)).is_empty() { Space::new() } else {
                let v129_6: Space = routine_10(c, &v87_4_cursor.path()[(v87_4_origin + 2)..(v87_4_origin + 3)], &v87_4_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v128_5),&(v129_6))
              };
              drop(v128_5);
              let v128_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v128_2));
              drop(v128_2);
              let v128_9: Space = if map_kernels::has_head(&(v128_8)) { singleton(&[]) } else { Space::new() };
              drop(v128_8);
              let v128_11: Space = if (&(v128_9)).is_empty() { Space::new() } else {
                let v130_10: Space = routine_11(c, &v87_4_cursor.path()[(v87_4_origin + 2)..(v87_4_origin + 3)], &v87_4_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v128_9),&(v130_10))
              };
              drop(v128_9);
              let v128_12: Space = map_map_kernels::unite(&(v128_7),&(v128_11));
              join_wrapped_into(&mut v127_11_write,&((v128_12).read_zipper()),&[]);
              }
              v87_4_cursor.ascend(1);
            }
            drop(v127_11_write);
            map_map_kernels::compose(&(v122_10),&(v127_11))
          };
          drop(v122_10);
          let v122_13: Space = map_kernels::wrap(&(v122_12),&v87_4_cursor.path()[v87_4_origin..(v87_4_origin + 2)]);
          let v122_14: Space = map_map_kernels::unite(&(v122_8),&(v122_13));
          join_wrapped_into(&mut v121_10_write,&((v122_14).read_zipper()),&[]);
          }
          v87_4_cursor.ascend(1);
        }
        drop(v121_10_write);
        map_map_kernels::compose(&(v110_9),&(v121_10))
      };
      drop(v110_9);
      let v110_12: Space = map_map_kernels::unite(&(v110_7),&(v110_11));
      join_wrapped_into(&mut v87_4_write,&((v110_12).read_zipper()),&[]);
      }
      v87_4_cursor.ascend(1);
    }
    drop(v87_4_cursor);
    drop(v87_4_write);
    let v87_5: Space = map_map_kernels::unite(&(v87_3),&(v87_4));
    let mut v87_8 = Space::new();
    let mut v87_8_write = v87_8.write_zipper();
    let mut v87_8_cursor = descend_cursor(descend_cursor(((*capture_0)).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_8));
    let v87_8_origin = v87_8_cursor.path().len();
    for v87_8_byte in v87_8_cursor.child_mask().iter() {
      v87_8_cursor.descend_to_existing_byte(v87_8_byte);
      {
      let v132_2: Space = singleton(&v87_8_cursor.path()[v87_8_origin..(v87_8_origin + 1)]);
      let v132_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v132_2));
      let v132_4: Space = if map_kernels::has_head(&(v132_3)) { singleton(&[]) } else { Space::new() };
      drop(v132_3);
      let v132_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v132_4));
      drop(v132_4);
      let v132_7: Space = if (&(v132_5)).is_empty() { Space::new() } else {
        let mut v133_6 = Space::new();
        let mut v133_6_write = v133_6.write_zipper();
        for v133_6_byte in v87_8_cursor.child_mask().iter() {
          v87_8_cursor.descend_to_existing_byte(v133_6_byte);
          {
          let v134_2: Space = singleton(&v87_8_cursor.path()[(v87_8_origin + 1)..(v87_8_origin + 2)]);
          let v134_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v134_2));
          let v134_4: Space = if map_kernels::has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
          drop(v134_3);
          let v134_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v134_4));
          drop(v134_4);
          let v134_8: Space = if (&(v134_5)).is_empty() { Space::new() } else {
            let mut v135_7 = Space::new();
            let mut v135_7_write = v135_7.write_zipper();
            for v135_7_byte in v87_8_cursor.child_mask().iter() {
              v87_8_cursor.descend_to_existing_byte(v135_7_byte);
              {
              let v136_2: Space = singleton(&v87_8_cursor.path()[(v87_8_origin + 2)..(v87_8_origin + 3)]);
              let v136_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v136_2));
              let v136_4: Space = if map_kernels::has_head(&(v136_3)) { singleton(&[]) } else { Space::new() };
              drop(v136_3);
              let v136_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v136_4));
              drop(v136_4);
              let v136_8: Space = if (&(v136_5)).is_empty() { Space::new() } else {
                let v137_7: Space = routine_12(c, &v87_8_cursor.path()[v87_8_origin..(v87_8_origin + 3)], &v87_8_cursor);
                map_map_kernels::compose(&(v136_5),&(v137_7))
              };
              drop(v136_5);
              let v136_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v136_2));
              drop(v136_2);
              let v136_10: Space = if map_kernels::has_head(&(v136_9)) { singleton(&[]) } else { Space::new() };
              drop(v136_9);
              let v136_12: Space = if (&(v136_10)).is_empty() { Space::new() } else {
                let v138_11: Space = routine_13(c, &v87_8_cursor.path()[v87_8_origin..(v87_8_origin + 3)], &v87_8_cursor);
                map_map_kernels::compose(&(v136_10),&(v138_11))
              };
              drop(v136_10);
              let v136_13: Space = map_map_kernels::unite(&(v136_8),&(v136_12));
              join_wrapped_into(&mut v135_7_write,&((v136_13).read_zipper()),&[]);
              }
              v87_8_cursor.ascend(1);
            }
            drop(v135_7_write);
            map_map_kernels::compose(&(v134_5),&(v135_7))
          };
          drop(v134_5);
          let v134_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v134_2));
          drop(v134_2);
          let v134_10: Space = if map_kernels::has_head(&(v134_9)) { singleton(&[]) } else { Space::new() };
          drop(v134_9);
          let v134_12: Space = if (&(v134_10)).is_empty() { Space::new() } else {
            let mut v139_11 = Space::new();
            let mut v139_11_write = v139_11.write_zipper();
            for v139_11_byte in v87_8_cursor.child_mask().iter() {
              v87_8_cursor.descend_to_existing_byte(v139_11_byte);
              {
              let v140_2: Space = singleton(&v87_8_cursor.path()[(v87_8_origin + 2)..(v87_8_origin + 3)]);
              let v140_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v140_2));
              let v140_4: Space = if map_kernels::has_head(&(v140_3)) { singleton(&[]) } else { Space::new() };
              drop(v140_3);
              let v140_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v140_4));
              drop(v140_4);
              let v140_8: Space = if (&(v140_5)).is_empty() { Space::new() } else {
                let v141_7: Space = routine_12(c, &v87_8_cursor.path()[v87_8_origin..(v87_8_origin + 3)], &v87_8_cursor);
                map_map_kernels::compose(&(v140_5),&(v141_7))
              };
              drop(v140_5);
              let v140_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v140_2));
              drop(v140_2);
              let v140_10: Space = if map_kernels::has_head(&(v140_9)) { singleton(&[]) } else { Space::new() };
              drop(v140_9);
              let v140_12: Space = if (&(v140_10)).is_empty() { Space::new() } else {
                let v142_11: Space = routine_14(c, &v87_8_cursor.path()[v87_8_origin..(v87_8_origin + 3)], &v87_8_cursor);
                map_map_kernels::compose(&(v140_10),&(v142_11))
              };
              drop(v140_10);
              let v140_13: Space = map_map_kernels::unite(&(v140_8),&(v140_12));
              join_wrapped_into(&mut v139_11_write,&((v140_13).read_zipper()),&[]);
              }
              v87_8_cursor.ascend(1);
            }
            drop(v139_11_write);
            map_map_kernels::compose(&(v134_10),&(v139_11))
          };
          drop(v134_10);
          let v134_13: Space = map_map_kernels::unite(&(v134_8),&(v134_12));
          join_wrapped_into(&mut v133_6_write,&((v134_13).read_zipper()),&[]);
          }
          v87_8_cursor.ascend(1);
        }
        drop(v133_6_write);
        map_map_kernels::compose(&(v132_5),&(v133_6))
      };
      drop(v132_5);
      let v132_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v132_2));
      drop(v132_2);
      let v132_9: Space = if map_kernels::has_head(&(v132_8)) { singleton(&[]) } else { Space::new() };
      drop(v132_8);
      let v132_11: Space = if (&(v132_9)).is_empty() { Space::new() } else {
        let mut v143_10 = Space::new();
        let mut v143_10_write = v143_10.write_zipper();
        for v143_10_byte in v87_8_cursor.child_mask().iter() {
          v87_8_cursor.descend_to_existing_byte(v143_10_byte);
          {
          let v144_2: Space = singleton(&v87_8_cursor.path()[(v87_8_origin + 1)..(v87_8_origin + 2)]);
          let v144_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v144_2));
          let v144_4: Space = if map_kernels::has_head(&(v144_3)) { singleton(&[]) } else { Space::new() };
          drop(v144_3);
          let v144_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v144_4));
          drop(v144_4);
          let v144_8: Space = if (&(v144_5)).is_empty() { Space::new() } else {
            let mut v145_7 = Space::new();
            let mut v145_7_write = v145_7.write_zipper();
            for v145_7_byte in v87_8_cursor.child_mask().iter() {
              v87_8_cursor.descend_to_existing_byte(v145_7_byte);
              {
              let v146_2: Space = singleton(&v87_8_cursor.path()[(v87_8_origin + 2)..(v87_8_origin + 3)]);
              let v146_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v146_2));
              let v146_4: Space = if map_kernels::has_head(&(v146_3)) { singleton(&[]) } else { Space::new() };
              drop(v146_3);
              let v146_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v146_4));
              drop(v146_4);
              let v146_8: Space = if (&(v146_5)).is_empty() { Space::new() } else {
                let v147_7: Space = routine_12(c, &v87_8_cursor.path()[v87_8_origin..(v87_8_origin + 3)], &v87_8_cursor);
                map_map_kernels::compose(&(v146_5),&(v147_7))
              };
              drop(v146_5);
              let v146_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v146_2));
              drop(v146_2);
              let v146_10: Space = if map_kernels::has_head(&(v146_9)) { singleton(&[]) } else { Space::new() };
              drop(v146_9);
              let v146_12: Space = if (&(v146_10)).is_empty() { Space::new() } else {
                let v148_11: Space = routine_13(c, &v87_8_cursor.path()[v87_8_origin..(v87_8_origin + 3)], &v87_8_cursor);
                map_map_kernels::compose(&(v146_10),&(v148_11))
              };
              drop(v146_10);
              let v146_13: Space = map_map_kernels::unite(&(v146_8),&(v146_12));
              join_wrapped_into(&mut v145_7_write,&((v146_13).read_zipper()),&[]);
              }
              v87_8_cursor.ascend(1);
            }
            drop(v145_7_write);
            map_map_kernels::compose(&(v144_5),&(v145_7))
          };
          drop(v144_5);
          let v144_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v144_2));
          drop(v144_2);
          let v144_10: Space = if map_kernels::has_head(&(v144_9)) { singleton(&[]) } else { Space::new() };
          drop(v144_9);
          let v144_12: Space = if (&(v144_10)).is_empty() { Space::new() } else {
            let v149_11: Space = view_map_kernels::subtract(&v87_8_cursor,&(*CONSTANT_5));
            map_map_kernels::compose(&(v144_10),&(v149_11))
          };
          drop(v144_10);
          let v144_13: Space = map_kernels::wrap(&(v144_12),&v87_8_cursor.path()[v87_8_origin..(v87_8_origin + 2)]);
          drop(v144_12);
          let v144_14: Space = map_map_kernels::unite(&(v144_8),&(v144_13));
          drop(v144_13);
          join_wrapped_into(&mut v143_10_write,&((v144_14).read_zipper()),&[]);
          }
          v87_8_cursor.ascend(1);
        }
        drop(v143_10_write);
        map_map_kernels::compose(&(v132_9),&(v143_10))
      };
      drop(v132_9);
      let v132_12: Space = map_map_kernels::unite(&(v132_7),&(v132_11));
      join_wrapped_into(&mut v87_8_write,&((v132_12).read_zipper()),&[]);
      }
      v87_8_cursor.ascend(1);
    }
    drop(v87_8_cursor);
    drop(v87_8_write);

((v87_3).clone(),(v87_4).clone(),(v87_5).clone(),(v87_8).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let v0_2: Space = routine_1(c, &((*CONSTANT_1).read_zipper()));
  let v0_3: Space = map_map_kernels::unite(&(*CONSTANT_0),&(v0_2));
  (&(descend_cursor((v0_3).read_zipper(),&(*CONSTANT_2)))).make_map()
}

fn routine_1(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let (mut v1_26,mut v1_48,mut v1_49,mut v1_73,) = native_block_0(c, s0);
  let v1_74: Space = map_map_kernels::unite(&(v1_49),&(v1_73));
  let mut v1_97 = Space::new();
  let mut v1_97_write = v1_97.write_zipper();
  let mut v1_97_cursor = descend_cursor(descend_cursor((*s0).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4));
  let v1_97_origin = v1_97_cursor.path().len();
  for v1_97_byte in v1_97_cursor.child_mask().iter() {
    v1_97_cursor.descend_to_existing_byte(v1_97_byte);
    {
    let v65_2: Space = singleton(&v1_97_cursor.path()[v1_97_origin..(v1_97_origin + 1)]);
    let v65_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v65_2));
    let v65_4: Space = if map_kernels::has_head(&(v65_3)) { singleton(&[]) } else { Space::new() };
    drop(v65_3);
    let v65_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v65_4));
    drop(v65_4);
    let v65_7: Space = if (&(v65_5)).is_empty() { Space::new() } else {
      let mut v66_6 = Space::new();
      let mut v66_6_write = v66_6.write_zipper();
      for v66_6_byte in v1_97_cursor.child_mask().iter() {
        v1_97_cursor.descend_to_existing_byte(v66_6_byte);
        {
        let v67_2: Space = singleton(&v1_97_cursor.path()[(v1_97_origin + 1)..(v1_97_origin + 2)]);
        let v67_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v67_2));
        let v67_4: Space = if map_kernels::has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
        drop(v67_3);
        let v67_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v67_4));
        drop(v67_4);
        let v67_8: Space = if (&(v67_5)).is_empty() { Space::new() } else {
          let mut v68_7 = Space::new();
          let mut v68_7_write = v68_7.write_zipper();
          for v68_7_byte in v1_97_cursor.child_mask().iter() {
            v1_97_cursor.descend_to_existing_byte(v68_7_byte);
            {
            let v69_2: Space = singleton(&v1_97_cursor.path()[(v1_97_origin + 2)..(v1_97_origin + 3)]);
            let v69_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v69_2));
            let v69_4: Space = if map_kernels::has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
            drop(v69_3);
            let v69_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v69_4));
            drop(v69_4);
            let v69_8: Space = if (&(v69_5)).is_empty() { Space::new() } else {
              let v70_7: Space = routine_15(c, &v1_97_cursor.path()[v1_97_origin..(v1_97_origin + 3)], &v1_97_cursor, &(*s0));
              map_map_kernels::compose(&(v69_5),&(v70_7))
            };
            drop(v69_5);
            let v69_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v69_2));
            drop(v69_2);
            let v69_10: Space = if map_kernels::has_head(&(v69_9)) { singleton(&[]) } else { Space::new() };
            drop(v69_9);
            let v69_12: Space = if (&(v69_10)).is_empty() { Space::new() } else {
              let v71_11: Space = routine_16(c, &v1_97_cursor.path()[v1_97_origin..(v1_97_origin + 3)], &v1_97_cursor, &(*s0));
              map_map_kernels::compose(&(v69_10),&(v71_11))
            };
            drop(v69_10);
            let v69_13: Space = map_map_kernels::unite(&(v69_8),&(v69_12));
            join_wrapped_into(&mut v68_7_write,&((v69_13).read_zipper()),&[]);
            }
            v1_97_cursor.ascend(1);
          }
          drop(v68_7_write);
          map_map_kernels::compose(&(v67_5),&(v68_7))
        };
        drop(v67_5);
        let v67_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v67_2));
        drop(v67_2);
        let v67_10: Space = if map_kernels::has_head(&(v67_9)) { singleton(&[]) } else { Space::new() };
        drop(v67_9);
        let v67_12: Space = if (&(v67_10)).is_empty() { Space::new() } else {
          let mut v72_11 = Space::new();
          let mut v72_11_write = v72_11.write_zipper();
          for v72_11_byte in v1_97_cursor.child_mask().iter() {
            v1_97_cursor.descend_to_existing_byte(v72_11_byte);
            {
            let v73_2: Space = singleton(&v1_97_cursor.path()[(v1_97_origin + 2)..(v1_97_origin + 3)]);
            let v73_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v73_2));
            let v73_4: Space = if map_kernels::has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
            drop(v73_3);
            let v73_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v73_4));
            drop(v73_4);
            let v73_8: Space = if (&(v73_5)).is_empty() { Space::new() } else {
              let v74_7: Space = routine_15(c, &v1_97_cursor.path()[v1_97_origin..(v1_97_origin + 3)], &v1_97_cursor, &(*s0));
              map_map_kernels::compose(&(v73_5),&(v74_7))
            };
            drop(v73_5);
            let v73_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v73_2));
            drop(v73_2);
            let v73_10: Space = if map_kernels::has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
            drop(v73_9);
            let v73_12: Space = if (&(v73_10)).is_empty() { Space::new() } else {
              let v75_11: Space = routine_17(c, &v1_97_cursor.path()[v1_97_origin..(v1_97_origin + 3)], &v1_97_cursor, &(*s0));
              map_map_kernels::compose(&(v73_10),&(v75_11))
            };
            drop(v73_10);
            let v73_13: Space = map_map_kernels::unite(&(v73_8),&(v73_12));
            join_wrapped_into(&mut v72_11_write,&((v73_13).read_zipper()),&[]);
            }
            v1_97_cursor.ascend(1);
          }
          drop(v72_11_write);
          map_map_kernels::compose(&(v67_10),&(v72_11))
        };
        drop(v67_10);
        let v67_13: Space = map_map_kernels::unite(&(v67_8),&(v67_12));
        join_wrapped_into(&mut v66_6_write,&((v67_13).read_zipper()),&[]);
        }
        v1_97_cursor.ascend(1);
      }
      drop(v66_6_write);
      map_map_kernels::compose(&(v65_5),&(v66_6))
    };
    drop(v65_5);
    let v65_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v65_2));
    drop(v65_2);
    let v65_9: Space = if map_kernels::has_head(&(v65_8)) { singleton(&[]) } else { Space::new() };
    drop(v65_8);
    let v65_11: Space = if (&(v65_9)).is_empty() { Space::new() } else {
      let mut v76_10 = Space::new();
      let mut v76_10_write = v76_10.write_zipper();
      for v76_10_byte in v1_97_cursor.child_mask().iter() {
        v1_97_cursor.descend_to_existing_byte(v76_10_byte);
        {
        let v77_2: Space = singleton(&v1_97_cursor.path()[(v1_97_origin + 1)..(v1_97_origin + 2)]);
        let v77_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v77_2));
        let v77_4: Space = if map_kernels::has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
        drop(v77_3);
        let v77_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v77_4));
        drop(v77_4);
        let v77_8: Space = if (&(v77_5)).is_empty() { Space::new() } else {
          let mut v78_7 = Space::new();
          let mut v78_7_write = v78_7.write_zipper();
          for v78_7_byte in v1_97_cursor.child_mask().iter() {
            v1_97_cursor.descend_to_existing_byte(v78_7_byte);
            {
            let v79_2: Space = singleton(&v1_97_cursor.path()[(v1_97_origin + 2)..(v1_97_origin + 3)]);
            let v79_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v79_2));
            let v79_4: Space = if map_kernels::has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
            drop(v79_3);
            let v79_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v79_4));
            drop(v79_4);
            let v79_8: Space = if (&(v79_5)).is_empty() { Space::new() } else {
              let v80_7: Space = routine_15(c, &v1_97_cursor.path()[v1_97_origin..(v1_97_origin + 3)], &v1_97_cursor, &(*s0));
              map_map_kernels::compose(&(v79_5),&(v80_7))
            };
            drop(v79_5);
            let v79_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v79_2));
            drop(v79_2);
            let v79_10: Space = if map_kernels::has_head(&(v79_9)) { singleton(&[]) } else { Space::new() };
            drop(v79_9);
            let v79_12: Space = if (&(v79_10)).is_empty() { Space::new() } else {
              let v81_11: Space = routine_16(c, &v1_97_cursor.path()[v1_97_origin..(v1_97_origin + 3)], &v1_97_cursor, &(*s0));
              map_map_kernels::compose(&(v79_10),&(v81_11))
            };
            drop(v79_10);
            let v79_13: Space = map_map_kernels::unite(&(v79_8),&(v79_12));
            join_wrapped_into(&mut v78_7_write,&((v79_13).read_zipper()),&[]);
            }
            v1_97_cursor.ascend(1);
          }
          drop(v78_7_write);
          map_map_kernels::compose(&(v77_5),&(v78_7))
        };
        drop(v77_5);
        let v77_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v77_2));
        drop(v77_2);
        let v77_10: Space = if map_kernels::has_head(&(v77_9)) { singleton(&[]) } else { Space::new() };
        drop(v77_9);
        let v77_12: Space = if (&(v77_10)).is_empty() { Space::new() } else {
          let mut v82_11 = Space::new();
          let mut v82_11_write = v82_11.write_zipper();
          for v82_11_byte in v1_97_cursor.child_mask().iter() {
            v1_97_cursor.descend_to_existing_byte(v82_11_byte);
            {
            let v83_2: Space = singleton(&v1_97_cursor.path()[(v1_97_origin + 2)..(v1_97_origin + 3)]);
            let v83_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v83_2));
            let v83_4: Space = if map_kernels::has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
            drop(v83_3);
            let v83_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v83_4));
            drop(v83_4);
            let v83_7: Space = if (&(v83_5)).is_empty() { Space::new() } else {
              let v84_6: Space = routine_18(c, &v1_97_cursor.path()[(v1_97_origin + 2)..(v1_97_origin + 3)], &v1_97_cursor, &(*s0));
              map_map_kernels::compose(&(v83_5),&(v84_6))
            };
            drop(v83_5);
            let v83_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v83_2));
            drop(v83_2);
            let v83_9: Space = if map_kernels::has_head(&(v83_8)) { singleton(&[]) } else { Space::new() };
            drop(v83_8);
            let v83_11: Space = if (&(v83_9)).is_empty() { Space::new() } else {
              let v85_10: Space = routine_19(c, &v1_97_cursor.path()[(v1_97_origin + 2)..(v1_97_origin + 3)], &v1_97_cursor, &(*s0));
              map_map_kernels::compose(&(v83_9),&(v85_10))
            };
            drop(v83_9);
            let v83_12: Space = map_map_kernels::unite(&(v83_7),&(v83_11));
            join_wrapped_into(&mut v82_11_write,&((v83_12).read_zipper()),&[]);
            }
            v1_97_cursor.ascend(1);
          }
          drop(v82_11_write);
          map_map_kernels::compose(&(v77_10),&(v82_11))
        };
        drop(v77_10);
        let v77_13: Space = map_kernels::wrap(&(v77_12),&v1_97_cursor.path()[v1_97_origin..(v1_97_origin + 2)]);
        let v77_14: Space = map_map_kernels::unite(&(v77_8),&(v77_13));
        join_wrapped_into(&mut v76_10_write,&((v77_14).read_zipper()),&[]);
        }
        v1_97_cursor.ascend(1);
      }
      drop(v76_10_write);
      map_map_kernels::compose(&(v65_9),&(v76_10))
    };
    drop(v65_9);
    let v65_12: Space = map_map_kernels::unite(&(v65_7),&(v65_11));
    join_wrapped_into(&mut v1_97_write,&((v65_12).read_zipper()),&[]);
    }
    v1_97_cursor.ascend(1);
  }
  drop(v1_97_cursor);
  drop(v1_97_write);
  let v1_98: Space = map_map_kernels::unite(&(v1_74),&(v1_97));
  let v1_101: Space = map_view_kernels::subtract(&(v1_98),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_2))));
  let v1_104: Space = map_view_kernels::subtract(&(v1_101),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_9))));
  let v1_105: Space = map_kernels::wrap(&(v1_104),&(*CONSTANT_9));
  let v1_106: Space = view_view_kernels::unite(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_3))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_7))));
  let v1_107: Space = map_kernels::wrap(&(v1_106),&(*CONSTANT_7));
  drop(v1_106);
  let v1_108: Space = map_map_kernels::unite(&(v1_105),&(v1_107));
  drop(v1_107);
  let v1_109: Space = map_view_kernels::unite(&(v1_108),&(*s0));
  let mut v1_192: Space = (v1_109).clone();
  loop {
    let (mut v87_3,mut v87_4,mut v87_5,mut v87_8,) = native_block_1(c, &v1_192);
    let v87_9: Space = map_map_kernels::unite(&(v87_5),&(v87_8));
    let mut v87_11 = Space::new();
    let mut v87_11_write = v87_11.write_zipper();
    let mut v87_11_cursor = descend_cursor(descend_cursor((v1_192).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4));
    let v87_11_origin = v87_11_cursor.path().len();
    for v87_11_byte in v87_11_cursor.child_mask().iter() {
      v87_11_cursor.descend_to_existing_byte(v87_11_byte);
      {
      let v151_2: Space = singleton(&v87_11_cursor.path()[v87_11_origin..(v87_11_origin + 1)]);
      let v151_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v151_2));
      let v151_4: Space = if map_kernels::has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
      drop(v151_3);
      let v151_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v151_4));
      drop(v151_4);
      let v151_7: Space = if (&(v151_5)).is_empty() { Space::new() } else {
        let mut v152_6 = Space::new();
        let mut v152_6_write = v152_6.write_zipper();
        for v152_6_byte in v87_11_cursor.child_mask().iter() {
          v87_11_cursor.descend_to_existing_byte(v152_6_byte);
          {
          let v153_2: Space = singleton(&v87_11_cursor.path()[(v87_11_origin + 1)..(v87_11_origin + 2)]);
          let v153_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v153_2));
          let v153_4: Space = if map_kernels::has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
          drop(v153_3);
          let v153_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v153_4));
          drop(v153_4);
          let v153_8: Space = if (&(v153_5)).is_empty() { Space::new() } else {
            let mut v154_7 = Space::new();
            let mut v154_7_write = v154_7.write_zipper();
            for v154_7_byte in v87_11_cursor.child_mask().iter() {
              v87_11_cursor.descend_to_existing_byte(v154_7_byte);
              {
              let v155_2: Space = singleton(&v87_11_cursor.path()[(v87_11_origin + 2)..(v87_11_origin + 3)]);
              let v155_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v155_2));
              let v155_4: Space = if map_kernels::has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
              drop(v155_3);
              let v155_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v155_4));
              drop(v155_4);
              let v155_8: Space = if (&(v155_5)).is_empty() { Space::new() } else {
                let v156_7: Space = routine_15(c, &v87_11_cursor.path()[v87_11_origin..(v87_11_origin + 3)], &v87_11_cursor, &((v1_192).read_zipper()));
                map_map_kernels::compose(&(v155_5),&(v156_7))
              };
              drop(v155_5);
              let v155_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v155_2));
              drop(v155_2);
              let v155_10: Space = if map_kernels::has_head(&(v155_9)) { singleton(&[]) } else { Space::new() };
              drop(v155_9);
              let v155_12: Space = if (&(v155_10)).is_empty() { Space::new() } else {
                let v157_11: Space = routine_16(c, &v87_11_cursor.path()[v87_11_origin..(v87_11_origin + 3)], &v87_11_cursor, &((v1_192).read_zipper()));
                map_map_kernels::compose(&(v155_10),&(v157_11))
              };
              drop(v155_10);
              let v155_13: Space = map_map_kernels::unite(&(v155_8),&(v155_12));
              join_wrapped_into(&mut v154_7_write,&((v155_13).read_zipper()),&[]);
              }
              v87_11_cursor.ascend(1);
            }
            drop(v154_7_write);
            map_map_kernels::compose(&(v153_5),&(v154_7))
          };
          drop(v153_5);
          let v153_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v153_2));
          drop(v153_2);
          let v153_10: Space = if map_kernels::has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
          drop(v153_9);
          let v153_12: Space = if (&(v153_10)).is_empty() { Space::new() } else {
            let mut v158_11 = Space::new();
            let mut v158_11_write = v158_11.write_zipper();
            for v158_11_byte in v87_11_cursor.child_mask().iter() {
              v87_11_cursor.descend_to_existing_byte(v158_11_byte);
              {
              let v159_2: Space = singleton(&v87_11_cursor.path()[(v87_11_origin + 2)..(v87_11_origin + 3)]);
              let v159_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v159_2));
              let v159_4: Space = if map_kernels::has_head(&(v159_3)) { singleton(&[]) } else { Space::new() };
              drop(v159_3);
              let v159_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v159_4));
              drop(v159_4);
              let v159_8: Space = if (&(v159_5)).is_empty() { Space::new() } else {
                let v160_7: Space = routine_15(c, &v87_11_cursor.path()[v87_11_origin..(v87_11_origin + 3)], &v87_11_cursor, &((v1_192).read_zipper()));
                map_map_kernels::compose(&(v159_5),&(v160_7))
              };
              drop(v159_5);
              let v159_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v159_2));
              drop(v159_2);
              let v159_10: Space = if map_kernels::has_head(&(v159_9)) { singleton(&[]) } else { Space::new() };
              drop(v159_9);
              let v159_12: Space = if (&(v159_10)).is_empty() { Space::new() } else {
                let v161_11: Space = routine_17(c, &v87_11_cursor.path()[v87_11_origin..(v87_11_origin + 3)], &v87_11_cursor, &((v1_192).read_zipper()));
                map_map_kernels::compose(&(v159_10),&(v161_11))
              };
              drop(v159_10);
              let v159_13: Space = map_map_kernels::unite(&(v159_8),&(v159_12));
              join_wrapped_into(&mut v158_11_write,&((v159_13).read_zipper()),&[]);
              }
              v87_11_cursor.ascend(1);
            }
            drop(v158_11_write);
            map_map_kernels::compose(&(v153_10),&(v158_11))
          };
          drop(v153_10);
          let v153_13: Space = map_map_kernels::unite(&(v153_8),&(v153_12));
          join_wrapped_into(&mut v152_6_write,&((v153_13).read_zipper()),&[]);
          }
          v87_11_cursor.ascend(1);
        }
        drop(v152_6_write);
        map_map_kernels::compose(&(v151_5),&(v152_6))
      };
      drop(v151_5);
      let v151_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v151_2));
      drop(v151_2);
      let v151_9: Space = if map_kernels::has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
      drop(v151_8);
      let v151_11: Space = if (&(v151_9)).is_empty() { Space::new() } else {
        let mut v162_10 = Space::new();
        let mut v162_10_write = v162_10.write_zipper();
        for v162_10_byte in v87_11_cursor.child_mask().iter() {
          v87_11_cursor.descend_to_existing_byte(v162_10_byte);
          {
          let v163_2: Space = singleton(&v87_11_cursor.path()[(v87_11_origin + 1)..(v87_11_origin + 2)]);
          let v163_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v163_2));
          let v163_4: Space = if map_kernels::has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
          drop(v163_3);
          let v163_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v163_4));
          drop(v163_4);
          let v163_8: Space = if (&(v163_5)).is_empty() { Space::new() } else {
            let mut v164_7 = Space::new();
            let mut v164_7_write = v164_7.write_zipper();
            for v164_7_byte in v87_11_cursor.child_mask().iter() {
              v87_11_cursor.descend_to_existing_byte(v164_7_byte);
              {
              let v165_2: Space = singleton(&v87_11_cursor.path()[(v87_11_origin + 2)..(v87_11_origin + 3)]);
              let v165_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v165_2));
              let v165_4: Space = if map_kernels::has_head(&(v165_3)) { singleton(&[]) } else { Space::new() };
              drop(v165_3);
              let v165_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v165_4));
              drop(v165_4);
              let v165_8: Space = if (&(v165_5)).is_empty() { Space::new() } else {
                let v166_7: Space = routine_15(c, &v87_11_cursor.path()[v87_11_origin..(v87_11_origin + 3)], &v87_11_cursor, &((v1_192).read_zipper()));
                map_map_kernels::compose(&(v165_5),&(v166_7))
              };
              drop(v165_5);
              let v165_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v165_2));
              drop(v165_2);
              let v165_10: Space = if map_kernels::has_head(&(v165_9)) { singleton(&[]) } else { Space::new() };
              drop(v165_9);
              let v165_12: Space = if (&(v165_10)).is_empty() { Space::new() } else {
                let v167_11: Space = routine_16(c, &v87_11_cursor.path()[v87_11_origin..(v87_11_origin + 3)], &v87_11_cursor, &((v1_192).read_zipper()));
                map_map_kernels::compose(&(v165_10),&(v167_11))
              };
              drop(v165_10);
              let v165_13: Space = map_map_kernels::unite(&(v165_8),&(v165_12));
              join_wrapped_into(&mut v164_7_write,&((v165_13).read_zipper()),&[]);
              }
              v87_11_cursor.ascend(1);
            }
            drop(v164_7_write);
            map_map_kernels::compose(&(v163_5),&(v164_7))
          };
          drop(v163_5);
          let v163_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v163_2));
          drop(v163_2);
          let v163_10: Space = if map_kernels::has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
          drop(v163_9);
          let v163_12: Space = if (&(v163_10)).is_empty() { Space::new() } else {
            let mut v168_11 = Space::new();
            let mut v168_11_write = v168_11.write_zipper();
            for v168_11_byte in v87_11_cursor.child_mask().iter() {
              v87_11_cursor.descend_to_existing_byte(v168_11_byte);
              {
              let v169_2: Space = singleton(&v87_11_cursor.path()[(v87_11_origin + 2)..(v87_11_origin + 3)]);
              let v169_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v169_2));
              let v169_4: Space = if map_kernels::has_head(&(v169_3)) { singleton(&[]) } else { Space::new() };
              drop(v169_3);
              let v169_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v169_4));
              drop(v169_4);
              let v169_7: Space = if (&(v169_5)).is_empty() { Space::new() } else {
                let v170_6: Space = routine_18(c, &v87_11_cursor.path()[(v87_11_origin + 2)..(v87_11_origin + 3)], &v87_11_cursor, &((v1_192).read_zipper()));
                map_map_kernels::compose(&(v169_5),&(v170_6))
              };
              drop(v169_5);
              let v169_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v169_2));
              drop(v169_2);
              let v169_9: Space = if map_kernels::has_head(&(v169_8)) { singleton(&[]) } else { Space::new() };
              drop(v169_8);
              let v169_11: Space = if (&(v169_9)).is_empty() { Space::new() } else {
                let v171_10: Space = routine_19(c, &v87_11_cursor.path()[(v87_11_origin + 2)..(v87_11_origin + 3)], &v87_11_cursor, &((v1_192).read_zipper()));
                map_map_kernels::compose(&(v169_9),&(v171_10))
              };
              drop(v169_9);
              let v169_12: Space = map_map_kernels::unite(&(v169_7),&(v169_11));
              join_wrapped_into(&mut v168_11_write,&((v169_12).read_zipper()),&[]);
              }
              v87_11_cursor.ascend(1);
            }
            drop(v168_11_write);
            map_map_kernels::compose(&(v163_10),&(v168_11))
          };
          drop(v163_10);
          let v163_13: Space = map_kernels::wrap(&(v163_12),&v87_11_cursor.path()[v87_11_origin..(v87_11_origin + 2)]);
          let v163_14: Space = map_map_kernels::unite(&(v163_8),&(v163_13));
          join_wrapped_into(&mut v162_10_write,&((v163_14).read_zipper()),&[]);
          }
          v87_11_cursor.ascend(1);
        }
        drop(v162_10_write);
        map_map_kernels::compose(&(v151_9),&(v162_10))
      };
      drop(v151_9);
      let v151_12: Space = map_map_kernels::unite(&(v151_7),&(v151_11));
      join_wrapped_into(&mut v87_11_write,&((v151_12).read_zipper()),&[]);
      }
      v87_11_cursor.ascend(1);
    }
    drop(v87_11_cursor);
    drop(v87_11_write);
    let v87_12: Space = map_map_kernels::unite(&(v87_9),&(v87_11));
    let v87_14: Space = map_view_kernels::subtract(&(v87_12),&(descend_cursor((v1_192).read_zipper(),&(*CONSTANT_2))));
    let v87_16: Space = map_view_kernels::subtract(&(v87_14),&(descend_cursor((v1_192).read_zipper(),&(*CONSTANT_9))));
    let v87_17: Space = map_kernels::wrap(&(v87_16),&(*CONSTANT_9));
    let v87_18: Space = view_view_kernels::unite(&(descend_cursor((v1_192).read_zipper(),&(*CONSTANT_3))),&(descend_cursor((v1_192).read_zipper(),&(*CONSTANT_7))));
    let v87_19: Space = map_kernels::wrap(&(v87_18),&(*CONSTANT_7));
    drop(v87_18);
    let v87_20: Space = map_map_kernels::unite(&(v87_17),&(v87_19));
    drop(v87_19);
    let v87_21: Space = map_map_kernels::unite(&(v87_20),&(v1_192));
    if !v1_192.join_into((v87_21).clone()).is_element() { break; }
  }
  let v1_193: Space = view_map_kernels::unite(&(*s0),&(v1_192));
  (v1_193).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v173_24 = Space::new();
  let mut v173_24_write = v173_24.write_zipper();
  let mut v173_24_cursor = (*s0).read_zipper();
  let v173_24_origin = v173_24_cursor.path().len();
  for v173_24_byte in v173_24_cursor.child_mask().iter() {
    v173_24_cursor.descend_to_existing_byte(v173_24_byte);
    {
    let v174_2: Space = singleton(&v173_24_cursor.path()[v173_24_origin..(v173_24_origin + 1)]);
    let v174_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v174_2));
    let v174_4: Space = if map_kernels::has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
    drop(v174_3);
    let v174_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v174_4));
    drop(v174_4);
    let v174_8: Space = if (&(v174_5)).is_empty() { Space::new() } else {
      let v175_6: Path = concat_path(&(*p0),&v173_24_cursor.path()[v173_24_origin..(v173_24_origin + 1)]);
      let mut v175_7 = Space::new();
      let mut v175_7_write = v175_7.write_zipper();
      for v175_7_byte in v173_24_cursor.child_mask().iter() {
        v173_24_cursor.descend_to_existing_byte(v175_7_byte);
        {
        let v176_2: Space = singleton(&v173_24_cursor.path()[(v173_24_origin + 1)..(v173_24_origin + 2)]);
        let v176_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v176_2));
        let v176_4: Space = if map_kernels::has_head(&(v176_3)) { singleton(&[]) } else { Space::new() };
        drop(v176_3);
        let v176_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v176_4));
        drop(v176_4);
        let v176_8: Space = if (&(v176_5)).is_empty() { Space::new() } else {
          let v177_6: Path = concat_path(&(v175_6),&v173_24_cursor.path()[(v173_24_origin + 1)..(v173_24_origin + 2)]);
          let mut v177_7 = Space::new();
          let mut v177_7_write = v177_7.write_zipper();
          for v177_7_byte in v173_24_cursor.child_mask().iter() {
            v173_24_cursor.descend_to_existing_byte(v177_7_byte);
            {
            let v178_2: Space = singleton(&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
            let v178_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v178_2));
            let v178_4: Space = if map_kernels::has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
            drop(v178_3);
            let v178_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v178_4));
            drop(v178_4);
            let v178_8: Space = if (&(v178_5)).is_empty() { Space::new() } else {
              let v179_6: Path = concat_path(&(v177_6),&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
              let v179_7: Space = routine_20(c, &(v179_6), &v173_24_cursor, &(*s1));
              map_map_kernels::compose(&(v178_5),&(v179_7))
            };
            drop(v178_5);
            let v178_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v178_2));
            drop(v178_2);
            let v178_10: Space = if map_kernels::has_head(&(v178_9)) { singleton(&[]) } else { Space::new() };
            drop(v178_9);
            let v178_12: Space = if (&(v178_10)).is_empty() { Space::new() } else {
              let v180_6: Path = concat_path(&(v177_6),&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
              let v180_11: Space = routine_21(c, &(v180_6), &v173_24_cursor, &(*s1));
              drop(v180_6);
              map_map_kernels::compose(&(v178_10),&(v180_11))
            };
            drop(v178_10);
            let v178_13: Space = map_map_kernels::unite(&(v178_8),&(v178_12));
            join_wrapped_into(&mut v177_7_write,&((v178_13).read_zipper()),&[]);
            }
            v173_24_cursor.ascend(1);
          }
          drop(v177_7_write);
          map_map_kernels::compose(&(v176_5),&(v177_7))
        };
        drop(v176_5);
        let v176_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v176_2));
        drop(v176_2);
        let v176_10: Space = if map_kernels::has_head(&(v176_9)) { singleton(&[]) } else { Space::new() };
        drop(v176_9);
        let v176_12: Space = if (&(v176_10)).is_empty() { Space::new() } else {
          let v181_6: Path = concat_path(&(v175_6),&v173_24_cursor.path()[(v173_24_origin + 1)..(v173_24_origin + 2)]);
          let mut v181_11 = Space::new();
          let mut v181_11_write = v181_11.write_zipper();
          for v181_11_byte in v173_24_cursor.child_mask().iter() {
            v173_24_cursor.descend_to_existing_byte(v181_11_byte);
            {
            let v182_2: Space = singleton(&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
            let v182_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v182_2));
            let v182_4: Space = if map_kernels::has_head(&(v182_3)) { singleton(&[]) } else { Space::new() };
            drop(v182_3);
            let v182_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v182_4));
            drop(v182_4);
            let v182_8: Space = if (&(v182_5)).is_empty() { Space::new() } else {
              let v183_6: Path = concat_path(&(v181_6),&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
              let v183_7: Space = routine_20(c, &(v183_6), &v173_24_cursor, &(*s1));
              map_map_kernels::compose(&(v182_5),&(v183_7))
            };
            drop(v182_5);
            let v182_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v182_2));
            drop(v182_2);
            let v182_10: Space = if map_kernels::has_head(&(v182_9)) { singleton(&[]) } else { Space::new() };
            drop(v182_9);
            let v182_12: Space = if (&(v182_10)).is_empty() { Space::new() } else {
              let v184_6: Path = concat_path(&(v181_6),&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
              let v184_11: Space = routine_4(c, &(v184_6), &v173_24_cursor, &(*s1));
              drop(v184_6);
              map_map_kernels::compose(&(v182_10),&(v184_11))
            };
            drop(v182_10);
            let v182_13: Space = map_map_kernels::unite(&(v182_8),&(v182_12));
            join_wrapped_into(&mut v181_11_write,&((v182_13).read_zipper()),&[]);
            }
            v173_24_cursor.ascend(1);
          }
          drop(v181_11_write);
          drop(v181_6);
          map_map_kernels::compose(&(v176_10),&(v181_11))
        };
        drop(v176_10);
        let v176_13: Space = map_map_kernels::unite(&(v176_8),&(v176_12));
        join_wrapped_into(&mut v175_7_write,&((v176_13).read_zipper()),&[]);
        }
        v173_24_cursor.ascend(1);
      }
      drop(v175_7_write);
      map_map_kernels::compose(&(v174_5),&(v175_7))
    };
    drop(v174_5);
    let v174_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v174_2));
    drop(v174_2);
    let v174_10: Space = if map_kernels::has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
    drop(v174_9);
    let v174_12: Space = if (&(v174_10)).is_empty() { Space::new() } else {
      let v185_6: Path = concat_path(&(*p0),&v173_24_cursor.path()[v173_24_origin..(v173_24_origin + 1)]);
      let mut v185_11 = Space::new();
      let mut v185_11_write = v185_11.write_zipper();
      for v185_11_byte in v173_24_cursor.child_mask().iter() {
        v173_24_cursor.descend_to_existing_byte(v185_11_byte);
        {
        let v186_2: Space = singleton(&v173_24_cursor.path()[(v173_24_origin + 1)..(v173_24_origin + 2)]);
        let v186_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v186_2));
        let v186_4: Space = if map_kernels::has_head(&(v186_3)) { singleton(&[]) } else { Space::new() };
        drop(v186_3);
        let v186_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v186_4));
        drop(v186_4);
        let v186_8: Space = if (&(v186_5)).is_empty() { Space::new() } else {
          let v187_6: Path = concat_path(&(v185_6),&v173_24_cursor.path()[(v173_24_origin + 1)..(v173_24_origin + 2)]);
          let mut v187_7 = Space::new();
          let mut v187_7_write = v187_7.write_zipper();
          for v187_7_byte in v173_24_cursor.child_mask().iter() {
            v173_24_cursor.descend_to_existing_byte(v187_7_byte);
            {
            let v188_2: Space = singleton(&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
            let v188_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v188_2));
            let v188_4: Space = if map_kernels::has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
            drop(v188_3);
            let v188_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v188_4));
            drop(v188_4);
            let v188_8: Space = if (&(v188_5)).is_empty() { Space::new() } else {
              let v189_6: Path = concat_path(&(v187_6),&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
              let v189_7: Space = routine_20(c, &(v189_6), &v173_24_cursor, &(*s1));
              map_map_kernels::compose(&(v188_5),&(v189_7))
            };
            drop(v188_5);
            let v188_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v188_2));
            drop(v188_2);
            let v188_10: Space = if map_kernels::has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
            drop(v188_9);
            let v188_12: Space = if (&(v188_10)).is_empty() { Space::new() } else {
              let v190_6: Path = concat_path(&(v187_6),&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
              let v190_11: Space = routine_21(c, &(v190_6), &v173_24_cursor, &(*s1));
              drop(v190_6);
              map_map_kernels::compose(&(v188_10),&(v190_11))
            };
            drop(v188_10);
            let v188_13: Space = map_map_kernels::unite(&(v188_8),&(v188_12));
            join_wrapped_into(&mut v187_7_write,&((v188_13).read_zipper()),&[]);
            }
            v173_24_cursor.ascend(1);
          }
          drop(v187_7_write);
          map_map_kernels::compose(&(v186_5),&(v187_7))
        };
        drop(v186_5);
        let v186_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v186_2));
        drop(v186_2);
        let v186_10: Space = if map_kernels::has_head(&(v186_9)) { singleton(&[]) } else { Space::new() };
        drop(v186_9);
        let v186_12: Space = if (&(v186_10)).is_empty() { Space::new() } else {
          let mut v191_11 = Space::new();
          let mut v191_11_write = v191_11.write_zipper();
          for v191_11_byte in v173_24_cursor.child_mask().iter() {
            v173_24_cursor.descend_to_existing_byte(v191_11_byte);
            {
            let v192_2: Space = singleton(&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
            let v192_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v192_2));
            let v192_4: Space = if map_kernels::has_head(&(v192_3)) { singleton(&[]) } else { Space::new() };
            drop(v192_3);
            let v192_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v192_4));
            drop(v192_4);
            let v192_7: Space = if (&(v192_5)).is_empty() { Space::new() } else {
              let v193_6: Space = routine_5(c, &v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)], &v173_24_cursor, &(*s1));
              map_map_kernels::compose(&(v192_5),&(v193_6))
            };
            drop(v192_5);
            let v192_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v192_2));
            drop(v192_2);
            let v192_9: Space = if map_kernels::has_head(&(v192_8)) { singleton(&[]) } else { Space::new() };
            drop(v192_8);
            let v192_11: Space = if (&(v192_9)).is_empty() { Space::new() } else {
              let v194_10: Space = routine_6(c, &v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)], &v173_24_cursor, &(*s1));
              map_map_kernels::compose(&(v192_9),&(v194_10))
            };
            drop(v192_9);
            let v192_12: Space = map_map_kernels::unite(&(v192_7),&(v192_11));
            join_wrapped_into(&mut v191_11_write,&((v192_12).read_zipper()),&[]);
            }
            v173_24_cursor.ascend(1);
          }
          drop(v191_11_write);
          map_map_kernels::compose(&(v186_10),&(v191_11))
        };
        drop(v186_10);
        let v195_6: Path = concat_path(&(v185_6),&v173_24_cursor.path()[(v173_24_origin + 1)..(v173_24_origin + 2)]);
        let v186_13: Space = map_kernels::wrap(&(v186_12),&(v195_6));
        let v186_14: Space = map_map_kernels::unite(&(v186_8),&(v186_13));
        join_wrapped_into(&mut v185_11_write,&((v186_14).read_zipper()),&[]);
        }
        v173_24_cursor.ascend(1);
      }
      drop(v185_11_write);
      drop(v185_6);
      map_map_kernels::compose(&(v174_10),&(v185_11))
    };
    drop(v174_10);
    let v174_13: Space = map_map_kernels::unite(&(v174_8),&(v174_12));
    join_wrapped_into(&mut v173_24_write,&((v174_13).read_zipper()),&[]);
    }
    v173_24_cursor.ascend(1);
  }
  drop(v173_24_cursor);
  drop(v173_24_write);
  (v173_24).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v196_24 = Space::new();
  let mut v196_24_write = v196_24.write_zipper();
  let mut v196_24_cursor = (*s0).read_zipper();
  let v196_24_origin = v196_24_cursor.path().len();
  for v196_24_byte in v196_24_cursor.child_mask().iter() {
    v196_24_cursor.descend_to_existing_byte(v196_24_byte);
    {
    let v197_2: Space = singleton(&v196_24_cursor.path()[v196_24_origin..(v196_24_origin + 1)]);
    let v197_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v197_2));
    let v197_4: Space = if map_kernels::has_head(&(v197_3)) { singleton(&[]) } else { Space::new() };
    drop(v197_3);
    let v197_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v197_4));
    drop(v197_4);
    let v197_8: Space = if (&(v197_5)).is_empty() { Space::new() } else {
      let v198_6: Path = concat_path(&(*p0),&v196_24_cursor.path()[v196_24_origin..(v196_24_origin + 1)]);
      let mut v198_7 = Space::new();
      let mut v198_7_write = v198_7.write_zipper();
      for v198_7_byte in v196_24_cursor.child_mask().iter() {
        v196_24_cursor.descend_to_existing_byte(v198_7_byte);
        {
        let v199_2: Space = singleton(&v196_24_cursor.path()[(v196_24_origin + 1)..(v196_24_origin + 2)]);
        let v199_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v199_2));
        let v199_4: Space = if map_kernels::has_head(&(v199_3)) { singleton(&[]) } else { Space::new() };
        drop(v199_3);
        let v199_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v199_4));
        drop(v199_4);
        let v199_8: Space = if (&(v199_5)).is_empty() { Space::new() } else {
          let v200_6: Path = concat_path(&(v198_6),&v196_24_cursor.path()[(v196_24_origin + 1)..(v196_24_origin + 2)]);
          let mut v200_7 = Space::new();
          let mut v200_7_write = v200_7.write_zipper();
          for v200_7_byte in v196_24_cursor.child_mask().iter() {
            v196_24_cursor.descend_to_existing_byte(v200_7_byte);
            {
            let v201_2: Space = singleton(&v196_24_cursor.path()[(v196_24_origin + 2)..(v196_24_origin + 3)]);
            let v201_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v201_2));
            let v201_4: Space = if map_kernels::has_head(&(v201_3)) { singleton(&[]) } else { Space::new() };
            drop(v201_3);
            let v201_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v201_4));
            drop(v201_4);
            let v201_8: Space = if (&(v201_5)).is_empty() { Space::new() } else {
              let v202_6: Path = concat_path(&(v200_6),&v196_24_cursor.path()[(v196_24_origin + 2)..(v196_24_origin + 3)]);
              let v202_7: Space = routine_20(c, &(v202_6), &v196_24_cursor, &(*s1));
              map_map_kernels::compose(&(v201_5),&(v202_7))
            };
            drop(v201_5);
            let v201_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v201_2));
            drop(v201_2);
            let v201_10: Space = if map_kernels::has_head(&(v201_9)) { singleton(&[]) } else { Space::new() };
            drop(v201_9);
            let v201_12: Space = if (&(v201_10)).is_empty() { Space::new() } else {
              let v203_6: Path = concat_path(&(v200_6),&v196_24_cursor.path()[(v196_24_origin + 2)..(v196_24_origin + 3)]);
              let v203_11: Space = routine_21(c, &(v203_6), &v196_24_cursor, &(*s1));
              drop(v203_6);
              map_map_kernels::compose(&(v201_10),&(v203_11))
            };
            drop(v201_10);
            let v201_13: Space = map_map_kernels::unite(&(v201_8),&(v201_12));
            join_wrapped_into(&mut v200_7_write,&((v201_13).read_zipper()),&[]);
            }
            v196_24_cursor.ascend(1);
          }
          drop(v200_7_write);
          map_map_kernels::compose(&(v199_5),&(v200_7))
        };
        drop(v199_5);
        let v199_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v199_2));
        drop(v199_2);
        let v199_10: Space = if map_kernels::has_head(&(v199_9)) { singleton(&[]) } else { Space::new() };
        drop(v199_9);
        let v199_12: Space = if (&(v199_10)).is_empty() { Space::new() } else {
          let v204_6: Path = concat_path(&(v198_6),&v196_24_cursor.path()[(v196_24_origin + 1)..(v196_24_origin + 2)]);
          let mut v204_11 = Space::new();
          let mut v204_11_write = v204_11.write_zipper();
          for v204_11_byte in v196_24_cursor.child_mask().iter() {
            v196_24_cursor.descend_to_existing_byte(v204_11_byte);
            {
            let v205_2: Space = singleton(&v196_24_cursor.path()[(v196_24_origin + 2)..(v196_24_origin + 3)]);
            let v205_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v205_2));
            let v205_4: Space = if map_kernels::has_head(&(v205_3)) { singleton(&[]) } else { Space::new() };
            drop(v205_3);
            let v205_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v205_4));
            drop(v205_4);
            let v205_8: Space = if (&(v205_5)).is_empty() { Space::new() } else {
              let v206_6: Path = concat_path(&(v204_6),&v196_24_cursor.path()[(v196_24_origin + 2)..(v196_24_origin + 3)]);
              let v206_7: Space = routine_20(c, &(v206_6), &v196_24_cursor, &(*s1));
              map_map_kernels::compose(&(v205_5),&(v206_7))
            };
            drop(v205_5);
            let v205_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v205_2));
            drop(v205_2);
            let v205_10: Space = if map_kernels::has_head(&(v205_9)) { singleton(&[]) } else { Space::new() };
            drop(v205_9);
            let v205_12: Space = if (&(v205_10)).is_empty() { Space::new() } else {
              let v207_6: Path = concat_path(&(v204_6),&v196_24_cursor.path()[(v196_24_origin + 2)..(v196_24_origin + 3)]);
              let v207_11: Space = routine_4(c, &(v207_6), &v196_24_cursor, &(*s1));
              drop(v207_6);
              map_map_kernels::compose(&(v205_10),&(v207_11))
            };
            drop(v205_10);
            let v205_13: Space = map_map_kernels::unite(&(v205_8),&(v205_12));
            join_wrapped_into(&mut v204_11_write,&((v205_13).read_zipper()),&[]);
            }
            v196_24_cursor.ascend(1);
          }
          drop(v204_11_write);
          drop(v204_6);
          map_map_kernels::compose(&(v199_10),&(v204_11))
        };
        drop(v199_10);
        let v199_13: Space = map_map_kernels::unite(&(v199_8),&(v199_12));
        join_wrapped_into(&mut v198_7_write,&((v199_13).read_zipper()),&[]);
        }
        v196_24_cursor.ascend(1);
      }
      drop(v198_7_write);
      map_map_kernels::compose(&(v197_5),&(v198_7))
    };
    drop(v197_5);
    let v197_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v197_2));
    drop(v197_2);
    let v197_10: Space = if map_kernels::has_head(&(v197_9)) { singleton(&[]) } else { Space::new() };
    drop(v197_9);
    let v197_12: Space = if (&(v197_10)).is_empty() { Space::new() } else {
      let mut v208_11 = Space::new();
      let mut v208_11_write = v208_11.write_zipper();
      for v208_11_byte in v196_24_cursor.child_mask().iter() {
        v196_24_cursor.descend_to_existing_byte(v208_11_byte);
        {
        let v209_2: Space = singleton(&v196_24_cursor.path()[(v196_24_origin + 1)..(v196_24_origin + 2)]);
        let v209_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v209_2));
        let v209_4: Space = if map_kernels::has_head(&(v209_3)) { singleton(&[]) } else { Space::new() };
        drop(v209_3);
        let v209_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v209_4));
        drop(v209_4);
        let v209_7: Space = if (&(v209_5)).is_empty() { Space::new() } else {
          let mut v210_6 = Space::new();
          let mut v210_6_write = v210_6.write_zipper();
          for v210_6_byte in v196_24_cursor.child_mask().iter() {
            v196_24_cursor.descend_to_existing_byte(v210_6_byte);
            {
            let v211_2: Space = singleton(&v196_24_cursor.path()[(v196_24_origin + 2)..(v196_24_origin + 3)]);
            let v211_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v211_2));
            let v211_4: Space = if map_kernels::has_head(&(v211_3)) { singleton(&[]) } else { Space::new() };
            drop(v211_3);
            let v211_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v211_4));
            drop(v211_4);
            let v211_8: Space = if (&(v211_5)).is_empty() { Space::new() } else {
              let v212_7: Space = routine_22(c, &v196_24_cursor.path()[(v196_24_origin + 1)..(v196_24_origin + 3)], &v196_24_cursor, &(*s1));
              map_map_kernels::compose(&(v211_5),&(v212_7))
            };
            drop(v211_5);
            let v211_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v211_2));
            drop(v211_2);
            let v211_10: Space = if map_kernels::has_head(&(v211_9)) { singleton(&[]) } else { Space::new() };
            drop(v211_9);
            let v211_12: Space = if (&(v211_10)).is_empty() { Space::new() } else {
              let v213_11: Space = routine_23(c, &v196_24_cursor.path()[(v196_24_origin + 1)..(v196_24_origin + 3)], &v196_24_cursor, &(*s1));
              map_map_kernels::compose(&(v211_10),&(v213_11))
            };
            drop(v211_10);
            let v211_13: Space = map_map_kernels::unite(&(v211_8),&(v211_12));
            join_wrapped_into(&mut v210_6_write,&((v211_13).read_zipper()),&[]);
            }
            v196_24_cursor.ascend(1);
          }
          drop(v210_6_write);
          map_map_kernels::compose(&(v209_5),&(v210_6))
        };
        drop(v209_5);
        let v209_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v209_2));
        drop(v209_2);
        let v209_9: Space = if map_kernels::has_head(&(v209_8)) { singleton(&[]) } else { Space::new() };
        drop(v209_8);
        let v209_11: Space = if (&(v209_9)).is_empty() { Space::new() } else {
          let mut v214_10 = Space::new();
          let mut v214_10_write = v214_10.write_zipper();
          for v214_10_byte in v196_24_cursor.child_mask().iter() {
            v196_24_cursor.descend_to_existing_byte(v214_10_byte);
            {
            let v215_2: Space = singleton(&v196_24_cursor.path()[(v196_24_origin + 2)..(v196_24_origin + 3)]);
            let v215_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v215_2));
            let v215_4: Space = if map_kernels::has_head(&(v215_3)) { singleton(&[]) } else { Space::new() };
            drop(v215_3);
            let v215_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v215_4));
            drop(v215_4);
            let v215_8: Space = if (&(v215_5)).is_empty() { Space::new() } else {
              let v216_7: Space = routine_22(c, &v196_24_cursor.path()[(v196_24_origin + 1)..(v196_24_origin + 3)], &v196_24_cursor, &(*s1));
              map_map_kernels::compose(&(v215_5),&(v216_7))
            };
            drop(v215_5);
            let v215_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v215_2));
            drop(v215_2);
            let v215_10: Space = if map_kernels::has_head(&(v215_9)) { singleton(&[]) } else { Space::new() };
            drop(v215_9);
            let v215_12: Space = if (&(v215_10)).is_empty() { Space::new() } else {
              let v217_11: Space = routine_24(c, &v196_24_cursor.path()[(v196_24_origin + 1)..(v196_24_origin + 3)], &v196_24_cursor, &(*s1));
              map_map_kernels::compose(&(v215_10),&(v217_11))
            };
            drop(v215_10);
            let v215_13: Space = map_map_kernels::unite(&(v215_8),&(v215_12));
            join_wrapped_into(&mut v214_10_write,&((v215_13).read_zipper()),&[]);
            }
            v196_24_cursor.ascend(1);
          }
          drop(v214_10_write);
          map_map_kernels::compose(&(v209_9),&(v214_10))
        };
        drop(v209_9);
        let v209_12: Space = map_map_kernels::unite(&(v209_7),&(v209_11));
        join_wrapped_into(&mut v208_11_write,&((v209_12).read_zipper()),&[]);
        }
        v196_24_cursor.ascend(1);
      }
      drop(v208_11_write);
      map_map_kernels::compose(&(v197_10),&(v208_11))
    };
    drop(v197_10);
    let v218_6: Path = concat_path(&(*p0),&v196_24_cursor.path()[v196_24_origin..(v196_24_origin + 1)]);
    let v197_13: Space = map_kernels::wrap(&(v197_12),&(v218_6));
    let v197_14: Space = map_map_kernels::unite(&(v197_8),&(v197_13));
    join_wrapped_into(&mut v196_24_write,&((v197_14).read_zipper()),&[]);
    }
    v196_24_cursor.ascend(1);
  }
  drop(v196_24_cursor);
  drop(v196_24_write);
  (v196_24).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v219_26 = Space::new();
  let mut v219_26_write = v219_26.write_zipper();
  let mut v219_26_cursor = (*s0).read_zipper();
  let v219_26_origin = v219_26_cursor.path().len();
  for v219_26_byte in v219_26_cursor.child_mask().iter() {
    v219_26_cursor.descend_to_existing_byte(v219_26_byte);
    {
    let v220_2: Space = singleton(&v219_26_cursor.path()[v219_26_origin..(v219_26_origin + 1)]);
    let v220_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v220_2));
    let v220_4: Space = if map_kernels::has_head(&(v220_3)) { singleton(&[]) } else { Space::new() };
    drop(v220_3);
    let v220_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v220_4));
    drop(v220_4);
    let v220_7: Space = if (&(v220_5)).is_empty() { Space::new() } else {
      let mut v221_6 = Space::new();
      let mut v221_6_write = v221_6.write_zipper();
      for v221_6_byte in v219_26_cursor.child_mask().iter() {
        v219_26_cursor.descend_to_existing_byte(v221_6_byte);
        {
        let v222_2: Space = singleton(&v219_26_cursor.path()[(v219_26_origin + 1)..(v219_26_origin + 2)]);
        let v222_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v222_2));
        let v222_4: Space = if map_kernels::has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
        drop(v222_3);
        let v222_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v222_4));
        drop(v222_4);
        let v222_8: Space = if (&(v222_5)).is_empty() { Space::new() } else {
          let mut v223_7 = Space::new();
          let mut v223_7_write = v223_7.write_zipper();
          for v223_7_byte in v219_26_cursor.child_mask().iter() {
            v219_26_cursor.descend_to_existing_byte(v223_7_byte);
            {
            let v224_2: Space = singleton(&v219_26_cursor.path()[(v219_26_origin + 2)..(v219_26_origin + 3)]);
            let v224_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v224_2));
            let v224_4: Space = if map_kernels::has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
            drop(v224_3);
            let v224_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v224_4));
            drop(v224_4);
            let v224_8: Space = if (&(v224_5)).is_empty() { Space::new() } else {
              let v225_7: Space = routine_25(c, &v219_26_cursor.path()[v219_26_origin..(v219_26_origin + 3)], &v219_26_cursor, &(*s1));
              map_map_kernels::compose(&(v224_5),&(v225_7))
            };
            drop(v224_5);
            let v224_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v224_2));
            drop(v224_2);
            let v224_10: Space = if map_kernels::has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
            drop(v224_9);
            let v224_12: Space = if (&(v224_10)).is_empty() { Space::new() } else {
              let v226_11: Space = routine_26(c, &v219_26_cursor.path()[v219_26_origin..(v219_26_origin + 3)], &v219_26_cursor, &(*s1));
              map_map_kernels::compose(&(v224_10),&(v226_11))
            };
            drop(v224_10);
            let v224_13: Space = map_map_kernels::unite(&(v224_8),&(v224_12));
            join_wrapped_into(&mut v223_7_write,&((v224_13).read_zipper()),&[]);
            }
            v219_26_cursor.ascend(1);
          }
          drop(v223_7_write);
          map_map_kernels::compose(&(v222_5),&(v223_7))
        };
        drop(v222_5);
        let v222_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v222_2));
        drop(v222_2);
        let v222_10: Space = if map_kernels::has_head(&(v222_9)) { singleton(&[]) } else { Space::new() };
        drop(v222_9);
        let v222_12: Space = if (&(v222_10)).is_empty() { Space::new() } else {
          let mut v227_11 = Space::new();
          let mut v227_11_write = v227_11.write_zipper();
          for v227_11_byte in v219_26_cursor.child_mask().iter() {
            v219_26_cursor.descend_to_existing_byte(v227_11_byte);
            {
            let v228_2: Space = singleton(&v219_26_cursor.path()[(v219_26_origin + 2)..(v219_26_origin + 3)]);
            let v228_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v228_2));
            let v228_4: Space = if map_kernels::has_head(&(v228_3)) { singleton(&[]) } else { Space::new() };
            drop(v228_3);
            let v228_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v228_4));
            drop(v228_4);
            let v228_8: Space = if (&(v228_5)).is_empty() { Space::new() } else {
              let v229_7: Space = routine_25(c, &v219_26_cursor.path()[v219_26_origin..(v219_26_origin + 3)], &v219_26_cursor, &(*s1));
              map_map_kernels::compose(&(v228_5),&(v229_7))
            };
            drop(v228_5);
            let v228_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v228_2));
            drop(v228_2);
            let v228_10: Space = if map_kernels::has_head(&(v228_9)) { singleton(&[]) } else { Space::new() };
            drop(v228_9);
            let v228_12: Space = if (&(v228_10)).is_empty() { Space::new() } else {
              let v230_11: Space = routine_24(c, &v219_26_cursor.path()[v219_26_origin..(v219_26_origin + 3)], &v219_26_cursor, &(*s1));
              map_map_kernels::compose(&(v228_10),&(v230_11))
            };
            drop(v228_10);
            let v228_13: Space = map_map_kernels::unite(&(v228_8),&(v228_12));
            join_wrapped_into(&mut v227_11_write,&((v228_13).read_zipper()),&[]);
            }
            v219_26_cursor.ascend(1);
          }
          drop(v227_11_write);
          map_map_kernels::compose(&(v222_10),&(v227_11))
        };
        drop(v222_10);
        let v222_13: Space = map_map_kernels::unite(&(v222_8),&(v222_12));
        join_wrapped_into(&mut v221_6_write,&((v222_13).read_zipper()),&[]);
        }
        v219_26_cursor.ascend(1);
      }
      drop(v221_6_write);
      map_map_kernels::compose(&(v220_5),&(v221_6))
    };
    drop(v220_5);
    let v220_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v220_2));
    drop(v220_2);
    let v220_9: Space = if map_kernels::has_head(&(v220_8)) { singleton(&[]) } else { Space::new() };
    drop(v220_8);
    let v220_12: Space = if (&(v220_9)).is_empty() { Space::new() } else {
      let mut v231_11 = Space::new();
      let mut v231_11_write = v231_11.write_zipper();
      for v231_11_byte in v219_26_cursor.child_mask().iter() {
        v219_26_cursor.descend_to_existing_byte(v231_11_byte);
        {
        let v232_2: Space = singleton(&v219_26_cursor.path()[(v219_26_origin + 1)..(v219_26_origin + 2)]);
        let v232_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v232_2));
        let v232_4: Space = if map_kernels::has_head(&(v232_3)) { singleton(&[]) } else { Space::new() };
        drop(v232_3);
        let v232_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v232_4));
        drop(v232_4);
        let v232_8: Space = if (&(v232_5)).is_empty() { Space::new() } else {
          let mut v233_7 = Space::new();
          let mut v233_7_write = v233_7.write_zipper();
          for v233_7_byte in v219_26_cursor.child_mask().iter() {
            v219_26_cursor.descend_to_existing_byte(v233_7_byte);
            {
            let v234_2: Space = singleton(&v219_26_cursor.path()[(v219_26_origin + 2)..(v219_26_origin + 3)]);
            let v234_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v234_2));
            let v234_4: Space = if map_kernels::has_head(&(v234_3)) { singleton(&[]) } else { Space::new() };
            drop(v234_3);
            let v234_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v234_4));
            drop(v234_4);
            let v234_8: Space = if (&(v234_5)).is_empty() { Space::new() } else {
              let v235_7: Space = routine_25(c, &v219_26_cursor.path()[v219_26_origin..(v219_26_origin + 3)], &v219_26_cursor, &(*s1));
              map_map_kernels::compose(&(v234_5),&(v235_7))
            };
            drop(v234_5);
            let v234_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v234_2));
            drop(v234_2);
            let v234_10: Space = if map_kernels::has_head(&(v234_9)) { singleton(&[]) } else { Space::new() };
            drop(v234_9);
            let v234_12: Space = if (&(v234_10)).is_empty() { Space::new() } else {
              let v236_11: Space = routine_26(c, &v219_26_cursor.path()[v219_26_origin..(v219_26_origin + 3)], &v219_26_cursor, &(*s1));
              map_map_kernels::compose(&(v234_10),&(v236_11))
            };
            drop(v234_10);
            let v234_13: Space = map_map_kernels::unite(&(v234_8),&(v234_12));
            join_wrapped_into(&mut v233_7_write,&((v234_13).read_zipper()),&[]);
            }
            v219_26_cursor.ascend(1);
          }
          drop(v233_7_write);
          map_map_kernels::compose(&(v232_5),&(v233_7))
        };
        drop(v232_5);
        let v232_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v232_2));
        drop(v232_2);
        let v232_10: Space = if map_kernels::has_head(&(v232_9)) { singleton(&[]) } else { Space::new() };
        drop(v232_9);
        let v232_13: Space = if (&(v232_10)).is_empty() { Space::new() } else {
          let v237_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&v219_26_cursor.path()[v219_26_origin..(v219_26_origin + 1)]),&v219_26_cursor.path()[(v219_26_origin + 1)..(v219_26_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v232_10),&(v237_12))
        };
        drop(v232_10);
        let v232_14: Space = map_map_kernels::unite(&(v232_8),&(v232_13));
        drop(v232_13);
        join_wrapped_into(&mut v231_11_write,&((v232_14).read_zipper()),&[]);
        }
        v219_26_cursor.ascend(1);
      }
      drop(v231_11_write);
      map_map_kernels::compose(&(v220_9),&(v231_11))
    };
    drop(v220_9);
    let v220_13: Space = map_map_kernels::unite(&(v220_7),&(v220_12));
    join_wrapped_into(&mut v219_26_write,&((v220_13).read_zipper()),&[]);
    }
    v219_26_cursor.ascend(1);
  }
  drop(v219_26_cursor);
  drop(v219_26_write);
  let v219_27: Space = map_kernels::wrap(&(v219_26),&(*p0));
  (v219_27).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v238_27 = Space::new();
  let mut v238_27_write = v238_27.write_zipper();
  let mut v238_27_cursor = (*s0).read_zipper();
  let v238_27_origin = v238_27_cursor.path().len();
  for v238_27_byte in v238_27_cursor.child_mask().iter() {
    v238_27_cursor.descend_to_existing_byte(v238_27_byte);
    {
    let v239_2: Space = singleton(&v238_27_cursor.path()[v238_27_origin..(v238_27_origin + 1)]);
    let v239_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v239_2));
    let v239_4: Space = if map_kernels::has_head(&(v239_3)) { singleton(&[]) } else { Space::new() };
    drop(v239_3);
    let v239_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v239_4));
    drop(v239_4);
    let v239_8: Space = if (&(v239_5)).is_empty() { Space::new() } else {
      let v240_6: Path = concat_path(&(*p0),&v238_27_cursor.path()[v238_27_origin..(v238_27_origin + 1)]);
      let mut v240_7 = Space::new();
      let mut v240_7_write = v240_7.write_zipper();
      for v240_7_byte in v238_27_cursor.child_mask().iter() {
        v238_27_cursor.descend_to_existing_byte(v240_7_byte);
        {
        let v241_2: Space = singleton(&v238_27_cursor.path()[(v238_27_origin + 1)..(v238_27_origin + 2)]);
        let v241_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v241_2));
        let v241_4: Space = if map_kernels::has_head(&(v241_3)) { singleton(&[]) } else { Space::new() };
        drop(v241_3);
        let v241_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v241_4));
        drop(v241_4);
        let v241_8: Space = if (&(v241_5)).is_empty() { Space::new() } else {
          let v242_6: Path = concat_path(&(v240_6),&v238_27_cursor.path()[(v238_27_origin + 1)..(v238_27_origin + 2)]);
          let mut v242_7 = Space::new();
          let mut v242_7_write = v242_7.write_zipper();
          for v242_7_byte in v238_27_cursor.child_mask().iter() {
            v238_27_cursor.descend_to_existing_byte(v242_7_byte);
            {
            let v243_2: Space = singleton(&v238_27_cursor.path()[(v238_27_origin + 2)..(v238_27_origin + 3)]);
            let v243_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v243_2));
            let v243_4: Space = if map_kernels::has_head(&(v243_3)) { singleton(&[]) } else { Space::new() };
            drop(v243_3);
            let v243_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v243_4));
            drop(v243_4);
            let v243_8: Space = if (&(v243_5)).is_empty() { Space::new() } else {
              let v244_6: Path = concat_path(&(v242_6),&v238_27_cursor.path()[(v238_27_origin + 2)..(v238_27_origin + 3)]);
              let v244_7: Space = routine_27(c, &(v244_6), &v238_27_cursor, &(*s1));
              map_map_kernels::compose(&(v243_5),&(v244_7))
            };
            drop(v243_5);
            let v243_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v243_2));
            drop(v243_2);
            let v243_10: Space = if map_kernels::has_head(&(v243_9)) { singleton(&[]) } else { Space::new() };
            drop(v243_9);
            let v243_12: Space = if (&(v243_10)).is_empty() { Space::new() } else {
              let v245_6: Path = concat_path(&(v242_6),&v238_27_cursor.path()[(v238_27_origin + 2)..(v238_27_origin + 3)]);
              let v245_11: Space = routine_28(c, &(v245_6), &v238_27_cursor, &(*s1));
              drop(v245_6);
              map_map_kernels::compose(&(v243_10),&(v245_11))
            };
            drop(v243_10);
            let v243_13: Space = map_map_kernels::unite(&(v243_8),&(v243_12));
            join_wrapped_into(&mut v242_7_write,&((v243_13).read_zipper()),&[]);
            }
            v238_27_cursor.ascend(1);
          }
          drop(v242_7_write);
          map_map_kernels::compose(&(v241_5),&(v242_7))
        };
        drop(v241_5);
        let v241_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v241_2));
        drop(v241_2);
        let v241_10: Space = if map_kernels::has_head(&(v241_9)) { singleton(&[]) } else { Space::new() };
        drop(v241_9);
        let v241_12: Space = if (&(v241_10)).is_empty() { Space::new() } else {
          let v246_6: Path = concat_path(&(v240_6),&v238_27_cursor.path()[(v238_27_origin + 1)..(v238_27_origin + 2)]);
          let mut v246_11 = Space::new();
          let mut v246_11_write = v246_11.write_zipper();
          for v246_11_byte in v238_27_cursor.child_mask().iter() {
            v238_27_cursor.descend_to_existing_byte(v246_11_byte);
            {
            let v247_2: Space = singleton(&v238_27_cursor.path()[(v238_27_origin + 2)..(v238_27_origin + 3)]);
            let v247_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v247_2));
            let v247_4: Space = if map_kernels::has_head(&(v247_3)) { singleton(&[]) } else { Space::new() };
            drop(v247_3);
            let v247_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v247_4));
            drop(v247_4);
            let v247_8: Space = if (&(v247_5)).is_empty() { Space::new() } else {
              let v248_6: Path = concat_path(&(v246_6),&v238_27_cursor.path()[(v238_27_origin + 2)..(v238_27_origin + 3)]);
              let v248_7: Space = routine_27(c, &(v248_6), &v238_27_cursor, &(*s1));
              map_map_kernels::compose(&(v247_5),&(v248_7))
            };
            drop(v247_5);
            let v247_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v247_2));
            drop(v247_2);
            let v247_10: Space = if map_kernels::has_head(&(v247_9)) { singleton(&[]) } else { Space::new() };
            drop(v247_9);
            let v247_12: Space = if (&(v247_10)).is_empty() { Space::new() } else {
              let v249_6: Path = concat_path(&(v246_6),&v238_27_cursor.path()[(v238_27_origin + 2)..(v238_27_origin + 3)]);
              let v249_11: Space = routine_24(c, &(v249_6), &v238_27_cursor, &(*s1));
              drop(v249_6);
              map_map_kernels::compose(&(v247_10),&(v249_11))
            };
            drop(v247_10);
            let v247_13: Space = map_map_kernels::unite(&(v247_8),&(v247_12));
            join_wrapped_into(&mut v246_11_write,&((v247_13).read_zipper()),&[]);
            }
            v238_27_cursor.ascend(1);
          }
          drop(v246_11_write);
          drop(v246_6);
          map_map_kernels::compose(&(v241_10),&(v246_11))
        };
        drop(v241_10);
        let v241_13: Space = map_map_kernels::unite(&(v241_8),&(v241_12));
        join_wrapped_into(&mut v240_7_write,&((v241_13).read_zipper()),&[]);
        }
        v238_27_cursor.ascend(1);
      }
      drop(v240_7_write);
      map_map_kernels::compose(&(v239_5),&(v240_7))
    };
    drop(v239_5);
    let v239_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v239_2));
    drop(v239_2);
    let v239_10: Space = if map_kernels::has_head(&(v239_9)) { singleton(&[]) } else { Space::new() };
    drop(v239_9);
    let v239_13: Space = if (&(v239_10)).is_empty() { Space::new() } else {
      let v250_6: Path = concat_path(&(*p0),&v238_27_cursor.path()[v238_27_origin..(v238_27_origin + 1)]);
      let mut v250_12 = Space::new();
      let mut v250_12_write = v250_12.write_zipper();
      for v250_12_byte in v238_27_cursor.child_mask().iter() {
        v238_27_cursor.descend_to_existing_byte(v250_12_byte);
        {
        let v251_2: Space = singleton(&v238_27_cursor.path()[(v238_27_origin + 1)..(v238_27_origin + 2)]);
        let v251_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v251_2));
        let v251_4: Space = if map_kernels::has_head(&(v251_3)) { singleton(&[]) } else { Space::new() };
        drop(v251_3);
        let v251_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v251_4));
        drop(v251_4);
        let v251_8: Space = if (&(v251_5)).is_empty() { Space::new() } else {
          let v252_6: Path = concat_path(&(v250_6),&v238_27_cursor.path()[(v238_27_origin + 1)..(v238_27_origin + 2)]);
          let mut v252_7 = Space::new();
          let mut v252_7_write = v252_7.write_zipper();
          for v252_7_byte in v238_27_cursor.child_mask().iter() {
            v238_27_cursor.descend_to_existing_byte(v252_7_byte);
            {
            let v253_2: Space = singleton(&v238_27_cursor.path()[(v238_27_origin + 2)..(v238_27_origin + 3)]);
            let v253_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v253_2));
            let v253_4: Space = if map_kernels::has_head(&(v253_3)) { singleton(&[]) } else { Space::new() };
            drop(v253_3);
            let v253_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v253_4));
            drop(v253_4);
            let v253_8: Space = if (&(v253_5)).is_empty() { Space::new() } else {
              let v254_6: Path = concat_path(&(v252_6),&v238_27_cursor.path()[(v238_27_origin + 2)..(v238_27_origin + 3)]);
              let v254_7: Space = routine_27(c, &(v254_6), &v238_27_cursor, &(*s1));
              map_map_kernels::compose(&(v253_5),&(v254_7))
            };
            drop(v253_5);
            let v253_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v253_2));
            drop(v253_2);
            let v253_10: Space = if map_kernels::has_head(&(v253_9)) { singleton(&[]) } else { Space::new() };
            drop(v253_9);
            let v253_12: Space = if (&(v253_10)).is_empty() { Space::new() } else {
              let v255_6: Path = concat_path(&(v252_6),&v238_27_cursor.path()[(v238_27_origin + 2)..(v238_27_origin + 3)]);
              let v255_11: Space = routine_28(c, &(v255_6), &v238_27_cursor, &(*s1));
              drop(v255_6);
              map_map_kernels::compose(&(v253_10),&(v255_11))
            };
            drop(v253_10);
            let v253_13: Space = map_map_kernels::unite(&(v253_8),&(v253_12));
            join_wrapped_into(&mut v252_7_write,&((v253_13).read_zipper()),&[]);
            }
            v238_27_cursor.ascend(1);
          }
          drop(v252_7_write);
          drop(v252_6);
          map_map_kernels::compose(&(v251_5),&(v252_7))
        };
        drop(v251_5);
        let v251_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v251_2));
        drop(v251_2);
        let v251_10: Space = if map_kernels::has_head(&(v251_9)) { singleton(&[]) } else { Space::new() };
        drop(v251_9);
        let v251_13: Space = if (&(v251_10)).is_empty() { Space::new() } else {
          let v256_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v238_27_cursor.path()[v238_27_origin..(v238_27_origin + 1)]),&v238_27_cursor.path()[(v238_27_origin + 1)..(v238_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v251_10),&(v256_12))
        };
        drop(v251_10);
        let v251_14: Space = map_map_kernels::unite(&(v251_8),&(v251_13));
        drop(v251_13);
        join_wrapped_into(&mut v250_12_write,&((v251_14).read_zipper()),&[]);
        }
        v238_27_cursor.ascend(1);
      }
      drop(v250_12_write);
      drop(v250_6);
      map_map_kernels::compose(&(v239_10),&(v250_12))
    };
    drop(v239_10);
    let v239_14: Space = map_map_kernels::unite(&(v239_8),&(v239_13));
    join_wrapped_into(&mut v238_27_write,&((v239_14).read_zipper()),&[]);
    }
    v238_27_cursor.ascend(1);
  }
  drop(v238_27_cursor);
  drop(v238_27_write);
  (v238_27).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v257_21 = Space::new();
  let mut v257_21_write = v257_21.write_zipper();
  let mut v257_21_cursor = (*s0).read_zipper();
  let v257_21_origin = v257_21_cursor.path().len();
  for v257_21_byte in v257_21_cursor.child_mask().iter() {
    v257_21_cursor.descend_to_existing_byte(v257_21_byte);
    {
    let v258_2: Space = singleton(&v257_21_cursor.path()[v257_21_origin..(v257_21_origin + 1)]);
    let v258_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v258_2));
    let v258_4: Space = if map_kernels::has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
    drop(v258_3);
    let v258_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v258_4));
    drop(v258_4);
    let v258_8: Space = if (&(v258_5)).is_empty() { Space::new() } else {
      let v259_6: Path = concat_path(&(*p0),&v257_21_cursor.path()[v257_21_origin..(v257_21_origin + 1)]);
      let mut v259_7 = Space::new();
      let mut v259_7_write = v259_7.write_zipper();
      for v259_7_byte in v257_21_cursor.child_mask().iter() {
        v257_21_cursor.descend_to_existing_byte(v259_7_byte);
        {
        let v260_2: Space = singleton(&v257_21_cursor.path()[(v257_21_origin + 1)..(v257_21_origin + 2)]);
        let v260_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v260_2));
        let v260_4: Space = if map_kernels::has_head(&(v260_3)) { singleton(&[]) } else { Space::new() };
        drop(v260_3);
        let v260_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v260_4));
        drop(v260_4);
        let v260_8: Space = if (&(v260_5)).is_empty() { Space::new() } else {
          let v261_6: Path = concat_path(&(v259_6),&v257_21_cursor.path()[(v257_21_origin + 1)..(v257_21_origin + 2)]);
          let mut v261_7 = Space::new();
          let mut v261_7_write = v261_7.write_zipper();
          for v261_7_byte in v257_21_cursor.child_mask().iter() {
            v257_21_cursor.descend_to_existing_byte(v261_7_byte);
            {
            let v262_2: Space = singleton(&v257_21_cursor.path()[(v257_21_origin + 2)..(v257_21_origin + 3)]);
            let v262_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v262_2));
            let v262_4: Space = if map_kernels::has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
            drop(v262_3);
            let v262_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v262_4));
            drop(v262_4);
            let v262_8: Space = if (&(v262_5)).is_empty() { Space::new() } else {
              let v263_6: Path = concat_path(&(v261_6),&v257_21_cursor.path()[(v257_21_origin + 2)..(v257_21_origin + 3)]);
              let v263_7: Space = routine_27(c, &(v263_6), &v257_21_cursor, &(*s1));
              map_map_kernels::compose(&(v262_5),&(v263_7))
            };
            drop(v262_5);
            let v262_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v262_2));
            drop(v262_2);
            let v262_10: Space = if map_kernels::has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
            drop(v262_9);
            let v262_12: Space = if (&(v262_10)).is_empty() { Space::new() } else {
              let v264_6: Path = concat_path(&(v261_6),&v257_21_cursor.path()[(v257_21_origin + 2)..(v257_21_origin + 3)]);
              let v264_11: Space = routine_28(c, &(v264_6), &v257_21_cursor, &(*s1));
              drop(v264_6);
              map_map_kernels::compose(&(v262_10),&(v264_11))
            };
            drop(v262_10);
            let v262_13: Space = map_map_kernels::unite(&(v262_8),&(v262_12));
            join_wrapped_into(&mut v261_7_write,&((v262_13).read_zipper()),&[]);
            }
            v257_21_cursor.ascend(1);
          }
          drop(v261_7_write);
          map_map_kernels::compose(&(v260_5),&(v261_7))
        };
        drop(v260_5);
        let v260_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v260_2));
        drop(v260_2);
        let v260_10: Space = if map_kernels::has_head(&(v260_9)) { singleton(&[]) } else { Space::new() };
        drop(v260_9);
        let v260_12: Space = if (&(v260_10)).is_empty() { Space::new() } else {
          let v265_6: Path = concat_path(&(v259_6),&v257_21_cursor.path()[(v257_21_origin + 1)..(v257_21_origin + 2)]);
          let mut v265_11 = Space::new();
          let mut v265_11_write = v265_11.write_zipper();
          for v265_11_byte in v257_21_cursor.child_mask().iter() {
            v257_21_cursor.descend_to_existing_byte(v265_11_byte);
            {
            let v266_2: Space = singleton(&v257_21_cursor.path()[(v257_21_origin + 2)..(v257_21_origin + 3)]);
            let v266_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v266_2));
            let v266_4: Space = if map_kernels::has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
            drop(v266_3);
            let v266_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v266_4));
            drop(v266_4);
            let v266_8: Space = if (&(v266_5)).is_empty() { Space::new() } else {
              let v267_6: Path = concat_path(&(v265_6),&v257_21_cursor.path()[(v257_21_origin + 2)..(v257_21_origin + 3)]);
              let v267_7: Space = routine_27(c, &(v267_6), &v257_21_cursor, &(*s1));
              map_map_kernels::compose(&(v266_5),&(v267_7))
            };
            drop(v266_5);
            let v266_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v266_2));
            drop(v266_2);
            let v266_10: Space = if map_kernels::has_head(&(v266_9)) { singleton(&[]) } else { Space::new() };
            drop(v266_9);
            let v266_12: Space = if (&(v266_10)).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v265_6),&v257_21_cursor.path()[(v257_21_origin + 2)..(v257_21_origin + 3)]);
              let v268_11: Space = routine_24(c, &(v268_6), &v257_21_cursor, &(*s1));
              drop(v268_6);
              map_map_kernels::compose(&(v266_10),&(v268_11))
            };
            drop(v266_10);
            let v266_13: Space = map_map_kernels::unite(&(v266_8),&(v266_12));
            join_wrapped_into(&mut v265_11_write,&((v266_13).read_zipper()),&[]);
            }
            v257_21_cursor.ascend(1);
          }
          drop(v265_11_write);
          drop(v265_6);
          map_map_kernels::compose(&(v260_10),&(v265_11))
        };
        drop(v260_10);
        let v260_13: Space = map_map_kernels::unite(&(v260_8),&(v260_12));
        join_wrapped_into(&mut v259_7_write,&((v260_13).read_zipper()),&[]);
        }
        v257_21_cursor.ascend(1);
      }
      drop(v259_7_write);
      drop(v259_6);
      map_map_kernels::compose(&(v258_5),&(v259_7))
    };
    drop(v258_5);
    let v258_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v258_2));
    drop(v258_2);
    let v258_10: Space = if map_kernels::has_head(&(v258_9)) { singleton(&[]) } else { Space::new() };
    drop(v258_9);
    let v258_13: Space = if (&(v258_10)).is_empty() { Space::new() } else {
      let v269_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v257_21_cursor.path()[v257_21_origin..(v257_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v258_10),&(v269_12))
    };
    drop(v258_10);
    let v258_14: Space = map_map_kernels::unite(&(v258_8),&(v258_13));
    drop(v258_13);
    join_wrapped_into(&mut v257_21_write,&((v258_14).read_zipper()),&[]);
    }
    v257_21_cursor.ascend(1);
  }
  drop(v257_21_cursor);
  drop(v257_21_write);
  (v257_21).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v270_24 = Space::new();
  let mut v270_24_write = v270_24.write_zipper();
  let mut v270_24_cursor = (*s0).read_zipper();
  let v270_24_origin = v270_24_cursor.path().len();
  for v270_24_byte in v270_24_cursor.child_mask().iter() {
    v270_24_cursor.descend_to_existing_byte(v270_24_byte);
    {
    let v271_2: Space = singleton(&v270_24_cursor.path()[v270_24_origin..(v270_24_origin + 1)]);
    let v271_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v271_2));
    let v271_4: Space = if map_kernels::has_head(&(v271_3)) { singleton(&[]) } else { Space::new() };
    drop(v271_3);
    let v271_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v271_4));
    drop(v271_4);
    let v271_8: Space = if (&(v271_5)).is_empty() { Space::new() } else {
      let v272_6: Path = concat_path(&(*p0),&v270_24_cursor.path()[v270_24_origin..(v270_24_origin + 1)]);
      let mut v272_7 = Space::new();
      let mut v272_7_write = v272_7.write_zipper();
      for v272_7_byte in v270_24_cursor.child_mask().iter() {
        v270_24_cursor.descend_to_existing_byte(v272_7_byte);
        {
        let v273_2: Space = singleton(&v270_24_cursor.path()[(v270_24_origin + 1)..(v270_24_origin + 2)]);
        let v273_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v273_2));
        let v273_4: Space = if map_kernels::has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
        drop(v273_3);
        let v273_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v273_4));
        drop(v273_4);
        let v273_8: Space = if (&(v273_5)).is_empty() { Space::new() } else {
          let v274_6: Path = concat_path(&(v272_6),&v270_24_cursor.path()[(v270_24_origin + 1)..(v270_24_origin + 2)]);
          let mut v274_7 = Space::new();
          let mut v274_7_write = v274_7.write_zipper();
          for v274_7_byte in v270_24_cursor.child_mask().iter() {
            v270_24_cursor.descend_to_existing_byte(v274_7_byte);
            {
            let v275_2: Space = singleton(&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
            let v275_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v275_2));
            let v275_4: Space = if map_kernels::has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
            drop(v275_3);
            let v275_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v275_4));
            drop(v275_4);
            let v275_8: Space = if (&(v275_5)).is_empty() { Space::new() } else {
              let v276_6: Path = concat_path(&(v274_6),&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
              let v276_7: Space = routine_29(c, &(v276_6), &v270_24_cursor, &(*s1));
              map_map_kernels::compose(&(v275_5),&(v276_7))
            };
            drop(v275_5);
            let v275_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v275_2));
            drop(v275_2);
            let v275_10: Space = if map_kernels::has_head(&(v275_9)) { singleton(&[]) } else { Space::new() };
            drop(v275_9);
            let v275_12: Space = if (&(v275_10)).is_empty() { Space::new() } else {
              let v277_6: Path = concat_path(&(v274_6),&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
              let v277_11: Space = routine_30(c, &(v277_6), &v270_24_cursor, &(*s1));
              drop(v277_6);
              map_map_kernels::compose(&(v275_10),&(v277_11))
            };
            drop(v275_10);
            let v275_13: Space = map_map_kernels::unite(&(v275_8),&(v275_12));
            join_wrapped_into(&mut v274_7_write,&((v275_13).read_zipper()),&[]);
            }
            v270_24_cursor.ascend(1);
          }
          drop(v274_7_write);
          map_map_kernels::compose(&(v273_5),&(v274_7))
        };
        drop(v273_5);
        let v273_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v273_2));
        drop(v273_2);
        let v273_10: Space = if map_kernels::has_head(&(v273_9)) { singleton(&[]) } else { Space::new() };
        drop(v273_9);
        let v273_12: Space = if (&(v273_10)).is_empty() { Space::new() } else {
          let v278_6: Path = concat_path(&(v272_6),&v270_24_cursor.path()[(v270_24_origin + 1)..(v270_24_origin + 2)]);
          let mut v278_11 = Space::new();
          let mut v278_11_write = v278_11.write_zipper();
          for v278_11_byte in v270_24_cursor.child_mask().iter() {
            v270_24_cursor.descend_to_existing_byte(v278_11_byte);
            {
            let v279_2: Space = singleton(&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
            let v279_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v279_2));
            let v279_4: Space = if map_kernels::has_head(&(v279_3)) { singleton(&[]) } else { Space::new() };
            drop(v279_3);
            let v279_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v279_4));
            drop(v279_4);
            let v279_8: Space = if (&(v279_5)).is_empty() { Space::new() } else {
              let v280_6: Path = concat_path(&(v278_6),&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
              let v280_7: Space = routine_29(c, &(v280_6), &v270_24_cursor, &(*s1));
              map_map_kernels::compose(&(v279_5),&(v280_7))
            };
            drop(v279_5);
            let v279_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v279_2));
            drop(v279_2);
            let v279_10: Space = if map_kernels::has_head(&(v279_9)) { singleton(&[]) } else { Space::new() };
            drop(v279_9);
            let v279_12: Space = if (&(v279_10)).is_empty() { Space::new() } else {
              let v281_6: Path = concat_path(&(v278_6),&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
              let v281_11: Space = routine_9(c, &(v281_6), &v270_24_cursor, &(*s1));
              drop(v281_6);
              map_map_kernels::compose(&(v279_10),&(v281_11))
            };
            drop(v279_10);
            let v279_13: Space = map_map_kernels::unite(&(v279_8),&(v279_12));
            join_wrapped_into(&mut v278_11_write,&((v279_13).read_zipper()),&[]);
            }
            v270_24_cursor.ascend(1);
          }
          drop(v278_11_write);
          drop(v278_6);
          map_map_kernels::compose(&(v273_10),&(v278_11))
        };
        drop(v273_10);
        let v273_13: Space = map_map_kernels::unite(&(v273_8),&(v273_12));
        join_wrapped_into(&mut v272_7_write,&((v273_13).read_zipper()),&[]);
        }
        v270_24_cursor.ascend(1);
      }
      drop(v272_7_write);
      map_map_kernels::compose(&(v271_5),&(v272_7))
    };
    drop(v271_5);
    let v271_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v271_2));
    drop(v271_2);
    let v271_10: Space = if map_kernels::has_head(&(v271_9)) { singleton(&[]) } else { Space::new() };
    drop(v271_9);
    let v271_12: Space = if (&(v271_10)).is_empty() { Space::new() } else {
      let v282_6: Path = concat_path(&(*p0),&v270_24_cursor.path()[v270_24_origin..(v270_24_origin + 1)]);
      let mut v282_11 = Space::new();
      let mut v282_11_write = v282_11.write_zipper();
      for v282_11_byte in v270_24_cursor.child_mask().iter() {
        v270_24_cursor.descend_to_existing_byte(v282_11_byte);
        {
        let v283_2: Space = singleton(&v270_24_cursor.path()[(v270_24_origin + 1)..(v270_24_origin + 2)]);
        let v283_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v283_2));
        let v283_4: Space = if map_kernels::has_head(&(v283_3)) { singleton(&[]) } else { Space::new() };
        drop(v283_3);
        let v283_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v283_4));
        drop(v283_4);
        let v283_8: Space = if (&(v283_5)).is_empty() { Space::new() } else {
          let v284_6: Path = concat_path(&(v282_6),&v270_24_cursor.path()[(v270_24_origin + 1)..(v270_24_origin + 2)]);
          let mut v284_7 = Space::new();
          let mut v284_7_write = v284_7.write_zipper();
          for v284_7_byte in v270_24_cursor.child_mask().iter() {
            v270_24_cursor.descend_to_existing_byte(v284_7_byte);
            {
            let v285_2: Space = singleton(&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
            let v285_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v285_2));
            let v285_4: Space = if map_kernels::has_head(&(v285_3)) { singleton(&[]) } else { Space::new() };
            drop(v285_3);
            let v285_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v285_4));
            drop(v285_4);
            let v285_8: Space = if (&(v285_5)).is_empty() { Space::new() } else {
              let v286_6: Path = concat_path(&(v284_6),&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
              let v286_7: Space = routine_29(c, &(v286_6), &v270_24_cursor, &(*s1));
              map_map_kernels::compose(&(v285_5),&(v286_7))
            };
            drop(v285_5);
            let v285_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v285_2));
            drop(v285_2);
            let v285_10: Space = if map_kernels::has_head(&(v285_9)) { singleton(&[]) } else { Space::new() };
            drop(v285_9);
            let v285_12: Space = if (&(v285_10)).is_empty() { Space::new() } else {
              let v287_6: Path = concat_path(&(v284_6),&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
              let v287_11: Space = routine_30(c, &(v287_6), &v270_24_cursor, &(*s1));
              drop(v287_6);
              map_map_kernels::compose(&(v285_10),&(v287_11))
            };
            drop(v285_10);
            let v285_13: Space = map_map_kernels::unite(&(v285_8),&(v285_12));
            join_wrapped_into(&mut v284_7_write,&((v285_13).read_zipper()),&[]);
            }
            v270_24_cursor.ascend(1);
          }
          drop(v284_7_write);
          map_map_kernels::compose(&(v283_5),&(v284_7))
        };
        drop(v283_5);
        let v283_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v283_2));
        drop(v283_2);
        let v283_10: Space = if map_kernels::has_head(&(v283_9)) { singleton(&[]) } else { Space::new() };
        drop(v283_9);
        let v283_12: Space = if (&(v283_10)).is_empty() { Space::new() } else {
          let mut v288_11 = Space::new();
          let mut v288_11_write = v288_11.write_zipper();
          for v288_11_byte in v270_24_cursor.child_mask().iter() {
            v270_24_cursor.descend_to_existing_byte(v288_11_byte);
            {
            let v289_2: Space = singleton(&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
            let v289_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v289_2));
            let v289_4: Space = if map_kernels::has_head(&(v289_3)) { singleton(&[]) } else { Space::new() };
            drop(v289_3);
            let v289_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v289_4));
            drop(v289_4);
            let v289_7: Space = if (&(v289_5)).is_empty() { Space::new() } else {
              let v290_6: Space = routine_10(c, &v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)], &v270_24_cursor, &(*s1));
              map_map_kernels::compose(&(v289_5),&(v290_6))
            };
            drop(v289_5);
            let v289_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v289_2));
            drop(v289_2);
            let v289_9: Space = if map_kernels::has_head(&(v289_8)) { singleton(&[]) } else { Space::new() };
            drop(v289_8);
            let v289_11: Space = if (&(v289_9)).is_empty() { Space::new() } else {
              let v291_10: Space = routine_11(c, &v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)], &v270_24_cursor, &(*s1));
              map_map_kernels::compose(&(v289_9),&(v291_10))
            };
            drop(v289_9);
            let v289_12: Space = map_map_kernels::unite(&(v289_7),&(v289_11));
            join_wrapped_into(&mut v288_11_write,&((v289_12).read_zipper()),&[]);
            }
            v270_24_cursor.ascend(1);
          }
          drop(v288_11_write);
          map_map_kernels::compose(&(v283_10),&(v288_11))
        };
        drop(v283_10);
        let v292_6: Path = concat_path(&(v282_6),&v270_24_cursor.path()[(v270_24_origin + 1)..(v270_24_origin + 2)]);
        let v283_13: Space = map_kernels::wrap(&(v283_12),&(v292_6));
        let v283_14: Space = map_map_kernels::unite(&(v283_8),&(v283_13));
        join_wrapped_into(&mut v282_11_write,&((v283_14).read_zipper()),&[]);
        }
        v270_24_cursor.ascend(1);
      }
      drop(v282_11_write);
      drop(v282_6);
      map_map_kernels::compose(&(v271_10),&(v282_11))
    };
    drop(v271_10);
    let v271_13: Space = map_map_kernels::unite(&(v271_8),&(v271_12));
    join_wrapped_into(&mut v270_24_write,&((v271_13).read_zipper()),&[]);
    }
    v270_24_cursor.ascend(1);
  }
  drop(v270_24_cursor);
  drop(v270_24_write);
  (v270_24).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v293_24 = Space::new();
  let mut v293_24_write = v293_24.write_zipper();
  let mut v293_24_cursor = (*s0).read_zipper();
  let v293_24_origin = v293_24_cursor.path().len();
  for v293_24_byte in v293_24_cursor.child_mask().iter() {
    v293_24_cursor.descend_to_existing_byte(v293_24_byte);
    {
    let v294_2: Space = singleton(&v293_24_cursor.path()[v293_24_origin..(v293_24_origin + 1)]);
    let v294_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v294_2));
    let v294_4: Space = if map_kernels::has_head(&(v294_3)) { singleton(&[]) } else { Space::new() };
    drop(v294_3);
    let v294_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v294_4));
    drop(v294_4);
    let v294_8: Space = if (&(v294_5)).is_empty() { Space::new() } else {
      let v295_6: Path = concat_path(&(*p0),&v293_24_cursor.path()[v293_24_origin..(v293_24_origin + 1)]);
      let mut v295_7 = Space::new();
      let mut v295_7_write = v295_7.write_zipper();
      for v295_7_byte in v293_24_cursor.child_mask().iter() {
        v293_24_cursor.descend_to_existing_byte(v295_7_byte);
        {
        let v296_2: Space = singleton(&v293_24_cursor.path()[(v293_24_origin + 1)..(v293_24_origin + 2)]);
        let v296_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v296_2));
        let v296_4: Space = if map_kernels::has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
        drop(v296_3);
        let v296_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v296_4));
        drop(v296_4);
        let v296_8: Space = if (&(v296_5)).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v295_6),&v293_24_cursor.path()[(v293_24_origin + 1)..(v293_24_origin + 2)]);
          let mut v297_7 = Space::new();
          let mut v297_7_write = v297_7.write_zipper();
          for v297_7_byte in v293_24_cursor.child_mask().iter() {
            v293_24_cursor.descend_to_existing_byte(v297_7_byte);
            {
            let v298_2: Space = singleton(&v293_24_cursor.path()[(v293_24_origin + 2)..(v293_24_origin + 3)]);
            let v298_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v298_2));
            let v298_4: Space = if map_kernels::has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v298_4));
            drop(v298_4);
            let v298_8: Space = if (&(v298_5)).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v297_6),&v293_24_cursor.path()[(v293_24_origin + 2)..(v293_24_origin + 3)]);
              let v299_7: Space = routine_29(c, &(v299_6), &v293_24_cursor, &(*s1));
              map_map_kernels::compose(&(v298_5),&(v299_7))
            };
            drop(v298_5);
            let v298_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v298_2));
            drop(v298_2);
            let v298_10: Space = if map_kernels::has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
            drop(v298_9);
            let v298_12: Space = if (&(v298_10)).is_empty() { Space::new() } else {
              let v300_6: Path = concat_path(&(v297_6),&v293_24_cursor.path()[(v293_24_origin + 2)..(v293_24_origin + 3)]);
              let v300_11: Space = routine_30(c, &(v300_6), &v293_24_cursor, &(*s1));
              drop(v300_6);
              map_map_kernels::compose(&(v298_10),&(v300_11))
            };
            drop(v298_10);
            let v298_13: Space = map_map_kernels::unite(&(v298_8),&(v298_12));
            join_wrapped_into(&mut v297_7_write,&((v298_13).read_zipper()),&[]);
            }
            v293_24_cursor.ascend(1);
          }
          drop(v297_7_write);
          map_map_kernels::compose(&(v296_5),&(v297_7))
        };
        drop(v296_5);
        let v296_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v296_2));
        drop(v296_2);
        let v296_10: Space = if map_kernels::has_head(&(v296_9)) { singleton(&[]) } else { Space::new() };
        drop(v296_9);
        let v296_12: Space = if (&(v296_10)).is_empty() { Space::new() } else {
          let v301_6: Path = concat_path(&(v295_6),&v293_24_cursor.path()[(v293_24_origin + 1)..(v293_24_origin + 2)]);
          let mut v301_11 = Space::new();
          let mut v301_11_write = v301_11.write_zipper();
          for v301_11_byte in v293_24_cursor.child_mask().iter() {
            v293_24_cursor.descend_to_existing_byte(v301_11_byte);
            {
            let v302_2: Space = singleton(&v293_24_cursor.path()[(v293_24_origin + 2)..(v293_24_origin + 3)]);
            let v302_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v302_2));
            let v302_4: Space = if map_kernels::has_head(&(v302_3)) { singleton(&[]) } else { Space::new() };
            drop(v302_3);
            let v302_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v302_4));
            drop(v302_4);
            let v302_8: Space = if (&(v302_5)).is_empty() { Space::new() } else {
              let v303_6: Path = concat_path(&(v301_6),&v293_24_cursor.path()[(v293_24_origin + 2)..(v293_24_origin + 3)]);
              let v303_7: Space = routine_29(c, &(v303_6), &v293_24_cursor, &(*s1));
              map_map_kernels::compose(&(v302_5),&(v303_7))
            };
            drop(v302_5);
            let v302_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v302_2));
            drop(v302_2);
            let v302_10: Space = if map_kernels::has_head(&(v302_9)) { singleton(&[]) } else { Space::new() };
            drop(v302_9);
            let v302_12: Space = if (&(v302_10)).is_empty() { Space::new() } else {
              let v304_6: Path = concat_path(&(v301_6),&v293_24_cursor.path()[(v293_24_origin + 2)..(v293_24_origin + 3)]);
              let v304_11: Space = routine_9(c, &(v304_6), &v293_24_cursor, &(*s1));
              drop(v304_6);
              map_map_kernels::compose(&(v302_10),&(v304_11))
            };
            drop(v302_10);
            let v302_13: Space = map_map_kernels::unite(&(v302_8),&(v302_12));
            join_wrapped_into(&mut v301_11_write,&((v302_13).read_zipper()),&[]);
            }
            v293_24_cursor.ascend(1);
          }
          drop(v301_11_write);
          drop(v301_6);
          map_map_kernels::compose(&(v296_10),&(v301_11))
        };
        drop(v296_10);
        let v296_13: Space = map_map_kernels::unite(&(v296_8),&(v296_12));
        join_wrapped_into(&mut v295_7_write,&((v296_13).read_zipper()),&[]);
        }
        v293_24_cursor.ascend(1);
      }
      drop(v295_7_write);
      map_map_kernels::compose(&(v294_5),&(v295_7))
    };
    drop(v294_5);
    let v294_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v294_2));
    drop(v294_2);
    let v294_10: Space = if map_kernels::has_head(&(v294_9)) { singleton(&[]) } else { Space::new() };
    drop(v294_9);
    let v294_12: Space = if (&(v294_10)).is_empty() { Space::new() } else {
      let mut v305_11 = Space::new();
      let mut v305_11_write = v305_11.write_zipper();
      for v305_11_byte in v293_24_cursor.child_mask().iter() {
        v293_24_cursor.descend_to_existing_byte(v305_11_byte);
        {
        let v306_2: Space = singleton(&v293_24_cursor.path()[(v293_24_origin + 1)..(v293_24_origin + 2)]);
        let v306_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v306_2));
        let v306_4: Space = if map_kernels::has_head(&(v306_3)) { singleton(&[]) } else { Space::new() };
        drop(v306_3);
        let v306_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v306_4));
        drop(v306_4);
        let v306_7: Space = if (&(v306_5)).is_empty() { Space::new() } else {
          let mut v307_6 = Space::new();
          let mut v307_6_write = v307_6.write_zipper();
          for v307_6_byte in v293_24_cursor.child_mask().iter() {
            v293_24_cursor.descend_to_existing_byte(v307_6_byte);
            {
            let v308_2: Space = singleton(&v293_24_cursor.path()[(v293_24_origin + 2)..(v293_24_origin + 3)]);
            let v308_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v308_2));
            let v308_4: Space = if map_kernels::has_head(&(v308_3)) { singleton(&[]) } else { Space::new() };
            drop(v308_3);
            let v308_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v308_4));
            drop(v308_4);
            let v308_8: Space = if (&(v308_5)).is_empty() { Space::new() } else {
              let v309_7: Space = routine_31(c, &v293_24_cursor.path()[(v293_24_origin + 1)..(v293_24_origin + 3)], &v293_24_cursor, &(*s1));
              map_map_kernels::compose(&(v308_5),&(v309_7))
            };
            drop(v308_5);
            let v308_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v308_2));
            drop(v308_2);
            let v308_10: Space = if map_kernels::has_head(&(v308_9)) { singleton(&[]) } else { Space::new() };
            drop(v308_9);
            let v308_12: Space = if (&(v308_10)).is_empty() { Space::new() } else {
              let v310_11: Space = routine_32(c, &v293_24_cursor.path()[(v293_24_origin + 1)..(v293_24_origin + 3)], &v293_24_cursor, &(*s1));
              map_map_kernels::compose(&(v308_10),&(v310_11))
            };
            drop(v308_10);
            let v308_13: Space = map_map_kernels::unite(&(v308_8),&(v308_12));
            join_wrapped_into(&mut v307_6_write,&((v308_13).read_zipper()),&[]);
            }
            v293_24_cursor.ascend(1);
          }
          drop(v307_6_write);
          map_map_kernels::compose(&(v306_5),&(v307_6))
        };
        drop(v306_5);
        let v306_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v306_2));
        drop(v306_2);
        let v306_9: Space = if map_kernels::has_head(&(v306_8)) { singleton(&[]) } else { Space::new() };
        drop(v306_8);
        let v306_11: Space = if (&(v306_9)).is_empty() { Space::new() } else {
          let mut v311_10 = Space::new();
          let mut v311_10_write = v311_10.write_zipper();
          for v311_10_byte in v293_24_cursor.child_mask().iter() {
            v293_24_cursor.descend_to_existing_byte(v311_10_byte);
            {
            let v312_2: Space = singleton(&v293_24_cursor.path()[(v293_24_origin + 2)..(v293_24_origin + 3)]);
            let v312_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v312_2));
            let v312_4: Space = if map_kernels::has_head(&(v312_3)) { singleton(&[]) } else { Space::new() };
            drop(v312_3);
            let v312_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v312_4));
            drop(v312_4);
            let v312_8: Space = if (&(v312_5)).is_empty() { Space::new() } else {
              let v313_7: Space = routine_31(c, &v293_24_cursor.path()[(v293_24_origin + 1)..(v293_24_origin + 3)], &v293_24_cursor, &(*s1));
              map_map_kernels::compose(&(v312_5),&(v313_7))
            };
            drop(v312_5);
            let v312_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v312_2));
            drop(v312_2);
            let v312_10: Space = if map_kernels::has_head(&(v312_9)) { singleton(&[]) } else { Space::new() };
            drop(v312_9);
            let v312_12: Space = if (&(v312_10)).is_empty() { Space::new() } else {
              let v314_11: Space = routine_33(c, &v293_24_cursor.path()[(v293_24_origin + 1)..(v293_24_origin + 3)], &v293_24_cursor, &(*s1));
              map_map_kernels::compose(&(v312_10),&(v314_11))
            };
            drop(v312_10);
            let v312_13: Space = map_map_kernels::unite(&(v312_8),&(v312_12));
            join_wrapped_into(&mut v311_10_write,&((v312_13).read_zipper()),&[]);
            }
            v293_24_cursor.ascend(1);
          }
          drop(v311_10_write);
          map_map_kernels::compose(&(v306_9),&(v311_10))
        };
        drop(v306_9);
        let v306_12: Space = map_map_kernels::unite(&(v306_7),&(v306_11));
        join_wrapped_into(&mut v305_11_write,&((v306_12).read_zipper()),&[]);
        }
        v293_24_cursor.ascend(1);
      }
      drop(v305_11_write);
      map_map_kernels::compose(&(v294_10),&(v305_11))
    };
    drop(v294_10);
    let v315_6: Path = concat_path(&(*p0),&v293_24_cursor.path()[v293_24_origin..(v293_24_origin + 1)]);
    let v294_13: Space = map_kernels::wrap(&(v294_12),&(v315_6));
    let v294_14: Space = map_map_kernels::unite(&(v294_8),&(v294_13));
    join_wrapped_into(&mut v293_24_write,&((v294_14).read_zipper()),&[]);
    }
    v293_24_cursor.ascend(1);
  }
  drop(v293_24_cursor);
  drop(v293_24_write);
  (v293_24).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v316_26 = Space::new();
  let mut v316_26_write = v316_26.write_zipper();
  let mut v316_26_cursor = (*s0).read_zipper();
  let v316_26_origin = v316_26_cursor.path().len();
  for v316_26_byte in v316_26_cursor.child_mask().iter() {
    v316_26_cursor.descend_to_existing_byte(v316_26_byte);
    {
    let v317_2: Space = singleton(&v316_26_cursor.path()[v316_26_origin..(v316_26_origin + 1)]);
    let v317_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v317_2));
    let v317_4: Space = if map_kernels::has_head(&(v317_3)) { singleton(&[]) } else { Space::new() };
    drop(v317_3);
    let v317_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v317_4));
    drop(v317_4);
    let v317_7: Space = if (&(v317_5)).is_empty() { Space::new() } else {
      let mut v318_6 = Space::new();
      let mut v318_6_write = v318_6.write_zipper();
      for v318_6_byte in v316_26_cursor.child_mask().iter() {
        v316_26_cursor.descend_to_existing_byte(v318_6_byte);
        {
        let v319_2: Space = singleton(&v316_26_cursor.path()[(v316_26_origin + 1)..(v316_26_origin + 2)]);
        let v319_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v319_2));
        let v319_4: Space = if map_kernels::has_head(&(v319_3)) { singleton(&[]) } else { Space::new() };
        drop(v319_3);
        let v319_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v319_4));
        drop(v319_4);
        let v319_8: Space = if (&(v319_5)).is_empty() { Space::new() } else {
          let mut v320_7 = Space::new();
          let mut v320_7_write = v320_7.write_zipper();
          for v320_7_byte in v316_26_cursor.child_mask().iter() {
            v316_26_cursor.descend_to_existing_byte(v320_7_byte);
            {
            let v321_2: Space = singleton(&v316_26_cursor.path()[(v316_26_origin + 2)..(v316_26_origin + 3)]);
            let v321_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v321_2));
            let v321_4: Space = if map_kernels::has_head(&(v321_3)) { singleton(&[]) } else { Space::new() };
            drop(v321_3);
            let v321_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v321_4));
            drop(v321_4);
            let v321_8: Space = if (&(v321_5)).is_empty() { Space::new() } else {
              let v322_7: Space = routine_34(c, &v316_26_cursor.path()[v316_26_origin..(v316_26_origin + 3)], &v316_26_cursor, &(*s1));
              map_map_kernels::compose(&(v321_5),&(v322_7))
            };
            drop(v321_5);
            let v321_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v321_2));
            drop(v321_2);
            let v321_10: Space = if map_kernels::has_head(&(v321_9)) { singleton(&[]) } else { Space::new() };
            drop(v321_9);
            let v321_12: Space = if (&(v321_10)).is_empty() { Space::new() } else {
              let v323_11: Space = routine_35(c, &v316_26_cursor.path()[v316_26_origin..(v316_26_origin + 3)], &v316_26_cursor, &(*s1));
              map_map_kernels::compose(&(v321_10),&(v323_11))
            };
            drop(v321_10);
            let v321_13: Space = map_map_kernels::unite(&(v321_8),&(v321_12));
            join_wrapped_into(&mut v320_7_write,&((v321_13).read_zipper()),&[]);
            }
            v316_26_cursor.ascend(1);
          }
          drop(v320_7_write);
          map_map_kernels::compose(&(v319_5),&(v320_7))
        };
        drop(v319_5);
        let v319_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v319_2));
        drop(v319_2);
        let v319_10: Space = if map_kernels::has_head(&(v319_9)) { singleton(&[]) } else { Space::new() };
        drop(v319_9);
        let v319_12: Space = if (&(v319_10)).is_empty() { Space::new() } else {
          let mut v324_11 = Space::new();
          let mut v324_11_write = v324_11.write_zipper();
          for v324_11_byte in v316_26_cursor.child_mask().iter() {
            v316_26_cursor.descend_to_existing_byte(v324_11_byte);
            {
            let v325_2: Space = singleton(&v316_26_cursor.path()[(v316_26_origin + 2)..(v316_26_origin + 3)]);
            let v325_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v325_2));
            let v325_4: Space = if map_kernels::has_head(&(v325_3)) { singleton(&[]) } else { Space::new() };
            drop(v325_3);
            let v325_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v325_4));
            drop(v325_4);
            let v325_8: Space = if (&(v325_5)).is_empty() { Space::new() } else {
              let v326_7: Space = routine_34(c, &v316_26_cursor.path()[v316_26_origin..(v316_26_origin + 3)], &v316_26_cursor, &(*s1));
              map_map_kernels::compose(&(v325_5),&(v326_7))
            };
            drop(v325_5);
            let v325_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v325_2));
            drop(v325_2);
            let v325_10: Space = if map_kernels::has_head(&(v325_9)) { singleton(&[]) } else { Space::new() };
            drop(v325_9);
            let v325_12: Space = if (&(v325_10)).is_empty() { Space::new() } else {
              let v327_11: Space = routine_33(c, &v316_26_cursor.path()[v316_26_origin..(v316_26_origin + 3)], &v316_26_cursor, &(*s1));
              map_map_kernels::compose(&(v325_10),&(v327_11))
            };
            drop(v325_10);
            let v325_13: Space = map_map_kernels::unite(&(v325_8),&(v325_12));
            join_wrapped_into(&mut v324_11_write,&((v325_13).read_zipper()),&[]);
            }
            v316_26_cursor.ascend(1);
          }
          drop(v324_11_write);
          map_map_kernels::compose(&(v319_10),&(v324_11))
        };
        drop(v319_10);
        let v319_13: Space = map_map_kernels::unite(&(v319_8),&(v319_12));
        join_wrapped_into(&mut v318_6_write,&((v319_13).read_zipper()),&[]);
        }
        v316_26_cursor.ascend(1);
      }
      drop(v318_6_write);
      map_map_kernels::compose(&(v317_5),&(v318_6))
    };
    drop(v317_5);
    let v317_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v317_2));
    drop(v317_2);
    let v317_9: Space = if map_kernels::has_head(&(v317_8)) { singleton(&[]) } else { Space::new() };
    drop(v317_8);
    let v317_12: Space = if (&(v317_9)).is_empty() { Space::new() } else {
      let mut v328_11 = Space::new();
      let mut v328_11_write = v328_11.write_zipper();
      for v328_11_byte in v316_26_cursor.child_mask().iter() {
        v316_26_cursor.descend_to_existing_byte(v328_11_byte);
        {
        let v329_2: Space = singleton(&v316_26_cursor.path()[(v316_26_origin + 1)..(v316_26_origin + 2)]);
        let v329_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v329_2));
        let v329_4: Space = if map_kernels::has_head(&(v329_3)) { singleton(&[]) } else { Space::new() };
        drop(v329_3);
        let v329_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v329_4));
        drop(v329_4);
        let v329_8: Space = if (&(v329_5)).is_empty() { Space::new() } else {
          let mut v330_7 = Space::new();
          let mut v330_7_write = v330_7.write_zipper();
          for v330_7_byte in v316_26_cursor.child_mask().iter() {
            v316_26_cursor.descend_to_existing_byte(v330_7_byte);
            {
            let v331_2: Space = singleton(&v316_26_cursor.path()[(v316_26_origin + 2)..(v316_26_origin + 3)]);
            let v331_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v331_2));
            let v331_4: Space = if map_kernels::has_head(&(v331_3)) { singleton(&[]) } else { Space::new() };
            drop(v331_3);
            let v331_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v331_4));
            drop(v331_4);
            let v331_8: Space = if (&(v331_5)).is_empty() { Space::new() } else {
              let v332_7: Space = routine_34(c, &v316_26_cursor.path()[v316_26_origin..(v316_26_origin + 3)], &v316_26_cursor, &(*s1));
              map_map_kernels::compose(&(v331_5),&(v332_7))
            };
            drop(v331_5);
            let v331_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v331_2));
            drop(v331_2);
            let v331_10: Space = if map_kernels::has_head(&(v331_9)) { singleton(&[]) } else { Space::new() };
            drop(v331_9);
            let v331_12: Space = if (&(v331_10)).is_empty() { Space::new() } else {
              let v333_11: Space = routine_35(c, &v316_26_cursor.path()[v316_26_origin..(v316_26_origin + 3)], &v316_26_cursor, &(*s1));
              map_map_kernels::compose(&(v331_10),&(v333_11))
            };
            drop(v331_10);
            let v331_13: Space = map_map_kernels::unite(&(v331_8),&(v331_12));
            join_wrapped_into(&mut v330_7_write,&((v331_13).read_zipper()),&[]);
            }
            v316_26_cursor.ascend(1);
          }
          drop(v330_7_write);
          map_map_kernels::compose(&(v329_5),&(v330_7))
        };
        drop(v329_5);
        let v329_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v329_2));
        drop(v329_2);
        let v329_10: Space = if map_kernels::has_head(&(v329_9)) { singleton(&[]) } else { Space::new() };
        drop(v329_9);
        let v329_13: Space = if (&(v329_10)).is_empty() { Space::new() } else {
          let v334_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&v316_26_cursor.path()[v316_26_origin..(v316_26_origin + 1)]),&v316_26_cursor.path()[(v316_26_origin + 1)..(v316_26_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v329_10),&(v334_12))
        };
        drop(v329_10);
        let v329_14: Space = map_map_kernels::unite(&(v329_8),&(v329_13));
        drop(v329_13);
        join_wrapped_into(&mut v328_11_write,&((v329_14).read_zipper()),&[]);
        }
        v316_26_cursor.ascend(1);
      }
      drop(v328_11_write);
      map_map_kernels::compose(&(v317_9),&(v328_11))
    };
    drop(v317_9);
    let v317_13: Space = map_map_kernels::unite(&(v317_7),&(v317_12));
    join_wrapped_into(&mut v316_26_write,&((v317_13).read_zipper()),&[]);
    }
    v316_26_cursor.ascend(1);
  }
  drop(v316_26_cursor);
  drop(v316_26_write);
  let v316_27: Space = map_kernels::wrap(&(v316_26),&(*p0));
  (v316_27).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v335_27 = Space::new();
  let mut v335_27_write = v335_27.write_zipper();
  let mut v335_27_cursor = (*s0).read_zipper();
  let v335_27_origin = v335_27_cursor.path().len();
  for v335_27_byte in v335_27_cursor.child_mask().iter() {
    v335_27_cursor.descend_to_existing_byte(v335_27_byte);
    {
    let v336_2: Space = singleton(&v335_27_cursor.path()[v335_27_origin..(v335_27_origin + 1)]);
    let v336_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v336_2));
    let v336_4: Space = if map_kernels::has_head(&(v336_3)) { singleton(&[]) } else { Space::new() };
    drop(v336_3);
    let v336_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v336_4));
    drop(v336_4);
    let v336_8: Space = if (&(v336_5)).is_empty() { Space::new() } else {
      let v337_6: Path = concat_path(&(*p0),&v335_27_cursor.path()[v335_27_origin..(v335_27_origin + 1)]);
      let mut v337_7 = Space::new();
      let mut v337_7_write = v337_7.write_zipper();
      for v337_7_byte in v335_27_cursor.child_mask().iter() {
        v335_27_cursor.descend_to_existing_byte(v337_7_byte);
        {
        let v338_2: Space = singleton(&v335_27_cursor.path()[(v335_27_origin + 1)..(v335_27_origin + 2)]);
        let v338_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v338_2));
        let v338_4: Space = if map_kernels::has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
        drop(v338_3);
        let v338_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v338_4));
        drop(v338_4);
        let v338_8: Space = if (&(v338_5)).is_empty() { Space::new() } else {
          let v339_6: Path = concat_path(&(v337_6),&v335_27_cursor.path()[(v335_27_origin + 1)..(v335_27_origin + 2)]);
          let mut v339_7 = Space::new();
          let mut v339_7_write = v339_7.write_zipper();
          for v339_7_byte in v335_27_cursor.child_mask().iter() {
            v335_27_cursor.descend_to_existing_byte(v339_7_byte);
            {
            let v340_2: Space = singleton(&v335_27_cursor.path()[(v335_27_origin + 2)..(v335_27_origin + 3)]);
            let v340_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v340_2));
            let v340_4: Space = if map_kernels::has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
            drop(v340_3);
            let v340_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v340_4));
            drop(v340_4);
            let v340_8: Space = if (&(v340_5)).is_empty() { Space::new() } else {
              let v341_6: Path = concat_path(&(v339_6),&v335_27_cursor.path()[(v335_27_origin + 2)..(v335_27_origin + 3)]);
              let v341_7: Space = routine_36(c, &(v341_6), &v335_27_cursor, &(*s1));
              map_map_kernels::compose(&(v340_5),&(v341_7))
            };
            drop(v340_5);
            let v340_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v340_2));
            drop(v340_2);
            let v340_10: Space = if map_kernels::has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
            drop(v340_9);
            let v340_12: Space = if (&(v340_10)).is_empty() { Space::new() } else {
              let v342_6: Path = concat_path(&(v339_6),&v335_27_cursor.path()[(v335_27_origin + 2)..(v335_27_origin + 3)]);
              let v342_11: Space = routine_37(c, &(v342_6), &v335_27_cursor, &(*s1));
              drop(v342_6);
              map_map_kernels::compose(&(v340_10),&(v342_11))
            };
            drop(v340_10);
            let v340_13: Space = map_map_kernels::unite(&(v340_8),&(v340_12));
            join_wrapped_into(&mut v339_7_write,&((v340_13).read_zipper()),&[]);
            }
            v335_27_cursor.ascend(1);
          }
          drop(v339_7_write);
          map_map_kernels::compose(&(v338_5),&(v339_7))
        };
        drop(v338_5);
        let v338_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v338_2));
        drop(v338_2);
        let v338_10: Space = if map_kernels::has_head(&(v338_9)) { singleton(&[]) } else { Space::new() };
        drop(v338_9);
        let v338_12: Space = if (&(v338_10)).is_empty() { Space::new() } else {
          let v343_6: Path = concat_path(&(v337_6),&v335_27_cursor.path()[(v335_27_origin + 1)..(v335_27_origin + 2)]);
          let mut v343_11 = Space::new();
          let mut v343_11_write = v343_11.write_zipper();
          for v343_11_byte in v335_27_cursor.child_mask().iter() {
            v335_27_cursor.descend_to_existing_byte(v343_11_byte);
            {
            let v344_2: Space = singleton(&v335_27_cursor.path()[(v335_27_origin + 2)..(v335_27_origin + 3)]);
            let v344_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v344_2));
            let v344_4: Space = if map_kernels::has_head(&(v344_3)) { singleton(&[]) } else { Space::new() };
            drop(v344_3);
            let v344_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v344_4));
            drop(v344_4);
            let v344_8: Space = if (&(v344_5)).is_empty() { Space::new() } else {
              let v345_6: Path = concat_path(&(v343_6),&v335_27_cursor.path()[(v335_27_origin + 2)..(v335_27_origin + 3)]);
              let v345_7: Space = routine_36(c, &(v345_6), &v335_27_cursor, &(*s1));
              map_map_kernels::compose(&(v344_5),&(v345_7))
            };
            drop(v344_5);
            let v344_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v344_2));
            drop(v344_2);
            let v344_10: Space = if map_kernels::has_head(&(v344_9)) { singleton(&[]) } else { Space::new() };
            drop(v344_9);
            let v344_12: Space = if (&(v344_10)).is_empty() { Space::new() } else {
              let v346_6: Path = concat_path(&(v343_6),&v335_27_cursor.path()[(v335_27_origin + 2)..(v335_27_origin + 3)]);
              let v346_11: Space = routine_33(c, &(v346_6), &v335_27_cursor, &(*s1));
              drop(v346_6);
              map_map_kernels::compose(&(v344_10),&(v346_11))
            };
            drop(v344_10);
            let v344_13: Space = map_map_kernels::unite(&(v344_8),&(v344_12));
            join_wrapped_into(&mut v343_11_write,&((v344_13).read_zipper()),&[]);
            }
            v335_27_cursor.ascend(1);
          }
          drop(v343_11_write);
          drop(v343_6);
          map_map_kernels::compose(&(v338_10),&(v343_11))
        };
        drop(v338_10);
        let v338_13: Space = map_map_kernels::unite(&(v338_8),&(v338_12));
        join_wrapped_into(&mut v337_7_write,&((v338_13).read_zipper()),&[]);
        }
        v335_27_cursor.ascend(1);
      }
      drop(v337_7_write);
      map_map_kernels::compose(&(v336_5),&(v337_7))
    };
    drop(v336_5);
    let v336_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v336_2));
    drop(v336_2);
    let v336_10: Space = if map_kernels::has_head(&(v336_9)) { singleton(&[]) } else { Space::new() };
    drop(v336_9);
    let v336_13: Space = if (&(v336_10)).is_empty() { Space::new() } else {
      let v347_6: Path = concat_path(&(*p0),&v335_27_cursor.path()[v335_27_origin..(v335_27_origin + 1)]);
      let mut v347_12 = Space::new();
      let mut v347_12_write = v347_12.write_zipper();
      for v347_12_byte in v335_27_cursor.child_mask().iter() {
        v335_27_cursor.descend_to_existing_byte(v347_12_byte);
        {
        let v348_2: Space = singleton(&v335_27_cursor.path()[(v335_27_origin + 1)..(v335_27_origin + 2)]);
        let v348_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v348_2));
        let v348_4: Space = if map_kernels::has_head(&(v348_3)) { singleton(&[]) } else { Space::new() };
        drop(v348_3);
        let v348_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v348_4));
        drop(v348_4);
        let v348_8: Space = if (&(v348_5)).is_empty() { Space::new() } else {
          let v349_6: Path = concat_path(&(v347_6),&v335_27_cursor.path()[(v335_27_origin + 1)..(v335_27_origin + 2)]);
          let mut v349_7 = Space::new();
          let mut v349_7_write = v349_7.write_zipper();
          for v349_7_byte in v335_27_cursor.child_mask().iter() {
            v335_27_cursor.descend_to_existing_byte(v349_7_byte);
            {
            let v350_2: Space = singleton(&v335_27_cursor.path()[(v335_27_origin + 2)..(v335_27_origin + 3)]);
            let v350_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v350_2));
            let v350_4: Space = if map_kernels::has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
            drop(v350_3);
            let v350_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v350_4));
            drop(v350_4);
            let v350_8: Space = if (&(v350_5)).is_empty() { Space::new() } else {
              let v351_6: Path = concat_path(&(v349_6),&v335_27_cursor.path()[(v335_27_origin + 2)..(v335_27_origin + 3)]);
              let v351_7: Space = routine_36(c, &(v351_6), &v335_27_cursor, &(*s1));
              map_map_kernels::compose(&(v350_5),&(v351_7))
            };
            drop(v350_5);
            let v350_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v350_2));
            drop(v350_2);
            let v350_10: Space = if map_kernels::has_head(&(v350_9)) { singleton(&[]) } else { Space::new() };
            drop(v350_9);
            let v350_12: Space = if (&(v350_10)).is_empty() { Space::new() } else {
              let v352_6: Path = concat_path(&(v349_6),&v335_27_cursor.path()[(v335_27_origin + 2)..(v335_27_origin + 3)]);
              let v352_11: Space = routine_37(c, &(v352_6), &v335_27_cursor, &(*s1));
              drop(v352_6);
              map_map_kernels::compose(&(v350_10),&(v352_11))
            };
            drop(v350_10);
            let v350_13: Space = map_map_kernels::unite(&(v350_8),&(v350_12));
            join_wrapped_into(&mut v349_7_write,&((v350_13).read_zipper()),&[]);
            }
            v335_27_cursor.ascend(1);
          }
          drop(v349_7_write);
          drop(v349_6);
          map_map_kernels::compose(&(v348_5),&(v349_7))
        };
        drop(v348_5);
        let v348_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v348_2));
        drop(v348_2);
        let v348_10: Space = if map_kernels::has_head(&(v348_9)) { singleton(&[]) } else { Space::new() };
        drop(v348_9);
        let v348_13: Space = if (&(v348_10)).is_empty() { Space::new() } else {
          let v353_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v335_27_cursor.path()[v335_27_origin..(v335_27_origin + 1)]),&v335_27_cursor.path()[(v335_27_origin + 1)..(v335_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v348_10),&(v353_12))
        };
        drop(v348_10);
        let v348_14: Space = map_map_kernels::unite(&(v348_8),&(v348_13));
        drop(v348_13);
        join_wrapped_into(&mut v347_12_write,&((v348_14).read_zipper()),&[]);
        }
        v335_27_cursor.ascend(1);
      }
      drop(v347_12_write);
      drop(v347_6);
      map_map_kernels::compose(&(v336_10),&(v347_12))
    };
    drop(v336_10);
    let v336_14: Space = map_map_kernels::unite(&(v336_8),&(v336_13));
    join_wrapped_into(&mut v335_27_write,&((v336_14).read_zipper()),&[]);
    }
    v335_27_cursor.ascend(1);
  }
  drop(v335_27_cursor);
  drop(v335_27_write);
  (v335_27).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v354_21 = Space::new();
  let mut v354_21_write = v354_21.write_zipper();
  let mut v354_21_cursor = (*s0).read_zipper();
  let v354_21_origin = v354_21_cursor.path().len();
  for v354_21_byte in v354_21_cursor.child_mask().iter() {
    v354_21_cursor.descend_to_existing_byte(v354_21_byte);
    {
    let v355_2: Space = singleton(&v354_21_cursor.path()[v354_21_origin..(v354_21_origin + 1)]);
    let v355_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v355_2));
    let v355_4: Space = if map_kernels::has_head(&(v355_3)) { singleton(&[]) } else { Space::new() };
    drop(v355_3);
    let v355_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v355_4));
    drop(v355_4);
    let v355_8: Space = if (&(v355_5)).is_empty() { Space::new() } else {
      let v356_6: Path = concat_path(&(*p0),&v354_21_cursor.path()[v354_21_origin..(v354_21_origin + 1)]);
      let mut v356_7 = Space::new();
      let mut v356_7_write = v356_7.write_zipper();
      for v356_7_byte in v354_21_cursor.child_mask().iter() {
        v354_21_cursor.descend_to_existing_byte(v356_7_byte);
        {
        let v357_2: Space = singleton(&v354_21_cursor.path()[(v354_21_origin + 1)..(v354_21_origin + 2)]);
        let v357_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v357_2));
        let v357_4: Space = if map_kernels::has_head(&(v357_3)) { singleton(&[]) } else { Space::new() };
        drop(v357_3);
        let v357_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v357_4));
        drop(v357_4);
        let v357_8: Space = if (&(v357_5)).is_empty() { Space::new() } else {
          let v358_6: Path = concat_path(&(v356_6),&v354_21_cursor.path()[(v354_21_origin + 1)..(v354_21_origin + 2)]);
          let mut v358_7 = Space::new();
          let mut v358_7_write = v358_7.write_zipper();
          for v358_7_byte in v354_21_cursor.child_mask().iter() {
            v354_21_cursor.descend_to_existing_byte(v358_7_byte);
            {
            let v359_2: Space = singleton(&v354_21_cursor.path()[(v354_21_origin + 2)..(v354_21_origin + 3)]);
            let v359_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v359_2));
            let v359_4: Space = if map_kernels::has_head(&(v359_3)) { singleton(&[]) } else { Space::new() };
            drop(v359_3);
            let v359_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v359_4));
            drop(v359_4);
            let v359_8: Space = if (&(v359_5)).is_empty() { Space::new() } else {
              let v360_6: Path = concat_path(&(v358_6),&v354_21_cursor.path()[(v354_21_origin + 2)..(v354_21_origin + 3)]);
              let v360_7: Space = routine_36(c, &(v360_6), &v354_21_cursor, &(*s1));
              map_map_kernels::compose(&(v359_5),&(v360_7))
            };
            drop(v359_5);
            let v359_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v359_2));
            drop(v359_2);
            let v359_10: Space = if map_kernels::has_head(&(v359_9)) { singleton(&[]) } else { Space::new() };
            drop(v359_9);
            let v359_12: Space = if (&(v359_10)).is_empty() { Space::new() } else {
              let v361_6: Path = concat_path(&(v358_6),&v354_21_cursor.path()[(v354_21_origin + 2)..(v354_21_origin + 3)]);
              let v361_11: Space = routine_37(c, &(v361_6), &v354_21_cursor, &(*s1));
              drop(v361_6);
              map_map_kernels::compose(&(v359_10),&(v361_11))
            };
            drop(v359_10);
            let v359_13: Space = map_map_kernels::unite(&(v359_8),&(v359_12));
            join_wrapped_into(&mut v358_7_write,&((v359_13).read_zipper()),&[]);
            }
            v354_21_cursor.ascend(1);
          }
          drop(v358_7_write);
          map_map_kernels::compose(&(v357_5),&(v358_7))
        };
        drop(v357_5);
        let v357_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v357_2));
        drop(v357_2);
        let v357_10: Space = if map_kernels::has_head(&(v357_9)) { singleton(&[]) } else { Space::new() };
        drop(v357_9);
        let v357_12: Space = if (&(v357_10)).is_empty() { Space::new() } else {
          let v362_6: Path = concat_path(&(v356_6),&v354_21_cursor.path()[(v354_21_origin + 1)..(v354_21_origin + 2)]);
          let mut v362_11 = Space::new();
          let mut v362_11_write = v362_11.write_zipper();
          for v362_11_byte in v354_21_cursor.child_mask().iter() {
            v354_21_cursor.descend_to_existing_byte(v362_11_byte);
            {
            let v363_2: Space = singleton(&v354_21_cursor.path()[(v354_21_origin + 2)..(v354_21_origin + 3)]);
            let v363_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v363_2));
            let v363_4: Space = if map_kernels::has_head(&(v363_3)) { singleton(&[]) } else { Space::new() };
            drop(v363_3);
            let v363_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v363_4));
            drop(v363_4);
            let v363_8: Space = if (&(v363_5)).is_empty() { Space::new() } else {
              let v364_6: Path = concat_path(&(v362_6),&v354_21_cursor.path()[(v354_21_origin + 2)..(v354_21_origin + 3)]);
              let v364_7: Space = routine_36(c, &(v364_6), &v354_21_cursor, &(*s1));
              map_map_kernels::compose(&(v363_5),&(v364_7))
            };
            drop(v363_5);
            let v363_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v363_2));
            drop(v363_2);
            let v363_10: Space = if map_kernels::has_head(&(v363_9)) { singleton(&[]) } else { Space::new() };
            drop(v363_9);
            let v363_12: Space = if (&(v363_10)).is_empty() { Space::new() } else {
              let v365_6: Path = concat_path(&(v362_6),&v354_21_cursor.path()[(v354_21_origin + 2)..(v354_21_origin + 3)]);
              let v365_11: Space = routine_33(c, &(v365_6), &v354_21_cursor, &(*s1));
              drop(v365_6);
              map_map_kernels::compose(&(v363_10),&(v365_11))
            };
            drop(v363_10);
            let v363_13: Space = map_map_kernels::unite(&(v363_8),&(v363_12));
            join_wrapped_into(&mut v362_11_write,&((v363_13).read_zipper()),&[]);
            }
            v354_21_cursor.ascend(1);
          }
          drop(v362_11_write);
          drop(v362_6);
          map_map_kernels::compose(&(v357_10),&(v362_11))
        };
        drop(v357_10);
        let v357_13: Space = map_map_kernels::unite(&(v357_8),&(v357_12));
        join_wrapped_into(&mut v356_7_write,&((v357_13).read_zipper()),&[]);
        }
        v354_21_cursor.ascend(1);
      }
      drop(v356_7_write);
      drop(v356_6);
      map_map_kernels::compose(&(v355_5),&(v356_7))
    };
    drop(v355_5);
    let v355_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v355_2));
    drop(v355_2);
    let v355_10: Space = if map_kernels::has_head(&(v355_9)) { singleton(&[]) } else { Space::new() };
    drop(v355_9);
    let v355_13: Space = if (&(v355_10)).is_empty() { Space::new() } else {
      let v366_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v354_21_cursor.path()[v354_21_origin..(v354_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v355_10),&(v366_12))
    };
    drop(v355_10);
    let v355_14: Space = map_map_kernels::unite(&(v355_8),&(v355_13));
    drop(v355_13);
    join_wrapped_into(&mut v354_21_write,&((v355_14).read_zipper()),&[]);
    }
    v354_21_cursor.ascend(1);
  }
  drop(v354_21_cursor);
  drop(v354_21_write);
  (v354_21).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v367_21 = Space::new();
  let mut v367_21_write = v367_21.write_zipper();
  let mut v367_21_cursor = (*s0).read_zipper();
  let v367_21_origin = v367_21_cursor.path().len();
  for v367_21_byte in v367_21_cursor.child_mask().iter() {
    v367_21_cursor.descend_to_existing_byte(v367_21_byte);
    {
    let v368_2: Space = singleton(&v367_21_cursor.path()[v367_21_origin..(v367_21_origin + 1)]);
    let v368_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v368_2));
    let v368_4: Space = if map_kernels::has_head(&(v368_3)) { singleton(&[]) } else { Space::new() };
    drop(v368_3);
    let v368_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v368_4));
    drop(v368_4);
    let v368_8: Space = if (&(v368_5)).is_empty() { Space::new() } else {
      let v369_6: Path = concat_path(&(*p0),&v367_21_cursor.path()[v367_21_origin..(v367_21_origin + 1)]);
      let mut v369_7 = Space::new();
      let mut v369_7_write = v369_7.write_zipper();
      for v369_7_byte in v367_21_cursor.child_mask().iter() {
        v367_21_cursor.descend_to_existing_byte(v369_7_byte);
        {
        let v370_2: Space = singleton(&v367_21_cursor.path()[(v367_21_origin + 1)..(v367_21_origin + 2)]);
        let v370_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v370_2));
        let v370_4: Space = if map_kernels::has_head(&(v370_3)) { singleton(&[]) } else { Space::new() };
        drop(v370_3);
        let v370_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v370_4));
        drop(v370_4);
        let v370_8: Space = if (&(v370_5)).is_empty() { Space::new() } else {
          let v371_6: Path = concat_path(&(v369_6),&v367_21_cursor.path()[(v367_21_origin + 1)..(v367_21_origin + 2)]);
          let mut v371_7 = Space::new();
          let mut v371_7_write = v371_7.write_zipper();
          for v371_7_byte in v367_21_cursor.child_mask().iter() {
            v367_21_cursor.descend_to_existing_byte(v371_7_byte);
            {
            let v372_2: Space = singleton(&v367_21_cursor.path()[(v367_21_origin + 2)..(v367_21_origin + 3)]);
            let v372_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v372_2));
            let v372_4: Space = if map_kernels::has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
            drop(v372_3);
            let v372_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v372_4));
            drop(v372_4);
            let v372_8: Space = if (&(v372_5)).is_empty() { Space::new() } else {
              let v373_6: Path = concat_path(&(v371_6),&v367_21_cursor.path()[(v367_21_origin + 2)..(v367_21_origin + 3)]);
              let v373_7: Space = routine_38(c, &(v373_6), &v367_21_cursor);
              map_map_kernels::compose(&(v372_5),&(v373_7))
            };
            drop(v372_5);
            let v372_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v372_2));
            drop(v372_2);
            let v372_10: Space = if map_kernels::has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
            drop(v372_9);
            let v372_12: Space = if (&(v372_10)).is_empty() { Space::new() } else {
              let v374_6: Path = concat_path(&(v371_6),&v367_21_cursor.path()[(v367_21_origin + 2)..(v367_21_origin + 3)]);
              let v374_11: Space = routine_39(c, &(v374_6), &v367_21_cursor);
              drop(v374_6);
              map_map_kernels::compose(&(v372_10),&(v374_11))
            };
            drop(v372_10);
            let v372_13: Space = map_map_kernels::unite(&(v372_8),&(v372_12));
            join_wrapped_into(&mut v371_7_write,&((v372_13).read_zipper()),&[]);
            }
            v367_21_cursor.ascend(1);
          }
          drop(v371_7_write);
          map_map_kernels::compose(&(v370_5),&(v371_7))
        };
        drop(v370_5);
        let v370_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v370_2));
        drop(v370_2);
        let v370_10: Space = if map_kernels::has_head(&(v370_9)) { singleton(&[]) } else { Space::new() };
        drop(v370_9);
        let v370_12: Space = if (&(v370_10)).is_empty() { Space::new() } else {
          let v375_6: Path = concat_path(&(v369_6),&v367_21_cursor.path()[(v367_21_origin + 1)..(v367_21_origin + 2)]);
          let mut v375_11 = Space::new();
          let mut v375_11_write = v375_11.write_zipper();
          for v375_11_byte in v367_21_cursor.child_mask().iter() {
            v367_21_cursor.descend_to_existing_byte(v375_11_byte);
            {
            let v376_2: Space = singleton(&v367_21_cursor.path()[(v367_21_origin + 2)..(v367_21_origin + 3)]);
            let v376_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v376_2));
            let v376_4: Space = if map_kernels::has_head(&(v376_3)) { singleton(&[]) } else { Space::new() };
            drop(v376_3);
            let v376_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v376_4));
            drop(v376_4);
            let v376_8: Space = if (&(v376_5)).is_empty() { Space::new() } else {
              let v377_6: Path = concat_path(&(v375_6),&v367_21_cursor.path()[(v367_21_origin + 2)..(v367_21_origin + 3)]);
              let v377_7: Space = routine_38(c, &(v377_6), &v367_21_cursor);
              map_map_kernels::compose(&(v376_5),&(v377_7))
            };
            drop(v376_5);
            let v376_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v376_2));
            drop(v376_2);
            let v376_10: Space = if map_kernels::has_head(&(v376_9)) { singleton(&[]) } else { Space::new() };
            drop(v376_9);
            let v376_12: Space = if (&(v376_10)).is_empty() { Space::new() } else {
              let v378_6: Path = concat_path(&(v375_6),&v367_21_cursor.path()[(v367_21_origin + 2)..(v367_21_origin + 3)]);
              let v378_11: Space = routine_14(c, &(v378_6), &v367_21_cursor);
              drop(v378_6);
              map_map_kernels::compose(&(v376_10),&(v378_11))
            };
            drop(v376_10);
            let v376_13: Space = map_map_kernels::unite(&(v376_8),&(v376_12));
            join_wrapped_into(&mut v375_11_write,&((v376_13).read_zipper()),&[]);
            }
            v367_21_cursor.ascend(1);
          }
          drop(v375_11_write);
          drop(v375_6);
          map_map_kernels::compose(&(v370_10),&(v375_11))
        };
        drop(v370_10);
        let v370_13: Space = map_map_kernels::unite(&(v370_8),&(v370_12));
        join_wrapped_into(&mut v369_7_write,&((v370_13).read_zipper()),&[]);
        }
        v367_21_cursor.ascend(1);
      }
      drop(v369_7_write);
      map_map_kernels::compose(&(v368_5),&(v369_7))
    };
    drop(v368_5);
    let v368_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v368_2));
    drop(v368_2);
    let v368_10: Space = if map_kernels::has_head(&(v368_9)) { singleton(&[]) } else { Space::new() };
    drop(v368_9);
    let v368_12: Space = if (&(v368_10)).is_empty() { Space::new() } else {
      let v379_6: Path = concat_path(&(*p0),&v367_21_cursor.path()[v367_21_origin..(v367_21_origin + 1)]);
      let mut v379_11 = Space::new();
      let mut v379_11_write = v379_11.write_zipper();
      for v379_11_byte in v367_21_cursor.child_mask().iter() {
        v367_21_cursor.descend_to_existing_byte(v379_11_byte);
        {
        let v380_2: Space = singleton(&v367_21_cursor.path()[(v367_21_origin + 1)..(v367_21_origin + 2)]);
        let v380_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v380_2));
        let v380_4: Space = if map_kernels::has_head(&(v380_3)) { singleton(&[]) } else { Space::new() };
        drop(v380_3);
        let v380_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v380_4));
        drop(v380_4);
        let v380_8: Space = if (&(v380_5)).is_empty() { Space::new() } else {
          let v381_6: Path = concat_path(&(v379_6),&v367_21_cursor.path()[(v367_21_origin + 1)..(v367_21_origin + 2)]);
          let mut v381_7 = Space::new();
          let mut v381_7_write = v381_7.write_zipper();
          for v381_7_byte in v367_21_cursor.child_mask().iter() {
            v367_21_cursor.descend_to_existing_byte(v381_7_byte);
            {
            let v382_2: Space = singleton(&v367_21_cursor.path()[(v367_21_origin + 2)..(v367_21_origin + 3)]);
            let v382_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v382_2));
            let v382_4: Space = if map_kernels::has_head(&(v382_3)) { singleton(&[]) } else { Space::new() };
            drop(v382_3);
            let v382_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v382_4));
            drop(v382_4);
            let v382_8: Space = if (&(v382_5)).is_empty() { Space::new() } else {
              let v383_6: Path = concat_path(&(v381_6),&v367_21_cursor.path()[(v367_21_origin + 2)..(v367_21_origin + 3)]);
              let v383_7: Space = routine_38(c, &(v383_6), &v367_21_cursor);
              map_map_kernels::compose(&(v382_5),&(v383_7))
            };
            drop(v382_5);
            let v382_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v382_2));
            drop(v382_2);
            let v382_10: Space = if map_kernels::has_head(&(v382_9)) { singleton(&[]) } else { Space::new() };
            drop(v382_9);
            let v382_12: Space = if (&(v382_10)).is_empty() { Space::new() } else {
              let v384_6: Path = concat_path(&(v381_6),&v367_21_cursor.path()[(v367_21_origin + 2)..(v367_21_origin + 3)]);
              let v384_11: Space = routine_39(c, &(v384_6), &v367_21_cursor);
              drop(v384_6);
              map_map_kernels::compose(&(v382_10),&(v384_11))
            };
            drop(v382_10);
            let v382_13: Space = map_map_kernels::unite(&(v382_8),&(v382_12));
            join_wrapped_into(&mut v381_7_write,&((v382_13).read_zipper()),&[]);
            }
            v367_21_cursor.ascend(1);
          }
          drop(v381_7_write);
          map_map_kernels::compose(&(v380_5),&(v381_7))
        };
        drop(v380_5);
        let v380_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v380_2));
        drop(v380_2);
        let v380_10: Space = if map_kernels::has_head(&(v380_9)) { singleton(&[]) } else { Space::new() };
        drop(v380_9);
        let v380_12: Space = if (&(v380_10)).is_empty() { Space::new() } else {
          let v385_11: Space = view_map_kernels::subtract(&v367_21_cursor,&(*CONSTANT_5));
          map_map_kernels::compose(&(v380_10),&(v385_11))
        };
        drop(v380_10);
        let v386_6: Path = concat_path(&(v379_6),&v367_21_cursor.path()[(v367_21_origin + 1)..(v367_21_origin + 2)]);
        let v380_13: Space = map_kernels::wrap(&(v380_12),&(v386_6));
        drop(v380_12);
        let v380_14: Space = map_map_kernels::unite(&(v380_8),&(v380_13));
        drop(v380_13);
        join_wrapped_into(&mut v379_11_write,&((v380_14).read_zipper()),&[]);
        }
        v367_21_cursor.ascend(1);
      }
      drop(v379_11_write);
      drop(v379_6);
      map_map_kernels::compose(&(v368_10),&(v379_11))
    };
    drop(v368_10);
    let v368_13: Space = map_map_kernels::unite(&(v368_8),&(v368_12));
    join_wrapped_into(&mut v367_21_write,&((v368_13).read_zipper()),&[]);
    }
    v367_21_cursor.ascend(1);
  }
  drop(v367_21_cursor);
  drop(v367_21_write);
  (v367_21).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v387_15 = Space::new();
  let mut v387_15_write = v387_15.write_zipper();
  let mut v387_15_cursor = (*s0).read_zipper();
  let v387_15_origin = v387_15_cursor.path().len();
  for v387_15_byte in v387_15_cursor.child_mask().iter() {
    v387_15_cursor.descend_to_existing_byte(v387_15_byte);
    {
    let v388_2: Space = singleton(&v387_15_cursor.path()[v387_15_origin..(v387_15_origin + 1)]);
    let v388_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v388_2));
    let v388_4: Space = if map_kernels::has_head(&(v388_3)) { singleton(&[]) } else { Space::new() };
    drop(v388_3);
    let v388_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v388_4));
    drop(v388_4);
    let v388_8: Space = if (&(v388_5)).is_empty() { Space::new() } else {
      let v389_6: Path = concat_path(&(*p0),&v387_15_cursor.path()[v387_15_origin..(v387_15_origin + 1)]);
      let mut v389_7 = Space::new();
      let mut v389_7_write = v389_7.write_zipper();
      for v389_7_byte in v387_15_cursor.child_mask().iter() {
        v387_15_cursor.descend_to_existing_byte(v389_7_byte);
        {
        let v390_2: Space = singleton(&v387_15_cursor.path()[(v387_15_origin + 1)..(v387_15_origin + 2)]);
        let v390_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v390_2));
        let v390_4: Space = if map_kernels::has_head(&(v390_3)) { singleton(&[]) } else { Space::new() };
        drop(v390_3);
        let v390_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v390_4));
        drop(v390_4);
        let v390_8: Space = if (&(v390_5)).is_empty() { Space::new() } else {
          let v391_6: Path = concat_path(&(v389_6),&v387_15_cursor.path()[(v387_15_origin + 1)..(v387_15_origin + 2)]);
          let mut v391_7 = Space::new();
          let mut v391_7_write = v391_7.write_zipper();
          for v391_7_byte in v387_15_cursor.child_mask().iter() {
            v387_15_cursor.descend_to_existing_byte(v391_7_byte);
            {
            let v392_2: Space = singleton(&v387_15_cursor.path()[(v387_15_origin + 2)..(v387_15_origin + 3)]);
            let v392_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v392_2));
            let v392_4: Space = if map_kernels::has_head(&(v392_3)) { singleton(&[]) } else { Space::new() };
            drop(v392_3);
            let v392_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v392_4));
            drop(v392_4);
            let v392_8: Space = if (&(v392_5)).is_empty() { Space::new() } else {
              let v393_6: Path = concat_path(&(v391_6),&v387_15_cursor.path()[(v387_15_origin + 2)..(v387_15_origin + 3)]);
              let v393_7: Space = routine_38(c, &(v393_6), &v387_15_cursor);
              map_map_kernels::compose(&(v392_5),&(v393_7))
            };
            drop(v392_5);
            let v392_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v392_2));
            drop(v392_2);
            let v392_10: Space = if map_kernels::has_head(&(v392_9)) { singleton(&[]) } else { Space::new() };
            drop(v392_9);
            let v392_12: Space = if (&(v392_10)).is_empty() { Space::new() } else {
              let v394_6: Path = concat_path(&(v391_6),&v387_15_cursor.path()[(v387_15_origin + 2)..(v387_15_origin + 3)]);
              let v394_11: Space = routine_39(c, &(v394_6), &v387_15_cursor);
              drop(v394_6);
              map_map_kernels::compose(&(v392_10),&(v394_11))
            };
            drop(v392_10);
            let v392_13: Space = map_map_kernels::unite(&(v392_8),&(v392_12));
            join_wrapped_into(&mut v391_7_write,&((v392_13).read_zipper()),&[]);
            }
            v387_15_cursor.ascend(1);
          }
          drop(v391_7_write);
          map_map_kernels::compose(&(v390_5),&(v391_7))
        };
        drop(v390_5);
        let v390_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v390_2));
        drop(v390_2);
        let v390_10: Space = if map_kernels::has_head(&(v390_9)) { singleton(&[]) } else { Space::new() };
        drop(v390_9);
        let v390_12: Space = if (&(v390_10)).is_empty() { Space::new() } else {
          let v395_6: Path = concat_path(&(v389_6),&v387_15_cursor.path()[(v387_15_origin + 1)..(v387_15_origin + 2)]);
          let mut v395_11 = Space::new();
          let mut v395_11_write = v395_11.write_zipper();
          for v395_11_byte in v387_15_cursor.child_mask().iter() {
            v387_15_cursor.descend_to_existing_byte(v395_11_byte);
            {
            let v396_2: Space = singleton(&v387_15_cursor.path()[(v387_15_origin + 2)..(v387_15_origin + 3)]);
            let v396_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v396_2));
            let v396_4: Space = if map_kernels::has_head(&(v396_3)) { singleton(&[]) } else { Space::new() };
            drop(v396_3);
            let v396_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v396_4));
            drop(v396_4);
            let v396_8: Space = if (&(v396_5)).is_empty() { Space::new() } else {
              let v397_6: Path = concat_path(&(v395_6),&v387_15_cursor.path()[(v387_15_origin + 2)..(v387_15_origin + 3)]);
              let v397_7: Space = routine_38(c, &(v397_6), &v387_15_cursor);
              map_map_kernels::compose(&(v396_5),&(v397_7))
            };
            drop(v396_5);
            let v396_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v396_2));
            drop(v396_2);
            let v396_10: Space = if map_kernels::has_head(&(v396_9)) { singleton(&[]) } else { Space::new() };
            drop(v396_9);
            let v396_12: Space = if (&(v396_10)).is_empty() { Space::new() } else {
              let v398_6: Path = concat_path(&(v395_6),&v387_15_cursor.path()[(v387_15_origin + 2)..(v387_15_origin + 3)]);
              let v398_11: Space = routine_14(c, &(v398_6), &v387_15_cursor);
              drop(v398_6);
              map_map_kernels::compose(&(v396_10),&(v398_11))
            };
            drop(v396_10);
            let v396_13: Space = map_map_kernels::unite(&(v396_8),&(v396_12));
            join_wrapped_into(&mut v395_11_write,&((v396_13).read_zipper()),&[]);
            }
            v387_15_cursor.ascend(1);
          }
          drop(v395_11_write);
          drop(v395_6);
          map_map_kernels::compose(&(v390_10),&(v395_11))
        };
        drop(v390_10);
        let v390_13: Space = map_map_kernels::unite(&(v390_8),&(v390_12));
        join_wrapped_into(&mut v389_7_write,&((v390_13).read_zipper()),&[]);
        }
        v387_15_cursor.ascend(1);
      }
      drop(v389_7_write);
      map_map_kernels::compose(&(v388_5),&(v389_7))
    };
    drop(v388_5);
    let v388_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v388_2));
    drop(v388_2);
    let v388_10: Space = if map_kernels::has_head(&(v388_9)) { singleton(&[]) } else { Space::new() };
    drop(v388_9);
    let v388_12: Space = if (&(v388_10)).is_empty() { Space::new() } else {
      let v399_11: Space = view_map_kernels::subtract(&v387_15_cursor,&(*CONSTANT_5));
      map_map_kernels::compose(&(v388_10),&(v399_11))
    };
    drop(v388_10);
    let v400_6: Path = concat_path(&(*p0),&v387_15_cursor.path()[v387_15_origin..(v387_15_origin + 1)]);
    let v388_13: Space = map_kernels::wrap(&(v388_12),&(v400_6));
    drop(v388_12);
    let v388_14: Space = map_map_kernels::unite(&(v388_8),&(v388_13));
    drop(v388_13);
    join_wrapped_into(&mut v387_15_write,&((v388_14).read_zipper()),&[]);
    }
    v387_15_cursor.ascend(1);
  }
  drop(v387_15_cursor);
  drop(v387_15_write);
  (v387_15).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v401_3: Space = view_map_kernels::subtract(&(*s0),&(*CONSTANT_5));
  let v401_4: Space = map_kernels::wrap(&(v401_3),&(*p0));
  drop(v401_3);
  (v401_4).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v402_24 = Space::new();
  let mut v402_24_write = v402_24.write_zipper();
  let mut v402_24_cursor = (*s0).read_zipper();
  let v402_24_origin = v402_24_cursor.path().len();
  for v402_24_byte in v402_24_cursor.child_mask().iter() {
    v402_24_cursor.descend_to_existing_byte(v402_24_byte);
    {
    let v403_2: Space = singleton(&v402_24_cursor.path()[v402_24_origin..(v402_24_origin + 1)]);
    let v403_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v403_2));
    let v403_4: Space = if map_kernels::has_head(&(v403_3)) { singleton(&[]) } else { Space::new() };
    drop(v403_3);
    let v403_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v403_4));
    drop(v403_4);
    let v403_8: Space = if (&(v403_5)).is_empty() { Space::new() } else {
      let v404_6: Path = concat_path(&(*p0),&v402_24_cursor.path()[v402_24_origin..(v402_24_origin + 1)]);
      let mut v404_7 = Space::new();
      let mut v404_7_write = v404_7.write_zipper();
      for v404_7_byte in v402_24_cursor.child_mask().iter() {
        v402_24_cursor.descend_to_existing_byte(v404_7_byte);
        {
        let v405_2: Space = singleton(&v402_24_cursor.path()[(v402_24_origin + 1)..(v402_24_origin + 2)]);
        let v405_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v405_2));
        let v405_4: Space = if map_kernels::has_head(&(v405_3)) { singleton(&[]) } else { Space::new() };
        drop(v405_3);
        let v405_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v405_4));
        drop(v405_4);
        let v405_8: Space = if (&(v405_5)).is_empty() { Space::new() } else {
          let v406_6: Path = concat_path(&(v404_6),&v402_24_cursor.path()[(v402_24_origin + 1)..(v402_24_origin + 2)]);
          let mut v406_7 = Space::new();
          let mut v406_7_write = v406_7.write_zipper();
          for v406_7_byte in v402_24_cursor.child_mask().iter() {
            v402_24_cursor.descend_to_existing_byte(v406_7_byte);
            {
            let v407_2: Space = singleton(&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
            let v407_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v407_2));
            let v407_4: Space = if map_kernels::has_head(&(v407_3)) { singleton(&[]) } else { Space::new() };
            drop(v407_3);
            let v407_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v407_4));
            drop(v407_4);
            let v407_8: Space = if (&(v407_5)).is_empty() { Space::new() } else {
              let v408_6: Path = concat_path(&(v406_6),&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
              let v408_7: Space = routine_40(c, &(v408_6), &v402_24_cursor, &(*s1));
              map_map_kernels::compose(&(v407_5),&(v408_7))
            };
            drop(v407_5);
            let v407_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v407_2));
            drop(v407_2);
            let v407_10: Space = if map_kernels::has_head(&(v407_9)) { singleton(&[]) } else { Space::new() };
            drop(v407_9);
            let v407_12: Space = if (&(v407_10)).is_empty() { Space::new() } else {
              let v409_6: Path = concat_path(&(v406_6),&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
              let v409_11: Space = routine_41(c, &(v409_6), &v402_24_cursor, &(*s1));
              drop(v409_6);
              map_map_kernels::compose(&(v407_10),&(v409_11))
            };
            drop(v407_10);
            let v407_13: Space = map_map_kernels::unite(&(v407_8),&(v407_12));
            join_wrapped_into(&mut v406_7_write,&((v407_13).read_zipper()),&[]);
            }
            v402_24_cursor.ascend(1);
          }
          drop(v406_7_write);
          map_map_kernels::compose(&(v405_5),&(v406_7))
        };
        drop(v405_5);
        let v405_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v405_2));
        drop(v405_2);
        let v405_10: Space = if map_kernels::has_head(&(v405_9)) { singleton(&[]) } else { Space::new() };
        drop(v405_9);
        let v405_12: Space = if (&(v405_10)).is_empty() { Space::new() } else {
          let v410_6: Path = concat_path(&(v404_6),&v402_24_cursor.path()[(v402_24_origin + 1)..(v402_24_origin + 2)]);
          let mut v410_11 = Space::new();
          let mut v410_11_write = v410_11.write_zipper();
          for v410_11_byte in v402_24_cursor.child_mask().iter() {
            v402_24_cursor.descend_to_existing_byte(v410_11_byte);
            {
            let v411_2: Space = singleton(&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
            let v411_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v411_2));
            let v411_4: Space = if map_kernels::has_head(&(v411_3)) { singleton(&[]) } else { Space::new() };
            drop(v411_3);
            let v411_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v411_4));
            drop(v411_4);
            let v411_8: Space = if (&(v411_5)).is_empty() { Space::new() } else {
              let v412_6: Path = concat_path(&(v410_6),&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
              let v412_7: Space = routine_40(c, &(v412_6), &v402_24_cursor, &(*s1));
              map_map_kernels::compose(&(v411_5),&(v412_7))
            };
            drop(v411_5);
            let v411_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v411_2));
            drop(v411_2);
            let v411_10: Space = if map_kernels::has_head(&(v411_9)) { singleton(&[]) } else { Space::new() };
            drop(v411_9);
            let v411_12: Space = if (&(v411_10)).is_empty() { Space::new() } else {
              let v413_6: Path = concat_path(&(v410_6),&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
              let v413_11: Space = routine_17(c, &(v413_6), &v402_24_cursor, &(*s1));
              drop(v413_6);
              map_map_kernels::compose(&(v411_10),&(v413_11))
            };
            drop(v411_10);
            let v411_13: Space = map_map_kernels::unite(&(v411_8),&(v411_12));
            join_wrapped_into(&mut v410_11_write,&((v411_13).read_zipper()),&[]);
            }
            v402_24_cursor.ascend(1);
          }
          drop(v410_11_write);
          drop(v410_6);
          map_map_kernels::compose(&(v405_10),&(v410_11))
        };
        drop(v405_10);
        let v405_13: Space = map_map_kernels::unite(&(v405_8),&(v405_12));
        join_wrapped_into(&mut v404_7_write,&((v405_13).read_zipper()),&[]);
        }
        v402_24_cursor.ascend(1);
      }
      drop(v404_7_write);
      map_map_kernels::compose(&(v403_5),&(v404_7))
    };
    drop(v403_5);
    let v403_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v403_2));
    drop(v403_2);
    let v403_10: Space = if map_kernels::has_head(&(v403_9)) { singleton(&[]) } else { Space::new() };
    drop(v403_9);
    let v403_12: Space = if (&(v403_10)).is_empty() { Space::new() } else {
      let v414_6: Path = concat_path(&(*p0),&v402_24_cursor.path()[v402_24_origin..(v402_24_origin + 1)]);
      let mut v414_11 = Space::new();
      let mut v414_11_write = v414_11.write_zipper();
      for v414_11_byte in v402_24_cursor.child_mask().iter() {
        v402_24_cursor.descend_to_existing_byte(v414_11_byte);
        {
        let v415_2: Space = singleton(&v402_24_cursor.path()[(v402_24_origin + 1)..(v402_24_origin + 2)]);
        let v415_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v415_2));
        let v415_4: Space = if map_kernels::has_head(&(v415_3)) { singleton(&[]) } else { Space::new() };
        drop(v415_3);
        let v415_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v415_4));
        drop(v415_4);
        let v415_8: Space = if (&(v415_5)).is_empty() { Space::new() } else {
          let v416_6: Path = concat_path(&(v414_6),&v402_24_cursor.path()[(v402_24_origin + 1)..(v402_24_origin + 2)]);
          let mut v416_7 = Space::new();
          let mut v416_7_write = v416_7.write_zipper();
          for v416_7_byte in v402_24_cursor.child_mask().iter() {
            v402_24_cursor.descend_to_existing_byte(v416_7_byte);
            {
            let v417_2: Space = singleton(&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
            let v417_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v417_2));
            let v417_4: Space = if map_kernels::has_head(&(v417_3)) { singleton(&[]) } else { Space::new() };
            drop(v417_3);
            let v417_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v417_4));
            drop(v417_4);
            let v417_8: Space = if (&(v417_5)).is_empty() { Space::new() } else {
              let v418_6: Path = concat_path(&(v416_6),&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
              let v418_7: Space = routine_40(c, &(v418_6), &v402_24_cursor, &(*s1));
              map_map_kernels::compose(&(v417_5),&(v418_7))
            };
            drop(v417_5);
            let v417_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v417_2));
            drop(v417_2);
            let v417_10: Space = if map_kernels::has_head(&(v417_9)) { singleton(&[]) } else { Space::new() };
            drop(v417_9);
            let v417_12: Space = if (&(v417_10)).is_empty() { Space::new() } else {
              let v419_6: Path = concat_path(&(v416_6),&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
              let v419_11: Space = routine_41(c, &(v419_6), &v402_24_cursor, &(*s1));
              drop(v419_6);
              map_map_kernels::compose(&(v417_10),&(v419_11))
            };
            drop(v417_10);
            let v417_13: Space = map_map_kernels::unite(&(v417_8),&(v417_12));
            join_wrapped_into(&mut v416_7_write,&((v417_13).read_zipper()),&[]);
            }
            v402_24_cursor.ascend(1);
          }
          drop(v416_7_write);
          map_map_kernels::compose(&(v415_5),&(v416_7))
        };
        drop(v415_5);
        let v415_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v415_2));
        drop(v415_2);
        let v415_10: Space = if map_kernels::has_head(&(v415_9)) { singleton(&[]) } else { Space::new() };
        drop(v415_9);
        let v415_12: Space = if (&(v415_10)).is_empty() { Space::new() } else {
          let mut v420_11 = Space::new();
          let mut v420_11_write = v420_11.write_zipper();
          for v420_11_byte in v402_24_cursor.child_mask().iter() {
            v402_24_cursor.descend_to_existing_byte(v420_11_byte);
            {
            let v421_2: Space = singleton(&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
            let v421_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v421_2));
            let v421_4: Space = if map_kernels::has_head(&(v421_3)) { singleton(&[]) } else { Space::new() };
            drop(v421_3);
            let v421_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v421_4));
            drop(v421_4);
            let v421_7: Space = if (&(v421_5)).is_empty() { Space::new() } else {
              let v422_6: Space = routine_18(c, &v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)], &v402_24_cursor, &(*s1));
              map_map_kernels::compose(&(v421_5),&(v422_6))
            };
            drop(v421_5);
            let v421_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v421_2));
            drop(v421_2);
            let v421_9: Space = if map_kernels::has_head(&(v421_8)) { singleton(&[]) } else { Space::new() };
            drop(v421_8);
            let v421_11: Space = if (&(v421_9)).is_empty() { Space::new() } else {
              let v423_10: Space = routine_19(c, &v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)], &v402_24_cursor, &(*s1));
              map_map_kernels::compose(&(v421_9),&(v423_10))
            };
            drop(v421_9);
            let v421_12: Space = map_map_kernels::unite(&(v421_7),&(v421_11));
            join_wrapped_into(&mut v420_11_write,&((v421_12).read_zipper()),&[]);
            }
            v402_24_cursor.ascend(1);
          }
          drop(v420_11_write);
          map_map_kernels::compose(&(v415_10),&(v420_11))
        };
        drop(v415_10);
        let v424_6: Path = concat_path(&(v414_6),&v402_24_cursor.path()[(v402_24_origin + 1)..(v402_24_origin + 2)]);
        let v415_13: Space = map_kernels::wrap(&(v415_12),&(v424_6));
        let v415_14: Space = map_map_kernels::unite(&(v415_8),&(v415_13));
        join_wrapped_into(&mut v414_11_write,&((v415_14).read_zipper()),&[]);
        }
        v402_24_cursor.ascend(1);
      }
      drop(v414_11_write);
      drop(v414_6);
      map_map_kernels::compose(&(v403_10),&(v414_11))
    };
    drop(v403_10);
    let v403_13: Space = map_map_kernels::unite(&(v403_8),&(v403_12));
    join_wrapped_into(&mut v402_24_write,&((v403_13).read_zipper()),&[]);
    }
    v402_24_cursor.ascend(1);
  }
  drop(v402_24_cursor);
  drop(v402_24_write);
  (v402_24).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v425_24 = Space::new();
  let mut v425_24_write = v425_24.write_zipper();
  let mut v425_24_cursor = (*s0).read_zipper();
  let v425_24_origin = v425_24_cursor.path().len();
  for v425_24_byte in v425_24_cursor.child_mask().iter() {
    v425_24_cursor.descend_to_existing_byte(v425_24_byte);
    {
    let v426_2: Space = singleton(&v425_24_cursor.path()[v425_24_origin..(v425_24_origin + 1)]);
    let v426_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v426_2));
    let v426_4: Space = if map_kernels::has_head(&(v426_3)) { singleton(&[]) } else { Space::new() };
    drop(v426_3);
    let v426_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v426_4));
    drop(v426_4);
    let v426_8: Space = if (&(v426_5)).is_empty() { Space::new() } else {
      let v427_6: Path = concat_path(&(*p0),&v425_24_cursor.path()[v425_24_origin..(v425_24_origin + 1)]);
      let mut v427_7 = Space::new();
      let mut v427_7_write = v427_7.write_zipper();
      for v427_7_byte in v425_24_cursor.child_mask().iter() {
        v425_24_cursor.descend_to_existing_byte(v427_7_byte);
        {
        let v428_2: Space = singleton(&v425_24_cursor.path()[(v425_24_origin + 1)..(v425_24_origin + 2)]);
        let v428_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v428_2));
        let v428_4: Space = if map_kernels::has_head(&(v428_3)) { singleton(&[]) } else { Space::new() };
        drop(v428_3);
        let v428_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v428_4));
        drop(v428_4);
        let v428_8: Space = if (&(v428_5)).is_empty() { Space::new() } else {
          let v429_6: Path = concat_path(&(v427_6),&v425_24_cursor.path()[(v425_24_origin + 1)..(v425_24_origin + 2)]);
          let mut v429_7 = Space::new();
          let mut v429_7_write = v429_7.write_zipper();
          for v429_7_byte in v425_24_cursor.child_mask().iter() {
            v425_24_cursor.descend_to_existing_byte(v429_7_byte);
            {
            let v430_2: Space = singleton(&v425_24_cursor.path()[(v425_24_origin + 2)..(v425_24_origin + 3)]);
            let v430_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v430_2));
            let v430_4: Space = if map_kernels::has_head(&(v430_3)) { singleton(&[]) } else { Space::new() };
            drop(v430_3);
            let v430_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v430_4));
            drop(v430_4);
            let v430_8: Space = if (&(v430_5)).is_empty() { Space::new() } else {
              let v431_6: Path = concat_path(&(v429_6),&v425_24_cursor.path()[(v425_24_origin + 2)..(v425_24_origin + 3)]);
              let v431_7: Space = routine_40(c, &(v431_6), &v425_24_cursor, &(*s1));
              map_map_kernels::compose(&(v430_5),&(v431_7))
            };
            drop(v430_5);
            let v430_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v430_2));
            drop(v430_2);
            let v430_10: Space = if map_kernels::has_head(&(v430_9)) { singleton(&[]) } else { Space::new() };
            drop(v430_9);
            let v430_12: Space = if (&(v430_10)).is_empty() { Space::new() } else {
              let v432_6: Path = concat_path(&(v429_6),&v425_24_cursor.path()[(v425_24_origin + 2)..(v425_24_origin + 3)]);
              let v432_11: Space = routine_41(c, &(v432_6), &v425_24_cursor, &(*s1));
              drop(v432_6);
              map_map_kernels::compose(&(v430_10),&(v432_11))
            };
            drop(v430_10);
            let v430_13: Space = map_map_kernels::unite(&(v430_8),&(v430_12));
            join_wrapped_into(&mut v429_7_write,&((v430_13).read_zipper()),&[]);
            }
            v425_24_cursor.ascend(1);
          }
          drop(v429_7_write);
          map_map_kernels::compose(&(v428_5),&(v429_7))
        };
        drop(v428_5);
        let v428_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v428_2));
        drop(v428_2);
        let v428_10: Space = if map_kernels::has_head(&(v428_9)) { singleton(&[]) } else { Space::new() };
        drop(v428_9);
        let v428_12: Space = if (&(v428_10)).is_empty() { Space::new() } else {
          let v433_6: Path = concat_path(&(v427_6),&v425_24_cursor.path()[(v425_24_origin + 1)..(v425_24_origin + 2)]);
          let mut v433_11 = Space::new();
          let mut v433_11_write = v433_11.write_zipper();
          for v433_11_byte in v425_24_cursor.child_mask().iter() {
            v425_24_cursor.descend_to_existing_byte(v433_11_byte);
            {
            let v434_2: Space = singleton(&v425_24_cursor.path()[(v425_24_origin + 2)..(v425_24_origin + 3)]);
            let v434_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v434_2));
            let v434_4: Space = if map_kernels::has_head(&(v434_3)) { singleton(&[]) } else { Space::new() };
            drop(v434_3);
            let v434_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v434_4));
            drop(v434_4);
            let v434_8: Space = if (&(v434_5)).is_empty() { Space::new() } else {
              let v435_6: Path = concat_path(&(v433_6),&v425_24_cursor.path()[(v425_24_origin + 2)..(v425_24_origin + 3)]);
              let v435_7: Space = routine_40(c, &(v435_6), &v425_24_cursor, &(*s1));
              map_map_kernels::compose(&(v434_5),&(v435_7))
            };
            drop(v434_5);
            let v434_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v434_2));
            drop(v434_2);
            let v434_10: Space = if map_kernels::has_head(&(v434_9)) { singleton(&[]) } else { Space::new() };
            drop(v434_9);
            let v434_12: Space = if (&(v434_10)).is_empty() { Space::new() } else {
              let v436_6: Path = concat_path(&(v433_6),&v425_24_cursor.path()[(v425_24_origin + 2)..(v425_24_origin + 3)]);
              let v436_11: Space = routine_17(c, &(v436_6), &v425_24_cursor, &(*s1));
              drop(v436_6);
              map_map_kernels::compose(&(v434_10),&(v436_11))
            };
            drop(v434_10);
            let v434_13: Space = map_map_kernels::unite(&(v434_8),&(v434_12));
            join_wrapped_into(&mut v433_11_write,&((v434_13).read_zipper()),&[]);
            }
            v425_24_cursor.ascend(1);
          }
          drop(v433_11_write);
          drop(v433_6);
          map_map_kernels::compose(&(v428_10),&(v433_11))
        };
        drop(v428_10);
        let v428_13: Space = map_map_kernels::unite(&(v428_8),&(v428_12));
        join_wrapped_into(&mut v427_7_write,&((v428_13).read_zipper()),&[]);
        }
        v425_24_cursor.ascend(1);
      }
      drop(v427_7_write);
      map_map_kernels::compose(&(v426_5),&(v427_7))
    };
    drop(v426_5);
    let v426_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v426_2));
    drop(v426_2);
    let v426_10: Space = if map_kernels::has_head(&(v426_9)) { singleton(&[]) } else { Space::new() };
    drop(v426_9);
    let v426_12: Space = if (&(v426_10)).is_empty() { Space::new() } else {
      let mut v437_11 = Space::new();
      let mut v437_11_write = v437_11.write_zipper();
      for v437_11_byte in v425_24_cursor.child_mask().iter() {
        v425_24_cursor.descend_to_existing_byte(v437_11_byte);
        {
        let v438_2: Space = singleton(&v425_24_cursor.path()[(v425_24_origin + 1)..(v425_24_origin + 2)]);
        let v438_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v438_2));
        let v438_4: Space = if map_kernels::has_head(&(v438_3)) { singleton(&[]) } else { Space::new() };
        drop(v438_3);
        let v438_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v438_4));
        drop(v438_4);
        let v438_7: Space = if (&(v438_5)).is_empty() { Space::new() } else {
          let mut v439_6 = Space::new();
          let mut v439_6_write = v439_6.write_zipper();
          for v439_6_byte in v425_24_cursor.child_mask().iter() {
            v425_24_cursor.descend_to_existing_byte(v439_6_byte);
            {
            let v440_2: Space = singleton(&v425_24_cursor.path()[(v425_24_origin + 2)..(v425_24_origin + 3)]);
            let v440_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v440_2));
            let v440_4: Space = if map_kernels::has_head(&(v440_3)) { singleton(&[]) } else { Space::new() };
            drop(v440_3);
            let v440_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v440_4));
            drop(v440_4);
            let v440_8: Space = if (&(v440_5)).is_empty() { Space::new() } else {
              let v441_7: Space = routine_42(c, &v425_24_cursor.path()[(v425_24_origin + 1)..(v425_24_origin + 3)], &v425_24_cursor, &(*s1));
              map_map_kernels::compose(&(v440_5),&(v441_7))
            };
            drop(v440_5);
            let v440_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v440_2));
            drop(v440_2);
            let v440_10: Space = if map_kernels::has_head(&(v440_9)) { singleton(&[]) } else { Space::new() };
            drop(v440_9);
            let v440_12: Space = if (&(v440_10)).is_empty() { Space::new() } else {
              let v442_11: Space = routine_43(c, &v425_24_cursor.path()[(v425_24_origin + 1)..(v425_24_origin + 3)], &v425_24_cursor, &(*s1));
              map_map_kernels::compose(&(v440_10),&(v442_11))
            };
            drop(v440_10);
            let v440_13: Space = map_map_kernels::unite(&(v440_8),&(v440_12));
            join_wrapped_into(&mut v439_6_write,&((v440_13).read_zipper()),&[]);
            }
            v425_24_cursor.ascend(1);
          }
          drop(v439_6_write);
          map_map_kernels::compose(&(v438_5),&(v439_6))
        };
        drop(v438_5);
        let v438_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v438_2));
        drop(v438_2);
        let v438_9: Space = if map_kernels::has_head(&(v438_8)) { singleton(&[]) } else { Space::new() };
        drop(v438_8);
        let v438_11: Space = if (&(v438_9)).is_empty() { Space::new() } else {
          let mut v443_10 = Space::new();
          let mut v443_10_write = v443_10.write_zipper();
          for v443_10_byte in v425_24_cursor.child_mask().iter() {
            v425_24_cursor.descend_to_existing_byte(v443_10_byte);
            {
            let v444_2: Space = singleton(&v425_24_cursor.path()[(v425_24_origin + 2)..(v425_24_origin + 3)]);
            let v444_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v444_2));
            let v444_4: Space = if map_kernels::has_head(&(v444_3)) { singleton(&[]) } else { Space::new() };
            drop(v444_3);
            let v444_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v444_4));
            drop(v444_4);
            let v444_8: Space = if (&(v444_5)).is_empty() { Space::new() } else {
              let v445_7: Space = routine_42(c, &v425_24_cursor.path()[(v425_24_origin + 1)..(v425_24_origin + 3)], &v425_24_cursor, &(*s1));
              map_map_kernels::compose(&(v444_5),&(v445_7))
            };
            drop(v444_5);
            let v444_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v444_2));
            drop(v444_2);
            let v444_10: Space = if map_kernels::has_head(&(v444_9)) { singleton(&[]) } else { Space::new() };
            drop(v444_9);
            let v444_12: Space = if (&(v444_10)).is_empty() { Space::new() } else {
              let v446_11: Space = routine_44(c, &v425_24_cursor.path()[(v425_24_origin + 1)..(v425_24_origin + 3)], &v425_24_cursor, &(*s1));
              map_map_kernels::compose(&(v444_10),&(v446_11))
            };
            drop(v444_10);
            let v444_13: Space = map_map_kernels::unite(&(v444_8),&(v444_12));
            join_wrapped_into(&mut v443_10_write,&((v444_13).read_zipper()),&[]);
            }
            v425_24_cursor.ascend(1);
          }
          drop(v443_10_write);
          map_map_kernels::compose(&(v438_9),&(v443_10))
        };
        drop(v438_9);
        let v438_12: Space = map_map_kernels::unite(&(v438_7),&(v438_11));
        join_wrapped_into(&mut v437_11_write,&((v438_12).read_zipper()),&[]);
        }
        v425_24_cursor.ascend(1);
      }
      drop(v437_11_write);
      map_map_kernels::compose(&(v426_10),&(v437_11))
    };
    drop(v426_10);
    let v447_6: Path = concat_path(&(*p0),&v425_24_cursor.path()[v425_24_origin..(v425_24_origin + 1)]);
    let v426_13: Space = map_kernels::wrap(&(v426_12),&(v447_6));
    let v426_14: Space = map_map_kernels::unite(&(v426_8),&(v426_13));
    join_wrapped_into(&mut v425_24_write,&((v426_14).read_zipper()),&[]);
    }
    v425_24_cursor.ascend(1);
  }
  drop(v425_24_cursor);
  drop(v425_24_write);
  (v425_24).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v448_26 = Space::new();
  let mut v448_26_write = v448_26.write_zipper();
  let mut v448_26_cursor = (*s0).read_zipper();
  let v448_26_origin = v448_26_cursor.path().len();
  for v448_26_byte in v448_26_cursor.child_mask().iter() {
    v448_26_cursor.descend_to_existing_byte(v448_26_byte);
    {
    let v449_2: Space = singleton(&v448_26_cursor.path()[v448_26_origin..(v448_26_origin + 1)]);
    let v449_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v449_2));
    let v449_4: Space = if map_kernels::has_head(&(v449_3)) { singleton(&[]) } else { Space::new() };
    drop(v449_3);
    let v449_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v449_4));
    drop(v449_4);
    let v449_7: Space = if (&(v449_5)).is_empty() { Space::new() } else {
      let mut v450_6 = Space::new();
      let mut v450_6_write = v450_6.write_zipper();
      for v450_6_byte in v448_26_cursor.child_mask().iter() {
        v448_26_cursor.descend_to_existing_byte(v450_6_byte);
        {
        let v451_2: Space = singleton(&v448_26_cursor.path()[(v448_26_origin + 1)..(v448_26_origin + 2)]);
        let v451_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v451_2));
        let v451_4: Space = if map_kernels::has_head(&(v451_3)) { singleton(&[]) } else { Space::new() };
        drop(v451_3);
        let v451_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v451_4));
        drop(v451_4);
        let v451_8: Space = if (&(v451_5)).is_empty() { Space::new() } else {
          let mut v452_7 = Space::new();
          let mut v452_7_write = v452_7.write_zipper();
          for v452_7_byte in v448_26_cursor.child_mask().iter() {
            v448_26_cursor.descend_to_existing_byte(v452_7_byte);
            {
            let v453_2: Space = singleton(&v448_26_cursor.path()[(v448_26_origin + 2)..(v448_26_origin + 3)]);
            let v453_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v453_2));
            let v453_4: Space = if map_kernels::has_head(&(v453_3)) { singleton(&[]) } else { Space::new() };
            drop(v453_3);
            let v453_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v453_4));
            drop(v453_4);
            let v453_8: Space = if (&(v453_5)).is_empty() { Space::new() } else {
              let v454_7: Space = routine_45(c, &v448_26_cursor.path()[v448_26_origin..(v448_26_origin + 3)], &v448_26_cursor, &(*s1));
              map_map_kernels::compose(&(v453_5),&(v454_7))
            };
            drop(v453_5);
            let v453_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v453_2));
            drop(v453_2);
            let v453_10: Space = if map_kernels::has_head(&(v453_9)) { singleton(&[]) } else { Space::new() };
            drop(v453_9);
            let v453_12: Space = if (&(v453_10)).is_empty() { Space::new() } else {
              let v455_11: Space = routine_46(c, &v448_26_cursor.path()[v448_26_origin..(v448_26_origin + 3)], &v448_26_cursor, &(*s1));
              map_map_kernels::compose(&(v453_10),&(v455_11))
            };
            drop(v453_10);
            let v453_13: Space = map_map_kernels::unite(&(v453_8),&(v453_12));
            join_wrapped_into(&mut v452_7_write,&((v453_13).read_zipper()),&[]);
            }
            v448_26_cursor.ascend(1);
          }
          drop(v452_7_write);
          map_map_kernels::compose(&(v451_5),&(v452_7))
        };
        drop(v451_5);
        let v451_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v451_2));
        drop(v451_2);
        let v451_10: Space = if map_kernels::has_head(&(v451_9)) { singleton(&[]) } else { Space::new() };
        drop(v451_9);
        let v451_12: Space = if (&(v451_10)).is_empty() { Space::new() } else {
          let mut v456_11 = Space::new();
          let mut v456_11_write = v456_11.write_zipper();
          for v456_11_byte in v448_26_cursor.child_mask().iter() {
            v448_26_cursor.descend_to_existing_byte(v456_11_byte);
            {
            let v457_2: Space = singleton(&v448_26_cursor.path()[(v448_26_origin + 2)..(v448_26_origin + 3)]);
            let v457_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v457_2));
            let v457_4: Space = if map_kernels::has_head(&(v457_3)) { singleton(&[]) } else { Space::new() };
            drop(v457_3);
            let v457_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v457_4));
            drop(v457_4);
            let v457_8: Space = if (&(v457_5)).is_empty() { Space::new() } else {
              let v458_7: Space = routine_45(c, &v448_26_cursor.path()[v448_26_origin..(v448_26_origin + 3)], &v448_26_cursor, &(*s1));
              map_map_kernels::compose(&(v457_5),&(v458_7))
            };
            drop(v457_5);
            let v457_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v457_2));
            drop(v457_2);
            let v457_10: Space = if map_kernels::has_head(&(v457_9)) { singleton(&[]) } else { Space::new() };
            drop(v457_9);
            let v457_12: Space = if (&(v457_10)).is_empty() { Space::new() } else {
              let v459_11: Space = routine_44(c, &v448_26_cursor.path()[v448_26_origin..(v448_26_origin + 3)], &v448_26_cursor, &(*s1));
              map_map_kernels::compose(&(v457_10),&(v459_11))
            };
            drop(v457_10);
            let v457_13: Space = map_map_kernels::unite(&(v457_8),&(v457_12));
            join_wrapped_into(&mut v456_11_write,&((v457_13).read_zipper()),&[]);
            }
            v448_26_cursor.ascend(1);
          }
          drop(v456_11_write);
          map_map_kernels::compose(&(v451_10),&(v456_11))
        };
        drop(v451_10);
        let v451_13: Space = map_map_kernels::unite(&(v451_8),&(v451_12));
        join_wrapped_into(&mut v450_6_write,&((v451_13).read_zipper()),&[]);
        }
        v448_26_cursor.ascend(1);
      }
      drop(v450_6_write);
      map_map_kernels::compose(&(v449_5),&(v450_6))
    };
    drop(v449_5);
    let v449_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v449_2));
    drop(v449_2);
    let v449_9: Space = if map_kernels::has_head(&(v449_8)) { singleton(&[]) } else { Space::new() };
    drop(v449_8);
    let v449_12: Space = if (&(v449_9)).is_empty() { Space::new() } else {
      let mut v460_11 = Space::new();
      let mut v460_11_write = v460_11.write_zipper();
      for v460_11_byte in v448_26_cursor.child_mask().iter() {
        v448_26_cursor.descend_to_existing_byte(v460_11_byte);
        {
        let v461_2: Space = singleton(&v448_26_cursor.path()[(v448_26_origin + 1)..(v448_26_origin + 2)]);
        let v461_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v461_2));
        let v461_4: Space = if map_kernels::has_head(&(v461_3)) { singleton(&[]) } else { Space::new() };
        drop(v461_3);
        let v461_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v461_4));
        drop(v461_4);
        let v461_8: Space = if (&(v461_5)).is_empty() { Space::new() } else {
          let mut v462_7 = Space::new();
          let mut v462_7_write = v462_7.write_zipper();
          for v462_7_byte in v448_26_cursor.child_mask().iter() {
            v448_26_cursor.descend_to_existing_byte(v462_7_byte);
            {
            let v463_2: Space = singleton(&v448_26_cursor.path()[(v448_26_origin + 2)..(v448_26_origin + 3)]);
            let v463_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v463_2));
            let v463_4: Space = if map_kernels::has_head(&(v463_3)) { singleton(&[]) } else { Space::new() };
            drop(v463_3);
            let v463_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v463_4));
            drop(v463_4);
            let v463_8: Space = if (&(v463_5)).is_empty() { Space::new() } else {
              let v464_7: Space = routine_45(c, &v448_26_cursor.path()[v448_26_origin..(v448_26_origin + 3)], &v448_26_cursor, &(*s1));
              map_map_kernels::compose(&(v463_5),&(v464_7))
            };
            drop(v463_5);
            let v463_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v463_2));
            drop(v463_2);
            let v463_10: Space = if map_kernels::has_head(&(v463_9)) { singleton(&[]) } else { Space::new() };
            drop(v463_9);
            let v463_12: Space = if (&(v463_10)).is_empty() { Space::new() } else {
              let v465_11: Space = routine_46(c, &v448_26_cursor.path()[v448_26_origin..(v448_26_origin + 3)], &v448_26_cursor, &(*s1));
              map_map_kernels::compose(&(v463_10),&(v465_11))
            };
            drop(v463_10);
            let v463_13: Space = map_map_kernels::unite(&(v463_8),&(v463_12));
            join_wrapped_into(&mut v462_7_write,&((v463_13).read_zipper()),&[]);
            }
            v448_26_cursor.ascend(1);
          }
          drop(v462_7_write);
          map_map_kernels::compose(&(v461_5),&(v462_7))
        };
        drop(v461_5);
        let v461_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v461_2));
        drop(v461_2);
        let v461_10: Space = if map_kernels::has_head(&(v461_9)) { singleton(&[]) } else { Space::new() };
        drop(v461_9);
        let v461_13: Space = if (&(v461_10)).is_empty() { Space::new() } else {
          let v466_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&v448_26_cursor.path()[v448_26_origin..(v448_26_origin + 1)]),&v448_26_cursor.path()[(v448_26_origin + 1)..(v448_26_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v461_10),&(v466_12))
        };
        drop(v461_10);
        let v461_14: Space = map_map_kernels::unite(&(v461_8),&(v461_13));
        drop(v461_13);
        join_wrapped_into(&mut v460_11_write,&((v461_14).read_zipper()),&[]);
        }
        v448_26_cursor.ascend(1);
      }
      drop(v460_11_write);
      map_map_kernels::compose(&(v449_9),&(v460_11))
    };
    drop(v449_9);
    let v449_13: Space = map_map_kernels::unite(&(v449_7),&(v449_12));
    join_wrapped_into(&mut v448_26_write,&((v449_13).read_zipper()),&[]);
    }
    v448_26_cursor.ascend(1);
  }
  drop(v448_26_cursor);
  drop(v448_26_write);
  let v448_27: Space = map_kernels::wrap(&(v448_26),&(*p0));
  (v448_27).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v467_27 = Space::new();
  let mut v467_27_write = v467_27.write_zipper();
  let mut v467_27_cursor = (*s0).read_zipper();
  let v467_27_origin = v467_27_cursor.path().len();
  for v467_27_byte in v467_27_cursor.child_mask().iter() {
    v467_27_cursor.descend_to_existing_byte(v467_27_byte);
    {
    let v468_2: Space = singleton(&v467_27_cursor.path()[v467_27_origin..(v467_27_origin + 1)]);
    let v468_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v468_2));
    let v468_4: Space = if map_kernels::has_head(&(v468_3)) { singleton(&[]) } else { Space::new() };
    drop(v468_3);
    let v468_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v468_4));
    drop(v468_4);
    let v468_8: Space = if (&(v468_5)).is_empty() { Space::new() } else {
      let v469_6: Path = concat_path(&(*p0),&v467_27_cursor.path()[v467_27_origin..(v467_27_origin + 1)]);
      let mut v469_7 = Space::new();
      let mut v469_7_write = v469_7.write_zipper();
      for v469_7_byte in v467_27_cursor.child_mask().iter() {
        v467_27_cursor.descend_to_existing_byte(v469_7_byte);
        {
        let v470_2: Space = singleton(&v467_27_cursor.path()[(v467_27_origin + 1)..(v467_27_origin + 2)]);
        let v470_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v470_2));
        let v470_4: Space = if map_kernels::has_head(&(v470_3)) { singleton(&[]) } else { Space::new() };
        drop(v470_3);
        let v470_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v470_4));
        drop(v470_4);
        let v470_8: Space = if (&(v470_5)).is_empty() { Space::new() } else {
          let v471_6: Path = concat_path(&(v469_6),&v467_27_cursor.path()[(v467_27_origin + 1)..(v467_27_origin + 2)]);
          let mut v471_7 = Space::new();
          let mut v471_7_write = v471_7.write_zipper();
          for v471_7_byte in v467_27_cursor.child_mask().iter() {
            v467_27_cursor.descend_to_existing_byte(v471_7_byte);
            {
            let v472_2: Space = singleton(&v467_27_cursor.path()[(v467_27_origin + 2)..(v467_27_origin + 3)]);
            let v472_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v472_2));
            let v472_4: Space = if map_kernels::has_head(&(v472_3)) { singleton(&[]) } else { Space::new() };
            drop(v472_3);
            let v472_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v472_4));
            drop(v472_4);
            let v472_8: Space = if (&(v472_5)).is_empty() { Space::new() } else {
              let v473_6: Path = concat_path(&(v471_6),&v467_27_cursor.path()[(v467_27_origin + 2)..(v467_27_origin + 3)]);
              let v473_7: Space = routine_47(c, &(v473_6), &v467_27_cursor, &(*s1));
              map_map_kernels::compose(&(v472_5),&(v473_7))
            };
            drop(v472_5);
            let v472_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v472_2));
            drop(v472_2);
            let v472_10: Space = if map_kernels::has_head(&(v472_9)) { singleton(&[]) } else { Space::new() };
            drop(v472_9);
            let v472_12: Space = if (&(v472_10)).is_empty() { Space::new() } else {
              let v474_6: Path = concat_path(&(v471_6),&v467_27_cursor.path()[(v467_27_origin + 2)..(v467_27_origin + 3)]);
              let v474_11: Space = routine_48(c, &(v474_6), &v467_27_cursor, &(*s1));
              drop(v474_6);
              map_map_kernels::compose(&(v472_10),&(v474_11))
            };
            drop(v472_10);
            let v472_13: Space = map_map_kernels::unite(&(v472_8),&(v472_12));
            join_wrapped_into(&mut v471_7_write,&((v472_13).read_zipper()),&[]);
            }
            v467_27_cursor.ascend(1);
          }
          drop(v471_7_write);
          map_map_kernels::compose(&(v470_5),&(v471_7))
        };
        drop(v470_5);
        let v470_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v470_2));
        drop(v470_2);
        let v470_10: Space = if map_kernels::has_head(&(v470_9)) { singleton(&[]) } else { Space::new() };
        drop(v470_9);
        let v470_12: Space = if (&(v470_10)).is_empty() { Space::new() } else {
          let v475_6: Path = concat_path(&(v469_6),&v467_27_cursor.path()[(v467_27_origin + 1)..(v467_27_origin + 2)]);
          let mut v475_11 = Space::new();
          let mut v475_11_write = v475_11.write_zipper();
          for v475_11_byte in v467_27_cursor.child_mask().iter() {
            v467_27_cursor.descend_to_existing_byte(v475_11_byte);
            {
            let v476_2: Space = singleton(&v467_27_cursor.path()[(v467_27_origin + 2)..(v467_27_origin + 3)]);
            let v476_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v476_2));
            let v476_4: Space = if map_kernels::has_head(&(v476_3)) { singleton(&[]) } else { Space::new() };
            drop(v476_3);
            let v476_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v476_4));
            drop(v476_4);
            let v476_8: Space = if (&(v476_5)).is_empty() { Space::new() } else {
              let v477_6: Path = concat_path(&(v475_6),&v467_27_cursor.path()[(v467_27_origin + 2)..(v467_27_origin + 3)]);
              let v477_7: Space = routine_47(c, &(v477_6), &v467_27_cursor, &(*s1));
              map_map_kernels::compose(&(v476_5),&(v477_7))
            };
            drop(v476_5);
            let v476_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v476_2));
            drop(v476_2);
            let v476_10: Space = if map_kernels::has_head(&(v476_9)) { singleton(&[]) } else { Space::new() };
            drop(v476_9);
            let v476_12: Space = if (&(v476_10)).is_empty() { Space::new() } else {
              let v478_6: Path = concat_path(&(v475_6),&v467_27_cursor.path()[(v467_27_origin + 2)..(v467_27_origin + 3)]);
              let v478_11: Space = routine_44(c, &(v478_6), &v467_27_cursor, &(*s1));
              drop(v478_6);
              map_map_kernels::compose(&(v476_10),&(v478_11))
            };
            drop(v476_10);
            let v476_13: Space = map_map_kernels::unite(&(v476_8),&(v476_12));
            join_wrapped_into(&mut v475_11_write,&((v476_13).read_zipper()),&[]);
            }
            v467_27_cursor.ascend(1);
          }
          drop(v475_11_write);
          drop(v475_6);
          map_map_kernels::compose(&(v470_10),&(v475_11))
        };
        drop(v470_10);
        let v470_13: Space = map_map_kernels::unite(&(v470_8),&(v470_12));
        join_wrapped_into(&mut v469_7_write,&((v470_13).read_zipper()),&[]);
        }
        v467_27_cursor.ascend(1);
      }
      drop(v469_7_write);
      map_map_kernels::compose(&(v468_5),&(v469_7))
    };
    drop(v468_5);
    let v468_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v468_2));
    drop(v468_2);
    let v468_10: Space = if map_kernels::has_head(&(v468_9)) { singleton(&[]) } else { Space::new() };
    drop(v468_9);
    let v468_13: Space = if (&(v468_10)).is_empty() { Space::new() } else {
      let v479_6: Path = concat_path(&(*p0),&v467_27_cursor.path()[v467_27_origin..(v467_27_origin + 1)]);
      let mut v479_12 = Space::new();
      let mut v479_12_write = v479_12.write_zipper();
      for v479_12_byte in v467_27_cursor.child_mask().iter() {
        v467_27_cursor.descend_to_existing_byte(v479_12_byte);
        {
        let v480_2: Space = singleton(&v467_27_cursor.path()[(v467_27_origin + 1)..(v467_27_origin + 2)]);
        let v480_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v480_2));
        let v480_4: Space = if map_kernels::has_head(&(v480_3)) { singleton(&[]) } else { Space::new() };
        drop(v480_3);
        let v480_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v480_4));
        drop(v480_4);
        let v480_8: Space = if (&(v480_5)).is_empty() { Space::new() } else {
          let v481_6: Path = concat_path(&(v479_6),&v467_27_cursor.path()[(v467_27_origin + 1)..(v467_27_origin + 2)]);
          let mut v481_7 = Space::new();
          let mut v481_7_write = v481_7.write_zipper();
          for v481_7_byte in v467_27_cursor.child_mask().iter() {
            v467_27_cursor.descend_to_existing_byte(v481_7_byte);
            {
            let v482_2: Space = singleton(&v467_27_cursor.path()[(v467_27_origin + 2)..(v467_27_origin + 3)]);
            let v482_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v482_2));
            let v482_4: Space = if map_kernels::has_head(&(v482_3)) { singleton(&[]) } else { Space::new() };
            drop(v482_3);
            let v482_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v482_4));
            drop(v482_4);
            let v482_8: Space = if (&(v482_5)).is_empty() { Space::new() } else {
              let v483_6: Path = concat_path(&(v481_6),&v467_27_cursor.path()[(v467_27_origin + 2)..(v467_27_origin + 3)]);
              let v483_7: Space = routine_47(c, &(v483_6), &v467_27_cursor, &(*s1));
              map_map_kernels::compose(&(v482_5),&(v483_7))
            };
            drop(v482_5);
            let v482_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v482_2));
            drop(v482_2);
            let v482_10: Space = if map_kernels::has_head(&(v482_9)) { singleton(&[]) } else { Space::new() };
            drop(v482_9);
            let v482_12: Space = if (&(v482_10)).is_empty() { Space::new() } else {
              let v484_6: Path = concat_path(&(v481_6),&v467_27_cursor.path()[(v467_27_origin + 2)..(v467_27_origin + 3)]);
              let v484_11: Space = routine_48(c, &(v484_6), &v467_27_cursor, &(*s1));
              drop(v484_6);
              map_map_kernels::compose(&(v482_10),&(v484_11))
            };
            drop(v482_10);
            let v482_13: Space = map_map_kernels::unite(&(v482_8),&(v482_12));
            join_wrapped_into(&mut v481_7_write,&((v482_13).read_zipper()),&[]);
            }
            v467_27_cursor.ascend(1);
          }
          drop(v481_7_write);
          drop(v481_6);
          map_map_kernels::compose(&(v480_5),&(v481_7))
        };
        drop(v480_5);
        let v480_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v480_2));
        drop(v480_2);
        let v480_10: Space = if map_kernels::has_head(&(v480_9)) { singleton(&[]) } else { Space::new() };
        drop(v480_9);
        let v480_13: Space = if (&(v480_10)).is_empty() { Space::new() } else {
          let v485_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v467_27_cursor.path()[v467_27_origin..(v467_27_origin + 1)]),&v467_27_cursor.path()[(v467_27_origin + 1)..(v467_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v480_10),&(v485_12))
        };
        drop(v480_10);
        let v480_14: Space = map_map_kernels::unite(&(v480_8),&(v480_13));
        drop(v480_13);
        join_wrapped_into(&mut v479_12_write,&((v480_14).read_zipper()),&[]);
        }
        v467_27_cursor.ascend(1);
      }
      drop(v479_12_write);
      drop(v479_6);
      map_map_kernels::compose(&(v468_10),&(v479_12))
    };
    drop(v468_10);
    let v468_14: Space = map_map_kernels::unite(&(v468_8),&(v468_13));
    join_wrapped_into(&mut v467_27_write,&((v468_14).read_zipper()),&[]);
    }
    v467_27_cursor.ascend(1);
  }
  drop(v467_27_cursor);
  drop(v467_27_write);
  (v467_27).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v486_21 = Space::new();
  let mut v486_21_write = v486_21.write_zipper();
  let mut v486_21_cursor = (*s0).read_zipper();
  let v486_21_origin = v486_21_cursor.path().len();
  for v486_21_byte in v486_21_cursor.child_mask().iter() {
    v486_21_cursor.descend_to_existing_byte(v486_21_byte);
    {
    let v487_2: Space = singleton(&v486_21_cursor.path()[v486_21_origin..(v486_21_origin + 1)]);
    let v487_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v487_2));
    let v487_4: Space = if map_kernels::has_head(&(v487_3)) { singleton(&[]) } else { Space::new() };
    drop(v487_3);
    let v487_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v487_4));
    drop(v487_4);
    let v487_8: Space = if (&(v487_5)).is_empty() { Space::new() } else {
      let v488_6: Path = concat_path(&(*p0),&v486_21_cursor.path()[v486_21_origin..(v486_21_origin + 1)]);
      let mut v488_7 = Space::new();
      let mut v488_7_write = v488_7.write_zipper();
      for v488_7_byte in v486_21_cursor.child_mask().iter() {
        v486_21_cursor.descend_to_existing_byte(v488_7_byte);
        {
        let v489_2: Space = singleton(&v486_21_cursor.path()[(v486_21_origin + 1)..(v486_21_origin + 2)]);
        let v489_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v489_2));
        let v489_4: Space = if map_kernels::has_head(&(v489_3)) { singleton(&[]) } else { Space::new() };
        drop(v489_3);
        let v489_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v489_4));
        drop(v489_4);
        let v489_8: Space = if (&(v489_5)).is_empty() { Space::new() } else {
          let v490_6: Path = concat_path(&(v488_6),&v486_21_cursor.path()[(v486_21_origin + 1)..(v486_21_origin + 2)]);
          let mut v490_7 = Space::new();
          let mut v490_7_write = v490_7.write_zipper();
          for v490_7_byte in v486_21_cursor.child_mask().iter() {
            v486_21_cursor.descend_to_existing_byte(v490_7_byte);
            {
            let v491_2: Space = singleton(&v486_21_cursor.path()[(v486_21_origin + 2)..(v486_21_origin + 3)]);
            let v491_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v491_2));
            let v491_4: Space = if map_kernels::has_head(&(v491_3)) { singleton(&[]) } else { Space::new() };
            drop(v491_3);
            let v491_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v491_4));
            drop(v491_4);
            let v491_8: Space = if (&(v491_5)).is_empty() { Space::new() } else {
              let v492_6: Path = concat_path(&(v490_6),&v486_21_cursor.path()[(v486_21_origin + 2)..(v486_21_origin + 3)]);
              let v492_7: Space = routine_47(c, &(v492_6), &v486_21_cursor, &(*s1));
              map_map_kernels::compose(&(v491_5),&(v492_7))
            };
            drop(v491_5);
            let v491_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v491_2));
            drop(v491_2);
            let v491_10: Space = if map_kernels::has_head(&(v491_9)) { singleton(&[]) } else { Space::new() };
            drop(v491_9);
            let v491_12: Space = if (&(v491_10)).is_empty() { Space::new() } else {
              let v493_6: Path = concat_path(&(v490_6),&v486_21_cursor.path()[(v486_21_origin + 2)..(v486_21_origin + 3)]);
              let v493_11: Space = routine_48(c, &(v493_6), &v486_21_cursor, &(*s1));
              drop(v493_6);
              map_map_kernels::compose(&(v491_10),&(v493_11))
            };
            drop(v491_10);
            let v491_13: Space = map_map_kernels::unite(&(v491_8),&(v491_12));
            join_wrapped_into(&mut v490_7_write,&((v491_13).read_zipper()),&[]);
            }
            v486_21_cursor.ascend(1);
          }
          drop(v490_7_write);
          map_map_kernels::compose(&(v489_5),&(v490_7))
        };
        drop(v489_5);
        let v489_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v489_2));
        drop(v489_2);
        let v489_10: Space = if map_kernels::has_head(&(v489_9)) { singleton(&[]) } else { Space::new() };
        drop(v489_9);
        let v489_12: Space = if (&(v489_10)).is_empty() { Space::new() } else {
          let v494_6: Path = concat_path(&(v488_6),&v486_21_cursor.path()[(v486_21_origin + 1)..(v486_21_origin + 2)]);
          let mut v494_11 = Space::new();
          let mut v494_11_write = v494_11.write_zipper();
          for v494_11_byte in v486_21_cursor.child_mask().iter() {
            v486_21_cursor.descend_to_existing_byte(v494_11_byte);
            {
            let v495_2: Space = singleton(&v486_21_cursor.path()[(v486_21_origin + 2)..(v486_21_origin + 3)]);
            let v495_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v495_2));
            let v495_4: Space = if map_kernels::has_head(&(v495_3)) { singleton(&[]) } else { Space::new() };
            drop(v495_3);
            let v495_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v495_4));
            drop(v495_4);
            let v495_8: Space = if (&(v495_5)).is_empty() { Space::new() } else {
              let v496_6: Path = concat_path(&(v494_6),&v486_21_cursor.path()[(v486_21_origin + 2)..(v486_21_origin + 3)]);
              let v496_7: Space = routine_47(c, &(v496_6), &v486_21_cursor, &(*s1));
              map_map_kernels::compose(&(v495_5),&(v496_7))
            };
            drop(v495_5);
            let v495_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v495_2));
            drop(v495_2);
            let v495_10: Space = if map_kernels::has_head(&(v495_9)) { singleton(&[]) } else { Space::new() };
            drop(v495_9);
            let v495_12: Space = if (&(v495_10)).is_empty() { Space::new() } else {
              let v497_6: Path = concat_path(&(v494_6),&v486_21_cursor.path()[(v486_21_origin + 2)..(v486_21_origin + 3)]);
              let v497_11: Space = routine_44(c, &(v497_6), &v486_21_cursor, &(*s1));
              drop(v497_6);
              map_map_kernels::compose(&(v495_10),&(v497_11))
            };
            drop(v495_10);
            let v495_13: Space = map_map_kernels::unite(&(v495_8),&(v495_12));
            join_wrapped_into(&mut v494_11_write,&((v495_13).read_zipper()),&[]);
            }
            v486_21_cursor.ascend(1);
          }
          drop(v494_11_write);
          drop(v494_6);
          map_map_kernels::compose(&(v489_10),&(v494_11))
        };
        drop(v489_10);
        let v489_13: Space = map_map_kernels::unite(&(v489_8),&(v489_12));
        join_wrapped_into(&mut v488_7_write,&((v489_13).read_zipper()),&[]);
        }
        v486_21_cursor.ascend(1);
      }
      drop(v488_7_write);
      drop(v488_6);
      map_map_kernels::compose(&(v487_5),&(v488_7))
    };
    drop(v487_5);
    let v487_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v487_2));
    drop(v487_2);
    let v487_10: Space = if map_kernels::has_head(&(v487_9)) { singleton(&[]) } else { Space::new() };
    drop(v487_9);
    let v487_13: Space = if (&(v487_10)).is_empty() { Space::new() } else {
      let v498_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v486_21_cursor.path()[v486_21_origin..(v486_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v487_10),&(v498_12))
    };
    drop(v487_10);
    let v487_14: Space = map_map_kernels::unite(&(v487_8),&(v487_13));
    drop(v487_13);
    join_wrapped_into(&mut v486_21_write,&((v487_14).read_zipper()),&[]);
    }
    v486_21_cursor.ascend(1);
  }
  drop(v486_21_cursor);
  drop(v486_21_write);
  (v486_21).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v499_10 = Space::new();
  let mut v499_10_write = v499_10.write_zipper();
  let mut v499_10_cursor = (*s0).read_zipper();
  let v499_10_origin = v499_10_cursor.path().len();
  for v499_10_byte in v499_10_cursor.child_mask().iter() {
    v499_10_cursor.descend_to_existing_byte(v499_10_byte);
    {
    let v500_2: Space = singleton(&v499_10_cursor.path()[v499_10_origin..(v499_10_origin + 1)]);
    let v500_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v500_2));
    let v500_4: Space = if map_kernels::has_head(&(v500_3)) { singleton(&[]) } else { Space::new() };
    drop(v500_3);
    let v500_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v500_4));
    drop(v500_4);
    let v500_7: Space = if (&(v500_5)).is_empty() { Space::new() } else {
      let mut v501_6 = Space::new();
      let mut v501_6_write = v501_6.write_zipper();
      for v501_6_byte in v499_10_cursor.child_mask().iter() {
        v499_10_cursor.descend_to_existing_byte(v501_6_byte);
        {
        let v502_2: Space = Space::new();
        join_wrapped_into(&mut v501_6_write,&((v502_2).read_zipper()),&[]);
        }
        v499_10_cursor.ascend(1);
      }
      drop(v501_6_write);
      map_map_kernels::compose(&(v500_5),&(v501_6))
    };
    drop(v500_5);
    let v500_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v500_2));
    drop(v500_2);
    let v500_9: Space = if map_kernels::has_head(&(v500_8)) { singleton(&[]) } else { Space::new() };
    drop(v500_8);
    let v500_12: Space = if (&(v500_9)).is_empty() { Space::new() } else {
      let v503_10: Path = concat_path(&(*p0),&v499_10_cursor.path()[v499_10_origin..(v499_10_origin + 1)]);
      let mut v503_11 = Space::new();
      let mut v503_11_write = v503_11.write_zipper();
      for v503_11_byte in v499_10_cursor.child_mask().iter() {
        v499_10_cursor.descend_to_existing_byte(v503_11_byte);
        {
        let v504_2: Space = singleton(&v499_10_cursor.path()[(v499_10_origin + 1)..(v499_10_origin + 2)]);
        let v504_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v504_2));
        drop(v504_2);
        let v504_4: Space = if map_kernels::has_head(&(v504_3)) { singleton(&[]) } else { Space::new() };
        drop(v504_3);
        let v504_6: Space = if (&(v504_4)).is_empty() { Space::new() } else {
          let mut v505_5 = Space::new();
          let mut v505_5_write = v505_5.write_zipper();
          for v505_5_byte in v499_10_cursor.child_mask().iter() {
            v499_10_cursor.descend_to_existing_byte(v505_5_byte);
            {
            let v506_2: Space = singleton(&v499_10_cursor.path()[(v499_10_origin + 2)..(v499_10_origin + 3)]);
            let v506_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v506_2));
            let v506_4: Space = if map_kernels::has_head(&(v506_3)) { singleton(&[]) } else { Space::new() };
            drop(v506_3);
            let v506_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v506_4));
            drop(v506_4);
            let v506_7: Space = if (&(v506_5)).is_empty() { Space::new() } else {
              let v507_6: Space = routine_5(c, &v499_10_cursor.path()[(v499_10_origin + 2)..(v499_10_origin + 3)], &v499_10_cursor, &(*s1));
              map_map_kernels::compose(&(v506_5),&(v507_6))
            };
            drop(v506_5);
            let v506_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v506_2));
            drop(v506_2);
            let v506_9: Space = if map_kernels::has_head(&(v506_8)) { singleton(&[]) } else { Space::new() };
            drop(v506_8);
            let v506_11: Space = if (&(v506_9)).is_empty() { Space::new() } else {
              let v508_10: Space = routine_6(c, &v499_10_cursor.path()[(v499_10_origin + 2)..(v499_10_origin + 3)], &v499_10_cursor, &(*s1));
              map_map_kernels::compose(&(v506_9),&(v508_10))
            };
            drop(v506_9);
            let v506_12: Space = map_map_kernels::unite(&(v506_7),&(v506_11));
            join_wrapped_into(&mut v505_5_write,&((v506_12).read_zipper()),&[]);
            }
            v499_10_cursor.ascend(1);
          }
          drop(v505_5_write);
          map_map_kernels::compose(&(v504_4),&(v505_5))
        };
        drop(v504_4);
        let v504_7: Path = concat_path(&(v503_10),&v499_10_cursor.path()[(v499_10_origin + 1)..(v499_10_origin + 2)]);
        join_wrapped_into(&mut v503_11_write,&((v504_6).read_zipper()),&(v504_7));
        drop(v504_7);
        }
        v499_10_cursor.ascend(1);
      }
      drop(v503_11_write);
      drop(v503_10);
      map_map_kernels::compose(&(v500_9),&(v503_11))
    };
    drop(v500_9);
    let v500_13: Space = map_map_kernels::unite(&(v500_7),&(v500_12));
    drop(v500_7);
    join_wrapped_into(&mut v499_10_write,&((v500_13).read_zipper()),&[]);
    }
    v499_10_cursor.ascend(1);
  }
  drop(v499_10_cursor);
  drop(v499_10_write);
  (v499_10).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v509_15 = Space::new();
  let mut v509_15_write = v509_15.write_zipper();
  let mut v509_15_cursor = (*s0).read_zipper();
  let v509_15_origin = v509_15_cursor.path().len();
  for v509_15_byte in v509_15_cursor.child_mask().iter() {
    v509_15_cursor.descend_to_existing_byte(v509_15_byte);
    {
    let v510_2: Space = singleton(&v509_15_cursor.path()[v509_15_origin..(v509_15_origin + 1)]);
    let v510_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v510_2));
    let v510_4: Space = if map_kernels::has_head(&(v510_3)) { singleton(&[]) } else { Space::new() };
    drop(v510_3);
    let v510_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v510_4));
    drop(v510_4);
    let v510_7: Space = if (&(v510_5)).is_empty() { Space::new() } else {
      let mut v511_6 = Space::new();
      let mut v511_6_write = v511_6.write_zipper();
      for v511_6_byte in v509_15_cursor.child_mask().iter() {
        v509_15_cursor.descend_to_existing_byte(v511_6_byte);
        {
        let v512_2: Space = Space::new();
        join_wrapped_into(&mut v511_6_write,&((v512_2).read_zipper()),&[]);
        }
        v509_15_cursor.ascend(1);
      }
      drop(v511_6_write);
      map_map_kernels::compose(&(v510_5),&(v511_6))
    };
    drop(v510_5);
    let v510_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v510_2));
    drop(v510_2);
    let v510_9: Space = if map_kernels::has_head(&(v510_8)) { singleton(&[]) } else { Space::new() };
    drop(v510_8);
    let v510_11: Space = if (&(v510_9)).is_empty() { Space::new() } else {
      let mut v513_10 = Space::new();
      let mut v513_10_write = v513_10.write_zipper();
      for v513_10_byte in v509_15_cursor.child_mask().iter() {
        v509_15_cursor.descend_to_existing_byte(v513_10_byte);
        {
        let v514_2: Space = singleton(&v509_15_cursor.path()[(v509_15_origin + 1)..(v509_15_origin + 2)]);
        let v514_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v514_2));
        let v514_4: Space = if map_kernels::has_head(&(v514_3)) { singleton(&[]) } else { Space::new() };
        drop(v514_3);
        let v514_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v514_4));
        drop(v514_4);
        let v514_7: Space = if (&(v514_5)).is_empty() { Space::new() } else {
          let mut v515_6 = Space::new();
          let mut v515_6_write = v515_6.write_zipper();
          for v515_6_byte in v509_15_cursor.child_mask().iter() {
            v509_15_cursor.descend_to_existing_byte(v515_6_byte);
            {
            let v516_2: Space = singleton(&v509_15_cursor.path()[(v509_15_origin + 2)..(v509_15_origin + 3)]);
            let v516_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v516_2));
            let v516_4: Space = if map_kernels::has_head(&(v516_3)) { singleton(&[]) } else { Space::new() };
            drop(v516_3);
            let v516_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v516_4));
            drop(v516_4);
            let v516_8: Space = if (&(v516_5)).is_empty() { Space::new() } else {
              let v517_7: Space = routine_22(c, &v509_15_cursor.path()[(v509_15_origin + 1)..(v509_15_origin + 3)], &v509_15_cursor, &(*s1));
              map_map_kernels::compose(&(v516_5),&(v517_7))
            };
            drop(v516_5);
            let v516_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v516_2));
            drop(v516_2);
            let v516_10: Space = if map_kernels::has_head(&(v516_9)) { singleton(&[]) } else { Space::new() };
            drop(v516_9);
            let v516_12: Space = if (&(v516_10)).is_empty() { Space::new() } else {
              let v518_11: Space = routine_23(c, &v509_15_cursor.path()[(v509_15_origin + 1)..(v509_15_origin + 3)], &v509_15_cursor, &(*s1));
              map_map_kernels::compose(&(v516_10),&(v518_11))
            };
            drop(v516_10);
            let v516_13: Space = map_map_kernels::unite(&(v516_8),&(v516_12));
            join_wrapped_into(&mut v515_6_write,&((v516_13).read_zipper()),&[]);
            }
            v509_15_cursor.ascend(1);
          }
          drop(v515_6_write);
          map_map_kernels::compose(&(v514_5),&(v515_6))
        };
        drop(v514_5);
        let v514_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v514_2));
        drop(v514_2);
        let v514_9: Space = if map_kernels::has_head(&(v514_8)) { singleton(&[]) } else { Space::new() };
        drop(v514_8);
        let v514_11: Space = if (&(v514_9)).is_empty() { Space::new() } else {
          let mut v519_10 = Space::new();
          let mut v519_10_write = v519_10.write_zipper();
          for v519_10_byte in v509_15_cursor.child_mask().iter() {
            v509_15_cursor.descend_to_existing_byte(v519_10_byte);
            {
            let v520_2: Space = singleton(&v509_15_cursor.path()[(v509_15_origin + 2)..(v509_15_origin + 3)]);
            let v520_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v520_2));
            let v520_4: Space = if map_kernels::has_head(&(v520_3)) { singleton(&[]) } else { Space::new() };
            drop(v520_3);
            let v520_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v520_4));
            drop(v520_4);
            let v520_8: Space = if (&(v520_5)).is_empty() { Space::new() } else {
              let v521_7: Space = routine_22(c, &v509_15_cursor.path()[(v509_15_origin + 1)..(v509_15_origin + 3)], &v509_15_cursor, &(*s1));
              map_map_kernels::compose(&(v520_5),&(v521_7))
            };
            drop(v520_5);
            let v520_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v520_2));
            drop(v520_2);
            let v520_10: Space = if map_kernels::has_head(&(v520_9)) { singleton(&[]) } else { Space::new() };
            drop(v520_9);
            let v520_12: Space = if (&(v520_10)).is_empty() { Space::new() } else {
              let v522_11: Space = routine_24(c, &v509_15_cursor.path()[(v509_15_origin + 1)..(v509_15_origin + 3)], &v509_15_cursor, &(*s1));
              map_map_kernels::compose(&(v520_10),&(v522_11))
            };
            drop(v520_10);
            let v520_13: Space = map_map_kernels::unite(&(v520_8),&(v520_12));
            join_wrapped_into(&mut v519_10_write,&((v520_13).read_zipper()),&[]);
            }
            v509_15_cursor.ascend(1);
          }
          drop(v519_10_write);
          map_map_kernels::compose(&(v514_9),&(v519_10))
        };
        drop(v514_9);
        let v514_12: Space = map_map_kernels::unite(&(v514_7),&(v514_11));
        join_wrapped_into(&mut v513_10_write,&((v514_12).read_zipper()),&[]);
        }
        v509_15_cursor.ascend(1);
      }
      drop(v513_10_write);
      map_map_kernels::compose(&(v510_9),&(v513_10))
    };
    drop(v510_9);
    let v510_12: Path = concat_path(&(*p0),&v509_15_cursor.path()[v509_15_origin..(v509_15_origin + 1)]);
    let v510_13: Space = map_kernels::wrap(&(v510_11),&(v510_12));
    drop(v510_12);
    let v510_14: Space = map_map_kernels::unite(&(v510_7),&(v510_13));
    drop(v510_7);
    join_wrapped_into(&mut v509_15_write,&((v510_14).read_zipper()),&[]);
    }
    v509_15_cursor.ascend(1);
  }
  drop(v509_15_cursor);
  drop(v509_15_write);
  (v509_15).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v523_27 = Space::new();
  let mut v523_27_write = v523_27.write_zipper();
  let mut v523_27_cursor = (*s0).read_zipper();
  let v523_27_origin = v523_27_cursor.path().len();
  for v523_27_byte in v523_27_cursor.child_mask().iter() {
    v523_27_cursor.descend_to_existing_byte(v523_27_byte);
    {
    let v524_2: Space = singleton(&v523_27_cursor.path()[v523_27_origin..(v523_27_origin + 1)]);
    let v524_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v524_2));
    let v524_4: Space = if map_kernels::has_head(&(v524_3)) { singleton(&[]) } else { Space::new() };
    drop(v524_3);
    let v524_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v524_4));
    drop(v524_4);
    let v524_8: Space = if (&(v524_5)).is_empty() { Space::new() } else {
      let v525_6: Path = concat_path(&(*p0),&v523_27_cursor.path()[v523_27_origin..(v523_27_origin + 1)]);
      let mut v525_7 = Space::new();
      let mut v525_7_write = v525_7.write_zipper();
      for v525_7_byte in v523_27_cursor.child_mask().iter() {
        v523_27_cursor.descend_to_existing_byte(v525_7_byte);
        {
        let v526_2: Space = singleton(&v523_27_cursor.path()[(v523_27_origin + 1)..(v523_27_origin + 2)]);
        let v526_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v526_2));
        let v526_4: Space = if map_kernels::has_head(&(v526_3)) { singleton(&[]) } else { Space::new() };
        drop(v526_3);
        let v526_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v526_4));
        drop(v526_4);
        let v526_8: Space = if (&(v526_5)).is_empty() { Space::new() } else {
          let v527_6: Path = concat_path(&(v525_6),&v523_27_cursor.path()[(v523_27_origin + 1)..(v523_27_origin + 2)]);
          let mut v527_7 = Space::new();
          let mut v527_7_write = v527_7.write_zipper();
          for v527_7_byte in v523_27_cursor.child_mask().iter() {
            v523_27_cursor.descend_to_existing_byte(v527_7_byte);
            {
            let v528_2: Space = singleton(&v523_27_cursor.path()[(v523_27_origin + 2)..(v523_27_origin + 3)]);
            let v528_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v528_2));
            let v528_4: Space = if map_kernels::has_head(&(v528_3)) { singleton(&[]) } else { Space::new() };
            drop(v528_3);
            let v528_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v528_4));
            drop(v528_4);
            let v528_8: Space = if (&(v528_5)).is_empty() { Space::new() } else {
              let v529_6: Path = concat_path(&(v527_6),&v523_27_cursor.path()[(v523_27_origin + 2)..(v523_27_origin + 3)]);
              let v529_7: Space = routine_49(c, &(v529_6), &v523_27_cursor, &(*s1));
              map_map_kernels::compose(&(v528_5),&(v529_7))
            };
            drop(v528_5);
            let v528_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v528_2));
            drop(v528_2);
            let v528_10: Space = if map_kernels::has_head(&(v528_9)) { singleton(&[]) } else { Space::new() };
            drop(v528_9);
            let v528_12: Space = if (&(v528_10)).is_empty() { Space::new() } else {
              let v530_6: Path = concat_path(&(v527_6),&v523_27_cursor.path()[(v523_27_origin + 2)..(v523_27_origin + 3)]);
              let v530_11: Space = routine_50(c, &(v530_6), &v523_27_cursor, &(*s1));
              drop(v530_6);
              map_map_kernels::compose(&(v528_10),&(v530_11))
            };
            drop(v528_10);
            let v528_13: Space = map_map_kernels::unite(&(v528_8),&(v528_12));
            join_wrapped_into(&mut v527_7_write,&((v528_13).read_zipper()),&[]);
            }
            v523_27_cursor.ascend(1);
          }
          drop(v527_7_write);
          map_map_kernels::compose(&(v526_5),&(v527_7))
        };
        drop(v526_5);
        let v526_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v526_2));
        drop(v526_2);
        let v526_10: Space = if map_kernels::has_head(&(v526_9)) { singleton(&[]) } else { Space::new() };
        drop(v526_9);
        let v526_12: Space = if (&(v526_10)).is_empty() { Space::new() } else {
          let v531_6: Path = concat_path(&(v525_6),&v523_27_cursor.path()[(v523_27_origin + 1)..(v523_27_origin + 2)]);
          let mut v531_11 = Space::new();
          let mut v531_11_write = v531_11.write_zipper();
          for v531_11_byte in v523_27_cursor.child_mask().iter() {
            v523_27_cursor.descend_to_existing_byte(v531_11_byte);
            {
            let v532_2: Space = singleton(&v523_27_cursor.path()[(v523_27_origin + 2)..(v523_27_origin + 3)]);
            let v532_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v532_2));
            let v532_4: Space = if map_kernels::has_head(&(v532_3)) { singleton(&[]) } else { Space::new() };
            drop(v532_3);
            let v532_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v532_4));
            drop(v532_4);
            let v532_8: Space = if (&(v532_5)).is_empty() { Space::new() } else {
              let v533_6: Path = concat_path(&(v531_6),&v523_27_cursor.path()[(v523_27_origin + 2)..(v523_27_origin + 3)]);
              let v533_7: Space = routine_49(c, &(v533_6), &v523_27_cursor, &(*s1));
              map_map_kernels::compose(&(v532_5),&(v533_7))
            };
            drop(v532_5);
            let v532_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v532_2));
            drop(v532_2);
            let v532_10: Space = if map_kernels::has_head(&(v532_9)) { singleton(&[]) } else { Space::new() };
            drop(v532_9);
            let v532_12: Space = if (&(v532_10)).is_empty() { Space::new() } else {
              let v534_6: Path = concat_path(&(v531_6),&v523_27_cursor.path()[(v523_27_origin + 2)..(v523_27_origin + 3)]);
              let v534_11: Space = routine_24(c, &(v534_6), &v523_27_cursor, &(*s1));
              drop(v534_6);
              map_map_kernels::compose(&(v532_10),&(v534_11))
            };
            drop(v532_10);
            let v532_13: Space = map_map_kernels::unite(&(v532_8),&(v532_12));
            join_wrapped_into(&mut v531_11_write,&((v532_13).read_zipper()),&[]);
            }
            v523_27_cursor.ascend(1);
          }
          drop(v531_11_write);
          drop(v531_6);
          map_map_kernels::compose(&(v526_10),&(v531_11))
        };
        drop(v526_10);
        let v526_13: Space = map_map_kernels::unite(&(v526_8),&(v526_12));
        join_wrapped_into(&mut v525_7_write,&((v526_13).read_zipper()),&[]);
        }
        v523_27_cursor.ascend(1);
      }
      drop(v525_7_write);
      map_map_kernels::compose(&(v524_5),&(v525_7))
    };
    drop(v524_5);
    let v524_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v524_2));
    drop(v524_2);
    let v524_10: Space = if map_kernels::has_head(&(v524_9)) { singleton(&[]) } else { Space::new() };
    drop(v524_9);
    let v524_13: Space = if (&(v524_10)).is_empty() { Space::new() } else {
      let v535_6: Path = concat_path(&(*p0),&v523_27_cursor.path()[v523_27_origin..(v523_27_origin + 1)]);
      let mut v535_12 = Space::new();
      let mut v535_12_write = v535_12.write_zipper();
      for v535_12_byte in v523_27_cursor.child_mask().iter() {
        v523_27_cursor.descend_to_existing_byte(v535_12_byte);
        {
        let v536_2: Space = singleton(&v523_27_cursor.path()[(v523_27_origin + 1)..(v523_27_origin + 2)]);
        let v536_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v536_2));
        let v536_4: Space = if map_kernels::has_head(&(v536_3)) { singleton(&[]) } else { Space::new() };
        drop(v536_3);
        let v536_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v536_4));
        drop(v536_4);
        let v536_8: Space = if (&(v536_5)).is_empty() { Space::new() } else {
          let v537_6: Path = concat_path(&(v535_6),&v523_27_cursor.path()[(v523_27_origin + 1)..(v523_27_origin + 2)]);
          let mut v537_7 = Space::new();
          let mut v537_7_write = v537_7.write_zipper();
          for v537_7_byte in v523_27_cursor.child_mask().iter() {
            v523_27_cursor.descend_to_existing_byte(v537_7_byte);
            {
            let v538_2: Space = singleton(&v523_27_cursor.path()[(v523_27_origin + 2)..(v523_27_origin + 3)]);
            let v538_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v538_2));
            let v538_4: Space = if map_kernels::has_head(&(v538_3)) { singleton(&[]) } else { Space::new() };
            drop(v538_3);
            let v538_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v538_4));
            drop(v538_4);
            let v538_8: Space = if (&(v538_5)).is_empty() { Space::new() } else {
              let v539_6: Path = concat_path(&(v537_6),&v523_27_cursor.path()[(v523_27_origin + 2)..(v523_27_origin + 3)]);
              let v539_7: Space = routine_49(c, &(v539_6), &v523_27_cursor, &(*s1));
              map_map_kernels::compose(&(v538_5),&(v539_7))
            };
            drop(v538_5);
            let v538_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v538_2));
            drop(v538_2);
            let v538_10: Space = if map_kernels::has_head(&(v538_9)) { singleton(&[]) } else { Space::new() };
            drop(v538_9);
            let v538_12: Space = if (&(v538_10)).is_empty() { Space::new() } else {
              let v540_6: Path = concat_path(&(v537_6),&v523_27_cursor.path()[(v523_27_origin + 2)..(v523_27_origin + 3)]);
              let v540_11: Space = routine_50(c, &(v540_6), &v523_27_cursor, &(*s1));
              drop(v540_6);
              map_map_kernels::compose(&(v538_10),&(v540_11))
            };
            drop(v538_10);
            let v538_13: Space = map_map_kernels::unite(&(v538_8),&(v538_12));
            join_wrapped_into(&mut v537_7_write,&((v538_13).read_zipper()),&[]);
            }
            v523_27_cursor.ascend(1);
          }
          drop(v537_7_write);
          drop(v537_6);
          map_map_kernels::compose(&(v536_5),&(v537_7))
        };
        drop(v536_5);
        let v536_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v536_2));
        drop(v536_2);
        let v536_10: Space = if map_kernels::has_head(&(v536_9)) { singleton(&[]) } else { Space::new() };
        drop(v536_9);
        let v536_13: Space = if (&(v536_10)).is_empty() { Space::new() } else {
          let v541_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v523_27_cursor.path()[v523_27_origin..(v523_27_origin + 1)]),&v523_27_cursor.path()[(v523_27_origin + 1)..(v523_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v536_10),&(v541_12))
        };
        drop(v536_10);
        let v536_14: Space = map_map_kernels::unite(&(v536_8),&(v536_13));
        drop(v536_13);
        join_wrapped_into(&mut v535_12_write,&((v536_14).read_zipper()),&[]);
        }
        v523_27_cursor.ascend(1);
      }
      drop(v535_12_write);
      drop(v535_6);
      map_map_kernels::compose(&(v524_10),&(v535_12))
    };
    drop(v524_10);
    let v524_14: Space = map_map_kernels::unite(&(v524_8),&(v524_13));
    join_wrapped_into(&mut v523_27_write,&((v524_14).read_zipper()),&[]);
    }
    v523_27_cursor.ascend(1);
  }
  drop(v523_27_cursor);
  drop(v523_27_write);
  (v523_27).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v542_21 = Space::new();
  let mut v542_21_write = v542_21.write_zipper();
  let mut v542_21_cursor = (*s0).read_zipper();
  let v542_21_origin = v542_21_cursor.path().len();
  for v542_21_byte in v542_21_cursor.child_mask().iter() {
    v542_21_cursor.descend_to_existing_byte(v542_21_byte);
    {
    let v543_2: Space = singleton(&v542_21_cursor.path()[v542_21_origin..(v542_21_origin + 1)]);
    let v543_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v543_2));
    let v543_4: Space = if map_kernels::has_head(&(v543_3)) { singleton(&[]) } else { Space::new() };
    drop(v543_3);
    let v543_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v543_4));
    drop(v543_4);
    let v543_8: Space = if (&(v543_5)).is_empty() { Space::new() } else {
      let v544_6: Path = concat_path(&(*p0),&v542_21_cursor.path()[v542_21_origin..(v542_21_origin + 1)]);
      let mut v544_7 = Space::new();
      let mut v544_7_write = v544_7.write_zipper();
      for v544_7_byte in v542_21_cursor.child_mask().iter() {
        v542_21_cursor.descend_to_existing_byte(v544_7_byte);
        {
        let v545_2: Space = singleton(&v542_21_cursor.path()[(v542_21_origin + 1)..(v542_21_origin + 2)]);
        let v545_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v545_2));
        let v545_4: Space = if map_kernels::has_head(&(v545_3)) { singleton(&[]) } else { Space::new() };
        drop(v545_3);
        let v545_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v545_4));
        drop(v545_4);
        let v545_8: Space = if (&(v545_5)).is_empty() { Space::new() } else {
          let v546_6: Path = concat_path(&(v544_6),&v542_21_cursor.path()[(v542_21_origin + 1)..(v542_21_origin + 2)]);
          let mut v546_7 = Space::new();
          let mut v546_7_write = v546_7.write_zipper();
          for v546_7_byte in v542_21_cursor.child_mask().iter() {
            v542_21_cursor.descend_to_existing_byte(v546_7_byte);
            {
            let v547_2: Space = singleton(&v542_21_cursor.path()[(v542_21_origin + 2)..(v542_21_origin + 3)]);
            let v547_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v547_2));
            let v547_4: Space = if map_kernels::has_head(&(v547_3)) { singleton(&[]) } else { Space::new() };
            drop(v547_3);
            let v547_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v547_4));
            drop(v547_4);
            let v547_8: Space = if (&(v547_5)).is_empty() { Space::new() } else {
              let v548_6: Path = concat_path(&(v546_6),&v542_21_cursor.path()[(v542_21_origin + 2)..(v542_21_origin + 3)]);
              let v548_7: Space = routine_49(c, &(v548_6), &v542_21_cursor, &(*s1));
              map_map_kernels::compose(&(v547_5),&(v548_7))
            };
            drop(v547_5);
            let v547_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v547_2));
            drop(v547_2);
            let v547_10: Space = if map_kernels::has_head(&(v547_9)) { singleton(&[]) } else { Space::new() };
            drop(v547_9);
            let v547_12: Space = if (&(v547_10)).is_empty() { Space::new() } else {
              let v549_6: Path = concat_path(&(v546_6),&v542_21_cursor.path()[(v542_21_origin + 2)..(v542_21_origin + 3)]);
              let v549_11: Space = routine_50(c, &(v549_6), &v542_21_cursor, &(*s1));
              drop(v549_6);
              map_map_kernels::compose(&(v547_10),&(v549_11))
            };
            drop(v547_10);
            let v547_13: Space = map_map_kernels::unite(&(v547_8),&(v547_12));
            join_wrapped_into(&mut v546_7_write,&((v547_13).read_zipper()),&[]);
            }
            v542_21_cursor.ascend(1);
          }
          drop(v546_7_write);
          map_map_kernels::compose(&(v545_5),&(v546_7))
        };
        drop(v545_5);
        let v545_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v545_2));
        drop(v545_2);
        let v545_10: Space = if map_kernels::has_head(&(v545_9)) { singleton(&[]) } else { Space::new() };
        drop(v545_9);
        let v545_12: Space = if (&(v545_10)).is_empty() { Space::new() } else {
          let v550_6: Path = concat_path(&(v544_6),&v542_21_cursor.path()[(v542_21_origin + 1)..(v542_21_origin + 2)]);
          let mut v550_11 = Space::new();
          let mut v550_11_write = v550_11.write_zipper();
          for v550_11_byte in v542_21_cursor.child_mask().iter() {
            v542_21_cursor.descend_to_existing_byte(v550_11_byte);
            {
            let v551_2: Space = singleton(&v542_21_cursor.path()[(v542_21_origin + 2)..(v542_21_origin + 3)]);
            let v551_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v551_2));
            let v551_4: Space = if map_kernels::has_head(&(v551_3)) { singleton(&[]) } else { Space::new() };
            drop(v551_3);
            let v551_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v551_4));
            drop(v551_4);
            let v551_8: Space = if (&(v551_5)).is_empty() { Space::new() } else {
              let v552_6: Path = concat_path(&(v550_6),&v542_21_cursor.path()[(v542_21_origin + 2)..(v542_21_origin + 3)]);
              let v552_7: Space = routine_49(c, &(v552_6), &v542_21_cursor, &(*s1));
              map_map_kernels::compose(&(v551_5),&(v552_7))
            };
            drop(v551_5);
            let v551_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v551_2));
            drop(v551_2);
            let v551_10: Space = if map_kernels::has_head(&(v551_9)) { singleton(&[]) } else { Space::new() };
            drop(v551_9);
            let v551_12: Space = if (&(v551_10)).is_empty() { Space::new() } else {
              let v553_6: Path = concat_path(&(v550_6),&v542_21_cursor.path()[(v542_21_origin + 2)..(v542_21_origin + 3)]);
              let v553_11: Space = routine_24(c, &(v553_6), &v542_21_cursor, &(*s1));
              drop(v553_6);
              map_map_kernels::compose(&(v551_10),&(v553_11))
            };
            drop(v551_10);
            let v551_13: Space = map_map_kernels::unite(&(v551_8),&(v551_12));
            join_wrapped_into(&mut v550_11_write,&((v551_13).read_zipper()),&[]);
            }
            v542_21_cursor.ascend(1);
          }
          drop(v550_11_write);
          drop(v550_6);
          map_map_kernels::compose(&(v545_10),&(v550_11))
        };
        drop(v545_10);
        let v545_13: Space = map_map_kernels::unite(&(v545_8),&(v545_12));
        join_wrapped_into(&mut v544_7_write,&((v545_13).read_zipper()),&[]);
        }
        v542_21_cursor.ascend(1);
      }
      drop(v544_7_write);
      drop(v544_6);
      map_map_kernels::compose(&(v543_5),&(v544_7))
    };
    drop(v543_5);
    let v543_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v543_2));
    drop(v543_2);
    let v543_10: Space = if map_kernels::has_head(&(v543_9)) { singleton(&[]) } else { Space::new() };
    drop(v543_9);
    let v543_13: Space = if (&(v543_10)).is_empty() { Space::new() } else {
      let v554_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v542_21_cursor.path()[v542_21_origin..(v542_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v543_10),&(v554_12))
    };
    drop(v543_10);
    let v543_14: Space = map_map_kernels::unite(&(v543_8),&(v543_13));
    drop(v543_13);
    join_wrapped_into(&mut v542_21_write,&((v543_14).read_zipper()),&[]);
    }
    v542_21_cursor.ascend(1);
  }
  drop(v542_21_cursor);
  drop(v542_21_write);
  (v542_21).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v555_9: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0))),&(*CONSTANT_5));
  (v555_9).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v556_27 = Space::new();
  let mut v556_27_write = v556_27.write_zipper();
  let mut v556_27_cursor = (*s0).read_zipper();
  let v556_27_origin = v556_27_cursor.path().len();
  for v556_27_byte in v556_27_cursor.child_mask().iter() {
    v556_27_cursor.descend_to_existing_byte(v556_27_byte);
    {
    let v557_2: Space = singleton(&v556_27_cursor.path()[v556_27_origin..(v556_27_origin + 1)]);
    let v557_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v557_2));
    let v557_4: Space = if map_kernels::has_head(&(v557_3)) { singleton(&[]) } else { Space::new() };
    drop(v557_3);
    let v557_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v557_4));
    drop(v557_4);
    let v557_8: Space = if (&(v557_5)).is_empty() { Space::new() } else {
      let v558_6: Path = concat_path(&(*p0),&v556_27_cursor.path()[v556_27_origin..(v556_27_origin + 1)]);
      let mut v558_7 = Space::new();
      let mut v558_7_write = v558_7.write_zipper();
      for v558_7_byte in v556_27_cursor.child_mask().iter() {
        v556_27_cursor.descend_to_existing_byte(v558_7_byte);
        {
        let v559_2: Space = singleton(&v556_27_cursor.path()[(v556_27_origin + 1)..(v556_27_origin + 2)]);
        let v559_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v559_2));
        let v559_4: Space = if map_kernels::has_head(&(v559_3)) { singleton(&[]) } else { Space::new() };
        drop(v559_3);
        let v559_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v559_4));
        drop(v559_4);
        let v559_8: Space = if (&(v559_5)).is_empty() { Space::new() } else {
          let v560_6: Path = concat_path(&(v558_6),&v556_27_cursor.path()[(v556_27_origin + 1)..(v556_27_origin + 2)]);
          let mut v560_7 = Space::new();
          let mut v560_7_write = v560_7.write_zipper();
          for v560_7_byte in v556_27_cursor.child_mask().iter() {
            v556_27_cursor.descend_to_existing_byte(v560_7_byte);
            {
            let v561_2: Space = singleton(&v556_27_cursor.path()[(v556_27_origin + 2)..(v556_27_origin + 3)]);
            let v561_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v561_2));
            let v561_4: Space = if map_kernels::has_head(&(v561_3)) { singleton(&[]) } else { Space::new() };
            drop(v561_3);
            let v561_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v561_4));
            drop(v561_4);
            let v561_8: Space = if (&(v561_5)).is_empty() { Space::new() } else {
              let v562_6: Path = concat_path(&(v560_6),&v556_27_cursor.path()[(v556_27_origin + 2)..(v556_27_origin + 3)]);
              let v562_7: Space = routine_51(c, &(v562_6), &v556_27_cursor, &(*s1));
              map_map_kernels::compose(&(v561_5),&(v562_7))
            };
            drop(v561_5);
            let v561_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v561_2));
            drop(v561_2);
            let v561_10: Space = if map_kernels::has_head(&(v561_9)) { singleton(&[]) } else { Space::new() };
            drop(v561_9);
            let v561_12: Space = if (&(v561_10)).is_empty() { Space::new() } else {
              let v563_6: Path = concat_path(&(v560_6),&v556_27_cursor.path()[(v556_27_origin + 2)..(v556_27_origin + 3)]);
              let v563_11: Space = routine_52(c, &(v563_6), &v556_27_cursor, &(*s1));
              drop(v563_6);
              map_map_kernels::compose(&(v561_10),&(v563_11))
            };
            drop(v561_10);
            let v561_13: Space = map_map_kernels::unite(&(v561_8),&(v561_12));
            join_wrapped_into(&mut v560_7_write,&((v561_13).read_zipper()),&[]);
            }
            v556_27_cursor.ascend(1);
          }
          drop(v560_7_write);
          map_map_kernels::compose(&(v559_5),&(v560_7))
        };
        drop(v559_5);
        let v559_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v559_2));
        drop(v559_2);
        let v559_10: Space = if map_kernels::has_head(&(v559_9)) { singleton(&[]) } else { Space::new() };
        drop(v559_9);
        let v559_12: Space = if (&(v559_10)).is_empty() { Space::new() } else {
          let v564_6: Path = concat_path(&(v558_6),&v556_27_cursor.path()[(v556_27_origin + 1)..(v556_27_origin + 2)]);
          let mut v564_11 = Space::new();
          let mut v564_11_write = v564_11.write_zipper();
          for v564_11_byte in v556_27_cursor.child_mask().iter() {
            v556_27_cursor.descend_to_existing_byte(v564_11_byte);
            {
            let v565_2: Space = singleton(&v556_27_cursor.path()[(v556_27_origin + 2)..(v556_27_origin + 3)]);
            let v565_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v565_2));
            let v565_4: Space = if map_kernels::has_head(&(v565_3)) { singleton(&[]) } else { Space::new() };
            drop(v565_3);
            let v565_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v565_4));
            drop(v565_4);
            let v565_8: Space = if (&(v565_5)).is_empty() { Space::new() } else {
              let v566_6: Path = concat_path(&(v564_6),&v556_27_cursor.path()[(v556_27_origin + 2)..(v556_27_origin + 3)]);
              let v566_7: Space = routine_51(c, &(v566_6), &v556_27_cursor, &(*s1));
              map_map_kernels::compose(&(v565_5),&(v566_7))
            };
            drop(v565_5);
            let v565_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v565_2));
            drop(v565_2);
            let v565_10: Space = if map_kernels::has_head(&(v565_9)) { singleton(&[]) } else { Space::new() };
            drop(v565_9);
            let v565_12: Space = if (&(v565_10)).is_empty() { Space::new() } else {
              let v567_6: Path = concat_path(&(v564_6),&v556_27_cursor.path()[(v556_27_origin + 2)..(v556_27_origin + 3)]);
              let v567_11: Space = routine_24(c, &(v567_6), &v556_27_cursor, &(*s1));
              drop(v567_6);
              map_map_kernels::compose(&(v565_10),&(v567_11))
            };
            drop(v565_10);
            let v565_13: Space = map_map_kernels::unite(&(v565_8),&(v565_12));
            join_wrapped_into(&mut v564_11_write,&((v565_13).read_zipper()),&[]);
            }
            v556_27_cursor.ascend(1);
          }
          drop(v564_11_write);
          drop(v564_6);
          map_map_kernels::compose(&(v559_10),&(v564_11))
        };
        drop(v559_10);
        let v559_13: Space = map_map_kernels::unite(&(v559_8),&(v559_12));
        join_wrapped_into(&mut v558_7_write,&((v559_13).read_zipper()),&[]);
        }
        v556_27_cursor.ascend(1);
      }
      drop(v558_7_write);
      map_map_kernels::compose(&(v557_5),&(v558_7))
    };
    drop(v557_5);
    let v557_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v557_2));
    drop(v557_2);
    let v557_10: Space = if map_kernels::has_head(&(v557_9)) { singleton(&[]) } else { Space::new() };
    drop(v557_9);
    let v557_13: Space = if (&(v557_10)).is_empty() { Space::new() } else {
      let v568_6: Path = concat_path(&(*p0),&v556_27_cursor.path()[v556_27_origin..(v556_27_origin + 1)]);
      let mut v568_12 = Space::new();
      let mut v568_12_write = v568_12.write_zipper();
      for v568_12_byte in v556_27_cursor.child_mask().iter() {
        v556_27_cursor.descend_to_existing_byte(v568_12_byte);
        {
        let v569_2: Space = singleton(&v556_27_cursor.path()[(v556_27_origin + 1)..(v556_27_origin + 2)]);
        let v569_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v569_2));
        let v569_4: Space = if map_kernels::has_head(&(v569_3)) { singleton(&[]) } else { Space::new() };
        drop(v569_3);
        let v569_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v569_4));
        drop(v569_4);
        let v569_8: Space = if (&(v569_5)).is_empty() { Space::new() } else {
          let v570_6: Path = concat_path(&(v568_6),&v556_27_cursor.path()[(v556_27_origin + 1)..(v556_27_origin + 2)]);
          let mut v570_7 = Space::new();
          let mut v570_7_write = v570_7.write_zipper();
          for v570_7_byte in v556_27_cursor.child_mask().iter() {
            v556_27_cursor.descend_to_existing_byte(v570_7_byte);
            {
            let v571_2: Space = singleton(&v556_27_cursor.path()[(v556_27_origin + 2)..(v556_27_origin + 3)]);
            let v571_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v571_2));
            let v571_4: Space = if map_kernels::has_head(&(v571_3)) { singleton(&[]) } else { Space::new() };
            drop(v571_3);
            let v571_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v571_4));
            drop(v571_4);
            let v571_8: Space = if (&(v571_5)).is_empty() { Space::new() } else {
              let v572_6: Path = concat_path(&(v570_6),&v556_27_cursor.path()[(v556_27_origin + 2)..(v556_27_origin + 3)]);
              let v572_7: Space = routine_51(c, &(v572_6), &v556_27_cursor, &(*s1));
              map_map_kernels::compose(&(v571_5),&(v572_7))
            };
            drop(v571_5);
            let v571_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v571_2));
            drop(v571_2);
            let v571_10: Space = if map_kernels::has_head(&(v571_9)) { singleton(&[]) } else { Space::new() };
            drop(v571_9);
            let v571_12: Space = if (&(v571_10)).is_empty() { Space::new() } else {
              let v573_6: Path = concat_path(&(v570_6),&v556_27_cursor.path()[(v556_27_origin + 2)..(v556_27_origin + 3)]);
              let v573_11: Space = routine_52(c, &(v573_6), &v556_27_cursor, &(*s1));
              drop(v573_6);
              map_map_kernels::compose(&(v571_10),&(v573_11))
            };
            drop(v571_10);
            let v571_13: Space = map_map_kernels::unite(&(v571_8),&(v571_12));
            join_wrapped_into(&mut v570_7_write,&((v571_13).read_zipper()),&[]);
            }
            v556_27_cursor.ascend(1);
          }
          drop(v570_7_write);
          drop(v570_6);
          map_map_kernels::compose(&(v569_5),&(v570_7))
        };
        drop(v569_5);
        let v569_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v569_2));
        drop(v569_2);
        let v569_10: Space = if map_kernels::has_head(&(v569_9)) { singleton(&[]) } else { Space::new() };
        drop(v569_9);
        let v569_13: Space = if (&(v569_10)).is_empty() { Space::new() } else {
          let v574_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v556_27_cursor.path()[v556_27_origin..(v556_27_origin + 1)]),&v556_27_cursor.path()[(v556_27_origin + 1)..(v556_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v569_10),&(v574_12))
        };
        drop(v569_10);
        let v569_14: Space = map_map_kernels::unite(&(v569_8),&(v569_13));
        drop(v569_13);
        join_wrapped_into(&mut v568_12_write,&((v569_14).read_zipper()),&[]);
        }
        v556_27_cursor.ascend(1);
      }
      drop(v568_12_write);
      drop(v568_6);
      map_map_kernels::compose(&(v557_10),&(v568_12))
    };
    drop(v557_10);
    let v557_14: Space = map_map_kernels::unite(&(v557_8),&(v557_13));
    join_wrapped_into(&mut v556_27_write,&((v557_14).read_zipper()),&[]);
    }
    v556_27_cursor.ascend(1);
  }
  drop(v556_27_cursor);
  drop(v556_27_write);
  (v556_27).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v575_21 = Space::new();
  let mut v575_21_write = v575_21.write_zipper();
  let mut v575_21_cursor = (*s0).read_zipper();
  let v575_21_origin = v575_21_cursor.path().len();
  for v575_21_byte in v575_21_cursor.child_mask().iter() {
    v575_21_cursor.descend_to_existing_byte(v575_21_byte);
    {
    let v576_2: Space = singleton(&v575_21_cursor.path()[v575_21_origin..(v575_21_origin + 1)]);
    let v576_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v576_2));
    let v576_4: Space = if map_kernels::has_head(&(v576_3)) { singleton(&[]) } else { Space::new() };
    drop(v576_3);
    let v576_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v576_4));
    drop(v576_4);
    let v576_8: Space = if (&(v576_5)).is_empty() { Space::new() } else {
      let v577_6: Path = concat_path(&(*p0),&v575_21_cursor.path()[v575_21_origin..(v575_21_origin + 1)]);
      let mut v577_7 = Space::new();
      let mut v577_7_write = v577_7.write_zipper();
      for v577_7_byte in v575_21_cursor.child_mask().iter() {
        v575_21_cursor.descend_to_existing_byte(v577_7_byte);
        {
        let v578_2: Space = singleton(&v575_21_cursor.path()[(v575_21_origin + 1)..(v575_21_origin + 2)]);
        let v578_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v578_2));
        let v578_4: Space = if map_kernels::has_head(&(v578_3)) { singleton(&[]) } else { Space::new() };
        drop(v578_3);
        let v578_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v578_4));
        drop(v578_4);
        let v578_8: Space = if (&(v578_5)).is_empty() { Space::new() } else {
          let v579_6: Path = concat_path(&(v577_6),&v575_21_cursor.path()[(v575_21_origin + 1)..(v575_21_origin + 2)]);
          let mut v579_7 = Space::new();
          let mut v579_7_write = v579_7.write_zipper();
          for v579_7_byte in v575_21_cursor.child_mask().iter() {
            v575_21_cursor.descend_to_existing_byte(v579_7_byte);
            {
            let v580_2: Space = singleton(&v575_21_cursor.path()[(v575_21_origin + 2)..(v575_21_origin + 3)]);
            let v580_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v580_2));
            let v580_4: Space = if map_kernels::has_head(&(v580_3)) { singleton(&[]) } else { Space::new() };
            drop(v580_3);
            let v580_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v580_4));
            drop(v580_4);
            let v580_8: Space = if (&(v580_5)).is_empty() { Space::new() } else {
              let v581_6: Path = concat_path(&(v579_6),&v575_21_cursor.path()[(v575_21_origin + 2)..(v575_21_origin + 3)]);
              let v581_7: Space = routine_51(c, &(v581_6), &v575_21_cursor, &(*s1));
              map_map_kernels::compose(&(v580_5),&(v581_7))
            };
            drop(v580_5);
            let v580_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v580_2));
            drop(v580_2);
            let v580_10: Space = if map_kernels::has_head(&(v580_9)) { singleton(&[]) } else { Space::new() };
            drop(v580_9);
            let v580_12: Space = if (&(v580_10)).is_empty() { Space::new() } else {
              let v582_6: Path = concat_path(&(v579_6),&v575_21_cursor.path()[(v575_21_origin + 2)..(v575_21_origin + 3)]);
              let v582_11: Space = routine_52(c, &(v582_6), &v575_21_cursor, &(*s1));
              drop(v582_6);
              map_map_kernels::compose(&(v580_10),&(v582_11))
            };
            drop(v580_10);
            let v580_13: Space = map_map_kernels::unite(&(v580_8),&(v580_12));
            join_wrapped_into(&mut v579_7_write,&((v580_13).read_zipper()),&[]);
            }
            v575_21_cursor.ascend(1);
          }
          drop(v579_7_write);
          map_map_kernels::compose(&(v578_5),&(v579_7))
        };
        drop(v578_5);
        let v578_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v578_2));
        drop(v578_2);
        let v578_10: Space = if map_kernels::has_head(&(v578_9)) { singleton(&[]) } else { Space::new() };
        drop(v578_9);
        let v578_12: Space = if (&(v578_10)).is_empty() { Space::new() } else {
          let v583_6: Path = concat_path(&(v577_6),&v575_21_cursor.path()[(v575_21_origin + 1)..(v575_21_origin + 2)]);
          let mut v583_11 = Space::new();
          let mut v583_11_write = v583_11.write_zipper();
          for v583_11_byte in v575_21_cursor.child_mask().iter() {
            v575_21_cursor.descend_to_existing_byte(v583_11_byte);
            {
            let v584_2: Space = singleton(&v575_21_cursor.path()[(v575_21_origin + 2)..(v575_21_origin + 3)]);
            let v584_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v584_2));
            let v584_4: Space = if map_kernels::has_head(&(v584_3)) { singleton(&[]) } else { Space::new() };
            drop(v584_3);
            let v584_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v584_4));
            drop(v584_4);
            let v584_8: Space = if (&(v584_5)).is_empty() { Space::new() } else {
              let v585_6: Path = concat_path(&(v583_6),&v575_21_cursor.path()[(v575_21_origin + 2)..(v575_21_origin + 3)]);
              let v585_7: Space = routine_51(c, &(v585_6), &v575_21_cursor, &(*s1));
              map_map_kernels::compose(&(v584_5),&(v585_7))
            };
            drop(v584_5);
            let v584_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v584_2));
            drop(v584_2);
            let v584_10: Space = if map_kernels::has_head(&(v584_9)) { singleton(&[]) } else { Space::new() };
            drop(v584_9);
            let v584_12: Space = if (&(v584_10)).is_empty() { Space::new() } else {
              let v586_6: Path = concat_path(&(v583_6),&v575_21_cursor.path()[(v575_21_origin + 2)..(v575_21_origin + 3)]);
              let v586_11: Space = routine_24(c, &(v586_6), &v575_21_cursor, &(*s1));
              drop(v586_6);
              map_map_kernels::compose(&(v584_10),&(v586_11))
            };
            drop(v584_10);
            let v584_13: Space = map_map_kernels::unite(&(v584_8),&(v584_12));
            join_wrapped_into(&mut v583_11_write,&((v584_13).read_zipper()),&[]);
            }
            v575_21_cursor.ascend(1);
          }
          drop(v583_11_write);
          drop(v583_6);
          map_map_kernels::compose(&(v578_10),&(v583_11))
        };
        drop(v578_10);
        let v578_13: Space = map_map_kernels::unite(&(v578_8),&(v578_12));
        join_wrapped_into(&mut v577_7_write,&((v578_13).read_zipper()),&[]);
        }
        v575_21_cursor.ascend(1);
      }
      drop(v577_7_write);
      drop(v577_6);
      map_map_kernels::compose(&(v576_5),&(v577_7))
    };
    drop(v576_5);
    let v576_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v576_2));
    drop(v576_2);
    let v576_10: Space = if map_kernels::has_head(&(v576_9)) { singleton(&[]) } else { Space::new() };
    drop(v576_9);
    let v576_13: Space = if (&(v576_10)).is_empty() { Space::new() } else {
      let v587_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v575_21_cursor.path()[v575_21_origin..(v575_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v576_10),&(v587_12))
    };
    drop(v576_10);
    let v576_14: Space = map_map_kernels::unite(&(v576_8),&(v576_13));
    drop(v576_13);
    join_wrapped_into(&mut v575_21_write,&((v576_14).read_zipper()),&[]);
    }
    v575_21_cursor.ascend(1);
  }
  drop(v575_21_cursor);
  drop(v575_21_write);
  (v575_21).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v588_27 = Space::new();
  let mut v588_27_write = v588_27.write_zipper();
  let mut v588_27_cursor = (*s0).read_zipper();
  let v588_27_origin = v588_27_cursor.path().len();
  for v588_27_byte in v588_27_cursor.child_mask().iter() {
    v588_27_cursor.descend_to_existing_byte(v588_27_byte);
    {
    let v589_2: Space = singleton(&v588_27_cursor.path()[v588_27_origin..(v588_27_origin + 1)]);
    let v589_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v589_2));
    let v589_4: Space = if map_kernels::has_head(&(v589_3)) { singleton(&[]) } else { Space::new() };
    drop(v589_3);
    let v589_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v589_4));
    drop(v589_4);
    let v589_8: Space = if (&(v589_5)).is_empty() { Space::new() } else {
      let v590_6: Path = concat_path(&(*p0),&v588_27_cursor.path()[v588_27_origin..(v588_27_origin + 1)]);
      let mut v590_7 = Space::new();
      let mut v590_7_write = v590_7.write_zipper();
      for v590_7_byte in v588_27_cursor.child_mask().iter() {
        v588_27_cursor.descend_to_existing_byte(v590_7_byte);
        {
        let v591_2: Space = singleton(&v588_27_cursor.path()[(v588_27_origin + 1)..(v588_27_origin + 2)]);
        let v591_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v591_2));
        let v591_4: Space = if map_kernels::has_head(&(v591_3)) { singleton(&[]) } else { Space::new() };
        drop(v591_3);
        let v591_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v591_4));
        drop(v591_4);
        let v591_8: Space = if (&(v591_5)).is_empty() { Space::new() } else {
          let v592_6: Path = concat_path(&(v590_6),&v588_27_cursor.path()[(v588_27_origin + 1)..(v588_27_origin + 2)]);
          let mut v592_7 = Space::new();
          let mut v592_7_write = v592_7.write_zipper();
          for v592_7_byte in v588_27_cursor.child_mask().iter() {
            v588_27_cursor.descend_to_existing_byte(v592_7_byte);
            {
            let v593_2: Space = singleton(&v588_27_cursor.path()[(v588_27_origin + 2)..(v588_27_origin + 3)]);
            let v593_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v593_2));
            let v593_4: Space = if map_kernels::has_head(&(v593_3)) { singleton(&[]) } else { Space::new() };
            drop(v593_3);
            let v593_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v593_4));
            drop(v593_4);
            let v593_8: Space = if (&(v593_5)).is_empty() { Space::new() } else {
              let v594_6: Path = concat_path(&(v592_6),&v588_27_cursor.path()[(v588_27_origin + 2)..(v588_27_origin + 3)]);
              let v594_7: Space = routine_53(c, &(v594_6), &v588_27_cursor, &(*s1));
              map_map_kernels::compose(&(v593_5),&(v594_7))
            };
            drop(v593_5);
            let v593_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v593_2));
            drop(v593_2);
            let v593_10: Space = if map_kernels::has_head(&(v593_9)) { singleton(&[]) } else { Space::new() };
            drop(v593_9);
            let v593_12: Space = if (&(v593_10)).is_empty() { Space::new() } else {
              let v595_6: Path = concat_path(&(v592_6),&v588_27_cursor.path()[(v588_27_origin + 2)..(v588_27_origin + 3)]);
              let v595_11: Space = routine_54(c, &(v595_6), &v588_27_cursor, &(*s1));
              drop(v595_6);
              map_map_kernels::compose(&(v593_10),&(v595_11))
            };
            drop(v593_10);
            let v593_13: Space = map_map_kernels::unite(&(v593_8),&(v593_12));
            join_wrapped_into(&mut v592_7_write,&((v593_13).read_zipper()),&[]);
            }
            v588_27_cursor.ascend(1);
          }
          drop(v592_7_write);
          map_map_kernels::compose(&(v591_5),&(v592_7))
        };
        drop(v591_5);
        let v591_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v591_2));
        drop(v591_2);
        let v591_10: Space = if map_kernels::has_head(&(v591_9)) { singleton(&[]) } else { Space::new() };
        drop(v591_9);
        let v591_12: Space = if (&(v591_10)).is_empty() { Space::new() } else {
          let v596_6: Path = concat_path(&(v590_6),&v588_27_cursor.path()[(v588_27_origin + 1)..(v588_27_origin + 2)]);
          let mut v596_11 = Space::new();
          let mut v596_11_write = v596_11.write_zipper();
          for v596_11_byte in v588_27_cursor.child_mask().iter() {
            v588_27_cursor.descend_to_existing_byte(v596_11_byte);
            {
            let v597_2: Space = singleton(&v588_27_cursor.path()[(v588_27_origin + 2)..(v588_27_origin + 3)]);
            let v597_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v597_2));
            let v597_4: Space = if map_kernels::has_head(&(v597_3)) { singleton(&[]) } else { Space::new() };
            drop(v597_3);
            let v597_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v597_4));
            drop(v597_4);
            let v597_8: Space = if (&(v597_5)).is_empty() { Space::new() } else {
              let v598_6: Path = concat_path(&(v596_6),&v588_27_cursor.path()[(v588_27_origin + 2)..(v588_27_origin + 3)]);
              let v598_7: Space = routine_53(c, &(v598_6), &v588_27_cursor, &(*s1));
              map_map_kernels::compose(&(v597_5),&(v598_7))
            };
            drop(v597_5);
            let v597_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v597_2));
            drop(v597_2);
            let v597_10: Space = if map_kernels::has_head(&(v597_9)) { singleton(&[]) } else { Space::new() };
            drop(v597_9);
            let v597_12: Space = if (&(v597_10)).is_empty() { Space::new() } else {
              let v599_6: Path = concat_path(&(v596_6),&v588_27_cursor.path()[(v588_27_origin + 2)..(v588_27_origin + 3)]);
              let v599_11: Space = routine_24(c, &(v599_6), &v588_27_cursor, &(*s1));
              drop(v599_6);
              map_map_kernels::compose(&(v597_10),&(v599_11))
            };
            drop(v597_10);
            let v597_13: Space = map_map_kernels::unite(&(v597_8),&(v597_12));
            join_wrapped_into(&mut v596_11_write,&((v597_13).read_zipper()),&[]);
            }
            v588_27_cursor.ascend(1);
          }
          drop(v596_11_write);
          drop(v596_6);
          map_map_kernels::compose(&(v591_10),&(v596_11))
        };
        drop(v591_10);
        let v591_13: Space = map_map_kernels::unite(&(v591_8),&(v591_12));
        join_wrapped_into(&mut v590_7_write,&((v591_13).read_zipper()),&[]);
        }
        v588_27_cursor.ascend(1);
      }
      drop(v590_7_write);
      map_map_kernels::compose(&(v589_5),&(v590_7))
    };
    drop(v589_5);
    let v589_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v589_2));
    drop(v589_2);
    let v589_10: Space = if map_kernels::has_head(&(v589_9)) { singleton(&[]) } else { Space::new() };
    drop(v589_9);
    let v589_13: Space = if (&(v589_10)).is_empty() { Space::new() } else {
      let v600_6: Path = concat_path(&(*p0),&v588_27_cursor.path()[v588_27_origin..(v588_27_origin + 1)]);
      let mut v600_12 = Space::new();
      let mut v600_12_write = v600_12.write_zipper();
      for v600_12_byte in v588_27_cursor.child_mask().iter() {
        v588_27_cursor.descend_to_existing_byte(v600_12_byte);
        {
        let v601_2: Space = singleton(&v588_27_cursor.path()[(v588_27_origin + 1)..(v588_27_origin + 2)]);
        let v601_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v601_2));
        let v601_4: Space = if map_kernels::has_head(&(v601_3)) { singleton(&[]) } else { Space::new() };
        drop(v601_3);
        let v601_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v601_4));
        drop(v601_4);
        let v601_8: Space = if (&(v601_5)).is_empty() { Space::new() } else {
          let v602_6: Path = concat_path(&(v600_6),&v588_27_cursor.path()[(v588_27_origin + 1)..(v588_27_origin + 2)]);
          let mut v602_7 = Space::new();
          let mut v602_7_write = v602_7.write_zipper();
          for v602_7_byte in v588_27_cursor.child_mask().iter() {
            v588_27_cursor.descend_to_existing_byte(v602_7_byte);
            {
            let v603_2: Space = singleton(&v588_27_cursor.path()[(v588_27_origin + 2)..(v588_27_origin + 3)]);
            let v603_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v603_2));
            let v603_4: Space = if map_kernels::has_head(&(v603_3)) { singleton(&[]) } else { Space::new() };
            drop(v603_3);
            let v603_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v603_4));
            drop(v603_4);
            let v603_8: Space = if (&(v603_5)).is_empty() { Space::new() } else {
              let v604_6: Path = concat_path(&(v602_6),&v588_27_cursor.path()[(v588_27_origin + 2)..(v588_27_origin + 3)]);
              let v604_7: Space = routine_53(c, &(v604_6), &v588_27_cursor, &(*s1));
              map_map_kernels::compose(&(v603_5),&(v604_7))
            };
            drop(v603_5);
            let v603_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v603_2));
            drop(v603_2);
            let v603_10: Space = if map_kernels::has_head(&(v603_9)) { singleton(&[]) } else { Space::new() };
            drop(v603_9);
            let v603_12: Space = if (&(v603_10)).is_empty() { Space::new() } else {
              let v605_6: Path = concat_path(&(v602_6),&v588_27_cursor.path()[(v588_27_origin + 2)..(v588_27_origin + 3)]);
              let v605_11: Space = routine_54(c, &(v605_6), &v588_27_cursor, &(*s1));
              drop(v605_6);
              map_map_kernels::compose(&(v603_10),&(v605_11))
            };
            drop(v603_10);
            let v603_13: Space = map_map_kernels::unite(&(v603_8),&(v603_12));
            join_wrapped_into(&mut v602_7_write,&((v603_13).read_zipper()),&[]);
            }
            v588_27_cursor.ascend(1);
          }
          drop(v602_7_write);
          drop(v602_6);
          map_map_kernels::compose(&(v601_5),&(v602_7))
        };
        drop(v601_5);
        let v601_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v601_2));
        drop(v601_2);
        let v601_10: Space = if map_kernels::has_head(&(v601_9)) { singleton(&[]) } else { Space::new() };
        drop(v601_9);
        let v601_13: Space = if (&(v601_10)).is_empty() { Space::new() } else {
          let v606_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v588_27_cursor.path()[v588_27_origin..(v588_27_origin + 1)]),&v588_27_cursor.path()[(v588_27_origin + 1)..(v588_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v601_10),&(v606_12))
        };
        drop(v601_10);
        let v601_14: Space = map_map_kernels::unite(&(v601_8),&(v601_13));
        drop(v601_13);
        join_wrapped_into(&mut v600_12_write,&((v601_14).read_zipper()),&[]);
        }
        v588_27_cursor.ascend(1);
      }
      drop(v600_12_write);
      drop(v600_6);
      map_map_kernels::compose(&(v589_10),&(v600_12))
    };
    drop(v589_10);
    let v589_14: Space = map_map_kernels::unite(&(v589_8),&(v589_13));
    join_wrapped_into(&mut v588_27_write,&((v589_14).read_zipper()),&[]);
    }
    v588_27_cursor.ascend(1);
  }
  drop(v588_27_cursor);
  drop(v588_27_write);
  (v588_27).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v607_21 = Space::new();
  let mut v607_21_write = v607_21.write_zipper();
  let mut v607_21_cursor = (*s0).read_zipper();
  let v607_21_origin = v607_21_cursor.path().len();
  for v607_21_byte in v607_21_cursor.child_mask().iter() {
    v607_21_cursor.descend_to_existing_byte(v607_21_byte);
    {
    let v608_2: Space = singleton(&v607_21_cursor.path()[v607_21_origin..(v607_21_origin + 1)]);
    let v608_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v608_2));
    let v608_4: Space = if map_kernels::has_head(&(v608_3)) { singleton(&[]) } else { Space::new() };
    drop(v608_3);
    let v608_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v608_4));
    drop(v608_4);
    let v608_8: Space = if (&(v608_5)).is_empty() { Space::new() } else {
      let v609_6: Path = concat_path(&(*p0),&v607_21_cursor.path()[v607_21_origin..(v607_21_origin + 1)]);
      let mut v609_7 = Space::new();
      let mut v609_7_write = v609_7.write_zipper();
      for v609_7_byte in v607_21_cursor.child_mask().iter() {
        v607_21_cursor.descend_to_existing_byte(v609_7_byte);
        {
        let v610_2: Space = singleton(&v607_21_cursor.path()[(v607_21_origin + 1)..(v607_21_origin + 2)]);
        let v610_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v610_2));
        let v610_4: Space = if map_kernels::has_head(&(v610_3)) { singleton(&[]) } else { Space::new() };
        drop(v610_3);
        let v610_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v610_4));
        drop(v610_4);
        let v610_8: Space = if (&(v610_5)).is_empty() { Space::new() } else {
          let v611_6: Path = concat_path(&(v609_6),&v607_21_cursor.path()[(v607_21_origin + 1)..(v607_21_origin + 2)]);
          let mut v611_7 = Space::new();
          let mut v611_7_write = v611_7.write_zipper();
          for v611_7_byte in v607_21_cursor.child_mask().iter() {
            v607_21_cursor.descend_to_existing_byte(v611_7_byte);
            {
            let v612_2: Space = singleton(&v607_21_cursor.path()[(v607_21_origin + 2)..(v607_21_origin + 3)]);
            let v612_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v612_2));
            let v612_4: Space = if map_kernels::has_head(&(v612_3)) { singleton(&[]) } else { Space::new() };
            drop(v612_3);
            let v612_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v612_4));
            drop(v612_4);
            let v612_8: Space = if (&(v612_5)).is_empty() { Space::new() } else {
              let v613_6: Path = concat_path(&(v611_6),&v607_21_cursor.path()[(v607_21_origin + 2)..(v607_21_origin + 3)]);
              let v613_7: Space = routine_53(c, &(v613_6), &v607_21_cursor, &(*s1));
              map_map_kernels::compose(&(v612_5),&(v613_7))
            };
            drop(v612_5);
            let v612_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v612_2));
            drop(v612_2);
            let v612_10: Space = if map_kernels::has_head(&(v612_9)) { singleton(&[]) } else { Space::new() };
            drop(v612_9);
            let v612_12: Space = if (&(v612_10)).is_empty() { Space::new() } else {
              let v614_6: Path = concat_path(&(v611_6),&v607_21_cursor.path()[(v607_21_origin + 2)..(v607_21_origin + 3)]);
              let v614_11: Space = routine_54(c, &(v614_6), &v607_21_cursor, &(*s1));
              drop(v614_6);
              map_map_kernels::compose(&(v612_10),&(v614_11))
            };
            drop(v612_10);
            let v612_13: Space = map_map_kernels::unite(&(v612_8),&(v612_12));
            join_wrapped_into(&mut v611_7_write,&((v612_13).read_zipper()),&[]);
            }
            v607_21_cursor.ascend(1);
          }
          drop(v611_7_write);
          map_map_kernels::compose(&(v610_5),&(v611_7))
        };
        drop(v610_5);
        let v610_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v610_2));
        drop(v610_2);
        let v610_10: Space = if map_kernels::has_head(&(v610_9)) { singleton(&[]) } else { Space::new() };
        drop(v610_9);
        let v610_12: Space = if (&(v610_10)).is_empty() { Space::new() } else {
          let v615_6: Path = concat_path(&(v609_6),&v607_21_cursor.path()[(v607_21_origin + 1)..(v607_21_origin + 2)]);
          let mut v615_11 = Space::new();
          let mut v615_11_write = v615_11.write_zipper();
          for v615_11_byte in v607_21_cursor.child_mask().iter() {
            v607_21_cursor.descend_to_existing_byte(v615_11_byte);
            {
            let v616_2: Space = singleton(&v607_21_cursor.path()[(v607_21_origin + 2)..(v607_21_origin + 3)]);
            let v616_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v616_2));
            let v616_4: Space = if map_kernels::has_head(&(v616_3)) { singleton(&[]) } else { Space::new() };
            drop(v616_3);
            let v616_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v616_4));
            drop(v616_4);
            let v616_8: Space = if (&(v616_5)).is_empty() { Space::new() } else {
              let v617_6: Path = concat_path(&(v615_6),&v607_21_cursor.path()[(v607_21_origin + 2)..(v607_21_origin + 3)]);
              let v617_7: Space = routine_53(c, &(v617_6), &v607_21_cursor, &(*s1));
              map_map_kernels::compose(&(v616_5),&(v617_7))
            };
            drop(v616_5);
            let v616_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v616_2));
            drop(v616_2);
            let v616_10: Space = if map_kernels::has_head(&(v616_9)) { singleton(&[]) } else { Space::new() };
            drop(v616_9);
            let v616_12: Space = if (&(v616_10)).is_empty() { Space::new() } else {
              let v618_6: Path = concat_path(&(v615_6),&v607_21_cursor.path()[(v607_21_origin + 2)..(v607_21_origin + 3)]);
              let v618_11: Space = routine_24(c, &(v618_6), &v607_21_cursor, &(*s1));
              drop(v618_6);
              map_map_kernels::compose(&(v616_10),&(v618_11))
            };
            drop(v616_10);
            let v616_13: Space = map_map_kernels::unite(&(v616_8),&(v616_12));
            join_wrapped_into(&mut v615_11_write,&((v616_13).read_zipper()),&[]);
            }
            v607_21_cursor.ascend(1);
          }
          drop(v615_11_write);
          drop(v615_6);
          map_map_kernels::compose(&(v610_10),&(v615_11))
        };
        drop(v610_10);
        let v610_13: Space = map_map_kernels::unite(&(v610_8),&(v610_12));
        join_wrapped_into(&mut v609_7_write,&((v610_13).read_zipper()),&[]);
        }
        v607_21_cursor.ascend(1);
      }
      drop(v609_7_write);
      drop(v609_6);
      map_map_kernels::compose(&(v608_5),&(v609_7))
    };
    drop(v608_5);
    let v608_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v608_2));
    drop(v608_2);
    let v608_10: Space = if map_kernels::has_head(&(v608_9)) { singleton(&[]) } else { Space::new() };
    drop(v608_9);
    let v608_13: Space = if (&(v608_10)).is_empty() { Space::new() } else {
      let v619_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v607_21_cursor.path()[v607_21_origin..(v607_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v608_10),&(v619_12))
    };
    drop(v608_10);
    let v608_14: Space = map_map_kernels::unite(&(v608_8),&(v608_13));
    drop(v608_13);
    join_wrapped_into(&mut v607_21_write,&((v608_14).read_zipper()),&[]);
    }
    v607_21_cursor.ascend(1);
  }
  drop(v607_21_cursor);
  drop(v607_21_write);
  (v607_21).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v620_10 = Space::new();
  let mut v620_10_write = v620_10.write_zipper();
  let mut v620_10_cursor = (*s0).read_zipper();
  let v620_10_origin = v620_10_cursor.path().len();
  for v620_10_byte in v620_10_cursor.child_mask().iter() {
    v620_10_cursor.descend_to_existing_byte(v620_10_byte);
    {
    let v621_2: Space = singleton(&v620_10_cursor.path()[v620_10_origin..(v620_10_origin + 1)]);
    let v621_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v621_2));
    let v621_4: Space = if map_kernels::has_head(&(v621_3)) { singleton(&[]) } else { Space::new() };
    drop(v621_3);
    let v621_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v621_4));
    drop(v621_4);
    let v621_7: Space = if (&(v621_5)).is_empty() { Space::new() } else {
      let mut v622_6 = Space::new();
      let mut v622_6_write = v622_6.write_zipper();
      for v622_6_byte in v620_10_cursor.child_mask().iter() {
        v620_10_cursor.descend_to_existing_byte(v622_6_byte);
        {
        let v623_2: Space = Space::new();
        join_wrapped_into(&mut v622_6_write,&((v623_2).read_zipper()),&[]);
        }
        v620_10_cursor.ascend(1);
      }
      drop(v622_6_write);
      map_map_kernels::compose(&(v621_5),&(v622_6))
    };
    drop(v621_5);
    let v621_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v621_2));
    drop(v621_2);
    let v621_9: Space = if map_kernels::has_head(&(v621_8)) { singleton(&[]) } else { Space::new() };
    drop(v621_8);
    let v621_12: Space = if (&(v621_9)).is_empty() { Space::new() } else {
      let v624_10: Path = concat_path(&(*p0),&v620_10_cursor.path()[v620_10_origin..(v620_10_origin + 1)]);
      let mut v624_11 = Space::new();
      let mut v624_11_write = v624_11.write_zipper();
      for v624_11_byte in v620_10_cursor.child_mask().iter() {
        v620_10_cursor.descend_to_existing_byte(v624_11_byte);
        {
        let v625_2: Space = singleton(&v620_10_cursor.path()[(v620_10_origin + 1)..(v620_10_origin + 2)]);
        let v625_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v625_2));
        drop(v625_2);
        let v625_4: Space = if map_kernels::has_head(&(v625_3)) { singleton(&[]) } else { Space::new() };
        drop(v625_3);
        let v625_6: Space = if (&(v625_4)).is_empty() { Space::new() } else {
          let mut v626_5 = Space::new();
          let mut v626_5_write = v626_5.write_zipper();
          for v626_5_byte in v620_10_cursor.child_mask().iter() {
            v620_10_cursor.descend_to_existing_byte(v626_5_byte);
            {
            let v627_2: Space = singleton(&v620_10_cursor.path()[(v620_10_origin + 2)..(v620_10_origin + 3)]);
            let v627_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v627_2));
            let v627_4: Space = if map_kernels::has_head(&(v627_3)) { singleton(&[]) } else { Space::new() };
            drop(v627_3);
            let v627_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v627_4));
            drop(v627_4);
            let v627_7: Space = if (&(v627_5)).is_empty() { Space::new() } else {
              let v628_6: Space = routine_10(c, &v620_10_cursor.path()[(v620_10_origin + 2)..(v620_10_origin + 3)], &v620_10_cursor, &(*s1));
              map_map_kernels::compose(&(v627_5),&(v628_6))
            };
            drop(v627_5);
            let v627_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v627_2));
            drop(v627_2);
            let v627_9: Space = if map_kernels::has_head(&(v627_8)) { singleton(&[]) } else { Space::new() };
            drop(v627_8);
            let v627_11: Space = if (&(v627_9)).is_empty() { Space::new() } else {
              let v629_10: Space = routine_11(c, &v620_10_cursor.path()[(v620_10_origin + 2)..(v620_10_origin + 3)], &v620_10_cursor, &(*s1));
              map_map_kernels::compose(&(v627_9),&(v629_10))
            };
            drop(v627_9);
            let v627_12: Space = map_map_kernels::unite(&(v627_7),&(v627_11));
            join_wrapped_into(&mut v626_5_write,&((v627_12).read_zipper()),&[]);
            }
            v620_10_cursor.ascend(1);
          }
          drop(v626_5_write);
          map_map_kernels::compose(&(v625_4),&(v626_5))
        };
        drop(v625_4);
        let v625_7: Path = concat_path(&(v624_10),&v620_10_cursor.path()[(v620_10_origin + 1)..(v620_10_origin + 2)]);
        join_wrapped_into(&mut v624_11_write,&((v625_6).read_zipper()),&(v625_7));
        drop(v625_7);
        }
        v620_10_cursor.ascend(1);
      }
      drop(v624_11_write);
      drop(v624_10);
      map_map_kernels::compose(&(v621_9),&(v624_11))
    };
    drop(v621_9);
    let v621_13: Space = map_map_kernels::unite(&(v621_7),&(v621_12));
    drop(v621_7);
    join_wrapped_into(&mut v620_10_write,&((v621_13).read_zipper()),&[]);
    }
    v620_10_cursor.ascend(1);
  }
  drop(v620_10_cursor);
  drop(v620_10_write);
  (v620_10).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v630_15 = Space::new();
  let mut v630_15_write = v630_15.write_zipper();
  let mut v630_15_cursor = (*s0).read_zipper();
  let v630_15_origin = v630_15_cursor.path().len();
  for v630_15_byte in v630_15_cursor.child_mask().iter() {
    v630_15_cursor.descend_to_existing_byte(v630_15_byte);
    {
    let v631_2: Space = singleton(&v630_15_cursor.path()[v630_15_origin..(v630_15_origin + 1)]);
    let v631_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v631_2));
    let v631_4: Space = if map_kernels::has_head(&(v631_3)) { singleton(&[]) } else { Space::new() };
    drop(v631_3);
    let v631_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v631_4));
    drop(v631_4);
    let v631_7: Space = if (&(v631_5)).is_empty() { Space::new() } else {
      let mut v632_6 = Space::new();
      let mut v632_6_write = v632_6.write_zipper();
      for v632_6_byte in v630_15_cursor.child_mask().iter() {
        v630_15_cursor.descend_to_existing_byte(v632_6_byte);
        {
        let v633_2: Space = Space::new();
        join_wrapped_into(&mut v632_6_write,&((v633_2).read_zipper()),&[]);
        }
        v630_15_cursor.ascend(1);
      }
      drop(v632_6_write);
      map_map_kernels::compose(&(v631_5),&(v632_6))
    };
    drop(v631_5);
    let v631_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v631_2));
    drop(v631_2);
    let v631_9: Space = if map_kernels::has_head(&(v631_8)) { singleton(&[]) } else { Space::new() };
    drop(v631_8);
    let v631_11: Space = if (&(v631_9)).is_empty() { Space::new() } else {
      let mut v634_10 = Space::new();
      let mut v634_10_write = v634_10.write_zipper();
      for v634_10_byte in v630_15_cursor.child_mask().iter() {
        v630_15_cursor.descend_to_existing_byte(v634_10_byte);
        {
        let v635_2: Space = singleton(&v630_15_cursor.path()[(v630_15_origin + 1)..(v630_15_origin + 2)]);
        let v635_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v635_2));
        let v635_4: Space = if map_kernels::has_head(&(v635_3)) { singleton(&[]) } else { Space::new() };
        drop(v635_3);
        let v635_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v635_4));
        drop(v635_4);
        let v635_7: Space = if (&(v635_5)).is_empty() { Space::new() } else {
          let mut v636_6 = Space::new();
          let mut v636_6_write = v636_6.write_zipper();
          for v636_6_byte in v630_15_cursor.child_mask().iter() {
            v630_15_cursor.descend_to_existing_byte(v636_6_byte);
            {
            let v637_2: Space = singleton(&v630_15_cursor.path()[(v630_15_origin + 2)..(v630_15_origin + 3)]);
            let v637_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v637_2));
            let v637_4: Space = if map_kernels::has_head(&(v637_3)) { singleton(&[]) } else { Space::new() };
            drop(v637_3);
            let v637_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v637_4));
            drop(v637_4);
            let v637_8: Space = if (&(v637_5)).is_empty() { Space::new() } else {
              let v638_7: Space = routine_31(c, &v630_15_cursor.path()[(v630_15_origin + 1)..(v630_15_origin + 3)], &v630_15_cursor, &(*s1));
              map_map_kernels::compose(&(v637_5),&(v638_7))
            };
            drop(v637_5);
            let v637_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v637_2));
            drop(v637_2);
            let v637_10: Space = if map_kernels::has_head(&(v637_9)) { singleton(&[]) } else { Space::new() };
            drop(v637_9);
            let v637_12: Space = if (&(v637_10)).is_empty() { Space::new() } else {
              let v639_11: Space = routine_32(c, &v630_15_cursor.path()[(v630_15_origin + 1)..(v630_15_origin + 3)], &v630_15_cursor, &(*s1));
              map_map_kernels::compose(&(v637_10),&(v639_11))
            };
            drop(v637_10);
            let v637_13: Space = map_map_kernels::unite(&(v637_8),&(v637_12));
            join_wrapped_into(&mut v636_6_write,&((v637_13).read_zipper()),&[]);
            }
            v630_15_cursor.ascend(1);
          }
          drop(v636_6_write);
          map_map_kernels::compose(&(v635_5),&(v636_6))
        };
        drop(v635_5);
        let v635_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v635_2));
        drop(v635_2);
        let v635_9: Space = if map_kernels::has_head(&(v635_8)) { singleton(&[]) } else { Space::new() };
        drop(v635_8);
        let v635_11: Space = if (&(v635_9)).is_empty() { Space::new() } else {
          let mut v640_10 = Space::new();
          let mut v640_10_write = v640_10.write_zipper();
          for v640_10_byte in v630_15_cursor.child_mask().iter() {
            v630_15_cursor.descend_to_existing_byte(v640_10_byte);
            {
            let v641_2: Space = singleton(&v630_15_cursor.path()[(v630_15_origin + 2)..(v630_15_origin + 3)]);
            let v641_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v641_2));
            let v641_4: Space = if map_kernels::has_head(&(v641_3)) { singleton(&[]) } else { Space::new() };
            drop(v641_3);
            let v641_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v641_4));
            drop(v641_4);
            let v641_8: Space = if (&(v641_5)).is_empty() { Space::new() } else {
              let v642_7: Space = routine_31(c, &v630_15_cursor.path()[(v630_15_origin + 1)..(v630_15_origin + 3)], &v630_15_cursor, &(*s1));
              map_map_kernels::compose(&(v641_5),&(v642_7))
            };
            drop(v641_5);
            let v641_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v641_2));
            drop(v641_2);
            let v641_10: Space = if map_kernels::has_head(&(v641_9)) { singleton(&[]) } else { Space::new() };
            drop(v641_9);
            let v641_12: Space = if (&(v641_10)).is_empty() { Space::new() } else {
              let v643_11: Space = routine_33(c, &v630_15_cursor.path()[(v630_15_origin + 1)..(v630_15_origin + 3)], &v630_15_cursor, &(*s1));
              map_map_kernels::compose(&(v641_10),&(v643_11))
            };
            drop(v641_10);
            let v641_13: Space = map_map_kernels::unite(&(v641_8),&(v641_12));
            join_wrapped_into(&mut v640_10_write,&((v641_13).read_zipper()),&[]);
            }
            v630_15_cursor.ascend(1);
          }
          drop(v640_10_write);
          map_map_kernels::compose(&(v635_9),&(v640_10))
        };
        drop(v635_9);
        let v635_12: Space = map_map_kernels::unite(&(v635_7),&(v635_11));
        join_wrapped_into(&mut v634_10_write,&((v635_12).read_zipper()),&[]);
        }
        v630_15_cursor.ascend(1);
      }
      drop(v634_10_write);
      map_map_kernels::compose(&(v631_9),&(v634_10))
    };
    drop(v631_9);
    let v631_12: Path = concat_path(&(*p0),&v630_15_cursor.path()[v630_15_origin..(v630_15_origin + 1)]);
    let v631_13: Space = map_kernels::wrap(&(v631_11),&(v631_12));
    drop(v631_12);
    let v631_14: Space = map_map_kernels::unite(&(v631_7),&(v631_13));
    drop(v631_7);
    join_wrapped_into(&mut v630_15_write,&((v631_14).read_zipper()),&[]);
    }
    v630_15_cursor.ascend(1);
  }
  drop(v630_15_cursor);
  drop(v630_15_write);
  (v630_15).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v644_27 = Space::new();
  let mut v644_27_write = v644_27.write_zipper();
  let mut v644_27_cursor = (*s0).read_zipper();
  let v644_27_origin = v644_27_cursor.path().len();
  for v644_27_byte in v644_27_cursor.child_mask().iter() {
    v644_27_cursor.descend_to_existing_byte(v644_27_byte);
    {
    let v645_2: Space = singleton(&v644_27_cursor.path()[v644_27_origin..(v644_27_origin + 1)]);
    let v645_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v645_2));
    let v645_4: Space = if map_kernels::has_head(&(v645_3)) { singleton(&[]) } else { Space::new() };
    drop(v645_3);
    let v645_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v645_4));
    drop(v645_4);
    let v645_8: Space = if (&(v645_5)).is_empty() { Space::new() } else {
      let v646_6: Path = concat_path(&(*p0),&v644_27_cursor.path()[v644_27_origin..(v644_27_origin + 1)]);
      let mut v646_7 = Space::new();
      let mut v646_7_write = v646_7.write_zipper();
      for v646_7_byte in v644_27_cursor.child_mask().iter() {
        v644_27_cursor.descend_to_existing_byte(v646_7_byte);
        {
        let v647_2: Space = singleton(&v644_27_cursor.path()[(v644_27_origin + 1)..(v644_27_origin + 2)]);
        let v647_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v647_2));
        let v647_4: Space = if map_kernels::has_head(&(v647_3)) { singleton(&[]) } else { Space::new() };
        drop(v647_3);
        let v647_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v647_4));
        drop(v647_4);
        let v647_8: Space = if (&(v647_5)).is_empty() { Space::new() } else {
          let v648_6: Path = concat_path(&(v646_6),&v644_27_cursor.path()[(v644_27_origin + 1)..(v644_27_origin + 2)]);
          let mut v648_7 = Space::new();
          let mut v648_7_write = v648_7.write_zipper();
          for v648_7_byte in v644_27_cursor.child_mask().iter() {
            v644_27_cursor.descend_to_existing_byte(v648_7_byte);
            {
            let v649_2: Space = singleton(&v644_27_cursor.path()[(v644_27_origin + 2)..(v644_27_origin + 3)]);
            let v649_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v649_2));
            let v649_4: Space = if map_kernels::has_head(&(v649_3)) { singleton(&[]) } else { Space::new() };
            drop(v649_3);
            let v649_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v649_4));
            drop(v649_4);
            let v649_8: Space = if (&(v649_5)).is_empty() { Space::new() } else {
              let v650_6: Path = concat_path(&(v648_6),&v644_27_cursor.path()[(v644_27_origin + 2)..(v644_27_origin + 3)]);
              let v650_7: Space = routine_55(c, &(v650_6), &v644_27_cursor, &(*s1));
              map_map_kernels::compose(&(v649_5),&(v650_7))
            };
            drop(v649_5);
            let v649_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v649_2));
            drop(v649_2);
            let v649_10: Space = if map_kernels::has_head(&(v649_9)) { singleton(&[]) } else { Space::new() };
            drop(v649_9);
            let v649_12: Space = if (&(v649_10)).is_empty() { Space::new() } else {
              let v651_6: Path = concat_path(&(v648_6),&v644_27_cursor.path()[(v644_27_origin + 2)..(v644_27_origin + 3)]);
              let v651_11: Space = routine_56(c, &(v651_6), &v644_27_cursor, &(*s1));
              drop(v651_6);
              map_map_kernels::compose(&(v649_10),&(v651_11))
            };
            drop(v649_10);
            let v649_13: Space = map_map_kernels::unite(&(v649_8),&(v649_12));
            join_wrapped_into(&mut v648_7_write,&((v649_13).read_zipper()),&[]);
            }
            v644_27_cursor.ascend(1);
          }
          drop(v648_7_write);
          map_map_kernels::compose(&(v647_5),&(v648_7))
        };
        drop(v647_5);
        let v647_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v647_2));
        drop(v647_2);
        let v647_10: Space = if map_kernels::has_head(&(v647_9)) { singleton(&[]) } else { Space::new() };
        drop(v647_9);
        let v647_12: Space = if (&(v647_10)).is_empty() { Space::new() } else {
          let v652_6: Path = concat_path(&(v646_6),&v644_27_cursor.path()[(v644_27_origin + 1)..(v644_27_origin + 2)]);
          let mut v652_11 = Space::new();
          let mut v652_11_write = v652_11.write_zipper();
          for v652_11_byte in v644_27_cursor.child_mask().iter() {
            v644_27_cursor.descend_to_existing_byte(v652_11_byte);
            {
            let v653_2: Space = singleton(&v644_27_cursor.path()[(v644_27_origin + 2)..(v644_27_origin + 3)]);
            let v653_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v653_2));
            let v653_4: Space = if map_kernels::has_head(&(v653_3)) { singleton(&[]) } else { Space::new() };
            drop(v653_3);
            let v653_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v653_4));
            drop(v653_4);
            let v653_8: Space = if (&(v653_5)).is_empty() { Space::new() } else {
              let v654_6: Path = concat_path(&(v652_6),&v644_27_cursor.path()[(v644_27_origin + 2)..(v644_27_origin + 3)]);
              let v654_7: Space = routine_55(c, &(v654_6), &v644_27_cursor, &(*s1));
              map_map_kernels::compose(&(v653_5),&(v654_7))
            };
            drop(v653_5);
            let v653_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v653_2));
            drop(v653_2);
            let v653_10: Space = if map_kernels::has_head(&(v653_9)) { singleton(&[]) } else { Space::new() };
            drop(v653_9);
            let v653_12: Space = if (&(v653_10)).is_empty() { Space::new() } else {
              let v655_6: Path = concat_path(&(v652_6),&v644_27_cursor.path()[(v644_27_origin + 2)..(v644_27_origin + 3)]);
              let v655_11: Space = routine_33(c, &(v655_6), &v644_27_cursor, &(*s1));
              drop(v655_6);
              map_map_kernels::compose(&(v653_10),&(v655_11))
            };
            drop(v653_10);
            let v653_13: Space = map_map_kernels::unite(&(v653_8),&(v653_12));
            join_wrapped_into(&mut v652_11_write,&((v653_13).read_zipper()),&[]);
            }
            v644_27_cursor.ascend(1);
          }
          drop(v652_11_write);
          drop(v652_6);
          map_map_kernels::compose(&(v647_10),&(v652_11))
        };
        drop(v647_10);
        let v647_13: Space = map_map_kernels::unite(&(v647_8),&(v647_12));
        join_wrapped_into(&mut v646_7_write,&((v647_13).read_zipper()),&[]);
        }
        v644_27_cursor.ascend(1);
      }
      drop(v646_7_write);
      map_map_kernels::compose(&(v645_5),&(v646_7))
    };
    drop(v645_5);
    let v645_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v645_2));
    drop(v645_2);
    let v645_10: Space = if map_kernels::has_head(&(v645_9)) { singleton(&[]) } else { Space::new() };
    drop(v645_9);
    let v645_13: Space = if (&(v645_10)).is_empty() { Space::new() } else {
      let v656_6: Path = concat_path(&(*p0),&v644_27_cursor.path()[v644_27_origin..(v644_27_origin + 1)]);
      let mut v656_12 = Space::new();
      let mut v656_12_write = v656_12.write_zipper();
      for v656_12_byte in v644_27_cursor.child_mask().iter() {
        v644_27_cursor.descend_to_existing_byte(v656_12_byte);
        {
        let v657_2: Space = singleton(&v644_27_cursor.path()[(v644_27_origin + 1)..(v644_27_origin + 2)]);
        let v657_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v657_2));
        let v657_4: Space = if map_kernels::has_head(&(v657_3)) { singleton(&[]) } else { Space::new() };
        drop(v657_3);
        let v657_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v657_4));
        drop(v657_4);
        let v657_8: Space = if (&(v657_5)).is_empty() { Space::new() } else {
          let v658_6: Path = concat_path(&(v656_6),&v644_27_cursor.path()[(v644_27_origin + 1)..(v644_27_origin + 2)]);
          let mut v658_7 = Space::new();
          let mut v658_7_write = v658_7.write_zipper();
          for v658_7_byte in v644_27_cursor.child_mask().iter() {
            v644_27_cursor.descend_to_existing_byte(v658_7_byte);
            {
            let v659_2: Space = singleton(&v644_27_cursor.path()[(v644_27_origin + 2)..(v644_27_origin + 3)]);
            let v659_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v659_2));
            let v659_4: Space = if map_kernels::has_head(&(v659_3)) { singleton(&[]) } else { Space::new() };
            drop(v659_3);
            let v659_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v659_4));
            drop(v659_4);
            let v659_8: Space = if (&(v659_5)).is_empty() { Space::new() } else {
              let v660_6: Path = concat_path(&(v658_6),&v644_27_cursor.path()[(v644_27_origin + 2)..(v644_27_origin + 3)]);
              let v660_7: Space = routine_55(c, &(v660_6), &v644_27_cursor, &(*s1));
              map_map_kernels::compose(&(v659_5),&(v660_7))
            };
            drop(v659_5);
            let v659_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v659_2));
            drop(v659_2);
            let v659_10: Space = if map_kernels::has_head(&(v659_9)) { singleton(&[]) } else { Space::new() };
            drop(v659_9);
            let v659_12: Space = if (&(v659_10)).is_empty() { Space::new() } else {
              let v661_6: Path = concat_path(&(v658_6),&v644_27_cursor.path()[(v644_27_origin + 2)..(v644_27_origin + 3)]);
              let v661_11: Space = routine_56(c, &(v661_6), &v644_27_cursor, &(*s1));
              drop(v661_6);
              map_map_kernels::compose(&(v659_10),&(v661_11))
            };
            drop(v659_10);
            let v659_13: Space = map_map_kernels::unite(&(v659_8),&(v659_12));
            join_wrapped_into(&mut v658_7_write,&((v659_13).read_zipper()),&[]);
            }
            v644_27_cursor.ascend(1);
          }
          drop(v658_7_write);
          drop(v658_6);
          map_map_kernels::compose(&(v657_5),&(v658_7))
        };
        drop(v657_5);
        let v657_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v657_2));
        drop(v657_2);
        let v657_10: Space = if map_kernels::has_head(&(v657_9)) { singleton(&[]) } else { Space::new() };
        drop(v657_9);
        let v657_13: Space = if (&(v657_10)).is_empty() { Space::new() } else {
          let v662_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v644_27_cursor.path()[v644_27_origin..(v644_27_origin + 1)]),&v644_27_cursor.path()[(v644_27_origin + 1)..(v644_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v657_10),&(v662_12))
        };
        drop(v657_10);
        let v657_14: Space = map_map_kernels::unite(&(v657_8),&(v657_13));
        drop(v657_13);
        join_wrapped_into(&mut v656_12_write,&((v657_14).read_zipper()),&[]);
        }
        v644_27_cursor.ascend(1);
      }
      drop(v656_12_write);
      drop(v656_6);
      map_map_kernels::compose(&(v645_10),&(v656_12))
    };
    drop(v645_10);
    let v645_14: Space = map_map_kernels::unite(&(v645_8),&(v645_13));
    join_wrapped_into(&mut v644_27_write,&((v645_14).read_zipper()),&[]);
    }
    v644_27_cursor.ascend(1);
  }
  drop(v644_27_cursor);
  drop(v644_27_write);
  (v644_27).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v663_21 = Space::new();
  let mut v663_21_write = v663_21.write_zipper();
  let mut v663_21_cursor = (*s0).read_zipper();
  let v663_21_origin = v663_21_cursor.path().len();
  for v663_21_byte in v663_21_cursor.child_mask().iter() {
    v663_21_cursor.descend_to_existing_byte(v663_21_byte);
    {
    let v664_2: Space = singleton(&v663_21_cursor.path()[v663_21_origin..(v663_21_origin + 1)]);
    let v664_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v664_2));
    let v664_4: Space = if map_kernels::has_head(&(v664_3)) { singleton(&[]) } else { Space::new() };
    drop(v664_3);
    let v664_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v664_4));
    drop(v664_4);
    let v664_8: Space = if (&(v664_5)).is_empty() { Space::new() } else {
      let v665_6: Path = concat_path(&(*p0),&v663_21_cursor.path()[v663_21_origin..(v663_21_origin + 1)]);
      let mut v665_7 = Space::new();
      let mut v665_7_write = v665_7.write_zipper();
      for v665_7_byte in v663_21_cursor.child_mask().iter() {
        v663_21_cursor.descend_to_existing_byte(v665_7_byte);
        {
        let v666_2: Space = singleton(&v663_21_cursor.path()[(v663_21_origin + 1)..(v663_21_origin + 2)]);
        let v666_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v666_2));
        let v666_4: Space = if map_kernels::has_head(&(v666_3)) { singleton(&[]) } else { Space::new() };
        drop(v666_3);
        let v666_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v666_4));
        drop(v666_4);
        let v666_8: Space = if (&(v666_5)).is_empty() { Space::new() } else {
          let v667_6: Path = concat_path(&(v665_6),&v663_21_cursor.path()[(v663_21_origin + 1)..(v663_21_origin + 2)]);
          let mut v667_7 = Space::new();
          let mut v667_7_write = v667_7.write_zipper();
          for v667_7_byte in v663_21_cursor.child_mask().iter() {
            v663_21_cursor.descend_to_existing_byte(v667_7_byte);
            {
            let v668_2: Space = singleton(&v663_21_cursor.path()[(v663_21_origin + 2)..(v663_21_origin + 3)]);
            let v668_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v668_2));
            let v668_4: Space = if map_kernels::has_head(&(v668_3)) { singleton(&[]) } else { Space::new() };
            drop(v668_3);
            let v668_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v668_4));
            drop(v668_4);
            let v668_8: Space = if (&(v668_5)).is_empty() { Space::new() } else {
              let v669_6: Path = concat_path(&(v667_6),&v663_21_cursor.path()[(v663_21_origin + 2)..(v663_21_origin + 3)]);
              let v669_7: Space = routine_55(c, &(v669_6), &v663_21_cursor, &(*s1));
              map_map_kernels::compose(&(v668_5),&(v669_7))
            };
            drop(v668_5);
            let v668_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v668_2));
            drop(v668_2);
            let v668_10: Space = if map_kernels::has_head(&(v668_9)) { singleton(&[]) } else { Space::new() };
            drop(v668_9);
            let v668_12: Space = if (&(v668_10)).is_empty() { Space::new() } else {
              let v670_6: Path = concat_path(&(v667_6),&v663_21_cursor.path()[(v663_21_origin + 2)..(v663_21_origin + 3)]);
              let v670_11: Space = routine_56(c, &(v670_6), &v663_21_cursor, &(*s1));
              drop(v670_6);
              map_map_kernels::compose(&(v668_10),&(v670_11))
            };
            drop(v668_10);
            let v668_13: Space = map_map_kernels::unite(&(v668_8),&(v668_12));
            join_wrapped_into(&mut v667_7_write,&((v668_13).read_zipper()),&[]);
            }
            v663_21_cursor.ascend(1);
          }
          drop(v667_7_write);
          map_map_kernels::compose(&(v666_5),&(v667_7))
        };
        drop(v666_5);
        let v666_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v666_2));
        drop(v666_2);
        let v666_10: Space = if map_kernels::has_head(&(v666_9)) { singleton(&[]) } else { Space::new() };
        drop(v666_9);
        let v666_12: Space = if (&(v666_10)).is_empty() { Space::new() } else {
          let v671_6: Path = concat_path(&(v665_6),&v663_21_cursor.path()[(v663_21_origin + 1)..(v663_21_origin + 2)]);
          let mut v671_11 = Space::new();
          let mut v671_11_write = v671_11.write_zipper();
          for v671_11_byte in v663_21_cursor.child_mask().iter() {
            v663_21_cursor.descend_to_existing_byte(v671_11_byte);
            {
            let v672_2: Space = singleton(&v663_21_cursor.path()[(v663_21_origin + 2)..(v663_21_origin + 3)]);
            let v672_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v672_2));
            let v672_4: Space = if map_kernels::has_head(&(v672_3)) { singleton(&[]) } else { Space::new() };
            drop(v672_3);
            let v672_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v672_4));
            drop(v672_4);
            let v672_8: Space = if (&(v672_5)).is_empty() { Space::new() } else {
              let v673_6: Path = concat_path(&(v671_6),&v663_21_cursor.path()[(v663_21_origin + 2)..(v663_21_origin + 3)]);
              let v673_7: Space = routine_55(c, &(v673_6), &v663_21_cursor, &(*s1));
              map_map_kernels::compose(&(v672_5),&(v673_7))
            };
            drop(v672_5);
            let v672_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v672_2));
            drop(v672_2);
            let v672_10: Space = if map_kernels::has_head(&(v672_9)) { singleton(&[]) } else { Space::new() };
            drop(v672_9);
            let v672_12: Space = if (&(v672_10)).is_empty() { Space::new() } else {
              let v674_6: Path = concat_path(&(v671_6),&v663_21_cursor.path()[(v663_21_origin + 2)..(v663_21_origin + 3)]);
              let v674_11: Space = routine_33(c, &(v674_6), &v663_21_cursor, &(*s1));
              drop(v674_6);
              map_map_kernels::compose(&(v672_10),&(v674_11))
            };
            drop(v672_10);
            let v672_13: Space = map_map_kernels::unite(&(v672_8),&(v672_12));
            join_wrapped_into(&mut v671_11_write,&((v672_13).read_zipper()),&[]);
            }
            v663_21_cursor.ascend(1);
          }
          drop(v671_11_write);
          drop(v671_6);
          map_map_kernels::compose(&(v666_10),&(v671_11))
        };
        drop(v666_10);
        let v666_13: Space = map_map_kernels::unite(&(v666_8),&(v666_12));
        join_wrapped_into(&mut v665_7_write,&((v666_13).read_zipper()),&[]);
        }
        v663_21_cursor.ascend(1);
      }
      drop(v665_7_write);
      drop(v665_6);
      map_map_kernels::compose(&(v664_5),&(v665_7))
    };
    drop(v664_5);
    let v664_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v664_2));
    drop(v664_2);
    let v664_10: Space = if map_kernels::has_head(&(v664_9)) { singleton(&[]) } else { Space::new() };
    drop(v664_9);
    let v664_13: Space = if (&(v664_10)).is_empty() { Space::new() } else {
      let v675_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v663_21_cursor.path()[v663_21_origin..(v663_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v664_10),&(v675_12))
    };
    drop(v664_10);
    let v664_14: Space = map_map_kernels::unite(&(v664_8),&(v664_13));
    drop(v664_13);
    join_wrapped_into(&mut v663_21_write,&((v664_14).read_zipper()),&[]);
    }
    v663_21_cursor.ascend(1);
  }
  drop(v663_21_cursor);
  drop(v663_21_write);
  (v663_21).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v676_9: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0))),&(*CONSTANT_5));
  (v676_9).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v677_27 = Space::new();
  let mut v677_27_write = v677_27.write_zipper();
  let mut v677_27_cursor = (*s0).read_zipper();
  let v677_27_origin = v677_27_cursor.path().len();
  for v677_27_byte in v677_27_cursor.child_mask().iter() {
    v677_27_cursor.descend_to_existing_byte(v677_27_byte);
    {
    let v678_2: Space = singleton(&v677_27_cursor.path()[v677_27_origin..(v677_27_origin + 1)]);
    let v678_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v678_2));
    let v678_4: Space = if map_kernels::has_head(&(v678_3)) { singleton(&[]) } else { Space::new() };
    drop(v678_3);
    let v678_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v678_4));
    drop(v678_4);
    let v678_8: Space = if (&(v678_5)).is_empty() { Space::new() } else {
      let v679_6: Path = concat_path(&(*p0),&v677_27_cursor.path()[v677_27_origin..(v677_27_origin + 1)]);
      let mut v679_7 = Space::new();
      let mut v679_7_write = v679_7.write_zipper();
      for v679_7_byte in v677_27_cursor.child_mask().iter() {
        v677_27_cursor.descend_to_existing_byte(v679_7_byte);
        {
        let v680_2: Space = singleton(&v677_27_cursor.path()[(v677_27_origin + 1)..(v677_27_origin + 2)]);
        let v680_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v680_2));
        let v680_4: Space = if map_kernels::has_head(&(v680_3)) { singleton(&[]) } else { Space::new() };
        drop(v680_3);
        let v680_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v680_4));
        drop(v680_4);
        let v680_8: Space = if (&(v680_5)).is_empty() { Space::new() } else {
          let v681_6: Path = concat_path(&(v679_6),&v677_27_cursor.path()[(v677_27_origin + 1)..(v677_27_origin + 2)]);
          let mut v681_7 = Space::new();
          let mut v681_7_write = v681_7.write_zipper();
          for v681_7_byte in v677_27_cursor.child_mask().iter() {
            v677_27_cursor.descend_to_existing_byte(v681_7_byte);
            {
            let v682_2: Space = singleton(&v677_27_cursor.path()[(v677_27_origin + 2)..(v677_27_origin + 3)]);
            let v682_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v682_2));
            let v682_4: Space = if map_kernels::has_head(&(v682_3)) { singleton(&[]) } else { Space::new() };
            drop(v682_3);
            let v682_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v682_4));
            drop(v682_4);
            let v682_8: Space = if (&(v682_5)).is_empty() { Space::new() } else {
              let v683_6: Path = concat_path(&(v681_6),&v677_27_cursor.path()[(v677_27_origin + 2)..(v677_27_origin + 3)]);
              let v683_7: Space = routine_57(c, &(v683_6), &v677_27_cursor, &(*s1));
              map_map_kernels::compose(&(v682_5),&(v683_7))
            };
            drop(v682_5);
            let v682_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v682_2));
            drop(v682_2);
            let v682_10: Space = if map_kernels::has_head(&(v682_9)) { singleton(&[]) } else { Space::new() };
            drop(v682_9);
            let v682_12: Space = if (&(v682_10)).is_empty() { Space::new() } else {
              let v684_6: Path = concat_path(&(v681_6),&v677_27_cursor.path()[(v677_27_origin + 2)..(v677_27_origin + 3)]);
              let v684_11: Space = routine_58(c, &(v684_6), &v677_27_cursor, &(*s1));
              drop(v684_6);
              map_map_kernels::compose(&(v682_10),&(v684_11))
            };
            drop(v682_10);
            let v682_13: Space = map_map_kernels::unite(&(v682_8),&(v682_12));
            join_wrapped_into(&mut v681_7_write,&((v682_13).read_zipper()),&[]);
            }
            v677_27_cursor.ascend(1);
          }
          drop(v681_7_write);
          map_map_kernels::compose(&(v680_5),&(v681_7))
        };
        drop(v680_5);
        let v680_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v680_2));
        drop(v680_2);
        let v680_10: Space = if map_kernels::has_head(&(v680_9)) { singleton(&[]) } else { Space::new() };
        drop(v680_9);
        let v680_12: Space = if (&(v680_10)).is_empty() { Space::new() } else {
          let v685_6: Path = concat_path(&(v679_6),&v677_27_cursor.path()[(v677_27_origin + 1)..(v677_27_origin + 2)]);
          let mut v685_11 = Space::new();
          let mut v685_11_write = v685_11.write_zipper();
          for v685_11_byte in v677_27_cursor.child_mask().iter() {
            v677_27_cursor.descend_to_existing_byte(v685_11_byte);
            {
            let v686_2: Space = singleton(&v677_27_cursor.path()[(v677_27_origin + 2)..(v677_27_origin + 3)]);
            let v686_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v686_2));
            let v686_4: Space = if map_kernels::has_head(&(v686_3)) { singleton(&[]) } else { Space::new() };
            drop(v686_3);
            let v686_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v686_4));
            drop(v686_4);
            let v686_8: Space = if (&(v686_5)).is_empty() { Space::new() } else {
              let v687_6: Path = concat_path(&(v685_6),&v677_27_cursor.path()[(v677_27_origin + 2)..(v677_27_origin + 3)]);
              let v687_7: Space = routine_57(c, &(v687_6), &v677_27_cursor, &(*s1));
              map_map_kernels::compose(&(v686_5),&(v687_7))
            };
            drop(v686_5);
            let v686_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v686_2));
            drop(v686_2);
            let v686_10: Space = if map_kernels::has_head(&(v686_9)) { singleton(&[]) } else { Space::new() };
            drop(v686_9);
            let v686_12: Space = if (&(v686_10)).is_empty() { Space::new() } else {
              let v688_6: Path = concat_path(&(v685_6),&v677_27_cursor.path()[(v677_27_origin + 2)..(v677_27_origin + 3)]);
              let v688_11: Space = routine_33(c, &(v688_6), &v677_27_cursor, &(*s1));
              drop(v688_6);
              map_map_kernels::compose(&(v686_10),&(v688_11))
            };
            drop(v686_10);
            let v686_13: Space = map_map_kernels::unite(&(v686_8),&(v686_12));
            join_wrapped_into(&mut v685_11_write,&((v686_13).read_zipper()),&[]);
            }
            v677_27_cursor.ascend(1);
          }
          drop(v685_11_write);
          drop(v685_6);
          map_map_kernels::compose(&(v680_10),&(v685_11))
        };
        drop(v680_10);
        let v680_13: Space = map_map_kernels::unite(&(v680_8),&(v680_12));
        join_wrapped_into(&mut v679_7_write,&((v680_13).read_zipper()),&[]);
        }
        v677_27_cursor.ascend(1);
      }
      drop(v679_7_write);
      map_map_kernels::compose(&(v678_5),&(v679_7))
    };
    drop(v678_5);
    let v678_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v678_2));
    drop(v678_2);
    let v678_10: Space = if map_kernels::has_head(&(v678_9)) { singleton(&[]) } else { Space::new() };
    drop(v678_9);
    let v678_13: Space = if (&(v678_10)).is_empty() { Space::new() } else {
      let v689_6: Path = concat_path(&(*p0),&v677_27_cursor.path()[v677_27_origin..(v677_27_origin + 1)]);
      let mut v689_12 = Space::new();
      let mut v689_12_write = v689_12.write_zipper();
      for v689_12_byte in v677_27_cursor.child_mask().iter() {
        v677_27_cursor.descend_to_existing_byte(v689_12_byte);
        {
        let v690_2: Space = singleton(&v677_27_cursor.path()[(v677_27_origin + 1)..(v677_27_origin + 2)]);
        let v690_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v690_2));
        let v690_4: Space = if map_kernels::has_head(&(v690_3)) { singleton(&[]) } else { Space::new() };
        drop(v690_3);
        let v690_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v690_4));
        drop(v690_4);
        let v690_8: Space = if (&(v690_5)).is_empty() { Space::new() } else {
          let v691_6: Path = concat_path(&(v689_6),&v677_27_cursor.path()[(v677_27_origin + 1)..(v677_27_origin + 2)]);
          let mut v691_7 = Space::new();
          let mut v691_7_write = v691_7.write_zipper();
          for v691_7_byte in v677_27_cursor.child_mask().iter() {
            v677_27_cursor.descend_to_existing_byte(v691_7_byte);
            {
            let v692_2: Space = singleton(&v677_27_cursor.path()[(v677_27_origin + 2)..(v677_27_origin + 3)]);
            let v692_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v692_2));
            let v692_4: Space = if map_kernels::has_head(&(v692_3)) { singleton(&[]) } else { Space::new() };
            drop(v692_3);
            let v692_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v692_4));
            drop(v692_4);
            let v692_8: Space = if (&(v692_5)).is_empty() { Space::new() } else {
              let v693_6: Path = concat_path(&(v691_6),&v677_27_cursor.path()[(v677_27_origin + 2)..(v677_27_origin + 3)]);
              let v693_7: Space = routine_57(c, &(v693_6), &v677_27_cursor, &(*s1));
              map_map_kernels::compose(&(v692_5),&(v693_7))
            };
            drop(v692_5);
            let v692_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v692_2));
            drop(v692_2);
            let v692_10: Space = if map_kernels::has_head(&(v692_9)) { singleton(&[]) } else { Space::new() };
            drop(v692_9);
            let v692_12: Space = if (&(v692_10)).is_empty() { Space::new() } else {
              let v694_6: Path = concat_path(&(v691_6),&v677_27_cursor.path()[(v677_27_origin + 2)..(v677_27_origin + 3)]);
              let v694_11: Space = routine_58(c, &(v694_6), &v677_27_cursor, &(*s1));
              drop(v694_6);
              map_map_kernels::compose(&(v692_10),&(v694_11))
            };
            drop(v692_10);
            let v692_13: Space = map_map_kernels::unite(&(v692_8),&(v692_12));
            join_wrapped_into(&mut v691_7_write,&((v692_13).read_zipper()),&[]);
            }
            v677_27_cursor.ascend(1);
          }
          drop(v691_7_write);
          drop(v691_6);
          map_map_kernels::compose(&(v690_5),&(v691_7))
        };
        drop(v690_5);
        let v690_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v690_2));
        drop(v690_2);
        let v690_10: Space = if map_kernels::has_head(&(v690_9)) { singleton(&[]) } else { Space::new() };
        drop(v690_9);
        let v690_13: Space = if (&(v690_10)).is_empty() { Space::new() } else {
          let v695_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v677_27_cursor.path()[v677_27_origin..(v677_27_origin + 1)]),&v677_27_cursor.path()[(v677_27_origin + 1)..(v677_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v690_10),&(v695_12))
        };
        drop(v690_10);
        let v690_14: Space = map_map_kernels::unite(&(v690_8),&(v690_13));
        drop(v690_13);
        join_wrapped_into(&mut v689_12_write,&((v690_14).read_zipper()),&[]);
        }
        v677_27_cursor.ascend(1);
      }
      drop(v689_12_write);
      drop(v689_6);
      map_map_kernels::compose(&(v678_10),&(v689_12))
    };
    drop(v678_10);
    let v678_14: Space = map_map_kernels::unite(&(v678_8),&(v678_13));
    join_wrapped_into(&mut v677_27_write,&((v678_14).read_zipper()),&[]);
    }
    v677_27_cursor.ascend(1);
  }
  drop(v677_27_cursor);
  drop(v677_27_write);
  (v677_27).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v696_21 = Space::new();
  let mut v696_21_write = v696_21.write_zipper();
  let mut v696_21_cursor = (*s0).read_zipper();
  let v696_21_origin = v696_21_cursor.path().len();
  for v696_21_byte in v696_21_cursor.child_mask().iter() {
    v696_21_cursor.descend_to_existing_byte(v696_21_byte);
    {
    let v697_2: Space = singleton(&v696_21_cursor.path()[v696_21_origin..(v696_21_origin + 1)]);
    let v697_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v697_2));
    let v697_4: Space = if map_kernels::has_head(&(v697_3)) { singleton(&[]) } else { Space::new() };
    drop(v697_3);
    let v697_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v697_4));
    drop(v697_4);
    let v697_8: Space = if (&(v697_5)).is_empty() { Space::new() } else {
      let v698_6: Path = concat_path(&(*p0),&v696_21_cursor.path()[v696_21_origin..(v696_21_origin + 1)]);
      let mut v698_7 = Space::new();
      let mut v698_7_write = v698_7.write_zipper();
      for v698_7_byte in v696_21_cursor.child_mask().iter() {
        v696_21_cursor.descend_to_existing_byte(v698_7_byte);
        {
        let v699_2: Space = singleton(&v696_21_cursor.path()[(v696_21_origin + 1)..(v696_21_origin + 2)]);
        let v699_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v699_2));
        let v699_4: Space = if map_kernels::has_head(&(v699_3)) { singleton(&[]) } else { Space::new() };
        drop(v699_3);
        let v699_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v699_4));
        drop(v699_4);
        let v699_8: Space = if (&(v699_5)).is_empty() { Space::new() } else {
          let v700_6: Path = concat_path(&(v698_6),&v696_21_cursor.path()[(v696_21_origin + 1)..(v696_21_origin + 2)]);
          let mut v700_7 = Space::new();
          let mut v700_7_write = v700_7.write_zipper();
          for v700_7_byte in v696_21_cursor.child_mask().iter() {
            v696_21_cursor.descend_to_existing_byte(v700_7_byte);
            {
            let v701_2: Space = singleton(&v696_21_cursor.path()[(v696_21_origin + 2)..(v696_21_origin + 3)]);
            let v701_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v701_2));
            let v701_4: Space = if map_kernels::has_head(&(v701_3)) { singleton(&[]) } else { Space::new() };
            drop(v701_3);
            let v701_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v701_4));
            drop(v701_4);
            let v701_8: Space = if (&(v701_5)).is_empty() { Space::new() } else {
              let v702_6: Path = concat_path(&(v700_6),&v696_21_cursor.path()[(v696_21_origin + 2)..(v696_21_origin + 3)]);
              let v702_7: Space = routine_57(c, &(v702_6), &v696_21_cursor, &(*s1));
              map_map_kernels::compose(&(v701_5),&(v702_7))
            };
            drop(v701_5);
            let v701_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v701_2));
            drop(v701_2);
            let v701_10: Space = if map_kernels::has_head(&(v701_9)) { singleton(&[]) } else { Space::new() };
            drop(v701_9);
            let v701_12: Space = if (&(v701_10)).is_empty() { Space::new() } else {
              let v703_6: Path = concat_path(&(v700_6),&v696_21_cursor.path()[(v696_21_origin + 2)..(v696_21_origin + 3)]);
              let v703_11: Space = routine_58(c, &(v703_6), &v696_21_cursor, &(*s1));
              drop(v703_6);
              map_map_kernels::compose(&(v701_10),&(v703_11))
            };
            drop(v701_10);
            let v701_13: Space = map_map_kernels::unite(&(v701_8),&(v701_12));
            join_wrapped_into(&mut v700_7_write,&((v701_13).read_zipper()),&[]);
            }
            v696_21_cursor.ascend(1);
          }
          drop(v700_7_write);
          map_map_kernels::compose(&(v699_5),&(v700_7))
        };
        drop(v699_5);
        let v699_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v699_2));
        drop(v699_2);
        let v699_10: Space = if map_kernels::has_head(&(v699_9)) { singleton(&[]) } else { Space::new() };
        drop(v699_9);
        let v699_12: Space = if (&(v699_10)).is_empty() { Space::new() } else {
          let v704_6: Path = concat_path(&(v698_6),&v696_21_cursor.path()[(v696_21_origin + 1)..(v696_21_origin + 2)]);
          let mut v704_11 = Space::new();
          let mut v704_11_write = v704_11.write_zipper();
          for v704_11_byte in v696_21_cursor.child_mask().iter() {
            v696_21_cursor.descend_to_existing_byte(v704_11_byte);
            {
            let v705_2: Space = singleton(&v696_21_cursor.path()[(v696_21_origin + 2)..(v696_21_origin + 3)]);
            let v705_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v705_2));
            let v705_4: Space = if map_kernels::has_head(&(v705_3)) { singleton(&[]) } else { Space::new() };
            drop(v705_3);
            let v705_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v705_4));
            drop(v705_4);
            let v705_8: Space = if (&(v705_5)).is_empty() { Space::new() } else {
              let v706_6: Path = concat_path(&(v704_6),&v696_21_cursor.path()[(v696_21_origin + 2)..(v696_21_origin + 3)]);
              let v706_7: Space = routine_57(c, &(v706_6), &v696_21_cursor, &(*s1));
              map_map_kernels::compose(&(v705_5),&(v706_7))
            };
            drop(v705_5);
            let v705_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v705_2));
            drop(v705_2);
            let v705_10: Space = if map_kernels::has_head(&(v705_9)) { singleton(&[]) } else { Space::new() };
            drop(v705_9);
            let v705_12: Space = if (&(v705_10)).is_empty() { Space::new() } else {
              let v707_6: Path = concat_path(&(v704_6),&v696_21_cursor.path()[(v696_21_origin + 2)..(v696_21_origin + 3)]);
              let v707_11: Space = routine_33(c, &(v707_6), &v696_21_cursor, &(*s1));
              drop(v707_6);
              map_map_kernels::compose(&(v705_10),&(v707_11))
            };
            drop(v705_10);
            let v705_13: Space = map_map_kernels::unite(&(v705_8),&(v705_12));
            join_wrapped_into(&mut v704_11_write,&((v705_13).read_zipper()),&[]);
            }
            v696_21_cursor.ascend(1);
          }
          drop(v704_11_write);
          drop(v704_6);
          map_map_kernels::compose(&(v699_10),&(v704_11))
        };
        drop(v699_10);
        let v699_13: Space = map_map_kernels::unite(&(v699_8),&(v699_12));
        join_wrapped_into(&mut v698_7_write,&((v699_13).read_zipper()),&[]);
        }
        v696_21_cursor.ascend(1);
      }
      drop(v698_7_write);
      drop(v698_6);
      map_map_kernels::compose(&(v697_5),&(v698_7))
    };
    drop(v697_5);
    let v697_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v697_2));
    drop(v697_2);
    let v697_10: Space = if map_kernels::has_head(&(v697_9)) { singleton(&[]) } else { Space::new() };
    drop(v697_9);
    let v697_13: Space = if (&(v697_10)).is_empty() { Space::new() } else {
      let v708_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v696_21_cursor.path()[v696_21_origin..(v696_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v697_10),&(v708_12))
    };
    drop(v697_10);
    let v697_14: Space = map_map_kernels::unite(&(v697_8),&(v697_13));
    drop(v697_13);
    join_wrapped_into(&mut v696_21_write,&((v697_14).read_zipper()),&[]);
    }
    v696_21_cursor.ascend(1);
  }
  drop(v696_21_cursor);
  drop(v696_21_write);
  (v696_21).clone()
}

fn routine_36(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v709_27 = Space::new();
  let mut v709_27_write = v709_27.write_zipper();
  let mut v709_27_cursor = (*s0).read_zipper();
  let v709_27_origin = v709_27_cursor.path().len();
  for v709_27_byte in v709_27_cursor.child_mask().iter() {
    v709_27_cursor.descend_to_existing_byte(v709_27_byte);
    {
    let v710_2: Space = singleton(&v709_27_cursor.path()[v709_27_origin..(v709_27_origin + 1)]);
    let v710_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v710_2));
    let v710_4: Space = if map_kernels::has_head(&(v710_3)) { singleton(&[]) } else { Space::new() };
    drop(v710_3);
    let v710_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v710_4));
    drop(v710_4);
    let v710_8: Space = if (&(v710_5)).is_empty() { Space::new() } else {
      let v711_6: Path = concat_path(&(*p0),&v709_27_cursor.path()[v709_27_origin..(v709_27_origin + 1)]);
      let mut v711_7 = Space::new();
      let mut v711_7_write = v711_7.write_zipper();
      for v711_7_byte in v709_27_cursor.child_mask().iter() {
        v709_27_cursor.descend_to_existing_byte(v711_7_byte);
        {
        let v712_2: Space = singleton(&v709_27_cursor.path()[(v709_27_origin + 1)..(v709_27_origin + 2)]);
        let v712_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v712_2));
        let v712_4: Space = if map_kernels::has_head(&(v712_3)) { singleton(&[]) } else { Space::new() };
        drop(v712_3);
        let v712_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v712_4));
        drop(v712_4);
        let v712_8: Space = if (&(v712_5)).is_empty() { Space::new() } else {
          let v713_6: Path = concat_path(&(v711_6),&v709_27_cursor.path()[(v709_27_origin + 1)..(v709_27_origin + 2)]);
          let mut v713_7 = Space::new();
          let mut v713_7_write = v713_7.write_zipper();
          for v713_7_byte in v709_27_cursor.child_mask().iter() {
            v709_27_cursor.descend_to_existing_byte(v713_7_byte);
            {
            let v714_2: Space = singleton(&v709_27_cursor.path()[(v709_27_origin + 2)..(v709_27_origin + 3)]);
            let v714_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v714_2));
            let v714_4: Space = if map_kernels::has_head(&(v714_3)) { singleton(&[]) } else { Space::new() };
            drop(v714_3);
            let v714_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v714_4));
            drop(v714_4);
            let v714_8: Space = if (&(v714_5)).is_empty() { Space::new() } else {
              let v715_6: Path = concat_path(&(v713_6),&v709_27_cursor.path()[(v709_27_origin + 2)..(v709_27_origin + 3)]);
              let v715_7: Space = routine_59(c, &(v715_6), &v709_27_cursor, &(*s1));
              map_map_kernels::compose(&(v714_5),&(v715_7))
            };
            drop(v714_5);
            let v714_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v714_2));
            drop(v714_2);
            let v714_10: Space = if map_kernels::has_head(&(v714_9)) { singleton(&[]) } else { Space::new() };
            drop(v714_9);
            let v714_12: Space = if (&(v714_10)).is_empty() { Space::new() } else {
              let v716_6: Path = concat_path(&(v713_6),&v709_27_cursor.path()[(v709_27_origin + 2)..(v709_27_origin + 3)]);
              let v716_11: Space = routine_60(c, &(v716_6), &v709_27_cursor, &(*s1));
              drop(v716_6);
              map_map_kernels::compose(&(v714_10),&(v716_11))
            };
            drop(v714_10);
            let v714_13: Space = map_map_kernels::unite(&(v714_8),&(v714_12));
            join_wrapped_into(&mut v713_7_write,&((v714_13).read_zipper()),&[]);
            }
            v709_27_cursor.ascend(1);
          }
          drop(v713_7_write);
          map_map_kernels::compose(&(v712_5),&(v713_7))
        };
        drop(v712_5);
        let v712_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v712_2));
        drop(v712_2);
        let v712_10: Space = if map_kernels::has_head(&(v712_9)) { singleton(&[]) } else { Space::new() };
        drop(v712_9);
        let v712_12: Space = if (&(v712_10)).is_empty() { Space::new() } else {
          let v717_6: Path = concat_path(&(v711_6),&v709_27_cursor.path()[(v709_27_origin + 1)..(v709_27_origin + 2)]);
          let mut v717_11 = Space::new();
          let mut v717_11_write = v717_11.write_zipper();
          for v717_11_byte in v709_27_cursor.child_mask().iter() {
            v709_27_cursor.descend_to_existing_byte(v717_11_byte);
            {
            let v718_2: Space = singleton(&v709_27_cursor.path()[(v709_27_origin + 2)..(v709_27_origin + 3)]);
            let v718_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v718_2));
            let v718_4: Space = if map_kernels::has_head(&(v718_3)) { singleton(&[]) } else { Space::new() };
            drop(v718_3);
            let v718_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v718_4));
            drop(v718_4);
            let v718_8: Space = if (&(v718_5)).is_empty() { Space::new() } else {
              let v719_6: Path = concat_path(&(v717_6),&v709_27_cursor.path()[(v709_27_origin + 2)..(v709_27_origin + 3)]);
              let v719_7: Space = routine_59(c, &(v719_6), &v709_27_cursor, &(*s1));
              map_map_kernels::compose(&(v718_5),&(v719_7))
            };
            drop(v718_5);
            let v718_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v718_2));
            drop(v718_2);
            let v718_10: Space = if map_kernels::has_head(&(v718_9)) { singleton(&[]) } else { Space::new() };
            drop(v718_9);
            let v718_12: Space = if (&(v718_10)).is_empty() { Space::new() } else {
              let v720_6: Path = concat_path(&(v717_6),&v709_27_cursor.path()[(v709_27_origin + 2)..(v709_27_origin + 3)]);
              let v720_11: Space = routine_33(c, &(v720_6), &v709_27_cursor, &(*s1));
              drop(v720_6);
              map_map_kernels::compose(&(v718_10),&(v720_11))
            };
            drop(v718_10);
            let v718_13: Space = map_map_kernels::unite(&(v718_8),&(v718_12));
            join_wrapped_into(&mut v717_11_write,&((v718_13).read_zipper()),&[]);
            }
            v709_27_cursor.ascend(1);
          }
          drop(v717_11_write);
          drop(v717_6);
          map_map_kernels::compose(&(v712_10),&(v717_11))
        };
        drop(v712_10);
        let v712_13: Space = map_map_kernels::unite(&(v712_8),&(v712_12));
        join_wrapped_into(&mut v711_7_write,&((v712_13).read_zipper()),&[]);
        }
        v709_27_cursor.ascend(1);
      }
      drop(v711_7_write);
      map_map_kernels::compose(&(v710_5),&(v711_7))
    };
    drop(v710_5);
    let v710_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v710_2));
    drop(v710_2);
    let v710_10: Space = if map_kernels::has_head(&(v710_9)) { singleton(&[]) } else { Space::new() };
    drop(v710_9);
    let v710_13: Space = if (&(v710_10)).is_empty() { Space::new() } else {
      let v721_6: Path = concat_path(&(*p0),&v709_27_cursor.path()[v709_27_origin..(v709_27_origin + 1)]);
      let mut v721_12 = Space::new();
      let mut v721_12_write = v721_12.write_zipper();
      for v721_12_byte in v709_27_cursor.child_mask().iter() {
        v709_27_cursor.descend_to_existing_byte(v721_12_byte);
        {
        let v722_2: Space = singleton(&v709_27_cursor.path()[(v709_27_origin + 1)..(v709_27_origin + 2)]);
        let v722_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v722_2));
        let v722_4: Space = if map_kernels::has_head(&(v722_3)) { singleton(&[]) } else { Space::new() };
        drop(v722_3);
        let v722_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v722_4));
        drop(v722_4);
        let v722_8: Space = if (&(v722_5)).is_empty() { Space::new() } else {
          let v723_6: Path = concat_path(&(v721_6),&v709_27_cursor.path()[(v709_27_origin + 1)..(v709_27_origin + 2)]);
          let mut v723_7 = Space::new();
          let mut v723_7_write = v723_7.write_zipper();
          for v723_7_byte in v709_27_cursor.child_mask().iter() {
            v709_27_cursor.descend_to_existing_byte(v723_7_byte);
            {
            let v724_2: Space = singleton(&v709_27_cursor.path()[(v709_27_origin + 2)..(v709_27_origin + 3)]);
            let v724_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v724_2));
            let v724_4: Space = if map_kernels::has_head(&(v724_3)) { singleton(&[]) } else { Space::new() };
            drop(v724_3);
            let v724_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v724_4));
            drop(v724_4);
            let v724_8: Space = if (&(v724_5)).is_empty() { Space::new() } else {
              let v725_6: Path = concat_path(&(v723_6),&v709_27_cursor.path()[(v709_27_origin + 2)..(v709_27_origin + 3)]);
              let v725_7: Space = routine_59(c, &(v725_6), &v709_27_cursor, &(*s1));
              map_map_kernels::compose(&(v724_5),&(v725_7))
            };
            drop(v724_5);
            let v724_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v724_2));
            drop(v724_2);
            let v724_10: Space = if map_kernels::has_head(&(v724_9)) { singleton(&[]) } else { Space::new() };
            drop(v724_9);
            let v724_12: Space = if (&(v724_10)).is_empty() { Space::new() } else {
              let v726_6: Path = concat_path(&(v723_6),&v709_27_cursor.path()[(v709_27_origin + 2)..(v709_27_origin + 3)]);
              let v726_11: Space = routine_60(c, &(v726_6), &v709_27_cursor, &(*s1));
              drop(v726_6);
              map_map_kernels::compose(&(v724_10),&(v726_11))
            };
            drop(v724_10);
            let v724_13: Space = map_map_kernels::unite(&(v724_8),&(v724_12));
            join_wrapped_into(&mut v723_7_write,&((v724_13).read_zipper()),&[]);
            }
            v709_27_cursor.ascend(1);
          }
          drop(v723_7_write);
          drop(v723_6);
          map_map_kernels::compose(&(v722_5),&(v723_7))
        };
        drop(v722_5);
        let v722_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v722_2));
        drop(v722_2);
        let v722_10: Space = if map_kernels::has_head(&(v722_9)) { singleton(&[]) } else { Space::new() };
        drop(v722_9);
        let v722_13: Space = if (&(v722_10)).is_empty() { Space::new() } else {
          let v727_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v709_27_cursor.path()[v709_27_origin..(v709_27_origin + 1)]),&v709_27_cursor.path()[(v709_27_origin + 1)..(v709_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v722_10),&(v727_12))
        };
        drop(v722_10);
        let v722_14: Space = map_map_kernels::unite(&(v722_8),&(v722_13));
        drop(v722_13);
        join_wrapped_into(&mut v721_12_write,&((v722_14).read_zipper()),&[]);
        }
        v709_27_cursor.ascend(1);
      }
      drop(v721_12_write);
      drop(v721_6);
      map_map_kernels::compose(&(v710_10),&(v721_12))
    };
    drop(v710_10);
    let v710_14: Space = map_map_kernels::unite(&(v710_8),&(v710_13));
    join_wrapped_into(&mut v709_27_write,&((v710_14).read_zipper()),&[]);
    }
    v709_27_cursor.ascend(1);
  }
  drop(v709_27_cursor);
  drop(v709_27_write);
  (v709_27).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v728_21 = Space::new();
  let mut v728_21_write = v728_21.write_zipper();
  let mut v728_21_cursor = (*s0).read_zipper();
  let v728_21_origin = v728_21_cursor.path().len();
  for v728_21_byte in v728_21_cursor.child_mask().iter() {
    v728_21_cursor.descend_to_existing_byte(v728_21_byte);
    {
    let v729_2: Space = singleton(&v728_21_cursor.path()[v728_21_origin..(v728_21_origin + 1)]);
    let v729_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v729_2));
    let v729_4: Space = if map_kernels::has_head(&(v729_3)) { singleton(&[]) } else { Space::new() };
    drop(v729_3);
    let v729_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v729_4));
    drop(v729_4);
    let v729_8: Space = if (&(v729_5)).is_empty() { Space::new() } else {
      let v730_6: Path = concat_path(&(*p0),&v728_21_cursor.path()[v728_21_origin..(v728_21_origin + 1)]);
      let mut v730_7 = Space::new();
      let mut v730_7_write = v730_7.write_zipper();
      for v730_7_byte in v728_21_cursor.child_mask().iter() {
        v728_21_cursor.descend_to_existing_byte(v730_7_byte);
        {
        let v731_2: Space = singleton(&v728_21_cursor.path()[(v728_21_origin + 1)..(v728_21_origin + 2)]);
        let v731_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v731_2));
        let v731_4: Space = if map_kernels::has_head(&(v731_3)) { singleton(&[]) } else { Space::new() };
        drop(v731_3);
        let v731_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v731_4));
        drop(v731_4);
        let v731_8: Space = if (&(v731_5)).is_empty() { Space::new() } else {
          let v732_6: Path = concat_path(&(v730_6),&v728_21_cursor.path()[(v728_21_origin + 1)..(v728_21_origin + 2)]);
          let mut v732_7 = Space::new();
          let mut v732_7_write = v732_7.write_zipper();
          for v732_7_byte in v728_21_cursor.child_mask().iter() {
            v728_21_cursor.descend_to_existing_byte(v732_7_byte);
            {
            let v733_2: Space = singleton(&v728_21_cursor.path()[(v728_21_origin + 2)..(v728_21_origin + 3)]);
            let v733_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v733_2));
            let v733_4: Space = if map_kernels::has_head(&(v733_3)) { singleton(&[]) } else { Space::new() };
            drop(v733_3);
            let v733_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v733_4));
            drop(v733_4);
            let v733_8: Space = if (&(v733_5)).is_empty() { Space::new() } else {
              let v734_6: Path = concat_path(&(v732_6),&v728_21_cursor.path()[(v728_21_origin + 2)..(v728_21_origin + 3)]);
              let v734_7: Space = routine_59(c, &(v734_6), &v728_21_cursor, &(*s1));
              map_map_kernels::compose(&(v733_5),&(v734_7))
            };
            drop(v733_5);
            let v733_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v733_2));
            drop(v733_2);
            let v733_10: Space = if map_kernels::has_head(&(v733_9)) { singleton(&[]) } else { Space::new() };
            drop(v733_9);
            let v733_12: Space = if (&(v733_10)).is_empty() { Space::new() } else {
              let v735_6: Path = concat_path(&(v732_6),&v728_21_cursor.path()[(v728_21_origin + 2)..(v728_21_origin + 3)]);
              let v735_11: Space = routine_60(c, &(v735_6), &v728_21_cursor, &(*s1));
              drop(v735_6);
              map_map_kernels::compose(&(v733_10),&(v735_11))
            };
            drop(v733_10);
            let v733_13: Space = map_map_kernels::unite(&(v733_8),&(v733_12));
            join_wrapped_into(&mut v732_7_write,&((v733_13).read_zipper()),&[]);
            }
            v728_21_cursor.ascend(1);
          }
          drop(v732_7_write);
          map_map_kernels::compose(&(v731_5),&(v732_7))
        };
        drop(v731_5);
        let v731_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v731_2));
        drop(v731_2);
        let v731_10: Space = if map_kernels::has_head(&(v731_9)) { singleton(&[]) } else { Space::new() };
        drop(v731_9);
        let v731_12: Space = if (&(v731_10)).is_empty() { Space::new() } else {
          let v736_6: Path = concat_path(&(v730_6),&v728_21_cursor.path()[(v728_21_origin + 1)..(v728_21_origin + 2)]);
          let mut v736_11 = Space::new();
          let mut v736_11_write = v736_11.write_zipper();
          for v736_11_byte in v728_21_cursor.child_mask().iter() {
            v728_21_cursor.descend_to_existing_byte(v736_11_byte);
            {
            let v737_2: Space = singleton(&v728_21_cursor.path()[(v728_21_origin + 2)..(v728_21_origin + 3)]);
            let v737_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v737_2));
            let v737_4: Space = if map_kernels::has_head(&(v737_3)) { singleton(&[]) } else { Space::new() };
            drop(v737_3);
            let v737_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v737_4));
            drop(v737_4);
            let v737_8: Space = if (&(v737_5)).is_empty() { Space::new() } else {
              let v738_6: Path = concat_path(&(v736_6),&v728_21_cursor.path()[(v728_21_origin + 2)..(v728_21_origin + 3)]);
              let v738_7: Space = routine_59(c, &(v738_6), &v728_21_cursor, &(*s1));
              map_map_kernels::compose(&(v737_5),&(v738_7))
            };
            drop(v737_5);
            let v737_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v737_2));
            drop(v737_2);
            let v737_10: Space = if map_kernels::has_head(&(v737_9)) { singleton(&[]) } else { Space::new() };
            drop(v737_9);
            let v737_12: Space = if (&(v737_10)).is_empty() { Space::new() } else {
              let v739_6: Path = concat_path(&(v736_6),&v728_21_cursor.path()[(v728_21_origin + 2)..(v728_21_origin + 3)]);
              let v739_11: Space = routine_33(c, &(v739_6), &v728_21_cursor, &(*s1));
              drop(v739_6);
              map_map_kernels::compose(&(v737_10),&(v739_11))
            };
            drop(v737_10);
            let v737_13: Space = map_map_kernels::unite(&(v737_8),&(v737_12));
            join_wrapped_into(&mut v736_11_write,&((v737_13).read_zipper()),&[]);
            }
            v728_21_cursor.ascend(1);
          }
          drop(v736_11_write);
          drop(v736_6);
          map_map_kernels::compose(&(v731_10),&(v736_11))
        };
        drop(v731_10);
        let v731_13: Space = map_map_kernels::unite(&(v731_8),&(v731_12));
        join_wrapped_into(&mut v730_7_write,&((v731_13).read_zipper()),&[]);
        }
        v728_21_cursor.ascend(1);
      }
      drop(v730_7_write);
      drop(v730_6);
      map_map_kernels::compose(&(v729_5),&(v730_7))
    };
    drop(v729_5);
    let v729_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v729_2));
    drop(v729_2);
    let v729_10: Space = if map_kernels::has_head(&(v729_9)) { singleton(&[]) } else { Space::new() };
    drop(v729_9);
    let v729_13: Space = if (&(v729_10)).is_empty() { Space::new() } else {
      let v740_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v728_21_cursor.path()[v728_21_origin..(v728_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v729_10),&(v740_12))
    };
    drop(v729_10);
    let v729_14: Space = map_map_kernels::unite(&(v729_8),&(v729_13));
    drop(v729_13);
    join_wrapped_into(&mut v728_21_write,&((v729_14).read_zipper()),&[]);
    }
    v728_21_cursor.ascend(1);
  }
  drop(v728_21_cursor);
  drop(v728_21_write);
  (v728_21).clone()
}

fn routine_38(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v741_7 = Space::new();
  let mut v741_7_write = v741_7.write_zipper();
  let mut v741_7_cursor = (*s0).read_zipper();
  let v741_7_origin = v741_7_cursor.path().len();
  for v741_7_byte in v741_7_cursor.child_mask().iter() {
    v741_7_cursor.descend_to_existing_byte(v741_7_byte);
    {
    let v742_2: Space = singleton(&v741_7_cursor.path()[v741_7_origin..(v741_7_origin + 1)]);
    let v742_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v742_2));
    let v742_4: Space = if map_kernels::has_head(&(v742_3)) { singleton(&[]) } else { Space::new() };
    drop(v742_3);
    let v742_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v742_4));
    drop(v742_4);
    let v742_7: Space = if (&(v742_5)).is_empty() { Space::new() } else {
      let mut v743_6 = Space::new();
      let mut v743_6_write = v743_6.write_zipper();
      for v743_6_byte in v741_7_cursor.child_mask().iter() {
        v741_7_cursor.descend_to_existing_byte(v743_6_byte);
        {
        let v744_2: Space = Space::new();
        join_wrapped_into(&mut v743_6_write,&((v744_2).read_zipper()),&[]);
        }
        v741_7_cursor.ascend(1);
      }
      drop(v743_6_write);
      map_map_kernels::compose(&(v742_5),&(v743_6))
    };
    drop(v742_5);
    let v742_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v742_2));
    drop(v742_2);
    let v742_9: Space = if map_kernels::has_head(&(v742_8)) { singleton(&[]) } else { Space::new() };
    drop(v742_8);
    let v742_12: Space = if (&(v742_9)).is_empty() { Space::new() } else {
      let v745_10: Path = concat_path(&(*p0),&v741_7_cursor.path()[v741_7_origin..(v741_7_origin + 1)]);
      let mut v745_11 = Space::new();
      let mut v745_11_write = v745_11.write_zipper();
      for v745_11_byte in v741_7_cursor.child_mask().iter() {
        v741_7_cursor.descend_to_existing_byte(v745_11_byte);
        {
        let v746_2: Space = singleton(&v741_7_cursor.path()[(v741_7_origin + 1)..(v741_7_origin + 2)]);
        let v746_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v746_2));
        drop(v746_2);
        let v746_4: Space = if map_kernels::has_head(&(v746_3)) { singleton(&[]) } else { Space::new() };
        drop(v746_3);
        let v746_6: Space = if (&(v746_4)).is_empty() { Space::new() } else {
          let v747_5: Space = view_map_kernels::subtract(&v741_7_cursor,&(*CONSTANT_5));
          map_map_kernels::compose(&(v746_4),&(v747_5))
        };
        drop(v746_4);
        let v746_7: Path = concat_path(&(v745_10),&v741_7_cursor.path()[(v741_7_origin + 1)..(v741_7_origin + 2)]);
        join_wrapped_into(&mut v745_11_write,&((v746_6).read_zipper()),&(v746_7));
        drop(v746_6);
        drop(v746_7);
        }
        v741_7_cursor.ascend(1);
      }
      drop(v745_11_write);
      drop(v745_10);
      map_map_kernels::compose(&(v742_9),&(v745_11))
    };
    drop(v742_9);
    let v742_13: Space = map_map_kernels::unite(&(v742_7),&(v742_12));
    drop(v742_7);
    drop(v742_12);
    join_wrapped_into(&mut v741_7_write,&((v742_13).read_zipper()),&[]);
    }
    v741_7_cursor.ascend(1);
  }
  drop(v741_7_cursor);
  drop(v741_7_write);
  (v741_7).clone()
}

fn routine_39(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v748_6 = Space::new();
  let mut v748_6_write = v748_6.write_zipper();
  let mut v748_6_cursor = (*s0).read_zipper();
  let v748_6_origin = v748_6_cursor.path().len();
  for v748_6_byte in v748_6_cursor.child_mask().iter() {
    v748_6_cursor.descend_to_existing_byte(v748_6_byte);
    {
    let v749_2: Space = singleton(&v748_6_cursor.path()[v748_6_origin..(v748_6_origin + 1)]);
    let v749_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v749_2));
    let v749_4: Space = if map_kernels::has_head(&(v749_3)) { singleton(&[]) } else { Space::new() };
    drop(v749_3);
    let v749_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v749_4));
    drop(v749_4);
    let v749_7: Space = if (&(v749_5)).is_empty() { Space::new() } else {
      let mut v750_6 = Space::new();
      let mut v750_6_write = v750_6.write_zipper();
      for v750_6_byte in v748_6_cursor.child_mask().iter() {
        v748_6_cursor.descend_to_existing_byte(v750_6_byte);
        {
        let v751_2: Space = Space::new();
        join_wrapped_into(&mut v750_6_write,&((v751_2).read_zipper()),&[]);
        }
        v748_6_cursor.ascend(1);
      }
      drop(v750_6_write);
      map_map_kernels::compose(&(v749_5),&(v750_6))
    };
    drop(v749_5);
    let v749_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v749_2));
    drop(v749_2);
    let v749_9: Space = if map_kernels::has_head(&(v749_8)) { singleton(&[]) } else { Space::new() };
    drop(v749_8);
    let v749_11: Space = if (&(v749_9)).is_empty() { Space::new() } else {
      let v752_10: Space = view_map_kernels::subtract(&v748_6_cursor,&(*CONSTANT_5));
      map_map_kernels::compose(&(v749_9),&(v752_10))
    };
    drop(v749_9);
    let v749_12: Path = concat_path(&(*p0),&v748_6_cursor.path()[v748_6_origin..(v748_6_origin + 1)]);
    let v749_13: Space = map_kernels::wrap(&(v749_11),&(v749_12));
    drop(v749_11);
    drop(v749_12);
    let v749_14: Space = map_map_kernels::unite(&(v749_7),&(v749_13));
    drop(v749_7);
    drop(v749_13);
    join_wrapped_into(&mut v748_6_write,&((v749_14).read_zipper()),&[]);
    }
    v748_6_cursor.ascend(1);
  }
  drop(v748_6_cursor);
  drop(v748_6_write);
  (v748_6).clone()
}

fn routine_40(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v753_10 = Space::new();
  let mut v753_10_write = v753_10.write_zipper();
  let mut v753_10_cursor = (*s0).read_zipper();
  let v753_10_origin = v753_10_cursor.path().len();
  for v753_10_byte in v753_10_cursor.child_mask().iter() {
    v753_10_cursor.descend_to_existing_byte(v753_10_byte);
    {
    let v754_2: Space = singleton(&v753_10_cursor.path()[v753_10_origin..(v753_10_origin + 1)]);
    let v754_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v754_2));
    let v754_4: Space = if map_kernels::has_head(&(v754_3)) { singleton(&[]) } else { Space::new() };
    drop(v754_3);
    let v754_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v754_4));
    drop(v754_4);
    let v754_7: Space = if (&(v754_5)).is_empty() { Space::new() } else {
      let mut v755_6 = Space::new();
      let mut v755_6_write = v755_6.write_zipper();
      for v755_6_byte in v753_10_cursor.child_mask().iter() {
        v753_10_cursor.descend_to_existing_byte(v755_6_byte);
        {
        let v756_2: Space = Space::new();
        join_wrapped_into(&mut v755_6_write,&((v756_2).read_zipper()),&[]);
        }
        v753_10_cursor.ascend(1);
      }
      drop(v755_6_write);
      map_map_kernels::compose(&(v754_5),&(v755_6))
    };
    drop(v754_5);
    let v754_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v754_2));
    drop(v754_2);
    let v754_9: Space = if map_kernels::has_head(&(v754_8)) { singleton(&[]) } else { Space::new() };
    drop(v754_8);
    let v754_12: Space = if (&(v754_9)).is_empty() { Space::new() } else {
      let v757_10: Path = concat_path(&(*p0),&v753_10_cursor.path()[v753_10_origin..(v753_10_origin + 1)]);
      let mut v757_11 = Space::new();
      let mut v757_11_write = v757_11.write_zipper();
      for v757_11_byte in v753_10_cursor.child_mask().iter() {
        v753_10_cursor.descend_to_existing_byte(v757_11_byte);
        {
        let v758_2: Space = singleton(&v753_10_cursor.path()[(v753_10_origin + 1)..(v753_10_origin + 2)]);
        let v758_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v758_2));
        drop(v758_2);
        let v758_4: Space = if map_kernels::has_head(&(v758_3)) { singleton(&[]) } else { Space::new() };
        drop(v758_3);
        let v758_6: Space = if (&(v758_4)).is_empty() { Space::new() } else {
          let mut v759_5 = Space::new();
          let mut v759_5_write = v759_5.write_zipper();
          for v759_5_byte in v753_10_cursor.child_mask().iter() {
            v753_10_cursor.descend_to_existing_byte(v759_5_byte);
            {
            let v760_2: Space = singleton(&v753_10_cursor.path()[(v753_10_origin + 2)..(v753_10_origin + 3)]);
            let v760_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v760_2));
            let v760_4: Space = if map_kernels::has_head(&(v760_3)) { singleton(&[]) } else { Space::new() };
            drop(v760_3);
            let v760_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v760_4));
            drop(v760_4);
            let v760_7: Space = if (&(v760_5)).is_empty() { Space::new() } else {
              let v761_6: Space = routine_18(c, &v753_10_cursor.path()[(v753_10_origin + 2)..(v753_10_origin + 3)], &v753_10_cursor, &(*s1));
              map_map_kernels::compose(&(v760_5),&(v761_6))
            };
            drop(v760_5);
            let v760_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v760_2));
            drop(v760_2);
            let v760_9: Space = if map_kernels::has_head(&(v760_8)) { singleton(&[]) } else { Space::new() };
            drop(v760_8);
            let v760_11: Space = if (&(v760_9)).is_empty() { Space::new() } else {
              let v762_10: Space = routine_19(c, &v753_10_cursor.path()[(v753_10_origin + 2)..(v753_10_origin + 3)], &v753_10_cursor, &(*s1));
              map_map_kernels::compose(&(v760_9),&(v762_10))
            };
            drop(v760_9);
            let v760_12: Space = map_map_kernels::unite(&(v760_7),&(v760_11));
            join_wrapped_into(&mut v759_5_write,&((v760_12).read_zipper()),&[]);
            }
            v753_10_cursor.ascend(1);
          }
          drop(v759_5_write);
          map_map_kernels::compose(&(v758_4),&(v759_5))
        };
        drop(v758_4);
        let v758_7: Path = concat_path(&(v757_10),&v753_10_cursor.path()[(v753_10_origin + 1)..(v753_10_origin + 2)]);
        join_wrapped_into(&mut v757_11_write,&((v758_6).read_zipper()),&(v758_7));
        drop(v758_7);
        }
        v753_10_cursor.ascend(1);
      }
      drop(v757_11_write);
      drop(v757_10);
      map_map_kernels::compose(&(v754_9),&(v757_11))
    };
    drop(v754_9);
    let v754_13: Space = map_map_kernels::unite(&(v754_7),&(v754_12));
    drop(v754_7);
    join_wrapped_into(&mut v753_10_write,&((v754_13).read_zipper()),&[]);
    }
    v753_10_cursor.ascend(1);
  }
  drop(v753_10_cursor);
  drop(v753_10_write);
  (v753_10).clone()
}

fn routine_41(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v763_15 = Space::new();
  let mut v763_15_write = v763_15.write_zipper();
  let mut v763_15_cursor = (*s0).read_zipper();
  let v763_15_origin = v763_15_cursor.path().len();
  for v763_15_byte in v763_15_cursor.child_mask().iter() {
    v763_15_cursor.descend_to_existing_byte(v763_15_byte);
    {
    let v764_2: Space = singleton(&v763_15_cursor.path()[v763_15_origin..(v763_15_origin + 1)]);
    let v764_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v764_2));
    let v764_4: Space = if map_kernels::has_head(&(v764_3)) { singleton(&[]) } else { Space::new() };
    drop(v764_3);
    let v764_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v764_4));
    drop(v764_4);
    let v764_7: Space = if (&(v764_5)).is_empty() { Space::new() } else {
      let mut v765_6 = Space::new();
      let mut v765_6_write = v765_6.write_zipper();
      for v765_6_byte in v763_15_cursor.child_mask().iter() {
        v763_15_cursor.descend_to_existing_byte(v765_6_byte);
        {
        let v766_2: Space = Space::new();
        join_wrapped_into(&mut v765_6_write,&((v766_2).read_zipper()),&[]);
        }
        v763_15_cursor.ascend(1);
      }
      drop(v765_6_write);
      map_map_kernels::compose(&(v764_5),&(v765_6))
    };
    drop(v764_5);
    let v764_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v764_2));
    drop(v764_2);
    let v764_9: Space = if map_kernels::has_head(&(v764_8)) { singleton(&[]) } else { Space::new() };
    drop(v764_8);
    let v764_11: Space = if (&(v764_9)).is_empty() { Space::new() } else {
      let mut v767_10 = Space::new();
      let mut v767_10_write = v767_10.write_zipper();
      for v767_10_byte in v763_15_cursor.child_mask().iter() {
        v763_15_cursor.descend_to_existing_byte(v767_10_byte);
        {
        let v768_2: Space = singleton(&v763_15_cursor.path()[(v763_15_origin + 1)..(v763_15_origin + 2)]);
        let v768_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v768_2));
        let v768_4: Space = if map_kernels::has_head(&(v768_3)) { singleton(&[]) } else { Space::new() };
        drop(v768_3);
        let v768_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v768_4));
        drop(v768_4);
        let v768_7: Space = if (&(v768_5)).is_empty() { Space::new() } else {
          let mut v769_6 = Space::new();
          let mut v769_6_write = v769_6.write_zipper();
          for v769_6_byte in v763_15_cursor.child_mask().iter() {
            v763_15_cursor.descend_to_existing_byte(v769_6_byte);
            {
            let v770_2: Space = singleton(&v763_15_cursor.path()[(v763_15_origin + 2)..(v763_15_origin + 3)]);
            let v770_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v770_2));
            let v770_4: Space = if map_kernels::has_head(&(v770_3)) { singleton(&[]) } else { Space::new() };
            drop(v770_3);
            let v770_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v770_4));
            drop(v770_4);
            let v770_8: Space = if (&(v770_5)).is_empty() { Space::new() } else {
              let v771_7: Space = routine_42(c, &v763_15_cursor.path()[(v763_15_origin + 1)..(v763_15_origin + 3)], &v763_15_cursor, &(*s1));
              map_map_kernels::compose(&(v770_5),&(v771_7))
            };
            drop(v770_5);
            let v770_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v770_2));
            drop(v770_2);
            let v770_10: Space = if map_kernels::has_head(&(v770_9)) { singleton(&[]) } else { Space::new() };
            drop(v770_9);
            let v770_12: Space = if (&(v770_10)).is_empty() { Space::new() } else {
              let v772_11: Space = routine_43(c, &v763_15_cursor.path()[(v763_15_origin + 1)..(v763_15_origin + 3)], &v763_15_cursor, &(*s1));
              map_map_kernels::compose(&(v770_10),&(v772_11))
            };
            drop(v770_10);
            let v770_13: Space = map_map_kernels::unite(&(v770_8),&(v770_12));
            join_wrapped_into(&mut v769_6_write,&((v770_13).read_zipper()),&[]);
            }
            v763_15_cursor.ascend(1);
          }
          drop(v769_6_write);
          map_map_kernels::compose(&(v768_5),&(v769_6))
        };
        drop(v768_5);
        let v768_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v768_2));
        drop(v768_2);
        let v768_9: Space = if map_kernels::has_head(&(v768_8)) { singleton(&[]) } else { Space::new() };
        drop(v768_8);
        let v768_11: Space = if (&(v768_9)).is_empty() { Space::new() } else {
          let mut v773_10 = Space::new();
          let mut v773_10_write = v773_10.write_zipper();
          for v773_10_byte in v763_15_cursor.child_mask().iter() {
            v763_15_cursor.descend_to_existing_byte(v773_10_byte);
            {
            let v774_2: Space = singleton(&v763_15_cursor.path()[(v763_15_origin + 2)..(v763_15_origin + 3)]);
            let v774_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v774_2));
            let v774_4: Space = if map_kernels::has_head(&(v774_3)) { singleton(&[]) } else { Space::new() };
            drop(v774_3);
            let v774_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v774_4));
            drop(v774_4);
            let v774_8: Space = if (&(v774_5)).is_empty() { Space::new() } else {
              let v775_7: Space = routine_42(c, &v763_15_cursor.path()[(v763_15_origin + 1)..(v763_15_origin + 3)], &v763_15_cursor, &(*s1));
              map_map_kernels::compose(&(v774_5),&(v775_7))
            };
            drop(v774_5);
            let v774_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v774_2));
            drop(v774_2);
            let v774_10: Space = if map_kernels::has_head(&(v774_9)) { singleton(&[]) } else { Space::new() };
            drop(v774_9);
            let v774_12: Space = if (&(v774_10)).is_empty() { Space::new() } else {
              let v776_11: Space = routine_44(c, &v763_15_cursor.path()[(v763_15_origin + 1)..(v763_15_origin + 3)], &v763_15_cursor, &(*s1));
              map_map_kernels::compose(&(v774_10),&(v776_11))
            };
            drop(v774_10);
            let v774_13: Space = map_map_kernels::unite(&(v774_8),&(v774_12));
            join_wrapped_into(&mut v773_10_write,&((v774_13).read_zipper()),&[]);
            }
            v763_15_cursor.ascend(1);
          }
          drop(v773_10_write);
          map_map_kernels::compose(&(v768_9),&(v773_10))
        };
        drop(v768_9);
        let v768_12: Space = map_map_kernels::unite(&(v768_7),&(v768_11));
        join_wrapped_into(&mut v767_10_write,&((v768_12).read_zipper()),&[]);
        }
        v763_15_cursor.ascend(1);
      }
      drop(v767_10_write);
      map_map_kernels::compose(&(v764_9),&(v767_10))
    };
    drop(v764_9);
    let v764_12: Path = concat_path(&(*p0),&v763_15_cursor.path()[v763_15_origin..(v763_15_origin + 1)]);
    let v764_13: Space = map_kernels::wrap(&(v764_11),&(v764_12));
    drop(v764_12);
    let v764_14: Space = map_map_kernels::unite(&(v764_7),&(v764_13));
    drop(v764_7);
    join_wrapped_into(&mut v763_15_write,&((v764_14).read_zipper()),&[]);
    }
    v763_15_cursor.ascend(1);
  }
  drop(v763_15_cursor);
  drop(v763_15_write);
  (v763_15).clone()
}

fn routine_42(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v777_27 = Space::new();
  let mut v777_27_write = v777_27.write_zipper();
  let mut v777_27_cursor = (*s0).read_zipper();
  let v777_27_origin = v777_27_cursor.path().len();
  for v777_27_byte in v777_27_cursor.child_mask().iter() {
    v777_27_cursor.descend_to_existing_byte(v777_27_byte);
    {
    let v778_2: Space = singleton(&v777_27_cursor.path()[v777_27_origin..(v777_27_origin + 1)]);
    let v778_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v778_2));
    let v778_4: Space = if map_kernels::has_head(&(v778_3)) { singleton(&[]) } else { Space::new() };
    drop(v778_3);
    let v778_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v778_4));
    drop(v778_4);
    let v778_8: Space = if (&(v778_5)).is_empty() { Space::new() } else {
      let v779_6: Path = concat_path(&(*p0),&v777_27_cursor.path()[v777_27_origin..(v777_27_origin + 1)]);
      let mut v779_7 = Space::new();
      let mut v779_7_write = v779_7.write_zipper();
      for v779_7_byte in v777_27_cursor.child_mask().iter() {
        v777_27_cursor.descend_to_existing_byte(v779_7_byte);
        {
        let v780_2: Space = singleton(&v777_27_cursor.path()[(v777_27_origin + 1)..(v777_27_origin + 2)]);
        let v780_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v780_2));
        let v780_4: Space = if map_kernels::has_head(&(v780_3)) { singleton(&[]) } else { Space::new() };
        drop(v780_3);
        let v780_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v780_4));
        drop(v780_4);
        let v780_8: Space = if (&(v780_5)).is_empty() { Space::new() } else {
          let v781_6: Path = concat_path(&(v779_6),&v777_27_cursor.path()[(v777_27_origin + 1)..(v777_27_origin + 2)]);
          let mut v781_7 = Space::new();
          let mut v781_7_write = v781_7.write_zipper();
          for v781_7_byte in v777_27_cursor.child_mask().iter() {
            v777_27_cursor.descend_to_existing_byte(v781_7_byte);
            {
            let v782_2: Space = singleton(&v777_27_cursor.path()[(v777_27_origin + 2)..(v777_27_origin + 3)]);
            let v782_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v782_2));
            let v782_4: Space = if map_kernels::has_head(&(v782_3)) { singleton(&[]) } else { Space::new() };
            drop(v782_3);
            let v782_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v782_4));
            drop(v782_4);
            let v782_8: Space = if (&(v782_5)).is_empty() { Space::new() } else {
              let v783_6: Path = concat_path(&(v781_6),&v777_27_cursor.path()[(v777_27_origin + 2)..(v777_27_origin + 3)]);
              let v783_7: Space = routine_61(c, &(v783_6), &v777_27_cursor, &(*s1));
              map_map_kernels::compose(&(v782_5),&(v783_7))
            };
            drop(v782_5);
            let v782_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v782_2));
            drop(v782_2);
            let v782_10: Space = if map_kernels::has_head(&(v782_9)) { singleton(&[]) } else { Space::new() };
            drop(v782_9);
            let v782_12: Space = if (&(v782_10)).is_empty() { Space::new() } else {
              let v784_6: Path = concat_path(&(v781_6),&v777_27_cursor.path()[(v777_27_origin + 2)..(v777_27_origin + 3)]);
              let v784_11: Space = routine_62(c, &(v784_6), &v777_27_cursor, &(*s1));
              drop(v784_6);
              map_map_kernels::compose(&(v782_10),&(v784_11))
            };
            drop(v782_10);
            let v782_13: Space = map_map_kernels::unite(&(v782_8),&(v782_12));
            join_wrapped_into(&mut v781_7_write,&((v782_13).read_zipper()),&[]);
            }
            v777_27_cursor.ascend(1);
          }
          drop(v781_7_write);
          map_map_kernels::compose(&(v780_5),&(v781_7))
        };
        drop(v780_5);
        let v780_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v780_2));
        drop(v780_2);
        let v780_10: Space = if map_kernels::has_head(&(v780_9)) { singleton(&[]) } else { Space::new() };
        drop(v780_9);
        let v780_12: Space = if (&(v780_10)).is_empty() { Space::new() } else {
          let v785_6: Path = concat_path(&(v779_6),&v777_27_cursor.path()[(v777_27_origin + 1)..(v777_27_origin + 2)]);
          let mut v785_11 = Space::new();
          let mut v785_11_write = v785_11.write_zipper();
          for v785_11_byte in v777_27_cursor.child_mask().iter() {
            v777_27_cursor.descend_to_existing_byte(v785_11_byte);
            {
            let v786_2: Space = singleton(&v777_27_cursor.path()[(v777_27_origin + 2)..(v777_27_origin + 3)]);
            let v786_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v786_2));
            let v786_4: Space = if map_kernels::has_head(&(v786_3)) { singleton(&[]) } else { Space::new() };
            drop(v786_3);
            let v786_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v786_4));
            drop(v786_4);
            let v786_8: Space = if (&(v786_5)).is_empty() { Space::new() } else {
              let v787_6: Path = concat_path(&(v785_6),&v777_27_cursor.path()[(v777_27_origin + 2)..(v777_27_origin + 3)]);
              let v787_7: Space = routine_61(c, &(v787_6), &v777_27_cursor, &(*s1));
              map_map_kernels::compose(&(v786_5),&(v787_7))
            };
            drop(v786_5);
            let v786_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v786_2));
            drop(v786_2);
            let v786_10: Space = if map_kernels::has_head(&(v786_9)) { singleton(&[]) } else { Space::new() };
            drop(v786_9);
            let v786_12: Space = if (&(v786_10)).is_empty() { Space::new() } else {
              let v788_6: Path = concat_path(&(v785_6),&v777_27_cursor.path()[(v777_27_origin + 2)..(v777_27_origin + 3)]);
              let v788_11: Space = routine_44(c, &(v788_6), &v777_27_cursor, &(*s1));
              drop(v788_6);
              map_map_kernels::compose(&(v786_10),&(v788_11))
            };
            drop(v786_10);
            let v786_13: Space = map_map_kernels::unite(&(v786_8),&(v786_12));
            join_wrapped_into(&mut v785_11_write,&((v786_13).read_zipper()),&[]);
            }
            v777_27_cursor.ascend(1);
          }
          drop(v785_11_write);
          drop(v785_6);
          map_map_kernels::compose(&(v780_10),&(v785_11))
        };
        drop(v780_10);
        let v780_13: Space = map_map_kernels::unite(&(v780_8),&(v780_12));
        join_wrapped_into(&mut v779_7_write,&((v780_13).read_zipper()),&[]);
        }
        v777_27_cursor.ascend(1);
      }
      drop(v779_7_write);
      map_map_kernels::compose(&(v778_5),&(v779_7))
    };
    drop(v778_5);
    let v778_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v778_2));
    drop(v778_2);
    let v778_10: Space = if map_kernels::has_head(&(v778_9)) { singleton(&[]) } else { Space::new() };
    drop(v778_9);
    let v778_13: Space = if (&(v778_10)).is_empty() { Space::new() } else {
      let v789_6: Path = concat_path(&(*p0),&v777_27_cursor.path()[v777_27_origin..(v777_27_origin + 1)]);
      let mut v789_12 = Space::new();
      let mut v789_12_write = v789_12.write_zipper();
      for v789_12_byte in v777_27_cursor.child_mask().iter() {
        v777_27_cursor.descend_to_existing_byte(v789_12_byte);
        {
        let v790_2: Space = singleton(&v777_27_cursor.path()[(v777_27_origin + 1)..(v777_27_origin + 2)]);
        let v790_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v790_2));
        let v790_4: Space = if map_kernels::has_head(&(v790_3)) { singleton(&[]) } else { Space::new() };
        drop(v790_3);
        let v790_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v790_4));
        drop(v790_4);
        let v790_8: Space = if (&(v790_5)).is_empty() { Space::new() } else {
          let v791_6: Path = concat_path(&(v789_6),&v777_27_cursor.path()[(v777_27_origin + 1)..(v777_27_origin + 2)]);
          let mut v791_7 = Space::new();
          let mut v791_7_write = v791_7.write_zipper();
          for v791_7_byte in v777_27_cursor.child_mask().iter() {
            v777_27_cursor.descend_to_existing_byte(v791_7_byte);
            {
            let v792_2: Space = singleton(&v777_27_cursor.path()[(v777_27_origin + 2)..(v777_27_origin + 3)]);
            let v792_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v792_2));
            let v792_4: Space = if map_kernels::has_head(&(v792_3)) { singleton(&[]) } else { Space::new() };
            drop(v792_3);
            let v792_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v792_4));
            drop(v792_4);
            let v792_8: Space = if (&(v792_5)).is_empty() { Space::new() } else {
              let v793_6: Path = concat_path(&(v791_6),&v777_27_cursor.path()[(v777_27_origin + 2)..(v777_27_origin + 3)]);
              let v793_7: Space = routine_61(c, &(v793_6), &v777_27_cursor, &(*s1));
              map_map_kernels::compose(&(v792_5),&(v793_7))
            };
            drop(v792_5);
            let v792_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v792_2));
            drop(v792_2);
            let v792_10: Space = if map_kernels::has_head(&(v792_9)) { singleton(&[]) } else { Space::new() };
            drop(v792_9);
            let v792_12: Space = if (&(v792_10)).is_empty() { Space::new() } else {
              let v794_6: Path = concat_path(&(v791_6),&v777_27_cursor.path()[(v777_27_origin + 2)..(v777_27_origin + 3)]);
              let v794_11: Space = routine_62(c, &(v794_6), &v777_27_cursor, &(*s1));
              drop(v794_6);
              map_map_kernels::compose(&(v792_10),&(v794_11))
            };
            drop(v792_10);
            let v792_13: Space = map_map_kernels::unite(&(v792_8),&(v792_12));
            join_wrapped_into(&mut v791_7_write,&((v792_13).read_zipper()),&[]);
            }
            v777_27_cursor.ascend(1);
          }
          drop(v791_7_write);
          drop(v791_6);
          map_map_kernels::compose(&(v790_5),&(v791_7))
        };
        drop(v790_5);
        let v790_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v790_2));
        drop(v790_2);
        let v790_10: Space = if map_kernels::has_head(&(v790_9)) { singleton(&[]) } else { Space::new() };
        drop(v790_9);
        let v790_13: Space = if (&(v790_10)).is_empty() { Space::new() } else {
          let v795_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v777_27_cursor.path()[v777_27_origin..(v777_27_origin + 1)]),&v777_27_cursor.path()[(v777_27_origin + 1)..(v777_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v790_10),&(v795_12))
        };
        drop(v790_10);
        let v790_14: Space = map_map_kernels::unite(&(v790_8),&(v790_13));
        drop(v790_13);
        join_wrapped_into(&mut v789_12_write,&((v790_14).read_zipper()),&[]);
        }
        v777_27_cursor.ascend(1);
      }
      drop(v789_12_write);
      drop(v789_6);
      map_map_kernels::compose(&(v778_10),&(v789_12))
    };
    drop(v778_10);
    let v778_14: Space = map_map_kernels::unite(&(v778_8),&(v778_13));
    join_wrapped_into(&mut v777_27_write,&((v778_14).read_zipper()),&[]);
    }
    v777_27_cursor.ascend(1);
  }
  drop(v777_27_cursor);
  drop(v777_27_write);
  (v777_27).clone()
}

fn routine_43(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v796_21 = Space::new();
  let mut v796_21_write = v796_21.write_zipper();
  let mut v796_21_cursor = (*s0).read_zipper();
  let v796_21_origin = v796_21_cursor.path().len();
  for v796_21_byte in v796_21_cursor.child_mask().iter() {
    v796_21_cursor.descend_to_existing_byte(v796_21_byte);
    {
    let v797_2: Space = singleton(&v796_21_cursor.path()[v796_21_origin..(v796_21_origin + 1)]);
    let v797_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v797_2));
    let v797_4: Space = if map_kernels::has_head(&(v797_3)) { singleton(&[]) } else { Space::new() };
    drop(v797_3);
    let v797_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v797_4));
    drop(v797_4);
    let v797_8: Space = if (&(v797_5)).is_empty() { Space::new() } else {
      let v798_6: Path = concat_path(&(*p0),&v796_21_cursor.path()[v796_21_origin..(v796_21_origin + 1)]);
      let mut v798_7 = Space::new();
      let mut v798_7_write = v798_7.write_zipper();
      for v798_7_byte in v796_21_cursor.child_mask().iter() {
        v796_21_cursor.descend_to_existing_byte(v798_7_byte);
        {
        let v799_2: Space = singleton(&v796_21_cursor.path()[(v796_21_origin + 1)..(v796_21_origin + 2)]);
        let v799_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v799_2));
        let v799_4: Space = if map_kernels::has_head(&(v799_3)) { singleton(&[]) } else { Space::new() };
        drop(v799_3);
        let v799_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v799_4));
        drop(v799_4);
        let v799_8: Space = if (&(v799_5)).is_empty() { Space::new() } else {
          let v800_6: Path = concat_path(&(v798_6),&v796_21_cursor.path()[(v796_21_origin + 1)..(v796_21_origin + 2)]);
          let mut v800_7 = Space::new();
          let mut v800_7_write = v800_7.write_zipper();
          for v800_7_byte in v796_21_cursor.child_mask().iter() {
            v796_21_cursor.descend_to_existing_byte(v800_7_byte);
            {
            let v801_2: Space = singleton(&v796_21_cursor.path()[(v796_21_origin + 2)..(v796_21_origin + 3)]);
            let v801_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v801_2));
            let v801_4: Space = if map_kernels::has_head(&(v801_3)) { singleton(&[]) } else { Space::new() };
            drop(v801_3);
            let v801_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v801_4));
            drop(v801_4);
            let v801_8: Space = if (&(v801_5)).is_empty() { Space::new() } else {
              let v802_6: Path = concat_path(&(v800_6),&v796_21_cursor.path()[(v796_21_origin + 2)..(v796_21_origin + 3)]);
              let v802_7: Space = routine_61(c, &(v802_6), &v796_21_cursor, &(*s1));
              map_map_kernels::compose(&(v801_5),&(v802_7))
            };
            drop(v801_5);
            let v801_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v801_2));
            drop(v801_2);
            let v801_10: Space = if map_kernels::has_head(&(v801_9)) { singleton(&[]) } else { Space::new() };
            drop(v801_9);
            let v801_12: Space = if (&(v801_10)).is_empty() { Space::new() } else {
              let v803_6: Path = concat_path(&(v800_6),&v796_21_cursor.path()[(v796_21_origin + 2)..(v796_21_origin + 3)]);
              let v803_11: Space = routine_62(c, &(v803_6), &v796_21_cursor, &(*s1));
              drop(v803_6);
              map_map_kernels::compose(&(v801_10),&(v803_11))
            };
            drop(v801_10);
            let v801_13: Space = map_map_kernels::unite(&(v801_8),&(v801_12));
            join_wrapped_into(&mut v800_7_write,&((v801_13).read_zipper()),&[]);
            }
            v796_21_cursor.ascend(1);
          }
          drop(v800_7_write);
          map_map_kernels::compose(&(v799_5),&(v800_7))
        };
        drop(v799_5);
        let v799_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v799_2));
        drop(v799_2);
        let v799_10: Space = if map_kernels::has_head(&(v799_9)) { singleton(&[]) } else { Space::new() };
        drop(v799_9);
        let v799_12: Space = if (&(v799_10)).is_empty() { Space::new() } else {
          let v804_6: Path = concat_path(&(v798_6),&v796_21_cursor.path()[(v796_21_origin + 1)..(v796_21_origin + 2)]);
          let mut v804_11 = Space::new();
          let mut v804_11_write = v804_11.write_zipper();
          for v804_11_byte in v796_21_cursor.child_mask().iter() {
            v796_21_cursor.descend_to_existing_byte(v804_11_byte);
            {
            let v805_2: Space = singleton(&v796_21_cursor.path()[(v796_21_origin + 2)..(v796_21_origin + 3)]);
            let v805_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v805_2));
            let v805_4: Space = if map_kernels::has_head(&(v805_3)) { singleton(&[]) } else { Space::new() };
            drop(v805_3);
            let v805_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v805_4));
            drop(v805_4);
            let v805_8: Space = if (&(v805_5)).is_empty() { Space::new() } else {
              let v806_6: Path = concat_path(&(v804_6),&v796_21_cursor.path()[(v796_21_origin + 2)..(v796_21_origin + 3)]);
              let v806_7: Space = routine_61(c, &(v806_6), &v796_21_cursor, &(*s1));
              map_map_kernels::compose(&(v805_5),&(v806_7))
            };
            drop(v805_5);
            let v805_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v805_2));
            drop(v805_2);
            let v805_10: Space = if map_kernels::has_head(&(v805_9)) { singleton(&[]) } else { Space::new() };
            drop(v805_9);
            let v805_12: Space = if (&(v805_10)).is_empty() { Space::new() } else {
              let v807_6: Path = concat_path(&(v804_6),&v796_21_cursor.path()[(v796_21_origin + 2)..(v796_21_origin + 3)]);
              let v807_11: Space = routine_44(c, &(v807_6), &v796_21_cursor, &(*s1));
              drop(v807_6);
              map_map_kernels::compose(&(v805_10),&(v807_11))
            };
            drop(v805_10);
            let v805_13: Space = map_map_kernels::unite(&(v805_8),&(v805_12));
            join_wrapped_into(&mut v804_11_write,&((v805_13).read_zipper()),&[]);
            }
            v796_21_cursor.ascend(1);
          }
          drop(v804_11_write);
          drop(v804_6);
          map_map_kernels::compose(&(v799_10),&(v804_11))
        };
        drop(v799_10);
        let v799_13: Space = map_map_kernels::unite(&(v799_8),&(v799_12));
        join_wrapped_into(&mut v798_7_write,&((v799_13).read_zipper()),&[]);
        }
        v796_21_cursor.ascend(1);
      }
      drop(v798_7_write);
      drop(v798_6);
      map_map_kernels::compose(&(v797_5),&(v798_7))
    };
    drop(v797_5);
    let v797_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v797_2));
    drop(v797_2);
    let v797_10: Space = if map_kernels::has_head(&(v797_9)) { singleton(&[]) } else { Space::new() };
    drop(v797_9);
    let v797_13: Space = if (&(v797_10)).is_empty() { Space::new() } else {
      let v808_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v796_21_cursor.path()[v796_21_origin..(v796_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v797_10),&(v808_12))
    };
    drop(v797_10);
    let v797_14: Space = map_map_kernels::unite(&(v797_8),&(v797_13));
    drop(v797_13);
    join_wrapped_into(&mut v796_21_write,&((v797_14).read_zipper()),&[]);
    }
    v796_21_cursor.ascend(1);
  }
  drop(v796_21_cursor);
  drop(v796_21_write);
  (v796_21).clone()
}

fn routine_44(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v809_9: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0))),&(*CONSTANT_5));
  (v809_9).clone()
}

fn routine_45(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v810_27 = Space::new();
  let mut v810_27_write = v810_27.write_zipper();
  let mut v810_27_cursor = (*s0).read_zipper();
  let v810_27_origin = v810_27_cursor.path().len();
  for v810_27_byte in v810_27_cursor.child_mask().iter() {
    v810_27_cursor.descend_to_existing_byte(v810_27_byte);
    {
    let v811_2: Space = singleton(&v810_27_cursor.path()[v810_27_origin..(v810_27_origin + 1)]);
    let v811_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v811_2));
    let v811_4: Space = if map_kernels::has_head(&(v811_3)) { singleton(&[]) } else { Space::new() };
    drop(v811_3);
    let v811_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v811_4));
    drop(v811_4);
    let v811_8: Space = if (&(v811_5)).is_empty() { Space::new() } else {
      let v812_6: Path = concat_path(&(*p0),&v810_27_cursor.path()[v810_27_origin..(v810_27_origin + 1)]);
      let mut v812_7 = Space::new();
      let mut v812_7_write = v812_7.write_zipper();
      for v812_7_byte in v810_27_cursor.child_mask().iter() {
        v810_27_cursor.descend_to_existing_byte(v812_7_byte);
        {
        let v813_2: Space = singleton(&v810_27_cursor.path()[(v810_27_origin + 1)..(v810_27_origin + 2)]);
        let v813_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v813_2));
        let v813_4: Space = if map_kernels::has_head(&(v813_3)) { singleton(&[]) } else { Space::new() };
        drop(v813_3);
        let v813_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v813_4));
        drop(v813_4);
        let v813_8: Space = if (&(v813_5)).is_empty() { Space::new() } else {
          let v814_6: Path = concat_path(&(v812_6),&v810_27_cursor.path()[(v810_27_origin + 1)..(v810_27_origin + 2)]);
          let mut v814_7 = Space::new();
          let mut v814_7_write = v814_7.write_zipper();
          for v814_7_byte in v810_27_cursor.child_mask().iter() {
            v810_27_cursor.descend_to_existing_byte(v814_7_byte);
            {
            let v815_2: Space = singleton(&v810_27_cursor.path()[(v810_27_origin + 2)..(v810_27_origin + 3)]);
            let v815_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v815_2));
            let v815_4: Space = if map_kernels::has_head(&(v815_3)) { singleton(&[]) } else { Space::new() };
            drop(v815_3);
            let v815_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v815_4));
            drop(v815_4);
            let v815_8: Space = if (&(v815_5)).is_empty() { Space::new() } else {
              let v816_6: Path = concat_path(&(v814_6),&v810_27_cursor.path()[(v810_27_origin + 2)..(v810_27_origin + 3)]);
              let v816_7: Space = routine_63(c, &(v816_6), &v810_27_cursor, &(*s1));
              map_map_kernels::compose(&(v815_5),&(v816_7))
            };
            drop(v815_5);
            let v815_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v815_2));
            drop(v815_2);
            let v815_10: Space = if map_kernels::has_head(&(v815_9)) { singleton(&[]) } else { Space::new() };
            drop(v815_9);
            let v815_12: Space = if (&(v815_10)).is_empty() { Space::new() } else {
              let v817_6: Path = concat_path(&(v814_6),&v810_27_cursor.path()[(v810_27_origin + 2)..(v810_27_origin + 3)]);
              let v817_11: Space = routine_64(c, &(v817_6), &v810_27_cursor, &(*s1));
              drop(v817_6);
              map_map_kernels::compose(&(v815_10),&(v817_11))
            };
            drop(v815_10);
            let v815_13: Space = map_map_kernels::unite(&(v815_8),&(v815_12));
            join_wrapped_into(&mut v814_7_write,&((v815_13).read_zipper()),&[]);
            }
            v810_27_cursor.ascend(1);
          }
          drop(v814_7_write);
          map_map_kernels::compose(&(v813_5),&(v814_7))
        };
        drop(v813_5);
        let v813_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v813_2));
        drop(v813_2);
        let v813_10: Space = if map_kernels::has_head(&(v813_9)) { singleton(&[]) } else { Space::new() };
        drop(v813_9);
        let v813_12: Space = if (&(v813_10)).is_empty() { Space::new() } else {
          let v818_6: Path = concat_path(&(v812_6),&v810_27_cursor.path()[(v810_27_origin + 1)..(v810_27_origin + 2)]);
          let mut v818_11 = Space::new();
          let mut v818_11_write = v818_11.write_zipper();
          for v818_11_byte in v810_27_cursor.child_mask().iter() {
            v810_27_cursor.descend_to_existing_byte(v818_11_byte);
            {
            let v819_2: Space = singleton(&v810_27_cursor.path()[(v810_27_origin + 2)..(v810_27_origin + 3)]);
            let v819_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v819_2));
            let v819_4: Space = if map_kernels::has_head(&(v819_3)) { singleton(&[]) } else { Space::new() };
            drop(v819_3);
            let v819_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v819_4));
            drop(v819_4);
            let v819_8: Space = if (&(v819_5)).is_empty() { Space::new() } else {
              let v820_6: Path = concat_path(&(v818_6),&v810_27_cursor.path()[(v810_27_origin + 2)..(v810_27_origin + 3)]);
              let v820_7: Space = routine_63(c, &(v820_6), &v810_27_cursor, &(*s1));
              map_map_kernels::compose(&(v819_5),&(v820_7))
            };
            drop(v819_5);
            let v819_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v819_2));
            drop(v819_2);
            let v819_10: Space = if map_kernels::has_head(&(v819_9)) { singleton(&[]) } else { Space::new() };
            drop(v819_9);
            let v819_12: Space = if (&(v819_10)).is_empty() { Space::new() } else {
              let v821_6: Path = concat_path(&(v818_6),&v810_27_cursor.path()[(v810_27_origin + 2)..(v810_27_origin + 3)]);
              let v821_11: Space = routine_44(c, &(v821_6), &v810_27_cursor, &(*s1));
              drop(v821_6);
              map_map_kernels::compose(&(v819_10),&(v821_11))
            };
            drop(v819_10);
            let v819_13: Space = map_map_kernels::unite(&(v819_8),&(v819_12));
            join_wrapped_into(&mut v818_11_write,&((v819_13).read_zipper()),&[]);
            }
            v810_27_cursor.ascend(1);
          }
          drop(v818_11_write);
          drop(v818_6);
          map_map_kernels::compose(&(v813_10),&(v818_11))
        };
        drop(v813_10);
        let v813_13: Space = map_map_kernels::unite(&(v813_8),&(v813_12));
        join_wrapped_into(&mut v812_7_write,&((v813_13).read_zipper()),&[]);
        }
        v810_27_cursor.ascend(1);
      }
      drop(v812_7_write);
      map_map_kernels::compose(&(v811_5),&(v812_7))
    };
    drop(v811_5);
    let v811_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v811_2));
    drop(v811_2);
    let v811_10: Space = if map_kernels::has_head(&(v811_9)) { singleton(&[]) } else { Space::new() };
    drop(v811_9);
    let v811_13: Space = if (&(v811_10)).is_empty() { Space::new() } else {
      let v822_6: Path = concat_path(&(*p0),&v810_27_cursor.path()[v810_27_origin..(v810_27_origin + 1)]);
      let mut v822_12 = Space::new();
      let mut v822_12_write = v822_12.write_zipper();
      for v822_12_byte in v810_27_cursor.child_mask().iter() {
        v810_27_cursor.descend_to_existing_byte(v822_12_byte);
        {
        let v823_2: Space = singleton(&v810_27_cursor.path()[(v810_27_origin + 1)..(v810_27_origin + 2)]);
        let v823_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v823_2));
        let v823_4: Space = if map_kernels::has_head(&(v823_3)) { singleton(&[]) } else { Space::new() };
        drop(v823_3);
        let v823_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v823_4));
        drop(v823_4);
        let v823_8: Space = if (&(v823_5)).is_empty() { Space::new() } else {
          let v824_6: Path = concat_path(&(v822_6),&v810_27_cursor.path()[(v810_27_origin + 1)..(v810_27_origin + 2)]);
          let mut v824_7 = Space::new();
          let mut v824_7_write = v824_7.write_zipper();
          for v824_7_byte in v810_27_cursor.child_mask().iter() {
            v810_27_cursor.descend_to_existing_byte(v824_7_byte);
            {
            let v825_2: Space = singleton(&v810_27_cursor.path()[(v810_27_origin + 2)..(v810_27_origin + 3)]);
            let v825_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v825_2));
            let v825_4: Space = if map_kernels::has_head(&(v825_3)) { singleton(&[]) } else { Space::new() };
            drop(v825_3);
            let v825_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v825_4));
            drop(v825_4);
            let v825_8: Space = if (&(v825_5)).is_empty() { Space::new() } else {
              let v826_6: Path = concat_path(&(v824_6),&v810_27_cursor.path()[(v810_27_origin + 2)..(v810_27_origin + 3)]);
              let v826_7: Space = routine_63(c, &(v826_6), &v810_27_cursor, &(*s1));
              map_map_kernels::compose(&(v825_5),&(v826_7))
            };
            drop(v825_5);
            let v825_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v825_2));
            drop(v825_2);
            let v825_10: Space = if map_kernels::has_head(&(v825_9)) { singleton(&[]) } else { Space::new() };
            drop(v825_9);
            let v825_12: Space = if (&(v825_10)).is_empty() { Space::new() } else {
              let v827_6: Path = concat_path(&(v824_6),&v810_27_cursor.path()[(v810_27_origin + 2)..(v810_27_origin + 3)]);
              let v827_11: Space = routine_64(c, &(v827_6), &v810_27_cursor, &(*s1));
              drop(v827_6);
              map_map_kernels::compose(&(v825_10),&(v827_11))
            };
            drop(v825_10);
            let v825_13: Space = map_map_kernels::unite(&(v825_8),&(v825_12));
            join_wrapped_into(&mut v824_7_write,&((v825_13).read_zipper()),&[]);
            }
            v810_27_cursor.ascend(1);
          }
          drop(v824_7_write);
          drop(v824_6);
          map_map_kernels::compose(&(v823_5),&(v824_7))
        };
        drop(v823_5);
        let v823_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v823_2));
        drop(v823_2);
        let v823_10: Space = if map_kernels::has_head(&(v823_9)) { singleton(&[]) } else { Space::new() };
        drop(v823_9);
        let v823_13: Space = if (&(v823_10)).is_empty() { Space::new() } else {
          let v828_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v810_27_cursor.path()[v810_27_origin..(v810_27_origin + 1)]),&v810_27_cursor.path()[(v810_27_origin + 1)..(v810_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v823_10),&(v828_12))
        };
        drop(v823_10);
        let v823_14: Space = map_map_kernels::unite(&(v823_8),&(v823_13));
        drop(v823_13);
        join_wrapped_into(&mut v822_12_write,&((v823_14).read_zipper()),&[]);
        }
        v810_27_cursor.ascend(1);
      }
      drop(v822_12_write);
      drop(v822_6);
      map_map_kernels::compose(&(v811_10),&(v822_12))
    };
    drop(v811_10);
    let v811_14: Space = map_map_kernels::unite(&(v811_8),&(v811_13));
    join_wrapped_into(&mut v810_27_write,&((v811_14).read_zipper()),&[]);
    }
    v810_27_cursor.ascend(1);
  }
  drop(v810_27_cursor);
  drop(v810_27_write);
  (v810_27).clone()
}

fn routine_46(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v829_21 = Space::new();
  let mut v829_21_write = v829_21.write_zipper();
  let mut v829_21_cursor = (*s0).read_zipper();
  let v829_21_origin = v829_21_cursor.path().len();
  for v829_21_byte in v829_21_cursor.child_mask().iter() {
    v829_21_cursor.descend_to_existing_byte(v829_21_byte);
    {
    let v830_2: Space = singleton(&v829_21_cursor.path()[v829_21_origin..(v829_21_origin + 1)]);
    let v830_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v830_2));
    let v830_4: Space = if map_kernels::has_head(&(v830_3)) { singleton(&[]) } else { Space::new() };
    drop(v830_3);
    let v830_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v830_4));
    drop(v830_4);
    let v830_8: Space = if (&(v830_5)).is_empty() { Space::new() } else {
      let v831_6: Path = concat_path(&(*p0),&v829_21_cursor.path()[v829_21_origin..(v829_21_origin + 1)]);
      let mut v831_7 = Space::new();
      let mut v831_7_write = v831_7.write_zipper();
      for v831_7_byte in v829_21_cursor.child_mask().iter() {
        v829_21_cursor.descend_to_existing_byte(v831_7_byte);
        {
        let v832_2: Space = singleton(&v829_21_cursor.path()[(v829_21_origin + 1)..(v829_21_origin + 2)]);
        let v832_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v832_2));
        let v832_4: Space = if map_kernels::has_head(&(v832_3)) { singleton(&[]) } else { Space::new() };
        drop(v832_3);
        let v832_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v832_4));
        drop(v832_4);
        let v832_8: Space = if (&(v832_5)).is_empty() { Space::new() } else {
          let v833_6: Path = concat_path(&(v831_6),&v829_21_cursor.path()[(v829_21_origin + 1)..(v829_21_origin + 2)]);
          let mut v833_7 = Space::new();
          let mut v833_7_write = v833_7.write_zipper();
          for v833_7_byte in v829_21_cursor.child_mask().iter() {
            v829_21_cursor.descend_to_existing_byte(v833_7_byte);
            {
            let v834_2: Space = singleton(&v829_21_cursor.path()[(v829_21_origin + 2)..(v829_21_origin + 3)]);
            let v834_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v834_2));
            let v834_4: Space = if map_kernels::has_head(&(v834_3)) { singleton(&[]) } else { Space::new() };
            drop(v834_3);
            let v834_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v834_4));
            drop(v834_4);
            let v834_8: Space = if (&(v834_5)).is_empty() { Space::new() } else {
              let v835_6: Path = concat_path(&(v833_6),&v829_21_cursor.path()[(v829_21_origin + 2)..(v829_21_origin + 3)]);
              let v835_7: Space = routine_63(c, &(v835_6), &v829_21_cursor, &(*s1));
              map_map_kernels::compose(&(v834_5),&(v835_7))
            };
            drop(v834_5);
            let v834_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v834_2));
            drop(v834_2);
            let v834_10: Space = if map_kernels::has_head(&(v834_9)) { singleton(&[]) } else { Space::new() };
            drop(v834_9);
            let v834_12: Space = if (&(v834_10)).is_empty() { Space::new() } else {
              let v836_6: Path = concat_path(&(v833_6),&v829_21_cursor.path()[(v829_21_origin + 2)..(v829_21_origin + 3)]);
              let v836_11: Space = routine_64(c, &(v836_6), &v829_21_cursor, &(*s1));
              drop(v836_6);
              map_map_kernels::compose(&(v834_10),&(v836_11))
            };
            drop(v834_10);
            let v834_13: Space = map_map_kernels::unite(&(v834_8),&(v834_12));
            join_wrapped_into(&mut v833_7_write,&((v834_13).read_zipper()),&[]);
            }
            v829_21_cursor.ascend(1);
          }
          drop(v833_7_write);
          map_map_kernels::compose(&(v832_5),&(v833_7))
        };
        drop(v832_5);
        let v832_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v832_2));
        drop(v832_2);
        let v832_10: Space = if map_kernels::has_head(&(v832_9)) { singleton(&[]) } else { Space::new() };
        drop(v832_9);
        let v832_12: Space = if (&(v832_10)).is_empty() { Space::new() } else {
          let v837_6: Path = concat_path(&(v831_6),&v829_21_cursor.path()[(v829_21_origin + 1)..(v829_21_origin + 2)]);
          let mut v837_11 = Space::new();
          let mut v837_11_write = v837_11.write_zipper();
          for v837_11_byte in v829_21_cursor.child_mask().iter() {
            v829_21_cursor.descend_to_existing_byte(v837_11_byte);
            {
            let v838_2: Space = singleton(&v829_21_cursor.path()[(v829_21_origin + 2)..(v829_21_origin + 3)]);
            let v838_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v838_2));
            let v838_4: Space = if map_kernels::has_head(&(v838_3)) { singleton(&[]) } else { Space::new() };
            drop(v838_3);
            let v838_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v838_4));
            drop(v838_4);
            let v838_8: Space = if (&(v838_5)).is_empty() { Space::new() } else {
              let v839_6: Path = concat_path(&(v837_6),&v829_21_cursor.path()[(v829_21_origin + 2)..(v829_21_origin + 3)]);
              let v839_7: Space = routine_63(c, &(v839_6), &v829_21_cursor, &(*s1));
              map_map_kernels::compose(&(v838_5),&(v839_7))
            };
            drop(v838_5);
            let v838_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v838_2));
            drop(v838_2);
            let v838_10: Space = if map_kernels::has_head(&(v838_9)) { singleton(&[]) } else { Space::new() };
            drop(v838_9);
            let v838_12: Space = if (&(v838_10)).is_empty() { Space::new() } else {
              let v840_6: Path = concat_path(&(v837_6),&v829_21_cursor.path()[(v829_21_origin + 2)..(v829_21_origin + 3)]);
              let v840_11: Space = routine_44(c, &(v840_6), &v829_21_cursor, &(*s1));
              drop(v840_6);
              map_map_kernels::compose(&(v838_10),&(v840_11))
            };
            drop(v838_10);
            let v838_13: Space = map_map_kernels::unite(&(v838_8),&(v838_12));
            join_wrapped_into(&mut v837_11_write,&((v838_13).read_zipper()),&[]);
            }
            v829_21_cursor.ascend(1);
          }
          drop(v837_11_write);
          drop(v837_6);
          map_map_kernels::compose(&(v832_10),&(v837_11))
        };
        drop(v832_10);
        let v832_13: Space = map_map_kernels::unite(&(v832_8),&(v832_12));
        join_wrapped_into(&mut v831_7_write,&((v832_13).read_zipper()),&[]);
        }
        v829_21_cursor.ascend(1);
      }
      drop(v831_7_write);
      drop(v831_6);
      map_map_kernels::compose(&(v830_5),&(v831_7))
    };
    drop(v830_5);
    let v830_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v830_2));
    drop(v830_2);
    let v830_10: Space = if map_kernels::has_head(&(v830_9)) { singleton(&[]) } else { Space::new() };
    drop(v830_9);
    let v830_13: Space = if (&(v830_10)).is_empty() { Space::new() } else {
      let v841_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v829_21_cursor.path()[v829_21_origin..(v829_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v830_10),&(v841_12))
    };
    drop(v830_10);
    let v830_14: Space = map_map_kernels::unite(&(v830_8),&(v830_13));
    drop(v830_13);
    join_wrapped_into(&mut v829_21_write,&((v830_14).read_zipper()),&[]);
    }
    v829_21_cursor.ascend(1);
  }
  drop(v829_21_cursor);
  drop(v829_21_write);
  (v829_21).clone()
}

fn routine_47(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v842_27 = Space::new();
  let mut v842_27_write = v842_27.write_zipper();
  let mut v842_27_cursor = (*s0).read_zipper();
  let v842_27_origin = v842_27_cursor.path().len();
  for v842_27_byte in v842_27_cursor.child_mask().iter() {
    v842_27_cursor.descend_to_existing_byte(v842_27_byte);
    {
    let v843_2: Space = singleton(&v842_27_cursor.path()[v842_27_origin..(v842_27_origin + 1)]);
    let v843_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v843_2));
    let v843_4: Space = if map_kernels::has_head(&(v843_3)) { singleton(&[]) } else { Space::new() };
    drop(v843_3);
    let v843_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v843_4));
    drop(v843_4);
    let v843_8: Space = if (&(v843_5)).is_empty() { Space::new() } else {
      let v844_6: Path = concat_path(&(*p0),&v842_27_cursor.path()[v842_27_origin..(v842_27_origin + 1)]);
      let mut v844_7 = Space::new();
      let mut v844_7_write = v844_7.write_zipper();
      for v844_7_byte in v842_27_cursor.child_mask().iter() {
        v842_27_cursor.descend_to_existing_byte(v844_7_byte);
        {
        let v845_2: Space = singleton(&v842_27_cursor.path()[(v842_27_origin + 1)..(v842_27_origin + 2)]);
        let v845_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v845_2));
        let v845_4: Space = if map_kernels::has_head(&(v845_3)) { singleton(&[]) } else { Space::new() };
        drop(v845_3);
        let v845_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v845_4));
        drop(v845_4);
        let v845_8: Space = if (&(v845_5)).is_empty() { Space::new() } else {
          let v846_6: Path = concat_path(&(v844_6),&v842_27_cursor.path()[(v842_27_origin + 1)..(v842_27_origin + 2)]);
          let mut v846_7 = Space::new();
          let mut v846_7_write = v846_7.write_zipper();
          for v846_7_byte in v842_27_cursor.child_mask().iter() {
            v842_27_cursor.descend_to_existing_byte(v846_7_byte);
            {
            let v847_2: Space = singleton(&v842_27_cursor.path()[(v842_27_origin + 2)..(v842_27_origin + 3)]);
            let v847_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v847_2));
            let v847_4: Space = if map_kernels::has_head(&(v847_3)) { singleton(&[]) } else { Space::new() };
            drop(v847_3);
            let v847_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v847_4));
            drop(v847_4);
            let v847_8: Space = if (&(v847_5)).is_empty() { Space::new() } else {
              let v848_6: Path = concat_path(&(v846_6),&v842_27_cursor.path()[(v842_27_origin + 2)..(v842_27_origin + 3)]);
              let v848_7: Space = routine_65(c, &(v848_6), &v842_27_cursor, &(*s1));
              map_map_kernels::compose(&(v847_5),&(v848_7))
            };
            drop(v847_5);
            let v847_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v847_2));
            drop(v847_2);
            let v847_10: Space = if map_kernels::has_head(&(v847_9)) { singleton(&[]) } else { Space::new() };
            drop(v847_9);
            let v847_12: Space = if (&(v847_10)).is_empty() { Space::new() } else {
              let v849_6: Path = concat_path(&(v846_6),&v842_27_cursor.path()[(v842_27_origin + 2)..(v842_27_origin + 3)]);
              let v849_11: Space = routine_66(c, &(v849_6), &v842_27_cursor, &(*s1));
              drop(v849_6);
              map_map_kernels::compose(&(v847_10),&(v849_11))
            };
            drop(v847_10);
            let v847_13: Space = map_map_kernels::unite(&(v847_8),&(v847_12));
            join_wrapped_into(&mut v846_7_write,&((v847_13).read_zipper()),&[]);
            }
            v842_27_cursor.ascend(1);
          }
          drop(v846_7_write);
          map_map_kernels::compose(&(v845_5),&(v846_7))
        };
        drop(v845_5);
        let v845_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v845_2));
        drop(v845_2);
        let v845_10: Space = if map_kernels::has_head(&(v845_9)) { singleton(&[]) } else { Space::new() };
        drop(v845_9);
        let v845_12: Space = if (&(v845_10)).is_empty() { Space::new() } else {
          let v850_6: Path = concat_path(&(v844_6),&v842_27_cursor.path()[(v842_27_origin + 1)..(v842_27_origin + 2)]);
          let mut v850_11 = Space::new();
          let mut v850_11_write = v850_11.write_zipper();
          for v850_11_byte in v842_27_cursor.child_mask().iter() {
            v842_27_cursor.descend_to_existing_byte(v850_11_byte);
            {
            let v851_2: Space = singleton(&v842_27_cursor.path()[(v842_27_origin + 2)..(v842_27_origin + 3)]);
            let v851_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v851_2));
            let v851_4: Space = if map_kernels::has_head(&(v851_3)) { singleton(&[]) } else { Space::new() };
            drop(v851_3);
            let v851_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v851_4));
            drop(v851_4);
            let v851_8: Space = if (&(v851_5)).is_empty() { Space::new() } else {
              let v852_6: Path = concat_path(&(v850_6),&v842_27_cursor.path()[(v842_27_origin + 2)..(v842_27_origin + 3)]);
              let v852_7: Space = routine_65(c, &(v852_6), &v842_27_cursor, &(*s1));
              map_map_kernels::compose(&(v851_5),&(v852_7))
            };
            drop(v851_5);
            let v851_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v851_2));
            drop(v851_2);
            let v851_10: Space = if map_kernels::has_head(&(v851_9)) { singleton(&[]) } else { Space::new() };
            drop(v851_9);
            let v851_12: Space = if (&(v851_10)).is_empty() { Space::new() } else {
              let v853_6: Path = concat_path(&(v850_6),&v842_27_cursor.path()[(v842_27_origin + 2)..(v842_27_origin + 3)]);
              let v853_11: Space = routine_44(c, &(v853_6), &v842_27_cursor, &(*s1));
              drop(v853_6);
              map_map_kernels::compose(&(v851_10),&(v853_11))
            };
            drop(v851_10);
            let v851_13: Space = map_map_kernels::unite(&(v851_8),&(v851_12));
            join_wrapped_into(&mut v850_11_write,&((v851_13).read_zipper()),&[]);
            }
            v842_27_cursor.ascend(1);
          }
          drop(v850_11_write);
          drop(v850_6);
          map_map_kernels::compose(&(v845_10),&(v850_11))
        };
        drop(v845_10);
        let v845_13: Space = map_map_kernels::unite(&(v845_8),&(v845_12));
        join_wrapped_into(&mut v844_7_write,&((v845_13).read_zipper()),&[]);
        }
        v842_27_cursor.ascend(1);
      }
      drop(v844_7_write);
      map_map_kernels::compose(&(v843_5),&(v844_7))
    };
    drop(v843_5);
    let v843_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v843_2));
    drop(v843_2);
    let v843_10: Space = if map_kernels::has_head(&(v843_9)) { singleton(&[]) } else { Space::new() };
    drop(v843_9);
    let v843_13: Space = if (&(v843_10)).is_empty() { Space::new() } else {
      let v854_6: Path = concat_path(&(*p0),&v842_27_cursor.path()[v842_27_origin..(v842_27_origin + 1)]);
      let mut v854_12 = Space::new();
      let mut v854_12_write = v854_12.write_zipper();
      for v854_12_byte in v842_27_cursor.child_mask().iter() {
        v842_27_cursor.descend_to_existing_byte(v854_12_byte);
        {
        let v855_2: Space = singleton(&v842_27_cursor.path()[(v842_27_origin + 1)..(v842_27_origin + 2)]);
        let v855_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v855_2));
        let v855_4: Space = if map_kernels::has_head(&(v855_3)) { singleton(&[]) } else { Space::new() };
        drop(v855_3);
        let v855_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v855_4));
        drop(v855_4);
        let v855_8: Space = if (&(v855_5)).is_empty() { Space::new() } else {
          let v856_6: Path = concat_path(&(v854_6),&v842_27_cursor.path()[(v842_27_origin + 1)..(v842_27_origin + 2)]);
          let mut v856_7 = Space::new();
          let mut v856_7_write = v856_7.write_zipper();
          for v856_7_byte in v842_27_cursor.child_mask().iter() {
            v842_27_cursor.descend_to_existing_byte(v856_7_byte);
            {
            let v857_2: Space = singleton(&v842_27_cursor.path()[(v842_27_origin + 2)..(v842_27_origin + 3)]);
            let v857_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v857_2));
            let v857_4: Space = if map_kernels::has_head(&(v857_3)) { singleton(&[]) } else { Space::new() };
            drop(v857_3);
            let v857_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v857_4));
            drop(v857_4);
            let v857_8: Space = if (&(v857_5)).is_empty() { Space::new() } else {
              let v858_6: Path = concat_path(&(v856_6),&v842_27_cursor.path()[(v842_27_origin + 2)..(v842_27_origin + 3)]);
              let v858_7: Space = routine_65(c, &(v858_6), &v842_27_cursor, &(*s1));
              map_map_kernels::compose(&(v857_5),&(v858_7))
            };
            drop(v857_5);
            let v857_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v857_2));
            drop(v857_2);
            let v857_10: Space = if map_kernels::has_head(&(v857_9)) { singleton(&[]) } else { Space::new() };
            drop(v857_9);
            let v857_12: Space = if (&(v857_10)).is_empty() { Space::new() } else {
              let v859_6: Path = concat_path(&(v856_6),&v842_27_cursor.path()[(v842_27_origin + 2)..(v842_27_origin + 3)]);
              let v859_11: Space = routine_66(c, &(v859_6), &v842_27_cursor, &(*s1));
              drop(v859_6);
              map_map_kernels::compose(&(v857_10),&(v859_11))
            };
            drop(v857_10);
            let v857_13: Space = map_map_kernels::unite(&(v857_8),&(v857_12));
            join_wrapped_into(&mut v856_7_write,&((v857_13).read_zipper()),&[]);
            }
            v842_27_cursor.ascend(1);
          }
          drop(v856_7_write);
          drop(v856_6);
          map_map_kernels::compose(&(v855_5),&(v856_7))
        };
        drop(v855_5);
        let v855_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v855_2));
        drop(v855_2);
        let v855_10: Space = if map_kernels::has_head(&(v855_9)) { singleton(&[]) } else { Space::new() };
        drop(v855_9);
        let v855_13: Space = if (&(v855_10)).is_empty() { Space::new() } else {
          let v860_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v842_27_cursor.path()[v842_27_origin..(v842_27_origin + 1)]),&v842_27_cursor.path()[(v842_27_origin + 1)..(v842_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v855_10),&(v860_12))
        };
        drop(v855_10);
        let v855_14: Space = map_map_kernels::unite(&(v855_8),&(v855_13));
        drop(v855_13);
        join_wrapped_into(&mut v854_12_write,&((v855_14).read_zipper()),&[]);
        }
        v842_27_cursor.ascend(1);
      }
      drop(v854_12_write);
      drop(v854_6);
      map_map_kernels::compose(&(v843_10),&(v854_12))
    };
    drop(v843_10);
    let v843_14: Space = map_map_kernels::unite(&(v843_8),&(v843_13));
    join_wrapped_into(&mut v842_27_write,&((v843_14).read_zipper()),&[]);
    }
    v842_27_cursor.ascend(1);
  }
  drop(v842_27_cursor);
  drop(v842_27_write);
  (v842_27).clone()
}

fn routine_48(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v861_21 = Space::new();
  let mut v861_21_write = v861_21.write_zipper();
  let mut v861_21_cursor = (*s0).read_zipper();
  let v861_21_origin = v861_21_cursor.path().len();
  for v861_21_byte in v861_21_cursor.child_mask().iter() {
    v861_21_cursor.descend_to_existing_byte(v861_21_byte);
    {
    let v862_2: Space = singleton(&v861_21_cursor.path()[v861_21_origin..(v861_21_origin + 1)]);
    let v862_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v862_2));
    let v862_4: Space = if map_kernels::has_head(&(v862_3)) { singleton(&[]) } else { Space::new() };
    drop(v862_3);
    let v862_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v862_4));
    drop(v862_4);
    let v862_8: Space = if (&(v862_5)).is_empty() { Space::new() } else {
      let v863_6: Path = concat_path(&(*p0),&v861_21_cursor.path()[v861_21_origin..(v861_21_origin + 1)]);
      let mut v863_7 = Space::new();
      let mut v863_7_write = v863_7.write_zipper();
      for v863_7_byte in v861_21_cursor.child_mask().iter() {
        v861_21_cursor.descend_to_existing_byte(v863_7_byte);
        {
        let v864_2: Space = singleton(&v861_21_cursor.path()[(v861_21_origin + 1)..(v861_21_origin + 2)]);
        let v864_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v864_2));
        let v864_4: Space = if map_kernels::has_head(&(v864_3)) { singleton(&[]) } else { Space::new() };
        drop(v864_3);
        let v864_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v864_4));
        drop(v864_4);
        let v864_8: Space = if (&(v864_5)).is_empty() { Space::new() } else {
          let v865_6: Path = concat_path(&(v863_6),&v861_21_cursor.path()[(v861_21_origin + 1)..(v861_21_origin + 2)]);
          let mut v865_7 = Space::new();
          let mut v865_7_write = v865_7.write_zipper();
          for v865_7_byte in v861_21_cursor.child_mask().iter() {
            v861_21_cursor.descend_to_existing_byte(v865_7_byte);
            {
            let v866_2: Space = singleton(&v861_21_cursor.path()[(v861_21_origin + 2)..(v861_21_origin + 3)]);
            let v866_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v866_2));
            let v866_4: Space = if map_kernels::has_head(&(v866_3)) { singleton(&[]) } else { Space::new() };
            drop(v866_3);
            let v866_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v866_4));
            drop(v866_4);
            let v866_8: Space = if (&(v866_5)).is_empty() { Space::new() } else {
              let v867_6: Path = concat_path(&(v865_6),&v861_21_cursor.path()[(v861_21_origin + 2)..(v861_21_origin + 3)]);
              let v867_7: Space = routine_65(c, &(v867_6), &v861_21_cursor, &(*s1));
              map_map_kernels::compose(&(v866_5),&(v867_7))
            };
            drop(v866_5);
            let v866_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v866_2));
            drop(v866_2);
            let v866_10: Space = if map_kernels::has_head(&(v866_9)) { singleton(&[]) } else { Space::new() };
            drop(v866_9);
            let v866_12: Space = if (&(v866_10)).is_empty() { Space::new() } else {
              let v868_6: Path = concat_path(&(v865_6),&v861_21_cursor.path()[(v861_21_origin + 2)..(v861_21_origin + 3)]);
              let v868_11: Space = routine_66(c, &(v868_6), &v861_21_cursor, &(*s1));
              drop(v868_6);
              map_map_kernels::compose(&(v866_10),&(v868_11))
            };
            drop(v866_10);
            let v866_13: Space = map_map_kernels::unite(&(v866_8),&(v866_12));
            join_wrapped_into(&mut v865_7_write,&((v866_13).read_zipper()),&[]);
            }
            v861_21_cursor.ascend(1);
          }
          drop(v865_7_write);
          map_map_kernels::compose(&(v864_5),&(v865_7))
        };
        drop(v864_5);
        let v864_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v864_2));
        drop(v864_2);
        let v864_10: Space = if map_kernels::has_head(&(v864_9)) { singleton(&[]) } else { Space::new() };
        drop(v864_9);
        let v864_12: Space = if (&(v864_10)).is_empty() { Space::new() } else {
          let v869_6: Path = concat_path(&(v863_6),&v861_21_cursor.path()[(v861_21_origin + 1)..(v861_21_origin + 2)]);
          let mut v869_11 = Space::new();
          let mut v869_11_write = v869_11.write_zipper();
          for v869_11_byte in v861_21_cursor.child_mask().iter() {
            v861_21_cursor.descend_to_existing_byte(v869_11_byte);
            {
            let v870_2: Space = singleton(&v861_21_cursor.path()[(v861_21_origin + 2)..(v861_21_origin + 3)]);
            let v870_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v870_2));
            let v870_4: Space = if map_kernels::has_head(&(v870_3)) { singleton(&[]) } else { Space::new() };
            drop(v870_3);
            let v870_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v870_4));
            drop(v870_4);
            let v870_8: Space = if (&(v870_5)).is_empty() { Space::new() } else {
              let v871_6: Path = concat_path(&(v869_6),&v861_21_cursor.path()[(v861_21_origin + 2)..(v861_21_origin + 3)]);
              let v871_7: Space = routine_65(c, &(v871_6), &v861_21_cursor, &(*s1));
              map_map_kernels::compose(&(v870_5),&(v871_7))
            };
            drop(v870_5);
            let v870_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v870_2));
            drop(v870_2);
            let v870_10: Space = if map_kernels::has_head(&(v870_9)) { singleton(&[]) } else { Space::new() };
            drop(v870_9);
            let v870_12: Space = if (&(v870_10)).is_empty() { Space::new() } else {
              let v872_6: Path = concat_path(&(v869_6),&v861_21_cursor.path()[(v861_21_origin + 2)..(v861_21_origin + 3)]);
              let v872_11: Space = routine_44(c, &(v872_6), &v861_21_cursor, &(*s1));
              drop(v872_6);
              map_map_kernels::compose(&(v870_10),&(v872_11))
            };
            drop(v870_10);
            let v870_13: Space = map_map_kernels::unite(&(v870_8),&(v870_12));
            join_wrapped_into(&mut v869_11_write,&((v870_13).read_zipper()),&[]);
            }
            v861_21_cursor.ascend(1);
          }
          drop(v869_11_write);
          drop(v869_6);
          map_map_kernels::compose(&(v864_10),&(v869_11))
        };
        drop(v864_10);
        let v864_13: Space = map_map_kernels::unite(&(v864_8),&(v864_12));
        join_wrapped_into(&mut v863_7_write,&((v864_13).read_zipper()),&[]);
        }
        v861_21_cursor.ascend(1);
      }
      drop(v863_7_write);
      drop(v863_6);
      map_map_kernels::compose(&(v862_5),&(v863_7))
    };
    drop(v862_5);
    let v862_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v862_2));
    drop(v862_2);
    let v862_10: Space = if map_kernels::has_head(&(v862_9)) { singleton(&[]) } else { Space::new() };
    drop(v862_9);
    let v862_13: Space = if (&(v862_10)).is_empty() { Space::new() } else {
      let v873_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v861_21_cursor.path()[v861_21_origin..(v861_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v862_10),&(v873_12))
    };
    drop(v862_10);
    let v862_14: Space = map_map_kernels::unite(&(v862_8),&(v862_13));
    drop(v862_13);
    join_wrapped_into(&mut v861_21_write,&((v862_14).read_zipper()),&[]);
    }
    v861_21_cursor.ascend(1);
  }
  drop(v861_21_cursor);
  drop(v861_21_write);
  (v861_21).clone()
}

fn routine_49(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v874_19 = Space::new();
  let mut v874_19_write = v874_19.write_zipper();
  let mut v874_19_cursor = (*s0).read_zipper();
  let v874_19_origin = v874_19_cursor.path().len();
  for v874_19_byte in v874_19_cursor.child_mask().iter() {
    v874_19_cursor.descend_to_existing_byte(v874_19_byte);
    {
    let v875_2: Space = singleton(&v874_19_cursor.path()[v874_19_origin..(v874_19_origin + 1)]);
    let v875_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v875_2));
    let v875_4: Space = if map_kernels::has_head(&(v875_3)) { singleton(&[]) } else { Space::new() };
    drop(v875_3);
    let v875_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v875_4));
    drop(v875_4);
    let v875_8: Space = if (&(v875_5)).is_empty() { Space::new() } else {
      let v876_6: Path = concat_path(&(*p0),&v874_19_cursor.path()[v874_19_origin..(v874_19_origin + 1)]);
      let mut v876_7 = Space::new();
      let mut v876_7_write = v876_7.write_zipper();
      for v876_7_byte in v874_19_cursor.child_mask().iter() {
        v874_19_cursor.descend_to_existing_byte(v876_7_byte);
        {
        let v877_2: Space = singleton(&v874_19_cursor.path()[(v874_19_origin + 1)..(v874_19_origin + 2)]);
        let v877_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v877_2));
        let v877_4: Space = if map_kernels::has_head(&(v877_3)) { singleton(&[]) } else { Space::new() };
        drop(v877_3);
        let v877_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v877_4));
        drop(v877_4);
        let v877_7: Space = if (&(v877_5)).is_empty() { Space::new() } else {
          let mut v878_6 = Space::new();
          let mut v878_6_write = v878_6.write_zipper();
          for v878_6_byte in v874_19_cursor.child_mask().iter() {
            v874_19_cursor.descend_to_existing_byte(v878_6_byte);
            {
            let v879_2: Space = Space::new();
            join_wrapped_into(&mut v878_6_write,&((v879_2).read_zipper()),&[]);
            }
            v874_19_cursor.ascend(1);
          }
          drop(v878_6_write);
          map_map_kernels::compose(&(v877_5),&(v878_6))
        };
        drop(v877_5);
        let v877_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v877_2));
        drop(v877_2);
        let v877_9: Space = if map_kernels::has_head(&(v877_8)) { singleton(&[]) } else { Space::new() };
        drop(v877_8);
        let v877_12: Space = if (&(v877_9)).is_empty() { Space::new() } else {
          let v880_10: Path = concat_path(&(v876_6),&v874_19_cursor.path()[(v874_19_origin + 1)..(v874_19_origin + 2)]);
          let mut v880_11 = Space::new();
          let mut v880_11_write = v880_11.write_zipper();
          for v880_11_byte in v874_19_cursor.child_mask().iter() {
            v874_19_cursor.descend_to_existing_byte(v880_11_byte);
            {
            let v881_2: Space = singleton(&v874_19_cursor.path()[(v874_19_origin + 2)..(v874_19_origin + 3)]);
            let v881_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v881_2));
            drop(v881_2);
            let v881_4: Space = if map_kernels::has_head(&(v881_3)) { singleton(&[]) } else { Space::new() };
            drop(v881_3);
            let v881_7: Space = if (&(v881_4)).is_empty() { Space::new() } else {
              let v882_5: Path = concat_path(&(v880_10),&v874_19_cursor.path()[(v874_19_origin + 2)..(v874_19_origin + 3)]);
              let v882_6: Space = routine_24(c, &(v882_5), &v874_19_cursor, &(*s1));
              drop(v882_5);
              map_map_kernels::compose(&(v881_4),&(v882_6))
            };
            drop(v881_4);
            join_wrapped_into(&mut v880_11_write,&((v881_7).read_zipper()),&[]);
            }
            v874_19_cursor.ascend(1);
          }
          drop(v880_11_write);
          drop(v880_10);
          map_map_kernels::compose(&(v877_9),&(v880_11))
        };
        drop(v877_9);
        let v877_13: Space = map_map_kernels::unite(&(v877_7),&(v877_12));
        drop(v877_7);
        join_wrapped_into(&mut v876_7_write,&((v877_13).read_zipper()),&[]);
        }
        v874_19_cursor.ascend(1);
      }
      drop(v876_7_write);
      drop(v876_6);
      map_map_kernels::compose(&(v875_5),&(v876_7))
    };
    drop(v875_5);
    let v875_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v875_2));
    drop(v875_2);
    let v875_10: Space = if map_kernels::has_head(&(v875_9)) { singleton(&[]) } else { Space::new() };
    drop(v875_9);
    let v875_13: Space = if (&(v875_10)).is_empty() { Space::new() } else {
      let mut v883_12 = Space::new();
      let mut v883_12_write = v883_12.write_zipper();
      for v883_12_byte in v874_19_cursor.child_mask().iter() {
        v874_19_cursor.descend_to_existing_byte(v883_12_byte);
        {
        let v884_2: Space = singleton(&v874_19_cursor.path()[(v874_19_origin + 1)..(v874_19_origin + 2)]);
        let v884_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v884_2));
        let v884_4: Space = if map_kernels::has_head(&(v884_3)) { singleton(&[]) } else { Space::new() };
        drop(v884_3);
        let v884_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v884_4));
        drop(v884_4);
        let v884_7: Space = if (&(v884_5)).is_empty() { Space::new() } else {
          let mut v885_6 = Space::new();
          let mut v885_6_write = v885_6.write_zipper();
          for v885_6_byte in v874_19_cursor.child_mask().iter() {
            v874_19_cursor.descend_to_existing_byte(v885_6_byte);
            {
            let v886_2: Space = Space::new();
            join_wrapped_into(&mut v885_6_write,&((v886_2).read_zipper()),&[]);
            }
            v874_19_cursor.ascend(1);
          }
          drop(v885_6_write);
          map_map_kernels::compose(&(v884_5),&(v885_6))
        };
        drop(v884_5);
        let v884_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v884_2));
        drop(v884_2);
        let v884_9: Space = if map_kernels::has_head(&(v884_8)) { singleton(&[]) } else { Space::new() };
        drop(v884_8);
        let v884_12: Space = if (&(v884_9)).is_empty() { Space::new() } else {
          let v887_11: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v874_19_cursor.path()[v874_19_origin..(v874_19_origin + 1)]),&v874_19_cursor.path()[(v874_19_origin + 1)..(v874_19_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v884_9),&(v887_11))
        };
        drop(v884_9);
        let v884_13: Space = map_map_kernels::unite(&(v884_7),&(v884_12));
        drop(v884_7);
        drop(v884_12);
        join_wrapped_into(&mut v883_12_write,&((v884_13).read_zipper()),&[]);
        }
        v874_19_cursor.ascend(1);
      }
      drop(v883_12_write);
      map_map_kernels::compose(&(v875_10),&(v883_12))
    };
    drop(v875_10);
    let v875_14: Space = map_map_kernels::unite(&(v875_8),&(v875_13));
    drop(v875_13);
    join_wrapped_into(&mut v874_19_write,&((v875_14).read_zipper()),&[]);
    }
    v874_19_cursor.ascend(1);
  }
  drop(v874_19_cursor);
  drop(v874_19_write);
  (v874_19).clone()
}

fn routine_50(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v888_16 = Space::new();
  let mut v888_16_write = v888_16.write_zipper();
  let mut v888_16_cursor = (*s0).read_zipper();
  let v888_16_origin = v888_16_cursor.path().len();
  for v888_16_byte in v888_16_cursor.child_mask().iter() {
    v888_16_cursor.descend_to_existing_byte(v888_16_byte);
    {
    let v889_2: Space = singleton(&v888_16_cursor.path()[v888_16_origin..(v888_16_origin + 1)]);
    let v889_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v889_2));
    let v889_4: Space = if map_kernels::has_head(&(v889_3)) { singleton(&[]) } else { Space::new() };
    drop(v889_3);
    let v889_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v889_4));
    drop(v889_4);
    let v889_8: Space = if (&(v889_5)).is_empty() { Space::new() } else {
      let v890_6: Path = concat_path(&(*p0),&v888_16_cursor.path()[v888_16_origin..(v888_16_origin + 1)]);
      let mut v890_7 = Space::new();
      let mut v890_7_write = v890_7.write_zipper();
      for v890_7_byte in v888_16_cursor.child_mask().iter() {
        v888_16_cursor.descend_to_existing_byte(v890_7_byte);
        {
        let v891_2: Space = singleton(&v888_16_cursor.path()[(v888_16_origin + 1)..(v888_16_origin + 2)]);
        let v891_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v891_2));
        let v891_4: Space = if map_kernels::has_head(&(v891_3)) { singleton(&[]) } else { Space::new() };
        drop(v891_3);
        let v891_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v891_4));
        drop(v891_4);
        let v891_7: Space = if (&(v891_5)).is_empty() { Space::new() } else {
          let mut v892_6 = Space::new();
          let mut v892_6_write = v892_6.write_zipper();
          for v892_6_byte in v888_16_cursor.child_mask().iter() {
            v888_16_cursor.descend_to_existing_byte(v892_6_byte);
            {
            let v893_2: Space = Space::new();
            join_wrapped_into(&mut v892_6_write,&((v893_2).read_zipper()),&[]);
            }
            v888_16_cursor.ascend(1);
          }
          drop(v892_6_write);
          map_map_kernels::compose(&(v891_5),&(v892_6))
        };
        drop(v891_5);
        let v891_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v891_2));
        drop(v891_2);
        let v891_9: Space = if map_kernels::has_head(&(v891_8)) { singleton(&[]) } else { Space::new() };
        drop(v891_8);
        let v891_12: Space = if (&(v891_9)).is_empty() { Space::new() } else {
          let v894_10: Path = concat_path(&(v890_6),&v888_16_cursor.path()[(v888_16_origin + 1)..(v888_16_origin + 2)]);
          let mut v894_11 = Space::new();
          let mut v894_11_write = v894_11.write_zipper();
          for v894_11_byte in v888_16_cursor.child_mask().iter() {
            v888_16_cursor.descend_to_existing_byte(v894_11_byte);
            {
            let v895_2: Space = singleton(&v888_16_cursor.path()[(v888_16_origin + 2)..(v888_16_origin + 3)]);
            let v895_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v895_2));
            drop(v895_2);
            let v895_4: Space = if map_kernels::has_head(&(v895_3)) { singleton(&[]) } else { Space::new() };
            drop(v895_3);
            let v895_7: Space = if (&(v895_4)).is_empty() { Space::new() } else {
              let v896_5: Path = concat_path(&(v894_10),&v888_16_cursor.path()[(v888_16_origin + 2)..(v888_16_origin + 3)]);
              let v896_6: Space = routine_24(c, &(v896_5), &v888_16_cursor, &(*s1));
              drop(v896_5);
              map_map_kernels::compose(&(v895_4),&(v896_6))
            };
            drop(v895_4);
            join_wrapped_into(&mut v894_11_write,&((v895_7).read_zipper()),&[]);
            }
            v888_16_cursor.ascend(1);
          }
          drop(v894_11_write);
          drop(v894_10);
          map_map_kernels::compose(&(v891_9),&(v894_11))
        };
        drop(v891_9);
        let v891_13: Space = map_map_kernels::unite(&(v891_7),&(v891_12));
        drop(v891_7);
        join_wrapped_into(&mut v890_7_write,&((v891_13).read_zipper()),&[]);
        }
        v888_16_cursor.ascend(1);
      }
      drop(v890_7_write);
      drop(v890_6);
      map_map_kernels::compose(&(v889_5),&(v890_7))
    };
    drop(v889_5);
    let v889_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v889_2));
    drop(v889_2);
    let v889_10: Space = if map_kernels::has_head(&(v889_9)) { singleton(&[]) } else { Space::new() };
    drop(v889_9);
    let v889_13: Space = if (&(v889_10)).is_empty() { Space::new() } else {
      let v897_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v888_16_cursor.path()[v888_16_origin..(v888_16_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v889_10),&(v897_12))
    };
    drop(v889_10);
    let v889_14: Space = map_map_kernels::unite(&(v889_8),&(v889_13));
    drop(v889_13);
    join_wrapped_into(&mut v888_16_write,&((v889_14).read_zipper()),&[]);
    }
    v888_16_cursor.ascend(1);
  }
  drop(v888_16_cursor);
  drop(v888_16_write);
  (v888_16).clone()
}

fn routine_51(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v898_13 = Space::new();
  let mut v898_13_write = v898_13.write_zipper();
  let mut v898_13_cursor = (*s0).read_zipper();
  let v898_13_origin = v898_13_cursor.path().len();
  for v898_13_byte in v898_13_cursor.child_mask().iter() {
    v898_13_cursor.descend_to_existing_byte(v898_13_byte);
    {
    let v899_2: Space = singleton(&v898_13_cursor.path()[v898_13_origin..(v898_13_origin + 1)]);
    let v899_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v899_2));
    let v899_4: Space = if map_kernels::has_head(&(v899_3)) { singleton(&[]) } else { Space::new() };
    drop(v899_3);
    let v899_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v899_4));
    drop(v899_4);
    let v899_7: Space = if (&(v899_5)).is_empty() { Space::new() } else {
      let mut v900_6 = Space::new();
      let mut v900_6_write = v900_6.write_zipper();
      for v900_6_byte in v898_13_cursor.child_mask().iter() {
        v898_13_cursor.descend_to_existing_byte(v900_6_byte);
        {
        let v901_2: Space = Space::new();
        join_wrapped_into(&mut v900_6_write,&((v901_2).read_zipper()),&[]);
        }
        v898_13_cursor.ascend(1);
      }
      drop(v900_6_write);
      map_map_kernels::compose(&(v899_5),&(v900_6))
    };
    drop(v899_5);
    let v899_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v899_2));
    drop(v899_2);
    let v899_9: Space = if map_kernels::has_head(&(v899_8)) { singleton(&[]) } else { Space::new() };
    drop(v899_8);
    let v899_12: Space = if (&(v899_9)).is_empty() { Space::new() } else {
      let mut v902_11 = Space::new();
      let mut v902_11_write = v902_11.write_zipper();
      for v902_11_byte in v898_13_cursor.child_mask().iter() {
        v898_13_cursor.descend_to_existing_byte(v902_11_byte);
        {
        let v903_2: Space = singleton(&v898_13_cursor.path()[(v898_13_origin + 1)..(v898_13_origin + 2)]);
        let v903_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v903_2));
        drop(v903_2);
        let v903_4: Space = if map_kernels::has_head(&(v903_3)) { singleton(&[]) } else { Space::new() };
        drop(v903_3);
        let v903_7: Space = if (&(v903_4)).is_empty() { Space::new() } else {
          let v904_6: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v898_13_cursor.path()[v898_13_origin..(v898_13_origin + 1)]),&v898_13_cursor.path()[(v898_13_origin + 1)..(v898_13_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v903_4),&(v904_6))
        };
        drop(v903_4);
        join_wrapped_into(&mut v902_11_write,&((v903_7).read_zipper()),&[]);
        }
        v898_13_cursor.ascend(1);
      }
      drop(v902_11_write);
      map_map_kernels::compose(&(v899_9),&(v902_11))
    };
    drop(v899_9);
    let v899_13: Space = map_map_kernels::unite(&(v899_7),&(v899_12));
    drop(v899_7);
    drop(v899_12);
    join_wrapped_into(&mut v898_13_write,&((v899_13).read_zipper()),&[]);
    }
    v898_13_cursor.ascend(1);
  }
  drop(v898_13_cursor);
  drop(v898_13_write);
  (v898_13).clone()
}

fn routine_52(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v905_12 = Space::new();
  let mut v905_12_write = v905_12.write_zipper();
  let mut v905_12_cursor = (*s0).read_zipper();
  let v905_12_origin = v905_12_cursor.path().len();
  for v905_12_byte in v905_12_cursor.child_mask().iter() {
    v905_12_cursor.descend_to_existing_byte(v905_12_byte);
    {
    let v906_2: Space = singleton(&v905_12_cursor.path()[v905_12_origin..(v905_12_origin + 1)]);
    let v906_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v906_2));
    let v906_4: Space = if map_kernels::has_head(&(v906_3)) { singleton(&[]) } else { Space::new() };
    drop(v906_3);
    let v906_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v906_4));
    drop(v906_4);
    let v906_7: Space = if (&(v906_5)).is_empty() { Space::new() } else {
      let mut v907_6 = Space::new();
      let mut v907_6_write = v907_6.write_zipper();
      for v907_6_byte in v905_12_cursor.child_mask().iter() {
        v905_12_cursor.descend_to_existing_byte(v907_6_byte);
        {
        let v908_2: Space = Space::new();
        join_wrapped_into(&mut v907_6_write,&((v908_2).read_zipper()),&[]);
        }
        v905_12_cursor.ascend(1);
      }
      drop(v907_6_write);
      map_map_kernels::compose(&(v906_5),&(v907_6))
    };
    drop(v906_5);
    let v906_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v906_2));
    drop(v906_2);
    let v906_9: Space = if map_kernels::has_head(&(v906_8)) { singleton(&[]) } else { Space::new() };
    drop(v906_8);
    let v906_12: Space = if (&(v906_9)).is_empty() { Space::new() } else {
      let v909_11: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v905_12_cursor.path()[v905_12_origin..(v905_12_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v906_9),&(v909_11))
    };
    drop(v906_9);
    let v906_13: Space = map_map_kernels::unite(&(v906_7),&(v906_12));
    drop(v906_7);
    drop(v906_12);
    join_wrapped_into(&mut v905_12_write,&((v906_13).read_zipper()),&[]);
    }
    v905_12_cursor.ascend(1);
  }
  drop(v905_12_cursor);
  drop(v905_12_write);
  (v905_12).clone()
}

fn routine_53(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v910_3 = Space::new();
  let mut v910_3_write = v910_3.write_zipper();
  let mut v910_3_cursor = (*s0).read_zipper();
  let v910_3_origin = v910_3_cursor.path().len();
  for v910_3_byte in v910_3_cursor.child_mask().iter() {
    v910_3_cursor.descend_to_existing_byte(v910_3_byte);
    {
    let v911_2: Space = Space::new();
    join_wrapped_into(&mut v910_3_write,&((v911_2).read_zipper()),&[]);
    }
    v910_3_cursor.ascend(1);
  }
  drop(v910_3_cursor);
  drop(v910_3_write);
  (v910_3).clone()
}

fn routine_54(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v912_10 = Space::new();
  let mut v912_10_write = v912_10.write_zipper();
  let mut v912_10_cursor = (*s0).read_zipper();
  let v912_10_origin = v912_10_cursor.path().len();
  for v912_10_byte in v912_10_cursor.child_mask().iter() {
    v912_10_cursor.descend_to_existing_byte(v912_10_byte);
    {
    let v913_2: Space = singleton(&v912_10_cursor.path()[v912_10_origin..(v912_10_origin + 1)]);
    let v913_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v913_2));
    drop(v913_2);
    let v913_4: Space = if map_kernels::has_head(&(v913_3)) { singleton(&[]) } else { Space::new() };
    drop(v913_3);
    let v913_7: Space = if (&(v913_4)).is_empty() { Space::new() } else {
      let v914_6: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v912_10_cursor.path()[v912_10_origin..(v912_10_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v913_4),&(v914_6))
    };
    drop(v913_4);
    join_wrapped_into(&mut v912_10_write,&((v913_7).read_zipper()),&[]);
    }
    v912_10_cursor.ascend(1);
  }
  drop(v912_10_cursor);
  drop(v912_10_write);
  (v912_10).clone()
}

fn routine_55(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v915_19 = Space::new();
  let mut v915_19_write = v915_19.write_zipper();
  let mut v915_19_cursor = (*s0).read_zipper();
  let v915_19_origin = v915_19_cursor.path().len();
  for v915_19_byte in v915_19_cursor.child_mask().iter() {
    v915_19_cursor.descend_to_existing_byte(v915_19_byte);
    {
    let v916_2: Space = singleton(&v915_19_cursor.path()[v915_19_origin..(v915_19_origin + 1)]);
    let v916_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v916_2));
    let v916_4: Space = if map_kernels::has_head(&(v916_3)) { singleton(&[]) } else { Space::new() };
    drop(v916_3);
    let v916_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v916_4));
    drop(v916_4);
    let v916_8: Space = if (&(v916_5)).is_empty() { Space::new() } else {
      let v917_6: Path = concat_path(&(*p0),&v915_19_cursor.path()[v915_19_origin..(v915_19_origin + 1)]);
      let mut v917_7 = Space::new();
      let mut v917_7_write = v917_7.write_zipper();
      for v917_7_byte in v915_19_cursor.child_mask().iter() {
        v915_19_cursor.descend_to_existing_byte(v917_7_byte);
        {
        let v918_2: Space = singleton(&v915_19_cursor.path()[(v915_19_origin + 1)..(v915_19_origin + 2)]);
        let v918_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v918_2));
        let v918_4: Space = if map_kernels::has_head(&(v918_3)) { singleton(&[]) } else { Space::new() };
        drop(v918_3);
        let v918_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v918_4));
        drop(v918_4);
        let v918_7: Space = if (&(v918_5)).is_empty() { Space::new() } else {
          let mut v919_6 = Space::new();
          let mut v919_6_write = v919_6.write_zipper();
          for v919_6_byte in v915_19_cursor.child_mask().iter() {
            v915_19_cursor.descend_to_existing_byte(v919_6_byte);
            {
            let v920_2: Space = Space::new();
            join_wrapped_into(&mut v919_6_write,&((v920_2).read_zipper()),&[]);
            }
            v915_19_cursor.ascend(1);
          }
          drop(v919_6_write);
          map_map_kernels::compose(&(v918_5),&(v919_6))
        };
        drop(v918_5);
        let v918_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v918_2));
        drop(v918_2);
        let v918_9: Space = if map_kernels::has_head(&(v918_8)) { singleton(&[]) } else { Space::new() };
        drop(v918_8);
        let v918_12: Space = if (&(v918_9)).is_empty() { Space::new() } else {
          let v921_10: Path = concat_path(&(v917_6),&v915_19_cursor.path()[(v915_19_origin + 1)..(v915_19_origin + 2)]);
          let mut v921_11 = Space::new();
          let mut v921_11_write = v921_11.write_zipper();
          for v921_11_byte in v915_19_cursor.child_mask().iter() {
            v915_19_cursor.descend_to_existing_byte(v921_11_byte);
            {
            let v922_2: Space = singleton(&v915_19_cursor.path()[(v915_19_origin + 2)..(v915_19_origin + 3)]);
            let v922_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v922_2));
            drop(v922_2);
            let v922_4: Space = if map_kernels::has_head(&(v922_3)) { singleton(&[]) } else { Space::new() };
            drop(v922_3);
            let v922_7: Space = if (&(v922_4)).is_empty() { Space::new() } else {
              let v923_5: Path = concat_path(&(v921_10),&v915_19_cursor.path()[(v915_19_origin + 2)..(v915_19_origin + 3)]);
              let v923_6: Space = routine_33(c, &(v923_5), &v915_19_cursor, &(*s1));
              drop(v923_5);
              map_map_kernels::compose(&(v922_4),&(v923_6))
            };
            drop(v922_4);
            join_wrapped_into(&mut v921_11_write,&((v922_7).read_zipper()),&[]);
            }
            v915_19_cursor.ascend(1);
          }
          drop(v921_11_write);
          drop(v921_10);
          map_map_kernels::compose(&(v918_9),&(v921_11))
        };
        drop(v918_9);
        let v918_13: Space = map_map_kernels::unite(&(v918_7),&(v918_12));
        drop(v918_7);
        join_wrapped_into(&mut v917_7_write,&((v918_13).read_zipper()),&[]);
        }
        v915_19_cursor.ascend(1);
      }
      drop(v917_7_write);
      drop(v917_6);
      map_map_kernels::compose(&(v916_5),&(v917_7))
    };
    drop(v916_5);
    let v916_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v916_2));
    drop(v916_2);
    let v916_10: Space = if map_kernels::has_head(&(v916_9)) { singleton(&[]) } else { Space::new() };
    drop(v916_9);
    let v916_13: Space = if (&(v916_10)).is_empty() { Space::new() } else {
      let mut v924_12 = Space::new();
      let mut v924_12_write = v924_12.write_zipper();
      for v924_12_byte in v915_19_cursor.child_mask().iter() {
        v915_19_cursor.descend_to_existing_byte(v924_12_byte);
        {
        let v925_2: Space = singleton(&v915_19_cursor.path()[(v915_19_origin + 1)..(v915_19_origin + 2)]);
        let v925_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v925_2));
        let v925_4: Space = if map_kernels::has_head(&(v925_3)) { singleton(&[]) } else { Space::new() };
        drop(v925_3);
        let v925_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v925_4));
        drop(v925_4);
        let v925_7: Space = if (&(v925_5)).is_empty() { Space::new() } else {
          let mut v926_6 = Space::new();
          let mut v926_6_write = v926_6.write_zipper();
          for v926_6_byte in v915_19_cursor.child_mask().iter() {
            v915_19_cursor.descend_to_existing_byte(v926_6_byte);
            {
            let v927_2: Space = Space::new();
            join_wrapped_into(&mut v926_6_write,&((v927_2).read_zipper()),&[]);
            }
            v915_19_cursor.ascend(1);
          }
          drop(v926_6_write);
          map_map_kernels::compose(&(v925_5),&(v926_6))
        };
        drop(v925_5);
        let v925_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v925_2));
        drop(v925_2);
        let v925_9: Space = if map_kernels::has_head(&(v925_8)) { singleton(&[]) } else { Space::new() };
        drop(v925_8);
        let v925_12: Space = if (&(v925_9)).is_empty() { Space::new() } else {
          let v928_11: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v915_19_cursor.path()[v915_19_origin..(v915_19_origin + 1)]),&v915_19_cursor.path()[(v915_19_origin + 1)..(v915_19_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v925_9),&(v928_11))
        };
        drop(v925_9);
        let v925_13: Space = map_map_kernels::unite(&(v925_7),&(v925_12));
        drop(v925_7);
        drop(v925_12);
        join_wrapped_into(&mut v924_12_write,&((v925_13).read_zipper()),&[]);
        }
        v915_19_cursor.ascend(1);
      }
      drop(v924_12_write);
      map_map_kernels::compose(&(v916_10),&(v924_12))
    };
    drop(v916_10);
    let v916_14: Space = map_map_kernels::unite(&(v916_8),&(v916_13));
    drop(v916_13);
    join_wrapped_into(&mut v915_19_write,&((v916_14).read_zipper()),&[]);
    }
    v915_19_cursor.ascend(1);
  }
  drop(v915_19_cursor);
  drop(v915_19_write);
  (v915_19).clone()
}

fn routine_56(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v929_16 = Space::new();
  let mut v929_16_write = v929_16.write_zipper();
  let mut v929_16_cursor = (*s0).read_zipper();
  let v929_16_origin = v929_16_cursor.path().len();
  for v929_16_byte in v929_16_cursor.child_mask().iter() {
    v929_16_cursor.descend_to_existing_byte(v929_16_byte);
    {
    let v930_2: Space = singleton(&v929_16_cursor.path()[v929_16_origin..(v929_16_origin + 1)]);
    let v930_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v930_2));
    let v930_4: Space = if map_kernels::has_head(&(v930_3)) { singleton(&[]) } else { Space::new() };
    drop(v930_3);
    let v930_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v930_4));
    drop(v930_4);
    let v930_8: Space = if (&(v930_5)).is_empty() { Space::new() } else {
      let v931_6: Path = concat_path(&(*p0),&v929_16_cursor.path()[v929_16_origin..(v929_16_origin + 1)]);
      let mut v931_7 = Space::new();
      let mut v931_7_write = v931_7.write_zipper();
      for v931_7_byte in v929_16_cursor.child_mask().iter() {
        v929_16_cursor.descend_to_existing_byte(v931_7_byte);
        {
        let v932_2: Space = singleton(&v929_16_cursor.path()[(v929_16_origin + 1)..(v929_16_origin + 2)]);
        let v932_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v932_2));
        let v932_4: Space = if map_kernels::has_head(&(v932_3)) { singleton(&[]) } else { Space::new() };
        drop(v932_3);
        let v932_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v932_4));
        drop(v932_4);
        let v932_7: Space = if (&(v932_5)).is_empty() { Space::new() } else {
          let mut v933_6 = Space::new();
          let mut v933_6_write = v933_6.write_zipper();
          for v933_6_byte in v929_16_cursor.child_mask().iter() {
            v929_16_cursor.descend_to_existing_byte(v933_6_byte);
            {
            let v934_2: Space = Space::new();
            join_wrapped_into(&mut v933_6_write,&((v934_2).read_zipper()),&[]);
            }
            v929_16_cursor.ascend(1);
          }
          drop(v933_6_write);
          map_map_kernels::compose(&(v932_5),&(v933_6))
        };
        drop(v932_5);
        let v932_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v932_2));
        drop(v932_2);
        let v932_9: Space = if map_kernels::has_head(&(v932_8)) { singleton(&[]) } else { Space::new() };
        drop(v932_8);
        let v932_12: Space = if (&(v932_9)).is_empty() { Space::new() } else {
          let v935_10: Path = concat_path(&(v931_6),&v929_16_cursor.path()[(v929_16_origin + 1)..(v929_16_origin + 2)]);
          let mut v935_11 = Space::new();
          let mut v935_11_write = v935_11.write_zipper();
          for v935_11_byte in v929_16_cursor.child_mask().iter() {
            v929_16_cursor.descend_to_existing_byte(v935_11_byte);
            {
            let v936_2: Space = singleton(&v929_16_cursor.path()[(v929_16_origin + 2)..(v929_16_origin + 3)]);
            let v936_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v936_2));
            drop(v936_2);
            let v936_4: Space = if map_kernels::has_head(&(v936_3)) { singleton(&[]) } else { Space::new() };
            drop(v936_3);
            let v936_7: Space = if (&(v936_4)).is_empty() { Space::new() } else {
              let v937_5: Path = concat_path(&(v935_10),&v929_16_cursor.path()[(v929_16_origin + 2)..(v929_16_origin + 3)]);
              let v937_6: Space = routine_33(c, &(v937_5), &v929_16_cursor, &(*s1));
              drop(v937_5);
              map_map_kernels::compose(&(v936_4),&(v937_6))
            };
            drop(v936_4);
            join_wrapped_into(&mut v935_11_write,&((v936_7).read_zipper()),&[]);
            }
            v929_16_cursor.ascend(1);
          }
          drop(v935_11_write);
          drop(v935_10);
          map_map_kernels::compose(&(v932_9),&(v935_11))
        };
        drop(v932_9);
        let v932_13: Space = map_map_kernels::unite(&(v932_7),&(v932_12));
        drop(v932_7);
        join_wrapped_into(&mut v931_7_write,&((v932_13).read_zipper()),&[]);
        }
        v929_16_cursor.ascend(1);
      }
      drop(v931_7_write);
      drop(v931_6);
      map_map_kernels::compose(&(v930_5),&(v931_7))
    };
    drop(v930_5);
    let v930_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v930_2));
    drop(v930_2);
    let v930_10: Space = if map_kernels::has_head(&(v930_9)) { singleton(&[]) } else { Space::new() };
    drop(v930_9);
    let v930_13: Space = if (&(v930_10)).is_empty() { Space::new() } else {
      let v938_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v929_16_cursor.path()[v929_16_origin..(v929_16_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v930_10),&(v938_12))
    };
    drop(v930_10);
    let v930_14: Space = map_map_kernels::unite(&(v930_8),&(v930_13));
    drop(v930_13);
    join_wrapped_into(&mut v929_16_write,&((v930_14).read_zipper()),&[]);
    }
    v929_16_cursor.ascend(1);
  }
  drop(v929_16_cursor);
  drop(v929_16_write);
  (v929_16).clone()
}

fn routine_57(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v939_13 = Space::new();
  let mut v939_13_write = v939_13.write_zipper();
  let mut v939_13_cursor = (*s0).read_zipper();
  let v939_13_origin = v939_13_cursor.path().len();
  for v939_13_byte in v939_13_cursor.child_mask().iter() {
    v939_13_cursor.descend_to_existing_byte(v939_13_byte);
    {
    let v940_2: Space = singleton(&v939_13_cursor.path()[v939_13_origin..(v939_13_origin + 1)]);
    let v940_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v940_2));
    let v940_4: Space = if map_kernels::has_head(&(v940_3)) { singleton(&[]) } else { Space::new() };
    drop(v940_3);
    let v940_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v940_4));
    drop(v940_4);
    let v940_7: Space = if (&(v940_5)).is_empty() { Space::new() } else {
      let mut v941_6 = Space::new();
      let mut v941_6_write = v941_6.write_zipper();
      for v941_6_byte in v939_13_cursor.child_mask().iter() {
        v939_13_cursor.descend_to_existing_byte(v941_6_byte);
        {
        let v942_2: Space = Space::new();
        join_wrapped_into(&mut v941_6_write,&((v942_2).read_zipper()),&[]);
        }
        v939_13_cursor.ascend(1);
      }
      drop(v941_6_write);
      map_map_kernels::compose(&(v940_5),&(v941_6))
    };
    drop(v940_5);
    let v940_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v940_2));
    drop(v940_2);
    let v940_9: Space = if map_kernels::has_head(&(v940_8)) { singleton(&[]) } else { Space::new() };
    drop(v940_8);
    let v940_12: Space = if (&(v940_9)).is_empty() { Space::new() } else {
      let mut v943_11 = Space::new();
      let mut v943_11_write = v943_11.write_zipper();
      for v943_11_byte in v939_13_cursor.child_mask().iter() {
        v939_13_cursor.descend_to_existing_byte(v943_11_byte);
        {
        let v944_2: Space = singleton(&v939_13_cursor.path()[(v939_13_origin + 1)..(v939_13_origin + 2)]);
        let v944_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v944_2));
        drop(v944_2);
        let v944_4: Space = if map_kernels::has_head(&(v944_3)) { singleton(&[]) } else { Space::new() };
        drop(v944_3);
        let v944_7: Space = if (&(v944_4)).is_empty() { Space::new() } else {
          let v945_6: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v939_13_cursor.path()[v939_13_origin..(v939_13_origin + 1)]),&v939_13_cursor.path()[(v939_13_origin + 1)..(v939_13_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v944_4),&(v945_6))
        };
        drop(v944_4);
        join_wrapped_into(&mut v943_11_write,&((v944_7).read_zipper()),&[]);
        }
        v939_13_cursor.ascend(1);
      }
      drop(v943_11_write);
      map_map_kernels::compose(&(v940_9),&(v943_11))
    };
    drop(v940_9);
    let v940_13: Space = map_map_kernels::unite(&(v940_7),&(v940_12));
    drop(v940_7);
    drop(v940_12);
    join_wrapped_into(&mut v939_13_write,&((v940_13).read_zipper()),&[]);
    }
    v939_13_cursor.ascend(1);
  }
  drop(v939_13_cursor);
  drop(v939_13_write);
  (v939_13).clone()
}

fn routine_58(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v946_12 = Space::new();
  let mut v946_12_write = v946_12.write_zipper();
  let mut v946_12_cursor = (*s0).read_zipper();
  let v946_12_origin = v946_12_cursor.path().len();
  for v946_12_byte in v946_12_cursor.child_mask().iter() {
    v946_12_cursor.descend_to_existing_byte(v946_12_byte);
    {
    let v947_2: Space = singleton(&v946_12_cursor.path()[v946_12_origin..(v946_12_origin + 1)]);
    let v947_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v947_2));
    let v947_4: Space = if map_kernels::has_head(&(v947_3)) { singleton(&[]) } else { Space::new() };
    drop(v947_3);
    let v947_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v947_4));
    drop(v947_4);
    let v947_7: Space = if (&(v947_5)).is_empty() { Space::new() } else {
      let mut v948_6 = Space::new();
      let mut v948_6_write = v948_6.write_zipper();
      for v948_6_byte in v946_12_cursor.child_mask().iter() {
        v946_12_cursor.descend_to_existing_byte(v948_6_byte);
        {
        let v949_2: Space = Space::new();
        join_wrapped_into(&mut v948_6_write,&((v949_2).read_zipper()),&[]);
        }
        v946_12_cursor.ascend(1);
      }
      drop(v948_6_write);
      map_map_kernels::compose(&(v947_5),&(v948_6))
    };
    drop(v947_5);
    let v947_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v947_2));
    drop(v947_2);
    let v947_9: Space = if map_kernels::has_head(&(v947_8)) { singleton(&[]) } else { Space::new() };
    drop(v947_8);
    let v947_12: Space = if (&(v947_9)).is_empty() { Space::new() } else {
      let v950_11: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v946_12_cursor.path()[v946_12_origin..(v946_12_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v947_9),&(v950_11))
    };
    drop(v947_9);
    let v947_13: Space = map_map_kernels::unite(&(v947_7),&(v947_12));
    drop(v947_7);
    drop(v947_12);
    join_wrapped_into(&mut v946_12_write,&((v947_13).read_zipper()),&[]);
    }
    v946_12_cursor.ascend(1);
  }
  drop(v946_12_cursor);
  drop(v946_12_write);
  (v946_12).clone()
}

fn routine_59(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v951_3 = Space::new();
  let mut v951_3_write = v951_3.write_zipper();
  let mut v951_3_cursor = (*s0).read_zipper();
  let v951_3_origin = v951_3_cursor.path().len();
  for v951_3_byte in v951_3_cursor.child_mask().iter() {
    v951_3_cursor.descend_to_existing_byte(v951_3_byte);
    {
    let v952_2: Space = Space::new();
    join_wrapped_into(&mut v951_3_write,&((v952_2).read_zipper()),&[]);
    }
    v951_3_cursor.ascend(1);
  }
  drop(v951_3_cursor);
  drop(v951_3_write);
  (v951_3).clone()
}

fn routine_60(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v953_10 = Space::new();
  let mut v953_10_write = v953_10.write_zipper();
  let mut v953_10_cursor = (*s0).read_zipper();
  let v953_10_origin = v953_10_cursor.path().len();
  for v953_10_byte in v953_10_cursor.child_mask().iter() {
    v953_10_cursor.descend_to_existing_byte(v953_10_byte);
    {
    let v954_2: Space = singleton(&v953_10_cursor.path()[v953_10_origin..(v953_10_origin + 1)]);
    let v954_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v954_2));
    drop(v954_2);
    let v954_4: Space = if map_kernels::has_head(&(v954_3)) { singleton(&[]) } else { Space::new() };
    drop(v954_3);
    let v954_7: Space = if (&(v954_4)).is_empty() { Space::new() } else {
      let v955_6: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v953_10_cursor.path()[v953_10_origin..(v953_10_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v954_4),&(v955_6))
    };
    drop(v954_4);
    join_wrapped_into(&mut v953_10_write,&((v954_7).read_zipper()),&[]);
    }
    v953_10_cursor.ascend(1);
  }
  drop(v953_10_cursor);
  drop(v953_10_write);
  (v953_10).clone()
}

fn routine_61(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v956_19 = Space::new();
  let mut v956_19_write = v956_19.write_zipper();
  let mut v956_19_cursor = (*s0).read_zipper();
  let v956_19_origin = v956_19_cursor.path().len();
  for v956_19_byte in v956_19_cursor.child_mask().iter() {
    v956_19_cursor.descend_to_existing_byte(v956_19_byte);
    {
    let v957_2: Space = singleton(&v956_19_cursor.path()[v956_19_origin..(v956_19_origin + 1)]);
    let v957_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v957_2));
    let v957_4: Space = if map_kernels::has_head(&(v957_3)) { singleton(&[]) } else { Space::new() };
    drop(v957_3);
    let v957_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v957_4));
    drop(v957_4);
    let v957_8: Space = if (&(v957_5)).is_empty() { Space::new() } else {
      let v958_6: Path = concat_path(&(*p0),&v956_19_cursor.path()[v956_19_origin..(v956_19_origin + 1)]);
      let mut v958_7 = Space::new();
      let mut v958_7_write = v958_7.write_zipper();
      for v958_7_byte in v956_19_cursor.child_mask().iter() {
        v956_19_cursor.descend_to_existing_byte(v958_7_byte);
        {
        let v959_2: Space = singleton(&v956_19_cursor.path()[(v956_19_origin + 1)..(v956_19_origin + 2)]);
        let v959_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v959_2));
        let v959_4: Space = if map_kernels::has_head(&(v959_3)) { singleton(&[]) } else { Space::new() };
        drop(v959_3);
        let v959_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v959_4));
        drop(v959_4);
        let v959_7: Space = if (&(v959_5)).is_empty() { Space::new() } else {
          let mut v960_6 = Space::new();
          let mut v960_6_write = v960_6.write_zipper();
          for v960_6_byte in v956_19_cursor.child_mask().iter() {
            v956_19_cursor.descend_to_existing_byte(v960_6_byte);
            {
            let v961_2: Space = Space::new();
            join_wrapped_into(&mut v960_6_write,&((v961_2).read_zipper()),&[]);
            }
            v956_19_cursor.ascend(1);
          }
          drop(v960_6_write);
          map_map_kernels::compose(&(v959_5),&(v960_6))
        };
        drop(v959_5);
        let v959_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v959_2));
        drop(v959_2);
        let v959_9: Space = if map_kernels::has_head(&(v959_8)) { singleton(&[]) } else { Space::new() };
        drop(v959_8);
        let v959_12: Space = if (&(v959_9)).is_empty() { Space::new() } else {
          let v962_10: Path = concat_path(&(v958_6),&v956_19_cursor.path()[(v956_19_origin + 1)..(v956_19_origin + 2)]);
          let mut v962_11 = Space::new();
          let mut v962_11_write = v962_11.write_zipper();
          for v962_11_byte in v956_19_cursor.child_mask().iter() {
            v956_19_cursor.descend_to_existing_byte(v962_11_byte);
            {
            let v963_2: Space = singleton(&v956_19_cursor.path()[(v956_19_origin + 2)..(v956_19_origin + 3)]);
            let v963_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v963_2));
            drop(v963_2);
            let v963_4: Space = if map_kernels::has_head(&(v963_3)) { singleton(&[]) } else { Space::new() };
            drop(v963_3);
            let v963_7: Space = if (&(v963_4)).is_empty() { Space::new() } else {
              let v964_5: Path = concat_path(&(v962_10),&v956_19_cursor.path()[(v956_19_origin + 2)..(v956_19_origin + 3)]);
              let v964_6: Space = routine_44(c, &(v964_5), &v956_19_cursor, &(*s1));
              drop(v964_5);
              map_map_kernels::compose(&(v963_4),&(v964_6))
            };
            drop(v963_4);
            join_wrapped_into(&mut v962_11_write,&((v963_7).read_zipper()),&[]);
            }
            v956_19_cursor.ascend(1);
          }
          drop(v962_11_write);
          drop(v962_10);
          map_map_kernels::compose(&(v959_9),&(v962_11))
        };
        drop(v959_9);
        let v959_13: Space = map_map_kernels::unite(&(v959_7),&(v959_12));
        drop(v959_7);
        join_wrapped_into(&mut v958_7_write,&((v959_13).read_zipper()),&[]);
        }
        v956_19_cursor.ascend(1);
      }
      drop(v958_7_write);
      drop(v958_6);
      map_map_kernels::compose(&(v957_5),&(v958_7))
    };
    drop(v957_5);
    let v957_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v957_2));
    drop(v957_2);
    let v957_10: Space = if map_kernels::has_head(&(v957_9)) { singleton(&[]) } else { Space::new() };
    drop(v957_9);
    let v957_13: Space = if (&(v957_10)).is_empty() { Space::new() } else {
      let mut v965_12 = Space::new();
      let mut v965_12_write = v965_12.write_zipper();
      for v965_12_byte in v956_19_cursor.child_mask().iter() {
        v956_19_cursor.descend_to_existing_byte(v965_12_byte);
        {
        let v966_2: Space = singleton(&v956_19_cursor.path()[(v956_19_origin + 1)..(v956_19_origin + 2)]);
        let v966_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v966_2));
        let v966_4: Space = if map_kernels::has_head(&(v966_3)) { singleton(&[]) } else { Space::new() };
        drop(v966_3);
        let v966_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v966_4));
        drop(v966_4);
        let v966_7: Space = if (&(v966_5)).is_empty() { Space::new() } else {
          let mut v967_6 = Space::new();
          let mut v967_6_write = v967_6.write_zipper();
          for v967_6_byte in v956_19_cursor.child_mask().iter() {
            v956_19_cursor.descend_to_existing_byte(v967_6_byte);
            {
            let v968_2: Space = Space::new();
            join_wrapped_into(&mut v967_6_write,&((v968_2).read_zipper()),&[]);
            }
            v956_19_cursor.ascend(1);
          }
          drop(v967_6_write);
          map_map_kernels::compose(&(v966_5),&(v967_6))
        };
        drop(v966_5);
        let v966_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v966_2));
        drop(v966_2);
        let v966_9: Space = if map_kernels::has_head(&(v966_8)) { singleton(&[]) } else { Space::new() };
        drop(v966_8);
        let v966_12: Space = if (&(v966_9)).is_empty() { Space::new() } else {
          let v969_11: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v956_19_cursor.path()[v956_19_origin..(v956_19_origin + 1)]),&v956_19_cursor.path()[(v956_19_origin + 1)..(v956_19_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v966_9),&(v969_11))
        };
        drop(v966_9);
        let v966_13: Space = map_map_kernels::unite(&(v966_7),&(v966_12));
        drop(v966_7);
        drop(v966_12);
        join_wrapped_into(&mut v965_12_write,&((v966_13).read_zipper()),&[]);
        }
        v956_19_cursor.ascend(1);
      }
      drop(v965_12_write);
      map_map_kernels::compose(&(v957_10),&(v965_12))
    };
    drop(v957_10);
    let v957_14: Space = map_map_kernels::unite(&(v957_8),&(v957_13));
    drop(v957_13);
    join_wrapped_into(&mut v956_19_write,&((v957_14).read_zipper()),&[]);
    }
    v956_19_cursor.ascend(1);
  }
  drop(v956_19_cursor);
  drop(v956_19_write);
  (v956_19).clone()
}

fn routine_62(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v970_16 = Space::new();
  let mut v970_16_write = v970_16.write_zipper();
  let mut v970_16_cursor = (*s0).read_zipper();
  let v970_16_origin = v970_16_cursor.path().len();
  for v970_16_byte in v970_16_cursor.child_mask().iter() {
    v970_16_cursor.descend_to_existing_byte(v970_16_byte);
    {
    let v971_2: Space = singleton(&v970_16_cursor.path()[v970_16_origin..(v970_16_origin + 1)]);
    let v971_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v971_2));
    let v971_4: Space = if map_kernels::has_head(&(v971_3)) { singleton(&[]) } else { Space::new() };
    drop(v971_3);
    let v971_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v971_4));
    drop(v971_4);
    let v971_8: Space = if (&(v971_5)).is_empty() { Space::new() } else {
      let v972_6: Path = concat_path(&(*p0),&v970_16_cursor.path()[v970_16_origin..(v970_16_origin + 1)]);
      let mut v972_7 = Space::new();
      let mut v972_7_write = v972_7.write_zipper();
      for v972_7_byte in v970_16_cursor.child_mask().iter() {
        v970_16_cursor.descend_to_existing_byte(v972_7_byte);
        {
        let v973_2: Space = singleton(&v970_16_cursor.path()[(v970_16_origin + 1)..(v970_16_origin + 2)]);
        let v973_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v973_2));
        let v973_4: Space = if map_kernels::has_head(&(v973_3)) { singleton(&[]) } else { Space::new() };
        drop(v973_3);
        let v973_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v973_4));
        drop(v973_4);
        let v973_7: Space = if (&(v973_5)).is_empty() { Space::new() } else {
          let mut v974_6 = Space::new();
          let mut v974_6_write = v974_6.write_zipper();
          for v974_6_byte in v970_16_cursor.child_mask().iter() {
            v970_16_cursor.descend_to_existing_byte(v974_6_byte);
            {
            let v975_2: Space = Space::new();
            join_wrapped_into(&mut v974_6_write,&((v975_2).read_zipper()),&[]);
            }
            v970_16_cursor.ascend(1);
          }
          drop(v974_6_write);
          map_map_kernels::compose(&(v973_5),&(v974_6))
        };
        drop(v973_5);
        let v973_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v973_2));
        drop(v973_2);
        let v973_9: Space = if map_kernels::has_head(&(v973_8)) { singleton(&[]) } else { Space::new() };
        drop(v973_8);
        let v973_12: Space = if (&(v973_9)).is_empty() { Space::new() } else {
          let v976_10: Path = concat_path(&(v972_6),&v970_16_cursor.path()[(v970_16_origin + 1)..(v970_16_origin + 2)]);
          let mut v976_11 = Space::new();
          let mut v976_11_write = v976_11.write_zipper();
          for v976_11_byte in v970_16_cursor.child_mask().iter() {
            v970_16_cursor.descend_to_existing_byte(v976_11_byte);
            {
            let v977_2: Space = singleton(&v970_16_cursor.path()[(v970_16_origin + 2)..(v970_16_origin + 3)]);
            let v977_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v977_2));
            drop(v977_2);
            let v977_4: Space = if map_kernels::has_head(&(v977_3)) { singleton(&[]) } else { Space::new() };
            drop(v977_3);
            let v977_7: Space = if (&(v977_4)).is_empty() { Space::new() } else {
              let v978_5: Path = concat_path(&(v976_10),&v970_16_cursor.path()[(v970_16_origin + 2)..(v970_16_origin + 3)]);
              let v978_6: Space = routine_44(c, &(v978_5), &v970_16_cursor, &(*s1));
              drop(v978_5);
              map_map_kernels::compose(&(v977_4),&(v978_6))
            };
            drop(v977_4);
            join_wrapped_into(&mut v976_11_write,&((v977_7).read_zipper()),&[]);
            }
            v970_16_cursor.ascend(1);
          }
          drop(v976_11_write);
          drop(v976_10);
          map_map_kernels::compose(&(v973_9),&(v976_11))
        };
        drop(v973_9);
        let v973_13: Space = map_map_kernels::unite(&(v973_7),&(v973_12));
        drop(v973_7);
        join_wrapped_into(&mut v972_7_write,&((v973_13).read_zipper()),&[]);
        }
        v970_16_cursor.ascend(1);
      }
      drop(v972_7_write);
      drop(v972_6);
      map_map_kernels::compose(&(v971_5),&(v972_7))
    };
    drop(v971_5);
    let v971_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v971_2));
    drop(v971_2);
    let v971_10: Space = if map_kernels::has_head(&(v971_9)) { singleton(&[]) } else { Space::new() };
    drop(v971_9);
    let v971_13: Space = if (&(v971_10)).is_empty() { Space::new() } else {
      let v979_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v970_16_cursor.path()[v970_16_origin..(v970_16_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v971_10),&(v979_12))
    };
    drop(v971_10);
    let v971_14: Space = map_map_kernels::unite(&(v971_8),&(v971_13));
    drop(v971_13);
    join_wrapped_into(&mut v970_16_write,&((v971_14).read_zipper()),&[]);
    }
    v970_16_cursor.ascend(1);
  }
  drop(v970_16_cursor);
  drop(v970_16_write);
  (v970_16).clone()
}

fn routine_63(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v980_13 = Space::new();
  let mut v980_13_write = v980_13.write_zipper();
  let mut v980_13_cursor = (*s0).read_zipper();
  let v980_13_origin = v980_13_cursor.path().len();
  for v980_13_byte in v980_13_cursor.child_mask().iter() {
    v980_13_cursor.descend_to_existing_byte(v980_13_byte);
    {
    let v981_2: Space = singleton(&v980_13_cursor.path()[v980_13_origin..(v980_13_origin + 1)]);
    let v981_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v981_2));
    let v981_4: Space = if map_kernels::has_head(&(v981_3)) { singleton(&[]) } else { Space::new() };
    drop(v981_3);
    let v981_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v981_4));
    drop(v981_4);
    let v981_7: Space = if (&(v981_5)).is_empty() { Space::new() } else {
      let mut v982_6 = Space::new();
      let mut v982_6_write = v982_6.write_zipper();
      for v982_6_byte in v980_13_cursor.child_mask().iter() {
        v980_13_cursor.descend_to_existing_byte(v982_6_byte);
        {
        let v983_2: Space = Space::new();
        join_wrapped_into(&mut v982_6_write,&((v983_2).read_zipper()),&[]);
        }
        v980_13_cursor.ascend(1);
      }
      drop(v982_6_write);
      map_map_kernels::compose(&(v981_5),&(v982_6))
    };
    drop(v981_5);
    let v981_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v981_2));
    drop(v981_2);
    let v981_9: Space = if map_kernels::has_head(&(v981_8)) { singleton(&[]) } else { Space::new() };
    drop(v981_8);
    let v981_12: Space = if (&(v981_9)).is_empty() { Space::new() } else {
      let mut v984_11 = Space::new();
      let mut v984_11_write = v984_11.write_zipper();
      for v984_11_byte in v980_13_cursor.child_mask().iter() {
        v980_13_cursor.descend_to_existing_byte(v984_11_byte);
        {
        let v985_2: Space = singleton(&v980_13_cursor.path()[(v980_13_origin + 1)..(v980_13_origin + 2)]);
        let v985_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v985_2));
        drop(v985_2);
        let v985_4: Space = if map_kernels::has_head(&(v985_3)) { singleton(&[]) } else { Space::new() };
        drop(v985_3);
        let v985_7: Space = if (&(v985_4)).is_empty() { Space::new() } else {
          let v986_6: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v980_13_cursor.path()[v980_13_origin..(v980_13_origin + 1)]),&v980_13_cursor.path()[(v980_13_origin + 1)..(v980_13_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v985_4),&(v986_6))
        };
        drop(v985_4);
        join_wrapped_into(&mut v984_11_write,&((v985_7).read_zipper()),&[]);
        }
        v980_13_cursor.ascend(1);
      }
      drop(v984_11_write);
      map_map_kernels::compose(&(v981_9),&(v984_11))
    };
    drop(v981_9);
    let v981_13: Space = map_map_kernels::unite(&(v981_7),&(v981_12));
    drop(v981_7);
    drop(v981_12);
    join_wrapped_into(&mut v980_13_write,&((v981_13).read_zipper()),&[]);
    }
    v980_13_cursor.ascend(1);
  }
  drop(v980_13_cursor);
  drop(v980_13_write);
  (v980_13).clone()
}

fn routine_64(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v987_12 = Space::new();
  let mut v987_12_write = v987_12.write_zipper();
  let mut v987_12_cursor = (*s0).read_zipper();
  let v987_12_origin = v987_12_cursor.path().len();
  for v987_12_byte in v987_12_cursor.child_mask().iter() {
    v987_12_cursor.descend_to_existing_byte(v987_12_byte);
    {
    let v988_2: Space = singleton(&v987_12_cursor.path()[v987_12_origin..(v987_12_origin + 1)]);
    let v988_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v988_2));
    let v988_4: Space = if map_kernels::has_head(&(v988_3)) { singleton(&[]) } else { Space::new() };
    drop(v988_3);
    let v988_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v988_4));
    drop(v988_4);
    let v988_7: Space = if (&(v988_5)).is_empty() { Space::new() } else {
      let mut v989_6 = Space::new();
      let mut v989_6_write = v989_6.write_zipper();
      for v989_6_byte in v987_12_cursor.child_mask().iter() {
        v987_12_cursor.descend_to_existing_byte(v989_6_byte);
        {
        let v990_2: Space = Space::new();
        join_wrapped_into(&mut v989_6_write,&((v990_2).read_zipper()),&[]);
        }
        v987_12_cursor.ascend(1);
      }
      drop(v989_6_write);
      map_map_kernels::compose(&(v988_5),&(v989_6))
    };
    drop(v988_5);
    let v988_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v988_2));
    drop(v988_2);
    let v988_9: Space = if map_kernels::has_head(&(v988_8)) { singleton(&[]) } else { Space::new() };
    drop(v988_8);
    let v988_12: Space = if (&(v988_9)).is_empty() { Space::new() } else {
      let v991_11: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v987_12_cursor.path()[v987_12_origin..(v987_12_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v988_9),&(v991_11))
    };
    drop(v988_9);
    let v988_13: Space = map_map_kernels::unite(&(v988_7),&(v988_12));
    drop(v988_7);
    drop(v988_12);
    join_wrapped_into(&mut v987_12_write,&((v988_13).read_zipper()),&[]);
    }
    v987_12_cursor.ascend(1);
  }
  drop(v987_12_cursor);
  drop(v987_12_write);
  (v987_12).clone()
}

fn routine_65(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v992_3 = Space::new();
  let mut v992_3_write = v992_3.write_zipper();
  let mut v992_3_cursor = (*s0).read_zipper();
  let v992_3_origin = v992_3_cursor.path().len();
  for v992_3_byte in v992_3_cursor.child_mask().iter() {
    v992_3_cursor.descend_to_existing_byte(v992_3_byte);
    {
    let v993_2: Space = Space::new();
    join_wrapped_into(&mut v992_3_write,&((v993_2).read_zipper()),&[]);
    }
    v992_3_cursor.ascend(1);
  }
  drop(v992_3_cursor);
  drop(v992_3_write);
  (v992_3).clone()
}

fn routine_66(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v994_10 = Space::new();
  let mut v994_10_write = v994_10.write_zipper();
  let mut v994_10_cursor = (*s0).read_zipper();
  let v994_10_origin = v994_10_cursor.path().len();
  for v994_10_byte in v994_10_cursor.child_mask().iter() {
    v994_10_cursor.descend_to_existing_byte(v994_10_byte);
    {
    let v995_2: Space = singleton(&v994_10_cursor.path()[v994_10_origin..(v994_10_origin + 1)]);
    let v995_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v995_2));
    drop(v995_2);
    let v995_4: Space = if map_kernels::has_head(&(v995_3)) { singleton(&[]) } else { Space::new() };
    drop(v995_3);
    let v995_7: Space = if (&(v995_4)).is_empty() { Space::new() } else {
      let v996_6: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v994_10_cursor.path()[v994_10_origin..(v994_10_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v995_4),&(v996_6))
    };
    drop(v995_4);
    join_wrapped_into(&mut v994_10_write,&((v995_7).read_zipper()),&[]);
    }
    v994_10_cursor.ascend(1);
  }
  drop(v994_10_cursor);
  drop(v994_10_write);
  (v994_10).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
