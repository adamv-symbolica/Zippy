#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("94 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 1 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 0 0 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 1 0 0 1 1 22 1 1 0 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 22 1 1 0 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 18 1 1 0 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 18 1 1 0 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 22 1 1 0 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 22 1 1 0 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 21 1 1 0 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 16 1 1 0 0 1 1 0 0 0 1 1 0 1 0 1 1 16 1 1 0 0 1 1 0 0 0 1 1 1 0 0 1 1 22 1 1 0 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 22 1 1 0 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 20 1 1 0 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 20 1 1 0 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 19 1 1 0 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 18 1 1 0 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 20 1 1 0 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 18 1 1 0 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 18 1 1 0 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 20 1 1 0 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 20 1 1 0 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 21 1 1 0 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 21 1 1 0 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 19 1 1 0 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 18 1 1 0 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 22 1 1 0 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 20 1 1 0 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 18 1 1 0 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 18 1 1 0 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 22 1 1 0 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 21 1 1 0 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 21 1 1 0 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 18 1 1 0 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 16 1 1 0 0 1 1 1 0 0 1 1 0 1 0 1 1 22 1 1 0 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 22 1 1 0 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 20 1 1 0 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 19 1 1 0 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 19 1 1 0 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 15 1 1 0 0 1 1 1 0 1 1 0 0 0 1 1 15 1 1 0 0 1 1 1 0 1 1 1 0 0 1 1"));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("184 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 0 0 1 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 1 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 0 1 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 1 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 0 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 0 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 0 1 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 0 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 1 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 0 1 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 1 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 1 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 0 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 1 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 0 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 1 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 0 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 1 0 1 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 1 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 0 1 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 0 1 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 0 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 1 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 0 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 0 1 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 0 0 0 1 1 22 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 0 1 0 1 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 0 1 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 1 0 0 1 1 22 1 1 0 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 22 1 1 0 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 18 1 1 0 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 18 1 1 0 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 22 1 1 0 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 22 1 1 0 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 21 1 1 0 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 16 1 1 0 0 1 1 0 0 0 1 1 0 1 0 1 1 16 1 1 0 0 1 1 0 0 0 1 1 1 0 0 1 1 22 1 1 0 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 22 1 1 0 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 20 1 1 0 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 20 1 1 0 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 19 1 1 0 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 18 1 1 0 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 20 1 1 0 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 18 1 1 0 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 18 1 1 0 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 20 1 1 0 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 20 1 1 0 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 21 1 1 0 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 21 1 1 0 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 19 1 1 0 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 18 1 1 0 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 22 1 1 0 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 20 1 1 0 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 18 1 1 0 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 18 1 1 0 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 22 1 1 0 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 21 1 1 0 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 21 1 1 0 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 18 1 1 0 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 16 1 1 0 0 1 1 1 0 0 1 1 0 1 0 1 1 22 1 1 0 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 22 1 1 0 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 20 1 1 0 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 19 1 1 0 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 19 1 1 0 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 15 1 1 0 0 1 1 1 0 1 1 0 0 0 1 1 15 1 1 0 0 1 1 1 0 1 1 1 0 0 1 1 21 1 1 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 21 1 1 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 19 1 1 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 19 1 1 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 17 1 1 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 17 1 1 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 21 1 1 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 21 1 1 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 20 1 1 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 19 1 1 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 15 1 1 0 1 1 0 0 0 1 1 0 1 0 1 1 15 1 1 0 1 1 0 0 0 1 1 1 0 0 1 1 21 1 1 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 21 1 1 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 19 1 1 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 19 1 1 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 18 1 1 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 17 1 1 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 19 1 1 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 19 1 1 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 17 1 1 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 17 1 1 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 19 1 1 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 19 1 1 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 20 1 1 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 20 1 1 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 18 1 1 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 17 1 1 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 21 1 1 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 19 1 1 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 19 1 1 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 17 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 17 1 1 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 19 1 1 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 21 1 1 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 20 1 1 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 20 1 1 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 17 1 1 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 15 1 1 0 1 1 1 0 0 1 1 0 1 0 1 1 21 1 1 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 21 1 1 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 19 1 1 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 19 1 1 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 18 1 1 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 18 1 1 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 14 1 1 0 1 1 1 0 1 1 0 0 0 1 1 14 1 1 0 1 1 1 0 1 1 1 0 0 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,0,1,1]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1,1]));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1,1]));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,0,1,1,0,1,1]));
#[inline(never)]
fn native_block_0(c: &mut Context,capture_0: &View<'_, '_>) -> (Space,Space,Space,Space,) {
  let mut v1_26 = Space::new();
  let mut v1_26_write = v1_26.write_zipper();
  let mut v1_26_cursor = descend_cursor(descend_cursor((*capture_0).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4));
  let v1_26_origin = v1_26_cursor.path().len();
  for v1_26_byte in v1_26_cursor.child_mask().iter() {
    v1_26_cursor.descend_to_existing_byte(v1_26_byte);
    {
    let v2_2: Space = singleton(&v1_26_cursor.path()[v1_26_origin..(v1_26_origin + 1)]);
    let v2_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v2_2));
    let v2_4: Space = if map_kernels::has_head(&(v2_3)) { singleton(&[]) } else { Space::new() };
    drop(v2_3);
    let v2_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v2_4));
    drop(v2_4);
    let v2_7: Space = if (&(v2_5)).is_empty() { Space::new() } else {
      let mut v3_6 = Space::new();
      let mut v3_6_write = v3_6.write_zipper();
      for v3_6_byte in v1_26_cursor.child_mask().iter() {
        v1_26_cursor.descend_to_existing_byte(v3_6_byte);
        {
        let v4_2: Space = singleton(&v1_26_cursor.path()[(v1_26_origin + 1)..(v1_26_origin + 2)]);
        let v4_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v4_2));
        let v4_4: Space = if map_kernels::has_head(&(v4_3)) { singleton(&[]) } else { Space::new() };
        drop(v4_3);
        let v4_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v4_4));
        drop(v4_4);
        let v4_8: Space = if (&(v4_5)).is_empty() { Space::new() } else {
          let mut v5_7 = Space::new();
          let mut v5_7_write = v5_7.write_zipper();
          for v5_7_byte in v1_26_cursor.child_mask().iter() {
            v1_26_cursor.descend_to_existing_byte(v5_7_byte);
            {
            let v6_2: Space = singleton(&v1_26_cursor.path()[(v1_26_origin + 2)..(v1_26_origin + 3)]);
            let v6_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v6_2));
            let v6_4: Space = if map_kernels::has_head(&(v6_3)) { singleton(&[]) } else { Space::new() };
            drop(v6_3);
            let v6_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v6_4));
            drop(v6_4);
            let v6_8: Space = if (&(v6_5)).is_empty() { Space::new() } else {
              let v7_7: Space = routine_2(c, &v1_26_cursor.path()[v1_26_origin..(v1_26_origin + 3)], &v1_26_cursor, &(*capture_0));
              map_map_kernels::compose(&(v6_5),&(v7_7))
            };
            drop(v6_5);
            let v6_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v6_2));
            drop(v6_2);
            let v6_10: Space = if map_kernels::has_head(&(v6_9)) { singleton(&[]) } else { Space::new() };
            drop(v6_9);
            let v6_12: Space = if (&(v6_10)).is_empty() { Space::new() } else {
              let v8_11: Space = routine_3(c, &v1_26_cursor.path()[v1_26_origin..(v1_26_origin + 3)], &v1_26_cursor, &(*capture_0));
              map_map_kernels::compose(&(v6_10),&(v8_11))
            };
            drop(v6_10);
            let v6_13: Space = map_map_kernels::unite(&(v6_8),&(v6_12));
            join_wrapped_into(&mut v5_7_write,&((v6_13).read_zipper()),&[]);
            }
            v1_26_cursor.ascend(1);
          }
          drop(v5_7_write);
          map_map_kernels::compose(&(v4_5),&(v5_7))
        };
        drop(v4_5);
        let v4_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v4_2));
        drop(v4_2);
        let v4_10: Space = if map_kernels::has_head(&(v4_9)) { singleton(&[]) } else { Space::new() };
        drop(v4_9);
        let v4_12: Space = if (&(v4_10)).is_empty() { Space::new() } else {
          let mut v9_11 = Space::new();
          let mut v9_11_write = v9_11.write_zipper();
          for v9_11_byte in v1_26_cursor.child_mask().iter() {
            v1_26_cursor.descend_to_existing_byte(v9_11_byte);
            {
            let v10_2: Space = singleton(&v1_26_cursor.path()[(v1_26_origin + 2)..(v1_26_origin + 3)]);
            let v10_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v10_2));
            let v10_4: Space = if map_kernels::has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
            drop(v10_3);
            let v10_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v10_4));
            drop(v10_4);
            let v10_8: Space = if (&(v10_5)).is_empty() { Space::new() } else {
              let v11_7: Space = routine_2(c, &v1_26_cursor.path()[v1_26_origin..(v1_26_origin + 3)], &v1_26_cursor, &(*capture_0));
              map_map_kernels::compose(&(v10_5),&(v11_7))
            };
            drop(v10_5);
            let v10_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v10_2));
            drop(v10_2);
            let v10_10: Space = if map_kernels::has_head(&(v10_9)) { singleton(&[]) } else { Space::new() };
            drop(v10_9);
            let v10_12: Space = if (&(v10_10)).is_empty() { Space::new() } else {
              let v12_11: Space = routine_4(c, &v1_26_cursor.path()[v1_26_origin..(v1_26_origin + 3)], &v1_26_cursor, &(*capture_0));
              map_map_kernels::compose(&(v10_10),&(v12_11))
            };
            drop(v10_10);
            let v10_13: Space = map_map_kernels::unite(&(v10_8),&(v10_12));
            join_wrapped_into(&mut v9_11_write,&((v10_13).read_zipper()),&[]);
            }
            v1_26_cursor.ascend(1);
          }
          drop(v9_11_write);
          map_map_kernels::compose(&(v4_10),&(v9_11))
        };
        drop(v4_10);
        let v4_13: Space = map_map_kernels::unite(&(v4_8),&(v4_12));
        join_wrapped_into(&mut v3_6_write,&((v4_13).read_zipper()),&[]);
        }
        v1_26_cursor.ascend(1);
      }
      drop(v3_6_write);
      map_map_kernels::compose(&(v2_5),&(v3_6))
    };
    drop(v2_5);
    let v2_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v2_2));
    drop(v2_2);
    let v2_9: Space = if map_kernels::has_head(&(v2_8)) { singleton(&[]) } else { Space::new() };
    drop(v2_8);
    let v2_11: Space = if (&(v2_9)).is_empty() { Space::new() } else {
      let mut v13_10 = Space::new();
      let mut v13_10_write = v13_10.write_zipper();
      for v13_10_byte in v1_26_cursor.child_mask().iter() {
        v1_26_cursor.descend_to_existing_byte(v13_10_byte);
        {
        let v14_2: Space = singleton(&v1_26_cursor.path()[(v1_26_origin + 1)..(v1_26_origin + 2)]);
        let v14_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v14_2));
        let v14_4: Space = if map_kernels::has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
        drop(v14_3);
        let v14_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v14_4));
        drop(v14_4);
        let v14_8: Space = if (&(v14_5)).is_empty() { Space::new() } else {
          let mut v15_7 = Space::new();
          let mut v15_7_write = v15_7.write_zipper();
          for v15_7_byte in v1_26_cursor.child_mask().iter() {
            v1_26_cursor.descend_to_existing_byte(v15_7_byte);
            {
            let v16_2: Space = singleton(&v1_26_cursor.path()[(v1_26_origin + 2)..(v1_26_origin + 3)]);
            let v16_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v16_2));
            let v16_4: Space = if map_kernels::has_head(&(v16_3)) { singleton(&[]) } else { Space::new() };
            drop(v16_3);
            let v16_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v16_4));
            drop(v16_4);
            let v16_8: Space = if (&(v16_5)).is_empty() { Space::new() } else {
              let v17_7: Space = routine_2(c, &v1_26_cursor.path()[v1_26_origin..(v1_26_origin + 3)], &v1_26_cursor, &(*capture_0));
              map_map_kernels::compose(&(v16_5),&(v17_7))
            };
            drop(v16_5);
            let v16_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v16_2));
            drop(v16_2);
            let v16_10: Space = if map_kernels::has_head(&(v16_9)) { singleton(&[]) } else { Space::new() };
            drop(v16_9);
            let v16_12: Space = if (&(v16_10)).is_empty() { Space::new() } else {
              let v18_11: Space = routine_3(c, &v1_26_cursor.path()[v1_26_origin..(v1_26_origin + 3)], &v1_26_cursor, &(*capture_0));
              map_map_kernels::compose(&(v16_10),&(v18_11))
            };
            drop(v16_10);
            let v16_13: Space = map_map_kernels::unite(&(v16_8),&(v16_12));
            join_wrapped_into(&mut v15_7_write,&((v16_13).read_zipper()),&[]);
            }
            v1_26_cursor.ascend(1);
          }
          drop(v15_7_write);
          map_map_kernels::compose(&(v14_5),&(v15_7))
        };
        drop(v14_5);
        let v14_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v14_2));
        drop(v14_2);
        let v14_10: Space = if map_kernels::has_head(&(v14_9)) { singleton(&[]) } else { Space::new() };
        drop(v14_9);
        let v14_12: Space = if (&(v14_10)).is_empty() { Space::new() } else {
          let mut v19_11 = Space::new();
          let mut v19_11_write = v19_11.write_zipper();
          for v19_11_byte in v1_26_cursor.child_mask().iter() {
            v1_26_cursor.descend_to_existing_byte(v19_11_byte);
            {
            let v20_2: Space = singleton(&v1_26_cursor.path()[(v1_26_origin + 2)..(v1_26_origin + 3)]);
            let v20_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v20_2));
            let v20_4: Space = if map_kernels::has_head(&(v20_3)) { singleton(&[]) } else { Space::new() };
            drop(v20_3);
            let v20_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v20_4));
            drop(v20_4);
            let v20_7: Space = if (&(v20_5)).is_empty() { Space::new() } else {
              let v21_6: Space = routine_5(c, &v1_26_cursor.path()[(v1_26_origin + 2)..(v1_26_origin + 3)], &v1_26_cursor, &(*capture_0));
              map_map_kernels::compose(&(v20_5),&(v21_6))
            };
            drop(v20_5);
            let v20_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v20_2));
            drop(v20_2);
            let v20_9: Space = if map_kernels::has_head(&(v20_8)) { singleton(&[]) } else { Space::new() };
            drop(v20_8);
            let v20_11: Space = if (&(v20_9)).is_empty() { Space::new() } else {
              let v22_10: Space = routine_6(c, &v1_26_cursor.path()[(v1_26_origin + 2)..(v1_26_origin + 3)], &v1_26_cursor, &(*capture_0));
              map_map_kernels::compose(&(v20_9),&(v22_10))
            };
            drop(v20_9);
            let v20_12: Space = map_map_kernels::unite(&(v20_7),&(v20_11));
            join_wrapped_into(&mut v19_11_write,&((v20_12).read_zipper()),&[]);
            }
            v1_26_cursor.ascend(1);
          }
          drop(v19_11_write);
          map_map_kernels::compose(&(v14_10),&(v19_11))
        };
        drop(v14_10);
        let v14_13: Space = map_kernels::wrap(&(v14_12),&v1_26_cursor.path()[v1_26_origin..(v1_26_origin + 2)]);
        let v14_14: Space = map_map_kernels::unite(&(v14_8),&(v14_13));
        join_wrapped_into(&mut v13_10_write,&((v14_14).read_zipper()),&[]);
        }
        v1_26_cursor.ascend(1);
      }
      drop(v13_10_write);
      map_map_kernels::compose(&(v2_9),&(v13_10))
    };
    drop(v2_9);
    let v2_12: Space = map_map_kernels::unite(&(v2_7),&(v2_11));
    join_wrapped_into(&mut v1_26_write,&((v2_12).read_zipper()),&[]);
    }
    v1_26_cursor.ascend(1);
  }
  drop(v1_26_cursor);
  drop(v1_26_write);
  let mut v1_48 = Space::new();
  let mut v1_48_write = v1_48.write_zipper();
  let mut v1_48_cursor = descend_cursor(descend_cursor((*capture_0).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4));
  let v1_48_origin = v1_48_cursor.path().len();
  for v1_48_byte in v1_48_cursor.child_mask().iter() {
    v1_48_cursor.descend_to_existing_byte(v1_48_byte);
    {
    let v24_2: Space = singleton(&v1_48_cursor.path()[v1_48_origin..(v1_48_origin + 1)]);
    let v24_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v24_2));
    let v24_4: Space = if map_kernels::has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
    drop(v24_3);
    let v24_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v24_4));
    drop(v24_4);
    let v24_7: Space = if (&(v24_5)).is_empty() { Space::new() } else {
      let mut v25_6 = Space::new();
      let mut v25_6_write = v25_6.write_zipper();
      for v25_6_byte in v1_48_cursor.child_mask().iter() {
        v1_48_cursor.descend_to_existing_byte(v25_6_byte);
        {
        let v26_2: Space = singleton(&v1_48_cursor.path()[(v1_48_origin + 1)..(v1_48_origin + 2)]);
        let v26_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v26_2));
        let v26_4: Space = if map_kernels::has_head(&(v26_3)) { singleton(&[]) } else { Space::new() };
        drop(v26_3);
        let v26_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v26_4));
        drop(v26_4);
        let v26_8: Space = if (&(v26_5)).is_empty() { Space::new() } else {
          let mut v27_7 = Space::new();
          let mut v27_7_write = v27_7.write_zipper();
          for v27_7_byte in v1_48_cursor.child_mask().iter() {
            v1_48_cursor.descend_to_existing_byte(v27_7_byte);
            {
            let v28_2: Space = singleton(&v1_48_cursor.path()[(v1_48_origin + 2)..(v1_48_origin + 3)]);
            let v28_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v28_2));
            let v28_4: Space = if map_kernels::has_head(&(v28_3)) { singleton(&[]) } else { Space::new() };
            drop(v28_3);
            let v28_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v28_4));
            drop(v28_4);
            let v28_8: Space = if (&(v28_5)).is_empty() { Space::new() } else {
              let v29_7: Space = routine_7(c, &v1_48_cursor.path()[v1_48_origin..(v1_48_origin + 3)], &v1_48_cursor, &(*capture_0));
              map_map_kernels::compose(&(v28_5),&(v29_7))
            };
            drop(v28_5);
            let v28_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v28_2));
            drop(v28_2);
            let v28_10: Space = if map_kernels::has_head(&(v28_9)) { singleton(&[]) } else { Space::new() };
            drop(v28_9);
            let v28_12: Space = if (&(v28_10)).is_empty() { Space::new() } else {
              let v30_11: Space = routine_8(c, &v1_48_cursor.path()[v1_48_origin..(v1_48_origin + 3)], &v1_48_cursor, &(*capture_0));
              map_map_kernels::compose(&(v28_10),&(v30_11))
            };
            drop(v28_10);
            let v28_13: Space = map_map_kernels::unite(&(v28_8),&(v28_12));
            join_wrapped_into(&mut v27_7_write,&((v28_13).read_zipper()),&[]);
            }
            v1_48_cursor.ascend(1);
          }
          drop(v27_7_write);
          map_map_kernels::compose(&(v26_5),&(v27_7))
        };
        drop(v26_5);
        let v26_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v26_2));
        drop(v26_2);
        let v26_10: Space = if map_kernels::has_head(&(v26_9)) { singleton(&[]) } else { Space::new() };
        drop(v26_9);
        let v26_12: Space = if (&(v26_10)).is_empty() { Space::new() } else {
          let mut v31_11 = Space::new();
          let mut v31_11_write = v31_11.write_zipper();
          for v31_11_byte in v1_48_cursor.child_mask().iter() {
            v1_48_cursor.descend_to_existing_byte(v31_11_byte);
            {
            let v32_2: Space = singleton(&v1_48_cursor.path()[(v1_48_origin + 2)..(v1_48_origin + 3)]);
            let v32_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v32_2));
            let v32_4: Space = if map_kernels::has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
            drop(v32_3);
            let v32_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v32_4));
            drop(v32_4);
            let v32_8: Space = if (&(v32_5)).is_empty() { Space::new() } else {
              let v33_7: Space = routine_7(c, &v1_48_cursor.path()[v1_48_origin..(v1_48_origin + 3)], &v1_48_cursor, &(*capture_0));
              map_map_kernels::compose(&(v32_5),&(v33_7))
            };
            drop(v32_5);
            let v32_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v32_2));
            drop(v32_2);
            let v32_10: Space = if map_kernels::has_head(&(v32_9)) { singleton(&[]) } else { Space::new() };
            drop(v32_9);
            let v32_12: Space = if (&(v32_10)).is_empty() { Space::new() } else {
              let v34_11: Space = routine_9(c, &v1_48_cursor.path()[v1_48_origin..(v1_48_origin + 3)], &v1_48_cursor, &(*capture_0));
              map_map_kernels::compose(&(v32_10),&(v34_11))
            };
            drop(v32_10);
            let v32_13: Space = map_map_kernels::unite(&(v32_8),&(v32_12));
            join_wrapped_into(&mut v31_11_write,&((v32_13).read_zipper()),&[]);
            }
            v1_48_cursor.ascend(1);
          }
          drop(v31_11_write);
          map_map_kernels::compose(&(v26_10),&(v31_11))
        };
        drop(v26_10);
        let v26_13: Space = map_map_kernels::unite(&(v26_8),&(v26_12));
        join_wrapped_into(&mut v25_6_write,&((v26_13).read_zipper()),&[]);
        }
        v1_48_cursor.ascend(1);
      }
      drop(v25_6_write);
      map_map_kernels::compose(&(v24_5),&(v25_6))
    };
    drop(v24_5);
    let v24_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v24_2));
    drop(v24_2);
    let v24_9: Space = if map_kernels::has_head(&(v24_8)) { singleton(&[]) } else { Space::new() };
    drop(v24_8);
    let v24_11: Space = if (&(v24_9)).is_empty() { Space::new() } else {
      let mut v35_10 = Space::new();
      let mut v35_10_write = v35_10.write_zipper();
      for v35_10_byte in v1_48_cursor.child_mask().iter() {
        v1_48_cursor.descend_to_existing_byte(v35_10_byte);
        {
        let v36_2: Space = singleton(&v1_48_cursor.path()[(v1_48_origin + 1)..(v1_48_origin + 2)]);
        let v36_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v36_2));
        let v36_4: Space = if map_kernels::has_head(&(v36_3)) { singleton(&[]) } else { Space::new() };
        drop(v36_3);
        let v36_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v36_4));
        drop(v36_4);
        let v36_8: Space = if (&(v36_5)).is_empty() { Space::new() } else {
          let mut v37_7 = Space::new();
          let mut v37_7_write = v37_7.write_zipper();
          for v37_7_byte in v1_48_cursor.child_mask().iter() {
            v1_48_cursor.descend_to_existing_byte(v37_7_byte);
            {
            let v38_2: Space = singleton(&v1_48_cursor.path()[(v1_48_origin + 2)..(v1_48_origin + 3)]);
            let v38_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v38_2));
            let v38_4: Space = if map_kernels::has_head(&(v38_3)) { singleton(&[]) } else { Space::new() };
            drop(v38_3);
            let v38_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v38_4));
            drop(v38_4);
            let v38_8: Space = if (&(v38_5)).is_empty() { Space::new() } else {
              let v39_7: Space = routine_7(c, &v1_48_cursor.path()[v1_48_origin..(v1_48_origin + 3)], &v1_48_cursor, &(*capture_0));
              map_map_kernels::compose(&(v38_5),&(v39_7))
            };
            drop(v38_5);
            let v38_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v38_2));
            drop(v38_2);
            let v38_10: Space = if map_kernels::has_head(&(v38_9)) { singleton(&[]) } else { Space::new() };
            drop(v38_9);
            let v38_12: Space = if (&(v38_10)).is_empty() { Space::new() } else {
              let v40_11: Space = routine_8(c, &v1_48_cursor.path()[v1_48_origin..(v1_48_origin + 3)], &v1_48_cursor, &(*capture_0));
              map_map_kernels::compose(&(v38_10),&(v40_11))
            };
            drop(v38_10);
            let v38_13: Space = map_map_kernels::unite(&(v38_8),&(v38_12));
            join_wrapped_into(&mut v37_7_write,&((v38_13).read_zipper()),&[]);
            }
            v1_48_cursor.ascend(1);
          }
          drop(v37_7_write);
          map_map_kernels::compose(&(v36_5),&(v37_7))
        };
        drop(v36_5);
        let v36_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v36_2));
        drop(v36_2);
        let v36_10: Space = if map_kernels::has_head(&(v36_9)) { singleton(&[]) } else { Space::new() };
        drop(v36_9);
        let v36_12: Space = if (&(v36_10)).is_empty() { Space::new() } else {
          let mut v41_11 = Space::new();
          let mut v41_11_write = v41_11.write_zipper();
          for v41_11_byte in v1_48_cursor.child_mask().iter() {
            v1_48_cursor.descend_to_existing_byte(v41_11_byte);
            {
            let v42_2: Space = singleton(&v1_48_cursor.path()[(v1_48_origin + 2)..(v1_48_origin + 3)]);
            let v42_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v42_2));
            let v42_4: Space = if map_kernels::has_head(&(v42_3)) { singleton(&[]) } else { Space::new() };
            drop(v42_3);
            let v42_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v42_4));
            drop(v42_4);
            let v42_7: Space = if (&(v42_5)).is_empty() { Space::new() } else {
              let v43_6: Space = routine_10(c, &v1_48_cursor.path()[(v1_48_origin + 2)..(v1_48_origin + 3)], &v1_48_cursor, &(*capture_0));
              map_map_kernels::compose(&(v42_5),&(v43_6))
            };
            drop(v42_5);
            let v42_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v42_2));
            drop(v42_2);
            let v42_9: Space = if map_kernels::has_head(&(v42_8)) { singleton(&[]) } else { Space::new() };
            drop(v42_8);
            let v42_11: Space = if (&(v42_9)).is_empty() { Space::new() } else {
              let v44_10: Space = routine_11(c, &v1_48_cursor.path()[(v1_48_origin + 2)..(v1_48_origin + 3)], &v1_48_cursor, &(*capture_0));
              map_map_kernels::compose(&(v42_9),&(v44_10))
            };
            drop(v42_9);
            let v42_12: Space = map_map_kernels::unite(&(v42_7),&(v42_11));
            join_wrapped_into(&mut v41_11_write,&((v42_12).read_zipper()),&[]);
            }
            v1_48_cursor.ascend(1);
          }
          drop(v41_11_write);
          map_map_kernels::compose(&(v36_10),&(v41_11))
        };
        drop(v36_10);
        let v36_13: Space = map_kernels::wrap(&(v36_12),&v1_48_cursor.path()[v1_48_origin..(v1_48_origin + 2)]);
        let v36_14: Space = map_map_kernels::unite(&(v36_8),&(v36_13));
        join_wrapped_into(&mut v35_10_write,&((v36_14).read_zipper()),&[]);
        }
        v1_48_cursor.ascend(1);
      }
      drop(v35_10_write);
      map_map_kernels::compose(&(v24_9),&(v35_10))
    };
    drop(v24_9);
    let v24_12: Space = map_map_kernels::unite(&(v24_7),&(v24_11));
    join_wrapped_into(&mut v1_48_write,&((v24_12).read_zipper()),&[]);
    }
    v1_48_cursor.ascend(1);
  }
  drop(v1_48_cursor);
  drop(v1_48_write);
  let v1_49: Space = map_map_kernels::unite(&(v1_26),&(v1_48));
  let mut v1_73 = Space::new();
  let mut v1_73_write = v1_73.write_zipper();
  let mut v1_73_cursor = descend_cursor(descend_cursor((*capture_0).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_8));
  let v1_73_origin = v1_73_cursor.path().len();
  for v1_73_byte in v1_73_cursor.child_mask().iter() {
    v1_73_cursor.descend_to_existing_byte(v1_73_byte);
    {
    let v46_2: Space = singleton(&v1_73_cursor.path()[v1_73_origin..(v1_73_origin + 1)]);
    let v46_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v46_2));
    let v46_4: Space = if map_kernels::has_head(&(v46_3)) { singleton(&[]) } else { Space::new() };
    drop(v46_3);
    let v46_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v46_4));
    drop(v46_4);
    let v46_7: Space = if (&(v46_5)).is_empty() { Space::new() } else {
      let mut v47_6 = Space::new();
      let mut v47_6_write = v47_6.write_zipper();
      for v47_6_byte in v1_73_cursor.child_mask().iter() {
        v1_73_cursor.descend_to_existing_byte(v47_6_byte);
        {
        let v48_2: Space = singleton(&v1_73_cursor.path()[(v1_73_origin + 1)..(v1_73_origin + 2)]);
        let v48_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v48_2));
        let v48_4: Space = if map_kernels::has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
        drop(v48_3);
        let v48_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v48_4));
        drop(v48_4);
        let v48_8: Space = if (&(v48_5)).is_empty() { Space::new() } else {
          let mut v49_7 = Space::new();
          let mut v49_7_write = v49_7.write_zipper();
          for v49_7_byte in v1_73_cursor.child_mask().iter() {
            v1_73_cursor.descend_to_existing_byte(v49_7_byte);
            {
            let v50_2: Space = singleton(&v1_73_cursor.path()[(v1_73_origin + 2)..(v1_73_origin + 3)]);
            let v50_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v50_2));
            let v50_4: Space = if map_kernels::has_head(&(v50_3)) { singleton(&[]) } else { Space::new() };
            drop(v50_3);
            let v50_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v50_4));
            drop(v50_4);
            let v50_8: Space = if (&(v50_5)).is_empty() { Space::new() } else {
              let v51_7: Space = routine_12(c, &v1_73_cursor.path()[v1_73_origin..(v1_73_origin + 3)], &v1_73_cursor);
              map_map_kernels::compose(&(v50_5),&(v51_7))
            };
            drop(v50_5);
            let v50_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v50_2));
            drop(v50_2);
            let v50_10: Space = if map_kernels::has_head(&(v50_9)) { singleton(&[]) } else { Space::new() };
            drop(v50_9);
            let v50_12: Space = if (&(v50_10)).is_empty() { Space::new() } else {
              let v52_11: Space = routine_13(c, &v1_73_cursor.path()[v1_73_origin..(v1_73_origin + 3)], &v1_73_cursor);
              map_map_kernels::compose(&(v50_10),&(v52_11))
            };
            drop(v50_10);
            let v50_13: Space = map_map_kernels::unite(&(v50_8),&(v50_12));
            join_wrapped_into(&mut v49_7_write,&((v50_13).read_zipper()),&[]);
            }
            v1_73_cursor.ascend(1);
          }
          drop(v49_7_write);
          map_map_kernels::compose(&(v48_5),&(v49_7))
        };
        drop(v48_5);
        let v48_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v48_2));
        drop(v48_2);
        let v48_10: Space = if map_kernels::has_head(&(v48_9)) { singleton(&[]) } else { Space::new() };
        drop(v48_9);
        let v48_12: Space = if (&(v48_10)).is_empty() { Space::new() } else {
          let mut v53_11 = Space::new();
          let mut v53_11_write = v53_11.write_zipper();
          for v53_11_byte in v1_73_cursor.child_mask().iter() {
            v1_73_cursor.descend_to_existing_byte(v53_11_byte);
            {
            let v54_2: Space = singleton(&v1_73_cursor.path()[(v1_73_origin + 2)..(v1_73_origin + 3)]);
            let v54_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v54_2));
            let v54_4: Space = if map_kernels::has_head(&(v54_3)) { singleton(&[]) } else { Space::new() };
            drop(v54_3);
            let v54_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v54_4));
            drop(v54_4);
            let v54_8: Space = if (&(v54_5)).is_empty() { Space::new() } else {
              let v55_7: Space = routine_12(c, &v1_73_cursor.path()[v1_73_origin..(v1_73_origin + 3)], &v1_73_cursor);
              map_map_kernels::compose(&(v54_5),&(v55_7))
            };
            drop(v54_5);
            let v54_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v54_2));
            drop(v54_2);
            let v54_10: Space = if map_kernels::has_head(&(v54_9)) { singleton(&[]) } else { Space::new() };
            drop(v54_9);
            let v54_12: Space = if (&(v54_10)).is_empty() { Space::new() } else {
              let v56_11: Space = routine_14(c, &v1_73_cursor.path()[v1_73_origin..(v1_73_origin + 3)], &v1_73_cursor);
              map_map_kernels::compose(&(v54_10),&(v56_11))
            };
            drop(v54_10);
            let v54_13: Space = map_map_kernels::unite(&(v54_8),&(v54_12));
            join_wrapped_into(&mut v53_11_write,&((v54_13).read_zipper()),&[]);
            }
            v1_73_cursor.ascend(1);
          }
          drop(v53_11_write);
          map_map_kernels::compose(&(v48_10),&(v53_11))
        };
        drop(v48_10);
        let v48_13: Space = map_map_kernels::unite(&(v48_8),&(v48_12));
        join_wrapped_into(&mut v47_6_write,&((v48_13).read_zipper()),&[]);
        }
        v1_73_cursor.ascend(1);
      }
      drop(v47_6_write);
      map_map_kernels::compose(&(v46_5),&(v47_6))
    };
    drop(v46_5);
    let v46_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v46_2));
    drop(v46_2);
    let v46_9: Space = if map_kernels::has_head(&(v46_8)) { singleton(&[]) } else { Space::new() };
    drop(v46_8);
    let v46_11: Space = if (&(v46_9)).is_empty() { Space::new() } else {
      let mut v57_10 = Space::new();
      let mut v57_10_write = v57_10.write_zipper();
      for v57_10_byte in v1_73_cursor.child_mask().iter() {
        v1_73_cursor.descend_to_existing_byte(v57_10_byte);
        {
        let v58_2: Space = singleton(&v1_73_cursor.path()[(v1_73_origin + 1)..(v1_73_origin + 2)]);
        let v58_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v58_2));
        let v58_4: Space = if map_kernels::has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
        drop(v58_3);
        let v58_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v58_4));
        drop(v58_4);
        let v58_8: Space = if (&(v58_5)).is_empty() { Space::new() } else {
          let mut v59_7 = Space::new();
          let mut v59_7_write = v59_7.write_zipper();
          for v59_7_byte in v1_73_cursor.child_mask().iter() {
            v1_73_cursor.descend_to_existing_byte(v59_7_byte);
            {
            let v60_2: Space = singleton(&v1_73_cursor.path()[(v1_73_origin + 2)..(v1_73_origin + 3)]);
            let v60_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v60_2));
            let v60_4: Space = if map_kernels::has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
            drop(v60_3);
            let v60_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v60_4));
            drop(v60_4);
            let v60_8: Space = if (&(v60_5)).is_empty() { Space::new() } else {
              let v61_7: Space = routine_12(c, &v1_73_cursor.path()[v1_73_origin..(v1_73_origin + 3)], &v1_73_cursor);
              map_map_kernels::compose(&(v60_5),&(v61_7))
            };
            drop(v60_5);
            let v60_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v60_2));
            drop(v60_2);
            let v60_10: Space = if map_kernels::has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
            drop(v60_9);
            let v60_12: Space = if (&(v60_10)).is_empty() { Space::new() } else {
              let v62_11: Space = routine_13(c, &v1_73_cursor.path()[v1_73_origin..(v1_73_origin + 3)], &v1_73_cursor);
              map_map_kernels::compose(&(v60_10),&(v62_11))
            };
            drop(v60_10);
            let v60_13: Space = map_map_kernels::unite(&(v60_8),&(v60_12));
            join_wrapped_into(&mut v59_7_write,&((v60_13).read_zipper()),&[]);
            }
            v1_73_cursor.ascend(1);
          }
          drop(v59_7_write);
          map_map_kernels::compose(&(v58_5),&(v59_7))
        };
        drop(v58_5);
        let v58_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v58_2));
        drop(v58_2);
        let v58_10: Space = if map_kernels::has_head(&(v58_9)) { singleton(&[]) } else { Space::new() };
        drop(v58_9);
        let v58_12: Space = if (&(v58_10)).is_empty() { Space::new() } else {
          let v63_11: Space = view_map_kernels::subtract(&v1_73_cursor,&(*CONSTANT_5));
          map_map_kernels::compose(&(v58_10),&(v63_11))
        };
        drop(v58_10);
        let v58_13: Space = map_kernels::wrap(&(v58_12),&v1_73_cursor.path()[v1_73_origin..(v1_73_origin + 2)]);
        drop(v58_12);
        let v58_14: Space = map_map_kernels::unite(&(v58_8),&(v58_13));
        drop(v58_13);
        join_wrapped_into(&mut v57_10_write,&((v58_14).read_zipper()),&[]);
        }
        v1_73_cursor.ascend(1);
      }
      drop(v57_10_write);
      map_map_kernels::compose(&(v46_9),&(v57_10))
    };
    drop(v46_9);
    let v46_12: Space = map_map_kernels::unite(&(v46_7),&(v46_11));
    join_wrapped_into(&mut v1_73_write,&((v46_12).read_zipper()),&[]);
    }
    v1_73_cursor.ascend(1);
  }
  drop(v1_73_cursor);
  drop(v1_73_write);

((v1_26).clone(),(v1_48).clone(),(v1_49).clone(),(v1_73).clone(),)
}

#[inline(never)]
fn native_block_1(c: &mut Context,capture_0: &Space) -> (Space,Space,Space,Space,) {
    let mut v87_3 = Space::new();
    let mut v87_3_write = v87_3.write_zipper();
    let mut v87_3_cursor = descend_cursor(descend_cursor(((*capture_0)).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4));
    let v87_3_origin = v87_3_cursor.path().len();
    for v87_3_byte in v87_3_cursor.child_mask().iter() {
      v87_3_cursor.descend_to_existing_byte(v87_3_byte);
      {
      let v88_2: Space = singleton(&v87_3_cursor.path()[v87_3_origin..(v87_3_origin + 1)]);
      let v88_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v88_2));
      let v88_4: Space = if map_kernels::has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
      drop(v88_3);
      let v88_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v88_4));
      drop(v88_4);
      let v88_7: Space = if (&(v88_5)).is_empty() { Space::new() } else {
        let mut v89_6 = Space::new();
        let mut v89_6_write = v89_6.write_zipper();
        for v89_6_byte in v87_3_cursor.child_mask().iter() {
          v87_3_cursor.descend_to_existing_byte(v89_6_byte);
          {
          let v90_2: Space = singleton(&v87_3_cursor.path()[(v87_3_origin + 1)..(v87_3_origin + 2)]);
          let v90_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v90_2));
          let v90_4: Space = if map_kernels::has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
          drop(v90_3);
          let v90_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v90_4));
          drop(v90_4);
          let v90_8: Space = if (&(v90_5)).is_empty() { Space::new() } else {
            let mut v91_7 = Space::new();
            let mut v91_7_write = v91_7.write_zipper();
            for v91_7_byte in v87_3_cursor.child_mask().iter() {
              v87_3_cursor.descend_to_existing_byte(v91_7_byte);
              {
              let v92_2: Space = singleton(&v87_3_cursor.path()[(v87_3_origin + 2)..(v87_3_origin + 3)]);
              let v92_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v92_2));
              let v92_4: Space = if map_kernels::has_head(&(v92_3)) { singleton(&[]) } else { Space::new() };
              drop(v92_3);
              let v92_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v92_4));
              drop(v92_4);
              let v92_8: Space = if (&(v92_5)).is_empty() { Space::new() } else {
                let v93_7: Space = routine_2(c, &v87_3_cursor.path()[v87_3_origin..(v87_3_origin + 3)], &v87_3_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v92_5),&(v93_7))
              };
              drop(v92_5);
              let v92_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v92_2));
              drop(v92_2);
              let v92_10: Space = if map_kernels::has_head(&(v92_9)) { singleton(&[]) } else { Space::new() };
              drop(v92_9);
              let v92_12: Space = if (&(v92_10)).is_empty() { Space::new() } else {
                let v94_11: Space = routine_3(c, &v87_3_cursor.path()[v87_3_origin..(v87_3_origin + 3)], &v87_3_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v92_10),&(v94_11))
              };
              drop(v92_10);
              let v92_13: Space = map_map_kernels::unite(&(v92_8),&(v92_12));
              join_wrapped_into(&mut v91_7_write,&((v92_13).read_zipper()),&[]);
              }
              v87_3_cursor.ascend(1);
            }
            drop(v91_7_write);
            map_map_kernels::compose(&(v90_5),&(v91_7))
          };
          drop(v90_5);
          let v90_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v90_2));
          drop(v90_2);
          let v90_10: Space = if map_kernels::has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
          drop(v90_9);
          let v90_12: Space = if (&(v90_10)).is_empty() { Space::new() } else {
            let mut v95_11 = Space::new();
            let mut v95_11_write = v95_11.write_zipper();
            for v95_11_byte in v87_3_cursor.child_mask().iter() {
              v87_3_cursor.descend_to_existing_byte(v95_11_byte);
              {
              let v96_2: Space = singleton(&v87_3_cursor.path()[(v87_3_origin + 2)..(v87_3_origin + 3)]);
              let v96_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v96_2));
              let v96_4: Space = if map_kernels::has_head(&(v96_3)) { singleton(&[]) } else { Space::new() };
              drop(v96_3);
              let v96_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v96_4));
              drop(v96_4);
              let v96_8: Space = if (&(v96_5)).is_empty() { Space::new() } else {
                let v97_7: Space = routine_2(c, &v87_3_cursor.path()[v87_3_origin..(v87_3_origin + 3)], &v87_3_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v96_5),&(v97_7))
              };
              drop(v96_5);
              let v96_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v96_2));
              drop(v96_2);
              let v96_10: Space = if map_kernels::has_head(&(v96_9)) { singleton(&[]) } else { Space::new() };
              drop(v96_9);
              let v96_12: Space = if (&(v96_10)).is_empty() { Space::new() } else {
                let v98_11: Space = routine_4(c, &v87_3_cursor.path()[v87_3_origin..(v87_3_origin + 3)], &v87_3_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v96_10),&(v98_11))
              };
              drop(v96_10);
              let v96_13: Space = map_map_kernels::unite(&(v96_8),&(v96_12));
              join_wrapped_into(&mut v95_11_write,&((v96_13).read_zipper()),&[]);
              }
              v87_3_cursor.ascend(1);
            }
            drop(v95_11_write);
            map_map_kernels::compose(&(v90_10),&(v95_11))
          };
          drop(v90_10);
          let v90_13: Space = map_map_kernels::unite(&(v90_8),&(v90_12));
          join_wrapped_into(&mut v89_6_write,&((v90_13).read_zipper()),&[]);
          }
          v87_3_cursor.ascend(1);
        }
        drop(v89_6_write);
        map_map_kernels::compose(&(v88_5),&(v89_6))
      };
      drop(v88_5);
      let v88_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v88_2));
      drop(v88_2);
      let v88_9: Space = if map_kernels::has_head(&(v88_8)) { singleton(&[]) } else { Space::new() };
      drop(v88_8);
      let v88_11: Space = if (&(v88_9)).is_empty() { Space::new() } else {
        let mut v99_10 = Space::new();
        let mut v99_10_write = v99_10.write_zipper();
        for v99_10_byte in v87_3_cursor.child_mask().iter() {
          v87_3_cursor.descend_to_existing_byte(v99_10_byte);
          {
          let v100_2: Space = singleton(&v87_3_cursor.path()[(v87_3_origin + 1)..(v87_3_origin + 2)]);
          let v100_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v100_2));
          let v100_4: Space = if map_kernels::has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
          drop(v100_3);
          let v100_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v100_4));
          drop(v100_4);
          let v100_8: Space = if (&(v100_5)).is_empty() { Space::new() } else {
            let mut v101_7 = Space::new();
            let mut v101_7_write = v101_7.write_zipper();
            for v101_7_byte in v87_3_cursor.child_mask().iter() {
              v87_3_cursor.descend_to_existing_byte(v101_7_byte);
              {
              let v102_2: Space = singleton(&v87_3_cursor.path()[(v87_3_origin + 2)..(v87_3_origin + 3)]);
              let v102_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v102_2));
              let v102_4: Space = if map_kernels::has_head(&(v102_3)) { singleton(&[]) } else { Space::new() };
              drop(v102_3);
              let v102_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v102_4));
              drop(v102_4);
              let v102_8: Space = if (&(v102_5)).is_empty() { Space::new() } else {
                let v103_7: Space = routine_2(c, &v87_3_cursor.path()[v87_3_origin..(v87_3_origin + 3)], &v87_3_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v102_5),&(v103_7))
              };
              drop(v102_5);
              let v102_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v102_2));
              drop(v102_2);
              let v102_10: Space = if map_kernels::has_head(&(v102_9)) { singleton(&[]) } else { Space::new() };
              drop(v102_9);
              let v102_12: Space = if (&(v102_10)).is_empty() { Space::new() } else {
                let v104_11: Space = routine_3(c, &v87_3_cursor.path()[v87_3_origin..(v87_3_origin + 3)], &v87_3_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v102_10),&(v104_11))
              };
              drop(v102_10);
              let v102_13: Space = map_map_kernels::unite(&(v102_8),&(v102_12));
              join_wrapped_into(&mut v101_7_write,&((v102_13).read_zipper()),&[]);
              }
              v87_3_cursor.ascend(1);
            }
            drop(v101_7_write);
            map_map_kernels::compose(&(v100_5),&(v101_7))
          };
          drop(v100_5);
          let v100_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v100_2));
          drop(v100_2);
          let v100_10: Space = if map_kernels::has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
          drop(v100_9);
          let v100_12: Space = if (&(v100_10)).is_empty() { Space::new() } else {
            let mut v105_11 = Space::new();
            let mut v105_11_write = v105_11.write_zipper();
            for v105_11_byte in v87_3_cursor.child_mask().iter() {
              v87_3_cursor.descend_to_existing_byte(v105_11_byte);
              {
              let v106_2: Space = singleton(&v87_3_cursor.path()[(v87_3_origin + 2)..(v87_3_origin + 3)]);
              let v106_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v106_2));
              let v106_4: Space = if map_kernels::has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
              drop(v106_3);
              let v106_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v106_4));
              drop(v106_4);
              let v106_7: Space = if (&(v106_5)).is_empty() { Space::new() } else {
                let v107_6: Space = routine_5(c, &v87_3_cursor.path()[(v87_3_origin + 2)..(v87_3_origin + 3)], &v87_3_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v106_5),&(v107_6))
              };
              drop(v106_5);
              let v106_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v106_2));
              drop(v106_2);
              let v106_9: Space = if map_kernels::has_head(&(v106_8)) { singleton(&[]) } else { Space::new() };
              drop(v106_8);
              let v106_11: Space = if (&(v106_9)).is_empty() { Space::new() } else {
                let v108_10: Space = routine_6(c, &v87_3_cursor.path()[(v87_3_origin + 2)..(v87_3_origin + 3)], &v87_3_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v106_9),&(v108_10))
              };
              drop(v106_9);
              let v106_12: Space = map_map_kernels::unite(&(v106_7),&(v106_11));
              join_wrapped_into(&mut v105_11_write,&((v106_12).read_zipper()),&[]);
              }
              v87_3_cursor.ascend(1);
            }
            drop(v105_11_write);
            map_map_kernels::compose(&(v100_10),&(v105_11))
          };
          drop(v100_10);
          let v100_13: Space = map_kernels::wrap(&(v100_12),&v87_3_cursor.path()[v87_3_origin..(v87_3_origin + 2)]);
          let v100_14: Space = map_map_kernels::unite(&(v100_8),&(v100_13));
          join_wrapped_into(&mut v99_10_write,&((v100_14).read_zipper()),&[]);
          }
          v87_3_cursor.ascend(1);
        }
        drop(v99_10_write);
        map_map_kernels::compose(&(v88_9),&(v99_10))
      };
      drop(v88_9);
      let v88_12: Space = map_map_kernels::unite(&(v88_7),&(v88_11));
      join_wrapped_into(&mut v87_3_write,&((v88_12).read_zipper()),&[]);
      }
      v87_3_cursor.ascend(1);
    }
    drop(v87_3_cursor);
    drop(v87_3_write);
    let mut v87_4 = Space::new();
    let mut v87_4_write = v87_4.write_zipper();
    let mut v87_4_cursor = descend_cursor(descend_cursor(((*capture_0)).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4));
    let v87_4_origin = v87_4_cursor.path().len();
    for v87_4_byte in v87_4_cursor.child_mask().iter() {
      v87_4_cursor.descend_to_existing_byte(v87_4_byte);
      {
      let v110_2: Space = singleton(&v87_4_cursor.path()[v87_4_origin..(v87_4_origin + 1)]);
      let v110_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v110_2));
      let v110_4: Space = if map_kernels::has_head(&(v110_3)) { singleton(&[]) } else { Space::new() };
      drop(v110_3);
      let v110_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v110_4));
      drop(v110_4);
      let v110_7: Space = if (&(v110_5)).is_empty() { Space::new() } else {
        let mut v111_6 = Space::new();
        let mut v111_6_write = v111_6.write_zipper();
        for v111_6_byte in v87_4_cursor.child_mask().iter() {
          v87_4_cursor.descend_to_existing_byte(v111_6_byte);
          {
          let v112_2: Space = singleton(&v87_4_cursor.path()[(v87_4_origin + 1)..(v87_4_origin + 2)]);
          let v112_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v112_2));
          let v112_4: Space = if map_kernels::has_head(&(v112_3)) { singleton(&[]) } else { Space::new() };
          drop(v112_3);
          let v112_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v112_4));
          drop(v112_4);
          let v112_8: Space = if (&(v112_5)).is_empty() { Space::new() } else {
            let mut v113_7 = Space::new();
            let mut v113_7_write = v113_7.write_zipper();
            for v113_7_byte in v87_4_cursor.child_mask().iter() {
              v87_4_cursor.descend_to_existing_byte(v113_7_byte);
              {
              let v114_2: Space = singleton(&v87_4_cursor.path()[(v87_4_origin + 2)..(v87_4_origin + 3)]);
              let v114_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v114_2));
              let v114_4: Space = if map_kernels::has_head(&(v114_3)) { singleton(&[]) } else { Space::new() };
              drop(v114_3);
              let v114_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v114_4));
              drop(v114_4);
              let v114_8: Space = if (&(v114_5)).is_empty() { Space::new() } else {
                let v115_7: Space = routine_7(c, &v87_4_cursor.path()[v87_4_origin..(v87_4_origin + 3)], &v87_4_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v114_5),&(v115_7))
              };
              drop(v114_5);
              let v114_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v114_2));
              drop(v114_2);
              let v114_10: Space = if map_kernels::has_head(&(v114_9)) { singleton(&[]) } else { Space::new() };
              drop(v114_9);
              let v114_12: Space = if (&(v114_10)).is_empty() { Space::new() } else {
                let v116_11: Space = routine_8(c, &v87_4_cursor.path()[v87_4_origin..(v87_4_origin + 3)], &v87_4_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v114_10),&(v116_11))
              };
              drop(v114_10);
              let v114_13: Space = map_map_kernels::unite(&(v114_8),&(v114_12));
              join_wrapped_into(&mut v113_7_write,&((v114_13).read_zipper()),&[]);
              }
              v87_4_cursor.ascend(1);
            }
            drop(v113_7_write);
            map_map_kernels::compose(&(v112_5),&(v113_7))
          };
          drop(v112_5);
          let v112_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v112_2));
          drop(v112_2);
          let v112_10: Space = if map_kernels::has_head(&(v112_9)) { singleton(&[]) } else { Space::new() };
          drop(v112_9);
          let v112_12: Space = if (&(v112_10)).is_empty() { Space::new() } else {
            let mut v117_11 = Space::new();
            let mut v117_11_write = v117_11.write_zipper();
            for v117_11_byte in v87_4_cursor.child_mask().iter() {
              v87_4_cursor.descend_to_existing_byte(v117_11_byte);
              {
              let v118_2: Space = singleton(&v87_4_cursor.path()[(v87_4_origin + 2)..(v87_4_origin + 3)]);
              let v118_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v118_2));
              let v118_4: Space = if map_kernels::has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
              drop(v118_3);
              let v118_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v118_4));
              drop(v118_4);
              let v118_8: Space = if (&(v118_5)).is_empty() { Space::new() } else {
                let v119_7: Space = routine_7(c, &v87_4_cursor.path()[v87_4_origin..(v87_4_origin + 3)], &v87_4_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v118_5),&(v119_7))
              };
              drop(v118_5);
              let v118_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v118_2));
              drop(v118_2);
              let v118_10: Space = if map_kernels::has_head(&(v118_9)) { singleton(&[]) } else { Space::new() };
              drop(v118_9);
              let v118_12: Space = if (&(v118_10)).is_empty() { Space::new() } else {
                let v120_11: Space = routine_9(c, &v87_4_cursor.path()[v87_4_origin..(v87_4_origin + 3)], &v87_4_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v118_10),&(v120_11))
              };
              drop(v118_10);
              let v118_13: Space = map_map_kernels::unite(&(v118_8),&(v118_12));
              join_wrapped_into(&mut v117_11_write,&((v118_13).read_zipper()),&[]);
              }
              v87_4_cursor.ascend(1);
            }
            drop(v117_11_write);
            map_map_kernels::compose(&(v112_10),&(v117_11))
          };
          drop(v112_10);
          let v112_13: Space = map_map_kernels::unite(&(v112_8),&(v112_12));
          join_wrapped_into(&mut v111_6_write,&((v112_13).read_zipper()),&[]);
          }
          v87_4_cursor.ascend(1);
        }
        drop(v111_6_write);
        map_map_kernels::compose(&(v110_5),&(v111_6))
      };
      drop(v110_5);
      let v110_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v110_2));
      drop(v110_2);
      let v110_9: Space = if map_kernels::has_head(&(v110_8)) { singleton(&[]) } else { Space::new() };
      drop(v110_8);
      let v110_11: Space = if (&(v110_9)).is_empty() { Space::new() } else {
        let mut v121_10 = Space::new();
        let mut v121_10_write = v121_10.write_zipper();
        for v121_10_byte in v87_4_cursor.child_mask().iter() {
          v87_4_cursor.descend_to_existing_byte(v121_10_byte);
          {
          let v122_2: Space = singleton(&v87_4_cursor.path()[(v87_4_origin + 1)..(v87_4_origin + 2)]);
          let v122_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v122_2));
          let v122_4: Space = if map_kernels::has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
          drop(v122_3);
          let v122_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v122_4));
          drop(v122_4);
          let v122_8: Space = if (&(v122_5)).is_empty() { Space::new() } else {
            let mut v123_7 = Space::new();
            let mut v123_7_write = v123_7.write_zipper();
            for v123_7_byte in v87_4_cursor.child_mask().iter() {
              v87_4_cursor.descend_to_existing_byte(v123_7_byte);
              {
              let v124_2: Space = singleton(&v87_4_cursor.path()[(v87_4_origin + 2)..(v87_4_origin + 3)]);
              let v124_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v124_2));
              let v124_4: Space = if map_kernels::has_head(&(v124_3)) { singleton(&[]) } else { Space::new() };
              drop(v124_3);
              let v124_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v124_4));
              drop(v124_4);
              let v124_8: Space = if (&(v124_5)).is_empty() { Space::new() } else {
                let v125_7: Space = routine_7(c, &v87_4_cursor.path()[v87_4_origin..(v87_4_origin + 3)], &v87_4_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v124_5),&(v125_7))
              };
              drop(v124_5);
              let v124_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v124_2));
              drop(v124_2);
              let v124_10: Space = if map_kernels::has_head(&(v124_9)) { singleton(&[]) } else { Space::new() };
              drop(v124_9);
              let v124_12: Space = if (&(v124_10)).is_empty() { Space::new() } else {
                let v126_11: Space = routine_8(c, &v87_4_cursor.path()[v87_4_origin..(v87_4_origin + 3)], &v87_4_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v124_10),&(v126_11))
              };
              drop(v124_10);
              let v124_13: Space = map_map_kernels::unite(&(v124_8),&(v124_12));
              join_wrapped_into(&mut v123_7_write,&((v124_13).read_zipper()),&[]);
              }
              v87_4_cursor.ascend(1);
            }
            drop(v123_7_write);
            map_map_kernels::compose(&(v122_5),&(v123_7))
          };
          drop(v122_5);
          let v122_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v122_2));
          drop(v122_2);
          let v122_10: Space = if map_kernels::has_head(&(v122_9)) { singleton(&[]) } else { Space::new() };
          drop(v122_9);
          let v122_12: Space = if (&(v122_10)).is_empty() { Space::new() } else {
            let mut v127_11 = Space::new();
            let mut v127_11_write = v127_11.write_zipper();
            for v127_11_byte in v87_4_cursor.child_mask().iter() {
              v87_4_cursor.descend_to_existing_byte(v127_11_byte);
              {
              let v128_2: Space = singleton(&v87_4_cursor.path()[(v87_4_origin + 2)..(v87_4_origin + 3)]);
              let v128_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v128_2));
              let v128_4: Space = if map_kernels::has_head(&(v128_3)) { singleton(&[]) } else { Space::new() };
              drop(v128_3);
              let v128_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v128_4));
              drop(v128_4);
              let v128_7: Space = if (&(v128_5)).is_empty() { Space::new() } else {
                let v129_6: Space = routine_10(c, &v87_4_cursor.path()[(v87_4_origin + 2)..(v87_4_origin + 3)], &v87_4_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v128_5),&(v129_6))
              };
              drop(v128_5);
              let v128_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v128_2));
              drop(v128_2);
              let v128_9: Space = if map_kernels::has_head(&(v128_8)) { singleton(&[]) } else { Space::new() };
              drop(v128_8);
              let v128_11: Space = if (&(v128_9)).is_empty() { Space::new() } else {
                let v130_10: Space = routine_11(c, &v87_4_cursor.path()[(v87_4_origin + 2)..(v87_4_origin + 3)], &v87_4_cursor, &(((*capture_0)).read_zipper()));
                map_map_kernels::compose(&(v128_9),&(v130_10))
              };
              drop(v128_9);
              let v128_12: Space = map_map_kernels::unite(&(v128_7),&(v128_11));
              join_wrapped_into(&mut v127_11_write,&((v128_12).read_zipper()),&[]);
              }
              v87_4_cursor.ascend(1);
            }
            drop(v127_11_write);
            map_map_kernels::compose(&(v122_10),&(v127_11))
          };
          drop(v122_10);
          let v122_13: Space = map_kernels::wrap(&(v122_12),&v87_4_cursor.path()[v87_4_origin..(v87_4_origin + 2)]);
          let v122_14: Space = map_map_kernels::unite(&(v122_8),&(v122_13));
          join_wrapped_into(&mut v121_10_write,&((v122_14).read_zipper()),&[]);
          }
          v87_4_cursor.ascend(1);
        }
        drop(v121_10_write);
        map_map_kernels::compose(&(v110_9),&(v121_10))
      };
      drop(v110_9);
      let v110_12: Space = map_map_kernels::unite(&(v110_7),&(v110_11));
      join_wrapped_into(&mut v87_4_write,&((v110_12).read_zipper()),&[]);
      }
      v87_4_cursor.ascend(1);
    }
    drop(v87_4_cursor);
    drop(v87_4_write);
    let v87_5: Space = map_map_kernels::unite(&(v87_3),&(v87_4));
    let mut v87_8 = Space::new();
    let mut v87_8_write = v87_8.write_zipper();
    let mut v87_8_cursor = descend_cursor(descend_cursor(((*capture_0)).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_8));
    let v87_8_origin = v87_8_cursor.path().len();
    for v87_8_byte in v87_8_cursor.child_mask().iter() {
      v87_8_cursor.descend_to_existing_byte(v87_8_byte);
      {
      let v132_2: Space = singleton(&v87_8_cursor.path()[v87_8_origin..(v87_8_origin + 1)]);
      let v132_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v132_2));
      let v132_4: Space = if map_kernels::has_head(&(v132_3)) { singleton(&[]) } else { Space::new() };
      drop(v132_3);
      let v132_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v132_4));
      drop(v132_4);
      let v132_7: Space = if (&(v132_5)).is_empty() { Space::new() } else {
        let mut v133_6 = Space::new();
        let mut v133_6_write = v133_6.write_zipper();
        for v133_6_byte in v87_8_cursor.child_mask().iter() {
          v87_8_cursor.descend_to_existing_byte(v133_6_byte);
          {
          let v134_2: Space = singleton(&v87_8_cursor.path()[(v87_8_origin + 1)..(v87_8_origin + 2)]);
          let v134_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v134_2));
          let v134_4: Space = if map_kernels::has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
          drop(v134_3);
          let v134_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v134_4));
          drop(v134_4);
          let v134_8: Space = if (&(v134_5)).is_empty() { Space::new() } else {
            let mut v135_7 = Space::new();
            let mut v135_7_write = v135_7.write_zipper();
            for v135_7_byte in v87_8_cursor.child_mask().iter() {
              v87_8_cursor.descend_to_existing_byte(v135_7_byte);
              {
              let v136_2: Space = singleton(&v87_8_cursor.path()[(v87_8_origin + 2)..(v87_8_origin + 3)]);
              let v136_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v136_2));
              let v136_4: Space = if map_kernels::has_head(&(v136_3)) { singleton(&[]) } else { Space::new() };
              drop(v136_3);
              let v136_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v136_4));
              drop(v136_4);
              let v136_8: Space = if (&(v136_5)).is_empty() { Space::new() } else {
                let v137_7: Space = routine_12(c, &v87_8_cursor.path()[v87_8_origin..(v87_8_origin + 3)], &v87_8_cursor);
                map_map_kernels::compose(&(v136_5),&(v137_7))
              };
              drop(v136_5);
              let v136_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v136_2));
              drop(v136_2);
              let v136_10: Space = if map_kernels::has_head(&(v136_9)) { singleton(&[]) } else { Space::new() };
              drop(v136_9);
              let v136_12: Space = if (&(v136_10)).is_empty() { Space::new() } else {
                let v138_11: Space = routine_13(c, &v87_8_cursor.path()[v87_8_origin..(v87_8_origin + 3)], &v87_8_cursor);
                map_map_kernels::compose(&(v136_10),&(v138_11))
              };
              drop(v136_10);
              let v136_13: Space = map_map_kernels::unite(&(v136_8),&(v136_12));
              join_wrapped_into(&mut v135_7_write,&((v136_13).read_zipper()),&[]);
              }
              v87_8_cursor.ascend(1);
            }
            drop(v135_7_write);
            map_map_kernels::compose(&(v134_5),&(v135_7))
          };
          drop(v134_5);
          let v134_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v134_2));
          drop(v134_2);
          let v134_10: Space = if map_kernels::has_head(&(v134_9)) { singleton(&[]) } else { Space::new() };
          drop(v134_9);
          let v134_12: Space = if (&(v134_10)).is_empty() { Space::new() } else {
            let mut v139_11 = Space::new();
            let mut v139_11_write = v139_11.write_zipper();
            for v139_11_byte in v87_8_cursor.child_mask().iter() {
              v87_8_cursor.descend_to_existing_byte(v139_11_byte);
              {
              let v140_2: Space = singleton(&v87_8_cursor.path()[(v87_8_origin + 2)..(v87_8_origin + 3)]);
              let v140_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v140_2));
              let v140_4: Space = if map_kernels::has_head(&(v140_3)) { singleton(&[]) } else { Space::new() };
              drop(v140_3);
              let v140_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v140_4));
              drop(v140_4);
              let v140_8: Space = if (&(v140_5)).is_empty() { Space::new() } else {
                let v141_7: Space = routine_12(c, &v87_8_cursor.path()[v87_8_origin..(v87_8_origin + 3)], &v87_8_cursor);
                map_map_kernels::compose(&(v140_5),&(v141_7))
              };
              drop(v140_5);
              let v140_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v140_2));
              drop(v140_2);
              let v140_10: Space = if map_kernels::has_head(&(v140_9)) { singleton(&[]) } else { Space::new() };
              drop(v140_9);
              let v140_12: Space = if (&(v140_10)).is_empty() { Space::new() } else {
                let v142_11: Space = routine_14(c, &v87_8_cursor.path()[v87_8_origin..(v87_8_origin + 3)], &v87_8_cursor);
                map_map_kernels::compose(&(v140_10),&(v142_11))
              };
              drop(v140_10);
              let v140_13: Space = map_map_kernels::unite(&(v140_8),&(v140_12));
              join_wrapped_into(&mut v139_11_write,&((v140_13).read_zipper()),&[]);
              }
              v87_8_cursor.ascend(1);
            }
            drop(v139_11_write);
            map_map_kernels::compose(&(v134_10),&(v139_11))
          };
          drop(v134_10);
          let v134_13: Space = map_map_kernels::unite(&(v134_8),&(v134_12));
          join_wrapped_into(&mut v133_6_write,&((v134_13).read_zipper()),&[]);
          }
          v87_8_cursor.ascend(1);
        }
        drop(v133_6_write);
        map_map_kernels::compose(&(v132_5),&(v133_6))
      };
      drop(v132_5);
      let v132_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v132_2));
      drop(v132_2);
      let v132_9: Space = if map_kernels::has_head(&(v132_8)) { singleton(&[]) } else { Space::new() };
      drop(v132_8);
      let v132_11: Space = if (&(v132_9)).is_empty() { Space::new() } else {
        let mut v143_10 = Space::new();
        let mut v143_10_write = v143_10.write_zipper();
        for v143_10_byte in v87_8_cursor.child_mask().iter() {
          v87_8_cursor.descend_to_existing_byte(v143_10_byte);
          {
          let v144_2: Space = singleton(&v87_8_cursor.path()[(v87_8_origin + 1)..(v87_8_origin + 2)]);
          let v144_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v144_2));
          let v144_4: Space = if map_kernels::has_head(&(v144_3)) { singleton(&[]) } else { Space::new() };
          drop(v144_3);
          let v144_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v144_4));
          drop(v144_4);
          let v144_8: Space = if (&(v144_5)).is_empty() { Space::new() } else {
            let mut v145_7 = Space::new();
            let mut v145_7_write = v145_7.write_zipper();
            for v145_7_byte in v87_8_cursor.child_mask().iter() {
              v87_8_cursor.descend_to_existing_byte(v145_7_byte);
              {
              let v146_2: Space = singleton(&v87_8_cursor.path()[(v87_8_origin + 2)..(v87_8_origin + 3)]);
              let v146_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v146_2));
              let v146_4: Space = if map_kernels::has_head(&(v146_3)) { singleton(&[]) } else { Space::new() };
              drop(v146_3);
              let v146_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v146_4));
              drop(v146_4);
              let v146_8: Space = if (&(v146_5)).is_empty() { Space::new() } else {
                let v147_7: Space = routine_12(c, &v87_8_cursor.path()[v87_8_origin..(v87_8_origin + 3)], &v87_8_cursor);
                map_map_kernels::compose(&(v146_5),&(v147_7))
              };
              drop(v146_5);
              let v146_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v146_2));
              drop(v146_2);
              let v146_10: Space = if map_kernels::has_head(&(v146_9)) { singleton(&[]) } else { Space::new() };
              drop(v146_9);
              let v146_12: Space = if (&(v146_10)).is_empty() { Space::new() } else {
                let v148_11: Space = routine_13(c, &v87_8_cursor.path()[v87_8_origin..(v87_8_origin + 3)], &v87_8_cursor);
                map_map_kernels::compose(&(v146_10),&(v148_11))
              };
              drop(v146_10);
              let v146_13: Space = map_map_kernels::unite(&(v146_8),&(v146_12));
              join_wrapped_into(&mut v145_7_write,&((v146_13).read_zipper()),&[]);
              }
              v87_8_cursor.ascend(1);
            }
            drop(v145_7_write);
            map_map_kernels::compose(&(v144_5),&(v145_7))
          };
          drop(v144_5);
          let v144_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v144_2));
          drop(v144_2);
          let v144_10: Space = if map_kernels::has_head(&(v144_9)) { singleton(&[]) } else { Space::new() };
          drop(v144_9);
          let v144_12: Space = if (&(v144_10)).is_empty() { Space::new() } else {
            let v149_11: Space = view_map_kernels::subtract(&v87_8_cursor,&(*CONSTANT_5));
            map_map_kernels::compose(&(v144_10),&(v149_11))
          };
          drop(v144_10);
          let v144_13: Space = map_kernels::wrap(&(v144_12),&v87_8_cursor.path()[v87_8_origin..(v87_8_origin + 2)]);
          drop(v144_12);
          let v144_14: Space = map_map_kernels::unite(&(v144_8),&(v144_13));
          drop(v144_13);
          join_wrapped_into(&mut v143_10_write,&((v144_14).read_zipper()),&[]);
          }
          v87_8_cursor.ascend(1);
        }
        drop(v143_10_write);
        map_map_kernels::compose(&(v132_9),&(v143_10))
      };
      drop(v132_9);
      let v132_12: Space = map_map_kernels::unite(&(v132_7),&(v132_11));
      join_wrapped_into(&mut v87_8_write,&((v132_12).read_zipper()),&[]);
      }
      v87_8_cursor.ascend(1);
    }
    drop(v87_8_cursor);
    drop(v87_8_write);

((v87_3).clone(),(v87_4).clone(),(v87_5).clone(),(v87_8).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let v0_2: Space = routine_1(c, &((*CONSTANT_1).read_zipper()));
  let v0_3: Space = map_map_kernels::unite(&(*CONSTANT_0),&(v0_2));
  (&(descend_cursor((v0_3).read_zipper(),&(*CONSTANT_2)))).make_map()
}

fn routine_1(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let (mut v1_26,mut v1_48,mut v1_49,mut v1_73,) = native_block_0(c, s0);
  let v1_74: Space = map_map_kernels::unite(&(v1_49),&(v1_73));
  let mut v1_97 = Space::new();
  let mut v1_97_write = v1_97.write_zipper();
  let mut v1_97_cursor = descend_cursor(descend_cursor((*s0).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4));
  let v1_97_origin = v1_97_cursor.path().len();
  for v1_97_byte in v1_97_cursor.child_mask().iter() {
    v1_97_cursor.descend_to_existing_byte(v1_97_byte);
    {
    let v65_2: Space = singleton(&v1_97_cursor.path()[v1_97_origin..(v1_97_origin + 1)]);
    let v65_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v65_2));
    let v65_4: Space = if map_kernels::has_head(&(v65_3)) { singleton(&[]) } else { Space::new() };
    drop(v65_3);
    let v65_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v65_4));
    drop(v65_4);
    let v65_7: Space = if (&(v65_5)).is_empty() { Space::new() } else {
      let mut v66_6 = Space::new();
      let mut v66_6_write = v66_6.write_zipper();
      for v66_6_byte in v1_97_cursor.child_mask().iter() {
        v1_97_cursor.descend_to_existing_byte(v66_6_byte);
        {
        let v67_2: Space = singleton(&v1_97_cursor.path()[(v1_97_origin + 1)..(v1_97_origin + 2)]);
        let v67_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v67_2));
        let v67_4: Space = if map_kernels::has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
        drop(v67_3);
        let v67_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v67_4));
        drop(v67_4);
        let v67_8: Space = if (&(v67_5)).is_empty() { Space::new() } else {
          let mut v68_7 = Space::new();
          let mut v68_7_write = v68_7.write_zipper();
          for v68_7_byte in v1_97_cursor.child_mask().iter() {
            v1_97_cursor.descend_to_existing_byte(v68_7_byte);
            {
            let v69_2: Space = singleton(&v1_97_cursor.path()[(v1_97_origin + 2)..(v1_97_origin + 3)]);
            let v69_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v69_2));
            let v69_4: Space = if map_kernels::has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
            drop(v69_3);
            let v69_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v69_4));
            drop(v69_4);
            let v69_8: Space = if (&(v69_5)).is_empty() { Space::new() } else {
              let v70_7: Space = routine_15(c, &v1_97_cursor.path()[v1_97_origin..(v1_97_origin + 3)], &v1_97_cursor, &(*s0));
              map_map_kernels::compose(&(v69_5),&(v70_7))
            };
            drop(v69_5);
            let v69_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v69_2));
            drop(v69_2);
            let v69_10: Space = if map_kernels::has_head(&(v69_9)) { singleton(&[]) } else { Space::new() };
            drop(v69_9);
            let v69_12: Space = if (&(v69_10)).is_empty() { Space::new() } else {
              let v71_11: Space = routine_16(c, &v1_97_cursor.path()[v1_97_origin..(v1_97_origin + 3)], &v1_97_cursor, &(*s0));
              map_map_kernels::compose(&(v69_10),&(v71_11))
            };
            drop(v69_10);
            let v69_13: Space = map_map_kernels::unite(&(v69_8),&(v69_12));
            join_wrapped_into(&mut v68_7_write,&((v69_13).read_zipper()),&[]);
            }
            v1_97_cursor.ascend(1);
          }
          drop(v68_7_write);
          map_map_kernels::compose(&(v67_5),&(v68_7))
        };
        drop(v67_5);
        let v67_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v67_2));
        drop(v67_2);
        let v67_10: Space = if map_kernels::has_head(&(v67_9)) { singleton(&[]) } else { Space::new() };
        drop(v67_9);
        let v67_12: Space = if (&(v67_10)).is_empty() { Space::new() } else {
          let mut v72_11 = Space::new();
          let mut v72_11_write = v72_11.write_zipper();
          for v72_11_byte in v1_97_cursor.child_mask().iter() {
            v1_97_cursor.descend_to_existing_byte(v72_11_byte);
            {
            let v73_2: Space = singleton(&v1_97_cursor.path()[(v1_97_origin + 2)..(v1_97_origin + 3)]);
            let v73_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v73_2));
            let v73_4: Space = if map_kernels::has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
            drop(v73_3);
            let v73_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v73_4));
            drop(v73_4);
            let v73_8: Space = if (&(v73_5)).is_empty() { Space::new() } else {
              let v74_7: Space = routine_15(c, &v1_97_cursor.path()[v1_97_origin..(v1_97_origin + 3)], &v1_97_cursor, &(*s0));
              map_map_kernels::compose(&(v73_5),&(v74_7))
            };
            drop(v73_5);
            let v73_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v73_2));
            drop(v73_2);
            let v73_10: Space = if map_kernels::has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
            drop(v73_9);
            let v73_12: Space = if (&(v73_10)).is_empty() { Space::new() } else {
              let v75_11: Space = routine_17(c, &v1_97_cursor.path()[v1_97_origin..(v1_97_origin + 3)], &v1_97_cursor, &(*s0));
              map_map_kernels::compose(&(v73_10),&(v75_11))
            };
            drop(v73_10);
            let v73_13: Space = map_map_kernels::unite(&(v73_8),&(v73_12));
            join_wrapped_into(&mut v72_11_write,&((v73_13).read_zipper()),&[]);
            }
            v1_97_cursor.ascend(1);
          }
          drop(v72_11_write);
          map_map_kernels::compose(&(v67_10),&(v72_11))
        };
        drop(v67_10);
        let v67_13: Space = map_map_kernels::unite(&(v67_8),&(v67_12));
        join_wrapped_into(&mut v66_6_write,&((v67_13).read_zipper()),&[]);
        }
        v1_97_cursor.ascend(1);
      }
      drop(v66_6_write);
      map_map_kernels::compose(&(v65_5),&(v66_6))
    };
    drop(v65_5);
    let v65_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v65_2));
    drop(v65_2);
    let v65_9: Space = if map_kernels::has_head(&(v65_8)) { singleton(&[]) } else { Space::new() };
    drop(v65_8);
    let v65_11: Space = if (&(v65_9)).is_empty() { Space::new() } else {
      let mut v76_10 = Space::new();
      let mut v76_10_write = v76_10.write_zipper();
      for v76_10_byte in v1_97_cursor.child_mask().iter() {
        v1_97_cursor.descend_to_existing_byte(v76_10_byte);
        {
        let v77_2: Space = singleton(&v1_97_cursor.path()[(v1_97_origin + 1)..(v1_97_origin + 2)]);
        let v77_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v77_2));
        let v77_4: Space = if map_kernels::has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
        drop(v77_3);
        let v77_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v77_4));
        drop(v77_4);
        let v77_8: Space = if (&(v77_5)).is_empty() { Space::new() } else {
          let mut v78_7 = Space::new();
          let mut v78_7_write = v78_7.write_zipper();
          for v78_7_byte in v1_97_cursor.child_mask().iter() {
            v1_97_cursor.descend_to_existing_byte(v78_7_byte);
            {
            let v79_2: Space = singleton(&v1_97_cursor.path()[(v1_97_origin + 2)..(v1_97_origin + 3)]);
            let v79_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v79_2));
            let v79_4: Space = if map_kernels::has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
            drop(v79_3);
            let v79_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v79_4));
            drop(v79_4);
            let v79_8: Space = if (&(v79_5)).is_empty() { Space::new() } else {
              let v80_7: Space = routine_15(c, &v1_97_cursor.path()[v1_97_origin..(v1_97_origin + 3)], &v1_97_cursor, &(*s0));
              map_map_kernels::compose(&(v79_5),&(v80_7))
            };
            drop(v79_5);
            let v79_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v79_2));
            drop(v79_2);
            let v79_10: Space = if map_kernels::has_head(&(v79_9)) { singleton(&[]) } else { Space::new() };
            drop(v79_9);
            let v79_12: Space = if (&(v79_10)).is_empty() { Space::new() } else {
              let v81_11: Space = routine_16(c, &v1_97_cursor.path()[v1_97_origin..(v1_97_origin + 3)], &v1_97_cursor, &(*s0));
              map_map_kernels::compose(&(v79_10),&(v81_11))
            };
            drop(v79_10);
            let v79_13: Space = map_map_kernels::unite(&(v79_8),&(v79_12));
            join_wrapped_into(&mut v78_7_write,&((v79_13).read_zipper()),&[]);
            }
            v1_97_cursor.ascend(1);
          }
          drop(v78_7_write);
          map_map_kernels::compose(&(v77_5),&(v78_7))
        };
        drop(v77_5);
        let v77_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v77_2));
        drop(v77_2);
        let v77_10: Space = if map_kernels::has_head(&(v77_9)) { singleton(&[]) } else { Space::new() };
        drop(v77_9);
        let v77_12: Space = if (&(v77_10)).is_empty() { Space::new() } else {
          let mut v82_11 = Space::new();
          let mut v82_11_write = v82_11.write_zipper();
          for v82_11_byte in v1_97_cursor.child_mask().iter() {
            v1_97_cursor.descend_to_existing_byte(v82_11_byte);
            {
            let v83_2: Space = singleton(&v1_97_cursor.path()[(v1_97_origin + 2)..(v1_97_origin + 3)]);
            let v83_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v83_2));
            let v83_4: Space = if map_kernels::has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
            drop(v83_3);
            let v83_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v83_4));
            drop(v83_4);
            let v83_7: Space = if (&(v83_5)).is_empty() { Space::new() } else {
              let v84_6: Space = routine_18(c, &v1_97_cursor.path()[(v1_97_origin + 2)..(v1_97_origin + 3)], &v1_97_cursor, &(*s0));
              map_map_kernels::compose(&(v83_5),&(v84_6))
            };
            drop(v83_5);
            let v83_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v83_2));
            drop(v83_2);
            let v83_9: Space = if map_kernels::has_head(&(v83_8)) { singleton(&[]) } else { Space::new() };
            drop(v83_8);
            let v83_11: Space = if (&(v83_9)).is_empty() { Space::new() } else {
              let v85_10: Space = routine_19(c, &v1_97_cursor.path()[(v1_97_origin + 2)..(v1_97_origin + 3)], &v1_97_cursor, &(*s0));
              map_map_kernels::compose(&(v83_9),&(v85_10))
            };
            drop(v83_9);
            let v83_12: Space = map_map_kernels::unite(&(v83_7),&(v83_11));
            join_wrapped_into(&mut v82_11_write,&((v83_12).read_zipper()),&[]);
            }
            v1_97_cursor.ascend(1);
          }
          drop(v82_11_write);
          map_map_kernels::compose(&(v77_10),&(v82_11))
        };
        drop(v77_10);
        let v77_13: Space = map_kernels::wrap(&(v77_12),&v1_97_cursor.path()[v1_97_origin..(v1_97_origin + 2)]);
        let v77_14: Space = map_map_kernels::unite(&(v77_8),&(v77_13));
        join_wrapped_into(&mut v76_10_write,&((v77_14).read_zipper()),&[]);
        }
        v1_97_cursor.ascend(1);
      }
      drop(v76_10_write);
      map_map_kernels::compose(&(v65_9),&(v76_10))
    };
    drop(v65_9);
    let v65_12: Space = map_map_kernels::unite(&(v65_7),&(v65_11));
    join_wrapped_into(&mut v1_97_write,&((v65_12).read_zipper()),&[]);
    }
    v1_97_cursor.ascend(1);
  }
  drop(v1_97_cursor);
  drop(v1_97_write);
  let v1_98: Space = map_map_kernels::unite(&(v1_74),&(v1_97));
  let v1_101: Space = map_view_kernels::subtract(&(v1_98),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_2))));
  let v1_104: Space = map_view_kernels::subtract(&(v1_101),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_9))));
  let v1_105: Space = map_kernels::wrap(&(v1_104),&(*CONSTANT_9));
  let v1_106: Space = view_view_kernels::unite(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_3))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_7))));
  let v1_107: Space = map_kernels::wrap(&(v1_106),&(*CONSTANT_7));
  drop(v1_106);
  let v1_108: Space = map_map_kernels::unite(&(v1_105),&(v1_107));
  drop(v1_107);
  let v1_109: Space = map_view_kernels::unite(&(v1_108),&(*s0));
  let mut v1_192: Space = (v1_109).clone();
  loop {
    let (mut v87_3,mut v87_4,mut v87_5,mut v87_8,) = native_block_1(c, &v1_192);
    let v87_9: Space = map_map_kernels::unite(&(v87_5),&(v87_8));
    let mut v87_11 = Space::new();
    let mut v87_11_write = v87_11.write_zipper();
    let mut v87_11_cursor = descend_cursor(descend_cursor((v1_192).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4));
    let v87_11_origin = v87_11_cursor.path().len();
    for v87_11_byte in v87_11_cursor.child_mask().iter() {
      v87_11_cursor.descend_to_existing_byte(v87_11_byte);
      {
      let v151_2: Space = singleton(&v87_11_cursor.path()[v87_11_origin..(v87_11_origin + 1)]);
      let v151_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v151_2));
      let v151_4: Space = if map_kernels::has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
      drop(v151_3);
      let v151_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v151_4));
      drop(v151_4);
      let v151_7: Space = if (&(v151_5)).is_empty() { Space::new() } else {
        let mut v152_6 = Space::new();
        let mut v152_6_write = v152_6.write_zipper();
        for v152_6_byte in v87_11_cursor.child_mask().iter() {
          v87_11_cursor.descend_to_existing_byte(v152_6_byte);
          {
          let v153_2: Space = singleton(&v87_11_cursor.path()[(v87_11_origin + 1)..(v87_11_origin + 2)]);
          let v153_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v153_2));
          let v153_4: Space = if map_kernels::has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
          drop(v153_3);
          let v153_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v153_4));
          drop(v153_4);
          let v153_8: Space = if (&(v153_5)).is_empty() { Space::new() } else {
            let mut v154_7 = Space::new();
            let mut v154_7_write = v154_7.write_zipper();
            for v154_7_byte in v87_11_cursor.child_mask().iter() {
              v87_11_cursor.descend_to_existing_byte(v154_7_byte);
              {
              let v155_2: Space = singleton(&v87_11_cursor.path()[(v87_11_origin + 2)..(v87_11_origin + 3)]);
              let v155_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v155_2));
              let v155_4: Space = if map_kernels::has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
              drop(v155_3);
              let v155_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v155_4));
              drop(v155_4);
              let v155_8: Space = if (&(v155_5)).is_empty() { Space::new() } else {
                let v156_7: Space = routine_15(c, &v87_11_cursor.path()[v87_11_origin..(v87_11_origin + 3)], &v87_11_cursor, &((v1_192).read_zipper()));
                map_map_kernels::compose(&(v155_5),&(v156_7))
              };
              drop(v155_5);
              let v155_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v155_2));
              drop(v155_2);
              let v155_10: Space = if map_kernels::has_head(&(v155_9)) { singleton(&[]) } else { Space::new() };
              drop(v155_9);
              let v155_12: Space = if (&(v155_10)).is_empty() { Space::new() } else {
                let v157_11: Space = routine_16(c, &v87_11_cursor.path()[v87_11_origin..(v87_11_origin + 3)], &v87_11_cursor, &((v1_192).read_zipper()));
                map_map_kernels::compose(&(v155_10),&(v157_11))
              };
              drop(v155_10);
              let v155_13: Space = map_map_kernels::unite(&(v155_8),&(v155_12));
              join_wrapped_into(&mut v154_7_write,&((v155_13).read_zipper()),&[]);
              }
              v87_11_cursor.ascend(1);
            }
            drop(v154_7_write);
            map_map_kernels::compose(&(v153_5),&(v154_7))
          };
          drop(v153_5);
          let v153_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v153_2));
          drop(v153_2);
          let v153_10: Space = if map_kernels::has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
          drop(v153_9);
          let v153_12: Space = if (&(v153_10)).is_empty() { Space::new() } else {
            let mut v158_11 = Space::new();
            let mut v158_11_write = v158_11.write_zipper();
            for v158_11_byte in v87_11_cursor.child_mask().iter() {
              v87_11_cursor.descend_to_existing_byte(v158_11_byte);
              {
              let v159_2: Space = singleton(&v87_11_cursor.path()[(v87_11_origin + 2)..(v87_11_origin + 3)]);
              let v159_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v159_2));
              let v159_4: Space = if map_kernels::has_head(&(v159_3)) { singleton(&[]) } else { Space::new() };
              drop(v159_3);
              let v159_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v159_4));
              drop(v159_4);
              let v159_8: Space = if (&(v159_5)).is_empty() { Space::new() } else {
                let v160_7: Space = routine_15(c, &v87_11_cursor.path()[v87_11_origin..(v87_11_origin + 3)], &v87_11_cursor, &((v1_192).read_zipper()));
                map_map_kernels::compose(&(v159_5),&(v160_7))
              };
              drop(v159_5);
              let v159_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v159_2));
              drop(v159_2);
              let v159_10: Space = if map_kernels::has_head(&(v159_9)) { singleton(&[]) } else { Space::new() };
              drop(v159_9);
              let v159_12: Space = if (&(v159_10)).is_empty() { Space::new() } else {
                let v161_11: Space = routine_17(c, &v87_11_cursor.path()[v87_11_origin..(v87_11_origin + 3)], &v87_11_cursor, &((v1_192).read_zipper()));
                map_map_kernels::compose(&(v159_10),&(v161_11))
              };
              drop(v159_10);
              let v159_13: Space = map_map_kernels::unite(&(v159_8),&(v159_12));
              join_wrapped_into(&mut v158_11_write,&((v159_13).read_zipper()),&[]);
              }
              v87_11_cursor.ascend(1);
            }
            drop(v158_11_write);
            map_map_kernels::compose(&(v153_10),&(v158_11))
          };
          drop(v153_10);
          let v153_13: Space = map_map_kernels::unite(&(v153_8),&(v153_12));
          join_wrapped_into(&mut v152_6_write,&((v153_13).read_zipper()),&[]);
          }
          v87_11_cursor.ascend(1);
        }
        drop(v152_6_write);
        map_map_kernels::compose(&(v151_5),&(v152_6))
      };
      drop(v151_5);
      let v151_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v151_2));
      drop(v151_2);
      let v151_9: Space = if map_kernels::has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
      drop(v151_8);
      let v151_11: Space = if (&(v151_9)).is_empty() { Space::new() } else {
        let mut v162_10 = Space::new();
        let mut v162_10_write = v162_10.write_zipper();
        for v162_10_byte in v87_11_cursor.child_mask().iter() {
          v87_11_cursor.descend_to_existing_byte(v162_10_byte);
          {
          let v163_2: Space = singleton(&v87_11_cursor.path()[(v87_11_origin + 1)..(v87_11_origin + 2)]);
          let v163_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v163_2));
          let v163_4: Space = if map_kernels::has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
          drop(v163_3);
          let v163_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v163_4));
          drop(v163_4);
          let v163_8: Space = if (&(v163_5)).is_empty() { Space::new() } else {
            let mut v164_7 = Space::new();
            let mut v164_7_write = v164_7.write_zipper();
            for v164_7_byte in v87_11_cursor.child_mask().iter() {
              v87_11_cursor.descend_to_existing_byte(v164_7_byte);
              {
              let v165_2: Space = singleton(&v87_11_cursor.path()[(v87_11_origin + 2)..(v87_11_origin + 3)]);
              let v165_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v165_2));
              let v165_4: Space = if map_kernels::has_head(&(v165_3)) { singleton(&[]) } else { Space::new() };
              drop(v165_3);
              let v165_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v165_4));
              drop(v165_4);
              let v165_8: Space = if (&(v165_5)).is_empty() { Space::new() } else {
                let v166_7: Space = routine_15(c, &v87_11_cursor.path()[v87_11_origin..(v87_11_origin + 3)], &v87_11_cursor, &((v1_192).read_zipper()));
                map_map_kernels::compose(&(v165_5),&(v166_7))
              };
              drop(v165_5);
              let v165_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v165_2));
              drop(v165_2);
              let v165_10: Space = if map_kernels::has_head(&(v165_9)) { singleton(&[]) } else { Space::new() };
              drop(v165_9);
              let v165_12: Space = if (&(v165_10)).is_empty() { Space::new() } else {
                let v167_11: Space = routine_16(c, &v87_11_cursor.path()[v87_11_origin..(v87_11_origin + 3)], &v87_11_cursor, &((v1_192).read_zipper()));
                map_map_kernels::compose(&(v165_10),&(v167_11))
              };
              drop(v165_10);
              let v165_13: Space = map_map_kernels::unite(&(v165_8),&(v165_12));
              join_wrapped_into(&mut v164_7_write,&((v165_13).read_zipper()),&[]);
              }
              v87_11_cursor.ascend(1);
            }
            drop(v164_7_write);
            map_map_kernels::compose(&(v163_5),&(v164_7))
          };
          drop(v163_5);
          let v163_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v163_2));
          drop(v163_2);
          let v163_10: Space = if map_kernels::has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
          drop(v163_9);
          let v163_12: Space = if (&(v163_10)).is_empty() { Space::new() } else {
            let mut v168_11 = Space::new();
            let mut v168_11_write = v168_11.write_zipper();
            for v168_11_byte in v87_11_cursor.child_mask().iter() {
              v87_11_cursor.descend_to_existing_byte(v168_11_byte);
              {
              let v169_2: Space = singleton(&v87_11_cursor.path()[(v87_11_origin + 2)..(v87_11_origin + 3)]);
              let v169_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v169_2));
              let v169_4: Space = if map_kernels::has_head(&(v169_3)) { singleton(&[]) } else { Space::new() };
              drop(v169_3);
              let v169_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v169_4));
              drop(v169_4);
              let v169_7: Space = if (&(v169_5)).is_empty() { Space::new() } else {
                let v170_6: Space = routine_18(c, &v87_11_cursor.path()[(v87_11_origin + 2)..(v87_11_origin + 3)], &v87_11_cursor, &((v1_192).read_zipper()));
                map_map_kernels::compose(&(v169_5),&(v170_6))
              };
              drop(v169_5);
              let v169_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v169_2));
              drop(v169_2);
              let v169_9: Space = if map_kernels::has_head(&(v169_8)) { singleton(&[]) } else { Space::new() };
              drop(v169_8);
              let v169_11: Space = if (&(v169_9)).is_empty() { Space::new() } else {
                let v171_10: Space = routine_19(c, &v87_11_cursor.path()[(v87_11_origin + 2)..(v87_11_origin + 3)], &v87_11_cursor, &((v1_192).read_zipper()));
                map_map_kernels::compose(&(v169_9),&(v171_10))
              };
              drop(v169_9);
              let v169_12: Space = map_map_kernels::unite(&(v169_7),&(v169_11));
              join_wrapped_into(&mut v168_11_write,&((v169_12).read_zipper()),&[]);
              }
              v87_11_cursor.ascend(1);
            }
            drop(v168_11_write);
            map_map_kernels::compose(&(v163_10),&(v168_11))
          };
          drop(v163_10);
          let v163_13: Space = map_kernels::wrap(&(v163_12),&v87_11_cursor.path()[v87_11_origin..(v87_11_origin + 2)]);
          let v163_14: Space = map_map_kernels::unite(&(v163_8),&(v163_13));
          join_wrapped_into(&mut v162_10_write,&((v163_14).read_zipper()),&[]);
          }
          v87_11_cursor.ascend(1);
        }
        drop(v162_10_write);
        map_map_kernels::compose(&(v151_9),&(v162_10))
      };
      drop(v151_9);
      let v151_12: Space = map_map_kernels::unite(&(v151_7),&(v151_11));
      join_wrapped_into(&mut v87_11_write,&((v151_12).read_zipper()),&[]);
      }
      v87_11_cursor.ascend(1);
    }
    drop(v87_11_cursor);
    drop(v87_11_write);
    let v87_12: Space = map_map_kernels::unite(&(v87_9),&(v87_11));
    let v87_14: Space = map_view_kernels::subtract(&(v87_12),&(descend_cursor((v1_192).read_zipper(),&(*CONSTANT_2))));
    let v87_16: Space = map_view_kernels::subtract(&(v87_14),&(descend_cursor((v1_192).read_zipper(),&(*CONSTANT_9))));
    let v87_17: Space = map_kernels::wrap(&(v87_16),&(*CONSTANT_9));
    let v87_18: Space = view_view_kernels::unite(&(descend_cursor((v1_192).read_zipper(),&(*CONSTANT_3))),&(descend_cursor((v1_192).read_zipper(),&(*CONSTANT_7))));
    let v87_19: Space = map_kernels::wrap(&(v87_18),&(*CONSTANT_7));
    drop(v87_18);
    let v87_20: Space = map_map_kernels::unite(&(v87_17),&(v87_19));
    drop(v87_19);
    let v87_21: Space = map_map_kernels::unite(&(v87_20),&(v1_192));
    if !v1_192.join_into((v87_21).clone()).is_element() { break; }
  }
  let v1_193: Space = view_map_kernels::unite(&(*s0),&(v1_192));
  (v1_193).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v173_24 = Space::new();
  let mut v173_24_write = v173_24.write_zipper();
  let mut v173_24_cursor = (*s0).read_zipper();
  let v173_24_origin = v173_24_cursor.path().len();
  for v173_24_byte in v173_24_cursor.child_mask().iter() {
    v173_24_cursor.descend_to_existing_byte(v173_24_byte);
    {
    let v174_2: Space = singleton(&v173_24_cursor.path()[v173_24_origin..(v173_24_origin + 1)]);
    let v174_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v174_2));
    let v174_4: Space = if map_kernels::has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
    drop(v174_3);
    let v174_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v174_4));
    drop(v174_4);
    let v174_8: Space = if (&(v174_5)).is_empty() { Space::new() } else {
      let v175_6: Path = concat_path(&(*p0),&v173_24_cursor.path()[v173_24_origin..(v173_24_origin + 1)]);
      let mut v175_7 = Space::new();
      let mut v175_7_write = v175_7.write_zipper();
      for v175_7_byte in v173_24_cursor.child_mask().iter() {
        v173_24_cursor.descend_to_existing_byte(v175_7_byte);
        {
        let v176_2: Space = singleton(&v173_24_cursor.path()[(v173_24_origin + 1)..(v173_24_origin + 2)]);
        let v176_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v176_2));
        let v176_4: Space = if map_kernels::has_head(&(v176_3)) { singleton(&[]) } else { Space::new() };
        drop(v176_3);
        let v176_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v176_4));
        drop(v176_4);
        let v176_8: Space = if (&(v176_5)).is_empty() { Space::new() } else {
          let v177_6: Path = concat_path(&(v175_6),&v173_24_cursor.path()[(v173_24_origin + 1)..(v173_24_origin + 2)]);
          let mut v177_7 = Space::new();
          let mut v177_7_write = v177_7.write_zipper();
          for v177_7_byte in v173_24_cursor.child_mask().iter() {
            v173_24_cursor.descend_to_existing_byte(v177_7_byte);
            {
            let v178_2: Space = singleton(&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
            let v178_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v178_2));
            let v178_4: Space = if map_kernels::has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
            drop(v178_3);
            let v178_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v178_4));
            drop(v178_4);
            let v178_8: Space = if (&(v178_5)).is_empty() { Space::new() } else {
              let v179_6: Path = concat_path(&(v177_6),&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
              let v179_7: Space = routine_20(c, &(v179_6), &v173_24_cursor, &(*s1));
              map_map_kernels::compose(&(v178_5),&(v179_7))
            };
            drop(v178_5);
            let v178_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v178_2));
            drop(v178_2);
            let v178_10: Space = if map_kernels::has_head(&(v178_9)) { singleton(&[]) } else { Space::new() };
            drop(v178_9);
            let v178_12: Space = if (&(v178_10)).is_empty() { Space::new() } else {
              let v180_6: Path = concat_path(&(v177_6),&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
              let v180_11: Space = routine_21(c, &(v180_6), &v173_24_cursor, &(*s1));
              drop(v180_6);
              map_map_kernels::compose(&(v178_10),&(v180_11))
            };
            drop(v178_10);
            let v178_13: Space = map_map_kernels::unite(&(v178_8),&(v178_12));
            join_wrapped_into(&mut v177_7_write,&((v178_13).read_zipper()),&[]);
            }
            v173_24_cursor.ascend(1);
          }
          drop(v177_7_write);
          map_map_kernels::compose(&(v176_5),&(v177_7))
        };
        drop(v176_5);
        let v176_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v176_2));
        drop(v176_2);
        let v176_10: Space = if map_kernels::has_head(&(v176_9)) { singleton(&[]) } else { Space::new() };
        drop(v176_9);
        let v176_12: Space = if (&(v176_10)).is_empty() { Space::new() } else {
          let v181_6: Path = concat_path(&(v175_6),&v173_24_cursor.path()[(v173_24_origin + 1)..(v173_24_origin + 2)]);
          let mut v181_11 = Space::new();
          let mut v181_11_write = v181_11.write_zipper();
          for v181_11_byte in v173_24_cursor.child_mask().iter() {
            v173_24_cursor.descend_to_existing_byte(v181_11_byte);
            {
            let v182_2: Space = singleton(&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
            let v182_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v182_2));
            let v182_4: Space = if map_kernels::has_head(&(v182_3)) { singleton(&[]) } else { Space::new() };
            drop(v182_3);
            let v182_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v182_4));
            drop(v182_4);
            let v182_8: Space = if (&(v182_5)).is_empty() { Space::new() } else {
              let v183_6: Path = concat_path(&(v181_6),&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
              let v183_7: Space = routine_20(c, &(v183_6), &v173_24_cursor, &(*s1));
              map_map_kernels::compose(&(v182_5),&(v183_7))
            };
            drop(v182_5);
            let v182_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v182_2));
            drop(v182_2);
            let v182_10: Space = if map_kernels::has_head(&(v182_9)) { singleton(&[]) } else { Space::new() };
            drop(v182_9);
            let v182_12: Space = if (&(v182_10)).is_empty() { Space::new() } else {
              let v184_6: Path = concat_path(&(v181_6),&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
              let v184_11: Space = routine_4(c, &(v184_6), &v173_24_cursor, &(*s1));
              drop(v184_6);
              map_map_kernels::compose(&(v182_10),&(v184_11))
            };
            drop(v182_10);
            let v182_13: Space = map_map_kernels::unite(&(v182_8),&(v182_12));
            join_wrapped_into(&mut v181_11_write,&((v182_13).read_zipper()),&[]);
            }
            v173_24_cursor.ascend(1);
          }
          drop(v181_11_write);
          drop(v181_6);
          map_map_kernels::compose(&(v176_10),&(v181_11))
        };
        drop(v176_10);
        let v176_13: Space = map_map_kernels::unite(&(v176_8),&(v176_12));
        join_wrapped_into(&mut v175_7_write,&((v176_13).read_zipper()),&[]);
        }
        v173_24_cursor.ascend(1);
      }
      drop(v175_7_write);
      map_map_kernels::compose(&(v174_5),&(v175_7))
    };
    drop(v174_5);
    let v174_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v174_2));
    drop(v174_2);
    let v174_10: Space = if map_kernels::has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
    drop(v174_9);
    let v174_12: Space = if (&(v174_10)).is_empty() { Space::new() } else {
      let v185_6: Path = concat_path(&(*p0),&v173_24_cursor.path()[v173_24_origin..(v173_24_origin + 1)]);
      let mut v185_11 = Space::new();
      let mut v185_11_write = v185_11.write_zipper();
      for v185_11_byte in v173_24_cursor.child_mask().iter() {
        v173_24_cursor.descend_to_existing_byte(v185_11_byte);
        {
        let v186_2: Space = singleton(&v173_24_cursor.path()[(v173_24_origin + 1)..(v173_24_origin + 2)]);
        let v186_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v186_2));
        let v186_4: Space = if map_kernels::has_head(&(v186_3)) { singleton(&[]) } else { Space::new() };
        drop(v186_3);
        let v186_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v186_4));
        drop(v186_4);
        let v186_8: Space = if (&(v186_5)).is_empty() { Space::new() } else {
          let v187_6: Path = concat_path(&(v185_6),&v173_24_cursor.path()[(v173_24_origin + 1)..(v173_24_origin + 2)]);
          let mut v187_7 = Space::new();
          let mut v187_7_write = v187_7.write_zipper();
          for v187_7_byte in v173_24_cursor.child_mask().iter() {
            v173_24_cursor.descend_to_existing_byte(v187_7_byte);
            {
            let v188_2: Space = singleton(&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
            let v188_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v188_2));
            let v188_4: Space = if map_kernels::has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
            drop(v188_3);
            let v188_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v188_4));
            drop(v188_4);
            let v188_8: Space = if (&(v188_5)).is_empty() { Space::new() } else {
              let v189_6: Path = concat_path(&(v187_6),&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
              let v189_7: Space = routine_20(c, &(v189_6), &v173_24_cursor, &(*s1));
              map_map_kernels::compose(&(v188_5),&(v189_7))
            };
            drop(v188_5);
            let v188_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v188_2));
            drop(v188_2);
            let v188_10: Space = if map_kernels::has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
            drop(v188_9);
            let v188_12: Space = if (&(v188_10)).is_empty() { Space::new() } else {
              let v190_6: Path = concat_path(&(v187_6),&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
              let v190_11: Space = routine_21(c, &(v190_6), &v173_24_cursor, &(*s1));
              drop(v190_6);
              map_map_kernels::compose(&(v188_10),&(v190_11))
            };
            drop(v188_10);
            let v188_13: Space = map_map_kernels::unite(&(v188_8),&(v188_12));
            join_wrapped_into(&mut v187_7_write,&((v188_13).read_zipper()),&[]);
            }
            v173_24_cursor.ascend(1);
          }
          drop(v187_7_write);
          map_map_kernels::compose(&(v186_5),&(v187_7))
        };
        drop(v186_5);
        let v186_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v186_2));
        drop(v186_2);
        let v186_10: Space = if map_kernels::has_head(&(v186_9)) { singleton(&[]) } else { Space::new() };
        drop(v186_9);
        let v186_12: Space = if (&(v186_10)).is_empty() { Space::new() } else {
          let mut v191_11 = Space::new();
          let mut v191_11_write = v191_11.write_zipper();
          for v191_11_byte in v173_24_cursor.child_mask().iter() {
            v173_24_cursor.descend_to_existing_byte(v191_11_byte);
            {
            let v192_2: Space = singleton(&v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)]);
            let v192_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v192_2));
            let v192_4: Space = if map_kernels::has_head(&(v192_3)) { singleton(&[]) } else { Space::new() };
            drop(v192_3);
            let v192_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v192_4));
            drop(v192_4);
            let v192_7: Space = if (&(v192_5)).is_empty() { Space::new() } else {
              let v193_6: Space = routine_5(c, &v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)], &v173_24_cursor, &(*s1));
              map_map_kernels::compose(&(v192_5),&(v193_6))
            };
            drop(v192_5);
            let v192_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v192_2));
            drop(v192_2);
            let v192_9: Space = if map_kernels::has_head(&(v192_8)) { singleton(&[]) } else { Space::new() };
            drop(v192_8);
            let v192_11: Space = if (&(v192_9)).is_empty() { Space::new() } else {
              let v194_10: Space = routine_6(c, &v173_24_cursor.path()[(v173_24_origin + 2)..(v173_24_origin + 3)], &v173_24_cursor, &(*s1));
              map_map_kernels::compose(&(v192_9),&(v194_10))
            };
            drop(v192_9);
            let v192_12: Space = map_map_kernels::unite(&(v192_7),&(v192_11));
            join_wrapped_into(&mut v191_11_write,&((v192_12).read_zipper()),&[]);
            }
            v173_24_cursor.ascend(1);
          }
          drop(v191_11_write);
          map_map_kernels::compose(&(v186_10),&(v191_11))
        };
        drop(v186_10);
        let v195_6: Path = concat_path(&(v185_6),&v173_24_cursor.path()[(v173_24_origin + 1)..(v173_24_origin + 2)]);
        let v186_13: Space = map_kernels::wrap(&(v186_12),&(v195_6));
        let v186_14: Space = map_map_kernels::unite(&(v186_8),&(v186_13));
        join_wrapped_into(&mut v185_11_write,&((v186_14).read_zipper()),&[]);
        }
        v173_24_cursor.ascend(1);
      }
      drop(v185_11_write);
      drop(v185_6);
      map_map_kernels::compose(&(v174_10),&(v185_11))
    };
    drop(v174_10);
    let v174_13: Space = map_map_kernels::unite(&(v174_8),&(v174_12));
    join_wrapped_into(&mut v173_24_write,&((v174_13).read_zipper()),&[]);
    }
    v173_24_cursor.ascend(1);
  }
  drop(v173_24_cursor);
  drop(v173_24_write);
  (v173_24).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v196_24 = Space::new();
  let mut v196_24_write = v196_24.write_zipper();
  let mut v196_24_cursor = (*s0).read_zipper();
  let v196_24_origin = v196_24_cursor.path().len();
  for v196_24_byte in v196_24_cursor.child_mask().iter() {
    v196_24_cursor.descend_to_existing_byte(v196_24_byte);
    {
    let v197_2: Space = singleton(&v196_24_cursor.path()[v196_24_origin..(v196_24_origin + 1)]);
    let v197_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v197_2));
    let v197_4: Space = if map_kernels::has_head(&(v197_3)) { singleton(&[]) } else { Space::new() };
    drop(v197_3);
    let v197_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v197_4));
    drop(v197_4);
    let v197_8: Space = if (&(v197_5)).is_empty() { Space::new() } else {
      let v198_6: Path = concat_path(&(*p0),&v196_24_cursor.path()[v196_24_origin..(v196_24_origin + 1)]);
      let mut v198_7 = Space::new();
      let mut v198_7_write = v198_7.write_zipper();
      for v198_7_byte in v196_24_cursor.child_mask().iter() {
        v196_24_cursor.descend_to_existing_byte(v198_7_byte);
        {
        let v199_2: Space = singleton(&v196_24_cursor.path()[(v196_24_origin + 1)..(v196_24_origin + 2)]);
        let v199_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v199_2));
        let v199_4: Space = if map_kernels::has_head(&(v199_3)) { singleton(&[]) } else { Space::new() };
        drop(v199_3);
        let v199_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v199_4));
        drop(v199_4);
        let v199_8: Space = if (&(v199_5)).is_empty() { Space::new() } else {
          let v200_6: Path = concat_path(&(v198_6),&v196_24_cursor.path()[(v196_24_origin + 1)..(v196_24_origin + 2)]);
          let mut v200_7 = Space::new();
          let mut v200_7_write = v200_7.write_zipper();
          for v200_7_byte in v196_24_cursor.child_mask().iter() {
            v196_24_cursor.descend_to_existing_byte(v200_7_byte);
            {
            let v201_2: Space = singleton(&v196_24_cursor.path()[(v196_24_origin + 2)..(v196_24_origin + 3)]);
            let v201_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v201_2));
            let v201_4: Space = if map_kernels::has_head(&(v201_3)) { singleton(&[]) } else { Space::new() };
            drop(v201_3);
            let v201_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v201_4));
            drop(v201_4);
            let v201_8: Space = if (&(v201_5)).is_empty() { Space::new() } else {
              let v202_6: Path = concat_path(&(v200_6),&v196_24_cursor.path()[(v196_24_origin + 2)..(v196_24_origin + 3)]);
              let v202_7: Space = routine_20(c, &(v202_6), &v196_24_cursor, &(*s1));
              map_map_kernels::compose(&(v201_5),&(v202_7))
            };
            drop(v201_5);
            let v201_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v201_2));
            drop(v201_2);
            let v201_10: Space = if map_kernels::has_head(&(v201_9)) { singleton(&[]) } else { Space::new() };
            drop(v201_9);
            let v201_12: Space = if (&(v201_10)).is_empty() { Space::new() } else {
              let v203_6: Path = concat_path(&(v200_6),&v196_24_cursor.path()[(v196_24_origin + 2)..(v196_24_origin + 3)]);
              let v203_11: Space = routine_21(c, &(v203_6), &v196_24_cursor, &(*s1));
              drop(v203_6);
              map_map_kernels::compose(&(v201_10),&(v203_11))
            };
            drop(v201_10);
            let v201_13: Space = map_map_kernels::unite(&(v201_8),&(v201_12));
            join_wrapped_into(&mut v200_7_write,&((v201_13).read_zipper()),&[]);
            }
            v196_24_cursor.ascend(1);
          }
          drop(v200_7_write);
          map_map_kernels::compose(&(v199_5),&(v200_7))
        };
        drop(v199_5);
        let v199_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v199_2));
        drop(v199_2);
        let v199_10: Space = if map_kernels::has_head(&(v199_9)) { singleton(&[]) } else { Space::new() };
        drop(v199_9);
        let v199_12: Space = if (&(v199_10)).is_empty() { Space::new() } else {
          let v204_6: Path = concat_path(&(v198_6),&v196_24_cursor.path()[(v196_24_origin + 1)..(v196_24_origin + 2)]);
          let mut v204_11 = Space::new();
          let mut v204_11_write = v204_11.write_zipper();
          for v204_11_byte in v196_24_cursor.child_mask().iter() {
            v196_24_cursor.descend_to_existing_byte(v204_11_byte);
            {
            let v205_2: Space = singleton(&v196_24_cursor.path()[(v196_24_origin + 2)..(v196_24_origin + 3)]);
            let v205_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v205_2));
            let v205_4: Space = if map_kernels::has_head(&(v205_3)) { singleton(&[]) } else { Space::new() };
            drop(v205_3);
            let v205_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v205_4));
            drop(v205_4);
            let v205_8: Space = if (&(v205_5)).is_empty() { Space::new() } else {
              let v206_6: Path = concat_path(&(v204_6),&v196_24_cursor.path()[(v196_24_origin + 2)..(v196_24_origin + 3)]);
              let v206_7: Space = routine_20(c, &(v206_6), &v196_24_cursor, &(*s1));
              map_map_kernels::compose(&(v205_5),&(v206_7))
            };
            drop(v205_5);
            let v205_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v205_2));
            drop(v205_2);
            let v205_10: Space = if map_kernels::has_head(&(v205_9)) { singleton(&[]) } else { Space::new() };
            drop(v205_9);
            let v205_12: Space = if (&(v205_10)).is_empty() { Space::new() } else {
              let v207_6: Path = concat_path(&(v204_6),&v196_24_cursor.path()[(v196_24_origin + 2)..(v196_24_origin + 3)]);
              let v207_11: Space = routine_4(c, &(v207_6), &v196_24_cursor, &(*s1));
              drop(v207_6);
              map_map_kernels::compose(&(v205_10),&(v207_11))
            };
            drop(v205_10);
            let v205_13: Space = map_map_kernels::unite(&(v205_8),&(v205_12));
            join_wrapped_into(&mut v204_11_write,&((v205_13).read_zipper()),&[]);
            }
            v196_24_cursor.ascend(1);
          }
          drop(v204_11_write);
          drop(v204_6);
          map_map_kernels::compose(&(v199_10),&(v204_11))
        };
        drop(v199_10);
        let v199_13: Space = map_map_kernels::unite(&(v199_8),&(v199_12));
        join_wrapped_into(&mut v198_7_write,&((v199_13).read_zipper()),&[]);
        }
        v196_24_cursor.ascend(1);
      }
      drop(v198_7_write);
      map_map_kernels::compose(&(v197_5),&(v198_7))
    };
    drop(v197_5);
    let v197_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v197_2));
    drop(v197_2);
    let v197_10: Space = if map_kernels::has_head(&(v197_9)) { singleton(&[]) } else { Space::new() };
    drop(v197_9);
    let v197_12: Space = if (&(v197_10)).is_empty() { Space::new() } else {
      let mut v208_11 = Space::new();
      let mut v208_11_write = v208_11.write_zipper();
      for v208_11_byte in v196_24_cursor.child_mask().iter() {
        v196_24_cursor.descend_to_existing_byte(v208_11_byte);
        {
        let v209_2: Space = singleton(&v196_24_cursor.path()[(v196_24_origin + 1)..(v196_24_origin + 2)]);
        let v209_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v209_2));
        let v209_4: Space = if map_kernels::has_head(&(v209_3)) { singleton(&[]) } else { Space::new() };
        drop(v209_3);
        let v209_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v209_4));
        drop(v209_4);
        let v209_7: Space = if (&(v209_5)).is_empty() { Space::new() } else {
          let mut v210_6 = Space::new();
          let mut v210_6_write = v210_6.write_zipper();
          for v210_6_byte in v196_24_cursor.child_mask().iter() {
            v196_24_cursor.descend_to_existing_byte(v210_6_byte);
            {
            let v211_2: Space = singleton(&v196_24_cursor.path()[(v196_24_origin + 2)..(v196_24_origin + 3)]);
            let v211_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v211_2));
            let v211_4: Space = if map_kernels::has_head(&(v211_3)) { singleton(&[]) } else { Space::new() };
            drop(v211_3);
            let v211_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v211_4));
            drop(v211_4);
            let v211_8: Space = if (&(v211_5)).is_empty() { Space::new() } else {
              let v212_7: Space = routine_22(c, &v196_24_cursor.path()[(v196_24_origin + 1)..(v196_24_origin + 3)], &v196_24_cursor, &(*s1));
              map_map_kernels::compose(&(v211_5),&(v212_7))
            };
            drop(v211_5);
            let v211_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v211_2));
            drop(v211_2);
            let v211_10: Space = if map_kernels::has_head(&(v211_9)) { singleton(&[]) } else { Space::new() };
            drop(v211_9);
            let v211_12: Space = if (&(v211_10)).is_empty() { Space::new() } else {
              let v213_11: Space = routine_23(c, &v196_24_cursor.path()[(v196_24_origin + 1)..(v196_24_origin + 3)], &v196_24_cursor, &(*s1));
              map_map_kernels::compose(&(v211_10),&(v213_11))
            };
            drop(v211_10);
            let v211_13: Space = map_map_kernels::unite(&(v211_8),&(v211_12));
            join_wrapped_into(&mut v210_6_write,&((v211_13).read_zipper()),&[]);
            }
            v196_24_cursor.ascend(1);
          }
          drop(v210_6_write);
          map_map_kernels::compose(&(v209_5),&(v210_6))
        };
        drop(v209_5);
        let v209_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v209_2));
        drop(v209_2);
        let v209_9: Space = if map_kernels::has_head(&(v209_8)) { singleton(&[]) } else { Space::new() };
        drop(v209_8);
        let v209_11: Space = if (&(v209_9)).is_empty() { Space::new() } else {
          let mut v214_10 = Space::new();
          let mut v214_10_write = v214_10.write_zipper();
          for v214_10_byte in v196_24_cursor.child_mask().iter() {
            v196_24_cursor.descend_to_existing_byte(v214_10_byte);
            {
            let v215_2: Space = singleton(&v196_24_cursor.path()[(v196_24_origin + 2)..(v196_24_origin + 3)]);
            let v215_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v215_2));
            let v215_4: Space = if map_kernels::has_head(&(v215_3)) { singleton(&[]) } else { Space::new() };
            drop(v215_3);
            let v215_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v215_4));
            drop(v215_4);
            let v215_8: Space = if (&(v215_5)).is_empty() { Space::new() } else {
              let v216_7: Space = routine_22(c, &v196_24_cursor.path()[(v196_24_origin + 1)..(v196_24_origin + 3)], &v196_24_cursor, &(*s1));
              map_map_kernels::compose(&(v215_5),&(v216_7))
            };
            drop(v215_5);
            let v215_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v215_2));
            drop(v215_2);
            let v215_10: Space = if map_kernels::has_head(&(v215_9)) { singleton(&[]) } else { Space::new() };
            drop(v215_9);
            let v215_12: Space = if (&(v215_10)).is_empty() { Space::new() } else {
              let v217_11: Space = routine_24(c, &v196_24_cursor.path()[(v196_24_origin + 1)..(v196_24_origin + 3)], &v196_24_cursor, &(*s1));
              map_map_kernels::compose(&(v215_10),&(v217_11))
            };
            drop(v215_10);
            let v215_13: Space = map_map_kernels::unite(&(v215_8),&(v215_12));
            join_wrapped_into(&mut v214_10_write,&((v215_13).read_zipper()),&[]);
            }
            v196_24_cursor.ascend(1);
          }
          drop(v214_10_write);
          map_map_kernels::compose(&(v209_9),&(v214_10))
        };
        drop(v209_9);
        let v209_12: Space = map_map_kernels::unite(&(v209_7),&(v209_11));
        join_wrapped_into(&mut v208_11_write,&((v209_12).read_zipper()),&[]);
        }
        v196_24_cursor.ascend(1);
      }
      drop(v208_11_write);
      map_map_kernels::compose(&(v197_10),&(v208_11))
    };
    drop(v197_10);
    let v218_6: Path = concat_path(&(*p0),&v196_24_cursor.path()[v196_24_origin..(v196_24_origin + 1)]);
    let v197_13: Space = map_kernels::wrap(&(v197_12),&(v218_6));
    let v197_14: Space = map_map_kernels::unite(&(v197_8),&(v197_13));
    join_wrapped_into(&mut v196_24_write,&((v197_14).read_zipper()),&[]);
    }
    v196_24_cursor.ascend(1);
  }
  drop(v196_24_cursor);
  drop(v196_24_write);
  (v196_24).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v219_26 = Space::new();
  let mut v219_26_write = v219_26.write_zipper();
  let mut v219_26_cursor = (*s0).read_zipper();
  let v219_26_origin = v219_26_cursor.path().len();
  for v219_26_byte in v219_26_cursor.child_mask().iter() {
    v219_26_cursor.descend_to_existing_byte(v219_26_byte);
    {
    let v220_2: Space = singleton(&v219_26_cursor.path()[v219_26_origin..(v219_26_origin + 1)]);
    let v220_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v220_2));
    let v220_4: Space = if map_kernels::has_head(&(v220_3)) { singleton(&[]) } else { Space::new() };
    drop(v220_3);
    let v220_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v220_4));
    drop(v220_4);
    let v220_7: Space = if (&(v220_5)).is_empty() { Space::new() } else {
      let mut v221_6 = Space::new();
      let mut v221_6_write = v221_6.write_zipper();
      for v221_6_byte in v219_26_cursor.child_mask().iter() {
        v219_26_cursor.descend_to_existing_byte(v221_6_byte);
        {
        let v222_2: Space = singleton(&v219_26_cursor.path()[(v219_26_origin + 1)..(v219_26_origin + 2)]);
        let v222_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v222_2));
        let v222_4: Space = if map_kernels::has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
        drop(v222_3);
        let v222_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v222_4));
        drop(v222_4);
        let v222_8: Space = if (&(v222_5)).is_empty() { Space::new() } else {
          let mut v223_7 = Space::new();
          let mut v223_7_write = v223_7.write_zipper();
          for v223_7_byte in v219_26_cursor.child_mask().iter() {
            v219_26_cursor.descend_to_existing_byte(v223_7_byte);
            {
            let v224_2: Space = singleton(&v219_26_cursor.path()[(v219_26_origin + 2)..(v219_26_origin + 3)]);
            let v224_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v224_2));
            let v224_4: Space = if map_kernels::has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
            drop(v224_3);
            let v224_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v224_4));
            drop(v224_4);
            let v224_8: Space = if (&(v224_5)).is_empty() { Space::new() } else {
              let v225_7: Space = routine_25(c, &v219_26_cursor.path()[v219_26_origin..(v219_26_origin + 3)], &v219_26_cursor, &(*s1));
              map_map_kernels::compose(&(v224_5),&(v225_7))
            };
            drop(v224_5);
            let v224_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v224_2));
            drop(v224_2);
            let v224_10: Space = if map_kernels::has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
            drop(v224_9);
            let v224_12: Space = if (&(v224_10)).is_empty() { Space::new() } else {
              let v226_11: Space = routine_26(c, &v219_26_cursor.path()[v219_26_origin..(v219_26_origin + 3)], &v219_26_cursor, &(*s1));
              map_map_kernels::compose(&(v224_10),&(v226_11))
            };
            drop(v224_10);
            let v224_13: Space = map_map_kernels::unite(&(v224_8),&(v224_12));
            join_wrapped_into(&mut v223_7_write,&((v224_13).read_zipper()),&[]);
            }
            v219_26_cursor.ascend(1);
          }
          drop(v223_7_write);
          map_map_kernels::compose(&(v222_5),&(v223_7))
        };
        drop(v222_5);
        let v222_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v222_2));
        drop(v222_2);
        let v222_10: Space = if map_kernels::has_head(&(v222_9)) { singleton(&[]) } else { Space::new() };
        drop(v222_9);
        let v222_12: Space = if (&(v222_10)).is_empty() { Space::new() } else {
          let mut v227_11 = Space::new();
          let mut v227_11_write = v227_11.write_zipper();
          for v227_11_byte in v219_26_cursor.child_mask().iter() {
            v219_26_cursor.descend_to_existing_byte(v227_11_byte);
            {
            let v228_2: Space = singleton(&v219_26_cursor.path()[(v219_26_origin + 2)..(v219_26_origin + 3)]);
            let v228_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v228_2));
            let v228_4: Space = if map_kernels::has_head(&(v228_3)) { singleton(&[]) } else { Space::new() };
            drop(v228_3);
            let v228_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v228_4));
            drop(v228_4);
            let v228_8: Space = if (&(v228_5)).is_empty() { Space::new() } else {
              let v229_7: Space = routine_25(c, &v219_26_cursor.path()[v219_26_origin..(v219_26_origin + 3)], &v219_26_cursor, &(*s1));
              map_map_kernels::compose(&(v228_5),&(v229_7))
            };
            drop(v228_5);
            let v228_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v228_2));
            drop(v228_2);
            let v228_10: Space = if map_kernels::has_head(&(v228_9)) { singleton(&[]) } else { Space::new() };
            drop(v228_9);
            let v228_12: Space = if (&(v228_10)).is_empty() { Space::new() } else {
              let v230_11: Space = routine_24(c, &v219_26_cursor.path()[v219_26_origin..(v219_26_origin + 3)], &v219_26_cursor, &(*s1));
              map_map_kernels::compose(&(v228_10),&(v230_11))
            };
            drop(v228_10);
            let v228_13: Space = map_map_kernels::unite(&(v228_8),&(v228_12));
            join_wrapped_into(&mut v227_11_write,&((v228_13).read_zipper()),&[]);
            }
            v219_26_cursor.ascend(1);
          }
          drop(v227_11_write);
          map_map_kernels::compose(&(v222_10),&(v227_11))
        };
        drop(v222_10);
        let v222_13: Space = map_map_kernels::unite(&(v222_8),&(v222_12));
        join_wrapped_into(&mut v221_6_write,&((v222_13).read_zipper()),&[]);
        }
        v219_26_cursor.ascend(1);
      }
      drop(v221_6_write);
      map_map_kernels::compose(&(v220_5),&(v221_6))
    };
    drop(v220_5);
    let v220_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v220_2));
    drop(v220_2);
    let v220_9: Space = if map_kernels::has_head(&(v220_8)) { singleton(&[]) } else { Space::new() };
    drop(v220_8);
    let v220_12: Space = if (&(v220_9)).is_empty() { Space::new() } else {
      let mut v231_11 = Space::new();
      let mut v231_11_write = v231_11.write_zipper();
      for v231_11_byte in v219_26_cursor.child_mask().iter() {
        v219_26_cursor.descend_to_existing_byte(v231_11_byte);
        {
        let v232_2: Space = singleton(&v219_26_cursor.path()[(v219_26_origin + 1)..(v219_26_origin + 2)]);
        let v232_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v232_2));
        let v232_4: Space = if map_kernels::has_head(&(v232_3)) { singleton(&[]) } else { Space::new() };
        drop(v232_3);
        let v232_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v232_4));
        drop(v232_4);
        let v232_8: Space = if (&(v232_5)).is_empty() { Space::new() } else {
          let mut v233_7 = Space::new();
          let mut v233_7_write = v233_7.write_zipper();
          for v233_7_byte in v219_26_cursor.child_mask().iter() {
            v219_26_cursor.descend_to_existing_byte(v233_7_byte);
            {
            let v234_2: Space = singleton(&v219_26_cursor.path()[(v219_26_origin + 2)..(v219_26_origin + 3)]);
            let v234_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v234_2));
            let v234_4: Space = if map_kernels::has_head(&(v234_3)) { singleton(&[]) } else { Space::new() };
            drop(v234_3);
            let v234_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v234_4));
            drop(v234_4);
            let v234_8: Space = if (&(v234_5)).is_empty() { Space::new() } else {
              let v235_7: Space = routine_25(c, &v219_26_cursor.path()[v219_26_origin..(v219_26_origin + 3)], &v219_26_cursor, &(*s1));
              map_map_kernels::compose(&(v234_5),&(v235_7))
            };
            drop(v234_5);
            let v234_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v234_2));
            drop(v234_2);
            let v234_10: Space = if map_kernels::has_head(&(v234_9)) { singleton(&[]) } else { Space::new() };
            drop(v234_9);
            let v234_12: Space = if (&(v234_10)).is_empty() { Space::new() } else {
              let v236_11: Space = routine_26(c, &v219_26_cursor.path()[v219_26_origin..(v219_26_origin + 3)], &v219_26_cursor, &(*s1));
              map_map_kernels::compose(&(v234_10),&(v236_11))
            };
            drop(v234_10);
            let v234_13: Space = map_map_kernels::unite(&(v234_8),&(v234_12));
            join_wrapped_into(&mut v233_7_write,&((v234_13).read_zipper()),&[]);
            }
            v219_26_cursor.ascend(1);
          }
          drop(v233_7_write);
          map_map_kernels::compose(&(v232_5),&(v233_7))
        };
        drop(v232_5);
        let v232_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v232_2));
        drop(v232_2);
        let v232_10: Space = if map_kernels::has_head(&(v232_9)) { singleton(&[]) } else { Space::new() };
        drop(v232_9);
        let v232_13: Space = if (&(v232_10)).is_empty() { Space::new() } else {
          let v237_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&v219_26_cursor.path()[v219_26_origin..(v219_26_origin + 1)]),&v219_26_cursor.path()[(v219_26_origin + 1)..(v219_26_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v232_10),&(v237_12))
        };
        drop(v232_10);
        let v232_14: Space = map_map_kernels::unite(&(v232_8),&(v232_13));
        drop(v232_13);
        join_wrapped_into(&mut v231_11_write,&((v232_14).read_zipper()),&[]);
        }
        v219_26_cursor.ascend(1);
      }
      drop(v231_11_write);
      map_map_kernels::compose(&(v220_9),&(v231_11))
    };
    drop(v220_9);
    let v220_13: Space = map_map_kernels::unite(&(v220_7),&(v220_12));
    join_wrapped_into(&mut v219_26_write,&((v220_13).read_zipper()),&[]);
    }
    v219_26_cursor.ascend(1);
  }
  drop(v219_26_cursor);
  drop(v219_26_write);
  let v219_27: Space = map_kernels::wrap(&(v219_26),&(*p0));
  (v219_27).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v238_27 = Space::new();
  let mut v238_27_write = v238_27.write_zipper();
  let mut v238_27_cursor = (*s0).read_zipper();
  let v238_27_origin = v238_27_cursor.path().len();
  for v238_27_byte in v238_27_cursor.child_mask().iter() {
    v238_27_cursor.descend_to_existing_byte(v238_27_byte);
    {
    let v239_2: Space = singleton(&v238_27_cursor.path()[v238_27_origin..(v238_27_origin + 1)]);
    let v239_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v239_2));
    let v239_4: Space = if map_kernels::has_head(&(v239_3)) { singleton(&[]) } else { Space::new() };
    drop(v239_3);
    let v239_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v239_4));
    drop(v239_4);
    let v239_8: Space = if (&(v239_5)).is_empty() { Space::new() } else {
      let v240_6: Path = concat_path(&(*p0),&v238_27_cursor.path()[v238_27_origin..(v238_27_origin + 1)]);
      let mut v240_7 = Space::new();
      let mut v240_7_write = v240_7.write_zipper();
      for v240_7_byte in v238_27_cursor.child_mask().iter() {
        v238_27_cursor.descend_to_existing_byte(v240_7_byte);
        {
        let v241_2: Space = singleton(&v238_27_cursor.path()[(v238_27_origin + 1)..(v238_27_origin + 2)]);
        let v241_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v241_2));
        let v241_4: Space = if map_kernels::has_head(&(v241_3)) { singleton(&[]) } else { Space::new() };
        drop(v241_3);
        let v241_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v241_4));
        drop(v241_4);
        let v241_8: Space = if (&(v241_5)).is_empty() { Space::new() } else {
          let v242_6: Path = concat_path(&(v240_6),&v238_27_cursor.path()[(v238_27_origin + 1)..(v238_27_origin + 2)]);
          let mut v242_7 = Space::new();
          let mut v242_7_write = v242_7.write_zipper();
          for v242_7_byte in v238_27_cursor.child_mask().iter() {
            v238_27_cursor.descend_to_existing_byte(v242_7_byte);
            {
            let v243_2: Space = singleton(&v238_27_cursor.path()[(v238_27_origin + 2)..(v238_27_origin + 3)]);
            let v243_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v243_2));
            let v243_4: Space = if map_kernels::has_head(&(v243_3)) { singleton(&[]) } else { Space::new() };
            drop(v243_3);
            let v243_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v243_4));
            drop(v243_4);
            let v243_8: Space = if (&(v243_5)).is_empty() { Space::new() } else {
              let v244_6: Path = concat_path(&(v242_6),&v238_27_cursor.path()[(v238_27_origin + 2)..(v238_27_origin + 3)]);
              let v244_7: Space = routine_27(c, &(v244_6), &v238_27_cursor, &(*s1));
              map_map_kernels::compose(&(v243_5),&(v244_7))
            };
            drop(v243_5);
            let v243_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v243_2));
            drop(v243_2);
            let v243_10: Space = if map_kernels::has_head(&(v243_9)) { singleton(&[]) } else { Space::new() };
            drop(v243_9);
            let v243_12: Space = if (&(v243_10)).is_empty() { Space::new() } else {
              let v245_6: Path = concat_path(&(v242_6),&v238_27_cursor.path()[(v238_27_origin + 2)..(v238_27_origin + 3)]);
              let v245_11: Space = routine_28(c, &(v245_6), &v238_27_cursor, &(*s1));
              drop(v245_6);
              map_map_kernels::compose(&(v243_10),&(v245_11))
            };
            drop(v243_10);
            let v243_13: Space = map_map_kernels::unite(&(v243_8),&(v243_12));
            join_wrapped_into(&mut v242_7_write,&((v243_13).read_zipper()),&[]);
            }
            v238_27_cursor.ascend(1);
          }
          drop(v242_7_write);
          map_map_kernels::compose(&(v241_5),&(v242_7))
        };
        drop(v241_5);
        let v241_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v241_2));
        drop(v241_2);
        let v241_10: Space = if map_kernels::has_head(&(v241_9)) { singleton(&[]) } else { Space::new() };
        drop(v241_9);
        let v241_12: Space = if (&(v241_10)).is_empty() { Space::new() } else {
          let v246_6: Path = concat_path(&(v240_6),&v238_27_cursor.path()[(v238_27_origin + 1)..(v238_27_origin + 2)]);
          let mut v246_11 = Space::new();
          let mut v246_11_write = v246_11.write_zipper();
          for v246_11_byte in v238_27_cursor.child_mask().iter() {
            v238_27_cursor.descend_to_existing_byte(v246_11_byte);
            {
            let v247_2: Space = singleton(&v238_27_cursor.path()[(v238_27_origin + 2)..(v238_27_origin + 3)]);
            let v247_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v247_2));
            let v247_4: Space = if map_kernels::has_head(&(v247_3)) { singleton(&[]) } else { Space::new() };
            drop(v247_3);
            let v247_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v247_4));
            drop(v247_4);
            let v247_8: Space = if (&(v247_5)).is_empty() { Space::new() } else {
              let v248_6: Path = concat_path(&(v246_6),&v238_27_cursor.path()[(v238_27_origin + 2)..(v238_27_origin + 3)]);
              let v248_7: Space = routine_27(c, &(v248_6), &v238_27_cursor, &(*s1));
              map_map_kernels::compose(&(v247_5),&(v248_7))
            };
            drop(v247_5);
            let v247_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v247_2));
            drop(v247_2);
            let v247_10: Space = if map_kernels::has_head(&(v247_9)) { singleton(&[]) } else { Space::new() };
            drop(v247_9);
            let v247_12: Space = if (&(v247_10)).is_empty() { Space::new() } else {
              let v249_6: Path = concat_path(&(v246_6),&v238_27_cursor.path()[(v238_27_origin + 2)..(v238_27_origin + 3)]);
              let v249_11: Space = routine_24(c, &(v249_6), &v238_27_cursor, &(*s1));
              drop(v249_6);
              map_map_kernels::compose(&(v247_10),&(v249_11))
            };
            drop(v247_10);
            let v247_13: Space = map_map_kernels::unite(&(v247_8),&(v247_12));
            join_wrapped_into(&mut v246_11_write,&((v247_13).read_zipper()),&[]);
            }
            v238_27_cursor.ascend(1);
          }
          drop(v246_11_write);
          drop(v246_6);
          map_map_kernels::compose(&(v241_10),&(v246_11))
        };
        drop(v241_10);
        let v241_13: Space = map_map_kernels::unite(&(v241_8),&(v241_12));
        join_wrapped_into(&mut v240_7_write,&((v241_13).read_zipper()),&[]);
        }
        v238_27_cursor.ascend(1);
      }
      drop(v240_7_write);
      map_map_kernels::compose(&(v239_5),&(v240_7))
    };
    drop(v239_5);
    let v239_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v239_2));
    drop(v239_2);
    let v239_10: Space = if map_kernels::has_head(&(v239_9)) { singleton(&[]) } else { Space::new() };
    drop(v239_9);
    let v239_13: Space = if (&(v239_10)).is_empty() { Space::new() } else {
      let v250_6: Path = concat_path(&(*p0),&v238_27_cursor.path()[v238_27_origin..(v238_27_origin + 1)]);
      let mut v250_12 = Space::new();
      let mut v250_12_write = v250_12.write_zipper();
      for v250_12_byte in v238_27_cursor.child_mask().iter() {
        v238_27_cursor.descend_to_existing_byte(v250_12_byte);
        {
        let v251_2: Space = singleton(&v238_27_cursor.path()[(v238_27_origin + 1)..(v238_27_origin + 2)]);
        let v251_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v251_2));
        let v251_4: Space = if map_kernels::has_head(&(v251_3)) { singleton(&[]) } else { Space::new() };
        drop(v251_3);
        let v251_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v251_4));
        drop(v251_4);
        let v251_8: Space = if (&(v251_5)).is_empty() { Space::new() } else {
          let v252_6: Path = concat_path(&(v250_6),&v238_27_cursor.path()[(v238_27_origin + 1)..(v238_27_origin + 2)]);
          let mut v252_7 = Space::new();
          let mut v252_7_write = v252_7.write_zipper();
          for v252_7_byte in v238_27_cursor.child_mask().iter() {
            v238_27_cursor.descend_to_existing_byte(v252_7_byte);
            {
            let v253_2: Space = singleton(&v238_27_cursor.path()[(v238_27_origin + 2)..(v238_27_origin + 3)]);
            let v253_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v253_2));
            let v253_4: Space = if map_kernels::has_head(&(v253_3)) { singleton(&[]) } else { Space::new() };
            drop(v253_3);
            let v253_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v253_4));
            drop(v253_4);
            let v253_8: Space = if (&(v253_5)).is_empty() { Space::new() } else {
              let v254_6: Path = concat_path(&(v252_6),&v238_27_cursor.path()[(v238_27_origin + 2)..(v238_27_origin + 3)]);
              let v254_7: Space = routine_27(c, &(v254_6), &v238_27_cursor, &(*s1));
              map_map_kernels::compose(&(v253_5),&(v254_7))
            };
            drop(v253_5);
            let v253_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v253_2));
            drop(v253_2);
            let v253_10: Space = if map_kernels::has_head(&(v253_9)) { singleton(&[]) } else { Space::new() };
            drop(v253_9);
            let v253_12: Space = if (&(v253_10)).is_empty() { Space::new() } else {
              let v255_6: Path = concat_path(&(v252_6),&v238_27_cursor.path()[(v238_27_origin + 2)..(v238_27_origin + 3)]);
              let v255_11: Space = routine_28(c, &(v255_6), &v238_27_cursor, &(*s1));
              drop(v255_6);
              map_map_kernels::compose(&(v253_10),&(v255_11))
            };
            drop(v253_10);
            let v253_13: Space = map_map_kernels::unite(&(v253_8),&(v253_12));
            join_wrapped_into(&mut v252_7_write,&((v253_13).read_zipper()),&[]);
            }
            v238_27_cursor.ascend(1);
          }
          drop(v252_7_write);
          drop(v252_6);
          map_map_kernels::compose(&(v251_5),&(v252_7))
        };
        drop(v251_5);
        let v251_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v251_2));
        drop(v251_2);
        let v251_10: Space = if map_kernels::has_head(&(v251_9)) { singleton(&[]) } else { Space::new() };
        drop(v251_9);
        let v251_13: Space = if (&(v251_10)).is_empty() { Space::new() } else {
          let v256_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v238_27_cursor.path()[v238_27_origin..(v238_27_origin + 1)]),&v238_27_cursor.path()[(v238_27_origin + 1)..(v238_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v251_10),&(v256_12))
        };
        drop(v251_10);
        let v251_14: Space = map_map_kernels::unite(&(v251_8),&(v251_13));
        drop(v251_13);
        join_wrapped_into(&mut v250_12_write,&((v251_14).read_zipper()),&[]);
        }
        v238_27_cursor.ascend(1);
      }
      drop(v250_12_write);
      drop(v250_6);
      map_map_kernels::compose(&(v239_10),&(v250_12))
    };
    drop(v239_10);
    let v239_14: Space = map_map_kernels::unite(&(v239_8),&(v239_13));
    join_wrapped_into(&mut v238_27_write,&((v239_14).read_zipper()),&[]);
    }
    v238_27_cursor.ascend(1);
  }
  drop(v238_27_cursor);
  drop(v238_27_write);
  (v238_27).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v257_21 = Space::new();
  let mut v257_21_write = v257_21.write_zipper();
  let mut v257_21_cursor = (*s0).read_zipper();
  let v257_21_origin = v257_21_cursor.path().len();
  for v257_21_byte in v257_21_cursor.child_mask().iter() {
    v257_21_cursor.descend_to_existing_byte(v257_21_byte);
    {
    let v258_2: Space = singleton(&v257_21_cursor.path()[v257_21_origin..(v257_21_origin + 1)]);
    let v258_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v258_2));
    let v258_4: Space = if map_kernels::has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
    drop(v258_3);
    let v258_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v258_4));
    drop(v258_4);
    let v258_8: Space = if (&(v258_5)).is_empty() { Space::new() } else {
      let v259_6: Path = concat_path(&(*p0),&v257_21_cursor.path()[v257_21_origin..(v257_21_origin + 1)]);
      let mut v259_7 = Space::new();
      let mut v259_7_write = v259_7.write_zipper();
      for v259_7_byte in v257_21_cursor.child_mask().iter() {
        v257_21_cursor.descend_to_existing_byte(v259_7_byte);
        {
        let v260_2: Space = singleton(&v257_21_cursor.path()[(v257_21_origin + 1)..(v257_21_origin + 2)]);
        let v260_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v260_2));
        let v260_4: Space = if map_kernels::has_head(&(v260_3)) { singleton(&[]) } else { Space::new() };
        drop(v260_3);
        let v260_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v260_4));
        drop(v260_4);
        let v260_8: Space = if (&(v260_5)).is_empty() { Space::new() } else {
          let v261_6: Path = concat_path(&(v259_6),&v257_21_cursor.path()[(v257_21_origin + 1)..(v257_21_origin + 2)]);
          let mut v261_7 = Space::new();
          let mut v261_7_write = v261_7.write_zipper();
          for v261_7_byte in v257_21_cursor.child_mask().iter() {
            v257_21_cursor.descend_to_existing_byte(v261_7_byte);
            {
            let v262_2: Space = singleton(&v257_21_cursor.path()[(v257_21_origin + 2)..(v257_21_origin + 3)]);
            let v262_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v262_2));
            let v262_4: Space = if map_kernels::has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
            drop(v262_3);
            let v262_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v262_4));
            drop(v262_4);
            let v262_8: Space = if (&(v262_5)).is_empty() { Space::new() } else {
              let v263_6: Path = concat_path(&(v261_6),&v257_21_cursor.path()[(v257_21_origin + 2)..(v257_21_origin + 3)]);
              let v263_7: Space = routine_27(c, &(v263_6), &v257_21_cursor, &(*s1));
              map_map_kernels::compose(&(v262_5),&(v263_7))
            };
            drop(v262_5);
            let v262_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v262_2));
            drop(v262_2);
            let v262_10: Space = if map_kernels::has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
            drop(v262_9);
            let v262_12: Space = if (&(v262_10)).is_empty() { Space::new() } else {
              let v264_6: Path = concat_path(&(v261_6),&v257_21_cursor.path()[(v257_21_origin + 2)..(v257_21_origin + 3)]);
              let v264_11: Space = routine_28(c, &(v264_6), &v257_21_cursor, &(*s1));
              drop(v264_6);
              map_map_kernels::compose(&(v262_10),&(v264_11))
            };
            drop(v262_10);
            let v262_13: Space = map_map_kernels::unite(&(v262_8),&(v262_12));
            join_wrapped_into(&mut v261_7_write,&((v262_13).read_zipper()),&[]);
            }
            v257_21_cursor.ascend(1);
          }
          drop(v261_7_write);
          map_map_kernels::compose(&(v260_5),&(v261_7))
        };
        drop(v260_5);
        let v260_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v260_2));
        drop(v260_2);
        let v260_10: Space = if map_kernels::has_head(&(v260_9)) { singleton(&[]) } else { Space::new() };
        drop(v260_9);
        let v260_12: Space = if (&(v260_10)).is_empty() { Space::new() } else {
          let v265_6: Path = concat_path(&(v259_6),&v257_21_cursor.path()[(v257_21_origin + 1)..(v257_21_origin + 2)]);
          let mut v265_11 = Space::new();
          let mut v265_11_write = v265_11.write_zipper();
          for v265_11_byte in v257_21_cursor.child_mask().iter() {
            v257_21_cursor.descend_to_existing_byte(v265_11_byte);
            {
            let v266_2: Space = singleton(&v257_21_cursor.path()[(v257_21_origin + 2)..(v257_21_origin + 3)]);
            let v266_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v266_2));
            let v266_4: Space = if map_kernels::has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
            drop(v266_3);
            let v266_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v266_4));
            drop(v266_4);
            let v266_8: Space = if (&(v266_5)).is_empty() { Space::new() } else {
              let v267_6: Path = concat_path(&(v265_6),&v257_21_cursor.path()[(v257_21_origin + 2)..(v257_21_origin + 3)]);
              let v267_7: Space = routine_27(c, &(v267_6), &v257_21_cursor, &(*s1));
              map_map_kernels::compose(&(v266_5),&(v267_7))
            };
            drop(v266_5);
            let v266_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v266_2));
            drop(v266_2);
            let v266_10: Space = if map_kernels::has_head(&(v266_9)) { singleton(&[]) } else { Space::new() };
            drop(v266_9);
            let v266_12: Space = if (&(v266_10)).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v265_6),&v257_21_cursor.path()[(v257_21_origin + 2)..(v257_21_origin + 3)]);
              let v268_11: Space = routine_24(c, &(v268_6), &v257_21_cursor, &(*s1));
              drop(v268_6);
              map_map_kernels::compose(&(v266_10),&(v268_11))
            };
            drop(v266_10);
            let v266_13: Space = map_map_kernels::unite(&(v266_8),&(v266_12));
            join_wrapped_into(&mut v265_11_write,&((v266_13).read_zipper()),&[]);
            }
            v257_21_cursor.ascend(1);
          }
          drop(v265_11_write);
          drop(v265_6);
          map_map_kernels::compose(&(v260_10),&(v265_11))
        };
        drop(v260_10);
        let v260_13: Space = map_map_kernels::unite(&(v260_8),&(v260_12));
        join_wrapped_into(&mut v259_7_write,&((v260_13).read_zipper()),&[]);
        }
        v257_21_cursor.ascend(1);
      }
      drop(v259_7_write);
      drop(v259_6);
      map_map_kernels::compose(&(v258_5),&(v259_7))
    };
    drop(v258_5);
    let v258_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v258_2));
    drop(v258_2);
    let v258_10: Space = if map_kernels::has_head(&(v258_9)) { singleton(&[]) } else { Space::new() };
    drop(v258_9);
    let v258_13: Space = if (&(v258_10)).is_empty() { Space::new() } else {
      let v269_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v257_21_cursor.path()[v257_21_origin..(v257_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v258_10),&(v269_12))
    };
    drop(v258_10);
    let v258_14: Space = map_map_kernels::unite(&(v258_8),&(v258_13));
    drop(v258_13);
    join_wrapped_into(&mut v257_21_write,&((v258_14).read_zipper()),&[]);
    }
    v257_21_cursor.ascend(1);
  }
  drop(v257_21_cursor);
  drop(v257_21_write);
  (v257_21).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v270_24 = Space::new();
  let mut v270_24_write = v270_24.write_zipper();
  let mut v270_24_cursor = (*s0).read_zipper();
  let v270_24_origin = v270_24_cursor.path().len();
  for v270_24_byte in v270_24_cursor.child_mask().iter() {
    v270_24_cursor.descend_to_existing_byte(v270_24_byte);
    {
    let v271_2: Space = singleton(&v270_24_cursor.path()[v270_24_origin..(v270_24_origin + 1)]);
    let v271_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v271_2));
    let v271_4: Space = if map_kernels::has_head(&(v271_3)) { singleton(&[]) } else { Space::new() };
    drop(v271_3);
    let v271_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v271_4));
    drop(v271_4);
    let v271_8: Space = if (&(v271_5)).is_empty() { Space::new() } else {
      let v272_6: Path = concat_path(&(*p0),&v270_24_cursor.path()[v270_24_origin..(v270_24_origin + 1)]);
      let mut v272_7 = Space::new();
      let mut v272_7_write = v272_7.write_zipper();
      for v272_7_byte in v270_24_cursor.child_mask().iter() {
        v270_24_cursor.descend_to_existing_byte(v272_7_byte);
        {
        let v273_2: Space = singleton(&v270_24_cursor.path()[(v270_24_origin + 1)..(v270_24_origin + 2)]);
        let v273_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v273_2));
        let v273_4: Space = if map_kernels::has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
        drop(v273_3);
        let v273_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v273_4));
        drop(v273_4);
        let v273_8: Space = if (&(v273_5)).is_empty() { Space::new() } else {
          let v274_6: Path = concat_path(&(v272_6),&v270_24_cursor.path()[(v270_24_origin + 1)..(v270_24_origin + 2)]);
          let mut v274_7 = Space::new();
          let mut v274_7_write = v274_7.write_zipper();
          for v274_7_byte in v270_24_cursor.child_mask().iter() {
            v270_24_cursor.descend_to_existing_byte(v274_7_byte);
            {
            let v275_2: Space = singleton(&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
            let v275_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v275_2));
            let v275_4: Space = if map_kernels::has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
            drop(v275_3);
            let v275_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v275_4));
            drop(v275_4);
            let v275_8: Space = if (&(v275_5)).is_empty() { Space::new() } else {
              let v276_6: Path = concat_path(&(v274_6),&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
              let v276_7: Space = routine_29(c, &(v276_6), &v270_24_cursor, &(*s1));
              map_map_kernels::compose(&(v275_5),&(v276_7))
            };
            drop(v275_5);
            let v275_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v275_2));
            drop(v275_2);
            let v275_10: Space = if map_kernels::has_head(&(v275_9)) { singleton(&[]) } else { Space::new() };
            drop(v275_9);
            let v275_12: Space = if (&(v275_10)).is_empty() { Space::new() } else {
              let v277_6: Path = concat_path(&(v274_6),&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
              let v277_11: Space = routine_30(c, &(v277_6), &v270_24_cursor, &(*s1));
              drop(v277_6);
              map_map_kernels::compose(&(v275_10),&(v277_11))
            };
            drop(v275_10);
            let v275_13: Space = map_map_kernels::unite(&(v275_8),&(v275_12));
            join_wrapped_into(&mut v274_7_write,&((v275_13).read_zipper()),&[]);
            }
            v270_24_cursor.ascend(1);
          }
          drop(v274_7_write);
          map_map_kernels::compose(&(v273_5),&(v274_7))
        };
        drop(v273_5);
        let v273_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v273_2));
        drop(v273_2);
        let v273_10: Space = if map_kernels::has_head(&(v273_9)) { singleton(&[]) } else { Space::new() };
        drop(v273_9);
        let v273_12: Space = if (&(v273_10)).is_empty() { Space::new() } else {
          let v278_6: Path = concat_path(&(v272_6),&v270_24_cursor.path()[(v270_24_origin + 1)..(v270_24_origin + 2)]);
          let mut v278_11 = Space::new();
          let mut v278_11_write = v278_11.write_zipper();
          for v278_11_byte in v270_24_cursor.child_mask().iter() {
            v270_24_cursor.descend_to_existing_byte(v278_11_byte);
            {
            let v279_2: Space = singleton(&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
            let v279_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v279_2));
            let v279_4: Space = if map_kernels::has_head(&(v279_3)) { singleton(&[]) } else { Space::new() };
            drop(v279_3);
            let v279_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v279_4));
            drop(v279_4);
            let v279_8: Space = if (&(v279_5)).is_empty() { Space::new() } else {
              let v280_6: Path = concat_path(&(v278_6),&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
              let v280_7: Space = routine_29(c, &(v280_6), &v270_24_cursor, &(*s1));
              map_map_kernels::compose(&(v279_5),&(v280_7))
            };
            drop(v279_5);
            let v279_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v279_2));
            drop(v279_2);
            let v279_10: Space = if map_kernels::has_head(&(v279_9)) { singleton(&[]) } else { Space::new() };
            drop(v279_9);
            let v279_12: Space = if (&(v279_10)).is_empty() { Space::new() } else {
              let v281_6: Path = concat_path(&(v278_6),&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
              let v281_11: Space = routine_9(c, &(v281_6), &v270_24_cursor, &(*s1));
              drop(v281_6);
              map_map_kernels::compose(&(v279_10),&(v281_11))
            };
            drop(v279_10);
            let v279_13: Space = map_map_kernels::unite(&(v279_8),&(v279_12));
            join_wrapped_into(&mut v278_11_write,&((v279_13).read_zipper()),&[]);
            }
            v270_24_cursor.ascend(1);
          }
          drop(v278_11_write);
          drop(v278_6);
          map_map_kernels::compose(&(v273_10),&(v278_11))
        };
        drop(v273_10);
        let v273_13: Space = map_map_kernels::unite(&(v273_8),&(v273_12));
        join_wrapped_into(&mut v272_7_write,&((v273_13).read_zipper()),&[]);
        }
        v270_24_cursor.ascend(1);
      }
      drop(v272_7_write);
      map_map_kernels::compose(&(v271_5),&(v272_7))
    };
    drop(v271_5);
    let v271_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v271_2));
    drop(v271_2);
    let v271_10: Space = if map_kernels::has_head(&(v271_9)) { singleton(&[]) } else { Space::new() };
    drop(v271_9);
    let v271_12: Space = if (&(v271_10)).is_empty() { Space::new() } else {
      let v282_6: Path = concat_path(&(*p0),&v270_24_cursor.path()[v270_24_origin..(v270_24_origin + 1)]);
      let mut v282_11 = Space::new();
      let mut v282_11_write = v282_11.write_zipper();
      for v282_11_byte in v270_24_cursor.child_mask().iter() {
        v270_24_cursor.descend_to_existing_byte(v282_11_byte);
        {
        let v283_2: Space = singleton(&v270_24_cursor.path()[(v270_24_origin + 1)..(v270_24_origin + 2)]);
        let v283_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v283_2));
        let v283_4: Space = if map_kernels::has_head(&(v283_3)) { singleton(&[]) } else { Space::new() };
        drop(v283_3);
        let v283_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v283_4));
        drop(v283_4);
        let v283_8: Space = if (&(v283_5)).is_empty() { Space::new() } else {
          let v284_6: Path = concat_path(&(v282_6),&v270_24_cursor.path()[(v270_24_origin + 1)..(v270_24_origin + 2)]);
          let mut v284_7 = Space::new();
          let mut v284_7_write = v284_7.write_zipper();
          for v284_7_byte in v270_24_cursor.child_mask().iter() {
            v270_24_cursor.descend_to_existing_byte(v284_7_byte);
            {
            let v285_2: Space = singleton(&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
            let v285_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v285_2));
            let v285_4: Space = if map_kernels::has_head(&(v285_3)) { singleton(&[]) } else { Space::new() };
            drop(v285_3);
            let v285_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v285_4));
            drop(v285_4);
            let v285_8: Space = if (&(v285_5)).is_empty() { Space::new() } else {
              let v286_6: Path = concat_path(&(v284_6),&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
              let v286_7: Space = routine_29(c, &(v286_6), &v270_24_cursor, &(*s1));
              map_map_kernels::compose(&(v285_5),&(v286_7))
            };
            drop(v285_5);
            let v285_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v285_2));
            drop(v285_2);
            let v285_10: Space = if map_kernels::has_head(&(v285_9)) { singleton(&[]) } else { Space::new() };
            drop(v285_9);
            let v285_12: Space = if (&(v285_10)).is_empty() { Space::new() } else {
              let v287_6: Path = concat_path(&(v284_6),&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
              let v287_11: Space = routine_30(c, &(v287_6), &v270_24_cursor, &(*s1));
              drop(v287_6);
              map_map_kernels::compose(&(v285_10),&(v287_11))
            };
            drop(v285_10);
            let v285_13: Space = map_map_kernels::unite(&(v285_8),&(v285_12));
            join_wrapped_into(&mut v284_7_write,&((v285_13).read_zipper()),&[]);
            }
            v270_24_cursor.ascend(1);
          }
          drop(v284_7_write);
          map_map_kernels::compose(&(v283_5),&(v284_7))
        };
        drop(v283_5);
        let v283_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v283_2));
        drop(v283_2);
        let v283_10: Space = if map_kernels::has_head(&(v283_9)) { singleton(&[]) } else { Space::new() };
        drop(v283_9);
        let v283_12: Space = if (&(v283_10)).is_empty() { Space::new() } else {
          let mut v288_11 = Space::new();
          let mut v288_11_write = v288_11.write_zipper();
          for v288_11_byte in v270_24_cursor.child_mask().iter() {
            v270_24_cursor.descend_to_existing_byte(v288_11_byte);
            {
            let v289_2: Space = singleton(&v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)]);
            let v289_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v289_2));
            let v289_4: Space = if map_kernels::has_head(&(v289_3)) { singleton(&[]) } else { Space::new() };
            drop(v289_3);
            let v289_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v289_4));
            drop(v289_4);
            let v289_7: Space = if (&(v289_5)).is_empty() { Space::new() } else {
              let v290_6: Space = routine_10(c, &v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)], &v270_24_cursor, &(*s1));
              map_map_kernels::compose(&(v289_5),&(v290_6))
            };
            drop(v289_5);
            let v289_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v289_2));
            drop(v289_2);
            let v289_9: Space = if map_kernels::has_head(&(v289_8)) { singleton(&[]) } else { Space::new() };
            drop(v289_8);
            let v289_11: Space = if (&(v289_9)).is_empty() { Space::new() } else {
              let v291_10: Space = routine_11(c, &v270_24_cursor.path()[(v270_24_origin + 2)..(v270_24_origin + 3)], &v270_24_cursor, &(*s1));
              map_map_kernels::compose(&(v289_9),&(v291_10))
            };
            drop(v289_9);
            let v289_12: Space = map_map_kernels::unite(&(v289_7),&(v289_11));
            join_wrapped_into(&mut v288_11_write,&((v289_12).read_zipper()),&[]);
            }
            v270_24_cursor.ascend(1);
          }
          drop(v288_11_write);
          map_map_kernels::compose(&(v283_10),&(v288_11))
        };
        drop(v283_10);
        let v292_6: Path = concat_path(&(v282_6),&v270_24_cursor.path()[(v270_24_origin + 1)..(v270_24_origin + 2)]);
        let v283_13: Space = map_kernels::wrap(&(v283_12),&(v292_6));
        let v283_14: Space = map_map_kernels::unite(&(v283_8),&(v283_13));
        join_wrapped_into(&mut v282_11_write,&((v283_14).read_zipper()),&[]);
        }
        v270_24_cursor.ascend(1);
      }
      drop(v282_11_write);
      drop(v282_6);
      map_map_kernels::compose(&(v271_10),&(v282_11))
    };
    drop(v271_10);
    let v271_13: Space = map_map_kernels::unite(&(v271_8),&(v271_12));
    join_wrapped_into(&mut v270_24_write,&((v271_13).read_zipper()),&[]);
    }
    v270_24_cursor.ascend(1);
  }
  drop(v270_24_cursor);
  drop(v270_24_write);
  (v270_24).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v293_24 = Space::new();
  let mut v293_24_write = v293_24.write_zipper();
  let mut v293_24_cursor = (*s0).read_zipper();
  let v293_24_origin = v293_24_cursor.path().len();
  for v293_24_byte in v293_24_cursor.child_mask().iter() {
    v293_24_cursor.descend_to_existing_byte(v293_24_byte);
    {
    let v294_2: Space = singleton(&v293_24_cursor.path()[v293_24_origin..(v293_24_origin + 1)]);
    let v294_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v294_2));
    let v294_4: Space = if map_kernels::has_head(&(v294_3)) { singleton(&[]) } else { Space::new() };
    drop(v294_3);
    let v294_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v294_4));
    drop(v294_4);
    let v294_8: Space = if (&(v294_5)).is_empty() { Space::new() } else {
      let v295_6: Path = concat_path(&(*p0),&v293_24_cursor.path()[v293_24_origin..(v293_24_origin + 1)]);
      let mut v295_7 = Space::new();
      let mut v295_7_write = v295_7.write_zipper();
      for v295_7_byte in v293_24_cursor.child_mask().iter() {
        v293_24_cursor.descend_to_existing_byte(v295_7_byte);
        {
        let v296_2: Space = singleton(&v293_24_cursor.path()[(v293_24_origin + 1)..(v293_24_origin + 2)]);
        let v296_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v296_2));
        let v296_4: Space = if map_kernels::has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
        drop(v296_3);
        let v296_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v296_4));
        drop(v296_4);
        let v296_8: Space = if (&(v296_5)).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v295_6),&v293_24_cursor.path()[(v293_24_origin + 1)..(v293_24_origin + 2)]);
          let mut v297_7 = Space::new();
          let mut v297_7_write = v297_7.write_zipper();
          for v297_7_byte in v293_24_cursor.child_mask().iter() {
            v293_24_cursor.descend_to_existing_byte(v297_7_byte);
            {
            let v298_2: Space = singleton(&v293_24_cursor.path()[(v293_24_origin + 2)..(v293_24_origin + 3)]);
            let v298_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v298_2));
            let v298_4: Space = if map_kernels::has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v298_4));
            drop(v298_4);
            let v298_8: Space = if (&(v298_5)).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v297_6),&v293_24_cursor.path()[(v293_24_origin + 2)..(v293_24_origin + 3)]);
              let v299_7: Space = routine_29(c, &(v299_6), &v293_24_cursor, &(*s1));
              map_map_kernels::compose(&(v298_5),&(v299_7))
            };
            drop(v298_5);
            let v298_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v298_2));
            drop(v298_2);
            let v298_10: Space = if map_kernels::has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
            drop(v298_9);
            let v298_12: Space = if (&(v298_10)).is_empty() { Space::new() } else {
              let v300_6: Path = concat_path(&(v297_6),&v293_24_cursor.path()[(v293_24_origin + 2)..(v293_24_origin + 3)]);
              let v300_11: Space = routine_30(c, &(v300_6), &v293_24_cursor, &(*s1));
              drop(v300_6);
              map_map_kernels::compose(&(v298_10),&(v300_11))
            };
            drop(v298_10);
            let v298_13: Space = map_map_kernels::unite(&(v298_8),&(v298_12));
            join_wrapped_into(&mut v297_7_write,&((v298_13).read_zipper()),&[]);
            }
            v293_24_cursor.ascend(1);
          }
          drop(v297_7_write);
          map_map_kernels::compose(&(v296_5),&(v297_7))
        };
        drop(v296_5);
        let v296_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v296_2));
        drop(v296_2);
        let v296_10: Space = if map_kernels::has_head(&(v296_9)) { singleton(&[]) } else { Space::new() };
        drop(v296_9);
        let v296_12: Space = if (&(v296_10)).is_empty() { Space::new() } else {
          let v301_6: Path = concat_path(&(v295_6),&v293_24_cursor.path()[(v293_24_origin + 1)..(v293_24_origin + 2)]);
          let mut v301_11 = Space::new();
          let mut v301_11_write = v301_11.write_zipper();
          for v301_11_byte in v293_24_cursor.child_mask().iter() {
            v293_24_cursor.descend_to_existing_byte(v301_11_byte);
            {
            let v302_2: Space = singleton(&v293_24_cursor.path()[(v293_24_origin + 2)..(v293_24_origin + 3)]);
            let v302_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v302_2));
            let v302_4: Space = if map_kernels::has_head(&(v302_3)) { singleton(&[]) } else { Space::new() };
            drop(v302_3);
            let v302_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v302_4));
            drop(v302_4);
            let v302_8: Space = if (&(v302_5)).is_empty() { Space::new() } else {
              let v303_6: Path = concat_path(&(v301_6),&v293_24_cursor.path()[(v293_24_origin + 2)..(v293_24_origin + 3)]);
              let v303_7: Space = routine_29(c, &(v303_6), &v293_24_cursor, &(*s1));
              map_map_kernels::compose(&(v302_5),&(v303_7))
            };
            drop(v302_5);
            let v302_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v302_2));
            drop(v302_2);
            let v302_10: Space = if map_kernels::has_head(&(v302_9)) { singleton(&[]) } else { Space::new() };
            drop(v302_9);
            let v302_12: Space = if (&(v302_10)).is_empty() { Space::new() } else {
              let v304_6: Path = concat_path(&(v301_6),&v293_24_cursor.path()[(v293_24_origin + 2)..(v293_24_origin + 3)]);
              let v304_11: Space = routine_9(c, &(v304_6), &v293_24_cursor, &(*s1));
              drop(v304_6);
              map_map_kernels::compose(&(v302_10),&(v304_11))
            };
            drop(v302_10);
            let v302_13: Space = map_map_kernels::unite(&(v302_8),&(v302_12));
            join_wrapped_into(&mut v301_11_write,&((v302_13).read_zipper()),&[]);
            }
            v293_24_cursor.ascend(1);
          }
          drop(v301_11_write);
          drop(v301_6);
          map_map_kernels::compose(&(v296_10),&(v301_11))
        };
        drop(v296_10);
        let v296_13: Space = map_map_kernels::unite(&(v296_8),&(v296_12));
        join_wrapped_into(&mut v295_7_write,&((v296_13).read_zipper()),&[]);
        }
        v293_24_cursor.ascend(1);
      }
      drop(v295_7_write);
      map_map_kernels::compose(&(v294_5),&(v295_7))
    };
    drop(v294_5);
    let v294_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v294_2));
    drop(v294_2);
    let v294_10: Space = if map_kernels::has_head(&(v294_9)) { singleton(&[]) } else { Space::new() };
    drop(v294_9);
    let v294_12: Space = if (&(v294_10)).is_empty() { Space::new() } else {
      let mut v305_11 = Space::new();
      let mut v305_11_write = v305_11.write_zipper();
      for v305_11_byte in v293_24_cursor.child_mask().iter() {
        v293_24_cursor.descend_to_existing_byte(v305_11_byte);
        {
        let v306_2: Space = singleton(&v293_24_cursor.path()[(v293_24_origin + 1)..(v293_24_origin + 2)]);
        let v306_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v306_2));
        let v306_4: Space = if map_kernels::has_head(&(v306_3)) { singleton(&[]) } else { Space::new() };
        drop(v306_3);
        let v306_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v306_4));
        drop(v306_4);
        let v306_7: Space = if (&(v306_5)).is_empty() { Space::new() } else {
          let mut v307_6 = Space::new();
          let mut v307_6_write = v307_6.write_zipper();
          for v307_6_byte in v293_24_cursor.child_mask().iter() {
            v293_24_cursor.descend_to_existing_byte(v307_6_byte);
            {
            let v308_2: Space = singleton(&v293_24_cursor.path()[(v293_24_origin + 2)..(v293_24_origin + 3)]);
            let v308_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v308_2));
            let v308_4: Space = if map_kernels::has_head(&(v308_3)) { singleton(&[]) } else { Space::new() };
            drop(v308_3);
            let v308_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v308_4));
            drop(v308_4);
            let v308_8: Space = if (&(v308_5)).is_empty() { Space::new() } else {
              let v309_7: Space = routine_31(c, &v293_24_cursor.path()[(v293_24_origin + 1)..(v293_24_origin + 3)], &v293_24_cursor, &(*s1));
              map_map_kernels::compose(&(v308_5),&(v309_7))
            };
            drop(v308_5);
            let v308_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v308_2));
            drop(v308_2);
            let v308_10: Space = if map_kernels::has_head(&(v308_9)) { singleton(&[]) } else { Space::new() };
            drop(v308_9);
            let v308_12: Space = if (&(v308_10)).is_empty() { Space::new() } else {
              let v310_11: Space = routine_32(c, &v293_24_cursor.path()[(v293_24_origin + 1)..(v293_24_origin + 3)], &v293_24_cursor, &(*s1));
              map_map_kernels::compose(&(v308_10),&(v310_11))
            };
            drop(v308_10);
            let v308_13: Space = map_map_kernels::unite(&(v308_8),&(v308_12));
            join_wrapped_into(&mut v307_6_write,&((v308_13).read_zipper()),&[]);
            }
            v293_24_cursor.ascend(1);
          }
          drop(v307_6_write);
          map_map_kernels::compose(&(v306_5),&(v307_6))
        };
        drop(v306_5);
        let v306_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v306_2));
        drop(v306_2);
        let v306_9: Space = if map_kernels::has_head(&(v306_8)) { singleton(&[]) } else { Space::new() };
        drop(v306_8);
        let v306_11: Space = if (&(v306_9)).is_empty() { Space::new() } else {
          let mut v311_10 = Space::new();
          let mut v311_10_write = v311_10.write_zipper();
          for v311_10_byte in v293_24_cursor.child_mask().iter() {
            v293_24_cursor.descend_to_existing_byte(v311_10_byte);
            {
            let v312_2: Space = singleton(&v293_24_cursor.path()[(v293_24_origin + 2)..(v293_24_origin + 3)]);
            let v312_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v312_2));
            let v312_4: Space = if map_kernels::has_head(&(v312_3)) { singleton(&[]) } else { Space::new() };
            drop(v312_3);
            let v312_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v312_4));
            drop(v312_4);
            let v312_8: Space = if (&(v312_5)).is_empty() { Space::new() } else {
              let v313_7: Space = routine_31(c, &v293_24_cursor.path()[(v293_24_origin + 1)..(v293_24_origin + 3)], &v293_24_cursor, &(*s1));
              map_map_kernels::compose(&(v312_5),&(v313_7))
            };
            drop(v312_5);
            let v312_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v312_2));
            drop(v312_2);
            let v312_10: Space = if map_kernels::has_head(&(v312_9)) { singleton(&[]) } else { Space::new() };
            drop(v312_9);
            let v312_12: Space = if (&(v312_10)).is_empty() { Space::new() } else {
              let v314_11: Space = routine_33(c, &v293_24_cursor.path()[(v293_24_origin + 1)..(v293_24_origin + 3)], &v293_24_cursor, &(*s1));
              map_map_kernels::compose(&(v312_10),&(v314_11))
            };
            drop(v312_10);
            let v312_13: Space = map_map_kernels::unite(&(v312_8),&(v312_12));
            join_wrapped_into(&mut v311_10_write,&((v312_13).read_zipper()),&[]);
            }
            v293_24_cursor.ascend(1);
          }
          drop(v311_10_write);
          map_map_kernels::compose(&(v306_9),&(v311_10))
        };
        drop(v306_9);
        let v306_12: Space = map_map_kernels::unite(&(v306_7),&(v306_11));
        join_wrapped_into(&mut v305_11_write,&((v306_12).read_zipper()),&[]);
        }
        v293_24_cursor.ascend(1);
      }
      drop(v305_11_write);
      map_map_kernels::compose(&(v294_10),&(v305_11))
    };
    drop(v294_10);
    let v315_6: Path = concat_path(&(*p0),&v293_24_cursor.path()[v293_24_origin..(v293_24_origin + 1)]);
    let v294_13: Space = map_kernels::wrap(&(v294_12),&(v315_6));
    let v294_14: Space = map_map_kernels::unite(&(v294_8),&(v294_13));
    join_wrapped_into(&mut v293_24_write,&((v294_14).read_zipper()),&[]);
    }
    v293_24_cursor.ascend(1);
  }
  drop(v293_24_cursor);
  drop(v293_24_write);
  (v293_24).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v316_26 = Space::new();
  let mut v316_26_write = v316_26.write_zipper();
  let mut v316_26_cursor = (*s0).read_zipper();
  let v316_26_origin = v316_26_cursor.path().len();
  for v316_26_byte in v316_26_cursor.child_mask().iter() {
    v316_26_cursor.descend_to_existing_byte(v316_26_byte);
    {
    let v317_2: Space = singleton(&v316_26_cursor.path()[v316_26_origin..(v316_26_origin + 1)]);
    let v317_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v317_2));
    let v317_4: Space = if map_kernels::has_head(&(v317_3)) { singleton(&[]) } else { Space::new() };
    drop(v317_3);
    let v317_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v317_4));
    drop(v317_4);
    let v317_7: Space = if (&(v317_5)).is_empty() { Space::new() } else {
      let mut v318_6 = Space::new();
      let mut v318_6_write = v318_6.write_zipper();
      for v318_6_byte in v316_26_cursor.child_mask().iter() {
        v316_26_cursor.descend_to_existing_byte(v318_6_byte);
        {
        let v319_2: Space = singleton(&v316_26_cursor.path()[(v316_26_origin + 1)..(v316_26_origin + 2)]);
        let v319_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v319_2));
        let v319_4: Space = if map_kernels::has_head(&(v319_3)) { singleton(&[]) } else { Space::new() };
        drop(v319_3);
        let v319_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v319_4));
        drop(v319_4);
        let v319_8: Space = if (&(v319_5)).is_empty() { Space::new() } else {
          let mut v320_7 = Space::new();
          let mut v320_7_write = v320_7.write_zipper();
          for v320_7_byte in v316_26_cursor.child_mask().iter() {
            v316_26_cursor.descend_to_existing_byte(v320_7_byte);
            {
            let v321_2: Space = singleton(&v316_26_cursor.path()[(v316_26_origin + 2)..(v316_26_origin + 3)]);
            let v321_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v321_2));
            let v321_4: Space = if map_kernels::has_head(&(v321_3)) { singleton(&[]) } else { Space::new() };
            drop(v321_3);
            let v321_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v321_4));
            drop(v321_4);
            let v321_8: Space = if (&(v321_5)).is_empty() { Space::new() } else {
              let v322_7: Space = routine_34(c, &v316_26_cursor.path()[v316_26_origin..(v316_26_origin + 3)], &v316_26_cursor, &(*s1));
              map_map_kernels::compose(&(v321_5),&(v322_7))
            };
            drop(v321_5);
            let v321_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v321_2));
            drop(v321_2);
            let v321_10: Space = if map_kernels::has_head(&(v321_9)) { singleton(&[]) } else { Space::new() };
            drop(v321_9);
            let v321_12: Space = if (&(v321_10)).is_empty() { Space::new() } else {
              let v323_11: Space = routine_35(c, &v316_26_cursor.path()[v316_26_origin..(v316_26_origin + 3)], &v316_26_cursor, &(*s1));
              map_map_kernels::compose(&(v321_10),&(v323_11))
            };
            drop(v321_10);
            let v321_13: Space = map_map_kernels::unite(&(v321_8),&(v321_12));
            join_wrapped_into(&mut v320_7_write,&((v321_13).read_zipper()),&[]);
            }
            v316_26_cursor.ascend(1);
          }
          drop(v320_7_write);
          map_map_kernels::compose(&(v319_5),&(v320_7))
        };
        drop(v319_5);
        let v319_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v319_2));
        drop(v319_2);
        let v319_10: Space = if map_kernels::has_head(&(v319_9)) { singleton(&[]) } else { Space::new() };
        drop(v319_9);
        let v319_12: Space = if (&(v319_10)).is_empty() { Space::new() } else {
          let mut v324_11 = Space::new();
          let mut v324_11_write = v324_11.write_zipper();
          for v324_11_byte in v316_26_cursor.child_mask().iter() {
            v316_26_cursor.descend_to_existing_byte(v324_11_byte);
            {
            let v325_2: Space = singleton(&v316_26_cursor.path()[(v316_26_origin + 2)..(v316_26_origin + 3)]);
            let v325_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v325_2));
            let v325_4: Space = if map_kernels::has_head(&(v325_3)) { singleton(&[]) } else { Space::new() };
            drop(v325_3);
            let v325_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v325_4));
            drop(v325_4);
            let v325_8: Space = if (&(v325_5)).is_empty() { Space::new() } else {
              let v326_7: Space = routine_34(c, &v316_26_cursor.path()[v316_26_origin..(v316_26_origin + 3)], &v316_26_cursor, &(*s1));
              map_map_kernels::compose(&(v325_5),&(v326_7))
            };
            drop(v325_5);
            let v325_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v325_2));
            drop(v325_2);
            let v325_10: Space = if map_kernels::has_head(&(v325_9)) { singleton(&[]) } else { Space::new() };
            drop(v325_9);
            let v325_12: Space = if (&(v325_10)).is_empty() { Space::new() } else {
              let v327_11: Space = routine_33(c, &v316_26_cursor.path()[v316_26_origin..(v316_26_origin + 3)], &v316_26_cursor, &(*s1));
              map_map_kernels::compose(&(v325_10),&(v327_11))
            };
            drop(v325_10);
            let v325_13: Space = map_map_kernels::unite(&(v325_8),&(v325_12));
            join_wrapped_into(&mut v324_11_write,&((v325_13).read_zipper()),&[]);
            }
            v316_26_cursor.ascend(1);
          }
          drop(v324_11_write);
          map_map_kernels::compose(&(v319_10),&(v324_11))
        };
        drop(v319_10);
        let v319_13: Space = map_map_kernels::unite(&(v319_8),&(v319_12));
        join_wrapped_into(&mut v318_6_write,&((v319_13).read_zipper()),&[]);
        }
        v316_26_cursor.ascend(1);
      }
      drop(v318_6_write);
      map_map_kernels::compose(&(v317_5),&(v318_6))
    };
    drop(v317_5);
    let v317_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v317_2));
    drop(v317_2);
    let v317_9: Space = if map_kernels::has_head(&(v317_8)) { singleton(&[]) } else { Space::new() };
    drop(v317_8);
    let v317_12: Space = if (&(v317_9)).is_empty() { Space::new() } else {
      let mut v328_11 = Space::new();
      let mut v328_11_write = v328_11.write_zipper();
      for v328_11_byte in v316_26_cursor.child_mask().iter() {
        v316_26_cursor.descend_to_existing_byte(v328_11_byte);
        {
        let v329_2: Space = singleton(&v316_26_cursor.path()[(v316_26_origin + 1)..(v316_26_origin + 2)]);
        let v329_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v329_2));
        let v329_4: Space = if map_kernels::has_head(&(v329_3)) { singleton(&[]) } else { Space::new() };
        drop(v329_3);
        let v329_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v329_4));
        drop(v329_4);
        let v329_8: Space = if (&(v329_5)).is_empty() { Space::new() } else {
          let mut v330_7 = Space::new();
          let mut v330_7_write = v330_7.write_zipper();
          for v330_7_byte in v316_26_cursor.child_mask().iter() {
            v316_26_cursor.descend_to_existing_byte(v330_7_byte);
            {
            let v331_2: Space = singleton(&v316_26_cursor.path()[(v316_26_origin + 2)..(v316_26_origin + 3)]);
            let v331_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v331_2));
            let v331_4: Space = if map_kernels::has_head(&(v331_3)) { singleton(&[]) } else { Space::new() };
            drop(v331_3);
            let v331_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v331_4));
            drop(v331_4);
            let v331_8: Space = if (&(v331_5)).is_empty() { Space::new() } else {
              let v332_7: Space = routine_34(c, &v316_26_cursor.path()[v316_26_origin..(v316_26_origin + 3)], &v316_26_cursor, &(*s1));
              map_map_kernels::compose(&(v331_5),&(v332_7))
            };
            drop(v331_5);
            let v331_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v331_2));
            drop(v331_2);
            let v331_10: Space = if map_kernels::has_head(&(v331_9)) { singleton(&[]) } else { Space::new() };
            drop(v331_9);
            let v331_12: Space = if (&(v331_10)).is_empty() { Space::new() } else {
              let v333_11: Space = routine_35(c, &v316_26_cursor.path()[v316_26_origin..(v316_26_origin + 3)], &v316_26_cursor, &(*s1));
              map_map_kernels::compose(&(v331_10),&(v333_11))
            };
            drop(v331_10);
            let v331_13: Space = map_map_kernels::unite(&(v331_8),&(v331_12));
            join_wrapped_into(&mut v330_7_write,&((v331_13).read_zipper()),&[]);
            }
            v316_26_cursor.ascend(1);
          }
          drop(v330_7_write);
          map_map_kernels::compose(&(v329_5),&(v330_7))
        };
        drop(v329_5);
        let v329_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v329_2));
        drop(v329_2);
        let v329_10: Space = if map_kernels::has_head(&(v329_9)) { singleton(&[]) } else { Space::new() };
        drop(v329_9);
        let v329_13: Space = if (&(v329_10)).is_empty() { Space::new() } else {
          let v334_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&v316_26_cursor.path()[v316_26_origin..(v316_26_origin + 1)]),&v316_26_cursor.path()[(v316_26_origin + 1)..(v316_26_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v329_10),&(v334_12))
        };
        drop(v329_10);
        let v329_14: Space = map_map_kernels::unite(&(v329_8),&(v329_13));
        drop(v329_13);
        join_wrapped_into(&mut v328_11_write,&((v329_14).read_zipper()),&[]);
        }
        v316_26_cursor.ascend(1);
      }
      drop(v328_11_write);
      map_map_kernels::compose(&(v317_9),&(v328_11))
    };
    drop(v317_9);
    let v317_13: Space = map_map_kernels::unite(&(v317_7),&(v317_12));
    join_wrapped_into(&mut v316_26_write,&((v317_13).read_zipper()),&[]);
    }
    v316_26_cursor.ascend(1);
  }
  drop(v316_26_cursor);
  drop(v316_26_write);
  let v316_27: Space = map_kernels::wrap(&(v316_26),&(*p0));
  (v316_27).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v335_27 = Space::new();
  let mut v335_27_write = v335_27.write_zipper();
  let mut v335_27_cursor = (*s0).read_zipper();
  let v335_27_origin = v335_27_cursor.path().len();
  for v335_27_byte in v335_27_cursor.child_mask().iter() {
    v335_27_cursor.descend_to_existing_byte(v335_27_byte);
    {
    let v336_2: Space = singleton(&v335_27_cursor.path()[v335_27_origin..(v335_27_origin + 1)]);
    let v336_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v336_2));
    let v336_4: Space = if map_kernels::has_head(&(v336_3)) { singleton(&[]) } else { Space::new() };
    drop(v336_3);
    let v336_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v336_4));
    drop(v336_4);
    let v336_8: Space = if (&(v336_5)).is_empty() { Space::new() } else {
      let v337_6: Path = concat_path(&(*p0),&v335_27_cursor.path()[v335_27_origin..(v335_27_origin + 1)]);
      let mut v337_7 = Space::new();
      let mut v337_7_write = v337_7.write_zipper();
      for v337_7_byte in v335_27_cursor.child_mask().iter() {
        v335_27_cursor.descend_to_existing_byte(v337_7_byte);
        {
        let v338_2: Space = singleton(&v335_27_cursor.path()[(v335_27_origin + 1)..(v335_27_origin + 2)]);
        let v338_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v338_2));
        let v338_4: Space = if map_kernels::has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
        drop(v338_3);
        let v338_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v338_4));
        drop(v338_4);
        let v338_8: Space = if (&(v338_5)).is_empty() { Space::new() } else {
          let v339_6: Path = concat_path(&(v337_6),&v335_27_cursor.path()[(v335_27_origin + 1)..(v335_27_origin + 2)]);
          let mut v339_7 = Space::new();
          let mut v339_7_write = v339_7.write_zipper();
          for v339_7_byte in v335_27_cursor.child_mask().iter() {
            v335_27_cursor.descend_to_existing_byte(v339_7_byte);
            {
            let v340_2: Space = singleton(&v335_27_cursor.path()[(v335_27_origin + 2)..(v335_27_origin + 3)]);
            let v340_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v340_2));
            let v340_4: Space = if map_kernels::has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
            drop(v340_3);
            let v340_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v340_4));
            drop(v340_4);
            let v340_8: Space = if (&(v340_5)).is_empty() { Space::new() } else {
              let v341_6: Path = concat_path(&(v339_6),&v335_27_cursor.path()[(v335_27_origin + 2)..(v335_27_origin + 3)]);
              let v341_7: Space = routine_36(c, &(v341_6), &v335_27_cursor, &(*s1));
              map_map_kernels::compose(&(v340_5),&(v341_7))
            };
            drop(v340_5);
            let v340_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v340_2));
            drop(v340_2);
            let v340_10: Space = if map_kernels::has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
            drop(v340_9);
            let v340_12: Space = if (&(v340_10)).is_empty() { Space::new() } else {
              let v342_6: Path = concat_path(&(v339_6),&v335_27_cursor.path()[(v335_27_origin + 2)..(v335_27_origin + 3)]);
              let v342_11: Space = routine_37(c, &(v342_6), &v335_27_cursor, &(*s1));
              drop(v342_6);
              map_map_kernels::compose(&(v340_10),&(v342_11))
            };
            drop(v340_10);
            let v340_13: Space = map_map_kernels::unite(&(v340_8),&(v340_12));
            join_wrapped_into(&mut v339_7_write,&((v340_13).read_zipper()),&[]);
            }
            v335_27_cursor.ascend(1);
          }
          drop(v339_7_write);
          map_map_kernels::compose(&(v338_5),&(v339_7))
        };
        drop(v338_5);
        let v338_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v338_2));
        drop(v338_2);
        let v338_10: Space = if map_kernels::has_head(&(v338_9)) { singleton(&[]) } else { Space::new() };
        drop(v338_9);
        let v338_12: Space = if (&(v338_10)).is_empty() { Space::new() } else {
          let v343_6: Path = concat_path(&(v337_6),&v335_27_cursor.path()[(v335_27_origin + 1)..(v335_27_origin + 2)]);
          let mut v343_11 = Space::new();
          let mut v343_11_write = v343_11.write_zipper();
          for v343_11_byte in v335_27_cursor.child_mask().iter() {
            v335_27_cursor.descend_to_existing_byte(v343_11_byte);
            {
            let v344_2: Space = singleton(&v335_27_cursor.path()[(v335_27_origin + 2)..(v335_27_origin + 3)]);
            let v344_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v344_2));
            let v344_4: Space = if map_kernels::has_head(&(v344_3)) { singleton(&[]) } else { Space::new() };
            drop(v344_3);
            let v344_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v344_4));
            drop(v344_4);
            let v344_8: Space = if (&(v344_5)).is_empty() { Space::new() } else {
              let v345_6: Path = concat_path(&(v343_6),&v335_27_cursor.path()[(v335_27_origin + 2)..(v335_27_origin + 3)]);
              let v345_7: Space = routine_36(c, &(v345_6), &v335_27_cursor, &(*s1));
              map_map_kernels::compose(&(v344_5),&(v345_7))
            };
            drop(v344_5);
            let v344_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v344_2));
            drop(v344_2);
            let v344_10: Space = if map_kernels::has_head(&(v344_9)) { singleton(&[]) } else { Space::new() };
            drop(v344_9);
            let v344_12: Space = if (&(v344_10)).is_empty() { Space::new() } else {
              let v346_6: Path = concat_path(&(v343_6),&v335_27_cursor.path()[(v335_27_origin + 2)..(v335_27_origin + 3)]);
              let v346_11: Space = routine_33(c, &(v346_6), &v335_27_cursor, &(*s1));
              drop(v346_6);
              map_map_kernels::compose(&(v344_10),&(v346_11))
            };
            drop(v344_10);
            let v344_13: Space = map_map_kernels::unite(&(v344_8),&(v344_12));
            join_wrapped_into(&mut v343_11_write,&((v344_13).read_zipper()),&[]);
            }
            v335_27_cursor.ascend(1);
          }
          drop(v343_11_write);
          drop(v343_6);
          map_map_kernels::compose(&(v338_10),&(v343_11))
        };
        drop(v338_10);
        let v338_13: Space = map_map_kernels::unite(&(v338_8),&(v338_12));
        join_wrapped_into(&mut v337_7_write,&((v338_13).read_zipper()),&[]);
        }
        v335_27_cursor.ascend(1);
      }
      drop(v337_7_write);
      map_map_kernels::compose(&(v336_5),&(v337_7))
    };
    drop(v336_5);
    let v336_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v336_2));
    drop(v336_2);
    let v336_10: Space = if map_kernels::has_head(&(v336_9)) { singleton(&[]) } else { Space::new() };
    drop(v336_9);
    let v336_13: Space = if (&(v336_10)).is_empty() { Space::new() } else {
      let v347_6: Path = concat_path(&(*p0),&v335_27_cursor.path()[v335_27_origin..(v335_27_origin + 1)]);
      let mut v347_12 = Space::new();
      let mut v347_12_write = v347_12.write_zipper();
      for v347_12_byte in v335_27_cursor.child_mask().iter() {
        v335_27_cursor.descend_to_existing_byte(v347_12_byte);
        {
        let v348_2: Space = singleton(&v335_27_cursor.path()[(v335_27_origin + 1)..(v335_27_origin + 2)]);
        let v348_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v348_2));
        let v348_4: Space = if map_kernels::has_head(&(v348_3)) { singleton(&[]) } else { Space::new() };
        drop(v348_3);
        let v348_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v348_4));
        drop(v348_4);
        let v348_8: Space = if (&(v348_5)).is_empty() { Space::new() } else {
          let v349_6: Path = concat_path(&(v347_6),&v335_27_cursor.path()[(v335_27_origin + 1)..(v335_27_origin + 2)]);
          let mut v349_7 = Space::new();
          let mut v349_7_write = v349_7.write_zipper();
          for v349_7_byte in v335_27_cursor.child_mask().iter() {
            v335_27_cursor.descend_to_existing_byte(v349_7_byte);
            {
            let v350_2: Space = singleton(&v335_27_cursor.path()[(v335_27_origin + 2)..(v335_27_origin + 3)]);
            let v350_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v350_2));
            let v350_4: Space = if map_kernels::has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
            drop(v350_3);
            let v350_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v350_4));
            drop(v350_4);
            let v350_8: Space = if (&(v350_5)).is_empty() { Space::new() } else {
              let v351_6: Path = concat_path(&(v349_6),&v335_27_cursor.path()[(v335_27_origin + 2)..(v335_27_origin + 3)]);
              let v351_7: Space = routine_36(c, &(v351_6), &v335_27_cursor, &(*s1));
              map_map_kernels::compose(&(v350_5),&(v351_7))
            };
            drop(v350_5);
            let v350_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v350_2));
            drop(v350_2);
            let v350_10: Space = if map_kernels::has_head(&(v350_9)) { singleton(&[]) } else { Space::new() };
            drop(v350_9);
            let v350_12: Space = if (&(v350_10)).is_empty() { Space::new() } else {
              let v352_6: Path = concat_path(&(v349_6),&v335_27_cursor.path()[(v335_27_origin + 2)..(v335_27_origin + 3)]);
              let v352_11: Space = routine_37(c, &(v352_6), &v335_27_cursor, &(*s1));
              drop(v352_6);
              map_map_kernels::compose(&(v350_10),&(v352_11))
            };
            drop(v350_10);
            let v350_13: Space = map_map_kernels::unite(&(v350_8),&(v350_12));
            join_wrapped_into(&mut v349_7_write,&((v350_13).read_zipper()),&[]);
            }
            v335_27_cursor.ascend(1);
          }
          drop(v349_7_write);
          drop(v349_6);
          map_map_kernels::compose(&(v348_5),&(v349_7))
        };
        drop(v348_5);
        let v348_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v348_2));
        drop(v348_2);
        let v348_10: Space = if map_kernels::has_head(&(v348_9)) { singleton(&[]) } else { Space::new() };
        drop(v348_9);
        let v348_13: Space = if (&(v348_10)).is_empty() { Space::new() } else {
          let v353_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v335_27_cursor.path()[v335_27_origin..(v335_27_origin + 1)]),&v335_27_cursor.path()[(v335_27_origin + 1)..(v335_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v348_10),&(v353_12))
        };
        drop(v348_10);
        let v348_14: Space = map_map_kernels::unite(&(v348_8),&(v348_13));
        drop(v348_13);
        join_wrapped_into(&mut v347_12_write,&((v348_14).read_zipper()),&[]);
        }
        v335_27_cursor.ascend(1);
      }
      drop(v347_12_write);
      drop(v347_6);
      map_map_kernels::compose(&(v336_10),&(v347_12))
    };
    drop(v336_10);
    let v336_14: Space = map_map_kernels::unite(&(v336_8),&(v336_13));
    join_wrapped_into(&mut v335_27_write,&((v336_14).read_zipper()),&[]);
    }
    v335_27_cursor.ascend(1);
  }
  drop(v335_27_cursor);
  drop(v335_27_write);
  (v335_27).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v354_21 = Space::new();
  let mut v354_21_write = v354_21.write_zipper();
  let mut v354_21_cursor = (*s0).read_zipper();
  let v354_21_origin = v354_21_cursor.path().len();
  for v354_21_byte in v354_21_cursor.child_mask().iter() {
    v354_21_cursor.descend_to_existing_byte(v354_21_byte);
    {
    let v355_2: Space = singleton(&v354_21_cursor.path()[v354_21_origin..(v354_21_origin + 1)]);
    let v355_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v355_2));
    let v355_4: Space = if map_kernels::has_head(&(v355_3)) { singleton(&[]) } else { Space::new() };
    drop(v355_3);
    let v355_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v355_4));
    drop(v355_4);
    let v355_8: Space = if (&(v355_5)).is_empty() { Space::new() } else {
      let v356_6: Path = concat_path(&(*p0),&v354_21_cursor.path()[v354_21_origin..(v354_21_origin + 1)]);
      let mut v356_7 = Space::new();
      let mut v356_7_write = v356_7.write_zipper();
      for v356_7_byte in v354_21_cursor.child_mask().iter() {
        v354_21_cursor.descend_to_existing_byte(v356_7_byte);
        {
        let v357_2: Space = singleton(&v354_21_cursor.path()[(v354_21_origin + 1)..(v354_21_origin + 2)]);
        let v357_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v357_2));
        let v357_4: Space = if map_kernels::has_head(&(v357_3)) { singleton(&[]) } else { Space::new() };
        drop(v357_3);
        let v357_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v357_4));
        drop(v357_4);
        let v357_8: Space = if (&(v357_5)).is_empty() { Space::new() } else {
          let v358_6: Path = concat_path(&(v356_6),&v354_21_cursor.path()[(v354_21_origin + 1)..(v354_21_origin + 2)]);
          let mut v358_7 = Space::new();
          let mut v358_7_write = v358_7.write_zipper();
          for v358_7_byte in v354_21_cursor.child_mask().iter() {
            v354_21_cursor.descend_to_existing_byte(v358_7_byte);
            {
            let v359_2: Space = singleton(&v354_21_cursor.path()[(v354_21_origin + 2)..(v354_21_origin + 3)]);
            let v359_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v359_2));
            let v359_4: Space = if map_kernels::has_head(&(v359_3)) { singleton(&[]) } else { Space::new() };
            drop(v359_3);
            let v359_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v359_4));
            drop(v359_4);
            let v359_8: Space = if (&(v359_5)).is_empty() { Space::new() } else {
              let v360_6: Path = concat_path(&(v358_6),&v354_21_cursor.path()[(v354_21_origin + 2)..(v354_21_origin + 3)]);
              let v360_7: Space = routine_36(c, &(v360_6), &v354_21_cursor, &(*s1));
              map_map_kernels::compose(&(v359_5),&(v360_7))
            };
            drop(v359_5);
            let v359_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v359_2));
            drop(v359_2);
            let v359_10: Space = if map_kernels::has_head(&(v359_9)) { singleton(&[]) } else { Space::new() };
            drop(v359_9);
            let v359_12: Space = if (&(v359_10)).is_empty() { Space::new() } else {
              let v361_6: Path = concat_path(&(v358_6),&v354_21_cursor.path()[(v354_21_origin + 2)..(v354_21_origin + 3)]);
              let v361_11: Space = routine_37(c, &(v361_6), &v354_21_cursor, &(*s1));
              drop(v361_6);
              map_map_kernels::compose(&(v359_10),&(v361_11))
            };
            drop(v359_10);
            let v359_13: Space = map_map_kernels::unite(&(v359_8),&(v359_12));
            join_wrapped_into(&mut v358_7_write,&((v359_13).read_zipper()),&[]);
            }
            v354_21_cursor.ascend(1);
          }
          drop(v358_7_write);
          map_map_kernels::compose(&(v357_5),&(v358_7))
        };
        drop(v357_5);
        let v357_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v357_2));
        drop(v357_2);
        let v357_10: Space = if map_kernels::has_head(&(v357_9)) { singleton(&[]) } else { Space::new() };
        drop(v357_9);
        let v357_12: Space = if (&(v357_10)).is_empty() { Space::new() } else {
          let v362_6: Path = concat_path(&(v356_6),&v354_21_cursor.path()[(v354_21_origin + 1)..(v354_21_origin + 2)]);
          let mut v362_11 = Space::new();
          let mut v362_11_write = v362_11.write_zipper();
          for v362_11_byte in v354_21_cursor.child_mask().iter() {
            v354_21_cursor.descend_to_existing_byte(v362_11_byte);
            {
            let v363_2: Space = singleton(&v354_21_cursor.path()[(v354_21_origin + 2)..(v354_21_origin + 3)]);
            let v363_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v363_2));
            let v363_4: Space = if map_kernels::has_head(&(v363_3)) { singleton(&[]) } else { Space::new() };
            drop(v363_3);
            let v363_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v363_4));
            drop(v363_4);
            let v363_8: Space = if (&(v363_5)).is_empty() { Space::new() } else {
              let v364_6: Path = concat_path(&(v362_6),&v354_21_cursor.path()[(v354_21_origin + 2)..(v354_21_origin + 3)]);
              let v364_7: Space = routine_36(c, &(v364_6), &v354_21_cursor, &(*s1));
              map_map_kernels::compose(&(v363_5),&(v364_7))
            };
            drop(v363_5);
            let v363_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v363_2));
            drop(v363_2);
            let v363_10: Space = if map_kernels::has_head(&(v363_9)) { singleton(&[]) } else { Space::new() };
            drop(v363_9);
            let v363_12: Space = if (&(v363_10)).is_empty() { Space::new() } else {
              let v365_6: Path = concat_path(&(v362_6),&v354_21_cursor.path()[(v354_21_origin + 2)..(v354_21_origin + 3)]);
              let v365_11: Space = routine_33(c, &(v365_6), &v354_21_cursor, &(*s1));
              drop(v365_6);
              map_map_kernels::compose(&(v363_10),&(v365_11))
            };
            drop(v363_10);
            let v363_13: Space = map_map_kernels::unite(&(v363_8),&(v363_12));
            join_wrapped_into(&mut v362_11_write,&((v363_13).read_zipper()),&[]);
            }
            v354_21_cursor.ascend(1);
          }
          drop(v362_11_write);
          drop(v362_6);
          map_map_kernels::compose(&(v357_10),&(v362_11))
        };
        drop(v357_10);
        let v357_13: Space = map_map_kernels::unite(&(v357_8),&(v357_12));
        join_wrapped_into(&mut v356_7_write,&((v357_13).read_zipper()),&[]);
        }
        v354_21_cursor.ascend(1);
      }
      drop(v356_7_write);
      drop(v356_6);
      map_map_kernels::compose(&(v355_5),&(v356_7))
    };
    drop(v355_5);
    let v355_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v355_2));
    drop(v355_2);
    let v355_10: Space = if map_kernels::has_head(&(v355_9)) { singleton(&[]) } else { Space::new() };
    drop(v355_9);
    let v355_13: Space = if (&(v355_10)).is_empty() { Space::new() } else {
      let v366_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v354_21_cursor.path()[v354_21_origin..(v354_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v355_10),&(v366_12))
    };
    drop(v355_10);
    let v355_14: Space = map_map_kernels::unite(&(v355_8),&(v355_13));
    drop(v355_13);
    join_wrapped_into(&mut v354_21_write,&((v355_14).read_zipper()),&[]);
    }
    v354_21_cursor.ascend(1);
  }
  drop(v354_21_cursor);
  drop(v354_21_write);
  (v354_21).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v367_21 = Space::new();
  let mut v367_21_write = v367_21.write_zipper();
  let mut v367_21_cursor = (*s0).read_zipper();
  let v367_21_origin = v367_21_cursor.path().len();
  for v367_21_byte in v367_21_cursor.child_mask().iter() {
    v367_21_cursor.descend_to_existing_byte(v367_21_byte);
    {
    let v368_2: Space = singleton(&v367_21_cursor.path()[v367_21_origin..(v367_21_origin + 1)]);
    let v368_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v368_2));
    let v368_4: Space = if map_kernels::has_head(&(v368_3)) { singleton(&[]) } else { Space::new() };
    drop(v368_3);
    let v368_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v368_4));
    drop(v368_4);
    let v368_8: Space = if (&(v368_5)).is_empty() { Space::new() } else {
      let v369_6: Path = concat_path(&(*p0),&v367_21_cursor.path()[v367_21_origin..(v367_21_origin + 1)]);
      let mut v369_7 = Space::new();
      let mut v369_7_write = v369_7.write_zipper();
      for v369_7_byte in v367_21_cursor.child_mask().iter() {
        v367_21_cursor.descend_to_existing_byte(v369_7_byte);
        {
        let v370_2: Space = singleton(&v367_21_cursor.path()[(v367_21_origin + 1)..(v367_21_origin + 2)]);
        let v370_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v370_2));
        let v370_4: Space = if map_kernels::has_head(&(v370_3)) { singleton(&[]) } else { Space::new() };
        drop(v370_3);
        let v370_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v370_4));
        drop(v370_4);
        let v370_8: Space = if (&(v370_5)).is_empty() { Space::new() } else {
          let v371_6: Path = concat_path(&(v369_6),&v367_21_cursor.path()[(v367_21_origin + 1)..(v367_21_origin + 2)]);
          let mut v371_7 = Space::new();
          let mut v371_7_write = v371_7.write_zipper();
          for v371_7_byte in v367_21_cursor.child_mask().iter() {
            v367_21_cursor.descend_to_existing_byte(v371_7_byte);
            {
            let v372_2: Space = singleton(&v367_21_cursor.path()[(v367_21_origin + 2)..(v367_21_origin + 3)]);
            let v372_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v372_2));
            let v372_4: Space = if map_kernels::has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
            drop(v372_3);
            let v372_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v372_4));
            drop(v372_4);
            let v372_8: Space = if (&(v372_5)).is_empty() { Space::new() } else {
              let v373_6: Path = concat_path(&(v371_6),&v367_21_cursor.path()[(v367_21_origin + 2)..(v367_21_origin + 3)]);
              let v373_7: Space = routine_38(c, &(v373_6), &v367_21_cursor);
              map_map_kernels::compose(&(v372_5),&(v373_7))
            };
            drop(v372_5);
            let v372_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v372_2));
            drop(v372_2);
            let v372_10: Space = if map_kernels::has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
            drop(v372_9);
            let v372_12: Space = if (&(v372_10)).is_empty() { Space::new() } else {
              let v374_6: Path = concat_path(&(v371_6),&v367_21_cursor.path()[(v367_21_origin + 2)..(v367_21_origin + 3)]);
              let v374_11: Space = routine_39(c, &(v374_6), &v367_21_cursor);
              drop(v374_6);
              map_map_kernels::compose(&(v372_10),&(v374_11))
            };
            drop(v372_10);
            let v372_13: Space = map_map_kernels::unite(&(v372_8),&(v372_12));
            join_wrapped_into(&mut v371_7_write,&((v372_13).read_zipper()),&[]);
            }
            v367_21_cursor.ascend(1);
          }
          drop(v371_7_write);
          map_map_kernels::compose(&(v370_5),&(v371_7))
        };
        drop(v370_5);
        let v370_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v370_2));
        drop(v370_2);
        let v370_10: Space = if map_kernels::has_head(&(v370_9)) { singleton(&[]) } else { Space::new() };
        drop(v370_9);
        let v370_12: Space = if (&(v370_10)).is_empty() { Space::new() } else {
          let v375_6: Path = concat_path(&(v369_6),&v367_21_cursor.path()[(v367_21_origin + 1)..(v367_21_origin + 2)]);
          let mut v375_11 = Space::new();
          let mut v375_11_write = v375_11.write_zipper();
          for v375_11_byte in v367_21_cursor.child_mask().iter() {
            v367_21_cursor.descend_to_existing_byte(v375_11_byte);
            {
            let v376_2: Space = singleton(&v367_21_cursor.path()[(v367_21_origin + 2)..(v367_21_origin + 3)]);
            let v376_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v376_2));
            let v376_4: Space = if map_kernels::has_head(&(v376_3)) { singleton(&[]) } else { Space::new() };
            drop(v376_3);
            let v376_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v376_4));
            drop(v376_4);
            let v376_8: Space = if (&(v376_5)).is_empty() { Space::new() } else {
              let v377_6: Path = concat_path(&(v375_6),&v367_21_cursor.path()[(v367_21_origin + 2)..(v367_21_origin + 3)]);
              let v377_7: Space = routine_38(c, &(v377_6), &v367_21_cursor);
              map_map_kernels::compose(&(v376_5),&(v377_7))
            };
            drop(v376_5);
            let v376_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v376_2));
            drop(v376_2);
            let v376_10: Space = if map_kernels::has_head(&(v376_9)) { singleton(&[]) } else { Space::new() };
            drop(v376_9);
            let v376_12: Space = if (&(v376_10)).is_empty() { Space::new() } else {
              let v378_6: Path = concat_path(&(v375_6),&v367_21_cursor.path()[(v367_21_origin + 2)..(v367_21_origin + 3)]);
              let v378_11: Space = routine_14(c, &(v378_6), &v367_21_cursor);
              drop(v378_6);
              map_map_kernels::compose(&(v376_10),&(v378_11))
            };
            drop(v376_10);
            let v376_13: Space = map_map_kernels::unite(&(v376_8),&(v376_12));
            join_wrapped_into(&mut v375_11_write,&((v376_13).read_zipper()),&[]);
            }
            v367_21_cursor.ascend(1);
          }
          drop(v375_11_write);
          drop(v375_6);
          map_map_kernels::compose(&(v370_10),&(v375_11))
        };
        drop(v370_10);
        let v370_13: Space = map_map_kernels::unite(&(v370_8),&(v370_12));
        join_wrapped_into(&mut v369_7_write,&((v370_13).read_zipper()),&[]);
        }
        v367_21_cursor.ascend(1);
      }
      drop(v369_7_write);
      map_map_kernels::compose(&(v368_5),&(v369_7))
    };
    drop(v368_5);
    let v368_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v368_2));
    drop(v368_2);
    let v368_10: Space = if map_kernels::has_head(&(v368_9)) { singleton(&[]) } else { Space::new() };
    drop(v368_9);
    let v368_12: Space = if (&(v368_10)).is_empty() { Space::new() } else {
      let v379_6: Path = concat_path(&(*p0),&v367_21_cursor.path()[v367_21_origin..(v367_21_origin + 1)]);
      let mut v379_11 = Space::new();
      let mut v379_11_write = v379_11.write_zipper();
      for v379_11_byte in v367_21_cursor.child_mask().iter() {
        v367_21_cursor.descend_to_existing_byte(v379_11_byte);
        {
        let v380_2: Space = singleton(&v367_21_cursor.path()[(v367_21_origin + 1)..(v367_21_origin + 2)]);
        let v380_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v380_2));
        let v380_4: Space = if map_kernels::has_head(&(v380_3)) { singleton(&[]) } else { Space::new() };
        drop(v380_3);
        let v380_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v380_4));
        drop(v380_4);
        let v380_8: Space = if (&(v380_5)).is_empty() { Space::new() } else {
          let v381_6: Path = concat_path(&(v379_6),&v367_21_cursor.path()[(v367_21_origin + 1)..(v367_21_origin + 2)]);
          let mut v381_7 = Space::new();
          let mut v381_7_write = v381_7.write_zipper();
          for v381_7_byte in v367_21_cursor.child_mask().iter() {
            v367_21_cursor.descend_to_existing_byte(v381_7_byte);
            {
            let v382_2: Space = singleton(&v367_21_cursor.path()[(v367_21_origin + 2)..(v367_21_origin + 3)]);
            let v382_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v382_2));
            let v382_4: Space = if map_kernels::has_head(&(v382_3)) { singleton(&[]) } else { Space::new() };
            drop(v382_3);
            let v382_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v382_4));
            drop(v382_4);
            let v382_8: Space = if (&(v382_5)).is_empty() { Space::new() } else {
              let v383_6: Path = concat_path(&(v381_6),&v367_21_cursor.path()[(v367_21_origin + 2)..(v367_21_origin + 3)]);
              let v383_7: Space = routine_38(c, &(v383_6), &v367_21_cursor);
              map_map_kernels::compose(&(v382_5),&(v383_7))
            };
            drop(v382_5);
            let v382_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v382_2));
            drop(v382_2);
            let v382_10: Space = if map_kernels::has_head(&(v382_9)) { singleton(&[]) } else { Space::new() };
            drop(v382_9);
            let v382_12: Space = if (&(v382_10)).is_empty() { Space::new() } else {
              let v384_6: Path = concat_path(&(v381_6),&v367_21_cursor.path()[(v367_21_origin + 2)..(v367_21_origin + 3)]);
              let v384_11: Space = routine_39(c, &(v384_6), &v367_21_cursor);
              drop(v384_6);
              map_map_kernels::compose(&(v382_10),&(v384_11))
            };
            drop(v382_10);
            let v382_13: Space = map_map_kernels::unite(&(v382_8),&(v382_12));
            join_wrapped_into(&mut v381_7_write,&((v382_13).read_zipper()),&[]);
            }
            v367_21_cursor.ascend(1);
          }
          drop(v381_7_write);
          map_map_kernels::compose(&(v380_5),&(v381_7))
        };
        drop(v380_5);
        let v380_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v380_2));
        drop(v380_2);
        let v380_10: Space = if map_kernels::has_head(&(v380_9)) { singleton(&[]) } else { Space::new() };
        drop(v380_9);
        let v380_12: Space = if (&(v380_10)).is_empty() { Space::new() } else {
          let v385_11: Space = view_map_kernels::subtract(&v367_21_cursor,&(*CONSTANT_5));
          map_map_kernels::compose(&(v380_10),&(v385_11))
        };
        drop(v380_10);
        let v386_6: Path = concat_path(&(v379_6),&v367_21_cursor.path()[(v367_21_origin + 1)..(v367_21_origin + 2)]);
        let v380_13: Space = map_kernels::wrap(&(v380_12),&(v386_6));
        drop(v380_12);
        let v380_14: Space = map_map_kernels::unite(&(v380_8),&(v380_13));
        drop(v380_13);
        join_wrapped_into(&mut v379_11_write,&((v380_14).read_zipper()),&[]);
        }
        v367_21_cursor.ascend(1);
      }
      drop(v379_11_write);
      drop(v379_6);
      map_map_kernels::compose(&(v368_10),&(v379_11))
    };
    drop(v368_10);
    let v368_13: Space = map_map_kernels::unite(&(v368_8),&(v368_12));
    join_wrapped_into(&mut v367_21_write,&((v368_13).read_zipper()),&[]);
    }
    v367_21_cursor.ascend(1);
  }
  drop(v367_21_cursor);
  drop(v367_21_write);
  (v367_21).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v387_15 = Space::new();
  let mut v387_15_write = v387_15.write_zipper();
  let mut v387_15_cursor = (*s0).read_zipper();
  let v387_15_origin = v387_15_cursor.path().len();
  for v387_15_byte in v387_15_cursor.child_mask().iter() {
    v387_15_cursor.descend_to_existing_byte(v387_15_byte);
    {
    let v388_2: Space = singleton(&v387_15_cursor.path()[v387_15_origin..(v387_15_origin + 1)]);
    let v388_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v388_2));
    let v388_4: Space = if map_kernels::has_head(&(v388_3)) { singleton(&[]) } else { Space::new() };
    drop(v388_3);
    let v388_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v388_4));
    drop(v388_4);
    let v388_8: Space = if (&(v388_5)).is_empty() { Space::new() } else {
      let v389_6: Path = concat_path(&(*p0),&v387_15_cursor.path()[v387_15_origin..(v387_15_origin + 1)]);
      let mut v389_7 = Space::new();
      let mut v389_7_write = v389_7.write_zipper();
      for v389_7_byte in v387_15_cursor.child_mask().iter() {
        v387_15_cursor.descend_to_existing_byte(v389_7_byte);
        {
        let v390_2: Space = singleton(&v387_15_cursor.path()[(v387_15_origin + 1)..(v387_15_origin + 2)]);
        let v390_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v390_2));
        let v390_4: Space = if map_kernels::has_head(&(v390_3)) { singleton(&[]) } else { Space::new() };
        drop(v390_3);
        let v390_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v390_4));
        drop(v390_4);
        let v390_8: Space = if (&(v390_5)).is_empty() { Space::new() } else {
          let v391_6: Path = concat_path(&(v389_6),&v387_15_cursor.path()[(v387_15_origin + 1)..(v387_15_origin + 2)]);
          let mut v391_7 = Space::new();
          let mut v391_7_write = v391_7.write_zipper();
          for v391_7_byte in v387_15_cursor.child_mask().iter() {
            v387_15_cursor.descend_to_existing_byte(v391_7_byte);
            {
            let v392_2: Space = singleton(&v387_15_cursor.path()[(v387_15_origin + 2)..(v387_15_origin + 3)]);
            let v392_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v392_2));
            let v392_4: Space = if map_kernels::has_head(&(v392_3)) { singleton(&[]) } else { Space::new() };
            drop(v392_3);
            let v392_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v392_4));
            drop(v392_4);
            let v392_8: Space = if (&(v392_5)).is_empty() { Space::new() } else {
              let v393_6: Path = concat_path(&(v391_6),&v387_15_cursor.path()[(v387_15_origin + 2)..(v387_15_origin + 3)]);
              let v393_7: Space = routine_38(c, &(v393_6), &v387_15_cursor);
              map_map_kernels::compose(&(v392_5),&(v393_7))
            };
            drop(v392_5);
            let v392_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v392_2));
            drop(v392_2);
            let v392_10: Space = if map_kernels::has_head(&(v392_9)) { singleton(&[]) } else { Space::new() };
            drop(v392_9);
            let v392_12: Space = if (&(v392_10)).is_empty() { Space::new() } else {
              let v394_6: Path = concat_path(&(v391_6),&v387_15_cursor.path()[(v387_15_origin + 2)..(v387_15_origin + 3)]);
              let v394_11: Space = routine_39(c, &(v394_6), &v387_15_cursor);
              drop(v394_6);
              map_map_kernels::compose(&(v392_10),&(v394_11))
            };
            drop(v392_10);
            let v392_13: Space = map_map_kernels::unite(&(v392_8),&(v392_12));
            join_wrapped_into(&mut v391_7_write,&((v392_13).read_zipper()),&[]);
            }
            v387_15_cursor.ascend(1);
          }
          drop(v391_7_write);
          map_map_kernels::compose(&(v390_5),&(v391_7))
        };
        drop(v390_5);
        let v390_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v390_2));
        drop(v390_2);
        let v390_10: Space = if map_kernels::has_head(&(v390_9)) { singleton(&[]) } else { Space::new() };
        drop(v390_9);
        let v390_12: Space = if (&(v390_10)).is_empty() { Space::new() } else {
          let v395_6: Path = concat_path(&(v389_6),&v387_15_cursor.path()[(v387_15_origin + 1)..(v387_15_origin + 2)]);
          let mut v395_11 = Space::new();
          let mut v395_11_write = v395_11.write_zipper();
          for v395_11_byte in v387_15_cursor.child_mask().iter() {
            v387_15_cursor.descend_to_existing_byte(v395_11_byte);
            {
            let v396_2: Space = singleton(&v387_15_cursor.path()[(v387_15_origin + 2)..(v387_15_origin + 3)]);
            let v396_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v396_2));
            let v396_4: Space = if map_kernels::has_head(&(v396_3)) { singleton(&[]) } else { Space::new() };
            drop(v396_3);
            let v396_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v396_4));
            drop(v396_4);
            let v396_8: Space = if (&(v396_5)).is_empty() { Space::new() } else {
              let v397_6: Path = concat_path(&(v395_6),&v387_15_cursor.path()[(v387_15_origin + 2)..(v387_15_origin + 3)]);
              let v397_7: Space = routine_38(c, &(v397_6), &v387_15_cursor);
              map_map_kernels::compose(&(v396_5),&(v397_7))
            };
            drop(v396_5);
            let v396_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v396_2));
            drop(v396_2);
            let v396_10: Space = if map_kernels::has_head(&(v396_9)) { singleton(&[]) } else { Space::new() };
            drop(v396_9);
            let v396_12: Space = if (&(v396_10)).is_empty() { Space::new() } else {
              let v398_6: Path = concat_path(&(v395_6),&v387_15_cursor.path()[(v387_15_origin + 2)..(v387_15_origin + 3)]);
              let v398_11: Space = routine_14(c, &(v398_6), &v387_15_cursor);
              drop(v398_6);
              map_map_kernels::compose(&(v396_10),&(v398_11))
            };
            drop(v396_10);
            let v396_13: Space = map_map_kernels::unite(&(v396_8),&(v396_12));
            join_wrapped_into(&mut v395_11_write,&((v396_13).read_zipper()),&[]);
            }
            v387_15_cursor.ascend(1);
          }
          drop(v395_11_write);
          drop(v395_6);
          map_map_kernels::compose(&(v390_10),&(v395_11))
        };
        drop(v390_10);
        let v390_13: Space = map_map_kernels::unite(&(v390_8),&(v390_12));
        join_wrapped_into(&mut v389_7_write,&((v390_13).read_zipper()),&[]);
        }
        v387_15_cursor.ascend(1);
      }
      drop(v389_7_write);
      map_map_kernels::compose(&(v388_5),&(v389_7))
    };
    drop(v388_5);
    let v388_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v388_2));
    drop(v388_2);
    let v388_10: Space = if map_kernels::has_head(&(v388_9)) { singleton(&[]) } else { Space::new() };
    drop(v388_9);
    let v388_12: Space = if (&(v388_10)).is_empty() { Space::new() } else {
      let v399_11: Space = view_map_kernels::subtract(&v387_15_cursor,&(*CONSTANT_5));
      map_map_kernels::compose(&(v388_10),&(v399_11))
    };
    drop(v388_10);
    let v400_6: Path = concat_path(&(*p0),&v387_15_cursor.path()[v387_15_origin..(v387_15_origin + 1)]);
    let v388_13: Space = map_kernels::wrap(&(v388_12),&(v400_6));
    drop(v388_12);
    let v388_14: Space = map_map_kernels::unite(&(v388_8),&(v388_13));
    drop(v388_13);
    join_wrapped_into(&mut v387_15_write,&((v388_14).read_zipper()),&[]);
    }
    v387_15_cursor.ascend(1);
  }
  drop(v387_15_cursor);
  drop(v387_15_write);
  (v387_15).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v401_3: Space = view_map_kernels::subtract(&(*s0),&(*CONSTANT_5));
  let v401_4: Space = map_kernels::wrap(&(v401_3),&(*p0));
  drop(v401_3);
  (v401_4).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v402_24 = Space::new();
  let mut v402_24_write = v402_24.write_zipper();
  let mut v402_24_cursor = (*s0).read_zipper();
  let v402_24_origin = v402_24_cursor.path().len();
  for v402_24_byte in v402_24_cursor.child_mask().iter() {
    v402_24_cursor.descend_to_existing_byte(v402_24_byte);
    {
    let v403_2: Space = singleton(&v402_24_cursor.path()[v402_24_origin..(v402_24_origin + 1)]);
    let v403_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v403_2));
    let v403_4: Space = if map_kernels::has_head(&(v403_3)) { singleton(&[]) } else { Space::new() };
    drop(v403_3);
    let v403_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v403_4));
    drop(v403_4);
    let v403_8: Space = if (&(v403_5)).is_empty() { Space::new() } else {
      let v404_6: Path = concat_path(&(*p0),&v402_24_cursor.path()[v402_24_origin..(v402_24_origin + 1)]);
      let mut v404_7 = Space::new();
      let mut v404_7_write = v404_7.write_zipper();
      for v404_7_byte in v402_24_cursor.child_mask().iter() {
        v402_24_cursor.descend_to_existing_byte(v404_7_byte);
        {
        let v405_2: Space = singleton(&v402_24_cursor.path()[(v402_24_origin + 1)..(v402_24_origin + 2)]);
        let v405_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v405_2));
        let v405_4: Space = if map_kernels::has_head(&(v405_3)) { singleton(&[]) } else { Space::new() };
        drop(v405_3);
        let v405_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v405_4));
        drop(v405_4);
        let v405_8: Space = if (&(v405_5)).is_empty() { Space::new() } else {
          let v406_6: Path = concat_path(&(v404_6),&v402_24_cursor.path()[(v402_24_origin + 1)..(v402_24_origin + 2)]);
          let mut v406_7 = Space::new();
          let mut v406_7_write = v406_7.write_zipper();
          for v406_7_byte in v402_24_cursor.child_mask().iter() {
            v402_24_cursor.descend_to_existing_byte(v406_7_byte);
            {
            let v407_2: Space = singleton(&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
            let v407_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v407_2));
            let v407_4: Space = if map_kernels::has_head(&(v407_3)) { singleton(&[]) } else { Space::new() };
            drop(v407_3);
            let v407_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v407_4));
            drop(v407_4);
            let v407_8: Space = if (&(v407_5)).is_empty() { Space::new() } else {
              let v408_6: Path = concat_path(&(v406_6),&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
              let v408_7: Space = routine_40(c, &(v408_6), &v402_24_cursor, &(*s1));
              map_map_kernels::compose(&(v407_5),&(v408_7))
            };
            drop(v407_5);
            let v407_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v407_2));
            drop(v407_2);
            let v407_10: Space = if map_kernels::has_head(&(v407_9)) { singleton(&[]) } else { Space::new() };
            drop(v407_9);
            let v407_12: Space = if (&(v407_10)).is_empty() { Space::new() } else {
              let v409_6: Path = concat_path(&(v406_6),&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
              let v409_11: Space = routine_41(c, &(v409_6), &v402_24_cursor, &(*s1));
              drop(v409_6);
              map_map_kernels::compose(&(v407_10),&(v409_11))
            };
            drop(v407_10);
            let v407_13: Space = map_map_kernels::unite(&(v407_8),&(v407_12));
            join_wrapped_into(&mut v406_7_write,&((v407_13).read_zipper()),&[]);
            }
            v402_24_cursor.ascend(1);
          }
          drop(v406_7_write);
          map_map_kernels::compose(&(v405_5),&(v406_7))
        };
        drop(v405_5);
        let v405_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v405_2));
        drop(v405_2);
        let v405_10: Space = if map_kernels::has_head(&(v405_9)) { singleton(&[]) } else { Space::new() };
        drop(v405_9);
        let v405_12: Space = if (&(v405_10)).is_empty() { Space::new() } else {
          let v410_6: Path = concat_path(&(v404_6),&v402_24_cursor.path()[(v402_24_origin + 1)..(v402_24_origin + 2)]);
          let mut v410_11 = Space::new();
          let mut v410_11_write = v410_11.write_zipper();
          for v410_11_byte in v402_24_cursor.child_mask().iter() {
            v402_24_cursor.descend_to_existing_byte(v410_11_byte);
            {
            let v411_2: Space = singleton(&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
            let v411_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v411_2));
            let v411_4: Space = if map_kernels::has_head(&(v411_3)) { singleton(&[]) } else { Space::new() };
            drop(v411_3);
            let v411_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v411_4));
            drop(v411_4);
            let v411_8: Space = if (&(v411_5)).is_empty() { Space::new() } else {
              let v412_6: Path = concat_path(&(v410_6),&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
              let v412_7: Space = routine_40(c, &(v412_6), &v402_24_cursor, &(*s1));
              map_map_kernels::compose(&(v411_5),&(v412_7))
            };
            drop(v411_5);
            let v411_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v411_2));
            drop(v411_2);
            let v411_10: Space = if map_kernels::has_head(&(v411_9)) { singleton(&[]) } else { Space::new() };
            drop(v411_9);
            let v411_12: Space = if (&(v411_10)).is_empty() { Space::new() } else {
              let v413_6: Path = concat_path(&(v410_6),&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
              let v413_11: Space = routine_17(c, &(v413_6), &v402_24_cursor, &(*s1));
              drop(v413_6);
              map_map_kernels::compose(&(v411_10),&(v413_11))
            };
            drop(v411_10);
            let v411_13: Space = map_map_kernels::unite(&(v411_8),&(v411_12));
            join_wrapped_into(&mut v410_11_write,&((v411_13).read_zipper()),&[]);
            }
            v402_24_cursor.ascend(1);
          }
          drop(v410_11_write);
          drop(v410_6);
          map_map_kernels::compose(&(v405_10),&(v410_11))
        };
        drop(v405_10);
        let v405_13: Space = map_map_kernels::unite(&(v405_8),&(v405_12));
        join_wrapped_into(&mut v404_7_write,&((v405_13).read_zipper()),&[]);
        }
        v402_24_cursor.ascend(1);
      }
      drop(v404_7_write);
      map_map_kernels::compose(&(v403_5),&(v404_7))
    };
    drop(v403_5);
    let v403_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v403_2));
    drop(v403_2);
    let v403_10: Space = if map_kernels::has_head(&(v403_9)) { singleton(&[]) } else { Space::new() };
    drop(v403_9);
    let v403_12: Space = if (&(v403_10)).is_empty() { Space::new() } else {
      let v414_6: Path = concat_path(&(*p0),&v402_24_cursor.path()[v402_24_origin..(v402_24_origin + 1)]);
      let mut v414_11 = Space::new();
      let mut v414_11_write = v414_11.write_zipper();
      for v414_11_byte in v402_24_cursor.child_mask().iter() {
        v402_24_cursor.descend_to_existing_byte(v414_11_byte);
        {
        let v415_2: Space = singleton(&v402_24_cursor.path()[(v402_24_origin + 1)..(v402_24_origin + 2)]);
        let v415_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v415_2));
        let v415_4: Space = if map_kernels::has_head(&(v415_3)) { singleton(&[]) } else { Space::new() };
        drop(v415_3);
        let v415_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v415_4));
        drop(v415_4);
        let v415_8: Space = if (&(v415_5)).is_empty() { Space::new() } else {
          let v416_6: Path = concat_path(&(v414_6),&v402_24_cursor.path()[(v402_24_origin + 1)..(v402_24_origin + 2)]);
          let mut v416_7 = Space::new();
          let mut v416_7_write = v416_7.write_zipper();
          for v416_7_byte in v402_24_cursor.child_mask().iter() {
            v402_24_cursor.descend_to_existing_byte(v416_7_byte);
            {
            let v417_2: Space = singleton(&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
            let v417_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v417_2));
            let v417_4: Space = if map_kernels::has_head(&(v417_3)) { singleton(&[]) } else { Space::new() };
            drop(v417_3);
            let v417_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v417_4));
            drop(v417_4);
            let v417_8: Space = if (&(v417_5)).is_empty() { Space::new() } else {
              let v418_6: Path = concat_path(&(v416_6),&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
              let v418_7: Space = routine_40(c, &(v418_6), &v402_24_cursor, &(*s1));
              map_map_kernels::compose(&(v417_5),&(v418_7))
            };
            drop(v417_5);
            let v417_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v417_2));
            drop(v417_2);
            let v417_10: Space = if map_kernels::has_head(&(v417_9)) { singleton(&[]) } else { Space::new() };
            drop(v417_9);
            let v417_12: Space = if (&(v417_10)).is_empty() { Space::new() } else {
              let v419_6: Path = concat_path(&(v416_6),&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
              let v419_11: Space = routine_41(c, &(v419_6), &v402_24_cursor, &(*s1));
              drop(v419_6);
              map_map_kernels::compose(&(v417_10),&(v419_11))
            };
            drop(v417_10);
            let v417_13: Space = map_map_kernels::unite(&(v417_8),&(v417_12));
            join_wrapped_into(&mut v416_7_write,&((v417_13).read_zipper()),&[]);
            }
            v402_24_cursor.ascend(1);
          }
          drop(v416_7_write);
          map_map_kernels::compose(&(v415_5),&(v416_7))
        };
        drop(v415_5);
        let v415_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v415_2));
        drop(v415_2);
        let v415_10: Space = if map_kernels::has_head(&(v415_9)) { singleton(&[]) } else { Space::new() };
        drop(v415_9);
        let v415_12: Space = if (&(v415_10)).is_empty() { Space::new() } else {
          let mut v420_11 = Space::new();
          let mut v420_11_write = v420_11.write_zipper();
          for v420_11_byte in v402_24_cursor.child_mask().iter() {
            v402_24_cursor.descend_to_existing_byte(v420_11_byte);
            {
            let v421_2: Space = singleton(&v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)]);
            let v421_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v421_2));
            let v421_4: Space = if map_kernels::has_head(&(v421_3)) { singleton(&[]) } else { Space::new() };
            drop(v421_3);
            let v421_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v421_4));
            drop(v421_4);
            let v421_7: Space = if (&(v421_5)).is_empty() { Space::new() } else {
              let v422_6: Space = routine_18(c, &v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)], &v402_24_cursor, &(*s1));
              map_map_kernels::compose(&(v421_5),&(v422_6))
            };
            drop(v421_5);
            let v421_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v421_2));
            drop(v421_2);
            let v421_9: Space = if map_kernels::has_head(&(v421_8)) { singleton(&[]) } else { Space::new() };
            drop(v421_8);
            let v421_11: Space = if (&(v421_9)).is_empty() { Space::new() } else {
              let v423_10: Space = routine_19(c, &v402_24_cursor.path()[(v402_24_origin + 2)..(v402_24_origin + 3)], &v402_24_cursor, &(*s1));
              map_map_kernels::compose(&(v421_9),&(v423_10))
            };
            drop(v421_9);
            let v421_12: Space = map_map_kernels::unite(&(v421_7),&(v421_11));
            join_wrapped_into(&mut v420_11_write,&((v421_12).read_zipper()),&[]);
            }
            v402_24_cursor.ascend(1);
          }
          drop(v420_11_write);
          map_map_kernels::compose(&(v415_10),&(v420_11))
        };
        drop(v415_10);
        let v424_6: Path = concat_path(&(v414_6),&v402_24_cursor.path()[(v402_24_origin + 1)..(v402_24_origin + 2)]);
        let v415_13: Space = map_kernels::wrap(&(v415_12),&(v424_6));
        let v415_14: Space = map_map_kernels::unite(&(v415_8),&(v415_13));
        join_wrapped_into(&mut v414_11_write,&((v415_14).read_zipper()),&[]);
        }
        v402_24_cursor.ascend(1);
      }
      drop(v414_11_write);
      drop(v414_6);
      map_map_kernels::compose(&(v403_10),&(v414_11))
    };
    drop(v403_10);
    let v403_13: Space = map_map_kernels::unite(&(v403_8),&(v403_12));
    join_wrapped_into(&mut v402_24_write,&((v403_13).read_zipper()),&[]);
    }
    v402_24_cursor.ascend(1);
  }
  drop(v402_24_cursor);
  drop(v402_24_write);
  (v402_24).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v425_24 = Space::new();
  let mut v425_24_write = v425_24.write_zipper();
  let mut v425_24_cursor = (*s0).read_zipper();
  let v425_24_origin = v425_24_cursor.path().len();
  for v425_24_byte in v425_24_cursor.child_mask().iter() {
    v425_24_cursor.descend_to_existing_byte(v425_24_byte);
    {
    let v426_2: Space = singleton(&v425_24_cursor.path()[v425_24_origin..(v425_24_origin + 1)]);
    let v426_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v426_2));
    let v426_4: Space = if map_kernels::has_head(&(v426_3)) { singleton(&[]) } else { Space::new() };
    drop(v426_3);
    let v426_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v426_4));
    drop(v426_4);
    let v426_8: Space = if (&(v426_5)).is_empty() { Space::new() } else {
      let v427_6: Path = concat_path(&(*p0),&v425_24_cursor.path()[v425_24_origin..(v425_24_origin + 1)]);
      let mut v427_7 = Space::new();
      let mut v427_7_write = v427_7.write_zipper();
      for v427_7_byte in v425_24_cursor.child_mask().iter() {
        v425_24_cursor.descend_to_existing_byte(v427_7_byte);
        {
        let v428_2: Space = singleton(&v425_24_cursor.path()[(v425_24_origin + 1)..(v425_24_origin + 2)]);
        let v428_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v428_2));
        let v428_4: Space = if map_kernels::has_head(&(v428_3)) { singleton(&[]) } else { Space::new() };
        drop(v428_3);
        let v428_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v428_4));
        drop(v428_4);
        let v428_8: Space = if (&(v428_5)).is_empty() { Space::new() } else {
          let v429_6: Path = concat_path(&(v427_6),&v425_24_cursor.path()[(v425_24_origin + 1)..(v425_24_origin + 2)]);
          let mut v429_7 = Space::new();
          let mut v429_7_write = v429_7.write_zipper();
          for v429_7_byte in v425_24_cursor.child_mask().iter() {
            v425_24_cursor.descend_to_existing_byte(v429_7_byte);
            {
            let v430_2: Space = singleton(&v425_24_cursor.path()[(v425_24_origin + 2)..(v425_24_origin + 3)]);
            let v430_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v430_2));
            let v430_4: Space = if map_kernels::has_head(&(v430_3)) { singleton(&[]) } else { Space::new() };
            drop(v430_3);
            let v430_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v430_4));
            drop(v430_4);
            let v430_8: Space = if (&(v430_5)).is_empty() { Space::new() } else {
              let v431_6: Path = concat_path(&(v429_6),&v425_24_cursor.path()[(v425_24_origin + 2)..(v425_24_origin + 3)]);
              let v431_7: Space = routine_40(c, &(v431_6), &v425_24_cursor, &(*s1));
              map_map_kernels::compose(&(v430_5),&(v431_7))
            };
            drop(v430_5);
            let v430_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v430_2));
            drop(v430_2);
            let v430_10: Space = if map_kernels::has_head(&(v430_9)) { singleton(&[]) } else { Space::new() };
            drop(v430_9);
            let v430_12: Space = if (&(v430_10)).is_empty() { Space::new() } else {
              let v432_6: Path = concat_path(&(v429_6),&v425_24_cursor.path()[(v425_24_origin + 2)..(v425_24_origin + 3)]);
              let v432_11: Space = routine_41(c, &(v432_6), &v425_24_cursor, &(*s1));
              drop(v432_6);
              map_map_kernels::compose(&(v430_10),&(v432_11))
            };
            drop(v430_10);
            let v430_13: Space = map_map_kernels::unite(&(v430_8),&(v430_12));
            join_wrapped_into(&mut v429_7_write,&((v430_13).read_zipper()),&[]);
            }
            v425_24_cursor.ascend(1);
          }
          drop(v429_7_write);
          map_map_kernels::compose(&(v428_5),&(v429_7))
        };
        drop(v428_5);
        let v428_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v428_2));
        drop(v428_2);
        let v428_10: Space = if map_kernels::has_head(&(v428_9)) { singleton(&[]) } else { Space::new() };
        drop(v428_9);
        let v428_12: Space = if (&(v428_10)).is_empty() { Space::new() } else {
          let v433_6: Path = concat_path(&(v427_6),&v425_24_cursor.path()[(v425_24_origin + 1)..(v425_24_origin + 2)]);
          let mut v433_11 = Space::new();
          let mut v433_11_write = v433_11.write_zipper();
          for v433_11_byte in v425_24_cursor.child_mask().iter() {
            v425_24_cursor.descend_to_existing_byte(v433_11_byte);
            {
            let v434_2: Space = singleton(&v425_24_cursor.path()[(v425_24_origin + 2)..(v425_24_origin + 3)]);
            let v434_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v434_2));
            let v434_4: Space = if map_kernels::has_head(&(v434_3)) { singleton(&[]) } else { Space::new() };
            drop(v434_3);
            let v434_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v434_4));
            drop(v434_4);
            let v434_8: Space = if (&(v434_5)).is_empty() { Space::new() } else {
              let v435_6: Path = concat_path(&(v433_6),&v425_24_cursor.path()[(v425_24_origin + 2)..(v425_24_origin + 3)]);
              let v435_7: Space = routine_40(c, &(v435_6), &v425_24_cursor, &(*s1));
              map_map_kernels::compose(&(v434_5),&(v435_7))
            };
            drop(v434_5);
            let v434_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v434_2));
            drop(v434_2);
            let v434_10: Space = if map_kernels::has_head(&(v434_9)) { singleton(&[]) } else { Space::new() };
            drop(v434_9);
            let v434_12: Space = if (&(v434_10)).is_empty() { Space::new() } else {
              let v436_6: Path = concat_path(&(v433_6),&v425_24_cursor.path()[(v425_24_origin + 2)..(v425_24_origin + 3)]);
              let v436_11: Space = routine_17(c, &(v436_6), &v425_24_cursor, &(*s1));
              drop(v436_6);
              map_map_kernels::compose(&(v434_10),&(v436_11))
            };
            drop(v434_10);
            let v434_13: Space = map_map_kernels::unite(&(v434_8),&(v434_12));
            join_wrapped_into(&mut v433_11_write,&((v434_13).read_zipper()),&[]);
            }
            v425_24_cursor.ascend(1);
          }
          drop(v433_11_write);
          drop(v433_6);
          map_map_kernels::compose(&(v428_10),&(v433_11))
        };
        drop(v428_10);
        let v428_13: Space = map_map_kernels::unite(&(v428_8),&(v428_12));
        join_wrapped_into(&mut v427_7_write,&((v428_13).read_zipper()),&[]);
        }
        v425_24_cursor.ascend(1);
      }
      drop(v427_7_write);
      map_map_kernels::compose(&(v426_5),&(v427_7))
    };
    drop(v426_5);
    let v426_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v426_2));
    drop(v426_2);
    let v426_10: Space = if map_kernels::has_head(&(v426_9)) { singleton(&[]) } else { Space::new() };
    drop(v426_9);
    let v426_12: Space = if (&(v426_10)).is_empty() { Space::new() } else {
      let mut v437_11 = Space::new();
      let mut v437_11_write = v437_11.write_zipper();
      for v437_11_byte in v425_24_cursor.child_mask().iter() {
        v425_24_cursor.descend_to_existing_byte(v437_11_byte);
        {
        let v438_2: Space = singleton(&v425_24_cursor.path()[(v425_24_origin + 1)..(v425_24_origin + 2)]);
        let v438_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v438_2));
        let v438_4: Space = if map_kernels::has_head(&(v438_3)) { singleton(&[]) } else { Space::new() };
        drop(v438_3);
        let v438_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v438_4));
        drop(v438_4);
        let v438_7: Space = if (&(v438_5)).is_empty() { Space::new() } else {
          let mut v439_6 = Space::new();
          let mut v439_6_write = v439_6.write_zipper();
          for v439_6_byte in v425_24_cursor.child_mask().iter() {
            v425_24_cursor.descend_to_existing_byte(v439_6_byte);
            {
            let v440_2: Space = singleton(&v425_24_cursor.path()[(v425_24_origin + 2)..(v425_24_origin + 3)]);
            let v440_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v440_2));
            let v440_4: Space = if map_kernels::has_head(&(v440_3)) { singleton(&[]) } else { Space::new() };
            drop(v440_3);
            let v440_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v440_4));
            drop(v440_4);
            let v440_8: Space = if (&(v440_5)).is_empty() { Space::new() } else {
              let v441_7: Space = routine_42(c, &v425_24_cursor.path()[(v425_24_origin + 1)..(v425_24_origin + 3)], &v425_24_cursor, &(*s1));
              map_map_kernels::compose(&(v440_5),&(v441_7))
            };
            drop(v440_5);
            let v440_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v440_2));
            drop(v440_2);
            let v440_10: Space = if map_kernels::has_head(&(v440_9)) { singleton(&[]) } else { Space::new() };
            drop(v440_9);
            let v440_12: Space = if (&(v440_10)).is_empty() { Space::new() } else {
              let v442_11: Space = routine_43(c, &v425_24_cursor.path()[(v425_24_origin + 1)..(v425_24_origin + 3)], &v425_24_cursor, &(*s1));
              map_map_kernels::compose(&(v440_10),&(v442_11))
            };
            drop(v440_10);
            let v440_13: Space = map_map_kernels::unite(&(v440_8),&(v440_12));
            join_wrapped_into(&mut v439_6_write,&((v440_13).read_zipper()),&[]);
            }
            v425_24_cursor.ascend(1);
          }
          drop(v439_6_write);
          map_map_kernels::compose(&(v438_5),&(v439_6))
        };
        drop(v438_5);
        let v438_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v438_2));
        drop(v438_2);
        let v438_9: Space = if map_kernels::has_head(&(v438_8)) { singleton(&[]) } else { Space::new() };
        drop(v438_8);
        let v438_11: Space = if (&(v438_9)).is_empty() { Space::new() } else {
          let mut v443_10 = Space::new();
          let mut v443_10_write = v443_10.write_zipper();
          for v443_10_byte in v425_24_cursor.child_mask().iter() {
            v425_24_cursor.descend_to_existing_byte(v443_10_byte);
            {
            let v444_2: Space = singleton(&v425_24_cursor.path()[(v425_24_origin + 2)..(v425_24_origin + 3)]);
            let v444_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v444_2));
            let v444_4: Space = if map_kernels::has_head(&(v444_3)) { singleton(&[]) } else { Space::new() };
            drop(v444_3);
            let v444_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v444_4));
            drop(v444_4);
            let v444_8: Space = if (&(v444_5)).is_empty() { Space::new() } else {
              let v445_7: Space = routine_42(c, &v425_24_cursor.path()[(v425_24_origin + 1)..(v425_24_origin + 3)], &v425_24_cursor, &(*s1));
              map_map_kernels::compose(&(v444_5),&(v445_7))
            };
            drop(v444_5);
            let v444_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v444_2));
            drop(v444_2);
            let v444_10: Space = if map_kernels::has_head(&(v444_9)) { singleton(&[]) } else { Space::new() };
            drop(v444_9);
            let v444_12: Space = if (&(v444_10)).is_empty() { Space::new() } else {
              let v446_11: Space = routine_44(c, &v425_24_cursor.path()[(v425_24_origin + 1)..(v425_24_origin + 3)], &v425_24_cursor, &(*s1));
              map_map_kernels::compose(&(v444_10),&(v446_11))
            };
            drop(v444_10);
            let v444_13: Space = map_map_kernels::unite(&(v444_8),&(v444_12));
            join_wrapped_into(&mut v443_10_write,&((v444_13).read_zipper()),&[]);
            }
            v425_24_cursor.ascend(1);
          }
          drop(v443_10_write);
          map_map_kernels::compose(&(v438_9),&(v443_10))
        };
        drop(v438_9);
        let v438_12: Space = map_map_kernels::unite(&(v438_7),&(v438_11));
        join_wrapped_into(&mut v437_11_write,&((v438_12).read_zipper()),&[]);
        }
        v425_24_cursor.ascend(1);
      }
      drop(v437_11_write);
      map_map_kernels::compose(&(v426_10),&(v437_11))
    };
    drop(v426_10);
    let v447_6: Path = concat_path(&(*p0),&v425_24_cursor.path()[v425_24_origin..(v425_24_origin + 1)]);
    let v426_13: Space = map_kernels::wrap(&(v426_12),&(v447_6));
    let v426_14: Space = map_map_kernels::unite(&(v426_8),&(v426_13));
    join_wrapped_into(&mut v425_24_write,&((v426_14).read_zipper()),&[]);
    }
    v425_24_cursor.ascend(1);
  }
  drop(v425_24_cursor);
  drop(v425_24_write);
  (v425_24).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v448_26 = Space::new();
  let mut v448_26_write = v448_26.write_zipper();
  let mut v448_26_cursor = (*s0).read_zipper();
  let v448_26_origin = v448_26_cursor.path().len();
  for v448_26_byte in v448_26_cursor.child_mask().iter() {
    v448_26_cursor.descend_to_existing_byte(v448_26_byte);
    {
    let v449_2: Space = singleton(&v448_26_cursor.path()[v448_26_origin..(v448_26_origin + 1)]);
    let v449_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v449_2));
    let v449_4: Space = if map_kernels::has_head(&(v449_3)) { singleton(&[]) } else { Space::new() };
    drop(v449_3);
    let v449_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v449_4));
    drop(v449_4);
    let v449_7: Space = if (&(v449_5)).is_empty() { Space::new() } else {
      let mut v450_6 = Space::new();
      let mut v450_6_write = v450_6.write_zipper();
      for v450_6_byte in v448_26_cursor.child_mask().iter() {
        v448_26_cursor.descend_to_existing_byte(v450_6_byte);
        {
        let v451_2: Space = singleton(&v448_26_cursor.path()[(v448_26_origin + 1)..(v448_26_origin + 2)]);
        let v451_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v451_2));
        let v451_4: Space = if map_kernels::has_head(&(v451_3)) { singleton(&[]) } else { Space::new() };
        drop(v451_3);
        let v451_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v451_4));
        drop(v451_4);
        let v451_8: Space = if (&(v451_5)).is_empty() { Space::new() } else {
          let mut v452_7 = Space::new();
          let mut v452_7_write = v452_7.write_zipper();
          for v452_7_byte in v448_26_cursor.child_mask().iter() {
            v448_26_cursor.descend_to_existing_byte(v452_7_byte);
            {
            let v453_2: Space = singleton(&v448_26_cursor.path()[(v448_26_origin + 2)..(v448_26_origin + 3)]);
            let v453_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v453_2));
            let v453_4: Space = if map_kernels::has_head(&(v453_3)) { singleton(&[]) } else { Space::new() };
            drop(v453_3);
            let v453_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v453_4));
            drop(v453_4);
            let v453_8: Space = if (&(v453_5)).is_empty() { Space::new() } else {
              let v454_7: Space = routine_45(c, &v448_26_cursor.path()[v448_26_origin..(v448_26_origin + 3)], &v448_26_cursor, &(*s1));
              map_map_kernels::compose(&(v453_5),&(v454_7))
            };
            drop(v453_5);
            let v453_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v453_2));
            drop(v453_2);
            let v453_10: Space = if map_kernels::has_head(&(v453_9)) { singleton(&[]) } else { Space::new() };
            drop(v453_9);
            let v453_12: Space = if (&(v453_10)).is_empty() { Space::new() } else {
              let v455_11: Space = routine_46(c, &v448_26_cursor.path()[v448_26_origin..(v448_26_origin + 3)], &v448_26_cursor, &(*s1));
              map_map_kernels::compose(&(v453_10),&(v455_11))
            };
            drop(v453_10);
            let v453_13: Space = map_map_kernels::unite(&(v453_8),&(v453_12));
            join_wrapped_into(&mut v452_7_write,&((v453_13).read_zipper()),&[]);
            }
            v448_26_cursor.ascend(1);
          }
          drop(v452_7_write);
          map_map_kernels::compose(&(v451_5),&(v452_7))
        };
        drop(v451_5);
        let v451_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v451_2));
        drop(v451_2);
        let v451_10: Space = if map_kernels::has_head(&(v451_9)) { singleton(&[]) } else { Space::new() };
        drop(v451_9);
        let v451_12: Space = if (&(v451_10)).is_empty() { Space::new() } else {
          let mut v456_11 = Space::new();
          let mut v456_11_write = v456_11.write_zipper();
          for v456_11_byte in v448_26_cursor.child_mask().iter() {
            v448_26_cursor.descend_to_existing_byte(v456_11_byte);
            {
            let v457_2: Space = singleton(&v448_26_cursor.path()[(v448_26_origin + 2)..(v448_26_origin + 3)]);
            let v457_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v457_2));
            let v457_4: Space = if map_kernels::has_head(&(v457_3)) { singleton(&[]) } else { Space::new() };
            drop(v457_3);
            let v457_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v457_4));
            drop(v457_4);
            let v457_8: Space = if (&(v457_5)).is_empty() { Space::new() } else {
              let v458_7: Space = routine_45(c, &v448_26_cursor.path()[v448_26_origin..(v448_26_origin + 3)], &v448_26_cursor, &(*s1));
              map_map_kernels::compose(&(v457_5),&(v458_7))
            };
            drop(v457_5);
            let v457_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v457_2));
            drop(v457_2);
            let v457_10: Space = if map_kernels::has_head(&(v457_9)) { singleton(&[]) } else { Space::new() };
            drop(v457_9);
            let v457_12: Space = if (&(v457_10)).is_empty() { Space::new() } else {
              let v459_11: Space = routine_44(c, &v448_26_cursor.path()[v448_26_origin..(v448_26_origin + 3)], &v448_26_cursor, &(*s1));
              map_map_kernels::compose(&(v457_10),&(v459_11))
            };
            drop(v457_10);
            let v457_13: Space = map_map_kernels::unite(&(v457_8),&(v457_12));
            join_wrapped_into(&mut v456_11_write,&((v457_13).read_zipper()),&[]);
            }
            v448_26_cursor.ascend(1);
          }
          drop(v456_11_write);
          map_map_kernels::compose(&(v451_10),&(v456_11))
        };
        drop(v451_10);
        let v451_13: Space = map_map_kernels::unite(&(v451_8),&(v451_12));
        join_wrapped_into(&mut v450_6_write,&((v451_13).read_zipper()),&[]);
        }
        v448_26_cursor.ascend(1);
      }
      drop(v450_6_write);
      map_map_kernels::compose(&(v449_5),&(v450_6))
    };
    drop(v449_5);
    let v449_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v449_2));
    drop(v449_2);
    let v449_9: Space = if map_kernels::has_head(&(v449_8)) { singleton(&[]) } else { Space::new() };
    drop(v449_8);
    let v449_12: Space = if (&(v449_9)).is_empty() { Space::new() } else {
      let mut v460_11 = Space::new();
      let mut v460_11_write = v460_11.write_zipper();
      for v460_11_byte in v448_26_cursor.child_mask().iter() {
        v448_26_cursor.descend_to_existing_byte(v460_11_byte);
        {
        let v461_2: Space = singleton(&v448_26_cursor.path()[(v448_26_origin + 1)..(v448_26_origin + 2)]);
        let v461_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v461_2));
        let v461_4: Space = if map_kernels::has_head(&(v461_3)) { singleton(&[]) } else { Space::new() };
        drop(v461_3);
        let v461_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v461_4));
        drop(v461_4);
        let v461_8: Space = if (&(v461_5)).is_empty() { Space::new() } else {
          let mut v462_7 = Space::new();
          let mut v462_7_write = v462_7.write_zipper();
          for v462_7_byte in v448_26_cursor.child_mask().iter() {
            v448_26_cursor.descend_to_existing_byte(v462_7_byte);
            {
            let v463_2: Space = singleton(&v448_26_cursor.path()[(v448_26_origin + 2)..(v448_26_origin + 3)]);
            let v463_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v463_2));
            let v463_4: Space = if map_kernels::has_head(&(v463_3)) { singleton(&[]) } else { Space::new() };
            drop(v463_3);
            let v463_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v463_4));
            drop(v463_4);
            let v463_8: Space = if (&(v463_5)).is_empty() { Space::new() } else {
              let v464_7: Space = routine_45(c, &v448_26_cursor.path()[v448_26_origin..(v448_26_origin + 3)], &v448_26_cursor, &(*s1));
              map_map_kernels::compose(&(v463_5),&(v464_7))
            };
            drop(v463_5);
            let v463_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v463_2));
            drop(v463_2);
            let v463_10: Space = if map_kernels::has_head(&(v463_9)) { singleton(&[]) } else { Space::new() };
            drop(v463_9);
            let v463_12: Space = if (&(v463_10)).is_empty() { Space::new() } else {
              let v465_11: Space = routine_46(c, &v448_26_cursor.path()[v448_26_origin..(v448_26_origin + 3)], &v448_26_cursor, &(*s1));
              map_map_kernels::compose(&(v463_10),&(v465_11))
            };
            drop(v463_10);
            let v463_13: Space = map_map_kernels::unite(&(v463_8),&(v463_12));
            join_wrapped_into(&mut v462_7_write,&((v463_13).read_zipper()),&[]);
            }
            v448_26_cursor.ascend(1);
          }
          drop(v462_7_write);
          map_map_kernels::compose(&(v461_5),&(v462_7))
        };
        drop(v461_5);
        let v461_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v461_2));
        drop(v461_2);
        let v461_10: Space = if map_kernels::has_head(&(v461_9)) { singleton(&[]) } else { Space::new() };
        drop(v461_9);
        let v461_13: Space = if (&(v461_10)).is_empty() { Space::new() } else {
          let v466_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&v448_26_cursor.path()[v448_26_origin..(v448_26_origin + 1)]),&v448_26_cursor.path()[(v448_26_origin + 1)..(v448_26_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v461_10),&(v466_12))
        };
        drop(v461_10);
        let v461_14: Space = map_map_kernels::unite(&(v461_8),&(v461_13));
        drop(v461_13);
        join_wrapped_into(&mut v460_11_write,&((v461_14).read_zipper()),&[]);
        }
        v448_26_cursor.ascend(1);
      }
      drop(v460_11_write);
      map_map_kernels::compose(&(v449_9),&(v460_11))
    };
    drop(v449_9);
    let v449_13: Space = map_map_kernels::unite(&(v449_7),&(v449_12));
    join_wrapped_into(&mut v448_26_write,&((v449_13).read_zipper()),&[]);
    }
    v448_26_cursor.ascend(1);
  }
  drop(v448_26_cursor);
  drop(v448_26_write);
  let v448_27: Space = map_kernels::wrap(&(v448_26),&(*p0));
  (v448_27).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v467_27 = Space::new();
  let mut v467_27_write = v467_27.write_zipper();
  let mut v467_27_cursor = (*s0).read_zipper();
  let v467_27_origin = v467_27_cursor.path().len();
  for v467_27_byte in v467_27_cursor.child_mask().iter() {
    v467_27_cursor.descend_to_existing_byte(v467_27_byte);
    {
    let v468_2: Space = singleton(&v467_27_cursor.path()[v467_27_origin..(v467_27_origin + 1)]);
    let v468_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v468_2));
    let v468_4: Space = if map_kernels::has_head(&(v468_3)) { singleton(&[]) } else { Space::new() };
    drop(v468_3);
    let v468_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v468_4));
    drop(v468_4);
    let v468_8: Space = if (&(v468_5)).is_empty() { Space::new() } else {
      let v469_6: Path = concat_path(&(*p0),&v467_27_cursor.path()[v467_27_origin..(v467_27_origin + 1)]);
      let mut v469_7 = Space::new();
      let mut v469_7_write = v469_7.write_zipper();
      for v469_7_byte in v467_27_cursor.child_mask().iter() {
        v467_27_cursor.descend_to_existing_byte(v469_7_byte);
        {
        let v470_2: Space = singleton(&v467_27_cursor.path()[(v467_27_origin + 1)..(v467_27_origin + 2)]);
        let v470_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v470_2));
        let v470_4: Space = if map_kernels::has_head(&(v470_3)) { singleton(&[]) } else { Space::new() };
        drop(v470_3);
        let v470_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v470_4));
        drop(v470_4);
        let v470_8: Space = if (&(v470_5)).is_empty() { Space::new() } else {
          let v471_6: Path = concat_path(&(v469_6),&v467_27_cursor.path()[(v467_27_origin + 1)..(v467_27_origin + 2)]);
          let mut v471_7 = Space::new();
          let mut v471_7_write = v471_7.write_zipper();
          for v471_7_byte in v467_27_cursor.child_mask().iter() {
            v467_27_cursor.descend_to_existing_byte(v471_7_byte);
            {
            let v472_2: Space = singleton(&v467_27_cursor.path()[(v467_27_origin + 2)..(v467_27_origin + 3)]);
            let v472_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v472_2));
            let v472_4: Space = if map_kernels::has_head(&(v472_3)) { singleton(&[]) } else { Space::new() };
            drop(v472_3);
            let v472_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v472_4));
            drop(v472_4);
            let v472_8: Space = if (&(v472_5)).is_empty() { Space::new() } else {
              let v473_6: Path = concat_path(&(v471_6),&v467_27_cursor.path()[(v467_27_origin + 2)..(v467_27_origin + 3)]);
              let v473_7: Space = routine_47(c, &(v473_6), &v467_27_cursor, &(*s1));
              map_map_kernels::compose(&(v472_5),&(v473_7))
            };
            drop(v472_5);
            let v472_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v472_2));
            drop(v472_2);
            let v472_10: Space = if map_kernels::has_head(&(v472_9)) { singleton(&[]) } else { Space::new() };
            drop(v472_9);
            let v472_12: Space = if (&(v472_10)).is_empty() { Space::new() } else {
              let v474_6: Path = concat_path(&(v471_6),&v467_27_cursor.path()[(v467_27_origin + 2)..(v467_27_origin + 3)]);
              let v474_11: Space = routine_48(c, &(v474_6), &v467_27_cursor, &(*s1));
              drop(v474_6);
              map_map_kernels::compose(&(v472_10),&(v474_11))
            };
            drop(v472_10);
            let v472_13: Space = map_map_kernels::unite(&(v472_8),&(v472_12));
            join_wrapped_into(&mut v471_7_write,&((v472_13).read_zipper()),&[]);
            }
            v467_27_cursor.ascend(1);
          }
          drop(v471_7_write);
          map_map_kernels::compose(&(v470_5),&(v471_7))
        };
        drop(v470_5);
        let v470_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v470_2));
        drop(v470_2);
        let v470_10: Space = if map_kernels::has_head(&(v470_9)) { singleton(&[]) } else { Space::new() };
        drop(v470_9);
        let v470_12: Space = if (&(v470_10)).is_empty() { Space::new() } else {
          let v475_6: Path = concat_path(&(v469_6),&v467_27_cursor.path()[(v467_27_origin + 1)..(v467_27_origin + 2)]);
          let mut v475_11 = Space::new();
          let mut v475_11_write = v475_11.write_zipper();
          for v475_11_byte in v467_27_cursor.child_mask().iter() {
            v467_27_cursor.descend_to_existing_byte(v475_11_byte);
            {
            let v476_2: Space = singleton(&v467_27_cursor.path()[(v467_27_origin + 2)..(v467_27_origin + 3)]);
            let v476_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v476_2));
            let v476_4: Space = if map_kernels::has_head(&(v476_3)) { singleton(&[]) } else { Space::new() };
            drop(v476_3);
            let v476_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v476_4));
            drop(v476_4);
            let v476_8: Space = if (&(v476_5)).is_empty() { Space::new() } else {
              let v477_6: Path = concat_path(&(v475_6),&v467_27_cursor.path()[(v467_27_origin + 2)..(v467_27_origin + 3)]);
              let v477_7: Space = routine_47(c, &(v477_6), &v467_27_cursor, &(*s1));
              map_map_kernels::compose(&(v476_5),&(v477_7))
            };
            drop(v476_5);
            let v476_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v476_2));
            drop(v476_2);
            let v476_10: Space = if map_kernels::has_head(&(v476_9)) { singleton(&[]) } else { Space::new() };
            drop(v476_9);
            let v476_12: Space = if (&(v476_10)).is_empty() { Space::new() } else {
              let v478_6: Path = concat_path(&(v475_6),&v467_27_cursor.path()[(v467_27_origin + 2)..(v467_27_origin + 3)]);
              let v478_11: Space = routine_44(c, &(v478_6), &v467_27_cursor, &(*s1));
              drop(v478_6);
              map_map_kernels::compose(&(v476_10),&(v478_11))
            };
            drop(v476_10);
            let v476_13: Space = map_map_kernels::unite(&(v476_8),&(v476_12));
            join_wrapped_into(&mut v475_11_write,&((v476_13).read_zipper()),&[]);
            }
            v467_27_cursor.ascend(1);
          }
          drop(v475_11_write);
          drop(v475_6);
          map_map_kernels::compose(&(v470_10),&(v475_11))
        };
        drop(v470_10);
        let v470_13: Space = map_map_kernels::unite(&(v470_8),&(v470_12));
        join_wrapped_into(&mut v469_7_write,&((v470_13).read_zipper()),&[]);
        }
        v467_27_cursor.ascend(1);
      }
      drop(v469_7_write);
      map_map_kernels::compose(&(v468_5),&(v469_7))
    };
    drop(v468_5);
    let v468_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v468_2));
    drop(v468_2);
    let v468_10: Space = if map_kernels::has_head(&(v468_9)) { singleton(&[]) } else { Space::new() };
    drop(v468_9);
    let v468_13: Space = if (&(v468_10)).is_empty() { Space::new() } else {
      let v479_6: Path = concat_path(&(*p0),&v467_27_cursor.path()[v467_27_origin..(v467_27_origin + 1)]);
      let mut v479_12 = Space::new();
      let mut v479_12_write = v479_12.write_zipper();
      for v479_12_byte in v467_27_cursor.child_mask().iter() {
        v467_27_cursor.descend_to_existing_byte(v479_12_byte);
        {
        let v480_2: Space = singleton(&v467_27_cursor.path()[(v467_27_origin + 1)..(v467_27_origin + 2)]);
        let v480_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v480_2));
        let v480_4: Space = if map_kernels::has_head(&(v480_3)) { singleton(&[]) } else { Space::new() };
        drop(v480_3);
        let v480_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v480_4));
        drop(v480_4);
        let v480_8: Space = if (&(v480_5)).is_empty() { Space::new() } else {
          let v481_6: Path = concat_path(&(v479_6),&v467_27_cursor.path()[(v467_27_origin + 1)..(v467_27_origin + 2)]);
          let mut v481_7 = Space::new();
          let mut v481_7_write = v481_7.write_zipper();
          for v481_7_byte in v467_27_cursor.child_mask().iter() {
            v467_27_cursor.descend_to_existing_byte(v481_7_byte);
            {
            let v482_2: Space = singleton(&v467_27_cursor.path()[(v467_27_origin + 2)..(v467_27_origin + 3)]);
            let v482_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v482_2));
            let v482_4: Space = if map_kernels::has_head(&(v482_3)) { singleton(&[]) } else { Space::new() };
            drop(v482_3);
            let v482_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v482_4));
            drop(v482_4);
            let v482_8: Space = if (&(v482_5)).is_empty() { Space::new() } else {
              let v483_6: Path = concat_path(&(v481_6),&v467_27_cursor.path()[(v467_27_origin + 2)..(v467_27_origin + 3)]);
              let v483_7: Space = routine_47(c, &(v483_6), &v467_27_cursor, &(*s1));
              map_map_kernels::compose(&(v482_5),&(v483_7))
            };
            drop(v482_5);
            let v482_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v482_2));
            drop(v482_2);
            let v482_10: Space = if map_kernels::has_head(&(v482_9)) { singleton(&[]) } else { Space::new() };
            drop(v482_9);
            let v482_12: Space = if (&(v482_10)).is_empty() { Space::new() } else {
              let v484_6: Path = concat_path(&(v481_6),&v467_27_cursor.path()[(v467_27_origin + 2)..(v467_27_origin + 3)]);
              let v484_11: Space = routine_48(c, &(v484_6), &v467_27_cursor, &(*s1));
              drop(v484_6);
              map_map_kernels::compose(&(v482_10),&(v484_11))
            };
            drop(v482_10);
            let v482_13: Space = map_map_kernels::unite(&(v482_8),&(v482_12));
            join_wrapped_into(&mut v481_7_write,&((v482_13).read_zipper()),&[]);
            }
            v467_27_cursor.ascend(1);
          }
          drop(v481_7_write);
          drop(v481_6);
          map_map_kernels::compose(&(v480_5),&(v481_7))
        };
        drop(v480_5);
        let v480_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v480_2));
        drop(v480_2);
        let v480_10: Space = if map_kernels::has_head(&(v480_9)) { singleton(&[]) } else { Space::new() };
        drop(v480_9);
        let v480_13: Space = if (&(v480_10)).is_empty() { Space::new() } else {
          let v485_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v467_27_cursor.path()[v467_27_origin..(v467_27_origin + 1)]),&v467_27_cursor.path()[(v467_27_origin + 1)..(v467_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v480_10),&(v485_12))
        };
        drop(v480_10);
        let v480_14: Space = map_map_kernels::unite(&(v480_8),&(v480_13));
        drop(v480_13);
        join_wrapped_into(&mut v479_12_write,&((v480_14).read_zipper()),&[]);
        }
        v467_27_cursor.ascend(1);
      }
      drop(v479_12_write);
      drop(v479_6);
      map_map_kernels::compose(&(v468_10),&(v479_12))
    };
    drop(v468_10);
    let v468_14: Space = map_map_kernels::unite(&(v468_8),&(v468_13));
    join_wrapped_into(&mut v467_27_write,&((v468_14).read_zipper()),&[]);
    }
    v467_27_cursor.ascend(1);
  }
  drop(v467_27_cursor);
  drop(v467_27_write);
  (v467_27).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v486_21 = Space::new();
  let mut v486_21_write = v486_21.write_zipper();
  let mut v486_21_cursor = (*s0).read_zipper();
  let v486_21_origin = v486_21_cursor.path().len();
  for v486_21_byte in v486_21_cursor.child_mask().iter() {
    v486_21_cursor.descend_to_existing_byte(v486_21_byte);
    {
    let v487_2: Space = singleton(&v486_21_cursor.path()[v486_21_origin..(v486_21_origin + 1)]);
    let v487_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v487_2));
    let v487_4: Space = if map_kernels::has_head(&(v487_3)) { singleton(&[]) } else { Space::new() };
    drop(v487_3);
    let v487_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v487_4));
    drop(v487_4);
    let v487_8: Space = if (&(v487_5)).is_empty() { Space::new() } else {
      let v488_6: Path = concat_path(&(*p0),&v486_21_cursor.path()[v486_21_origin..(v486_21_origin + 1)]);
      let mut v488_7 = Space::new();
      let mut v488_7_write = v488_7.write_zipper();
      for v488_7_byte in v486_21_cursor.child_mask().iter() {
        v486_21_cursor.descend_to_existing_byte(v488_7_byte);
        {
        let v489_2: Space = singleton(&v486_21_cursor.path()[(v486_21_origin + 1)..(v486_21_origin + 2)]);
        let v489_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v489_2));
        let v489_4: Space = if map_kernels::has_head(&(v489_3)) { singleton(&[]) } else { Space::new() };
        drop(v489_3);
        let v489_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v489_4));
        drop(v489_4);
        let v489_8: Space = if (&(v489_5)).is_empty() { Space::new() } else {
          let v490_6: Path = concat_path(&(v488_6),&v486_21_cursor.path()[(v486_21_origin + 1)..(v486_21_origin + 2)]);
          let mut v490_7 = Space::new();
          let mut v490_7_write = v490_7.write_zipper();
          for v490_7_byte in v486_21_cursor.child_mask().iter() {
            v486_21_cursor.descend_to_existing_byte(v490_7_byte);
            {
            let v491_2: Space = singleton(&v486_21_cursor.path()[(v486_21_origin + 2)..(v486_21_origin + 3)]);
            let v491_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v491_2));
            let v491_4: Space = if map_kernels::has_head(&(v491_3)) { singleton(&[]) } else { Space::new() };
            drop(v491_3);
            let v491_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v491_4));
            drop(v491_4);
            let v491_8: Space = if (&(v491_5)).is_empty() { Space::new() } else {
              let v492_6: Path = concat_path(&(v490_6),&v486_21_cursor.path()[(v486_21_origin + 2)..(v486_21_origin + 3)]);
              let v492_7: Space = routine_47(c, &(v492_6), &v486_21_cursor, &(*s1));
              map_map_kernels::compose(&(v491_5),&(v492_7))
            };
            drop(v491_5);
            let v491_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v491_2));
            drop(v491_2);
            let v491_10: Space = if map_kernels::has_head(&(v491_9)) { singleton(&[]) } else { Space::new() };
            drop(v491_9);
            let v491_12: Space = if (&(v491_10)).is_empty() { Space::new() } else {
              let v493_6: Path = concat_path(&(v490_6),&v486_21_cursor.path()[(v486_21_origin + 2)..(v486_21_origin + 3)]);
              let v493_11: Space = routine_48(c, &(v493_6), &v486_21_cursor, &(*s1));
              drop(v493_6);
              map_map_kernels::compose(&(v491_10),&(v493_11))
            };
            drop(v491_10);
            let v491_13: Space = map_map_kernels::unite(&(v491_8),&(v491_12));
            join_wrapped_into(&mut v490_7_write,&((v491_13).read_zipper()),&[]);
            }
            v486_21_cursor.ascend(1);
          }
          drop(v490_7_write);
          map_map_kernels::compose(&(v489_5),&(v490_7))
        };
        drop(v489_5);
        let v489_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v489_2));
        drop(v489_2);
        let v489_10: Space = if map_kernels::has_head(&(v489_9)) { singleton(&[]) } else { Space::new() };
        drop(v489_9);
        let v489_12: Space = if (&(v489_10)).is_empty() { Space::new() } else {
          let v494_6: Path = concat_path(&(v488_6),&v486_21_cursor.path()[(v486_21_origin + 1)..(v486_21_origin + 2)]);
          let mut v494_11 = Space::new();
          let mut v494_11_write = v494_11.write_zipper();
          for v494_11_byte in v486_21_cursor.child_mask().iter() {
            v486_21_cursor.descend_to_existing_byte(v494_11_byte);
            {
            let v495_2: Space = singleton(&v486_21_cursor.path()[(v486_21_origin + 2)..(v486_21_origin + 3)]);
            let v495_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v495_2));
            let v495_4: Space = if map_kernels::has_head(&(v495_3)) { singleton(&[]) } else { Space::new() };
            drop(v495_3);
            let v495_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v495_4));
            drop(v495_4);
            let v495_8: Space = if (&(v495_5)).is_empty() { Space::new() } else {
              let v496_6: Path = concat_path(&(v494_6),&v486_21_cursor.path()[(v486_21_origin + 2)..(v486_21_origin + 3)]);
              let v496_7: Space = routine_47(c, &(v496_6), &v486_21_cursor, &(*s1));
              map_map_kernels::compose(&(v495_5),&(v496_7))
            };
            drop(v495_5);
            let v495_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v495_2));
            drop(v495_2);
            let v495_10: Space = if map_kernels::has_head(&(v495_9)) { singleton(&[]) } else { Space::new() };
            drop(v495_9);
            let v495_12: Space = if (&(v495_10)).is_empty() { Space::new() } else {
              let v497_6: Path = concat_path(&(v494_6),&v486_21_cursor.path()[(v486_21_origin + 2)..(v486_21_origin + 3)]);
              let v497_11: Space = routine_44(c, &(v497_6), &v486_21_cursor, &(*s1));
              drop(v497_6);
              map_map_kernels::compose(&(v495_10),&(v497_11))
            };
            drop(v495_10);
            let v495_13: Space = map_map_kernels::unite(&(v495_8),&(v495_12));
            join_wrapped_into(&mut v494_11_write,&((v495_13).read_zipper()),&[]);
            }
            v486_21_cursor.ascend(1);
          }
          drop(v494_11_write);
          drop(v494_6);
          map_map_kernels::compose(&(v489_10),&(v494_11))
        };
        drop(v489_10);
        let v489_13: Space = map_map_kernels::unite(&(v489_8),&(v489_12));
        join_wrapped_into(&mut v488_7_write,&((v489_13).read_zipper()),&[]);
        }
        v486_21_cursor.ascend(1);
      }
      drop(v488_7_write);
      drop(v488_6);
      map_map_kernels::compose(&(v487_5),&(v488_7))
    };
    drop(v487_5);
    let v487_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v487_2));
    drop(v487_2);
    let v487_10: Space = if map_kernels::has_head(&(v487_9)) { singleton(&[]) } else { Space::new() };
    drop(v487_9);
    let v487_13: Space = if (&(v487_10)).is_empty() { Space::new() } else {
      let v498_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v486_21_cursor.path()[v486_21_origin..(v486_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v487_10),&(v498_12))
    };
    drop(v487_10);
    let v487_14: Space = map_map_kernels::unite(&(v487_8),&(v487_13));
    drop(v487_13);
    join_wrapped_into(&mut v486_21_write,&((v487_14).read_zipper()),&[]);
    }
    v486_21_cursor.ascend(1);
  }
  drop(v486_21_cursor);
  drop(v486_21_write);
  (v486_21).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v499_8 = Space::new();
  let mut v499_8_write = v499_8.write_zipper();
  let mut v499_8_cursor = (*s0).read_zipper();
  let v499_8_origin = v499_8_cursor.path().len();
  for v499_8_byte in v499_8_cursor.child_mask().iter() {
    v499_8_cursor.descend_to_existing_byte(v499_8_byte);
    {
    let v500_2: Space = singleton(&v499_8_cursor.path()[v499_8_origin..(v499_8_origin + 1)]);
    let v500_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v500_2));
    drop(v500_2);
    let v500_4: Space = if map_kernels::has_head(&(v500_3)) { singleton(&[]) } else { Space::new() };
    drop(v500_3);
    let v500_7: Space = if (&(v500_4)).is_empty() { Space::new() } else {
      let v501_5: Path = concat_path(&(*p0),&v499_8_cursor.path()[v499_8_origin..(v499_8_origin + 1)]);
      let mut v501_6 = Space::new();
      let mut v501_6_write = v501_6.write_zipper();
      for v501_6_byte in v499_8_cursor.child_mask().iter() {
        v499_8_cursor.descend_to_existing_byte(v501_6_byte);
        {
        let v502_2: Space = singleton(&v499_8_cursor.path()[(v499_8_origin + 1)..(v499_8_origin + 2)]);
        let v502_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v502_2));
        drop(v502_2);
        let v502_4: Space = if map_kernels::has_head(&(v502_3)) { singleton(&[]) } else { Space::new() };
        drop(v502_3);
        let v502_6: Space = if (&(v502_4)).is_empty() { Space::new() } else {
          let mut v503_5 = Space::new();
          let mut v503_5_write = v503_5.write_zipper();
          for v503_5_byte in v499_8_cursor.child_mask().iter() {
            v499_8_cursor.descend_to_existing_byte(v503_5_byte);
            {
            let v504_2: Space = singleton(&v499_8_cursor.path()[(v499_8_origin + 2)..(v499_8_origin + 3)]);
            let v504_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v504_2));
            let v504_4: Space = if map_kernels::has_head(&(v504_3)) { singleton(&[]) } else { Space::new() };
            drop(v504_3);
            let v504_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v504_4));
            drop(v504_4);
            let v504_7: Space = if (&(v504_5)).is_empty() { Space::new() } else {
              let v505_6: Space = routine_5(c, &v499_8_cursor.path()[(v499_8_origin + 2)..(v499_8_origin + 3)], &v499_8_cursor, &(*s1));
              map_map_kernels::compose(&(v504_5),&(v505_6))
            };
            drop(v504_5);
            let v504_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v504_2));
            drop(v504_2);
            let v504_9: Space = if map_kernels::has_head(&(v504_8)) { singleton(&[]) } else { Space::new() };
            drop(v504_8);
            let v504_11: Space = if (&(v504_9)).is_empty() { Space::new() } else {
              let v506_10: Space = routine_6(c, &v499_8_cursor.path()[(v499_8_origin + 2)..(v499_8_origin + 3)], &v499_8_cursor, &(*s1));
              map_map_kernels::compose(&(v504_9),&(v506_10))
            };
            drop(v504_9);
            let v504_12: Space = map_map_kernels::unite(&(v504_7),&(v504_11));
            join_wrapped_into(&mut v503_5_write,&((v504_12).read_zipper()),&[]);
            }
            v499_8_cursor.ascend(1);
          }
          drop(v503_5_write);
          map_map_kernels::compose(&(v502_4),&(v503_5))
        };
        drop(v502_4);
        let v502_7: Path = concat_path(&(v501_5),&v499_8_cursor.path()[(v499_8_origin + 1)..(v499_8_origin + 2)]);
        join_wrapped_into(&mut v501_6_write,&((v502_6).read_zipper()),&(v502_7));
        drop(v502_7);
        }
        v499_8_cursor.ascend(1);
      }
      drop(v501_6_write);
      drop(v501_5);
      map_map_kernels::compose(&(v500_4),&(v501_6))
    };
    drop(v500_4);
    join_wrapped_into(&mut v499_8_write,&((v500_7).read_zipper()),&[]);
    }
    v499_8_cursor.ascend(1);
  }
  drop(v499_8_cursor);
  drop(v499_8_write);
  (v499_8).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v507_13 = Space::new();
  let mut v507_13_write = v507_13.write_zipper();
  let mut v507_13_cursor = (*s0).read_zipper();
  let v507_13_origin = v507_13_cursor.path().len();
  for v507_13_byte in v507_13_cursor.child_mask().iter() {
    v507_13_cursor.descend_to_existing_byte(v507_13_byte);
    {
    let v508_2: Space = singleton(&v507_13_cursor.path()[v507_13_origin..(v507_13_origin + 1)]);
    let v508_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v508_2));
    drop(v508_2);
    let v508_4: Space = if map_kernels::has_head(&(v508_3)) { singleton(&[]) } else { Space::new() };
    drop(v508_3);
    let v508_6: Space = if (&(v508_4)).is_empty() { Space::new() } else {
      let mut v509_5 = Space::new();
      let mut v509_5_write = v509_5.write_zipper();
      for v509_5_byte in v507_13_cursor.child_mask().iter() {
        v507_13_cursor.descend_to_existing_byte(v509_5_byte);
        {
        let v510_2: Space = singleton(&v507_13_cursor.path()[(v507_13_origin + 1)..(v507_13_origin + 2)]);
        let v510_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v510_2));
        let v510_4: Space = if map_kernels::has_head(&(v510_3)) { singleton(&[]) } else { Space::new() };
        drop(v510_3);
        let v510_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v510_4));
        drop(v510_4);
        let v510_7: Space = if (&(v510_5)).is_empty() { Space::new() } else {
          let mut v511_6 = Space::new();
          let mut v511_6_write = v511_6.write_zipper();
          for v511_6_byte in v507_13_cursor.child_mask().iter() {
            v507_13_cursor.descend_to_existing_byte(v511_6_byte);
            {
            let v512_2: Space = singleton(&v507_13_cursor.path()[(v507_13_origin + 2)..(v507_13_origin + 3)]);
            let v512_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v512_2));
            let v512_4: Space = if map_kernels::has_head(&(v512_3)) { singleton(&[]) } else { Space::new() };
            drop(v512_3);
            let v512_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v512_4));
            drop(v512_4);
            let v512_8: Space = if (&(v512_5)).is_empty() { Space::new() } else {
              let v513_7: Space = routine_22(c, &v507_13_cursor.path()[(v507_13_origin + 1)..(v507_13_origin + 3)], &v507_13_cursor, &(*s1));
              map_map_kernels::compose(&(v512_5),&(v513_7))
            };
            drop(v512_5);
            let v512_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v512_2));
            drop(v512_2);
            let v512_10: Space = if map_kernels::has_head(&(v512_9)) { singleton(&[]) } else { Space::new() };
            drop(v512_9);
            let v512_12: Space = if (&(v512_10)).is_empty() { Space::new() } else {
              let v514_11: Space = routine_23(c, &v507_13_cursor.path()[(v507_13_origin + 1)..(v507_13_origin + 3)], &v507_13_cursor, &(*s1));
              map_map_kernels::compose(&(v512_10),&(v514_11))
            };
            drop(v512_10);
            let v512_13: Space = map_map_kernels::unite(&(v512_8),&(v512_12));
            join_wrapped_into(&mut v511_6_write,&((v512_13).read_zipper()),&[]);
            }
            v507_13_cursor.ascend(1);
          }
          drop(v511_6_write);
          map_map_kernels::compose(&(v510_5),&(v511_6))
        };
        drop(v510_5);
        let v510_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v510_2));
        drop(v510_2);
        let v510_9: Space = if map_kernels::has_head(&(v510_8)) { singleton(&[]) } else { Space::new() };
        drop(v510_8);
        let v510_11: Space = if (&(v510_9)).is_empty() { Space::new() } else {
          let mut v515_10 = Space::new();
          let mut v515_10_write = v515_10.write_zipper();
          for v515_10_byte in v507_13_cursor.child_mask().iter() {
            v507_13_cursor.descend_to_existing_byte(v515_10_byte);
            {
            let v516_2: Space = singleton(&v507_13_cursor.path()[(v507_13_origin + 2)..(v507_13_origin + 3)]);
            let v516_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v516_2));
            let v516_4: Space = if map_kernels::has_head(&(v516_3)) { singleton(&[]) } else { Space::new() };
            drop(v516_3);
            let v516_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v516_4));
            drop(v516_4);
            let v516_8: Space = if (&(v516_5)).is_empty() { Space::new() } else {
              let v517_7: Space = routine_22(c, &v507_13_cursor.path()[(v507_13_origin + 1)..(v507_13_origin + 3)], &v507_13_cursor, &(*s1));
              map_map_kernels::compose(&(v516_5),&(v517_7))
            };
            drop(v516_5);
            let v516_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v516_2));
            drop(v516_2);
            let v516_10: Space = if map_kernels::has_head(&(v516_9)) { singleton(&[]) } else { Space::new() };
            drop(v516_9);
            let v516_12: Space = if (&(v516_10)).is_empty() { Space::new() } else {
              let v518_11: Space = routine_24(c, &v507_13_cursor.path()[(v507_13_origin + 1)..(v507_13_origin + 3)], &v507_13_cursor, &(*s1));
              map_map_kernels::compose(&(v516_10),&(v518_11))
            };
            drop(v516_10);
            let v516_13: Space = map_map_kernels::unite(&(v516_8),&(v516_12));
            join_wrapped_into(&mut v515_10_write,&((v516_13).read_zipper()),&[]);
            }
            v507_13_cursor.ascend(1);
          }
          drop(v515_10_write);
          map_map_kernels::compose(&(v510_9),&(v515_10))
        };
        drop(v510_9);
        let v510_12: Space = map_map_kernels::unite(&(v510_7),&(v510_11));
        join_wrapped_into(&mut v509_5_write,&((v510_12).read_zipper()),&[]);
        }
        v507_13_cursor.ascend(1);
      }
      drop(v509_5_write);
      map_map_kernels::compose(&(v508_4),&(v509_5))
    };
    drop(v508_4);
    let v508_7: Path = concat_path(&(*p0),&v507_13_cursor.path()[v507_13_origin..(v507_13_origin + 1)]);
    join_wrapped_into(&mut v507_13_write,&((v508_6).read_zipper()),&(v508_7));
    drop(v508_7);
    }
    v507_13_cursor.ascend(1);
  }
  drop(v507_13_cursor);
  drop(v507_13_write);
  (v507_13).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v519_27 = Space::new();
  let mut v519_27_write = v519_27.write_zipper();
  let mut v519_27_cursor = (*s0).read_zipper();
  let v519_27_origin = v519_27_cursor.path().len();
  for v519_27_byte in v519_27_cursor.child_mask().iter() {
    v519_27_cursor.descend_to_existing_byte(v519_27_byte);
    {
    let v520_2: Space = singleton(&v519_27_cursor.path()[v519_27_origin..(v519_27_origin + 1)]);
    let v520_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v520_2));
    let v520_4: Space = if map_kernels::has_head(&(v520_3)) { singleton(&[]) } else { Space::new() };
    drop(v520_3);
    let v520_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v520_4));
    drop(v520_4);
    let v520_8: Space = if (&(v520_5)).is_empty() { Space::new() } else {
      let v521_6: Path = concat_path(&(*p0),&v519_27_cursor.path()[v519_27_origin..(v519_27_origin + 1)]);
      let mut v521_7 = Space::new();
      let mut v521_7_write = v521_7.write_zipper();
      for v521_7_byte in v519_27_cursor.child_mask().iter() {
        v519_27_cursor.descend_to_existing_byte(v521_7_byte);
        {
        let v522_2: Space = singleton(&v519_27_cursor.path()[(v519_27_origin + 1)..(v519_27_origin + 2)]);
        let v522_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v522_2));
        let v522_4: Space = if map_kernels::has_head(&(v522_3)) { singleton(&[]) } else { Space::new() };
        drop(v522_3);
        let v522_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v522_4));
        drop(v522_4);
        let v522_8: Space = if (&(v522_5)).is_empty() { Space::new() } else {
          let v523_6: Path = concat_path(&(v521_6),&v519_27_cursor.path()[(v519_27_origin + 1)..(v519_27_origin + 2)]);
          let mut v523_7 = Space::new();
          let mut v523_7_write = v523_7.write_zipper();
          for v523_7_byte in v519_27_cursor.child_mask().iter() {
            v519_27_cursor.descend_to_existing_byte(v523_7_byte);
            {
            let v524_2: Space = singleton(&v519_27_cursor.path()[(v519_27_origin + 2)..(v519_27_origin + 3)]);
            let v524_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v524_2));
            let v524_4: Space = if map_kernels::has_head(&(v524_3)) { singleton(&[]) } else { Space::new() };
            drop(v524_3);
            let v524_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v524_4));
            drop(v524_4);
            let v524_8: Space = if (&(v524_5)).is_empty() { Space::new() } else {
              let v525_6: Path = concat_path(&(v523_6),&v519_27_cursor.path()[(v519_27_origin + 2)..(v519_27_origin + 3)]);
              let v525_7: Space = routine_49(c, &(v525_6), &v519_27_cursor, &(*s1));
              map_map_kernels::compose(&(v524_5),&(v525_7))
            };
            drop(v524_5);
            let v524_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v524_2));
            drop(v524_2);
            let v524_10: Space = if map_kernels::has_head(&(v524_9)) { singleton(&[]) } else { Space::new() };
            drop(v524_9);
            let v524_12: Space = if (&(v524_10)).is_empty() { Space::new() } else {
              let v526_6: Path = concat_path(&(v523_6),&v519_27_cursor.path()[(v519_27_origin + 2)..(v519_27_origin + 3)]);
              let v526_11: Space = routine_50(c, &(v526_6), &v519_27_cursor, &(*s1));
              drop(v526_6);
              map_map_kernels::compose(&(v524_10),&(v526_11))
            };
            drop(v524_10);
            let v524_13: Space = map_map_kernels::unite(&(v524_8),&(v524_12));
            join_wrapped_into(&mut v523_7_write,&((v524_13).read_zipper()),&[]);
            }
            v519_27_cursor.ascend(1);
          }
          drop(v523_7_write);
          map_map_kernels::compose(&(v522_5),&(v523_7))
        };
        drop(v522_5);
        let v522_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v522_2));
        drop(v522_2);
        let v522_10: Space = if map_kernels::has_head(&(v522_9)) { singleton(&[]) } else { Space::new() };
        drop(v522_9);
        let v522_12: Space = if (&(v522_10)).is_empty() { Space::new() } else {
          let v527_6: Path = concat_path(&(v521_6),&v519_27_cursor.path()[(v519_27_origin + 1)..(v519_27_origin + 2)]);
          let mut v527_11 = Space::new();
          let mut v527_11_write = v527_11.write_zipper();
          for v527_11_byte in v519_27_cursor.child_mask().iter() {
            v519_27_cursor.descend_to_existing_byte(v527_11_byte);
            {
            let v528_2: Space = singleton(&v519_27_cursor.path()[(v519_27_origin + 2)..(v519_27_origin + 3)]);
            let v528_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v528_2));
            let v528_4: Space = if map_kernels::has_head(&(v528_3)) { singleton(&[]) } else { Space::new() };
            drop(v528_3);
            let v528_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v528_4));
            drop(v528_4);
            let v528_8: Space = if (&(v528_5)).is_empty() { Space::new() } else {
              let v529_6: Path = concat_path(&(v527_6),&v519_27_cursor.path()[(v519_27_origin + 2)..(v519_27_origin + 3)]);
              let v529_7: Space = routine_49(c, &(v529_6), &v519_27_cursor, &(*s1));
              map_map_kernels::compose(&(v528_5),&(v529_7))
            };
            drop(v528_5);
            let v528_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v528_2));
            drop(v528_2);
            let v528_10: Space = if map_kernels::has_head(&(v528_9)) { singleton(&[]) } else { Space::new() };
            drop(v528_9);
            let v528_12: Space = if (&(v528_10)).is_empty() { Space::new() } else {
              let v530_6: Path = concat_path(&(v527_6),&v519_27_cursor.path()[(v519_27_origin + 2)..(v519_27_origin + 3)]);
              let v530_11: Space = routine_24(c, &(v530_6), &v519_27_cursor, &(*s1));
              drop(v530_6);
              map_map_kernels::compose(&(v528_10),&(v530_11))
            };
            drop(v528_10);
            let v528_13: Space = map_map_kernels::unite(&(v528_8),&(v528_12));
            join_wrapped_into(&mut v527_11_write,&((v528_13).read_zipper()),&[]);
            }
            v519_27_cursor.ascend(1);
          }
          drop(v527_11_write);
          drop(v527_6);
          map_map_kernels::compose(&(v522_10),&(v527_11))
        };
        drop(v522_10);
        let v522_13: Space = map_map_kernels::unite(&(v522_8),&(v522_12));
        join_wrapped_into(&mut v521_7_write,&((v522_13).read_zipper()),&[]);
        }
        v519_27_cursor.ascend(1);
      }
      drop(v521_7_write);
      map_map_kernels::compose(&(v520_5),&(v521_7))
    };
    drop(v520_5);
    let v520_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v520_2));
    drop(v520_2);
    let v520_10: Space = if map_kernels::has_head(&(v520_9)) { singleton(&[]) } else { Space::new() };
    drop(v520_9);
    let v520_13: Space = if (&(v520_10)).is_empty() { Space::new() } else {
      let v531_6: Path = concat_path(&(*p0),&v519_27_cursor.path()[v519_27_origin..(v519_27_origin + 1)]);
      let mut v531_12 = Space::new();
      let mut v531_12_write = v531_12.write_zipper();
      for v531_12_byte in v519_27_cursor.child_mask().iter() {
        v519_27_cursor.descend_to_existing_byte(v531_12_byte);
        {
        let v532_2: Space = singleton(&v519_27_cursor.path()[(v519_27_origin + 1)..(v519_27_origin + 2)]);
        let v532_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v532_2));
        let v532_4: Space = if map_kernels::has_head(&(v532_3)) { singleton(&[]) } else { Space::new() };
        drop(v532_3);
        let v532_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v532_4));
        drop(v532_4);
        let v532_8: Space = if (&(v532_5)).is_empty() { Space::new() } else {
          let v533_6: Path = concat_path(&(v531_6),&v519_27_cursor.path()[(v519_27_origin + 1)..(v519_27_origin + 2)]);
          let mut v533_7 = Space::new();
          let mut v533_7_write = v533_7.write_zipper();
          for v533_7_byte in v519_27_cursor.child_mask().iter() {
            v519_27_cursor.descend_to_existing_byte(v533_7_byte);
            {
            let v534_2: Space = singleton(&v519_27_cursor.path()[(v519_27_origin + 2)..(v519_27_origin + 3)]);
            let v534_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v534_2));
            let v534_4: Space = if map_kernels::has_head(&(v534_3)) { singleton(&[]) } else { Space::new() };
            drop(v534_3);
            let v534_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v534_4));
            drop(v534_4);
            let v534_8: Space = if (&(v534_5)).is_empty() { Space::new() } else {
              let v535_6: Path = concat_path(&(v533_6),&v519_27_cursor.path()[(v519_27_origin + 2)..(v519_27_origin + 3)]);
              let v535_7: Space = routine_49(c, &(v535_6), &v519_27_cursor, &(*s1));
              map_map_kernels::compose(&(v534_5),&(v535_7))
            };
            drop(v534_5);
            let v534_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v534_2));
            drop(v534_2);
            let v534_10: Space = if map_kernels::has_head(&(v534_9)) { singleton(&[]) } else { Space::new() };
            drop(v534_9);
            let v534_12: Space = if (&(v534_10)).is_empty() { Space::new() } else {
              let v536_6: Path = concat_path(&(v533_6),&v519_27_cursor.path()[(v519_27_origin + 2)..(v519_27_origin + 3)]);
              let v536_11: Space = routine_50(c, &(v536_6), &v519_27_cursor, &(*s1));
              drop(v536_6);
              map_map_kernels::compose(&(v534_10),&(v536_11))
            };
            drop(v534_10);
            let v534_13: Space = map_map_kernels::unite(&(v534_8),&(v534_12));
            join_wrapped_into(&mut v533_7_write,&((v534_13).read_zipper()),&[]);
            }
            v519_27_cursor.ascend(1);
          }
          drop(v533_7_write);
          drop(v533_6);
          map_map_kernels::compose(&(v532_5),&(v533_7))
        };
        drop(v532_5);
        let v532_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v532_2));
        drop(v532_2);
        let v532_10: Space = if map_kernels::has_head(&(v532_9)) { singleton(&[]) } else { Space::new() };
        drop(v532_9);
        let v532_13: Space = if (&(v532_10)).is_empty() { Space::new() } else {
          let v537_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v519_27_cursor.path()[v519_27_origin..(v519_27_origin + 1)]),&v519_27_cursor.path()[(v519_27_origin + 1)..(v519_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v532_10),&(v537_12))
        };
        drop(v532_10);
        let v532_14: Space = map_map_kernels::unite(&(v532_8),&(v532_13));
        drop(v532_13);
        join_wrapped_into(&mut v531_12_write,&((v532_14).read_zipper()),&[]);
        }
        v519_27_cursor.ascend(1);
      }
      drop(v531_12_write);
      drop(v531_6);
      map_map_kernels::compose(&(v520_10),&(v531_12))
    };
    drop(v520_10);
    let v520_14: Space = map_map_kernels::unite(&(v520_8),&(v520_13));
    join_wrapped_into(&mut v519_27_write,&((v520_14).read_zipper()),&[]);
    }
    v519_27_cursor.ascend(1);
  }
  drop(v519_27_cursor);
  drop(v519_27_write);
  (v519_27).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v538_21 = Space::new();
  let mut v538_21_write = v538_21.write_zipper();
  let mut v538_21_cursor = (*s0).read_zipper();
  let v538_21_origin = v538_21_cursor.path().len();
  for v538_21_byte in v538_21_cursor.child_mask().iter() {
    v538_21_cursor.descend_to_existing_byte(v538_21_byte);
    {
    let v539_2: Space = singleton(&v538_21_cursor.path()[v538_21_origin..(v538_21_origin + 1)]);
    let v539_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v539_2));
    let v539_4: Space = if map_kernels::has_head(&(v539_3)) { singleton(&[]) } else { Space::new() };
    drop(v539_3);
    let v539_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v539_4));
    drop(v539_4);
    let v539_8: Space = if (&(v539_5)).is_empty() { Space::new() } else {
      let v540_6: Path = concat_path(&(*p0),&v538_21_cursor.path()[v538_21_origin..(v538_21_origin + 1)]);
      let mut v540_7 = Space::new();
      let mut v540_7_write = v540_7.write_zipper();
      for v540_7_byte in v538_21_cursor.child_mask().iter() {
        v538_21_cursor.descend_to_existing_byte(v540_7_byte);
        {
        let v541_2: Space = singleton(&v538_21_cursor.path()[(v538_21_origin + 1)..(v538_21_origin + 2)]);
        let v541_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v541_2));
        let v541_4: Space = if map_kernels::has_head(&(v541_3)) { singleton(&[]) } else { Space::new() };
        drop(v541_3);
        let v541_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v541_4));
        drop(v541_4);
        let v541_8: Space = if (&(v541_5)).is_empty() { Space::new() } else {
          let v542_6: Path = concat_path(&(v540_6),&v538_21_cursor.path()[(v538_21_origin + 1)..(v538_21_origin + 2)]);
          let mut v542_7 = Space::new();
          let mut v542_7_write = v542_7.write_zipper();
          for v542_7_byte in v538_21_cursor.child_mask().iter() {
            v538_21_cursor.descend_to_existing_byte(v542_7_byte);
            {
            let v543_2: Space = singleton(&v538_21_cursor.path()[(v538_21_origin + 2)..(v538_21_origin + 3)]);
            let v543_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v543_2));
            let v543_4: Space = if map_kernels::has_head(&(v543_3)) { singleton(&[]) } else { Space::new() };
            drop(v543_3);
            let v543_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v543_4));
            drop(v543_4);
            let v543_8: Space = if (&(v543_5)).is_empty() { Space::new() } else {
              let v544_6: Path = concat_path(&(v542_6),&v538_21_cursor.path()[(v538_21_origin + 2)..(v538_21_origin + 3)]);
              let v544_7: Space = routine_49(c, &(v544_6), &v538_21_cursor, &(*s1));
              map_map_kernels::compose(&(v543_5),&(v544_7))
            };
            drop(v543_5);
            let v543_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v543_2));
            drop(v543_2);
            let v543_10: Space = if map_kernels::has_head(&(v543_9)) { singleton(&[]) } else { Space::new() };
            drop(v543_9);
            let v543_12: Space = if (&(v543_10)).is_empty() { Space::new() } else {
              let v545_6: Path = concat_path(&(v542_6),&v538_21_cursor.path()[(v538_21_origin + 2)..(v538_21_origin + 3)]);
              let v545_11: Space = routine_50(c, &(v545_6), &v538_21_cursor, &(*s1));
              drop(v545_6);
              map_map_kernels::compose(&(v543_10),&(v545_11))
            };
            drop(v543_10);
            let v543_13: Space = map_map_kernels::unite(&(v543_8),&(v543_12));
            join_wrapped_into(&mut v542_7_write,&((v543_13).read_zipper()),&[]);
            }
            v538_21_cursor.ascend(1);
          }
          drop(v542_7_write);
          map_map_kernels::compose(&(v541_5),&(v542_7))
        };
        drop(v541_5);
        let v541_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v541_2));
        drop(v541_2);
        let v541_10: Space = if map_kernels::has_head(&(v541_9)) { singleton(&[]) } else { Space::new() };
        drop(v541_9);
        let v541_12: Space = if (&(v541_10)).is_empty() { Space::new() } else {
          let v546_6: Path = concat_path(&(v540_6),&v538_21_cursor.path()[(v538_21_origin + 1)..(v538_21_origin + 2)]);
          let mut v546_11 = Space::new();
          let mut v546_11_write = v546_11.write_zipper();
          for v546_11_byte in v538_21_cursor.child_mask().iter() {
            v538_21_cursor.descend_to_existing_byte(v546_11_byte);
            {
            let v547_2: Space = singleton(&v538_21_cursor.path()[(v538_21_origin + 2)..(v538_21_origin + 3)]);
            let v547_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v547_2));
            let v547_4: Space = if map_kernels::has_head(&(v547_3)) { singleton(&[]) } else { Space::new() };
            drop(v547_3);
            let v547_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v547_4));
            drop(v547_4);
            let v547_8: Space = if (&(v547_5)).is_empty() { Space::new() } else {
              let v548_6: Path = concat_path(&(v546_6),&v538_21_cursor.path()[(v538_21_origin + 2)..(v538_21_origin + 3)]);
              let v548_7: Space = routine_49(c, &(v548_6), &v538_21_cursor, &(*s1));
              map_map_kernels::compose(&(v547_5),&(v548_7))
            };
            drop(v547_5);
            let v547_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v547_2));
            drop(v547_2);
            let v547_10: Space = if map_kernels::has_head(&(v547_9)) { singleton(&[]) } else { Space::new() };
            drop(v547_9);
            let v547_12: Space = if (&(v547_10)).is_empty() { Space::new() } else {
              let v549_6: Path = concat_path(&(v546_6),&v538_21_cursor.path()[(v538_21_origin + 2)..(v538_21_origin + 3)]);
              let v549_11: Space = routine_24(c, &(v549_6), &v538_21_cursor, &(*s1));
              drop(v549_6);
              map_map_kernels::compose(&(v547_10),&(v549_11))
            };
            drop(v547_10);
            let v547_13: Space = map_map_kernels::unite(&(v547_8),&(v547_12));
            join_wrapped_into(&mut v546_11_write,&((v547_13).read_zipper()),&[]);
            }
            v538_21_cursor.ascend(1);
          }
          drop(v546_11_write);
          drop(v546_6);
          map_map_kernels::compose(&(v541_10),&(v546_11))
        };
        drop(v541_10);
        let v541_13: Space = map_map_kernels::unite(&(v541_8),&(v541_12));
        join_wrapped_into(&mut v540_7_write,&((v541_13).read_zipper()),&[]);
        }
        v538_21_cursor.ascend(1);
      }
      drop(v540_7_write);
      drop(v540_6);
      map_map_kernels::compose(&(v539_5),&(v540_7))
    };
    drop(v539_5);
    let v539_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v539_2));
    drop(v539_2);
    let v539_10: Space = if map_kernels::has_head(&(v539_9)) { singleton(&[]) } else { Space::new() };
    drop(v539_9);
    let v539_13: Space = if (&(v539_10)).is_empty() { Space::new() } else {
      let v550_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v538_21_cursor.path()[v538_21_origin..(v538_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v539_10),&(v550_12))
    };
    drop(v539_10);
    let v539_14: Space = map_map_kernels::unite(&(v539_8),&(v539_13));
    drop(v539_13);
    join_wrapped_into(&mut v538_21_write,&((v539_14).read_zipper()),&[]);
    }
    v538_21_cursor.ascend(1);
  }
  drop(v538_21_cursor);
  drop(v538_21_write);
  (v538_21).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v551_9: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0))),&(*CONSTANT_5));
  (v551_9).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v552_27 = Space::new();
  let mut v552_27_write = v552_27.write_zipper();
  let mut v552_27_cursor = (*s0).read_zipper();
  let v552_27_origin = v552_27_cursor.path().len();
  for v552_27_byte in v552_27_cursor.child_mask().iter() {
    v552_27_cursor.descend_to_existing_byte(v552_27_byte);
    {
    let v553_2: Space = singleton(&v552_27_cursor.path()[v552_27_origin..(v552_27_origin + 1)]);
    let v553_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v553_2));
    let v553_4: Space = if map_kernels::has_head(&(v553_3)) { singleton(&[]) } else { Space::new() };
    drop(v553_3);
    let v553_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v553_4));
    drop(v553_4);
    let v553_8: Space = if (&(v553_5)).is_empty() { Space::new() } else {
      let v554_6: Path = concat_path(&(*p0),&v552_27_cursor.path()[v552_27_origin..(v552_27_origin + 1)]);
      let mut v554_7 = Space::new();
      let mut v554_7_write = v554_7.write_zipper();
      for v554_7_byte in v552_27_cursor.child_mask().iter() {
        v552_27_cursor.descend_to_existing_byte(v554_7_byte);
        {
        let v555_2: Space = singleton(&v552_27_cursor.path()[(v552_27_origin + 1)..(v552_27_origin + 2)]);
        let v555_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v555_2));
        let v555_4: Space = if map_kernels::has_head(&(v555_3)) { singleton(&[]) } else { Space::new() };
        drop(v555_3);
        let v555_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v555_4));
        drop(v555_4);
        let v555_8: Space = if (&(v555_5)).is_empty() { Space::new() } else {
          let v556_6: Path = concat_path(&(v554_6),&v552_27_cursor.path()[(v552_27_origin + 1)..(v552_27_origin + 2)]);
          let mut v556_7 = Space::new();
          let mut v556_7_write = v556_7.write_zipper();
          for v556_7_byte in v552_27_cursor.child_mask().iter() {
            v552_27_cursor.descend_to_existing_byte(v556_7_byte);
            {
            let v557_2: Space = singleton(&v552_27_cursor.path()[(v552_27_origin + 2)..(v552_27_origin + 3)]);
            let v557_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v557_2));
            let v557_4: Space = if map_kernels::has_head(&(v557_3)) { singleton(&[]) } else { Space::new() };
            drop(v557_3);
            let v557_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v557_4));
            drop(v557_4);
            let v557_8: Space = if (&(v557_5)).is_empty() { Space::new() } else {
              let v558_6: Path = concat_path(&(v556_6),&v552_27_cursor.path()[(v552_27_origin + 2)..(v552_27_origin + 3)]);
              let v558_7: Space = routine_51(c, &(v558_6), &v552_27_cursor, &(*s1));
              map_map_kernels::compose(&(v557_5),&(v558_7))
            };
            drop(v557_5);
            let v557_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v557_2));
            drop(v557_2);
            let v557_10: Space = if map_kernels::has_head(&(v557_9)) { singleton(&[]) } else { Space::new() };
            drop(v557_9);
            let v557_12: Space = if (&(v557_10)).is_empty() { Space::new() } else {
              let v559_6: Path = concat_path(&(v556_6),&v552_27_cursor.path()[(v552_27_origin + 2)..(v552_27_origin + 3)]);
              let v559_11: Space = routine_52(c, &(v559_6), &v552_27_cursor, &(*s1));
              drop(v559_6);
              map_map_kernels::compose(&(v557_10),&(v559_11))
            };
            drop(v557_10);
            let v557_13: Space = map_map_kernels::unite(&(v557_8),&(v557_12));
            join_wrapped_into(&mut v556_7_write,&((v557_13).read_zipper()),&[]);
            }
            v552_27_cursor.ascend(1);
          }
          drop(v556_7_write);
          map_map_kernels::compose(&(v555_5),&(v556_7))
        };
        drop(v555_5);
        let v555_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v555_2));
        drop(v555_2);
        let v555_10: Space = if map_kernels::has_head(&(v555_9)) { singleton(&[]) } else { Space::new() };
        drop(v555_9);
        let v555_12: Space = if (&(v555_10)).is_empty() { Space::new() } else {
          let v560_6: Path = concat_path(&(v554_6),&v552_27_cursor.path()[(v552_27_origin + 1)..(v552_27_origin + 2)]);
          let mut v560_11 = Space::new();
          let mut v560_11_write = v560_11.write_zipper();
          for v560_11_byte in v552_27_cursor.child_mask().iter() {
            v552_27_cursor.descend_to_existing_byte(v560_11_byte);
            {
            let v561_2: Space = singleton(&v552_27_cursor.path()[(v552_27_origin + 2)..(v552_27_origin + 3)]);
            let v561_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v561_2));
            let v561_4: Space = if map_kernels::has_head(&(v561_3)) { singleton(&[]) } else { Space::new() };
            drop(v561_3);
            let v561_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v561_4));
            drop(v561_4);
            let v561_8: Space = if (&(v561_5)).is_empty() { Space::new() } else {
              let v562_6: Path = concat_path(&(v560_6),&v552_27_cursor.path()[(v552_27_origin + 2)..(v552_27_origin + 3)]);
              let v562_7: Space = routine_51(c, &(v562_6), &v552_27_cursor, &(*s1));
              map_map_kernels::compose(&(v561_5),&(v562_7))
            };
            drop(v561_5);
            let v561_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v561_2));
            drop(v561_2);
            let v561_10: Space = if map_kernels::has_head(&(v561_9)) { singleton(&[]) } else { Space::new() };
            drop(v561_9);
            let v561_12: Space = if (&(v561_10)).is_empty() { Space::new() } else {
              let v563_6: Path = concat_path(&(v560_6),&v552_27_cursor.path()[(v552_27_origin + 2)..(v552_27_origin + 3)]);
              let v563_11: Space = routine_24(c, &(v563_6), &v552_27_cursor, &(*s1));
              drop(v563_6);
              map_map_kernels::compose(&(v561_10),&(v563_11))
            };
            drop(v561_10);
            let v561_13: Space = map_map_kernels::unite(&(v561_8),&(v561_12));
            join_wrapped_into(&mut v560_11_write,&((v561_13).read_zipper()),&[]);
            }
            v552_27_cursor.ascend(1);
          }
          drop(v560_11_write);
          drop(v560_6);
          map_map_kernels::compose(&(v555_10),&(v560_11))
        };
        drop(v555_10);
        let v555_13: Space = map_map_kernels::unite(&(v555_8),&(v555_12));
        join_wrapped_into(&mut v554_7_write,&((v555_13).read_zipper()),&[]);
        }
        v552_27_cursor.ascend(1);
      }
      drop(v554_7_write);
      map_map_kernels::compose(&(v553_5),&(v554_7))
    };
    drop(v553_5);
    let v553_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v553_2));
    drop(v553_2);
    let v553_10: Space = if map_kernels::has_head(&(v553_9)) { singleton(&[]) } else { Space::new() };
    drop(v553_9);
    let v553_13: Space = if (&(v553_10)).is_empty() { Space::new() } else {
      let v564_6: Path = concat_path(&(*p0),&v552_27_cursor.path()[v552_27_origin..(v552_27_origin + 1)]);
      let mut v564_12 = Space::new();
      let mut v564_12_write = v564_12.write_zipper();
      for v564_12_byte in v552_27_cursor.child_mask().iter() {
        v552_27_cursor.descend_to_existing_byte(v564_12_byte);
        {
        let v565_2: Space = singleton(&v552_27_cursor.path()[(v552_27_origin + 1)..(v552_27_origin + 2)]);
        let v565_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v565_2));
        let v565_4: Space = if map_kernels::has_head(&(v565_3)) { singleton(&[]) } else { Space::new() };
        drop(v565_3);
        let v565_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v565_4));
        drop(v565_4);
        let v565_8: Space = if (&(v565_5)).is_empty() { Space::new() } else {
          let v566_6: Path = concat_path(&(v564_6),&v552_27_cursor.path()[(v552_27_origin + 1)..(v552_27_origin + 2)]);
          let mut v566_7 = Space::new();
          let mut v566_7_write = v566_7.write_zipper();
          for v566_7_byte in v552_27_cursor.child_mask().iter() {
            v552_27_cursor.descend_to_existing_byte(v566_7_byte);
            {
            let v567_2: Space = singleton(&v552_27_cursor.path()[(v552_27_origin + 2)..(v552_27_origin + 3)]);
            let v567_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v567_2));
            let v567_4: Space = if map_kernels::has_head(&(v567_3)) { singleton(&[]) } else { Space::new() };
            drop(v567_3);
            let v567_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v567_4));
            drop(v567_4);
            let v567_8: Space = if (&(v567_5)).is_empty() { Space::new() } else {
              let v568_6: Path = concat_path(&(v566_6),&v552_27_cursor.path()[(v552_27_origin + 2)..(v552_27_origin + 3)]);
              let v568_7: Space = routine_51(c, &(v568_6), &v552_27_cursor, &(*s1));
              map_map_kernels::compose(&(v567_5),&(v568_7))
            };
            drop(v567_5);
            let v567_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v567_2));
            drop(v567_2);
            let v567_10: Space = if map_kernels::has_head(&(v567_9)) { singleton(&[]) } else { Space::new() };
            drop(v567_9);
            let v567_12: Space = if (&(v567_10)).is_empty() { Space::new() } else {
              let v569_6: Path = concat_path(&(v566_6),&v552_27_cursor.path()[(v552_27_origin + 2)..(v552_27_origin + 3)]);
              let v569_11: Space = routine_52(c, &(v569_6), &v552_27_cursor, &(*s1));
              drop(v569_6);
              map_map_kernels::compose(&(v567_10),&(v569_11))
            };
            drop(v567_10);
            let v567_13: Space = map_map_kernels::unite(&(v567_8),&(v567_12));
            join_wrapped_into(&mut v566_7_write,&((v567_13).read_zipper()),&[]);
            }
            v552_27_cursor.ascend(1);
          }
          drop(v566_7_write);
          drop(v566_6);
          map_map_kernels::compose(&(v565_5),&(v566_7))
        };
        drop(v565_5);
        let v565_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v565_2));
        drop(v565_2);
        let v565_10: Space = if map_kernels::has_head(&(v565_9)) { singleton(&[]) } else { Space::new() };
        drop(v565_9);
        let v565_13: Space = if (&(v565_10)).is_empty() { Space::new() } else {
          let v570_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v552_27_cursor.path()[v552_27_origin..(v552_27_origin + 1)]),&v552_27_cursor.path()[(v552_27_origin + 1)..(v552_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v565_10),&(v570_12))
        };
        drop(v565_10);
        let v565_14: Space = map_map_kernels::unite(&(v565_8),&(v565_13));
        drop(v565_13);
        join_wrapped_into(&mut v564_12_write,&((v565_14).read_zipper()),&[]);
        }
        v552_27_cursor.ascend(1);
      }
      drop(v564_12_write);
      drop(v564_6);
      map_map_kernels::compose(&(v553_10),&(v564_12))
    };
    drop(v553_10);
    let v553_14: Space = map_map_kernels::unite(&(v553_8),&(v553_13));
    join_wrapped_into(&mut v552_27_write,&((v553_14).read_zipper()),&[]);
    }
    v552_27_cursor.ascend(1);
  }
  drop(v552_27_cursor);
  drop(v552_27_write);
  (v552_27).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v571_21 = Space::new();
  let mut v571_21_write = v571_21.write_zipper();
  let mut v571_21_cursor = (*s0).read_zipper();
  let v571_21_origin = v571_21_cursor.path().len();
  for v571_21_byte in v571_21_cursor.child_mask().iter() {
    v571_21_cursor.descend_to_existing_byte(v571_21_byte);
    {
    let v572_2: Space = singleton(&v571_21_cursor.path()[v571_21_origin..(v571_21_origin + 1)]);
    let v572_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v572_2));
    let v572_4: Space = if map_kernels::has_head(&(v572_3)) { singleton(&[]) } else { Space::new() };
    drop(v572_3);
    let v572_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v572_4));
    drop(v572_4);
    let v572_8: Space = if (&(v572_5)).is_empty() { Space::new() } else {
      let v573_6: Path = concat_path(&(*p0),&v571_21_cursor.path()[v571_21_origin..(v571_21_origin + 1)]);
      let mut v573_7 = Space::new();
      let mut v573_7_write = v573_7.write_zipper();
      for v573_7_byte in v571_21_cursor.child_mask().iter() {
        v571_21_cursor.descend_to_existing_byte(v573_7_byte);
        {
        let v574_2: Space = singleton(&v571_21_cursor.path()[(v571_21_origin + 1)..(v571_21_origin + 2)]);
        let v574_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v574_2));
        let v574_4: Space = if map_kernels::has_head(&(v574_3)) { singleton(&[]) } else { Space::new() };
        drop(v574_3);
        let v574_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v574_4));
        drop(v574_4);
        let v574_8: Space = if (&(v574_5)).is_empty() { Space::new() } else {
          let v575_6: Path = concat_path(&(v573_6),&v571_21_cursor.path()[(v571_21_origin + 1)..(v571_21_origin + 2)]);
          let mut v575_7 = Space::new();
          let mut v575_7_write = v575_7.write_zipper();
          for v575_7_byte in v571_21_cursor.child_mask().iter() {
            v571_21_cursor.descend_to_existing_byte(v575_7_byte);
            {
            let v576_2: Space = singleton(&v571_21_cursor.path()[(v571_21_origin + 2)..(v571_21_origin + 3)]);
            let v576_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v576_2));
            let v576_4: Space = if map_kernels::has_head(&(v576_3)) { singleton(&[]) } else { Space::new() };
            drop(v576_3);
            let v576_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v576_4));
            drop(v576_4);
            let v576_8: Space = if (&(v576_5)).is_empty() { Space::new() } else {
              let v577_6: Path = concat_path(&(v575_6),&v571_21_cursor.path()[(v571_21_origin + 2)..(v571_21_origin + 3)]);
              let v577_7: Space = routine_51(c, &(v577_6), &v571_21_cursor, &(*s1));
              map_map_kernels::compose(&(v576_5),&(v577_7))
            };
            drop(v576_5);
            let v576_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v576_2));
            drop(v576_2);
            let v576_10: Space = if map_kernels::has_head(&(v576_9)) { singleton(&[]) } else { Space::new() };
            drop(v576_9);
            let v576_12: Space = if (&(v576_10)).is_empty() { Space::new() } else {
              let v578_6: Path = concat_path(&(v575_6),&v571_21_cursor.path()[(v571_21_origin + 2)..(v571_21_origin + 3)]);
              let v578_11: Space = routine_52(c, &(v578_6), &v571_21_cursor, &(*s1));
              drop(v578_6);
              map_map_kernels::compose(&(v576_10),&(v578_11))
            };
            drop(v576_10);
            let v576_13: Space = map_map_kernels::unite(&(v576_8),&(v576_12));
            join_wrapped_into(&mut v575_7_write,&((v576_13).read_zipper()),&[]);
            }
            v571_21_cursor.ascend(1);
          }
          drop(v575_7_write);
          map_map_kernels::compose(&(v574_5),&(v575_7))
        };
        drop(v574_5);
        let v574_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v574_2));
        drop(v574_2);
        let v574_10: Space = if map_kernels::has_head(&(v574_9)) { singleton(&[]) } else { Space::new() };
        drop(v574_9);
        let v574_12: Space = if (&(v574_10)).is_empty() { Space::new() } else {
          let v579_6: Path = concat_path(&(v573_6),&v571_21_cursor.path()[(v571_21_origin + 1)..(v571_21_origin + 2)]);
          let mut v579_11 = Space::new();
          let mut v579_11_write = v579_11.write_zipper();
          for v579_11_byte in v571_21_cursor.child_mask().iter() {
            v571_21_cursor.descend_to_existing_byte(v579_11_byte);
            {
            let v580_2: Space = singleton(&v571_21_cursor.path()[(v571_21_origin + 2)..(v571_21_origin + 3)]);
            let v580_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v580_2));
            let v580_4: Space = if map_kernels::has_head(&(v580_3)) { singleton(&[]) } else { Space::new() };
            drop(v580_3);
            let v580_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v580_4));
            drop(v580_4);
            let v580_8: Space = if (&(v580_5)).is_empty() { Space::new() } else {
              let v581_6: Path = concat_path(&(v579_6),&v571_21_cursor.path()[(v571_21_origin + 2)..(v571_21_origin + 3)]);
              let v581_7: Space = routine_51(c, &(v581_6), &v571_21_cursor, &(*s1));
              map_map_kernels::compose(&(v580_5),&(v581_7))
            };
            drop(v580_5);
            let v580_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v580_2));
            drop(v580_2);
            let v580_10: Space = if map_kernels::has_head(&(v580_9)) { singleton(&[]) } else { Space::new() };
            drop(v580_9);
            let v580_12: Space = if (&(v580_10)).is_empty() { Space::new() } else {
              let v582_6: Path = concat_path(&(v579_6),&v571_21_cursor.path()[(v571_21_origin + 2)..(v571_21_origin + 3)]);
              let v582_11: Space = routine_24(c, &(v582_6), &v571_21_cursor, &(*s1));
              drop(v582_6);
              map_map_kernels::compose(&(v580_10),&(v582_11))
            };
            drop(v580_10);
            let v580_13: Space = map_map_kernels::unite(&(v580_8),&(v580_12));
            join_wrapped_into(&mut v579_11_write,&((v580_13).read_zipper()),&[]);
            }
            v571_21_cursor.ascend(1);
          }
          drop(v579_11_write);
          drop(v579_6);
          map_map_kernels::compose(&(v574_10),&(v579_11))
        };
        drop(v574_10);
        let v574_13: Space = map_map_kernels::unite(&(v574_8),&(v574_12));
        join_wrapped_into(&mut v573_7_write,&((v574_13).read_zipper()),&[]);
        }
        v571_21_cursor.ascend(1);
      }
      drop(v573_7_write);
      drop(v573_6);
      map_map_kernels::compose(&(v572_5),&(v573_7))
    };
    drop(v572_5);
    let v572_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v572_2));
    drop(v572_2);
    let v572_10: Space = if map_kernels::has_head(&(v572_9)) { singleton(&[]) } else { Space::new() };
    drop(v572_9);
    let v572_13: Space = if (&(v572_10)).is_empty() { Space::new() } else {
      let v583_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v571_21_cursor.path()[v571_21_origin..(v571_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v572_10),&(v583_12))
    };
    drop(v572_10);
    let v572_14: Space = map_map_kernels::unite(&(v572_8),&(v572_13));
    drop(v572_13);
    join_wrapped_into(&mut v571_21_write,&((v572_14).read_zipper()),&[]);
    }
    v571_21_cursor.ascend(1);
  }
  drop(v571_21_cursor);
  drop(v571_21_write);
  (v571_21).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v584_27 = Space::new();
  let mut v584_27_write = v584_27.write_zipper();
  let mut v584_27_cursor = (*s0).read_zipper();
  let v584_27_origin = v584_27_cursor.path().len();
  for v584_27_byte in v584_27_cursor.child_mask().iter() {
    v584_27_cursor.descend_to_existing_byte(v584_27_byte);
    {
    let v585_2: Space = singleton(&v584_27_cursor.path()[v584_27_origin..(v584_27_origin + 1)]);
    let v585_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v585_2));
    let v585_4: Space = if map_kernels::has_head(&(v585_3)) { singleton(&[]) } else { Space::new() };
    drop(v585_3);
    let v585_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v585_4));
    drop(v585_4);
    let v585_8: Space = if (&(v585_5)).is_empty() { Space::new() } else {
      let v586_6: Path = concat_path(&(*p0),&v584_27_cursor.path()[v584_27_origin..(v584_27_origin + 1)]);
      let mut v586_7 = Space::new();
      let mut v586_7_write = v586_7.write_zipper();
      for v586_7_byte in v584_27_cursor.child_mask().iter() {
        v584_27_cursor.descend_to_existing_byte(v586_7_byte);
        {
        let v587_2: Space = singleton(&v584_27_cursor.path()[(v584_27_origin + 1)..(v584_27_origin + 2)]);
        let v587_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v587_2));
        let v587_4: Space = if map_kernels::has_head(&(v587_3)) { singleton(&[]) } else { Space::new() };
        drop(v587_3);
        let v587_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v587_4));
        drop(v587_4);
        let v587_8: Space = if (&(v587_5)).is_empty() { Space::new() } else {
          let v588_6: Path = concat_path(&(v586_6),&v584_27_cursor.path()[(v584_27_origin + 1)..(v584_27_origin + 2)]);
          let mut v588_7 = Space::new();
          let mut v588_7_write = v588_7.write_zipper();
          for v588_7_byte in v584_27_cursor.child_mask().iter() {
            v584_27_cursor.descend_to_existing_byte(v588_7_byte);
            {
            let v589_2: Space = singleton(&v584_27_cursor.path()[(v584_27_origin + 2)..(v584_27_origin + 3)]);
            let v589_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v589_2));
            let v589_4: Space = if map_kernels::has_head(&(v589_3)) { singleton(&[]) } else { Space::new() };
            drop(v589_3);
            let v589_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v589_4));
            drop(v589_4);
            let v589_8: Space = if (&(v589_5)).is_empty() { Space::new() } else {
              let v590_6: Path = concat_path(&(v588_6),&v584_27_cursor.path()[(v584_27_origin + 2)..(v584_27_origin + 3)]);
              let v590_7: Space = routine_53(c, &(v590_6), &v584_27_cursor, &(*s1));
              map_map_kernels::compose(&(v589_5),&(v590_7))
            };
            drop(v589_5);
            let v589_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v589_2));
            drop(v589_2);
            let v589_10: Space = if map_kernels::has_head(&(v589_9)) { singleton(&[]) } else { Space::new() };
            drop(v589_9);
            let v589_12: Space = if (&(v589_10)).is_empty() { Space::new() } else {
              let v591_6: Path = concat_path(&(v588_6),&v584_27_cursor.path()[(v584_27_origin + 2)..(v584_27_origin + 3)]);
              let v591_11: Space = routine_54(c, &(v591_6), &v584_27_cursor, &(*s1));
              drop(v591_6);
              map_map_kernels::compose(&(v589_10),&(v591_11))
            };
            drop(v589_10);
            let v589_13: Space = map_map_kernels::unite(&(v589_8),&(v589_12));
            join_wrapped_into(&mut v588_7_write,&((v589_13).read_zipper()),&[]);
            }
            v584_27_cursor.ascend(1);
          }
          drop(v588_7_write);
          map_map_kernels::compose(&(v587_5),&(v588_7))
        };
        drop(v587_5);
        let v587_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v587_2));
        drop(v587_2);
        let v587_10: Space = if map_kernels::has_head(&(v587_9)) { singleton(&[]) } else { Space::new() };
        drop(v587_9);
        let v587_12: Space = if (&(v587_10)).is_empty() { Space::new() } else {
          let v592_6: Path = concat_path(&(v586_6),&v584_27_cursor.path()[(v584_27_origin + 1)..(v584_27_origin + 2)]);
          let mut v592_11 = Space::new();
          let mut v592_11_write = v592_11.write_zipper();
          for v592_11_byte in v584_27_cursor.child_mask().iter() {
            v584_27_cursor.descend_to_existing_byte(v592_11_byte);
            {
            let v593_2: Space = singleton(&v584_27_cursor.path()[(v584_27_origin + 2)..(v584_27_origin + 3)]);
            let v593_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v593_2));
            let v593_4: Space = if map_kernels::has_head(&(v593_3)) { singleton(&[]) } else { Space::new() };
            drop(v593_3);
            let v593_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v593_4));
            drop(v593_4);
            let v593_8: Space = if (&(v593_5)).is_empty() { Space::new() } else {
              let v594_6: Path = concat_path(&(v592_6),&v584_27_cursor.path()[(v584_27_origin + 2)..(v584_27_origin + 3)]);
              let v594_7: Space = routine_53(c, &(v594_6), &v584_27_cursor, &(*s1));
              map_map_kernels::compose(&(v593_5),&(v594_7))
            };
            drop(v593_5);
            let v593_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v593_2));
            drop(v593_2);
            let v593_10: Space = if map_kernels::has_head(&(v593_9)) { singleton(&[]) } else { Space::new() };
            drop(v593_9);
            let v593_12: Space = if (&(v593_10)).is_empty() { Space::new() } else {
              let v595_6: Path = concat_path(&(v592_6),&v584_27_cursor.path()[(v584_27_origin + 2)..(v584_27_origin + 3)]);
              let v595_11: Space = routine_24(c, &(v595_6), &v584_27_cursor, &(*s1));
              drop(v595_6);
              map_map_kernels::compose(&(v593_10),&(v595_11))
            };
            drop(v593_10);
            let v593_13: Space = map_map_kernels::unite(&(v593_8),&(v593_12));
            join_wrapped_into(&mut v592_11_write,&((v593_13).read_zipper()),&[]);
            }
            v584_27_cursor.ascend(1);
          }
          drop(v592_11_write);
          drop(v592_6);
          map_map_kernels::compose(&(v587_10),&(v592_11))
        };
        drop(v587_10);
        let v587_13: Space = map_map_kernels::unite(&(v587_8),&(v587_12));
        join_wrapped_into(&mut v586_7_write,&((v587_13).read_zipper()),&[]);
        }
        v584_27_cursor.ascend(1);
      }
      drop(v586_7_write);
      map_map_kernels::compose(&(v585_5),&(v586_7))
    };
    drop(v585_5);
    let v585_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v585_2));
    drop(v585_2);
    let v585_10: Space = if map_kernels::has_head(&(v585_9)) { singleton(&[]) } else { Space::new() };
    drop(v585_9);
    let v585_13: Space = if (&(v585_10)).is_empty() { Space::new() } else {
      let v596_6: Path = concat_path(&(*p0),&v584_27_cursor.path()[v584_27_origin..(v584_27_origin + 1)]);
      let mut v596_12 = Space::new();
      let mut v596_12_write = v596_12.write_zipper();
      for v596_12_byte in v584_27_cursor.child_mask().iter() {
        v584_27_cursor.descend_to_existing_byte(v596_12_byte);
        {
        let v597_2: Space = singleton(&v584_27_cursor.path()[(v584_27_origin + 1)..(v584_27_origin + 2)]);
        let v597_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v597_2));
        let v597_4: Space = if map_kernels::has_head(&(v597_3)) { singleton(&[]) } else { Space::new() };
        drop(v597_3);
        let v597_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v597_4));
        drop(v597_4);
        let v597_8: Space = if (&(v597_5)).is_empty() { Space::new() } else {
          let v598_6: Path = concat_path(&(v596_6),&v584_27_cursor.path()[(v584_27_origin + 1)..(v584_27_origin + 2)]);
          let mut v598_7 = Space::new();
          let mut v598_7_write = v598_7.write_zipper();
          for v598_7_byte in v584_27_cursor.child_mask().iter() {
            v584_27_cursor.descend_to_existing_byte(v598_7_byte);
            {
            let v599_2: Space = singleton(&v584_27_cursor.path()[(v584_27_origin + 2)..(v584_27_origin + 3)]);
            let v599_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v599_2));
            let v599_4: Space = if map_kernels::has_head(&(v599_3)) { singleton(&[]) } else { Space::new() };
            drop(v599_3);
            let v599_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v599_4));
            drop(v599_4);
            let v599_8: Space = if (&(v599_5)).is_empty() { Space::new() } else {
              let v600_6: Path = concat_path(&(v598_6),&v584_27_cursor.path()[(v584_27_origin + 2)..(v584_27_origin + 3)]);
              let v600_7: Space = routine_53(c, &(v600_6), &v584_27_cursor, &(*s1));
              map_map_kernels::compose(&(v599_5),&(v600_7))
            };
            drop(v599_5);
            let v599_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v599_2));
            drop(v599_2);
            let v599_10: Space = if map_kernels::has_head(&(v599_9)) { singleton(&[]) } else { Space::new() };
            drop(v599_9);
            let v599_12: Space = if (&(v599_10)).is_empty() { Space::new() } else {
              let v601_6: Path = concat_path(&(v598_6),&v584_27_cursor.path()[(v584_27_origin + 2)..(v584_27_origin + 3)]);
              let v601_11: Space = routine_54(c, &(v601_6), &v584_27_cursor, &(*s1));
              drop(v601_6);
              map_map_kernels::compose(&(v599_10),&(v601_11))
            };
            drop(v599_10);
            let v599_13: Space = map_map_kernels::unite(&(v599_8),&(v599_12));
            join_wrapped_into(&mut v598_7_write,&((v599_13).read_zipper()),&[]);
            }
            v584_27_cursor.ascend(1);
          }
          drop(v598_7_write);
          drop(v598_6);
          map_map_kernels::compose(&(v597_5),&(v598_7))
        };
        drop(v597_5);
        let v597_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v597_2));
        drop(v597_2);
        let v597_10: Space = if map_kernels::has_head(&(v597_9)) { singleton(&[]) } else { Space::new() };
        drop(v597_9);
        let v597_13: Space = if (&(v597_10)).is_empty() { Space::new() } else {
          let v602_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v584_27_cursor.path()[v584_27_origin..(v584_27_origin + 1)]),&v584_27_cursor.path()[(v584_27_origin + 1)..(v584_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v597_10),&(v602_12))
        };
        drop(v597_10);
        let v597_14: Space = map_map_kernels::unite(&(v597_8),&(v597_13));
        drop(v597_13);
        join_wrapped_into(&mut v596_12_write,&((v597_14).read_zipper()),&[]);
        }
        v584_27_cursor.ascend(1);
      }
      drop(v596_12_write);
      drop(v596_6);
      map_map_kernels::compose(&(v585_10),&(v596_12))
    };
    drop(v585_10);
    let v585_14: Space = map_map_kernels::unite(&(v585_8),&(v585_13));
    join_wrapped_into(&mut v584_27_write,&((v585_14).read_zipper()),&[]);
    }
    v584_27_cursor.ascend(1);
  }
  drop(v584_27_cursor);
  drop(v584_27_write);
  (v584_27).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v603_21 = Space::new();
  let mut v603_21_write = v603_21.write_zipper();
  let mut v603_21_cursor = (*s0).read_zipper();
  let v603_21_origin = v603_21_cursor.path().len();
  for v603_21_byte in v603_21_cursor.child_mask().iter() {
    v603_21_cursor.descend_to_existing_byte(v603_21_byte);
    {
    let v604_2: Space = singleton(&v603_21_cursor.path()[v603_21_origin..(v603_21_origin + 1)]);
    let v604_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v604_2));
    let v604_4: Space = if map_kernels::has_head(&(v604_3)) { singleton(&[]) } else { Space::new() };
    drop(v604_3);
    let v604_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v604_4));
    drop(v604_4);
    let v604_8: Space = if (&(v604_5)).is_empty() { Space::new() } else {
      let v605_6: Path = concat_path(&(*p0),&v603_21_cursor.path()[v603_21_origin..(v603_21_origin + 1)]);
      let mut v605_7 = Space::new();
      let mut v605_7_write = v605_7.write_zipper();
      for v605_7_byte in v603_21_cursor.child_mask().iter() {
        v603_21_cursor.descend_to_existing_byte(v605_7_byte);
        {
        let v606_2: Space = singleton(&v603_21_cursor.path()[(v603_21_origin + 1)..(v603_21_origin + 2)]);
        let v606_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v606_2));
        let v606_4: Space = if map_kernels::has_head(&(v606_3)) { singleton(&[]) } else { Space::new() };
        drop(v606_3);
        let v606_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v606_4));
        drop(v606_4);
        let v606_8: Space = if (&(v606_5)).is_empty() { Space::new() } else {
          let v607_6: Path = concat_path(&(v605_6),&v603_21_cursor.path()[(v603_21_origin + 1)..(v603_21_origin + 2)]);
          let mut v607_7 = Space::new();
          let mut v607_7_write = v607_7.write_zipper();
          for v607_7_byte in v603_21_cursor.child_mask().iter() {
            v603_21_cursor.descend_to_existing_byte(v607_7_byte);
            {
            let v608_2: Space = singleton(&v603_21_cursor.path()[(v603_21_origin + 2)..(v603_21_origin + 3)]);
            let v608_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v608_2));
            let v608_4: Space = if map_kernels::has_head(&(v608_3)) { singleton(&[]) } else { Space::new() };
            drop(v608_3);
            let v608_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v608_4));
            drop(v608_4);
            let v608_8: Space = if (&(v608_5)).is_empty() { Space::new() } else {
              let v609_6: Path = concat_path(&(v607_6),&v603_21_cursor.path()[(v603_21_origin + 2)..(v603_21_origin + 3)]);
              let v609_7: Space = routine_53(c, &(v609_6), &v603_21_cursor, &(*s1));
              map_map_kernels::compose(&(v608_5),&(v609_7))
            };
            drop(v608_5);
            let v608_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v608_2));
            drop(v608_2);
            let v608_10: Space = if map_kernels::has_head(&(v608_9)) { singleton(&[]) } else { Space::new() };
            drop(v608_9);
            let v608_12: Space = if (&(v608_10)).is_empty() { Space::new() } else {
              let v610_6: Path = concat_path(&(v607_6),&v603_21_cursor.path()[(v603_21_origin + 2)..(v603_21_origin + 3)]);
              let v610_11: Space = routine_54(c, &(v610_6), &v603_21_cursor, &(*s1));
              drop(v610_6);
              map_map_kernels::compose(&(v608_10),&(v610_11))
            };
            drop(v608_10);
            let v608_13: Space = map_map_kernels::unite(&(v608_8),&(v608_12));
            join_wrapped_into(&mut v607_7_write,&((v608_13).read_zipper()),&[]);
            }
            v603_21_cursor.ascend(1);
          }
          drop(v607_7_write);
          map_map_kernels::compose(&(v606_5),&(v607_7))
        };
        drop(v606_5);
        let v606_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v606_2));
        drop(v606_2);
        let v606_10: Space = if map_kernels::has_head(&(v606_9)) { singleton(&[]) } else { Space::new() };
        drop(v606_9);
        let v606_12: Space = if (&(v606_10)).is_empty() { Space::new() } else {
          let v611_6: Path = concat_path(&(v605_6),&v603_21_cursor.path()[(v603_21_origin + 1)..(v603_21_origin + 2)]);
          let mut v611_11 = Space::new();
          let mut v611_11_write = v611_11.write_zipper();
          for v611_11_byte in v603_21_cursor.child_mask().iter() {
            v603_21_cursor.descend_to_existing_byte(v611_11_byte);
            {
            let v612_2: Space = singleton(&v603_21_cursor.path()[(v603_21_origin + 2)..(v603_21_origin + 3)]);
            let v612_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v612_2));
            let v612_4: Space = if map_kernels::has_head(&(v612_3)) { singleton(&[]) } else { Space::new() };
            drop(v612_3);
            let v612_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v612_4));
            drop(v612_4);
            let v612_8: Space = if (&(v612_5)).is_empty() { Space::new() } else {
              let v613_6: Path = concat_path(&(v611_6),&v603_21_cursor.path()[(v603_21_origin + 2)..(v603_21_origin + 3)]);
              let v613_7: Space = routine_53(c, &(v613_6), &v603_21_cursor, &(*s1));
              map_map_kernels::compose(&(v612_5),&(v613_7))
            };
            drop(v612_5);
            let v612_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v612_2));
            drop(v612_2);
            let v612_10: Space = if map_kernels::has_head(&(v612_9)) { singleton(&[]) } else { Space::new() };
            drop(v612_9);
            let v612_12: Space = if (&(v612_10)).is_empty() { Space::new() } else {
              let v614_6: Path = concat_path(&(v611_6),&v603_21_cursor.path()[(v603_21_origin + 2)..(v603_21_origin + 3)]);
              let v614_11: Space = routine_24(c, &(v614_6), &v603_21_cursor, &(*s1));
              drop(v614_6);
              map_map_kernels::compose(&(v612_10),&(v614_11))
            };
            drop(v612_10);
            let v612_13: Space = map_map_kernels::unite(&(v612_8),&(v612_12));
            join_wrapped_into(&mut v611_11_write,&((v612_13).read_zipper()),&[]);
            }
            v603_21_cursor.ascend(1);
          }
          drop(v611_11_write);
          drop(v611_6);
          map_map_kernels::compose(&(v606_10),&(v611_11))
        };
        drop(v606_10);
        let v606_13: Space = map_map_kernels::unite(&(v606_8),&(v606_12));
        join_wrapped_into(&mut v605_7_write,&((v606_13).read_zipper()),&[]);
        }
        v603_21_cursor.ascend(1);
      }
      drop(v605_7_write);
      drop(v605_6);
      map_map_kernels::compose(&(v604_5),&(v605_7))
    };
    drop(v604_5);
    let v604_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v604_2));
    drop(v604_2);
    let v604_10: Space = if map_kernels::has_head(&(v604_9)) { singleton(&[]) } else { Space::new() };
    drop(v604_9);
    let v604_13: Space = if (&(v604_10)).is_empty() { Space::new() } else {
      let v615_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v603_21_cursor.path()[v603_21_origin..(v603_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v604_10),&(v615_12))
    };
    drop(v604_10);
    let v604_14: Space = map_map_kernels::unite(&(v604_8),&(v604_13));
    drop(v604_13);
    join_wrapped_into(&mut v603_21_write,&((v604_14).read_zipper()),&[]);
    }
    v603_21_cursor.ascend(1);
  }
  drop(v603_21_cursor);
  drop(v603_21_write);
  (v603_21).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v616_8 = Space::new();
  let mut v616_8_write = v616_8.write_zipper();
  let mut v616_8_cursor = (*s0).read_zipper();
  let v616_8_origin = v616_8_cursor.path().len();
  for v616_8_byte in v616_8_cursor.child_mask().iter() {
    v616_8_cursor.descend_to_existing_byte(v616_8_byte);
    {
    let v617_2: Space = singleton(&v616_8_cursor.path()[v616_8_origin..(v616_8_origin + 1)]);
    let v617_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v617_2));
    drop(v617_2);
    let v617_4: Space = if map_kernels::has_head(&(v617_3)) { singleton(&[]) } else { Space::new() };
    drop(v617_3);
    let v617_7: Space = if (&(v617_4)).is_empty() { Space::new() } else {
      let v618_5: Path = concat_path(&(*p0),&v616_8_cursor.path()[v616_8_origin..(v616_8_origin + 1)]);
      let mut v618_6 = Space::new();
      let mut v618_6_write = v618_6.write_zipper();
      for v618_6_byte in v616_8_cursor.child_mask().iter() {
        v616_8_cursor.descend_to_existing_byte(v618_6_byte);
        {
        let v619_2: Space = singleton(&v616_8_cursor.path()[(v616_8_origin + 1)..(v616_8_origin + 2)]);
        let v619_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v619_2));
        drop(v619_2);
        let v619_4: Space = if map_kernels::has_head(&(v619_3)) { singleton(&[]) } else { Space::new() };
        drop(v619_3);
        let v619_6: Space = if (&(v619_4)).is_empty() { Space::new() } else {
          let mut v620_5 = Space::new();
          let mut v620_5_write = v620_5.write_zipper();
          for v620_5_byte in v616_8_cursor.child_mask().iter() {
            v616_8_cursor.descend_to_existing_byte(v620_5_byte);
            {
            let v621_2: Space = singleton(&v616_8_cursor.path()[(v616_8_origin + 2)..(v616_8_origin + 3)]);
            let v621_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v621_2));
            let v621_4: Space = if map_kernels::has_head(&(v621_3)) { singleton(&[]) } else { Space::new() };
            drop(v621_3);
            let v621_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v621_4));
            drop(v621_4);
            let v621_7: Space = if (&(v621_5)).is_empty() { Space::new() } else {
              let v622_6: Space = routine_10(c, &v616_8_cursor.path()[(v616_8_origin + 2)..(v616_8_origin + 3)], &v616_8_cursor, &(*s1));
              map_map_kernels::compose(&(v621_5),&(v622_6))
            };
            drop(v621_5);
            let v621_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v621_2));
            drop(v621_2);
            let v621_9: Space = if map_kernels::has_head(&(v621_8)) { singleton(&[]) } else { Space::new() };
            drop(v621_8);
            let v621_11: Space = if (&(v621_9)).is_empty() { Space::new() } else {
              let v623_10: Space = routine_11(c, &v616_8_cursor.path()[(v616_8_origin + 2)..(v616_8_origin + 3)], &v616_8_cursor, &(*s1));
              map_map_kernels::compose(&(v621_9),&(v623_10))
            };
            drop(v621_9);
            let v621_12: Space = map_map_kernels::unite(&(v621_7),&(v621_11));
            join_wrapped_into(&mut v620_5_write,&((v621_12).read_zipper()),&[]);
            }
            v616_8_cursor.ascend(1);
          }
          drop(v620_5_write);
          map_map_kernels::compose(&(v619_4),&(v620_5))
        };
        drop(v619_4);
        let v619_7: Path = concat_path(&(v618_5),&v616_8_cursor.path()[(v616_8_origin + 1)..(v616_8_origin + 2)]);
        join_wrapped_into(&mut v618_6_write,&((v619_6).read_zipper()),&(v619_7));
        drop(v619_7);
        }
        v616_8_cursor.ascend(1);
      }
      drop(v618_6_write);
      drop(v618_5);
      map_map_kernels::compose(&(v617_4),&(v618_6))
    };
    drop(v617_4);
    join_wrapped_into(&mut v616_8_write,&((v617_7).read_zipper()),&[]);
    }
    v616_8_cursor.ascend(1);
  }
  drop(v616_8_cursor);
  drop(v616_8_write);
  (v616_8).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v624_13 = Space::new();
  let mut v624_13_write = v624_13.write_zipper();
  let mut v624_13_cursor = (*s0).read_zipper();
  let v624_13_origin = v624_13_cursor.path().len();
  for v624_13_byte in v624_13_cursor.child_mask().iter() {
    v624_13_cursor.descend_to_existing_byte(v624_13_byte);
    {
    let v625_2: Space = singleton(&v624_13_cursor.path()[v624_13_origin..(v624_13_origin + 1)]);
    let v625_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v625_2));
    drop(v625_2);
    let v625_4: Space = if map_kernels::has_head(&(v625_3)) { singleton(&[]) } else { Space::new() };
    drop(v625_3);
    let v625_6: Space = if (&(v625_4)).is_empty() { Space::new() } else {
      let mut v626_5 = Space::new();
      let mut v626_5_write = v626_5.write_zipper();
      for v626_5_byte in v624_13_cursor.child_mask().iter() {
        v624_13_cursor.descend_to_existing_byte(v626_5_byte);
        {
        let v627_2: Space = singleton(&v624_13_cursor.path()[(v624_13_origin + 1)..(v624_13_origin + 2)]);
        let v627_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v627_2));
        let v627_4: Space = if map_kernels::has_head(&(v627_3)) { singleton(&[]) } else { Space::new() };
        drop(v627_3);
        let v627_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v627_4));
        drop(v627_4);
        let v627_7: Space = if (&(v627_5)).is_empty() { Space::new() } else {
          let mut v628_6 = Space::new();
          let mut v628_6_write = v628_6.write_zipper();
          for v628_6_byte in v624_13_cursor.child_mask().iter() {
            v624_13_cursor.descend_to_existing_byte(v628_6_byte);
            {
            let v629_2: Space = singleton(&v624_13_cursor.path()[(v624_13_origin + 2)..(v624_13_origin + 3)]);
            let v629_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v629_2));
            let v629_4: Space = if map_kernels::has_head(&(v629_3)) { singleton(&[]) } else { Space::new() };
            drop(v629_3);
            let v629_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v629_4));
            drop(v629_4);
            let v629_8: Space = if (&(v629_5)).is_empty() { Space::new() } else {
              let v630_7: Space = routine_31(c, &v624_13_cursor.path()[(v624_13_origin + 1)..(v624_13_origin + 3)], &v624_13_cursor, &(*s1));
              map_map_kernels::compose(&(v629_5),&(v630_7))
            };
            drop(v629_5);
            let v629_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v629_2));
            drop(v629_2);
            let v629_10: Space = if map_kernels::has_head(&(v629_9)) { singleton(&[]) } else { Space::new() };
            drop(v629_9);
            let v629_12: Space = if (&(v629_10)).is_empty() { Space::new() } else {
              let v631_11: Space = routine_32(c, &v624_13_cursor.path()[(v624_13_origin + 1)..(v624_13_origin + 3)], &v624_13_cursor, &(*s1));
              map_map_kernels::compose(&(v629_10),&(v631_11))
            };
            drop(v629_10);
            let v629_13: Space = map_map_kernels::unite(&(v629_8),&(v629_12));
            join_wrapped_into(&mut v628_6_write,&((v629_13).read_zipper()),&[]);
            }
            v624_13_cursor.ascend(1);
          }
          drop(v628_6_write);
          map_map_kernels::compose(&(v627_5),&(v628_6))
        };
        drop(v627_5);
        let v627_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v627_2));
        drop(v627_2);
        let v627_9: Space = if map_kernels::has_head(&(v627_8)) { singleton(&[]) } else { Space::new() };
        drop(v627_8);
        let v627_11: Space = if (&(v627_9)).is_empty() { Space::new() } else {
          let mut v632_10 = Space::new();
          let mut v632_10_write = v632_10.write_zipper();
          for v632_10_byte in v624_13_cursor.child_mask().iter() {
            v624_13_cursor.descend_to_existing_byte(v632_10_byte);
            {
            let v633_2: Space = singleton(&v624_13_cursor.path()[(v624_13_origin + 2)..(v624_13_origin + 3)]);
            let v633_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v633_2));
            let v633_4: Space = if map_kernels::has_head(&(v633_3)) { singleton(&[]) } else { Space::new() };
            drop(v633_3);
            let v633_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v633_4));
            drop(v633_4);
            let v633_8: Space = if (&(v633_5)).is_empty() { Space::new() } else {
              let v634_7: Space = routine_31(c, &v624_13_cursor.path()[(v624_13_origin + 1)..(v624_13_origin + 3)], &v624_13_cursor, &(*s1));
              map_map_kernels::compose(&(v633_5),&(v634_7))
            };
            drop(v633_5);
            let v633_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v633_2));
            drop(v633_2);
            let v633_10: Space = if map_kernels::has_head(&(v633_9)) { singleton(&[]) } else { Space::new() };
            drop(v633_9);
            let v633_12: Space = if (&(v633_10)).is_empty() { Space::new() } else {
              let v635_11: Space = routine_33(c, &v624_13_cursor.path()[(v624_13_origin + 1)..(v624_13_origin + 3)], &v624_13_cursor, &(*s1));
              map_map_kernels::compose(&(v633_10),&(v635_11))
            };
            drop(v633_10);
            let v633_13: Space = map_map_kernels::unite(&(v633_8),&(v633_12));
            join_wrapped_into(&mut v632_10_write,&((v633_13).read_zipper()),&[]);
            }
            v624_13_cursor.ascend(1);
          }
          drop(v632_10_write);
          map_map_kernels::compose(&(v627_9),&(v632_10))
        };
        drop(v627_9);
        let v627_12: Space = map_map_kernels::unite(&(v627_7),&(v627_11));
        join_wrapped_into(&mut v626_5_write,&((v627_12).read_zipper()),&[]);
        }
        v624_13_cursor.ascend(1);
      }
      drop(v626_5_write);
      map_map_kernels::compose(&(v625_4),&(v626_5))
    };
    drop(v625_4);
    let v625_7: Path = concat_path(&(*p0),&v624_13_cursor.path()[v624_13_origin..(v624_13_origin + 1)]);
    join_wrapped_into(&mut v624_13_write,&((v625_6).read_zipper()),&(v625_7));
    drop(v625_7);
    }
    v624_13_cursor.ascend(1);
  }
  drop(v624_13_cursor);
  drop(v624_13_write);
  (v624_13).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v636_27 = Space::new();
  let mut v636_27_write = v636_27.write_zipper();
  let mut v636_27_cursor = (*s0).read_zipper();
  let v636_27_origin = v636_27_cursor.path().len();
  for v636_27_byte in v636_27_cursor.child_mask().iter() {
    v636_27_cursor.descend_to_existing_byte(v636_27_byte);
    {
    let v637_2: Space = singleton(&v636_27_cursor.path()[v636_27_origin..(v636_27_origin + 1)]);
    let v637_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v637_2));
    let v637_4: Space = if map_kernels::has_head(&(v637_3)) { singleton(&[]) } else { Space::new() };
    drop(v637_3);
    let v637_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v637_4));
    drop(v637_4);
    let v637_8: Space = if (&(v637_5)).is_empty() { Space::new() } else {
      let v638_6: Path = concat_path(&(*p0),&v636_27_cursor.path()[v636_27_origin..(v636_27_origin + 1)]);
      let mut v638_7 = Space::new();
      let mut v638_7_write = v638_7.write_zipper();
      for v638_7_byte in v636_27_cursor.child_mask().iter() {
        v636_27_cursor.descend_to_existing_byte(v638_7_byte);
        {
        let v639_2: Space = singleton(&v636_27_cursor.path()[(v636_27_origin + 1)..(v636_27_origin + 2)]);
        let v639_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v639_2));
        let v639_4: Space = if map_kernels::has_head(&(v639_3)) { singleton(&[]) } else { Space::new() };
        drop(v639_3);
        let v639_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v639_4));
        drop(v639_4);
        let v639_8: Space = if (&(v639_5)).is_empty() { Space::new() } else {
          let v640_6: Path = concat_path(&(v638_6),&v636_27_cursor.path()[(v636_27_origin + 1)..(v636_27_origin + 2)]);
          let mut v640_7 = Space::new();
          let mut v640_7_write = v640_7.write_zipper();
          for v640_7_byte in v636_27_cursor.child_mask().iter() {
            v636_27_cursor.descend_to_existing_byte(v640_7_byte);
            {
            let v641_2: Space = singleton(&v636_27_cursor.path()[(v636_27_origin + 2)..(v636_27_origin + 3)]);
            let v641_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v641_2));
            let v641_4: Space = if map_kernels::has_head(&(v641_3)) { singleton(&[]) } else { Space::new() };
            drop(v641_3);
            let v641_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v641_4));
            drop(v641_4);
            let v641_8: Space = if (&(v641_5)).is_empty() { Space::new() } else {
              let v642_6: Path = concat_path(&(v640_6),&v636_27_cursor.path()[(v636_27_origin + 2)..(v636_27_origin + 3)]);
              let v642_7: Space = routine_55(c, &(v642_6), &v636_27_cursor, &(*s1));
              map_map_kernels::compose(&(v641_5),&(v642_7))
            };
            drop(v641_5);
            let v641_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v641_2));
            drop(v641_2);
            let v641_10: Space = if map_kernels::has_head(&(v641_9)) { singleton(&[]) } else { Space::new() };
            drop(v641_9);
            let v641_12: Space = if (&(v641_10)).is_empty() { Space::new() } else {
              let v643_6: Path = concat_path(&(v640_6),&v636_27_cursor.path()[(v636_27_origin + 2)..(v636_27_origin + 3)]);
              let v643_11: Space = routine_56(c, &(v643_6), &v636_27_cursor, &(*s1));
              drop(v643_6);
              map_map_kernels::compose(&(v641_10),&(v643_11))
            };
            drop(v641_10);
            let v641_13: Space = map_map_kernels::unite(&(v641_8),&(v641_12));
            join_wrapped_into(&mut v640_7_write,&((v641_13).read_zipper()),&[]);
            }
            v636_27_cursor.ascend(1);
          }
          drop(v640_7_write);
          map_map_kernels::compose(&(v639_5),&(v640_7))
        };
        drop(v639_5);
        let v639_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v639_2));
        drop(v639_2);
        let v639_10: Space = if map_kernels::has_head(&(v639_9)) { singleton(&[]) } else { Space::new() };
        drop(v639_9);
        let v639_12: Space = if (&(v639_10)).is_empty() { Space::new() } else {
          let v644_6: Path = concat_path(&(v638_6),&v636_27_cursor.path()[(v636_27_origin + 1)..(v636_27_origin + 2)]);
          let mut v644_11 = Space::new();
          let mut v644_11_write = v644_11.write_zipper();
          for v644_11_byte in v636_27_cursor.child_mask().iter() {
            v636_27_cursor.descend_to_existing_byte(v644_11_byte);
            {
            let v645_2: Space = singleton(&v636_27_cursor.path()[(v636_27_origin + 2)..(v636_27_origin + 3)]);
            let v645_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v645_2));
            let v645_4: Space = if map_kernels::has_head(&(v645_3)) { singleton(&[]) } else { Space::new() };
            drop(v645_3);
            let v645_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v645_4));
            drop(v645_4);
            let v645_8: Space = if (&(v645_5)).is_empty() { Space::new() } else {
              let v646_6: Path = concat_path(&(v644_6),&v636_27_cursor.path()[(v636_27_origin + 2)..(v636_27_origin + 3)]);
              let v646_7: Space = routine_55(c, &(v646_6), &v636_27_cursor, &(*s1));
              map_map_kernels::compose(&(v645_5),&(v646_7))
            };
            drop(v645_5);
            let v645_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v645_2));
            drop(v645_2);
            let v645_10: Space = if map_kernels::has_head(&(v645_9)) { singleton(&[]) } else { Space::new() };
            drop(v645_9);
            let v645_12: Space = if (&(v645_10)).is_empty() { Space::new() } else {
              let v647_6: Path = concat_path(&(v644_6),&v636_27_cursor.path()[(v636_27_origin + 2)..(v636_27_origin + 3)]);
              let v647_11: Space = routine_33(c, &(v647_6), &v636_27_cursor, &(*s1));
              drop(v647_6);
              map_map_kernels::compose(&(v645_10),&(v647_11))
            };
            drop(v645_10);
            let v645_13: Space = map_map_kernels::unite(&(v645_8),&(v645_12));
            join_wrapped_into(&mut v644_11_write,&((v645_13).read_zipper()),&[]);
            }
            v636_27_cursor.ascend(1);
          }
          drop(v644_11_write);
          drop(v644_6);
          map_map_kernels::compose(&(v639_10),&(v644_11))
        };
        drop(v639_10);
        let v639_13: Space = map_map_kernels::unite(&(v639_8),&(v639_12));
        join_wrapped_into(&mut v638_7_write,&((v639_13).read_zipper()),&[]);
        }
        v636_27_cursor.ascend(1);
      }
      drop(v638_7_write);
      map_map_kernels::compose(&(v637_5),&(v638_7))
    };
    drop(v637_5);
    let v637_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v637_2));
    drop(v637_2);
    let v637_10: Space = if map_kernels::has_head(&(v637_9)) { singleton(&[]) } else { Space::new() };
    drop(v637_9);
    let v637_13: Space = if (&(v637_10)).is_empty() { Space::new() } else {
      let v648_6: Path = concat_path(&(*p0),&v636_27_cursor.path()[v636_27_origin..(v636_27_origin + 1)]);
      let mut v648_12 = Space::new();
      let mut v648_12_write = v648_12.write_zipper();
      for v648_12_byte in v636_27_cursor.child_mask().iter() {
        v636_27_cursor.descend_to_existing_byte(v648_12_byte);
        {
        let v649_2: Space = singleton(&v636_27_cursor.path()[(v636_27_origin + 1)..(v636_27_origin + 2)]);
        let v649_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v649_2));
        let v649_4: Space = if map_kernels::has_head(&(v649_3)) { singleton(&[]) } else { Space::new() };
        drop(v649_3);
        let v649_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v649_4));
        drop(v649_4);
        let v649_8: Space = if (&(v649_5)).is_empty() { Space::new() } else {
          let v650_6: Path = concat_path(&(v648_6),&v636_27_cursor.path()[(v636_27_origin + 1)..(v636_27_origin + 2)]);
          let mut v650_7 = Space::new();
          let mut v650_7_write = v650_7.write_zipper();
          for v650_7_byte in v636_27_cursor.child_mask().iter() {
            v636_27_cursor.descend_to_existing_byte(v650_7_byte);
            {
            let v651_2: Space = singleton(&v636_27_cursor.path()[(v636_27_origin + 2)..(v636_27_origin + 3)]);
            let v651_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v651_2));
            let v651_4: Space = if map_kernels::has_head(&(v651_3)) { singleton(&[]) } else { Space::new() };
            drop(v651_3);
            let v651_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v651_4));
            drop(v651_4);
            let v651_8: Space = if (&(v651_5)).is_empty() { Space::new() } else {
              let v652_6: Path = concat_path(&(v650_6),&v636_27_cursor.path()[(v636_27_origin + 2)..(v636_27_origin + 3)]);
              let v652_7: Space = routine_55(c, &(v652_6), &v636_27_cursor, &(*s1));
              map_map_kernels::compose(&(v651_5),&(v652_7))
            };
            drop(v651_5);
            let v651_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v651_2));
            drop(v651_2);
            let v651_10: Space = if map_kernels::has_head(&(v651_9)) { singleton(&[]) } else { Space::new() };
            drop(v651_9);
            let v651_12: Space = if (&(v651_10)).is_empty() { Space::new() } else {
              let v653_6: Path = concat_path(&(v650_6),&v636_27_cursor.path()[(v636_27_origin + 2)..(v636_27_origin + 3)]);
              let v653_11: Space = routine_56(c, &(v653_6), &v636_27_cursor, &(*s1));
              drop(v653_6);
              map_map_kernels::compose(&(v651_10),&(v653_11))
            };
            drop(v651_10);
            let v651_13: Space = map_map_kernels::unite(&(v651_8),&(v651_12));
            join_wrapped_into(&mut v650_7_write,&((v651_13).read_zipper()),&[]);
            }
            v636_27_cursor.ascend(1);
          }
          drop(v650_7_write);
          drop(v650_6);
          map_map_kernels::compose(&(v649_5),&(v650_7))
        };
        drop(v649_5);
        let v649_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v649_2));
        drop(v649_2);
        let v649_10: Space = if map_kernels::has_head(&(v649_9)) { singleton(&[]) } else { Space::new() };
        drop(v649_9);
        let v649_13: Space = if (&(v649_10)).is_empty() { Space::new() } else {
          let v654_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v636_27_cursor.path()[v636_27_origin..(v636_27_origin + 1)]),&v636_27_cursor.path()[(v636_27_origin + 1)..(v636_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v649_10),&(v654_12))
        };
        drop(v649_10);
        let v649_14: Space = map_map_kernels::unite(&(v649_8),&(v649_13));
        drop(v649_13);
        join_wrapped_into(&mut v648_12_write,&((v649_14).read_zipper()),&[]);
        }
        v636_27_cursor.ascend(1);
      }
      drop(v648_12_write);
      drop(v648_6);
      map_map_kernels::compose(&(v637_10),&(v648_12))
    };
    drop(v637_10);
    let v637_14: Space = map_map_kernels::unite(&(v637_8),&(v637_13));
    join_wrapped_into(&mut v636_27_write,&((v637_14).read_zipper()),&[]);
    }
    v636_27_cursor.ascend(1);
  }
  drop(v636_27_cursor);
  drop(v636_27_write);
  (v636_27).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v655_21 = Space::new();
  let mut v655_21_write = v655_21.write_zipper();
  let mut v655_21_cursor = (*s0).read_zipper();
  let v655_21_origin = v655_21_cursor.path().len();
  for v655_21_byte in v655_21_cursor.child_mask().iter() {
    v655_21_cursor.descend_to_existing_byte(v655_21_byte);
    {
    let v656_2: Space = singleton(&v655_21_cursor.path()[v655_21_origin..(v655_21_origin + 1)]);
    let v656_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v656_2));
    let v656_4: Space = if map_kernels::has_head(&(v656_3)) { singleton(&[]) } else { Space::new() };
    drop(v656_3);
    let v656_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v656_4));
    drop(v656_4);
    let v656_8: Space = if (&(v656_5)).is_empty() { Space::new() } else {
      let v657_6: Path = concat_path(&(*p0),&v655_21_cursor.path()[v655_21_origin..(v655_21_origin + 1)]);
      let mut v657_7 = Space::new();
      let mut v657_7_write = v657_7.write_zipper();
      for v657_7_byte in v655_21_cursor.child_mask().iter() {
        v655_21_cursor.descend_to_existing_byte(v657_7_byte);
        {
        let v658_2: Space = singleton(&v655_21_cursor.path()[(v655_21_origin + 1)..(v655_21_origin + 2)]);
        let v658_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v658_2));
        let v658_4: Space = if map_kernels::has_head(&(v658_3)) { singleton(&[]) } else { Space::new() };
        drop(v658_3);
        let v658_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v658_4));
        drop(v658_4);
        let v658_8: Space = if (&(v658_5)).is_empty() { Space::new() } else {
          let v659_6: Path = concat_path(&(v657_6),&v655_21_cursor.path()[(v655_21_origin + 1)..(v655_21_origin + 2)]);
          let mut v659_7 = Space::new();
          let mut v659_7_write = v659_7.write_zipper();
          for v659_7_byte in v655_21_cursor.child_mask().iter() {
            v655_21_cursor.descend_to_existing_byte(v659_7_byte);
            {
            let v660_2: Space = singleton(&v655_21_cursor.path()[(v655_21_origin + 2)..(v655_21_origin + 3)]);
            let v660_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v660_2));
            let v660_4: Space = if map_kernels::has_head(&(v660_3)) { singleton(&[]) } else { Space::new() };
            drop(v660_3);
            let v660_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v660_4));
            drop(v660_4);
            let v660_8: Space = if (&(v660_5)).is_empty() { Space::new() } else {
              let v661_6: Path = concat_path(&(v659_6),&v655_21_cursor.path()[(v655_21_origin + 2)..(v655_21_origin + 3)]);
              let v661_7: Space = routine_55(c, &(v661_6), &v655_21_cursor, &(*s1));
              map_map_kernels::compose(&(v660_5),&(v661_7))
            };
            drop(v660_5);
            let v660_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v660_2));
            drop(v660_2);
            let v660_10: Space = if map_kernels::has_head(&(v660_9)) { singleton(&[]) } else { Space::new() };
            drop(v660_9);
            let v660_12: Space = if (&(v660_10)).is_empty() { Space::new() } else {
              let v662_6: Path = concat_path(&(v659_6),&v655_21_cursor.path()[(v655_21_origin + 2)..(v655_21_origin + 3)]);
              let v662_11: Space = routine_56(c, &(v662_6), &v655_21_cursor, &(*s1));
              drop(v662_6);
              map_map_kernels::compose(&(v660_10),&(v662_11))
            };
            drop(v660_10);
            let v660_13: Space = map_map_kernels::unite(&(v660_8),&(v660_12));
            join_wrapped_into(&mut v659_7_write,&((v660_13).read_zipper()),&[]);
            }
            v655_21_cursor.ascend(1);
          }
          drop(v659_7_write);
          map_map_kernels::compose(&(v658_5),&(v659_7))
        };
        drop(v658_5);
        let v658_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v658_2));
        drop(v658_2);
        let v658_10: Space = if map_kernels::has_head(&(v658_9)) { singleton(&[]) } else { Space::new() };
        drop(v658_9);
        let v658_12: Space = if (&(v658_10)).is_empty() { Space::new() } else {
          let v663_6: Path = concat_path(&(v657_6),&v655_21_cursor.path()[(v655_21_origin + 1)..(v655_21_origin + 2)]);
          let mut v663_11 = Space::new();
          let mut v663_11_write = v663_11.write_zipper();
          for v663_11_byte in v655_21_cursor.child_mask().iter() {
            v655_21_cursor.descend_to_existing_byte(v663_11_byte);
            {
            let v664_2: Space = singleton(&v655_21_cursor.path()[(v655_21_origin + 2)..(v655_21_origin + 3)]);
            let v664_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v664_2));
            let v664_4: Space = if map_kernels::has_head(&(v664_3)) { singleton(&[]) } else { Space::new() };
            drop(v664_3);
            let v664_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v664_4));
            drop(v664_4);
            let v664_8: Space = if (&(v664_5)).is_empty() { Space::new() } else {
              let v665_6: Path = concat_path(&(v663_6),&v655_21_cursor.path()[(v655_21_origin + 2)..(v655_21_origin + 3)]);
              let v665_7: Space = routine_55(c, &(v665_6), &v655_21_cursor, &(*s1));
              map_map_kernels::compose(&(v664_5),&(v665_7))
            };
            drop(v664_5);
            let v664_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v664_2));
            drop(v664_2);
            let v664_10: Space = if map_kernels::has_head(&(v664_9)) { singleton(&[]) } else { Space::new() };
            drop(v664_9);
            let v664_12: Space = if (&(v664_10)).is_empty() { Space::new() } else {
              let v666_6: Path = concat_path(&(v663_6),&v655_21_cursor.path()[(v655_21_origin + 2)..(v655_21_origin + 3)]);
              let v666_11: Space = routine_33(c, &(v666_6), &v655_21_cursor, &(*s1));
              drop(v666_6);
              map_map_kernels::compose(&(v664_10),&(v666_11))
            };
            drop(v664_10);
            let v664_13: Space = map_map_kernels::unite(&(v664_8),&(v664_12));
            join_wrapped_into(&mut v663_11_write,&((v664_13).read_zipper()),&[]);
            }
            v655_21_cursor.ascend(1);
          }
          drop(v663_11_write);
          drop(v663_6);
          map_map_kernels::compose(&(v658_10),&(v663_11))
        };
        drop(v658_10);
        let v658_13: Space = map_map_kernels::unite(&(v658_8),&(v658_12));
        join_wrapped_into(&mut v657_7_write,&((v658_13).read_zipper()),&[]);
        }
        v655_21_cursor.ascend(1);
      }
      drop(v657_7_write);
      drop(v657_6);
      map_map_kernels::compose(&(v656_5),&(v657_7))
    };
    drop(v656_5);
    let v656_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v656_2));
    drop(v656_2);
    let v656_10: Space = if map_kernels::has_head(&(v656_9)) { singleton(&[]) } else { Space::new() };
    drop(v656_9);
    let v656_13: Space = if (&(v656_10)).is_empty() { Space::new() } else {
      let v667_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v655_21_cursor.path()[v655_21_origin..(v655_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v656_10),&(v667_12))
    };
    drop(v656_10);
    let v656_14: Space = map_map_kernels::unite(&(v656_8),&(v656_13));
    drop(v656_13);
    join_wrapped_into(&mut v655_21_write,&((v656_14).read_zipper()),&[]);
    }
    v655_21_cursor.ascend(1);
  }
  drop(v655_21_cursor);
  drop(v655_21_write);
  (v655_21).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v668_9: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0))),&(*CONSTANT_5));
  (v668_9).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v669_27 = Space::new();
  let mut v669_27_write = v669_27.write_zipper();
  let mut v669_27_cursor = (*s0).read_zipper();
  let v669_27_origin = v669_27_cursor.path().len();
  for v669_27_byte in v669_27_cursor.child_mask().iter() {
    v669_27_cursor.descend_to_existing_byte(v669_27_byte);
    {
    let v670_2: Space = singleton(&v669_27_cursor.path()[v669_27_origin..(v669_27_origin + 1)]);
    let v670_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v670_2));
    let v670_4: Space = if map_kernels::has_head(&(v670_3)) { singleton(&[]) } else { Space::new() };
    drop(v670_3);
    let v670_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v670_4));
    drop(v670_4);
    let v670_8: Space = if (&(v670_5)).is_empty() { Space::new() } else {
      let v671_6: Path = concat_path(&(*p0),&v669_27_cursor.path()[v669_27_origin..(v669_27_origin + 1)]);
      let mut v671_7 = Space::new();
      let mut v671_7_write = v671_7.write_zipper();
      for v671_7_byte in v669_27_cursor.child_mask().iter() {
        v669_27_cursor.descend_to_existing_byte(v671_7_byte);
        {
        let v672_2: Space = singleton(&v669_27_cursor.path()[(v669_27_origin + 1)..(v669_27_origin + 2)]);
        let v672_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v672_2));
        let v672_4: Space = if map_kernels::has_head(&(v672_3)) { singleton(&[]) } else { Space::new() };
        drop(v672_3);
        let v672_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v672_4));
        drop(v672_4);
        let v672_8: Space = if (&(v672_5)).is_empty() { Space::new() } else {
          let v673_6: Path = concat_path(&(v671_6),&v669_27_cursor.path()[(v669_27_origin + 1)..(v669_27_origin + 2)]);
          let mut v673_7 = Space::new();
          let mut v673_7_write = v673_7.write_zipper();
          for v673_7_byte in v669_27_cursor.child_mask().iter() {
            v669_27_cursor.descend_to_existing_byte(v673_7_byte);
            {
            let v674_2: Space = singleton(&v669_27_cursor.path()[(v669_27_origin + 2)..(v669_27_origin + 3)]);
            let v674_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v674_2));
            let v674_4: Space = if map_kernels::has_head(&(v674_3)) { singleton(&[]) } else { Space::new() };
            drop(v674_3);
            let v674_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v674_4));
            drop(v674_4);
            let v674_8: Space = if (&(v674_5)).is_empty() { Space::new() } else {
              let v675_6: Path = concat_path(&(v673_6),&v669_27_cursor.path()[(v669_27_origin + 2)..(v669_27_origin + 3)]);
              let v675_7: Space = routine_57(c, &(v675_6), &v669_27_cursor, &(*s1));
              map_map_kernels::compose(&(v674_5),&(v675_7))
            };
            drop(v674_5);
            let v674_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v674_2));
            drop(v674_2);
            let v674_10: Space = if map_kernels::has_head(&(v674_9)) { singleton(&[]) } else { Space::new() };
            drop(v674_9);
            let v674_12: Space = if (&(v674_10)).is_empty() { Space::new() } else {
              let v676_6: Path = concat_path(&(v673_6),&v669_27_cursor.path()[(v669_27_origin + 2)..(v669_27_origin + 3)]);
              let v676_11: Space = routine_58(c, &(v676_6), &v669_27_cursor, &(*s1));
              drop(v676_6);
              map_map_kernels::compose(&(v674_10),&(v676_11))
            };
            drop(v674_10);
            let v674_13: Space = map_map_kernels::unite(&(v674_8),&(v674_12));
            join_wrapped_into(&mut v673_7_write,&((v674_13).read_zipper()),&[]);
            }
            v669_27_cursor.ascend(1);
          }
          drop(v673_7_write);
          map_map_kernels::compose(&(v672_5),&(v673_7))
        };
        drop(v672_5);
        let v672_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v672_2));
        drop(v672_2);
        let v672_10: Space = if map_kernels::has_head(&(v672_9)) { singleton(&[]) } else { Space::new() };
        drop(v672_9);
        let v672_12: Space = if (&(v672_10)).is_empty() { Space::new() } else {
          let v677_6: Path = concat_path(&(v671_6),&v669_27_cursor.path()[(v669_27_origin + 1)..(v669_27_origin + 2)]);
          let mut v677_11 = Space::new();
          let mut v677_11_write = v677_11.write_zipper();
          for v677_11_byte in v669_27_cursor.child_mask().iter() {
            v669_27_cursor.descend_to_existing_byte(v677_11_byte);
            {
            let v678_2: Space = singleton(&v669_27_cursor.path()[(v669_27_origin + 2)..(v669_27_origin + 3)]);
            let v678_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v678_2));
            let v678_4: Space = if map_kernels::has_head(&(v678_3)) { singleton(&[]) } else { Space::new() };
            drop(v678_3);
            let v678_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v678_4));
            drop(v678_4);
            let v678_8: Space = if (&(v678_5)).is_empty() { Space::new() } else {
              let v679_6: Path = concat_path(&(v677_6),&v669_27_cursor.path()[(v669_27_origin + 2)..(v669_27_origin + 3)]);
              let v679_7: Space = routine_57(c, &(v679_6), &v669_27_cursor, &(*s1));
              map_map_kernels::compose(&(v678_5),&(v679_7))
            };
            drop(v678_5);
            let v678_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v678_2));
            drop(v678_2);
            let v678_10: Space = if map_kernels::has_head(&(v678_9)) { singleton(&[]) } else { Space::new() };
            drop(v678_9);
            let v678_12: Space = if (&(v678_10)).is_empty() { Space::new() } else {
              let v680_6: Path = concat_path(&(v677_6),&v669_27_cursor.path()[(v669_27_origin + 2)..(v669_27_origin + 3)]);
              let v680_11: Space = routine_33(c, &(v680_6), &v669_27_cursor, &(*s1));
              drop(v680_6);
              map_map_kernels::compose(&(v678_10),&(v680_11))
            };
            drop(v678_10);
            let v678_13: Space = map_map_kernels::unite(&(v678_8),&(v678_12));
            join_wrapped_into(&mut v677_11_write,&((v678_13).read_zipper()),&[]);
            }
            v669_27_cursor.ascend(1);
          }
          drop(v677_11_write);
          drop(v677_6);
          map_map_kernels::compose(&(v672_10),&(v677_11))
        };
        drop(v672_10);
        let v672_13: Space = map_map_kernels::unite(&(v672_8),&(v672_12));
        join_wrapped_into(&mut v671_7_write,&((v672_13).read_zipper()),&[]);
        }
        v669_27_cursor.ascend(1);
      }
      drop(v671_7_write);
      map_map_kernels::compose(&(v670_5),&(v671_7))
    };
    drop(v670_5);
    let v670_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v670_2));
    drop(v670_2);
    let v670_10: Space = if map_kernels::has_head(&(v670_9)) { singleton(&[]) } else { Space::new() };
    drop(v670_9);
    let v670_13: Space = if (&(v670_10)).is_empty() { Space::new() } else {
      let v681_6: Path = concat_path(&(*p0),&v669_27_cursor.path()[v669_27_origin..(v669_27_origin + 1)]);
      let mut v681_12 = Space::new();
      let mut v681_12_write = v681_12.write_zipper();
      for v681_12_byte in v669_27_cursor.child_mask().iter() {
        v669_27_cursor.descend_to_existing_byte(v681_12_byte);
        {
        let v682_2: Space = singleton(&v669_27_cursor.path()[(v669_27_origin + 1)..(v669_27_origin + 2)]);
        let v682_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v682_2));
        let v682_4: Space = if map_kernels::has_head(&(v682_3)) { singleton(&[]) } else { Space::new() };
        drop(v682_3);
        let v682_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v682_4));
        drop(v682_4);
        let v682_8: Space = if (&(v682_5)).is_empty() { Space::new() } else {
          let v683_6: Path = concat_path(&(v681_6),&v669_27_cursor.path()[(v669_27_origin + 1)..(v669_27_origin + 2)]);
          let mut v683_7 = Space::new();
          let mut v683_7_write = v683_7.write_zipper();
          for v683_7_byte in v669_27_cursor.child_mask().iter() {
            v669_27_cursor.descend_to_existing_byte(v683_7_byte);
            {
            let v684_2: Space = singleton(&v669_27_cursor.path()[(v669_27_origin + 2)..(v669_27_origin + 3)]);
            let v684_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v684_2));
            let v684_4: Space = if map_kernels::has_head(&(v684_3)) { singleton(&[]) } else { Space::new() };
            drop(v684_3);
            let v684_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v684_4));
            drop(v684_4);
            let v684_8: Space = if (&(v684_5)).is_empty() { Space::new() } else {
              let v685_6: Path = concat_path(&(v683_6),&v669_27_cursor.path()[(v669_27_origin + 2)..(v669_27_origin + 3)]);
              let v685_7: Space = routine_57(c, &(v685_6), &v669_27_cursor, &(*s1));
              map_map_kernels::compose(&(v684_5),&(v685_7))
            };
            drop(v684_5);
            let v684_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v684_2));
            drop(v684_2);
            let v684_10: Space = if map_kernels::has_head(&(v684_9)) { singleton(&[]) } else { Space::new() };
            drop(v684_9);
            let v684_12: Space = if (&(v684_10)).is_empty() { Space::new() } else {
              let v686_6: Path = concat_path(&(v683_6),&v669_27_cursor.path()[(v669_27_origin + 2)..(v669_27_origin + 3)]);
              let v686_11: Space = routine_58(c, &(v686_6), &v669_27_cursor, &(*s1));
              drop(v686_6);
              map_map_kernels::compose(&(v684_10),&(v686_11))
            };
            drop(v684_10);
            let v684_13: Space = map_map_kernels::unite(&(v684_8),&(v684_12));
            join_wrapped_into(&mut v683_7_write,&((v684_13).read_zipper()),&[]);
            }
            v669_27_cursor.ascend(1);
          }
          drop(v683_7_write);
          drop(v683_6);
          map_map_kernels::compose(&(v682_5),&(v683_7))
        };
        drop(v682_5);
        let v682_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v682_2));
        drop(v682_2);
        let v682_10: Space = if map_kernels::has_head(&(v682_9)) { singleton(&[]) } else { Space::new() };
        drop(v682_9);
        let v682_13: Space = if (&(v682_10)).is_empty() { Space::new() } else {
          let v687_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v669_27_cursor.path()[v669_27_origin..(v669_27_origin + 1)]),&v669_27_cursor.path()[(v669_27_origin + 1)..(v669_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v682_10),&(v687_12))
        };
        drop(v682_10);
        let v682_14: Space = map_map_kernels::unite(&(v682_8),&(v682_13));
        drop(v682_13);
        join_wrapped_into(&mut v681_12_write,&((v682_14).read_zipper()),&[]);
        }
        v669_27_cursor.ascend(1);
      }
      drop(v681_12_write);
      drop(v681_6);
      map_map_kernels::compose(&(v670_10),&(v681_12))
    };
    drop(v670_10);
    let v670_14: Space = map_map_kernels::unite(&(v670_8),&(v670_13));
    join_wrapped_into(&mut v669_27_write,&((v670_14).read_zipper()),&[]);
    }
    v669_27_cursor.ascend(1);
  }
  drop(v669_27_cursor);
  drop(v669_27_write);
  (v669_27).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v688_21 = Space::new();
  let mut v688_21_write = v688_21.write_zipper();
  let mut v688_21_cursor = (*s0).read_zipper();
  let v688_21_origin = v688_21_cursor.path().len();
  for v688_21_byte in v688_21_cursor.child_mask().iter() {
    v688_21_cursor.descend_to_existing_byte(v688_21_byte);
    {
    let v689_2: Space = singleton(&v688_21_cursor.path()[v688_21_origin..(v688_21_origin + 1)]);
    let v689_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v689_2));
    let v689_4: Space = if map_kernels::has_head(&(v689_3)) { singleton(&[]) } else { Space::new() };
    drop(v689_3);
    let v689_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v689_4));
    drop(v689_4);
    let v689_8: Space = if (&(v689_5)).is_empty() { Space::new() } else {
      let v690_6: Path = concat_path(&(*p0),&v688_21_cursor.path()[v688_21_origin..(v688_21_origin + 1)]);
      let mut v690_7 = Space::new();
      let mut v690_7_write = v690_7.write_zipper();
      for v690_7_byte in v688_21_cursor.child_mask().iter() {
        v688_21_cursor.descend_to_existing_byte(v690_7_byte);
        {
        let v691_2: Space = singleton(&v688_21_cursor.path()[(v688_21_origin + 1)..(v688_21_origin + 2)]);
        let v691_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v691_2));
        let v691_4: Space = if map_kernels::has_head(&(v691_3)) { singleton(&[]) } else { Space::new() };
        drop(v691_3);
        let v691_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v691_4));
        drop(v691_4);
        let v691_8: Space = if (&(v691_5)).is_empty() { Space::new() } else {
          let v692_6: Path = concat_path(&(v690_6),&v688_21_cursor.path()[(v688_21_origin + 1)..(v688_21_origin + 2)]);
          let mut v692_7 = Space::new();
          let mut v692_7_write = v692_7.write_zipper();
          for v692_7_byte in v688_21_cursor.child_mask().iter() {
            v688_21_cursor.descend_to_existing_byte(v692_7_byte);
            {
            let v693_2: Space = singleton(&v688_21_cursor.path()[(v688_21_origin + 2)..(v688_21_origin + 3)]);
            let v693_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v693_2));
            let v693_4: Space = if map_kernels::has_head(&(v693_3)) { singleton(&[]) } else { Space::new() };
            drop(v693_3);
            let v693_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v693_4));
            drop(v693_4);
            let v693_8: Space = if (&(v693_5)).is_empty() { Space::new() } else {
              let v694_6: Path = concat_path(&(v692_6),&v688_21_cursor.path()[(v688_21_origin + 2)..(v688_21_origin + 3)]);
              let v694_7: Space = routine_57(c, &(v694_6), &v688_21_cursor, &(*s1));
              map_map_kernels::compose(&(v693_5),&(v694_7))
            };
            drop(v693_5);
            let v693_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v693_2));
            drop(v693_2);
            let v693_10: Space = if map_kernels::has_head(&(v693_9)) { singleton(&[]) } else { Space::new() };
            drop(v693_9);
            let v693_12: Space = if (&(v693_10)).is_empty() { Space::new() } else {
              let v695_6: Path = concat_path(&(v692_6),&v688_21_cursor.path()[(v688_21_origin + 2)..(v688_21_origin + 3)]);
              let v695_11: Space = routine_58(c, &(v695_6), &v688_21_cursor, &(*s1));
              drop(v695_6);
              map_map_kernels::compose(&(v693_10),&(v695_11))
            };
            drop(v693_10);
            let v693_13: Space = map_map_kernels::unite(&(v693_8),&(v693_12));
            join_wrapped_into(&mut v692_7_write,&((v693_13).read_zipper()),&[]);
            }
            v688_21_cursor.ascend(1);
          }
          drop(v692_7_write);
          map_map_kernels::compose(&(v691_5),&(v692_7))
        };
        drop(v691_5);
        let v691_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v691_2));
        drop(v691_2);
        let v691_10: Space = if map_kernels::has_head(&(v691_9)) { singleton(&[]) } else { Space::new() };
        drop(v691_9);
        let v691_12: Space = if (&(v691_10)).is_empty() { Space::new() } else {
          let v696_6: Path = concat_path(&(v690_6),&v688_21_cursor.path()[(v688_21_origin + 1)..(v688_21_origin + 2)]);
          let mut v696_11 = Space::new();
          let mut v696_11_write = v696_11.write_zipper();
          for v696_11_byte in v688_21_cursor.child_mask().iter() {
            v688_21_cursor.descend_to_existing_byte(v696_11_byte);
            {
            let v697_2: Space = singleton(&v688_21_cursor.path()[(v688_21_origin + 2)..(v688_21_origin + 3)]);
            let v697_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v697_2));
            let v697_4: Space = if map_kernels::has_head(&(v697_3)) { singleton(&[]) } else { Space::new() };
            drop(v697_3);
            let v697_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v697_4));
            drop(v697_4);
            let v697_8: Space = if (&(v697_5)).is_empty() { Space::new() } else {
              let v698_6: Path = concat_path(&(v696_6),&v688_21_cursor.path()[(v688_21_origin + 2)..(v688_21_origin + 3)]);
              let v698_7: Space = routine_57(c, &(v698_6), &v688_21_cursor, &(*s1));
              map_map_kernels::compose(&(v697_5),&(v698_7))
            };
            drop(v697_5);
            let v697_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v697_2));
            drop(v697_2);
            let v697_10: Space = if map_kernels::has_head(&(v697_9)) { singleton(&[]) } else { Space::new() };
            drop(v697_9);
            let v697_12: Space = if (&(v697_10)).is_empty() { Space::new() } else {
              let v699_6: Path = concat_path(&(v696_6),&v688_21_cursor.path()[(v688_21_origin + 2)..(v688_21_origin + 3)]);
              let v699_11: Space = routine_33(c, &(v699_6), &v688_21_cursor, &(*s1));
              drop(v699_6);
              map_map_kernels::compose(&(v697_10),&(v699_11))
            };
            drop(v697_10);
            let v697_13: Space = map_map_kernels::unite(&(v697_8),&(v697_12));
            join_wrapped_into(&mut v696_11_write,&((v697_13).read_zipper()),&[]);
            }
            v688_21_cursor.ascend(1);
          }
          drop(v696_11_write);
          drop(v696_6);
          map_map_kernels::compose(&(v691_10),&(v696_11))
        };
        drop(v691_10);
        let v691_13: Space = map_map_kernels::unite(&(v691_8),&(v691_12));
        join_wrapped_into(&mut v690_7_write,&((v691_13).read_zipper()),&[]);
        }
        v688_21_cursor.ascend(1);
      }
      drop(v690_7_write);
      drop(v690_6);
      map_map_kernels::compose(&(v689_5),&(v690_7))
    };
    drop(v689_5);
    let v689_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v689_2));
    drop(v689_2);
    let v689_10: Space = if map_kernels::has_head(&(v689_9)) { singleton(&[]) } else { Space::new() };
    drop(v689_9);
    let v689_13: Space = if (&(v689_10)).is_empty() { Space::new() } else {
      let v700_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v688_21_cursor.path()[v688_21_origin..(v688_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v689_10),&(v700_12))
    };
    drop(v689_10);
    let v689_14: Space = map_map_kernels::unite(&(v689_8),&(v689_13));
    drop(v689_13);
    join_wrapped_into(&mut v688_21_write,&((v689_14).read_zipper()),&[]);
    }
    v688_21_cursor.ascend(1);
  }
  drop(v688_21_cursor);
  drop(v688_21_write);
  (v688_21).clone()
}

fn routine_36(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v701_27 = Space::new();
  let mut v701_27_write = v701_27.write_zipper();
  let mut v701_27_cursor = (*s0).read_zipper();
  let v701_27_origin = v701_27_cursor.path().len();
  for v701_27_byte in v701_27_cursor.child_mask().iter() {
    v701_27_cursor.descend_to_existing_byte(v701_27_byte);
    {
    let v702_2: Space = singleton(&v701_27_cursor.path()[v701_27_origin..(v701_27_origin + 1)]);
    let v702_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v702_2));
    let v702_4: Space = if map_kernels::has_head(&(v702_3)) { singleton(&[]) } else { Space::new() };
    drop(v702_3);
    let v702_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v702_4));
    drop(v702_4);
    let v702_8: Space = if (&(v702_5)).is_empty() { Space::new() } else {
      let v703_6: Path = concat_path(&(*p0),&v701_27_cursor.path()[v701_27_origin..(v701_27_origin + 1)]);
      let mut v703_7 = Space::new();
      let mut v703_7_write = v703_7.write_zipper();
      for v703_7_byte in v701_27_cursor.child_mask().iter() {
        v701_27_cursor.descend_to_existing_byte(v703_7_byte);
        {
        let v704_2: Space = singleton(&v701_27_cursor.path()[(v701_27_origin + 1)..(v701_27_origin + 2)]);
        let v704_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v704_2));
        let v704_4: Space = if map_kernels::has_head(&(v704_3)) { singleton(&[]) } else { Space::new() };
        drop(v704_3);
        let v704_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v704_4));
        drop(v704_4);
        let v704_8: Space = if (&(v704_5)).is_empty() { Space::new() } else {
          let v705_6: Path = concat_path(&(v703_6),&v701_27_cursor.path()[(v701_27_origin + 1)..(v701_27_origin + 2)]);
          let mut v705_7 = Space::new();
          let mut v705_7_write = v705_7.write_zipper();
          for v705_7_byte in v701_27_cursor.child_mask().iter() {
            v701_27_cursor.descend_to_existing_byte(v705_7_byte);
            {
            let v706_2: Space = singleton(&v701_27_cursor.path()[(v701_27_origin + 2)..(v701_27_origin + 3)]);
            let v706_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v706_2));
            let v706_4: Space = if map_kernels::has_head(&(v706_3)) { singleton(&[]) } else { Space::new() };
            drop(v706_3);
            let v706_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v706_4));
            drop(v706_4);
            let v706_8: Space = if (&(v706_5)).is_empty() { Space::new() } else {
              let v707_6: Path = concat_path(&(v705_6),&v701_27_cursor.path()[(v701_27_origin + 2)..(v701_27_origin + 3)]);
              let v707_7: Space = routine_59(c, &(v707_6), &v701_27_cursor, &(*s1));
              map_map_kernels::compose(&(v706_5),&(v707_7))
            };
            drop(v706_5);
            let v706_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v706_2));
            drop(v706_2);
            let v706_10: Space = if map_kernels::has_head(&(v706_9)) { singleton(&[]) } else { Space::new() };
            drop(v706_9);
            let v706_12: Space = if (&(v706_10)).is_empty() { Space::new() } else {
              let v708_6: Path = concat_path(&(v705_6),&v701_27_cursor.path()[(v701_27_origin + 2)..(v701_27_origin + 3)]);
              let v708_11: Space = routine_60(c, &(v708_6), &v701_27_cursor, &(*s1));
              drop(v708_6);
              map_map_kernels::compose(&(v706_10),&(v708_11))
            };
            drop(v706_10);
            let v706_13: Space = map_map_kernels::unite(&(v706_8),&(v706_12));
            join_wrapped_into(&mut v705_7_write,&((v706_13).read_zipper()),&[]);
            }
            v701_27_cursor.ascend(1);
          }
          drop(v705_7_write);
          map_map_kernels::compose(&(v704_5),&(v705_7))
        };
        drop(v704_5);
        let v704_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v704_2));
        drop(v704_2);
        let v704_10: Space = if map_kernels::has_head(&(v704_9)) { singleton(&[]) } else { Space::new() };
        drop(v704_9);
        let v704_12: Space = if (&(v704_10)).is_empty() { Space::new() } else {
          let v709_6: Path = concat_path(&(v703_6),&v701_27_cursor.path()[(v701_27_origin + 1)..(v701_27_origin + 2)]);
          let mut v709_11 = Space::new();
          let mut v709_11_write = v709_11.write_zipper();
          for v709_11_byte in v701_27_cursor.child_mask().iter() {
            v701_27_cursor.descend_to_existing_byte(v709_11_byte);
            {
            let v710_2: Space = singleton(&v701_27_cursor.path()[(v701_27_origin + 2)..(v701_27_origin + 3)]);
            let v710_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v710_2));
            let v710_4: Space = if map_kernels::has_head(&(v710_3)) { singleton(&[]) } else { Space::new() };
            drop(v710_3);
            let v710_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v710_4));
            drop(v710_4);
            let v710_8: Space = if (&(v710_5)).is_empty() { Space::new() } else {
              let v711_6: Path = concat_path(&(v709_6),&v701_27_cursor.path()[(v701_27_origin + 2)..(v701_27_origin + 3)]);
              let v711_7: Space = routine_59(c, &(v711_6), &v701_27_cursor, &(*s1));
              map_map_kernels::compose(&(v710_5),&(v711_7))
            };
            drop(v710_5);
            let v710_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v710_2));
            drop(v710_2);
            let v710_10: Space = if map_kernels::has_head(&(v710_9)) { singleton(&[]) } else { Space::new() };
            drop(v710_9);
            let v710_12: Space = if (&(v710_10)).is_empty() { Space::new() } else {
              let v712_6: Path = concat_path(&(v709_6),&v701_27_cursor.path()[(v701_27_origin + 2)..(v701_27_origin + 3)]);
              let v712_11: Space = routine_33(c, &(v712_6), &v701_27_cursor, &(*s1));
              drop(v712_6);
              map_map_kernels::compose(&(v710_10),&(v712_11))
            };
            drop(v710_10);
            let v710_13: Space = map_map_kernels::unite(&(v710_8),&(v710_12));
            join_wrapped_into(&mut v709_11_write,&((v710_13).read_zipper()),&[]);
            }
            v701_27_cursor.ascend(1);
          }
          drop(v709_11_write);
          drop(v709_6);
          map_map_kernels::compose(&(v704_10),&(v709_11))
        };
        drop(v704_10);
        let v704_13: Space = map_map_kernels::unite(&(v704_8),&(v704_12));
        join_wrapped_into(&mut v703_7_write,&((v704_13).read_zipper()),&[]);
        }
        v701_27_cursor.ascend(1);
      }
      drop(v703_7_write);
      map_map_kernels::compose(&(v702_5),&(v703_7))
    };
    drop(v702_5);
    let v702_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v702_2));
    drop(v702_2);
    let v702_10: Space = if map_kernels::has_head(&(v702_9)) { singleton(&[]) } else { Space::new() };
    drop(v702_9);
    let v702_13: Space = if (&(v702_10)).is_empty() { Space::new() } else {
      let v713_6: Path = concat_path(&(*p0),&v701_27_cursor.path()[v701_27_origin..(v701_27_origin + 1)]);
      let mut v713_12 = Space::new();
      let mut v713_12_write = v713_12.write_zipper();
      for v713_12_byte in v701_27_cursor.child_mask().iter() {
        v701_27_cursor.descend_to_existing_byte(v713_12_byte);
        {
        let v714_2: Space = singleton(&v701_27_cursor.path()[(v701_27_origin + 1)..(v701_27_origin + 2)]);
        let v714_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v714_2));
        let v714_4: Space = if map_kernels::has_head(&(v714_3)) { singleton(&[]) } else { Space::new() };
        drop(v714_3);
        let v714_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v714_4));
        drop(v714_4);
        let v714_8: Space = if (&(v714_5)).is_empty() { Space::new() } else {
          let v715_6: Path = concat_path(&(v713_6),&v701_27_cursor.path()[(v701_27_origin + 1)..(v701_27_origin + 2)]);
          let mut v715_7 = Space::new();
          let mut v715_7_write = v715_7.write_zipper();
          for v715_7_byte in v701_27_cursor.child_mask().iter() {
            v701_27_cursor.descend_to_existing_byte(v715_7_byte);
            {
            let v716_2: Space = singleton(&v701_27_cursor.path()[(v701_27_origin + 2)..(v701_27_origin + 3)]);
            let v716_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v716_2));
            let v716_4: Space = if map_kernels::has_head(&(v716_3)) { singleton(&[]) } else { Space::new() };
            drop(v716_3);
            let v716_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v716_4));
            drop(v716_4);
            let v716_8: Space = if (&(v716_5)).is_empty() { Space::new() } else {
              let v717_6: Path = concat_path(&(v715_6),&v701_27_cursor.path()[(v701_27_origin + 2)..(v701_27_origin + 3)]);
              let v717_7: Space = routine_59(c, &(v717_6), &v701_27_cursor, &(*s1));
              map_map_kernels::compose(&(v716_5),&(v717_7))
            };
            drop(v716_5);
            let v716_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v716_2));
            drop(v716_2);
            let v716_10: Space = if map_kernels::has_head(&(v716_9)) { singleton(&[]) } else { Space::new() };
            drop(v716_9);
            let v716_12: Space = if (&(v716_10)).is_empty() { Space::new() } else {
              let v718_6: Path = concat_path(&(v715_6),&v701_27_cursor.path()[(v701_27_origin + 2)..(v701_27_origin + 3)]);
              let v718_11: Space = routine_60(c, &(v718_6), &v701_27_cursor, &(*s1));
              drop(v718_6);
              map_map_kernels::compose(&(v716_10),&(v718_11))
            };
            drop(v716_10);
            let v716_13: Space = map_map_kernels::unite(&(v716_8),&(v716_12));
            join_wrapped_into(&mut v715_7_write,&((v716_13).read_zipper()),&[]);
            }
            v701_27_cursor.ascend(1);
          }
          drop(v715_7_write);
          drop(v715_6);
          map_map_kernels::compose(&(v714_5),&(v715_7))
        };
        drop(v714_5);
        let v714_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v714_2));
        drop(v714_2);
        let v714_10: Space = if map_kernels::has_head(&(v714_9)) { singleton(&[]) } else { Space::new() };
        drop(v714_9);
        let v714_13: Space = if (&(v714_10)).is_empty() { Space::new() } else {
          let v719_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v701_27_cursor.path()[v701_27_origin..(v701_27_origin + 1)]),&v701_27_cursor.path()[(v701_27_origin + 1)..(v701_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v714_10),&(v719_12))
        };
        drop(v714_10);
        let v714_14: Space = map_map_kernels::unite(&(v714_8),&(v714_13));
        drop(v714_13);
        join_wrapped_into(&mut v713_12_write,&((v714_14).read_zipper()),&[]);
        }
        v701_27_cursor.ascend(1);
      }
      drop(v713_12_write);
      drop(v713_6);
      map_map_kernels::compose(&(v702_10),&(v713_12))
    };
    drop(v702_10);
    let v702_14: Space = map_map_kernels::unite(&(v702_8),&(v702_13));
    join_wrapped_into(&mut v701_27_write,&((v702_14).read_zipper()),&[]);
    }
    v701_27_cursor.ascend(1);
  }
  drop(v701_27_cursor);
  drop(v701_27_write);
  (v701_27).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v720_21 = Space::new();
  let mut v720_21_write = v720_21.write_zipper();
  let mut v720_21_cursor = (*s0).read_zipper();
  let v720_21_origin = v720_21_cursor.path().len();
  for v720_21_byte in v720_21_cursor.child_mask().iter() {
    v720_21_cursor.descend_to_existing_byte(v720_21_byte);
    {
    let v721_2: Space = singleton(&v720_21_cursor.path()[v720_21_origin..(v720_21_origin + 1)]);
    let v721_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v721_2));
    let v721_4: Space = if map_kernels::has_head(&(v721_3)) { singleton(&[]) } else { Space::new() };
    drop(v721_3);
    let v721_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v721_4));
    drop(v721_4);
    let v721_8: Space = if (&(v721_5)).is_empty() { Space::new() } else {
      let v722_6: Path = concat_path(&(*p0),&v720_21_cursor.path()[v720_21_origin..(v720_21_origin + 1)]);
      let mut v722_7 = Space::new();
      let mut v722_7_write = v722_7.write_zipper();
      for v722_7_byte in v720_21_cursor.child_mask().iter() {
        v720_21_cursor.descend_to_existing_byte(v722_7_byte);
        {
        let v723_2: Space = singleton(&v720_21_cursor.path()[(v720_21_origin + 1)..(v720_21_origin + 2)]);
        let v723_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v723_2));
        let v723_4: Space = if map_kernels::has_head(&(v723_3)) { singleton(&[]) } else { Space::new() };
        drop(v723_3);
        let v723_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v723_4));
        drop(v723_4);
        let v723_8: Space = if (&(v723_5)).is_empty() { Space::new() } else {
          let v724_6: Path = concat_path(&(v722_6),&v720_21_cursor.path()[(v720_21_origin + 1)..(v720_21_origin + 2)]);
          let mut v724_7 = Space::new();
          let mut v724_7_write = v724_7.write_zipper();
          for v724_7_byte in v720_21_cursor.child_mask().iter() {
            v720_21_cursor.descend_to_existing_byte(v724_7_byte);
            {
            let v725_2: Space = singleton(&v720_21_cursor.path()[(v720_21_origin + 2)..(v720_21_origin + 3)]);
            let v725_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v725_2));
            let v725_4: Space = if map_kernels::has_head(&(v725_3)) { singleton(&[]) } else { Space::new() };
            drop(v725_3);
            let v725_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v725_4));
            drop(v725_4);
            let v725_8: Space = if (&(v725_5)).is_empty() { Space::new() } else {
              let v726_6: Path = concat_path(&(v724_6),&v720_21_cursor.path()[(v720_21_origin + 2)..(v720_21_origin + 3)]);
              let v726_7: Space = routine_59(c, &(v726_6), &v720_21_cursor, &(*s1));
              map_map_kernels::compose(&(v725_5),&(v726_7))
            };
            drop(v725_5);
            let v725_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v725_2));
            drop(v725_2);
            let v725_10: Space = if map_kernels::has_head(&(v725_9)) { singleton(&[]) } else { Space::new() };
            drop(v725_9);
            let v725_12: Space = if (&(v725_10)).is_empty() { Space::new() } else {
              let v727_6: Path = concat_path(&(v724_6),&v720_21_cursor.path()[(v720_21_origin + 2)..(v720_21_origin + 3)]);
              let v727_11: Space = routine_60(c, &(v727_6), &v720_21_cursor, &(*s1));
              drop(v727_6);
              map_map_kernels::compose(&(v725_10),&(v727_11))
            };
            drop(v725_10);
            let v725_13: Space = map_map_kernels::unite(&(v725_8),&(v725_12));
            join_wrapped_into(&mut v724_7_write,&((v725_13).read_zipper()),&[]);
            }
            v720_21_cursor.ascend(1);
          }
          drop(v724_7_write);
          map_map_kernels::compose(&(v723_5),&(v724_7))
        };
        drop(v723_5);
        let v723_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v723_2));
        drop(v723_2);
        let v723_10: Space = if map_kernels::has_head(&(v723_9)) { singleton(&[]) } else { Space::new() };
        drop(v723_9);
        let v723_12: Space = if (&(v723_10)).is_empty() { Space::new() } else {
          let v728_6: Path = concat_path(&(v722_6),&v720_21_cursor.path()[(v720_21_origin + 1)..(v720_21_origin + 2)]);
          let mut v728_11 = Space::new();
          let mut v728_11_write = v728_11.write_zipper();
          for v728_11_byte in v720_21_cursor.child_mask().iter() {
            v720_21_cursor.descend_to_existing_byte(v728_11_byte);
            {
            let v729_2: Space = singleton(&v720_21_cursor.path()[(v720_21_origin + 2)..(v720_21_origin + 3)]);
            let v729_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v729_2));
            let v729_4: Space = if map_kernels::has_head(&(v729_3)) { singleton(&[]) } else { Space::new() };
            drop(v729_3);
            let v729_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v729_4));
            drop(v729_4);
            let v729_8: Space = if (&(v729_5)).is_empty() { Space::new() } else {
              let v730_6: Path = concat_path(&(v728_6),&v720_21_cursor.path()[(v720_21_origin + 2)..(v720_21_origin + 3)]);
              let v730_7: Space = routine_59(c, &(v730_6), &v720_21_cursor, &(*s1));
              map_map_kernels::compose(&(v729_5),&(v730_7))
            };
            drop(v729_5);
            let v729_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v729_2));
            drop(v729_2);
            let v729_10: Space = if map_kernels::has_head(&(v729_9)) { singleton(&[]) } else { Space::new() };
            drop(v729_9);
            let v729_12: Space = if (&(v729_10)).is_empty() { Space::new() } else {
              let v731_6: Path = concat_path(&(v728_6),&v720_21_cursor.path()[(v720_21_origin + 2)..(v720_21_origin + 3)]);
              let v731_11: Space = routine_33(c, &(v731_6), &v720_21_cursor, &(*s1));
              drop(v731_6);
              map_map_kernels::compose(&(v729_10),&(v731_11))
            };
            drop(v729_10);
            let v729_13: Space = map_map_kernels::unite(&(v729_8),&(v729_12));
            join_wrapped_into(&mut v728_11_write,&((v729_13).read_zipper()),&[]);
            }
            v720_21_cursor.ascend(1);
          }
          drop(v728_11_write);
          drop(v728_6);
          map_map_kernels::compose(&(v723_10),&(v728_11))
        };
        drop(v723_10);
        let v723_13: Space = map_map_kernels::unite(&(v723_8),&(v723_12));
        join_wrapped_into(&mut v722_7_write,&((v723_13).read_zipper()),&[]);
        }
        v720_21_cursor.ascend(1);
      }
      drop(v722_7_write);
      drop(v722_6);
      map_map_kernels::compose(&(v721_5),&(v722_7))
    };
    drop(v721_5);
    let v721_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v721_2));
    drop(v721_2);
    let v721_10: Space = if map_kernels::has_head(&(v721_9)) { singleton(&[]) } else { Space::new() };
    drop(v721_9);
    let v721_13: Space = if (&(v721_10)).is_empty() { Space::new() } else {
      let v732_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v720_21_cursor.path()[v720_21_origin..(v720_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v721_10),&(v732_12))
    };
    drop(v721_10);
    let v721_14: Space = map_map_kernels::unite(&(v721_8),&(v721_13));
    drop(v721_13);
    join_wrapped_into(&mut v720_21_write,&((v721_14).read_zipper()),&[]);
    }
    v720_21_cursor.ascend(1);
  }
  drop(v720_21_cursor);
  drop(v720_21_write);
  (v720_21).clone()
}

fn routine_38(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v733_5 = Space::new();
  let mut v733_5_write = v733_5.write_zipper();
  let mut v733_5_cursor = (*s0).read_zipper();
  let v733_5_origin = v733_5_cursor.path().len();
  for v733_5_byte in v733_5_cursor.child_mask().iter() {
    v733_5_cursor.descend_to_existing_byte(v733_5_byte);
    {
    let v734_2: Space = singleton(&v733_5_cursor.path()[v733_5_origin..(v733_5_origin + 1)]);
    let v734_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v734_2));
    drop(v734_2);
    let v734_4: Space = if map_kernels::has_head(&(v734_3)) { singleton(&[]) } else { Space::new() };
    drop(v734_3);
    let v734_7: Space = if (&(v734_4)).is_empty() { Space::new() } else {
      let v735_5: Path = concat_path(&(*p0),&v733_5_cursor.path()[v733_5_origin..(v733_5_origin + 1)]);
      let mut v735_6 = Space::new();
      let mut v735_6_write = v735_6.write_zipper();
      for v735_6_byte in v733_5_cursor.child_mask().iter() {
        v733_5_cursor.descend_to_existing_byte(v735_6_byte);
        {
        let v736_2: Space = singleton(&v733_5_cursor.path()[(v733_5_origin + 1)..(v733_5_origin + 2)]);
        let v736_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v736_2));
        drop(v736_2);
        let v736_4: Space = if map_kernels::has_head(&(v736_3)) { singleton(&[]) } else { Space::new() };
        drop(v736_3);
        let v736_6: Space = if (&(v736_4)).is_empty() { Space::new() } else {
          let v737_5: Space = view_map_kernels::subtract(&v733_5_cursor,&(*CONSTANT_5));
          map_map_kernels::compose(&(v736_4),&(v737_5))
        };
        drop(v736_4);
        let v736_7: Path = concat_path(&(v735_5),&v733_5_cursor.path()[(v733_5_origin + 1)..(v733_5_origin + 2)]);
        join_wrapped_into(&mut v735_6_write,&((v736_6).read_zipper()),&(v736_7));
        drop(v736_6);
        drop(v736_7);
        }
        v733_5_cursor.ascend(1);
      }
      drop(v735_6_write);
      drop(v735_5);
      map_map_kernels::compose(&(v734_4),&(v735_6))
    };
    drop(v734_4);
    join_wrapped_into(&mut v733_5_write,&((v734_7).read_zipper()),&[]);
    }
    v733_5_cursor.ascend(1);
  }
  drop(v733_5_cursor);
  drop(v733_5_write);
  (v733_5).clone()
}

fn routine_39(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v738_4 = Space::new();
  let mut v738_4_write = v738_4.write_zipper();
  let mut v738_4_cursor = (*s0).read_zipper();
  let v738_4_origin = v738_4_cursor.path().len();
  for v738_4_byte in v738_4_cursor.child_mask().iter() {
    v738_4_cursor.descend_to_existing_byte(v738_4_byte);
    {
    let v739_2: Space = singleton(&v738_4_cursor.path()[v738_4_origin..(v738_4_origin + 1)]);
    let v739_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v739_2));
    drop(v739_2);
    let v739_4: Space = if map_kernels::has_head(&(v739_3)) { singleton(&[]) } else { Space::new() };
    drop(v739_3);
    let v739_6: Space = if (&(v739_4)).is_empty() { Space::new() } else {
      let v740_5: Space = view_map_kernels::subtract(&v738_4_cursor,&(*CONSTANT_5));
      map_map_kernels::compose(&(v739_4),&(v740_5))
    };
    drop(v739_4);
    let v739_7: Path = concat_path(&(*p0),&v738_4_cursor.path()[v738_4_origin..(v738_4_origin + 1)]);
    join_wrapped_into(&mut v738_4_write,&((v739_6).read_zipper()),&(v739_7));
    drop(v739_6);
    drop(v739_7);
    }
    v738_4_cursor.ascend(1);
  }
  drop(v738_4_cursor);
  drop(v738_4_write);
  (v738_4).clone()
}

fn routine_40(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v741_8 = Space::new();
  let mut v741_8_write = v741_8.write_zipper();
  let mut v741_8_cursor = (*s0).read_zipper();
  let v741_8_origin = v741_8_cursor.path().len();
  for v741_8_byte in v741_8_cursor.child_mask().iter() {
    v741_8_cursor.descend_to_existing_byte(v741_8_byte);
    {
    let v742_2: Space = singleton(&v741_8_cursor.path()[v741_8_origin..(v741_8_origin + 1)]);
    let v742_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v742_2));
    drop(v742_2);
    let v742_4: Space = if map_kernels::has_head(&(v742_3)) { singleton(&[]) } else { Space::new() };
    drop(v742_3);
    let v742_7: Space = if (&(v742_4)).is_empty() { Space::new() } else {
      let v743_5: Path = concat_path(&(*p0),&v741_8_cursor.path()[v741_8_origin..(v741_8_origin + 1)]);
      let mut v743_6 = Space::new();
      let mut v743_6_write = v743_6.write_zipper();
      for v743_6_byte in v741_8_cursor.child_mask().iter() {
        v741_8_cursor.descend_to_existing_byte(v743_6_byte);
        {
        let v744_2: Space = singleton(&v741_8_cursor.path()[(v741_8_origin + 1)..(v741_8_origin + 2)]);
        let v744_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v744_2));
        drop(v744_2);
        let v744_4: Space = if map_kernels::has_head(&(v744_3)) { singleton(&[]) } else { Space::new() };
        drop(v744_3);
        let v744_6: Space = if (&(v744_4)).is_empty() { Space::new() } else {
          let mut v745_5 = Space::new();
          let mut v745_5_write = v745_5.write_zipper();
          for v745_5_byte in v741_8_cursor.child_mask().iter() {
            v741_8_cursor.descend_to_existing_byte(v745_5_byte);
            {
            let v746_2: Space = singleton(&v741_8_cursor.path()[(v741_8_origin + 2)..(v741_8_origin + 3)]);
            let v746_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v746_2));
            let v746_4: Space = if map_kernels::has_head(&(v746_3)) { singleton(&[]) } else { Space::new() };
            drop(v746_3);
            let v746_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v746_4));
            drop(v746_4);
            let v746_7: Space = if (&(v746_5)).is_empty() { Space::new() } else {
              let v747_6: Space = routine_18(c, &v741_8_cursor.path()[(v741_8_origin + 2)..(v741_8_origin + 3)], &v741_8_cursor, &(*s1));
              map_map_kernels::compose(&(v746_5),&(v747_6))
            };
            drop(v746_5);
            let v746_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v746_2));
            drop(v746_2);
            let v746_9: Space = if map_kernels::has_head(&(v746_8)) { singleton(&[]) } else { Space::new() };
            drop(v746_8);
            let v746_11: Space = if (&(v746_9)).is_empty() { Space::new() } else {
              let v748_10: Space = routine_19(c, &v741_8_cursor.path()[(v741_8_origin + 2)..(v741_8_origin + 3)], &v741_8_cursor, &(*s1));
              map_map_kernels::compose(&(v746_9),&(v748_10))
            };
            drop(v746_9);
            let v746_12: Space = map_map_kernels::unite(&(v746_7),&(v746_11));
            join_wrapped_into(&mut v745_5_write,&((v746_12).read_zipper()),&[]);
            }
            v741_8_cursor.ascend(1);
          }
          drop(v745_5_write);
          map_map_kernels::compose(&(v744_4),&(v745_5))
        };
        drop(v744_4);
        let v744_7: Path = concat_path(&(v743_5),&v741_8_cursor.path()[(v741_8_origin + 1)..(v741_8_origin + 2)]);
        join_wrapped_into(&mut v743_6_write,&((v744_6).read_zipper()),&(v744_7));
        drop(v744_7);
        }
        v741_8_cursor.ascend(1);
      }
      drop(v743_6_write);
      drop(v743_5);
      map_map_kernels::compose(&(v742_4),&(v743_6))
    };
    drop(v742_4);
    join_wrapped_into(&mut v741_8_write,&((v742_7).read_zipper()),&[]);
    }
    v741_8_cursor.ascend(1);
  }
  drop(v741_8_cursor);
  drop(v741_8_write);
  (v741_8).clone()
}

fn routine_41(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v749_13 = Space::new();
  let mut v749_13_write = v749_13.write_zipper();
  let mut v749_13_cursor = (*s0).read_zipper();
  let v749_13_origin = v749_13_cursor.path().len();
  for v749_13_byte in v749_13_cursor.child_mask().iter() {
    v749_13_cursor.descend_to_existing_byte(v749_13_byte);
    {
    let v750_2: Space = singleton(&v749_13_cursor.path()[v749_13_origin..(v749_13_origin + 1)]);
    let v750_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v750_2));
    drop(v750_2);
    let v750_4: Space = if map_kernels::has_head(&(v750_3)) { singleton(&[]) } else { Space::new() };
    drop(v750_3);
    let v750_6: Space = if (&(v750_4)).is_empty() { Space::new() } else {
      let mut v751_5 = Space::new();
      let mut v751_5_write = v751_5.write_zipper();
      for v751_5_byte in v749_13_cursor.child_mask().iter() {
        v749_13_cursor.descend_to_existing_byte(v751_5_byte);
        {
        let v752_2: Space = singleton(&v749_13_cursor.path()[(v749_13_origin + 1)..(v749_13_origin + 2)]);
        let v752_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v752_2));
        let v752_4: Space = if map_kernels::has_head(&(v752_3)) { singleton(&[]) } else { Space::new() };
        drop(v752_3);
        let v752_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v752_4));
        drop(v752_4);
        let v752_7: Space = if (&(v752_5)).is_empty() { Space::new() } else {
          let mut v753_6 = Space::new();
          let mut v753_6_write = v753_6.write_zipper();
          for v753_6_byte in v749_13_cursor.child_mask().iter() {
            v749_13_cursor.descend_to_existing_byte(v753_6_byte);
            {
            let v754_2: Space = singleton(&v749_13_cursor.path()[(v749_13_origin + 2)..(v749_13_origin + 3)]);
            let v754_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v754_2));
            let v754_4: Space = if map_kernels::has_head(&(v754_3)) { singleton(&[]) } else { Space::new() };
            drop(v754_3);
            let v754_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v754_4));
            drop(v754_4);
            let v754_8: Space = if (&(v754_5)).is_empty() { Space::new() } else {
              let v755_7: Space = routine_42(c, &v749_13_cursor.path()[(v749_13_origin + 1)..(v749_13_origin + 3)], &v749_13_cursor, &(*s1));
              map_map_kernels::compose(&(v754_5),&(v755_7))
            };
            drop(v754_5);
            let v754_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v754_2));
            drop(v754_2);
            let v754_10: Space = if map_kernels::has_head(&(v754_9)) { singleton(&[]) } else { Space::new() };
            drop(v754_9);
            let v754_12: Space = if (&(v754_10)).is_empty() { Space::new() } else {
              let v756_11: Space = routine_43(c, &v749_13_cursor.path()[(v749_13_origin + 1)..(v749_13_origin + 3)], &v749_13_cursor, &(*s1));
              map_map_kernels::compose(&(v754_10),&(v756_11))
            };
            drop(v754_10);
            let v754_13: Space = map_map_kernels::unite(&(v754_8),&(v754_12));
            join_wrapped_into(&mut v753_6_write,&((v754_13).read_zipper()),&[]);
            }
            v749_13_cursor.ascend(1);
          }
          drop(v753_6_write);
          map_map_kernels::compose(&(v752_5),&(v753_6))
        };
        drop(v752_5);
        let v752_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v752_2));
        drop(v752_2);
        let v752_9: Space = if map_kernels::has_head(&(v752_8)) { singleton(&[]) } else { Space::new() };
        drop(v752_8);
        let v752_11: Space = if (&(v752_9)).is_empty() { Space::new() } else {
          let mut v757_10 = Space::new();
          let mut v757_10_write = v757_10.write_zipper();
          for v757_10_byte in v749_13_cursor.child_mask().iter() {
            v749_13_cursor.descend_to_existing_byte(v757_10_byte);
            {
            let v758_2: Space = singleton(&v749_13_cursor.path()[(v749_13_origin + 2)..(v749_13_origin + 3)]);
            let v758_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v758_2));
            let v758_4: Space = if map_kernels::has_head(&(v758_3)) { singleton(&[]) } else { Space::new() };
            drop(v758_3);
            let v758_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v758_4));
            drop(v758_4);
            let v758_8: Space = if (&(v758_5)).is_empty() { Space::new() } else {
              let v759_7: Space = routine_42(c, &v749_13_cursor.path()[(v749_13_origin + 1)..(v749_13_origin + 3)], &v749_13_cursor, &(*s1));
              map_map_kernels::compose(&(v758_5),&(v759_7))
            };
            drop(v758_5);
            let v758_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v758_2));
            drop(v758_2);
            let v758_10: Space = if map_kernels::has_head(&(v758_9)) { singleton(&[]) } else { Space::new() };
            drop(v758_9);
            let v758_12: Space = if (&(v758_10)).is_empty() { Space::new() } else {
              let v760_11: Space = routine_44(c, &v749_13_cursor.path()[(v749_13_origin + 1)..(v749_13_origin + 3)], &v749_13_cursor, &(*s1));
              map_map_kernels::compose(&(v758_10),&(v760_11))
            };
            drop(v758_10);
            let v758_13: Space = map_map_kernels::unite(&(v758_8),&(v758_12));
            join_wrapped_into(&mut v757_10_write,&((v758_13).read_zipper()),&[]);
            }
            v749_13_cursor.ascend(1);
          }
          drop(v757_10_write);
          map_map_kernels::compose(&(v752_9),&(v757_10))
        };
        drop(v752_9);
        let v752_12: Space = map_map_kernels::unite(&(v752_7),&(v752_11));
        join_wrapped_into(&mut v751_5_write,&((v752_12).read_zipper()),&[]);
        }
        v749_13_cursor.ascend(1);
      }
      drop(v751_5_write);
      map_map_kernels::compose(&(v750_4),&(v751_5))
    };
    drop(v750_4);
    let v750_7: Path = concat_path(&(*p0),&v749_13_cursor.path()[v749_13_origin..(v749_13_origin + 1)]);
    join_wrapped_into(&mut v749_13_write,&((v750_6).read_zipper()),&(v750_7));
    drop(v750_7);
    }
    v749_13_cursor.ascend(1);
  }
  drop(v749_13_cursor);
  drop(v749_13_write);
  (v749_13).clone()
}

fn routine_42(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v761_27 = Space::new();
  let mut v761_27_write = v761_27.write_zipper();
  let mut v761_27_cursor = (*s0).read_zipper();
  let v761_27_origin = v761_27_cursor.path().len();
  for v761_27_byte in v761_27_cursor.child_mask().iter() {
    v761_27_cursor.descend_to_existing_byte(v761_27_byte);
    {
    let v762_2: Space = singleton(&v761_27_cursor.path()[v761_27_origin..(v761_27_origin + 1)]);
    let v762_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v762_2));
    let v762_4: Space = if map_kernels::has_head(&(v762_3)) { singleton(&[]) } else { Space::new() };
    drop(v762_3);
    let v762_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v762_4));
    drop(v762_4);
    let v762_8: Space = if (&(v762_5)).is_empty() { Space::new() } else {
      let v763_6: Path = concat_path(&(*p0),&v761_27_cursor.path()[v761_27_origin..(v761_27_origin + 1)]);
      let mut v763_7 = Space::new();
      let mut v763_7_write = v763_7.write_zipper();
      for v763_7_byte in v761_27_cursor.child_mask().iter() {
        v761_27_cursor.descend_to_existing_byte(v763_7_byte);
        {
        let v764_2: Space = singleton(&v761_27_cursor.path()[(v761_27_origin + 1)..(v761_27_origin + 2)]);
        let v764_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v764_2));
        let v764_4: Space = if map_kernels::has_head(&(v764_3)) { singleton(&[]) } else { Space::new() };
        drop(v764_3);
        let v764_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v764_4));
        drop(v764_4);
        let v764_8: Space = if (&(v764_5)).is_empty() { Space::new() } else {
          let v765_6: Path = concat_path(&(v763_6),&v761_27_cursor.path()[(v761_27_origin + 1)..(v761_27_origin + 2)]);
          let mut v765_7 = Space::new();
          let mut v765_7_write = v765_7.write_zipper();
          for v765_7_byte in v761_27_cursor.child_mask().iter() {
            v761_27_cursor.descend_to_existing_byte(v765_7_byte);
            {
            let v766_2: Space = singleton(&v761_27_cursor.path()[(v761_27_origin + 2)..(v761_27_origin + 3)]);
            let v766_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v766_2));
            let v766_4: Space = if map_kernels::has_head(&(v766_3)) { singleton(&[]) } else { Space::new() };
            drop(v766_3);
            let v766_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v766_4));
            drop(v766_4);
            let v766_8: Space = if (&(v766_5)).is_empty() { Space::new() } else {
              let v767_6: Path = concat_path(&(v765_6),&v761_27_cursor.path()[(v761_27_origin + 2)..(v761_27_origin + 3)]);
              let v767_7: Space = routine_61(c, &(v767_6), &v761_27_cursor, &(*s1));
              map_map_kernels::compose(&(v766_5),&(v767_7))
            };
            drop(v766_5);
            let v766_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v766_2));
            drop(v766_2);
            let v766_10: Space = if map_kernels::has_head(&(v766_9)) { singleton(&[]) } else { Space::new() };
            drop(v766_9);
            let v766_12: Space = if (&(v766_10)).is_empty() { Space::new() } else {
              let v768_6: Path = concat_path(&(v765_6),&v761_27_cursor.path()[(v761_27_origin + 2)..(v761_27_origin + 3)]);
              let v768_11: Space = routine_62(c, &(v768_6), &v761_27_cursor, &(*s1));
              drop(v768_6);
              map_map_kernels::compose(&(v766_10),&(v768_11))
            };
            drop(v766_10);
            let v766_13: Space = map_map_kernels::unite(&(v766_8),&(v766_12));
            join_wrapped_into(&mut v765_7_write,&((v766_13).read_zipper()),&[]);
            }
            v761_27_cursor.ascend(1);
          }
          drop(v765_7_write);
          map_map_kernels::compose(&(v764_5),&(v765_7))
        };
        drop(v764_5);
        let v764_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v764_2));
        drop(v764_2);
        let v764_10: Space = if map_kernels::has_head(&(v764_9)) { singleton(&[]) } else { Space::new() };
        drop(v764_9);
        let v764_12: Space = if (&(v764_10)).is_empty() { Space::new() } else {
          let v769_6: Path = concat_path(&(v763_6),&v761_27_cursor.path()[(v761_27_origin + 1)..(v761_27_origin + 2)]);
          let mut v769_11 = Space::new();
          let mut v769_11_write = v769_11.write_zipper();
          for v769_11_byte in v761_27_cursor.child_mask().iter() {
            v761_27_cursor.descend_to_existing_byte(v769_11_byte);
            {
            let v770_2: Space = singleton(&v761_27_cursor.path()[(v761_27_origin + 2)..(v761_27_origin + 3)]);
            let v770_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v770_2));
            let v770_4: Space = if map_kernels::has_head(&(v770_3)) { singleton(&[]) } else { Space::new() };
            drop(v770_3);
            let v770_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v770_4));
            drop(v770_4);
            let v770_8: Space = if (&(v770_5)).is_empty() { Space::new() } else {
              let v771_6: Path = concat_path(&(v769_6),&v761_27_cursor.path()[(v761_27_origin + 2)..(v761_27_origin + 3)]);
              let v771_7: Space = routine_61(c, &(v771_6), &v761_27_cursor, &(*s1));
              map_map_kernels::compose(&(v770_5),&(v771_7))
            };
            drop(v770_5);
            let v770_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v770_2));
            drop(v770_2);
            let v770_10: Space = if map_kernels::has_head(&(v770_9)) { singleton(&[]) } else { Space::new() };
            drop(v770_9);
            let v770_12: Space = if (&(v770_10)).is_empty() { Space::new() } else {
              let v772_6: Path = concat_path(&(v769_6),&v761_27_cursor.path()[(v761_27_origin + 2)..(v761_27_origin + 3)]);
              let v772_11: Space = routine_44(c, &(v772_6), &v761_27_cursor, &(*s1));
              drop(v772_6);
              map_map_kernels::compose(&(v770_10),&(v772_11))
            };
            drop(v770_10);
            let v770_13: Space = map_map_kernels::unite(&(v770_8),&(v770_12));
            join_wrapped_into(&mut v769_11_write,&((v770_13).read_zipper()),&[]);
            }
            v761_27_cursor.ascend(1);
          }
          drop(v769_11_write);
          drop(v769_6);
          map_map_kernels::compose(&(v764_10),&(v769_11))
        };
        drop(v764_10);
        let v764_13: Space = map_map_kernels::unite(&(v764_8),&(v764_12));
        join_wrapped_into(&mut v763_7_write,&((v764_13).read_zipper()),&[]);
        }
        v761_27_cursor.ascend(1);
      }
      drop(v763_7_write);
      map_map_kernels::compose(&(v762_5),&(v763_7))
    };
    drop(v762_5);
    let v762_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v762_2));
    drop(v762_2);
    let v762_10: Space = if map_kernels::has_head(&(v762_9)) { singleton(&[]) } else { Space::new() };
    drop(v762_9);
    let v762_13: Space = if (&(v762_10)).is_empty() { Space::new() } else {
      let v773_6: Path = concat_path(&(*p0),&v761_27_cursor.path()[v761_27_origin..(v761_27_origin + 1)]);
      let mut v773_12 = Space::new();
      let mut v773_12_write = v773_12.write_zipper();
      for v773_12_byte in v761_27_cursor.child_mask().iter() {
        v761_27_cursor.descend_to_existing_byte(v773_12_byte);
        {
        let v774_2: Space = singleton(&v761_27_cursor.path()[(v761_27_origin + 1)..(v761_27_origin + 2)]);
        let v774_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v774_2));
        let v774_4: Space = if map_kernels::has_head(&(v774_3)) { singleton(&[]) } else { Space::new() };
        drop(v774_3);
        let v774_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v774_4));
        drop(v774_4);
        let v774_8: Space = if (&(v774_5)).is_empty() { Space::new() } else {
          let v775_6: Path = concat_path(&(v773_6),&v761_27_cursor.path()[(v761_27_origin + 1)..(v761_27_origin + 2)]);
          let mut v775_7 = Space::new();
          let mut v775_7_write = v775_7.write_zipper();
          for v775_7_byte in v761_27_cursor.child_mask().iter() {
            v761_27_cursor.descend_to_existing_byte(v775_7_byte);
            {
            let v776_2: Space = singleton(&v761_27_cursor.path()[(v761_27_origin + 2)..(v761_27_origin + 3)]);
            let v776_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v776_2));
            let v776_4: Space = if map_kernels::has_head(&(v776_3)) { singleton(&[]) } else { Space::new() };
            drop(v776_3);
            let v776_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v776_4));
            drop(v776_4);
            let v776_8: Space = if (&(v776_5)).is_empty() { Space::new() } else {
              let v777_6: Path = concat_path(&(v775_6),&v761_27_cursor.path()[(v761_27_origin + 2)..(v761_27_origin + 3)]);
              let v777_7: Space = routine_61(c, &(v777_6), &v761_27_cursor, &(*s1));
              map_map_kernels::compose(&(v776_5),&(v777_7))
            };
            drop(v776_5);
            let v776_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v776_2));
            drop(v776_2);
            let v776_10: Space = if map_kernels::has_head(&(v776_9)) { singleton(&[]) } else { Space::new() };
            drop(v776_9);
            let v776_12: Space = if (&(v776_10)).is_empty() { Space::new() } else {
              let v778_6: Path = concat_path(&(v775_6),&v761_27_cursor.path()[(v761_27_origin + 2)..(v761_27_origin + 3)]);
              let v778_11: Space = routine_62(c, &(v778_6), &v761_27_cursor, &(*s1));
              drop(v778_6);
              map_map_kernels::compose(&(v776_10),&(v778_11))
            };
            drop(v776_10);
            let v776_13: Space = map_map_kernels::unite(&(v776_8),&(v776_12));
            join_wrapped_into(&mut v775_7_write,&((v776_13).read_zipper()),&[]);
            }
            v761_27_cursor.ascend(1);
          }
          drop(v775_7_write);
          drop(v775_6);
          map_map_kernels::compose(&(v774_5),&(v775_7))
        };
        drop(v774_5);
        let v774_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v774_2));
        drop(v774_2);
        let v774_10: Space = if map_kernels::has_head(&(v774_9)) { singleton(&[]) } else { Space::new() };
        drop(v774_9);
        let v774_13: Space = if (&(v774_10)).is_empty() { Space::new() } else {
          let v779_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v761_27_cursor.path()[v761_27_origin..(v761_27_origin + 1)]),&v761_27_cursor.path()[(v761_27_origin + 1)..(v761_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v774_10),&(v779_12))
        };
        drop(v774_10);
        let v774_14: Space = map_map_kernels::unite(&(v774_8),&(v774_13));
        drop(v774_13);
        join_wrapped_into(&mut v773_12_write,&((v774_14).read_zipper()),&[]);
        }
        v761_27_cursor.ascend(1);
      }
      drop(v773_12_write);
      drop(v773_6);
      map_map_kernels::compose(&(v762_10),&(v773_12))
    };
    drop(v762_10);
    let v762_14: Space = map_map_kernels::unite(&(v762_8),&(v762_13));
    join_wrapped_into(&mut v761_27_write,&((v762_14).read_zipper()),&[]);
    }
    v761_27_cursor.ascend(1);
  }
  drop(v761_27_cursor);
  drop(v761_27_write);
  (v761_27).clone()
}

fn routine_43(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v780_21 = Space::new();
  let mut v780_21_write = v780_21.write_zipper();
  let mut v780_21_cursor = (*s0).read_zipper();
  let v780_21_origin = v780_21_cursor.path().len();
  for v780_21_byte in v780_21_cursor.child_mask().iter() {
    v780_21_cursor.descend_to_existing_byte(v780_21_byte);
    {
    let v781_2: Space = singleton(&v780_21_cursor.path()[v780_21_origin..(v780_21_origin + 1)]);
    let v781_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v781_2));
    let v781_4: Space = if map_kernels::has_head(&(v781_3)) { singleton(&[]) } else { Space::new() };
    drop(v781_3);
    let v781_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v781_4));
    drop(v781_4);
    let v781_8: Space = if (&(v781_5)).is_empty() { Space::new() } else {
      let v782_6: Path = concat_path(&(*p0),&v780_21_cursor.path()[v780_21_origin..(v780_21_origin + 1)]);
      let mut v782_7 = Space::new();
      let mut v782_7_write = v782_7.write_zipper();
      for v782_7_byte in v780_21_cursor.child_mask().iter() {
        v780_21_cursor.descend_to_existing_byte(v782_7_byte);
        {
        let v783_2: Space = singleton(&v780_21_cursor.path()[(v780_21_origin + 1)..(v780_21_origin + 2)]);
        let v783_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v783_2));
        let v783_4: Space = if map_kernels::has_head(&(v783_3)) { singleton(&[]) } else { Space::new() };
        drop(v783_3);
        let v783_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v783_4));
        drop(v783_4);
        let v783_8: Space = if (&(v783_5)).is_empty() { Space::new() } else {
          let v784_6: Path = concat_path(&(v782_6),&v780_21_cursor.path()[(v780_21_origin + 1)..(v780_21_origin + 2)]);
          let mut v784_7 = Space::new();
          let mut v784_7_write = v784_7.write_zipper();
          for v784_7_byte in v780_21_cursor.child_mask().iter() {
            v780_21_cursor.descend_to_existing_byte(v784_7_byte);
            {
            let v785_2: Space = singleton(&v780_21_cursor.path()[(v780_21_origin + 2)..(v780_21_origin + 3)]);
            let v785_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v785_2));
            let v785_4: Space = if map_kernels::has_head(&(v785_3)) { singleton(&[]) } else { Space::new() };
            drop(v785_3);
            let v785_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v785_4));
            drop(v785_4);
            let v785_8: Space = if (&(v785_5)).is_empty() { Space::new() } else {
              let v786_6: Path = concat_path(&(v784_6),&v780_21_cursor.path()[(v780_21_origin + 2)..(v780_21_origin + 3)]);
              let v786_7: Space = routine_61(c, &(v786_6), &v780_21_cursor, &(*s1));
              map_map_kernels::compose(&(v785_5),&(v786_7))
            };
            drop(v785_5);
            let v785_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v785_2));
            drop(v785_2);
            let v785_10: Space = if map_kernels::has_head(&(v785_9)) { singleton(&[]) } else { Space::new() };
            drop(v785_9);
            let v785_12: Space = if (&(v785_10)).is_empty() { Space::new() } else {
              let v787_6: Path = concat_path(&(v784_6),&v780_21_cursor.path()[(v780_21_origin + 2)..(v780_21_origin + 3)]);
              let v787_11: Space = routine_62(c, &(v787_6), &v780_21_cursor, &(*s1));
              drop(v787_6);
              map_map_kernels::compose(&(v785_10),&(v787_11))
            };
            drop(v785_10);
            let v785_13: Space = map_map_kernels::unite(&(v785_8),&(v785_12));
            join_wrapped_into(&mut v784_7_write,&((v785_13).read_zipper()),&[]);
            }
            v780_21_cursor.ascend(1);
          }
          drop(v784_7_write);
          map_map_kernels::compose(&(v783_5),&(v784_7))
        };
        drop(v783_5);
        let v783_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v783_2));
        drop(v783_2);
        let v783_10: Space = if map_kernels::has_head(&(v783_9)) { singleton(&[]) } else { Space::new() };
        drop(v783_9);
        let v783_12: Space = if (&(v783_10)).is_empty() { Space::new() } else {
          let v788_6: Path = concat_path(&(v782_6),&v780_21_cursor.path()[(v780_21_origin + 1)..(v780_21_origin + 2)]);
          let mut v788_11 = Space::new();
          let mut v788_11_write = v788_11.write_zipper();
          for v788_11_byte in v780_21_cursor.child_mask().iter() {
            v780_21_cursor.descend_to_existing_byte(v788_11_byte);
            {
            let v789_2: Space = singleton(&v780_21_cursor.path()[(v780_21_origin + 2)..(v780_21_origin + 3)]);
            let v789_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v789_2));
            let v789_4: Space = if map_kernels::has_head(&(v789_3)) { singleton(&[]) } else { Space::new() };
            drop(v789_3);
            let v789_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v789_4));
            drop(v789_4);
            let v789_8: Space = if (&(v789_5)).is_empty() { Space::new() } else {
              let v790_6: Path = concat_path(&(v788_6),&v780_21_cursor.path()[(v780_21_origin + 2)..(v780_21_origin + 3)]);
              let v790_7: Space = routine_61(c, &(v790_6), &v780_21_cursor, &(*s1));
              map_map_kernels::compose(&(v789_5),&(v790_7))
            };
            drop(v789_5);
            let v789_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v789_2));
            drop(v789_2);
            let v789_10: Space = if map_kernels::has_head(&(v789_9)) { singleton(&[]) } else { Space::new() };
            drop(v789_9);
            let v789_12: Space = if (&(v789_10)).is_empty() { Space::new() } else {
              let v791_6: Path = concat_path(&(v788_6),&v780_21_cursor.path()[(v780_21_origin + 2)..(v780_21_origin + 3)]);
              let v791_11: Space = routine_44(c, &(v791_6), &v780_21_cursor, &(*s1));
              drop(v791_6);
              map_map_kernels::compose(&(v789_10),&(v791_11))
            };
            drop(v789_10);
            let v789_13: Space = map_map_kernels::unite(&(v789_8),&(v789_12));
            join_wrapped_into(&mut v788_11_write,&((v789_13).read_zipper()),&[]);
            }
            v780_21_cursor.ascend(1);
          }
          drop(v788_11_write);
          drop(v788_6);
          map_map_kernels::compose(&(v783_10),&(v788_11))
        };
        drop(v783_10);
        let v783_13: Space = map_map_kernels::unite(&(v783_8),&(v783_12));
        join_wrapped_into(&mut v782_7_write,&((v783_13).read_zipper()),&[]);
        }
        v780_21_cursor.ascend(1);
      }
      drop(v782_7_write);
      drop(v782_6);
      map_map_kernels::compose(&(v781_5),&(v782_7))
    };
    drop(v781_5);
    let v781_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v781_2));
    drop(v781_2);
    let v781_10: Space = if map_kernels::has_head(&(v781_9)) { singleton(&[]) } else { Space::new() };
    drop(v781_9);
    let v781_13: Space = if (&(v781_10)).is_empty() { Space::new() } else {
      let v792_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v780_21_cursor.path()[v780_21_origin..(v780_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v781_10),&(v792_12))
    };
    drop(v781_10);
    let v781_14: Space = map_map_kernels::unite(&(v781_8),&(v781_13));
    drop(v781_13);
    join_wrapped_into(&mut v780_21_write,&((v781_14).read_zipper()),&[]);
    }
    v780_21_cursor.ascend(1);
  }
  drop(v780_21_cursor);
  drop(v780_21_write);
  (v780_21).clone()
}

fn routine_44(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v793_9: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0))),&(*CONSTANT_5));
  (v793_9).clone()
}

fn routine_45(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v794_27 = Space::new();
  let mut v794_27_write = v794_27.write_zipper();
  let mut v794_27_cursor = (*s0).read_zipper();
  let v794_27_origin = v794_27_cursor.path().len();
  for v794_27_byte in v794_27_cursor.child_mask().iter() {
    v794_27_cursor.descend_to_existing_byte(v794_27_byte);
    {
    let v795_2: Space = singleton(&v794_27_cursor.path()[v794_27_origin..(v794_27_origin + 1)]);
    let v795_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v795_2));
    let v795_4: Space = if map_kernels::has_head(&(v795_3)) { singleton(&[]) } else { Space::new() };
    drop(v795_3);
    let v795_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v795_4));
    drop(v795_4);
    let v795_8: Space = if (&(v795_5)).is_empty() { Space::new() } else {
      let v796_6: Path = concat_path(&(*p0),&v794_27_cursor.path()[v794_27_origin..(v794_27_origin + 1)]);
      let mut v796_7 = Space::new();
      let mut v796_7_write = v796_7.write_zipper();
      for v796_7_byte in v794_27_cursor.child_mask().iter() {
        v794_27_cursor.descend_to_existing_byte(v796_7_byte);
        {
        let v797_2: Space = singleton(&v794_27_cursor.path()[(v794_27_origin + 1)..(v794_27_origin + 2)]);
        let v797_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v797_2));
        let v797_4: Space = if map_kernels::has_head(&(v797_3)) { singleton(&[]) } else { Space::new() };
        drop(v797_3);
        let v797_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v797_4));
        drop(v797_4);
        let v797_8: Space = if (&(v797_5)).is_empty() { Space::new() } else {
          let v798_6: Path = concat_path(&(v796_6),&v794_27_cursor.path()[(v794_27_origin + 1)..(v794_27_origin + 2)]);
          let mut v798_7 = Space::new();
          let mut v798_7_write = v798_7.write_zipper();
          for v798_7_byte in v794_27_cursor.child_mask().iter() {
            v794_27_cursor.descend_to_existing_byte(v798_7_byte);
            {
            let v799_2: Space = singleton(&v794_27_cursor.path()[(v794_27_origin + 2)..(v794_27_origin + 3)]);
            let v799_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v799_2));
            let v799_4: Space = if map_kernels::has_head(&(v799_3)) { singleton(&[]) } else { Space::new() };
            drop(v799_3);
            let v799_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v799_4));
            drop(v799_4);
            let v799_8: Space = if (&(v799_5)).is_empty() { Space::new() } else {
              let v800_6: Path = concat_path(&(v798_6),&v794_27_cursor.path()[(v794_27_origin + 2)..(v794_27_origin + 3)]);
              let v800_7: Space = routine_63(c, &(v800_6), &v794_27_cursor, &(*s1));
              map_map_kernels::compose(&(v799_5),&(v800_7))
            };
            drop(v799_5);
            let v799_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v799_2));
            drop(v799_2);
            let v799_10: Space = if map_kernels::has_head(&(v799_9)) { singleton(&[]) } else { Space::new() };
            drop(v799_9);
            let v799_12: Space = if (&(v799_10)).is_empty() { Space::new() } else {
              let v801_6: Path = concat_path(&(v798_6),&v794_27_cursor.path()[(v794_27_origin + 2)..(v794_27_origin + 3)]);
              let v801_11: Space = routine_64(c, &(v801_6), &v794_27_cursor, &(*s1));
              drop(v801_6);
              map_map_kernels::compose(&(v799_10),&(v801_11))
            };
            drop(v799_10);
            let v799_13: Space = map_map_kernels::unite(&(v799_8),&(v799_12));
            join_wrapped_into(&mut v798_7_write,&((v799_13).read_zipper()),&[]);
            }
            v794_27_cursor.ascend(1);
          }
          drop(v798_7_write);
          map_map_kernels::compose(&(v797_5),&(v798_7))
        };
        drop(v797_5);
        let v797_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v797_2));
        drop(v797_2);
        let v797_10: Space = if map_kernels::has_head(&(v797_9)) { singleton(&[]) } else { Space::new() };
        drop(v797_9);
        let v797_12: Space = if (&(v797_10)).is_empty() { Space::new() } else {
          let v802_6: Path = concat_path(&(v796_6),&v794_27_cursor.path()[(v794_27_origin + 1)..(v794_27_origin + 2)]);
          let mut v802_11 = Space::new();
          let mut v802_11_write = v802_11.write_zipper();
          for v802_11_byte in v794_27_cursor.child_mask().iter() {
            v794_27_cursor.descend_to_existing_byte(v802_11_byte);
            {
            let v803_2: Space = singleton(&v794_27_cursor.path()[(v794_27_origin + 2)..(v794_27_origin + 3)]);
            let v803_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v803_2));
            let v803_4: Space = if map_kernels::has_head(&(v803_3)) { singleton(&[]) } else { Space::new() };
            drop(v803_3);
            let v803_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v803_4));
            drop(v803_4);
            let v803_8: Space = if (&(v803_5)).is_empty() { Space::new() } else {
              let v804_6: Path = concat_path(&(v802_6),&v794_27_cursor.path()[(v794_27_origin + 2)..(v794_27_origin + 3)]);
              let v804_7: Space = routine_63(c, &(v804_6), &v794_27_cursor, &(*s1));
              map_map_kernels::compose(&(v803_5),&(v804_7))
            };
            drop(v803_5);
            let v803_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v803_2));
            drop(v803_2);
            let v803_10: Space = if map_kernels::has_head(&(v803_9)) { singleton(&[]) } else { Space::new() };
            drop(v803_9);
            let v803_12: Space = if (&(v803_10)).is_empty() { Space::new() } else {
              let v805_6: Path = concat_path(&(v802_6),&v794_27_cursor.path()[(v794_27_origin + 2)..(v794_27_origin + 3)]);
              let v805_11: Space = routine_44(c, &(v805_6), &v794_27_cursor, &(*s1));
              drop(v805_6);
              map_map_kernels::compose(&(v803_10),&(v805_11))
            };
            drop(v803_10);
            let v803_13: Space = map_map_kernels::unite(&(v803_8),&(v803_12));
            join_wrapped_into(&mut v802_11_write,&((v803_13).read_zipper()),&[]);
            }
            v794_27_cursor.ascend(1);
          }
          drop(v802_11_write);
          drop(v802_6);
          map_map_kernels::compose(&(v797_10),&(v802_11))
        };
        drop(v797_10);
        let v797_13: Space = map_map_kernels::unite(&(v797_8),&(v797_12));
        join_wrapped_into(&mut v796_7_write,&((v797_13).read_zipper()),&[]);
        }
        v794_27_cursor.ascend(1);
      }
      drop(v796_7_write);
      map_map_kernels::compose(&(v795_5),&(v796_7))
    };
    drop(v795_5);
    let v795_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v795_2));
    drop(v795_2);
    let v795_10: Space = if map_kernels::has_head(&(v795_9)) { singleton(&[]) } else { Space::new() };
    drop(v795_9);
    let v795_13: Space = if (&(v795_10)).is_empty() { Space::new() } else {
      let v806_6: Path = concat_path(&(*p0),&v794_27_cursor.path()[v794_27_origin..(v794_27_origin + 1)]);
      let mut v806_12 = Space::new();
      let mut v806_12_write = v806_12.write_zipper();
      for v806_12_byte in v794_27_cursor.child_mask().iter() {
        v794_27_cursor.descend_to_existing_byte(v806_12_byte);
        {
        let v807_2: Space = singleton(&v794_27_cursor.path()[(v794_27_origin + 1)..(v794_27_origin + 2)]);
        let v807_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v807_2));
        let v807_4: Space = if map_kernels::has_head(&(v807_3)) { singleton(&[]) } else { Space::new() };
        drop(v807_3);
        let v807_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v807_4));
        drop(v807_4);
        let v807_8: Space = if (&(v807_5)).is_empty() { Space::new() } else {
          let v808_6: Path = concat_path(&(v806_6),&v794_27_cursor.path()[(v794_27_origin + 1)..(v794_27_origin + 2)]);
          let mut v808_7 = Space::new();
          let mut v808_7_write = v808_7.write_zipper();
          for v808_7_byte in v794_27_cursor.child_mask().iter() {
            v794_27_cursor.descend_to_existing_byte(v808_7_byte);
            {
            let v809_2: Space = singleton(&v794_27_cursor.path()[(v794_27_origin + 2)..(v794_27_origin + 3)]);
            let v809_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v809_2));
            let v809_4: Space = if map_kernels::has_head(&(v809_3)) { singleton(&[]) } else { Space::new() };
            drop(v809_3);
            let v809_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v809_4));
            drop(v809_4);
            let v809_8: Space = if (&(v809_5)).is_empty() { Space::new() } else {
              let v810_6: Path = concat_path(&(v808_6),&v794_27_cursor.path()[(v794_27_origin + 2)..(v794_27_origin + 3)]);
              let v810_7: Space = routine_63(c, &(v810_6), &v794_27_cursor, &(*s1));
              map_map_kernels::compose(&(v809_5),&(v810_7))
            };
            drop(v809_5);
            let v809_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v809_2));
            drop(v809_2);
            let v809_10: Space = if map_kernels::has_head(&(v809_9)) { singleton(&[]) } else { Space::new() };
            drop(v809_9);
            let v809_12: Space = if (&(v809_10)).is_empty() { Space::new() } else {
              let v811_6: Path = concat_path(&(v808_6),&v794_27_cursor.path()[(v794_27_origin + 2)..(v794_27_origin + 3)]);
              let v811_11: Space = routine_64(c, &(v811_6), &v794_27_cursor, &(*s1));
              drop(v811_6);
              map_map_kernels::compose(&(v809_10),&(v811_11))
            };
            drop(v809_10);
            let v809_13: Space = map_map_kernels::unite(&(v809_8),&(v809_12));
            join_wrapped_into(&mut v808_7_write,&((v809_13).read_zipper()),&[]);
            }
            v794_27_cursor.ascend(1);
          }
          drop(v808_7_write);
          drop(v808_6);
          map_map_kernels::compose(&(v807_5),&(v808_7))
        };
        drop(v807_5);
        let v807_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v807_2));
        drop(v807_2);
        let v807_10: Space = if map_kernels::has_head(&(v807_9)) { singleton(&[]) } else { Space::new() };
        drop(v807_9);
        let v807_13: Space = if (&(v807_10)).is_empty() { Space::new() } else {
          let v812_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v794_27_cursor.path()[v794_27_origin..(v794_27_origin + 1)]),&v794_27_cursor.path()[(v794_27_origin + 1)..(v794_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v807_10),&(v812_12))
        };
        drop(v807_10);
        let v807_14: Space = map_map_kernels::unite(&(v807_8),&(v807_13));
        drop(v807_13);
        join_wrapped_into(&mut v806_12_write,&((v807_14).read_zipper()),&[]);
        }
        v794_27_cursor.ascend(1);
      }
      drop(v806_12_write);
      drop(v806_6);
      map_map_kernels::compose(&(v795_10),&(v806_12))
    };
    drop(v795_10);
    let v795_14: Space = map_map_kernels::unite(&(v795_8),&(v795_13));
    join_wrapped_into(&mut v794_27_write,&((v795_14).read_zipper()),&[]);
    }
    v794_27_cursor.ascend(1);
  }
  drop(v794_27_cursor);
  drop(v794_27_write);
  (v794_27).clone()
}

fn routine_46(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v813_21 = Space::new();
  let mut v813_21_write = v813_21.write_zipper();
  let mut v813_21_cursor = (*s0).read_zipper();
  let v813_21_origin = v813_21_cursor.path().len();
  for v813_21_byte in v813_21_cursor.child_mask().iter() {
    v813_21_cursor.descend_to_existing_byte(v813_21_byte);
    {
    let v814_2: Space = singleton(&v813_21_cursor.path()[v813_21_origin..(v813_21_origin + 1)]);
    let v814_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v814_2));
    let v814_4: Space = if map_kernels::has_head(&(v814_3)) { singleton(&[]) } else { Space::new() };
    drop(v814_3);
    let v814_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v814_4));
    drop(v814_4);
    let v814_8: Space = if (&(v814_5)).is_empty() { Space::new() } else {
      let v815_6: Path = concat_path(&(*p0),&v813_21_cursor.path()[v813_21_origin..(v813_21_origin + 1)]);
      let mut v815_7 = Space::new();
      let mut v815_7_write = v815_7.write_zipper();
      for v815_7_byte in v813_21_cursor.child_mask().iter() {
        v813_21_cursor.descend_to_existing_byte(v815_7_byte);
        {
        let v816_2: Space = singleton(&v813_21_cursor.path()[(v813_21_origin + 1)..(v813_21_origin + 2)]);
        let v816_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v816_2));
        let v816_4: Space = if map_kernels::has_head(&(v816_3)) { singleton(&[]) } else { Space::new() };
        drop(v816_3);
        let v816_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v816_4));
        drop(v816_4);
        let v816_8: Space = if (&(v816_5)).is_empty() { Space::new() } else {
          let v817_6: Path = concat_path(&(v815_6),&v813_21_cursor.path()[(v813_21_origin + 1)..(v813_21_origin + 2)]);
          let mut v817_7 = Space::new();
          let mut v817_7_write = v817_7.write_zipper();
          for v817_7_byte in v813_21_cursor.child_mask().iter() {
            v813_21_cursor.descend_to_existing_byte(v817_7_byte);
            {
            let v818_2: Space = singleton(&v813_21_cursor.path()[(v813_21_origin + 2)..(v813_21_origin + 3)]);
            let v818_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v818_2));
            let v818_4: Space = if map_kernels::has_head(&(v818_3)) { singleton(&[]) } else { Space::new() };
            drop(v818_3);
            let v818_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v818_4));
            drop(v818_4);
            let v818_8: Space = if (&(v818_5)).is_empty() { Space::new() } else {
              let v819_6: Path = concat_path(&(v817_6),&v813_21_cursor.path()[(v813_21_origin + 2)..(v813_21_origin + 3)]);
              let v819_7: Space = routine_63(c, &(v819_6), &v813_21_cursor, &(*s1));
              map_map_kernels::compose(&(v818_5),&(v819_7))
            };
            drop(v818_5);
            let v818_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v818_2));
            drop(v818_2);
            let v818_10: Space = if map_kernels::has_head(&(v818_9)) { singleton(&[]) } else { Space::new() };
            drop(v818_9);
            let v818_12: Space = if (&(v818_10)).is_empty() { Space::new() } else {
              let v820_6: Path = concat_path(&(v817_6),&v813_21_cursor.path()[(v813_21_origin + 2)..(v813_21_origin + 3)]);
              let v820_11: Space = routine_64(c, &(v820_6), &v813_21_cursor, &(*s1));
              drop(v820_6);
              map_map_kernels::compose(&(v818_10),&(v820_11))
            };
            drop(v818_10);
            let v818_13: Space = map_map_kernels::unite(&(v818_8),&(v818_12));
            join_wrapped_into(&mut v817_7_write,&((v818_13).read_zipper()),&[]);
            }
            v813_21_cursor.ascend(1);
          }
          drop(v817_7_write);
          map_map_kernels::compose(&(v816_5),&(v817_7))
        };
        drop(v816_5);
        let v816_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v816_2));
        drop(v816_2);
        let v816_10: Space = if map_kernels::has_head(&(v816_9)) { singleton(&[]) } else { Space::new() };
        drop(v816_9);
        let v816_12: Space = if (&(v816_10)).is_empty() { Space::new() } else {
          let v821_6: Path = concat_path(&(v815_6),&v813_21_cursor.path()[(v813_21_origin + 1)..(v813_21_origin + 2)]);
          let mut v821_11 = Space::new();
          let mut v821_11_write = v821_11.write_zipper();
          for v821_11_byte in v813_21_cursor.child_mask().iter() {
            v813_21_cursor.descend_to_existing_byte(v821_11_byte);
            {
            let v822_2: Space = singleton(&v813_21_cursor.path()[(v813_21_origin + 2)..(v813_21_origin + 3)]);
            let v822_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v822_2));
            let v822_4: Space = if map_kernels::has_head(&(v822_3)) { singleton(&[]) } else { Space::new() };
            drop(v822_3);
            let v822_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v822_4));
            drop(v822_4);
            let v822_8: Space = if (&(v822_5)).is_empty() { Space::new() } else {
              let v823_6: Path = concat_path(&(v821_6),&v813_21_cursor.path()[(v813_21_origin + 2)..(v813_21_origin + 3)]);
              let v823_7: Space = routine_63(c, &(v823_6), &v813_21_cursor, &(*s1));
              map_map_kernels::compose(&(v822_5),&(v823_7))
            };
            drop(v822_5);
            let v822_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v822_2));
            drop(v822_2);
            let v822_10: Space = if map_kernels::has_head(&(v822_9)) { singleton(&[]) } else { Space::new() };
            drop(v822_9);
            let v822_12: Space = if (&(v822_10)).is_empty() { Space::new() } else {
              let v824_6: Path = concat_path(&(v821_6),&v813_21_cursor.path()[(v813_21_origin + 2)..(v813_21_origin + 3)]);
              let v824_11: Space = routine_44(c, &(v824_6), &v813_21_cursor, &(*s1));
              drop(v824_6);
              map_map_kernels::compose(&(v822_10),&(v824_11))
            };
            drop(v822_10);
            let v822_13: Space = map_map_kernels::unite(&(v822_8),&(v822_12));
            join_wrapped_into(&mut v821_11_write,&((v822_13).read_zipper()),&[]);
            }
            v813_21_cursor.ascend(1);
          }
          drop(v821_11_write);
          drop(v821_6);
          map_map_kernels::compose(&(v816_10),&(v821_11))
        };
        drop(v816_10);
        let v816_13: Space = map_map_kernels::unite(&(v816_8),&(v816_12));
        join_wrapped_into(&mut v815_7_write,&((v816_13).read_zipper()),&[]);
        }
        v813_21_cursor.ascend(1);
      }
      drop(v815_7_write);
      drop(v815_6);
      map_map_kernels::compose(&(v814_5),&(v815_7))
    };
    drop(v814_5);
    let v814_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v814_2));
    drop(v814_2);
    let v814_10: Space = if map_kernels::has_head(&(v814_9)) { singleton(&[]) } else { Space::new() };
    drop(v814_9);
    let v814_13: Space = if (&(v814_10)).is_empty() { Space::new() } else {
      let v825_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v813_21_cursor.path()[v813_21_origin..(v813_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v814_10),&(v825_12))
    };
    drop(v814_10);
    let v814_14: Space = map_map_kernels::unite(&(v814_8),&(v814_13));
    drop(v814_13);
    join_wrapped_into(&mut v813_21_write,&((v814_14).read_zipper()),&[]);
    }
    v813_21_cursor.ascend(1);
  }
  drop(v813_21_cursor);
  drop(v813_21_write);
  (v813_21).clone()
}

fn routine_47(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v826_27 = Space::new();
  let mut v826_27_write = v826_27.write_zipper();
  let mut v826_27_cursor = (*s0).read_zipper();
  let v826_27_origin = v826_27_cursor.path().len();
  for v826_27_byte in v826_27_cursor.child_mask().iter() {
    v826_27_cursor.descend_to_existing_byte(v826_27_byte);
    {
    let v827_2: Space = singleton(&v826_27_cursor.path()[v826_27_origin..(v826_27_origin + 1)]);
    let v827_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v827_2));
    let v827_4: Space = if map_kernels::has_head(&(v827_3)) { singleton(&[]) } else { Space::new() };
    drop(v827_3);
    let v827_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v827_4));
    drop(v827_4);
    let v827_8: Space = if (&(v827_5)).is_empty() { Space::new() } else {
      let v828_6: Path = concat_path(&(*p0),&v826_27_cursor.path()[v826_27_origin..(v826_27_origin + 1)]);
      let mut v828_7 = Space::new();
      let mut v828_7_write = v828_7.write_zipper();
      for v828_7_byte in v826_27_cursor.child_mask().iter() {
        v826_27_cursor.descend_to_existing_byte(v828_7_byte);
        {
        let v829_2: Space = singleton(&v826_27_cursor.path()[(v826_27_origin + 1)..(v826_27_origin + 2)]);
        let v829_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v829_2));
        let v829_4: Space = if map_kernels::has_head(&(v829_3)) { singleton(&[]) } else { Space::new() };
        drop(v829_3);
        let v829_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v829_4));
        drop(v829_4);
        let v829_8: Space = if (&(v829_5)).is_empty() { Space::new() } else {
          let v830_6: Path = concat_path(&(v828_6),&v826_27_cursor.path()[(v826_27_origin + 1)..(v826_27_origin + 2)]);
          let mut v830_7 = Space::new();
          let mut v830_7_write = v830_7.write_zipper();
          for v830_7_byte in v826_27_cursor.child_mask().iter() {
            v826_27_cursor.descend_to_existing_byte(v830_7_byte);
            {
            let v831_2: Space = singleton(&v826_27_cursor.path()[(v826_27_origin + 2)..(v826_27_origin + 3)]);
            let v831_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v831_2));
            let v831_4: Space = if map_kernels::has_head(&(v831_3)) { singleton(&[]) } else { Space::new() };
            drop(v831_3);
            let v831_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v831_4));
            drop(v831_4);
            let v831_8: Space = if (&(v831_5)).is_empty() { Space::new() } else {
              let v832_6: Path = concat_path(&(v830_6),&v826_27_cursor.path()[(v826_27_origin + 2)..(v826_27_origin + 3)]);
              let v832_7: Space = routine_65(c, &(v832_6), &v826_27_cursor, &(*s1));
              map_map_kernels::compose(&(v831_5),&(v832_7))
            };
            drop(v831_5);
            let v831_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v831_2));
            drop(v831_2);
            let v831_10: Space = if map_kernels::has_head(&(v831_9)) { singleton(&[]) } else { Space::new() };
            drop(v831_9);
            let v831_12: Space = if (&(v831_10)).is_empty() { Space::new() } else {
              let v833_6: Path = concat_path(&(v830_6),&v826_27_cursor.path()[(v826_27_origin + 2)..(v826_27_origin + 3)]);
              let v833_11: Space = routine_66(c, &(v833_6), &v826_27_cursor, &(*s1));
              drop(v833_6);
              map_map_kernels::compose(&(v831_10),&(v833_11))
            };
            drop(v831_10);
            let v831_13: Space = map_map_kernels::unite(&(v831_8),&(v831_12));
            join_wrapped_into(&mut v830_7_write,&((v831_13).read_zipper()),&[]);
            }
            v826_27_cursor.ascend(1);
          }
          drop(v830_7_write);
          map_map_kernels::compose(&(v829_5),&(v830_7))
        };
        drop(v829_5);
        let v829_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v829_2));
        drop(v829_2);
        let v829_10: Space = if map_kernels::has_head(&(v829_9)) { singleton(&[]) } else { Space::new() };
        drop(v829_9);
        let v829_12: Space = if (&(v829_10)).is_empty() { Space::new() } else {
          let v834_6: Path = concat_path(&(v828_6),&v826_27_cursor.path()[(v826_27_origin + 1)..(v826_27_origin + 2)]);
          let mut v834_11 = Space::new();
          let mut v834_11_write = v834_11.write_zipper();
          for v834_11_byte in v826_27_cursor.child_mask().iter() {
            v826_27_cursor.descend_to_existing_byte(v834_11_byte);
            {
            let v835_2: Space = singleton(&v826_27_cursor.path()[(v826_27_origin + 2)..(v826_27_origin + 3)]);
            let v835_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v835_2));
            let v835_4: Space = if map_kernels::has_head(&(v835_3)) { singleton(&[]) } else { Space::new() };
            drop(v835_3);
            let v835_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v835_4));
            drop(v835_4);
            let v835_8: Space = if (&(v835_5)).is_empty() { Space::new() } else {
              let v836_6: Path = concat_path(&(v834_6),&v826_27_cursor.path()[(v826_27_origin + 2)..(v826_27_origin + 3)]);
              let v836_7: Space = routine_65(c, &(v836_6), &v826_27_cursor, &(*s1));
              map_map_kernels::compose(&(v835_5),&(v836_7))
            };
            drop(v835_5);
            let v835_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v835_2));
            drop(v835_2);
            let v835_10: Space = if map_kernels::has_head(&(v835_9)) { singleton(&[]) } else { Space::new() };
            drop(v835_9);
            let v835_12: Space = if (&(v835_10)).is_empty() { Space::new() } else {
              let v837_6: Path = concat_path(&(v834_6),&v826_27_cursor.path()[(v826_27_origin + 2)..(v826_27_origin + 3)]);
              let v837_11: Space = routine_44(c, &(v837_6), &v826_27_cursor, &(*s1));
              drop(v837_6);
              map_map_kernels::compose(&(v835_10),&(v837_11))
            };
            drop(v835_10);
            let v835_13: Space = map_map_kernels::unite(&(v835_8),&(v835_12));
            join_wrapped_into(&mut v834_11_write,&((v835_13).read_zipper()),&[]);
            }
            v826_27_cursor.ascend(1);
          }
          drop(v834_11_write);
          drop(v834_6);
          map_map_kernels::compose(&(v829_10),&(v834_11))
        };
        drop(v829_10);
        let v829_13: Space = map_map_kernels::unite(&(v829_8),&(v829_12));
        join_wrapped_into(&mut v828_7_write,&((v829_13).read_zipper()),&[]);
        }
        v826_27_cursor.ascend(1);
      }
      drop(v828_7_write);
      map_map_kernels::compose(&(v827_5),&(v828_7))
    };
    drop(v827_5);
    let v827_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v827_2));
    drop(v827_2);
    let v827_10: Space = if map_kernels::has_head(&(v827_9)) { singleton(&[]) } else { Space::new() };
    drop(v827_9);
    let v827_13: Space = if (&(v827_10)).is_empty() { Space::new() } else {
      let v838_6: Path = concat_path(&(*p0),&v826_27_cursor.path()[v826_27_origin..(v826_27_origin + 1)]);
      let mut v838_12 = Space::new();
      let mut v838_12_write = v838_12.write_zipper();
      for v838_12_byte in v826_27_cursor.child_mask().iter() {
        v826_27_cursor.descend_to_existing_byte(v838_12_byte);
        {
        let v839_2: Space = singleton(&v826_27_cursor.path()[(v826_27_origin + 1)..(v826_27_origin + 2)]);
        let v839_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v839_2));
        let v839_4: Space = if map_kernels::has_head(&(v839_3)) { singleton(&[]) } else { Space::new() };
        drop(v839_3);
        let v839_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v839_4));
        drop(v839_4);
        let v839_8: Space = if (&(v839_5)).is_empty() { Space::new() } else {
          let v840_6: Path = concat_path(&(v838_6),&v826_27_cursor.path()[(v826_27_origin + 1)..(v826_27_origin + 2)]);
          let mut v840_7 = Space::new();
          let mut v840_7_write = v840_7.write_zipper();
          for v840_7_byte in v826_27_cursor.child_mask().iter() {
            v826_27_cursor.descend_to_existing_byte(v840_7_byte);
            {
            let v841_2: Space = singleton(&v826_27_cursor.path()[(v826_27_origin + 2)..(v826_27_origin + 3)]);
            let v841_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v841_2));
            let v841_4: Space = if map_kernels::has_head(&(v841_3)) { singleton(&[]) } else { Space::new() };
            drop(v841_3);
            let v841_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v841_4));
            drop(v841_4);
            let v841_8: Space = if (&(v841_5)).is_empty() { Space::new() } else {
              let v842_6: Path = concat_path(&(v840_6),&v826_27_cursor.path()[(v826_27_origin + 2)..(v826_27_origin + 3)]);
              let v842_7: Space = routine_65(c, &(v842_6), &v826_27_cursor, &(*s1));
              map_map_kernels::compose(&(v841_5),&(v842_7))
            };
            drop(v841_5);
            let v841_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v841_2));
            drop(v841_2);
            let v841_10: Space = if map_kernels::has_head(&(v841_9)) { singleton(&[]) } else { Space::new() };
            drop(v841_9);
            let v841_12: Space = if (&(v841_10)).is_empty() { Space::new() } else {
              let v843_6: Path = concat_path(&(v840_6),&v826_27_cursor.path()[(v826_27_origin + 2)..(v826_27_origin + 3)]);
              let v843_11: Space = routine_66(c, &(v843_6), &v826_27_cursor, &(*s1));
              drop(v843_6);
              map_map_kernels::compose(&(v841_10),&(v843_11))
            };
            drop(v841_10);
            let v841_13: Space = map_map_kernels::unite(&(v841_8),&(v841_12));
            join_wrapped_into(&mut v840_7_write,&((v841_13).read_zipper()),&[]);
            }
            v826_27_cursor.ascend(1);
          }
          drop(v840_7_write);
          drop(v840_6);
          map_map_kernels::compose(&(v839_5),&(v840_7))
        };
        drop(v839_5);
        let v839_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v839_2));
        drop(v839_2);
        let v839_10: Space = if map_kernels::has_head(&(v839_9)) { singleton(&[]) } else { Space::new() };
        drop(v839_9);
        let v839_13: Space = if (&(v839_10)).is_empty() { Space::new() } else {
          let v844_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v826_27_cursor.path()[v826_27_origin..(v826_27_origin + 1)]),&v826_27_cursor.path()[(v826_27_origin + 1)..(v826_27_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v839_10),&(v844_12))
        };
        drop(v839_10);
        let v839_14: Space = map_map_kernels::unite(&(v839_8),&(v839_13));
        drop(v839_13);
        join_wrapped_into(&mut v838_12_write,&((v839_14).read_zipper()),&[]);
        }
        v826_27_cursor.ascend(1);
      }
      drop(v838_12_write);
      drop(v838_6);
      map_map_kernels::compose(&(v827_10),&(v838_12))
    };
    drop(v827_10);
    let v827_14: Space = map_map_kernels::unite(&(v827_8),&(v827_13));
    join_wrapped_into(&mut v826_27_write,&((v827_14).read_zipper()),&[]);
    }
    v826_27_cursor.ascend(1);
  }
  drop(v826_27_cursor);
  drop(v826_27_write);
  (v826_27).clone()
}

fn routine_48(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v845_21 = Space::new();
  let mut v845_21_write = v845_21.write_zipper();
  let mut v845_21_cursor = (*s0).read_zipper();
  let v845_21_origin = v845_21_cursor.path().len();
  for v845_21_byte in v845_21_cursor.child_mask().iter() {
    v845_21_cursor.descend_to_existing_byte(v845_21_byte);
    {
    let v846_2: Space = singleton(&v845_21_cursor.path()[v845_21_origin..(v845_21_origin + 1)]);
    let v846_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v846_2));
    let v846_4: Space = if map_kernels::has_head(&(v846_3)) { singleton(&[]) } else { Space::new() };
    drop(v846_3);
    let v846_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v846_4));
    drop(v846_4);
    let v846_8: Space = if (&(v846_5)).is_empty() { Space::new() } else {
      let v847_6: Path = concat_path(&(*p0),&v845_21_cursor.path()[v845_21_origin..(v845_21_origin + 1)]);
      let mut v847_7 = Space::new();
      let mut v847_7_write = v847_7.write_zipper();
      for v847_7_byte in v845_21_cursor.child_mask().iter() {
        v845_21_cursor.descend_to_existing_byte(v847_7_byte);
        {
        let v848_2: Space = singleton(&v845_21_cursor.path()[(v845_21_origin + 1)..(v845_21_origin + 2)]);
        let v848_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v848_2));
        let v848_4: Space = if map_kernels::has_head(&(v848_3)) { singleton(&[]) } else { Space::new() };
        drop(v848_3);
        let v848_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v848_4));
        drop(v848_4);
        let v848_8: Space = if (&(v848_5)).is_empty() { Space::new() } else {
          let v849_6: Path = concat_path(&(v847_6),&v845_21_cursor.path()[(v845_21_origin + 1)..(v845_21_origin + 2)]);
          let mut v849_7 = Space::new();
          let mut v849_7_write = v849_7.write_zipper();
          for v849_7_byte in v845_21_cursor.child_mask().iter() {
            v845_21_cursor.descend_to_existing_byte(v849_7_byte);
            {
            let v850_2: Space = singleton(&v845_21_cursor.path()[(v845_21_origin + 2)..(v845_21_origin + 3)]);
            let v850_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v850_2));
            let v850_4: Space = if map_kernels::has_head(&(v850_3)) { singleton(&[]) } else { Space::new() };
            drop(v850_3);
            let v850_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v850_4));
            drop(v850_4);
            let v850_8: Space = if (&(v850_5)).is_empty() { Space::new() } else {
              let v851_6: Path = concat_path(&(v849_6),&v845_21_cursor.path()[(v845_21_origin + 2)..(v845_21_origin + 3)]);
              let v851_7: Space = routine_65(c, &(v851_6), &v845_21_cursor, &(*s1));
              map_map_kernels::compose(&(v850_5),&(v851_7))
            };
            drop(v850_5);
            let v850_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v850_2));
            drop(v850_2);
            let v850_10: Space = if map_kernels::has_head(&(v850_9)) { singleton(&[]) } else { Space::new() };
            drop(v850_9);
            let v850_12: Space = if (&(v850_10)).is_empty() { Space::new() } else {
              let v852_6: Path = concat_path(&(v849_6),&v845_21_cursor.path()[(v845_21_origin + 2)..(v845_21_origin + 3)]);
              let v852_11: Space = routine_66(c, &(v852_6), &v845_21_cursor, &(*s1));
              drop(v852_6);
              map_map_kernels::compose(&(v850_10),&(v852_11))
            };
            drop(v850_10);
            let v850_13: Space = map_map_kernels::unite(&(v850_8),&(v850_12));
            join_wrapped_into(&mut v849_7_write,&((v850_13).read_zipper()),&[]);
            }
            v845_21_cursor.ascend(1);
          }
          drop(v849_7_write);
          map_map_kernels::compose(&(v848_5),&(v849_7))
        };
        drop(v848_5);
        let v848_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v848_2));
        drop(v848_2);
        let v848_10: Space = if map_kernels::has_head(&(v848_9)) { singleton(&[]) } else { Space::new() };
        drop(v848_9);
        let v848_12: Space = if (&(v848_10)).is_empty() { Space::new() } else {
          let v853_6: Path = concat_path(&(v847_6),&v845_21_cursor.path()[(v845_21_origin + 1)..(v845_21_origin + 2)]);
          let mut v853_11 = Space::new();
          let mut v853_11_write = v853_11.write_zipper();
          for v853_11_byte in v845_21_cursor.child_mask().iter() {
            v845_21_cursor.descend_to_existing_byte(v853_11_byte);
            {
            let v854_2: Space = singleton(&v845_21_cursor.path()[(v845_21_origin + 2)..(v845_21_origin + 3)]);
            let v854_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v854_2));
            let v854_4: Space = if map_kernels::has_head(&(v854_3)) { singleton(&[]) } else { Space::new() };
            drop(v854_3);
            let v854_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v854_4));
            drop(v854_4);
            let v854_8: Space = if (&(v854_5)).is_empty() { Space::new() } else {
              let v855_6: Path = concat_path(&(v853_6),&v845_21_cursor.path()[(v845_21_origin + 2)..(v845_21_origin + 3)]);
              let v855_7: Space = routine_65(c, &(v855_6), &v845_21_cursor, &(*s1));
              map_map_kernels::compose(&(v854_5),&(v855_7))
            };
            drop(v854_5);
            let v854_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v854_2));
            drop(v854_2);
            let v854_10: Space = if map_kernels::has_head(&(v854_9)) { singleton(&[]) } else { Space::new() };
            drop(v854_9);
            let v854_12: Space = if (&(v854_10)).is_empty() { Space::new() } else {
              let v856_6: Path = concat_path(&(v853_6),&v845_21_cursor.path()[(v845_21_origin + 2)..(v845_21_origin + 3)]);
              let v856_11: Space = routine_44(c, &(v856_6), &v845_21_cursor, &(*s1));
              drop(v856_6);
              map_map_kernels::compose(&(v854_10),&(v856_11))
            };
            drop(v854_10);
            let v854_13: Space = map_map_kernels::unite(&(v854_8),&(v854_12));
            join_wrapped_into(&mut v853_11_write,&((v854_13).read_zipper()),&[]);
            }
            v845_21_cursor.ascend(1);
          }
          drop(v853_11_write);
          drop(v853_6);
          map_map_kernels::compose(&(v848_10),&(v853_11))
        };
        drop(v848_10);
        let v848_13: Space = map_map_kernels::unite(&(v848_8),&(v848_12));
        join_wrapped_into(&mut v847_7_write,&((v848_13).read_zipper()),&[]);
        }
        v845_21_cursor.ascend(1);
      }
      drop(v847_7_write);
      drop(v847_6);
      map_map_kernels::compose(&(v846_5),&(v847_7))
    };
    drop(v846_5);
    let v846_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v846_2));
    drop(v846_2);
    let v846_10: Space = if map_kernels::has_head(&(v846_9)) { singleton(&[]) } else { Space::new() };
    drop(v846_9);
    let v846_13: Space = if (&(v846_10)).is_empty() { Space::new() } else {
      let v857_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v845_21_cursor.path()[v845_21_origin..(v845_21_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v846_10),&(v857_12))
    };
    drop(v846_10);
    let v846_14: Space = map_map_kernels::unite(&(v846_8),&(v846_13));
    drop(v846_13);
    join_wrapped_into(&mut v845_21_write,&((v846_14).read_zipper()),&[]);
    }
    v845_21_cursor.ascend(1);
  }
  drop(v845_21_cursor);
  drop(v845_21_write);
  (v845_21).clone()
}

fn routine_49(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v858_15 = Space::new();
  let mut v858_15_write = v858_15.write_zipper();
  let mut v858_15_cursor = (*s0).read_zipper();
  let v858_15_origin = v858_15_cursor.path().len();
  for v858_15_byte in v858_15_cursor.child_mask().iter() {
    v858_15_cursor.descend_to_existing_byte(v858_15_byte);
    {
    let v859_2: Space = singleton(&v858_15_cursor.path()[v858_15_origin..(v858_15_origin + 1)]);
    let v859_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v859_2));
    let v859_4: Space = if map_kernels::has_head(&(v859_3)) { singleton(&[]) } else { Space::new() };
    drop(v859_3);
    let v859_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v859_4));
    drop(v859_4);
    let v859_8: Space = if (&(v859_5)).is_empty() { Space::new() } else {
      let v860_6: Path = concat_path(&(*p0),&v858_15_cursor.path()[v858_15_origin..(v858_15_origin + 1)]);
      let mut v860_7 = Space::new();
      let mut v860_7_write = v860_7.write_zipper();
      for v860_7_byte in v858_15_cursor.child_mask().iter() {
        v858_15_cursor.descend_to_existing_byte(v860_7_byte);
        {
        let v861_2: Space = singleton(&v858_15_cursor.path()[(v858_15_origin + 1)..(v858_15_origin + 2)]);
        let v861_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v861_2));
        drop(v861_2);
        let v861_4: Space = if map_kernels::has_head(&(v861_3)) { singleton(&[]) } else { Space::new() };
        drop(v861_3);
        let v861_7: Space = if (&(v861_4)).is_empty() { Space::new() } else {
          let v862_5: Path = concat_path(&(v860_6),&v858_15_cursor.path()[(v858_15_origin + 1)..(v858_15_origin + 2)]);
          let mut v862_6 = Space::new();
          let mut v862_6_write = v862_6.write_zipper();
          for v862_6_byte in v858_15_cursor.child_mask().iter() {
            v858_15_cursor.descend_to_existing_byte(v862_6_byte);
            {
            let v863_2: Space = singleton(&v858_15_cursor.path()[(v858_15_origin + 2)..(v858_15_origin + 3)]);
            let v863_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v863_2));
            drop(v863_2);
            let v863_4: Space = if map_kernels::has_head(&(v863_3)) { singleton(&[]) } else { Space::new() };
            drop(v863_3);
            let v863_7: Space = if (&(v863_4)).is_empty() { Space::new() } else {
              let v864_5: Path = concat_path(&(v862_5),&v858_15_cursor.path()[(v858_15_origin + 2)..(v858_15_origin + 3)]);
              let v864_6: Space = routine_24(c, &(v864_5), &v858_15_cursor, &(*s1));
              drop(v864_5);
              map_map_kernels::compose(&(v863_4),&(v864_6))
            };
            drop(v863_4);
            join_wrapped_into(&mut v862_6_write,&((v863_7).read_zipper()),&[]);
            }
            v858_15_cursor.ascend(1);
          }
          drop(v862_6_write);
          drop(v862_5);
          map_map_kernels::compose(&(v861_4),&(v862_6))
        };
        drop(v861_4);
        join_wrapped_into(&mut v860_7_write,&((v861_7).read_zipper()),&[]);
        }
        v858_15_cursor.ascend(1);
      }
      drop(v860_7_write);
      drop(v860_6);
      map_map_kernels::compose(&(v859_5),&(v860_7))
    };
    drop(v859_5);
    let v859_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v859_2));
    drop(v859_2);
    let v859_10: Space = if map_kernels::has_head(&(v859_9)) { singleton(&[]) } else { Space::new() };
    drop(v859_9);
    let v859_13: Space = if (&(v859_10)).is_empty() { Space::new() } else {
      let mut v865_12 = Space::new();
      let mut v865_12_write = v865_12.write_zipper();
      for v865_12_byte in v858_15_cursor.child_mask().iter() {
        v858_15_cursor.descend_to_existing_byte(v865_12_byte);
        {
        let v866_2: Space = singleton(&v858_15_cursor.path()[(v858_15_origin + 1)..(v858_15_origin + 2)]);
        let v866_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v866_2));
        drop(v866_2);
        let v866_4: Space = if map_kernels::has_head(&(v866_3)) { singleton(&[]) } else { Space::new() };
        drop(v866_3);
        let v866_7: Space = if (&(v866_4)).is_empty() { Space::new() } else {
          let v867_6: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v858_15_cursor.path()[v858_15_origin..(v858_15_origin + 1)]),&v858_15_cursor.path()[(v858_15_origin + 1)..(v858_15_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v866_4),&(v867_6))
        };
        drop(v866_4);
        join_wrapped_into(&mut v865_12_write,&((v866_7).read_zipper()),&[]);
        }
        v858_15_cursor.ascend(1);
      }
      drop(v865_12_write);
      map_map_kernels::compose(&(v859_10),&(v865_12))
    };
    drop(v859_10);
    let v859_14: Space = map_map_kernels::unite(&(v859_8),&(v859_13));
    drop(v859_13);
    join_wrapped_into(&mut v858_15_write,&((v859_14).read_zipper()),&[]);
    }
    v858_15_cursor.ascend(1);
  }
  drop(v858_15_cursor);
  drop(v858_15_write);
  (v858_15).clone()
}

fn routine_50(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v868_14 = Space::new();
  let mut v868_14_write = v868_14.write_zipper();
  let mut v868_14_cursor = (*s0).read_zipper();
  let v868_14_origin = v868_14_cursor.path().len();
  for v868_14_byte in v868_14_cursor.child_mask().iter() {
    v868_14_cursor.descend_to_existing_byte(v868_14_byte);
    {
    let v869_2: Space = singleton(&v868_14_cursor.path()[v868_14_origin..(v868_14_origin + 1)]);
    let v869_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v869_2));
    let v869_4: Space = if map_kernels::has_head(&(v869_3)) { singleton(&[]) } else { Space::new() };
    drop(v869_3);
    let v869_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v869_4));
    drop(v869_4);
    let v869_8: Space = if (&(v869_5)).is_empty() { Space::new() } else {
      let v870_6: Path = concat_path(&(*p0),&v868_14_cursor.path()[v868_14_origin..(v868_14_origin + 1)]);
      let mut v870_7 = Space::new();
      let mut v870_7_write = v870_7.write_zipper();
      for v870_7_byte in v868_14_cursor.child_mask().iter() {
        v868_14_cursor.descend_to_existing_byte(v870_7_byte);
        {
        let v871_2: Space = singleton(&v868_14_cursor.path()[(v868_14_origin + 1)..(v868_14_origin + 2)]);
        let v871_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v871_2));
        drop(v871_2);
        let v871_4: Space = if map_kernels::has_head(&(v871_3)) { singleton(&[]) } else { Space::new() };
        drop(v871_3);
        let v871_7: Space = if (&(v871_4)).is_empty() { Space::new() } else {
          let v872_5: Path = concat_path(&(v870_6),&v868_14_cursor.path()[(v868_14_origin + 1)..(v868_14_origin + 2)]);
          let mut v872_6 = Space::new();
          let mut v872_6_write = v872_6.write_zipper();
          for v872_6_byte in v868_14_cursor.child_mask().iter() {
            v868_14_cursor.descend_to_existing_byte(v872_6_byte);
            {
            let v873_2: Space = singleton(&v868_14_cursor.path()[(v868_14_origin + 2)..(v868_14_origin + 3)]);
            let v873_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v873_2));
            drop(v873_2);
            let v873_4: Space = if map_kernels::has_head(&(v873_3)) { singleton(&[]) } else { Space::new() };
            drop(v873_3);
            let v873_7: Space = if (&(v873_4)).is_empty() { Space::new() } else {
              let v874_5: Path = concat_path(&(v872_5),&v868_14_cursor.path()[(v868_14_origin + 2)..(v868_14_origin + 3)]);
              let v874_6: Space = routine_24(c, &(v874_5), &v868_14_cursor, &(*s1));
              drop(v874_5);
              map_map_kernels::compose(&(v873_4),&(v874_6))
            };
            drop(v873_4);
            join_wrapped_into(&mut v872_6_write,&((v873_7).read_zipper()),&[]);
            }
            v868_14_cursor.ascend(1);
          }
          drop(v872_6_write);
          drop(v872_5);
          map_map_kernels::compose(&(v871_4),&(v872_6))
        };
        drop(v871_4);
        join_wrapped_into(&mut v870_7_write,&((v871_7).read_zipper()),&[]);
        }
        v868_14_cursor.ascend(1);
      }
      drop(v870_7_write);
      drop(v870_6);
      map_map_kernels::compose(&(v869_5),&(v870_7))
    };
    drop(v869_5);
    let v869_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v869_2));
    drop(v869_2);
    let v869_10: Space = if map_kernels::has_head(&(v869_9)) { singleton(&[]) } else { Space::new() };
    drop(v869_9);
    let v869_13: Space = if (&(v869_10)).is_empty() { Space::new() } else {
      let v875_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v868_14_cursor.path()[v868_14_origin..(v868_14_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v869_10),&(v875_12))
    };
    drop(v869_10);
    let v869_14: Space = map_map_kernels::unite(&(v869_8),&(v869_13));
    drop(v869_13);
    join_wrapped_into(&mut v868_14_write,&((v869_14).read_zipper()),&[]);
    }
    v868_14_cursor.ascend(1);
  }
  drop(v868_14_cursor);
  drop(v868_14_write);
  (v868_14).clone()
}

fn routine_51(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v876_11 = Space::new();
  let mut v876_11_write = v876_11.write_zipper();
  let mut v876_11_cursor = (*s0).read_zipper();
  let v876_11_origin = v876_11_cursor.path().len();
  for v876_11_byte in v876_11_cursor.child_mask().iter() {
    v876_11_cursor.descend_to_existing_byte(v876_11_byte);
    {
    let v877_2: Space = singleton(&v876_11_cursor.path()[v876_11_origin..(v876_11_origin + 1)]);
    let v877_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v877_2));
    drop(v877_2);
    let v877_4: Space = if map_kernels::has_head(&(v877_3)) { singleton(&[]) } else { Space::new() };
    drop(v877_3);
    let v877_7: Space = if (&(v877_4)).is_empty() { Space::new() } else {
      let mut v878_6 = Space::new();
      let mut v878_6_write = v878_6.write_zipper();
      for v878_6_byte in v876_11_cursor.child_mask().iter() {
        v876_11_cursor.descend_to_existing_byte(v878_6_byte);
        {
        let v879_2: Space = singleton(&v876_11_cursor.path()[(v876_11_origin + 1)..(v876_11_origin + 2)]);
        let v879_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v879_2));
        drop(v879_2);
        let v879_4: Space = if map_kernels::has_head(&(v879_3)) { singleton(&[]) } else { Space::new() };
        drop(v879_3);
        let v879_7: Space = if (&(v879_4)).is_empty() { Space::new() } else {
          let v880_6: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v876_11_cursor.path()[v876_11_origin..(v876_11_origin + 1)]),&v876_11_cursor.path()[(v876_11_origin + 1)..(v876_11_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v879_4),&(v880_6))
        };
        drop(v879_4);
        join_wrapped_into(&mut v878_6_write,&((v879_7).read_zipper()),&[]);
        }
        v876_11_cursor.ascend(1);
      }
      drop(v878_6_write);
      map_map_kernels::compose(&(v877_4),&(v878_6))
    };
    drop(v877_4);
    join_wrapped_into(&mut v876_11_write,&((v877_7).read_zipper()),&[]);
    }
    v876_11_cursor.ascend(1);
  }
  drop(v876_11_cursor);
  drop(v876_11_write);
  (v876_11).clone()
}

fn routine_52(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v881_10 = Space::new();
  let mut v881_10_write = v881_10.write_zipper();
  let mut v881_10_cursor = (*s0).read_zipper();
  let v881_10_origin = v881_10_cursor.path().len();
  for v881_10_byte in v881_10_cursor.child_mask().iter() {
    v881_10_cursor.descend_to_existing_byte(v881_10_byte);
    {
    let v882_2: Space = singleton(&v881_10_cursor.path()[v881_10_origin..(v881_10_origin + 1)]);
    let v882_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v882_2));
    drop(v882_2);
    let v882_4: Space = if map_kernels::has_head(&(v882_3)) { singleton(&[]) } else { Space::new() };
    drop(v882_3);
    let v882_7: Space = if (&(v882_4)).is_empty() { Space::new() } else {
      let v883_6: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v881_10_cursor.path()[v881_10_origin..(v881_10_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v882_4),&(v883_6))
    };
    drop(v882_4);
    join_wrapped_into(&mut v881_10_write,&((v882_7).read_zipper()),&[]);
    }
    v881_10_cursor.ascend(1);
  }
  drop(v881_10_cursor);
  drop(v881_10_write);
  (v881_10).clone()
}

fn routine_53(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v884_3: Space = Space::new();
  (v884_3).clone()
}

fn routine_54(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v885_10 = Space::new();
  let mut v885_10_write = v885_10.write_zipper();
  let mut v885_10_cursor = (*s0).read_zipper();
  let v885_10_origin = v885_10_cursor.path().len();
  for v885_10_byte in v885_10_cursor.child_mask().iter() {
    v885_10_cursor.descend_to_existing_byte(v885_10_byte);
    {
    let v886_2: Space = singleton(&v885_10_cursor.path()[v885_10_origin..(v885_10_origin + 1)]);
    let v886_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v886_2));
    drop(v886_2);
    let v886_4: Space = if map_kernels::has_head(&(v886_3)) { singleton(&[]) } else { Space::new() };
    drop(v886_3);
    let v886_7: Space = if (&(v886_4)).is_empty() { Space::new() } else {
      let v887_6: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7)),&(*CONSTANT_4)),&(*p0)),&v885_10_cursor.path()[v885_10_origin..(v885_10_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v886_4),&(v887_6))
    };
    drop(v886_4);
    join_wrapped_into(&mut v885_10_write,&((v886_7).read_zipper()),&[]);
    }
    v885_10_cursor.ascend(1);
  }
  drop(v885_10_cursor);
  drop(v885_10_write);
  (v885_10).clone()
}

fn routine_55(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v888_15 = Space::new();
  let mut v888_15_write = v888_15.write_zipper();
  let mut v888_15_cursor = (*s0).read_zipper();
  let v888_15_origin = v888_15_cursor.path().len();
  for v888_15_byte in v888_15_cursor.child_mask().iter() {
    v888_15_cursor.descend_to_existing_byte(v888_15_byte);
    {
    let v889_2: Space = singleton(&v888_15_cursor.path()[v888_15_origin..(v888_15_origin + 1)]);
    let v889_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v889_2));
    let v889_4: Space = if map_kernels::has_head(&(v889_3)) { singleton(&[]) } else { Space::new() };
    drop(v889_3);
    let v889_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v889_4));
    drop(v889_4);
    let v889_8: Space = if (&(v889_5)).is_empty() { Space::new() } else {
      let v890_6: Path = concat_path(&(*p0),&v888_15_cursor.path()[v888_15_origin..(v888_15_origin + 1)]);
      let mut v890_7 = Space::new();
      let mut v890_7_write = v890_7.write_zipper();
      for v890_7_byte in v888_15_cursor.child_mask().iter() {
        v888_15_cursor.descend_to_existing_byte(v890_7_byte);
        {
        let v891_2: Space = singleton(&v888_15_cursor.path()[(v888_15_origin + 1)..(v888_15_origin + 2)]);
        let v891_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v891_2));
        drop(v891_2);
        let v891_4: Space = if map_kernels::has_head(&(v891_3)) { singleton(&[]) } else { Space::new() };
        drop(v891_3);
        let v891_7: Space = if (&(v891_4)).is_empty() { Space::new() } else {
          let v892_5: Path = concat_path(&(v890_6),&v888_15_cursor.path()[(v888_15_origin + 1)..(v888_15_origin + 2)]);
          let mut v892_6 = Space::new();
          let mut v892_6_write = v892_6.write_zipper();
          for v892_6_byte in v888_15_cursor.child_mask().iter() {
            v888_15_cursor.descend_to_existing_byte(v892_6_byte);
            {
            let v893_2: Space = singleton(&v888_15_cursor.path()[(v888_15_origin + 2)..(v888_15_origin + 3)]);
            let v893_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v893_2));
            drop(v893_2);
            let v893_4: Space = if map_kernels::has_head(&(v893_3)) { singleton(&[]) } else { Space::new() };
            drop(v893_3);
            let v893_7: Space = if (&(v893_4)).is_empty() { Space::new() } else {
              let v894_5: Path = concat_path(&(v892_5),&v888_15_cursor.path()[(v888_15_origin + 2)..(v888_15_origin + 3)]);
              let v894_6: Space = routine_33(c, &(v894_5), &v888_15_cursor, &(*s1));
              drop(v894_5);
              map_map_kernels::compose(&(v893_4),&(v894_6))
            };
            drop(v893_4);
            join_wrapped_into(&mut v892_6_write,&((v893_7).read_zipper()),&[]);
            }
            v888_15_cursor.ascend(1);
          }
          drop(v892_6_write);
          drop(v892_5);
          map_map_kernels::compose(&(v891_4),&(v892_6))
        };
        drop(v891_4);
        join_wrapped_into(&mut v890_7_write,&((v891_7).read_zipper()),&[]);
        }
        v888_15_cursor.ascend(1);
      }
      drop(v890_7_write);
      drop(v890_6);
      map_map_kernels::compose(&(v889_5),&(v890_7))
    };
    drop(v889_5);
    let v889_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v889_2));
    drop(v889_2);
    let v889_10: Space = if map_kernels::has_head(&(v889_9)) { singleton(&[]) } else { Space::new() };
    drop(v889_9);
    let v889_13: Space = if (&(v889_10)).is_empty() { Space::new() } else {
      let mut v895_12 = Space::new();
      let mut v895_12_write = v895_12.write_zipper();
      for v895_12_byte in v888_15_cursor.child_mask().iter() {
        v888_15_cursor.descend_to_existing_byte(v895_12_byte);
        {
        let v896_2: Space = singleton(&v888_15_cursor.path()[(v888_15_origin + 1)..(v888_15_origin + 2)]);
        let v896_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v896_2));
        drop(v896_2);
        let v896_4: Space = if map_kernels::has_head(&(v896_3)) { singleton(&[]) } else { Space::new() };
        drop(v896_3);
        let v896_7: Space = if (&(v896_4)).is_empty() { Space::new() } else {
          let v897_6: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v888_15_cursor.path()[v888_15_origin..(v888_15_origin + 1)]),&v888_15_cursor.path()[(v888_15_origin + 1)..(v888_15_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v896_4),&(v897_6))
        };
        drop(v896_4);
        join_wrapped_into(&mut v895_12_write,&((v896_7).read_zipper()),&[]);
        }
        v888_15_cursor.ascend(1);
      }
      drop(v895_12_write);
      map_map_kernels::compose(&(v889_10),&(v895_12))
    };
    drop(v889_10);
    let v889_14: Space = map_map_kernels::unite(&(v889_8),&(v889_13));
    drop(v889_13);
    join_wrapped_into(&mut v888_15_write,&((v889_14).read_zipper()),&[]);
    }
    v888_15_cursor.ascend(1);
  }
  drop(v888_15_cursor);
  drop(v888_15_write);
  (v888_15).clone()
}

fn routine_56(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v898_14 = Space::new();
  let mut v898_14_write = v898_14.write_zipper();
  let mut v898_14_cursor = (*s0).read_zipper();
  let v898_14_origin = v898_14_cursor.path().len();
  for v898_14_byte in v898_14_cursor.child_mask().iter() {
    v898_14_cursor.descend_to_existing_byte(v898_14_byte);
    {
    let v899_2: Space = singleton(&v898_14_cursor.path()[v898_14_origin..(v898_14_origin + 1)]);
    let v899_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v899_2));
    let v899_4: Space = if map_kernels::has_head(&(v899_3)) { singleton(&[]) } else { Space::new() };
    drop(v899_3);
    let v899_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v899_4));
    drop(v899_4);
    let v899_8: Space = if (&(v899_5)).is_empty() { Space::new() } else {
      let v900_6: Path = concat_path(&(*p0),&v898_14_cursor.path()[v898_14_origin..(v898_14_origin + 1)]);
      let mut v900_7 = Space::new();
      let mut v900_7_write = v900_7.write_zipper();
      for v900_7_byte in v898_14_cursor.child_mask().iter() {
        v898_14_cursor.descend_to_existing_byte(v900_7_byte);
        {
        let v901_2: Space = singleton(&v898_14_cursor.path()[(v898_14_origin + 1)..(v898_14_origin + 2)]);
        let v901_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v901_2));
        drop(v901_2);
        let v901_4: Space = if map_kernels::has_head(&(v901_3)) { singleton(&[]) } else { Space::new() };
        drop(v901_3);
        let v901_7: Space = if (&(v901_4)).is_empty() { Space::new() } else {
          let v902_5: Path = concat_path(&(v900_6),&v898_14_cursor.path()[(v898_14_origin + 1)..(v898_14_origin + 2)]);
          let mut v902_6 = Space::new();
          let mut v902_6_write = v902_6.write_zipper();
          for v902_6_byte in v898_14_cursor.child_mask().iter() {
            v898_14_cursor.descend_to_existing_byte(v902_6_byte);
            {
            let v903_2: Space = singleton(&v898_14_cursor.path()[(v898_14_origin + 2)..(v898_14_origin + 3)]);
            let v903_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v903_2));
            drop(v903_2);
            let v903_4: Space = if map_kernels::has_head(&(v903_3)) { singleton(&[]) } else { Space::new() };
            drop(v903_3);
            let v903_7: Space = if (&(v903_4)).is_empty() { Space::new() } else {
              let v904_5: Path = concat_path(&(v902_5),&v898_14_cursor.path()[(v898_14_origin + 2)..(v898_14_origin + 3)]);
              let v904_6: Space = routine_33(c, &(v904_5), &v898_14_cursor, &(*s1));
              drop(v904_5);
              map_map_kernels::compose(&(v903_4),&(v904_6))
            };
            drop(v903_4);
            join_wrapped_into(&mut v902_6_write,&((v903_7).read_zipper()),&[]);
            }
            v898_14_cursor.ascend(1);
          }
          drop(v902_6_write);
          drop(v902_5);
          map_map_kernels::compose(&(v901_4),&(v902_6))
        };
        drop(v901_4);
        join_wrapped_into(&mut v900_7_write,&((v901_7).read_zipper()),&[]);
        }
        v898_14_cursor.ascend(1);
      }
      drop(v900_7_write);
      drop(v900_6);
      map_map_kernels::compose(&(v899_5),&(v900_7))
    };
    drop(v899_5);
    let v899_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v899_2));
    drop(v899_2);
    let v899_10: Space = if map_kernels::has_head(&(v899_9)) { singleton(&[]) } else { Space::new() };
    drop(v899_9);
    let v899_13: Space = if (&(v899_10)).is_empty() { Space::new() } else {
      let v905_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v898_14_cursor.path()[v898_14_origin..(v898_14_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v899_10),&(v905_12))
    };
    drop(v899_10);
    let v899_14: Space = map_map_kernels::unite(&(v899_8),&(v899_13));
    drop(v899_13);
    join_wrapped_into(&mut v898_14_write,&((v899_14).read_zipper()),&[]);
    }
    v898_14_cursor.ascend(1);
  }
  drop(v898_14_cursor);
  drop(v898_14_write);
  (v898_14).clone()
}

fn routine_57(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v906_11 = Space::new();
  let mut v906_11_write = v906_11.write_zipper();
  let mut v906_11_cursor = (*s0).read_zipper();
  let v906_11_origin = v906_11_cursor.path().len();
  for v906_11_byte in v906_11_cursor.child_mask().iter() {
    v906_11_cursor.descend_to_existing_byte(v906_11_byte);
    {
    let v907_2: Space = singleton(&v906_11_cursor.path()[v906_11_origin..(v906_11_origin + 1)]);
    let v907_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v907_2));
    drop(v907_2);
    let v907_4: Space = if map_kernels::has_head(&(v907_3)) { singleton(&[]) } else { Space::new() };
    drop(v907_3);
    let v907_7: Space = if (&(v907_4)).is_empty() { Space::new() } else {
      let mut v908_6 = Space::new();
      let mut v908_6_write = v908_6.write_zipper();
      for v908_6_byte in v906_11_cursor.child_mask().iter() {
        v906_11_cursor.descend_to_existing_byte(v908_6_byte);
        {
        let v909_2: Space = singleton(&v906_11_cursor.path()[(v906_11_origin + 1)..(v906_11_origin + 2)]);
        let v909_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v909_2));
        drop(v909_2);
        let v909_4: Space = if map_kernels::has_head(&(v909_3)) { singleton(&[]) } else { Space::new() };
        drop(v909_3);
        let v909_7: Space = if (&(v909_4)).is_empty() { Space::new() } else {
          let v910_6: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v906_11_cursor.path()[v906_11_origin..(v906_11_origin + 1)]),&v906_11_cursor.path()[(v906_11_origin + 1)..(v906_11_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v909_4),&(v910_6))
        };
        drop(v909_4);
        join_wrapped_into(&mut v908_6_write,&((v909_7).read_zipper()),&[]);
        }
        v906_11_cursor.ascend(1);
      }
      drop(v908_6_write);
      map_map_kernels::compose(&(v907_4),&(v908_6))
    };
    drop(v907_4);
    join_wrapped_into(&mut v906_11_write,&((v907_7).read_zipper()),&[]);
    }
    v906_11_cursor.ascend(1);
  }
  drop(v906_11_cursor);
  drop(v906_11_write);
  (v906_11).clone()
}

fn routine_58(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v911_10 = Space::new();
  let mut v911_10_write = v911_10.write_zipper();
  let mut v911_10_cursor = (*s0).read_zipper();
  let v911_10_origin = v911_10_cursor.path().len();
  for v911_10_byte in v911_10_cursor.child_mask().iter() {
    v911_10_cursor.descend_to_existing_byte(v911_10_byte);
    {
    let v912_2: Space = singleton(&v911_10_cursor.path()[v911_10_origin..(v911_10_origin + 1)]);
    let v912_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v912_2));
    drop(v912_2);
    let v912_4: Space = if map_kernels::has_head(&(v912_3)) { singleton(&[]) } else { Space::new() };
    drop(v912_3);
    let v912_7: Space = if (&(v912_4)).is_empty() { Space::new() } else {
      let v913_6: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v911_10_cursor.path()[v911_10_origin..(v911_10_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v912_4),&(v913_6))
    };
    drop(v912_4);
    join_wrapped_into(&mut v911_10_write,&((v912_7).read_zipper()),&[]);
    }
    v911_10_cursor.ascend(1);
  }
  drop(v911_10_cursor);
  drop(v911_10_write);
  (v911_10).clone()
}

fn routine_59(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v914_3: Space = Space::new();
  (v914_3).clone()
}

fn routine_60(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v915_10 = Space::new();
  let mut v915_10_write = v915_10.write_zipper();
  let mut v915_10_cursor = (*s0).read_zipper();
  let v915_10_origin = v915_10_cursor.path().len();
  for v915_10_byte in v915_10_cursor.child_mask().iter() {
    v915_10_cursor.descend_to_existing_byte(v915_10_byte);
    {
    let v916_2: Space = singleton(&v915_10_cursor.path()[v915_10_origin..(v915_10_origin + 1)]);
    let v916_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v916_2));
    drop(v916_2);
    let v916_4: Space = if map_kernels::has_head(&(v916_3)) { singleton(&[]) } else { Space::new() };
    drop(v916_3);
    let v916_7: Space = if (&(v916_4)).is_empty() { Space::new() } else {
      let v917_6: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v915_10_cursor.path()[v915_10_origin..(v915_10_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v916_4),&(v917_6))
    };
    drop(v916_4);
    join_wrapped_into(&mut v915_10_write,&((v916_7).read_zipper()),&[]);
    }
    v915_10_cursor.ascend(1);
  }
  drop(v915_10_cursor);
  drop(v915_10_write);
  (v915_10).clone()
}

fn routine_61(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v918_15 = Space::new();
  let mut v918_15_write = v918_15.write_zipper();
  let mut v918_15_cursor = (*s0).read_zipper();
  let v918_15_origin = v918_15_cursor.path().len();
  for v918_15_byte in v918_15_cursor.child_mask().iter() {
    v918_15_cursor.descend_to_existing_byte(v918_15_byte);
    {
    let v919_2: Space = singleton(&v918_15_cursor.path()[v918_15_origin..(v918_15_origin + 1)]);
    let v919_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v919_2));
    let v919_4: Space = if map_kernels::has_head(&(v919_3)) { singleton(&[]) } else { Space::new() };
    drop(v919_3);
    let v919_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v919_4));
    drop(v919_4);
    let v919_8: Space = if (&(v919_5)).is_empty() { Space::new() } else {
      let v920_6: Path = concat_path(&(*p0),&v918_15_cursor.path()[v918_15_origin..(v918_15_origin + 1)]);
      let mut v920_7 = Space::new();
      let mut v920_7_write = v920_7.write_zipper();
      for v920_7_byte in v918_15_cursor.child_mask().iter() {
        v918_15_cursor.descend_to_existing_byte(v920_7_byte);
        {
        let v921_2: Space = singleton(&v918_15_cursor.path()[(v918_15_origin + 1)..(v918_15_origin + 2)]);
        let v921_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v921_2));
        drop(v921_2);
        let v921_4: Space = if map_kernels::has_head(&(v921_3)) { singleton(&[]) } else { Space::new() };
        drop(v921_3);
        let v921_7: Space = if (&(v921_4)).is_empty() { Space::new() } else {
          let v922_5: Path = concat_path(&(v920_6),&v918_15_cursor.path()[(v918_15_origin + 1)..(v918_15_origin + 2)]);
          let mut v922_6 = Space::new();
          let mut v922_6_write = v922_6.write_zipper();
          for v922_6_byte in v918_15_cursor.child_mask().iter() {
            v918_15_cursor.descend_to_existing_byte(v922_6_byte);
            {
            let v923_2: Space = singleton(&v918_15_cursor.path()[(v918_15_origin + 2)..(v918_15_origin + 3)]);
            let v923_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v923_2));
            drop(v923_2);
            let v923_4: Space = if map_kernels::has_head(&(v923_3)) { singleton(&[]) } else { Space::new() };
            drop(v923_3);
            let v923_7: Space = if (&(v923_4)).is_empty() { Space::new() } else {
              let v924_5: Path = concat_path(&(v922_5),&v918_15_cursor.path()[(v918_15_origin + 2)..(v918_15_origin + 3)]);
              let v924_6: Space = routine_44(c, &(v924_5), &v918_15_cursor, &(*s1));
              drop(v924_5);
              map_map_kernels::compose(&(v923_4),&(v924_6))
            };
            drop(v923_4);
            join_wrapped_into(&mut v922_6_write,&((v923_7).read_zipper()),&[]);
            }
            v918_15_cursor.ascend(1);
          }
          drop(v922_6_write);
          drop(v922_5);
          map_map_kernels::compose(&(v921_4),&(v922_6))
        };
        drop(v921_4);
        join_wrapped_into(&mut v920_7_write,&((v921_7).read_zipper()),&[]);
        }
        v918_15_cursor.ascend(1);
      }
      drop(v920_7_write);
      drop(v920_6);
      map_map_kernels::compose(&(v919_5),&(v920_7))
    };
    drop(v919_5);
    let v919_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v919_2));
    drop(v919_2);
    let v919_10: Space = if map_kernels::has_head(&(v919_9)) { singleton(&[]) } else { Space::new() };
    drop(v919_9);
    let v919_13: Space = if (&(v919_10)).is_empty() { Space::new() } else {
      let mut v925_12 = Space::new();
      let mut v925_12_write = v925_12.write_zipper();
      for v925_12_byte in v918_15_cursor.child_mask().iter() {
        v918_15_cursor.descend_to_existing_byte(v925_12_byte);
        {
        let v926_2: Space = singleton(&v918_15_cursor.path()[(v918_15_origin + 1)..(v918_15_origin + 2)]);
        let v926_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v926_2));
        drop(v926_2);
        let v926_4: Space = if map_kernels::has_head(&(v926_3)) { singleton(&[]) } else { Space::new() };
        drop(v926_3);
        let v926_7: Space = if (&(v926_4)).is_empty() { Space::new() } else {
          let v927_6: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v918_15_cursor.path()[v918_15_origin..(v918_15_origin + 1)]),&v918_15_cursor.path()[(v918_15_origin + 1)..(v918_15_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v926_4),&(v927_6))
        };
        drop(v926_4);
        join_wrapped_into(&mut v925_12_write,&((v926_7).read_zipper()),&[]);
        }
        v918_15_cursor.ascend(1);
      }
      drop(v925_12_write);
      map_map_kernels::compose(&(v919_10),&(v925_12))
    };
    drop(v919_10);
    let v919_14: Space = map_map_kernels::unite(&(v919_8),&(v919_13));
    drop(v919_13);
    join_wrapped_into(&mut v918_15_write,&((v919_14).read_zipper()),&[]);
    }
    v918_15_cursor.ascend(1);
  }
  drop(v918_15_cursor);
  drop(v918_15_write);
  (v918_15).clone()
}

fn routine_62(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v928_14 = Space::new();
  let mut v928_14_write = v928_14.write_zipper();
  let mut v928_14_cursor = (*s0).read_zipper();
  let v928_14_origin = v928_14_cursor.path().len();
  for v928_14_byte in v928_14_cursor.child_mask().iter() {
    v928_14_cursor.descend_to_existing_byte(v928_14_byte);
    {
    let v929_2: Space = singleton(&v928_14_cursor.path()[v928_14_origin..(v928_14_origin + 1)]);
    let v929_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v929_2));
    let v929_4: Space = if map_kernels::has_head(&(v929_3)) { singleton(&[]) } else { Space::new() };
    drop(v929_3);
    let v929_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v929_4));
    drop(v929_4);
    let v929_8: Space = if (&(v929_5)).is_empty() { Space::new() } else {
      let v930_6: Path = concat_path(&(*p0),&v928_14_cursor.path()[v928_14_origin..(v928_14_origin + 1)]);
      let mut v930_7 = Space::new();
      let mut v930_7_write = v930_7.write_zipper();
      for v930_7_byte in v928_14_cursor.child_mask().iter() {
        v928_14_cursor.descend_to_existing_byte(v930_7_byte);
        {
        let v931_2: Space = singleton(&v928_14_cursor.path()[(v928_14_origin + 1)..(v928_14_origin + 2)]);
        let v931_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v931_2));
        drop(v931_2);
        let v931_4: Space = if map_kernels::has_head(&(v931_3)) { singleton(&[]) } else { Space::new() };
        drop(v931_3);
        let v931_7: Space = if (&(v931_4)).is_empty() { Space::new() } else {
          let v932_5: Path = concat_path(&(v930_6),&v928_14_cursor.path()[(v928_14_origin + 1)..(v928_14_origin + 2)]);
          let mut v932_6 = Space::new();
          let mut v932_6_write = v932_6.write_zipper();
          for v932_6_byte in v928_14_cursor.child_mask().iter() {
            v928_14_cursor.descend_to_existing_byte(v932_6_byte);
            {
            let v933_2: Space = singleton(&v928_14_cursor.path()[(v928_14_origin + 2)..(v928_14_origin + 3)]);
            let v933_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v933_2));
            drop(v933_2);
            let v933_4: Space = if map_kernels::has_head(&(v933_3)) { singleton(&[]) } else { Space::new() };
            drop(v933_3);
            let v933_7: Space = if (&(v933_4)).is_empty() { Space::new() } else {
              let v934_5: Path = concat_path(&(v932_5),&v928_14_cursor.path()[(v928_14_origin + 2)..(v928_14_origin + 3)]);
              let v934_6: Space = routine_44(c, &(v934_5), &v928_14_cursor, &(*s1));
              drop(v934_5);
              map_map_kernels::compose(&(v933_4),&(v934_6))
            };
            drop(v933_4);
            join_wrapped_into(&mut v932_6_write,&((v933_7).read_zipper()),&[]);
            }
            v928_14_cursor.ascend(1);
          }
          drop(v932_6_write);
          drop(v932_5);
          map_map_kernels::compose(&(v931_4),&(v932_6))
        };
        drop(v931_4);
        join_wrapped_into(&mut v930_7_write,&((v931_7).read_zipper()),&[]);
        }
        v928_14_cursor.ascend(1);
      }
      drop(v930_7_write);
      drop(v930_6);
      map_map_kernels::compose(&(v929_5),&(v930_7))
    };
    drop(v929_5);
    let v929_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v929_2));
    drop(v929_2);
    let v929_10: Space = if map_kernels::has_head(&(v929_9)) { singleton(&[]) } else { Space::new() };
    drop(v929_9);
    let v929_13: Space = if (&(v929_10)).is_empty() { Space::new() } else {
      let v935_12: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v928_14_cursor.path()[v928_14_origin..(v928_14_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v929_10),&(v935_12))
    };
    drop(v929_10);
    let v929_14: Space = map_map_kernels::unite(&(v929_8),&(v929_13));
    drop(v929_13);
    join_wrapped_into(&mut v928_14_write,&((v929_14).read_zipper()),&[]);
    }
    v928_14_cursor.ascend(1);
  }
  drop(v928_14_cursor);
  drop(v928_14_write);
  (v928_14).clone()
}

fn routine_63(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v936_11 = Space::new();
  let mut v936_11_write = v936_11.write_zipper();
  let mut v936_11_cursor = (*s0).read_zipper();
  let v936_11_origin = v936_11_cursor.path().len();
  for v936_11_byte in v936_11_cursor.child_mask().iter() {
    v936_11_cursor.descend_to_existing_byte(v936_11_byte);
    {
    let v937_2: Space = singleton(&v936_11_cursor.path()[v936_11_origin..(v936_11_origin + 1)]);
    let v937_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v937_2));
    drop(v937_2);
    let v937_4: Space = if map_kernels::has_head(&(v937_3)) { singleton(&[]) } else { Space::new() };
    drop(v937_3);
    let v937_7: Space = if (&(v937_4)).is_empty() { Space::new() } else {
      let mut v938_6 = Space::new();
      let mut v938_6_write = v938_6.write_zipper();
      for v938_6_byte in v936_11_cursor.child_mask().iter() {
        v936_11_cursor.descend_to_existing_byte(v938_6_byte);
        {
        let v939_2: Space = singleton(&v936_11_cursor.path()[(v936_11_origin + 1)..(v936_11_origin + 2)]);
        let v939_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v939_2));
        drop(v939_2);
        let v939_4: Space = if map_kernels::has_head(&(v939_3)) { singleton(&[]) } else { Space::new() };
        drop(v939_3);
        let v939_7: Space = if (&(v939_4)).is_empty() { Space::new() } else {
          let v940_6: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v936_11_cursor.path()[v936_11_origin..(v936_11_origin + 1)]),&v936_11_cursor.path()[(v936_11_origin + 1)..(v936_11_origin + 2)])),&(*CONSTANT_5));
          map_map_kernels::compose(&(v939_4),&(v940_6))
        };
        drop(v939_4);
        join_wrapped_into(&mut v938_6_write,&((v939_7).read_zipper()),&[]);
        }
        v936_11_cursor.ascend(1);
      }
      drop(v938_6_write);
      map_map_kernels::compose(&(v937_4),&(v938_6))
    };
    drop(v937_4);
    join_wrapped_into(&mut v936_11_write,&((v937_7).read_zipper()),&[]);
    }
    v936_11_cursor.ascend(1);
  }
  drop(v936_11_cursor);
  drop(v936_11_write);
  (v936_11).clone()
}

fn routine_64(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v941_10 = Space::new();
  let mut v941_10_write = v941_10.write_zipper();
  let mut v941_10_cursor = (*s0).read_zipper();
  let v941_10_origin = v941_10_cursor.path().len();
  for v941_10_byte in v941_10_cursor.child_mask().iter() {
    v941_10_cursor.descend_to_existing_byte(v941_10_byte);
    {
    let v942_2: Space = singleton(&v941_10_cursor.path()[v941_10_origin..(v941_10_origin + 1)]);
    let v942_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v942_2));
    drop(v942_2);
    let v942_4: Space = if map_kernels::has_head(&(v942_3)) { singleton(&[]) } else { Space::new() };
    drop(v942_3);
    let v942_7: Space = if (&(v942_4)).is_empty() { Space::new() } else {
      let v943_6: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v941_10_cursor.path()[v941_10_origin..(v941_10_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v942_4),&(v943_6))
    };
    drop(v942_4);
    join_wrapped_into(&mut v941_10_write,&((v942_7).read_zipper()),&[]);
    }
    v941_10_cursor.ascend(1);
  }
  drop(v941_10_cursor);
  drop(v941_10_write);
  (v941_10).clone()
}

fn routine_65(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v944_3: Space = Space::new();
  (v944_3).clone()
}

fn routine_66(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v945_10 = Space::new();
  let mut v945_10_write = v945_10.write_zipper();
  let mut v945_10_cursor = (*s0).read_zipper();
  let v945_10_origin = v945_10_cursor.path().len();
  for v945_10_byte in v945_10_cursor.child_mask().iter() {
    v945_10_cursor.descend_to_existing_byte(v945_10_byte);
    {
    let v946_2: Space = singleton(&v945_10_cursor.path()[v945_10_origin..(v945_10_origin + 1)]);
    let v946_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v946_2));
    drop(v946_2);
    let v946_4: Space = if map_kernels::has_head(&(v946_3)) { singleton(&[]) } else { Space::new() };
    drop(v946_3);
    let v946_7: Space = if (&(v946_4)).is_empty() { Space::new() } else {
      let v947_6: Space = view_map_kernels::subtract(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_4)),&(*p0)),&v945_10_cursor.path()[v945_10_origin..(v945_10_origin + 1)])),&(*CONSTANT_5));
      map_map_kernels::compose(&(v946_4),&(v947_6))
    };
    drop(v946_4);
    join_wrapped_into(&mut v945_10_write,&((v946_7).read_zipper()),&[]);
    }
    v945_10_cursor.ascend(1);
  }
  drop(v945_10_cursor);
  drop(v945_10_write);
  (v945_10).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
