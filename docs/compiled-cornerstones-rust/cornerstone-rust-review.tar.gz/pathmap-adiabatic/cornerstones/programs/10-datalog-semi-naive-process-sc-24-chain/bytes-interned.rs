#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("94 16 0 0 0 0 0 0 0 2 0 0 0 3 0 0 0 4 16 0 0 0 0 0 0 0 2 0 0 0 3 0 0 0 5 16 0 0 0 0 0 0 0 2 0 0 0 4 0 0 0 5 16 0 0 0 0 0 0 0 2 0 0 0 4 0 0 0 6 16 0 0 0 0 0 0 0 2 0 0 0 5 0 0 0 6 16 0 0 0 0 0 0 0 2 0 0 0 5 0 0 0 19 16 0 0 0 0 0 0 0 2 0 0 0 6 0 0 0 19 16 0 0 0 0 0 0 0 2 0 0 0 6 0 0 0 23 16 0 0 0 0 0 0 0 2 0 0 0 7 0 0 0 8 16 0 0 0 0 0 0 0 2 0 0 0 7 0 0 0 9 16 0 0 0 0 0 0 0 2 0 0 0 8 0 0 0 9 16 0 0 0 0 0 0 0 2 0 0 0 8 0 0 0 10 16 0 0 0 0 0 0 0 2 0 0 0 9 0 0 0 10 16 0 0 0 0 0 0 0 2 0 0 0 9 0 0 0 11 16 0 0 0 0 0 0 0 2 0 0 0 10 0 0 0 11 16 0 0 0 0 0 0 0 2 0 0 0 10 0 0 0 12 16 0 0 0 0 0 0 0 2 0 0 0 11 0 0 0 12 16 0 0 0 0 0 0 0 2 0 0 0 11 0 0 0 13 16 0 0 0 0 0 0 0 2 0 0 0 12 0 0 0 13 16 0 0 0 0 0 0 0 2 0 0 0 12 0 0 0 14 16 0 0 0 0 0 0 0 2 0 0 0 13 0 0 0 14 16 0 0 0 0 0 0 0 2 0 0 0 13 0 0 0 15 16 0 0 0 0 0 0 0 2 0 0 0 14 0 0 0 15 16 0 0 0 0 0 0 0 2 0 0 0 14 0 0 0 16 16 0 0 0 0 0 0 0 2 0 0 0 15 0 0 0 16 16 0 0 0 0 0 0 0 2 0 0 0 15 0 0 0 17 16 0 0 0 0 0 0 0 2 0 0 0 16 0 0 0 17 16 0 0 0 0 0 0 0 2 0 0 0 16 0 0 0 18 16 0 0 0 0 0 0 0 2 0 0 0 17 0 0 0 18 16 0 0 0 0 0 0 0 2 0 0 0 17 0 0 0 20 16 0 0 0 0 0 0 0 2 0 0 0 18 0 0 0 20 16 0 0 0 0 0 0 0 2 0 0 0 18 0 0 0 21 16 0 0 0 0 0 0 0 2 0 0 0 19 0 0 0 23 16 0 0 0 0 0 0 0 2 0 0 0 19 0 0 0 24 16 0 0 0 0 0 0 0 2 0 0 0 20 0 0 0 21 16 0 0 0 0 0 0 0 2 0 0 0 20 0 0 0 22 16 0 0 0 0 0 0 0 2 0 0 0 21 0 0 0 22 16 0 0 0 0 0 0 0 2 0 0 0 23 0 0 0 24 16 0 0 0 0 0 0 0 2 0 0 0 23 0 0 0 25 16 0 0 0 0 0 0 0 2 0 0 0 24 0 0 0 25 16 0 0 0 0 0 0 0 2 0 0 0 24 0 0 0 26 16 0 0 0 0 0 0 0 2 0 0 0 25 0 0 0 26 16 0 0 0 0 0 0 0 2 0 0 0 25 0 0 0 27 16 0 0 0 0 0 0 0 2 0 0 0 26 0 0 0 7 16 0 0 0 0 0 0 0 2 0 0 0 26 0 0 0 27 16 0 0 0 0 0 0 0 2 0 0 0 27 0 0 0 7 16 0 0 0 0 0 0 0 2 0 0 0 27 0 0 0 8 16 0 0 0 28 0 0 0 1 0 0 0 3 0 0 0 4 16 0 0 0 28 0 0 0 1 0 0 0 3 0 0 0 5 16 0 0 0 28 0 0 0 1 0 0 0 4 0 0 0 5 16 0 0 0 28 0 0 0 1 0 0 0 4 0 0 0 6 16 0 0 0 28 0 0 0 1 0 0 0 5 0 0 0 6 16 0 0 0 28 0 0 0 1 0 0 0 5 0 0 0 19 16 0 0 0 28 0 0 0 1 0 0 0 6 0 0 0 19 16 0 0 0 28 0 0 0 1 0 0 0 6 0 0 0 23 16 0 0 0 28 0 0 0 1 0 0 0 7 0 0 0 8 16 0 0 0 28 0 0 0 1 0 0 0 7 0 0 0 9 16 0 0 0 28 0 0 0 1 0 0 0 8 0 0 0 9 16 0 0 0 28 0 0 0 1 0 0 0 8 0 0 0 10 16 0 0 0 28 0 0 0 1 0 0 0 9 0 0 0 10 16 0 0 0 28 0 0 0 1 0 0 0 9 0 0 0 11 16 0 0 0 28 0 0 0 1 0 0 0 10 0 0 0 11 16 0 0 0 28 0 0 0 1 0 0 0 10 0 0 0 12 16 0 0 0 28 0 0 0 1 0 0 0 11 0 0 0 12 16 0 0 0 28 0 0 0 1 0 0 0 11 0 0 0 13 16 0 0 0 28 0 0 0 1 0 0 0 12 0 0 0 13 16 0 0 0 28 0 0 0 1 0 0 0 12 0 0 0 14 16 0 0 0 28 0 0 0 1 0 0 0 13 0 0 0 14 16 0 0 0 28 0 0 0 1 0 0 0 13 0 0 0 15 16 0 0 0 28 0 0 0 1 0 0 0 14 0 0 0 15 16 0 0 0 28 0 0 0 1 0 0 0 14 0 0 0 16 16 0 0 0 28 0 0 0 1 0 0 0 15 0 0 0 16 16 0 0 0 28 0 0 0 1 0 0 0 15 0 0 0 17 16 0 0 0 28 0 0 0 1 0 0 0 16 0 0 0 17 16 0 0 0 28 0 0 0 1 0 0 0 16 0 0 0 18 16 0 0 0 28 0 0 0 1 0 0 0 17 0 0 0 18 16 0 0 0 28 0 0 0 1 0 0 0 17 0 0 0 20 16 0 0 0 28 0 0 0 1 0 0 0 18 0 0 0 20 16 0 0 0 28 0 0 0 1 0 0 0 18 0 0 0 21 16 0 0 0 28 0 0 0 1 0 0 0 19 0 0 0 23 16 0 0 0 28 0 0 0 1 0 0 0 19 0 0 0 24 16 0 0 0 28 0 0 0 1 0 0 0 20 0 0 0 21 16 0 0 0 28 0 0 0 1 0 0 0 20 0 0 0 22 16 0 0 0 28 0 0 0 1 0 0 0 21 0 0 0 22 16 0 0 0 28 0 0 0 1 0 0 0 23 0 0 0 24 16 0 0 0 28 0 0 0 1 0 0 0 23 0 0 0 25 16 0 0 0 28 0 0 0 1 0 0 0 24 0 0 0 25 16 0 0 0 28 0 0 0 1 0 0 0 24 0 0 0 26 16 0 0 0 28 0 0 0 1 0 0 0 25 0 0 0 26 16 0 0 0 28 0 0 0 1 0 0 0 25 0 0 0 27 16 0 0 0 28 0 0 0 1 0 0 0 26 0 0 0 7 16 0 0 0 28 0 0 0 1 0 0 0 26 0 0 0 27 16 0 0 0 28 0 0 0 1 0 0 0 27 0 0 0 7 16 0 0 0 28 0 0 0 1 0 0 0 27 0 0 0 8"));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("184 16 0 0 0 0 0 0 0 1 0 0 0 3 0 0 0 4 16 0 0 0 0 0 0 0 1 0 0 0 3 0 0 0 5 16 0 0 0 0 0 0 0 1 0 0 0 4 0 0 0 5 16 0 0 0 0 0 0 0 1 0 0 0 4 0 0 0 6 16 0 0 0 0 0 0 0 1 0 0 0 5 0 0 0 6 16 0 0 0 0 0 0 0 1 0 0 0 5 0 0 0 19 16 0 0 0 0 0 0 0 1 0 0 0 6 0 0 0 19 16 0 0 0 0 0 0 0 1 0 0 0 6 0 0 0 23 16 0 0 0 0 0 0 0 1 0 0 0 7 0 0 0 8 16 0 0 0 0 0 0 0 1 0 0 0 7 0 0 0 9 16 0 0 0 0 0 0 0 1 0 0 0 8 0 0 0 9 16 0 0 0 0 0 0 0 1 0 0 0 8 0 0 0 10 16 0 0 0 0 0 0 0 1 0 0 0 9 0 0 0 10 16 0 0 0 0 0 0 0 1 0 0 0 9 0 0 0 11 16 0 0 0 0 0 0 0 1 0 0 0 10 0 0 0 11 16 0 0 0 0 0 0 0 1 0 0 0 10 0 0 0 12 16 0 0 0 0 0 0 0 1 0 0 0 11 0 0 0 12 16 0 0 0 0 0 0 0 1 0 0 0 11 0 0 0 13 16 0 0 0 0 0 0 0 1 0 0 0 12 0 0 0 13 16 0 0 0 0 0 0 0 1 0 0 0 12 0 0 0 14 16 0 0 0 0 0 0 0 1 0 0 0 13 0 0 0 14 16 0 0 0 0 0 0 0 1 0 0 0 13 0 0 0 15 16 0 0 0 0 0 0 0 1 0 0 0 14 0 0 0 15 16 0 0 0 0 0 0 0 1 0 0 0 14 0 0 0 16 16 0 0 0 0 0 0 0 1 0 0 0 15 0 0 0 16 16 0 0 0 0 0 0 0 1 0 0 0 15 0 0 0 17 16 0 0 0 0 0 0 0 1 0 0 0 16 0 0 0 17 16 0 0 0 0 0 0 0 1 0 0 0 16 0 0 0 18 16 0 0 0 0 0 0 0 1 0 0 0 17 0 0 0 18 16 0 0 0 0 0 0 0 1 0 0 0 17 0 0 0 20 16 0 0 0 0 0 0 0 1 0 0 0 18 0 0 0 20 16 0 0 0 0 0 0 0 1 0 0 0 18 0 0 0 21 16 0 0 0 0 0 0 0 1 0 0 0 19 0 0 0 23 16 0 0 0 0 0 0 0 1 0 0 0 19 0 0 0 24 16 0 0 0 0 0 0 0 1 0 0 0 20 0 0 0 21 16 0 0 0 0 0 0 0 1 0 0 0 20 0 0 0 22 16 0 0 0 0 0 0 0 1 0 0 0 21 0 0 0 22 16 0 0 0 0 0 0 0 1 0 0 0 23 0 0 0 24 16 0 0 0 0 0 0 0 1 0 0 0 23 0 0 0 25 16 0 0 0 0 0 0 0 1 0 0 0 24 0 0 0 25 16 0 0 0 0 0 0 0 1 0 0 0 24 0 0 0 26 16 0 0 0 0 0 0 0 1 0 0 0 25 0 0 0 26 16 0 0 0 0 0 0 0 1 0 0 0 25 0 0 0 27 16 0 0 0 0 0 0 0 1 0 0 0 26 0 0 0 7 16 0 0 0 0 0 0 0 1 0 0 0 26 0 0 0 27 16 0 0 0 0 0 0 0 1 0 0 0 27 0 0 0 7 16 0 0 0 0 0 0 0 1 0 0 0 27 0 0 0 8 16 0 0 0 0 0 0 0 2 0 0 0 3 0 0 0 4 16 0 0 0 0 0 0 0 2 0 0 0 3 0 0 0 5 16 0 0 0 0 0 0 0 2 0 0 0 4 0 0 0 5 16 0 0 0 0 0 0 0 2 0 0 0 4 0 0 0 6 16 0 0 0 0 0 0 0 2 0 0 0 5 0 0 0 6 16 0 0 0 0 0 0 0 2 0 0 0 5 0 0 0 19 16 0 0 0 0 0 0 0 2 0 0 0 6 0 0 0 19 16 0 0 0 0 0 0 0 2 0 0 0 6 0 0 0 23 16 0 0 0 0 0 0 0 2 0 0 0 7 0 0 0 8 16 0 0 0 0 0 0 0 2 0 0 0 7 0 0 0 9 16 0 0 0 0 0 0 0 2 0 0 0 8 0 0 0 9 16 0 0 0 0 0 0 0 2 0 0 0 8 0 0 0 10 16 0 0 0 0 0 0 0 2 0 0 0 9 0 0 0 10 16 0 0 0 0 0 0 0 2 0 0 0 9 0 0 0 11 16 0 0 0 0 0 0 0 2 0 0 0 10 0 0 0 11 16 0 0 0 0 0 0 0 2 0 0 0 10 0 0 0 12 16 0 0 0 0 0 0 0 2 0 0 0 11 0 0 0 12 16 0 0 0 0 0 0 0 2 0 0 0 11 0 0 0 13 16 0 0 0 0 0 0 0 2 0 0 0 12 0 0 0 13 16 0 0 0 0 0 0 0 2 0 0 0 12 0 0 0 14 16 0 0 0 0 0 0 0 2 0 0 0 13 0 0 0 14 16 0 0 0 0 0 0 0 2 0 0 0 13 0 0 0 15 16 0 0 0 0 0 0 0 2 0 0 0 14 0 0 0 15 16 0 0 0 0 0 0 0 2 0 0 0 14 0 0 0 16 16 0 0 0 0 0 0 0 2 0 0 0 15 0 0 0 16 16 0 0 0 0 0 0 0 2 0 0 0 15 0 0 0 17 16 0 0 0 0 0 0 0 2 0 0 0 16 0 0 0 17 16 0 0 0 0 0 0 0 2 0 0 0 16 0 0 0 18 16 0 0 0 0 0 0 0 2 0 0 0 17 0 0 0 18 16 0 0 0 0 0 0 0 2 0 0 0 17 0 0 0 20 16 0 0 0 0 0 0 0 2 0 0 0 18 0 0 0 20 16 0 0 0 0 0 0 0 2 0 0 0 18 0 0 0 21 16 0 0 0 0 0 0 0 2 0 0 0 19 0 0 0 23 16 0 0 0 0 0 0 0 2 0 0 0 19 0 0 0 24 16 0 0 0 0 0 0 0 2 0 0 0 20 0 0 0 21 16 0 0 0 0 0 0 0 2 0 0 0 20 0 0 0 22 16 0 0 0 0 0 0 0 2 0 0 0 21 0 0 0 22 16 0 0 0 0 0 0 0 2 0 0 0 23 0 0 0 24 16 0 0 0 0 0 0 0 2 0 0 0 23 0 0 0 25 16 0 0 0 0 0 0 0 2 0 0 0 24 0 0 0 25 16 0 0 0 0 0 0 0 2 0 0 0 24 0 0 0 26 16 0 0 0 0 0 0 0 2 0 0 0 25 0 0 0 26 16 0 0 0 0 0 0 0 2 0 0 0 25 0 0 0 27 16 0 0 0 0 0 0 0 2 0 0 0 26 0 0 0 7 16 0 0 0 0 0 0 0 2 0 0 0 26 0 0 0 27 16 0 0 0 0 0 0 0 2 0 0 0 27 0 0 0 7 16 0 0 0 0 0 0 0 2 0 0 0 27 0 0 0 8 16 0 0 0 28 0 0 0 1 0 0 0 3 0 0 0 4 16 0 0 0 28 0 0 0 1 0 0 0 3 0 0 0 5 16 0 0 0 28 0 0 0 1 0 0 0 3 0 0 0 6 16 0 0 0 28 0 0 0 1 0 0 0 3 0 0 0 19 16 0 0 0 28 0 0 0 1 0 0 0 4 0 0 0 5 16 0 0 0 28 0 0 0 1 0 0 0 4 0 0 0 6 16 0 0 0 28 0 0 0 1 0 0 0 4 0 0 0 19 16 0 0 0 28 0 0 0 1 0 0 0 4 0 0 0 23 16 0 0 0 28 0 0 0 1 0 0 0 5 0 0 0 6 16 0 0 0 28 0 0 0 1 0 0 0 5 0 0 0 19 16 0 0 0 28 0 0 0 1 0 0 0 5 0 0 0 23 16 0 0 0 28 0 0 0 1 0 0 0 5 0 0 0 24 16 0 0 0 28 0 0 0 1 0 0 0 6 0 0 0 19 16 0 0 0 28 0 0 0 1 0 0 0 6 0 0 0 23 16 0 0 0 28 0 0 0 1 0 0 0 6 0 0 0 24 16 0 0 0 28 0 0 0 1 0 0 0 6 0 0 0 25 16 0 0 0 28 0 0 0 1 0 0 0 7 0 0 0 8 16 0 0 0 28 0 0 0 1 0 0 0 7 0 0 0 9 16 0 0 0 28 0 0 0 1 0 0 0 7 0 0 0 10 16 0 0 0 28 0 0 0 1 0 0 0 7 0 0 0 11 16 0 0 0 28 0 0 0 1 0 0 0 8 0 0 0 9 16 0 0 0 28 0 0 0 1 0 0 0 8 0 0 0 10 16 0 0 0 28 0 0 0 1 0 0 0 8 0 0 0 11 16 0 0 0 28 0 0 0 1 0 0 0 8 0 0 0 12 16 0 0 0 28 0 0 0 1 0 0 0 9 0 0 0 10 16 0 0 0 28 0 0 0 1 0 0 0 9 0 0 0 11 16 0 0 0 28 0 0 0 1 0 0 0 9 0 0 0 12 16 0 0 0 28 0 0 0 1 0 0 0 9 0 0 0 13 16 0 0 0 28 0 0 0 1 0 0 0 10 0 0 0 11 16 0 0 0 28 0 0 0 1 0 0 0 10 0 0 0 12 16 0 0 0 28 0 0 0 1 0 0 0 10 0 0 0 13 16 0 0 0 28 0 0 0 1 0 0 0 10 0 0 0 14 16 0 0 0 28 0 0 0 1 0 0 0 11 0 0 0 12 16 0 0 0 28 0 0 0 1 0 0 0 11 0 0 0 13 16 0 0 0 28 0 0 0 1 0 0 0 11 0 0 0 14 16 0 0 0 28 0 0 0 1 0 0 0 11 0 0 0 15 16 0 0 0 28 0 0 0 1 0 0 0 12 0 0 0 13 16 0 0 0 28 0 0 0 1 0 0 0 12 0 0 0 14 16 0 0 0 28 0 0 0 1 0 0 0 12 0 0 0 15 16 0 0 0 28 0 0 0 1 0 0 0 12 0 0 0 16 16 0 0 0 28 0 0 0 1 0 0 0 13 0 0 0 14 16 0 0 0 28 0 0 0 1 0 0 0 13 0 0 0 15 16 0 0 0 28 0 0 0 1 0 0 0 13 0 0 0 16 16 0 0 0 28 0 0 0 1 0 0 0 13 0 0 0 17 16 0 0 0 28 0 0 0 1 0 0 0 14 0 0 0 15 16 0 0 0 28 0 0 0 1 0 0 0 14 0 0 0 16 16 0 0 0 28 0 0 0 1 0 0 0 14 0 0 0 17 16 0 0 0 28 0 0 0 1 0 0 0 14 0 0 0 18 16 0 0 0 28 0 0 0 1 0 0 0 15 0 0 0 16 16 0 0 0 28 0 0 0 1 0 0 0 15 0 0 0 17 16 0 0 0 28 0 0 0 1 0 0 0 15 0 0 0 18 16 0 0 0 28 0 0 0 1 0 0 0 15 0 0 0 20 16 0 0 0 28 0 0 0 1 0 0 0 16 0 0 0 17 16 0 0 0 28 0 0 0 1 0 0 0 16 0 0 0 18 16 0 0 0 28 0 0 0 1 0 0 0 16 0 0 0 20 16 0 0 0 28 0 0 0 1 0 0 0 16 0 0 0 21 16 0 0 0 28 0 0 0 1 0 0 0 17 0 0 0 18 16 0 0 0 28 0 0 0 1 0 0 0 17 0 0 0 20 16 0 0 0 28 0 0 0 1 0 0 0 17 0 0 0 21 16 0 0 0 28 0 0 0 1 0 0 0 17 0 0 0 22 16 0 0 0 28 0 0 0 1 0 0 0 18 0 0 0 20 16 0 0 0 28 0 0 0 1 0 0 0 18 0 0 0 21 16 0 0 0 28 0 0 0 1 0 0 0 18 0 0 0 22 16 0 0 0 28 0 0 0 1 0 0 0 19 0 0 0 23 16 0 0 0 28 0 0 0 1 0 0 0 19 0 0 0 24 16 0 0 0 28 0 0 0 1 0 0 0 19 0 0 0 25 16 0 0 0 28 0 0 0 1 0 0 0 19 0 0 0 26 16 0 0 0 28 0 0 0 1 0 0 0 20 0 0 0 21 16 0 0 0 28 0 0 0 1 0 0 0 20 0 0 0 22 16 0 0 0 28 0 0 0 1 0 0 0 21 0 0 0 22 16 0 0 0 28 0 0 0 1 0 0 0 23 0 0 0 24 16 0 0 0 28 0 0 0 1 0 0 0 23 0 0 0 25 16 0 0 0 28 0 0 0 1 0 0 0 23 0 0 0 26 16 0 0 0 28 0 0 0 1 0 0 0 23 0 0 0 27 16 0 0 0 28 0 0 0 1 0 0 0 24 0 0 0 7 16 0 0 0 28 0 0 0 1 0 0 0 24 0 0 0 25 16 0 0 0 28 0 0 0 1 0 0 0 24 0 0 0 26 16 0 0 0 28 0 0 0 1 0 0 0 24 0 0 0 27 16 0 0 0 28 0 0 0 1 0 0 0 25 0 0 0 7 16 0 0 0 28 0 0 0 1 0 0 0 25 0 0 0 8 16 0 0 0 28 0 0 0 1 0 0 0 25 0 0 0 26 16 0 0 0 28 0 0 0 1 0 0 0 25 0 0 0 27 16 0 0 0 28 0 0 0 1 0 0 0 26 0 0 0 7 16 0 0 0 28 0 0 0 1 0 0 0 26 0 0 0 8 16 0 0 0 28 0 0 0 1 0 0 0 26 0 0 0 9 16 0 0 0 28 0 0 0 1 0 0 0 26 0 0 0 27 16 0 0 0 28 0 0 0 1 0 0 0 27 0 0 0 7 16 0 0 0 28 0 0 0 1 0 0 0 27 0 0 0 8 16 0 0 0 28 0 0 0 1 0 0 0 27 0 0 0 9 16 0 0 0 28 0 0 0 1 0 0 0 27 0 0 0 10"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,0,0,0,1]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,28]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1]));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,2]));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,28,0,0,0,1]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
fn routine_0(c: &mut Context) -> Space {
  let v0_2: Space = routine_1(c, &((*CONSTANT_1).read_zipper()));
  let v0_3: Space = unite(&(*CONSTANT_0),&(v0_2));
  (&(descend_cursor((v0_3).read_zipper(),&(*CONSTANT_2)))).make_map()
}

fn routine_1(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v1_5: Space = unite(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_3))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_4))));
  let v1_6: Space = wrap(&(v1_5),&(*CONSTANT_3));
  drop(v1_5);
  let mut v1_9 = Space::new();
  let mut v1_9_write = v1_9.write_zipper();
  let mut v1_9_cursor = descend_cursor(descend_cursor((*s0).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_5));
  let v1_9_origin = v1_9_cursor.path().len();
  for v1_9_byte in v1_9_cursor.child_mask().iter() {
    v1_9_cursor.descend_to_existing_byte(v1_9_byte);
    {
    for v2_2_byte in v1_9_cursor.child_mask().iter() {
      v1_9_cursor.descend_to_existing_byte(v2_2_byte);
      {
      for v3_3_byte in v1_9_cursor.child_mask().iter() {
        v1_9_cursor.descend_to_existing_byte(v3_3_byte);
        {
        for v4_3_byte in v1_9_cursor.child_mask().iter() {
          v1_9_cursor.descend_to_existing_byte(v4_3_byte);
          {
          let mut v5_2 = Space::new();
          let mut v5_2_write = v5_2.write_zipper();
          for v5_2_byte in v1_9_cursor.child_mask().iter() {
            v1_9_cursor.descend_to_existing_byte(v5_2_byte);
            {
            for v6_2_byte in v1_9_cursor.child_mask().iter() {
              v1_9_cursor.descend_to_existing_byte(v6_2_byte);
              {
              for v7_3_byte in v1_9_cursor.child_mask().iter() {
                v1_9_cursor.descend_to_existing_byte(v7_3_byte);
                {
                for v8_3_byte in v1_9_cursor.child_mask().iter() {
                  v1_9_cursor.descend_to_existing_byte(v8_3_byte);
                  {
                  let v9_3: Space = routine_2(c, &v1_9_cursor.path()[(v1_9_origin + 4)..(v1_9_origin + 8)], &v1_9_cursor, &(*s0));
                  join_wrapped_into(&mut v5_2_write,&((v9_3).read_zipper()),&[]);
                  }
                  v1_9_cursor.ascend(1);
                }
                }
                v1_9_cursor.ascend(1);
              }
              }
              v1_9_cursor.ascend(1);
            }
            }
            v1_9_cursor.ascend(1);
          }
          drop(v5_2_write);
          join_wrapped_into(&mut v1_9_write,&((v5_2).read_zipper()),&v1_9_cursor.path()[v1_9_origin..(v1_9_origin + 4)]);
          }
          v1_9_cursor.ascend(1);
        }
        }
        v1_9_cursor.ascend(1);
      }
      }
      v1_9_cursor.ascend(1);
    }
    }
    v1_9_cursor.ascend(1);
  }
  drop(v1_9_cursor);
  drop(v1_9_write);
  let mut v1_13 = Space::new();
  let mut v1_13_write = v1_13.write_zipper();
  let mut v1_13_cursor = descend_cursor(descend_cursor((*s0).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_6));
  let v1_13_origin = v1_13_cursor.path().len();
  for v1_13_byte in v1_13_cursor.child_mask().iter() {
    v1_13_cursor.descend_to_existing_byte(v1_13_byte);
    {
    for v10_2_byte in v1_13_cursor.child_mask().iter() {
      v1_13_cursor.descend_to_existing_byte(v10_2_byte);
      {
      for v11_3_byte in v1_13_cursor.child_mask().iter() {
        v1_13_cursor.descend_to_existing_byte(v11_3_byte);
        {
        for v12_3_byte in v1_13_cursor.child_mask().iter() {
          v1_13_cursor.descend_to_existing_byte(v12_3_byte);
          {
          v1_13_write.descend_to(&v1_13_cursor.path()[v1_13_origin..(v1_13_origin + 4)]);
          join_branches(&mut v1_13_write,&mut v1_13_cursor);
          v1_13_write.ascend((&v1_13_cursor.path()[v1_13_origin..(v1_13_origin + 4)]).len());
          }
          v1_13_cursor.ascend(1);
        }
        }
        v1_13_cursor.ascend(1);
      }
      }
      v1_13_cursor.ascend(1);
    }
    }
    v1_13_cursor.ascend(1);
  }
  drop(v1_13_cursor);
  drop(v1_13_write);
  let v1_14: Space = unite(&(v1_9),&(v1_13));
  drop(v1_13);
  let mut v1_16 = Space::new();
  let mut v1_16_write = v1_16.write_zipper();
  let mut v1_16_cursor = descend_cursor(descend_cursor((*s0).read_zipper(),&(*CONSTANT_4)),&(*CONSTANT_5));
  let v1_16_origin = v1_16_cursor.path().len();
  for v1_16_byte in v1_16_cursor.child_mask().iter() {
    v1_16_cursor.descend_to_existing_byte(v1_16_byte);
    {
    for v14_2_byte in v1_16_cursor.child_mask().iter() {
      v1_16_cursor.descend_to_existing_byte(v14_2_byte);
      {
      for v15_3_byte in v1_16_cursor.child_mask().iter() {
        v1_16_cursor.descend_to_existing_byte(v15_3_byte);
        {
        for v16_3_byte in v1_16_cursor.child_mask().iter() {
          v1_16_cursor.descend_to_existing_byte(v16_3_byte);
          {
          let mut v17_2 = Space::new();
          let mut v17_2_write = v17_2.write_zipper();
          for v17_2_byte in v1_16_cursor.child_mask().iter() {
            v1_16_cursor.descend_to_existing_byte(v17_2_byte);
            {
            for v18_2_byte in v1_16_cursor.child_mask().iter() {
              v1_16_cursor.descend_to_existing_byte(v18_2_byte);
              {
              for v19_3_byte in v1_16_cursor.child_mask().iter() {
                v1_16_cursor.descend_to_existing_byte(v19_3_byte);
                {
                for v20_3_byte in v1_16_cursor.child_mask().iter() {
                  v1_16_cursor.descend_to_existing_byte(v20_3_byte);
                  {
                  let v21_3: Space = routine_3(c, &v1_16_cursor.path()[(v1_16_origin + 4)..(v1_16_origin + 8)], &v1_16_cursor, &(*s0));
                  join_wrapped_into(&mut v17_2_write,&((v21_3).read_zipper()),&[]);
                  }
                  v1_16_cursor.ascend(1);
                }
                }
                v1_16_cursor.ascend(1);
              }
              }
              v1_16_cursor.ascend(1);
            }
            }
            v1_16_cursor.ascend(1);
          }
          drop(v17_2_write);
          join_wrapped_into(&mut v1_16_write,&((v17_2).read_zipper()),&v1_16_cursor.path()[v1_16_origin..(v1_16_origin + 4)]);
          }
          v1_16_cursor.ascend(1);
        }
        }
        v1_16_cursor.ascend(1);
      }
      }
      v1_16_cursor.ascend(1);
    }
    }
    v1_16_cursor.ascend(1);
  }
  drop(v1_16_cursor);
  drop(v1_16_write);
  let v1_17: Space = unite(&(v1_14),&(v1_16));
  let mut v1_18 = Space::new();
  let mut v1_18_write = v1_18.write_zipper();
  let mut v1_18_cursor = descend_cursor(descend_cursor((*s0).read_zipper(),&(*CONSTANT_4)),&(*CONSTANT_5));
  let v1_18_origin = v1_18_cursor.path().len();
  for v1_18_byte in v1_18_cursor.child_mask().iter() {
    v1_18_cursor.descend_to_existing_byte(v1_18_byte);
    {
    for v22_2_byte in v1_18_cursor.child_mask().iter() {
      v1_18_cursor.descend_to_existing_byte(v22_2_byte);
      {
      for v23_3_byte in v1_18_cursor.child_mask().iter() {
        v1_18_cursor.descend_to_existing_byte(v23_3_byte);
        {
        for v24_3_byte in v1_18_cursor.child_mask().iter() {
          v1_18_cursor.descend_to_existing_byte(v24_3_byte);
          {
          let mut v25_2 = Space::new();
          let mut v25_2_write = v25_2.write_zipper();
          for v25_2_byte in v1_18_cursor.child_mask().iter() {
            v1_18_cursor.descend_to_existing_byte(v25_2_byte);
            {
            for v26_2_byte in v1_18_cursor.child_mask().iter() {
              v1_18_cursor.descend_to_existing_byte(v26_2_byte);
              {
              for v27_3_byte in v1_18_cursor.child_mask().iter() {
                v1_18_cursor.descend_to_existing_byte(v27_3_byte);
                {
                for v28_3_byte in v1_18_cursor.child_mask().iter() {
                  v1_18_cursor.descend_to_existing_byte(v28_3_byte);
                  {
                  let v29_3: Space = routine_4(c, &v1_18_cursor.path()[(v1_18_origin + 4)..(v1_18_origin + 8)], &v1_18_cursor, &(*s0));
                  join_wrapped_into(&mut v25_2_write,&((v29_3).read_zipper()),&[]);
                  }
                  v1_18_cursor.ascend(1);
                }
                }
                v1_18_cursor.ascend(1);
              }
              }
              v1_18_cursor.ascend(1);
            }
            }
            v1_18_cursor.ascend(1);
          }
          drop(v25_2_write);
          join_wrapped_into(&mut v1_18_write,&((v25_2).read_zipper()),&v1_18_cursor.path()[v1_18_origin..(v1_18_origin + 4)]);
          }
          v1_18_cursor.ascend(1);
        }
        }
        v1_18_cursor.ascend(1);
      }
      }
      v1_18_cursor.ascend(1);
    }
    }
    v1_18_cursor.ascend(1);
  }
  drop(v1_18_cursor);
  drop(v1_18_write);
  let v1_19: Space = unite(&(v1_17),&(v1_18));
  let v1_22: Space = subtract(&(v1_19),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_2))));
  let v1_25: Space = subtract(&(v1_22),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_7))));
  let v1_26: Space = wrap(&(v1_25),&(*CONSTANT_7));
  let v1_27: Space = unite(&(v1_6),&(v1_26));
  drop(v1_6);
  let v1_28: Space = unite(&(v1_27),&(*s0));
  let mut v1_30: Space = (v1_28).clone();
  loop {
    let v30_3: Space = unite(&(descend_cursor((v1_30).read_zipper(),&(*CONSTANT_3))),&(descend_cursor((v1_30).read_zipper(),&(*CONSTANT_4))));
    let v30_4: Space = wrap(&(v30_3),&(*CONSTANT_3));
    drop(v30_3);
    let mut v30_6 = Space::new();
    let mut v30_6_write = v30_6.write_zipper();
    let mut v30_6_cursor = descend_cursor(descend_cursor((v1_30).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_5));
    let v30_6_origin = v30_6_cursor.path().len();
    for v30_6_byte in v30_6_cursor.child_mask().iter() {
      v30_6_cursor.descend_to_existing_byte(v30_6_byte);
      {
      for v31_2_byte in v30_6_cursor.child_mask().iter() {
        v30_6_cursor.descend_to_existing_byte(v31_2_byte);
        {
        for v32_3_byte in v30_6_cursor.child_mask().iter() {
          v30_6_cursor.descend_to_existing_byte(v32_3_byte);
          {
          for v33_3_byte in v30_6_cursor.child_mask().iter() {
            v30_6_cursor.descend_to_existing_byte(v33_3_byte);
            {
            let mut v34_2 = Space::new();
            let mut v34_2_write = v34_2.write_zipper();
            for v34_2_byte in v30_6_cursor.child_mask().iter() {
              v30_6_cursor.descend_to_existing_byte(v34_2_byte);
              {
              for v35_2_byte in v30_6_cursor.child_mask().iter() {
                v30_6_cursor.descend_to_existing_byte(v35_2_byte);
                {
                for v36_3_byte in v30_6_cursor.child_mask().iter() {
                  v30_6_cursor.descend_to_existing_byte(v36_3_byte);
                  {
                  for v37_3_byte in v30_6_cursor.child_mask().iter() {
                    v30_6_cursor.descend_to_existing_byte(v37_3_byte);
                    {
                    let v38_3: Space = routine_2(c, &v30_6_cursor.path()[(v30_6_origin + 4)..(v30_6_origin + 8)], &v30_6_cursor, &((v1_30).read_zipper()));
                    join_wrapped_into(&mut v34_2_write,&((v38_3).read_zipper()),&[]);
                    }
                    v30_6_cursor.ascend(1);
                  }
                  }
                  v30_6_cursor.ascend(1);
                }
                }
                v30_6_cursor.ascend(1);
              }
              }
              v30_6_cursor.ascend(1);
            }
            drop(v34_2_write);
            join_wrapped_into(&mut v30_6_write,&((v34_2).read_zipper()),&v30_6_cursor.path()[v30_6_origin..(v30_6_origin + 4)]);
            }
            v30_6_cursor.ascend(1);
          }
          }
          v30_6_cursor.ascend(1);
        }
        }
        v30_6_cursor.ascend(1);
      }
      }
      v30_6_cursor.ascend(1);
    }
    drop(v30_6_cursor);
    drop(v30_6_write);
    let mut v30_8 = Space::new();
    let mut v30_8_write = v30_8.write_zipper();
    let mut v30_8_cursor = descend_cursor(descend_cursor((v1_30).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_6));
    let v30_8_origin = v30_8_cursor.path().len();
    for v30_8_byte in v30_8_cursor.child_mask().iter() {
      v30_8_cursor.descend_to_existing_byte(v30_8_byte);
      {
      for v39_2_byte in v30_8_cursor.child_mask().iter() {
        v30_8_cursor.descend_to_existing_byte(v39_2_byte);
        {
        for v40_3_byte in v30_8_cursor.child_mask().iter() {
          v30_8_cursor.descend_to_existing_byte(v40_3_byte);
          {
          for v41_3_byte in v30_8_cursor.child_mask().iter() {
            v30_8_cursor.descend_to_existing_byte(v41_3_byte);
            {
            v30_8_write.descend_to(&v30_8_cursor.path()[v30_8_origin..(v30_8_origin + 4)]);
            join_branches(&mut v30_8_write,&mut v30_8_cursor);
            v30_8_write.ascend((&v30_8_cursor.path()[v30_8_origin..(v30_8_origin + 4)]).len());
            }
            v30_8_cursor.ascend(1);
          }
          }
          v30_8_cursor.ascend(1);
        }
        }
        v30_8_cursor.ascend(1);
      }
      }
      v30_8_cursor.ascend(1);
    }
    drop(v30_8_cursor);
    drop(v30_8_write);
    let v30_9: Space = unite(&(v30_6),&(v30_8));
    drop(v30_8);
    let mut v30_11 = Space::new();
    let mut v30_11_write = v30_11.write_zipper();
    let mut v30_11_cursor = descend_cursor(descend_cursor((v1_30).read_zipper(),&(*CONSTANT_4)),&(*CONSTANT_5));
    let v30_11_origin = v30_11_cursor.path().len();
    for v30_11_byte in v30_11_cursor.child_mask().iter() {
      v30_11_cursor.descend_to_existing_byte(v30_11_byte);
      {
      for v43_2_byte in v30_11_cursor.child_mask().iter() {
        v30_11_cursor.descend_to_existing_byte(v43_2_byte);
        {
        for v44_3_byte in v30_11_cursor.child_mask().iter() {
          v30_11_cursor.descend_to_existing_byte(v44_3_byte);
          {
          for v45_3_byte in v30_11_cursor.child_mask().iter() {
            v30_11_cursor.descend_to_existing_byte(v45_3_byte);
            {
            let mut v46_2 = Space::new();
            let mut v46_2_write = v46_2.write_zipper();
            for v46_2_byte in v30_11_cursor.child_mask().iter() {
              v30_11_cursor.descend_to_existing_byte(v46_2_byte);
              {
              for v47_2_byte in v30_11_cursor.child_mask().iter() {
                v30_11_cursor.descend_to_existing_byte(v47_2_byte);
                {
                for v48_3_byte in v30_11_cursor.child_mask().iter() {
                  v30_11_cursor.descend_to_existing_byte(v48_3_byte);
                  {
                  for v49_3_byte in v30_11_cursor.child_mask().iter() {
                    v30_11_cursor.descend_to_existing_byte(v49_3_byte);
                    {
                    let v50_3: Space = routine_3(c, &v30_11_cursor.path()[(v30_11_origin + 4)..(v30_11_origin + 8)], &v30_11_cursor, &((v1_30).read_zipper()));
                    join_wrapped_into(&mut v46_2_write,&((v50_3).read_zipper()),&[]);
                    }
                    v30_11_cursor.ascend(1);
                  }
                  }
                  v30_11_cursor.ascend(1);
                }
                }
                v30_11_cursor.ascend(1);
              }
              }
              v30_11_cursor.ascend(1);
            }
            drop(v46_2_write);
            join_wrapped_into(&mut v30_11_write,&((v46_2).read_zipper()),&v30_11_cursor.path()[v30_11_origin..(v30_11_origin + 4)]);
            }
            v30_11_cursor.ascend(1);
          }
          }
          v30_11_cursor.ascend(1);
        }
        }
        v30_11_cursor.ascend(1);
      }
      }
      v30_11_cursor.ascend(1);
    }
    drop(v30_11_cursor);
    drop(v30_11_write);
    let v30_12: Space = unite(&(v30_9),&(v30_11));
    let mut v30_13 = Space::new();
    let mut v30_13_write = v30_13.write_zipper();
    let mut v30_13_cursor = descend_cursor(descend_cursor((v1_30).read_zipper(),&(*CONSTANT_4)),&(*CONSTANT_5));
    let v30_13_origin = v30_13_cursor.path().len();
    for v30_13_byte in v30_13_cursor.child_mask().iter() {
      v30_13_cursor.descend_to_existing_byte(v30_13_byte);
      {
      for v51_2_byte in v30_13_cursor.child_mask().iter() {
        v30_13_cursor.descend_to_existing_byte(v51_2_byte);
        {
        for v52_3_byte in v30_13_cursor.child_mask().iter() {
          v30_13_cursor.descend_to_existing_byte(v52_3_byte);
          {
          for v53_3_byte in v30_13_cursor.child_mask().iter() {
            v30_13_cursor.descend_to_existing_byte(v53_3_byte);
            {
            let mut v54_2 = Space::new();
            let mut v54_2_write = v54_2.write_zipper();
            for v54_2_byte in v30_13_cursor.child_mask().iter() {
              v30_13_cursor.descend_to_existing_byte(v54_2_byte);
              {
              for v55_2_byte in v30_13_cursor.child_mask().iter() {
                v30_13_cursor.descend_to_existing_byte(v55_2_byte);
                {
                for v56_3_byte in v30_13_cursor.child_mask().iter() {
                  v30_13_cursor.descend_to_existing_byte(v56_3_byte);
                  {
                  for v57_3_byte in v30_13_cursor.child_mask().iter() {
                    v30_13_cursor.descend_to_existing_byte(v57_3_byte);
                    {
                    let v58_3: Space = routine_4(c, &v30_13_cursor.path()[(v30_13_origin + 4)..(v30_13_origin + 8)], &v30_13_cursor, &((v1_30).read_zipper()));
                    join_wrapped_into(&mut v54_2_write,&((v58_3).read_zipper()),&[]);
                    }
                    v30_13_cursor.ascend(1);
                  }
                  }
                  v30_13_cursor.ascend(1);
                }
                }
                v30_13_cursor.ascend(1);
              }
              }
              v30_13_cursor.ascend(1);
            }
            drop(v54_2_write);
            join_wrapped_into(&mut v30_13_write,&((v54_2).read_zipper()),&v30_13_cursor.path()[v30_13_origin..(v30_13_origin + 4)]);
            }
            v30_13_cursor.ascend(1);
          }
          }
          v30_13_cursor.ascend(1);
        }
        }
        v30_13_cursor.ascend(1);
      }
      }
      v30_13_cursor.ascend(1);
    }
    drop(v30_13_cursor);
    drop(v30_13_write);
    let v30_14: Space = unite(&(v30_12),&(v30_13));
    let v30_16: Space = subtract(&(v30_14),&(descend_cursor((v1_30).read_zipper(),&(*CONSTANT_2))));
    let v30_18: Space = subtract(&(v30_16),&(descend_cursor((v1_30).read_zipper(),&(*CONSTANT_7))));
    let v30_19: Space = wrap(&(v30_18),&(*CONSTANT_7));
    let v30_20: Space = unite(&(v30_4),&(v30_19));
    drop(v30_4);
    let v30_21: Space = unite(&(v30_20),&(v1_30));
    if !v1_30.join_into((v30_21).clone()).is_element() { break; }
  }
  let v1_31: Space = unite(&(*s0),&(v1_30));
  (v1_31).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v59_9: Space = subtract(&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*CONSTANT_5)),&(*p0))),&(*CONSTANT_8));
  (v59_9).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v60_9: Space = subtract(&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3)),&(*CONSTANT_5)),&(*p0))),&(*CONSTANT_8));
  (v60_9).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v61_9: Space = subtract(&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*CONSTANT_5)),&(*p0))),&(*CONSTANT_8));
  (v61_9).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
