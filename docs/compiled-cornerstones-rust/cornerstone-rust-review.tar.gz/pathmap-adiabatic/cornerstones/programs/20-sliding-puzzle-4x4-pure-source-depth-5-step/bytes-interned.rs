#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 56 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,16]));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 2 0 0 0 5 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,17]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 56 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,18]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 56 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 3 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 3 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,19]));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 4 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,20]));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_13: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,21]));
static CONSTANT_14: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 56 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 6 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_15: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,22]));
static CONSTANT_16: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_17: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,23]));
static CONSTANT_18: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_19: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,24]));
static CONSTANT_20: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 5 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_21: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,25]));
static CONSTANT_22: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_23: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,26]));
static CONSTANT_24: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 56 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 11 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 11 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 11 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_25: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,27]));
static CONSTANT_26: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 13 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 12 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 12 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_27: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,28]));
static CONSTANT_28: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 13 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 14 0 0 0 15"));
static CONSTANT_29: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,29]));
static CONSTANT_30: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 14 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 14 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 14 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 13 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 14 0 0 0 15"));
static CONSTANT_31: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,4]));
static CONSTANT_32: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 56 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_33: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 1 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 5 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_34: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 56 0 0 0 1 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_35: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 1 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 3 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_36: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 5 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 5 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_37: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 5 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_38: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 6 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 7 0 0 0 9 0 0 0 10 0 0 0 6 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 5 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 5 0 0 0 1 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_39: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_40: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_41: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 12 0 0 0 10 0 0 0 11 0 0 0 13 0 0 0 9 0 0 0 14 0 0 0 15"));
static CONSTANT_42: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_43: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 11 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_44: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 13 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 12 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 13 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 12 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_45: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 13 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 13 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 12 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_46: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 14 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 14 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 13 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 10 0 0 0 14 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 13 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 12 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_47: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,5]));
static CONSTANT_48: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 56 0 0 0 2 0 0 0 3 0 0 0 1 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_49: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 56 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_50: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 0"));
static CONSTANT_51: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 16"));
static CONSTANT_52: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 17"));
static CONSTANT_53: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 18"));
static CONSTANT_54: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 19"));
static CONSTANT_55: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 20"));
static CONSTANT_56: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 21"));
static CONSTANT_57: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 22"));
static CONSTANT_58: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 23"));
static CONSTANT_59: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 24"));
static CONSTANT_60: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 25"));
static CONSTANT_61: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 26"));
static CONSTANT_62: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 27"));
static CONSTANT_63: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 28"));
static CONSTANT_64: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 29"));
static CONSTANT_65: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 34"));
static CONSTANT_66: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 12 0 0 0 30 0 0 0 0 0 0 0 19 12 0 0 0 30 0 0 0 19 0 0 0 0 12 0 0 0 31 0 0 0 0 0 0 0 16 12 0 0 0 31 0 0 0 16 0 0 0 0"));
static CONSTANT_67: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 12 0 0 0 30 0 0 0 16 0 0 0 20 12 0 0 0 30 0 0 0 20 0 0 0 16 12 0 0 0 31 0 0 0 16 0 0 0 17 12 0 0 0 31 0 0 0 17 0 0 0 16 12 0 0 0 32 0 0 0 0 0 0 0 16 12 0 0 0 32 0 0 0 16 0 0 0 0"));
static CONSTANT_68: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 12 0 0 0 30 0 0 0 17 0 0 0 21 12 0 0 0 30 0 0 0 21 0 0 0 17 12 0 0 0 31 0 0 0 17 0 0 0 18 12 0 0 0 31 0 0 0 18 0 0 0 17 12 0 0 0 32 0 0 0 16 0 0 0 17 12 0 0 0 32 0 0 0 17 0 0 0 16"));
static CONSTANT_69: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 12 0 0 0 30 0 0 0 18 0 0 0 22 12 0 0 0 30 0 0 0 22 0 0 0 18 12 0 0 0 32 0 0 0 17 0 0 0 18 12 0 0 0 32 0 0 0 18 0 0 0 17"));
static CONSTANT_70: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 12 0 0 0 30 0 0 0 19 0 0 0 23 12 0 0 0 30 0 0 0 23 0 0 0 19 12 0 0 0 31 0 0 0 19 0 0 0 20 12 0 0 0 31 0 0 0 20 0 0 0 19 12 0 0 0 33 0 0 0 0 0 0 0 19 12 0 0 0 33 0 0 0 19 0 0 0 0"));
static CONSTANT_71: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 12 0 0 0 30 0 0 0 20 0 0 0 24 12 0 0 0 30 0 0 0 24 0 0 0 20 12 0 0 0 31 0 0 0 20 0 0 0 21 12 0 0 0 31 0 0 0 21 0 0 0 20 12 0 0 0 32 0 0 0 19 0 0 0 20 12 0 0 0 32 0 0 0 20 0 0 0 19 12 0 0 0 33 0 0 0 16 0 0 0 20 12 0 0 0 33 0 0 0 20 0 0 0 16"));
static CONSTANT_72: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 12 0 0 0 30 0 0 0 21 0 0 0 25 12 0 0 0 30 0 0 0 25 0 0 0 21 12 0 0 0 31 0 0 0 21 0 0 0 22 12 0 0 0 31 0 0 0 22 0 0 0 21 12 0 0 0 32 0 0 0 20 0 0 0 21 12 0 0 0 32 0 0 0 21 0 0 0 20 12 0 0 0 33 0 0 0 17 0 0 0 21 12 0 0 0 33 0 0 0 21 0 0 0 17"));
static CONSTANT_73: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 12 0 0 0 30 0 0 0 22 0 0 0 26 12 0 0 0 30 0 0 0 26 0 0 0 22 12 0 0 0 32 0 0 0 21 0 0 0 22 12 0 0 0 32 0 0 0 22 0 0 0 21 12 0 0 0 33 0 0 0 18 0 0 0 22 12 0 0 0 33 0 0 0 22 0 0 0 18"));
static CONSTANT_74: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 12 0 0 0 30 0 0 0 23 0 0 0 27 12 0 0 0 30 0 0 0 27 0 0 0 23 12 0 0 0 31 0 0 0 23 0 0 0 24 12 0 0 0 31 0 0 0 24 0 0 0 23 12 0 0 0 33 0 0 0 19 0 0 0 23 12 0 0 0 33 0 0 0 23 0 0 0 19"));
static CONSTANT_75: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 12 0 0 0 30 0 0 0 24 0 0 0 28 12 0 0 0 30 0 0 0 28 0 0 0 24 12 0 0 0 31 0 0 0 24 0 0 0 25 12 0 0 0 31 0 0 0 25 0 0 0 24 12 0 0 0 32 0 0 0 23 0 0 0 24 12 0 0 0 32 0 0 0 24 0 0 0 23 12 0 0 0 33 0 0 0 20 0 0 0 24 12 0 0 0 33 0 0 0 24 0 0 0 20"));
static CONSTANT_76: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 12 0 0 0 30 0 0 0 25 0 0 0 29 12 0 0 0 30 0 0 0 29 0 0 0 25 12 0 0 0 31 0 0 0 25 0 0 0 26 12 0 0 0 31 0 0 0 26 0 0 0 25 12 0 0 0 32 0 0 0 24 0 0 0 25 12 0 0 0 32 0 0 0 25 0 0 0 24 12 0 0 0 33 0 0 0 21 0 0 0 25 12 0 0 0 33 0 0 0 25 0 0 0 21"));
static CONSTANT_77: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 12 0 0 0 30 0 0 0 26 0 0 0 34 12 0 0 0 30 0 0 0 34 0 0 0 26 12 0 0 0 32 0 0 0 25 0 0 0 26 12 0 0 0 32 0 0 0 26 0 0 0 25 12 0 0 0 33 0 0 0 22 0 0 0 26 12 0 0 0 33 0 0 0 26 0 0 0 22"));
static CONSTANT_78: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 12 0 0 0 31 0 0 0 27 0 0 0 28 12 0 0 0 31 0 0 0 28 0 0 0 27 12 0 0 0 33 0 0 0 23 0 0 0 27 12 0 0 0 33 0 0 0 27 0 0 0 23"));
static CONSTANT_79: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 12 0 0 0 31 0 0 0 28 0 0 0 29 12 0 0 0 31 0 0 0 29 0 0 0 28 12 0 0 0 32 0 0 0 27 0 0 0 28 12 0 0 0 32 0 0 0 28 0 0 0 27 12 0 0 0 33 0 0 0 24 0 0 0 28 12 0 0 0 33 0 0 0 28 0 0 0 24"));
static CONSTANT_80: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 12 0 0 0 31 0 0 0 29 0 0 0 34 12 0 0 0 31 0 0 0 34 0 0 0 29 12 0 0 0 32 0 0 0 28 0 0 0 29 12 0 0 0 32 0 0 0 29 0 0 0 28 12 0 0 0 33 0 0 0 25 0 0 0 29 12 0 0 0 33 0 0 0 29 0 0 0 25"));
static CONSTANT_81: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,34]));
static CONSTANT_82: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 12 0 0 0 32 0 0 0 29 0 0 0 34 12 0 0 0 32 0 0 0 34 0 0 0 29 12 0 0 0 33 0 0 0 26 0 0 0 34 12 0 0 0 33 0 0 0 34 0 0 0 26"));
static CONSTANT_83: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("16 8 0 0 0 0 0 0 0 0 8 0 0 0 16 0 0 0 16 8 0 0 0 17 0 0 0 17 8 0 0 0 18 0 0 0 18 8 0 0 0 19 0 0 0 19 8 0 0 0 20 0 0 0 20 8 0 0 0 21 0 0 0 21 8 0 0 0 22 0 0 0 22 8 0 0 0 23 0 0 0 23 8 0 0 0 24 0 0 0 24 8 0 0 0 25 0 0 0 25 8 0 0 0 26 0 0 0 26 8 0 0 0 27 0 0 0 27 8 0 0 0 28 0 0 0 28 8 0 0 0 29 0 0 0 29 8 0 0 0 34 0 0 0 34"));
static CONSTANT_84: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 0 0 0 0 35"));
static CONSTANT_85: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 16 0 0 0 35"));
static CONSTANT_86: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 17 0 0 0 35"));
static CONSTANT_87: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 18 0 0 0 35"));
static CONSTANT_88: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 19 0 0 0 35"));
static CONSTANT_89: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 20 0 0 0 35"));
static CONSTANT_90: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 21 0 0 0 35"));
static CONSTANT_91: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 22 0 0 0 35"));
static CONSTANT_92: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 23 0 0 0 35"));
static CONSTANT_93: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 24 0 0 0 35"));
static CONSTANT_94: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 25 0 0 0 35"));
static CONSTANT_95: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 26 0 0 0 35"));
static CONSTANT_96: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 27 0 0 0 35"));
static CONSTANT_97: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 28 0 0 0 35"));
static CONSTANT_98: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 29 0 0 0 35"));
static CONSTANT_99: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 34 0 0 0 35"));
#[inline(never)]
fn native_block_0(c: &mut Context,capture_0: &[u8],capture_1: &[u8],capture_2: &[u8],capture_3: &[u8],capture_4: &[u8],capture_5: &[u8],capture_6: &[u8],capture_7: &[u8],capture_8: &[u8],capture_9: &[u8],capture_10: &[u8],capture_11: &[u8],capture_12: &[u8],capture_13: &[u8],capture_14: &[u8],capture_15: &[u8]) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v64_18: Space = singleton(&(*capture_1));
  let v64_19: Space = intersect(&(*CONSTANT_50),&(v64_18));
  let mut v64_20 = Space::new();
  let mut v64_20_write = v64_20.write_zipper();
  let mut v64_20_cursor = (v64_19).read_zipper();
  let v64_20_origin = v64_20_cursor.path().len();
  for v64_20_byte in v64_20_cursor.child_mask().iter() {
    v64_20_cursor.descend_to_existing_byte(v64_20_byte);
    {
    for v65_2_byte in v64_20_cursor.child_mask().iter() {
      v64_20_cursor.descend_to_existing_byte(v65_2_byte);
      {
      for v66_3_byte in v64_20_cursor.child_mask().iter() {
        v64_20_cursor.descend_to_existing_byte(v66_3_byte);
        {
        for v67_3_byte in v64_20_cursor.child_mask().iter() {
          v64_20_cursor.descend_to_existing_byte(v67_3_byte);
          {
          let v68_3: Space = routine_9(c, &v64_20_cursor.path()[v64_20_origin..(v64_20_origin + 4)], &v64_20_cursor);
          join_wrapped_into(&mut v64_20_write,&((v68_3).read_zipper()),&[]);
          }
          v64_20_cursor.ascend(1);
        }
        }
        v64_20_cursor.ascend(1);
      }
      }
      v64_20_cursor.ascend(1);
    }
    }
    v64_20_cursor.ascend(1);
  }
  drop(v64_20_cursor);
  drop(v64_20_write);
  drop(v64_19);
  let v64_37: Space = if (&(v64_20)).is_empty() { Space::new() } else {
    let v69_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v69_22: Path = concat_path(&(v69_21),&(*capture_10));
    drop(v69_21);
    let v69_23: Path = concat_path(&(v69_22),&(*capture_11));
    drop(v69_22);
    let v69_24: Path = concat_path(&(v69_23),&(*capture_12));
    drop(v69_23);
    let v69_25: Path = concat_path(&(v69_24),&(*capture_13));
    drop(v69_24);
    let v69_26: Path = concat_path(&(v69_25),&(*capture_14));
    drop(v69_25);
    let v69_27: Path = concat_path(&(v69_26),&(*capture_15));
    drop(v69_26);
    let v69_28: Path = concat_path(&(v69_27),&(*capture_2));
    drop(v69_27);
    let v69_29: Path = concat_path(&(v69_28),&(*capture_3));
    drop(v69_28);
    let v69_30: Path = concat_path(&(v69_29),&(*capture_4));
    drop(v69_29);
    let v69_31: Path = concat_path(&(v69_30),&(*capture_5));
    drop(v69_30);
    let v69_32: Path = concat_path(&(v69_31),&(*capture_6));
    drop(v69_31);
    let v69_33: Path = concat_path(&(v69_32),&(*capture_7));
    drop(v69_32);
    let v69_34: Path = concat_path(&(v69_33),&(*capture_0));
    drop(v69_33);
    let v69_35: Space = singleton(&(v69_34));
    drop(v69_34);
    let mut v69_36 = Space::new();
    let mut v69_36_write = v69_36.write_zipper();
    let mut v69_36_cursor = (v69_35).read_zipper();
    let v69_36_origin = v69_36_cursor.path().len();
    for v69_36_byte in v69_36_cursor.child_mask().iter() {
      v69_36_cursor.descend_to_existing_byte(v69_36_byte);
      {
      for v70_2_byte in v69_36_cursor.child_mask().iter() {
        v69_36_cursor.descend_to_existing_byte(v70_2_byte);
        {
        for v71_3_byte in v69_36_cursor.child_mask().iter() {
          v69_36_cursor.descend_to_existing_byte(v71_3_byte);
          {
          for v72_3_byte in v69_36_cursor.child_mask().iter() {
            v69_36_cursor.descend_to_existing_byte(v72_3_byte);
            {
            let v73_3: Space = routine_10(c, &v69_36_cursor.path()[v69_36_origin..(v69_36_origin + 4)], &v69_36_cursor);
            join_wrapped_into(&mut v69_36_write,&((v73_3).read_zipper()),&[]);
            }
            v69_36_cursor.ascend(1);
          }
          }
          v69_36_cursor.ascend(1);
        }
        }
        v69_36_cursor.ascend(1);
      }
      }
      v69_36_cursor.ascend(1);
    }
    drop(v69_36_cursor);
    drop(v69_36_write);
    compose(&(v64_20),&(v69_36))
  };
  let v64_39: Space = intersect(&(*CONSTANT_51),&(v64_18));
  let mut v64_40 = Space::new();
  let mut v64_40_write = v64_40.write_zipper();
  let mut v64_40_cursor = (v64_39).read_zipper();
  let v64_40_origin = v64_40_cursor.path().len();
  for v64_40_byte in v64_40_cursor.child_mask().iter() {
    v64_40_cursor.descend_to_existing_byte(v64_40_byte);
    {
    for v74_2_byte in v64_40_cursor.child_mask().iter() {
      v64_40_cursor.descend_to_existing_byte(v74_2_byte);
      {
      for v75_3_byte in v64_40_cursor.child_mask().iter() {
        v64_40_cursor.descend_to_existing_byte(v75_3_byte);
        {
        for v76_3_byte in v64_40_cursor.child_mask().iter() {
          v64_40_cursor.descend_to_existing_byte(v76_3_byte);
          {
          let v77_3: Space = routine_11(c, &v64_40_cursor.path()[v64_40_origin..(v64_40_origin + 4)], &v64_40_cursor);
          join_wrapped_into(&mut v64_40_write,&((v77_3).read_zipper()),&[]);
          }
          v64_40_cursor.ascend(1);
        }
        }
        v64_40_cursor.ascend(1);
      }
      }
      v64_40_cursor.ascend(1);
    }
    }
    v64_40_cursor.ascend(1);
  }
  drop(v64_40_cursor);
  drop(v64_40_write);
  drop(v64_39);
  let v64_42: Space = if (&(v64_40)).is_empty() { Space::new() } else {
    let v78_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v78_22: Path = concat_path(&(v78_21),&(*capture_10));
    drop(v78_21);
    let v78_23: Path = concat_path(&(v78_22),&(*capture_11));
    drop(v78_22);
    let v78_24: Path = concat_path(&(v78_23),&(*capture_12));
    drop(v78_23);
    let v78_25: Path = concat_path(&(v78_24),&(*capture_13));
    drop(v78_24);
    let v78_26: Path = concat_path(&(v78_25),&(*capture_14));
    drop(v78_25);
    let v78_27: Path = concat_path(&(v78_26),&(*capture_15));
    drop(v78_26);
    let v78_28: Path = concat_path(&(v78_27),&(*capture_2));
    drop(v78_27);
    let v78_29: Path = concat_path(&(v78_28),&(*capture_3));
    drop(v78_28);
    let v78_30: Path = concat_path(&(v78_29),&(*capture_4));
    drop(v78_29);
    let v78_31: Path = concat_path(&(v78_30),&(*capture_5));
    drop(v78_30);
    let v78_32: Path = concat_path(&(v78_31),&(*capture_6));
    drop(v78_31);
    let v78_33: Path = concat_path(&(v78_32),&(*capture_7));
    drop(v78_32);
    let v78_34: Path = concat_path(&(v78_33),&(*capture_0));
    drop(v78_33);
    let v78_35: Space = singleton(&(v78_34));
    drop(v78_34);
    let mut v78_41 = Space::new();
    let mut v78_41_write = v78_41.write_zipper();
    let mut v78_41_cursor = (v78_35).read_zipper();
    let v78_41_origin = v78_41_cursor.path().len();
    for v78_41_byte in v78_41_cursor.child_mask().iter() {
      v78_41_cursor.descend_to_existing_byte(v78_41_byte);
      {
      for v79_2_byte in v78_41_cursor.child_mask().iter() {
        v78_41_cursor.descend_to_existing_byte(v79_2_byte);
        {
        for v80_3_byte in v78_41_cursor.child_mask().iter() {
          v78_41_cursor.descend_to_existing_byte(v80_3_byte);
          {
          for v81_3_byte in v78_41_cursor.child_mask().iter() {
            v78_41_cursor.descend_to_existing_byte(v81_3_byte);
            {
            let v82_3: Space = routine_12(c, &v78_41_cursor.path()[v78_41_origin..(v78_41_origin + 4)], &v78_41_cursor);
            join_wrapped_into(&mut v78_41_write,&((v82_3).read_zipper()),&[]);
            }
            v78_41_cursor.ascend(1);
          }
          }
          v78_41_cursor.ascend(1);
        }
        }
        v78_41_cursor.ascend(1);
      }
      }
      v78_41_cursor.ascend(1);
    }
    drop(v78_41_cursor);
    drop(v78_41_write);
    compose(&(v64_40),&(v78_41))
  };
  let v64_43: Space = unite(&(v64_37),&(v64_42));
  let v64_45: Space = intersect(&(*CONSTANT_52),&(v64_18));
  let mut v64_46 = Space::new();
  let mut v64_46_write = v64_46.write_zipper();
  let mut v64_46_cursor = (v64_45).read_zipper();
  let v64_46_origin = v64_46_cursor.path().len();
  for v64_46_byte in v64_46_cursor.child_mask().iter() {
    v64_46_cursor.descend_to_existing_byte(v64_46_byte);
    {
    for v83_2_byte in v64_46_cursor.child_mask().iter() {
      v64_46_cursor.descend_to_existing_byte(v83_2_byte);
      {
      for v84_3_byte in v64_46_cursor.child_mask().iter() {
        v64_46_cursor.descend_to_existing_byte(v84_3_byte);
        {
        for v85_3_byte in v64_46_cursor.child_mask().iter() {
          v64_46_cursor.descend_to_existing_byte(v85_3_byte);
          {
          let v86_3: Space = routine_13(c, &v64_46_cursor.path()[v64_46_origin..(v64_46_origin + 4)], &v64_46_cursor);
          join_wrapped_into(&mut v64_46_write,&((v86_3).read_zipper()),&[]);
          }
          v64_46_cursor.ascend(1);
        }
        }
        v64_46_cursor.ascend(1);
      }
      }
      v64_46_cursor.ascend(1);
    }
    }
    v64_46_cursor.ascend(1);
  }
  drop(v64_46_cursor);
  drop(v64_46_write);
  drop(v64_45);
  let v64_48: Space = if (&(v64_46)).is_empty() { Space::new() } else {
    let v87_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v87_22: Path = concat_path(&(v87_21),&(*capture_10));
    drop(v87_21);
    let v87_23: Path = concat_path(&(v87_22),&(*capture_11));
    drop(v87_22);
    let v87_24: Path = concat_path(&(v87_23),&(*capture_12));
    drop(v87_23);
    let v87_25: Path = concat_path(&(v87_24),&(*capture_13));
    drop(v87_24);
    let v87_26: Path = concat_path(&(v87_25),&(*capture_14));
    drop(v87_25);
    let v87_27: Path = concat_path(&(v87_26),&(*capture_15));
    drop(v87_26);
    let v87_28: Path = concat_path(&(v87_27),&(*capture_2));
    drop(v87_27);
    let v87_29: Path = concat_path(&(v87_28),&(*capture_3));
    drop(v87_28);
    let v87_30: Path = concat_path(&(v87_29),&(*capture_4));
    drop(v87_29);
    let v87_31: Path = concat_path(&(v87_30),&(*capture_5));
    drop(v87_30);
    let v87_32: Path = concat_path(&(v87_31),&(*capture_6));
    drop(v87_31);
    let v87_33: Path = concat_path(&(v87_32),&(*capture_7));
    drop(v87_32);
    let v87_34: Path = concat_path(&(v87_33),&(*capture_0));
    drop(v87_33);
    let v87_35: Space = singleton(&(v87_34));
    drop(v87_34);
    let mut v87_47 = Space::new();
    let mut v87_47_write = v87_47.write_zipper();
    let mut v87_47_cursor = (v87_35).read_zipper();
    let v87_47_origin = v87_47_cursor.path().len();
    for v87_47_byte in v87_47_cursor.child_mask().iter() {
      v87_47_cursor.descend_to_existing_byte(v87_47_byte);
      {
      for v88_2_byte in v87_47_cursor.child_mask().iter() {
        v87_47_cursor.descend_to_existing_byte(v88_2_byte);
        {
        for v89_3_byte in v87_47_cursor.child_mask().iter() {
          v87_47_cursor.descend_to_existing_byte(v89_3_byte);
          {
          for v90_3_byte in v87_47_cursor.child_mask().iter() {
            v87_47_cursor.descend_to_existing_byte(v90_3_byte);
            {
            let v91_3: Space = routine_14(c, &v87_47_cursor.path()[v87_47_origin..(v87_47_origin + 4)], &v87_47_cursor);
            join_wrapped_into(&mut v87_47_write,&((v91_3).read_zipper()),&[]);
            }
            v87_47_cursor.ascend(1);
          }
          }
          v87_47_cursor.ascend(1);
        }
        }
        v87_47_cursor.ascend(1);
      }
      }
      v87_47_cursor.ascend(1);
    }
    drop(v87_47_cursor);
    drop(v87_47_write);
    compose(&(v64_46),&(v87_47))
  };
  let v64_49: Space = unite(&(v64_43),&(v64_48));
  let v64_51: Space = intersect(&(*CONSTANT_53),&(v64_18));
  let mut v64_52 = Space::new();
  let mut v64_52_write = v64_52.write_zipper();
  let mut v64_52_cursor = (v64_51).read_zipper();
  let v64_52_origin = v64_52_cursor.path().len();
  for v64_52_byte in v64_52_cursor.child_mask().iter() {
    v64_52_cursor.descend_to_existing_byte(v64_52_byte);
    {
    for v92_2_byte in v64_52_cursor.child_mask().iter() {
      v64_52_cursor.descend_to_existing_byte(v92_2_byte);
      {
      for v93_3_byte in v64_52_cursor.child_mask().iter() {
        v64_52_cursor.descend_to_existing_byte(v93_3_byte);
        {
        for v94_3_byte in v64_52_cursor.child_mask().iter() {
          v64_52_cursor.descend_to_existing_byte(v94_3_byte);
          {
          let v95_3: Space = routine_15(c, &v64_52_cursor.path()[v64_52_origin..(v64_52_origin + 4)], &v64_52_cursor);
          join_wrapped_into(&mut v64_52_write,&((v95_3).read_zipper()),&[]);
          }
          v64_52_cursor.ascend(1);
        }
        }
        v64_52_cursor.ascend(1);
      }
      }
      v64_52_cursor.ascend(1);
    }
    }
    v64_52_cursor.ascend(1);
  }
  drop(v64_52_cursor);
  drop(v64_52_write);
  drop(v64_51);
  let v64_54: Space = if (&(v64_52)).is_empty() { Space::new() } else {
    let v96_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v96_22: Path = concat_path(&(v96_21),&(*capture_10));
    drop(v96_21);
    let v96_23: Path = concat_path(&(v96_22),&(*capture_11));
    drop(v96_22);
    let v96_24: Path = concat_path(&(v96_23),&(*capture_12));
    drop(v96_23);
    let v96_25: Path = concat_path(&(v96_24),&(*capture_13));
    drop(v96_24);
    let v96_26: Path = concat_path(&(v96_25),&(*capture_14));
    drop(v96_25);
    let v96_27: Path = concat_path(&(v96_26),&(*capture_15));
    drop(v96_26);
    let v96_28: Path = concat_path(&(v96_27),&(*capture_2));
    drop(v96_27);
    let v96_29: Path = concat_path(&(v96_28),&(*capture_3));
    drop(v96_28);
    let v96_30: Path = concat_path(&(v96_29),&(*capture_4));
    drop(v96_29);
    let v96_31: Path = concat_path(&(v96_30),&(*capture_5));
    drop(v96_30);
    let v96_32: Path = concat_path(&(v96_31),&(*capture_6));
    drop(v96_31);
    let v96_33: Path = concat_path(&(v96_32),&(*capture_7));
    drop(v96_32);
    let v96_34: Path = concat_path(&(v96_33),&(*capture_0));
    drop(v96_33);
    let v96_35: Space = singleton(&(v96_34));
    drop(v96_34);
    let mut v96_53 = Space::new();
    let mut v96_53_write = v96_53.write_zipper();
    let mut v96_53_cursor = (v96_35).read_zipper();
    let v96_53_origin = v96_53_cursor.path().len();
    for v96_53_byte in v96_53_cursor.child_mask().iter() {
      v96_53_cursor.descend_to_existing_byte(v96_53_byte);
      {
      for v97_2_byte in v96_53_cursor.child_mask().iter() {
        v96_53_cursor.descend_to_existing_byte(v97_2_byte);
        {
        for v98_3_byte in v96_53_cursor.child_mask().iter() {
          v96_53_cursor.descend_to_existing_byte(v98_3_byte);
          {
          for v99_3_byte in v96_53_cursor.child_mask().iter() {
            v96_53_cursor.descend_to_existing_byte(v99_3_byte);
            {
            let v100_3: Space = routine_16(c, &v96_53_cursor.path()[v96_53_origin..(v96_53_origin + 4)], &v96_53_cursor);
            join_wrapped_into(&mut v96_53_write,&((v100_3).read_zipper()),&[]);
            }
            v96_53_cursor.ascend(1);
          }
          }
          v96_53_cursor.ascend(1);
        }
        }
        v96_53_cursor.ascend(1);
      }
      }
      v96_53_cursor.ascend(1);
    }
    drop(v96_53_cursor);
    drop(v96_53_write);
    compose(&(v64_52),&(v96_53))
  };
  let v64_55: Space = unite(&(v64_49),&(v64_54));
  let v64_57: Space = intersect(&(*CONSTANT_54),&(v64_18));
  let mut v64_58 = Space::new();
  let mut v64_58_write = v64_58.write_zipper();
  let mut v64_58_cursor = (v64_57).read_zipper();
  let v64_58_origin = v64_58_cursor.path().len();
  for v64_58_byte in v64_58_cursor.child_mask().iter() {
    v64_58_cursor.descend_to_existing_byte(v64_58_byte);
    {
    for v101_2_byte in v64_58_cursor.child_mask().iter() {
      v64_58_cursor.descend_to_existing_byte(v101_2_byte);
      {
      for v102_3_byte in v64_58_cursor.child_mask().iter() {
        v64_58_cursor.descend_to_existing_byte(v102_3_byte);
        {
        for v103_3_byte in v64_58_cursor.child_mask().iter() {
          v64_58_cursor.descend_to_existing_byte(v103_3_byte);
          {
          let v104_3: Space = routine_17(c, &v64_58_cursor.path()[v64_58_origin..(v64_58_origin + 4)], &v64_58_cursor);
          join_wrapped_into(&mut v64_58_write,&((v104_3).read_zipper()),&[]);
          }
          v64_58_cursor.ascend(1);
        }
        }
        v64_58_cursor.ascend(1);
      }
      }
      v64_58_cursor.ascend(1);
    }
    }
    v64_58_cursor.ascend(1);
  }
  drop(v64_58_cursor);
  drop(v64_58_write);
  drop(v64_57);
  let v64_60: Space = if (&(v64_58)).is_empty() { Space::new() } else {
    let v105_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v105_22: Path = concat_path(&(v105_21),&(*capture_10));
    drop(v105_21);
    let v105_23: Path = concat_path(&(v105_22),&(*capture_11));
    drop(v105_22);
    let v105_24: Path = concat_path(&(v105_23),&(*capture_12));
    drop(v105_23);
    let v105_25: Path = concat_path(&(v105_24),&(*capture_13));
    drop(v105_24);
    let v105_26: Path = concat_path(&(v105_25),&(*capture_14));
    drop(v105_25);
    let v105_27: Path = concat_path(&(v105_26),&(*capture_15));
    drop(v105_26);
    let v105_28: Path = concat_path(&(v105_27),&(*capture_2));
    drop(v105_27);
    let v105_29: Path = concat_path(&(v105_28),&(*capture_3));
    drop(v105_28);
    let v105_30: Path = concat_path(&(v105_29),&(*capture_4));
    drop(v105_29);
    let v105_31: Path = concat_path(&(v105_30),&(*capture_5));
    drop(v105_30);
    let v105_32: Path = concat_path(&(v105_31),&(*capture_6));
    drop(v105_31);
    let v105_33: Path = concat_path(&(v105_32),&(*capture_7));
    drop(v105_32);
    let v105_34: Path = concat_path(&(v105_33),&(*capture_0));
    drop(v105_33);
    let v105_35: Space = singleton(&(v105_34));
    drop(v105_34);
    let mut v105_59 = Space::new();
    let mut v105_59_write = v105_59.write_zipper();
    let mut v105_59_cursor = (v105_35).read_zipper();
    let v105_59_origin = v105_59_cursor.path().len();
    for v105_59_byte in v105_59_cursor.child_mask().iter() {
      v105_59_cursor.descend_to_existing_byte(v105_59_byte);
      {
      for v106_2_byte in v105_59_cursor.child_mask().iter() {
        v105_59_cursor.descend_to_existing_byte(v106_2_byte);
        {
        for v107_3_byte in v105_59_cursor.child_mask().iter() {
          v105_59_cursor.descend_to_existing_byte(v107_3_byte);
          {
          for v108_3_byte in v105_59_cursor.child_mask().iter() {
            v105_59_cursor.descend_to_existing_byte(v108_3_byte);
            {
            let v109_3: Space = routine_18(c, &v105_59_cursor.path()[v105_59_origin..(v105_59_origin + 4)], &v105_59_cursor);
            join_wrapped_into(&mut v105_59_write,&((v109_3).read_zipper()),&[]);
            }
            v105_59_cursor.ascend(1);
          }
          }
          v105_59_cursor.ascend(1);
        }
        }
        v105_59_cursor.ascend(1);
      }
      }
      v105_59_cursor.ascend(1);
    }
    drop(v105_59_cursor);
    drop(v105_59_write);
    compose(&(v64_58),&(v105_59))
  };
  let v64_61: Space = unite(&(v64_55),&(v64_60));
  let v64_63: Space = intersect(&(*CONSTANT_55),&(v64_18));
  let mut v64_64 = Space::new();
  let mut v64_64_write = v64_64.write_zipper();
  let mut v64_64_cursor = (v64_63).read_zipper();
  let v64_64_origin = v64_64_cursor.path().len();
  for v64_64_byte in v64_64_cursor.child_mask().iter() {
    v64_64_cursor.descend_to_existing_byte(v64_64_byte);
    {
    for v110_2_byte in v64_64_cursor.child_mask().iter() {
      v64_64_cursor.descend_to_existing_byte(v110_2_byte);
      {
      for v111_3_byte in v64_64_cursor.child_mask().iter() {
        v64_64_cursor.descend_to_existing_byte(v111_3_byte);
        {
        for v112_3_byte in v64_64_cursor.child_mask().iter() {
          v64_64_cursor.descend_to_existing_byte(v112_3_byte);
          {
          let v113_3: Space = routine_19(c, &v64_64_cursor.path()[v64_64_origin..(v64_64_origin + 4)], &v64_64_cursor);
          join_wrapped_into(&mut v64_64_write,&((v113_3).read_zipper()),&[]);
          }
          v64_64_cursor.ascend(1);
        }
        }
        v64_64_cursor.ascend(1);
      }
      }
      v64_64_cursor.ascend(1);
    }
    }
    v64_64_cursor.ascend(1);
  }
  drop(v64_64_cursor);
  drop(v64_64_write);
  drop(v64_63);
  let v64_66: Space = if (&(v64_64)).is_empty() { Space::new() } else {
    let v114_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v114_22: Path = concat_path(&(v114_21),&(*capture_10));
    drop(v114_21);
    let v114_23: Path = concat_path(&(v114_22),&(*capture_11));
    drop(v114_22);
    let v114_24: Path = concat_path(&(v114_23),&(*capture_12));
    drop(v114_23);
    let v114_25: Path = concat_path(&(v114_24),&(*capture_13));
    drop(v114_24);
    let v114_26: Path = concat_path(&(v114_25),&(*capture_14));
    drop(v114_25);
    let v114_27: Path = concat_path(&(v114_26),&(*capture_15));
    drop(v114_26);
    let v114_28: Path = concat_path(&(v114_27),&(*capture_2));
    drop(v114_27);
    let v114_29: Path = concat_path(&(v114_28),&(*capture_3));
    drop(v114_28);
    let v114_30: Path = concat_path(&(v114_29),&(*capture_4));
    drop(v114_29);
    let v114_31: Path = concat_path(&(v114_30),&(*capture_5));
    drop(v114_30);
    let v114_32: Path = concat_path(&(v114_31),&(*capture_6));
    drop(v114_31);
    let v114_33: Path = concat_path(&(v114_32),&(*capture_7));
    drop(v114_32);
    let v114_34: Path = concat_path(&(v114_33),&(*capture_0));
    drop(v114_33);
    let v114_35: Space = singleton(&(v114_34));
    drop(v114_34);
    let mut v114_65 = Space::new();
    let mut v114_65_write = v114_65.write_zipper();
    let mut v114_65_cursor = (v114_35).read_zipper();
    let v114_65_origin = v114_65_cursor.path().len();
    for v114_65_byte in v114_65_cursor.child_mask().iter() {
      v114_65_cursor.descend_to_existing_byte(v114_65_byte);
      {
      for v115_2_byte in v114_65_cursor.child_mask().iter() {
        v114_65_cursor.descend_to_existing_byte(v115_2_byte);
        {
        for v116_3_byte in v114_65_cursor.child_mask().iter() {
          v114_65_cursor.descend_to_existing_byte(v116_3_byte);
          {
          for v117_3_byte in v114_65_cursor.child_mask().iter() {
            v114_65_cursor.descend_to_existing_byte(v117_3_byte);
            {
            let v118_3: Space = routine_20(c, &v114_65_cursor.path()[v114_65_origin..(v114_65_origin + 4)], &v114_65_cursor);
            join_wrapped_into(&mut v114_65_write,&((v118_3).read_zipper()),&[]);
            }
            v114_65_cursor.ascend(1);
          }
          }
          v114_65_cursor.ascend(1);
        }
        }
        v114_65_cursor.ascend(1);
      }
      }
      v114_65_cursor.ascend(1);
    }
    drop(v114_65_cursor);
    drop(v114_65_write);
    compose(&(v64_64),&(v114_65))
  };
  let v64_67: Space = unite(&(v64_61),&(v64_66));
  let v64_69: Space = intersect(&(*CONSTANT_56),&(v64_18));
  let mut v64_70 = Space::new();
  let mut v64_70_write = v64_70.write_zipper();
  let mut v64_70_cursor = (v64_69).read_zipper();
  let v64_70_origin = v64_70_cursor.path().len();
  for v64_70_byte in v64_70_cursor.child_mask().iter() {
    v64_70_cursor.descend_to_existing_byte(v64_70_byte);
    {
    for v119_2_byte in v64_70_cursor.child_mask().iter() {
      v64_70_cursor.descend_to_existing_byte(v119_2_byte);
      {
      for v120_3_byte in v64_70_cursor.child_mask().iter() {
        v64_70_cursor.descend_to_existing_byte(v120_3_byte);
        {
        for v121_3_byte in v64_70_cursor.child_mask().iter() {
          v64_70_cursor.descend_to_existing_byte(v121_3_byte);
          {
          let v122_3: Space = routine_21(c, &v64_70_cursor.path()[v64_70_origin..(v64_70_origin + 4)], &v64_70_cursor);
          join_wrapped_into(&mut v64_70_write,&((v122_3).read_zipper()),&[]);
          }
          v64_70_cursor.ascend(1);
        }
        }
        v64_70_cursor.ascend(1);
      }
      }
      v64_70_cursor.ascend(1);
    }
    }
    v64_70_cursor.ascend(1);
  }
  drop(v64_70_cursor);
  drop(v64_70_write);
  drop(v64_69);
  let v64_72: Space = if (&(v64_70)).is_empty() { Space::new() } else {
    let v123_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v123_22: Path = concat_path(&(v123_21),&(*capture_10));
    drop(v123_21);
    let v123_23: Path = concat_path(&(v123_22),&(*capture_11));
    drop(v123_22);
    let v123_24: Path = concat_path(&(v123_23),&(*capture_12));
    drop(v123_23);
    let v123_25: Path = concat_path(&(v123_24),&(*capture_13));
    drop(v123_24);
    let v123_26: Path = concat_path(&(v123_25),&(*capture_14));
    drop(v123_25);
    let v123_27: Path = concat_path(&(v123_26),&(*capture_15));
    drop(v123_26);
    let v123_28: Path = concat_path(&(v123_27),&(*capture_2));
    drop(v123_27);
    let v123_29: Path = concat_path(&(v123_28),&(*capture_3));
    drop(v123_28);
    let v123_30: Path = concat_path(&(v123_29),&(*capture_4));
    drop(v123_29);
    let v123_31: Path = concat_path(&(v123_30),&(*capture_5));
    drop(v123_30);
    let v123_32: Path = concat_path(&(v123_31),&(*capture_6));
    drop(v123_31);
    let v123_33: Path = concat_path(&(v123_32),&(*capture_7));
    drop(v123_32);
    let v123_34: Path = concat_path(&(v123_33),&(*capture_0));
    drop(v123_33);
    let v123_35: Space = singleton(&(v123_34));
    drop(v123_34);
    let mut v123_71 = Space::new();
    let mut v123_71_write = v123_71.write_zipper();
    let mut v123_71_cursor = (v123_35).read_zipper();
    let v123_71_origin = v123_71_cursor.path().len();
    for v123_71_byte in v123_71_cursor.child_mask().iter() {
      v123_71_cursor.descend_to_existing_byte(v123_71_byte);
      {
      for v124_2_byte in v123_71_cursor.child_mask().iter() {
        v123_71_cursor.descend_to_existing_byte(v124_2_byte);
        {
        for v125_3_byte in v123_71_cursor.child_mask().iter() {
          v123_71_cursor.descend_to_existing_byte(v125_3_byte);
          {
          for v126_3_byte in v123_71_cursor.child_mask().iter() {
            v123_71_cursor.descend_to_existing_byte(v126_3_byte);
            {
            let v127_3: Space = routine_22(c, &v123_71_cursor.path()[v123_71_origin..(v123_71_origin + 4)], &v123_71_cursor);
            join_wrapped_into(&mut v123_71_write,&((v127_3).read_zipper()),&[]);
            }
            v123_71_cursor.ascend(1);
          }
          }
          v123_71_cursor.ascend(1);
        }
        }
        v123_71_cursor.ascend(1);
      }
      }
      v123_71_cursor.ascend(1);
    }
    drop(v123_71_cursor);
    drop(v123_71_write);
    compose(&(v64_70),&(v123_71))
  };
  let v64_73: Space = unite(&(v64_67),&(v64_72));
  let v64_75: Space = intersect(&(*CONSTANT_57),&(v64_18));
  let mut v64_76 = Space::new();
  let mut v64_76_write = v64_76.write_zipper();
  let mut v64_76_cursor = (v64_75).read_zipper();
  let v64_76_origin = v64_76_cursor.path().len();
  for v64_76_byte in v64_76_cursor.child_mask().iter() {
    v64_76_cursor.descend_to_existing_byte(v64_76_byte);
    {
    for v128_2_byte in v64_76_cursor.child_mask().iter() {
      v64_76_cursor.descend_to_existing_byte(v128_2_byte);
      {
      for v129_3_byte in v64_76_cursor.child_mask().iter() {
        v64_76_cursor.descend_to_existing_byte(v129_3_byte);
        {
        for v130_3_byte in v64_76_cursor.child_mask().iter() {
          v64_76_cursor.descend_to_existing_byte(v130_3_byte);
          {
          let v131_3: Space = routine_23(c, &v64_76_cursor.path()[v64_76_origin..(v64_76_origin + 4)], &v64_76_cursor);
          join_wrapped_into(&mut v64_76_write,&((v131_3).read_zipper()),&[]);
          }
          v64_76_cursor.ascend(1);
        }
        }
        v64_76_cursor.ascend(1);
      }
      }
      v64_76_cursor.ascend(1);
    }
    }
    v64_76_cursor.ascend(1);
  }
  drop(v64_76_cursor);
  drop(v64_76_write);
  drop(v64_75);
  let v64_78: Space = if (&(v64_76)).is_empty() { Space::new() } else {
    let v132_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v132_22: Path = concat_path(&(v132_21),&(*capture_10));
    drop(v132_21);
    let v132_23: Path = concat_path(&(v132_22),&(*capture_11));
    drop(v132_22);
    let v132_24: Path = concat_path(&(v132_23),&(*capture_12));
    drop(v132_23);
    let v132_25: Path = concat_path(&(v132_24),&(*capture_13));
    drop(v132_24);
    let v132_26: Path = concat_path(&(v132_25),&(*capture_14));
    drop(v132_25);
    let v132_27: Path = concat_path(&(v132_26),&(*capture_15));
    drop(v132_26);
    let v132_28: Path = concat_path(&(v132_27),&(*capture_2));
    drop(v132_27);
    let v132_29: Path = concat_path(&(v132_28),&(*capture_3));
    drop(v132_28);
    let v132_30: Path = concat_path(&(v132_29),&(*capture_4));
    drop(v132_29);
    let v132_31: Path = concat_path(&(v132_30),&(*capture_5));
    drop(v132_30);
    let v132_32: Path = concat_path(&(v132_31),&(*capture_6));
    drop(v132_31);
    let v132_33: Path = concat_path(&(v132_32),&(*capture_7));
    drop(v132_32);
    let v132_34: Path = concat_path(&(v132_33),&(*capture_0));
    drop(v132_33);
    let v132_35: Space = singleton(&(v132_34));
    drop(v132_34);
    let mut v132_77 = Space::new();
    let mut v132_77_write = v132_77.write_zipper();
    let mut v132_77_cursor = (v132_35).read_zipper();
    let v132_77_origin = v132_77_cursor.path().len();
    for v132_77_byte in v132_77_cursor.child_mask().iter() {
      v132_77_cursor.descend_to_existing_byte(v132_77_byte);
      {
      for v133_2_byte in v132_77_cursor.child_mask().iter() {
        v132_77_cursor.descend_to_existing_byte(v133_2_byte);
        {
        for v134_3_byte in v132_77_cursor.child_mask().iter() {
          v132_77_cursor.descend_to_existing_byte(v134_3_byte);
          {
          for v135_3_byte in v132_77_cursor.child_mask().iter() {
            v132_77_cursor.descend_to_existing_byte(v135_3_byte);
            {
            let v136_3: Space = routine_24(c, &v132_77_cursor.path()[v132_77_origin..(v132_77_origin + 4)], &v132_77_cursor);
            join_wrapped_into(&mut v132_77_write,&((v136_3).read_zipper()),&[]);
            }
            v132_77_cursor.ascend(1);
          }
          }
          v132_77_cursor.ascend(1);
        }
        }
        v132_77_cursor.ascend(1);
      }
      }
      v132_77_cursor.ascend(1);
    }
    drop(v132_77_cursor);
    drop(v132_77_write);
    compose(&(v64_76),&(v132_77))
  };
  let v64_79: Space = unite(&(v64_73),&(v64_78));
  let v64_81: Space = intersect(&(*CONSTANT_58),&(v64_18));
  let mut v64_82 = Space::new();
  let mut v64_82_write = v64_82.write_zipper();
  let mut v64_82_cursor = (v64_81).read_zipper();
  let v64_82_origin = v64_82_cursor.path().len();
  for v64_82_byte in v64_82_cursor.child_mask().iter() {
    v64_82_cursor.descend_to_existing_byte(v64_82_byte);
    {
    for v137_2_byte in v64_82_cursor.child_mask().iter() {
      v64_82_cursor.descend_to_existing_byte(v137_2_byte);
      {
      for v138_3_byte in v64_82_cursor.child_mask().iter() {
        v64_82_cursor.descend_to_existing_byte(v138_3_byte);
        {
        for v139_3_byte in v64_82_cursor.child_mask().iter() {
          v64_82_cursor.descend_to_existing_byte(v139_3_byte);
          {
          let v140_3: Space = routine_25(c, &v64_82_cursor.path()[v64_82_origin..(v64_82_origin + 4)], &v64_82_cursor);
          join_wrapped_into(&mut v64_82_write,&((v140_3).read_zipper()),&[]);
          }
          v64_82_cursor.ascend(1);
        }
        }
        v64_82_cursor.ascend(1);
      }
      }
      v64_82_cursor.ascend(1);
    }
    }
    v64_82_cursor.ascend(1);
  }
  drop(v64_82_cursor);
  drop(v64_82_write);
  drop(v64_81);
  let v64_84: Space = if (&(v64_82)).is_empty() { Space::new() } else {
    let v141_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v141_22: Path = concat_path(&(v141_21),&(*capture_10));
    drop(v141_21);
    let v141_23: Path = concat_path(&(v141_22),&(*capture_11));
    drop(v141_22);
    let v141_24: Path = concat_path(&(v141_23),&(*capture_12));
    drop(v141_23);
    let v141_25: Path = concat_path(&(v141_24),&(*capture_13));
    drop(v141_24);
    let v141_26: Path = concat_path(&(v141_25),&(*capture_14));
    drop(v141_25);
    let v141_27: Path = concat_path(&(v141_26),&(*capture_15));
    drop(v141_26);
    let v141_28: Path = concat_path(&(v141_27),&(*capture_2));
    drop(v141_27);
    let v141_29: Path = concat_path(&(v141_28),&(*capture_3));
    drop(v141_28);
    let v141_30: Path = concat_path(&(v141_29),&(*capture_4));
    drop(v141_29);
    let v141_31: Path = concat_path(&(v141_30),&(*capture_5));
    drop(v141_30);
    let v141_32: Path = concat_path(&(v141_31),&(*capture_6));
    drop(v141_31);
    let v141_33: Path = concat_path(&(v141_32),&(*capture_7));
    drop(v141_32);
    let v141_34: Path = concat_path(&(v141_33),&(*capture_0));
    drop(v141_33);
    let v141_35: Space = singleton(&(v141_34));
    drop(v141_34);
    let mut v141_83 = Space::new();
    let mut v141_83_write = v141_83.write_zipper();
    let mut v141_83_cursor = (v141_35).read_zipper();
    let v141_83_origin = v141_83_cursor.path().len();
    for v141_83_byte in v141_83_cursor.child_mask().iter() {
      v141_83_cursor.descend_to_existing_byte(v141_83_byte);
      {
      for v142_2_byte in v141_83_cursor.child_mask().iter() {
        v141_83_cursor.descend_to_existing_byte(v142_2_byte);
        {
        for v143_3_byte in v141_83_cursor.child_mask().iter() {
          v141_83_cursor.descend_to_existing_byte(v143_3_byte);
          {
          for v144_3_byte in v141_83_cursor.child_mask().iter() {
            v141_83_cursor.descend_to_existing_byte(v144_3_byte);
            {
            let v145_3: Space = routine_26(c, &v141_83_cursor.path()[v141_83_origin..(v141_83_origin + 4)], &v141_83_cursor);
            join_wrapped_into(&mut v141_83_write,&((v145_3).read_zipper()),&[]);
            }
            v141_83_cursor.ascend(1);
          }
          }
          v141_83_cursor.ascend(1);
        }
        }
        v141_83_cursor.ascend(1);
      }
      }
      v141_83_cursor.ascend(1);
    }
    drop(v141_83_cursor);
    drop(v141_83_write);
    compose(&(v64_82),&(v141_83))
  };

((v64_18).clone(),(v64_20).clone(),(v64_37).clone(),(v64_40).clone(),(v64_42).clone(),(v64_43).clone(),(v64_46).clone(),(v64_48).clone(),(v64_49).clone(),(v64_52).clone(),(v64_54).clone(),(v64_55).clone(),(v64_58).clone(),(v64_60).clone(),(v64_61).clone(),(v64_64).clone(),(v64_66).clone(),(v64_67).clone(),(v64_70).clone(),(v64_72).clone(),(v64_73).clone(),(v64_76).clone(),(v64_78).clone(),(v64_79).clone(),(v64_82).clone(),(v64_84).clone(),)
}

#[inline(never)]
fn native_block_1(c: &mut Context,capture_0: &[u8],capture_1: &[u8],capture_2: &[u8],capture_3: &[u8],capture_4: &[u8],capture_5: &[u8],capture_6: &[u8],capture_7: &[u8],capture_8: &[u8],capture_9: &[u8],capture_10: &[u8],capture_11: &[u8],capture_12: &[u8],capture_13: &[u8],capture_14: &[u8],capture_15: &[u8],capture_16: &Space,capture_17: &Space,capture_18: &Space) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v64_85: Space = unite(&((*capture_17)),&((*capture_18)));
  let v64_87: Space = intersect(&(*CONSTANT_59),&((*capture_16)));
  let mut v64_88 = Space::new();
  let mut v64_88_write = v64_88.write_zipper();
  let mut v64_88_cursor = (v64_87).read_zipper();
  let v64_88_origin = v64_88_cursor.path().len();
  for v64_88_byte in v64_88_cursor.child_mask().iter() {
    v64_88_cursor.descend_to_existing_byte(v64_88_byte);
    {
    for v146_2_byte in v64_88_cursor.child_mask().iter() {
      v64_88_cursor.descend_to_existing_byte(v146_2_byte);
      {
      for v147_3_byte in v64_88_cursor.child_mask().iter() {
        v64_88_cursor.descend_to_existing_byte(v147_3_byte);
        {
        for v148_3_byte in v64_88_cursor.child_mask().iter() {
          v64_88_cursor.descend_to_existing_byte(v148_3_byte);
          {
          let v149_3: Space = routine_27(c, &v64_88_cursor.path()[v64_88_origin..(v64_88_origin + 4)], &v64_88_cursor);
          join_wrapped_into(&mut v64_88_write,&((v149_3).read_zipper()),&[]);
          }
          v64_88_cursor.ascend(1);
        }
        }
        v64_88_cursor.ascend(1);
      }
      }
      v64_88_cursor.ascend(1);
    }
    }
    v64_88_cursor.ascend(1);
  }
  drop(v64_88_cursor);
  drop(v64_88_write);
  drop(v64_87);
  let v64_90: Space = if (&(v64_88)).is_empty() { Space::new() } else {
    let v150_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v150_22: Path = concat_path(&(v150_21),&(*capture_10));
    drop(v150_21);
    let v150_23: Path = concat_path(&(v150_22),&(*capture_11));
    drop(v150_22);
    let v150_24: Path = concat_path(&(v150_23),&(*capture_12));
    drop(v150_23);
    let v150_25: Path = concat_path(&(v150_24),&(*capture_13));
    drop(v150_24);
    let v150_26: Path = concat_path(&(v150_25),&(*capture_14));
    drop(v150_25);
    let v150_27: Path = concat_path(&(v150_26),&(*capture_15));
    drop(v150_26);
    let v150_28: Path = concat_path(&(v150_27),&(*capture_2));
    drop(v150_27);
    let v150_29: Path = concat_path(&(v150_28),&(*capture_3));
    drop(v150_28);
    let v150_30: Path = concat_path(&(v150_29),&(*capture_4));
    drop(v150_29);
    let v150_31: Path = concat_path(&(v150_30),&(*capture_5));
    drop(v150_30);
    let v150_32: Path = concat_path(&(v150_31),&(*capture_6));
    drop(v150_31);
    let v150_33: Path = concat_path(&(v150_32),&(*capture_7));
    drop(v150_32);
    let v150_34: Path = concat_path(&(v150_33),&(*capture_0));
    drop(v150_33);
    let v150_35: Space = singleton(&(v150_34));
    drop(v150_34);
    let mut v150_89 = Space::new();
    let mut v150_89_write = v150_89.write_zipper();
    let mut v150_89_cursor = (v150_35).read_zipper();
    let v150_89_origin = v150_89_cursor.path().len();
    for v150_89_byte in v150_89_cursor.child_mask().iter() {
      v150_89_cursor.descend_to_existing_byte(v150_89_byte);
      {
      for v151_2_byte in v150_89_cursor.child_mask().iter() {
        v150_89_cursor.descend_to_existing_byte(v151_2_byte);
        {
        for v152_3_byte in v150_89_cursor.child_mask().iter() {
          v150_89_cursor.descend_to_existing_byte(v152_3_byte);
          {
          for v153_3_byte in v150_89_cursor.child_mask().iter() {
            v150_89_cursor.descend_to_existing_byte(v153_3_byte);
            {
            let v154_3: Space = routine_28(c, &v150_89_cursor.path()[v150_89_origin..(v150_89_origin + 4)], &v150_89_cursor);
            join_wrapped_into(&mut v150_89_write,&((v154_3).read_zipper()),&[]);
            }
            v150_89_cursor.ascend(1);
          }
          }
          v150_89_cursor.ascend(1);
        }
        }
        v150_89_cursor.ascend(1);
      }
      }
      v150_89_cursor.ascend(1);
    }
    drop(v150_89_cursor);
    drop(v150_89_write);
    compose(&(v64_88),&(v150_89))
  };
  let v64_91: Space = unite(&(v64_85),&(v64_90));
  let v64_93: Space = intersect(&(*CONSTANT_60),&((*capture_16)));
  let mut v64_94 = Space::new();
  let mut v64_94_write = v64_94.write_zipper();
  let mut v64_94_cursor = (v64_93).read_zipper();
  let v64_94_origin = v64_94_cursor.path().len();
  for v64_94_byte in v64_94_cursor.child_mask().iter() {
    v64_94_cursor.descend_to_existing_byte(v64_94_byte);
    {
    for v155_2_byte in v64_94_cursor.child_mask().iter() {
      v64_94_cursor.descend_to_existing_byte(v155_2_byte);
      {
      for v156_3_byte in v64_94_cursor.child_mask().iter() {
        v64_94_cursor.descend_to_existing_byte(v156_3_byte);
        {
        for v157_3_byte in v64_94_cursor.child_mask().iter() {
          v64_94_cursor.descend_to_existing_byte(v157_3_byte);
          {
          let v158_3: Space = routine_29(c, &v64_94_cursor.path()[v64_94_origin..(v64_94_origin + 4)], &v64_94_cursor);
          join_wrapped_into(&mut v64_94_write,&((v158_3).read_zipper()),&[]);
          }
          v64_94_cursor.ascend(1);
        }
        }
        v64_94_cursor.ascend(1);
      }
      }
      v64_94_cursor.ascend(1);
    }
    }
    v64_94_cursor.ascend(1);
  }
  drop(v64_94_cursor);
  drop(v64_94_write);
  drop(v64_93);
  let v64_96: Space = if (&(v64_94)).is_empty() { Space::new() } else {
    let v159_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v159_22: Path = concat_path(&(v159_21),&(*capture_10));
    drop(v159_21);
    let v159_23: Path = concat_path(&(v159_22),&(*capture_11));
    drop(v159_22);
    let v159_24: Path = concat_path(&(v159_23),&(*capture_12));
    drop(v159_23);
    let v159_25: Path = concat_path(&(v159_24),&(*capture_13));
    drop(v159_24);
    let v159_26: Path = concat_path(&(v159_25),&(*capture_14));
    drop(v159_25);
    let v159_27: Path = concat_path(&(v159_26),&(*capture_15));
    drop(v159_26);
    let v159_28: Path = concat_path(&(v159_27),&(*capture_2));
    drop(v159_27);
    let v159_29: Path = concat_path(&(v159_28),&(*capture_3));
    drop(v159_28);
    let v159_30: Path = concat_path(&(v159_29),&(*capture_4));
    drop(v159_29);
    let v159_31: Path = concat_path(&(v159_30),&(*capture_5));
    drop(v159_30);
    let v159_32: Path = concat_path(&(v159_31),&(*capture_6));
    drop(v159_31);
    let v159_33: Path = concat_path(&(v159_32),&(*capture_7));
    drop(v159_32);
    let v159_34: Path = concat_path(&(v159_33),&(*capture_0));
    drop(v159_33);
    let v159_35: Space = singleton(&(v159_34));
    drop(v159_34);
    let mut v159_95 = Space::new();
    let mut v159_95_write = v159_95.write_zipper();
    let mut v159_95_cursor = (v159_35).read_zipper();
    let v159_95_origin = v159_95_cursor.path().len();
    for v159_95_byte in v159_95_cursor.child_mask().iter() {
      v159_95_cursor.descend_to_existing_byte(v159_95_byte);
      {
      for v160_2_byte in v159_95_cursor.child_mask().iter() {
        v159_95_cursor.descend_to_existing_byte(v160_2_byte);
        {
        for v161_3_byte in v159_95_cursor.child_mask().iter() {
          v159_95_cursor.descend_to_existing_byte(v161_3_byte);
          {
          for v162_3_byte in v159_95_cursor.child_mask().iter() {
            v159_95_cursor.descend_to_existing_byte(v162_3_byte);
            {
            let v163_3: Space = routine_30(c, &v159_95_cursor.path()[v159_95_origin..(v159_95_origin + 4)], &v159_95_cursor);
            join_wrapped_into(&mut v159_95_write,&((v163_3).read_zipper()),&[]);
            }
            v159_95_cursor.ascend(1);
          }
          }
          v159_95_cursor.ascend(1);
        }
        }
        v159_95_cursor.ascend(1);
      }
      }
      v159_95_cursor.ascend(1);
    }
    drop(v159_95_cursor);
    drop(v159_95_write);
    compose(&(v64_94),&(v159_95))
  };
  let v64_97: Space = unite(&(v64_91),&(v64_96));
  let v64_99: Space = intersect(&(*CONSTANT_61),&((*capture_16)));
  let mut v64_100 = Space::new();
  let mut v64_100_write = v64_100.write_zipper();
  let mut v64_100_cursor = (v64_99).read_zipper();
  let v64_100_origin = v64_100_cursor.path().len();
  for v64_100_byte in v64_100_cursor.child_mask().iter() {
    v64_100_cursor.descend_to_existing_byte(v64_100_byte);
    {
    for v164_2_byte in v64_100_cursor.child_mask().iter() {
      v64_100_cursor.descend_to_existing_byte(v164_2_byte);
      {
      for v165_3_byte in v64_100_cursor.child_mask().iter() {
        v64_100_cursor.descend_to_existing_byte(v165_3_byte);
        {
        for v166_3_byte in v64_100_cursor.child_mask().iter() {
          v64_100_cursor.descend_to_existing_byte(v166_3_byte);
          {
          let v167_3: Space = routine_31(c, &v64_100_cursor.path()[v64_100_origin..(v64_100_origin + 4)], &v64_100_cursor);
          join_wrapped_into(&mut v64_100_write,&((v167_3).read_zipper()),&[]);
          }
          v64_100_cursor.ascend(1);
        }
        }
        v64_100_cursor.ascend(1);
      }
      }
      v64_100_cursor.ascend(1);
    }
    }
    v64_100_cursor.ascend(1);
  }
  drop(v64_100_cursor);
  drop(v64_100_write);
  drop(v64_99);
  let v64_102: Space = if (&(v64_100)).is_empty() { Space::new() } else {
    let v168_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v168_22: Path = concat_path(&(v168_21),&(*capture_10));
    drop(v168_21);
    let v168_23: Path = concat_path(&(v168_22),&(*capture_11));
    drop(v168_22);
    let v168_24: Path = concat_path(&(v168_23),&(*capture_12));
    drop(v168_23);
    let v168_25: Path = concat_path(&(v168_24),&(*capture_13));
    drop(v168_24);
    let v168_26: Path = concat_path(&(v168_25),&(*capture_14));
    drop(v168_25);
    let v168_27: Path = concat_path(&(v168_26),&(*capture_15));
    drop(v168_26);
    let v168_28: Path = concat_path(&(v168_27),&(*capture_2));
    drop(v168_27);
    let v168_29: Path = concat_path(&(v168_28),&(*capture_3));
    drop(v168_28);
    let v168_30: Path = concat_path(&(v168_29),&(*capture_4));
    drop(v168_29);
    let v168_31: Path = concat_path(&(v168_30),&(*capture_5));
    drop(v168_30);
    let v168_32: Path = concat_path(&(v168_31),&(*capture_6));
    drop(v168_31);
    let v168_33: Path = concat_path(&(v168_32),&(*capture_7));
    drop(v168_32);
    let v168_34: Path = concat_path(&(v168_33),&(*capture_0));
    drop(v168_33);
    let v168_35: Space = singleton(&(v168_34));
    drop(v168_34);
    let mut v168_101 = Space::new();
    let mut v168_101_write = v168_101.write_zipper();
    let mut v168_101_cursor = (v168_35).read_zipper();
    let v168_101_origin = v168_101_cursor.path().len();
    for v168_101_byte in v168_101_cursor.child_mask().iter() {
      v168_101_cursor.descend_to_existing_byte(v168_101_byte);
      {
      for v169_2_byte in v168_101_cursor.child_mask().iter() {
        v168_101_cursor.descend_to_existing_byte(v169_2_byte);
        {
        for v170_3_byte in v168_101_cursor.child_mask().iter() {
          v168_101_cursor.descend_to_existing_byte(v170_3_byte);
          {
          for v171_3_byte in v168_101_cursor.child_mask().iter() {
            v168_101_cursor.descend_to_existing_byte(v171_3_byte);
            {
            let v172_3: Space = routine_32(c, &v168_101_cursor.path()[v168_101_origin..(v168_101_origin + 4)], &v168_101_cursor);
            join_wrapped_into(&mut v168_101_write,&((v172_3).read_zipper()),&[]);
            }
            v168_101_cursor.ascend(1);
          }
          }
          v168_101_cursor.ascend(1);
        }
        }
        v168_101_cursor.ascend(1);
      }
      }
      v168_101_cursor.ascend(1);
    }
    drop(v168_101_cursor);
    drop(v168_101_write);
    compose(&(v64_100),&(v168_101))
  };
  let v64_103: Space = unite(&(v64_97),&(v64_102));
  let v64_105: Space = intersect(&(*CONSTANT_62),&((*capture_16)));
  let mut v64_106 = Space::new();
  let mut v64_106_write = v64_106.write_zipper();
  let mut v64_106_cursor = (v64_105).read_zipper();
  let v64_106_origin = v64_106_cursor.path().len();
  for v64_106_byte in v64_106_cursor.child_mask().iter() {
    v64_106_cursor.descend_to_existing_byte(v64_106_byte);
    {
    for v173_2_byte in v64_106_cursor.child_mask().iter() {
      v64_106_cursor.descend_to_existing_byte(v173_2_byte);
      {
      for v174_3_byte in v64_106_cursor.child_mask().iter() {
        v64_106_cursor.descend_to_existing_byte(v174_3_byte);
        {
        for v175_3_byte in v64_106_cursor.child_mask().iter() {
          v64_106_cursor.descend_to_existing_byte(v175_3_byte);
          {
          let v176_3: Space = routine_33(c, &v64_106_cursor.path()[v64_106_origin..(v64_106_origin + 4)], &v64_106_cursor);
          join_wrapped_into(&mut v64_106_write,&((v176_3).read_zipper()),&[]);
          }
          v64_106_cursor.ascend(1);
        }
        }
        v64_106_cursor.ascend(1);
      }
      }
      v64_106_cursor.ascend(1);
    }
    }
    v64_106_cursor.ascend(1);
  }
  drop(v64_106_cursor);
  drop(v64_106_write);
  drop(v64_105);
  let v64_108: Space = if (&(v64_106)).is_empty() { Space::new() } else {
    let v177_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v177_22: Path = concat_path(&(v177_21),&(*capture_10));
    drop(v177_21);
    let v177_23: Path = concat_path(&(v177_22),&(*capture_11));
    drop(v177_22);
    let v177_24: Path = concat_path(&(v177_23),&(*capture_12));
    drop(v177_23);
    let v177_25: Path = concat_path(&(v177_24),&(*capture_13));
    drop(v177_24);
    let v177_26: Path = concat_path(&(v177_25),&(*capture_14));
    drop(v177_25);
    let v177_27: Path = concat_path(&(v177_26),&(*capture_15));
    drop(v177_26);
    let v177_28: Path = concat_path(&(v177_27),&(*capture_2));
    drop(v177_27);
    let v177_29: Path = concat_path(&(v177_28),&(*capture_3));
    drop(v177_28);
    let v177_30: Path = concat_path(&(v177_29),&(*capture_4));
    drop(v177_29);
    let v177_31: Path = concat_path(&(v177_30),&(*capture_5));
    drop(v177_30);
    let v177_32: Path = concat_path(&(v177_31),&(*capture_6));
    drop(v177_31);
    let v177_33: Path = concat_path(&(v177_32),&(*capture_7));
    drop(v177_32);
    let v177_34: Path = concat_path(&(v177_33),&(*capture_0));
    drop(v177_33);
    let v177_35: Space = singleton(&(v177_34));
    drop(v177_34);
    let mut v177_107 = Space::new();
    let mut v177_107_write = v177_107.write_zipper();
    let mut v177_107_cursor = (v177_35).read_zipper();
    let v177_107_origin = v177_107_cursor.path().len();
    for v177_107_byte in v177_107_cursor.child_mask().iter() {
      v177_107_cursor.descend_to_existing_byte(v177_107_byte);
      {
      for v178_2_byte in v177_107_cursor.child_mask().iter() {
        v177_107_cursor.descend_to_existing_byte(v178_2_byte);
        {
        for v179_3_byte in v177_107_cursor.child_mask().iter() {
          v177_107_cursor.descend_to_existing_byte(v179_3_byte);
          {
          for v180_3_byte in v177_107_cursor.child_mask().iter() {
            v177_107_cursor.descend_to_existing_byte(v180_3_byte);
            {
            let v181_3: Space = routine_34(c, &v177_107_cursor.path()[v177_107_origin..(v177_107_origin + 4)], &v177_107_cursor);
            join_wrapped_into(&mut v177_107_write,&((v181_3).read_zipper()),&[]);
            }
            v177_107_cursor.ascend(1);
          }
          }
          v177_107_cursor.ascend(1);
        }
        }
        v177_107_cursor.ascend(1);
      }
      }
      v177_107_cursor.ascend(1);
    }
    drop(v177_107_cursor);
    drop(v177_107_write);
    compose(&(v64_106),&(v177_107))
  };
  let v64_109: Space = unite(&(v64_103),&(v64_108));
  let v64_111: Space = intersect(&(*CONSTANT_63),&((*capture_16)));
  let mut v64_112 = Space::new();
  let mut v64_112_write = v64_112.write_zipper();
  let mut v64_112_cursor = (v64_111).read_zipper();
  let v64_112_origin = v64_112_cursor.path().len();
  for v64_112_byte in v64_112_cursor.child_mask().iter() {
    v64_112_cursor.descend_to_existing_byte(v64_112_byte);
    {
    for v182_2_byte in v64_112_cursor.child_mask().iter() {
      v64_112_cursor.descend_to_existing_byte(v182_2_byte);
      {
      for v183_3_byte in v64_112_cursor.child_mask().iter() {
        v64_112_cursor.descend_to_existing_byte(v183_3_byte);
        {
        for v184_3_byte in v64_112_cursor.child_mask().iter() {
          v64_112_cursor.descend_to_existing_byte(v184_3_byte);
          {
          let v185_3: Space = routine_35(c, &v64_112_cursor.path()[v64_112_origin..(v64_112_origin + 4)], &v64_112_cursor);
          join_wrapped_into(&mut v64_112_write,&((v185_3).read_zipper()),&[]);
          }
          v64_112_cursor.ascend(1);
        }
        }
        v64_112_cursor.ascend(1);
      }
      }
      v64_112_cursor.ascend(1);
    }
    }
    v64_112_cursor.ascend(1);
  }
  drop(v64_112_cursor);
  drop(v64_112_write);
  drop(v64_111);
  let v64_114: Space = if (&(v64_112)).is_empty() { Space::new() } else {
    let v186_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v186_22: Path = concat_path(&(v186_21),&(*capture_10));
    drop(v186_21);
    let v186_23: Path = concat_path(&(v186_22),&(*capture_11));
    drop(v186_22);
    let v186_24: Path = concat_path(&(v186_23),&(*capture_12));
    drop(v186_23);
    let v186_25: Path = concat_path(&(v186_24),&(*capture_13));
    drop(v186_24);
    let v186_26: Path = concat_path(&(v186_25),&(*capture_14));
    drop(v186_25);
    let v186_27: Path = concat_path(&(v186_26),&(*capture_15));
    drop(v186_26);
    let v186_28: Path = concat_path(&(v186_27),&(*capture_2));
    drop(v186_27);
    let v186_29: Path = concat_path(&(v186_28),&(*capture_3));
    drop(v186_28);
    let v186_30: Path = concat_path(&(v186_29),&(*capture_4));
    drop(v186_29);
    let v186_31: Path = concat_path(&(v186_30),&(*capture_5));
    drop(v186_30);
    let v186_32: Path = concat_path(&(v186_31),&(*capture_6));
    drop(v186_31);
    let v186_33: Path = concat_path(&(v186_32),&(*capture_7));
    drop(v186_32);
    let v186_34: Path = concat_path(&(v186_33),&(*capture_0));
    drop(v186_33);
    let v186_35: Space = singleton(&(v186_34));
    drop(v186_34);
    let mut v186_113 = Space::new();
    let mut v186_113_write = v186_113.write_zipper();
    let mut v186_113_cursor = (v186_35).read_zipper();
    let v186_113_origin = v186_113_cursor.path().len();
    for v186_113_byte in v186_113_cursor.child_mask().iter() {
      v186_113_cursor.descend_to_existing_byte(v186_113_byte);
      {
      for v187_2_byte in v186_113_cursor.child_mask().iter() {
        v186_113_cursor.descend_to_existing_byte(v187_2_byte);
        {
        for v188_3_byte in v186_113_cursor.child_mask().iter() {
          v186_113_cursor.descend_to_existing_byte(v188_3_byte);
          {
          for v189_3_byte in v186_113_cursor.child_mask().iter() {
            v186_113_cursor.descend_to_existing_byte(v189_3_byte);
            {
            let v190_3: Space = routine_36(c, &v186_113_cursor.path()[v186_113_origin..(v186_113_origin + 4)], &v186_113_cursor);
            join_wrapped_into(&mut v186_113_write,&((v190_3).read_zipper()),&[]);
            }
            v186_113_cursor.ascend(1);
          }
          }
          v186_113_cursor.ascend(1);
        }
        }
        v186_113_cursor.ascend(1);
      }
      }
      v186_113_cursor.ascend(1);
    }
    drop(v186_113_cursor);
    drop(v186_113_write);
    compose(&(v64_112),&(v186_113))
  };
  let v64_115: Space = unite(&(v64_109),&(v64_114));
  let v64_117: Space = intersect(&(*CONSTANT_64),&((*capture_16)));
  let mut v64_118 = Space::new();
  let mut v64_118_write = v64_118.write_zipper();
  let mut v64_118_cursor = (v64_117).read_zipper();
  let v64_118_origin = v64_118_cursor.path().len();
  for v64_118_byte in v64_118_cursor.child_mask().iter() {
    v64_118_cursor.descend_to_existing_byte(v64_118_byte);
    {
    for v191_2_byte in v64_118_cursor.child_mask().iter() {
      v64_118_cursor.descend_to_existing_byte(v191_2_byte);
      {
      for v192_3_byte in v64_118_cursor.child_mask().iter() {
        v64_118_cursor.descend_to_existing_byte(v192_3_byte);
        {
        for v193_3_byte in v64_118_cursor.child_mask().iter() {
          v64_118_cursor.descend_to_existing_byte(v193_3_byte);
          {
          let v194_3: Space = routine_37(c, &v64_118_cursor.path()[v64_118_origin..(v64_118_origin + 4)], &v64_118_cursor);
          join_wrapped_into(&mut v64_118_write,&((v194_3).read_zipper()),&[]);
          }
          v64_118_cursor.ascend(1);
        }
        }
        v64_118_cursor.ascend(1);
      }
      }
      v64_118_cursor.ascend(1);
    }
    }
    v64_118_cursor.ascend(1);
  }
  drop(v64_118_cursor);
  drop(v64_118_write);
  drop(v64_117);
  let v64_120: Space = if (&(v64_118)).is_empty() { Space::new() } else {
    let v195_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v195_22: Path = concat_path(&(v195_21),&(*capture_10));
    drop(v195_21);
    let v195_23: Path = concat_path(&(v195_22),&(*capture_11));
    drop(v195_22);
    let v195_24: Path = concat_path(&(v195_23),&(*capture_12));
    drop(v195_23);
    let v195_25: Path = concat_path(&(v195_24),&(*capture_13));
    drop(v195_24);
    let v195_26: Path = concat_path(&(v195_25),&(*capture_14));
    drop(v195_25);
    let v195_27: Path = concat_path(&(v195_26),&(*capture_15));
    drop(v195_26);
    let v195_28: Path = concat_path(&(v195_27),&(*capture_2));
    drop(v195_27);
    let v195_29: Path = concat_path(&(v195_28),&(*capture_3));
    drop(v195_28);
    let v195_30: Path = concat_path(&(v195_29),&(*capture_4));
    drop(v195_29);
    let v195_31: Path = concat_path(&(v195_30),&(*capture_5));
    drop(v195_30);
    let v195_32: Path = concat_path(&(v195_31),&(*capture_6));
    drop(v195_31);
    let v195_33: Path = concat_path(&(v195_32),&(*capture_7));
    drop(v195_32);
    let v195_34: Path = concat_path(&(v195_33),&(*capture_0));
    drop(v195_33);
    let v195_35: Space = singleton(&(v195_34));
    drop(v195_34);
    let mut v195_119 = Space::new();
    let mut v195_119_write = v195_119.write_zipper();
    let mut v195_119_cursor = (v195_35).read_zipper();
    let v195_119_origin = v195_119_cursor.path().len();
    for v195_119_byte in v195_119_cursor.child_mask().iter() {
      v195_119_cursor.descend_to_existing_byte(v195_119_byte);
      {
      for v196_2_byte in v195_119_cursor.child_mask().iter() {
        v195_119_cursor.descend_to_existing_byte(v196_2_byte);
        {
        for v197_3_byte in v195_119_cursor.child_mask().iter() {
          v195_119_cursor.descend_to_existing_byte(v197_3_byte);
          {
          for v198_3_byte in v195_119_cursor.child_mask().iter() {
            v195_119_cursor.descend_to_existing_byte(v198_3_byte);
            {
            let v199_3: Space = routine_38(c, &v195_119_cursor.path()[v195_119_origin..(v195_119_origin + 4)], &v195_119_cursor);
            join_wrapped_into(&mut v195_119_write,&((v199_3).read_zipper()),&[]);
            }
            v195_119_cursor.ascend(1);
          }
          }
          v195_119_cursor.ascend(1);
        }
        }
        v195_119_cursor.ascend(1);
      }
      }
      v195_119_cursor.ascend(1);
    }
    drop(v195_119_cursor);
    drop(v195_119_write);
    compose(&(v64_118),&(v195_119))
  };
  let v64_121: Space = unite(&(v64_115),&(v64_120));
  let v64_123: Space = intersect(&(*CONSTANT_65),&((*capture_16)));

  let mut v64_124 = Space::new();
  let mut v64_124_write = v64_124.write_zipper();
  let mut v64_124_cursor = (v64_123).read_zipper();
  let v64_124_origin = v64_124_cursor.path().len();
  for v64_124_byte in v64_124_cursor.child_mask().iter() {
    v64_124_cursor.descend_to_existing_byte(v64_124_byte);
    {
    for v200_2_byte in v64_124_cursor.child_mask().iter() {
      v64_124_cursor.descend_to_existing_byte(v200_2_byte);
      {
      for v201_3_byte in v64_124_cursor.child_mask().iter() {
        v64_124_cursor.descend_to_existing_byte(v201_3_byte);
        {
        for v202_3_byte in v64_124_cursor.child_mask().iter() {
          v64_124_cursor.descend_to_existing_byte(v202_3_byte);
          {
          let v203_3: Space = routine_39(c, &v64_124_cursor.path()[v64_124_origin..(v64_124_origin + 4)], &v64_124_cursor);
          join_wrapped_into(&mut v64_124_write,&((v203_3).read_zipper()),&[]);
          }
          v64_124_cursor.ascend(1);
        }
        }
        v64_124_cursor.ascend(1);
      }
      }
      v64_124_cursor.ascend(1);
    }
    }
    v64_124_cursor.ascend(1);
  }
  drop(v64_124_cursor);
  drop(v64_124_write);
  drop(v64_123);
  let v64_126: Space = if (&(v64_124)).is_empty() { Space::new() } else {
    let v204_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v204_22: Path = concat_path(&(v204_21),&(*capture_10));
    drop(v204_21);
    let v204_23: Path = concat_path(&(v204_22),&(*capture_11));
    drop(v204_22);
    let v204_24: Path = concat_path(&(v204_23),&(*capture_12));
    drop(v204_23);
    let v204_25: Path = concat_path(&(v204_24),&(*capture_13));
    drop(v204_24);
    let v204_26: Path = concat_path(&(v204_25),&(*capture_14));
    drop(v204_25);
    let v204_27: Path = concat_path(&(v204_26),&(*capture_15));
    drop(v204_26);
    let v204_28: Path = concat_path(&(v204_27),&(*capture_2));
    drop(v204_27);
    let v204_29: Path = concat_path(&(v204_28),&(*capture_3));
    drop(v204_28);
    let v204_30: Path = concat_path(&(v204_29),&(*capture_4));
    drop(v204_29);
    let v204_31: Path = concat_path(&(v204_30),&(*capture_5));
    drop(v204_30);
    let v204_32: Path = concat_path(&(v204_31),&(*capture_6));
    drop(v204_31);
    let v204_33: Path = concat_path(&(v204_32),&(*capture_7));
    drop(v204_32);
    let v204_34: Path = concat_path(&(v204_33),&(*capture_0));
    drop(v204_33);
    let v204_35: Space = singleton(&(v204_34));
    drop(v204_34);
    let mut v204_125 = Space::new();
    let mut v204_125_write = v204_125.write_zipper();
    let mut v204_125_cursor = (v204_35).read_zipper();
    let v204_125_origin = v204_125_cursor.path().len();
    for v204_125_byte in v204_125_cursor.child_mask().iter() {
      v204_125_cursor.descend_to_existing_byte(v204_125_byte);
      {
      for v205_2_byte in v204_125_cursor.child_mask().iter() {
        v204_125_cursor.descend_to_existing_byte(v205_2_byte);
        {
        for v206_3_byte in v204_125_cursor.child_mask().iter() {
          v204_125_cursor.descend_to_existing_byte(v206_3_byte);
          {
          for v207_3_byte in v204_125_cursor.child_mask().iter() {
            v204_125_cursor.descend_to_existing_byte(v207_3_byte);
            {
            let v208_3: Space = routine_40(c, &v204_125_cursor.path()[v204_125_origin..(v204_125_origin + 4)], &v204_125_cursor);
            join_wrapped_into(&mut v204_125_write,&((v208_3).read_zipper()),&[]);
            }
            v204_125_cursor.ascend(1);
          }
          }
          v204_125_cursor.ascend(1);
        }
        }
        v204_125_cursor.ascend(1);
      }
      }
      v204_125_cursor.ascend(1);
    }
    drop(v204_125_cursor);
    drop(v204_125_write);
    drop(v204_35);
    compose(&(v64_124),&(v204_125))
  };
  let v64_127: Space = unite(&(v64_121),&(v64_126));
  let mut v64_160 = Space::new();
  let mut v64_160_write = v64_160.write_zipper();
  let mut v64_160_cursor = (v64_127).read_zipper();
  let v64_160_origin = v64_160_cursor.path().len();
  for v64_160_byte in v64_160_cursor.child_mask().iter() {
    v64_160_cursor.descend_to_existing_byte(v64_160_byte);
    {
    for v209_2_byte in v64_160_cursor.child_mask().iter() {
      v64_160_cursor.descend_to_existing_byte(v209_2_byte);
      {
      for v210_3_byte in v64_160_cursor.child_mask().iter() {
        v64_160_cursor.descend_to_existing_byte(v210_3_byte);
        {
        for v211_3_byte in v64_160_cursor.child_mask().iter() {
          v64_160_cursor.descend_to_existing_byte(v211_3_byte);
          {
          let v212_2: Space = routine_41(c, &(*CONSTANT_1), &(*capture_1), &((*CONSTANT_66).read_zipper()));
          let v212_3: Space = routine_41(c, &(*CONSTANT_3), &(*capture_1), &((*CONSTANT_67).read_zipper()));
          let v212_4: Space = unite(&(v212_2),&(v212_3));
          let v212_5: Space = routine_41(c, &(*CONSTANT_5), &(*capture_1), &((*CONSTANT_68).read_zipper()));
          let v212_6: Space = unite(&(v212_4),&(v212_5));
          let v212_7: Space = routine_41(c, &(*CONSTANT_7), &(*capture_1), &((*CONSTANT_69).read_zipper()));
          let v212_8: Space = unite(&(v212_6),&(v212_7));
          let v212_9: Space = routine_41(c, &(*CONSTANT_9), &(*capture_1), &((*CONSTANT_70).read_zipper()));
          let v212_10: Space = unite(&(v212_8),&(v212_9));
          let v212_11: Space = routine_41(c, &(*CONSTANT_11), &(*capture_1), &((*CONSTANT_71).read_zipper()));
          let v212_12: Space = unite(&(v212_10),&(v212_11));
          let v212_13: Space = routine_41(c, &(*CONSTANT_13), &(*capture_1), &((*CONSTANT_72).read_zipper()));
          let v212_14: Space = unite(&(v212_12),&(v212_13));
          let v212_15: Space = routine_41(c, &(*CONSTANT_15), &(*capture_1), &((*CONSTANT_73).read_zipper()));
          let v212_16: Space = unite(&(v212_14),&(v212_15));
          let v212_17: Space = routine_41(c, &(*CONSTANT_17), &(*capture_1), &((*CONSTANT_74).read_zipper()));
          let v212_18: Space = unite(&(v212_16),&(v212_17));
          let v212_19: Space = routine_41(c, &(*CONSTANT_19), &(*capture_1), &((*CONSTANT_75).read_zipper()));
          let v212_20: Space = unite(&(v212_18),&(v212_19));
          let v212_21: Space = routine_41(c, &(*CONSTANT_21), &(*capture_1), &((*CONSTANT_76).read_zipper()));
          let v212_22: Space = unite(&(v212_20),&(v212_21));
          let v212_23: Space = routine_41(c, &(*CONSTANT_23), &(*capture_1), &((*CONSTANT_77).read_zipper()));
          let v212_24: Space = unite(&(v212_22),&(v212_23));
          let v212_25: Space = routine_41(c, &(*CONSTANT_25), &(*capture_1), &((*CONSTANT_78).read_zipper()));
          let v212_26: Space = unite(&(v212_24),&(v212_25));
          let v212_27: Space = routine_41(c, &(*CONSTANT_27), &(*capture_1), &((*CONSTANT_79).read_zipper()));
          let v212_28: Space = unite(&(v212_26),&(v212_27));
          let v212_29: Space = routine_41(c, &(*CONSTANT_29), &(*capture_1), &((*CONSTANT_80).read_zipper()));
          let v212_30: Space = unite(&(v212_28),&(v212_29));
          let v212_31: Space = routine_41(c, &(*CONSTANT_81), &(*capture_1), &((*CONSTANT_82).read_zipper()));
          let v212_32: Space = unite(&(v212_30),&(v212_31));
          let mut v212_34_cursor = (v212_32).read_zipper();
          let v212_34_origin = v212_34_cursor.path().len();
          for v212_34_byte in v212_34_cursor.child_mask().iter() {
            v212_34_cursor.descend_to_existing_byte(v212_34_byte);
            {
            for v213_2_byte in v212_34_cursor.child_mask().iter() {
              v212_34_cursor.descend_to_existing_byte(v213_2_byte);
              {
              for v214_3_byte in v212_34_cursor.child_mask().iter() {
                v212_34_cursor.descend_to_existing_byte(v214_3_byte);
                {
                for v215_3_byte in v212_34_cursor.child_mask().iter() {
                  v212_34_cursor.descend_to_existing_byte(v215_3_byte);
                  {
                  let v216_3: Space = routine_42(c, &v212_34_cursor.path()[v212_34_origin..(v212_34_origin + 4)], &v64_160_cursor.path()[v64_160_origin..(v64_160_origin + 4)], &v212_34_cursor, &v64_160_cursor);
                  join_wrapped_into(&mut v64_160_write,&((v216_3).read_zipper()),&[]);
                  }
                  v212_34_cursor.ascend(1);
                }
                }
                v212_34_cursor.ascend(1);
              }
              }
              v212_34_cursor.ascend(1);
            }
            }
            v212_34_cursor.ascend(1);
          }
          drop(v212_34_cursor);
          }
          v64_160_cursor.ascend(1);
        }
        }
        v64_160_cursor.ascend(1);
      }
      }
      v64_160_cursor.ascend(1);
    }
    }
    v64_160_cursor.ascend(1);
  }
  drop(v64_160_cursor);
  drop(v64_160_write);
  let mut v64_177 = Space::new();
  let mut v64_177_write = v64_177.write_zipper();
  let mut v64_177_cursor = (v64_160).read_zipper();
  let v64_177_origin = v64_177_cursor.path().len();
  for v64_177_byte in v64_177_cursor.child_mask().iter() {
    v64_177_cursor.descend_to_existing_byte(v64_177_byte);
    {
    for v217_2_byte in v64_177_cursor.child_mask().iter() {
      v64_177_cursor.descend_to_existing_byte(v217_2_byte);
      {
      for v218_3_byte in v64_177_cursor.child_mask().iter() {
        v64_177_cursor.descend_to_existing_byte(v218_3_byte);
        {
        for v219_3_byte in v64_177_cursor.child_mask().iter() {
          v64_177_cursor.descend_to_existing_byte(v219_3_byte);
          {
          let v220_3: Space = routine_43(c, &(*CONSTANT_1), &(*capture_1), &v64_177_cursor.path()[v64_177_origin..(v64_177_origin + 4)], &((*CONSTANT_66).read_zipper()));
          let v220_4: Space = routine_43(c, &(*CONSTANT_3), &(*capture_1), &v64_177_cursor.path()[v64_177_origin..(v64_177_origin + 4)], &((*CONSTANT_67).read_zipper()));
          let v220_5: Space = unite(&(v220_3),&(v220_4));
          let v220_6: Space = routine_43(c, &(*CONSTANT_5), &(*capture_1), &v64_177_cursor.path()[v64_177_origin..(v64_177_origin + 4)], &((*CONSTANT_68).read_zipper()));
          let v220_7: Space = unite(&(v220_5),&(v220_6));
          let v220_8: Space = routine_43(c, &(*CONSTANT_7), &(*capture_1), &v64_177_cursor.path()[v64_177_origin..(v64_177_origin + 4)], &((*CONSTANT_69).read_zipper()));
          let v220_9: Space = unite(&(v220_7),&(v220_8));
          let v220_10: Space = routine_43(c, &(*CONSTANT_9), &(*capture_1), &v64_177_cursor.path()[v64_177_origin..(v64_177_origin + 4)], &((*CONSTANT_70).read_zipper()));
          let v220_11: Space = unite(&(v220_9),&(v220_10));
          let v220_12: Space = routine_43(c, &(*CONSTANT_11), &(*capture_1), &v64_177_cursor.path()[v64_177_origin..(v64_177_origin + 4)], &((*CONSTANT_71).read_zipper()));
          let v220_13: Space = unite(&(v220_11),&(v220_12));
          let v220_14: Space = routine_43(c, &(*CONSTANT_13), &(*capture_1), &v64_177_cursor.path()[v64_177_origin..(v64_177_origin + 4)], &((*CONSTANT_72).read_zipper()));
          let v220_15: Space = unite(&(v220_13),&(v220_14));
          let v220_16: Space = routine_43(c, &(*CONSTANT_15), &(*capture_1), &v64_177_cursor.path()[v64_177_origin..(v64_177_origin + 4)], &((*CONSTANT_73).read_zipper()));
          let v220_17: Space = unite(&(v220_15),&(v220_16));
          let v220_18: Space = routine_43(c, &(*CONSTANT_17), &(*capture_1), &v64_177_cursor.path()[v64_177_origin..(v64_177_origin + 4)], &((*CONSTANT_74).read_zipper()));
          let v220_19: Space = unite(&(v220_17),&(v220_18));
          let v220_20: Space = routine_43(c, &(*CONSTANT_19), &(*capture_1), &v64_177_cursor.path()[v64_177_origin..(v64_177_origin + 4)], &((*CONSTANT_75).read_zipper()));
          let v220_21: Space = unite(&(v220_19),&(v220_20));
          let v220_22: Space = routine_43(c, &(*CONSTANT_21), &(*capture_1), &v64_177_cursor.path()[v64_177_origin..(v64_177_origin + 4)], &((*CONSTANT_76).read_zipper()));
          let v220_23: Space = unite(&(v220_21),&(v220_22));
          let v220_24: Space = routine_43(c, &(*CONSTANT_23), &(*capture_1), &v64_177_cursor.path()[v64_177_origin..(v64_177_origin + 4)], &((*CONSTANT_77).read_zipper()));
          let v220_25: Space = unite(&(v220_23),&(v220_24));
          let v220_26: Space = routine_43(c, &(*CONSTANT_25), &(*capture_1), &v64_177_cursor.path()[v64_177_origin..(v64_177_origin + 4)], &((*CONSTANT_78).read_zipper()));
          let v220_27: Space = unite(&(v220_25),&(v220_26));
          let v220_28: Space = routine_43(c, &(*CONSTANT_27), &(*capture_1), &v64_177_cursor.path()[v64_177_origin..(v64_177_origin + 4)], &((*CONSTANT_79).read_zipper()));
          let v220_29: Space = unite(&(v220_27),&(v220_28));
          let v220_30: Space = routine_43(c, &(*CONSTANT_29), &(*capture_1), &v64_177_cursor.path()[v64_177_origin..(v64_177_origin + 4)], &((*CONSTANT_80).read_zipper()));
          let v220_31: Space = unite(&(v220_29),&(v220_30));
          let v220_32: Space = routine_43(c, &(*CONSTANT_81), &(*capture_1), &v64_177_cursor.path()[v64_177_origin..(v64_177_origin + 4)], &((*CONSTANT_82).read_zipper()));
          let v220_33: Space = unite(&(v220_31),&(v220_32));
          let mut v220_34_cursor = (v220_33).read_zipper();
          let v220_34_origin = v220_34_cursor.path().len();
          for v220_34_byte in v220_34_cursor.child_mask().iter() {
            v220_34_cursor.descend_to_existing_byte(v220_34_byte);
            {
            for v221_2_byte in v220_34_cursor.child_mask().iter() {
              v220_34_cursor.descend_to_existing_byte(v221_2_byte);
              {
              for v222_3_byte in v220_34_cursor.child_mask().iter() {
                v220_34_cursor.descend_to_existing_byte(v222_3_byte);
                {
                for v223_3_byte in v220_34_cursor.child_mask().iter() {
                  v220_34_cursor.descend_to_existing_byte(v223_3_byte);
                  {
                  let v224_3: Space = routine_44(c, &v220_34_cursor.path()[v220_34_origin..(v220_34_origin + 4)], &v220_34_cursor, &v64_177_cursor);
                  join_wrapped_into(&mut v64_177_write,&((v224_3).read_zipper()),&[]);
                  }
                  v220_34_cursor.ascend(1);
                }
                }
                v220_34_cursor.ascend(1);
              }
              }
              v220_34_cursor.ascend(1);
            }
            }
            v220_34_cursor.ascend(1);
          }
          drop(v220_34_cursor);
          }
          v64_177_cursor.ascend(1);
        }
        }
        v64_177_cursor.ascend(1);
      }
      }
      v64_177_cursor.ascend(1);
    }
    }
    v64_177_cursor.ascend(1);
  }
  drop(v64_177_cursor);
  drop(v64_177_write);

((v64_100).clone(),(v64_102).clone(),(v64_103).clone(),(v64_106).clone(),(v64_108).clone(),(v64_109).clone(),(v64_112).clone(),(v64_114).clone(),(v64_115).clone(),(v64_118).clone(),(v64_120).clone(),(v64_121).clone(),(v64_124).clone(),(v64_126).clone(),(v64_127).clone(),(v64_160).clone(),(v64_177).clone(),(v64_85).clone(),(v64_88).clone(),(v64_90).clone(),(v64_91).clone(),(v64_94).clone(),(v64_96).clone(),(v64_97).clone(),)
}

#[inline(never)]
fn native_block_2(c: &mut Context,capture_0: &[u8],capture_1: &View<'_, '_>) -> (Space,Space,Space,) {
  let v405_4: Space = singleton(&(*capture_0));
  let v405_5: Space = intersect(&(*CONSTANT_50),&(v405_4));
  let v405_50: Space = if (&(v405_5)).is_empty() { Space::new() } else {
    let v406_10: Space = if (&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_3)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_3))),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_5))))
    };
    let v406_13: Space = if (&(v406_10)).is_empty() { Space::new() } else {
      compose(&(v406_10),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v406_10);
    let v406_16: Space = if (&(v406_13)).is_empty() { Space::new() } else {
      compose(&(v406_13),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v406_13);
    let v406_19: Space = if (&(v406_16)).is_empty() { Space::new() } else {
      compose(&(v406_16),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v406_16);
    let v406_22: Space = if (&(v406_19)).is_empty() { Space::new() } else {
      compose(&(v406_19),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v406_19);
    let v406_25: Space = if (&(v406_22)).is_empty() { Space::new() } else {
      compose(&(v406_22),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v406_22);
    let v406_28: Space = if (&(v406_25)).is_empty() { Space::new() } else {
      compose(&(v406_25),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v406_25);
    let v406_31: Space = if (&(v406_28)).is_empty() { Space::new() } else {
      compose(&(v406_28),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v406_28);
    let v406_34: Space = if (&(v406_31)).is_empty() { Space::new() } else {
      compose(&(v406_31),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v406_31);
    let v406_37: Space = if (&(v406_34)).is_empty() { Space::new() } else {
      compose(&(v406_34),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v406_34);
    let v406_40: Space = if (&(v406_37)).is_empty() { Space::new() } else {
      compose(&(v406_37),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v406_37);
    let v406_43: Space = if (&(v406_40)).is_empty() { Space::new() } else {
      compose(&(v406_40),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_27))))
    };
    drop(v406_40);
    let v406_46: Space = if (&(v406_43)).is_empty() { Space::new() } else {
      compose(&(v406_43),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_29))))
    };
    drop(v406_43);
    let v406_49: Space = if (&(v406_46)).is_empty() { Space::new() } else {
      compose(&(v406_46),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_81))))
    };
    drop(v406_46);
    compose(&(v405_5),&(v406_49))
  };
  drop(v405_5);
  let v405_52: Space = intersect(&(*CONSTANT_51),&(v405_4));
  let v405_69: Space = if (&(v405_52)).is_empty() { Space::new() } else {
    let v421_55: Space = if (&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_5))))
    };
    let v421_56: Space = if (&(v421_55)).is_empty() { Space::new() } else {
      compose(&(v421_55),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v421_55);
    let v421_57: Space = if (&(v421_56)).is_empty() { Space::new() } else {
      compose(&(v421_56),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v421_56);
    let v421_58: Space = if (&(v421_57)).is_empty() { Space::new() } else {
      compose(&(v421_57),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v421_57);
    let v421_59: Space = if (&(v421_58)).is_empty() { Space::new() } else {
      compose(&(v421_58),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v421_58);
    let v421_60: Space = if (&(v421_59)).is_empty() { Space::new() } else {
      compose(&(v421_59),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v421_59);
    let v421_61: Space = if (&(v421_60)).is_empty() { Space::new() } else {
      compose(&(v421_60),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v421_60);
    let v421_62: Space = if (&(v421_61)).is_empty() { Space::new() } else {
      compose(&(v421_61),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v421_61);
    let v421_63: Space = if (&(v421_62)).is_empty() { Space::new() } else {
      compose(&(v421_62),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v421_62);
    let v421_64: Space = if (&(v421_63)).is_empty() { Space::new() } else {
      compose(&(v421_63),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v421_63);
    let v421_65: Space = if (&(v421_64)).is_empty() { Space::new() } else {
      compose(&(v421_64),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v421_64);
    let v421_66: Space = if (&(v421_65)).is_empty() { Space::new() } else {
      compose(&(v421_65),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_27))))
    };
    drop(v421_65);
    let v421_67: Space = if (&(v421_66)).is_empty() { Space::new() } else {
      compose(&(v421_66),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_29))))
    };
    drop(v421_66);
    let v421_68: Space = if (&(v421_67)).is_empty() { Space::new() } else {
      compose(&(v421_67),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_81))))
    };
    drop(v421_67);
    compose(&(v405_52),&(v421_68))
  };
  drop(v405_52);
  let v405_70: Space = unite(&(v405_50),&(v405_69));
  drop(v405_50);
  drop(v405_69);
  let v405_72: Space = intersect(&(*CONSTANT_52),&(v405_4));
  let v405_87: Space = if (&(v405_72)).is_empty() { Space::new() } else {
    let v436_73: Space = if (&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_3))))
    };
    let v436_74: Space = if (&(v436_73)).is_empty() { Space::new() } else {
      compose(&(v436_73),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_7))))
    };
    let v436_75: Space = if (&(v436_74)).is_empty() { Space::new() } else {
      compose(&(v436_74),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v436_74);
    let v436_76: Space = if (&(v436_75)).is_empty() { Space::new() } else {
      compose(&(v436_75),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v436_75);
    let v436_77: Space = if (&(v436_76)).is_empty() { Space::new() } else {
      compose(&(v436_76),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v436_76);
    let v436_78: Space = if (&(v436_77)).is_empty() { Space::new() } else {
      compose(&(v436_77),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v436_77);
    let v436_79: Space = if (&(v436_78)).is_empty() { Space::new() } else {
      compose(&(v436_78),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v436_78);
    let v436_80: Space = if (&(v436_79)).is_empty() { Space::new() } else {
      compose(&(v436_79),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v436_79);
    let v436_81: Space = if (&(v436_80)).is_empty() { Space::new() } else {
      compose(&(v436_80),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v436_80);
    let v436_82: Space = if (&(v436_81)).is_empty() { Space::new() } else {
      compose(&(v436_81),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v436_81);
    let v436_83: Space = if (&(v436_82)).is_empty() { Space::new() } else {
      compose(&(v436_82),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v436_82);
    let v436_84: Space = if (&(v436_83)).is_empty() { Space::new() } else {
      compose(&(v436_83),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_27))))
    };
    drop(v436_83);
    let v436_85: Space = if (&(v436_84)).is_empty() { Space::new() } else {
      compose(&(v436_84),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_29))))
    };
    drop(v436_84);
    let v436_86: Space = if (&(v436_85)).is_empty() { Space::new() } else {
      compose(&(v436_85),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_81))))
    };
    drop(v436_85);
    compose(&(v405_72),&(v436_86))
  };
  drop(v405_72);
  let v405_88: Space = unite(&(v405_70),&(v405_87));
  drop(v405_70);
  drop(v405_87);
  let v405_90: Space = intersect(&(*CONSTANT_53),&(v405_4));
  let v405_104: Space = if (&(v405_90)).is_empty() { Space::new() } else {
    let v451_73: Space = if (&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_3))))
    };
    let v451_91: Space = if (&(v451_73)).is_empty() { Space::new() } else {
      compose(&(v451_73),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_5))))
    };
    drop(v451_73);
    let v451_92: Space = if (&(v451_91)).is_empty() { Space::new() } else {
      compose(&(v451_91),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_9))))
    };
    let v451_93: Space = if (&(v451_92)).is_empty() { Space::new() } else {
      compose(&(v451_92),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v451_92);
    let v451_94: Space = if (&(v451_93)).is_empty() { Space::new() } else {
      compose(&(v451_93),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v451_93);
    let v451_95: Space = if (&(v451_94)).is_empty() { Space::new() } else {
      compose(&(v451_94),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v451_94);
    let v451_96: Space = if (&(v451_95)).is_empty() { Space::new() } else {
      compose(&(v451_95),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v451_95);
    let v451_97: Space = if (&(v451_96)).is_empty() { Space::new() } else {
      compose(&(v451_96),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v451_96);
    let v451_98: Space = if (&(v451_97)).is_empty() { Space::new() } else {
      compose(&(v451_97),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v451_97);
    let v451_99: Space = if (&(v451_98)).is_empty() { Space::new() } else {
      compose(&(v451_98),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v451_98);
    let v451_100: Space = if (&(v451_99)).is_empty() { Space::new() } else {
      compose(&(v451_99),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v451_99);
    let v451_101: Space = if (&(v451_100)).is_empty() { Space::new() } else {
      compose(&(v451_100),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_27))))
    };
    drop(v451_100);
    let v451_102: Space = if (&(v451_101)).is_empty() { Space::new() } else {
      compose(&(v451_101),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_29))))
    };
    drop(v451_101);
    let v451_103: Space = if (&(v451_102)).is_empty() { Space::new() } else {
      compose(&(v451_102),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_81))))
    };
    drop(v451_102);
    compose(&(v405_90),&(v451_103))
  };
  drop(v405_90);
  let v405_105: Space = unite(&(v405_88),&(v405_104));
  drop(v405_88);
  drop(v405_104);
  let v405_107: Space = intersect(&(*CONSTANT_54),&(v405_4));
  let v405_120: Space = if (&(v405_107)).is_empty() { Space::new() } else {
    let v466_73: Space = if (&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_3))))
    };
    let v466_91: Space = if (&(v466_73)).is_empty() { Space::new() } else {
      compose(&(v466_73),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_5))))
    };
    drop(v466_73);
    let v466_108: Space = if (&(v466_91)).is_empty() { Space::new() } else {
      compose(&(v466_91),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v466_91);
    let v466_109: Space = if (&(v466_108)).is_empty() { Space::new() } else {
      compose(&(v466_108),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_11))))
    };
    let v466_110: Space = if (&(v466_109)).is_empty() { Space::new() } else {
      compose(&(v466_109),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v466_109);
    let v466_111: Space = if (&(v466_110)).is_empty() { Space::new() } else {
      compose(&(v466_110),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v466_110);
    let v466_112: Space = if (&(v466_111)).is_empty() { Space::new() } else {
      compose(&(v466_111),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v466_111);
    let v466_113: Space = if (&(v466_112)).is_empty() { Space::new() } else {
      compose(&(v466_112),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v466_112);
    let v466_114: Space = if (&(v466_113)).is_empty() { Space::new() } else {
      compose(&(v466_113),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v466_113);
    let v466_115: Space = if (&(v466_114)).is_empty() { Space::new() } else {
      compose(&(v466_114),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v466_114);
    let v466_116: Space = if (&(v466_115)).is_empty() { Space::new() } else {
      compose(&(v466_115),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v466_115);
    let v466_117: Space = if (&(v466_116)).is_empty() { Space::new() } else {
      compose(&(v466_116),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_27))))
    };
    drop(v466_116);
    let v466_118: Space = if (&(v466_117)).is_empty() { Space::new() } else {
      compose(&(v466_117),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_29))))
    };
    drop(v466_117);
    let v466_119: Space = if (&(v466_118)).is_empty() { Space::new() } else {
      compose(&(v466_118),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_81))))
    };
    drop(v466_118);
    compose(&(v405_107),&(v466_119))
  };
  drop(v405_107);
  let v405_121: Space = unite(&(v405_105),&(v405_120));
  drop(v405_105);
  drop(v405_120);
  let v405_123: Space = intersect(&(*CONSTANT_55),&(v405_4));
  let v405_135: Space = if (&(v405_123)).is_empty() { Space::new() } else {
    let v481_73: Space = if (&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_3))))
    };
    let v481_91: Space = if (&(v481_73)).is_empty() { Space::new() } else {
      compose(&(v481_73),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_5))))
    };
    drop(v481_73);
    let v481_108: Space = if (&(v481_91)).is_empty() { Space::new() } else {
      compose(&(v481_91),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v481_91);
    let v481_124: Space = if (&(v481_108)).is_empty() { Space::new() } else {
      compose(&(v481_108),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v481_108);
    let v481_125: Space = if (&(v481_124)).is_empty() { Space::new() } else {
      compose(&(v481_124),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_13))))
    };
    let v481_126: Space = if (&(v481_125)).is_empty() { Space::new() } else {
      compose(&(v481_125),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v481_125);
    let v481_127: Space = if (&(v481_126)).is_empty() { Space::new() } else {
      compose(&(v481_126),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v481_126);
    let v481_128: Space = if (&(v481_127)).is_empty() { Space::new() } else {
      compose(&(v481_127),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v481_127);
    let v481_129: Space = if (&(v481_128)).is_empty() { Space::new() } else {
      compose(&(v481_128),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v481_128);
    let v481_130: Space = if (&(v481_129)).is_empty() { Space::new() } else {
      compose(&(v481_129),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v481_129);
    let v481_131: Space = if (&(v481_130)).is_empty() { Space::new() } else {
      compose(&(v481_130),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v481_130);
    let v481_132: Space = if (&(v481_131)).is_empty() { Space::new() } else {
      compose(&(v481_131),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_27))))
    };
    drop(v481_131);
    let v481_133: Space = if (&(v481_132)).is_empty() { Space::new() } else {
      compose(&(v481_132),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_29))))
    };
    drop(v481_132);
    let v481_134: Space = if (&(v481_133)).is_empty() { Space::new() } else {
      compose(&(v481_133),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_81))))
    };
    drop(v481_133);
    compose(&(v405_123),&(v481_134))
  };
  drop(v405_123);
  let v405_136: Space = unite(&(v405_121),&(v405_135));
  drop(v405_121);
  drop(v405_135);
  let v405_138: Space = intersect(&(*CONSTANT_56),&(v405_4));
  let v405_149: Space = if (&(v405_138)).is_empty() { Space::new() } else {
    let v496_73: Space = if (&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_3))))
    };
    let v496_91: Space = if (&(v496_73)).is_empty() { Space::new() } else {
      compose(&(v496_73),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_5))))
    };
    drop(v496_73);
    let v496_108: Space = if (&(v496_91)).is_empty() { Space::new() } else {
      compose(&(v496_91),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v496_91);
    let v496_124: Space = if (&(v496_108)).is_empty() { Space::new() } else {
      compose(&(v496_108),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v496_108);
    let v496_139: Space = if (&(v496_124)).is_empty() { Space::new() } else {
      compose(&(v496_124),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v496_124);
    let v496_140: Space = if (&(v496_139)).is_empty() { Space::new() } else {
      compose(&(v496_139),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_15))))
    };
    let v496_141: Space = if (&(v496_140)).is_empty() { Space::new() } else {
      compose(&(v496_140),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v496_140);
    let v496_142: Space = if (&(v496_141)).is_empty() { Space::new() } else {
      compose(&(v496_141),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v496_141);
    let v496_143: Space = if (&(v496_142)).is_empty() { Space::new() } else {
      compose(&(v496_142),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v496_142);
    let v496_144: Space = if (&(v496_143)).is_empty() { Space::new() } else {
      compose(&(v496_143),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v496_143);
    let v496_145: Space = if (&(v496_144)).is_empty() { Space::new() } else {
      compose(&(v496_144),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v496_144);
    let v496_146: Space = if (&(v496_145)).is_empty() { Space::new() } else {
      compose(&(v496_145),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_27))))
    };
    drop(v496_145);
    let v496_147: Space = if (&(v496_146)).is_empty() { Space::new() } else {
      compose(&(v496_146),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_29))))
    };
    drop(v496_146);
    let v496_148: Space = if (&(v496_147)).is_empty() { Space::new() } else {
      compose(&(v496_147),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_81))))
    };
    drop(v496_147);
    compose(&(v405_138),&(v496_148))
  };
  drop(v405_138);
  let v405_150: Space = unite(&(v405_136),&(v405_149));
  drop(v405_136);
  drop(v405_149);
  let v405_152: Space = intersect(&(*CONSTANT_57),&(v405_4));
  let v405_162: Space = if (&(v405_152)).is_empty() { Space::new() } else {
    let v511_73: Space = if (&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_3))))
    };
    let v511_91: Space = if (&(v511_73)).is_empty() { Space::new() } else {
      compose(&(v511_73),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_5))))
    };
    drop(v511_73);
    let v511_108: Space = if (&(v511_91)).is_empty() { Space::new() } else {
      compose(&(v511_91),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v511_91);
    let v511_124: Space = if (&(v511_108)).is_empty() { Space::new() } else {
      compose(&(v511_108),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v511_108);
    let v511_139: Space = if (&(v511_124)).is_empty() { Space::new() } else {
      compose(&(v511_124),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v511_124);
    let v511_153: Space = if (&(v511_139)).is_empty() { Space::new() } else {
      compose(&(v511_139),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v511_139);
    let v511_154: Space = if (&(v511_153)).is_empty() { Space::new() } else {
      compose(&(v511_153),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_17))))
    };
    let v511_155: Space = if (&(v511_154)).is_empty() { Space::new() } else {
      compose(&(v511_154),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v511_154);
    let v511_156: Space = if (&(v511_155)).is_empty() { Space::new() } else {
      compose(&(v511_155),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v511_155);
    let v511_157: Space = if (&(v511_156)).is_empty() { Space::new() } else {
      compose(&(v511_156),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v511_156);
    let v511_158: Space = if (&(v511_157)).is_empty() { Space::new() } else {
      compose(&(v511_157),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v511_157);
    let v511_159: Space = if (&(v511_158)).is_empty() { Space::new() } else {
      compose(&(v511_158),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_27))))
    };
    drop(v511_158);
    let v511_160: Space = if (&(v511_159)).is_empty() { Space::new() } else {
      compose(&(v511_159),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_29))))
    };
    drop(v511_159);
    let v511_161: Space = if (&(v511_160)).is_empty() { Space::new() } else {
      compose(&(v511_160),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_81))))
    };
    drop(v511_160);
    compose(&(v405_152),&(v511_161))
  };
  drop(v405_152);
  let v405_163: Space = unite(&(v405_150),&(v405_162));
  drop(v405_150);
  drop(v405_162);
  let v405_165: Space = intersect(&(*CONSTANT_58),&(v405_4));
  let v405_174: Space = if (&(v405_165)).is_empty() { Space::new() } else {
    let v526_73: Space = if (&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_3))))
    };
    let v526_91: Space = if (&(v526_73)).is_empty() { Space::new() } else {
      compose(&(v526_73),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_5))))
    };
    drop(v526_73);
    let v526_108: Space = if (&(v526_91)).is_empty() { Space::new() } else {
      compose(&(v526_91),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v526_91);
    let v526_124: Space = if (&(v526_108)).is_empty() { Space::new() } else {
      compose(&(v526_108),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v526_108);
    let v526_139: Space = if (&(v526_124)).is_empty() { Space::new() } else {
      compose(&(v526_124),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v526_124);
    let v526_153: Space = if (&(v526_139)).is_empty() { Space::new() } else {
      compose(&(v526_139),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v526_139);
    let v526_166: Space = if (&(v526_153)).is_empty() { Space::new() } else {
      compose(&(v526_153),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v526_153);
    let v526_167: Space = if (&(v526_166)).is_empty() { Space::new() } else {
      compose(&(v526_166),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_19))))
    };
    let v526_168: Space = if (&(v526_167)).is_empty() { Space::new() } else {
      compose(&(v526_167),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v526_167);
    let v526_169: Space = if (&(v526_168)).is_empty() { Space::new() } else {
      compose(&(v526_168),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v526_168);
    let v526_170: Space = if (&(v526_169)).is_empty() { Space::new() } else {
      compose(&(v526_169),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v526_169);
    let v526_171: Space = if (&(v526_170)).is_empty() { Space::new() } else {
      compose(&(v526_170),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_27))))
    };
    drop(v526_170);
    let v526_172: Space = if (&(v526_171)).is_empty() { Space::new() } else {
      compose(&(v526_171),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_29))))
    };
    drop(v526_171);
    let v526_173: Space = if (&(v526_172)).is_empty() { Space::new() } else {
      compose(&(v526_172),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_81))))
    };
    drop(v526_172);
    compose(&(v405_165),&(v526_173))
  };
  drop(v405_165);
  let v405_175: Space = unite(&(v405_163),&(v405_174));
  drop(v405_163);
  drop(v405_174);
  let v405_177: Space = intersect(&(*CONSTANT_59),&(v405_4));
  let v405_185: Space = if (&(v405_177)).is_empty() { Space::new() } else {
    let v541_73: Space = if (&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_3))))
    };
    let v541_91: Space = if (&(v541_73)).is_empty() { Space::new() } else {
      compose(&(v541_73),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_5))))
    };
    drop(v541_73);
    let v541_108: Space = if (&(v541_91)).is_empty() { Space::new() } else {
      compose(&(v541_91),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v541_91);
    let v541_124: Space = if (&(v541_108)).is_empty() { Space::new() } else {
      compose(&(v541_108),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v541_108);
    let v541_139: Space = if (&(v541_124)).is_empty() { Space::new() } else {
      compose(&(v541_124),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v541_124);
    let v541_153: Space = if (&(v541_139)).is_empty() { Space::new() } else {
      compose(&(v541_139),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v541_139);
    let v541_166: Space = if (&(v541_153)).is_empty() { Space::new() } else {
      compose(&(v541_153),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v541_153);
    let v541_178: Space = if (&(v541_166)).is_empty() { Space::new() } else {
      compose(&(v541_166),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v541_166);
    let v541_179: Space = if (&(v541_178)).is_empty() { Space::new() } else {
      compose(&(v541_178),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_21))))
    };
    let v541_180: Space = if (&(v541_179)).is_empty() { Space::new() } else {
      compose(&(v541_179),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v541_179);
    let v541_181: Space = if (&(v541_180)).is_empty() { Space::new() } else {
      compose(&(v541_180),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v541_180);
    let v541_182: Space = if (&(v541_181)).is_empty() { Space::new() } else {
      compose(&(v541_181),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_27))))
    };
    drop(v541_181);
    let v541_183: Space = if (&(v541_182)).is_empty() { Space::new() } else {
      compose(&(v541_182),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_29))))
    };
    drop(v541_182);
    let v541_184: Space = if (&(v541_183)).is_empty() { Space::new() } else {
      compose(&(v541_183),&(descend_cursor((*capture_1).read_zipper(),&(*CONSTANT_81))))
    };
    drop(v541_183);
    compose(&(v405_177),&(v541_184))
  };
  drop(v405_177);

((v405_175).clone(),(v405_185).clone(),(v405_4).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let v0_3: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
  let v0_6: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
  let v0_7: Space = unite(&(v0_3),&(v0_6));
  let v0_10: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
  let v0_11: Space = unite(&(v0_7),&(v0_10));
  let v0_14: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
  let v0_15: Space = unite(&(v0_11),&(v0_14));
  let v0_18: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_9), &((*CONSTANT_10).read_zipper()));
  let v0_19: Space = unite(&(v0_15),&(v0_18));
  let v0_22: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_11), &((*CONSTANT_12).read_zipper()));
  let v0_23: Space = unite(&(v0_19),&(v0_22));
  let v0_26: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_13), &((*CONSTANT_14).read_zipper()));
  let v0_27: Space = unite(&(v0_23),&(v0_26));
  let v0_30: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_15), &((*CONSTANT_16).read_zipper()));
  let v0_31: Space = unite(&(v0_27),&(v0_30));
  let v0_34: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_17), &((*CONSTANT_18).read_zipper()));
  let v0_35: Space = unite(&(v0_31),&(v0_34));
  let v0_38: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_19), &((*CONSTANT_20).read_zipper()));
  let v0_39: Space = unite(&(v0_35),&(v0_38));
  let v0_42: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_21), &((*CONSTANT_22).read_zipper()));
  let v0_43: Space = unite(&(v0_39),&(v0_42));
  let v0_46: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_23), &((*CONSTANT_24).read_zipper()));
  let v0_47: Space = unite(&(v0_43),&(v0_46));
  let v0_50: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_25), &((*CONSTANT_26).read_zipper()));
  let v0_51: Space = unite(&(v0_47),&(v0_50));
  let v0_54: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_27), &((*CONSTANT_28).read_zipper()));
  let v0_55: Space = unite(&(v0_51),&(v0_54));
  let v0_58: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_29), &((*CONSTANT_30).read_zipper()));
  let v0_59: Space = unite(&(v0_55),&(v0_58));
  let v0_62: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_1), &((*CONSTANT_32).read_zipper()));
  let v0_63: Space = unite(&(v0_59),&(v0_62));
  let v0_65: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_3), &((*CONSTANT_33).read_zipper()));
  let v0_66: Space = unite(&(v0_63),&(v0_65));
  let v0_68: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_5), &((*CONSTANT_34).read_zipper()));
  let v0_69: Space = unite(&(v0_66),&(v0_68));
  let v0_71: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_7), &((*CONSTANT_35).read_zipper()));
  let v0_72: Space = unite(&(v0_69),&(v0_71));
  let v0_74: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_9), &((*CONSTANT_36).read_zipper()));
  let v0_75: Space = unite(&(v0_72),&(v0_74));
  let v0_77: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_11), &((*CONSTANT_37).read_zipper()));
  let v0_78: Space = unite(&(v0_75),&(v0_77));
  let v0_80: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_13), &((*CONSTANT_38).read_zipper()));
  let v0_81: Space = unite(&(v0_78),&(v0_80));
  let v0_83: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_15), &((*CONSTANT_39).read_zipper()));
  let v0_84: Space = unite(&(v0_81),&(v0_83));
  let v0_86: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_17), &((*CONSTANT_40).read_zipper()));
  let v0_87: Space = unite(&(v0_84),&(v0_86));
  let v0_89: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_19), &((*CONSTANT_41).read_zipper()));
  let v0_90: Space = unite(&(v0_87),&(v0_89));
  let v0_92: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_21), &((*CONSTANT_42).read_zipper()));
  let v0_93: Space = unite(&(v0_90),&(v0_92));
  let v0_95: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_23), &((*CONSTANT_43).read_zipper()));
  let v0_96: Space = unite(&(v0_93),&(v0_95));
  let v0_98: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_25), &((*CONSTANT_44).read_zipper()));
  let v0_99: Space = unite(&(v0_96),&(v0_98));
  let v0_101: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_27), &((*CONSTANT_45).read_zipper()));
  let v0_102: Space = unite(&(v0_99),&(v0_101));
  let v0_104: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_29), &((*CONSTANT_46).read_zipper()));
  let v0_105: Space = unite(&(v0_102),&(v0_104));
  let v0_108: Space = routine_1(c, &(*CONSTANT_47), &(*CONSTANT_1), &((*CONSTANT_48).read_zipper()));
  let v0_109: Space = unite(&(v0_105),&(v0_108));
  let v0_111: Space = routine_1(c, &(*CONSTANT_47), &(*CONSTANT_3), &((*CONSTANT_48).read_zipper()));
  let v0_112: Space = unite(&(v0_109),&(v0_111));
  let v0_114: Space = routine_1(c, &(*CONSTANT_47), &(*CONSTANT_9), &((*CONSTANT_49).read_zipper()));
  let v0_115: Space = unite(&(v0_112),&(v0_114));
  (v0_115).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1_3 = Space::new();
  let mut v1_3_write = v1_3.write_zipper();
  let mut v1_3_cursor = (*s0).read_zipper();
  let v1_3_origin = v1_3_cursor.path().len();
  for v1_3_byte in v1_3_cursor.child_mask().iter() {
    v1_3_cursor.descend_to_existing_byte(v1_3_byte);
    {
    for v2_2_byte in v1_3_cursor.child_mask().iter() {
      v1_3_cursor.descend_to_existing_byte(v2_2_byte);
      {
      for v3_3_byte in v1_3_cursor.child_mask().iter() {
        v1_3_cursor.descend_to_existing_byte(v3_3_byte);
        {
        for v4_3_byte in v1_3_cursor.child_mask().iter() {
          v1_3_cursor.descend_to_existing_byte(v4_3_byte);
          {
          for v5_3_byte in v1_3_cursor.child_mask().iter() {
            v1_3_cursor.descend_to_existing_byte(v5_3_byte);
            {
            for v6_2_byte in v1_3_cursor.child_mask().iter() {
              v1_3_cursor.descend_to_existing_byte(v6_2_byte);
              {
              for v7_3_byte in v1_3_cursor.child_mask().iter() {
                v1_3_cursor.descend_to_existing_byte(v7_3_byte);
                {
                for v8_3_byte in v1_3_cursor.child_mask().iter() {
                  v1_3_cursor.descend_to_existing_byte(v8_3_byte);
                  {
                  let v9_3: Space = routine_2(c, &v1_3_cursor.path()[(v1_3_origin + 4)..(v1_3_origin + 8)], &(*p1), &(*p0), &v1_3_cursor.path()[v1_3_origin..(v1_3_origin + 4)], &v1_3_cursor);
                  join_wrapped_into(&mut v1_3_write,&((v9_3).read_zipper()),&[]);
                  }
                  v1_3_cursor.ascend(1);
                }
                }
                v1_3_cursor.ascend(1);
              }
              }
              v1_3_cursor.ascend(1);
            }
            }
            v1_3_cursor.ascend(1);
          }
          }
          v1_3_cursor.ascend(1);
        }
        }
        v1_3_cursor.ascend(1);
      }
      }
      v1_3_cursor.ascend(1);
    }
    }
    v1_3_cursor.ascend(1);
  }
  drop(v1_3_cursor);
  drop(v1_3_write);
  (v1_3).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v10_5 = Space::new();
  let mut v10_5_write = v10_5.write_zipper();
  let mut v10_5_cursor = (*s0).read_zipper();
  let v10_5_origin = v10_5_cursor.path().len();
  for v10_5_byte in v10_5_cursor.child_mask().iter() {
    v10_5_cursor.descend_to_existing_byte(v10_5_byte);
    {
    for v11_2_byte in v10_5_cursor.child_mask().iter() {
      v10_5_cursor.descend_to_existing_byte(v11_2_byte);
      {
      for v12_3_byte in v10_5_cursor.child_mask().iter() {
        v10_5_cursor.descend_to_existing_byte(v12_3_byte);
        {
        for v13_3_byte in v10_5_cursor.child_mask().iter() {
          v10_5_cursor.descend_to_existing_byte(v13_3_byte);
          {
          for v14_3_byte in v10_5_cursor.child_mask().iter() {
            v10_5_cursor.descend_to_existing_byte(v14_3_byte);
            {
            for v15_2_byte in v10_5_cursor.child_mask().iter() {
              v10_5_cursor.descend_to_existing_byte(v15_2_byte);
              {
              for v16_3_byte in v10_5_cursor.child_mask().iter() {
                v10_5_cursor.descend_to_existing_byte(v16_3_byte);
                {
                for v17_3_byte in v10_5_cursor.child_mask().iter() {
                  v10_5_cursor.descend_to_existing_byte(v17_3_byte);
                  {
                  let v18_3: Space = routine_3(c, &v10_5_cursor.path()[(v10_5_origin + 4)..(v10_5_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p0), &v10_5_cursor.path()[v10_5_origin..(v10_5_origin + 4)], &v10_5_cursor);
                  join_wrapped_into(&mut v10_5_write,&((v18_3).read_zipper()),&[]);
                  }
                  v10_5_cursor.ascend(1);
                }
                }
                v10_5_cursor.ascend(1);
              }
              }
              v10_5_cursor.ascend(1);
            }
            }
            v10_5_cursor.ascend(1);
          }
          }
          v10_5_cursor.ascend(1);
        }
        }
        v10_5_cursor.ascend(1);
      }
      }
      v10_5_cursor.ascend(1);
    }
    }
    v10_5_cursor.ascend(1);
  }
  drop(v10_5_cursor);
  drop(v10_5_write);
  (v10_5).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v19_7 = Space::new();
  let mut v19_7_write = v19_7.write_zipper();
  let mut v19_7_cursor = (*s0).read_zipper();
  let v19_7_origin = v19_7_cursor.path().len();
  for v19_7_byte in v19_7_cursor.child_mask().iter() {
    v19_7_cursor.descend_to_existing_byte(v19_7_byte);
    {
    for v20_2_byte in v19_7_cursor.child_mask().iter() {
      v19_7_cursor.descend_to_existing_byte(v20_2_byte);
      {
      for v21_3_byte in v19_7_cursor.child_mask().iter() {
        v19_7_cursor.descend_to_existing_byte(v21_3_byte);
        {
        for v22_3_byte in v19_7_cursor.child_mask().iter() {
          v19_7_cursor.descend_to_existing_byte(v22_3_byte);
          {
          for v23_3_byte in v19_7_cursor.child_mask().iter() {
            v19_7_cursor.descend_to_existing_byte(v23_3_byte);
            {
            for v24_2_byte in v19_7_cursor.child_mask().iter() {
              v19_7_cursor.descend_to_existing_byte(v24_2_byte);
              {
              for v25_3_byte in v19_7_cursor.child_mask().iter() {
                v19_7_cursor.descend_to_existing_byte(v25_3_byte);
                {
                for v26_3_byte in v19_7_cursor.child_mask().iter() {
                  v19_7_cursor.descend_to_existing_byte(v26_3_byte);
                  {
                  let v27_3: Space = routine_4(c, &v19_7_cursor.path()[(v19_7_origin + 4)..(v19_7_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v19_7_cursor.path()[v19_7_origin..(v19_7_origin + 4)], &v19_7_cursor);
                  join_wrapped_into(&mut v19_7_write,&((v27_3).read_zipper()),&[]);
                  }
                  v19_7_cursor.ascend(1);
                }
                }
                v19_7_cursor.ascend(1);
              }
              }
              v19_7_cursor.ascend(1);
            }
            }
            v19_7_cursor.ascend(1);
          }
          }
          v19_7_cursor.ascend(1);
        }
        }
        v19_7_cursor.ascend(1);
      }
      }
      v19_7_cursor.ascend(1);
    }
    }
    v19_7_cursor.ascend(1);
  }
  drop(v19_7_cursor);
  drop(v19_7_write);
  (v19_7).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v28_9 = Space::new();
  let mut v28_9_write = v28_9.write_zipper();
  let mut v28_9_cursor = (*s0).read_zipper();
  let v28_9_origin = v28_9_cursor.path().len();
  for v28_9_byte in v28_9_cursor.child_mask().iter() {
    v28_9_cursor.descend_to_existing_byte(v28_9_byte);
    {
    for v29_2_byte in v28_9_cursor.child_mask().iter() {
      v28_9_cursor.descend_to_existing_byte(v29_2_byte);
      {
      for v30_3_byte in v28_9_cursor.child_mask().iter() {
        v28_9_cursor.descend_to_existing_byte(v30_3_byte);
        {
        for v31_3_byte in v28_9_cursor.child_mask().iter() {
          v28_9_cursor.descend_to_existing_byte(v31_3_byte);
          {
          for v32_3_byte in v28_9_cursor.child_mask().iter() {
            v28_9_cursor.descend_to_existing_byte(v32_3_byte);
            {
            for v33_2_byte in v28_9_cursor.child_mask().iter() {
              v28_9_cursor.descend_to_existing_byte(v33_2_byte);
              {
              for v34_3_byte in v28_9_cursor.child_mask().iter() {
                v28_9_cursor.descend_to_existing_byte(v34_3_byte);
                {
                for v35_3_byte in v28_9_cursor.child_mask().iter() {
                  v28_9_cursor.descend_to_existing_byte(v35_3_byte);
                  {
                  let v36_3: Space = routine_5(c, &v28_9_cursor.path()[(v28_9_origin + 4)..(v28_9_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p0), &v28_9_cursor.path()[v28_9_origin..(v28_9_origin + 4)], &v28_9_cursor);
                  join_wrapped_into(&mut v28_9_write,&((v36_3).read_zipper()),&[]);
                  }
                  v28_9_cursor.ascend(1);
                }
                }
                v28_9_cursor.ascend(1);
              }
              }
              v28_9_cursor.ascend(1);
            }
            }
            v28_9_cursor.ascend(1);
          }
          }
          v28_9_cursor.ascend(1);
        }
        }
        v28_9_cursor.ascend(1);
      }
      }
      v28_9_cursor.ascend(1);
    }
    }
    v28_9_cursor.ascend(1);
  }
  drop(v28_9_cursor);
  drop(v28_9_write);
  (v28_9).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v37_11 = Space::new();
  let mut v37_11_write = v37_11.write_zipper();
  let mut v37_11_cursor = (*s0).read_zipper();
  let v37_11_origin = v37_11_cursor.path().len();
  for v37_11_byte in v37_11_cursor.child_mask().iter() {
    v37_11_cursor.descend_to_existing_byte(v37_11_byte);
    {
    for v38_2_byte in v37_11_cursor.child_mask().iter() {
      v37_11_cursor.descend_to_existing_byte(v38_2_byte);
      {
      for v39_3_byte in v37_11_cursor.child_mask().iter() {
        v37_11_cursor.descend_to_existing_byte(v39_3_byte);
        {
        for v40_3_byte in v37_11_cursor.child_mask().iter() {
          v37_11_cursor.descend_to_existing_byte(v40_3_byte);
          {
          for v41_3_byte in v37_11_cursor.child_mask().iter() {
            v37_11_cursor.descend_to_existing_byte(v41_3_byte);
            {
            for v42_2_byte in v37_11_cursor.child_mask().iter() {
              v37_11_cursor.descend_to_existing_byte(v42_2_byte);
              {
              for v43_3_byte in v37_11_cursor.child_mask().iter() {
                v37_11_cursor.descend_to_existing_byte(v43_3_byte);
                {
                for v44_3_byte in v37_11_cursor.child_mask().iter() {
                  v37_11_cursor.descend_to_existing_byte(v44_3_byte);
                  {
                  let v45_3: Space = routine_6(c, &v37_11_cursor.path()[(v37_11_origin + 4)..(v37_11_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p0), &v37_11_cursor.path()[v37_11_origin..(v37_11_origin + 4)], &v37_11_cursor);
                  join_wrapped_into(&mut v37_11_write,&((v45_3).read_zipper()),&[]);
                  }
                  v37_11_cursor.ascend(1);
                }
                }
                v37_11_cursor.ascend(1);
              }
              }
              v37_11_cursor.ascend(1);
            }
            }
            v37_11_cursor.ascend(1);
          }
          }
          v37_11_cursor.ascend(1);
        }
        }
        v37_11_cursor.ascend(1);
      }
      }
      v37_11_cursor.ascend(1);
    }
    }
    v37_11_cursor.ascend(1);
  }
  drop(v37_11_cursor);
  drop(v37_11_write);
  (v37_11).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v46_13 = Space::new();
  let mut v46_13_write = v46_13.write_zipper();
  let mut v46_13_cursor = (*s0).read_zipper();
  let v46_13_origin = v46_13_cursor.path().len();
  for v46_13_byte in v46_13_cursor.child_mask().iter() {
    v46_13_cursor.descend_to_existing_byte(v46_13_byte);
    {
    for v47_2_byte in v46_13_cursor.child_mask().iter() {
      v46_13_cursor.descend_to_existing_byte(v47_2_byte);
      {
      for v48_3_byte in v46_13_cursor.child_mask().iter() {
        v46_13_cursor.descend_to_existing_byte(v48_3_byte);
        {
        for v49_3_byte in v46_13_cursor.child_mask().iter() {
          v46_13_cursor.descend_to_existing_byte(v49_3_byte);
          {
          for v50_3_byte in v46_13_cursor.child_mask().iter() {
            v46_13_cursor.descend_to_existing_byte(v50_3_byte);
            {
            for v51_2_byte in v46_13_cursor.child_mask().iter() {
              v46_13_cursor.descend_to_existing_byte(v51_2_byte);
              {
              for v52_3_byte in v46_13_cursor.child_mask().iter() {
                v46_13_cursor.descend_to_existing_byte(v52_3_byte);
                {
                for v53_3_byte in v46_13_cursor.child_mask().iter() {
                  v46_13_cursor.descend_to_existing_byte(v53_3_byte);
                  {
                  let v54_3: Space = routine_7(c, &v46_13_cursor.path()[(v46_13_origin + 4)..(v46_13_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p0), &v46_13_cursor.path()[v46_13_origin..(v46_13_origin + 4)], &v46_13_cursor);
                  join_wrapped_into(&mut v46_13_write,&((v54_3).read_zipper()),&[]);
                  }
                  v46_13_cursor.ascend(1);
                }
                }
                v46_13_cursor.ascend(1);
              }
              }
              v46_13_cursor.ascend(1);
            }
            }
            v46_13_cursor.ascend(1);
          }
          }
          v46_13_cursor.ascend(1);
        }
        }
        v46_13_cursor.ascend(1);
      }
      }
      v46_13_cursor.ascend(1);
    }
    }
    v46_13_cursor.ascend(1);
  }
  drop(v46_13_cursor);
  drop(v46_13_write);
  (v46_13).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], p13: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v55_15 = Space::new();
  let mut v55_15_write = v55_15.write_zipper();
  let mut v55_15_cursor = (*s0).read_zipper();
  let v55_15_origin = v55_15_cursor.path().len();
  for v55_15_byte in v55_15_cursor.child_mask().iter() {
    v55_15_cursor.descend_to_existing_byte(v55_15_byte);
    {
    for v56_2_byte in v55_15_cursor.child_mask().iter() {
      v55_15_cursor.descend_to_existing_byte(v56_2_byte);
      {
      for v57_3_byte in v55_15_cursor.child_mask().iter() {
        v55_15_cursor.descend_to_existing_byte(v57_3_byte);
        {
        for v58_3_byte in v55_15_cursor.child_mask().iter() {
          v55_15_cursor.descend_to_existing_byte(v58_3_byte);
          {
          for v59_3_byte in v55_15_cursor.child_mask().iter() {
            v55_15_cursor.descend_to_existing_byte(v59_3_byte);
            {
            for v60_2_byte in v55_15_cursor.child_mask().iter() {
              v55_15_cursor.descend_to_existing_byte(v60_2_byte);
              {
              for v61_3_byte in v55_15_cursor.child_mask().iter() {
                v55_15_cursor.descend_to_existing_byte(v61_3_byte);
                {
                for v62_3_byte in v55_15_cursor.child_mask().iter() {
                  v55_15_cursor.descend_to_existing_byte(v62_3_byte);
                  {
                  let v63_3: Space = routine_8(c, &v55_15_cursor.path()[(v55_15_origin + 4)..(v55_15_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p13), &(*p0), &v55_15_cursor.path()[v55_15_origin..(v55_15_origin + 4)], &v55_15_cursor);
                  join_wrapped_into(&mut v55_15_write,&((v63_3).read_zipper()),&[]);
                  }
                  v55_15_cursor.ascend(1);
                }
                }
                v55_15_cursor.ascend(1);
              }
              }
              v55_15_cursor.ascend(1);
            }
            }
            v55_15_cursor.ascend(1);
          }
          }
          v55_15_cursor.ascend(1);
        }
        }
        v55_15_cursor.ascend(1);
      }
      }
      v55_15_cursor.ascend(1);
    }
    }
    v55_15_cursor.ascend(1);
  }
  drop(v55_15_cursor);
  drop(v55_15_write);
  (v55_15).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], p13: &[u8], p14: &[u8], p15: &[u8], s0: &View<'_, '_>) -> Space {
  let (mut v64_18,mut v64_20,mut v64_37,mut v64_40,mut v64_42,mut v64_43,mut v64_46,mut v64_48,mut v64_49,mut v64_52,mut v64_54,mut v64_55,mut v64_58,mut v64_60,mut v64_61,mut v64_64,mut v64_66,mut v64_67,mut v64_70,mut v64_72,mut v64_73,mut v64_76,mut v64_78,mut v64_79,mut v64_82,mut v64_84,) = native_block_0(c, p0, p1, p10, p11, p12, p13, p14, p15, p2, p3, p4, p5, p6, p7, p8, p9);
  let (mut v64_100,mut v64_102,mut v64_103,mut v64_106,mut v64_108,mut v64_109,mut v64_112,mut v64_114,mut v64_115,mut v64_118,mut v64_120,mut v64_121,mut v64_124,mut v64_126,mut v64_127,mut v64_160,mut v64_177,mut v64_85,mut v64_88,mut v64_90,mut v64_91,mut v64_94,mut v64_96,mut v64_97,) = native_block_1(c, p0, p1, p10, p11, p12, p13, p14, p15, p2, p3, p4, p5, p6, p7, p8, p9, &v64_18, &v64_79, &v64_84);
  drop(v64_18);
  (v64_177).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v226_2 = Space::new();
  let mut v226_2_write = v226_2.write_zipper();
  let mut v226_2_cursor = (*s0).read_zipper();
  let v226_2_origin = v226_2_cursor.path().len();
  for v226_2_byte in v226_2_cursor.child_mask().iter() {
    v226_2_cursor.descend_to_existing_byte(v226_2_byte);
    {
    for v227_2_byte in v226_2_cursor.child_mask().iter() {
      v226_2_cursor.descend_to_existing_byte(v227_2_byte);
      {
      for v228_3_byte in v226_2_cursor.child_mask().iter() {
        v226_2_cursor.descend_to_existing_byte(v228_3_byte);
        {
        for v229_3_byte in v226_2_cursor.child_mask().iter() {
          v226_2_cursor.descend_to_existing_byte(v229_3_byte);
          {
          for v230_3_byte in v226_2_cursor.child_mask().iter() {
            v226_2_cursor.descend_to_existing_byte(v230_3_byte);
            {
            for v231_2_byte in v226_2_cursor.child_mask().iter() {
              v226_2_cursor.descend_to_existing_byte(v231_2_byte);
              {
              for v232_3_byte in v226_2_cursor.child_mask().iter() {
                v226_2_cursor.descend_to_existing_byte(v232_3_byte);
                {
                for v233_3_byte in v226_2_cursor.child_mask().iter() {
                  v226_2_cursor.descend_to_existing_byte(v233_3_byte);
                  {
                  let v234_3: Space = routine_45(c, &v226_2_cursor.path()[(v226_2_origin + 4)..(v226_2_origin + 8)], &(*p0), &v226_2_cursor.path()[v226_2_origin..(v226_2_origin + 4)], &v226_2_cursor);
                  join_wrapped_into(&mut v226_2_write,&((v234_3).read_zipper()),&[]);
                  }
                  v226_2_cursor.ascend(1);
                }
                }
                v226_2_cursor.ascend(1);
              }
              }
              v226_2_cursor.ascend(1);
            }
            }
            v226_2_cursor.ascend(1);
          }
          }
          v226_2_cursor.ascend(1);
        }
        }
        v226_2_cursor.ascend(1);
      }
      }
      v226_2_cursor.ascend(1);
    }
    }
    v226_2_cursor.ascend(1);
  }
  drop(v226_2_cursor);
  drop(v226_2_write);
  (v226_2).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_12(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v236_2 = Space::new();
  let mut v236_2_write = v236_2.write_zipper();
  let mut v236_2_cursor = (*s0).read_zipper();
  let v236_2_origin = v236_2_cursor.path().len();
  for v236_2_byte in v236_2_cursor.child_mask().iter() {
    v236_2_cursor.descend_to_existing_byte(v236_2_byte);
    {
    for v237_2_byte in v236_2_cursor.child_mask().iter() {
      v236_2_cursor.descend_to_existing_byte(v237_2_byte);
      {
      for v238_3_byte in v236_2_cursor.child_mask().iter() {
        v236_2_cursor.descend_to_existing_byte(v238_3_byte);
        {
        for v239_3_byte in v236_2_cursor.child_mask().iter() {
          v236_2_cursor.descend_to_existing_byte(v239_3_byte);
          {
          for v240_3_byte in v236_2_cursor.child_mask().iter() {
            v236_2_cursor.descend_to_existing_byte(v240_3_byte);
            {
            for v241_2_byte in v236_2_cursor.child_mask().iter() {
              v236_2_cursor.descend_to_existing_byte(v241_2_byte);
              {
              for v242_3_byte in v236_2_cursor.child_mask().iter() {
                v236_2_cursor.descend_to_existing_byte(v242_3_byte);
                {
                for v243_3_byte in v236_2_cursor.child_mask().iter() {
                  v236_2_cursor.descend_to_existing_byte(v243_3_byte);
                  {
                  let v244_3: Space = routine_46(c, &v236_2_cursor.path()[(v236_2_origin + 4)..(v236_2_origin + 8)], &(*p0), &v236_2_cursor.path()[v236_2_origin..(v236_2_origin + 4)], &v236_2_cursor);
                  join_wrapped_into(&mut v236_2_write,&((v244_3).read_zipper()),&[]);
                  }
                  v236_2_cursor.ascend(1);
                }
                }
                v236_2_cursor.ascend(1);
              }
              }
              v236_2_cursor.ascend(1);
            }
            }
            v236_2_cursor.ascend(1);
          }
          }
          v236_2_cursor.ascend(1);
        }
        }
        v236_2_cursor.ascend(1);
      }
      }
      v236_2_cursor.ascend(1);
    }
    }
    v236_2_cursor.ascend(1);
  }
  drop(v236_2_cursor);
  drop(v236_2_write);
  (v236_2).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_14(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v246_2 = Space::new();
  let mut v246_2_write = v246_2.write_zipper();
  let mut v246_2_cursor = (*s0).read_zipper();
  let v246_2_origin = v246_2_cursor.path().len();
  for v246_2_byte in v246_2_cursor.child_mask().iter() {
    v246_2_cursor.descend_to_existing_byte(v246_2_byte);
    {
    for v247_2_byte in v246_2_cursor.child_mask().iter() {
      v246_2_cursor.descend_to_existing_byte(v247_2_byte);
      {
      for v248_3_byte in v246_2_cursor.child_mask().iter() {
        v246_2_cursor.descend_to_existing_byte(v248_3_byte);
        {
        for v249_3_byte in v246_2_cursor.child_mask().iter() {
          v246_2_cursor.descend_to_existing_byte(v249_3_byte);
          {
          for v250_3_byte in v246_2_cursor.child_mask().iter() {
            v246_2_cursor.descend_to_existing_byte(v250_3_byte);
            {
            for v251_2_byte in v246_2_cursor.child_mask().iter() {
              v246_2_cursor.descend_to_existing_byte(v251_2_byte);
              {
              for v252_3_byte in v246_2_cursor.child_mask().iter() {
                v246_2_cursor.descend_to_existing_byte(v252_3_byte);
                {
                for v253_3_byte in v246_2_cursor.child_mask().iter() {
                  v246_2_cursor.descend_to_existing_byte(v253_3_byte);
                  {
                  let v254_3: Space = routine_47(c, &v246_2_cursor.path()[(v246_2_origin + 4)..(v246_2_origin + 8)], &(*p0), &v246_2_cursor.path()[v246_2_origin..(v246_2_origin + 4)], &v246_2_cursor);
                  join_wrapped_into(&mut v246_2_write,&((v254_3).read_zipper()),&[]);
                  }
                  v246_2_cursor.ascend(1);
                }
                }
                v246_2_cursor.ascend(1);
              }
              }
              v246_2_cursor.ascend(1);
            }
            }
            v246_2_cursor.ascend(1);
          }
          }
          v246_2_cursor.ascend(1);
        }
        }
        v246_2_cursor.ascend(1);
      }
      }
      v246_2_cursor.ascend(1);
    }
    }
    v246_2_cursor.ascend(1);
  }
  drop(v246_2_cursor);
  drop(v246_2_write);
  (v246_2).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_16(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v256_2 = Space::new();
  let mut v256_2_write = v256_2.write_zipper();
  let mut v256_2_cursor = (*s0).read_zipper();
  let v256_2_origin = v256_2_cursor.path().len();
  for v256_2_byte in v256_2_cursor.child_mask().iter() {
    v256_2_cursor.descend_to_existing_byte(v256_2_byte);
    {
    for v257_2_byte in v256_2_cursor.child_mask().iter() {
      v256_2_cursor.descend_to_existing_byte(v257_2_byte);
      {
      for v258_3_byte in v256_2_cursor.child_mask().iter() {
        v256_2_cursor.descend_to_existing_byte(v258_3_byte);
        {
        for v259_3_byte in v256_2_cursor.child_mask().iter() {
          v256_2_cursor.descend_to_existing_byte(v259_3_byte);
          {
          for v260_3_byte in v256_2_cursor.child_mask().iter() {
            v256_2_cursor.descend_to_existing_byte(v260_3_byte);
            {
            for v261_2_byte in v256_2_cursor.child_mask().iter() {
              v256_2_cursor.descend_to_existing_byte(v261_2_byte);
              {
              for v262_3_byte in v256_2_cursor.child_mask().iter() {
                v256_2_cursor.descend_to_existing_byte(v262_3_byte);
                {
                for v263_3_byte in v256_2_cursor.child_mask().iter() {
                  v256_2_cursor.descend_to_existing_byte(v263_3_byte);
                  {
                  let v264_3: Space = routine_48(c, &v256_2_cursor.path()[(v256_2_origin + 4)..(v256_2_origin + 8)], &(*p0), &v256_2_cursor.path()[v256_2_origin..(v256_2_origin + 4)], &v256_2_cursor);
                  join_wrapped_into(&mut v256_2_write,&((v264_3).read_zipper()),&[]);
                  }
                  v256_2_cursor.ascend(1);
                }
                }
                v256_2_cursor.ascend(1);
              }
              }
              v256_2_cursor.ascend(1);
            }
            }
            v256_2_cursor.ascend(1);
          }
          }
          v256_2_cursor.ascend(1);
        }
        }
        v256_2_cursor.ascend(1);
      }
      }
      v256_2_cursor.ascend(1);
    }
    }
    v256_2_cursor.ascend(1);
  }
  drop(v256_2_cursor);
  drop(v256_2_write);
  (v256_2).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_18(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v266_2 = Space::new();
  let mut v266_2_write = v266_2.write_zipper();
  let mut v266_2_cursor = (*s0).read_zipper();
  let v266_2_origin = v266_2_cursor.path().len();
  for v266_2_byte in v266_2_cursor.child_mask().iter() {
    v266_2_cursor.descend_to_existing_byte(v266_2_byte);
    {
    for v267_2_byte in v266_2_cursor.child_mask().iter() {
      v266_2_cursor.descend_to_existing_byte(v267_2_byte);
      {
      for v268_3_byte in v266_2_cursor.child_mask().iter() {
        v266_2_cursor.descend_to_existing_byte(v268_3_byte);
        {
        for v269_3_byte in v266_2_cursor.child_mask().iter() {
          v266_2_cursor.descend_to_existing_byte(v269_3_byte);
          {
          for v270_3_byte in v266_2_cursor.child_mask().iter() {
            v266_2_cursor.descend_to_existing_byte(v270_3_byte);
            {
            for v271_2_byte in v266_2_cursor.child_mask().iter() {
              v266_2_cursor.descend_to_existing_byte(v271_2_byte);
              {
              for v272_3_byte in v266_2_cursor.child_mask().iter() {
                v266_2_cursor.descend_to_existing_byte(v272_3_byte);
                {
                for v273_3_byte in v266_2_cursor.child_mask().iter() {
                  v266_2_cursor.descend_to_existing_byte(v273_3_byte);
                  {
                  let v274_3: Space = routine_49(c, &v266_2_cursor.path()[(v266_2_origin + 4)..(v266_2_origin + 8)], &(*p0), &v266_2_cursor.path()[v266_2_origin..(v266_2_origin + 4)], &v266_2_cursor);
                  join_wrapped_into(&mut v266_2_write,&((v274_3).read_zipper()),&[]);
                  }
                  v266_2_cursor.ascend(1);
                }
                }
                v266_2_cursor.ascend(1);
              }
              }
              v266_2_cursor.ascend(1);
            }
            }
            v266_2_cursor.ascend(1);
          }
          }
          v266_2_cursor.ascend(1);
        }
        }
        v266_2_cursor.ascend(1);
      }
      }
      v266_2_cursor.ascend(1);
    }
    }
    v266_2_cursor.ascend(1);
  }
  drop(v266_2_cursor);
  drop(v266_2_write);
  (v266_2).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v276_2 = Space::new();
  let mut v276_2_write = v276_2.write_zipper();
  let mut v276_2_cursor = (*s0).read_zipper();
  let v276_2_origin = v276_2_cursor.path().len();
  for v276_2_byte in v276_2_cursor.child_mask().iter() {
    v276_2_cursor.descend_to_existing_byte(v276_2_byte);
    {
    for v277_2_byte in v276_2_cursor.child_mask().iter() {
      v276_2_cursor.descend_to_existing_byte(v277_2_byte);
      {
      for v278_3_byte in v276_2_cursor.child_mask().iter() {
        v276_2_cursor.descend_to_existing_byte(v278_3_byte);
        {
        for v279_3_byte in v276_2_cursor.child_mask().iter() {
          v276_2_cursor.descend_to_existing_byte(v279_3_byte);
          {
          for v280_3_byte in v276_2_cursor.child_mask().iter() {
            v276_2_cursor.descend_to_existing_byte(v280_3_byte);
            {
            for v281_2_byte in v276_2_cursor.child_mask().iter() {
              v276_2_cursor.descend_to_existing_byte(v281_2_byte);
              {
              for v282_3_byte in v276_2_cursor.child_mask().iter() {
                v276_2_cursor.descend_to_existing_byte(v282_3_byte);
                {
                for v283_3_byte in v276_2_cursor.child_mask().iter() {
                  v276_2_cursor.descend_to_existing_byte(v283_3_byte);
                  {
                  let v284_3: Space = routine_50(c, &v276_2_cursor.path()[(v276_2_origin + 4)..(v276_2_origin + 8)], &(*p0), &v276_2_cursor.path()[v276_2_origin..(v276_2_origin + 4)], &v276_2_cursor);
                  join_wrapped_into(&mut v276_2_write,&((v284_3).read_zipper()),&[]);
                  }
                  v276_2_cursor.ascend(1);
                }
                }
                v276_2_cursor.ascend(1);
              }
              }
              v276_2_cursor.ascend(1);
            }
            }
            v276_2_cursor.ascend(1);
          }
          }
          v276_2_cursor.ascend(1);
        }
        }
        v276_2_cursor.ascend(1);
      }
      }
      v276_2_cursor.ascend(1);
    }
    }
    v276_2_cursor.ascend(1);
  }
  drop(v276_2_cursor);
  drop(v276_2_write);
  (v276_2).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_22(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v286_2 = Space::new();
  let mut v286_2_write = v286_2.write_zipper();
  let mut v286_2_cursor = (*s0).read_zipper();
  let v286_2_origin = v286_2_cursor.path().len();
  for v286_2_byte in v286_2_cursor.child_mask().iter() {
    v286_2_cursor.descend_to_existing_byte(v286_2_byte);
    {
    for v287_2_byte in v286_2_cursor.child_mask().iter() {
      v286_2_cursor.descend_to_existing_byte(v287_2_byte);
      {
      for v288_3_byte in v286_2_cursor.child_mask().iter() {
        v286_2_cursor.descend_to_existing_byte(v288_3_byte);
        {
        for v289_3_byte in v286_2_cursor.child_mask().iter() {
          v286_2_cursor.descend_to_existing_byte(v289_3_byte);
          {
          for v290_3_byte in v286_2_cursor.child_mask().iter() {
            v286_2_cursor.descend_to_existing_byte(v290_3_byte);
            {
            for v291_2_byte in v286_2_cursor.child_mask().iter() {
              v286_2_cursor.descend_to_existing_byte(v291_2_byte);
              {
              for v292_3_byte in v286_2_cursor.child_mask().iter() {
                v286_2_cursor.descend_to_existing_byte(v292_3_byte);
                {
                for v293_3_byte in v286_2_cursor.child_mask().iter() {
                  v286_2_cursor.descend_to_existing_byte(v293_3_byte);
                  {
                  let v294_3: Space = routine_51(c, &v286_2_cursor.path()[(v286_2_origin + 4)..(v286_2_origin + 8)], &(*p0), &v286_2_cursor.path()[v286_2_origin..(v286_2_origin + 4)], &v286_2_cursor);
                  join_wrapped_into(&mut v286_2_write,&((v294_3).read_zipper()),&[]);
                  }
                  v286_2_cursor.ascend(1);
                }
                }
                v286_2_cursor.ascend(1);
              }
              }
              v286_2_cursor.ascend(1);
            }
            }
            v286_2_cursor.ascend(1);
          }
          }
          v286_2_cursor.ascend(1);
        }
        }
        v286_2_cursor.ascend(1);
      }
      }
      v286_2_cursor.ascend(1);
    }
    }
    v286_2_cursor.ascend(1);
  }
  drop(v286_2_cursor);
  drop(v286_2_write);
  (v286_2).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_24(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v296_2 = Space::new();
  let mut v296_2_write = v296_2.write_zipper();
  let mut v296_2_cursor = (*s0).read_zipper();
  let v296_2_origin = v296_2_cursor.path().len();
  for v296_2_byte in v296_2_cursor.child_mask().iter() {
    v296_2_cursor.descend_to_existing_byte(v296_2_byte);
    {
    for v297_2_byte in v296_2_cursor.child_mask().iter() {
      v296_2_cursor.descend_to_existing_byte(v297_2_byte);
      {
      for v298_3_byte in v296_2_cursor.child_mask().iter() {
        v296_2_cursor.descend_to_existing_byte(v298_3_byte);
        {
        for v299_3_byte in v296_2_cursor.child_mask().iter() {
          v296_2_cursor.descend_to_existing_byte(v299_3_byte);
          {
          for v300_3_byte in v296_2_cursor.child_mask().iter() {
            v296_2_cursor.descend_to_existing_byte(v300_3_byte);
            {
            for v301_2_byte in v296_2_cursor.child_mask().iter() {
              v296_2_cursor.descend_to_existing_byte(v301_2_byte);
              {
              for v302_3_byte in v296_2_cursor.child_mask().iter() {
                v296_2_cursor.descend_to_existing_byte(v302_3_byte);
                {
                for v303_3_byte in v296_2_cursor.child_mask().iter() {
                  v296_2_cursor.descend_to_existing_byte(v303_3_byte);
                  {
                  let v304_3: Space = routine_52(c, &v296_2_cursor.path()[(v296_2_origin + 4)..(v296_2_origin + 8)], &(*p0), &v296_2_cursor.path()[v296_2_origin..(v296_2_origin + 4)], &v296_2_cursor);
                  join_wrapped_into(&mut v296_2_write,&((v304_3).read_zipper()),&[]);
                  }
                  v296_2_cursor.ascend(1);
                }
                }
                v296_2_cursor.ascend(1);
              }
              }
              v296_2_cursor.ascend(1);
            }
            }
            v296_2_cursor.ascend(1);
          }
          }
          v296_2_cursor.ascend(1);
        }
        }
        v296_2_cursor.ascend(1);
      }
      }
      v296_2_cursor.ascend(1);
    }
    }
    v296_2_cursor.ascend(1);
  }
  drop(v296_2_cursor);
  drop(v296_2_write);
  (v296_2).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_26(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v306_2 = Space::new();
  let mut v306_2_write = v306_2.write_zipper();
  let mut v306_2_cursor = (*s0).read_zipper();
  let v306_2_origin = v306_2_cursor.path().len();
  for v306_2_byte in v306_2_cursor.child_mask().iter() {
    v306_2_cursor.descend_to_existing_byte(v306_2_byte);
    {
    for v307_2_byte in v306_2_cursor.child_mask().iter() {
      v306_2_cursor.descend_to_existing_byte(v307_2_byte);
      {
      for v308_3_byte in v306_2_cursor.child_mask().iter() {
        v306_2_cursor.descend_to_existing_byte(v308_3_byte);
        {
        for v309_3_byte in v306_2_cursor.child_mask().iter() {
          v306_2_cursor.descend_to_existing_byte(v309_3_byte);
          {
          for v310_3_byte in v306_2_cursor.child_mask().iter() {
            v306_2_cursor.descend_to_existing_byte(v310_3_byte);
            {
            for v311_2_byte in v306_2_cursor.child_mask().iter() {
              v306_2_cursor.descend_to_existing_byte(v311_2_byte);
              {
              for v312_3_byte in v306_2_cursor.child_mask().iter() {
                v306_2_cursor.descend_to_existing_byte(v312_3_byte);
                {
                for v313_3_byte in v306_2_cursor.child_mask().iter() {
                  v306_2_cursor.descend_to_existing_byte(v313_3_byte);
                  {
                  let v314_3: Space = routine_53(c, &v306_2_cursor.path()[(v306_2_origin + 4)..(v306_2_origin + 8)], &(*p0), &v306_2_cursor.path()[v306_2_origin..(v306_2_origin + 4)], &v306_2_cursor);
                  join_wrapped_into(&mut v306_2_write,&((v314_3).read_zipper()),&[]);
                  }
                  v306_2_cursor.ascend(1);
                }
                }
                v306_2_cursor.ascend(1);
              }
              }
              v306_2_cursor.ascend(1);
            }
            }
            v306_2_cursor.ascend(1);
          }
          }
          v306_2_cursor.ascend(1);
        }
        }
        v306_2_cursor.ascend(1);
      }
      }
      v306_2_cursor.ascend(1);
    }
    }
    v306_2_cursor.ascend(1);
  }
  drop(v306_2_cursor);
  drop(v306_2_write);
  (v306_2).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_28(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v316_2 = Space::new();
  let mut v316_2_write = v316_2.write_zipper();
  let mut v316_2_cursor = (*s0).read_zipper();
  let v316_2_origin = v316_2_cursor.path().len();
  for v316_2_byte in v316_2_cursor.child_mask().iter() {
    v316_2_cursor.descend_to_existing_byte(v316_2_byte);
    {
    for v317_2_byte in v316_2_cursor.child_mask().iter() {
      v316_2_cursor.descend_to_existing_byte(v317_2_byte);
      {
      for v318_3_byte in v316_2_cursor.child_mask().iter() {
        v316_2_cursor.descend_to_existing_byte(v318_3_byte);
        {
        for v319_3_byte in v316_2_cursor.child_mask().iter() {
          v316_2_cursor.descend_to_existing_byte(v319_3_byte);
          {
          for v320_3_byte in v316_2_cursor.child_mask().iter() {
            v316_2_cursor.descend_to_existing_byte(v320_3_byte);
            {
            for v321_2_byte in v316_2_cursor.child_mask().iter() {
              v316_2_cursor.descend_to_existing_byte(v321_2_byte);
              {
              for v322_3_byte in v316_2_cursor.child_mask().iter() {
                v316_2_cursor.descend_to_existing_byte(v322_3_byte);
                {
                for v323_3_byte in v316_2_cursor.child_mask().iter() {
                  v316_2_cursor.descend_to_existing_byte(v323_3_byte);
                  {
                  let v324_3: Space = routine_54(c, &v316_2_cursor.path()[(v316_2_origin + 4)..(v316_2_origin + 8)], &(*p0), &v316_2_cursor.path()[v316_2_origin..(v316_2_origin + 4)], &v316_2_cursor);
                  join_wrapped_into(&mut v316_2_write,&((v324_3).read_zipper()),&[]);
                  }
                  v316_2_cursor.ascend(1);
                }
                }
                v316_2_cursor.ascend(1);
              }
              }
              v316_2_cursor.ascend(1);
            }
            }
            v316_2_cursor.ascend(1);
          }
          }
          v316_2_cursor.ascend(1);
        }
        }
        v316_2_cursor.ascend(1);
      }
      }
      v316_2_cursor.ascend(1);
    }
    }
    v316_2_cursor.ascend(1);
  }
  drop(v316_2_cursor);
  drop(v316_2_write);
  (v316_2).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_30(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v326_2 = Space::new();
  let mut v326_2_write = v326_2.write_zipper();
  let mut v326_2_cursor = (*s0).read_zipper();
  let v326_2_origin = v326_2_cursor.path().len();
  for v326_2_byte in v326_2_cursor.child_mask().iter() {
    v326_2_cursor.descend_to_existing_byte(v326_2_byte);
    {
    for v327_2_byte in v326_2_cursor.child_mask().iter() {
      v326_2_cursor.descend_to_existing_byte(v327_2_byte);
      {
      for v328_3_byte in v326_2_cursor.child_mask().iter() {
        v326_2_cursor.descend_to_existing_byte(v328_3_byte);
        {
        for v329_3_byte in v326_2_cursor.child_mask().iter() {
          v326_2_cursor.descend_to_existing_byte(v329_3_byte);
          {
          for v330_3_byte in v326_2_cursor.child_mask().iter() {
            v326_2_cursor.descend_to_existing_byte(v330_3_byte);
            {
            for v331_2_byte in v326_2_cursor.child_mask().iter() {
              v326_2_cursor.descend_to_existing_byte(v331_2_byte);
              {
              for v332_3_byte in v326_2_cursor.child_mask().iter() {
                v326_2_cursor.descend_to_existing_byte(v332_3_byte);
                {
                for v333_3_byte in v326_2_cursor.child_mask().iter() {
                  v326_2_cursor.descend_to_existing_byte(v333_3_byte);
                  {
                  let v334_3: Space = routine_55(c, &v326_2_cursor.path()[(v326_2_origin + 4)..(v326_2_origin + 8)], &(*p0), &v326_2_cursor.path()[v326_2_origin..(v326_2_origin + 4)], &v326_2_cursor);
                  join_wrapped_into(&mut v326_2_write,&((v334_3).read_zipper()),&[]);
                  }
                  v326_2_cursor.ascend(1);
                }
                }
                v326_2_cursor.ascend(1);
              }
              }
              v326_2_cursor.ascend(1);
            }
            }
            v326_2_cursor.ascend(1);
          }
          }
          v326_2_cursor.ascend(1);
        }
        }
        v326_2_cursor.ascend(1);
      }
      }
      v326_2_cursor.ascend(1);
    }
    }
    v326_2_cursor.ascend(1);
  }
  drop(v326_2_cursor);
  drop(v326_2_write);
  (v326_2).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_32(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v336_2 = Space::new();
  let mut v336_2_write = v336_2.write_zipper();
  let mut v336_2_cursor = (*s0).read_zipper();
  let v336_2_origin = v336_2_cursor.path().len();
  for v336_2_byte in v336_2_cursor.child_mask().iter() {
    v336_2_cursor.descend_to_existing_byte(v336_2_byte);
    {
    for v337_2_byte in v336_2_cursor.child_mask().iter() {
      v336_2_cursor.descend_to_existing_byte(v337_2_byte);
      {
      for v338_3_byte in v336_2_cursor.child_mask().iter() {
        v336_2_cursor.descend_to_existing_byte(v338_3_byte);
        {
        for v339_3_byte in v336_2_cursor.child_mask().iter() {
          v336_2_cursor.descend_to_existing_byte(v339_3_byte);
          {
          for v340_3_byte in v336_2_cursor.child_mask().iter() {
            v336_2_cursor.descend_to_existing_byte(v340_3_byte);
            {
            for v341_2_byte in v336_2_cursor.child_mask().iter() {
              v336_2_cursor.descend_to_existing_byte(v341_2_byte);
              {
              for v342_3_byte in v336_2_cursor.child_mask().iter() {
                v336_2_cursor.descend_to_existing_byte(v342_3_byte);
                {
                for v343_3_byte in v336_2_cursor.child_mask().iter() {
                  v336_2_cursor.descend_to_existing_byte(v343_3_byte);
                  {
                  let v344_3: Space = routine_56(c, &v336_2_cursor.path()[(v336_2_origin + 4)..(v336_2_origin + 8)], &(*p0), &v336_2_cursor.path()[v336_2_origin..(v336_2_origin + 4)], &v336_2_cursor);
                  join_wrapped_into(&mut v336_2_write,&((v344_3).read_zipper()),&[]);
                  }
                  v336_2_cursor.ascend(1);
                }
                }
                v336_2_cursor.ascend(1);
              }
              }
              v336_2_cursor.ascend(1);
            }
            }
            v336_2_cursor.ascend(1);
          }
          }
          v336_2_cursor.ascend(1);
        }
        }
        v336_2_cursor.ascend(1);
      }
      }
      v336_2_cursor.ascend(1);
    }
    }
    v336_2_cursor.ascend(1);
  }
  drop(v336_2_cursor);
  drop(v336_2_write);
  (v336_2).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_34(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v346_2 = Space::new();
  let mut v346_2_write = v346_2.write_zipper();
  let mut v346_2_cursor = (*s0).read_zipper();
  let v346_2_origin = v346_2_cursor.path().len();
  for v346_2_byte in v346_2_cursor.child_mask().iter() {
    v346_2_cursor.descend_to_existing_byte(v346_2_byte);
    {
    for v347_2_byte in v346_2_cursor.child_mask().iter() {
      v346_2_cursor.descend_to_existing_byte(v347_2_byte);
      {
      for v348_3_byte in v346_2_cursor.child_mask().iter() {
        v346_2_cursor.descend_to_existing_byte(v348_3_byte);
        {
        for v349_3_byte in v346_2_cursor.child_mask().iter() {
          v346_2_cursor.descend_to_existing_byte(v349_3_byte);
          {
          for v350_3_byte in v346_2_cursor.child_mask().iter() {
            v346_2_cursor.descend_to_existing_byte(v350_3_byte);
            {
            for v351_2_byte in v346_2_cursor.child_mask().iter() {
              v346_2_cursor.descend_to_existing_byte(v351_2_byte);
              {
              for v352_3_byte in v346_2_cursor.child_mask().iter() {
                v346_2_cursor.descend_to_existing_byte(v352_3_byte);
                {
                for v353_3_byte in v346_2_cursor.child_mask().iter() {
                  v346_2_cursor.descend_to_existing_byte(v353_3_byte);
                  {
                  let v354_3: Space = routine_57(c, &v346_2_cursor.path()[(v346_2_origin + 4)..(v346_2_origin + 8)], &(*p0), &v346_2_cursor.path()[v346_2_origin..(v346_2_origin + 4)], &v346_2_cursor);
                  join_wrapped_into(&mut v346_2_write,&((v354_3).read_zipper()),&[]);
                  }
                  v346_2_cursor.ascend(1);
                }
                }
                v346_2_cursor.ascend(1);
              }
              }
              v346_2_cursor.ascend(1);
            }
            }
            v346_2_cursor.ascend(1);
          }
          }
          v346_2_cursor.ascend(1);
        }
        }
        v346_2_cursor.ascend(1);
      }
      }
      v346_2_cursor.ascend(1);
    }
    }
    v346_2_cursor.ascend(1);
  }
  drop(v346_2_cursor);
  drop(v346_2_write);
  (v346_2).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_36(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v356_2 = Space::new();
  let mut v356_2_write = v356_2.write_zipper();
  let mut v356_2_cursor = (*s0).read_zipper();
  let v356_2_origin = v356_2_cursor.path().len();
  for v356_2_byte in v356_2_cursor.child_mask().iter() {
    v356_2_cursor.descend_to_existing_byte(v356_2_byte);
    {
    for v357_2_byte in v356_2_cursor.child_mask().iter() {
      v356_2_cursor.descend_to_existing_byte(v357_2_byte);
      {
      for v358_3_byte in v356_2_cursor.child_mask().iter() {
        v356_2_cursor.descend_to_existing_byte(v358_3_byte);
        {
        for v359_3_byte in v356_2_cursor.child_mask().iter() {
          v356_2_cursor.descend_to_existing_byte(v359_3_byte);
          {
          for v360_3_byte in v356_2_cursor.child_mask().iter() {
            v356_2_cursor.descend_to_existing_byte(v360_3_byte);
            {
            for v361_2_byte in v356_2_cursor.child_mask().iter() {
              v356_2_cursor.descend_to_existing_byte(v361_2_byte);
              {
              for v362_3_byte in v356_2_cursor.child_mask().iter() {
                v356_2_cursor.descend_to_existing_byte(v362_3_byte);
                {
                for v363_3_byte in v356_2_cursor.child_mask().iter() {
                  v356_2_cursor.descend_to_existing_byte(v363_3_byte);
                  {
                  let v364_3: Space = routine_58(c, &v356_2_cursor.path()[(v356_2_origin + 4)..(v356_2_origin + 8)], &(*p0), &v356_2_cursor.path()[v356_2_origin..(v356_2_origin + 4)], &v356_2_cursor);
                  join_wrapped_into(&mut v356_2_write,&((v364_3).read_zipper()),&[]);
                  }
                  v356_2_cursor.ascend(1);
                }
                }
                v356_2_cursor.ascend(1);
              }
              }
              v356_2_cursor.ascend(1);
            }
            }
            v356_2_cursor.ascend(1);
          }
          }
          v356_2_cursor.ascend(1);
        }
        }
        v356_2_cursor.ascend(1);
      }
      }
      v356_2_cursor.ascend(1);
    }
    }
    v356_2_cursor.ascend(1);
  }
  drop(v356_2_cursor);
  drop(v356_2_write);
  (v356_2).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_38(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v366_2 = Space::new();
  let mut v366_2_write = v366_2.write_zipper();
  let mut v366_2_cursor = (*s0).read_zipper();
  let v366_2_origin = v366_2_cursor.path().len();
  for v366_2_byte in v366_2_cursor.child_mask().iter() {
    v366_2_cursor.descend_to_existing_byte(v366_2_byte);
    {
    for v367_2_byte in v366_2_cursor.child_mask().iter() {
      v366_2_cursor.descend_to_existing_byte(v367_2_byte);
      {
      for v368_3_byte in v366_2_cursor.child_mask().iter() {
        v366_2_cursor.descend_to_existing_byte(v368_3_byte);
        {
        for v369_3_byte in v366_2_cursor.child_mask().iter() {
          v366_2_cursor.descend_to_existing_byte(v369_3_byte);
          {
          for v370_3_byte in v366_2_cursor.child_mask().iter() {
            v366_2_cursor.descend_to_existing_byte(v370_3_byte);
            {
            for v371_2_byte in v366_2_cursor.child_mask().iter() {
              v366_2_cursor.descend_to_existing_byte(v371_2_byte);
              {
              for v372_3_byte in v366_2_cursor.child_mask().iter() {
                v366_2_cursor.descend_to_existing_byte(v372_3_byte);
                {
                for v373_3_byte in v366_2_cursor.child_mask().iter() {
                  v366_2_cursor.descend_to_existing_byte(v373_3_byte);
                  {
                  let v374_3: Space = routine_59(c, &v366_2_cursor.path()[(v366_2_origin + 4)..(v366_2_origin + 8)], &(*p0), &v366_2_cursor.path()[v366_2_origin..(v366_2_origin + 4)], &v366_2_cursor);
                  join_wrapped_into(&mut v366_2_write,&((v374_3).read_zipper()),&[]);
                  }
                  v366_2_cursor.ascend(1);
                }
                }
                v366_2_cursor.ascend(1);
              }
              }
              v366_2_cursor.ascend(1);
            }
            }
            v366_2_cursor.ascend(1);
          }
          }
          v366_2_cursor.ascend(1);
        }
        }
        v366_2_cursor.ascend(1);
      }
      }
      v366_2_cursor.ascend(1);
    }
    }
    v366_2_cursor.ascend(1);
  }
  drop(v366_2_cursor);
  drop(v366_2_write);
  (v366_2).clone()
}

fn routine_39(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_40(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v376_2 = Space::new();
  let mut v376_2_write = v376_2.write_zipper();
  let mut v376_2_cursor = (*s0).read_zipper();
  let v376_2_origin = v376_2_cursor.path().len();
  for v376_2_byte in v376_2_cursor.child_mask().iter() {
    v376_2_cursor.descend_to_existing_byte(v376_2_byte);
    {
    for v377_2_byte in v376_2_cursor.child_mask().iter() {
      v376_2_cursor.descend_to_existing_byte(v377_2_byte);
      {
      for v378_3_byte in v376_2_cursor.child_mask().iter() {
        v376_2_cursor.descend_to_existing_byte(v378_3_byte);
        {
        for v379_3_byte in v376_2_cursor.child_mask().iter() {
          v376_2_cursor.descend_to_existing_byte(v379_3_byte);
          {
          for v380_3_byte in v376_2_cursor.child_mask().iter() {
            v376_2_cursor.descend_to_existing_byte(v380_3_byte);
            {
            for v381_2_byte in v376_2_cursor.child_mask().iter() {
              v376_2_cursor.descend_to_existing_byte(v381_2_byte);
              {
              for v382_3_byte in v376_2_cursor.child_mask().iter() {
                v376_2_cursor.descend_to_existing_byte(v382_3_byte);
                {
                for v383_3_byte in v376_2_cursor.child_mask().iter() {
                  v376_2_cursor.descend_to_existing_byte(v383_3_byte);
                  {
                  let v384_3: Space = routine_60(c, &v376_2_cursor.path()[(v376_2_origin + 4)..(v376_2_origin + 8)], &(*p0), &v376_2_cursor.path()[v376_2_origin..(v376_2_origin + 4)], &v376_2_cursor);
                  join_wrapped_into(&mut v376_2_write,&((v384_3).read_zipper()),&[]);
                  }
                  v376_2_cursor.ascend(1);
                }
                }
                v376_2_cursor.ascend(1);
              }
              }
              v376_2_cursor.ascend(1);
            }
            }
            v376_2_cursor.ascend(1);
          }
          }
          v376_2_cursor.ascend(1);
        }
        }
        v376_2_cursor.ascend(1);
      }
      }
      v376_2_cursor.ascend(1);
    }
    }
    v376_2_cursor.ascend(1);
  }
  drop(v376_2_cursor);
  drop(v376_2_write);
  (v376_2).clone()
}

fn routine_41(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v385_4 = Space::new();
  let mut v385_4_write = v385_4.write_zipper();
  let mut v385_4_cursor = (*s0).read_zipper();
  let v385_4_origin = v385_4_cursor.path().len();
  for v385_4_byte in v385_4_cursor.child_mask().iter() {
    v385_4_cursor.descend_to_existing_byte(v385_4_byte);
    {
    for v386_2_byte in v385_4_cursor.child_mask().iter() {
      v385_4_cursor.descend_to_existing_byte(v386_2_byte);
      {
      for v387_3_byte in v385_4_cursor.child_mask().iter() {
        v385_4_cursor.descend_to_existing_byte(v387_3_byte);
        {
        for v388_3_byte in v385_4_cursor.child_mask().iter() {
          v385_4_cursor.descend_to_existing_byte(v388_3_byte);
          {
          let mut v389_2 = Space::new();
          let mut v389_2_write = v389_2.write_zipper();
          for v389_2_byte in v385_4_cursor.child_mask().iter() {
            v385_4_cursor.descend_to_existing_byte(v389_2_byte);
            {
            for v390_2_byte in v385_4_cursor.child_mask().iter() {
              v385_4_cursor.descend_to_existing_byte(v390_2_byte);
              {
              for v391_3_byte in v385_4_cursor.child_mask().iter() {
                v385_4_cursor.descend_to_existing_byte(v391_3_byte);
                {
                for v392_3_byte in v385_4_cursor.child_mask().iter() {
                  v385_4_cursor.descend_to_existing_byte(v392_3_byte);
                  {
                  let v393_3: Space = routine_61(c, &v385_4_cursor.path()[(v385_4_origin + 4)..(v385_4_origin + 8)], &v385_4_cursor);
                  join_wrapped_into(&mut v389_2_write,&((v393_3).read_zipper()),&[]);
                  }
                  v385_4_cursor.ascend(1);
                }
                }
                v385_4_cursor.ascend(1);
              }
              }
              v385_4_cursor.ascend(1);
            }
            }
            v385_4_cursor.ascend(1);
          }
          drop(v389_2_write);
          let v389_3: Space = raffine(&(*CONSTANT_83),&(v389_2));
          let v389_4: Space = unite(&(v389_3),&v385_4_cursor);
          let v389_6: Path = concat_path(&(*p0),&v385_4_cursor.path()[v385_4_origin..(v385_4_origin + 4)]);
          let v389_7: Space = wrap(&(v389_4),&(v389_6));
          drop(v389_6);
          join_wrapped_into(&mut v385_4_write,&(descend_cursor((v389_7).read_zipper(),&(*p1))),&[]);
          }
          v385_4_cursor.ascend(1);
        }
        }
        v385_4_cursor.ascend(1);
      }
      }
      v385_4_cursor.ascend(1);
    }
    }
    v385_4_cursor.ascend(1);
  }
  drop(v385_4_cursor);
  drop(v385_4_write);
  (v385_4).clone()
}

fn routine_42(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v394_5: Space = wrap(&(descend_cursor((*s0).read_zipper(),&(*p1))),&(*p0));
  let v394_6: Space = if (&(v394_5)).is_empty() { Space::new() } else {
    compose(&(v394_5),&(*s1))
  };
  drop(v394_5);
  (v394_6).clone()
}

fn routine_43(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v396_5 = Space::new();
  let mut v396_5_write = v396_5.write_zipper();
  let mut v396_5_cursor = (*s0).read_zipper();
  let v396_5_origin = v396_5_cursor.path().len();
  for v396_5_byte in v396_5_cursor.child_mask().iter() {
    v396_5_cursor.descend_to_existing_byte(v396_5_byte);
    {
    for v397_2_byte in v396_5_cursor.child_mask().iter() {
      v396_5_cursor.descend_to_existing_byte(v397_2_byte);
      {
      for v398_3_byte in v396_5_cursor.child_mask().iter() {
        v396_5_cursor.descend_to_existing_byte(v398_3_byte);
        {
        for v399_3_byte in v396_5_cursor.child_mask().iter() {
          v396_5_cursor.descend_to_existing_byte(v399_3_byte);
          {
          let mut v400_2 = Space::new();
          let mut v400_2_write = v400_2.write_zipper();
          for v400_2_byte in v396_5_cursor.child_mask().iter() {
            v396_5_cursor.descend_to_existing_byte(v400_2_byte);
            {
            for v401_2_byte in v396_5_cursor.child_mask().iter() {
              v396_5_cursor.descend_to_existing_byte(v401_2_byte);
              {
              for v402_3_byte in v396_5_cursor.child_mask().iter() {
                v396_5_cursor.descend_to_existing_byte(v402_3_byte);
                {
                for v403_3_byte in v396_5_cursor.child_mask().iter() {
                  v396_5_cursor.descend_to_existing_byte(v403_3_byte);
                  {
                  let v404_3: Space = routine_62(c, &v396_5_cursor.path()[(v396_5_origin + 4)..(v396_5_origin + 8)], &v396_5_cursor);
                  join_wrapped_into(&mut v400_2_write,&((v404_3).read_zipper()),&[]);
                  }
                  v396_5_cursor.ascend(1);
                }
                }
                v396_5_cursor.ascend(1);
              }
              }
              v396_5_cursor.ascend(1);
            }
            }
            v396_5_cursor.ascend(1);
          }
          drop(v400_2_write);
          let v400_3: Space = raffine(&(*CONSTANT_83),&(v400_2));
          let v400_4: Space = unite(&(v400_3),&v396_5_cursor);
          let v400_6: Path = concat_path(&(*p0),&v396_5_cursor.path()[v396_5_origin..(v396_5_origin + 4)]);
          let v400_7: Space = wrap(&(v400_4),&(v400_6));
          drop(v400_6);
          join_wrapped_into(&mut v396_5_write,&(descend_cursor(descend_cursor(descend_cursor((v400_7).read_zipper(),&(*p1)),&(*p2)),&(*p1))),&[]);
          }
          v396_5_cursor.ascend(1);
        }
        }
        v396_5_cursor.ascend(1);
      }
      }
      v396_5_cursor.ascend(1);
    }
    }
    v396_5_cursor.ascend(1);
  }
  drop(v396_5_cursor);
  drop(v396_5_write);
  (v396_5).clone()
}

fn routine_44(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let (mut v405_175,mut v405_185,mut v405_4,) = native_block_2(c, p0, s1);
  let v405_186: Space = unite(&(v405_175),&(v405_185));
  drop(v405_175);
  drop(v405_185);
  let v405_188: Space = intersect(&(*CONSTANT_60),&(v405_4));
  let v405_195: Space = if (&(v405_188)).is_empty() { Space::new() } else {
    let v556_73: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))))
    };
    let v556_91: Space = if (&(v556_73)).is_empty() { Space::new() } else {
      compose(&(v556_73),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))))
    };
    drop(v556_73);
    let v556_108: Space = if (&(v556_91)).is_empty() { Space::new() } else {
      compose(&(v556_91),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v556_91);
    let v556_124: Space = if (&(v556_108)).is_empty() { Space::new() } else {
      compose(&(v556_108),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v556_108);
    let v556_139: Space = if (&(v556_124)).is_empty() { Space::new() } else {
      compose(&(v556_124),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v556_124);
    let v556_153: Space = if (&(v556_139)).is_empty() { Space::new() } else {
      compose(&(v556_139),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v556_139);
    let v556_166: Space = if (&(v556_153)).is_empty() { Space::new() } else {
      compose(&(v556_153),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v556_153);
    let v556_178: Space = if (&(v556_166)).is_empty() { Space::new() } else {
      compose(&(v556_166),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v556_166);
    let v556_189: Space = if (&(v556_178)).is_empty() { Space::new() } else {
      compose(&(v556_178),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v556_178);
    let v556_190: Space = if (&(v556_189)).is_empty() { Space::new() } else {
      compose(&(v556_189),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))))
    };
    let v556_191: Space = if (&(v556_190)).is_empty() { Space::new() } else {
      compose(&(v556_190),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v556_190);
    let v556_192: Space = if (&(v556_191)).is_empty() { Space::new() } else {
      compose(&(v556_191),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_27))))
    };
    drop(v556_191);
    let v556_193: Space = if (&(v556_192)).is_empty() { Space::new() } else {
      compose(&(v556_192),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_29))))
    };
    drop(v556_192);
    let v556_194: Space = if (&(v556_193)).is_empty() { Space::new() } else {
      compose(&(v556_193),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_81))))
    };
    drop(v556_193);
    compose(&(v405_188),&(v556_194))
  };
  drop(v405_188);
  let v405_196: Space = unite(&(v405_186),&(v405_195));
  drop(v405_186);
  drop(v405_195);
  let v405_198: Space = intersect(&(*CONSTANT_61),&(v405_4));
  let v405_204: Space = if (&(v405_198)).is_empty() { Space::new() } else {
    let v571_73: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))))
    };
    let v571_91: Space = if (&(v571_73)).is_empty() { Space::new() } else {
      compose(&(v571_73),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))))
    };
    drop(v571_73);
    let v571_108: Space = if (&(v571_91)).is_empty() { Space::new() } else {
      compose(&(v571_91),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v571_91);
    let v571_124: Space = if (&(v571_108)).is_empty() { Space::new() } else {
      compose(&(v571_108),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v571_108);
    let v571_139: Space = if (&(v571_124)).is_empty() { Space::new() } else {
      compose(&(v571_124),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v571_124);
    let v571_153: Space = if (&(v571_139)).is_empty() { Space::new() } else {
      compose(&(v571_139),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v571_139);
    let v571_166: Space = if (&(v571_153)).is_empty() { Space::new() } else {
      compose(&(v571_153),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v571_153);
    let v571_178: Space = if (&(v571_166)).is_empty() { Space::new() } else {
      compose(&(v571_166),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v571_166);
    let v571_189: Space = if (&(v571_178)).is_empty() { Space::new() } else {
      compose(&(v571_178),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v571_178);
    let v571_199: Space = if (&(v571_189)).is_empty() { Space::new() } else {
      compose(&(v571_189),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v571_189);
    let v571_200: Space = if (&(v571_199)).is_empty() { Space::new() } else {
      compose(&(v571_199),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_25))))
    };
    let v571_201: Space = if (&(v571_200)).is_empty() { Space::new() } else {
      compose(&(v571_200),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_27))))
    };
    drop(v571_200);
    let v571_202: Space = if (&(v571_201)).is_empty() { Space::new() } else {
      compose(&(v571_201),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_29))))
    };
    drop(v571_201);
    let v571_203: Space = if (&(v571_202)).is_empty() { Space::new() } else {
      compose(&(v571_202),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_81))))
    };
    drop(v571_202);
    compose(&(v405_198),&(v571_203))
  };
  drop(v405_198);
  let v405_205: Space = unite(&(v405_196),&(v405_204));
  drop(v405_196);
  drop(v405_204);
  let v405_207: Space = intersect(&(*CONSTANT_62),&(v405_4));
  let v405_212: Space = if (&(v405_207)).is_empty() { Space::new() } else {
    let v586_73: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))))
    };
    let v586_91: Space = if (&(v586_73)).is_empty() { Space::new() } else {
      compose(&(v586_73),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))))
    };
    drop(v586_73);
    let v586_108: Space = if (&(v586_91)).is_empty() { Space::new() } else {
      compose(&(v586_91),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v586_91);
    let v586_124: Space = if (&(v586_108)).is_empty() { Space::new() } else {
      compose(&(v586_108),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v586_108);
    let v586_139: Space = if (&(v586_124)).is_empty() { Space::new() } else {
      compose(&(v586_124),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v586_124);
    let v586_153: Space = if (&(v586_139)).is_empty() { Space::new() } else {
      compose(&(v586_139),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v586_139);
    let v586_166: Space = if (&(v586_153)).is_empty() { Space::new() } else {
      compose(&(v586_153),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v586_153);
    let v586_178: Space = if (&(v586_166)).is_empty() { Space::new() } else {
      compose(&(v586_166),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v586_166);
    let v586_189: Space = if (&(v586_178)).is_empty() { Space::new() } else {
      compose(&(v586_178),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v586_178);
    let v586_199: Space = if (&(v586_189)).is_empty() { Space::new() } else {
      compose(&(v586_189),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v586_189);
    let v586_208: Space = if (&(v586_199)).is_empty() { Space::new() } else {
      compose(&(v586_199),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v586_199);
    let v586_209: Space = if (&(v586_208)).is_empty() { Space::new() } else {
      compose(&(v586_208),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_27))))
    };
    let v586_210: Space = if (&(v586_209)).is_empty() { Space::new() } else {
      compose(&(v586_209),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_29))))
    };
    drop(v586_209);
    let v586_211: Space = if (&(v586_210)).is_empty() { Space::new() } else {
      compose(&(v586_210),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_81))))
    };
    drop(v586_210);
    compose(&(v405_207),&(v586_211))
  };
  drop(v405_207);
  let v405_213: Space = unite(&(v405_205),&(v405_212));
  drop(v405_205);
  drop(v405_212);
  let v405_215: Space = intersect(&(*CONSTANT_63),&(v405_4));
  let v405_219: Space = if (&(v405_215)).is_empty() { Space::new() } else {
    let v601_73: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))))
    };
    let v601_91: Space = if (&(v601_73)).is_empty() { Space::new() } else {
      compose(&(v601_73),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))))
    };
    drop(v601_73);
    let v601_108: Space = if (&(v601_91)).is_empty() { Space::new() } else {
      compose(&(v601_91),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v601_91);
    let v601_124: Space = if (&(v601_108)).is_empty() { Space::new() } else {
      compose(&(v601_108),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v601_108);
    let v601_139: Space = if (&(v601_124)).is_empty() { Space::new() } else {
      compose(&(v601_124),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v601_124);
    let v601_153: Space = if (&(v601_139)).is_empty() { Space::new() } else {
      compose(&(v601_139),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v601_139);
    let v601_166: Space = if (&(v601_153)).is_empty() { Space::new() } else {
      compose(&(v601_153),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v601_153);
    let v601_178: Space = if (&(v601_166)).is_empty() { Space::new() } else {
      compose(&(v601_166),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v601_166);
    let v601_189: Space = if (&(v601_178)).is_empty() { Space::new() } else {
      compose(&(v601_178),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v601_178);
    let v601_199: Space = if (&(v601_189)).is_empty() { Space::new() } else {
      compose(&(v601_189),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v601_189);
    let v601_208: Space = if (&(v601_199)).is_empty() { Space::new() } else {
      compose(&(v601_199),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v601_199);
    let v601_216: Space = if (&(v601_208)).is_empty() { Space::new() } else {
      compose(&(v601_208),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v601_208);
    let v601_217: Space = if (&(v601_216)).is_empty() { Space::new() } else {
      compose(&(v601_216),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_29))))
    };
    let v601_218: Space = if (&(v601_217)).is_empty() { Space::new() } else {
      compose(&(v601_217),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_81))))
    };
    drop(v601_217);
    compose(&(v405_215),&(v601_218))
  };
  drop(v405_215);
  let v405_220: Space = unite(&(v405_213),&(v405_219));
  drop(v405_213);
  drop(v405_219);
  let v405_222: Space = intersect(&(*CONSTANT_64),&(v405_4));
  let v405_225: Space = if (&(v405_222)).is_empty() { Space::new() } else {
    let v616_73: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))))
    };
    let v616_91: Space = if (&(v616_73)).is_empty() { Space::new() } else {
      compose(&(v616_73),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))))
    };
    drop(v616_73);
    let v616_108: Space = if (&(v616_91)).is_empty() { Space::new() } else {
      compose(&(v616_91),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v616_91);
    let v616_124: Space = if (&(v616_108)).is_empty() { Space::new() } else {
      compose(&(v616_108),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v616_108);
    let v616_139: Space = if (&(v616_124)).is_empty() { Space::new() } else {
      compose(&(v616_124),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v616_124);
    let v616_153: Space = if (&(v616_139)).is_empty() { Space::new() } else {
      compose(&(v616_139),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v616_139);
    let v616_166: Space = if (&(v616_153)).is_empty() { Space::new() } else {
      compose(&(v616_153),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v616_153);
    let v616_178: Space = if (&(v616_166)).is_empty() { Space::new() } else {
      compose(&(v616_166),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v616_166);
    let v616_189: Space = if (&(v616_178)).is_empty() { Space::new() } else {
      compose(&(v616_178),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v616_178);
    let v616_199: Space = if (&(v616_189)).is_empty() { Space::new() } else {
      compose(&(v616_189),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v616_189);
    let v616_208: Space = if (&(v616_199)).is_empty() { Space::new() } else {
      compose(&(v616_199),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v616_199);
    let v616_216: Space = if (&(v616_208)).is_empty() { Space::new() } else {
      compose(&(v616_208),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v616_208);
    let v616_223: Space = if (&(v616_216)).is_empty() { Space::new() } else {
      compose(&(v616_216),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_27))))
    };
    drop(v616_216);
    let v616_224: Space = if (&(v616_223)).is_empty() { Space::new() } else {
      compose(&(v616_223),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_81))))
    };
    compose(&(v405_222),&(v616_224))
  };
  drop(v405_222);
  let v405_226: Space = unite(&(v405_220),&(v405_225));
  drop(v405_220);
  drop(v405_225);
  let v405_228: Space = intersect(&(*CONSTANT_65),&(v405_4));
  drop(v405_4);
  let v405_230: Space = if (&(v405_228)).is_empty() { Space::new() } else {
    let v631_73: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))))
    };
    let v631_91: Space = if (&(v631_73)).is_empty() { Space::new() } else {
      compose(&(v631_73),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))))
    };
    drop(v631_73);
    let v631_108: Space = if (&(v631_91)).is_empty() { Space::new() } else {
      compose(&(v631_91),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v631_91);
    let v631_124: Space = if (&(v631_108)).is_empty() { Space::new() } else {
      compose(&(v631_108),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v631_108);
    let v631_139: Space = if (&(v631_124)).is_empty() { Space::new() } else {
      compose(&(v631_124),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v631_124);
    let v631_153: Space = if (&(v631_139)).is_empty() { Space::new() } else {
      compose(&(v631_139),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v631_139);
    let v631_166: Space = if (&(v631_153)).is_empty() { Space::new() } else {
      compose(&(v631_153),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v631_153);
    let v631_178: Space = if (&(v631_166)).is_empty() { Space::new() } else {
      compose(&(v631_166),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v631_166);
    let v631_189: Space = if (&(v631_178)).is_empty() { Space::new() } else {
      compose(&(v631_178),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v631_178);
    let v631_199: Space = if (&(v631_189)).is_empty() { Space::new() } else {
      compose(&(v631_189),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v631_189);
    let v631_208: Space = if (&(v631_199)).is_empty() { Space::new() } else {
      compose(&(v631_199),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v631_199);
    let v631_216: Space = if (&(v631_208)).is_empty() { Space::new() } else {
      compose(&(v631_208),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v631_208);
    let v631_223: Space = if (&(v631_216)).is_empty() { Space::new() } else {
      compose(&(v631_216),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_27))))
    };
    drop(v631_216);
    let v631_229: Space = if (&(v631_223)).is_empty() { Space::new() } else {
      compose(&(v631_223),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_29))))
    };
    drop(v631_223);
    compose(&(v405_228),&(v631_229))
  };
  drop(v405_228);
  let v405_231: Space = unite(&(v405_226),&(v405_230));
  drop(v405_226);
  drop(v405_230);
  (v405_231).clone()
}

fn routine_45(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v646_4 = Space::new();
  let mut v646_4_write = v646_4.write_zipper();
  let mut v646_4_cursor = (*s0).read_zipper();
  let v646_4_origin = v646_4_cursor.path().len();
  for v646_4_byte in v646_4_cursor.child_mask().iter() {
    v646_4_cursor.descend_to_existing_byte(v646_4_byte);
    {
    for v647_2_byte in v646_4_cursor.child_mask().iter() {
      v646_4_cursor.descend_to_existing_byte(v647_2_byte);
      {
      for v648_3_byte in v646_4_cursor.child_mask().iter() {
        v646_4_cursor.descend_to_existing_byte(v648_3_byte);
        {
        for v649_3_byte in v646_4_cursor.child_mask().iter() {
          v646_4_cursor.descend_to_existing_byte(v649_3_byte);
          {
          for v650_3_byte in v646_4_cursor.child_mask().iter() {
            v646_4_cursor.descend_to_existing_byte(v650_3_byte);
            {
            for v651_2_byte in v646_4_cursor.child_mask().iter() {
              v646_4_cursor.descend_to_existing_byte(v651_2_byte);
              {
              for v652_3_byte in v646_4_cursor.child_mask().iter() {
                v646_4_cursor.descend_to_existing_byte(v652_3_byte);
                {
                for v653_3_byte in v646_4_cursor.child_mask().iter() {
                  v646_4_cursor.descend_to_existing_byte(v653_3_byte);
                  {
                  let v654_3: Space = routine_63(c, &v646_4_cursor.path()[(v646_4_origin + 4)..(v646_4_origin + 8)], &(*p1), &(*p2), &(*p0), &v646_4_cursor.path()[v646_4_origin..(v646_4_origin + 4)], &v646_4_cursor);
                  join_wrapped_into(&mut v646_4_write,&((v654_3).read_zipper()),&[]);
                  }
                  v646_4_cursor.ascend(1);
                }
                }
                v646_4_cursor.ascend(1);
              }
              }
              v646_4_cursor.ascend(1);
            }
            }
            v646_4_cursor.ascend(1);
          }
          }
          v646_4_cursor.ascend(1);
        }
        }
        v646_4_cursor.ascend(1);
      }
      }
      v646_4_cursor.ascend(1);
    }
    }
    v646_4_cursor.ascend(1);
  }
  drop(v646_4_cursor);
  drop(v646_4_write);
  (v646_4).clone()
}

fn routine_46(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v655_4 = Space::new();
  let mut v655_4_write = v655_4.write_zipper();
  let mut v655_4_cursor = (*s0).read_zipper();
  let v655_4_origin = v655_4_cursor.path().len();
  for v655_4_byte in v655_4_cursor.child_mask().iter() {
    v655_4_cursor.descend_to_existing_byte(v655_4_byte);
    {
    for v656_2_byte in v655_4_cursor.child_mask().iter() {
      v655_4_cursor.descend_to_existing_byte(v656_2_byte);
      {
      for v657_3_byte in v655_4_cursor.child_mask().iter() {
        v655_4_cursor.descend_to_existing_byte(v657_3_byte);
        {
        for v658_3_byte in v655_4_cursor.child_mask().iter() {
          v655_4_cursor.descend_to_existing_byte(v658_3_byte);
          {
          for v659_3_byte in v655_4_cursor.child_mask().iter() {
            v655_4_cursor.descend_to_existing_byte(v659_3_byte);
            {
            for v660_2_byte in v655_4_cursor.child_mask().iter() {
              v655_4_cursor.descend_to_existing_byte(v660_2_byte);
              {
              for v661_3_byte in v655_4_cursor.child_mask().iter() {
                v655_4_cursor.descend_to_existing_byte(v661_3_byte);
                {
                for v662_3_byte in v655_4_cursor.child_mask().iter() {
                  v655_4_cursor.descend_to_existing_byte(v662_3_byte);
                  {
                  let v663_3: Space = routine_64(c, &v655_4_cursor.path()[(v655_4_origin + 4)..(v655_4_origin + 8)], &(*p1), &(*p2), &(*p0), &v655_4_cursor.path()[v655_4_origin..(v655_4_origin + 4)], &v655_4_cursor);
                  join_wrapped_into(&mut v655_4_write,&((v663_3).read_zipper()),&[]);
                  }
                  v655_4_cursor.ascend(1);
                }
                }
                v655_4_cursor.ascend(1);
              }
              }
              v655_4_cursor.ascend(1);
            }
            }
            v655_4_cursor.ascend(1);
          }
          }
          v655_4_cursor.ascend(1);
        }
        }
        v655_4_cursor.ascend(1);
      }
      }
      v655_4_cursor.ascend(1);
    }
    }
    v655_4_cursor.ascend(1);
  }
  drop(v655_4_cursor);
  drop(v655_4_write);
  (v655_4).clone()
}

fn routine_47(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v664_4 = Space::new();
  let mut v664_4_write = v664_4.write_zipper();
  let mut v664_4_cursor = (*s0).read_zipper();
  let v664_4_origin = v664_4_cursor.path().len();
  for v664_4_byte in v664_4_cursor.child_mask().iter() {
    v664_4_cursor.descend_to_existing_byte(v664_4_byte);
    {
    for v665_2_byte in v664_4_cursor.child_mask().iter() {
      v664_4_cursor.descend_to_existing_byte(v665_2_byte);
      {
      for v666_3_byte in v664_4_cursor.child_mask().iter() {
        v664_4_cursor.descend_to_existing_byte(v666_3_byte);
        {
        for v667_3_byte in v664_4_cursor.child_mask().iter() {
          v664_4_cursor.descend_to_existing_byte(v667_3_byte);
          {
          for v668_3_byte in v664_4_cursor.child_mask().iter() {
            v664_4_cursor.descend_to_existing_byte(v668_3_byte);
            {
            for v669_2_byte in v664_4_cursor.child_mask().iter() {
              v664_4_cursor.descend_to_existing_byte(v669_2_byte);
              {
              for v670_3_byte in v664_4_cursor.child_mask().iter() {
                v664_4_cursor.descend_to_existing_byte(v670_3_byte);
                {
                for v671_3_byte in v664_4_cursor.child_mask().iter() {
                  v664_4_cursor.descend_to_existing_byte(v671_3_byte);
                  {
                  let v672_3: Space = routine_65(c, &v664_4_cursor.path()[(v664_4_origin + 4)..(v664_4_origin + 8)], &(*p1), &(*p2), &(*p0), &v664_4_cursor.path()[v664_4_origin..(v664_4_origin + 4)], &v664_4_cursor);
                  join_wrapped_into(&mut v664_4_write,&((v672_3).read_zipper()),&[]);
                  }
                  v664_4_cursor.ascend(1);
                }
                }
                v664_4_cursor.ascend(1);
              }
              }
              v664_4_cursor.ascend(1);
            }
            }
            v664_4_cursor.ascend(1);
          }
          }
          v664_4_cursor.ascend(1);
        }
        }
        v664_4_cursor.ascend(1);
      }
      }
      v664_4_cursor.ascend(1);
    }
    }
    v664_4_cursor.ascend(1);
  }
  drop(v664_4_cursor);
  drop(v664_4_write);
  (v664_4).clone()
}

fn routine_48(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v673_4 = Space::new();
  let mut v673_4_write = v673_4.write_zipper();
  let mut v673_4_cursor = (*s0).read_zipper();
  let v673_4_origin = v673_4_cursor.path().len();
  for v673_4_byte in v673_4_cursor.child_mask().iter() {
    v673_4_cursor.descend_to_existing_byte(v673_4_byte);
    {
    for v674_2_byte in v673_4_cursor.child_mask().iter() {
      v673_4_cursor.descend_to_existing_byte(v674_2_byte);
      {
      for v675_3_byte in v673_4_cursor.child_mask().iter() {
        v673_4_cursor.descend_to_existing_byte(v675_3_byte);
        {
        for v676_3_byte in v673_4_cursor.child_mask().iter() {
          v673_4_cursor.descend_to_existing_byte(v676_3_byte);
          {
          for v677_3_byte in v673_4_cursor.child_mask().iter() {
            v673_4_cursor.descend_to_existing_byte(v677_3_byte);
            {
            for v678_2_byte in v673_4_cursor.child_mask().iter() {
              v673_4_cursor.descend_to_existing_byte(v678_2_byte);
              {
              for v679_3_byte in v673_4_cursor.child_mask().iter() {
                v673_4_cursor.descend_to_existing_byte(v679_3_byte);
                {
                for v680_3_byte in v673_4_cursor.child_mask().iter() {
                  v673_4_cursor.descend_to_existing_byte(v680_3_byte);
                  {
                  let v681_3: Space = routine_66(c, &v673_4_cursor.path()[(v673_4_origin + 4)..(v673_4_origin + 8)], &(*p1), &(*p2), &(*p0), &v673_4_cursor.path()[v673_4_origin..(v673_4_origin + 4)], &v673_4_cursor);
                  join_wrapped_into(&mut v673_4_write,&((v681_3).read_zipper()),&[]);
                  }
                  v673_4_cursor.ascend(1);
                }
                }
                v673_4_cursor.ascend(1);
              }
              }
              v673_4_cursor.ascend(1);
            }
            }
            v673_4_cursor.ascend(1);
          }
          }
          v673_4_cursor.ascend(1);
        }
        }
        v673_4_cursor.ascend(1);
      }
      }
      v673_4_cursor.ascend(1);
    }
    }
    v673_4_cursor.ascend(1);
  }
  drop(v673_4_cursor);
  drop(v673_4_write);
  (v673_4).clone()
}

fn routine_49(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v682_4 = Space::new();
  let mut v682_4_write = v682_4.write_zipper();
  let mut v682_4_cursor = (*s0).read_zipper();
  let v682_4_origin = v682_4_cursor.path().len();
  for v682_4_byte in v682_4_cursor.child_mask().iter() {
    v682_4_cursor.descend_to_existing_byte(v682_4_byte);
    {
    for v683_2_byte in v682_4_cursor.child_mask().iter() {
      v682_4_cursor.descend_to_existing_byte(v683_2_byte);
      {
      for v684_3_byte in v682_4_cursor.child_mask().iter() {
        v682_4_cursor.descend_to_existing_byte(v684_3_byte);
        {
        for v685_3_byte in v682_4_cursor.child_mask().iter() {
          v682_4_cursor.descend_to_existing_byte(v685_3_byte);
          {
          for v686_3_byte in v682_4_cursor.child_mask().iter() {
            v682_4_cursor.descend_to_existing_byte(v686_3_byte);
            {
            for v687_2_byte in v682_4_cursor.child_mask().iter() {
              v682_4_cursor.descend_to_existing_byte(v687_2_byte);
              {
              for v688_3_byte in v682_4_cursor.child_mask().iter() {
                v682_4_cursor.descend_to_existing_byte(v688_3_byte);
                {
                for v689_3_byte in v682_4_cursor.child_mask().iter() {
                  v682_4_cursor.descend_to_existing_byte(v689_3_byte);
                  {
                  let v690_3: Space = routine_67(c, &v682_4_cursor.path()[(v682_4_origin + 4)..(v682_4_origin + 8)], &(*p1), &(*p2), &(*p0), &v682_4_cursor.path()[v682_4_origin..(v682_4_origin + 4)], &v682_4_cursor);
                  join_wrapped_into(&mut v682_4_write,&((v690_3).read_zipper()),&[]);
                  }
                  v682_4_cursor.ascend(1);
                }
                }
                v682_4_cursor.ascend(1);
              }
              }
              v682_4_cursor.ascend(1);
            }
            }
            v682_4_cursor.ascend(1);
          }
          }
          v682_4_cursor.ascend(1);
        }
        }
        v682_4_cursor.ascend(1);
      }
      }
      v682_4_cursor.ascend(1);
    }
    }
    v682_4_cursor.ascend(1);
  }
  drop(v682_4_cursor);
  drop(v682_4_write);
  (v682_4).clone()
}

fn routine_50(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v691_4 = Space::new();
  let mut v691_4_write = v691_4.write_zipper();
  let mut v691_4_cursor = (*s0).read_zipper();
  let v691_4_origin = v691_4_cursor.path().len();
  for v691_4_byte in v691_4_cursor.child_mask().iter() {
    v691_4_cursor.descend_to_existing_byte(v691_4_byte);
    {
    for v692_2_byte in v691_4_cursor.child_mask().iter() {
      v691_4_cursor.descend_to_existing_byte(v692_2_byte);
      {
      for v693_3_byte in v691_4_cursor.child_mask().iter() {
        v691_4_cursor.descend_to_existing_byte(v693_3_byte);
        {
        for v694_3_byte in v691_4_cursor.child_mask().iter() {
          v691_4_cursor.descend_to_existing_byte(v694_3_byte);
          {
          for v695_3_byte in v691_4_cursor.child_mask().iter() {
            v691_4_cursor.descend_to_existing_byte(v695_3_byte);
            {
            for v696_2_byte in v691_4_cursor.child_mask().iter() {
              v691_4_cursor.descend_to_existing_byte(v696_2_byte);
              {
              for v697_3_byte in v691_4_cursor.child_mask().iter() {
                v691_4_cursor.descend_to_existing_byte(v697_3_byte);
                {
                for v698_3_byte in v691_4_cursor.child_mask().iter() {
                  v691_4_cursor.descend_to_existing_byte(v698_3_byte);
                  {
                  let v699_3: Space = routine_68(c, &v691_4_cursor.path()[(v691_4_origin + 4)..(v691_4_origin + 8)], &(*p1), &(*p2), &(*p0), &v691_4_cursor.path()[v691_4_origin..(v691_4_origin + 4)], &v691_4_cursor);
                  join_wrapped_into(&mut v691_4_write,&((v699_3).read_zipper()),&[]);
                  }
                  v691_4_cursor.ascend(1);
                }
                }
                v691_4_cursor.ascend(1);
              }
              }
              v691_4_cursor.ascend(1);
            }
            }
            v691_4_cursor.ascend(1);
          }
          }
          v691_4_cursor.ascend(1);
        }
        }
        v691_4_cursor.ascend(1);
      }
      }
      v691_4_cursor.ascend(1);
    }
    }
    v691_4_cursor.ascend(1);
  }
  drop(v691_4_cursor);
  drop(v691_4_write);
  (v691_4).clone()
}

fn routine_51(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v700_4 = Space::new();
  let mut v700_4_write = v700_4.write_zipper();
  let mut v700_4_cursor = (*s0).read_zipper();
  let v700_4_origin = v700_4_cursor.path().len();
  for v700_4_byte in v700_4_cursor.child_mask().iter() {
    v700_4_cursor.descend_to_existing_byte(v700_4_byte);
    {
    for v701_2_byte in v700_4_cursor.child_mask().iter() {
      v700_4_cursor.descend_to_existing_byte(v701_2_byte);
      {
      for v702_3_byte in v700_4_cursor.child_mask().iter() {
        v700_4_cursor.descend_to_existing_byte(v702_3_byte);
        {
        for v703_3_byte in v700_4_cursor.child_mask().iter() {
          v700_4_cursor.descend_to_existing_byte(v703_3_byte);
          {
          for v704_3_byte in v700_4_cursor.child_mask().iter() {
            v700_4_cursor.descend_to_existing_byte(v704_3_byte);
            {
            for v705_2_byte in v700_4_cursor.child_mask().iter() {
              v700_4_cursor.descend_to_existing_byte(v705_2_byte);
              {
              for v706_3_byte in v700_4_cursor.child_mask().iter() {
                v700_4_cursor.descend_to_existing_byte(v706_3_byte);
                {
                for v707_3_byte in v700_4_cursor.child_mask().iter() {
                  v700_4_cursor.descend_to_existing_byte(v707_3_byte);
                  {
                  let v708_3: Space = routine_69(c, &v700_4_cursor.path()[(v700_4_origin + 4)..(v700_4_origin + 8)], &(*p1), &(*p2), &(*p0), &v700_4_cursor.path()[v700_4_origin..(v700_4_origin + 4)], &v700_4_cursor);
                  join_wrapped_into(&mut v700_4_write,&((v708_3).read_zipper()),&[]);
                  }
                  v700_4_cursor.ascend(1);
                }
                }
                v700_4_cursor.ascend(1);
              }
              }
              v700_4_cursor.ascend(1);
            }
            }
            v700_4_cursor.ascend(1);
          }
          }
          v700_4_cursor.ascend(1);
        }
        }
        v700_4_cursor.ascend(1);
      }
      }
      v700_4_cursor.ascend(1);
    }
    }
    v700_4_cursor.ascend(1);
  }
  drop(v700_4_cursor);
  drop(v700_4_write);
  (v700_4).clone()
}

fn routine_52(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v709_4 = Space::new();
  let mut v709_4_write = v709_4.write_zipper();
  let mut v709_4_cursor = (*s0).read_zipper();
  let v709_4_origin = v709_4_cursor.path().len();
  for v709_4_byte in v709_4_cursor.child_mask().iter() {
    v709_4_cursor.descend_to_existing_byte(v709_4_byte);
    {
    for v710_2_byte in v709_4_cursor.child_mask().iter() {
      v709_4_cursor.descend_to_existing_byte(v710_2_byte);
      {
      for v711_3_byte in v709_4_cursor.child_mask().iter() {
        v709_4_cursor.descend_to_existing_byte(v711_3_byte);
        {
        for v712_3_byte in v709_4_cursor.child_mask().iter() {
          v709_4_cursor.descend_to_existing_byte(v712_3_byte);
          {
          for v713_3_byte in v709_4_cursor.child_mask().iter() {
            v709_4_cursor.descend_to_existing_byte(v713_3_byte);
            {
            for v714_2_byte in v709_4_cursor.child_mask().iter() {
              v709_4_cursor.descend_to_existing_byte(v714_2_byte);
              {
              for v715_3_byte in v709_4_cursor.child_mask().iter() {
                v709_4_cursor.descend_to_existing_byte(v715_3_byte);
                {
                for v716_3_byte in v709_4_cursor.child_mask().iter() {
                  v709_4_cursor.descend_to_existing_byte(v716_3_byte);
                  {
                  let v717_3: Space = routine_70(c, &v709_4_cursor.path()[(v709_4_origin + 4)..(v709_4_origin + 8)], &(*p1), &(*p2), &(*p0), &v709_4_cursor.path()[v709_4_origin..(v709_4_origin + 4)], &v709_4_cursor);
                  join_wrapped_into(&mut v709_4_write,&((v717_3).read_zipper()),&[]);
                  }
                  v709_4_cursor.ascend(1);
                }
                }
                v709_4_cursor.ascend(1);
              }
              }
              v709_4_cursor.ascend(1);
            }
            }
            v709_4_cursor.ascend(1);
          }
          }
          v709_4_cursor.ascend(1);
        }
        }
        v709_4_cursor.ascend(1);
      }
      }
      v709_4_cursor.ascend(1);
    }
    }
    v709_4_cursor.ascend(1);
  }
  drop(v709_4_cursor);
  drop(v709_4_write);
  (v709_4).clone()
}

fn routine_53(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v718_4 = Space::new();
  let mut v718_4_write = v718_4.write_zipper();
  let mut v718_4_cursor = (*s0).read_zipper();
  let v718_4_origin = v718_4_cursor.path().len();
  for v718_4_byte in v718_4_cursor.child_mask().iter() {
    v718_4_cursor.descend_to_existing_byte(v718_4_byte);
    {
    for v719_2_byte in v718_4_cursor.child_mask().iter() {
      v718_4_cursor.descend_to_existing_byte(v719_2_byte);
      {
      for v720_3_byte in v718_4_cursor.child_mask().iter() {
        v718_4_cursor.descend_to_existing_byte(v720_3_byte);
        {
        for v721_3_byte in v718_4_cursor.child_mask().iter() {
          v718_4_cursor.descend_to_existing_byte(v721_3_byte);
          {
          for v722_3_byte in v718_4_cursor.child_mask().iter() {
            v718_4_cursor.descend_to_existing_byte(v722_3_byte);
            {
            for v723_2_byte in v718_4_cursor.child_mask().iter() {
              v718_4_cursor.descend_to_existing_byte(v723_2_byte);
              {
              for v724_3_byte in v718_4_cursor.child_mask().iter() {
                v718_4_cursor.descend_to_existing_byte(v724_3_byte);
                {
                for v725_3_byte in v718_4_cursor.child_mask().iter() {
                  v718_4_cursor.descend_to_existing_byte(v725_3_byte);
                  {
                  let v726_3: Space = routine_71(c, &v718_4_cursor.path()[(v718_4_origin + 4)..(v718_4_origin + 8)], &(*p1), &(*p2), &(*p0), &v718_4_cursor.path()[v718_4_origin..(v718_4_origin + 4)], &v718_4_cursor);
                  join_wrapped_into(&mut v718_4_write,&((v726_3).read_zipper()),&[]);
                  }
                  v718_4_cursor.ascend(1);
                }
                }
                v718_4_cursor.ascend(1);
              }
              }
              v718_4_cursor.ascend(1);
            }
            }
            v718_4_cursor.ascend(1);
          }
          }
          v718_4_cursor.ascend(1);
        }
        }
        v718_4_cursor.ascend(1);
      }
      }
      v718_4_cursor.ascend(1);
    }
    }
    v718_4_cursor.ascend(1);
  }
  drop(v718_4_cursor);
  drop(v718_4_write);
  (v718_4).clone()
}

fn routine_54(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v727_4 = Space::new();
  let mut v727_4_write = v727_4.write_zipper();
  let mut v727_4_cursor = (*s0).read_zipper();
  let v727_4_origin = v727_4_cursor.path().len();
  for v727_4_byte in v727_4_cursor.child_mask().iter() {
    v727_4_cursor.descend_to_existing_byte(v727_4_byte);
    {
    for v728_2_byte in v727_4_cursor.child_mask().iter() {
      v727_4_cursor.descend_to_existing_byte(v728_2_byte);
      {
      for v729_3_byte in v727_4_cursor.child_mask().iter() {
        v727_4_cursor.descend_to_existing_byte(v729_3_byte);
        {
        for v730_3_byte in v727_4_cursor.child_mask().iter() {
          v727_4_cursor.descend_to_existing_byte(v730_3_byte);
          {
          for v731_3_byte in v727_4_cursor.child_mask().iter() {
            v727_4_cursor.descend_to_existing_byte(v731_3_byte);
            {
            for v732_2_byte in v727_4_cursor.child_mask().iter() {
              v727_4_cursor.descend_to_existing_byte(v732_2_byte);
              {
              for v733_3_byte in v727_4_cursor.child_mask().iter() {
                v727_4_cursor.descend_to_existing_byte(v733_3_byte);
                {
                for v734_3_byte in v727_4_cursor.child_mask().iter() {
                  v727_4_cursor.descend_to_existing_byte(v734_3_byte);
                  {
                  let v735_3: Space = routine_72(c, &v727_4_cursor.path()[(v727_4_origin + 4)..(v727_4_origin + 8)], &(*p1), &(*p2), &(*p0), &v727_4_cursor.path()[v727_4_origin..(v727_4_origin + 4)], &v727_4_cursor);
                  join_wrapped_into(&mut v727_4_write,&((v735_3).read_zipper()),&[]);
                  }
                  v727_4_cursor.ascend(1);
                }
                }
                v727_4_cursor.ascend(1);
              }
              }
              v727_4_cursor.ascend(1);
            }
            }
            v727_4_cursor.ascend(1);
          }
          }
          v727_4_cursor.ascend(1);
        }
        }
        v727_4_cursor.ascend(1);
      }
      }
      v727_4_cursor.ascend(1);
    }
    }
    v727_4_cursor.ascend(1);
  }
  drop(v727_4_cursor);
  drop(v727_4_write);
  (v727_4).clone()
}

fn routine_55(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v736_4 = Space::new();
  let mut v736_4_write = v736_4.write_zipper();
  let mut v736_4_cursor = (*s0).read_zipper();
  let v736_4_origin = v736_4_cursor.path().len();
  for v736_4_byte in v736_4_cursor.child_mask().iter() {
    v736_4_cursor.descend_to_existing_byte(v736_4_byte);
    {
    for v737_2_byte in v736_4_cursor.child_mask().iter() {
      v736_4_cursor.descend_to_existing_byte(v737_2_byte);
      {
      for v738_3_byte in v736_4_cursor.child_mask().iter() {
        v736_4_cursor.descend_to_existing_byte(v738_3_byte);
        {
        for v739_3_byte in v736_4_cursor.child_mask().iter() {
          v736_4_cursor.descend_to_existing_byte(v739_3_byte);
          {
          for v740_3_byte in v736_4_cursor.child_mask().iter() {
            v736_4_cursor.descend_to_existing_byte(v740_3_byte);
            {
            for v741_2_byte in v736_4_cursor.child_mask().iter() {
              v736_4_cursor.descend_to_existing_byte(v741_2_byte);
              {
              for v742_3_byte in v736_4_cursor.child_mask().iter() {
                v736_4_cursor.descend_to_existing_byte(v742_3_byte);
                {
                for v743_3_byte in v736_4_cursor.child_mask().iter() {
                  v736_4_cursor.descend_to_existing_byte(v743_3_byte);
                  {
                  let v744_3: Space = routine_73(c, &v736_4_cursor.path()[(v736_4_origin + 4)..(v736_4_origin + 8)], &(*p1), &(*p2), &(*p0), &v736_4_cursor.path()[v736_4_origin..(v736_4_origin + 4)], &v736_4_cursor);
                  join_wrapped_into(&mut v736_4_write,&((v744_3).read_zipper()),&[]);
                  }
                  v736_4_cursor.ascend(1);
                }
                }
                v736_4_cursor.ascend(1);
              }
              }
              v736_4_cursor.ascend(1);
            }
            }
            v736_4_cursor.ascend(1);
          }
          }
          v736_4_cursor.ascend(1);
        }
        }
        v736_4_cursor.ascend(1);
      }
      }
      v736_4_cursor.ascend(1);
    }
    }
    v736_4_cursor.ascend(1);
  }
  drop(v736_4_cursor);
  drop(v736_4_write);
  (v736_4).clone()
}

fn routine_56(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v745_4 = Space::new();
  let mut v745_4_write = v745_4.write_zipper();
  let mut v745_4_cursor = (*s0).read_zipper();
  let v745_4_origin = v745_4_cursor.path().len();
  for v745_4_byte in v745_4_cursor.child_mask().iter() {
    v745_4_cursor.descend_to_existing_byte(v745_4_byte);
    {
    for v746_2_byte in v745_4_cursor.child_mask().iter() {
      v745_4_cursor.descend_to_existing_byte(v746_2_byte);
      {
      for v747_3_byte in v745_4_cursor.child_mask().iter() {
        v745_4_cursor.descend_to_existing_byte(v747_3_byte);
        {
        for v748_3_byte in v745_4_cursor.child_mask().iter() {
          v745_4_cursor.descend_to_existing_byte(v748_3_byte);
          {
          for v749_3_byte in v745_4_cursor.child_mask().iter() {
            v745_4_cursor.descend_to_existing_byte(v749_3_byte);
            {
            for v750_2_byte in v745_4_cursor.child_mask().iter() {
              v745_4_cursor.descend_to_existing_byte(v750_2_byte);
              {
              for v751_3_byte in v745_4_cursor.child_mask().iter() {
                v745_4_cursor.descend_to_existing_byte(v751_3_byte);
                {
                for v752_3_byte in v745_4_cursor.child_mask().iter() {
                  v745_4_cursor.descend_to_existing_byte(v752_3_byte);
                  {
                  let v753_3: Space = routine_74(c, &v745_4_cursor.path()[(v745_4_origin + 4)..(v745_4_origin + 8)], &(*p1), &(*p2), &(*p0), &v745_4_cursor.path()[v745_4_origin..(v745_4_origin + 4)], &v745_4_cursor);
                  join_wrapped_into(&mut v745_4_write,&((v753_3).read_zipper()),&[]);
                  }
                  v745_4_cursor.ascend(1);
                }
                }
                v745_4_cursor.ascend(1);
              }
              }
              v745_4_cursor.ascend(1);
            }
            }
            v745_4_cursor.ascend(1);
          }
          }
          v745_4_cursor.ascend(1);
        }
        }
        v745_4_cursor.ascend(1);
      }
      }
      v745_4_cursor.ascend(1);
    }
    }
    v745_4_cursor.ascend(1);
  }
  drop(v745_4_cursor);
  drop(v745_4_write);
  (v745_4).clone()
}

fn routine_57(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v754_4 = Space::new();
  let mut v754_4_write = v754_4.write_zipper();
  let mut v754_4_cursor = (*s0).read_zipper();
  let v754_4_origin = v754_4_cursor.path().len();
  for v754_4_byte in v754_4_cursor.child_mask().iter() {
    v754_4_cursor.descend_to_existing_byte(v754_4_byte);
    {
    for v755_2_byte in v754_4_cursor.child_mask().iter() {
      v754_4_cursor.descend_to_existing_byte(v755_2_byte);
      {
      for v756_3_byte in v754_4_cursor.child_mask().iter() {
        v754_4_cursor.descend_to_existing_byte(v756_3_byte);
        {
        for v757_3_byte in v754_4_cursor.child_mask().iter() {
          v754_4_cursor.descend_to_existing_byte(v757_3_byte);
          {
          for v758_3_byte in v754_4_cursor.child_mask().iter() {
            v754_4_cursor.descend_to_existing_byte(v758_3_byte);
            {
            for v759_2_byte in v754_4_cursor.child_mask().iter() {
              v754_4_cursor.descend_to_existing_byte(v759_2_byte);
              {
              for v760_3_byte in v754_4_cursor.child_mask().iter() {
                v754_4_cursor.descend_to_existing_byte(v760_3_byte);
                {
                for v761_3_byte in v754_4_cursor.child_mask().iter() {
                  v754_4_cursor.descend_to_existing_byte(v761_3_byte);
                  {
                  let v762_3: Space = routine_75(c, &v754_4_cursor.path()[(v754_4_origin + 4)..(v754_4_origin + 8)], &(*p1), &(*p2), &(*p0), &v754_4_cursor.path()[v754_4_origin..(v754_4_origin + 4)], &v754_4_cursor);
                  join_wrapped_into(&mut v754_4_write,&((v762_3).read_zipper()),&[]);
                  }
                  v754_4_cursor.ascend(1);
                }
                }
                v754_4_cursor.ascend(1);
              }
              }
              v754_4_cursor.ascend(1);
            }
            }
            v754_4_cursor.ascend(1);
          }
          }
          v754_4_cursor.ascend(1);
        }
        }
        v754_4_cursor.ascend(1);
      }
      }
      v754_4_cursor.ascend(1);
    }
    }
    v754_4_cursor.ascend(1);
  }
  drop(v754_4_cursor);
  drop(v754_4_write);
  (v754_4).clone()
}

fn routine_58(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v763_4 = Space::new();
  let mut v763_4_write = v763_4.write_zipper();
  let mut v763_4_cursor = (*s0).read_zipper();
  let v763_4_origin = v763_4_cursor.path().len();
  for v763_4_byte in v763_4_cursor.child_mask().iter() {
    v763_4_cursor.descend_to_existing_byte(v763_4_byte);
    {
    for v764_2_byte in v763_4_cursor.child_mask().iter() {
      v763_4_cursor.descend_to_existing_byte(v764_2_byte);
      {
      for v765_3_byte in v763_4_cursor.child_mask().iter() {
        v763_4_cursor.descend_to_existing_byte(v765_3_byte);
        {
        for v766_3_byte in v763_4_cursor.child_mask().iter() {
          v763_4_cursor.descend_to_existing_byte(v766_3_byte);
          {
          for v767_3_byte in v763_4_cursor.child_mask().iter() {
            v763_4_cursor.descend_to_existing_byte(v767_3_byte);
            {
            for v768_2_byte in v763_4_cursor.child_mask().iter() {
              v763_4_cursor.descend_to_existing_byte(v768_2_byte);
              {
              for v769_3_byte in v763_4_cursor.child_mask().iter() {
                v763_4_cursor.descend_to_existing_byte(v769_3_byte);
                {
                for v770_3_byte in v763_4_cursor.child_mask().iter() {
                  v763_4_cursor.descend_to_existing_byte(v770_3_byte);
                  {
                  let v771_3: Space = routine_76(c, &v763_4_cursor.path()[(v763_4_origin + 4)..(v763_4_origin + 8)], &(*p1), &(*p2), &(*p0), &v763_4_cursor.path()[v763_4_origin..(v763_4_origin + 4)], &v763_4_cursor);
                  join_wrapped_into(&mut v763_4_write,&((v771_3).read_zipper()),&[]);
                  }
                  v763_4_cursor.ascend(1);
                }
                }
                v763_4_cursor.ascend(1);
              }
              }
              v763_4_cursor.ascend(1);
            }
            }
            v763_4_cursor.ascend(1);
          }
          }
          v763_4_cursor.ascend(1);
        }
        }
        v763_4_cursor.ascend(1);
      }
      }
      v763_4_cursor.ascend(1);
    }
    }
    v763_4_cursor.ascend(1);
  }
  drop(v763_4_cursor);
  drop(v763_4_write);
  (v763_4).clone()
}

fn routine_59(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v772_4 = Space::new();
  let mut v772_4_write = v772_4.write_zipper();
  let mut v772_4_cursor = (*s0).read_zipper();
  let v772_4_origin = v772_4_cursor.path().len();
  for v772_4_byte in v772_4_cursor.child_mask().iter() {
    v772_4_cursor.descend_to_existing_byte(v772_4_byte);
    {
    for v773_2_byte in v772_4_cursor.child_mask().iter() {
      v772_4_cursor.descend_to_existing_byte(v773_2_byte);
      {
      for v774_3_byte in v772_4_cursor.child_mask().iter() {
        v772_4_cursor.descend_to_existing_byte(v774_3_byte);
        {
        for v775_3_byte in v772_4_cursor.child_mask().iter() {
          v772_4_cursor.descend_to_existing_byte(v775_3_byte);
          {
          for v776_3_byte in v772_4_cursor.child_mask().iter() {
            v772_4_cursor.descend_to_existing_byte(v776_3_byte);
            {
            for v777_2_byte in v772_4_cursor.child_mask().iter() {
              v772_4_cursor.descend_to_existing_byte(v777_2_byte);
              {
              for v778_3_byte in v772_4_cursor.child_mask().iter() {
                v772_4_cursor.descend_to_existing_byte(v778_3_byte);
                {
                for v779_3_byte in v772_4_cursor.child_mask().iter() {
                  v772_4_cursor.descend_to_existing_byte(v779_3_byte);
                  {
                  let v780_3: Space = routine_77(c, &v772_4_cursor.path()[(v772_4_origin + 4)..(v772_4_origin + 8)], &(*p1), &(*p2), &(*p0), &v772_4_cursor.path()[v772_4_origin..(v772_4_origin + 4)], &v772_4_cursor);
                  join_wrapped_into(&mut v772_4_write,&((v780_3).read_zipper()),&[]);
                  }
                  v772_4_cursor.ascend(1);
                }
                }
                v772_4_cursor.ascend(1);
              }
              }
              v772_4_cursor.ascend(1);
            }
            }
            v772_4_cursor.ascend(1);
          }
          }
          v772_4_cursor.ascend(1);
        }
        }
        v772_4_cursor.ascend(1);
      }
      }
      v772_4_cursor.ascend(1);
    }
    }
    v772_4_cursor.ascend(1);
  }
  drop(v772_4_cursor);
  drop(v772_4_write);
  (v772_4).clone()
}

fn routine_60(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v781_4 = Space::new();
  let mut v781_4_write = v781_4.write_zipper();
  let mut v781_4_cursor = (*s0).read_zipper();
  let v781_4_origin = v781_4_cursor.path().len();
  for v781_4_byte in v781_4_cursor.child_mask().iter() {
    v781_4_cursor.descend_to_existing_byte(v781_4_byte);
    {
    for v782_2_byte in v781_4_cursor.child_mask().iter() {
      v781_4_cursor.descend_to_existing_byte(v782_2_byte);
      {
      for v783_3_byte in v781_4_cursor.child_mask().iter() {
        v781_4_cursor.descend_to_existing_byte(v783_3_byte);
        {
        for v784_3_byte in v781_4_cursor.child_mask().iter() {
          v781_4_cursor.descend_to_existing_byte(v784_3_byte);
          {
          for v785_3_byte in v781_4_cursor.child_mask().iter() {
            v781_4_cursor.descend_to_existing_byte(v785_3_byte);
            {
            for v786_2_byte in v781_4_cursor.child_mask().iter() {
              v781_4_cursor.descend_to_existing_byte(v786_2_byte);
              {
              for v787_3_byte in v781_4_cursor.child_mask().iter() {
                v781_4_cursor.descend_to_existing_byte(v787_3_byte);
                {
                for v788_3_byte in v781_4_cursor.child_mask().iter() {
                  v781_4_cursor.descend_to_existing_byte(v788_3_byte);
                  {
                  let v789_3: Space = routine_78(c, &v781_4_cursor.path()[(v781_4_origin + 4)..(v781_4_origin + 8)], &(*p1), &(*p2), &(*p0), &v781_4_cursor.path()[v781_4_origin..(v781_4_origin + 4)], &v781_4_cursor);
                  join_wrapped_into(&mut v781_4_write,&((v789_3).read_zipper()),&[]);
                  }
                  v781_4_cursor.ascend(1);
                }
                }
                v781_4_cursor.ascend(1);
              }
              }
              v781_4_cursor.ascend(1);
            }
            }
            v781_4_cursor.ascend(1);
          }
          }
          v781_4_cursor.ascend(1);
        }
        }
        v781_4_cursor.ascend(1);
      }
      }
      v781_4_cursor.ascend(1);
    }
    }
    v781_4_cursor.ascend(1);
  }
  drop(v781_4_cursor);
  drop(v781_4_write);
  (v781_4).clone()
}

fn routine_61(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v790_2: Space = singleton(&(*p0));
  (v790_2).clone()
}

fn routine_62(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v791_2: Space = singleton(&(*p0));
  (v791_2).clone()
}

fn routine_63(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v792_6 = Space::new();
  let mut v792_6_write = v792_6.write_zipper();
  let mut v792_6_cursor = (*s0).read_zipper();
  let v792_6_origin = v792_6_cursor.path().len();
  for v792_6_byte in v792_6_cursor.child_mask().iter() {
    v792_6_cursor.descend_to_existing_byte(v792_6_byte);
    {
    for v793_2_byte in v792_6_cursor.child_mask().iter() {
      v792_6_cursor.descend_to_existing_byte(v793_2_byte);
      {
      for v794_3_byte in v792_6_cursor.child_mask().iter() {
        v792_6_cursor.descend_to_existing_byte(v794_3_byte);
        {
        for v795_3_byte in v792_6_cursor.child_mask().iter() {
          v792_6_cursor.descend_to_existing_byte(v795_3_byte);
          {
          for v796_3_byte in v792_6_cursor.child_mask().iter() {
            v792_6_cursor.descend_to_existing_byte(v796_3_byte);
            {
            for v797_2_byte in v792_6_cursor.child_mask().iter() {
              v792_6_cursor.descend_to_existing_byte(v797_2_byte);
              {
              for v798_3_byte in v792_6_cursor.child_mask().iter() {
                v792_6_cursor.descend_to_existing_byte(v798_3_byte);
                {
                for v799_3_byte in v792_6_cursor.child_mask().iter() {
                  v792_6_cursor.descend_to_existing_byte(v799_3_byte);
                  {
                  let v800_3: Space = routine_79(c, &v792_6_cursor.path()[(v792_6_origin + 4)..(v792_6_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v792_6_cursor.path()[v792_6_origin..(v792_6_origin + 4)], &v792_6_cursor);
                  join_wrapped_into(&mut v792_6_write,&((v800_3).read_zipper()),&[]);
                  }
                  v792_6_cursor.ascend(1);
                }
                }
                v792_6_cursor.ascend(1);
              }
              }
              v792_6_cursor.ascend(1);
            }
            }
            v792_6_cursor.ascend(1);
          }
          }
          v792_6_cursor.ascend(1);
        }
        }
        v792_6_cursor.ascend(1);
      }
      }
      v792_6_cursor.ascend(1);
    }
    }
    v792_6_cursor.ascend(1);
  }
  drop(v792_6_cursor);
  drop(v792_6_write);
  (v792_6).clone()
}

fn routine_64(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v801_6 = Space::new();
  let mut v801_6_write = v801_6.write_zipper();
  let mut v801_6_cursor = (*s0).read_zipper();
  let v801_6_origin = v801_6_cursor.path().len();
  for v801_6_byte in v801_6_cursor.child_mask().iter() {
    v801_6_cursor.descend_to_existing_byte(v801_6_byte);
    {
    for v802_2_byte in v801_6_cursor.child_mask().iter() {
      v801_6_cursor.descend_to_existing_byte(v802_2_byte);
      {
      for v803_3_byte in v801_6_cursor.child_mask().iter() {
        v801_6_cursor.descend_to_existing_byte(v803_3_byte);
        {
        for v804_3_byte in v801_6_cursor.child_mask().iter() {
          v801_6_cursor.descend_to_existing_byte(v804_3_byte);
          {
          for v805_3_byte in v801_6_cursor.child_mask().iter() {
            v801_6_cursor.descend_to_existing_byte(v805_3_byte);
            {
            for v806_2_byte in v801_6_cursor.child_mask().iter() {
              v801_6_cursor.descend_to_existing_byte(v806_2_byte);
              {
              for v807_3_byte in v801_6_cursor.child_mask().iter() {
                v801_6_cursor.descend_to_existing_byte(v807_3_byte);
                {
                for v808_3_byte in v801_6_cursor.child_mask().iter() {
                  v801_6_cursor.descend_to_existing_byte(v808_3_byte);
                  {
                  let v809_3: Space = routine_80(c, &v801_6_cursor.path()[(v801_6_origin + 4)..(v801_6_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v801_6_cursor.path()[v801_6_origin..(v801_6_origin + 4)], &v801_6_cursor);
                  join_wrapped_into(&mut v801_6_write,&((v809_3).read_zipper()),&[]);
                  }
                  v801_6_cursor.ascend(1);
                }
                }
                v801_6_cursor.ascend(1);
              }
              }
              v801_6_cursor.ascend(1);
            }
            }
            v801_6_cursor.ascend(1);
          }
          }
          v801_6_cursor.ascend(1);
        }
        }
        v801_6_cursor.ascend(1);
      }
      }
      v801_6_cursor.ascend(1);
    }
    }
    v801_6_cursor.ascend(1);
  }
  drop(v801_6_cursor);
  drop(v801_6_write);
  (v801_6).clone()
}

fn routine_65(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v810_6 = Space::new();
  let mut v810_6_write = v810_6.write_zipper();
  let mut v810_6_cursor = (*s0).read_zipper();
  let v810_6_origin = v810_6_cursor.path().len();
  for v810_6_byte in v810_6_cursor.child_mask().iter() {
    v810_6_cursor.descend_to_existing_byte(v810_6_byte);
    {
    for v811_2_byte in v810_6_cursor.child_mask().iter() {
      v810_6_cursor.descend_to_existing_byte(v811_2_byte);
      {
      for v812_3_byte in v810_6_cursor.child_mask().iter() {
        v810_6_cursor.descend_to_existing_byte(v812_3_byte);
        {
        for v813_3_byte in v810_6_cursor.child_mask().iter() {
          v810_6_cursor.descend_to_existing_byte(v813_3_byte);
          {
          for v814_3_byte in v810_6_cursor.child_mask().iter() {
            v810_6_cursor.descend_to_existing_byte(v814_3_byte);
            {
            for v815_2_byte in v810_6_cursor.child_mask().iter() {
              v810_6_cursor.descend_to_existing_byte(v815_2_byte);
              {
              for v816_3_byte in v810_6_cursor.child_mask().iter() {
                v810_6_cursor.descend_to_existing_byte(v816_3_byte);
                {
                for v817_3_byte in v810_6_cursor.child_mask().iter() {
                  v810_6_cursor.descend_to_existing_byte(v817_3_byte);
                  {
                  let v818_3: Space = routine_81(c, &v810_6_cursor.path()[(v810_6_origin + 4)..(v810_6_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v810_6_cursor.path()[v810_6_origin..(v810_6_origin + 4)], &v810_6_cursor);
                  join_wrapped_into(&mut v810_6_write,&((v818_3).read_zipper()),&[]);
                  }
                  v810_6_cursor.ascend(1);
                }
                }
                v810_6_cursor.ascend(1);
              }
              }
              v810_6_cursor.ascend(1);
            }
            }
            v810_6_cursor.ascend(1);
          }
          }
          v810_6_cursor.ascend(1);
        }
        }
        v810_6_cursor.ascend(1);
      }
      }
      v810_6_cursor.ascend(1);
    }
    }
    v810_6_cursor.ascend(1);
  }
  drop(v810_6_cursor);
  drop(v810_6_write);
  (v810_6).clone()
}

fn routine_66(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v819_6 = Space::new();
  let mut v819_6_write = v819_6.write_zipper();
  let mut v819_6_cursor = (*s0).read_zipper();
  let v819_6_origin = v819_6_cursor.path().len();
  for v819_6_byte in v819_6_cursor.child_mask().iter() {
    v819_6_cursor.descend_to_existing_byte(v819_6_byte);
    {
    for v820_2_byte in v819_6_cursor.child_mask().iter() {
      v819_6_cursor.descend_to_existing_byte(v820_2_byte);
      {
      for v821_3_byte in v819_6_cursor.child_mask().iter() {
        v819_6_cursor.descend_to_existing_byte(v821_3_byte);
        {
        for v822_3_byte in v819_6_cursor.child_mask().iter() {
          v819_6_cursor.descend_to_existing_byte(v822_3_byte);
          {
          for v823_3_byte in v819_6_cursor.child_mask().iter() {
            v819_6_cursor.descend_to_existing_byte(v823_3_byte);
            {
            for v824_2_byte in v819_6_cursor.child_mask().iter() {
              v819_6_cursor.descend_to_existing_byte(v824_2_byte);
              {
              for v825_3_byte in v819_6_cursor.child_mask().iter() {
                v819_6_cursor.descend_to_existing_byte(v825_3_byte);
                {
                for v826_3_byte in v819_6_cursor.child_mask().iter() {
                  v819_6_cursor.descend_to_existing_byte(v826_3_byte);
                  {
                  let v827_3: Space = routine_82(c, &v819_6_cursor.path()[(v819_6_origin + 4)..(v819_6_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v819_6_cursor.path()[v819_6_origin..(v819_6_origin + 4)], &v819_6_cursor);
                  join_wrapped_into(&mut v819_6_write,&((v827_3).read_zipper()),&[]);
                  }
                  v819_6_cursor.ascend(1);
                }
                }
                v819_6_cursor.ascend(1);
              }
              }
              v819_6_cursor.ascend(1);
            }
            }
            v819_6_cursor.ascend(1);
          }
          }
          v819_6_cursor.ascend(1);
        }
        }
        v819_6_cursor.ascend(1);
      }
      }
      v819_6_cursor.ascend(1);
    }
    }
    v819_6_cursor.ascend(1);
  }
  drop(v819_6_cursor);
  drop(v819_6_write);
  (v819_6).clone()
}

fn routine_67(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v828_6 = Space::new();
  let mut v828_6_write = v828_6.write_zipper();
  let mut v828_6_cursor = (*s0).read_zipper();
  let v828_6_origin = v828_6_cursor.path().len();
  for v828_6_byte in v828_6_cursor.child_mask().iter() {
    v828_6_cursor.descend_to_existing_byte(v828_6_byte);
    {
    for v829_2_byte in v828_6_cursor.child_mask().iter() {
      v828_6_cursor.descend_to_existing_byte(v829_2_byte);
      {
      for v830_3_byte in v828_6_cursor.child_mask().iter() {
        v828_6_cursor.descend_to_existing_byte(v830_3_byte);
        {
        for v831_3_byte in v828_6_cursor.child_mask().iter() {
          v828_6_cursor.descend_to_existing_byte(v831_3_byte);
          {
          for v832_3_byte in v828_6_cursor.child_mask().iter() {
            v828_6_cursor.descend_to_existing_byte(v832_3_byte);
            {
            for v833_2_byte in v828_6_cursor.child_mask().iter() {
              v828_6_cursor.descend_to_existing_byte(v833_2_byte);
              {
              for v834_3_byte in v828_6_cursor.child_mask().iter() {
                v828_6_cursor.descend_to_existing_byte(v834_3_byte);
                {
                for v835_3_byte in v828_6_cursor.child_mask().iter() {
                  v828_6_cursor.descend_to_existing_byte(v835_3_byte);
                  {
                  let v836_3: Space = routine_83(c, &v828_6_cursor.path()[(v828_6_origin + 4)..(v828_6_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v828_6_cursor.path()[v828_6_origin..(v828_6_origin + 4)], &v828_6_cursor);
                  join_wrapped_into(&mut v828_6_write,&((v836_3).read_zipper()),&[]);
                  }
                  v828_6_cursor.ascend(1);
                }
                }
                v828_6_cursor.ascend(1);
              }
              }
              v828_6_cursor.ascend(1);
            }
            }
            v828_6_cursor.ascend(1);
          }
          }
          v828_6_cursor.ascend(1);
        }
        }
        v828_6_cursor.ascend(1);
      }
      }
      v828_6_cursor.ascend(1);
    }
    }
    v828_6_cursor.ascend(1);
  }
  drop(v828_6_cursor);
  drop(v828_6_write);
  (v828_6).clone()
}

fn routine_68(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v837_6 = Space::new();
  let mut v837_6_write = v837_6.write_zipper();
  let mut v837_6_cursor = (*s0).read_zipper();
  let v837_6_origin = v837_6_cursor.path().len();
  for v837_6_byte in v837_6_cursor.child_mask().iter() {
    v837_6_cursor.descend_to_existing_byte(v837_6_byte);
    {
    for v838_2_byte in v837_6_cursor.child_mask().iter() {
      v837_6_cursor.descend_to_existing_byte(v838_2_byte);
      {
      for v839_3_byte in v837_6_cursor.child_mask().iter() {
        v837_6_cursor.descend_to_existing_byte(v839_3_byte);
        {
        for v840_3_byte in v837_6_cursor.child_mask().iter() {
          v837_6_cursor.descend_to_existing_byte(v840_3_byte);
          {
          for v841_3_byte in v837_6_cursor.child_mask().iter() {
            v837_6_cursor.descend_to_existing_byte(v841_3_byte);
            {
            for v842_2_byte in v837_6_cursor.child_mask().iter() {
              v837_6_cursor.descend_to_existing_byte(v842_2_byte);
              {
              for v843_3_byte in v837_6_cursor.child_mask().iter() {
                v837_6_cursor.descend_to_existing_byte(v843_3_byte);
                {
                for v844_3_byte in v837_6_cursor.child_mask().iter() {
                  v837_6_cursor.descend_to_existing_byte(v844_3_byte);
                  {
                  let v845_3: Space = routine_84(c, &v837_6_cursor.path()[(v837_6_origin + 4)..(v837_6_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v837_6_cursor.path()[v837_6_origin..(v837_6_origin + 4)], &v837_6_cursor);
                  join_wrapped_into(&mut v837_6_write,&((v845_3).read_zipper()),&[]);
                  }
                  v837_6_cursor.ascend(1);
                }
                }
                v837_6_cursor.ascend(1);
              }
              }
              v837_6_cursor.ascend(1);
            }
            }
            v837_6_cursor.ascend(1);
          }
          }
          v837_6_cursor.ascend(1);
        }
        }
        v837_6_cursor.ascend(1);
      }
      }
      v837_6_cursor.ascend(1);
    }
    }
    v837_6_cursor.ascend(1);
  }
  drop(v837_6_cursor);
  drop(v837_6_write);
  (v837_6).clone()
}

fn routine_69(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v846_6 = Space::new();
  let mut v846_6_write = v846_6.write_zipper();
  let mut v846_6_cursor = (*s0).read_zipper();
  let v846_6_origin = v846_6_cursor.path().len();
  for v846_6_byte in v846_6_cursor.child_mask().iter() {
    v846_6_cursor.descend_to_existing_byte(v846_6_byte);
    {
    for v847_2_byte in v846_6_cursor.child_mask().iter() {
      v846_6_cursor.descend_to_existing_byte(v847_2_byte);
      {
      for v848_3_byte in v846_6_cursor.child_mask().iter() {
        v846_6_cursor.descend_to_existing_byte(v848_3_byte);
        {
        for v849_3_byte in v846_6_cursor.child_mask().iter() {
          v846_6_cursor.descend_to_existing_byte(v849_3_byte);
          {
          for v850_3_byte in v846_6_cursor.child_mask().iter() {
            v846_6_cursor.descend_to_existing_byte(v850_3_byte);
            {
            for v851_2_byte in v846_6_cursor.child_mask().iter() {
              v846_6_cursor.descend_to_existing_byte(v851_2_byte);
              {
              for v852_3_byte in v846_6_cursor.child_mask().iter() {
                v846_6_cursor.descend_to_existing_byte(v852_3_byte);
                {
                for v853_3_byte in v846_6_cursor.child_mask().iter() {
                  v846_6_cursor.descend_to_existing_byte(v853_3_byte);
                  {
                  let v854_3: Space = routine_85(c, &v846_6_cursor.path()[(v846_6_origin + 4)..(v846_6_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v846_6_cursor.path()[v846_6_origin..(v846_6_origin + 4)], &v846_6_cursor);
                  join_wrapped_into(&mut v846_6_write,&((v854_3).read_zipper()),&[]);
                  }
                  v846_6_cursor.ascend(1);
                }
                }
                v846_6_cursor.ascend(1);
              }
              }
              v846_6_cursor.ascend(1);
            }
            }
            v846_6_cursor.ascend(1);
          }
          }
          v846_6_cursor.ascend(1);
        }
        }
        v846_6_cursor.ascend(1);
      }
      }
      v846_6_cursor.ascend(1);
    }
    }
    v846_6_cursor.ascend(1);
  }
  drop(v846_6_cursor);
  drop(v846_6_write);
  (v846_6).clone()
}

fn routine_70(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v855_6 = Space::new();
  let mut v855_6_write = v855_6.write_zipper();
  let mut v855_6_cursor = (*s0).read_zipper();
  let v855_6_origin = v855_6_cursor.path().len();
  for v855_6_byte in v855_6_cursor.child_mask().iter() {
    v855_6_cursor.descend_to_existing_byte(v855_6_byte);
    {
    for v856_2_byte in v855_6_cursor.child_mask().iter() {
      v855_6_cursor.descend_to_existing_byte(v856_2_byte);
      {
      for v857_3_byte in v855_6_cursor.child_mask().iter() {
        v855_6_cursor.descend_to_existing_byte(v857_3_byte);
        {
        for v858_3_byte in v855_6_cursor.child_mask().iter() {
          v855_6_cursor.descend_to_existing_byte(v858_3_byte);
          {
          for v859_3_byte in v855_6_cursor.child_mask().iter() {
            v855_6_cursor.descend_to_existing_byte(v859_3_byte);
            {
            for v860_2_byte in v855_6_cursor.child_mask().iter() {
              v855_6_cursor.descend_to_existing_byte(v860_2_byte);
              {
              for v861_3_byte in v855_6_cursor.child_mask().iter() {
                v855_6_cursor.descend_to_existing_byte(v861_3_byte);
                {
                for v862_3_byte in v855_6_cursor.child_mask().iter() {
                  v855_6_cursor.descend_to_existing_byte(v862_3_byte);
                  {
                  let v863_3: Space = routine_86(c, &v855_6_cursor.path()[(v855_6_origin + 4)..(v855_6_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v855_6_cursor.path()[v855_6_origin..(v855_6_origin + 4)], &v855_6_cursor);
                  join_wrapped_into(&mut v855_6_write,&((v863_3).read_zipper()),&[]);
                  }
                  v855_6_cursor.ascend(1);
                }
                }
                v855_6_cursor.ascend(1);
              }
              }
              v855_6_cursor.ascend(1);
            }
            }
            v855_6_cursor.ascend(1);
          }
          }
          v855_6_cursor.ascend(1);
        }
        }
        v855_6_cursor.ascend(1);
      }
      }
      v855_6_cursor.ascend(1);
    }
    }
    v855_6_cursor.ascend(1);
  }
  drop(v855_6_cursor);
  drop(v855_6_write);
  (v855_6).clone()
}

fn routine_71(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v864_6 = Space::new();
  let mut v864_6_write = v864_6.write_zipper();
  let mut v864_6_cursor = (*s0).read_zipper();
  let v864_6_origin = v864_6_cursor.path().len();
  for v864_6_byte in v864_6_cursor.child_mask().iter() {
    v864_6_cursor.descend_to_existing_byte(v864_6_byte);
    {
    for v865_2_byte in v864_6_cursor.child_mask().iter() {
      v864_6_cursor.descend_to_existing_byte(v865_2_byte);
      {
      for v866_3_byte in v864_6_cursor.child_mask().iter() {
        v864_6_cursor.descend_to_existing_byte(v866_3_byte);
        {
        for v867_3_byte in v864_6_cursor.child_mask().iter() {
          v864_6_cursor.descend_to_existing_byte(v867_3_byte);
          {
          for v868_3_byte in v864_6_cursor.child_mask().iter() {
            v864_6_cursor.descend_to_existing_byte(v868_3_byte);
            {
            for v869_2_byte in v864_6_cursor.child_mask().iter() {
              v864_6_cursor.descend_to_existing_byte(v869_2_byte);
              {
              for v870_3_byte in v864_6_cursor.child_mask().iter() {
                v864_6_cursor.descend_to_existing_byte(v870_3_byte);
                {
                for v871_3_byte in v864_6_cursor.child_mask().iter() {
                  v864_6_cursor.descend_to_existing_byte(v871_3_byte);
                  {
                  let v872_3: Space = routine_87(c, &v864_6_cursor.path()[(v864_6_origin + 4)..(v864_6_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v864_6_cursor.path()[v864_6_origin..(v864_6_origin + 4)], &v864_6_cursor);
                  join_wrapped_into(&mut v864_6_write,&((v872_3).read_zipper()),&[]);
                  }
                  v864_6_cursor.ascend(1);
                }
                }
                v864_6_cursor.ascend(1);
              }
              }
              v864_6_cursor.ascend(1);
            }
            }
            v864_6_cursor.ascend(1);
          }
          }
          v864_6_cursor.ascend(1);
        }
        }
        v864_6_cursor.ascend(1);
      }
      }
      v864_6_cursor.ascend(1);
    }
    }
    v864_6_cursor.ascend(1);
  }
  drop(v864_6_cursor);
  drop(v864_6_write);
  (v864_6).clone()
}

fn routine_72(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v873_6 = Space::new();
  let mut v873_6_write = v873_6.write_zipper();
  let mut v873_6_cursor = (*s0).read_zipper();
  let v873_6_origin = v873_6_cursor.path().len();
  for v873_6_byte in v873_6_cursor.child_mask().iter() {
    v873_6_cursor.descend_to_existing_byte(v873_6_byte);
    {
    for v874_2_byte in v873_6_cursor.child_mask().iter() {
      v873_6_cursor.descend_to_existing_byte(v874_2_byte);
      {
      for v875_3_byte in v873_6_cursor.child_mask().iter() {
        v873_6_cursor.descend_to_existing_byte(v875_3_byte);
        {
        for v876_3_byte in v873_6_cursor.child_mask().iter() {
          v873_6_cursor.descend_to_existing_byte(v876_3_byte);
          {
          for v877_3_byte in v873_6_cursor.child_mask().iter() {
            v873_6_cursor.descend_to_existing_byte(v877_3_byte);
            {
            for v878_2_byte in v873_6_cursor.child_mask().iter() {
              v873_6_cursor.descend_to_existing_byte(v878_2_byte);
              {
              for v879_3_byte in v873_6_cursor.child_mask().iter() {
                v873_6_cursor.descend_to_existing_byte(v879_3_byte);
                {
                for v880_3_byte in v873_6_cursor.child_mask().iter() {
                  v873_6_cursor.descend_to_existing_byte(v880_3_byte);
                  {
                  let v881_3: Space = routine_88(c, &v873_6_cursor.path()[(v873_6_origin + 4)..(v873_6_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v873_6_cursor.path()[v873_6_origin..(v873_6_origin + 4)], &v873_6_cursor);
                  join_wrapped_into(&mut v873_6_write,&((v881_3).read_zipper()),&[]);
                  }
                  v873_6_cursor.ascend(1);
                }
                }
                v873_6_cursor.ascend(1);
              }
              }
              v873_6_cursor.ascend(1);
            }
            }
            v873_6_cursor.ascend(1);
          }
          }
          v873_6_cursor.ascend(1);
        }
        }
        v873_6_cursor.ascend(1);
      }
      }
      v873_6_cursor.ascend(1);
    }
    }
    v873_6_cursor.ascend(1);
  }
  drop(v873_6_cursor);
  drop(v873_6_write);
  (v873_6).clone()
}

fn routine_73(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v882_6 = Space::new();
  let mut v882_6_write = v882_6.write_zipper();
  let mut v882_6_cursor = (*s0).read_zipper();
  let v882_6_origin = v882_6_cursor.path().len();
  for v882_6_byte in v882_6_cursor.child_mask().iter() {
    v882_6_cursor.descend_to_existing_byte(v882_6_byte);
    {
    for v883_2_byte in v882_6_cursor.child_mask().iter() {
      v882_6_cursor.descend_to_existing_byte(v883_2_byte);
      {
      for v884_3_byte in v882_6_cursor.child_mask().iter() {
        v882_6_cursor.descend_to_existing_byte(v884_3_byte);
        {
        for v885_3_byte in v882_6_cursor.child_mask().iter() {
          v882_6_cursor.descend_to_existing_byte(v885_3_byte);
          {
          for v886_3_byte in v882_6_cursor.child_mask().iter() {
            v882_6_cursor.descend_to_existing_byte(v886_3_byte);
            {
            for v887_2_byte in v882_6_cursor.child_mask().iter() {
              v882_6_cursor.descend_to_existing_byte(v887_2_byte);
              {
              for v888_3_byte in v882_6_cursor.child_mask().iter() {
                v882_6_cursor.descend_to_existing_byte(v888_3_byte);
                {
                for v889_3_byte in v882_6_cursor.child_mask().iter() {
                  v882_6_cursor.descend_to_existing_byte(v889_3_byte);
                  {
                  let v890_3: Space = routine_89(c, &v882_6_cursor.path()[(v882_6_origin + 4)..(v882_6_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v882_6_cursor.path()[v882_6_origin..(v882_6_origin + 4)], &v882_6_cursor);
                  join_wrapped_into(&mut v882_6_write,&((v890_3).read_zipper()),&[]);
                  }
                  v882_6_cursor.ascend(1);
                }
                }
                v882_6_cursor.ascend(1);
              }
              }
              v882_6_cursor.ascend(1);
            }
            }
            v882_6_cursor.ascend(1);
          }
          }
          v882_6_cursor.ascend(1);
        }
        }
        v882_6_cursor.ascend(1);
      }
      }
      v882_6_cursor.ascend(1);
    }
    }
    v882_6_cursor.ascend(1);
  }
  drop(v882_6_cursor);
  drop(v882_6_write);
  (v882_6).clone()
}

fn routine_74(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v891_6 = Space::new();
  let mut v891_6_write = v891_6.write_zipper();
  let mut v891_6_cursor = (*s0).read_zipper();
  let v891_6_origin = v891_6_cursor.path().len();
  for v891_6_byte in v891_6_cursor.child_mask().iter() {
    v891_6_cursor.descend_to_existing_byte(v891_6_byte);
    {
    for v892_2_byte in v891_6_cursor.child_mask().iter() {
      v891_6_cursor.descend_to_existing_byte(v892_2_byte);
      {
      for v893_3_byte in v891_6_cursor.child_mask().iter() {
        v891_6_cursor.descend_to_existing_byte(v893_3_byte);
        {
        for v894_3_byte in v891_6_cursor.child_mask().iter() {
          v891_6_cursor.descend_to_existing_byte(v894_3_byte);
          {
          for v895_3_byte in v891_6_cursor.child_mask().iter() {
            v891_6_cursor.descend_to_existing_byte(v895_3_byte);
            {
            for v896_2_byte in v891_6_cursor.child_mask().iter() {
              v891_6_cursor.descend_to_existing_byte(v896_2_byte);
              {
              for v897_3_byte in v891_6_cursor.child_mask().iter() {
                v891_6_cursor.descend_to_existing_byte(v897_3_byte);
                {
                for v898_3_byte in v891_6_cursor.child_mask().iter() {
                  v891_6_cursor.descend_to_existing_byte(v898_3_byte);
                  {
                  let v899_3: Space = routine_90(c, &v891_6_cursor.path()[(v891_6_origin + 4)..(v891_6_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v891_6_cursor.path()[v891_6_origin..(v891_6_origin + 4)], &v891_6_cursor);
                  join_wrapped_into(&mut v891_6_write,&((v899_3).read_zipper()),&[]);
                  }
                  v891_6_cursor.ascend(1);
                }
                }
                v891_6_cursor.ascend(1);
              }
              }
              v891_6_cursor.ascend(1);
            }
            }
            v891_6_cursor.ascend(1);
          }
          }
          v891_6_cursor.ascend(1);
        }
        }
        v891_6_cursor.ascend(1);
      }
      }
      v891_6_cursor.ascend(1);
    }
    }
    v891_6_cursor.ascend(1);
  }
  drop(v891_6_cursor);
  drop(v891_6_write);
  (v891_6).clone()
}

fn routine_75(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v900_6 = Space::new();
  let mut v900_6_write = v900_6.write_zipper();
  let mut v900_6_cursor = (*s0).read_zipper();
  let v900_6_origin = v900_6_cursor.path().len();
  for v900_6_byte in v900_6_cursor.child_mask().iter() {
    v900_6_cursor.descend_to_existing_byte(v900_6_byte);
    {
    for v901_2_byte in v900_6_cursor.child_mask().iter() {
      v900_6_cursor.descend_to_existing_byte(v901_2_byte);
      {
      for v902_3_byte in v900_6_cursor.child_mask().iter() {
        v900_6_cursor.descend_to_existing_byte(v902_3_byte);
        {
        for v903_3_byte in v900_6_cursor.child_mask().iter() {
          v900_6_cursor.descend_to_existing_byte(v903_3_byte);
          {
          for v904_3_byte in v900_6_cursor.child_mask().iter() {
            v900_6_cursor.descend_to_existing_byte(v904_3_byte);
            {
            for v905_2_byte in v900_6_cursor.child_mask().iter() {
              v900_6_cursor.descend_to_existing_byte(v905_2_byte);
              {
              for v906_3_byte in v900_6_cursor.child_mask().iter() {
                v900_6_cursor.descend_to_existing_byte(v906_3_byte);
                {
                for v907_3_byte in v900_6_cursor.child_mask().iter() {
                  v900_6_cursor.descend_to_existing_byte(v907_3_byte);
                  {
                  let v908_3: Space = routine_91(c, &v900_6_cursor.path()[(v900_6_origin + 4)..(v900_6_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v900_6_cursor.path()[v900_6_origin..(v900_6_origin + 4)], &v900_6_cursor);
                  join_wrapped_into(&mut v900_6_write,&((v908_3).read_zipper()),&[]);
                  }
                  v900_6_cursor.ascend(1);
                }
                }
                v900_6_cursor.ascend(1);
              }
              }
              v900_6_cursor.ascend(1);
            }
            }
            v900_6_cursor.ascend(1);
          }
          }
          v900_6_cursor.ascend(1);
        }
        }
        v900_6_cursor.ascend(1);
      }
      }
      v900_6_cursor.ascend(1);
    }
    }
    v900_6_cursor.ascend(1);
  }
  drop(v900_6_cursor);
  drop(v900_6_write);
  (v900_6).clone()
}

fn routine_76(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v909_6 = Space::new();
  let mut v909_6_write = v909_6.write_zipper();
  let mut v909_6_cursor = (*s0).read_zipper();
  let v909_6_origin = v909_6_cursor.path().len();
  for v909_6_byte in v909_6_cursor.child_mask().iter() {
    v909_6_cursor.descend_to_existing_byte(v909_6_byte);
    {
    for v910_2_byte in v909_6_cursor.child_mask().iter() {
      v909_6_cursor.descend_to_existing_byte(v910_2_byte);
      {
      for v911_3_byte in v909_6_cursor.child_mask().iter() {
        v909_6_cursor.descend_to_existing_byte(v911_3_byte);
        {
        for v912_3_byte in v909_6_cursor.child_mask().iter() {
          v909_6_cursor.descend_to_existing_byte(v912_3_byte);
          {
          for v913_3_byte in v909_6_cursor.child_mask().iter() {
            v909_6_cursor.descend_to_existing_byte(v913_3_byte);
            {
            for v914_2_byte in v909_6_cursor.child_mask().iter() {
              v909_6_cursor.descend_to_existing_byte(v914_2_byte);
              {
              for v915_3_byte in v909_6_cursor.child_mask().iter() {
                v909_6_cursor.descend_to_existing_byte(v915_3_byte);
                {
                for v916_3_byte in v909_6_cursor.child_mask().iter() {
                  v909_6_cursor.descend_to_existing_byte(v916_3_byte);
                  {
                  let v917_3: Space = routine_92(c, &v909_6_cursor.path()[(v909_6_origin + 4)..(v909_6_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v909_6_cursor.path()[v909_6_origin..(v909_6_origin + 4)], &v909_6_cursor);
                  join_wrapped_into(&mut v909_6_write,&((v917_3).read_zipper()),&[]);
                  }
                  v909_6_cursor.ascend(1);
                }
                }
                v909_6_cursor.ascend(1);
              }
              }
              v909_6_cursor.ascend(1);
            }
            }
            v909_6_cursor.ascend(1);
          }
          }
          v909_6_cursor.ascend(1);
        }
        }
        v909_6_cursor.ascend(1);
      }
      }
      v909_6_cursor.ascend(1);
    }
    }
    v909_6_cursor.ascend(1);
  }
  drop(v909_6_cursor);
  drop(v909_6_write);
  (v909_6).clone()
}

fn routine_77(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v918_6 = Space::new();
  let mut v918_6_write = v918_6.write_zipper();
  let mut v918_6_cursor = (*s0).read_zipper();
  let v918_6_origin = v918_6_cursor.path().len();
  for v918_6_byte in v918_6_cursor.child_mask().iter() {
    v918_6_cursor.descend_to_existing_byte(v918_6_byte);
    {
    for v919_2_byte in v918_6_cursor.child_mask().iter() {
      v918_6_cursor.descend_to_existing_byte(v919_2_byte);
      {
      for v920_3_byte in v918_6_cursor.child_mask().iter() {
        v918_6_cursor.descend_to_existing_byte(v920_3_byte);
        {
        for v921_3_byte in v918_6_cursor.child_mask().iter() {
          v918_6_cursor.descend_to_existing_byte(v921_3_byte);
          {
          for v922_3_byte in v918_6_cursor.child_mask().iter() {
            v918_6_cursor.descend_to_existing_byte(v922_3_byte);
            {
            for v923_2_byte in v918_6_cursor.child_mask().iter() {
              v918_6_cursor.descend_to_existing_byte(v923_2_byte);
              {
              for v924_3_byte in v918_6_cursor.child_mask().iter() {
                v918_6_cursor.descend_to_existing_byte(v924_3_byte);
                {
                for v925_3_byte in v918_6_cursor.child_mask().iter() {
                  v918_6_cursor.descend_to_existing_byte(v925_3_byte);
                  {
                  let v926_3: Space = routine_93(c, &v918_6_cursor.path()[(v918_6_origin + 4)..(v918_6_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v918_6_cursor.path()[v918_6_origin..(v918_6_origin + 4)], &v918_6_cursor);
                  join_wrapped_into(&mut v918_6_write,&((v926_3).read_zipper()),&[]);
                  }
                  v918_6_cursor.ascend(1);
                }
                }
                v918_6_cursor.ascend(1);
              }
              }
              v918_6_cursor.ascend(1);
            }
            }
            v918_6_cursor.ascend(1);
          }
          }
          v918_6_cursor.ascend(1);
        }
        }
        v918_6_cursor.ascend(1);
      }
      }
      v918_6_cursor.ascend(1);
    }
    }
    v918_6_cursor.ascend(1);
  }
  drop(v918_6_cursor);
  drop(v918_6_write);
  (v918_6).clone()
}

fn routine_78(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v927_6 = Space::new();
  let mut v927_6_write = v927_6.write_zipper();
  let mut v927_6_cursor = (*s0).read_zipper();
  let v927_6_origin = v927_6_cursor.path().len();
  for v927_6_byte in v927_6_cursor.child_mask().iter() {
    v927_6_cursor.descend_to_existing_byte(v927_6_byte);
    {
    for v928_2_byte in v927_6_cursor.child_mask().iter() {
      v927_6_cursor.descend_to_existing_byte(v928_2_byte);
      {
      for v929_3_byte in v927_6_cursor.child_mask().iter() {
        v927_6_cursor.descend_to_existing_byte(v929_3_byte);
        {
        for v930_3_byte in v927_6_cursor.child_mask().iter() {
          v927_6_cursor.descend_to_existing_byte(v930_3_byte);
          {
          for v931_3_byte in v927_6_cursor.child_mask().iter() {
            v927_6_cursor.descend_to_existing_byte(v931_3_byte);
            {
            for v932_2_byte in v927_6_cursor.child_mask().iter() {
              v927_6_cursor.descend_to_existing_byte(v932_2_byte);
              {
              for v933_3_byte in v927_6_cursor.child_mask().iter() {
                v927_6_cursor.descend_to_existing_byte(v933_3_byte);
                {
                for v934_3_byte in v927_6_cursor.child_mask().iter() {
                  v927_6_cursor.descend_to_existing_byte(v934_3_byte);
                  {
                  let v935_3: Space = routine_94(c, &v927_6_cursor.path()[(v927_6_origin + 4)..(v927_6_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v927_6_cursor.path()[v927_6_origin..(v927_6_origin + 4)], &v927_6_cursor);
                  join_wrapped_into(&mut v927_6_write,&((v935_3).read_zipper()),&[]);
                  }
                  v927_6_cursor.ascend(1);
                }
                }
                v927_6_cursor.ascend(1);
              }
              }
              v927_6_cursor.ascend(1);
            }
            }
            v927_6_cursor.ascend(1);
          }
          }
          v927_6_cursor.ascend(1);
        }
        }
        v927_6_cursor.ascend(1);
      }
      }
      v927_6_cursor.ascend(1);
    }
    }
    v927_6_cursor.ascend(1);
  }
  drop(v927_6_cursor);
  drop(v927_6_write);
  (v927_6).clone()
}

fn routine_79(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v936_8 = Space::new();
  let mut v936_8_write = v936_8.write_zipper();
  let mut v936_8_cursor = (*s0).read_zipper();
  let v936_8_origin = v936_8_cursor.path().len();
  for v936_8_byte in v936_8_cursor.child_mask().iter() {
    v936_8_cursor.descend_to_existing_byte(v936_8_byte);
    {
    for v937_2_byte in v936_8_cursor.child_mask().iter() {
      v936_8_cursor.descend_to_existing_byte(v937_2_byte);
      {
      for v938_3_byte in v936_8_cursor.child_mask().iter() {
        v936_8_cursor.descend_to_existing_byte(v938_3_byte);
        {
        for v939_3_byte in v936_8_cursor.child_mask().iter() {
          v936_8_cursor.descend_to_existing_byte(v939_3_byte);
          {
          for v940_3_byte in v936_8_cursor.child_mask().iter() {
            v936_8_cursor.descend_to_existing_byte(v940_3_byte);
            {
            for v941_2_byte in v936_8_cursor.child_mask().iter() {
              v936_8_cursor.descend_to_existing_byte(v941_2_byte);
              {
              for v942_3_byte in v936_8_cursor.child_mask().iter() {
                v936_8_cursor.descend_to_existing_byte(v942_3_byte);
                {
                for v943_3_byte in v936_8_cursor.child_mask().iter() {
                  v936_8_cursor.descend_to_existing_byte(v943_3_byte);
                  {
                  let v944_3: Space = routine_95(c, &v936_8_cursor.path()[(v936_8_origin + 4)..(v936_8_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v936_8_cursor.path()[v936_8_origin..(v936_8_origin + 4)], &v936_8_cursor);
                  join_wrapped_into(&mut v936_8_write,&((v944_3).read_zipper()),&[]);
                  }
                  v936_8_cursor.ascend(1);
                }
                }
                v936_8_cursor.ascend(1);
              }
              }
              v936_8_cursor.ascend(1);
            }
            }
            v936_8_cursor.ascend(1);
          }
          }
          v936_8_cursor.ascend(1);
        }
        }
        v936_8_cursor.ascend(1);
      }
      }
      v936_8_cursor.ascend(1);
    }
    }
    v936_8_cursor.ascend(1);
  }
  drop(v936_8_cursor);
  drop(v936_8_write);
  (v936_8).clone()
}

fn routine_80(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v945_8 = Space::new();
  let mut v945_8_write = v945_8.write_zipper();
  let mut v945_8_cursor = (*s0).read_zipper();
  let v945_8_origin = v945_8_cursor.path().len();
  for v945_8_byte in v945_8_cursor.child_mask().iter() {
    v945_8_cursor.descend_to_existing_byte(v945_8_byte);
    {
    for v946_2_byte in v945_8_cursor.child_mask().iter() {
      v945_8_cursor.descend_to_existing_byte(v946_2_byte);
      {
      for v947_3_byte in v945_8_cursor.child_mask().iter() {
        v945_8_cursor.descend_to_existing_byte(v947_3_byte);
        {
        for v948_3_byte in v945_8_cursor.child_mask().iter() {
          v945_8_cursor.descend_to_existing_byte(v948_3_byte);
          {
          for v949_3_byte in v945_8_cursor.child_mask().iter() {
            v945_8_cursor.descend_to_existing_byte(v949_3_byte);
            {
            for v950_2_byte in v945_8_cursor.child_mask().iter() {
              v945_8_cursor.descend_to_existing_byte(v950_2_byte);
              {
              for v951_3_byte in v945_8_cursor.child_mask().iter() {
                v945_8_cursor.descend_to_existing_byte(v951_3_byte);
                {
                for v952_3_byte in v945_8_cursor.child_mask().iter() {
                  v945_8_cursor.descend_to_existing_byte(v952_3_byte);
                  {
                  let v953_3: Space = routine_96(c, &v945_8_cursor.path()[(v945_8_origin + 4)..(v945_8_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v945_8_cursor.path()[v945_8_origin..(v945_8_origin + 4)], &v945_8_cursor);
                  join_wrapped_into(&mut v945_8_write,&((v953_3).read_zipper()),&[]);
                  }
                  v945_8_cursor.ascend(1);
                }
                }
                v945_8_cursor.ascend(1);
              }
              }
              v945_8_cursor.ascend(1);
            }
            }
            v945_8_cursor.ascend(1);
          }
          }
          v945_8_cursor.ascend(1);
        }
        }
        v945_8_cursor.ascend(1);
      }
      }
      v945_8_cursor.ascend(1);
    }
    }
    v945_8_cursor.ascend(1);
  }
  drop(v945_8_cursor);
  drop(v945_8_write);
  (v945_8).clone()
}

fn routine_81(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v954_8 = Space::new();
  let mut v954_8_write = v954_8.write_zipper();
  let mut v954_8_cursor = (*s0).read_zipper();
  let v954_8_origin = v954_8_cursor.path().len();
  for v954_8_byte in v954_8_cursor.child_mask().iter() {
    v954_8_cursor.descend_to_existing_byte(v954_8_byte);
    {
    for v955_2_byte in v954_8_cursor.child_mask().iter() {
      v954_8_cursor.descend_to_existing_byte(v955_2_byte);
      {
      for v956_3_byte in v954_8_cursor.child_mask().iter() {
        v954_8_cursor.descend_to_existing_byte(v956_3_byte);
        {
        for v957_3_byte in v954_8_cursor.child_mask().iter() {
          v954_8_cursor.descend_to_existing_byte(v957_3_byte);
          {
          for v958_3_byte in v954_8_cursor.child_mask().iter() {
            v954_8_cursor.descend_to_existing_byte(v958_3_byte);
            {
            for v959_2_byte in v954_8_cursor.child_mask().iter() {
              v954_8_cursor.descend_to_existing_byte(v959_2_byte);
              {
              for v960_3_byte in v954_8_cursor.child_mask().iter() {
                v954_8_cursor.descend_to_existing_byte(v960_3_byte);
                {
                for v961_3_byte in v954_8_cursor.child_mask().iter() {
                  v954_8_cursor.descend_to_existing_byte(v961_3_byte);
                  {
                  let v962_3: Space = routine_97(c, &v954_8_cursor.path()[(v954_8_origin + 4)..(v954_8_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v954_8_cursor.path()[v954_8_origin..(v954_8_origin + 4)], &v954_8_cursor);
                  join_wrapped_into(&mut v954_8_write,&((v962_3).read_zipper()),&[]);
                  }
                  v954_8_cursor.ascend(1);
                }
                }
                v954_8_cursor.ascend(1);
              }
              }
              v954_8_cursor.ascend(1);
            }
            }
            v954_8_cursor.ascend(1);
          }
          }
          v954_8_cursor.ascend(1);
        }
        }
        v954_8_cursor.ascend(1);
      }
      }
      v954_8_cursor.ascend(1);
    }
    }
    v954_8_cursor.ascend(1);
  }
  drop(v954_8_cursor);
  drop(v954_8_write);
  (v954_8).clone()
}

fn routine_82(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v963_8 = Space::new();
  let mut v963_8_write = v963_8.write_zipper();
  let mut v963_8_cursor = (*s0).read_zipper();
  let v963_8_origin = v963_8_cursor.path().len();
  for v963_8_byte in v963_8_cursor.child_mask().iter() {
    v963_8_cursor.descend_to_existing_byte(v963_8_byte);
    {
    for v964_2_byte in v963_8_cursor.child_mask().iter() {
      v963_8_cursor.descend_to_existing_byte(v964_2_byte);
      {
      for v965_3_byte in v963_8_cursor.child_mask().iter() {
        v963_8_cursor.descend_to_existing_byte(v965_3_byte);
        {
        for v966_3_byte in v963_8_cursor.child_mask().iter() {
          v963_8_cursor.descend_to_existing_byte(v966_3_byte);
          {
          for v967_3_byte in v963_8_cursor.child_mask().iter() {
            v963_8_cursor.descend_to_existing_byte(v967_3_byte);
            {
            for v968_2_byte in v963_8_cursor.child_mask().iter() {
              v963_8_cursor.descend_to_existing_byte(v968_2_byte);
              {
              for v969_3_byte in v963_8_cursor.child_mask().iter() {
                v963_8_cursor.descend_to_existing_byte(v969_3_byte);
                {
                for v970_3_byte in v963_8_cursor.child_mask().iter() {
                  v963_8_cursor.descend_to_existing_byte(v970_3_byte);
                  {
                  let v971_3: Space = routine_98(c, &v963_8_cursor.path()[(v963_8_origin + 4)..(v963_8_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v963_8_cursor.path()[v963_8_origin..(v963_8_origin + 4)], &v963_8_cursor);
                  join_wrapped_into(&mut v963_8_write,&((v971_3).read_zipper()),&[]);
                  }
                  v963_8_cursor.ascend(1);
                }
                }
                v963_8_cursor.ascend(1);
              }
              }
              v963_8_cursor.ascend(1);
            }
            }
            v963_8_cursor.ascend(1);
          }
          }
          v963_8_cursor.ascend(1);
        }
        }
        v963_8_cursor.ascend(1);
      }
      }
      v963_8_cursor.ascend(1);
    }
    }
    v963_8_cursor.ascend(1);
  }
  drop(v963_8_cursor);
  drop(v963_8_write);
  (v963_8).clone()
}

fn routine_83(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v972_8 = Space::new();
  let mut v972_8_write = v972_8.write_zipper();
  let mut v972_8_cursor = (*s0).read_zipper();
  let v972_8_origin = v972_8_cursor.path().len();
  for v972_8_byte in v972_8_cursor.child_mask().iter() {
    v972_8_cursor.descend_to_existing_byte(v972_8_byte);
    {
    for v973_2_byte in v972_8_cursor.child_mask().iter() {
      v972_8_cursor.descend_to_existing_byte(v973_2_byte);
      {
      for v974_3_byte in v972_8_cursor.child_mask().iter() {
        v972_8_cursor.descend_to_existing_byte(v974_3_byte);
        {
        for v975_3_byte in v972_8_cursor.child_mask().iter() {
          v972_8_cursor.descend_to_existing_byte(v975_3_byte);
          {
          for v976_3_byte in v972_8_cursor.child_mask().iter() {
            v972_8_cursor.descend_to_existing_byte(v976_3_byte);
            {
            for v977_2_byte in v972_8_cursor.child_mask().iter() {
              v972_8_cursor.descend_to_existing_byte(v977_2_byte);
              {
              for v978_3_byte in v972_8_cursor.child_mask().iter() {
                v972_8_cursor.descend_to_existing_byte(v978_3_byte);
                {
                for v979_3_byte in v972_8_cursor.child_mask().iter() {
                  v972_8_cursor.descend_to_existing_byte(v979_3_byte);
                  {
                  let v980_3: Space = routine_99(c, &v972_8_cursor.path()[(v972_8_origin + 4)..(v972_8_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v972_8_cursor.path()[v972_8_origin..(v972_8_origin + 4)], &v972_8_cursor);
                  join_wrapped_into(&mut v972_8_write,&((v980_3).read_zipper()),&[]);
                  }
                  v972_8_cursor.ascend(1);
                }
                }
                v972_8_cursor.ascend(1);
              }
              }
              v972_8_cursor.ascend(1);
            }
            }
            v972_8_cursor.ascend(1);
          }
          }
          v972_8_cursor.ascend(1);
        }
        }
        v972_8_cursor.ascend(1);
      }
      }
      v972_8_cursor.ascend(1);
    }
    }
    v972_8_cursor.ascend(1);
  }
  drop(v972_8_cursor);
  drop(v972_8_write);
  (v972_8).clone()
}

fn routine_84(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v981_8 = Space::new();
  let mut v981_8_write = v981_8.write_zipper();
  let mut v981_8_cursor = (*s0).read_zipper();
  let v981_8_origin = v981_8_cursor.path().len();
  for v981_8_byte in v981_8_cursor.child_mask().iter() {
    v981_8_cursor.descend_to_existing_byte(v981_8_byte);
    {
    for v982_2_byte in v981_8_cursor.child_mask().iter() {
      v981_8_cursor.descend_to_existing_byte(v982_2_byte);
      {
      for v983_3_byte in v981_8_cursor.child_mask().iter() {
        v981_8_cursor.descend_to_existing_byte(v983_3_byte);
        {
        for v984_3_byte in v981_8_cursor.child_mask().iter() {
          v981_8_cursor.descend_to_existing_byte(v984_3_byte);
          {
          for v985_3_byte in v981_8_cursor.child_mask().iter() {
            v981_8_cursor.descend_to_existing_byte(v985_3_byte);
            {
            for v986_2_byte in v981_8_cursor.child_mask().iter() {
              v981_8_cursor.descend_to_existing_byte(v986_2_byte);
              {
              for v987_3_byte in v981_8_cursor.child_mask().iter() {
                v981_8_cursor.descend_to_existing_byte(v987_3_byte);
                {
                for v988_3_byte in v981_8_cursor.child_mask().iter() {
                  v981_8_cursor.descend_to_existing_byte(v988_3_byte);
                  {
                  let v989_3: Space = routine_100(c, &v981_8_cursor.path()[(v981_8_origin + 4)..(v981_8_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v981_8_cursor.path()[v981_8_origin..(v981_8_origin + 4)], &v981_8_cursor);
                  join_wrapped_into(&mut v981_8_write,&((v989_3).read_zipper()),&[]);
                  }
                  v981_8_cursor.ascend(1);
                }
                }
                v981_8_cursor.ascend(1);
              }
              }
              v981_8_cursor.ascend(1);
            }
            }
            v981_8_cursor.ascend(1);
          }
          }
          v981_8_cursor.ascend(1);
        }
        }
        v981_8_cursor.ascend(1);
      }
      }
      v981_8_cursor.ascend(1);
    }
    }
    v981_8_cursor.ascend(1);
  }
  drop(v981_8_cursor);
  drop(v981_8_write);
  (v981_8).clone()
}

fn routine_85(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v990_8 = Space::new();
  let mut v990_8_write = v990_8.write_zipper();
  let mut v990_8_cursor = (*s0).read_zipper();
  let v990_8_origin = v990_8_cursor.path().len();
  for v990_8_byte in v990_8_cursor.child_mask().iter() {
    v990_8_cursor.descend_to_existing_byte(v990_8_byte);
    {
    for v991_2_byte in v990_8_cursor.child_mask().iter() {
      v990_8_cursor.descend_to_existing_byte(v991_2_byte);
      {
      for v992_3_byte in v990_8_cursor.child_mask().iter() {
        v990_8_cursor.descend_to_existing_byte(v992_3_byte);
        {
        for v993_3_byte in v990_8_cursor.child_mask().iter() {
          v990_8_cursor.descend_to_existing_byte(v993_3_byte);
          {
          for v994_3_byte in v990_8_cursor.child_mask().iter() {
            v990_8_cursor.descend_to_existing_byte(v994_3_byte);
            {
            for v995_2_byte in v990_8_cursor.child_mask().iter() {
              v990_8_cursor.descend_to_existing_byte(v995_2_byte);
              {
              for v996_3_byte in v990_8_cursor.child_mask().iter() {
                v990_8_cursor.descend_to_existing_byte(v996_3_byte);
                {
                for v997_3_byte in v990_8_cursor.child_mask().iter() {
                  v990_8_cursor.descend_to_existing_byte(v997_3_byte);
                  {
                  let v998_3: Space = routine_101(c, &v990_8_cursor.path()[(v990_8_origin + 4)..(v990_8_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v990_8_cursor.path()[v990_8_origin..(v990_8_origin + 4)], &v990_8_cursor);
                  join_wrapped_into(&mut v990_8_write,&((v998_3).read_zipper()),&[]);
                  }
                  v990_8_cursor.ascend(1);
                }
                }
                v990_8_cursor.ascend(1);
              }
              }
              v990_8_cursor.ascend(1);
            }
            }
            v990_8_cursor.ascend(1);
          }
          }
          v990_8_cursor.ascend(1);
        }
        }
        v990_8_cursor.ascend(1);
      }
      }
      v990_8_cursor.ascend(1);
    }
    }
    v990_8_cursor.ascend(1);
  }
  drop(v990_8_cursor);
  drop(v990_8_write);
  (v990_8).clone()
}

fn routine_86(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v999_8 = Space::new();
  let mut v999_8_write = v999_8.write_zipper();
  let mut v999_8_cursor = (*s0).read_zipper();
  let v999_8_origin = v999_8_cursor.path().len();
  for v999_8_byte in v999_8_cursor.child_mask().iter() {
    v999_8_cursor.descend_to_existing_byte(v999_8_byte);
    {
    for v1000_2_byte in v999_8_cursor.child_mask().iter() {
      v999_8_cursor.descend_to_existing_byte(v1000_2_byte);
      {
      for v1001_3_byte in v999_8_cursor.child_mask().iter() {
        v999_8_cursor.descend_to_existing_byte(v1001_3_byte);
        {
        for v1002_3_byte in v999_8_cursor.child_mask().iter() {
          v999_8_cursor.descend_to_existing_byte(v1002_3_byte);
          {
          for v1003_3_byte in v999_8_cursor.child_mask().iter() {
            v999_8_cursor.descend_to_existing_byte(v1003_3_byte);
            {
            for v1004_2_byte in v999_8_cursor.child_mask().iter() {
              v999_8_cursor.descend_to_existing_byte(v1004_2_byte);
              {
              for v1005_3_byte in v999_8_cursor.child_mask().iter() {
                v999_8_cursor.descend_to_existing_byte(v1005_3_byte);
                {
                for v1006_3_byte in v999_8_cursor.child_mask().iter() {
                  v999_8_cursor.descend_to_existing_byte(v1006_3_byte);
                  {
                  let v1007_3: Space = routine_102(c, &v999_8_cursor.path()[(v999_8_origin + 4)..(v999_8_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v999_8_cursor.path()[v999_8_origin..(v999_8_origin + 4)], &v999_8_cursor);
                  join_wrapped_into(&mut v999_8_write,&((v1007_3).read_zipper()),&[]);
                  }
                  v999_8_cursor.ascend(1);
                }
                }
                v999_8_cursor.ascend(1);
              }
              }
              v999_8_cursor.ascend(1);
            }
            }
            v999_8_cursor.ascend(1);
          }
          }
          v999_8_cursor.ascend(1);
        }
        }
        v999_8_cursor.ascend(1);
      }
      }
      v999_8_cursor.ascend(1);
    }
    }
    v999_8_cursor.ascend(1);
  }
  drop(v999_8_cursor);
  drop(v999_8_write);
  (v999_8).clone()
}

fn routine_87(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1008_8 = Space::new();
  let mut v1008_8_write = v1008_8.write_zipper();
  let mut v1008_8_cursor = (*s0).read_zipper();
  let v1008_8_origin = v1008_8_cursor.path().len();
  for v1008_8_byte in v1008_8_cursor.child_mask().iter() {
    v1008_8_cursor.descend_to_existing_byte(v1008_8_byte);
    {
    for v1009_2_byte in v1008_8_cursor.child_mask().iter() {
      v1008_8_cursor.descend_to_existing_byte(v1009_2_byte);
      {
      for v1010_3_byte in v1008_8_cursor.child_mask().iter() {
        v1008_8_cursor.descend_to_existing_byte(v1010_3_byte);
        {
        for v1011_3_byte in v1008_8_cursor.child_mask().iter() {
          v1008_8_cursor.descend_to_existing_byte(v1011_3_byte);
          {
          for v1012_3_byte in v1008_8_cursor.child_mask().iter() {
            v1008_8_cursor.descend_to_existing_byte(v1012_3_byte);
            {
            for v1013_2_byte in v1008_8_cursor.child_mask().iter() {
              v1008_8_cursor.descend_to_existing_byte(v1013_2_byte);
              {
              for v1014_3_byte in v1008_8_cursor.child_mask().iter() {
                v1008_8_cursor.descend_to_existing_byte(v1014_3_byte);
                {
                for v1015_3_byte in v1008_8_cursor.child_mask().iter() {
                  v1008_8_cursor.descend_to_existing_byte(v1015_3_byte);
                  {
                  let v1016_3: Space = routine_103(c, &v1008_8_cursor.path()[(v1008_8_origin + 4)..(v1008_8_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v1008_8_cursor.path()[v1008_8_origin..(v1008_8_origin + 4)], &v1008_8_cursor);
                  join_wrapped_into(&mut v1008_8_write,&((v1016_3).read_zipper()),&[]);
                  }
                  v1008_8_cursor.ascend(1);
                }
                }
                v1008_8_cursor.ascend(1);
              }
              }
              v1008_8_cursor.ascend(1);
            }
            }
            v1008_8_cursor.ascend(1);
          }
          }
          v1008_8_cursor.ascend(1);
        }
        }
        v1008_8_cursor.ascend(1);
      }
      }
      v1008_8_cursor.ascend(1);
    }
    }
    v1008_8_cursor.ascend(1);
  }
  drop(v1008_8_cursor);
  drop(v1008_8_write);
  (v1008_8).clone()
}

fn routine_88(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1017_8 = Space::new();
  let mut v1017_8_write = v1017_8.write_zipper();
  let mut v1017_8_cursor = (*s0).read_zipper();
  let v1017_8_origin = v1017_8_cursor.path().len();
  for v1017_8_byte in v1017_8_cursor.child_mask().iter() {
    v1017_8_cursor.descend_to_existing_byte(v1017_8_byte);
    {
    for v1018_2_byte in v1017_8_cursor.child_mask().iter() {
      v1017_8_cursor.descend_to_existing_byte(v1018_2_byte);
      {
      for v1019_3_byte in v1017_8_cursor.child_mask().iter() {
        v1017_8_cursor.descend_to_existing_byte(v1019_3_byte);
        {
        for v1020_3_byte in v1017_8_cursor.child_mask().iter() {
          v1017_8_cursor.descend_to_existing_byte(v1020_3_byte);
          {
          for v1021_3_byte in v1017_8_cursor.child_mask().iter() {
            v1017_8_cursor.descend_to_existing_byte(v1021_3_byte);
            {
            for v1022_2_byte in v1017_8_cursor.child_mask().iter() {
              v1017_8_cursor.descend_to_existing_byte(v1022_2_byte);
              {
              for v1023_3_byte in v1017_8_cursor.child_mask().iter() {
                v1017_8_cursor.descend_to_existing_byte(v1023_3_byte);
                {
                for v1024_3_byte in v1017_8_cursor.child_mask().iter() {
                  v1017_8_cursor.descend_to_existing_byte(v1024_3_byte);
                  {
                  let v1025_3: Space = routine_104(c, &v1017_8_cursor.path()[(v1017_8_origin + 4)..(v1017_8_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v1017_8_cursor.path()[v1017_8_origin..(v1017_8_origin + 4)], &v1017_8_cursor);
                  join_wrapped_into(&mut v1017_8_write,&((v1025_3).read_zipper()),&[]);
                  }
                  v1017_8_cursor.ascend(1);
                }
                }
                v1017_8_cursor.ascend(1);
              }
              }
              v1017_8_cursor.ascend(1);
            }
            }
            v1017_8_cursor.ascend(1);
          }
          }
          v1017_8_cursor.ascend(1);
        }
        }
        v1017_8_cursor.ascend(1);
      }
      }
      v1017_8_cursor.ascend(1);
    }
    }
    v1017_8_cursor.ascend(1);
  }
  drop(v1017_8_cursor);
  drop(v1017_8_write);
  (v1017_8).clone()
}

fn routine_89(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1026_8 = Space::new();
  let mut v1026_8_write = v1026_8.write_zipper();
  let mut v1026_8_cursor = (*s0).read_zipper();
  let v1026_8_origin = v1026_8_cursor.path().len();
  for v1026_8_byte in v1026_8_cursor.child_mask().iter() {
    v1026_8_cursor.descend_to_existing_byte(v1026_8_byte);
    {
    for v1027_2_byte in v1026_8_cursor.child_mask().iter() {
      v1026_8_cursor.descend_to_existing_byte(v1027_2_byte);
      {
      for v1028_3_byte in v1026_8_cursor.child_mask().iter() {
        v1026_8_cursor.descend_to_existing_byte(v1028_3_byte);
        {
        for v1029_3_byte in v1026_8_cursor.child_mask().iter() {
          v1026_8_cursor.descend_to_existing_byte(v1029_3_byte);
          {
          for v1030_3_byte in v1026_8_cursor.child_mask().iter() {
            v1026_8_cursor.descend_to_existing_byte(v1030_3_byte);
            {
            for v1031_2_byte in v1026_8_cursor.child_mask().iter() {
              v1026_8_cursor.descend_to_existing_byte(v1031_2_byte);
              {
              for v1032_3_byte in v1026_8_cursor.child_mask().iter() {
                v1026_8_cursor.descend_to_existing_byte(v1032_3_byte);
                {
                for v1033_3_byte in v1026_8_cursor.child_mask().iter() {
                  v1026_8_cursor.descend_to_existing_byte(v1033_3_byte);
                  {
                  let v1034_3: Space = routine_105(c, &v1026_8_cursor.path()[(v1026_8_origin + 4)..(v1026_8_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v1026_8_cursor.path()[v1026_8_origin..(v1026_8_origin + 4)], &v1026_8_cursor);
                  join_wrapped_into(&mut v1026_8_write,&((v1034_3).read_zipper()),&[]);
                  }
                  v1026_8_cursor.ascend(1);
                }
                }
                v1026_8_cursor.ascend(1);
              }
              }
              v1026_8_cursor.ascend(1);
            }
            }
            v1026_8_cursor.ascend(1);
          }
          }
          v1026_8_cursor.ascend(1);
        }
        }
        v1026_8_cursor.ascend(1);
      }
      }
      v1026_8_cursor.ascend(1);
    }
    }
    v1026_8_cursor.ascend(1);
  }
  drop(v1026_8_cursor);
  drop(v1026_8_write);
  (v1026_8).clone()
}

fn routine_90(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1035_8 = Space::new();
  let mut v1035_8_write = v1035_8.write_zipper();
  let mut v1035_8_cursor = (*s0).read_zipper();
  let v1035_8_origin = v1035_8_cursor.path().len();
  for v1035_8_byte in v1035_8_cursor.child_mask().iter() {
    v1035_8_cursor.descend_to_existing_byte(v1035_8_byte);
    {
    for v1036_2_byte in v1035_8_cursor.child_mask().iter() {
      v1035_8_cursor.descend_to_existing_byte(v1036_2_byte);
      {
      for v1037_3_byte in v1035_8_cursor.child_mask().iter() {
        v1035_8_cursor.descend_to_existing_byte(v1037_3_byte);
        {
        for v1038_3_byte in v1035_8_cursor.child_mask().iter() {
          v1035_8_cursor.descend_to_existing_byte(v1038_3_byte);
          {
          for v1039_3_byte in v1035_8_cursor.child_mask().iter() {
            v1035_8_cursor.descend_to_existing_byte(v1039_3_byte);
            {
            for v1040_2_byte in v1035_8_cursor.child_mask().iter() {
              v1035_8_cursor.descend_to_existing_byte(v1040_2_byte);
              {
              for v1041_3_byte in v1035_8_cursor.child_mask().iter() {
                v1035_8_cursor.descend_to_existing_byte(v1041_3_byte);
                {
                for v1042_3_byte in v1035_8_cursor.child_mask().iter() {
                  v1035_8_cursor.descend_to_existing_byte(v1042_3_byte);
                  {
                  let v1043_3: Space = routine_106(c, &v1035_8_cursor.path()[(v1035_8_origin + 4)..(v1035_8_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v1035_8_cursor.path()[v1035_8_origin..(v1035_8_origin + 4)], &v1035_8_cursor);
                  join_wrapped_into(&mut v1035_8_write,&((v1043_3).read_zipper()),&[]);
                  }
                  v1035_8_cursor.ascend(1);
                }
                }
                v1035_8_cursor.ascend(1);
              }
              }
              v1035_8_cursor.ascend(1);
            }
            }
            v1035_8_cursor.ascend(1);
          }
          }
          v1035_8_cursor.ascend(1);
        }
        }
        v1035_8_cursor.ascend(1);
      }
      }
      v1035_8_cursor.ascend(1);
    }
    }
    v1035_8_cursor.ascend(1);
  }
  drop(v1035_8_cursor);
  drop(v1035_8_write);
  (v1035_8).clone()
}

fn routine_91(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1044_8 = Space::new();
  let mut v1044_8_write = v1044_8.write_zipper();
  let mut v1044_8_cursor = (*s0).read_zipper();
  let v1044_8_origin = v1044_8_cursor.path().len();
  for v1044_8_byte in v1044_8_cursor.child_mask().iter() {
    v1044_8_cursor.descend_to_existing_byte(v1044_8_byte);
    {
    for v1045_2_byte in v1044_8_cursor.child_mask().iter() {
      v1044_8_cursor.descend_to_existing_byte(v1045_2_byte);
      {
      for v1046_3_byte in v1044_8_cursor.child_mask().iter() {
        v1044_8_cursor.descend_to_existing_byte(v1046_3_byte);
        {
        for v1047_3_byte in v1044_8_cursor.child_mask().iter() {
          v1044_8_cursor.descend_to_existing_byte(v1047_3_byte);
          {
          for v1048_3_byte in v1044_8_cursor.child_mask().iter() {
            v1044_8_cursor.descend_to_existing_byte(v1048_3_byte);
            {
            for v1049_2_byte in v1044_8_cursor.child_mask().iter() {
              v1044_8_cursor.descend_to_existing_byte(v1049_2_byte);
              {
              for v1050_3_byte in v1044_8_cursor.child_mask().iter() {
                v1044_8_cursor.descend_to_existing_byte(v1050_3_byte);
                {
                for v1051_3_byte in v1044_8_cursor.child_mask().iter() {
                  v1044_8_cursor.descend_to_existing_byte(v1051_3_byte);
                  {
                  let v1052_3: Space = routine_107(c, &v1044_8_cursor.path()[(v1044_8_origin + 4)..(v1044_8_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v1044_8_cursor.path()[v1044_8_origin..(v1044_8_origin + 4)], &v1044_8_cursor);
                  join_wrapped_into(&mut v1044_8_write,&((v1052_3).read_zipper()),&[]);
                  }
                  v1044_8_cursor.ascend(1);
                }
                }
                v1044_8_cursor.ascend(1);
              }
              }
              v1044_8_cursor.ascend(1);
            }
            }
            v1044_8_cursor.ascend(1);
          }
          }
          v1044_8_cursor.ascend(1);
        }
        }
        v1044_8_cursor.ascend(1);
      }
      }
      v1044_8_cursor.ascend(1);
    }
    }
    v1044_8_cursor.ascend(1);
  }
  drop(v1044_8_cursor);
  drop(v1044_8_write);
  (v1044_8).clone()
}

fn routine_92(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1053_8 = Space::new();
  let mut v1053_8_write = v1053_8.write_zipper();
  let mut v1053_8_cursor = (*s0).read_zipper();
  let v1053_8_origin = v1053_8_cursor.path().len();
  for v1053_8_byte in v1053_8_cursor.child_mask().iter() {
    v1053_8_cursor.descend_to_existing_byte(v1053_8_byte);
    {
    for v1054_2_byte in v1053_8_cursor.child_mask().iter() {
      v1053_8_cursor.descend_to_existing_byte(v1054_2_byte);
      {
      for v1055_3_byte in v1053_8_cursor.child_mask().iter() {
        v1053_8_cursor.descend_to_existing_byte(v1055_3_byte);
        {
        for v1056_3_byte in v1053_8_cursor.child_mask().iter() {
          v1053_8_cursor.descend_to_existing_byte(v1056_3_byte);
          {
          for v1057_3_byte in v1053_8_cursor.child_mask().iter() {
            v1053_8_cursor.descend_to_existing_byte(v1057_3_byte);
            {
            for v1058_2_byte in v1053_8_cursor.child_mask().iter() {
              v1053_8_cursor.descend_to_existing_byte(v1058_2_byte);
              {
              for v1059_3_byte in v1053_8_cursor.child_mask().iter() {
                v1053_8_cursor.descend_to_existing_byte(v1059_3_byte);
                {
                for v1060_3_byte in v1053_8_cursor.child_mask().iter() {
                  v1053_8_cursor.descend_to_existing_byte(v1060_3_byte);
                  {
                  let v1061_3: Space = routine_108(c, &v1053_8_cursor.path()[(v1053_8_origin + 4)..(v1053_8_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v1053_8_cursor.path()[v1053_8_origin..(v1053_8_origin + 4)], &v1053_8_cursor);
                  join_wrapped_into(&mut v1053_8_write,&((v1061_3).read_zipper()),&[]);
                  }
                  v1053_8_cursor.ascend(1);
                }
                }
                v1053_8_cursor.ascend(1);
              }
              }
              v1053_8_cursor.ascend(1);
            }
            }
            v1053_8_cursor.ascend(1);
          }
          }
          v1053_8_cursor.ascend(1);
        }
        }
        v1053_8_cursor.ascend(1);
      }
      }
      v1053_8_cursor.ascend(1);
    }
    }
    v1053_8_cursor.ascend(1);
  }
  drop(v1053_8_cursor);
  drop(v1053_8_write);
  (v1053_8).clone()
}

fn routine_93(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1062_8 = Space::new();
  let mut v1062_8_write = v1062_8.write_zipper();
  let mut v1062_8_cursor = (*s0).read_zipper();
  let v1062_8_origin = v1062_8_cursor.path().len();
  for v1062_8_byte in v1062_8_cursor.child_mask().iter() {
    v1062_8_cursor.descend_to_existing_byte(v1062_8_byte);
    {
    for v1063_2_byte in v1062_8_cursor.child_mask().iter() {
      v1062_8_cursor.descend_to_existing_byte(v1063_2_byte);
      {
      for v1064_3_byte in v1062_8_cursor.child_mask().iter() {
        v1062_8_cursor.descend_to_existing_byte(v1064_3_byte);
        {
        for v1065_3_byte in v1062_8_cursor.child_mask().iter() {
          v1062_8_cursor.descend_to_existing_byte(v1065_3_byte);
          {
          for v1066_3_byte in v1062_8_cursor.child_mask().iter() {
            v1062_8_cursor.descend_to_existing_byte(v1066_3_byte);
            {
            for v1067_2_byte in v1062_8_cursor.child_mask().iter() {
              v1062_8_cursor.descend_to_existing_byte(v1067_2_byte);
              {
              for v1068_3_byte in v1062_8_cursor.child_mask().iter() {
                v1062_8_cursor.descend_to_existing_byte(v1068_3_byte);
                {
                for v1069_3_byte in v1062_8_cursor.child_mask().iter() {
                  v1062_8_cursor.descend_to_existing_byte(v1069_3_byte);
                  {
                  let v1070_3: Space = routine_109(c, &v1062_8_cursor.path()[(v1062_8_origin + 4)..(v1062_8_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v1062_8_cursor.path()[v1062_8_origin..(v1062_8_origin + 4)], &v1062_8_cursor);
                  join_wrapped_into(&mut v1062_8_write,&((v1070_3).read_zipper()),&[]);
                  }
                  v1062_8_cursor.ascend(1);
                }
                }
                v1062_8_cursor.ascend(1);
              }
              }
              v1062_8_cursor.ascend(1);
            }
            }
            v1062_8_cursor.ascend(1);
          }
          }
          v1062_8_cursor.ascend(1);
        }
        }
        v1062_8_cursor.ascend(1);
      }
      }
      v1062_8_cursor.ascend(1);
    }
    }
    v1062_8_cursor.ascend(1);
  }
  drop(v1062_8_cursor);
  drop(v1062_8_write);
  (v1062_8).clone()
}

fn routine_94(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1071_8 = Space::new();
  let mut v1071_8_write = v1071_8.write_zipper();
  let mut v1071_8_cursor = (*s0).read_zipper();
  let v1071_8_origin = v1071_8_cursor.path().len();
  for v1071_8_byte in v1071_8_cursor.child_mask().iter() {
    v1071_8_cursor.descend_to_existing_byte(v1071_8_byte);
    {
    for v1072_2_byte in v1071_8_cursor.child_mask().iter() {
      v1071_8_cursor.descend_to_existing_byte(v1072_2_byte);
      {
      for v1073_3_byte in v1071_8_cursor.child_mask().iter() {
        v1071_8_cursor.descend_to_existing_byte(v1073_3_byte);
        {
        for v1074_3_byte in v1071_8_cursor.child_mask().iter() {
          v1071_8_cursor.descend_to_existing_byte(v1074_3_byte);
          {
          for v1075_3_byte in v1071_8_cursor.child_mask().iter() {
            v1071_8_cursor.descend_to_existing_byte(v1075_3_byte);
            {
            for v1076_2_byte in v1071_8_cursor.child_mask().iter() {
              v1071_8_cursor.descend_to_existing_byte(v1076_2_byte);
              {
              for v1077_3_byte in v1071_8_cursor.child_mask().iter() {
                v1071_8_cursor.descend_to_existing_byte(v1077_3_byte);
                {
                for v1078_3_byte in v1071_8_cursor.child_mask().iter() {
                  v1071_8_cursor.descend_to_existing_byte(v1078_3_byte);
                  {
                  let v1079_3: Space = routine_110(c, &v1071_8_cursor.path()[(v1071_8_origin + 4)..(v1071_8_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v1071_8_cursor.path()[v1071_8_origin..(v1071_8_origin + 4)], &v1071_8_cursor);
                  join_wrapped_into(&mut v1071_8_write,&((v1079_3).read_zipper()),&[]);
                  }
                  v1071_8_cursor.ascend(1);
                }
                }
                v1071_8_cursor.ascend(1);
              }
              }
              v1071_8_cursor.ascend(1);
            }
            }
            v1071_8_cursor.ascend(1);
          }
          }
          v1071_8_cursor.ascend(1);
        }
        }
        v1071_8_cursor.ascend(1);
      }
      }
      v1071_8_cursor.ascend(1);
    }
    }
    v1071_8_cursor.ascend(1);
  }
  drop(v1071_8_cursor);
  drop(v1071_8_write);
  (v1071_8).clone()
}

fn routine_95(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1080_10 = Space::new();
  let mut v1080_10_write = v1080_10.write_zipper();
  let mut v1080_10_cursor = (*s0).read_zipper();
  let v1080_10_origin = v1080_10_cursor.path().len();
  for v1080_10_byte in v1080_10_cursor.child_mask().iter() {
    v1080_10_cursor.descend_to_existing_byte(v1080_10_byte);
    {
    for v1081_2_byte in v1080_10_cursor.child_mask().iter() {
      v1080_10_cursor.descend_to_existing_byte(v1081_2_byte);
      {
      for v1082_3_byte in v1080_10_cursor.child_mask().iter() {
        v1080_10_cursor.descend_to_existing_byte(v1082_3_byte);
        {
        for v1083_3_byte in v1080_10_cursor.child_mask().iter() {
          v1080_10_cursor.descend_to_existing_byte(v1083_3_byte);
          {
          for v1084_3_byte in v1080_10_cursor.child_mask().iter() {
            v1080_10_cursor.descend_to_existing_byte(v1084_3_byte);
            {
            for v1085_2_byte in v1080_10_cursor.child_mask().iter() {
              v1080_10_cursor.descend_to_existing_byte(v1085_2_byte);
              {
              for v1086_3_byte in v1080_10_cursor.child_mask().iter() {
                v1080_10_cursor.descend_to_existing_byte(v1086_3_byte);
                {
                for v1087_3_byte in v1080_10_cursor.child_mask().iter() {
                  v1080_10_cursor.descend_to_existing_byte(v1087_3_byte);
                  {
                  let v1088_3: Space = routine_111(c, &v1080_10_cursor.path()[(v1080_10_origin + 4)..(v1080_10_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &v1080_10_cursor.path()[v1080_10_origin..(v1080_10_origin + 4)], &v1080_10_cursor);
                  join_wrapped_into(&mut v1080_10_write,&((v1088_3).read_zipper()),&[]);
                  }
                  v1080_10_cursor.ascend(1);
                }
                }
                v1080_10_cursor.ascend(1);
              }
              }
              v1080_10_cursor.ascend(1);
            }
            }
            v1080_10_cursor.ascend(1);
          }
          }
          v1080_10_cursor.ascend(1);
        }
        }
        v1080_10_cursor.ascend(1);
      }
      }
      v1080_10_cursor.ascend(1);
    }
    }
    v1080_10_cursor.ascend(1);
  }
  drop(v1080_10_cursor);
  drop(v1080_10_write);
  (v1080_10).clone()
}

fn routine_96(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1089_10 = Space::new();
  let mut v1089_10_write = v1089_10.write_zipper();
  let mut v1089_10_cursor = (*s0).read_zipper();
  let v1089_10_origin = v1089_10_cursor.path().len();
  for v1089_10_byte in v1089_10_cursor.child_mask().iter() {
    v1089_10_cursor.descend_to_existing_byte(v1089_10_byte);
    {
    for v1090_2_byte in v1089_10_cursor.child_mask().iter() {
      v1089_10_cursor.descend_to_existing_byte(v1090_2_byte);
      {
      for v1091_3_byte in v1089_10_cursor.child_mask().iter() {
        v1089_10_cursor.descend_to_existing_byte(v1091_3_byte);
        {
        for v1092_3_byte in v1089_10_cursor.child_mask().iter() {
          v1089_10_cursor.descend_to_existing_byte(v1092_3_byte);
          {
          for v1093_3_byte in v1089_10_cursor.child_mask().iter() {
            v1089_10_cursor.descend_to_existing_byte(v1093_3_byte);
            {
            for v1094_2_byte in v1089_10_cursor.child_mask().iter() {
              v1089_10_cursor.descend_to_existing_byte(v1094_2_byte);
              {
              for v1095_3_byte in v1089_10_cursor.child_mask().iter() {
                v1089_10_cursor.descend_to_existing_byte(v1095_3_byte);
                {
                for v1096_3_byte in v1089_10_cursor.child_mask().iter() {
                  v1089_10_cursor.descend_to_existing_byte(v1096_3_byte);
                  {
                  let v1097_3: Space = routine_112(c, &v1089_10_cursor.path()[(v1089_10_origin + 4)..(v1089_10_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &v1089_10_cursor.path()[v1089_10_origin..(v1089_10_origin + 4)], &v1089_10_cursor);
                  join_wrapped_into(&mut v1089_10_write,&((v1097_3).read_zipper()),&[]);
                  }
                  v1089_10_cursor.ascend(1);
                }
                }
                v1089_10_cursor.ascend(1);
              }
              }
              v1089_10_cursor.ascend(1);
            }
            }
            v1089_10_cursor.ascend(1);
          }
          }
          v1089_10_cursor.ascend(1);
        }
        }
        v1089_10_cursor.ascend(1);
      }
      }
      v1089_10_cursor.ascend(1);
    }
    }
    v1089_10_cursor.ascend(1);
  }
  drop(v1089_10_cursor);
  drop(v1089_10_write);
  (v1089_10).clone()
}

fn routine_97(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1098_10 = Space::new();
  let mut v1098_10_write = v1098_10.write_zipper();
  let mut v1098_10_cursor = (*s0).read_zipper();
  let v1098_10_origin = v1098_10_cursor.path().len();
  for v1098_10_byte in v1098_10_cursor.child_mask().iter() {
    v1098_10_cursor.descend_to_existing_byte(v1098_10_byte);
    {
    for v1099_2_byte in v1098_10_cursor.child_mask().iter() {
      v1098_10_cursor.descend_to_existing_byte(v1099_2_byte);
      {
      for v1100_3_byte in v1098_10_cursor.child_mask().iter() {
        v1098_10_cursor.descend_to_existing_byte(v1100_3_byte);
        {
        for v1101_3_byte in v1098_10_cursor.child_mask().iter() {
          v1098_10_cursor.descend_to_existing_byte(v1101_3_byte);
          {
          for v1102_3_byte in v1098_10_cursor.child_mask().iter() {
            v1098_10_cursor.descend_to_existing_byte(v1102_3_byte);
            {
            for v1103_2_byte in v1098_10_cursor.child_mask().iter() {
              v1098_10_cursor.descend_to_existing_byte(v1103_2_byte);
              {
              for v1104_3_byte in v1098_10_cursor.child_mask().iter() {
                v1098_10_cursor.descend_to_existing_byte(v1104_3_byte);
                {
                for v1105_3_byte in v1098_10_cursor.child_mask().iter() {
                  v1098_10_cursor.descend_to_existing_byte(v1105_3_byte);
                  {
                  let v1106_3: Space = routine_113(c, &v1098_10_cursor.path()[(v1098_10_origin + 4)..(v1098_10_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &v1098_10_cursor.path()[v1098_10_origin..(v1098_10_origin + 4)], &v1098_10_cursor);
                  join_wrapped_into(&mut v1098_10_write,&((v1106_3).read_zipper()),&[]);
                  }
                  v1098_10_cursor.ascend(1);
                }
                }
                v1098_10_cursor.ascend(1);
              }
              }
              v1098_10_cursor.ascend(1);
            }
            }
            v1098_10_cursor.ascend(1);
          }
          }
          v1098_10_cursor.ascend(1);
        }
        }
        v1098_10_cursor.ascend(1);
      }
      }
      v1098_10_cursor.ascend(1);
    }
    }
    v1098_10_cursor.ascend(1);
  }
  drop(v1098_10_cursor);
  drop(v1098_10_write);
  (v1098_10).clone()
}

fn routine_98(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1107_10 = Space::new();
  let mut v1107_10_write = v1107_10.write_zipper();
  let mut v1107_10_cursor = (*s0).read_zipper();
  let v1107_10_origin = v1107_10_cursor.path().len();
  for v1107_10_byte in v1107_10_cursor.child_mask().iter() {
    v1107_10_cursor.descend_to_existing_byte(v1107_10_byte);
    {
    for v1108_2_byte in v1107_10_cursor.child_mask().iter() {
      v1107_10_cursor.descend_to_existing_byte(v1108_2_byte);
      {
      for v1109_3_byte in v1107_10_cursor.child_mask().iter() {
        v1107_10_cursor.descend_to_existing_byte(v1109_3_byte);
        {
        for v1110_3_byte in v1107_10_cursor.child_mask().iter() {
          v1107_10_cursor.descend_to_existing_byte(v1110_3_byte);
          {
          for v1111_3_byte in v1107_10_cursor.child_mask().iter() {
            v1107_10_cursor.descend_to_existing_byte(v1111_3_byte);
            {
            for v1112_2_byte in v1107_10_cursor.child_mask().iter() {
              v1107_10_cursor.descend_to_existing_byte(v1112_2_byte);
              {
              for v1113_3_byte in v1107_10_cursor.child_mask().iter() {
                v1107_10_cursor.descend_to_existing_byte(v1113_3_byte);
                {
                for v1114_3_byte in v1107_10_cursor.child_mask().iter() {
                  v1107_10_cursor.descend_to_existing_byte(v1114_3_byte);
                  {
                  let v1115_3: Space = routine_114(c, &v1107_10_cursor.path()[(v1107_10_origin + 4)..(v1107_10_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &v1107_10_cursor.path()[v1107_10_origin..(v1107_10_origin + 4)], &v1107_10_cursor);
                  join_wrapped_into(&mut v1107_10_write,&((v1115_3).read_zipper()),&[]);
                  }
                  v1107_10_cursor.ascend(1);
                }
                }
                v1107_10_cursor.ascend(1);
              }
              }
              v1107_10_cursor.ascend(1);
            }
            }
            v1107_10_cursor.ascend(1);
          }
          }
          v1107_10_cursor.ascend(1);
        }
        }
        v1107_10_cursor.ascend(1);
      }
      }
      v1107_10_cursor.ascend(1);
    }
    }
    v1107_10_cursor.ascend(1);
  }
  drop(v1107_10_cursor);
  drop(v1107_10_write);
  (v1107_10).clone()
}

fn routine_99(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1116_10 = Space::new();
  let mut v1116_10_write = v1116_10.write_zipper();
  let mut v1116_10_cursor = (*s0).read_zipper();
  let v1116_10_origin = v1116_10_cursor.path().len();
  for v1116_10_byte in v1116_10_cursor.child_mask().iter() {
    v1116_10_cursor.descend_to_existing_byte(v1116_10_byte);
    {
    for v1117_2_byte in v1116_10_cursor.child_mask().iter() {
      v1116_10_cursor.descend_to_existing_byte(v1117_2_byte);
      {
      for v1118_3_byte in v1116_10_cursor.child_mask().iter() {
        v1116_10_cursor.descend_to_existing_byte(v1118_3_byte);
        {
        for v1119_3_byte in v1116_10_cursor.child_mask().iter() {
          v1116_10_cursor.descend_to_existing_byte(v1119_3_byte);
          {
          for v1120_3_byte in v1116_10_cursor.child_mask().iter() {
            v1116_10_cursor.descend_to_existing_byte(v1120_3_byte);
            {
            for v1121_2_byte in v1116_10_cursor.child_mask().iter() {
              v1116_10_cursor.descend_to_existing_byte(v1121_2_byte);
              {
              for v1122_3_byte in v1116_10_cursor.child_mask().iter() {
                v1116_10_cursor.descend_to_existing_byte(v1122_3_byte);
                {
                for v1123_3_byte in v1116_10_cursor.child_mask().iter() {
                  v1116_10_cursor.descend_to_existing_byte(v1123_3_byte);
                  {
                  let v1124_3: Space = routine_115(c, &v1116_10_cursor.path()[(v1116_10_origin + 4)..(v1116_10_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &v1116_10_cursor.path()[v1116_10_origin..(v1116_10_origin + 4)], &v1116_10_cursor);
                  join_wrapped_into(&mut v1116_10_write,&((v1124_3).read_zipper()),&[]);
                  }
                  v1116_10_cursor.ascend(1);
                }
                }
                v1116_10_cursor.ascend(1);
              }
              }
              v1116_10_cursor.ascend(1);
            }
            }
            v1116_10_cursor.ascend(1);
          }
          }
          v1116_10_cursor.ascend(1);
        }
        }
        v1116_10_cursor.ascend(1);
      }
      }
      v1116_10_cursor.ascend(1);
    }
    }
    v1116_10_cursor.ascend(1);
  }
  drop(v1116_10_cursor);
  drop(v1116_10_write);
  (v1116_10).clone()
}

fn routine_100(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1125_10 = Space::new();
  let mut v1125_10_write = v1125_10.write_zipper();
  let mut v1125_10_cursor = (*s0).read_zipper();
  let v1125_10_origin = v1125_10_cursor.path().len();
  for v1125_10_byte in v1125_10_cursor.child_mask().iter() {
    v1125_10_cursor.descend_to_existing_byte(v1125_10_byte);
    {
    for v1126_2_byte in v1125_10_cursor.child_mask().iter() {
      v1125_10_cursor.descend_to_existing_byte(v1126_2_byte);
      {
      for v1127_3_byte in v1125_10_cursor.child_mask().iter() {
        v1125_10_cursor.descend_to_existing_byte(v1127_3_byte);
        {
        for v1128_3_byte in v1125_10_cursor.child_mask().iter() {
          v1125_10_cursor.descend_to_existing_byte(v1128_3_byte);
          {
          for v1129_3_byte in v1125_10_cursor.child_mask().iter() {
            v1125_10_cursor.descend_to_existing_byte(v1129_3_byte);
            {
            for v1130_2_byte in v1125_10_cursor.child_mask().iter() {
              v1125_10_cursor.descend_to_existing_byte(v1130_2_byte);
              {
              for v1131_3_byte in v1125_10_cursor.child_mask().iter() {
                v1125_10_cursor.descend_to_existing_byte(v1131_3_byte);
                {
                for v1132_3_byte in v1125_10_cursor.child_mask().iter() {
                  v1125_10_cursor.descend_to_existing_byte(v1132_3_byte);
                  {
                  let v1133_3: Space = routine_116(c, &v1125_10_cursor.path()[(v1125_10_origin + 4)..(v1125_10_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &v1125_10_cursor.path()[v1125_10_origin..(v1125_10_origin + 4)], &v1125_10_cursor);
                  join_wrapped_into(&mut v1125_10_write,&((v1133_3).read_zipper()),&[]);
                  }
                  v1125_10_cursor.ascend(1);
                }
                }
                v1125_10_cursor.ascend(1);
              }
              }
              v1125_10_cursor.ascend(1);
            }
            }
            v1125_10_cursor.ascend(1);
          }
          }
          v1125_10_cursor.ascend(1);
        }
        }
        v1125_10_cursor.ascend(1);
      }
      }
      v1125_10_cursor.ascend(1);
    }
    }
    v1125_10_cursor.ascend(1);
  }
  drop(v1125_10_cursor);
  drop(v1125_10_write);
  (v1125_10).clone()
}

fn routine_101(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1134_10 = Space::new();
  let mut v1134_10_write = v1134_10.write_zipper();
  let mut v1134_10_cursor = (*s0).read_zipper();
  let v1134_10_origin = v1134_10_cursor.path().len();
  for v1134_10_byte in v1134_10_cursor.child_mask().iter() {
    v1134_10_cursor.descend_to_existing_byte(v1134_10_byte);
    {
    for v1135_2_byte in v1134_10_cursor.child_mask().iter() {
      v1134_10_cursor.descend_to_existing_byte(v1135_2_byte);
      {
      for v1136_3_byte in v1134_10_cursor.child_mask().iter() {
        v1134_10_cursor.descend_to_existing_byte(v1136_3_byte);
        {
        for v1137_3_byte in v1134_10_cursor.child_mask().iter() {
          v1134_10_cursor.descend_to_existing_byte(v1137_3_byte);
          {
          for v1138_3_byte in v1134_10_cursor.child_mask().iter() {
            v1134_10_cursor.descend_to_existing_byte(v1138_3_byte);
            {
            for v1139_2_byte in v1134_10_cursor.child_mask().iter() {
              v1134_10_cursor.descend_to_existing_byte(v1139_2_byte);
              {
              for v1140_3_byte in v1134_10_cursor.child_mask().iter() {
                v1134_10_cursor.descend_to_existing_byte(v1140_3_byte);
                {
                for v1141_3_byte in v1134_10_cursor.child_mask().iter() {
                  v1134_10_cursor.descend_to_existing_byte(v1141_3_byte);
                  {
                  let v1142_3: Space = routine_117(c, &v1134_10_cursor.path()[(v1134_10_origin + 4)..(v1134_10_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &v1134_10_cursor.path()[v1134_10_origin..(v1134_10_origin + 4)], &v1134_10_cursor);
                  join_wrapped_into(&mut v1134_10_write,&((v1142_3).read_zipper()),&[]);
                  }
                  v1134_10_cursor.ascend(1);
                }
                }
                v1134_10_cursor.ascend(1);
              }
              }
              v1134_10_cursor.ascend(1);
            }
            }
            v1134_10_cursor.ascend(1);
          }
          }
          v1134_10_cursor.ascend(1);
        }
        }
        v1134_10_cursor.ascend(1);
      }
      }
      v1134_10_cursor.ascend(1);
    }
    }
    v1134_10_cursor.ascend(1);
  }
  drop(v1134_10_cursor);
  drop(v1134_10_write);
  (v1134_10).clone()
}

fn routine_102(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1143_10 = Space::new();
  let mut v1143_10_write = v1143_10.write_zipper();
  let mut v1143_10_cursor = (*s0).read_zipper();
  let v1143_10_origin = v1143_10_cursor.path().len();
  for v1143_10_byte in v1143_10_cursor.child_mask().iter() {
    v1143_10_cursor.descend_to_existing_byte(v1143_10_byte);
    {
    for v1144_2_byte in v1143_10_cursor.child_mask().iter() {
      v1143_10_cursor.descend_to_existing_byte(v1144_2_byte);
      {
      for v1145_3_byte in v1143_10_cursor.child_mask().iter() {
        v1143_10_cursor.descend_to_existing_byte(v1145_3_byte);
        {
        for v1146_3_byte in v1143_10_cursor.child_mask().iter() {
          v1143_10_cursor.descend_to_existing_byte(v1146_3_byte);
          {
          for v1147_3_byte in v1143_10_cursor.child_mask().iter() {
            v1143_10_cursor.descend_to_existing_byte(v1147_3_byte);
            {
            for v1148_2_byte in v1143_10_cursor.child_mask().iter() {
              v1143_10_cursor.descend_to_existing_byte(v1148_2_byte);
              {
              for v1149_3_byte in v1143_10_cursor.child_mask().iter() {
                v1143_10_cursor.descend_to_existing_byte(v1149_3_byte);
                {
                for v1150_3_byte in v1143_10_cursor.child_mask().iter() {
                  v1143_10_cursor.descend_to_existing_byte(v1150_3_byte);
                  {
                  let v1151_3: Space = routine_118(c, &v1143_10_cursor.path()[(v1143_10_origin + 4)..(v1143_10_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &v1143_10_cursor.path()[v1143_10_origin..(v1143_10_origin + 4)], &v1143_10_cursor);
                  join_wrapped_into(&mut v1143_10_write,&((v1151_3).read_zipper()),&[]);
                  }
                  v1143_10_cursor.ascend(1);
                }
                }
                v1143_10_cursor.ascend(1);
              }
              }
              v1143_10_cursor.ascend(1);
            }
            }
            v1143_10_cursor.ascend(1);
          }
          }
          v1143_10_cursor.ascend(1);
        }
        }
        v1143_10_cursor.ascend(1);
      }
      }
      v1143_10_cursor.ascend(1);
    }
    }
    v1143_10_cursor.ascend(1);
  }
  drop(v1143_10_cursor);
  drop(v1143_10_write);
  (v1143_10).clone()
}

fn routine_103(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1152_10 = Space::new();
  let mut v1152_10_write = v1152_10.write_zipper();
  let mut v1152_10_cursor = (*s0).read_zipper();
  let v1152_10_origin = v1152_10_cursor.path().len();
  for v1152_10_byte in v1152_10_cursor.child_mask().iter() {
    v1152_10_cursor.descend_to_existing_byte(v1152_10_byte);
    {
    for v1153_2_byte in v1152_10_cursor.child_mask().iter() {
      v1152_10_cursor.descend_to_existing_byte(v1153_2_byte);
      {
      for v1154_3_byte in v1152_10_cursor.child_mask().iter() {
        v1152_10_cursor.descend_to_existing_byte(v1154_3_byte);
        {
        for v1155_3_byte in v1152_10_cursor.child_mask().iter() {
          v1152_10_cursor.descend_to_existing_byte(v1155_3_byte);
          {
          for v1156_3_byte in v1152_10_cursor.child_mask().iter() {
            v1152_10_cursor.descend_to_existing_byte(v1156_3_byte);
            {
            for v1157_2_byte in v1152_10_cursor.child_mask().iter() {
              v1152_10_cursor.descend_to_existing_byte(v1157_2_byte);
              {
              for v1158_3_byte in v1152_10_cursor.child_mask().iter() {
                v1152_10_cursor.descend_to_existing_byte(v1158_3_byte);
                {
                for v1159_3_byte in v1152_10_cursor.child_mask().iter() {
                  v1152_10_cursor.descend_to_existing_byte(v1159_3_byte);
                  {
                  let v1160_3: Space = routine_119(c, &v1152_10_cursor.path()[(v1152_10_origin + 4)..(v1152_10_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &v1152_10_cursor.path()[v1152_10_origin..(v1152_10_origin + 4)], &v1152_10_cursor);
                  join_wrapped_into(&mut v1152_10_write,&((v1160_3).read_zipper()),&[]);
                  }
                  v1152_10_cursor.ascend(1);
                }
                }
                v1152_10_cursor.ascend(1);
              }
              }
              v1152_10_cursor.ascend(1);
            }
            }
            v1152_10_cursor.ascend(1);
          }
          }
          v1152_10_cursor.ascend(1);
        }
        }
        v1152_10_cursor.ascend(1);
      }
      }
      v1152_10_cursor.ascend(1);
    }
    }
    v1152_10_cursor.ascend(1);
  }
  drop(v1152_10_cursor);
  drop(v1152_10_write);
  (v1152_10).clone()
}

fn routine_104(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1161_10 = Space::new();
  let mut v1161_10_write = v1161_10.write_zipper();
  let mut v1161_10_cursor = (*s0).read_zipper();
  let v1161_10_origin = v1161_10_cursor.path().len();
  for v1161_10_byte in v1161_10_cursor.child_mask().iter() {
    v1161_10_cursor.descend_to_existing_byte(v1161_10_byte);
    {
    for v1162_2_byte in v1161_10_cursor.child_mask().iter() {
      v1161_10_cursor.descend_to_existing_byte(v1162_2_byte);
      {
      for v1163_3_byte in v1161_10_cursor.child_mask().iter() {
        v1161_10_cursor.descend_to_existing_byte(v1163_3_byte);
        {
        for v1164_3_byte in v1161_10_cursor.child_mask().iter() {
          v1161_10_cursor.descend_to_existing_byte(v1164_3_byte);
          {
          for v1165_3_byte in v1161_10_cursor.child_mask().iter() {
            v1161_10_cursor.descend_to_existing_byte(v1165_3_byte);
            {
            for v1166_2_byte in v1161_10_cursor.child_mask().iter() {
              v1161_10_cursor.descend_to_existing_byte(v1166_2_byte);
              {
              for v1167_3_byte in v1161_10_cursor.child_mask().iter() {
                v1161_10_cursor.descend_to_existing_byte(v1167_3_byte);
                {
                for v1168_3_byte in v1161_10_cursor.child_mask().iter() {
                  v1161_10_cursor.descend_to_existing_byte(v1168_3_byte);
                  {
                  let v1169_3: Space = routine_120(c, &v1161_10_cursor.path()[(v1161_10_origin + 4)..(v1161_10_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &v1161_10_cursor.path()[v1161_10_origin..(v1161_10_origin + 4)], &v1161_10_cursor);
                  join_wrapped_into(&mut v1161_10_write,&((v1169_3).read_zipper()),&[]);
                  }
                  v1161_10_cursor.ascend(1);
                }
                }
                v1161_10_cursor.ascend(1);
              }
              }
              v1161_10_cursor.ascend(1);
            }
            }
            v1161_10_cursor.ascend(1);
          }
          }
          v1161_10_cursor.ascend(1);
        }
        }
        v1161_10_cursor.ascend(1);
      }
      }
      v1161_10_cursor.ascend(1);
    }
    }
    v1161_10_cursor.ascend(1);
  }
  drop(v1161_10_cursor);
  drop(v1161_10_write);
  (v1161_10).clone()
}

fn routine_105(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1170_10 = Space::new();
  let mut v1170_10_write = v1170_10.write_zipper();
  let mut v1170_10_cursor = (*s0).read_zipper();
  let v1170_10_origin = v1170_10_cursor.path().len();
  for v1170_10_byte in v1170_10_cursor.child_mask().iter() {
    v1170_10_cursor.descend_to_existing_byte(v1170_10_byte);
    {
    for v1171_2_byte in v1170_10_cursor.child_mask().iter() {
      v1170_10_cursor.descend_to_existing_byte(v1171_2_byte);
      {
      for v1172_3_byte in v1170_10_cursor.child_mask().iter() {
        v1170_10_cursor.descend_to_existing_byte(v1172_3_byte);
        {
        for v1173_3_byte in v1170_10_cursor.child_mask().iter() {
          v1170_10_cursor.descend_to_existing_byte(v1173_3_byte);
          {
          for v1174_3_byte in v1170_10_cursor.child_mask().iter() {
            v1170_10_cursor.descend_to_existing_byte(v1174_3_byte);
            {
            for v1175_2_byte in v1170_10_cursor.child_mask().iter() {
              v1170_10_cursor.descend_to_existing_byte(v1175_2_byte);
              {
              for v1176_3_byte in v1170_10_cursor.child_mask().iter() {
                v1170_10_cursor.descend_to_existing_byte(v1176_3_byte);
                {
                for v1177_3_byte in v1170_10_cursor.child_mask().iter() {
                  v1170_10_cursor.descend_to_existing_byte(v1177_3_byte);
                  {
                  let v1178_3: Space = routine_121(c, &v1170_10_cursor.path()[(v1170_10_origin + 4)..(v1170_10_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &v1170_10_cursor.path()[v1170_10_origin..(v1170_10_origin + 4)], &v1170_10_cursor);
                  join_wrapped_into(&mut v1170_10_write,&((v1178_3).read_zipper()),&[]);
                  }
                  v1170_10_cursor.ascend(1);
                }
                }
                v1170_10_cursor.ascend(1);
              }
              }
              v1170_10_cursor.ascend(1);
            }
            }
            v1170_10_cursor.ascend(1);
          }
          }
          v1170_10_cursor.ascend(1);
        }
        }
        v1170_10_cursor.ascend(1);
      }
      }
      v1170_10_cursor.ascend(1);
    }
    }
    v1170_10_cursor.ascend(1);
  }
  drop(v1170_10_cursor);
  drop(v1170_10_write);
  (v1170_10).clone()
}

fn routine_106(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1179_10 = Space::new();
  let mut v1179_10_write = v1179_10.write_zipper();
  let mut v1179_10_cursor = (*s0).read_zipper();
  let v1179_10_origin = v1179_10_cursor.path().len();
  for v1179_10_byte in v1179_10_cursor.child_mask().iter() {
    v1179_10_cursor.descend_to_existing_byte(v1179_10_byte);
    {
    for v1180_2_byte in v1179_10_cursor.child_mask().iter() {
      v1179_10_cursor.descend_to_existing_byte(v1180_2_byte);
      {
      for v1181_3_byte in v1179_10_cursor.child_mask().iter() {
        v1179_10_cursor.descend_to_existing_byte(v1181_3_byte);
        {
        for v1182_3_byte in v1179_10_cursor.child_mask().iter() {
          v1179_10_cursor.descend_to_existing_byte(v1182_3_byte);
          {
          for v1183_3_byte in v1179_10_cursor.child_mask().iter() {
            v1179_10_cursor.descend_to_existing_byte(v1183_3_byte);
            {
            for v1184_2_byte in v1179_10_cursor.child_mask().iter() {
              v1179_10_cursor.descend_to_existing_byte(v1184_2_byte);
              {
              for v1185_3_byte in v1179_10_cursor.child_mask().iter() {
                v1179_10_cursor.descend_to_existing_byte(v1185_3_byte);
                {
                for v1186_3_byte in v1179_10_cursor.child_mask().iter() {
                  v1179_10_cursor.descend_to_existing_byte(v1186_3_byte);
                  {
                  let v1187_3: Space = routine_122(c, &v1179_10_cursor.path()[(v1179_10_origin + 4)..(v1179_10_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &v1179_10_cursor.path()[v1179_10_origin..(v1179_10_origin + 4)], &v1179_10_cursor);
                  join_wrapped_into(&mut v1179_10_write,&((v1187_3).read_zipper()),&[]);
                  }
                  v1179_10_cursor.ascend(1);
                }
                }
                v1179_10_cursor.ascend(1);
              }
              }
              v1179_10_cursor.ascend(1);
            }
            }
            v1179_10_cursor.ascend(1);
          }
          }
          v1179_10_cursor.ascend(1);
        }
        }
        v1179_10_cursor.ascend(1);
      }
      }
      v1179_10_cursor.ascend(1);
    }
    }
    v1179_10_cursor.ascend(1);
  }
  drop(v1179_10_cursor);
  drop(v1179_10_write);
  (v1179_10).clone()
}

fn routine_107(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1188_10 = Space::new();
  let mut v1188_10_write = v1188_10.write_zipper();
  let mut v1188_10_cursor = (*s0).read_zipper();
  let v1188_10_origin = v1188_10_cursor.path().len();
  for v1188_10_byte in v1188_10_cursor.child_mask().iter() {
    v1188_10_cursor.descend_to_existing_byte(v1188_10_byte);
    {
    for v1189_2_byte in v1188_10_cursor.child_mask().iter() {
      v1188_10_cursor.descend_to_existing_byte(v1189_2_byte);
      {
      for v1190_3_byte in v1188_10_cursor.child_mask().iter() {
        v1188_10_cursor.descend_to_existing_byte(v1190_3_byte);
        {
        for v1191_3_byte in v1188_10_cursor.child_mask().iter() {
          v1188_10_cursor.descend_to_existing_byte(v1191_3_byte);
          {
          for v1192_3_byte in v1188_10_cursor.child_mask().iter() {
            v1188_10_cursor.descend_to_existing_byte(v1192_3_byte);
            {
            for v1193_2_byte in v1188_10_cursor.child_mask().iter() {
              v1188_10_cursor.descend_to_existing_byte(v1193_2_byte);
              {
              for v1194_3_byte in v1188_10_cursor.child_mask().iter() {
                v1188_10_cursor.descend_to_existing_byte(v1194_3_byte);
                {
                for v1195_3_byte in v1188_10_cursor.child_mask().iter() {
                  v1188_10_cursor.descend_to_existing_byte(v1195_3_byte);
                  {
                  let v1196_3: Space = routine_123(c, &v1188_10_cursor.path()[(v1188_10_origin + 4)..(v1188_10_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &v1188_10_cursor.path()[v1188_10_origin..(v1188_10_origin + 4)], &v1188_10_cursor);
                  join_wrapped_into(&mut v1188_10_write,&((v1196_3).read_zipper()),&[]);
                  }
                  v1188_10_cursor.ascend(1);
                }
                }
                v1188_10_cursor.ascend(1);
              }
              }
              v1188_10_cursor.ascend(1);
            }
            }
            v1188_10_cursor.ascend(1);
          }
          }
          v1188_10_cursor.ascend(1);
        }
        }
        v1188_10_cursor.ascend(1);
      }
      }
      v1188_10_cursor.ascend(1);
    }
    }
    v1188_10_cursor.ascend(1);
  }
  drop(v1188_10_cursor);
  drop(v1188_10_write);
  (v1188_10).clone()
}

fn routine_108(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1197_10 = Space::new();
  let mut v1197_10_write = v1197_10.write_zipper();
  let mut v1197_10_cursor = (*s0).read_zipper();
  let v1197_10_origin = v1197_10_cursor.path().len();
  for v1197_10_byte in v1197_10_cursor.child_mask().iter() {
    v1197_10_cursor.descend_to_existing_byte(v1197_10_byte);
    {
    for v1198_2_byte in v1197_10_cursor.child_mask().iter() {
      v1197_10_cursor.descend_to_existing_byte(v1198_2_byte);
      {
      for v1199_3_byte in v1197_10_cursor.child_mask().iter() {
        v1197_10_cursor.descend_to_existing_byte(v1199_3_byte);
        {
        for v1200_3_byte in v1197_10_cursor.child_mask().iter() {
          v1197_10_cursor.descend_to_existing_byte(v1200_3_byte);
          {
          for v1201_3_byte in v1197_10_cursor.child_mask().iter() {
            v1197_10_cursor.descend_to_existing_byte(v1201_3_byte);
            {
            for v1202_2_byte in v1197_10_cursor.child_mask().iter() {
              v1197_10_cursor.descend_to_existing_byte(v1202_2_byte);
              {
              for v1203_3_byte in v1197_10_cursor.child_mask().iter() {
                v1197_10_cursor.descend_to_existing_byte(v1203_3_byte);
                {
                for v1204_3_byte in v1197_10_cursor.child_mask().iter() {
                  v1197_10_cursor.descend_to_existing_byte(v1204_3_byte);
                  {
                  let v1205_3: Space = routine_124(c, &v1197_10_cursor.path()[(v1197_10_origin + 4)..(v1197_10_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &v1197_10_cursor.path()[v1197_10_origin..(v1197_10_origin + 4)], &v1197_10_cursor);
                  join_wrapped_into(&mut v1197_10_write,&((v1205_3).read_zipper()),&[]);
                  }
                  v1197_10_cursor.ascend(1);
                }
                }
                v1197_10_cursor.ascend(1);
              }
              }
              v1197_10_cursor.ascend(1);
            }
            }
            v1197_10_cursor.ascend(1);
          }
          }
          v1197_10_cursor.ascend(1);
        }
        }
        v1197_10_cursor.ascend(1);
      }
      }
      v1197_10_cursor.ascend(1);
    }
    }
    v1197_10_cursor.ascend(1);
  }
  drop(v1197_10_cursor);
  drop(v1197_10_write);
  (v1197_10).clone()
}

fn routine_109(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1206_10 = Space::new();
  let mut v1206_10_write = v1206_10.write_zipper();
  let mut v1206_10_cursor = (*s0).read_zipper();
  let v1206_10_origin = v1206_10_cursor.path().len();
  for v1206_10_byte in v1206_10_cursor.child_mask().iter() {
    v1206_10_cursor.descend_to_existing_byte(v1206_10_byte);
    {
    for v1207_2_byte in v1206_10_cursor.child_mask().iter() {
      v1206_10_cursor.descend_to_existing_byte(v1207_2_byte);
      {
      for v1208_3_byte in v1206_10_cursor.child_mask().iter() {
        v1206_10_cursor.descend_to_existing_byte(v1208_3_byte);
        {
        for v1209_3_byte in v1206_10_cursor.child_mask().iter() {
          v1206_10_cursor.descend_to_existing_byte(v1209_3_byte);
          {
          for v1210_3_byte in v1206_10_cursor.child_mask().iter() {
            v1206_10_cursor.descend_to_existing_byte(v1210_3_byte);
            {
            for v1211_2_byte in v1206_10_cursor.child_mask().iter() {
              v1206_10_cursor.descend_to_existing_byte(v1211_2_byte);
              {
              for v1212_3_byte in v1206_10_cursor.child_mask().iter() {
                v1206_10_cursor.descend_to_existing_byte(v1212_3_byte);
                {
                for v1213_3_byte in v1206_10_cursor.child_mask().iter() {
                  v1206_10_cursor.descend_to_existing_byte(v1213_3_byte);
                  {
                  let v1214_3: Space = routine_125(c, &v1206_10_cursor.path()[(v1206_10_origin + 4)..(v1206_10_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &v1206_10_cursor.path()[v1206_10_origin..(v1206_10_origin + 4)], &v1206_10_cursor);
                  join_wrapped_into(&mut v1206_10_write,&((v1214_3).read_zipper()),&[]);
                  }
                  v1206_10_cursor.ascend(1);
                }
                }
                v1206_10_cursor.ascend(1);
              }
              }
              v1206_10_cursor.ascend(1);
            }
            }
            v1206_10_cursor.ascend(1);
          }
          }
          v1206_10_cursor.ascend(1);
        }
        }
        v1206_10_cursor.ascend(1);
      }
      }
      v1206_10_cursor.ascend(1);
    }
    }
    v1206_10_cursor.ascend(1);
  }
  drop(v1206_10_cursor);
  drop(v1206_10_write);
  (v1206_10).clone()
}

fn routine_110(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1215_10 = Space::new();
  let mut v1215_10_write = v1215_10.write_zipper();
  let mut v1215_10_cursor = (*s0).read_zipper();
  let v1215_10_origin = v1215_10_cursor.path().len();
  for v1215_10_byte in v1215_10_cursor.child_mask().iter() {
    v1215_10_cursor.descend_to_existing_byte(v1215_10_byte);
    {
    for v1216_2_byte in v1215_10_cursor.child_mask().iter() {
      v1215_10_cursor.descend_to_existing_byte(v1216_2_byte);
      {
      for v1217_3_byte in v1215_10_cursor.child_mask().iter() {
        v1215_10_cursor.descend_to_existing_byte(v1217_3_byte);
        {
        for v1218_3_byte in v1215_10_cursor.child_mask().iter() {
          v1215_10_cursor.descend_to_existing_byte(v1218_3_byte);
          {
          for v1219_3_byte in v1215_10_cursor.child_mask().iter() {
            v1215_10_cursor.descend_to_existing_byte(v1219_3_byte);
            {
            for v1220_2_byte in v1215_10_cursor.child_mask().iter() {
              v1215_10_cursor.descend_to_existing_byte(v1220_2_byte);
              {
              for v1221_3_byte in v1215_10_cursor.child_mask().iter() {
                v1215_10_cursor.descend_to_existing_byte(v1221_3_byte);
                {
                for v1222_3_byte in v1215_10_cursor.child_mask().iter() {
                  v1215_10_cursor.descend_to_existing_byte(v1222_3_byte);
                  {
                  let v1223_3: Space = routine_126(c, &v1215_10_cursor.path()[(v1215_10_origin + 4)..(v1215_10_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &v1215_10_cursor.path()[v1215_10_origin..(v1215_10_origin + 4)], &v1215_10_cursor);
                  join_wrapped_into(&mut v1215_10_write,&((v1223_3).read_zipper()),&[]);
                  }
                  v1215_10_cursor.ascend(1);
                }
                }
                v1215_10_cursor.ascend(1);
              }
              }
              v1215_10_cursor.ascend(1);
            }
            }
            v1215_10_cursor.ascend(1);
          }
          }
          v1215_10_cursor.ascend(1);
        }
        }
        v1215_10_cursor.ascend(1);
      }
      }
      v1215_10_cursor.ascend(1);
    }
    }
    v1215_10_cursor.ascend(1);
  }
  drop(v1215_10_cursor);
  drop(v1215_10_write);
  (v1215_10).clone()
}

fn routine_111(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1224_12 = Space::new();
  let mut v1224_12_write = v1224_12.write_zipper();
  let mut v1224_12_cursor = (*s0).read_zipper();
  let v1224_12_origin = v1224_12_cursor.path().len();
  for v1224_12_byte in v1224_12_cursor.child_mask().iter() {
    v1224_12_cursor.descend_to_existing_byte(v1224_12_byte);
    {
    for v1225_2_byte in v1224_12_cursor.child_mask().iter() {
      v1224_12_cursor.descend_to_existing_byte(v1225_2_byte);
      {
      for v1226_3_byte in v1224_12_cursor.child_mask().iter() {
        v1224_12_cursor.descend_to_existing_byte(v1226_3_byte);
        {
        for v1227_3_byte in v1224_12_cursor.child_mask().iter() {
          v1224_12_cursor.descend_to_existing_byte(v1227_3_byte);
          {
          for v1228_3_byte in v1224_12_cursor.child_mask().iter() {
            v1224_12_cursor.descend_to_existing_byte(v1228_3_byte);
            {
            for v1229_2_byte in v1224_12_cursor.child_mask().iter() {
              v1224_12_cursor.descend_to_existing_byte(v1229_2_byte);
              {
              for v1230_3_byte in v1224_12_cursor.child_mask().iter() {
                v1224_12_cursor.descend_to_existing_byte(v1230_3_byte);
                {
                for v1231_3_byte in v1224_12_cursor.child_mask().iter() {
                  v1224_12_cursor.descend_to_existing_byte(v1231_3_byte);
                  {
                  let v1232_3: Space = routine_127(c, &v1224_12_cursor.path()[(v1224_12_origin + 4)..(v1224_12_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &v1224_12_cursor.path()[v1224_12_origin..(v1224_12_origin + 4)], &v1224_12_cursor);
                  join_wrapped_into(&mut v1224_12_write,&((v1232_3).read_zipper()),&[]);
                  }
                  v1224_12_cursor.ascend(1);
                }
                }
                v1224_12_cursor.ascend(1);
              }
              }
              v1224_12_cursor.ascend(1);
            }
            }
            v1224_12_cursor.ascend(1);
          }
          }
          v1224_12_cursor.ascend(1);
        }
        }
        v1224_12_cursor.ascend(1);
      }
      }
      v1224_12_cursor.ascend(1);
    }
    }
    v1224_12_cursor.ascend(1);
  }
  drop(v1224_12_cursor);
  drop(v1224_12_write);
  (v1224_12).clone()
}

fn routine_112(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1233_12 = Space::new();
  let mut v1233_12_write = v1233_12.write_zipper();
  let mut v1233_12_cursor = (*s0).read_zipper();
  let v1233_12_origin = v1233_12_cursor.path().len();
  for v1233_12_byte in v1233_12_cursor.child_mask().iter() {
    v1233_12_cursor.descend_to_existing_byte(v1233_12_byte);
    {
    for v1234_2_byte in v1233_12_cursor.child_mask().iter() {
      v1233_12_cursor.descend_to_existing_byte(v1234_2_byte);
      {
      for v1235_3_byte in v1233_12_cursor.child_mask().iter() {
        v1233_12_cursor.descend_to_existing_byte(v1235_3_byte);
        {
        for v1236_3_byte in v1233_12_cursor.child_mask().iter() {
          v1233_12_cursor.descend_to_existing_byte(v1236_3_byte);
          {
          for v1237_3_byte in v1233_12_cursor.child_mask().iter() {
            v1233_12_cursor.descend_to_existing_byte(v1237_3_byte);
            {
            for v1238_2_byte in v1233_12_cursor.child_mask().iter() {
              v1233_12_cursor.descend_to_existing_byte(v1238_2_byte);
              {
              for v1239_3_byte in v1233_12_cursor.child_mask().iter() {
                v1233_12_cursor.descend_to_existing_byte(v1239_3_byte);
                {
                for v1240_3_byte in v1233_12_cursor.child_mask().iter() {
                  v1233_12_cursor.descend_to_existing_byte(v1240_3_byte);
                  {
                  let v1241_3: Space = routine_128(c, &v1233_12_cursor.path()[(v1233_12_origin + 4)..(v1233_12_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &v1233_12_cursor.path()[v1233_12_origin..(v1233_12_origin + 4)], &v1233_12_cursor);
                  join_wrapped_into(&mut v1233_12_write,&((v1241_3).read_zipper()),&[]);
                  }
                  v1233_12_cursor.ascend(1);
                }
                }
                v1233_12_cursor.ascend(1);
              }
              }
              v1233_12_cursor.ascend(1);
            }
            }
            v1233_12_cursor.ascend(1);
          }
          }
          v1233_12_cursor.ascend(1);
        }
        }
        v1233_12_cursor.ascend(1);
      }
      }
      v1233_12_cursor.ascend(1);
    }
    }
    v1233_12_cursor.ascend(1);
  }
  drop(v1233_12_cursor);
  drop(v1233_12_write);
  (v1233_12).clone()
}

fn routine_113(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1242_12 = Space::new();
  let mut v1242_12_write = v1242_12.write_zipper();
  let mut v1242_12_cursor = (*s0).read_zipper();
  let v1242_12_origin = v1242_12_cursor.path().len();
  for v1242_12_byte in v1242_12_cursor.child_mask().iter() {
    v1242_12_cursor.descend_to_existing_byte(v1242_12_byte);
    {
    for v1243_2_byte in v1242_12_cursor.child_mask().iter() {
      v1242_12_cursor.descend_to_existing_byte(v1243_2_byte);
      {
      for v1244_3_byte in v1242_12_cursor.child_mask().iter() {
        v1242_12_cursor.descend_to_existing_byte(v1244_3_byte);
        {
        for v1245_3_byte in v1242_12_cursor.child_mask().iter() {
          v1242_12_cursor.descend_to_existing_byte(v1245_3_byte);
          {
          for v1246_3_byte in v1242_12_cursor.child_mask().iter() {
            v1242_12_cursor.descend_to_existing_byte(v1246_3_byte);
            {
            for v1247_2_byte in v1242_12_cursor.child_mask().iter() {
              v1242_12_cursor.descend_to_existing_byte(v1247_2_byte);
              {
              for v1248_3_byte in v1242_12_cursor.child_mask().iter() {
                v1242_12_cursor.descend_to_existing_byte(v1248_3_byte);
                {
                for v1249_3_byte in v1242_12_cursor.child_mask().iter() {
                  v1242_12_cursor.descend_to_existing_byte(v1249_3_byte);
                  {
                  let v1250_3: Space = routine_129(c, &v1242_12_cursor.path()[(v1242_12_origin + 4)..(v1242_12_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &v1242_12_cursor.path()[v1242_12_origin..(v1242_12_origin + 4)], &v1242_12_cursor);
                  join_wrapped_into(&mut v1242_12_write,&((v1250_3).read_zipper()),&[]);
                  }
                  v1242_12_cursor.ascend(1);
                }
                }
                v1242_12_cursor.ascend(1);
              }
              }
              v1242_12_cursor.ascend(1);
            }
            }
            v1242_12_cursor.ascend(1);
          }
          }
          v1242_12_cursor.ascend(1);
        }
        }
        v1242_12_cursor.ascend(1);
      }
      }
      v1242_12_cursor.ascend(1);
    }
    }
    v1242_12_cursor.ascend(1);
  }
  drop(v1242_12_cursor);
  drop(v1242_12_write);
  (v1242_12).clone()
}

fn routine_114(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1251_12 = Space::new();
  let mut v1251_12_write = v1251_12.write_zipper();
  let mut v1251_12_cursor = (*s0).read_zipper();
  let v1251_12_origin = v1251_12_cursor.path().len();
  for v1251_12_byte in v1251_12_cursor.child_mask().iter() {
    v1251_12_cursor.descend_to_existing_byte(v1251_12_byte);
    {
    for v1252_2_byte in v1251_12_cursor.child_mask().iter() {
      v1251_12_cursor.descend_to_existing_byte(v1252_2_byte);
      {
      for v1253_3_byte in v1251_12_cursor.child_mask().iter() {
        v1251_12_cursor.descend_to_existing_byte(v1253_3_byte);
        {
        for v1254_3_byte in v1251_12_cursor.child_mask().iter() {
          v1251_12_cursor.descend_to_existing_byte(v1254_3_byte);
          {
          for v1255_3_byte in v1251_12_cursor.child_mask().iter() {
            v1251_12_cursor.descend_to_existing_byte(v1255_3_byte);
            {
            for v1256_2_byte in v1251_12_cursor.child_mask().iter() {
              v1251_12_cursor.descend_to_existing_byte(v1256_2_byte);
              {
              for v1257_3_byte in v1251_12_cursor.child_mask().iter() {
                v1251_12_cursor.descend_to_existing_byte(v1257_3_byte);
                {
                for v1258_3_byte in v1251_12_cursor.child_mask().iter() {
                  v1251_12_cursor.descend_to_existing_byte(v1258_3_byte);
                  {
                  let v1259_3: Space = routine_130(c, &v1251_12_cursor.path()[(v1251_12_origin + 4)..(v1251_12_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &v1251_12_cursor.path()[v1251_12_origin..(v1251_12_origin + 4)], &v1251_12_cursor);
                  join_wrapped_into(&mut v1251_12_write,&((v1259_3).read_zipper()),&[]);
                  }
                  v1251_12_cursor.ascend(1);
                }
                }
                v1251_12_cursor.ascend(1);
              }
              }
              v1251_12_cursor.ascend(1);
            }
            }
            v1251_12_cursor.ascend(1);
          }
          }
          v1251_12_cursor.ascend(1);
        }
        }
        v1251_12_cursor.ascend(1);
      }
      }
      v1251_12_cursor.ascend(1);
    }
    }
    v1251_12_cursor.ascend(1);
  }
  drop(v1251_12_cursor);
  drop(v1251_12_write);
  (v1251_12).clone()
}

fn routine_115(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1260_12 = Space::new();
  let mut v1260_12_write = v1260_12.write_zipper();
  let mut v1260_12_cursor = (*s0).read_zipper();
  let v1260_12_origin = v1260_12_cursor.path().len();
  for v1260_12_byte in v1260_12_cursor.child_mask().iter() {
    v1260_12_cursor.descend_to_existing_byte(v1260_12_byte);
    {
    for v1261_2_byte in v1260_12_cursor.child_mask().iter() {
      v1260_12_cursor.descend_to_existing_byte(v1261_2_byte);
      {
      for v1262_3_byte in v1260_12_cursor.child_mask().iter() {
        v1260_12_cursor.descend_to_existing_byte(v1262_3_byte);
        {
        for v1263_3_byte in v1260_12_cursor.child_mask().iter() {
          v1260_12_cursor.descend_to_existing_byte(v1263_3_byte);
          {
          for v1264_3_byte in v1260_12_cursor.child_mask().iter() {
            v1260_12_cursor.descend_to_existing_byte(v1264_3_byte);
            {
            for v1265_2_byte in v1260_12_cursor.child_mask().iter() {
              v1260_12_cursor.descend_to_existing_byte(v1265_2_byte);
              {
              for v1266_3_byte in v1260_12_cursor.child_mask().iter() {
                v1260_12_cursor.descend_to_existing_byte(v1266_3_byte);
                {
                for v1267_3_byte in v1260_12_cursor.child_mask().iter() {
                  v1260_12_cursor.descend_to_existing_byte(v1267_3_byte);
                  {
                  let v1268_3: Space = routine_131(c, &v1260_12_cursor.path()[(v1260_12_origin + 4)..(v1260_12_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &v1260_12_cursor.path()[v1260_12_origin..(v1260_12_origin + 4)], &v1260_12_cursor);
                  join_wrapped_into(&mut v1260_12_write,&((v1268_3).read_zipper()),&[]);
                  }
                  v1260_12_cursor.ascend(1);
                }
                }
                v1260_12_cursor.ascend(1);
              }
              }
              v1260_12_cursor.ascend(1);
            }
            }
            v1260_12_cursor.ascend(1);
          }
          }
          v1260_12_cursor.ascend(1);
        }
        }
        v1260_12_cursor.ascend(1);
      }
      }
      v1260_12_cursor.ascend(1);
    }
    }
    v1260_12_cursor.ascend(1);
  }
  drop(v1260_12_cursor);
  drop(v1260_12_write);
  (v1260_12).clone()
}

fn routine_116(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1269_12 = Space::new();
  let mut v1269_12_write = v1269_12.write_zipper();
  let mut v1269_12_cursor = (*s0).read_zipper();
  let v1269_12_origin = v1269_12_cursor.path().len();
  for v1269_12_byte in v1269_12_cursor.child_mask().iter() {
    v1269_12_cursor.descend_to_existing_byte(v1269_12_byte);
    {
    for v1270_2_byte in v1269_12_cursor.child_mask().iter() {
      v1269_12_cursor.descend_to_existing_byte(v1270_2_byte);
      {
      for v1271_3_byte in v1269_12_cursor.child_mask().iter() {
        v1269_12_cursor.descend_to_existing_byte(v1271_3_byte);
        {
        for v1272_3_byte in v1269_12_cursor.child_mask().iter() {
          v1269_12_cursor.descend_to_existing_byte(v1272_3_byte);
          {
          for v1273_3_byte in v1269_12_cursor.child_mask().iter() {
            v1269_12_cursor.descend_to_existing_byte(v1273_3_byte);
            {
            for v1274_2_byte in v1269_12_cursor.child_mask().iter() {
              v1269_12_cursor.descend_to_existing_byte(v1274_2_byte);
              {
              for v1275_3_byte in v1269_12_cursor.child_mask().iter() {
                v1269_12_cursor.descend_to_existing_byte(v1275_3_byte);
                {
                for v1276_3_byte in v1269_12_cursor.child_mask().iter() {
                  v1269_12_cursor.descend_to_existing_byte(v1276_3_byte);
                  {
                  let v1277_3: Space = routine_132(c, &v1269_12_cursor.path()[(v1269_12_origin + 4)..(v1269_12_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &v1269_12_cursor.path()[v1269_12_origin..(v1269_12_origin + 4)], &v1269_12_cursor);
                  join_wrapped_into(&mut v1269_12_write,&((v1277_3).read_zipper()),&[]);
                  }
                  v1269_12_cursor.ascend(1);
                }
                }
                v1269_12_cursor.ascend(1);
              }
              }
              v1269_12_cursor.ascend(1);
            }
            }
            v1269_12_cursor.ascend(1);
          }
          }
          v1269_12_cursor.ascend(1);
        }
        }
        v1269_12_cursor.ascend(1);
      }
      }
      v1269_12_cursor.ascend(1);
    }
    }
    v1269_12_cursor.ascend(1);
  }
  drop(v1269_12_cursor);
  drop(v1269_12_write);
  (v1269_12).clone()
}

fn routine_117(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1278_12 = Space::new();
  let mut v1278_12_write = v1278_12.write_zipper();
  let mut v1278_12_cursor = (*s0).read_zipper();
  let v1278_12_origin = v1278_12_cursor.path().len();
  for v1278_12_byte in v1278_12_cursor.child_mask().iter() {
    v1278_12_cursor.descend_to_existing_byte(v1278_12_byte);
    {
    for v1279_2_byte in v1278_12_cursor.child_mask().iter() {
      v1278_12_cursor.descend_to_existing_byte(v1279_2_byte);
      {
      for v1280_3_byte in v1278_12_cursor.child_mask().iter() {
        v1278_12_cursor.descend_to_existing_byte(v1280_3_byte);
        {
        for v1281_3_byte in v1278_12_cursor.child_mask().iter() {
          v1278_12_cursor.descend_to_existing_byte(v1281_3_byte);
          {
          for v1282_3_byte in v1278_12_cursor.child_mask().iter() {
            v1278_12_cursor.descend_to_existing_byte(v1282_3_byte);
            {
            for v1283_2_byte in v1278_12_cursor.child_mask().iter() {
              v1278_12_cursor.descend_to_existing_byte(v1283_2_byte);
              {
              for v1284_3_byte in v1278_12_cursor.child_mask().iter() {
                v1278_12_cursor.descend_to_existing_byte(v1284_3_byte);
                {
                for v1285_3_byte in v1278_12_cursor.child_mask().iter() {
                  v1278_12_cursor.descend_to_existing_byte(v1285_3_byte);
                  {
                  let v1286_3: Space = routine_133(c, &v1278_12_cursor.path()[(v1278_12_origin + 4)..(v1278_12_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &v1278_12_cursor.path()[v1278_12_origin..(v1278_12_origin + 4)], &v1278_12_cursor);
                  join_wrapped_into(&mut v1278_12_write,&((v1286_3).read_zipper()),&[]);
                  }
                  v1278_12_cursor.ascend(1);
                }
                }
                v1278_12_cursor.ascend(1);
              }
              }
              v1278_12_cursor.ascend(1);
            }
            }
            v1278_12_cursor.ascend(1);
          }
          }
          v1278_12_cursor.ascend(1);
        }
        }
        v1278_12_cursor.ascend(1);
      }
      }
      v1278_12_cursor.ascend(1);
    }
    }
    v1278_12_cursor.ascend(1);
  }
  drop(v1278_12_cursor);
  drop(v1278_12_write);
  (v1278_12).clone()
}

fn routine_118(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1287_12 = Space::new();
  let mut v1287_12_write = v1287_12.write_zipper();
  let mut v1287_12_cursor = (*s0).read_zipper();
  let v1287_12_origin = v1287_12_cursor.path().len();
  for v1287_12_byte in v1287_12_cursor.child_mask().iter() {
    v1287_12_cursor.descend_to_existing_byte(v1287_12_byte);
    {
    for v1288_2_byte in v1287_12_cursor.child_mask().iter() {
      v1287_12_cursor.descend_to_existing_byte(v1288_2_byte);
      {
      for v1289_3_byte in v1287_12_cursor.child_mask().iter() {
        v1287_12_cursor.descend_to_existing_byte(v1289_3_byte);
        {
        for v1290_3_byte in v1287_12_cursor.child_mask().iter() {
          v1287_12_cursor.descend_to_existing_byte(v1290_3_byte);
          {
          for v1291_3_byte in v1287_12_cursor.child_mask().iter() {
            v1287_12_cursor.descend_to_existing_byte(v1291_3_byte);
            {
            for v1292_2_byte in v1287_12_cursor.child_mask().iter() {
              v1287_12_cursor.descend_to_existing_byte(v1292_2_byte);
              {
              for v1293_3_byte in v1287_12_cursor.child_mask().iter() {
                v1287_12_cursor.descend_to_existing_byte(v1293_3_byte);
                {
                for v1294_3_byte in v1287_12_cursor.child_mask().iter() {
                  v1287_12_cursor.descend_to_existing_byte(v1294_3_byte);
                  {
                  let v1295_3: Space = routine_134(c, &v1287_12_cursor.path()[(v1287_12_origin + 4)..(v1287_12_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &v1287_12_cursor.path()[v1287_12_origin..(v1287_12_origin + 4)], &v1287_12_cursor);
                  join_wrapped_into(&mut v1287_12_write,&((v1295_3).read_zipper()),&[]);
                  }
                  v1287_12_cursor.ascend(1);
                }
                }
                v1287_12_cursor.ascend(1);
              }
              }
              v1287_12_cursor.ascend(1);
            }
            }
            v1287_12_cursor.ascend(1);
          }
          }
          v1287_12_cursor.ascend(1);
        }
        }
        v1287_12_cursor.ascend(1);
      }
      }
      v1287_12_cursor.ascend(1);
    }
    }
    v1287_12_cursor.ascend(1);
  }
  drop(v1287_12_cursor);
  drop(v1287_12_write);
  (v1287_12).clone()
}

fn routine_119(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1296_12 = Space::new();
  let mut v1296_12_write = v1296_12.write_zipper();
  let mut v1296_12_cursor = (*s0).read_zipper();
  let v1296_12_origin = v1296_12_cursor.path().len();
  for v1296_12_byte in v1296_12_cursor.child_mask().iter() {
    v1296_12_cursor.descend_to_existing_byte(v1296_12_byte);
    {
    for v1297_2_byte in v1296_12_cursor.child_mask().iter() {
      v1296_12_cursor.descend_to_existing_byte(v1297_2_byte);
      {
      for v1298_3_byte in v1296_12_cursor.child_mask().iter() {
        v1296_12_cursor.descend_to_existing_byte(v1298_3_byte);
        {
        for v1299_3_byte in v1296_12_cursor.child_mask().iter() {
          v1296_12_cursor.descend_to_existing_byte(v1299_3_byte);
          {
          for v1300_3_byte in v1296_12_cursor.child_mask().iter() {
            v1296_12_cursor.descend_to_existing_byte(v1300_3_byte);
            {
            for v1301_2_byte in v1296_12_cursor.child_mask().iter() {
              v1296_12_cursor.descend_to_existing_byte(v1301_2_byte);
              {
              for v1302_3_byte in v1296_12_cursor.child_mask().iter() {
                v1296_12_cursor.descend_to_existing_byte(v1302_3_byte);
                {
                for v1303_3_byte in v1296_12_cursor.child_mask().iter() {
                  v1296_12_cursor.descend_to_existing_byte(v1303_3_byte);
                  {
                  let v1304_3: Space = routine_135(c, &v1296_12_cursor.path()[(v1296_12_origin + 4)..(v1296_12_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &v1296_12_cursor.path()[v1296_12_origin..(v1296_12_origin + 4)], &v1296_12_cursor);
                  join_wrapped_into(&mut v1296_12_write,&((v1304_3).read_zipper()),&[]);
                  }
                  v1296_12_cursor.ascend(1);
                }
                }
                v1296_12_cursor.ascend(1);
              }
              }
              v1296_12_cursor.ascend(1);
            }
            }
            v1296_12_cursor.ascend(1);
          }
          }
          v1296_12_cursor.ascend(1);
        }
        }
        v1296_12_cursor.ascend(1);
      }
      }
      v1296_12_cursor.ascend(1);
    }
    }
    v1296_12_cursor.ascend(1);
  }
  drop(v1296_12_cursor);
  drop(v1296_12_write);
  (v1296_12).clone()
}

fn routine_120(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1305_12 = Space::new();
  let mut v1305_12_write = v1305_12.write_zipper();
  let mut v1305_12_cursor = (*s0).read_zipper();
  let v1305_12_origin = v1305_12_cursor.path().len();
  for v1305_12_byte in v1305_12_cursor.child_mask().iter() {
    v1305_12_cursor.descend_to_existing_byte(v1305_12_byte);
    {
    for v1306_2_byte in v1305_12_cursor.child_mask().iter() {
      v1305_12_cursor.descend_to_existing_byte(v1306_2_byte);
      {
      for v1307_3_byte in v1305_12_cursor.child_mask().iter() {
        v1305_12_cursor.descend_to_existing_byte(v1307_3_byte);
        {
        for v1308_3_byte in v1305_12_cursor.child_mask().iter() {
          v1305_12_cursor.descend_to_existing_byte(v1308_3_byte);
          {
          for v1309_3_byte in v1305_12_cursor.child_mask().iter() {
            v1305_12_cursor.descend_to_existing_byte(v1309_3_byte);
            {
            for v1310_2_byte in v1305_12_cursor.child_mask().iter() {
              v1305_12_cursor.descend_to_existing_byte(v1310_2_byte);
              {
              for v1311_3_byte in v1305_12_cursor.child_mask().iter() {
                v1305_12_cursor.descend_to_existing_byte(v1311_3_byte);
                {
                for v1312_3_byte in v1305_12_cursor.child_mask().iter() {
                  v1305_12_cursor.descend_to_existing_byte(v1312_3_byte);
                  {
                  let v1313_3: Space = routine_136(c, &v1305_12_cursor.path()[(v1305_12_origin + 4)..(v1305_12_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &v1305_12_cursor.path()[v1305_12_origin..(v1305_12_origin + 4)], &v1305_12_cursor);
                  join_wrapped_into(&mut v1305_12_write,&((v1313_3).read_zipper()),&[]);
                  }
                  v1305_12_cursor.ascend(1);
                }
                }
                v1305_12_cursor.ascend(1);
              }
              }
              v1305_12_cursor.ascend(1);
            }
            }
            v1305_12_cursor.ascend(1);
          }
          }
          v1305_12_cursor.ascend(1);
        }
        }
        v1305_12_cursor.ascend(1);
      }
      }
      v1305_12_cursor.ascend(1);
    }
    }
    v1305_12_cursor.ascend(1);
  }
  drop(v1305_12_cursor);
  drop(v1305_12_write);
  (v1305_12).clone()
}

fn routine_121(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1314_12 = Space::new();
  let mut v1314_12_write = v1314_12.write_zipper();
  let mut v1314_12_cursor = (*s0).read_zipper();
  let v1314_12_origin = v1314_12_cursor.path().len();
  for v1314_12_byte in v1314_12_cursor.child_mask().iter() {
    v1314_12_cursor.descend_to_existing_byte(v1314_12_byte);
    {
    for v1315_2_byte in v1314_12_cursor.child_mask().iter() {
      v1314_12_cursor.descend_to_existing_byte(v1315_2_byte);
      {
      for v1316_3_byte in v1314_12_cursor.child_mask().iter() {
        v1314_12_cursor.descend_to_existing_byte(v1316_3_byte);
        {
        for v1317_3_byte in v1314_12_cursor.child_mask().iter() {
          v1314_12_cursor.descend_to_existing_byte(v1317_3_byte);
          {
          for v1318_3_byte in v1314_12_cursor.child_mask().iter() {
            v1314_12_cursor.descend_to_existing_byte(v1318_3_byte);
            {
            for v1319_2_byte in v1314_12_cursor.child_mask().iter() {
              v1314_12_cursor.descend_to_existing_byte(v1319_2_byte);
              {
              for v1320_3_byte in v1314_12_cursor.child_mask().iter() {
                v1314_12_cursor.descend_to_existing_byte(v1320_3_byte);
                {
                for v1321_3_byte in v1314_12_cursor.child_mask().iter() {
                  v1314_12_cursor.descend_to_existing_byte(v1321_3_byte);
                  {
                  let v1322_3: Space = routine_137(c, &v1314_12_cursor.path()[(v1314_12_origin + 4)..(v1314_12_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &v1314_12_cursor.path()[v1314_12_origin..(v1314_12_origin + 4)], &v1314_12_cursor);
                  join_wrapped_into(&mut v1314_12_write,&((v1322_3).read_zipper()),&[]);
                  }
                  v1314_12_cursor.ascend(1);
                }
                }
                v1314_12_cursor.ascend(1);
              }
              }
              v1314_12_cursor.ascend(1);
            }
            }
            v1314_12_cursor.ascend(1);
          }
          }
          v1314_12_cursor.ascend(1);
        }
        }
        v1314_12_cursor.ascend(1);
      }
      }
      v1314_12_cursor.ascend(1);
    }
    }
    v1314_12_cursor.ascend(1);
  }
  drop(v1314_12_cursor);
  drop(v1314_12_write);
  (v1314_12).clone()
}

fn routine_122(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1323_12 = Space::new();
  let mut v1323_12_write = v1323_12.write_zipper();
  let mut v1323_12_cursor = (*s0).read_zipper();
  let v1323_12_origin = v1323_12_cursor.path().len();
  for v1323_12_byte in v1323_12_cursor.child_mask().iter() {
    v1323_12_cursor.descend_to_existing_byte(v1323_12_byte);
    {
    for v1324_2_byte in v1323_12_cursor.child_mask().iter() {
      v1323_12_cursor.descend_to_existing_byte(v1324_2_byte);
      {
      for v1325_3_byte in v1323_12_cursor.child_mask().iter() {
        v1323_12_cursor.descend_to_existing_byte(v1325_3_byte);
        {
        for v1326_3_byte in v1323_12_cursor.child_mask().iter() {
          v1323_12_cursor.descend_to_existing_byte(v1326_3_byte);
          {
          for v1327_3_byte in v1323_12_cursor.child_mask().iter() {
            v1323_12_cursor.descend_to_existing_byte(v1327_3_byte);
            {
            for v1328_2_byte in v1323_12_cursor.child_mask().iter() {
              v1323_12_cursor.descend_to_existing_byte(v1328_2_byte);
              {
              for v1329_3_byte in v1323_12_cursor.child_mask().iter() {
                v1323_12_cursor.descend_to_existing_byte(v1329_3_byte);
                {
                for v1330_3_byte in v1323_12_cursor.child_mask().iter() {
                  v1323_12_cursor.descend_to_existing_byte(v1330_3_byte);
                  {
                  let v1331_3: Space = routine_138(c, &v1323_12_cursor.path()[(v1323_12_origin + 4)..(v1323_12_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &v1323_12_cursor.path()[v1323_12_origin..(v1323_12_origin + 4)], &v1323_12_cursor);
                  join_wrapped_into(&mut v1323_12_write,&((v1331_3).read_zipper()),&[]);
                  }
                  v1323_12_cursor.ascend(1);
                }
                }
                v1323_12_cursor.ascend(1);
              }
              }
              v1323_12_cursor.ascend(1);
            }
            }
            v1323_12_cursor.ascend(1);
          }
          }
          v1323_12_cursor.ascend(1);
        }
        }
        v1323_12_cursor.ascend(1);
      }
      }
      v1323_12_cursor.ascend(1);
    }
    }
    v1323_12_cursor.ascend(1);
  }
  drop(v1323_12_cursor);
  drop(v1323_12_write);
  (v1323_12).clone()
}

fn routine_123(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1332_12 = Space::new();
  let mut v1332_12_write = v1332_12.write_zipper();
  let mut v1332_12_cursor = (*s0).read_zipper();
  let v1332_12_origin = v1332_12_cursor.path().len();
  for v1332_12_byte in v1332_12_cursor.child_mask().iter() {
    v1332_12_cursor.descend_to_existing_byte(v1332_12_byte);
    {
    for v1333_2_byte in v1332_12_cursor.child_mask().iter() {
      v1332_12_cursor.descend_to_existing_byte(v1333_2_byte);
      {
      for v1334_3_byte in v1332_12_cursor.child_mask().iter() {
        v1332_12_cursor.descend_to_existing_byte(v1334_3_byte);
        {
        for v1335_3_byte in v1332_12_cursor.child_mask().iter() {
          v1332_12_cursor.descend_to_existing_byte(v1335_3_byte);
          {
          for v1336_3_byte in v1332_12_cursor.child_mask().iter() {
            v1332_12_cursor.descend_to_existing_byte(v1336_3_byte);
            {
            for v1337_2_byte in v1332_12_cursor.child_mask().iter() {
              v1332_12_cursor.descend_to_existing_byte(v1337_2_byte);
              {
              for v1338_3_byte in v1332_12_cursor.child_mask().iter() {
                v1332_12_cursor.descend_to_existing_byte(v1338_3_byte);
                {
                for v1339_3_byte in v1332_12_cursor.child_mask().iter() {
                  v1332_12_cursor.descend_to_existing_byte(v1339_3_byte);
                  {
                  let v1340_3: Space = routine_139(c, &v1332_12_cursor.path()[(v1332_12_origin + 4)..(v1332_12_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &v1332_12_cursor.path()[v1332_12_origin..(v1332_12_origin + 4)], &v1332_12_cursor);
                  join_wrapped_into(&mut v1332_12_write,&((v1340_3).read_zipper()),&[]);
                  }
                  v1332_12_cursor.ascend(1);
                }
                }
                v1332_12_cursor.ascend(1);
              }
              }
              v1332_12_cursor.ascend(1);
            }
            }
            v1332_12_cursor.ascend(1);
          }
          }
          v1332_12_cursor.ascend(1);
        }
        }
        v1332_12_cursor.ascend(1);
      }
      }
      v1332_12_cursor.ascend(1);
    }
    }
    v1332_12_cursor.ascend(1);
  }
  drop(v1332_12_cursor);
  drop(v1332_12_write);
  (v1332_12).clone()
}

fn routine_124(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1341_12 = Space::new();
  let mut v1341_12_write = v1341_12.write_zipper();
  let mut v1341_12_cursor = (*s0).read_zipper();
  let v1341_12_origin = v1341_12_cursor.path().len();
  for v1341_12_byte in v1341_12_cursor.child_mask().iter() {
    v1341_12_cursor.descend_to_existing_byte(v1341_12_byte);
    {
    for v1342_2_byte in v1341_12_cursor.child_mask().iter() {
      v1341_12_cursor.descend_to_existing_byte(v1342_2_byte);
      {
      for v1343_3_byte in v1341_12_cursor.child_mask().iter() {
        v1341_12_cursor.descend_to_existing_byte(v1343_3_byte);
        {
        for v1344_3_byte in v1341_12_cursor.child_mask().iter() {
          v1341_12_cursor.descend_to_existing_byte(v1344_3_byte);
          {
          for v1345_3_byte in v1341_12_cursor.child_mask().iter() {
            v1341_12_cursor.descend_to_existing_byte(v1345_3_byte);
            {
            for v1346_2_byte in v1341_12_cursor.child_mask().iter() {
              v1341_12_cursor.descend_to_existing_byte(v1346_2_byte);
              {
              for v1347_3_byte in v1341_12_cursor.child_mask().iter() {
                v1341_12_cursor.descend_to_existing_byte(v1347_3_byte);
                {
                for v1348_3_byte in v1341_12_cursor.child_mask().iter() {
                  v1341_12_cursor.descend_to_existing_byte(v1348_3_byte);
                  {
                  let v1349_3: Space = routine_140(c, &v1341_12_cursor.path()[(v1341_12_origin + 4)..(v1341_12_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &v1341_12_cursor.path()[v1341_12_origin..(v1341_12_origin + 4)], &v1341_12_cursor);
                  join_wrapped_into(&mut v1341_12_write,&((v1349_3).read_zipper()),&[]);
                  }
                  v1341_12_cursor.ascend(1);
                }
                }
                v1341_12_cursor.ascend(1);
              }
              }
              v1341_12_cursor.ascend(1);
            }
            }
            v1341_12_cursor.ascend(1);
          }
          }
          v1341_12_cursor.ascend(1);
        }
        }
        v1341_12_cursor.ascend(1);
      }
      }
      v1341_12_cursor.ascend(1);
    }
    }
    v1341_12_cursor.ascend(1);
  }
  drop(v1341_12_cursor);
  drop(v1341_12_write);
  (v1341_12).clone()
}

fn routine_125(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1350_12 = Space::new();
  let mut v1350_12_write = v1350_12.write_zipper();
  let mut v1350_12_cursor = (*s0).read_zipper();
  let v1350_12_origin = v1350_12_cursor.path().len();
  for v1350_12_byte in v1350_12_cursor.child_mask().iter() {
    v1350_12_cursor.descend_to_existing_byte(v1350_12_byte);
    {
    for v1351_2_byte in v1350_12_cursor.child_mask().iter() {
      v1350_12_cursor.descend_to_existing_byte(v1351_2_byte);
      {
      for v1352_3_byte in v1350_12_cursor.child_mask().iter() {
        v1350_12_cursor.descend_to_existing_byte(v1352_3_byte);
        {
        for v1353_3_byte in v1350_12_cursor.child_mask().iter() {
          v1350_12_cursor.descend_to_existing_byte(v1353_3_byte);
          {
          for v1354_3_byte in v1350_12_cursor.child_mask().iter() {
            v1350_12_cursor.descend_to_existing_byte(v1354_3_byte);
            {
            for v1355_2_byte in v1350_12_cursor.child_mask().iter() {
              v1350_12_cursor.descend_to_existing_byte(v1355_2_byte);
              {
              for v1356_3_byte in v1350_12_cursor.child_mask().iter() {
                v1350_12_cursor.descend_to_existing_byte(v1356_3_byte);
                {
                for v1357_3_byte in v1350_12_cursor.child_mask().iter() {
                  v1350_12_cursor.descend_to_existing_byte(v1357_3_byte);
                  {
                  let v1358_3: Space = routine_141(c, &v1350_12_cursor.path()[(v1350_12_origin + 4)..(v1350_12_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &v1350_12_cursor.path()[v1350_12_origin..(v1350_12_origin + 4)], &v1350_12_cursor);
                  join_wrapped_into(&mut v1350_12_write,&((v1358_3).read_zipper()),&[]);
                  }
                  v1350_12_cursor.ascend(1);
                }
                }
                v1350_12_cursor.ascend(1);
              }
              }
              v1350_12_cursor.ascend(1);
            }
            }
            v1350_12_cursor.ascend(1);
          }
          }
          v1350_12_cursor.ascend(1);
        }
        }
        v1350_12_cursor.ascend(1);
      }
      }
      v1350_12_cursor.ascend(1);
    }
    }
    v1350_12_cursor.ascend(1);
  }
  drop(v1350_12_cursor);
  drop(v1350_12_write);
  (v1350_12).clone()
}

fn routine_126(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1359_12 = Space::new();
  let mut v1359_12_write = v1359_12.write_zipper();
  let mut v1359_12_cursor = (*s0).read_zipper();
  let v1359_12_origin = v1359_12_cursor.path().len();
  for v1359_12_byte in v1359_12_cursor.child_mask().iter() {
    v1359_12_cursor.descend_to_existing_byte(v1359_12_byte);
    {
    for v1360_2_byte in v1359_12_cursor.child_mask().iter() {
      v1359_12_cursor.descend_to_existing_byte(v1360_2_byte);
      {
      for v1361_3_byte in v1359_12_cursor.child_mask().iter() {
        v1359_12_cursor.descend_to_existing_byte(v1361_3_byte);
        {
        for v1362_3_byte in v1359_12_cursor.child_mask().iter() {
          v1359_12_cursor.descend_to_existing_byte(v1362_3_byte);
          {
          for v1363_3_byte in v1359_12_cursor.child_mask().iter() {
            v1359_12_cursor.descend_to_existing_byte(v1363_3_byte);
            {
            for v1364_2_byte in v1359_12_cursor.child_mask().iter() {
              v1359_12_cursor.descend_to_existing_byte(v1364_2_byte);
              {
              for v1365_3_byte in v1359_12_cursor.child_mask().iter() {
                v1359_12_cursor.descend_to_existing_byte(v1365_3_byte);
                {
                for v1366_3_byte in v1359_12_cursor.child_mask().iter() {
                  v1359_12_cursor.descend_to_existing_byte(v1366_3_byte);
                  {
                  let v1367_3: Space = routine_142(c, &v1359_12_cursor.path()[(v1359_12_origin + 4)..(v1359_12_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &v1359_12_cursor.path()[v1359_12_origin..(v1359_12_origin + 4)], &v1359_12_cursor);
                  join_wrapped_into(&mut v1359_12_write,&((v1367_3).read_zipper()),&[]);
                  }
                  v1359_12_cursor.ascend(1);
                }
                }
                v1359_12_cursor.ascend(1);
              }
              }
              v1359_12_cursor.ascend(1);
            }
            }
            v1359_12_cursor.ascend(1);
          }
          }
          v1359_12_cursor.ascend(1);
        }
        }
        v1359_12_cursor.ascend(1);
      }
      }
      v1359_12_cursor.ascend(1);
    }
    }
    v1359_12_cursor.ascend(1);
  }
  drop(v1359_12_cursor);
  drop(v1359_12_write);
  (v1359_12).clone()
}

fn routine_127(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1368_14 = Space::new();
  let mut v1368_14_write = v1368_14.write_zipper();
  let mut v1368_14_cursor = (*s0).read_zipper();
  let v1368_14_origin = v1368_14_cursor.path().len();
  for v1368_14_byte in v1368_14_cursor.child_mask().iter() {
    v1368_14_cursor.descend_to_existing_byte(v1368_14_byte);
    {
    for v1369_2_byte in v1368_14_cursor.child_mask().iter() {
      v1368_14_cursor.descend_to_existing_byte(v1369_2_byte);
      {
      for v1370_3_byte in v1368_14_cursor.child_mask().iter() {
        v1368_14_cursor.descend_to_existing_byte(v1370_3_byte);
        {
        for v1371_3_byte in v1368_14_cursor.child_mask().iter() {
          v1368_14_cursor.descend_to_existing_byte(v1371_3_byte);
          {
          for v1372_3_byte in v1368_14_cursor.child_mask().iter() {
            v1368_14_cursor.descend_to_existing_byte(v1372_3_byte);
            {
            for v1373_2_byte in v1368_14_cursor.child_mask().iter() {
              v1368_14_cursor.descend_to_existing_byte(v1373_2_byte);
              {
              for v1374_3_byte in v1368_14_cursor.child_mask().iter() {
                v1368_14_cursor.descend_to_existing_byte(v1374_3_byte);
                {
                for v1375_3_byte in v1368_14_cursor.child_mask().iter() {
                  v1368_14_cursor.descend_to_existing_byte(v1375_3_byte);
                  {
                  let v1376_3: Space = routine_143(c, &v1368_14_cursor.path()[(v1368_14_origin + 4)..(v1368_14_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &v1368_14_cursor.path()[v1368_14_origin..(v1368_14_origin + 4)], &v1368_14_cursor);
                  join_wrapped_into(&mut v1368_14_write,&((v1376_3).read_zipper()),&[]);
                  }
                  v1368_14_cursor.ascend(1);
                }
                }
                v1368_14_cursor.ascend(1);
              }
              }
              v1368_14_cursor.ascend(1);
            }
            }
            v1368_14_cursor.ascend(1);
          }
          }
          v1368_14_cursor.ascend(1);
        }
        }
        v1368_14_cursor.ascend(1);
      }
      }
      v1368_14_cursor.ascend(1);
    }
    }
    v1368_14_cursor.ascend(1);
  }
  drop(v1368_14_cursor);
  drop(v1368_14_write);
  (v1368_14).clone()
}

fn routine_128(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1377_14 = Space::new();
  let mut v1377_14_write = v1377_14.write_zipper();
  let mut v1377_14_cursor = (*s0).read_zipper();
  let v1377_14_origin = v1377_14_cursor.path().len();
  for v1377_14_byte in v1377_14_cursor.child_mask().iter() {
    v1377_14_cursor.descend_to_existing_byte(v1377_14_byte);
    {
    for v1378_2_byte in v1377_14_cursor.child_mask().iter() {
      v1377_14_cursor.descend_to_existing_byte(v1378_2_byte);
      {
      for v1379_3_byte in v1377_14_cursor.child_mask().iter() {
        v1377_14_cursor.descend_to_existing_byte(v1379_3_byte);
        {
        for v1380_3_byte in v1377_14_cursor.child_mask().iter() {
          v1377_14_cursor.descend_to_existing_byte(v1380_3_byte);
          {
          for v1381_3_byte in v1377_14_cursor.child_mask().iter() {
            v1377_14_cursor.descend_to_existing_byte(v1381_3_byte);
            {
            for v1382_2_byte in v1377_14_cursor.child_mask().iter() {
              v1377_14_cursor.descend_to_existing_byte(v1382_2_byte);
              {
              for v1383_3_byte in v1377_14_cursor.child_mask().iter() {
                v1377_14_cursor.descend_to_existing_byte(v1383_3_byte);
                {
                for v1384_3_byte in v1377_14_cursor.child_mask().iter() {
                  v1377_14_cursor.descend_to_existing_byte(v1384_3_byte);
                  {
                  let v1385_3: Space = routine_144(c, &v1377_14_cursor.path()[(v1377_14_origin + 4)..(v1377_14_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &v1377_14_cursor.path()[v1377_14_origin..(v1377_14_origin + 4)], &v1377_14_cursor);
                  join_wrapped_into(&mut v1377_14_write,&((v1385_3).read_zipper()),&[]);
                  }
                  v1377_14_cursor.ascend(1);
                }
                }
                v1377_14_cursor.ascend(1);
              }
              }
              v1377_14_cursor.ascend(1);
            }
            }
            v1377_14_cursor.ascend(1);
          }
          }
          v1377_14_cursor.ascend(1);
        }
        }
        v1377_14_cursor.ascend(1);
      }
      }
      v1377_14_cursor.ascend(1);
    }
    }
    v1377_14_cursor.ascend(1);
  }
  drop(v1377_14_cursor);
  drop(v1377_14_write);
  (v1377_14).clone()
}

fn routine_129(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1386_14 = Space::new();
  let mut v1386_14_write = v1386_14.write_zipper();
  let mut v1386_14_cursor = (*s0).read_zipper();
  let v1386_14_origin = v1386_14_cursor.path().len();
  for v1386_14_byte in v1386_14_cursor.child_mask().iter() {
    v1386_14_cursor.descend_to_existing_byte(v1386_14_byte);
    {
    for v1387_2_byte in v1386_14_cursor.child_mask().iter() {
      v1386_14_cursor.descend_to_existing_byte(v1387_2_byte);
      {
      for v1388_3_byte in v1386_14_cursor.child_mask().iter() {
        v1386_14_cursor.descend_to_existing_byte(v1388_3_byte);
        {
        for v1389_3_byte in v1386_14_cursor.child_mask().iter() {
          v1386_14_cursor.descend_to_existing_byte(v1389_3_byte);
          {
          for v1390_3_byte in v1386_14_cursor.child_mask().iter() {
            v1386_14_cursor.descend_to_existing_byte(v1390_3_byte);
            {
            for v1391_2_byte in v1386_14_cursor.child_mask().iter() {
              v1386_14_cursor.descend_to_existing_byte(v1391_2_byte);
              {
              for v1392_3_byte in v1386_14_cursor.child_mask().iter() {
                v1386_14_cursor.descend_to_existing_byte(v1392_3_byte);
                {
                for v1393_3_byte in v1386_14_cursor.child_mask().iter() {
                  v1386_14_cursor.descend_to_existing_byte(v1393_3_byte);
                  {
                  let v1394_3: Space = routine_145(c, &v1386_14_cursor.path()[(v1386_14_origin + 4)..(v1386_14_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &v1386_14_cursor.path()[v1386_14_origin..(v1386_14_origin + 4)], &v1386_14_cursor);
                  join_wrapped_into(&mut v1386_14_write,&((v1394_3).read_zipper()),&[]);
                  }
                  v1386_14_cursor.ascend(1);
                }
                }
                v1386_14_cursor.ascend(1);
              }
              }
              v1386_14_cursor.ascend(1);
            }
            }
            v1386_14_cursor.ascend(1);
          }
          }
          v1386_14_cursor.ascend(1);
        }
        }
        v1386_14_cursor.ascend(1);
      }
      }
      v1386_14_cursor.ascend(1);
    }
    }
    v1386_14_cursor.ascend(1);
  }
  drop(v1386_14_cursor);
  drop(v1386_14_write);
  (v1386_14).clone()
}

fn routine_130(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1395_14 = Space::new();
  let mut v1395_14_write = v1395_14.write_zipper();
  let mut v1395_14_cursor = (*s0).read_zipper();
  let v1395_14_origin = v1395_14_cursor.path().len();
  for v1395_14_byte in v1395_14_cursor.child_mask().iter() {
    v1395_14_cursor.descend_to_existing_byte(v1395_14_byte);
    {
    for v1396_2_byte in v1395_14_cursor.child_mask().iter() {
      v1395_14_cursor.descend_to_existing_byte(v1396_2_byte);
      {
      for v1397_3_byte in v1395_14_cursor.child_mask().iter() {
        v1395_14_cursor.descend_to_existing_byte(v1397_3_byte);
        {
        for v1398_3_byte in v1395_14_cursor.child_mask().iter() {
          v1395_14_cursor.descend_to_existing_byte(v1398_3_byte);
          {
          for v1399_3_byte in v1395_14_cursor.child_mask().iter() {
            v1395_14_cursor.descend_to_existing_byte(v1399_3_byte);
            {
            for v1400_2_byte in v1395_14_cursor.child_mask().iter() {
              v1395_14_cursor.descend_to_existing_byte(v1400_2_byte);
              {
              for v1401_3_byte in v1395_14_cursor.child_mask().iter() {
                v1395_14_cursor.descend_to_existing_byte(v1401_3_byte);
                {
                for v1402_3_byte in v1395_14_cursor.child_mask().iter() {
                  v1395_14_cursor.descend_to_existing_byte(v1402_3_byte);
                  {
                  let v1403_3: Space = routine_146(c, &v1395_14_cursor.path()[(v1395_14_origin + 4)..(v1395_14_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &v1395_14_cursor.path()[v1395_14_origin..(v1395_14_origin + 4)], &v1395_14_cursor);
                  join_wrapped_into(&mut v1395_14_write,&((v1403_3).read_zipper()),&[]);
                  }
                  v1395_14_cursor.ascend(1);
                }
                }
                v1395_14_cursor.ascend(1);
              }
              }
              v1395_14_cursor.ascend(1);
            }
            }
            v1395_14_cursor.ascend(1);
          }
          }
          v1395_14_cursor.ascend(1);
        }
        }
        v1395_14_cursor.ascend(1);
      }
      }
      v1395_14_cursor.ascend(1);
    }
    }
    v1395_14_cursor.ascend(1);
  }
  drop(v1395_14_cursor);
  drop(v1395_14_write);
  (v1395_14).clone()
}

fn routine_131(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1404_14 = Space::new();
  let mut v1404_14_write = v1404_14.write_zipper();
  let mut v1404_14_cursor = (*s0).read_zipper();
  let v1404_14_origin = v1404_14_cursor.path().len();
  for v1404_14_byte in v1404_14_cursor.child_mask().iter() {
    v1404_14_cursor.descend_to_existing_byte(v1404_14_byte);
    {
    for v1405_2_byte in v1404_14_cursor.child_mask().iter() {
      v1404_14_cursor.descend_to_existing_byte(v1405_2_byte);
      {
      for v1406_3_byte in v1404_14_cursor.child_mask().iter() {
        v1404_14_cursor.descend_to_existing_byte(v1406_3_byte);
        {
        for v1407_3_byte in v1404_14_cursor.child_mask().iter() {
          v1404_14_cursor.descend_to_existing_byte(v1407_3_byte);
          {
          for v1408_3_byte in v1404_14_cursor.child_mask().iter() {
            v1404_14_cursor.descend_to_existing_byte(v1408_3_byte);
            {
            for v1409_2_byte in v1404_14_cursor.child_mask().iter() {
              v1404_14_cursor.descend_to_existing_byte(v1409_2_byte);
              {
              for v1410_3_byte in v1404_14_cursor.child_mask().iter() {
                v1404_14_cursor.descend_to_existing_byte(v1410_3_byte);
                {
                for v1411_3_byte in v1404_14_cursor.child_mask().iter() {
                  v1404_14_cursor.descend_to_existing_byte(v1411_3_byte);
                  {
                  let v1412_3: Space = routine_147(c, &v1404_14_cursor.path()[(v1404_14_origin + 4)..(v1404_14_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &v1404_14_cursor.path()[v1404_14_origin..(v1404_14_origin + 4)], &v1404_14_cursor);
                  join_wrapped_into(&mut v1404_14_write,&((v1412_3).read_zipper()),&[]);
                  }
                  v1404_14_cursor.ascend(1);
                }
                }
                v1404_14_cursor.ascend(1);
              }
              }
              v1404_14_cursor.ascend(1);
            }
            }
            v1404_14_cursor.ascend(1);
          }
          }
          v1404_14_cursor.ascend(1);
        }
        }
        v1404_14_cursor.ascend(1);
      }
      }
      v1404_14_cursor.ascend(1);
    }
    }
    v1404_14_cursor.ascend(1);
  }
  drop(v1404_14_cursor);
  drop(v1404_14_write);
  (v1404_14).clone()
}

fn routine_132(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1413_14 = Space::new();
  let mut v1413_14_write = v1413_14.write_zipper();
  let mut v1413_14_cursor = (*s0).read_zipper();
  let v1413_14_origin = v1413_14_cursor.path().len();
  for v1413_14_byte in v1413_14_cursor.child_mask().iter() {
    v1413_14_cursor.descend_to_existing_byte(v1413_14_byte);
    {
    for v1414_2_byte in v1413_14_cursor.child_mask().iter() {
      v1413_14_cursor.descend_to_existing_byte(v1414_2_byte);
      {
      for v1415_3_byte in v1413_14_cursor.child_mask().iter() {
        v1413_14_cursor.descend_to_existing_byte(v1415_3_byte);
        {
        for v1416_3_byte in v1413_14_cursor.child_mask().iter() {
          v1413_14_cursor.descend_to_existing_byte(v1416_3_byte);
          {
          for v1417_3_byte in v1413_14_cursor.child_mask().iter() {
            v1413_14_cursor.descend_to_existing_byte(v1417_3_byte);
            {
            for v1418_2_byte in v1413_14_cursor.child_mask().iter() {
              v1413_14_cursor.descend_to_existing_byte(v1418_2_byte);
              {
              for v1419_3_byte in v1413_14_cursor.child_mask().iter() {
                v1413_14_cursor.descend_to_existing_byte(v1419_3_byte);
                {
                for v1420_3_byte in v1413_14_cursor.child_mask().iter() {
                  v1413_14_cursor.descend_to_existing_byte(v1420_3_byte);
                  {
                  let v1421_3: Space = routine_148(c, &v1413_14_cursor.path()[(v1413_14_origin + 4)..(v1413_14_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &v1413_14_cursor.path()[v1413_14_origin..(v1413_14_origin + 4)], &v1413_14_cursor);
                  join_wrapped_into(&mut v1413_14_write,&((v1421_3).read_zipper()),&[]);
                  }
                  v1413_14_cursor.ascend(1);
                }
                }
                v1413_14_cursor.ascend(1);
              }
              }
              v1413_14_cursor.ascend(1);
            }
            }
            v1413_14_cursor.ascend(1);
          }
          }
          v1413_14_cursor.ascend(1);
        }
        }
        v1413_14_cursor.ascend(1);
      }
      }
      v1413_14_cursor.ascend(1);
    }
    }
    v1413_14_cursor.ascend(1);
  }
  drop(v1413_14_cursor);
  drop(v1413_14_write);
  (v1413_14).clone()
}

fn routine_133(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1422_14 = Space::new();
  let mut v1422_14_write = v1422_14.write_zipper();
  let mut v1422_14_cursor = (*s0).read_zipper();
  let v1422_14_origin = v1422_14_cursor.path().len();
  for v1422_14_byte in v1422_14_cursor.child_mask().iter() {
    v1422_14_cursor.descend_to_existing_byte(v1422_14_byte);
    {
    for v1423_2_byte in v1422_14_cursor.child_mask().iter() {
      v1422_14_cursor.descend_to_existing_byte(v1423_2_byte);
      {
      for v1424_3_byte in v1422_14_cursor.child_mask().iter() {
        v1422_14_cursor.descend_to_existing_byte(v1424_3_byte);
        {
        for v1425_3_byte in v1422_14_cursor.child_mask().iter() {
          v1422_14_cursor.descend_to_existing_byte(v1425_3_byte);
          {
          for v1426_3_byte in v1422_14_cursor.child_mask().iter() {
            v1422_14_cursor.descend_to_existing_byte(v1426_3_byte);
            {
            for v1427_2_byte in v1422_14_cursor.child_mask().iter() {
              v1422_14_cursor.descend_to_existing_byte(v1427_2_byte);
              {
              for v1428_3_byte in v1422_14_cursor.child_mask().iter() {
                v1422_14_cursor.descend_to_existing_byte(v1428_3_byte);
                {
                for v1429_3_byte in v1422_14_cursor.child_mask().iter() {
                  v1422_14_cursor.descend_to_existing_byte(v1429_3_byte);
                  {
                  let v1430_3: Space = routine_149(c, &v1422_14_cursor.path()[(v1422_14_origin + 4)..(v1422_14_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &v1422_14_cursor.path()[v1422_14_origin..(v1422_14_origin + 4)], &v1422_14_cursor);
                  join_wrapped_into(&mut v1422_14_write,&((v1430_3).read_zipper()),&[]);
                  }
                  v1422_14_cursor.ascend(1);
                }
                }
                v1422_14_cursor.ascend(1);
              }
              }
              v1422_14_cursor.ascend(1);
            }
            }
            v1422_14_cursor.ascend(1);
          }
          }
          v1422_14_cursor.ascend(1);
        }
        }
        v1422_14_cursor.ascend(1);
      }
      }
      v1422_14_cursor.ascend(1);
    }
    }
    v1422_14_cursor.ascend(1);
  }
  drop(v1422_14_cursor);
  drop(v1422_14_write);
  (v1422_14).clone()
}

fn routine_134(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1431_14 = Space::new();
  let mut v1431_14_write = v1431_14.write_zipper();
  let mut v1431_14_cursor = (*s0).read_zipper();
  let v1431_14_origin = v1431_14_cursor.path().len();
  for v1431_14_byte in v1431_14_cursor.child_mask().iter() {
    v1431_14_cursor.descend_to_existing_byte(v1431_14_byte);
    {
    for v1432_2_byte in v1431_14_cursor.child_mask().iter() {
      v1431_14_cursor.descend_to_existing_byte(v1432_2_byte);
      {
      for v1433_3_byte in v1431_14_cursor.child_mask().iter() {
        v1431_14_cursor.descend_to_existing_byte(v1433_3_byte);
        {
        for v1434_3_byte in v1431_14_cursor.child_mask().iter() {
          v1431_14_cursor.descend_to_existing_byte(v1434_3_byte);
          {
          for v1435_3_byte in v1431_14_cursor.child_mask().iter() {
            v1431_14_cursor.descend_to_existing_byte(v1435_3_byte);
            {
            for v1436_2_byte in v1431_14_cursor.child_mask().iter() {
              v1431_14_cursor.descend_to_existing_byte(v1436_2_byte);
              {
              for v1437_3_byte in v1431_14_cursor.child_mask().iter() {
                v1431_14_cursor.descend_to_existing_byte(v1437_3_byte);
                {
                for v1438_3_byte in v1431_14_cursor.child_mask().iter() {
                  v1431_14_cursor.descend_to_existing_byte(v1438_3_byte);
                  {
                  let v1439_3: Space = routine_150(c, &v1431_14_cursor.path()[(v1431_14_origin + 4)..(v1431_14_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &v1431_14_cursor.path()[v1431_14_origin..(v1431_14_origin + 4)], &v1431_14_cursor);
                  join_wrapped_into(&mut v1431_14_write,&((v1439_3).read_zipper()),&[]);
                  }
                  v1431_14_cursor.ascend(1);
                }
                }
                v1431_14_cursor.ascend(1);
              }
              }
              v1431_14_cursor.ascend(1);
            }
            }
            v1431_14_cursor.ascend(1);
          }
          }
          v1431_14_cursor.ascend(1);
        }
        }
        v1431_14_cursor.ascend(1);
      }
      }
      v1431_14_cursor.ascend(1);
    }
    }
    v1431_14_cursor.ascend(1);
  }
  drop(v1431_14_cursor);
  drop(v1431_14_write);
  (v1431_14).clone()
}

fn routine_135(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1440_14 = Space::new();
  let mut v1440_14_write = v1440_14.write_zipper();
  let mut v1440_14_cursor = (*s0).read_zipper();
  let v1440_14_origin = v1440_14_cursor.path().len();
  for v1440_14_byte in v1440_14_cursor.child_mask().iter() {
    v1440_14_cursor.descend_to_existing_byte(v1440_14_byte);
    {
    for v1441_2_byte in v1440_14_cursor.child_mask().iter() {
      v1440_14_cursor.descend_to_existing_byte(v1441_2_byte);
      {
      for v1442_3_byte in v1440_14_cursor.child_mask().iter() {
        v1440_14_cursor.descend_to_existing_byte(v1442_3_byte);
        {
        for v1443_3_byte in v1440_14_cursor.child_mask().iter() {
          v1440_14_cursor.descend_to_existing_byte(v1443_3_byte);
          {
          for v1444_3_byte in v1440_14_cursor.child_mask().iter() {
            v1440_14_cursor.descend_to_existing_byte(v1444_3_byte);
            {
            for v1445_2_byte in v1440_14_cursor.child_mask().iter() {
              v1440_14_cursor.descend_to_existing_byte(v1445_2_byte);
              {
              for v1446_3_byte in v1440_14_cursor.child_mask().iter() {
                v1440_14_cursor.descend_to_existing_byte(v1446_3_byte);
                {
                for v1447_3_byte in v1440_14_cursor.child_mask().iter() {
                  v1440_14_cursor.descend_to_existing_byte(v1447_3_byte);
                  {
                  let v1448_3: Space = routine_151(c, &v1440_14_cursor.path()[(v1440_14_origin + 4)..(v1440_14_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &v1440_14_cursor.path()[v1440_14_origin..(v1440_14_origin + 4)], &v1440_14_cursor);
                  join_wrapped_into(&mut v1440_14_write,&((v1448_3).read_zipper()),&[]);
                  }
                  v1440_14_cursor.ascend(1);
                }
                }
                v1440_14_cursor.ascend(1);
              }
              }
              v1440_14_cursor.ascend(1);
            }
            }
            v1440_14_cursor.ascend(1);
          }
          }
          v1440_14_cursor.ascend(1);
        }
        }
        v1440_14_cursor.ascend(1);
      }
      }
      v1440_14_cursor.ascend(1);
    }
    }
    v1440_14_cursor.ascend(1);
  }
  drop(v1440_14_cursor);
  drop(v1440_14_write);
  (v1440_14).clone()
}

fn routine_136(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1449_14 = Space::new();
  let mut v1449_14_write = v1449_14.write_zipper();
  let mut v1449_14_cursor = (*s0).read_zipper();
  let v1449_14_origin = v1449_14_cursor.path().len();
  for v1449_14_byte in v1449_14_cursor.child_mask().iter() {
    v1449_14_cursor.descend_to_existing_byte(v1449_14_byte);
    {
    for v1450_2_byte in v1449_14_cursor.child_mask().iter() {
      v1449_14_cursor.descend_to_existing_byte(v1450_2_byte);
      {
      for v1451_3_byte in v1449_14_cursor.child_mask().iter() {
        v1449_14_cursor.descend_to_existing_byte(v1451_3_byte);
        {
        for v1452_3_byte in v1449_14_cursor.child_mask().iter() {
          v1449_14_cursor.descend_to_existing_byte(v1452_3_byte);
          {
          for v1453_3_byte in v1449_14_cursor.child_mask().iter() {
            v1449_14_cursor.descend_to_existing_byte(v1453_3_byte);
            {
            for v1454_2_byte in v1449_14_cursor.child_mask().iter() {
              v1449_14_cursor.descend_to_existing_byte(v1454_2_byte);
              {
              for v1455_3_byte in v1449_14_cursor.child_mask().iter() {
                v1449_14_cursor.descend_to_existing_byte(v1455_3_byte);
                {
                for v1456_3_byte in v1449_14_cursor.child_mask().iter() {
                  v1449_14_cursor.descend_to_existing_byte(v1456_3_byte);
                  {
                  let v1457_3: Space = routine_152(c, &v1449_14_cursor.path()[(v1449_14_origin + 4)..(v1449_14_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &v1449_14_cursor.path()[v1449_14_origin..(v1449_14_origin + 4)], &v1449_14_cursor);
                  join_wrapped_into(&mut v1449_14_write,&((v1457_3).read_zipper()),&[]);
                  }
                  v1449_14_cursor.ascend(1);
                }
                }
                v1449_14_cursor.ascend(1);
              }
              }
              v1449_14_cursor.ascend(1);
            }
            }
            v1449_14_cursor.ascend(1);
          }
          }
          v1449_14_cursor.ascend(1);
        }
        }
        v1449_14_cursor.ascend(1);
      }
      }
      v1449_14_cursor.ascend(1);
    }
    }
    v1449_14_cursor.ascend(1);
  }
  drop(v1449_14_cursor);
  drop(v1449_14_write);
  (v1449_14).clone()
}

fn routine_137(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1458_14 = Space::new();
  let mut v1458_14_write = v1458_14.write_zipper();
  let mut v1458_14_cursor = (*s0).read_zipper();
  let v1458_14_origin = v1458_14_cursor.path().len();
  for v1458_14_byte in v1458_14_cursor.child_mask().iter() {
    v1458_14_cursor.descend_to_existing_byte(v1458_14_byte);
    {
    for v1459_2_byte in v1458_14_cursor.child_mask().iter() {
      v1458_14_cursor.descend_to_existing_byte(v1459_2_byte);
      {
      for v1460_3_byte in v1458_14_cursor.child_mask().iter() {
        v1458_14_cursor.descend_to_existing_byte(v1460_3_byte);
        {
        for v1461_3_byte in v1458_14_cursor.child_mask().iter() {
          v1458_14_cursor.descend_to_existing_byte(v1461_3_byte);
          {
          for v1462_3_byte in v1458_14_cursor.child_mask().iter() {
            v1458_14_cursor.descend_to_existing_byte(v1462_3_byte);
            {
            for v1463_2_byte in v1458_14_cursor.child_mask().iter() {
              v1458_14_cursor.descend_to_existing_byte(v1463_2_byte);
              {
              for v1464_3_byte in v1458_14_cursor.child_mask().iter() {
                v1458_14_cursor.descend_to_existing_byte(v1464_3_byte);
                {
                for v1465_3_byte in v1458_14_cursor.child_mask().iter() {
                  v1458_14_cursor.descend_to_existing_byte(v1465_3_byte);
                  {
                  let v1466_3: Space = routine_153(c, &v1458_14_cursor.path()[(v1458_14_origin + 4)..(v1458_14_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &v1458_14_cursor.path()[v1458_14_origin..(v1458_14_origin + 4)], &v1458_14_cursor);
                  join_wrapped_into(&mut v1458_14_write,&((v1466_3).read_zipper()),&[]);
                  }
                  v1458_14_cursor.ascend(1);
                }
                }
                v1458_14_cursor.ascend(1);
              }
              }
              v1458_14_cursor.ascend(1);
            }
            }
            v1458_14_cursor.ascend(1);
          }
          }
          v1458_14_cursor.ascend(1);
        }
        }
        v1458_14_cursor.ascend(1);
      }
      }
      v1458_14_cursor.ascend(1);
    }
    }
    v1458_14_cursor.ascend(1);
  }
  drop(v1458_14_cursor);
  drop(v1458_14_write);
  (v1458_14).clone()
}

fn routine_138(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1467_14 = Space::new();
  let mut v1467_14_write = v1467_14.write_zipper();
  let mut v1467_14_cursor = (*s0).read_zipper();
  let v1467_14_origin = v1467_14_cursor.path().len();
  for v1467_14_byte in v1467_14_cursor.child_mask().iter() {
    v1467_14_cursor.descend_to_existing_byte(v1467_14_byte);
    {
    for v1468_2_byte in v1467_14_cursor.child_mask().iter() {
      v1467_14_cursor.descend_to_existing_byte(v1468_2_byte);
      {
      for v1469_3_byte in v1467_14_cursor.child_mask().iter() {
        v1467_14_cursor.descend_to_existing_byte(v1469_3_byte);
        {
        for v1470_3_byte in v1467_14_cursor.child_mask().iter() {
          v1467_14_cursor.descend_to_existing_byte(v1470_3_byte);
          {
          for v1471_3_byte in v1467_14_cursor.child_mask().iter() {
            v1467_14_cursor.descend_to_existing_byte(v1471_3_byte);
            {
            for v1472_2_byte in v1467_14_cursor.child_mask().iter() {
              v1467_14_cursor.descend_to_existing_byte(v1472_2_byte);
              {
              for v1473_3_byte in v1467_14_cursor.child_mask().iter() {
                v1467_14_cursor.descend_to_existing_byte(v1473_3_byte);
                {
                for v1474_3_byte in v1467_14_cursor.child_mask().iter() {
                  v1467_14_cursor.descend_to_existing_byte(v1474_3_byte);
                  {
                  let v1475_3: Space = routine_154(c, &v1467_14_cursor.path()[(v1467_14_origin + 4)..(v1467_14_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &v1467_14_cursor.path()[v1467_14_origin..(v1467_14_origin + 4)], &v1467_14_cursor);
                  join_wrapped_into(&mut v1467_14_write,&((v1475_3).read_zipper()),&[]);
                  }
                  v1467_14_cursor.ascend(1);
                }
                }
                v1467_14_cursor.ascend(1);
              }
              }
              v1467_14_cursor.ascend(1);
            }
            }
            v1467_14_cursor.ascend(1);
          }
          }
          v1467_14_cursor.ascend(1);
        }
        }
        v1467_14_cursor.ascend(1);
      }
      }
      v1467_14_cursor.ascend(1);
    }
    }
    v1467_14_cursor.ascend(1);
  }
  drop(v1467_14_cursor);
  drop(v1467_14_write);
  (v1467_14).clone()
}

fn routine_139(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1476_14 = Space::new();
  let mut v1476_14_write = v1476_14.write_zipper();
  let mut v1476_14_cursor = (*s0).read_zipper();
  let v1476_14_origin = v1476_14_cursor.path().len();
  for v1476_14_byte in v1476_14_cursor.child_mask().iter() {
    v1476_14_cursor.descend_to_existing_byte(v1476_14_byte);
    {
    for v1477_2_byte in v1476_14_cursor.child_mask().iter() {
      v1476_14_cursor.descend_to_existing_byte(v1477_2_byte);
      {
      for v1478_3_byte in v1476_14_cursor.child_mask().iter() {
        v1476_14_cursor.descend_to_existing_byte(v1478_3_byte);
        {
        for v1479_3_byte in v1476_14_cursor.child_mask().iter() {
          v1476_14_cursor.descend_to_existing_byte(v1479_3_byte);
          {
          for v1480_3_byte in v1476_14_cursor.child_mask().iter() {
            v1476_14_cursor.descend_to_existing_byte(v1480_3_byte);
            {
            for v1481_2_byte in v1476_14_cursor.child_mask().iter() {
              v1476_14_cursor.descend_to_existing_byte(v1481_2_byte);
              {
              for v1482_3_byte in v1476_14_cursor.child_mask().iter() {
                v1476_14_cursor.descend_to_existing_byte(v1482_3_byte);
                {
                for v1483_3_byte in v1476_14_cursor.child_mask().iter() {
                  v1476_14_cursor.descend_to_existing_byte(v1483_3_byte);
                  {
                  let v1484_3: Space = routine_155(c, &v1476_14_cursor.path()[(v1476_14_origin + 4)..(v1476_14_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &v1476_14_cursor.path()[v1476_14_origin..(v1476_14_origin + 4)], &v1476_14_cursor);
                  join_wrapped_into(&mut v1476_14_write,&((v1484_3).read_zipper()),&[]);
                  }
                  v1476_14_cursor.ascend(1);
                }
                }
                v1476_14_cursor.ascend(1);
              }
              }
              v1476_14_cursor.ascend(1);
            }
            }
            v1476_14_cursor.ascend(1);
          }
          }
          v1476_14_cursor.ascend(1);
        }
        }
        v1476_14_cursor.ascend(1);
      }
      }
      v1476_14_cursor.ascend(1);
    }
    }
    v1476_14_cursor.ascend(1);
  }
  drop(v1476_14_cursor);
  drop(v1476_14_write);
  (v1476_14).clone()
}

fn routine_140(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1485_14 = Space::new();
  let mut v1485_14_write = v1485_14.write_zipper();
  let mut v1485_14_cursor = (*s0).read_zipper();
  let v1485_14_origin = v1485_14_cursor.path().len();
  for v1485_14_byte in v1485_14_cursor.child_mask().iter() {
    v1485_14_cursor.descend_to_existing_byte(v1485_14_byte);
    {
    for v1486_2_byte in v1485_14_cursor.child_mask().iter() {
      v1485_14_cursor.descend_to_existing_byte(v1486_2_byte);
      {
      for v1487_3_byte in v1485_14_cursor.child_mask().iter() {
        v1485_14_cursor.descend_to_existing_byte(v1487_3_byte);
        {
        for v1488_3_byte in v1485_14_cursor.child_mask().iter() {
          v1485_14_cursor.descend_to_existing_byte(v1488_3_byte);
          {
          for v1489_3_byte in v1485_14_cursor.child_mask().iter() {
            v1485_14_cursor.descend_to_existing_byte(v1489_3_byte);
            {
            for v1490_2_byte in v1485_14_cursor.child_mask().iter() {
              v1485_14_cursor.descend_to_existing_byte(v1490_2_byte);
              {
              for v1491_3_byte in v1485_14_cursor.child_mask().iter() {
                v1485_14_cursor.descend_to_existing_byte(v1491_3_byte);
                {
                for v1492_3_byte in v1485_14_cursor.child_mask().iter() {
                  v1485_14_cursor.descend_to_existing_byte(v1492_3_byte);
                  {
                  let v1493_3: Space = routine_156(c, &v1485_14_cursor.path()[(v1485_14_origin + 4)..(v1485_14_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &v1485_14_cursor.path()[v1485_14_origin..(v1485_14_origin + 4)], &v1485_14_cursor);
                  join_wrapped_into(&mut v1485_14_write,&((v1493_3).read_zipper()),&[]);
                  }
                  v1485_14_cursor.ascend(1);
                }
                }
                v1485_14_cursor.ascend(1);
              }
              }
              v1485_14_cursor.ascend(1);
            }
            }
            v1485_14_cursor.ascend(1);
          }
          }
          v1485_14_cursor.ascend(1);
        }
        }
        v1485_14_cursor.ascend(1);
      }
      }
      v1485_14_cursor.ascend(1);
    }
    }
    v1485_14_cursor.ascend(1);
  }
  drop(v1485_14_cursor);
  drop(v1485_14_write);
  (v1485_14).clone()
}

fn routine_141(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1494_14 = Space::new();
  let mut v1494_14_write = v1494_14.write_zipper();
  let mut v1494_14_cursor = (*s0).read_zipper();
  let v1494_14_origin = v1494_14_cursor.path().len();
  for v1494_14_byte in v1494_14_cursor.child_mask().iter() {
    v1494_14_cursor.descend_to_existing_byte(v1494_14_byte);
    {
    for v1495_2_byte in v1494_14_cursor.child_mask().iter() {
      v1494_14_cursor.descend_to_existing_byte(v1495_2_byte);
      {
      for v1496_3_byte in v1494_14_cursor.child_mask().iter() {
        v1494_14_cursor.descend_to_existing_byte(v1496_3_byte);
        {
        for v1497_3_byte in v1494_14_cursor.child_mask().iter() {
          v1494_14_cursor.descend_to_existing_byte(v1497_3_byte);
          {
          for v1498_3_byte in v1494_14_cursor.child_mask().iter() {
            v1494_14_cursor.descend_to_existing_byte(v1498_3_byte);
            {
            for v1499_2_byte in v1494_14_cursor.child_mask().iter() {
              v1494_14_cursor.descend_to_existing_byte(v1499_2_byte);
              {
              for v1500_3_byte in v1494_14_cursor.child_mask().iter() {
                v1494_14_cursor.descend_to_existing_byte(v1500_3_byte);
                {
                for v1501_3_byte in v1494_14_cursor.child_mask().iter() {
                  v1494_14_cursor.descend_to_existing_byte(v1501_3_byte);
                  {
                  let v1502_3: Space = routine_157(c, &v1494_14_cursor.path()[(v1494_14_origin + 4)..(v1494_14_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &v1494_14_cursor.path()[v1494_14_origin..(v1494_14_origin + 4)], &v1494_14_cursor);
                  join_wrapped_into(&mut v1494_14_write,&((v1502_3).read_zipper()),&[]);
                  }
                  v1494_14_cursor.ascend(1);
                }
                }
                v1494_14_cursor.ascend(1);
              }
              }
              v1494_14_cursor.ascend(1);
            }
            }
            v1494_14_cursor.ascend(1);
          }
          }
          v1494_14_cursor.ascend(1);
        }
        }
        v1494_14_cursor.ascend(1);
      }
      }
      v1494_14_cursor.ascend(1);
    }
    }
    v1494_14_cursor.ascend(1);
  }
  drop(v1494_14_cursor);
  drop(v1494_14_write);
  (v1494_14).clone()
}

fn routine_142(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1503_14 = Space::new();
  let mut v1503_14_write = v1503_14.write_zipper();
  let mut v1503_14_cursor = (*s0).read_zipper();
  let v1503_14_origin = v1503_14_cursor.path().len();
  for v1503_14_byte in v1503_14_cursor.child_mask().iter() {
    v1503_14_cursor.descend_to_existing_byte(v1503_14_byte);
    {
    for v1504_2_byte in v1503_14_cursor.child_mask().iter() {
      v1503_14_cursor.descend_to_existing_byte(v1504_2_byte);
      {
      for v1505_3_byte in v1503_14_cursor.child_mask().iter() {
        v1503_14_cursor.descend_to_existing_byte(v1505_3_byte);
        {
        for v1506_3_byte in v1503_14_cursor.child_mask().iter() {
          v1503_14_cursor.descend_to_existing_byte(v1506_3_byte);
          {
          for v1507_3_byte in v1503_14_cursor.child_mask().iter() {
            v1503_14_cursor.descend_to_existing_byte(v1507_3_byte);
            {
            for v1508_2_byte in v1503_14_cursor.child_mask().iter() {
              v1503_14_cursor.descend_to_existing_byte(v1508_2_byte);
              {
              for v1509_3_byte in v1503_14_cursor.child_mask().iter() {
                v1503_14_cursor.descend_to_existing_byte(v1509_3_byte);
                {
                for v1510_3_byte in v1503_14_cursor.child_mask().iter() {
                  v1503_14_cursor.descend_to_existing_byte(v1510_3_byte);
                  {
                  let v1511_3: Space = routine_158(c, &v1503_14_cursor.path()[(v1503_14_origin + 4)..(v1503_14_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &v1503_14_cursor.path()[v1503_14_origin..(v1503_14_origin + 4)], &v1503_14_cursor);
                  join_wrapped_into(&mut v1503_14_write,&((v1511_3).read_zipper()),&[]);
                  }
                  v1503_14_cursor.ascend(1);
                }
                }
                v1503_14_cursor.ascend(1);
              }
              }
              v1503_14_cursor.ascend(1);
            }
            }
            v1503_14_cursor.ascend(1);
          }
          }
          v1503_14_cursor.ascend(1);
        }
        }
        v1503_14_cursor.ascend(1);
      }
      }
      v1503_14_cursor.ascend(1);
    }
    }
    v1503_14_cursor.ascend(1);
  }
  drop(v1503_14_cursor);
  drop(v1503_14_write);
  (v1503_14).clone()
}

fn routine_143(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], p13: &[u8], p14: &[u8], s0: &View<'_, '_>) -> Space {
  let v1512_18: Path = concat_path(&(*CONSTANT_3),&(*p1));
  let v1512_19: Space = singleton(&(v1512_18));
  drop(v1512_18);
  let v1512_20: Space = unite(&(*CONSTANT_84),&(v1512_19));
  drop(v1512_19);
  let v1512_22: Path = concat_path(&(*CONSTANT_5),&(*p2));
  let v1512_23: Space = singleton(&(v1512_22));
  drop(v1512_22);
  let v1512_24: Space = unite(&(v1512_20),&(v1512_23));
  drop(v1512_20);
  drop(v1512_23);
  let v1512_26: Path = concat_path(&(*CONSTANT_7),&(*p3));
  let v1512_27: Space = singleton(&(v1512_26));
  drop(v1512_26);
  let v1512_28: Space = unite(&(v1512_24),&(v1512_27));
  drop(v1512_24);
  drop(v1512_27);
  let v1512_30: Path = concat_path(&(*CONSTANT_9),&(*p4));
  let v1512_31: Space = singleton(&(v1512_30));
  drop(v1512_30);
  let v1512_32: Space = unite(&(v1512_28),&(v1512_31));
  drop(v1512_28);
  drop(v1512_31);
  let v1512_34: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v1512_35: Space = singleton(&(v1512_34));
  drop(v1512_34);
  let v1512_36: Space = unite(&(v1512_32),&(v1512_35));
  drop(v1512_32);
  drop(v1512_35);
  let v1512_38: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v1512_39: Space = singleton(&(v1512_38));
  drop(v1512_38);
  let v1512_40: Space = unite(&(v1512_36),&(v1512_39));
  drop(v1512_36);
  drop(v1512_39);
  let v1512_42: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v1512_43: Space = singleton(&(v1512_42));
  drop(v1512_42);
  let v1512_44: Space = unite(&(v1512_40),&(v1512_43));
  drop(v1512_40);
  drop(v1512_43);
  let v1512_46: Path = concat_path(&(*CONSTANT_17),&(*p8));
  let v1512_47: Space = singleton(&(v1512_46));
  drop(v1512_46);
  let v1512_48: Space = unite(&(v1512_44),&(v1512_47));
  drop(v1512_44);
  drop(v1512_47);
  let v1512_50: Path = concat_path(&(*CONSTANT_19),&(*p9));
  let v1512_51: Space = singleton(&(v1512_50));
  drop(v1512_50);
  let v1512_52: Space = unite(&(v1512_48),&(v1512_51));
  drop(v1512_48);
  drop(v1512_51);
  let v1512_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1512_55: Space = singleton(&(v1512_54));
  drop(v1512_54);
  let v1512_56: Space = unite(&(v1512_52),&(v1512_55));
  drop(v1512_52);
  drop(v1512_55);
  let v1512_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1512_59: Space = singleton(&(v1512_58));
  drop(v1512_58);
  let v1512_60: Space = unite(&(v1512_56),&(v1512_59));
  drop(v1512_56);
  drop(v1512_59);
  let v1512_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1512_63: Space = singleton(&(v1512_62));
  drop(v1512_62);
  let v1512_64: Space = unite(&(v1512_60),&(v1512_63));
  drop(v1512_60);
  drop(v1512_63);
  let v1512_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1512_67: Space = singleton(&(v1512_66));
  drop(v1512_66);
  let v1512_68: Space = unite(&(v1512_64),&(v1512_67));
  drop(v1512_64);
  drop(v1512_67);
  let v1512_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1512_71: Space = singleton(&(v1512_70));
  drop(v1512_70);
  let v1512_72: Space = unite(&(v1512_68),&(v1512_71));
  drop(v1512_68);
  drop(v1512_71);
  let v1512_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1512_75: Space = singleton(&(v1512_74));
  drop(v1512_74);
  let v1512_76: Space = unite(&(v1512_72),&(v1512_75));
  drop(v1512_72);
  drop(v1512_75);
  (v1512_76).clone()
}

fn routine_144(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], p13: &[u8], p14: &[u8], s0: &View<'_, '_>) -> Space {
  let v1513_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1513_19: Space = singleton(&(v1513_18));
  drop(v1513_18);
  let v1513_20: Space = unite(&(*CONSTANT_85),&(v1513_19));
  drop(v1513_19);
  let v1513_22: Path = concat_path(&(*CONSTANT_5),&(*p2));
  let v1513_23: Space = singleton(&(v1513_22));
  drop(v1513_22);
  let v1513_24: Space = unite(&(v1513_20),&(v1513_23));
  drop(v1513_20);
  drop(v1513_23);
  let v1513_26: Path = concat_path(&(*CONSTANT_7),&(*p3));
  let v1513_27: Space = singleton(&(v1513_26));
  drop(v1513_26);
  let v1513_28: Space = unite(&(v1513_24),&(v1513_27));
  drop(v1513_24);
  drop(v1513_27);
  let v1513_30: Path = concat_path(&(*CONSTANT_9),&(*p4));
  let v1513_31: Space = singleton(&(v1513_30));
  drop(v1513_30);
  let v1513_32: Space = unite(&(v1513_28),&(v1513_31));
  drop(v1513_28);
  drop(v1513_31);
  let v1513_34: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v1513_35: Space = singleton(&(v1513_34));
  drop(v1513_34);
  let v1513_36: Space = unite(&(v1513_32),&(v1513_35));
  drop(v1513_32);
  drop(v1513_35);
  let v1513_38: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v1513_39: Space = singleton(&(v1513_38));
  drop(v1513_38);
  let v1513_40: Space = unite(&(v1513_36),&(v1513_39));
  drop(v1513_36);
  drop(v1513_39);
  let v1513_42: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v1513_43: Space = singleton(&(v1513_42));
  drop(v1513_42);
  let v1513_44: Space = unite(&(v1513_40),&(v1513_43));
  drop(v1513_40);
  drop(v1513_43);
  let v1513_46: Path = concat_path(&(*CONSTANT_17),&(*p8));
  let v1513_47: Space = singleton(&(v1513_46));
  drop(v1513_46);
  let v1513_48: Space = unite(&(v1513_44),&(v1513_47));
  drop(v1513_44);
  drop(v1513_47);
  let v1513_50: Path = concat_path(&(*CONSTANT_19),&(*p9));
  let v1513_51: Space = singleton(&(v1513_50));
  drop(v1513_50);
  let v1513_52: Space = unite(&(v1513_48),&(v1513_51));
  drop(v1513_48);
  drop(v1513_51);
  let v1513_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1513_55: Space = singleton(&(v1513_54));
  drop(v1513_54);
  let v1513_56: Space = unite(&(v1513_52),&(v1513_55));
  drop(v1513_52);
  drop(v1513_55);
  let v1513_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1513_59: Space = singleton(&(v1513_58));
  drop(v1513_58);
  let v1513_60: Space = unite(&(v1513_56),&(v1513_59));
  drop(v1513_56);
  drop(v1513_59);
  let v1513_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1513_63: Space = singleton(&(v1513_62));
  drop(v1513_62);
  let v1513_64: Space = unite(&(v1513_60),&(v1513_63));
  drop(v1513_60);
  drop(v1513_63);
  let v1513_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1513_67: Space = singleton(&(v1513_66));
  drop(v1513_66);
  let v1513_68: Space = unite(&(v1513_64),&(v1513_67));
  drop(v1513_64);
  drop(v1513_67);
  let v1513_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1513_71: Space = singleton(&(v1513_70));
  drop(v1513_70);
  let v1513_72: Space = unite(&(v1513_68),&(v1513_71));
  drop(v1513_68);
  drop(v1513_71);
  let v1513_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1513_75: Space = singleton(&(v1513_74));
  drop(v1513_74);
  let v1513_76: Space = unite(&(v1513_72),&(v1513_75));
  drop(v1513_72);
  drop(v1513_75);
  (v1513_76).clone()
}

fn routine_145(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], p13: &[u8], p14: &[u8], s0: &View<'_, '_>) -> Space {
  let v1514_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1514_19: Space = singleton(&(v1514_18));
  drop(v1514_18);
  let v1514_20: Space = unite(&(*CONSTANT_86),&(v1514_19));
  drop(v1514_19);
  let v1514_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1514_23: Space = singleton(&(v1514_22));
  drop(v1514_22);
  let v1514_24: Space = unite(&(v1514_20),&(v1514_23));
  drop(v1514_20);
  drop(v1514_23);
  let v1514_26: Path = concat_path(&(*CONSTANT_7),&(*p3));
  let v1514_27: Space = singleton(&(v1514_26));
  drop(v1514_26);
  let v1514_28: Space = unite(&(v1514_24),&(v1514_27));
  drop(v1514_24);
  drop(v1514_27);
  let v1514_30: Path = concat_path(&(*CONSTANT_9),&(*p4));
  let v1514_31: Space = singleton(&(v1514_30));
  drop(v1514_30);
  let v1514_32: Space = unite(&(v1514_28),&(v1514_31));
  drop(v1514_28);
  drop(v1514_31);
  let v1514_34: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v1514_35: Space = singleton(&(v1514_34));
  drop(v1514_34);
  let v1514_36: Space = unite(&(v1514_32),&(v1514_35));
  drop(v1514_32);
  drop(v1514_35);
  let v1514_38: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v1514_39: Space = singleton(&(v1514_38));
  drop(v1514_38);
  let v1514_40: Space = unite(&(v1514_36),&(v1514_39));
  drop(v1514_36);
  drop(v1514_39);
  let v1514_42: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v1514_43: Space = singleton(&(v1514_42));
  drop(v1514_42);
  let v1514_44: Space = unite(&(v1514_40),&(v1514_43));
  drop(v1514_40);
  drop(v1514_43);
  let v1514_46: Path = concat_path(&(*CONSTANT_17),&(*p8));
  let v1514_47: Space = singleton(&(v1514_46));
  drop(v1514_46);
  let v1514_48: Space = unite(&(v1514_44),&(v1514_47));
  drop(v1514_44);
  drop(v1514_47);
  let v1514_50: Path = concat_path(&(*CONSTANT_19),&(*p9));
  let v1514_51: Space = singleton(&(v1514_50));
  drop(v1514_50);
  let v1514_52: Space = unite(&(v1514_48),&(v1514_51));
  drop(v1514_48);
  drop(v1514_51);
  let v1514_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1514_55: Space = singleton(&(v1514_54));
  drop(v1514_54);
  let v1514_56: Space = unite(&(v1514_52),&(v1514_55));
  drop(v1514_52);
  drop(v1514_55);
  let v1514_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1514_59: Space = singleton(&(v1514_58));
  drop(v1514_58);
  let v1514_60: Space = unite(&(v1514_56),&(v1514_59));
  drop(v1514_56);
  drop(v1514_59);
  let v1514_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1514_63: Space = singleton(&(v1514_62));
  drop(v1514_62);
  let v1514_64: Space = unite(&(v1514_60),&(v1514_63));
  drop(v1514_60);
  drop(v1514_63);
  let v1514_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1514_67: Space = singleton(&(v1514_66));
  drop(v1514_66);
  let v1514_68: Space = unite(&(v1514_64),&(v1514_67));
  drop(v1514_64);
  drop(v1514_67);
  let v1514_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1514_71: Space = singleton(&(v1514_70));
  drop(v1514_70);
  let v1514_72: Space = unite(&(v1514_68),&(v1514_71));
  drop(v1514_68);
  drop(v1514_71);
  let v1514_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1514_75: Space = singleton(&(v1514_74));
  drop(v1514_74);
  let v1514_76: Space = unite(&(v1514_72),&(v1514_75));
  drop(v1514_72);
  drop(v1514_75);
  (v1514_76).clone()
}

fn routine_146(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], p13: &[u8], p14: &[u8], s0: &View<'_, '_>) -> Space {
  let v1515_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1515_19: Space = singleton(&(v1515_18));
  drop(v1515_18);
  let v1515_20: Space = unite(&(*CONSTANT_87),&(v1515_19));
  drop(v1515_19);
  let v1515_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1515_23: Space = singleton(&(v1515_22));
  drop(v1515_22);
  let v1515_24: Space = unite(&(v1515_20),&(v1515_23));
  drop(v1515_20);
  drop(v1515_23);
  let v1515_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1515_27: Space = singleton(&(v1515_26));
  drop(v1515_26);
  let v1515_28: Space = unite(&(v1515_24),&(v1515_27));
  drop(v1515_24);
  drop(v1515_27);
  let v1515_30: Path = concat_path(&(*CONSTANT_9),&(*p4));
  let v1515_31: Space = singleton(&(v1515_30));
  drop(v1515_30);
  let v1515_32: Space = unite(&(v1515_28),&(v1515_31));
  drop(v1515_28);
  drop(v1515_31);
  let v1515_34: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v1515_35: Space = singleton(&(v1515_34));
  drop(v1515_34);
  let v1515_36: Space = unite(&(v1515_32),&(v1515_35));
  drop(v1515_32);
  drop(v1515_35);
  let v1515_38: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v1515_39: Space = singleton(&(v1515_38));
  drop(v1515_38);
  let v1515_40: Space = unite(&(v1515_36),&(v1515_39));
  drop(v1515_36);
  drop(v1515_39);
  let v1515_42: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v1515_43: Space = singleton(&(v1515_42));
  drop(v1515_42);
  let v1515_44: Space = unite(&(v1515_40),&(v1515_43));
  drop(v1515_40);
  drop(v1515_43);
  let v1515_46: Path = concat_path(&(*CONSTANT_17),&(*p8));
  let v1515_47: Space = singleton(&(v1515_46));
  drop(v1515_46);
  let v1515_48: Space = unite(&(v1515_44),&(v1515_47));
  drop(v1515_44);
  drop(v1515_47);
  let v1515_50: Path = concat_path(&(*CONSTANT_19),&(*p9));
  let v1515_51: Space = singleton(&(v1515_50));
  drop(v1515_50);
  let v1515_52: Space = unite(&(v1515_48),&(v1515_51));
  drop(v1515_48);
  drop(v1515_51);
  let v1515_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1515_55: Space = singleton(&(v1515_54));
  drop(v1515_54);
  let v1515_56: Space = unite(&(v1515_52),&(v1515_55));
  drop(v1515_52);
  drop(v1515_55);
  let v1515_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1515_59: Space = singleton(&(v1515_58));
  drop(v1515_58);
  let v1515_60: Space = unite(&(v1515_56),&(v1515_59));
  drop(v1515_56);
  drop(v1515_59);
  let v1515_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1515_63: Space = singleton(&(v1515_62));
  drop(v1515_62);
  let v1515_64: Space = unite(&(v1515_60),&(v1515_63));
  drop(v1515_60);
  drop(v1515_63);
  let v1515_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1515_67: Space = singleton(&(v1515_66));
  drop(v1515_66);
  let v1515_68: Space = unite(&(v1515_64),&(v1515_67));
  drop(v1515_64);
  drop(v1515_67);
  let v1515_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1515_71: Space = singleton(&(v1515_70));
  drop(v1515_70);
  let v1515_72: Space = unite(&(v1515_68),&(v1515_71));
  drop(v1515_68);
  drop(v1515_71);
  let v1515_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1515_75: Space = singleton(&(v1515_74));
  drop(v1515_74);
  let v1515_76: Space = unite(&(v1515_72),&(v1515_75));
  drop(v1515_72);
  drop(v1515_75);
  (v1515_76).clone()
}

fn routine_147(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], p13: &[u8], p14: &[u8], s0: &View<'_, '_>) -> Space {
  let v1516_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1516_19: Space = singleton(&(v1516_18));
  drop(v1516_18);
  let v1516_20: Space = unite(&(*CONSTANT_88),&(v1516_19));
  drop(v1516_19);
  let v1516_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1516_23: Space = singleton(&(v1516_22));
  drop(v1516_22);
  let v1516_24: Space = unite(&(v1516_20),&(v1516_23));
  drop(v1516_20);
  drop(v1516_23);
  let v1516_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1516_27: Space = singleton(&(v1516_26));
  drop(v1516_26);
  let v1516_28: Space = unite(&(v1516_24),&(v1516_27));
  drop(v1516_24);
  drop(v1516_27);
  let v1516_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1516_31: Space = singleton(&(v1516_30));
  drop(v1516_30);
  let v1516_32: Space = unite(&(v1516_28),&(v1516_31));
  drop(v1516_28);
  drop(v1516_31);
  let v1516_34: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v1516_35: Space = singleton(&(v1516_34));
  drop(v1516_34);
  let v1516_36: Space = unite(&(v1516_32),&(v1516_35));
  drop(v1516_32);
  drop(v1516_35);
  let v1516_38: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v1516_39: Space = singleton(&(v1516_38));
  drop(v1516_38);
  let v1516_40: Space = unite(&(v1516_36),&(v1516_39));
  drop(v1516_36);
  drop(v1516_39);
  let v1516_42: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v1516_43: Space = singleton(&(v1516_42));
  drop(v1516_42);
  let v1516_44: Space = unite(&(v1516_40),&(v1516_43));
  drop(v1516_40);
  drop(v1516_43);
  let v1516_46: Path = concat_path(&(*CONSTANT_17),&(*p8));
  let v1516_47: Space = singleton(&(v1516_46));
  drop(v1516_46);
  let v1516_48: Space = unite(&(v1516_44),&(v1516_47));
  drop(v1516_44);
  drop(v1516_47);
  let v1516_50: Path = concat_path(&(*CONSTANT_19),&(*p9));
  let v1516_51: Space = singleton(&(v1516_50));
  drop(v1516_50);
  let v1516_52: Space = unite(&(v1516_48),&(v1516_51));
  drop(v1516_48);
  drop(v1516_51);
  let v1516_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1516_55: Space = singleton(&(v1516_54));
  drop(v1516_54);
  let v1516_56: Space = unite(&(v1516_52),&(v1516_55));
  drop(v1516_52);
  drop(v1516_55);
  let v1516_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1516_59: Space = singleton(&(v1516_58));
  drop(v1516_58);
  let v1516_60: Space = unite(&(v1516_56),&(v1516_59));
  drop(v1516_56);
  drop(v1516_59);
  let v1516_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1516_63: Space = singleton(&(v1516_62));
  drop(v1516_62);
  let v1516_64: Space = unite(&(v1516_60),&(v1516_63));
  drop(v1516_60);
  drop(v1516_63);
  let v1516_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1516_67: Space = singleton(&(v1516_66));
  drop(v1516_66);
  let v1516_68: Space = unite(&(v1516_64),&(v1516_67));
  drop(v1516_64);
  drop(v1516_67);
  let v1516_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1516_71: Space = singleton(&(v1516_70));
  drop(v1516_70);
  let v1516_72: Space = unite(&(v1516_68),&(v1516_71));
  drop(v1516_68);
  drop(v1516_71);
  let v1516_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1516_75: Space = singleton(&(v1516_74));
  drop(v1516_74);
  let v1516_76: Space = unite(&(v1516_72),&(v1516_75));
  drop(v1516_72);
  drop(v1516_75);
  (v1516_76).clone()
}

fn routine_148(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], p13: &[u8], p14: &[u8], s0: &View<'_, '_>) -> Space {
  let v1517_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1517_19: Space = singleton(&(v1517_18));
  drop(v1517_18);
  let v1517_20: Space = unite(&(*CONSTANT_89),&(v1517_19));
  drop(v1517_19);
  let v1517_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1517_23: Space = singleton(&(v1517_22));
  drop(v1517_22);
  let v1517_24: Space = unite(&(v1517_20),&(v1517_23));
  drop(v1517_20);
  drop(v1517_23);
  let v1517_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1517_27: Space = singleton(&(v1517_26));
  drop(v1517_26);
  let v1517_28: Space = unite(&(v1517_24),&(v1517_27));
  drop(v1517_24);
  drop(v1517_27);
  let v1517_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1517_31: Space = singleton(&(v1517_30));
  drop(v1517_30);
  let v1517_32: Space = unite(&(v1517_28),&(v1517_31));
  drop(v1517_28);
  drop(v1517_31);
  let v1517_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1517_35: Space = singleton(&(v1517_34));
  drop(v1517_34);
  let v1517_36: Space = unite(&(v1517_32),&(v1517_35));
  drop(v1517_32);
  drop(v1517_35);
  let v1517_38: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v1517_39: Space = singleton(&(v1517_38));
  drop(v1517_38);
  let v1517_40: Space = unite(&(v1517_36),&(v1517_39));
  drop(v1517_36);
  drop(v1517_39);
  let v1517_42: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v1517_43: Space = singleton(&(v1517_42));
  drop(v1517_42);
  let v1517_44: Space = unite(&(v1517_40),&(v1517_43));
  drop(v1517_40);
  drop(v1517_43);
  let v1517_46: Path = concat_path(&(*CONSTANT_17),&(*p8));
  let v1517_47: Space = singleton(&(v1517_46));
  drop(v1517_46);
  let v1517_48: Space = unite(&(v1517_44),&(v1517_47));
  drop(v1517_44);
  drop(v1517_47);
  let v1517_50: Path = concat_path(&(*CONSTANT_19),&(*p9));
  let v1517_51: Space = singleton(&(v1517_50));
  drop(v1517_50);
  let v1517_52: Space = unite(&(v1517_48),&(v1517_51));
  drop(v1517_48);
  drop(v1517_51);
  let v1517_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1517_55: Space = singleton(&(v1517_54));
  drop(v1517_54);
  let v1517_56: Space = unite(&(v1517_52),&(v1517_55));
  drop(v1517_52);
  drop(v1517_55);
  let v1517_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1517_59: Space = singleton(&(v1517_58));
  drop(v1517_58);
  let v1517_60: Space = unite(&(v1517_56),&(v1517_59));
  drop(v1517_56);
  drop(v1517_59);
  let v1517_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1517_63: Space = singleton(&(v1517_62));
  drop(v1517_62);
  let v1517_64: Space = unite(&(v1517_60),&(v1517_63));
  drop(v1517_60);
  drop(v1517_63);
  let v1517_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1517_67: Space = singleton(&(v1517_66));
  drop(v1517_66);
  let v1517_68: Space = unite(&(v1517_64),&(v1517_67));
  drop(v1517_64);
  drop(v1517_67);
  let v1517_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1517_71: Space = singleton(&(v1517_70));
  drop(v1517_70);
  let v1517_72: Space = unite(&(v1517_68),&(v1517_71));
  drop(v1517_68);
  drop(v1517_71);
  let v1517_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1517_75: Space = singleton(&(v1517_74));
  drop(v1517_74);
  let v1517_76: Space = unite(&(v1517_72),&(v1517_75));
  drop(v1517_72);
  drop(v1517_75);
  (v1517_76).clone()
}

fn routine_149(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], p13: &[u8], p14: &[u8], s0: &View<'_, '_>) -> Space {
  let v1518_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1518_19: Space = singleton(&(v1518_18));
  drop(v1518_18);
  let v1518_20: Space = unite(&(*CONSTANT_90),&(v1518_19));
  drop(v1518_19);
  let v1518_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1518_23: Space = singleton(&(v1518_22));
  drop(v1518_22);
  let v1518_24: Space = unite(&(v1518_20),&(v1518_23));
  drop(v1518_20);
  drop(v1518_23);
  let v1518_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1518_27: Space = singleton(&(v1518_26));
  drop(v1518_26);
  let v1518_28: Space = unite(&(v1518_24),&(v1518_27));
  drop(v1518_24);
  drop(v1518_27);
  let v1518_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1518_31: Space = singleton(&(v1518_30));
  drop(v1518_30);
  let v1518_32: Space = unite(&(v1518_28),&(v1518_31));
  drop(v1518_28);
  drop(v1518_31);
  let v1518_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1518_35: Space = singleton(&(v1518_34));
  drop(v1518_34);
  let v1518_36: Space = unite(&(v1518_32),&(v1518_35));
  drop(v1518_32);
  drop(v1518_35);
  let v1518_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1518_39: Space = singleton(&(v1518_38));
  drop(v1518_38);
  let v1518_40: Space = unite(&(v1518_36),&(v1518_39));
  drop(v1518_36);
  drop(v1518_39);
  let v1518_42: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v1518_43: Space = singleton(&(v1518_42));
  drop(v1518_42);
  let v1518_44: Space = unite(&(v1518_40),&(v1518_43));
  drop(v1518_40);
  drop(v1518_43);
  let v1518_46: Path = concat_path(&(*CONSTANT_17),&(*p8));
  let v1518_47: Space = singleton(&(v1518_46));
  drop(v1518_46);
  let v1518_48: Space = unite(&(v1518_44),&(v1518_47));
  drop(v1518_44);
  drop(v1518_47);
  let v1518_50: Path = concat_path(&(*CONSTANT_19),&(*p9));
  let v1518_51: Space = singleton(&(v1518_50));
  drop(v1518_50);
  let v1518_52: Space = unite(&(v1518_48),&(v1518_51));
  drop(v1518_48);
  drop(v1518_51);
  let v1518_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1518_55: Space = singleton(&(v1518_54));
  drop(v1518_54);
  let v1518_56: Space = unite(&(v1518_52),&(v1518_55));
  drop(v1518_52);
  drop(v1518_55);
  let v1518_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1518_59: Space = singleton(&(v1518_58));
  drop(v1518_58);
  let v1518_60: Space = unite(&(v1518_56),&(v1518_59));
  drop(v1518_56);
  drop(v1518_59);
  let v1518_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1518_63: Space = singleton(&(v1518_62));
  drop(v1518_62);
  let v1518_64: Space = unite(&(v1518_60),&(v1518_63));
  drop(v1518_60);
  drop(v1518_63);
  let v1518_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1518_67: Space = singleton(&(v1518_66));
  drop(v1518_66);
  let v1518_68: Space = unite(&(v1518_64),&(v1518_67));
  drop(v1518_64);
  drop(v1518_67);
  let v1518_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1518_71: Space = singleton(&(v1518_70));
  drop(v1518_70);
  let v1518_72: Space = unite(&(v1518_68),&(v1518_71));
  drop(v1518_68);
  drop(v1518_71);
  let v1518_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1518_75: Space = singleton(&(v1518_74));
  drop(v1518_74);
  let v1518_76: Space = unite(&(v1518_72),&(v1518_75));
  drop(v1518_72);
  drop(v1518_75);
  (v1518_76).clone()
}

fn routine_150(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], p13: &[u8], p14: &[u8], s0: &View<'_, '_>) -> Space {
  let v1519_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1519_19: Space = singleton(&(v1519_18));
  drop(v1519_18);
  let v1519_20: Space = unite(&(*CONSTANT_91),&(v1519_19));
  drop(v1519_19);
  let v1519_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1519_23: Space = singleton(&(v1519_22));
  drop(v1519_22);
  let v1519_24: Space = unite(&(v1519_20),&(v1519_23));
  drop(v1519_20);
  drop(v1519_23);
  let v1519_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1519_27: Space = singleton(&(v1519_26));
  drop(v1519_26);
  let v1519_28: Space = unite(&(v1519_24),&(v1519_27));
  drop(v1519_24);
  drop(v1519_27);
  let v1519_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1519_31: Space = singleton(&(v1519_30));
  drop(v1519_30);
  let v1519_32: Space = unite(&(v1519_28),&(v1519_31));
  drop(v1519_28);
  drop(v1519_31);
  let v1519_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1519_35: Space = singleton(&(v1519_34));
  drop(v1519_34);
  let v1519_36: Space = unite(&(v1519_32),&(v1519_35));
  drop(v1519_32);
  drop(v1519_35);
  let v1519_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1519_39: Space = singleton(&(v1519_38));
  drop(v1519_38);
  let v1519_40: Space = unite(&(v1519_36),&(v1519_39));
  drop(v1519_36);
  drop(v1519_39);
  let v1519_42: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v1519_43: Space = singleton(&(v1519_42));
  drop(v1519_42);
  let v1519_44: Space = unite(&(v1519_40),&(v1519_43));
  drop(v1519_40);
  drop(v1519_43);
  let v1519_46: Path = concat_path(&(*CONSTANT_17),&(*p8));
  let v1519_47: Space = singleton(&(v1519_46));
  drop(v1519_46);
  let v1519_48: Space = unite(&(v1519_44),&(v1519_47));
  drop(v1519_44);
  drop(v1519_47);
  let v1519_50: Path = concat_path(&(*CONSTANT_19),&(*p9));
  let v1519_51: Space = singleton(&(v1519_50));
  drop(v1519_50);
  let v1519_52: Space = unite(&(v1519_48),&(v1519_51));
  drop(v1519_48);
  drop(v1519_51);
  let v1519_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1519_55: Space = singleton(&(v1519_54));
  drop(v1519_54);
  let v1519_56: Space = unite(&(v1519_52),&(v1519_55));
  drop(v1519_52);
  drop(v1519_55);
  let v1519_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1519_59: Space = singleton(&(v1519_58));
  drop(v1519_58);
  let v1519_60: Space = unite(&(v1519_56),&(v1519_59));
  drop(v1519_56);
  drop(v1519_59);
  let v1519_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1519_63: Space = singleton(&(v1519_62));
  drop(v1519_62);
  let v1519_64: Space = unite(&(v1519_60),&(v1519_63));
  drop(v1519_60);
  drop(v1519_63);
  let v1519_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1519_67: Space = singleton(&(v1519_66));
  drop(v1519_66);
  let v1519_68: Space = unite(&(v1519_64),&(v1519_67));
  drop(v1519_64);
  drop(v1519_67);
  let v1519_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1519_71: Space = singleton(&(v1519_70));
  drop(v1519_70);
  let v1519_72: Space = unite(&(v1519_68),&(v1519_71));
  drop(v1519_68);
  drop(v1519_71);
  let v1519_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1519_75: Space = singleton(&(v1519_74));
  drop(v1519_74);
  let v1519_76: Space = unite(&(v1519_72),&(v1519_75));
  drop(v1519_72);
  drop(v1519_75);
  (v1519_76).clone()
}

fn routine_151(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], p13: &[u8], p14: &[u8], s0: &View<'_, '_>) -> Space {
  let v1520_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1520_19: Space = singleton(&(v1520_18));
  drop(v1520_18);
  let v1520_20: Space = unite(&(*CONSTANT_92),&(v1520_19));
  drop(v1520_19);
  let v1520_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1520_23: Space = singleton(&(v1520_22));
  drop(v1520_22);
  let v1520_24: Space = unite(&(v1520_20),&(v1520_23));
  drop(v1520_20);
  drop(v1520_23);
  let v1520_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1520_27: Space = singleton(&(v1520_26));
  drop(v1520_26);
  let v1520_28: Space = unite(&(v1520_24),&(v1520_27));
  drop(v1520_24);
  drop(v1520_27);
  let v1520_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1520_31: Space = singleton(&(v1520_30));
  drop(v1520_30);
  let v1520_32: Space = unite(&(v1520_28),&(v1520_31));
  drop(v1520_28);
  drop(v1520_31);
  let v1520_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1520_35: Space = singleton(&(v1520_34));
  drop(v1520_34);
  let v1520_36: Space = unite(&(v1520_32),&(v1520_35));
  drop(v1520_32);
  drop(v1520_35);
  let v1520_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1520_39: Space = singleton(&(v1520_38));
  drop(v1520_38);
  let v1520_40: Space = unite(&(v1520_36),&(v1520_39));
  drop(v1520_36);
  drop(v1520_39);
  let v1520_42: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v1520_43: Space = singleton(&(v1520_42));
  drop(v1520_42);
  let v1520_44: Space = unite(&(v1520_40),&(v1520_43));
  drop(v1520_40);
  drop(v1520_43);
  let v1520_46: Path = concat_path(&(*CONSTANT_15),&(*p8));
  let v1520_47: Space = singleton(&(v1520_46));
  drop(v1520_46);
  let v1520_48: Space = unite(&(v1520_44),&(v1520_47));
  drop(v1520_44);
  drop(v1520_47);
  let v1520_50: Path = concat_path(&(*CONSTANT_19),&(*p9));
  let v1520_51: Space = singleton(&(v1520_50));
  drop(v1520_50);
  let v1520_52: Space = unite(&(v1520_48),&(v1520_51));
  drop(v1520_48);
  drop(v1520_51);
  let v1520_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1520_55: Space = singleton(&(v1520_54));
  drop(v1520_54);
  let v1520_56: Space = unite(&(v1520_52),&(v1520_55));
  drop(v1520_52);
  drop(v1520_55);
  let v1520_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1520_59: Space = singleton(&(v1520_58));
  drop(v1520_58);
  let v1520_60: Space = unite(&(v1520_56),&(v1520_59));
  drop(v1520_56);
  drop(v1520_59);
  let v1520_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1520_63: Space = singleton(&(v1520_62));
  drop(v1520_62);
  let v1520_64: Space = unite(&(v1520_60),&(v1520_63));
  drop(v1520_60);
  drop(v1520_63);
  let v1520_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1520_67: Space = singleton(&(v1520_66));
  drop(v1520_66);
  let v1520_68: Space = unite(&(v1520_64),&(v1520_67));
  drop(v1520_64);
  drop(v1520_67);
  let v1520_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1520_71: Space = singleton(&(v1520_70));
  drop(v1520_70);
  let v1520_72: Space = unite(&(v1520_68),&(v1520_71));
  drop(v1520_68);
  drop(v1520_71);
  let v1520_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1520_75: Space = singleton(&(v1520_74));
  drop(v1520_74);
  let v1520_76: Space = unite(&(v1520_72),&(v1520_75));
  drop(v1520_72);
  drop(v1520_75);
  (v1520_76).clone()
}

fn routine_152(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], p13: &[u8], p14: &[u8], s0: &View<'_, '_>) -> Space {
  let v1521_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1521_19: Space = singleton(&(v1521_18));
  drop(v1521_18);
  let v1521_20: Space = unite(&(*CONSTANT_93),&(v1521_19));
  drop(v1521_19);
  let v1521_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1521_23: Space = singleton(&(v1521_22));
  drop(v1521_22);
  let v1521_24: Space = unite(&(v1521_20),&(v1521_23));
  drop(v1521_20);
  drop(v1521_23);
  let v1521_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1521_27: Space = singleton(&(v1521_26));
  drop(v1521_26);
  let v1521_28: Space = unite(&(v1521_24),&(v1521_27));
  drop(v1521_24);
  drop(v1521_27);
  let v1521_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1521_31: Space = singleton(&(v1521_30));
  drop(v1521_30);
  let v1521_32: Space = unite(&(v1521_28),&(v1521_31));
  drop(v1521_28);
  drop(v1521_31);
  let v1521_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1521_35: Space = singleton(&(v1521_34));
  drop(v1521_34);
  let v1521_36: Space = unite(&(v1521_32),&(v1521_35));
  drop(v1521_32);
  drop(v1521_35);
  let v1521_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1521_39: Space = singleton(&(v1521_38));
  drop(v1521_38);
  let v1521_40: Space = unite(&(v1521_36),&(v1521_39));
  drop(v1521_36);
  drop(v1521_39);
  let v1521_42: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v1521_43: Space = singleton(&(v1521_42));
  drop(v1521_42);
  let v1521_44: Space = unite(&(v1521_40),&(v1521_43));
  drop(v1521_40);
  drop(v1521_43);
  let v1521_46: Path = concat_path(&(*CONSTANT_15),&(*p8));
  let v1521_47: Space = singleton(&(v1521_46));
  drop(v1521_46);
  let v1521_48: Space = unite(&(v1521_44),&(v1521_47));
  drop(v1521_44);
  drop(v1521_47);
  let v1521_50: Path = concat_path(&(*CONSTANT_17),&(*p9));
  let v1521_51: Space = singleton(&(v1521_50));
  drop(v1521_50);
  let v1521_52: Space = unite(&(v1521_48),&(v1521_51));
  drop(v1521_48);
  drop(v1521_51);
  let v1521_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1521_55: Space = singleton(&(v1521_54));
  drop(v1521_54);
  let v1521_56: Space = unite(&(v1521_52),&(v1521_55));
  drop(v1521_52);
  drop(v1521_55);
  let v1521_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1521_59: Space = singleton(&(v1521_58));
  drop(v1521_58);
  let v1521_60: Space = unite(&(v1521_56),&(v1521_59));
  drop(v1521_56);
  drop(v1521_59);
  let v1521_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1521_63: Space = singleton(&(v1521_62));
  drop(v1521_62);
  let v1521_64: Space = unite(&(v1521_60),&(v1521_63));
  drop(v1521_60);
  drop(v1521_63);
  let v1521_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1521_67: Space = singleton(&(v1521_66));
  drop(v1521_66);
  let v1521_68: Space = unite(&(v1521_64),&(v1521_67));
  drop(v1521_64);
  drop(v1521_67);
  let v1521_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1521_71: Space = singleton(&(v1521_70));
  drop(v1521_70);
  let v1521_72: Space = unite(&(v1521_68),&(v1521_71));
  drop(v1521_68);
  drop(v1521_71);
  let v1521_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1521_75: Space = singleton(&(v1521_74));
  drop(v1521_74);
  let v1521_76: Space = unite(&(v1521_72),&(v1521_75));
  drop(v1521_72);
  drop(v1521_75);
  (v1521_76).clone()
}

fn routine_153(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], p13: &[u8], p14: &[u8], s0: &View<'_, '_>) -> Space {
  let v1522_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1522_19: Space = singleton(&(v1522_18));
  drop(v1522_18);
  let v1522_20: Space = unite(&(*CONSTANT_94),&(v1522_19));
  drop(v1522_19);
  let v1522_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1522_23: Space = singleton(&(v1522_22));
  drop(v1522_22);
  let v1522_24: Space = unite(&(v1522_20),&(v1522_23));
  drop(v1522_20);
  drop(v1522_23);
  let v1522_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1522_27: Space = singleton(&(v1522_26));
  drop(v1522_26);
  let v1522_28: Space = unite(&(v1522_24),&(v1522_27));
  drop(v1522_24);
  drop(v1522_27);
  let v1522_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1522_31: Space = singleton(&(v1522_30));
  drop(v1522_30);
  let v1522_32: Space = unite(&(v1522_28),&(v1522_31));
  drop(v1522_28);
  drop(v1522_31);
  let v1522_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1522_35: Space = singleton(&(v1522_34));
  drop(v1522_34);
  let v1522_36: Space = unite(&(v1522_32),&(v1522_35));
  drop(v1522_32);
  drop(v1522_35);
  let v1522_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1522_39: Space = singleton(&(v1522_38));
  drop(v1522_38);
  let v1522_40: Space = unite(&(v1522_36),&(v1522_39));
  drop(v1522_36);
  drop(v1522_39);
  let v1522_42: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v1522_43: Space = singleton(&(v1522_42));
  drop(v1522_42);
  let v1522_44: Space = unite(&(v1522_40),&(v1522_43));
  drop(v1522_40);
  drop(v1522_43);
  let v1522_46: Path = concat_path(&(*CONSTANT_15),&(*p8));
  let v1522_47: Space = singleton(&(v1522_46));
  drop(v1522_46);
  let v1522_48: Space = unite(&(v1522_44),&(v1522_47));
  drop(v1522_44);
  drop(v1522_47);
  let v1522_50: Path = concat_path(&(*CONSTANT_17),&(*p9));
  let v1522_51: Space = singleton(&(v1522_50));
  drop(v1522_50);
  let v1522_52: Space = unite(&(v1522_48),&(v1522_51));
  drop(v1522_48);
  drop(v1522_51);
  let v1522_54: Path = concat_path(&(*CONSTANT_19),&(*p10));
  let v1522_55: Space = singleton(&(v1522_54));
  drop(v1522_54);
  let v1522_56: Space = unite(&(v1522_52),&(v1522_55));
  drop(v1522_52);
  drop(v1522_55);
  let v1522_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1522_59: Space = singleton(&(v1522_58));
  drop(v1522_58);
  let v1522_60: Space = unite(&(v1522_56),&(v1522_59));
  drop(v1522_56);
  drop(v1522_59);
  let v1522_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1522_63: Space = singleton(&(v1522_62));
  drop(v1522_62);
  let v1522_64: Space = unite(&(v1522_60),&(v1522_63));
  drop(v1522_60);
  drop(v1522_63);
  let v1522_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1522_67: Space = singleton(&(v1522_66));
  drop(v1522_66);
  let v1522_68: Space = unite(&(v1522_64),&(v1522_67));
  drop(v1522_64);
  drop(v1522_67);
  let v1522_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1522_71: Space = singleton(&(v1522_70));
  drop(v1522_70);
  let v1522_72: Space = unite(&(v1522_68),&(v1522_71));
  drop(v1522_68);
  drop(v1522_71);
  let v1522_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1522_75: Space = singleton(&(v1522_74));
  drop(v1522_74);
  let v1522_76: Space = unite(&(v1522_72),&(v1522_75));
  drop(v1522_72);
  drop(v1522_75);
  (v1522_76).clone()
}

fn routine_154(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], p13: &[u8], p14: &[u8], s0: &View<'_, '_>) -> Space {
  let v1523_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1523_19: Space = singleton(&(v1523_18));
  drop(v1523_18);
  let v1523_20: Space = unite(&(*CONSTANT_95),&(v1523_19));
  drop(v1523_19);
  let v1523_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1523_23: Space = singleton(&(v1523_22));
  drop(v1523_22);
  let v1523_24: Space = unite(&(v1523_20),&(v1523_23));
  drop(v1523_20);
  drop(v1523_23);
  let v1523_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1523_27: Space = singleton(&(v1523_26));
  drop(v1523_26);
  let v1523_28: Space = unite(&(v1523_24),&(v1523_27));
  drop(v1523_24);
  drop(v1523_27);
  let v1523_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1523_31: Space = singleton(&(v1523_30));
  drop(v1523_30);
  let v1523_32: Space = unite(&(v1523_28),&(v1523_31));
  drop(v1523_28);
  drop(v1523_31);
  let v1523_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1523_35: Space = singleton(&(v1523_34));
  drop(v1523_34);
  let v1523_36: Space = unite(&(v1523_32),&(v1523_35));
  drop(v1523_32);
  drop(v1523_35);
  let v1523_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1523_39: Space = singleton(&(v1523_38));
  drop(v1523_38);
  let v1523_40: Space = unite(&(v1523_36),&(v1523_39));
  drop(v1523_36);
  drop(v1523_39);
  let v1523_42: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v1523_43: Space = singleton(&(v1523_42));
  drop(v1523_42);
  let v1523_44: Space = unite(&(v1523_40),&(v1523_43));
  drop(v1523_40);
  drop(v1523_43);
  let v1523_46: Path = concat_path(&(*CONSTANT_15),&(*p8));
  let v1523_47: Space = singleton(&(v1523_46));
  drop(v1523_46);
  let v1523_48: Space = unite(&(v1523_44),&(v1523_47));
  drop(v1523_44);
  drop(v1523_47);
  let v1523_50: Path = concat_path(&(*CONSTANT_17),&(*p9));
  let v1523_51: Space = singleton(&(v1523_50));
  drop(v1523_50);
  let v1523_52: Space = unite(&(v1523_48),&(v1523_51));
  drop(v1523_48);
  drop(v1523_51);
  let v1523_54: Path = concat_path(&(*CONSTANT_19),&(*p10));
  let v1523_55: Space = singleton(&(v1523_54));
  drop(v1523_54);
  let v1523_56: Space = unite(&(v1523_52),&(v1523_55));
  drop(v1523_52);
  drop(v1523_55);
  let v1523_58: Path = concat_path(&(*CONSTANT_21),&(*p11));
  let v1523_59: Space = singleton(&(v1523_58));
  drop(v1523_58);
  let v1523_60: Space = unite(&(v1523_56),&(v1523_59));
  drop(v1523_56);
  drop(v1523_59);
  let v1523_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1523_63: Space = singleton(&(v1523_62));
  drop(v1523_62);
  let v1523_64: Space = unite(&(v1523_60),&(v1523_63));
  drop(v1523_60);
  drop(v1523_63);
  let v1523_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1523_67: Space = singleton(&(v1523_66));
  drop(v1523_66);
  let v1523_68: Space = unite(&(v1523_64),&(v1523_67));
  drop(v1523_64);
  drop(v1523_67);
  let v1523_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1523_71: Space = singleton(&(v1523_70));
  drop(v1523_70);
  let v1523_72: Space = unite(&(v1523_68),&(v1523_71));
  drop(v1523_68);
  drop(v1523_71);
  let v1523_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1523_75: Space = singleton(&(v1523_74));
  drop(v1523_74);
  let v1523_76: Space = unite(&(v1523_72),&(v1523_75));
  drop(v1523_72);
  drop(v1523_75);
  (v1523_76).clone()
}

fn routine_155(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], p13: &[u8], p14: &[u8], s0: &View<'_, '_>) -> Space {
  let v1524_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1524_19: Space = singleton(&(v1524_18));
  drop(v1524_18);
  let v1524_20: Space = unite(&(*CONSTANT_96),&(v1524_19));
  drop(v1524_19);
  let v1524_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1524_23: Space = singleton(&(v1524_22));
  drop(v1524_22);
  let v1524_24: Space = unite(&(v1524_20),&(v1524_23));
  drop(v1524_20);
  drop(v1524_23);
  let v1524_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1524_27: Space = singleton(&(v1524_26));
  drop(v1524_26);
  let v1524_28: Space = unite(&(v1524_24),&(v1524_27));
  drop(v1524_24);
  drop(v1524_27);
  let v1524_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1524_31: Space = singleton(&(v1524_30));
  drop(v1524_30);
  let v1524_32: Space = unite(&(v1524_28),&(v1524_31));
  drop(v1524_28);
  drop(v1524_31);
  let v1524_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1524_35: Space = singleton(&(v1524_34));
  drop(v1524_34);
  let v1524_36: Space = unite(&(v1524_32),&(v1524_35));
  drop(v1524_32);
  drop(v1524_35);
  let v1524_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1524_39: Space = singleton(&(v1524_38));
  drop(v1524_38);
  let v1524_40: Space = unite(&(v1524_36),&(v1524_39));
  drop(v1524_36);
  drop(v1524_39);
  let v1524_42: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v1524_43: Space = singleton(&(v1524_42));
  drop(v1524_42);
  let v1524_44: Space = unite(&(v1524_40),&(v1524_43));
  drop(v1524_40);
  drop(v1524_43);
  let v1524_46: Path = concat_path(&(*CONSTANT_15),&(*p8));
  let v1524_47: Space = singleton(&(v1524_46));
  drop(v1524_46);
  let v1524_48: Space = unite(&(v1524_44),&(v1524_47));
  drop(v1524_44);
  drop(v1524_47);
  let v1524_50: Path = concat_path(&(*CONSTANT_17),&(*p9));
  let v1524_51: Space = singleton(&(v1524_50));
  drop(v1524_50);
  let v1524_52: Space = unite(&(v1524_48),&(v1524_51));
  drop(v1524_48);
  drop(v1524_51);
  let v1524_54: Path = concat_path(&(*CONSTANT_19),&(*p10));
  let v1524_55: Space = singleton(&(v1524_54));
  drop(v1524_54);
  let v1524_56: Space = unite(&(v1524_52),&(v1524_55));
  drop(v1524_52);
  drop(v1524_55);
  let v1524_58: Path = concat_path(&(*CONSTANT_21),&(*p11));
  let v1524_59: Space = singleton(&(v1524_58));
  drop(v1524_58);
  let v1524_60: Space = unite(&(v1524_56),&(v1524_59));
  drop(v1524_56);
  drop(v1524_59);
  let v1524_62: Path = concat_path(&(*CONSTANT_23),&(*p12));
  let v1524_63: Space = singleton(&(v1524_62));
  drop(v1524_62);
  let v1524_64: Space = unite(&(v1524_60),&(v1524_63));
  drop(v1524_60);
  drop(v1524_63);
  let v1524_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1524_67: Space = singleton(&(v1524_66));
  drop(v1524_66);
  let v1524_68: Space = unite(&(v1524_64),&(v1524_67));
  drop(v1524_64);
  drop(v1524_67);
  let v1524_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1524_71: Space = singleton(&(v1524_70));
  drop(v1524_70);
  let v1524_72: Space = unite(&(v1524_68),&(v1524_71));
  drop(v1524_68);
  drop(v1524_71);
  let v1524_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1524_75: Space = singleton(&(v1524_74));
  drop(v1524_74);
  let v1524_76: Space = unite(&(v1524_72),&(v1524_75));
  drop(v1524_72);
  drop(v1524_75);
  (v1524_76).clone()
}

fn routine_156(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], p13: &[u8], p14: &[u8], s0: &View<'_, '_>) -> Space {
  let v1525_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1525_19: Space = singleton(&(v1525_18));
  drop(v1525_18);
  let v1525_20: Space = unite(&(*CONSTANT_97),&(v1525_19));
  drop(v1525_19);
  let v1525_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1525_23: Space = singleton(&(v1525_22));
  drop(v1525_22);
  let v1525_24: Space = unite(&(v1525_20),&(v1525_23));
  drop(v1525_20);
  drop(v1525_23);
  let v1525_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1525_27: Space = singleton(&(v1525_26));
  drop(v1525_26);
  let v1525_28: Space = unite(&(v1525_24),&(v1525_27));
  drop(v1525_24);
  drop(v1525_27);
  let v1525_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1525_31: Space = singleton(&(v1525_30));
  drop(v1525_30);
  let v1525_32: Space = unite(&(v1525_28),&(v1525_31));
  drop(v1525_28);
  drop(v1525_31);
  let v1525_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1525_35: Space = singleton(&(v1525_34));
  drop(v1525_34);
  let v1525_36: Space = unite(&(v1525_32),&(v1525_35));
  drop(v1525_32);
  drop(v1525_35);
  let v1525_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1525_39: Space = singleton(&(v1525_38));
  drop(v1525_38);
  let v1525_40: Space = unite(&(v1525_36),&(v1525_39));
  drop(v1525_36);
  drop(v1525_39);
  let v1525_42: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v1525_43: Space = singleton(&(v1525_42));
  drop(v1525_42);
  let v1525_44: Space = unite(&(v1525_40),&(v1525_43));
  drop(v1525_40);
  drop(v1525_43);
  let v1525_46: Path = concat_path(&(*CONSTANT_15),&(*p8));
  let v1525_47: Space = singleton(&(v1525_46));
  drop(v1525_46);
  let v1525_48: Space = unite(&(v1525_44),&(v1525_47));
  drop(v1525_44);
  drop(v1525_47);
  let v1525_50: Path = concat_path(&(*CONSTANT_17),&(*p9));
  let v1525_51: Space = singleton(&(v1525_50));
  drop(v1525_50);
  let v1525_52: Space = unite(&(v1525_48),&(v1525_51));
  drop(v1525_48);
  drop(v1525_51);
  let v1525_54: Path = concat_path(&(*CONSTANT_19),&(*p10));
  let v1525_55: Space = singleton(&(v1525_54));
  drop(v1525_54);
  let v1525_56: Space = unite(&(v1525_52),&(v1525_55));
  drop(v1525_52);
  drop(v1525_55);
  let v1525_58: Path = concat_path(&(*CONSTANT_21),&(*p11));
  let v1525_59: Space = singleton(&(v1525_58));
  drop(v1525_58);
  let v1525_60: Space = unite(&(v1525_56),&(v1525_59));
  drop(v1525_56);
  drop(v1525_59);
  let v1525_62: Path = concat_path(&(*CONSTANT_23),&(*p12));
  let v1525_63: Space = singleton(&(v1525_62));
  drop(v1525_62);
  let v1525_64: Space = unite(&(v1525_60),&(v1525_63));
  drop(v1525_60);
  drop(v1525_63);
  let v1525_66: Path = concat_path(&(*CONSTANT_25),&(*p13));
  let v1525_67: Space = singleton(&(v1525_66));
  drop(v1525_66);
  let v1525_68: Space = unite(&(v1525_64),&(v1525_67));
  drop(v1525_64);
  drop(v1525_67);
  let v1525_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1525_71: Space = singleton(&(v1525_70));
  drop(v1525_70);
  let v1525_72: Space = unite(&(v1525_68),&(v1525_71));
  drop(v1525_68);
  drop(v1525_71);
  let v1525_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1525_75: Space = singleton(&(v1525_74));
  drop(v1525_74);
  let v1525_76: Space = unite(&(v1525_72),&(v1525_75));
  drop(v1525_72);
  drop(v1525_75);
  (v1525_76).clone()
}

fn routine_157(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], p13: &[u8], p14: &[u8], s0: &View<'_, '_>) -> Space {
  let v1526_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1526_19: Space = singleton(&(v1526_18));
  drop(v1526_18);
  let v1526_20: Space = unite(&(*CONSTANT_98),&(v1526_19));
  drop(v1526_19);
  let v1526_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1526_23: Space = singleton(&(v1526_22));
  drop(v1526_22);
  let v1526_24: Space = unite(&(v1526_20),&(v1526_23));
  drop(v1526_20);
  drop(v1526_23);
  let v1526_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1526_27: Space = singleton(&(v1526_26));
  drop(v1526_26);
  let v1526_28: Space = unite(&(v1526_24),&(v1526_27));
  drop(v1526_24);
  drop(v1526_27);
  let v1526_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1526_31: Space = singleton(&(v1526_30));
  drop(v1526_30);
  let v1526_32: Space = unite(&(v1526_28),&(v1526_31));
  drop(v1526_28);
  drop(v1526_31);
  let v1526_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1526_35: Space = singleton(&(v1526_34));
  drop(v1526_34);
  let v1526_36: Space = unite(&(v1526_32),&(v1526_35));
  drop(v1526_32);
  drop(v1526_35);
  let v1526_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1526_39: Space = singleton(&(v1526_38));
  drop(v1526_38);
  let v1526_40: Space = unite(&(v1526_36),&(v1526_39));
  drop(v1526_36);
  drop(v1526_39);
  let v1526_42: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v1526_43: Space = singleton(&(v1526_42));
  drop(v1526_42);
  let v1526_44: Space = unite(&(v1526_40),&(v1526_43));
  drop(v1526_40);
  drop(v1526_43);
  let v1526_46: Path = concat_path(&(*CONSTANT_15),&(*p8));
  let v1526_47: Space = singleton(&(v1526_46));
  drop(v1526_46);
  let v1526_48: Space = unite(&(v1526_44),&(v1526_47));
  drop(v1526_44);
  drop(v1526_47);
  let v1526_50: Path = concat_path(&(*CONSTANT_17),&(*p9));
  let v1526_51: Space = singleton(&(v1526_50));
  drop(v1526_50);
  let v1526_52: Space = unite(&(v1526_48),&(v1526_51));
  drop(v1526_48);
  drop(v1526_51);
  let v1526_54: Path = concat_path(&(*CONSTANT_19),&(*p10));
  let v1526_55: Space = singleton(&(v1526_54));
  drop(v1526_54);
  let v1526_56: Space = unite(&(v1526_52),&(v1526_55));
  drop(v1526_52);
  drop(v1526_55);
  let v1526_58: Path = concat_path(&(*CONSTANT_21),&(*p11));
  let v1526_59: Space = singleton(&(v1526_58));
  drop(v1526_58);
  let v1526_60: Space = unite(&(v1526_56),&(v1526_59));
  drop(v1526_56);
  drop(v1526_59);
  let v1526_62: Path = concat_path(&(*CONSTANT_23),&(*p12));
  let v1526_63: Space = singleton(&(v1526_62));
  drop(v1526_62);
  let v1526_64: Space = unite(&(v1526_60),&(v1526_63));
  drop(v1526_60);
  drop(v1526_63);
  let v1526_66: Path = concat_path(&(*CONSTANT_25),&(*p13));
  let v1526_67: Space = singleton(&(v1526_66));
  drop(v1526_66);
  let v1526_68: Space = unite(&(v1526_64),&(v1526_67));
  drop(v1526_64);
  drop(v1526_67);
  let v1526_70: Path = concat_path(&(*CONSTANT_27),&(*p14));
  let v1526_71: Space = singleton(&(v1526_70));
  drop(v1526_70);
  let v1526_72: Space = unite(&(v1526_68),&(v1526_71));
  drop(v1526_68);
  drop(v1526_71);
  let v1526_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1526_75: Space = singleton(&(v1526_74));
  drop(v1526_74);
  let v1526_76: Space = unite(&(v1526_72),&(v1526_75));
  drop(v1526_72);
  drop(v1526_75);
  (v1526_76).clone()
}

fn routine_158(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], p10: &[u8], p11: &[u8], p12: &[u8], p13: &[u8], p14: &[u8], s0: &View<'_, '_>) -> Space {
  let v1527_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1527_19: Space = singleton(&(v1527_18));
  drop(v1527_18);
  let v1527_20: Space = unite(&(*CONSTANT_99),&(v1527_19));
  drop(v1527_19);
  let v1527_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1527_23: Space = singleton(&(v1527_22));
  drop(v1527_22);
  let v1527_24: Space = unite(&(v1527_20),&(v1527_23));
  drop(v1527_20);
  drop(v1527_23);
  let v1527_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1527_27: Space = singleton(&(v1527_26));
  drop(v1527_26);
  let v1527_28: Space = unite(&(v1527_24),&(v1527_27));
  drop(v1527_24);
  drop(v1527_27);
  let v1527_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1527_31: Space = singleton(&(v1527_30));
  drop(v1527_30);
  let v1527_32: Space = unite(&(v1527_28),&(v1527_31));
  drop(v1527_28);
  drop(v1527_31);
  let v1527_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1527_35: Space = singleton(&(v1527_34));
  drop(v1527_34);
  let v1527_36: Space = unite(&(v1527_32),&(v1527_35));
  drop(v1527_32);
  drop(v1527_35);
  let v1527_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1527_39: Space = singleton(&(v1527_38));
  drop(v1527_38);
  let v1527_40: Space = unite(&(v1527_36),&(v1527_39));
  drop(v1527_36);
  drop(v1527_39);
  let v1527_42: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v1527_43: Space = singleton(&(v1527_42));
  drop(v1527_42);
  let v1527_44: Space = unite(&(v1527_40),&(v1527_43));
  drop(v1527_40);
  drop(v1527_43);
  let v1527_46: Path = concat_path(&(*CONSTANT_15),&(*p8));
  let v1527_47: Space = singleton(&(v1527_46));
  drop(v1527_46);
  let v1527_48: Space = unite(&(v1527_44),&(v1527_47));
  drop(v1527_44);
  drop(v1527_47);
  let v1527_50: Path = concat_path(&(*CONSTANT_17),&(*p9));
  let v1527_51: Space = singleton(&(v1527_50));
  drop(v1527_50);
  let v1527_52: Space = unite(&(v1527_48),&(v1527_51));
  drop(v1527_48);
  drop(v1527_51);
  let v1527_54: Path = concat_path(&(*CONSTANT_19),&(*p10));
  let v1527_55: Space = singleton(&(v1527_54));
  drop(v1527_54);
  let v1527_56: Space = unite(&(v1527_52),&(v1527_55));
  drop(v1527_52);
  drop(v1527_55);
  let v1527_58: Path = concat_path(&(*CONSTANT_21),&(*p11));
  let v1527_59: Space = singleton(&(v1527_58));
  drop(v1527_58);
  let v1527_60: Space = unite(&(v1527_56),&(v1527_59));
  drop(v1527_56);
  drop(v1527_59);
  let v1527_62: Path = concat_path(&(*CONSTANT_23),&(*p12));
  let v1527_63: Space = singleton(&(v1527_62));
  drop(v1527_62);
  let v1527_64: Space = unite(&(v1527_60),&(v1527_63));
  drop(v1527_60);
  drop(v1527_63);
  let v1527_66: Path = concat_path(&(*CONSTANT_25),&(*p13));
  let v1527_67: Space = singleton(&(v1527_66));
  drop(v1527_66);
  let v1527_68: Space = unite(&(v1527_64),&(v1527_67));
  drop(v1527_64);
  drop(v1527_67);
  let v1527_70: Path = concat_path(&(*CONSTANT_27),&(*p14));
  let v1527_71: Space = singleton(&(v1527_70));
  drop(v1527_70);
  let v1527_72: Space = unite(&(v1527_68),&(v1527_71));
  drop(v1527_68);
  drop(v1527_71);
  let v1527_74: Path = concat_path(&(*CONSTANT_29),&(*p0));
  let v1527_75: Space = singleton(&(v1527_74));
  drop(v1527_74);
  let v1527_76: Space = unite(&(v1527_72),&(v1527_75));
  drop(v1527_72);
  drop(v1527_75);
  (v1527_76).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
