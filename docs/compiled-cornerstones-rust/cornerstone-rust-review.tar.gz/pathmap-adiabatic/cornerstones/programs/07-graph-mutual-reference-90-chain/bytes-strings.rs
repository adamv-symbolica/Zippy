#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[101,100,103,101,0]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[77,117,116,117,97,108,0]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_15 = Space::new();
  let mut v0_15_write = v0_15.write_zipper();
  let mut v0_15_cursor = descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0));
  let v0_15_origin = v0_15_cursor.path().len();
  for v0_15_byte in v0_15_cursor.child_mask().iter() {
    v0_15_cursor.descend_to_existing_byte(v0_15_byte);
    {
    let v1_2: Space = singleton(&v0_15_cursor.path()[v0_15_origin..(v0_15_origin + 1)]);
    let v1_3: Space = intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (&(v1_5)).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_write = v2_6.write_zipper();
      for v2_6_byte in v0_15_cursor.child_mask().iter() {
        v0_15_cursor.descend_to_existing_byte(v2_6_byte);
        {
        let v3_2: Space = singleton(&v0_15_cursor.path()[(v0_15_origin + 1)..(v0_15_origin + 2)]);
        let v3_3: Space = intersect(&(*CONSTANT_2),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_1),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (&(v3_5)).is_empty() { Space::new() } else {
          let v4_7: Space = routine_1(c, &v0_15_cursor.path()[v0_15_origin..(v0_15_origin + 2)], &v0_15_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_2),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (&(v3_10)).is_empty() { Space::new() } else {
          let mut v5_11 = Space::new();
          let mut v5_11_write = v5_11.write_zipper();
          for v5_11_byte in v0_15_cursor.child_mask().iter() {
            v0_15_cursor.descend_to_existing_byte(v5_11_byte);
            {
            let v6_2: Space = singleton(&v0_15_cursor.path()[(v0_15_origin + 2)..(v0_15_origin + 3)]);
            let v6_3: Space = intersect(&(*CONSTANT_2),&(v6_2));
            let v6_4: Space = if has_head(&(v6_3)) { singleton(&[]) } else { Space::new() };
            drop(v6_3);
            let v6_5: Space = subtract(&(*CONSTANT_1),&(v6_4));
            drop(v6_4);
            let v6_7: Space = if (&(v6_5)).is_empty() { Space::new() } else {
              let v7_6: Space = routine_2(c, &v0_15_cursor.path()[(v0_15_origin + 2)..(v0_15_origin + 3)], &v0_15_cursor.path()[v0_15_origin..(v0_15_origin + 2)], &v0_15_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v6_5),&(v7_6))
            };
            drop(v6_5);
            let v6_8: Space = intersect(&(*CONSTANT_2),&(v6_2));
            drop(v6_2);
            let v6_9: Space = if has_head(&(v6_8)) { singleton(&[]) } else { Space::new() };
            drop(v6_8);
            let v6_11: Space = if (&(v6_9)).is_empty() { Space::new() } else {
              let v8_10: Space = routine_3(c, &v0_15_cursor.path()[(v0_15_origin + 2)..(v0_15_origin + 3)], &v0_15_cursor.path()[v0_15_origin..(v0_15_origin + 2)], &v0_15_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v6_9),&(v8_10))
            };
            drop(v6_9);
            let v6_12: Space = unite(&(v6_7),&(v6_11));
            join_wrapped_into(&mut v5_11_write,&((v6_12).read_zipper()),&[]);
            }
            v0_15_cursor.ascend(1);
          }
          drop(v5_11_write);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        join_wrapped_into(&mut v2_6_write,&((v3_13).read_zipper()),&[]);
        }
        v0_15_cursor.ascend(1);
      }
      drop(v2_6_write);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (&(v1_9)).is_empty() { Space::new() } else {
      let mut v9_10 = Space::new();
      let mut v9_10_write = v9_10.write_zipper();
      for v9_10_byte in v0_15_cursor.child_mask().iter() {
        v0_15_cursor.descend_to_existing_byte(v9_10_byte);
        {
        let v10_2: Space = singleton(&v0_15_cursor.path()[(v0_15_origin + 1)..(v0_15_origin + 2)]);
        let v10_3: Space = intersect(&(*CONSTANT_2),&(v10_2));
        let v10_4: Space = if has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
        drop(v10_3);
        let v10_5: Space = subtract(&(*CONSTANT_1),&(v10_4));
        drop(v10_4);
        let v10_7: Space = if (&(v10_5)).is_empty() { Space::new() } else {
          let v11_6: Space = routine_2(c, &v0_15_cursor.path()[(v0_15_origin + 1)..(v0_15_origin + 2)], &v0_15_cursor.path()[v0_15_origin..(v0_15_origin + 1)], &v0_15_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          compose(&(v10_5),&(v11_6))
        };
        drop(v10_5);
        let v10_8: Space = intersect(&(*CONSTANT_2),&(v10_2));
        drop(v10_2);
        let v10_9: Space = if has_head(&(v10_8)) { singleton(&[]) } else { Space::new() };
        drop(v10_8);
        let v10_12: Space = if (&(v10_9)).is_empty() { Space::new() } else {
          compose(&(v10_9),&(descend_cursor(descend_cursor(descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0)),&v0_15_cursor.path()[(v0_15_origin + 1)..(v0_15_origin + 2)]),&v0_15_cursor.path()[v0_15_origin..(v0_15_origin + 1)])))
        };
        drop(v10_9);
        let v10_13: Space = wrap(&(v10_12),&v0_15_cursor.path()[(v0_15_origin + 1)..(v0_15_origin + 2)]);
        drop(v10_12);
        let v10_14: Space = wrap(&(v10_13),&v0_15_cursor.path()[v0_15_origin..(v0_15_origin + 1)]);
        drop(v10_13);
        let v10_15: Space = unite(&(v10_7),&(v10_14));
        drop(v10_14);
        join_wrapped_into(&mut v9_10_write,&((v10_15).read_zipper()),&[]);
        }
        v0_15_cursor.ascend(1);
      }
      drop(v9_10_write);
      compose(&(v1_9),&(v9_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    join_wrapped_into(&mut v0_15_write,&((v1_12).read_zipper()),&[]);
    }
    v0_15_cursor.ascend(1);
  }
  drop(v0_15_cursor);
  drop(v0_15_write);
  let v0_17: Space = wrap(&(v0_15),&(*CONSTANT_3));
  (v0_17).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v13_11 = Space::new();
  let mut v13_11_write = v13_11.write_zipper();
  let mut v13_11_cursor = (*s0).read_zipper();
  let v13_11_origin = v13_11_cursor.path().len();
  for v13_11_byte in v13_11_cursor.child_mask().iter() {
    v13_11_cursor.descend_to_existing_byte(v13_11_byte);
    {
    let v14_2: Space = singleton(&v13_11_cursor.path()[v13_11_origin..(v13_11_origin + 1)]);
    let v14_3: Space = intersect(&(*CONSTANT_2),&(v14_2));
    let v14_4: Space = if has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
    drop(v14_3);
    let v14_5: Space = subtract(&(*CONSTANT_1),&(v14_4));
    drop(v14_4);
    let v14_8: Space = if (&(v14_5)).is_empty() { Space::new() } else {
      let v15_6: Path = concat_path(&(*p0),&v13_11_cursor.path()[v13_11_origin..(v13_11_origin + 1)]);
      let v15_7: Space = routine_1(c, &(v15_6), &v13_11_cursor, &(*s1));
      compose(&(v14_5),&(v15_7))
    };
    drop(v14_5);
    let v14_9: Space = intersect(&(*CONSTANT_2),&(v14_2));
    drop(v14_2);
    let v14_10: Space = if has_head(&(v14_9)) { singleton(&[]) } else { Space::new() };
    drop(v14_9);
    let v14_12: Space = if (&(v14_10)).is_empty() { Space::new() } else {
      let v16_6: Path = concat_path(&(*p0),&v13_11_cursor.path()[v13_11_origin..(v13_11_origin + 1)]);
      let mut v16_11 = Space::new();
      let mut v16_11_write = v16_11.write_zipper();
      for v16_11_byte in v13_11_cursor.child_mask().iter() {
        v13_11_cursor.descend_to_existing_byte(v16_11_byte);
        {
        let v17_2: Space = singleton(&v13_11_cursor.path()[(v13_11_origin + 1)..(v13_11_origin + 2)]);
        let v17_3: Space = intersect(&(*CONSTANT_2),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_1),&(v17_4));
        drop(v17_4);
        let v17_7: Space = if (&(v17_5)).is_empty() { Space::new() } else {
          let v18_6: Space = routine_2(c, &v13_11_cursor.path()[(v13_11_origin + 1)..(v13_11_origin + 2)], &(v16_6), &v13_11_cursor, &(*s1));
          compose(&(v17_5),&(v18_6))
        };
        drop(v17_5);
        let v17_8: Space = intersect(&(*CONSTANT_2),&(v17_2));
        drop(v17_2);
        let v17_9: Space = if has_head(&(v17_8)) { singleton(&[]) } else { Space::new() };
        drop(v17_8);
        let v17_13: Space = if (&(v17_9)).is_empty() { Space::new() } else {
          compose(&(v17_9),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&v13_11_cursor.path()[(v13_11_origin + 1)..(v13_11_origin + 2)]),&(*p0)),&v13_11_cursor.path()[v13_11_origin..(v13_11_origin + 1)])))
        };
        drop(v17_9);
        let v17_14: Space = wrap(&(v17_13),&v13_11_cursor.path()[(v13_11_origin + 1)..(v13_11_origin + 2)]);
        drop(v17_13);
        let v17_15: Space = wrap(&(v17_14),&(v16_6));
        drop(v17_14);
        let v17_16: Space = unite(&(v17_7),&(v17_15));
        drop(v17_15);
        join_wrapped_into(&mut v16_11_write,&((v17_16).read_zipper()),&[]);
        }
        v13_11_cursor.ascend(1);
      }
      drop(v16_11_write);
      drop(v16_6);
      compose(&(v14_10),&(v16_11))
    };
    drop(v14_10);
    let v14_13: Space = unite(&(v14_8),&(v14_12));
    join_wrapped_into(&mut v13_11_write,&((v14_13).read_zipper()),&[]);
    }
    v13_11_cursor.ascend(1);
  }
  drop(v13_11_cursor);
  drop(v13_11_write);
  (v13_11).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v20_10 = Space::new();
  let mut v20_10_write = v20_10.write_zipper();
  let mut v20_10_cursor = (*s0).read_zipper();
  let v20_10_origin = v20_10_cursor.path().len();
  for v20_10_byte in v20_10_cursor.child_mask().iter() {
    v20_10_cursor.descend_to_existing_byte(v20_10_byte);
    {
    let v21_2: Space = singleton(&v20_10_cursor.path()[v20_10_origin..(v20_10_origin + 1)]);
    let v21_3: Space = intersect(&(*CONSTANT_2),&(v21_2));
    let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
    drop(v21_3);
    let v21_5: Space = subtract(&(*CONSTANT_1),&(v21_4));
    drop(v21_4);
    let v21_8: Space = if (&(v21_5)).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&v20_10_cursor.path()[v20_10_origin..(v20_10_origin + 1)]);
      let v22_7: Space = routine_2(c, &(v22_6), &(*p1), &v20_10_cursor, &(*s1));
      compose(&(v21_5),&(v22_7))
    };
    drop(v21_5);
    let v21_9: Space = intersect(&(*CONSTANT_2),&(v21_2));
    drop(v21_2);
    let v21_10: Space = if has_head(&(v21_9)) { singleton(&[]) } else { Space::new() };
    drop(v21_9);
    let v21_13: Space = if (&(v21_10)).is_empty() { Space::new() } else {
      compose(&(v21_10),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v20_10_cursor.path()[v20_10_origin..(v20_10_origin + 1)]),&(*p1))))
    };
    drop(v21_10);
    let v24_6: Path = concat_path(&(*p0),&v20_10_cursor.path()[v20_10_origin..(v20_10_origin + 1)]);
    let v21_14: Space = wrap(&(v21_13),&(v24_6));
    drop(v21_13);
    let v21_15: Space = wrap(&(v21_14),&(*p1));
    drop(v21_14);
    let v21_16: Space = unite(&(v21_8),&(v21_15));
    drop(v21_15);
    join_wrapped_into(&mut v20_10_write,&((v21_16).read_zipper()),&[]);
    }
    v20_10_cursor.ascend(1);
  }
  drop(v20_10_cursor);
  drop(v20_10_write);
  (v20_10).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v25_8: Space = wrap(&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&(*p1))),&(*p0));
  let v25_9: Space = wrap(&(v25_8),&(*p1));
  drop(v25_8);
  (v25_9).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
