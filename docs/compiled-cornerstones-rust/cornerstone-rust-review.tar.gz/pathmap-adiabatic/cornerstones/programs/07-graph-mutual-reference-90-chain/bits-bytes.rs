#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,1,0,0,0,0,0,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_24 = Space::new();
  let mut v0_24_write = v0_24.write_zipper();
  let mut v0_24_cursor = descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0));
  let v0_24_origin = v0_24_cursor.path().len();
  for v0_24_byte in v0_24_cursor.child_mask().iter() {
    v0_24_cursor.descend_to_existing_byte(v0_24_byte);
    {
    let v1_2: Space = singleton(&v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 1)]);
    let v1_3: Space = intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (&(v1_5)).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_write = v2_6.write_zipper();
      for v2_6_byte in v0_24_cursor.child_mask().iter() {
        v0_24_cursor.descend_to_existing_byte(v2_6_byte);
        {
        let v3_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 1)..(v0_24_origin + 2)]);
        let v3_3: Space = intersect(&(*CONSTANT_2),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_1),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (&(v3_5)).is_empty() { Space::new() } else {
          let mut v4_7 = Space::new();
          let mut v4_7_write = v4_7.write_zipper();
          for v4_7_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v4_7_byte);
            {
            let v5_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v5_3: Space = intersect(&(*CONSTANT_2),&(v5_2));
            let v5_4: Space = if has_head(&(v5_3)) { singleton(&[]) } else { Space::new() };
            drop(v5_3);
            let v5_5: Space = subtract(&(*CONSTANT_1),&(v5_4));
            drop(v5_4);
            let v5_8: Space = if (&(v5_5)).is_empty() { Space::new() } else {
              let v6_7: Space = routine_1(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v5_5),&(v6_7))
            };
            drop(v5_5);
            let v5_9: Space = intersect(&(*CONSTANT_2),&(v5_2));
            drop(v5_2);
            let v5_10: Space = if has_head(&(v5_9)) { singleton(&[]) } else { Space::new() };
            drop(v5_9);
            let v5_12: Space = if (&(v5_10)).is_empty() { Space::new() } else {
              let v7_11: Space = routine_2(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v5_10),&(v7_11))
            };
            drop(v5_10);
            let v5_13: Space = unite(&(v5_8),&(v5_12));
            join_wrapped_into(&mut v4_7_write,&((v5_13).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v4_7_write);
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_2),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (&(v3_10)).is_empty() { Space::new() } else {
          let mut v8_11 = Space::new();
          let mut v8_11_write = v8_11.write_zipper();
          for v8_11_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v8_11_byte);
            {
            let v9_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v9_3: Space = intersect(&(*CONSTANT_2),&(v9_2));
            let v9_4: Space = if has_head(&(v9_3)) { singleton(&[]) } else { Space::new() };
            drop(v9_3);
            let v9_5: Space = subtract(&(*CONSTANT_1),&(v9_4));
            drop(v9_4);
            let v9_8: Space = if (&(v9_5)).is_empty() { Space::new() } else {
              let v10_7: Space = routine_1(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v9_5),&(v10_7))
            };
            drop(v9_5);
            let v9_9: Space = intersect(&(*CONSTANT_2),&(v9_2));
            drop(v9_2);
            let v9_10: Space = if has_head(&(v9_9)) { singleton(&[]) } else { Space::new() };
            drop(v9_9);
            let v9_12: Space = if (&(v9_10)).is_empty() { Space::new() } else {
              let v11_11: Space = routine_3(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v9_10),&(v11_11))
            };
            drop(v9_10);
            let v9_13: Space = unite(&(v9_8),&(v9_12));
            join_wrapped_into(&mut v8_11_write,&((v9_13).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v8_11_write);
          compose(&(v3_10),&(v8_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        join_wrapped_into(&mut v2_6_write,&((v3_13).read_zipper()),&[]);
        }
        v0_24_cursor.ascend(1);
      }
      drop(v2_6_write);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (&(v1_9)).is_empty() { Space::new() } else {
      let mut v12_10 = Space::new();
      let mut v12_10_write = v12_10.write_zipper();
      for v12_10_byte in v0_24_cursor.child_mask().iter() {
        v0_24_cursor.descend_to_existing_byte(v12_10_byte);
        {
        let v13_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 1)..(v0_24_origin + 2)]);
        let v13_3: Space = intersect(&(*CONSTANT_2),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_1),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (&(v13_5)).is_empty() { Space::new() } else {
          let mut v14_7 = Space::new();
          let mut v14_7_write = v14_7.write_zipper();
          for v14_7_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v14_7_byte);
            {
            let v15_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v15_3: Space = intersect(&(*CONSTANT_2),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_1),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (&(v15_5)).is_empty() { Space::new() } else {
              let v16_7: Space = routine_1(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_2),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (&(v15_10)).is_empty() { Space::new() } else {
              let v17_11: Space = routine_2(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            join_wrapped_into(&mut v14_7_write,&((v15_13).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v14_7_write);
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_2),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (&(v13_10)).is_empty() { Space::new() } else {
          let mut v18_11 = Space::new();
          let mut v18_11_write = v18_11.write_zipper();
          for v18_11_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v18_11_byte);
            {
            let v19_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v19_3: Space = intersect(&(*CONSTANT_2),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_1),&(v19_4));
            drop(v19_4);
            let v19_7: Space = if (&(v19_5)).is_empty() { Space::new() } else {
              let v20_6: Space = routine_4(c, &v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)], &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 2)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v19_5),&(v20_6))
            };
            drop(v19_5);
            let v19_8: Space = intersect(&(*CONSTANT_2),&(v19_2));
            drop(v19_2);
            let v19_9: Space = if has_head(&(v19_8)) { singleton(&[]) } else { Space::new() };
            drop(v19_8);
            let v19_11: Space = if (&(v19_9)).is_empty() { Space::new() } else {
              let v21_10: Space = routine_5(c, &v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)], &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 2)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v19_9),&(v21_10))
            };
            drop(v19_9);
            let v19_12: Space = unite(&(v19_7),&(v19_11));
            join_wrapped_into(&mut v18_11_write,&((v19_12).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v18_11_write);
          compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        join_wrapped_into(&mut v12_10_write,&((v13_13).read_zipper()),&[]);
        }
        v0_24_cursor.ascend(1);
      }
      drop(v12_10_write);
      compose(&(v1_9),&(v12_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    join_wrapped_into(&mut v0_24_write,&((v1_12).read_zipper()),&[]);
    }
    v0_24_cursor.ascend(1);
  }
  drop(v0_24_cursor);
  drop(v0_24_write);
  let v0_26: Space = wrap(&(v0_24),&(*CONSTANT_3));
  (v0_26).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v22_24 = Space::new();
  let mut v22_24_write = v22_24.write_zipper();
  let mut v22_24_cursor = (*s0).read_zipper();
  let v22_24_origin = v22_24_cursor.path().len();
  for v22_24_byte in v22_24_cursor.child_mask().iter() {
    v22_24_cursor.descend_to_existing_byte(v22_24_byte);
    {
    let v23_2: Space = singleton(&v22_24_cursor.path()[v22_24_origin..(v22_24_origin + 1)]);
    let v23_3: Space = intersect(&(*CONSTANT_2),&(v23_2));
    let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
    drop(v23_3);
    let v23_5: Space = subtract(&(*CONSTANT_1),&(v23_4));
    drop(v23_4);
    let v23_8: Space = if (&(v23_5)).is_empty() { Space::new() } else {
      let v24_6: Path = concat_path(&(*p0),&v22_24_cursor.path()[v22_24_origin..(v22_24_origin + 1)]);
      let mut v24_7 = Space::new();
      let mut v24_7_write = v24_7.write_zipper();
      for v24_7_byte in v22_24_cursor.child_mask().iter() {
        v22_24_cursor.descend_to_existing_byte(v24_7_byte);
        {
        let v25_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
        let v25_3: Space = intersect(&(*CONSTANT_2),&(v25_2));
        let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
        drop(v25_3);
        let v25_5: Space = subtract(&(*CONSTANT_1),&(v25_4));
        drop(v25_4);
        let v25_8: Space = if (&(v25_5)).is_empty() { Space::new() } else {
          let v26_6: Path = concat_path(&(v24_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v26_7 = Space::new();
          let mut v26_7_write = v26_7.write_zipper();
          for v26_7_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v26_7_byte);
            {
            let v27_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v27_3: Space = intersect(&(*CONSTANT_2),&(v27_2));
            let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
            drop(v27_3);
            let v27_5: Space = subtract(&(*CONSTANT_1),&(v27_4));
            drop(v27_4);
            let v27_8: Space = if (&(v27_5)).is_empty() { Space::new() } else {
              let v28_6: Path = concat_path(&(v26_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v28_7: Space = routine_6(c, &(v28_6), &v22_24_cursor, &(*s1));
              compose(&(v27_5),&(v28_7))
            };
            drop(v27_5);
            let v27_9: Space = intersect(&(*CONSTANT_2),&(v27_2));
            drop(v27_2);
            let v27_10: Space = if has_head(&(v27_9)) { singleton(&[]) } else { Space::new() };
            drop(v27_9);
            let v27_12: Space = if (&(v27_10)).is_empty() { Space::new() } else {
              let v29_6: Path = concat_path(&(v26_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v29_11: Space = routine_7(c, &(v29_6), &v22_24_cursor, &(*s1));
              drop(v29_6);
              compose(&(v27_10),&(v29_11))
            };
            drop(v27_10);
            let v27_13: Space = unite(&(v27_8),&(v27_12));
            join_wrapped_into(&mut v26_7_write,&((v27_13).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v26_7_write);
          compose(&(v25_5),&(v26_7))
        };
        drop(v25_5);
        let v25_9: Space = intersect(&(*CONSTANT_2),&(v25_2));
        drop(v25_2);
        let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
        drop(v25_9);
        let v25_12: Space = if (&(v25_10)).is_empty() { Space::new() } else {
          let v30_6: Path = concat_path(&(v24_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v30_11 = Space::new();
          let mut v30_11_write = v30_11.write_zipper();
          for v30_11_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v30_11_byte);
            {
            let v31_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v31_3: Space = intersect(&(*CONSTANT_2),&(v31_2));
            let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
            drop(v31_3);
            let v31_5: Space = subtract(&(*CONSTANT_1),&(v31_4));
            drop(v31_4);
            let v31_8: Space = if (&(v31_5)).is_empty() { Space::new() } else {
              let v32_6: Path = concat_path(&(v30_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v32_7: Space = routine_6(c, &(v32_6), &v22_24_cursor, &(*s1));
              compose(&(v31_5),&(v32_7))
            };
            drop(v31_5);
            let v31_9: Space = intersect(&(*CONSTANT_2),&(v31_2));
            drop(v31_2);
            let v31_10: Space = if has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
            drop(v31_9);
            let v31_12: Space = if (&(v31_10)).is_empty() { Space::new() } else {
              let v33_6: Path = concat_path(&(v30_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v33_11: Space = routine_3(c, &(v33_6), &v22_24_cursor, &(*s1));
              drop(v33_6);
              compose(&(v31_10),&(v33_11))
            };
            drop(v31_10);
            let v31_13: Space = unite(&(v31_8),&(v31_12));
            join_wrapped_into(&mut v30_11_write,&((v31_13).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v30_11_write);
          drop(v30_6);
          compose(&(v25_10),&(v30_11))
        };
        drop(v25_10);
        let v25_13: Space = unite(&(v25_8),&(v25_12));
        join_wrapped_into(&mut v24_7_write,&((v25_13).read_zipper()),&[]);
        }
        v22_24_cursor.ascend(1);
      }
      drop(v24_7_write);
      compose(&(v23_5),&(v24_7))
    };
    drop(v23_5);
    let v23_9: Space = intersect(&(*CONSTANT_2),&(v23_2));
    drop(v23_2);
    let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
    drop(v23_9);
    let v23_12: Space = if (&(v23_10)).is_empty() { Space::new() } else {
      let v34_6: Path = concat_path(&(*p0),&v22_24_cursor.path()[v22_24_origin..(v22_24_origin + 1)]);
      let mut v34_11 = Space::new();
      let mut v34_11_write = v34_11.write_zipper();
      for v34_11_byte in v22_24_cursor.child_mask().iter() {
        v22_24_cursor.descend_to_existing_byte(v34_11_byte);
        {
        let v35_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
        let v35_3: Space = intersect(&(*CONSTANT_2),&(v35_2));
        let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
        drop(v35_3);
        let v35_5: Space = subtract(&(*CONSTANT_1),&(v35_4));
        drop(v35_4);
        let v35_8: Space = if (&(v35_5)).is_empty() { Space::new() } else {
          let v36_6: Path = concat_path(&(v34_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v36_7 = Space::new();
          let mut v36_7_write = v36_7.write_zipper();
          for v36_7_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v36_7_byte);
            {
            let v37_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v37_3: Space = intersect(&(*CONSTANT_2),&(v37_2));
            let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
            drop(v37_3);
            let v37_5: Space = subtract(&(*CONSTANT_1),&(v37_4));
            drop(v37_4);
            let v37_8: Space = if (&(v37_5)).is_empty() { Space::new() } else {
              let v38_6: Path = concat_path(&(v36_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v38_7: Space = routine_6(c, &(v38_6), &v22_24_cursor, &(*s1));
              compose(&(v37_5),&(v38_7))
            };
            drop(v37_5);
            let v37_9: Space = intersect(&(*CONSTANT_2),&(v37_2));
            drop(v37_2);
            let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
            drop(v37_9);
            let v37_12: Space = if (&(v37_10)).is_empty() { Space::new() } else {
              let v39_6: Path = concat_path(&(v36_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v39_11: Space = routine_7(c, &(v39_6), &v22_24_cursor, &(*s1));
              drop(v39_6);
              compose(&(v37_10),&(v39_11))
            };
            drop(v37_10);
            let v37_13: Space = unite(&(v37_8),&(v37_12));
            join_wrapped_into(&mut v36_7_write,&((v37_13).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v36_7_write);
          compose(&(v35_5),&(v36_7))
        };
        drop(v35_5);
        let v35_9: Space = intersect(&(*CONSTANT_2),&(v35_2));
        drop(v35_2);
        let v35_10: Space = if has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
        drop(v35_9);
        let v35_12: Space = if (&(v35_10)).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v34_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v40_11 = Space::new();
          let mut v40_11_write = v40_11.write_zipper();
          for v40_11_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v40_11_byte);
            {
            let v41_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v41_3: Space = intersect(&(*CONSTANT_2),&(v41_2));
            let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = subtract(&(*CONSTANT_1),&(v41_4));
            drop(v41_4);
            let v41_7: Space = if (&(v41_5)).is_empty() { Space::new() } else {
              let v42_6: Space = routine_4(c, &v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)], &(v40_6), &v22_24_cursor, &(*s1));
              compose(&(v41_5),&(v42_6))
            };
            drop(v41_5);
            let v41_8: Space = intersect(&(*CONSTANT_2),&(v41_2));
            drop(v41_2);
            let v41_9: Space = if has_head(&(v41_8)) { singleton(&[]) } else { Space::new() };
            drop(v41_8);
            let v41_11: Space = if (&(v41_9)).is_empty() { Space::new() } else {
              let v43_10: Space = routine_5(c, &v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)], &(v40_6), &v22_24_cursor, &(*s1));
              compose(&(v41_9),&(v43_10))
            };
            drop(v41_9);
            let v41_12: Space = unite(&(v41_7),&(v41_11));
            join_wrapped_into(&mut v40_11_write,&((v41_12).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v40_11_write);
          drop(v40_6);
          compose(&(v35_10),&(v40_11))
        };
        drop(v35_10);
        let v35_13: Space = unite(&(v35_8),&(v35_12));
        join_wrapped_into(&mut v34_11_write,&((v35_13).read_zipper()),&[]);
        }
        v22_24_cursor.ascend(1);
      }
      drop(v34_11_write);
      drop(v34_6);
      compose(&(v23_10),&(v34_11))
    };
    drop(v23_10);
    let v23_13: Space = unite(&(v23_8),&(v23_12));
    join_wrapped_into(&mut v22_24_write,&((v23_13).read_zipper()),&[]);
    }
    v22_24_cursor.ascend(1);
  }
  drop(v22_24_cursor);
  drop(v22_24_write);
  (v22_24).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v44_24 = Space::new();
  let mut v44_24_write = v44_24.write_zipper();
  let mut v44_24_cursor = (*s0).read_zipper();
  let v44_24_origin = v44_24_cursor.path().len();
  for v44_24_byte in v44_24_cursor.child_mask().iter() {
    v44_24_cursor.descend_to_existing_byte(v44_24_byte);
    {
    let v45_2: Space = singleton(&v44_24_cursor.path()[v44_24_origin..(v44_24_origin + 1)]);
    let v45_3: Space = intersect(&(*CONSTANT_2),&(v45_2));
    let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
    drop(v45_3);
    let v45_5: Space = subtract(&(*CONSTANT_1),&(v45_4));
    drop(v45_4);
    let v45_8: Space = if (&(v45_5)).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&v44_24_cursor.path()[v44_24_origin..(v44_24_origin + 1)]);
      let mut v46_7 = Space::new();
      let mut v46_7_write = v46_7.write_zipper();
      for v46_7_byte in v44_24_cursor.child_mask().iter() {
        v44_24_cursor.descend_to_existing_byte(v46_7_byte);
        {
        let v47_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
        let v47_3: Space = intersect(&(*CONSTANT_2),&(v47_2));
        let v47_4: Space = if has_head(&(v47_3)) { singleton(&[]) } else { Space::new() };
        drop(v47_3);
        let v47_5: Space = subtract(&(*CONSTANT_1),&(v47_4));
        drop(v47_4);
        let v47_8: Space = if (&(v47_5)).is_empty() { Space::new() } else {
          let v48_6: Path = concat_path(&(v46_6),&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
          let mut v48_7 = Space::new();
          let mut v48_7_write = v48_7.write_zipper();
          for v48_7_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v48_7_byte);
            {
            let v49_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v49_3: Space = intersect(&(*CONSTANT_2),&(v49_2));
            let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
            drop(v49_3);
            let v49_5: Space = subtract(&(*CONSTANT_1),&(v49_4));
            drop(v49_4);
            let v49_8: Space = if (&(v49_5)).is_empty() { Space::new() } else {
              let v50_6: Path = concat_path(&(v48_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v50_7: Space = routine_6(c, &(v50_6), &v44_24_cursor, &(*s1));
              compose(&(v49_5),&(v50_7))
            };
            drop(v49_5);
            let v49_9: Space = intersect(&(*CONSTANT_2),&(v49_2));
            drop(v49_2);
            let v49_10: Space = if has_head(&(v49_9)) { singleton(&[]) } else { Space::new() };
            drop(v49_9);
            let v49_12: Space = if (&(v49_10)).is_empty() { Space::new() } else {
              let v51_6: Path = concat_path(&(v48_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v51_11: Space = routine_7(c, &(v51_6), &v44_24_cursor, &(*s1));
              drop(v51_6);
              compose(&(v49_10),&(v51_11))
            };
            drop(v49_10);
            let v49_13: Space = unite(&(v49_8),&(v49_12));
            join_wrapped_into(&mut v48_7_write,&((v49_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v48_7_write);
          compose(&(v47_5),&(v48_7))
        };
        drop(v47_5);
        let v47_9: Space = intersect(&(*CONSTANT_2),&(v47_2));
        drop(v47_2);
        let v47_10: Space = if has_head(&(v47_9)) { singleton(&[]) } else { Space::new() };
        drop(v47_9);
        let v47_12: Space = if (&(v47_10)).is_empty() { Space::new() } else {
          let v52_6: Path = concat_path(&(v46_6),&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
          let mut v52_11 = Space::new();
          let mut v52_11_write = v52_11.write_zipper();
          for v52_11_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v52_11_byte);
            {
            let v53_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v53_3: Space = intersect(&(*CONSTANT_2),&(v53_2));
            let v53_4: Space = if has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
            drop(v53_3);
            let v53_5: Space = subtract(&(*CONSTANT_1),&(v53_4));
            drop(v53_4);
            let v53_8: Space = if (&(v53_5)).is_empty() { Space::new() } else {
              let v54_6: Path = concat_path(&(v52_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v54_7: Space = routine_6(c, &(v54_6), &v44_24_cursor, &(*s1));
              compose(&(v53_5),&(v54_7))
            };
            drop(v53_5);
            let v53_9: Space = intersect(&(*CONSTANT_2),&(v53_2));
            drop(v53_2);
            let v53_10: Space = if has_head(&(v53_9)) { singleton(&[]) } else { Space::new() };
            drop(v53_9);
            let v53_12: Space = if (&(v53_10)).is_empty() { Space::new() } else {
              let v55_6: Path = concat_path(&(v52_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v55_11: Space = routine_3(c, &(v55_6), &v44_24_cursor, &(*s1));
              drop(v55_6);
              compose(&(v53_10),&(v55_11))
            };
            drop(v53_10);
            let v53_13: Space = unite(&(v53_8),&(v53_12));
            join_wrapped_into(&mut v52_11_write,&((v53_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v52_11_write);
          drop(v52_6);
          compose(&(v47_10),&(v52_11))
        };
        drop(v47_10);
        let v47_13: Space = unite(&(v47_8),&(v47_12));
        join_wrapped_into(&mut v46_7_write,&((v47_13).read_zipper()),&[]);
        }
        v44_24_cursor.ascend(1);
      }
      drop(v46_7_write);
      compose(&(v45_5),&(v46_7))
    };
    drop(v45_5);
    let v45_9: Space = intersect(&(*CONSTANT_2),&(v45_2));
    drop(v45_2);
    let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
    drop(v45_9);
    let v45_12: Space = if (&(v45_10)).is_empty() { Space::new() } else {
      let v56_6: Path = concat_path(&(*p0),&v44_24_cursor.path()[v44_24_origin..(v44_24_origin + 1)]);
      let mut v56_11 = Space::new();
      let mut v56_11_write = v56_11.write_zipper();
      for v56_11_byte in v44_24_cursor.child_mask().iter() {
        v44_24_cursor.descend_to_existing_byte(v56_11_byte);
        {
        let v57_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
        let v57_3: Space = intersect(&(*CONSTANT_2),&(v57_2));
        let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = subtract(&(*CONSTANT_1),&(v57_4));
        drop(v57_4);
        let v57_7: Space = if (&(v57_5)).is_empty() { Space::new() } else {
          let mut v58_6 = Space::new();
          let mut v58_6_write = v58_6.write_zipper();
          for v58_6_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v58_6_byte);
            {
            let v59_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v59_3: Space = intersect(&(*CONSTANT_2),&(v59_2));
            let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
            drop(v59_3);
            let v59_5: Space = subtract(&(*CONSTANT_1),&(v59_4));
            drop(v59_4);
            let v59_8: Space = if (&(v59_5)).is_empty() { Space::new() } else {
              let v60_7: Space = routine_8(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              compose(&(v59_5),&(v60_7))
            };
            drop(v59_5);
            let v59_9: Space = intersect(&(*CONSTANT_2),&(v59_2));
            drop(v59_2);
            let v59_10: Space = if has_head(&(v59_9)) { singleton(&[]) } else { Space::new() };
            drop(v59_9);
            let v59_12: Space = if (&(v59_10)).is_empty() { Space::new() } else {
              let v61_11: Space = routine_9(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              compose(&(v59_10),&(v61_11))
            };
            drop(v59_10);
            let v59_13: Space = unite(&(v59_8),&(v59_12));
            join_wrapped_into(&mut v58_6_write,&((v59_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v58_6_write);
          compose(&(v57_5),&(v58_6))
        };
        drop(v57_5);
        let v57_8: Space = intersect(&(*CONSTANT_2),&(v57_2));
        drop(v57_2);
        let v57_9: Space = if has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
        drop(v57_8);
        let v57_11: Space = if (&(v57_9)).is_empty() { Space::new() } else {
          let mut v62_10 = Space::new();
          let mut v62_10_write = v62_10.write_zipper();
          for v62_10_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v62_10_byte);
            {
            let v63_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v63_3: Space = intersect(&(*CONSTANT_2),&(v63_2));
            let v63_4: Space = if has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
            drop(v63_3);
            let v63_5: Space = subtract(&(*CONSTANT_1),&(v63_4));
            drop(v63_4);
            let v63_8: Space = if (&(v63_5)).is_empty() { Space::new() } else {
              let v64_7: Space = routine_8(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              compose(&(v63_5),&(v64_7))
            };
            drop(v63_5);
            let v63_9: Space = intersect(&(*CONSTANT_2),&(v63_2));
            drop(v63_2);
            let v63_10: Space = if has_head(&(v63_9)) { singleton(&[]) } else { Space::new() };
            drop(v63_9);
            let v63_12: Space = if (&(v63_10)).is_empty() { Space::new() } else {
              let v65_11: Space = routine_10(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              compose(&(v63_10),&(v65_11))
            };
            drop(v63_10);
            let v63_13: Space = unite(&(v63_8),&(v63_12));
            join_wrapped_into(&mut v62_10_write,&((v63_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v62_10_write);
          compose(&(v57_9),&(v62_10))
        };
        drop(v57_9);
        let v57_12: Space = unite(&(v57_7),&(v57_11));
        join_wrapped_into(&mut v56_11_write,&((v57_12).read_zipper()),&[]);
        }
        v44_24_cursor.ascend(1);
      }
      drop(v56_11_write);
      drop(v56_6);
      compose(&(v45_10),&(v56_11))
    };
    drop(v45_10);
    let v45_13: Space = unite(&(v45_8),&(v45_12));
    join_wrapped_into(&mut v44_24_write,&((v45_13).read_zipper()),&[]);
    }
    v44_24_cursor.ascend(1);
  }
  drop(v44_24_cursor);
  drop(v44_24_write);
  (v44_24).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v66_23 = Space::new();
  let mut v66_23_write = v66_23.write_zipper();
  let mut v66_23_cursor = (*s0).read_zipper();
  let v66_23_origin = v66_23_cursor.path().len();
  for v66_23_byte in v66_23_cursor.child_mask().iter() {
    v66_23_cursor.descend_to_existing_byte(v66_23_byte);
    {
    let v67_2: Space = singleton(&v66_23_cursor.path()[v66_23_origin..(v66_23_origin + 1)]);
    let v67_3: Space = intersect(&(*CONSTANT_2),&(v67_2));
    let v67_4: Space = if has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
    drop(v67_3);
    let v67_5: Space = subtract(&(*CONSTANT_1),&(v67_4));
    drop(v67_4);
    let v67_7: Space = if (&(v67_5)).is_empty() { Space::new() } else {
      let mut v68_6 = Space::new();
      let mut v68_6_write = v68_6.write_zipper();
      for v68_6_byte in v66_23_cursor.child_mask().iter() {
        v66_23_cursor.descend_to_existing_byte(v68_6_byte);
        {
        let v69_2: Space = singleton(&v66_23_cursor.path()[(v66_23_origin + 1)..(v66_23_origin + 2)]);
        let v69_3: Space = intersect(&(*CONSTANT_2),&(v69_2));
        let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
        drop(v69_3);
        let v69_5: Space = subtract(&(*CONSTANT_1),&(v69_4));
        drop(v69_4);
        let v69_8: Space = if (&(v69_5)).is_empty() { Space::new() } else {
          let mut v70_7 = Space::new();
          let mut v70_7_write = v70_7.write_zipper();
          for v70_7_byte in v66_23_cursor.child_mask().iter() {
            v66_23_cursor.descend_to_existing_byte(v70_7_byte);
            {
            let v71_2: Space = singleton(&v66_23_cursor.path()[(v66_23_origin + 2)..(v66_23_origin + 3)]);
            let v71_3: Space = intersect(&(*CONSTANT_2),&(v71_2));
            let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
            drop(v71_3);
            let v71_5: Space = subtract(&(*CONSTANT_1),&(v71_4));
            drop(v71_4);
            let v71_8: Space = if (&(v71_5)).is_empty() { Space::new() } else {
              let v72_7: Space = routine_11(c, &v66_23_cursor.path()[v66_23_origin..(v66_23_origin + 3)], &(*p0), &v66_23_cursor, &(*s1));
              compose(&(v71_5),&(v72_7))
            };
            drop(v71_5);
            let v71_9: Space = intersect(&(*CONSTANT_2),&(v71_2));
            drop(v71_2);
            let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
            drop(v71_9);
            let v71_12: Space = if (&(v71_10)).is_empty() { Space::new() } else {
              let v73_11: Space = routine_12(c, &v66_23_cursor.path()[v66_23_origin..(v66_23_origin + 3)], &(*p0), &v66_23_cursor, &(*s1));
              compose(&(v71_10),&(v73_11))
            };
            drop(v71_10);
            let v71_13: Space = unite(&(v71_8),&(v71_12));
            join_wrapped_into(&mut v70_7_write,&((v71_13).read_zipper()),&[]);
            }
            v66_23_cursor.ascend(1);
          }
          drop(v70_7_write);
          compose(&(v69_5),&(v70_7))
        };
        drop(v69_5);
        let v69_9: Space = intersect(&(*CONSTANT_2),&(v69_2));
        drop(v69_2);
        let v69_10: Space = if has_head(&(v69_9)) { singleton(&[]) } else { Space::new() };
        drop(v69_9);
        let v69_12: Space = if (&(v69_10)).is_empty() { Space::new() } else {
          let mut v74_11 = Space::new();
          let mut v74_11_write = v74_11.write_zipper();
          for v74_11_byte in v66_23_cursor.child_mask().iter() {
            v66_23_cursor.descend_to_existing_byte(v74_11_byte);
            {
            let v75_2: Space = singleton(&v66_23_cursor.path()[(v66_23_origin + 2)..(v66_23_origin + 3)]);
            let v75_3: Space = intersect(&(*CONSTANT_2),&(v75_2));
            let v75_4: Space = if has_head(&(v75_3)) { singleton(&[]) } else { Space::new() };
            drop(v75_3);
            let v75_5: Space = subtract(&(*CONSTANT_1),&(v75_4));
            drop(v75_4);
            let v75_8: Space = if (&(v75_5)).is_empty() { Space::new() } else {
              let v76_7: Space = routine_11(c, &v66_23_cursor.path()[v66_23_origin..(v66_23_origin + 3)], &(*p0), &v66_23_cursor, &(*s1));
              compose(&(v75_5),&(v76_7))
            };
            drop(v75_5);
            let v75_9: Space = intersect(&(*CONSTANT_2),&(v75_2));
            drop(v75_2);
            let v75_10: Space = if has_head(&(v75_9)) { singleton(&[]) } else { Space::new() };
            drop(v75_9);
            let v75_12: Space = if (&(v75_10)).is_empty() { Space::new() } else {
              let v77_11: Space = routine_10(c, &v66_23_cursor.path()[v66_23_origin..(v66_23_origin + 3)], &(*p0), &v66_23_cursor, &(*s1));
              compose(&(v75_10),&(v77_11))
            };
            drop(v75_10);
            let v75_13: Space = unite(&(v75_8),&(v75_12));
            join_wrapped_into(&mut v74_11_write,&((v75_13).read_zipper()),&[]);
            }
            v66_23_cursor.ascend(1);
          }
          drop(v74_11_write);
          compose(&(v69_10),&(v74_11))
        };
        drop(v69_10);
        let v69_13: Space = unite(&(v69_8),&(v69_12));
        join_wrapped_into(&mut v68_6_write,&((v69_13).read_zipper()),&[]);
        }
        v66_23_cursor.ascend(1);
      }
      drop(v68_6_write);
      compose(&(v67_5),&(v68_6))
    };
    drop(v67_5);
    let v67_8: Space = intersect(&(*CONSTANT_2),&(v67_2));
    drop(v67_2);
    let v67_9: Space = if has_head(&(v67_8)) { singleton(&[]) } else { Space::new() };
    drop(v67_8);
    let v67_12: Space = if (&(v67_9)).is_empty() { Space::new() } else {
      let mut v78_11 = Space::new();
      let mut v78_11_write = v78_11.write_zipper();
      for v78_11_byte in v66_23_cursor.child_mask().iter() {
        v66_23_cursor.descend_to_existing_byte(v78_11_byte);
        {
        let v79_2: Space = singleton(&v66_23_cursor.path()[(v66_23_origin + 1)..(v66_23_origin + 2)]);
        let v79_3: Space = intersect(&(*CONSTANT_2),&(v79_2));
        let v79_4: Space = if has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
        drop(v79_3);
        let v79_5: Space = subtract(&(*CONSTANT_1),&(v79_4));
        drop(v79_4);
        let v79_8: Space = if (&(v79_5)).is_empty() { Space::new() } else {
          let mut v80_7 = Space::new();
          let mut v80_7_write = v80_7.write_zipper();
          for v80_7_byte in v66_23_cursor.child_mask().iter() {
            v66_23_cursor.descend_to_existing_byte(v80_7_byte);
            {
            let v81_2: Space = singleton(&v66_23_cursor.path()[(v66_23_origin + 2)..(v66_23_origin + 3)]);
            let v81_3: Space = intersect(&(*CONSTANT_2),&(v81_2));
            let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
            drop(v81_3);
            let v81_5: Space = subtract(&(*CONSTANT_1),&(v81_4));
            drop(v81_4);
            let v81_8: Space = if (&(v81_5)).is_empty() { Space::new() } else {
              let v82_7: Space = routine_11(c, &v66_23_cursor.path()[v66_23_origin..(v66_23_origin + 3)], &(*p0), &v66_23_cursor, &(*s1));
              compose(&(v81_5),&(v82_7))
            };
            drop(v81_5);
            let v81_9: Space = intersect(&(*CONSTANT_2),&(v81_2));
            drop(v81_2);
            let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
            drop(v81_9);
            let v81_12: Space = if (&(v81_10)).is_empty() { Space::new() } else {
              let v83_11: Space = routine_12(c, &v66_23_cursor.path()[v66_23_origin..(v66_23_origin + 3)], &(*p0), &v66_23_cursor, &(*s1));
              compose(&(v81_10),&(v83_11))
            };
            drop(v81_10);
            let v81_13: Space = unite(&(v81_8),&(v81_12));
            join_wrapped_into(&mut v80_7_write,&((v81_13).read_zipper()),&[]);
            }
            v66_23_cursor.ascend(1);
          }
          drop(v80_7_write);
          compose(&(v79_5),&(v80_7))
        };
        drop(v79_5);
        let v79_9: Space = intersect(&(*CONSTANT_2),&(v79_2));
        drop(v79_2);
        let v79_10: Space = if has_head(&(v79_9)) { singleton(&[]) } else { Space::new() };
        drop(v79_9);
        let v79_13: Space = if (&(v79_10)).is_empty() { Space::new() } else {
          compose(&(v79_10),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&v66_23_cursor.path()[v66_23_origin..(v66_23_origin + 1)]),&v66_23_cursor.path()[(v66_23_origin + 1)..(v66_23_origin + 2)]),&(*p0))))
        };
        drop(v79_10);
        let v79_14: Space = wrap(&(v79_13),&v66_23_cursor.path()[v66_23_origin..(v66_23_origin + 2)]);
        drop(v79_13);
        let v79_15: Space = wrap(&(v79_14),&(*p0));
        drop(v79_14);
        let v79_16: Space = unite(&(v79_8),&(v79_15));
        drop(v79_15);
        join_wrapped_into(&mut v78_11_write,&((v79_16).read_zipper()),&[]);
        }
        v66_23_cursor.ascend(1);
      }
      drop(v78_11_write);
      compose(&(v67_9),&(v78_11))
    };
    drop(v67_9);
    let v67_13: Space = unite(&(v67_7),&(v67_12));
    join_wrapped_into(&mut v66_23_write,&((v67_13).read_zipper()),&[]);
    }
    v66_23_cursor.ascend(1);
  }
  drop(v66_23_cursor);
  drop(v66_23_write);
  (v66_23).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v86_25 = Space::new();
  let mut v86_25_write = v86_25.write_zipper();
  let mut v86_25_cursor = (*s0).read_zipper();
  let v86_25_origin = v86_25_cursor.path().len();
  for v86_25_byte in v86_25_cursor.child_mask().iter() {
    v86_25_cursor.descend_to_existing_byte(v86_25_byte);
    {
    let v87_2: Space = singleton(&v86_25_cursor.path()[v86_25_origin..(v86_25_origin + 1)]);
    let v87_3: Space = intersect(&(*CONSTANT_2),&(v87_2));
    let v87_4: Space = if has_head(&(v87_3)) { singleton(&[]) } else { Space::new() };
    drop(v87_3);
    let v87_5: Space = subtract(&(*CONSTANT_1),&(v87_4));
    drop(v87_4);
    let v87_8: Space = if (&(v87_5)).is_empty() { Space::new() } else {
      let v88_6: Path = concat_path(&(*p0),&v86_25_cursor.path()[v86_25_origin..(v86_25_origin + 1)]);
      let mut v88_7 = Space::new();
      let mut v88_7_write = v88_7.write_zipper();
      for v88_7_byte in v86_25_cursor.child_mask().iter() {
        v86_25_cursor.descend_to_existing_byte(v88_7_byte);
        {
        let v89_2: Space = singleton(&v86_25_cursor.path()[(v86_25_origin + 1)..(v86_25_origin + 2)]);
        let v89_3: Space = intersect(&(*CONSTANT_2),&(v89_2));
        let v89_4: Space = if has_head(&(v89_3)) { singleton(&[]) } else { Space::new() };
        drop(v89_3);
        let v89_5: Space = subtract(&(*CONSTANT_1),&(v89_4));
        drop(v89_4);
        let v89_8: Space = if (&(v89_5)).is_empty() { Space::new() } else {
          let v90_6: Path = concat_path(&(v88_6),&v86_25_cursor.path()[(v86_25_origin + 1)..(v86_25_origin + 2)]);
          let mut v90_7 = Space::new();
          let mut v90_7_write = v90_7.write_zipper();
          for v90_7_byte in v86_25_cursor.child_mask().iter() {
            v86_25_cursor.descend_to_existing_byte(v90_7_byte);
            {
            let v91_2: Space = singleton(&v86_25_cursor.path()[(v86_25_origin + 2)..(v86_25_origin + 3)]);
            let v91_3: Space = intersect(&(*CONSTANT_2),&(v91_2));
            let v91_4: Space = if has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
            drop(v91_3);
            let v91_5: Space = subtract(&(*CONSTANT_1),&(v91_4));
            drop(v91_4);
            let v91_8: Space = if (&(v91_5)).is_empty() { Space::new() } else {
              let v92_6: Path = concat_path(&(v90_6),&v86_25_cursor.path()[(v86_25_origin + 2)..(v86_25_origin + 3)]);
              let v92_7: Space = routine_13(c, &(v92_6), &(*p1), &v86_25_cursor, &(*s1));
              compose(&(v91_5),&(v92_7))
            };
            drop(v91_5);
            let v91_9: Space = intersect(&(*CONSTANT_2),&(v91_2));
            drop(v91_2);
            let v91_10: Space = if has_head(&(v91_9)) { singleton(&[]) } else { Space::new() };
            drop(v91_9);
            let v91_12: Space = if (&(v91_10)).is_empty() { Space::new() } else {
              let v93_6: Path = concat_path(&(v90_6),&v86_25_cursor.path()[(v86_25_origin + 2)..(v86_25_origin + 3)]);
              let v93_11: Space = routine_14(c, &(v93_6), &(*p1), &v86_25_cursor, &(*s1));
              drop(v93_6);
              compose(&(v91_10),&(v93_11))
            };
            drop(v91_10);
            let v91_13: Space = unite(&(v91_8),&(v91_12));
            join_wrapped_into(&mut v90_7_write,&((v91_13).read_zipper()),&[]);
            }
            v86_25_cursor.ascend(1);
          }
          drop(v90_7_write);
          compose(&(v89_5),&(v90_7))
        };
        drop(v89_5);
        let v89_9: Space = intersect(&(*CONSTANT_2),&(v89_2));
        drop(v89_2);
        let v89_10: Space = if has_head(&(v89_9)) { singleton(&[]) } else { Space::new() };
        drop(v89_9);
        let v89_12: Space = if (&(v89_10)).is_empty() { Space::new() } else {
          let v94_6: Path = concat_path(&(v88_6),&v86_25_cursor.path()[(v86_25_origin + 1)..(v86_25_origin + 2)]);
          let mut v94_11 = Space::new();
          let mut v94_11_write = v94_11.write_zipper();
          for v94_11_byte in v86_25_cursor.child_mask().iter() {
            v86_25_cursor.descend_to_existing_byte(v94_11_byte);
            {
            let v95_2: Space = singleton(&v86_25_cursor.path()[(v86_25_origin + 2)..(v86_25_origin + 3)]);
            let v95_3: Space = intersect(&(*CONSTANT_2),&(v95_2));
            let v95_4: Space = if has_head(&(v95_3)) { singleton(&[]) } else { Space::new() };
            drop(v95_3);
            let v95_5: Space = subtract(&(*CONSTANT_1),&(v95_4));
            drop(v95_4);
            let v95_8: Space = if (&(v95_5)).is_empty() { Space::new() } else {
              let v96_6: Path = concat_path(&(v94_6),&v86_25_cursor.path()[(v86_25_origin + 2)..(v86_25_origin + 3)]);
              let v96_7: Space = routine_13(c, &(v96_6), &(*p1), &v86_25_cursor, &(*s1));
              compose(&(v95_5),&(v96_7))
            };
            drop(v95_5);
            let v95_9: Space = intersect(&(*CONSTANT_2),&(v95_2));
            drop(v95_2);
            let v95_10: Space = if has_head(&(v95_9)) { singleton(&[]) } else { Space::new() };
            drop(v95_9);
            let v95_12: Space = if (&(v95_10)).is_empty() { Space::new() } else {
              let v97_6: Path = concat_path(&(v94_6),&v86_25_cursor.path()[(v86_25_origin + 2)..(v86_25_origin + 3)]);
              let v97_11: Space = routine_10(c, &(v97_6), &(*p1), &v86_25_cursor, &(*s1));
              drop(v97_6);
              compose(&(v95_10),&(v97_11))
            };
            drop(v95_10);
            let v95_13: Space = unite(&(v95_8),&(v95_12));
            join_wrapped_into(&mut v94_11_write,&((v95_13).read_zipper()),&[]);
            }
            v86_25_cursor.ascend(1);
          }
          drop(v94_11_write);
          drop(v94_6);
          compose(&(v89_10),&(v94_11))
        };
        drop(v89_10);
        let v89_13: Space = unite(&(v89_8),&(v89_12));
        join_wrapped_into(&mut v88_7_write,&((v89_13).read_zipper()),&[]);
        }
        v86_25_cursor.ascend(1);
      }
      drop(v88_7_write);
      compose(&(v87_5),&(v88_7))
    };
    drop(v87_5);
    let v87_9: Space = intersect(&(*CONSTANT_2),&(v87_2));
    drop(v87_2);
    let v87_10: Space = if has_head(&(v87_9)) { singleton(&[]) } else { Space::new() };
    drop(v87_9);
    let v87_13: Space = if (&(v87_10)).is_empty() { Space::new() } else {
      let v98_6: Path = concat_path(&(*p0),&v86_25_cursor.path()[v86_25_origin..(v86_25_origin + 1)]);
      let mut v98_12 = Space::new();
      let mut v98_12_write = v98_12.write_zipper();
      for v98_12_byte in v86_25_cursor.child_mask().iter() {
        v86_25_cursor.descend_to_existing_byte(v98_12_byte);
        {
        let v99_2: Space = singleton(&v86_25_cursor.path()[(v86_25_origin + 1)..(v86_25_origin + 2)]);
        let v99_3: Space = intersect(&(*CONSTANT_2),&(v99_2));
        let v99_4: Space = if has_head(&(v99_3)) { singleton(&[]) } else { Space::new() };
        drop(v99_3);
        let v99_5: Space = subtract(&(*CONSTANT_1),&(v99_4));
        drop(v99_4);
        let v99_8: Space = if (&(v99_5)).is_empty() { Space::new() } else {
          let v100_6: Path = concat_path(&(v98_6),&v86_25_cursor.path()[(v86_25_origin + 1)..(v86_25_origin + 2)]);
          let mut v100_7 = Space::new();
          let mut v100_7_write = v100_7.write_zipper();
          for v100_7_byte in v86_25_cursor.child_mask().iter() {
            v86_25_cursor.descend_to_existing_byte(v100_7_byte);
            {
            let v101_2: Space = singleton(&v86_25_cursor.path()[(v86_25_origin + 2)..(v86_25_origin + 3)]);
            let v101_3: Space = intersect(&(*CONSTANT_2),&(v101_2));
            let v101_4: Space = if has_head(&(v101_3)) { singleton(&[]) } else { Space::new() };
            drop(v101_3);
            let v101_5: Space = subtract(&(*CONSTANT_1),&(v101_4));
            drop(v101_4);
            let v101_8: Space = if (&(v101_5)).is_empty() { Space::new() } else {
              let v102_6: Path = concat_path(&(v100_6),&v86_25_cursor.path()[(v86_25_origin + 2)..(v86_25_origin + 3)]);
              let v102_7: Space = routine_13(c, &(v102_6), &(*p1), &v86_25_cursor, &(*s1));
              compose(&(v101_5),&(v102_7))
            };
            drop(v101_5);
            let v101_9: Space = intersect(&(*CONSTANT_2),&(v101_2));
            drop(v101_2);
            let v101_10: Space = if has_head(&(v101_9)) { singleton(&[]) } else { Space::new() };
            drop(v101_9);
            let v101_12: Space = if (&(v101_10)).is_empty() { Space::new() } else {
              let v103_6: Path = concat_path(&(v100_6),&v86_25_cursor.path()[(v86_25_origin + 2)..(v86_25_origin + 3)]);
              let v103_11: Space = routine_14(c, &(v103_6), &(*p1), &v86_25_cursor, &(*s1));
              drop(v103_6);
              compose(&(v101_10),&(v103_11))
            };
            drop(v101_10);
            let v101_13: Space = unite(&(v101_8),&(v101_12));
            join_wrapped_into(&mut v100_7_write,&((v101_13).read_zipper()),&[]);
            }
            v86_25_cursor.ascend(1);
          }
          drop(v100_7_write);
          compose(&(v99_5),&(v100_7))
        };
        drop(v99_5);
        let v99_9: Space = intersect(&(*CONSTANT_2),&(v99_2));
        drop(v99_2);
        let v99_10: Space = if has_head(&(v99_9)) { singleton(&[]) } else { Space::new() };
        drop(v99_9);
        let v99_13: Space = if (&(v99_10)).is_empty() { Space::new() } else {
          compose(&(v99_10),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v86_25_cursor.path()[v86_25_origin..(v86_25_origin + 1)]),&v86_25_cursor.path()[(v86_25_origin + 1)..(v86_25_origin + 2)]),&(*p1))))
        };
        drop(v99_10);
        let v105_6: Path = concat_path(&(v98_6),&v86_25_cursor.path()[(v86_25_origin + 1)..(v86_25_origin + 2)]);
        let v99_14: Space = wrap(&(v99_13),&(v105_6));
        drop(v99_13);
        let v99_15: Space = wrap(&(v99_14),&(*p1));
        drop(v99_14);
        let v99_16: Space = unite(&(v99_8),&(v99_15));
        drop(v99_15);
        join_wrapped_into(&mut v98_12_write,&((v99_16).read_zipper()),&[]);
        }
        v86_25_cursor.ascend(1);
      }
      drop(v98_12_write);
      drop(v98_6);
      compose(&(v87_10),&(v98_12))
    };
    drop(v87_10);
    let v87_14: Space = unite(&(v87_8),&(v87_13));
    join_wrapped_into(&mut v86_25_write,&((v87_14).read_zipper()),&[]);
    }
    v86_25_cursor.ascend(1);
  }
  drop(v86_25_cursor);
  drop(v86_25_write);
  (v86_25).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v106_19 = Space::new();
  let mut v106_19_write = v106_19.write_zipper();
  let mut v106_19_cursor = (*s0).read_zipper();
  let v106_19_origin = v106_19_cursor.path().len();
  for v106_19_byte in v106_19_cursor.child_mask().iter() {
    v106_19_cursor.descend_to_existing_byte(v106_19_byte);
    {
    let v107_2: Space = singleton(&v106_19_cursor.path()[v106_19_origin..(v106_19_origin + 1)]);
    let v107_3: Space = intersect(&(*CONSTANT_2),&(v107_2));
    let v107_4: Space = if has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
    drop(v107_3);
    let v107_5: Space = subtract(&(*CONSTANT_1),&(v107_4));
    drop(v107_4);
    let v107_8: Space = if (&(v107_5)).is_empty() { Space::new() } else {
      let v108_6: Path = concat_path(&(*p0),&v106_19_cursor.path()[v106_19_origin..(v106_19_origin + 1)]);
      let mut v108_7 = Space::new();
      let mut v108_7_write = v108_7.write_zipper();
      for v108_7_byte in v106_19_cursor.child_mask().iter() {
        v106_19_cursor.descend_to_existing_byte(v108_7_byte);
        {
        let v109_2: Space = singleton(&v106_19_cursor.path()[(v106_19_origin + 1)..(v106_19_origin + 2)]);
        let v109_3: Space = intersect(&(*CONSTANT_2),&(v109_2));
        let v109_4: Space = if has_head(&(v109_3)) { singleton(&[]) } else { Space::new() };
        drop(v109_3);
        let v109_5: Space = subtract(&(*CONSTANT_1),&(v109_4));
        drop(v109_4);
        let v109_8: Space = if (&(v109_5)).is_empty() { Space::new() } else {
          let v110_6: Path = concat_path(&(v108_6),&v106_19_cursor.path()[(v106_19_origin + 1)..(v106_19_origin + 2)]);
          let mut v110_7 = Space::new();
          let mut v110_7_write = v110_7.write_zipper();
          for v110_7_byte in v106_19_cursor.child_mask().iter() {
            v106_19_cursor.descend_to_existing_byte(v110_7_byte);
            {
            let v111_2: Space = singleton(&v106_19_cursor.path()[(v106_19_origin + 2)..(v106_19_origin + 3)]);
            let v111_3: Space = intersect(&(*CONSTANT_2),&(v111_2));
            let v111_4: Space = if has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
            drop(v111_3);
            let v111_5: Space = subtract(&(*CONSTANT_1),&(v111_4));
            drop(v111_4);
            let v111_8: Space = if (&(v111_5)).is_empty() { Space::new() } else {
              let v112_6: Path = concat_path(&(v110_6),&v106_19_cursor.path()[(v106_19_origin + 2)..(v106_19_origin + 3)]);
              let v112_7: Space = routine_13(c, &(v112_6), &(*p1), &v106_19_cursor, &(*s1));
              compose(&(v111_5),&(v112_7))
            };
            drop(v111_5);
            let v111_9: Space = intersect(&(*CONSTANT_2),&(v111_2));
            drop(v111_2);
            let v111_10: Space = if has_head(&(v111_9)) { singleton(&[]) } else { Space::new() };
            drop(v111_9);
            let v111_12: Space = if (&(v111_10)).is_empty() { Space::new() } else {
              let v113_6: Path = concat_path(&(v110_6),&v106_19_cursor.path()[(v106_19_origin + 2)..(v106_19_origin + 3)]);
              let v113_11: Space = routine_14(c, &(v113_6), &(*p1), &v106_19_cursor, &(*s1));
              drop(v113_6);
              compose(&(v111_10),&(v113_11))
            };
            drop(v111_10);
            let v111_13: Space = unite(&(v111_8),&(v111_12));
            join_wrapped_into(&mut v110_7_write,&((v111_13).read_zipper()),&[]);
            }
            v106_19_cursor.ascend(1);
          }
          drop(v110_7_write);
          compose(&(v109_5),&(v110_7))
        };
        drop(v109_5);
        let v109_9: Space = intersect(&(*CONSTANT_2),&(v109_2));
        drop(v109_2);
        let v109_10: Space = if has_head(&(v109_9)) { singleton(&[]) } else { Space::new() };
        drop(v109_9);
        let v109_12: Space = if (&(v109_10)).is_empty() { Space::new() } else {
          let v114_6: Path = concat_path(&(v108_6),&v106_19_cursor.path()[(v106_19_origin + 1)..(v106_19_origin + 2)]);
          let mut v114_11 = Space::new();
          let mut v114_11_write = v114_11.write_zipper();
          for v114_11_byte in v106_19_cursor.child_mask().iter() {
            v106_19_cursor.descend_to_existing_byte(v114_11_byte);
            {
            let v115_2: Space = singleton(&v106_19_cursor.path()[(v106_19_origin + 2)..(v106_19_origin + 3)]);
            let v115_3: Space = intersect(&(*CONSTANT_2),&(v115_2));
            let v115_4: Space = if has_head(&(v115_3)) { singleton(&[]) } else { Space::new() };
            drop(v115_3);
            let v115_5: Space = subtract(&(*CONSTANT_1),&(v115_4));
            drop(v115_4);
            let v115_8: Space = if (&(v115_5)).is_empty() { Space::new() } else {
              let v116_6: Path = concat_path(&(v114_6),&v106_19_cursor.path()[(v106_19_origin + 2)..(v106_19_origin + 3)]);
              let v116_7: Space = routine_13(c, &(v116_6), &(*p1), &v106_19_cursor, &(*s1));
              compose(&(v115_5),&(v116_7))
            };
            drop(v115_5);
            let v115_9: Space = intersect(&(*CONSTANT_2),&(v115_2));
            drop(v115_2);
            let v115_10: Space = if has_head(&(v115_9)) { singleton(&[]) } else { Space::new() };
            drop(v115_9);
            let v115_12: Space = if (&(v115_10)).is_empty() { Space::new() } else {
              let v117_6: Path = concat_path(&(v114_6),&v106_19_cursor.path()[(v106_19_origin + 2)..(v106_19_origin + 3)]);
              let v117_11: Space = routine_10(c, &(v117_6), &(*p1), &v106_19_cursor, &(*s1));
              drop(v117_6);
              compose(&(v115_10),&(v117_11))
            };
            drop(v115_10);
            let v115_13: Space = unite(&(v115_8),&(v115_12));
            join_wrapped_into(&mut v114_11_write,&((v115_13).read_zipper()),&[]);
            }
            v106_19_cursor.ascend(1);
          }
          drop(v114_11_write);
          drop(v114_6);
          compose(&(v109_10),&(v114_11))
        };
        drop(v109_10);
        let v109_13: Space = unite(&(v109_8),&(v109_12));
        join_wrapped_into(&mut v108_7_write,&((v109_13).read_zipper()),&[]);
        }
        v106_19_cursor.ascend(1);
      }
      drop(v108_7_write);
      compose(&(v107_5),&(v108_7))
    };
    drop(v107_5);
    let v107_9: Space = intersect(&(*CONSTANT_2),&(v107_2));
    drop(v107_2);
    let v107_10: Space = if has_head(&(v107_9)) { singleton(&[]) } else { Space::new() };
    drop(v107_9);
    let v107_13: Space = if (&(v107_10)).is_empty() { Space::new() } else {
      compose(&(v107_10),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v106_19_cursor.path()[v106_19_origin..(v106_19_origin + 1)]),&(*p1))))
    };
    drop(v107_10);
    let v119_6: Path = concat_path(&(*p0),&v106_19_cursor.path()[v106_19_origin..(v106_19_origin + 1)]);
    let v107_14: Space = wrap(&(v107_13),&(v119_6));
    drop(v107_13);
    let v107_15: Space = wrap(&(v107_14),&(*p1));
    drop(v107_14);
    let v107_16: Space = unite(&(v107_8),&(v107_15));
    drop(v107_15);
    join_wrapped_into(&mut v106_19_write,&((v107_16).read_zipper()),&[]);
    }
    v106_19_cursor.ascend(1);
  }
  drop(v106_19_cursor);
  drop(v106_19_write);
  (v106_19).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v120_24 = Space::new();
  let mut v120_24_write = v120_24.write_zipper();
  let mut v120_24_cursor = (*s0).read_zipper();
  let v120_24_origin = v120_24_cursor.path().len();
  for v120_24_byte in v120_24_cursor.child_mask().iter() {
    v120_24_cursor.descend_to_existing_byte(v120_24_byte);
    {
    let v121_2: Space = singleton(&v120_24_cursor.path()[v120_24_origin..(v120_24_origin + 1)]);
    let v121_3: Space = intersect(&(*CONSTANT_2),&(v121_2));
    let v121_4: Space = if has_head(&(v121_3)) { singleton(&[]) } else { Space::new() };
    drop(v121_3);
    let v121_5: Space = subtract(&(*CONSTANT_1),&(v121_4));
    drop(v121_4);
    let v121_8: Space = if (&(v121_5)).is_empty() { Space::new() } else {
      let v122_6: Path = concat_path(&(*p0),&v120_24_cursor.path()[v120_24_origin..(v120_24_origin + 1)]);
      let mut v122_7 = Space::new();
      let mut v122_7_write = v122_7.write_zipper();
      for v122_7_byte in v120_24_cursor.child_mask().iter() {
        v120_24_cursor.descend_to_existing_byte(v122_7_byte);
        {
        let v123_2: Space = singleton(&v120_24_cursor.path()[(v120_24_origin + 1)..(v120_24_origin + 2)]);
        let v123_3: Space = intersect(&(*CONSTANT_2),&(v123_2));
        let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = subtract(&(*CONSTANT_1),&(v123_4));
        drop(v123_4);
        let v123_8: Space = if (&(v123_5)).is_empty() { Space::new() } else {
          let v124_6: Path = concat_path(&(v122_6),&v120_24_cursor.path()[(v120_24_origin + 1)..(v120_24_origin + 2)]);
          let mut v124_7 = Space::new();
          let mut v124_7_write = v124_7.write_zipper();
          for v124_7_byte in v120_24_cursor.child_mask().iter() {
            v120_24_cursor.descend_to_existing_byte(v124_7_byte);
            {
            let v125_2: Space = singleton(&v120_24_cursor.path()[(v120_24_origin + 2)..(v120_24_origin + 3)]);
            let v125_3: Space = intersect(&(*CONSTANT_2),&(v125_2));
            let v125_4: Space = if has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
            drop(v125_3);
            let v125_5: Space = subtract(&(*CONSTANT_1),&(v125_4));
            drop(v125_4);
            let v125_8: Space = if (&(v125_5)).is_empty() { Space::new() } else {
              let v126_6: Path = concat_path(&(v124_6),&v120_24_cursor.path()[(v120_24_origin + 2)..(v120_24_origin + 3)]);
              let v126_7: Space = routine_15(c, &(v126_6), &v120_24_cursor, &(*s1));
              compose(&(v125_5),&(v126_7))
            };
            drop(v125_5);
            let v125_9: Space = intersect(&(*CONSTANT_2),&(v125_2));
            drop(v125_2);
            let v125_10: Space = if has_head(&(v125_9)) { singleton(&[]) } else { Space::new() };
            drop(v125_9);
            let v125_12: Space = if (&(v125_10)).is_empty() { Space::new() } else {
              let v127_6: Path = concat_path(&(v124_6),&v120_24_cursor.path()[(v120_24_origin + 2)..(v120_24_origin + 3)]);
              let v127_11: Space = routine_16(c, &(v127_6), &v120_24_cursor, &(*s1));
              drop(v127_6);
              compose(&(v125_10),&(v127_11))
            };
            drop(v125_10);
            let v125_13: Space = unite(&(v125_8),&(v125_12));
            join_wrapped_into(&mut v124_7_write,&((v125_13).read_zipper()),&[]);
            }
            v120_24_cursor.ascend(1);
          }
          drop(v124_7_write);
          compose(&(v123_5),&(v124_7))
        };
        drop(v123_5);
        let v123_9: Space = intersect(&(*CONSTANT_2),&(v123_2));
        drop(v123_2);
        let v123_10: Space = if has_head(&(v123_9)) { singleton(&[]) } else { Space::new() };
        drop(v123_9);
        let v123_12: Space = if (&(v123_10)).is_empty() { Space::new() } else {
          let v128_6: Path = concat_path(&(v122_6),&v120_24_cursor.path()[(v120_24_origin + 1)..(v120_24_origin + 2)]);
          let mut v128_11 = Space::new();
          let mut v128_11_write = v128_11.write_zipper();
          for v128_11_byte in v120_24_cursor.child_mask().iter() {
            v120_24_cursor.descend_to_existing_byte(v128_11_byte);
            {
            let v129_2: Space = singleton(&v120_24_cursor.path()[(v120_24_origin + 2)..(v120_24_origin + 3)]);
            let v129_3: Space = intersect(&(*CONSTANT_2),&(v129_2));
            let v129_4: Space = if has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
            drop(v129_3);
            let v129_5: Space = subtract(&(*CONSTANT_1),&(v129_4));
            drop(v129_4);
            let v129_8: Space = if (&(v129_5)).is_empty() { Space::new() } else {
              let v130_6: Path = concat_path(&(v128_6),&v120_24_cursor.path()[(v120_24_origin + 2)..(v120_24_origin + 3)]);
              let v130_7: Space = routine_15(c, &(v130_6), &v120_24_cursor, &(*s1));
              compose(&(v129_5),&(v130_7))
            };
            drop(v129_5);
            let v129_9: Space = intersect(&(*CONSTANT_2),&(v129_2));
            drop(v129_2);
            let v129_10: Space = if has_head(&(v129_9)) { singleton(&[]) } else { Space::new() };
            drop(v129_9);
            let v129_12: Space = if (&(v129_10)).is_empty() { Space::new() } else {
              let v131_6: Path = concat_path(&(v128_6),&v120_24_cursor.path()[(v120_24_origin + 2)..(v120_24_origin + 3)]);
              let v131_11: Space = routine_3(c, &(v131_6), &v120_24_cursor, &(*s1));
              drop(v131_6);
              compose(&(v129_10),&(v131_11))
            };
            drop(v129_10);
            let v129_13: Space = unite(&(v129_8),&(v129_12));
            join_wrapped_into(&mut v128_11_write,&((v129_13).read_zipper()),&[]);
            }
            v120_24_cursor.ascend(1);
          }
          drop(v128_11_write);
          drop(v128_6);
          compose(&(v123_10),&(v128_11))
        };
        drop(v123_10);
        let v123_13: Space = unite(&(v123_8),&(v123_12));
        join_wrapped_into(&mut v122_7_write,&((v123_13).read_zipper()),&[]);
        }
        v120_24_cursor.ascend(1);
      }
      drop(v122_7_write);
      compose(&(v121_5),&(v122_7))
    };
    drop(v121_5);
    let v121_9: Space = intersect(&(*CONSTANT_2),&(v121_2));
    drop(v121_2);
    let v121_10: Space = if has_head(&(v121_9)) { singleton(&[]) } else { Space::new() };
    drop(v121_9);
    let v121_12: Space = if (&(v121_10)).is_empty() { Space::new() } else {
      let v132_6: Path = concat_path(&(*p0),&v120_24_cursor.path()[v120_24_origin..(v120_24_origin + 1)]);
      let mut v132_11 = Space::new();
      let mut v132_11_write = v132_11.write_zipper();
      for v132_11_byte in v120_24_cursor.child_mask().iter() {
        v120_24_cursor.descend_to_existing_byte(v132_11_byte);
        {
        let v133_2: Space = singleton(&v120_24_cursor.path()[(v120_24_origin + 1)..(v120_24_origin + 2)]);
        let v133_3: Space = intersect(&(*CONSTANT_2),&(v133_2));
        let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
        drop(v133_3);
        let v133_5: Space = subtract(&(*CONSTANT_1),&(v133_4));
        drop(v133_4);
        let v133_8: Space = if (&(v133_5)).is_empty() { Space::new() } else {
          let v134_6: Path = concat_path(&(v132_6),&v120_24_cursor.path()[(v120_24_origin + 1)..(v120_24_origin + 2)]);
          let mut v134_7 = Space::new();
          let mut v134_7_write = v134_7.write_zipper();
          for v134_7_byte in v120_24_cursor.child_mask().iter() {
            v120_24_cursor.descend_to_existing_byte(v134_7_byte);
            {
            let v135_2: Space = singleton(&v120_24_cursor.path()[(v120_24_origin + 2)..(v120_24_origin + 3)]);
            let v135_3: Space = intersect(&(*CONSTANT_2),&(v135_2));
            let v135_4: Space = if has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
            drop(v135_3);
            let v135_5: Space = subtract(&(*CONSTANT_1),&(v135_4));
            drop(v135_4);
            let v135_8: Space = if (&(v135_5)).is_empty() { Space::new() } else {
              let v136_6: Path = concat_path(&(v134_6),&v120_24_cursor.path()[(v120_24_origin + 2)..(v120_24_origin + 3)]);
              let v136_7: Space = routine_15(c, &(v136_6), &v120_24_cursor, &(*s1));
              compose(&(v135_5),&(v136_7))
            };
            drop(v135_5);
            let v135_9: Space = intersect(&(*CONSTANT_2),&(v135_2));
            drop(v135_2);
            let v135_10: Space = if has_head(&(v135_9)) { singleton(&[]) } else { Space::new() };
            drop(v135_9);
            let v135_12: Space = if (&(v135_10)).is_empty() { Space::new() } else {
              let v137_6: Path = concat_path(&(v134_6),&v120_24_cursor.path()[(v120_24_origin + 2)..(v120_24_origin + 3)]);
              let v137_11: Space = routine_16(c, &(v137_6), &v120_24_cursor, &(*s1));
              drop(v137_6);
              compose(&(v135_10),&(v137_11))
            };
            drop(v135_10);
            let v135_13: Space = unite(&(v135_8),&(v135_12));
            join_wrapped_into(&mut v134_7_write,&((v135_13).read_zipper()),&[]);
            }
            v120_24_cursor.ascend(1);
          }
          drop(v134_7_write);
          compose(&(v133_5),&(v134_7))
        };
        drop(v133_5);
        let v133_9: Space = intersect(&(*CONSTANT_2),&(v133_2));
        drop(v133_2);
        let v133_10: Space = if has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
        drop(v133_9);
        let v133_12: Space = if (&(v133_10)).is_empty() { Space::new() } else {
          let v138_6: Path = concat_path(&(v132_6),&v120_24_cursor.path()[(v120_24_origin + 1)..(v120_24_origin + 2)]);
          let mut v138_11 = Space::new();
          let mut v138_11_write = v138_11.write_zipper();
          for v138_11_byte in v120_24_cursor.child_mask().iter() {
            v120_24_cursor.descend_to_existing_byte(v138_11_byte);
            {
            let v139_2: Space = singleton(&v120_24_cursor.path()[(v120_24_origin + 2)..(v120_24_origin + 3)]);
            let v139_3: Space = intersect(&(*CONSTANT_2),&(v139_2));
            let v139_4: Space = if has_head(&(v139_3)) { singleton(&[]) } else { Space::new() };
            drop(v139_3);
            let v139_5: Space = subtract(&(*CONSTANT_1),&(v139_4));
            drop(v139_4);
            let v139_7: Space = if (&(v139_5)).is_empty() { Space::new() } else {
              let v140_6: Space = routine_4(c, &v120_24_cursor.path()[(v120_24_origin + 2)..(v120_24_origin + 3)], &(v138_6), &v120_24_cursor, &(*s1));
              compose(&(v139_5),&(v140_6))
            };
            drop(v139_5);
            let v139_8: Space = intersect(&(*CONSTANT_2),&(v139_2));
            drop(v139_2);
            let v139_9: Space = if has_head(&(v139_8)) { singleton(&[]) } else { Space::new() };
            drop(v139_8);
            let v139_11: Space = if (&(v139_9)).is_empty() { Space::new() } else {
              let v141_10: Space = routine_5(c, &v120_24_cursor.path()[(v120_24_origin + 2)..(v120_24_origin + 3)], &(v138_6), &v120_24_cursor, &(*s1));
              compose(&(v139_9),&(v141_10))
            };
            drop(v139_9);
            let v139_12: Space = unite(&(v139_7),&(v139_11));
            join_wrapped_into(&mut v138_11_write,&((v139_12).read_zipper()),&[]);
            }
            v120_24_cursor.ascend(1);
          }
          drop(v138_11_write);
          drop(v138_6);
          compose(&(v133_10),&(v138_11))
        };
        drop(v133_10);
        let v133_13: Space = unite(&(v133_8),&(v133_12));
        join_wrapped_into(&mut v132_11_write,&((v133_13).read_zipper()),&[]);
        }
        v120_24_cursor.ascend(1);
      }
      drop(v132_11_write);
      drop(v132_6);
      compose(&(v121_10),&(v132_11))
    };
    drop(v121_10);
    let v121_13: Space = unite(&(v121_8),&(v121_12));
    join_wrapped_into(&mut v120_24_write,&((v121_13).read_zipper()),&[]);
    }
    v120_24_cursor.ascend(1);
  }
  drop(v120_24_cursor);
  drop(v120_24_write);
  (v120_24).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v142_24 = Space::new();
  let mut v142_24_write = v142_24.write_zipper();
  let mut v142_24_cursor = (*s0).read_zipper();
  let v142_24_origin = v142_24_cursor.path().len();
  for v142_24_byte in v142_24_cursor.child_mask().iter() {
    v142_24_cursor.descend_to_existing_byte(v142_24_byte);
    {
    let v143_2: Space = singleton(&v142_24_cursor.path()[v142_24_origin..(v142_24_origin + 1)]);
    let v143_3: Space = intersect(&(*CONSTANT_2),&(v143_2));
    let v143_4: Space = if has_head(&(v143_3)) { singleton(&[]) } else { Space::new() };
    drop(v143_3);
    let v143_5: Space = subtract(&(*CONSTANT_1),&(v143_4));
    drop(v143_4);
    let v143_8: Space = if (&(v143_5)).is_empty() { Space::new() } else {
      let v144_6: Path = concat_path(&(*p0),&v142_24_cursor.path()[v142_24_origin..(v142_24_origin + 1)]);
      let mut v144_7 = Space::new();
      let mut v144_7_write = v144_7.write_zipper();
      for v144_7_byte in v142_24_cursor.child_mask().iter() {
        v142_24_cursor.descend_to_existing_byte(v144_7_byte);
        {
        let v145_2: Space = singleton(&v142_24_cursor.path()[(v142_24_origin + 1)..(v142_24_origin + 2)]);
        let v145_3: Space = intersect(&(*CONSTANT_2),&(v145_2));
        let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
        drop(v145_3);
        let v145_5: Space = subtract(&(*CONSTANT_1),&(v145_4));
        drop(v145_4);
        let v145_8: Space = if (&(v145_5)).is_empty() { Space::new() } else {
          let v146_6: Path = concat_path(&(v144_6),&v142_24_cursor.path()[(v142_24_origin + 1)..(v142_24_origin + 2)]);
          let mut v146_7 = Space::new();
          let mut v146_7_write = v146_7.write_zipper();
          for v146_7_byte in v142_24_cursor.child_mask().iter() {
            v142_24_cursor.descend_to_existing_byte(v146_7_byte);
            {
            let v147_2: Space = singleton(&v142_24_cursor.path()[(v142_24_origin + 2)..(v142_24_origin + 3)]);
            let v147_3: Space = intersect(&(*CONSTANT_2),&(v147_2));
            let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
            drop(v147_3);
            let v147_5: Space = subtract(&(*CONSTANT_1),&(v147_4));
            drop(v147_4);
            let v147_8: Space = if (&(v147_5)).is_empty() { Space::new() } else {
              let v148_6: Path = concat_path(&(v146_6),&v142_24_cursor.path()[(v142_24_origin + 2)..(v142_24_origin + 3)]);
              let v148_7: Space = routine_15(c, &(v148_6), &v142_24_cursor, &(*s1));
              compose(&(v147_5),&(v148_7))
            };
            drop(v147_5);
            let v147_9: Space = intersect(&(*CONSTANT_2),&(v147_2));
            drop(v147_2);
            let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
            drop(v147_9);
            let v147_12: Space = if (&(v147_10)).is_empty() { Space::new() } else {
              let v149_6: Path = concat_path(&(v146_6),&v142_24_cursor.path()[(v142_24_origin + 2)..(v142_24_origin + 3)]);
              let v149_11: Space = routine_16(c, &(v149_6), &v142_24_cursor, &(*s1));
              drop(v149_6);
              compose(&(v147_10),&(v149_11))
            };
            drop(v147_10);
            let v147_13: Space = unite(&(v147_8),&(v147_12));
            join_wrapped_into(&mut v146_7_write,&((v147_13).read_zipper()),&[]);
            }
            v142_24_cursor.ascend(1);
          }
          drop(v146_7_write);
          compose(&(v145_5),&(v146_7))
        };
        drop(v145_5);
        let v145_9: Space = intersect(&(*CONSTANT_2),&(v145_2));
        drop(v145_2);
        let v145_10: Space = if has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
        drop(v145_9);
        let v145_12: Space = if (&(v145_10)).is_empty() { Space::new() } else {
          let v150_6: Path = concat_path(&(v144_6),&v142_24_cursor.path()[(v142_24_origin + 1)..(v142_24_origin + 2)]);
          let mut v150_11 = Space::new();
          let mut v150_11_write = v150_11.write_zipper();
          for v150_11_byte in v142_24_cursor.child_mask().iter() {
            v142_24_cursor.descend_to_existing_byte(v150_11_byte);
            {
            let v151_2: Space = singleton(&v142_24_cursor.path()[(v142_24_origin + 2)..(v142_24_origin + 3)]);
            let v151_3: Space = intersect(&(*CONSTANT_2),&(v151_2));
            let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
            drop(v151_3);
            let v151_5: Space = subtract(&(*CONSTANT_1),&(v151_4));
            drop(v151_4);
            let v151_8: Space = if (&(v151_5)).is_empty() { Space::new() } else {
              let v152_6: Path = concat_path(&(v150_6),&v142_24_cursor.path()[(v142_24_origin + 2)..(v142_24_origin + 3)]);
              let v152_7: Space = routine_15(c, &(v152_6), &v142_24_cursor, &(*s1));
              compose(&(v151_5),&(v152_7))
            };
            drop(v151_5);
            let v151_9: Space = intersect(&(*CONSTANT_2),&(v151_2));
            drop(v151_2);
            let v151_10: Space = if has_head(&(v151_9)) { singleton(&[]) } else { Space::new() };
            drop(v151_9);
            let v151_12: Space = if (&(v151_10)).is_empty() { Space::new() } else {
              let v153_6: Path = concat_path(&(v150_6),&v142_24_cursor.path()[(v142_24_origin + 2)..(v142_24_origin + 3)]);
              let v153_11: Space = routine_3(c, &(v153_6), &v142_24_cursor, &(*s1));
              drop(v153_6);
              compose(&(v151_10),&(v153_11))
            };
            drop(v151_10);
            let v151_13: Space = unite(&(v151_8),&(v151_12));
            join_wrapped_into(&mut v150_11_write,&((v151_13).read_zipper()),&[]);
            }
            v142_24_cursor.ascend(1);
          }
          drop(v150_11_write);
          drop(v150_6);
          compose(&(v145_10),&(v150_11))
        };
        drop(v145_10);
        let v145_13: Space = unite(&(v145_8),&(v145_12));
        join_wrapped_into(&mut v144_7_write,&((v145_13).read_zipper()),&[]);
        }
        v142_24_cursor.ascend(1);
      }
      drop(v144_7_write);
      compose(&(v143_5),&(v144_7))
    };
    drop(v143_5);
    let v143_9: Space = intersect(&(*CONSTANT_2),&(v143_2));
    drop(v143_2);
    let v143_10: Space = if has_head(&(v143_9)) { singleton(&[]) } else { Space::new() };
    drop(v143_9);
    let v143_12: Space = if (&(v143_10)).is_empty() { Space::new() } else {
      let v154_6: Path = concat_path(&(*p0),&v142_24_cursor.path()[v142_24_origin..(v142_24_origin + 1)]);
      let mut v154_11 = Space::new();
      let mut v154_11_write = v154_11.write_zipper();
      for v154_11_byte in v142_24_cursor.child_mask().iter() {
        v142_24_cursor.descend_to_existing_byte(v154_11_byte);
        {
        let v155_2: Space = singleton(&v142_24_cursor.path()[(v142_24_origin + 1)..(v142_24_origin + 2)]);
        let v155_3: Space = intersect(&(*CONSTANT_2),&(v155_2));
        let v155_4: Space = if has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
        drop(v155_3);
        let v155_5: Space = subtract(&(*CONSTANT_1),&(v155_4));
        drop(v155_4);
        let v155_7: Space = if (&(v155_5)).is_empty() { Space::new() } else {
          let mut v156_6 = Space::new();
          let mut v156_6_write = v156_6.write_zipper();
          for v156_6_byte in v142_24_cursor.child_mask().iter() {
            v142_24_cursor.descend_to_existing_byte(v156_6_byte);
            {
            let v157_2: Space = singleton(&v142_24_cursor.path()[(v142_24_origin + 2)..(v142_24_origin + 3)]);
            let v157_3: Space = intersect(&(*CONSTANT_2),&(v157_2));
            let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
            drop(v157_3);
            let v157_5: Space = subtract(&(*CONSTANT_1),&(v157_4));
            drop(v157_4);
            let v157_8: Space = if (&(v157_5)).is_empty() { Space::new() } else {
              let v158_7: Space = routine_8(c, &v142_24_cursor.path()[(v142_24_origin + 1)..(v142_24_origin + 3)], &(v154_6), &v142_24_cursor, &(*s1));
              compose(&(v157_5),&(v158_7))
            };
            drop(v157_5);
            let v157_9: Space = intersect(&(*CONSTANT_2),&(v157_2));
            drop(v157_2);
            let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
            drop(v157_9);
            let v157_12: Space = if (&(v157_10)).is_empty() { Space::new() } else {
              let v159_11: Space = routine_9(c, &v142_24_cursor.path()[(v142_24_origin + 1)..(v142_24_origin + 3)], &(v154_6), &v142_24_cursor, &(*s1));
              compose(&(v157_10),&(v159_11))
            };
            drop(v157_10);
            let v157_13: Space = unite(&(v157_8),&(v157_12));
            join_wrapped_into(&mut v156_6_write,&((v157_13).read_zipper()),&[]);
            }
            v142_24_cursor.ascend(1);
          }
          drop(v156_6_write);
          compose(&(v155_5),&(v156_6))
        };
        drop(v155_5);
        let v155_8: Space = intersect(&(*CONSTANT_2),&(v155_2));
        drop(v155_2);
        let v155_9: Space = if has_head(&(v155_8)) { singleton(&[]) } else { Space::new() };
        drop(v155_8);
        let v155_11: Space = if (&(v155_9)).is_empty() { Space::new() } else {
          let mut v160_10 = Space::new();
          let mut v160_10_write = v160_10.write_zipper();
          for v160_10_byte in v142_24_cursor.child_mask().iter() {
            v142_24_cursor.descend_to_existing_byte(v160_10_byte);
            {
            let v161_2: Space = singleton(&v142_24_cursor.path()[(v142_24_origin + 2)..(v142_24_origin + 3)]);
            let v161_3: Space = intersect(&(*CONSTANT_2),&(v161_2));
            let v161_4: Space = if has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
            drop(v161_3);
            let v161_5: Space = subtract(&(*CONSTANT_1),&(v161_4));
            drop(v161_4);
            let v161_8: Space = if (&(v161_5)).is_empty() { Space::new() } else {
              let v162_7: Space = routine_8(c, &v142_24_cursor.path()[(v142_24_origin + 1)..(v142_24_origin + 3)], &(v154_6), &v142_24_cursor, &(*s1));
              compose(&(v161_5),&(v162_7))
            };
            drop(v161_5);
            let v161_9: Space = intersect(&(*CONSTANT_2),&(v161_2));
            drop(v161_2);
            let v161_10: Space = if has_head(&(v161_9)) { singleton(&[]) } else { Space::new() };
            drop(v161_9);
            let v161_12: Space = if (&(v161_10)).is_empty() { Space::new() } else {
              let v163_11: Space = routine_10(c, &v142_24_cursor.path()[(v142_24_origin + 1)..(v142_24_origin + 3)], &(v154_6), &v142_24_cursor, &(*s1));
              compose(&(v161_10),&(v163_11))
            };
            drop(v161_10);
            let v161_13: Space = unite(&(v161_8),&(v161_12));
            join_wrapped_into(&mut v160_10_write,&((v161_13).read_zipper()),&[]);
            }
            v142_24_cursor.ascend(1);
          }
          drop(v160_10_write);
          compose(&(v155_9),&(v160_10))
        };
        drop(v155_9);
        let v155_12: Space = unite(&(v155_7),&(v155_11));
        join_wrapped_into(&mut v154_11_write,&((v155_12).read_zipper()),&[]);
        }
        v142_24_cursor.ascend(1);
      }
      drop(v154_11_write);
      drop(v154_6);
      compose(&(v143_10),&(v154_11))
    };
    drop(v143_10);
    let v143_13: Space = unite(&(v143_8),&(v143_12));
    join_wrapped_into(&mut v142_24_write,&((v143_13).read_zipper()),&[]);
    }
    v142_24_cursor.ascend(1);
  }
  drop(v142_24_cursor);
  drop(v142_24_write);
  (v142_24).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v164_25 = Space::new();
  let mut v164_25_write = v164_25.write_zipper();
  let mut v164_25_cursor = (*s0).read_zipper();
  let v164_25_origin = v164_25_cursor.path().len();
  for v164_25_byte in v164_25_cursor.child_mask().iter() {
    v164_25_cursor.descend_to_existing_byte(v164_25_byte);
    {
    let v165_2: Space = singleton(&v164_25_cursor.path()[v164_25_origin..(v164_25_origin + 1)]);
    let v165_3: Space = intersect(&(*CONSTANT_2),&(v165_2));
    let v165_4: Space = if has_head(&(v165_3)) { singleton(&[]) } else { Space::new() };
    drop(v165_3);
    let v165_5: Space = subtract(&(*CONSTANT_1),&(v165_4));
    drop(v165_4);
    let v165_8: Space = if (&(v165_5)).is_empty() { Space::new() } else {
      let v166_6: Path = concat_path(&(*p0),&v164_25_cursor.path()[v164_25_origin..(v164_25_origin + 1)]);
      let mut v166_7 = Space::new();
      let mut v166_7_write = v166_7.write_zipper();
      for v166_7_byte in v164_25_cursor.child_mask().iter() {
        v164_25_cursor.descend_to_existing_byte(v166_7_byte);
        {
        let v167_2: Space = singleton(&v164_25_cursor.path()[(v164_25_origin + 1)..(v164_25_origin + 2)]);
        let v167_3: Space = intersect(&(*CONSTANT_2),&(v167_2));
        let v167_4: Space = if has_head(&(v167_3)) { singleton(&[]) } else { Space::new() };
        drop(v167_3);
        let v167_5: Space = subtract(&(*CONSTANT_1),&(v167_4));
        drop(v167_4);
        let v167_8: Space = if (&(v167_5)).is_empty() { Space::new() } else {
          let v168_6: Path = concat_path(&(v166_6),&v164_25_cursor.path()[(v164_25_origin + 1)..(v164_25_origin + 2)]);
          let mut v168_7 = Space::new();
          let mut v168_7_write = v168_7.write_zipper();
          for v168_7_byte in v164_25_cursor.child_mask().iter() {
            v164_25_cursor.descend_to_existing_byte(v168_7_byte);
            {
            let v169_2: Space = singleton(&v164_25_cursor.path()[(v164_25_origin + 2)..(v164_25_origin + 3)]);
            let v169_3: Space = intersect(&(*CONSTANT_2),&(v169_2));
            let v169_4: Space = if has_head(&(v169_3)) { singleton(&[]) } else { Space::new() };
            drop(v169_3);
            let v169_5: Space = subtract(&(*CONSTANT_1),&(v169_4));
            drop(v169_4);
            let v169_8: Space = if (&(v169_5)).is_empty() { Space::new() } else {
              let v170_6: Path = concat_path(&(v168_6),&v164_25_cursor.path()[(v164_25_origin + 2)..(v164_25_origin + 3)]);
              let v170_7: Space = routine_17(c, &(v170_6), &(*p1), &v164_25_cursor, &(*s1));
              compose(&(v169_5),&(v170_7))
            };
            drop(v169_5);
            let v169_9: Space = intersect(&(*CONSTANT_2),&(v169_2));
            drop(v169_2);
            let v169_10: Space = if has_head(&(v169_9)) { singleton(&[]) } else { Space::new() };
            drop(v169_9);
            let v169_12: Space = if (&(v169_10)).is_empty() { Space::new() } else {
              let v171_6: Path = concat_path(&(v168_6),&v164_25_cursor.path()[(v164_25_origin + 2)..(v164_25_origin + 3)]);
              let v171_11: Space = routine_18(c, &(v171_6), &(*p1), &v164_25_cursor, &(*s1));
              drop(v171_6);
              compose(&(v169_10),&(v171_11))
            };
            drop(v169_10);
            let v169_13: Space = unite(&(v169_8),&(v169_12));
            join_wrapped_into(&mut v168_7_write,&((v169_13).read_zipper()),&[]);
            }
            v164_25_cursor.ascend(1);
          }
          drop(v168_7_write);
          compose(&(v167_5),&(v168_7))
        };
        drop(v167_5);
        let v167_9: Space = intersect(&(*CONSTANT_2),&(v167_2));
        drop(v167_2);
        let v167_10: Space = if has_head(&(v167_9)) { singleton(&[]) } else { Space::new() };
        drop(v167_9);
        let v167_12: Space = if (&(v167_10)).is_empty() { Space::new() } else {
          let v172_6: Path = concat_path(&(v166_6),&v164_25_cursor.path()[(v164_25_origin + 1)..(v164_25_origin + 2)]);
          let mut v172_11 = Space::new();
          let mut v172_11_write = v172_11.write_zipper();
          for v172_11_byte in v164_25_cursor.child_mask().iter() {
            v164_25_cursor.descend_to_existing_byte(v172_11_byte);
            {
            let v173_2: Space = singleton(&v164_25_cursor.path()[(v164_25_origin + 2)..(v164_25_origin + 3)]);
            let v173_3: Space = intersect(&(*CONSTANT_2),&(v173_2));
            let v173_4: Space = if has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
            drop(v173_3);
            let v173_5: Space = subtract(&(*CONSTANT_1),&(v173_4));
            drop(v173_4);
            let v173_8: Space = if (&(v173_5)).is_empty() { Space::new() } else {
              let v174_6: Path = concat_path(&(v172_6),&v164_25_cursor.path()[(v164_25_origin + 2)..(v164_25_origin + 3)]);
              let v174_7: Space = routine_17(c, &(v174_6), &(*p1), &v164_25_cursor, &(*s1));
              compose(&(v173_5),&(v174_7))
            };
            drop(v173_5);
            let v173_9: Space = intersect(&(*CONSTANT_2),&(v173_2));
            drop(v173_2);
            let v173_10: Space = if has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
            drop(v173_9);
            let v173_12: Space = if (&(v173_10)).is_empty() { Space::new() } else {
              let v175_6: Path = concat_path(&(v172_6),&v164_25_cursor.path()[(v164_25_origin + 2)..(v164_25_origin + 3)]);
              let v175_11: Space = routine_10(c, &(v175_6), &(*p1), &v164_25_cursor, &(*s1));
              drop(v175_6);
              compose(&(v173_10),&(v175_11))
            };
            drop(v173_10);
            let v173_13: Space = unite(&(v173_8),&(v173_12));
            join_wrapped_into(&mut v172_11_write,&((v173_13).read_zipper()),&[]);
            }
            v164_25_cursor.ascend(1);
          }
          drop(v172_11_write);
          drop(v172_6);
          compose(&(v167_10),&(v172_11))
        };
        drop(v167_10);
        let v167_13: Space = unite(&(v167_8),&(v167_12));
        join_wrapped_into(&mut v166_7_write,&((v167_13).read_zipper()),&[]);
        }
        v164_25_cursor.ascend(1);
      }
      drop(v166_7_write);
      compose(&(v165_5),&(v166_7))
    };
    drop(v165_5);
    let v165_9: Space = intersect(&(*CONSTANT_2),&(v165_2));
    drop(v165_2);
    let v165_10: Space = if has_head(&(v165_9)) { singleton(&[]) } else { Space::new() };
    drop(v165_9);
    let v165_13: Space = if (&(v165_10)).is_empty() { Space::new() } else {
      let v176_6: Path = concat_path(&(*p0),&v164_25_cursor.path()[v164_25_origin..(v164_25_origin + 1)]);
      let mut v176_12 = Space::new();
      let mut v176_12_write = v176_12.write_zipper();
      for v176_12_byte in v164_25_cursor.child_mask().iter() {
        v164_25_cursor.descend_to_existing_byte(v176_12_byte);
        {
        let v177_2: Space = singleton(&v164_25_cursor.path()[(v164_25_origin + 1)..(v164_25_origin + 2)]);
        let v177_3: Space = intersect(&(*CONSTANT_2),&(v177_2));
        let v177_4: Space = if has_head(&(v177_3)) { singleton(&[]) } else { Space::new() };
        drop(v177_3);
        let v177_5: Space = subtract(&(*CONSTANT_1),&(v177_4));
        drop(v177_4);
        let v177_8: Space = if (&(v177_5)).is_empty() { Space::new() } else {
          let v178_6: Path = concat_path(&(v176_6),&v164_25_cursor.path()[(v164_25_origin + 1)..(v164_25_origin + 2)]);
          let mut v178_7 = Space::new();
          let mut v178_7_write = v178_7.write_zipper();
          for v178_7_byte in v164_25_cursor.child_mask().iter() {
            v164_25_cursor.descend_to_existing_byte(v178_7_byte);
            {
            let v179_2: Space = singleton(&v164_25_cursor.path()[(v164_25_origin + 2)..(v164_25_origin + 3)]);
            let v179_3: Space = intersect(&(*CONSTANT_2),&(v179_2));
            let v179_4: Space = if has_head(&(v179_3)) { singleton(&[]) } else { Space::new() };
            drop(v179_3);
            let v179_5: Space = subtract(&(*CONSTANT_1),&(v179_4));
            drop(v179_4);
            let v179_8: Space = if (&(v179_5)).is_empty() { Space::new() } else {
              let v180_6: Path = concat_path(&(v178_6),&v164_25_cursor.path()[(v164_25_origin + 2)..(v164_25_origin + 3)]);
              let v180_7: Space = routine_17(c, &(v180_6), &(*p1), &v164_25_cursor, &(*s1));
              compose(&(v179_5),&(v180_7))
            };
            drop(v179_5);
            let v179_9: Space = intersect(&(*CONSTANT_2),&(v179_2));
            drop(v179_2);
            let v179_10: Space = if has_head(&(v179_9)) { singleton(&[]) } else { Space::new() };
            drop(v179_9);
            let v179_12: Space = if (&(v179_10)).is_empty() { Space::new() } else {
              let v181_6: Path = concat_path(&(v178_6),&v164_25_cursor.path()[(v164_25_origin + 2)..(v164_25_origin + 3)]);
              let v181_11: Space = routine_18(c, &(v181_6), &(*p1), &v164_25_cursor, &(*s1));
              drop(v181_6);
              compose(&(v179_10),&(v181_11))
            };
            drop(v179_10);
            let v179_13: Space = unite(&(v179_8),&(v179_12));
            join_wrapped_into(&mut v178_7_write,&((v179_13).read_zipper()),&[]);
            }
            v164_25_cursor.ascend(1);
          }
          drop(v178_7_write);
          compose(&(v177_5),&(v178_7))
        };
        drop(v177_5);
        let v177_9: Space = intersect(&(*CONSTANT_2),&(v177_2));
        drop(v177_2);
        let v177_10: Space = if has_head(&(v177_9)) { singleton(&[]) } else { Space::new() };
        drop(v177_9);
        let v177_13: Space = if (&(v177_10)).is_empty() { Space::new() } else {
          compose(&(v177_10),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v164_25_cursor.path()[v164_25_origin..(v164_25_origin + 1)]),&v164_25_cursor.path()[(v164_25_origin + 1)..(v164_25_origin + 2)]),&(*p1))))
        };
        drop(v177_10);
        let v183_6: Path = concat_path(&(v176_6),&v164_25_cursor.path()[(v164_25_origin + 1)..(v164_25_origin + 2)]);
        let v177_14: Space = wrap(&(v177_13),&(v183_6));
        drop(v177_13);
        let v177_15: Space = wrap(&(v177_14),&(*p1));
        drop(v177_14);
        let v177_16: Space = unite(&(v177_8),&(v177_15));
        drop(v177_15);
        join_wrapped_into(&mut v176_12_write,&((v177_16).read_zipper()),&[]);
        }
        v164_25_cursor.ascend(1);
      }
      drop(v176_12_write);
      drop(v176_6);
      compose(&(v165_10),&(v176_12))
    };
    drop(v165_10);
    let v165_14: Space = unite(&(v165_8),&(v165_13));
    join_wrapped_into(&mut v164_25_write,&((v165_14).read_zipper()),&[]);
    }
    v164_25_cursor.ascend(1);
  }
  drop(v164_25_cursor);
  drop(v164_25_write);
  (v164_25).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v184_19 = Space::new();
  let mut v184_19_write = v184_19.write_zipper();
  let mut v184_19_cursor = (*s0).read_zipper();
  let v184_19_origin = v184_19_cursor.path().len();
  for v184_19_byte in v184_19_cursor.child_mask().iter() {
    v184_19_cursor.descend_to_existing_byte(v184_19_byte);
    {
    let v185_2: Space = singleton(&v184_19_cursor.path()[v184_19_origin..(v184_19_origin + 1)]);
    let v185_3: Space = intersect(&(*CONSTANT_2),&(v185_2));
    let v185_4: Space = if has_head(&(v185_3)) { singleton(&[]) } else { Space::new() };
    drop(v185_3);
    let v185_5: Space = subtract(&(*CONSTANT_1),&(v185_4));
    drop(v185_4);
    let v185_8: Space = if (&(v185_5)).is_empty() { Space::new() } else {
      let v186_6: Path = concat_path(&(*p0),&v184_19_cursor.path()[v184_19_origin..(v184_19_origin + 1)]);
      let mut v186_7 = Space::new();
      let mut v186_7_write = v186_7.write_zipper();
      for v186_7_byte in v184_19_cursor.child_mask().iter() {
        v184_19_cursor.descend_to_existing_byte(v186_7_byte);
        {
        let v187_2: Space = singleton(&v184_19_cursor.path()[(v184_19_origin + 1)..(v184_19_origin + 2)]);
        let v187_3: Space = intersect(&(*CONSTANT_2),&(v187_2));
        let v187_4: Space = if has_head(&(v187_3)) { singleton(&[]) } else { Space::new() };
        drop(v187_3);
        let v187_5: Space = subtract(&(*CONSTANT_1),&(v187_4));
        drop(v187_4);
        let v187_8: Space = if (&(v187_5)).is_empty() { Space::new() } else {
          let v188_6: Path = concat_path(&(v186_6),&v184_19_cursor.path()[(v184_19_origin + 1)..(v184_19_origin + 2)]);
          let mut v188_7 = Space::new();
          let mut v188_7_write = v188_7.write_zipper();
          for v188_7_byte in v184_19_cursor.child_mask().iter() {
            v184_19_cursor.descend_to_existing_byte(v188_7_byte);
            {
            let v189_2: Space = singleton(&v184_19_cursor.path()[(v184_19_origin + 2)..(v184_19_origin + 3)]);
            let v189_3: Space = intersect(&(*CONSTANT_2),&(v189_2));
            let v189_4: Space = if has_head(&(v189_3)) { singleton(&[]) } else { Space::new() };
            drop(v189_3);
            let v189_5: Space = subtract(&(*CONSTANT_1),&(v189_4));
            drop(v189_4);
            let v189_8: Space = if (&(v189_5)).is_empty() { Space::new() } else {
              let v190_6: Path = concat_path(&(v188_6),&v184_19_cursor.path()[(v184_19_origin + 2)..(v184_19_origin + 3)]);
              let v190_7: Space = routine_17(c, &(v190_6), &(*p1), &v184_19_cursor, &(*s1));
              compose(&(v189_5),&(v190_7))
            };
            drop(v189_5);
            let v189_9: Space = intersect(&(*CONSTANT_2),&(v189_2));
            drop(v189_2);
            let v189_10: Space = if has_head(&(v189_9)) { singleton(&[]) } else { Space::new() };
            drop(v189_9);
            let v189_12: Space = if (&(v189_10)).is_empty() { Space::new() } else {
              let v191_6: Path = concat_path(&(v188_6),&v184_19_cursor.path()[(v184_19_origin + 2)..(v184_19_origin + 3)]);
              let v191_11: Space = routine_18(c, &(v191_6), &(*p1), &v184_19_cursor, &(*s1));
              drop(v191_6);
              compose(&(v189_10),&(v191_11))
            };
            drop(v189_10);
            let v189_13: Space = unite(&(v189_8),&(v189_12));
            join_wrapped_into(&mut v188_7_write,&((v189_13).read_zipper()),&[]);
            }
            v184_19_cursor.ascend(1);
          }
          drop(v188_7_write);
          compose(&(v187_5),&(v188_7))
        };
        drop(v187_5);
        let v187_9: Space = intersect(&(*CONSTANT_2),&(v187_2));
        drop(v187_2);
        let v187_10: Space = if has_head(&(v187_9)) { singleton(&[]) } else { Space::new() };
        drop(v187_9);
        let v187_12: Space = if (&(v187_10)).is_empty() { Space::new() } else {
          let v192_6: Path = concat_path(&(v186_6),&v184_19_cursor.path()[(v184_19_origin + 1)..(v184_19_origin + 2)]);
          let mut v192_11 = Space::new();
          let mut v192_11_write = v192_11.write_zipper();
          for v192_11_byte in v184_19_cursor.child_mask().iter() {
            v184_19_cursor.descend_to_existing_byte(v192_11_byte);
            {
            let v193_2: Space = singleton(&v184_19_cursor.path()[(v184_19_origin + 2)..(v184_19_origin + 3)]);
            let v193_3: Space = intersect(&(*CONSTANT_2),&(v193_2));
            let v193_4: Space = if has_head(&(v193_3)) { singleton(&[]) } else { Space::new() };
            drop(v193_3);
            let v193_5: Space = subtract(&(*CONSTANT_1),&(v193_4));
            drop(v193_4);
            let v193_8: Space = if (&(v193_5)).is_empty() { Space::new() } else {
              let v194_6: Path = concat_path(&(v192_6),&v184_19_cursor.path()[(v184_19_origin + 2)..(v184_19_origin + 3)]);
              let v194_7: Space = routine_17(c, &(v194_6), &(*p1), &v184_19_cursor, &(*s1));
              compose(&(v193_5),&(v194_7))
            };
            drop(v193_5);
            let v193_9: Space = intersect(&(*CONSTANT_2),&(v193_2));
            drop(v193_2);
            let v193_10: Space = if has_head(&(v193_9)) { singleton(&[]) } else { Space::new() };
            drop(v193_9);
            let v193_12: Space = if (&(v193_10)).is_empty() { Space::new() } else {
              let v195_6: Path = concat_path(&(v192_6),&v184_19_cursor.path()[(v184_19_origin + 2)..(v184_19_origin + 3)]);
              let v195_11: Space = routine_10(c, &(v195_6), &(*p1), &v184_19_cursor, &(*s1));
              drop(v195_6);
              compose(&(v193_10),&(v195_11))
            };
            drop(v193_10);
            let v193_13: Space = unite(&(v193_8),&(v193_12));
            join_wrapped_into(&mut v192_11_write,&((v193_13).read_zipper()),&[]);
            }
            v184_19_cursor.ascend(1);
          }
          drop(v192_11_write);
          drop(v192_6);
          compose(&(v187_10),&(v192_11))
        };
        drop(v187_10);
        let v187_13: Space = unite(&(v187_8),&(v187_12));
        join_wrapped_into(&mut v186_7_write,&((v187_13).read_zipper()),&[]);
        }
        v184_19_cursor.ascend(1);
      }
      drop(v186_7_write);
      compose(&(v185_5),&(v186_7))
    };
    drop(v185_5);
    let v185_9: Space = intersect(&(*CONSTANT_2),&(v185_2));
    drop(v185_2);
    let v185_10: Space = if has_head(&(v185_9)) { singleton(&[]) } else { Space::new() };
    drop(v185_9);
    let v185_13: Space = if (&(v185_10)).is_empty() { Space::new() } else {
      compose(&(v185_10),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v184_19_cursor.path()[v184_19_origin..(v184_19_origin + 1)]),&(*p1))))
    };
    drop(v185_10);
    let v197_6: Path = concat_path(&(*p0),&v184_19_cursor.path()[v184_19_origin..(v184_19_origin + 1)]);
    let v185_14: Space = wrap(&(v185_13),&(v197_6));
    drop(v185_13);
    let v185_15: Space = wrap(&(v185_14),&(*p1));
    drop(v185_14);
    let v185_16: Space = unite(&(v185_8),&(v185_15));
    drop(v185_15);
    join_wrapped_into(&mut v184_19_write,&((v185_16).read_zipper()),&[]);
    }
    v184_19_cursor.ascend(1);
  }
  drop(v184_19_cursor);
  drop(v184_19_write);
  (v184_19).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v198_8: Space = wrap(&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&(*p1))),&(*p0));
  let v198_9: Space = wrap(&(v198_8),&(*p1));
  drop(v198_8);
  (v198_9).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v199_25 = Space::new();
  let mut v199_25_write = v199_25.write_zipper();
  let mut v199_25_cursor = (*s0).read_zipper();
  let v199_25_origin = v199_25_cursor.path().len();
  for v199_25_byte in v199_25_cursor.child_mask().iter() {
    v199_25_cursor.descend_to_existing_byte(v199_25_byte);
    {
    let v200_2: Space = singleton(&v199_25_cursor.path()[v199_25_origin..(v199_25_origin + 1)]);
    let v200_3: Space = intersect(&(*CONSTANT_2),&(v200_2));
    let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
    drop(v200_3);
    let v200_5: Space = subtract(&(*CONSTANT_1),&(v200_4));
    drop(v200_4);
    let v200_8: Space = if (&(v200_5)).is_empty() { Space::new() } else {
      let v201_6: Path = concat_path(&(*p0),&v199_25_cursor.path()[v199_25_origin..(v199_25_origin + 1)]);
      let mut v201_7 = Space::new();
      let mut v201_7_write = v201_7.write_zipper();
      for v201_7_byte in v199_25_cursor.child_mask().iter() {
        v199_25_cursor.descend_to_existing_byte(v201_7_byte);
        {
        let v202_2: Space = singleton(&v199_25_cursor.path()[(v199_25_origin + 1)..(v199_25_origin + 2)]);
        let v202_3: Space = intersect(&(*CONSTANT_2),&(v202_2));
        let v202_4: Space = if has_head(&(v202_3)) { singleton(&[]) } else { Space::new() };
        drop(v202_3);
        let v202_5: Space = subtract(&(*CONSTANT_1),&(v202_4));
        drop(v202_4);
        let v202_8: Space = if (&(v202_5)).is_empty() { Space::new() } else {
          let v203_6: Path = concat_path(&(v201_6),&v199_25_cursor.path()[(v199_25_origin + 1)..(v199_25_origin + 2)]);
          let mut v203_7 = Space::new();
          let mut v203_7_write = v203_7.write_zipper();
          for v203_7_byte in v199_25_cursor.child_mask().iter() {
            v199_25_cursor.descend_to_existing_byte(v203_7_byte);
            {
            let v204_2: Space = singleton(&v199_25_cursor.path()[(v199_25_origin + 2)..(v199_25_origin + 3)]);
            let v204_3: Space = intersect(&(*CONSTANT_2),&(v204_2));
            let v204_4: Space = if has_head(&(v204_3)) { singleton(&[]) } else { Space::new() };
            drop(v204_3);
            let v204_5: Space = subtract(&(*CONSTANT_1),&(v204_4));
            drop(v204_4);
            let v204_8: Space = if (&(v204_5)).is_empty() { Space::new() } else {
              let v205_6: Path = concat_path(&(v203_6),&v199_25_cursor.path()[(v199_25_origin + 2)..(v199_25_origin + 3)]);
              let v205_7: Space = routine_19(c, &(v205_6), &(*p1), &v199_25_cursor, &(*s1));
              compose(&(v204_5),&(v205_7))
            };
            drop(v204_5);
            let v204_9: Space = intersect(&(*CONSTANT_2),&(v204_2));
            drop(v204_2);
            let v204_10: Space = if has_head(&(v204_9)) { singleton(&[]) } else { Space::new() };
            drop(v204_9);
            let v204_12: Space = if (&(v204_10)).is_empty() { Space::new() } else {
              let v206_6: Path = concat_path(&(v203_6),&v199_25_cursor.path()[(v199_25_origin + 2)..(v199_25_origin + 3)]);
              let v206_11: Space = routine_20(c, &(v206_6), &(*p1), &v199_25_cursor, &(*s1));
              drop(v206_6);
              compose(&(v204_10),&(v206_11))
            };
            drop(v204_10);
            let v204_13: Space = unite(&(v204_8),&(v204_12));
            join_wrapped_into(&mut v203_7_write,&((v204_13).read_zipper()),&[]);
            }
            v199_25_cursor.ascend(1);
          }
          drop(v203_7_write);
          compose(&(v202_5),&(v203_7))
        };
        drop(v202_5);
        let v202_9: Space = intersect(&(*CONSTANT_2),&(v202_2));
        drop(v202_2);
        let v202_10: Space = if has_head(&(v202_9)) { singleton(&[]) } else { Space::new() };
        drop(v202_9);
        let v202_12: Space = if (&(v202_10)).is_empty() { Space::new() } else {
          let v207_6: Path = concat_path(&(v201_6),&v199_25_cursor.path()[(v199_25_origin + 1)..(v199_25_origin + 2)]);
          let mut v207_11 = Space::new();
          let mut v207_11_write = v207_11.write_zipper();
          for v207_11_byte in v199_25_cursor.child_mask().iter() {
            v199_25_cursor.descend_to_existing_byte(v207_11_byte);
            {
            let v208_2: Space = singleton(&v199_25_cursor.path()[(v199_25_origin + 2)..(v199_25_origin + 3)]);
            let v208_3: Space = intersect(&(*CONSTANT_2),&(v208_2));
            let v208_4: Space = if has_head(&(v208_3)) { singleton(&[]) } else { Space::new() };
            drop(v208_3);
            let v208_5: Space = subtract(&(*CONSTANT_1),&(v208_4));
            drop(v208_4);
            let v208_8: Space = if (&(v208_5)).is_empty() { Space::new() } else {
              let v209_6: Path = concat_path(&(v207_6),&v199_25_cursor.path()[(v199_25_origin + 2)..(v199_25_origin + 3)]);
              let v209_7: Space = routine_19(c, &(v209_6), &(*p1), &v199_25_cursor, &(*s1));
              compose(&(v208_5),&(v209_7))
            };
            drop(v208_5);
            let v208_9: Space = intersect(&(*CONSTANT_2),&(v208_2));
            drop(v208_2);
            let v208_10: Space = if has_head(&(v208_9)) { singleton(&[]) } else { Space::new() };
            drop(v208_9);
            let v208_12: Space = if (&(v208_10)).is_empty() { Space::new() } else {
              let v210_6: Path = concat_path(&(v207_6),&v199_25_cursor.path()[(v199_25_origin + 2)..(v199_25_origin + 3)]);
              let v210_11: Space = routine_10(c, &(v210_6), &(*p1), &v199_25_cursor, &(*s1));
              drop(v210_6);
              compose(&(v208_10),&(v210_11))
            };
            drop(v208_10);
            let v208_13: Space = unite(&(v208_8),&(v208_12));
            join_wrapped_into(&mut v207_11_write,&((v208_13).read_zipper()),&[]);
            }
            v199_25_cursor.ascend(1);
          }
          drop(v207_11_write);
          drop(v207_6);
          compose(&(v202_10),&(v207_11))
        };
        drop(v202_10);
        let v202_13: Space = unite(&(v202_8),&(v202_12));
        join_wrapped_into(&mut v201_7_write,&((v202_13).read_zipper()),&[]);
        }
        v199_25_cursor.ascend(1);
      }
      drop(v201_7_write);
      compose(&(v200_5),&(v201_7))
    };
    drop(v200_5);
    let v200_9: Space = intersect(&(*CONSTANT_2),&(v200_2));
    drop(v200_2);
    let v200_10: Space = if has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
    drop(v200_9);
    let v200_13: Space = if (&(v200_10)).is_empty() { Space::new() } else {
      let v211_6: Path = concat_path(&(*p0),&v199_25_cursor.path()[v199_25_origin..(v199_25_origin + 1)]);
      let mut v211_12 = Space::new();
      let mut v211_12_write = v211_12.write_zipper();
      for v211_12_byte in v199_25_cursor.child_mask().iter() {
        v199_25_cursor.descend_to_existing_byte(v211_12_byte);
        {
        let v212_2: Space = singleton(&v199_25_cursor.path()[(v199_25_origin + 1)..(v199_25_origin + 2)]);
        let v212_3: Space = intersect(&(*CONSTANT_2),&(v212_2));
        let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
        drop(v212_3);
        let v212_5: Space = subtract(&(*CONSTANT_1),&(v212_4));
        drop(v212_4);
        let v212_8: Space = if (&(v212_5)).is_empty() { Space::new() } else {
          let v213_6: Path = concat_path(&(v211_6),&v199_25_cursor.path()[(v199_25_origin + 1)..(v199_25_origin + 2)]);
          let mut v213_7 = Space::new();
          let mut v213_7_write = v213_7.write_zipper();
          for v213_7_byte in v199_25_cursor.child_mask().iter() {
            v199_25_cursor.descend_to_existing_byte(v213_7_byte);
            {
            let v214_2: Space = singleton(&v199_25_cursor.path()[(v199_25_origin + 2)..(v199_25_origin + 3)]);
            let v214_3: Space = intersect(&(*CONSTANT_2),&(v214_2));
            let v214_4: Space = if has_head(&(v214_3)) { singleton(&[]) } else { Space::new() };
            drop(v214_3);
            let v214_5: Space = subtract(&(*CONSTANT_1),&(v214_4));
            drop(v214_4);
            let v214_8: Space = if (&(v214_5)).is_empty() { Space::new() } else {
              let v215_6: Path = concat_path(&(v213_6),&v199_25_cursor.path()[(v199_25_origin + 2)..(v199_25_origin + 3)]);
              let v215_7: Space = routine_19(c, &(v215_6), &(*p1), &v199_25_cursor, &(*s1));
              compose(&(v214_5),&(v215_7))
            };
            drop(v214_5);
            let v214_9: Space = intersect(&(*CONSTANT_2),&(v214_2));
            drop(v214_2);
            let v214_10: Space = if has_head(&(v214_9)) { singleton(&[]) } else { Space::new() };
            drop(v214_9);
            let v214_12: Space = if (&(v214_10)).is_empty() { Space::new() } else {
              let v216_6: Path = concat_path(&(v213_6),&v199_25_cursor.path()[(v199_25_origin + 2)..(v199_25_origin + 3)]);
              let v216_11: Space = routine_20(c, &(v216_6), &(*p1), &v199_25_cursor, &(*s1));
              drop(v216_6);
              compose(&(v214_10),&(v216_11))
            };
            drop(v214_10);
            let v214_13: Space = unite(&(v214_8),&(v214_12));
            join_wrapped_into(&mut v213_7_write,&((v214_13).read_zipper()),&[]);
            }
            v199_25_cursor.ascend(1);
          }
          drop(v213_7_write);
          compose(&(v212_5),&(v213_7))
        };
        drop(v212_5);
        let v212_9: Space = intersect(&(*CONSTANT_2),&(v212_2));
        drop(v212_2);
        let v212_10: Space = if has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
        drop(v212_9);
        let v212_13: Space = if (&(v212_10)).is_empty() { Space::new() } else {
          compose(&(v212_10),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v199_25_cursor.path()[v199_25_origin..(v199_25_origin + 1)]),&v199_25_cursor.path()[(v199_25_origin + 1)..(v199_25_origin + 2)]),&(*p1))))
        };
        drop(v212_10);
        let v218_6: Path = concat_path(&(v211_6),&v199_25_cursor.path()[(v199_25_origin + 1)..(v199_25_origin + 2)]);
        let v212_14: Space = wrap(&(v212_13),&(v218_6));
        drop(v212_13);
        let v212_15: Space = wrap(&(v212_14),&(*p1));
        drop(v212_14);
        let v212_16: Space = unite(&(v212_8),&(v212_15));
        drop(v212_15);
        join_wrapped_into(&mut v211_12_write,&((v212_16).read_zipper()),&[]);
        }
        v199_25_cursor.ascend(1);
      }
      drop(v211_12_write);
      drop(v211_6);
      compose(&(v200_10),&(v211_12))
    };
    drop(v200_10);
    let v200_14: Space = unite(&(v200_8),&(v200_13));
    join_wrapped_into(&mut v199_25_write,&((v200_14).read_zipper()),&[]);
    }
    v199_25_cursor.ascend(1);
  }
  drop(v199_25_cursor);
  drop(v199_25_write);
  (v199_25).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v219_19 = Space::new();
  let mut v219_19_write = v219_19.write_zipper();
  let mut v219_19_cursor = (*s0).read_zipper();
  let v219_19_origin = v219_19_cursor.path().len();
  for v219_19_byte in v219_19_cursor.child_mask().iter() {
    v219_19_cursor.descend_to_existing_byte(v219_19_byte);
    {
    let v220_2: Space = singleton(&v219_19_cursor.path()[v219_19_origin..(v219_19_origin + 1)]);
    let v220_3: Space = intersect(&(*CONSTANT_2),&(v220_2));
    let v220_4: Space = if has_head(&(v220_3)) { singleton(&[]) } else { Space::new() };
    drop(v220_3);
    let v220_5: Space = subtract(&(*CONSTANT_1),&(v220_4));
    drop(v220_4);
    let v220_8: Space = if (&(v220_5)).is_empty() { Space::new() } else {
      let v221_6: Path = concat_path(&(*p0),&v219_19_cursor.path()[v219_19_origin..(v219_19_origin + 1)]);
      let mut v221_7 = Space::new();
      let mut v221_7_write = v221_7.write_zipper();
      for v221_7_byte in v219_19_cursor.child_mask().iter() {
        v219_19_cursor.descend_to_existing_byte(v221_7_byte);
        {
        let v222_2: Space = singleton(&v219_19_cursor.path()[(v219_19_origin + 1)..(v219_19_origin + 2)]);
        let v222_3: Space = intersect(&(*CONSTANT_2),&(v222_2));
        let v222_4: Space = if has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
        drop(v222_3);
        let v222_5: Space = subtract(&(*CONSTANT_1),&(v222_4));
        drop(v222_4);
        let v222_8: Space = if (&(v222_5)).is_empty() { Space::new() } else {
          let v223_6: Path = concat_path(&(v221_6),&v219_19_cursor.path()[(v219_19_origin + 1)..(v219_19_origin + 2)]);
          let mut v223_7 = Space::new();
          let mut v223_7_write = v223_7.write_zipper();
          for v223_7_byte in v219_19_cursor.child_mask().iter() {
            v219_19_cursor.descend_to_existing_byte(v223_7_byte);
            {
            let v224_2: Space = singleton(&v219_19_cursor.path()[(v219_19_origin + 2)..(v219_19_origin + 3)]);
            let v224_3: Space = intersect(&(*CONSTANT_2),&(v224_2));
            let v224_4: Space = if has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
            drop(v224_3);
            let v224_5: Space = subtract(&(*CONSTANT_1),&(v224_4));
            drop(v224_4);
            let v224_8: Space = if (&(v224_5)).is_empty() { Space::new() } else {
              let v225_6: Path = concat_path(&(v223_6),&v219_19_cursor.path()[(v219_19_origin + 2)..(v219_19_origin + 3)]);
              let v225_7: Space = routine_19(c, &(v225_6), &(*p1), &v219_19_cursor, &(*s1));
              compose(&(v224_5),&(v225_7))
            };
            drop(v224_5);
            let v224_9: Space = intersect(&(*CONSTANT_2),&(v224_2));
            drop(v224_2);
            let v224_10: Space = if has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
            drop(v224_9);
            let v224_12: Space = if (&(v224_10)).is_empty() { Space::new() } else {
              let v226_6: Path = concat_path(&(v223_6),&v219_19_cursor.path()[(v219_19_origin + 2)..(v219_19_origin + 3)]);
              let v226_11: Space = routine_20(c, &(v226_6), &(*p1), &v219_19_cursor, &(*s1));
              drop(v226_6);
              compose(&(v224_10),&(v226_11))
            };
            drop(v224_10);
            let v224_13: Space = unite(&(v224_8),&(v224_12));
            join_wrapped_into(&mut v223_7_write,&((v224_13).read_zipper()),&[]);
            }
            v219_19_cursor.ascend(1);
          }
          drop(v223_7_write);
          compose(&(v222_5),&(v223_7))
        };
        drop(v222_5);
        let v222_9: Space = intersect(&(*CONSTANT_2),&(v222_2));
        drop(v222_2);
        let v222_10: Space = if has_head(&(v222_9)) { singleton(&[]) } else { Space::new() };
        drop(v222_9);
        let v222_12: Space = if (&(v222_10)).is_empty() { Space::new() } else {
          let v227_6: Path = concat_path(&(v221_6),&v219_19_cursor.path()[(v219_19_origin + 1)..(v219_19_origin + 2)]);
          let mut v227_11 = Space::new();
          let mut v227_11_write = v227_11.write_zipper();
          for v227_11_byte in v219_19_cursor.child_mask().iter() {
            v219_19_cursor.descend_to_existing_byte(v227_11_byte);
            {
            let v228_2: Space = singleton(&v219_19_cursor.path()[(v219_19_origin + 2)..(v219_19_origin + 3)]);
            let v228_3: Space = intersect(&(*CONSTANT_2),&(v228_2));
            let v228_4: Space = if has_head(&(v228_3)) { singleton(&[]) } else { Space::new() };
            drop(v228_3);
            let v228_5: Space = subtract(&(*CONSTANT_1),&(v228_4));
            drop(v228_4);
            let v228_8: Space = if (&(v228_5)).is_empty() { Space::new() } else {
              let v229_6: Path = concat_path(&(v227_6),&v219_19_cursor.path()[(v219_19_origin + 2)..(v219_19_origin + 3)]);
              let v229_7: Space = routine_19(c, &(v229_6), &(*p1), &v219_19_cursor, &(*s1));
              compose(&(v228_5),&(v229_7))
            };
            drop(v228_5);
            let v228_9: Space = intersect(&(*CONSTANT_2),&(v228_2));
            drop(v228_2);
            let v228_10: Space = if has_head(&(v228_9)) { singleton(&[]) } else { Space::new() };
            drop(v228_9);
            let v228_12: Space = if (&(v228_10)).is_empty() { Space::new() } else {
              let v230_6: Path = concat_path(&(v227_6),&v219_19_cursor.path()[(v219_19_origin + 2)..(v219_19_origin + 3)]);
              let v230_11: Space = routine_10(c, &(v230_6), &(*p1), &v219_19_cursor, &(*s1));
              drop(v230_6);
              compose(&(v228_10),&(v230_11))
            };
            drop(v228_10);
            let v228_13: Space = unite(&(v228_8),&(v228_12));
            join_wrapped_into(&mut v227_11_write,&((v228_13).read_zipper()),&[]);
            }
            v219_19_cursor.ascend(1);
          }
          drop(v227_11_write);
          drop(v227_6);
          compose(&(v222_10),&(v227_11))
        };
        drop(v222_10);
        let v222_13: Space = unite(&(v222_8),&(v222_12));
        join_wrapped_into(&mut v221_7_write,&((v222_13).read_zipper()),&[]);
        }
        v219_19_cursor.ascend(1);
      }
      drop(v221_7_write);
      compose(&(v220_5),&(v221_7))
    };
    drop(v220_5);
    let v220_9: Space = intersect(&(*CONSTANT_2),&(v220_2));
    drop(v220_2);
    let v220_10: Space = if has_head(&(v220_9)) { singleton(&[]) } else { Space::new() };
    drop(v220_9);
    let v220_13: Space = if (&(v220_10)).is_empty() { Space::new() } else {
      compose(&(v220_10),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v219_19_cursor.path()[v219_19_origin..(v219_19_origin + 1)]),&(*p1))))
    };
    drop(v220_10);
    let v232_6: Path = concat_path(&(*p0),&v219_19_cursor.path()[v219_19_origin..(v219_19_origin + 1)]);
    let v220_14: Space = wrap(&(v220_13),&(v232_6));
    drop(v220_13);
    let v220_15: Space = wrap(&(v220_14),&(*p1));
    drop(v220_14);
    let v220_16: Space = unite(&(v220_8),&(v220_15));
    drop(v220_15);
    join_wrapped_into(&mut v219_19_write,&((v220_16).read_zipper()),&[]);
    }
    v219_19_cursor.ascend(1);
  }
  drop(v219_19_cursor);
  drop(v219_19_write);
  (v219_19).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v233_25 = Space::new();
  let mut v233_25_write = v233_25.write_zipper();
  let mut v233_25_cursor = (*s0).read_zipper();
  let v233_25_origin = v233_25_cursor.path().len();
  for v233_25_byte in v233_25_cursor.child_mask().iter() {
    v233_25_cursor.descend_to_existing_byte(v233_25_byte);
    {
    let v234_2: Space = singleton(&v233_25_cursor.path()[v233_25_origin..(v233_25_origin + 1)]);
    let v234_3: Space = intersect(&(*CONSTANT_2),&(v234_2));
    let v234_4: Space = if has_head(&(v234_3)) { singleton(&[]) } else { Space::new() };
    drop(v234_3);
    let v234_5: Space = subtract(&(*CONSTANT_1),&(v234_4));
    drop(v234_4);
    let v234_8: Space = if (&(v234_5)).is_empty() { Space::new() } else {
      let v235_6: Path = concat_path(&(*p0),&v233_25_cursor.path()[v233_25_origin..(v233_25_origin + 1)]);
      let mut v235_7 = Space::new();
      let mut v235_7_write = v235_7.write_zipper();
      for v235_7_byte in v233_25_cursor.child_mask().iter() {
        v233_25_cursor.descend_to_existing_byte(v235_7_byte);
        {
        let v236_2: Space = singleton(&v233_25_cursor.path()[(v233_25_origin + 1)..(v233_25_origin + 2)]);
        let v236_3: Space = intersect(&(*CONSTANT_2),&(v236_2));
        let v236_4: Space = if has_head(&(v236_3)) { singleton(&[]) } else { Space::new() };
        drop(v236_3);
        let v236_5: Space = subtract(&(*CONSTANT_1),&(v236_4));
        drop(v236_4);
        let v236_8: Space = if (&(v236_5)).is_empty() { Space::new() } else {
          let v237_6: Path = concat_path(&(v235_6),&v233_25_cursor.path()[(v233_25_origin + 1)..(v233_25_origin + 2)]);
          let mut v237_7 = Space::new();
          let mut v237_7_write = v237_7.write_zipper();
          for v237_7_byte in v233_25_cursor.child_mask().iter() {
            v233_25_cursor.descend_to_existing_byte(v237_7_byte);
            {
            let v238_2: Space = singleton(&v233_25_cursor.path()[(v233_25_origin + 2)..(v233_25_origin + 3)]);
            let v238_3: Space = intersect(&(*CONSTANT_2),&(v238_2));
            let v238_4: Space = if has_head(&(v238_3)) { singleton(&[]) } else { Space::new() };
            drop(v238_3);
            let v238_5: Space = subtract(&(*CONSTANT_1),&(v238_4));
            drop(v238_4);
            let v238_8: Space = if (&(v238_5)).is_empty() { Space::new() } else {
              let v239_6: Path = concat_path(&(v237_6),&v233_25_cursor.path()[(v233_25_origin + 2)..(v233_25_origin + 3)]);
              let v239_7: Space = routine_21(c, &(v239_6), &(*p1), &v233_25_cursor, &(*s1));
              compose(&(v238_5),&(v239_7))
            };
            drop(v238_5);
            let v238_9: Space = intersect(&(*CONSTANT_2),&(v238_2));
            drop(v238_2);
            let v238_10: Space = if has_head(&(v238_9)) { singleton(&[]) } else { Space::new() };
            drop(v238_9);
            let v238_12: Space = if (&(v238_10)).is_empty() { Space::new() } else {
              let v240_6: Path = concat_path(&(v237_6),&v233_25_cursor.path()[(v233_25_origin + 2)..(v233_25_origin + 3)]);
              let v240_11: Space = routine_22(c, &(v240_6), &(*p1), &v233_25_cursor, &(*s1));
              drop(v240_6);
              compose(&(v238_10),&(v240_11))
            };
            drop(v238_10);
            let v238_13: Space = unite(&(v238_8),&(v238_12));
            join_wrapped_into(&mut v237_7_write,&((v238_13).read_zipper()),&[]);
            }
            v233_25_cursor.ascend(1);
          }
          drop(v237_7_write);
          compose(&(v236_5),&(v237_7))
        };
        drop(v236_5);
        let v236_9: Space = intersect(&(*CONSTANT_2),&(v236_2));
        drop(v236_2);
        let v236_10: Space = if has_head(&(v236_9)) { singleton(&[]) } else { Space::new() };
        drop(v236_9);
        let v236_12: Space = if (&(v236_10)).is_empty() { Space::new() } else {
          let v241_6: Path = concat_path(&(v235_6),&v233_25_cursor.path()[(v233_25_origin + 1)..(v233_25_origin + 2)]);
          let mut v241_11 = Space::new();
          let mut v241_11_write = v241_11.write_zipper();
          for v241_11_byte in v233_25_cursor.child_mask().iter() {
            v233_25_cursor.descend_to_existing_byte(v241_11_byte);
            {
            let v242_2: Space = singleton(&v233_25_cursor.path()[(v233_25_origin + 2)..(v233_25_origin + 3)]);
            let v242_3: Space = intersect(&(*CONSTANT_2),&(v242_2));
            let v242_4: Space = if has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
            drop(v242_3);
            let v242_5: Space = subtract(&(*CONSTANT_1),&(v242_4));
            drop(v242_4);
            let v242_8: Space = if (&(v242_5)).is_empty() { Space::new() } else {
              let v243_6: Path = concat_path(&(v241_6),&v233_25_cursor.path()[(v233_25_origin + 2)..(v233_25_origin + 3)]);
              let v243_7: Space = routine_21(c, &(v243_6), &(*p1), &v233_25_cursor, &(*s1));
              compose(&(v242_5),&(v243_7))
            };
            drop(v242_5);
            let v242_9: Space = intersect(&(*CONSTANT_2),&(v242_2));
            drop(v242_2);
            let v242_10: Space = if has_head(&(v242_9)) { singleton(&[]) } else { Space::new() };
            drop(v242_9);
            let v242_12: Space = if (&(v242_10)).is_empty() { Space::new() } else {
              let v244_6: Path = concat_path(&(v241_6),&v233_25_cursor.path()[(v233_25_origin + 2)..(v233_25_origin + 3)]);
              let v244_11: Space = routine_10(c, &(v244_6), &(*p1), &v233_25_cursor, &(*s1));
              drop(v244_6);
              compose(&(v242_10),&(v244_11))
            };
            drop(v242_10);
            let v242_13: Space = unite(&(v242_8),&(v242_12));
            join_wrapped_into(&mut v241_11_write,&((v242_13).read_zipper()),&[]);
            }
            v233_25_cursor.ascend(1);
          }
          drop(v241_11_write);
          drop(v241_6);
          compose(&(v236_10),&(v241_11))
        };
        drop(v236_10);
        let v236_13: Space = unite(&(v236_8),&(v236_12));
        join_wrapped_into(&mut v235_7_write,&((v236_13).read_zipper()),&[]);
        }
        v233_25_cursor.ascend(1);
      }
      drop(v235_7_write);
      compose(&(v234_5),&(v235_7))
    };
    drop(v234_5);
    let v234_9: Space = intersect(&(*CONSTANT_2),&(v234_2));
    drop(v234_2);
    let v234_10: Space = if has_head(&(v234_9)) { singleton(&[]) } else { Space::new() };
    drop(v234_9);
    let v234_13: Space = if (&(v234_10)).is_empty() { Space::new() } else {
      let v245_6: Path = concat_path(&(*p0),&v233_25_cursor.path()[v233_25_origin..(v233_25_origin + 1)]);
      let mut v245_12 = Space::new();
      let mut v245_12_write = v245_12.write_zipper();
      for v245_12_byte in v233_25_cursor.child_mask().iter() {
        v233_25_cursor.descend_to_existing_byte(v245_12_byte);
        {
        let v246_2: Space = singleton(&v233_25_cursor.path()[(v233_25_origin + 1)..(v233_25_origin + 2)]);
        let v246_3: Space = intersect(&(*CONSTANT_2),&(v246_2));
        let v246_4: Space = if has_head(&(v246_3)) { singleton(&[]) } else { Space::new() };
        drop(v246_3);
        let v246_5: Space = subtract(&(*CONSTANT_1),&(v246_4));
        drop(v246_4);
        let v246_8: Space = if (&(v246_5)).is_empty() { Space::new() } else {
          let v247_6: Path = concat_path(&(v245_6),&v233_25_cursor.path()[(v233_25_origin + 1)..(v233_25_origin + 2)]);
          let mut v247_7 = Space::new();
          let mut v247_7_write = v247_7.write_zipper();
          for v247_7_byte in v233_25_cursor.child_mask().iter() {
            v233_25_cursor.descend_to_existing_byte(v247_7_byte);
            {
            let v248_2: Space = singleton(&v233_25_cursor.path()[(v233_25_origin + 2)..(v233_25_origin + 3)]);
            let v248_3: Space = intersect(&(*CONSTANT_2),&(v248_2));
            let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
            drop(v248_3);
            let v248_5: Space = subtract(&(*CONSTANT_1),&(v248_4));
            drop(v248_4);
            let v248_8: Space = if (&(v248_5)).is_empty() { Space::new() } else {
              let v249_6: Path = concat_path(&(v247_6),&v233_25_cursor.path()[(v233_25_origin + 2)..(v233_25_origin + 3)]);
              let v249_7: Space = routine_21(c, &(v249_6), &(*p1), &v233_25_cursor, &(*s1));
              compose(&(v248_5),&(v249_7))
            };
            drop(v248_5);
            let v248_9: Space = intersect(&(*CONSTANT_2),&(v248_2));
            drop(v248_2);
            let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
            drop(v248_9);
            let v248_12: Space = if (&(v248_10)).is_empty() { Space::new() } else {
              let v250_6: Path = concat_path(&(v247_6),&v233_25_cursor.path()[(v233_25_origin + 2)..(v233_25_origin + 3)]);
              let v250_11: Space = routine_22(c, &(v250_6), &(*p1), &v233_25_cursor, &(*s1));
              drop(v250_6);
              compose(&(v248_10),&(v250_11))
            };
            drop(v248_10);
            let v248_13: Space = unite(&(v248_8),&(v248_12));
            join_wrapped_into(&mut v247_7_write,&((v248_13).read_zipper()),&[]);
            }
            v233_25_cursor.ascend(1);
          }
          drop(v247_7_write);
          compose(&(v246_5),&(v247_7))
        };
        drop(v246_5);
        let v246_9: Space = intersect(&(*CONSTANT_2),&(v246_2));
        drop(v246_2);
        let v246_10: Space = if has_head(&(v246_9)) { singleton(&[]) } else { Space::new() };
        drop(v246_9);
        let v246_13: Space = if (&(v246_10)).is_empty() { Space::new() } else {
          compose(&(v246_10),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v233_25_cursor.path()[v233_25_origin..(v233_25_origin + 1)]),&v233_25_cursor.path()[(v233_25_origin + 1)..(v233_25_origin + 2)]),&(*p1))))
        };
        drop(v246_10);
        let v252_6: Path = concat_path(&(v245_6),&v233_25_cursor.path()[(v233_25_origin + 1)..(v233_25_origin + 2)]);
        let v246_14: Space = wrap(&(v246_13),&(v252_6));
        drop(v246_13);
        let v246_15: Space = wrap(&(v246_14),&(*p1));
        drop(v246_14);
        let v246_16: Space = unite(&(v246_8),&(v246_15));
        drop(v246_15);
        join_wrapped_into(&mut v245_12_write,&((v246_16).read_zipper()),&[]);
        }
        v233_25_cursor.ascend(1);
      }
      drop(v245_12_write);
      drop(v245_6);
      compose(&(v234_10),&(v245_12))
    };
    drop(v234_10);
    let v234_14: Space = unite(&(v234_8),&(v234_13));
    join_wrapped_into(&mut v233_25_write,&((v234_14).read_zipper()),&[]);
    }
    v233_25_cursor.ascend(1);
  }
  drop(v233_25_cursor);
  drop(v233_25_write);
  (v233_25).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v253_19 = Space::new();
  let mut v253_19_write = v253_19.write_zipper();
  let mut v253_19_cursor = (*s0).read_zipper();
  let v253_19_origin = v253_19_cursor.path().len();
  for v253_19_byte in v253_19_cursor.child_mask().iter() {
    v253_19_cursor.descend_to_existing_byte(v253_19_byte);
    {
    let v254_2: Space = singleton(&v253_19_cursor.path()[v253_19_origin..(v253_19_origin + 1)]);
    let v254_3: Space = intersect(&(*CONSTANT_2),&(v254_2));
    let v254_4: Space = if has_head(&(v254_3)) { singleton(&[]) } else { Space::new() };
    drop(v254_3);
    let v254_5: Space = subtract(&(*CONSTANT_1),&(v254_4));
    drop(v254_4);
    let v254_8: Space = if (&(v254_5)).is_empty() { Space::new() } else {
      let v255_6: Path = concat_path(&(*p0),&v253_19_cursor.path()[v253_19_origin..(v253_19_origin + 1)]);
      let mut v255_7 = Space::new();
      let mut v255_7_write = v255_7.write_zipper();
      for v255_7_byte in v253_19_cursor.child_mask().iter() {
        v253_19_cursor.descend_to_existing_byte(v255_7_byte);
        {
        let v256_2: Space = singleton(&v253_19_cursor.path()[(v253_19_origin + 1)..(v253_19_origin + 2)]);
        let v256_3: Space = intersect(&(*CONSTANT_2),&(v256_2));
        let v256_4: Space = if has_head(&(v256_3)) { singleton(&[]) } else { Space::new() };
        drop(v256_3);
        let v256_5: Space = subtract(&(*CONSTANT_1),&(v256_4));
        drop(v256_4);
        let v256_8: Space = if (&(v256_5)).is_empty() { Space::new() } else {
          let v257_6: Path = concat_path(&(v255_6),&v253_19_cursor.path()[(v253_19_origin + 1)..(v253_19_origin + 2)]);
          let mut v257_7 = Space::new();
          let mut v257_7_write = v257_7.write_zipper();
          for v257_7_byte in v253_19_cursor.child_mask().iter() {
            v253_19_cursor.descend_to_existing_byte(v257_7_byte);
            {
            let v258_2: Space = singleton(&v253_19_cursor.path()[(v253_19_origin + 2)..(v253_19_origin + 3)]);
            let v258_3: Space = intersect(&(*CONSTANT_2),&(v258_2));
            let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
            drop(v258_3);
            let v258_5: Space = subtract(&(*CONSTANT_1),&(v258_4));
            drop(v258_4);
            let v258_8: Space = if (&(v258_5)).is_empty() { Space::new() } else {
              let v259_6: Path = concat_path(&(v257_6),&v253_19_cursor.path()[(v253_19_origin + 2)..(v253_19_origin + 3)]);
              let v259_7: Space = routine_21(c, &(v259_6), &(*p1), &v253_19_cursor, &(*s1));
              compose(&(v258_5),&(v259_7))
            };
            drop(v258_5);
            let v258_9: Space = intersect(&(*CONSTANT_2),&(v258_2));
            drop(v258_2);
            let v258_10: Space = if has_head(&(v258_9)) { singleton(&[]) } else { Space::new() };
            drop(v258_9);
            let v258_12: Space = if (&(v258_10)).is_empty() { Space::new() } else {
              let v260_6: Path = concat_path(&(v257_6),&v253_19_cursor.path()[(v253_19_origin + 2)..(v253_19_origin + 3)]);
              let v260_11: Space = routine_22(c, &(v260_6), &(*p1), &v253_19_cursor, &(*s1));
              drop(v260_6);
              compose(&(v258_10),&(v260_11))
            };
            drop(v258_10);
            let v258_13: Space = unite(&(v258_8),&(v258_12));
            join_wrapped_into(&mut v257_7_write,&((v258_13).read_zipper()),&[]);
            }
            v253_19_cursor.ascend(1);
          }
          drop(v257_7_write);
          compose(&(v256_5),&(v257_7))
        };
        drop(v256_5);
        let v256_9: Space = intersect(&(*CONSTANT_2),&(v256_2));
        drop(v256_2);
        let v256_10: Space = if has_head(&(v256_9)) { singleton(&[]) } else { Space::new() };
        drop(v256_9);
        let v256_12: Space = if (&(v256_10)).is_empty() { Space::new() } else {
          let v261_6: Path = concat_path(&(v255_6),&v253_19_cursor.path()[(v253_19_origin + 1)..(v253_19_origin + 2)]);
          let mut v261_11 = Space::new();
          let mut v261_11_write = v261_11.write_zipper();
          for v261_11_byte in v253_19_cursor.child_mask().iter() {
            v253_19_cursor.descend_to_existing_byte(v261_11_byte);
            {
            let v262_2: Space = singleton(&v253_19_cursor.path()[(v253_19_origin + 2)..(v253_19_origin + 3)]);
            let v262_3: Space = intersect(&(*CONSTANT_2),&(v262_2));
            let v262_4: Space = if has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
            drop(v262_3);
            let v262_5: Space = subtract(&(*CONSTANT_1),&(v262_4));
            drop(v262_4);
            let v262_8: Space = if (&(v262_5)).is_empty() { Space::new() } else {
              let v263_6: Path = concat_path(&(v261_6),&v253_19_cursor.path()[(v253_19_origin + 2)..(v253_19_origin + 3)]);
              let v263_7: Space = routine_21(c, &(v263_6), &(*p1), &v253_19_cursor, &(*s1));
              compose(&(v262_5),&(v263_7))
            };
            drop(v262_5);
            let v262_9: Space = intersect(&(*CONSTANT_2),&(v262_2));
            drop(v262_2);
            let v262_10: Space = if has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
            drop(v262_9);
            let v262_12: Space = if (&(v262_10)).is_empty() { Space::new() } else {
              let v264_6: Path = concat_path(&(v261_6),&v253_19_cursor.path()[(v253_19_origin + 2)..(v253_19_origin + 3)]);
              let v264_11: Space = routine_10(c, &(v264_6), &(*p1), &v253_19_cursor, &(*s1));
              drop(v264_6);
              compose(&(v262_10),&(v264_11))
            };
            drop(v262_10);
            let v262_13: Space = unite(&(v262_8),&(v262_12));
            join_wrapped_into(&mut v261_11_write,&((v262_13).read_zipper()),&[]);
            }
            v253_19_cursor.ascend(1);
          }
          drop(v261_11_write);
          drop(v261_6);
          compose(&(v256_10),&(v261_11))
        };
        drop(v256_10);
        let v256_13: Space = unite(&(v256_8),&(v256_12));
        join_wrapped_into(&mut v255_7_write,&((v256_13).read_zipper()),&[]);
        }
        v253_19_cursor.ascend(1);
      }
      drop(v255_7_write);
      compose(&(v254_5),&(v255_7))
    };
    drop(v254_5);
    let v254_9: Space = intersect(&(*CONSTANT_2),&(v254_2));
    drop(v254_2);
    let v254_10: Space = if has_head(&(v254_9)) { singleton(&[]) } else { Space::new() };
    drop(v254_9);
    let v254_13: Space = if (&(v254_10)).is_empty() { Space::new() } else {
      compose(&(v254_10),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v253_19_cursor.path()[v253_19_origin..(v253_19_origin + 1)]),&(*p1))))
    };
    drop(v254_10);
    let v266_6: Path = concat_path(&(*p0),&v253_19_cursor.path()[v253_19_origin..(v253_19_origin + 1)]);
    let v254_14: Space = wrap(&(v254_13),&(v266_6));
    drop(v254_13);
    let v254_15: Space = wrap(&(v254_14),&(*p1));
    drop(v254_14);
    let v254_16: Space = unite(&(v254_8),&(v254_15));
    drop(v254_15);
    join_wrapped_into(&mut v253_19_write,&((v254_16).read_zipper()),&[]);
    }
    v253_19_cursor.ascend(1);
  }
  drop(v253_19_cursor);
  drop(v253_19_write);
  (v253_19).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v267_10 = Space::new();
  let mut v267_10_write = v267_10.write_zipper();
  let mut v267_10_cursor = (*s0).read_zipper();
  let v267_10_origin = v267_10_cursor.path().len();
  for v267_10_byte in v267_10_cursor.child_mask().iter() {
    v267_10_cursor.descend_to_existing_byte(v267_10_byte);
    {
    let v268_2: Space = singleton(&v267_10_cursor.path()[v267_10_origin..(v267_10_origin + 1)]);
    let v268_3: Space = intersect(&(*CONSTANT_2),&(v268_2));
    let v268_4: Space = if has_head(&(v268_3)) { singleton(&[]) } else { Space::new() };
    drop(v268_3);
    let v268_5: Space = subtract(&(*CONSTANT_1),&(v268_4));
    drop(v268_4);
    let v268_7: Space = if (&(v268_5)).is_empty() { Space::new() } else {
      let mut v269_6 = Space::new();
      let mut v269_6_write = v269_6.write_zipper();
      for v269_6_byte in v267_10_cursor.child_mask().iter() {
        v267_10_cursor.descend_to_existing_byte(v269_6_byte);
        {
        let v270_2: Space = Space::new();
        join_wrapped_into(&mut v269_6_write,&((v270_2).read_zipper()),&[]);
        }
        v267_10_cursor.ascend(1);
      }
      drop(v269_6_write);
      compose(&(v268_5),&(v269_6))
    };
    drop(v268_5);
    let v268_8: Space = intersect(&(*CONSTANT_2),&(v268_2));
    drop(v268_2);
    let v268_9: Space = if has_head(&(v268_8)) { singleton(&[]) } else { Space::new() };
    drop(v268_8);
    let v268_12: Space = if (&(v268_9)).is_empty() { Space::new() } else {
      let v271_10: Path = concat_path(&(*p0),&v267_10_cursor.path()[v267_10_origin..(v267_10_origin + 1)]);
      let mut v271_11 = Space::new();
      let mut v271_11_write = v271_11.write_zipper();
      for v271_11_byte in v267_10_cursor.child_mask().iter() {
        v267_10_cursor.descend_to_existing_byte(v271_11_byte);
        {
        let v272_2: Space = singleton(&v267_10_cursor.path()[(v267_10_origin + 1)..(v267_10_origin + 2)]);
        let v272_3: Space = intersect(&(*CONSTANT_2),&(v272_2));
        drop(v272_2);
        let v272_4: Space = if has_head(&(v272_3)) { singleton(&[]) } else { Space::new() };
        drop(v272_3);
        let v272_7: Space = if (&(v272_4)).is_empty() { Space::new() } else {
          let v273_5: Path = concat_path(&(v271_10),&v267_10_cursor.path()[(v267_10_origin + 1)..(v267_10_origin + 2)]);
          let mut v273_6 = Space::new();
          let mut v273_6_write = v273_6.write_zipper();
          for v273_6_byte in v267_10_cursor.child_mask().iter() {
            v267_10_cursor.descend_to_existing_byte(v273_6_byte);
            {
            let v274_2: Space = singleton(&v267_10_cursor.path()[(v267_10_origin + 2)..(v267_10_origin + 3)]);
            let v274_3: Space = intersect(&(*CONSTANT_2),&(v274_2));
            let v274_4: Space = if has_head(&(v274_3)) { singleton(&[]) } else { Space::new() };
            drop(v274_3);
            let v274_5: Space = subtract(&(*CONSTANT_1),&(v274_4));
            drop(v274_4);
            let v274_7: Space = if (&(v274_5)).is_empty() { Space::new() } else {
              let v275_6: Space = routine_4(c, &v267_10_cursor.path()[(v267_10_origin + 2)..(v267_10_origin + 3)], &(v273_5), &v267_10_cursor, &(*s1));
              compose(&(v274_5),&(v275_6))
            };
            drop(v274_5);
            let v274_8: Space = intersect(&(*CONSTANT_2),&(v274_2));
            drop(v274_2);
            let v274_9: Space = if has_head(&(v274_8)) { singleton(&[]) } else { Space::new() };
            drop(v274_8);
            let v274_11: Space = if (&(v274_9)).is_empty() { Space::new() } else {
              let v276_10: Space = routine_5(c, &v267_10_cursor.path()[(v267_10_origin + 2)..(v267_10_origin + 3)], &(v273_5), &v267_10_cursor, &(*s1));
              compose(&(v274_9),&(v276_10))
            };
            drop(v274_9);
            let v274_12: Space = unite(&(v274_7),&(v274_11));
            join_wrapped_into(&mut v273_6_write,&((v274_12).read_zipper()),&[]);
            }
            v267_10_cursor.ascend(1);
          }
          drop(v273_6_write);
          drop(v273_5);
          compose(&(v272_4),&(v273_6))
        };
        drop(v272_4);
        join_wrapped_into(&mut v271_11_write,&((v272_7).read_zipper()),&[]);
        }
        v267_10_cursor.ascend(1);
      }
      drop(v271_11_write);
      drop(v271_10);
      compose(&(v268_9),&(v271_11))
    };
    drop(v268_9);
    let v268_13: Space = unite(&(v268_7),&(v268_12));
    drop(v268_7);
    join_wrapped_into(&mut v267_10_write,&((v268_13).read_zipper()),&[]);
    }
    v267_10_cursor.ascend(1);
  }
  drop(v267_10_cursor);
  drop(v267_10_write);
  (v267_10).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v277_15 = Space::new();
  let mut v277_15_write = v277_15.write_zipper();
  let mut v277_15_cursor = (*s0).read_zipper();
  let v277_15_origin = v277_15_cursor.path().len();
  for v277_15_byte in v277_15_cursor.child_mask().iter() {
    v277_15_cursor.descend_to_existing_byte(v277_15_byte);
    {
    let v278_2: Space = singleton(&v277_15_cursor.path()[v277_15_origin..(v277_15_origin + 1)]);
    let v278_3: Space = intersect(&(*CONSTANT_2),&(v278_2));
    let v278_4: Space = if has_head(&(v278_3)) { singleton(&[]) } else { Space::new() };
    drop(v278_3);
    let v278_5: Space = subtract(&(*CONSTANT_1),&(v278_4));
    drop(v278_4);
    let v278_7: Space = if (&(v278_5)).is_empty() { Space::new() } else {
      let mut v279_6 = Space::new();
      let mut v279_6_write = v279_6.write_zipper();
      for v279_6_byte in v277_15_cursor.child_mask().iter() {
        v277_15_cursor.descend_to_existing_byte(v279_6_byte);
        {
        let v280_2: Space = Space::new();
        join_wrapped_into(&mut v279_6_write,&((v280_2).read_zipper()),&[]);
        }
        v277_15_cursor.ascend(1);
      }
      drop(v279_6_write);
      compose(&(v278_5),&(v279_6))
    };
    drop(v278_5);
    let v278_8: Space = intersect(&(*CONSTANT_2),&(v278_2));
    drop(v278_2);
    let v278_9: Space = if has_head(&(v278_8)) { singleton(&[]) } else { Space::new() };
    drop(v278_8);
    let v278_12: Space = if (&(v278_9)).is_empty() { Space::new() } else {
      let v281_10: Path = concat_path(&(*p0),&v277_15_cursor.path()[v277_15_origin..(v277_15_origin + 1)]);
      let mut v281_11 = Space::new();
      let mut v281_11_write = v281_11.write_zipper();
      for v281_11_byte in v277_15_cursor.child_mask().iter() {
        v277_15_cursor.descend_to_existing_byte(v281_11_byte);
        {
        let v282_2: Space = singleton(&v277_15_cursor.path()[(v277_15_origin + 1)..(v277_15_origin + 2)]);
        let v282_3: Space = intersect(&(*CONSTANT_2),&(v282_2));
        let v282_4: Space = if has_head(&(v282_3)) { singleton(&[]) } else { Space::new() };
        drop(v282_3);
        let v282_5: Space = subtract(&(*CONSTANT_1),&(v282_4));
        drop(v282_4);
        let v282_7: Space = if (&(v282_5)).is_empty() { Space::new() } else {
          let mut v283_6 = Space::new();
          let mut v283_6_write = v283_6.write_zipper();
          for v283_6_byte in v277_15_cursor.child_mask().iter() {
            v277_15_cursor.descend_to_existing_byte(v283_6_byte);
            {
            let v284_2: Space = singleton(&v277_15_cursor.path()[(v277_15_origin + 2)..(v277_15_origin + 3)]);
            let v284_3: Space = intersect(&(*CONSTANT_2),&(v284_2));
            let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
            drop(v284_3);
            let v284_5: Space = subtract(&(*CONSTANT_1),&(v284_4));
            drop(v284_4);
            let v284_8: Space = if (&(v284_5)).is_empty() { Space::new() } else {
              let v285_7: Space = routine_8(c, &v277_15_cursor.path()[(v277_15_origin + 1)..(v277_15_origin + 3)], &(v281_10), &v277_15_cursor, &(*s1));
              compose(&(v284_5),&(v285_7))
            };
            drop(v284_5);
            let v284_9: Space = intersect(&(*CONSTANT_2),&(v284_2));
            drop(v284_2);
            let v284_10: Space = if has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
            drop(v284_9);
            let v284_12: Space = if (&(v284_10)).is_empty() { Space::new() } else {
              let v286_11: Space = routine_9(c, &v277_15_cursor.path()[(v277_15_origin + 1)..(v277_15_origin + 3)], &(v281_10), &v277_15_cursor, &(*s1));
              compose(&(v284_10),&(v286_11))
            };
            drop(v284_10);
            let v284_13: Space = unite(&(v284_8),&(v284_12));
            join_wrapped_into(&mut v283_6_write,&((v284_13).read_zipper()),&[]);
            }
            v277_15_cursor.ascend(1);
          }
          drop(v283_6_write);
          compose(&(v282_5),&(v283_6))
        };
        drop(v282_5);
        let v282_8: Space = intersect(&(*CONSTANT_2),&(v282_2));
        drop(v282_2);
        let v282_9: Space = if has_head(&(v282_8)) { singleton(&[]) } else { Space::new() };
        drop(v282_8);
        let v282_11: Space = if (&(v282_9)).is_empty() { Space::new() } else {
          let mut v287_10 = Space::new();
          let mut v287_10_write = v287_10.write_zipper();
          for v287_10_byte in v277_15_cursor.child_mask().iter() {
            v277_15_cursor.descend_to_existing_byte(v287_10_byte);
            {
            let v288_2: Space = singleton(&v277_15_cursor.path()[(v277_15_origin + 2)..(v277_15_origin + 3)]);
            let v288_3: Space = intersect(&(*CONSTANT_2),&(v288_2));
            let v288_4: Space = if has_head(&(v288_3)) { singleton(&[]) } else { Space::new() };
            drop(v288_3);
            let v288_5: Space = subtract(&(*CONSTANT_1),&(v288_4));
            drop(v288_4);
            let v288_8: Space = if (&(v288_5)).is_empty() { Space::new() } else {
              let v289_7: Space = routine_8(c, &v277_15_cursor.path()[(v277_15_origin + 1)..(v277_15_origin + 3)], &(v281_10), &v277_15_cursor, &(*s1));
              compose(&(v288_5),&(v289_7))
            };
            drop(v288_5);
            let v288_9: Space = intersect(&(*CONSTANT_2),&(v288_2));
            drop(v288_2);
            let v288_10: Space = if has_head(&(v288_9)) { singleton(&[]) } else { Space::new() };
            drop(v288_9);
            let v288_12: Space = if (&(v288_10)).is_empty() { Space::new() } else {
              let v290_11: Space = routine_10(c, &v277_15_cursor.path()[(v277_15_origin + 1)..(v277_15_origin + 3)], &(v281_10), &v277_15_cursor, &(*s1));
              compose(&(v288_10),&(v290_11))
            };
            drop(v288_10);
            let v288_13: Space = unite(&(v288_8),&(v288_12));
            join_wrapped_into(&mut v287_10_write,&((v288_13).read_zipper()),&[]);
            }
            v277_15_cursor.ascend(1);
          }
          drop(v287_10_write);
          compose(&(v282_9),&(v287_10))
        };
        drop(v282_9);
        let v282_12: Space = unite(&(v282_7),&(v282_11));
        join_wrapped_into(&mut v281_11_write,&((v282_12).read_zipper()),&[]);
        }
        v277_15_cursor.ascend(1);
      }
      drop(v281_11_write);
      drop(v281_10);
      compose(&(v278_9),&(v281_11))
    };
    drop(v278_9);
    let v278_13: Space = unite(&(v278_7),&(v278_12));
    drop(v278_7);
    join_wrapped_into(&mut v277_15_write,&((v278_13).read_zipper()),&[]);
    }
    v277_15_cursor.ascend(1);
  }
  drop(v277_15_cursor);
  drop(v277_15_write);
  (v277_15).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v291_25 = Space::new();
  let mut v291_25_write = v291_25.write_zipper();
  let mut v291_25_cursor = (*s0).read_zipper();
  let v291_25_origin = v291_25_cursor.path().len();
  for v291_25_byte in v291_25_cursor.child_mask().iter() {
    v291_25_cursor.descend_to_existing_byte(v291_25_byte);
    {
    let v292_2: Space = singleton(&v291_25_cursor.path()[v291_25_origin..(v291_25_origin + 1)]);
    let v292_3: Space = intersect(&(*CONSTANT_2),&(v292_2));
    let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
    drop(v292_3);
    let v292_5: Space = subtract(&(*CONSTANT_1),&(v292_4));
    drop(v292_4);
    let v292_8: Space = if (&(v292_5)).is_empty() { Space::new() } else {
      let v293_6: Path = concat_path(&(*p0),&v291_25_cursor.path()[v291_25_origin..(v291_25_origin + 1)]);
      let mut v293_7 = Space::new();
      let mut v293_7_write = v293_7.write_zipper();
      for v293_7_byte in v291_25_cursor.child_mask().iter() {
        v291_25_cursor.descend_to_existing_byte(v293_7_byte);
        {
        let v294_2: Space = singleton(&v291_25_cursor.path()[(v291_25_origin + 1)..(v291_25_origin + 2)]);
        let v294_3: Space = intersect(&(*CONSTANT_2),&(v294_2));
        let v294_4: Space = if has_head(&(v294_3)) { singleton(&[]) } else { Space::new() };
        drop(v294_3);
        let v294_5: Space = subtract(&(*CONSTANT_1),&(v294_4));
        drop(v294_4);
        let v294_8: Space = if (&(v294_5)).is_empty() { Space::new() } else {
          let v295_6: Path = concat_path(&(v293_6),&v291_25_cursor.path()[(v291_25_origin + 1)..(v291_25_origin + 2)]);
          let mut v295_7 = Space::new();
          let mut v295_7_write = v295_7.write_zipper();
          for v295_7_byte in v291_25_cursor.child_mask().iter() {
            v291_25_cursor.descend_to_existing_byte(v295_7_byte);
            {
            let v296_2: Space = singleton(&v291_25_cursor.path()[(v291_25_origin + 2)..(v291_25_origin + 3)]);
            let v296_3: Space = intersect(&(*CONSTANT_2),&(v296_2));
            let v296_4: Space = if has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
            drop(v296_3);
            let v296_5: Space = subtract(&(*CONSTANT_1),&(v296_4));
            drop(v296_4);
            let v296_8: Space = if (&(v296_5)).is_empty() { Space::new() } else {
              let v297_6: Path = concat_path(&(v295_6),&v291_25_cursor.path()[(v291_25_origin + 2)..(v291_25_origin + 3)]);
              let v297_7: Space = routine_23(c, &(v297_6), &(*p1), &v291_25_cursor, &(*s1));
              compose(&(v296_5),&(v297_7))
            };
            drop(v296_5);
            let v296_9: Space = intersect(&(*CONSTANT_2),&(v296_2));
            drop(v296_2);
            let v296_10: Space = if has_head(&(v296_9)) { singleton(&[]) } else { Space::new() };
            drop(v296_9);
            let v296_12: Space = if (&(v296_10)).is_empty() { Space::new() } else {
              let v298_6: Path = concat_path(&(v295_6),&v291_25_cursor.path()[(v291_25_origin + 2)..(v291_25_origin + 3)]);
              let v298_11: Space = routine_24(c, &(v298_6), &(*p1), &v291_25_cursor, &(*s1));
              drop(v298_6);
              compose(&(v296_10),&(v298_11))
            };
            drop(v296_10);
            let v296_13: Space = unite(&(v296_8),&(v296_12));
            join_wrapped_into(&mut v295_7_write,&((v296_13).read_zipper()),&[]);
            }
            v291_25_cursor.ascend(1);
          }
          drop(v295_7_write);
          compose(&(v294_5),&(v295_7))
        };
        drop(v294_5);
        let v294_9: Space = intersect(&(*CONSTANT_2),&(v294_2));
        drop(v294_2);
        let v294_10: Space = if has_head(&(v294_9)) { singleton(&[]) } else { Space::new() };
        drop(v294_9);
        let v294_12: Space = if (&(v294_10)).is_empty() { Space::new() } else {
          let v299_6: Path = concat_path(&(v293_6),&v291_25_cursor.path()[(v291_25_origin + 1)..(v291_25_origin + 2)]);
          let mut v299_11 = Space::new();
          let mut v299_11_write = v299_11.write_zipper();
          for v299_11_byte in v291_25_cursor.child_mask().iter() {
            v291_25_cursor.descend_to_existing_byte(v299_11_byte);
            {
            let v300_2: Space = singleton(&v291_25_cursor.path()[(v291_25_origin + 2)..(v291_25_origin + 3)]);
            let v300_3: Space = intersect(&(*CONSTANT_2),&(v300_2));
            let v300_4: Space = if has_head(&(v300_3)) { singleton(&[]) } else { Space::new() };
            drop(v300_3);
            let v300_5: Space = subtract(&(*CONSTANT_1),&(v300_4));
            drop(v300_4);
            let v300_8: Space = if (&(v300_5)).is_empty() { Space::new() } else {
              let v301_6: Path = concat_path(&(v299_6),&v291_25_cursor.path()[(v291_25_origin + 2)..(v291_25_origin + 3)]);
              let v301_7: Space = routine_23(c, &(v301_6), &(*p1), &v291_25_cursor, &(*s1));
              compose(&(v300_5),&(v301_7))
            };
            drop(v300_5);
            let v300_9: Space = intersect(&(*CONSTANT_2),&(v300_2));
            drop(v300_2);
            let v300_10: Space = if has_head(&(v300_9)) { singleton(&[]) } else { Space::new() };
            drop(v300_9);
            let v300_12: Space = if (&(v300_10)).is_empty() { Space::new() } else {
              let v302_6: Path = concat_path(&(v299_6),&v291_25_cursor.path()[(v291_25_origin + 2)..(v291_25_origin + 3)]);
              let v302_11: Space = routine_10(c, &(v302_6), &(*p1), &v291_25_cursor, &(*s1));
              drop(v302_6);
              compose(&(v300_10),&(v302_11))
            };
            drop(v300_10);
            let v300_13: Space = unite(&(v300_8),&(v300_12));
            join_wrapped_into(&mut v299_11_write,&((v300_13).read_zipper()),&[]);
            }
            v291_25_cursor.ascend(1);
          }
          drop(v299_11_write);
          drop(v299_6);
          compose(&(v294_10),&(v299_11))
        };
        drop(v294_10);
        let v294_13: Space = unite(&(v294_8),&(v294_12));
        join_wrapped_into(&mut v293_7_write,&((v294_13).read_zipper()),&[]);
        }
        v291_25_cursor.ascend(1);
      }
      drop(v293_7_write);
      compose(&(v292_5),&(v293_7))
    };
    drop(v292_5);
    let v292_9: Space = intersect(&(*CONSTANT_2),&(v292_2));
    drop(v292_2);
    let v292_10: Space = if has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
    drop(v292_9);
    let v292_13: Space = if (&(v292_10)).is_empty() { Space::new() } else {
      let v303_6: Path = concat_path(&(*p0),&v291_25_cursor.path()[v291_25_origin..(v291_25_origin + 1)]);
      let mut v303_12 = Space::new();
      let mut v303_12_write = v303_12.write_zipper();
      for v303_12_byte in v291_25_cursor.child_mask().iter() {
        v291_25_cursor.descend_to_existing_byte(v303_12_byte);
        {
        let v304_2: Space = singleton(&v291_25_cursor.path()[(v291_25_origin + 1)..(v291_25_origin + 2)]);
        let v304_3: Space = intersect(&(*CONSTANT_2),&(v304_2));
        let v304_4: Space = if has_head(&(v304_3)) { singleton(&[]) } else { Space::new() };
        drop(v304_3);
        let v304_5: Space = subtract(&(*CONSTANT_1),&(v304_4));
        drop(v304_4);
        let v304_8: Space = if (&(v304_5)).is_empty() { Space::new() } else {
          let v305_6: Path = concat_path(&(v303_6),&v291_25_cursor.path()[(v291_25_origin + 1)..(v291_25_origin + 2)]);
          let mut v305_7 = Space::new();
          let mut v305_7_write = v305_7.write_zipper();
          for v305_7_byte in v291_25_cursor.child_mask().iter() {
            v291_25_cursor.descend_to_existing_byte(v305_7_byte);
            {
            let v306_2: Space = singleton(&v291_25_cursor.path()[(v291_25_origin + 2)..(v291_25_origin + 3)]);
            let v306_3: Space = intersect(&(*CONSTANT_2),&(v306_2));
            let v306_4: Space = if has_head(&(v306_3)) { singleton(&[]) } else { Space::new() };
            drop(v306_3);
            let v306_5: Space = subtract(&(*CONSTANT_1),&(v306_4));
            drop(v306_4);
            let v306_8: Space = if (&(v306_5)).is_empty() { Space::new() } else {
              let v307_6: Path = concat_path(&(v305_6),&v291_25_cursor.path()[(v291_25_origin + 2)..(v291_25_origin + 3)]);
              let v307_7: Space = routine_23(c, &(v307_6), &(*p1), &v291_25_cursor, &(*s1));
              compose(&(v306_5),&(v307_7))
            };
            drop(v306_5);
            let v306_9: Space = intersect(&(*CONSTANT_2),&(v306_2));
            drop(v306_2);
            let v306_10: Space = if has_head(&(v306_9)) { singleton(&[]) } else { Space::new() };
            drop(v306_9);
            let v306_12: Space = if (&(v306_10)).is_empty() { Space::new() } else {
              let v308_6: Path = concat_path(&(v305_6),&v291_25_cursor.path()[(v291_25_origin + 2)..(v291_25_origin + 3)]);
              let v308_11: Space = routine_24(c, &(v308_6), &(*p1), &v291_25_cursor, &(*s1));
              drop(v308_6);
              compose(&(v306_10),&(v308_11))
            };
            drop(v306_10);
            let v306_13: Space = unite(&(v306_8),&(v306_12));
            join_wrapped_into(&mut v305_7_write,&((v306_13).read_zipper()),&[]);
            }
            v291_25_cursor.ascend(1);
          }
          drop(v305_7_write);
          compose(&(v304_5),&(v305_7))
        };
        drop(v304_5);
        let v304_9: Space = intersect(&(*CONSTANT_2),&(v304_2));
        drop(v304_2);
        let v304_10: Space = if has_head(&(v304_9)) { singleton(&[]) } else { Space::new() };
        drop(v304_9);
        let v304_13: Space = if (&(v304_10)).is_empty() { Space::new() } else {
          compose(&(v304_10),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v291_25_cursor.path()[v291_25_origin..(v291_25_origin + 1)]),&v291_25_cursor.path()[(v291_25_origin + 1)..(v291_25_origin + 2)]),&(*p1))))
        };
        drop(v304_10);
        let v310_6: Path = concat_path(&(v303_6),&v291_25_cursor.path()[(v291_25_origin + 1)..(v291_25_origin + 2)]);
        let v304_14: Space = wrap(&(v304_13),&(v310_6));
        drop(v304_13);
        let v304_15: Space = wrap(&(v304_14),&(*p1));
        drop(v304_14);
        let v304_16: Space = unite(&(v304_8),&(v304_15));
        drop(v304_15);
        join_wrapped_into(&mut v303_12_write,&((v304_16).read_zipper()),&[]);
        }
        v291_25_cursor.ascend(1);
      }
      drop(v303_12_write);
      drop(v303_6);
      compose(&(v292_10),&(v303_12))
    };
    drop(v292_10);
    let v292_14: Space = unite(&(v292_8),&(v292_13));
    join_wrapped_into(&mut v291_25_write,&((v292_14).read_zipper()),&[]);
    }
    v291_25_cursor.ascend(1);
  }
  drop(v291_25_cursor);
  drop(v291_25_write);
  (v291_25).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v311_19 = Space::new();
  let mut v311_19_write = v311_19.write_zipper();
  let mut v311_19_cursor = (*s0).read_zipper();
  let v311_19_origin = v311_19_cursor.path().len();
  for v311_19_byte in v311_19_cursor.child_mask().iter() {
    v311_19_cursor.descend_to_existing_byte(v311_19_byte);
    {
    let v312_2: Space = singleton(&v311_19_cursor.path()[v311_19_origin..(v311_19_origin + 1)]);
    let v312_3: Space = intersect(&(*CONSTANT_2),&(v312_2));
    let v312_4: Space = if has_head(&(v312_3)) { singleton(&[]) } else { Space::new() };
    drop(v312_3);
    let v312_5: Space = subtract(&(*CONSTANT_1),&(v312_4));
    drop(v312_4);
    let v312_8: Space = if (&(v312_5)).is_empty() { Space::new() } else {
      let v313_6: Path = concat_path(&(*p0),&v311_19_cursor.path()[v311_19_origin..(v311_19_origin + 1)]);
      let mut v313_7 = Space::new();
      let mut v313_7_write = v313_7.write_zipper();
      for v313_7_byte in v311_19_cursor.child_mask().iter() {
        v311_19_cursor.descend_to_existing_byte(v313_7_byte);
        {
        let v314_2: Space = singleton(&v311_19_cursor.path()[(v311_19_origin + 1)..(v311_19_origin + 2)]);
        let v314_3: Space = intersect(&(*CONSTANT_2),&(v314_2));
        let v314_4: Space = if has_head(&(v314_3)) { singleton(&[]) } else { Space::new() };
        drop(v314_3);
        let v314_5: Space = subtract(&(*CONSTANT_1),&(v314_4));
        drop(v314_4);
        let v314_8: Space = if (&(v314_5)).is_empty() { Space::new() } else {
          let v315_6: Path = concat_path(&(v313_6),&v311_19_cursor.path()[(v311_19_origin + 1)..(v311_19_origin + 2)]);
          let mut v315_7 = Space::new();
          let mut v315_7_write = v315_7.write_zipper();
          for v315_7_byte in v311_19_cursor.child_mask().iter() {
            v311_19_cursor.descend_to_existing_byte(v315_7_byte);
            {
            let v316_2: Space = singleton(&v311_19_cursor.path()[(v311_19_origin + 2)..(v311_19_origin + 3)]);
            let v316_3: Space = intersect(&(*CONSTANT_2),&(v316_2));
            let v316_4: Space = if has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
            drop(v316_3);
            let v316_5: Space = subtract(&(*CONSTANT_1),&(v316_4));
            drop(v316_4);
            let v316_8: Space = if (&(v316_5)).is_empty() { Space::new() } else {
              let v317_6: Path = concat_path(&(v315_6),&v311_19_cursor.path()[(v311_19_origin + 2)..(v311_19_origin + 3)]);
              let v317_7: Space = routine_23(c, &(v317_6), &(*p1), &v311_19_cursor, &(*s1));
              compose(&(v316_5),&(v317_7))
            };
            drop(v316_5);
            let v316_9: Space = intersect(&(*CONSTANT_2),&(v316_2));
            drop(v316_2);
            let v316_10: Space = if has_head(&(v316_9)) { singleton(&[]) } else { Space::new() };
            drop(v316_9);
            let v316_12: Space = if (&(v316_10)).is_empty() { Space::new() } else {
              let v318_6: Path = concat_path(&(v315_6),&v311_19_cursor.path()[(v311_19_origin + 2)..(v311_19_origin + 3)]);
              let v318_11: Space = routine_24(c, &(v318_6), &(*p1), &v311_19_cursor, &(*s1));
              drop(v318_6);
              compose(&(v316_10),&(v318_11))
            };
            drop(v316_10);
            let v316_13: Space = unite(&(v316_8),&(v316_12));
            join_wrapped_into(&mut v315_7_write,&((v316_13).read_zipper()),&[]);
            }
            v311_19_cursor.ascend(1);
          }
          drop(v315_7_write);
          compose(&(v314_5),&(v315_7))
        };
        drop(v314_5);
        let v314_9: Space = intersect(&(*CONSTANT_2),&(v314_2));
        drop(v314_2);
        let v314_10: Space = if has_head(&(v314_9)) { singleton(&[]) } else { Space::new() };
        drop(v314_9);
        let v314_12: Space = if (&(v314_10)).is_empty() { Space::new() } else {
          let v319_6: Path = concat_path(&(v313_6),&v311_19_cursor.path()[(v311_19_origin + 1)..(v311_19_origin + 2)]);
          let mut v319_11 = Space::new();
          let mut v319_11_write = v319_11.write_zipper();
          for v319_11_byte in v311_19_cursor.child_mask().iter() {
            v311_19_cursor.descend_to_existing_byte(v319_11_byte);
            {
            let v320_2: Space = singleton(&v311_19_cursor.path()[(v311_19_origin + 2)..(v311_19_origin + 3)]);
            let v320_3: Space = intersect(&(*CONSTANT_2),&(v320_2));
            let v320_4: Space = if has_head(&(v320_3)) { singleton(&[]) } else { Space::new() };
            drop(v320_3);
            let v320_5: Space = subtract(&(*CONSTANT_1),&(v320_4));
            drop(v320_4);
            let v320_8: Space = if (&(v320_5)).is_empty() { Space::new() } else {
              let v321_6: Path = concat_path(&(v319_6),&v311_19_cursor.path()[(v311_19_origin + 2)..(v311_19_origin + 3)]);
              let v321_7: Space = routine_23(c, &(v321_6), &(*p1), &v311_19_cursor, &(*s1));
              compose(&(v320_5),&(v321_7))
            };
            drop(v320_5);
            let v320_9: Space = intersect(&(*CONSTANT_2),&(v320_2));
            drop(v320_2);
            let v320_10: Space = if has_head(&(v320_9)) { singleton(&[]) } else { Space::new() };
            drop(v320_9);
            let v320_12: Space = if (&(v320_10)).is_empty() { Space::new() } else {
              let v322_6: Path = concat_path(&(v319_6),&v311_19_cursor.path()[(v311_19_origin + 2)..(v311_19_origin + 3)]);
              let v322_11: Space = routine_10(c, &(v322_6), &(*p1), &v311_19_cursor, &(*s1));
              drop(v322_6);
              compose(&(v320_10),&(v322_11))
            };
            drop(v320_10);
            let v320_13: Space = unite(&(v320_8),&(v320_12));
            join_wrapped_into(&mut v319_11_write,&((v320_13).read_zipper()),&[]);
            }
            v311_19_cursor.ascend(1);
          }
          drop(v319_11_write);
          drop(v319_6);
          compose(&(v314_10),&(v319_11))
        };
        drop(v314_10);
        let v314_13: Space = unite(&(v314_8),&(v314_12));
        join_wrapped_into(&mut v313_7_write,&((v314_13).read_zipper()),&[]);
        }
        v311_19_cursor.ascend(1);
      }
      drop(v313_7_write);
      compose(&(v312_5),&(v313_7))
    };
    drop(v312_5);
    let v312_9: Space = intersect(&(*CONSTANT_2),&(v312_2));
    drop(v312_2);
    let v312_10: Space = if has_head(&(v312_9)) { singleton(&[]) } else { Space::new() };
    drop(v312_9);
    let v312_13: Space = if (&(v312_10)).is_empty() { Space::new() } else {
      compose(&(v312_10),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v311_19_cursor.path()[v311_19_origin..(v311_19_origin + 1)]),&(*p1))))
    };
    drop(v312_10);
    let v324_6: Path = concat_path(&(*p0),&v311_19_cursor.path()[v311_19_origin..(v311_19_origin + 1)]);
    let v312_14: Space = wrap(&(v312_13),&(v324_6));
    drop(v312_13);
    let v312_15: Space = wrap(&(v312_14),&(*p1));
    drop(v312_14);
    let v312_16: Space = unite(&(v312_8),&(v312_15));
    drop(v312_15);
    join_wrapped_into(&mut v311_19_write,&((v312_16).read_zipper()),&[]);
    }
    v311_19_cursor.ascend(1);
  }
  drop(v311_19_cursor);
  drop(v311_19_write);
  (v311_19).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v325_25 = Space::new();
  let mut v325_25_write = v325_25.write_zipper();
  let mut v325_25_cursor = (*s0).read_zipper();
  let v325_25_origin = v325_25_cursor.path().len();
  for v325_25_byte in v325_25_cursor.child_mask().iter() {
    v325_25_cursor.descend_to_existing_byte(v325_25_byte);
    {
    let v326_2: Space = singleton(&v325_25_cursor.path()[v325_25_origin..(v325_25_origin + 1)]);
    let v326_3: Space = intersect(&(*CONSTANT_2),&(v326_2));
    let v326_4: Space = if has_head(&(v326_3)) { singleton(&[]) } else { Space::new() };
    drop(v326_3);
    let v326_5: Space = subtract(&(*CONSTANT_1),&(v326_4));
    drop(v326_4);
    let v326_8: Space = if (&(v326_5)).is_empty() { Space::new() } else {
      let v327_6: Path = concat_path(&(*p0),&v325_25_cursor.path()[v325_25_origin..(v325_25_origin + 1)]);
      let mut v327_7 = Space::new();
      let mut v327_7_write = v327_7.write_zipper();
      for v327_7_byte in v325_25_cursor.child_mask().iter() {
        v325_25_cursor.descend_to_existing_byte(v327_7_byte);
        {
        let v328_2: Space = singleton(&v325_25_cursor.path()[(v325_25_origin + 1)..(v325_25_origin + 2)]);
        let v328_3: Space = intersect(&(*CONSTANT_2),&(v328_2));
        let v328_4: Space = if has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
        drop(v328_3);
        let v328_5: Space = subtract(&(*CONSTANT_1),&(v328_4));
        drop(v328_4);
        let v328_8: Space = if (&(v328_5)).is_empty() { Space::new() } else {
          let v329_6: Path = concat_path(&(v327_6),&v325_25_cursor.path()[(v325_25_origin + 1)..(v325_25_origin + 2)]);
          let mut v329_7 = Space::new();
          let mut v329_7_write = v329_7.write_zipper();
          for v329_7_byte in v325_25_cursor.child_mask().iter() {
            v325_25_cursor.descend_to_existing_byte(v329_7_byte);
            {
            let v330_2: Space = singleton(&v325_25_cursor.path()[(v325_25_origin + 2)..(v325_25_origin + 3)]);
            let v330_3: Space = intersect(&(*CONSTANT_2),&(v330_2));
            let v330_4: Space = if has_head(&(v330_3)) { singleton(&[]) } else { Space::new() };
            drop(v330_3);
            let v330_5: Space = subtract(&(*CONSTANT_1),&(v330_4));
            drop(v330_4);
            let v330_8: Space = if (&(v330_5)).is_empty() { Space::new() } else {
              let v331_6: Path = concat_path(&(v329_6),&v325_25_cursor.path()[(v325_25_origin + 2)..(v325_25_origin + 3)]);
              let v331_7: Space = routine_25(c, &(v331_6), &(*p1), &v325_25_cursor, &(*s1));
              compose(&(v330_5),&(v331_7))
            };
            drop(v330_5);
            let v330_9: Space = intersect(&(*CONSTANT_2),&(v330_2));
            drop(v330_2);
            let v330_10: Space = if has_head(&(v330_9)) { singleton(&[]) } else { Space::new() };
            drop(v330_9);
            let v330_12: Space = if (&(v330_10)).is_empty() { Space::new() } else {
              let v332_6: Path = concat_path(&(v329_6),&v325_25_cursor.path()[(v325_25_origin + 2)..(v325_25_origin + 3)]);
              let v332_11: Space = routine_26(c, &(v332_6), &(*p1), &v325_25_cursor, &(*s1));
              drop(v332_6);
              compose(&(v330_10),&(v332_11))
            };
            drop(v330_10);
            let v330_13: Space = unite(&(v330_8),&(v330_12));
            join_wrapped_into(&mut v329_7_write,&((v330_13).read_zipper()),&[]);
            }
            v325_25_cursor.ascend(1);
          }
          drop(v329_7_write);
          compose(&(v328_5),&(v329_7))
        };
        drop(v328_5);
        let v328_9: Space = intersect(&(*CONSTANT_2),&(v328_2));
        drop(v328_2);
        let v328_10: Space = if has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
        drop(v328_9);
        let v328_12: Space = if (&(v328_10)).is_empty() { Space::new() } else {
          let v333_6: Path = concat_path(&(v327_6),&v325_25_cursor.path()[(v325_25_origin + 1)..(v325_25_origin + 2)]);
          let mut v333_11 = Space::new();
          let mut v333_11_write = v333_11.write_zipper();
          for v333_11_byte in v325_25_cursor.child_mask().iter() {
            v325_25_cursor.descend_to_existing_byte(v333_11_byte);
            {
            let v334_2: Space = singleton(&v325_25_cursor.path()[(v325_25_origin + 2)..(v325_25_origin + 3)]);
            let v334_3: Space = intersect(&(*CONSTANT_2),&(v334_2));
            let v334_4: Space = if has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
            drop(v334_3);
            let v334_5: Space = subtract(&(*CONSTANT_1),&(v334_4));
            drop(v334_4);
            let v334_8: Space = if (&(v334_5)).is_empty() { Space::new() } else {
              let v335_6: Path = concat_path(&(v333_6),&v325_25_cursor.path()[(v325_25_origin + 2)..(v325_25_origin + 3)]);
              let v335_7: Space = routine_25(c, &(v335_6), &(*p1), &v325_25_cursor, &(*s1));
              compose(&(v334_5),&(v335_7))
            };
            drop(v334_5);
            let v334_9: Space = intersect(&(*CONSTANT_2),&(v334_2));
            drop(v334_2);
            let v334_10: Space = if has_head(&(v334_9)) { singleton(&[]) } else { Space::new() };
            drop(v334_9);
            let v334_12: Space = if (&(v334_10)).is_empty() { Space::new() } else {
              let v336_6: Path = concat_path(&(v333_6),&v325_25_cursor.path()[(v325_25_origin + 2)..(v325_25_origin + 3)]);
              let v336_11: Space = routine_10(c, &(v336_6), &(*p1), &v325_25_cursor, &(*s1));
              drop(v336_6);
              compose(&(v334_10),&(v336_11))
            };
            drop(v334_10);
            let v334_13: Space = unite(&(v334_8),&(v334_12));
            join_wrapped_into(&mut v333_11_write,&((v334_13).read_zipper()),&[]);
            }
            v325_25_cursor.ascend(1);
          }
          drop(v333_11_write);
          drop(v333_6);
          compose(&(v328_10),&(v333_11))
        };
        drop(v328_10);
        let v328_13: Space = unite(&(v328_8),&(v328_12));
        join_wrapped_into(&mut v327_7_write,&((v328_13).read_zipper()),&[]);
        }
        v325_25_cursor.ascend(1);
      }
      drop(v327_7_write);
      compose(&(v326_5),&(v327_7))
    };
    drop(v326_5);
    let v326_9: Space = intersect(&(*CONSTANT_2),&(v326_2));
    drop(v326_2);
    let v326_10: Space = if has_head(&(v326_9)) { singleton(&[]) } else { Space::new() };
    drop(v326_9);
    let v326_13: Space = if (&(v326_10)).is_empty() { Space::new() } else {
      let v337_6: Path = concat_path(&(*p0),&v325_25_cursor.path()[v325_25_origin..(v325_25_origin + 1)]);
      let mut v337_12 = Space::new();
      let mut v337_12_write = v337_12.write_zipper();
      for v337_12_byte in v325_25_cursor.child_mask().iter() {
        v325_25_cursor.descend_to_existing_byte(v337_12_byte);
        {
        let v338_2: Space = singleton(&v325_25_cursor.path()[(v325_25_origin + 1)..(v325_25_origin + 2)]);
        let v338_3: Space = intersect(&(*CONSTANT_2),&(v338_2));
        let v338_4: Space = if has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
        drop(v338_3);
        let v338_5: Space = subtract(&(*CONSTANT_1),&(v338_4));
        drop(v338_4);
        let v338_8: Space = if (&(v338_5)).is_empty() { Space::new() } else {
          let v339_6: Path = concat_path(&(v337_6),&v325_25_cursor.path()[(v325_25_origin + 1)..(v325_25_origin + 2)]);
          let mut v339_7 = Space::new();
          let mut v339_7_write = v339_7.write_zipper();
          for v339_7_byte in v325_25_cursor.child_mask().iter() {
            v325_25_cursor.descend_to_existing_byte(v339_7_byte);
            {
            let v340_2: Space = singleton(&v325_25_cursor.path()[(v325_25_origin + 2)..(v325_25_origin + 3)]);
            let v340_3: Space = intersect(&(*CONSTANT_2),&(v340_2));
            let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
            drop(v340_3);
            let v340_5: Space = subtract(&(*CONSTANT_1),&(v340_4));
            drop(v340_4);
            let v340_8: Space = if (&(v340_5)).is_empty() { Space::new() } else {
              let v341_6: Path = concat_path(&(v339_6),&v325_25_cursor.path()[(v325_25_origin + 2)..(v325_25_origin + 3)]);
              let v341_7: Space = routine_25(c, &(v341_6), &(*p1), &v325_25_cursor, &(*s1));
              compose(&(v340_5),&(v341_7))
            };
            drop(v340_5);
            let v340_9: Space = intersect(&(*CONSTANT_2),&(v340_2));
            drop(v340_2);
            let v340_10: Space = if has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
            drop(v340_9);
            let v340_12: Space = if (&(v340_10)).is_empty() { Space::new() } else {
              let v342_6: Path = concat_path(&(v339_6),&v325_25_cursor.path()[(v325_25_origin + 2)..(v325_25_origin + 3)]);
              let v342_11: Space = routine_26(c, &(v342_6), &(*p1), &v325_25_cursor, &(*s1));
              drop(v342_6);
              compose(&(v340_10),&(v342_11))
            };
            drop(v340_10);
            let v340_13: Space = unite(&(v340_8),&(v340_12));
            join_wrapped_into(&mut v339_7_write,&((v340_13).read_zipper()),&[]);
            }
            v325_25_cursor.ascend(1);
          }
          drop(v339_7_write);
          compose(&(v338_5),&(v339_7))
        };
        drop(v338_5);
        let v338_9: Space = intersect(&(*CONSTANT_2),&(v338_2));
        drop(v338_2);
        let v338_10: Space = if has_head(&(v338_9)) { singleton(&[]) } else { Space::new() };
        drop(v338_9);
        let v338_13: Space = if (&(v338_10)).is_empty() { Space::new() } else {
          compose(&(v338_10),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v325_25_cursor.path()[v325_25_origin..(v325_25_origin + 1)]),&v325_25_cursor.path()[(v325_25_origin + 1)..(v325_25_origin + 2)]),&(*p1))))
        };
        drop(v338_10);
        let v344_6: Path = concat_path(&(v337_6),&v325_25_cursor.path()[(v325_25_origin + 1)..(v325_25_origin + 2)]);
        let v338_14: Space = wrap(&(v338_13),&(v344_6));
        drop(v338_13);
        let v338_15: Space = wrap(&(v338_14),&(*p1));
        drop(v338_14);
        let v338_16: Space = unite(&(v338_8),&(v338_15));
        drop(v338_15);
        join_wrapped_into(&mut v337_12_write,&((v338_16).read_zipper()),&[]);
        }
        v325_25_cursor.ascend(1);
      }
      drop(v337_12_write);
      drop(v337_6);
      compose(&(v326_10),&(v337_12))
    };
    drop(v326_10);
    let v326_14: Space = unite(&(v326_8),&(v326_13));
    join_wrapped_into(&mut v325_25_write,&((v326_14).read_zipper()),&[]);
    }
    v325_25_cursor.ascend(1);
  }
  drop(v325_25_cursor);
  drop(v325_25_write);
  (v325_25).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v345_19 = Space::new();
  let mut v345_19_write = v345_19.write_zipper();
  let mut v345_19_cursor = (*s0).read_zipper();
  let v345_19_origin = v345_19_cursor.path().len();
  for v345_19_byte in v345_19_cursor.child_mask().iter() {
    v345_19_cursor.descend_to_existing_byte(v345_19_byte);
    {
    let v346_2: Space = singleton(&v345_19_cursor.path()[v345_19_origin..(v345_19_origin + 1)]);
    let v346_3: Space = intersect(&(*CONSTANT_2),&(v346_2));
    let v346_4: Space = if has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
    drop(v346_3);
    let v346_5: Space = subtract(&(*CONSTANT_1),&(v346_4));
    drop(v346_4);
    let v346_8: Space = if (&(v346_5)).is_empty() { Space::new() } else {
      let v347_6: Path = concat_path(&(*p0),&v345_19_cursor.path()[v345_19_origin..(v345_19_origin + 1)]);
      let mut v347_7 = Space::new();
      let mut v347_7_write = v347_7.write_zipper();
      for v347_7_byte in v345_19_cursor.child_mask().iter() {
        v345_19_cursor.descend_to_existing_byte(v347_7_byte);
        {
        let v348_2: Space = singleton(&v345_19_cursor.path()[(v345_19_origin + 1)..(v345_19_origin + 2)]);
        let v348_3: Space = intersect(&(*CONSTANT_2),&(v348_2));
        let v348_4: Space = if has_head(&(v348_3)) { singleton(&[]) } else { Space::new() };
        drop(v348_3);
        let v348_5: Space = subtract(&(*CONSTANT_1),&(v348_4));
        drop(v348_4);
        let v348_8: Space = if (&(v348_5)).is_empty() { Space::new() } else {
          let v349_6: Path = concat_path(&(v347_6),&v345_19_cursor.path()[(v345_19_origin + 1)..(v345_19_origin + 2)]);
          let mut v349_7 = Space::new();
          let mut v349_7_write = v349_7.write_zipper();
          for v349_7_byte in v345_19_cursor.child_mask().iter() {
            v345_19_cursor.descend_to_existing_byte(v349_7_byte);
            {
            let v350_2: Space = singleton(&v345_19_cursor.path()[(v345_19_origin + 2)..(v345_19_origin + 3)]);
            let v350_3: Space = intersect(&(*CONSTANT_2),&(v350_2));
            let v350_4: Space = if has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
            drop(v350_3);
            let v350_5: Space = subtract(&(*CONSTANT_1),&(v350_4));
            drop(v350_4);
            let v350_8: Space = if (&(v350_5)).is_empty() { Space::new() } else {
              let v351_6: Path = concat_path(&(v349_6),&v345_19_cursor.path()[(v345_19_origin + 2)..(v345_19_origin + 3)]);
              let v351_7: Space = routine_25(c, &(v351_6), &(*p1), &v345_19_cursor, &(*s1));
              compose(&(v350_5),&(v351_7))
            };
            drop(v350_5);
            let v350_9: Space = intersect(&(*CONSTANT_2),&(v350_2));
            drop(v350_2);
            let v350_10: Space = if has_head(&(v350_9)) { singleton(&[]) } else { Space::new() };
            drop(v350_9);
            let v350_12: Space = if (&(v350_10)).is_empty() { Space::new() } else {
              let v352_6: Path = concat_path(&(v349_6),&v345_19_cursor.path()[(v345_19_origin + 2)..(v345_19_origin + 3)]);
              let v352_11: Space = routine_26(c, &(v352_6), &(*p1), &v345_19_cursor, &(*s1));
              drop(v352_6);
              compose(&(v350_10),&(v352_11))
            };
            drop(v350_10);
            let v350_13: Space = unite(&(v350_8),&(v350_12));
            join_wrapped_into(&mut v349_7_write,&((v350_13).read_zipper()),&[]);
            }
            v345_19_cursor.ascend(1);
          }
          drop(v349_7_write);
          compose(&(v348_5),&(v349_7))
        };
        drop(v348_5);
        let v348_9: Space = intersect(&(*CONSTANT_2),&(v348_2));
        drop(v348_2);
        let v348_10: Space = if has_head(&(v348_9)) { singleton(&[]) } else { Space::new() };
        drop(v348_9);
        let v348_12: Space = if (&(v348_10)).is_empty() { Space::new() } else {
          let v353_6: Path = concat_path(&(v347_6),&v345_19_cursor.path()[(v345_19_origin + 1)..(v345_19_origin + 2)]);
          let mut v353_11 = Space::new();
          let mut v353_11_write = v353_11.write_zipper();
          for v353_11_byte in v345_19_cursor.child_mask().iter() {
            v345_19_cursor.descend_to_existing_byte(v353_11_byte);
            {
            let v354_2: Space = singleton(&v345_19_cursor.path()[(v345_19_origin + 2)..(v345_19_origin + 3)]);
            let v354_3: Space = intersect(&(*CONSTANT_2),&(v354_2));
            let v354_4: Space = if has_head(&(v354_3)) { singleton(&[]) } else { Space::new() };
            drop(v354_3);
            let v354_5: Space = subtract(&(*CONSTANT_1),&(v354_4));
            drop(v354_4);
            let v354_8: Space = if (&(v354_5)).is_empty() { Space::new() } else {
              let v355_6: Path = concat_path(&(v353_6),&v345_19_cursor.path()[(v345_19_origin + 2)..(v345_19_origin + 3)]);
              let v355_7: Space = routine_25(c, &(v355_6), &(*p1), &v345_19_cursor, &(*s1));
              compose(&(v354_5),&(v355_7))
            };
            drop(v354_5);
            let v354_9: Space = intersect(&(*CONSTANT_2),&(v354_2));
            drop(v354_2);
            let v354_10: Space = if has_head(&(v354_9)) { singleton(&[]) } else { Space::new() };
            drop(v354_9);
            let v354_12: Space = if (&(v354_10)).is_empty() { Space::new() } else {
              let v356_6: Path = concat_path(&(v353_6),&v345_19_cursor.path()[(v345_19_origin + 2)..(v345_19_origin + 3)]);
              let v356_11: Space = routine_10(c, &(v356_6), &(*p1), &v345_19_cursor, &(*s1));
              drop(v356_6);
              compose(&(v354_10),&(v356_11))
            };
            drop(v354_10);
            let v354_13: Space = unite(&(v354_8),&(v354_12));
            join_wrapped_into(&mut v353_11_write,&((v354_13).read_zipper()),&[]);
            }
            v345_19_cursor.ascend(1);
          }
          drop(v353_11_write);
          drop(v353_6);
          compose(&(v348_10),&(v353_11))
        };
        drop(v348_10);
        let v348_13: Space = unite(&(v348_8),&(v348_12));
        join_wrapped_into(&mut v347_7_write,&((v348_13).read_zipper()),&[]);
        }
        v345_19_cursor.ascend(1);
      }
      drop(v347_7_write);
      compose(&(v346_5),&(v347_7))
    };
    drop(v346_5);
    let v346_9: Space = intersect(&(*CONSTANT_2),&(v346_2));
    drop(v346_2);
    let v346_10: Space = if has_head(&(v346_9)) { singleton(&[]) } else { Space::new() };
    drop(v346_9);
    let v346_13: Space = if (&(v346_10)).is_empty() { Space::new() } else {
      compose(&(v346_10),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v345_19_cursor.path()[v345_19_origin..(v345_19_origin + 1)]),&(*p1))))
    };
    drop(v346_10);
    let v358_6: Path = concat_path(&(*p0),&v345_19_cursor.path()[v345_19_origin..(v345_19_origin + 1)]);
    let v346_14: Space = wrap(&(v346_13),&(v358_6));
    drop(v346_13);
    let v346_15: Space = wrap(&(v346_14),&(*p1));
    drop(v346_14);
    let v346_16: Space = unite(&(v346_8),&(v346_15));
    drop(v346_15);
    join_wrapped_into(&mut v345_19_write,&((v346_16).read_zipper()),&[]);
    }
    v345_19_cursor.ascend(1);
  }
  drop(v345_19_cursor);
  drop(v345_19_write);
  (v345_19).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v359_25 = Space::new();
  let mut v359_25_write = v359_25.write_zipper();
  let mut v359_25_cursor = (*s0).read_zipper();
  let v359_25_origin = v359_25_cursor.path().len();
  for v359_25_byte in v359_25_cursor.child_mask().iter() {
    v359_25_cursor.descend_to_existing_byte(v359_25_byte);
    {
    let v360_2: Space = singleton(&v359_25_cursor.path()[v359_25_origin..(v359_25_origin + 1)]);
    let v360_3: Space = intersect(&(*CONSTANT_2),&(v360_2));
    let v360_4: Space = if has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
    drop(v360_3);
    let v360_5: Space = subtract(&(*CONSTANT_1),&(v360_4));
    drop(v360_4);
    let v360_8: Space = if (&(v360_5)).is_empty() { Space::new() } else {
      let v361_6: Path = concat_path(&(*p0),&v359_25_cursor.path()[v359_25_origin..(v359_25_origin + 1)]);
      let mut v361_7 = Space::new();
      let mut v361_7_write = v361_7.write_zipper();
      for v361_7_byte in v359_25_cursor.child_mask().iter() {
        v359_25_cursor.descend_to_existing_byte(v361_7_byte);
        {
        let v362_2: Space = singleton(&v359_25_cursor.path()[(v359_25_origin + 1)..(v359_25_origin + 2)]);
        let v362_3: Space = intersect(&(*CONSTANT_2),&(v362_2));
        let v362_4: Space = if has_head(&(v362_3)) { singleton(&[]) } else { Space::new() };
        drop(v362_3);
        let v362_5: Space = subtract(&(*CONSTANT_1),&(v362_4));
        drop(v362_4);
        let v362_8: Space = if (&(v362_5)).is_empty() { Space::new() } else {
          let v363_6: Path = concat_path(&(v361_6),&v359_25_cursor.path()[(v359_25_origin + 1)..(v359_25_origin + 2)]);
          let mut v363_7 = Space::new();
          let mut v363_7_write = v363_7.write_zipper();
          for v363_7_byte in v359_25_cursor.child_mask().iter() {
            v359_25_cursor.descend_to_existing_byte(v363_7_byte);
            {
            let v364_2: Space = singleton(&v359_25_cursor.path()[(v359_25_origin + 2)..(v359_25_origin + 3)]);
            let v364_3: Space = intersect(&(*CONSTANT_2),&(v364_2));
            let v364_4: Space = if has_head(&(v364_3)) { singleton(&[]) } else { Space::new() };
            drop(v364_3);
            let v364_5: Space = subtract(&(*CONSTANT_1),&(v364_4));
            drop(v364_4);
            let v364_8: Space = if (&(v364_5)).is_empty() { Space::new() } else {
              let v365_6: Path = concat_path(&(v363_6),&v359_25_cursor.path()[(v359_25_origin + 2)..(v359_25_origin + 3)]);
              let v365_7: Space = routine_27(c, &(v365_6), &(*p1), &v359_25_cursor, &(*s1));
              compose(&(v364_5),&(v365_7))
            };
            drop(v364_5);
            let v364_9: Space = intersect(&(*CONSTANT_2),&(v364_2));
            drop(v364_2);
            let v364_10: Space = if has_head(&(v364_9)) { singleton(&[]) } else { Space::new() };
            drop(v364_9);
            let v364_12: Space = if (&(v364_10)).is_empty() { Space::new() } else {
              let v366_6: Path = concat_path(&(v363_6),&v359_25_cursor.path()[(v359_25_origin + 2)..(v359_25_origin + 3)]);
              let v366_11: Space = routine_28(c, &(v366_6), &(*p1), &v359_25_cursor, &(*s1));
              drop(v366_6);
              compose(&(v364_10),&(v366_11))
            };
            drop(v364_10);
            let v364_13: Space = unite(&(v364_8),&(v364_12));
            join_wrapped_into(&mut v363_7_write,&((v364_13).read_zipper()),&[]);
            }
            v359_25_cursor.ascend(1);
          }
          drop(v363_7_write);
          compose(&(v362_5),&(v363_7))
        };
        drop(v362_5);
        let v362_9: Space = intersect(&(*CONSTANT_2),&(v362_2));
        drop(v362_2);
        let v362_10: Space = if has_head(&(v362_9)) { singleton(&[]) } else { Space::new() };
        drop(v362_9);
        let v362_12: Space = if (&(v362_10)).is_empty() { Space::new() } else {
          let v367_6: Path = concat_path(&(v361_6),&v359_25_cursor.path()[(v359_25_origin + 1)..(v359_25_origin + 2)]);
          let mut v367_11 = Space::new();
          let mut v367_11_write = v367_11.write_zipper();
          for v367_11_byte in v359_25_cursor.child_mask().iter() {
            v359_25_cursor.descend_to_existing_byte(v367_11_byte);
            {
            let v368_2: Space = singleton(&v359_25_cursor.path()[(v359_25_origin + 2)..(v359_25_origin + 3)]);
            let v368_3: Space = intersect(&(*CONSTANT_2),&(v368_2));
            let v368_4: Space = if has_head(&(v368_3)) { singleton(&[]) } else { Space::new() };
            drop(v368_3);
            let v368_5: Space = subtract(&(*CONSTANT_1),&(v368_4));
            drop(v368_4);
            let v368_8: Space = if (&(v368_5)).is_empty() { Space::new() } else {
              let v369_6: Path = concat_path(&(v367_6),&v359_25_cursor.path()[(v359_25_origin + 2)..(v359_25_origin + 3)]);
              let v369_7: Space = routine_27(c, &(v369_6), &(*p1), &v359_25_cursor, &(*s1));
              compose(&(v368_5),&(v369_7))
            };
            drop(v368_5);
            let v368_9: Space = intersect(&(*CONSTANT_2),&(v368_2));
            drop(v368_2);
            let v368_10: Space = if has_head(&(v368_9)) { singleton(&[]) } else { Space::new() };
            drop(v368_9);
            let v368_12: Space = if (&(v368_10)).is_empty() { Space::new() } else {
              let v370_6: Path = concat_path(&(v367_6),&v359_25_cursor.path()[(v359_25_origin + 2)..(v359_25_origin + 3)]);
              let v370_11: Space = routine_10(c, &(v370_6), &(*p1), &v359_25_cursor, &(*s1));
              drop(v370_6);
              compose(&(v368_10),&(v370_11))
            };
            drop(v368_10);
            let v368_13: Space = unite(&(v368_8),&(v368_12));
            join_wrapped_into(&mut v367_11_write,&((v368_13).read_zipper()),&[]);
            }
            v359_25_cursor.ascend(1);
          }
          drop(v367_11_write);
          drop(v367_6);
          compose(&(v362_10),&(v367_11))
        };
        drop(v362_10);
        let v362_13: Space = unite(&(v362_8),&(v362_12));
        join_wrapped_into(&mut v361_7_write,&((v362_13).read_zipper()),&[]);
        }
        v359_25_cursor.ascend(1);
      }
      drop(v361_7_write);
      compose(&(v360_5),&(v361_7))
    };
    drop(v360_5);
    let v360_9: Space = intersect(&(*CONSTANT_2),&(v360_2));
    drop(v360_2);
    let v360_10: Space = if has_head(&(v360_9)) { singleton(&[]) } else { Space::new() };
    drop(v360_9);
    let v360_13: Space = if (&(v360_10)).is_empty() { Space::new() } else {
      let v371_6: Path = concat_path(&(*p0),&v359_25_cursor.path()[v359_25_origin..(v359_25_origin + 1)]);
      let mut v371_12 = Space::new();
      let mut v371_12_write = v371_12.write_zipper();
      for v371_12_byte in v359_25_cursor.child_mask().iter() {
        v359_25_cursor.descend_to_existing_byte(v371_12_byte);
        {
        let v372_2: Space = singleton(&v359_25_cursor.path()[(v359_25_origin + 1)..(v359_25_origin + 2)]);
        let v372_3: Space = intersect(&(*CONSTANT_2),&(v372_2));
        let v372_4: Space = if has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
        drop(v372_3);
        let v372_5: Space = subtract(&(*CONSTANT_1),&(v372_4));
        drop(v372_4);
        let v372_8: Space = if (&(v372_5)).is_empty() { Space::new() } else {
          let v373_6: Path = concat_path(&(v371_6),&v359_25_cursor.path()[(v359_25_origin + 1)..(v359_25_origin + 2)]);
          let mut v373_7 = Space::new();
          let mut v373_7_write = v373_7.write_zipper();
          for v373_7_byte in v359_25_cursor.child_mask().iter() {
            v359_25_cursor.descend_to_existing_byte(v373_7_byte);
            {
            let v374_2: Space = singleton(&v359_25_cursor.path()[(v359_25_origin + 2)..(v359_25_origin + 3)]);
            let v374_3: Space = intersect(&(*CONSTANT_2),&(v374_2));
            let v374_4: Space = if has_head(&(v374_3)) { singleton(&[]) } else { Space::new() };
            drop(v374_3);
            let v374_5: Space = subtract(&(*CONSTANT_1),&(v374_4));
            drop(v374_4);
            let v374_8: Space = if (&(v374_5)).is_empty() { Space::new() } else {
              let v375_6: Path = concat_path(&(v373_6),&v359_25_cursor.path()[(v359_25_origin + 2)..(v359_25_origin + 3)]);
              let v375_7: Space = routine_27(c, &(v375_6), &(*p1), &v359_25_cursor, &(*s1));
              compose(&(v374_5),&(v375_7))
            };
            drop(v374_5);
            let v374_9: Space = intersect(&(*CONSTANT_2),&(v374_2));
            drop(v374_2);
            let v374_10: Space = if has_head(&(v374_9)) { singleton(&[]) } else { Space::new() };
            drop(v374_9);
            let v374_12: Space = if (&(v374_10)).is_empty() { Space::new() } else {
              let v376_6: Path = concat_path(&(v373_6),&v359_25_cursor.path()[(v359_25_origin + 2)..(v359_25_origin + 3)]);
              let v376_11: Space = routine_28(c, &(v376_6), &(*p1), &v359_25_cursor, &(*s1));
              drop(v376_6);
              compose(&(v374_10),&(v376_11))
            };
            drop(v374_10);
            let v374_13: Space = unite(&(v374_8),&(v374_12));
            join_wrapped_into(&mut v373_7_write,&((v374_13).read_zipper()),&[]);
            }
            v359_25_cursor.ascend(1);
          }
          drop(v373_7_write);
          compose(&(v372_5),&(v373_7))
        };
        drop(v372_5);
        let v372_9: Space = intersect(&(*CONSTANT_2),&(v372_2));
        drop(v372_2);
        let v372_10: Space = if has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
        drop(v372_9);
        let v372_13: Space = if (&(v372_10)).is_empty() { Space::new() } else {
          compose(&(v372_10),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v359_25_cursor.path()[v359_25_origin..(v359_25_origin + 1)]),&v359_25_cursor.path()[(v359_25_origin + 1)..(v359_25_origin + 2)]),&(*p1))))
        };
        drop(v372_10);
        let v378_6: Path = concat_path(&(v371_6),&v359_25_cursor.path()[(v359_25_origin + 1)..(v359_25_origin + 2)]);
        let v372_14: Space = wrap(&(v372_13),&(v378_6));
        drop(v372_13);
        let v372_15: Space = wrap(&(v372_14),&(*p1));
        drop(v372_14);
        let v372_16: Space = unite(&(v372_8),&(v372_15));
        drop(v372_15);
        join_wrapped_into(&mut v371_12_write,&((v372_16).read_zipper()),&[]);
        }
        v359_25_cursor.ascend(1);
      }
      drop(v371_12_write);
      drop(v371_6);
      compose(&(v360_10),&(v371_12))
    };
    drop(v360_10);
    let v360_14: Space = unite(&(v360_8),&(v360_13));
    join_wrapped_into(&mut v359_25_write,&((v360_14).read_zipper()),&[]);
    }
    v359_25_cursor.ascend(1);
  }
  drop(v359_25_cursor);
  drop(v359_25_write);
  (v359_25).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v379_19 = Space::new();
  let mut v379_19_write = v379_19.write_zipper();
  let mut v379_19_cursor = (*s0).read_zipper();
  let v379_19_origin = v379_19_cursor.path().len();
  for v379_19_byte in v379_19_cursor.child_mask().iter() {
    v379_19_cursor.descend_to_existing_byte(v379_19_byte);
    {
    let v380_2: Space = singleton(&v379_19_cursor.path()[v379_19_origin..(v379_19_origin + 1)]);
    let v380_3: Space = intersect(&(*CONSTANT_2),&(v380_2));
    let v380_4: Space = if has_head(&(v380_3)) { singleton(&[]) } else { Space::new() };
    drop(v380_3);
    let v380_5: Space = subtract(&(*CONSTANT_1),&(v380_4));
    drop(v380_4);
    let v380_8: Space = if (&(v380_5)).is_empty() { Space::new() } else {
      let v381_6: Path = concat_path(&(*p0),&v379_19_cursor.path()[v379_19_origin..(v379_19_origin + 1)]);
      let mut v381_7 = Space::new();
      let mut v381_7_write = v381_7.write_zipper();
      for v381_7_byte in v379_19_cursor.child_mask().iter() {
        v379_19_cursor.descend_to_existing_byte(v381_7_byte);
        {
        let v382_2: Space = singleton(&v379_19_cursor.path()[(v379_19_origin + 1)..(v379_19_origin + 2)]);
        let v382_3: Space = intersect(&(*CONSTANT_2),&(v382_2));
        let v382_4: Space = if has_head(&(v382_3)) { singleton(&[]) } else { Space::new() };
        drop(v382_3);
        let v382_5: Space = subtract(&(*CONSTANT_1),&(v382_4));
        drop(v382_4);
        let v382_8: Space = if (&(v382_5)).is_empty() { Space::new() } else {
          let v383_6: Path = concat_path(&(v381_6),&v379_19_cursor.path()[(v379_19_origin + 1)..(v379_19_origin + 2)]);
          let mut v383_7 = Space::new();
          let mut v383_7_write = v383_7.write_zipper();
          for v383_7_byte in v379_19_cursor.child_mask().iter() {
            v379_19_cursor.descend_to_existing_byte(v383_7_byte);
            {
            let v384_2: Space = singleton(&v379_19_cursor.path()[(v379_19_origin + 2)..(v379_19_origin + 3)]);
            let v384_3: Space = intersect(&(*CONSTANT_2),&(v384_2));
            let v384_4: Space = if has_head(&(v384_3)) { singleton(&[]) } else { Space::new() };
            drop(v384_3);
            let v384_5: Space = subtract(&(*CONSTANT_1),&(v384_4));
            drop(v384_4);
            let v384_8: Space = if (&(v384_5)).is_empty() { Space::new() } else {
              let v385_6: Path = concat_path(&(v383_6),&v379_19_cursor.path()[(v379_19_origin + 2)..(v379_19_origin + 3)]);
              let v385_7: Space = routine_27(c, &(v385_6), &(*p1), &v379_19_cursor, &(*s1));
              compose(&(v384_5),&(v385_7))
            };
            drop(v384_5);
            let v384_9: Space = intersect(&(*CONSTANT_2),&(v384_2));
            drop(v384_2);
            let v384_10: Space = if has_head(&(v384_9)) { singleton(&[]) } else { Space::new() };
            drop(v384_9);
            let v384_12: Space = if (&(v384_10)).is_empty() { Space::new() } else {
              let v386_6: Path = concat_path(&(v383_6),&v379_19_cursor.path()[(v379_19_origin + 2)..(v379_19_origin + 3)]);
              let v386_11: Space = routine_28(c, &(v386_6), &(*p1), &v379_19_cursor, &(*s1));
              drop(v386_6);
              compose(&(v384_10),&(v386_11))
            };
            drop(v384_10);
            let v384_13: Space = unite(&(v384_8),&(v384_12));
            join_wrapped_into(&mut v383_7_write,&((v384_13).read_zipper()),&[]);
            }
            v379_19_cursor.ascend(1);
          }
          drop(v383_7_write);
          compose(&(v382_5),&(v383_7))
        };
        drop(v382_5);
        let v382_9: Space = intersect(&(*CONSTANT_2),&(v382_2));
        drop(v382_2);
        let v382_10: Space = if has_head(&(v382_9)) { singleton(&[]) } else { Space::new() };
        drop(v382_9);
        let v382_12: Space = if (&(v382_10)).is_empty() { Space::new() } else {
          let v387_6: Path = concat_path(&(v381_6),&v379_19_cursor.path()[(v379_19_origin + 1)..(v379_19_origin + 2)]);
          let mut v387_11 = Space::new();
          let mut v387_11_write = v387_11.write_zipper();
          for v387_11_byte in v379_19_cursor.child_mask().iter() {
            v379_19_cursor.descend_to_existing_byte(v387_11_byte);
            {
            let v388_2: Space = singleton(&v379_19_cursor.path()[(v379_19_origin + 2)..(v379_19_origin + 3)]);
            let v388_3: Space = intersect(&(*CONSTANT_2),&(v388_2));
            let v388_4: Space = if has_head(&(v388_3)) { singleton(&[]) } else { Space::new() };
            drop(v388_3);
            let v388_5: Space = subtract(&(*CONSTANT_1),&(v388_4));
            drop(v388_4);
            let v388_8: Space = if (&(v388_5)).is_empty() { Space::new() } else {
              let v389_6: Path = concat_path(&(v387_6),&v379_19_cursor.path()[(v379_19_origin + 2)..(v379_19_origin + 3)]);
              let v389_7: Space = routine_27(c, &(v389_6), &(*p1), &v379_19_cursor, &(*s1));
              compose(&(v388_5),&(v389_7))
            };
            drop(v388_5);
            let v388_9: Space = intersect(&(*CONSTANT_2),&(v388_2));
            drop(v388_2);
            let v388_10: Space = if has_head(&(v388_9)) { singleton(&[]) } else { Space::new() };
            drop(v388_9);
            let v388_12: Space = if (&(v388_10)).is_empty() { Space::new() } else {
              let v390_6: Path = concat_path(&(v387_6),&v379_19_cursor.path()[(v379_19_origin + 2)..(v379_19_origin + 3)]);
              let v390_11: Space = routine_10(c, &(v390_6), &(*p1), &v379_19_cursor, &(*s1));
              drop(v390_6);
              compose(&(v388_10),&(v390_11))
            };
            drop(v388_10);
            let v388_13: Space = unite(&(v388_8),&(v388_12));
            join_wrapped_into(&mut v387_11_write,&((v388_13).read_zipper()),&[]);
            }
            v379_19_cursor.ascend(1);
          }
          drop(v387_11_write);
          drop(v387_6);
          compose(&(v382_10),&(v387_11))
        };
        drop(v382_10);
        let v382_13: Space = unite(&(v382_8),&(v382_12));
        join_wrapped_into(&mut v381_7_write,&((v382_13).read_zipper()),&[]);
        }
        v379_19_cursor.ascend(1);
      }
      drop(v381_7_write);
      compose(&(v380_5),&(v381_7))
    };
    drop(v380_5);
    let v380_9: Space = intersect(&(*CONSTANT_2),&(v380_2));
    drop(v380_2);
    let v380_10: Space = if has_head(&(v380_9)) { singleton(&[]) } else { Space::new() };
    drop(v380_9);
    let v380_13: Space = if (&(v380_10)).is_empty() { Space::new() } else {
      compose(&(v380_10),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v379_19_cursor.path()[v379_19_origin..(v379_19_origin + 1)]),&(*p1))))
    };
    drop(v380_10);
    let v392_6: Path = concat_path(&(*p0),&v379_19_cursor.path()[v379_19_origin..(v379_19_origin + 1)]);
    let v380_14: Space = wrap(&(v380_13),&(v392_6));
    drop(v380_13);
    let v380_15: Space = wrap(&(v380_14),&(*p1));
    drop(v380_14);
    let v380_16: Space = unite(&(v380_8),&(v380_15));
    drop(v380_15);
    join_wrapped_into(&mut v379_19_write,&((v380_16).read_zipper()),&[]);
    }
    v379_19_cursor.ascend(1);
  }
  drop(v379_19_cursor);
  drop(v379_19_write);
  (v379_19).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v393_17 = Space::new();
  let mut v393_17_write = v393_17.write_zipper();
  let mut v393_17_cursor = (*s0).read_zipper();
  let v393_17_origin = v393_17_cursor.path().len();
  for v393_17_byte in v393_17_cursor.child_mask().iter() {
    v393_17_cursor.descend_to_existing_byte(v393_17_byte);
    {
    let v394_2: Space = singleton(&v393_17_cursor.path()[v393_17_origin..(v393_17_origin + 1)]);
    let v394_3: Space = intersect(&(*CONSTANT_2),&(v394_2));
    let v394_4: Space = if has_head(&(v394_3)) { singleton(&[]) } else { Space::new() };
    drop(v394_3);
    let v394_5: Space = subtract(&(*CONSTANT_1),&(v394_4));
    drop(v394_4);
    let v394_8: Space = if (&(v394_5)).is_empty() { Space::new() } else {
      let v395_6: Path = concat_path(&(*p0),&v393_17_cursor.path()[v393_17_origin..(v393_17_origin + 1)]);
      let mut v395_7 = Space::new();
      let mut v395_7_write = v395_7.write_zipper();
      for v395_7_byte in v393_17_cursor.child_mask().iter() {
        v393_17_cursor.descend_to_existing_byte(v395_7_byte);
        {
        let v396_2: Space = singleton(&v393_17_cursor.path()[(v393_17_origin + 1)..(v393_17_origin + 2)]);
        let v396_3: Space = intersect(&(*CONSTANT_2),&(v396_2));
        let v396_4: Space = if has_head(&(v396_3)) { singleton(&[]) } else { Space::new() };
        drop(v396_3);
        let v396_5: Space = subtract(&(*CONSTANT_1),&(v396_4));
        drop(v396_4);
        let v396_7: Space = if (&(v396_5)).is_empty() { Space::new() } else {
          let mut v397_6 = Space::new();
          let mut v397_6_write = v397_6.write_zipper();
          for v397_6_byte in v393_17_cursor.child_mask().iter() {
            v393_17_cursor.descend_to_existing_byte(v397_6_byte);
            {
            let v398_2: Space = Space::new();
            join_wrapped_into(&mut v397_6_write,&((v398_2).read_zipper()),&[]);
            }
            v393_17_cursor.ascend(1);
          }
          drop(v397_6_write);
          compose(&(v396_5),&(v397_6))
        };
        drop(v396_5);
        let v396_8: Space = intersect(&(*CONSTANT_2),&(v396_2));
        drop(v396_2);
        let v396_9: Space = if has_head(&(v396_8)) { singleton(&[]) } else { Space::new() };
        drop(v396_8);
        let v396_12: Space = if (&(v396_9)).is_empty() { Space::new() } else {
          let v399_10: Path = concat_path(&(v395_6),&v393_17_cursor.path()[(v393_17_origin + 1)..(v393_17_origin + 2)]);
          let mut v399_11 = Space::new();
          let mut v399_11_write = v399_11.write_zipper();
          for v399_11_byte in v393_17_cursor.child_mask().iter() {
            v393_17_cursor.descend_to_existing_byte(v399_11_byte);
            {
            let v400_2: Space = singleton(&v393_17_cursor.path()[(v393_17_origin + 2)..(v393_17_origin + 3)]);
            let v400_3: Space = intersect(&(*CONSTANT_2),&(v400_2));
            drop(v400_2);
            let v400_4: Space = if has_head(&(v400_3)) { singleton(&[]) } else { Space::new() };
            drop(v400_3);
            let v400_7: Space = if (&(v400_4)).is_empty() { Space::new() } else {
              let v401_5: Path = concat_path(&(v399_10),&v393_17_cursor.path()[(v393_17_origin + 2)..(v393_17_origin + 3)]);
              let v401_6: Space = routine_10(c, &(v401_5), &(*p1), &v393_17_cursor, &(*s1));
              drop(v401_5);
              compose(&(v400_4),&(v401_6))
            };
            drop(v400_4);
            join_wrapped_into(&mut v399_11_write,&((v400_7).read_zipper()),&[]);
            }
            v393_17_cursor.ascend(1);
          }
          drop(v399_11_write);
          drop(v399_10);
          compose(&(v396_9),&(v399_11))
        };
        drop(v396_9);
        let v396_13: Space = unite(&(v396_7),&(v396_12));
        drop(v396_7);
        join_wrapped_into(&mut v395_7_write,&((v396_13).read_zipper()),&[]);
        }
        v393_17_cursor.ascend(1);
      }
      drop(v395_7_write);
      compose(&(v394_5),&(v395_7))
    };
    drop(v394_5);
    let v394_9: Space = intersect(&(*CONSTANT_2),&(v394_2));
    drop(v394_2);
    let v394_10: Space = if has_head(&(v394_9)) { singleton(&[]) } else { Space::new() };
    drop(v394_9);
    let v394_13: Space = if (&(v394_10)).is_empty() { Space::new() } else {
      let v402_6: Path = concat_path(&(*p0),&v393_17_cursor.path()[v393_17_origin..(v393_17_origin + 1)]);
      let mut v402_12 = Space::new();
      let mut v402_12_write = v402_12.write_zipper();
      for v402_12_byte in v393_17_cursor.child_mask().iter() {
        v393_17_cursor.descend_to_existing_byte(v402_12_byte);
        {
        let v403_2: Space = singleton(&v393_17_cursor.path()[(v393_17_origin + 1)..(v393_17_origin + 2)]);
        let v403_3: Space = intersect(&(*CONSTANT_2),&(v403_2));
        let v403_4: Space = if has_head(&(v403_3)) { singleton(&[]) } else { Space::new() };
        drop(v403_3);
        let v403_5: Space = subtract(&(*CONSTANT_1),&(v403_4));
        drop(v403_4);
        let v403_7: Space = if (&(v403_5)).is_empty() { Space::new() } else {
          let mut v404_6 = Space::new();
          let mut v404_6_write = v404_6.write_zipper();
          for v404_6_byte in v393_17_cursor.child_mask().iter() {
            v393_17_cursor.descend_to_existing_byte(v404_6_byte);
            {
            let v405_2: Space = Space::new();
            join_wrapped_into(&mut v404_6_write,&((v405_2).read_zipper()),&[]);
            }
            v393_17_cursor.ascend(1);
          }
          drop(v404_6_write);
          compose(&(v403_5),&(v404_6))
        };
        drop(v403_5);
        let v403_8: Space = intersect(&(*CONSTANT_2),&(v403_2));
        drop(v403_2);
        let v403_9: Space = if has_head(&(v403_8)) { singleton(&[]) } else { Space::new() };
        drop(v403_8);
        let v403_12: Space = if (&(v403_9)).is_empty() { Space::new() } else {
          compose(&(v403_9),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v393_17_cursor.path()[v393_17_origin..(v393_17_origin + 1)]),&v393_17_cursor.path()[(v393_17_origin + 1)..(v393_17_origin + 2)]),&(*p1))))
        };
        drop(v403_9);
        let v403_13: Path = concat_path(&(v402_6),&v393_17_cursor.path()[(v393_17_origin + 1)..(v393_17_origin + 2)]);
        let v403_14: Space = wrap(&(v403_12),&(v403_13));
        drop(v403_12);
        drop(v403_13);
        let v403_15: Space = wrap(&(v403_14),&(*p1));
        drop(v403_14);
        let v403_16: Space = unite(&(v403_7),&(v403_15));
        drop(v403_7);
        drop(v403_15);
        join_wrapped_into(&mut v402_12_write,&((v403_16).read_zipper()),&[]);
        }
        v393_17_cursor.ascend(1);
      }
      drop(v402_12_write);
      drop(v402_6);
      compose(&(v394_10),&(v402_12))
    };
    drop(v394_10);
    let v394_14: Space = unite(&(v394_8),&(v394_13));
    drop(v394_13);
    join_wrapped_into(&mut v393_17_write,&((v394_14).read_zipper()),&[]);
    }
    v393_17_cursor.ascend(1);
  }
  drop(v393_17_cursor);
  drop(v393_17_write);
  (v393_17).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v407_14 = Space::new();
  let mut v407_14_write = v407_14.write_zipper();
  let mut v407_14_cursor = (*s0).read_zipper();
  let v407_14_origin = v407_14_cursor.path().len();
  for v407_14_byte in v407_14_cursor.child_mask().iter() {
    v407_14_cursor.descend_to_existing_byte(v407_14_byte);
    {
    let v408_2: Space = singleton(&v407_14_cursor.path()[v407_14_origin..(v407_14_origin + 1)]);
    let v408_3: Space = intersect(&(*CONSTANT_2),&(v408_2));
    let v408_4: Space = if has_head(&(v408_3)) { singleton(&[]) } else { Space::new() };
    drop(v408_3);
    let v408_5: Space = subtract(&(*CONSTANT_1),&(v408_4));
    drop(v408_4);
    let v408_8: Space = if (&(v408_5)).is_empty() { Space::new() } else {
      let v409_6: Path = concat_path(&(*p0),&v407_14_cursor.path()[v407_14_origin..(v407_14_origin + 1)]);
      let mut v409_7 = Space::new();
      let mut v409_7_write = v409_7.write_zipper();
      for v409_7_byte in v407_14_cursor.child_mask().iter() {
        v407_14_cursor.descend_to_existing_byte(v409_7_byte);
        {
        let v410_2: Space = singleton(&v407_14_cursor.path()[(v407_14_origin + 1)..(v407_14_origin + 2)]);
        let v410_3: Space = intersect(&(*CONSTANT_2),&(v410_2));
        let v410_4: Space = if has_head(&(v410_3)) { singleton(&[]) } else { Space::new() };
        drop(v410_3);
        let v410_5: Space = subtract(&(*CONSTANT_1),&(v410_4));
        drop(v410_4);
        let v410_7: Space = if (&(v410_5)).is_empty() { Space::new() } else {
          let mut v411_6 = Space::new();
          let mut v411_6_write = v411_6.write_zipper();
          for v411_6_byte in v407_14_cursor.child_mask().iter() {
            v407_14_cursor.descend_to_existing_byte(v411_6_byte);
            {
            let v412_2: Space = Space::new();
            join_wrapped_into(&mut v411_6_write,&((v412_2).read_zipper()),&[]);
            }
            v407_14_cursor.ascend(1);
          }
          drop(v411_6_write);
          compose(&(v410_5),&(v411_6))
        };
        drop(v410_5);
        let v410_8: Space = intersect(&(*CONSTANT_2),&(v410_2));
        drop(v410_2);
        let v410_9: Space = if has_head(&(v410_8)) { singleton(&[]) } else { Space::new() };
        drop(v410_8);
        let v410_12: Space = if (&(v410_9)).is_empty() { Space::new() } else {
          let v413_10: Path = concat_path(&(v409_6),&v407_14_cursor.path()[(v407_14_origin + 1)..(v407_14_origin + 2)]);
          let mut v413_11 = Space::new();
          let mut v413_11_write = v413_11.write_zipper();
          for v413_11_byte in v407_14_cursor.child_mask().iter() {
            v407_14_cursor.descend_to_existing_byte(v413_11_byte);
            {
            let v414_2: Space = singleton(&v407_14_cursor.path()[(v407_14_origin + 2)..(v407_14_origin + 3)]);
            let v414_3: Space = intersect(&(*CONSTANT_2),&(v414_2));
            drop(v414_2);
            let v414_4: Space = if has_head(&(v414_3)) { singleton(&[]) } else { Space::new() };
            drop(v414_3);
            let v414_7: Space = if (&(v414_4)).is_empty() { Space::new() } else {
              let v415_5: Path = concat_path(&(v413_10),&v407_14_cursor.path()[(v407_14_origin + 2)..(v407_14_origin + 3)]);
              let v415_6: Space = routine_10(c, &(v415_5), &(*p1), &v407_14_cursor, &(*s1));
              drop(v415_5);
              compose(&(v414_4),&(v415_6))
            };
            drop(v414_4);
            join_wrapped_into(&mut v413_11_write,&((v414_7).read_zipper()),&[]);
            }
            v407_14_cursor.ascend(1);
          }
          drop(v413_11_write);
          drop(v413_10);
          compose(&(v410_9),&(v413_11))
        };
        drop(v410_9);
        let v410_13: Space = unite(&(v410_7),&(v410_12));
        drop(v410_7);
        join_wrapped_into(&mut v409_7_write,&((v410_13).read_zipper()),&[]);
        }
        v407_14_cursor.ascend(1);
      }
      drop(v409_7_write);
      compose(&(v408_5),&(v409_7))
    };
    drop(v408_5);
    let v408_9: Space = intersect(&(*CONSTANT_2),&(v408_2));
    drop(v408_2);
    let v408_10: Space = if has_head(&(v408_9)) { singleton(&[]) } else { Space::new() };
    drop(v408_9);
    let v408_13: Space = if (&(v408_10)).is_empty() { Space::new() } else {
      compose(&(v408_10),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v407_14_cursor.path()[v407_14_origin..(v407_14_origin + 1)]),&(*p1))))
    };
    drop(v408_10);
    let v417_6: Path = concat_path(&(*p0),&v407_14_cursor.path()[v407_14_origin..(v407_14_origin + 1)]);
    let v408_14: Space = wrap(&(v408_13),&(v417_6));
    drop(v408_13);
    let v408_15: Space = wrap(&(v408_14),&(*p1));
    drop(v408_14);
    let v408_16: Space = unite(&(v408_8),&(v408_15));
    drop(v408_15);
    join_wrapped_into(&mut v407_14_write,&((v408_16).read_zipper()),&[]);
    }
    v407_14_cursor.ascend(1);
  }
  drop(v407_14_cursor);
  drop(v407_14_write);
  (v407_14).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v418_11 = Space::new();
  let mut v418_11_write = v418_11.write_zipper();
  let mut v418_11_cursor = (*s0).read_zipper();
  let v418_11_origin = v418_11_cursor.path().len();
  for v418_11_byte in v418_11_cursor.child_mask().iter() {
    v418_11_cursor.descend_to_existing_byte(v418_11_byte);
    {
    let v419_2: Space = singleton(&v418_11_cursor.path()[v418_11_origin..(v418_11_origin + 1)]);
    let v419_3: Space = intersect(&(*CONSTANT_2),&(v419_2));
    let v419_4: Space = if has_head(&(v419_3)) { singleton(&[]) } else { Space::new() };
    drop(v419_3);
    let v419_5: Space = subtract(&(*CONSTANT_1),&(v419_4));
    drop(v419_4);
    let v419_7: Space = if (&(v419_5)).is_empty() { Space::new() } else {
      let mut v420_6 = Space::new();
      let mut v420_6_write = v420_6.write_zipper();
      for v420_6_byte in v418_11_cursor.child_mask().iter() {
        v418_11_cursor.descend_to_existing_byte(v420_6_byte);
        {
        let v421_2: Space = Space::new();
        join_wrapped_into(&mut v420_6_write,&((v421_2).read_zipper()),&[]);
        }
        v418_11_cursor.ascend(1);
      }
      drop(v420_6_write);
      compose(&(v419_5),&(v420_6))
    };
    drop(v419_5);
    let v419_8: Space = intersect(&(*CONSTANT_2),&(v419_2));
    drop(v419_2);
    let v419_9: Space = if has_head(&(v419_8)) { singleton(&[]) } else { Space::new() };
    drop(v419_8);
    let v419_13: Space = if (&(v419_9)).is_empty() { Space::new() } else {
      let v422_11: Path = concat_path(&(*p0),&v418_11_cursor.path()[v418_11_origin..(v418_11_origin + 1)]);
      let mut v422_12 = Space::new();
      let mut v422_12_write = v422_12.write_zipper();
      for v422_12_byte in v418_11_cursor.child_mask().iter() {
        v418_11_cursor.descend_to_existing_byte(v422_12_byte);
        {
        let v423_2: Space = singleton(&v418_11_cursor.path()[(v418_11_origin + 1)..(v418_11_origin + 2)]);
        let v423_3: Space = intersect(&(*CONSTANT_2),&(v423_2));
        drop(v423_2);
        let v423_4: Space = if has_head(&(v423_3)) { singleton(&[]) } else { Space::new() };
        drop(v423_3);
        let v423_7: Space = if (&(v423_4)).is_empty() { Space::new() } else {
          compose(&(v423_4),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v418_11_cursor.path()[v418_11_origin..(v418_11_origin + 1)]),&v418_11_cursor.path()[(v418_11_origin + 1)..(v418_11_origin + 2)]),&(*p1))))
        };
        drop(v423_4);
        let v423_8: Path = concat_path(&(v422_11),&v418_11_cursor.path()[(v418_11_origin + 1)..(v418_11_origin + 2)]);
        join_wrapped_into(&mut v422_12_write,&((v423_7).read_zipper()),&(v423_8));
        drop(v423_7);
        drop(v423_8);
        }
        v418_11_cursor.ascend(1);
      }
      drop(v422_12_write);
      drop(v422_11);
      compose(&(v419_9),&(v422_12))
    };
    drop(v419_9);
    let v419_14: Space = wrap(&(v419_13),&(*p1));
    drop(v419_13);
    let v419_15: Space = unite(&(v419_7),&(v419_14));
    drop(v419_7);
    drop(v419_14);
    join_wrapped_into(&mut v418_11_write,&((v419_15).read_zipper()),&[]);
    }
    v418_11_cursor.ascend(1);
  }
  drop(v418_11_cursor);
  drop(v418_11_write);
  (v418_11).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v425_10 = Space::new();
  let mut v425_10_write = v425_10.write_zipper();
  let mut v425_10_cursor = (*s0).read_zipper();
  let v425_10_origin = v425_10_cursor.path().len();
  for v425_10_byte in v425_10_cursor.child_mask().iter() {
    v425_10_cursor.descend_to_existing_byte(v425_10_byte);
    {
    let v426_2: Space = singleton(&v425_10_cursor.path()[v425_10_origin..(v425_10_origin + 1)]);
    let v426_3: Space = intersect(&(*CONSTANT_2),&(v426_2));
    let v426_4: Space = if has_head(&(v426_3)) { singleton(&[]) } else { Space::new() };
    drop(v426_3);
    let v426_5: Space = subtract(&(*CONSTANT_1),&(v426_4));
    drop(v426_4);
    let v426_7: Space = if (&(v426_5)).is_empty() { Space::new() } else {
      let mut v427_6 = Space::new();
      let mut v427_6_write = v427_6.write_zipper();
      for v427_6_byte in v425_10_cursor.child_mask().iter() {
        v425_10_cursor.descend_to_existing_byte(v427_6_byte);
        {
        let v428_2: Space = Space::new();
        join_wrapped_into(&mut v427_6_write,&((v428_2).read_zipper()),&[]);
        }
        v425_10_cursor.ascend(1);
      }
      drop(v427_6_write);
      compose(&(v426_5),&(v427_6))
    };
    drop(v426_5);
    let v426_8: Space = intersect(&(*CONSTANT_2),&(v426_2));
    drop(v426_2);
    let v426_9: Space = if has_head(&(v426_8)) { singleton(&[]) } else { Space::new() };
    drop(v426_8);
    let v426_12: Space = if (&(v426_9)).is_empty() { Space::new() } else {
      compose(&(v426_9),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v425_10_cursor.path()[v425_10_origin..(v425_10_origin + 1)]),&(*p1))))
    };
    drop(v426_9);
    let v426_13: Path = concat_path(&(*p0),&v425_10_cursor.path()[v425_10_origin..(v425_10_origin + 1)]);
    let v426_14: Space = wrap(&(v426_12),&(v426_13));
    drop(v426_12);
    drop(v426_13);
    let v426_15: Space = wrap(&(v426_14),&(*p1));
    drop(v426_14);
    let v426_16: Space = unite(&(v426_7),&(v426_15));
    drop(v426_7);
    drop(v426_15);
    join_wrapped_into(&mut v425_10_write,&((v426_16).read_zipper()),&[]);
    }
    v425_10_cursor.ascend(1);
  }
  drop(v425_10_cursor);
  drop(v425_10_write);
  (v425_10).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v430_4 = Space::new();
  let mut v430_4_write = v430_4.write_zipper();
  let mut v430_4_cursor = (*s0).read_zipper();
  let v430_4_origin = v430_4_cursor.path().len();
  for v430_4_byte in v430_4_cursor.child_mask().iter() {
    v430_4_cursor.descend_to_existing_byte(v430_4_byte);
    {
    let v431_2: Space = Space::new();
    join_wrapped_into(&mut v430_4_write,&((v431_2).read_zipper()),&[]);
    }
    v430_4_cursor.ascend(1);
  }
  drop(v430_4_cursor);
  drop(v430_4_write);
  (v430_4).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v432_8 = Space::new();
  let mut v432_8_write = v432_8.write_zipper();
  let mut v432_8_cursor = (*s0).read_zipper();
  let v432_8_origin = v432_8_cursor.path().len();
  for v432_8_byte in v432_8_cursor.child_mask().iter() {
    v432_8_cursor.descend_to_existing_byte(v432_8_byte);
    {
    let v433_2: Space = singleton(&v432_8_cursor.path()[v432_8_origin..(v432_8_origin + 1)]);
    let v433_3: Space = intersect(&(*CONSTANT_2),&(v433_2));
    drop(v433_2);
    let v433_4: Space = if has_head(&(v433_3)) { singleton(&[]) } else { Space::new() };
    drop(v433_3);
    let v433_7: Space = if (&(v433_4)).is_empty() { Space::new() } else {
      compose(&(v433_4),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v432_8_cursor.path()[v432_8_origin..(v432_8_origin + 1)]),&(*p1))))
    };
    drop(v433_4);
    let v433_8: Path = concat_path(&(*p0),&v432_8_cursor.path()[v432_8_origin..(v432_8_origin + 1)]);
    join_wrapped_into(&mut v432_8_write,&((v433_7).read_zipper()),&(v433_8));
    drop(v433_7);
    drop(v433_8);
    }
    v432_8_cursor.ascend(1);
  }
  drop(v432_8_cursor);
  drop(v432_8_write);
  let v432_9: Space = wrap(&(v432_8),&(*p1));
  drop(v432_8);
  (v432_9).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
