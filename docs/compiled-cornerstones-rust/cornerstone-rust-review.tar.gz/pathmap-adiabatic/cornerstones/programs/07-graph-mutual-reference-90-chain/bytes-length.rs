#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4,101,100,103,101]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("255 2 1 0 2 2 1 2 3 2 2 4 3 2 5 4 2 6 5 2 7 6 2 8 7 2 9 8 2 10 9 2 11 10 2 12 11 2 13 12 2 14 13 2 15 14 2 16 15 2 17 16 2 18 17 2 19 18 2 20 19 2 21 20 2 22 21 2 23 22 2 24 23 2 25 24 2 26 25 2 27 26 2 28 27 2 29 28 2 30 29 2 31 30 2 32 31 2 33 32 2 34 33 2 35 34 2 36 35 2 37 36 2 38 37 2 39 38 2 40 39 2 41 40 2 42 41 2 43 42 2 44 43 2 45 44 2 46 45 2 47 46 2 48 47 2 49 48 2 50 49 2 51 50 2 52 51 2 53 52 2 54 53 2 55 54 2 56 55 2 57 56 2 58 57 2 59 58 2 60 59 2 61 60 2 62 61 2 63 62 2 64 63 2 65 64 2 66 65 2 67 66 2 68 67 2 69 68 2 70 69 2 71 70 2 72 71 2 73 72 2 74 73 2 75 74 2 76 75 2 77 76 2 78 77 2 79 78 2 80 79 2 81 80 2 82 81 2 83 82 2 84 83 2 85 84 2 86 85 2 87 86 2 88 87 2 89 88 2 90 89 2 91 90 2 92 91 2 93 92 2 94 93 2 95 94 2 96 95 2 97 96 2 98 97 2 99 98 2 100 99 2 101 100 2 102 101 2 103 102 2 104 103 2 105 104 2 106 105 2 107 106 2 108 107 2 109 108 2 110 109 2 111 110 2 112 111 2 113 112 2 114 113 2 115 114 2 116 115 2 117 116 2 118 117 2 119 118 2 120 119 2 121 120 2 122 121 2 123 122 2 124 123 2 125 124 2 126 125 2 127 126 2 128 127 2 129 128 2 130 129 2 131 130 2 132 131 2 133 132 2 134 133 2 135 134 2 136 135 2 137 136 2 138 137 2 139 138 2 140 139 2 141 140 2 142 141 2 143 142 2 144 143 2 145 144 2 146 145 2 147 146 2 148 147 2 149 148 2 150 149 2 151 150 2 152 151 2 153 152 2 154 153 2 155 154 2 156 155 2 157 156 2 158 157 2 159 158 2 160 159 2 161 160 2 162 161 2 163 162 2 164 163 2 165 164 2 166 165 2 167 166 2 168 167 2 169 168 2 170 169 2 171 170 2 172 171 2 173 172 2 174 173 2 175 174 2 176 175 2 177 176 2 178 177 2 179 178 2 180 179 2 181 180 2 182 181 2 183 182 2 184 183 2 185 184 2 186 185 2 187 186 2 188 187 2 189 188 2 190 189 2 191 190 2 192 191 2 193 192 2 194 193 2 195 194 2 196 195 2 197 196 2 198 197 2 199 198 2 200 199 2 201 200 2 202 201 2 203 202 2 204 203 2 205 204 2 206 205 2 207 206 2 208 207 2 209 208 2 210 209 2 211 210 2 212 211 2 213 212 2 214 213 2 215 214 2 216 215 2 217 216 2 218 217 2 219 218 2 220 219 2 221 220 2 222 221 2 223 222 2 224 223 2 225 224 2 226 225 2 227 226 2 228 227 2 229 228 2 230 229 2 231 230 2 232 231 2 233 232 2 234 233 2 235 234 2 236 235 2 237 236 2 238 237 2 239 238 2 240 239 2 241 240 2 242 241 2 243 242 2 244 243 2 245 244 2 246 245 2 247 246 2 248 247 2 249 248 2 250 249 2 251 250 2 252 251 2 253 252 2 254 253 2 255 254"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[6,77,117,116,117,97,108]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_8 = Space::new();
  let mut v0_8_write = v0_8.write_zipper();
  let mut v0_8_cursor = descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0));
  let v0_8_origin = v0_8_cursor.path().len();
  for v0_8_byte in v0_8_cursor.child_mask().iter() {
    v0_8_cursor.descend_to_existing_byte(v0_8_byte);
    {
    let v1_2: Space = singleton(&v0_8_cursor.path()[v0_8_origin..(v0_8_origin + 1)]);
    let v1_3: Space = intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_8: Space = if (&(v1_5)).is_empty() { Space::new() } else {
      let mut v2_7 = Space::new();
      let mut v2_7_write = v2_7.write_zipper();
      let v2_7_arg_0: &[u8] = &(*CONSTANT_3);
      let v2_7_arg_1: &[u8] = &v0_8_cursor.path()[v0_8_origin..(v0_8_origin + 1)];
      let v2_7_arg_3: &Space = &(&v0_8_cursor).make_map();
      let v2_7_arg_4: &Space = &(*s0.expect("unbound native input"));
      let mut v2_7_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&v0_8_cursor.path()[v0_8_origin..(v0_8_origin + 1)]);
      let v2_7_origin = v2_7_cursor.path().len();
      let mut v2_7_more = v2_7_cursor.is_val() || next_value_within(&mut v2_7_cursor,v2_7_origin);
      while v2_7_more {
        {
        let v2_7_depth = v2_7_cursor.path().len();
        let mut v3_5_cursor = (*v2_7_arg_3).read_zipper();
        let v3_5_origin = v3_5_cursor.path().len();
        for v3_5_byte in v3_5_cursor.child_mask().iter() {
          v3_5_cursor.descend_to_existing_byte(v3_5_byte);
          {
          let v4_2: Path = concat_path(&(*v2_7_arg_1),&v3_5_cursor.path()[v3_5_origin..(v3_5_origin + 1)]);
          let v4_3: Space = routine_1(c, &(v4_2), &v2_7_cursor.path()[v2_7_origin..v2_7_depth], &v3_5_cursor, &((*v2_7_arg_4).read_zipper()));
          drop(v4_2);
          join_wrapped_into(&mut v2_7_write,&((v4_3).read_zipper()),&[]);
          }
          v3_5_cursor.ascend(1);
        }
        drop(v3_5_cursor);
        }
        v2_7_more = next_value_within(&mut v2_7_cursor,v2_7_origin);
      }
      drop(v2_7_cursor);
      drop(v2_7_write);
      compose(&(v1_5),&(v2_7))
    };
    drop(v1_5);
    let v1_9: Space = intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_10: Space = if has_head(&(v1_9)) { singleton(&[]) } else { Space::new() };
    drop(v1_9);
    let v1_12: Space = if (&(v1_10)).is_empty() { Space::new() } else {
      let mut v5_11 = Space::new();
      let mut v5_11_write = v5_11.write_zipper();
      for v5_11_byte in v0_8_cursor.child_mask().iter() {
        v0_8_cursor.descend_to_existing_byte(v5_11_byte);
        {
        let v6_2: Space = routine_2(c, &v0_8_cursor.path()[(v0_8_origin + 1)..(v0_8_origin + 2)], &v0_8_cursor.path()[(v0_8_origin + 1)..(v0_8_origin + 2)], &v0_8_cursor.path()[v0_8_origin..(v0_8_origin + 1)], &v0_8_cursor, &((*s0.expect("unbound native input")).read_zipper()));
        join_wrapped_into(&mut v5_11_write,&((v6_2).read_zipper()),&[]);
        }
        v0_8_cursor.ascend(1);
      }
      drop(v5_11_write);
      compose(&(v1_10),&(v5_11))
    };
    drop(v1_10);
    let v1_13: Space = unite(&(v1_8),&(v1_12));
    join_wrapped_into(&mut v0_8_write,&((v1_13).read_zipper()),&[]);
    }
    v0_8_cursor.ascend(1);
  }
  drop(v0_8_cursor);
  drop(v0_8_write);
  let v0_10: Space = wrap(&(v0_8),&(*CONSTANT_5));
  (v0_10).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v7_6: Space = singleton(&(*p1));
  let v7_7: Space = intersect(&(*CONSTANT_2),&(v7_6));
  let v7_8: Space = if has_head(&(v7_7)) { singleton(&[]) } else { Space::new() };
  drop(v7_7);
  let v7_9: Space = subtract(&(*CONSTANT_1),&(v7_8));
  drop(v7_8);
  let v7_20: Space = if (&(v7_9)).is_empty() { Space::new() } else {
    let v8_12: Space = first_matching(&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p1))),&(*CONSTANT_1),false);
    let v8_15: Space = if (&(v8_12)).is_empty() { Space::new() } else {
      let v9_14: Space = routine_3(c, &(*CONSTANT_3), &(*p0), &(*s0), &(*s1));
      compose(&(v8_12),&(v9_14))
    };
    drop(v8_12);
    let mut v8_18 = Space::new();
    let mut v8_18_write = v8_18.write_zipper();
    let mut v8_18_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p1));
    let v8_18_origin = v8_18_cursor.path().len();
    for v8_18_byte in v8_18_cursor.child_mask().iter() {
      v8_18_cursor.descend_to_existing_byte(v8_18_byte);
      {
      let v10_2_arg_0: &[u8] = &v8_18_cursor.path()[v8_18_origin..(v8_18_origin + 1)];
      let v10_2_arg_1: &[u8] = &(*p0);
      let v10_2_arg_3: &Space = &(&(*s0)).make_map();
      let v10_2_arg_4: &Space = &(&(*s1)).make_map();
      let mut v10_2_more = v8_18_cursor.is_val() || next_value_within(&mut v8_18_cursor,(v8_18_origin + 1));
      while v10_2_more {
        {
        let v10_2_depth = v8_18_cursor.path().len();
        let mut v11_5_cursor = (*v10_2_arg_3).read_zipper();
        let v11_5_origin = v11_5_cursor.path().len();
        for v11_5_byte in v11_5_cursor.child_mask().iter() {
          v11_5_cursor.descend_to_existing_byte(v11_5_byte);
          {
          let v12_2: Path = concat_path(&(*v10_2_arg_1),&v11_5_cursor.path()[v11_5_origin..(v11_5_origin + 1)]);
          let v12_3: Space = routine_1(c, &(v12_2), &v8_18_cursor.path()[v8_18_origin..v10_2_depth], &v11_5_cursor, &((*v10_2_arg_4).read_zipper()));
          drop(v12_2);
          join_wrapped_into(&mut v8_18_write,&((v12_3).read_zipper()),&[]);
          }
          v11_5_cursor.ascend(1);
        }
        drop(v11_5_cursor);
        }
        v10_2_more = next_value_within(&mut v8_18_cursor,(v8_18_origin + 1));
      }
      }
      v8_18_cursor.ascend(1);
    }
    drop(v8_18_cursor);
    drop(v8_18_write);
    let v8_19: Space = unite(&(v8_15),&(v8_18));
    compose(&(v7_9),&(v8_19))
  };
  drop(v7_9);
  let v7_22: Space = intersect(&(*CONSTANT_2),&(v7_6));
  drop(v7_6);
  let v7_23: Space = if has_head(&(v7_22)) { singleton(&[]) } else { Space::new() };
  drop(v7_22);
  let v7_25: Space = if (&(v7_23)).is_empty() { Space::new() } else {
    let mut v13_24 = Space::new();
    let mut v13_24_write = v13_24.write_zipper();
    let mut v13_24_cursor = (*s0).read_zipper();
    let v13_24_origin = v13_24_cursor.path().len();
    for v13_24_byte in v13_24_cursor.child_mask().iter() {
      v13_24_cursor.descend_to_existing_byte(v13_24_byte);
      {
      let v14_2: Space = routine_2(c, &v13_24_cursor.path()[v13_24_origin..(v13_24_origin + 1)], &v13_24_cursor.path()[v13_24_origin..(v13_24_origin + 1)], &(*p0), &v13_24_cursor, &(*s1));
      join_wrapped_into(&mut v13_24_write,&((v14_2).read_zipper()),&[]);
      }
      v13_24_cursor.ascend(1);
    }
    drop(v13_24_cursor);
    drop(v13_24_write);
    compose(&(v7_23),&(v13_24))
  };
  drop(v7_23);
  let v7_26: Space = unite(&(v7_20),&(v7_25));
  (v7_26).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v15_7: Space = singleton(&(*p1));
  let v15_8: Space = intersect(&(*CONSTANT_2),&(v15_7));
  let v15_9: Space = if has_head(&(v15_8)) { singleton(&[]) } else { Space::new() };
  drop(v15_8);
  let v15_10: Space = subtract(&(*CONSTANT_1),&(v15_9));
  drop(v15_9);
  let v15_21: Space = if (&(v15_10)).is_empty() { Space::new() } else {
    let v16_13: Space = first_matching(&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p1))),&(*CONSTANT_1),false);
    let v16_16: Space = if (&(v16_13)).is_empty() { Space::new() } else {
      let v17_15: Space = routine_4(c, &(*CONSTANT_3), &(*p0), &(*p2), &(*s0), &(*s1));
      compose(&(v16_13),&(v17_15))
    };
    drop(v16_13);
    let mut v16_19 = Space::new();
    let mut v16_19_write = v16_19.write_zipper();
    let mut v16_19_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p1));
    let v16_19_origin = v16_19_cursor.path().len();
    for v16_19_byte in v16_19_cursor.child_mask().iter() {
      v16_19_cursor.descend_to_existing_byte(v16_19_byte);
      {
      let v18_2_arg_0: &[u8] = &v16_19_cursor.path()[v16_19_origin..(v16_19_origin + 1)];
      let v18_2_arg_1: &[u8] = &(*p0);
      let v18_2_arg_2: &[u8] = &(*p2);
      let v18_2_arg_4: &Space = &(&(*s0)).make_map();
      let v18_2_arg_5: &Space = &(&(*s1)).make_map();
      let mut v18_2_more = v16_19_cursor.is_val() || next_value_within(&mut v16_19_cursor,(v16_19_origin + 1));
      while v18_2_more {
        {
        let v18_2_depth = v16_19_cursor.path().len();
        let mut v19_6_cursor = (*v18_2_arg_4).read_zipper();
        let v19_6_origin = v19_6_cursor.path().len();
        for v19_6_byte in v19_6_cursor.child_mask().iter() {
          v19_6_cursor.descend_to_existing_byte(v19_6_byte);
          {
          let v20_2: Path = concat_path(&(*v18_2_arg_1),&v19_6_cursor.path()[v19_6_origin..(v19_6_origin + 1)]);
          let v20_3: Space = routine_2(c, &(v20_2), &v16_19_cursor.path()[v16_19_origin..v18_2_depth], &(*v18_2_arg_2), &v19_6_cursor, &((*v18_2_arg_5).read_zipper()));
          drop(v20_2);
          join_wrapped_into(&mut v16_19_write,&((v20_3).read_zipper()),&[]);
          }
          v19_6_cursor.ascend(1);
        }
        drop(v19_6_cursor);
        }
        v18_2_more = next_value_within(&mut v16_19_cursor,(v16_19_origin + 1));
      }
      }
      v16_19_cursor.ascend(1);
    }
    drop(v16_19_cursor);
    drop(v16_19_write);
    let v16_20: Space = unite(&(v16_16),&(v16_19));
    compose(&(v15_10),&(v16_20))
  };
  drop(v15_10);
  let v15_23: Space = intersect(&(*CONSTANT_2),&(v15_7));
  drop(v15_7);
  let v15_24: Space = if has_head(&(v15_23)) { singleton(&[]) } else { Space::new() };
  drop(v15_23);
  let v15_29: Space = if (&(v15_24)).is_empty() { Space::new() } else {
    compose(&(v15_24),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&(*p2))))
  };
  drop(v15_24);
  let v15_30: Space = wrap(&(v15_29),&(*p0));
  drop(v15_29);
  let v15_31: Space = wrap(&(v15_30),&(*p2));
  drop(v15_30);
  let v15_32: Space = unite(&(v15_21),&(v15_31));
  drop(v15_31);
  (v15_32).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v22_6: Space = singleton(&(*p0));
  let v22_7: Space = intersect(&(*CONSTANT_2),&(v22_6));
  let v22_8: Space = if has_head(&(v22_7)) { singleton(&[]) } else { Space::new() };
  drop(v22_7);
  let v22_9: Space = subtract(&(*CONSTANT_1),&(v22_8));
  drop(v22_8);
  let v22_14: Space = intersect(&(*CONSTANT_2),&(v22_6));
  drop(v22_6);
  let v22_15: Space = if has_head(&(v22_14)) { singleton(&[]) } else { Space::new() };
  drop(v22_14);
  let mut v22_16 = Space::new();
  let mut v22_16_write = v22_16.write_zipper();
  let mut v22_16_cursor = (*s0).read_zipper();
  let v22_16_origin = v22_16_cursor.path().len();
  for v22_16_byte in v22_16_cursor.child_mask().iter() {
    v22_16_cursor.descend_to_existing_byte(v22_16_byte);
    {
    let v23_4: Space = if (&(v22_9)).is_empty() { Space::new() } else {
      let v24_2: Path = concat_path(&(*p1),&v22_16_cursor.path()[v22_16_origin..(v22_16_origin + 1)]);
      let mut v24_3 = Space::new();
      let mut v24_3_write = v24_3.write_zipper();
      let v24_3_arg_0: &[u8] = &(*CONSTANT_3);
      let v24_3_arg_1: &[u8] = &(v24_2);
      let v24_3_arg_3: &Space = &(&v22_16_cursor).make_map();
      let v24_3_arg_4: &Space = &(&(*s1)).make_map();
      let mut v24_3_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p0));
      let v24_3_origin = v24_3_cursor.path().len();
      let mut v24_3_more = v24_3_cursor.is_val() || next_value_within(&mut v24_3_cursor,v24_3_origin);
      while v24_3_more {
        {
        let v24_3_depth = v24_3_cursor.path().len();
        let v25_5: Space = routine_3(c, &v24_3_cursor.path()[v24_3_origin..v24_3_depth], &(*v24_3_arg_1), &((*v24_3_arg_3).read_zipper()), &((*v24_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v24_3_write,&((v25_5).read_zipper()),&[]);
        }
        v24_3_more = next_value_within(&mut v24_3_cursor,v24_3_origin);
      }
      drop(v24_3_cursor);
      drop(v24_3_write);
      compose(&(v22_9),&(v24_3))
    };
    let v23_6: Space = if (&(v22_15)).is_empty() { Space::new() } else {
      let v26_2: Path = concat_path(&(*p1),&v22_16_cursor.path()[v22_16_origin..(v22_16_origin + 1)]);
      let mut v26_5 = Space::new();
      let mut v26_5_write = v26_5.write_zipper();
      for v26_5_byte in v22_16_cursor.child_mask().iter() {
        v22_16_cursor.descend_to_existing_byte(v26_5_byte);
        {
        let v27_2: Space = routine_2(c, &v22_16_cursor.path()[(v22_16_origin + 1)..(v22_16_origin + 2)], &v22_16_cursor.path()[(v22_16_origin + 1)..(v22_16_origin + 2)], &(v26_2), &v22_16_cursor, &(*s1));
        join_wrapped_into(&mut v26_5_write,&((v27_2).read_zipper()),&[]);
        }
        v22_16_cursor.ascend(1);
      }
      drop(v26_5_write);
      drop(v26_2);
      compose(&(v22_15),&(v26_5))
    };
    let v23_7: Space = unite(&(v23_4),&(v23_6));
    join_wrapped_into(&mut v22_16_write,&((v23_7).read_zipper()),&[]);
    }
    v22_16_cursor.ascend(1);
  }
  drop(v22_16_cursor);
  drop(v22_16_write);
  drop(v22_9);
  drop(v22_15);
  (v22_16).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v28_7: Space = singleton(&(*p0));
  let v28_8: Space = intersect(&(*CONSTANT_2),&(v28_7));
  let v28_9: Space = if has_head(&(v28_8)) { singleton(&[]) } else { Space::new() };
  drop(v28_8);
  let v28_10: Space = subtract(&(*CONSTANT_1),&(v28_9));
  drop(v28_9);
  let v28_15: Space = intersect(&(*CONSTANT_2),&(v28_7));
  drop(v28_7);
  let v28_16: Space = if has_head(&(v28_15)) { singleton(&[]) } else { Space::new() };
  drop(v28_15);
  let mut v28_20 = Space::new();
  let mut v28_20_write = v28_20.write_zipper();
  let mut v28_20_cursor = (*s0).read_zipper();
  let v28_20_origin = v28_20_cursor.path().len();
  for v28_20_byte in v28_20_cursor.child_mask().iter() {
    v28_20_cursor.descend_to_existing_byte(v28_20_byte);
    {
    let v29_4: Space = if (&(v28_10)).is_empty() { Space::new() } else {
      let v30_2: Path = concat_path(&(*p1),&v28_20_cursor.path()[v28_20_origin..(v28_20_origin + 1)]);
      let mut v30_3 = Space::new();
      let mut v30_3_write = v30_3.write_zipper();
      let v30_3_arg_0: &[u8] = &(*CONSTANT_3);
      let v30_3_arg_1: &[u8] = &(v30_2);
      let v30_3_arg_2: &[u8] = &(*p2);
      let v30_3_arg_4: &Space = &(&v28_20_cursor).make_map();
      let v30_3_arg_5: &Space = &(&(*s1)).make_map();
      let mut v30_3_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p0));
      let v30_3_origin = v30_3_cursor.path().len();
      let mut v30_3_more = v30_3_cursor.is_val() || next_value_within(&mut v30_3_cursor,v30_3_origin);
      while v30_3_more {
        {
        let v30_3_depth = v30_3_cursor.path().len();
        let v31_6: Space = routine_4(c, &v30_3_cursor.path()[v30_3_origin..v30_3_depth], &(*v30_3_arg_1), &(*v30_3_arg_2), &((*v30_3_arg_4).read_zipper()), &((*v30_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v30_3_write,&((v31_6).read_zipper()),&[]);
        }
        v30_3_more = next_value_within(&mut v30_3_cursor,v30_3_origin);
      }
      drop(v30_3_cursor);
      drop(v30_3_write);
      compose(&(v28_10),&(v30_3))
    };
    let v29_7: Space = if (&(v28_16)).is_empty() { Space::new() } else {
      compose(&(v28_16),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p1)),&v28_20_cursor.path()[v28_20_origin..(v28_20_origin + 1)]),&(*p2))))
    };
    let v33_2: Path = concat_path(&(*p1),&v28_20_cursor.path()[v28_20_origin..(v28_20_origin + 1)]);
    let v29_8: Space = wrap(&(v29_7),&(v33_2));
    drop(v29_7);
    let v29_9: Space = wrap(&(v29_8),&(*p2));
    drop(v29_8);
    let v29_10: Space = unite(&(v29_4),&(v29_9));
    drop(v29_9);
    join_wrapped_into(&mut v28_20_write,&((v29_10).read_zipper()),&[]);
    }
    v28_20_cursor.ascend(1);
  }
  drop(v28_20_cursor);
  drop(v28_20_write);
  drop(v28_10);
  drop(v28_16);
  (v28_20).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
