#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,1,0,0,0,0,0,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_24 = Space::new();
  let mut v0_24_write = v0_24.write_zipper();
  let mut v0_24_cursor = descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0));
  let v0_24_origin = v0_24_cursor.path().len();
  for v0_24_byte in v0_24_cursor.child_mask().iter() {
    v0_24_cursor.descend_to_existing_byte(v0_24_byte);
    {
    let v1_2: Space = singleton(&v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 1)]);
    let v1_3: Space = intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (&(v1_5)).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_write = v2_6.write_zipper();
      for v2_6_byte in v0_24_cursor.child_mask().iter() {
        v0_24_cursor.descend_to_existing_byte(v2_6_byte);
        {
        let v3_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 1)..(v0_24_origin + 2)]);
        let v3_3: Space = intersect(&(*CONSTANT_2),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_1),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (&(v3_5)).is_empty() { Space::new() } else {
          let mut v4_7 = Space::new();
          let mut v4_7_write = v4_7.write_zipper();
          for v4_7_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v4_7_byte);
            {
            let v5_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v5_3: Space = intersect(&(*CONSTANT_2),&(v5_2));
            let v5_4: Space = if has_head(&(v5_3)) { singleton(&[]) } else { Space::new() };
            drop(v5_3);
            let v5_5: Space = subtract(&(*CONSTANT_1),&(v5_4));
            drop(v5_4);
            let v5_8: Space = if (&(v5_5)).is_empty() { Space::new() } else {
              let v6_7: Space = routine_1(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v5_5),&(v6_7))
            };
            drop(v5_5);
            let v5_9: Space = intersect(&(*CONSTANT_2),&(v5_2));
            drop(v5_2);
            let v5_10: Space = if has_head(&(v5_9)) { singleton(&[]) } else { Space::new() };
            drop(v5_9);
            let v5_12: Space = if (&(v5_10)).is_empty() { Space::new() } else {
              let v7_11: Space = routine_2(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v5_10),&(v7_11))
            };
            drop(v5_10);
            let v5_13: Space = unite(&(v5_8),&(v5_12));
            join_wrapped_into(&mut v4_7_write,&((v5_13).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v4_7_write);
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_2),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (&(v3_10)).is_empty() { Space::new() } else {
          let mut v8_11 = Space::new();
          let mut v8_11_write = v8_11.write_zipper();
          for v8_11_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v8_11_byte);
            {
            let v9_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v9_3: Space = intersect(&(*CONSTANT_2),&(v9_2));
            let v9_4: Space = if has_head(&(v9_3)) { singleton(&[]) } else { Space::new() };
            drop(v9_3);
            let v9_5: Space = subtract(&(*CONSTANT_1),&(v9_4));
            drop(v9_4);
            let v9_8: Space = if (&(v9_5)).is_empty() { Space::new() } else {
              let v10_7: Space = routine_1(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v9_5),&(v10_7))
            };
            drop(v9_5);
            let v9_9: Space = intersect(&(*CONSTANT_2),&(v9_2));
            drop(v9_2);
            let v9_10: Space = if has_head(&(v9_9)) { singleton(&[]) } else { Space::new() };
            drop(v9_9);
            let v9_12: Space = if (&(v9_10)).is_empty() { Space::new() } else {
              let v11_11: Space = routine_3(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v9_10),&(v11_11))
            };
            drop(v9_10);
            let v9_13: Space = unite(&(v9_8),&(v9_12));
            join_wrapped_into(&mut v8_11_write,&((v9_13).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v8_11_write);
          compose(&(v3_10),&(v8_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        join_wrapped_into(&mut v2_6_write,&((v3_13).read_zipper()),&[]);
        }
        v0_24_cursor.ascend(1);
      }
      drop(v2_6_write);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (&(v1_9)).is_empty() { Space::new() } else {
      let mut v12_10 = Space::new();
      let mut v12_10_write = v12_10.write_zipper();
      for v12_10_byte in v0_24_cursor.child_mask().iter() {
        v0_24_cursor.descend_to_existing_byte(v12_10_byte);
        {
        let v13_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 1)..(v0_24_origin + 2)]);
        let v13_3: Space = intersect(&(*CONSTANT_2),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_1),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (&(v13_5)).is_empty() { Space::new() } else {
          let mut v14_7 = Space::new();
          let mut v14_7_write = v14_7.write_zipper();
          for v14_7_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v14_7_byte);
            {
            let v15_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v15_3: Space = intersect(&(*CONSTANT_2),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_1),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (&(v15_5)).is_empty() { Space::new() } else {
              let v16_7: Space = routine_1(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_2),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (&(v15_10)).is_empty() { Space::new() } else {
              let v17_11: Space = routine_2(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            join_wrapped_into(&mut v14_7_write,&((v15_13).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v14_7_write);
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_2),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (&(v13_10)).is_empty() { Space::new() } else {
          let mut v18_11 = Space::new();
          let mut v18_11_write = v18_11.write_zipper();
          for v18_11_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v18_11_byte);
            {
            let v19_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v19_3: Space = intersect(&(*CONSTANT_2),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_1),&(v19_4));
            drop(v19_4);
            let v19_7: Space = if (&(v19_5)).is_empty() { Space::new() } else {
              let v20_6: Space = routine_4(c, &v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)], &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 2)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v19_5),&(v20_6))
            };
            drop(v19_5);
            let v19_8: Space = intersect(&(*CONSTANT_2),&(v19_2));
            drop(v19_2);
            let v19_9: Space = if has_head(&(v19_8)) { singleton(&[]) } else { Space::new() };
            drop(v19_8);
            let v19_11: Space = if (&(v19_9)).is_empty() { Space::new() } else {
              let v21_10: Space = routine_5(c, &v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)], &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 2)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v19_9),&(v21_10))
            };
            drop(v19_9);
            let v19_12: Space = unite(&(v19_7),&(v19_11));
            join_wrapped_into(&mut v18_11_write,&((v19_12).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v18_11_write);
          compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        join_wrapped_into(&mut v12_10_write,&((v13_13).read_zipper()),&[]);
        }
        v0_24_cursor.ascend(1);
      }
      drop(v12_10_write);
      compose(&(v1_9),&(v12_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    join_wrapped_into(&mut v0_24_write,&((v1_12).read_zipper()),&[]);
    }
    v0_24_cursor.ascend(1);
  }
  drop(v0_24_cursor);
  drop(v0_24_write);
  let v0_26: Space = wrap(&(v0_24),&(*CONSTANT_3));
  (v0_26).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v22_24 = Space::new();
  let mut v22_24_write = v22_24.write_zipper();
  let mut v22_24_cursor = (*s0).read_zipper();
  let v22_24_origin = v22_24_cursor.path().len();
  for v22_24_byte in v22_24_cursor.child_mask().iter() {
    v22_24_cursor.descend_to_existing_byte(v22_24_byte);
    {
    let v23_2: Space = singleton(&v22_24_cursor.path()[v22_24_origin..(v22_24_origin + 1)]);
    let v23_3: Space = intersect(&(*CONSTANT_2),&(v23_2));
    let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
    drop(v23_3);
    let v23_5: Space = subtract(&(*CONSTANT_1),&(v23_4));
    drop(v23_4);
    let v23_8: Space = if (&(v23_5)).is_empty() { Space::new() } else {
      let v24_6: Path = concat_path(&(*p0),&v22_24_cursor.path()[v22_24_origin..(v22_24_origin + 1)]);
      let mut v24_7 = Space::new();
      let mut v24_7_write = v24_7.write_zipper();
      for v24_7_byte in v22_24_cursor.child_mask().iter() {
        v22_24_cursor.descend_to_existing_byte(v24_7_byte);
        {
        let v25_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
        let v25_3: Space = intersect(&(*CONSTANT_2),&(v25_2));
        let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
        drop(v25_3);
        let v25_5: Space = subtract(&(*CONSTANT_1),&(v25_4));
        drop(v25_4);
        let v25_8: Space = if (&(v25_5)).is_empty() { Space::new() } else {
          let v26_6: Path = concat_path(&(v24_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v26_7 = Space::new();
          let mut v26_7_write = v26_7.write_zipper();
          for v26_7_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v26_7_byte);
            {
            let v27_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v27_3: Space = intersect(&(*CONSTANT_2),&(v27_2));
            let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
            drop(v27_3);
            let v27_5: Space = subtract(&(*CONSTANT_1),&(v27_4));
            drop(v27_4);
            let v27_8: Space = if (&(v27_5)).is_empty() { Space::new() } else {
              let v28_6: Path = concat_path(&(v26_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v28_7: Space = routine_6(c, &(v28_6), &v22_24_cursor, &(*s1));
              compose(&(v27_5),&(v28_7))
            };
            drop(v27_5);
            let v27_9: Space = intersect(&(*CONSTANT_2),&(v27_2));
            drop(v27_2);
            let v27_10: Space = if has_head(&(v27_9)) { singleton(&[]) } else { Space::new() };
            drop(v27_9);
            let v27_12: Space = if (&(v27_10)).is_empty() { Space::new() } else {
              let v29_6: Path = concat_path(&(v26_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v29_11: Space = routine_7(c, &(v29_6), &v22_24_cursor, &(*s1));
              drop(v29_6);
              compose(&(v27_10),&(v29_11))
            };
            drop(v27_10);
            let v27_13: Space = unite(&(v27_8),&(v27_12));
            join_wrapped_into(&mut v26_7_write,&((v27_13).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v26_7_write);
          compose(&(v25_5),&(v26_7))
        };
        drop(v25_5);
        let v25_9: Space = intersect(&(*CONSTANT_2),&(v25_2));
        drop(v25_2);
        let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
        drop(v25_9);
        let v25_12: Space = if (&(v25_10)).is_empty() { Space::new() } else {
          let v30_6: Path = concat_path(&(v24_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v30_11 = Space::new();
          let mut v30_11_write = v30_11.write_zipper();
          for v30_11_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v30_11_byte);
            {
            let v31_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v31_3: Space = intersect(&(*CONSTANT_2),&(v31_2));
            let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
            drop(v31_3);
            let v31_5: Space = subtract(&(*CONSTANT_1),&(v31_4));
            drop(v31_4);
            let v31_8: Space = if (&(v31_5)).is_empty() { Space::new() } else {
              let v32_6: Path = concat_path(&(v30_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v32_7: Space = routine_6(c, &(v32_6), &v22_24_cursor, &(*s1));
              compose(&(v31_5),&(v32_7))
            };
            drop(v31_5);
            let v31_9: Space = intersect(&(*CONSTANT_2),&(v31_2));
            drop(v31_2);
            let v31_10: Space = if has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
            drop(v31_9);
            let v31_12: Space = if (&(v31_10)).is_empty() { Space::new() } else {
              let v33_6: Path = concat_path(&(v30_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v33_11: Space = routine_3(c, &(v33_6), &v22_24_cursor, &(*s1));
              drop(v33_6);
              compose(&(v31_10),&(v33_11))
            };
            drop(v31_10);
            let v31_13: Space = unite(&(v31_8),&(v31_12));
            join_wrapped_into(&mut v30_11_write,&((v31_13).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v30_11_write);
          drop(v30_6);
          compose(&(v25_10),&(v30_11))
        };
        drop(v25_10);
        let v25_13: Space = unite(&(v25_8),&(v25_12));
        join_wrapped_into(&mut v24_7_write,&((v25_13).read_zipper()),&[]);
        }
        v22_24_cursor.ascend(1);
      }
      drop(v24_7_write);
      compose(&(v23_5),&(v24_7))
    };
    drop(v23_5);
    let v23_9: Space = intersect(&(*CONSTANT_2),&(v23_2));
    drop(v23_2);
    let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
    drop(v23_9);
    let v23_12: Space = if (&(v23_10)).is_empty() { Space::new() } else {
      let v34_6: Path = concat_path(&(*p0),&v22_24_cursor.path()[v22_24_origin..(v22_24_origin + 1)]);
      let mut v34_11 = Space::new();
      let mut v34_11_write = v34_11.write_zipper();
      for v34_11_byte in v22_24_cursor.child_mask().iter() {
        v22_24_cursor.descend_to_existing_byte(v34_11_byte);
        {
        let v35_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
        let v35_3: Space = intersect(&(*CONSTANT_2),&(v35_2));
        let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
        drop(v35_3);
        let v35_5: Space = subtract(&(*CONSTANT_1),&(v35_4));
        drop(v35_4);
        let v35_8: Space = if (&(v35_5)).is_empty() { Space::new() } else {
          let v36_6: Path = concat_path(&(v34_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v36_7 = Space::new();
          let mut v36_7_write = v36_7.write_zipper();
          for v36_7_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v36_7_byte);
            {
            let v37_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v37_3: Space = intersect(&(*CONSTANT_2),&(v37_2));
            let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
            drop(v37_3);
            let v37_5: Space = subtract(&(*CONSTANT_1),&(v37_4));
            drop(v37_4);
            let v37_8: Space = if (&(v37_5)).is_empty() { Space::new() } else {
              let v38_6: Path = concat_path(&(v36_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v38_7: Space = routine_6(c, &(v38_6), &v22_24_cursor, &(*s1));
              compose(&(v37_5),&(v38_7))
            };
            drop(v37_5);
            let v37_9: Space = intersect(&(*CONSTANT_2),&(v37_2));
            drop(v37_2);
            let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
            drop(v37_9);
            let v37_12: Space = if (&(v37_10)).is_empty() { Space::new() } else {
              let v39_6: Path = concat_path(&(v36_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v39_11: Space = routine_7(c, &(v39_6), &v22_24_cursor, &(*s1));
              drop(v39_6);
              compose(&(v37_10),&(v39_11))
            };
            drop(v37_10);
            let v37_13: Space = unite(&(v37_8),&(v37_12));
            join_wrapped_into(&mut v36_7_write,&((v37_13).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v36_7_write);
          compose(&(v35_5),&(v36_7))
        };
        drop(v35_5);
        let v35_9: Space = intersect(&(*CONSTANT_2),&(v35_2));
        drop(v35_2);
        let v35_10: Space = if has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
        drop(v35_9);
        let v35_12: Space = if (&(v35_10)).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v34_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v40_11 = Space::new();
          let mut v40_11_write = v40_11.write_zipper();
          for v40_11_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v40_11_byte);
            {
            let v41_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v41_3: Space = intersect(&(*CONSTANT_2),&(v41_2));
            let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = subtract(&(*CONSTANT_1),&(v41_4));
            drop(v41_4);
            let v41_7: Space = if (&(v41_5)).is_empty() { Space::new() } else {
              let v42_6: Space = routine_4(c, &v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)], &(v40_6), &v22_24_cursor, &(*s1));
              compose(&(v41_5),&(v42_6))
            };
            drop(v41_5);
            let v41_8: Space = intersect(&(*CONSTANT_2),&(v41_2));
            drop(v41_2);
            let v41_9: Space = if has_head(&(v41_8)) { singleton(&[]) } else { Space::new() };
            drop(v41_8);
            let v41_11: Space = if (&(v41_9)).is_empty() { Space::new() } else {
              let v43_10: Space = routine_5(c, &v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)], &(v40_6), &v22_24_cursor, &(*s1));
              compose(&(v41_9),&(v43_10))
            };
            drop(v41_9);
            let v41_12: Space = unite(&(v41_7),&(v41_11));
            join_wrapped_into(&mut v40_11_write,&((v41_12).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v40_11_write);
          drop(v40_6);
          compose(&(v35_10),&(v40_11))
        };
        drop(v35_10);
        let v35_13: Space = unite(&(v35_8),&(v35_12));
        join_wrapped_into(&mut v34_11_write,&((v35_13).read_zipper()),&[]);
        }
        v22_24_cursor.ascend(1);
      }
      drop(v34_11_write);
      drop(v34_6);
      compose(&(v23_10),&(v34_11))
    };
    drop(v23_10);
    let v23_13: Space = unite(&(v23_8),&(v23_12));
    join_wrapped_into(&mut v22_24_write,&((v23_13).read_zipper()),&[]);
    }
    v22_24_cursor.ascend(1);
  }
  drop(v22_24_cursor);
  drop(v22_24_write);
  (v22_24).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v44_24 = Space::new();
  let mut v44_24_write = v44_24.write_zipper();
  let mut v44_24_cursor = (*s0).read_zipper();
  let v44_24_origin = v44_24_cursor.path().len();
  for v44_24_byte in v44_24_cursor.child_mask().iter() {
    v44_24_cursor.descend_to_existing_byte(v44_24_byte);
    {
    let v45_2: Space = singleton(&v44_24_cursor.path()[v44_24_origin..(v44_24_origin + 1)]);
    let v45_3: Space = intersect(&(*CONSTANT_2),&(v45_2));
    let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
    drop(v45_3);
    let v45_5: Space = subtract(&(*CONSTANT_1),&(v45_4));
    drop(v45_4);
    let v45_8: Space = if (&(v45_5)).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&v44_24_cursor.path()[v44_24_origin..(v44_24_origin + 1)]);
      let mut v46_7 = Space::new();
      let mut v46_7_write = v46_7.write_zipper();
      for v46_7_byte in v44_24_cursor.child_mask().iter() {
        v44_24_cursor.descend_to_existing_byte(v46_7_byte);
        {
        let v47_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
        let v47_3: Space = intersect(&(*CONSTANT_2),&(v47_2));
        let v47_4: Space = if has_head(&(v47_3)) { singleton(&[]) } else { Space::new() };
        drop(v47_3);
        let v47_5: Space = subtract(&(*CONSTANT_1),&(v47_4));
        drop(v47_4);
        let v47_8: Space = if (&(v47_5)).is_empty() { Space::new() } else {
          let v48_6: Path = concat_path(&(v46_6),&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
          let mut v48_7 = Space::new();
          let mut v48_7_write = v48_7.write_zipper();
          for v48_7_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v48_7_byte);
            {
            let v49_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v49_3: Space = intersect(&(*CONSTANT_2),&(v49_2));
            let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
            drop(v49_3);
            let v49_5: Space = subtract(&(*CONSTANT_1),&(v49_4));
            drop(v49_4);
            let v49_8: Space = if (&(v49_5)).is_empty() { Space::new() } else {
              let v50_6: Path = concat_path(&(v48_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v50_7: Space = routine_6(c, &(v50_6), &v44_24_cursor, &(*s1));
              compose(&(v49_5),&(v50_7))
            };
            drop(v49_5);
            let v49_9: Space = intersect(&(*CONSTANT_2),&(v49_2));
            drop(v49_2);
            let v49_10: Space = if has_head(&(v49_9)) { singleton(&[]) } else { Space::new() };
            drop(v49_9);
            let v49_12: Space = if (&(v49_10)).is_empty() { Space::new() } else {
              let v51_6: Path = concat_path(&(v48_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v51_11: Space = routine_7(c, &(v51_6), &v44_24_cursor, &(*s1));
              drop(v51_6);
              compose(&(v49_10),&(v51_11))
            };
            drop(v49_10);
            let v49_13: Space = unite(&(v49_8),&(v49_12));
            join_wrapped_into(&mut v48_7_write,&((v49_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v48_7_write);
          compose(&(v47_5),&(v48_7))
        };
        drop(v47_5);
        let v47_9: Space = intersect(&(*CONSTANT_2),&(v47_2));
        drop(v47_2);
        let v47_10: Space = if has_head(&(v47_9)) { singleton(&[]) } else { Space::new() };
        drop(v47_9);
        let v47_12: Space = if (&(v47_10)).is_empty() { Space::new() } else {
          let v52_6: Path = concat_path(&(v46_6),&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
          let mut v52_11 = Space::new();
          let mut v52_11_write = v52_11.write_zipper();
          for v52_11_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v52_11_byte);
            {
            let v53_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v53_3: Space = intersect(&(*CONSTANT_2),&(v53_2));
            let v53_4: Space = if has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
            drop(v53_3);
            let v53_5: Space = subtract(&(*CONSTANT_1),&(v53_4));
            drop(v53_4);
            let v53_8: Space = if (&(v53_5)).is_empty() { Space::new() } else {
              let v54_6: Path = concat_path(&(v52_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v54_7: Space = routine_6(c, &(v54_6), &v44_24_cursor, &(*s1));
              compose(&(v53_5),&(v54_7))
            };
            drop(v53_5);
            let v53_9: Space = intersect(&(*CONSTANT_2),&(v53_2));
            drop(v53_2);
            let v53_10: Space = if has_head(&(v53_9)) { singleton(&[]) } else { Space::new() };
            drop(v53_9);
            let v53_12: Space = if (&(v53_10)).is_empty() { Space::new() } else {
              let v55_6: Path = concat_path(&(v52_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v55_11: Space = routine_3(c, &(v55_6), &v44_24_cursor, &(*s1));
              drop(v55_6);
              compose(&(v53_10),&(v55_11))
            };
            drop(v53_10);
            let v53_13: Space = unite(&(v53_8),&(v53_12));
            join_wrapped_into(&mut v52_11_write,&((v53_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v52_11_write);
          drop(v52_6);
          compose(&(v47_10),&(v52_11))
        };
        drop(v47_10);
        let v47_13: Space = unite(&(v47_8),&(v47_12));
        join_wrapped_into(&mut v46_7_write,&((v47_13).read_zipper()),&[]);
        }
        v44_24_cursor.ascend(1);
      }
      drop(v46_7_write);
      compose(&(v45_5),&(v46_7))
    };
    drop(v45_5);
    let v45_9: Space = intersect(&(*CONSTANT_2),&(v45_2));
    drop(v45_2);
    let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
    drop(v45_9);
    let v45_12: Space = if (&(v45_10)).is_empty() { Space::new() } else {
      let v56_6: Path = concat_path(&(*p0),&v44_24_cursor.path()[v44_24_origin..(v44_24_origin + 1)]);
      let mut v56_11 = Space::new();
      let mut v56_11_write = v56_11.write_zipper();
      for v56_11_byte in v44_24_cursor.child_mask().iter() {
        v44_24_cursor.descend_to_existing_byte(v56_11_byte);
        {
        let v57_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
        let v57_3: Space = intersect(&(*CONSTANT_2),&(v57_2));
        let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = subtract(&(*CONSTANT_1),&(v57_4));
        drop(v57_4);
        let v57_7: Space = if (&(v57_5)).is_empty() { Space::new() } else {
          let mut v58_6 = Space::new();
          let mut v58_6_write = v58_6.write_zipper();
          for v58_6_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v58_6_byte);
            {
            let v59_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v59_3: Space = intersect(&(*CONSTANT_2),&(v59_2));
            let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
            drop(v59_3);
            let v59_5: Space = subtract(&(*CONSTANT_1),&(v59_4));
            drop(v59_4);
            let v59_8: Space = if (&(v59_5)).is_empty() { Space::new() } else {
              let v60_7: Space = routine_8(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              compose(&(v59_5),&(v60_7))
            };
            drop(v59_5);
            let v59_9: Space = intersect(&(*CONSTANT_2),&(v59_2));
            drop(v59_2);
            let v59_10: Space = if has_head(&(v59_9)) { singleton(&[]) } else { Space::new() };
            drop(v59_9);
            let v59_12: Space = if (&(v59_10)).is_empty() { Space::new() } else {
              let v61_11: Space = routine_9(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              compose(&(v59_10),&(v61_11))
            };
            drop(v59_10);
            let v59_13: Space = unite(&(v59_8),&(v59_12));
            join_wrapped_into(&mut v58_6_write,&((v59_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v58_6_write);
          compose(&(v57_5),&(v58_6))
        };
        drop(v57_5);
        let v57_8: Space = intersect(&(*CONSTANT_2),&(v57_2));
        drop(v57_2);
        let v57_9: Space = if has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
        drop(v57_8);
        let v57_11: Space = if (&(v57_9)).is_empty() { Space::new() } else {
          let mut v62_10 = Space::new();
          let mut v62_10_write = v62_10.write_zipper();
          for v62_10_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v62_10_byte);
            {
            let v63_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v63_3: Space = intersect(&(*CONSTANT_2),&(v63_2));
            let v63_4: Space = if has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
            drop(v63_3);
            let v63_5: Space = subtract(&(*CONSTANT_1),&(v63_4));
            drop(v63_4);
            let v63_8: Space = if (&(v63_5)).is_empty() { Space::new() } else {
              let v64_7: Space = routine_8(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              compose(&(v63_5),&(v64_7))
            };
            drop(v63_5);
            let v63_9: Space = intersect(&(*CONSTANT_2),&(v63_2));
            drop(v63_2);
            let v63_10: Space = if has_head(&(v63_9)) { singleton(&[]) } else { Space::new() };
            drop(v63_9);
            let v63_12: Space = if (&(v63_10)).is_empty() { Space::new() } else {
              let v65_11: Space = routine_10(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              compose(&(v63_10),&(v65_11))
            };
            drop(v63_10);
            let v63_13: Space = unite(&(v63_8),&(v63_12));
            join_wrapped_into(&mut v62_10_write,&((v63_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v62_10_write);
          compose(&(v57_9),&(v62_10))
        };
        drop(v57_9);
        let v57_12: Space = unite(&(v57_7),&(v57_11));
        join_wrapped_into(&mut v56_11_write,&((v57_12).read_zipper()),&[]);
        }
        v44_24_cursor.ascend(1);
      }
      drop(v56_11_write);
      drop(v56_6);
      compose(&(v45_10),&(v56_11))
    };
    drop(v45_10);
    let v45_13: Space = unite(&(v45_8),&(v45_12));
    join_wrapped_into(&mut v44_24_write,&((v45_13).read_zipper()),&[]);
    }
    v44_24_cursor.ascend(1);
  }
  drop(v44_24_cursor);
  drop(v44_24_write);
  (v44_24).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v66_26 = Space::new();
  let mut v66_26_write = v66_26.write_zipper();
  let mut v66_26_cursor = (*s0).read_zipper();
  let v66_26_origin = v66_26_cursor.path().len();
  for v66_26_byte in v66_26_cursor.child_mask().iter() {
    v66_26_cursor.descend_to_existing_byte(v66_26_byte);
    {
    let v67_2: Space = singleton(&v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 1)]);
    let v67_3: Space = intersect(&(*CONSTANT_2),&(v67_2));
    let v67_4: Space = if has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
    drop(v67_3);
    let v67_5: Space = subtract(&(*CONSTANT_1),&(v67_4));
    drop(v67_4);
    let v67_7: Space = if (&(v67_5)).is_empty() { Space::new() } else {
      let mut v68_6 = Space::new();
      let mut v68_6_write = v68_6.write_zipper();
      for v68_6_byte in v66_26_cursor.child_mask().iter() {
        v66_26_cursor.descend_to_existing_byte(v68_6_byte);
        {
        let v69_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 1)..(v66_26_origin + 2)]);
        let v69_3: Space = intersect(&(*CONSTANT_2),&(v69_2));
        let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
        drop(v69_3);
        let v69_5: Space = subtract(&(*CONSTANT_1),&(v69_4));
        drop(v69_4);
        let v69_8: Space = if (&(v69_5)).is_empty() { Space::new() } else {
          let mut v70_7 = Space::new();
          let mut v70_7_write = v70_7.write_zipper();
          for v70_7_byte in v66_26_cursor.child_mask().iter() {
            v66_26_cursor.descend_to_existing_byte(v70_7_byte);
            {
            let v71_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 2)..(v66_26_origin + 3)]);
            let v71_3: Space = intersect(&(*CONSTANT_2),&(v71_2));
            let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
            drop(v71_3);
            let v71_5: Space = subtract(&(*CONSTANT_1),&(v71_4));
            drop(v71_4);
            let v71_8: Space = if (&(v71_5)).is_empty() { Space::new() } else {
              let v72_7: Space = routine_11(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              compose(&(v71_5),&(v72_7))
            };
            drop(v71_5);
            let v71_9: Space = intersect(&(*CONSTANT_2),&(v71_2));
            drop(v71_2);
            let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
            drop(v71_9);
            let v71_12: Space = if (&(v71_10)).is_empty() { Space::new() } else {
              let v73_11: Space = routine_12(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              compose(&(v71_10),&(v73_11))
            };
            drop(v71_10);
            let v71_13: Space = unite(&(v71_8),&(v71_12));
            join_wrapped_into(&mut v70_7_write,&((v71_13).read_zipper()),&[]);
            }
            v66_26_cursor.ascend(1);
          }
          drop(v70_7_write);
          compose(&(v69_5),&(v70_7))
        };
        drop(v69_5);
        let v69_9: Space = intersect(&(*CONSTANT_2),&(v69_2));
        drop(v69_2);
        let v69_10: Space = if has_head(&(v69_9)) { singleton(&[]) } else { Space::new() };
        drop(v69_9);
        let v69_12: Space = if (&(v69_10)).is_empty() { Space::new() } else {
          let mut v74_11 = Space::new();
          let mut v74_11_write = v74_11.write_zipper();
          for v74_11_byte in v66_26_cursor.child_mask().iter() {
            v66_26_cursor.descend_to_existing_byte(v74_11_byte);
            {
            let v75_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 2)..(v66_26_origin + 3)]);
            let v75_3: Space = intersect(&(*CONSTANT_2),&(v75_2));
            let v75_4: Space = if has_head(&(v75_3)) { singleton(&[]) } else { Space::new() };
            drop(v75_3);
            let v75_5: Space = subtract(&(*CONSTANT_1),&(v75_4));
            drop(v75_4);
            let v75_8: Space = if (&(v75_5)).is_empty() { Space::new() } else {
              let v76_7: Space = routine_11(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              compose(&(v75_5),&(v76_7))
            };
            drop(v75_5);
            let v75_9: Space = intersect(&(*CONSTANT_2),&(v75_2));
            drop(v75_2);
            let v75_10: Space = if has_head(&(v75_9)) { singleton(&[]) } else { Space::new() };
            drop(v75_9);
            let v75_12: Space = if (&(v75_10)).is_empty() { Space::new() } else {
              let v77_11: Space = routine_10(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              compose(&(v75_10),&(v77_11))
            };
            drop(v75_10);
            let v75_13: Space = unite(&(v75_8),&(v75_12));
            join_wrapped_into(&mut v74_11_write,&((v75_13).read_zipper()),&[]);
            }
            v66_26_cursor.ascend(1);
          }
          drop(v74_11_write);
          compose(&(v69_10),&(v74_11))
        };
        drop(v69_10);
        let v69_13: Space = unite(&(v69_8),&(v69_12));
        join_wrapped_into(&mut v68_6_write,&((v69_13).read_zipper()),&[]);
        }
        v66_26_cursor.ascend(1);
      }
      drop(v68_6_write);
      compose(&(v67_5),&(v68_6))
    };
    drop(v67_5);
    let v67_8: Space = intersect(&(*CONSTANT_2),&(v67_2));
    drop(v67_2);
    let v67_9: Space = if has_head(&(v67_8)) { singleton(&[]) } else { Space::new() };
    drop(v67_8);
    let v67_12: Space = if (&(v67_9)).is_empty() { Space::new() } else {
      let mut v78_11 = Space::new();
      let mut v78_11_write = v78_11.write_zipper();
      for v78_11_byte in v66_26_cursor.child_mask().iter() {
        v66_26_cursor.descend_to_existing_byte(v78_11_byte);
        {
        let v79_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 1)..(v66_26_origin + 2)]);
        let v79_3: Space = intersect(&(*CONSTANT_2),&(v79_2));
        let v79_4: Space = if has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
        drop(v79_3);
        let v79_5: Space = subtract(&(*CONSTANT_1),&(v79_4));
        drop(v79_4);
        let v79_8: Space = if (&(v79_5)).is_empty() { Space::new() } else {
          let mut v80_7 = Space::new();
          let mut v80_7_write = v80_7.write_zipper();
          for v80_7_byte in v66_26_cursor.child_mask().iter() {
            v66_26_cursor.descend_to_existing_byte(v80_7_byte);
            {
            let v81_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 2)..(v66_26_origin + 3)]);
            let v81_3: Space = intersect(&(*CONSTANT_2),&(v81_2));
            let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
            drop(v81_3);
            let v81_5: Space = subtract(&(*CONSTANT_1),&(v81_4));
            drop(v81_4);
            let v81_8: Space = if (&(v81_5)).is_empty() { Space::new() } else {
              let v82_7: Space = routine_11(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              compose(&(v81_5),&(v82_7))
            };
            drop(v81_5);
            let v81_9: Space = intersect(&(*CONSTANT_2),&(v81_2));
            drop(v81_2);
            let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
            drop(v81_9);
            let v81_12: Space = if (&(v81_10)).is_empty() { Space::new() } else {
              let v83_11: Space = routine_12(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              compose(&(v81_10),&(v83_11))
            };
            drop(v81_10);
            let v81_13: Space = unite(&(v81_8),&(v81_12));
            join_wrapped_into(&mut v80_7_write,&((v81_13).read_zipper()),&[]);
            }
            v66_26_cursor.ascend(1);
          }
          drop(v80_7_write);
          compose(&(v79_5),&(v80_7))
        };
        drop(v79_5);
        let v79_9: Space = intersect(&(*CONSTANT_2),&(v79_2));
        drop(v79_2);
        let v79_10: Space = if has_head(&(v79_9)) { singleton(&[]) } else { Space::new() };
        drop(v79_9);
        let v79_13: Space = if (&(v79_10)).is_empty() { Space::new() } else {
          let mut v84_12 = Space::new();
          let mut v84_12_write = v84_12.write_zipper();
          let mut v84_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 1)]),&v66_26_cursor.path()[(v66_26_origin + 1)..(v66_26_origin + 2)]);
          let v84_12_origin = v84_12_cursor.path().len();
          for v84_12_byte in v84_12_cursor.child_mask().iter() {
            v84_12_cursor.descend_to_existing_byte(v84_12_byte);
            {
            let v85_2: Space = singleton(&v84_12_cursor.path()[v84_12_origin..(v84_12_origin + 1)]);
            let v85_3: Space = intersect(&(*CONSTANT_2),&(v85_2));
            let v85_4: Space = if has_head(&(v85_3)) { singleton(&[]) } else { Space::new() };
            drop(v85_3);
            let v85_5: Space = subtract(&(*CONSTANT_1),&(v85_4));
            drop(v85_4);
            let v85_7: Space = if (&(v85_5)).is_empty() { Space::new() } else {
              let v86_6: Space = routine_13(c, &v84_12_cursor.path()[v84_12_origin..(v84_12_origin + 1)], &(*p0), &v84_12_cursor);
              compose(&(v85_5),&(v86_6))
            };
            drop(v85_5);
            let v85_8: Space = intersect(&(*CONSTANT_2),&(v85_2));
            drop(v85_2);
            let v85_9: Space = if has_head(&(v85_8)) { singleton(&[]) } else { Space::new() };
            drop(v85_8);
            let v85_11: Space = if (&(v85_9)).is_empty() { Space::new() } else {
              let v87_10: Space = routine_14(c, &v84_12_cursor.path()[v84_12_origin..(v84_12_origin + 1)], &(*p0), &v84_12_cursor);
              compose(&(v85_9),&(v87_10))
            };
            drop(v85_9);
            let v85_12: Space = unite(&(v85_7),&(v85_11));
            join_wrapped_into(&mut v84_12_write,&((v85_12).read_zipper()),&[]);
            }
            v84_12_cursor.ascend(1);
          }
          drop(v84_12_cursor);
          drop(v84_12_write);
          compose(&(v79_10),&(v84_12))
        };
        drop(v79_10);
        let v79_14: Space = unite(&(v79_8),&(v79_13));
        join_wrapped_into(&mut v78_11_write,&((v79_14).read_zipper()),&[]);
        }
        v66_26_cursor.ascend(1);
      }
      drop(v78_11_write);
      compose(&(v67_9),&(v78_11))
    };
    drop(v67_9);
    let v67_13: Space = unite(&(v67_7),&(v67_12));
    join_wrapped_into(&mut v66_26_write,&((v67_13).read_zipper()),&[]);
    }
    v66_26_cursor.ascend(1);
  }
  drop(v66_26_cursor);
  drop(v66_26_write);
  (v66_26).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v88_28 = Space::new();
  let mut v88_28_write = v88_28.write_zipper();
  let mut v88_28_cursor = (*s0).read_zipper();
  let v88_28_origin = v88_28_cursor.path().len();
  for v88_28_byte in v88_28_cursor.child_mask().iter() {
    v88_28_cursor.descend_to_existing_byte(v88_28_byte);
    {
    let v89_2: Space = singleton(&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]);
    let v89_3: Space = intersect(&(*CONSTANT_2),&(v89_2));
    let v89_4: Space = if has_head(&(v89_3)) { singleton(&[]) } else { Space::new() };
    drop(v89_3);
    let v89_5: Space = subtract(&(*CONSTANT_1),&(v89_4));
    drop(v89_4);
    let v89_8: Space = if (&(v89_5)).is_empty() { Space::new() } else {
      let v90_6: Path = concat_path(&(*p0),&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]);
      let mut v90_7 = Space::new();
      let mut v90_7_write = v90_7.write_zipper();
      for v90_7_byte in v88_28_cursor.child_mask().iter() {
        v88_28_cursor.descend_to_existing_byte(v90_7_byte);
        {
        let v91_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
        let v91_3: Space = intersect(&(*CONSTANT_2),&(v91_2));
        let v91_4: Space = if has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
        drop(v91_3);
        let v91_5: Space = subtract(&(*CONSTANT_1),&(v91_4));
        drop(v91_4);
        let v91_8: Space = if (&(v91_5)).is_empty() { Space::new() } else {
          let v92_6: Path = concat_path(&(v90_6),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let mut v92_7 = Space::new();
          let mut v92_7_write = v92_7.write_zipper();
          for v92_7_byte in v88_28_cursor.child_mask().iter() {
            v88_28_cursor.descend_to_existing_byte(v92_7_byte);
            {
            let v93_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
            let v93_3: Space = intersect(&(*CONSTANT_2),&(v93_2));
            let v93_4: Space = if has_head(&(v93_3)) { singleton(&[]) } else { Space::new() };
            drop(v93_3);
            let v93_5: Space = subtract(&(*CONSTANT_1),&(v93_4));
            drop(v93_4);
            let v93_8: Space = if (&(v93_5)).is_empty() { Space::new() } else {
              let v94_6: Path = concat_path(&(v92_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v94_7: Space = routine_15(c, &(v94_6), &(*p1), &v88_28_cursor, &(*s1));
              compose(&(v93_5),&(v94_7))
            };
            drop(v93_5);
            let v93_9: Space = intersect(&(*CONSTANT_2),&(v93_2));
            drop(v93_2);
            let v93_10: Space = if has_head(&(v93_9)) { singleton(&[]) } else { Space::new() };
            drop(v93_9);
            let v93_12: Space = if (&(v93_10)).is_empty() { Space::new() } else {
              let v95_6: Path = concat_path(&(v92_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v95_11: Space = routine_16(c, &(v95_6), &(*p1), &v88_28_cursor, &(*s1));
              drop(v95_6);
              compose(&(v93_10),&(v95_11))
            };
            drop(v93_10);
            let v93_13: Space = unite(&(v93_8),&(v93_12));
            join_wrapped_into(&mut v92_7_write,&((v93_13).read_zipper()),&[]);
            }
            v88_28_cursor.ascend(1);
          }
          drop(v92_7_write);
          compose(&(v91_5),&(v92_7))
        };
        drop(v91_5);
        let v91_9: Space = intersect(&(*CONSTANT_2),&(v91_2));
        drop(v91_2);
        let v91_10: Space = if has_head(&(v91_9)) { singleton(&[]) } else { Space::new() };
        drop(v91_9);
        let v91_12: Space = if (&(v91_10)).is_empty() { Space::new() } else {
          let v96_6: Path = concat_path(&(v90_6),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let mut v96_11 = Space::new();
          let mut v96_11_write = v96_11.write_zipper();
          for v96_11_byte in v88_28_cursor.child_mask().iter() {
            v88_28_cursor.descend_to_existing_byte(v96_11_byte);
            {
            let v97_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
            let v97_3: Space = intersect(&(*CONSTANT_2),&(v97_2));
            let v97_4: Space = if has_head(&(v97_3)) { singleton(&[]) } else { Space::new() };
            drop(v97_3);
            let v97_5: Space = subtract(&(*CONSTANT_1),&(v97_4));
            drop(v97_4);
            let v97_8: Space = if (&(v97_5)).is_empty() { Space::new() } else {
              let v98_6: Path = concat_path(&(v96_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v98_7: Space = routine_15(c, &(v98_6), &(*p1), &v88_28_cursor, &(*s1));
              compose(&(v97_5),&(v98_7))
            };
            drop(v97_5);
            let v97_9: Space = intersect(&(*CONSTANT_2),&(v97_2));
            drop(v97_2);
            let v97_10: Space = if has_head(&(v97_9)) { singleton(&[]) } else { Space::new() };
            drop(v97_9);
            let v97_12: Space = if (&(v97_10)).is_empty() { Space::new() } else {
              let v99_6: Path = concat_path(&(v96_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v99_11: Space = routine_10(c, &(v99_6), &(*p1), &v88_28_cursor, &(*s1));
              drop(v99_6);
              compose(&(v97_10),&(v99_11))
            };
            drop(v97_10);
            let v97_13: Space = unite(&(v97_8),&(v97_12));
            join_wrapped_into(&mut v96_11_write,&((v97_13).read_zipper()),&[]);
            }
            v88_28_cursor.ascend(1);
          }
          drop(v96_11_write);
          drop(v96_6);
          compose(&(v91_10),&(v96_11))
        };
        drop(v91_10);
        let v91_13: Space = unite(&(v91_8),&(v91_12));
        join_wrapped_into(&mut v90_7_write,&((v91_13).read_zipper()),&[]);
        }
        v88_28_cursor.ascend(1);
      }
      drop(v90_7_write);
      compose(&(v89_5),&(v90_7))
    };
    drop(v89_5);
    let v89_9: Space = intersect(&(*CONSTANT_2),&(v89_2));
    drop(v89_2);
    let v89_10: Space = if has_head(&(v89_9)) { singleton(&[]) } else { Space::new() };
    drop(v89_9);
    let v89_13: Space = if (&(v89_10)).is_empty() { Space::new() } else {
      let v100_6: Path = concat_path(&(*p0),&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]);
      let mut v100_12 = Space::new();
      let mut v100_12_write = v100_12.write_zipper();
      for v100_12_byte in v88_28_cursor.child_mask().iter() {
        v88_28_cursor.descend_to_existing_byte(v100_12_byte);
        {
        let v101_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
        let v101_3: Space = intersect(&(*CONSTANT_2),&(v101_2));
        let v101_4: Space = if has_head(&(v101_3)) { singleton(&[]) } else { Space::new() };
        drop(v101_3);
        let v101_5: Space = subtract(&(*CONSTANT_1),&(v101_4));
        drop(v101_4);
        let v101_8: Space = if (&(v101_5)).is_empty() { Space::new() } else {
          let v102_6: Path = concat_path(&(v100_6),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let mut v102_7 = Space::new();
          let mut v102_7_write = v102_7.write_zipper();
          for v102_7_byte in v88_28_cursor.child_mask().iter() {
            v88_28_cursor.descend_to_existing_byte(v102_7_byte);
            {
            let v103_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
            let v103_3: Space = intersect(&(*CONSTANT_2),&(v103_2));
            let v103_4: Space = if has_head(&(v103_3)) { singleton(&[]) } else { Space::new() };
            drop(v103_3);
            let v103_5: Space = subtract(&(*CONSTANT_1),&(v103_4));
            drop(v103_4);
            let v103_8: Space = if (&(v103_5)).is_empty() { Space::new() } else {
              let v104_6: Path = concat_path(&(v102_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v104_7: Space = routine_15(c, &(v104_6), &(*p1), &v88_28_cursor, &(*s1));
              compose(&(v103_5),&(v104_7))
            };
            drop(v103_5);
            let v103_9: Space = intersect(&(*CONSTANT_2),&(v103_2));
            drop(v103_2);
            let v103_10: Space = if has_head(&(v103_9)) { singleton(&[]) } else { Space::new() };
            drop(v103_9);
            let v103_12: Space = if (&(v103_10)).is_empty() { Space::new() } else {
              let v105_6: Path = concat_path(&(v102_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v105_11: Space = routine_16(c, &(v105_6), &(*p1), &v88_28_cursor, &(*s1));
              drop(v105_6);
              compose(&(v103_10),&(v105_11))
            };
            drop(v103_10);
            let v103_13: Space = unite(&(v103_8),&(v103_12));
            join_wrapped_into(&mut v102_7_write,&((v103_13).read_zipper()),&[]);
            }
            v88_28_cursor.ascend(1);
          }
          drop(v102_7_write);
          drop(v102_6);
          compose(&(v101_5),&(v102_7))
        };
        drop(v101_5);
        let v101_9: Space = intersect(&(*CONSTANT_2),&(v101_2));
        drop(v101_2);
        let v101_10: Space = if has_head(&(v101_9)) { singleton(&[]) } else { Space::new() };
        drop(v101_9);
        let v101_13: Space = if (&(v101_10)).is_empty() { Space::new() } else {
          let mut v106_12 = Space::new();
          let mut v106_12_write = v106_12.write_zipper();
          let mut v106_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let v106_12_origin = v106_12_cursor.path().len();
          for v106_12_byte in v106_12_cursor.child_mask().iter() {
            v106_12_cursor.descend_to_existing_byte(v106_12_byte);
            {
            let v107_2: Space = singleton(&v106_12_cursor.path()[v106_12_origin..(v106_12_origin + 1)]);
            let v107_3: Space = intersect(&(*CONSTANT_2),&(v107_2));
            let v107_4: Space = if has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
            drop(v107_3);
            let v107_5: Space = subtract(&(*CONSTANT_1),&(v107_4));
            drop(v107_4);
            let v107_7: Space = if (&(v107_5)).is_empty() { Space::new() } else {
              let v108_6: Space = routine_13(c, &v106_12_cursor.path()[v106_12_origin..(v106_12_origin + 1)], &(*p1), &v106_12_cursor);
              compose(&(v107_5),&(v108_6))
            };
            drop(v107_5);
            let v107_8: Space = intersect(&(*CONSTANT_2),&(v107_2));
            drop(v107_2);
            let v107_9: Space = if has_head(&(v107_8)) { singleton(&[]) } else { Space::new() };
            drop(v107_8);
            let v107_11: Space = if (&(v107_9)).is_empty() { Space::new() } else {
              let v109_10: Space = routine_14(c, &v106_12_cursor.path()[v106_12_origin..(v106_12_origin + 1)], &(*p1), &v106_12_cursor);
              compose(&(v107_9),&(v109_10))
            };
            drop(v107_9);
            let v107_12: Space = unite(&(v107_7),&(v107_11));
            join_wrapped_into(&mut v106_12_write,&((v107_12).read_zipper()),&[]);
            }
            v106_12_cursor.ascend(1);
          }
          drop(v106_12_cursor);
          drop(v106_12_write);
          compose(&(v101_10),&(v106_12))
        };
        drop(v101_10);
        let v101_14: Space = unite(&(v101_8),&(v101_13));
        join_wrapped_into(&mut v100_12_write,&((v101_14).read_zipper()),&[]);
        }
        v88_28_cursor.ascend(1);
      }
      drop(v100_12_write);
      drop(v100_6);
      compose(&(v89_10),&(v100_12))
    };
    drop(v89_10);
    let v89_14: Space = unite(&(v89_8),&(v89_13));
    join_wrapped_into(&mut v88_28_write,&((v89_14).read_zipper()),&[]);
    }
    v88_28_cursor.ascend(1);
  }
  drop(v88_28_cursor);
  drop(v88_28_write);
  (v88_28).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v110_28 = Space::new();
  let mut v110_28_write = v110_28.write_zipper();
  let mut v110_28_cursor = (*s0).read_zipper();
  let v110_28_origin = v110_28_cursor.path().len();
  for v110_28_byte in v110_28_cursor.child_mask().iter() {
    v110_28_cursor.descend_to_existing_byte(v110_28_byte);
    {
    let v111_2: Space = singleton(&v110_28_cursor.path()[v110_28_origin..(v110_28_origin + 1)]);
    let v111_3: Space = intersect(&(*CONSTANT_2),&(v111_2));
    let v111_4: Space = if has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
    drop(v111_3);
    let v111_5: Space = subtract(&(*CONSTANT_1),&(v111_4));
    drop(v111_4);
    let v111_8: Space = if (&(v111_5)).is_empty() { Space::new() } else {
      let v112_6: Path = concat_path(&(*p0),&v110_28_cursor.path()[v110_28_origin..(v110_28_origin + 1)]);
      let mut v112_7 = Space::new();
      let mut v112_7_write = v112_7.write_zipper();
      for v112_7_byte in v110_28_cursor.child_mask().iter() {
        v110_28_cursor.descend_to_existing_byte(v112_7_byte);
        {
        let v113_2: Space = singleton(&v110_28_cursor.path()[(v110_28_origin + 1)..(v110_28_origin + 2)]);
        let v113_3: Space = intersect(&(*CONSTANT_2),&(v113_2));
        let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
        drop(v113_3);
        let v113_5: Space = subtract(&(*CONSTANT_1),&(v113_4));
        drop(v113_4);
        let v113_8: Space = if (&(v113_5)).is_empty() { Space::new() } else {
          let v114_6: Path = concat_path(&(v112_6),&v110_28_cursor.path()[(v110_28_origin + 1)..(v110_28_origin + 2)]);
          let mut v114_7 = Space::new();
          let mut v114_7_write = v114_7.write_zipper();
          for v114_7_byte in v110_28_cursor.child_mask().iter() {
            v110_28_cursor.descend_to_existing_byte(v114_7_byte);
            {
            let v115_2: Space = singleton(&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
            let v115_3: Space = intersect(&(*CONSTANT_2),&(v115_2));
            let v115_4: Space = if has_head(&(v115_3)) { singleton(&[]) } else { Space::new() };
            drop(v115_3);
            let v115_5: Space = subtract(&(*CONSTANT_1),&(v115_4));
            drop(v115_4);
            let v115_8: Space = if (&(v115_5)).is_empty() { Space::new() } else {
              let v116_6: Path = concat_path(&(v114_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v116_7: Space = routine_15(c, &(v116_6), &(*p1), &v110_28_cursor, &(*s1));
              compose(&(v115_5),&(v116_7))
            };
            drop(v115_5);
            let v115_9: Space = intersect(&(*CONSTANT_2),&(v115_2));
            drop(v115_2);
            let v115_10: Space = if has_head(&(v115_9)) { singleton(&[]) } else { Space::new() };
            drop(v115_9);
            let v115_12: Space = if (&(v115_10)).is_empty() { Space::new() } else {
              let v117_6: Path = concat_path(&(v114_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v117_11: Space = routine_16(c, &(v117_6), &(*p1), &v110_28_cursor, &(*s1));
              drop(v117_6);
              compose(&(v115_10),&(v117_11))
            };
            drop(v115_10);
            let v115_13: Space = unite(&(v115_8),&(v115_12));
            join_wrapped_into(&mut v114_7_write,&((v115_13).read_zipper()),&[]);
            }
            v110_28_cursor.ascend(1);
          }
          drop(v114_7_write);
          compose(&(v113_5),&(v114_7))
        };
        drop(v113_5);
        let v113_9: Space = intersect(&(*CONSTANT_2),&(v113_2));
        drop(v113_2);
        let v113_10: Space = if has_head(&(v113_9)) { singleton(&[]) } else { Space::new() };
        drop(v113_9);
        let v113_12: Space = if (&(v113_10)).is_empty() { Space::new() } else {
          let v118_6: Path = concat_path(&(v112_6),&v110_28_cursor.path()[(v110_28_origin + 1)..(v110_28_origin + 2)]);
          let mut v118_11 = Space::new();
          let mut v118_11_write = v118_11.write_zipper();
          for v118_11_byte in v110_28_cursor.child_mask().iter() {
            v110_28_cursor.descend_to_existing_byte(v118_11_byte);
            {
            let v119_2: Space = singleton(&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
            let v119_3: Space = intersect(&(*CONSTANT_2),&(v119_2));
            let v119_4: Space = if has_head(&(v119_3)) { singleton(&[]) } else { Space::new() };
            drop(v119_3);
            let v119_5: Space = subtract(&(*CONSTANT_1),&(v119_4));
            drop(v119_4);
            let v119_8: Space = if (&(v119_5)).is_empty() { Space::new() } else {
              let v120_6: Path = concat_path(&(v118_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v120_7: Space = routine_15(c, &(v120_6), &(*p1), &v110_28_cursor, &(*s1));
              compose(&(v119_5),&(v120_7))
            };
            drop(v119_5);
            let v119_9: Space = intersect(&(*CONSTANT_2),&(v119_2));
            drop(v119_2);
            let v119_10: Space = if has_head(&(v119_9)) { singleton(&[]) } else { Space::new() };
            drop(v119_9);
            let v119_12: Space = if (&(v119_10)).is_empty() { Space::new() } else {
              let v121_6: Path = concat_path(&(v118_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v121_11: Space = routine_10(c, &(v121_6), &(*p1), &v110_28_cursor, &(*s1));
              drop(v121_6);
              compose(&(v119_10),&(v121_11))
            };
            drop(v119_10);
            let v119_13: Space = unite(&(v119_8),&(v119_12));
            join_wrapped_into(&mut v118_11_write,&((v119_13).read_zipper()),&[]);
            }
            v110_28_cursor.ascend(1);
          }
          drop(v118_11_write);
          drop(v118_6);
          compose(&(v113_10),&(v118_11))
        };
        drop(v113_10);
        let v113_13: Space = unite(&(v113_8),&(v113_12));
        join_wrapped_into(&mut v112_7_write,&((v113_13).read_zipper()),&[]);
        }
        v110_28_cursor.ascend(1);
      }
      drop(v112_7_write);
      drop(v112_6);
      compose(&(v111_5),&(v112_7))
    };
    drop(v111_5);
    let v111_9: Space = intersect(&(*CONSTANT_2),&(v111_2));
    drop(v111_2);
    let v111_10: Space = if has_head(&(v111_9)) { singleton(&[]) } else { Space::new() };
    drop(v111_9);
    let v111_13: Space = if (&(v111_10)).is_empty() { Space::new() } else {
      let mut v122_12 = Space::new();
      let mut v122_12_write = v122_12.write_zipper();
      let mut v122_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v110_28_cursor.path()[v110_28_origin..(v110_28_origin + 1)]);
      let v122_12_origin = v122_12_cursor.path().len();
      for v122_12_byte in v122_12_cursor.child_mask().iter() {
        v122_12_cursor.descend_to_existing_byte(v122_12_byte);
        {
        let v123_2: Space = singleton(&v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 1)]);
        let v123_3: Space = intersect(&(*CONSTANT_2),&(v123_2));
        let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = subtract(&(*CONSTANT_1),&(v123_4));
        drop(v123_4);
        let v123_7: Space = if (&(v123_5)).is_empty() { Space::new() } else {
          let mut v124_6 = Space::new();
          let mut v124_6_write = v124_6.write_zipper();
          for v124_6_byte in v122_12_cursor.child_mask().iter() {
            v122_12_cursor.descend_to_existing_byte(v124_6_byte);
            {
            let v125_2: Space = singleton(&v122_12_cursor.path()[(v122_12_origin + 1)..(v122_12_origin + 2)]);
            let v125_3: Space = intersect(&(*CONSTANT_2),&(v125_2));
            let v125_4: Space = if has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
            drop(v125_3);
            let v125_5: Space = subtract(&(*CONSTANT_1),&(v125_4));
            drop(v125_4);
            let v125_8: Space = if (&(v125_5)).is_empty() { Space::new() } else {
              let v126_7: Space = routine_17(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              compose(&(v125_5),&(v126_7))
            };
            drop(v125_5);
            let v125_9: Space = intersect(&(*CONSTANT_2),&(v125_2));
            drop(v125_2);
            let v125_10: Space = if has_head(&(v125_9)) { singleton(&[]) } else { Space::new() };
            drop(v125_9);
            let v125_12: Space = if (&(v125_10)).is_empty() { Space::new() } else {
              let v127_11: Space = routine_18(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              compose(&(v125_10),&(v127_11))
            };
            drop(v125_10);
            let v125_13: Space = unite(&(v125_8),&(v125_12));
            join_wrapped_into(&mut v124_6_write,&((v125_13).read_zipper()),&[]);
            }
            v122_12_cursor.ascend(1);
          }
          drop(v124_6_write);
          compose(&(v123_5),&(v124_6))
        };
        drop(v123_5);
        let v123_8: Space = intersect(&(*CONSTANT_2),&(v123_2));
        drop(v123_2);
        let v123_9: Space = if has_head(&(v123_8)) { singleton(&[]) } else { Space::new() };
        drop(v123_8);
        let v123_11: Space = if (&(v123_9)).is_empty() { Space::new() } else {
          let mut v128_10 = Space::new();
          let mut v128_10_write = v128_10.write_zipper();
          for v128_10_byte in v122_12_cursor.child_mask().iter() {
            v122_12_cursor.descend_to_existing_byte(v128_10_byte);
            {
            let v129_2: Space = singleton(&v122_12_cursor.path()[(v122_12_origin + 1)..(v122_12_origin + 2)]);
            let v129_3: Space = intersect(&(*CONSTANT_2),&(v129_2));
            let v129_4: Space = if has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
            drop(v129_3);
            let v129_5: Space = subtract(&(*CONSTANT_1),&(v129_4));
            drop(v129_4);
            let v129_8: Space = if (&(v129_5)).is_empty() { Space::new() } else {
              let v130_7: Space = routine_17(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              compose(&(v129_5),&(v130_7))
            };
            drop(v129_5);
            let v129_9: Space = intersect(&(*CONSTANT_2),&(v129_2));
            drop(v129_2);
            let v129_10: Space = if has_head(&(v129_9)) { singleton(&[]) } else { Space::new() };
            drop(v129_9);
            let v129_12: Space = if (&(v129_10)).is_empty() { Space::new() } else {
              let v131_11: Space = routine_19(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              compose(&(v129_10),&(v131_11))
            };
            drop(v129_10);
            let v129_13: Space = unite(&(v129_8),&(v129_12));
            join_wrapped_into(&mut v128_10_write,&((v129_13).read_zipper()),&[]);
            }
            v122_12_cursor.ascend(1);
          }
          drop(v128_10_write);
          compose(&(v123_9),&(v128_10))
        };
        drop(v123_9);
        let v123_12: Space = unite(&(v123_7),&(v123_11));
        join_wrapped_into(&mut v122_12_write,&((v123_12).read_zipper()),&[]);
        }
        v122_12_cursor.ascend(1);
      }
      drop(v122_12_cursor);
      drop(v122_12_write);
      compose(&(v111_10),&(v122_12))
    };
    drop(v111_10);
    let v111_14: Space = unite(&(v111_8),&(v111_13));
    join_wrapped_into(&mut v110_28_write,&((v111_14).read_zipper()),&[]);
    }
    v110_28_cursor.ascend(1);
  }
  drop(v110_28_cursor);
  drop(v110_28_write);
  (v110_28).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v132_24 = Space::new();
  let mut v132_24_write = v132_24.write_zipper();
  let mut v132_24_cursor = (*s0).read_zipper();
  let v132_24_origin = v132_24_cursor.path().len();
  for v132_24_byte in v132_24_cursor.child_mask().iter() {
    v132_24_cursor.descend_to_existing_byte(v132_24_byte);
    {
    let v133_2: Space = singleton(&v132_24_cursor.path()[v132_24_origin..(v132_24_origin + 1)]);
    let v133_3: Space = intersect(&(*CONSTANT_2),&(v133_2));
    let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
    drop(v133_3);
    let v133_5: Space = subtract(&(*CONSTANT_1),&(v133_4));
    drop(v133_4);
    let v133_8: Space = if (&(v133_5)).is_empty() { Space::new() } else {
      let v134_6: Path = concat_path(&(*p0),&v132_24_cursor.path()[v132_24_origin..(v132_24_origin + 1)]);
      let mut v134_7 = Space::new();
      let mut v134_7_write = v134_7.write_zipper();
      for v134_7_byte in v132_24_cursor.child_mask().iter() {
        v132_24_cursor.descend_to_existing_byte(v134_7_byte);
        {
        let v135_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
        let v135_3: Space = intersect(&(*CONSTANT_2),&(v135_2));
        let v135_4: Space = if has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
        drop(v135_3);
        let v135_5: Space = subtract(&(*CONSTANT_1),&(v135_4));
        drop(v135_4);
        let v135_8: Space = if (&(v135_5)).is_empty() { Space::new() } else {
          let v136_6: Path = concat_path(&(v134_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v136_7 = Space::new();
          let mut v136_7_write = v136_7.write_zipper();
          for v136_7_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v136_7_byte);
            {
            let v137_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v137_3: Space = intersect(&(*CONSTANT_2),&(v137_2));
            let v137_4: Space = if has_head(&(v137_3)) { singleton(&[]) } else { Space::new() };
            drop(v137_3);
            let v137_5: Space = subtract(&(*CONSTANT_1),&(v137_4));
            drop(v137_4);
            let v137_8: Space = if (&(v137_5)).is_empty() { Space::new() } else {
              let v138_6: Path = concat_path(&(v136_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v138_7: Space = routine_20(c, &(v138_6), &v132_24_cursor, &(*s1));
              compose(&(v137_5),&(v138_7))
            };
            drop(v137_5);
            let v137_9: Space = intersect(&(*CONSTANT_2),&(v137_2));
            drop(v137_2);
            let v137_10: Space = if has_head(&(v137_9)) { singleton(&[]) } else { Space::new() };
            drop(v137_9);
            let v137_12: Space = if (&(v137_10)).is_empty() { Space::new() } else {
              let v139_6: Path = concat_path(&(v136_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v139_11: Space = routine_21(c, &(v139_6), &v132_24_cursor, &(*s1));
              drop(v139_6);
              compose(&(v137_10),&(v139_11))
            };
            drop(v137_10);
            let v137_13: Space = unite(&(v137_8),&(v137_12));
            join_wrapped_into(&mut v136_7_write,&((v137_13).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v136_7_write);
          compose(&(v135_5),&(v136_7))
        };
        drop(v135_5);
        let v135_9: Space = intersect(&(*CONSTANT_2),&(v135_2));
        drop(v135_2);
        let v135_10: Space = if has_head(&(v135_9)) { singleton(&[]) } else { Space::new() };
        drop(v135_9);
        let v135_12: Space = if (&(v135_10)).is_empty() { Space::new() } else {
          let v140_6: Path = concat_path(&(v134_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v140_11 = Space::new();
          let mut v140_11_write = v140_11.write_zipper();
          for v140_11_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v140_11_byte);
            {
            let v141_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v141_3: Space = intersect(&(*CONSTANT_2),&(v141_2));
            let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
            drop(v141_3);
            let v141_5: Space = subtract(&(*CONSTANT_1),&(v141_4));
            drop(v141_4);
            let v141_8: Space = if (&(v141_5)).is_empty() { Space::new() } else {
              let v142_6: Path = concat_path(&(v140_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v142_7: Space = routine_20(c, &(v142_6), &v132_24_cursor, &(*s1));
              compose(&(v141_5),&(v142_7))
            };
            drop(v141_5);
            let v141_9: Space = intersect(&(*CONSTANT_2),&(v141_2));
            drop(v141_2);
            let v141_10: Space = if has_head(&(v141_9)) { singleton(&[]) } else { Space::new() };
            drop(v141_9);
            let v141_12: Space = if (&(v141_10)).is_empty() { Space::new() } else {
              let v143_6: Path = concat_path(&(v140_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v143_11: Space = routine_3(c, &(v143_6), &v132_24_cursor, &(*s1));
              drop(v143_6);
              compose(&(v141_10),&(v143_11))
            };
            drop(v141_10);
            let v141_13: Space = unite(&(v141_8),&(v141_12));
            join_wrapped_into(&mut v140_11_write,&((v141_13).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v140_11_write);
          drop(v140_6);
          compose(&(v135_10),&(v140_11))
        };
        drop(v135_10);
        let v135_13: Space = unite(&(v135_8),&(v135_12));
        join_wrapped_into(&mut v134_7_write,&((v135_13).read_zipper()),&[]);
        }
        v132_24_cursor.ascend(1);
      }
      drop(v134_7_write);
      compose(&(v133_5),&(v134_7))
    };
    drop(v133_5);
    let v133_9: Space = intersect(&(*CONSTANT_2),&(v133_2));
    drop(v133_2);
    let v133_10: Space = if has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
    drop(v133_9);
    let v133_12: Space = if (&(v133_10)).is_empty() { Space::new() } else {
      let v144_6: Path = concat_path(&(*p0),&v132_24_cursor.path()[v132_24_origin..(v132_24_origin + 1)]);
      let mut v144_11 = Space::new();
      let mut v144_11_write = v144_11.write_zipper();
      for v144_11_byte in v132_24_cursor.child_mask().iter() {
        v132_24_cursor.descend_to_existing_byte(v144_11_byte);
        {
        let v145_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
        let v145_3: Space = intersect(&(*CONSTANT_2),&(v145_2));
        let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
        drop(v145_3);
        let v145_5: Space = subtract(&(*CONSTANT_1),&(v145_4));
        drop(v145_4);
        let v145_8: Space = if (&(v145_5)).is_empty() { Space::new() } else {
          let v146_6: Path = concat_path(&(v144_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v146_7 = Space::new();
          let mut v146_7_write = v146_7.write_zipper();
          for v146_7_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v146_7_byte);
            {
            let v147_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v147_3: Space = intersect(&(*CONSTANT_2),&(v147_2));
            let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
            drop(v147_3);
            let v147_5: Space = subtract(&(*CONSTANT_1),&(v147_4));
            drop(v147_4);
            let v147_8: Space = if (&(v147_5)).is_empty() { Space::new() } else {
              let v148_6: Path = concat_path(&(v146_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v148_7: Space = routine_20(c, &(v148_6), &v132_24_cursor, &(*s1));
              compose(&(v147_5),&(v148_7))
            };
            drop(v147_5);
            let v147_9: Space = intersect(&(*CONSTANT_2),&(v147_2));
            drop(v147_2);
            let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
            drop(v147_9);
            let v147_12: Space = if (&(v147_10)).is_empty() { Space::new() } else {
              let v149_6: Path = concat_path(&(v146_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v149_11: Space = routine_21(c, &(v149_6), &v132_24_cursor, &(*s1));
              drop(v149_6);
              compose(&(v147_10),&(v149_11))
            };
            drop(v147_10);
            let v147_13: Space = unite(&(v147_8),&(v147_12));
            join_wrapped_into(&mut v146_7_write,&((v147_13).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v146_7_write);
          compose(&(v145_5),&(v146_7))
        };
        drop(v145_5);
        let v145_9: Space = intersect(&(*CONSTANT_2),&(v145_2));
        drop(v145_2);
        let v145_10: Space = if has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
        drop(v145_9);
        let v145_12: Space = if (&(v145_10)).is_empty() { Space::new() } else {
          let v150_6: Path = concat_path(&(v144_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v150_11 = Space::new();
          let mut v150_11_write = v150_11.write_zipper();
          for v150_11_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v150_11_byte);
            {
            let v151_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v151_3: Space = intersect(&(*CONSTANT_2),&(v151_2));
            let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
            drop(v151_3);
            let v151_5: Space = subtract(&(*CONSTANT_1),&(v151_4));
            drop(v151_4);
            let v151_7: Space = if (&(v151_5)).is_empty() { Space::new() } else {
              let v152_6: Space = routine_4(c, &v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)], &(v150_6), &v132_24_cursor, &(*s1));
              compose(&(v151_5),&(v152_6))
            };
            drop(v151_5);
            let v151_8: Space = intersect(&(*CONSTANT_2),&(v151_2));
            drop(v151_2);
            let v151_9: Space = if has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
            drop(v151_8);
            let v151_11: Space = if (&(v151_9)).is_empty() { Space::new() } else {
              let v153_10: Space = routine_5(c, &v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)], &(v150_6), &v132_24_cursor, &(*s1));
              compose(&(v151_9),&(v153_10))
            };
            drop(v151_9);
            let v151_12: Space = unite(&(v151_7),&(v151_11));
            join_wrapped_into(&mut v150_11_write,&((v151_12).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v150_11_write);
          drop(v150_6);
          compose(&(v145_10),&(v150_11))
        };
        drop(v145_10);
        let v145_13: Space = unite(&(v145_8),&(v145_12));
        join_wrapped_into(&mut v144_11_write,&((v145_13).read_zipper()),&[]);
        }
        v132_24_cursor.ascend(1);
      }
      drop(v144_11_write);
      drop(v144_6);
      compose(&(v133_10),&(v144_11))
    };
    drop(v133_10);
    let v133_13: Space = unite(&(v133_8),&(v133_12));
    join_wrapped_into(&mut v132_24_write,&((v133_13).read_zipper()),&[]);
    }
    v132_24_cursor.ascend(1);
  }
  drop(v132_24_cursor);
  drop(v132_24_write);
  (v132_24).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v154_24 = Space::new();
  let mut v154_24_write = v154_24.write_zipper();
  let mut v154_24_cursor = (*s0).read_zipper();
  let v154_24_origin = v154_24_cursor.path().len();
  for v154_24_byte in v154_24_cursor.child_mask().iter() {
    v154_24_cursor.descend_to_existing_byte(v154_24_byte);
    {
    let v155_2: Space = singleton(&v154_24_cursor.path()[v154_24_origin..(v154_24_origin + 1)]);
    let v155_3: Space = intersect(&(*CONSTANT_2),&(v155_2));
    let v155_4: Space = if has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
    drop(v155_3);
    let v155_5: Space = subtract(&(*CONSTANT_1),&(v155_4));
    drop(v155_4);
    let v155_8: Space = if (&(v155_5)).is_empty() { Space::new() } else {
      let v156_6: Path = concat_path(&(*p0),&v154_24_cursor.path()[v154_24_origin..(v154_24_origin + 1)]);
      let mut v156_7 = Space::new();
      let mut v156_7_write = v156_7.write_zipper();
      for v156_7_byte in v154_24_cursor.child_mask().iter() {
        v154_24_cursor.descend_to_existing_byte(v156_7_byte);
        {
        let v157_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
        let v157_3: Space = intersect(&(*CONSTANT_2),&(v157_2));
        let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
        drop(v157_3);
        let v157_5: Space = subtract(&(*CONSTANT_1),&(v157_4));
        drop(v157_4);
        let v157_8: Space = if (&(v157_5)).is_empty() { Space::new() } else {
          let v158_6: Path = concat_path(&(v156_6),&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
          let mut v158_7 = Space::new();
          let mut v158_7_write = v158_7.write_zipper();
          for v158_7_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v158_7_byte);
            {
            let v159_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v159_3: Space = intersect(&(*CONSTANT_2),&(v159_2));
            let v159_4: Space = if has_head(&(v159_3)) { singleton(&[]) } else { Space::new() };
            drop(v159_3);
            let v159_5: Space = subtract(&(*CONSTANT_1),&(v159_4));
            drop(v159_4);
            let v159_8: Space = if (&(v159_5)).is_empty() { Space::new() } else {
              let v160_6: Path = concat_path(&(v158_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v160_7: Space = routine_20(c, &(v160_6), &v154_24_cursor, &(*s1));
              compose(&(v159_5),&(v160_7))
            };
            drop(v159_5);
            let v159_9: Space = intersect(&(*CONSTANT_2),&(v159_2));
            drop(v159_2);
            let v159_10: Space = if has_head(&(v159_9)) { singleton(&[]) } else { Space::new() };
            drop(v159_9);
            let v159_12: Space = if (&(v159_10)).is_empty() { Space::new() } else {
              let v161_6: Path = concat_path(&(v158_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v161_11: Space = routine_21(c, &(v161_6), &v154_24_cursor, &(*s1));
              drop(v161_6);
              compose(&(v159_10),&(v161_11))
            };
            drop(v159_10);
            let v159_13: Space = unite(&(v159_8),&(v159_12));
            join_wrapped_into(&mut v158_7_write,&((v159_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v158_7_write);
          compose(&(v157_5),&(v158_7))
        };
        drop(v157_5);
        let v157_9: Space = intersect(&(*CONSTANT_2),&(v157_2));
        drop(v157_2);
        let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
        drop(v157_9);
        let v157_12: Space = if (&(v157_10)).is_empty() { Space::new() } else {
          let v162_6: Path = concat_path(&(v156_6),&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
          let mut v162_11 = Space::new();
          let mut v162_11_write = v162_11.write_zipper();
          for v162_11_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v162_11_byte);
            {
            let v163_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v163_3: Space = intersect(&(*CONSTANT_2),&(v163_2));
            let v163_4: Space = if has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
            drop(v163_3);
            let v163_5: Space = subtract(&(*CONSTANT_1),&(v163_4));
            drop(v163_4);
            let v163_8: Space = if (&(v163_5)).is_empty() { Space::new() } else {
              let v164_6: Path = concat_path(&(v162_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v164_7: Space = routine_20(c, &(v164_6), &v154_24_cursor, &(*s1));
              compose(&(v163_5),&(v164_7))
            };
            drop(v163_5);
            let v163_9: Space = intersect(&(*CONSTANT_2),&(v163_2));
            drop(v163_2);
            let v163_10: Space = if has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
            drop(v163_9);
            let v163_12: Space = if (&(v163_10)).is_empty() { Space::new() } else {
              let v165_6: Path = concat_path(&(v162_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v165_11: Space = routine_3(c, &(v165_6), &v154_24_cursor, &(*s1));
              drop(v165_6);
              compose(&(v163_10),&(v165_11))
            };
            drop(v163_10);
            let v163_13: Space = unite(&(v163_8),&(v163_12));
            join_wrapped_into(&mut v162_11_write,&((v163_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v162_11_write);
          drop(v162_6);
          compose(&(v157_10),&(v162_11))
        };
        drop(v157_10);
        let v157_13: Space = unite(&(v157_8),&(v157_12));
        join_wrapped_into(&mut v156_7_write,&((v157_13).read_zipper()),&[]);
        }
        v154_24_cursor.ascend(1);
      }
      drop(v156_7_write);
      compose(&(v155_5),&(v156_7))
    };
    drop(v155_5);
    let v155_9: Space = intersect(&(*CONSTANT_2),&(v155_2));
    drop(v155_2);
    let v155_10: Space = if has_head(&(v155_9)) { singleton(&[]) } else { Space::new() };
    drop(v155_9);
    let v155_12: Space = if (&(v155_10)).is_empty() { Space::new() } else {
      let v166_6: Path = concat_path(&(*p0),&v154_24_cursor.path()[v154_24_origin..(v154_24_origin + 1)]);
      let mut v166_11 = Space::new();
      let mut v166_11_write = v166_11.write_zipper();
      for v166_11_byte in v154_24_cursor.child_mask().iter() {
        v154_24_cursor.descend_to_existing_byte(v166_11_byte);
        {
        let v167_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
        let v167_3: Space = intersect(&(*CONSTANT_2),&(v167_2));
        let v167_4: Space = if has_head(&(v167_3)) { singleton(&[]) } else { Space::new() };
        drop(v167_3);
        let v167_5: Space = subtract(&(*CONSTANT_1),&(v167_4));
        drop(v167_4);
        let v167_7: Space = if (&(v167_5)).is_empty() { Space::new() } else {
          let mut v168_6 = Space::new();
          let mut v168_6_write = v168_6.write_zipper();
          for v168_6_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v168_6_byte);
            {
            let v169_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v169_3: Space = intersect(&(*CONSTANT_2),&(v169_2));
            let v169_4: Space = if has_head(&(v169_3)) { singleton(&[]) } else { Space::new() };
            drop(v169_3);
            let v169_5: Space = subtract(&(*CONSTANT_1),&(v169_4));
            drop(v169_4);
            let v169_8: Space = if (&(v169_5)).is_empty() { Space::new() } else {
              let v170_7: Space = routine_8(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              compose(&(v169_5),&(v170_7))
            };
            drop(v169_5);
            let v169_9: Space = intersect(&(*CONSTANT_2),&(v169_2));
            drop(v169_2);
            let v169_10: Space = if has_head(&(v169_9)) { singleton(&[]) } else { Space::new() };
            drop(v169_9);
            let v169_12: Space = if (&(v169_10)).is_empty() { Space::new() } else {
              let v171_11: Space = routine_9(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              compose(&(v169_10),&(v171_11))
            };
            drop(v169_10);
            let v169_13: Space = unite(&(v169_8),&(v169_12));
            join_wrapped_into(&mut v168_6_write,&((v169_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v168_6_write);
          compose(&(v167_5),&(v168_6))
        };
        drop(v167_5);
        let v167_8: Space = intersect(&(*CONSTANT_2),&(v167_2));
        drop(v167_2);
        let v167_9: Space = if has_head(&(v167_8)) { singleton(&[]) } else { Space::new() };
        drop(v167_8);
        let v167_11: Space = if (&(v167_9)).is_empty() { Space::new() } else {
          let mut v172_10 = Space::new();
          let mut v172_10_write = v172_10.write_zipper();
          for v172_10_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v172_10_byte);
            {
            let v173_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v173_3: Space = intersect(&(*CONSTANT_2),&(v173_2));
            let v173_4: Space = if has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
            drop(v173_3);
            let v173_5: Space = subtract(&(*CONSTANT_1),&(v173_4));
            drop(v173_4);
            let v173_8: Space = if (&(v173_5)).is_empty() { Space::new() } else {
              let v174_7: Space = routine_8(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              compose(&(v173_5),&(v174_7))
            };
            drop(v173_5);
            let v173_9: Space = intersect(&(*CONSTANT_2),&(v173_2));
            drop(v173_2);
            let v173_10: Space = if has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
            drop(v173_9);
            let v173_12: Space = if (&(v173_10)).is_empty() { Space::new() } else {
              let v175_11: Space = routine_10(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              compose(&(v173_10),&(v175_11))
            };
            drop(v173_10);
            let v173_13: Space = unite(&(v173_8),&(v173_12));
            join_wrapped_into(&mut v172_10_write,&((v173_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v172_10_write);
          compose(&(v167_9),&(v172_10))
        };
        drop(v167_9);
        let v167_12: Space = unite(&(v167_7),&(v167_11));
        join_wrapped_into(&mut v166_11_write,&((v167_12).read_zipper()),&[]);
        }
        v154_24_cursor.ascend(1);
      }
      drop(v166_11_write);
      drop(v166_6);
      compose(&(v155_10),&(v166_11))
    };
    drop(v155_10);
    let v155_13: Space = unite(&(v155_8),&(v155_12));
    join_wrapped_into(&mut v154_24_write,&((v155_13).read_zipper()),&[]);
    }
    v154_24_cursor.ascend(1);
  }
  drop(v154_24_cursor);
  drop(v154_24_write);
  (v154_24).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v176_28 = Space::new();
  let mut v176_28_write = v176_28.write_zipper();
  let mut v176_28_cursor = (*s0).read_zipper();
  let v176_28_origin = v176_28_cursor.path().len();
  for v176_28_byte in v176_28_cursor.child_mask().iter() {
    v176_28_cursor.descend_to_existing_byte(v176_28_byte);
    {
    let v177_2: Space = singleton(&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]);
    let v177_3: Space = intersect(&(*CONSTANT_2),&(v177_2));
    let v177_4: Space = if has_head(&(v177_3)) { singleton(&[]) } else { Space::new() };
    drop(v177_3);
    let v177_5: Space = subtract(&(*CONSTANT_1),&(v177_4));
    drop(v177_4);
    let v177_8: Space = if (&(v177_5)).is_empty() { Space::new() } else {
      let v178_6: Path = concat_path(&(*p0),&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]);
      let mut v178_7 = Space::new();
      let mut v178_7_write = v178_7.write_zipper();
      for v178_7_byte in v176_28_cursor.child_mask().iter() {
        v176_28_cursor.descend_to_existing_byte(v178_7_byte);
        {
        let v179_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
        let v179_3: Space = intersect(&(*CONSTANT_2),&(v179_2));
        let v179_4: Space = if has_head(&(v179_3)) { singleton(&[]) } else { Space::new() };
        drop(v179_3);
        let v179_5: Space = subtract(&(*CONSTANT_1),&(v179_4));
        drop(v179_4);
        let v179_8: Space = if (&(v179_5)).is_empty() { Space::new() } else {
          let v180_6: Path = concat_path(&(v178_6),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let mut v180_7 = Space::new();
          let mut v180_7_write = v180_7.write_zipper();
          for v180_7_byte in v176_28_cursor.child_mask().iter() {
            v176_28_cursor.descend_to_existing_byte(v180_7_byte);
            {
            let v181_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
            let v181_3: Space = intersect(&(*CONSTANT_2),&(v181_2));
            let v181_4: Space = if has_head(&(v181_3)) { singleton(&[]) } else { Space::new() };
            drop(v181_3);
            let v181_5: Space = subtract(&(*CONSTANT_1),&(v181_4));
            drop(v181_4);
            let v181_8: Space = if (&(v181_5)).is_empty() { Space::new() } else {
              let v182_6: Path = concat_path(&(v180_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v182_7: Space = routine_22(c, &(v182_6), &(*p1), &v176_28_cursor, &(*s1));
              compose(&(v181_5),&(v182_7))
            };
            drop(v181_5);
            let v181_9: Space = intersect(&(*CONSTANT_2),&(v181_2));
            drop(v181_2);
            let v181_10: Space = if has_head(&(v181_9)) { singleton(&[]) } else { Space::new() };
            drop(v181_9);
            let v181_12: Space = if (&(v181_10)).is_empty() { Space::new() } else {
              let v183_6: Path = concat_path(&(v180_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v183_11: Space = routine_23(c, &(v183_6), &(*p1), &v176_28_cursor, &(*s1));
              drop(v183_6);
              compose(&(v181_10),&(v183_11))
            };
            drop(v181_10);
            let v181_13: Space = unite(&(v181_8),&(v181_12));
            join_wrapped_into(&mut v180_7_write,&((v181_13).read_zipper()),&[]);
            }
            v176_28_cursor.ascend(1);
          }
          drop(v180_7_write);
          compose(&(v179_5),&(v180_7))
        };
        drop(v179_5);
        let v179_9: Space = intersect(&(*CONSTANT_2),&(v179_2));
        drop(v179_2);
        let v179_10: Space = if has_head(&(v179_9)) { singleton(&[]) } else { Space::new() };
        drop(v179_9);
        let v179_12: Space = if (&(v179_10)).is_empty() { Space::new() } else {
          let v184_6: Path = concat_path(&(v178_6),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let mut v184_11 = Space::new();
          let mut v184_11_write = v184_11.write_zipper();
          for v184_11_byte in v176_28_cursor.child_mask().iter() {
            v176_28_cursor.descend_to_existing_byte(v184_11_byte);
            {
            let v185_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
            let v185_3: Space = intersect(&(*CONSTANT_2),&(v185_2));
            let v185_4: Space = if has_head(&(v185_3)) { singleton(&[]) } else { Space::new() };
            drop(v185_3);
            let v185_5: Space = subtract(&(*CONSTANT_1),&(v185_4));
            drop(v185_4);
            let v185_8: Space = if (&(v185_5)).is_empty() { Space::new() } else {
              let v186_6: Path = concat_path(&(v184_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v186_7: Space = routine_22(c, &(v186_6), &(*p1), &v176_28_cursor, &(*s1));
              compose(&(v185_5),&(v186_7))
            };
            drop(v185_5);
            let v185_9: Space = intersect(&(*CONSTANT_2),&(v185_2));
            drop(v185_2);
            let v185_10: Space = if has_head(&(v185_9)) { singleton(&[]) } else { Space::new() };
            drop(v185_9);
            let v185_12: Space = if (&(v185_10)).is_empty() { Space::new() } else {
              let v187_6: Path = concat_path(&(v184_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v187_11: Space = routine_10(c, &(v187_6), &(*p1), &v176_28_cursor, &(*s1));
              drop(v187_6);
              compose(&(v185_10),&(v187_11))
            };
            drop(v185_10);
            let v185_13: Space = unite(&(v185_8),&(v185_12));
            join_wrapped_into(&mut v184_11_write,&((v185_13).read_zipper()),&[]);
            }
            v176_28_cursor.ascend(1);
          }
          drop(v184_11_write);
          drop(v184_6);
          compose(&(v179_10),&(v184_11))
        };
        drop(v179_10);
        let v179_13: Space = unite(&(v179_8),&(v179_12));
        join_wrapped_into(&mut v178_7_write,&((v179_13).read_zipper()),&[]);
        }
        v176_28_cursor.ascend(1);
      }
      drop(v178_7_write);
      compose(&(v177_5),&(v178_7))
    };
    drop(v177_5);
    let v177_9: Space = intersect(&(*CONSTANT_2),&(v177_2));
    drop(v177_2);
    let v177_10: Space = if has_head(&(v177_9)) { singleton(&[]) } else { Space::new() };
    drop(v177_9);
    let v177_13: Space = if (&(v177_10)).is_empty() { Space::new() } else {
      let v188_6: Path = concat_path(&(*p0),&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]);
      let mut v188_12 = Space::new();
      let mut v188_12_write = v188_12.write_zipper();
      for v188_12_byte in v176_28_cursor.child_mask().iter() {
        v176_28_cursor.descend_to_existing_byte(v188_12_byte);
        {
        let v189_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
        let v189_3: Space = intersect(&(*CONSTANT_2),&(v189_2));
        let v189_4: Space = if has_head(&(v189_3)) { singleton(&[]) } else { Space::new() };
        drop(v189_3);
        let v189_5: Space = subtract(&(*CONSTANT_1),&(v189_4));
        drop(v189_4);
        let v189_8: Space = if (&(v189_5)).is_empty() { Space::new() } else {
          let v190_6: Path = concat_path(&(v188_6),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let mut v190_7 = Space::new();
          let mut v190_7_write = v190_7.write_zipper();
          for v190_7_byte in v176_28_cursor.child_mask().iter() {
            v176_28_cursor.descend_to_existing_byte(v190_7_byte);
            {
            let v191_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
            let v191_3: Space = intersect(&(*CONSTANT_2),&(v191_2));
            let v191_4: Space = if has_head(&(v191_3)) { singleton(&[]) } else { Space::new() };
            drop(v191_3);
            let v191_5: Space = subtract(&(*CONSTANT_1),&(v191_4));
            drop(v191_4);
            let v191_8: Space = if (&(v191_5)).is_empty() { Space::new() } else {
              let v192_6: Path = concat_path(&(v190_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v192_7: Space = routine_22(c, &(v192_6), &(*p1), &v176_28_cursor, &(*s1));
              compose(&(v191_5),&(v192_7))
            };
            drop(v191_5);
            let v191_9: Space = intersect(&(*CONSTANT_2),&(v191_2));
            drop(v191_2);
            let v191_10: Space = if has_head(&(v191_9)) { singleton(&[]) } else { Space::new() };
            drop(v191_9);
            let v191_12: Space = if (&(v191_10)).is_empty() { Space::new() } else {
              let v193_6: Path = concat_path(&(v190_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v193_11: Space = routine_23(c, &(v193_6), &(*p1), &v176_28_cursor, &(*s1));
              drop(v193_6);
              compose(&(v191_10),&(v193_11))
            };
            drop(v191_10);
            let v191_13: Space = unite(&(v191_8),&(v191_12));
            join_wrapped_into(&mut v190_7_write,&((v191_13).read_zipper()),&[]);
            }
            v176_28_cursor.ascend(1);
          }
          drop(v190_7_write);
          drop(v190_6);
          compose(&(v189_5),&(v190_7))
        };
        drop(v189_5);
        let v189_9: Space = intersect(&(*CONSTANT_2),&(v189_2));
        drop(v189_2);
        let v189_10: Space = if has_head(&(v189_9)) { singleton(&[]) } else { Space::new() };
        drop(v189_9);
        let v189_13: Space = if (&(v189_10)).is_empty() { Space::new() } else {
          let mut v194_12 = Space::new();
          let mut v194_12_write = v194_12.write_zipper();
          let mut v194_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let v194_12_origin = v194_12_cursor.path().len();
          for v194_12_byte in v194_12_cursor.child_mask().iter() {
            v194_12_cursor.descend_to_existing_byte(v194_12_byte);
            {
            let v195_2: Space = singleton(&v194_12_cursor.path()[v194_12_origin..(v194_12_origin + 1)]);
            let v195_3: Space = intersect(&(*CONSTANT_2),&(v195_2));
            let v195_4: Space = if has_head(&(v195_3)) { singleton(&[]) } else { Space::new() };
            drop(v195_3);
            let v195_5: Space = subtract(&(*CONSTANT_1),&(v195_4));
            drop(v195_4);
            let v195_7: Space = if (&(v195_5)).is_empty() { Space::new() } else {
              let v196_6: Space = routine_13(c, &v194_12_cursor.path()[v194_12_origin..(v194_12_origin + 1)], &(*p1), &v194_12_cursor);
              compose(&(v195_5),&(v196_6))
            };
            drop(v195_5);
            let v195_8: Space = intersect(&(*CONSTANT_2),&(v195_2));
            drop(v195_2);
            let v195_9: Space = if has_head(&(v195_8)) { singleton(&[]) } else { Space::new() };
            drop(v195_8);
            let v195_11: Space = if (&(v195_9)).is_empty() { Space::new() } else {
              let v197_10: Space = routine_14(c, &v194_12_cursor.path()[v194_12_origin..(v194_12_origin + 1)], &(*p1), &v194_12_cursor);
              compose(&(v195_9),&(v197_10))
            };
            drop(v195_9);
            let v195_12: Space = unite(&(v195_7),&(v195_11));
            join_wrapped_into(&mut v194_12_write,&((v195_12).read_zipper()),&[]);
            }
            v194_12_cursor.ascend(1);
          }
          drop(v194_12_cursor);
          drop(v194_12_write);
          compose(&(v189_10),&(v194_12))
        };
        drop(v189_10);
        let v189_14: Space = unite(&(v189_8),&(v189_13));
        join_wrapped_into(&mut v188_12_write,&((v189_14).read_zipper()),&[]);
        }
        v176_28_cursor.ascend(1);
      }
      drop(v188_12_write);
      drop(v188_6);
      compose(&(v177_10),&(v188_12))
    };
    drop(v177_10);
    let v177_14: Space = unite(&(v177_8),&(v177_13));
    join_wrapped_into(&mut v176_28_write,&((v177_14).read_zipper()),&[]);
    }
    v176_28_cursor.ascend(1);
  }
  drop(v176_28_cursor);
  drop(v176_28_write);
  (v176_28).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v198_28 = Space::new();
  let mut v198_28_write = v198_28.write_zipper();
  let mut v198_28_cursor = (*s0).read_zipper();
  let v198_28_origin = v198_28_cursor.path().len();
  for v198_28_byte in v198_28_cursor.child_mask().iter() {
    v198_28_cursor.descend_to_existing_byte(v198_28_byte);
    {
    let v199_2: Space = singleton(&v198_28_cursor.path()[v198_28_origin..(v198_28_origin + 1)]);
    let v199_3: Space = intersect(&(*CONSTANT_2),&(v199_2));
    let v199_4: Space = if has_head(&(v199_3)) { singleton(&[]) } else { Space::new() };
    drop(v199_3);
    let v199_5: Space = subtract(&(*CONSTANT_1),&(v199_4));
    drop(v199_4);
    let v199_8: Space = if (&(v199_5)).is_empty() { Space::new() } else {
      let v200_6: Path = concat_path(&(*p0),&v198_28_cursor.path()[v198_28_origin..(v198_28_origin + 1)]);
      let mut v200_7 = Space::new();
      let mut v200_7_write = v200_7.write_zipper();
      for v200_7_byte in v198_28_cursor.child_mask().iter() {
        v198_28_cursor.descend_to_existing_byte(v200_7_byte);
        {
        let v201_2: Space = singleton(&v198_28_cursor.path()[(v198_28_origin + 1)..(v198_28_origin + 2)]);
        let v201_3: Space = intersect(&(*CONSTANT_2),&(v201_2));
        let v201_4: Space = if has_head(&(v201_3)) { singleton(&[]) } else { Space::new() };
        drop(v201_3);
        let v201_5: Space = subtract(&(*CONSTANT_1),&(v201_4));
        drop(v201_4);
        let v201_8: Space = if (&(v201_5)).is_empty() { Space::new() } else {
          let v202_6: Path = concat_path(&(v200_6),&v198_28_cursor.path()[(v198_28_origin + 1)..(v198_28_origin + 2)]);
          let mut v202_7 = Space::new();
          let mut v202_7_write = v202_7.write_zipper();
          for v202_7_byte in v198_28_cursor.child_mask().iter() {
            v198_28_cursor.descend_to_existing_byte(v202_7_byte);
            {
            let v203_2: Space = singleton(&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
            let v203_3: Space = intersect(&(*CONSTANT_2),&(v203_2));
            let v203_4: Space = if has_head(&(v203_3)) { singleton(&[]) } else { Space::new() };
            drop(v203_3);
            let v203_5: Space = subtract(&(*CONSTANT_1),&(v203_4));
            drop(v203_4);
            let v203_8: Space = if (&(v203_5)).is_empty() { Space::new() } else {
              let v204_6: Path = concat_path(&(v202_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v204_7: Space = routine_22(c, &(v204_6), &(*p1), &v198_28_cursor, &(*s1));
              compose(&(v203_5),&(v204_7))
            };
            drop(v203_5);
            let v203_9: Space = intersect(&(*CONSTANT_2),&(v203_2));
            drop(v203_2);
            let v203_10: Space = if has_head(&(v203_9)) { singleton(&[]) } else { Space::new() };
            drop(v203_9);
            let v203_12: Space = if (&(v203_10)).is_empty() { Space::new() } else {
              let v205_6: Path = concat_path(&(v202_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v205_11: Space = routine_23(c, &(v205_6), &(*p1), &v198_28_cursor, &(*s1));
              drop(v205_6);
              compose(&(v203_10),&(v205_11))
            };
            drop(v203_10);
            let v203_13: Space = unite(&(v203_8),&(v203_12));
            join_wrapped_into(&mut v202_7_write,&((v203_13).read_zipper()),&[]);
            }
            v198_28_cursor.ascend(1);
          }
          drop(v202_7_write);
          compose(&(v201_5),&(v202_7))
        };
        drop(v201_5);
        let v201_9: Space = intersect(&(*CONSTANT_2),&(v201_2));
        drop(v201_2);
        let v201_10: Space = if has_head(&(v201_9)) { singleton(&[]) } else { Space::new() };
        drop(v201_9);
        let v201_12: Space = if (&(v201_10)).is_empty() { Space::new() } else {
          let v206_6: Path = concat_path(&(v200_6),&v198_28_cursor.path()[(v198_28_origin + 1)..(v198_28_origin + 2)]);
          let mut v206_11 = Space::new();
          let mut v206_11_write = v206_11.write_zipper();
          for v206_11_byte in v198_28_cursor.child_mask().iter() {
            v198_28_cursor.descend_to_existing_byte(v206_11_byte);
            {
            let v207_2: Space = singleton(&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
            let v207_3: Space = intersect(&(*CONSTANT_2),&(v207_2));
            let v207_4: Space = if has_head(&(v207_3)) { singleton(&[]) } else { Space::new() };
            drop(v207_3);
            let v207_5: Space = subtract(&(*CONSTANT_1),&(v207_4));
            drop(v207_4);
            let v207_8: Space = if (&(v207_5)).is_empty() { Space::new() } else {
              let v208_6: Path = concat_path(&(v206_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v208_7: Space = routine_22(c, &(v208_6), &(*p1), &v198_28_cursor, &(*s1));
              compose(&(v207_5),&(v208_7))
            };
            drop(v207_5);
            let v207_9: Space = intersect(&(*CONSTANT_2),&(v207_2));
            drop(v207_2);
            let v207_10: Space = if has_head(&(v207_9)) { singleton(&[]) } else { Space::new() };
            drop(v207_9);
            let v207_12: Space = if (&(v207_10)).is_empty() { Space::new() } else {
              let v209_6: Path = concat_path(&(v206_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v209_11: Space = routine_10(c, &(v209_6), &(*p1), &v198_28_cursor, &(*s1));
              drop(v209_6);
              compose(&(v207_10),&(v209_11))
            };
            drop(v207_10);
            let v207_13: Space = unite(&(v207_8),&(v207_12));
            join_wrapped_into(&mut v206_11_write,&((v207_13).read_zipper()),&[]);
            }
            v198_28_cursor.ascend(1);
          }
          drop(v206_11_write);
          drop(v206_6);
          compose(&(v201_10),&(v206_11))
        };
        drop(v201_10);
        let v201_13: Space = unite(&(v201_8),&(v201_12));
        join_wrapped_into(&mut v200_7_write,&((v201_13).read_zipper()),&[]);
        }
        v198_28_cursor.ascend(1);
      }
      drop(v200_7_write);
      drop(v200_6);
      compose(&(v199_5),&(v200_7))
    };
    drop(v199_5);
    let v199_9: Space = intersect(&(*CONSTANT_2),&(v199_2));
    drop(v199_2);
    let v199_10: Space = if has_head(&(v199_9)) { singleton(&[]) } else { Space::new() };
    drop(v199_9);
    let v199_13: Space = if (&(v199_10)).is_empty() { Space::new() } else {
      let mut v210_12 = Space::new();
      let mut v210_12_write = v210_12.write_zipper();
      let mut v210_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v198_28_cursor.path()[v198_28_origin..(v198_28_origin + 1)]);
      let v210_12_origin = v210_12_cursor.path().len();
      for v210_12_byte in v210_12_cursor.child_mask().iter() {
        v210_12_cursor.descend_to_existing_byte(v210_12_byte);
        {
        let v211_2: Space = singleton(&v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 1)]);
        let v211_3: Space = intersect(&(*CONSTANT_2),&(v211_2));
        let v211_4: Space = if has_head(&(v211_3)) { singleton(&[]) } else { Space::new() };
        drop(v211_3);
        let v211_5: Space = subtract(&(*CONSTANT_1),&(v211_4));
        drop(v211_4);
        let v211_7: Space = if (&(v211_5)).is_empty() { Space::new() } else {
          let mut v212_6 = Space::new();
          let mut v212_6_write = v212_6.write_zipper();
          for v212_6_byte in v210_12_cursor.child_mask().iter() {
            v210_12_cursor.descend_to_existing_byte(v212_6_byte);
            {
            let v213_2: Space = singleton(&v210_12_cursor.path()[(v210_12_origin + 1)..(v210_12_origin + 2)]);
            let v213_3: Space = intersect(&(*CONSTANT_2),&(v213_2));
            let v213_4: Space = if has_head(&(v213_3)) { singleton(&[]) } else { Space::new() };
            drop(v213_3);
            let v213_5: Space = subtract(&(*CONSTANT_1),&(v213_4));
            drop(v213_4);
            let v213_8: Space = if (&(v213_5)).is_empty() { Space::new() } else {
              let v214_7: Space = routine_17(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              compose(&(v213_5),&(v214_7))
            };
            drop(v213_5);
            let v213_9: Space = intersect(&(*CONSTANT_2),&(v213_2));
            drop(v213_2);
            let v213_10: Space = if has_head(&(v213_9)) { singleton(&[]) } else { Space::new() };
            drop(v213_9);
            let v213_12: Space = if (&(v213_10)).is_empty() { Space::new() } else {
              let v215_11: Space = routine_18(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              compose(&(v213_10),&(v215_11))
            };
            drop(v213_10);
            let v213_13: Space = unite(&(v213_8),&(v213_12));
            join_wrapped_into(&mut v212_6_write,&((v213_13).read_zipper()),&[]);
            }
            v210_12_cursor.ascend(1);
          }
          drop(v212_6_write);
          compose(&(v211_5),&(v212_6))
        };
        drop(v211_5);
        let v211_8: Space = intersect(&(*CONSTANT_2),&(v211_2));
        drop(v211_2);
        let v211_9: Space = if has_head(&(v211_8)) { singleton(&[]) } else { Space::new() };
        drop(v211_8);
        let v211_11: Space = if (&(v211_9)).is_empty() { Space::new() } else {
          let mut v216_10 = Space::new();
          let mut v216_10_write = v216_10.write_zipper();
          for v216_10_byte in v210_12_cursor.child_mask().iter() {
            v210_12_cursor.descend_to_existing_byte(v216_10_byte);
            {
            let v217_2: Space = singleton(&v210_12_cursor.path()[(v210_12_origin + 1)..(v210_12_origin + 2)]);
            let v217_3: Space = intersect(&(*CONSTANT_2),&(v217_2));
            let v217_4: Space = if has_head(&(v217_3)) { singleton(&[]) } else { Space::new() };
            drop(v217_3);
            let v217_5: Space = subtract(&(*CONSTANT_1),&(v217_4));
            drop(v217_4);
            let v217_8: Space = if (&(v217_5)).is_empty() { Space::new() } else {
              let v218_7: Space = routine_17(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              compose(&(v217_5),&(v218_7))
            };
            drop(v217_5);
            let v217_9: Space = intersect(&(*CONSTANT_2),&(v217_2));
            drop(v217_2);
            let v217_10: Space = if has_head(&(v217_9)) { singleton(&[]) } else { Space::new() };
            drop(v217_9);
            let v217_12: Space = if (&(v217_10)).is_empty() { Space::new() } else {
              let v219_11: Space = routine_19(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              compose(&(v217_10),&(v219_11))
            };
            drop(v217_10);
            let v217_13: Space = unite(&(v217_8),&(v217_12));
            join_wrapped_into(&mut v216_10_write,&((v217_13).read_zipper()),&[]);
            }
            v210_12_cursor.ascend(1);
          }
          drop(v216_10_write);
          compose(&(v211_9),&(v216_10))
        };
        drop(v211_9);
        let v211_12: Space = unite(&(v211_7),&(v211_11));
        join_wrapped_into(&mut v210_12_write,&((v211_12).read_zipper()),&[]);
        }
        v210_12_cursor.ascend(1);
      }
      drop(v210_12_cursor);
      drop(v210_12_write);
      compose(&(v199_10),&(v210_12))
    };
    drop(v199_10);
    let v199_14: Space = unite(&(v199_8),&(v199_13));
    join_wrapped_into(&mut v198_28_write,&((v199_14).read_zipper()),&[]);
    }
    v198_28_cursor.ascend(1);
  }
  drop(v198_28_cursor);
  drop(v198_28_write);
  (v198_28).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v220_25 = Space::new();
  let mut v220_25_write = v220_25.write_zipper();
  let mut v220_25_cursor = descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0));
  let v220_25_origin = v220_25_cursor.path().len();
  for v220_25_byte in v220_25_cursor.child_mask().iter() {
    v220_25_cursor.descend_to_existing_byte(v220_25_byte);
    {
    let v221_2: Space = singleton(&v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 1)]);
    let v221_3: Space = intersect(&(*CONSTANT_2),&(v221_2));
    let v221_4: Space = if has_head(&(v221_3)) { singleton(&[]) } else { Space::new() };
    drop(v221_3);
    let v221_5: Space = subtract(&(*CONSTANT_1),&(v221_4));
    drop(v221_4);
    let v221_7: Space = if (&(v221_5)).is_empty() { Space::new() } else {
      let mut v222_6 = Space::new();
      let mut v222_6_write = v222_6.write_zipper();
      for v222_6_byte in v220_25_cursor.child_mask().iter() {
        v220_25_cursor.descend_to_existing_byte(v222_6_byte);
        {
        let v223_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 1)..(v220_25_origin + 2)]);
        let v223_3: Space = intersect(&(*CONSTANT_2),&(v223_2));
        let v223_4: Space = if has_head(&(v223_3)) { singleton(&[]) } else { Space::new() };
        drop(v223_3);
        let v223_5: Space = subtract(&(*CONSTANT_1),&(v223_4));
        drop(v223_4);
        let v223_8: Space = if (&(v223_5)).is_empty() { Space::new() } else {
          let mut v224_7 = Space::new();
          let mut v224_7_write = v224_7.write_zipper();
          for v224_7_byte in v220_25_cursor.child_mask().iter() {
            v220_25_cursor.descend_to_existing_byte(v224_7_byte);
            {
            let v225_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 2)..(v220_25_origin + 3)]);
            let v225_3: Space = intersect(&(*CONSTANT_2),&(v225_2));
            let v225_4: Space = if has_head(&(v225_3)) { singleton(&[]) } else { Space::new() };
            drop(v225_3);
            let v225_5: Space = subtract(&(*CONSTANT_1),&(v225_4));
            drop(v225_4);
            let v225_8: Space = if (&(v225_5)).is_empty() { Space::new() } else {
              let v226_7: Space = routine_24(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              compose(&(v225_5),&(v226_7))
            };
            drop(v225_5);
            let v225_9: Space = intersect(&(*CONSTANT_2),&(v225_2));
            drop(v225_2);
            let v225_10: Space = if has_head(&(v225_9)) { singleton(&[]) } else { Space::new() };
            drop(v225_9);
            let v225_12: Space = if (&(v225_10)).is_empty() { Space::new() } else {
              let v227_11: Space = routine_25(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              compose(&(v225_10),&(v227_11))
            };
            drop(v225_10);
            let v225_13: Space = unite(&(v225_8),&(v225_12));
            join_wrapped_into(&mut v224_7_write,&((v225_13).read_zipper()),&[]);
            }
            v220_25_cursor.ascend(1);
          }
          drop(v224_7_write);
          compose(&(v223_5),&(v224_7))
        };
        drop(v223_5);
        let v223_9: Space = intersect(&(*CONSTANT_2),&(v223_2));
        drop(v223_2);
        let v223_10: Space = if has_head(&(v223_9)) { singleton(&[]) } else { Space::new() };
        drop(v223_9);
        let v223_12: Space = if (&(v223_10)).is_empty() { Space::new() } else {
          let mut v228_11 = Space::new();
          let mut v228_11_write = v228_11.write_zipper();
          for v228_11_byte in v220_25_cursor.child_mask().iter() {
            v220_25_cursor.descend_to_existing_byte(v228_11_byte);
            {
            let v229_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 2)..(v220_25_origin + 3)]);
            let v229_3: Space = intersect(&(*CONSTANT_2),&(v229_2));
            let v229_4: Space = if has_head(&(v229_3)) { singleton(&[]) } else { Space::new() };
            drop(v229_3);
            let v229_5: Space = subtract(&(*CONSTANT_1),&(v229_4));
            drop(v229_4);
            let v229_8: Space = if (&(v229_5)).is_empty() { Space::new() } else {
              let v230_7: Space = routine_24(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              compose(&(v229_5),&(v230_7))
            };
            drop(v229_5);
            let v229_9: Space = intersect(&(*CONSTANT_2),&(v229_2));
            drop(v229_2);
            let v229_10: Space = if has_head(&(v229_9)) { singleton(&[]) } else { Space::new() };
            drop(v229_9);
            let v229_12: Space = if (&(v229_10)).is_empty() { Space::new() } else {
              let v231_11: Space = routine_19(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              compose(&(v229_10),&(v231_11))
            };
            drop(v229_10);
            let v229_13: Space = unite(&(v229_8),&(v229_12));
            join_wrapped_into(&mut v228_11_write,&((v229_13).read_zipper()),&[]);
            }
            v220_25_cursor.ascend(1);
          }
          drop(v228_11_write);
          compose(&(v223_10),&(v228_11))
        };
        drop(v223_10);
        let v223_13: Space = unite(&(v223_8),&(v223_12));
        join_wrapped_into(&mut v222_6_write,&((v223_13).read_zipper()),&[]);
        }
        v220_25_cursor.ascend(1);
      }
      drop(v222_6_write);
      compose(&(v221_5),&(v222_6))
    };
    drop(v221_5);
    let v221_8: Space = intersect(&(*CONSTANT_2),&(v221_2));
    drop(v221_2);
    let v221_9: Space = if has_head(&(v221_8)) { singleton(&[]) } else { Space::new() };
    drop(v221_8);
    let v221_11: Space = if (&(v221_9)).is_empty() { Space::new() } else {
      let mut v232_10 = Space::new();
      let mut v232_10_write = v232_10.write_zipper();
      for v232_10_byte in v220_25_cursor.child_mask().iter() {
        v220_25_cursor.descend_to_existing_byte(v232_10_byte);
        {
        let v233_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 1)..(v220_25_origin + 2)]);
        let v233_3: Space = intersect(&(*CONSTANT_2),&(v233_2));
        let v233_4: Space = if has_head(&(v233_3)) { singleton(&[]) } else { Space::new() };
        drop(v233_3);
        let v233_5: Space = subtract(&(*CONSTANT_1),&(v233_4));
        drop(v233_4);
        let v233_8: Space = if (&(v233_5)).is_empty() { Space::new() } else {
          let mut v234_7 = Space::new();
          let mut v234_7_write = v234_7.write_zipper();
          for v234_7_byte in v220_25_cursor.child_mask().iter() {
            v220_25_cursor.descend_to_existing_byte(v234_7_byte);
            {
            let v235_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 2)..(v220_25_origin + 3)]);
            let v235_3: Space = intersect(&(*CONSTANT_2),&(v235_2));
            let v235_4: Space = if has_head(&(v235_3)) { singleton(&[]) } else { Space::new() };
            drop(v235_3);
            let v235_5: Space = subtract(&(*CONSTANT_1),&(v235_4));
            drop(v235_4);
            let v235_8: Space = if (&(v235_5)).is_empty() { Space::new() } else {
              let v236_7: Space = routine_24(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              compose(&(v235_5),&(v236_7))
            };
            drop(v235_5);
            let v235_9: Space = intersect(&(*CONSTANT_2),&(v235_2));
            drop(v235_2);
            let v235_10: Space = if has_head(&(v235_9)) { singleton(&[]) } else { Space::new() };
            drop(v235_9);
            let v235_12: Space = if (&(v235_10)).is_empty() { Space::new() } else {
              let v237_11: Space = routine_25(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              compose(&(v235_10),&(v237_11))
            };
            drop(v235_10);
            let v235_13: Space = unite(&(v235_8),&(v235_12));
            join_wrapped_into(&mut v234_7_write,&((v235_13).read_zipper()),&[]);
            }
            v220_25_cursor.ascend(1);
          }
          drop(v234_7_write);
          compose(&(v233_5),&(v234_7))
        };
        drop(v233_5);
        let v233_9: Space = intersect(&(*CONSTANT_2),&(v233_2));
        drop(v233_2);
        let v233_10: Space = if has_head(&(v233_9)) { singleton(&[]) } else { Space::new() };
        drop(v233_9);
        let v233_11: Space = compose(&(v233_10),&v220_25_cursor);
        drop(v233_10);
        let v233_12: Space = wrap(&(v233_11),&v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 2)]);
        drop(v233_11);
        let v233_13: Space = wrap(&(v233_12),&(*p1));
        drop(v233_12);
        let v233_14: Space = unite(&(v233_8),&(v233_13));
        drop(v233_13);
        join_wrapped_into(&mut v232_10_write,&((v233_14).read_zipper()),&[]);
        }
        v220_25_cursor.ascend(1);
      }
      drop(v232_10_write);
      compose(&(v221_9),&(v232_10))
    };
    drop(v221_9);
    let v221_12: Space = unite(&(v221_7),&(v221_11));
    join_wrapped_into(&mut v220_25_write,&((v221_12).read_zipper()),&[]);
    }
    v220_25_cursor.ascend(1);
  }
  drop(v220_25_cursor);
  drop(v220_25_write);
  (v220_25).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v239_28 = Space::new();
  let mut v239_28_write = v239_28.write_zipper();
  let mut v239_28_cursor = (*s0).read_zipper();
  let v239_28_origin = v239_28_cursor.path().len();
  for v239_28_byte in v239_28_cursor.child_mask().iter() {
    v239_28_cursor.descend_to_existing_byte(v239_28_byte);
    {
    let v240_2: Space = singleton(&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]);
    let v240_3: Space = intersect(&(*CONSTANT_2),&(v240_2));
    let v240_4: Space = if has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
    drop(v240_3);
    let v240_5: Space = subtract(&(*CONSTANT_1),&(v240_4));
    drop(v240_4);
    let v240_8: Space = if (&(v240_5)).is_empty() { Space::new() } else {
      let v241_6: Path = concat_path(&(*p0),&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]);
      let mut v241_7 = Space::new();
      let mut v241_7_write = v241_7.write_zipper();
      for v241_7_byte in v239_28_cursor.child_mask().iter() {
        v239_28_cursor.descend_to_existing_byte(v241_7_byte);
        {
        let v242_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
        let v242_3: Space = intersect(&(*CONSTANT_2),&(v242_2));
        let v242_4: Space = if has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
        drop(v242_3);
        let v242_5: Space = subtract(&(*CONSTANT_1),&(v242_4));
        drop(v242_4);
        let v242_8: Space = if (&(v242_5)).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v241_6),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let mut v243_7 = Space::new();
          let mut v243_7_write = v243_7.write_zipper();
          for v243_7_byte in v239_28_cursor.child_mask().iter() {
            v239_28_cursor.descend_to_existing_byte(v243_7_byte);
            {
            let v244_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
            let v244_3: Space = intersect(&(*CONSTANT_2),&(v244_2));
            let v244_4: Space = if has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
            drop(v244_3);
            let v244_5: Space = subtract(&(*CONSTANT_1),&(v244_4));
            drop(v244_4);
            let v244_8: Space = if (&(v244_5)).is_empty() { Space::new() } else {
              let v245_6: Path = concat_path(&(v243_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v245_7: Space = routine_26(c, &(v245_6), &(*p1), &v239_28_cursor, &(*s1));
              compose(&(v244_5),&(v245_7))
            };
            drop(v244_5);
            let v244_9: Space = intersect(&(*CONSTANT_2),&(v244_2));
            drop(v244_2);
            let v244_10: Space = if has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
            drop(v244_9);
            let v244_12: Space = if (&(v244_10)).is_empty() { Space::new() } else {
              let v246_6: Path = concat_path(&(v243_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v246_11: Space = routine_27(c, &(v246_6), &(*p1), &v239_28_cursor, &(*s1));
              drop(v246_6);
              compose(&(v244_10),&(v246_11))
            };
            drop(v244_10);
            let v244_13: Space = unite(&(v244_8),&(v244_12));
            join_wrapped_into(&mut v243_7_write,&((v244_13).read_zipper()),&[]);
            }
            v239_28_cursor.ascend(1);
          }
          drop(v243_7_write);
          compose(&(v242_5),&(v243_7))
        };
        drop(v242_5);
        let v242_9: Space = intersect(&(*CONSTANT_2),&(v242_2));
        drop(v242_2);
        let v242_10: Space = if has_head(&(v242_9)) { singleton(&[]) } else { Space::new() };
        drop(v242_9);
        let v242_12: Space = if (&(v242_10)).is_empty() { Space::new() } else {
          let v247_6: Path = concat_path(&(v241_6),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let mut v247_11 = Space::new();
          let mut v247_11_write = v247_11.write_zipper();
          for v247_11_byte in v239_28_cursor.child_mask().iter() {
            v239_28_cursor.descend_to_existing_byte(v247_11_byte);
            {
            let v248_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
            let v248_3: Space = intersect(&(*CONSTANT_2),&(v248_2));
            let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
            drop(v248_3);
            let v248_5: Space = subtract(&(*CONSTANT_1),&(v248_4));
            drop(v248_4);
            let v248_8: Space = if (&(v248_5)).is_empty() { Space::new() } else {
              let v249_6: Path = concat_path(&(v247_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v249_7: Space = routine_26(c, &(v249_6), &(*p1), &v239_28_cursor, &(*s1));
              compose(&(v248_5),&(v249_7))
            };
            drop(v248_5);
            let v248_9: Space = intersect(&(*CONSTANT_2),&(v248_2));
            drop(v248_2);
            let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
            drop(v248_9);
            let v248_12: Space = if (&(v248_10)).is_empty() { Space::new() } else {
              let v250_6: Path = concat_path(&(v247_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v250_11: Space = routine_10(c, &(v250_6), &(*p1), &v239_28_cursor, &(*s1));
              drop(v250_6);
              compose(&(v248_10),&(v250_11))
            };
            drop(v248_10);
            let v248_13: Space = unite(&(v248_8),&(v248_12));
            join_wrapped_into(&mut v247_11_write,&((v248_13).read_zipper()),&[]);
            }
            v239_28_cursor.ascend(1);
          }
          drop(v247_11_write);
          drop(v247_6);
          compose(&(v242_10),&(v247_11))
        };
        drop(v242_10);
        let v242_13: Space = unite(&(v242_8),&(v242_12));
        join_wrapped_into(&mut v241_7_write,&((v242_13).read_zipper()),&[]);
        }
        v239_28_cursor.ascend(1);
      }
      drop(v241_7_write);
      compose(&(v240_5),&(v241_7))
    };
    drop(v240_5);
    let v240_9: Space = intersect(&(*CONSTANT_2),&(v240_2));
    drop(v240_2);
    let v240_10: Space = if has_head(&(v240_9)) { singleton(&[]) } else { Space::new() };
    drop(v240_9);
    let v240_13: Space = if (&(v240_10)).is_empty() { Space::new() } else {
      let v251_6: Path = concat_path(&(*p0),&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]);
      let mut v251_12 = Space::new();
      let mut v251_12_write = v251_12.write_zipper();
      for v251_12_byte in v239_28_cursor.child_mask().iter() {
        v239_28_cursor.descend_to_existing_byte(v251_12_byte);
        {
        let v252_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
        let v252_3: Space = intersect(&(*CONSTANT_2),&(v252_2));
        let v252_4: Space = if has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
        drop(v252_3);
        let v252_5: Space = subtract(&(*CONSTANT_1),&(v252_4));
        drop(v252_4);
        let v252_8: Space = if (&(v252_5)).is_empty() { Space::new() } else {
          let v253_6: Path = concat_path(&(v251_6),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let mut v253_7 = Space::new();
          let mut v253_7_write = v253_7.write_zipper();
          for v253_7_byte in v239_28_cursor.child_mask().iter() {
            v239_28_cursor.descend_to_existing_byte(v253_7_byte);
            {
            let v254_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
            let v254_3: Space = intersect(&(*CONSTANT_2),&(v254_2));
            let v254_4: Space = if has_head(&(v254_3)) { singleton(&[]) } else { Space::new() };
            drop(v254_3);
            let v254_5: Space = subtract(&(*CONSTANT_1),&(v254_4));
            drop(v254_4);
            let v254_8: Space = if (&(v254_5)).is_empty() { Space::new() } else {
              let v255_6: Path = concat_path(&(v253_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v255_7: Space = routine_26(c, &(v255_6), &(*p1), &v239_28_cursor, &(*s1));
              compose(&(v254_5),&(v255_7))
            };
            drop(v254_5);
            let v254_9: Space = intersect(&(*CONSTANT_2),&(v254_2));
            drop(v254_2);
            let v254_10: Space = if has_head(&(v254_9)) { singleton(&[]) } else { Space::new() };
            drop(v254_9);
            let v254_12: Space = if (&(v254_10)).is_empty() { Space::new() } else {
              let v256_6: Path = concat_path(&(v253_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v256_11: Space = routine_27(c, &(v256_6), &(*p1), &v239_28_cursor, &(*s1));
              drop(v256_6);
              compose(&(v254_10),&(v256_11))
            };
            drop(v254_10);
            let v254_13: Space = unite(&(v254_8),&(v254_12));
            join_wrapped_into(&mut v253_7_write,&((v254_13).read_zipper()),&[]);
            }
            v239_28_cursor.ascend(1);
          }
          drop(v253_7_write);
          drop(v253_6);
          compose(&(v252_5),&(v253_7))
        };
        drop(v252_5);
        let v252_9: Space = intersect(&(*CONSTANT_2),&(v252_2));
        drop(v252_2);
        let v252_10: Space = if has_head(&(v252_9)) { singleton(&[]) } else { Space::new() };
        drop(v252_9);
        let v252_13: Space = if (&(v252_10)).is_empty() { Space::new() } else {
          let mut v257_12 = Space::new();
          let mut v257_12_write = v257_12.write_zipper();
          let mut v257_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let v257_12_origin = v257_12_cursor.path().len();
          for v257_12_byte in v257_12_cursor.child_mask().iter() {
            v257_12_cursor.descend_to_existing_byte(v257_12_byte);
            {
            let v258_2: Space = singleton(&v257_12_cursor.path()[v257_12_origin..(v257_12_origin + 1)]);
            let v258_3: Space = intersect(&(*CONSTANT_2),&(v258_2));
            let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
            drop(v258_3);
            let v258_5: Space = subtract(&(*CONSTANT_1),&(v258_4));
            drop(v258_4);
            let v258_7: Space = if (&(v258_5)).is_empty() { Space::new() } else {
              let v259_6: Space = routine_13(c, &v257_12_cursor.path()[v257_12_origin..(v257_12_origin + 1)], &(*p1), &v257_12_cursor);
              compose(&(v258_5),&(v259_6))
            };
            drop(v258_5);
            let v258_8: Space = intersect(&(*CONSTANT_2),&(v258_2));
            drop(v258_2);
            let v258_9: Space = if has_head(&(v258_8)) { singleton(&[]) } else { Space::new() };
            drop(v258_8);
            let v258_11: Space = if (&(v258_9)).is_empty() { Space::new() } else {
              let v260_10: Space = routine_14(c, &v257_12_cursor.path()[v257_12_origin..(v257_12_origin + 1)], &(*p1), &v257_12_cursor);
              compose(&(v258_9),&(v260_10))
            };
            drop(v258_9);
            let v258_12: Space = unite(&(v258_7),&(v258_11));
            join_wrapped_into(&mut v257_12_write,&((v258_12).read_zipper()),&[]);
            }
            v257_12_cursor.ascend(1);
          }
          drop(v257_12_cursor);
          drop(v257_12_write);
          compose(&(v252_10),&(v257_12))
        };
        drop(v252_10);
        let v252_14: Space = unite(&(v252_8),&(v252_13));
        join_wrapped_into(&mut v251_12_write,&((v252_14).read_zipper()),&[]);
        }
        v239_28_cursor.ascend(1);
      }
      drop(v251_12_write);
      drop(v251_6);
      compose(&(v240_10),&(v251_12))
    };
    drop(v240_10);
    let v240_14: Space = unite(&(v240_8),&(v240_13));
    join_wrapped_into(&mut v239_28_write,&((v240_14).read_zipper()),&[]);
    }
    v239_28_cursor.ascend(1);
  }
  drop(v239_28_cursor);
  drop(v239_28_write);
  (v239_28).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v261_28 = Space::new();
  let mut v261_28_write = v261_28.write_zipper();
  let mut v261_28_cursor = (*s0).read_zipper();
  let v261_28_origin = v261_28_cursor.path().len();
  for v261_28_byte in v261_28_cursor.child_mask().iter() {
    v261_28_cursor.descend_to_existing_byte(v261_28_byte);
    {
    let v262_2: Space = singleton(&v261_28_cursor.path()[v261_28_origin..(v261_28_origin + 1)]);
    let v262_3: Space = intersect(&(*CONSTANT_2),&(v262_2));
    let v262_4: Space = if has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
    drop(v262_3);
    let v262_5: Space = subtract(&(*CONSTANT_1),&(v262_4));
    drop(v262_4);
    let v262_8: Space = if (&(v262_5)).is_empty() { Space::new() } else {
      let v263_6: Path = concat_path(&(*p0),&v261_28_cursor.path()[v261_28_origin..(v261_28_origin + 1)]);
      let mut v263_7 = Space::new();
      let mut v263_7_write = v263_7.write_zipper();
      for v263_7_byte in v261_28_cursor.child_mask().iter() {
        v261_28_cursor.descend_to_existing_byte(v263_7_byte);
        {
        let v264_2: Space = singleton(&v261_28_cursor.path()[(v261_28_origin + 1)..(v261_28_origin + 2)]);
        let v264_3: Space = intersect(&(*CONSTANT_2),&(v264_2));
        let v264_4: Space = if has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
        drop(v264_3);
        let v264_5: Space = subtract(&(*CONSTANT_1),&(v264_4));
        drop(v264_4);
        let v264_8: Space = if (&(v264_5)).is_empty() { Space::new() } else {
          let v265_6: Path = concat_path(&(v263_6),&v261_28_cursor.path()[(v261_28_origin + 1)..(v261_28_origin + 2)]);
          let mut v265_7 = Space::new();
          let mut v265_7_write = v265_7.write_zipper();
          for v265_7_byte in v261_28_cursor.child_mask().iter() {
            v261_28_cursor.descend_to_existing_byte(v265_7_byte);
            {
            let v266_2: Space = singleton(&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
            let v266_3: Space = intersect(&(*CONSTANT_2),&(v266_2));
            let v266_4: Space = if has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
            drop(v266_3);
            let v266_5: Space = subtract(&(*CONSTANT_1),&(v266_4));
            drop(v266_4);
            let v266_8: Space = if (&(v266_5)).is_empty() { Space::new() } else {
              let v267_6: Path = concat_path(&(v265_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v267_7: Space = routine_26(c, &(v267_6), &(*p1), &v261_28_cursor, &(*s1));
              compose(&(v266_5),&(v267_7))
            };
            drop(v266_5);
            let v266_9: Space = intersect(&(*CONSTANT_2),&(v266_2));
            drop(v266_2);
            let v266_10: Space = if has_head(&(v266_9)) { singleton(&[]) } else { Space::new() };
            drop(v266_9);
            let v266_12: Space = if (&(v266_10)).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v265_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v268_11: Space = routine_27(c, &(v268_6), &(*p1), &v261_28_cursor, &(*s1));
              drop(v268_6);
              compose(&(v266_10),&(v268_11))
            };
            drop(v266_10);
            let v266_13: Space = unite(&(v266_8),&(v266_12));
            join_wrapped_into(&mut v265_7_write,&((v266_13).read_zipper()),&[]);
            }
            v261_28_cursor.ascend(1);
          }
          drop(v265_7_write);
          compose(&(v264_5),&(v265_7))
        };
        drop(v264_5);
        let v264_9: Space = intersect(&(*CONSTANT_2),&(v264_2));
        drop(v264_2);
        let v264_10: Space = if has_head(&(v264_9)) { singleton(&[]) } else { Space::new() };
        drop(v264_9);
        let v264_12: Space = if (&(v264_10)).is_empty() { Space::new() } else {
          let v269_6: Path = concat_path(&(v263_6),&v261_28_cursor.path()[(v261_28_origin + 1)..(v261_28_origin + 2)]);
          let mut v269_11 = Space::new();
          let mut v269_11_write = v269_11.write_zipper();
          for v269_11_byte in v261_28_cursor.child_mask().iter() {
            v261_28_cursor.descend_to_existing_byte(v269_11_byte);
            {
            let v270_2: Space = singleton(&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
            let v270_3: Space = intersect(&(*CONSTANT_2),&(v270_2));
            let v270_4: Space = if has_head(&(v270_3)) { singleton(&[]) } else { Space::new() };
            drop(v270_3);
            let v270_5: Space = subtract(&(*CONSTANT_1),&(v270_4));
            drop(v270_4);
            let v270_8: Space = if (&(v270_5)).is_empty() { Space::new() } else {
              let v271_6: Path = concat_path(&(v269_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v271_7: Space = routine_26(c, &(v271_6), &(*p1), &v261_28_cursor, &(*s1));
              compose(&(v270_5),&(v271_7))
            };
            drop(v270_5);
            let v270_9: Space = intersect(&(*CONSTANT_2),&(v270_2));
            drop(v270_2);
            let v270_10: Space = if has_head(&(v270_9)) { singleton(&[]) } else { Space::new() };
            drop(v270_9);
            let v270_12: Space = if (&(v270_10)).is_empty() { Space::new() } else {
              let v272_6: Path = concat_path(&(v269_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v272_11: Space = routine_10(c, &(v272_6), &(*p1), &v261_28_cursor, &(*s1));
              drop(v272_6);
              compose(&(v270_10),&(v272_11))
            };
            drop(v270_10);
            let v270_13: Space = unite(&(v270_8),&(v270_12));
            join_wrapped_into(&mut v269_11_write,&((v270_13).read_zipper()),&[]);
            }
            v261_28_cursor.ascend(1);
          }
          drop(v269_11_write);
          drop(v269_6);
          compose(&(v264_10),&(v269_11))
        };
        drop(v264_10);
        let v264_13: Space = unite(&(v264_8),&(v264_12));
        join_wrapped_into(&mut v263_7_write,&((v264_13).read_zipper()),&[]);
        }
        v261_28_cursor.ascend(1);
      }
      drop(v263_7_write);
      drop(v263_6);
      compose(&(v262_5),&(v263_7))
    };
    drop(v262_5);
    let v262_9: Space = intersect(&(*CONSTANT_2),&(v262_2));
    drop(v262_2);
    let v262_10: Space = if has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
    drop(v262_9);
    let v262_13: Space = if (&(v262_10)).is_empty() { Space::new() } else {
      let mut v273_12 = Space::new();
      let mut v273_12_write = v273_12.write_zipper();
      let mut v273_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v261_28_cursor.path()[v261_28_origin..(v261_28_origin + 1)]);
      let v273_12_origin = v273_12_cursor.path().len();
      for v273_12_byte in v273_12_cursor.child_mask().iter() {
        v273_12_cursor.descend_to_existing_byte(v273_12_byte);
        {
        let v274_2: Space = singleton(&v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 1)]);
        let v274_3: Space = intersect(&(*CONSTANT_2),&(v274_2));
        let v274_4: Space = if has_head(&(v274_3)) { singleton(&[]) } else { Space::new() };
        drop(v274_3);
        let v274_5: Space = subtract(&(*CONSTANT_1),&(v274_4));
        drop(v274_4);
        let v274_7: Space = if (&(v274_5)).is_empty() { Space::new() } else {
          let mut v275_6 = Space::new();
          let mut v275_6_write = v275_6.write_zipper();
          for v275_6_byte in v273_12_cursor.child_mask().iter() {
            v273_12_cursor.descend_to_existing_byte(v275_6_byte);
            {
            let v276_2: Space = singleton(&v273_12_cursor.path()[(v273_12_origin + 1)..(v273_12_origin + 2)]);
            let v276_3: Space = intersect(&(*CONSTANT_2),&(v276_2));
            let v276_4: Space = if has_head(&(v276_3)) { singleton(&[]) } else { Space::new() };
            drop(v276_3);
            let v276_5: Space = subtract(&(*CONSTANT_1),&(v276_4));
            drop(v276_4);
            let v276_8: Space = if (&(v276_5)).is_empty() { Space::new() } else {
              let v277_7: Space = routine_17(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              compose(&(v276_5),&(v277_7))
            };
            drop(v276_5);
            let v276_9: Space = intersect(&(*CONSTANT_2),&(v276_2));
            drop(v276_2);
            let v276_10: Space = if has_head(&(v276_9)) { singleton(&[]) } else { Space::new() };
            drop(v276_9);
            let v276_12: Space = if (&(v276_10)).is_empty() { Space::new() } else {
              let v278_11: Space = routine_18(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              compose(&(v276_10),&(v278_11))
            };
            drop(v276_10);
            let v276_13: Space = unite(&(v276_8),&(v276_12));
            join_wrapped_into(&mut v275_6_write,&((v276_13).read_zipper()),&[]);
            }
            v273_12_cursor.ascend(1);
          }
          drop(v275_6_write);
          compose(&(v274_5),&(v275_6))
        };
        drop(v274_5);
        let v274_8: Space = intersect(&(*CONSTANT_2),&(v274_2));
        drop(v274_2);
        let v274_9: Space = if has_head(&(v274_8)) { singleton(&[]) } else { Space::new() };
        drop(v274_8);
        let v274_11: Space = if (&(v274_9)).is_empty() { Space::new() } else {
          let mut v279_10 = Space::new();
          let mut v279_10_write = v279_10.write_zipper();
          for v279_10_byte in v273_12_cursor.child_mask().iter() {
            v273_12_cursor.descend_to_existing_byte(v279_10_byte);
            {
            let v280_2: Space = singleton(&v273_12_cursor.path()[(v273_12_origin + 1)..(v273_12_origin + 2)]);
            let v280_3: Space = intersect(&(*CONSTANT_2),&(v280_2));
            let v280_4: Space = if has_head(&(v280_3)) { singleton(&[]) } else { Space::new() };
            drop(v280_3);
            let v280_5: Space = subtract(&(*CONSTANT_1),&(v280_4));
            drop(v280_4);
            let v280_8: Space = if (&(v280_5)).is_empty() { Space::new() } else {
              let v281_7: Space = routine_17(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              compose(&(v280_5),&(v281_7))
            };
            drop(v280_5);
            let v280_9: Space = intersect(&(*CONSTANT_2),&(v280_2));
            drop(v280_2);
            let v280_10: Space = if has_head(&(v280_9)) { singleton(&[]) } else { Space::new() };
            drop(v280_9);
            let v280_12: Space = if (&(v280_10)).is_empty() { Space::new() } else {
              let v282_11: Space = routine_19(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              compose(&(v280_10),&(v282_11))
            };
            drop(v280_10);
            let v280_13: Space = unite(&(v280_8),&(v280_12));
            join_wrapped_into(&mut v279_10_write,&((v280_13).read_zipper()),&[]);
            }
            v273_12_cursor.ascend(1);
          }
          drop(v279_10_write);
          compose(&(v274_9),&(v279_10))
        };
        drop(v274_9);
        let v274_12: Space = unite(&(v274_7),&(v274_11));
        join_wrapped_into(&mut v273_12_write,&((v274_12).read_zipper()),&[]);
        }
        v273_12_cursor.ascend(1);
      }
      drop(v273_12_cursor);
      drop(v273_12_write);
      compose(&(v262_10),&(v273_12))
    };
    drop(v262_10);
    let v262_14: Space = unite(&(v262_8),&(v262_13));
    join_wrapped_into(&mut v261_28_write,&((v262_14).read_zipper()),&[]);
    }
    v261_28_cursor.ascend(1);
  }
  drop(v261_28_cursor);
  drop(v261_28_write);
  (v261_28).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v283_21 = Space::new();
  let mut v283_21_write = v283_21.write_zipper();
  let mut v283_21_cursor = (*s0).read_zipper();
  let v283_21_origin = v283_21_cursor.path().len();
  for v283_21_byte in v283_21_cursor.child_mask().iter() {
    v283_21_cursor.descend_to_existing_byte(v283_21_byte);
    {
    let v284_2: Space = singleton(&v283_21_cursor.path()[v283_21_origin..(v283_21_origin + 1)]);
    let v284_3: Space = intersect(&(*CONSTANT_2),&(v284_2));
    let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
    drop(v284_3);
    let v284_5: Space = subtract(&(*CONSTANT_1),&(v284_4));
    drop(v284_4);
    let v284_8: Space = if (&(v284_5)).is_empty() { Space::new() } else {
      let v285_6: Path = concat_path(&(*p0),&v283_21_cursor.path()[v283_21_origin..(v283_21_origin + 1)]);
      let mut v285_7 = Space::new();
      let mut v285_7_write = v285_7.write_zipper();
      for v285_7_byte in v283_21_cursor.child_mask().iter() {
        v283_21_cursor.descend_to_existing_byte(v285_7_byte);
        {
        let v286_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
        let v286_3: Space = intersect(&(*CONSTANT_2),&(v286_2));
        let v286_4: Space = if has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
        drop(v286_3);
        let v286_5: Space = subtract(&(*CONSTANT_1),&(v286_4));
        drop(v286_4);
        let v286_8: Space = if (&(v286_5)).is_empty() { Space::new() } else {
          let v287_6: Path = concat_path(&(v285_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
          let mut v287_7 = Space::new();
          let mut v287_7_write = v287_7.write_zipper();
          for v287_7_byte in v283_21_cursor.child_mask().iter() {
            v283_21_cursor.descend_to_existing_byte(v287_7_byte);
            {
            let v288_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
            let v288_3: Space = intersect(&(*CONSTANT_2),&(v288_2));
            let v288_4: Space = if has_head(&(v288_3)) { singleton(&[]) } else { Space::new() };
            drop(v288_3);
            let v288_5: Space = subtract(&(*CONSTANT_1),&(v288_4));
            drop(v288_4);
            let v288_8: Space = if (&(v288_5)).is_empty() { Space::new() } else {
              let v289_6: Path = concat_path(&(v287_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v289_7: Space = routine_28(c, &(v289_6), &(*p1), &v283_21_cursor);
              compose(&(v288_5),&(v289_7))
            };
            drop(v288_5);
            let v288_9: Space = intersect(&(*CONSTANT_2),&(v288_2));
            drop(v288_2);
            let v288_10: Space = if has_head(&(v288_9)) { singleton(&[]) } else { Space::new() };
            drop(v288_9);
            let v288_12: Space = if (&(v288_10)).is_empty() { Space::new() } else {
              let v290_6: Path = concat_path(&(v287_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v290_11: Space = routine_29(c, &(v290_6), &(*p1), &v283_21_cursor);
              drop(v290_6);
              compose(&(v288_10),&(v290_11))
            };
            drop(v288_10);
            let v288_13: Space = unite(&(v288_8),&(v288_12));
            join_wrapped_into(&mut v287_7_write,&((v288_13).read_zipper()),&[]);
            }
            v283_21_cursor.ascend(1);
          }
          drop(v287_7_write);
          compose(&(v286_5),&(v287_7))
        };
        drop(v286_5);
        let v286_9: Space = intersect(&(*CONSTANT_2),&(v286_2));
        drop(v286_2);
        let v286_10: Space = if has_head(&(v286_9)) { singleton(&[]) } else { Space::new() };
        drop(v286_9);
        let v286_12: Space = if (&(v286_10)).is_empty() { Space::new() } else {
          let v291_6: Path = concat_path(&(v285_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
          let mut v291_11 = Space::new();
          let mut v291_11_write = v291_11.write_zipper();
          for v291_11_byte in v283_21_cursor.child_mask().iter() {
            v283_21_cursor.descend_to_existing_byte(v291_11_byte);
            {
            let v292_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
            let v292_3: Space = intersect(&(*CONSTANT_2),&(v292_2));
            let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
            drop(v292_3);
            let v292_5: Space = subtract(&(*CONSTANT_1),&(v292_4));
            drop(v292_4);
            let v292_8: Space = if (&(v292_5)).is_empty() { Space::new() } else {
              let v293_6: Path = concat_path(&(v291_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v293_7: Space = routine_28(c, &(v293_6), &(*p1), &v283_21_cursor);
              compose(&(v292_5),&(v293_7))
            };
            drop(v292_5);
            let v292_9: Space = intersect(&(*CONSTANT_2),&(v292_2));
            drop(v292_2);
            let v292_10: Space = if has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
            drop(v292_9);
            let v292_12: Space = if (&(v292_10)).is_empty() { Space::new() } else {
              let v294_6: Path = concat_path(&(v291_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v294_11: Space = routine_19(c, &(v294_6), &(*p1), &v283_21_cursor);
              drop(v294_6);
              compose(&(v292_10),&(v294_11))
            };
            drop(v292_10);
            let v292_13: Space = unite(&(v292_8),&(v292_12));
            join_wrapped_into(&mut v291_11_write,&((v292_13).read_zipper()),&[]);
            }
            v283_21_cursor.ascend(1);
          }
          drop(v291_11_write);
          drop(v291_6);
          compose(&(v286_10),&(v291_11))
        };
        drop(v286_10);
        let v286_13: Space = unite(&(v286_8),&(v286_12));
        join_wrapped_into(&mut v285_7_write,&((v286_13).read_zipper()),&[]);
        }
        v283_21_cursor.ascend(1);
      }
      drop(v285_7_write);
      compose(&(v284_5),&(v285_7))
    };
    drop(v284_5);
    let v284_9: Space = intersect(&(*CONSTANT_2),&(v284_2));
    drop(v284_2);
    let v284_10: Space = if has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
    drop(v284_9);
    let v284_12: Space = if (&(v284_10)).is_empty() { Space::new() } else {
      let v295_6: Path = concat_path(&(*p0),&v283_21_cursor.path()[v283_21_origin..(v283_21_origin + 1)]);
      let mut v295_11 = Space::new();
      let mut v295_11_write = v295_11.write_zipper();
      for v295_11_byte in v283_21_cursor.child_mask().iter() {
        v283_21_cursor.descend_to_existing_byte(v295_11_byte);
        {
        let v296_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
        let v296_3: Space = intersect(&(*CONSTANT_2),&(v296_2));
        let v296_4: Space = if has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
        drop(v296_3);
        let v296_5: Space = subtract(&(*CONSTANT_1),&(v296_4));
        drop(v296_4);
        let v296_8: Space = if (&(v296_5)).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v295_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
          let mut v297_7 = Space::new();
          let mut v297_7_write = v297_7.write_zipper();
          for v297_7_byte in v283_21_cursor.child_mask().iter() {
            v283_21_cursor.descend_to_existing_byte(v297_7_byte);
            {
            let v298_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
            let v298_3: Space = intersect(&(*CONSTANT_2),&(v298_2));
            let v298_4: Space = if has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = subtract(&(*CONSTANT_1),&(v298_4));
            drop(v298_4);
            let v298_8: Space = if (&(v298_5)).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v297_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v299_7: Space = routine_28(c, &(v299_6), &(*p1), &v283_21_cursor);
              compose(&(v298_5),&(v299_7))
            };
            drop(v298_5);
            let v298_9: Space = intersect(&(*CONSTANT_2),&(v298_2));
            drop(v298_2);
            let v298_10: Space = if has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
            drop(v298_9);
            let v298_12: Space = if (&(v298_10)).is_empty() { Space::new() } else {
              let v300_6: Path = concat_path(&(v297_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v300_11: Space = routine_29(c, &(v300_6), &(*p1), &v283_21_cursor);
              drop(v300_6);
              compose(&(v298_10),&(v300_11))
            };
            drop(v298_10);
            let v298_13: Space = unite(&(v298_8),&(v298_12));
            join_wrapped_into(&mut v297_7_write,&((v298_13).read_zipper()),&[]);
            }
            v283_21_cursor.ascend(1);
          }
          drop(v297_7_write);
          compose(&(v296_5),&(v297_7))
        };
        drop(v296_5);
        let v296_9: Space = intersect(&(*CONSTANT_2),&(v296_2));
        drop(v296_2);
        let v296_10: Space = if has_head(&(v296_9)) { singleton(&[]) } else { Space::new() };
        drop(v296_9);
        let v296_11: Space = compose(&(v296_10),&v283_21_cursor);
        drop(v296_10);
        let v301_6: Path = concat_path(&(v295_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
        let v296_12: Space = wrap(&(v296_11),&(v301_6));
        drop(v296_11);
        let v296_13: Space = wrap(&(v296_12),&(*p1));
        drop(v296_12);
        let v296_14: Space = unite(&(v296_8),&(v296_13));
        drop(v296_13);
        join_wrapped_into(&mut v295_11_write,&((v296_14).read_zipper()),&[]);
        }
        v283_21_cursor.ascend(1);
      }
      drop(v295_11_write);
      drop(v295_6);
      compose(&(v284_10),&(v295_11))
    };
    drop(v284_10);
    let v284_13: Space = unite(&(v284_8),&(v284_12));
    join_wrapped_into(&mut v283_21_write,&((v284_13).read_zipper()),&[]);
    }
    v283_21_cursor.ascend(1);
  }
  drop(v283_21_cursor);
  drop(v283_21_write);
  (v283_21).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v302_15 = Space::new();
  let mut v302_15_write = v302_15.write_zipper();
  let mut v302_15_cursor = (*s0).read_zipper();
  let v302_15_origin = v302_15_cursor.path().len();
  for v302_15_byte in v302_15_cursor.child_mask().iter() {
    v302_15_cursor.descend_to_existing_byte(v302_15_byte);
    {
    let v303_2: Space = singleton(&v302_15_cursor.path()[v302_15_origin..(v302_15_origin + 1)]);
    let v303_3: Space = intersect(&(*CONSTANT_2),&(v303_2));
    let v303_4: Space = if has_head(&(v303_3)) { singleton(&[]) } else { Space::new() };
    drop(v303_3);
    let v303_5: Space = subtract(&(*CONSTANT_1),&(v303_4));
    drop(v303_4);
    let v303_8: Space = if (&(v303_5)).is_empty() { Space::new() } else {
      let v304_6: Path = concat_path(&(*p0),&v302_15_cursor.path()[v302_15_origin..(v302_15_origin + 1)]);
      let mut v304_7 = Space::new();
      let mut v304_7_write = v304_7.write_zipper();
      for v304_7_byte in v302_15_cursor.child_mask().iter() {
        v302_15_cursor.descend_to_existing_byte(v304_7_byte);
        {
        let v305_2: Space = singleton(&v302_15_cursor.path()[(v302_15_origin + 1)..(v302_15_origin + 2)]);
        let v305_3: Space = intersect(&(*CONSTANT_2),&(v305_2));
        let v305_4: Space = if has_head(&(v305_3)) { singleton(&[]) } else { Space::new() };
        drop(v305_3);
        let v305_5: Space = subtract(&(*CONSTANT_1),&(v305_4));
        drop(v305_4);
        let v305_8: Space = if (&(v305_5)).is_empty() { Space::new() } else {
          let v306_6: Path = concat_path(&(v304_6),&v302_15_cursor.path()[(v302_15_origin + 1)..(v302_15_origin + 2)]);
          let mut v306_7 = Space::new();
          let mut v306_7_write = v306_7.write_zipper();
          for v306_7_byte in v302_15_cursor.child_mask().iter() {
            v302_15_cursor.descend_to_existing_byte(v306_7_byte);
            {
            let v307_2: Space = singleton(&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
            let v307_3: Space = intersect(&(*CONSTANT_2),&(v307_2));
            let v307_4: Space = if has_head(&(v307_3)) { singleton(&[]) } else { Space::new() };
            drop(v307_3);
            let v307_5: Space = subtract(&(*CONSTANT_1),&(v307_4));
            drop(v307_4);
            let v307_8: Space = if (&(v307_5)).is_empty() { Space::new() } else {
              let v308_6: Path = concat_path(&(v306_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v308_7: Space = routine_28(c, &(v308_6), &(*p1), &v302_15_cursor);
              compose(&(v307_5),&(v308_7))
            };
            drop(v307_5);
            let v307_9: Space = intersect(&(*CONSTANT_2),&(v307_2));
            drop(v307_2);
            let v307_10: Space = if has_head(&(v307_9)) { singleton(&[]) } else { Space::new() };
            drop(v307_9);
            let v307_12: Space = if (&(v307_10)).is_empty() { Space::new() } else {
              let v309_6: Path = concat_path(&(v306_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v309_11: Space = routine_29(c, &(v309_6), &(*p1), &v302_15_cursor);
              drop(v309_6);
              compose(&(v307_10),&(v309_11))
            };
            drop(v307_10);
            let v307_13: Space = unite(&(v307_8),&(v307_12));
            join_wrapped_into(&mut v306_7_write,&((v307_13).read_zipper()),&[]);
            }
            v302_15_cursor.ascend(1);
          }
          drop(v306_7_write);
          compose(&(v305_5),&(v306_7))
        };
        drop(v305_5);
        let v305_9: Space = intersect(&(*CONSTANT_2),&(v305_2));
        drop(v305_2);
        let v305_10: Space = if has_head(&(v305_9)) { singleton(&[]) } else { Space::new() };
        drop(v305_9);
        let v305_12: Space = if (&(v305_10)).is_empty() { Space::new() } else {
          let v310_6: Path = concat_path(&(v304_6),&v302_15_cursor.path()[(v302_15_origin + 1)..(v302_15_origin + 2)]);
          let mut v310_11 = Space::new();
          let mut v310_11_write = v310_11.write_zipper();
          for v310_11_byte in v302_15_cursor.child_mask().iter() {
            v302_15_cursor.descend_to_existing_byte(v310_11_byte);
            {
            let v311_2: Space = singleton(&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
            let v311_3: Space = intersect(&(*CONSTANT_2),&(v311_2));
            let v311_4: Space = if has_head(&(v311_3)) { singleton(&[]) } else { Space::new() };
            drop(v311_3);
            let v311_5: Space = subtract(&(*CONSTANT_1),&(v311_4));
            drop(v311_4);
            let v311_8: Space = if (&(v311_5)).is_empty() { Space::new() } else {
              let v312_6: Path = concat_path(&(v310_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v312_7: Space = routine_28(c, &(v312_6), &(*p1), &v302_15_cursor);
              compose(&(v311_5),&(v312_7))
            };
            drop(v311_5);
            let v311_9: Space = intersect(&(*CONSTANT_2),&(v311_2));
            drop(v311_2);
            let v311_10: Space = if has_head(&(v311_9)) { singleton(&[]) } else { Space::new() };
            drop(v311_9);
            let v311_12: Space = if (&(v311_10)).is_empty() { Space::new() } else {
              let v313_6: Path = concat_path(&(v310_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v313_11: Space = routine_19(c, &(v313_6), &(*p1), &v302_15_cursor);
              drop(v313_6);
              compose(&(v311_10),&(v313_11))
            };
            drop(v311_10);
            let v311_13: Space = unite(&(v311_8),&(v311_12));
            join_wrapped_into(&mut v310_11_write,&((v311_13).read_zipper()),&[]);
            }
            v302_15_cursor.ascend(1);
          }
          drop(v310_11_write);
          drop(v310_6);
          compose(&(v305_10),&(v310_11))
        };
        drop(v305_10);
        let v305_13: Space = unite(&(v305_8),&(v305_12));
        join_wrapped_into(&mut v304_7_write,&((v305_13).read_zipper()),&[]);
        }
        v302_15_cursor.ascend(1);
      }
      drop(v304_7_write);
      compose(&(v303_5),&(v304_7))
    };
    drop(v303_5);
    let v303_9: Space = intersect(&(*CONSTANT_2),&(v303_2));
    drop(v303_2);
    let v303_10: Space = if has_head(&(v303_9)) { singleton(&[]) } else { Space::new() };
    drop(v303_9);
    let v303_11: Space = compose(&(v303_10),&v302_15_cursor);
    drop(v303_10);
    let v314_6: Path = concat_path(&(*p0),&v302_15_cursor.path()[v302_15_origin..(v302_15_origin + 1)]);
    let v303_12: Space = wrap(&(v303_11),&(v314_6));
    drop(v303_11);
    let v303_13: Space = wrap(&(v303_12),&(*p1));
    drop(v303_12);
    let v303_14: Space = unite(&(v303_8),&(v303_13));
    drop(v303_13);
    join_wrapped_into(&mut v302_15_write,&((v303_14).read_zipper()),&[]);
    }
    v302_15_cursor.ascend(1);
  }
  drop(v302_15_cursor);
  drop(v302_15_write);
  (v302_15).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v315_28 = Space::new();
  let mut v315_28_write = v315_28.write_zipper();
  let mut v315_28_cursor = (*s0).read_zipper();
  let v315_28_origin = v315_28_cursor.path().len();
  for v315_28_byte in v315_28_cursor.child_mask().iter() {
    v315_28_cursor.descend_to_existing_byte(v315_28_byte);
    {
    let v316_2: Space = singleton(&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]);
    let v316_3: Space = intersect(&(*CONSTANT_2),&(v316_2));
    let v316_4: Space = if has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
    drop(v316_3);
    let v316_5: Space = subtract(&(*CONSTANT_1),&(v316_4));
    drop(v316_4);
    let v316_8: Space = if (&(v316_5)).is_empty() { Space::new() } else {
      let v317_6: Path = concat_path(&(*p0),&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]);
      let mut v317_7 = Space::new();
      let mut v317_7_write = v317_7.write_zipper();
      for v317_7_byte in v315_28_cursor.child_mask().iter() {
        v315_28_cursor.descend_to_existing_byte(v317_7_byte);
        {
        let v318_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
        let v318_3: Space = intersect(&(*CONSTANT_2),&(v318_2));
        let v318_4: Space = if has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
        drop(v318_3);
        let v318_5: Space = subtract(&(*CONSTANT_1),&(v318_4));
        drop(v318_4);
        let v318_8: Space = if (&(v318_5)).is_empty() { Space::new() } else {
          let v319_6: Path = concat_path(&(v317_6),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let mut v319_7 = Space::new();
          let mut v319_7_write = v319_7.write_zipper();
          for v319_7_byte in v315_28_cursor.child_mask().iter() {
            v315_28_cursor.descend_to_existing_byte(v319_7_byte);
            {
            let v320_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
            let v320_3: Space = intersect(&(*CONSTANT_2),&(v320_2));
            let v320_4: Space = if has_head(&(v320_3)) { singleton(&[]) } else { Space::new() };
            drop(v320_3);
            let v320_5: Space = subtract(&(*CONSTANT_1),&(v320_4));
            drop(v320_4);
            let v320_8: Space = if (&(v320_5)).is_empty() { Space::new() } else {
              let v321_6: Path = concat_path(&(v319_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v321_7: Space = routine_30(c, &(v321_6), &(*p1), &v315_28_cursor, &(*s1));
              compose(&(v320_5),&(v321_7))
            };
            drop(v320_5);
            let v320_9: Space = intersect(&(*CONSTANT_2),&(v320_2));
            drop(v320_2);
            let v320_10: Space = if has_head(&(v320_9)) { singleton(&[]) } else { Space::new() };
            drop(v320_9);
            let v320_12: Space = if (&(v320_10)).is_empty() { Space::new() } else {
              let v322_6: Path = concat_path(&(v319_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v322_11: Space = routine_31(c, &(v322_6), &(*p1), &v315_28_cursor, &(*s1));
              drop(v322_6);
              compose(&(v320_10),&(v322_11))
            };
            drop(v320_10);
            let v320_13: Space = unite(&(v320_8),&(v320_12));
            join_wrapped_into(&mut v319_7_write,&((v320_13).read_zipper()),&[]);
            }
            v315_28_cursor.ascend(1);
          }
          drop(v319_7_write);
          compose(&(v318_5),&(v319_7))
        };
        drop(v318_5);
        let v318_9: Space = intersect(&(*CONSTANT_2),&(v318_2));
        drop(v318_2);
        let v318_10: Space = if has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
        drop(v318_9);
        let v318_12: Space = if (&(v318_10)).is_empty() { Space::new() } else {
          let v323_6: Path = concat_path(&(v317_6),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let mut v323_11 = Space::new();
          let mut v323_11_write = v323_11.write_zipper();
          for v323_11_byte in v315_28_cursor.child_mask().iter() {
            v315_28_cursor.descend_to_existing_byte(v323_11_byte);
            {
            let v324_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
            let v324_3: Space = intersect(&(*CONSTANT_2),&(v324_2));
            let v324_4: Space = if has_head(&(v324_3)) { singleton(&[]) } else { Space::new() };
            drop(v324_3);
            let v324_5: Space = subtract(&(*CONSTANT_1),&(v324_4));
            drop(v324_4);
            let v324_8: Space = if (&(v324_5)).is_empty() { Space::new() } else {
              let v325_6: Path = concat_path(&(v323_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v325_7: Space = routine_30(c, &(v325_6), &(*p1), &v315_28_cursor, &(*s1));
              compose(&(v324_5),&(v325_7))
            };
            drop(v324_5);
            let v324_9: Space = intersect(&(*CONSTANT_2),&(v324_2));
            drop(v324_2);
            let v324_10: Space = if has_head(&(v324_9)) { singleton(&[]) } else { Space::new() };
            drop(v324_9);
            let v324_12: Space = if (&(v324_10)).is_empty() { Space::new() } else {
              let v326_6: Path = concat_path(&(v323_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v326_11: Space = routine_10(c, &(v326_6), &(*p1), &v315_28_cursor, &(*s1));
              drop(v326_6);
              compose(&(v324_10),&(v326_11))
            };
            drop(v324_10);
            let v324_13: Space = unite(&(v324_8),&(v324_12));
            join_wrapped_into(&mut v323_11_write,&((v324_13).read_zipper()),&[]);
            }
            v315_28_cursor.ascend(1);
          }
          drop(v323_11_write);
          drop(v323_6);
          compose(&(v318_10),&(v323_11))
        };
        drop(v318_10);
        let v318_13: Space = unite(&(v318_8),&(v318_12));
        join_wrapped_into(&mut v317_7_write,&((v318_13).read_zipper()),&[]);
        }
        v315_28_cursor.ascend(1);
      }
      drop(v317_7_write);
      compose(&(v316_5),&(v317_7))
    };
    drop(v316_5);
    let v316_9: Space = intersect(&(*CONSTANT_2),&(v316_2));
    drop(v316_2);
    let v316_10: Space = if has_head(&(v316_9)) { singleton(&[]) } else { Space::new() };
    drop(v316_9);
    let v316_13: Space = if (&(v316_10)).is_empty() { Space::new() } else {
      let v327_6: Path = concat_path(&(*p0),&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]);
      let mut v327_12 = Space::new();
      let mut v327_12_write = v327_12.write_zipper();
      for v327_12_byte in v315_28_cursor.child_mask().iter() {
        v315_28_cursor.descend_to_existing_byte(v327_12_byte);
        {
        let v328_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
        let v328_3: Space = intersect(&(*CONSTANT_2),&(v328_2));
        let v328_4: Space = if has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
        drop(v328_3);
        let v328_5: Space = subtract(&(*CONSTANT_1),&(v328_4));
        drop(v328_4);
        let v328_8: Space = if (&(v328_5)).is_empty() { Space::new() } else {
          let v329_6: Path = concat_path(&(v327_6),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let mut v329_7 = Space::new();
          let mut v329_7_write = v329_7.write_zipper();
          for v329_7_byte in v315_28_cursor.child_mask().iter() {
            v315_28_cursor.descend_to_existing_byte(v329_7_byte);
            {
            let v330_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
            let v330_3: Space = intersect(&(*CONSTANT_2),&(v330_2));
            let v330_4: Space = if has_head(&(v330_3)) { singleton(&[]) } else { Space::new() };
            drop(v330_3);
            let v330_5: Space = subtract(&(*CONSTANT_1),&(v330_4));
            drop(v330_4);
            let v330_8: Space = if (&(v330_5)).is_empty() { Space::new() } else {
              let v331_6: Path = concat_path(&(v329_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v331_7: Space = routine_30(c, &(v331_6), &(*p1), &v315_28_cursor, &(*s1));
              compose(&(v330_5),&(v331_7))
            };
            drop(v330_5);
            let v330_9: Space = intersect(&(*CONSTANT_2),&(v330_2));
            drop(v330_2);
            let v330_10: Space = if has_head(&(v330_9)) { singleton(&[]) } else { Space::new() };
            drop(v330_9);
            let v330_12: Space = if (&(v330_10)).is_empty() { Space::new() } else {
              let v332_6: Path = concat_path(&(v329_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v332_11: Space = routine_31(c, &(v332_6), &(*p1), &v315_28_cursor, &(*s1));
              drop(v332_6);
              compose(&(v330_10),&(v332_11))
            };
            drop(v330_10);
            let v330_13: Space = unite(&(v330_8),&(v330_12));
            join_wrapped_into(&mut v329_7_write,&((v330_13).read_zipper()),&[]);
            }
            v315_28_cursor.ascend(1);
          }
          drop(v329_7_write);
          drop(v329_6);
          compose(&(v328_5),&(v329_7))
        };
        drop(v328_5);
        let v328_9: Space = intersect(&(*CONSTANT_2),&(v328_2));
        drop(v328_2);
        let v328_10: Space = if has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
        drop(v328_9);
        let v328_13: Space = if (&(v328_10)).is_empty() { Space::new() } else {
          let mut v333_12 = Space::new();
          let mut v333_12_write = v333_12.write_zipper();
          let mut v333_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let v333_12_origin = v333_12_cursor.path().len();
          for v333_12_byte in v333_12_cursor.child_mask().iter() {
            v333_12_cursor.descend_to_existing_byte(v333_12_byte);
            {
            let v334_2: Space = singleton(&v333_12_cursor.path()[v333_12_origin..(v333_12_origin + 1)]);
            let v334_3: Space = intersect(&(*CONSTANT_2),&(v334_2));
            let v334_4: Space = if has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
            drop(v334_3);
            let v334_5: Space = subtract(&(*CONSTANT_1),&(v334_4));
            drop(v334_4);
            let v334_7: Space = if (&(v334_5)).is_empty() { Space::new() } else {
              let v335_6: Space = routine_13(c, &v333_12_cursor.path()[v333_12_origin..(v333_12_origin + 1)], &(*p1), &v333_12_cursor);
              compose(&(v334_5),&(v335_6))
            };
            drop(v334_5);
            let v334_8: Space = intersect(&(*CONSTANT_2),&(v334_2));
            drop(v334_2);
            let v334_9: Space = if has_head(&(v334_8)) { singleton(&[]) } else { Space::new() };
            drop(v334_8);
            let v334_11: Space = if (&(v334_9)).is_empty() { Space::new() } else {
              let v336_10: Space = routine_14(c, &v333_12_cursor.path()[v333_12_origin..(v333_12_origin + 1)], &(*p1), &v333_12_cursor);
              compose(&(v334_9),&(v336_10))
            };
            drop(v334_9);
            let v334_12: Space = unite(&(v334_7),&(v334_11));
            join_wrapped_into(&mut v333_12_write,&((v334_12).read_zipper()),&[]);
            }
            v333_12_cursor.ascend(1);
          }
          drop(v333_12_cursor);
          drop(v333_12_write);
          compose(&(v328_10),&(v333_12))
        };
        drop(v328_10);
        let v328_14: Space = unite(&(v328_8),&(v328_13));
        join_wrapped_into(&mut v327_12_write,&((v328_14).read_zipper()),&[]);
        }
        v315_28_cursor.ascend(1);
      }
      drop(v327_12_write);
      drop(v327_6);
      compose(&(v316_10),&(v327_12))
    };
    drop(v316_10);
    let v316_14: Space = unite(&(v316_8),&(v316_13));
    join_wrapped_into(&mut v315_28_write,&((v316_14).read_zipper()),&[]);
    }
    v315_28_cursor.ascend(1);
  }
  drop(v315_28_cursor);
  drop(v315_28_write);
  (v315_28).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v337_28 = Space::new();
  let mut v337_28_write = v337_28.write_zipper();
  let mut v337_28_cursor = (*s0).read_zipper();
  let v337_28_origin = v337_28_cursor.path().len();
  for v337_28_byte in v337_28_cursor.child_mask().iter() {
    v337_28_cursor.descend_to_existing_byte(v337_28_byte);
    {
    let v338_2: Space = singleton(&v337_28_cursor.path()[v337_28_origin..(v337_28_origin + 1)]);
    let v338_3: Space = intersect(&(*CONSTANT_2),&(v338_2));
    let v338_4: Space = if has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
    drop(v338_3);
    let v338_5: Space = subtract(&(*CONSTANT_1),&(v338_4));
    drop(v338_4);
    let v338_8: Space = if (&(v338_5)).is_empty() { Space::new() } else {
      let v339_6: Path = concat_path(&(*p0),&v337_28_cursor.path()[v337_28_origin..(v337_28_origin + 1)]);
      let mut v339_7 = Space::new();
      let mut v339_7_write = v339_7.write_zipper();
      for v339_7_byte in v337_28_cursor.child_mask().iter() {
        v337_28_cursor.descend_to_existing_byte(v339_7_byte);
        {
        let v340_2: Space = singleton(&v337_28_cursor.path()[(v337_28_origin + 1)..(v337_28_origin + 2)]);
        let v340_3: Space = intersect(&(*CONSTANT_2),&(v340_2));
        let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
        drop(v340_3);
        let v340_5: Space = subtract(&(*CONSTANT_1),&(v340_4));
        drop(v340_4);
        let v340_8: Space = if (&(v340_5)).is_empty() { Space::new() } else {
          let v341_6: Path = concat_path(&(v339_6),&v337_28_cursor.path()[(v337_28_origin + 1)..(v337_28_origin + 2)]);
          let mut v341_7 = Space::new();
          let mut v341_7_write = v341_7.write_zipper();
          for v341_7_byte in v337_28_cursor.child_mask().iter() {
            v337_28_cursor.descend_to_existing_byte(v341_7_byte);
            {
            let v342_2: Space = singleton(&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
            let v342_3: Space = intersect(&(*CONSTANT_2),&(v342_2));
            let v342_4: Space = if has_head(&(v342_3)) { singleton(&[]) } else { Space::new() };
            drop(v342_3);
            let v342_5: Space = subtract(&(*CONSTANT_1),&(v342_4));
            drop(v342_4);
            let v342_8: Space = if (&(v342_5)).is_empty() { Space::new() } else {
              let v343_6: Path = concat_path(&(v341_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v343_7: Space = routine_30(c, &(v343_6), &(*p1), &v337_28_cursor, &(*s1));
              compose(&(v342_5),&(v343_7))
            };
            drop(v342_5);
            let v342_9: Space = intersect(&(*CONSTANT_2),&(v342_2));
            drop(v342_2);
            let v342_10: Space = if has_head(&(v342_9)) { singleton(&[]) } else { Space::new() };
            drop(v342_9);
            let v342_12: Space = if (&(v342_10)).is_empty() { Space::new() } else {
              let v344_6: Path = concat_path(&(v341_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v344_11: Space = routine_31(c, &(v344_6), &(*p1), &v337_28_cursor, &(*s1));
              drop(v344_6);
              compose(&(v342_10),&(v344_11))
            };
            drop(v342_10);
            let v342_13: Space = unite(&(v342_8),&(v342_12));
            join_wrapped_into(&mut v341_7_write,&((v342_13).read_zipper()),&[]);
            }
            v337_28_cursor.ascend(1);
          }
          drop(v341_7_write);
          compose(&(v340_5),&(v341_7))
        };
        drop(v340_5);
        let v340_9: Space = intersect(&(*CONSTANT_2),&(v340_2));
        drop(v340_2);
        let v340_10: Space = if has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
        drop(v340_9);
        let v340_12: Space = if (&(v340_10)).is_empty() { Space::new() } else {
          let v345_6: Path = concat_path(&(v339_6),&v337_28_cursor.path()[(v337_28_origin + 1)..(v337_28_origin + 2)]);
          let mut v345_11 = Space::new();
          let mut v345_11_write = v345_11.write_zipper();
          for v345_11_byte in v337_28_cursor.child_mask().iter() {
            v337_28_cursor.descend_to_existing_byte(v345_11_byte);
            {
            let v346_2: Space = singleton(&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
            let v346_3: Space = intersect(&(*CONSTANT_2),&(v346_2));
            let v346_4: Space = if has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
            drop(v346_3);
            let v346_5: Space = subtract(&(*CONSTANT_1),&(v346_4));
            drop(v346_4);
            let v346_8: Space = if (&(v346_5)).is_empty() { Space::new() } else {
              let v347_6: Path = concat_path(&(v345_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v347_7: Space = routine_30(c, &(v347_6), &(*p1), &v337_28_cursor, &(*s1));
              compose(&(v346_5),&(v347_7))
            };
            drop(v346_5);
            let v346_9: Space = intersect(&(*CONSTANT_2),&(v346_2));
            drop(v346_2);
            let v346_10: Space = if has_head(&(v346_9)) { singleton(&[]) } else { Space::new() };
            drop(v346_9);
            let v346_12: Space = if (&(v346_10)).is_empty() { Space::new() } else {
              let v348_6: Path = concat_path(&(v345_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v348_11: Space = routine_10(c, &(v348_6), &(*p1), &v337_28_cursor, &(*s1));
              drop(v348_6);
              compose(&(v346_10),&(v348_11))
            };
            drop(v346_10);
            let v346_13: Space = unite(&(v346_8),&(v346_12));
            join_wrapped_into(&mut v345_11_write,&((v346_13).read_zipper()),&[]);
            }
            v337_28_cursor.ascend(1);
          }
          drop(v345_11_write);
          drop(v345_6);
          compose(&(v340_10),&(v345_11))
        };
        drop(v340_10);
        let v340_13: Space = unite(&(v340_8),&(v340_12));
        join_wrapped_into(&mut v339_7_write,&((v340_13).read_zipper()),&[]);
        }
        v337_28_cursor.ascend(1);
      }
      drop(v339_7_write);
      drop(v339_6);
      compose(&(v338_5),&(v339_7))
    };
    drop(v338_5);
    let v338_9: Space = intersect(&(*CONSTANT_2),&(v338_2));
    drop(v338_2);
    let v338_10: Space = if has_head(&(v338_9)) { singleton(&[]) } else { Space::new() };
    drop(v338_9);
    let v338_13: Space = if (&(v338_10)).is_empty() { Space::new() } else {
      let mut v349_12 = Space::new();
      let mut v349_12_write = v349_12.write_zipper();
      let mut v349_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v337_28_cursor.path()[v337_28_origin..(v337_28_origin + 1)]);
      let v349_12_origin = v349_12_cursor.path().len();
      for v349_12_byte in v349_12_cursor.child_mask().iter() {
        v349_12_cursor.descend_to_existing_byte(v349_12_byte);
        {
        let v350_2: Space = singleton(&v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 1)]);
        let v350_3: Space = intersect(&(*CONSTANT_2),&(v350_2));
        let v350_4: Space = if has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
        drop(v350_3);
        let v350_5: Space = subtract(&(*CONSTANT_1),&(v350_4));
        drop(v350_4);
        let v350_7: Space = if (&(v350_5)).is_empty() { Space::new() } else {
          let mut v351_6 = Space::new();
          let mut v351_6_write = v351_6.write_zipper();
          for v351_6_byte in v349_12_cursor.child_mask().iter() {
            v349_12_cursor.descend_to_existing_byte(v351_6_byte);
            {
            let v352_2: Space = singleton(&v349_12_cursor.path()[(v349_12_origin + 1)..(v349_12_origin + 2)]);
            let v352_3: Space = intersect(&(*CONSTANT_2),&(v352_2));
            let v352_4: Space = if has_head(&(v352_3)) { singleton(&[]) } else { Space::new() };
            drop(v352_3);
            let v352_5: Space = subtract(&(*CONSTANT_1),&(v352_4));
            drop(v352_4);
            let v352_8: Space = if (&(v352_5)).is_empty() { Space::new() } else {
              let v353_7: Space = routine_17(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              compose(&(v352_5),&(v353_7))
            };
            drop(v352_5);
            let v352_9: Space = intersect(&(*CONSTANT_2),&(v352_2));
            drop(v352_2);
            let v352_10: Space = if has_head(&(v352_9)) { singleton(&[]) } else { Space::new() };
            drop(v352_9);
            let v352_12: Space = if (&(v352_10)).is_empty() { Space::new() } else {
              let v354_11: Space = routine_18(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              compose(&(v352_10),&(v354_11))
            };
            drop(v352_10);
            let v352_13: Space = unite(&(v352_8),&(v352_12));
            join_wrapped_into(&mut v351_6_write,&((v352_13).read_zipper()),&[]);
            }
            v349_12_cursor.ascend(1);
          }
          drop(v351_6_write);
          compose(&(v350_5),&(v351_6))
        };
        drop(v350_5);
        let v350_8: Space = intersect(&(*CONSTANT_2),&(v350_2));
        drop(v350_2);
        let v350_9: Space = if has_head(&(v350_8)) { singleton(&[]) } else { Space::new() };
        drop(v350_8);
        let v350_11: Space = if (&(v350_9)).is_empty() { Space::new() } else {
          let mut v355_10 = Space::new();
          let mut v355_10_write = v355_10.write_zipper();
          for v355_10_byte in v349_12_cursor.child_mask().iter() {
            v349_12_cursor.descend_to_existing_byte(v355_10_byte);
            {
            let v356_2: Space = singleton(&v349_12_cursor.path()[(v349_12_origin + 1)..(v349_12_origin + 2)]);
            let v356_3: Space = intersect(&(*CONSTANT_2),&(v356_2));
            let v356_4: Space = if has_head(&(v356_3)) { singleton(&[]) } else { Space::new() };
            drop(v356_3);
            let v356_5: Space = subtract(&(*CONSTANT_1),&(v356_4));
            drop(v356_4);
            let v356_8: Space = if (&(v356_5)).is_empty() { Space::new() } else {
              let v357_7: Space = routine_17(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              compose(&(v356_5),&(v357_7))
            };
            drop(v356_5);
            let v356_9: Space = intersect(&(*CONSTANT_2),&(v356_2));
            drop(v356_2);
            let v356_10: Space = if has_head(&(v356_9)) { singleton(&[]) } else { Space::new() };
            drop(v356_9);
            let v356_12: Space = if (&(v356_10)).is_empty() { Space::new() } else {
              let v358_11: Space = routine_19(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              compose(&(v356_10),&(v358_11))
            };
            drop(v356_10);
            let v356_13: Space = unite(&(v356_8),&(v356_12));
            join_wrapped_into(&mut v355_10_write,&((v356_13).read_zipper()),&[]);
            }
            v349_12_cursor.ascend(1);
          }
          drop(v355_10_write);
          compose(&(v350_9),&(v355_10))
        };
        drop(v350_9);
        let v350_12: Space = unite(&(v350_7),&(v350_11));
        join_wrapped_into(&mut v349_12_write,&((v350_12).read_zipper()),&[]);
        }
        v349_12_cursor.ascend(1);
      }
      drop(v349_12_cursor);
      drop(v349_12_write);
      compose(&(v338_10),&(v349_12))
    };
    drop(v338_10);
    let v338_14: Space = unite(&(v338_8),&(v338_13));
    join_wrapped_into(&mut v337_28_write,&((v338_14).read_zipper()),&[]);
    }
    v337_28_cursor.ascend(1);
  }
  drop(v337_28_cursor);
  drop(v337_28_write);
  (v337_28).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v359_21 = Space::new();
  let mut v359_21_write = v359_21.write_zipper();
  let mut v359_21_cursor = (*s0).read_zipper();
  let v359_21_origin = v359_21_cursor.path().len();
  for v359_21_byte in v359_21_cursor.child_mask().iter() {
    v359_21_cursor.descend_to_existing_byte(v359_21_byte);
    {
    let v360_2: Space = singleton(&v359_21_cursor.path()[v359_21_origin..(v359_21_origin + 1)]);
    let v360_3: Space = intersect(&(*CONSTANT_2),&(v360_2));
    let v360_4: Space = if has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
    drop(v360_3);
    let v360_5: Space = subtract(&(*CONSTANT_1),&(v360_4));
    drop(v360_4);
    let v360_8: Space = if (&(v360_5)).is_empty() { Space::new() } else {
      let v361_6: Path = concat_path(&(*p0),&v359_21_cursor.path()[v359_21_origin..(v359_21_origin + 1)]);
      let mut v361_7 = Space::new();
      let mut v361_7_write = v361_7.write_zipper();
      for v361_7_byte in v359_21_cursor.child_mask().iter() {
        v359_21_cursor.descend_to_existing_byte(v361_7_byte);
        {
        let v362_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
        let v362_3: Space = intersect(&(*CONSTANT_2),&(v362_2));
        let v362_4: Space = if has_head(&(v362_3)) { singleton(&[]) } else { Space::new() };
        drop(v362_3);
        let v362_5: Space = subtract(&(*CONSTANT_1),&(v362_4));
        drop(v362_4);
        let v362_8: Space = if (&(v362_5)).is_empty() { Space::new() } else {
          let v363_6: Path = concat_path(&(v361_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
          let mut v363_7 = Space::new();
          let mut v363_7_write = v363_7.write_zipper();
          for v363_7_byte in v359_21_cursor.child_mask().iter() {
            v359_21_cursor.descend_to_existing_byte(v363_7_byte);
            {
            let v364_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
            let v364_3: Space = intersect(&(*CONSTANT_2),&(v364_2));
            let v364_4: Space = if has_head(&(v364_3)) { singleton(&[]) } else { Space::new() };
            drop(v364_3);
            let v364_5: Space = subtract(&(*CONSTANT_1),&(v364_4));
            drop(v364_4);
            let v364_8: Space = if (&(v364_5)).is_empty() { Space::new() } else {
              let v365_6: Path = concat_path(&(v363_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v365_7: Space = routine_32(c, &(v365_6), &(*p1), &v359_21_cursor);
              compose(&(v364_5),&(v365_7))
            };
            drop(v364_5);
            let v364_9: Space = intersect(&(*CONSTANT_2),&(v364_2));
            drop(v364_2);
            let v364_10: Space = if has_head(&(v364_9)) { singleton(&[]) } else { Space::new() };
            drop(v364_9);
            let v364_12: Space = if (&(v364_10)).is_empty() { Space::new() } else {
              let v366_6: Path = concat_path(&(v363_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v366_11: Space = routine_33(c, &(v366_6), &(*p1), &v359_21_cursor);
              drop(v366_6);
              compose(&(v364_10),&(v366_11))
            };
            drop(v364_10);
            let v364_13: Space = unite(&(v364_8),&(v364_12));
            join_wrapped_into(&mut v363_7_write,&((v364_13).read_zipper()),&[]);
            }
            v359_21_cursor.ascend(1);
          }
          drop(v363_7_write);
          compose(&(v362_5),&(v363_7))
        };
        drop(v362_5);
        let v362_9: Space = intersect(&(*CONSTANT_2),&(v362_2));
        drop(v362_2);
        let v362_10: Space = if has_head(&(v362_9)) { singleton(&[]) } else { Space::new() };
        drop(v362_9);
        let v362_12: Space = if (&(v362_10)).is_empty() { Space::new() } else {
          let v367_6: Path = concat_path(&(v361_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
          let mut v367_11 = Space::new();
          let mut v367_11_write = v367_11.write_zipper();
          for v367_11_byte in v359_21_cursor.child_mask().iter() {
            v359_21_cursor.descend_to_existing_byte(v367_11_byte);
            {
            let v368_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
            let v368_3: Space = intersect(&(*CONSTANT_2),&(v368_2));
            let v368_4: Space = if has_head(&(v368_3)) { singleton(&[]) } else { Space::new() };
            drop(v368_3);
            let v368_5: Space = subtract(&(*CONSTANT_1),&(v368_4));
            drop(v368_4);
            let v368_8: Space = if (&(v368_5)).is_empty() { Space::new() } else {
              let v369_6: Path = concat_path(&(v367_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v369_7: Space = routine_32(c, &(v369_6), &(*p1), &v359_21_cursor);
              compose(&(v368_5),&(v369_7))
            };
            drop(v368_5);
            let v368_9: Space = intersect(&(*CONSTANT_2),&(v368_2));
            drop(v368_2);
            let v368_10: Space = if has_head(&(v368_9)) { singleton(&[]) } else { Space::new() };
            drop(v368_9);
            let v368_12: Space = if (&(v368_10)).is_empty() { Space::new() } else {
              let v370_6: Path = concat_path(&(v367_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v370_11: Space = routine_19(c, &(v370_6), &(*p1), &v359_21_cursor);
              drop(v370_6);
              compose(&(v368_10),&(v370_11))
            };
            drop(v368_10);
            let v368_13: Space = unite(&(v368_8),&(v368_12));
            join_wrapped_into(&mut v367_11_write,&((v368_13).read_zipper()),&[]);
            }
            v359_21_cursor.ascend(1);
          }
          drop(v367_11_write);
          drop(v367_6);
          compose(&(v362_10),&(v367_11))
        };
        drop(v362_10);
        let v362_13: Space = unite(&(v362_8),&(v362_12));
        join_wrapped_into(&mut v361_7_write,&((v362_13).read_zipper()),&[]);
        }
        v359_21_cursor.ascend(1);
      }
      drop(v361_7_write);
      compose(&(v360_5),&(v361_7))
    };
    drop(v360_5);
    let v360_9: Space = intersect(&(*CONSTANT_2),&(v360_2));
    drop(v360_2);
    let v360_10: Space = if has_head(&(v360_9)) { singleton(&[]) } else { Space::new() };
    drop(v360_9);
    let v360_12: Space = if (&(v360_10)).is_empty() { Space::new() } else {
      let v371_6: Path = concat_path(&(*p0),&v359_21_cursor.path()[v359_21_origin..(v359_21_origin + 1)]);
      let mut v371_11 = Space::new();
      let mut v371_11_write = v371_11.write_zipper();
      for v371_11_byte in v359_21_cursor.child_mask().iter() {
        v359_21_cursor.descend_to_existing_byte(v371_11_byte);
        {
        let v372_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
        let v372_3: Space = intersect(&(*CONSTANT_2),&(v372_2));
        let v372_4: Space = if has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
        drop(v372_3);
        let v372_5: Space = subtract(&(*CONSTANT_1),&(v372_4));
        drop(v372_4);
        let v372_8: Space = if (&(v372_5)).is_empty() { Space::new() } else {
          let v373_6: Path = concat_path(&(v371_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
          let mut v373_7 = Space::new();
          let mut v373_7_write = v373_7.write_zipper();
          for v373_7_byte in v359_21_cursor.child_mask().iter() {
            v359_21_cursor.descend_to_existing_byte(v373_7_byte);
            {
            let v374_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
            let v374_3: Space = intersect(&(*CONSTANT_2),&(v374_2));
            let v374_4: Space = if has_head(&(v374_3)) { singleton(&[]) } else { Space::new() };
            drop(v374_3);
            let v374_5: Space = subtract(&(*CONSTANT_1),&(v374_4));
            drop(v374_4);
            let v374_8: Space = if (&(v374_5)).is_empty() { Space::new() } else {
              let v375_6: Path = concat_path(&(v373_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v375_7: Space = routine_32(c, &(v375_6), &(*p1), &v359_21_cursor);
              compose(&(v374_5),&(v375_7))
            };
            drop(v374_5);
            let v374_9: Space = intersect(&(*CONSTANT_2),&(v374_2));
            drop(v374_2);
            let v374_10: Space = if has_head(&(v374_9)) { singleton(&[]) } else { Space::new() };
            drop(v374_9);
            let v374_12: Space = if (&(v374_10)).is_empty() { Space::new() } else {
              let v376_6: Path = concat_path(&(v373_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v376_11: Space = routine_33(c, &(v376_6), &(*p1), &v359_21_cursor);
              drop(v376_6);
              compose(&(v374_10),&(v376_11))
            };
            drop(v374_10);
            let v374_13: Space = unite(&(v374_8),&(v374_12));
            join_wrapped_into(&mut v373_7_write,&((v374_13).read_zipper()),&[]);
            }
            v359_21_cursor.ascend(1);
          }
          drop(v373_7_write);
          compose(&(v372_5),&(v373_7))
        };
        drop(v372_5);
        let v372_9: Space = intersect(&(*CONSTANT_2),&(v372_2));
        drop(v372_2);
        let v372_10: Space = if has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
        drop(v372_9);
        let v372_11: Space = compose(&(v372_10),&v359_21_cursor);
        drop(v372_10);
        let v377_6: Path = concat_path(&(v371_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
        let v372_12: Space = wrap(&(v372_11),&(v377_6));
        drop(v372_11);
        let v372_13: Space = wrap(&(v372_12),&(*p1));
        drop(v372_12);
        let v372_14: Space = unite(&(v372_8),&(v372_13));
        drop(v372_13);
        join_wrapped_into(&mut v371_11_write,&((v372_14).read_zipper()),&[]);
        }
        v359_21_cursor.ascend(1);
      }
      drop(v371_11_write);
      drop(v371_6);
      compose(&(v360_10),&(v371_11))
    };
    drop(v360_10);
    let v360_13: Space = unite(&(v360_8),&(v360_12));
    join_wrapped_into(&mut v359_21_write,&((v360_13).read_zipper()),&[]);
    }
    v359_21_cursor.ascend(1);
  }
  drop(v359_21_cursor);
  drop(v359_21_write);
  (v359_21).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v378_15 = Space::new();
  let mut v378_15_write = v378_15.write_zipper();
  let mut v378_15_cursor = (*s0).read_zipper();
  let v378_15_origin = v378_15_cursor.path().len();
  for v378_15_byte in v378_15_cursor.child_mask().iter() {
    v378_15_cursor.descend_to_existing_byte(v378_15_byte);
    {
    let v379_2: Space = singleton(&v378_15_cursor.path()[v378_15_origin..(v378_15_origin + 1)]);
    let v379_3: Space = intersect(&(*CONSTANT_2),&(v379_2));
    let v379_4: Space = if has_head(&(v379_3)) { singleton(&[]) } else { Space::new() };
    drop(v379_3);
    let v379_5: Space = subtract(&(*CONSTANT_1),&(v379_4));
    drop(v379_4);
    let v379_8: Space = if (&(v379_5)).is_empty() { Space::new() } else {
      let v380_6: Path = concat_path(&(*p0),&v378_15_cursor.path()[v378_15_origin..(v378_15_origin + 1)]);
      let mut v380_7 = Space::new();
      let mut v380_7_write = v380_7.write_zipper();
      for v380_7_byte in v378_15_cursor.child_mask().iter() {
        v378_15_cursor.descend_to_existing_byte(v380_7_byte);
        {
        let v381_2: Space = singleton(&v378_15_cursor.path()[(v378_15_origin + 1)..(v378_15_origin + 2)]);
        let v381_3: Space = intersect(&(*CONSTANT_2),&(v381_2));
        let v381_4: Space = if has_head(&(v381_3)) { singleton(&[]) } else { Space::new() };
        drop(v381_3);
        let v381_5: Space = subtract(&(*CONSTANT_1),&(v381_4));
        drop(v381_4);
        let v381_8: Space = if (&(v381_5)).is_empty() { Space::new() } else {
          let v382_6: Path = concat_path(&(v380_6),&v378_15_cursor.path()[(v378_15_origin + 1)..(v378_15_origin + 2)]);
          let mut v382_7 = Space::new();
          let mut v382_7_write = v382_7.write_zipper();
          for v382_7_byte in v378_15_cursor.child_mask().iter() {
            v378_15_cursor.descend_to_existing_byte(v382_7_byte);
            {
            let v383_2: Space = singleton(&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
            let v383_3: Space = intersect(&(*CONSTANT_2),&(v383_2));
            let v383_4: Space = if has_head(&(v383_3)) { singleton(&[]) } else { Space::new() };
            drop(v383_3);
            let v383_5: Space = subtract(&(*CONSTANT_1),&(v383_4));
            drop(v383_4);
            let v383_8: Space = if (&(v383_5)).is_empty() { Space::new() } else {
              let v384_6: Path = concat_path(&(v382_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v384_7: Space = routine_32(c, &(v384_6), &(*p1), &v378_15_cursor);
              compose(&(v383_5),&(v384_7))
            };
            drop(v383_5);
            let v383_9: Space = intersect(&(*CONSTANT_2),&(v383_2));
            drop(v383_2);
            let v383_10: Space = if has_head(&(v383_9)) { singleton(&[]) } else { Space::new() };
            drop(v383_9);
            let v383_12: Space = if (&(v383_10)).is_empty() { Space::new() } else {
              let v385_6: Path = concat_path(&(v382_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v385_11: Space = routine_33(c, &(v385_6), &(*p1), &v378_15_cursor);
              drop(v385_6);
              compose(&(v383_10),&(v385_11))
            };
            drop(v383_10);
            let v383_13: Space = unite(&(v383_8),&(v383_12));
            join_wrapped_into(&mut v382_7_write,&((v383_13).read_zipper()),&[]);
            }
            v378_15_cursor.ascend(1);
          }
          drop(v382_7_write);
          compose(&(v381_5),&(v382_7))
        };
        drop(v381_5);
        let v381_9: Space = intersect(&(*CONSTANT_2),&(v381_2));
        drop(v381_2);
        let v381_10: Space = if has_head(&(v381_9)) { singleton(&[]) } else { Space::new() };
        drop(v381_9);
        let v381_12: Space = if (&(v381_10)).is_empty() { Space::new() } else {
          let v386_6: Path = concat_path(&(v380_6),&v378_15_cursor.path()[(v378_15_origin + 1)..(v378_15_origin + 2)]);
          let mut v386_11 = Space::new();
          let mut v386_11_write = v386_11.write_zipper();
          for v386_11_byte in v378_15_cursor.child_mask().iter() {
            v378_15_cursor.descend_to_existing_byte(v386_11_byte);
            {
            let v387_2: Space = singleton(&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
            let v387_3: Space = intersect(&(*CONSTANT_2),&(v387_2));
            let v387_4: Space = if has_head(&(v387_3)) { singleton(&[]) } else { Space::new() };
            drop(v387_3);
            let v387_5: Space = subtract(&(*CONSTANT_1),&(v387_4));
            drop(v387_4);
            let v387_8: Space = if (&(v387_5)).is_empty() { Space::new() } else {
              let v388_6: Path = concat_path(&(v386_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v388_7: Space = routine_32(c, &(v388_6), &(*p1), &v378_15_cursor);
              compose(&(v387_5),&(v388_7))
            };
            drop(v387_5);
            let v387_9: Space = intersect(&(*CONSTANT_2),&(v387_2));
            drop(v387_2);
            let v387_10: Space = if has_head(&(v387_9)) { singleton(&[]) } else { Space::new() };
            drop(v387_9);
            let v387_12: Space = if (&(v387_10)).is_empty() { Space::new() } else {
              let v389_6: Path = concat_path(&(v386_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v389_11: Space = routine_19(c, &(v389_6), &(*p1), &v378_15_cursor);
              drop(v389_6);
              compose(&(v387_10),&(v389_11))
            };
            drop(v387_10);
            let v387_13: Space = unite(&(v387_8),&(v387_12));
            join_wrapped_into(&mut v386_11_write,&((v387_13).read_zipper()),&[]);
            }
            v378_15_cursor.ascend(1);
          }
          drop(v386_11_write);
          drop(v386_6);
          compose(&(v381_10),&(v386_11))
        };
        drop(v381_10);
        let v381_13: Space = unite(&(v381_8),&(v381_12));
        join_wrapped_into(&mut v380_7_write,&((v381_13).read_zipper()),&[]);
        }
        v378_15_cursor.ascend(1);
      }
      drop(v380_7_write);
      compose(&(v379_5),&(v380_7))
    };
    drop(v379_5);
    let v379_9: Space = intersect(&(*CONSTANT_2),&(v379_2));
    drop(v379_2);
    let v379_10: Space = if has_head(&(v379_9)) { singleton(&[]) } else { Space::new() };
    drop(v379_9);
    let v379_11: Space = compose(&(v379_10),&v378_15_cursor);
    drop(v379_10);
    let v390_6: Path = concat_path(&(*p0),&v378_15_cursor.path()[v378_15_origin..(v378_15_origin + 1)]);
    let v379_12: Space = wrap(&(v379_11),&(v390_6));
    drop(v379_11);
    let v379_13: Space = wrap(&(v379_12),&(*p1));
    drop(v379_12);
    let v379_14: Space = unite(&(v379_8),&(v379_13));
    drop(v379_13);
    join_wrapped_into(&mut v378_15_write,&((v379_14).read_zipper()),&[]);
    }
    v378_15_cursor.ascend(1);
  }
  drop(v378_15_cursor);
  drop(v378_15_write);
  (v378_15).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v391_3: Space = wrap(&(*s0),&(*p0));
  let v391_4: Space = wrap(&(v391_3),&(*p1));
  drop(v391_3);
  (v391_4).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v392_8 = Space::new();
  let mut v392_8_write = v392_8.write_zipper();
  let mut v392_8_cursor = (*s0).read_zipper();
  let v392_8_origin = v392_8_cursor.path().len();
  for v392_8_byte in v392_8_cursor.child_mask().iter() {
    v392_8_cursor.descend_to_existing_byte(v392_8_byte);
    {
    let v393_2: Space = singleton(&v392_8_cursor.path()[v392_8_origin..(v392_8_origin + 1)]);
    let v393_3: Space = intersect(&(*CONSTANT_2),&(v393_2));
    drop(v393_2);
    let v393_4: Space = if has_head(&(v393_3)) { singleton(&[]) } else { Space::new() };
    drop(v393_3);
    let v393_7: Space = if (&(v393_4)).is_empty() { Space::new() } else {
      let v394_5: Path = concat_path(&(*p0),&v392_8_cursor.path()[v392_8_origin..(v392_8_origin + 1)]);
      let mut v394_6 = Space::new();
      let mut v394_6_write = v394_6.write_zipper();
      for v394_6_byte in v392_8_cursor.child_mask().iter() {
        v392_8_cursor.descend_to_existing_byte(v394_6_byte);
        {
        let v395_2: Space = singleton(&v392_8_cursor.path()[(v392_8_origin + 1)..(v392_8_origin + 2)]);
        let v395_3: Space = intersect(&(*CONSTANT_2),&(v395_2));
        drop(v395_2);
        let v395_4: Space = if has_head(&(v395_3)) { singleton(&[]) } else { Space::new() };
        drop(v395_3);
        let v395_7: Space = if (&(v395_4)).is_empty() { Space::new() } else {
          let v396_5: Path = concat_path(&(v394_5),&v392_8_cursor.path()[(v392_8_origin + 1)..(v392_8_origin + 2)]);
          let mut v396_6 = Space::new();
          let mut v396_6_write = v396_6.write_zipper();
          for v396_6_byte in v392_8_cursor.child_mask().iter() {
            v392_8_cursor.descend_to_existing_byte(v396_6_byte);
            {
            let v397_2: Space = singleton(&v392_8_cursor.path()[(v392_8_origin + 2)..(v392_8_origin + 3)]);
            let v397_3: Space = intersect(&(*CONSTANT_2),&(v397_2));
            let v397_4: Space = if has_head(&(v397_3)) { singleton(&[]) } else { Space::new() };
            drop(v397_3);
            let v397_5: Space = subtract(&(*CONSTANT_1),&(v397_4));
            drop(v397_4);
            let v397_7: Space = if (&(v397_5)).is_empty() { Space::new() } else {
              let v398_6: Space = routine_4(c, &v392_8_cursor.path()[(v392_8_origin + 2)..(v392_8_origin + 3)], &(v396_5), &v392_8_cursor, &(*s1));
              compose(&(v397_5),&(v398_6))
            };
            drop(v397_5);
            let v397_8: Space = intersect(&(*CONSTANT_2),&(v397_2));
            drop(v397_2);
            let v397_9: Space = if has_head(&(v397_8)) { singleton(&[]) } else { Space::new() };
            drop(v397_8);
            let v397_11: Space = if (&(v397_9)).is_empty() { Space::new() } else {
              let v399_10: Space = routine_5(c, &v392_8_cursor.path()[(v392_8_origin + 2)..(v392_8_origin + 3)], &(v396_5), &v392_8_cursor, &(*s1));
              compose(&(v397_9),&(v399_10))
            };
            drop(v397_9);
            let v397_12: Space = unite(&(v397_7),&(v397_11));
            join_wrapped_into(&mut v396_6_write,&((v397_12).read_zipper()),&[]);
            }
            v392_8_cursor.ascend(1);
          }
          drop(v396_6_write);
          drop(v396_5);
          compose(&(v395_4),&(v396_6))
        };
        drop(v395_4);
        join_wrapped_into(&mut v394_6_write,&((v395_7).read_zipper()),&[]);
        }
        v392_8_cursor.ascend(1);
      }
      drop(v394_6_write);
      drop(v394_5);
      compose(&(v393_4),&(v394_6))
    };
    drop(v393_4);
    join_wrapped_into(&mut v392_8_write,&((v393_7).read_zipper()),&[]);
    }
    v392_8_cursor.ascend(1);
  }
  drop(v392_8_cursor);
  drop(v392_8_write);
  (v392_8).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v400_13 = Space::new();
  let mut v400_13_write = v400_13.write_zipper();
  let mut v400_13_cursor = (*s0).read_zipper();
  let v400_13_origin = v400_13_cursor.path().len();
  for v400_13_byte in v400_13_cursor.child_mask().iter() {
    v400_13_cursor.descend_to_existing_byte(v400_13_byte);
    {
    let v401_2: Space = singleton(&v400_13_cursor.path()[v400_13_origin..(v400_13_origin + 1)]);
    let v401_3: Space = intersect(&(*CONSTANT_2),&(v401_2));
    drop(v401_2);
    let v401_4: Space = if has_head(&(v401_3)) { singleton(&[]) } else { Space::new() };
    drop(v401_3);
    let v401_7: Space = if (&(v401_4)).is_empty() { Space::new() } else {
      let v402_5: Path = concat_path(&(*p0),&v400_13_cursor.path()[v400_13_origin..(v400_13_origin + 1)]);
      let mut v402_6 = Space::new();
      let mut v402_6_write = v402_6.write_zipper();
      for v402_6_byte in v400_13_cursor.child_mask().iter() {
        v400_13_cursor.descend_to_existing_byte(v402_6_byte);
        {
        let v403_2: Space = singleton(&v400_13_cursor.path()[(v400_13_origin + 1)..(v400_13_origin + 2)]);
        let v403_3: Space = intersect(&(*CONSTANT_2),&(v403_2));
        let v403_4: Space = if has_head(&(v403_3)) { singleton(&[]) } else { Space::new() };
        drop(v403_3);
        let v403_5: Space = subtract(&(*CONSTANT_1),&(v403_4));
        drop(v403_4);
        let v403_7: Space = if (&(v403_5)).is_empty() { Space::new() } else {
          let mut v404_6 = Space::new();
          let mut v404_6_write = v404_6.write_zipper();
          for v404_6_byte in v400_13_cursor.child_mask().iter() {
            v400_13_cursor.descend_to_existing_byte(v404_6_byte);
            {
            let v405_2: Space = singleton(&v400_13_cursor.path()[(v400_13_origin + 2)..(v400_13_origin + 3)]);
            let v405_3: Space = intersect(&(*CONSTANT_2),&(v405_2));
            let v405_4: Space = if has_head(&(v405_3)) { singleton(&[]) } else { Space::new() };
            drop(v405_3);
            let v405_5: Space = subtract(&(*CONSTANT_1),&(v405_4));
            drop(v405_4);
            let v405_8: Space = if (&(v405_5)).is_empty() { Space::new() } else {
              let v406_7: Space = routine_8(c, &v400_13_cursor.path()[(v400_13_origin + 1)..(v400_13_origin + 3)], &(v402_5), &v400_13_cursor, &(*s1));
              compose(&(v405_5),&(v406_7))
            };
            drop(v405_5);
            let v405_9: Space = intersect(&(*CONSTANT_2),&(v405_2));
            drop(v405_2);
            let v405_10: Space = if has_head(&(v405_9)) { singleton(&[]) } else { Space::new() };
            drop(v405_9);
            let v405_12: Space = if (&(v405_10)).is_empty() { Space::new() } else {
              let v407_11: Space = routine_9(c, &v400_13_cursor.path()[(v400_13_origin + 1)..(v400_13_origin + 3)], &(v402_5), &v400_13_cursor, &(*s1));
              compose(&(v405_10),&(v407_11))
            };
            drop(v405_10);
            let v405_13: Space = unite(&(v405_8),&(v405_12));
            join_wrapped_into(&mut v404_6_write,&((v405_13).read_zipper()),&[]);
            }
            v400_13_cursor.ascend(1);
          }
          drop(v404_6_write);
          compose(&(v403_5),&(v404_6))
        };
        drop(v403_5);
        let v403_8: Space = intersect(&(*CONSTANT_2),&(v403_2));
        drop(v403_2);
        let v403_9: Space = if has_head(&(v403_8)) { singleton(&[]) } else { Space::new() };
        drop(v403_8);
        let v403_11: Space = if (&(v403_9)).is_empty() { Space::new() } else {
          let mut v408_10 = Space::new();
          let mut v408_10_write = v408_10.write_zipper();
          for v408_10_byte in v400_13_cursor.child_mask().iter() {
            v400_13_cursor.descend_to_existing_byte(v408_10_byte);
            {
            let v409_2: Space = singleton(&v400_13_cursor.path()[(v400_13_origin + 2)..(v400_13_origin + 3)]);
            let v409_3: Space = intersect(&(*CONSTANT_2),&(v409_2));
            let v409_4: Space = if has_head(&(v409_3)) { singleton(&[]) } else { Space::new() };
            drop(v409_3);
            let v409_5: Space = subtract(&(*CONSTANT_1),&(v409_4));
            drop(v409_4);
            let v409_8: Space = if (&(v409_5)).is_empty() { Space::new() } else {
              let v410_7: Space = routine_8(c, &v400_13_cursor.path()[(v400_13_origin + 1)..(v400_13_origin + 3)], &(v402_5), &v400_13_cursor, &(*s1));
              compose(&(v409_5),&(v410_7))
            };
            drop(v409_5);
            let v409_9: Space = intersect(&(*CONSTANT_2),&(v409_2));
            drop(v409_2);
            let v409_10: Space = if has_head(&(v409_9)) { singleton(&[]) } else { Space::new() };
            drop(v409_9);
            let v409_12: Space = if (&(v409_10)).is_empty() { Space::new() } else {
              let v411_11: Space = routine_10(c, &v400_13_cursor.path()[(v400_13_origin + 1)..(v400_13_origin + 3)], &(v402_5), &v400_13_cursor, &(*s1));
              compose(&(v409_10),&(v411_11))
            };
            drop(v409_10);
            let v409_13: Space = unite(&(v409_8),&(v409_12));
            join_wrapped_into(&mut v408_10_write,&((v409_13).read_zipper()),&[]);
            }
            v400_13_cursor.ascend(1);
          }
          drop(v408_10_write);
          compose(&(v403_9),&(v408_10))
        };
        drop(v403_9);
        let v403_12: Space = unite(&(v403_7),&(v403_11));
        join_wrapped_into(&mut v402_6_write,&((v403_12).read_zipper()),&[]);
        }
        v400_13_cursor.ascend(1);
      }
      drop(v402_6_write);
      drop(v402_5);
      compose(&(v401_4),&(v402_6))
    };
    drop(v401_4);
    join_wrapped_into(&mut v400_13_write,&((v401_7).read_zipper()),&[]);
    }
    v400_13_cursor.ascend(1);
  }
  drop(v400_13_cursor);
  drop(v400_13_write);
  (v400_13).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v412_28 = Space::new();
  let mut v412_28_write = v412_28.write_zipper();
  let mut v412_28_cursor = (*s0).read_zipper();
  let v412_28_origin = v412_28_cursor.path().len();
  for v412_28_byte in v412_28_cursor.child_mask().iter() {
    v412_28_cursor.descend_to_existing_byte(v412_28_byte);
    {
    let v413_2: Space = singleton(&v412_28_cursor.path()[v412_28_origin..(v412_28_origin + 1)]);
    let v413_3: Space = intersect(&(*CONSTANT_2),&(v413_2));
    let v413_4: Space = if has_head(&(v413_3)) { singleton(&[]) } else { Space::new() };
    drop(v413_3);
    let v413_5: Space = subtract(&(*CONSTANT_1),&(v413_4));
    drop(v413_4);
    let v413_8: Space = if (&(v413_5)).is_empty() { Space::new() } else {
      let v414_6: Path = concat_path(&(*p0),&v412_28_cursor.path()[v412_28_origin..(v412_28_origin + 1)]);
      let mut v414_7 = Space::new();
      let mut v414_7_write = v414_7.write_zipper();
      for v414_7_byte in v412_28_cursor.child_mask().iter() {
        v412_28_cursor.descend_to_existing_byte(v414_7_byte);
        {
        let v415_2: Space = singleton(&v412_28_cursor.path()[(v412_28_origin + 1)..(v412_28_origin + 2)]);
        let v415_3: Space = intersect(&(*CONSTANT_2),&(v415_2));
        let v415_4: Space = if has_head(&(v415_3)) { singleton(&[]) } else { Space::new() };
        drop(v415_3);
        let v415_5: Space = subtract(&(*CONSTANT_1),&(v415_4));
        drop(v415_4);
        let v415_8: Space = if (&(v415_5)).is_empty() { Space::new() } else {
          let v416_6: Path = concat_path(&(v414_6),&v412_28_cursor.path()[(v412_28_origin + 1)..(v412_28_origin + 2)]);
          let mut v416_7 = Space::new();
          let mut v416_7_write = v416_7.write_zipper();
          for v416_7_byte in v412_28_cursor.child_mask().iter() {
            v412_28_cursor.descend_to_existing_byte(v416_7_byte);
            {
            let v417_2: Space = singleton(&v412_28_cursor.path()[(v412_28_origin + 2)..(v412_28_origin + 3)]);
            let v417_3: Space = intersect(&(*CONSTANT_2),&(v417_2));
            let v417_4: Space = if has_head(&(v417_3)) { singleton(&[]) } else { Space::new() };
            drop(v417_3);
            let v417_5: Space = subtract(&(*CONSTANT_1),&(v417_4));
            drop(v417_4);
            let v417_8: Space = if (&(v417_5)).is_empty() { Space::new() } else {
              let v418_6: Path = concat_path(&(v416_6),&v412_28_cursor.path()[(v412_28_origin + 2)..(v412_28_origin + 3)]);
              let v418_7: Space = routine_34(c, &(v418_6), &(*p1), &v412_28_cursor, &(*s1));
              compose(&(v417_5),&(v418_7))
            };
            drop(v417_5);
            let v417_9: Space = intersect(&(*CONSTANT_2),&(v417_2));
            drop(v417_2);
            let v417_10: Space = if has_head(&(v417_9)) { singleton(&[]) } else { Space::new() };
            drop(v417_9);
            let v417_12: Space = if (&(v417_10)).is_empty() { Space::new() } else {
              let v419_6: Path = concat_path(&(v416_6),&v412_28_cursor.path()[(v412_28_origin + 2)..(v412_28_origin + 3)]);
              let v419_11: Space = routine_35(c, &(v419_6), &(*p1), &v412_28_cursor, &(*s1));
              drop(v419_6);
              compose(&(v417_10),&(v419_11))
            };
            drop(v417_10);
            let v417_13: Space = unite(&(v417_8),&(v417_12));
            join_wrapped_into(&mut v416_7_write,&((v417_13).read_zipper()),&[]);
            }
            v412_28_cursor.ascend(1);
          }
          drop(v416_7_write);
          compose(&(v415_5),&(v416_7))
        };
        drop(v415_5);
        let v415_9: Space = intersect(&(*CONSTANT_2),&(v415_2));
        drop(v415_2);
        let v415_10: Space = if has_head(&(v415_9)) { singleton(&[]) } else { Space::new() };
        drop(v415_9);
        let v415_12: Space = if (&(v415_10)).is_empty() { Space::new() } else {
          let v420_6: Path = concat_path(&(v414_6),&v412_28_cursor.path()[(v412_28_origin + 1)..(v412_28_origin + 2)]);
          let mut v420_11 = Space::new();
          let mut v420_11_write = v420_11.write_zipper();
          for v420_11_byte in v412_28_cursor.child_mask().iter() {
            v412_28_cursor.descend_to_existing_byte(v420_11_byte);
            {
            let v421_2: Space = singleton(&v412_28_cursor.path()[(v412_28_origin + 2)..(v412_28_origin + 3)]);
            let v421_3: Space = intersect(&(*CONSTANT_2),&(v421_2));
            let v421_4: Space = if has_head(&(v421_3)) { singleton(&[]) } else { Space::new() };
            drop(v421_3);
            let v421_5: Space = subtract(&(*CONSTANT_1),&(v421_4));
            drop(v421_4);
            let v421_8: Space = if (&(v421_5)).is_empty() { Space::new() } else {
              let v422_6: Path = concat_path(&(v420_6),&v412_28_cursor.path()[(v412_28_origin + 2)..(v412_28_origin + 3)]);
              let v422_7: Space = routine_34(c, &(v422_6), &(*p1), &v412_28_cursor, &(*s1));
              compose(&(v421_5),&(v422_7))
            };
            drop(v421_5);
            let v421_9: Space = intersect(&(*CONSTANT_2),&(v421_2));
            drop(v421_2);
            let v421_10: Space = if has_head(&(v421_9)) { singleton(&[]) } else { Space::new() };
            drop(v421_9);
            let v421_12: Space = if (&(v421_10)).is_empty() { Space::new() } else {
              let v423_6: Path = concat_path(&(v420_6),&v412_28_cursor.path()[(v412_28_origin + 2)..(v412_28_origin + 3)]);
              let v423_11: Space = routine_10(c, &(v423_6), &(*p1), &v412_28_cursor, &(*s1));
              drop(v423_6);
              compose(&(v421_10),&(v423_11))
            };
            drop(v421_10);
            let v421_13: Space = unite(&(v421_8),&(v421_12));
            join_wrapped_into(&mut v420_11_write,&((v421_13).read_zipper()),&[]);
            }
            v412_28_cursor.ascend(1);
          }
          drop(v420_11_write);
          drop(v420_6);
          compose(&(v415_10),&(v420_11))
        };
        drop(v415_10);
        let v415_13: Space = unite(&(v415_8),&(v415_12));
        join_wrapped_into(&mut v414_7_write,&((v415_13).read_zipper()),&[]);
        }
        v412_28_cursor.ascend(1);
      }
      drop(v414_7_write);
      compose(&(v413_5),&(v414_7))
    };
    drop(v413_5);
    let v413_9: Space = intersect(&(*CONSTANT_2),&(v413_2));
    drop(v413_2);
    let v413_10: Space = if has_head(&(v413_9)) { singleton(&[]) } else { Space::new() };
    drop(v413_9);
    let v413_13: Space = if (&(v413_10)).is_empty() { Space::new() } else {
      let v424_6: Path = concat_path(&(*p0),&v412_28_cursor.path()[v412_28_origin..(v412_28_origin + 1)]);
      let mut v424_12 = Space::new();
      let mut v424_12_write = v424_12.write_zipper();
      for v424_12_byte in v412_28_cursor.child_mask().iter() {
        v412_28_cursor.descend_to_existing_byte(v424_12_byte);
        {
        let v425_2: Space = singleton(&v412_28_cursor.path()[(v412_28_origin + 1)..(v412_28_origin + 2)]);
        let v425_3: Space = intersect(&(*CONSTANT_2),&(v425_2));
        let v425_4: Space = if has_head(&(v425_3)) { singleton(&[]) } else { Space::new() };
        drop(v425_3);
        let v425_5: Space = subtract(&(*CONSTANT_1),&(v425_4));
        drop(v425_4);
        let v425_8: Space = if (&(v425_5)).is_empty() { Space::new() } else {
          let v426_6: Path = concat_path(&(v424_6),&v412_28_cursor.path()[(v412_28_origin + 1)..(v412_28_origin + 2)]);
          let mut v426_7 = Space::new();
          let mut v426_7_write = v426_7.write_zipper();
          for v426_7_byte in v412_28_cursor.child_mask().iter() {
            v412_28_cursor.descend_to_existing_byte(v426_7_byte);
            {
            let v427_2: Space = singleton(&v412_28_cursor.path()[(v412_28_origin + 2)..(v412_28_origin + 3)]);
            let v427_3: Space = intersect(&(*CONSTANT_2),&(v427_2));
            let v427_4: Space = if has_head(&(v427_3)) { singleton(&[]) } else { Space::new() };
            drop(v427_3);
            let v427_5: Space = subtract(&(*CONSTANT_1),&(v427_4));
            drop(v427_4);
            let v427_8: Space = if (&(v427_5)).is_empty() { Space::new() } else {
              let v428_6: Path = concat_path(&(v426_6),&v412_28_cursor.path()[(v412_28_origin + 2)..(v412_28_origin + 3)]);
              let v428_7: Space = routine_34(c, &(v428_6), &(*p1), &v412_28_cursor, &(*s1));
              compose(&(v427_5),&(v428_7))
            };
            drop(v427_5);
            let v427_9: Space = intersect(&(*CONSTANT_2),&(v427_2));
            drop(v427_2);
            let v427_10: Space = if has_head(&(v427_9)) { singleton(&[]) } else { Space::new() };
            drop(v427_9);
            let v427_12: Space = if (&(v427_10)).is_empty() { Space::new() } else {
              let v429_6: Path = concat_path(&(v426_6),&v412_28_cursor.path()[(v412_28_origin + 2)..(v412_28_origin + 3)]);
              let v429_11: Space = routine_35(c, &(v429_6), &(*p1), &v412_28_cursor, &(*s1));
              drop(v429_6);
              compose(&(v427_10),&(v429_11))
            };
            drop(v427_10);
            let v427_13: Space = unite(&(v427_8),&(v427_12));
            join_wrapped_into(&mut v426_7_write,&((v427_13).read_zipper()),&[]);
            }
            v412_28_cursor.ascend(1);
          }
          drop(v426_7_write);
          drop(v426_6);
          compose(&(v425_5),&(v426_7))
        };
        drop(v425_5);
        let v425_9: Space = intersect(&(*CONSTANT_2),&(v425_2));
        drop(v425_2);
        let v425_10: Space = if has_head(&(v425_9)) { singleton(&[]) } else { Space::new() };
        drop(v425_9);
        let v425_13: Space = if (&(v425_10)).is_empty() { Space::new() } else {
          let mut v430_12 = Space::new();
          let mut v430_12_write = v430_12.write_zipper();
          let mut v430_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v412_28_cursor.path()[v412_28_origin..(v412_28_origin + 1)]),&v412_28_cursor.path()[(v412_28_origin + 1)..(v412_28_origin + 2)]);
          let v430_12_origin = v430_12_cursor.path().len();
          for v430_12_byte in v430_12_cursor.child_mask().iter() {
            v430_12_cursor.descend_to_existing_byte(v430_12_byte);
            {
            let v431_2: Space = singleton(&v430_12_cursor.path()[v430_12_origin..(v430_12_origin + 1)]);
            let v431_3: Space = intersect(&(*CONSTANT_2),&(v431_2));
            let v431_4: Space = if has_head(&(v431_3)) { singleton(&[]) } else { Space::new() };
            drop(v431_3);
            let v431_5: Space = subtract(&(*CONSTANT_1),&(v431_4));
            drop(v431_4);
            let v431_7: Space = if (&(v431_5)).is_empty() { Space::new() } else {
              let v432_6: Space = routine_13(c, &v430_12_cursor.path()[v430_12_origin..(v430_12_origin + 1)], &(*p1), &v430_12_cursor);
              compose(&(v431_5),&(v432_6))
            };
            drop(v431_5);
            let v431_8: Space = intersect(&(*CONSTANT_2),&(v431_2));
            drop(v431_2);
            let v431_9: Space = if has_head(&(v431_8)) { singleton(&[]) } else { Space::new() };
            drop(v431_8);
            let v431_11: Space = if (&(v431_9)).is_empty() { Space::new() } else {
              let v433_10: Space = routine_14(c, &v430_12_cursor.path()[v430_12_origin..(v430_12_origin + 1)], &(*p1), &v430_12_cursor);
              compose(&(v431_9),&(v433_10))
            };
            drop(v431_9);
            let v431_12: Space = unite(&(v431_7),&(v431_11));
            join_wrapped_into(&mut v430_12_write,&((v431_12).read_zipper()),&[]);
            }
            v430_12_cursor.ascend(1);
          }
          drop(v430_12_cursor);
          drop(v430_12_write);
          compose(&(v425_10),&(v430_12))
        };
        drop(v425_10);
        let v425_14: Space = unite(&(v425_8),&(v425_13));
        join_wrapped_into(&mut v424_12_write,&((v425_14).read_zipper()),&[]);
        }
        v412_28_cursor.ascend(1);
      }
      drop(v424_12_write);
      drop(v424_6);
      compose(&(v413_10),&(v424_12))
    };
    drop(v413_10);
    let v413_14: Space = unite(&(v413_8),&(v413_13));
    join_wrapped_into(&mut v412_28_write,&((v413_14).read_zipper()),&[]);
    }
    v412_28_cursor.ascend(1);
  }
  drop(v412_28_cursor);
  drop(v412_28_write);
  (v412_28).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v434_28 = Space::new();
  let mut v434_28_write = v434_28.write_zipper();
  let mut v434_28_cursor = (*s0).read_zipper();
  let v434_28_origin = v434_28_cursor.path().len();
  for v434_28_byte in v434_28_cursor.child_mask().iter() {
    v434_28_cursor.descend_to_existing_byte(v434_28_byte);
    {
    let v435_2: Space = singleton(&v434_28_cursor.path()[v434_28_origin..(v434_28_origin + 1)]);
    let v435_3: Space = intersect(&(*CONSTANT_2),&(v435_2));
    let v435_4: Space = if has_head(&(v435_3)) { singleton(&[]) } else { Space::new() };
    drop(v435_3);
    let v435_5: Space = subtract(&(*CONSTANT_1),&(v435_4));
    drop(v435_4);
    let v435_8: Space = if (&(v435_5)).is_empty() { Space::new() } else {
      let v436_6: Path = concat_path(&(*p0),&v434_28_cursor.path()[v434_28_origin..(v434_28_origin + 1)]);
      let mut v436_7 = Space::new();
      let mut v436_7_write = v436_7.write_zipper();
      for v436_7_byte in v434_28_cursor.child_mask().iter() {
        v434_28_cursor.descend_to_existing_byte(v436_7_byte);
        {
        let v437_2: Space = singleton(&v434_28_cursor.path()[(v434_28_origin + 1)..(v434_28_origin + 2)]);
        let v437_3: Space = intersect(&(*CONSTANT_2),&(v437_2));
        let v437_4: Space = if has_head(&(v437_3)) { singleton(&[]) } else { Space::new() };
        drop(v437_3);
        let v437_5: Space = subtract(&(*CONSTANT_1),&(v437_4));
        drop(v437_4);
        let v437_8: Space = if (&(v437_5)).is_empty() { Space::new() } else {
          let v438_6: Path = concat_path(&(v436_6),&v434_28_cursor.path()[(v434_28_origin + 1)..(v434_28_origin + 2)]);
          let mut v438_7 = Space::new();
          let mut v438_7_write = v438_7.write_zipper();
          for v438_7_byte in v434_28_cursor.child_mask().iter() {
            v434_28_cursor.descend_to_existing_byte(v438_7_byte);
            {
            let v439_2: Space = singleton(&v434_28_cursor.path()[(v434_28_origin + 2)..(v434_28_origin + 3)]);
            let v439_3: Space = intersect(&(*CONSTANT_2),&(v439_2));
            let v439_4: Space = if has_head(&(v439_3)) { singleton(&[]) } else { Space::new() };
            drop(v439_3);
            let v439_5: Space = subtract(&(*CONSTANT_1),&(v439_4));
            drop(v439_4);
            let v439_8: Space = if (&(v439_5)).is_empty() { Space::new() } else {
              let v440_6: Path = concat_path(&(v438_6),&v434_28_cursor.path()[(v434_28_origin + 2)..(v434_28_origin + 3)]);
              let v440_7: Space = routine_34(c, &(v440_6), &(*p1), &v434_28_cursor, &(*s1));
              compose(&(v439_5),&(v440_7))
            };
            drop(v439_5);
            let v439_9: Space = intersect(&(*CONSTANT_2),&(v439_2));
            drop(v439_2);
            let v439_10: Space = if has_head(&(v439_9)) { singleton(&[]) } else { Space::new() };
            drop(v439_9);
            let v439_12: Space = if (&(v439_10)).is_empty() { Space::new() } else {
              let v441_6: Path = concat_path(&(v438_6),&v434_28_cursor.path()[(v434_28_origin + 2)..(v434_28_origin + 3)]);
              let v441_11: Space = routine_35(c, &(v441_6), &(*p1), &v434_28_cursor, &(*s1));
              drop(v441_6);
              compose(&(v439_10),&(v441_11))
            };
            drop(v439_10);
            let v439_13: Space = unite(&(v439_8),&(v439_12));
            join_wrapped_into(&mut v438_7_write,&((v439_13).read_zipper()),&[]);
            }
            v434_28_cursor.ascend(1);
          }
          drop(v438_7_write);
          compose(&(v437_5),&(v438_7))
        };
        drop(v437_5);
        let v437_9: Space = intersect(&(*CONSTANT_2),&(v437_2));
        drop(v437_2);
        let v437_10: Space = if has_head(&(v437_9)) { singleton(&[]) } else { Space::new() };
        drop(v437_9);
        let v437_12: Space = if (&(v437_10)).is_empty() { Space::new() } else {
          let v442_6: Path = concat_path(&(v436_6),&v434_28_cursor.path()[(v434_28_origin + 1)..(v434_28_origin + 2)]);
          let mut v442_11 = Space::new();
          let mut v442_11_write = v442_11.write_zipper();
          for v442_11_byte in v434_28_cursor.child_mask().iter() {
            v434_28_cursor.descend_to_existing_byte(v442_11_byte);
            {
            let v443_2: Space = singleton(&v434_28_cursor.path()[(v434_28_origin + 2)..(v434_28_origin + 3)]);
            let v443_3: Space = intersect(&(*CONSTANT_2),&(v443_2));
            let v443_4: Space = if has_head(&(v443_3)) { singleton(&[]) } else { Space::new() };
            drop(v443_3);
            let v443_5: Space = subtract(&(*CONSTANT_1),&(v443_4));
            drop(v443_4);
            let v443_8: Space = if (&(v443_5)).is_empty() { Space::new() } else {
              let v444_6: Path = concat_path(&(v442_6),&v434_28_cursor.path()[(v434_28_origin + 2)..(v434_28_origin + 3)]);
              let v444_7: Space = routine_34(c, &(v444_6), &(*p1), &v434_28_cursor, &(*s1));
              compose(&(v443_5),&(v444_7))
            };
            drop(v443_5);
            let v443_9: Space = intersect(&(*CONSTANT_2),&(v443_2));
            drop(v443_2);
            let v443_10: Space = if has_head(&(v443_9)) { singleton(&[]) } else { Space::new() };
            drop(v443_9);
            let v443_12: Space = if (&(v443_10)).is_empty() { Space::new() } else {
              let v445_6: Path = concat_path(&(v442_6),&v434_28_cursor.path()[(v434_28_origin + 2)..(v434_28_origin + 3)]);
              let v445_11: Space = routine_10(c, &(v445_6), &(*p1), &v434_28_cursor, &(*s1));
              drop(v445_6);
              compose(&(v443_10),&(v445_11))
            };
            drop(v443_10);
            let v443_13: Space = unite(&(v443_8),&(v443_12));
            join_wrapped_into(&mut v442_11_write,&((v443_13).read_zipper()),&[]);
            }
            v434_28_cursor.ascend(1);
          }
          drop(v442_11_write);
          drop(v442_6);
          compose(&(v437_10),&(v442_11))
        };
        drop(v437_10);
        let v437_13: Space = unite(&(v437_8),&(v437_12));
        join_wrapped_into(&mut v436_7_write,&((v437_13).read_zipper()),&[]);
        }
        v434_28_cursor.ascend(1);
      }
      drop(v436_7_write);
      drop(v436_6);
      compose(&(v435_5),&(v436_7))
    };
    drop(v435_5);
    let v435_9: Space = intersect(&(*CONSTANT_2),&(v435_2));
    drop(v435_2);
    let v435_10: Space = if has_head(&(v435_9)) { singleton(&[]) } else { Space::new() };
    drop(v435_9);
    let v435_13: Space = if (&(v435_10)).is_empty() { Space::new() } else {
      let mut v446_12 = Space::new();
      let mut v446_12_write = v446_12.write_zipper();
      let mut v446_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v434_28_cursor.path()[v434_28_origin..(v434_28_origin + 1)]);
      let v446_12_origin = v446_12_cursor.path().len();
      for v446_12_byte in v446_12_cursor.child_mask().iter() {
        v446_12_cursor.descend_to_existing_byte(v446_12_byte);
        {
        let v447_2: Space = singleton(&v446_12_cursor.path()[v446_12_origin..(v446_12_origin + 1)]);
        let v447_3: Space = intersect(&(*CONSTANT_2),&(v447_2));
        let v447_4: Space = if has_head(&(v447_3)) { singleton(&[]) } else { Space::new() };
        drop(v447_3);
        let v447_5: Space = subtract(&(*CONSTANT_1),&(v447_4));
        drop(v447_4);
        let v447_7: Space = if (&(v447_5)).is_empty() { Space::new() } else {
          let mut v448_6 = Space::new();
          let mut v448_6_write = v448_6.write_zipper();
          for v448_6_byte in v446_12_cursor.child_mask().iter() {
            v446_12_cursor.descend_to_existing_byte(v448_6_byte);
            {
            let v449_2: Space = singleton(&v446_12_cursor.path()[(v446_12_origin + 1)..(v446_12_origin + 2)]);
            let v449_3: Space = intersect(&(*CONSTANT_2),&(v449_2));
            let v449_4: Space = if has_head(&(v449_3)) { singleton(&[]) } else { Space::new() };
            drop(v449_3);
            let v449_5: Space = subtract(&(*CONSTANT_1),&(v449_4));
            drop(v449_4);
            let v449_8: Space = if (&(v449_5)).is_empty() { Space::new() } else {
              let v450_7: Space = routine_17(c, &v446_12_cursor.path()[v446_12_origin..(v446_12_origin + 2)], &(*p1), &v446_12_cursor);
              compose(&(v449_5),&(v450_7))
            };
            drop(v449_5);
            let v449_9: Space = intersect(&(*CONSTANT_2),&(v449_2));
            drop(v449_2);
            let v449_10: Space = if has_head(&(v449_9)) { singleton(&[]) } else { Space::new() };
            drop(v449_9);
            let v449_12: Space = if (&(v449_10)).is_empty() { Space::new() } else {
              let v451_11: Space = routine_18(c, &v446_12_cursor.path()[v446_12_origin..(v446_12_origin + 2)], &(*p1), &v446_12_cursor);
              compose(&(v449_10),&(v451_11))
            };
            drop(v449_10);
            let v449_13: Space = unite(&(v449_8),&(v449_12));
            join_wrapped_into(&mut v448_6_write,&((v449_13).read_zipper()),&[]);
            }
            v446_12_cursor.ascend(1);
          }
          drop(v448_6_write);
          compose(&(v447_5),&(v448_6))
        };
        drop(v447_5);
        let v447_8: Space = intersect(&(*CONSTANT_2),&(v447_2));
        drop(v447_2);
        let v447_9: Space = if has_head(&(v447_8)) { singleton(&[]) } else { Space::new() };
        drop(v447_8);
        let v447_11: Space = if (&(v447_9)).is_empty() { Space::new() } else {
          let mut v452_10 = Space::new();
          let mut v452_10_write = v452_10.write_zipper();
          for v452_10_byte in v446_12_cursor.child_mask().iter() {
            v446_12_cursor.descend_to_existing_byte(v452_10_byte);
            {
            let v453_2: Space = singleton(&v446_12_cursor.path()[(v446_12_origin + 1)..(v446_12_origin + 2)]);
            let v453_3: Space = intersect(&(*CONSTANT_2),&(v453_2));
            let v453_4: Space = if has_head(&(v453_3)) { singleton(&[]) } else { Space::new() };
            drop(v453_3);
            let v453_5: Space = subtract(&(*CONSTANT_1),&(v453_4));
            drop(v453_4);
            let v453_8: Space = if (&(v453_5)).is_empty() { Space::new() } else {
              let v454_7: Space = routine_17(c, &v446_12_cursor.path()[v446_12_origin..(v446_12_origin + 2)], &(*p1), &v446_12_cursor);
              compose(&(v453_5),&(v454_7))
            };
            drop(v453_5);
            let v453_9: Space = intersect(&(*CONSTANT_2),&(v453_2));
            drop(v453_2);
            let v453_10: Space = if has_head(&(v453_9)) { singleton(&[]) } else { Space::new() };
            drop(v453_9);
            let v453_12: Space = if (&(v453_10)).is_empty() { Space::new() } else {
              let v455_11: Space = routine_19(c, &v446_12_cursor.path()[v446_12_origin..(v446_12_origin + 2)], &(*p1), &v446_12_cursor);
              compose(&(v453_10),&(v455_11))
            };
            drop(v453_10);
            let v453_13: Space = unite(&(v453_8),&(v453_12));
            join_wrapped_into(&mut v452_10_write,&((v453_13).read_zipper()),&[]);
            }
            v446_12_cursor.ascend(1);
          }
          drop(v452_10_write);
          compose(&(v447_9),&(v452_10))
        };
        drop(v447_9);
        let v447_12: Space = unite(&(v447_7),&(v447_11));
        join_wrapped_into(&mut v446_12_write,&((v447_12).read_zipper()),&[]);
        }
        v446_12_cursor.ascend(1);
      }
      drop(v446_12_cursor);
      drop(v446_12_write);
      compose(&(v435_10),&(v446_12))
    };
    drop(v435_10);
    let v435_14: Space = unite(&(v435_8),&(v435_13));
    join_wrapped_into(&mut v434_28_write,&((v435_14).read_zipper()),&[]);
    }
    v434_28_cursor.ascend(1);
  }
  drop(v434_28_cursor);
  drop(v434_28_write);
  (v434_28).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v456_21 = Space::new();
  let mut v456_21_write = v456_21.write_zipper();
  let mut v456_21_cursor = (*s0).read_zipper();
  let v456_21_origin = v456_21_cursor.path().len();
  for v456_21_byte in v456_21_cursor.child_mask().iter() {
    v456_21_cursor.descend_to_existing_byte(v456_21_byte);
    {
    let v457_2: Space = singleton(&v456_21_cursor.path()[v456_21_origin..(v456_21_origin + 1)]);
    let v457_3: Space = intersect(&(*CONSTANT_2),&(v457_2));
    let v457_4: Space = if has_head(&(v457_3)) { singleton(&[]) } else { Space::new() };
    drop(v457_3);
    let v457_5: Space = subtract(&(*CONSTANT_1),&(v457_4));
    drop(v457_4);
    let v457_8: Space = if (&(v457_5)).is_empty() { Space::new() } else {
      let v458_6: Path = concat_path(&(*p0),&v456_21_cursor.path()[v456_21_origin..(v456_21_origin + 1)]);
      let mut v458_7 = Space::new();
      let mut v458_7_write = v458_7.write_zipper();
      for v458_7_byte in v456_21_cursor.child_mask().iter() {
        v456_21_cursor.descend_to_existing_byte(v458_7_byte);
        {
        let v459_2: Space = singleton(&v456_21_cursor.path()[(v456_21_origin + 1)..(v456_21_origin + 2)]);
        let v459_3: Space = intersect(&(*CONSTANT_2),&(v459_2));
        let v459_4: Space = if has_head(&(v459_3)) { singleton(&[]) } else { Space::new() };
        drop(v459_3);
        let v459_5: Space = subtract(&(*CONSTANT_1),&(v459_4));
        drop(v459_4);
        let v459_8: Space = if (&(v459_5)).is_empty() { Space::new() } else {
          let v460_6: Path = concat_path(&(v458_6),&v456_21_cursor.path()[(v456_21_origin + 1)..(v456_21_origin + 2)]);
          let mut v460_7 = Space::new();
          let mut v460_7_write = v460_7.write_zipper();
          for v460_7_byte in v456_21_cursor.child_mask().iter() {
            v456_21_cursor.descend_to_existing_byte(v460_7_byte);
            {
            let v461_2: Space = singleton(&v456_21_cursor.path()[(v456_21_origin + 2)..(v456_21_origin + 3)]);
            let v461_3: Space = intersect(&(*CONSTANT_2),&(v461_2));
            let v461_4: Space = if has_head(&(v461_3)) { singleton(&[]) } else { Space::new() };
            drop(v461_3);
            let v461_5: Space = subtract(&(*CONSTANT_1),&(v461_4));
            drop(v461_4);
            let v461_8: Space = if (&(v461_5)).is_empty() { Space::new() } else {
              let v462_6: Path = concat_path(&(v460_6),&v456_21_cursor.path()[(v456_21_origin + 2)..(v456_21_origin + 3)]);
              let v462_7: Space = routine_36(c, &(v462_6), &(*p1), &v456_21_cursor);
              compose(&(v461_5),&(v462_7))
            };
            drop(v461_5);
            let v461_9: Space = intersect(&(*CONSTANT_2),&(v461_2));
            drop(v461_2);
            let v461_10: Space = if has_head(&(v461_9)) { singleton(&[]) } else { Space::new() };
            drop(v461_9);
            let v461_12: Space = if (&(v461_10)).is_empty() { Space::new() } else {
              let v463_6: Path = concat_path(&(v460_6),&v456_21_cursor.path()[(v456_21_origin + 2)..(v456_21_origin + 3)]);
              let v463_11: Space = routine_37(c, &(v463_6), &(*p1), &v456_21_cursor);
              drop(v463_6);
              compose(&(v461_10),&(v463_11))
            };
            drop(v461_10);
            let v461_13: Space = unite(&(v461_8),&(v461_12));
            join_wrapped_into(&mut v460_7_write,&((v461_13).read_zipper()),&[]);
            }
            v456_21_cursor.ascend(1);
          }
          drop(v460_7_write);
          compose(&(v459_5),&(v460_7))
        };
        drop(v459_5);
        let v459_9: Space = intersect(&(*CONSTANT_2),&(v459_2));
        drop(v459_2);
        let v459_10: Space = if has_head(&(v459_9)) { singleton(&[]) } else { Space::new() };
        drop(v459_9);
        let v459_12: Space = if (&(v459_10)).is_empty() { Space::new() } else {
          let v464_6: Path = concat_path(&(v458_6),&v456_21_cursor.path()[(v456_21_origin + 1)..(v456_21_origin + 2)]);
          let mut v464_11 = Space::new();
          let mut v464_11_write = v464_11.write_zipper();
          for v464_11_byte in v456_21_cursor.child_mask().iter() {
            v456_21_cursor.descend_to_existing_byte(v464_11_byte);
            {
            let v465_2: Space = singleton(&v456_21_cursor.path()[(v456_21_origin + 2)..(v456_21_origin + 3)]);
            let v465_3: Space = intersect(&(*CONSTANT_2),&(v465_2));
            let v465_4: Space = if has_head(&(v465_3)) { singleton(&[]) } else { Space::new() };
            drop(v465_3);
            let v465_5: Space = subtract(&(*CONSTANT_1),&(v465_4));
            drop(v465_4);
            let v465_8: Space = if (&(v465_5)).is_empty() { Space::new() } else {
              let v466_6: Path = concat_path(&(v464_6),&v456_21_cursor.path()[(v456_21_origin + 2)..(v456_21_origin + 3)]);
              let v466_7: Space = routine_36(c, &(v466_6), &(*p1), &v456_21_cursor);
              compose(&(v465_5),&(v466_7))
            };
            drop(v465_5);
            let v465_9: Space = intersect(&(*CONSTANT_2),&(v465_2));
            drop(v465_2);
            let v465_10: Space = if has_head(&(v465_9)) { singleton(&[]) } else { Space::new() };
            drop(v465_9);
            let v465_12: Space = if (&(v465_10)).is_empty() { Space::new() } else {
              let v467_6: Path = concat_path(&(v464_6),&v456_21_cursor.path()[(v456_21_origin + 2)..(v456_21_origin + 3)]);
              let v467_11: Space = routine_19(c, &(v467_6), &(*p1), &v456_21_cursor);
              drop(v467_6);
              compose(&(v465_10),&(v467_11))
            };
            drop(v465_10);
            let v465_13: Space = unite(&(v465_8),&(v465_12));
            join_wrapped_into(&mut v464_11_write,&((v465_13).read_zipper()),&[]);
            }
            v456_21_cursor.ascend(1);
          }
          drop(v464_11_write);
          drop(v464_6);
          compose(&(v459_10),&(v464_11))
        };
        drop(v459_10);
        let v459_13: Space = unite(&(v459_8),&(v459_12));
        join_wrapped_into(&mut v458_7_write,&((v459_13).read_zipper()),&[]);
        }
        v456_21_cursor.ascend(1);
      }
      drop(v458_7_write);
      compose(&(v457_5),&(v458_7))
    };
    drop(v457_5);
    let v457_9: Space = intersect(&(*CONSTANT_2),&(v457_2));
    drop(v457_2);
    let v457_10: Space = if has_head(&(v457_9)) { singleton(&[]) } else { Space::new() };
    drop(v457_9);
    let v457_12: Space = if (&(v457_10)).is_empty() { Space::new() } else {
      let v468_6: Path = concat_path(&(*p0),&v456_21_cursor.path()[v456_21_origin..(v456_21_origin + 1)]);
      let mut v468_11 = Space::new();
      let mut v468_11_write = v468_11.write_zipper();
      for v468_11_byte in v456_21_cursor.child_mask().iter() {
        v456_21_cursor.descend_to_existing_byte(v468_11_byte);
        {
        let v469_2: Space = singleton(&v456_21_cursor.path()[(v456_21_origin + 1)..(v456_21_origin + 2)]);
        let v469_3: Space = intersect(&(*CONSTANT_2),&(v469_2));
        let v469_4: Space = if has_head(&(v469_3)) { singleton(&[]) } else { Space::new() };
        drop(v469_3);
        let v469_5: Space = subtract(&(*CONSTANT_1),&(v469_4));
        drop(v469_4);
        let v469_8: Space = if (&(v469_5)).is_empty() { Space::new() } else {
          let v470_6: Path = concat_path(&(v468_6),&v456_21_cursor.path()[(v456_21_origin + 1)..(v456_21_origin + 2)]);
          let mut v470_7 = Space::new();
          let mut v470_7_write = v470_7.write_zipper();
          for v470_7_byte in v456_21_cursor.child_mask().iter() {
            v456_21_cursor.descend_to_existing_byte(v470_7_byte);
            {
            let v471_2: Space = singleton(&v456_21_cursor.path()[(v456_21_origin + 2)..(v456_21_origin + 3)]);
            let v471_3: Space = intersect(&(*CONSTANT_2),&(v471_2));
            let v471_4: Space = if has_head(&(v471_3)) { singleton(&[]) } else { Space::new() };
            drop(v471_3);
            let v471_5: Space = subtract(&(*CONSTANT_1),&(v471_4));
            drop(v471_4);
            let v471_8: Space = if (&(v471_5)).is_empty() { Space::new() } else {
              let v472_6: Path = concat_path(&(v470_6),&v456_21_cursor.path()[(v456_21_origin + 2)..(v456_21_origin + 3)]);
              let v472_7: Space = routine_36(c, &(v472_6), &(*p1), &v456_21_cursor);
              compose(&(v471_5),&(v472_7))
            };
            drop(v471_5);
            let v471_9: Space = intersect(&(*CONSTANT_2),&(v471_2));
            drop(v471_2);
            let v471_10: Space = if has_head(&(v471_9)) { singleton(&[]) } else { Space::new() };
            drop(v471_9);
            let v471_12: Space = if (&(v471_10)).is_empty() { Space::new() } else {
              let v473_6: Path = concat_path(&(v470_6),&v456_21_cursor.path()[(v456_21_origin + 2)..(v456_21_origin + 3)]);
              let v473_11: Space = routine_37(c, &(v473_6), &(*p1), &v456_21_cursor);
              drop(v473_6);
              compose(&(v471_10),&(v473_11))
            };
            drop(v471_10);
            let v471_13: Space = unite(&(v471_8),&(v471_12));
            join_wrapped_into(&mut v470_7_write,&((v471_13).read_zipper()),&[]);
            }
            v456_21_cursor.ascend(1);
          }
          drop(v470_7_write);
          compose(&(v469_5),&(v470_7))
        };
        drop(v469_5);
        let v469_9: Space = intersect(&(*CONSTANT_2),&(v469_2));
        drop(v469_2);
        let v469_10: Space = if has_head(&(v469_9)) { singleton(&[]) } else { Space::new() };
        drop(v469_9);
        let v469_11: Space = compose(&(v469_10),&v456_21_cursor);
        drop(v469_10);
        let v474_6: Path = concat_path(&(v468_6),&v456_21_cursor.path()[(v456_21_origin + 1)..(v456_21_origin + 2)]);
        let v469_12: Space = wrap(&(v469_11),&(v474_6));
        drop(v469_11);
        let v469_13: Space = wrap(&(v469_12),&(*p1));
        drop(v469_12);
        let v469_14: Space = unite(&(v469_8),&(v469_13));
        drop(v469_13);
        join_wrapped_into(&mut v468_11_write,&((v469_14).read_zipper()),&[]);
        }
        v456_21_cursor.ascend(1);
      }
      drop(v468_11_write);
      drop(v468_6);
      compose(&(v457_10),&(v468_11))
    };
    drop(v457_10);
    let v457_13: Space = unite(&(v457_8),&(v457_12));
    join_wrapped_into(&mut v456_21_write,&((v457_13).read_zipper()),&[]);
    }
    v456_21_cursor.ascend(1);
  }
  drop(v456_21_cursor);
  drop(v456_21_write);
  (v456_21).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v475_15 = Space::new();
  let mut v475_15_write = v475_15.write_zipper();
  let mut v475_15_cursor = (*s0).read_zipper();
  let v475_15_origin = v475_15_cursor.path().len();
  for v475_15_byte in v475_15_cursor.child_mask().iter() {
    v475_15_cursor.descend_to_existing_byte(v475_15_byte);
    {
    let v476_2: Space = singleton(&v475_15_cursor.path()[v475_15_origin..(v475_15_origin + 1)]);
    let v476_3: Space = intersect(&(*CONSTANT_2),&(v476_2));
    let v476_4: Space = if has_head(&(v476_3)) { singleton(&[]) } else { Space::new() };
    drop(v476_3);
    let v476_5: Space = subtract(&(*CONSTANT_1),&(v476_4));
    drop(v476_4);
    let v476_8: Space = if (&(v476_5)).is_empty() { Space::new() } else {
      let v477_6: Path = concat_path(&(*p0),&v475_15_cursor.path()[v475_15_origin..(v475_15_origin + 1)]);
      let mut v477_7 = Space::new();
      let mut v477_7_write = v477_7.write_zipper();
      for v477_7_byte in v475_15_cursor.child_mask().iter() {
        v475_15_cursor.descend_to_existing_byte(v477_7_byte);
        {
        let v478_2: Space = singleton(&v475_15_cursor.path()[(v475_15_origin + 1)..(v475_15_origin + 2)]);
        let v478_3: Space = intersect(&(*CONSTANT_2),&(v478_2));
        let v478_4: Space = if has_head(&(v478_3)) { singleton(&[]) } else { Space::new() };
        drop(v478_3);
        let v478_5: Space = subtract(&(*CONSTANT_1),&(v478_4));
        drop(v478_4);
        let v478_8: Space = if (&(v478_5)).is_empty() { Space::new() } else {
          let v479_6: Path = concat_path(&(v477_6),&v475_15_cursor.path()[(v475_15_origin + 1)..(v475_15_origin + 2)]);
          let mut v479_7 = Space::new();
          let mut v479_7_write = v479_7.write_zipper();
          for v479_7_byte in v475_15_cursor.child_mask().iter() {
            v475_15_cursor.descend_to_existing_byte(v479_7_byte);
            {
            let v480_2: Space = singleton(&v475_15_cursor.path()[(v475_15_origin + 2)..(v475_15_origin + 3)]);
            let v480_3: Space = intersect(&(*CONSTANT_2),&(v480_2));
            let v480_4: Space = if has_head(&(v480_3)) { singleton(&[]) } else { Space::new() };
            drop(v480_3);
            let v480_5: Space = subtract(&(*CONSTANT_1),&(v480_4));
            drop(v480_4);
            let v480_8: Space = if (&(v480_5)).is_empty() { Space::new() } else {
              let v481_6: Path = concat_path(&(v479_6),&v475_15_cursor.path()[(v475_15_origin + 2)..(v475_15_origin + 3)]);
              let v481_7: Space = routine_36(c, &(v481_6), &(*p1), &v475_15_cursor);
              compose(&(v480_5),&(v481_7))
            };
            drop(v480_5);
            let v480_9: Space = intersect(&(*CONSTANT_2),&(v480_2));
            drop(v480_2);
            let v480_10: Space = if has_head(&(v480_9)) { singleton(&[]) } else { Space::new() };
            drop(v480_9);
            let v480_12: Space = if (&(v480_10)).is_empty() { Space::new() } else {
              let v482_6: Path = concat_path(&(v479_6),&v475_15_cursor.path()[(v475_15_origin + 2)..(v475_15_origin + 3)]);
              let v482_11: Space = routine_37(c, &(v482_6), &(*p1), &v475_15_cursor);
              drop(v482_6);
              compose(&(v480_10),&(v482_11))
            };
            drop(v480_10);
            let v480_13: Space = unite(&(v480_8),&(v480_12));
            join_wrapped_into(&mut v479_7_write,&((v480_13).read_zipper()),&[]);
            }
            v475_15_cursor.ascend(1);
          }
          drop(v479_7_write);
          compose(&(v478_5),&(v479_7))
        };
        drop(v478_5);
        let v478_9: Space = intersect(&(*CONSTANT_2),&(v478_2));
        drop(v478_2);
        let v478_10: Space = if has_head(&(v478_9)) { singleton(&[]) } else { Space::new() };
        drop(v478_9);
        let v478_12: Space = if (&(v478_10)).is_empty() { Space::new() } else {
          let v483_6: Path = concat_path(&(v477_6),&v475_15_cursor.path()[(v475_15_origin + 1)..(v475_15_origin + 2)]);
          let mut v483_11 = Space::new();
          let mut v483_11_write = v483_11.write_zipper();
          for v483_11_byte in v475_15_cursor.child_mask().iter() {
            v475_15_cursor.descend_to_existing_byte(v483_11_byte);
            {
            let v484_2: Space = singleton(&v475_15_cursor.path()[(v475_15_origin + 2)..(v475_15_origin + 3)]);
            let v484_3: Space = intersect(&(*CONSTANT_2),&(v484_2));
            let v484_4: Space = if has_head(&(v484_3)) { singleton(&[]) } else { Space::new() };
            drop(v484_3);
            let v484_5: Space = subtract(&(*CONSTANT_1),&(v484_4));
            drop(v484_4);
            let v484_8: Space = if (&(v484_5)).is_empty() { Space::new() } else {
              let v485_6: Path = concat_path(&(v483_6),&v475_15_cursor.path()[(v475_15_origin + 2)..(v475_15_origin + 3)]);
              let v485_7: Space = routine_36(c, &(v485_6), &(*p1), &v475_15_cursor);
              compose(&(v484_5),&(v485_7))
            };
            drop(v484_5);
            let v484_9: Space = intersect(&(*CONSTANT_2),&(v484_2));
            drop(v484_2);
            let v484_10: Space = if has_head(&(v484_9)) { singleton(&[]) } else { Space::new() };
            drop(v484_9);
            let v484_12: Space = if (&(v484_10)).is_empty() { Space::new() } else {
              let v486_6: Path = concat_path(&(v483_6),&v475_15_cursor.path()[(v475_15_origin + 2)..(v475_15_origin + 3)]);
              let v486_11: Space = routine_19(c, &(v486_6), &(*p1), &v475_15_cursor);
              drop(v486_6);
              compose(&(v484_10),&(v486_11))
            };
            drop(v484_10);
            let v484_13: Space = unite(&(v484_8),&(v484_12));
            join_wrapped_into(&mut v483_11_write,&((v484_13).read_zipper()),&[]);
            }
            v475_15_cursor.ascend(1);
          }
          drop(v483_11_write);
          drop(v483_6);
          compose(&(v478_10),&(v483_11))
        };
        drop(v478_10);
        let v478_13: Space = unite(&(v478_8),&(v478_12));
        join_wrapped_into(&mut v477_7_write,&((v478_13).read_zipper()),&[]);
        }
        v475_15_cursor.ascend(1);
      }
      drop(v477_7_write);
      compose(&(v476_5),&(v477_7))
    };
    drop(v476_5);
    let v476_9: Space = intersect(&(*CONSTANT_2),&(v476_2));
    drop(v476_2);
    let v476_10: Space = if has_head(&(v476_9)) { singleton(&[]) } else { Space::new() };
    drop(v476_9);
    let v476_11: Space = compose(&(v476_10),&v475_15_cursor);
    drop(v476_10);
    let v487_6: Path = concat_path(&(*p0),&v475_15_cursor.path()[v475_15_origin..(v475_15_origin + 1)]);
    let v476_12: Space = wrap(&(v476_11),&(v487_6));
    drop(v476_11);
    let v476_13: Space = wrap(&(v476_12),&(*p1));
    drop(v476_12);
    let v476_14: Space = unite(&(v476_8),&(v476_13));
    drop(v476_13);
    join_wrapped_into(&mut v475_15_write,&((v476_14).read_zipper()),&[]);
    }
    v475_15_cursor.ascend(1);
  }
  drop(v475_15_cursor);
  drop(v475_15_write);
  (v475_15).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v488_28 = Space::new();
  let mut v488_28_write = v488_28.write_zipper();
  let mut v488_28_cursor = (*s0).read_zipper();
  let v488_28_origin = v488_28_cursor.path().len();
  for v488_28_byte in v488_28_cursor.child_mask().iter() {
    v488_28_cursor.descend_to_existing_byte(v488_28_byte);
    {
    let v489_2: Space = singleton(&v488_28_cursor.path()[v488_28_origin..(v488_28_origin + 1)]);
    let v489_3: Space = intersect(&(*CONSTANT_2),&(v489_2));
    let v489_4: Space = if has_head(&(v489_3)) { singleton(&[]) } else { Space::new() };
    drop(v489_3);
    let v489_5: Space = subtract(&(*CONSTANT_1),&(v489_4));
    drop(v489_4);
    let v489_8: Space = if (&(v489_5)).is_empty() { Space::new() } else {
      let v490_6: Path = concat_path(&(*p0),&v488_28_cursor.path()[v488_28_origin..(v488_28_origin + 1)]);
      let mut v490_7 = Space::new();
      let mut v490_7_write = v490_7.write_zipper();
      for v490_7_byte in v488_28_cursor.child_mask().iter() {
        v488_28_cursor.descend_to_existing_byte(v490_7_byte);
        {
        let v491_2: Space = singleton(&v488_28_cursor.path()[(v488_28_origin + 1)..(v488_28_origin + 2)]);
        let v491_3: Space = intersect(&(*CONSTANT_2),&(v491_2));
        let v491_4: Space = if has_head(&(v491_3)) { singleton(&[]) } else { Space::new() };
        drop(v491_3);
        let v491_5: Space = subtract(&(*CONSTANT_1),&(v491_4));
        drop(v491_4);
        let v491_8: Space = if (&(v491_5)).is_empty() { Space::new() } else {
          let v492_6: Path = concat_path(&(v490_6),&v488_28_cursor.path()[(v488_28_origin + 1)..(v488_28_origin + 2)]);
          let mut v492_7 = Space::new();
          let mut v492_7_write = v492_7.write_zipper();
          for v492_7_byte in v488_28_cursor.child_mask().iter() {
            v488_28_cursor.descend_to_existing_byte(v492_7_byte);
            {
            let v493_2: Space = singleton(&v488_28_cursor.path()[(v488_28_origin + 2)..(v488_28_origin + 3)]);
            let v493_3: Space = intersect(&(*CONSTANT_2),&(v493_2));
            let v493_4: Space = if has_head(&(v493_3)) { singleton(&[]) } else { Space::new() };
            drop(v493_3);
            let v493_5: Space = subtract(&(*CONSTANT_1),&(v493_4));
            drop(v493_4);
            let v493_8: Space = if (&(v493_5)).is_empty() { Space::new() } else {
              let v494_6: Path = concat_path(&(v492_6),&v488_28_cursor.path()[(v488_28_origin + 2)..(v488_28_origin + 3)]);
              let v494_7: Space = routine_38(c, &(v494_6), &(*p1), &v488_28_cursor, &(*s1));
              compose(&(v493_5),&(v494_7))
            };
            drop(v493_5);
            let v493_9: Space = intersect(&(*CONSTANT_2),&(v493_2));
            drop(v493_2);
            let v493_10: Space = if has_head(&(v493_9)) { singleton(&[]) } else { Space::new() };
            drop(v493_9);
            let v493_12: Space = if (&(v493_10)).is_empty() { Space::new() } else {
              let v495_6: Path = concat_path(&(v492_6),&v488_28_cursor.path()[(v488_28_origin + 2)..(v488_28_origin + 3)]);
              let v495_11: Space = routine_39(c, &(v495_6), &(*p1), &v488_28_cursor, &(*s1));
              drop(v495_6);
              compose(&(v493_10),&(v495_11))
            };
            drop(v493_10);
            let v493_13: Space = unite(&(v493_8),&(v493_12));
            join_wrapped_into(&mut v492_7_write,&((v493_13).read_zipper()),&[]);
            }
            v488_28_cursor.ascend(1);
          }
          drop(v492_7_write);
          compose(&(v491_5),&(v492_7))
        };
        drop(v491_5);
        let v491_9: Space = intersect(&(*CONSTANT_2),&(v491_2));
        drop(v491_2);
        let v491_10: Space = if has_head(&(v491_9)) { singleton(&[]) } else { Space::new() };
        drop(v491_9);
        let v491_12: Space = if (&(v491_10)).is_empty() { Space::new() } else {
          let v496_6: Path = concat_path(&(v490_6),&v488_28_cursor.path()[(v488_28_origin + 1)..(v488_28_origin + 2)]);
          let mut v496_11 = Space::new();
          let mut v496_11_write = v496_11.write_zipper();
          for v496_11_byte in v488_28_cursor.child_mask().iter() {
            v488_28_cursor.descend_to_existing_byte(v496_11_byte);
            {
            let v497_2: Space = singleton(&v488_28_cursor.path()[(v488_28_origin + 2)..(v488_28_origin + 3)]);
            let v497_3: Space = intersect(&(*CONSTANT_2),&(v497_2));
            let v497_4: Space = if has_head(&(v497_3)) { singleton(&[]) } else { Space::new() };
            drop(v497_3);
            let v497_5: Space = subtract(&(*CONSTANT_1),&(v497_4));
            drop(v497_4);
            let v497_8: Space = if (&(v497_5)).is_empty() { Space::new() } else {
              let v498_6: Path = concat_path(&(v496_6),&v488_28_cursor.path()[(v488_28_origin + 2)..(v488_28_origin + 3)]);
              let v498_7: Space = routine_38(c, &(v498_6), &(*p1), &v488_28_cursor, &(*s1));
              compose(&(v497_5),&(v498_7))
            };
            drop(v497_5);
            let v497_9: Space = intersect(&(*CONSTANT_2),&(v497_2));
            drop(v497_2);
            let v497_10: Space = if has_head(&(v497_9)) { singleton(&[]) } else { Space::new() };
            drop(v497_9);
            let v497_12: Space = if (&(v497_10)).is_empty() { Space::new() } else {
              let v499_6: Path = concat_path(&(v496_6),&v488_28_cursor.path()[(v488_28_origin + 2)..(v488_28_origin + 3)]);
              let v499_11: Space = routine_10(c, &(v499_6), &(*p1), &v488_28_cursor, &(*s1));
              drop(v499_6);
              compose(&(v497_10),&(v499_11))
            };
            drop(v497_10);
            let v497_13: Space = unite(&(v497_8),&(v497_12));
            join_wrapped_into(&mut v496_11_write,&((v497_13).read_zipper()),&[]);
            }
            v488_28_cursor.ascend(1);
          }
          drop(v496_11_write);
          drop(v496_6);
          compose(&(v491_10),&(v496_11))
        };
        drop(v491_10);
        let v491_13: Space = unite(&(v491_8),&(v491_12));
        join_wrapped_into(&mut v490_7_write,&((v491_13).read_zipper()),&[]);
        }
        v488_28_cursor.ascend(1);
      }
      drop(v490_7_write);
      compose(&(v489_5),&(v490_7))
    };
    drop(v489_5);
    let v489_9: Space = intersect(&(*CONSTANT_2),&(v489_2));
    drop(v489_2);
    let v489_10: Space = if has_head(&(v489_9)) { singleton(&[]) } else { Space::new() };
    drop(v489_9);
    let v489_13: Space = if (&(v489_10)).is_empty() { Space::new() } else {
      let v500_6: Path = concat_path(&(*p0),&v488_28_cursor.path()[v488_28_origin..(v488_28_origin + 1)]);
      let mut v500_12 = Space::new();
      let mut v500_12_write = v500_12.write_zipper();
      for v500_12_byte in v488_28_cursor.child_mask().iter() {
        v488_28_cursor.descend_to_existing_byte(v500_12_byte);
        {
        let v501_2: Space = singleton(&v488_28_cursor.path()[(v488_28_origin + 1)..(v488_28_origin + 2)]);
        let v501_3: Space = intersect(&(*CONSTANT_2),&(v501_2));
        let v501_4: Space = if has_head(&(v501_3)) { singleton(&[]) } else { Space::new() };
        drop(v501_3);
        let v501_5: Space = subtract(&(*CONSTANT_1),&(v501_4));
        drop(v501_4);
        let v501_8: Space = if (&(v501_5)).is_empty() { Space::new() } else {
          let v502_6: Path = concat_path(&(v500_6),&v488_28_cursor.path()[(v488_28_origin + 1)..(v488_28_origin + 2)]);
          let mut v502_7 = Space::new();
          let mut v502_7_write = v502_7.write_zipper();
          for v502_7_byte in v488_28_cursor.child_mask().iter() {
            v488_28_cursor.descend_to_existing_byte(v502_7_byte);
            {
            let v503_2: Space = singleton(&v488_28_cursor.path()[(v488_28_origin + 2)..(v488_28_origin + 3)]);
            let v503_3: Space = intersect(&(*CONSTANT_2),&(v503_2));
            let v503_4: Space = if has_head(&(v503_3)) { singleton(&[]) } else { Space::new() };
            drop(v503_3);
            let v503_5: Space = subtract(&(*CONSTANT_1),&(v503_4));
            drop(v503_4);
            let v503_8: Space = if (&(v503_5)).is_empty() { Space::new() } else {
              let v504_6: Path = concat_path(&(v502_6),&v488_28_cursor.path()[(v488_28_origin + 2)..(v488_28_origin + 3)]);
              let v504_7: Space = routine_38(c, &(v504_6), &(*p1), &v488_28_cursor, &(*s1));
              compose(&(v503_5),&(v504_7))
            };
            drop(v503_5);
            let v503_9: Space = intersect(&(*CONSTANT_2),&(v503_2));
            drop(v503_2);
            let v503_10: Space = if has_head(&(v503_9)) { singleton(&[]) } else { Space::new() };
            drop(v503_9);
            let v503_12: Space = if (&(v503_10)).is_empty() { Space::new() } else {
              let v505_6: Path = concat_path(&(v502_6),&v488_28_cursor.path()[(v488_28_origin + 2)..(v488_28_origin + 3)]);
              let v505_11: Space = routine_39(c, &(v505_6), &(*p1), &v488_28_cursor, &(*s1));
              drop(v505_6);
              compose(&(v503_10),&(v505_11))
            };
            drop(v503_10);
            let v503_13: Space = unite(&(v503_8),&(v503_12));
            join_wrapped_into(&mut v502_7_write,&((v503_13).read_zipper()),&[]);
            }
            v488_28_cursor.ascend(1);
          }
          drop(v502_7_write);
          drop(v502_6);
          compose(&(v501_5),&(v502_7))
        };
        drop(v501_5);
        let v501_9: Space = intersect(&(*CONSTANT_2),&(v501_2));
        drop(v501_2);
        let v501_10: Space = if has_head(&(v501_9)) { singleton(&[]) } else { Space::new() };
        drop(v501_9);
        let v501_13: Space = if (&(v501_10)).is_empty() { Space::new() } else {
          let mut v506_12 = Space::new();
          let mut v506_12_write = v506_12.write_zipper();
          let mut v506_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v488_28_cursor.path()[v488_28_origin..(v488_28_origin + 1)]),&v488_28_cursor.path()[(v488_28_origin + 1)..(v488_28_origin + 2)]);
          let v506_12_origin = v506_12_cursor.path().len();
          for v506_12_byte in v506_12_cursor.child_mask().iter() {
            v506_12_cursor.descend_to_existing_byte(v506_12_byte);
            {
            let v507_2: Space = singleton(&v506_12_cursor.path()[v506_12_origin..(v506_12_origin + 1)]);
            let v507_3: Space = intersect(&(*CONSTANT_2),&(v507_2));
            let v507_4: Space = if has_head(&(v507_3)) { singleton(&[]) } else { Space::new() };
            drop(v507_3);
            let v507_5: Space = subtract(&(*CONSTANT_1),&(v507_4));
            drop(v507_4);
            let v507_7: Space = if (&(v507_5)).is_empty() { Space::new() } else {
              let v508_6: Space = routine_13(c, &v506_12_cursor.path()[v506_12_origin..(v506_12_origin + 1)], &(*p1), &v506_12_cursor);
              compose(&(v507_5),&(v508_6))
            };
            drop(v507_5);
            let v507_8: Space = intersect(&(*CONSTANT_2),&(v507_2));
            drop(v507_2);
            let v507_9: Space = if has_head(&(v507_8)) { singleton(&[]) } else { Space::new() };
            drop(v507_8);
            let v507_11: Space = if (&(v507_9)).is_empty() { Space::new() } else {
              let v509_10: Space = routine_14(c, &v506_12_cursor.path()[v506_12_origin..(v506_12_origin + 1)], &(*p1), &v506_12_cursor);
              compose(&(v507_9),&(v509_10))
            };
            drop(v507_9);
            let v507_12: Space = unite(&(v507_7),&(v507_11));
            join_wrapped_into(&mut v506_12_write,&((v507_12).read_zipper()),&[]);
            }
            v506_12_cursor.ascend(1);
          }
          drop(v506_12_cursor);
          drop(v506_12_write);
          compose(&(v501_10),&(v506_12))
        };
        drop(v501_10);
        let v501_14: Space = unite(&(v501_8),&(v501_13));
        join_wrapped_into(&mut v500_12_write,&((v501_14).read_zipper()),&[]);
        }
        v488_28_cursor.ascend(1);
      }
      drop(v500_12_write);
      drop(v500_6);
      compose(&(v489_10),&(v500_12))
    };
    drop(v489_10);
    let v489_14: Space = unite(&(v489_8),&(v489_13));
    join_wrapped_into(&mut v488_28_write,&((v489_14).read_zipper()),&[]);
    }
    v488_28_cursor.ascend(1);
  }
  drop(v488_28_cursor);
  drop(v488_28_write);
  (v488_28).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v510_28 = Space::new();
  let mut v510_28_write = v510_28.write_zipper();
  let mut v510_28_cursor = (*s0).read_zipper();
  let v510_28_origin = v510_28_cursor.path().len();
  for v510_28_byte in v510_28_cursor.child_mask().iter() {
    v510_28_cursor.descend_to_existing_byte(v510_28_byte);
    {
    let v511_2: Space = singleton(&v510_28_cursor.path()[v510_28_origin..(v510_28_origin + 1)]);
    let v511_3: Space = intersect(&(*CONSTANT_2),&(v511_2));
    let v511_4: Space = if has_head(&(v511_3)) { singleton(&[]) } else { Space::new() };
    drop(v511_3);
    let v511_5: Space = subtract(&(*CONSTANT_1),&(v511_4));
    drop(v511_4);
    let v511_8: Space = if (&(v511_5)).is_empty() { Space::new() } else {
      let v512_6: Path = concat_path(&(*p0),&v510_28_cursor.path()[v510_28_origin..(v510_28_origin + 1)]);
      let mut v512_7 = Space::new();
      let mut v512_7_write = v512_7.write_zipper();
      for v512_7_byte in v510_28_cursor.child_mask().iter() {
        v510_28_cursor.descend_to_existing_byte(v512_7_byte);
        {
        let v513_2: Space = singleton(&v510_28_cursor.path()[(v510_28_origin + 1)..(v510_28_origin + 2)]);
        let v513_3: Space = intersect(&(*CONSTANT_2),&(v513_2));
        let v513_4: Space = if has_head(&(v513_3)) { singleton(&[]) } else { Space::new() };
        drop(v513_3);
        let v513_5: Space = subtract(&(*CONSTANT_1),&(v513_4));
        drop(v513_4);
        let v513_8: Space = if (&(v513_5)).is_empty() { Space::new() } else {
          let v514_6: Path = concat_path(&(v512_6),&v510_28_cursor.path()[(v510_28_origin + 1)..(v510_28_origin + 2)]);
          let mut v514_7 = Space::new();
          let mut v514_7_write = v514_7.write_zipper();
          for v514_7_byte in v510_28_cursor.child_mask().iter() {
            v510_28_cursor.descend_to_existing_byte(v514_7_byte);
            {
            let v515_2: Space = singleton(&v510_28_cursor.path()[(v510_28_origin + 2)..(v510_28_origin + 3)]);
            let v515_3: Space = intersect(&(*CONSTANT_2),&(v515_2));
            let v515_4: Space = if has_head(&(v515_3)) { singleton(&[]) } else { Space::new() };
            drop(v515_3);
            let v515_5: Space = subtract(&(*CONSTANT_1),&(v515_4));
            drop(v515_4);
            let v515_8: Space = if (&(v515_5)).is_empty() { Space::new() } else {
              let v516_6: Path = concat_path(&(v514_6),&v510_28_cursor.path()[(v510_28_origin + 2)..(v510_28_origin + 3)]);
              let v516_7: Space = routine_38(c, &(v516_6), &(*p1), &v510_28_cursor, &(*s1));
              compose(&(v515_5),&(v516_7))
            };
            drop(v515_5);
            let v515_9: Space = intersect(&(*CONSTANT_2),&(v515_2));
            drop(v515_2);
            let v515_10: Space = if has_head(&(v515_9)) { singleton(&[]) } else { Space::new() };
            drop(v515_9);
            let v515_12: Space = if (&(v515_10)).is_empty() { Space::new() } else {
              let v517_6: Path = concat_path(&(v514_6),&v510_28_cursor.path()[(v510_28_origin + 2)..(v510_28_origin + 3)]);
              let v517_11: Space = routine_39(c, &(v517_6), &(*p1), &v510_28_cursor, &(*s1));
              drop(v517_6);
              compose(&(v515_10),&(v517_11))
            };
            drop(v515_10);
            let v515_13: Space = unite(&(v515_8),&(v515_12));
            join_wrapped_into(&mut v514_7_write,&((v515_13).read_zipper()),&[]);
            }
            v510_28_cursor.ascend(1);
          }
          drop(v514_7_write);
          compose(&(v513_5),&(v514_7))
        };
        drop(v513_5);
        let v513_9: Space = intersect(&(*CONSTANT_2),&(v513_2));
        drop(v513_2);
        let v513_10: Space = if has_head(&(v513_9)) { singleton(&[]) } else { Space::new() };
        drop(v513_9);
        let v513_12: Space = if (&(v513_10)).is_empty() { Space::new() } else {
          let v518_6: Path = concat_path(&(v512_6),&v510_28_cursor.path()[(v510_28_origin + 1)..(v510_28_origin + 2)]);
          let mut v518_11 = Space::new();
          let mut v518_11_write = v518_11.write_zipper();
          for v518_11_byte in v510_28_cursor.child_mask().iter() {
            v510_28_cursor.descend_to_existing_byte(v518_11_byte);
            {
            let v519_2: Space = singleton(&v510_28_cursor.path()[(v510_28_origin + 2)..(v510_28_origin + 3)]);
            let v519_3: Space = intersect(&(*CONSTANT_2),&(v519_2));
            let v519_4: Space = if has_head(&(v519_3)) { singleton(&[]) } else { Space::new() };
            drop(v519_3);
            let v519_5: Space = subtract(&(*CONSTANT_1),&(v519_4));
            drop(v519_4);
            let v519_8: Space = if (&(v519_5)).is_empty() { Space::new() } else {
              let v520_6: Path = concat_path(&(v518_6),&v510_28_cursor.path()[(v510_28_origin + 2)..(v510_28_origin + 3)]);
              let v520_7: Space = routine_38(c, &(v520_6), &(*p1), &v510_28_cursor, &(*s1));
              compose(&(v519_5),&(v520_7))
            };
            drop(v519_5);
            let v519_9: Space = intersect(&(*CONSTANT_2),&(v519_2));
            drop(v519_2);
            let v519_10: Space = if has_head(&(v519_9)) { singleton(&[]) } else { Space::new() };
            drop(v519_9);
            let v519_12: Space = if (&(v519_10)).is_empty() { Space::new() } else {
              let v521_6: Path = concat_path(&(v518_6),&v510_28_cursor.path()[(v510_28_origin + 2)..(v510_28_origin + 3)]);
              let v521_11: Space = routine_10(c, &(v521_6), &(*p1), &v510_28_cursor, &(*s1));
              drop(v521_6);
              compose(&(v519_10),&(v521_11))
            };
            drop(v519_10);
            let v519_13: Space = unite(&(v519_8),&(v519_12));
            join_wrapped_into(&mut v518_11_write,&((v519_13).read_zipper()),&[]);
            }
            v510_28_cursor.ascend(1);
          }
          drop(v518_11_write);
          drop(v518_6);
          compose(&(v513_10),&(v518_11))
        };
        drop(v513_10);
        let v513_13: Space = unite(&(v513_8),&(v513_12));
        join_wrapped_into(&mut v512_7_write,&((v513_13).read_zipper()),&[]);
        }
        v510_28_cursor.ascend(1);
      }
      drop(v512_7_write);
      drop(v512_6);
      compose(&(v511_5),&(v512_7))
    };
    drop(v511_5);
    let v511_9: Space = intersect(&(*CONSTANT_2),&(v511_2));
    drop(v511_2);
    let v511_10: Space = if has_head(&(v511_9)) { singleton(&[]) } else { Space::new() };
    drop(v511_9);
    let v511_13: Space = if (&(v511_10)).is_empty() { Space::new() } else {
      let mut v522_12 = Space::new();
      let mut v522_12_write = v522_12.write_zipper();
      let mut v522_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v510_28_cursor.path()[v510_28_origin..(v510_28_origin + 1)]);
      let v522_12_origin = v522_12_cursor.path().len();
      for v522_12_byte in v522_12_cursor.child_mask().iter() {
        v522_12_cursor.descend_to_existing_byte(v522_12_byte);
        {
        let v523_2: Space = singleton(&v522_12_cursor.path()[v522_12_origin..(v522_12_origin + 1)]);
        let v523_3: Space = intersect(&(*CONSTANT_2),&(v523_2));
        let v523_4: Space = if has_head(&(v523_3)) { singleton(&[]) } else { Space::new() };
        drop(v523_3);
        let v523_5: Space = subtract(&(*CONSTANT_1),&(v523_4));
        drop(v523_4);
        let v523_7: Space = if (&(v523_5)).is_empty() { Space::new() } else {
          let mut v524_6 = Space::new();
          let mut v524_6_write = v524_6.write_zipper();
          for v524_6_byte in v522_12_cursor.child_mask().iter() {
            v522_12_cursor.descend_to_existing_byte(v524_6_byte);
            {
            let v525_2: Space = singleton(&v522_12_cursor.path()[(v522_12_origin + 1)..(v522_12_origin + 2)]);
            let v525_3: Space = intersect(&(*CONSTANT_2),&(v525_2));
            let v525_4: Space = if has_head(&(v525_3)) { singleton(&[]) } else { Space::new() };
            drop(v525_3);
            let v525_5: Space = subtract(&(*CONSTANT_1),&(v525_4));
            drop(v525_4);
            let v525_8: Space = if (&(v525_5)).is_empty() { Space::new() } else {
              let v526_7: Space = routine_17(c, &v522_12_cursor.path()[v522_12_origin..(v522_12_origin + 2)], &(*p1), &v522_12_cursor);
              compose(&(v525_5),&(v526_7))
            };
            drop(v525_5);
            let v525_9: Space = intersect(&(*CONSTANT_2),&(v525_2));
            drop(v525_2);
            let v525_10: Space = if has_head(&(v525_9)) { singleton(&[]) } else { Space::new() };
            drop(v525_9);
            let v525_12: Space = if (&(v525_10)).is_empty() { Space::new() } else {
              let v527_11: Space = routine_18(c, &v522_12_cursor.path()[v522_12_origin..(v522_12_origin + 2)], &(*p1), &v522_12_cursor);
              compose(&(v525_10),&(v527_11))
            };
            drop(v525_10);
            let v525_13: Space = unite(&(v525_8),&(v525_12));
            join_wrapped_into(&mut v524_6_write,&((v525_13).read_zipper()),&[]);
            }
            v522_12_cursor.ascend(1);
          }
          drop(v524_6_write);
          compose(&(v523_5),&(v524_6))
        };
        drop(v523_5);
        let v523_8: Space = intersect(&(*CONSTANT_2),&(v523_2));
        drop(v523_2);
        let v523_9: Space = if has_head(&(v523_8)) { singleton(&[]) } else { Space::new() };
        drop(v523_8);
        let v523_11: Space = if (&(v523_9)).is_empty() { Space::new() } else {
          let mut v528_10 = Space::new();
          let mut v528_10_write = v528_10.write_zipper();
          for v528_10_byte in v522_12_cursor.child_mask().iter() {
            v522_12_cursor.descend_to_existing_byte(v528_10_byte);
            {
            let v529_2: Space = singleton(&v522_12_cursor.path()[(v522_12_origin + 1)..(v522_12_origin + 2)]);
            let v529_3: Space = intersect(&(*CONSTANT_2),&(v529_2));
            let v529_4: Space = if has_head(&(v529_3)) { singleton(&[]) } else { Space::new() };
            drop(v529_3);
            let v529_5: Space = subtract(&(*CONSTANT_1),&(v529_4));
            drop(v529_4);
            let v529_8: Space = if (&(v529_5)).is_empty() { Space::new() } else {
              let v530_7: Space = routine_17(c, &v522_12_cursor.path()[v522_12_origin..(v522_12_origin + 2)], &(*p1), &v522_12_cursor);
              compose(&(v529_5),&(v530_7))
            };
            drop(v529_5);
            let v529_9: Space = intersect(&(*CONSTANT_2),&(v529_2));
            drop(v529_2);
            let v529_10: Space = if has_head(&(v529_9)) { singleton(&[]) } else { Space::new() };
            drop(v529_9);
            let v529_12: Space = if (&(v529_10)).is_empty() { Space::new() } else {
              let v531_11: Space = routine_19(c, &v522_12_cursor.path()[v522_12_origin..(v522_12_origin + 2)], &(*p1), &v522_12_cursor);
              compose(&(v529_10),&(v531_11))
            };
            drop(v529_10);
            let v529_13: Space = unite(&(v529_8),&(v529_12));
            join_wrapped_into(&mut v528_10_write,&((v529_13).read_zipper()),&[]);
            }
            v522_12_cursor.ascend(1);
          }
          drop(v528_10_write);
          compose(&(v523_9),&(v528_10))
        };
        drop(v523_9);
        let v523_12: Space = unite(&(v523_7),&(v523_11));
        join_wrapped_into(&mut v522_12_write,&((v523_12).read_zipper()),&[]);
        }
        v522_12_cursor.ascend(1);
      }
      drop(v522_12_cursor);
      drop(v522_12_write);
      compose(&(v511_10),&(v522_12))
    };
    drop(v511_10);
    let v511_14: Space = unite(&(v511_8),&(v511_13));
    join_wrapped_into(&mut v510_28_write,&((v511_14).read_zipper()),&[]);
    }
    v510_28_cursor.ascend(1);
  }
  drop(v510_28_cursor);
  drop(v510_28_write);
  (v510_28).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v532_21 = Space::new();
  let mut v532_21_write = v532_21.write_zipper();
  let mut v532_21_cursor = (*s0).read_zipper();
  let v532_21_origin = v532_21_cursor.path().len();
  for v532_21_byte in v532_21_cursor.child_mask().iter() {
    v532_21_cursor.descend_to_existing_byte(v532_21_byte);
    {
    let v533_2: Space = singleton(&v532_21_cursor.path()[v532_21_origin..(v532_21_origin + 1)]);
    let v533_3: Space = intersect(&(*CONSTANT_2),&(v533_2));
    let v533_4: Space = if has_head(&(v533_3)) { singleton(&[]) } else { Space::new() };
    drop(v533_3);
    let v533_5: Space = subtract(&(*CONSTANT_1),&(v533_4));
    drop(v533_4);
    let v533_8: Space = if (&(v533_5)).is_empty() { Space::new() } else {
      let v534_6: Path = concat_path(&(*p0),&v532_21_cursor.path()[v532_21_origin..(v532_21_origin + 1)]);
      let mut v534_7 = Space::new();
      let mut v534_7_write = v534_7.write_zipper();
      for v534_7_byte in v532_21_cursor.child_mask().iter() {
        v532_21_cursor.descend_to_existing_byte(v534_7_byte);
        {
        let v535_2: Space = singleton(&v532_21_cursor.path()[(v532_21_origin + 1)..(v532_21_origin + 2)]);
        let v535_3: Space = intersect(&(*CONSTANT_2),&(v535_2));
        let v535_4: Space = if has_head(&(v535_3)) { singleton(&[]) } else { Space::new() };
        drop(v535_3);
        let v535_5: Space = subtract(&(*CONSTANT_1),&(v535_4));
        drop(v535_4);
        let v535_8: Space = if (&(v535_5)).is_empty() { Space::new() } else {
          let v536_6: Path = concat_path(&(v534_6),&v532_21_cursor.path()[(v532_21_origin + 1)..(v532_21_origin + 2)]);
          let mut v536_7 = Space::new();
          let mut v536_7_write = v536_7.write_zipper();
          for v536_7_byte in v532_21_cursor.child_mask().iter() {
            v532_21_cursor.descend_to_existing_byte(v536_7_byte);
            {
            let v537_2: Space = singleton(&v532_21_cursor.path()[(v532_21_origin + 2)..(v532_21_origin + 3)]);
            let v537_3: Space = intersect(&(*CONSTANT_2),&(v537_2));
            let v537_4: Space = if has_head(&(v537_3)) { singleton(&[]) } else { Space::new() };
            drop(v537_3);
            let v537_5: Space = subtract(&(*CONSTANT_1),&(v537_4));
            drop(v537_4);
            let v537_8: Space = if (&(v537_5)).is_empty() { Space::new() } else {
              let v538_6: Path = concat_path(&(v536_6),&v532_21_cursor.path()[(v532_21_origin + 2)..(v532_21_origin + 3)]);
              let v538_7: Space = routine_40(c, &(v538_6), &(*p1), &v532_21_cursor);
              compose(&(v537_5),&(v538_7))
            };
            drop(v537_5);
            let v537_9: Space = intersect(&(*CONSTANT_2),&(v537_2));
            drop(v537_2);
            let v537_10: Space = if has_head(&(v537_9)) { singleton(&[]) } else { Space::new() };
            drop(v537_9);
            let v537_12: Space = if (&(v537_10)).is_empty() { Space::new() } else {
              let v539_6: Path = concat_path(&(v536_6),&v532_21_cursor.path()[(v532_21_origin + 2)..(v532_21_origin + 3)]);
              let v539_11: Space = routine_41(c, &(v539_6), &(*p1), &v532_21_cursor);
              drop(v539_6);
              compose(&(v537_10),&(v539_11))
            };
            drop(v537_10);
            let v537_13: Space = unite(&(v537_8),&(v537_12));
            join_wrapped_into(&mut v536_7_write,&((v537_13).read_zipper()),&[]);
            }
            v532_21_cursor.ascend(1);
          }
          drop(v536_7_write);
          compose(&(v535_5),&(v536_7))
        };
        drop(v535_5);
        let v535_9: Space = intersect(&(*CONSTANT_2),&(v535_2));
        drop(v535_2);
        let v535_10: Space = if has_head(&(v535_9)) { singleton(&[]) } else { Space::new() };
        drop(v535_9);
        let v535_12: Space = if (&(v535_10)).is_empty() { Space::new() } else {
          let v540_6: Path = concat_path(&(v534_6),&v532_21_cursor.path()[(v532_21_origin + 1)..(v532_21_origin + 2)]);
          let mut v540_11 = Space::new();
          let mut v540_11_write = v540_11.write_zipper();
          for v540_11_byte in v532_21_cursor.child_mask().iter() {
            v532_21_cursor.descend_to_existing_byte(v540_11_byte);
            {
            let v541_2: Space = singleton(&v532_21_cursor.path()[(v532_21_origin + 2)..(v532_21_origin + 3)]);
            let v541_3: Space = intersect(&(*CONSTANT_2),&(v541_2));
            let v541_4: Space = if has_head(&(v541_3)) { singleton(&[]) } else { Space::new() };
            drop(v541_3);
            let v541_5: Space = subtract(&(*CONSTANT_1),&(v541_4));
            drop(v541_4);
            let v541_8: Space = if (&(v541_5)).is_empty() { Space::new() } else {
              let v542_6: Path = concat_path(&(v540_6),&v532_21_cursor.path()[(v532_21_origin + 2)..(v532_21_origin + 3)]);
              let v542_7: Space = routine_40(c, &(v542_6), &(*p1), &v532_21_cursor);
              compose(&(v541_5),&(v542_7))
            };
            drop(v541_5);
            let v541_9: Space = intersect(&(*CONSTANT_2),&(v541_2));
            drop(v541_2);
            let v541_10: Space = if has_head(&(v541_9)) { singleton(&[]) } else { Space::new() };
            drop(v541_9);
            let v541_12: Space = if (&(v541_10)).is_empty() { Space::new() } else {
              let v543_6: Path = concat_path(&(v540_6),&v532_21_cursor.path()[(v532_21_origin + 2)..(v532_21_origin + 3)]);
              let v543_11: Space = routine_19(c, &(v543_6), &(*p1), &v532_21_cursor);
              drop(v543_6);
              compose(&(v541_10),&(v543_11))
            };
            drop(v541_10);
            let v541_13: Space = unite(&(v541_8),&(v541_12));
            join_wrapped_into(&mut v540_11_write,&((v541_13).read_zipper()),&[]);
            }
            v532_21_cursor.ascend(1);
          }
          drop(v540_11_write);
          drop(v540_6);
          compose(&(v535_10),&(v540_11))
        };
        drop(v535_10);
        let v535_13: Space = unite(&(v535_8),&(v535_12));
        join_wrapped_into(&mut v534_7_write,&((v535_13).read_zipper()),&[]);
        }
        v532_21_cursor.ascend(1);
      }
      drop(v534_7_write);
      compose(&(v533_5),&(v534_7))
    };
    drop(v533_5);
    let v533_9: Space = intersect(&(*CONSTANT_2),&(v533_2));
    drop(v533_2);
    let v533_10: Space = if has_head(&(v533_9)) { singleton(&[]) } else { Space::new() };
    drop(v533_9);
    let v533_12: Space = if (&(v533_10)).is_empty() { Space::new() } else {
      let v544_6: Path = concat_path(&(*p0),&v532_21_cursor.path()[v532_21_origin..(v532_21_origin + 1)]);
      let mut v544_11 = Space::new();
      let mut v544_11_write = v544_11.write_zipper();
      for v544_11_byte in v532_21_cursor.child_mask().iter() {
        v532_21_cursor.descend_to_existing_byte(v544_11_byte);
        {
        let v545_2: Space = singleton(&v532_21_cursor.path()[(v532_21_origin + 1)..(v532_21_origin + 2)]);
        let v545_3: Space = intersect(&(*CONSTANT_2),&(v545_2));
        let v545_4: Space = if has_head(&(v545_3)) { singleton(&[]) } else { Space::new() };
        drop(v545_3);
        let v545_5: Space = subtract(&(*CONSTANT_1),&(v545_4));
        drop(v545_4);
        let v545_8: Space = if (&(v545_5)).is_empty() { Space::new() } else {
          let v546_6: Path = concat_path(&(v544_6),&v532_21_cursor.path()[(v532_21_origin + 1)..(v532_21_origin + 2)]);
          let mut v546_7 = Space::new();
          let mut v546_7_write = v546_7.write_zipper();
          for v546_7_byte in v532_21_cursor.child_mask().iter() {
            v532_21_cursor.descend_to_existing_byte(v546_7_byte);
            {
            let v547_2: Space = singleton(&v532_21_cursor.path()[(v532_21_origin + 2)..(v532_21_origin + 3)]);
            let v547_3: Space = intersect(&(*CONSTANT_2),&(v547_2));
            let v547_4: Space = if has_head(&(v547_3)) { singleton(&[]) } else { Space::new() };
            drop(v547_3);
            let v547_5: Space = subtract(&(*CONSTANT_1),&(v547_4));
            drop(v547_4);
            let v547_8: Space = if (&(v547_5)).is_empty() { Space::new() } else {
              let v548_6: Path = concat_path(&(v546_6),&v532_21_cursor.path()[(v532_21_origin + 2)..(v532_21_origin + 3)]);
              let v548_7: Space = routine_40(c, &(v548_6), &(*p1), &v532_21_cursor);
              compose(&(v547_5),&(v548_7))
            };
            drop(v547_5);
            let v547_9: Space = intersect(&(*CONSTANT_2),&(v547_2));
            drop(v547_2);
            let v547_10: Space = if has_head(&(v547_9)) { singleton(&[]) } else { Space::new() };
            drop(v547_9);
            let v547_12: Space = if (&(v547_10)).is_empty() { Space::new() } else {
              let v549_6: Path = concat_path(&(v546_6),&v532_21_cursor.path()[(v532_21_origin + 2)..(v532_21_origin + 3)]);
              let v549_11: Space = routine_41(c, &(v549_6), &(*p1), &v532_21_cursor);
              drop(v549_6);
              compose(&(v547_10),&(v549_11))
            };
            drop(v547_10);
            let v547_13: Space = unite(&(v547_8),&(v547_12));
            join_wrapped_into(&mut v546_7_write,&((v547_13).read_zipper()),&[]);
            }
            v532_21_cursor.ascend(1);
          }
          drop(v546_7_write);
          compose(&(v545_5),&(v546_7))
        };
        drop(v545_5);
        let v545_9: Space = intersect(&(*CONSTANT_2),&(v545_2));
        drop(v545_2);
        let v545_10: Space = if has_head(&(v545_9)) { singleton(&[]) } else { Space::new() };
        drop(v545_9);
        let v545_11: Space = compose(&(v545_10),&v532_21_cursor);
        drop(v545_10);
        let v550_6: Path = concat_path(&(v544_6),&v532_21_cursor.path()[(v532_21_origin + 1)..(v532_21_origin + 2)]);
        let v545_12: Space = wrap(&(v545_11),&(v550_6));
        drop(v545_11);
        let v545_13: Space = wrap(&(v545_12),&(*p1));
        drop(v545_12);
        let v545_14: Space = unite(&(v545_8),&(v545_13));
        drop(v545_13);
        join_wrapped_into(&mut v544_11_write,&((v545_14).read_zipper()),&[]);
        }
        v532_21_cursor.ascend(1);
      }
      drop(v544_11_write);
      drop(v544_6);
      compose(&(v533_10),&(v544_11))
    };
    drop(v533_10);
    let v533_13: Space = unite(&(v533_8),&(v533_12));
    join_wrapped_into(&mut v532_21_write,&((v533_13).read_zipper()),&[]);
    }
    v532_21_cursor.ascend(1);
  }
  drop(v532_21_cursor);
  drop(v532_21_write);
  (v532_21).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v551_15 = Space::new();
  let mut v551_15_write = v551_15.write_zipper();
  let mut v551_15_cursor = (*s0).read_zipper();
  let v551_15_origin = v551_15_cursor.path().len();
  for v551_15_byte in v551_15_cursor.child_mask().iter() {
    v551_15_cursor.descend_to_existing_byte(v551_15_byte);
    {
    let v552_2: Space = singleton(&v551_15_cursor.path()[v551_15_origin..(v551_15_origin + 1)]);
    let v552_3: Space = intersect(&(*CONSTANT_2),&(v552_2));
    let v552_4: Space = if has_head(&(v552_3)) { singleton(&[]) } else { Space::new() };
    drop(v552_3);
    let v552_5: Space = subtract(&(*CONSTANT_1),&(v552_4));
    drop(v552_4);
    let v552_8: Space = if (&(v552_5)).is_empty() { Space::new() } else {
      let v553_6: Path = concat_path(&(*p0),&v551_15_cursor.path()[v551_15_origin..(v551_15_origin + 1)]);
      let mut v553_7 = Space::new();
      let mut v553_7_write = v553_7.write_zipper();
      for v553_7_byte in v551_15_cursor.child_mask().iter() {
        v551_15_cursor.descend_to_existing_byte(v553_7_byte);
        {
        let v554_2: Space = singleton(&v551_15_cursor.path()[(v551_15_origin + 1)..(v551_15_origin + 2)]);
        let v554_3: Space = intersect(&(*CONSTANT_2),&(v554_2));
        let v554_4: Space = if has_head(&(v554_3)) { singleton(&[]) } else { Space::new() };
        drop(v554_3);
        let v554_5: Space = subtract(&(*CONSTANT_1),&(v554_4));
        drop(v554_4);
        let v554_8: Space = if (&(v554_5)).is_empty() { Space::new() } else {
          let v555_6: Path = concat_path(&(v553_6),&v551_15_cursor.path()[(v551_15_origin + 1)..(v551_15_origin + 2)]);
          let mut v555_7 = Space::new();
          let mut v555_7_write = v555_7.write_zipper();
          for v555_7_byte in v551_15_cursor.child_mask().iter() {
            v551_15_cursor.descend_to_existing_byte(v555_7_byte);
            {
            let v556_2: Space = singleton(&v551_15_cursor.path()[(v551_15_origin + 2)..(v551_15_origin + 3)]);
            let v556_3: Space = intersect(&(*CONSTANT_2),&(v556_2));
            let v556_4: Space = if has_head(&(v556_3)) { singleton(&[]) } else { Space::new() };
            drop(v556_3);
            let v556_5: Space = subtract(&(*CONSTANT_1),&(v556_4));
            drop(v556_4);
            let v556_8: Space = if (&(v556_5)).is_empty() { Space::new() } else {
              let v557_6: Path = concat_path(&(v555_6),&v551_15_cursor.path()[(v551_15_origin + 2)..(v551_15_origin + 3)]);
              let v557_7: Space = routine_40(c, &(v557_6), &(*p1), &v551_15_cursor);
              compose(&(v556_5),&(v557_7))
            };
            drop(v556_5);
            let v556_9: Space = intersect(&(*CONSTANT_2),&(v556_2));
            drop(v556_2);
            let v556_10: Space = if has_head(&(v556_9)) { singleton(&[]) } else { Space::new() };
            drop(v556_9);
            let v556_12: Space = if (&(v556_10)).is_empty() { Space::new() } else {
              let v558_6: Path = concat_path(&(v555_6),&v551_15_cursor.path()[(v551_15_origin + 2)..(v551_15_origin + 3)]);
              let v558_11: Space = routine_41(c, &(v558_6), &(*p1), &v551_15_cursor);
              drop(v558_6);
              compose(&(v556_10),&(v558_11))
            };
            drop(v556_10);
            let v556_13: Space = unite(&(v556_8),&(v556_12));
            join_wrapped_into(&mut v555_7_write,&((v556_13).read_zipper()),&[]);
            }
            v551_15_cursor.ascend(1);
          }
          drop(v555_7_write);
          compose(&(v554_5),&(v555_7))
        };
        drop(v554_5);
        let v554_9: Space = intersect(&(*CONSTANT_2),&(v554_2));
        drop(v554_2);
        let v554_10: Space = if has_head(&(v554_9)) { singleton(&[]) } else { Space::new() };
        drop(v554_9);
        let v554_12: Space = if (&(v554_10)).is_empty() { Space::new() } else {
          let v559_6: Path = concat_path(&(v553_6),&v551_15_cursor.path()[(v551_15_origin + 1)..(v551_15_origin + 2)]);
          let mut v559_11 = Space::new();
          let mut v559_11_write = v559_11.write_zipper();
          for v559_11_byte in v551_15_cursor.child_mask().iter() {
            v551_15_cursor.descend_to_existing_byte(v559_11_byte);
            {
            let v560_2: Space = singleton(&v551_15_cursor.path()[(v551_15_origin + 2)..(v551_15_origin + 3)]);
            let v560_3: Space = intersect(&(*CONSTANT_2),&(v560_2));
            let v560_4: Space = if has_head(&(v560_3)) { singleton(&[]) } else { Space::new() };
            drop(v560_3);
            let v560_5: Space = subtract(&(*CONSTANT_1),&(v560_4));
            drop(v560_4);
            let v560_8: Space = if (&(v560_5)).is_empty() { Space::new() } else {
              let v561_6: Path = concat_path(&(v559_6),&v551_15_cursor.path()[(v551_15_origin + 2)..(v551_15_origin + 3)]);
              let v561_7: Space = routine_40(c, &(v561_6), &(*p1), &v551_15_cursor);
              compose(&(v560_5),&(v561_7))
            };
            drop(v560_5);
            let v560_9: Space = intersect(&(*CONSTANT_2),&(v560_2));
            drop(v560_2);
            let v560_10: Space = if has_head(&(v560_9)) { singleton(&[]) } else { Space::new() };
            drop(v560_9);
            let v560_12: Space = if (&(v560_10)).is_empty() { Space::new() } else {
              let v562_6: Path = concat_path(&(v559_6),&v551_15_cursor.path()[(v551_15_origin + 2)..(v551_15_origin + 3)]);
              let v562_11: Space = routine_19(c, &(v562_6), &(*p1), &v551_15_cursor);
              drop(v562_6);
              compose(&(v560_10),&(v562_11))
            };
            drop(v560_10);
            let v560_13: Space = unite(&(v560_8),&(v560_12));
            join_wrapped_into(&mut v559_11_write,&((v560_13).read_zipper()),&[]);
            }
            v551_15_cursor.ascend(1);
          }
          drop(v559_11_write);
          drop(v559_6);
          compose(&(v554_10),&(v559_11))
        };
        drop(v554_10);
        let v554_13: Space = unite(&(v554_8),&(v554_12));
        join_wrapped_into(&mut v553_7_write,&((v554_13).read_zipper()),&[]);
        }
        v551_15_cursor.ascend(1);
      }
      drop(v553_7_write);
      compose(&(v552_5),&(v553_7))
    };
    drop(v552_5);
    let v552_9: Space = intersect(&(*CONSTANT_2),&(v552_2));
    drop(v552_2);
    let v552_10: Space = if has_head(&(v552_9)) { singleton(&[]) } else { Space::new() };
    drop(v552_9);
    let v552_11: Space = compose(&(v552_10),&v551_15_cursor);
    drop(v552_10);
    let v563_6: Path = concat_path(&(*p0),&v551_15_cursor.path()[v551_15_origin..(v551_15_origin + 1)]);
    let v552_12: Space = wrap(&(v552_11),&(v563_6));
    drop(v552_11);
    let v552_13: Space = wrap(&(v552_12),&(*p1));
    drop(v552_12);
    let v552_14: Space = unite(&(v552_8),&(v552_13));
    drop(v552_13);
    join_wrapped_into(&mut v551_15_write,&((v552_14).read_zipper()),&[]);
    }
    v551_15_cursor.ascend(1);
  }
  drop(v551_15_cursor);
  drop(v551_15_write);
  (v551_15).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v564_28 = Space::new();
  let mut v564_28_write = v564_28.write_zipper();
  let mut v564_28_cursor = (*s0).read_zipper();
  let v564_28_origin = v564_28_cursor.path().len();
  for v564_28_byte in v564_28_cursor.child_mask().iter() {
    v564_28_cursor.descend_to_existing_byte(v564_28_byte);
    {
    let v565_2: Space = singleton(&v564_28_cursor.path()[v564_28_origin..(v564_28_origin + 1)]);
    let v565_3: Space = intersect(&(*CONSTANT_2),&(v565_2));
    let v565_4: Space = if has_head(&(v565_3)) { singleton(&[]) } else { Space::new() };
    drop(v565_3);
    let v565_5: Space = subtract(&(*CONSTANT_1),&(v565_4));
    drop(v565_4);
    let v565_8: Space = if (&(v565_5)).is_empty() { Space::new() } else {
      let v566_6: Path = concat_path(&(*p0),&v564_28_cursor.path()[v564_28_origin..(v564_28_origin + 1)]);
      let mut v566_7 = Space::new();
      let mut v566_7_write = v566_7.write_zipper();
      for v566_7_byte in v564_28_cursor.child_mask().iter() {
        v564_28_cursor.descend_to_existing_byte(v566_7_byte);
        {
        let v567_2: Space = singleton(&v564_28_cursor.path()[(v564_28_origin + 1)..(v564_28_origin + 2)]);
        let v567_3: Space = intersect(&(*CONSTANT_2),&(v567_2));
        let v567_4: Space = if has_head(&(v567_3)) { singleton(&[]) } else { Space::new() };
        drop(v567_3);
        let v567_5: Space = subtract(&(*CONSTANT_1),&(v567_4));
        drop(v567_4);
        let v567_8: Space = if (&(v567_5)).is_empty() { Space::new() } else {
          let v568_6: Path = concat_path(&(v566_6),&v564_28_cursor.path()[(v564_28_origin + 1)..(v564_28_origin + 2)]);
          let mut v568_7 = Space::new();
          let mut v568_7_write = v568_7.write_zipper();
          for v568_7_byte in v564_28_cursor.child_mask().iter() {
            v564_28_cursor.descend_to_existing_byte(v568_7_byte);
            {
            let v569_2: Space = singleton(&v564_28_cursor.path()[(v564_28_origin + 2)..(v564_28_origin + 3)]);
            let v569_3: Space = intersect(&(*CONSTANT_2),&(v569_2));
            let v569_4: Space = if has_head(&(v569_3)) { singleton(&[]) } else { Space::new() };
            drop(v569_3);
            let v569_5: Space = subtract(&(*CONSTANT_1),&(v569_4));
            drop(v569_4);
            let v569_8: Space = if (&(v569_5)).is_empty() { Space::new() } else {
              let v570_6: Path = concat_path(&(v568_6),&v564_28_cursor.path()[(v564_28_origin + 2)..(v564_28_origin + 3)]);
              let v570_7: Space = routine_42(c, &(v570_6), &(*p1), &v564_28_cursor, &(*s1));
              compose(&(v569_5),&(v570_7))
            };
            drop(v569_5);
            let v569_9: Space = intersect(&(*CONSTANT_2),&(v569_2));
            drop(v569_2);
            let v569_10: Space = if has_head(&(v569_9)) { singleton(&[]) } else { Space::new() };
            drop(v569_9);
            let v569_12: Space = if (&(v569_10)).is_empty() { Space::new() } else {
              let v571_6: Path = concat_path(&(v568_6),&v564_28_cursor.path()[(v564_28_origin + 2)..(v564_28_origin + 3)]);
              let v571_11: Space = routine_43(c, &(v571_6), &(*p1), &v564_28_cursor, &(*s1));
              drop(v571_6);
              compose(&(v569_10),&(v571_11))
            };
            drop(v569_10);
            let v569_13: Space = unite(&(v569_8),&(v569_12));
            join_wrapped_into(&mut v568_7_write,&((v569_13).read_zipper()),&[]);
            }
            v564_28_cursor.ascend(1);
          }
          drop(v568_7_write);
          compose(&(v567_5),&(v568_7))
        };
        drop(v567_5);
        let v567_9: Space = intersect(&(*CONSTANT_2),&(v567_2));
        drop(v567_2);
        let v567_10: Space = if has_head(&(v567_9)) { singleton(&[]) } else { Space::new() };
        drop(v567_9);
        let v567_12: Space = if (&(v567_10)).is_empty() { Space::new() } else {
          let v572_6: Path = concat_path(&(v566_6),&v564_28_cursor.path()[(v564_28_origin + 1)..(v564_28_origin + 2)]);
          let mut v572_11 = Space::new();
          let mut v572_11_write = v572_11.write_zipper();
          for v572_11_byte in v564_28_cursor.child_mask().iter() {
            v564_28_cursor.descend_to_existing_byte(v572_11_byte);
            {
            let v573_2: Space = singleton(&v564_28_cursor.path()[(v564_28_origin + 2)..(v564_28_origin + 3)]);
            let v573_3: Space = intersect(&(*CONSTANT_2),&(v573_2));
            let v573_4: Space = if has_head(&(v573_3)) { singleton(&[]) } else { Space::new() };
            drop(v573_3);
            let v573_5: Space = subtract(&(*CONSTANT_1),&(v573_4));
            drop(v573_4);
            let v573_8: Space = if (&(v573_5)).is_empty() { Space::new() } else {
              let v574_6: Path = concat_path(&(v572_6),&v564_28_cursor.path()[(v564_28_origin + 2)..(v564_28_origin + 3)]);
              let v574_7: Space = routine_42(c, &(v574_6), &(*p1), &v564_28_cursor, &(*s1));
              compose(&(v573_5),&(v574_7))
            };
            drop(v573_5);
            let v573_9: Space = intersect(&(*CONSTANT_2),&(v573_2));
            drop(v573_2);
            let v573_10: Space = if has_head(&(v573_9)) { singleton(&[]) } else { Space::new() };
            drop(v573_9);
            let v573_12: Space = if (&(v573_10)).is_empty() { Space::new() } else {
              let v575_6: Path = concat_path(&(v572_6),&v564_28_cursor.path()[(v564_28_origin + 2)..(v564_28_origin + 3)]);
              let v575_11: Space = routine_10(c, &(v575_6), &(*p1), &v564_28_cursor, &(*s1));
              drop(v575_6);
              compose(&(v573_10),&(v575_11))
            };
            drop(v573_10);
            let v573_13: Space = unite(&(v573_8),&(v573_12));
            join_wrapped_into(&mut v572_11_write,&((v573_13).read_zipper()),&[]);
            }
            v564_28_cursor.ascend(1);
          }
          drop(v572_11_write);
          drop(v572_6);
          compose(&(v567_10),&(v572_11))
        };
        drop(v567_10);
        let v567_13: Space = unite(&(v567_8),&(v567_12));
        join_wrapped_into(&mut v566_7_write,&((v567_13).read_zipper()),&[]);
        }
        v564_28_cursor.ascend(1);
      }
      drop(v566_7_write);
      compose(&(v565_5),&(v566_7))
    };
    drop(v565_5);
    let v565_9: Space = intersect(&(*CONSTANT_2),&(v565_2));
    drop(v565_2);
    let v565_10: Space = if has_head(&(v565_9)) { singleton(&[]) } else { Space::new() };
    drop(v565_9);
    let v565_13: Space = if (&(v565_10)).is_empty() { Space::new() } else {
      let v576_6: Path = concat_path(&(*p0),&v564_28_cursor.path()[v564_28_origin..(v564_28_origin + 1)]);
      let mut v576_12 = Space::new();
      let mut v576_12_write = v576_12.write_zipper();
      for v576_12_byte in v564_28_cursor.child_mask().iter() {
        v564_28_cursor.descend_to_existing_byte(v576_12_byte);
        {
        let v577_2: Space = singleton(&v564_28_cursor.path()[(v564_28_origin + 1)..(v564_28_origin + 2)]);
        let v577_3: Space = intersect(&(*CONSTANT_2),&(v577_2));
        let v577_4: Space = if has_head(&(v577_3)) { singleton(&[]) } else { Space::new() };
        drop(v577_3);
        let v577_5: Space = subtract(&(*CONSTANT_1),&(v577_4));
        drop(v577_4);
        let v577_8: Space = if (&(v577_5)).is_empty() { Space::new() } else {
          let v578_6: Path = concat_path(&(v576_6),&v564_28_cursor.path()[(v564_28_origin + 1)..(v564_28_origin + 2)]);
          let mut v578_7 = Space::new();
          let mut v578_7_write = v578_7.write_zipper();
          for v578_7_byte in v564_28_cursor.child_mask().iter() {
            v564_28_cursor.descend_to_existing_byte(v578_7_byte);
            {
            let v579_2: Space = singleton(&v564_28_cursor.path()[(v564_28_origin + 2)..(v564_28_origin + 3)]);
            let v579_3: Space = intersect(&(*CONSTANT_2),&(v579_2));
            let v579_4: Space = if has_head(&(v579_3)) { singleton(&[]) } else { Space::new() };
            drop(v579_3);
            let v579_5: Space = subtract(&(*CONSTANT_1),&(v579_4));
            drop(v579_4);
            let v579_8: Space = if (&(v579_5)).is_empty() { Space::new() } else {
              let v580_6: Path = concat_path(&(v578_6),&v564_28_cursor.path()[(v564_28_origin + 2)..(v564_28_origin + 3)]);
              let v580_7: Space = routine_42(c, &(v580_6), &(*p1), &v564_28_cursor, &(*s1));
              compose(&(v579_5),&(v580_7))
            };
            drop(v579_5);
            let v579_9: Space = intersect(&(*CONSTANT_2),&(v579_2));
            drop(v579_2);
            let v579_10: Space = if has_head(&(v579_9)) { singleton(&[]) } else { Space::new() };
            drop(v579_9);
            let v579_12: Space = if (&(v579_10)).is_empty() { Space::new() } else {
              let v581_6: Path = concat_path(&(v578_6),&v564_28_cursor.path()[(v564_28_origin + 2)..(v564_28_origin + 3)]);
              let v581_11: Space = routine_43(c, &(v581_6), &(*p1), &v564_28_cursor, &(*s1));
              drop(v581_6);
              compose(&(v579_10),&(v581_11))
            };
            drop(v579_10);
            let v579_13: Space = unite(&(v579_8),&(v579_12));
            join_wrapped_into(&mut v578_7_write,&((v579_13).read_zipper()),&[]);
            }
            v564_28_cursor.ascend(1);
          }
          drop(v578_7_write);
          drop(v578_6);
          compose(&(v577_5),&(v578_7))
        };
        drop(v577_5);
        let v577_9: Space = intersect(&(*CONSTANT_2),&(v577_2));
        drop(v577_2);
        let v577_10: Space = if has_head(&(v577_9)) { singleton(&[]) } else { Space::new() };
        drop(v577_9);
        let v577_13: Space = if (&(v577_10)).is_empty() { Space::new() } else {
          let mut v582_12 = Space::new();
          let mut v582_12_write = v582_12.write_zipper();
          let mut v582_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v564_28_cursor.path()[v564_28_origin..(v564_28_origin + 1)]),&v564_28_cursor.path()[(v564_28_origin + 1)..(v564_28_origin + 2)]);
          let v582_12_origin = v582_12_cursor.path().len();
          for v582_12_byte in v582_12_cursor.child_mask().iter() {
            v582_12_cursor.descend_to_existing_byte(v582_12_byte);
            {
            let v583_2: Space = singleton(&v582_12_cursor.path()[v582_12_origin..(v582_12_origin + 1)]);
            let v583_3: Space = intersect(&(*CONSTANT_2),&(v583_2));
            let v583_4: Space = if has_head(&(v583_3)) { singleton(&[]) } else { Space::new() };
            drop(v583_3);
            let v583_5: Space = subtract(&(*CONSTANT_1),&(v583_4));
            drop(v583_4);
            let v583_7: Space = if (&(v583_5)).is_empty() { Space::new() } else {
              let v584_6: Space = routine_13(c, &v582_12_cursor.path()[v582_12_origin..(v582_12_origin + 1)], &(*p1), &v582_12_cursor);
              compose(&(v583_5),&(v584_6))
            };
            drop(v583_5);
            let v583_8: Space = intersect(&(*CONSTANT_2),&(v583_2));
            drop(v583_2);
            let v583_9: Space = if has_head(&(v583_8)) { singleton(&[]) } else { Space::new() };
            drop(v583_8);
            let v583_11: Space = if (&(v583_9)).is_empty() { Space::new() } else {
              let v585_10: Space = routine_14(c, &v582_12_cursor.path()[v582_12_origin..(v582_12_origin + 1)], &(*p1), &v582_12_cursor);
              compose(&(v583_9),&(v585_10))
            };
            drop(v583_9);
            let v583_12: Space = unite(&(v583_7),&(v583_11));
            join_wrapped_into(&mut v582_12_write,&((v583_12).read_zipper()),&[]);
            }
            v582_12_cursor.ascend(1);
          }
          drop(v582_12_cursor);
          drop(v582_12_write);
          compose(&(v577_10),&(v582_12))
        };
        drop(v577_10);
        let v577_14: Space = unite(&(v577_8),&(v577_13));
        join_wrapped_into(&mut v576_12_write,&((v577_14).read_zipper()),&[]);
        }
        v564_28_cursor.ascend(1);
      }
      drop(v576_12_write);
      drop(v576_6);
      compose(&(v565_10),&(v576_12))
    };
    drop(v565_10);
    let v565_14: Space = unite(&(v565_8),&(v565_13));
    join_wrapped_into(&mut v564_28_write,&((v565_14).read_zipper()),&[]);
    }
    v564_28_cursor.ascend(1);
  }
  drop(v564_28_cursor);
  drop(v564_28_write);
  (v564_28).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v586_28 = Space::new();
  let mut v586_28_write = v586_28.write_zipper();
  let mut v586_28_cursor = (*s0).read_zipper();
  let v586_28_origin = v586_28_cursor.path().len();
  for v586_28_byte in v586_28_cursor.child_mask().iter() {
    v586_28_cursor.descend_to_existing_byte(v586_28_byte);
    {
    let v587_2: Space = singleton(&v586_28_cursor.path()[v586_28_origin..(v586_28_origin + 1)]);
    let v587_3: Space = intersect(&(*CONSTANT_2),&(v587_2));
    let v587_4: Space = if has_head(&(v587_3)) { singleton(&[]) } else { Space::new() };
    drop(v587_3);
    let v587_5: Space = subtract(&(*CONSTANT_1),&(v587_4));
    drop(v587_4);
    let v587_8: Space = if (&(v587_5)).is_empty() { Space::new() } else {
      let v588_6: Path = concat_path(&(*p0),&v586_28_cursor.path()[v586_28_origin..(v586_28_origin + 1)]);
      let mut v588_7 = Space::new();
      let mut v588_7_write = v588_7.write_zipper();
      for v588_7_byte in v586_28_cursor.child_mask().iter() {
        v586_28_cursor.descend_to_existing_byte(v588_7_byte);
        {
        let v589_2: Space = singleton(&v586_28_cursor.path()[(v586_28_origin + 1)..(v586_28_origin + 2)]);
        let v589_3: Space = intersect(&(*CONSTANT_2),&(v589_2));
        let v589_4: Space = if has_head(&(v589_3)) { singleton(&[]) } else { Space::new() };
        drop(v589_3);
        let v589_5: Space = subtract(&(*CONSTANT_1),&(v589_4));
        drop(v589_4);
        let v589_8: Space = if (&(v589_5)).is_empty() { Space::new() } else {
          let v590_6: Path = concat_path(&(v588_6),&v586_28_cursor.path()[(v586_28_origin + 1)..(v586_28_origin + 2)]);
          let mut v590_7 = Space::new();
          let mut v590_7_write = v590_7.write_zipper();
          for v590_7_byte in v586_28_cursor.child_mask().iter() {
            v586_28_cursor.descend_to_existing_byte(v590_7_byte);
            {
            let v591_2: Space = singleton(&v586_28_cursor.path()[(v586_28_origin + 2)..(v586_28_origin + 3)]);
            let v591_3: Space = intersect(&(*CONSTANT_2),&(v591_2));
            let v591_4: Space = if has_head(&(v591_3)) { singleton(&[]) } else { Space::new() };
            drop(v591_3);
            let v591_5: Space = subtract(&(*CONSTANT_1),&(v591_4));
            drop(v591_4);
            let v591_8: Space = if (&(v591_5)).is_empty() { Space::new() } else {
              let v592_6: Path = concat_path(&(v590_6),&v586_28_cursor.path()[(v586_28_origin + 2)..(v586_28_origin + 3)]);
              let v592_7: Space = routine_42(c, &(v592_6), &(*p1), &v586_28_cursor, &(*s1));
              compose(&(v591_5),&(v592_7))
            };
            drop(v591_5);
            let v591_9: Space = intersect(&(*CONSTANT_2),&(v591_2));
            drop(v591_2);
            let v591_10: Space = if has_head(&(v591_9)) { singleton(&[]) } else { Space::new() };
            drop(v591_9);
            let v591_12: Space = if (&(v591_10)).is_empty() { Space::new() } else {
              let v593_6: Path = concat_path(&(v590_6),&v586_28_cursor.path()[(v586_28_origin + 2)..(v586_28_origin + 3)]);
              let v593_11: Space = routine_43(c, &(v593_6), &(*p1), &v586_28_cursor, &(*s1));
              drop(v593_6);
              compose(&(v591_10),&(v593_11))
            };
            drop(v591_10);
            let v591_13: Space = unite(&(v591_8),&(v591_12));
            join_wrapped_into(&mut v590_7_write,&((v591_13).read_zipper()),&[]);
            }
            v586_28_cursor.ascend(1);
          }
          drop(v590_7_write);
          compose(&(v589_5),&(v590_7))
        };
        drop(v589_5);
        let v589_9: Space = intersect(&(*CONSTANT_2),&(v589_2));
        drop(v589_2);
        let v589_10: Space = if has_head(&(v589_9)) { singleton(&[]) } else { Space::new() };
        drop(v589_9);
        let v589_12: Space = if (&(v589_10)).is_empty() { Space::new() } else {
          let v594_6: Path = concat_path(&(v588_6),&v586_28_cursor.path()[(v586_28_origin + 1)..(v586_28_origin + 2)]);
          let mut v594_11 = Space::new();
          let mut v594_11_write = v594_11.write_zipper();
          for v594_11_byte in v586_28_cursor.child_mask().iter() {
            v586_28_cursor.descend_to_existing_byte(v594_11_byte);
            {
            let v595_2: Space = singleton(&v586_28_cursor.path()[(v586_28_origin + 2)..(v586_28_origin + 3)]);
            let v595_3: Space = intersect(&(*CONSTANT_2),&(v595_2));
            let v595_4: Space = if has_head(&(v595_3)) { singleton(&[]) } else { Space::new() };
            drop(v595_3);
            let v595_5: Space = subtract(&(*CONSTANT_1),&(v595_4));
            drop(v595_4);
            let v595_8: Space = if (&(v595_5)).is_empty() { Space::new() } else {
              let v596_6: Path = concat_path(&(v594_6),&v586_28_cursor.path()[(v586_28_origin + 2)..(v586_28_origin + 3)]);
              let v596_7: Space = routine_42(c, &(v596_6), &(*p1), &v586_28_cursor, &(*s1));
              compose(&(v595_5),&(v596_7))
            };
            drop(v595_5);
            let v595_9: Space = intersect(&(*CONSTANT_2),&(v595_2));
            drop(v595_2);
            let v595_10: Space = if has_head(&(v595_9)) { singleton(&[]) } else { Space::new() };
            drop(v595_9);
            let v595_12: Space = if (&(v595_10)).is_empty() { Space::new() } else {
              let v597_6: Path = concat_path(&(v594_6),&v586_28_cursor.path()[(v586_28_origin + 2)..(v586_28_origin + 3)]);
              let v597_11: Space = routine_10(c, &(v597_6), &(*p1), &v586_28_cursor, &(*s1));
              drop(v597_6);
              compose(&(v595_10),&(v597_11))
            };
            drop(v595_10);
            let v595_13: Space = unite(&(v595_8),&(v595_12));
            join_wrapped_into(&mut v594_11_write,&((v595_13).read_zipper()),&[]);
            }
            v586_28_cursor.ascend(1);
          }
          drop(v594_11_write);
          drop(v594_6);
          compose(&(v589_10),&(v594_11))
        };
        drop(v589_10);
        let v589_13: Space = unite(&(v589_8),&(v589_12));
        join_wrapped_into(&mut v588_7_write,&((v589_13).read_zipper()),&[]);
        }
        v586_28_cursor.ascend(1);
      }
      drop(v588_7_write);
      drop(v588_6);
      compose(&(v587_5),&(v588_7))
    };
    drop(v587_5);
    let v587_9: Space = intersect(&(*CONSTANT_2),&(v587_2));
    drop(v587_2);
    let v587_10: Space = if has_head(&(v587_9)) { singleton(&[]) } else { Space::new() };
    drop(v587_9);
    let v587_13: Space = if (&(v587_10)).is_empty() { Space::new() } else {
      let mut v598_12 = Space::new();
      let mut v598_12_write = v598_12.write_zipper();
      let mut v598_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v586_28_cursor.path()[v586_28_origin..(v586_28_origin + 1)]);
      let v598_12_origin = v598_12_cursor.path().len();
      for v598_12_byte in v598_12_cursor.child_mask().iter() {
        v598_12_cursor.descend_to_existing_byte(v598_12_byte);
        {
        let v599_2: Space = singleton(&v598_12_cursor.path()[v598_12_origin..(v598_12_origin + 1)]);
        let v599_3: Space = intersect(&(*CONSTANT_2),&(v599_2));
        let v599_4: Space = if has_head(&(v599_3)) { singleton(&[]) } else { Space::new() };
        drop(v599_3);
        let v599_5: Space = subtract(&(*CONSTANT_1),&(v599_4));
        drop(v599_4);
        let v599_7: Space = if (&(v599_5)).is_empty() { Space::new() } else {
          let mut v600_6 = Space::new();
          let mut v600_6_write = v600_6.write_zipper();
          for v600_6_byte in v598_12_cursor.child_mask().iter() {
            v598_12_cursor.descend_to_existing_byte(v600_6_byte);
            {
            let v601_2: Space = singleton(&v598_12_cursor.path()[(v598_12_origin + 1)..(v598_12_origin + 2)]);
            let v601_3: Space = intersect(&(*CONSTANT_2),&(v601_2));
            let v601_4: Space = if has_head(&(v601_3)) { singleton(&[]) } else { Space::new() };
            drop(v601_3);
            let v601_5: Space = subtract(&(*CONSTANT_1),&(v601_4));
            drop(v601_4);
            let v601_8: Space = if (&(v601_5)).is_empty() { Space::new() } else {
              let v602_7: Space = routine_17(c, &v598_12_cursor.path()[v598_12_origin..(v598_12_origin + 2)], &(*p1), &v598_12_cursor);
              compose(&(v601_5),&(v602_7))
            };
            drop(v601_5);
            let v601_9: Space = intersect(&(*CONSTANT_2),&(v601_2));
            drop(v601_2);
            let v601_10: Space = if has_head(&(v601_9)) { singleton(&[]) } else { Space::new() };
            drop(v601_9);
            let v601_12: Space = if (&(v601_10)).is_empty() { Space::new() } else {
              let v603_11: Space = routine_18(c, &v598_12_cursor.path()[v598_12_origin..(v598_12_origin + 2)], &(*p1), &v598_12_cursor);
              compose(&(v601_10),&(v603_11))
            };
            drop(v601_10);
            let v601_13: Space = unite(&(v601_8),&(v601_12));
            join_wrapped_into(&mut v600_6_write,&((v601_13).read_zipper()),&[]);
            }
            v598_12_cursor.ascend(1);
          }
          drop(v600_6_write);
          compose(&(v599_5),&(v600_6))
        };
        drop(v599_5);
        let v599_8: Space = intersect(&(*CONSTANT_2),&(v599_2));
        drop(v599_2);
        let v599_9: Space = if has_head(&(v599_8)) { singleton(&[]) } else { Space::new() };
        drop(v599_8);
        let v599_11: Space = if (&(v599_9)).is_empty() { Space::new() } else {
          let mut v604_10 = Space::new();
          let mut v604_10_write = v604_10.write_zipper();
          for v604_10_byte in v598_12_cursor.child_mask().iter() {
            v598_12_cursor.descend_to_existing_byte(v604_10_byte);
            {
            let v605_2: Space = singleton(&v598_12_cursor.path()[(v598_12_origin + 1)..(v598_12_origin + 2)]);
            let v605_3: Space = intersect(&(*CONSTANT_2),&(v605_2));
            let v605_4: Space = if has_head(&(v605_3)) { singleton(&[]) } else { Space::new() };
            drop(v605_3);
            let v605_5: Space = subtract(&(*CONSTANT_1),&(v605_4));
            drop(v605_4);
            let v605_8: Space = if (&(v605_5)).is_empty() { Space::new() } else {
              let v606_7: Space = routine_17(c, &v598_12_cursor.path()[v598_12_origin..(v598_12_origin + 2)], &(*p1), &v598_12_cursor);
              compose(&(v605_5),&(v606_7))
            };
            drop(v605_5);
            let v605_9: Space = intersect(&(*CONSTANT_2),&(v605_2));
            drop(v605_2);
            let v605_10: Space = if has_head(&(v605_9)) { singleton(&[]) } else { Space::new() };
            drop(v605_9);
            let v605_12: Space = if (&(v605_10)).is_empty() { Space::new() } else {
              let v607_11: Space = routine_19(c, &v598_12_cursor.path()[v598_12_origin..(v598_12_origin + 2)], &(*p1), &v598_12_cursor);
              compose(&(v605_10),&(v607_11))
            };
            drop(v605_10);
            let v605_13: Space = unite(&(v605_8),&(v605_12));
            join_wrapped_into(&mut v604_10_write,&((v605_13).read_zipper()),&[]);
            }
            v598_12_cursor.ascend(1);
          }
          drop(v604_10_write);
          compose(&(v599_9),&(v604_10))
        };
        drop(v599_9);
        let v599_12: Space = unite(&(v599_7),&(v599_11));
        join_wrapped_into(&mut v598_12_write,&((v599_12).read_zipper()),&[]);
        }
        v598_12_cursor.ascend(1);
      }
      drop(v598_12_cursor);
      drop(v598_12_write);
      compose(&(v587_10),&(v598_12))
    };
    drop(v587_10);
    let v587_14: Space = unite(&(v587_8),&(v587_13));
    join_wrapped_into(&mut v586_28_write,&((v587_14).read_zipper()),&[]);
    }
    v586_28_cursor.ascend(1);
  }
  drop(v586_28_cursor);
  drop(v586_28_write);
  (v586_28).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v608_21 = Space::new();
  let mut v608_21_write = v608_21.write_zipper();
  let mut v608_21_cursor = (*s0).read_zipper();
  let v608_21_origin = v608_21_cursor.path().len();
  for v608_21_byte in v608_21_cursor.child_mask().iter() {
    v608_21_cursor.descend_to_existing_byte(v608_21_byte);
    {
    let v609_2: Space = singleton(&v608_21_cursor.path()[v608_21_origin..(v608_21_origin + 1)]);
    let v609_3: Space = intersect(&(*CONSTANT_2),&(v609_2));
    let v609_4: Space = if has_head(&(v609_3)) { singleton(&[]) } else { Space::new() };
    drop(v609_3);
    let v609_5: Space = subtract(&(*CONSTANT_1),&(v609_4));
    drop(v609_4);
    let v609_8: Space = if (&(v609_5)).is_empty() { Space::new() } else {
      let v610_6: Path = concat_path(&(*p0),&v608_21_cursor.path()[v608_21_origin..(v608_21_origin + 1)]);
      let mut v610_7 = Space::new();
      let mut v610_7_write = v610_7.write_zipper();
      for v610_7_byte in v608_21_cursor.child_mask().iter() {
        v608_21_cursor.descend_to_existing_byte(v610_7_byte);
        {
        let v611_2: Space = singleton(&v608_21_cursor.path()[(v608_21_origin + 1)..(v608_21_origin + 2)]);
        let v611_3: Space = intersect(&(*CONSTANT_2),&(v611_2));
        let v611_4: Space = if has_head(&(v611_3)) { singleton(&[]) } else { Space::new() };
        drop(v611_3);
        let v611_5: Space = subtract(&(*CONSTANT_1),&(v611_4));
        drop(v611_4);
        let v611_8: Space = if (&(v611_5)).is_empty() { Space::new() } else {
          let v612_6: Path = concat_path(&(v610_6),&v608_21_cursor.path()[(v608_21_origin + 1)..(v608_21_origin + 2)]);
          let mut v612_7 = Space::new();
          let mut v612_7_write = v612_7.write_zipper();
          for v612_7_byte in v608_21_cursor.child_mask().iter() {
            v608_21_cursor.descend_to_existing_byte(v612_7_byte);
            {
            let v613_2: Space = singleton(&v608_21_cursor.path()[(v608_21_origin + 2)..(v608_21_origin + 3)]);
            let v613_3: Space = intersect(&(*CONSTANT_2),&(v613_2));
            let v613_4: Space = if has_head(&(v613_3)) { singleton(&[]) } else { Space::new() };
            drop(v613_3);
            let v613_5: Space = subtract(&(*CONSTANT_1),&(v613_4));
            drop(v613_4);
            let v613_8: Space = if (&(v613_5)).is_empty() { Space::new() } else {
              let v614_6: Path = concat_path(&(v612_6),&v608_21_cursor.path()[(v608_21_origin + 2)..(v608_21_origin + 3)]);
              let v614_7: Space = routine_44(c, &(v614_6), &(*p1), &v608_21_cursor);
              compose(&(v613_5),&(v614_7))
            };
            drop(v613_5);
            let v613_9: Space = intersect(&(*CONSTANT_2),&(v613_2));
            drop(v613_2);
            let v613_10: Space = if has_head(&(v613_9)) { singleton(&[]) } else { Space::new() };
            drop(v613_9);
            let v613_12: Space = if (&(v613_10)).is_empty() { Space::new() } else {
              let v615_6: Path = concat_path(&(v612_6),&v608_21_cursor.path()[(v608_21_origin + 2)..(v608_21_origin + 3)]);
              let v615_11: Space = routine_45(c, &(v615_6), &(*p1), &v608_21_cursor);
              drop(v615_6);
              compose(&(v613_10),&(v615_11))
            };
            drop(v613_10);
            let v613_13: Space = unite(&(v613_8),&(v613_12));
            join_wrapped_into(&mut v612_7_write,&((v613_13).read_zipper()),&[]);
            }
            v608_21_cursor.ascend(1);
          }
          drop(v612_7_write);
          compose(&(v611_5),&(v612_7))
        };
        drop(v611_5);
        let v611_9: Space = intersect(&(*CONSTANT_2),&(v611_2));
        drop(v611_2);
        let v611_10: Space = if has_head(&(v611_9)) { singleton(&[]) } else { Space::new() };
        drop(v611_9);
        let v611_12: Space = if (&(v611_10)).is_empty() { Space::new() } else {
          let v616_6: Path = concat_path(&(v610_6),&v608_21_cursor.path()[(v608_21_origin + 1)..(v608_21_origin + 2)]);
          let mut v616_11 = Space::new();
          let mut v616_11_write = v616_11.write_zipper();
          for v616_11_byte in v608_21_cursor.child_mask().iter() {
            v608_21_cursor.descend_to_existing_byte(v616_11_byte);
            {
            let v617_2: Space = singleton(&v608_21_cursor.path()[(v608_21_origin + 2)..(v608_21_origin + 3)]);
            let v617_3: Space = intersect(&(*CONSTANT_2),&(v617_2));
            let v617_4: Space = if has_head(&(v617_3)) { singleton(&[]) } else { Space::new() };
            drop(v617_3);
            let v617_5: Space = subtract(&(*CONSTANT_1),&(v617_4));
            drop(v617_4);
            let v617_8: Space = if (&(v617_5)).is_empty() { Space::new() } else {
              let v618_6: Path = concat_path(&(v616_6),&v608_21_cursor.path()[(v608_21_origin + 2)..(v608_21_origin + 3)]);
              let v618_7: Space = routine_44(c, &(v618_6), &(*p1), &v608_21_cursor);
              compose(&(v617_5),&(v618_7))
            };
            drop(v617_5);
            let v617_9: Space = intersect(&(*CONSTANT_2),&(v617_2));
            drop(v617_2);
            let v617_10: Space = if has_head(&(v617_9)) { singleton(&[]) } else { Space::new() };
            drop(v617_9);
            let v617_12: Space = if (&(v617_10)).is_empty() { Space::new() } else {
              let v619_6: Path = concat_path(&(v616_6),&v608_21_cursor.path()[(v608_21_origin + 2)..(v608_21_origin + 3)]);
              let v619_11: Space = routine_19(c, &(v619_6), &(*p1), &v608_21_cursor);
              drop(v619_6);
              compose(&(v617_10),&(v619_11))
            };
            drop(v617_10);
            let v617_13: Space = unite(&(v617_8),&(v617_12));
            join_wrapped_into(&mut v616_11_write,&((v617_13).read_zipper()),&[]);
            }
            v608_21_cursor.ascend(1);
          }
          drop(v616_11_write);
          drop(v616_6);
          compose(&(v611_10),&(v616_11))
        };
        drop(v611_10);
        let v611_13: Space = unite(&(v611_8),&(v611_12));
        join_wrapped_into(&mut v610_7_write,&((v611_13).read_zipper()),&[]);
        }
        v608_21_cursor.ascend(1);
      }
      drop(v610_7_write);
      compose(&(v609_5),&(v610_7))
    };
    drop(v609_5);
    let v609_9: Space = intersect(&(*CONSTANT_2),&(v609_2));
    drop(v609_2);
    let v609_10: Space = if has_head(&(v609_9)) { singleton(&[]) } else { Space::new() };
    drop(v609_9);
    let v609_12: Space = if (&(v609_10)).is_empty() { Space::new() } else {
      let v620_6: Path = concat_path(&(*p0),&v608_21_cursor.path()[v608_21_origin..(v608_21_origin + 1)]);
      let mut v620_11 = Space::new();
      let mut v620_11_write = v620_11.write_zipper();
      for v620_11_byte in v608_21_cursor.child_mask().iter() {
        v608_21_cursor.descend_to_existing_byte(v620_11_byte);
        {
        let v621_2: Space = singleton(&v608_21_cursor.path()[(v608_21_origin + 1)..(v608_21_origin + 2)]);
        let v621_3: Space = intersect(&(*CONSTANT_2),&(v621_2));
        let v621_4: Space = if has_head(&(v621_3)) { singleton(&[]) } else { Space::new() };
        drop(v621_3);
        let v621_5: Space = subtract(&(*CONSTANT_1),&(v621_4));
        drop(v621_4);
        let v621_8: Space = if (&(v621_5)).is_empty() { Space::new() } else {
          let v622_6: Path = concat_path(&(v620_6),&v608_21_cursor.path()[(v608_21_origin + 1)..(v608_21_origin + 2)]);
          let mut v622_7 = Space::new();
          let mut v622_7_write = v622_7.write_zipper();
          for v622_7_byte in v608_21_cursor.child_mask().iter() {
            v608_21_cursor.descend_to_existing_byte(v622_7_byte);
            {
            let v623_2: Space = singleton(&v608_21_cursor.path()[(v608_21_origin + 2)..(v608_21_origin + 3)]);
            let v623_3: Space = intersect(&(*CONSTANT_2),&(v623_2));
            let v623_4: Space = if has_head(&(v623_3)) { singleton(&[]) } else { Space::new() };
            drop(v623_3);
            let v623_5: Space = subtract(&(*CONSTANT_1),&(v623_4));
            drop(v623_4);
            let v623_8: Space = if (&(v623_5)).is_empty() { Space::new() } else {
              let v624_6: Path = concat_path(&(v622_6),&v608_21_cursor.path()[(v608_21_origin + 2)..(v608_21_origin + 3)]);
              let v624_7: Space = routine_44(c, &(v624_6), &(*p1), &v608_21_cursor);
              compose(&(v623_5),&(v624_7))
            };
            drop(v623_5);
            let v623_9: Space = intersect(&(*CONSTANT_2),&(v623_2));
            drop(v623_2);
            let v623_10: Space = if has_head(&(v623_9)) { singleton(&[]) } else { Space::new() };
            drop(v623_9);
            let v623_12: Space = if (&(v623_10)).is_empty() { Space::new() } else {
              let v625_6: Path = concat_path(&(v622_6),&v608_21_cursor.path()[(v608_21_origin + 2)..(v608_21_origin + 3)]);
              let v625_11: Space = routine_45(c, &(v625_6), &(*p1), &v608_21_cursor);
              drop(v625_6);
              compose(&(v623_10),&(v625_11))
            };
            drop(v623_10);
            let v623_13: Space = unite(&(v623_8),&(v623_12));
            join_wrapped_into(&mut v622_7_write,&((v623_13).read_zipper()),&[]);
            }
            v608_21_cursor.ascend(1);
          }
          drop(v622_7_write);
          compose(&(v621_5),&(v622_7))
        };
        drop(v621_5);
        let v621_9: Space = intersect(&(*CONSTANT_2),&(v621_2));
        drop(v621_2);
        let v621_10: Space = if has_head(&(v621_9)) { singleton(&[]) } else { Space::new() };
        drop(v621_9);
        let v621_11: Space = compose(&(v621_10),&v608_21_cursor);
        drop(v621_10);
        let v626_6: Path = concat_path(&(v620_6),&v608_21_cursor.path()[(v608_21_origin + 1)..(v608_21_origin + 2)]);
        let v621_12: Space = wrap(&(v621_11),&(v626_6));
        drop(v621_11);
        let v621_13: Space = wrap(&(v621_12),&(*p1));
        drop(v621_12);
        let v621_14: Space = unite(&(v621_8),&(v621_13));
        drop(v621_13);
        join_wrapped_into(&mut v620_11_write,&((v621_14).read_zipper()),&[]);
        }
        v608_21_cursor.ascend(1);
      }
      drop(v620_11_write);
      drop(v620_6);
      compose(&(v609_10),&(v620_11))
    };
    drop(v609_10);
    let v609_13: Space = unite(&(v609_8),&(v609_12));
    join_wrapped_into(&mut v608_21_write,&((v609_13).read_zipper()),&[]);
    }
    v608_21_cursor.ascend(1);
  }
  drop(v608_21_cursor);
  drop(v608_21_write);
  (v608_21).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v627_15 = Space::new();
  let mut v627_15_write = v627_15.write_zipper();
  let mut v627_15_cursor = (*s0).read_zipper();
  let v627_15_origin = v627_15_cursor.path().len();
  for v627_15_byte in v627_15_cursor.child_mask().iter() {
    v627_15_cursor.descend_to_existing_byte(v627_15_byte);
    {
    let v628_2: Space = singleton(&v627_15_cursor.path()[v627_15_origin..(v627_15_origin + 1)]);
    let v628_3: Space = intersect(&(*CONSTANT_2),&(v628_2));
    let v628_4: Space = if has_head(&(v628_3)) { singleton(&[]) } else { Space::new() };
    drop(v628_3);
    let v628_5: Space = subtract(&(*CONSTANT_1),&(v628_4));
    drop(v628_4);
    let v628_8: Space = if (&(v628_5)).is_empty() { Space::new() } else {
      let v629_6: Path = concat_path(&(*p0),&v627_15_cursor.path()[v627_15_origin..(v627_15_origin + 1)]);
      let mut v629_7 = Space::new();
      let mut v629_7_write = v629_7.write_zipper();
      for v629_7_byte in v627_15_cursor.child_mask().iter() {
        v627_15_cursor.descend_to_existing_byte(v629_7_byte);
        {
        let v630_2: Space = singleton(&v627_15_cursor.path()[(v627_15_origin + 1)..(v627_15_origin + 2)]);
        let v630_3: Space = intersect(&(*CONSTANT_2),&(v630_2));
        let v630_4: Space = if has_head(&(v630_3)) { singleton(&[]) } else { Space::new() };
        drop(v630_3);
        let v630_5: Space = subtract(&(*CONSTANT_1),&(v630_4));
        drop(v630_4);
        let v630_8: Space = if (&(v630_5)).is_empty() { Space::new() } else {
          let v631_6: Path = concat_path(&(v629_6),&v627_15_cursor.path()[(v627_15_origin + 1)..(v627_15_origin + 2)]);
          let mut v631_7 = Space::new();
          let mut v631_7_write = v631_7.write_zipper();
          for v631_7_byte in v627_15_cursor.child_mask().iter() {
            v627_15_cursor.descend_to_existing_byte(v631_7_byte);
            {
            let v632_2: Space = singleton(&v627_15_cursor.path()[(v627_15_origin + 2)..(v627_15_origin + 3)]);
            let v632_3: Space = intersect(&(*CONSTANT_2),&(v632_2));
            let v632_4: Space = if has_head(&(v632_3)) { singleton(&[]) } else { Space::new() };
            drop(v632_3);
            let v632_5: Space = subtract(&(*CONSTANT_1),&(v632_4));
            drop(v632_4);
            let v632_8: Space = if (&(v632_5)).is_empty() { Space::new() } else {
              let v633_6: Path = concat_path(&(v631_6),&v627_15_cursor.path()[(v627_15_origin + 2)..(v627_15_origin + 3)]);
              let v633_7: Space = routine_44(c, &(v633_6), &(*p1), &v627_15_cursor);
              compose(&(v632_5),&(v633_7))
            };
            drop(v632_5);
            let v632_9: Space = intersect(&(*CONSTANT_2),&(v632_2));
            drop(v632_2);
            let v632_10: Space = if has_head(&(v632_9)) { singleton(&[]) } else { Space::new() };
            drop(v632_9);
            let v632_12: Space = if (&(v632_10)).is_empty() { Space::new() } else {
              let v634_6: Path = concat_path(&(v631_6),&v627_15_cursor.path()[(v627_15_origin + 2)..(v627_15_origin + 3)]);
              let v634_11: Space = routine_45(c, &(v634_6), &(*p1), &v627_15_cursor);
              drop(v634_6);
              compose(&(v632_10),&(v634_11))
            };
            drop(v632_10);
            let v632_13: Space = unite(&(v632_8),&(v632_12));
            join_wrapped_into(&mut v631_7_write,&((v632_13).read_zipper()),&[]);
            }
            v627_15_cursor.ascend(1);
          }
          drop(v631_7_write);
          compose(&(v630_5),&(v631_7))
        };
        drop(v630_5);
        let v630_9: Space = intersect(&(*CONSTANT_2),&(v630_2));
        drop(v630_2);
        let v630_10: Space = if has_head(&(v630_9)) { singleton(&[]) } else { Space::new() };
        drop(v630_9);
        let v630_12: Space = if (&(v630_10)).is_empty() { Space::new() } else {
          let v635_6: Path = concat_path(&(v629_6),&v627_15_cursor.path()[(v627_15_origin + 1)..(v627_15_origin + 2)]);
          let mut v635_11 = Space::new();
          let mut v635_11_write = v635_11.write_zipper();
          for v635_11_byte in v627_15_cursor.child_mask().iter() {
            v627_15_cursor.descend_to_existing_byte(v635_11_byte);
            {
            let v636_2: Space = singleton(&v627_15_cursor.path()[(v627_15_origin + 2)..(v627_15_origin + 3)]);
            let v636_3: Space = intersect(&(*CONSTANT_2),&(v636_2));
            let v636_4: Space = if has_head(&(v636_3)) { singleton(&[]) } else { Space::new() };
            drop(v636_3);
            let v636_5: Space = subtract(&(*CONSTANT_1),&(v636_4));
            drop(v636_4);
            let v636_8: Space = if (&(v636_5)).is_empty() { Space::new() } else {
              let v637_6: Path = concat_path(&(v635_6),&v627_15_cursor.path()[(v627_15_origin + 2)..(v627_15_origin + 3)]);
              let v637_7: Space = routine_44(c, &(v637_6), &(*p1), &v627_15_cursor);
              compose(&(v636_5),&(v637_7))
            };
            drop(v636_5);
            let v636_9: Space = intersect(&(*CONSTANT_2),&(v636_2));
            drop(v636_2);
            let v636_10: Space = if has_head(&(v636_9)) { singleton(&[]) } else { Space::new() };
            drop(v636_9);
            let v636_12: Space = if (&(v636_10)).is_empty() { Space::new() } else {
              let v638_6: Path = concat_path(&(v635_6),&v627_15_cursor.path()[(v627_15_origin + 2)..(v627_15_origin + 3)]);
              let v638_11: Space = routine_19(c, &(v638_6), &(*p1), &v627_15_cursor);
              drop(v638_6);
              compose(&(v636_10),&(v638_11))
            };
            drop(v636_10);
            let v636_13: Space = unite(&(v636_8),&(v636_12));
            join_wrapped_into(&mut v635_11_write,&((v636_13).read_zipper()),&[]);
            }
            v627_15_cursor.ascend(1);
          }
          drop(v635_11_write);
          drop(v635_6);
          compose(&(v630_10),&(v635_11))
        };
        drop(v630_10);
        let v630_13: Space = unite(&(v630_8),&(v630_12));
        join_wrapped_into(&mut v629_7_write,&((v630_13).read_zipper()),&[]);
        }
        v627_15_cursor.ascend(1);
      }
      drop(v629_7_write);
      compose(&(v628_5),&(v629_7))
    };
    drop(v628_5);
    let v628_9: Space = intersect(&(*CONSTANT_2),&(v628_2));
    drop(v628_2);
    let v628_10: Space = if has_head(&(v628_9)) { singleton(&[]) } else { Space::new() };
    drop(v628_9);
    let v628_11: Space = compose(&(v628_10),&v627_15_cursor);
    drop(v628_10);
    let v639_6: Path = concat_path(&(*p0),&v627_15_cursor.path()[v627_15_origin..(v627_15_origin + 1)]);
    let v628_12: Space = wrap(&(v628_11),&(v639_6));
    drop(v628_11);
    let v628_13: Space = wrap(&(v628_12),&(*p1));
    drop(v628_12);
    let v628_14: Space = unite(&(v628_8),&(v628_13));
    drop(v628_13);
    join_wrapped_into(&mut v627_15_write,&((v628_14).read_zipper()),&[]);
    }
    v627_15_cursor.ascend(1);
  }
  drop(v627_15_cursor);
  drop(v627_15_write);
  (v627_15).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v640_16 = Space::new();
  let mut v640_16_write = v640_16.write_zipper();
  let mut v640_16_cursor = (*s0).read_zipper();
  let v640_16_origin = v640_16_cursor.path().len();
  for v640_16_byte in v640_16_cursor.child_mask().iter() {
    v640_16_cursor.descend_to_existing_byte(v640_16_byte);
    {
    let v641_2: Space = singleton(&v640_16_cursor.path()[v640_16_origin..(v640_16_origin + 1)]);
    let v641_3: Space = intersect(&(*CONSTANT_2),&(v641_2));
    let v641_4: Space = if has_head(&(v641_3)) { singleton(&[]) } else { Space::new() };
    drop(v641_3);
    let v641_5: Space = subtract(&(*CONSTANT_1),&(v641_4));
    drop(v641_4);
    let v641_8: Space = if (&(v641_5)).is_empty() { Space::new() } else {
      let v642_6: Path = concat_path(&(*p0),&v640_16_cursor.path()[v640_16_origin..(v640_16_origin + 1)]);
      let mut v642_7 = Space::new();
      let mut v642_7_write = v642_7.write_zipper();
      for v642_7_byte in v640_16_cursor.child_mask().iter() {
        v640_16_cursor.descend_to_existing_byte(v642_7_byte);
        {
        let v643_2: Space = singleton(&v640_16_cursor.path()[(v640_16_origin + 1)..(v640_16_origin + 2)]);
        let v643_3: Space = intersect(&(*CONSTANT_2),&(v643_2));
        drop(v643_2);
        let v643_4: Space = if has_head(&(v643_3)) { singleton(&[]) } else { Space::new() };
        drop(v643_3);
        let v643_7: Space = if (&(v643_4)).is_empty() { Space::new() } else {
          let v644_5: Path = concat_path(&(v642_6),&v640_16_cursor.path()[(v640_16_origin + 1)..(v640_16_origin + 2)]);
          let mut v644_6 = Space::new();
          let mut v644_6_write = v644_6.write_zipper();
          for v644_6_byte in v640_16_cursor.child_mask().iter() {
            v640_16_cursor.descend_to_existing_byte(v644_6_byte);
            {
            let v645_2: Space = singleton(&v640_16_cursor.path()[(v640_16_origin + 2)..(v640_16_origin + 3)]);
            let v645_3: Space = intersect(&(*CONSTANT_2),&(v645_2));
            drop(v645_2);
            let v645_4: Space = if has_head(&(v645_3)) { singleton(&[]) } else { Space::new() };
            drop(v645_3);
            let v645_7: Space = if (&(v645_4)).is_empty() { Space::new() } else {
              let v646_5: Path = concat_path(&(v644_5),&v640_16_cursor.path()[(v640_16_origin + 2)..(v640_16_origin + 3)]);
              let v646_6: Space = routine_10(c, &(v646_5), &(*p1), &v640_16_cursor, &(*s1));
              drop(v646_5);
              compose(&(v645_4),&(v646_6))
            };
            drop(v645_4);
            join_wrapped_into(&mut v644_6_write,&((v645_7).read_zipper()),&[]);
            }
            v640_16_cursor.ascend(1);
          }
          drop(v644_6_write);
          drop(v644_5);
          compose(&(v643_4),&(v644_6))
        };
        drop(v643_4);
        join_wrapped_into(&mut v642_7_write,&((v643_7).read_zipper()),&[]);
        }
        v640_16_cursor.ascend(1);
      }
      drop(v642_7_write);
      drop(v642_6);
      compose(&(v641_5),&(v642_7))
    };
    drop(v641_5);
    let v641_9: Space = intersect(&(*CONSTANT_2),&(v641_2));
    drop(v641_2);
    let v641_10: Space = if has_head(&(v641_9)) { singleton(&[]) } else { Space::new() };
    drop(v641_9);
    let v641_13: Space = if (&(v641_10)).is_empty() { Space::new() } else {
      let mut v647_12 = Space::new();
      let mut v647_12_write = v647_12.write_zipper();
      for v647_12_byte in v640_16_cursor.child_mask().iter() {
        v640_16_cursor.descend_to_existing_byte(v647_12_byte);
        {
        let v648_2: Space = singleton(&v640_16_cursor.path()[(v640_16_origin + 1)..(v640_16_origin + 2)]);
        let v648_3: Space = intersect(&(*CONSTANT_2),&(v648_2));
        drop(v648_2);
        let v648_4: Space = if has_head(&(v648_3)) { singleton(&[]) } else { Space::new() };
        drop(v648_3);
        let v648_7: Space = if (&(v648_4)).is_empty() { Space::new() } else {
          let mut v649_6 = Space::new();
          let mut v649_6_write = v649_6.write_zipper();
          let mut v649_6_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v640_16_cursor.path()[v640_16_origin..(v640_16_origin + 1)]),&v640_16_cursor.path()[(v640_16_origin + 1)..(v640_16_origin + 2)]);
          let v649_6_origin = v649_6_cursor.path().len();
          for v649_6_byte in v649_6_cursor.child_mask().iter() {
            v649_6_cursor.descend_to_existing_byte(v649_6_byte);
            {
            let v650_2: Space = singleton(&v649_6_cursor.path()[v649_6_origin..(v649_6_origin + 1)]);
            let v650_3: Space = intersect(&(*CONSTANT_2),&(v650_2));
            let v650_4: Space = if has_head(&(v650_3)) { singleton(&[]) } else { Space::new() };
            drop(v650_3);
            let v650_5: Space = subtract(&(*CONSTANT_1),&(v650_4));
            drop(v650_4);
            let v650_7: Space = if (&(v650_5)).is_empty() { Space::new() } else {
              let v651_6: Space = routine_13(c, &v649_6_cursor.path()[v649_6_origin..(v649_6_origin + 1)], &(*p1), &v649_6_cursor);
              compose(&(v650_5),&(v651_6))
            };
            drop(v650_5);
            let v650_8: Space = intersect(&(*CONSTANT_2),&(v650_2));
            drop(v650_2);
            let v650_9: Space = if has_head(&(v650_8)) { singleton(&[]) } else { Space::new() };
            drop(v650_8);
            let v650_11: Space = if (&(v650_9)).is_empty() { Space::new() } else {
              let v652_10: Space = routine_14(c, &v649_6_cursor.path()[v649_6_origin..(v649_6_origin + 1)], &(*p1), &v649_6_cursor);
              compose(&(v650_9),&(v652_10))
            };
            drop(v650_9);
            let v650_12: Space = unite(&(v650_7),&(v650_11));
            join_wrapped_into(&mut v649_6_write,&((v650_12).read_zipper()),&[]);
            }
            v649_6_cursor.ascend(1);
          }
          drop(v649_6_cursor);
          drop(v649_6_write);
          compose(&(v648_4),&(v649_6))
        };
        drop(v648_4);
        join_wrapped_into(&mut v647_12_write,&((v648_7).read_zipper()),&[]);
        }
        v640_16_cursor.ascend(1);
      }
      drop(v647_12_write);
      compose(&(v641_10),&(v647_12))
    };
    drop(v641_10);
    let v641_14: Space = unite(&(v641_8),&(v641_13));
    join_wrapped_into(&mut v640_16_write,&((v641_14).read_zipper()),&[]);
    }
    v640_16_cursor.ascend(1);
  }
  drop(v640_16_cursor);
  drop(v640_16_write);
  (v640_16).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v653_21 = Space::new();
  let mut v653_21_write = v653_21.write_zipper();
  let mut v653_21_cursor = (*s0).read_zipper();
  let v653_21_origin = v653_21_cursor.path().len();
  for v653_21_byte in v653_21_cursor.child_mask().iter() {
    v653_21_cursor.descend_to_existing_byte(v653_21_byte);
    {
    let v654_2: Space = singleton(&v653_21_cursor.path()[v653_21_origin..(v653_21_origin + 1)]);
    let v654_3: Space = intersect(&(*CONSTANT_2),&(v654_2));
    let v654_4: Space = if has_head(&(v654_3)) { singleton(&[]) } else { Space::new() };
    drop(v654_3);
    let v654_5: Space = subtract(&(*CONSTANT_1),&(v654_4));
    drop(v654_4);
    let v654_8: Space = if (&(v654_5)).is_empty() { Space::new() } else {
      let v655_6: Path = concat_path(&(*p0),&v653_21_cursor.path()[v653_21_origin..(v653_21_origin + 1)]);
      let mut v655_7 = Space::new();
      let mut v655_7_write = v655_7.write_zipper();
      for v655_7_byte in v653_21_cursor.child_mask().iter() {
        v653_21_cursor.descend_to_existing_byte(v655_7_byte);
        {
        let v656_2: Space = singleton(&v653_21_cursor.path()[(v653_21_origin + 1)..(v653_21_origin + 2)]);
        let v656_3: Space = intersect(&(*CONSTANT_2),&(v656_2));
        drop(v656_2);
        let v656_4: Space = if has_head(&(v656_3)) { singleton(&[]) } else { Space::new() };
        drop(v656_3);
        let v656_7: Space = if (&(v656_4)).is_empty() { Space::new() } else {
          let v657_5: Path = concat_path(&(v655_6),&v653_21_cursor.path()[(v653_21_origin + 1)..(v653_21_origin + 2)]);
          let mut v657_6 = Space::new();
          let mut v657_6_write = v657_6.write_zipper();
          for v657_6_byte in v653_21_cursor.child_mask().iter() {
            v653_21_cursor.descend_to_existing_byte(v657_6_byte);
            {
            let v658_2: Space = singleton(&v653_21_cursor.path()[(v653_21_origin + 2)..(v653_21_origin + 3)]);
            let v658_3: Space = intersect(&(*CONSTANT_2),&(v658_2));
            drop(v658_2);
            let v658_4: Space = if has_head(&(v658_3)) { singleton(&[]) } else { Space::new() };
            drop(v658_3);
            let v658_7: Space = if (&(v658_4)).is_empty() { Space::new() } else {
              let v659_5: Path = concat_path(&(v657_5),&v653_21_cursor.path()[(v653_21_origin + 2)..(v653_21_origin + 3)]);
              let v659_6: Space = routine_10(c, &(v659_5), &(*p1), &v653_21_cursor, &(*s1));
              drop(v659_5);
              compose(&(v658_4),&(v659_6))
            };
            drop(v658_4);
            join_wrapped_into(&mut v657_6_write,&((v658_7).read_zipper()),&[]);
            }
            v653_21_cursor.ascend(1);
          }
          drop(v657_6_write);
          drop(v657_5);
          compose(&(v656_4),&(v657_6))
        };
        drop(v656_4);
        join_wrapped_into(&mut v655_7_write,&((v656_7).read_zipper()),&[]);
        }
        v653_21_cursor.ascend(1);
      }
      drop(v655_7_write);
      drop(v655_6);
      compose(&(v654_5),&(v655_7))
    };
    drop(v654_5);
    let v654_9: Space = intersect(&(*CONSTANT_2),&(v654_2));
    drop(v654_2);
    let v654_10: Space = if has_head(&(v654_9)) { singleton(&[]) } else { Space::new() };
    drop(v654_9);
    let v654_13: Space = if (&(v654_10)).is_empty() { Space::new() } else {
      let mut v660_12 = Space::new();
      let mut v660_12_write = v660_12.write_zipper();
      let mut v660_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v653_21_cursor.path()[v653_21_origin..(v653_21_origin + 1)]);
      let v660_12_origin = v660_12_cursor.path().len();
      for v660_12_byte in v660_12_cursor.child_mask().iter() {
        v660_12_cursor.descend_to_existing_byte(v660_12_byte);
        {
        let v661_2: Space = singleton(&v660_12_cursor.path()[v660_12_origin..(v660_12_origin + 1)]);
        let v661_3: Space = intersect(&(*CONSTANT_2),&(v661_2));
        let v661_4: Space = if has_head(&(v661_3)) { singleton(&[]) } else { Space::new() };
        drop(v661_3);
        let v661_5: Space = subtract(&(*CONSTANT_1),&(v661_4));
        drop(v661_4);
        let v661_7: Space = if (&(v661_5)).is_empty() { Space::new() } else {
          let mut v662_6 = Space::new();
          let mut v662_6_write = v662_6.write_zipper();
          for v662_6_byte in v660_12_cursor.child_mask().iter() {
            v660_12_cursor.descend_to_existing_byte(v662_6_byte);
            {
            let v663_2: Space = singleton(&v660_12_cursor.path()[(v660_12_origin + 1)..(v660_12_origin + 2)]);
            let v663_3: Space = intersect(&(*CONSTANT_2),&(v663_2));
            let v663_4: Space = if has_head(&(v663_3)) { singleton(&[]) } else { Space::new() };
            drop(v663_3);
            let v663_5: Space = subtract(&(*CONSTANT_1),&(v663_4));
            drop(v663_4);
            let v663_8: Space = if (&(v663_5)).is_empty() { Space::new() } else {
              let v664_7: Space = routine_17(c, &v660_12_cursor.path()[v660_12_origin..(v660_12_origin + 2)], &(*p1), &v660_12_cursor);
              compose(&(v663_5),&(v664_7))
            };
            drop(v663_5);
            let v663_9: Space = intersect(&(*CONSTANT_2),&(v663_2));
            drop(v663_2);
            let v663_10: Space = if has_head(&(v663_9)) { singleton(&[]) } else { Space::new() };
            drop(v663_9);
            let v663_12: Space = if (&(v663_10)).is_empty() { Space::new() } else {
              let v665_11: Space = routine_18(c, &v660_12_cursor.path()[v660_12_origin..(v660_12_origin + 2)], &(*p1), &v660_12_cursor);
              compose(&(v663_10),&(v665_11))
            };
            drop(v663_10);
            let v663_13: Space = unite(&(v663_8),&(v663_12));
            join_wrapped_into(&mut v662_6_write,&((v663_13).read_zipper()),&[]);
            }
            v660_12_cursor.ascend(1);
          }
          drop(v662_6_write);
          compose(&(v661_5),&(v662_6))
        };
        drop(v661_5);
        let v661_8: Space = intersect(&(*CONSTANT_2),&(v661_2));
        drop(v661_2);
        let v661_9: Space = if has_head(&(v661_8)) { singleton(&[]) } else { Space::new() };
        drop(v661_8);
        let v661_11: Space = if (&(v661_9)).is_empty() { Space::new() } else {
          let mut v666_10 = Space::new();
          let mut v666_10_write = v666_10.write_zipper();
          for v666_10_byte in v660_12_cursor.child_mask().iter() {
            v660_12_cursor.descend_to_existing_byte(v666_10_byte);
            {
            let v667_2: Space = singleton(&v660_12_cursor.path()[(v660_12_origin + 1)..(v660_12_origin + 2)]);
            let v667_3: Space = intersect(&(*CONSTANT_2),&(v667_2));
            let v667_4: Space = if has_head(&(v667_3)) { singleton(&[]) } else { Space::new() };
            drop(v667_3);
            let v667_5: Space = subtract(&(*CONSTANT_1),&(v667_4));
            drop(v667_4);
            let v667_8: Space = if (&(v667_5)).is_empty() { Space::new() } else {
              let v668_7: Space = routine_17(c, &v660_12_cursor.path()[v660_12_origin..(v660_12_origin + 2)], &(*p1), &v660_12_cursor);
              compose(&(v667_5),&(v668_7))
            };
            drop(v667_5);
            let v667_9: Space = intersect(&(*CONSTANT_2),&(v667_2));
            drop(v667_2);
            let v667_10: Space = if has_head(&(v667_9)) { singleton(&[]) } else { Space::new() };
            drop(v667_9);
            let v667_12: Space = if (&(v667_10)).is_empty() { Space::new() } else {
              let v669_11: Space = routine_19(c, &v660_12_cursor.path()[v660_12_origin..(v660_12_origin + 2)], &(*p1), &v660_12_cursor);
              compose(&(v667_10),&(v669_11))
            };
            drop(v667_10);
            let v667_13: Space = unite(&(v667_8),&(v667_12));
            join_wrapped_into(&mut v666_10_write,&((v667_13).read_zipper()),&[]);
            }
            v660_12_cursor.ascend(1);
          }
          drop(v666_10_write);
          compose(&(v661_9),&(v666_10))
        };
        drop(v661_9);
        let v661_12: Space = unite(&(v661_7),&(v661_11));
        join_wrapped_into(&mut v660_12_write,&((v661_12).read_zipper()),&[]);
        }
        v660_12_cursor.ascend(1);
      }
      drop(v660_12_cursor);
      drop(v660_12_write);
      compose(&(v654_10),&(v660_12))
    };
    drop(v654_10);
    let v654_14: Space = unite(&(v654_8),&(v654_13));
    join_wrapped_into(&mut v653_21_write,&((v654_14).read_zipper()),&[]);
    }
    v653_21_cursor.ascend(1);
  }
  drop(v653_21_cursor);
  drop(v653_21_write);
  (v653_21).clone()
}

fn routine_36(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v670_21 = Space::new();
  let mut v670_21_write = v670_21.write_zipper();
  let mut v670_21_cursor = (*s0).read_zipper();
  let v670_21_origin = v670_21_cursor.path().len();
  for v670_21_byte in v670_21_cursor.child_mask().iter() {
    v670_21_cursor.descend_to_existing_byte(v670_21_byte);
    {
    let v671_2: Space = singleton(&v670_21_cursor.path()[v670_21_origin..(v670_21_origin + 1)]);
    let v671_3: Space = intersect(&(*CONSTANT_2),&(v671_2));
    let v671_4: Space = if has_head(&(v671_3)) { singleton(&[]) } else { Space::new() };
    drop(v671_3);
    let v671_5: Space = subtract(&(*CONSTANT_1),&(v671_4));
    drop(v671_4);
    let v671_8: Space = if (&(v671_5)).is_empty() { Space::new() } else {
      let v672_6: Path = concat_path(&(*p0),&v670_21_cursor.path()[v670_21_origin..(v670_21_origin + 1)]);
      let mut v672_7 = Space::new();
      let mut v672_7_write = v672_7.write_zipper();
      for v672_7_byte in v670_21_cursor.child_mask().iter() {
        v670_21_cursor.descend_to_existing_byte(v672_7_byte);
        {
        let v673_2: Space = singleton(&v670_21_cursor.path()[(v670_21_origin + 1)..(v670_21_origin + 2)]);
        let v673_3: Space = intersect(&(*CONSTANT_2),&(v673_2));
        let v673_4: Space = if has_head(&(v673_3)) { singleton(&[]) } else { Space::new() };
        drop(v673_3);
        let v673_5: Space = subtract(&(*CONSTANT_1),&(v673_4));
        drop(v673_4);
        let v673_8: Space = if (&(v673_5)).is_empty() { Space::new() } else {
          let v674_6: Path = concat_path(&(v672_6),&v670_21_cursor.path()[(v670_21_origin + 1)..(v670_21_origin + 2)]);
          let mut v674_7 = Space::new();
          let mut v674_7_write = v674_7.write_zipper();
          for v674_7_byte in v670_21_cursor.child_mask().iter() {
            v670_21_cursor.descend_to_existing_byte(v674_7_byte);
            {
            let v675_2: Space = singleton(&v670_21_cursor.path()[(v670_21_origin + 2)..(v670_21_origin + 3)]);
            let v675_3: Space = intersect(&(*CONSTANT_2),&(v675_2));
            let v675_4: Space = if has_head(&(v675_3)) { singleton(&[]) } else { Space::new() };
            drop(v675_3);
            let v675_5: Space = subtract(&(*CONSTANT_1),&(v675_4));
            drop(v675_4);
            let v675_8: Space = if (&(v675_5)).is_empty() { Space::new() } else {
              let v676_6: Path = concat_path(&(v674_6),&v670_21_cursor.path()[(v670_21_origin + 2)..(v670_21_origin + 3)]);
              let v676_7: Space = routine_46(c, &(v676_6), &(*p1), &v670_21_cursor);
              compose(&(v675_5),&(v676_7))
            };
            drop(v675_5);
            let v675_9: Space = intersect(&(*CONSTANT_2),&(v675_2));
            drop(v675_2);
            let v675_10: Space = if has_head(&(v675_9)) { singleton(&[]) } else { Space::new() };
            drop(v675_9);
            let v675_12: Space = if (&(v675_10)).is_empty() { Space::new() } else {
              let v677_6: Path = concat_path(&(v674_6),&v670_21_cursor.path()[(v670_21_origin + 2)..(v670_21_origin + 3)]);
              let v677_11: Space = routine_47(c, &(v677_6), &(*p1), &v670_21_cursor);
              drop(v677_6);
              compose(&(v675_10),&(v677_11))
            };
            drop(v675_10);
            let v675_13: Space = unite(&(v675_8),&(v675_12));
            join_wrapped_into(&mut v674_7_write,&((v675_13).read_zipper()),&[]);
            }
            v670_21_cursor.ascend(1);
          }
          drop(v674_7_write);
          compose(&(v673_5),&(v674_7))
        };
        drop(v673_5);
        let v673_9: Space = intersect(&(*CONSTANT_2),&(v673_2));
        drop(v673_2);
        let v673_10: Space = if has_head(&(v673_9)) { singleton(&[]) } else { Space::new() };
        drop(v673_9);
        let v673_12: Space = if (&(v673_10)).is_empty() { Space::new() } else {
          let v678_6: Path = concat_path(&(v672_6),&v670_21_cursor.path()[(v670_21_origin + 1)..(v670_21_origin + 2)]);
          let mut v678_11 = Space::new();
          let mut v678_11_write = v678_11.write_zipper();
          for v678_11_byte in v670_21_cursor.child_mask().iter() {
            v670_21_cursor.descend_to_existing_byte(v678_11_byte);
            {
            let v679_2: Space = singleton(&v670_21_cursor.path()[(v670_21_origin + 2)..(v670_21_origin + 3)]);
            let v679_3: Space = intersect(&(*CONSTANT_2),&(v679_2));
            let v679_4: Space = if has_head(&(v679_3)) { singleton(&[]) } else { Space::new() };
            drop(v679_3);
            let v679_5: Space = subtract(&(*CONSTANT_1),&(v679_4));
            drop(v679_4);
            let v679_8: Space = if (&(v679_5)).is_empty() { Space::new() } else {
              let v680_6: Path = concat_path(&(v678_6),&v670_21_cursor.path()[(v670_21_origin + 2)..(v670_21_origin + 3)]);
              let v680_7: Space = routine_46(c, &(v680_6), &(*p1), &v670_21_cursor);
              compose(&(v679_5),&(v680_7))
            };
            drop(v679_5);
            let v679_9: Space = intersect(&(*CONSTANT_2),&(v679_2));
            drop(v679_2);
            let v679_10: Space = if has_head(&(v679_9)) { singleton(&[]) } else { Space::new() };
            drop(v679_9);
            let v679_12: Space = if (&(v679_10)).is_empty() { Space::new() } else {
              let v681_6: Path = concat_path(&(v678_6),&v670_21_cursor.path()[(v670_21_origin + 2)..(v670_21_origin + 3)]);
              let v681_11: Space = routine_19(c, &(v681_6), &(*p1), &v670_21_cursor);
              drop(v681_6);
              compose(&(v679_10),&(v681_11))
            };
            drop(v679_10);
            let v679_13: Space = unite(&(v679_8),&(v679_12));
            join_wrapped_into(&mut v678_11_write,&((v679_13).read_zipper()),&[]);
            }
            v670_21_cursor.ascend(1);
          }
          drop(v678_11_write);
          drop(v678_6);
          compose(&(v673_10),&(v678_11))
        };
        drop(v673_10);
        let v673_13: Space = unite(&(v673_8),&(v673_12));
        join_wrapped_into(&mut v672_7_write,&((v673_13).read_zipper()),&[]);
        }
        v670_21_cursor.ascend(1);
      }
      drop(v672_7_write);
      compose(&(v671_5),&(v672_7))
    };
    drop(v671_5);
    let v671_9: Space = intersect(&(*CONSTANT_2),&(v671_2));
    drop(v671_2);
    let v671_10: Space = if has_head(&(v671_9)) { singleton(&[]) } else { Space::new() };
    drop(v671_9);
    let v671_12: Space = if (&(v671_10)).is_empty() { Space::new() } else {
      let v682_6: Path = concat_path(&(*p0),&v670_21_cursor.path()[v670_21_origin..(v670_21_origin + 1)]);
      let mut v682_11 = Space::new();
      let mut v682_11_write = v682_11.write_zipper();
      for v682_11_byte in v670_21_cursor.child_mask().iter() {
        v670_21_cursor.descend_to_existing_byte(v682_11_byte);
        {
        let v683_2: Space = singleton(&v670_21_cursor.path()[(v670_21_origin + 1)..(v670_21_origin + 2)]);
        let v683_3: Space = intersect(&(*CONSTANT_2),&(v683_2));
        let v683_4: Space = if has_head(&(v683_3)) { singleton(&[]) } else { Space::new() };
        drop(v683_3);
        let v683_5: Space = subtract(&(*CONSTANT_1),&(v683_4));
        drop(v683_4);
        let v683_8: Space = if (&(v683_5)).is_empty() { Space::new() } else {
          let v684_6: Path = concat_path(&(v682_6),&v670_21_cursor.path()[(v670_21_origin + 1)..(v670_21_origin + 2)]);
          let mut v684_7 = Space::new();
          let mut v684_7_write = v684_7.write_zipper();
          for v684_7_byte in v670_21_cursor.child_mask().iter() {
            v670_21_cursor.descend_to_existing_byte(v684_7_byte);
            {
            let v685_2: Space = singleton(&v670_21_cursor.path()[(v670_21_origin + 2)..(v670_21_origin + 3)]);
            let v685_3: Space = intersect(&(*CONSTANT_2),&(v685_2));
            let v685_4: Space = if has_head(&(v685_3)) { singleton(&[]) } else { Space::new() };
            drop(v685_3);
            let v685_5: Space = subtract(&(*CONSTANT_1),&(v685_4));
            drop(v685_4);
            let v685_8: Space = if (&(v685_5)).is_empty() { Space::new() } else {
              let v686_6: Path = concat_path(&(v684_6),&v670_21_cursor.path()[(v670_21_origin + 2)..(v670_21_origin + 3)]);
              let v686_7: Space = routine_46(c, &(v686_6), &(*p1), &v670_21_cursor);
              compose(&(v685_5),&(v686_7))
            };
            drop(v685_5);
            let v685_9: Space = intersect(&(*CONSTANT_2),&(v685_2));
            drop(v685_2);
            let v685_10: Space = if has_head(&(v685_9)) { singleton(&[]) } else { Space::new() };
            drop(v685_9);
            let v685_12: Space = if (&(v685_10)).is_empty() { Space::new() } else {
              let v687_6: Path = concat_path(&(v684_6),&v670_21_cursor.path()[(v670_21_origin + 2)..(v670_21_origin + 3)]);
              let v687_11: Space = routine_47(c, &(v687_6), &(*p1), &v670_21_cursor);
              drop(v687_6);
              compose(&(v685_10),&(v687_11))
            };
            drop(v685_10);
            let v685_13: Space = unite(&(v685_8),&(v685_12));
            join_wrapped_into(&mut v684_7_write,&((v685_13).read_zipper()),&[]);
            }
            v670_21_cursor.ascend(1);
          }
          drop(v684_7_write);
          compose(&(v683_5),&(v684_7))
        };
        drop(v683_5);
        let v683_9: Space = intersect(&(*CONSTANT_2),&(v683_2));
        drop(v683_2);
        let v683_10: Space = if has_head(&(v683_9)) { singleton(&[]) } else { Space::new() };
        drop(v683_9);
        let v683_11: Space = compose(&(v683_10),&v670_21_cursor);
        drop(v683_10);
        let v688_6: Path = concat_path(&(v682_6),&v670_21_cursor.path()[(v670_21_origin + 1)..(v670_21_origin + 2)]);
        let v683_12: Space = wrap(&(v683_11),&(v688_6));
        drop(v683_11);
        let v683_13: Space = wrap(&(v683_12),&(*p1));
        drop(v683_12);
        let v683_14: Space = unite(&(v683_8),&(v683_13));
        drop(v683_13);
        join_wrapped_into(&mut v682_11_write,&((v683_14).read_zipper()),&[]);
        }
        v670_21_cursor.ascend(1);
      }
      drop(v682_11_write);
      drop(v682_6);
      compose(&(v671_10),&(v682_11))
    };
    drop(v671_10);
    let v671_13: Space = unite(&(v671_8),&(v671_12));
    join_wrapped_into(&mut v670_21_write,&((v671_13).read_zipper()),&[]);
    }
    v670_21_cursor.ascend(1);
  }
  drop(v670_21_cursor);
  drop(v670_21_write);
  (v670_21).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v689_15 = Space::new();
  let mut v689_15_write = v689_15.write_zipper();
  let mut v689_15_cursor = (*s0).read_zipper();
  let v689_15_origin = v689_15_cursor.path().len();
  for v689_15_byte in v689_15_cursor.child_mask().iter() {
    v689_15_cursor.descend_to_existing_byte(v689_15_byte);
    {
    let v690_2: Space = singleton(&v689_15_cursor.path()[v689_15_origin..(v689_15_origin + 1)]);
    let v690_3: Space = intersect(&(*CONSTANT_2),&(v690_2));
    let v690_4: Space = if has_head(&(v690_3)) { singleton(&[]) } else { Space::new() };
    drop(v690_3);
    let v690_5: Space = subtract(&(*CONSTANT_1),&(v690_4));
    drop(v690_4);
    let v690_8: Space = if (&(v690_5)).is_empty() { Space::new() } else {
      let v691_6: Path = concat_path(&(*p0),&v689_15_cursor.path()[v689_15_origin..(v689_15_origin + 1)]);
      let mut v691_7 = Space::new();
      let mut v691_7_write = v691_7.write_zipper();
      for v691_7_byte in v689_15_cursor.child_mask().iter() {
        v689_15_cursor.descend_to_existing_byte(v691_7_byte);
        {
        let v692_2: Space = singleton(&v689_15_cursor.path()[(v689_15_origin + 1)..(v689_15_origin + 2)]);
        let v692_3: Space = intersect(&(*CONSTANT_2),&(v692_2));
        let v692_4: Space = if has_head(&(v692_3)) { singleton(&[]) } else { Space::new() };
        drop(v692_3);
        let v692_5: Space = subtract(&(*CONSTANT_1),&(v692_4));
        drop(v692_4);
        let v692_8: Space = if (&(v692_5)).is_empty() { Space::new() } else {
          let v693_6: Path = concat_path(&(v691_6),&v689_15_cursor.path()[(v689_15_origin + 1)..(v689_15_origin + 2)]);
          let mut v693_7 = Space::new();
          let mut v693_7_write = v693_7.write_zipper();
          for v693_7_byte in v689_15_cursor.child_mask().iter() {
            v689_15_cursor.descend_to_existing_byte(v693_7_byte);
            {
            let v694_2: Space = singleton(&v689_15_cursor.path()[(v689_15_origin + 2)..(v689_15_origin + 3)]);
            let v694_3: Space = intersect(&(*CONSTANT_2),&(v694_2));
            let v694_4: Space = if has_head(&(v694_3)) { singleton(&[]) } else { Space::new() };
            drop(v694_3);
            let v694_5: Space = subtract(&(*CONSTANT_1),&(v694_4));
            drop(v694_4);
            let v694_8: Space = if (&(v694_5)).is_empty() { Space::new() } else {
              let v695_6: Path = concat_path(&(v693_6),&v689_15_cursor.path()[(v689_15_origin + 2)..(v689_15_origin + 3)]);
              let v695_7: Space = routine_46(c, &(v695_6), &(*p1), &v689_15_cursor);
              compose(&(v694_5),&(v695_7))
            };
            drop(v694_5);
            let v694_9: Space = intersect(&(*CONSTANT_2),&(v694_2));
            drop(v694_2);
            let v694_10: Space = if has_head(&(v694_9)) { singleton(&[]) } else { Space::new() };
            drop(v694_9);
            let v694_12: Space = if (&(v694_10)).is_empty() { Space::new() } else {
              let v696_6: Path = concat_path(&(v693_6),&v689_15_cursor.path()[(v689_15_origin + 2)..(v689_15_origin + 3)]);
              let v696_11: Space = routine_47(c, &(v696_6), &(*p1), &v689_15_cursor);
              drop(v696_6);
              compose(&(v694_10),&(v696_11))
            };
            drop(v694_10);
            let v694_13: Space = unite(&(v694_8),&(v694_12));
            join_wrapped_into(&mut v693_7_write,&((v694_13).read_zipper()),&[]);
            }
            v689_15_cursor.ascend(1);
          }
          drop(v693_7_write);
          compose(&(v692_5),&(v693_7))
        };
        drop(v692_5);
        let v692_9: Space = intersect(&(*CONSTANT_2),&(v692_2));
        drop(v692_2);
        let v692_10: Space = if has_head(&(v692_9)) { singleton(&[]) } else { Space::new() };
        drop(v692_9);
        let v692_12: Space = if (&(v692_10)).is_empty() { Space::new() } else {
          let v697_6: Path = concat_path(&(v691_6),&v689_15_cursor.path()[(v689_15_origin + 1)..(v689_15_origin + 2)]);
          let mut v697_11 = Space::new();
          let mut v697_11_write = v697_11.write_zipper();
          for v697_11_byte in v689_15_cursor.child_mask().iter() {
            v689_15_cursor.descend_to_existing_byte(v697_11_byte);
            {
            let v698_2: Space = singleton(&v689_15_cursor.path()[(v689_15_origin + 2)..(v689_15_origin + 3)]);
            let v698_3: Space = intersect(&(*CONSTANT_2),&(v698_2));
            let v698_4: Space = if has_head(&(v698_3)) { singleton(&[]) } else { Space::new() };
            drop(v698_3);
            let v698_5: Space = subtract(&(*CONSTANT_1),&(v698_4));
            drop(v698_4);
            let v698_8: Space = if (&(v698_5)).is_empty() { Space::new() } else {
              let v699_6: Path = concat_path(&(v697_6),&v689_15_cursor.path()[(v689_15_origin + 2)..(v689_15_origin + 3)]);
              let v699_7: Space = routine_46(c, &(v699_6), &(*p1), &v689_15_cursor);
              compose(&(v698_5),&(v699_7))
            };
            drop(v698_5);
            let v698_9: Space = intersect(&(*CONSTANT_2),&(v698_2));
            drop(v698_2);
            let v698_10: Space = if has_head(&(v698_9)) { singleton(&[]) } else { Space::new() };
            drop(v698_9);
            let v698_12: Space = if (&(v698_10)).is_empty() { Space::new() } else {
              let v700_6: Path = concat_path(&(v697_6),&v689_15_cursor.path()[(v689_15_origin + 2)..(v689_15_origin + 3)]);
              let v700_11: Space = routine_19(c, &(v700_6), &(*p1), &v689_15_cursor);
              drop(v700_6);
              compose(&(v698_10),&(v700_11))
            };
            drop(v698_10);
            let v698_13: Space = unite(&(v698_8),&(v698_12));
            join_wrapped_into(&mut v697_11_write,&((v698_13).read_zipper()),&[]);
            }
            v689_15_cursor.ascend(1);
          }
          drop(v697_11_write);
          drop(v697_6);
          compose(&(v692_10),&(v697_11))
        };
        drop(v692_10);
        let v692_13: Space = unite(&(v692_8),&(v692_12));
        join_wrapped_into(&mut v691_7_write,&((v692_13).read_zipper()),&[]);
        }
        v689_15_cursor.ascend(1);
      }
      drop(v691_7_write);
      compose(&(v690_5),&(v691_7))
    };
    drop(v690_5);
    let v690_9: Space = intersect(&(*CONSTANT_2),&(v690_2));
    drop(v690_2);
    let v690_10: Space = if has_head(&(v690_9)) { singleton(&[]) } else { Space::new() };
    drop(v690_9);
    let v690_11: Space = compose(&(v690_10),&v689_15_cursor);
    drop(v690_10);
    let v701_6: Path = concat_path(&(*p0),&v689_15_cursor.path()[v689_15_origin..(v689_15_origin + 1)]);
    let v690_12: Space = wrap(&(v690_11),&(v701_6));
    drop(v690_11);
    let v690_13: Space = wrap(&(v690_12),&(*p1));
    drop(v690_12);
    let v690_14: Space = unite(&(v690_8),&(v690_13));
    drop(v690_13);
    join_wrapped_into(&mut v689_15_write,&((v690_14).read_zipper()),&[]);
    }
    v689_15_cursor.ascend(1);
  }
  drop(v689_15_cursor);
  drop(v689_15_write);
  (v689_15).clone()
}

fn routine_38(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v702_12 = Space::new();
  let mut v702_12_write = v702_12.write_zipper();
  let mut v702_12_cursor = (*s0).read_zipper();
  let v702_12_origin = v702_12_cursor.path().len();
  for v702_12_byte in v702_12_cursor.child_mask().iter() {
    v702_12_cursor.descend_to_existing_byte(v702_12_byte);
    {
    let v703_2: Space = singleton(&v702_12_cursor.path()[v702_12_origin..(v702_12_origin + 1)]);
    let v703_3: Space = intersect(&(*CONSTANT_2),&(v703_2));
    drop(v703_2);
    let v703_4: Space = if has_head(&(v703_3)) { singleton(&[]) } else { Space::new() };
    drop(v703_3);
    let v703_7: Space = if (&(v703_4)).is_empty() { Space::new() } else {
      let mut v704_6 = Space::new();
      let mut v704_6_write = v704_6.write_zipper();
      for v704_6_byte in v702_12_cursor.child_mask().iter() {
        v702_12_cursor.descend_to_existing_byte(v704_6_byte);
        {
        let v705_2: Space = singleton(&v702_12_cursor.path()[(v702_12_origin + 1)..(v702_12_origin + 2)]);
        let v705_3: Space = intersect(&(*CONSTANT_2),&(v705_2));
        drop(v705_2);
        let v705_4: Space = if has_head(&(v705_3)) { singleton(&[]) } else { Space::new() };
        drop(v705_3);
        let v705_7: Space = if (&(v705_4)).is_empty() { Space::new() } else {
          let mut v706_6 = Space::new();
          let mut v706_6_write = v706_6.write_zipper();
          let mut v706_6_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v702_12_cursor.path()[v702_12_origin..(v702_12_origin + 1)]),&v702_12_cursor.path()[(v702_12_origin + 1)..(v702_12_origin + 2)]);
          let v706_6_origin = v706_6_cursor.path().len();
          for v706_6_byte in v706_6_cursor.child_mask().iter() {
            v706_6_cursor.descend_to_existing_byte(v706_6_byte);
            {
            let v707_2: Space = singleton(&v706_6_cursor.path()[v706_6_origin..(v706_6_origin + 1)]);
            let v707_3: Space = intersect(&(*CONSTANT_2),&(v707_2));
            let v707_4: Space = if has_head(&(v707_3)) { singleton(&[]) } else { Space::new() };
            drop(v707_3);
            let v707_5: Space = subtract(&(*CONSTANT_1),&(v707_4));
            drop(v707_4);
            let v707_7: Space = if (&(v707_5)).is_empty() { Space::new() } else {
              let v708_6: Space = routine_13(c, &v706_6_cursor.path()[v706_6_origin..(v706_6_origin + 1)], &(*p1), &v706_6_cursor);
              compose(&(v707_5),&(v708_6))
            };
            drop(v707_5);
            let v707_8: Space = intersect(&(*CONSTANT_2),&(v707_2));
            drop(v707_2);
            let v707_9: Space = if has_head(&(v707_8)) { singleton(&[]) } else { Space::new() };
            drop(v707_8);
            let v707_11: Space = if (&(v707_9)).is_empty() { Space::new() } else {
              let v709_10: Space = routine_14(c, &v706_6_cursor.path()[v706_6_origin..(v706_6_origin + 1)], &(*p1), &v706_6_cursor);
              compose(&(v707_9),&(v709_10))
            };
            drop(v707_9);
            let v707_12: Space = unite(&(v707_7),&(v707_11));
            join_wrapped_into(&mut v706_6_write,&((v707_12).read_zipper()),&[]);
            }
            v706_6_cursor.ascend(1);
          }
          drop(v706_6_cursor);
          drop(v706_6_write);
          compose(&(v705_4),&(v706_6))
        };
        drop(v705_4);
        join_wrapped_into(&mut v704_6_write,&((v705_7).read_zipper()),&[]);
        }
        v702_12_cursor.ascend(1);
      }
      drop(v704_6_write);
      compose(&(v703_4),&(v704_6))
    };
    drop(v703_4);
    join_wrapped_into(&mut v702_12_write,&((v703_7).read_zipper()),&[]);
    }
    v702_12_cursor.ascend(1);
  }
  drop(v702_12_cursor);
  drop(v702_12_write);
  (v702_12).clone()
}

fn routine_39(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v710_17 = Space::new();
  let mut v710_17_write = v710_17.write_zipper();
  let mut v710_17_cursor = (*s0).read_zipper();
  let v710_17_origin = v710_17_cursor.path().len();
  for v710_17_byte in v710_17_cursor.child_mask().iter() {
    v710_17_cursor.descend_to_existing_byte(v710_17_byte);
    {
    let v711_2: Space = singleton(&v710_17_cursor.path()[v710_17_origin..(v710_17_origin + 1)]);
    let v711_3: Space = intersect(&(*CONSTANT_2),&(v711_2));
    drop(v711_2);
    let v711_4: Space = if has_head(&(v711_3)) { singleton(&[]) } else { Space::new() };
    drop(v711_3);
    let v711_7: Space = if (&(v711_4)).is_empty() { Space::new() } else {
      let mut v712_6 = Space::new();
      let mut v712_6_write = v712_6.write_zipper();
      let mut v712_6_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v710_17_cursor.path()[v710_17_origin..(v710_17_origin + 1)]);
      let v712_6_origin = v712_6_cursor.path().len();
      for v712_6_byte in v712_6_cursor.child_mask().iter() {
        v712_6_cursor.descend_to_existing_byte(v712_6_byte);
        {
        let v713_2: Space = singleton(&v712_6_cursor.path()[v712_6_origin..(v712_6_origin + 1)]);
        let v713_3: Space = intersect(&(*CONSTANT_2),&(v713_2));
        let v713_4: Space = if has_head(&(v713_3)) { singleton(&[]) } else { Space::new() };
        drop(v713_3);
        let v713_5: Space = subtract(&(*CONSTANT_1),&(v713_4));
        drop(v713_4);
        let v713_7: Space = if (&(v713_5)).is_empty() { Space::new() } else {
          let mut v714_6 = Space::new();
          let mut v714_6_write = v714_6.write_zipper();
          for v714_6_byte in v712_6_cursor.child_mask().iter() {
            v712_6_cursor.descend_to_existing_byte(v714_6_byte);
            {
            let v715_2: Space = singleton(&v712_6_cursor.path()[(v712_6_origin + 1)..(v712_6_origin + 2)]);
            let v715_3: Space = intersect(&(*CONSTANT_2),&(v715_2));
            let v715_4: Space = if has_head(&(v715_3)) { singleton(&[]) } else { Space::new() };
            drop(v715_3);
            let v715_5: Space = subtract(&(*CONSTANT_1),&(v715_4));
            drop(v715_4);
            let v715_8: Space = if (&(v715_5)).is_empty() { Space::new() } else {
              let v716_7: Space = routine_17(c, &v712_6_cursor.path()[v712_6_origin..(v712_6_origin + 2)], &(*p1), &v712_6_cursor);
              compose(&(v715_5),&(v716_7))
            };
            drop(v715_5);
            let v715_9: Space = intersect(&(*CONSTANT_2),&(v715_2));
            drop(v715_2);
            let v715_10: Space = if has_head(&(v715_9)) { singleton(&[]) } else { Space::new() };
            drop(v715_9);
            let v715_12: Space = if (&(v715_10)).is_empty() { Space::new() } else {
              let v717_11: Space = routine_18(c, &v712_6_cursor.path()[v712_6_origin..(v712_6_origin + 2)], &(*p1), &v712_6_cursor);
              compose(&(v715_10),&(v717_11))
            };
            drop(v715_10);
            let v715_13: Space = unite(&(v715_8),&(v715_12));
            join_wrapped_into(&mut v714_6_write,&((v715_13).read_zipper()),&[]);
            }
            v712_6_cursor.ascend(1);
          }
          drop(v714_6_write);
          compose(&(v713_5),&(v714_6))
        };
        drop(v713_5);
        let v713_8: Space = intersect(&(*CONSTANT_2),&(v713_2));
        drop(v713_2);
        let v713_9: Space = if has_head(&(v713_8)) { singleton(&[]) } else { Space::new() };
        drop(v713_8);
        let v713_11: Space = if (&(v713_9)).is_empty() { Space::new() } else {
          let mut v718_10 = Space::new();
          let mut v718_10_write = v718_10.write_zipper();
          for v718_10_byte in v712_6_cursor.child_mask().iter() {
            v712_6_cursor.descend_to_existing_byte(v718_10_byte);
            {
            let v719_2: Space = singleton(&v712_6_cursor.path()[(v712_6_origin + 1)..(v712_6_origin + 2)]);
            let v719_3: Space = intersect(&(*CONSTANT_2),&(v719_2));
            let v719_4: Space = if has_head(&(v719_3)) { singleton(&[]) } else { Space::new() };
            drop(v719_3);
            let v719_5: Space = subtract(&(*CONSTANT_1),&(v719_4));
            drop(v719_4);
            let v719_8: Space = if (&(v719_5)).is_empty() { Space::new() } else {
              let v720_7: Space = routine_17(c, &v712_6_cursor.path()[v712_6_origin..(v712_6_origin + 2)], &(*p1), &v712_6_cursor);
              compose(&(v719_5),&(v720_7))
            };
            drop(v719_5);
            let v719_9: Space = intersect(&(*CONSTANT_2),&(v719_2));
            drop(v719_2);
            let v719_10: Space = if has_head(&(v719_9)) { singleton(&[]) } else { Space::new() };
            drop(v719_9);
            let v719_12: Space = if (&(v719_10)).is_empty() { Space::new() } else {
              let v721_11: Space = routine_19(c, &v712_6_cursor.path()[v712_6_origin..(v712_6_origin + 2)], &(*p1), &v712_6_cursor);
              compose(&(v719_10),&(v721_11))
            };
            drop(v719_10);
            let v719_13: Space = unite(&(v719_8),&(v719_12));
            join_wrapped_into(&mut v718_10_write,&((v719_13).read_zipper()),&[]);
            }
            v712_6_cursor.ascend(1);
          }
          drop(v718_10_write);
          compose(&(v713_9),&(v718_10))
        };
        drop(v713_9);
        let v713_12: Space = unite(&(v713_7),&(v713_11));
        join_wrapped_into(&mut v712_6_write,&((v713_12).read_zipper()),&[]);
        }
        v712_6_cursor.ascend(1);
      }
      drop(v712_6_cursor);
      drop(v712_6_write);
      compose(&(v711_4),&(v712_6))
    };
    drop(v711_4);
    join_wrapped_into(&mut v710_17_write,&((v711_7).read_zipper()),&[]);
    }
    v710_17_cursor.ascend(1);
  }
  drop(v710_17_cursor);
  drop(v710_17_write);
  (v710_17).clone()
}

fn routine_40(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v722_21 = Space::new();
  let mut v722_21_write = v722_21.write_zipper();
  let mut v722_21_cursor = (*s0).read_zipper();
  let v722_21_origin = v722_21_cursor.path().len();
  for v722_21_byte in v722_21_cursor.child_mask().iter() {
    v722_21_cursor.descend_to_existing_byte(v722_21_byte);
    {
    let v723_2: Space = singleton(&v722_21_cursor.path()[v722_21_origin..(v722_21_origin + 1)]);
    let v723_3: Space = intersect(&(*CONSTANT_2),&(v723_2));
    let v723_4: Space = if has_head(&(v723_3)) { singleton(&[]) } else { Space::new() };
    drop(v723_3);
    let v723_5: Space = subtract(&(*CONSTANT_1),&(v723_4));
    drop(v723_4);
    let v723_8: Space = if (&(v723_5)).is_empty() { Space::new() } else {
      let v724_6: Path = concat_path(&(*p0),&v722_21_cursor.path()[v722_21_origin..(v722_21_origin + 1)]);
      let mut v724_7 = Space::new();
      let mut v724_7_write = v724_7.write_zipper();
      for v724_7_byte in v722_21_cursor.child_mask().iter() {
        v722_21_cursor.descend_to_existing_byte(v724_7_byte);
        {
        let v725_2: Space = singleton(&v722_21_cursor.path()[(v722_21_origin + 1)..(v722_21_origin + 2)]);
        let v725_3: Space = intersect(&(*CONSTANT_2),&(v725_2));
        let v725_4: Space = if has_head(&(v725_3)) { singleton(&[]) } else { Space::new() };
        drop(v725_3);
        let v725_5: Space = subtract(&(*CONSTANT_1),&(v725_4));
        drop(v725_4);
        let v725_8: Space = if (&(v725_5)).is_empty() { Space::new() } else {
          let v726_6: Path = concat_path(&(v724_6),&v722_21_cursor.path()[(v722_21_origin + 1)..(v722_21_origin + 2)]);
          let mut v726_7 = Space::new();
          let mut v726_7_write = v726_7.write_zipper();
          for v726_7_byte in v722_21_cursor.child_mask().iter() {
            v722_21_cursor.descend_to_existing_byte(v726_7_byte);
            {
            let v727_2: Space = singleton(&v722_21_cursor.path()[(v722_21_origin + 2)..(v722_21_origin + 3)]);
            let v727_3: Space = intersect(&(*CONSTANT_2),&(v727_2));
            let v727_4: Space = if has_head(&(v727_3)) { singleton(&[]) } else { Space::new() };
            drop(v727_3);
            let v727_5: Space = subtract(&(*CONSTANT_1),&(v727_4));
            drop(v727_4);
            let v727_8: Space = if (&(v727_5)).is_empty() { Space::new() } else {
              let v728_6: Path = concat_path(&(v726_6),&v722_21_cursor.path()[(v722_21_origin + 2)..(v722_21_origin + 3)]);
              let v728_7: Space = routine_48(c, &(v728_6), &(*p1), &v722_21_cursor);
              compose(&(v727_5),&(v728_7))
            };
            drop(v727_5);
            let v727_9: Space = intersect(&(*CONSTANT_2),&(v727_2));
            drop(v727_2);
            let v727_10: Space = if has_head(&(v727_9)) { singleton(&[]) } else { Space::new() };
            drop(v727_9);
            let v727_12: Space = if (&(v727_10)).is_empty() { Space::new() } else {
              let v729_6: Path = concat_path(&(v726_6),&v722_21_cursor.path()[(v722_21_origin + 2)..(v722_21_origin + 3)]);
              let v729_11: Space = routine_49(c, &(v729_6), &(*p1), &v722_21_cursor);
              drop(v729_6);
              compose(&(v727_10),&(v729_11))
            };
            drop(v727_10);
            let v727_13: Space = unite(&(v727_8),&(v727_12));
            join_wrapped_into(&mut v726_7_write,&((v727_13).read_zipper()),&[]);
            }
            v722_21_cursor.ascend(1);
          }
          drop(v726_7_write);
          compose(&(v725_5),&(v726_7))
        };
        drop(v725_5);
        let v725_9: Space = intersect(&(*CONSTANT_2),&(v725_2));
        drop(v725_2);
        let v725_10: Space = if has_head(&(v725_9)) { singleton(&[]) } else { Space::new() };
        drop(v725_9);
        let v725_12: Space = if (&(v725_10)).is_empty() { Space::new() } else {
          let v730_6: Path = concat_path(&(v724_6),&v722_21_cursor.path()[(v722_21_origin + 1)..(v722_21_origin + 2)]);
          let mut v730_11 = Space::new();
          let mut v730_11_write = v730_11.write_zipper();
          for v730_11_byte in v722_21_cursor.child_mask().iter() {
            v722_21_cursor.descend_to_existing_byte(v730_11_byte);
            {
            let v731_2: Space = singleton(&v722_21_cursor.path()[(v722_21_origin + 2)..(v722_21_origin + 3)]);
            let v731_3: Space = intersect(&(*CONSTANT_2),&(v731_2));
            let v731_4: Space = if has_head(&(v731_3)) { singleton(&[]) } else { Space::new() };
            drop(v731_3);
            let v731_5: Space = subtract(&(*CONSTANT_1),&(v731_4));
            drop(v731_4);
            let v731_8: Space = if (&(v731_5)).is_empty() { Space::new() } else {
              let v732_6: Path = concat_path(&(v730_6),&v722_21_cursor.path()[(v722_21_origin + 2)..(v722_21_origin + 3)]);
              let v732_7: Space = routine_48(c, &(v732_6), &(*p1), &v722_21_cursor);
              compose(&(v731_5),&(v732_7))
            };
            drop(v731_5);
            let v731_9: Space = intersect(&(*CONSTANT_2),&(v731_2));
            drop(v731_2);
            let v731_10: Space = if has_head(&(v731_9)) { singleton(&[]) } else { Space::new() };
            drop(v731_9);
            let v731_12: Space = if (&(v731_10)).is_empty() { Space::new() } else {
              let v733_6: Path = concat_path(&(v730_6),&v722_21_cursor.path()[(v722_21_origin + 2)..(v722_21_origin + 3)]);
              let v733_11: Space = routine_19(c, &(v733_6), &(*p1), &v722_21_cursor);
              drop(v733_6);
              compose(&(v731_10),&(v733_11))
            };
            drop(v731_10);
            let v731_13: Space = unite(&(v731_8),&(v731_12));
            join_wrapped_into(&mut v730_11_write,&((v731_13).read_zipper()),&[]);
            }
            v722_21_cursor.ascend(1);
          }
          drop(v730_11_write);
          drop(v730_6);
          compose(&(v725_10),&(v730_11))
        };
        drop(v725_10);
        let v725_13: Space = unite(&(v725_8),&(v725_12));
        join_wrapped_into(&mut v724_7_write,&((v725_13).read_zipper()),&[]);
        }
        v722_21_cursor.ascend(1);
      }
      drop(v724_7_write);
      compose(&(v723_5),&(v724_7))
    };
    drop(v723_5);
    let v723_9: Space = intersect(&(*CONSTANT_2),&(v723_2));
    drop(v723_2);
    let v723_10: Space = if has_head(&(v723_9)) { singleton(&[]) } else { Space::new() };
    drop(v723_9);
    let v723_12: Space = if (&(v723_10)).is_empty() { Space::new() } else {
      let v734_6: Path = concat_path(&(*p0),&v722_21_cursor.path()[v722_21_origin..(v722_21_origin + 1)]);
      let mut v734_11 = Space::new();
      let mut v734_11_write = v734_11.write_zipper();
      for v734_11_byte in v722_21_cursor.child_mask().iter() {
        v722_21_cursor.descend_to_existing_byte(v734_11_byte);
        {
        let v735_2: Space = singleton(&v722_21_cursor.path()[(v722_21_origin + 1)..(v722_21_origin + 2)]);
        let v735_3: Space = intersect(&(*CONSTANT_2),&(v735_2));
        let v735_4: Space = if has_head(&(v735_3)) { singleton(&[]) } else { Space::new() };
        drop(v735_3);
        let v735_5: Space = subtract(&(*CONSTANT_1),&(v735_4));
        drop(v735_4);
        let v735_8: Space = if (&(v735_5)).is_empty() { Space::new() } else {
          let v736_6: Path = concat_path(&(v734_6),&v722_21_cursor.path()[(v722_21_origin + 1)..(v722_21_origin + 2)]);
          let mut v736_7 = Space::new();
          let mut v736_7_write = v736_7.write_zipper();
          for v736_7_byte in v722_21_cursor.child_mask().iter() {
            v722_21_cursor.descend_to_existing_byte(v736_7_byte);
            {
            let v737_2: Space = singleton(&v722_21_cursor.path()[(v722_21_origin + 2)..(v722_21_origin + 3)]);
            let v737_3: Space = intersect(&(*CONSTANT_2),&(v737_2));
            let v737_4: Space = if has_head(&(v737_3)) { singleton(&[]) } else { Space::new() };
            drop(v737_3);
            let v737_5: Space = subtract(&(*CONSTANT_1),&(v737_4));
            drop(v737_4);
            let v737_8: Space = if (&(v737_5)).is_empty() { Space::new() } else {
              let v738_6: Path = concat_path(&(v736_6),&v722_21_cursor.path()[(v722_21_origin + 2)..(v722_21_origin + 3)]);
              let v738_7: Space = routine_48(c, &(v738_6), &(*p1), &v722_21_cursor);
              compose(&(v737_5),&(v738_7))
            };
            drop(v737_5);
            let v737_9: Space = intersect(&(*CONSTANT_2),&(v737_2));
            drop(v737_2);
            let v737_10: Space = if has_head(&(v737_9)) { singleton(&[]) } else { Space::new() };
            drop(v737_9);
            let v737_12: Space = if (&(v737_10)).is_empty() { Space::new() } else {
              let v739_6: Path = concat_path(&(v736_6),&v722_21_cursor.path()[(v722_21_origin + 2)..(v722_21_origin + 3)]);
              let v739_11: Space = routine_49(c, &(v739_6), &(*p1), &v722_21_cursor);
              drop(v739_6);
              compose(&(v737_10),&(v739_11))
            };
            drop(v737_10);
            let v737_13: Space = unite(&(v737_8),&(v737_12));
            join_wrapped_into(&mut v736_7_write,&((v737_13).read_zipper()),&[]);
            }
            v722_21_cursor.ascend(1);
          }
          drop(v736_7_write);
          compose(&(v735_5),&(v736_7))
        };
        drop(v735_5);
        let v735_9: Space = intersect(&(*CONSTANT_2),&(v735_2));
        drop(v735_2);
        let v735_10: Space = if has_head(&(v735_9)) { singleton(&[]) } else { Space::new() };
        drop(v735_9);
        let v735_11: Space = compose(&(v735_10),&v722_21_cursor);
        drop(v735_10);
        let v740_6: Path = concat_path(&(v734_6),&v722_21_cursor.path()[(v722_21_origin + 1)..(v722_21_origin + 2)]);
        let v735_12: Space = wrap(&(v735_11),&(v740_6));
        drop(v735_11);
        let v735_13: Space = wrap(&(v735_12),&(*p1));
        drop(v735_12);
        let v735_14: Space = unite(&(v735_8),&(v735_13));
        drop(v735_13);
        join_wrapped_into(&mut v734_11_write,&((v735_14).read_zipper()),&[]);
        }
        v722_21_cursor.ascend(1);
      }
      drop(v734_11_write);
      drop(v734_6);
      compose(&(v723_10),&(v734_11))
    };
    drop(v723_10);
    let v723_13: Space = unite(&(v723_8),&(v723_12));
    join_wrapped_into(&mut v722_21_write,&((v723_13).read_zipper()),&[]);
    }
    v722_21_cursor.ascend(1);
  }
  drop(v722_21_cursor);
  drop(v722_21_write);
  (v722_21).clone()
}

fn routine_41(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v741_15 = Space::new();
  let mut v741_15_write = v741_15.write_zipper();
  let mut v741_15_cursor = (*s0).read_zipper();
  let v741_15_origin = v741_15_cursor.path().len();
  for v741_15_byte in v741_15_cursor.child_mask().iter() {
    v741_15_cursor.descend_to_existing_byte(v741_15_byte);
    {
    let v742_2: Space = singleton(&v741_15_cursor.path()[v741_15_origin..(v741_15_origin + 1)]);
    let v742_3: Space = intersect(&(*CONSTANT_2),&(v742_2));
    let v742_4: Space = if has_head(&(v742_3)) { singleton(&[]) } else { Space::new() };
    drop(v742_3);
    let v742_5: Space = subtract(&(*CONSTANT_1),&(v742_4));
    drop(v742_4);
    let v742_8: Space = if (&(v742_5)).is_empty() { Space::new() } else {
      let v743_6: Path = concat_path(&(*p0),&v741_15_cursor.path()[v741_15_origin..(v741_15_origin + 1)]);
      let mut v743_7 = Space::new();
      let mut v743_7_write = v743_7.write_zipper();
      for v743_7_byte in v741_15_cursor.child_mask().iter() {
        v741_15_cursor.descend_to_existing_byte(v743_7_byte);
        {
        let v744_2: Space = singleton(&v741_15_cursor.path()[(v741_15_origin + 1)..(v741_15_origin + 2)]);
        let v744_3: Space = intersect(&(*CONSTANT_2),&(v744_2));
        let v744_4: Space = if has_head(&(v744_3)) { singleton(&[]) } else { Space::new() };
        drop(v744_3);
        let v744_5: Space = subtract(&(*CONSTANT_1),&(v744_4));
        drop(v744_4);
        let v744_8: Space = if (&(v744_5)).is_empty() { Space::new() } else {
          let v745_6: Path = concat_path(&(v743_6),&v741_15_cursor.path()[(v741_15_origin + 1)..(v741_15_origin + 2)]);
          let mut v745_7 = Space::new();
          let mut v745_7_write = v745_7.write_zipper();
          for v745_7_byte in v741_15_cursor.child_mask().iter() {
            v741_15_cursor.descend_to_existing_byte(v745_7_byte);
            {
            let v746_2: Space = singleton(&v741_15_cursor.path()[(v741_15_origin + 2)..(v741_15_origin + 3)]);
            let v746_3: Space = intersect(&(*CONSTANT_2),&(v746_2));
            let v746_4: Space = if has_head(&(v746_3)) { singleton(&[]) } else { Space::new() };
            drop(v746_3);
            let v746_5: Space = subtract(&(*CONSTANT_1),&(v746_4));
            drop(v746_4);
            let v746_8: Space = if (&(v746_5)).is_empty() { Space::new() } else {
              let v747_6: Path = concat_path(&(v745_6),&v741_15_cursor.path()[(v741_15_origin + 2)..(v741_15_origin + 3)]);
              let v747_7: Space = routine_48(c, &(v747_6), &(*p1), &v741_15_cursor);
              compose(&(v746_5),&(v747_7))
            };
            drop(v746_5);
            let v746_9: Space = intersect(&(*CONSTANT_2),&(v746_2));
            drop(v746_2);
            let v746_10: Space = if has_head(&(v746_9)) { singleton(&[]) } else { Space::new() };
            drop(v746_9);
            let v746_12: Space = if (&(v746_10)).is_empty() { Space::new() } else {
              let v748_6: Path = concat_path(&(v745_6),&v741_15_cursor.path()[(v741_15_origin + 2)..(v741_15_origin + 3)]);
              let v748_11: Space = routine_49(c, &(v748_6), &(*p1), &v741_15_cursor);
              drop(v748_6);
              compose(&(v746_10),&(v748_11))
            };
            drop(v746_10);
            let v746_13: Space = unite(&(v746_8),&(v746_12));
            join_wrapped_into(&mut v745_7_write,&((v746_13).read_zipper()),&[]);
            }
            v741_15_cursor.ascend(1);
          }
          drop(v745_7_write);
          compose(&(v744_5),&(v745_7))
        };
        drop(v744_5);
        let v744_9: Space = intersect(&(*CONSTANT_2),&(v744_2));
        drop(v744_2);
        let v744_10: Space = if has_head(&(v744_9)) { singleton(&[]) } else { Space::new() };
        drop(v744_9);
        let v744_12: Space = if (&(v744_10)).is_empty() { Space::new() } else {
          let v749_6: Path = concat_path(&(v743_6),&v741_15_cursor.path()[(v741_15_origin + 1)..(v741_15_origin + 2)]);
          let mut v749_11 = Space::new();
          let mut v749_11_write = v749_11.write_zipper();
          for v749_11_byte in v741_15_cursor.child_mask().iter() {
            v741_15_cursor.descend_to_existing_byte(v749_11_byte);
            {
            let v750_2: Space = singleton(&v741_15_cursor.path()[(v741_15_origin + 2)..(v741_15_origin + 3)]);
            let v750_3: Space = intersect(&(*CONSTANT_2),&(v750_2));
            let v750_4: Space = if has_head(&(v750_3)) { singleton(&[]) } else { Space::new() };
            drop(v750_3);
            let v750_5: Space = subtract(&(*CONSTANT_1),&(v750_4));
            drop(v750_4);
            let v750_8: Space = if (&(v750_5)).is_empty() { Space::new() } else {
              let v751_6: Path = concat_path(&(v749_6),&v741_15_cursor.path()[(v741_15_origin + 2)..(v741_15_origin + 3)]);
              let v751_7: Space = routine_48(c, &(v751_6), &(*p1), &v741_15_cursor);
              compose(&(v750_5),&(v751_7))
            };
            drop(v750_5);
            let v750_9: Space = intersect(&(*CONSTANT_2),&(v750_2));
            drop(v750_2);
            let v750_10: Space = if has_head(&(v750_9)) { singleton(&[]) } else { Space::new() };
            drop(v750_9);
            let v750_12: Space = if (&(v750_10)).is_empty() { Space::new() } else {
              let v752_6: Path = concat_path(&(v749_6),&v741_15_cursor.path()[(v741_15_origin + 2)..(v741_15_origin + 3)]);
              let v752_11: Space = routine_19(c, &(v752_6), &(*p1), &v741_15_cursor);
              drop(v752_6);
              compose(&(v750_10),&(v752_11))
            };
            drop(v750_10);
            let v750_13: Space = unite(&(v750_8),&(v750_12));
            join_wrapped_into(&mut v749_11_write,&((v750_13).read_zipper()),&[]);
            }
            v741_15_cursor.ascend(1);
          }
          drop(v749_11_write);
          drop(v749_6);
          compose(&(v744_10),&(v749_11))
        };
        drop(v744_10);
        let v744_13: Space = unite(&(v744_8),&(v744_12));
        join_wrapped_into(&mut v743_7_write,&((v744_13).read_zipper()),&[]);
        }
        v741_15_cursor.ascend(1);
      }
      drop(v743_7_write);
      compose(&(v742_5),&(v743_7))
    };
    drop(v742_5);
    let v742_9: Space = intersect(&(*CONSTANT_2),&(v742_2));
    drop(v742_2);
    let v742_10: Space = if has_head(&(v742_9)) { singleton(&[]) } else { Space::new() };
    drop(v742_9);
    let v742_11: Space = compose(&(v742_10),&v741_15_cursor);
    drop(v742_10);
    let v753_6: Path = concat_path(&(*p0),&v741_15_cursor.path()[v741_15_origin..(v741_15_origin + 1)]);
    let v742_12: Space = wrap(&(v742_11),&(v753_6));
    drop(v742_11);
    let v742_13: Space = wrap(&(v742_12),&(*p1));
    drop(v742_12);
    let v742_14: Space = unite(&(v742_8),&(v742_13));
    drop(v742_13);
    join_wrapped_into(&mut v741_15_write,&((v742_14).read_zipper()),&[]);
    }
    v741_15_cursor.ascend(1);
  }
  drop(v741_15_cursor);
  drop(v741_15_write);
  (v741_15).clone()
}

fn routine_42(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v754_4: Space = Space::new();
  (v754_4).clone()
}

fn routine_43(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v755_17 = Space::new();
  let mut v755_17_write = v755_17.write_zipper();
  let mut v755_17_cursor = (*s0).read_zipper();
  let v755_17_origin = v755_17_cursor.path().len();
  for v755_17_byte in v755_17_cursor.child_mask().iter() {
    v755_17_cursor.descend_to_existing_byte(v755_17_byte);
    {
    let v756_2: Space = singleton(&v755_17_cursor.path()[v755_17_origin..(v755_17_origin + 1)]);
    let v756_3: Space = intersect(&(*CONSTANT_2),&(v756_2));
    drop(v756_2);
    let v756_4: Space = if has_head(&(v756_3)) { singleton(&[]) } else { Space::new() };
    drop(v756_3);
    let v756_7: Space = if (&(v756_4)).is_empty() { Space::new() } else {
      let mut v757_6 = Space::new();
      let mut v757_6_write = v757_6.write_zipper();
      let mut v757_6_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v755_17_cursor.path()[v755_17_origin..(v755_17_origin + 1)]);
      let v757_6_origin = v757_6_cursor.path().len();
      for v757_6_byte in v757_6_cursor.child_mask().iter() {
        v757_6_cursor.descend_to_existing_byte(v757_6_byte);
        {
        let v758_2: Space = singleton(&v757_6_cursor.path()[v757_6_origin..(v757_6_origin + 1)]);
        let v758_3: Space = intersect(&(*CONSTANT_2),&(v758_2));
        let v758_4: Space = if has_head(&(v758_3)) { singleton(&[]) } else { Space::new() };
        drop(v758_3);
        let v758_5: Space = subtract(&(*CONSTANT_1),&(v758_4));
        drop(v758_4);
        let v758_7: Space = if (&(v758_5)).is_empty() { Space::new() } else {
          let mut v759_6 = Space::new();
          let mut v759_6_write = v759_6.write_zipper();
          for v759_6_byte in v757_6_cursor.child_mask().iter() {
            v757_6_cursor.descend_to_existing_byte(v759_6_byte);
            {
            let v760_2: Space = singleton(&v757_6_cursor.path()[(v757_6_origin + 1)..(v757_6_origin + 2)]);
            let v760_3: Space = intersect(&(*CONSTANT_2),&(v760_2));
            let v760_4: Space = if has_head(&(v760_3)) { singleton(&[]) } else { Space::new() };
            drop(v760_3);
            let v760_5: Space = subtract(&(*CONSTANT_1),&(v760_4));
            drop(v760_4);
            let v760_8: Space = if (&(v760_5)).is_empty() { Space::new() } else {
              let v761_7: Space = routine_17(c, &v757_6_cursor.path()[v757_6_origin..(v757_6_origin + 2)], &(*p1), &v757_6_cursor);
              compose(&(v760_5),&(v761_7))
            };
            drop(v760_5);
            let v760_9: Space = intersect(&(*CONSTANT_2),&(v760_2));
            drop(v760_2);
            let v760_10: Space = if has_head(&(v760_9)) { singleton(&[]) } else { Space::new() };
            drop(v760_9);
            let v760_12: Space = if (&(v760_10)).is_empty() { Space::new() } else {
              let v762_11: Space = routine_18(c, &v757_6_cursor.path()[v757_6_origin..(v757_6_origin + 2)], &(*p1), &v757_6_cursor);
              compose(&(v760_10),&(v762_11))
            };
            drop(v760_10);
            let v760_13: Space = unite(&(v760_8),&(v760_12));
            join_wrapped_into(&mut v759_6_write,&((v760_13).read_zipper()),&[]);
            }
            v757_6_cursor.ascend(1);
          }
          drop(v759_6_write);
          compose(&(v758_5),&(v759_6))
        };
        drop(v758_5);
        let v758_8: Space = intersect(&(*CONSTANT_2),&(v758_2));
        drop(v758_2);
        let v758_9: Space = if has_head(&(v758_8)) { singleton(&[]) } else { Space::new() };
        drop(v758_8);
        let v758_11: Space = if (&(v758_9)).is_empty() { Space::new() } else {
          let mut v763_10 = Space::new();
          let mut v763_10_write = v763_10.write_zipper();
          for v763_10_byte in v757_6_cursor.child_mask().iter() {
            v757_6_cursor.descend_to_existing_byte(v763_10_byte);
            {
            let v764_2: Space = singleton(&v757_6_cursor.path()[(v757_6_origin + 1)..(v757_6_origin + 2)]);
            let v764_3: Space = intersect(&(*CONSTANT_2),&(v764_2));
            let v764_4: Space = if has_head(&(v764_3)) { singleton(&[]) } else { Space::new() };
            drop(v764_3);
            let v764_5: Space = subtract(&(*CONSTANT_1),&(v764_4));
            drop(v764_4);
            let v764_8: Space = if (&(v764_5)).is_empty() { Space::new() } else {
              let v765_7: Space = routine_17(c, &v757_6_cursor.path()[v757_6_origin..(v757_6_origin + 2)], &(*p1), &v757_6_cursor);
              compose(&(v764_5),&(v765_7))
            };
            drop(v764_5);
            let v764_9: Space = intersect(&(*CONSTANT_2),&(v764_2));
            drop(v764_2);
            let v764_10: Space = if has_head(&(v764_9)) { singleton(&[]) } else { Space::new() };
            drop(v764_9);
            let v764_12: Space = if (&(v764_10)).is_empty() { Space::new() } else {
              let v766_11: Space = routine_19(c, &v757_6_cursor.path()[v757_6_origin..(v757_6_origin + 2)], &(*p1), &v757_6_cursor);
              compose(&(v764_10),&(v766_11))
            };
            drop(v764_10);
            let v764_13: Space = unite(&(v764_8),&(v764_12));
            join_wrapped_into(&mut v763_10_write,&((v764_13).read_zipper()),&[]);
            }
            v757_6_cursor.ascend(1);
          }
          drop(v763_10_write);
          compose(&(v758_9),&(v763_10))
        };
        drop(v758_9);
        let v758_12: Space = unite(&(v758_7),&(v758_11));
        join_wrapped_into(&mut v757_6_write,&((v758_12).read_zipper()),&[]);
        }
        v757_6_cursor.ascend(1);
      }
      drop(v757_6_cursor);
      drop(v757_6_write);
      compose(&(v756_4),&(v757_6))
    };
    drop(v756_4);
    join_wrapped_into(&mut v755_17_write,&((v756_7).read_zipper()),&[]);
    }
    v755_17_cursor.ascend(1);
  }
  drop(v755_17_cursor);
  drop(v755_17_write);
  (v755_17).clone()
}

fn routine_44(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v767_9 = Space::new();
  let mut v767_9_write = v767_9.write_zipper();
  let mut v767_9_cursor = (*s0).read_zipper();
  let v767_9_origin = v767_9_cursor.path().len();
  for v767_9_byte in v767_9_cursor.child_mask().iter() {
    v767_9_cursor.descend_to_existing_byte(v767_9_byte);
    {
    let v768_2: Space = singleton(&v767_9_cursor.path()[v767_9_origin..(v767_9_origin + 1)]);
    let v768_3: Space = intersect(&(*CONSTANT_2),&(v768_2));
    let v768_4: Space = if has_head(&(v768_3)) { singleton(&[]) } else { Space::new() };
    drop(v768_3);
    let v768_5: Space = subtract(&(*CONSTANT_1),&(v768_4));
    drop(v768_4);
    let v768_8: Space = if (&(v768_5)).is_empty() { Space::new() } else {
      let v769_6: Path = concat_path(&(*p0),&v767_9_cursor.path()[v767_9_origin..(v767_9_origin + 1)]);
      let mut v769_7 = Space::new();
      let mut v769_7_write = v769_7.write_zipper();
      for v769_7_byte in v767_9_cursor.child_mask().iter() {
        v767_9_cursor.descend_to_existing_byte(v769_7_byte);
        {
        let v770_2: Space = singleton(&v767_9_cursor.path()[(v767_9_origin + 1)..(v767_9_origin + 2)]);
        let v770_3: Space = intersect(&(*CONSTANT_2),&(v770_2));
        drop(v770_2);
        let v770_4: Space = if has_head(&(v770_3)) { singleton(&[]) } else { Space::new() };
        drop(v770_3);
        let v770_7: Space = if (&(v770_4)).is_empty() { Space::new() } else {
          let v771_5: Path = concat_path(&(v769_6),&v767_9_cursor.path()[(v767_9_origin + 1)..(v767_9_origin + 2)]);
          let mut v771_6 = Space::new();
          let mut v771_6_write = v771_6.write_zipper();
          for v771_6_byte in v767_9_cursor.child_mask().iter() {
            v767_9_cursor.descend_to_existing_byte(v771_6_byte);
            {
            let v772_2: Space = singleton(&v767_9_cursor.path()[(v767_9_origin + 2)..(v767_9_origin + 3)]);
            let v772_3: Space = intersect(&(*CONSTANT_2),&(v772_2));
            drop(v772_2);
            let v772_4: Space = if has_head(&(v772_3)) { singleton(&[]) } else { Space::new() };
            drop(v772_3);
            let v772_7: Space = if (&(v772_4)).is_empty() { Space::new() } else {
              let v773_5: Path = concat_path(&(v771_5),&v767_9_cursor.path()[(v767_9_origin + 2)..(v767_9_origin + 3)]);
              let v773_6: Space = routine_19(c, &(v773_5), &(*p1), &v767_9_cursor);
              drop(v773_5);
              compose(&(v772_4),&(v773_6))
            };
            drop(v772_4);
            join_wrapped_into(&mut v771_6_write,&((v772_7).read_zipper()),&[]);
            }
            v767_9_cursor.ascend(1);
          }
          drop(v771_6_write);
          drop(v771_5);
          compose(&(v770_4),&(v771_6))
        };
        drop(v770_4);
        join_wrapped_into(&mut v769_7_write,&((v770_7).read_zipper()),&[]);
        }
        v767_9_cursor.ascend(1);
      }
      drop(v769_7_write);
      compose(&(v768_5),&(v769_7))
    };
    drop(v768_5);
    let v768_9: Space = intersect(&(*CONSTANT_2),&(v768_2));
    drop(v768_2);
    let v768_10: Space = if has_head(&(v768_9)) { singleton(&[]) } else { Space::new() };
    drop(v768_9);
    let v768_12: Space = if (&(v768_10)).is_empty() { Space::new() } else {
      let v774_6: Path = concat_path(&(*p0),&v767_9_cursor.path()[v767_9_origin..(v767_9_origin + 1)]);
      let mut v774_11 = Space::new();
      let mut v774_11_write = v774_11.write_zipper();
      for v774_11_byte in v767_9_cursor.child_mask().iter() {
        v767_9_cursor.descend_to_existing_byte(v774_11_byte);
        {
        let v775_2: Space = singleton(&v767_9_cursor.path()[(v767_9_origin + 1)..(v767_9_origin + 2)]);
        let v775_3: Space = intersect(&(*CONSTANT_2),&(v775_2));
        drop(v775_2);
        let v775_4: Space = if has_head(&(v775_3)) { singleton(&[]) } else { Space::new() };
        drop(v775_3);
        let v775_5: Space = compose(&(v775_4),&v767_9_cursor);
        drop(v775_4);
        let v775_6: Path = concat_path(&(v774_6),&v767_9_cursor.path()[(v767_9_origin + 1)..(v767_9_origin + 2)]);
        join_wrapped_into(&mut v774_11_write,&((v775_5).read_zipper()),&(v775_6));
        drop(v775_5);
        drop(v775_6);
        }
        v767_9_cursor.ascend(1);
      }
      drop(v774_11_write);
      drop(v774_6);
      compose(&(v768_10),&(v774_11))
    };
    drop(v768_10);
    let v768_13: Space = wrap(&(v768_12),&(*p1));
    drop(v768_12);
    let v768_14: Space = unite(&(v768_8),&(v768_13));
    drop(v768_13);
    join_wrapped_into(&mut v767_9_write,&((v768_14).read_zipper()),&[]);
    }
    v767_9_cursor.ascend(1);
  }
  drop(v767_9_cursor);
  drop(v767_9_write);
  (v767_9).clone()
}

fn routine_45(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v776_8 = Space::new();
  let mut v776_8_write = v776_8.write_zipper();
  let mut v776_8_cursor = (*s0).read_zipper();
  let v776_8_origin = v776_8_cursor.path().len();
  for v776_8_byte in v776_8_cursor.child_mask().iter() {
    v776_8_cursor.descend_to_existing_byte(v776_8_byte);
    {
    let v777_2: Space = singleton(&v776_8_cursor.path()[v776_8_origin..(v776_8_origin + 1)]);
    let v777_3: Space = intersect(&(*CONSTANT_2),&(v777_2));
    let v777_4: Space = if has_head(&(v777_3)) { singleton(&[]) } else { Space::new() };
    drop(v777_3);
    let v777_5: Space = subtract(&(*CONSTANT_1),&(v777_4));
    drop(v777_4);
    let v777_8: Space = if (&(v777_5)).is_empty() { Space::new() } else {
      let v778_6: Path = concat_path(&(*p0),&v776_8_cursor.path()[v776_8_origin..(v776_8_origin + 1)]);
      let mut v778_7 = Space::new();
      let mut v778_7_write = v778_7.write_zipper();
      for v778_7_byte in v776_8_cursor.child_mask().iter() {
        v776_8_cursor.descend_to_existing_byte(v778_7_byte);
        {
        let v779_2: Space = singleton(&v776_8_cursor.path()[(v776_8_origin + 1)..(v776_8_origin + 2)]);
        let v779_3: Space = intersect(&(*CONSTANT_2),&(v779_2));
        drop(v779_2);
        let v779_4: Space = if has_head(&(v779_3)) { singleton(&[]) } else { Space::new() };
        drop(v779_3);
        let v779_7: Space = if (&(v779_4)).is_empty() { Space::new() } else {
          let v780_5: Path = concat_path(&(v778_6),&v776_8_cursor.path()[(v776_8_origin + 1)..(v776_8_origin + 2)]);
          let mut v780_6 = Space::new();
          let mut v780_6_write = v780_6.write_zipper();
          for v780_6_byte in v776_8_cursor.child_mask().iter() {
            v776_8_cursor.descend_to_existing_byte(v780_6_byte);
            {
            let v781_2: Space = singleton(&v776_8_cursor.path()[(v776_8_origin + 2)..(v776_8_origin + 3)]);
            let v781_3: Space = intersect(&(*CONSTANT_2),&(v781_2));
            drop(v781_2);
            let v781_4: Space = if has_head(&(v781_3)) { singleton(&[]) } else { Space::new() };
            drop(v781_3);
            let v781_7: Space = if (&(v781_4)).is_empty() { Space::new() } else {
              let v782_5: Path = concat_path(&(v780_5),&v776_8_cursor.path()[(v776_8_origin + 2)..(v776_8_origin + 3)]);
              let v782_6: Space = routine_19(c, &(v782_5), &(*p1), &v776_8_cursor);
              drop(v782_5);
              compose(&(v781_4),&(v782_6))
            };
            drop(v781_4);
            join_wrapped_into(&mut v780_6_write,&((v781_7).read_zipper()),&[]);
            }
            v776_8_cursor.ascend(1);
          }
          drop(v780_6_write);
          drop(v780_5);
          compose(&(v779_4),&(v780_6))
        };
        drop(v779_4);
        join_wrapped_into(&mut v778_7_write,&((v779_7).read_zipper()),&[]);
        }
        v776_8_cursor.ascend(1);
      }
      drop(v778_7_write);
      compose(&(v777_5),&(v778_7))
    };
    drop(v777_5);
    let v777_9: Space = intersect(&(*CONSTANT_2),&(v777_2));
    drop(v777_2);
    let v777_10: Space = if has_head(&(v777_9)) { singleton(&[]) } else { Space::new() };
    drop(v777_9);
    let v777_11: Space = compose(&(v777_10),&v776_8_cursor);
    drop(v777_10);
    let v783_6: Path = concat_path(&(*p0),&v776_8_cursor.path()[v776_8_origin..(v776_8_origin + 1)]);
    let v777_12: Space = wrap(&(v777_11),&(v783_6));
    drop(v777_11);
    let v777_13: Space = wrap(&(v777_12),&(*p1));
    drop(v777_12);
    let v777_14: Space = unite(&(v777_8),&(v777_13));
    drop(v777_13);
    join_wrapped_into(&mut v776_8_write,&((v777_14).read_zipper()),&[]);
    }
    v776_8_cursor.ascend(1);
  }
  drop(v776_8_cursor);
  drop(v776_8_write);
  (v776_8).clone()
}

fn routine_46(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v784_5 = Space::new();
  let mut v784_5_write = v784_5.write_zipper();
  let mut v784_5_cursor = (*s0).read_zipper();
  let v784_5_origin = v784_5_cursor.path().len();
  for v784_5_byte in v784_5_cursor.child_mask().iter() {
    v784_5_cursor.descend_to_existing_byte(v784_5_byte);
    {
    let v785_2: Space = singleton(&v784_5_cursor.path()[v784_5_origin..(v784_5_origin + 1)]);
    let v785_3: Space = intersect(&(*CONSTANT_2),&(v785_2));
    drop(v785_2);
    let v785_4: Space = if has_head(&(v785_3)) { singleton(&[]) } else { Space::new() };
    drop(v785_3);
    let v785_7: Space = if (&(v785_4)).is_empty() { Space::new() } else {
      let v786_5: Path = concat_path(&(*p0),&v784_5_cursor.path()[v784_5_origin..(v784_5_origin + 1)]);
      let mut v786_6 = Space::new();
      let mut v786_6_write = v786_6.write_zipper();
      for v786_6_byte in v784_5_cursor.child_mask().iter() {
        v784_5_cursor.descend_to_existing_byte(v786_6_byte);
        {
        let v787_2: Space = singleton(&v784_5_cursor.path()[(v784_5_origin + 1)..(v784_5_origin + 2)]);
        let v787_3: Space = intersect(&(*CONSTANT_2),&(v787_2));
        drop(v787_2);
        let v787_4: Space = if has_head(&(v787_3)) { singleton(&[]) } else { Space::new() };
        drop(v787_3);
        let v787_5: Space = compose(&(v787_4),&v784_5_cursor);
        drop(v787_4);
        let v787_6: Path = concat_path(&(v786_5),&v784_5_cursor.path()[(v784_5_origin + 1)..(v784_5_origin + 2)]);
        join_wrapped_into(&mut v786_6_write,&((v787_5).read_zipper()),&(v787_6));
        drop(v787_5);
        drop(v787_6);
        }
        v784_5_cursor.ascend(1);
      }
      drop(v786_6_write);
      drop(v786_5);
      compose(&(v785_4),&(v786_6))
    };
    drop(v785_4);
    join_wrapped_into(&mut v784_5_write,&((v785_7).read_zipper()),&[]);
    }
    v784_5_cursor.ascend(1);
  }
  drop(v784_5_cursor);
  drop(v784_5_write);
  let v784_6: Space = wrap(&(v784_5),&(*p1));
  drop(v784_5);
  (v784_6).clone()
}

fn routine_47(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v788_4 = Space::new();
  let mut v788_4_write = v788_4.write_zipper();
  let mut v788_4_cursor = (*s0).read_zipper();
  let v788_4_origin = v788_4_cursor.path().len();
  for v788_4_byte in v788_4_cursor.child_mask().iter() {
    v788_4_cursor.descend_to_existing_byte(v788_4_byte);
    {
    let v789_2: Space = singleton(&v788_4_cursor.path()[v788_4_origin..(v788_4_origin + 1)]);
    let v789_3: Space = intersect(&(*CONSTANT_2),&(v789_2));
    drop(v789_2);
    let v789_4: Space = if has_head(&(v789_3)) { singleton(&[]) } else { Space::new() };
    drop(v789_3);
    let v789_5: Space = compose(&(v789_4),&v788_4_cursor);
    drop(v789_4);
    let v789_6: Path = concat_path(&(*p0),&v788_4_cursor.path()[v788_4_origin..(v788_4_origin + 1)]);
    join_wrapped_into(&mut v788_4_write,&((v789_5).read_zipper()),&(v789_6));
    drop(v789_5);
    drop(v789_6);
    }
    v788_4_cursor.ascend(1);
  }
  drop(v788_4_cursor);
  drop(v788_4_write);
  let v788_5: Space = wrap(&(v788_4),&(*p1));
  drop(v788_4);
  (v788_5).clone()
}

fn routine_48(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v790_3: Space = Space::new();
  (v790_3).clone()
}

fn routine_49(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v791_4 = Space::new();
  let mut v791_4_write = v791_4.write_zipper();
  let mut v791_4_cursor = (*s0).read_zipper();
  let v791_4_origin = v791_4_cursor.path().len();
  for v791_4_byte in v791_4_cursor.child_mask().iter() {
    v791_4_cursor.descend_to_existing_byte(v791_4_byte);
    {
    let v792_2: Space = singleton(&v791_4_cursor.path()[v791_4_origin..(v791_4_origin + 1)]);
    let v792_3: Space = intersect(&(*CONSTANT_2),&(v792_2));
    drop(v792_2);
    let v792_4: Space = if has_head(&(v792_3)) { singleton(&[]) } else { Space::new() };
    drop(v792_3);
    let v792_5: Space = compose(&(v792_4),&v791_4_cursor);
    drop(v792_4);
    let v792_6: Path = concat_path(&(*p0),&v791_4_cursor.path()[v791_4_origin..(v791_4_origin + 1)]);
    join_wrapped_into(&mut v791_4_write,&((v792_5).read_zipper()),&(v792_6));
    drop(v792_5);
    drop(v792_6);
    }
    v791_4_cursor.ascend(1);
  }
  drop(v791_4_cursor);
  drop(v791_4_write);
  let v791_5: Space = wrap(&(v791_4),&(*p1));
  drop(v791_4);
  (v791_5).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
