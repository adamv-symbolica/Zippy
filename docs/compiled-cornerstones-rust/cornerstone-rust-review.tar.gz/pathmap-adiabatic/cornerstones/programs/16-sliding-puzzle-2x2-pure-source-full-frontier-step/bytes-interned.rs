#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 2 0 0 0 3"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,4]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,5]));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 3 0 0 0 2"));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,6]));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,2]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 3 0 0 0 1"));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 1 0 0 0 3"));
static CONSTANT_10: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,3]));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 1 0 0 0 2"));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 2 0 0 0 1"));
static CONSTANT_13: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 0"));
static CONSTANT_14: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 4"));
static CONSTANT_15: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 5"));
static CONSTANT_16: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 6"));
static CONSTANT_17: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 12 0 0 0 8 0 0 0 0 0 0 0 4 12 0 0 0 8 0 0 0 4 0 0 0 0 12 0 0 0 10 0 0 0 0 0 0 0 5 12 0 0 0 10 0 0 0 5 0 0 0 0"));
static CONSTANT_18: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 12 0 0 0 9 0 0 0 0 0 0 0 4 12 0 0 0 9 0 0 0 4 0 0 0 0 12 0 0 0 10 0 0 0 4 0 0 0 6 12 0 0 0 10 0 0 0 6 0 0 0 4"));
static CONSTANT_19: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 12 0 0 0 7 0 0 0 0 0 0 0 5 12 0 0 0 7 0 0 0 5 0 0 0 0 12 0 0 0 8 0 0 0 5 0 0 0 6 12 0 0 0 8 0 0 0 6 0 0 0 5"));
static CONSTANT_20: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 12 0 0 0 7 0 0 0 4 0 0 0 6 12 0 0 0 7 0 0 0 6 0 0 0 4 12 0 0 0 9 0 0 0 5 0 0 0 6 12 0 0 0 9 0 0 0 6 0 0 0 5"));
static CONSTANT_21: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 8 0 0 0 0 0 0 0 0 8 0 0 0 4 0 0 0 4 8 0 0 0 5 0 0 0 5 8 0 0 0 6 0 0 0 6"));
static CONSTANT_22: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 0 0 0 0 11"));
static CONSTANT_23: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 4 0 0 0 11"));
static CONSTANT_24: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 5 0 0 0 11"));
static CONSTANT_25: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 6 0 0 0 11"));
fn routine_0(c: &mut Context) -> Space {
  let v0_3: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
  let v0_6: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_3), &((*CONSTANT_2).read_zipper()));
  let v0_7: Space = unite(&(v0_3),&(v0_6));
  let v0_10: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_4), &((*CONSTANT_5).read_zipper()));
  let v0_11: Space = unite(&(v0_7),&(v0_10));
  let v0_14: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_6), &((*CONSTANT_5).read_zipper()));
  let v0_15: Space = unite(&(v0_11),&(v0_14));
  let v0_18: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_1), &((*CONSTANT_8).read_zipper()));
  let v0_19: Space = unite(&(v0_15),&(v0_18));
  let v0_21: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_3), &((*CONSTANT_8).read_zipper()));
  let v0_22: Space = unite(&(v0_19),&(v0_21));
  let v0_24: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_4), &((*CONSTANT_9).read_zipper()));
  let v0_25: Space = unite(&(v0_22),&(v0_24));
  let v0_27: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_6), &((*CONSTANT_9).read_zipper()));
  let v0_28: Space = unite(&(v0_25),&(v0_27));
  let v0_31: Space = routine_1(c, &(*CONSTANT_10), &(*CONSTANT_1), &((*CONSTANT_11).read_zipper()));
  let v0_32: Space = unite(&(v0_28),&(v0_31));
  let v0_34: Space = routine_1(c, &(*CONSTANT_10), &(*CONSTANT_3), &((*CONSTANT_11).read_zipper()));
  let v0_35: Space = unite(&(v0_32),&(v0_34));
  let v0_37: Space = routine_1(c, &(*CONSTANT_10), &(*CONSTANT_4), &((*CONSTANT_12).read_zipper()));
  let v0_38: Space = unite(&(v0_35),&(v0_37));
  let v0_40: Space = routine_1(c, &(*CONSTANT_10), &(*CONSTANT_6), &((*CONSTANT_12).read_zipper()));
  let v0_41: Space = unite(&(v0_38),&(v0_40));
  (v0_41).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1_3 = Space::new();
  let mut v1_3_write = v1_3.write_zipper();
  let mut v1_3_cursor = (*s0).read_zipper();
  let v1_3_origin = v1_3_cursor.path().len();
  for v1_3_byte in v1_3_cursor.child_mask().iter() {
    v1_3_cursor.descend_to_existing_byte(v1_3_byte);
    {
    for v2_2_byte in v1_3_cursor.child_mask().iter() {
      v1_3_cursor.descend_to_existing_byte(v2_2_byte);
      {
      for v3_3_byte in v1_3_cursor.child_mask().iter() {
        v1_3_cursor.descend_to_existing_byte(v3_3_byte);
        {
        for v4_3_byte in v1_3_cursor.child_mask().iter() {
          v1_3_cursor.descend_to_existing_byte(v4_3_byte);
          {
          for v5_3_byte in v1_3_cursor.child_mask().iter() {
            v1_3_cursor.descend_to_existing_byte(v5_3_byte);
            {
            for v6_2_byte in v1_3_cursor.child_mask().iter() {
              v1_3_cursor.descend_to_existing_byte(v6_2_byte);
              {
              for v7_3_byte in v1_3_cursor.child_mask().iter() {
                v1_3_cursor.descend_to_existing_byte(v7_3_byte);
                {
                for v8_3_byte in v1_3_cursor.child_mask().iter() {
                  v1_3_cursor.descend_to_existing_byte(v8_3_byte);
                  {
                  let v9_3: Space = routine_2(c, &v1_3_cursor.path()[(v1_3_origin + 4)..(v1_3_origin + 8)], &(*p1), &(*p0), &v1_3_cursor.path()[v1_3_origin..(v1_3_origin + 4)], &v1_3_cursor);
                  join_wrapped_into(&mut v1_3_write,&((v9_3).read_zipper()),&[]);
                  }
                  v1_3_cursor.ascend(1);
                }
                }
                v1_3_cursor.ascend(1);
              }
              }
              v1_3_cursor.ascend(1);
            }
            }
            v1_3_cursor.ascend(1);
          }
          }
          v1_3_cursor.ascend(1);
        }
        }
        v1_3_cursor.ascend(1);
      }
      }
      v1_3_cursor.ascend(1);
    }
    }
    v1_3_cursor.ascend(1);
  }
  drop(v1_3_cursor);
  drop(v1_3_write);
  (v1_3).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v10_6: Space = singleton(&(*p1));
  let v10_7: Space = intersect(&(*CONSTANT_13),&(v10_6));
  let mut v10_8 = Space::new();
  let mut v10_8_write = v10_8.write_zipper();
  let mut v10_8_cursor = (v10_7).read_zipper();
  let v10_8_origin = v10_8_cursor.path().len();
  for v10_8_byte in v10_8_cursor.child_mask().iter() {
    v10_8_cursor.descend_to_existing_byte(v10_8_byte);
    {
    for v11_2_byte in v10_8_cursor.child_mask().iter() {
      v10_8_cursor.descend_to_existing_byte(v11_2_byte);
      {
      for v12_3_byte in v10_8_cursor.child_mask().iter() {
        v10_8_cursor.descend_to_existing_byte(v12_3_byte);
        {
        for v13_3_byte in v10_8_cursor.child_mask().iter() {
          v10_8_cursor.descend_to_existing_byte(v13_3_byte);
          {
          let v14_3: Space = routine_3(c, &v10_8_cursor.path()[v10_8_origin..(v10_8_origin + 4)], &v10_8_cursor);
          join_wrapped_into(&mut v10_8_write,&((v14_3).read_zipper()),&[]);
          }
          v10_8_cursor.ascend(1);
        }
        }
        v10_8_cursor.ascend(1);
      }
      }
      v10_8_cursor.ascend(1);
    }
    }
    v10_8_cursor.ascend(1);
  }
  drop(v10_8_cursor);
  drop(v10_8_write);
  drop(v10_7);
  let v10_13: Space = if (&(v10_8)).is_empty() { Space::new() } else {
    let v15_9: Path = concat_path(&(*p2),&(*p3));
    let v15_10: Path = concat_path(&(v15_9),&(*p0));
    drop(v15_9);
    let v15_11: Space = singleton(&(v15_10));
    drop(v15_10);
    let mut v15_12 = Space::new();
    let mut v15_12_write = v15_12.write_zipper();
    let mut v15_12_cursor = (v15_11).read_zipper();
    let v15_12_origin = v15_12_cursor.path().len();
    for v15_12_byte in v15_12_cursor.child_mask().iter() {
      v15_12_cursor.descend_to_existing_byte(v15_12_byte);
      {
      for v16_2_byte in v15_12_cursor.child_mask().iter() {
        v15_12_cursor.descend_to_existing_byte(v16_2_byte);
        {
        for v17_3_byte in v15_12_cursor.child_mask().iter() {
          v15_12_cursor.descend_to_existing_byte(v17_3_byte);
          {
          for v18_3_byte in v15_12_cursor.child_mask().iter() {
            v15_12_cursor.descend_to_existing_byte(v18_3_byte);
            {
            let v19_3: Space = routine_4(c, &v15_12_cursor.path()[v15_12_origin..(v15_12_origin + 4)], &v15_12_cursor);
            join_wrapped_into(&mut v15_12_write,&((v19_3).read_zipper()),&[]);
            }
            v15_12_cursor.ascend(1);
          }
          }
          v15_12_cursor.ascend(1);
        }
        }
        v15_12_cursor.ascend(1);
      }
      }
      v15_12_cursor.ascend(1);
    }
    drop(v15_12_cursor);
    drop(v15_12_write);
    compose(&(v10_8),&(v15_12))
  };
  let v10_15: Space = intersect(&(*CONSTANT_14),&(v10_6));
  let mut v10_16 = Space::new();
  let mut v10_16_write = v10_16.write_zipper();
  let mut v10_16_cursor = (v10_15).read_zipper();
  let v10_16_origin = v10_16_cursor.path().len();
  for v10_16_byte in v10_16_cursor.child_mask().iter() {
    v10_16_cursor.descend_to_existing_byte(v10_16_byte);
    {
    for v20_2_byte in v10_16_cursor.child_mask().iter() {
      v10_16_cursor.descend_to_existing_byte(v20_2_byte);
      {
      for v21_3_byte in v10_16_cursor.child_mask().iter() {
        v10_16_cursor.descend_to_existing_byte(v21_3_byte);
        {
        for v22_3_byte in v10_16_cursor.child_mask().iter() {
          v10_16_cursor.descend_to_existing_byte(v22_3_byte);
          {
          let v23_3: Space = routine_5(c, &v10_16_cursor.path()[v10_16_origin..(v10_16_origin + 4)], &v10_16_cursor);
          join_wrapped_into(&mut v10_16_write,&((v23_3).read_zipper()),&[]);
          }
          v10_16_cursor.ascend(1);
        }
        }
        v10_16_cursor.ascend(1);
      }
      }
      v10_16_cursor.ascend(1);
    }
    }
    v10_16_cursor.ascend(1);
  }
  drop(v10_16_cursor);
  drop(v10_16_write);
  drop(v10_15);
  let v10_18: Space = if (&(v10_16)).is_empty() { Space::new() } else {
    let v24_9: Path = concat_path(&(*p2),&(*p3));
    let v24_10: Path = concat_path(&(v24_9),&(*p0));
    drop(v24_9);
    let v24_11: Space = singleton(&(v24_10));
    drop(v24_10);
    let mut v24_17 = Space::new();
    let mut v24_17_write = v24_17.write_zipper();
    let mut v24_17_cursor = (v24_11).read_zipper();
    let v24_17_origin = v24_17_cursor.path().len();
    for v24_17_byte in v24_17_cursor.child_mask().iter() {
      v24_17_cursor.descend_to_existing_byte(v24_17_byte);
      {
      for v25_2_byte in v24_17_cursor.child_mask().iter() {
        v24_17_cursor.descend_to_existing_byte(v25_2_byte);
        {
        for v26_3_byte in v24_17_cursor.child_mask().iter() {
          v24_17_cursor.descend_to_existing_byte(v26_3_byte);
          {
          for v27_3_byte in v24_17_cursor.child_mask().iter() {
            v24_17_cursor.descend_to_existing_byte(v27_3_byte);
            {
            let v28_3: Space = routine_6(c, &v24_17_cursor.path()[v24_17_origin..(v24_17_origin + 4)], &v24_17_cursor);
            join_wrapped_into(&mut v24_17_write,&((v28_3).read_zipper()),&[]);
            }
            v24_17_cursor.ascend(1);
          }
          }
          v24_17_cursor.ascend(1);
        }
        }
        v24_17_cursor.ascend(1);
      }
      }
      v24_17_cursor.ascend(1);
    }
    drop(v24_17_cursor);
    drop(v24_17_write);
    compose(&(v10_16),&(v24_17))
  };
  let v10_19: Space = unite(&(v10_13),&(v10_18));
  let v10_21: Space = intersect(&(*CONSTANT_15),&(v10_6));
  let mut v10_22 = Space::new();
  let mut v10_22_write = v10_22.write_zipper();
  let mut v10_22_cursor = (v10_21).read_zipper();
  let v10_22_origin = v10_22_cursor.path().len();
  for v10_22_byte in v10_22_cursor.child_mask().iter() {
    v10_22_cursor.descend_to_existing_byte(v10_22_byte);
    {
    for v29_2_byte in v10_22_cursor.child_mask().iter() {
      v10_22_cursor.descend_to_existing_byte(v29_2_byte);
      {
      for v30_3_byte in v10_22_cursor.child_mask().iter() {
        v10_22_cursor.descend_to_existing_byte(v30_3_byte);
        {
        for v31_3_byte in v10_22_cursor.child_mask().iter() {
          v10_22_cursor.descend_to_existing_byte(v31_3_byte);
          {
          let v32_3: Space = routine_7(c, &v10_22_cursor.path()[v10_22_origin..(v10_22_origin + 4)], &v10_22_cursor);
          join_wrapped_into(&mut v10_22_write,&((v32_3).read_zipper()),&[]);
          }
          v10_22_cursor.ascend(1);
        }
        }
        v10_22_cursor.ascend(1);
      }
      }
      v10_22_cursor.ascend(1);
    }
    }
    v10_22_cursor.ascend(1);
  }
  drop(v10_22_cursor);
  drop(v10_22_write);
  drop(v10_21);
  let v10_24: Space = if (&(v10_22)).is_empty() { Space::new() } else {
    let v33_9: Path = concat_path(&(*p2),&(*p3));
    let v33_10: Path = concat_path(&(v33_9),&(*p0));
    drop(v33_9);
    let v33_11: Space = singleton(&(v33_10));
    drop(v33_10);
    let mut v33_23 = Space::new();
    let mut v33_23_write = v33_23.write_zipper();
    let mut v33_23_cursor = (v33_11).read_zipper();
    let v33_23_origin = v33_23_cursor.path().len();
    for v33_23_byte in v33_23_cursor.child_mask().iter() {
      v33_23_cursor.descend_to_existing_byte(v33_23_byte);
      {
      for v34_2_byte in v33_23_cursor.child_mask().iter() {
        v33_23_cursor.descend_to_existing_byte(v34_2_byte);
        {
        for v35_3_byte in v33_23_cursor.child_mask().iter() {
          v33_23_cursor.descend_to_existing_byte(v35_3_byte);
          {
          for v36_3_byte in v33_23_cursor.child_mask().iter() {
            v33_23_cursor.descend_to_existing_byte(v36_3_byte);
            {
            let v37_3: Space = routine_8(c, &v33_23_cursor.path()[v33_23_origin..(v33_23_origin + 4)], &v33_23_cursor);
            join_wrapped_into(&mut v33_23_write,&((v37_3).read_zipper()),&[]);
            }
            v33_23_cursor.ascend(1);
          }
          }
          v33_23_cursor.ascend(1);
        }
        }
        v33_23_cursor.ascend(1);
      }
      }
      v33_23_cursor.ascend(1);
    }
    drop(v33_23_cursor);
    drop(v33_23_write);
    compose(&(v10_22),&(v33_23))
  };
  let v10_25: Space = unite(&(v10_19),&(v10_24));
  let v10_27: Space = intersect(&(*CONSTANT_16),&(v10_6));
  drop(v10_6);
  let mut v10_28 = Space::new();
  let mut v10_28_write = v10_28.write_zipper();
  let mut v10_28_cursor = (v10_27).read_zipper();
  let v10_28_origin = v10_28_cursor.path().len();
  for v10_28_byte in v10_28_cursor.child_mask().iter() {
    v10_28_cursor.descend_to_existing_byte(v10_28_byte);
    {
    for v38_2_byte in v10_28_cursor.child_mask().iter() {
      v10_28_cursor.descend_to_existing_byte(v38_2_byte);
      {
      for v39_3_byte in v10_28_cursor.child_mask().iter() {
        v10_28_cursor.descend_to_existing_byte(v39_3_byte);
        {
        for v40_3_byte in v10_28_cursor.child_mask().iter() {
          v10_28_cursor.descend_to_existing_byte(v40_3_byte);
          {
          let v41_3: Space = routine_9(c, &v10_28_cursor.path()[v10_28_origin..(v10_28_origin + 4)], &v10_28_cursor);
          join_wrapped_into(&mut v10_28_write,&((v41_3).read_zipper()),&[]);
          }
          v10_28_cursor.ascend(1);
        }
        }
        v10_28_cursor.ascend(1);
      }
      }
      v10_28_cursor.ascend(1);
    }
    }
    v10_28_cursor.ascend(1);
  }
  drop(v10_28_cursor);
  drop(v10_28_write);
  drop(v10_27);
  let v10_30: Space = if (&(v10_28)).is_empty() { Space::new() } else {
    let v42_9: Path = concat_path(&(*p2),&(*p3));
    let v42_10: Path = concat_path(&(v42_9),&(*p0));
    drop(v42_9);
    let v42_11: Space = singleton(&(v42_10));
    drop(v42_10);
    let mut v42_29 = Space::new();
    let mut v42_29_write = v42_29.write_zipper();
    let mut v42_29_cursor = (v42_11).read_zipper();
    let v42_29_origin = v42_29_cursor.path().len();
    for v42_29_byte in v42_29_cursor.child_mask().iter() {
      v42_29_cursor.descend_to_existing_byte(v42_29_byte);
      {
      for v43_2_byte in v42_29_cursor.child_mask().iter() {
        v42_29_cursor.descend_to_existing_byte(v43_2_byte);
        {
        for v44_3_byte in v42_29_cursor.child_mask().iter() {
          v42_29_cursor.descend_to_existing_byte(v44_3_byte);
          {
          for v45_3_byte in v42_29_cursor.child_mask().iter() {
            v42_29_cursor.descend_to_existing_byte(v45_3_byte);
            {
            let v46_3: Space = routine_10(c, &v42_29_cursor.path()[v42_29_origin..(v42_29_origin + 4)], &v42_29_cursor);
            join_wrapped_into(&mut v42_29_write,&((v46_3).read_zipper()),&[]);
            }
            v42_29_cursor.ascend(1);
          }
          }
          v42_29_cursor.ascend(1);
        }
        }
        v42_29_cursor.ascend(1);
      }
      }
      v42_29_cursor.ascend(1);
    }
    drop(v42_29_cursor);
    drop(v42_29_write);
    drop(v42_11);
    compose(&(v10_28),&(v42_29))
  };
  let v10_31: Space = unite(&(v10_25),&(v10_30));
  let mut v10_40 = Space::new();
  let mut v10_40_write = v10_40.write_zipper();
  let mut v10_40_cursor = (v10_31).read_zipper();
  let v10_40_origin = v10_40_cursor.path().len();
  for v10_40_byte in v10_40_cursor.child_mask().iter() {
    v10_40_cursor.descend_to_existing_byte(v10_40_byte);
    {
    for v47_2_byte in v10_40_cursor.child_mask().iter() {
      v10_40_cursor.descend_to_existing_byte(v47_2_byte);
      {
      for v48_3_byte in v10_40_cursor.child_mask().iter() {
        v10_40_cursor.descend_to_existing_byte(v48_3_byte);
        {
        for v49_3_byte in v10_40_cursor.child_mask().iter() {
          v10_40_cursor.descend_to_existing_byte(v49_3_byte);
          {
          let v50_2: Space = routine_11(c, &(*CONSTANT_1), &((*CONSTANT_17).read_zipper()));
          let v50_3: Space = routine_11(c, &(*CONSTANT_3), &((*CONSTANT_18).read_zipper()));
          let v50_4: Space = unite(&(v50_2),&(v50_3));
          let v50_5: Space = routine_11(c, &(*CONSTANT_4), &((*CONSTANT_19).read_zipper()));
          let v50_6: Space = unite(&(v50_4),&(v50_5));
          let v50_7: Space = routine_11(c, &(*CONSTANT_6), &((*CONSTANT_20).read_zipper()));
          let v50_8: Space = unite(&(v50_6),&(v50_7));
          let mut v50_11_cursor = descend_cursor((v50_8).read_zipper(),&(*p1));
          let v50_11_origin = v50_11_cursor.path().len();
          for v50_11_byte in v50_11_cursor.child_mask().iter() {
            v50_11_cursor.descend_to_existing_byte(v50_11_byte);
            {
            for v51_2_byte in v50_11_cursor.child_mask().iter() {
              v50_11_cursor.descend_to_existing_byte(v51_2_byte);
              {
              for v52_3_byte in v50_11_cursor.child_mask().iter() {
                v50_11_cursor.descend_to_existing_byte(v52_3_byte);
                {
                for v53_3_byte in v50_11_cursor.child_mask().iter() {
                  v50_11_cursor.descend_to_existing_byte(v53_3_byte);
                  {
                  let v54_3: Space = routine_12(c, &v50_11_cursor.path()[v50_11_origin..(v50_11_origin + 4)], &v10_40_cursor.path()[v10_40_origin..(v10_40_origin + 4)], &v50_11_cursor, &v10_40_cursor);
                  join_wrapped_into(&mut v10_40_write,&((v54_3).read_zipper()),&[]);
                  }
                  v50_11_cursor.ascend(1);
                }
                }
                v50_11_cursor.ascend(1);
              }
              }
              v50_11_cursor.ascend(1);
            }
            }
            v50_11_cursor.ascend(1);
          }
          drop(v50_11_cursor);
          }
          v10_40_cursor.ascend(1);
        }
        }
        v10_40_cursor.ascend(1);
      }
      }
      v10_40_cursor.ascend(1);
    }
    }
    v10_40_cursor.ascend(1);
  }
  drop(v10_40_cursor);
  drop(v10_40_write);
  let mut v10_45 = Space::new();
  let mut v10_45_write = v10_45.write_zipper();
  let mut v10_45_cursor = (v10_40).read_zipper();
  let v10_45_origin = v10_45_cursor.path().len();
  for v10_45_byte in v10_45_cursor.child_mask().iter() {
    v10_45_cursor.descend_to_existing_byte(v10_45_byte);
    {
    for v55_2_byte in v10_45_cursor.child_mask().iter() {
      v10_45_cursor.descend_to_existing_byte(v55_2_byte);
      {
      for v56_2_byte in v10_45_cursor.child_mask().iter() {
        v10_45_cursor.descend_to_existing_byte(v56_2_byte);
        {
        for v57_2_byte in v10_45_cursor.child_mask().iter() {
          v10_45_cursor.descend_to_existing_byte(v57_2_byte);
          {
          let v58_2: Space = routine_13(c, &(*CONSTANT_1), &((*CONSTANT_17).read_zipper()));
          let v58_3: Space = routine_13(c, &(*CONSTANT_3), &((*CONSTANT_18).read_zipper()));
          let v58_4: Space = unite(&(v58_2),&(v58_3));
          let v58_5: Space = routine_13(c, &(*CONSTANT_4), &((*CONSTANT_19).read_zipper()));
          let v58_6: Space = unite(&(v58_4),&(v58_5));
          let v58_7: Space = routine_13(c, &(*CONSTANT_6), &((*CONSTANT_20).read_zipper()));
          let v58_8: Space = unite(&(v58_6),&(v58_7));
          let mut v58_15_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((v58_8).read_zipper(),&(*p1)),&v10_45_cursor.path()[v10_45_origin..(v10_45_origin + 1)]),&v10_45_cursor.path()[(v10_45_origin + 1)..(v10_45_origin + 2)]),&v10_45_cursor.path()[(v10_45_origin + 2)..(v10_45_origin + 3)]),&v10_45_cursor.path()[(v10_45_origin + 3)..(v10_45_origin + 4)]),&(*p1));
          let v58_15_origin = v58_15_cursor.path().len();
          for v58_15_byte in v58_15_cursor.child_mask().iter() {
            v58_15_cursor.descend_to_existing_byte(v58_15_byte);
            {
            for v59_2_byte in v58_15_cursor.child_mask().iter() {
              v58_15_cursor.descend_to_existing_byte(v59_2_byte);
              {
              for v60_3_byte in v58_15_cursor.child_mask().iter() {
                v58_15_cursor.descend_to_existing_byte(v60_3_byte);
                {
                for v61_3_byte in v58_15_cursor.child_mask().iter() {
                  v58_15_cursor.descend_to_existing_byte(v61_3_byte);
                  {
                  let v62_3: Space = routine_14(c, &v58_15_cursor.path()[v58_15_origin..(v58_15_origin + 4)], &v58_15_cursor, &v10_45_cursor);
                  join_wrapped_into(&mut v10_45_write,&((v62_3).read_zipper()),&[]);
                  }
                  v58_15_cursor.ascend(1);
                }
                }
                v58_15_cursor.ascend(1);
              }
              }
              v58_15_cursor.ascend(1);
            }
            }
            v58_15_cursor.ascend(1);
          }
          drop(v58_15_cursor);
          }
          v10_45_cursor.ascend(1);
        }
        }
        v10_45_cursor.ascend(1);
      }
      }
      v10_45_cursor.ascend(1);
    }
    }
    v10_45_cursor.ascend(1);
  }
  drop(v10_45_cursor);
  drop(v10_45_write);
  (v10_45).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_4(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v64_2 = Space::new();
  let mut v64_2_write = v64_2.write_zipper();
  let mut v64_2_cursor = (*s0).read_zipper();
  let v64_2_origin = v64_2_cursor.path().len();
  for v64_2_byte in v64_2_cursor.child_mask().iter() {
    v64_2_cursor.descend_to_existing_byte(v64_2_byte);
    {
    for v65_2_byte in v64_2_cursor.child_mask().iter() {
      v64_2_cursor.descend_to_existing_byte(v65_2_byte);
      {
      for v66_3_byte in v64_2_cursor.child_mask().iter() {
        v64_2_cursor.descend_to_existing_byte(v66_3_byte);
        {
        for v67_3_byte in v64_2_cursor.child_mask().iter() {
          v64_2_cursor.descend_to_existing_byte(v67_3_byte);
          {
          for v68_3_byte in v64_2_cursor.child_mask().iter() {
            v64_2_cursor.descend_to_existing_byte(v68_3_byte);
            {
            for v69_2_byte in v64_2_cursor.child_mask().iter() {
              v64_2_cursor.descend_to_existing_byte(v69_2_byte);
              {
              for v70_3_byte in v64_2_cursor.child_mask().iter() {
                v64_2_cursor.descend_to_existing_byte(v70_3_byte);
                {
                for v71_3_byte in v64_2_cursor.child_mask().iter() {
                  v64_2_cursor.descend_to_existing_byte(v71_3_byte);
                  {
                  let v72_3: Space = routine_15(c, &v64_2_cursor.path()[(v64_2_origin + 4)..(v64_2_origin + 8)], &v64_2_cursor.path()[v64_2_origin..(v64_2_origin + 4)], &(*p0), &v64_2_cursor);
                  join_wrapped_into(&mut v64_2_write,&((v72_3).read_zipper()),&[]);
                  }
                  v64_2_cursor.ascend(1);
                }
                }
                v64_2_cursor.ascend(1);
              }
              }
              v64_2_cursor.ascend(1);
            }
            }
            v64_2_cursor.ascend(1);
          }
          }
          v64_2_cursor.ascend(1);
        }
        }
        v64_2_cursor.ascend(1);
      }
      }
      v64_2_cursor.ascend(1);
    }
    }
    v64_2_cursor.ascend(1);
  }
  drop(v64_2_cursor);
  drop(v64_2_write);
  (v64_2).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v74_2 = Space::new();
  let mut v74_2_write = v74_2.write_zipper();
  let mut v74_2_cursor = (*s0).read_zipper();
  let v74_2_origin = v74_2_cursor.path().len();
  for v74_2_byte in v74_2_cursor.child_mask().iter() {
    v74_2_cursor.descend_to_existing_byte(v74_2_byte);
    {
    for v75_2_byte in v74_2_cursor.child_mask().iter() {
      v74_2_cursor.descend_to_existing_byte(v75_2_byte);
      {
      for v76_3_byte in v74_2_cursor.child_mask().iter() {
        v74_2_cursor.descend_to_existing_byte(v76_3_byte);
        {
        for v77_3_byte in v74_2_cursor.child_mask().iter() {
          v74_2_cursor.descend_to_existing_byte(v77_3_byte);
          {
          for v78_3_byte in v74_2_cursor.child_mask().iter() {
            v74_2_cursor.descend_to_existing_byte(v78_3_byte);
            {
            for v79_2_byte in v74_2_cursor.child_mask().iter() {
              v74_2_cursor.descend_to_existing_byte(v79_2_byte);
              {
              for v80_3_byte in v74_2_cursor.child_mask().iter() {
                v74_2_cursor.descend_to_existing_byte(v80_3_byte);
                {
                for v81_3_byte in v74_2_cursor.child_mask().iter() {
                  v74_2_cursor.descend_to_existing_byte(v81_3_byte);
                  {
                  let v82_3: Space = routine_16(c, &v74_2_cursor.path()[(v74_2_origin + 4)..(v74_2_origin + 8)], &(*p0), &v74_2_cursor.path()[v74_2_origin..(v74_2_origin + 4)], &v74_2_cursor);
                  join_wrapped_into(&mut v74_2_write,&((v82_3).read_zipper()),&[]);
                  }
                  v74_2_cursor.ascend(1);
                }
                }
                v74_2_cursor.ascend(1);
              }
              }
              v74_2_cursor.ascend(1);
            }
            }
            v74_2_cursor.ascend(1);
          }
          }
          v74_2_cursor.ascend(1);
        }
        }
        v74_2_cursor.ascend(1);
      }
      }
      v74_2_cursor.ascend(1);
    }
    }
    v74_2_cursor.ascend(1);
  }
  drop(v74_2_cursor);
  drop(v74_2_write);
  (v74_2).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_8(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v84_2 = Space::new();
  let mut v84_2_write = v84_2.write_zipper();
  let mut v84_2_cursor = (*s0).read_zipper();
  let v84_2_origin = v84_2_cursor.path().len();
  for v84_2_byte in v84_2_cursor.child_mask().iter() {
    v84_2_cursor.descend_to_existing_byte(v84_2_byte);
    {
    for v85_2_byte in v84_2_cursor.child_mask().iter() {
      v84_2_cursor.descend_to_existing_byte(v85_2_byte);
      {
      for v86_3_byte in v84_2_cursor.child_mask().iter() {
        v84_2_cursor.descend_to_existing_byte(v86_3_byte);
        {
        for v87_3_byte in v84_2_cursor.child_mask().iter() {
          v84_2_cursor.descend_to_existing_byte(v87_3_byte);
          {
          for v88_3_byte in v84_2_cursor.child_mask().iter() {
            v84_2_cursor.descend_to_existing_byte(v88_3_byte);
            {
            for v89_2_byte in v84_2_cursor.child_mask().iter() {
              v84_2_cursor.descend_to_existing_byte(v89_2_byte);
              {
              for v90_3_byte in v84_2_cursor.child_mask().iter() {
                v84_2_cursor.descend_to_existing_byte(v90_3_byte);
                {
                for v91_3_byte in v84_2_cursor.child_mask().iter() {
                  v84_2_cursor.descend_to_existing_byte(v91_3_byte);
                  {
                  let v92_3: Space = routine_17(c, &v84_2_cursor.path()[(v84_2_origin + 4)..(v84_2_origin + 8)], &(*p0), &v84_2_cursor.path()[v84_2_origin..(v84_2_origin + 4)], &v84_2_cursor);
                  join_wrapped_into(&mut v84_2_write,&((v92_3).read_zipper()),&[]);
                  }
                  v84_2_cursor.ascend(1);
                }
                }
                v84_2_cursor.ascend(1);
              }
              }
              v84_2_cursor.ascend(1);
            }
            }
            v84_2_cursor.ascend(1);
          }
          }
          v84_2_cursor.ascend(1);
        }
        }
        v84_2_cursor.ascend(1);
      }
      }
      v84_2_cursor.ascend(1);
    }
    }
    v84_2_cursor.ascend(1);
  }
  drop(v84_2_cursor);
  drop(v84_2_write);
  (v84_2).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v94_2 = Space::new();
  let mut v94_2_write = v94_2.write_zipper();
  let mut v94_2_cursor = (*s0).read_zipper();
  let v94_2_origin = v94_2_cursor.path().len();
  for v94_2_byte in v94_2_cursor.child_mask().iter() {
    v94_2_cursor.descend_to_existing_byte(v94_2_byte);
    {
    for v95_2_byte in v94_2_cursor.child_mask().iter() {
      v94_2_cursor.descend_to_existing_byte(v95_2_byte);
      {
      for v96_3_byte in v94_2_cursor.child_mask().iter() {
        v94_2_cursor.descend_to_existing_byte(v96_3_byte);
        {
        for v97_3_byte in v94_2_cursor.child_mask().iter() {
          v94_2_cursor.descend_to_existing_byte(v97_3_byte);
          {
          for v98_3_byte in v94_2_cursor.child_mask().iter() {
            v94_2_cursor.descend_to_existing_byte(v98_3_byte);
            {
            for v99_2_byte in v94_2_cursor.child_mask().iter() {
              v94_2_cursor.descend_to_existing_byte(v99_2_byte);
              {
              for v100_3_byte in v94_2_cursor.child_mask().iter() {
                v94_2_cursor.descend_to_existing_byte(v100_3_byte);
                {
                for v101_3_byte in v94_2_cursor.child_mask().iter() {
                  v94_2_cursor.descend_to_existing_byte(v101_3_byte);
                  {
                  let v102_3: Space = routine_18(c, &v94_2_cursor.path()[(v94_2_origin + 4)..(v94_2_origin + 8)], &(*p0), &v94_2_cursor.path()[v94_2_origin..(v94_2_origin + 4)], &v94_2_cursor);
                  join_wrapped_into(&mut v94_2_write,&((v102_3).read_zipper()),&[]);
                  }
                  v94_2_cursor.ascend(1);
                }
                }
                v94_2_cursor.ascend(1);
              }
              }
              v94_2_cursor.ascend(1);
            }
            }
            v94_2_cursor.ascend(1);
          }
          }
          v94_2_cursor.ascend(1);
        }
        }
        v94_2_cursor.ascend(1);
      }
      }
      v94_2_cursor.ascend(1);
    }
    }
    v94_2_cursor.ascend(1);
  }
  drop(v94_2_cursor);
  drop(v94_2_write);
  (v94_2).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v103_3 = Space::new();
  let mut v103_3_write = v103_3.write_zipper();
  let mut v103_3_cursor = (*s0).read_zipper();
  let v103_3_origin = v103_3_cursor.path().len();
  for v103_3_byte in v103_3_cursor.child_mask().iter() {
    v103_3_cursor.descend_to_existing_byte(v103_3_byte);
    {
    for v104_2_byte in v103_3_cursor.child_mask().iter() {
      v103_3_cursor.descend_to_existing_byte(v104_2_byte);
      {
      for v105_3_byte in v103_3_cursor.child_mask().iter() {
        v103_3_cursor.descend_to_existing_byte(v105_3_byte);
        {
        for v106_3_byte in v103_3_cursor.child_mask().iter() {
          v103_3_cursor.descend_to_existing_byte(v106_3_byte);
          {
          let mut v107_2 = Space::new();
          let mut v107_2_write = v107_2.write_zipper();
          for v107_2_byte in v103_3_cursor.child_mask().iter() {
            v103_3_cursor.descend_to_existing_byte(v107_2_byte);
            {
            for v108_2_byte in v103_3_cursor.child_mask().iter() {
              v103_3_cursor.descend_to_existing_byte(v108_2_byte);
              {
              for v109_3_byte in v103_3_cursor.child_mask().iter() {
                v103_3_cursor.descend_to_existing_byte(v109_3_byte);
                {
                for v110_3_byte in v103_3_cursor.child_mask().iter() {
                  v103_3_cursor.descend_to_existing_byte(v110_3_byte);
                  {
                  let v111_3: Space = routine_19(c, &v103_3_cursor.path()[(v103_3_origin + 4)..(v103_3_origin + 8)], &v103_3_cursor);
                  join_wrapped_into(&mut v107_2_write,&((v111_3).read_zipper()),&[]);
                  }
                  v103_3_cursor.ascend(1);
                }
                }
                v103_3_cursor.ascend(1);
              }
              }
              v103_3_cursor.ascend(1);
            }
            }
            v103_3_cursor.ascend(1);
          }
          drop(v107_2_write);
          let v107_3: Space = raffine(&(*CONSTANT_21),&(v107_2));
          let v107_4: Space = unite(&(v107_3),&v103_3_cursor);
          let v107_6: Path = concat_path(&(*p0),&v103_3_cursor.path()[v103_3_origin..(v103_3_origin + 4)]);
          join_wrapped_into(&mut v103_3_write,&((v107_4).read_zipper()),&(v107_6));
          drop(v107_6);
          }
          v103_3_cursor.ascend(1);
        }
        }
        v103_3_cursor.ascend(1);
      }
      }
      v103_3_cursor.ascend(1);
    }
    }
    v103_3_cursor.ascend(1);
  }
  drop(v103_3_cursor);
  drop(v103_3_write);
  (v103_3).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v112_5: Space = wrap(&(descend_cursor((*s0).read_zipper(),&(*p1))),&(*p0));
  let v112_6: Space = if (&(v112_5)).is_empty() { Space::new() } else {
    compose(&(v112_5),&(*s1))
  };
  drop(v112_5);
  (v112_6).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v114_3 = Space::new();
  let mut v114_3_write = v114_3.write_zipper();
  let mut v114_3_cursor = (*s0).read_zipper();
  let v114_3_origin = v114_3_cursor.path().len();
  for v114_3_byte in v114_3_cursor.child_mask().iter() {
    v114_3_cursor.descend_to_existing_byte(v114_3_byte);
    {
    for v115_2_byte in v114_3_cursor.child_mask().iter() {
      v114_3_cursor.descend_to_existing_byte(v115_2_byte);
      {
      for v116_3_byte in v114_3_cursor.child_mask().iter() {
        v114_3_cursor.descend_to_existing_byte(v116_3_byte);
        {
        for v117_3_byte in v114_3_cursor.child_mask().iter() {
          v114_3_cursor.descend_to_existing_byte(v117_3_byte);
          {
          let mut v118_2 = Space::new();
          let mut v118_2_write = v118_2.write_zipper();
          for v118_2_byte in v114_3_cursor.child_mask().iter() {
            v114_3_cursor.descend_to_existing_byte(v118_2_byte);
            {
            for v119_2_byte in v114_3_cursor.child_mask().iter() {
              v114_3_cursor.descend_to_existing_byte(v119_2_byte);
              {
              for v120_3_byte in v114_3_cursor.child_mask().iter() {
                v114_3_cursor.descend_to_existing_byte(v120_3_byte);
                {
                for v121_3_byte in v114_3_cursor.child_mask().iter() {
                  v114_3_cursor.descend_to_existing_byte(v121_3_byte);
                  {
                  let v122_3: Space = routine_20(c, &v114_3_cursor.path()[(v114_3_origin + 4)..(v114_3_origin + 8)], &v114_3_cursor);
                  join_wrapped_into(&mut v118_2_write,&((v122_3).read_zipper()),&[]);
                  }
                  v114_3_cursor.ascend(1);
                }
                }
                v114_3_cursor.ascend(1);
              }
              }
              v114_3_cursor.ascend(1);
            }
            }
            v114_3_cursor.ascend(1);
          }
          drop(v118_2_write);
          let v118_3: Space = raffine(&(*CONSTANT_21),&(v118_2));
          let v118_4: Space = unite(&(v118_3),&v114_3_cursor);
          let v118_6: Path = concat_path(&(*p0),&v114_3_cursor.path()[v114_3_origin..(v114_3_origin + 4)]);
          join_wrapped_into(&mut v114_3_write,&((v118_4).read_zipper()),&(v118_6));
          drop(v118_6);
          }
          v114_3_cursor.ascend(1);
        }
        }
        v114_3_cursor.ascend(1);
      }
      }
      v114_3_cursor.ascend(1);
    }
    }
    v114_3_cursor.ascend(1);
  }
  drop(v114_3_cursor);
  drop(v114_3_write);
  (v114_3).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v123_4: Space = singleton(&(*p0));
  let v123_5: Space = intersect(&(*CONSTANT_13),&(v123_4));
  let v123_14: Space = if (&(v123_5)).is_empty() { Space::new() } else {
    let v124_10: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_6))))
    };
    let v124_13: Space = if (&(v124_10)).is_empty() { Space::new() } else {
      compose(&(v124_10),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))))
    };
    compose(&(v123_5),&(v124_13))
  };
  drop(v123_5);
  let v123_16: Space = intersect(&(*CONSTANT_14),&(v123_4));
  let v123_20: Space = if (&(v123_16)).is_empty() { Space::new() } else {
    let v127_10: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_6))))
    };
    let v127_19: Space = if (&(v127_10)).is_empty() { Space::new() } else {
      compose(&(v127_10),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_1))))
    };
    drop(v127_10);
    compose(&(v123_16),&(v127_19))
  };
  drop(v123_16);
  let v123_21: Space = unite(&(v123_14),&(v123_20));
  drop(v123_14);
  drop(v123_20);
  let v123_23: Space = intersect(&(*CONSTANT_15),&(v123_4));
  let v123_26: Space = if (&(v123_23)).is_empty() { Space::new() } else {
    let v130_24: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_6)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_6))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_1))))
    };
    let v130_25: Space = if (&(v130_24)).is_empty() { Space::new() } else {
      compose(&(v130_24),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))))
    };
    drop(v130_24);
    compose(&(v123_23),&(v130_25))
  };
  drop(v123_23);
  let v123_27: Space = unite(&(v123_21),&(v123_26));
  drop(v123_21);
  drop(v123_26);
  let v123_29: Space = intersect(&(*CONSTANT_16),&(v123_4));
  drop(v123_4);
  let v123_32: Space = if (&(v123_29)).is_empty() { Space::new() } else {
    let v133_30: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_1))))
    };
    let v133_31: Space = if (&(v133_30)).is_empty() { Space::new() } else {
      compose(&(v133_30),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))))
    };
    drop(v133_30);
    compose(&(v123_29),&(v133_31))
  };
  drop(v123_29);
  let v123_33: Space = unite(&(v123_27),&(v123_32));
  drop(v123_27);
  drop(v123_32);
  (v123_33).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v136_6: Path = concat_path(&(*CONSTANT_3),&(*p0));
  let v136_7: Space = singleton(&(v136_6));
  drop(v136_6);
  let v136_8: Space = unite(&(*CONSTANT_22),&(v136_7));
  drop(v136_7);
  let v136_10: Path = concat_path(&(*CONSTANT_4),&(*p2));
  let v136_11: Space = singleton(&(v136_10));
  drop(v136_10);
  let v136_12: Space = unite(&(v136_8),&(v136_11));
  drop(v136_8);
  drop(v136_11);
  let v136_14: Path = concat_path(&(*CONSTANT_6),&(*p1));
  let v136_15: Space = singleton(&(v136_14));
  drop(v136_14);
  let v136_16: Space = unite(&(v136_12),&(v136_15));
  drop(v136_12);
  drop(v136_15);
  (v136_16).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v137_6: Path = concat_path(&(*CONSTANT_1),&(*p0));
  let v137_7: Space = singleton(&(v137_6));
  drop(v137_6);
  let v137_8: Space = unite(&(*CONSTANT_23),&(v137_7));
  drop(v137_7);
  let v137_10: Path = concat_path(&(*CONSTANT_4),&(*p1));
  let v137_11: Space = singleton(&(v137_10));
  drop(v137_10);
  let v137_12: Space = unite(&(v137_8),&(v137_11));
  drop(v137_8);
  drop(v137_11);
  let v137_14: Path = concat_path(&(*CONSTANT_6),&(*p2));
  let v137_15: Space = singleton(&(v137_14));
  drop(v137_14);
  let v137_16: Space = unite(&(v137_12),&(v137_15));
  drop(v137_12);
  drop(v137_15);
  (v137_16).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v138_6: Path = concat_path(&(*CONSTANT_1),&(*p2));
  let v138_7: Space = singleton(&(v138_6));
  drop(v138_6);
  let v138_8: Space = unite(&(*CONSTANT_24),&(v138_7));
  drop(v138_7);
  let v138_10: Path = concat_path(&(*CONSTANT_3),&(*p0));
  let v138_11: Space = singleton(&(v138_10));
  drop(v138_10);
  let v138_12: Space = unite(&(v138_8),&(v138_11));
  drop(v138_8);
  drop(v138_11);
  let v138_14: Path = concat_path(&(*CONSTANT_6),&(*p1));
  let v138_15: Space = singleton(&(v138_14));
  drop(v138_14);
  let v138_16: Space = unite(&(v138_12),&(v138_15));
  drop(v138_12);
  drop(v138_15);
  (v138_16).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v139_6: Path = concat_path(&(*CONSTANT_1),&(*p2));
  let v139_7: Space = singleton(&(v139_6));
  drop(v139_6);
  let v139_8: Space = unite(&(*CONSTANT_25),&(v139_7));
  drop(v139_7);
  let v139_10: Path = concat_path(&(*CONSTANT_3),&(*p0));
  let v139_11: Space = singleton(&(v139_10));
  drop(v139_10);
  let v139_12: Space = unite(&(v139_8),&(v139_11));
  drop(v139_8);
  drop(v139_11);
  let v139_14: Path = concat_path(&(*CONSTANT_4),&(*p1));
  let v139_15: Space = singleton(&(v139_14));
  drop(v139_14);
  let v139_16: Space = unite(&(v139_12),&(v139_15));
  drop(v139_12);
  drop(v139_15);
  (v139_16).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v140_2: Space = singleton(&(*p0));
  (v140_2).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v141_2: Space = singleton(&(*p0));
  (v141_2).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
