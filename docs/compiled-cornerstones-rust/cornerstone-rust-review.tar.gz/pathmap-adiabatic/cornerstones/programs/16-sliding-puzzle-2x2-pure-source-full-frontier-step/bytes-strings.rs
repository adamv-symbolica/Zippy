#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[66,76]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 7 0 49 0 51 0 50 0 7 0 50 0 49 0 51 0 7 0 51 0 50 0 49 0"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[66,82]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[84,76]));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 7 0 49 0 50 0 51 0 7 0 50 0 51 0 49 0 7 0 51 0 49 0 50 0"));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[84,82]));
static CONSTANT_7: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 3 66 76 0"));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 3 66 82 0"));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 3 84 76 0"));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 3 84 82 0"));
static CONSTANT_12: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[66]));
static CONSTANT_13: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 10 76 0 82 0 66 76 0 66 82 0 10 76 0 82 0 66 82 0 66 76 0 10 76 0 85 0 66 76 0 84 76 0 10 76 0 85 0 84 76 0 66 76 0 10 82 0 76 0 66 76 0 66 82 0 10 82 0 76 0 66 82 0 66 76 0 10 82 0 85 0 66 82 0 84 82 0 10 82 0 85 0 84 82 0 66 82 0"));
static CONSTANT_14: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[84]));
static CONSTANT_15: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 10 76 0 68 0 66 76 0 84 76 0 10 76 0 68 0 84 76 0 66 76 0 10 76 0 82 0 84 76 0 84 82 0 10 76 0 82 0 84 82 0 84 76 0 10 82 0 68 0 66 82 0 84 82 0 10 82 0 68 0 84 82 0 66 82 0 10 82 0 76 0 84 76 0 84 82 0 10 82 0 76 0 84 82 0 84 76 0"));
static CONSTANT_16: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[84,76,0]));
static CONSTANT_17: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[84,82,0]));
static CONSTANT_18: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[66,82,0]));
static CONSTANT_19: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[66,76,0]));
static CONSTANT_20: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 9 0 82 0 66 76 0 66 82 0 9 0 82 0 66 82 0 66 76 0 9 0 85 0 66 76 0 84 76 0 9 0 85 0 84 76 0 66 76 0"));
static CONSTANT_21: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 9 0 76 0 66 76 0 66 82 0 9 0 76 0 66 82 0 66 76 0 9 0 85 0 66 82 0 84 82 0 9 0 85 0 84 82 0 66 82 0"));
static CONSTANT_22: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 9 0 68 0 66 76 0 84 76 0 9 0 68 0 84 76 0 66 76 0 9 0 82 0 84 76 0 84 82 0 9 0 82 0 84 82 0 84 76 0"));
static CONSTANT_23: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 9 0 68 0 66 82 0 84 82 0 9 0 68 0 84 82 0 66 82 0 9 0 76 0 84 76 0 84 82 0 9 0 76 0 84 82 0 84 76 0"));
static CONSTANT_24: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 66 76 0 95 0"));
static CONSTANT_25: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 66 82 0 95 0"));
static CONSTANT_26: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 84 76 0 95 0"));
static CONSTANT_27: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 84 82 0 95 0"));
static CONSTANT_28: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 6 66 76 0 66 76 0 6 66 82 0 66 82 0 6 84 76 0 84 76 0 6 84 82 0 84 82 0"));
#[inline(never)]
fn native_block_0(c: &mut Context,capture_0: &[u8],capture_1: &[u8],capture_2: &[u8],capture_3: &[u8]) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v65_6: Space = singleton(&(*capture_1));
  let v65_7: Space = intersect(&(*CONSTANT_8),&(v65_6));
  let mut v65_11 = Space::new();
  let mut v65_11_write = v65_11.write_zipper();
  let mut v65_11_cursor = (v65_7).read_zipper();
  let v65_11_origin = v65_11_cursor.path().len();
  for v65_11_byte in v65_11_cursor.child_mask().iter() {
    v65_11_cursor.descend_to_existing_byte(v65_11_byte);
    {
    let v66_2: Space = singleton(&v65_11_cursor.path()[v65_11_origin..(v65_11_origin + 1)]);
    let v66_3: Space = intersect(&(*CONSTANT_7),&(v66_2));
    let v66_4: Space = if has_head(&(v66_3)) { singleton(&[]) } else { Space::new() };
    drop(v66_3);
    let v66_5: Space = subtract(&(*CONSTANT_0),&(v66_4));
    drop(v66_4);
    let v66_7: Space = if (&(v66_5)).is_empty() { Space::new() } else {
      let v67_6: Space = routine_12(c, &v65_11_cursor.path()[v65_11_origin..(v65_11_origin + 1)], &v65_11_cursor);
      compose(&(v66_5),&(v67_6))
    };
    drop(v66_5);
    let v66_8: Space = intersect(&(*CONSTANT_7),&(v66_2));
    drop(v66_2);
    let v66_9: Space = if has_head(&(v66_8)) { singleton(&[]) } else { Space::new() };
    drop(v66_8);
    let v66_10: Space = compose(&(v66_9),&v65_11_cursor);
    drop(v66_9);
    let v66_11: Space = unite(&(v66_7),&(v66_10));
    drop(v66_10);
    join_wrapped_into(&mut v65_11_write,&((v66_11).read_zipper()),&[]);
    }
    v65_11_cursor.ascend(1);
  }
  drop(v65_11_cursor);
  drop(v65_11_write);
  drop(v65_7);
  let v65_22: Space = if (&(v65_11)).is_empty() { Space::new() } else {
    let v68_12: Path = concat_path(&(*capture_2),&(*capture_3));
    let v68_13: Path = concat_path(&(v68_12),&(*capture_0));
    drop(v68_12);
    let v68_14: Space = singleton(&(v68_13));
    drop(v68_13);
    let mut v68_21 = Space::new();
    let mut v68_21_write = v68_21.write_zipper();
    let mut v68_21_cursor = (v68_14).read_zipper();
    let v68_21_origin = v68_21_cursor.path().len();
    for v68_21_byte in v68_21_cursor.child_mask().iter() {
      v68_21_cursor.descend_to_existing_byte(v68_21_byte);
      {
      let v69_2: Space = singleton(&v68_21_cursor.path()[v68_21_origin..(v68_21_origin + 1)]);
      let v69_3: Space = intersect(&(*CONSTANT_7),&(v69_2));
      let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
      drop(v69_3);
      let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
      drop(v69_4);
      let v69_7: Space = if (&(v69_5)).is_empty() { Space::new() } else {
        let v70_6: Space = routine_13(c, &v68_21_cursor.path()[v68_21_origin..(v68_21_origin + 1)], &v68_21_cursor);
        compose(&(v69_5),&(v70_6))
      };
      drop(v69_5);
      let v69_8: Space = intersect(&(*CONSTANT_7),&(v69_2));
      drop(v69_2);
      let v69_9: Space = if has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
      drop(v69_8);
      let v69_11: Space = if (&(v69_9)).is_empty() { Space::new() } else {
        let mut v71_10 = Space::new();
        let mut v71_10_write = v71_10.write_zipper();
        for v71_10_byte in v68_21_cursor.child_mask().iter() {
          v68_21_cursor.descend_to_existing_byte(v71_10_byte);
          {
          let v72_2: Space = singleton(&v68_21_cursor.path()[(v68_21_origin + 1)..(v68_21_origin + 2)]);
          let v72_3: Space = intersect(&(*CONSTANT_7),&(v72_2));
          let v72_4: Space = if has_head(&(v72_3)) { singleton(&[]) } else { Space::new() };
          drop(v72_3);
          let v72_5: Space = subtract(&(*CONSTANT_0),&(v72_4));
          drop(v72_4);
          let v72_7: Space = if (&(v72_5)).is_empty() { Space::new() } else {
            let v73_6: Space = routine_14(c, &v68_21_cursor.path()[(v68_21_origin + 1)..(v68_21_origin + 2)], &v68_21_cursor.path()[v68_21_origin..(v68_21_origin + 1)], &v68_21_cursor);
            compose(&(v72_5),&(v73_6))
          };
          drop(v72_5);
          let v72_8: Space = intersect(&(*CONSTANT_7),&(v72_2));
          drop(v72_2);
          let v72_9: Space = if has_head(&(v72_8)) { singleton(&[]) } else { Space::new() };
          drop(v72_8);
          let v72_11: Space = if (&(v72_9)).is_empty() { Space::new() } else {
            let v74_10: Space = routine_15(c, &v68_21_cursor.path()[(v68_21_origin + 1)..(v68_21_origin + 2)], &v68_21_cursor.path()[v68_21_origin..(v68_21_origin + 1)], &v68_21_cursor);
            compose(&(v72_9),&(v74_10))
          };
          drop(v72_9);
          let v72_12: Space = unite(&(v72_7),&(v72_11));
          join_wrapped_into(&mut v71_10_write,&((v72_12).read_zipper()),&[]);
          }
          v68_21_cursor.ascend(1);
        }
        drop(v71_10_write);
        compose(&(v69_9),&(v71_10))
      };
      drop(v69_9);
      let v69_12: Space = unite(&(v69_7),&(v69_11));
      join_wrapped_into(&mut v68_21_write,&((v69_12).read_zipper()),&[]);
      }
      v68_21_cursor.ascend(1);
    }
    drop(v68_21_cursor);
    drop(v68_21_write);
    compose(&(v65_11),&(v68_21))
  };
  let v65_24: Space = intersect(&(*CONSTANT_9),&(v65_6));
  let mut v65_28 = Space::new();
  let mut v65_28_write = v65_28.write_zipper();
  let mut v65_28_cursor = (v65_24).read_zipper();
  let v65_28_origin = v65_28_cursor.path().len();
  for v65_28_byte in v65_28_cursor.child_mask().iter() {
    v65_28_cursor.descend_to_existing_byte(v65_28_byte);
    {
    let v75_2: Space = singleton(&v65_28_cursor.path()[v65_28_origin..(v65_28_origin + 1)]);
    let v75_3: Space = intersect(&(*CONSTANT_7),&(v75_2));
    let v75_4: Space = if has_head(&(v75_3)) { singleton(&[]) } else { Space::new() };
    drop(v75_3);
    let v75_5: Space = subtract(&(*CONSTANT_0),&(v75_4));
    drop(v75_4);
    let v75_7: Space = if (&(v75_5)).is_empty() { Space::new() } else {
      let v76_6: Space = routine_16(c, &v65_28_cursor.path()[v65_28_origin..(v65_28_origin + 1)], &v65_28_cursor);
      compose(&(v75_5),&(v76_6))
    };
    drop(v75_5);
    let v75_8: Space = intersect(&(*CONSTANT_7),&(v75_2));
    drop(v75_2);
    let v75_9: Space = if has_head(&(v75_8)) { singleton(&[]) } else { Space::new() };
    drop(v75_8);
    let v75_10: Space = compose(&(v75_9),&v65_28_cursor);
    drop(v75_9);
    let v75_11: Space = unite(&(v75_7),&(v75_10));
    drop(v75_10);
    join_wrapped_into(&mut v65_28_write,&((v75_11).read_zipper()),&[]);
    }
    v65_28_cursor.ascend(1);
  }
  drop(v65_28_cursor);
  drop(v65_28_write);
  drop(v65_24);
  let v65_36: Space = if (&(v65_28)).is_empty() { Space::new() } else {
    let v77_12: Path = concat_path(&(*capture_2),&(*capture_3));
    let v77_13: Path = concat_path(&(v77_12),&(*capture_0));
    drop(v77_12);
    let v77_14: Space = singleton(&(v77_13));
    drop(v77_13);
    let mut v77_35 = Space::new();
    let mut v77_35_write = v77_35.write_zipper();
    let mut v77_35_cursor = (v77_14).read_zipper();
    let v77_35_origin = v77_35_cursor.path().len();
    for v77_35_byte in v77_35_cursor.child_mask().iter() {
      v77_35_cursor.descend_to_existing_byte(v77_35_byte);
      {
      let v78_2: Space = singleton(&v77_35_cursor.path()[v77_35_origin..(v77_35_origin + 1)]);
      let v78_3: Space = intersect(&(*CONSTANT_7),&(v78_2));
      let v78_4: Space = if has_head(&(v78_3)) { singleton(&[]) } else { Space::new() };
      drop(v78_3);
      let v78_5: Space = subtract(&(*CONSTANT_0),&(v78_4));
      drop(v78_4);
      let v78_7: Space = if (&(v78_5)).is_empty() { Space::new() } else {
        let v79_6: Space = routine_17(c, &v77_35_cursor.path()[v77_35_origin..(v77_35_origin + 1)], &v77_35_cursor);
        compose(&(v78_5),&(v79_6))
      };
      drop(v78_5);
      let v78_8: Space = intersect(&(*CONSTANT_7),&(v78_2));
      drop(v78_2);
      let v78_9: Space = if has_head(&(v78_8)) { singleton(&[]) } else { Space::new() };
      drop(v78_8);
      let v78_11: Space = if (&(v78_9)).is_empty() { Space::new() } else {
        let mut v80_10 = Space::new();
        let mut v80_10_write = v80_10.write_zipper();
        for v80_10_byte in v77_35_cursor.child_mask().iter() {
          v77_35_cursor.descend_to_existing_byte(v80_10_byte);
          {
          let v81_2: Space = singleton(&v77_35_cursor.path()[(v77_35_origin + 1)..(v77_35_origin + 2)]);
          let v81_3: Space = intersect(&(*CONSTANT_7),&(v81_2));
          let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
          drop(v81_3);
          let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
          drop(v81_4);
          let v81_7: Space = if (&(v81_5)).is_empty() { Space::new() } else {
            let v82_6: Space = routine_18(c, &v77_35_cursor.path()[(v77_35_origin + 1)..(v77_35_origin + 2)], &v77_35_cursor.path()[v77_35_origin..(v77_35_origin + 1)], &v77_35_cursor);
            compose(&(v81_5),&(v82_6))
          };
          drop(v81_5);
          let v81_8: Space = intersect(&(*CONSTANT_7),&(v81_2));
          drop(v81_2);
          let v81_9: Space = if has_head(&(v81_8)) { singleton(&[]) } else { Space::new() };
          drop(v81_8);
          let v81_11: Space = if (&(v81_9)).is_empty() { Space::new() } else {
            let v83_10: Space = routine_19(c, &v77_35_cursor.path()[(v77_35_origin + 1)..(v77_35_origin + 2)], &v77_35_cursor.path()[v77_35_origin..(v77_35_origin + 1)], &v77_35_cursor);
            compose(&(v81_9),&(v83_10))
          };
          drop(v81_9);
          let v81_12: Space = unite(&(v81_7),&(v81_11));
          join_wrapped_into(&mut v80_10_write,&((v81_12).read_zipper()),&[]);
          }
          v77_35_cursor.ascend(1);
        }
        drop(v80_10_write);
        compose(&(v78_9),&(v80_10))
      };
      drop(v78_9);
      let v78_12: Space = unite(&(v78_7),&(v78_11));
      join_wrapped_into(&mut v77_35_write,&((v78_12).read_zipper()),&[]);
      }
      v77_35_cursor.ascend(1);
    }
    drop(v77_35_cursor);
    drop(v77_35_write);
    compose(&(v65_28),&(v77_35))
  };
  let v65_37: Space = unite(&(v65_22),&(v65_36));
  let v65_39: Space = intersect(&(*CONSTANT_10),&(v65_6));
  let mut v65_43 = Space::new();
  let mut v65_43_write = v65_43.write_zipper();
  let mut v65_43_cursor = (v65_39).read_zipper();
  let v65_43_origin = v65_43_cursor.path().len();
  for v65_43_byte in v65_43_cursor.child_mask().iter() {
    v65_43_cursor.descend_to_existing_byte(v65_43_byte);
    {
    let v84_2: Space = singleton(&v65_43_cursor.path()[v65_43_origin..(v65_43_origin + 1)]);
    let v84_3: Space = intersect(&(*CONSTANT_7),&(v84_2));
    let v84_4: Space = if has_head(&(v84_3)) { singleton(&[]) } else { Space::new() };
    drop(v84_3);
    let v84_5: Space = subtract(&(*CONSTANT_0),&(v84_4));
    drop(v84_4);
    let v84_7: Space = if (&(v84_5)).is_empty() { Space::new() } else {
      let v85_6: Space = routine_20(c, &v65_43_cursor.path()[v65_43_origin..(v65_43_origin + 1)], &v65_43_cursor);
      compose(&(v84_5),&(v85_6))
    };
    drop(v84_5);
    let v84_8: Space = intersect(&(*CONSTANT_7),&(v84_2));
    drop(v84_2);
    let v84_9: Space = if has_head(&(v84_8)) { singleton(&[]) } else { Space::new() };
    drop(v84_8);
    let v84_10: Space = compose(&(v84_9),&v65_43_cursor);
    drop(v84_9);
    let v84_11: Space = unite(&(v84_7),&(v84_10));
    drop(v84_10);
    join_wrapped_into(&mut v65_43_write,&((v84_11).read_zipper()),&[]);
    }
    v65_43_cursor.ascend(1);
  }
  drop(v65_43_cursor);
  drop(v65_43_write);
  drop(v65_39);
  let v65_51: Space = if (&(v65_43)).is_empty() { Space::new() } else {
    let v86_12: Path = concat_path(&(*capture_2),&(*capture_3));
    let v86_13: Path = concat_path(&(v86_12),&(*capture_0));
    drop(v86_12);
    let v86_14: Space = singleton(&(v86_13));
    drop(v86_13);
    let mut v86_50 = Space::new();
    let mut v86_50_write = v86_50.write_zipper();
    let mut v86_50_cursor = (v86_14).read_zipper();
    let v86_50_origin = v86_50_cursor.path().len();
    for v86_50_byte in v86_50_cursor.child_mask().iter() {
      v86_50_cursor.descend_to_existing_byte(v86_50_byte);
      {
      let v87_2: Space = singleton(&v86_50_cursor.path()[v86_50_origin..(v86_50_origin + 1)]);
      let v87_3: Space = intersect(&(*CONSTANT_7),&(v87_2));
      let v87_4: Space = if has_head(&(v87_3)) { singleton(&[]) } else { Space::new() };
      drop(v87_3);
      let v87_5: Space = subtract(&(*CONSTANT_0),&(v87_4));
      drop(v87_4);
      let v87_7: Space = if (&(v87_5)).is_empty() { Space::new() } else {
        let v88_6: Space = routine_21(c, &v86_50_cursor.path()[v86_50_origin..(v86_50_origin + 1)], &v86_50_cursor);
        compose(&(v87_5),&(v88_6))
      };
      drop(v87_5);
      let v87_8: Space = intersect(&(*CONSTANT_7),&(v87_2));
      drop(v87_2);
      let v87_9: Space = if has_head(&(v87_8)) { singleton(&[]) } else { Space::new() };
      drop(v87_8);
      let v87_11: Space = if (&(v87_9)).is_empty() { Space::new() } else {
        let mut v89_10 = Space::new();
        let mut v89_10_write = v89_10.write_zipper();
        for v89_10_byte in v86_50_cursor.child_mask().iter() {
          v86_50_cursor.descend_to_existing_byte(v89_10_byte);
          {
          let v90_2: Space = singleton(&v86_50_cursor.path()[(v86_50_origin + 1)..(v86_50_origin + 2)]);
          let v90_3: Space = intersect(&(*CONSTANT_7),&(v90_2));
          let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
          drop(v90_3);
          let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
          drop(v90_4);
          let v90_7: Space = if (&(v90_5)).is_empty() { Space::new() } else {
            let v91_6: Space = routine_22(c, &v86_50_cursor.path()[(v86_50_origin + 1)..(v86_50_origin + 2)], &v86_50_cursor.path()[v86_50_origin..(v86_50_origin + 1)], &v86_50_cursor);
            compose(&(v90_5),&(v91_6))
          };
          drop(v90_5);
          let v90_8: Space = intersect(&(*CONSTANT_7),&(v90_2));
          drop(v90_2);
          let v90_9: Space = if has_head(&(v90_8)) { singleton(&[]) } else { Space::new() };
          drop(v90_8);
          let v90_11: Space = if (&(v90_9)).is_empty() { Space::new() } else {
            let v92_10: Space = routine_23(c, &v86_50_cursor.path()[(v86_50_origin + 1)..(v86_50_origin + 2)], &v86_50_cursor.path()[v86_50_origin..(v86_50_origin + 1)], &v86_50_cursor);
            compose(&(v90_9),&(v92_10))
          };
          drop(v90_9);
          let v90_12: Space = unite(&(v90_7),&(v90_11));
          join_wrapped_into(&mut v89_10_write,&((v90_12).read_zipper()),&[]);
          }
          v86_50_cursor.ascend(1);
        }
        drop(v89_10_write);
        compose(&(v87_9),&(v89_10))
      };
      drop(v87_9);
      let v87_12: Space = unite(&(v87_7),&(v87_11));
      join_wrapped_into(&mut v86_50_write,&((v87_12).read_zipper()),&[]);
      }
      v86_50_cursor.ascend(1);
    }
    drop(v86_50_cursor);
    drop(v86_50_write);
    compose(&(v65_43),&(v86_50))
  };
  let v65_52: Space = unite(&(v65_37),&(v65_51));
  let v65_54: Space = intersect(&(*CONSTANT_11),&(v65_6));
  drop(v65_6);
  let mut v65_58 = Space::new();
  let mut v65_58_write = v65_58.write_zipper();
  let mut v65_58_cursor = (v65_54).read_zipper();
  let v65_58_origin = v65_58_cursor.path().len();
  for v65_58_byte in v65_58_cursor.child_mask().iter() {
    v65_58_cursor.descend_to_existing_byte(v65_58_byte);
    {
    let v93_2: Space = singleton(&v65_58_cursor.path()[v65_58_origin..(v65_58_origin + 1)]);
    let v93_3: Space = intersect(&(*CONSTANT_7),&(v93_2));
    let v93_4: Space = if has_head(&(v93_3)) { singleton(&[]) } else { Space::new() };
    drop(v93_3);
    let v93_5: Space = subtract(&(*CONSTANT_0),&(v93_4));
    drop(v93_4);
    let v93_7: Space = if (&(v93_5)).is_empty() { Space::new() } else {
      let v94_6: Space = routine_24(c, &v65_58_cursor.path()[v65_58_origin..(v65_58_origin + 1)], &v65_58_cursor);
      compose(&(v93_5),&(v94_6))
    };
    drop(v93_5);
    let v93_8: Space = intersect(&(*CONSTANT_7),&(v93_2));
    drop(v93_2);
    let v93_9: Space = if has_head(&(v93_8)) { singleton(&[]) } else { Space::new() };
    drop(v93_8);
    let v93_10: Space = compose(&(v93_9),&v65_58_cursor);
    drop(v93_9);
    let v93_11: Space = unite(&(v93_7),&(v93_10));
    drop(v93_10);
    join_wrapped_into(&mut v65_58_write,&((v93_11).read_zipper()),&[]);
    }
    v65_58_cursor.ascend(1);
  }
  drop(v65_58_cursor);
  drop(v65_58_write);
  drop(v65_54);
  let v65_66: Space = if (&(v65_58)).is_empty() { Space::new() } else {
    let v95_12: Path = concat_path(&(*capture_2),&(*capture_3));
    let v95_13: Path = concat_path(&(v95_12),&(*capture_0));
    drop(v95_12);
    let v95_14: Space = singleton(&(v95_13));
    drop(v95_13);
    let mut v95_65 = Space::new();
    let mut v95_65_write = v95_65.write_zipper();
    let mut v95_65_cursor = (v95_14).read_zipper();
    let v95_65_origin = v95_65_cursor.path().len();
    for v95_65_byte in v95_65_cursor.child_mask().iter() {
      v95_65_cursor.descend_to_existing_byte(v95_65_byte);
      {
      let v96_2: Space = singleton(&v95_65_cursor.path()[v95_65_origin..(v95_65_origin + 1)]);
      let v96_3: Space = intersect(&(*CONSTANT_7),&(v96_2));
      let v96_4: Space = if has_head(&(v96_3)) { singleton(&[]) } else { Space::new() };
      drop(v96_3);
      let v96_5: Space = subtract(&(*CONSTANT_0),&(v96_4));
      drop(v96_4);
      let v96_7: Space = if (&(v96_5)).is_empty() { Space::new() } else {
        let v97_6: Space = routine_25(c, &v95_65_cursor.path()[v95_65_origin..(v95_65_origin + 1)], &v95_65_cursor);
        compose(&(v96_5),&(v97_6))
      };
      drop(v96_5);
      let v96_8: Space = intersect(&(*CONSTANT_7),&(v96_2));
      drop(v96_2);
      let v96_9: Space = if has_head(&(v96_8)) { singleton(&[]) } else { Space::new() };
      drop(v96_8);
      let v96_11: Space = if (&(v96_9)).is_empty() { Space::new() } else {
        let mut v98_10 = Space::new();
        let mut v98_10_write = v98_10.write_zipper();
        for v98_10_byte in v95_65_cursor.child_mask().iter() {
          v95_65_cursor.descend_to_existing_byte(v98_10_byte);
          {
          let v99_2: Space = singleton(&v95_65_cursor.path()[(v95_65_origin + 1)..(v95_65_origin + 2)]);
          let v99_3: Space = intersect(&(*CONSTANT_7),&(v99_2));
          let v99_4: Space = if has_head(&(v99_3)) { singleton(&[]) } else { Space::new() };
          drop(v99_3);
          let v99_5: Space = subtract(&(*CONSTANT_0),&(v99_4));
          drop(v99_4);
          let v99_7: Space = if (&(v99_5)).is_empty() { Space::new() } else {
            let v100_6: Space = routine_26(c, &v95_65_cursor.path()[(v95_65_origin + 1)..(v95_65_origin + 2)], &v95_65_cursor.path()[v95_65_origin..(v95_65_origin + 1)], &v95_65_cursor);
            compose(&(v99_5),&(v100_6))
          };
          drop(v99_5);
          let v99_8: Space = intersect(&(*CONSTANT_7),&(v99_2));
          drop(v99_2);
          let v99_9: Space = if has_head(&(v99_8)) { singleton(&[]) } else { Space::new() };
          drop(v99_8);
          let v99_11: Space = if (&(v99_9)).is_empty() { Space::new() } else {
            let v101_10: Space = routine_27(c, &v95_65_cursor.path()[(v95_65_origin + 1)..(v95_65_origin + 2)], &v95_65_cursor.path()[v95_65_origin..(v95_65_origin + 1)], &v95_65_cursor);
            compose(&(v99_9),&(v101_10))
          };
          drop(v99_9);
          let v99_12: Space = unite(&(v99_7),&(v99_11));
          join_wrapped_into(&mut v98_10_write,&((v99_12).read_zipper()),&[]);
          }
          v95_65_cursor.ascend(1);
        }
        drop(v98_10_write);
        compose(&(v96_9),&(v98_10))
      };
      drop(v96_9);
      let v96_12: Space = unite(&(v96_7),&(v96_11));
      join_wrapped_into(&mut v95_65_write,&((v96_12).read_zipper()),&[]);
      }
      v95_65_cursor.ascend(1);
    }
    drop(v95_65_cursor);
    drop(v95_65_write);
    drop(v95_14);
    compose(&(v65_58),&(v95_65))
  };
  let v65_67: Space = unite(&(v65_52),&(v65_66));
  let mut v65_82 = Space::new();
  let mut v65_82_write = v65_82.write_zipper();
  let mut v65_82_cursor = (v65_67).read_zipper();
  let v65_82_origin = v65_82_cursor.path().len();
  for v65_82_byte in v65_82_cursor.child_mask().iter() {
    v65_82_cursor.descend_to_existing_byte(v65_82_byte);
    {
    let v102_2: Space = singleton(&v65_82_cursor.path()[v65_82_origin..(v65_82_origin + 1)]);
    let v102_3: Space = intersect(&(*CONSTANT_7),&(v102_2));
    let v102_4: Space = if has_head(&(v102_3)) { singleton(&[]) } else { Space::new() };
    drop(v102_3);
    let v102_5: Space = subtract(&(*CONSTANT_0),&(v102_4));
    drop(v102_4);
    let v102_7: Space = if (&(v102_5)).is_empty() { Space::new() } else {
      let mut v103_6 = Space::new();
      let mut v103_6_write = v103_6.write_zipper();
      for v103_6_byte in v65_82_cursor.child_mask().iter() {
        v65_82_cursor.descend_to_existing_byte(v103_6_byte);
        {
        let v104_2: Space = singleton(&v65_82_cursor.path()[(v65_82_origin + 1)..(v65_82_origin + 2)]);
        let v104_3: Space = intersect(&(*CONSTANT_7),&(v104_2));
        let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
        drop(v104_3);
        let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
        drop(v104_4);
        let v104_8: Space = if (&(v104_5)).is_empty() { Space::new() } else {
          let v105_7: Space = routine_8(c, &v65_82_cursor.path()[v65_82_origin..(v65_82_origin + 2)], &(*capture_1), &v65_82_cursor);
          compose(&(v104_5),&(v105_7))
        };
        drop(v104_5);
        let v104_9: Space = intersect(&(*CONSTANT_7),&(v104_2));
        drop(v104_2);
        let v104_10: Space = if has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
        drop(v104_9);
        let v104_12: Space = if (&(v104_10)).is_empty() { Space::new() } else {
          let v106_11: Space = routine_9(c, &v65_82_cursor.path()[v65_82_origin..(v65_82_origin + 2)], &(*capture_1), &v65_82_cursor);
          compose(&(v104_10),&(v106_11))
        };
        drop(v104_10);
        let v104_13: Space = unite(&(v104_8),&(v104_12));
        join_wrapped_into(&mut v103_6_write,&((v104_13).read_zipper()),&[]);
        }
        v65_82_cursor.ascend(1);
      }
      drop(v103_6_write);
      compose(&(v102_5),&(v103_6))
    };
    drop(v102_5);
    let v102_8: Space = intersect(&(*CONSTANT_7),&(v102_2));
    drop(v102_2);
    let v102_9: Space = if has_head(&(v102_8)) { singleton(&[]) } else { Space::new() };
    drop(v102_8);
    let v102_16: Space = if (&(v102_9)).is_empty() { Space::new() } else {
      let v107_13: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v108_10: Space = routine_28(c, &(*CONSTANT_12), &((*CONSTANT_13).read_zipper()));
        let v108_11: Space = routine_28(c, &(*CONSTANT_14), &((*CONSTANT_15).read_zipper()));
        let v108_12: Space = unite(&(v108_10),&(v108_11));
        compose(&(*CONSTANT_0),&(v108_12))
      };
      let mut v107_15 = Space::new();
      let mut v107_15_write = v107_15.write_zipper();
      let mut v107_15_cursor = descend_cursor((v107_13).read_zipper(),&(*capture_1));
      let v107_15_origin = v107_15_cursor.path().len();
      for v107_15_byte in v107_15_cursor.child_mask().iter() {
        v107_15_cursor.descend_to_existing_byte(v107_15_byte);
        {
        let v109_2: Space = singleton(&v107_15_cursor.path()[v107_15_origin..(v107_15_origin + 1)]);
        let v109_3: Space = intersect(&(*CONSTANT_7),&(v109_2));
        let v109_4: Space = if has_head(&(v109_3)) { singleton(&[]) } else { Space::new() };
        drop(v109_3);
        let v109_5: Space = subtract(&(*CONSTANT_0),&(v109_4));
        drop(v109_4);
        let v109_7: Space = if (&(v109_5)).is_empty() { Space::new() } else {
          let v110_6: Space = routine_29(c, &v107_15_cursor.path()[v107_15_origin..(v107_15_origin + 1)], &v65_82_cursor.path()[v65_82_origin..(v65_82_origin + 1)], &v107_15_cursor, &v65_82_cursor);
          compose(&(v109_5),&(v110_6))
        };
        drop(v109_5);
        let v109_8: Space = intersect(&(*CONSTANT_7),&(v109_2));
        drop(v109_2);
        let v109_9: Space = if has_head(&(v109_8)) { singleton(&[]) } else { Space::new() };
        drop(v109_8);
        let v109_13: Space = if (&(v109_9)).is_empty() { Space::new() } else {
          let v111_11: Space = wrap(&(descend_cursor(cursor_at(&v107_15_cursor,(v107_15_origin + 1)),&v65_82_cursor.path()[v65_82_origin..(v65_82_origin + 1)])),&v107_15_cursor.path()[v107_15_origin..(v107_15_origin + 1)]);
          let v111_12: Space = compose(&(v111_11),&v65_82_cursor);
          drop(v111_11);
          compose(&(v109_9),&(v111_12))
        };
        drop(v109_9);
        let v109_14: Space = unite(&(v109_7),&(v109_13));
        drop(v109_13);
        join_wrapped_into(&mut v107_15_write,&((v109_14).read_zipper()),&[]);
        }
        v107_15_cursor.ascend(1);
      }
      drop(v107_15_cursor);
      drop(v107_15_write);
      compose(&(v102_9),&(v107_15))
    };
    drop(v102_9);
    let v102_17: Space = unite(&(v102_7),&(v102_16));
    join_wrapped_into(&mut v65_82_write,&((v102_17).read_zipper()),&[]);
    }
    v65_82_cursor.ascend(1);
  }
  drop(v65_82_cursor);
  drop(v65_82_write);
  let mut v65_103 = Space::new();
  let mut v65_103_write = v65_103.write_zipper();
  let mut v65_103_cursor = (v65_82).read_zipper();
  let v65_103_origin = v65_103_cursor.path().len();
  for v65_103_byte in v65_103_cursor.child_mask().iter() {
    v65_103_cursor.descend_to_existing_byte(v65_103_byte);
    {
    let v112_2: Space = singleton(&v65_103_cursor.path()[v65_103_origin..(v65_103_origin + 1)]);
    let v112_3: Space = intersect(&(*CONSTANT_7),&(v112_2));
    let v112_4: Space = if has_head(&(v112_3)) { singleton(&[]) } else { Space::new() };
    drop(v112_3);
    let v112_5: Space = subtract(&(*CONSTANT_0),&(v112_4));
    drop(v112_4);
    let v112_7: Space = if (&(v112_5)).is_empty() { Space::new() } else {
      let mut v113_6 = Space::new();
      let mut v113_6_write = v113_6.write_zipper();
      for v113_6_byte in v65_103_cursor.child_mask().iter() {
        v65_103_cursor.descend_to_existing_byte(v113_6_byte);
        {
        let v114_2: Space = singleton(&v65_103_cursor.path()[(v65_103_origin + 1)..(v65_103_origin + 2)]);
        let v114_3: Space = intersect(&(*CONSTANT_7),&(v114_2));
        let v114_4: Space = if has_head(&(v114_3)) { singleton(&[]) } else { Space::new() };
        drop(v114_3);
        let v114_5: Space = subtract(&(*CONSTANT_0),&(v114_4));
        drop(v114_4);
        let v114_8: Space = if (&(v114_5)).is_empty() { Space::new() } else {
          let v115_7: Space = routine_10(c, &v65_103_cursor.path()[v65_103_origin..(v65_103_origin + 2)], &(*capture_1), &v65_103_cursor);
          compose(&(v114_5),&(v115_7))
        };
        drop(v114_5);
        let v114_9: Space = intersect(&(*CONSTANT_7),&(v114_2));
        drop(v114_2);
        let v114_10: Space = if has_head(&(v114_9)) { singleton(&[]) } else { Space::new() };
        drop(v114_9);
        let v114_12: Space = if (&(v114_10)).is_empty() { Space::new() } else {
          let v116_11: Space = routine_11(c, &v65_103_cursor.path()[v65_103_origin..(v65_103_origin + 2)], &(*capture_1), &v65_103_cursor);
          compose(&(v114_10),&(v116_11))
        };
        drop(v114_10);
        let v114_13: Space = unite(&(v114_8),&(v114_12));
        join_wrapped_into(&mut v113_6_write,&((v114_13).read_zipper()),&[]);
        }
        v65_103_cursor.ascend(1);
      }
      drop(v113_6_write);
      compose(&(v112_5),&(v113_6))
    };
    drop(v112_5);
    let v112_8: Space = intersect(&(*CONSTANT_7),&(v112_2));
    drop(v112_2);
    let v112_9: Space = if has_head(&(v112_8)) { singleton(&[]) } else { Space::new() };
    drop(v112_8);
    let v112_29: Space = if (&(v112_9)).is_empty() { Space::new() } else {
      let v117_13: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v118_10: Space = routine_30(c, &(*CONSTANT_12), &((*CONSTANT_13).read_zipper()));
        let v118_11: Space = routine_30(c, &(*CONSTANT_14), &((*CONSTANT_15).read_zipper()));
        let v118_12: Space = unite(&(v118_10),&(v118_11));
        compose(&(*CONSTANT_0),&(v118_12))
      };
      let v117_19: Space = if (&(descend_cursor(cursor_at(&v65_103_cursor,(v65_103_origin + 1)),&(*CONSTANT_16)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor(cursor_at(&v65_103_cursor,(v65_103_origin + 1)),&(*CONSTANT_16))),&(descend_cursor(cursor_at(&v65_103_cursor,(v65_103_origin + 1)),&(*CONSTANT_17))))
      };
      let v117_21: Space = if (&(v117_19)).is_empty() { Space::new() } else {
        compose(&(v117_19),&(descend_cursor(cursor_at(&v65_103_cursor,(v65_103_origin + 1)),&(*CONSTANT_18))))
      };
      let v117_23: Space = if (&(v117_19)).is_empty() { Space::new() } else {
        compose(&(v117_19),&(descend_cursor(cursor_at(&v65_103_cursor,(v65_103_origin + 1)),&(*CONSTANT_19))))
      };
      drop(v117_19);
      let v117_24: Space = if (&(descend_cursor(cursor_at(&v65_103_cursor,(v65_103_origin + 1)),&(*CONSTANT_17)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor(cursor_at(&v65_103_cursor,(v65_103_origin + 1)),&(*CONSTANT_17))),&(descend_cursor(cursor_at(&v65_103_cursor,(v65_103_origin + 1)),&(*CONSTANT_19))))
      };
      let v117_25: Space = if (&(v117_24)).is_empty() { Space::new() } else {
        compose(&(v117_24),&(descend_cursor(cursor_at(&v65_103_cursor,(v65_103_origin + 1)),&(*CONSTANT_18))))
      };
      drop(v117_24);
      let v117_26: Space = if (&(descend_cursor(cursor_at(&v65_103_cursor,(v65_103_origin + 1)),&(*CONSTANT_16)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor(cursor_at(&v65_103_cursor,(v65_103_origin + 1)),&(*CONSTANT_16))),&(descend_cursor(cursor_at(&v65_103_cursor,(v65_103_origin + 1)),&(*CONSTANT_19))))
      };
      let v117_27: Space = if (&(v117_26)).is_empty() { Space::new() } else {
        compose(&(v117_26),&(descend_cursor(cursor_at(&v65_103_cursor,(v65_103_origin + 1)),&(*CONSTANT_18))))
      };
      drop(v117_26);
      let mut v117_28 = Space::new();
      let mut v117_28_write = v117_28.write_zipper();
      let mut v117_28_cursor = descend_cursor(descend_cursor(descend_cursor((v117_13).read_zipper(),&(*capture_1)),&v65_103_cursor.path()[v65_103_origin..(v65_103_origin + 1)]),&(*capture_1));
      let v117_28_origin = v117_28_cursor.path().len();
      for v117_28_byte in v117_28_cursor.child_mask().iter() {
        v117_28_cursor.descend_to_existing_byte(v117_28_byte);
        {
        let v127_2: Space = singleton(&v117_28_cursor.path()[v117_28_origin..(v117_28_origin + 1)]);
        let v127_3: Space = intersect(&(*CONSTANT_7),&(v127_2));
        let v127_4: Space = if has_head(&(v127_3)) { singleton(&[]) } else { Space::new() };
        drop(v127_3);
        let v127_5: Space = subtract(&(*CONSTANT_0),&(v127_4));
        drop(v127_4);
        let v127_7: Space = if (&(v127_5)).is_empty() { Space::new() } else {
          let v128_6: Space = routine_31(c, &v117_28_cursor.path()[v117_28_origin..(v117_28_origin + 1)], &v117_28_cursor, &v65_103_cursor);
          compose(&(v127_5),&(v128_6))
        };
        drop(v127_5);
        let v127_8: Space = intersect(&(*CONSTANT_7),&(v127_2));
        let v127_9: Space = if has_head(&(v127_8)) { singleton(&[]) } else { Space::new() };
        drop(v127_8);
        let v127_21: Space = if (&(v127_9)).is_empty() { Space::new() } else {
          let v129_10: Space = intersect(&(*CONSTANT_8),&(v127_2));
          let v129_11: Space = compose(&(v129_10),&(v117_21));
          drop(v129_10);
          let v129_12: Space = intersect(&(*CONSTANT_9),&(v127_2));
          let v129_13: Space = compose(&(v129_12),&(v117_23));
          drop(v129_12);
          let v129_14: Space = unite(&(v129_11),&(v129_13));
          drop(v129_11);
          drop(v129_13);
          let v129_15: Space = intersect(&(*CONSTANT_10),&(v127_2));
          let v129_16: Space = compose(&(v129_15),&(v117_25));
          drop(v129_15);
          let v129_17: Space = unite(&(v129_14),&(v129_16));
          drop(v129_14);
          drop(v129_16);
          let v129_18: Space = intersect(&(*CONSTANT_11),&(v127_2));
          let v129_19: Space = compose(&(v129_18),&(v117_27));
          drop(v129_18);
          let v129_20: Space = unite(&(v129_17),&(v129_19));
          drop(v129_17);
          drop(v129_19);
          compose(&(v127_9),&(v129_20))
        };
        drop(v127_9);
        let v127_22: Space = unite(&(v127_7),&(v127_21));
        drop(v127_21);
        join_wrapped_into(&mut v117_28_write,&((v127_22).read_zipper()),&[]);
        }
        v117_28_cursor.ascend(1);
      }
      drop(v117_28_cursor);
      drop(v117_28_write);
      drop(v117_21);
      drop(v117_23);
      drop(v117_25);
      drop(v117_27);
      compose(&(v112_9),&(v117_28))
    };
    drop(v112_9);
    let v112_30: Space = unite(&(v112_7),&(v112_29));
    join_wrapped_into(&mut v65_103_write,&((v112_30).read_zipper()),&[]);
    }
    v65_103_cursor.ascend(1);
  }
  drop(v65_103_cursor);
  drop(v65_103_write);

((v65_103).clone(),(v65_11).clone(),(v65_22).clone(),(v65_28).clone(),(v65_36).clone(),(v65_37).clone(),(v65_43).clone(),(v65_51).clone(),(v65_52).clone(),(v65_58).clone(),(v65_66).clone(),(v65_67).clone(),(v65_82).clone(),)
}

#[inline(never)]
fn native_block_1(c: &mut Context,capture_0: &[u8],capture_1: &View<'_, '_>) -> (Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v130_3: Space = singleton(&(*capture_0));
  let v130_4: Space = intersect(&(*CONSTANT_8),&(v130_3));
  let mut v130_11 = Space::new();
  let mut v130_11_write = v130_11.write_zipper();
  let mut v130_11_cursor = (v130_4).read_zipper();
  let v130_11_origin = v130_11_cursor.path().len();
  for v130_11_byte in v130_11_cursor.child_mask().iter() {
    v130_11_cursor.descend_to_existing_byte(v130_11_byte);
    {
    let v131_2: Space = singleton(&v130_11_cursor.path()[v130_11_origin..(v130_11_origin + 1)]);
    let v131_3: Space = intersect(&(*CONSTANT_7),&(v131_2));
    let v131_4: Space = if has_head(&(v131_3)) { singleton(&[]) } else { Space::new() };
    drop(v131_3);
    let v131_5: Space = subtract(&(*CONSTANT_0),&(v131_4));
    drop(v131_4);
    let v131_7: Space = if (&(v131_5)).is_empty() { Space::new() } else {
      let mut v132_6 = Space::new();
      let mut v132_6_write = v132_6.write_zipper();
      for v132_6_byte in v130_11_cursor.child_mask().iter() {
        v130_11_cursor.descend_to_existing_byte(v132_6_byte);
        {
        let v133_2: Space = singleton(&v130_11_cursor.path()[(v130_11_origin + 1)..(v130_11_origin + 2)]);
        let v133_3: Space = intersect(&(*CONSTANT_7),&(v133_2));
        let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
        drop(v133_3);
        let v133_5: Space = subtract(&(*CONSTANT_0),&(v133_4));
        drop(v133_4);
        let v133_8: Space = if (&(v133_5)).is_empty() { Space::new() } else {
          let v134_7: Space = routine_12(c, &v130_11_cursor.path()[v130_11_origin..(v130_11_origin + 2)], &v130_11_cursor);
          compose(&(v133_5),&(v134_7))
        };
        drop(v133_5);
        let v133_9: Space = intersect(&(*CONSTANT_7),&(v133_2));
        drop(v133_2);
        let v133_10: Space = if has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
        drop(v133_9);
        let v133_11: Space = compose(&(v133_10),&v130_11_cursor);
        drop(v133_10);
        let v133_12: Space = unite(&(v133_8),&(v133_11));
        drop(v133_11);
        join_wrapped_into(&mut v132_6_write,&((v133_12).read_zipper()),&[]);
        }
        v130_11_cursor.ascend(1);
      }
      drop(v132_6_write);
      compose(&(v131_5),&(v132_6))
    };
    drop(v131_5);
    let v131_8: Space = intersect(&(*CONSTANT_7),&(v131_2));
    drop(v131_2);
    let v131_9: Space = if has_head(&(v131_8)) { singleton(&[]) } else { Space::new() };
    drop(v131_8);
    let v131_10: Space = compose(&(v131_9),&v130_11_cursor);
    drop(v131_9);
    let v131_11: Space = unite(&(v131_7),&(v131_10));
    drop(v131_10);
    join_wrapped_into(&mut v130_11_write,&((v131_11).read_zipper()),&[]);
    }
    v130_11_cursor.ascend(1);
  }
  drop(v130_11_cursor);
  drop(v130_11_write);
  drop(v130_4);
  let v130_28: Space = if (&(v130_11)).is_empty() { Space::new() } else {
    let mut v135_27 = Space::new();
    let mut v135_27_write = v135_27.write_zipper();
    let mut v135_27_cursor = (*capture_1).read_zipper();
    let v135_27_origin = v135_27_cursor.path().len();
    for v135_27_byte in v135_27_cursor.child_mask().iter() {
      v135_27_cursor.descend_to_existing_byte(v135_27_byte);
      {
      let v136_2: Space = singleton(&v135_27_cursor.path()[v135_27_origin..(v135_27_origin + 1)]);
      let v136_3: Space = intersect(&(*CONSTANT_7),&(v136_2));
      let v136_4: Space = if has_head(&(v136_3)) { singleton(&[]) } else { Space::new() };
      drop(v136_3);
      let v136_5: Space = subtract(&(*CONSTANT_0),&(v136_4));
      drop(v136_4);
      let v136_7: Space = if (&(v136_5)).is_empty() { Space::new() } else {
        let mut v137_6 = Space::new();
        let mut v137_6_write = v137_6.write_zipper();
        for v137_6_byte in v135_27_cursor.child_mask().iter() {
          v135_27_cursor.descend_to_existing_byte(v137_6_byte);
          {
          let v138_2: Space = singleton(&v135_27_cursor.path()[(v135_27_origin + 1)..(v135_27_origin + 2)]);
          let v138_3: Space = intersect(&(*CONSTANT_7),&(v138_2));
          let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
          drop(v138_3);
          let v138_5: Space = subtract(&(*CONSTANT_0),&(v138_4));
          drop(v138_4);
          let v138_8: Space = if (&(v138_5)).is_empty() { Space::new() } else {
            let v139_7: Space = routine_13(c, &v135_27_cursor.path()[v135_27_origin..(v135_27_origin + 2)], &v135_27_cursor);
            compose(&(v138_5),&(v139_7))
          };
          drop(v138_5);
          let v138_9: Space = intersect(&(*CONSTANT_7),&(v138_2));
          drop(v138_2);
          let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
          drop(v138_9);
          let v138_12: Space = if (&(v138_10)).is_empty() { Space::new() } else {
            let mut v140_11 = Space::new();
            let mut v140_11_write = v140_11.write_zipper();
            for v140_11_byte in v135_27_cursor.child_mask().iter() {
              v135_27_cursor.descend_to_existing_byte(v140_11_byte);
              {
              let v141_2: Space = singleton(&v135_27_cursor.path()[(v135_27_origin + 2)..(v135_27_origin + 3)]);
              let v141_3: Space = intersect(&(*CONSTANT_7),&(v141_2));
              let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
              drop(v141_3);
              let v141_5: Space = subtract(&(*CONSTANT_0),&(v141_4));
              drop(v141_4);
              let v141_7: Space = if (&(v141_5)).is_empty() { Space::new() } else {
                let v142_6: Space = routine_14(c, &v135_27_cursor.path()[(v135_27_origin + 2)..(v135_27_origin + 3)], &v135_27_cursor.path()[v135_27_origin..(v135_27_origin + 2)], &v135_27_cursor);
                compose(&(v141_5),&(v142_6))
              };
              drop(v141_5);
              let v141_8: Space = intersect(&(*CONSTANT_7),&(v141_2));
              drop(v141_2);
              let v141_9: Space = if has_head(&(v141_8)) { singleton(&[]) } else { Space::new() };
              drop(v141_8);
              let v141_11: Space = if (&(v141_9)).is_empty() { Space::new() } else {
                let v143_10: Space = routine_15(c, &v135_27_cursor.path()[(v135_27_origin + 2)..(v135_27_origin + 3)], &v135_27_cursor.path()[v135_27_origin..(v135_27_origin + 2)], &v135_27_cursor);
                compose(&(v141_9),&(v143_10))
              };
              drop(v141_9);
              let v141_12: Space = unite(&(v141_7),&(v141_11));
              join_wrapped_into(&mut v140_11_write,&((v141_12).read_zipper()),&[]);
              }
              v135_27_cursor.ascend(1);
            }
            drop(v140_11_write);
            compose(&(v138_10),&(v140_11))
          };
          drop(v138_10);
          let v138_13: Space = unite(&(v138_8),&(v138_12));
          join_wrapped_into(&mut v137_6_write,&((v138_13).read_zipper()),&[]);
          }
          v135_27_cursor.ascend(1);
        }
        drop(v137_6_write);
        compose(&(v136_5),&(v137_6))
      };
      drop(v136_5);
      let v136_8: Space = intersect(&(*CONSTANT_7),&(v136_2));
      drop(v136_2);
      let v136_9: Space = if has_head(&(v136_8)) { singleton(&[]) } else { Space::new() };
      drop(v136_8);
      let v136_11: Space = if (&(v136_9)).is_empty() { Space::new() } else {
        let mut v144_10 = Space::new();
        let mut v144_10_write = v144_10.write_zipper();
        for v144_10_byte in v135_27_cursor.child_mask().iter() {
          v135_27_cursor.descend_to_existing_byte(v144_10_byte);
          {
          let v145_2: Space = singleton(&v135_27_cursor.path()[(v135_27_origin + 1)..(v135_27_origin + 2)]);
          let v145_3: Space = intersect(&(*CONSTANT_7),&(v145_2));
          let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
          drop(v145_3);
          let v145_5: Space = subtract(&(*CONSTANT_0),&(v145_4));
          drop(v145_4);
          let v145_7: Space = if (&(v145_5)).is_empty() { Space::new() } else {
            let v146_6: Space = routine_14(c, &v135_27_cursor.path()[(v135_27_origin + 1)..(v135_27_origin + 2)], &v135_27_cursor.path()[v135_27_origin..(v135_27_origin + 1)], &v135_27_cursor);
            compose(&(v145_5),&(v146_6))
          };
          drop(v145_5);
          let v145_8: Space = intersect(&(*CONSTANT_7),&(v145_2));
          drop(v145_2);
          let v145_9: Space = if has_head(&(v145_8)) { singleton(&[]) } else { Space::new() };
          drop(v145_8);
          let v145_11: Space = if (&(v145_9)).is_empty() { Space::new() } else {
            let mut v147_10 = Space::new();
            let mut v147_10_write = v147_10.write_zipper();
            for v147_10_byte in v135_27_cursor.child_mask().iter() {
              v135_27_cursor.descend_to_existing_byte(v147_10_byte);
              {
              let v148_2: Space = singleton(&v135_27_cursor.path()[(v135_27_origin + 2)..(v135_27_origin + 3)]);
              let v148_3: Space = intersect(&(*CONSTANT_7),&(v148_2));
              let v148_4: Space = if has_head(&(v148_3)) { singleton(&[]) } else { Space::new() };
              drop(v148_3);
              let v148_5: Space = subtract(&(*CONSTANT_0),&(v148_4));
              drop(v148_4);
              let v148_7: Space = if (&(v148_5)).is_empty() { Space::new() } else {
                let v149_6: Space = routine_32(c, &v135_27_cursor.path()[(v135_27_origin + 2)..(v135_27_origin + 3)], &v135_27_cursor.path()[v135_27_origin..(v135_27_origin + 1)], &v135_27_cursor.path()[(v135_27_origin + 1)..(v135_27_origin + 2)], &v135_27_cursor);
                compose(&(v148_5),&(v149_6))
              };
              drop(v148_5);
              let v148_8: Space = intersect(&(*CONSTANT_7),&(v148_2));
              drop(v148_2);
              let v148_9: Space = if has_head(&(v148_8)) { singleton(&[]) } else { Space::new() };
              drop(v148_8);
              let v148_11: Space = if (&(v148_9)).is_empty() { Space::new() } else {
                let v150_10: Space = routine_33(c, &v135_27_cursor.path()[(v135_27_origin + 2)..(v135_27_origin + 3)], &v135_27_cursor.path()[v135_27_origin..(v135_27_origin + 1)], &v135_27_cursor.path()[(v135_27_origin + 1)..(v135_27_origin + 2)], &v135_27_cursor);
                compose(&(v148_9),&(v150_10))
              };
              drop(v148_9);
              let v148_12: Space = unite(&(v148_7),&(v148_11));
              join_wrapped_into(&mut v147_10_write,&((v148_12).read_zipper()),&[]);
              }
              v135_27_cursor.ascend(1);
            }
            drop(v147_10_write);
            compose(&(v145_9),&(v147_10))
          };
          drop(v145_9);
          let v145_12: Space = unite(&(v145_7),&(v145_11));
          join_wrapped_into(&mut v144_10_write,&((v145_12).read_zipper()),&[]);
          }
          v135_27_cursor.ascend(1);
        }
        drop(v144_10_write);
        compose(&(v136_9),&(v144_10))
      };
      drop(v136_9);
      let v136_12: Space = unite(&(v136_7),&(v136_11));
      join_wrapped_into(&mut v135_27_write,&((v136_12).read_zipper()),&[]);
      }
      v135_27_cursor.ascend(1);
    }
    drop(v135_27_cursor);
    drop(v135_27_write);
    compose(&(v130_11),&(v135_27))
  };
  let v130_30: Space = intersect(&(*CONSTANT_9),&(v130_3));
  let mut v130_37 = Space::new();
  let mut v130_37_write = v130_37.write_zipper();
  let mut v130_37_cursor = (v130_30).read_zipper();
  let v130_37_origin = v130_37_cursor.path().len();
  for v130_37_byte in v130_37_cursor.child_mask().iter() {
    v130_37_cursor.descend_to_existing_byte(v130_37_byte);
    {
    let v151_2: Space = singleton(&v130_37_cursor.path()[v130_37_origin..(v130_37_origin + 1)]);
    let v151_3: Space = intersect(&(*CONSTANT_7),&(v151_2));
    let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
    drop(v151_3);
    let v151_5: Space = subtract(&(*CONSTANT_0),&(v151_4));
    drop(v151_4);
    let v151_7: Space = if (&(v151_5)).is_empty() { Space::new() } else {
      let mut v152_6 = Space::new();
      let mut v152_6_write = v152_6.write_zipper();
      for v152_6_byte in v130_37_cursor.child_mask().iter() {
        v130_37_cursor.descend_to_existing_byte(v152_6_byte);
        {
        let v153_2: Space = singleton(&v130_37_cursor.path()[(v130_37_origin + 1)..(v130_37_origin + 2)]);
        let v153_3: Space = intersect(&(*CONSTANT_7),&(v153_2));
        let v153_4: Space = if has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
        drop(v153_3);
        let v153_5: Space = subtract(&(*CONSTANT_0),&(v153_4));
        drop(v153_4);
        let v153_8: Space = if (&(v153_5)).is_empty() { Space::new() } else {
          let v154_7: Space = routine_16(c, &v130_37_cursor.path()[v130_37_origin..(v130_37_origin + 2)], &v130_37_cursor);
          compose(&(v153_5),&(v154_7))
        };
        drop(v153_5);
        let v153_9: Space = intersect(&(*CONSTANT_7),&(v153_2));
        drop(v153_2);
        let v153_10: Space = if has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
        drop(v153_9);
        let v153_11: Space = compose(&(v153_10),&v130_37_cursor);
        drop(v153_10);
        let v153_12: Space = unite(&(v153_8),&(v153_11));
        drop(v153_11);
        join_wrapped_into(&mut v152_6_write,&((v153_12).read_zipper()),&[]);
        }
        v130_37_cursor.ascend(1);
      }
      drop(v152_6_write);
      compose(&(v151_5),&(v152_6))
    };
    drop(v151_5);
    let v151_8: Space = intersect(&(*CONSTANT_7),&(v151_2));
    drop(v151_2);
    let v151_9: Space = if has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
    drop(v151_8);
    let v151_10: Space = compose(&(v151_9),&v130_37_cursor);
    drop(v151_9);
    let v151_11: Space = unite(&(v151_7),&(v151_10));
    drop(v151_10);
    join_wrapped_into(&mut v130_37_write,&((v151_11).read_zipper()),&[]);
    }
    v130_37_cursor.ascend(1);
  }
  drop(v130_37_cursor);
  drop(v130_37_write);
  drop(v130_30);
  let v130_54: Space = if (&(v130_37)).is_empty() { Space::new() } else {
    let mut v155_53 = Space::new();
    let mut v155_53_write = v155_53.write_zipper();
    let mut v155_53_cursor = (*capture_1).read_zipper();
    let v155_53_origin = v155_53_cursor.path().len();
    for v155_53_byte in v155_53_cursor.child_mask().iter() {
      v155_53_cursor.descend_to_existing_byte(v155_53_byte);
      {
      let v156_2: Space = singleton(&v155_53_cursor.path()[v155_53_origin..(v155_53_origin + 1)]);
      let v156_3: Space = intersect(&(*CONSTANT_7),&(v156_2));
      let v156_4: Space = if has_head(&(v156_3)) { singleton(&[]) } else { Space::new() };
      drop(v156_3);
      let v156_5: Space = subtract(&(*CONSTANT_0),&(v156_4));
      drop(v156_4);
      let v156_7: Space = if (&(v156_5)).is_empty() { Space::new() } else {
        let mut v157_6 = Space::new();
        let mut v157_6_write = v157_6.write_zipper();
        for v157_6_byte in v155_53_cursor.child_mask().iter() {
          v155_53_cursor.descend_to_existing_byte(v157_6_byte);
          {
          let v158_2: Space = singleton(&v155_53_cursor.path()[(v155_53_origin + 1)..(v155_53_origin + 2)]);
          let v158_3: Space = intersect(&(*CONSTANT_7),&(v158_2));
          let v158_4: Space = if has_head(&(v158_3)) { singleton(&[]) } else { Space::new() };
          drop(v158_3);
          let v158_5: Space = subtract(&(*CONSTANT_0),&(v158_4));
          drop(v158_4);
          let v158_8: Space = if (&(v158_5)).is_empty() { Space::new() } else {
            let v159_7: Space = routine_17(c, &v155_53_cursor.path()[v155_53_origin..(v155_53_origin + 2)], &v155_53_cursor);
            compose(&(v158_5),&(v159_7))
          };
          drop(v158_5);
          let v158_9: Space = intersect(&(*CONSTANT_7),&(v158_2));
          drop(v158_2);
          let v158_10: Space = if has_head(&(v158_9)) { singleton(&[]) } else { Space::new() };
          drop(v158_9);
          let v158_12: Space = if (&(v158_10)).is_empty() { Space::new() } else {
            let mut v160_11 = Space::new();
            let mut v160_11_write = v160_11.write_zipper();
            for v160_11_byte in v155_53_cursor.child_mask().iter() {
              v155_53_cursor.descend_to_existing_byte(v160_11_byte);
              {
              let v161_2: Space = singleton(&v155_53_cursor.path()[(v155_53_origin + 2)..(v155_53_origin + 3)]);
              let v161_3: Space = intersect(&(*CONSTANT_7),&(v161_2));
              let v161_4: Space = if has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
              drop(v161_3);
              let v161_5: Space = subtract(&(*CONSTANT_0),&(v161_4));
              drop(v161_4);
              let v161_7: Space = if (&(v161_5)).is_empty() { Space::new() } else {
                let v162_6: Space = routine_18(c, &v155_53_cursor.path()[(v155_53_origin + 2)..(v155_53_origin + 3)], &v155_53_cursor.path()[v155_53_origin..(v155_53_origin + 2)], &v155_53_cursor);
                compose(&(v161_5),&(v162_6))
              };
              drop(v161_5);
              let v161_8: Space = intersect(&(*CONSTANT_7),&(v161_2));
              drop(v161_2);
              let v161_9: Space = if has_head(&(v161_8)) { singleton(&[]) } else { Space::new() };
              drop(v161_8);
              let v161_11: Space = if (&(v161_9)).is_empty() { Space::new() } else {
                let v163_10: Space = routine_19(c, &v155_53_cursor.path()[(v155_53_origin + 2)..(v155_53_origin + 3)], &v155_53_cursor.path()[v155_53_origin..(v155_53_origin + 2)], &v155_53_cursor);
                compose(&(v161_9),&(v163_10))
              };
              drop(v161_9);
              let v161_12: Space = unite(&(v161_7),&(v161_11));
              join_wrapped_into(&mut v160_11_write,&((v161_12).read_zipper()),&[]);
              }
              v155_53_cursor.ascend(1);
            }
            drop(v160_11_write);
            compose(&(v158_10),&(v160_11))
          };
          drop(v158_10);
          let v158_13: Space = unite(&(v158_8),&(v158_12));
          join_wrapped_into(&mut v157_6_write,&((v158_13).read_zipper()),&[]);
          }
          v155_53_cursor.ascend(1);
        }
        drop(v157_6_write);
        compose(&(v156_5),&(v157_6))
      };
      drop(v156_5);
      let v156_8: Space = intersect(&(*CONSTANT_7),&(v156_2));
      drop(v156_2);
      let v156_9: Space = if has_head(&(v156_8)) { singleton(&[]) } else { Space::new() };
      drop(v156_8);
      let v156_11: Space = if (&(v156_9)).is_empty() { Space::new() } else {
        let mut v164_10 = Space::new();
        let mut v164_10_write = v164_10.write_zipper();
        for v164_10_byte in v155_53_cursor.child_mask().iter() {
          v155_53_cursor.descend_to_existing_byte(v164_10_byte);
          {
          let v165_2: Space = singleton(&v155_53_cursor.path()[(v155_53_origin + 1)..(v155_53_origin + 2)]);
          let v165_3: Space = intersect(&(*CONSTANT_7),&(v165_2));
          let v165_4: Space = if has_head(&(v165_3)) { singleton(&[]) } else { Space::new() };
          drop(v165_3);
          let v165_5: Space = subtract(&(*CONSTANT_0),&(v165_4));
          drop(v165_4);
          let v165_7: Space = if (&(v165_5)).is_empty() { Space::new() } else {
            let v166_6: Space = routine_18(c, &v155_53_cursor.path()[(v155_53_origin + 1)..(v155_53_origin + 2)], &v155_53_cursor.path()[v155_53_origin..(v155_53_origin + 1)], &v155_53_cursor);
            compose(&(v165_5),&(v166_6))
          };
          drop(v165_5);
          let v165_8: Space = intersect(&(*CONSTANT_7),&(v165_2));
          drop(v165_2);
          let v165_9: Space = if has_head(&(v165_8)) { singleton(&[]) } else { Space::new() };
          drop(v165_8);
          let v165_11: Space = if (&(v165_9)).is_empty() { Space::new() } else {
            let mut v167_10 = Space::new();
            let mut v167_10_write = v167_10.write_zipper();
            for v167_10_byte in v155_53_cursor.child_mask().iter() {
              v155_53_cursor.descend_to_existing_byte(v167_10_byte);
              {
              let v168_2: Space = singleton(&v155_53_cursor.path()[(v155_53_origin + 2)..(v155_53_origin + 3)]);
              let v168_3: Space = intersect(&(*CONSTANT_7),&(v168_2));
              let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
              drop(v168_3);
              let v168_5: Space = subtract(&(*CONSTANT_0),&(v168_4));
              drop(v168_4);
              let v168_7: Space = if (&(v168_5)).is_empty() { Space::new() } else {
                let v169_6: Space = routine_34(c, &v155_53_cursor.path()[(v155_53_origin + 2)..(v155_53_origin + 3)], &v155_53_cursor.path()[v155_53_origin..(v155_53_origin + 1)], &v155_53_cursor.path()[(v155_53_origin + 1)..(v155_53_origin + 2)], &v155_53_cursor);
                compose(&(v168_5),&(v169_6))
              };
              drop(v168_5);
              let v168_8: Space = intersect(&(*CONSTANT_7),&(v168_2));
              drop(v168_2);
              let v168_9: Space = if has_head(&(v168_8)) { singleton(&[]) } else { Space::new() };
              drop(v168_8);
              let v168_11: Space = if (&(v168_9)).is_empty() { Space::new() } else {
                let v170_10: Space = routine_35(c, &v155_53_cursor.path()[(v155_53_origin + 2)..(v155_53_origin + 3)], &v155_53_cursor.path()[v155_53_origin..(v155_53_origin + 1)], &v155_53_cursor.path()[(v155_53_origin + 1)..(v155_53_origin + 2)], &v155_53_cursor);
                compose(&(v168_9),&(v170_10))
              };
              drop(v168_9);
              let v168_12: Space = unite(&(v168_7),&(v168_11));
              join_wrapped_into(&mut v167_10_write,&((v168_12).read_zipper()),&[]);
              }
              v155_53_cursor.ascend(1);
            }
            drop(v167_10_write);
            compose(&(v165_9),&(v167_10))
          };
          drop(v165_9);
          let v165_12: Space = unite(&(v165_7),&(v165_11));
          join_wrapped_into(&mut v164_10_write,&((v165_12).read_zipper()),&[]);
          }
          v155_53_cursor.ascend(1);
        }
        drop(v164_10_write);
        compose(&(v156_9),&(v164_10))
      };
      drop(v156_9);
      let v156_12: Space = unite(&(v156_7),&(v156_11));
      join_wrapped_into(&mut v155_53_write,&((v156_12).read_zipper()),&[]);
      }
      v155_53_cursor.ascend(1);
    }
    drop(v155_53_cursor);
    drop(v155_53_write);
    compose(&(v130_37),&(v155_53))
  };
  let v130_55: Space = unite(&(v130_28),&(v130_54));
  let v130_57: Space = intersect(&(*CONSTANT_10),&(v130_3));
  let mut v130_64 = Space::new();
  let mut v130_64_write = v130_64.write_zipper();
  let mut v130_64_cursor = (v130_57).read_zipper();
  let v130_64_origin = v130_64_cursor.path().len();
  for v130_64_byte in v130_64_cursor.child_mask().iter() {
    v130_64_cursor.descend_to_existing_byte(v130_64_byte);
    {
    let v171_2: Space = singleton(&v130_64_cursor.path()[v130_64_origin..(v130_64_origin + 1)]);
    let v171_3: Space = intersect(&(*CONSTANT_7),&(v171_2));
    let v171_4: Space = if has_head(&(v171_3)) { singleton(&[]) } else { Space::new() };
    drop(v171_3);
    let v171_5: Space = subtract(&(*CONSTANT_0),&(v171_4));
    drop(v171_4);
    let v171_7: Space = if (&(v171_5)).is_empty() { Space::new() } else {
      let mut v172_6 = Space::new();
      let mut v172_6_write = v172_6.write_zipper();
      for v172_6_byte in v130_64_cursor.child_mask().iter() {
        v130_64_cursor.descend_to_existing_byte(v172_6_byte);
        {
        let v173_2: Space = singleton(&v130_64_cursor.path()[(v130_64_origin + 1)..(v130_64_origin + 2)]);
        let v173_3: Space = intersect(&(*CONSTANT_7),&(v173_2));
        let v173_4: Space = if has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
        drop(v173_3);
        let v173_5: Space = subtract(&(*CONSTANT_0),&(v173_4));
        drop(v173_4);
        let v173_8: Space = if (&(v173_5)).is_empty() { Space::new() } else {
          let v174_7: Space = routine_20(c, &v130_64_cursor.path()[v130_64_origin..(v130_64_origin + 2)], &v130_64_cursor);
          compose(&(v173_5),&(v174_7))
        };
        drop(v173_5);
        let v173_9: Space = intersect(&(*CONSTANT_7),&(v173_2));
        drop(v173_2);
        let v173_10: Space = if has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
        drop(v173_9);
        let v173_11: Space = compose(&(v173_10),&v130_64_cursor);
        drop(v173_10);
        let v173_12: Space = unite(&(v173_8),&(v173_11));
        drop(v173_11);
        join_wrapped_into(&mut v172_6_write,&((v173_12).read_zipper()),&[]);
        }
        v130_64_cursor.ascend(1);
      }
      drop(v172_6_write);
      compose(&(v171_5),&(v172_6))
    };
    drop(v171_5);
    let v171_8: Space = intersect(&(*CONSTANT_7),&(v171_2));
    drop(v171_2);
    let v171_9: Space = if has_head(&(v171_8)) { singleton(&[]) } else { Space::new() };
    drop(v171_8);
    let v171_10: Space = compose(&(v171_9),&v130_64_cursor);
    drop(v171_9);
    let v171_11: Space = unite(&(v171_7),&(v171_10));
    drop(v171_10);
    join_wrapped_into(&mut v130_64_write,&((v171_11).read_zipper()),&[]);
    }
    v130_64_cursor.ascend(1);
  }
  drop(v130_64_cursor);
  drop(v130_64_write);
  drop(v130_57);
  let v130_81: Space = if (&(v130_64)).is_empty() { Space::new() } else {
    let mut v175_80 = Space::new();
    let mut v175_80_write = v175_80.write_zipper();
    let mut v175_80_cursor = (*capture_1).read_zipper();
    let v175_80_origin = v175_80_cursor.path().len();
    for v175_80_byte in v175_80_cursor.child_mask().iter() {
      v175_80_cursor.descend_to_existing_byte(v175_80_byte);
      {
      let v176_2: Space = singleton(&v175_80_cursor.path()[v175_80_origin..(v175_80_origin + 1)]);
      let v176_3: Space = intersect(&(*CONSTANT_7),&(v176_2));
      let v176_4: Space = if has_head(&(v176_3)) { singleton(&[]) } else { Space::new() };
      drop(v176_3);
      let v176_5: Space = subtract(&(*CONSTANT_0),&(v176_4));
      drop(v176_4);
      let v176_7: Space = if (&(v176_5)).is_empty() { Space::new() } else {
        let mut v177_6 = Space::new();
        let mut v177_6_write = v177_6.write_zipper();
        for v177_6_byte in v175_80_cursor.child_mask().iter() {
          v175_80_cursor.descend_to_existing_byte(v177_6_byte);
          {
          let v178_2: Space = singleton(&v175_80_cursor.path()[(v175_80_origin + 1)..(v175_80_origin + 2)]);
          let v178_3: Space = intersect(&(*CONSTANT_7),&(v178_2));
          let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
          drop(v178_3);
          let v178_5: Space = subtract(&(*CONSTANT_0),&(v178_4));
          drop(v178_4);
          let v178_8: Space = if (&(v178_5)).is_empty() { Space::new() } else {
            let v179_7: Space = routine_21(c, &v175_80_cursor.path()[v175_80_origin..(v175_80_origin + 2)], &v175_80_cursor);
            compose(&(v178_5),&(v179_7))
          };
          drop(v178_5);
          let v178_9: Space = intersect(&(*CONSTANT_7),&(v178_2));
          drop(v178_2);
          let v178_10: Space = if has_head(&(v178_9)) { singleton(&[]) } else { Space::new() };
          drop(v178_9);
          let v178_12: Space = if (&(v178_10)).is_empty() { Space::new() } else {
            let mut v180_11 = Space::new();
            let mut v180_11_write = v180_11.write_zipper();
            for v180_11_byte in v175_80_cursor.child_mask().iter() {
              v175_80_cursor.descend_to_existing_byte(v180_11_byte);
              {
              let v181_2: Space = singleton(&v175_80_cursor.path()[(v175_80_origin + 2)..(v175_80_origin + 3)]);
              let v181_3: Space = intersect(&(*CONSTANT_7),&(v181_2));
              let v181_4: Space = if has_head(&(v181_3)) { singleton(&[]) } else { Space::new() };
              drop(v181_3);
              let v181_5: Space = subtract(&(*CONSTANT_0),&(v181_4));
              drop(v181_4);
              let v181_7: Space = if (&(v181_5)).is_empty() { Space::new() } else {
                let v182_6: Space = routine_22(c, &v175_80_cursor.path()[(v175_80_origin + 2)..(v175_80_origin + 3)], &v175_80_cursor.path()[v175_80_origin..(v175_80_origin + 2)], &v175_80_cursor);
                compose(&(v181_5),&(v182_6))
              };
              drop(v181_5);
              let v181_8: Space = intersect(&(*CONSTANT_7),&(v181_2));
              drop(v181_2);
              let v181_9: Space = if has_head(&(v181_8)) { singleton(&[]) } else { Space::new() };
              drop(v181_8);
              let v181_11: Space = if (&(v181_9)).is_empty() { Space::new() } else {
                let v183_10: Space = routine_23(c, &v175_80_cursor.path()[(v175_80_origin + 2)..(v175_80_origin + 3)], &v175_80_cursor.path()[v175_80_origin..(v175_80_origin + 2)], &v175_80_cursor);
                compose(&(v181_9),&(v183_10))
              };
              drop(v181_9);
              let v181_12: Space = unite(&(v181_7),&(v181_11));
              join_wrapped_into(&mut v180_11_write,&((v181_12).read_zipper()),&[]);
              }
              v175_80_cursor.ascend(1);
            }
            drop(v180_11_write);
            compose(&(v178_10),&(v180_11))
          };
          drop(v178_10);
          let v178_13: Space = unite(&(v178_8),&(v178_12));
          join_wrapped_into(&mut v177_6_write,&((v178_13).read_zipper()),&[]);
          }
          v175_80_cursor.ascend(1);
        }
        drop(v177_6_write);
        compose(&(v176_5),&(v177_6))
      };
      drop(v176_5);
      let v176_8: Space = intersect(&(*CONSTANT_7),&(v176_2));
      drop(v176_2);
      let v176_9: Space = if has_head(&(v176_8)) { singleton(&[]) } else { Space::new() };
      drop(v176_8);
      let v176_11: Space = if (&(v176_9)).is_empty() { Space::new() } else {
        let mut v184_10 = Space::new();
        let mut v184_10_write = v184_10.write_zipper();
        for v184_10_byte in v175_80_cursor.child_mask().iter() {
          v175_80_cursor.descend_to_existing_byte(v184_10_byte);
          {
          let v185_2: Space = singleton(&v175_80_cursor.path()[(v175_80_origin + 1)..(v175_80_origin + 2)]);
          let v185_3: Space = intersect(&(*CONSTANT_7),&(v185_2));
          let v185_4: Space = if has_head(&(v185_3)) { singleton(&[]) } else { Space::new() };
          drop(v185_3);
          let v185_5: Space = subtract(&(*CONSTANT_0),&(v185_4));
          drop(v185_4);
          let v185_7: Space = if (&(v185_5)).is_empty() { Space::new() } else {
            let v186_6: Space = routine_22(c, &v175_80_cursor.path()[(v175_80_origin + 1)..(v175_80_origin + 2)], &v175_80_cursor.path()[v175_80_origin..(v175_80_origin + 1)], &v175_80_cursor);
            compose(&(v185_5),&(v186_6))
          };
          drop(v185_5);
          let v185_8: Space = intersect(&(*CONSTANT_7),&(v185_2));
          drop(v185_2);
          let v185_9: Space = if has_head(&(v185_8)) { singleton(&[]) } else { Space::new() };
          drop(v185_8);
          let v185_11: Space = if (&(v185_9)).is_empty() { Space::new() } else {
            let mut v187_10 = Space::new();
            let mut v187_10_write = v187_10.write_zipper();
            for v187_10_byte in v175_80_cursor.child_mask().iter() {
              v175_80_cursor.descend_to_existing_byte(v187_10_byte);
              {
              let v188_2: Space = singleton(&v175_80_cursor.path()[(v175_80_origin + 2)..(v175_80_origin + 3)]);
              let v188_3: Space = intersect(&(*CONSTANT_7),&(v188_2));
              let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
              drop(v188_3);
              let v188_5: Space = subtract(&(*CONSTANT_0),&(v188_4));
              drop(v188_4);
              let v188_7: Space = if (&(v188_5)).is_empty() { Space::new() } else {
                let v189_6: Space = routine_36(c, &v175_80_cursor.path()[(v175_80_origin + 2)..(v175_80_origin + 3)], &v175_80_cursor.path()[v175_80_origin..(v175_80_origin + 1)], &v175_80_cursor.path()[(v175_80_origin + 1)..(v175_80_origin + 2)], &v175_80_cursor);
                compose(&(v188_5),&(v189_6))
              };
              drop(v188_5);
              let v188_8: Space = intersect(&(*CONSTANT_7),&(v188_2));
              drop(v188_2);
              let v188_9: Space = if has_head(&(v188_8)) { singleton(&[]) } else { Space::new() };
              drop(v188_8);
              let v188_11: Space = if (&(v188_9)).is_empty() { Space::new() } else {
                let v190_10: Space = routine_37(c, &v175_80_cursor.path()[(v175_80_origin + 2)..(v175_80_origin + 3)], &v175_80_cursor.path()[v175_80_origin..(v175_80_origin + 1)], &v175_80_cursor.path()[(v175_80_origin + 1)..(v175_80_origin + 2)], &v175_80_cursor);
                compose(&(v188_9),&(v190_10))
              };
              drop(v188_9);
              let v188_12: Space = unite(&(v188_7),&(v188_11));
              join_wrapped_into(&mut v187_10_write,&((v188_12).read_zipper()),&[]);
              }
              v175_80_cursor.ascend(1);
            }
            drop(v187_10_write);
            compose(&(v185_9),&(v187_10))
          };
          drop(v185_9);
          let v185_12: Space = unite(&(v185_7),&(v185_11));
          join_wrapped_into(&mut v184_10_write,&((v185_12).read_zipper()),&[]);
          }
          v175_80_cursor.ascend(1);
        }
        drop(v184_10_write);
        compose(&(v176_9),&(v184_10))
      };
      drop(v176_9);
      let v176_12: Space = unite(&(v176_7),&(v176_11));
      join_wrapped_into(&mut v175_80_write,&((v176_12).read_zipper()),&[]);
      }
      v175_80_cursor.ascend(1);
    }
    drop(v175_80_cursor);
    drop(v175_80_write);
    compose(&(v130_64),&(v175_80))
  };

((v130_11).clone(),(v130_28).clone(),(v130_3).clone(),(v130_37).clone(),(v130_54).clone(),(v130_55).clone(),(v130_64).clone(),(v130_81).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let v0_18: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v1_17: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
      let v2_4: Space = routine_1(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
      let v2_7: Space = routine_1(c, &(*CONSTANT_3), &((*CONSTANT_2).read_zipper()));
      let v2_8: Space = unite(&(v2_4),&(v2_7));
      let v2_11: Space = routine_1(c, &(*CONSTANT_4), &((*CONSTANT_5).read_zipper()));
      let v2_12: Space = unite(&(v2_8),&(v2_11));
      let v2_15: Space = routine_1(c, &(*CONSTANT_6), &((*CONSTANT_5).read_zipper()));
      let v2_16: Space = unite(&(v2_12),&(v2_15));
      compose(&(*CONSTANT_0),&(v2_16))
    };
    compose(&(*CONSTANT_0),&(v1_17))
  };
  (v0_18).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v3_11 = Space::new();
  let mut v3_11_write = v3_11.write_zipper();
  let mut v3_11_cursor = (*s0).read_zipper();
  let v3_11_origin = v3_11_cursor.path().len();
  for v3_11_byte in v3_11_cursor.child_mask().iter() {
    v3_11_cursor.descend_to_existing_byte(v3_11_byte);
    {
    let v4_2: Space = singleton(&v3_11_cursor.path()[v3_11_origin..(v3_11_origin + 1)]);
    let v4_3: Space = intersect(&(*CONSTANT_7),&(v4_2));
    let v4_4: Space = if has_head(&(v4_3)) { singleton(&[]) } else { Space::new() };
    drop(v4_3);
    let v4_5: Space = subtract(&(*CONSTANT_0),&(v4_4));
    drop(v4_4);
    let v4_8: Space = if (&(v4_5)).is_empty() { Space::new() } else {
      let v5_6: Path = concat_path(&(*p0),&v3_11_cursor.path()[v3_11_origin..(v3_11_origin + 1)]);
      let v5_7: Space = routine_1(c, &(v5_6), &v3_11_cursor);
      compose(&(v4_5),&(v5_7))
    };
    drop(v4_5);
    let v4_9: Space = intersect(&(*CONSTANT_7),&(v4_2));
    drop(v4_2);
    let v4_10: Space = if has_head(&(v4_9)) { singleton(&[]) } else { Space::new() };
    drop(v4_9);
    let v4_12: Space = if (&(v4_10)).is_empty() { Space::new() } else {
      let v6_6: Path = concat_path(&(*p0),&v3_11_cursor.path()[v3_11_origin..(v3_11_origin + 1)]);
      let mut v6_11 = Space::new();
      let mut v6_11_write = v6_11.write_zipper();
      for v6_11_byte in v3_11_cursor.child_mask().iter() {
        v3_11_cursor.descend_to_existing_byte(v6_11_byte);
        {
        let v7_2: Space = singleton(&v3_11_cursor.path()[(v3_11_origin + 1)..(v3_11_origin + 2)]);
        let v7_3: Space = intersect(&(*CONSTANT_7),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_7: Space = if (&(v7_5)).is_empty() { Space::new() } else {
          let v8_6: Space = routine_2(c, &v3_11_cursor.path()[(v3_11_origin + 1)..(v3_11_origin + 2)], &(v6_6), &v3_11_cursor);
          compose(&(v7_5),&(v8_6))
        };
        drop(v7_5);
        let v7_8: Space = intersect(&(*CONSTANT_7),&(v7_2));
        drop(v7_2);
        let v7_9: Space = if has_head(&(v7_8)) { singleton(&[]) } else { Space::new() };
        drop(v7_8);
        let v7_11: Space = if (&(v7_9)).is_empty() { Space::new() } else {
          let mut v9_10 = Space::new();
          let mut v9_10_write = v9_10.write_zipper();
          for v9_10_byte in v3_11_cursor.child_mask().iter() {
            v3_11_cursor.descend_to_existing_byte(v9_10_byte);
            {
            let v10_2: Space = singleton(&v3_11_cursor.path()[(v3_11_origin + 2)..(v3_11_origin + 3)]);
            let v10_3: Space = intersect(&(*CONSTANT_7),&(v10_2));
            let v10_4: Space = if has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
            drop(v10_3);
            let v10_5: Space = subtract(&(*CONSTANT_0),&(v10_4));
            drop(v10_4);
            let v10_7: Space = if (&(v10_5)).is_empty() { Space::new() } else {
              let v11_6: Space = routine_3(c, &v3_11_cursor.path()[(v3_11_origin + 2)..(v3_11_origin + 3)], &(v6_6), &v3_11_cursor.path()[(v3_11_origin + 1)..(v3_11_origin + 2)], &v3_11_cursor);
              compose(&(v10_5),&(v11_6))
            };
            drop(v10_5);
            let v10_8: Space = intersect(&(*CONSTANT_7),&(v10_2));
            drop(v10_2);
            let v10_9: Space = if has_head(&(v10_8)) { singleton(&[]) } else { Space::new() };
            drop(v10_8);
            let v10_11: Space = if (&(v10_9)).is_empty() { Space::new() } else {
              let v12_10: Space = routine_4(c, &v3_11_cursor.path()[(v3_11_origin + 2)..(v3_11_origin + 3)], &(v6_6), &v3_11_cursor.path()[(v3_11_origin + 1)..(v3_11_origin + 2)], &v3_11_cursor);
              compose(&(v10_9),&(v12_10))
            };
            drop(v10_9);
            let v10_12: Space = unite(&(v10_7),&(v10_11));
            join_wrapped_into(&mut v9_10_write,&((v10_12).read_zipper()),&[]);
            }
            v3_11_cursor.ascend(1);
          }
          drop(v9_10_write);
          compose(&(v7_9),&(v9_10))
        };
        drop(v7_9);
        let v7_12: Space = unite(&(v7_7),&(v7_11));
        join_wrapped_into(&mut v6_11_write,&((v7_12).read_zipper()),&[]);
        }
        v3_11_cursor.ascend(1);
      }
      drop(v6_11_write);
      drop(v6_6);
      compose(&(v4_10),&(v6_11))
    };
    drop(v4_10);
    let v4_13: Space = unite(&(v4_8),&(v4_12));
    join_wrapped_into(&mut v3_11_write,&((v4_13).read_zipper()),&[]);
    }
    v3_11_cursor.ascend(1);
  }
  drop(v3_11_cursor);
  drop(v3_11_write);
  (v3_11).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v13_12 = Space::new();
  let mut v13_12_write = v13_12.write_zipper();
  let mut v13_12_cursor = (*s0).read_zipper();
  let v13_12_origin = v13_12_cursor.path().len();
  for v13_12_byte in v13_12_cursor.child_mask().iter() {
    v13_12_cursor.descend_to_existing_byte(v13_12_byte);
    {
    let v14_2: Space = singleton(&v13_12_cursor.path()[v13_12_origin..(v13_12_origin + 1)]);
    let v14_3: Space = intersect(&(*CONSTANT_7),&(v14_2));
    let v14_4: Space = if has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
    drop(v14_3);
    let v14_5: Space = subtract(&(*CONSTANT_0),&(v14_4));
    drop(v14_4);
    let v14_8: Space = if (&(v14_5)).is_empty() { Space::new() } else {
      let v15_6: Path = concat_path(&(*p0),&v13_12_cursor.path()[v13_12_origin..(v13_12_origin + 1)]);
      let v15_7: Space = routine_2(c, &(v15_6), &(*p1), &v13_12_cursor);
      compose(&(v14_5),&(v15_7))
    };
    drop(v14_5);
    let v14_9: Space = intersect(&(*CONSTANT_7),&(v14_2));
    drop(v14_2);
    let v14_10: Space = if has_head(&(v14_9)) { singleton(&[]) } else { Space::new() };
    drop(v14_9);
    let v14_12: Space = if (&(v14_10)).is_empty() { Space::new() } else {
      let v16_6: Path = concat_path(&(*p0),&v13_12_cursor.path()[v13_12_origin..(v13_12_origin + 1)]);
      let mut v16_11 = Space::new();
      let mut v16_11_write = v16_11.write_zipper();
      for v16_11_byte in v13_12_cursor.child_mask().iter() {
        v13_12_cursor.descend_to_existing_byte(v16_11_byte);
        {
        let v17_2: Space = singleton(&v13_12_cursor.path()[(v13_12_origin + 1)..(v13_12_origin + 2)]);
        let v17_3: Space = intersect(&(*CONSTANT_7),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_0),&(v17_4));
        drop(v17_4);
        let v17_7: Space = if (&(v17_5)).is_empty() { Space::new() } else {
          let v18_6: Space = routine_3(c, &v13_12_cursor.path()[(v13_12_origin + 1)..(v13_12_origin + 2)], &(*p1), &(v16_6), &v13_12_cursor);
          compose(&(v17_5),&(v18_6))
        };
        drop(v17_5);
        let v17_8: Space = intersect(&(*CONSTANT_7),&(v17_2));
        drop(v17_2);
        let v17_9: Space = if has_head(&(v17_8)) { singleton(&[]) } else { Space::new() };
        drop(v17_8);
        let v17_11: Space = if (&(v17_9)).is_empty() { Space::new() } else {
          let mut v19_10 = Space::new();
          let mut v19_10_write = v19_10.write_zipper();
          for v19_10_byte in v13_12_cursor.child_mask().iter() {
            v13_12_cursor.descend_to_existing_byte(v19_10_byte);
            {
            let v20_2: Space = singleton(&v13_12_cursor.path()[(v13_12_origin + 2)..(v13_12_origin + 3)]);
            let v20_3: Space = intersect(&(*CONSTANT_7),&(v20_2));
            let v20_4: Space = if has_head(&(v20_3)) { singleton(&[]) } else { Space::new() };
            drop(v20_3);
            let v20_5: Space = subtract(&(*CONSTANT_0),&(v20_4));
            drop(v20_4);
            let v20_7: Space = if (&(v20_5)).is_empty() { Space::new() } else {
              let v21_6: Space = routine_5(c, &v13_12_cursor.path()[(v13_12_origin + 2)..(v13_12_origin + 3)], &(*p1), &(v16_6), &v13_12_cursor.path()[(v13_12_origin + 1)..(v13_12_origin + 2)], &v13_12_cursor);
              compose(&(v20_5),&(v21_6))
            };
            drop(v20_5);
            let v20_8: Space = intersect(&(*CONSTANT_7),&(v20_2));
            drop(v20_2);
            let v20_9: Space = if has_head(&(v20_8)) { singleton(&[]) } else { Space::new() };
            drop(v20_8);
            let v20_11: Space = if (&(v20_9)).is_empty() { Space::new() } else {
              let v22_10: Space = routine_6(c, &v13_12_cursor.path()[(v13_12_origin + 2)..(v13_12_origin + 3)], &(*p1), &(v16_6), &v13_12_cursor.path()[(v13_12_origin + 1)..(v13_12_origin + 2)], &v13_12_cursor);
              compose(&(v20_9),&(v22_10))
            };
            drop(v20_9);
            let v20_12: Space = unite(&(v20_7),&(v20_11));
            join_wrapped_into(&mut v19_10_write,&((v20_12).read_zipper()),&[]);
            }
            v13_12_cursor.ascend(1);
          }
          drop(v19_10_write);
          compose(&(v17_9),&(v19_10))
        };
        drop(v17_9);
        let v17_12: Space = unite(&(v17_7),&(v17_11));
        join_wrapped_into(&mut v16_11_write,&((v17_12).read_zipper()),&[]);
        }
        v13_12_cursor.ascend(1);
      }
      drop(v16_11_write);
      drop(v16_6);
      compose(&(v14_10),&(v16_11))
    };
    drop(v14_10);
    let v14_13: Space = unite(&(v14_8),&(v14_12));
    join_wrapped_into(&mut v13_12_write,&((v14_13).read_zipper()),&[]);
    }
    v13_12_cursor.ascend(1);
  }
  drop(v13_12_cursor);
  drop(v13_12_write);
  (v13_12).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v23_16 = Space::new();
  let mut v23_16_write = v23_16.write_zipper();
  let mut v23_16_cursor = (*s0).read_zipper();
  let v23_16_origin = v23_16_cursor.path().len();
  for v23_16_byte in v23_16_cursor.child_mask().iter() {
    v23_16_cursor.descend_to_existing_byte(v23_16_byte);
    {
    let v24_2: Space = singleton(&v23_16_cursor.path()[v23_16_origin..(v23_16_origin + 1)]);
    let v24_3: Space = intersect(&(*CONSTANT_7),&(v24_2));
    let v24_4: Space = if has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
    drop(v24_3);
    let v24_5: Space = subtract(&(*CONSTANT_0),&(v24_4));
    drop(v24_4);
    let v24_8: Space = if (&(v24_5)).is_empty() { Space::new() } else {
      let v25_6: Path = concat_path(&(*p0),&v23_16_cursor.path()[v23_16_origin..(v23_16_origin + 1)]);
      let v25_7: Space = routine_3(c, &(v25_6), &(*p1), &(*p2), &v23_16_cursor);
      compose(&(v24_5),&(v25_7))
    };
    drop(v24_5);
    let v24_9: Space = intersect(&(*CONSTANT_7),&(v24_2));
    drop(v24_2);
    let v24_10: Space = if has_head(&(v24_9)) { singleton(&[]) } else { Space::new() };
    drop(v24_9);
    let v24_13: Space = if (&(v24_10)).is_empty() { Space::new() } else {
      let v26_6: Path = concat_path(&(*p0),&v23_16_cursor.path()[v23_16_origin..(v23_16_origin + 1)]);
      let v26_11: Path = concat_path(&(*p2),&(v26_6));
      let mut v26_12 = Space::new();
      let mut v26_12_write = v26_12.write_zipper();
      for v26_12_byte in v23_16_cursor.child_mask().iter() {
        v23_16_cursor.descend_to_existing_byte(v26_12_byte);
        {
        let v27_2: Space = singleton(&v23_16_cursor.path()[(v23_16_origin + 1)..(v23_16_origin + 2)]);
        let v27_3: Space = intersect(&(*CONSTANT_7),&(v27_2));
        let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
        drop(v27_3);
        let v27_5: Space = subtract(&(*CONSTANT_0),&(v27_4));
        drop(v27_4);
        let v27_7: Space = if (&(v27_5)).is_empty() { Space::new() } else {
          let v28_6: Space = routine_5(c, &v23_16_cursor.path()[(v23_16_origin + 1)..(v23_16_origin + 2)], &(*p1), &(*p2), &(v26_6), &v23_16_cursor);
          compose(&(v27_5),&(v28_6))
        };
        drop(v27_5);
        let v27_8: Space = intersect(&(*CONSTANT_7),&(v27_2));
        drop(v27_2);
        let v27_9: Space = if has_head(&(v27_8)) { singleton(&[]) } else { Space::new() };
        drop(v27_8);
        let v27_15: Space = if (&(v27_9)).is_empty() { Space::new() } else {
          let v29_10: Path = concat_path(&(v26_11),&v23_16_cursor.path()[(v23_16_origin + 1)..(v23_16_origin + 2)]);
          let v29_11: Space = singleton(&(v29_10));
          drop(v29_10);
          let v29_12: Space = routine_7(c, &(*p1), &((v29_11).read_zipper()));
          drop(v29_11);
          let mut v29_13 = Space::new();
          let mut v29_13_write = v29_13.write_zipper();
          let mut v29_13_cursor = (v29_12).read_zipper();
          let v29_13_origin = v29_13_cursor.path().len();
          for v29_13_byte in v29_13_cursor.child_mask().iter() {
            v29_13_cursor.descend_to_existing_byte(v29_13_byte);
            {
            let v30_2: Space = singleton(&v29_13_cursor.path()[v29_13_origin..(v29_13_origin + 1)]);
            let v30_3: Space = intersect(&(*CONSTANT_7),&(v30_2));
            let v30_4: Space = if has_head(&(v30_3)) { singleton(&[]) } else { Space::new() };
            drop(v30_3);
            let v30_5: Space = subtract(&(*CONSTANT_0),&(v30_4));
            drop(v30_4);
            let v30_7: Space = if (&(v30_5)).is_empty() { Space::new() } else {
              let v31_6: Space = routine_8(c, &v29_13_cursor.path()[v29_13_origin..(v29_13_origin + 1)], &(*p1), &v29_13_cursor);
              compose(&(v30_5),&(v31_6))
            };
            drop(v30_5);
            let v30_8: Space = intersect(&(*CONSTANT_7),&(v30_2));
            drop(v30_2);
            let v30_9: Space = if has_head(&(v30_8)) { singleton(&[]) } else { Space::new() };
            drop(v30_8);
            let v30_11: Space = if (&(v30_9)).is_empty() { Space::new() } else {
              let v32_10: Space = routine_9(c, &v29_13_cursor.path()[v29_13_origin..(v29_13_origin + 1)], &(*p1), &v29_13_cursor);
              compose(&(v30_9),&(v32_10))
            };
            drop(v30_9);
            let v30_12: Space = unite(&(v30_7),&(v30_11));
            join_wrapped_into(&mut v29_13_write,&((v30_12).read_zipper()),&[]);
            }
            v29_13_cursor.ascend(1);
          }
          drop(v29_13_cursor);
          drop(v29_13_write);
          let mut v29_14 = Space::new();
          let mut v29_14_write = v29_14.write_zipper();
          let mut v29_14_cursor = (v29_13).read_zipper();
          let v29_14_origin = v29_14_cursor.path().len();
          for v29_14_byte in v29_14_cursor.child_mask().iter() {
            v29_14_cursor.descend_to_existing_byte(v29_14_byte);
            {
            let v33_2: Space = singleton(&v29_14_cursor.path()[v29_14_origin..(v29_14_origin + 1)]);
            let v33_3: Space = intersect(&(*CONSTANT_7),&(v33_2));
            let v33_4: Space = if has_head(&(v33_3)) { singleton(&[]) } else { Space::new() };
            drop(v33_3);
            let v33_5: Space = subtract(&(*CONSTANT_0),&(v33_4));
            drop(v33_4);
            let v33_7: Space = if (&(v33_5)).is_empty() { Space::new() } else {
              let v34_6: Space = routine_10(c, &v29_14_cursor.path()[v29_14_origin..(v29_14_origin + 1)], &(*p1), &v29_14_cursor);
              compose(&(v33_5),&(v34_6))
            };
            drop(v33_5);
            let v33_8: Space = intersect(&(*CONSTANT_7),&(v33_2));
            drop(v33_2);
            let v33_9: Space = if has_head(&(v33_8)) { singleton(&[]) } else { Space::new() };
            drop(v33_8);
            let v33_11: Space = if (&(v33_9)).is_empty() { Space::new() } else {
              let v35_10: Space = routine_11(c, &v29_14_cursor.path()[v29_14_origin..(v29_14_origin + 1)], &(*p1), &v29_14_cursor);
              compose(&(v33_9),&(v35_10))
            };
            drop(v33_9);
            let v33_12: Space = unite(&(v33_7),&(v33_11));
            join_wrapped_into(&mut v29_14_write,&((v33_12).read_zipper()),&[]);
            }
            v29_14_cursor.ascend(1);
          }
          drop(v29_14_cursor);
          drop(v29_14_write);
          compose(&(v27_9),&(v29_14))
        };
        drop(v27_9);
        let v27_16: Space = unite(&(v27_7),&(v27_15));
        join_wrapped_into(&mut v26_12_write,&((v27_16).read_zipper()),&[]);
        }
        v23_16_cursor.ascend(1);
      }
      drop(v26_12_write);
      drop(v26_6);
      drop(v26_11);
      compose(&(v24_10),&(v26_12))
    };
    drop(v24_10);
    let v24_14: Space = unite(&(v24_8),&(v24_13));
    join_wrapped_into(&mut v23_16_write,&((v24_14).read_zipper()),&[]);
    }
    v23_16_cursor.ascend(1);
  }
  drop(v23_16_cursor);
  drop(v23_16_write);
  (v23_16).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v36_7: Path = concat_path(&(*p2),&(*p0));
  let mut v36_23 = Space::new();
  let mut v36_23_write = v36_23.write_zipper();
  let mut v36_23_cursor = (*s0).read_zipper();
  let v36_23_origin = v36_23_cursor.path().len();
  for v36_23_byte in v36_23_cursor.child_mask().iter() {
    v36_23_cursor.descend_to_existing_byte(v36_23_byte);
    {
    let v37_2: Space = singleton(&v36_23_cursor.path()[v36_23_origin..(v36_23_origin + 1)]);
    let v37_3: Space = intersect(&(*CONSTANT_7),&(v37_2));
    let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
    drop(v37_3);
    let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
    drop(v37_4);
    let v37_7: Space = if (&(v37_5)).is_empty() { Space::new() } else {
      let mut v38_6 = Space::new();
      let mut v38_6_write = v38_6.write_zipper();
      for v38_6_byte in v36_23_cursor.child_mask().iter() {
        v36_23_cursor.descend_to_existing_byte(v38_6_byte);
        {
        let v39_2: Space = singleton(&v36_23_cursor.path()[(v36_23_origin + 1)..(v36_23_origin + 2)]);
        let v39_3: Space = intersect(&(*CONSTANT_7),&(v39_2));
        let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_8: Space = if (&(v39_5)).is_empty() { Space::new() } else {
          let v40_7: Space = routine_5(c, &v36_23_cursor.path()[v36_23_origin..(v36_23_origin + 2)], &(*p1), &(*p2), &(*p0), &v36_23_cursor);
          compose(&(v39_5),&(v40_7))
        };
        drop(v39_5);
        let v39_9: Space = intersect(&(*CONSTANT_7),&(v39_2));
        drop(v39_2);
        let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
        drop(v39_9);
        let v39_16: Space = if (&(v39_10)).is_empty() { Space::new() } else {
          let v41_11: Path = concat_path(&(v36_7),&v36_23_cursor.path()[v36_23_origin..(v36_23_origin + 2)]);
          let v41_12: Space = singleton(&(v41_11));
          drop(v41_11);
          let v41_13: Space = routine_7(c, &(*p1), &((v41_12).read_zipper()));
          drop(v41_12);
          let mut v41_14 = Space::new();
          let mut v41_14_write = v41_14.write_zipper();
          let mut v41_14_cursor = (v41_13).read_zipper();
          let v41_14_origin = v41_14_cursor.path().len();
          for v41_14_byte in v41_14_cursor.child_mask().iter() {
            v41_14_cursor.descend_to_existing_byte(v41_14_byte);
            {
            let v42_2: Space = singleton(&v41_14_cursor.path()[v41_14_origin..(v41_14_origin + 1)]);
            let v42_3: Space = intersect(&(*CONSTANT_7),&(v42_2));
            let v42_4: Space = if has_head(&(v42_3)) { singleton(&[]) } else { Space::new() };
            drop(v42_3);
            let v42_5: Space = subtract(&(*CONSTANT_0),&(v42_4));
            drop(v42_4);
            let v42_7: Space = if (&(v42_5)).is_empty() { Space::new() } else {
              let v43_6: Space = routine_8(c, &v41_14_cursor.path()[v41_14_origin..(v41_14_origin + 1)], &(*p1), &v41_14_cursor);
              compose(&(v42_5),&(v43_6))
            };
            drop(v42_5);
            let v42_8: Space = intersect(&(*CONSTANT_7),&(v42_2));
            drop(v42_2);
            let v42_9: Space = if has_head(&(v42_8)) { singleton(&[]) } else { Space::new() };
            drop(v42_8);
            let v42_11: Space = if (&(v42_9)).is_empty() { Space::new() } else {
              let v44_10: Space = routine_9(c, &v41_14_cursor.path()[v41_14_origin..(v41_14_origin + 1)], &(*p1), &v41_14_cursor);
              compose(&(v42_9),&(v44_10))
            };
            drop(v42_9);
            let v42_12: Space = unite(&(v42_7),&(v42_11));
            join_wrapped_into(&mut v41_14_write,&((v42_12).read_zipper()),&[]);
            }
            v41_14_cursor.ascend(1);
          }
          drop(v41_14_cursor);
          drop(v41_14_write);
          let mut v41_15 = Space::new();
          let mut v41_15_write = v41_15.write_zipper();
          let mut v41_15_cursor = (v41_14).read_zipper();
          let v41_15_origin = v41_15_cursor.path().len();
          for v41_15_byte in v41_15_cursor.child_mask().iter() {
            v41_15_cursor.descend_to_existing_byte(v41_15_byte);
            {
            let v45_2: Space = singleton(&v41_15_cursor.path()[v41_15_origin..(v41_15_origin + 1)]);
            let v45_3: Space = intersect(&(*CONSTANT_7),&(v45_2));
            let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
            drop(v45_3);
            let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
            drop(v45_4);
            let v45_7: Space = if (&(v45_5)).is_empty() { Space::new() } else {
              let v46_6: Space = routine_10(c, &v41_15_cursor.path()[v41_15_origin..(v41_15_origin + 1)], &(*p1), &v41_15_cursor);
              compose(&(v45_5),&(v46_6))
            };
            drop(v45_5);
            let v45_8: Space = intersect(&(*CONSTANT_7),&(v45_2));
            drop(v45_2);
            let v45_9: Space = if has_head(&(v45_8)) { singleton(&[]) } else { Space::new() };
            drop(v45_8);
            let v45_11: Space = if (&(v45_9)).is_empty() { Space::new() } else {
              let v47_10: Space = routine_11(c, &v41_15_cursor.path()[v41_15_origin..(v41_15_origin + 1)], &(*p1), &v41_15_cursor);
              compose(&(v45_9),&(v47_10))
            };
            drop(v45_9);
            let v45_12: Space = unite(&(v45_7),&(v45_11));
            join_wrapped_into(&mut v41_15_write,&((v45_12).read_zipper()),&[]);
            }
            v41_15_cursor.ascend(1);
          }
          drop(v41_15_cursor);
          drop(v41_15_write);
          compose(&(v39_10),&(v41_15))
        };
        drop(v39_10);
        let v39_17: Space = unite(&(v39_8),&(v39_16));
        join_wrapped_into(&mut v38_6_write,&((v39_17).read_zipper()),&[]);
        }
        v36_23_cursor.ascend(1);
      }
      drop(v38_6_write);
      compose(&(v37_5),&(v38_6))
    };
    drop(v37_5);
    let v37_8: Space = intersect(&(*CONSTANT_7),&(v37_2));
    drop(v37_2);
    let v37_9: Space = if has_head(&(v37_8)) { singleton(&[]) } else { Space::new() };
    drop(v37_8);
    let v37_15: Space = if (&(v37_9)).is_empty() { Space::new() } else {
      let v48_10: Path = concat_path(&(v36_7),&v36_23_cursor.path()[v36_23_origin..(v36_23_origin + 1)]);
      let v48_11: Space = singleton(&(v48_10));
      drop(v48_10);
      let v48_12: Space = routine_7(c, &(*p1), &((v48_11).read_zipper()));
      drop(v48_11);
      let mut v48_13 = Space::new();
      let mut v48_13_write = v48_13.write_zipper();
      let mut v48_13_cursor = (v48_12).read_zipper();
      let v48_13_origin = v48_13_cursor.path().len();
      for v48_13_byte in v48_13_cursor.child_mask().iter() {
        v48_13_cursor.descend_to_existing_byte(v48_13_byte);
        {
        let v49_2: Space = singleton(&v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 1)]);
        let v49_3: Space = intersect(&(*CONSTANT_7),&(v49_2));
        let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
        drop(v49_3);
        let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
        drop(v49_4);
        let v49_7: Space = if (&(v49_5)).is_empty() { Space::new() } else {
          let v50_6: Space = routine_8(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 1)], &(*p1), &v48_13_cursor);
          compose(&(v49_5),&(v50_6))
        };
        drop(v49_5);
        let v49_8: Space = intersect(&(*CONSTANT_7),&(v49_2));
        drop(v49_2);
        let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
        drop(v49_8);
        let v49_11: Space = if (&(v49_9)).is_empty() { Space::new() } else {
          let v51_10: Space = routine_9(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 1)], &(*p1), &v48_13_cursor);
          compose(&(v49_9),&(v51_10))
        };
        drop(v49_9);
        let v49_12: Space = unite(&(v49_7),&(v49_11));
        join_wrapped_into(&mut v48_13_write,&((v49_12).read_zipper()),&[]);
        }
        v48_13_cursor.ascend(1);
      }
      drop(v48_13_cursor);
      drop(v48_13_write);
      let mut v48_14 = Space::new();
      let mut v48_14_write = v48_14.write_zipper();
      let mut v48_14_cursor = (v48_13).read_zipper();
      let v48_14_origin = v48_14_cursor.path().len();
      for v48_14_byte in v48_14_cursor.child_mask().iter() {
        v48_14_cursor.descend_to_existing_byte(v48_14_byte);
        {
        let v52_2: Space = singleton(&v48_14_cursor.path()[v48_14_origin..(v48_14_origin + 1)]);
        let v52_3: Space = intersect(&(*CONSTANT_7),&(v52_2));
        let v52_4: Space = if has_head(&(v52_3)) { singleton(&[]) } else { Space::new() };
        drop(v52_3);
        let v52_5: Space = subtract(&(*CONSTANT_0),&(v52_4));
        drop(v52_4);
        let v52_7: Space = if (&(v52_5)).is_empty() { Space::new() } else {
          let v53_6: Space = routine_10(c, &v48_14_cursor.path()[v48_14_origin..(v48_14_origin + 1)], &(*p1), &v48_14_cursor);
          compose(&(v52_5),&(v53_6))
        };
        drop(v52_5);
        let v52_8: Space = intersect(&(*CONSTANT_7),&(v52_2));
        drop(v52_2);
        let v52_9: Space = if has_head(&(v52_8)) { singleton(&[]) } else { Space::new() };
        drop(v52_8);
        let v52_11: Space = if (&(v52_9)).is_empty() { Space::new() } else {
          let v54_10: Space = routine_11(c, &v48_14_cursor.path()[v48_14_origin..(v48_14_origin + 1)], &(*p1), &v48_14_cursor);
          compose(&(v52_9),&(v54_10))
        };
        drop(v52_9);
        let v52_12: Space = unite(&(v52_7),&(v52_11));
        join_wrapped_into(&mut v48_14_write,&((v52_12).read_zipper()),&[]);
        }
        v48_14_cursor.ascend(1);
      }
      drop(v48_14_cursor);
      drop(v48_14_write);
      compose(&(v37_9),&(v48_14))
    };
    drop(v37_9);
    let v37_16: Space = unite(&(v37_7),&(v37_15));
    join_wrapped_into(&mut v36_23_write,&((v37_16).read_zipper()),&[]);
    }
    v36_23_cursor.ascend(1);
  }
  drop(v36_23_cursor);
  drop(v36_23_write);
  drop(v36_7);
  (v36_23).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v55_8: Path = concat_path(&(*p2),&(*p3));
  let mut v55_15 = Space::new();
  let mut v55_15_write = v55_15.write_zipper();
  let mut v55_15_cursor = (*s0).read_zipper();
  let v55_15_origin = v55_15_cursor.path().len();
  for v55_15_byte in v55_15_cursor.child_mask().iter() {
    v55_15_cursor.descend_to_existing_byte(v55_15_byte);
    {
    let v56_2: Space = singleton(&v55_15_cursor.path()[v55_15_origin..(v55_15_origin + 1)]);
    let v56_3: Space = intersect(&(*CONSTANT_7),&(v56_2));
    let v56_4: Space = if has_head(&(v56_3)) { singleton(&[]) } else { Space::new() };
    drop(v56_3);
    let v56_5: Space = subtract(&(*CONSTANT_0),&(v56_4));
    drop(v56_4);
    let v56_8: Space = if (&(v56_5)).is_empty() { Space::new() } else {
      let v57_6: Path = concat_path(&(*p0),&v55_15_cursor.path()[v55_15_origin..(v55_15_origin + 1)]);
      let v57_7: Space = routine_5(c, &(v57_6), &(*p1), &(*p2), &(*p3), &v55_15_cursor);
      compose(&(v56_5),&(v57_7))
    };
    drop(v56_5);
    let v56_9: Space = intersect(&(*CONSTANT_7),&(v56_2));
    drop(v56_2);
    let v56_10: Space = if has_head(&(v56_9)) { singleton(&[]) } else { Space::new() };
    drop(v56_9);
    let v56_16: Space = if (&(v56_10)).is_empty() { Space::new() } else {
      let v58_6: Path = concat_path(&(*p0),&v55_15_cursor.path()[v55_15_origin..(v55_15_origin + 1)]);
      let v58_11: Path = concat_path(&(v55_8),&(v58_6));
      drop(v58_6);
      let v58_12: Space = singleton(&(v58_11));
      drop(v58_11);
      let v58_13: Space = routine_7(c, &(*p1), &((v58_12).read_zipper()));
      drop(v58_12);
      let mut v58_14 = Space::new();
      let mut v58_14_write = v58_14.write_zipper();
      let mut v58_14_cursor = (v58_13).read_zipper();
      let v58_14_origin = v58_14_cursor.path().len();
      for v58_14_byte in v58_14_cursor.child_mask().iter() {
        v58_14_cursor.descend_to_existing_byte(v58_14_byte);
        {
        let v59_2: Space = singleton(&v58_14_cursor.path()[v58_14_origin..(v58_14_origin + 1)]);
        let v59_3: Space = intersect(&(*CONSTANT_7),&(v59_2));
        let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
        drop(v59_3);
        let v59_5: Space = subtract(&(*CONSTANT_0),&(v59_4));
        drop(v59_4);
        let v59_7: Space = if (&(v59_5)).is_empty() { Space::new() } else {
          let v60_6: Space = routine_8(c, &v58_14_cursor.path()[v58_14_origin..(v58_14_origin + 1)], &(*p1), &v58_14_cursor);
          compose(&(v59_5),&(v60_6))
        };
        drop(v59_5);
        let v59_8: Space = intersect(&(*CONSTANT_7),&(v59_2));
        drop(v59_2);
        let v59_9: Space = if has_head(&(v59_8)) { singleton(&[]) } else { Space::new() };
        drop(v59_8);
        let v59_11: Space = if (&(v59_9)).is_empty() { Space::new() } else {
          let v61_10: Space = routine_9(c, &v58_14_cursor.path()[v58_14_origin..(v58_14_origin + 1)], &(*p1), &v58_14_cursor);
          compose(&(v59_9),&(v61_10))
        };
        drop(v59_9);
        let v59_12: Space = unite(&(v59_7),&(v59_11));
        join_wrapped_into(&mut v58_14_write,&((v59_12).read_zipper()),&[]);
        }
        v58_14_cursor.ascend(1);
      }
      drop(v58_14_cursor);
      drop(v58_14_write);
      let mut v58_15 = Space::new();
      let mut v58_15_write = v58_15.write_zipper();
      let mut v58_15_cursor = (v58_14).read_zipper();
      let v58_15_origin = v58_15_cursor.path().len();
      for v58_15_byte in v58_15_cursor.child_mask().iter() {
        v58_15_cursor.descend_to_existing_byte(v58_15_byte);
        {
        let v62_2: Space = singleton(&v58_15_cursor.path()[v58_15_origin..(v58_15_origin + 1)]);
        let v62_3: Space = intersect(&(*CONSTANT_7),&(v62_2));
        let v62_4: Space = if has_head(&(v62_3)) { singleton(&[]) } else { Space::new() };
        drop(v62_3);
        let v62_5: Space = subtract(&(*CONSTANT_0),&(v62_4));
        drop(v62_4);
        let v62_7: Space = if (&(v62_5)).is_empty() { Space::new() } else {
          let v63_6: Space = routine_10(c, &v58_15_cursor.path()[v58_15_origin..(v58_15_origin + 1)], &(*p1), &v58_15_cursor);
          compose(&(v62_5),&(v63_6))
        };
        drop(v62_5);
        let v62_8: Space = intersect(&(*CONSTANT_7),&(v62_2));
        drop(v62_2);
        let v62_9: Space = if has_head(&(v62_8)) { singleton(&[]) } else { Space::new() };
        drop(v62_8);
        let v62_11: Space = if (&(v62_9)).is_empty() { Space::new() } else {
          let v64_10: Space = routine_11(c, &v58_15_cursor.path()[v58_15_origin..(v58_15_origin + 1)], &(*p1), &v58_15_cursor);
          compose(&(v62_9),&(v64_10))
        };
        drop(v62_9);
        let v62_12: Space = unite(&(v62_7),&(v62_11));
        join_wrapped_into(&mut v58_15_write,&((v62_12).read_zipper()),&[]);
        }
        v58_15_cursor.ascend(1);
      }
      drop(v58_15_cursor);
      drop(v58_15_write);
      compose(&(v56_10),&(v58_15))
    };
    drop(v56_10);
    let v56_17: Space = unite(&(v56_8),&(v56_16));
    join_wrapped_into(&mut v55_15_write,&((v56_17).read_zipper()),&[]);
    }
    v55_15_cursor.ascend(1);
  }
  drop(v55_15_cursor);
  drop(v55_15_write);
  drop(v55_8);
  (v55_15).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let (mut v65_103,mut v65_11,mut v65_22,mut v65_28,mut v65_36,mut v65_37,mut v65_43,mut v65_51,mut v65_52,mut v65_58,mut v65_66,mut v65_67,mut v65_82,) = native_block_0(c, p0, p1, p2, p3);
  (v65_103).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let (mut v130_11,mut v130_28,mut v130_3,mut v130_37,mut v130_54,mut v130_55,mut v130_64,mut v130_81,) = native_block_1(c, p0, s0);
  let v130_82: Space = unite(&(v130_55),&(v130_81));
  let v130_84: Space = intersect(&(*CONSTANT_11),&(v130_3));
  drop(v130_3);
  let mut v130_91 = Space::new();
  let mut v130_91_write = v130_91.write_zipper();
  let mut v130_91_cursor = (v130_84).read_zipper();
  let v130_91_origin = v130_91_cursor.path().len();
  for v130_91_byte in v130_91_cursor.child_mask().iter() {
    v130_91_cursor.descend_to_existing_byte(v130_91_byte);
    {
    let v191_2: Space = singleton(&v130_91_cursor.path()[v130_91_origin..(v130_91_origin + 1)]);
    let v191_3: Space = intersect(&(*CONSTANT_7),&(v191_2));
    let v191_4: Space = if has_head(&(v191_3)) { singleton(&[]) } else { Space::new() };
    drop(v191_3);
    let v191_5: Space = subtract(&(*CONSTANT_0),&(v191_4));
    drop(v191_4);
    let v191_7: Space = if (&(v191_5)).is_empty() { Space::new() } else {
      let mut v192_6 = Space::new();
      let mut v192_6_write = v192_6.write_zipper();
      for v192_6_byte in v130_91_cursor.child_mask().iter() {
        v130_91_cursor.descend_to_existing_byte(v192_6_byte);
        {
        let v193_2: Space = singleton(&v130_91_cursor.path()[(v130_91_origin + 1)..(v130_91_origin + 2)]);
        let v193_3: Space = intersect(&(*CONSTANT_7),&(v193_2));
        let v193_4: Space = if has_head(&(v193_3)) { singleton(&[]) } else { Space::new() };
        drop(v193_3);
        let v193_5: Space = subtract(&(*CONSTANT_0),&(v193_4));
        drop(v193_4);
        let v193_8: Space = if (&(v193_5)).is_empty() { Space::new() } else {
          let v194_7: Space = routine_24(c, &v130_91_cursor.path()[v130_91_origin..(v130_91_origin + 2)], &v130_91_cursor);
          compose(&(v193_5),&(v194_7))
        };
        drop(v193_5);
        let v193_9: Space = intersect(&(*CONSTANT_7),&(v193_2));
        drop(v193_2);
        let v193_10: Space = if has_head(&(v193_9)) { singleton(&[]) } else { Space::new() };
        drop(v193_9);
        let v193_11: Space = compose(&(v193_10),&v130_91_cursor);
        drop(v193_10);
        let v193_12: Space = unite(&(v193_8),&(v193_11));
        drop(v193_11);
        join_wrapped_into(&mut v192_6_write,&((v193_12).read_zipper()),&[]);
        }
        v130_91_cursor.ascend(1);
      }
      drop(v192_6_write);
      compose(&(v191_5),&(v192_6))
    };
    drop(v191_5);
    let v191_8: Space = intersect(&(*CONSTANT_7),&(v191_2));
    drop(v191_2);
    let v191_9: Space = if has_head(&(v191_8)) { singleton(&[]) } else { Space::new() };
    drop(v191_8);
    let v191_10: Space = compose(&(v191_9),&v130_91_cursor);
    drop(v191_9);
    let v191_11: Space = unite(&(v191_7),&(v191_10));
    drop(v191_10);
    join_wrapped_into(&mut v130_91_write,&((v191_11).read_zipper()),&[]);
    }
    v130_91_cursor.ascend(1);
  }
  drop(v130_91_cursor);
  drop(v130_91_write);
  drop(v130_84);
  let v130_108: Space = if (&(v130_91)).is_empty() { Space::new() } else {
    let mut v195_107 = Space::new();
    let mut v195_107_write = v195_107.write_zipper();
    let mut v195_107_cursor = (*s0).read_zipper();
    let v195_107_origin = v195_107_cursor.path().len();
    for v195_107_byte in v195_107_cursor.child_mask().iter() {
      v195_107_cursor.descend_to_existing_byte(v195_107_byte);
      {
      let v196_2: Space = singleton(&v195_107_cursor.path()[v195_107_origin..(v195_107_origin + 1)]);
      let v196_3: Space = intersect(&(*CONSTANT_7),&(v196_2));
      let v196_4: Space = if has_head(&(v196_3)) { singleton(&[]) } else { Space::new() };
      drop(v196_3);
      let v196_5: Space = subtract(&(*CONSTANT_0),&(v196_4));
      drop(v196_4);
      let v196_7: Space = if (&(v196_5)).is_empty() { Space::new() } else {
        let mut v197_6 = Space::new();
        let mut v197_6_write = v197_6.write_zipper();
        for v197_6_byte in v195_107_cursor.child_mask().iter() {
          v195_107_cursor.descend_to_existing_byte(v197_6_byte);
          {
          let v198_2: Space = singleton(&v195_107_cursor.path()[(v195_107_origin + 1)..(v195_107_origin + 2)]);
          let v198_3: Space = intersect(&(*CONSTANT_7),&(v198_2));
          let v198_4: Space = if has_head(&(v198_3)) { singleton(&[]) } else { Space::new() };
          drop(v198_3);
          let v198_5: Space = subtract(&(*CONSTANT_0),&(v198_4));
          drop(v198_4);
          let v198_8: Space = if (&(v198_5)).is_empty() { Space::new() } else {
            let v199_7: Space = routine_25(c, &v195_107_cursor.path()[v195_107_origin..(v195_107_origin + 2)], &v195_107_cursor);
            compose(&(v198_5),&(v199_7))
          };
          drop(v198_5);
          let v198_9: Space = intersect(&(*CONSTANT_7),&(v198_2));
          drop(v198_2);
          let v198_10: Space = if has_head(&(v198_9)) { singleton(&[]) } else { Space::new() };
          drop(v198_9);
          let v198_12: Space = if (&(v198_10)).is_empty() { Space::new() } else {
            let mut v200_11 = Space::new();
            let mut v200_11_write = v200_11.write_zipper();
            for v200_11_byte in v195_107_cursor.child_mask().iter() {
              v195_107_cursor.descend_to_existing_byte(v200_11_byte);
              {
              let v201_2: Space = singleton(&v195_107_cursor.path()[(v195_107_origin + 2)..(v195_107_origin + 3)]);
              let v201_3: Space = intersect(&(*CONSTANT_7),&(v201_2));
              let v201_4: Space = if has_head(&(v201_3)) { singleton(&[]) } else { Space::new() };
              drop(v201_3);
              let v201_5: Space = subtract(&(*CONSTANT_0),&(v201_4));
              drop(v201_4);
              let v201_7: Space = if (&(v201_5)).is_empty() { Space::new() } else {
                let v202_6: Space = routine_26(c, &v195_107_cursor.path()[(v195_107_origin + 2)..(v195_107_origin + 3)], &v195_107_cursor.path()[v195_107_origin..(v195_107_origin + 2)], &v195_107_cursor);
                compose(&(v201_5),&(v202_6))
              };
              drop(v201_5);
              let v201_8: Space = intersect(&(*CONSTANT_7),&(v201_2));
              drop(v201_2);
              let v201_9: Space = if has_head(&(v201_8)) { singleton(&[]) } else { Space::new() };
              drop(v201_8);
              let v201_11: Space = if (&(v201_9)).is_empty() { Space::new() } else {
                let v203_10: Space = routine_27(c, &v195_107_cursor.path()[(v195_107_origin + 2)..(v195_107_origin + 3)], &v195_107_cursor.path()[v195_107_origin..(v195_107_origin + 2)], &v195_107_cursor);
                compose(&(v201_9),&(v203_10))
              };
              drop(v201_9);
              let v201_12: Space = unite(&(v201_7),&(v201_11));
              join_wrapped_into(&mut v200_11_write,&((v201_12).read_zipper()),&[]);
              }
              v195_107_cursor.ascend(1);
            }
            drop(v200_11_write);
            compose(&(v198_10),&(v200_11))
          };
          drop(v198_10);
          let v198_13: Space = unite(&(v198_8),&(v198_12));
          join_wrapped_into(&mut v197_6_write,&((v198_13).read_zipper()),&[]);
          }
          v195_107_cursor.ascend(1);
        }
        drop(v197_6_write);
        compose(&(v196_5),&(v197_6))
      };
      drop(v196_5);
      let v196_8: Space = intersect(&(*CONSTANT_7),&(v196_2));
      drop(v196_2);
      let v196_9: Space = if has_head(&(v196_8)) { singleton(&[]) } else { Space::new() };
      drop(v196_8);
      let v196_11: Space = if (&(v196_9)).is_empty() { Space::new() } else {
        let mut v204_10 = Space::new();
        let mut v204_10_write = v204_10.write_zipper();
        for v204_10_byte in v195_107_cursor.child_mask().iter() {
          v195_107_cursor.descend_to_existing_byte(v204_10_byte);
          {
          let v205_2: Space = singleton(&v195_107_cursor.path()[(v195_107_origin + 1)..(v195_107_origin + 2)]);
          let v205_3: Space = intersect(&(*CONSTANT_7),&(v205_2));
          let v205_4: Space = if has_head(&(v205_3)) { singleton(&[]) } else { Space::new() };
          drop(v205_3);
          let v205_5: Space = subtract(&(*CONSTANT_0),&(v205_4));
          drop(v205_4);
          let v205_7: Space = if (&(v205_5)).is_empty() { Space::new() } else {
            let v206_6: Space = routine_26(c, &v195_107_cursor.path()[(v195_107_origin + 1)..(v195_107_origin + 2)], &v195_107_cursor.path()[v195_107_origin..(v195_107_origin + 1)], &v195_107_cursor);
            compose(&(v205_5),&(v206_6))
          };
          drop(v205_5);
          let v205_8: Space = intersect(&(*CONSTANT_7),&(v205_2));
          drop(v205_2);
          let v205_9: Space = if has_head(&(v205_8)) { singleton(&[]) } else { Space::new() };
          drop(v205_8);
          let v205_11: Space = if (&(v205_9)).is_empty() { Space::new() } else {
            let mut v207_10 = Space::new();
            let mut v207_10_write = v207_10.write_zipper();
            for v207_10_byte in v195_107_cursor.child_mask().iter() {
              v195_107_cursor.descend_to_existing_byte(v207_10_byte);
              {
              let v208_2: Space = singleton(&v195_107_cursor.path()[(v195_107_origin + 2)..(v195_107_origin + 3)]);
              let v208_3: Space = intersect(&(*CONSTANT_7),&(v208_2));
              let v208_4: Space = if has_head(&(v208_3)) { singleton(&[]) } else { Space::new() };
              drop(v208_3);
              let v208_5: Space = subtract(&(*CONSTANT_0),&(v208_4));
              drop(v208_4);
              let v208_7: Space = if (&(v208_5)).is_empty() { Space::new() } else {
                let v209_6: Space = routine_38(c, &v195_107_cursor.path()[(v195_107_origin + 2)..(v195_107_origin + 3)], &v195_107_cursor.path()[v195_107_origin..(v195_107_origin + 1)], &v195_107_cursor.path()[(v195_107_origin + 1)..(v195_107_origin + 2)], &v195_107_cursor);
                compose(&(v208_5),&(v209_6))
              };
              drop(v208_5);
              let v208_8: Space = intersect(&(*CONSTANT_7),&(v208_2));
              drop(v208_2);
              let v208_9: Space = if has_head(&(v208_8)) { singleton(&[]) } else { Space::new() };
              drop(v208_8);
              let v208_11: Space = if (&(v208_9)).is_empty() { Space::new() } else {
                let v210_10: Space = routine_39(c, &v195_107_cursor.path()[(v195_107_origin + 2)..(v195_107_origin + 3)], &v195_107_cursor.path()[v195_107_origin..(v195_107_origin + 1)], &v195_107_cursor.path()[(v195_107_origin + 1)..(v195_107_origin + 2)], &v195_107_cursor);
                compose(&(v208_9),&(v210_10))
              };
              drop(v208_9);
              let v208_12: Space = unite(&(v208_7),&(v208_11));
              join_wrapped_into(&mut v207_10_write,&((v208_12).read_zipper()),&[]);
              }
              v195_107_cursor.ascend(1);
            }
            drop(v207_10_write);
            compose(&(v205_9),&(v207_10))
          };
          drop(v205_9);
          let v205_12: Space = unite(&(v205_7),&(v205_11));
          join_wrapped_into(&mut v204_10_write,&((v205_12).read_zipper()),&[]);
          }
          v195_107_cursor.ascend(1);
        }
        drop(v204_10_write);
        compose(&(v196_9),&(v204_10))
      };
      drop(v196_9);
      let v196_12: Space = unite(&(v196_7),&(v196_11));
      join_wrapped_into(&mut v195_107_write,&((v196_12).read_zipper()),&[]);
      }
      v195_107_cursor.ascend(1);
    }
    drop(v195_107_cursor);
    drop(v195_107_write);
    compose(&(v130_91),&(v195_107))
  };
  let v130_109: Space = unite(&(v130_82),&(v130_108));
  (v130_109).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v211_14 = Space::new();
  let mut v211_14_write = v211_14.write_zipper();
  let mut v211_14_cursor = (*s0).read_zipper();
  let v211_14_origin = v211_14_cursor.path().len();
  for v211_14_byte in v211_14_cursor.child_mask().iter() {
    v211_14_cursor.descend_to_existing_byte(v211_14_byte);
    {
    let v212_2: Space = singleton(&v211_14_cursor.path()[v211_14_origin..(v211_14_origin + 1)]);
    let v212_3: Space = intersect(&(*CONSTANT_7),&(v212_2));
    let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
    drop(v212_3);
    let v212_5: Space = subtract(&(*CONSTANT_0),&(v212_4));
    drop(v212_4);
    let v212_8: Space = if (&(v212_5)).is_empty() { Space::new() } else {
      let v213_6: Path = concat_path(&(*p0),&v211_14_cursor.path()[v211_14_origin..(v211_14_origin + 1)]);
      let v213_7: Space = routine_8(c, &(v213_6), &(*p1), &v211_14_cursor);
      compose(&(v212_5),&(v213_7))
    };
    drop(v212_5);
    let v212_9: Space = intersect(&(*CONSTANT_7),&(v212_2));
    drop(v212_2);
    let v212_10: Space = if has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
    drop(v212_9);
    let v212_17: Space = if (&(v212_10)).is_empty() { Space::new() } else {
      let v214_6: Path = concat_path(&(*p0),&v211_14_cursor.path()[v211_14_origin..(v211_14_origin + 1)]);
      let v214_14: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v215_11: Space = routine_28(c, &(*CONSTANT_12), &((*CONSTANT_13).read_zipper()));
        let v215_12: Space = routine_28(c, &(*CONSTANT_14), &((*CONSTANT_15).read_zipper()));
        let v215_13: Space = unite(&(v215_11),&(v215_12));
        compose(&(*CONSTANT_0),&(v215_13))
      };
      let mut v214_16 = Space::new();
      let mut v214_16_write = v214_16.write_zipper();
      let mut v214_16_cursor = descend_cursor((v214_14).read_zipper(),&(*p1));
      let v214_16_origin = v214_16_cursor.path().len();
      for v214_16_byte in v214_16_cursor.child_mask().iter() {
        v214_16_cursor.descend_to_existing_byte(v214_16_byte);
        {
        let v216_2: Space = singleton(&v214_16_cursor.path()[v214_16_origin..(v214_16_origin + 1)]);
        let v216_3: Space = intersect(&(*CONSTANT_7),&(v216_2));
        let v216_4: Space = if has_head(&(v216_3)) { singleton(&[]) } else { Space::new() };
        drop(v216_3);
        let v216_5: Space = subtract(&(*CONSTANT_0),&(v216_4));
        drop(v216_4);
        let v216_7: Space = if (&(v216_5)).is_empty() { Space::new() } else {
          let v217_6: Space = routine_29(c, &v214_16_cursor.path()[v214_16_origin..(v214_16_origin + 1)], &(v214_6), &v214_16_cursor, &v211_14_cursor);
          compose(&(v216_5),&(v217_6))
        };
        drop(v216_5);
        let v216_8: Space = intersect(&(*CONSTANT_7),&(v216_2));
        drop(v216_2);
        let v216_9: Space = if has_head(&(v216_8)) { singleton(&[]) } else { Space::new() };
        drop(v216_8);
        let v216_14: Space = if (&(v216_9)).is_empty() { Space::new() } else {
          let v218_12: Space = wrap(&(descend_cursor(descend_cursor(cursor_at(&v214_16_cursor,(v214_16_origin + 1)),&(*p0)),&v211_14_cursor.path()[v211_14_origin..(v211_14_origin + 1)])),&v214_16_cursor.path()[v214_16_origin..(v214_16_origin + 1)]);
          let v218_13: Space = compose(&(v218_12),&v211_14_cursor);
          drop(v218_12);
          compose(&(v216_9),&(v218_13))
        };
        drop(v216_9);
        let v216_15: Space = unite(&(v216_7),&(v216_14));
        drop(v216_14);
        join_wrapped_into(&mut v214_16_write,&((v216_15).read_zipper()),&[]);
        }
        v214_16_cursor.ascend(1);
      }
      drop(v214_16_cursor);
      drop(v214_16_write);
      drop(v214_6);
      compose(&(v212_10),&(v214_16))
    };
    drop(v212_10);
    let v212_18: Space = unite(&(v212_8),&(v212_17));
    join_wrapped_into(&mut v211_14_write,&((v212_18).read_zipper()),&[]);
    }
    v211_14_cursor.ascend(1);
  }
  drop(v211_14_cursor);
  drop(v211_14_write);
  (v211_14).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v219_21: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v220_20: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
      let v221_7: Space = routine_28(c, &(*CONSTANT_1), &((*CONSTANT_20).read_zipper()));
      let v221_10: Space = routine_28(c, &(*CONSTANT_3), &((*CONSTANT_21).read_zipper()));
      let v221_11: Space = unite(&(v221_7),&(v221_10));
      let v221_14: Space = routine_28(c, &(*CONSTANT_4), &((*CONSTANT_22).read_zipper()));
      let v221_15: Space = unite(&(v221_11),&(v221_14));
      let v221_18: Space = routine_28(c, &(*CONSTANT_6), &((*CONSTANT_23).read_zipper()));
      let v221_19: Space = unite(&(v221_15),&(v221_18));
      compose(&(*CONSTANT_0),&(v221_19))
    };
    compose(&(*CONSTANT_0),&(v220_20))
  };
  let mut v219_29 = Space::new();
  let mut v219_29_write = v219_29.write_zipper();
  let mut v219_29_cursor = descend_cursor((v219_21).read_zipper(),&(*p1));
  let v219_29_origin = v219_29_cursor.path().len();
  for v219_29_byte in v219_29_cursor.child_mask().iter() {
    v219_29_cursor.descend_to_existing_byte(v219_29_byte);
    {
    let v222_2: Space = singleton(&v219_29_cursor.path()[v219_29_origin..(v219_29_origin + 1)]);
    let v222_3: Space = intersect(&(*CONSTANT_7),&(v222_2));
    let v222_4: Space = if has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
    drop(v222_3);
    let v222_5: Space = subtract(&(*CONSTANT_0),&(v222_4));
    drop(v222_4);
    let v222_7: Space = if (&(v222_5)).is_empty() { Space::new() } else {
      let mut v223_6 = Space::new();
      let mut v223_6_write = v223_6.write_zipper();
      for v223_6_byte in v219_29_cursor.child_mask().iter() {
        v219_29_cursor.descend_to_existing_byte(v223_6_byte);
        {
        let v224_2: Space = singleton(&v219_29_cursor.path()[(v219_29_origin + 1)..(v219_29_origin + 2)]);
        let v224_3: Space = intersect(&(*CONSTANT_7),&(v224_2));
        let v224_4: Space = if has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
        drop(v224_3);
        let v224_5: Space = subtract(&(*CONSTANT_0),&(v224_4));
        drop(v224_4);
        let v224_8: Space = if (&(v224_5)).is_empty() { Space::new() } else {
          let v225_7: Space = routine_29(c, &v219_29_cursor.path()[v219_29_origin..(v219_29_origin + 2)], &(*p0), &v219_29_cursor, &(*s0));
          compose(&(v224_5),&(v225_7))
        };
        drop(v224_5);
        let v224_9: Space = intersect(&(*CONSTANT_7),&(v224_2));
        drop(v224_2);
        let v224_10: Space = if has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
        drop(v224_9);
        let v224_14: Space = if (&(v224_10)).is_empty() { Space::new() } else {
          let v226_12: Space = wrap(&(descend_cursor(cursor_at(&v219_29_cursor,(v219_29_origin + 2)),&(*p0))),&v219_29_cursor.path()[v219_29_origin..(v219_29_origin + 2)]);
          let v226_13: Space = compose(&(v226_12),&(*s0));
          drop(v226_12);
          compose(&(v224_10),&(v226_13))
        };
        drop(v224_10);
        let v224_15: Space = unite(&(v224_8),&(v224_14));
        drop(v224_14);
        join_wrapped_into(&mut v223_6_write,&((v224_15).read_zipper()),&[]);
        }
        v219_29_cursor.ascend(1);
      }
      drop(v223_6_write);
      compose(&(v222_5),&(v223_6))
    };
    drop(v222_5);
    let v222_8: Space = intersect(&(*CONSTANT_7),&(v222_2));
    drop(v222_2);
    let v222_9: Space = if has_head(&(v222_8)) { singleton(&[]) } else { Space::new() };
    drop(v222_8);
    let v222_13: Space = if (&(v222_9)).is_empty() { Space::new() } else {
      let v227_11: Space = wrap(&(descend_cursor(cursor_at(&v219_29_cursor,(v219_29_origin + 1)),&(*p0))),&v219_29_cursor.path()[v219_29_origin..(v219_29_origin + 1)]);
      let v227_12: Space = compose(&(v227_11),&(*s0));
      drop(v227_11);
      compose(&(v222_9),&(v227_12))
    };
    drop(v222_9);
    let v222_14: Space = unite(&(v222_7),&(v222_13));
    drop(v222_13);
    join_wrapped_into(&mut v219_29_write,&((v222_14).read_zipper()),&[]);
    }
    v219_29_cursor.ascend(1);
  }
  drop(v219_29_cursor);
  drop(v219_29_write);
  (v219_29).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v228_22 = Space::new();
  let mut v228_22_write = v228_22.write_zipper();
  let mut v228_22_cursor = (*s0).read_zipper();
  let v228_22_origin = v228_22_cursor.path().len();
  for v228_22_byte in v228_22_cursor.child_mask().iter() {
    v228_22_cursor.descend_to_existing_byte(v228_22_byte);
    {
    let v229_2: Space = singleton(&v228_22_cursor.path()[v228_22_origin..(v228_22_origin + 1)]);
    let v229_3: Space = intersect(&(*CONSTANT_7),&(v229_2));
    let v229_4: Space = if has_head(&(v229_3)) { singleton(&[]) } else { Space::new() };
    drop(v229_3);
    let v229_5: Space = subtract(&(*CONSTANT_0),&(v229_4));
    drop(v229_4);
    let v229_8: Space = if (&(v229_5)).is_empty() { Space::new() } else {
      let v230_6: Path = concat_path(&(*p0),&v228_22_cursor.path()[v228_22_origin..(v228_22_origin + 1)]);
      let v230_7: Space = routine_10(c, &(v230_6), &(*p1), &v228_22_cursor);
      drop(v230_6);
      compose(&(v229_5),&(v230_7))
    };
    drop(v229_5);
    let v229_9: Space = intersect(&(*CONSTANT_7),&(v229_2));
    drop(v229_2);
    let v229_10: Space = if has_head(&(v229_9)) { singleton(&[]) } else { Space::new() };
    drop(v229_9);
    let v229_31: Space = if (&(v229_10)).is_empty() { Space::new() } else {
      let v231_14: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v232_11: Space = routine_30(c, &(*CONSTANT_12), &((*CONSTANT_13).read_zipper()));
        let v232_12: Space = routine_30(c, &(*CONSTANT_14), &((*CONSTANT_15).read_zipper()));
        let v232_13: Space = unite(&(v232_11),&(v232_12));
        compose(&(*CONSTANT_0),&(v232_13))
      };
      let v231_21: Space = if (&(descend_cursor(cursor_at(&v228_22_cursor,(v228_22_origin + 1)),&(*CONSTANT_16)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor(cursor_at(&v228_22_cursor,(v228_22_origin + 1)),&(*CONSTANT_16))),&(descend_cursor(cursor_at(&v228_22_cursor,(v228_22_origin + 1)),&(*CONSTANT_17))))
      };
      let v231_23: Space = if (&(v231_21)).is_empty() { Space::new() } else {
        compose(&(v231_21),&(descend_cursor(cursor_at(&v228_22_cursor,(v228_22_origin + 1)),&(*CONSTANT_18))))
      };
      let v231_25: Space = if (&(v231_21)).is_empty() { Space::new() } else {
        compose(&(v231_21),&(descend_cursor(cursor_at(&v228_22_cursor,(v228_22_origin + 1)),&(*CONSTANT_19))))
      };
      drop(v231_21);
      let v231_26: Space = if (&(descend_cursor(cursor_at(&v228_22_cursor,(v228_22_origin + 1)),&(*CONSTANT_17)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor(cursor_at(&v228_22_cursor,(v228_22_origin + 1)),&(*CONSTANT_17))),&(descend_cursor(cursor_at(&v228_22_cursor,(v228_22_origin + 1)),&(*CONSTANT_19))))
      };
      let v231_27: Space = if (&(v231_26)).is_empty() { Space::new() } else {
        compose(&(v231_26),&(descend_cursor(cursor_at(&v228_22_cursor,(v228_22_origin + 1)),&(*CONSTANT_18))))
      };
      drop(v231_26);
      let v231_28: Space = if (&(descend_cursor(cursor_at(&v228_22_cursor,(v228_22_origin + 1)),&(*CONSTANT_16)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor(cursor_at(&v228_22_cursor,(v228_22_origin + 1)),&(*CONSTANT_16))),&(descend_cursor(cursor_at(&v228_22_cursor,(v228_22_origin + 1)),&(*CONSTANT_19))))
      };
      let v231_29: Space = if (&(v231_28)).is_empty() { Space::new() } else {
        compose(&(v231_28),&(descend_cursor(cursor_at(&v228_22_cursor,(v228_22_origin + 1)),&(*CONSTANT_18))))
      };
      drop(v231_28);
      let mut v231_30 = Space::new();
      let mut v231_30_write = v231_30.write_zipper();
      let mut v231_30_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((v231_14).read_zipper(),&(*p1)),&(*p0)),&v228_22_cursor.path()[v228_22_origin..(v228_22_origin + 1)]),&(*p1));
      let v231_30_origin = v231_30_cursor.path().len();
      for v231_30_byte in v231_30_cursor.child_mask().iter() {
        v231_30_cursor.descend_to_existing_byte(v231_30_byte);
        {
        let v241_2: Space = singleton(&v231_30_cursor.path()[v231_30_origin..(v231_30_origin + 1)]);
        let v241_3: Space = intersect(&(*CONSTANT_7),&(v241_2));
        let v241_4: Space = if has_head(&(v241_3)) { singleton(&[]) } else { Space::new() };
        drop(v241_3);
        let v241_5: Space = subtract(&(*CONSTANT_0),&(v241_4));
        drop(v241_4);
        let v241_7: Space = if (&(v241_5)).is_empty() { Space::new() } else {
          let v242_6: Space = routine_31(c, &v231_30_cursor.path()[v231_30_origin..(v231_30_origin + 1)], &v231_30_cursor, &v228_22_cursor);
          compose(&(v241_5),&(v242_6))
        };
        drop(v241_5);
        let v241_8: Space = intersect(&(*CONSTANT_7),&(v241_2));
        let v241_9: Space = if has_head(&(v241_8)) { singleton(&[]) } else { Space::new() };
        drop(v241_8);
        let v241_21: Space = if (&(v241_9)).is_empty() { Space::new() } else {
          let v243_10: Space = intersect(&(*CONSTANT_8),&(v241_2));
          let v243_11: Space = compose(&(v243_10),&(v231_23));
          drop(v243_10);
          let v243_12: Space = intersect(&(*CONSTANT_9),&(v241_2));
          let v243_13: Space = compose(&(v243_12),&(v231_25));
          drop(v243_12);
          let v243_14: Space = unite(&(v243_11),&(v243_13));
          drop(v243_11);
          drop(v243_13);
          let v243_15: Space = intersect(&(*CONSTANT_10),&(v241_2));
          let v243_16: Space = compose(&(v243_15),&(v231_27));
          drop(v243_15);
          let v243_17: Space = unite(&(v243_14),&(v243_16));
          drop(v243_14);
          drop(v243_16);
          let v243_18: Space = intersect(&(*CONSTANT_11),&(v241_2));
          let v243_19: Space = compose(&(v243_18),&(v231_29));
          drop(v243_18);
          let v243_20: Space = unite(&(v243_17),&(v243_19));
          drop(v243_17);
          drop(v243_19);
          compose(&(v241_9),&(v243_20))
        };
        drop(v241_9);
        let v241_22: Space = unite(&(v241_7),&(v241_21));
        drop(v241_21);
        join_wrapped_into(&mut v231_30_write,&((v241_22).read_zipper()),&[]);
        }
        v231_30_cursor.ascend(1);
      }
      drop(v231_30_cursor);
      drop(v231_30_write);
      drop(v231_23);
      drop(v231_25);
      drop(v231_27);
      drop(v231_29);
      compose(&(v229_10),&(v231_30))
    };
    drop(v229_10);
    let v229_32: Space = unite(&(v229_8),&(v229_31));
    join_wrapped_into(&mut v228_22_write,&((v229_32).read_zipper()),&[]);
    }
    v228_22_cursor.ascend(1);
  }
  drop(v228_22_cursor);
  drop(v228_22_write);
  (v228_22).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v244_21: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v245_20: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
      let v246_7: Space = routine_30(c, &(*CONSTANT_1), &((*CONSTANT_20).read_zipper()));
      let v246_10: Space = routine_30(c, &(*CONSTANT_3), &((*CONSTANT_21).read_zipper()));
      let v246_11: Space = unite(&(v246_7),&(v246_10));
      let v246_14: Space = routine_30(c, &(*CONSTANT_4), &((*CONSTANT_22).read_zipper()));
      let v246_15: Space = unite(&(v246_11),&(v246_14));
      let v246_18: Space = routine_30(c, &(*CONSTANT_6), &((*CONSTANT_23).read_zipper()));
      let v246_19: Space = unite(&(v246_15),&(v246_18));
      compose(&(*CONSTANT_0),&(v246_19))
    };
    compose(&(*CONSTANT_0),&(v245_20))
  };
  let v244_33: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_16)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_16))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_17))))
  };
  let v244_36: Space = if (&(v244_33)).is_empty() { Space::new() } else {
    compose(&(v244_33),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_18))))
  };
  let v244_40: Space = if (&(v244_33)).is_empty() { Space::new() } else {
    compose(&(v244_33),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_19))))
  };
  drop(v244_33);
  let v244_42: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_17)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_17))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_19))))
  };
  let v244_43: Space = if (&(v244_42)).is_empty() { Space::new() } else {
    compose(&(v244_42),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_18))))
  };
  drop(v244_42);
  let v244_45: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_16)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_16))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_19))))
  };
  let v244_46: Space = if (&(v244_45)).is_empty() { Space::new() } else {
    compose(&(v244_45),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_18))))
  };
  drop(v244_45);
  let mut v244_54 = Space::new();
  let mut v244_54_write = v244_54.write_zipper();
  let mut v244_54_cursor = descend_cursor(descend_cursor(descend_cursor((v244_21).read_zipper(),&(*p1)),&(*p0)),&(*p1));
  let v244_54_origin = v244_54_cursor.path().len();
  for v244_54_byte in v244_54_cursor.child_mask().iter() {
    v244_54_cursor.descend_to_existing_byte(v244_54_byte);
    {
    let v255_2: Space = singleton(&v244_54_cursor.path()[v244_54_origin..(v244_54_origin + 1)]);
    let v255_3: Space = intersect(&(*CONSTANT_7),&(v255_2));
    let v255_4: Space = if has_head(&(v255_3)) { singleton(&[]) } else { Space::new() };
    drop(v255_3);
    let v255_5: Space = subtract(&(*CONSTANT_0),&(v255_4));
    drop(v255_4);
    let v255_7: Space = if (&(v255_5)).is_empty() { Space::new() } else {
      let mut v256_6 = Space::new();
      let mut v256_6_write = v256_6.write_zipper();
      for v256_6_byte in v244_54_cursor.child_mask().iter() {
        v244_54_cursor.descend_to_existing_byte(v256_6_byte);
        {
        let v257_2: Space = singleton(&v244_54_cursor.path()[(v244_54_origin + 1)..(v244_54_origin + 2)]);
        let v257_3: Space = intersect(&(*CONSTANT_7),&(v257_2));
        let v257_4: Space = if has_head(&(v257_3)) { singleton(&[]) } else { Space::new() };
        drop(v257_3);
        let v257_5: Space = subtract(&(*CONSTANT_0),&(v257_4));
        drop(v257_4);
        let v257_8: Space = if (&(v257_5)).is_empty() { Space::new() } else {
          let v258_7: Space = routine_31(c, &v244_54_cursor.path()[v244_54_origin..(v244_54_origin + 2)], &v244_54_cursor, &(*s0));
          compose(&(v257_5),&(v258_7))
        };
        drop(v257_5);
        let v257_9: Space = intersect(&(*CONSTANT_7),&(v257_2));
        drop(v257_2);
        let v257_10: Space = if has_head(&(v257_9)) { singleton(&[]) } else { Space::new() };
        drop(v257_9);
        let v257_23: Space = if (&(v257_10)).is_empty() { Space::new() } else {
          let v259_11: Space = singleton(&v244_54_cursor.path()[v244_54_origin..(v244_54_origin + 2)]);
          let v259_12: Space = intersect(&(*CONSTANT_8),&(v259_11));
          let v259_13: Space = compose(&(v259_12),&(v244_36));
          drop(v259_12);
          let v259_14: Space = intersect(&(*CONSTANT_9),&(v259_11));
          let v259_15: Space = compose(&(v259_14),&(v244_40));
          drop(v259_14);
          let v259_16: Space = unite(&(v259_13),&(v259_15));
          drop(v259_13);
          drop(v259_15);
          let v259_17: Space = intersect(&(*CONSTANT_10),&(v259_11));
          let v259_18: Space = compose(&(v259_17),&(v244_43));
          drop(v259_17);
          let v259_19: Space = unite(&(v259_16),&(v259_18));
          drop(v259_16);
          drop(v259_18);
          let v259_20: Space = intersect(&(*CONSTANT_11),&(v259_11));
          drop(v259_11);
          let v259_21: Space = compose(&(v259_20),&(v244_46));
          drop(v259_20);
          let v259_22: Space = unite(&(v259_19),&(v259_21));
          drop(v259_19);
          drop(v259_21);
          compose(&(v257_10),&(v259_22))
        };
        drop(v257_10);
        let v257_24: Space = unite(&(v257_8),&(v257_23));
        drop(v257_23);
        join_wrapped_into(&mut v256_6_write,&((v257_24).read_zipper()),&[]);
        }
        v244_54_cursor.ascend(1);
      }
      drop(v256_6_write);
      compose(&(v255_5),&(v256_6))
    };
    drop(v255_5);
    let v255_8: Space = intersect(&(*CONSTANT_7),&(v255_2));
    let v255_9: Space = if has_head(&(v255_8)) { singleton(&[]) } else { Space::new() };
    drop(v255_8);
    let v255_21: Space = if (&(v255_9)).is_empty() { Space::new() } else {
      let v260_10: Space = intersect(&(*CONSTANT_8),&(v255_2));
      let v260_11: Space = compose(&(v260_10),&(v244_36));
      drop(v260_10);
      let v260_12: Space = intersect(&(*CONSTANT_9),&(v255_2));
      let v260_13: Space = compose(&(v260_12),&(v244_40));
      drop(v260_12);
      let v260_14: Space = unite(&(v260_11),&(v260_13));
      drop(v260_11);
      drop(v260_13);
      let v260_15: Space = intersect(&(*CONSTANT_10),&(v255_2));
      let v260_16: Space = compose(&(v260_15),&(v244_43));
      drop(v260_15);
      let v260_17: Space = unite(&(v260_14),&(v260_16));
      drop(v260_14);
      drop(v260_16);
      let v260_18: Space = intersect(&(*CONSTANT_11),&(v255_2));
      let v260_19: Space = compose(&(v260_18),&(v244_46));
      drop(v260_18);
      let v260_20: Space = unite(&(v260_17),&(v260_19));
      drop(v260_17);
      drop(v260_19);
      compose(&(v255_9),&(v260_20))
    };
    drop(v255_9);
    let v255_22: Space = unite(&(v255_7),&(v255_21));
    drop(v255_21);
    join_wrapped_into(&mut v244_54_write,&((v255_22).read_zipper()),&[]);
    }
    v244_54_cursor.ascend(1);
  }
  drop(v244_54_cursor);
  drop(v244_54_write);
  drop(v244_36);
  drop(v244_40);
  drop(v244_43);
  drop(v244_46);
  (v244_54).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v261_5 = Space::new();
  let mut v261_5_write = v261_5.write_zipper();
  let mut v261_5_cursor = (*s0).read_zipper();
  let v261_5_origin = v261_5_cursor.path().len();
  for v261_5_byte in v261_5_cursor.child_mask().iter() {
    v261_5_cursor.descend_to_existing_byte(v261_5_byte);
    {
    let v262_2: Space = singleton(&v261_5_cursor.path()[v261_5_origin..(v261_5_origin + 1)]);
    let v262_3: Space = intersect(&(*CONSTANT_7),&(v262_2));
    let v262_4: Space = if has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
    drop(v262_3);
    let v262_5: Space = subtract(&(*CONSTANT_0),&(v262_4));
    drop(v262_4);
    let v262_8: Space = if (&(v262_5)).is_empty() { Space::new() } else {
      let v263_6: Path = concat_path(&(*p0),&v261_5_cursor.path()[v261_5_origin..(v261_5_origin + 1)]);
      let v263_7: Space = routine_12(c, &(v263_6), &v261_5_cursor);
      drop(v263_6);
      compose(&(v262_5),&(v263_7))
    };
    drop(v262_5);
    let v262_9: Space = intersect(&(*CONSTANT_7),&(v262_2));
    drop(v262_2);
    let v262_10: Space = if has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
    drop(v262_9);
    let v262_11: Space = compose(&(v262_10),&v261_5_cursor);
    drop(v262_10);
    let v262_12: Space = unite(&(v262_8),&(v262_11));
    drop(v262_11);
    join_wrapped_into(&mut v261_5_write,&((v262_12).read_zipper()),&[]);
    }
    v261_5_cursor.ascend(1);
  }
  drop(v261_5_cursor);
  drop(v261_5_write);
  (v261_5).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v264_11 = Space::new();
  let mut v264_11_write = v264_11.write_zipper();
  let mut v264_11_cursor = (*s0).read_zipper();
  let v264_11_origin = v264_11_cursor.path().len();
  for v264_11_byte in v264_11_cursor.child_mask().iter() {
    v264_11_cursor.descend_to_existing_byte(v264_11_byte);
    {
    let v265_2: Space = singleton(&v264_11_cursor.path()[v264_11_origin..(v264_11_origin + 1)]);
    let v265_3: Space = intersect(&(*CONSTANT_7),&(v265_2));
    let v265_4: Space = if has_head(&(v265_3)) { singleton(&[]) } else { Space::new() };
    drop(v265_3);
    let v265_5: Space = subtract(&(*CONSTANT_0),&(v265_4));
    drop(v265_4);
    let v265_8: Space = if (&(v265_5)).is_empty() { Space::new() } else {
      let v266_6: Path = concat_path(&(*p0),&v264_11_cursor.path()[v264_11_origin..(v264_11_origin + 1)]);
      let v266_7: Space = routine_13(c, &(v266_6), &v264_11_cursor);
      compose(&(v265_5),&(v266_7))
    };
    drop(v265_5);
    let v265_9: Space = intersect(&(*CONSTANT_7),&(v265_2));
    drop(v265_2);
    let v265_10: Space = if has_head(&(v265_9)) { singleton(&[]) } else { Space::new() };
    drop(v265_9);
    let v265_12: Space = if (&(v265_10)).is_empty() { Space::new() } else {
      let v267_6: Path = concat_path(&(*p0),&v264_11_cursor.path()[v264_11_origin..(v264_11_origin + 1)]);
      let mut v267_11 = Space::new();
      let mut v267_11_write = v267_11.write_zipper();
      for v267_11_byte in v264_11_cursor.child_mask().iter() {
        v264_11_cursor.descend_to_existing_byte(v267_11_byte);
        {
        let v268_2: Space = singleton(&v264_11_cursor.path()[(v264_11_origin + 1)..(v264_11_origin + 2)]);
        let v268_3: Space = intersect(&(*CONSTANT_7),&(v268_2));
        let v268_4: Space = if has_head(&(v268_3)) { singleton(&[]) } else { Space::new() };
        drop(v268_3);
        let v268_5: Space = subtract(&(*CONSTANT_0),&(v268_4));
        drop(v268_4);
        let v268_7: Space = if (&(v268_5)).is_empty() { Space::new() } else {
          let v269_6: Space = routine_14(c, &v264_11_cursor.path()[(v264_11_origin + 1)..(v264_11_origin + 2)], &(v267_6), &v264_11_cursor);
          compose(&(v268_5),&(v269_6))
        };
        drop(v268_5);
        let v268_8: Space = intersect(&(*CONSTANT_7),&(v268_2));
        drop(v268_2);
        let v268_9: Space = if has_head(&(v268_8)) { singleton(&[]) } else { Space::new() };
        drop(v268_8);
        let v268_11: Space = if (&(v268_9)).is_empty() { Space::new() } else {
          let mut v270_10 = Space::new();
          let mut v270_10_write = v270_10.write_zipper();
          for v270_10_byte in v264_11_cursor.child_mask().iter() {
            v264_11_cursor.descend_to_existing_byte(v270_10_byte);
            {
            let v271_2: Space = singleton(&v264_11_cursor.path()[(v264_11_origin + 2)..(v264_11_origin + 3)]);
            let v271_3: Space = intersect(&(*CONSTANT_7),&(v271_2));
            let v271_4: Space = if has_head(&(v271_3)) { singleton(&[]) } else { Space::new() };
            drop(v271_3);
            let v271_5: Space = subtract(&(*CONSTANT_0),&(v271_4));
            drop(v271_4);
            let v271_7: Space = if (&(v271_5)).is_empty() { Space::new() } else {
              let v272_6: Space = routine_32(c, &v264_11_cursor.path()[(v264_11_origin + 2)..(v264_11_origin + 3)], &(v267_6), &v264_11_cursor.path()[(v264_11_origin + 1)..(v264_11_origin + 2)], &v264_11_cursor);
              compose(&(v271_5),&(v272_6))
            };
            drop(v271_5);
            let v271_8: Space = intersect(&(*CONSTANT_7),&(v271_2));
            drop(v271_2);
            let v271_9: Space = if has_head(&(v271_8)) { singleton(&[]) } else { Space::new() };
            drop(v271_8);
            let v271_11: Space = if (&(v271_9)).is_empty() { Space::new() } else {
              let v273_10: Space = routine_33(c, &v264_11_cursor.path()[(v264_11_origin + 2)..(v264_11_origin + 3)], &(v267_6), &v264_11_cursor.path()[(v264_11_origin + 1)..(v264_11_origin + 2)], &v264_11_cursor);
              compose(&(v271_9),&(v273_10))
            };
            drop(v271_9);
            let v271_12: Space = unite(&(v271_7),&(v271_11));
            join_wrapped_into(&mut v270_10_write,&((v271_12).read_zipper()),&[]);
            }
            v264_11_cursor.ascend(1);
          }
          drop(v270_10_write);
          compose(&(v268_9),&(v270_10))
        };
        drop(v268_9);
        let v268_12: Space = unite(&(v268_7),&(v268_11));
        join_wrapped_into(&mut v267_11_write,&((v268_12).read_zipper()),&[]);
        }
        v264_11_cursor.ascend(1);
      }
      drop(v267_11_write);
      drop(v267_6);
      compose(&(v265_10),&(v267_11))
    };
    drop(v265_10);
    let v265_13: Space = unite(&(v265_8),&(v265_12));
    join_wrapped_into(&mut v264_11_write,&((v265_13).read_zipper()),&[]);
    }
    v264_11_cursor.ascend(1);
  }
  drop(v264_11_cursor);
  drop(v264_11_write);
  (v264_11).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v274_13: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v274_14: Space = singleton(&(v274_13));
  drop(v274_13);
  let mut v274_15 = Space::new();
  let mut v274_15_write = v274_15.write_zipper();
  let mut v274_15_cursor = (*s0).read_zipper();
  let v274_15_origin = v274_15_cursor.path().len();
  for v274_15_byte in v274_15_cursor.child_mask().iter() {
    v274_15_cursor.descend_to_existing_byte(v274_15_byte);
    {
    let v275_2: Space = singleton(&v274_15_cursor.path()[v274_15_origin..(v274_15_origin + 1)]);
    let v275_3: Space = intersect(&(*CONSTANT_7),&(v275_2));
    let v275_4: Space = if has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
    drop(v275_3);
    let v275_5: Space = subtract(&(*CONSTANT_0),&(v275_4));
    drop(v275_4);
    let v275_8: Space = if (&(v275_5)).is_empty() { Space::new() } else {
      let v276_6: Path = concat_path(&(*p0),&v274_15_cursor.path()[v274_15_origin..(v274_15_origin + 1)]);
      let v276_7: Space = routine_14(c, &(v276_6), &(*p1), &v274_15_cursor);
      compose(&(v275_5),&(v276_7))
    };
    drop(v275_5);
    let v275_9: Space = intersect(&(*CONSTANT_7),&(v275_2));
    drop(v275_2);
    let v275_10: Space = if has_head(&(v275_9)) { singleton(&[]) } else { Space::new() };
    drop(v275_9);
    let v275_14: Space = if (&(v275_10)).is_empty() { Space::new() } else {
      let v277_6: Path = concat_path(&(*p0),&v274_15_cursor.path()[v274_15_origin..(v274_15_origin + 1)]);
      let v277_11: Path = concat_path(&(*CONSTANT_17),&(v277_6));
      let v277_12: Space = singleton(&(v277_11));
      drop(v277_11);
      let mut v277_13 = Space::new();
      let mut v277_13_write = v277_13.write_zipper();
      for v277_13_byte in v274_15_cursor.child_mask().iter() {
        v274_15_cursor.descend_to_existing_byte(v277_13_byte);
        {
        let v278_2: Space = singleton(&v274_15_cursor.path()[(v274_15_origin + 1)..(v274_15_origin + 2)]);
        let v278_3: Space = intersect(&(*CONSTANT_7),&(v278_2));
        let v278_4: Space = if has_head(&(v278_3)) { singleton(&[]) } else { Space::new() };
        drop(v278_3);
        let v278_5: Space = subtract(&(*CONSTANT_0),&(v278_4));
        drop(v278_4);
        let v278_7: Space = if (&(v278_5)).is_empty() { Space::new() } else {
          let v279_6: Space = routine_32(c, &v274_15_cursor.path()[(v274_15_origin + 1)..(v274_15_origin + 2)], &(*p1), &(v277_6), &v274_15_cursor);
          compose(&(v278_5),&(v279_6))
        };
        drop(v278_5);
        let v278_8: Space = intersect(&(*CONSTANT_7),&(v278_2));
        drop(v278_2);
        let v278_9: Space = if has_head(&(v278_8)) { singleton(&[]) } else { Space::new() };
        drop(v278_8);
        let v278_15: Space = if (&(v278_9)).is_empty() { Space::new() } else {
          let v280_10: Path = concat_path(&(*CONSTANT_18),&v274_15_cursor.path()[(v274_15_origin + 1)..(v274_15_origin + 2)]);
          let v280_11: Space = singleton(&(v280_10));
          drop(v280_10);
          let v280_12: Space = unite(&(*CONSTANT_24),&(v280_11));
          drop(v280_11);
          let v280_13: Space = unite(&(v280_12),&(v274_14));
          drop(v280_12);
          let v280_14: Space = unite(&(v280_13),&(v277_12));
          drop(v280_13);
          compose(&(v278_9),&(v280_14))
        };
        drop(v278_9);
        let v278_16: Space = unite(&(v278_7),&(v278_15));
        drop(v278_15);
        join_wrapped_into(&mut v277_13_write,&((v278_16).read_zipper()),&[]);
        }
        v274_15_cursor.ascend(1);
      }
      drop(v277_13_write);
      drop(v277_6);
      drop(v277_12);
      compose(&(v275_10),&(v277_13))
    };
    drop(v275_10);
    let v275_15: Space = unite(&(v275_8),&(v275_14));
    join_wrapped_into(&mut v274_15_write,&((v275_15).read_zipper()),&[]);
    }
    v274_15_cursor.ascend(1);
  }
  drop(v274_15_cursor);
  drop(v274_15_write);
  drop(v274_14);
  (v274_15).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v281_9: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v281_10: Space = singleton(&(v281_9));
  drop(v281_9);
  let v281_12: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v281_13: Space = singleton(&(v281_12));
  drop(v281_12);
  let mut v281_18 = Space::new();
  let mut v281_18_write = v281_18.write_zipper();
  let mut v281_18_cursor = (*s0).read_zipper();
  let v281_18_origin = v281_18_cursor.path().len();
  for v281_18_byte in v281_18_cursor.child_mask().iter() {
    v281_18_cursor.descend_to_existing_byte(v281_18_byte);
    {
    let v282_2: Space = singleton(&v281_18_cursor.path()[v281_18_origin..(v281_18_origin + 1)]);
    let v282_3: Space = intersect(&(*CONSTANT_7),&(v282_2));
    let v282_4: Space = if has_head(&(v282_3)) { singleton(&[]) } else { Space::new() };
    drop(v282_3);
    let v282_5: Space = subtract(&(*CONSTANT_0),&(v282_4));
    drop(v282_4);
    let v282_7: Space = if (&(v282_5)).is_empty() { Space::new() } else {
      let mut v283_6 = Space::new();
      let mut v283_6_write = v283_6.write_zipper();
      for v283_6_byte in v281_18_cursor.child_mask().iter() {
        v281_18_cursor.descend_to_existing_byte(v283_6_byte);
        {
        let v284_2: Space = singleton(&v281_18_cursor.path()[(v281_18_origin + 1)..(v281_18_origin + 2)]);
        let v284_3: Space = intersect(&(*CONSTANT_7),&(v284_2));
        let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
        drop(v284_3);
        let v284_5: Space = subtract(&(*CONSTANT_0),&(v284_4));
        drop(v284_4);
        let v284_8: Space = if (&(v284_5)).is_empty() { Space::new() } else {
          let v285_7: Space = routine_32(c, &v281_18_cursor.path()[v281_18_origin..(v281_18_origin + 2)], &(*p1), &(*p0), &v281_18_cursor);
          compose(&(v284_5),&(v285_7))
        };
        drop(v284_5);
        let v284_9: Space = intersect(&(*CONSTANT_7),&(v284_2));
        drop(v284_2);
        let v284_10: Space = if has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
        drop(v284_9);
        let v284_16: Space = if (&(v284_10)).is_empty() { Space::new() } else {
          let v286_11: Path = concat_path(&(*CONSTANT_18),&v281_18_cursor.path()[v281_18_origin..(v281_18_origin + 2)]);
          let v286_12: Space = singleton(&(v286_11));
          drop(v286_11);
          let v286_13: Space = unite(&(*CONSTANT_24),&(v286_12));
          drop(v286_12);
          let v286_14: Space = unite(&(v286_13),&(v281_10));
          drop(v286_13);
          let v286_15: Space = unite(&(v286_14),&(v281_13));
          drop(v286_14);
          compose(&(v284_10),&(v286_15))
        };
        drop(v284_10);
        let v284_17: Space = unite(&(v284_8),&(v284_16));
        drop(v284_16);
        join_wrapped_into(&mut v283_6_write,&((v284_17).read_zipper()),&[]);
        }
        v281_18_cursor.ascend(1);
      }
      drop(v283_6_write);
      compose(&(v282_5),&(v283_6))
    };
    drop(v282_5);
    let v282_8: Space = intersect(&(*CONSTANT_7),&(v282_2));
    drop(v282_2);
    let v282_9: Space = if has_head(&(v282_8)) { singleton(&[]) } else { Space::new() };
    drop(v282_8);
    let v282_15: Space = if (&(v282_9)).is_empty() { Space::new() } else {
      let v287_10: Path = concat_path(&(*CONSTANT_18),&v281_18_cursor.path()[v281_18_origin..(v281_18_origin + 1)]);
      let v287_11: Space = singleton(&(v287_10));
      drop(v287_10);
      let v287_12: Space = unite(&(*CONSTANT_24),&(v287_11));
      drop(v287_11);
      let v287_13: Space = unite(&(v287_12),&(v281_10));
      drop(v287_12);
      let v287_14: Space = unite(&(v287_13),&(v281_13));
      drop(v287_13);
      compose(&(v282_9),&(v287_14))
    };
    drop(v282_9);
    let v282_16: Space = unite(&(v282_7),&(v282_15));
    drop(v282_15);
    join_wrapped_into(&mut v281_18_write,&((v282_16).read_zipper()),&[]);
    }
    v281_18_cursor.ascend(1);
  }
  drop(v281_18_cursor);
  drop(v281_18_write);
  drop(v281_10);
  drop(v281_13);
  (v281_18).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v288_5 = Space::new();
  let mut v288_5_write = v288_5.write_zipper();
  let mut v288_5_cursor = (*s0).read_zipper();
  let v288_5_origin = v288_5_cursor.path().len();
  for v288_5_byte in v288_5_cursor.child_mask().iter() {
    v288_5_cursor.descend_to_existing_byte(v288_5_byte);
    {
    let v289_2: Space = singleton(&v288_5_cursor.path()[v288_5_origin..(v288_5_origin + 1)]);
    let v289_3: Space = intersect(&(*CONSTANT_7),&(v289_2));
    let v289_4: Space = if has_head(&(v289_3)) { singleton(&[]) } else { Space::new() };
    drop(v289_3);
    let v289_5: Space = subtract(&(*CONSTANT_0),&(v289_4));
    drop(v289_4);
    let v289_8: Space = if (&(v289_5)).is_empty() { Space::new() } else {
      let v290_6: Path = concat_path(&(*p0),&v288_5_cursor.path()[v288_5_origin..(v288_5_origin + 1)]);
      let v290_7: Space = routine_16(c, &(v290_6), &v288_5_cursor);
      drop(v290_6);
      compose(&(v289_5),&(v290_7))
    };
    drop(v289_5);
    let v289_9: Space = intersect(&(*CONSTANT_7),&(v289_2));
    drop(v289_2);
    let v289_10: Space = if has_head(&(v289_9)) { singleton(&[]) } else { Space::new() };
    drop(v289_9);
    let v289_11: Space = compose(&(v289_10),&v288_5_cursor);
    drop(v289_10);
    let v289_12: Space = unite(&(v289_8),&(v289_11));
    drop(v289_11);
    join_wrapped_into(&mut v288_5_write,&((v289_12).read_zipper()),&[]);
    }
    v288_5_cursor.ascend(1);
  }
  drop(v288_5_cursor);
  drop(v288_5_write);
  (v288_5).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v291_11 = Space::new();
  let mut v291_11_write = v291_11.write_zipper();
  let mut v291_11_cursor = (*s0).read_zipper();
  let v291_11_origin = v291_11_cursor.path().len();
  for v291_11_byte in v291_11_cursor.child_mask().iter() {
    v291_11_cursor.descend_to_existing_byte(v291_11_byte);
    {
    let v292_2: Space = singleton(&v291_11_cursor.path()[v291_11_origin..(v291_11_origin + 1)]);
    let v292_3: Space = intersect(&(*CONSTANT_7),&(v292_2));
    let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
    drop(v292_3);
    let v292_5: Space = subtract(&(*CONSTANT_0),&(v292_4));
    drop(v292_4);
    let v292_8: Space = if (&(v292_5)).is_empty() { Space::new() } else {
      let v293_6: Path = concat_path(&(*p0),&v291_11_cursor.path()[v291_11_origin..(v291_11_origin + 1)]);
      let v293_7: Space = routine_17(c, &(v293_6), &v291_11_cursor);
      compose(&(v292_5),&(v293_7))
    };
    drop(v292_5);
    let v292_9: Space = intersect(&(*CONSTANT_7),&(v292_2));
    drop(v292_2);
    let v292_10: Space = if has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
    drop(v292_9);
    let v292_12: Space = if (&(v292_10)).is_empty() { Space::new() } else {
      let v294_6: Path = concat_path(&(*p0),&v291_11_cursor.path()[v291_11_origin..(v291_11_origin + 1)]);
      let mut v294_11 = Space::new();
      let mut v294_11_write = v294_11.write_zipper();
      for v294_11_byte in v291_11_cursor.child_mask().iter() {
        v291_11_cursor.descend_to_existing_byte(v294_11_byte);
        {
        let v295_2: Space = singleton(&v291_11_cursor.path()[(v291_11_origin + 1)..(v291_11_origin + 2)]);
        let v295_3: Space = intersect(&(*CONSTANT_7),&(v295_2));
        let v295_4: Space = if has_head(&(v295_3)) { singleton(&[]) } else { Space::new() };
        drop(v295_3);
        let v295_5: Space = subtract(&(*CONSTANT_0),&(v295_4));
        drop(v295_4);
        let v295_7: Space = if (&(v295_5)).is_empty() { Space::new() } else {
          let v296_6: Space = routine_18(c, &v291_11_cursor.path()[(v291_11_origin + 1)..(v291_11_origin + 2)], &(v294_6), &v291_11_cursor);
          compose(&(v295_5),&(v296_6))
        };
        drop(v295_5);
        let v295_8: Space = intersect(&(*CONSTANT_7),&(v295_2));
        drop(v295_2);
        let v295_9: Space = if has_head(&(v295_8)) { singleton(&[]) } else { Space::new() };
        drop(v295_8);
        let v295_11: Space = if (&(v295_9)).is_empty() { Space::new() } else {
          let mut v297_10 = Space::new();
          let mut v297_10_write = v297_10.write_zipper();
          for v297_10_byte in v291_11_cursor.child_mask().iter() {
            v291_11_cursor.descend_to_existing_byte(v297_10_byte);
            {
            let v298_2: Space = singleton(&v291_11_cursor.path()[(v291_11_origin + 2)..(v291_11_origin + 3)]);
            let v298_3: Space = intersect(&(*CONSTANT_7),&(v298_2));
            let v298_4: Space = if has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = subtract(&(*CONSTANT_0),&(v298_4));
            drop(v298_4);
            let v298_7: Space = if (&(v298_5)).is_empty() { Space::new() } else {
              let v299_6: Space = routine_34(c, &v291_11_cursor.path()[(v291_11_origin + 2)..(v291_11_origin + 3)], &(v294_6), &v291_11_cursor.path()[(v291_11_origin + 1)..(v291_11_origin + 2)], &v291_11_cursor);
              compose(&(v298_5),&(v299_6))
            };
            drop(v298_5);
            let v298_8: Space = intersect(&(*CONSTANT_7),&(v298_2));
            drop(v298_2);
            let v298_9: Space = if has_head(&(v298_8)) { singleton(&[]) } else { Space::new() };
            drop(v298_8);
            let v298_11: Space = if (&(v298_9)).is_empty() { Space::new() } else {
              let v300_10: Space = routine_35(c, &v291_11_cursor.path()[(v291_11_origin + 2)..(v291_11_origin + 3)], &(v294_6), &v291_11_cursor.path()[(v291_11_origin + 1)..(v291_11_origin + 2)], &v291_11_cursor);
              compose(&(v298_9),&(v300_10))
            };
            drop(v298_9);
            let v298_12: Space = unite(&(v298_7),&(v298_11));
            join_wrapped_into(&mut v297_10_write,&((v298_12).read_zipper()),&[]);
            }
            v291_11_cursor.ascend(1);
          }
          drop(v297_10_write);
          compose(&(v295_9),&(v297_10))
        };
        drop(v295_9);
        let v295_12: Space = unite(&(v295_7),&(v295_11));
        join_wrapped_into(&mut v294_11_write,&((v295_12).read_zipper()),&[]);
        }
        v291_11_cursor.ascend(1);
      }
      drop(v294_11_write);
      drop(v294_6);
      compose(&(v292_10),&(v294_11))
    };
    drop(v292_10);
    let v292_13: Space = unite(&(v292_8),&(v292_12));
    join_wrapped_into(&mut v291_11_write,&((v292_13).read_zipper()),&[]);
    }
    v291_11_cursor.ascend(1);
  }
  drop(v291_11_cursor);
  drop(v291_11_write);
  (v291_11).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v301_13: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v301_14: Space = singleton(&(v301_13));
  drop(v301_13);
  let mut v301_15 = Space::new();
  let mut v301_15_write = v301_15.write_zipper();
  let mut v301_15_cursor = (*s0).read_zipper();
  let v301_15_origin = v301_15_cursor.path().len();
  for v301_15_byte in v301_15_cursor.child_mask().iter() {
    v301_15_cursor.descend_to_existing_byte(v301_15_byte);
    {
    let v302_2: Space = singleton(&v301_15_cursor.path()[v301_15_origin..(v301_15_origin + 1)]);
    let v302_3: Space = intersect(&(*CONSTANT_7),&(v302_2));
    let v302_4: Space = if has_head(&(v302_3)) { singleton(&[]) } else { Space::new() };
    drop(v302_3);
    let v302_5: Space = subtract(&(*CONSTANT_0),&(v302_4));
    drop(v302_4);
    let v302_8: Space = if (&(v302_5)).is_empty() { Space::new() } else {
      let v303_6: Path = concat_path(&(*p0),&v301_15_cursor.path()[v301_15_origin..(v301_15_origin + 1)]);
      let v303_7: Space = routine_18(c, &(v303_6), &(*p1), &v301_15_cursor);
      compose(&(v302_5),&(v303_7))
    };
    drop(v302_5);
    let v302_9: Space = intersect(&(*CONSTANT_7),&(v302_2));
    drop(v302_2);
    let v302_10: Space = if has_head(&(v302_9)) { singleton(&[]) } else { Space::new() };
    drop(v302_9);
    let v302_14: Space = if (&(v302_10)).is_empty() { Space::new() } else {
      let v304_6: Path = concat_path(&(*p0),&v301_15_cursor.path()[v301_15_origin..(v301_15_origin + 1)]);
      let v304_11: Path = concat_path(&(*CONSTANT_17),&(v304_6));
      let v304_12: Space = singleton(&(v304_11));
      drop(v304_11);
      let mut v304_13 = Space::new();
      let mut v304_13_write = v304_13.write_zipper();
      for v304_13_byte in v301_15_cursor.child_mask().iter() {
        v301_15_cursor.descend_to_existing_byte(v304_13_byte);
        {
        let v305_2: Space = singleton(&v301_15_cursor.path()[(v301_15_origin + 1)..(v301_15_origin + 2)]);
        let v305_3: Space = intersect(&(*CONSTANT_7),&(v305_2));
        let v305_4: Space = if has_head(&(v305_3)) { singleton(&[]) } else { Space::new() };
        drop(v305_3);
        let v305_5: Space = subtract(&(*CONSTANT_0),&(v305_4));
        drop(v305_4);
        let v305_7: Space = if (&(v305_5)).is_empty() { Space::new() } else {
          let v306_6: Space = routine_34(c, &v301_15_cursor.path()[(v301_15_origin + 1)..(v301_15_origin + 2)], &(*p1), &(v304_6), &v301_15_cursor);
          compose(&(v305_5),&(v306_6))
        };
        drop(v305_5);
        let v305_8: Space = intersect(&(*CONSTANT_7),&(v305_2));
        drop(v305_2);
        let v305_9: Space = if has_head(&(v305_8)) { singleton(&[]) } else { Space::new() };
        drop(v305_8);
        let v305_15: Space = if (&(v305_9)).is_empty() { Space::new() } else {
          let v307_10: Path = concat_path(&(*CONSTANT_19),&v301_15_cursor.path()[(v301_15_origin + 1)..(v301_15_origin + 2)]);
          let v307_11: Space = singleton(&(v307_10));
          drop(v307_10);
          let v307_12: Space = unite(&(*CONSTANT_25),&(v307_11));
          drop(v307_11);
          let v307_13: Space = unite(&(v307_12),&(v301_14));
          drop(v307_12);
          let v307_14: Space = unite(&(v307_13),&(v304_12));
          drop(v307_13);
          compose(&(v305_9),&(v307_14))
        };
        drop(v305_9);
        let v305_16: Space = unite(&(v305_7),&(v305_15));
        drop(v305_15);
        join_wrapped_into(&mut v304_13_write,&((v305_16).read_zipper()),&[]);
        }
        v301_15_cursor.ascend(1);
      }
      drop(v304_13_write);
      drop(v304_6);
      drop(v304_12);
      compose(&(v302_10),&(v304_13))
    };
    drop(v302_10);
    let v302_15: Space = unite(&(v302_8),&(v302_14));
    join_wrapped_into(&mut v301_15_write,&((v302_15).read_zipper()),&[]);
    }
    v301_15_cursor.ascend(1);
  }
  drop(v301_15_cursor);
  drop(v301_15_write);
  drop(v301_14);
  (v301_15).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v308_9: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v308_10: Space = singleton(&(v308_9));
  drop(v308_9);
  let v308_12: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v308_13: Space = singleton(&(v308_12));
  drop(v308_12);
  let mut v308_18 = Space::new();
  let mut v308_18_write = v308_18.write_zipper();
  let mut v308_18_cursor = (*s0).read_zipper();
  let v308_18_origin = v308_18_cursor.path().len();
  for v308_18_byte in v308_18_cursor.child_mask().iter() {
    v308_18_cursor.descend_to_existing_byte(v308_18_byte);
    {
    let v309_2: Space = singleton(&v308_18_cursor.path()[v308_18_origin..(v308_18_origin + 1)]);
    let v309_3: Space = intersect(&(*CONSTANT_7),&(v309_2));
    let v309_4: Space = if has_head(&(v309_3)) { singleton(&[]) } else { Space::new() };
    drop(v309_3);
    let v309_5: Space = subtract(&(*CONSTANT_0),&(v309_4));
    drop(v309_4);
    let v309_7: Space = if (&(v309_5)).is_empty() { Space::new() } else {
      let mut v310_6 = Space::new();
      let mut v310_6_write = v310_6.write_zipper();
      for v310_6_byte in v308_18_cursor.child_mask().iter() {
        v308_18_cursor.descend_to_existing_byte(v310_6_byte);
        {
        let v311_2: Space = singleton(&v308_18_cursor.path()[(v308_18_origin + 1)..(v308_18_origin + 2)]);
        let v311_3: Space = intersect(&(*CONSTANT_7),&(v311_2));
        let v311_4: Space = if has_head(&(v311_3)) { singleton(&[]) } else { Space::new() };
        drop(v311_3);
        let v311_5: Space = subtract(&(*CONSTANT_0),&(v311_4));
        drop(v311_4);
        let v311_8: Space = if (&(v311_5)).is_empty() { Space::new() } else {
          let v312_7: Space = routine_34(c, &v308_18_cursor.path()[v308_18_origin..(v308_18_origin + 2)], &(*p1), &(*p0), &v308_18_cursor);
          compose(&(v311_5),&(v312_7))
        };
        drop(v311_5);
        let v311_9: Space = intersect(&(*CONSTANT_7),&(v311_2));
        drop(v311_2);
        let v311_10: Space = if has_head(&(v311_9)) { singleton(&[]) } else { Space::new() };
        drop(v311_9);
        let v311_16: Space = if (&(v311_10)).is_empty() { Space::new() } else {
          let v313_11: Path = concat_path(&(*CONSTANT_19),&v308_18_cursor.path()[v308_18_origin..(v308_18_origin + 2)]);
          let v313_12: Space = singleton(&(v313_11));
          drop(v313_11);
          let v313_13: Space = unite(&(*CONSTANT_25),&(v313_12));
          drop(v313_12);
          let v313_14: Space = unite(&(v313_13),&(v308_10));
          drop(v313_13);
          let v313_15: Space = unite(&(v313_14),&(v308_13));
          drop(v313_14);
          compose(&(v311_10),&(v313_15))
        };
        drop(v311_10);
        let v311_17: Space = unite(&(v311_8),&(v311_16));
        drop(v311_16);
        join_wrapped_into(&mut v310_6_write,&((v311_17).read_zipper()),&[]);
        }
        v308_18_cursor.ascend(1);
      }
      drop(v310_6_write);
      compose(&(v309_5),&(v310_6))
    };
    drop(v309_5);
    let v309_8: Space = intersect(&(*CONSTANT_7),&(v309_2));
    drop(v309_2);
    let v309_9: Space = if has_head(&(v309_8)) { singleton(&[]) } else { Space::new() };
    drop(v309_8);
    let v309_15: Space = if (&(v309_9)).is_empty() { Space::new() } else {
      let v314_10: Path = concat_path(&(*CONSTANT_19),&v308_18_cursor.path()[v308_18_origin..(v308_18_origin + 1)]);
      let v314_11: Space = singleton(&(v314_10));
      drop(v314_10);
      let v314_12: Space = unite(&(*CONSTANT_25),&(v314_11));
      drop(v314_11);
      let v314_13: Space = unite(&(v314_12),&(v308_10));
      drop(v314_12);
      let v314_14: Space = unite(&(v314_13),&(v308_13));
      drop(v314_13);
      compose(&(v309_9),&(v314_14))
    };
    drop(v309_9);
    let v309_16: Space = unite(&(v309_7),&(v309_15));
    drop(v309_15);
    join_wrapped_into(&mut v308_18_write,&((v309_16).read_zipper()),&[]);
    }
    v308_18_cursor.ascend(1);
  }
  drop(v308_18_cursor);
  drop(v308_18_write);
  drop(v308_10);
  drop(v308_13);
  (v308_18).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v315_5 = Space::new();
  let mut v315_5_write = v315_5.write_zipper();
  let mut v315_5_cursor = (*s0).read_zipper();
  let v315_5_origin = v315_5_cursor.path().len();
  for v315_5_byte in v315_5_cursor.child_mask().iter() {
    v315_5_cursor.descend_to_existing_byte(v315_5_byte);
    {
    let v316_2: Space = singleton(&v315_5_cursor.path()[v315_5_origin..(v315_5_origin + 1)]);
    let v316_3: Space = intersect(&(*CONSTANT_7),&(v316_2));
    let v316_4: Space = if has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
    drop(v316_3);
    let v316_5: Space = subtract(&(*CONSTANT_0),&(v316_4));
    drop(v316_4);
    let v316_8: Space = if (&(v316_5)).is_empty() { Space::new() } else {
      let v317_6: Path = concat_path(&(*p0),&v315_5_cursor.path()[v315_5_origin..(v315_5_origin + 1)]);
      let v317_7: Space = routine_20(c, &(v317_6), &v315_5_cursor);
      drop(v317_6);
      compose(&(v316_5),&(v317_7))
    };
    drop(v316_5);
    let v316_9: Space = intersect(&(*CONSTANT_7),&(v316_2));
    drop(v316_2);
    let v316_10: Space = if has_head(&(v316_9)) { singleton(&[]) } else { Space::new() };
    drop(v316_9);
    let v316_11: Space = compose(&(v316_10),&v315_5_cursor);
    drop(v316_10);
    let v316_12: Space = unite(&(v316_8),&(v316_11));
    drop(v316_11);
    join_wrapped_into(&mut v315_5_write,&((v316_12).read_zipper()),&[]);
    }
    v315_5_cursor.ascend(1);
  }
  drop(v315_5_cursor);
  drop(v315_5_write);
  (v315_5).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v318_11 = Space::new();
  let mut v318_11_write = v318_11.write_zipper();
  let mut v318_11_cursor = (*s0).read_zipper();
  let v318_11_origin = v318_11_cursor.path().len();
  for v318_11_byte in v318_11_cursor.child_mask().iter() {
    v318_11_cursor.descend_to_existing_byte(v318_11_byte);
    {
    let v319_2: Space = singleton(&v318_11_cursor.path()[v318_11_origin..(v318_11_origin + 1)]);
    let v319_3: Space = intersect(&(*CONSTANT_7),&(v319_2));
    let v319_4: Space = if has_head(&(v319_3)) { singleton(&[]) } else { Space::new() };
    drop(v319_3);
    let v319_5: Space = subtract(&(*CONSTANT_0),&(v319_4));
    drop(v319_4);
    let v319_8: Space = if (&(v319_5)).is_empty() { Space::new() } else {
      let v320_6: Path = concat_path(&(*p0),&v318_11_cursor.path()[v318_11_origin..(v318_11_origin + 1)]);
      let v320_7: Space = routine_21(c, &(v320_6), &v318_11_cursor);
      compose(&(v319_5),&(v320_7))
    };
    drop(v319_5);
    let v319_9: Space = intersect(&(*CONSTANT_7),&(v319_2));
    drop(v319_2);
    let v319_10: Space = if has_head(&(v319_9)) { singleton(&[]) } else { Space::new() };
    drop(v319_9);
    let v319_12: Space = if (&(v319_10)).is_empty() { Space::new() } else {
      let v321_6: Path = concat_path(&(*p0),&v318_11_cursor.path()[v318_11_origin..(v318_11_origin + 1)]);
      let mut v321_11 = Space::new();
      let mut v321_11_write = v321_11.write_zipper();
      for v321_11_byte in v318_11_cursor.child_mask().iter() {
        v318_11_cursor.descend_to_existing_byte(v321_11_byte);
        {
        let v322_2: Space = singleton(&v318_11_cursor.path()[(v318_11_origin + 1)..(v318_11_origin + 2)]);
        let v322_3: Space = intersect(&(*CONSTANT_7),&(v322_2));
        let v322_4: Space = if has_head(&(v322_3)) { singleton(&[]) } else { Space::new() };
        drop(v322_3);
        let v322_5: Space = subtract(&(*CONSTANT_0),&(v322_4));
        drop(v322_4);
        let v322_7: Space = if (&(v322_5)).is_empty() { Space::new() } else {
          let v323_6: Space = routine_22(c, &v318_11_cursor.path()[(v318_11_origin + 1)..(v318_11_origin + 2)], &(v321_6), &v318_11_cursor);
          compose(&(v322_5),&(v323_6))
        };
        drop(v322_5);
        let v322_8: Space = intersect(&(*CONSTANT_7),&(v322_2));
        drop(v322_2);
        let v322_9: Space = if has_head(&(v322_8)) { singleton(&[]) } else { Space::new() };
        drop(v322_8);
        let v322_11: Space = if (&(v322_9)).is_empty() { Space::new() } else {
          let mut v324_10 = Space::new();
          let mut v324_10_write = v324_10.write_zipper();
          for v324_10_byte in v318_11_cursor.child_mask().iter() {
            v318_11_cursor.descend_to_existing_byte(v324_10_byte);
            {
            let v325_2: Space = singleton(&v318_11_cursor.path()[(v318_11_origin + 2)..(v318_11_origin + 3)]);
            let v325_3: Space = intersect(&(*CONSTANT_7),&(v325_2));
            let v325_4: Space = if has_head(&(v325_3)) { singleton(&[]) } else { Space::new() };
            drop(v325_3);
            let v325_5: Space = subtract(&(*CONSTANT_0),&(v325_4));
            drop(v325_4);
            let v325_7: Space = if (&(v325_5)).is_empty() { Space::new() } else {
              let v326_6: Space = routine_36(c, &v318_11_cursor.path()[(v318_11_origin + 2)..(v318_11_origin + 3)], &(v321_6), &v318_11_cursor.path()[(v318_11_origin + 1)..(v318_11_origin + 2)], &v318_11_cursor);
              compose(&(v325_5),&(v326_6))
            };
            drop(v325_5);
            let v325_8: Space = intersect(&(*CONSTANT_7),&(v325_2));
            drop(v325_2);
            let v325_9: Space = if has_head(&(v325_8)) { singleton(&[]) } else { Space::new() };
            drop(v325_8);
            let v325_11: Space = if (&(v325_9)).is_empty() { Space::new() } else {
              let v327_10: Space = routine_37(c, &v318_11_cursor.path()[(v318_11_origin + 2)..(v318_11_origin + 3)], &(v321_6), &v318_11_cursor.path()[(v318_11_origin + 1)..(v318_11_origin + 2)], &v318_11_cursor);
              compose(&(v325_9),&(v327_10))
            };
            drop(v325_9);
            let v325_12: Space = unite(&(v325_7),&(v325_11));
            join_wrapped_into(&mut v324_10_write,&((v325_12).read_zipper()),&[]);
            }
            v318_11_cursor.ascend(1);
          }
          drop(v324_10_write);
          compose(&(v322_9),&(v324_10))
        };
        drop(v322_9);
        let v322_12: Space = unite(&(v322_7),&(v322_11));
        join_wrapped_into(&mut v321_11_write,&((v322_12).read_zipper()),&[]);
        }
        v318_11_cursor.ascend(1);
      }
      drop(v321_11_write);
      drop(v321_6);
      compose(&(v319_10),&(v321_11))
    };
    drop(v319_10);
    let v319_13: Space = unite(&(v319_8),&(v319_12));
    join_wrapped_into(&mut v318_11_write,&((v319_13).read_zipper()),&[]);
    }
    v318_11_cursor.ascend(1);
  }
  drop(v318_11_cursor);
  drop(v318_11_write);
  (v318_11).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v328_13: Path = concat_path(&(*CONSTANT_17),&(*p1));
  let v328_14: Space = singleton(&(v328_13));
  drop(v328_13);
  let mut v328_15 = Space::new();
  let mut v328_15_write = v328_15.write_zipper();
  let mut v328_15_cursor = (*s0).read_zipper();
  let v328_15_origin = v328_15_cursor.path().len();
  for v328_15_byte in v328_15_cursor.child_mask().iter() {
    v328_15_cursor.descend_to_existing_byte(v328_15_byte);
    {
    let v329_2: Space = singleton(&v328_15_cursor.path()[v328_15_origin..(v328_15_origin + 1)]);
    let v329_3: Space = intersect(&(*CONSTANT_7),&(v329_2));
    let v329_4: Space = if has_head(&(v329_3)) { singleton(&[]) } else { Space::new() };
    drop(v329_3);
    let v329_5: Space = subtract(&(*CONSTANT_0),&(v329_4));
    drop(v329_4);
    let v329_8: Space = if (&(v329_5)).is_empty() { Space::new() } else {
      let v330_6: Path = concat_path(&(*p0),&v328_15_cursor.path()[v328_15_origin..(v328_15_origin + 1)]);
      let v330_7: Space = routine_22(c, &(v330_6), &(*p1), &v328_15_cursor);
      compose(&(v329_5),&(v330_7))
    };
    drop(v329_5);
    let v329_9: Space = intersect(&(*CONSTANT_7),&(v329_2));
    drop(v329_2);
    let v329_10: Space = if has_head(&(v329_9)) { singleton(&[]) } else { Space::new() };
    drop(v329_9);
    let v329_15: Space = if (&(v329_10)).is_empty() { Space::new() } else {
      let v331_6: Path = concat_path(&(*p0),&v328_15_cursor.path()[v328_15_origin..(v328_15_origin + 1)]);
      let v331_11: Path = concat_path(&(*CONSTANT_19),&(v331_6));
      let v331_12: Space = singleton(&(v331_11));
      drop(v331_11);
      let v331_13: Space = unite(&(*CONSTANT_26),&(v331_12));
      drop(v331_12);
      let mut v331_14 = Space::new();
      let mut v331_14_write = v331_14.write_zipper();
      for v331_14_byte in v328_15_cursor.child_mask().iter() {
        v328_15_cursor.descend_to_existing_byte(v331_14_byte);
        {
        let v332_2: Space = singleton(&v328_15_cursor.path()[(v328_15_origin + 1)..(v328_15_origin + 2)]);
        let v332_3: Space = intersect(&(*CONSTANT_7),&(v332_2));
        let v332_4: Space = if has_head(&(v332_3)) { singleton(&[]) } else { Space::new() };
        drop(v332_3);
        let v332_5: Space = subtract(&(*CONSTANT_0),&(v332_4));
        drop(v332_4);
        let v332_7: Space = if (&(v332_5)).is_empty() { Space::new() } else {
          let v333_6: Space = routine_36(c, &v328_15_cursor.path()[(v328_15_origin + 1)..(v328_15_origin + 2)], &(*p1), &(v331_6), &v328_15_cursor);
          compose(&(v332_5),&(v333_6))
        };
        drop(v332_5);
        let v332_8: Space = intersect(&(*CONSTANT_7),&(v332_2));
        drop(v332_2);
        let v332_9: Space = if has_head(&(v332_8)) { singleton(&[]) } else { Space::new() };
        drop(v332_8);
        let v332_14: Space = if (&(v332_9)).is_empty() { Space::new() } else {
          let v334_10: Path = concat_path(&(*CONSTANT_18),&v328_15_cursor.path()[(v328_15_origin + 1)..(v328_15_origin + 2)]);
          let v334_11: Space = singleton(&(v334_10));
          drop(v334_10);
          let v334_12: Space = unite(&(v331_13),&(v334_11));
          drop(v334_11);
          let v334_13: Space = unite(&(v334_12),&(v328_14));
          drop(v334_12);
          compose(&(v332_9),&(v334_13))
        };
        drop(v332_9);
        let v332_15: Space = unite(&(v332_7),&(v332_14));
        drop(v332_14);
        join_wrapped_into(&mut v331_14_write,&((v332_15).read_zipper()),&[]);
        }
        v328_15_cursor.ascend(1);
      }
      drop(v331_14_write);
      drop(v331_6);
      drop(v331_13);
      compose(&(v329_10),&(v331_14))
    };
    drop(v329_10);
    let v329_16: Space = unite(&(v329_8),&(v329_15));
    join_wrapped_into(&mut v328_15_write,&((v329_16).read_zipper()),&[]);
    }
    v328_15_cursor.ascend(1);
  }
  drop(v328_15_cursor);
  drop(v328_15_write);
  drop(v328_14);
  (v328_15).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v335_8: Path = concat_path(&(*CONSTANT_19),&(*p0));
  let v335_9: Space = singleton(&(v335_8));
  drop(v335_8);
  let v335_10: Space = unite(&(*CONSTANT_26),&(v335_9));
  let v335_13: Path = concat_path(&(*CONSTANT_17),&(*p1));
  let v335_14: Space = singleton(&(v335_13));
  drop(v335_13);
  let v335_19: Space = unite(&(*CONSTANT_26),&(v335_9));
  drop(v335_9);
  let mut v335_20 = Space::new();
  let mut v335_20_write = v335_20.write_zipper();
  let mut v335_20_cursor = (*s0).read_zipper();
  let v335_20_origin = v335_20_cursor.path().len();
  for v335_20_byte in v335_20_cursor.child_mask().iter() {
    v335_20_cursor.descend_to_existing_byte(v335_20_byte);
    {
    let v336_2: Space = singleton(&v335_20_cursor.path()[v335_20_origin..(v335_20_origin + 1)]);
    let v336_3: Space = intersect(&(*CONSTANT_7),&(v336_2));
    let v336_4: Space = if has_head(&(v336_3)) { singleton(&[]) } else { Space::new() };
    drop(v336_3);
    let v336_5: Space = subtract(&(*CONSTANT_0),&(v336_4));
    drop(v336_4);
    let v336_7: Space = if (&(v336_5)).is_empty() { Space::new() } else {
      let mut v337_6 = Space::new();
      let mut v337_6_write = v337_6.write_zipper();
      for v337_6_byte in v335_20_cursor.child_mask().iter() {
        v335_20_cursor.descend_to_existing_byte(v337_6_byte);
        {
        let v338_2: Space = singleton(&v335_20_cursor.path()[(v335_20_origin + 1)..(v335_20_origin + 2)]);
        let v338_3: Space = intersect(&(*CONSTANT_7),&(v338_2));
        let v338_4: Space = if has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
        drop(v338_3);
        let v338_5: Space = subtract(&(*CONSTANT_0),&(v338_4));
        drop(v338_4);
        let v338_8: Space = if (&(v338_5)).is_empty() { Space::new() } else {
          let v339_7: Space = routine_36(c, &v335_20_cursor.path()[v335_20_origin..(v335_20_origin + 2)], &(*p1), &(*p0), &v335_20_cursor);
          compose(&(v338_5),&(v339_7))
        };
        drop(v338_5);
        let v338_9: Space = intersect(&(*CONSTANT_7),&(v338_2));
        drop(v338_2);
        let v338_10: Space = if has_head(&(v338_9)) { singleton(&[]) } else { Space::new() };
        drop(v338_9);
        let v338_15: Space = if (&(v338_10)).is_empty() { Space::new() } else {
          let v340_11: Path = concat_path(&(*CONSTANT_18),&v335_20_cursor.path()[v335_20_origin..(v335_20_origin + 2)]);
          let v340_12: Space = singleton(&(v340_11));
          drop(v340_11);
          let v340_13: Space = unite(&(v335_19),&(v340_12));
          drop(v340_12);
          let v340_14: Space = unite(&(v340_13),&(v335_14));
          drop(v340_13);
          compose(&(v338_10),&(v340_14))
        };
        drop(v338_10);
        let v338_16: Space = unite(&(v338_8),&(v338_15));
        drop(v338_15);
        join_wrapped_into(&mut v337_6_write,&((v338_16).read_zipper()),&[]);
        }
        v335_20_cursor.ascend(1);
      }
      drop(v337_6_write);
      compose(&(v336_5),&(v337_6))
    };
    drop(v336_5);
    let v336_8: Space = intersect(&(*CONSTANT_7),&(v336_2));
    drop(v336_2);
    let v336_9: Space = if has_head(&(v336_8)) { singleton(&[]) } else { Space::new() };
    drop(v336_8);
    let v336_14: Space = if (&(v336_9)).is_empty() { Space::new() } else {
      let v341_10: Path = concat_path(&(*CONSTANT_18),&v335_20_cursor.path()[v335_20_origin..(v335_20_origin + 1)]);
      let v341_11: Space = singleton(&(v341_10));
      drop(v341_10);
      let v341_12: Space = unite(&(v335_10),&(v341_11));
      drop(v341_11);
      let v341_13: Space = unite(&(v341_12),&(v335_14));
      drop(v341_12);
      compose(&(v336_9),&(v341_13))
    };
    drop(v336_9);
    let v336_15: Space = unite(&(v336_7),&(v336_14));
    drop(v336_14);
    join_wrapped_into(&mut v335_20_write,&((v336_15).read_zipper()),&[]);
    }
    v335_20_cursor.ascend(1);
  }
  drop(v335_20_cursor);
  drop(v335_20_write);
  drop(v335_10);
  drop(v335_14);
  drop(v335_19);
  (v335_20).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v342_5 = Space::new();
  let mut v342_5_write = v342_5.write_zipper();
  let mut v342_5_cursor = (*s0).read_zipper();
  let v342_5_origin = v342_5_cursor.path().len();
  for v342_5_byte in v342_5_cursor.child_mask().iter() {
    v342_5_cursor.descend_to_existing_byte(v342_5_byte);
    {
    let v343_2: Space = singleton(&v342_5_cursor.path()[v342_5_origin..(v342_5_origin + 1)]);
    let v343_3: Space = intersect(&(*CONSTANT_7),&(v343_2));
    let v343_4: Space = if has_head(&(v343_3)) { singleton(&[]) } else { Space::new() };
    drop(v343_3);
    let v343_5: Space = subtract(&(*CONSTANT_0),&(v343_4));
    drop(v343_4);
    let v343_8: Space = if (&(v343_5)).is_empty() { Space::new() } else {
      let v344_6: Path = concat_path(&(*p0),&v342_5_cursor.path()[v342_5_origin..(v342_5_origin + 1)]);
      let v344_7: Space = routine_24(c, &(v344_6), &v342_5_cursor);
      drop(v344_6);
      compose(&(v343_5),&(v344_7))
    };
    drop(v343_5);
    let v343_9: Space = intersect(&(*CONSTANT_7),&(v343_2));
    drop(v343_2);
    let v343_10: Space = if has_head(&(v343_9)) { singleton(&[]) } else { Space::new() };
    drop(v343_9);
    let v343_11: Space = compose(&(v343_10),&v342_5_cursor);
    drop(v343_10);
    let v343_12: Space = unite(&(v343_8),&(v343_11));
    drop(v343_11);
    join_wrapped_into(&mut v342_5_write,&((v343_12).read_zipper()),&[]);
    }
    v342_5_cursor.ascend(1);
  }
  drop(v342_5_cursor);
  drop(v342_5_write);
  (v342_5).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v345_11 = Space::new();
  let mut v345_11_write = v345_11.write_zipper();
  let mut v345_11_cursor = (*s0).read_zipper();
  let v345_11_origin = v345_11_cursor.path().len();
  for v345_11_byte in v345_11_cursor.child_mask().iter() {
    v345_11_cursor.descend_to_existing_byte(v345_11_byte);
    {
    let v346_2: Space = singleton(&v345_11_cursor.path()[v345_11_origin..(v345_11_origin + 1)]);
    let v346_3: Space = intersect(&(*CONSTANT_7),&(v346_2));
    let v346_4: Space = if has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
    drop(v346_3);
    let v346_5: Space = subtract(&(*CONSTANT_0),&(v346_4));
    drop(v346_4);
    let v346_8: Space = if (&(v346_5)).is_empty() { Space::new() } else {
      let v347_6: Path = concat_path(&(*p0),&v345_11_cursor.path()[v345_11_origin..(v345_11_origin + 1)]);
      let v347_7: Space = routine_25(c, &(v347_6), &v345_11_cursor);
      compose(&(v346_5),&(v347_7))
    };
    drop(v346_5);
    let v346_9: Space = intersect(&(*CONSTANT_7),&(v346_2));
    drop(v346_2);
    let v346_10: Space = if has_head(&(v346_9)) { singleton(&[]) } else { Space::new() };
    drop(v346_9);
    let v346_12: Space = if (&(v346_10)).is_empty() { Space::new() } else {
      let v348_6: Path = concat_path(&(*p0),&v345_11_cursor.path()[v345_11_origin..(v345_11_origin + 1)]);
      let mut v348_11 = Space::new();
      let mut v348_11_write = v348_11.write_zipper();
      for v348_11_byte in v345_11_cursor.child_mask().iter() {
        v345_11_cursor.descend_to_existing_byte(v348_11_byte);
        {
        let v349_2: Space = singleton(&v345_11_cursor.path()[(v345_11_origin + 1)..(v345_11_origin + 2)]);
        let v349_3: Space = intersect(&(*CONSTANT_7),&(v349_2));
        let v349_4: Space = if has_head(&(v349_3)) { singleton(&[]) } else { Space::new() };
        drop(v349_3);
        let v349_5: Space = subtract(&(*CONSTANT_0),&(v349_4));
        drop(v349_4);
        let v349_7: Space = if (&(v349_5)).is_empty() { Space::new() } else {
          let v350_6: Space = routine_26(c, &v345_11_cursor.path()[(v345_11_origin + 1)..(v345_11_origin + 2)], &(v348_6), &v345_11_cursor);
          compose(&(v349_5),&(v350_6))
        };
        drop(v349_5);
        let v349_8: Space = intersect(&(*CONSTANT_7),&(v349_2));
        drop(v349_2);
        let v349_9: Space = if has_head(&(v349_8)) { singleton(&[]) } else { Space::new() };
        drop(v349_8);
        let v349_11: Space = if (&(v349_9)).is_empty() { Space::new() } else {
          let mut v351_10 = Space::new();
          let mut v351_10_write = v351_10.write_zipper();
          for v351_10_byte in v345_11_cursor.child_mask().iter() {
            v345_11_cursor.descend_to_existing_byte(v351_10_byte);
            {
            let v352_2: Space = singleton(&v345_11_cursor.path()[(v345_11_origin + 2)..(v345_11_origin + 3)]);
            let v352_3: Space = intersect(&(*CONSTANT_7),&(v352_2));
            let v352_4: Space = if has_head(&(v352_3)) { singleton(&[]) } else { Space::new() };
            drop(v352_3);
            let v352_5: Space = subtract(&(*CONSTANT_0),&(v352_4));
            drop(v352_4);
            let v352_7: Space = if (&(v352_5)).is_empty() { Space::new() } else {
              let v353_6: Space = routine_38(c, &v345_11_cursor.path()[(v345_11_origin + 2)..(v345_11_origin + 3)], &(v348_6), &v345_11_cursor.path()[(v345_11_origin + 1)..(v345_11_origin + 2)], &v345_11_cursor);
              compose(&(v352_5),&(v353_6))
            };
            drop(v352_5);
            let v352_8: Space = intersect(&(*CONSTANT_7),&(v352_2));
            drop(v352_2);
            let v352_9: Space = if has_head(&(v352_8)) { singleton(&[]) } else { Space::new() };
            drop(v352_8);
            let v352_11: Space = if (&(v352_9)).is_empty() { Space::new() } else {
              let v354_10: Space = routine_39(c, &v345_11_cursor.path()[(v345_11_origin + 2)..(v345_11_origin + 3)], &(v348_6), &v345_11_cursor.path()[(v345_11_origin + 1)..(v345_11_origin + 2)], &v345_11_cursor);
              compose(&(v352_9),&(v354_10))
            };
            drop(v352_9);
            let v352_12: Space = unite(&(v352_7),&(v352_11));
            join_wrapped_into(&mut v351_10_write,&((v352_12).read_zipper()),&[]);
            }
            v345_11_cursor.ascend(1);
          }
          drop(v351_10_write);
          compose(&(v349_9),&(v351_10))
        };
        drop(v349_9);
        let v349_12: Space = unite(&(v349_7),&(v349_11));
        join_wrapped_into(&mut v348_11_write,&((v349_12).read_zipper()),&[]);
        }
        v345_11_cursor.ascend(1);
      }
      drop(v348_11_write);
      drop(v348_6);
      compose(&(v346_10),&(v348_11))
    };
    drop(v346_10);
    let v346_13: Space = unite(&(v346_8),&(v346_12));
    join_wrapped_into(&mut v345_11_write,&((v346_13).read_zipper()),&[]);
    }
    v345_11_cursor.ascend(1);
  }
  drop(v345_11_cursor);
  drop(v345_11_write);
  (v345_11).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v355_13: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v355_14: Space = singleton(&(v355_13));
  drop(v355_13);
  let mut v355_15 = Space::new();
  let mut v355_15_write = v355_15.write_zipper();
  let mut v355_15_cursor = (*s0).read_zipper();
  let v355_15_origin = v355_15_cursor.path().len();
  for v355_15_byte in v355_15_cursor.child_mask().iter() {
    v355_15_cursor.descend_to_existing_byte(v355_15_byte);
    {
    let v356_2: Space = singleton(&v355_15_cursor.path()[v355_15_origin..(v355_15_origin + 1)]);
    let v356_3: Space = intersect(&(*CONSTANT_7),&(v356_2));
    let v356_4: Space = if has_head(&(v356_3)) { singleton(&[]) } else { Space::new() };
    drop(v356_3);
    let v356_5: Space = subtract(&(*CONSTANT_0),&(v356_4));
    drop(v356_4);
    let v356_8: Space = if (&(v356_5)).is_empty() { Space::new() } else {
      let v357_6: Path = concat_path(&(*p0),&v355_15_cursor.path()[v355_15_origin..(v355_15_origin + 1)]);
      let v357_7: Space = routine_26(c, &(v357_6), &(*p1), &v355_15_cursor);
      compose(&(v356_5),&(v357_7))
    };
    drop(v356_5);
    let v356_9: Space = intersect(&(*CONSTANT_7),&(v356_2));
    drop(v356_2);
    let v356_10: Space = if has_head(&(v356_9)) { singleton(&[]) } else { Space::new() };
    drop(v356_9);
    let v356_15: Space = if (&(v356_10)).is_empty() { Space::new() } else {
      let v358_6: Path = concat_path(&(*p0),&v355_15_cursor.path()[v355_15_origin..(v355_15_origin + 1)]);
      let v358_11: Path = concat_path(&(*CONSTANT_19),&(v358_6));
      let v358_12: Space = singleton(&(v358_11));
      drop(v358_11);
      let v358_13: Space = unite(&(*CONSTANT_27),&(v358_12));
      drop(v358_12);
      let mut v358_14 = Space::new();
      let mut v358_14_write = v358_14.write_zipper();
      for v358_14_byte in v355_15_cursor.child_mask().iter() {
        v355_15_cursor.descend_to_existing_byte(v358_14_byte);
        {
        let v359_2: Space = singleton(&v355_15_cursor.path()[(v355_15_origin + 1)..(v355_15_origin + 2)]);
        let v359_3: Space = intersect(&(*CONSTANT_7),&(v359_2));
        let v359_4: Space = if has_head(&(v359_3)) { singleton(&[]) } else { Space::new() };
        drop(v359_3);
        let v359_5: Space = subtract(&(*CONSTANT_0),&(v359_4));
        drop(v359_4);
        let v359_7: Space = if (&(v359_5)).is_empty() { Space::new() } else {
          let v360_6: Space = routine_38(c, &v355_15_cursor.path()[(v355_15_origin + 1)..(v355_15_origin + 2)], &(*p1), &(v358_6), &v355_15_cursor);
          compose(&(v359_5),&(v360_6))
        };
        drop(v359_5);
        let v359_8: Space = intersect(&(*CONSTANT_7),&(v359_2));
        drop(v359_2);
        let v359_9: Space = if has_head(&(v359_8)) { singleton(&[]) } else { Space::new() };
        drop(v359_8);
        let v359_14: Space = if (&(v359_9)).is_empty() { Space::new() } else {
          let v361_10: Path = concat_path(&(*CONSTANT_18),&v355_15_cursor.path()[(v355_15_origin + 1)..(v355_15_origin + 2)]);
          let v361_11: Space = singleton(&(v361_10));
          drop(v361_10);
          let v361_12: Space = unite(&(v358_13),&(v361_11));
          drop(v361_11);
          let v361_13: Space = unite(&(v361_12),&(v355_14));
          drop(v361_12);
          compose(&(v359_9),&(v361_13))
        };
        drop(v359_9);
        let v359_15: Space = unite(&(v359_7),&(v359_14));
        drop(v359_14);
        join_wrapped_into(&mut v358_14_write,&((v359_15).read_zipper()),&[]);
        }
        v355_15_cursor.ascend(1);
      }
      drop(v358_14_write);
      drop(v358_6);
      drop(v358_13);
      compose(&(v356_10),&(v358_14))
    };
    drop(v356_10);
    let v356_16: Space = unite(&(v356_8),&(v356_15));
    join_wrapped_into(&mut v355_15_write,&((v356_16).read_zipper()),&[]);
    }
    v355_15_cursor.ascend(1);
  }
  drop(v355_15_cursor);
  drop(v355_15_write);
  drop(v355_14);
  (v355_15).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v362_8: Path = concat_path(&(*CONSTANT_19),&(*p0));
  let v362_9: Space = singleton(&(v362_8));
  drop(v362_8);
  let v362_10: Space = unite(&(*CONSTANT_27),&(v362_9));
  let v362_13: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v362_14: Space = singleton(&(v362_13));
  drop(v362_13);
  let v362_19: Space = unite(&(*CONSTANT_27),&(v362_9));
  drop(v362_9);
  let mut v362_20 = Space::new();
  let mut v362_20_write = v362_20.write_zipper();
  let mut v362_20_cursor = (*s0).read_zipper();
  let v362_20_origin = v362_20_cursor.path().len();
  for v362_20_byte in v362_20_cursor.child_mask().iter() {
    v362_20_cursor.descend_to_existing_byte(v362_20_byte);
    {
    let v363_2: Space = singleton(&v362_20_cursor.path()[v362_20_origin..(v362_20_origin + 1)]);
    let v363_3: Space = intersect(&(*CONSTANT_7),&(v363_2));
    let v363_4: Space = if has_head(&(v363_3)) { singleton(&[]) } else { Space::new() };
    drop(v363_3);
    let v363_5: Space = subtract(&(*CONSTANT_0),&(v363_4));
    drop(v363_4);
    let v363_7: Space = if (&(v363_5)).is_empty() { Space::new() } else {
      let mut v364_6 = Space::new();
      let mut v364_6_write = v364_6.write_zipper();
      for v364_6_byte in v362_20_cursor.child_mask().iter() {
        v362_20_cursor.descend_to_existing_byte(v364_6_byte);
        {
        let v365_2: Space = singleton(&v362_20_cursor.path()[(v362_20_origin + 1)..(v362_20_origin + 2)]);
        let v365_3: Space = intersect(&(*CONSTANT_7),&(v365_2));
        let v365_4: Space = if has_head(&(v365_3)) { singleton(&[]) } else { Space::new() };
        drop(v365_3);
        let v365_5: Space = subtract(&(*CONSTANT_0),&(v365_4));
        drop(v365_4);
        let v365_8: Space = if (&(v365_5)).is_empty() { Space::new() } else {
          let v366_7: Space = routine_38(c, &v362_20_cursor.path()[v362_20_origin..(v362_20_origin + 2)], &(*p1), &(*p0), &v362_20_cursor);
          compose(&(v365_5),&(v366_7))
        };
        drop(v365_5);
        let v365_9: Space = intersect(&(*CONSTANT_7),&(v365_2));
        drop(v365_2);
        let v365_10: Space = if has_head(&(v365_9)) { singleton(&[]) } else { Space::new() };
        drop(v365_9);
        let v365_15: Space = if (&(v365_10)).is_empty() { Space::new() } else {
          let v367_11: Path = concat_path(&(*CONSTANT_18),&v362_20_cursor.path()[v362_20_origin..(v362_20_origin + 2)]);
          let v367_12: Space = singleton(&(v367_11));
          drop(v367_11);
          let v367_13: Space = unite(&(v362_19),&(v367_12));
          drop(v367_12);
          let v367_14: Space = unite(&(v367_13),&(v362_14));
          drop(v367_13);
          compose(&(v365_10),&(v367_14))
        };
        drop(v365_10);
        let v365_16: Space = unite(&(v365_8),&(v365_15));
        drop(v365_15);
        join_wrapped_into(&mut v364_6_write,&((v365_16).read_zipper()),&[]);
        }
        v362_20_cursor.ascend(1);
      }
      drop(v364_6_write);
      compose(&(v363_5),&(v364_6))
    };
    drop(v363_5);
    let v363_8: Space = intersect(&(*CONSTANT_7),&(v363_2));
    drop(v363_2);
    let v363_9: Space = if has_head(&(v363_8)) { singleton(&[]) } else { Space::new() };
    drop(v363_8);
    let v363_14: Space = if (&(v363_9)).is_empty() { Space::new() } else {
      let v368_10: Path = concat_path(&(*CONSTANT_18),&v362_20_cursor.path()[v362_20_origin..(v362_20_origin + 1)]);
      let v368_11: Space = singleton(&(v368_10));
      drop(v368_10);
      let v368_12: Space = unite(&(v362_10),&(v368_11));
      drop(v368_11);
      let v368_13: Space = unite(&(v368_12),&(v362_14));
      drop(v368_12);
      compose(&(v363_9),&(v368_13))
    };
    drop(v363_9);
    let v363_15: Space = unite(&(v363_7),&(v363_14));
    drop(v363_14);
    join_wrapped_into(&mut v362_20_write,&((v363_15).read_zipper()),&[]);
    }
    v362_20_cursor.ascend(1);
  }
  drop(v362_20_cursor);
  drop(v362_20_write);
  drop(v362_10);
  drop(v362_14);
  drop(v362_19);
  (v362_20).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v369_12 = Space::new();
  let mut v369_12_write = v369_12.write_zipper();
  let mut v369_12_cursor = (*s0).read_zipper();
  let v369_12_origin = v369_12_cursor.path().len();
  for v369_12_byte in v369_12_cursor.child_mask().iter() {
    v369_12_cursor.descend_to_existing_byte(v369_12_byte);
    {
    let v370_2: Space = singleton(&v369_12_cursor.path()[v369_12_origin..(v369_12_origin + 1)]);
    let v370_3: Space = intersect(&(*CONSTANT_7),&(v370_2));
    let v370_4: Space = if has_head(&(v370_3)) { singleton(&[]) } else { Space::new() };
    drop(v370_3);
    let v370_5: Space = subtract(&(*CONSTANT_0),&(v370_4));
    drop(v370_4);
    let v370_8: Space = if (&(v370_5)).is_empty() { Space::new() } else {
      let v371_6: Path = concat_path(&(*p0),&v369_12_cursor.path()[v369_12_origin..(v369_12_origin + 1)]);
      let v371_7: Space = routine_28(c, &(v371_6), &v369_12_cursor);
      compose(&(v370_5),&(v371_7))
    };
    drop(v370_5);
    let v370_9: Space = intersect(&(*CONSTANT_7),&(v370_2));
    drop(v370_2);
    let v370_10: Space = if has_head(&(v370_9)) { singleton(&[]) } else { Space::new() };
    drop(v370_9);
    let v370_12: Space = if (&(v370_10)).is_empty() { Space::new() } else {
      let v372_6: Path = concat_path(&(*p0),&v369_12_cursor.path()[v369_12_origin..(v369_12_origin + 1)]);
      let mut v372_11 = Space::new();
      let mut v372_11_write = v372_11.write_zipper();
      for v372_11_byte in v369_12_cursor.child_mask().iter() {
        v369_12_cursor.descend_to_existing_byte(v372_11_byte);
        {
        let v373_2: Space = singleton(&v369_12_cursor.path()[(v369_12_origin + 1)..(v369_12_origin + 2)]);
        let v373_3: Space = intersect(&(*CONSTANT_7),&(v373_2));
        let v373_4: Space = if has_head(&(v373_3)) { singleton(&[]) } else { Space::new() };
        drop(v373_3);
        let v373_5: Space = subtract(&(*CONSTANT_0),&(v373_4));
        drop(v373_4);
        let v373_7: Space = if (&(v373_5)).is_empty() { Space::new() } else {
          let v374_6: Space = routine_40(c, &v369_12_cursor.path()[(v369_12_origin + 1)..(v369_12_origin + 2)], &(v372_6), &v369_12_cursor);
          compose(&(v373_5),&(v374_6))
        };
        drop(v373_5);
        let v373_8: Space = intersect(&(*CONSTANT_7),&(v373_2));
        drop(v373_2);
        let v373_9: Space = if has_head(&(v373_8)) { singleton(&[]) } else { Space::new() };
        drop(v373_8);
        let v373_13: Space = if (&(v373_9)).is_empty() { Space::new() } else {
          let mut v375_10 = Space::new();
          let mut v375_10_write = v375_10.write_zipper();
          for v375_10_byte in v369_12_cursor.child_mask().iter() {
            v369_12_cursor.descend_to_existing_byte(v375_10_byte);
            {
            let v376_2: Space = singleton(&v369_12_cursor.path()[(v369_12_origin + 2)..(v369_12_origin + 3)]);
            let v376_3: Space = intersect(&(*CONSTANT_7),&(v376_2));
            let v376_4: Space = if has_head(&(v376_3)) { singleton(&[]) } else { Space::new() };
            drop(v376_3);
            let v376_5: Space = subtract(&(*CONSTANT_0),&(v376_4));
            drop(v376_4);
            let v376_7: Space = if (&(v376_5)).is_empty() { Space::new() } else {
              let v377_6: Space = routine_41(c, &v369_12_cursor.path()[(v369_12_origin + 2)..(v369_12_origin + 3)], &v369_12_cursor);
              compose(&(v376_5),&(v377_6))
            };
            drop(v376_5);
            let v376_8: Space = intersect(&(*CONSTANT_7),&(v376_2));
            drop(v376_2);
            let v376_9: Space = if has_head(&(v376_8)) { singleton(&[]) } else { Space::new() };
            drop(v376_8);
            let v376_11: Space = if (&(v376_9)).is_empty() { Space::new() } else {
              let v378_10: Space = routine_42(c, &v369_12_cursor.path()[(v369_12_origin + 2)..(v369_12_origin + 3)], &v369_12_cursor);
              compose(&(v376_9),&(v378_10))
            };
            drop(v376_9);
            let v376_12: Space = unite(&(v376_7),&(v376_11));
            join_wrapped_into(&mut v375_10_write,&((v376_12).read_zipper()),&[]);
            }
            v369_12_cursor.ascend(1);
          }
          drop(v375_10_write);
          let v375_11: Space = raffine(&(*CONSTANT_28),&(v375_10));
          let v375_12: Space = unite(&(v375_11),&v369_12_cursor);
          compose(&(v373_9),&(v375_12))
        };
        drop(v373_9);
        let v373_14: Path = concat_path(&(v372_6),&v369_12_cursor.path()[(v369_12_origin + 1)..(v369_12_origin + 2)]);
        let v373_15: Space = wrap(&(v373_13),&(v373_14));
        drop(v373_14);
        let v373_16: Space = unite(&(v373_7),&(v373_15));
        join_wrapped_into(&mut v372_11_write,&((v373_16).read_zipper()),&[]);
        }
        v369_12_cursor.ascend(1);
      }
      drop(v372_11_write);
      drop(v372_6);
      compose(&(v370_10),&(v372_11))
    };
    drop(v370_10);
    let v370_13: Space = unite(&(v370_8),&(v370_12));
    join_wrapped_into(&mut v369_12_write,&((v370_13).read_zipper()),&[]);
    }
    v369_12_cursor.ascend(1);
  }
  drop(v369_12_cursor);
  drop(v369_12_write);
  (v369_12).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v379_7 = Space::new();
  let mut v379_7_write = v379_7.write_zipper();
  let mut v379_7_cursor = (*s0).read_zipper();
  let v379_7_origin = v379_7_cursor.path().len();
  for v379_7_byte in v379_7_cursor.child_mask().iter() {
    v379_7_cursor.descend_to_existing_byte(v379_7_byte);
    {
    let v380_2: Space = singleton(&v379_7_cursor.path()[v379_7_origin..(v379_7_origin + 1)]);
    let v380_3: Space = intersect(&(*CONSTANT_7),&(v380_2));
    let v380_4: Space = if has_head(&(v380_3)) { singleton(&[]) } else { Space::new() };
    drop(v380_3);
    let v380_5: Space = subtract(&(*CONSTANT_0),&(v380_4));
    drop(v380_4);
    let v380_8: Space = if (&(v380_5)).is_empty() { Space::new() } else {
      let v381_6: Path = concat_path(&(*p0),&v379_7_cursor.path()[v379_7_origin..(v379_7_origin + 1)]);
      let v381_7: Space = routine_29(c, &(v381_6), &(*p1), &v379_7_cursor, &(*s1));
      compose(&(v380_5),&(v381_7))
    };
    drop(v380_5);
    let v380_9: Space = intersect(&(*CONSTANT_7),&(v380_2));
    drop(v380_2);
    let v380_10: Space = if has_head(&(v380_9)) { singleton(&[]) } else { Space::new() };
    drop(v380_9);
    let v380_14: Space = if (&(v380_10)).is_empty() { Space::new() } else {
      let v382_6: Path = concat_path(&(*p0),&v379_7_cursor.path()[v379_7_origin..(v379_7_origin + 1)]);
      let v382_12: Space = wrap(&(descend_cursor(cursor_at(&v379_7_cursor,(v379_7_origin + 1)),&(*p1))),&(v382_6));
      drop(v382_6);
      let v382_13: Space = compose(&(v382_12),&(*s1));
      drop(v382_12);
      compose(&(v380_10),&(v382_13))
    };
    drop(v380_10);
    let v380_15: Space = unite(&(v380_8),&(v380_14));
    drop(v380_14);
    join_wrapped_into(&mut v379_7_write,&((v380_15).read_zipper()),&[]);
    }
    v379_7_cursor.ascend(1);
  }
  drop(v379_7_cursor);
  drop(v379_7_write);
  (v379_7).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v383_12 = Space::new();
  let mut v383_12_write = v383_12.write_zipper();
  let mut v383_12_cursor = (*s0).read_zipper();
  let v383_12_origin = v383_12_cursor.path().len();
  for v383_12_byte in v383_12_cursor.child_mask().iter() {
    v383_12_cursor.descend_to_existing_byte(v383_12_byte);
    {
    let v384_2: Space = singleton(&v383_12_cursor.path()[v383_12_origin..(v383_12_origin + 1)]);
    let v384_3: Space = intersect(&(*CONSTANT_7),&(v384_2));
    let v384_4: Space = if has_head(&(v384_3)) { singleton(&[]) } else { Space::new() };
    drop(v384_3);
    let v384_5: Space = subtract(&(*CONSTANT_0),&(v384_4));
    drop(v384_4);
    let v384_8: Space = if (&(v384_5)).is_empty() { Space::new() } else {
      let v385_6: Path = concat_path(&(*p0),&v383_12_cursor.path()[v383_12_origin..(v383_12_origin + 1)]);
      let v385_7: Space = routine_30(c, &(v385_6), &v383_12_cursor);
      compose(&(v384_5),&(v385_7))
    };
    drop(v384_5);
    let v384_9: Space = intersect(&(*CONSTANT_7),&(v384_2));
    drop(v384_2);
    let v384_10: Space = if has_head(&(v384_9)) { singleton(&[]) } else { Space::new() };
    drop(v384_9);
    let v384_12: Space = if (&(v384_10)).is_empty() { Space::new() } else {
      let v386_6: Path = concat_path(&(*p0),&v383_12_cursor.path()[v383_12_origin..(v383_12_origin + 1)]);
      let mut v386_11 = Space::new();
      let mut v386_11_write = v386_11.write_zipper();
      for v386_11_byte in v383_12_cursor.child_mask().iter() {
        v383_12_cursor.descend_to_existing_byte(v386_11_byte);
        {
        let v387_2: Space = singleton(&v383_12_cursor.path()[(v383_12_origin + 1)..(v383_12_origin + 2)]);
        let v387_3: Space = intersect(&(*CONSTANT_7),&(v387_2));
        let v387_4: Space = if has_head(&(v387_3)) { singleton(&[]) } else { Space::new() };
        drop(v387_3);
        let v387_5: Space = subtract(&(*CONSTANT_0),&(v387_4));
        drop(v387_4);
        let v387_7: Space = if (&(v387_5)).is_empty() { Space::new() } else {
          let v388_6: Space = routine_43(c, &v383_12_cursor.path()[(v383_12_origin + 1)..(v383_12_origin + 2)], &(v386_6), &v383_12_cursor);
          compose(&(v387_5),&(v388_6))
        };
        drop(v387_5);
        let v387_8: Space = intersect(&(*CONSTANT_7),&(v387_2));
        drop(v387_2);
        let v387_9: Space = if has_head(&(v387_8)) { singleton(&[]) } else { Space::new() };
        drop(v387_8);
        let v387_13: Space = if (&(v387_9)).is_empty() { Space::new() } else {
          let mut v389_10 = Space::new();
          let mut v389_10_write = v389_10.write_zipper();
          for v389_10_byte in v383_12_cursor.child_mask().iter() {
            v383_12_cursor.descend_to_existing_byte(v389_10_byte);
            {
            let v390_2: Space = singleton(&v383_12_cursor.path()[(v383_12_origin + 2)..(v383_12_origin + 3)]);
            let v390_3: Space = intersect(&(*CONSTANT_7),&(v390_2));
            let v390_4: Space = if has_head(&(v390_3)) { singleton(&[]) } else { Space::new() };
            drop(v390_3);
            let v390_5: Space = subtract(&(*CONSTANT_0),&(v390_4));
            drop(v390_4);
            let v390_7: Space = if (&(v390_5)).is_empty() { Space::new() } else {
              let v391_6: Space = routine_44(c, &v383_12_cursor.path()[(v383_12_origin + 2)..(v383_12_origin + 3)], &v383_12_cursor);
              compose(&(v390_5),&(v391_6))
            };
            drop(v390_5);
            let v390_8: Space = intersect(&(*CONSTANT_7),&(v390_2));
            drop(v390_2);
            let v390_9: Space = if has_head(&(v390_8)) { singleton(&[]) } else { Space::new() };
            drop(v390_8);
            let v390_11: Space = if (&(v390_9)).is_empty() { Space::new() } else {
              let v392_10: Space = routine_45(c, &v383_12_cursor.path()[(v383_12_origin + 2)..(v383_12_origin + 3)], &v383_12_cursor);
              compose(&(v390_9),&(v392_10))
            };
            drop(v390_9);
            let v390_12: Space = unite(&(v390_7),&(v390_11));
            join_wrapped_into(&mut v389_10_write,&((v390_12).read_zipper()),&[]);
            }
            v383_12_cursor.ascend(1);
          }
          drop(v389_10_write);
          let v389_11: Space = raffine(&(*CONSTANT_28),&(v389_10));
          let v389_12: Space = unite(&(v389_11),&v383_12_cursor);
          compose(&(v387_9),&(v389_12))
        };
        drop(v387_9);
        let v387_14: Path = concat_path(&(v386_6),&v383_12_cursor.path()[(v383_12_origin + 1)..(v383_12_origin + 2)]);
        let v387_15: Space = wrap(&(v387_13),&(v387_14));
        drop(v387_14);
        let v387_16: Space = unite(&(v387_7),&(v387_15));
        join_wrapped_into(&mut v386_11_write,&((v387_16).read_zipper()),&[]);
        }
        v383_12_cursor.ascend(1);
      }
      drop(v386_11_write);
      drop(v386_6);
      compose(&(v384_10),&(v386_11))
    };
    drop(v384_10);
    let v384_13: Space = unite(&(v384_8),&(v384_12));
    join_wrapped_into(&mut v383_12_write,&((v384_13).read_zipper()),&[]);
    }
    v383_12_cursor.ascend(1);
  }
  drop(v383_12_cursor);
  drop(v383_12_write);
  (v383_12).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v393_11: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_16)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_16))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_17))))
  };
  let v393_14: Space = if (&(v393_11)).is_empty() { Space::new() } else {
    compose(&(v393_11),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_18))))
  };
  let v393_18: Space = if (&(v393_11)).is_empty() { Space::new() } else {
    compose(&(v393_11),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_19))))
  };
  drop(v393_11);
  let v393_20: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_17)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_17))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_19))))
  };
  let v393_21: Space = if (&(v393_20)).is_empty() { Space::new() } else {
    compose(&(v393_20),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_18))))
  };
  drop(v393_20);
  let v393_23: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_16)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_16))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_19))))
  };
  let v393_24: Space = if (&(v393_23)).is_empty() { Space::new() } else {
    compose(&(v393_23),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_18))))
  };
  drop(v393_23);
  let mut v393_25 = Space::new();
  let mut v393_25_write = v393_25.write_zipper();
  let mut v393_25_cursor = (*s0).read_zipper();
  let v393_25_origin = v393_25_cursor.path().len();
  for v393_25_byte in v393_25_cursor.child_mask().iter() {
    v393_25_cursor.descend_to_existing_byte(v393_25_byte);
    {
    let v402_2: Space = singleton(&v393_25_cursor.path()[v393_25_origin..(v393_25_origin + 1)]);
    let v402_3: Space = intersect(&(*CONSTANT_7),&(v402_2));
    let v402_4: Space = if has_head(&(v402_3)) { singleton(&[]) } else { Space::new() };
    drop(v402_3);
    let v402_5: Space = subtract(&(*CONSTANT_0),&(v402_4));
    drop(v402_4);
    let v402_8: Space = if (&(v402_5)).is_empty() { Space::new() } else {
      let v403_6: Path = concat_path(&(*p0),&v393_25_cursor.path()[v393_25_origin..(v393_25_origin + 1)]);
      let v403_7: Space = routine_31(c, &(v403_6), &v393_25_cursor, &(*s1));
      compose(&(v402_5),&(v403_7))
    };
    drop(v402_5);
    let v402_9: Space = intersect(&(*CONSTANT_7),&(v402_2));
    drop(v402_2);
    let v402_10: Space = if has_head(&(v402_9)) { singleton(&[]) } else { Space::new() };
    drop(v402_9);
    let v402_23: Space = if (&(v402_10)).is_empty() { Space::new() } else {
      let v404_6: Path = concat_path(&(*p0),&v393_25_cursor.path()[v393_25_origin..(v393_25_origin + 1)]);
      let v404_11: Space = singleton(&(v404_6));
      drop(v404_6);
      let v404_12: Space = intersect(&(*CONSTANT_8),&(v404_11));
      let v404_13: Space = compose(&(v404_12),&(v393_14));
      drop(v404_12);
      let v404_14: Space = intersect(&(*CONSTANT_9),&(v404_11));
      let v404_15: Space = compose(&(v404_14),&(v393_18));
      drop(v404_14);
      let v404_16: Space = unite(&(v404_13),&(v404_15));
      drop(v404_13);
      drop(v404_15);
      let v404_17: Space = intersect(&(*CONSTANT_10),&(v404_11));
      let v404_18: Space = compose(&(v404_17),&(v393_21));
      drop(v404_17);
      let v404_19: Space = unite(&(v404_16),&(v404_18));
      drop(v404_16);
      drop(v404_18);
      let v404_20: Space = intersect(&(*CONSTANT_11),&(v404_11));
      drop(v404_11);
      let v404_21: Space = compose(&(v404_20),&(v393_24));
      drop(v404_20);
      let v404_22: Space = unite(&(v404_19),&(v404_21));
      drop(v404_19);
      drop(v404_21);
      compose(&(v402_10),&(v404_22))
    };
    drop(v402_10);
    let v402_24: Space = unite(&(v402_8),&(v402_23));
    drop(v402_23);
    join_wrapped_into(&mut v393_25_write,&((v402_24).read_zipper()),&[]);
    }
    v393_25_cursor.ascend(1);
  }
  drop(v393_25_cursor);
  drop(v393_25_write);
  drop(v393_14);
  drop(v393_18);
  drop(v393_21);
  drop(v393_24);
  (v393_25).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v405_10: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v405_11: Space = singleton(&(v405_10));
  drop(v405_10);
  let v405_13: Path = concat_path(&(*CONSTANT_17),&(*p2));
  let v405_14: Space = singleton(&(v405_13));
  drop(v405_13);
  let mut v405_15 = Space::new();
  let mut v405_15_write = v405_15.write_zipper();
  let mut v405_15_cursor = (*s0).read_zipper();
  let v405_15_origin = v405_15_cursor.path().len();
  for v405_15_byte in v405_15_cursor.child_mask().iter() {
    v405_15_cursor.descend_to_existing_byte(v405_15_byte);
    {
    let v406_2: Space = singleton(&v405_15_cursor.path()[v405_15_origin..(v405_15_origin + 1)]);
    let v406_3: Space = intersect(&(*CONSTANT_7),&(v406_2));
    let v406_4: Space = if has_head(&(v406_3)) { singleton(&[]) } else { Space::new() };
    drop(v406_3);
    let v406_5: Space = subtract(&(*CONSTANT_0),&(v406_4));
    drop(v406_4);
    let v406_8: Space = if (&(v406_5)).is_empty() { Space::new() } else {
      let v407_6: Path = concat_path(&(*p0),&v405_15_cursor.path()[v405_15_origin..(v405_15_origin + 1)]);
      let v407_7: Space = routine_32(c, &(v407_6), &(*p1), &(*p2), &v405_15_cursor);
      compose(&(v406_5),&(v407_7))
    };
    drop(v406_5);
    let v406_9: Space = intersect(&(*CONSTANT_7),&(v406_2));
    drop(v406_2);
    let v406_10: Space = if has_head(&(v406_9)) { singleton(&[]) } else { Space::new() };
    drop(v406_9);
    let v406_16: Space = if (&(v406_10)).is_empty() { Space::new() } else {
      let v408_6: Path = concat_path(&(*p0),&v405_15_cursor.path()[v405_15_origin..(v405_15_origin + 1)]);
      let v408_11: Path = concat_path(&(*CONSTANT_18),&(v408_6));
      drop(v408_6);
      let v408_12: Space = singleton(&(v408_11));
      drop(v408_11);
      let v408_13: Space = unite(&(*CONSTANT_24),&(v408_12));
      drop(v408_12);
      let v408_14: Space = unite(&(v408_13),&(v405_11));
      drop(v408_13);
      let v408_15: Space = unite(&(v408_14),&(v405_14));
      drop(v408_14);
      compose(&(v406_10),&(v408_15))
    };
    drop(v406_10);
    let v406_17: Space = unite(&(v406_8),&(v406_16));
    drop(v406_16);
    join_wrapped_into(&mut v405_15_write,&((v406_17).read_zipper()),&[]);
    }
    v405_15_cursor.ascend(1);
  }
  drop(v405_15_cursor);
  drop(v405_15_write);
  drop(v405_11);
  drop(v405_14);
  (v405_15).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v409_6: Path = concat_path(&(*CONSTANT_18),&(*p0));
  let v409_7: Space = singleton(&(v409_6));
  drop(v409_6);
  let v409_8: Space = unite(&(*CONSTANT_24),&(v409_7));
  drop(v409_7);
  let v409_10: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v409_11: Space = singleton(&(v409_10));
  drop(v409_10);
  let v409_12: Space = unite(&(v409_8),&(v409_11));
  drop(v409_8);
  drop(v409_11);
  let v409_14: Path = concat_path(&(*CONSTANT_17),&(*p2));
  let v409_15: Space = singleton(&(v409_14));
  drop(v409_14);
  let v409_16: Space = unite(&(v409_12),&(v409_15));
  drop(v409_12);
  drop(v409_15);
  (v409_16).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v410_10: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v410_11: Space = singleton(&(v410_10));
  drop(v410_10);
  let v410_13: Path = concat_path(&(*CONSTANT_17),&(*p2));
  let v410_14: Space = singleton(&(v410_13));
  drop(v410_13);
  let mut v410_15 = Space::new();
  let mut v410_15_write = v410_15.write_zipper();
  let mut v410_15_cursor = (*s0).read_zipper();
  let v410_15_origin = v410_15_cursor.path().len();
  for v410_15_byte in v410_15_cursor.child_mask().iter() {
    v410_15_cursor.descend_to_existing_byte(v410_15_byte);
    {
    let v411_2: Space = singleton(&v410_15_cursor.path()[v410_15_origin..(v410_15_origin + 1)]);
    let v411_3: Space = intersect(&(*CONSTANT_7),&(v411_2));
    let v411_4: Space = if has_head(&(v411_3)) { singleton(&[]) } else { Space::new() };
    drop(v411_3);
    let v411_5: Space = subtract(&(*CONSTANT_0),&(v411_4));
    drop(v411_4);
    let v411_8: Space = if (&(v411_5)).is_empty() { Space::new() } else {
      let v412_6: Path = concat_path(&(*p0),&v410_15_cursor.path()[v410_15_origin..(v410_15_origin + 1)]);
      let v412_7: Space = routine_34(c, &(v412_6), &(*p1), &(*p2), &v410_15_cursor);
      compose(&(v411_5),&(v412_7))
    };
    drop(v411_5);
    let v411_9: Space = intersect(&(*CONSTANT_7),&(v411_2));
    drop(v411_2);
    let v411_10: Space = if has_head(&(v411_9)) { singleton(&[]) } else { Space::new() };
    drop(v411_9);
    let v411_16: Space = if (&(v411_10)).is_empty() { Space::new() } else {
      let v413_6: Path = concat_path(&(*p0),&v410_15_cursor.path()[v410_15_origin..(v410_15_origin + 1)]);
      let v413_11: Path = concat_path(&(*CONSTANT_19),&(v413_6));
      drop(v413_6);
      let v413_12: Space = singleton(&(v413_11));
      drop(v413_11);
      let v413_13: Space = unite(&(*CONSTANT_25),&(v413_12));
      drop(v413_12);
      let v413_14: Space = unite(&(v413_13),&(v410_11));
      drop(v413_13);
      let v413_15: Space = unite(&(v413_14),&(v410_14));
      drop(v413_14);
      compose(&(v411_10),&(v413_15))
    };
    drop(v411_10);
    let v411_17: Space = unite(&(v411_8),&(v411_16));
    drop(v411_16);
    join_wrapped_into(&mut v410_15_write,&((v411_17).read_zipper()),&[]);
    }
    v410_15_cursor.ascend(1);
  }
  drop(v410_15_cursor);
  drop(v410_15_write);
  drop(v410_11);
  drop(v410_14);
  (v410_15).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v414_6: Path = concat_path(&(*CONSTANT_19),&(*p0));
  let v414_7: Space = singleton(&(v414_6));
  drop(v414_6);
  let v414_8: Space = unite(&(*CONSTANT_25),&(v414_7));
  drop(v414_7);
  let v414_10: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v414_11: Space = singleton(&(v414_10));
  drop(v414_10);
  let v414_12: Space = unite(&(v414_8),&(v414_11));
  drop(v414_8);
  drop(v414_11);
  let v414_14: Path = concat_path(&(*CONSTANT_17),&(*p2));
  let v414_15: Space = singleton(&(v414_14));
  drop(v414_14);
  let v414_16: Space = unite(&(v414_12),&(v414_15));
  drop(v414_12);
  drop(v414_15);
  (v414_16).clone()
}

fn routine_36(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v415_9: Path = concat_path(&(*CONSTANT_19),&(*p2));
  let v415_10: Space = singleton(&(v415_9));
  drop(v415_9);
  let v415_11: Space = unite(&(*CONSTANT_26),&(v415_10));
  drop(v415_10);
  let v415_14: Path = concat_path(&(*CONSTANT_17),&(*p1));
  let v415_15: Space = singleton(&(v415_14));
  drop(v415_14);
  let mut v415_16 = Space::new();
  let mut v415_16_write = v415_16.write_zipper();
  let mut v415_16_cursor = (*s0).read_zipper();
  let v415_16_origin = v415_16_cursor.path().len();
  for v415_16_byte in v415_16_cursor.child_mask().iter() {
    v415_16_cursor.descend_to_existing_byte(v415_16_byte);
    {
    let v416_2: Space = singleton(&v415_16_cursor.path()[v415_16_origin..(v415_16_origin + 1)]);
    let v416_3: Space = intersect(&(*CONSTANT_7),&(v416_2));
    let v416_4: Space = if has_head(&(v416_3)) { singleton(&[]) } else { Space::new() };
    drop(v416_3);
    let v416_5: Space = subtract(&(*CONSTANT_0),&(v416_4));
    drop(v416_4);
    let v416_8: Space = if (&(v416_5)).is_empty() { Space::new() } else {
      let v417_6: Path = concat_path(&(*p0),&v415_16_cursor.path()[v415_16_origin..(v415_16_origin + 1)]);
      let v417_7: Space = routine_36(c, &(v417_6), &(*p1), &(*p2), &v415_16_cursor);
      compose(&(v416_5),&(v417_7))
    };
    drop(v416_5);
    let v416_9: Space = intersect(&(*CONSTANT_7),&(v416_2));
    drop(v416_2);
    let v416_10: Space = if has_head(&(v416_9)) { singleton(&[]) } else { Space::new() };
    drop(v416_9);
    let v416_15: Space = if (&(v416_10)).is_empty() { Space::new() } else {
      let v418_6: Path = concat_path(&(*p0),&v415_16_cursor.path()[v415_16_origin..(v415_16_origin + 1)]);
      let v418_11: Path = concat_path(&(*CONSTANT_18),&(v418_6));
      drop(v418_6);
      let v418_12: Space = singleton(&(v418_11));
      drop(v418_11);
      let v418_13: Space = unite(&(v415_11),&(v418_12));
      drop(v418_12);
      let v418_14: Space = unite(&(v418_13),&(v415_15));
      drop(v418_13);
      compose(&(v416_10),&(v418_14))
    };
    drop(v416_10);
    let v416_16: Space = unite(&(v416_8),&(v416_15));
    drop(v416_15);
    join_wrapped_into(&mut v415_16_write,&((v416_16).read_zipper()),&[]);
    }
    v415_16_cursor.ascend(1);
  }
  drop(v415_16_cursor);
  drop(v415_16_write);
  drop(v415_11);
  drop(v415_15);
  (v415_16).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v419_6: Path = concat_path(&(*CONSTANT_19),&(*p2));
  let v419_7: Space = singleton(&(v419_6));
  drop(v419_6);
  let v419_8: Space = unite(&(*CONSTANT_26),&(v419_7));
  drop(v419_7);
  let v419_10: Path = concat_path(&(*CONSTANT_18),&(*p0));
  let v419_11: Space = singleton(&(v419_10));
  drop(v419_10);
  let v419_12: Space = unite(&(v419_8),&(v419_11));
  drop(v419_8);
  drop(v419_11);
  let v419_14: Path = concat_path(&(*CONSTANT_17),&(*p1));
  let v419_15: Space = singleton(&(v419_14));
  drop(v419_14);
  let v419_16: Space = unite(&(v419_12),&(v419_15));
  drop(v419_12);
  drop(v419_15);
  (v419_16).clone()
}

fn routine_38(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v420_9: Path = concat_path(&(*CONSTANT_19),&(*p2));
  let v420_10: Space = singleton(&(v420_9));
  drop(v420_9);
  let v420_11: Space = unite(&(*CONSTANT_27),&(v420_10));
  drop(v420_10);
  let v420_14: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v420_15: Space = singleton(&(v420_14));
  drop(v420_14);
  let mut v420_16 = Space::new();
  let mut v420_16_write = v420_16.write_zipper();
  let mut v420_16_cursor = (*s0).read_zipper();
  let v420_16_origin = v420_16_cursor.path().len();
  for v420_16_byte in v420_16_cursor.child_mask().iter() {
    v420_16_cursor.descend_to_existing_byte(v420_16_byte);
    {
    let v421_2: Space = singleton(&v420_16_cursor.path()[v420_16_origin..(v420_16_origin + 1)]);
    let v421_3: Space = intersect(&(*CONSTANT_7),&(v421_2));
    let v421_4: Space = if has_head(&(v421_3)) { singleton(&[]) } else { Space::new() };
    drop(v421_3);
    let v421_5: Space = subtract(&(*CONSTANT_0),&(v421_4));
    drop(v421_4);
    let v421_8: Space = if (&(v421_5)).is_empty() { Space::new() } else {
      let v422_6: Path = concat_path(&(*p0),&v420_16_cursor.path()[v420_16_origin..(v420_16_origin + 1)]);
      let v422_7: Space = routine_38(c, &(v422_6), &(*p1), &(*p2), &v420_16_cursor);
      compose(&(v421_5),&(v422_7))
    };
    drop(v421_5);
    let v421_9: Space = intersect(&(*CONSTANT_7),&(v421_2));
    drop(v421_2);
    let v421_10: Space = if has_head(&(v421_9)) { singleton(&[]) } else { Space::new() };
    drop(v421_9);
    let v421_15: Space = if (&(v421_10)).is_empty() { Space::new() } else {
      let v423_6: Path = concat_path(&(*p0),&v420_16_cursor.path()[v420_16_origin..(v420_16_origin + 1)]);
      let v423_11: Path = concat_path(&(*CONSTANT_18),&(v423_6));
      drop(v423_6);
      let v423_12: Space = singleton(&(v423_11));
      drop(v423_11);
      let v423_13: Space = unite(&(v420_11),&(v423_12));
      drop(v423_12);
      let v423_14: Space = unite(&(v423_13),&(v420_15));
      drop(v423_13);
      compose(&(v421_10),&(v423_14))
    };
    drop(v421_10);
    let v421_16: Space = unite(&(v421_8),&(v421_15));
    drop(v421_15);
    join_wrapped_into(&mut v420_16_write,&((v421_16).read_zipper()),&[]);
    }
    v420_16_cursor.ascend(1);
  }
  drop(v420_16_cursor);
  drop(v420_16_write);
  drop(v420_11);
  drop(v420_15);
  (v420_16).clone()
}

fn routine_39(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v424_6: Path = concat_path(&(*CONSTANT_19),&(*p2));
  let v424_7: Space = singleton(&(v424_6));
  drop(v424_6);
  let v424_8: Space = unite(&(*CONSTANT_27),&(v424_7));
  drop(v424_7);
  let v424_10: Path = concat_path(&(*CONSTANT_18),&(*p0));
  let v424_11: Space = singleton(&(v424_10));
  drop(v424_10);
  let v424_12: Space = unite(&(v424_8),&(v424_11));
  drop(v424_8);
  drop(v424_11);
  let v424_14: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v424_15: Space = singleton(&(v424_14));
  drop(v424_14);
  let v424_16: Space = unite(&(v424_12),&(v424_15));
  drop(v424_12);
  drop(v424_15);
  (v424_16).clone()
}

fn routine_40(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v425_10 = Space::new();
  let mut v425_10_write = v425_10.write_zipper();
  let mut v425_10_cursor = (*s0).read_zipper();
  let v425_10_origin = v425_10_cursor.path().len();
  for v425_10_byte in v425_10_cursor.child_mask().iter() {
    v425_10_cursor.descend_to_existing_byte(v425_10_byte);
    {
    let v426_2: Space = singleton(&v425_10_cursor.path()[v425_10_origin..(v425_10_origin + 1)]);
    let v426_3: Space = intersect(&(*CONSTANT_7),&(v426_2));
    let v426_4: Space = if has_head(&(v426_3)) { singleton(&[]) } else { Space::new() };
    drop(v426_3);
    let v426_5: Space = subtract(&(*CONSTANT_0),&(v426_4));
    drop(v426_4);
    let v426_8: Space = if (&(v426_5)).is_empty() { Space::new() } else {
      let v427_6: Path = concat_path(&(*p0),&v425_10_cursor.path()[v425_10_origin..(v425_10_origin + 1)]);
      let v427_7: Space = routine_40(c, &(v427_6), &(*p1), &v425_10_cursor);
      compose(&(v426_5),&(v427_7))
    };
    drop(v426_5);
    let v426_9: Space = intersect(&(*CONSTANT_7),&(v426_2));
    drop(v426_2);
    let v426_10: Space = if has_head(&(v426_9)) { singleton(&[]) } else { Space::new() };
    drop(v426_9);
    let v426_14: Space = if (&(v426_10)).is_empty() { Space::new() } else {
      let mut v428_11 = Space::new();
      let mut v428_11_write = v428_11.write_zipper();
      for v428_11_byte in v425_10_cursor.child_mask().iter() {
        v425_10_cursor.descend_to_existing_byte(v428_11_byte);
        {
        let v429_2: Space = singleton(&v425_10_cursor.path()[(v425_10_origin + 1)..(v425_10_origin + 2)]);
        let v429_3: Space = intersect(&(*CONSTANT_7),&(v429_2));
        let v429_4: Space = if has_head(&(v429_3)) { singleton(&[]) } else { Space::new() };
        drop(v429_3);
        let v429_5: Space = subtract(&(*CONSTANT_0),&(v429_4));
        drop(v429_4);
        let v429_7: Space = if (&(v429_5)).is_empty() { Space::new() } else {
          let v430_6: Space = routine_41(c, &v425_10_cursor.path()[(v425_10_origin + 1)..(v425_10_origin + 2)], &v425_10_cursor);
          compose(&(v429_5),&(v430_6))
        };
        drop(v429_5);
        let v429_8: Space = intersect(&(*CONSTANT_7),&(v429_2));
        let v429_9: Space = if has_head(&(v429_8)) { singleton(&[]) } else { Space::new() };
        drop(v429_8);
        let v429_10: Space = compose(&(v429_9),&(v429_2));
        drop(v429_2);
        drop(v429_9);
        let v429_11: Space = unite(&(v429_7),&(v429_10));
        drop(v429_10);
        join_wrapped_into(&mut v428_11_write,&((v429_11).read_zipper()),&[]);
        }
        v425_10_cursor.ascend(1);
      }
      drop(v428_11_write);
      let v428_12: Space = raffine(&(*CONSTANT_28),&(v428_11));
      let v428_13: Space = unite(&(v428_12),&v425_10_cursor);
      compose(&(v426_10),&(v428_13))
    };
    drop(v426_10);
    let v431_6: Path = concat_path(&(*p0),&v425_10_cursor.path()[v425_10_origin..(v425_10_origin + 1)]);
    let v426_15: Path = concat_path(&(*p1),&(v431_6));
    let v426_16: Space = wrap(&(v426_14),&(v426_15));
    drop(v426_15);
    let v426_17: Space = unite(&(v426_8),&(v426_16));
    join_wrapped_into(&mut v425_10_write,&((v426_17).read_zipper()),&[]);
    }
    v425_10_cursor.ascend(1);
  }
  drop(v425_10_cursor);
  drop(v425_10_write);
  (v425_10).clone()
}

fn routine_41(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v432_5 = Space::new();
  let mut v432_5_write = v432_5.write_zipper();
  let mut v432_5_cursor = (*s0).read_zipper();
  let v432_5_origin = v432_5_cursor.path().len();
  for v432_5_byte in v432_5_cursor.child_mask().iter() {
    v432_5_cursor.descend_to_existing_byte(v432_5_byte);
    {
    let v433_2: Space = singleton(&v432_5_cursor.path()[v432_5_origin..(v432_5_origin + 1)]);
    let v433_3: Space = intersect(&(*CONSTANT_7),&(v433_2));
    let v433_4: Space = if has_head(&(v433_3)) { singleton(&[]) } else { Space::new() };
    drop(v433_3);
    let v433_5: Space = subtract(&(*CONSTANT_0),&(v433_4));
    drop(v433_4);
    let v433_8: Space = if (&(v433_5)).is_empty() { Space::new() } else {
      let v434_6: Path = concat_path(&(*p0),&v432_5_cursor.path()[v432_5_origin..(v432_5_origin + 1)]);
      let v434_7: Space = routine_41(c, &(v434_6), &v432_5_cursor);
      compose(&(v433_5),&(v434_7))
    };
    drop(v433_5);
    let v433_9: Space = intersect(&(*CONSTANT_7),&(v433_2));
    drop(v433_2);
    let v433_10: Space = if has_head(&(v433_9)) { singleton(&[]) } else { Space::new() };
    drop(v433_9);
    let v433_12: Space = if (&(v433_10)).is_empty() { Space::new() } else {
      let v435_6: Path = concat_path(&(*p0),&v432_5_cursor.path()[v432_5_origin..(v432_5_origin + 1)]);
      let v435_11: Space = singleton(&(v435_6));
      drop(v435_6);
      compose(&(v433_10),&(v435_11))
    };
    drop(v433_10);
    let v433_13: Space = unite(&(v433_8),&(v433_12));
    drop(v433_12);
    join_wrapped_into(&mut v432_5_write,&((v433_13).read_zipper()),&[]);
    }
    v432_5_cursor.ascend(1);
  }
  drop(v432_5_cursor);
  drop(v432_5_write);
  (v432_5).clone()
}

fn routine_42(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v436_2: Space = singleton(&(*p0));
  (v436_2).clone()
}

fn routine_43(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v437_10 = Space::new();
  let mut v437_10_write = v437_10.write_zipper();
  let mut v437_10_cursor = (*s0).read_zipper();
  let v437_10_origin = v437_10_cursor.path().len();
  for v437_10_byte in v437_10_cursor.child_mask().iter() {
    v437_10_cursor.descend_to_existing_byte(v437_10_byte);
    {
    let v438_2: Space = singleton(&v437_10_cursor.path()[v437_10_origin..(v437_10_origin + 1)]);
    let v438_3: Space = intersect(&(*CONSTANT_7),&(v438_2));
    let v438_4: Space = if has_head(&(v438_3)) { singleton(&[]) } else { Space::new() };
    drop(v438_3);
    let v438_5: Space = subtract(&(*CONSTANT_0),&(v438_4));
    drop(v438_4);
    let v438_8: Space = if (&(v438_5)).is_empty() { Space::new() } else {
      let v439_6: Path = concat_path(&(*p0),&v437_10_cursor.path()[v437_10_origin..(v437_10_origin + 1)]);
      let v439_7: Space = routine_43(c, &(v439_6), &(*p1), &v437_10_cursor);
      compose(&(v438_5),&(v439_7))
    };
    drop(v438_5);
    let v438_9: Space = intersect(&(*CONSTANT_7),&(v438_2));
    drop(v438_2);
    let v438_10: Space = if has_head(&(v438_9)) { singleton(&[]) } else { Space::new() };
    drop(v438_9);
    let v438_14: Space = if (&(v438_10)).is_empty() { Space::new() } else {
      let mut v440_11 = Space::new();
      let mut v440_11_write = v440_11.write_zipper();
      for v440_11_byte in v437_10_cursor.child_mask().iter() {
        v437_10_cursor.descend_to_existing_byte(v440_11_byte);
        {
        let v441_2: Space = singleton(&v437_10_cursor.path()[(v437_10_origin + 1)..(v437_10_origin + 2)]);
        let v441_3: Space = intersect(&(*CONSTANT_7),&(v441_2));
        let v441_4: Space = if has_head(&(v441_3)) { singleton(&[]) } else { Space::new() };
        drop(v441_3);
        let v441_5: Space = subtract(&(*CONSTANT_0),&(v441_4));
        drop(v441_4);
        let v441_7: Space = if (&(v441_5)).is_empty() { Space::new() } else {
          let v442_6: Space = routine_44(c, &v437_10_cursor.path()[(v437_10_origin + 1)..(v437_10_origin + 2)], &v437_10_cursor);
          compose(&(v441_5),&(v442_6))
        };
        drop(v441_5);
        let v441_8: Space = intersect(&(*CONSTANT_7),&(v441_2));
        let v441_9: Space = if has_head(&(v441_8)) { singleton(&[]) } else { Space::new() };
        drop(v441_8);
        let v441_10: Space = compose(&(v441_9),&(v441_2));
        drop(v441_2);
        drop(v441_9);
        let v441_11: Space = unite(&(v441_7),&(v441_10));
        drop(v441_10);
        join_wrapped_into(&mut v440_11_write,&((v441_11).read_zipper()),&[]);
        }
        v437_10_cursor.ascend(1);
      }
      drop(v440_11_write);
      let v440_12: Space = raffine(&(*CONSTANT_28),&(v440_11));
      let v440_13: Space = unite(&(v440_12),&v437_10_cursor);
      compose(&(v438_10),&(v440_13))
    };
    drop(v438_10);
    let v443_6: Path = concat_path(&(*p0),&v437_10_cursor.path()[v437_10_origin..(v437_10_origin + 1)]);
    let v438_15: Path = concat_path(&(*p1),&(v443_6));
    let v438_16: Space = wrap(&(v438_14),&(v438_15));
    drop(v438_15);
    let v438_17: Space = unite(&(v438_8),&(v438_16));
    join_wrapped_into(&mut v437_10_write,&((v438_17).read_zipper()),&[]);
    }
    v437_10_cursor.ascend(1);
  }
  drop(v437_10_cursor);
  drop(v437_10_write);
  (v437_10).clone()
}

fn routine_44(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v444_5 = Space::new();
  let mut v444_5_write = v444_5.write_zipper();
  let mut v444_5_cursor = (*s0).read_zipper();
  let v444_5_origin = v444_5_cursor.path().len();
  for v444_5_byte in v444_5_cursor.child_mask().iter() {
    v444_5_cursor.descend_to_existing_byte(v444_5_byte);
    {
    let v445_2: Space = singleton(&v444_5_cursor.path()[v444_5_origin..(v444_5_origin + 1)]);
    let v445_3: Space = intersect(&(*CONSTANT_7),&(v445_2));
    let v445_4: Space = if has_head(&(v445_3)) { singleton(&[]) } else { Space::new() };
    drop(v445_3);
    let v445_5: Space = subtract(&(*CONSTANT_0),&(v445_4));
    drop(v445_4);
    let v445_8: Space = if (&(v445_5)).is_empty() { Space::new() } else {
      let v446_6: Path = concat_path(&(*p0),&v444_5_cursor.path()[v444_5_origin..(v444_5_origin + 1)]);
      let v446_7: Space = routine_44(c, &(v446_6), &v444_5_cursor);
      compose(&(v445_5),&(v446_7))
    };
    drop(v445_5);
    let v445_9: Space = intersect(&(*CONSTANT_7),&(v445_2));
    drop(v445_2);
    let v445_10: Space = if has_head(&(v445_9)) { singleton(&[]) } else { Space::new() };
    drop(v445_9);
    let v445_12: Space = if (&(v445_10)).is_empty() { Space::new() } else {
      let v447_6: Path = concat_path(&(*p0),&v444_5_cursor.path()[v444_5_origin..(v444_5_origin + 1)]);
      let v447_11: Space = singleton(&(v447_6));
      drop(v447_6);
      compose(&(v445_10),&(v447_11))
    };
    drop(v445_10);
    let v445_13: Space = unite(&(v445_8),&(v445_12));
    drop(v445_12);
    join_wrapped_into(&mut v444_5_write,&((v445_13).read_zipper()),&[]);
    }
    v444_5_cursor.ascend(1);
  }
  drop(v444_5_cursor);
  drop(v444_5_write);
  (v444_5).clone()
}

fn routine_45(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v448_2: Space = singleton(&(*p0));
  (v448_2).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
