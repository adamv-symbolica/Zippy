#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[2]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("12 8 66 76 1 49 1 51 1 50 8 66 76 1 50 1 49 1 51 8 66 76 1 51 1 50 1 49 8 66 82 1 49 1 51 1 50 8 66 82 1 50 1 49 1 51 8 66 82 1 51 1 50 1 49 8 84 76 1 49 1 50 1 51 8 84 76 1 50 1 51 1 49 8 84 76 1 51 1 49 1 50 8 84 82 1 49 1 50 1 51 8 84 82 1 50 1 51 1 49 8 84 82 1 51 1 49 1 50"));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("255 2 1 0 2 2 1 2 3 2 2 4 3 2 5 4 2 6 5 2 7 6 2 8 7 2 9 8 2 10 9 2 11 10 2 12 11 2 13 12 2 14 13 2 15 14 2 16 15 2 17 16 2 18 17 2 19 18 2 20 19 2 21 20 2 22 21 2 23 22 2 24 23 2 25 24 2 26 25 2 27 26 2 28 27 2 29 28 2 30 29 2 31 30 2 32 31 2 33 32 2 34 33 2 35 34 2 36 35 2 37 36 2 38 37 2 39 38 2 40 39 2 41 40 2 42 41 2 43 42 2 44 43 2 45 44 2 46 45 2 47 46 2 48 47 2 49 48 2 50 49 2 51 50 2 52 51 2 53 52 2 54 53 2 55 54 2 56 55 2 57 56 2 58 57 2 59 58 2 60 59 2 61 60 2 62 61 2 63 62 2 64 63 2 65 64 2 66 65 2 67 66 2 68 67 2 69 68 2 70 69 2 71 70 2 72 71 2 73 72 2 74 73 2 75 74 2 76 75 2 77 76 2 78 77 2 79 78 2 80 79 2 81 80 2 82 81 2 83 82 2 84 83 2 85 84 2 86 85 2 87 86 2 88 87 2 89 88 2 90 89 2 91 90 2 92 91 2 93 92 2 94 93 2 95 94 2 96 95 2 97 96 2 98 97 2 99 98 2 100 99 2 101 100 2 102 101 2 103 102 2 104 103 2 105 104 2 106 105 2 107 106 2 108 107 2 109 108 2 110 109 2 111 110 2 112 111 2 113 112 2 114 113 2 115 114 2 116 115 2 117 116 2 118 117 2 119 118 2 120 119 2 121 120 2 122 121 2 123 122 2 124 123 2 125 124 2 126 125 2 127 126 2 128 127 2 129 128 2 130 129 2 131 130 2 132 131 2 133 132 2 134 133 2 135 134 2 136 135 2 137 136 2 138 137 2 139 138 2 140 139 2 141 140 2 142 141 2 143 142 2 144 143 2 145 144 2 146 145 2 147 146 2 148 147 2 149 148 2 150 149 2 151 150 2 152 151 2 153 152 2 154 153 2 155 154 2 156 155 2 157 156 2 158 157 2 159 158 2 160 159 2 161 160 2 162 161 2 163 162 2 164 163 2 165 164 2 166 165 2 167 166 2 168 167 2 169 168 2 170 169 2 171 170 2 172 171 2 173 172 2 174 173 2 175 174 2 176 175 2 177 176 2 178 177 2 179 178 2 180 179 2 181 180 2 182 181 2 183 182 2 184 183 2 185 184 2 186 185 2 187 186 2 188 187 2 189 188 2 190 189 2 191 190 2 192 191 2 193 192 2 194 193 2 195 194 2 196 195 2 197 196 2 198 197 2 199 198 2 200 199 2 201 200 2 202 201 2 203 202 2 204 203 2 205 204 2 206 205 2 207 206 2 208 207 2 209 208 2 210 209 2 211 210 2 212 211 2 213 212 2 214 213 2 215 214 2 216 215 2 217 216 2 218 217 2 219 218 2 220 219 2 221 220 2 222 221 2 223 222 2 224 223 2 225 224 2 226 225 2 227 226 2 228 227 2 229 228 2 230 229 2 231 230 2 232 231 2 233 232 2 234 233 2 235 234 2 236 235 2 237 236 2 238 237 2 239 238 2 240 239 2 241 240 2 242 241 2 243 242 2 244 243 2 245 244 2 246 245 2 247 246 2 248 247 2 249 248 2 250 249 2 251 250 2 252 251 2 253 252 2 254 253 2 255 254"));
static CONSTANT_7: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 3 2 66 76"));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 3 2 66 82"));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 3 2 84 76"));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 3 2 84 82"));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("16 10 66 76 1 82 2 66 76 2 66 82 10 66 76 1 82 2 66 82 2 66 76 10 66 76 1 85 2 66 76 2 84 76 10 66 76 1 85 2 84 76 2 66 76 10 66 82 1 76 2 66 76 2 66 82 10 66 82 1 76 2 66 82 2 66 76 10 66 82 1 85 2 66 82 2 84 82 10 66 82 1 85 2 84 82 2 66 82 10 84 76 1 68 2 66 76 2 84 76 10 84 76 1 68 2 84 76 2 66 76 10 84 76 1 82 2 84 76 2 84 82 10 84 76 1 82 2 84 82 2 84 76 10 84 82 1 68 2 66 82 2 84 82 10 84 82 1 68 2 84 82 2 66 82 10 84 82 1 76 2 84 76 2 84 82 10 84 82 1 76 2 84 82 2 84 76"));
static CONSTANT_12: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[2,84,76]));
static CONSTANT_13: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[2,84,82]));
static CONSTANT_14: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[2,66,82]));
static CONSTANT_15: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[2,66,76]));
static CONSTANT_16: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 2 66 76 1 95"));
static CONSTANT_17: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 2 66 82 1 95"));
static CONSTANT_18: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 2 84 76 1 95"));
static CONSTANT_19: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 2 84 82 1 95"));
static CONSTANT_20: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 6 2 66 76 2 66 76 6 2 66 82 2 66 82 6 2 84 76 2 84 76 6 2 84 82 2 84 82"));
fn routine_0(c: &mut Context) -> Space {
  let v0_6: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let mut v1_5 = Space::new();
    let mut v1_5_write = v1_5.write_zipper();
    let v1_5_arg_0: &[u8] = &(*CONSTANT_1);
    let v1_5_arg_1: &[u8] = &(*CONSTANT_2);
    let v1_5_arg_3: &Space = &(*CONSTANT_4);
    let mut v1_5_cursor = (*CONSTANT_3).read_zipper();
    let v1_5_origin = v1_5_cursor.path().len();
    let mut v1_5_more = v1_5_cursor.is_val() || next_value_within(&mut v1_5_cursor,v1_5_origin);
    while v1_5_more {
      {
      let v1_5_depth = v1_5_cursor.path().len();
      let mut v2_4_cursor = (*v1_5_arg_3).read_zipper();
      let v2_4_origin = v2_4_cursor.path().len();
      for v2_4_byte in v2_4_cursor.child_mask().iter() {
        v2_4_cursor.descend_to_existing_byte(v2_4_byte);
        {
        let v3_2: Path = concat_path(&(*v1_5_arg_1),&v2_4_cursor.path()[v2_4_origin..(v2_4_origin + 1)]);
        let v3_3: Space = routine_1(c, &(v3_2), &v1_5_cursor.path()[v1_5_origin..v1_5_depth], &v2_4_cursor);
        drop(v3_2);
        join_wrapped_into(&mut v1_5_write,&((v3_3).read_zipper()),&[]);
        }
        v2_4_cursor.ascend(1);
      }
      drop(v2_4_cursor);
      }
      v1_5_more = next_value_within(&mut v1_5_cursor,v1_5_origin);
    }
    drop(v1_5_cursor);
    drop(v1_5_write);
    compose(&(*CONSTANT_0),&(v1_5))
  };
  (v0_6).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v4_5: Space = singleton(&(*p1));
  let v4_6: Space = intersect(&(*CONSTANT_5),&(v4_5));
  let v4_7: Space = if has_head(&(v4_6)) { singleton(&[]) } else { Space::new() };
  drop(v4_6);
  let v4_8: Space = subtract(&(*CONSTANT_0),&(v4_7));
  drop(v4_7);
  let v4_19: Space = if (&(v4_8)).is_empty() { Space::new() } else {
    let v5_11: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v5_14: Space = if (&(v5_11)).is_empty() { Space::new() } else {
      let v6_13: Space = routine_2(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v5_11),&(v6_13))
    };
    drop(v5_11);
    let mut v5_17 = Space::new();
    let mut v5_17_write = v5_17.write_zipper();
    let mut v5_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v5_17_origin = v5_17_cursor.path().len();
    for v5_17_byte in v5_17_cursor.child_mask().iter() {
      v5_17_cursor.descend_to_existing_byte(v5_17_byte);
      {
      let v7_2_arg_0: &[u8] = &v5_17_cursor.path()[v5_17_origin..(v5_17_origin + 1)];
      let v7_2_arg_1: &[u8] = &(*p0);
      let v7_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v7_2_more = v5_17_cursor.is_val() || next_value_within(&mut v5_17_cursor,(v5_17_origin + 1));
      while v7_2_more {
        {
        let v7_2_depth = v5_17_cursor.path().len();
        let mut v8_4_cursor = (*v7_2_arg_3).read_zipper();
        let v8_4_origin = v8_4_cursor.path().len();
        for v8_4_byte in v8_4_cursor.child_mask().iter() {
          v8_4_cursor.descend_to_existing_byte(v8_4_byte);
          {
          let v9_2: Path = concat_path(&(*v7_2_arg_1),&v8_4_cursor.path()[v8_4_origin..(v8_4_origin + 1)]);
          let v9_3: Space = routine_1(c, &(v9_2), &v5_17_cursor.path()[v5_17_origin..v7_2_depth], &v8_4_cursor);
          drop(v9_2);
          join_wrapped_into(&mut v5_17_write,&((v9_3).read_zipper()),&[]);
          }
          v8_4_cursor.ascend(1);
        }
        drop(v8_4_cursor);
        }
        v7_2_more = next_value_within(&mut v5_17_cursor,(v5_17_origin + 1));
      }
      }
      v5_17_cursor.ascend(1);
    }
    drop(v5_17_cursor);
    drop(v5_17_write);
    let v5_18: Space = unite(&(v5_14),&(v5_17));
    compose(&(v4_8),&(v5_18))
  };
  drop(v4_8);
  let v4_21: Space = intersect(&(*CONSTANT_5),&(v4_5));
  drop(v4_5);
  let v4_22: Space = if has_head(&(v4_21)) { singleton(&[]) } else { Space::new() };
  drop(v4_21);
  let v4_24: Space = if (&(v4_22)).is_empty() { Space::new() } else {
    let mut v10_23 = Space::new();
    let mut v10_23_write = v10_23.write_zipper();
    let mut v10_23_cursor = (*s0).read_zipper();
    let v10_23_origin = v10_23_cursor.path().len();
    for v10_23_byte in v10_23_cursor.child_mask().iter() {
      v10_23_cursor.descend_to_existing_byte(v10_23_byte);
      {
      let v11_2: Space = routine_3(c, &v10_23_cursor.path()[v10_23_origin..(v10_23_origin + 1)], &v10_23_cursor.path()[v10_23_origin..(v10_23_origin + 1)], &(*p0), &v10_23_cursor);
      join_wrapped_into(&mut v10_23_write,&((v11_2).read_zipper()),&[]);
      }
      v10_23_cursor.ascend(1);
    }
    drop(v10_23_cursor);
    drop(v10_23_write);
    compose(&(v4_22),&(v10_23))
  };
  drop(v4_22);
  let v4_25: Space = unite(&(v4_19),&(v4_24));
  (v4_25).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v12_5: Space = singleton(&(*p0));
  let v12_6: Space = intersect(&(*CONSTANT_5),&(v12_5));
  let v12_7: Space = if has_head(&(v12_6)) { singleton(&[]) } else { Space::new() };
  drop(v12_6);
  let v12_8: Space = subtract(&(*CONSTANT_0),&(v12_7));
  drop(v12_7);
  let v12_13: Space = intersect(&(*CONSTANT_5),&(v12_5));
  drop(v12_5);
  let v12_14: Space = if has_head(&(v12_13)) { singleton(&[]) } else { Space::new() };
  drop(v12_13);
  let mut v12_15 = Space::new();
  let mut v12_15_write = v12_15.write_zipper();
  let mut v12_15_cursor = (*s0).read_zipper();
  let v12_15_origin = v12_15_cursor.path().len();
  for v12_15_byte in v12_15_cursor.child_mask().iter() {
    v12_15_cursor.descend_to_existing_byte(v12_15_byte);
    {
    let v13_4: Space = if (&(v12_8)).is_empty() { Space::new() } else {
      let v14_2: Path = concat_path(&(*p1),&v12_15_cursor.path()[v12_15_origin..(v12_15_origin + 1)]);
      let mut v14_3 = Space::new();
      let mut v14_3_write = v14_3.write_zipper();
      let v14_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v14_3_arg_1: &[u8] = &(v14_2);
      let v14_3_arg_3: &Space = &(&v12_15_cursor).make_map();
      let mut v14_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v14_3_origin = v14_3_cursor.path().len();
      let mut v14_3_more = v14_3_cursor.is_val() || next_value_within(&mut v14_3_cursor,v14_3_origin);
      while v14_3_more {
        {
        let v14_3_depth = v14_3_cursor.path().len();
        let v15_4: Space = routine_2(c, &v14_3_cursor.path()[v14_3_origin..v14_3_depth], &(*v14_3_arg_1), &((*v14_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v14_3_write,&((v15_4).read_zipper()),&[]);
        }
        v14_3_more = next_value_within(&mut v14_3_cursor,v14_3_origin);
      }
      drop(v14_3_cursor);
      drop(v14_3_write);
      compose(&(v12_8),&(v14_3))
    };
    let v13_6: Space = if (&(v12_14)).is_empty() { Space::new() } else {
      let v16_2: Path = concat_path(&(*p1),&v12_15_cursor.path()[v12_15_origin..(v12_15_origin + 1)]);
      let mut v16_5 = Space::new();
      let mut v16_5_write = v16_5.write_zipper();
      for v16_5_byte in v12_15_cursor.child_mask().iter() {
        v12_15_cursor.descend_to_existing_byte(v16_5_byte);
        {
        let v17_2: Space = routine_3(c, &v12_15_cursor.path()[(v12_15_origin + 1)..(v12_15_origin + 2)], &v12_15_cursor.path()[(v12_15_origin + 1)..(v12_15_origin + 2)], &(v16_2), &v12_15_cursor);
        join_wrapped_into(&mut v16_5_write,&((v17_2).read_zipper()),&[]);
        }
        v12_15_cursor.ascend(1);
      }
      drop(v16_5_write);
      drop(v16_2);
      compose(&(v12_14),&(v16_5))
    };
    let v13_7: Space = unite(&(v13_4),&(v13_6));
    join_wrapped_into(&mut v12_15_write,&((v13_7).read_zipper()),&[]);
    }
    v12_15_cursor.ascend(1);
  }
  drop(v12_15_cursor);
  drop(v12_15_write);
  drop(v12_8);
  drop(v12_14);
  (v12_15).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v18_6: Space = singleton(&(*p1));
  let v18_7: Space = intersect(&(*CONSTANT_5),&(v18_6));
  let v18_8: Space = if has_head(&(v18_7)) { singleton(&[]) } else { Space::new() };
  drop(v18_7);
  let v18_9: Space = subtract(&(*CONSTANT_0),&(v18_8));
  drop(v18_8);
  let v18_20: Space = if (&(v18_9)).is_empty() { Space::new() } else {
    let v19_12: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v19_15: Space = if (&(v19_12)).is_empty() { Space::new() } else {
      let v20_14: Space = routine_4(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v19_12),&(v20_14))
    };
    drop(v19_12);
    let mut v19_18 = Space::new();
    let mut v19_18_write = v19_18.write_zipper();
    let mut v19_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v19_18_origin = v19_18_cursor.path().len();
    for v19_18_byte in v19_18_cursor.child_mask().iter() {
      v19_18_cursor.descend_to_existing_byte(v19_18_byte);
      {
      let v21_2_arg_0: &[u8] = &v19_18_cursor.path()[v19_18_origin..(v19_18_origin + 1)];
      let v21_2_arg_1: &[u8] = &(*p0);
      let v21_2_arg_2: &[u8] = &(*p2);
      let v21_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v21_2_more = v19_18_cursor.is_val() || next_value_within(&mut v19_18_cursor,(v19_18_origin + 1));
      while v21_2_more {
        {
        let v21_2_depth = v19_18_cursor.path().len();
        let mut v22_5_cursor = (*v21_2_arg_4).read_zipper();
        let v22_5_origin = v22_5_cursor.path().len();
        for v22_5_byte in v22_5_cursor.child_mask().iter() {
          v22_5_cursor.descend_to_existing_byte(v22_5_byte);
          {
          let v23_2: Path = concat_path(&(*v21_2_arg_1),&v22_5_cursor.path()[v22_5_origin..(v22_5_origin + 1)]);
          let v23_3: Space = routine_3(c, &(v23_2), &v19_18_cursor.path()[v19_18_origin..v21_2_depth], &(*v21_2_arg_2), &v22_5_cursor);
          drop(v23_2);
          join_wrapped_into(&mut v19_18_write,&((v23_3).read_zipper()),&[]);
          }
          v22_5_cursor.ascend(1);
        }
        drop(v22_5_cursor);
        }
        v21_2_more = next_value_within(&mut v19_18_cursor,(v19_18_origin + 1));
      }
      }
      v19_18_cursor.ascend(1);
    }
    drop(v19_18_cursor);
    drop(v19_18_write);
    let v19_19: Space = unite(&(v19_15),&(v19_18));
    compose(&(v18_9),&(v19_19))
  };
  drop(v18_9);
  let v18_22: Space = intersect(&(*CONSTANT_5),&(v18_6));
  drop(v18_6);
  let v18_23: Space = if has_head(&(v18_22)) { singleton(&[]) } else { Space::new() };
  drop(v18_22);
  let v18_25: Space = if (&(v18_23)).is_empty() { Space::new() } else {
    let mut v24_24 = Space::new();
    let mut v24_24_write = v24_24.write_zipper();
    let mut v24_24_cursor = (*s0).read_zipper();
    let v24_24_origin = v24_24_cursor.path().len();
    for v24_24_byte in v24_24_cursor.child_mask().iter() {
      v24_24_cursor.descend_to_existing_byte(v24_24_byte);
      {
      let v25_2: Space = routine_5(c, &v24_24_cursor.path()[v24_24_origin..(v24_24_origin + 1)], &v24_24_cursor.path()[v24_24_origin..(v24_24_origin + 1)], &(*p2), &(*p0), &v24_24_cursor);
      join_wrapped_into(&mut v24_24_write,&((v25_2).read_zipper()),&[]);
      }
      v24_24_cursor.ascend(1);
    }
    drop(v24_24_cursor);
    drop(v24_24_write);
    compose(&(v18_23),&(v24_24))
  };
  drop(v18_23);
  let v18_26: Space = unite(&(v18_20),&(v18_25));
  (v18_26).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v26_6: Space = singleton(&(*p0));
  let v26_7: Space = intersect(&(*CONSTANT_5),&(v26_6));
  let v26_8: Space = if has_head(&(v26_7)) { singleton(&[]) } else { Space::new() };
  drop(v26_7);
  let v26_9: Space = subtract(&(*CONSTANT_0),&(v26_8));
  drop(v26_8);
  let v26_14: Space = intersect(&(*CONSTANT_5),&(v26_6));
  drop(v26_6);
  let v26_15: Space = if has_head(&(v26_14)) { singleton(&[]) } else { Space::new() };
  drop(v26_14);
  let mut v26_16 = Space::new();
  let mut v26_16_write = v26_16.write_zipper();
  let mut v26_16_cursor = (*s0).read_zipper();
  let v26_16_origin = v26_16_cursor.path().len();
  for v26_16_byte in v26_16_cursor.child_mask().iter() {
    v26_16_cursor.descend_to_existing_byte(v26_16_byte);
    {
    let v27_4: Space = if (&(v26_9)).is_empty() { Space::new() } else {
      let v28_2: Path = concat_path(&(*p1),&v26_16_cursor.path()[v26_16_origin..(v26_16_origin + 1)]);
      let mut v28_3 = Space::new();
      let mut v28_3_write = v28_3.write_zipper();
      let v28_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v28_3_arg_1: &[u8] = &(v28_2);
      let v28_3_arg_2: &[u8] = &(*p2);
      let v28_3_arg_4: &Space = &(&v26_16_cursor).make_map();
      let mut v28_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v28_3_origin = v28_3_cursor.path().len();
      let mut v28_3_more = v28_3_cursor.is_val() || next_value_within(&mut v28_3_cursor,v28_3_origin);
      while v28_3_more {
        {
        let v28_3_depth = v28_3_cursor.path().len();
        let v29_5: Space = routine_4(c, &v28_3_cursor.path()[v28_3_origin..v28_3_depth], &(*v28_3_arg_1), &(*v28_3_arg_2), &((*v28_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v28_3_write,&((v29_5).read_zipper()),&[]);
        }
        v28_3_more = next_value_within(&mut v28_3_cursor,v28_3_origin);
      }
      drop(v28_3_cursor);
      drop(v28_3_write);
      compose(&(v26_9),&(v28_3))
    };
    let v27_6: Space = if (&(v26_15)).is_empty() { Space::new() } else {
      let v30_2: Path = concat_path(&(*p1),&v26_16_cursor.path()[v26_16_origin..(v26_16_origin + 1)]);
      let mut v30_5 = Space::new();
      let mut v30_5_write = v30_5.write_zipper();
      for v30_5_byte in v26_16_cursor.child_mask().iter() {
        v26_16_cursor.descend_to_existing_byte(v30_5_byte);
        {
        let v31_2: Space = routine_5(c, &v26_16_cursor.path()[(v26_16_origin + 1)..(v26_16_origin + 2)], &v26_16_cursor.path()[(v26_16_origin + 1)..(v26_16_origin + 2)], &(*p2), &(v30_2), &v26_16_cursor);
        join_wrapped_into(&mut v30_5_write,&((v31_2).read_zipper()),&[]);
        }
        v26_16_cursor.ascend(1);
      }
      drop(v30_5_write);
      drop(v30_2);
      compose(&(v26_15),&(v30_5))
    };
    let v27_7: Space = unite(&(v27_4),&(v27_6));
    join_wrapped_into(&mut v26_16_write,&((v27_7).read_zipper()),&[]);
    }
    v26_16_cursor.ascend(1);
  }
  drop(v26_16_cursor);
  drop(v26_16_write);
  drop(v26_9);
  drop(v26_15);
  (v26_16).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v32_7: Space = singleton(&(*p1));
  let v32_8: Space = intersect(&(*CONSTANT_5),&(v32_7));
  let v32_9: Space = if has_head(&(v32_8)) { singleton(&[]) } else { Space::new() };
  drop(v32_8);
  let v32_10: Space = subtract(&(*CONSTANT_0),&(v32_9));
  drop(v32_9);
  let v32_21: Space = if (&(v32_10)).is_empty() { Space::new() } else {
    let v33_13: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v33_16: Space = if (&(v33_13)).is_empty() { Space::new() } else {
      let v34_15: Space = routine_6(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      compose(&(v33_13),&(v34_15))
    };
    drop(v33_13);
    let mut v33_19 = Space::new();
    let mut v33_19_write = v33_19.write_zipper();
    let mut v33_19_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v33_19_origin = v33_19_cursor.path().len();
    for v33_19_byte in v33_19_cursor.child_mask().iter() {
      v33_19_cursor.descend_to_existing_byte(v33_19_byte);
      {
      let v35_2_arg_0: &[u8] = &v33_19_cursor.path()[v33_19_origin..(v33_19_origin + 1)];
      let v35_2_arg_1: &[u8] = &(*p0);
      let v35_2_arg_2: &[u8] = &(*p2);
      let v35_2_arg_3: &[u8] = &(*p3);
      let v35_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v35_2_more = v33_19_cursor.is_val() || next_value_within(&mut v33_19_cursor,(v33_19_origin + 1));
      while v35_2_more {
        {
        let v35_2_depth = v33_19_cursor.path().len();
        let mut v36_6_cursor = (*v35_2_arg_5).read_zipper();
        let v36_6_origin = v36_6_cursor.path().len();
        for v36_6_byte in v36_6_cursor.child_mask().iter() {
          v36_6_cursor.descend_to_existing_byte(v36_6_byte);
          {
          let v37_2: Path = concat_path(&(*v35_2_arg_1),&v36_6_cursor.path()[v36_6_origin..(v36_6_origin + 1)]);
          let v37_3: Space = routine_5(c, &(v37_2), &v33_19_cursor.path()[v33_19_origin..v35_2_depth], &(*v35_2_arg_2), &(*v35_2_arg_3), &v36_6_cursor);
          drop(v37_2);
          join_wrapped_into(&mut v33_19_write,&((v37_3).read_zipper()),&[]);
          }
          v36_6_cursor.ascend(1);
        }
        drop(v36_6_cursor);
        }
        v35_2_more = next_value_within(&mut v33_19_cursor,(v33_19_origin + 1));
      }
      }
      v33_19_cursor.ascend(1);
    }
    drop(v33_19_cursor);
    drop(v33_19_write);
    let v33_20: Space = unite(&(v33_16),&(v33_19));
    compose(&(v32_10),&(v33_20))
  };
  drop(v32_10);
  let v32_23: Space = intersect(&(*CONSTANT_5),&(v32_7));
  drop(v32_7);
  let v32_24: Space = if has_head(&(v32_23)) { singleton(&[]) } else { Space::new() };
  drop(v32_23);
  let v32_26: Space = if (&(v32_24)).is_empty() { Space::new() } else {
    let mut v38_25 = Space::new();
    let mut v38_25_write = v38_25.write_zipper();
    let mut v38_25_cursor = (*s0).read_zipper();
    let v38_25_origin = v38_25_cursor.path().len();
    for v38_25_byte in v38_25_cursor.child_mask().iter() {
      v38_25_cursor.descend_to_existing_byte(v38_25_byte);
      {
      let v39_2: Space = routine_7(c, &v38_25_cursor.path()[v38_25_origin..(v38_25_origin + 1)], &v38_25_cursor.path()[v38_25_origin..(v38_25_origin + 1)], &(*p2), &(*p3), &(*p0), &v38_25_cursor);
      join_wrapped_into(&mut v38_25_write,&((v39_2).read_zipper()),&[]);
      }
      v38_25_cursor.ascend(1);
    }
    drop(v38_25_cursor);
    drop(v38_25_write);
    compose(&(v32_24),&(v38_25))
  };
  drop(v32_24);
  let v32_27: Space = unite(&(v32_21),&(v32_26));
  (v32_27).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v40_7: Space = singleton(&(*p0));
  let v40_8: Space = intersect(&(*CONSTANT_5),&(v40_7));
  let v40_9: Space = if has_head(&(v40_8)) { singleton(&[]) } else { Space::new() };
  drop(v40_8);
  let v40_10: Space = subtract(&(*CONSTANT_0),&(v40_9));
  drop(v40_9);
  let v40_15: Space = intersect(&(*CONSTANT_5),&(v40_7));
  drop(v40_7);
  let v40_16: Space = if has_head(&(v40_15)) { singleton(&[]) } else { Space::new() };
  drop(v40_15);
  let mut v40_17 = Space::new();
  let mut v40_17_write = v40_17.write_zipper();
  let mut v40_17_cursor = (*s0).read_zipper();
  let v40_17_origin = v40_17_cursor.path().len();
  for v40_17_byte in v40_17_cursor.child_mask().iter() {
    v40_17_cursor.descend_to_existing_byte(v40_17_byte);
    {
    let v41_4: Space = if (&(v40_10)).is_empty() { Space::new() } else {
      let v42_2: Path = concat_path(&(*p1),&v40_17_cursor.path()[v40_17_origin..(v40_17_origin + 1)]);
      let mut v42_3 = Space::new();
      let mut v42_3_write = v42_3.write_zipper();
      let v42_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v42_3_arg_1: &[u8] = &(v42_2);
      let v42_3_arg_2: &[u8] = &(*p2);
      let v42_3_arg_3: &[u8] = &(*p3);
      let v42_3_arg_5: &Space = &(&v40_17_cursor).make_map();
      let mut v42_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v42_3_origin = v42_3_cursor.path().len();
      let mut v42_3_more = v42_3_cursor.is_val() || next_value_within(&mut v42_3_cursor,v42_3_origin);
      while v42_3_more {
        {
        let v42_3_depth = v42_3_cursor.path().len();
        let v43_6: Space = routine_6(c, &v42_3_cursor.path()[v42_3_origin..v42_3_depth], &(*v42_3_arg_1), &(*v42_3_arg_2), &(*v42_3_arg_3), &((*v42_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v42_3_write,&((v43_6).read_zipper()),&[]);
        }
        v42_3_more = next_value_within(&mut v42_3_cursor,v42_3_origin);
      }
      drop(v42_3_cursor);
      drop(v42_3_write);
      compose(&(v40_10),&(v42_3))
    };
    let v41_6: Space = if (&(v40_16)).is_empty() { Space::new() } else {
      let v44_2: Path = concat_path(&(*p1),&v40_17_cursor.path()[v40_17_origin..(v40_17_origin + 1)]);
      let mut v44_5 = Space::new();
      let mut v44_5_write = v44_5.write_zipper();
      for v44_5_byte in v40_17_cursor.child_mask().iter() {
        v40_17_cursor.descend_to_existing_byte(v44_5_byte);
        {
        let v45_2: Space = routine_7(c, &v40_17_cursor.path()[(v40_17_origin + 1)..(v40_17_origin + 2)], &v40_17_cursor.path()[(v40_17_origin + 1)..(v40_17_origin + 2)], &(*p2), &(*p3), &(v44_2), &v40_17_cursor);
        join_wrapped_into(&mut v44_5_write,&((v45_2).read_zipper()),&[]);
        }
        v40_17_cursor.ascend(1);
      }
      drop(v44_5_write);
      drop(v44_2);
      compose(&(v40_16),&(v44_5))
    };
    let v41_7: Space = unite(&(v41_4),&(v41_6));
    join_wrapped_into(&mut v40_17_write,&((v41_7).read_zipper()),&[]);
    }
    v40_17_cursor.ascend(1);
  }
  drop(v40_17_cursor);
  drop(v40_17_write);
  drop(v40_10);
  drop(v40_16);
  (v40_17).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v46_8: Space = singleton(&(*p1));
  let v46_9: Space = intersect(&(*CONSTANT_5),&(v46_8));
  let v46_10: Space = if has_head(&(v46_9)) { singleton(&[]) } else { Space::new() };
  drop(v46_9);
  let v46_11: Space = subtract(&(*CONSTANT_0),&(v46_10));
  drop(v46_10);
  let v46_22: Space = if (&(v46_11)).is_empty() { Space::new() } else {
    let v47_14: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v47_17: Space = if (&(v47_14)).is_empty() { Space::new() } else {
      let v48_16: Space = routine_8(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*s0));
      compose(&(v47_14),&(v48_16))
    };
    drop(v47_14);
    let mut v47_20 = Space::new();
    let mut v47_20_write = v47_20.write_zipper();
    let mut v47_20_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v47_20_origin = v47_20_cursor.path().len();
    for v47_20_byte in v47_20_cursor.child_mask().iter() {
      v47_20_cursor.descend_to_existing_byte(v47_20_byte);
      {
      let v49_2_arg_0: &[u8] = &v47_20_cursor.path()[v47_20_origin..(v47_20_origin + 1)];
      let v49_2_arg_1: &[u8] = &(*p0);
      let v49_2_arg_2: &[u8] = &(*p2);
      let v49_2_arg_3: &[u8] = &(*p3);
      let v49_2_arg_4: &[u8] = &(*p4);
      let v49_2_arg_6: &Space = &(&(*s0)).make_map();
      let mut v49_2_more = v47_20_cursor.is_val() || next_value_within(&mut v47_20_cursor,(v47_20_origin + 1));
      while v49_2_more {
        {
        let v49_2_depth = v47_20_cursor.path().len();
        let mut v50_7_cursor = (*v49_2_arg_6).read_zipper();
        let v50_7_origin = v50_7_cursor.path().len();
        for v50_7_byte in v50_7_cursor.child_mask().iter() {
          v50_7_cursor.descend_to_existing_byte(v50_7_byte);
          {
          let v51_2: Path = concat_path(&(*v49_2_arg_1),&v50_7_cursor.path()[v50_7_origin..(v50_7_origin + 1)]);
          let v51_3: Space = routine_7(c, &(v51_2), &v47_20_cursor.path()[v47_20_origin..v49_2_depth], &(*v49_2_arg_2), &(*v49_2_arg_3), &(*v49_2_arg_4), &v50_7_cursor);
          drop(v51_2);
          join_wrapped_into(&mut v47_20_write,&((v51_3).read_zipper()),&[]);
          }
          v50_7_cursor.ascend(1);
        }
        drop(v50_7_cursor);
        }
        v49_2_more = next_value_within(&mut v47_20_cursor,(v47_20_origin + 1));
      }
      }
      v47_20_cursor.ascend(1);
    }
    drop(v47_20_cursor);
    drop(v47_20_write);
    let v47_21: Space = unite(&(v47_17),&(v47_20));
    compose(&(v46_11),&(v47_21))
  };
  drop(v46_11);
  let v46_24: Space = intersect(&(*CONSTANT_5),&(v46_8));
  drop(v46_8);
  let v46_25: Space = if has_head(&(v46_24)) { singleton(&[]) } else { Space::new() };
  drop(v46_24);
  let v46_32: Space = if (&(v46_25)).is_empty() { Space::new() } else {
    let v52_26: Path = concat_path(&(*p3),&(*p4));
    let v52_27: Path = concat_path(&(v52_26),&(*p0));
    drop(v52_26);
    let v52_28: Space = singleton(&(v52_27));
    drop(v52_27);
    let v52_29: Space = routine_9(c, &(*p2), &((v52_28).read_zipper()));
    drop(v52_28);
    let mut v52_30 = Space::new();
    let mut v52_30_write = v52_30.write_zipper();
    let mut v52_30_cursor = (v52_29).read_zipper();
    let v52_30_origin = v52_30_cursor.path().len();
    for v52_30_byte in v52_30_cursor.child_mask().iter() {
      v52_30_cursor.descend_to_existing_byte(v52_30_byte);
      {
      let v53_2: Space = routine_10(c, &v52_30_cursor.path()[v52_30_origin..(v52_30_origin + 1)], &v52_30_cursor.path()[v52_30_origin..(v52_30_origin + 1)], &(*p2), &v52_30_cursor);
      join_wrapped_into(&mut v52_30_write,&((v53_2).read_zipper()),&[]);
      }
      v52_30_cursor.ascend(1);
    }
    drop(v52_30_cursor);
    drop(v52_30_write);
    let mut v52_31 = Space::new();
    let mut v52_31_write = v52_31.write_zipper();
    let mut v52_31_cursor = (v52_30).read_zipper();
    let v52_31_origin = v52_31_cursor.path().len();
    for v52_31_byte in v52_31_cursor.child_mask().iter() {
      v52_31_cursor.descend_to_existing_byte(v52_31_byte);
      {
      let v54_2: Space = routine_11(c, &v52_31_cursor.path()[v52_31_origin..(v52_31_origin + 1)], &v52_31_cursor.path()[v52_31_origin..(v52_31_origin + 1)], &(*p2), &v52_31_cursor);
      join_wrapped_into(&mut v52_31_write,&((v54_2).read_zipper()),&[]);
      }
      v52_31_cursor.ascend(1);
    }
    drop(v52_31_cursor);
    drop(v52_31_write);
    compose(&(v46_25),&(v52_31))
  };
  drop(v46_25);
  let v46_33: Space = unite(&(v46_22),&(v46_32));
  (v46_33).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v55_8: Space = singleton(&(*p0));
  let v55_9: Space = intersect(&(*CONSTANT_5),&(v55_8));
  let v55_10: Space = if has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
  drop(v55_9);
  let v55_11: Space = subtract(&(*CONSTANT_0),&(v55_10));
  drop(v55_10);
  let v55_16: Space = intersect(&(*CONSTANT_5),&(v55_8));
  drop(v55_8);
  let v55_17: Space = if has_head(&(v55_16)) { singleton(&[]) } else { Space::new() };
  drop(v55_16);
  let v55_18: Path = concat_path(&(*p3),&(*p4));
  let mut v55_19 = Space::new();
  let mut v55_19_write = v55_19.write_zipper();
  let mut v55_19_cursor = (*s0).read_zipper();
  let v55_19_origin = v55_19_cursor.path().len();
  for v55_19_byte in v55_19_cursor.child_mask().iter() {
    v55_19_cursor.descend_to_existing_byte(v55_19_byte);
    {
    let v56_4: Space = if (&(v55_11)).is_empty() { Space::new() } else {
      let v57_2: Path = concat_path(&(*p1),&v55_19_cursor.path()[v55_19_origin..(v55_19_origin + 1)]);
      let mut v57_3 = Space::new();
      let mut v57_3_write = v57_3.write_zipper();
      let v57_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v57_3_arg_1: &[u8] = &(v57_2);
      let v57_3_arg_2: &[u8] = &(*p2);
      let v57_3_arg_3: &[u8] = &(*p3);
      let v57_3_arg_4: &[u8] = &(*p4);
      let v57_3_arg_6: &Space = &(&v55_19_cursor).make_map();
      let mut v57_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v57_3_origin = v57_3_cursor.path().len();
      let mut v57_3_more = v57_3_cursor.is_val() || next_value_within(&mut v57_3_cursor,v57_3_origin);
      while v57_3_more {
        {
        let v57_3_depth = v57_3_cursor.path().len();
        let v58_7: Space = routine_8(c, &v57_3_cursor.path()[v57_3_origin..v57_3_depth], &(*v57_3_arg_1), &(*v57_3_arg_2), &(*v57_3_arg_3), &(*v57_3_arg_4), &((*v57_3_arg_6).read_zipper()));
        join_wrapped_into(&mut v57_3_write,&((v58_7).read_zipper()),&[]);
        }
        v57_3_more = next_value_within(&mut v57_3_cursor,v57_3_origin);
      }
      drop(v57_3_cursor);
      drop(v57_3_write);
      compose(&(v55_11),&(v57_3))
    };
    let v56_10: Space = if (&(v55_17)).is_empty() { Space::new() } else {
      let v59_2: Path = concat_path(&(*p1),&v55_19_cursor.path()[v55_19_origin..(v55_19_origin + 1)]);
      let v59_5: Path = concat_path(&(v55_18),&(v59_2));
      drop(v59_2);
      let v59_6: Space = singleton(&(v59_5));
      drop(v59_5);
      let v59_7: Space = routine_9(c, &(*p2), &((v59_6).read_zipper()));
      drop(v59_6);
      let mut v59_8 = Space::new();
      let mut v59_8_write = v59_8.write_zipper();
      let mut v59_8_cursor = (v59_7).read_zipper();
      let v59_8_origin = v59_8_cursor.path().len();
      for v59_8_byte in v59_8_cursor.child_mask().iter() {
        v59_8_cursor.descend_to_existing_byte(v59_8_byte);
        {
        let v60_2: Space = routine_10(c, &v59_8_cursor.path()[v59_8_origin..(v59_8_origin + 1)], &v59_8_cursor.path()[v59_8_origin..(v59_8_origin + 1)], &(*p2), &v59_8_cursor);
        join_wrapped_into(&mut v59_8_write,&((v60_2).read_zipper()),&[]);
        }
        v59_8_cursor.ascend(1);
      }
      drop(v59_8_cursor);
      drop(v59_8_write);
      let mut v59_9 = Space::new();
      let mut v59_9_write = v59_9.write_zipper();
      let mut v59_9_cursor = (v59_8).read_zipper();
      let v59_9_origin = v59_9_cursor.path().len();
      for v59_9_byte in v59_9_cursor.child_mask().iter() {
        v59_9_cursor.descend_to_existing_byte(v59_9_byte);
        {
        let v61_2: Space = routine_11(c, &v59_9_cursor.path()[v59_9_origin..(v59_9_origin + 1)], &v59_9_cursor.path()[v59_9_origin..(v59_9_origin + 1)], &(*p2), &v59_9_cursor);
        join_wrapped_into(&mut v59_9_write,&((v61_2).read_zipper()),&[]);
        }
        v59_9_cursor.ascend(1);
      }
      drop(v59_9_cursor);
      drop(v59_9_write);
      compose(&(v55_17),&(v59_9))
    };
    let v56_11: Space = unite(&(v56_4),&(v56_10));
    join_wrapped_into(&mut v55_19_write,&((v56_11).read_zipper()),&[]);
    }
    v55_19_cursor.ascend(1);
  }
  drop(v55_19_cursor);
  drop(v55_19_write);
  drop(v55_11);
  drop(v55_17);
  drop(v55_18);
  (v55_19).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v62_3: Space = singleton(&(*p0));
  let v62_4: Space = intersect(&(*CONSTANT_7),&(v62_3));
  let v62_770: Space = drop_length_prefixes(&(v62_4));
  drop(v62_4);
  let v62_777: Space = if (&(v62_770)).is_empty() { Space::new() } else {
    let mut v63_776 = Space::new();
    let mut v63_776_write = v63_776.write_zipper();
    let mut v63_776_cursor = (*s0).read_zipper();
    let v63_776_origin = v63_776_cursor.path().len();
    for v63_776_byte in v63_776_cursor.child_mask().iter() {
      v63_776_cursor.descend_to_existing_byte(v63_776_byte);
      {
      let v64_2: Space = singleton(&v63_776_cursor.path()[v63_776_origin..(v63_776_origin + 1)]);
      let v64_3: Space = intersect(&(*CONSTANT_5),&(v64_2));
      let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
      drop(v64_3);
      let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
      drop(v64_4);
      let v64_8: Space = if (&(v64_5)).is_empty() { Space::new() } else {
        let mut v65_7 = Space::new();
        let mut v65_7_write = v65_7.write_zipper();
        let v65_7_arg_0: &[u8] = &(*CONSTANT_1);
        let v65_7_arg_1: &[u8] = &v63_776_cursor.path()[v63_776_origin..(v63_776_origin + 1)];
        let v65_7_arg_3: &Space = &(&v63_776_cursor).make_map();
        let mut v65_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v63_776_cursor.path()[v63_776_origin..(v63_776_origin + 1)]);
        let v65_7_origin = v65_7_cursor.path().len();
        let mut v65_7_more = v65_7_cursor.is_val() || next_value_within(&mut v65_7_cursor,v65_7_origin);
        while v65_7_more {
          {
          let v65_7_depth = v65_7_cursor.path().len();
          let mut v66_4_cursor = (*v65_7_arg_3).read_zipper();
          let v66_4_origin = v66_4_cursor.path().len();
          for v66_4_byte in v66_4_cursor.child_mask().iter() {
            v66_4_cursor.descend_to_existing_byte(v66_4_byte);
            {
            let v67_2: Path = concat_path(&(*v65_7_arg_1),&v66_4_cursor.path()[v66_4_origin..(v66_4_origin + 1)]);
            let v67_3: Space = routine_12(c, &(v67_2), &v65_7_cursor.path()[v65_7_origin..v65_7_depth], &v66_4_cursor);
            drop(v67_2);
            join_wrapped_into(&mut v65_7_write,&((v67_3).read_zipper()),&[]);
            }
            v66_4_cursor.ascend(1);
          }
          drop(v66_4_cursor);
          }
          v65_7_more = next_value_within(&mut v65_7_cursor,v65_7_origin);
        }
        drop(v65_7_cursor);
        drop(v65_7_write);
        compose(&(v64_5),&(v65_7))
      };
      drop(v64_5);
      let v64_9: Space = intersect(&(*CONSTANT_5),&(v64_2));
      drop(v64_2);
      let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
      drop(v64_9);
      let v64_12: Space = if (&(v64_10)).is_empty() { Space::new() } else {
        let v68_11: Space = routine_13(c, &v63_776_cursor.path()[v63_776_origin..(v63_776_origin + 1)], &v63_776_cursor);
        compose(&(v64_10),&(v68_11))
      };
      drop(v64_10);
      let v64_13: Space = unite(&(v64_8),&(v64_12));
      join_wrapped_into(&mut v63_776_write,&((v64_13).read_zipper()),&[]);
      }
      v63_776_cursor.ascend(1);
    }
    drop(v63_776_cursor);
    drop(v63_776_write);
    compose(&(v62_770),&(v63_776))
  };
  drop(v62_770);
  let v62_779: Space = intersect(&(*CONSTANT_8),&(v62_3));
  let v62_1545: Space = drop_length_prefixes(&(v62_779));
  drop(v62_779);
  let v62_1551: Space = if (&(v62_1545)).is_empty() { Space::new() } else {
    let mut v69_1550 = Space::new();
    let mut v69_1550_write = v69_1550.write_zipper();
    let mut v69_1550_cursor = (*s0).read_zipper();
    let v69_1550_origin = v69_1550_cursor.path().len();
    for v69_1550_byte in v69_1550_cursor.child_mask().iter() {
      v69_1550_cursor.descend_to_existing_byte(v69_1550_byte);
      {
      let v70_2: Space = singleton(&v69_1550_cursor.path()[v69_1550_origin..(v69_1550_origin + 1)]);
      let v70_3: Space = intersect(&(*CONSTANT_5),&(v70_2));
      let v70_4: Space = if has_head(&(v70_3)) { singleton(&[]) } else { Space::new() };
      drop(v70_3);
      let v70_5: Space = subtract(&(*CONSTANT_0),&(v70_4));
      drop(v70_4);
      let v70_8: Space = if (&(v70_5)).is_empty() { Space::new() } else {
        let mut v71_7 = Space::new();
        let mut v71_7_write = v71_7.write_zipper();
        let v71_7_arg_0: &[u8] = &(*CONSTANT_1);
        let v71_7_arg_1: &[u8] = &v69_1550_cursor.path()[v69_1550_origin..(v69_1550_origin + 1)];
        let v71_7_arg_3: &Space = &(&v69_1550_cursor).make_map();
        let mut v71_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v69_1550_cursor.path()[v69_1550_origin..(v69_1550_origin + 1)]);
        let v71_7_origin = v71_7_cursor.path().len();
        let mut v71_7_more = v71_7_cursor.is_val() || next_value_within(&mut v71_7_cursor,v71_7_origin);
        while v71_7_more {
          {
          let v71_7_depth = v71_7_cursor.path().len();
          let mut v72_4_cursor = (*v71_7_arg_3).read_zipper();
          let v72_4_origin = v72_4_cursor.path().len();
          for v72_4_byte in v72_4_cursor.child_mask().iter() {
            v72_4_cursor.descend_to_existing_byte(v72_4_byte);
            {
            let v73_2: Path = concat_path(&(*v71_7_arg_1),&v72_4_cursor.path()[v72_4_origin..(v72_4_origin + 1)]);
            let v73_3: Space = routine_14(c, &(v73_2), &v71_7_cursor.path()[v71_7_origin..v71_7_depth], &v72_4_cursor);
            drop(v73_2);
            join_wrapped_into(&mut v71_7_write,&((v73_3).read_zipper()),&[]);
            }
            v72_4_cursor.ascend(1);
          }
          drop(v72_4_cursor);
          }
          v71_7_more = next_value_within(&mut v71_7_cursor,v71_7_origin);
        }
        drop(v71_7_cursor);
        drop(v71_7_write);
        compose(&(v70_5),&(v71_7))
      };
      drop(v70_5);
      let v70_9: Space = intersect(&(*CONSTANT_5),&(v70_2));
      drop(v70_2);
      let v70_10: Space = if has_head(&(v70_9)) { singleton(&[]) } else { Space::new() };
      drop(v70_9);
      let v70_12: Space = if (&(v70_10)).is_empty() { Space::new() } else {
        let v74_11: Space = routine_15(c, &v69_1550_cursor.path()[v69_1550_origin..(v69_1550_origin + 1)], &v69_1550_cursor);
        compose(&(v70_10),&(v74_11))
      };
      drop(v70_10);
      let v70_13: Space = unite(&(v70_8),&(v70_12));
      join_wrapped_into(&mut v69_1550_write,&((v70_13).read_zipper()),&[]);
      }
      v69_1550_cursor.ascend(1);
    }
    drop(v69_1550_cursor);
    drop(v69_1550_write);
    compose(&(v62_1545),&(v69_1550))
  };
  drop(v62_1545);
  let v62_1552: Space = unite(&(v62_777),&(v62_1551));
  let v62_1554: Space = intersect(&(*CONSTANT_9),&(v62_3));
  let v62_2320: Space = drop_length_prefixes(&(v62_1554));
  drop(v62_1554);
  let v62_2326: Space = if (&(v62_2320)).is_empty() { Space::new() } else {
    let mut v75_2325 = Space::new();
    let mut v75_2325_write = v75_2325.write_zipper();
    let mut v75_2325_cursor = (*s0).read_zipper();
    let v75_2325_origin = v75_2325_cursor.path().len();
    for v75_2325_byte in v75_2325_cursor.child_mask().iter() {
      v75_2325_cursor.descend_to_existing_byte(v75_2325_byte);
      {
      let v76_2: Space = singleton(&v75_2325_cursor.path()[v75_2325_origin..(v75_2325_origin + 1)]);
      let v76_3: Space = intersect(&(*CONSTANT_5),&(v76_2));
      let v76_4: Space = if has_head(&(v76_3)) { singleton(&[]) } else { Space::new() };
      drop(v76_3);
      let v76_5: Space = subtract(&(*CONSTANT_0),&(v76_4));
      drop(v76_4);
      let v76_8: Space = if (&(v76_5)).is_empty() { Space::new() } else {
        let mut v77_7 = Space::new();
        let mut v77_7_write = v77_7.write_zipper();
        let v77_7_arg_0: &[u8] = &(*CONSTANT_1);
        let v77_7_arg_1: &[u8] = &v75_2325_cursor.path()[v75_2325_origin..(v75_2325_origin + 1)];
        let v77_7_arg_3: &Space = &(&v75_2325_cursor).make_map();
        let mut v77_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v75_2325_cursor.path()[v75_2325_origin..(v75_2325_origin + 1)]);
        let v77_7_origin = v77_7_cursor.path().len();
        let mut v77_7_more = v77_7_cursor.is_val() || next_value_within(&mut v77_7_cursor,v77_7_origin);
        while v77_7_more {
          {
          let v77_7_depth = v77_7_cursor.path().len();
          let mut v78_4_cursor = (*v77_7_arg_3).read_zipper();
          let v78_4_origin = v78_4_cursor.path().len();
          for v78_4_byte in v78_4_cursor.child_mask().iter() {
            v78_4_cursor.descend_to_existing_byte(v78_4_byte);
            {
            let v79_2: Path = concat_path(&(*v77_7_arg_1),&v78_4_cursor.path()[v78_4_origin..(v78_4_origin + 1)]);
            let v79_3: Space = routine_16(c, &(v79_2), &v77_7_cursor.path()[v77_7_origin..v77_7_depth], &v78_4_cursor);
            drop(v79_2);
            join_wrapped_into(&mut v77_7_write,&((v79_3).read_zipper()),&[]);
            }
            v78_4_cursor.ascend(1);
          }
          drop(v78_4_cursor);
          }
          v77_7_more = next_value_within(&mut v77_7_cursor,v77_7_origin);
        }
        drop(v77_7_cursor);
        drop(v77_7_write);
        compose(&(v76_5),&(v77_7))
      };
      drop(v76_5);
      let v76_9: Space = intersect(&(*CONSTANT_5),&(v76_2));
      drop(v76_2);
      let v76_10: Space = if has_head(&(v76_9)) { singleton(&[]) } else { Space::new() };
      drop(v76_9);
      let v76_12: Space = if (&(v76_10)).is_empty() { Space::new() } else {
        let v80_11: Space = routine_17(c, &v75_2325_cursor.path()[v75_2325_origin..(v75_2325_origin + 1)], &v75_2325_cursor);
        compose(&(v76_10),&(v80_11))
      };
      drop(v76_10);
      let v76_13: Space = unite(&(v76_8),&(v76_12));
      join_wrapped_into(&mut v75_2325_write,&((v76_13).read_zipper()),&[]);
      }
      v75_2325_cursor.ascend(1);
    }
    drop(v75_2325_cursor);
    drop(v75_2325_write);
    compose(&(v62_2320),&(v75_2325))
  };
  drop(v62_2320);
  let v62_2327: Space = unite(&(v62_1552),&(v62_2326));
  let v62_2329: Space = intersect(&(*CONSTANT_10),&(v62_3));
  drop(v62_3);
  let v62_3095: Space = drop_length_prefixes(&(v62_2329));
  drop(v62_2329);
  let v62_3101: Space = if (&(v62_3095)).is_empty() { Space::new() } else {
    let mut v81_3100 = Space::new();
    let mut v81_3100_write = v81_3100.write_zipper();
    let mut v81_3100_cursor = (*s0).read_zipper();
    let v81_3100_origin = v81_3100_cursor.path().len();
    for v81_3100_byte in v81_3100_cursor.child_mask().iter() {
      v81_3100_cursor.descend_to_existing_byte(v81_3100_byte);
      {
      let v82_2: Space = singleton(&v81_3100_cursor.path()[v81_3100_origin..(v81_3100_origin + 1)]);
      let v82_3: Space = intersect(&(*CONSTANT_5),&(v82_2));
      let v82_4: Space = if has_head(&(v82_3)) { singleton(&[]) } else { Space::new() };
      drop(v82_3);
      let v82_5: Space = subtract(&(*CONSTANT_0),&(v82_4));
      drop(v82_4);
      let v82_8: Space = if (&(v82_5)).is_empty() { Space::new() } else {
        let mut v83_7 = Space::new();
        let mut v83_7_write = v83_7.write_zipper();
        let v83_7_arg_0: &[u8] = &(*CONSTANT_1);
        let v83_7_arg_1: &[u8] = &v81_3100_cursor.path()[v81_3100_origin..(v81_3100_origin + 1)];
        let v83_7_arg_3: &Space = &(&v81_3100_cursor).make_map();
        let mut v83_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v81_3100_cursor.path()[v81_3100_origin..(v81_3100_origin + 1)]);
        let v83_7_origin = v83_7_cursor.path().len();
        let mut v83_7_more = v83_7_cursor.is_val() || next_value_within(&mut v83_7_cursor,v83_7_origin);
        while v83_7_more {
          {
          let v83_7_depth = v83_7_cursor.path().len();
          let mut v84_4_cursor = (*v83_7_arg_3).read_zipper();
          let v84_4_origin = v84_4_cursor.path().len();
          for v84_4_byte in v84_4_cursor.child_mask().iter() {
            v84_4_cursor.descend_to_existing_byte(v84_4_byte);
            {
            let v85_2: Path = concat_path(&(*v83_7_arg_1),&v84_4_cursor.path()[v84_4_origin..(v84_4_origin + 1)]);
            let v85_3: Space = routine_18(c, &(v85_2), &v83_7_cursor.path()[v83_7_origin..v83_7_depth], &v84_4_cursor);
            drop(v85_2);
            join_wrapped_into(&mut v83_7_write,&((v85_3).read_zipper()),&[]);
            }
            v84_4_cursor.ascend(1);
          }
          drop(v84_4_cursor);
          }
          v83_7_more = next_value_within(&mut v83_7_cursor,v83_7_origin);
        }
        drop(v83_7_cursor);
        drop(v83_7_write);
        compose(&(v82_5),&(v83_7))
      };
      drop(v82_5);
      let v82_9: Space = intersect(&(*CONSTANT_5),&(v82_2));
      drop(v82_2);
      let v82_10: Space = if has_head(&(v82_9)) { singleton(&[]) } else { Space::new() };
      drop(v82_9);
      let v82_12: Space = if (&(v82_10)).is_empty() { Space::new() } else {
        let v86_11: Space = routine_19(c, &v81_3100_cursor.path()[v81_3100_origin..(v81_3100_origin + 1)], &v81_3100_cursor);
        compose(&(v82_10),&(v86_11))
      };
      drop(v82_10);
      let v82_13: Space = unite(&(v82_8),&(v82_12));
      join_wrapped_into(&mut v81_3100_write,&((v82_13).read_zipper()),&[]);
      }
      v81_3100_cursor.ascend(1);
    }
    drop(v81_3100_cursor);
    drop(v81_3100_write);
    compose(&(v62_3095),&(v81_3100))
  };
  drop(v62_3095);
  let v62_3102: Space = unite(&(v62_2327),&(v62_3101));
  (v62_3102).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v87_6: Space = singleton(&(*p1));
  let v87_7: Space = intersect(&(*CONSTANT_5),&(v87_6));
  let v87_8: Space = if has_head(&(v87_7)) { singleton(&[]) } else { Space::new() };
  drop(v87_7);
  let v87_9: Space = subtract(&(*CONSTANT_0),&(v87_8));
  drop(v87_8);
  let v87_20: Space = if (&(v87_9)).is_empty() { Space::new() } else {
    let v88_12: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v88_15: Space = if (&(v88_12)).is_empty() { Space::new() } else {
      let v89_14: Space = routine_20(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v88_12),&(v89_14))
    };
    drop(v88_12);
    let mut v88_18 = Space::new();
    let mut v88_18_write = v88_18.write_zipper();
    let mut v88_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v88_18_origin = v88_18_cursor.path().len();
    for v88_18_byte in v88_18_cursor.child_mask().iter() {
      v88_18_cursor.descend_to_existing_byte(v88_18_byte);
      {
      let v90_2_arg_0: &[u8] = &v88_18_cursor.path()[v88_18_origin..(v88_18_origin + 1)];
      let v90_2_arg_1: &[u8] = &(*p0);
      let v90_2_arg_2: &[u8] = &(*p2);
      let v90_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v90_2_more = v88_18_cursor.is_val() || next_value_within(&mut v88_18_cursor,(v88_18_origin + 1));
      while v90_2_more {
        {
        let v90_2_depth = v88_18_cursor.path().len();
        let mut v91_5_cursor = (*v90_2_arg_4).read_zipper();
        let v91_5_origin = v91_5_cursor.path().len();
        for v91_5_byte in v91_5_cursor.child_mask().iter() {
          v91_5_cursor.descend_to_existing_byte(v91_5_byte);
          {
          let v92_2: Path = concat_path(&(*v90_2_arg_1),&v91_5_cursor.path()[v91_5_origin..(v91_5_origin + 1)]);
          let v92_3: Space = routine_10(c, &(v92_2), &v88_18_cursor.path()[v88_18_origin..v90_2_depth], &(*v90_2_arg_2), &v91_5_cursor);
          drop(v92_2);
          join_wrapped_into(&mut v88_18_write,&((v92_3).read_zipper()),&[]);
          }
          v91_5_cursor.ascend(1);
        }
        drop(v91_5_cursor);
        }
        v90_2_more = next_value_within(&mut v88_18_cursor,(v88_18_origin + 1));
      }
      }
      v88_18_cursor.ascend(1);
    }
    drop(v88_18_cursor);
    drop(v88_18_write);
    let v88_19: Space = unite(&(v88_15),&(v88_18));
    compose(&(v87_9),&(v88_19))
  };
  drop(v87_9);
  let v87_22: Space = intersect(&(*CONSTANT_5),&(v87_6));
  drop(v87_6);
  let v87_23: Space = if has_head(&(v87_22)) { singleton(&[]) } else { Space::new() };
  drop(v87_22);
  let v87_29: Space = if (&(v87_23)).is_empty() { Space::new() } else {
    let v93_26: Space = routine_21(c, &(*CONSTANT_2), &(*CONSTANT_2), &((*CONSTANT_11).read_zipper()));
    let mut v93_28 = Space::new();
    let mut v93_28_write = v93_28.write_zipper();
    let mut v93_28_cursor = descend_cursor((v93_26).read_zipper(),&(*p2));
    let v93_28_origin = v93_28_cursor.path().len();
    for v93_28_byte in v93_28_cursor.child_mask().iter() {
      v93_28_cursor.descend_to_existing_byte(v93_28_byte);
      {
      let v94_2: Space = routine_22(c, &v93_28_cursor.path()[v93_28_origin..(v93_28_origin + 1)], &v93_28_cursor.path()[v93_28_origin..(v93_28_origin + 1)], &(*p0), &v93_28_cursor, &(*s0));
      join_wrapped_into(&mut v93_28_write,&((v94_2).read_zipper()),&[]);
      }
      v93_28_cursor.ascend(1);
    }
    drop(v93_28_cursor);
    drop(v93_28_write);
    compose(&(v87_23),&(v93_28))
  };
  drop(v87_23);
  let v87_30: Space = unite(&(v87_20),&(v87_29));
  (v87_30).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v95_6: Space = singleton(&(*p1));
  let v95_7: Space = intersect(&(*CONSTANT_5),&(v95_6));
  let v95_8: Space = if has_head(&(v95_7)) { singleton(&[]) } else { Space::new() };
  drop(v95_7);
  let v95_9: Space = subtract(&(*CONSTANT_0),&(v95_8));
  drop(v95_8);
  let v95_20: Space = if (&(v95_9)).is_empty() { Space::new() } else {
    let v96_12: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v96_15: Space = if (&(v96_12)).is_empty() { Space::new() } else {
      let v97_14: Space = routine_23(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v96_12),&(v97_14))
    };
    drop(v96_12);
    let mut v96_18 = Space::new();
    let mut v96_18_write = v96_18.write_zipper();
    let mut v96_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v96_18_origin = v96_18_cursor.path().len();
    for v96_18_byte in v96_18_cursor.child_mask().iter() {
      v96_18_cursor.descend_to_existing_byte(v96_18_byte);
      {
      let v98_2_arg_0: &[u8] = &v96_18_cursor.path()[v96_18_origin..(v96_18_origin + 1)];
      let v98_2_arg_1: &[u8] = &(*p0);
      let v98_2_arg_2: &[u8] = &(*p2);
      let v98_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v98_2_more = v96_18_cursor.is_val() || next_value_within(&mut v96_18_cursor,(v96_18_origin + 1));
      while v98_2_more {
        {
        let v98_2_depth = v96_18_cursor.path().len();
        let mut v99_5_cursor = (*v98_2_arg_4).read_zipper();
        let v99_5_origin = v99_5_cursor.path().len();
        for v99_5_byte in v99_5_cursor.child_mask().iter() {
          v99_5_cursor.descend_to_existing_byte(v99_5_byte);
          {
          let v100_2: Path = concat_path(&(*v98_2_arg_1),&v99_5_cursor.path()[v99_5_origin..(v99_5_origin + 1)]);
          let v100_3: Space = routine_11(c, &(v100_2), &v96_18_cursor.path()[v96_18_origin..v98_2_depth], &(*v98_2_arg_2), &v99_5_cursor);
          drop(v100_2);
          join_wrapped_into(&mut v96_18_write,&((v100_3).read_zipper()),&[]);
          }
          v99_5_cursor.ascend(1);
        }
        drop(v99_5_cursor);
        }
        v98_2_more = next_value_within(&mut v96_18_cursor,(v96_18_origin + 1));
      }
      }
      v96_18_cursor.ascend(1);
    }
    drop(v96_18_cursor);
    drop(v96_18_write);
    let v96_19: Space = unite(&(v96_15),&(v96_18));
    compose(&(v95_9),&(v96_19))
  };
  drop(v95_9);
  let v95_22: Space = intersect(&(*CONSTANT_5),&(v95_6));
  drop(v95_6);
  let v95_23: Space = if has_head(&(v95_22)) { singleton(&[]) } else { Space::new() };
  drop(v95_22);
  let v95_31: Space = if (&(v95_23)).is_empty() { Space::new() } else {
    let v101_26: Space = routine_24(c, &(*CONSTANT_2), &(*CONSTANT_2), &((*CONSTANT_11).read_zipper()));
    let mut v101_30 = Space::new();
    let mut v101_30_write = v101_30.write_zipper();
    let mut v101_30_cursor = descend_cursor(descend_cursor(descend_cursor((v101_26).read_zipper(),&(*p2)),&(*p0)),&(*p2));
    let v101_30_origin = v101_30_cursor.path().len();
    for v101_30_byte in v101_30_cursor.child_mask().iter() {
      v101_30_cursor.descend_to_existing_byte(v101_30_byte);
      {
      let v102_2: Space = routine_25(c, &v101_30_cursor.path()[v101_30_origin..(v101_30_origin + 1)], &v101_30_cursor.path()[v101_30_origin..(v101_30_origin + 1)], &v101_30_cursor, &(*s0));
      join_wrapped_into(&mut v101_30_write,&((v102_2).read_zipper()),&[]);
      }
      v101_30_cursor.ascend(1);
    }
    drop(v101_30_cursor);
    drop(v101_30_write);
    compose(&(v95_23),&(v101_30))
  };
  drop(v95_23);
  let v95_32: Space = unite(&(v95_20),&(v95_31));
  (v95_32).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v103_5: Space = singleton(&(*p1));
  let v103_6: Space = intersect(&(*CONSTANT_5),&(v103_5));
  let v103_7: Space = if has_head(&(v103_6)) { singleton(&[]) } else { Space::new() };
  drop(v103_6);
  let v103_8: Space = subtract(&(*CONSTANT_0),&(v103_7));
  drop(v103_7);
  let v103_19: Space = if (&(v103_8)).is_empty() { Space::new() } else {
    let v104_11: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v104_14: Space = if (&(v104_11)).is_empty() { Space::new() } else {
      let v105_13: Space = routine_26(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v104_11),&(v105_13))
    };
    drop(v104_11);
    let mut v104_17 = Space::new();
    let mut v104_17_write = v104_17.write_zipper();
    let mut v104_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v104_17_origin = v104_17_cursor.path().len();
    for v104_17_byte in v104_17_cursor.child_mask().iter() {
      v104_17_cursor.descend_to_existing_byte(v104_17_byte);
      {
      let v106_2_arg_0: &[u8] = &v104_17_cursor.path()[v104_17_origin..(v104_17_origin + 1)];
      let v106_2_arg_1: &[u8] = &(*p0);
      let v106_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v106_2_more = v104_17_cursor.is_val() || next_value_within(&mut v104_17_cursor,(v104_17_origin + 1));
      while v106_2_more {
        {
        let v106_2_depth = v104_17_cursor.path().len();
        let mut v107_4_cursor = (*v106_2_arg_3).read_zipper();
        let v107_4_origin = v107_4_cursor.path().len();
        for v107_4_byte in v107_4_cursor.child_mask().iter() {
          v107_4_cursor.descend_to_existing_byte(v107_4_byte);
          {
          let v108_2: Path = concat_path(&(*v106_2_arg_1),&v107_4_cursor.path()[v107_4_origin..(v107_4_origin + 1)]);
          let v108_3: Space = routine_12(c, &(v108_2), &v104_17_cursor.path()[v104_17_origin..v106_2_depth], &v107_4_cursor);
          drop(v108_2);
          join_wrapped_into(&mut v104_17_write,&((v108_3).read_zipper()),&[]);
          }
          v107_4_cursor.ascend(1);
        }
        drop(v107_4_cursor);
        }
        v106_2_more = next_value_within(&mut v104_17_cursor,(v104_17_origin + 1));
      }
      }
      v104_17_cursor.ascend(1);
    }
    drop(v104_17_cursor);
    drop(v104_17_write);
    let v104_18: Space = unite(&(v104_14),&(v104_17));
    compose(&(v103_8),&(v104_18))
  };
  drop(v103_8);
  let v103_21: Space = intersect(&(*CONSTANT_5),&(v103_5));
  drop(v103_5);
  let v103_22: Space = if has_head(&(v103_21)) { singleton(&[]) } else { Space::new() };
  drop(v103_21);
  let v103_24: Space = if (&(v103_22)).is_empty() { Space::new() } else {
    let mut v109_23 = Space::new();
    let mut v109_23_write = v109_23.write_zipper();
    let mut v109_23_cursor = (*s0).read_zipper();
    let v109_23_origin = v109_23_cursor.path().len();
    for v109_23_byte in v109_23_cursor.child_mask().iter() {
      v109_23_cursor.descend_to_existing_byte(v109_23_byte);
      {
      let v110_2: Space = routine_27(c, &v109_23_cursor.path()[v109_23_origin..(v109_23_origin + 1)], &v109_23_cursor.path()[v109_23_origin..(v109_23_origin + 1)], &(*p0), &v109_23_cursor);
      join_wrapped_into(&mut v109_23_write,&((v110_2).read_zipper()),&[]);
      }
      v109_23_cursor.ascend(1);
    }
    drop(v109_23_cursor);
    drop(v109_23_write);
    compose(&(v103_22),&(v109_23))
  };
  drop(v103_22);
  let v103_25: Space = unite(&(v103_19),&(v103_24));
  (v103_25).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v111_7 = Space::new();
  let mut v111_7_write = v111_7.write_zipper();
  let mut v111_7_cursor = (*s0).read_zipper();
  let v111_7_origin = v111_7_cursor.path().len();
  for v111_7_byte in v111_7_cursor.child_mask().iter() {
    v111_7_cursor.descend_to_existing_byte(v111_7_byte);
    {
    let v112_2: Space = singleton(&v111_7_cursor.path()[v111_7_origin..(v111_7_origin + 1)]);
    let v112_3: Space = intersect(&(*CONSTANT_5),&(v112_2));
    let v112_4: Space = if has_head(&(v112_3)) { singleton(&[]) } else { Space::new() };
    drop(v112_3);
    let v112_5: Space = subtract(&(*CONSTANT_0),&(v112_4));
    drop(v112_4);
    let v112_8: Space = if (&(v112_5)).is_empty() { Space::new() } else {
      let mut v113_7 = Space::new();
      let mut v113_7_write = v113_7.write_zipper();
      let v113_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v113_7_arg_1: &[u8] = &v111_7_cursor.path()[v111_7_origin..(v111_7_origin + 1)];
      let v113_7_arg_2: &[u8] = &(*p0);
      let v113_7_arg_4: &Space = &(&v111_7_cursor).make_map();
      let mut v113_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v111_7_cursor.path()[v111_7_origin..(v111_7_origin + 1)]);
      let v113_7_origin = v113_7_cursor.path().len();
      let mut v113_7_more = v113_7_cursor.is_val() || next_value_within(&mut v113_7_cursor,v113_7_origin);
      while v113_7_more {
        {
        let v113_7_depth = v113_7_cursor.path().len();
        let mut v114_5_cursor = (*v113_7_arg_4).read_zipper();
        let v114_5_origin = v114_5_cursor.path().len();
        for v114_5_byte in v114_5_cursor.child_mask().iter() {
          v114_5_cursor.descend_to_existing_byte(v114_5_byte);
          {
          let v115_2: Path = concat_path(&(*v113_7_arg_1),&v114_5_cursor.path()[v114_5_origin..(v114_5_origin + 1)]);
          let v115_3: Space = routine_27(c, &(v115_2), &v113_7_cursor.path()[v113_7_origin..v113_7_depth], &(*v113_7_arg_2), &v114_5_cursor);
          drop(v115_2);
          join_wrapped_into(&mut v113_7_write,&((v115_3).read_zipper()),&[]);
          }
          v114_5_cursor.ascend(1);
        }
        drop(v114_5_cursor);
        }
        v113_7_more = next_value_within(&mut v113_7_cursor,v113_7_origin);
      }
      drop(v113_7_cursor);
      drop(v113_7_write);
      compose(&(v112_5),&(v113_7))
    };
    drop(v112_5);
    let v112_9: Space = intersect(&(*CONSTANT_5),&(v112_2));
    drop(v112_2);
    let v112_10: Space = if has_head(&(v112_9)) { singleton(&[]) } else { Space::new() };
    drop(v112_9);
    let v112_12: Space = if (&(v112_10)).is_empty() { Space::new() } else {
      let mut v116_11 = Space::new();
      let mut v116_11_write = v116_11.write_zipper();
      for v116_11_byte in v111_7_cursor.child_mask().iter() {
        v111_7_cursor.descend_to_existing_byte(v116_11_byte);
        {
        let v117_2: Space = routine_28(c, &v111_7_cursor.path()[(v111_7_origin + 1)..(v111_7_origin + 2)], &v111_7_cursor.path()[(v111_7_origin + 1)..(v111_7_origin + 2)], &(*p0), &v111_7_cursor.path()[v111_7_origin..(v111_7_origin + 1)], &v111_7_cursor);
        join_wrapped_into(&mut v116_11_write,&((v117_2).read_zipper()),&[]);
        }
        v111_7_cursor.ascend(1);
      }
      drop(v116_11_write);
      compose(&(v112_10),&(v116_11))
    };
    drop(v112_10);
    let v112_13: Space = unite(&(v112_8),&(v112_12));
    join_wrapped_into(&mut v111_7_write,&((v112_13).read_zipper()),&[]);
    }
    v111_7_cursor.ascend(1);
  }
  drop(v111_7_cursor);
  drop(v111_7_write);
  (v111_7).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v118_5: Space = singleton(&(*p1));
  let v118_6: Space = intersect(&(*CONSTANT_5),&(v118_5));
  let v118_7: Space = if has_head(&(v118_6)) { singleton(&[]) } else { Space::new() };
  drop(v118_6);
  let v118_8: Space = subtract(&(*CONSTANT_0),&(v118_7));
  drop(v118_7);
  let v118_19: Space = if (&(v118_8)).is_empty() { Space::new() } else {
    let v119_11: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v119_14: Space = if (&(v119_11)).is_empty() { Space::new() } else {
      let v120_13: Space = routine_29(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v119_11),&(v120_13))
    };
    drop(v119_11);
    let mut v119_17 = Space::new();
    let mut v119_17_write = v119_17.write_zipper();
    let mut v119_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v119_17_origin = v119_17_cursor.path().len();
    for v119_17_byte in v119_17_cursor.child_mask().iter() {
      v119_17_cursor.descend_to_existing_byte(v119_17_byte);
      {
      let v121_2_arg_0: &[u8] = &v119_17_cursor.path()[v119_17_origin..(v119_17_origin + 1)];
      let v121_2_arg_1: &[u8] = &(*p0);
      let v121_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v121_2_more = v119_17_cursor.is_val() || next_value_within(&mut v119_17_cursor,(v119_17_origin + 1));
      while v121_2_more {
        {
        let v121_2_depth = v119_17_cursor.path().len();
        let mut v122_4_cursor = (*v121_2_arg_3).read_zipper();
        let v122_4_origin = v122_4_cursor.path().len();
        for v122_4_byte in v122_4_cursor.child_mask().iter() {
          v122_4_cursor.descend_to_existing_byte(v122_4_byte);
          {
          let v123_2: Path = concat_path(&(*v121_2_arg_1),&v122_4_cursor.path()[v122_4_origin..(v122_4_origin + 1)]);
          let v123_3: Space = routine_14(c, &(v123_2), &v119_17_cursor.path()[v119_17_origin..v121_2_depth], &v122_4_cursor);
          drop(v123_2);
          join_wrapped_into(&mut v119_17_write,&((v123_3).read_zipper()),&[]);
          }
          v122_4_cursor.ascend(1);
        }
        drop(v122_4_cursor);
        }
        v121_2_more = next_value_within(&mut v119_17_cursor,(v119_17_origin + 1));
      }
      }
      v119_17_cursor.ascend(1);
    }
    drop(v119_17_cursor);
    drop(v119_17_write);
    let v119_18: Space = unite(&(v119_14),&(v119_17));
    compose(&(v118_8),&(v119_18))
  };
  drop(v118_8);
  let v118_21: Space = intersect(&(*CONSTANT_5),&(v118_5));
  drop(v118_5);
  let v118_22: Space = if has_head(&(v118_21)) { singleton(&[]) } else { Space::new() };
  drop(v118_21);
  let v118_24: Space = if (&(v118_22)).is_empty() { Space::new() } else {
    let mut v124_23 = Space::new();
    let mut v124_23_write = v124_23.write_zipper();
    let mut v124_23_cursor = (*s0).read_zipper();
    let v124_23_origin = v124_23_cursor.path().len();
    for v124_23_byte in v124_23_cursor.child_mask().iter() {
      v124_23_cursor.descend_to_existing_byte(v124_23_byte);
      {
      let v125_2: Space = routine_30(c, &v124_23_cursor.path()[v124_23_origin..(v124_23_origin + 1)], &v124_23_cursor.path()[v124_23_origin..(v124_23_origin + 1)], &(*p0), &v124_23_cursor);
      join_wrapped_into(&mut v124_23_write,&((v125_2).read_zipper()),&[]);
      }
      v124_23_cursor.ascend(1);
    }
    drop(v124_23_cursor);
    drop(v124_23_write);
    compose(&(v118_22),&(v124_23))
  };
  drop(v118_22);
  let v118_25: Space = unite(&(v118_19),&(v118_24));
  (v118_25).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v126_7 = Space::new();
  let mut v126_7_write = v126_7.write_zipper();
  let mut v126_7_cursor = (*s0).read_zipper();
  let v126_7_origin = v126_7_cursor.path().len();
  for v126_7_byte in v126_7_cursor.child_mask().iter() {
    v126_7_cursor.descend_to_existing_byte(v126_7_byte);
    {
    let v127_2: Space = singleton(&v126_7_cursor.path()[v126_7_origin..(v126_7_origin + 1)]);
    let v127_3: Space = intersect(&(*CONSTANT_5),&(v127_2));
    let v127_4: Space = if has_head(&(v127_3)) { singleton(&[]) } else { Space::new() };
    drop(v127_3);
    let v127_5: Space = subtract(&(*CONSTANT_0),&(v127_4));
    drop(v127_4);
    let v127_8: Space = if (&(v127_5)).is_empty() { Space::new() } else {
      let mut v128_7 = Space::new();
      let mut v128_7_write = v128_7.write_zipper();
      let v128_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v128_7_arg_1: &[u8] = &v126_7_cursor.path()[v126_7_origin..(v126_7_origin + 1)];
      let v128_7_arg_2: &[u8] = &(*p0);
      let v128_7_arg_4: &Space = &(&v126_7_cursor).make_map();
      let mut v128_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v126_7_cursor.path()[v126_7_origin..(v126_7_origin + 1)]);
      let v128_7_origin = v128_7_cursor.path().len();
      let mut v128_7_more = v128_7_cursor.is_val() || next_value_within(&mut v128_7_cursor,v128_7_origin);
      while v128_7_more {
        {
        let v128_7_depth = v128_7_cursor.path().len();
        let mut v129_5_cursor = (*v128_7_arg_4).read_zipper();
        let v129_5_origin = v129_5_cursor.path().len();
        for v129_5_byte in v129_5_cursor.child_mask().iter() {
          v129_5_cursor.descend_to_existing_byte(v129_5_byte);
          {
          let v130_2: Path = concat_path(&(*v128_7_arg_1),&v129_5_cursor.path()[v129_5_origin..(v129_5_origin + 1)]);
          let v130_3: Space = routine_30(c, &(v130_2), &v128_7_cursor.path()[v128_7_origin..v128_7_depth], &(*v128_7_arg_2), &v129_5_cursor);
          drop(v130_2);
          join_wrapped_into(&mut v128_7_write,&((v130_3).read_zipper()),&[]);
          }
          v129_5_cursor.ascend(1);
        }
        drop(v129_5_cursor);
        }
        v128_7_more = next_value_within(&mut v128_7_cursor,v128_7_origin);
      }
      drop(v128_7_cursor);
      drop(v128_7_write);
      compose(&(v127_5),&(v128_7))
    };
    drop(v127_5);
    let v127_9: Space = intersect(&(*CONSTANT_5),&(v127_2));
    drop(v127_2);
    let v127_10: Space = if has_head(&(v127_9)) { singleton(&[]) } else { Space::new() };
    drop(v127_9);
    let v127_12: Space = if (&(v127_10)).is_empty() { Space::new() } else {
      let mut v131_11 = Space::new();
      let mut v131_11_write = v131_11.write_zipper();
      for v131_11_byte in v126_7_cursor.child_mask().iter() {
        v126_7_cursor.descend_to_existing_byte(v131_11_byte);
        {
        let v132_2: Space = routine_31(c, &v126_7_cursor.path()[(v126_7_origin + 1)..(v126_7_origin + 2)], &v126_7_cursor.path()[(v126_7_origin + 1)..(v126_7_origin + 2)], &(*p0), &v126_7_cursor.path()[v126_7_origin..(v126_7_origin + 1)], &v126_7_cursor);
        join_wrapped_into(&mut v131_11_write,&((v132_2).read_zipper()),&[]);
        }
        v126_7_cursor.ascend(1);
      }
      drop(v131_11_write);
      compose(&(v127_10),&(v131_11))
    };
    drop(v127_10);
    let v127_13: Space = unite(&(v127_8),&(v127_12));
    join_wrapped_into(&mut v126_7_write,&((v127_13).read_zipper()),&[]);
    }
    v126_7_cursor.ascend(1);
  }
  drop(v126_7_cursor);
  drop(v126_7_write);
  (v126_7).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v133_5: Space = singleton(&(*p1));
  let v133_6: Space = intersect(&(*CONSTANT_5),&(v133_5));
  let v133_7: Space = if has_head(&(v133_6)) { singleton(&[]) } else { Space::new() };
  drop(v133_6);
  let v133_8: Space = subtract(&(*CONSTANT_0),&(v133_7));
  drop(v133_7);
  let v133_19: Space = if (&(v133_8)).is_empty() { Space::new() } else {
    let v134_11: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v134_14: Space = if (&(v134_11)).is_empty() { Space::new() } else {
      let v135_13: Space = routine_32(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v134_11),&(v135_13))
    };
    drop(v134_11);
    let mut v134_17 = Space::new();
    let mut v134_17_write = v134_17.write_zipper();
    let mut v134_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v134_17_origin = v134_17_cursor.path().len();
    for v134_17_byte in v134_17_cursor.child_mask().iter() {
      v134_17_cursor.descend_to_existing_byte(v134_17_byte);
      {
      let v136_2_arg_0: &[u8] = &v134_17_cursor.path()[v134_17_origin..(v134_17_origin + 1)];
      let v136_2_arg_1: &[u8] = &(*p0);
      let v136_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v136_2_more = v134_17_cursor.is_val() || next_value_within(&mut v134_17_cursor,(v134_17_origin + 1));
      while v136_2_more {
        {
        let v136_2_depth = v134_17_cursor.path().len();
        let mut v137_4_cursor = (*v136_2_arg_3).read_zipper();
        let v137_4_origin = v137_4_cursor.path().len();
        for v137_4_byte in v137_4_cursor.child_mask().iter() {
          v137_4_cursor.descend_to_existing_byte(v137_4_byte);
          {
          let v138_2: Path = concat_path(&(*v136_2_arg_1),&v137_4_cursor.path()[v137_4_origin..(v137_4_origin + 1)]);
          let v138_3: Space = routine_16(c, &(v138_2), &v134_17_cursor.path()[v134_17_origin..v136_2_depth], &v137_4_cursor);
          drop(v138_2);
          join_wrapped_into(&mut v134_17_write,&((v138_3).read_zipper()),&[]);
          }
          v137_4_cursor.ascend(1);
        }
        drop(v137_4_cursor);
        }
        v136_2_more = next_value_within(&mut v134_17_cursor,(v134_17_origin + 1));
      }
      }
      v134_17_cursor.ascend(1);
    }
    drop(v134_17_cursor);
    drop(v134_17_write);
    let v134_18: Space = unite(&(v134_14),&(v134_17));
    compose(&(v133_8),&(v134_18))
  };
  drop(v133_8);
  let v133_21: Space = intersect(&(*CONSTANT_5),&(v133_5));
  drop(v133_5);
  let v133_22: Space = if has_head(&(v133_21)) { singleton(&[]) } else { Space::new() };
  drop(v133_21);
  let v133_24: Space = if (&(v133_22)).is_empty() { Space::new() } else {
    let mut v139_23 = Space::new();
    let mut v139_23_write = v139_23.write_zipper();
    let mut v139_23_cursor = (*s0).read_zipper();
    let v139_23_origin = v139_23_cursor.path().len();
    for v139_23_byte in v139_23_cursor.child_mask().iter() {
      v139_23_cursor.descend_to_existing_byte(v139_23_byte);
      {
      let v140_2: Space = routine_33(c, &v139_23_cursor.path()[v139_23_origin..(v139_23_origin + 1)], &v139_23_cursor.path()[v139_23_origin..(v139_23_origin + 1)], &(*p0), &v139_23_cursor);
      join_wrapped_into(&mut v139_23_write,&((v140_2).read_zipper()),&[]);
      }
      v139_23_cursor.ascend(1);
    }
    drop(v139_23_cursor);
    drop(v139_23_write);
    compose(&(v133_22),&(v139_23))
  };
  drop(v133_22);
  let v133_25: Space = unite(&(v133_19),&(v133_24));
  (v133_25).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v141_7 = Space::new();
  let mut v141_7_write = v141_7.write_zipper();
  let mut v141_7_cursor = (*s0).read_zipper();
  let v141_7_origin = v141_7_cursor.path().len();
  for v141_7_byte in v141_7_cursor.child_mask().iter() {
    v141_7_cursor.descend_to_existing_byte(v141_7_byte);
    {
    let v142_2: Space = singleton(&v141_7_cursor.path()[v141_7_origin..(v141_7_origin + 1)]);
    let v142_3: Space = intersect(&(*CONSTANT_5),&(v142_2));
    let v142_4: Space = if has_head(&(v142_3)) { singleton(&[]) } else { Space::new() };
    drop(v142_3);
    let v142_5: Space = subtract(&(*CONSTANT_0),&(v142_4));
    drop(v142_4);
    let v142_8: Space = if (&(v142_5)).is_empty() { Space::new() } else {
      let mut v143_7 = Space::new();
      let mut v143_7_write = v143_7.write_zipper();
      let v143_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v143_7_arg_1: &[u8] = &v141_7_cursor.path()[v141_7_origin..(v141_7_origin + 1)];
      let v143_7_arg_2: &[u8] = &(*p0);
      let v143_7_arg_4: &Space = &(&v141_7_cursor).make_map();
      let mut v143_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v141_7_cursor.path()[v141_7_origin..(v141_7_origin + 1)]);
      let v143_7_origin = v143_7_cursor.path().len();
      let mut v143_7_more = v143_7_cursor.is_val() || next_value_within(&mut v143_7_cursor,v143_7_origin);
      while v143_7_more {
        {
        let v143_7_depth = v143_7_cursor.path().len();
        let mut v144_5_cursor = (*v143_7_arg_4).read_zipper();
        let v144_5_origin = v144_5_cursor.path().len();
        for v144_5_byte in v144_5_cursor.child_mask().iter() {
          v144_5_cursor.descend_to_existing_byte(v144_5_byte);
          {
          let v145_2: Path = concat_path(&(*v143_7_arg_1),&v144_5_cursor.path()[v144_5_origin..(v144_5_origin + 1)]);
          let v145_3: Space = routine_33(c, &(v145_2), &v143_7_cursor.path()[v143_7_origin..v143_7_depth], &(*v143_7_arg_2), &v144_5_cursor);
          drop(v145_2);
          join_wrapped_into(&mut v143_7_write,&((v145_3).read_zipper()),&[]);
          }
          v144_5_cursor.ascend(1);
        }
        drop(v144_5_cursor);
        }
        v143_7_more = next_value_within(&mut v143_7_cursor,v143_7_origin);
      }
      drop(v143_7_cursor);
      drop(v143_7_write);
      compose(&(v142_5),&(v143_7))
    };
    drop(v142_5);
    let v142_9: Space = intersect(&(*CONSTANT_5),&(v142_2));
    drop(v142_2);
    let v142_10: Space = if has_head(&(v142_9)) { singleton(&[]) } else { Space::new() };
    drop(v142_9);
    let v142_12: Space = if (&(v142_10)).is_empty() { Space::new() } else {
      let mut v146_11 = Space::new();
      let mut v146_11_write = v146_11.write_zipper();
      for v146_11_byte in v141_7_cursor.child_mask().iter() {
        v141_7_cursor.descend_to_existing_byte(v146_11_byte);
        {
        let v147_2: Space = routine_34(c, &v141_7_cursor.path()[(v141_7_origin + 1)..(v141_7_origin + 2)], &v141_7_cursor.path()[(v141_7_origin + 1)..(v141_7_origin + 2)], &(*p0), &v141_7_cursor.path()[v141_7_origin..(v141_7_origin + 1)], &v141_7_cursor);
        join_wrapped_into(&mut v146_11_write,&((v147_2).read_zipper()),&[]);
        }
        v141_7_cursor.ascend(1);
      }
      drop(v146_11_write);
      compose(&(v142_10),&(v146_11))
    };
    drop(v142_10);
    let v142_13: Space = unite(&(v142_8),&(v142_12));
    join_wrapped_into(&mut v141_7_write,&((v142_13).read_zipper()),&[]);
    }
    v141_7_cursor.ascend(1);
  }
  drop(v141_7_cursor);
  drop(v141_7_write);
  (v141_7).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v148_5: Space = singleton(&(*p1));
  let v148_6: Space = intersect(&(*CONSTANT_5),&(v148_5));
  let v148_7: Space = if has_head(&(v148_6)) { singleton(&[]) } else { Space::new() };
  drop(v148_6);
  let v148_8: Space = subtract(&(*CONSTANT_0),&(v148_7));
  drop(v148_7);
  let v148_19: Space = if (&(v148_8)).is_empty() { Space::new() } else {
    let v149_11: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v149_14: Space = if (&(v149_11)).is_empty() { Space::new() } else {
      let v150_13: Space = routine_35(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v149_11),&(v150_13))
    };
    drop(v149_11);
    let mut v149_17 = Space::new();
    let mut v149_17_write = v149_17.write_zipper();
    let mut v149_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v149_17_origin = v149_17_cursor.path().len();
    for v149_17_byte in v149_17_cursor.child_mask().iter() {
      v149_17_cursor.descend_to_existing_byte(v149_17_byte);
      {
      let v151_2_arg_0: &[u8] = &v149_17_cursor.path()[v149_17_origin..(v149_17_origin + 1)];
      let v151_2_arg_1: &[u8] = &(*p0);
      let v151_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v151_2_more = v149_17_cursor.is_val() || next_value_within(&mut v149_17_cursor,(v149_17_origin + 1));
      while v151_2_more {
        {
        let v151_2_depth = v149_17_cursor.path().len();
        let mut v152_4_cursor = (*v151_2_arg_3).read_zipper();
        let v152_4_origin = v152_4_cursor.path().len();
        for v152_4_byte in v152_4_cursor.child_mask().iter() {
          v152_4_cursor.descend_to_existing_byte(v152_4_byte);
          {
          let v153_2: Path = concat_path(&(*v151_2_arg_1),&v152_4_cursor.path()[v152_4_origin..(v152_4_origin + 1)]);
          let v153_3: Space = routine_18(c, &(v153_2), &v149_17_cursor.path()[v149_17_origin..v151_2_depth], &v152_4_cursor);
          drop(v153_2);
          join_wrapped_into(&mut v149_17_write,&((v153_3).read_zipper()),&[]);
          }
          v152_4_cursor.ascend(1);
        }
        drop(v152_4_cursor);
        }
        v151_2_more = next_value_within(&mut v149_17_cursor,(v149_17_origin + 1));
      }
      }
      v149_17_cursor.ascend(1);
    }
    drop(v149_17_cursor);
    drop(v149_17_write);
    let v149_18: Space = unite(&(v149_14),&(v149_17));
    compose(&(v148_8),&(v149_18))
  };
  drop(v148_8);
  let v148_21: Space = intersect(&(*CONSTANT_5),&(v148_5));
  drop(v148_5);
  let v148_22: Space = if has_head(&(v148_21)) { singleton(&[]) } else { Space::new() };
  drop(v148_21);
  let v148_24: Space = if (&(v148_22)).is_empty() { Space::new() } else {
    let mut v154_23 = Space::new();
    let mut v154_23_write = v154_23.write_zipper();
    let mut v154_23_cursor = (*s0).read_zipper();
    let v154_23_origin = v154_23_cursor.path().len();
    for v154_23_byte in v154_23_cursor.child_mask().iter() {
      v154_23_cursor.descend_to_existing_byte(v154_23_byte);
      {
      let v155_2: Space = routine_36(c, &v154_23_cursor.path()[v154_23_origin..(v154_23_origin + 1)], &v154_23_cursor.path()[v154_23_origin..(v154_23_origin + 1)], &(*p0), &v154_23_cursor);
      join_wrapped_into(&mut v154_23_write,&((v155_2).read_zipper()),&[]);
      }
      v154_23_cursor.ascend(1);
    }
    drop(v154_23_cursor);
    drop(v154_23_write);
    compose(&(v148_22),&(v154_23))
  };
  drop(v148_22);
  let v148_25: Space = unite(&(v148_19),&(v148_24));
  (v148_25).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v156_7 = Space::new();
  let mut v156_7_write = v156_7.write_zipper();
  let mut v156_7_cursor = (*s0).read_zipper();
  let v156_7_origin = v156_7_cursor.path().len();
  for v156_7_byte in v156_7_cursor.child_mask().iter() {
    v156_7_cursor.descend_to_existing_byte(v156_7_byte);
    {
    let v157_2: Space = singleton(&v156_7_cursor.path()[v156_7_origin..(v156_7_origin + 1)]);
    let v157_3: Space = intersect(&(*CONSTANT_5),&(v157_2));
    let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
    drop(v157_3);
    let v157_5: Space = subtract(&(*CONSTANT_0),&(v157_4));
    drop(v157_4);
    let v157_8: Space = if (&(v157_5)).is_empty() { Space::new() } else {
      let mut v158_7 = Space::new();
      let mut v158_7_write = v158_7.write_zipper();
      let v158_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v158_7_arg_1: &[u8] = &v156_7_cursor.path()[v156_7_origin..(v156_7_origin + 1)];
      let v158_7_arg_2: &[u8] = &(*p0);
      let v158_7_arg_4: &Space = &(&v156_7_cursor).make_map();
      let mut v158_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v156_7_cursor.path()[v156_7_origin..(v156_7_origin + 1)]);
      let v158_7_origin = v158_7_cursor.path().len();
      let mut v158_7_more = v158_7_cursor.is_val() || next_value_within(&mut v158_7_cursor,v158_7_origin);
      while v158_7_more {
        {
        let v158_7_depth = v158_7_cursor.path().len();
        let mut v159_5_cursor = (*v158_7_arg_4).read_zipper();
        let v159_5_origin = v159_5_cursor.path().len();
        for v159_5_byte in v159_5_cursor.child_mask().iter() {
          v159_5_cursor.descend_to_existing_byte(v159_5_byte);
          {
          let v160_2: Path = concat_path(&(*v158_7_arg_1),&v159_5_cursor.path()[v159_5_origin..(v159_5_origin + 1)]);
          let v160_3: Space = routine_36(c, &(v160_2), &v158_7_cursor.path()[v158_7_origin..v158_7_depth], &(*v158_7_arg_2), &v159_5_cursor);
          drop(v160_2);
          join_wrapped_into(&mut v158_7_write,&((v160_3).read_zipper()),&[]);
          }
          v159_5_cursor.ascend(1);
        }
        drop(v159_5_cursor);
        }
        v158_7_more = next_value_within(&mut v158_7_cursor,v158_7_origin);
      }
      drop(v158_7_cursor);
      drop(v158_7_write);
      compose(&(v157_5),&(v158_7))
    };
    drop(v157_5);
    let v157_9: Space = intersect(&(*CONSTANT_5),&(v157_2));
    drop(v157_2);
    let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
    drop(v157_9);
    let v157_12: Space = if (&(v157_10)).is_empty() { Space::new() } else {
      let mut v161_11 = Space::new();
      let mut v161_11_write = v161_11.write_zipper();
      for v161_11_byte in v156_7_cursor.child_mask().iter() {
        v156_7_cursor.descend_to_existing_byte(v161_11_byte);
        {
        let v162_2: Space = routine_37(c, &v156_7_cursor.path()[(v156_7_origin + 1)..(v156_7_origin + 2)], &v156_7_cursor.path()[(v156_7_origin + 1)..(v156_7_origin + 2)], &(*p0), &v156_7_cursor.path()[v156_7_origin..(v156_7_origin + 1)], &v156_7_cursor);
        join_wrapped_into(&mut v161_11_write,&((v162_2).read_zipper()),&[]);
        }
        v156_7_cursor.ascend(1);
      }
      drop(v161_11_write);
      compose(&(v157_10),&(v161_11))
    };
    drop(v157_10);
    let v157_13: Space = unite(&(v157_8),&(v157_12));
    join_wrapped_into(&mut v156_7_write,&((v157_13).read_zipper()),&[]);
    }
    v156_7_cursor.ascend(1);
  }
  drop(v156_7_cursor);
  drop(v156_7_write);
  (v156_7).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v163_6: Space = singleton(&(*p0));
  let v163_7: Space = intersect(&(*CONSTANT_5),&(v163_6));
  let v163_8: Space = if has_head(&(v163_7)) { singleton(&[]) } else { Space::new() };
  drop(v163_7);
  let v163_9: Space = subtract(&(*CONSTANT_0),&(v163_8));
  drop(v163_8);
  let v163_14: Space = intersect(&(*CONSTANT_5),&(v163_6));
  drop(v163_6);
  let v163_15: Space = if has_head(&(v163_14)) { singleton(&[]) } else { Space::new() };
  drop(v163_14);
  let mut v163_18 = Space::new();
  let mut v163_18_write = v163_18.write_zipper();
  let mut v163_18_cursor = (*s0).read_zipper();
  let v163_18_origin = v163_18_cursor.path().len();
  for v163_18_byte in v163_18_cursor.child_mask().iter() {
    v163_18_cursor.descend_to_existing_byte(v163_18_byte);
    {
    let v164_4: Space = if (&(v163_9)).is_empty() { Space::new() } else {
      let v165_2: Path = concat_path(&(*p1),&v163_18_cursor.path()[v163_18_origin..(v163_18_origin + 1)]);
      let mut v165_3 = Space::new();
      let mut v165_3_write = v165_3.write_zipper();
      let v165_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v165_3_arg_1: &[u8] = &(v165_2);
      let v165_3_arg_2: &[u8] = &(*p2);
      let v165_3_arg_4: &Space = &(&v163_18_cursor).make_map();
      let mut v165_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v165_3_origin = v165_3_cursor.path().len();
      let mut v165_3_more = v165_3_cursor.is_val() || next_value_within(&mut v165_3_cursor,v165_3_origin);
      while v165_3_more {
        {
        let v165_3_depth = v165_3_cursor.path().len();
        let v166_5: Space = routine_20(c, &v165_3_cursor.path()[v165_3_origin..v165_3_depth], &(*v165_3_arg_1), &(*v165_3_arg_2), &((*v165_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v165_3_write,&((v166_5).read_zipper()),&[]);
        }
        v165_3_more = next_value_within(&mut v165_3_cursor,v165_3_origin);
      }
      drop(v165_3_cursor);
      drop(v165_3_write);
      compose(&(v163_9),&(v165_3))
    };
    let v164_8: Space = if (&(v163_15)).is_empty() { Space::new() } else {
      let v167_2: Path = concat_path(&(*p1),&v163_18_cursor.path()[v163_18_origin..(v163_18_origin + 1)]);
      let v167_5: Space = routine_21(c, &(*CONSTANT_2), &(*CONSTANT_2), &((*CONSTANT_11).read_zipper()));
      let mut v167_7 = Space::new();
      let mut v167_7_write = v167_7.write_zipper();
      let mut v167_7_cursor = descend_cursor((v167_5).read_zipper(),&(*p2));
      let v167_7_origin = v167_7_cursor.path().len();
      for v167_7_byte in v167_7_cursor.child_mask().iter() {
        v167_7_cursor.descend_to_existing_byte(v167_7_byte);
        {
        let v168_2: Space = routine_22(c, &v167_7_cursor.path()[v167_7_origin..(v167_7_origin + 1)], &v167_7_cursor.path()[v167_7_origin..(v167_7_origin + 1)], &(v167_2), &v167_7_cursor, &v163_18_cursor);
        join_wrapped_into(&mut v167_7_write,&((v168_2).read_zipper()),&[]);
        }
        v167_7_cursor.ascend(1);
      }
      drop(v167_7_cursor);
      drop(v167_7_write);
      drop(v167_2);
      compose(&(v163_15),&(v167_7))
    };
    let v164_9: Space = unite(&(v164_4),&(v164_8));
    join_wrapped_into(&mut v163_18_write,&((v164_9).read_zipper()),&[]);
    }
    v163_18_cursor.ascend(1);
  }
  drop(v163_18_cursor);
  drop(v163_18_write);
  drop(v163_9);
  drop(v163_15);
  (v163_18).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v169_5: Space = singleton(&(*p1));
  let v169_6: Space = intersect(&(*CONSTANT_5),&(v169_5));
  let v169_7: Space = if has_head(&(v169_6)) { singleton(&[]) } else { Space::new() };
  drop(v169_6);
  let v169_8: Space = subtract(&(*CONSTANT_0),&(v169_7));
  drop(v169_7);
  let v169_19: Space = if (&(v169_8)).is_empty() { Space::new() } else {
    let v170_11: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v170_14: Space = if (&(v170_11)).is_empty() { Space::new() } else {
      let v171_13: Space = routine_38(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v170_11),&(v171_13))
    };
    drop(v170_11);
    let mut v170_17 = Space::new();
    let mut v170_17_write = v170_17.write_zipper();
    let mut v170_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v170_17_origin = v170_17_cursor.path().len();
    for v170_17_byte in v170_17_cursor.child_mask().iter() {
      v170_17_cursor.descend_to_existing_byte(v170_17_byte);
      {
      let v172_2_arg_0: &[u8] = &v170_17_cursor.path()[v170_17_origin..(v170_17_origin + 1)];
      let v172_2_arg_1: &[u8] = &(*p0);
      let v172_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v172_2_more = v170_17_cursor.is_val() || next_value_within(&mut v170_17_cursor,(v170_17_origin + 1));
      while v172_2_more {
        {
        let v172_2_depth = v170_17_cursor.path().len();
        let mut v173_4_cursor = (*v172_2_arg_3).read_zipper();
        let v173_4_origin = v173_4_cursor.path().len();
        for v173_4_byte in v173_4_cursor.child_mask().iter() {
          v173_4_cursor.descend_to_existing_byte(v173_4_byte);
          {
          let v174_2: Path = concat_path(&(*v172_2_arg_1),&v173_4_cursor.path()[v173_4_origin..(v173_4_origin + 1)]);
          let v174_3: Space = routine_21(c, &(v174_2), &v170_17_cursor.path()[v170_17_origin..v172_2_depth], &v173_4_cursor);
          drop(v174_2);
          join_wrapped_into(&mut v170_17_write,&((v174_3).read_zipper()),&[]);
          }
          v173_4_cursor.ascend(1);
        }
        drop(v173_4_cursor);
        }
        v172_2_more = next_value_within(&mut v170_17_cursor,(v170_17_origin + 1));
      }
      }
      v170_17_cursor.ascend(1);
    }
    drop(v170_17_cursor);
    drop(v170_17_write);
    let v170_18: Space = unite(&(v170_14),&(v170_17));
    compose(&(v169_8),&(v170_18))
  };
  drop(v169_8);
  let v169_21: Space = intersect(&(*CONSTANT_5),&(v169_5));
  drop(v169_5);
  let v169_22: Space = if has_head(&(v169_21)) { singleton(&[]) } else { Space::new() };
  drop(v169_21);
  let v169_24: Space = if (&(v169_22)).is_empty() { Space::new() } else {
    let mut v175_23 = Space::new();
    let mut v175_23_write = v175_23.write_zipper();
    let mut v175_23_cursor = (*s0).read_zipper();
    let v175_23_origin = v175_23_cursor.path().len();
    for v175_23_byte in v175_23_cursor.child_mask().iter() {
      v175_23_cursor.descend_to_existing_byte(v175_23_byte);
      {
      let v176_2: Space = routine_39(c, &v175_23_cursor.path()[v175_23_origin..(v175_23_origin + 1)], &v175_23_cursor.path()[v175_23_origin..(v175_23_origin + 1)], &(*p0), &v175_23_cursor);
      join_wrapped_into(&mut v175_23_write,&((v176_2).read_zipper()),&[]);
      }
      v175_23_cursor.ascend(1);
    }
    drop(v175_23_cursor);
    drop(v175_23_write);
    compose(&(v169_22),&(v175_23))
  };
  drop(v169_22);
  let v169_25: Space = unite(&(v169_19),&(v169_24));
  (v169_25).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v177_7: Space = singleton(&(*p1));
  let v177_8: Space = intersect(&(*CONSTANT_5),&(v177_7));
  let v177_9: Space = if has_head(&(v177_8)) { singleton(&[]) } else { Space::new() };
  drop(v177_8);
  let v177_10: Space = subtract(&(*CONSTANT_0),&(v177_9));
  drop(v177_9);
  let v177_21: Space = if (&(v177_10)).is_empty() { Space::new() } else {
    let v178_13: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v178_16: Space = if (&(v178_13)).is_empty() { Space::new() } else {
      let v179_15: Space = routine_40(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0), &(*s1));
      compose(&(v178_13),&(v179_15))
    };
    drop(v178_13);
    let mut v178_19 = Space::new();
    let mut v178_19_write = v178_19.write_zipper();
    let mut v178_19_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v178_19_origin = v178_19_cursor.path().len();
    for v178_19_byte in v178_19_cursor.child_mask().iter() {
      v178_19_cursor.descend_to_existing_byte(v178_19_byte);
      {
      let v180_2_arg_0: &[u8] = &v178_19_cursor.path()[v178_19_origin..(v178_19_origin + 1)];
      let v180_2_arg_1: &[u8] = &(*p0);
      let v180_2_arg_2: &[u8] = &(*p2);
      let v180_2_arg_4: &Space = &(&(*s0)).make_map();
      let v180_2_arg_5: &Space = &(&(*s1)).make_map();
      let mut v180_2_more = v178_19_cursor.is_val() || next_value_within(&mut v178_19_cursor,(v178_19_origin + 1));
      while v180_2_more {
        {
        let v180_2_depth = v178_19_cursor.path().len();
        let mut v181_6_cursor = (*v180_2_arg_4).read_zipper();
        let v181_6_origin = v181_6_cursor.path().len();
        for v181_6_byte in v181_6_cursor.child_mask().iter() {
          v181_6_cursor.descend_to_existing_byte(v181_6_byte);
          {
          let v182_2: Path = concat_path(&(*v180_2_arg_1),&v181_6_cursor.path()[v181_6_origin..(v181_6_origin + 1)]);
          let v182_3: Space = routine_22(c, &(v182_2), &v178_19_cursor.path()[v178_19_origin..v180_2_depth], &(*v180_2_arg_2), &v181_6_cursor, &((*v180_2_arg_5).read_zipper()));
          drop(v182_2);
          join_wrapped_into(&mut v178_19_write,&((v182_3).read_zipper()),&[]);
          }
          v181_6_cursor.ascend(1);
        }
        drop(v181_6_cursor);
        }
        v180_2_more = next_value_within(&mut v178_19_cursor,(v178_19_origin + 1));
      }
      }
      v178_19_cursor.ascend(1);
    }
    drop(v178_19_cursor);
    drop(v178_19_write);
    let v178_20: Space = unite(&(v178_16),&(v178_19));
    compose(&(v177_10),&(v178_20))
  };
  drop(v177_10);
  let v177_23: Space = intersect(&(*CONSTANT_5),&(v177_7));
  drop(v177_7);
  let v177_24: Space = if has_head(&(v177_23)) { singleton(&[]) } else { Space::new() };
  drop(v177_23);
  let v177_28: Space = if (&(v177_24)).is_empty() { Space::new() } else {
    let v183_26: Space = wrap(&(descend_cursor((*s0).read_zipper(),&(*p2))),&(*p0));
    let v183_27: Space = if (&(v183_26)).is_empty() { Space::new() } else {
      compose(&(v183_26),&(*s1))
    };
    drop(v183_26);
    compose(&(v177_24),&(v183_27))
  };
  drop(v177_24);
  let v177_29: Space = unite(&(v177_21),&(v177_28));
  drop(v177_28);
  (v177_29).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v185_6: Space = singleton(&(*p0));
  let v185_7: Space = intersect(&(*CONSTANT_5),&(v185_6));
  let v185_8: Space = if has_head(&(v185_7)) { singleton(&[]) } else { Space::new() };
  drop(v185_7);
  let v185_9: Space = subtract(&(*CONSTANT_0),&(v185_8));
  drop(v185_8);
  let v185_14: Space = intersect(&(*CONSTANT_5),&(v185_6));
  drop(v185_6);
  let v185_15: Space = if has_head(&(v185_14)) { singleton(&[]) } else { Space::new() };
  drop(v185_14);
  let mut v185_18 = Space::new();
  let mut v185_18_write = v185_18.write_zipper();
  let mut v185_18_cursor = (*s0).read_zipper();
  let v185_18_origin = v185_18_cursor.path().len();
  for v185_18_byte in v185_18_cursor.child_mask().iter() {
    v185_18_cursor.descend_to_existing_byte(v185_18_byte);
    {
    let v186_4: Space = if (&(v185_9)).is_empty() { Space::new() } else {
      let v187_2: Path = concat_path(&(*p1),&v185_18_cursor.path()[v185_18_origin..(v185_18_origin + 1)]);
      let mut v187_3 = Space::new();
      let mut v187_3_write = v187_3.write_zipper();
      let v187_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v187_3_arg_1: &[u8] = &(v187_2);
      let v187_3_arg_2: &[u8] = &(*p2);
      let v187_3_arg_4: &Space = &(&v185_18_cursor).make_map();
      let mut v187_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v187_3_origin = v187_3_cursor.path().len();
      let mut v187_3_more = v187_3_cursor.is_val() || next_value_within(&mut v187_3_cursor,v187_3_origin);
      while v187_3_more {
        {
        let v187_3_depth = v187_3_cursor.path().len();
        let v188_5: Space = routine_23(c, &v187_3_cursor.path()[v187_3_origin..v187_3_depth], &(*v187_3_arg_1), &(*v187_3_arg_2), &((*v187_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v187_3_write,&((v188_5).read_zipper()),&[]);
        }
        v187_3_more = next_value_within(&mut v187_3_cursor,v187_3_origin);
      }
      drop(v187_3_cursor);
      drop(v187_3_write);
      drop(v187_2);
      compose(&(v185_9),&(v187_3))
    };
    let v186_11: Space = if (&(v185_15)).is_empty() { Space::new() } else {
      let v189_5: Space = routine_24(c, &(*CONSTANT_2), &(*CONSTANT_2), &((*CONSTANT_11).read_zipper()));
      let mut v189_10 = Space::new();
      let mut v189_10_write = v189_10.write_zipper();
      let mut v189_10_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((v189_5).read_zipper(),&(*p2)),&(*p1)),&v185_18_cursor.path()[v185_18_origin..(v185_18_origin + 1)]),&(*p2));
      let v189_10_origin = v189_10_cursor.path().len();
      for v189_10_byte in v189_10_cursor.child_mask().iter() {
        v189_10_cursor.descend_to_existing_byte(v189_10_byte);
        {
        let v190_2: Space = routine_25(c, &v189_10_cursor.path()[v189_10_origin..(v189_10_origin + 1)], &v189_10_cursor.path()[v189_10_origin..(v189_10_origin + 1)], &v189_10_cursor, &v185_18_cursor);
        join_wrapped_into(&mut v189_10_write,&((v190_2).read_zipper()),&[]);
        }
        v189_10_cursor.ascend(1);
      }
      drop(v189_10_cursor);
      drop(v189_10_write);
      compose(&(v185_15),&(v189_10))
    };
    let v186_12: Space = unite(&(v186_4),&(v186_11));
    join_wrapped_into(&mut v185_18_write,&((v186_12).read_zipper()),&[]);
    }
    v185_18_cursor.ascend(1);
  }
  drop(v185_18_cursor);
  drop(v185_18_write);
  drop(v185_9);
  drop(v185_15);
  (v185_18).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v191_5: Space = singleton(&(*p1));
  let v191_6: Space = intersect(&(*CONSTANT_5),&(v191_5));
  let v191_7: Space = if has_head(&(v191_6)) { singleton(&[]) } else { Space::new() };
  drop(v191_6);
  let v191_8: Space = subtract(&(*CONSTANT_0),&(v191_7));
  drop(v191_7);
  let v191_19: Space = if (&(v191_8)).is_empty() { Space::new() } else {
    let v192_11: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v192_14: Space = if (&(v192_11)).is_empty() { Space::new() } else {
      let v193_13: Space = routine_41(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v192_11),&(v193_13))
    };
    drop(v192_11);
    let mut v192_17 = Space::new();
    let mut v192_17_write = v192_17.write_zipper();
    let mut v192_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v192_17_origin = v192_17_cursor.path().len();
    for v192_17_byte in v192_17_cursor.child_mask().iter() {
      v192_17_cursor.descend_to_existing_byte(v192_17_byte);
      {
      let v194_2_arg_0: &[u8] = &v192_17_cursor.path()[v192_17_origin..(v192_17_origin + 1)];
      let v194_2_arg_1: &[u8] = &(*p0);
      let v194_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v194_2_more = v192_17_cursor.is_val() || next_value_within(&mut v192_17_cursor,(v192_17_origin + 1));
      while v194_2_more {
        {
        let v194_2_depth = v192_17_cursor.path().len();
        let mut v195_4_cursor = (*v194_2_arg_3).read_zipper();
        let v195_4_origin = v195_4_cursor.path().len();
        for v195_4_byte in v195_4_cursor.child_mask().iter() {
          v195_4_cursor.descend_to_existing_byte(v195_4_byte);
          {
          let v196_2: Path = concat_path(&(*v194_2_arg_1),&v195_4_cursor.path()[v195_4_origin..(v195_4_origin + 1)]);
          let v196_3: Space = routine_24(c, &(v196_2), &v192_17_cursor.path()[v192_17_origin..v194_2_depth], &v195_4_cursor);
          drop(v196_2);
          join_wrapped_into(&mut v192_17_write,&((v196_3).read_zipper()),&[]);
          }
          v195_4_cursor.ascend(1);
        }
        drop(v195_4_cursor);
        }
        v194_2_more = next_value_within(&mut v192_17_cursor,(v192_17_origin + 1));
      }
      }
      v192_17_cursor.ascend(1);
    }
    drop(v192_17_cursor);
    drop(v192_17_write);
    let v192_18: Space = unite(&(v192_14),&(v192_17));
    compose(&(v191_8),&(v192_18))
  };
  drop(v191_8);
  let v191_21: Space = intersect(&(*CONSTANT_5),&(v191_5));
  drop(v191_5);
  let v191_22: Space = if has_head(&(v191_21)) { singleton(&[]) } else { Space::new() };
  drop(v191_21);
  let v191_24: Space = if (&(v191_22)).is_empty() { Space::new() } else {
    let mut v197_23 = Space::new();
    let mut v197_23_write = v197_23.write_zipper();
    let mut v197_23_cursor = (*s0).read_zipper();
    let v197_23_origin = v197_23_cursor.path().len();
    for v197_23_byte in v197_23_cursor.child_mask().iter() {
      v197_23_cursor.descend_to_existing_byte(v197_23_byte);
      {
      let v198_2: Space = routine_42(c, &v197_23_cursor.path()[v197_23_origin..(v197_23_origin + 1)], &v197_23_cursor.path()[v197_23_origin..(v197_23_origin + 1)], &(*p0), &v197_23_cursor);
      join_wrapped_into(&mut v197_23_write,&((v198_2).read_zipper()),&[]);
      }
      v197_23_cursor.ascend(1);
    }
    drop(v197_23_cursor);
    drop(v197_23_write);
    compose(&(v191_22),&(v197_23))
  };
  drop(v191_22);
  let v191_25: Space = unite(&(v191_19),&(v191_24));
  (v191_25).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v199_6: Space = singleton(&(*p1));
  let v199_7: Space = intersect(&(*CONSTANT_5),&(v199_6));
  let v199_8: Space = if has_head(&(v199_7)) { singleton(&[]) } else { Space::new() };
  drop(v199_7);
  let v199_9: Space = subtract(&(*CONSTANT_0),&(v199_8));
  drop(v199_8);
  let v199_20: Space = if (&(v199_9)).is_empty() { Space::new() } else {
    let v200_12: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v200_15: Space = if (&(v200_12)).is_empty() { Space::new() } else {
      let v201_14: Space = routine_43(c, &(*CONSTANT_1), &(*p0), &(*s0), &(*s1));
      compose(&(v200_12),&(v201_14))
    };
    drop(v200_12);
    let mut v200_18 = Space::new();
    let mut v200_18_write = v200_18.write_zipper();
    let mut v200_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v200_18_origin = v200_18_cursor.path().len();
    for v200_18_byte in v200_18_cursor.child_mask().iter() {
      v200_18_cursor.descend_to_existing_byte(v200_18_byte);
      {
      let v202_2_arg_0: &[u8] = &v200_18_cursor.path()[v200_18_origin..(v200_18_origin + 1)];
      let v202_2_arg_1: &[u8] = &(*p0);
      let v202_2_arg_3: &Space = &(&(*s0)).make_map();
      let v202_2_arg_4: &Space = &(&(*s1)).make_map();
      let mut v202_2_more = v200_18_cursor.is_val() || next_value_within(&mut v200_18_cursor,(v200_18_origin + 1));
      while v202_2_more {
        {
        let v202_2_depth = v200_18_cursor.path().len();
        let mut v203_5_cursor = (*v202_2_arg_3).read_zipper();
        let v203_5_origin = v203_5_cursor.path().len();
        for v203_5_byte in v203_5_cursor.child_mask().iter() {
          v203_5_cursor.descend_to_existing_byte(v203_5_byte);
          {
          let v204_2: Path = concat_path(&(*v202_2_arg_1),&v203_5_cursor.path()[v203_5_origin..(v203_5_origin + 1)]);
          let v204_3: Space = routine_25(c, &(v204_2), &v200_18_cursor.path()[v200_18_origin..v202_2_depth], &v203_5_cursor, &((*v202_2_arg_4).read_zipper()));
          drop(v204_2);
          join_wrapped_into(&mut v200_18_write,&((v204_3).read_zipper()),&[]);
          }
          v203_5_cursor.ascend(1);
        }
        drop(v203_5_cursor);
        }
        v202_2_more = next_value_within(&mut v200_18_cursor,(v200_18_origin + 1));
      }
      }
      v200_18_cursor.ascend(1);
    }
    drop(v200_18_cursor);
    drop(v200_18_write);
    let v200_19: Space = unite(&(v200_15),&(v200_18));
    compose(&(v199_9),&(v200_19))
  };
  drop(v199_9);
  let v199_22: Space = intersect(&(*CONSTANT_5),&(v199_6));
  drop(v199_6);
  let v199_23: Space = if has_head(&(v199_22)) { singleton(&[]) } else { Space::new() };
  drop(v199_22);
  let v199_55: Space = if (&(v199_23)).is_empty() { Space::new() } else {
    let v205_25: Space = singleton(&(*p0));
    let v205_26: Space = intersect(&(*CONSTANT_7),&(v205_25));
    let v205_35: Space = if (&(v205_26)).is_empty() { Space::new() } else {
      let v206_31: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_12)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_12))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_13))))
      };
      let v206_34: Space = if (&(v206_31)).is_empty() { Space::new() } else {
        compose(&(v206_31),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_14))))
      };
      compose(&(v205_26),&(v206_34))
    };
    drop(v205_26);
    let v205_37: Space = intersect(&(*CONSTANT_8),&(v205_25));
    let v205_41: Space = if (&(v205_37)).is_empty() { Space::new() } else {
      let v209_31: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_12)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_12))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_13))))
      };
      let v209_40: Space = if (&(v209_31)).is_empty() { Space::new() } else {
        compose(&(v209_31),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_15))))
      };
      drop(v209_31);
      compose(&(v205_37),&(v209_40))
    };
    drop(v205_37);
    let v205_42: Space = unite(&(v205_35),&(v205_41));
    drop(v205_35);
    drop(v205_41);
    let v205_44: Space = intersect(&(*CONSTANT_9),&(v205_25));
    let v205_47: Space = if (&(v205_44)).is_empty() { Space::new() } else {
      let v212_45: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_13)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_13))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_15))))
      };
      let v212_46: Space = if (&(v212_45)).is_empty() { Space::new() } else {
        compose(&(v212_45),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_14))))
      };
      drop(v212_45);
      compose(&(v205_44),&(v212_46))
    };
    drop(v205_44);
    let v205_48: Space = unite(&(v205_42),&(v205_47));
    drop(v205_42);
    drop(v205_47);
    let v205_50: Space = intersect(&(*CONSTANT_10),&(v205_25));
    drop(v205_25);
    let v205_53: Space = if (&(v205_50)).is_empty() { Space::new() } else {
      let v215_51: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_12)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_12))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_15))))
      };
      let v215_52: Space = if (&(v215_51)).is_empty() { Space::new() } else {
        compose(&(v215_51),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_14))))
      };
      drop(v215_51);
      compose(&(v205_50),&(v215_52))
    };
    drop(v205_50);
    let v205_54: Space = unite(&(v205_48),&(v205_53));
    drop(v205_48);
    drop(v205_53);
    compose(&(v199_23),&(v205_54))
  };
  drop(v199_23);
  let v199_56: Space = unite(&(v199_20),&(v199_55));
  drop(v199_55);
  (v199_56).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v218_5: Space = singleton(&(*p0));
  let v218_6: Space = intersect(&(*CONSTANT_5),&(v218_5));
  let v218_7: Space = if has_head(&(v218_6)) { singleton(&[]) } else { Space::new() };
  drop(v218_6);
  let v218_8: Space = subtract(&(*CONSTANT_0),&(v218_7));
  drop(v218_7);
  let v218_13: Space = intersect(&(*CONSTANT_5),&(v218_5));
  drop(v218_5);
  let v218_14: Space = if has_head(&(v218_13)) { singleton(&[]) } else { Space::new() };
  drop(v218_13);
  let mut v218_15 = Space::new();
  let mut v218_15_write = v218_15.write_zipper();
  let mut v218_15_cursor = (*s0).read_zipper();
  let v218_15_origin = v218_15_cursor.path().len();
  for v218_15_byte in v218_15_cursor.child_mask().iter() {
    v218_15_cursor.descend_to_existing_byte(v218_15_byte);
    {
    let v219_4: Space = if (&(v218_8)).is_empty() { Space::new() } else {
      let v220_2: Path = concat_path(&(*p1),&v218_15_cursor.path()[v218_15_origin..(v218_15_origin + 1)]);
      let mut v220_3 = Space::new();
      let mut v220_3_write = v220_3.write_zipper();
      let v220_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v220_3_arg_1: &[u8] = &(v220_2);
      let v220_3_arg_3: &Space = &(&v218_15_cursor).make_map();
      let mut v220_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v220_3_origin = v220_3_cursor.path().len();
      let mut v220_3_more = v220_3_cursor.is_val() || next_value_within(&mut v220_3_cursor,v220_3_origin);
      while v220_3_more {
        {
        let v220_3_depth = v220_3_cursor.path().len();
        let v221_4: Space = routine_26(c, &v220_3_cursor.path()[v220_3_origin..v220_3_depth], &(*v220_3_arg_1), &((*v220_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v220_3_write,&((v221_4).read_zipper()),&[]);
        }
        v220_3_more = next_value_within(&mut v220_3_cursor,v220_3_origin);
      }
      drop(v220_3_cursor);
      drop(v220_3_write);
      compose(&(v218_8),&(v220_3))
    };
    let v219_6: Space = if (&(v218_14)).is_empty() { Space::new() } else {
      let v222_2: Path = concat_path(&(*p1),&v218_15_cursor.path()[v218_15_origin..(v218_15_origin + 1)]);
      let mut v222_5 = Space::new();
      let mut v222_5_write = v222_5.write_zipper();
      for v222_5_byte in v218_15_cursor.child_mask().iter() {
        v218_15_cursor.descend_to_existing_byte(v222_5_byte);
        {
        let v223_2: Space = routine_27(c, &v218_15_cursor.path()[(v218_15_origin + 1)..(v218_15_origin + 2)], &v218_15_cursor.path()[(v218_15_origin + 1)..(v218_15_origin + 2)], &(v222_2), &v218_15_cursor);
        join_wrapped_into(&mut v222_5_write,&((v223_2).read_zipper()),&[]);
        }
        v218_15_cursor.ascend(1);
      }
      drop(v222_5_write);
      drop(v222_2);
      compose(&(v218_14),&(v222_5))
    };
    let v219_7: Space = unite(&(v219_4),&(v219_6));
    join_wrapped_into(&mut v218_15_write,&((v219_7).read_zipper()),&[]);
    }
    v218_15_cursor.ascend(1);
  }
  drop(v218_15_cursor);
  drop(v218_15_write);
  drop(v218_8);
  drop(v218_14);
  (v218_15).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v224_6: Space = singleton(&(*p1));
  let v224_7: Space = intersect(&(*CONSTANT_5),&(v224_6));
  let v224_8: Space = if has_head(&(v224_7)) { singleton(&[]) } else { Space::new() };
  drop(v224_7);
  let v224_9: Space = subtract(&(*CONSTANT_0),&(v224_8));
  drop(v224_8);
  let v224_20: Space = if (&(v224_9)).is_empty() { Space::new() } else {
    let v225_12: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v225_15: Space = if (&(v225_12)).is_empty() { Space::new() } else {
      let v226_14: Space = routine_44(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v225_12),&(v226_14))
    };
    drop(v225_12);
    let mut v225_18 = Space::new();
    let mut v225_18_write = v225_18.write_zipper();
    let mut v225_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v225_18_origin = v225_18_cursor.path().len();
    for v225_18_byte in v225_18_cursor.child_mask().iter() {
      v225_18_cursor.descend_to_existing_byte(v225_18_byte);
      {
      let v227_2_arg_0: &[u8] = &v225_18_cursor.path()[v225_18_origin..(v225_18_origin + 1)];
      let v227_2_arg_1: &[u8] = &(*p0);
      let v227_2_arg_2: &[u8] = &(*p2);
      let v227_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v227_2_more = v225_18_cursor.is_val() || next_value_within(&mut v225_18_cursor,(v225_18_origin + 1));
      while v227_2_more {
        {
        let v227_2_depth = v225_18_cursor.path().len();
        let mut v228_5_cursor = (*v227_2_arg_4).read_zipper();
        let v228_5_origin = v228_5_cursor.path().len();
        for v228_5_byte in v228_5_cursor.child_mask().iter() {
          v228_5_cursor.descend_to_existing_byte(v228_5_byte);
          {
          let v229_2: Path = concat_path(&(*v227_2_arg_1),&v228_5_cursor.path()[v228_5_origin..(v228_5_origin + 1)]);
          let v229_3: Space = routine_27(c, &(v229_2), &v225_18_cursor.path()[v225_18_origin..v227_2_depth], &(*v227_2_arg_2), &v228_5_cursor);
          drop(v229_2);
          join_wrapped_into(&mut v225_18_write,&((v229_3).read_zipper()),&[]);
          }
          v228_5_cursor.ascend(1);
        }
        drop(v228_5_cursor);
        }
        v227_2_more = next_value_within(&mut v225_18_cursor,(v225_18_origin + 1));
      }
      }
      v225_18_cursor.ascend(1);
    }
    drop(v225_18_cursor);
    drop(v225_18_write);
    let v225_19: Space = unite(&(v225_15),&(v225_18));
    compose(&(v224_9),&(v225_19))
  };
  drop(v224_9);
  let v224_22: Space = intersect(&(*CONSTANT_5),&(v224_6));
  drop(v224_6);
  let v224_23: Space = if has_head(&(v224_22)) { singleton(&[]) } else { Space::new() };
  drop(v224_22);
  let v224_25: Space = if (&(v224_23)).is_empty() { Space::new() } else {
    let mut v230_24 = Space::new();
    let mut v230_24_write = v230_24.write_zipper();
    let mut v230_24_cursor = (*s0).read_zipper();
    let v230_24_origin = v230_24_cursor.path().len();
    for v230_24_byte in v230_24_cursor.child_mask().iter() {
      v230_24_cursor.descend_to_existing_byte(v230_24_byte);
      {
      let v231_2: Space = routine_28(c, &v230_24_cursor.path()[v230_24_origin..(v230_24_origin + 1)], &v230_24_cursor.path()[v230_24_origin..(v230_24_origin + 1)], &(*p2), &(*p0), &v230_24_cursor);
      join_wrapped_into(&mut v230_24_write,&((v231_2).read_zipper()),&[]);
      }
      v230_24_cursor.ascend(1);
    }
    drop(v230_24_cursor);
    drop(v230_24_write);
    compose(&(v224_23),&(v230_24))
  };
  drop(v224_23);
  let v224_26: Space = unite(&(v224_20),&(v224_25));
  (v224_26).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v232_7: Space = singleton(&(*p1));
  let v232_8: Space = intersect(&(*CONSTANT_5),&(v232_7));
  let v232_9: Space = if has_head(&(v232_8)) { singleton(&[]) } else { Space::new() };
  drop(v232_8);
  let v232_10: Space = subtract(&(*CONSTANT_0),&(v232_9));
  drop(v232_9);
  let v232_21: Space = if (&(v232_10)).is_empty() { Space::new() } else {
    let v233_13: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v233_16: Space = if (&(v233_13)).is_empty() { Space::new() } else {
      let v234_15: Space = routine_45(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      compose(&(v233_13),&(v234_15))
    };
    drop(v233_13);
    let mut v233_19 = Space::new();
    let mut v233_19_write = v233_19.write_zipper();
    let mut v233_19_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v233_19_origin = v233_19_cursor.path().len();
    for v233_19_byte in v233_19_cursor.child_mask().iter() {
      v233_19_cursor.descend_to_existing_byte(v233_19_byte);
      {
      let v235_2_arg_0: &[u8] = &v233_19_cursor.path()[v233_19_origin..(v233_19_origin + 1)];
      let v235_2_arg_1: &[u8] = &(*p0);
      let v235_2_arg_2: &[u8] = &(*p2);
      let v235_2_arg_3: &[u8] = &(*p3);
      let v235_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v235_2_more = v233_19_cursor.is_val() || next_value_within(&mut v233_19_cursor,(v233_19_origin + 1));
      while v235_2_more {
        {
        let v235_2_depth = v233_19_cursor.path().len();
        let mut v236_6_cursor = (*v235_2_arg_5).read_zipper();
        let v236_6_origin = v236_6_cursor.path().len();
        for v236_6_byte in v236_6_cursor.child_mask().iter() {
          v236_6_cursor.descend_to_existing_byte(v236_6_byte);
          {
          let v237_2: Path = concat_path(&(*v235_2_arg_1),&v236_6_cursor.path()[v236_6_origin..(v236_6_origin + 1)]);
          let v237_3: Space = routine_28(c, &(v237_2), &v233_19_cursor.path()[v233_19_origin..v235_2_depth], &(*v235_2_arg_2), &(*v235_2_arg_3), &v236_6_cursor);
          drop(v237_2);
          join_wrapped_into(&mut v233_19_write,&((v237_3).read_zipper()),&[]);
          }
          v236_6_cursor.ascend(1);
        }
        drop(v236_6_cursor);
        }
        v235_2_more = next_value_within(&mut v233_19_cursor,(v233_19_origin + 1));
      }
      }
      v233_19_cursor.ascend(1);
    }
    drop(v233_19_cursor);
    drop(v233_19_write);
    let v233_20: Space = unite(&(v233_16),&(v233_19));
    compose(&(v232_10),&(v233_20))
  };
  drop(v232_10);
  let v232_23: Space = intersect(&(*CONSTANT_5),&(v232_7));
  drop(v232_7);
  let v232_24: Space = if has_head(&(v232_23)) { singleton(&[]) } else { Space::new() };
  drop(v232_23);
  let v232_38: Space = if (&(v232_24)).is_empty() { Space::new() } else {
    let v238_27: Path = concat_path(&(*CONSTANT_14),&(*p0));
    let v238_28: Space = singleton(&(v238_27));
    drop(v238_27);
    let v238_29: Space = unite(&(*CONSTANT_16),&(v238_28));
    drop(v238_28);
    let v238_31: Path = concat_path(&(*CONSTANT_12),&(*p2));
    let v238_32: Space = singleton(&(v238_31));
    drop(v238_31);
    let v238_33: Space = unite(&(v238_29),&(v238_32));
    drop(v238_29);
    drop(v238_32);
    let v238_35: Path = concat_path(&(*CONSTANT_13),&(*p3));
    let v238_36: Space = singleton(&(v238_35));
    drop(v238_35);
    let v238_37: Space = unite(&(v238_33),&(v238_36));
    drop(v238_33);
    drop(v238_36);
    compose(&(v232_24),&(v238_37))
  };
  drop(v232_24);
  let v232_39: Space = unite(&(v232_21),&(v232_38));
  drop(v232_38);
  (v232_39).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v239_5: Space = singleton(&(*p0));
  let v239_6: Space = intersect(&(*CONSTANT_5),&(v239_5));
  let v239_7: Space = if has_head(&(v239_6)) { singleton(&[]) } else { Space::new() };
  drop(v239_6);
  let v239_8: Space = subtract(&(*CONSTANT_0),&(v239_7));
  drop(v239_7);
  let v239_13: Space = intersect(&(*CONSTANT_5),&(v239_5));
  drop(v239_5);
  let v239_14: Space = if has_head(&(v239_13)) { singleton(&[]) } else { Space::new() };
  drop(v239_13);
  let mut v239_15 = Space::new();
  let mut v239_15_write = v239_15.write_zipper();
  let mut v239_15_cursor = (*s0).read_zipper();
  let v239_15_origin = v239_15_cursor.path().len();
  for v239_15_byte in v239_15_cursor.child_mask().iter() {
    v239_15_cursor.descend_to_existing_byte(v239_15_byte);
    {
    let v240_4: Space = if (&(v239_8)).is_empty() { Space::new() } else {
      let v241_2: Path = concat_path(&(*p1),&v239_15_cursor.path()[v239_15_origin..(v239_15_origin + 1)]);
      let mut v241_3 = Space::new();
      let mut v241_3_write = v241_3.write_zipper();
      let v241_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v241_3_arg_1: &[u8] = &(v241_2);
      let v241_3_arg_3: &Space = &(&v239_15_cursor).make_map();
      let mut v241_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v241_3_origin = v241_3_cursor.path().len();
      let mut v241_3_more = v241_3_cursor.is_val() || next_value_within(&mut v241_3_cursor,v241_3_origin);
      while v241_3_more {
        {
        let v241_3_depth = v241_3_cursor.path().len();
        let v242_4: Space = routine_29(c, &v241_3_cursor.path()[v241_3_origin..v241_3_depth], &(*v241_3_arg_1), &((*v241_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v241_3_write,&((v242_4).read_zipper()),&[]);
        }
        v241_3_more = next_value_within(&mut v241_3_cursor,v241_3_origin);
      }
      drop(v241_3_cursor);
      drop(v241_3_write);
      compose(&(v239_8),&(v241_3))
    };
    let v240_6: Space = if (&(v239_14)).is_empty() { Space::new() } else {
      let v243_2: Path = concat_path(&(*p1),&v239_15_cursor.path()[v239_15_origin..(v239_15_origin + 1)]);
      let mut v243_5 = Space::new();
      let mut v243_5_write = v243_5.write_zipper();
      for v243_5_byte in v239_15_cursor.child_mask().iter() {
        v239_15_cursor.descend_to_existing_byte(v243_5_byte);
        {
        let v244_2: Space = routine_30(c, &v239_15_cursor.path()[(v239_15_origin + 1)..(v239_15_origin + 2)], &v239_15_cursor.path()[(v239_15_origin + 1)..(v239_15_origin + 2)], &(v243_2), &v239_15_cursor);
        join_wrapped_into(&mut v243_5_write,&((v244_2).read_zipper()),&[]);
        }
        v239_15_cursor.ascend(1);
      }
      drop(v243_5_write);
      drop(v243_2);
      compose(&(v239_14),&(v243_5))
    };
    let v240_7: Space = unite(&(v240_4),&(v240_6));
    join_wrapped_into(&mut v239_15_write,&((v240_7).read_zipper()),&[]);
    }
    v239_15_cursor.ascend(1);
  }
  drop(v239_15_cursor);
  drop(v239_15_write);
  drop(v239_8);
  drop(v239_14);
  (v239_15).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v245_6: Space = singleton(&(*p1));
  let v245_7: Space = intersect(&(*CONSTANT_5),&(v245_6));
  let v245_8: Space = if has_head(&(v245_7)) { singleton(&[]) } else { Space::new() };
  drop(v245_7);
  let v245_9: Space = subtract(&(*CONSTANT_0),&(v245_8));
  drop(v245_8);
  let v245_20: Space = if (&(v245_9)).is_empty() { Space::new() } else {
    let v246_12: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v246_15: Space = if (&(v246_12)).is_empty() { Space::new() } else {
      let v247_14: Space = routine_46(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v246_12),&(v247_14))
    };
    drop(v246_12);
    let mut v246_18 = Space::new();
    let mut v246_18_write = v246_18.write_zipper();
    let mut v246_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v246_18_origin = v246_18_cursor.path().len();
    for v246_18_byte in v246_18_cursor.child_mask().iter() {
      v246_18_cursor.descend_to_existing_byte(v246_18_byte);
      {
      let v248_2_arg_0: &[u8] = &v246_18_cursor.path()[v246_18_origin..(v246_18_origin + 1)];
      let v248_2_arg_1: &[u8] = &(*p0);
      let v248_2_arg_2: &[u8] = &(*p2);
      let v248_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v248_2_more = v246_18_cursor.is_val() || next_value_within(&mut v246_18_cursor,(v246_18_origin + 1));
      while v248_2_more {
        {
        let v248_2_depth = v246_18_cursor.path().len();
        let mut v249_5_cursor = (*v248_2_arg_4).read_zipper();
        let v249_5_origin = v249_5_cursor.path().len();
        for v249_5_byte in v249_5_cursor.child_mask().iter() {
          v249_5_cursor.descend_to_existing_byte(v249_5_byte);
          {
          let v250_2: Path = concat_path(&(*v248_2_arg_1),&v249_5_cursor.path()[v249_5_origin..(v249_5_origin + 1)]);
          let v250_3: Space = routine_30(c, &(v250_2), &v246_18_cursor.path()[v246_18_origin..v248_2_depth], &(*v248_2_arg_2), &v249_5_cursor);
          drop(v250_2);
          join_wrapped_into(&mut v246_18_write,&((v250_3).read_zipper()),&[]);
          }
          v249_5_cursor.ascend(1);
        }
        drop(v249_5_cursor);
        }
        v248_2_more = next_value_within(&mut v246_18_cursor,(v246_18_origin + 1));
      }
      }
      v246_18_cursor.ascend(1);
    }
    drop(v246_18_cursor);
    drop(v246_18_write);
    let v246_19: Space = unite(&(v246_15),&(v246_18));
    compose(&(v245_9),&(v246_19))
  };
  drop(v245_9);
  let v245_22: Space = intersect(&(*CONSTANT_5),&(v245_6));
  drop(v245_6);
  let v245_23: Space = if has_head(&(v245_22)) { singleton(&[]) } else { Space::new() };
  drop(v245_22);
  let v245_25: Space = if (&(v245_23)).is_empty() { Space::new() } else {
    let mut v251_24 = Space::new();
    let mut v251_24_write = v251_24.write_zipper();
    let mut v251_24_cursor = (*s0).read_zipper();
    let v251_24_origin = v251_24_cursor.path().len();
    for v251_24_byte in v251_24_cursor.child_mask().iter() {
      v251_24_cursor.descend_to_existing_byte(v251_24_byte);
      {
      let v252_2: Space = routine_31(c, &v251_24_cursor.path()[v251_24_origin..(v251_24_origin + 1)], &v251_24_cursor.path()[v251_24_origin..(v251_24_origin + 1)], &(*p2), &(*p0), &v251_24_cursor);
      join_wrapped_into(&mut v251_24_write,&((v252_2).read_zipper()),&[]);
      }
      v251_24_cursor.ascend(1);
    }
    drop(v251_24_cursor);
    drop(v251_24_write);
    compose(&(v245_23),&(v251_24))
  };
  drop(v245_23);
  let v245_26: Space = unite(&(v245_20),&(v245_25));
  (v245_26).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v253_7: Space = singleton(&(*p1));
  let v253_8: Space = intersect(&(*CONSTANT_5),&(v253_7));
  let v253_9: Space = if has_head(&(v253_8)) { singleton(&[]) } else { Space::new() };
  drop(v253_8);
  let v253_10: Space = subtract(&(*CONSTANT_0),&(v253_9));
  drop(v253_9);
  let v253_21: Space = if (&(v253_10)).is_empty() { Space::new() } else {
    let v254_13: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v254_16: Space = if (&(v254_13)).is_empty() { Space::new() } else {
      let v255_15: Space = routine_47(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      compose(&(v254_13),&(v255_15))
    };
    drop(v254_13);
    let mut v254_19 = Space::new();
    let mut v254_19_write = v254_19.write_zipper();
    let mut v254_19_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v254_19_origin = v254_19_cursor.path().len();
    for v254_19_byte in v254_19_cursor.child_mask().iter() {
      v254_19_cursor.descend_to_existing_byte(v254_19_byte);
      {
      let v256_2_arg_0: &[u8] = &v254_19_cursor.path()[v254_19_origin..(v254_19_origin + 1)];
      let v256_2_arg_1: &[u8] = &(*p0);
      let v256_2_arg_2: &[u8] = &(*p2);
      let v256_2_arg_3: &[u8] = &(*p3);
      let v256_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v256_2_more = v254_19_cursor.is_val() || next_value_within(&mut v254_19_cursor,(v254_19_origin + 1));
      while v256_2_more {
        {
        let v256_2_depth = v254_19_cursor.path().len();
        let mut v257_6_cursor = (*v256_2_arg_5).read_zipper();
        let v257_6_origin = v257_6_cursor.path().len();
        for v257_6_byte in v257_6_cursor.child_mask().iter() {
          v257_6_cursor.descend_to_existing_byte(v257_6_byte);
          {
          let v258_2: Path = concat_path(&(*v256_2_arg_1),&v257_6_cursor.path()[v257_6_origin..(v257_6_origin + 1)]);
          let v258_3: Space = routine_31(c, &(v258_2), &v254_19_cursor.path()[v254_19_origin..v256_2_depth], &(*v256_2_arg_2), &(*v256_2_arg_3), &v257_6_cursor);
          drop(v258_2);
          join_wrapped_into(&mut v254_19_write,&((v258_3).read_zipper()),&[]);
          }
          v257_6_cursor.ascend(1);
        }
        drop(v257_6_cursor);
        }
        v256_2_more = next_value_within(&mut v254_19_cursor,(v254_19_origin + 1));
      }
      }
      v254_19_cursor.ascend(1);
    }
    drop(v254_19_cursor);
    drop(v254_19_write);
    let v254_20: Space = unite(&(v254_16),&(v254_19));
    compose(&(v253_10),&(v254_20))
  };
  drop(v253_10);
  let v253_23: Space = intersect(&(*CONSTANT_5),&(v253_7));
  drop(v253_7);
  let v253_24: Space = if has_head(&(v253_23)) { singleton(&[]) } else { Space::new() };
  drop(v253_23);
  let v253_38: Space = if (&(v253_24)).is_empty() { Space::new() } else {
    let v259_27: Path = concat_path(&(*CONSTANT_15),&(*p0));
    let v259_28: Space = singleton(&(v259_27));
    drop(v259_27);
    let v259_29: Space = unite(&(*CONSTANT_17),&(v259_28));
    drop(v259_28);
    let v259_31: Path = concat_path(&(*CONSTANT_12),&(*p2));
    let v259_32: Space = singleton(&(v259_31));
    drop(v259_31);
    let v259_33: Space = unite(&(v259_29),&(v259_32));
    drop(v259_29);
    drop(v259_32);
    let v259_35: Path = concat_path(&(*CONSTANT_13),&(*p3));
    let v259_36: Space = singleton(&(v259_35));
    drop(v259_35);
    let v259_37: Space = unite(&(v259_33),&(v259_36));
    drop(v259_33);
    drop(v259_36);
    compose(&(v253_24),&(v259_37))
  };
  drop(v253_24);
  let v253_39: Space = unite(&(v253_21),&(v253_38));
  drop(v253_38);
  (v253_39).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v260_5: Space = singleton(&(*p0));
  let v260_6: Space = intersect(&(*CONSTANT_5),&(v260_5));
  let v260_7: Space = if has_head(&(v260_6)) { singleton(&[]) } else { Space::new() };
  drop(v260_6);
  let v260_8: Space = subtract(&(*CONSTANT_0),&(v260_7));
  drop(v260_7);
  let v260_13: Space = intersect(&(*CONSTANT_5),&(v260_5));
  drop(v260_5);
  let v260_14: Space = if has_head(&(v260_13)) { singleton(&[]) } else { Space::new() };
  drop(v260_13);
  let mut v260_15 = Space::new();
  let mut v260_15_write = v260_15.write_zipper();
  let mut v260_15_cursor = (*s0).read_zipper();
  let v260_15_origin = v260_15_cursor.path().len();
  for v260_15_byte in v260_15_cursor.child_mask().iter() {
    v260_15_cursor.descend_to_existing_byte(v260_15_byte);
    {
    let v261_4: Space = if (&(v260_8)).is_empty() { Space::new() } else {
      let v262_2: Path = concat_path(&(*p1),&v260_15_cursor.path()[v260_15_origin..(v260_15_origin + 1)]);
      let mut v262_3 = Space::new();
      let mut v262_3_write = v262_3.write_zipper();
      let v262_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v262_3_arg_1: &[u8] = &(v262_2);
      let v262_3_arg_3: &Space = &(&v260_15_cursor).make_map();
      let mut v262_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v262_3_origin = v262_3_cursor.path().len();
      let mut v262_3_more = v262_3_cursor.is_val() || next_value_within(&mut v262_3_cursor,v262_3_origin);
      while v262_3_more {
        {
        let v262_3_depth = v262_3_cursor.path().len();
        let v263_4: Space = routine_32(c, &v262_3_cursor.path()[v262_3_origin..v262_3_depth], &(*v262_3_arg_1), &((*v262_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v262_3_write,&((v263_4).read_zipper()),&[]);
        }
        v262_3_more = next_value_within(&mut v262_3_cursor,v262_3_origin);
      }
      drop(v262_3_cursor);
      drop(v262_3_write);
      compose(&(v260_8),&(v262_3))
    };
    let v261_6: Space = if (&(v260_14)).is_empty() { Space::new() } else {
      let v264_2: Path = concat_path(&(*p1),&v260_15_cursor.path()[v260_15_origin..(v260_15_origin + 1)]);
      let mut v264_5 = Space::new();
      let mut v264_5_write = v264_5.write_zipper();
      for v264_5_byte in v260_15_cursor.child_mask().iter() {
        v260_15_cursor.descend_to_existing_byte(v264_5_byte);
        {
        let v265_2: Space = routine_33(c, &v260_15_cursor.path()[(v260_15_origin + 1)..(v260_15_origin + 2)], &v260_15_cursor.path()[(v260_15_origin + 1)..(v260_15_origin + 2)], &(v264_2), &v260_15_cursor);
        join_wrapped_into(&mut v264_5_write,&((v265_2).read_zipper()),&[]);
        }
        v260_15_cursor.ascend(1);
      }
      drop(v264_5_write);
      drop(v264_2);
      compose(&(v260_14),&(v264_5))
    };
    let v261_7: Space = unite(&(v261_4),&(v261_6));
    join_wrapped_into(&mut v260_15_write,&((v261_7).read_zipper()),&[]);
    }
    v260_15_cursor.ascend(1);
  }
  drop(v260_15_cursor);
  drop(v260_15_write);
  drop(v260_8);
  drop(v260_14);
  (v260_15).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v266_6: Space = singleton(&(*p1));
  let v266_7: Space = intersect(&(*CONSTANT_5),&(v266_6));
  let v266_8: Space = if has_head(&(v266_7)) { singleton(&[]) } else { Space::new() };
  drop(v266_7);
  let v266_9: Space = subtract(&(*CONSTANT_0),&(v266_8));
  drop(v266_8);
  let v266_20: Space = if (&(v266_9)).is_empty() { Space::new() } else {
    let v267_12: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v267_15: Space = if (&(v267_12)).is_empty() { Space::new() } else {
      let v268_14: Space = routine_48(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v267_12),&(v268_14))
    };
    drop(v267_12);
    let mut v267_18 = Space::new();
    let mut v267_18_write = v267_18.write_zipper();
    let mut v267_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v267_18_origin = v267_18_cursor.path().len();
    for v267_18_byte in v267_18_cursor.child_mask().iter() {
      v267_18_cursor.descend_to_existing_byte(v267_18_byte);
      {
      let v269_2_arg_0: &[u8] = &v267_18_cursor.path()[v267_18_origin..(v267_18_origin + 1)];
      let v269_2_arg_1: &[u8] = &(*p0);
      let v269_2_arg_2: &[u8] = &(*p2);
      let v269_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v269_2_more = v267_18_cursor.is_val() || next_value_within(&mut v267_18_cursor,(v267_18_origin + 1));
      while v269_2_more {
        {
        let v269_2_depth = v267_18_cursor.path().len();
        let mut v270_5_cursor = (*v269_2_arg_4).read_zipper();
        let v270_5_origin = v270_5_cursor.path().len();
        for v270_5_byte in v270_5_cursor.child_mask().iter() {
          v270_5_cursor.descend_to_existing_byte(v270_5_byte);
          {
          let v271_2: Path = concat_path(&(*v269_2_arg_1),&v270_5_cursor.path()[v270_5_origin..(v270_5_origin + 1)]);
          let v271_3: Space = routine_33(c, &(v271_2), &v267_18_cursor.path()[v267_18_origin..v269_2_depth], &(*v269_2_arg_2), &v270_5_cursor);
          drop(v271_2);
          join_wrapped_into(&mut v267_18_write,&((v271_3).read_zipper()),&[]);
          }
          v270_5_cursor.ascend(1);
        }
        drop(v270_5_cursor);
        }
        v269_2_more = next_value_within(&mut v267_18_cursor,(v267_18_origin + 1));
      }
      }
      v267_18_cursor.ascend(1);
    }
    drop(v267_18_cursor);
    drop(v267_18_write);
    let v267_19: Space = unite(&(v267_15),&(v267_18));
    compose(&(v266_9),&(v267_19))
  };
  drop(v266_9);
  let v266_22: Space = intersect(&(*CONSTANT_5),&(v266_6));
  drop(v266_6);
  let v266_23: Space = if has_head(&(v266_22)) { singleton(&[]) } else { Space::new() };
  drop(v266_22);
  let v266_25: Space = if (&(v266_23)).is_empty() { Space::new() } else {
    let mut v272_24 = Space::new();
    let mut v272_24_write = v272_24.write_zipper();
    let mut v272_24_cursor = (*s0).read_zipper();
    let v272_24_origin = v272_24_cursor.path().len();
    for v272_24_byte in v272_24_cursor.child_mask().iter() {
      v272_24_cursor.descend_to_existing_byte(v272_24_byte);
      {
      let v273_2: Space = routine_34(c, &v272_24_cursor.path()[v272_24_origin..(v272_24_origin + 1)], &v272_24_cursor.path()[v272_24_origin..(v272_24_origin + 1)], &(*p2), &(*p0), &v272_24_cursor);
      join_wrapped_into(&mut v272_24_write,&((v273_2).read_zipper()),&[]);
      }
      v272_24_cursor.ascend(1);
    }
    drop(v272_24_cursor);
    drop(v272_24_write);
    compose(&(v266_23),&(v272_24))
  };
  drop(v266_23);
  let v266_26: Space = unite(&(v266_20),&(v266_25));
  (v266_26).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v274_7: Space = singleton(&(*p1));
  let v274_8: Space = intersect(&(*CONSTANT_5),&(v274_7));
  let v274_9: Space = if has_head(&(v274_8)) { singleton(&[]) } else { Space::new() };
  drop(v274_8);
  let v274_10: Space = subtract(&(*CONSTANT_0),&(v274_9));
  drop(v274_9);
  let v274_21: Space = if (&(v274_10)).is_empty() { Space::new() } else {
    let v275_13: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v275_16: Space = if (&(v275_13)).is_empty() { Space::new() } else {
      let v276_15: Space = routine_49(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      compose(&(v275_13),&(v276_15))
    };
    drop(v275_13);
    let mut v275_19 = Space::new();
    let mut v275_19_write = v275_19.write_zipper();
    let mut v275_19_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v275_19_origin = v275_19_cursor.path().len();
    for v275_19_byte in v275_19_cursor.child_mask().iter() {
      v275_19_cursor.descend_to_existing_byte(v275_19_byte);
      {
      let v277_2_arg_0: &[u8] = &v275_19_cursor.path()[v275_19_origin..(v275_19_origin + 1)];
      let v277_2_arg_1: &[u8] = &(*p0);
      let v277_2_arg_2: &[u8] = &(*p2);
      let v277_2_arg_3: &[u8] = &(*p3);
      let v277_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v277_2_more = v275_19_cursor.is_val() || next_value_within(&mut v275_19_cursor,(v275_19_origin + 1));
      while v277_2_more {
        {
        let v277_2_depth = v275_19_cursor.path().len();
        let mut v278_6_cursor = (*v277_2_arg_5).read_zipper();
        let v278_6_origin = v278_6_cursor.path().len();
        for v278_6_byte in v278_6_cursor.child_mask().iter() {
          v278_6_cursor.descend_to_existing_byte(v278_6_byte);
          {
          let v279_2: Path = concat_path(&(*v277_2_arg_1),&v278_6_cursor.path()[v278_6_origin..(v278_6_origin + 1)]);
          let v279_3: Space = routine_34(c, &(v279_2), &v275_19_cursor.path()[v275_19_origin..v277_2_depth], &(*v277_2_arg_2), &(*v277_2_arg_3), &v278_6_cursor);
          drop(v279_2);
          join_wrapped_into(&mut v275_19_write,&((v279_3).read_zipper()),&[]);
          }
          v278_6_cursor.ascend(1);
        }
        drop(v278_6_cursor);
        }
        v277_2_more = next_value_within(&mut v275_19_cursor,(v275_19_origin + 1));
      }
      }
      v275_19_cursor.ascend(1);
    }
    drop(v275_19_cursor);
    drop(v275_19_write);
    let v275_20: Space = unite(&(v275_16),&(v275_19));
    compose(&(v274_10),&(v275_20))
  };
  drop(v274_10);
  let v274_23: Space = intersect(&(*CONSTANT_5),&(v274_7));
  drop(v274_7);
  let v274_24: Space = if has_head(&(v274_23)) { singleton(&[]) } else { Space::new() };
  drop(v274_23);
  let v274_38: Space = if (&(v274_24)).is_empty() { Space::new() } else {
    let v280_27: Path = concat_path(&(*CONSTANT_15),&(*p3));
    let v280_28: Space = singleton(&(v280_27));
    drop(v280_27);
    let v280_29: Space = unite(&(*CONSTANT_18),&(v280_28));
    drop(v280_28);
    let v280_31: Path = concat_path(&(*CONSTANT_14),&(*p0));
    let v280_32: Space = singleton(&(v280_31));
    drop(v280_31);
    let v280_33: Space = unite(&(v280_29),&(v280_32));
    drop(v280_29);
    drop(v280_32);
    let v280_35: Path = concat_path(&(*CONSTANT_13),&(*p2));
    let v280_36: Space = singleton(&(v280_35));
    drop(v280_35);
    let v280_37: Space = unite(&(v280_33),&(v280_36));
    drop(v280_33);
    drop(v280_36);
    compose(&(v274_24),&(v280_37))
  };
  drop(v274_24);
  let v274_39: Space = unite(&(v274_21),&(v274_38));
  drop(v274_38);
  (v274_39).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v281_5: Space = singleton(&(*p0));
  let v281_6: Space = intersect(&(*CONSTANT_5),&(v281_5));
  let v281_7: Space = if has_head(&(v281_6)) { singleton(&[]) } else { Space::new() };
  drop(v281_6);
  let v281_8: Space = subtract(&(*CONSTANT_0),&(v281_7));
  drop(v281_7);
  let v281_13: Space = intersect(&(*CONSTANT_5),&(v281_5));
  drop(v281_5);
  let v281_14: Space = if has_head(&(v281_13)) { singleton(&[]) } else { Space::new() };
  drop(v281_13);
  let mut v281_15 = Space::new();
  let mut v281_15_write = v281_15.write_zipper();
  let mut v281_15_cursor = (*s0).read_zipper();
  let v281_15_origin = v281_15_cursor.path().len();
  for v281_15_byte in v281_15_cursor.child_mask().iter() {
    v281_15_cursor.descend_to_existing_byte(v281_15_byte);
    {
    let v282_4: Space = if (&(v281_8)).is_empty() { Space::new() } else {
      let v283_2: Path = concat_path(&(*p1),&v281_15_cursor.path()[v281_15_origin..(v281_15_origin + 1)]);
      let mut v283_3 = Space::new();
      let mut v283_3_write = v283_3.write_zipper();
      let v283_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v283_3_arg_1: &[u8] = &(v283_2);
      let v283_3_arg_3: &Space = &(&v281_15_cursor).make_map();
      let mut v283_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v283_3_origin = v283_3_cursor.path().len();
      let mut v283_3_more = v283_3_cursor.is_val() || next_value_within(&mut v283_3_cursor,v283_3_origin);
      while v283_3_more {
        {
        let v283_3_depth = v283_3_cursor.path().len();
        let v284_4: Space = routine_35(c, &v283_3_cursor.path()[v283_3_origin..v283_3_depth], &(*v283_3_arg_1), &((*v283_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v283_3_write,&((v284_4).read_zipper()),&[]);
        }
        v283_3_more = next_value_within(&mut v283_3_cursor,v283_3_origin);
      }
      drop(v283_3_cursor);
      drop(v283_3_write);
      compose(&(v281_8),&(v283_3))
    };
    let v282_6: Space = if (&(v281_14)).is_empty() { Space::new() } else {
      let v285_2: Path = concat_path(&(*p1),&v281_15_cursor.path()[v281_15_origin..(v281_15_origin + 1)]);
      let mut v285_5 = Space::new();
      let mut v285_5_write = v285_5.write_zipper();
      for v285_5_byte in v281_15_cursor.child_mask().iter() {
        v281_15_cursor.descend_to_existing_byte(v285_5_byte);
        {
        let v286_2: Space = routine_36(c, &v281_15_cursor.path()[(v281_15_origin + 1)..(v281_15_origin + 2)], &v281_15_cursor.path()[(v281_15_origin + 1)..(v281_15_origin + 2)], &(v285_2), &v281_15_cursor);
        join_wrapped_into(&mut v285_5_write,&((v286_2).read_zipper()),&[]);
        }
        v281_15_cursor.ascend(1);
      }
      drop(v285_5_write);
      drop(v285_2);
      compose(&(v281_14),&(v285_5))
    };
    let v282_7: Space = unite(&(v282_4),&(v282_6));
    join_wrapped_into(&mut v281_15_write,&((v282_7).read_zipper()),&[]);
    }
    v281_15_cursor.ascend(1);
  }
  drop(v281_15_cursor);
  drop(v281_15_write);
  drop(v281_8);
  drop(v281_14);
  (v281_15).clone()
}

fn routine_36(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v287_6: Space = singleton(&(*p1));
  let v287_7: Space = intersect(&(*CONSTANT_5),&(v287_6));
  let v287_8: Space = if has_head(&(v287_7)) { singleton(&[]) } else { Space::new() };
  drop(v287_7);
  let v287_9: Space = subtract(&(*CONSTANT_0),&(v287_8));
  drop(v287_8);
  let v287_20: Space = if (&(v287_9)).is_empty() { Space::new() } else {
    let v288_12: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v288_15: Space = if (&(v288_12)).is_empty() { Space::new() } else {
      let v289_14: Space = routine_50(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v288_12),&(v289_14))
    };
    drop(v288_12);
    let mut v288_18 = Space::new();
    let mut v288_18_write = v288_18.write_zipper();
    let mut v288_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v288_18_origin = v288_18_cursor.path().len();
    for v288_18_byte in v288_18_cursor.child_mask().iter() {
      v288_18_cursor.descend_to_existing_byte(v288_18_byte);
      {
      let v290_2_arg_0: &[u8] = &v288_18_cursor.path()[v288_18_origin..(v288_18_origin + 1)];
      let v290_2_arg_1: &[u8] = &(*p0);
      let v290_2_arg_2: &[u8] = &(*p2);
      let v290_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v290_2_more = v288_18_cursor.is_val() || next_value_within(&mut v288_18_cursor,(v288_18_origin + 1));
      while v290_2_more {
        {
        let v290_2_depth = v288_18_cursor.path().len();
        let mut v291_5_cursor = (*v290_2_arg_4).read_zipper();
        let v291_5_origin = v291_5_cursor.path().len();
        for v291_5_byte in v291_5_cursor.child_mask().iter() {
          v291_5_cursor.descend_to_existing_byte(v291_5_byte);
          {
          let v292_2: Path = concat_path(&(*v290_2_arg_1),&v291_5_cursor.path()[v291_5_origin..(v291_5_origin + 1)]);
          let v292_3: Space = routine_36(c, &(v292_2), &v288_18_cursor.path()[v288_18_origin..v290_2_depth], &(*v290_2_arg_2), &v291_5_cursor);
          drop(v292_2);
          join_wrapped_into(&mut v288_18_write,&((v292_3).read_zipper()),&[]);
          }
          v291_5_cursor.ascend(1);
        }
        drop(v291_5_cursor);
        }
        v290_2_more = next_value_within(&mut v288_18_cursor,(v288_18_origin + 1));
      }
      }
      v288_18_cursor.ascend(1);
    }
    drop(v288_18_cursor);
    drop(v288_18_write);
    let v288_19: Space = unite(&(v288_15),&(v288_18));
    compose(&(v287_9),&(v288_19))
  };
  drop(v287_9);
  let v287_22: Space = intersect(&(*CONSTANT_5),&(v287_6));
  drop(v287_6);
  let v287_23: Space = if has_head(&(v287_22)) { singleton(&[]) } else { Space::new() };
  drop(v287_22);
  let v287_25: Space = if (&(v287_23)).is_empty() { Space::new() } else {
    let mut v293_24 = Space::new();
    let mut v293_24_write = v293_24.write_zipper();
    let mut v293_24_cursor = (*s0).read_zipper();
    let v293_24_origin = v293_24_cursor.path().len();
    for v293_24_byte in v293_24_cursor.child_mask().iter() {
      v293_24_cursor.descend_to_existing_byte(v293_24_byte);
      {
      let v294_2: Space = routine_37(c, &v293_24_cursor.path()[v293_24_origin..(v293_24_origin + 1)], &v293_24_cursor.path()[v293_24_origin..(v293_24_origin + 1)], &(*p2), &(*p0), &v293_24_cursor);
      join_wrapped_into(&mut v293_24_write,&((v294_2).read_zipper()),&[]);
      }
      v293_24_cursor.ascend(1);
    }
    drop(v293_24_cursor);
    drop(v293_24_write);
    compose(&(v287_23),&(v293_24))
  };
  drop(v287_23);
  let v287_26: Space = unite(&(v287_20),&(v287_25));
  (v287_26).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v295_7: Space = singleton(&(*p1));
  let v295_8: Space = intersect(&(*CONSTANT_5),&(v295_7));
  let v295_9: Space = if has_head(&(v295_8)) { singleton(&[]) } else { Space::new() };
  drop(v295_8);
  let v295_10: Space = subtract(&(*CONSTANT_0),&(v295_9));
  drop(v295_9);
  let v295_21: Space = if (&(v295_10)).is_empty() { Space::new() } else {
    let v296_13: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v296_16: Space = if (&(v296_13)).is_empty() { Space::new() } else {
      let v297_15: Space = routine_51(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      compose(&(v296_13),&(v297_15))
    };
    drop(v296_13);
    let mut v296_19 = Space::new();
    let mut v296_19_write = v296_19.write_zipper();
    let mut v296_19_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v296_19_origin = v296_19_cursor.path().len();
    for v296_19_byte in v296_19_cursor.child_mask().iter() {
      v296_19_cursor.descend_to_existing_byte(v296_19_byte);
      {
      let v298_2_arg_0: &[u8] = &v296_19_cursor.path()[v296_19_origin..(v296_19_origin + 1)];
      let v298_2_arg_1: &[u8] = &(*p0);
      let v298_2_arg_2: &[u8] = &(*p2);
      let v298_2_arg_3: &[u8] = &(*p3);
      let v298_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v298_2_more = v296_19_cursor.is_val() || next_value_within(&mut v296_19_cursor,(v296_19_origin + 1));
      while v298_2_more {
        {
        let v298_2_depth = v296_19_cursor.path().len();
        let mut v299_6_cursor = (*v298_2_arg_5).read_zipper();
        let v299_6_origin = v299_6_cursor.path().len();
        for v299_6_byte in v299_6_cursor.child_mask().iter() {
          v299_6_cursor.descend_to_existing_byte(v299_6_byte);
          {
          let v300_2: Path = concat_path(&(*v298_2_arg_1),&v299_6_cursor.path()[v299_6_origin..(v299_6_origin + 1)]);
          let v300_3: Space = routine_37(c, &(v300_2), &v296_19_cursor.path()[v296_19_origin..v298_2_depth], &(*v298_2_arg_2), &(*v298_2_arg_3), &v299_6_cursor);
          drop(v300_2);
          join_wrapped_into(&mut v296_19_write,&((v300_3).read_zipper()),&[]);
          }
          v299_6_cursor.ascend(1);
        }
        drop(v299_6_cursor);
        }
        v298_2_more = next_value_within(&mut v296_19_cursor,(v296_19_origin + 1));
      }
      }
      v296_19_cursor.ascend(1);
    }
    drop(v296_19_cursor);
    drop(v296_19_write);
    let v296_20: Space = unite(&(v296_16),&(v296_19));
    compose(&(v295_10),&(v296_20))
  };
  drop(v295_10);
  let v295_23: Space = intersect(&(*CONSTANT_5),&(v295_7));
  drop(v295_7);
  let v295_24: Space = if has_head(&(v295_23)) { singleton(&[]) } else { Space::new() };
  drop(v295_23);
  let v295_38: Space = if (&(v295_24)).is_empty() { Space::new() } else {
    let v301_27: Path = concat_path(&(*CONSTANT_15),&(*p3));
    let v301_28: Space = singleton(&(v301_27));
    drop(v301_27);
    let v301_29: Space = unite(&(*CONSTANT_19),&(v301_28));
    drop(v301_28);
    let v301_31: Path = concat_path(&(*CONSTANT_14),&(*p0));
    let v301_32: Space = singleton(&(v301_31));
    drop(v301_31);
    let v301_33: Space = unite(&(v301_29),&(v301_32));
    drop(v301_29);
    drop(v301_32);
    let v301_35: Path = concat_path(&(*CONSTANT_12),&(*p2));
    let v301_36: Space = singleton(&(v301_35));
    drop(v301_35);
    let v301_37: Space = unite(&(v301_33),&(v301_36));
    drop(v301_33);
    drop(v301_36);
    compose(&(v295_24),&(v301_37))
  };
  drop(v295_24);
  let v295_39: Space = unite(&(v295_21),&(v295_38));
  drop(v295_38);
  (v295_39).clone()
}

fn routine_38(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v302_5: Space = singleton(&(*p0));
  let v302_6: Space = intersect(&(*CONSTANT_5),&(v302_5));
  let v302_7: Space = if has_head(&(v302_6)) { singleton(&[]) } else { Space::new() };
  drop(v302_6);
  let v302_8: Space = subtract(&(*CONSTANT_0),&(v302_7));
  drop(v302_7);
  let v302_13: Space = intersect(&(*CONSTANT_5),&(v302_5));
  drop(v302_5);
  let v302_14: Space = if has_head(&(v302_13)) { singleton(&[]) } else { Space::new() };
  drop(v302_13);
  let mut v302_15 = Space::new();
  let mut v302_15_write = v302_15.write_zipper();
  let mut v302_15_cursor = (*s0).read_zipper();
  let v302_15_origin = v302_15_cursor.path().len();
  for v302_15_byte in v302_15_cursor.child_mask().iter() {
    v302_15_cursor.descend_to_existing_byte(v302_15_byte);
    {
    let v303_4: Space = if (&(v302_8)).is_empty() { Space::new() } else {
      let v304_2: Path = concat_path(&(*p1),&v302_15_cursor.path()[v302_15_origin..(v302_15_origin + 1)]);
      let mut v304_3 = Space::new();
      let mut v304_3_write = v304_3.write_zipper();
      let v304_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v304_3_arg_1: &[u8] = &(v304_2);
      let v304_3_arg_3: &Space = &(&v302_15_cursor).make_map();
      let mut v304_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v304_3_origin = v304_3_cursor.path().len();
      let mut v304_3_more = v304_3_cursor.is_val() || next_value_within(&mut v304_3_cursor,v304_3_origin);
      while v304_3_more {
        {
        let v304_3_depth = v304_3_cursor.path().len();
        let v305_4: Space = routine_38(c, &v304_3_cursor.path()[v304_3_origin..v304_3_depth], &(*v304_3_arg_1), &((*v304_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v304_3_write,&((v305_4).read_zipper()),&[]);
        }
        v304_3_more = next_value_within(&mut v304_3_cursor,v304_3_origin);
      }
      drop(v304_3_cursor);
      drop(v304_3_write);
      compose(&(v302_8),&(v304_3))
    };
    let v303_6: Space = if (&(v302_14)).is_empty() { Space::new() } else {
      let v306_2: Path = concat_path(&(*p1),&v302_15_cursor.path()[v302_15_origin..(v302_15_origin + 1)]);
      let mut v306_5 = Space::new();
      let mut v306_5_write = v306_5.write_zipper();
      for v306_5_byte in v302_15_cursor.child_mask().iter() {
        v302_15_cursor.descend_to_existing_byte(v306_5_byte);
        {
        let v307_2: Space = routine_39(c, &v302_15_cursor.path()[(v302_15_origin + 1)..(v302_15_origin + 2)], &v302_15_cursor.path()[(v302_15_origin + 1)..(v302_15_origin + 2)], &(v306_2), &v302_15_cursor);
        join_wrapped_into(&mut v306_5_write,&((v307_2).read_zipper()),&[]);
        }
        v302_15_cursor.ascend(1);
      }
      drop(v306_5_write);
      drop(v306_2);
      compose(&(v302_14),&(v306_5))
    };
    let v303_7: Space = unite(&(v303_4),&(v303_6));
    join_wrapped_into(&mut v302_15_write,&((v303_7).read_zipper()),&[]);
    }
    v302_15_cursor.ascend(1);
  }
  drop(v302_15_cursor);
  drop(v302_15_write);
  drop(v302_8);
  drop(v302_14);
  (v302_15).clone()
}

fn routine_39(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v308_6: Space = singleton(&(*p1));
  let v308_7: Space = intersect(&(*CONSTANT_5),&(v308_6));
  let v308_8: Space = if has_head(&(v308_7)) { singleton(&[]) } else { Space::new() };
  drop(v308_7);
  let v308_9: Space = subtract(&(*CONSTANT_0),&(v308_8));
  drop(v308_8);
  let v308_20: Space = if (&(v308_9)).is_empty() { Space::new() } else {
    let v309_12: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v309_15: Space = if (&(v309_12)).is_empty() { Space::new() } else {
      let v310_14: Space = routine_52(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v309_12),&(v310_14))
    };
    drop(v309_12);
    let mut v309_18 = Space::new();
    let mut v309_18_write = v309_18.write_zipper();
    let mut v309_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v309_18_origin = v309_18_cursor.path().len();
    for v309_18_byte in v309_18_cursor.child_mask().iter() {
      v309_18_cursor.descend_to_existing_byte(v309_18_byte);
      {
      let v311_2_arg_0: &[u8] = &v309_18_cursor.path()[v309_18_origin..(v309_18_origin + 1)];
      let v311_2_arg_1: &[u8] = &(*p0);
      let v311_2_arg_2: &[u8] = &(*p2);
      let v311_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v311_2_more = v309_18_cursor.is_val() || next_value_within(&mut v309_18_cursor,(v309_18_origin + 1));
      while v311_2_more {
        {
        let v311_2_depth = v309_18_cursor.path().len();
        let mut v312_5_cursor = (*v311_2_arg_4).read_zipper();
        let v312_5_origin = v312_5_cursor.path().len();
        for v312_5_byte in v312_5_cursor.child_mask().iter() {
          v312_5_cursor.descend_to_existing_byte(v312_5_byte);
          {
          let v313_2: Path = concat_path(&(*v311_2_arg_1),&v312_5_cursor.path()[v312_5_origin..(v312_5_origin + 1)]);
          let v313_3: Space = routine_39(c, &(v313_2), &v309_18_cursor.path()[v309_18_origin..v311_2_depth], &(*v311_2_arg_2), &v312_5_cursor);
          drop(v313_2);
          join_wrapped_into(&mut v309_18_write,&((v313_3).read_zipper()),&[]);
          }
          v312_5_cursor.ascend(1);
        }
        drop(v312_5_cursor);
        }
        v311_2_more = next_value_within(&mut v309_18_cursor,(v309_18_origin + 1));
      }
      }
      v309_18_cursor.ascend(1);
    }
    drop(v309_18_cursor);
    drop(v309_18_write);
    let v309_19: Space = unite(&(v309_15),&(v309_18));
    compose(&(v308_9),&(v309_19))
  };
  drop(v308_9);
  let v308_22: Space = intersect(&(*CONSTANT_5),&(v308_6));
  drop(v308_6);
  let v308_23: Space = if has_head(&(v308_22)) { singleton(&[]) } else { Space::new() };
  drop(v308_22);
  let v308_28: Space = if (&(v308_23)).is_empty() { Space::new() } else {
    let mut v314_25 = Space::new();
    let mut v314_25_write = v314_25.write_zipper();
    let mut v314_25_cursor = (*s0).read_zipper();
    let v314_25_origin = v314_25_cursor.path().len();
    for v314_25_byte in v314_25_cursor.child_mask().iter() {
      v314_25_cursor.descend_to_existing_byte(v314_25_byte);
      {
      let v315_2: Space = routine_53(c, &v314_25_cursor.path()[v314_25_origin..(v314_25_origin + 1)], &v314_25_cursor.path()[v314_25_origin..(v314_25_origin + 1)], &v314_25_cursor);
      join_wrapped_into(&mut v314_25_write,&((v315_2).read_zipper()),&[]);
      }
      v314_25_cursor.ascend(1);
    }
    drop(v314_25_cursor);
    drop(v314_25_write);
    let v314_26: Space = raffine(&(*CONSTANT_20),&(v314_25));
    let v314_27: Space = unite(&(v314_26),&(*s0));
    compose(&(v308_23),&(v314_27))
  };
  drop(v308_23);
  let v308_29: Path = concat_path(&(*p2),&(*p0));
  let v308_30: Space = wrap(&(v308_28),&(v308_29));
  drop(v308_29);
  let v308_31: Space = unite(&(v308_20),&(v308_30));
  (v308_31).clone()
}

fn routine_40(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v316_7: Space = singleton(&(*p0));
  let v316_8: Space = intersect(&(*CONSTANT_5),&(v316_7));
  let v316_9: Space = if has_head(&(v316_8)) { singleton(&[]) } else { Space::new() };
  drop(v316_8);
  let v316_10: Space = subtract(&(*CONSTANT_0),&(v316_9));
  drop(v316_9);
  let v316_15: Space = intersect(&(*CONSTANT_5),&(v316_7));
  drop(v316_7);
  let v316_16: Space = if has_head(&(v316_15)) { singleton(&[]) } else { Space::new() };
  drop(v316_15);
  let mut v316_17 = Space::new();
  let mut v316_17_write = v316_17.write_zipper();
  let mut v316_17_cursor = (*s0).read_zipper();
  let v316_17_origin = v316_17_cursor.path().len();
  for v316_17_byte in v316_17_cursor.child_mask().iter() {
    v316_17_cursor.descend_to_existing_byte(v316_17_byte);
    {
    let v317_4: Space = if (&(v316_10)).is_empty() { Space::new() } else {
      let v318_2: Path = concat_path(&(*p1),&v316_17_cursor.path()[v316_17_origin..(v316_17_origin + 1)]);
      let mut v318_3 = Space::new();
      let mut v318_3_write = v318_3.write_zipper();
      let v318_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v318_3_arg_1: &[u8] = &(v318_2);
      let v318_3_arg_2: &[u8] = &(*p2);
      let v318_3_arg_4: &Space = &(&v316_17_cursor).make_map();
      let v318_3_arg_5: &Space = &(&(*s1)).make_map();
      let mut v318_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v318_3_origin = v318_3_cursor.path().len();
      let mut v318_3_more = v318_3_cursor.is_val() || next_value_within(&mut v318_3_cursor,v318_3_origin);
      while v318_3_more {
        {
        let v318_3_depth = v318_3_cursor.path().len();
        let v319_6: Space = routine_40(c, &v318_3_cursor.path()[v318_3_origin..v318_3_depth], &(*v318_3_arg_1), &(*v318_3_arg_2), &((*v318_3_arg_4).read_zipper()), &((*v318_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v318_3_write,&((v319_6).read_zipper()),&[]);
        }
        v318_3_more = next_value_within(&mut v318_3_cursor,v318_3_origin);
      }
      drop(v318_3_cursor);
      drop(v318_3_write);
      compose(&(v316_10),&(v318_3))
    };
    let v317_8: Space = if (&(v316_16)).is_empty() { Space::new() } else {
      let v320_2: Path = concat_path(&(*p1),&v316_17_cursor.path()[v316_17_origin..(v316_17_origin + 1)]);
      let v320_6: Space = wrap(&(descend_cursor(cursor_at(&v316_17_cursor,(v316_17_origin + 1)),&(*p2))),&(v320_2));
      drop(v320_2);
      let v320_7: Space = compose(&(v320_6),&(*s1));
      drop(v320_6);
      compose(&(v316_16),&(v320_7))
    };
    let v317_9: Space = unite(&(v317_4),&(v317_8));
    drop(v317_8);
    join_wrapped_into(&mut v316_17_write,&((v317_9).read_zipper()),&[]);
    }
    v316_17_cursor.ascend(1);
  }
  drop(v316_17_cursor);
  drop(v316_17_write);
  drop(v316_10);
  drop(v316_16);
  (v316_17).clone()
}

fn routine_41(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v321_5: Space = singleton(&(*p0));
  let v321_6: Space = intersect(&(*CONSTANT_5),&(v321_5));
  let v321_7: Space = if has_head(&(v321_6)) { singleton(&[]) } else { Space::new() };
  drop(v321_6);
  let v321_8: Space = subtract(&(*CONSTANT_0),&(v321_7));
  drop(v321_7);
  let v321_13: Space = intersect(&(*CONSTANT_5),&(v321_5));
  drop(v321_5);
  let v321_14: Space = if has_head(&(v321_13)) { singleton(&[]) } else { Space::new() };
  drop(v321_13);
  let mut v321_15 = Space::new();
  let mut v321_15_write = v321_15.write_zipper();
  let mut v321_15_cursor = (*s0).read_zipper();
  let v321_15_origin = v321_15_cursor.path().len();
  for v321_15_byte in v321_15_cursor.child_mask().iter() {
    v321_15_cursor.descend_to_existing_byte(v321_15_byte);
    {
    let v322_4: Space = if (&(v321_8)).is_empty() { Space::new() } else {
      let v323_2: Path = concat_path(&(*p1),&v321_15_cursor.path()[v321_15_origin..(v321_15_origin + 1)]);
      let mut v323_3 = Space::new();
      let mut v323_3_write = v323_3.write_zipper();
      let v323_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v323_3_arg_1: &[u8] = &(v323_2);
      let v323_3_arg_3: &Space = &(&v321_15_cursor).make_map();
      let mut v323_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v323_3_origin = v323_3_cursor.path().len();
      let mut v323_3_more = v323_3_cursor.is_val() || next_value_within(&mut v323_3_cursor,v323_3_origin);
      while v323_3_more {
        {
        let v323_3_depth = v323_3_cursor.path().len();
        let v324_4: Space = routine_41(c, &v323_3_cursor.path()[v323_3_origin..v323_3_depth], &(*v323_3_arg_1), &((*v323_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v323_3_write,&((v324_4).read_zipper()),&[]);
        }
        v323_3_more = next_value_within(&mut v323_3_cursor,v323_3_origin);
      }
      drop(v323_3_cursor);
      drop(v323_3_write);
      compose(&(v321_8),&(v323_3))
    };
    let v322_6: Space = if (&(v321_14)).is_empty() { Space::new() } else {
      let v325_2: Path = concat_path(&(*p1),&v321_15_cursor.path()[v321_15_origin..(v321_15_origin + 1)]);
      let mut v325_5 = Space::new();
      let mut v325_5_write = v325_5.write_zipper();
      for v325_5_byte in v321_15_cursor.child_mask().iter() {
        v321_15_cursor.descend_to_existing_byte(v325_5_byte);
        {
        let v326_2: Space = routine_42(c, &v321_15_cursor.path()[(v321_15_origin + 1)..(v321_15_origin + 2)], &v321_15_cursor.path()[(v321_15_origin + 1)..(v321_15_origin + 2)], &(v325_2), &v321_15_cursor);
        join_wrapped_into(&mut v325_5_write,&((v326_2).read_zipper()),&[]);
        }
        v321_15_cursor.ascend(1);
      }
      drop(v325_5_write);
      drop(v325_2);
      compose(&(v321_14),&(v325_5))
    };
    let v322_7: Space = unite(&(v322_4),&(v322_6));
    join_wrapped_into(&mut v321_15_write,&((v322_7).read_zipper()),&[]);
    }
    v321_15_cursor.ascend(1);
  }
  drop(v321_15_cursor);
  drop(v321_15_write);
  drop(v321_8);
  drop(v321_14);
  (v321_15).clone()
}

fn routine_42(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v327_6: Space = singleton(&(*p1));
  let v327_7: Space = intersect(&(*CONSTANT_5),&(v327_6));
  let v327_8: Space = if has_head(&(v327_7)) { singleton(&[]) } else { Space::new() };
  drop(v327_7);
  let v327_9: Space = subtract(&(*CONSTANT_0),&(v327_8));
  drop(v327_8);
  let v327_20: Space = if (&(v327_9)).is_empty() { Space::new() } else {
    let v328_12: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v328_15: Space = if (&(v328_12)).is_empty() { Space::new() } else {
      let v329_14: Space = routine_54(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v328_12),&(v329_14))
    };
    drop(v328_12);
    let mut v328_18 = Space::new();
    let mut v328_18_write = v328_18.write_zipper();
    let mut v328_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v328_18_origin = v328_18_cursor.path().len();
    for v328_18_byte in v328_18_cursor.child_mask().iter() {
      v328_18_cursor.descend_to_existing_byte(v328_18_byte);
      {
      let v330_2_arg_0: &[u8] = &v328_18_cursor.path()[v328_18_origin..(v328_18_origin + 1)];
      let v330_2_arg_1: &[u8] = &(*p0);
      let v330_2_arg_2: &[u8] = &(*p2);
      let v330_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v330_2_more = v328_18_cursor.is_val() || next_value_within(&mut v328_18_cursor,(v328_18_origin + 1));
      while v330_2_more {
        {
        let v330_2_depth = v328_18_cursor.path().len();
        let mut v331_5_cursor = (*v330_2_arg_4).read_zipper();
        let v331_5_origin = v331_5_cursor.path().len();
        for v331_5_byte in v331_5_cursor.child_mask().iter() {
          v331_5_cursor.descend_to_existing_byte(v331_5_byte);
          {
          let v332_2: Path = concat_path(&(*v330_2_arg_1),&v331_5_cursor.path()[v331_5_origin..(v331_5_origin + 1)]);
          let v332_3: Space = routine_42(c, &(v332_2), &v328_18_cursor.path()[v328_18_origin..v330_2_depth], &(*v330_2_arg_2), &v331_5_cursor);
          drop(v332_2);
          join_wrapped_into(&mut v328_18_write,&((v332_3).read_zipper()),&[]);
          }
          v331_5_cursor.ascend(1);
        }
        drop(v331_5_cursor);
        }
        v330_2_more = next_value_within(&mut v328_18_cursor,(v328_18_origin + 1));
      }
      }
      v328_18_cursor.ascend(1);
    }
    drop(v328_18_cursor);
    drop(v328_18_write);
    let v328_19: Space = unite(&(v328_15),&(v328_18));
    compose(&(v327_9),&(v328_19))
  };
  drop(v327_9);
  let v327_22: Space = intersect(&(*CONSTANT_5),&(v327_6));
  drop(v327_6);
  let v327_23: Space = if has_head(&(v327_22)) { singleton(&[]) } else { Space::new() };
  drop(v327_22);
  let v327_28: Space = if (&(v327_23)).is_empty() { Space::new() } else {
    let mut v333_25 = Space::new();
    let mut v333_25_write = v333_25.write_zipper();
    let mut v333_25_cursor = (*s0).read_zipper();
    let v333_25_origin = v333_25_cursor.path().len();
    for v333_25_byte in v333_25_cursor.child_mask().iter() {
      v333_25_cursor.descend_to_existing_byte(v333_25_byte);
      {
      let v334_2: Space = routine_55(c, &v333_25_cursor.path()[v333_25_origin..(v333_25_origin + 1)], &v333_25_cursor.path()[v333_25_origin..(v333_25_origin + 1)], &v333_25_cursor);
      join_wrapped_into(&mut v333_25_write,&((v334_2).read_zipper()),&[]);
      }
      v333_25_cursor.ascend(1);
    }
    drop(v333_25_cursor);
    drop(v333_25_write);
    let v333_26: Space = raffine(&(*CONSTANT_20),&(v333_25));
    let v333_27: Space = unite(&(v333_26),&(*s0));
    compose(&(v327_23),&(v333_27))
  };
  drop(v327_23);
  let v327_29: Path = concat_path(&(*p2),&(*p0));
  let v327_30: Space = wrap(&(v327_28),&(v327_29));
  drop(v327_29);
  let v327_31: Space = unite(&(v327_20),&(v327_30));
  (v327_31).clone()
}

fn routine_43(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v335_6: Space = singleton(&(*p0));
  let v335_7: Space = intersect(&(*CONSTANT_5),&(v335_6));
  let v335_8: Space = if has_head(&(v335_7)) { singleton(&[]) } else { Space::new() };
  drop(v335_7);
  let v335_9: Space = subtract(&(*CONSTANT_0),&(v335_8));
  drop(v335_8);
  let v335_14: Space = intersect(&(*CONSTANT_5),&(v335_6));
  drop(v335_6);
  let v335_15: Space = if has_head(&(v335_14)) { singleton(&[]) } else { Space::new() };
  drop(v335_14);
  let v335_21: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_12)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_12))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_13))))
  };
  let v335_24: Space = if (&(v335_21)).is_empty() { Space::new() } else {
    compose(&(v335_21),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_14))))
  };
  let v335_28: Space = if (&(v335_21)).is_empty() { Space::new() } else {
    compose(&(v335_21),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_15))))
  };
  drop(v335_21);
  let v335_30: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_13)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_13))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_15))))
  };
  let v335_31: Space = if (&(v335_30)).is_empty() { Space::new() } else {
    compose(&(v335_30),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_14))))
  };
  drop(v335_30);
  let v335_33: Space = if (&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_12)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_12))),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_15))))
  };
  let v335_34: Space = if (&(v335_33)).is_empty() { Space::new() } else {
    compose(&(v335_33),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_14))))
  };
  drop(v335_33);
  let mut v335_35 = Space::new();
  let mut v335_35_write = v335_35.write_zipper();
  let mut v335_35_cursor = (*s0).read_zipper();
  let v335_35_origin = v335_35_cursor.path().len();
  for v335_35_byte in v335_35_cursor.child_mask().iter() {
    v335_35_cursor.descend_to_existing_byte(v335_35_byte);
    {
    let v344_4: Space = if (&(v335_9)).is_empty() { Space::new() } else {
      let v345_2: Path = concat_path(&(*p1),&v335_35_cursor.path()[v335_35_origin..(v335_35_origin + 1)]);
      let mut v345_3 = Space::new();
      let mut v345_3_write = v345_3.write_zipper();
      let v345_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v345_3_arg_1: &[u8] = &(v345_2);
      let v345_3_arg_3: &Space = &(&v335_35_cursor).make_map();
      let v345_3_arg_4: &Space = &(&(*s1)).make_map();
      let mut v345_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v345_3_origin = v345_3_cursor.path().len();
      let mut v345_3_more = v345_3_cursor.is_val() || next_value_within(&mut v345_3_cursor,v345_3_origin);
      while v345_3_more {
        {
        let v345_3_depth = v345_3_cursor.path().len();
        let v346_5: Space = routine_43(c, &v345_3_cursor.path()[v345_3_origin..v345_3_depth], &(*v345_3_arg_1), &((*v345_3_arg_3).read_zipper()), &((*v345_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v345_3_write,&((v346_5).read_zipper()),&[]);
        }
        v345_3_more = next_value_within(&mut v345_3_cursor,v345_3_origin);
      }
      drop(v345_3_cursor);
      drop(v345_3_write);
      compose(&(v335_9),&(v345_3))
    };
    let v344_17: Space = if (&(v335_15)).is_empty() { Space::new() } else {
      let v347_2: Path = concat_path(&(*p1),&v335_35_cursor.path()[v335_35_origin..(v335_35_origin + 1)]);
      let v347_5: Space = singleton(&(v347_2));
      drop(v347_2);
      let v347_6: Space = intersect(&(*CONSTANT_7),&(v347_5));
      let v347_7: Space = compose(&(v347_6),&(v335_24));
      drop(v347_6);
      let v347_8: Space = intersect(&(*CONSTANT_8),&(v347_5));
      let v347_9: Space = compose(&(v347_8),&(v335_28));
      drop(v347_8);
      let v347_10: Space = unite(&(v347_7),&(v347_9));
      drop(v347_7);
      drop(v347_9);
      let v347_11: Space = intersect(&(*CONSTANT_9),&(v347_5));
      let v347_12: Space = compose(&(v347_11),&(v335_31));
      drop(v347_11);
      let v347_13: Space = unite(&(v347_10),&(v347_12));
      drop(v347_10);
      drop(v347_12);
      let v347_14: Space = intersect(&(*CONSTANT_10),&(v347_5));
      drop(v347_5);
      let v347_15: Space = compose(&(v347_14),&(v335_34));
      drop(v347_14);
      let v347_16: Space = unite(&(v347_13),&(v347_15));
      drop(v347_13);
      drop(v347_15);
      compose(&(v335_15),&(v347_16))
    };
    let v344_18: Space = unite(&(v344_4),&(v344_17));
    drop(v344_17);
    join_wrapped_into(&mut v335_35_write,&((v344_18).read_zipper()),&[]);
    }
    v335_35_cursor.ascend(1);
  }
  drop(v335_35_cursor);
  drop(v335_35_write);
  drop(v335_9);
  drop(v335_15);
  drop(v335_24);
  drop(v335_28);
  drop(v335_31);
  drop(v335_34);
  (v335_35).clone()
}

fn routine_44(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v348_6: Space = singleton(&(*p0));
  let v348_7: Space = intersect(&(*CONSTANT_5),&(v348_6));
  let v348_8: Space = if has_head(&(v348_7)) { singleton(&[]) } else { Space::new() };
  drop(v348_7);
  let v348_9: Space = subtract(&(*CONSTANT_0),&(v348_8));
  drop(v348_8);
  let v348_14: Space = intersect(&(*CONSTANT_5),&(v348_6));
  drop(v348_6);
  let v348_15: Space = if has_head(&(v348_14)) { singleton(&[]) } else { Space::new() };
  drop(v348_14);
  let mut v348_16 = Space::new();
  let mut v348_16_write = v348_16.write_zipper();
  let mut v348_16_cursor = (*s0).read_zipper();
  let v348_16_origin = v348_16_cursor.path().len();
  for v348_16_byte in v348_16_cursor.child_mask().iter() {
    v348_16_cursor.descend_to_existing_byte(v348_16_byte);
    {
    let v349_4: Space = if (&(v348_9)).is_empty() { Space::new() } else {
      let v350_2: Path = concat_path(&(*p1),&v348_16_cursor.path()[v348_16_origin..(v348_16_origin + 1)]);
      let mut v350_3 = Space::new();
      let mut v350_3_write = v350_3.write_zipper();
      let v350_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v350_3_arg_1: &[u8] = &(v350_2);
      let v350_3_arg_2: &[u8] = &(*p2);
      let v350_3_arg_4: &Space = &(&v348_16_cursor).make_map();
      let mut v350_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v350_3_origin = v350_3_cursor.path().len();
      let mut v350_3_more = v350_3_cursor.is_val() || next_value_within(&mut v350_3_cursor,v350_3_origin);
      while v350_3_more {
        {
        let v350_3_depth = v350_3_cursor.path().len();
        let v351_5: Space = routine_44(c, &v350_3_cursor.path()[v350_3_origin..v350_3_depth], &(*v350_3_arg_1), &(*v350_3_arg_2), &((*v350_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v350_3_write,&((v351_5).read_zipper()),&[]);
        }
        v350_3_more = next_value_within(&mut v350_3_cursor,v350_3_origin);
      }
      drop(v350_3_cursor);
      drop(v350_3_write);
      compose(&(v348_9),&(v350_3))
    };
    let v349_6: Space = if (&(v348_15)).is_empty() { Space::new() } else {
      let v352_2: Path = concat_path(&(*p1),&v348_16_cursor.path()[v348_16_origin..(v348_16_origin + 1)]);
      let mut v352_5 = Space::new();
      let mut v352_5_write = v352_5.write_zipper();
      for v352_5_byte in v348_16_cursor.child_mask().iter() {
        v348_16_cursor.descend_to_existing_byte(v352_5_byte);
        {
        let v353_2: Space = routine_28(c, &v348_16_cursor.path()[(v348_16_origin + 1)..(v348_16_origin + 2)], &v348_16_cursor.path()[(v348_16_origin + 1)..(v348_16_origin + 2)], &(*p2), &(v352_2), &v348_16_cursor);
        join_wrapped_into(&mut v352_5_write,&((v353_2).read_zipper()),&[]);
        }
        v348_16_cursor.ascend(1);
      }
      drop(v352_5_write);
      drop(v352_2);
      compose(&(v348_15),&(v352_5))
    };
    let v349_7: Space = unite(&(v349_4),&(v349_6));
    join_wrapped_into(&mut v348_16_write,&((v349_7).read_zipper()),&[]);
    }
    v348_16_cursor.ascend(1);
  }
  drop(v348_16_cursor);
  drop(v348_16_write);
  drop(v348_9);
  drop(v348_15);
  (v348_16).clone()
}

fn routine_45(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v354_7: Space = singleton(&(*p0));
  let v354_8: Space = intersect(&(*CONSTANT_5),&(v354_7));
  let v354_9: Space = if has_head(&(v354_8)) { singleton(&[]) } else { Space::new() };
  drop(v354_8);
  let v354_10: Space = subtract(&(*CONSTANT_0),&(v354_9));
  drop(v354_9);
  let v354_15: Space = intersect(&(*CONSTANT_5),&(v354_7));
  drop(v354_7);
  let v354_16: Space = if has_head(&(v354_15)) { singleton(&[]) } else { Space::new() };
  drop(v354_15);
  let v354_20: Path = concat_path(&(*CONSTANT_12),&(*p2));
  let v354_21: Space = singleton(&(v354_20));
  drop(v354_20);
  let v354_23: Path = concat_path(&(*CONSTANT_13),&(*p3));
  let v354_24: Space = singleton(&(v354_23));
  drop(v354_23);
  let mut v354_25 = Space::new();
  let mut v354_25_write = v354_25.write_zipper();
  let mut v354_25_cursor = (*s0).read_zipper();
  let v354_25_origin = v354_25_cursor.path().len();
  for v354_25_byte in v354_25_cursor.child_mask().iter() {
    v354_25_cursor.descend_to_existing_byte(v354_25_byte);
    {
    let v355_4: Space = if (&(v354_10)).is_empty() { Space::new() } else {
      let v356_2: Path = concat_path(&(*p1),&v354_25_cursor.path()[v354_25_origin..(v354_25_origin + 1)]);
      let mut v356_3 = Space::new();
      let mut v356_3_write = v356_3.write_zipper();
      let v356_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v356_3_arg_1: &[u8] = &(v356_2);
      let v356_3_arg_2: &[u8] = &(*p2);
      let v356_3_arg_3: &[u8] = &(*p3);
      let v356_3_arg_5: &Space = &(&v354_25_cursor).make_map();
      let mut v356_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v356_3_origin = v356_3_cursor.path().len();
      let mut v356_3_more = v356_3_cursor.is_val() || next_value_within(&mut v356_3_cursor,v356_3_origin);
      while v356_3_more {
        {
        let v356_3_depth = v356_3_cursor.path().len();
        let v357_6: Space = routine_45(c, &v356_3_cursor.path()[v356_3_origin..v356_3_depth], &(*v356_3_arg_1), &(*v356_3_arg_2), &(*v356_3_arg_3), &((*v356_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v356_3_write,&((v357_6).read_zipper()),&[]);
        }
        v356_3_more = next_value_within(&mut v356_3_cursor,v356_3_origin);
      }
      drop(v356_3_cursor);
      drop(v356_3_write);
      compose(&(v354_10),&(v356_3))
    };
    let v355_10: Space = if (&(v354_16)).is_empty() { Space::new() } else {
      let v358_2: Path = concat_path(&(*p1),&v354_25_cursor.path()[v354_25_origin..(v354_25_origin + 1)]);
      let v358_5: Path = concat_path(&(*CONSTANT_14),&(v358_2));
      drop(v358_2);
      let v358_6: Space = singleton(&(v358_5));
      drop(v358_5);
      let v358_7: Space = unite(&(*CONSTANT_16),&(v358_6));
      drop(v358_6);
      let v358_8: Space = unite(&(v358_7),&(v354_21));
      drop(v358_7);
      let v358_9: Space = unite(&(v358_8),&(v354_24));
      drop(v358_8);
      compose(&(v354_16),&(v358_9))
    };
    let v355_11: Space = unite(&(v355_4),&(v355_10));
    drop(v355_10);
    join_wrapped_into(&mut v354_25_write,&((v355_11).read_zipper()),&[]);
    }
    v354_25_cursor.ascend(1);
  }
  drop(v354_25_cursor);
  drop(v354_25_write);
  drop(v354_10);
  drop(v354_16);
  drop(v354_21);
  drop(v354_24);
  (v354_25).clone()
}

fn routine_46(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v359_6: Space = singleton(&(*p0));
  let v359_7: Space = intersect(&(*CONSTANT_5),&(v359_6));
  let v359_8: Space = if has_head(&(v359_7)) { singleton(&[]) } else { Space::new() };
  drop(v359_7);
  let v359_9: Space = subtract(&(*CONSTANT_0),&(v359_8));
  drop(v359_8);
  let v359_14: Space = intersect(&(*CONSTANT_5),&(v359_6));
  drop(v359_6);
  let v359_15: Space = if has_head(&(v359_14)) { singleton(&[]) } else { Space::new() };
  drop(v359_14);
  let mut v359_16 = Space::new();
  let mut v359_16_write = v359_16.write_zipper();
  let mut v359_16_cursor = (*s0).read_zipper();
  let v359_16_origin = v359_16_cursor.path().len();
  for v359_16_byte in v359_16_cursor.child_mask().iter() {
    v359_16_cursor.descend_to_existing_byte(v359_16_byte);
    {
    let v360_4: Space = if (&(v359_9)).is_empty() { Space::new() } else {
      let v361_2: Path = concat_path(&(*p1),&v359_16_cursor.path()[v359_16_origin..(v359_16_origin + 1)]);
      let mut v361_3 = Space::new();
      let mut v361_3_write = v361_3.write_zipper();
      let v361_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v361_3_arg_1: &[u8] = &(v361_2);
      let v361_3_arg_2: &[u8] = &(*p2);
      let v361_3_arg_4: &Space = &(&v359_16_cursor).make_map();
      let mut v361_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v361_3_origin = v361_3_cursor.path().len();
      let mut v361_3_more = v361_3_cursor.is_val() || next_value_within(&mut v361_3_cursor,v361_3_origin);
      while v361_3_more {
        {
        let v361_3_depth = v361_3_cursor.path().len();
        let v362_5: Space = routine_46(c, &v361_3_cursor.path()[v361_3_origin..v361_3_depth], &(*v361_3_arg_1), &(*v361_3_arg_2), &((*v361_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v361_3_write,&((v362_5).read_zipper()),&[]);
        }
        v361_3_more = next_value_within(&mut v361_3_cursor,v361_3_origin);
      }
      drop(v361_3_cursor);
      drop(v361_3_write);
      compose(&(v359_9),&(v361_3))
    };
    let v360_6: Space = if (&(v359_15)).is_empty() { Space::new() } else {
      let v363_2: Path = concat_path(&(*p1),&v359_16_cursor.path()[v359_16_origin..(v359_16_origin + 1)]);
      let mut v363_5 = Space::new();
      let mut v363_5_write = v363_5.write_zipper();
      for v363_5_byte in v359_16_cursor.child_mask().iter() {
        v359_16_cursor.descend_to_existing_byte(v363_5_byte);
        {
        let v364_2: Space = routine_31(c, &v359_16_cursor.path()[(v359_16_origin + 1)..(v359_16_origin + 2)], &v359_16_cursor.path()[(v359_16_origin + 1)..(v359_16_origin + 2)], &(*p2), &(v363_2), &v359_16_cursor);
        join_wrapped_into(&mut v363_5_write,&((v364_2).read_zipper()),&[]);
        }
        v359_16_cursor.ascend(1);
      }
      drop(v363_5_write);
      drop(v363_2);
      compose(&(v359_15),&(v363_5))
    };
    let v360_7: Space = unite(&(v360_4),&(v360_6));
    join_wrapped_into(&mut v359_16_write,&((v360_7).read_zipper()),&[]);
    }
    v359_16_cursor.ascend(1);
  }
  drop(v359_16_cursor);
  drop(v359_16_write);
  drop(v359_9);
  drop(v359_15);
  (v359_16).clone()
}

fn routine_47(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v365_7: Space = singleton(&(*p0));
  let v365_8: Space = intersect(&(*CONSTANT_5),&(v365_7));
  let v365_9: Space = if has_head(&(v365_8)) { singleton(&[]) } else { Space::new() };
  drop(v365_8);
  let v365_10: Space = subtract(&(*CONSTANT_0),&(v365_9));
  drop(v365_9);
  let v365_15: Space = intersect(&(*CONSTANT_5),&(v365_7));
  drop(v365_7);
  let v365_16: Space = if has_head(&(v365_15)) { singleton(&[]) } else { Space::new() };
  drop(v365_15);
  let v365_20: Path = concat_path(&(*CONSTANT_12),&(*p2));
  let v365_21: Space = singleton(&(v365_20));
  drop(v365_20);
  let v365_23: Path = concat_path(&(*CONSTANT_13),&(*p3));
  let v365_24: Space = singleton(&(v365_23));
  drop(v365_23);
  let mut v365_25 = Space::new();
  let mut v365_25_write = v365_25.write_zipper();
  let mut v365_25_cursor = (*s0).read_zipper();
  let v365_25_origin = v365_25_cursor.path().len();
  for v365_25_byte in v365_25_cursor.child_mask().iter() {
    v365_25_cursor.descend_to_existing_byte(v365_25_byte);
    {
    let v366_4: Space = if (&(v365_10)).is_empty() { Space::new() } else {
      let v367_2: Path = concat_path(&(*p1),&v365_25_cursor.path()[v365_25_origin..(v365_25_origin + 1)]);
      let mut v367_3 = Space::new();
      let mut v367_3_write = v367_3.write_zipper();
      let v367_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v367_3_arg_1: &[u8] = &(v367_2);
      let v367_3_arg_2: &[u8] = &(*p2);
      let v367_3_arg_3: &[u8] = &(*p3);
      let v367_3_arg_5: &Space = &(&v365_25_cursor).make_map();
      let mut v367_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v367_3_origin = v367_3_cursor.path().len();
      let mut v367_3_more = v367_3_cursor.is_val() || next_value_within(&mut v367_3_cursor,v367_3_origin);
      while v367_3_more {
        {
        let v367_3_depth = v367_3_cursor.path().len();
        let v368_6: Space = routine_47(c, &v367_3_cursor.path()[v367_3_origin..v367_3_depth], &(*v367_3_arg_1), &(*v367_3_arg_2), &(*v367_3_arg_3), &((*v367_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v367_3_write,&((v368_6).read_zipper()),&[]);
        }
        v367_3_more = next_value_within(&mut v367_3_cursor,v367_3_origin);
      }
      drop(v367_3_cursor);
      drop(v367_3_write);
      compose(&(v365_10),&(v367_3))
    };
    let v366_10: Space = if (&(v365_16)).is_empty() { Space::new() } else {
      let v369_2: Path = concat_path(&(*p1),&v365_25_cursor.path()[v365_25_origin..(v365_25_origin + 1)]);
      let v369_5: Path = concat_path(&(*CONSTANT_15),&(v369_2));
      drop(v369_2);
      let v369_6: Space = singleton(&(v369_5));
      drop(v369_5);
      let v369_7: Space = unite(&(*CONSTANT_17),&(v369_6));
      drop(v369_6);
      let v369_8: Space = unite(&(v369_7),&(v365_21));
      drop(v369_7);
      let v369_9: Space = unite(&(v369_8),&(v365_24));
      drop(v369_8);
      compose(&(v365_16),&(v369_9))
    };
    let v366_11: Space = unite(&(v366_4),&(v366_10));
    drop(v366_10);
    join_wrapped_into(&mut v365_25_write,&((v366_11).read_zipper()),&[]);
    }
    v365_25_cursor.ascend(1);
  }
  drop(v365_25_cursor);
  drop(v365_25_write);
  drop(v365_10);
  drop(v365_16);
  drop(v365_21);
  drop(v365_24);
  (v365_25).clone()
}

fn routine_48(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v370_6: Space = singleton(&(*p0));
  let v370_7: Space = intersect(&(*CONSTANT_5),&(v370_6));
  let v370_8: Space = if has_head(&(v370_7)) { singleton(&[]) } else { Space::new() };
  drop(v370_7);
  let v370_9: Space = subtract(&(*CONSTANT_0),&(v370_8));
  drop(v370_8);
  let v370_14: Space = intersect(&(*CONSTANT_5),&(v370_6));
  drop(v370_6);
  let v370_15: Space = if has_head(&(v370_14)) { singleton(&[]) } else { Space::new() };
  drop(v370_14);
  let mut v370_16 = Space::new();
  let mut v370_16_write = v370_16.write_zipper();
  let mut v370_16_cursor = (*s0).read_zipper();
  let v370_16_origin = v370_16_cursor.path().len();
  for v370_16_byte in v370_16_cursor.child_mask().iter() {
    v370_16_cursor.descend_to_existing_byte(v370_16_byte);
    {
    let v371_4: Space = if (&(v370_9)).is_empty() { Space::new() } else {
      let v372_2: Path = concat_path(&(*p1),&v370_16_cursor.path()[v370_16_origin..(v370_16_origin + 1)]);
      let mut v372_3 = Space::new();
      let mut v372_3_write = v372_3.write_zipper();
      let v372_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v372_3_arg_1: &[u8] = &(v372_2);
      let v372_3_arg_2: &[u8] = &(*p2);
      let v372_3_arg_4: &Space = &(&v370_16_cursor).make_map();
      let mut v372_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v372_3_origin = v372_3_cursor.path().len();
      let mut v372_3_more = v372_3_cursor.is_val() || next_value_within(&mut v372_3_cursor,v372_3_origin);
      while v372_3_more {
        {
        let v372_3_depth = v372_3_cursor.path().len();
        let v373_5: Space = routine_48(c, &v372_3_cursor.path()[v372_3_origin..v372_3_depth], &(*v372_3_arg_1), &(*v372_3_arg_2), &((*v372_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v372_3_write,&((v373_5).read_zipper()),&[]);
        }
        v372_3_more = next_value_within(&mut v372_3_cursor,v372_3_origin);
      }
      drop(v372_3_cursor);
      drop(v372_3_write);
      compose(&(v370_9),&(v372_3))
    };
    let v371_6: Space = if (&(v370_15)).is_empty() { Space::new() } else {
      let v374_2: Path = concat_path(&(*p1),&v370_16_cursor.path()[v370_16_origin..(v370_16_origin + 1)]);
      let mut v374_5 = Space::new();
      let mut v374_5_write = v374_5.write_zipper();
      for v374_5_byte in v370_16_cursor.child_mask().iter() {
        v370_16_cursor.descend_to_existing_byte(v374_5_byte);
        {
        let v375_2: Space = routine_34(c, &v370_16_cursor.path()[(v370_16_origin + 1)..(v370_16_origin + 2)], &v370_16_cursor.path()[(v370_16_origin + 1)..(v370_16_origin + 2)], &(*p2), &(v374_2), &v370_16_cursor);
        join_wrapped_into(&mut v374_5_write,&((v375_2).read_zipper()),&[]);
        }
        v370_16_cursor.ascend(1);
      }
      drop(v374_5_write);
      drop(v374_2);
      compose(&(v370_15),&(v374_5))
    };
    let v371_7: Space = unite(&(v371_4),&(v371_6));
    join_wrapped_into(&mut v370_16_write,&((v371_7).read_zipper()),&[]);
    }
    v370_16_cursor.ascend(1);
  }
  drop(v370_16_cursor);
  drop(v370_16_write);
  drop(v370_9);
  drop(v370_15);
  (v370_16).clone()
}

fn routine_49(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v376_7: Space = singleton(&(*p0));
  let v376_8: Space = intersect(&(*CONSTANT_5),&(v376_7));
  let v376_9: Space = if has_head(&(v376_8)) { singleton(&[]) } else { Space::new() };
  drop(v376_8);
  let v376_10: Space = subtract(&(*CONSTANT_0),&(v376_9));
  drop(v376_9);
  let v376_15: Space = intersect(&(*CONSTANT_5),&(v376_7));
  drop(v376_7);
  let v376_16: Space = if has_head(&(v376_15)) { singleton(&[]) } else { Space::new() };
  drop(v376_15);
  let v376_19: Path = concat_path(&(*CONSTANT_15),&(*p3));
  let v376_20: Space = singleton(&(v376_19));
  drop(v376_19);
  let v376_21: Space = unite(&(*CONSTANT_18),&(v376_20));
  drop(v376_20);
  let v376_24: Path = concat_path(&(*CONSTANT_13),&(*p2));
  let v376_25: Space = singleton(&(v376_24));
  drop(v376_24);
  let mut v376_26 = Space::new();
  let mut v376_26_write = v376_26.write_zipper();
  let mut v376_26_cursor = (*s0).read_zipper();
  let v376_26_origin = v376_26_cursor.path().len();
  for v376_26_byte in v376_26_cursor.child_mask().iter() {
    v376_26_cursor.descend_to_existing_byte(v376_26_byte);
    {
    let v377_4: Space = if (&(v376_10)).is_empty() { Space::new() } else {
      let v378_2: Path = concat_path(&(*p1),&v376_26_cursor.path()[v376_26_origin..(v376_26_origin + 1)]);
      let mut v378_3 = Space::new();
      let mut v378_3_write = v378_3.write_zipper();
      let v378_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v378_3_arg_1: &[u8] = &(v378_2);
      let v378_3_arg_2: &[u8] = &(*p2);
      let v378_3_arg_3: &[u8] = &(*p3);
      let v378_3_arg_5: &Space = &(&v376_26_cursor).make_map();
      let mut v378_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v378_3_origin = v378_3_cursor.path().len();
      let mut v378_3_more = v378_3_cursor.is_val() || next_value_within(&mut v378_3_cursor,v378_3_origin);
      while v378_3_more {
        {
        let v378_3_depth = v378_3_cursor.path().len();
        let v379_6: Space = routine_49(c, &v378_3_cursor.path()[v378_3_origin..v378_3_depth], &(*v378_3_arg_1), &(*v378_3_arg_2), &(*v378_3_arg_3), &((*v378_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v378_3_write,&((v379_6).read_zipper()),&[]);
        }
        v378_3_more = next_value_within(&mut v378_3_cursor,v378_3_origin);
      }
      drop(v378_3_cursor);
      drop(v378_3_write);
      compose(&(v376_10),&(v378_3))
    };
    let v377_9: Space = if (&(v376_16)).is_empty() { Space::new() } else {
      let v380_2: Path = concat_path(&(*p1),&v376_26_cursor.path()[v376_26_origin..(v376_26_origin + 1)]);
      let v380_5: Path = concat_path(&(*CONSTANT_14),&(v380_2));
      drop(v380_2);
      let v380_6: Space = singleton(&(v380_5));
      drop(v380_5);
      let v380_7: Space = unite(&(v376_21),&(v380_6));
      drop(v380_6);
      let v380_8: Space = unite(&(v380_7),&(v376_25));
      drop(v380_7);
      compose(&(v376_16),&(v380_8))
    };
    let v377_10: Space = unite(&(v377_4),&(v377_9));
    drop(v377_9);
    join_wrapped_into(&mut v376_26_write,&((v377_10).read_zipper()),&[]);
    }
    v376_26_cursor.ascend(1);
  }
  drop(v376_26_cursor);
  drop(v376_26_write);
  drop(v376_10);
  drop(v376_16);
  drop(v376_21);
  drop(v376_25);
  (v376_26).clone()
}

fn routine_50(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v381_6: Space = singleton(&(*p0));
  let v381_7: Space = intersect(&(*CONSTANT_5),&(v381_6));
  let v381_8: Space = if has_head(&(v381_7)) { singleton(&[]) } else { Space::new() };
  drop(v381_7);
  let v381_9: Space = subtract(&(*CONSTANT_0),&(v381_8));
  drop(v381_8);
  let v381_14: Space = intersect(&(*CONSTANT_5),&(v381_6));
  drop(v381_6);
  let v381_15: Space = if has_head(&(v381_14)) { singleton(&[]) } else { Space::new() };
  drop(v381_14);
  let mut v381_16 = Space::new();
  let mut v381_16_write = v381_16.write_zipper();
  let mut v381_16_cursor = (*s0).read_zipper();
  let v381_16_origin = v381_16_cursor.path().len();
  for v381_16_byte in v381_16_cursor.child_mask().iter() {
    v381_16_cursor.descend_to_existing_byte(v381_16_byte);
    {
    let v382_4: Space = if (&(v381_9)).is_empty() { Space::new() } else {
      let v383_2: Path = concat_path(&(*p1),&v381_16_cursor.path()[v381_16_origin..(v381_16_origin + 1)]);
      let mut v383_3 = Space::new();
      let mut v383_3_write = v383_3.write_zipper();
      let v383_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v383_3_arg_1: &[u8] = &(v383_2);
      let v383_3_arg_2: &[u8] = &(*p2);
      let v383_3_arg_4: &Space = &(&v381_16_cursor).make_map();
      let mut v383_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v383_3_origin = v383_3_cursor.path().len();
      let mut v383_3_more = v383_3_cursor.is_val() || next_value_within(&mut v383_3_cursor,v383_3_origin);
      while v383_3_more {
        {
        let v383_3_depth = v383_3_cursor.path().len();
        let v384_5: Space = routine_50(c, &v383_3_cursor.path()[v383_3_origin..v383_3_depth], &(*v383_3_arg_1), &(*v383_3_arg_2), &((*v383_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v383_3_write,&((v384_5).read_zipper()),&[]);
        }
        v383_3_more = next_value_within(&mut v383_3_cursor,v383_3_origin);
      }
      drop(v383_3_cursor);
      drop(v383_3_write);
      compose(&(v381_9),&(v383_3))
    };
    let v382_6: Space = if (&(v381_15)).is_empty() { Space::new() } else {
      let v385_2: Path = concat_path(&(*p1),&v381_16_cursor.path()[v381_16_origin..(v381_16_origin + 1)]);
      let mut v385_5 = Space::new();
      let mut v385_5_write = v385_5.write_zipper();
      for v385_5_byte in v381_16_cursor.child_mask().iter() {
        v381_16_cursor.descend_to_existing_byte(v385_5_byte);
        {
        let v386_2: Space = routine_37(c, &v381_16_cursor.path()[(v381_16_origin + 1)..(v381_16_origin + 2)], &v381_16_cursor.path()[(v381_16_origin + 1)..(v381_16_origin + 2)], &(*p2), &(v385_2), &v381_16_cursor);
        join_wrapped_into(&mut v385_5_write,&((v386_2).read_zipper()),&[]);
        }
        v381_16_cursor.ascend(1);
      }
      drop(v385_5_write);
      drop(v385_2);
      compose(&(v381_15),&(v385_5))
    };
    let v382_7: Space = unite(&(v382_4),&(v382_6));
    join_wrapped_into(&mut v381_16_write,&((v382_7).read_zipper()),&[]);
    }
    v381_16_cursor.ascend(1);
  }
  drop(v381_16_cursor);
  drop(v381_16_write);
  drop(v381_9);
  drop(v381_15);
  (v381_16).clone()
}

fn routine_51(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v387_7: Space = singleton(&(*p0));
  let v387_8: Space = intersect(&(*CONSTANT_5),&(v387_7));
  let v387_9: Space = if has_head(&(v387_8)) { singleton(&[]) } else { Space::new() };
  drop(v387_8);
  let v387_10: Space = subtract(&(*CONSTANT_0),&(v387_9));
  drop(v387_9);
  let v387_15: Space = intersect(&(*CONSTANT_5),&(v387_7));
  drop(v387_7);
  let v387_16: Space = if has_head(&(v387_15)) { singleton(&[]) } else { Space::new() };
  drop(v387_15);
  let v387_19: Path = concat_path(&(*CONSTANT_15),&(*p3));
  let v387_20: Space = singleton(&(v387_19));
  drop(v387_19);
  let v387_21: Space = unite(&(*CONSTANT_19),&(v387_20));
  drop(v387_20);
  let v387_24: Path = concat_path(&(*CONSTANT_12),&(*p2));
  let v387_25: Space = singleton(&(v387_24));
  drop(v387_24);
  let mut v387_26 = Space::new();
  let mut v387_26_write = v387_26.write_zipper();
  let mut v387_26_cursor = (*s0).read_zipper();
  let v387_26_origin = v387_26_cursor.path().len();
  for v387_26_byte in v387_26_cursor.child_mask().iter() {
    v387_26_cursor.descend_to_existing_byte(v387_26_byte);
    {
    let v388_4: Space = if (&(v387_10)).is_empty() { Space::new() } else {
      let v389_2: Path = concat_path(&(*p1),&v387_26_cursor.path()[v387_26_origin..(v387_26_origin + 1)]);
      let mut v389_3 = Space::new();
      let mut v389_3_write = v389_3.write_zipper();
      let v389_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v389_3_arg_1: &[u8] = &(v389_2);
      let v389_3_arg_2: &[u8] = &(*p2);
      let v389_3_arg_3: &[u8] = &(*p3);
      let v389_3_arg_5: &Space = &(&v387_26_cursor).make_map();
      let mut v389_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v389_3_origin = v389_3_cursor.path().len();
      let mut v389_3_more = v389_3_cursor.is_val() || next_value_within(&mut v389_3_cursor,v389_3_origin);
      while v389_3_more {
        {
        let v389_3_depth = v389_3_cursor.path().len();
        let v390_6: Space = routine_51(c, &v389_3_cursor.path()[v389_3_origin..v389_3_depth], &(*v389_3_arg_1), &(*v389_3_arg_2), &(*v389_3_arg_3), &((*v389_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v389_3_write,&((v390_6).read_zipper()),&[]);
        }
        v389_3_more = next_value_within(&mut v389_3_cursor,v389_3_origin);
      }
      drop(v389_3_cursor);
      drop(v389_3_write);
      compose(&(v387_10),&(v389_3))
    };
    let v388_9: Space = if (&(v387_16)).is_empty() { Space::new() } else {
      let v391_2: Path = concat_path(&(*p1),&v387_26_cursor.path()[v387_26_origin..(v387_26_origin + 1)]);
      let v391_5: Path = concat_path(&(*CONSTANT_14),&(v391_2));
      drop(v391_2);
      let v391_6: Space = singleton(&(v391_5));
      drop(v391_5);
      let v391_7: Space = unite(&(v387_21),&(v391_6));
      drop(v391_6);
      let v391_8: Space = unite(&(v391_7),&(v387_25));
      drop(v391_7);
      compose(&(v387_16),&(v391_8))
    };
    let v388_10: Space = unite(&(v388_4),&(v388_9));
    drop(v388_9);
    join_wrapped_into(&mut v387_26_write,&((v388_10).read_zipper()),&[]);
    }
    v387_26_cursor.ascend(1);
  }
  drop(v387_26_cursor);
  drop(v387_26_write);
  drop(v387_10);
  drop(v387_16);
  drop(v387_21);
  drop(v387_25);
  (v387_26).clone()
}

fn routine_52(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v392_6: Space = singleton(&(*p0));
  let v392_7: Space = intersect(&(*CONSTANT_5),&(v392_6));
  let v392_8: Space = if has_head(&(v392_7)) { singleton(&[]) } else { Space::new() };
  drop(v392_7);
  let v392_9: Space = subtract(&(*CONSTANT_0),&(v392_8));
  drop(v392_8);
  let v392_14: Space = intersect(&(*CONSTANT_5),&(v392_6));
  drop(v392_6);
  let v392_15: Space = if has_head(&(v392_14)) { singleton(&[]) } else { Space::new() };
  drop(v392_14);
  let mut v392_17 = Space::new();
  let mut v392_17_write = v392_17.write_zipper();
  let mut v392_17_cursor = (*s0).read_zipper();
  let v392_17_origin = v392_17_cursor.path().len();
  for v392_17_byte in v392_17_cursor.child_mask().iter() {
    v392_17_cursor.descend_to_existing_byte(v392_17_byte);
    {
    let v393_4: Space = if (&(v392_9)).is_empty() { Space::new() } else {
      let v394_2: Path = concat_path(&(*p1),&v392_17_cursor.path()[v392_17_origin..(v392_17_origin + 1)]);
      let mut v394_3 = Space::new();
      let mut v394_3_write = v394_3.write_zipper();
      let v394_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v394_3_arg_1: &[u8] = &(v394_2);
      let v394_3_arg_2: &[u8] = &(*p2);
      let v394_3_arg_4: &Space = &(&v392_17_cursor).make_map();
      let mut v394_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v394_3_origin = v394_3_cursor.path().len();
      let mut v394_3_more = v394_3_cursor.is_val() || next_value_within(&mut v394_3_cursor,v394_3_origin);
      while v394_3_more {
        {
        let v394_3_depth = v394_3_cursor.path().len();
        let v395_5: Space = routine_52(c, &v394_3_cursor.path()[v394_3_origin..v394_3_depth], &(*v394_3_arg_1), &(*v394_3_arg_2), &((*v394_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v394_3_write,&((v395_5).read_zipper()),&[]);
        }
        v394_3_more = next_value_within(&mut v394_3_cursor,v394_3_origin);
      }
      drop(v394_3_cursor);
      drop(v394_3_write);
      compose(&(v392_9),&(v394_3))
    };
    let v393_8: Space = if (&(v392_15)).is_empty() { Space::new() } else {
      let mut v396_5 = Space::new();
      let mut v396_5_write = v396_5.write_zipper();
      for v396_5_byte in v392_17_cursor.child_mask().iter() {
        v392_17_cursor.descend_to_existing_byte(v396_5_byte);
        {
        let v397_2: Space = routine_53(c, &v392_17_cursor.path()[(v392_17_origin + 1)..(v392_17_origin + 2)], &v392_17_cursor.path()[(v392_17_origin + 1)..(v392_17_origin + 2)], &v392_17_cursor);
        join_wrapped_into(&mut v396_5_write,&((v397_2).read_zipper()),&[]);
        }
        v392_17_cursor.ascend(1);
      }
      drop(v396_5_write);
      let v396_6: Space = raffine(&(*CONSTANT_20),&(v396_5));
      let v396_7: Space = unite(&(v396_6),&v392_17_cursor);
      compose(&(v392_15),&(v396_7))
    };
    let v398_2: Path = concat_path(&(*p1),&v392_17_cursor.path()[v392_17_origin..(v392_17_origin + 1)]);
    let v393_9: Path = concat_path(&(*p2),&(v398_2));
    let v393_10: Space = wrap(&(v393_8),&(v393_9));
    drop(v393_9);
    let v393_11: Space = unite(&(v393_4),&(v393_10));
    join_wrapped_into(&mut v392_17_write,&((v393_11).read_zipper()),&[]);
    }
    v392_17_cursor.ascend(1);
  }
  drop(v392_17_cursor);
  drop(v392_17_write);
  drop(v392_9);
  drop(v392_15);
  (v392_17).clone()
}

fn routine_53(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v399_5: Space = singleton(&(*p1));
  let v399_6: Space = intersect(&(*CONSTANT_5),&(v399_5));
  let v399_7: Space = if has_head(&(v399_6)) { singleton(&[]) } else { Space::new() };
  drop(v399_6);
  let v399_8: Space = subtract(&(*CONSTANT_0),&(v399_7));
  drop(v399_7);
  let v399_19: Space = if (&(v399_8)).is_empty() { Space::new() } else {
    let v400_11: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v400_14: Space = if (&(v400_11)).is_empty() { Space::new() } else {
      let v401_13: Space = routine_56(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v400_11),&(v401_13))
    };
    drop(v400_11);
    let mut v400_17 = Space::new();
    let mut v400_17_write = v400_17.write_zipper();
    let mut v400_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v400_17_origin = v400_17_cursor.path().len();
    for v400_17_byte in v400_17_cursor.child_mask().iter() {
      v400_17_cursor.descend_to_existing_byte(v400_17_byte);
      {
      let v402_2_arg_0: &[u8] = &v400_17_cursor.path()[v400_17_origin..(v400_17_origin + 1)];
      let v402_2_arg_1: &[u8] = &(*p0);
      let v402_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v402_2_more = v400_17_cursor.is_val() || next_value_within(&mut v400_17_cursor,(v400_17_origin + 1));
      while v402_2_more {
        {
        let v402_2_depth = v400_17_cursor.path().len();
        let mut v403_4_cursor = (*v402_2_arg_3).read_zipper();
        let v403_4_origin = v403_4_cursor.path().len();
        for v403_4_byte in v403_4_cursor.child_mask().iter() {
          v403_4_cursor.descend_to_existing_byte(v403_4_byte);
          {
          let v404_2: Path = concat_path(&(*v402_2_arg_1),&v403_4_cursor.path()[v403_4_origin..(v403_4_origin + 1)]);
          let v404_3: Space = routine_53(c, &(v404_2), &v400_17_cursor.path()[v400_17_origin..v402_2_depth], &v403_4_cursor);
          drop(v404_2);
          join_wrapped_into(&mut v400_17_write,&((v404_3).read_zipper()),&[]);
          }
          v403_4_cursor.ascend(1);
        }
        drop(v403_4_cursor);
        }
        v402_2_more = next_value_within(&mut v400_17_cursor,(v400_17_origin + 1));
      }
      }
      v400_17_cursor.ascend(1);
    }
    drop(v400_17_cursor);
    drop(v400_17_write);
    let v400_18: Space = unite(&(v400_14),&(v400_17));
    compose(&(v399_8),&(v400_18))
  };
  drop(v399_8);
  let v399_21: Space = intersect(&(*CONSTANT_5),&(v399_5));
  drop(v399_5);
  let v399_22: Space = if has_head(&(v399_21)) { singleton(&[]) } else { Space::new() };
  drop(v399_21);
  let v399_24: Space = if (&(v399_22)).is_empty() { Space::new() } else {
    let v405_23: Space = singleton(&(*p0));
    compose(&(v399_22),&(v405_23))
  };
  drop(v399_22);
  let v399_25: Space = unite(&(v399_19),&(v399_24));
  drop(v399_24);
  (v399_25).clone()
}

fn routine_54(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v406_6: Space = singleton(&(*p0));
  let v406_7: Space = intersect(&(*CONSTANT_5),&(v406_6));
  let v406_8: Space = if has_head(&(v406_7)) { singleton(&[]) } else { Space::new() };
  drop(v406_7);
  let v406_9: Space = subtract(&(*CONSTANT_0),&(v406_8));
  drop(v406_8);
  let v406_14: Space = intersect(&(*CONSTANT_5),&(v406_6));
  drop(v406_6);
  let v406_15: Space = if has_head(&(v406_14)) { singleton(&[]) } else { Space::new() };
  drop(v406_14);
  let mut v406_17 = Space::new();
  let mut v406_17_write = v406_17.write_zipper();
  let mut v406_17_cursor = (*s0).read_zipper();
  let v406_17_origin = v406_17_cursor.path().len();
  for v406_17_byte in v406_17_cursor.child_mask().iter() {
    v406_17_cursor.descend_to_existing_byte(v406_17_byte);
    {
    let v407_4: Space = if (&(v406_9)).is_empty() { Space::new() } else {
      let v408_2: Path = concat_path(&(*p1),&v406_17_cursor.path()[v406_17_origin..(v406_17_origin + 1)]);
      let mut v408_3 = Space::new();
      let mut v408_3_write = v408_3.write_zipper();
      let v408_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v408_3_arg_1: &[u8] = &(v408_2);
      let v408_3_arg_2: &[u8] = &(*p2);
      let v408_3_arg_4: &Space = &(&v406_17_cursor).make_map();
      let mut v408_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v408_3_origin = v408_3_cursor.path().len();
      let mut v408_3_more = v408_3_cursor.is_val() || next_value_within(&mut v408_3_cursor,v408_3_origin);
      while v408_3_more {
        {
        let v408_3_depth = v408_3_cursor.path().len();
        let v409_5: Space = routine_54(c, &v408_3_cursor.path()[v408_3_origin..v408_3_depth], &(*v408_3_arg_1), &(*v408_3_arg_2), &((*v408_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v408_3_write,&((v409_5).read_zipper()),&[]);
        }
        v408_3_more = next_value_within(&mut v408_3_cursor,v408_3_origin);
      }
      drop(v408_3_cursor);
      drop(v408_3_write);
      compose(&(v406_9),&(v408_3))
    };
    let v407_8: Space = if (&(v406_15)).is_empty() { Space::new() } else {
      let mut v410_5 = Space::new();
      let mut v410_5_write = v410_5.write_zipper();
      for v410_5_byte in v406_17_cursor.child_mask().iter() {
        v406_17_cursor.descend_to_existing_byte(v410_5_byte);
        {
        let v411_2: Space = routine_55(c, &v406_17_cursor.path()[(v406_17_origin + 1)..(v406_17_origin + 2)], &v406_17_cursor.path()[(v406_17_origin + 1)..(v406_17_origin + 2)], &v406_17_cursor);
        join_wrapped_into(&mut v410_5_write,&((v411_2).read_zipper()),&[]);
        }
        v406_17_cursor.ascend(1);
      }
      drop(v410_5_write);
      let v410_6: Space = raffine(&(*CONSTANT_20),&(v410_5));
      let v410_7: Space = unite(&(v410_6),&v406_17_cursor);
      compose(&(v406_15),&(v410_7))
    };
    let v412_2: Path = concat_path(&(*p1),&v406_17_cursor.path()[v406_17_origin..(v406_17_origin + 1)]);
    let v407_9: Path = concat_path(&(*p2),&(v412_2));
    let v407_10: Space = wrap(&(v407_8),&(v407_9));
    drop(v407_9);
    let v407_11: Space = unite(&(v407_4),&(v407_10));
    join_wrapped_into(&mut v406_17_write,&((v407_11).read_zipper()),&[]);
    }
    v406_17_cursor.ascend(1);
  }
  drop(v406_17_cursor);
  drop(v406_17_write);
  drop(v406_9);
  drop(v406_15);
  (v406_17).clone()
}

fn routine_55(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v413_5: Space = singleton(&(*p1));
  let v413_6: Space = intersect(&(*CONSTANT_5),&(v413_5));
  let v413_7: Space = if has_head(&(v413_6)) { singleton(&[]) } else { Space::new() };
  drop(v413_6);
  let v413_8: Space = subtract(&(*CONSTANT_0),&(v413_7));
  drop(v413_7);
  let v413_19: Space = if (&(v413_8)).is_empty() { Space::new() } else {
    let v414_11: Space = first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v414_14: Space = if (&(v414_11)).is_empty() { Space::new() } else {
      let v415_13: Space = routine_57(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v414_11),&(v415_13))
    };
    drop(v414_11);
    let mut v414_17 = Space::new();
    let mut v414_17_write = v414_17.write_zipper();
    let mut v414_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v414_17_origin = v414_17_cursor.path().len();
    for v414_17_byte in v414_17_cursor.child_mask().iter() {
      v414_17_cursor.descend_to_existing_byte(v414_17_byte);
      {
      let v416_2_arg_0: &[u8] = &v414_17_cursor.path()[v414_17_origin..(v414_17_origin + 1)];
      let v416_2_arg_1: &[u8] = &(*p0);
      let v416_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v416_2_more = v414_17_cursor.is_val() || next_value_within(&mut v414_17_cursor,(v414_17_origin + 1));
      while v416_2_more {
        {
        let v416_2_depth = v414_17_cursor.path().len();
        let mut v417_4_cursor = (*v416_2_arg_3).read_zipper();
        let v417_4_origin = v417_4_cursor.path().len();
        for v417_4_byte in v417_4_cursor.child_mask().iter() {
          v417_4_cursor.descend_to_existing_byte(v417_4_byte);
          {
          let v418_2: Path = concat_path(&(*v416_2_arg_1),&v417_4_cursor.path()[v417_4_origin..(v417_4_origin + 1)]);
          let v418_3: Space = routine_55(c, &(v418_2), &v414_17_cursor.path()[v414_17_origin..v416_2_depth], &v417_4_cursor);
          drop(v418_2);
          join_wrapped_into(&mut v414_17_write,&((v418_3).read_zipper()),&[]);
          }
          v417_4_cursor.ascend(1);
        }
        drop(v417_4_cursor);
        }
        v416_2_more = next_value_within(&mut v414_17_cursor,(v414_17_origin + 1));
      }
      }
      v414_17_cursor.ascend(1);
    }
    drop(v414_17_cursor);
    drop(v414_17_write);
    let v414_18: Space = unite(&(v414_14),&(v414_17));
    compose(&(v413_8),&(v414_18))
  };
  drop(v413_8);
  let v413_21: Space = intersect(&(*CONSTANT_5),&(v413_5));
  drop(v413_5);
  let v413_22: Space = if has_head(&(v413_21)) { singleton(&[]) } else { Space::new() };
  drop(v413_21);
  let v413_24: Space = if (&(v413_22)).is_empty() { Space::new() } else {
    let v419_23: Space = singleton(&(*p0));
    compose(&(v413_22),&(v419_23))
  };
  drop(v413_22);
  let v413_25: Space = unite(&(v413_19),&(v413_24));
  drop(v413_24);
  (v413_25).clone()
}

fn routine_56(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v420_5: Space = singleton(&(*p0));
  let v420_6: Space = intersect(&(*CONSTANT_5),&(v420_5));
  let v420_7: Space = if has_head(&(v420_6)) { singleton(&[]) } else { Space::new() };
  drop(v420_6);
  let v420_8: Space = subtract(&(*CONSTANT_0),&(v420_7));
  drop(v420_7);
  let v420_13: Space = intersect(&(*CONSTANT_5),&(v420_5));
  drop(v420_5);
  let v420_14: Space = if has_head(&(v420_13)) { singleton(&[]) } else { Space::new() };
  drop(v420_13);
  let mut v420_15 = Space::new();
  let mut v420_15_write = v420_15.write_zipper();
  let mut v420_15_cursor = (*s0).read_zipper();
  let v420_15_origin = v420_15_cursor.path().len();
  for v420_15_byte in v420_15_cursor.child_mask().iter() {
    v420_15_cursor.descend_to_existing_byte(v420_15_byte);
    {
    let v421_4: Space = if (&(v420_8)).is_empty() { Space::new() } else {
      let v422_2: Path = concat_path(&(*p1),&v420_15_cursor.path()[v420_15_origin..(v420_15_origin + 1)]);
      let mut v422_3 = Space::new();
      let mut v422_3_write = v422_3.write_zipper();
      let v422_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v422_3_arg_1: &[u8] = &(v422_2);
      let v422_3_arg_3: &Space = &(&v420_15_cursor).make_map();
      let mut v422_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v422_3_origin = v422_3_cursor.path().len();
      let mut v422_3_more = v422_3_cursor.is_val() || next_value_within(&mut v422_3_cursor,v422_3_origin);
      while v422_3_more {
        {
        let v422_3_depth = v422_3_cursor.path().len();
        let v423_4: Space = routine_56(c, &v422_3_cursor.path()[v422_3_origin..v422_3_depth], &(*v422_3_arg_1), &((*v422_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v422_3_write,&((v423_4).read_zipper()),&[]);
        }
        v422_3_more = next_value_within(&mut v422_3_cursor,v422_3_origin);
      }
      drop(v422_3_cursor);
      drop(v422_3_write);
      compose(&(v420_8),&(v422_3))
    };
    let v421_6: Space = if (&(v420_14)).is_empty() { Space::new() } else {
      let v424_2: Path = concat_path(&(*p1),&v420_15_cursor.path()[v420_15_origin..(v420_15_origin + 1)]);
      let v424_5: Space = singleton(&(v424_2));
      drop(v424_2);
      compose(&(v420_14),&(v424_5))
    };
    let v421_7: Space = unite(&(v421_4),&(v421_6));
    drop(v421_6);
    join_wrapped_into(&mut v420_15_write,&((v421_7).read_zipper()),&[]);
    }
    v420_15_cursor.ascend(1);
  }
  drop(v420_15_cursor);
  drop(v420_15_write);
  drop(v420_8);
  drop(v420_14);
  (v420_15).clone()
}

fn routine_57(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v425_5: Space = singleton(&(*p0));
  let v425_6: Space = intersect(&(*CONSTANT_5),&(v425_5));
  let v425_7: Space = if has_head(&(v425_6)) { singleton(&[]) } else { Space::new() };
  drop(v425_6);
  let v425_8: Space = subtract(&(*CONSTANT_0),&(v425_7));
  drop(v425_7);
  let v425_13: Space = intersect(&(*CONSTANT_5),&(v425_5));
  drop(v425_5);
  let v425_14: Space = if has_head(&(v425_13)) { singleton(&[]) } else { Space::new() };
  drop(v425_13);
  let mut v425_15 = Space::new();
  let mut v425_15_write = v425_15.write_zipper();
  let mut v425_15_cursor = (*s0).read_zipper();
  let v425_15_origin = v425_15_cursor.path().len();
  for v425_15_byte in v425_15_cursor.child_mask().iter() {
    v425_15_cursor.descend_to_existing_byte(v425_15_byte);
    {
    let v426_4: Space = if (&(v425_8)).is_empty() { Space::new() } else {
      let v427_2: Path = concat_path(&(*p1),&v425_15_cursor.path()[v425_15_origin..(v425_15_origin + 1)]);
      let mut v427_3 = Space::new();
      let mut v427_3_write = v427_3.write_zipper();
      let v427_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v427_3_arg_1: &[u8] = &(v427_2);
      let v427_3_arg_3: &Space = &(&v425_15_cursor).make_map();
      let mut v427_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v427_3_origin = v427_3_cursor.path().len();
      let mut v427_3_more = v427_3_cursor.is_val() || next_value_within(&mut v427_3_cursor,v427_3_origin);
      while v427_3_more {
        {
        let v427_3_depth = v427_3_cursor.path().len();
        let v428_4: Space = routine_57(c, &v427_3_cursor.path()[v427_3_origin..v427_3_depth], &(*v427_3_arg_1), &((*v427_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v427_3_write,&((v428_4).read_zipper()),&[]);
        }
        v427_3_more = next_value_within(&mut v427_3_cursor,v427_3_origin);
      }
      drop(v427_3_cursor);
      drop(v427_3_write);
      compose(&(v425_8),&(v427_3))
    };
    let v426_6: Space = if (&(v425_14)).is_empty() { Space::new() } else {
      let v429_2: Path = concat_path(&(*p1),&v425_15_cursor.path()[v425_15_origin..(v425_15_origin + 1)]);
      let v429_5: Space = singleton(&(v429_2));
      drop(v429_2);
      compose(&(v425_14),&(v429_5))
    };
    let v426_7: Space = unite(&(v426_4),&(v426_6));
    drop(v426_6);
    join_wrapped_into(&mut v425_15_write,&((v426_7).read_zipper()),&[]);
    }
    v425_15_cursor.ascend(1);
  }
  drop(v425_15_cursor);
  drop(v425_15_write);
  drop(v425_8);
  drop(v425_14);
  (v425_15).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
