#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 28 0 0 0 5 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 1 20 0 0 0 5 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1 16 0 0 0 5 0 0 0 0 0 0 0 1 0 0 0 1 24 0 0 0 5 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 1 16 0 0 0 5 0 0 0 1 0 0 0 0 0 0 0 1 12 0 0 0 5 0 0 0 1 0 0 0 1"));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = restrict_to(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  (v0_2).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
