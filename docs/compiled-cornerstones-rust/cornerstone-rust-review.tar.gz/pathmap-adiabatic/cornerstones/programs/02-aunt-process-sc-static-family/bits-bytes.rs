#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 8 0 0 0 1 1 0 1 1 8 0 1 0 1 1 0 1 1 9 0 1 0 1 1 1 0 1 1 8 0 1 1 1 0 0 1 1 5 0 1 1 1 1 9 1 0 0 1 1 0 0 1 1"));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 9 0 0 1 1 1 0 0 1 1 8 0 1 1 0 0 0 1 1 8 0 1 1 0 1 0 1 1 8 1 0 0 1 1 0 1 1 9 1 0 1 1 0 1 0 1 1 5 1 1 0 1 1"));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 5 0 0 0 1 1 5 1 0 0 1 1 4 1 0 1 1 2 1 1"));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_10 = Space::new();
  let mut v0_10_write = v0_10.write_zipper();
  let mut v0_10_cursor = (*s0.expect("unbound native input")).read_zipper();
  let v0_10_origin = v0_10_cursor.path().len();
  for v0_10_byte in v0_10_cursor.child_mask().iter() {
    v0_10_cursor.descend_to_existing_byte(v0_10_byte);
    {
    let v1_2: Space = singleton(&v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 1)]);
    let v1_3: Space = intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (&(v1_5)).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_write = v2_6.write_zipper();
      for v2_6_byte in v0_10_cursor.child_mask().iter() {
        v0_10_cursor.descend_to_existing_byte(v2_6_byte);
        {
        let v3_2: Space = singleton(&v0_10_cursor.path()[(v0_10_origin + 1)..(v0_10_origin + 2)]);
        let v3_3: Space = intersect(&(*CONSTANT_1),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_0),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (&(v3_5)).is_empty() { Space::new() } else {
          let v4_7: Space = routine_1(c, &v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 2)], &v0_10_cursor);
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_1),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (&(v3_10)).is_empty() { Space::new() } else {
          let v5_11: Space = routine_2(c, &v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 2)], &v0_10_cursor);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        join_wrapped_into(&mut v2_6_write,&((v3_13).read_zipper()),&[]);
        }
        v0_10_cursor.ascend(1);
      }
      drop(v2_6_write);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (&(v1_9)).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_write = v6_10.write_zipper();
      for v6_10_byte in v0_10_cursor.child_mask().iter() {
        v0_10_cursor.descend_to_existing_byte(v6_10_byte);
        {
        let v7_2: Space = singleton(&v0_10_cursor.path()[(v0_10_origin + 1)..(v0_10_origin + 2)]);
        let v7_3: Space = intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (&(v7_5)).is_empty() { Space::new() } else {
          let v8_7: Space = routine_1(c, &v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 2)], &v0_10_cursor);
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (&(v7_10)).is_empty() { Space::new() } else {
          let v9_11: Space = routine_3(c, &v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 2)], &v0_10_cursor);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        join_wrapped_into(&mut v6_10_write,&((v7_13).read_zipper()),&[]);
        }
        v0_10_cursor.ascend(1);
      }
      drop(v6_10_write);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    join_wrapped_into(&mut v0_10_write,&((v1_12).read_zipper()),&[]);
    }
    v0_10_cursor.ascend(1);
  }
  drop(v0_10_cursor);
  drop(v0_10_write);
  let v0_12: Space = wrap(&(v0_10),&(*CONSTANT_2));
  (v0_12).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v10_33 = Space::new();
  let mut v10_33_write = v10_33.write_zipper();
  let mut v10_33_cursor = (*s0).read_zipper();
  let v10_33_origin = v10_33_cursor.path().len();
  for v10_33_byte in v10_33_cursor.child_mask().iter() {
    v10_33_cursor.descend_to_existing_byte(v10_33_byte);
    {
    let v11_2: Space = singleton(&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]);
    let v11_3: Space = intersect(&(*CONSTANT_1),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (&(v11_5)).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]);
      let mut v12_7 = Space::new();
      let mut v12_7_write = v12_7.write_zipper();
      for v12_7_byte in v10_33_cursor.child_mask().iter() {
        v10_33_cursor.descend_to_existing_byte(v12_7_byte);
        {
        let v13_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
        let v13_3: Space = intersect(&(*CONSTANT_1),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_0),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (&(v13_5)).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v12_6),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
          let mut v14_7 = Space::new();
          let mut v14_7_write = v14_7.write_zipper();
          for v14_7_byte in v10_33_cursor.child_mask().iter() {
            v10_33_cursor.descend_to_existing_byte(v14_7_byte);
            {
            let v15_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
            let v15_3: Space = intersect(&(*CONSTANT_1),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (&(v15_5)).is_empty() { Space::new() } else {
              let v16_6: Path = concat_path(&(v14_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v16_7: Space = routine_4(c, &(v16_6), &v10_33_cursor);
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_1),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (&(v15_10)).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v14_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v17_11: Space = routine_5(c, &(v17_6), &v10_33_cursor);
              drop(v17_6);
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            join_wrapped_into(&mut v14_7_write,&((v15_13).read_zipper()),&[]);
            }
            v10_33_cursor.ascend(1);
          }
          drop(v14_7_write);
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_1),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (&(v13_10)).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v12_6),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
          let mut v18_11 = Space::new();
          let mut v18_11_write = v18_11.write_zipper();
          for v18_11_byte in v10_33_cursor.child_mask().iter() {
            v10_33_cursor.descend_to_existing_byte(v18_11_byte);
            {
            let v19_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
            let v19_3: Space = intersect(&(*CONSTANT_1),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
            drop(v19_4);
            let v19_8: Space = if (&(v19_5)).is_empty() { Space::new() } else {
              let v20_6: Path = concat_path(&(v18_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v20_7: Space = routine_4(c, &(v20_6), &v10_33_cursor);
              compose(&(v19_5),&(v20_7))
            };
            drop(v19_5);
            let v19_9: Space = intersect(&(*CONSTANT_1),&(v19_2));
            drop(v19_2);
            let v19_10: Space = if has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
            drop(v19_9);
            let v19_12: Space = if (&(v19_10)).is_empty() { Space::new() } else {
              let v21_6: Path = concat_path(&(v18_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v21_11: Space = routine_3(c, &(v21_6), &v10_33_cursor);
              drop(v21_6);
              compose(&(v19_10),&(v21_11))
            };
            drop(v19_10);
            let v19_13: Space = unite(&(v19_8),&(v19_12));
            join_wrapped_into(&mut v18_11_write,&((v19_13).read_zipper()),&[]);
            }
            v10_33_cursor.ascend(1);
          }
          drop(v18_11_write);
          drop(v18_6);
          compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        join_wrapped_into(&mut v12_7_write,&((v13_13).read_zipper()),&[]);
        }
        v10_33_cursor.ascend(1);
      }
      drop(v12_7_write);
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_1),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_14: Space = if (&(v11_10)).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]);
      let mut v22_13 = Space::new();
      let mut v22_13_write = v22_13.write_zipper();
      for v22_13_byte in v10_33_cursor.child_mask().iter() {
        v10_33_cursor.descend_to_existing_byte(v22_13_byte);
        {
        let v23_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
        let v23_3: Space = intersect(&(*CONSTANT_1),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_0),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (&(v23_5)).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v22_6),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
          let mut v24_7 = Space::new();
          let mut v24_7_write = v24_7.write_zipper();
          for v24_7_byte in v10_33_cursor.child_mask().iter() {
            v10_33_cursor.descend_to_existing_byte(v24_7_byte);
            {
            let v25_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
            let v25_3: Space = intersect(&(*CONSTANT_1),&(v25_2));
            let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
            drop(v25_3);
            let v25_5: Space = subtract(&(*CONSTANT_0),&(v25_4));
            drop(v25_4);
            let v25_8: Space = if (&(v25_5)).is_empty() { Space::new() } else {
              let v26_6: Path = concat_path(&(v24_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v26_7: Space = routine_4(c, &(v26_6), &v10_33_cursor);
              compose(&(v25_5),&(v26_7))
            };
            drop(v25_5);
            let v25_9: Space = intersect(&(*CONSTANT_1),&(v25_2));
            drop(v25_2);
            let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
            drop(v25_9);
            let v25_12: Space = if (&(v25_10)).is_empty() { Space::new() } else {
              let v27_6: Path = concat_path(&(v24_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v27_11: Space = routine_5(c, &(v27_6), &v10_33_cursor);
              drop(v27_6);
              compose(&(v25_10),&(v27_11))
            };
            drop(v25_10);
            let v25_13: Space = unite(&(v25_8),&(v25_12));
            join_wrapped_into(&mut v24_7_write,&((v25_13).read_zipper()),&[]);
            }
            v10_33_cursor.ascend(1);
          }
          drop(v24_7_write);
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_1),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_19: Space = if (&(v23_10)).is_empty() { Space::new() } else {
          let v28_12: Space = restrict_to(&(*CONSTANT_4),&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)])));
          let mut v28_13 = Space::new();
          let mut v28_13_write = v28_13.write_zipper();
          let mut v28_13_cursor = (v28_12).read_zipper();
          let v28_13_origin = v28_13_cursor.path().len();
          for v28_13_byte in v28_13_cursor.child_mask().iter() {
            v28_13_cursor.descend_to_existing_byte(v28_13_byte);
            {
            let v29_2: Space = singleton(&v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)]);
            let v29_3: Space = intersect(&(*CONSTANT_1),&(v29_2));
            let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
            drop(v29_3);
            let v29_5: Space = subtract(&(*CONSTANT_0),&(v29_4));
            drop(v29_4);
            let v29_7: Space = if (&(v29_5)).is_empty() { Space::new() } else {
              let v30_6: Space = routine_6(c, &v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)], &v28_13_cursor);
              compose(&(v29_5),&(v30_6))
            };
            drop(v29_5);
            let v29_8: Space = intersect(&(*CONSTANT_1),&(v29_2));
            drop(v29_2);
            let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
            drop(v29_8);
            let v29_11: Space = if (&(v29_9)).is_empty() { Space::new() } else {
              let v31_10: Space = routine_7(c, &v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)], &v28_13_cursor);
              compose(&(v29_9),&(v31_10))
            };
            drop(v29_9);
            let v29_12: Space = unite(&(v29_7),&(v29_11));
            join_wrapped_into(&mut v28_13_write,&((v29_12).read_zipper()),&[]);
            }
            v28_13_cursor.ascend(1);
          }
          drop(v28_13_cursor);
          drop(v28_13_write);
          drop(v28_12);
          let v28_14: Space = restrict_to(&(*CONSTANT_3),&(v28_13));
          let mut v28_15 = Space::new();
          let mut v28_15_write = v28_15.write_zipper();
          let mut v28_15_cursor = (v28_14).read_zipper();
          let v28_15_origin = v28_15_cursor.path().len();
          for v28_15_byte in v28_15_cursor.child_mask().iter() {
            v28_15_cursor.descend_to_existing_byte(v28_15_byte);
            {
            let v32_2: Space = singleton(&v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)]);
            let v32_3: Space = intersect(&(*CONSTANT_1),&(v32_2));
            let v32_4: Space = if has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
            drop(v32_3);
            let v32_5: Space = subtract(&(*CONSTANT_0),&(v32_4));
            drop(v32_4);
            let v32_7: Space = if (&(v32_5)).is_empty() { Space::new() } else {
              let v33_6: Space = routine_8(c, &v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)], &v28_15_cursor);
              compose(&(v32_5),&(v33_6))
            };
            drop(v32_5);
            let v32_8: Space = intersect(&(*CONSTANT_1),&(v32_2));
            drop(v32_2);
            let v32_9: Space = if has_head(&(v32_8)) { singleton(&[]) } else { Space::new() };
            drop(v32_8);
            let v32_11: Space = if (&(v32_9)).is_empty() { Space::new() } else {
              let v34_10: Space = routine_9(c, &v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)], &v28_15_cursor);
              compose(&(v32_9),&(v34_10))
            };
            drop(v32_9);
            let v32_12: Space = unite(&(v32_7),&(v32_11));
            join_wrapped_into(&mut v28_15_write,&((v32_12).read_zipper()),&[]);
            }
            v28_15_cursor.ascend(1);
          }
          drop(v28_15_cursor);
          drop(v28_15_write);
          let v28_17: Space = subtract(&(v28_15),&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)])));
          let v28_18: Space = intersect(&(v28_17),&(*CONSTANT_5));
          compose(&(v23_10),&(v28_18))
        };
        drop(v23_10);
        let v35_6: Path = concat_path(&(v22_6),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
        let v23_20: Space = wrap(&(v23_19),&(v35_6));
        let v23_21: Space = unite(&(v23_8),&(v23_20));
        join_wrapped_into(&mut v22_13_write,&((v23_21).read_zipper()),&[]);
        }
        v10_33_cursor.ascend(1);
      }
      drop(v22_13_write);
      drop(v22_6);
      compose(&(v11_10),&(v22_13))
    };
    drop(v11_10);
    let v11_15: Space = unite(&(v11_8),&(v11_14));
    join_wrapped_into(&mut v10_33_write,&((v11_15).read_zipper()),&[]);
    }
    v10_33_cursor.ascend(1);
  }
  drop(v10_33_cursor);
  drop(v10_33_write);
  (v10_33).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v36_39 = Space::new();
  let mut v36_39_write = v36_39.write_zipper();
  let mut v36_39_cursor = (*s0).read_zipper();
  let v36_39_origin = v36_39_cursor.path().len();
  for v36_39_byte in v36_39_cursor.child_mask().iter() {
    v36_39_cursor.descend_to_existing_byte(v36_39_byte);
    {
    let v37_2: Space = singleton(&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)]);
    let v37_3: Space = intersect(&(*CONSTANT_1),&(v37_2));
    let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
    drop(v37_3);
    let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
    drop(v37_4);
    let v37_8: Space = if (&(v37_5)).is_empty() { Space::new() } else {
      let v38_6: Path = concat_path(&(*p0),&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)]);
      let mut v38_7 = Space::new();
      let mut v38_7_write = v38_7.write_zipper();
      for v38_7_byte in v36_39_cursor.child_mask().iter() {
        v36_39_cursor.descend_to_existing_byte(v38_7_byte);
        {
        let v39_2: Space = singleton(&v36_39_cursor.path()[(v36_39_origin + 1)..(v36_39_origin + 2)]);
        let v39_3: Space = intersect(&(*CONSTANT_1),&(v39_2));
        let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_8: Space = if (&(v39_5)).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v38_6),&v36_39_cursor.path()[(v36_39_origin + 1)..(v36_39_origin + 2)]);
          let mut v40_7 = Space::new();
          let mut v40_7_write = v40_7.write_zipper();
          for v40_7_byte in v36_39_cursor.child_mask().iter() {
            v36_39_cursor.descend_to_existing_byte(v40_7_byte);
            {
            let v41_2: Space = singleton(&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
            let v41_3: Space = intersect(&(*CONSTANT_1),&(v41_2));
            let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
            drop(v41_4);
            let v41_8: Space = if (&(v41_5)).is_empty() { Space::new() } else {
              let v42_6: Path = concat_path(&(v40_6),&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
              let v42_7: Space = routine_4(c, &(v42_6), &v36_39_cursor);
              compose(&(v41_5),&(v42_7))
            };
            drop(v41_5);
            let v41_9: Space = intersect(&(*CONSTANT_1),&(v41_2));
            drop(v41_2);
            let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
            drop(v41_9);
            let v41_12: Space = if (&(v41_10)).is_empty() { Space::new() } else {
              let v43_6: Path = concat_path(&(v40_6),&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
              let v43_11: Space = routine_5(c, &(v43_6), &v36_39_cursor);
              drop(v43_6);
              compose(&(v41_10),&(v43_11))
            };
            drop(v41_10);
            let v41_13: Space = unite(&(v41_8),&(v41_12));
            join_wrapped_into(&mut v40_7_write,&((v41_13).read_zipper()),&[]);
            }
            v36_39_cursor.ascend(1);
          }
          drop(v40_7_write);
          compose(&(v39_5),&(v40_7))
        };
        drop(v39_5);
        let v39_9: Space = intersect(&(*CONSTANT_1),&(v39_2));
        drop(v39_2);
        let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
        drop(v39_9);
        let v39_12: Space = if (&(v39_10)).is_empty() { Space::new() } else {
          let v44_6: Path = concat_path(&(v38_6),&v36_39_cursor.path()[(v36_39_origin + 1)..(v36_39_origin + 2)]);
          let mut v44_11 = Space::new();
          let mut v44_11_write = v44_11.write_zipper();
          for v44_11_byte in v36_39_cursor.child_mask().iter() {
            v36_39_cursor.descend_to_existing_byte(v44_11_byte);
            {
            let v45_2: Space = singleton(&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
            let v45_3: Space = intersect(&(*CONSTANT_1),&(v45_2));
            let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
            drop(v45_3);
            let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
            drop(v45_4);
            let v45_8: Space = if (&(v45_5)).is_empty() { Space::new() } else {
              let v46_6: Path = concat_path(&(v44_6),&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
              let v46_7: Space = routine_4(c, &(v46_6), &v36_39_cursor);
              compose(&(v45_5),&(v46_7))
            };
            drop(v45_5);
            let v45_9: Space = intersect(&(*CONSTANT_1),&(v45_2));
            drop(v45_2);
            let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
            drop(v45_9);
            let v45_12: Space = if (&(v45_10)).is_empty() { Space::new() } else {
              let v47_6: Path = concat_path(&(v44_6),&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
              let v47_11: Space = routine_3(c, &(v47_6), &v36_39_cursor);
              drop(v47_6);
              compose(&(v45_10),&(v47_11))
            };
            drop(v45_10);
            let v45_13: Space = unite(&(v45_8),&(v45_12));
            join_wrapped_into(&mut v44_11_write,&((v45_13).read_zipper()),&[]);
            }
            v36_39_cursor.ascend(1);
          }
          drop(v44_11_write);
          drop(v44_6);
          compose(&(v39_10),&(v44_11))
        };
        drop(v39_10);
        let v39_13: Space = unite(&(v39_8),&(v39_12));
        join_wrapped_into(&mut v38_7_write,&((v39_13).read_zipper()),&[]);
        }
        v36_39_cursor.ascend(1);
      }
      drop(v38_7_write);
      compose(&(v37_5),&(v38_7))
    };
    drop(v37_5);
    let v37_9: Space = intersect(&(*CONSTANT_1),&(v37_2));
    drop(v37_2);
    let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
    drop(v37_9);
    let v37_19: Space = if (&(v37_10)).is_empty() { Space::new() } else {
      let v48_12: Space = restrict_to(&(*CONSTANT_4),&(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)])));
      let mut v48_13 = Space::new();
      let mut v48_13_write = v48_13.write_zipper();
      let mut v48_13_cursor = (v48_12).read_zipper();
      let v48_13_origin = v48_13_cursor.path().len();
      for v48_13_byte in v48_13_cursor.child_mask().iter() {
        v48_13_cursor.descend_to_existing_byte(v48_13_byte);
        {
        let v49_2: Space = singleton(&v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 1)]);
        let v49_3: Space = intersect(&(*CONSTANT_1),&(v49_2));
        let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
        drop(v49_3);
        let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
        drop(v49_4);
        let v49_7: Space = if (&(v49_5)).is_empty() { Space::new() } else {
          let mut v50_6 = Space::new();
          let mut v50_6_write = v50_6.write_zipper();
          for v50_6_byte in v48_13_cursor.child_mask().iter() {
            v48_13_cursor.descend_to_existing_byte(v50_6_byte);
            {
            let v51_2: Space = singleton(&v48_13_cursor.path()[(v48_13_origin + 1)..(v48_13_origin + 2)]);
            let v51_3: Space = intersect(&(*CONSTANT_1),&(v51_2));
            let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
            drop(v51_3);
            let v51_5: Space = subtract(&(*CONSTANT_0),&(v51_4));
            drop(v51_4);
            let v51_8: Space = if (&(v51_5)).is_empty() { Space::new() } else {
              let v52_7: Space = routine_10(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v51_5),&(v52_7))
            };
            drop(v51_5);
            let v51_9: Space = intersect(&(*CONSTANT_1),&(v51_2));
            drop(v51_2);
            let v51_10: Space = if has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
            drop(v51_9);
            let v51_12: Space = if (&(v51_10)).is_empty() { Space::new() } else {
              let v53_11: Space = routine_11(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v51_10),&(v53_11))
            };
            drop(v51_10);
            let v51_13: Space = unite(&(v51_8),&(v51_12));
            join_wrapped_into(&mut v50_6_write,&((v51_13).read_zipper()),&[]);
            }
            v48_13_cursor.ascend(1);
          }
          drop(v50_6_write);
          compose(&(v49_5),&(v50_6))
        };
        drop(v49_5);
        let v49_8: Space = intersect(&(*CONSTANT_1),&(v49_2));
        drop(v49_2);
        let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
        drop(v49_8);
        let v49_11: Space = if (&(v49_9)).is_empty() { Space::new() } else {
          let mut v54_10 = Space::new();
          let mut v54_10_write = v54_10.write_zipper();
          for v54_10_byte in v48_13_cursor.child_mask().iter() {
            v48_13_cursor.descend_to_existing_byte(v54_10_byte);
            {
            let v55_2: Space = singleton(&v48_13_cursor.path()[(v48_13_origin + 1)..(v48_13_origin + 2)]);
            let v55_3: Space = intersect(&(*CONSTANT_1),&(v55_2));
            let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
            drop(v55_3);
            let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
            drop(v55_4);
            let v55_8: Space = if (&(v55_5)).is_empty() { Space::new() } else {
              let v56_7: Space = routine_10(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v55_5),&(v56_7))
            };
            drop(v55_5);
            let v55_9: Space = intersect(&(*CONSTANT_1),&(v55_2));
            drop(v55_2);
            let v55_10: Space = if has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
            drop(v55_9);
            let v55_12: Space = if (&(v55_10)).is_empty() { Space::new() } else {
              let v57_11: Space = routine_12(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v55_10),&(v57_11))
            };
            drop(v55_10);
            let v55_13: Space = unite(&(v55_8),&(v55_12));
            join_wrapped_into(&mut v54_10_write,&((v55_13).read_zipper()),&[]);
            }
            v48_13_cursor.ascend(1);
          }
          drop(v54_10_write);
          compose(&(v49_9),&(v54_10))
        };
        drop(v49_9);
        let v49_12: Space = unite(&(v49_7),&(v49_11));
        join_wrapped_into(&mut v48_13_write,&((v49_12).read_zipper()),&[]);
        }
        v48_13_cursor.ascend(1);
      }
      drop(v48_13_cursor);
      drop(v48_13_write);
      drop(v48_12);
      let v48_14: Space = restrict_to(&(*CONSTANT_3),&(v48_13));
      let mut v48_15 = Space::new();
      let mut v48_15_write = v48_15.write_zipper();
      let mut v48_15_cursor = (v48_14).read_zipper();
      let v48_15_origin = v48_15_cursor.path().len();
      for v48_15_byte in v48_15_cursor.child_mask().iter() {
        v48_15_cursor.descend_to_existing_byte(v48_15_byte);
        {
        let v58_2: Space = singleton(&v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 1)]);
        let v58_3: Space = intersect(&(*CONSTANT_1),&(v58_2));
        let v58_4: Space = if has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
        drop(v58_3);
        let v58_5: Space = subtract(&(*CONSTANT_0),&(v58_4));
        drop(v58_4);
        let v58_7: Space = if (&(v58_5)).is_empty() { Space::new() } else {
          let mut v59_6 = Space::new();
          let mut v59_6_write = v59_6.write_zipper();
          for v59_6_byte in v48_15_cursor.child_mask().iter() {
            v48_15_cursor.descend_to_existing_byte(v59_6_byte);
            {
            let v60_2: Space = singleton(&v48_15_cursor.path()[(v48_15_origin + 1)..(v48_15_origin + 2)]);
            let v60_3: Space = intersect(&(*CONSTANT_1),&(v60_2));
            let v60_4: Space = if has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
            drop(v60_3);
            let v60_5: Space = subtract(&(*CONSTANT_0),&(v60_4));
            drop(v60_4);
            let v60_8: Space = if (&(v60_5)).is_empty() { Space::new() } else {
              let v61_7: Space = routine_13(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v60_5),&(v61_7))
            };
            drop(v60_5);
            let v60_9: Space = intersect(&(*CONSTANT_1),&(v60_2));
            drop(v60_2);
            let v60_10: Space = if has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
            drop(v60_9);
            let v60_12: Space = if (&(v60_10)).is_empty() { Space::new() } else {
              let v62_11: Space = routine_14(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v60_10),&(v62_11))
            };
            drop(v60_10);
            let v60_13: Space = unite(&(v60_8),&(v60_12));
            join_wrapped_into(&mut v59_6_write,&((v60_13).read_zipper()),&[]);
            }
            v48_15_cursor.ascend(1);
          }
          drop(v59_6_write);
          compose(&(v58_5),&(v59_6))
        };
        drop(v58_5);
        let v58_8: Space = intersect(&(*CONSTANT_1),&(v58_2));
        drop(v58_2);
        let v58_9: Space = if has_head(&(v58_8)) { singleton(&[]) } else { Space::new() };
        drop(v58_8);
        let v58_11: Space = if (&(v58_9)).is_empty() { Space::new() } else {
          let mut v63_10 = Space::new();
          let mut v63_10_write = v63_10.write_zipper();
          for v63_10_byte in v48_15_cursor.child_mask().iter() {
            v48_15_cursor.descend_to_existing_byte(v63_10_byte);
            {
            let v64_2: Space = singleton(&v48_15_cursor.path()[(v48_15_origin + 1)..(v48_15_origin + 2)]);
            let v64_3: Space = intersect(&(*CONSTANT_1),&(v64_2));
            let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
            drop(v64_3);
            let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
            drop(v64_4);
            let v64_8: Space = if (&(v64_5)).is_empty() { Space::new() } else {
              let v65_7: Space = routine_13(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v64_5),&(v65_7))
            };
            drop(v64_5);
            let v64_9: Space = intersect(&(*CONSTANT_1),&(v64_2));
            drop(v64_2);
            let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
            drop(v64_9);
            let v64_12: Space = if (&(v64_10)).is_empty() { Space::new() } else {
              let v66_11: Space = routine_15(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v64_10),&(v66_11))
            };
            drop(v64_10);
            let v64_13: Space = unite(&(v64_8),&(v64_12));
            join_wrapped_into(&mut v63_10_write,&((v64_13).read_zipper()),&[]);
            }
            v48_15_cursor.ascend(1);
          }
          drop(v63_10_write);
          compose(&(v58_9),&(v63_10))
        };
        drop(v58_9);
        let v58_12: Space = unite(&(v58_7),&(v58_11));
        join_wrapped_into(&mut v48_15_write,&((v58_12).read_zipper()),&[]);
        }
        v48_15_cursor.ascend(1);
      }
      drop(v48_15_cursor);
      drop(v48_15_write);
      let v48_17: Space = subtract(&(v48_15),&(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)])));
      let v48_18: Space = intersect(&(v48_17),&(*CONSTANT_5));
      compose(&(v37_10),&(v48_18))
    };
    drop(v37_10);
    let v67_6: Path = concat_path(&(*p0),&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)]);
    let v37_20: Space = wrap(&(v37_19),&(v67_6));
    let v37_21: Space = unite(&(v37_8),&(v37_20));
    join_wrapped_into(&mut v36_39_write,&((v37_21).read_zipper()),&[]);
    }
    v36_39_cursor.ascend(1);
  }
  drop(v36_39_cursor);
  drop(v36_39_write);
  (v36_39).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v68_6: Space = restrict_to(&(*CONSTANT_4),&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0))));
  let mut v68_25 = Space::new();
  let mut v68_25_write = v68_25.write_zipper();
  let mut v68_25_cursor = (v68_6).read_zipper();
  let v68_25_origin = v68_25_cursor.path().len();
  for v68_25_byte in v68_25_cursor.child_mask().iter() {
    v68_25_cursor.descend_to_existing_byte(v68_25_byte);
    {
    let v69_2: Space = singleton(&v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 1)]);
    let v69_3: Space = intersect(&(*CONSTANT_1),&(v69_2));
    let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
    drop(v69_3);
    let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
    drop(v69_4);
    let v69_7: Space = if (&(v69_5)).is_empty() { Space::new() } else {
      let mut v70_6 = Space::new();
      let mut v70_6_write = v70_6.write_zipper();
      for v70_6_byte in v68_25_cursor.child_mask().iter() {
        v68_25_cursor.descend_to_existing_byte(v70_6_byte);
        {
        let v71_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 1)..(v68_25_origin + 2)]);
        let v71_3: Space = intersect(&(*CONSTANT_1),&(v71_2));
        let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
        drop(v71_3);
        let v71_5: Space = subtract(&(*CONSTANT_0),&(v71_4));
        drop(v71_4);
        let v71_8: Space = if (&(v71_5)).is_empty() { Space::new() } else {
          let mut v72_7 = Space::new();
          let mut v72_7_write = v72_7.write_zipper();
          for v72_7_byte in v68_25_cursor.child_mask().iter() {
            v68_25_cursor.descend_to_existing_byte(v72_7_byte);
            {
            let v73_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 2)..(v68_25_origin + 3)]);
            let v73_3: Space = intersect(&(*CONSTANT_1),&(v73_2));
            let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
            drop(v73_3);
            let v73_5: Space = subtract(&(*CONSTANT_0),&(v73_4));
            drop(v73_4);
            let v73_8: Space = if (&(v73_5)).is_empty() { Space::new() } else {
              let v74_7: Space = routine_16(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v73_5),&(v74_7))
            };
            drop(v73_5);
            let v73_9: Space = intersect(&(*CONSTANT_1),&(v73_2));
            drop(v73_2);
            let v73_10: Space = if has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
            drop(v73_9);
            let v73_12: Space = if (&(v73_10)).is_empty() { Space::new() } else {
              let v75_11: Space = routine_17(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v73_10),&(v75_11))
            };
            drop(v73_10);
            let v73_13: Space = unite(&(v73_8),&(v73_12));
            join_wrapped_into(&mut v72_7_write,&((v73_13).read_zipper()),&[]);
            }
            v68_25_cursor.ascend(1);
          }
          drop(v72_7_write);
          compose(&(v71_5),&(v72_7))
        };
        drop(v71_5);
        let v71_9: Space = intersect(&(*CONSTANT_1),&(v71_2));
        drop(v71_2);
        let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
        drop(v71_9);
        let v71_12: Space = if (&(v71_10)).is_empty() { Space::new() } else {
          let mut v76_11 = Space::new();
          let mut v76_11_write = v76_11.write_zipper();
          for v76_11_byte in v68_25_cursor.child_mask().iter() {
            v68_25_cursor.descend_to_existing_byte(v76_11_byte);
            {
            let v77_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 2)..(v68_25_origin + 3)]);
            let v77_3: Space = intersect(&(*CONSTANT_1),&(v77_2));
            let v77_4: Space = if has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
            drop(v77_3);
            let v77_5: Space = subtract(&(*CONSTANT_0),&(v77_4));
            drop(v77_4);
            let v77_8: Space = if (&(v77_5)).is_empty() { Space::new() } else {
              let v78_7: Space = routine_16(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v77_5),&(v78_7))
            };
            drop(v77_5);
            let v77_9: Space = intersect(&(*CONSTANT_1),&(v77_2));
            drop(v77_2);
            let v77_10: Space = if has_head(&(v77_9)) { singleton(&[]) } else { Space::new() };
            drop(v77_9);
            let v77_12: Space = if (&(v77_10)).is_empty() { Space::new() } else {
              let v79_11: Space = routine_12(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v77_10),&(v79_11))
            };
            drop(v77_10);
            let v77_13: Space = unite(&(v77_8),&(v77_12));
            join_wrapped_into(&mut v76_11_write,&((v77_13).read_zipper()),&[]);
            }
            v68_25_cursor.ascend(1);
          }
          drop(v76_11_write);
          compose(&(v71_10),&(v76_11))
        };
        drop(v71_10);
        let v71_13: Space = unite(&(v71_8),&(v71_12));
        join_wrapped_into(&mut v70_6_write,&((v71_13).read_zipper()),&[]);
        }
        v68_25_cursor.ascend(1);
      }
      drop(v70_6_write);
      compose(&(v69_5),&(v70_6))
    };
    drop(v69_5);
    let v69_8: Space = intersect(&(*CONSTANT_1),&(v69_2));
    drop(v69_2);
    let v69_9: Space = if has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
    drop(v69_8);
    let v69_11: Space = if (&(v69_9)).is_empty() { Space::new() } else {
      let mut v80_10 = Space::new();
      let mut v80_10_write = v80_10.write_zipper();
      for v80_10_byte in v68_25_cursor.child_mask().iter() {
        v68_25_cursor.descend_to_existing_byte(v80_10_byte);
        {
        let v81_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 1)..(v68_25_origin + 2)]);
        let v81_3: Space = intersect(&(*CONSTANT_1),&(v81_2));
        let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
        drop(v81_3);
        let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
        drop(v81_4);
        let v81_8: Space = if (&(v81_5)).is_empty() { Space::new() } else {
          let mut v82_7 = Space::new();
          let mut v82_7_write = v82_7.write_zipper();
          for v82_7_byte in v68_25_cursor.child_mask().iter() {
            v68_25_cursor.descend_to_existing_byte(v82_7_byte);
            {
            let v83_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 2)..(v68_25_origin + 3)]);
            let v83_3: Space = intersect(&(*CONSTANT_1),&(v83_2));
            let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
            drop(v83_3);
            let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
            drop(v83_4);
            let v83_8: Space = if (&(v83_5)).is_empty() { Space::new() } else {
              let v84_7: Space = routine_16(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v83_5),&(v84_7))
            };
            drop(v83_5);
            let v83_9: Space = intersect(&(*CONSTANT_1),&(v83_2));
            drop(v83_2);
            let v83_10: Space = if has_head(&(v83_9)) { singleton(&[]) } else { Space::new() };
            drop(v83_9);
            let v83_12: Space = if (&(v83_10)).is_empty() { Space::new() } else {
              let v85_11: Space = routine_17(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v83_10),&(v85_11))
            };
            drop(v83_10);
            let v83_13: Space = unite(&(v83_8),&(v83_12));
            join_wrapped_into(&mut v82_7_write,&((v83_13).read_zipper()),&[]);
            }
            v68_25_cursor.ascend(1);
          }
          drop(v82_7_write);
          compose(&(v81_5),&(v82_7))
        };
        drop(v81_5);
        let v81_9: Space = intersect(&(*CONSTANT_1),&(v81_2));
        drop(v81_2);
        let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
        drop(v81_9);
        let v81_11: Space = compose(&(v81_10),&v68_25_cursor);
        drop(v81_10);
        let v81_12: Space = unite(&(v81_8),&(v81_11));
        drop(v81_11);
        join_wrapped_into(&mut v80_10_write,&((v81_12).read_zipper()),&[]);
        }
        v68_25_cursor.ascend(1);
      }
      drop(v80_10_write);
      compose(&(v69_9),&(v80_10))
    };
    drop(v69_9);
    let v69_12: Space = unite(&(v69_7),&(v69_11));
    join_wrapped_into(&mut v68_25_write,&((v69_12).read_zipper()),&[]);
    }
    v68_25_cursor.ascend(1);
  }
  drop(v68_25_cursor);
  drop(v68_25_write);
  drop(v68_6);
  let v68_26: Space = restrict_to(&(*CONSTANT_3),&(v68_25));
  let mut v68_45 = Space::new();
  let mut v68_45_write = v68_45.write_zipper();
  let mut v68_45_cursor = (v68_26).read_zipper();
  let v68_45_origin = v68_45_cursor.path().len();
  for v68_45_byte in v68_45_cursor.child_mask().iter() {
    v68_45_cursor.descend_to_existing_byte(v68_45_byte);
    {
    let v86_2: Space = singleton(&v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 1)]);
    let v86_3: Space = intersect(&(*CONSTANT_1),&(v86_2));
    let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
    drop(v86_3);
    let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
    drop(v86_4);
    let v86_7: Space = if (&(v86_5)).is_empty() { Space::new() } else {
      let mut v87_6 = Space::new();
      let mut v87_6_write = v87_6.write_zipper();
      for v87_6_byte in v68_45_cursor.child_mask().iter() {
        v68_45_cursor.descend_to_existing_byte(v87_6_byte);
        {
        let v88_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 1)..(v68_45_origin + 2)]);
        let v88_3: Space = intersect(&(*CONSTANT_1),&(v88_2));
        let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
        drop(v88_3);
        let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
        drop(v88_4);
        let v88_8: Space = if (&(v88_5)).is_empty() { Space::new() } else {
          let mut v89_7 = Space::new();
          let mut v89_7_write = v89_7.write_zipper();
          for v89_7_byte in v68_45_cursor.child_mask().iter() {
            v68_45_cursor.descend_to_existing_byte(v89_7_byte);
            {
            let v90_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 2)..(v68_45_origin + 3)]);
            let v90_3: Space = intersect(&(*CONSTANT_1),&(v90_2));
            let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
            drop(v90_3);
            let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
            drop(v90_4);
            let v90_8: Space = if (&(v90_5)).is_empty() { Space::new() } else {
              let v91_7: Space = routine_18(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v90_5),&(v91_7))
            };
            drop(v90_5);
            let v90_9: Space = intersect(&(*CONSTANT_1),&(v90_2));
            drop(v90_2);
            let v90_10: Space = if has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
            drop(v90_9);
            let v90_12: Space = if (&(v90_10)).is_empty() { Space::new() } else {
              let v92_11: Space = routine_19(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v90_10),&(v92_11))
            };
            drop(v90_10);
            let v90_13: Space = unite(&(v90_8),&(v90_12));
            join_wrapped_into(&mut v89_7_write,&((v90_13).read_zipper()),&[]);
            }
            v68_45_cursor.ascend(1);
          }
          drop(v89_7_write);
          compose(&(v88_5),&(v89_7))
        };
        drop(v88_5);
        let v88_9: Space = intersect(&(*CONSTANT_1),&(v88_2));
        drop(v88_2);
        let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
        drop(v88_9);
        let v88_12: Space = if (&(v88_10)).is_empty() { Space::new() } else {
          let mut v93_11 = Space::new();
          let mut v93_11_write = v93_11.write_zipper();
          for v93_11_byte in v68_45_cursor.child_mask().iter() {
            v68_45_cursor.descend_to_existing_byte(v93_11_byte);
            {
            let v94_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 2)..(v68_45_origin + 3)]);
            let v94_3: Space = intersect(&(*CONSTANT_1),&(v94_2));
            let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
            drop(v94_3);
            let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
            drop(v94_4);
            let v94_8: Space = if (&(v94_5)).is_empty() { Space::new() } else {
              let v95_7: Space = routine_18(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v94_5),&(v95_7))
            };
            drop(v94_5);
            let v94_9: Space = intersect(&(*CONSTANT_1),&(v94_2));
            drop(v94_2);
            let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
            drop(v94_9);
            let v94_12: Space = if (&(v94_10)).is_empty() { Space::new() } else {
              let v96_11: Space = routine_15(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v94_10),&(v96_11))
            };
            drop(v94_10);
            let v94_13: Space = unite(&(v94_8),&(v94_12));
            join_wrapped_into(&mut v93_11_write,&((v94_13).read_zipper()),&[]);
            }
            v68_45_cursor.ascend(1);
          }
          drop(v93_11_write);
          compose(&(v88_10),&(v93_11))
        };
        drop(v88_10);
        let v88_13: Space = unite(&(v88_8),&(v88_12));
        join_wrapped_into(&mut v87_6_write,&((v88_13).read_zipper()),&[]);
        }
        v68_45_cursor.ascend(1);
      }
      drop(v87_6_write);
      compose(&(v86_5),&(v87_6))
    };
    drop(v86_5);
    let v86_8: Space = intersect(&(*CONSTANT_1),&(v86_2));
    drop(v86_2);
    let v86_9: Space = if has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
    drop(v86_8);
    let v86_11: Space = if (&(v86_9)).is_empty() { Space::new() } else {
      let mut v97_10 = Space::new();
      let mut v97_10_write = v97_10.write_zipper();
      for v97_10_byte in v68_45_cursor.child_mask().iter() {
        v68_45_cursor.descend_to_existing_byte(v97_10_byte);
        {
        let v98_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 1)..(v68_45_origin + 2)]);
        let v98_3: Space = intersect(&(*CONSTANT_1),&(v98_2));
        let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
        drop(v98_3);
        let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
        drop(v98_4);
        let v98_8: Space = if (&(v98_5)).is_empty() { Space::new() } else {
          let mut v99_7 = Space::new();
          let mut v99_7_write = v99_7.write_zipper();
          for v99_7_byte in v68_45_cursor.child_mask().iter() {
            v68_45_cursor.descend_to_existing_byte(v99_7_byte);
            {
            let v100_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 2)..(v68_45_origin + 3)]);
            let v100_3: Space = intersect(&(*CONSTANT_1),&(v100_2));
            let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
            drop(v100_3);
            let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
            drop(v100_4);
            let v100_8: Space = if (&(v100_5)).is_empty() { Space::new() } else {
              let v101_7: Space = routine_18(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v100_5),&(v101_7))
            };
            drop(v100_5);
            let v100_9: Space = intersect(&(*CONSTANT_1),&(v100_2));
            drop(v100_2);
            let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
            drop(v100_9);
            let v100_12: Space = if (&(v100_10)).is_empty() { Space::new() } else {
              let v102_11: Space = routine_19(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v100_10),&(v102_11))
            };
            drop(v100_10);
            let v100_13: Space = unite(&(v100_8),&(v100_12));
            join_wrapped_into(&mut v99_7_write,&((v100_13).read_zipper()),&[]);
            }
            v68_45_cursor.ascend(1);
          }
          drop(v99_7_write);
          compose(&(v98_5),&(v99_7))
        };
        drop(v98_5);
        let v98_9: Space = intersect(&(*CONSTANT_1),&(v98_2));
        drop(v98_2);
        let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
        drop(v98_9);
        let v98_11: Space = compose(&(v98_10),&v68_45_cursor);
        drop(v98_10);
        let v98_12: Space = unite(&(v98_8),&(v98_11));
        drop(v98_11);
        join_wrapped_into(&mut v97_10_write,&((v98_12).read_zipper()),&[]);
        }
        v68_45_cursor.ascend(1);
      }
      drop(v97_10_write);
      compose(&(v86_9),&(v97_10))
    };
    drop(v86_9);
    let v86_12: Space = unite(&(v86_7),&(v86_11));
    join_wrapped_into(&mut v68_45_write,&((v86_12).read_zipper()),&[]);
    }
    v68_45_cursor.ascend(1);
  }
  drop(v68_45_cursor);
  drop(v68_45_write);
  let v68_48: Space = subtract(&(v68_45),&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0))));
  let v68_50: Space = intersect(&(v68_48),&(*CONSTANT_5));
  let v68_51: Space = wrap(&(v68_50),&(*p0));
  (v68_51).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v103_2: Space = Space::new();
  (v103_2).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v104_28 = Space::new();
  let mut v104_28_write = v104_28.write_zipper();
  let mut v104_28_cursor = (*s0).read_zipper();
  let v104_28_origin = v104_28_cursor.path().len();
  for v104_28_byte in v104_28_cursor.child_mask().iter() {
    v104_28_cursor.descend_to_existing_byte(v104_28_byte);
    {
    let v105_2: Space = singleton(&v104_28_cursor.path()[v104_28_origin..(v104_28_origin + 1)]);
    let v105_3: Space = intersect(&(*CONSTANT_1),&(v105_2));
    drop(v105_2);
    let v105_4: Space = if has_head(&(v105_3)) { singleton(&[]) } else { Space::new() };
    drop(v105_3);
    let v105_13: Space = if (&(v105_4)).is_empty() { Space::new() } else {
      let v106_6: Space = restrict_to(&(*CONSTANT_4),&(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v104_28_cursor.path()[v104_28_origin..(v104_28_origin + 1)])));
      let mut v106_7 = Space::new();
      let mut v106_7_write = v106_7.write_zipper();
      let mut v106_7_cursor = (v106_6).read_zipper();
      let v106_7_origin = v106_7_cursor.path().len();
      for v106_7_byte in v106_7_cursor.child_mask().iter() {
        v106_7_cursor.descend_to_existing_byte(v106_7_byte);
        {
        let v107_2: Space = singleton(&v106_7_cursor.path()[v106_7_origin..(v106_7_origin + 1)]);
        let v107_3: Space = intersect(&(*CONSTANT_1),&(v107_2));
        let v107_4: Space = if has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
        drop(v107_3);
        let v107_5: Space = subtract(&(*CONSTANT_0),&(v107_4));
        drop(v107_4);
        let v107_7: Space = if (&(v107_5)).is_empty() { Space::new() } else {
          let mut v108_6 = Space::new();
          let mut v108_6_write = v108_6.write_zipper();
          for v108_6_byte in v106_7_cursor.child_mask().iter() {
            v106_7_cursor.descend_to_existing_byte(v108_6_byte);
            {
            let v109_2: Space = singleton(&v106_7_cursor.path()[(v106_7_origin + 1)..(v106_7_origin + 2)]);
            let v109_3: Space = intersect(&(*CONSTANT_1),&(v109_2));
            let v109_4: Space = if has_head(&(v109_3)) { singleton(&[]) } else { Space::new() };
            drop(v109_3);
            let v109_5: Space = subtract(&(*CONSTANT_0),&(v109_4));
            drop(v109_4);
            let v109_8: Space = if (&(v109_5)).is_empty() { Space::new() } else {
              let v110_7: Space = routine_10(c, &v106_7_cursor.path()[v106_7_origin..(v106_7_origin + 2)], &v106_7_cursor);
              compose(&(v109_5),&(v110_7))
            };
            drop(v109_5);
            let v109_9: Space = intersect(&(*CONSTANT_1),&(v109_2));
            drop(v109_2);
            let v109_10: Space = if has_head(&(v109_9)) { singleton(&[]) } else { Space::new() };
            drop(v109_9);
            let v109_12: Space = if (&(v109_10)).is_empty() { Space::new() } else {
              let v111_11: Space = routine_11(c, &v106_7_cursor.path()[v106_7_origin..(v106_7_origin + 2)], &v106_7_cursor);
              compose(&(v109_10),&(v111_11))
            };
            drop(v109_10);
            let v109_13: Space = unite(&(v109_8),&(v109_12));
            join_wrapped_into(&mut v108_6_write,&((v109_13).read_zipper()),&[]);
            }
            v106_7_cursor.ascend(1);
          }
          drop(v108_6_write);
          compose(&(v107_5),&(v108_6))
        };
        drop(v107_5);
        let v107_8: Space = intersect(&(*CONSTANT_1),&(v107_2));
        drop(v107_2);
        let v107_9: Space = if has_head(&(v107_8)) { singleton(&[]) } else { Space::new() };
        drop(v107_8);
        let v107_11: Space = if (&(v107_9)).is_empty() { Space::new() } else {
          let mut v112_10 = Space::new();
          let mut v112_10_write = v112_10.write_zipper();
          for v112_10_byte in v106_7_cursor.child_mask().iter() {
            v106_7_cursor.descend_to_existing_byte(v112_10_byte);
            {
            let v113_2: Space = singleton(&v106_7_cursor.path()[(v106_7_origin + 1)..(v106_7_origin + 2)]);
            let v113_3: Space = intersect(&(*CONSTANT_1),&(v113_2));
            let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
            drop(v113_3);
            let v113_5: Space = subtract(&(*CONSTANT_0),&(v113_4));
            drop(v113_4);
            let v113_8: Space = if (&(v113_5)).is_empty() { Space::new() } else {
              let v114_7: Space = routine_10(c, &v106_7_cursor.path()[v106_7_origin..(v106_7_origin + 2)], &v106_7_cursor);
              compose(&(v113_5),&(v114_7))
            };
            drop(v113_5);
            let v113_9: Space = intersect(&(*CONSTANT_1),&(v113_2));
            drop(v113_2);
            let v113_10: Space = if has_head(&(v113_9)) { singleton(&[]) } else { Space::new() };
            drop(v113_9);
            let v113_12: Space = if (&(v113_10)).is_empty() { Space::new() } else {
              let v115_11: Space = routine_12(c, &v106_7_cursor.path()[v106_7_origin..(v106_7_origin + 2)], &v106_7_cursor);
              compose(&(v113_10),&(v115_11))
            };
            drop(v113_10);
            let v113_13: Space = unite(&(v113_8),&(v113_12));
            join_wrapped_into(&mut v112_10_write,&((v113_13).read_zipper()),&[]);
            }
            v106_7_cursor.ascend(1);
          }
          drop(v112_10_write);
          compose(&(v107_9),&(v112_10))
        };
        drop(v107_9);
        let v107_12: Space = unite(&(v107_7),&(v107_11));
        join_wrapped_into(&mut v106_7_write,&((v107_12).read_zipper()),&[]);
        }
        v106_7_cursor.ascend(1);
      }
      drop(v106_7_cursor);
      drop(v106_7_write);
      drop(v106_6);
      let v106_8: Space = restrict_to(&(*CONSTANT_3),&(v106_7));
      let mut v106_9 = Space::new();
      let mut v106_9_write = v106_9.write_zipper();
      let mut v106_9_cursor = (v106_8).read_zipper();
      let v106_9_origin = v106_9_cursor.path().len();
      for v106_9_byte in v106_9_cursor.child_mask().iter() {
        v106_9_cursor.descend_to_existing_byte(v106_9_byte);
        {
        let v116_2: Space = singleton(&v106_9_cursor.path()[v106_9_origin..(v106_9_origin + 1)]);
        let v116_3: Space = intersect(&(*CONSTANT_1),&(v116_2));
        let v116_4: Space = if has_head(&(v116_3)) { singleton(&[]) } else { Space::new() };
        drop(v116_3);
        let v116_5: Space = subtract(&(*CONSTANT_0),&(v116_4));
        drop(v116_4);
        let v116_7: Space = if (&(v116_5)).is_empty() { Space::new() } else {
          let mut v117_6 = Space::new();
          let mut v117_6_write = v117_6.write_zipper();
          for v117_6_byte in v106_9_cursor.child_mask().iter() {
            v106_9_cursor.descend_to_existing_byte(v117_6_byte);
            {
            let v118_2: Space = singleton(&v106_9_cursor.path()[(v106_9_origin + 1)..(v106_9_origin + 2)]);
            let v118_3: Space = intersect(&(*CONSTANT_1),&(v118_2));
            let v118_4: Space = if has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
            drop(v118_3);
            let v118_5: Space = subtract(&(*CONSTANT_0),&(v118_4));
            drop(v118_4);
            let v118_8: Space = if (&(v118_5)).is_empty() { Space::new() } else {
              let v119_7: Space = routine_13(c, &v106_9_cursor.path()[v106_9_origin..(v106_9_origin + 2)], &v106_9_cursor);
              compose(&(v118_5),&(v119_7))
            };
            drop(v118_5);
            let v118_9: Space = intersect(&(*CONSTANT_1),&(v118_2));
            drop(v118_2);
            let v118_10: Space = if has_head(&(v118_9)) { singleton(&[]) } else { Space::new() };
            drop(v118_9);
            let v118_12: Space = if (&(v118_10)).is_empty() { Space::new() } else {
              let v120_11: Space = routine_14(c, &v106_9_cursor.path()[v106_9_origin..(v106_9_origin + 2)], &v106_9_cursor);
              compose(&(v118_10),&(v120_11))
            };
            drop(v118_10);
            let v118_13: Space = unite(&(v118_8),&(v118_12));
            join_wrapped_into(&mut v117_6_write,&((v118_13).read_zipper()),&[]);
            }
            v106_9_cursor.ascend(1);
          }
          drop(v117_6_write);
          compose(&(v116_5),&(v117_6))
        };
        drop(v116_5);
        let v116_8: Space = intersect(&(*CONSTANT_1),&(v116_2));
        drop(v116_2);
        let v116_9: Space = if has_head(&(v116_8)) { singleton(&[]) } else { Space::new() };
        drop(v116_8);
        let v116_11: Space = if (&(v116_9)).is_empty() { Space::new() } else {
          let mut v121_10 = Space::new();
          let mut v121_10_write = v121_10.write_zipper();
          for v121_10_byte in v106_9_cursor.child_mask().iter() {
            v106_9_cursor.descend_to_existing_byte(v121_10_byte);
            {
            let v122_2: Space = singleton(&v106_9_cursor.path()[(v106_9_origin + 1)..(v106_9_origin + 2)]);
            let v122_3: Space = intersect(&(*CONSTANT_1),&(v122_2));
            let v122_4: Space = if has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
            drop(v122_3);
            let v122_5: Space = subtract(&(*CONSTANT_0),&(v122_4));
            drop(v122_4);
            let v122_8: Space = if (&(v122_5)).is_empty() { Space::new() } else {
              let v123_7: Space = routine_13(c, &v106_9_cursor.path()[v106_9_origin..(v106_9_origin + 2)], &v106_9_cursor);
              compose(&(v122_5),&(v123_7))
            };
            drop(v122_5);
            let v122_9: Space = intersect(&(*CONSTANT_1),&(v122_2));
            drop(v122_2);
            let v122_10: Space = if has_head(&(v122_9)) { singleton(&[]) } else { Space::new() };
            drop(v122_9);
            let v122_12: Space = if (&(v122_10)).is_empty() { Space::new() } else {
              let v124_11: Space = routine_15(c, &v106_9_cursor.path()[v106_9_origin..(v106_9_origin + 2)], &v106_9_cursor);
              compose(&(v122_10),&(v124_11))
            };
            drop(v122_10);
            let v122_13: Space = unite(&(v122_8),&(v122_12));
            join_wrapped_into(&mut v121_10_write,&((v122_13).read_zipper()),&[]);
            }
            v106_9_cursor.ascend(1);
          }
          drop(v121_10_write);
          compose(&(v116_9),&(v121_10))
        };
        drop(v116_9);
        let v116_12: Space = unite(&(v116_7),&(v116_11));
        join_wrapped_into(&mut v106_9_write,&((v116_12).read_zipper()),&[]);
        }
        v106_9_cursor.ascend(1);
      }
      drop(v106_9_cursor);
      drop(v106_9_write);
      let v106_11: Space = subtract(&(v106_9),&(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v104_28_cursor.path()[v104_28_origin..(v104_28_origin + 1)])));
      let v106_12: Space = intersect(&(v106_11),&(*CONSTANT_5));
      compose(&(v105_4),&(v106_12))
    };
    drop(v105_4);
    let v105_14: Path = concat_path(&(*p0),&v104_28_cursor.path()[v104_28_origin..(v104_28_origin + 1)]);
    join_wrapped_into(&mut v104_28_write,&((v105_13).read_zipper()),&(v105_14));
    drop(v105_14);
    }
    v104_28_cursor.ascend(1);
  }
  drop(v104_28_cursor);
  drop(v104_28_write);
  (v104_28).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v125_20 = Space::new();
  let mut v125_20_write = v125_20.write_zipper();
  let mut v125_20_cursor = (*s0).read_zipper();
  let v125_20_origin = v125_20_cursor.path().len();
  for v125_20_byte in v125_20_cursor.child_mask().iter() {
    v125_20_cursor.descend_to_existing_byte(v125_20_byte);
    {
    let v126_2: Space = singleton(&v125_20_cursor.path()[v125_20_origin..(v125_20_origin + 1)]);
    let v126_3: Space = intersect(&(*CONSTANT_1),&(v126_2));
    let v126_4: Space = if has_head(&(v126_3)) { singleton(&[]) } else { Space::new() };
    drop(v126_3);
    let v126_5: Space = subtract(&(*CONSTANT_0),&(v126_4));
    drop(v126_4);
    let v126_8: Space = if (&(v126_5)).is_empty() { Space::new() } else {
      let v127_6: Path = concat_path(&(*p0),&v125_20_cursor.path()[v125_20_origin..(v125_20_origin + 1)]);
      let mut v127_7 = Space::new();
      let mut v127_7_write = v127_7.write_zipper();
      for v127_7_byte in v125_20_cursor.child_mask().iter() {
        v125_20_cursor.descend_to_existing_byte(v127_7_byte);
        {
        let v128_2: Space = singleton(&v125_20_cursor.path()[(v125_20_origin + 1)..(v125_20_origin + 2)]);
        let v128_3: Space = intersect(&(*CONSTANT_1),&(v128_2));
        let v128_4: Space = if has_head(&(v128_3)) { singleton(&[]) } else { Space::new() };
        drop(v128_3);
        let v128_5: Space = subtract(&(*CONSTANT_0),&(v128_4));
        drop(v128_4);
        let v128_8: Space = if (&(v128_5)).is_empty() { Space::new() } else {
          let v129_6: Path = concat_path(&(v127_6),&v125_20_cursor.path()[(v125_20_origin + 1)..(v125_20_origin + 2)]);
          let mut v129_7 = Space::new();
          let mut v129_7_write = v129_7.write_zipper();
          for v129_7_byte in v125_20_cursor.child_mask().iter() {
            v125_20_cursor.descend_to_existing_byte(v129_7_byte);
            {
            let v130_2: Space = singleton(&v125_20_cursor.path()[(v125_20_origin + 2)..(v125_20_origin + 3)]);
            let v130_3: Space = intersect(&(*CONSTANT_1),&(v130_2));
            let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
            drop(v130_3);
            let v130_5: Space = subtract(&(*CONSTANT_0),&(v130_4));
            drop(v130_4);
            let v130_8: Space = if (&(v130_5)).is_empty() { Space::new() } else {
              let v131_6: Path = concat_path(&(v129_6),&v125_20_cursor.path()[(v125_20_origin + 2)..(v125_20_origin + 3)]);
              let v131_7: Space = routine_20(c, &(v131_6), &v125_20_cursor);
              compose(&(v130_5),&(v131_7))
            };
            drop(v130_5);
            let v130_9: Space = intersect(&(*CONSTANT_1),&(v130_2));
            drop(v130_2);
            let v130_10: Space = if has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
            drop(v130_9);
            let v130_12: Space = if (&(v130_10)).is_empty() { Space::new() } else {
              let v132_6: Path = concat_path(&(v129_6),&v125_20_cursor.path()[(v125_20_origin + 2)..(v125_20_origin + 3)]);
              let v132_11: Space = routine_21(c, &(v132_6), &v125_20_cursor);
              drop(v132_6);
              compose(&(v130_10),&(v132_11))
            };
            drop(v130_10);
            let v130_13: Space = unite(&(v130_8),&(v130_12));
            join_wrapped_into(&mut v129_7_write,&((v130_13).read_zipper()),&[]);
            }
            v125_20_cursor.ascend(1);
          }
          drop(v129_7_write);
          compose(&(v128_5),&(v129_7))
        };
        drop(v128_5);
        let v128_9: Space = intersect(&(*CONSTANT_1),&(v128_2));
        drop(v128_2);
        let v128_10: Space = if has_head(&(v128_9)) { singleton(&[]) } else { Space::new() };
        drop(v128_9);
        let v128_12: Space = if (&(v128_10)).is_empty() { Space::new() } else {
          let v133_6: Path = concat_path(&(v127_6),&v125_20_cursor.path()[(v125_20_origin + 1)..(v125_20_origin + 2)]);
          let mut v133_11 = Space::new();
          let mut v133_11_write = v133_11.write_zipper();
          for v133_11_byte in v125_20_cursor.child_mask().iter() {
            v125_20_cursor.descend_to_existing_byte(v133_11_byte);
            {
            let v134_2: Space = singleton(&v125_20_cursor.path()[(v125_20_origin + 2)..(v125_20_origin + 3)]);
            let v134_3: Space = intersect(&(*CONSTANT_1),&(v134_2));
            let v134_4: Space = if has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
            drop(v134_3);
            let v134_5: Space = subtract(&(*CONSTANT_0),&(v134_4));
            drop(v134_4);
            let v134_8: Space = if (&(v134_5)).is_empty() { Space::new() } else {
              let v135_6: Path = concat_path(&(v133_6),&v125_20_cursor.path()[(v125_20_origin + 2)..(v125_20_origin + 3)]);
              let v135_7: Space = routine_20(c, &(v135_6), &v125_20_cursor);
              compose(&(v134_5),&(v135_7))
            };
            drop(v134_5);
            let v134_9: Space = intersect(&(*CONSTANT_1),&(v134_2));
            drop(v134_2);
            let v134_10: Space = if has_head(&(v134_9)) { singleton(&[]) } else { Space::new() };
            drop(v134_9);
            let v134_12: Space = if (&(v134_10)).is_empty() { Space::new() } else {
              let v136_6: Path = concat_path(&(v133_6),&v125_20_cursor.path()[(v125_20_origin + 2)..(v125_20_origin + 3)]);
              let v136_11: Space = routine_12(c, &(v136_6), &v125_20_cursor);
              drop(v136_6);
              compose(&(v134_10),&(v136_11))
            };
            drop(v134_10);
            let v134_13: Space = unite(&(v134_8),&(v134_12));
            join_wrapped_into(&mut v133_11_write,&((v134_13).read_zipper()),&[]);
            }
            v125_20_cursor.ascend(1);
          }
          drop(v133_11_write);
          drop(v133_6);
          compose(&(v128_10),&(v133_11))
        };
        drop(v128_10);
        let v128_13: Space = unite(&(v128_8),&(v128_12));
        join_wrapped_into(&mut v127_7_write,&((v128_13).read_zipper()),&[]);
        }
        v125_20_cursor.ascend(1);
      }
      drop(v127_7_write);
      compose(&(v126_5),&(v127_7))
    };
    drop(v126_5);
    let v126_9: Space = intersect(&(*CONSTANT_1),&(v126_2));
    drop(v126_2);
    let v126_10: Space = if has_head(&(v126_9)) { singleton(&[]) } else { Space::new() };
    drop(v126_9);
    let v126_12: Space = if (&(v126_10)).is_empty() { Space::new() } else {
      let v137_6: Path = concat_path(&(*p0),&v125_20_cursor.path()[v125_20_origin..(v125_20_origin + 1)]);
      let mut v137_11 = Space::new();
      let mut v137_11_write = v137_11.write_zipper();
      for v137_11_byte in v125_20_cursor.child_mask().iter() {
        v125_20_cursor.descend_to_existing_byte(v137_11_byte);
        {
        let v138_2: Space = singleton(&v125_20_cursor.path()[(v125_20_origin + 1)..(v125_20_origin + 2)]);
        let v138_3: Space = intersect(&(*CONSTANT_1),&(v138_2));
        let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
        drop(v138_3);
        let v138_5: Space = subtract(&(*CONSTANT_0),&(v138_4));
        drop(v138_4);
        let v138_8: Space = if (&(v138_5)).is_empty() { Space::new() } else {
          let v139_6: Path = concat_path(&(v137_6),&v125_20_cursor.path()[(v125_20_origin + 1)..(v125_20_origin + 2)]);
          let mut v139_7 = Space::new();
          let mut v139_7_write = v139_7.write_zipper();
          for v139_7_byte in v125_20_cursor.child_mask().iter() {
            v125_20_cursor.descend_to_existing_byte(v139_7_byte);
            {
            let v140_2: Space = singleton(&v125_20_cursor.path()[(v125_20_origin + 2)..(v125_20_origin + 3)]);
            let v140_3: Space = intersect(&(*CONSTANT_1),&(v140_2));
            let v140_4: Space = if has_head(&(v140_3)) { singleton(&[]) } else { Space::new() };
            drop(v140_3);
            let v140_5: Space = subtract(&(*CONSTANT_0),&(v140_4));
            drop(v140_4);
            let v140_8: Space = if (&(v140_5)).is_empty() { Space::new() } else {
              let v141_6: Path = concat_path(&(v139_6),&v125_20_cursor.path()[(v125_20_origin + 2)..(v125_20_origin + 3)]);
              let v141_7: Space = routine_20(c, &(v141_6), &v125_20_cursor);
              compose(&(v140_5),&(v141_7))
            };
            drop(v140_5);
            let v140_9: Space = intersect(&(*CONSTANT_1),&(v140_2));
            drop(v140_2);
            let v140_10: Space = if has_head(&(v140_9)) { singleton(&[]) } else { Space::new() };
            drop(v140_9);
            let v140_12: Space = if (&(v140_10)).is_empty() { Space::new() } else {
              let v142_6: Path = concat_path(&(v139_6),&v125_20_cursor.path()[(v125_20_origin + 2)..(v125_20_origin + 3)]);
              let v142_11: Space = routine_21(c, &(v142_6), &v125_20_cursor);
              drop(v142_6);
              compose(&(v140_10),&(v142_11))
            };
            drop(v140_10);
            let v140_13: Space = unite(&(v140_8),&(v140_12));
            join_wrapped_into(&mut v139_7_write,&((v140_13).read_zipper()),&[]);
            }
            v125_20_cursor.ascend(1);
          }
          drop(v139_7_write);
          drop(v139_6);
          compose(&(v138_5),&(v139_7))
        };
        drop(v138_5);
        let v138_9: Space = intersect(&(*CONSTANT_1),&(v138_2));
        drop(v138_2);
        let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
        drop(v138_9);
        let v138_11: Space = compose(&(v138_10),&v125_20_cursor);
        drop(v138_10);
        let v138_12: Space = unite(&(v138_8),&(v138_11));
        drop(v138_11);
        join_wrapped_into(&mut v137_11_write,&((v138_12).read_zipper()),&[]);
        }
        v125_20_cursor.ascend(1);
      }
      drop(v137_11_write);
      drop(v137_6);
      compose(&(v126_10),&(v137_11))
    };
    drop(v126_10);
    let v126_13: Space = unite(&(v126_8),&(v126_12));
    join_wrapped_into(&mut v125_20_write,&((v126_13).read_zipper()),&[]);
    }
    v125_20_cursor.ascend(1);
  }
  drop(v125_20_cursor);
  drop(v125_20_write);
  (v125_20).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v143_14 = Space::new();
  let mut v143_14_write = v143_14.write_zipper();
  let mut v143_14_cursor = (*s0).read_zipper();
  let v143_14_origin = v143_14_cursor.path().len();
  for v143_14_byte in v143_14_cursor.child_mask().iter() {
    v143_14_cursor.descend_to_existing_byte(v143_14_byte);
    {
    let v144_2: Space = singleton(&v143_14_cursor.path()[v143_14_origin..(v143_14_origin + 1)]);
    let v144_3: Space = intersect(&(*CONSTANT_1),&(v144_2));
    let v144_4: Space = if has_head(&(v144_3)) { singleton(&[]) } else { Space::new() };
    drop(v144_3);
    let v144_5: Space = subtract(&(*CONSTANT_0),&(v144_4));
    drop(v144_4);
    let v144_8: Space = if (&(v144_5)).is_empty() { Space::new() } else {
      let v145_6: Path = concat_path(&(*p0),&v143_14_cursor.path()[v143_14_origin..(v143_14_origin + 1)]);
      let mut v145_7 = Space::new();
      let mut v145_7_write = v145_7.write_zipper();
      for v145_7_byte in v143_14_cursor.child_mask().iter() {
        v143_14_cursor.descend_to_existing_byte(v145_7_byte);
        {
        let v146_2: Space = singleton(&v143_14_cursor.path()[(v143_14_origin + 1)..(v143_14_origin + 2)]);
        let v146_3: Space = intersect(&(*CONSTANT_1),&(v146_2));
        let v146_4: Space = if has_head(&(v146_3)) { singleton(&[]) } else { Space::new() };
        drop(v146_3);
        let v146_5: Space = subtract(&(*CONSTANT_0),&(v146_4));
        drop(v146_4);
        let v146_8: Space = if (&(v146_5)).is_empty() { Space::new() } else {
          let v147_6: Path = concat_path(&(v145_6),&v143_14_cursor.path()[(v143_14_origin + 1)..(v143_14_origin + 2)]);
          let mut v147_7 = Space::new();
          let mut v147_7_write = v147_7.write_zipper();
          for v147_7_byte in v143_14_cursor.child_mask().iter() {
            v143_14_cursor.descend_to_existing_byte(v147_7_byte);
            {
            let v148_2: Space = singleton(&v143_14_cursor.path()[(v143_14_origin + 2)..(v143_14_origin + 3)]);
            let v148_3: Space = intersect(&(*CONSTANT_1),&(v148_2));
            let v148_4: Space = if has_head(&(v148_3)) { singleton(&[]) } else { Space::new() };
            drop(v148_3);
            let v148_5: Space = subtract(&(*CONSTANT_0),&(v148_4));
            drop(v148_4);
            let v148_8: Space = if (&(v148_5)).is_empty() { Space::new() } else {
              let v149_6: Path = concat_path(&(v147_6),&v143_14_cursor.path()[(v143_14_origin + 2)..(v143_14_origin + 3)]);
              let v149_7: Space = routine_20(c, &(v149_6), &v143_14_cursor);
              compose(&(v148_5),&(v149_7))
            };
            drop(v148_5);
            let v148_9: Space = intersect(&(*CONSTANT_1),&(v148_2));
            drop(v148_2);
            let v148_10: Space = if has_head(&(v148_9)) { singleton(&[]) } else { Space::new() };
            drop(v148_9);
            let v148_12: Space = if (&(v148_10)).is_empty() { Space::new() } else {
              let v150_6: Path = concat_path(&(v147_6),&v143_14_cursor.path()[(v143_14_origin + 2)..(v143_14_origin + 3)]);
              let v150_11: Space = routine_21(c, &(v150_6), &v143_14_cursor);
              drop(v150_6);
              compose(&(v148_10),&(v150_11))
            };
            drop(v148_10);
            let v148_13: Space = unite(&(v148_8),&(v148_12));
            join_wrapped_into(&mut v147_7_write,&((v148_13).read_zipper()),&[]);
            }
            v143_14_cursor.ascend(1);
          }
          drop(v147_7_write);
          compose(&(v146_5),&(v147_7))
        };
        drop(v146_5);
        let v146_9: Space = intersect(&(*CONSTANT_1),&(v146_2));
        drop(v146_2);
        let v146_10: Space = if has_head(&(v146_9)) { singleton(&[]) } else { Space::new() };
        drop(v146_9);
        let v146_12: Space = if (&(v146_10)).is_empty() { Space::new() } else {
          let v151_6: Path = concat_path(&(v145_6),&v143_14_cursor.path()[(v143_14_origin + 1)..(v143_14_origin + 2)]);
          let mut v151_11 = Space::new();
          let mut v151_11_write = v151_11.write_zipper();
          for v151_11_byte in v143_14_cursor.child_mask().iter() {
            v143_14_cursor.descend_to_existing_byte(v151_11_byte);
            {
            let v152_2: Space = singleton(&v143_14_cursor.path()[(v143_14_origin + 2)..(v143_14_origin + 3)]);
            let v152_3: Space = intersect(&(*CONSTANT_1),&(v152_2));
            let v152_4: Space = if has_head(&(v152_3)) { singleton(&[]) } else { Space::new() };
            drop(v152_3);
            let v152_5: Space = subtract(&(*CONSTANT_0),&(v152_4));
            drop(v152_4);
            let v152_8: Space = if (&(v152_5)).is_empty() { Space::new() } else {
              let v153_6: Path = concat_path(&(v151_6),&v143_14_cursor.path()[(v143_14_origin + 2)..(v143_14_origin + 3)]);
              let v153_7: Space = routine_20(c, &(v153_6), &v143_14_cursor);
              compose(&(v152_5),&(v153_7))
            };
            drop(v152_5);
            let v152_9: Space = intersect(&(*CONSTANT_1),&(v152_2));
            drop(v152_2);
            let v152_10: Space = if has_head(&(v152_9)) { singleton(&[]) } else { Space::new() };
            drop(v152_9);
            let v152_12: Space = if (&(v152_10)).is_empty() { Space::new() } else {
              let v154_6: Path = concat_path(&(v151_6),&v143_14_cursor.path()[(v143_14_origin + 2)..(v143_14_origin + 3)]);
              let v154_11: Space = routine_12(c, &(v154_6), &v143_14_cursor);
              drop(v154_6);
              compose(&(v152_10),&(v154_11))
            };
            drop(v152_10);
            let v152_13: Space = unite(&(v152_8),&(v152_12));
            join_wrapped_into(&mut v151_11_write,&((v152_13).read_zipper()),&[]);
            }
            v143_14_cursor.ascend(1);
          }
          drop(v151_11_write);
          drop(v151_6);
          compose(&(v146_10),&(v151_11))
        };
        drop(v146_10);
        let v146_13: Space = unite(&(v146_8),&(v146_12));
        join_wrapped_into(&mut v145_7_write,&((v146_13).read_zipper()),&[]);
        }
        v143_14_cursor.ascend(1);
      }
      drop(v145_7_write);
      drop(v145_6);
      compose(&(v144_5),&(v145_7))
    };
    drop(v144_5);
    let v144_9: Space = intersect(&(*CONSTANT_1),&(v144_2));
    drop(v144_2);
    let v144_10: Space = if has_head(&(v144_9)) { singleton(&[]) } else { Space::new() };
    drop(v144_9);
    let v144_11: Space = compose(&(v144_10),&v143_14_cursor);
    drop(v144_10);
    let v144_12: Space = unite(&(v144_8),&(v144_11));
    drop(v144_11);
    join_wrapped_into(&mut v143_14_write,&((v144_12).read_zipper()),&[]);
    }
    v143_14_cursor.ascend(1);
  }
  drop(v143_14_cursor);
  drop(v143_14_write);
  (v143_14).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v155_20 = Space::new();
  let mut v155_20_write = v155_20.write_zipper();
  let mut v155_20_cursor = (*s0).read_zipper();
  let v155_20_origin = v155_20_cursor.path().len();
  for v155_20_byte in v155_20_cursor.child_mask().iter() {
    v155_20_cursor.descend_to_existing_byte(v155_20_byte);
    {
    let v156_2: Space = singleton(&v155_20_cursor.path()[v155_20_origin..(v155_20_origin + 1)]);
    let v156_3: Space = intersect(&(*CONSTANT_1),&(v156_2));
    let v156_4: Space = if has_head(&(v156_3)) { singleton(&[]) } else { Space::new() };
    drop(v156_3);
    let v156_5: Space = subtract(&(*CONSTANT_0),&(v156_4));
    drop(v156_4);
    let v156_8: Space = if (&(v156_5)).is_empty() { Space::new() } else {
      let v157_6: Path = concat_path(&(*p0),&v155_20_cursor.path()[v155_20_origin..(v155_20_origin + 1)]);
      let mut v157_7 = Space::new();
      let mut v157_7_write = v157_7.write_zipper();
      for v157_7_byte in v155_20_cursor.child_mask().iter() {
        v155_20_cursor.descend_to_existing_byte(v157_7_byte);
        {
        let v158_2: Space = singleton(&v155_20_cursor.path()[(v155_20_origin + 1)..(v155_20_origin + 2)]);
        let v158_3: Space = intersect(&(*CONSTANT_1),&(v158_2));
        let v158_4: Space = if has_head(&(v158_3)) { singleton(&[]) } else { Space::new() };
        drop(v158_3);
        let v158_5: Space = subtract(&(*CONSTANT_0),&(v158_4));
        drop(v158_4);
        let v158_8: Space = if (&(v158_5)).is_empty() { Space::new() } else {
          let v159_6: Path = concat_path(&(v157_6),&v155_20_cursor.path()[(v155_20_origin + 1)..(v155_20_origin + 2)]);
          let mut v159_7 = Space::new();
          let mut v159_7_write = v159_7.write_zipper();
          for v159_7_byte in v155_20_cursor.child_mask().iter() {
            v155_20_cursor.descend_to_existing_byte(v159_7_byte);
            {
            let v160_2: Space = singleton(&v155_20_cursor.path()[(v155_20_origin + 2)..(v155_20_origin + 3)]);
            let v160_3: Space = intersect(&(*CONSTANT_1),&(v160_2));
            let v160_4: Space = if has_head(&(v160_3)) { singleton(&[]) } else { Space::new() };
            drop(v160_3);
            let v160_5: Space = subtract(&(*CONSTANT_0),&(v160_4));
            drop(v160_4);
            let v160_8: Space = if (&(v160_5)).is_empty() { Space::new() } else {
              let v161_6: Path = concat_path(&(v159_6),&v155_20_cursor.path()[(v155_20_origin + 2)..(v155_20_origin + 3)]);
              let v161_7: Space = routine_22(c, &(v161_6), &v155_20_cursor);
              compose(&(v160_5),&(v161_7))
            };
            drop(v160_5);
            let v160_9: Space = intersect(&(*CONSTANT_1),&(v160_2));
            drop(v160_2);
            let v160_10: Space = if has_head(&(v160_9)) { singleton(&[]) } else { Space::new() };
            drop(v160_9);
            let v160_12: Space = if (&(v160_10)).is_empty() { Space::new() } else {
              let v162_6: Path = concat_path(&(v159_6),&v155_20_cursor.path()[(v155_20_origin + 2)..(v155_20_origin + 3)]);
              let v162_11: Space = routine_23(c, &(v162_6), &v155_20_cursor);
              drop(v162_6);
              compose(&(v160_10),&(v162_11))
            };
            drop(v160_10);
            let v160_13: Space = unite(&(v160_8),&(v160_12));
            join_wrapped_into(&mut v159_7_write,&((v160_13).read_zipper()),&[]);
            }
            v155_20_cursor.ascend(1);
          }
          drop(v159_7_write);
          compose(&(v158_5),&(v159_7))
        };
        drop(v158_5);
        let v158_9: Space = intersect(&(*CONSTANT_1),&(v158_2));
        drop(v158_2);
        let v158_10: Space = if has_head(&(v158_9)) { singleton(&[]) } else { Space::new() };
        drop(v158_9);
        let v158_12: Space = if (&(v158_10)).is_empty() { Space::new() } else {
          let v163_6: Path = concat_path(&(v157_6),&v155_20_cursor.path()[(v155_20_origin + 1)..(v155_20_origin + 2)]);
          let mut v163_11 = Space::new();
          let mut v163_11_write = v163_11.write_zipper();
          for v163_11_byte in v155_20_cursor.child_mask().iter() {
            v155_20_cursor.descend_to_existing_byte(v163_11_byte);
            {
            let v164_2: Space = singleton(&v155_20_cursor.path()[(v155_20_origin + 2)..(v155_20_origin + 3)]);
            let v164_3: Space = intersect(&(*CONSTANT_1),&(v164_2));
            let v164_4: Space = if has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
            drop(v164_3);
            let v164_5: Space = subtract(&(*CONSTANT_0),&(v164_4));
            drop(v164_4);
            let v164_8: Space = if (&(v164_5)).is_empty() { Space::new() } else {
              let v165_6: Path = concat_path(&(v163_6),&v155_20_cursor.path()[(v155_20_origin + 2)..(v155_20_origin + 3)]);
              let v165_7: Space = routine_22(c, &(v165_6), &v155_20_cursor);
              compose(&(v164_5),&(v165_7))
            };
            drop(v164_5);
            let v164_9: Space = intersect(&(*CONSTANT_1),&(v164_2));
            drop(v164_2);
            let v164_10: Space = if has_head(&(v164_9)) { singleton(&[]) } else { Space::new() };
            drop(v164_9);
            let v164_12: Space = if (&(v164_10)).is_empty() { Space::new() } else {
              let v166_6: Path = concat_path(&(v163_6),&v155_20_cursor.path()[(v155_20_origin + 2)..(v155_20_origin + 3)]);
              let v166_11: Space = routine_15(c, &(v166_6), &v155_20_cursor);
              drop(v166_6);
              compose(&(v164_10),&(v166_11))
            };
            drop(v164_10);
            let v164_13: Space = unite(&(v164_8),&(v164_12));
            join_wrapped_into(&mut v163_11_write,&((v164_13).read_zipper()),&[]);
            }
            v155_20_cursor.ascend(1);
          }
          drop(v163_11_write);
          drop(v163_6);
          compose(&(v158_10),&(v163_11))
        };
        drop(v158_10);
        let v158_13: Space = unite(&(v158_8),&(v158_12));
        join_wrapped_into(&mut v157_7_write,&((v158_13).read_zipper()),&[]);
        }
        v155_20_cursor.ascend(1);
      }
      drop(v157_7_write);
      compose(&(v156_5),&(v157_7))
    };
    drop(v156_5);
    let v156_9: Space = intersect(&(*CONSTANT_1),&(v156_2));
    drop(v156_2);
    let v156_10: Space = if has_head(&(v156_9)) { singleton(&[]) } else { Space::new() };
    drop(v156_9);
    let v156_12: Space = if (&(v156_10)).is_empty() { Space::new() } else {
      let v167_6: Path = concat_path(&(*p0),&v155_20_cursor.path()[v155_20_origin..(v155_20_origin + 1)]);
      let mut v167_11 = Space::new();
      let mut v167_11_write = v167_11.write_zipper();
      for v167_11_byte in v155_20_cursor.child_mask().iter() {
        v155_20_cursor.descend_to_existing_byte(v167_11_byte);
        {
        let v168_2: Space = singleton(&v155_20_cursor.path()[(v155_20_origin + 1)..(v155_20_origin + 2)]);
        let v168_3: Space = intersect(&(*CONSTANT_1),&(v168_2));
        let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
        drop(v168_3);
        let v168_5: Space = subtract(&(*CONSTANT_0),&(v168_4));
        drop(v168_4);
        let v168_8: Space = if (&(v168_5)).is_empty() { Space::new() } else {
          let v169_6: Path = concat_path(&(v167_6),&v155_20_cursor.path()[(v155_20_origin + 1)..(v155_20_origin + 2)]);
          let mut v169_7 = Space::new();
          let mut v169_7_write = v169_7.write_zipper();
          for v169_7_byte in v155_20_cursor.child_mask().iter() {
            v155_20_cursor.descend_to_existing_byte(v169_7_byte);
            {
            let v170_2: Space = singleton(&v155_20_cursor.path()[(v155_20_origin + 2)..(v155_20_origin + 3)]);
            let v170_3: Space = intersect(&(*CONSTANT_1),&(v170_2));
            let v170_4: Space = if has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
            drop(v170_3);
            let v170_5: Space = subtract(&(*CONSTANT_0),&(v170_4));
            drop(v170_4);
            let v170_8: Space = if (&(v170_5)).is_empty() { Space::new() } else {
              let v171_6: Path = concat_path(&(v169_6),&v155_20_cursor.path()[(v155_20_origin + 2)..(v155_20_origin + 3)]);
              let v171_7: Space = routine_22(c, &(v171_6), &v155_20_cursor);
              compose(&(v170_5),&(v171_7))
            };
            drop(v170_5);
            let v170_9: Space = intersect(&(*CONSTANT_1),&(v170_2));
            drop(v170_2);
            let v170_10: Space = if has_head(&(v170_9)) { singleton(&[]) } else { Space::new() };
            drop(v170_9);
            let v170_12: Space = if (&(v170_10)).is_empty() { Space::new() } else {
              let v172_6: Path = concat_path(&(v169_6),&v155_20_cursor.path()[(v155_20_origin + 2)..(v155_20_origin + 3)]);
              let v172_11: Space = routine_23(c, &(v172_6), &v155_20_cursor);
              drop(v172_6);
              compose(&(v170_10),&(v172_11))
            };
            drop(v170_10);
            let v170_13: Space = unite(&(v170_8),&(v170_12));
            join_wrapped_into(&mut v169_7_write,&((v170_13).read_zipper()),&[]);
            }
            v155_20_cursor.ascend(1);
          }
          drop(v169_7_write);
          drop(v169_6);
          compose(&(v168_5),&(v169_7))
        };
        drop(v168_5);
        let v168_9: Space = intersect(&(*CONSTANT_1),&(v168_2));
        drop(v168_2);
        let v168_10: Space = if has_head(&(v168_9)) { singleton(&[]) } else { Space::new() };
        drop(v168_9);
        let v168_11: Space = compose(&(v168_10),&v155_20_cursor);
        drop(v168_10);
        let v168_12: Space = unite(&(v168_8),&(v168_11));
        drop(v168_11);
        join_wrapped_into(&mut v167_11_write,&((v168_12).read_zipper()),&[]);
        }
        v155_20_cursor.ascend(1);
      }
      drop(v167_11_write);
      drop(v167_6);
      compose(&(v156_10),&(v167_11))
    };
    drop(v156_10);
    let v156_13: Space = unite(&(v156_8),&(v156_12));
    join_wrapped_into(&mut v155_20_write,&((v156_13).read_zipper()),&[]);
    }
    v155_20_cursor.ascend(1);
  }
  drop(v155_20_cursor);
  drop(v155_20_write);
  (v155_20).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v173_14 = Space::new();
  let mut v173_14_write = v173_14.write_zipper();
  let mut v173_14_cursor = (*s0).read_zipper();
  let v173_14_origin = v173_14_cursor.path().len();
  for v173_14_byte in v173_14_cursor.child_mask().iter() {
    v173_14_cursor.descend_to_existing_byte(v173_14_byte);
    {
    let v174_2: Space = singleton(&v173_14_cursor.path()[v173_14_origin..(v173_14_origin + 1)]);
    let v174_3: Space = intersect(&(*CONSTANT_1),&(v174_2));
    let v174_4: Space = if has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
    drop(v174_3);
    let v174_5: Space = subtract(&(*CONSTANT_0),&(v174_4));
    drop(v174_4);
    let v174_8: Space = if (&(v174_5)).is_empty() { Space::new() } else {
      let v175_6: Path = concat_path(&(*p0),&v173_14_cursor.path()[v173_14_origin..(v173_14_origin + 1)]);
      let mut v175_7 = Space::new();
      let mut v175_7_write = v175_7.write_zipper();
      for v175_7_byte in v173_14_cursor.child_mask().iter() {
        v173_14_cursor.descend_to_existing_byte(v175_7_byte);
        {
        let v176_2: Space = singleton(&v173_14_cursor.path()[(v173_14_origin + 1)..(v173_14_origin + 2)]);
        let v176_3: Space = intersect(&(*CONSTANT_1),&(v176_2));
        let v176_4: Space = if has_head(&(v176_3)) { singleton(&[]) } else { Space::new() };
        drop(v176_3);
        let v176_5: Space = subtract(&(*CONSTANT_0),&(v176_4));
        drop(v176_4);
        let v176_8: Space = if (&(v176_5)).is_empty() { Space::new() } else {
          let v177_6: Path = concat_path(&(v175_6),&v173_14_cursor.path()[(v173_14_origin + 1)..(v173_14_origin + 2)]);
          let mut v177_7 = Space::new();
          let mut v177_7_write = v177_7.write_zipper();
          for v177_7_byte in v173_14_cursor.child_mask().iter() {
            v173_14_cursor.descend_to_existing_byte(v177_7_byte);
            {
            let v178_2: Space = singleton(&v173_14_cursor.path()[(v173_14_origin + 2)..(v173_14_origin + 3)]);
            let v178_3: Space = intersect(&(*CONSTANT_1),&(v178_2));
            let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
            drop(v178_3);
            let v178_5: Space = subtract(&(*CONSTANT_0),&(v178_4));
            drop(v178_4);
            let v178_8: Space = if (&(v178_5)).is_empty() { Space::new() } else {
              let v179_6: Path = concat_path(&(v177_6),&v173_14_cursor.path()[(v173_14_origin + 2)..(v173_14_origin + 3)]);
              let v179_7: Space = routine_22(c, &(v179_6), &v173_14_cursor);
              compose(&(v178_5),&(v179_7))
            };
            drop(v178_5);
            let v178_9: Space = intersect(&(*CONSTANT_1),&(v178_2));
            drop(v178_2);
            let v178_10: Space = if has_head(&(v178_9)) { singleton(&[]) } else { Space::new() };
            drop(v178_9);
            let v178_12: Space = if (&(v178_10)).is_empty() { Space::new() } else {
              let v180_6: Path = concat_path(&(v177_6),&v173_14_cursor.path()[(v173_14_origin + 2)..(v173_14_origin + 3)]);
              let v180_11: Space = routine_23(c, &(v180_6), &v173_14_cursor);
              drop(v180_6);
              compose(&(v178_10),&(v180_11))
            };
            drop(v178_10);
            let v178_13: Space = unite(&(v178_8),&(v178_12));
            join_wrapped_into(&mut v177_7_write,&((v178_13).read_zipper()),&[]);
            }
            v173_14_cursor.ascend(1);
          }
          drop(v177_7_write);
          compose(&(v176_5),&(v177_7))
        };
        drop(v176_5);
        let v176_9: Space = intersect(&(*CONSTANT_1),&(v176_2));
        drop(v176_2);
        let v176_10: Space = if has_head(&(v176_9)) { singleton(&[]) } else { Space::new() };
        drop(v176_9);
        let v176_12: Space = if (&(v176_10)).is_empty() { Space::new() } else {
          let v181_6: Path = concat_path(&(v175_6),&v173_14_cursor.path()[(v173_14_origin + 1)..(v173_14_origin + 2)]);
          let mut v181_11 = Space::new();
          let mut v181_11_write = v181_11.write_zipper();
          for v181_11_byte in v173_14_cursor.child_mask().iter() {
            v173_14_cursor.descend_to_existing_byte(v181_11_byte);
            {
            let v182_2: Space = singleton(&v173_14_cursor.path()[(v173_14_origin + 2)..(v173_14_origin + 3)]);
            let v182_3: Space = intersect(&(*CONSTANT_1),&(v182_2));
            let v182_4: Space = if has_head(&(v182_3)) { singleton(&[]) } else { Space::new() };
            drop(v182_3);
            let v182_5: Space = subtract(&(*CONSTANT_0),&(v182_4));
            drop(v182_4);
            let v182_8: Space = if (&(v182_5)).is_empty() { Space::new() } else {
              let v183_6: Path = concat_path(&(v181_6),&v173_14_cursor.path()[(v173_14_origin + 2)..(v173_14_origin + 3)]);
              let v183_7: Space = routine_22(c, &(v183_6), &v173_14_cursor);
              compose(&(v182_5),&(v183_7))
            };
            drop(v182_5);
            let v182_9: Space = intersect(&(*CONSTANT_1),&(v182_2));
            drop(v182_2);
            let v182_10: Space = if has_head(&(v182_9)) { singleton(&[]) } else { Space::new() };
            drop(v182_9);
            let v182_12: Space = if (&(v182_10)).is_empty() { Space::new() } else {
              let v184_6: Path = concat_path(&(v181_6),&v173_14_cursor.path()[(v173_14_origin + 2)..(v173_14_origin + 3)]);
              let v184_11: Space = routine_15(c, &(v184_6), &v173_14_cursor);
              drop(v184_6);
              compose(&(v182_10),&(v184_11))
            };
            drop(v182_10);
            let v182_13: Space = unite(&(v182_8),&(v182_12));
            join_wrapped_into(&mut v181_11_write,&((v182_13).read_zipper()),&[]);
            }
            v173_14_cursor.ascend(1);
          }
          drop(v181_11_write);
          drop(v181_6);
          compose(&(v176_10),&(v181_11))
        };
        drop(v176_10);
        let v176_13: Space = unite(&(v176_8),&(v176_12));
        join_wrapped_into(&mut v175_7_write,&((v176_13).read_zipper()),&[]);
        }
        v173_14_cursor.ascend(1);
      }
      drop(v175_7_write);
      drop(v175_6);
      compose(&(v174_5),&(v175_7))
    };
    drop(v174_5);
    let v174_9: Space = intersect(&(*CONSTANT_1),&(v174_2));
    drop(v174_2);
    let v174_10: Space = if has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
    drop(v174_9);
    let v174_11: Space = compose(&(v174_10),&v173_14_cursor);
    drop(v174_10);
    let v174_12: Space = unite(&(v174_8),&(v174_11));
    drop(v174_11);
    join_wrapped_into(&mut v173_14_write,&((v174_12).read_zipper()),&[]);
    }
    v173_14_cursor.ascend(1);
  }
  drop(v173_14_cursor);
  drop(v173_14_write);
  (v173_14).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v185_20 = Space::new();
  let mut v185_20_write = v185_20.write_zipper();
  let mut v185_20_cursor = (*s0).read_zipper();
  let v185_20_origin = v185_20_cursor.path().len();
  for v185_20_byte in v185_20_cursor.child_mask().iter() {
    v185_20_cursor.descend_to_existing_byte(v185_20_byte);
    {
    let v186_2: Space = singleton(&v185_20_cursor.path()[v185_20_origin..(v185_20_origin + 1)]);
    let v186_3: Space = intersect(&(*CONSTANT_1),&(v186_2));
    let v186_4: Space = if has_head(&(v186_3)) { singleton(&[]) } else { Space::new() };
    drop(v186_3);
    let v186_5: Space = subtract(&(*CONSTANT_0),&(v186_4));
    drop(v186_4);
    let v186_8: Space = if (&(v186_5)).is_empty() { Space::new() } else {
      let v187_6: Path = concat_path(&(*p0),&v185_20_cursor.path()[v185_20_origin..(v185_20_origin + 1)]);
      let mut v187_7 = Space::new();
      let mut v187_7_write = v187_7.write_zipper();
      for v187_7_byte in v185_20_cursor.child_mask().iter() {
        v185_20_cursor.descend_to_existing_byte(v187_7_byte);
        {
        let v188_2: Space = singleton(&v185_20_cursor.path()[(v185_20_origin + 1)..(v185_20_origin + 2)]);
        let v188_3: Space = intersect(&(*CONSTANT_1),&(v188_2));
        let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
        drop(v188_3);
        let v188_5: Space = subtract(&(*CONSTANT_0),&(v188_4));
        drop(v188_4);
        let v188_8: Space = if (&(v188_5)).is_empty() { Space::new() } else {
          let v189_6: Path = concat_path(&(v187_6),&v185_20_cursor.path()[(v185_20_origin + 1)..(v185_20_origin + 2)]);
          let mut v189_7 = Space::new();
          let mut v189_7_write = v189_7.write_zipper();
          for v189_7_byte in v185_20_cursor.child_mask().iter() {
            v185_20_cursor.descend_to_existing_byte(v189_7_byte);
            {
            let v190_2: Space = singleton(&v185_20_cursor.path()[(v185_20_origin + 2)..(v185_20_origin + 3)]);
            let v190_3: Space = intersect(&(*CONSTANT_1),&(v190_2));
            let v190_4: Space = if has_head(&(v190_3)) { singleton(&[]) } else { Space::new() };
            drop(v190_3);
            let v190_5: Space = subtract(&(*CONSTANT_0),&(v190_4));
            drop(v190_4);
            let v190_8: Space = if (&(v190_5)).is_empty() { Space::new() } else {
              let v191_6: Path = concat_path(&(v189_6),&v185_20_cursor.path()[(v185_20_origin + 2)..(v185_20_origin + 3)]);
              let v191_7: Space = routine_24(c, &(v191_6), &v185_20_cursor);
              compose(&(v190_5),&(v191_7))
            };
            drop(v190_5);
            let v190_9: Space = intersect(&(*CONSTANT_1),&(v190_2));
            drop(v190_2);
            let v190_10: Space = if has_head(&(v190_9)) { singleton(&[]) } else { Space::new() };
            drop(v190_9);
            let v190_12: Space = if (&(v190_10)).is_empty() { Space::new() } else {
              let v192_6: Path = concat_path(&(v189_6),&v185_20_cursor.path()[(v185_20_origin + 2)..(v185_20_origin + 3)]);
              let v192_11: Space = routine_25(c, &(v192_6), &v185_20_cursor);
              drop(v192_6);
              compose(&(v190_10),&(v192_11))
            };
            drop(v190_10);
            let v190_13: Space = unite(&(v190_8),&(v190_12));
            join_wrapped_into(&mut v189_7_write,&((v190_13).read_zipper()),&[]);
            }
            v185_20_cursor.ascend(1);
          }
          drop(v189_7_write);
          compose(&(v188_5),&(v189_7))
        };
        drop(v188_5);
        let v188_9: Space = intersect(&(*CONSTANT_1),&(v188_2));
        drop(v188_2);
        let v188_10: Space = if has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
        drop(v188_9);
        let v188_12: Space = if (&(v188_10)).is_empty() { Space::new() } else {
          let v193_6: Path = concat_path(&(v187_6),&v185_20_cursor.path()[(v185_20_origin + 1)..(v185_20_origin + 2)]);
          let mut v193_11 = Space::new();
          let mut v193_11_write = v193_11.write_zipper();
          for v193_11_byte in v185_20_cursor.child_mask().iter() {
            v185_20_cursor.descend_to_existing_byte(v193_11_byte);
            {
            let v194_2: Space = singleton(&v185_20_cursor.path()[(v185_20_origin + 2)..(v185_20_origin + 3)]);
            let v194_3: Space = intersect(&(*CONSTANT_1),&(v194_2));
            let v194_4: Space = if has_head(&(v194_3)) { singleton(&[]) } else { Space::new() };
            drop(v194_3);
            let v194_5: Space = subtract(&(*CONSTANT_0),&(v194_4));
            drop(v194_4);
            let v194_8: Space = if (&(v194_5)).is_empty() { Space::new() } else {
              let v195_6: Path = concat_path(&(v193_6),&v185_20_cursor.path()[(v185_20_origin + 2)..(v185_20_origin + 3)]);
              let v195_7: Space = routine_24(c, &(v195_6), &v185_20_cursor);
              compose(&(v194_5),&(v195_7))
            };
            drop(v194_5);
            let v194_9: Space = intersect(&(*CONSTANT_1),&(v194_2));
            drop(v194_2);
            let v194_10: Space = if has_head(&(v194_9)) { singleton(&[]) } else { Space::new() };
            drop(v194_9);
            let v194_12: Space = if (&(v194_10)).is_empty() { Space::new() } else {
              let v196_6: Path = concat_path(&(v193_6),&v185_20_cursor.path()[(v185_20_origin + 2)..(v185_20_origin + 3)]);
              let v196_11: Space = routine_12(c, &(v196_6), &v185_20_cursor);
              drop(v196_6);
              compose(&(v194_10),&(v196_11))
            };
            drop(v194_10);
            let v194_13: Space = unite(&(v194_8),&(v194_12));
            join_wrapped_into(&mut v193_11_write,&((v194_13).read_zipper()),&[]);
            }
            v185_20_cursor.ascend(1);
          }
          drop(v193_11_write);
          drop(v193_6);
          compose(&(v188_10),&(v193_11))
        };
        drop(v188_10);
        let v188_13: Space = unite(&(v188_8),&(v188_12));
        join_wrapped_into(&mut v187_7_write,&((v188_13).read_zipper()),&[]);
        }
        v185_20_cursor.ascend(1);
      }
      drop(v187_7_write);
      compose(&(v186_5),&(v187_7))
    };
    drop(v186_5);
    let v186_9: Space = intersect(&(*CONSTANT_1),&(v186_2));
    drop(v186_2);
    let v186_10: Space = if has_head(&(v186_9)) { singleton(&[]) } else { Space::new() };
    drop(v186_9);
    let v186_12: Space = if (&(v186_10)).is_empty() { Space::new() } else {
      let v197_6: Path = concat_path(&(*p0),&v185_20_cursor.path()[v185_20_origin..(v185_20_origin + 1)]);
      let mut v197_11 = Space::new();
      let mut v197_11_write = v197_11.write_zipper();
      for v197_11_byte in v185_20_cursor.child_mask().iter() {
        v185_20_cursor.descend_to_existing_byte(v197_11_byte);
        {
        let v198_2: Space = singleton(&v185_20_cursor.path()[(v185_20_origin + 1)..(v185_20_origin + 2)]);
        let v198_3: Space = intersect(&(*CONSTANT_1),&(v198_2));
        let v198_4: Space = if has_head(&(v198_3)) { singleton(&[]) } else { Space::new() };
        drop(v198_3);
        let v198_5: Space = subtract(&(*CONSTANT_0),&(v198_4));
        drop(v198_4);
        let v198_8: Space = if (&(v198_5)).is_empty() { Space::new() } else {
          let v199_6: Path = concat_path(&(v197_6),&v185_20_cursor.path()[(v185_20_origin + 1)..(v185_20_origin + 2)]);
          let mut v199_7 = Space::new();
          let mut v199_7_write = v199_7.write_zipper();
          for v199_7_byte in v185_20_cursor.child_mask().iter() {
            v185_20_cursor.descend_to_existing_byte(v199_7_byte);
            {
            let v200_2: Space = singleton(&v185_20_cursor.path()[(v185_20_origin + 2)..(v185_20_origin + 3)]);
            let v200_3: Space = intersect(&(*CONSTANT_1),&(v200_2));
            let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
            drop(v200_3);
            let v200_5: Space = subtract(&(*CONSTANT_0),&(v200_4));
            drop(v200_4);
            let v200_8: Space = if (&(v200_5)).is_empty() { Space::new() } else {
              let v201_6: Path = concat_path(&(v199_6),&v185_20_cursor.path()[(v185_20_origin + 2)..(v185_20_origin + 3)]);
              let v201_7: Space = routine_24(c, &(v201_6), &v185_20_cursor);
              compose(&(v200_5),&(v201_7))
            };
            drop(v200_5);
            let v200_9: Space = intersect(&(*CONSTANT_1),&(v200_2));
            drop(v200_2);
            let v200_10: Space = if has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
            drop(v200_9);
            let v200_12: Space = if (&(v200_10)).is_empty() { Space::new() } else {
              let v202_6: Path = concat_path(&(v199_6),&v185_20_cursor.path()[(v185_20_origin + 2)..(v185_20_origin + 3)]);
              let v202_11: Space = routine_25(c, &(v202_6), &v185_20_cursor);
              drop(v202_6);
              compose(&(v200_10),&(v202_11))
            };
            drop(v200_10);
            let v200_13: Space = unite(&(v200_8),&(v200_12));
            join_wrapped_into(&mut v199_7_write,&((v200_13).read_zipper()),&[]);
            }
            v185_20_cursor.ascend(1);
          }
          drop(v199_7_write);
          drop(v199_6);
          compose(&(v198_5),&(v199_7))
        };
        drop(v198_5);
        let v198_9: Space = intersect(&(*CONSTANT_1),&(v198_2));
        drop(v198_2);
        let v198_10: Space = if has_head(&(v198_9)) { singleton(&[]) } else { Space::new() };
        drop(v198_9);
        let v198_11: Space = compose(&(v198_10),&v185_20_cursor);
        drop(v198_10);
        let v198_12: Space = unite(&(v198_8),&(v198_11));
        drop(v198_11);
        join_wrapped_into(&mut v197_11_write,&((v198_12).read_zipper()),&[]);
        }
        v185_20_cursor.ascend(1);
      }
      drop(v197_11_write);
      drop(v197_6);
      compose(&(v186_10),&(v197_11))
    };
    drop(v186_10);
    let v186_13: Space = unite(&(v186_8),&(v186_12));
    join_wrapped_into(&mut v185_20_write,&((v186_13).read_zipper()),&[]);
    }
    v185_20_cursor.ascend(1);
  }
  drop(v185_20_cursor);
  drop(v185_20_write);
  (v185_20).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v203_14 = Space::new();
  let mut v203_14_write = v203_14.write_zipper();
  let mut v203_14_cursor = (*s0).read_zipper();
  let v203_14_origin = v203_14_cursor.path().len();
  for v203_14_byte in v203_14_cursor.child_mask().iter() {
    v203_14_cursor.descend_to_existing_byte(v203_14_byte);
    {
    let v204_2: Space = singleton(&v203_14_cursor.path()[v203_14_origin..(v203_14_origin + 1)]);
    let v204_3: Space = intersect(&(*CONSTANT_1),&(v204_2));
    let v204_4: Space = if has_head(&(v204_3)) { singleton(&[]) } else { Space::new() };
    drop(v204_3);
    let v204_5: Space = subtract(&(*CONSTANT_0),&(v204_4));
    drop(v204_4);
    let v204_8: Space = if (&(v204_5)).is_empty() { Space::new() } else {
      let v205_6: Path = concat_path(&(*p0),&v203_14_cursor.path()[v203_14_origin..(v203_14_origin + 1)]);
      let mut v205_7 = Space::new();
      let mut v205_7_write = v205_7.write_zipper();
      for v205_7_byte in v203_14_cursor.child_mask().iter() {
        v203_14_cursor.descend_to_existing_byte(v205_7_byte);
        {
        let v206_2: Space = singleton(&v203_14_cursor.path()[(v203_14_origin + 1)..(v203_14_origin + 2)]);
        let v206_3: Space = intersect(&(*CONSTANT_1),&(v206_2));
        let v206_4: Space = if has_head(&(v206_3)) { singleton(&[]) } else { Space::new() };
        drop(v206_3);
        let v206_5: Space = subtract(&(*CONSTANT_0),&(v206_4));
        drop(v206_4);
        let v206_8: Space = if (&(v206_5)).is_empty() { Space::new() } else {
          let v207_6: Path = concat_path(&(v205_6),&v203_14_cursor.path()[(v203_14_origin + 1)..(v203_14_origin + 2)]);
          let mut v207_7 = Space::new();
          let mut v207_7_write = v207_7.write_zipper();
          for v207_7_byte in v203_14_cursor.child_mask().iter() {
            v203_14_cursor.descend_to_existing_byte(v207_7_byte);
            {
            let v208_2: Space = singleton(&v203_14_cursor.path()[(v203_14_origin + 2)..(v203_14_origin + 3)]);
            let v208_3: Space = intersect(&(*CONSTANT_1),&(v208_2));
            let v208_4: Space = if has_head(&(v208_3)) { singleton(&[]) } else { Space::new() };
            drop(v208_3);
            let v208_5: Space = subtract(&(*CONSTANT_0),&(v208_4));
            drop(v208_4);
            let v208_8: Space = if (&(v208_5)).is_empty() { Space::new() } else {
              let v209_6: Path = concat_path(&(v207_6),&v203_14_cursor.path()[(v203_14_origin + 2)..(v203_14_origin + 3)]);
              let v209_7: Space = routine_24(c, &(v209_6), &v203_14_cursor);
              compose(&(v208_5),&(v209_7))
            };
            drop(v208_5);
            let v208_9: Space = intersect(&(*CONSTANT_1),&(v208_2));
            drop(v208_2);
            let v208_10: Space = if has_head(&(v208_9)) { singleton(&[]) } else { Space::new() };
            drop(v208_9);
            let v208_12: Space = if (&(v208_10)).is_empty() { Space::new() } else {
              let v210_6: Path = concat_path(&(v207_6),&v203_14_cursor.path()[(v203_14_origin + 2)..(v203_14_origin + 3)]);
              let v210_11: Space = routine_25(c, &(v210_6), &v203_14_cursor);
              drop(v210_6);
              compose(&(v208_10),&(v210_11))
            };
            drop(v208_10);
            let v208_13: Space = unite(&(v208_8),&(v208_12));
            join_wrapped_into(&mut v207_7_write,&((v208_13).read_zipper()),&[]);
            }
            v203_14_cursor.ascend(1);
          }
          drop(v207_7_write);
          compose(&(v206_5),&(v207_7))
        };
        drop(v206_5);
        let v206_9: Space = intersect(&(*CONSTANT_1),&(v206_2));
        drop(v206_2);
        let v206_10: Space = if has_head(&(v206_9)) { singleton(&[]) } else { Space::new() };
        drop(v206_9);
        let v206_12: Space = if (&(v206_10)).is_empty() { Space::new() } else {
          let v211_6: Path = concat_path(&(v205_6),&v203_14_cursor.path()[(v203_14_origin + 1)..(v203_14_origin + 2)]);
          let mut v211_11 = Space::new();
          let mut v211_11_write = v211_11.write_zipper();
          for v211_11_byte in v203_14_cursor.child_mask().iter() {
            v203_14_cursor.descend_to_existing_byte(v211_11_byte);
            {
            let v212_2: Space = singleton(&v203_14_cursor.path()[(v203_14_origin + 2)..(v203_14_origin + 3)]);
            let v212_3: Space = intersect(&(*CONSTANT_1),&(v212_2));
            let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
            drop(v212_3);
            let v212_5: Space = subtract(&(*CONSTANT_0),&(v212_4));
            drop(v212_4);
            let v212_8: Space = if (&(v212_5)).is_empty() { Space::new() } else {
              let v213_6: Path = concat_path(&(v211_6),&v203_14_cursor.path()[(v203_14_origin + 2)..(v203_14_origin + 3)]);
              let v213_7: Space = routine_24(c, &(v213_6), &v203_14_cursor);
              compose(&(v212_5),&(v213_7))
            };
            drop(v212_5);
            let v212_9: Space = intersect(&(*CONSTANT_1),&(v212_2));
            drop(v212_2);
            let v212_10: Space = if has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
            drop(v212_9);
            let v212_12: Space = if (&(v212_10)).is_empty() { Space::new() } else {
              let v214_6: Path = concat_path(&(v211_6),&v203_14_cursor.path()[(v203_14_origin + 2)..(v203_14_origin + 3)]);
              let v214_11: Space = routine_12(c, &(v214_6), &v203_14_cursor);
              drop(v214_6);
              compose(&(v212_10),&(v214_11))
            };
            drop(v212_10);
            let v212_13: Space = unite(&(v212_8),&(v212_12));
            join_wrapped_into(&mut v211_11_write,&((v212_13).read_zipper()),&[]);
            }
            v203_14_cursor.ascend(1);
          }
          drop(v211_11_write);
          drop(v211_6);
          compose(&(v206_10),&(v211_11))
        };
        drop(v206_10);
        let v206_13: Space = unite(&(v206_8),&(v206_12));
        join_wrapped_into(&mut v205_7_write,&((v206_13).read_zipper()),&[]);
        }
        v203_14_cursor.ascend(1);
      }
      drop(v205_7_write);
      drop(v205_6);
      compose(&(v204_5),&(v205_7))
    };
    drop(v204_5);
    let v204_9: Space = intersect(&(*CONSTANT_1),&(v204_2));
    drop(v204_2);
    let v204_10: Space = if has_head(&(v204_9)) { singleton(&[]) } else { Space::new() };
    drop(v204_9);
    let v204_11: Space = compose(&(v204_10),&v203_14_cursor);
    drop(v204_10);
    let v204_12: Space = unite(&(v204_8),&(v204_11));
    drop(v204_11);
    join_wrapped_into(&mut v203_14_write,&((v204_12).read_zipper()),&[]);
    }
    v203_14_cursor.ascend(1);
  }
  drop(v203_14_cursor);
  drop(v203_14_write);
  (v203_14).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v216_20 = Space::new();
  let mut v216_20_write = v216_20.write_zipper();
  let mut v216_20_cursor = (*s0).read_zipper();
  let v216_20_origin = v216_20_cursor.path().len();
  for v216_20_byte in v216_20_cursor.child_mask().iter() {
    v216_20_cursor.descend_to_existing_byte(v216_20_byte);
    {
    let v217_2: Space = singleton(&v216_20_cursor.path()[v216_20_origin..(v216_20_origin + 1)]);
    let v217_3: Space = intersect(&(*CONSTANT_1),&(v217_2));
    let v217_4: Space = if has_head(&(v217_3)) { singleton(&[]) } else { Space::new() };
    drop(v217_3);
    let v217_5: Space = subtract(&(*CONSTANT_0),&(v217_4));
    drop(v217_4);
    let v217_8: Space = if (&(v217_5)).is_empty() { Space::new() } else {
      let v218_6: Path = concat_path(&(*p0),&v216_20_cursor.path()[v216_20_origin..(v216_20_origin + 1)]);
      let mut v218_7 = Space::new();
      let mut v218_7_write = v218_7.write_zipper();
      for v218_7_byte in v216_20_cursor.child_mask().iter() {
        v216_20_cursor.descend_to_existing_byte(v218_7_byte);
        {
        let v219_2: Space = singleton(&v216_20_cursor.path()[(v216_20_origin + 1)..(v216_20_origin + 2)]);
        let v219_3: Space = intersect(&(*CONSTANT_1),&(v219_2));
        let v219_4: Space = if has_head(&(v219_3)) { singleton(&[]) } else { Space::new() };
        drop(v219_3);
        let v219_5: Space = subtract(&(*CONSTANT_0),&(v219_4));
        drop(v219_4);
        let v219_8: Space = if (&(v219_5)).is_empty() { Space::new() } else {
          let v220_6: Path = concat_path(&(v218_6),&v216_20_cursor.path()[(v216_20_origin + 1)..(v216_20_origin + 2)]);
          let mut v220_7 = Space::new();
          let mut v220_7_write = v220_7.write_zipper();
          for v220_7_byte in v216_20_cursor.child_mask().iter() {
            v216_20_cursor.descend_to_existing_byte(v220_7_byte);
            {
            let v221_2: Space = singleton(&v216_20_cursor.path()[(v216_20_origin + 2)..(v216_20_origin + 3)]);
            let v221_3: Space = intersect(&(*CONSTANT_1),&(v221_2));
            let v221_4: Space = if has_head(&(v221_3)) { singleton(&[]) } else { Space::new() };
            drop(v221_3);
            let v221_5: Space = subtract(&(*CONSTANT_0),&(v221_4));
            drop(v221_4);
            let v221_8: Space = if (&(v221_5)).is_empty() { Space::new() } else {
              let v222_6: Path = concat_path(&(v220_6),&v216_20_cursor.path()[(v216_20_origin + 2)..(v216_20_origin + 3)]);
              let v222_7: Space = routine_26(c, &(v222_6), &v216_20_cursor);
              compose(&(v221_5),&(v222_7))
            };
            drop(v221_5);
            let v221_9: Space = intersect(&(*CONSTANT_1),&(v221_2));
            drop(v221_2);
            let v221_10: Space = if has_head(&(v221_9)) { singleton(&[]) } else { Space::new() };
            drop(v221_9);
            let v221_12: Space = if (&(v221_10)).is_empty() { Space::new() } else {
              let v223_6: Path = concat_path(&(v220_6),&v216_20_cursor.path()[(v216_20_origin + 2)..(v216_20_origin + 3)]);
              let v223_11: Space = routine_27(c, &(v223_6), &v216_20_cursor);
              drop(v223_6);
              compose(&(v221_10),&(v223_11))
            };
            drop(v221_10);
            let v221_13: Space = unite(&(v221_8),&(v221_12));
            join_wrapped_into(&mut v220_7_write,&((v221_13).read_zipper()),&[]);
            }
            v216_20_cursor.ascend(1);
          }
          drop(v220_7_write);
          compose(&(v219_5),&(v220_7))
        };
        drop(v219_5);
        let v219_9: Space = intersect(&(*CONSTANT_1),&(v219_2));
        drop(v219_2);
        let v219_10: Space = if has_head(&(v219_9)) { singleton(&[]) } else { Space::new() };
        drop(v219_9);
        let v219_12: Space = if (&(v219_10)).is_empty() { Space::new() } else {
          let v224_6: Path = concat_path(&(v218_6),&v216_20_cursor.path()[(v216_20_origin + 1)..(v216_20_origin + 2)]);
          let mut v224_11 = Space::new();
          let mut v224_11_write = v224_11.write_zipper();
          for v224_11_byte in v216_20_cursor.child_mask().iter() {
            v216_20_cursor.descend_to_existing_byte(v224_11_byte);
            {
            let v225_2: Space = singleton(&v216_20_cursor.path()[(v216_20_origin + 2)..(v216_20_origin + 3)]);
            let v225_3: Space = intersect(&(*CONSTANT_1),&(v225_2));
            let v225_4: Space = if has_head(&(v225_3)) { singleton(&[]) } else { Space::new() };
            drop(v225_3);
            let v225_5: Space = subtract(&(*CONSTANT_0),&(v225_4));
            drop(v225_4);
            let v225_8: Space = if (&(v225_5)).is_empty() { Space::new() } else {
              let v226_6: Path = concat_path(&(v224_6),&v216_20_cursor.path()[(v216_20_origin + 2)..(v216_20_origin + 3)]);
              let v226_7: Space = routine_26(c, &(v226_6), &v216_20_cursor);
              compose(&(v225_5),&(v226_7))
            };
            drop(v225_5);
            let v225_9: Space = intersect(&(*CONSTANT_1),&(v225_2));
            drop(v225_2);
            let v225_10: Space = if has_head(&(v225_9)) { singleton(&[]) } else { Space::new() };
            drop(v225_9);
            let v225_12: Space = if (&(v225_10)).is_empty() { Space::new() } else {
              let v227_6: Path = concat_path(&(v224_6),&v216_20_cursor.path()[(v216_20_origin + 2)..(v216_20_origin + 3)]);
              let v227_11: Space = routine_15(c, &(v227_6), &v216_20_cursor);
              drop(v227_6);
              compose(&(v225_10),&(v227_11))
            };
            drop(v225_10);
            let v225_13: Space = unite(&(v225_8),&(v225_12));
            join_wrapped_into(&mut v224_11_write,&((v225_13).read_zipper()),&[]);
            }
            v216_20_cursor.ascend(1);
          }
          drop(v224_11_write);
          drop(v224_6);
          compose(&(v219_10),&(v224_11))
        };
        drop(v219_10);
        let v219_13: Space = unite(&(v219_8),&(v219_12));
        join_wrapped_into(&mut v218_7_write,&((v219_13).read_zipper()),&[]);
        }
        v216_20_cursor.ascend(1);
      }
      drop(v218_7_write);
      compose(&(v217_5),&(v218_7))
    };
    drop(v217_5);
    let v217_9: Space = intersect(&(*CONSTANT_1),&(v217_2));
    drop(v217_2);
    let v217_10: Space = if has_head(&(v217_9)) { singleton(&[]) } else { Space::new() };
    drop(v217_9);
    let v217_12: Space = if (&(v217_10)).is_empty() { Space::new() } else {
      let v228_6: Path = concat_path(&(*p0),&v216_20_cursor.path()[v216_20_origin..(v216_20_origin + 1)]);
      let mut v228_11 = Space::new();
      let mut v228_11_write = v228_11.write_zipper();
      for v228_11_byte in v216_20_cursor.child_mask().iter() {
        v216_20_cursor.descend_to_existing_byte(v228_11_byte);
        {
        let v229_2: Space = singleton(&v216_20_cursor.path()[(v216_20_origin + 1)..(v216_20_origin + 2)]);
        let v229_3: Space = intersect(&(*CONSTANT_1),&(v229_2));
        let v229_4: Space = if has_head(&(v229_3)) { singleton(&[]) } else { Space::new() };
        drop(v229_3);
        let v229_5: Space = subtract(&(*CONSTANT_0),&(v229_4));
        drop(v229_4);
        let v229_8: Space = if (&(v229_5)).is_empty() { Space::new() } else {
          let v230_6: Path = concat_path(&(v228_6),&v216_20_cursor.path()[(v216_20_origin + 1)..(v216_20_origin + 2)]);
          let mut v230_7 = Space::new();
          let mut v230_7_write = v230_7.write_zipper();
          for v230_7_byte in v216_20_cursor.child_mask().iter() {
            v216_20_cursor.descend_to_existing_byte(v230_7_byte);
            {
            let v231_2: Space = singleton(&v216_20_cursor.path()[(v216_20_origin + 2)..(v216_20_origin + 3)]);
            let v231_3: Space = intersect(&(*CONSTANT_1),&(v231_2));
            let v231_4: Space = if has_head(&(v231_3)) { singleton(&[]) } else { Space::new() };
            drop(v231_3);
            let v231_5: Space = subtract(&(*CONSTANT_0),&(v231_4));
            drop(v231_4);
            let v231_8: Space = if (&(v231_5)).is_empty() { Space::new() } else {
              let v232_6: Path = concat_path(&(v230_6),&v216_20_cursor.path()[(v216_20_origin + 2)..(v216_20_origin + 3)]);
              let v232_7: Space = routine_26(c, &(v232_6), &v216_20_cursor);
              compose(&(v231_5),&(v232_7))
            };
            drop(v231_5);
            let v231_9: Space = intersect(&(*CONSTANT_1),&(v231_2));
            drop(v231_2);
            let v231_10: Space = if has_head(&(v231_9)) { singleton(&[]) } else { Space::new() };
            drop(v231_9);
            let v231_12: Space = if (&(v231_10)).is_empty() { Space::new() } else {
              let v233_6: Path = concat_path(&(v230_6),&v216_20_cursor.path()[(v216_20_origin + 2)..(v216_20_origin + 3)]);
              let v233_11: Space = routine_27(c, &(v233_6), &v216_20_cursor);
              drop(v233_6);
              compose(&(v231_10),&(v233_11))
            };
            drop(v231_10);
            let v231_13: Space = unite(&(v231_8),&(v231_12));
            join_wrapped_into(&mut v230_7_write,&((v231_13).read_zipper()),&[]);
            }
            v216_20_cursor.ascend(1);
          }
          drop(v230_7_write);
          drop(v230_6);
          compose(&(v229_5),&(v230_7))
        };
        drop(v229_5);
        let v229_9: Space = intersect(&(*CONSTANT_1),&(v229_2));
        drop(v229_2);
        let v229_10: Space = if has_head(&(v229_9)) { singleton(&[]) } else { Space::new() };
        drop(v229_9);
        let v229_11: Space = compose(&(v229_10),&v216_20_cursor);
        drop(v229_10);
        let v229_12: Space = unite(&(v229_8),&(v229_11));
        drop(v229_11);
        join_wrapped_into(&mut v228_11_write,&((v229_12).read_zipper()),&[]);
        }
        v216_20_cursor.ascend(1);
      }
      drop(v228_11_write);
      drop(v228_6);
      compose(&(v217_10),&(v228_11))
    };
    drop(v217_10);
    let v217_13: Space = unite(&(v217_8),&(v217_12));
    join_wrapped_into(&mut v216_20_write,&((v217_13).read_zipper()),&[]);
    }
    v216_20_cursor.ascend(1);
  }
  drop(v216_20_cursor);
  drop(v216_20_write);
  (v216_20).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v234_14 = Space::new();
  let mut v234_14_write = v234_14.write_zipper();
  let mut v234_14_cursor = (*s0).read_zipper();
  let v234_14_origin = v234_14_cursor.path().len();
  for v234_14_byte in v234_14_cursor.child_mask().iter() {
    v234_14_cursor.descend_to_existing_byte(v234_14_byte);
    {
    let v235_2: Space = singleton(&v234_14_cursor.path()[v234_14_origin..(v234_14_origin + 1)]);
    let v235_3: Space = intersect(&(*CONSTANT_1),&(v235_2));
    let v235_4: Space = if has_head(&(v235_3)) { singleton(&[]) } else { Space::new() };
    drop(v235_3);
    let v235_5: Space = subtract(&(*CONSTANT_0),&(v235_4));
    drop(v235_4);
    let v235_8: Space = if (&(v235_5)).is_empty() { Space::new() } else {
      let v236_6: Path = concat_path(&(*p0),&v234_14_cursor.path()[v234_14_origin..(v234_14_origin + 1)]);
      let mut v236_7 = Space::new();
      let mut v236_7_write = v236_7.write_zipper();
      for v236_7_byte in v234_14_cursor.child_mask().iter() {
        v234_14_cursor.descend_to_existing_byte(v236_7_byte);
        {
        let v237_2: Space = singleton(&v234_14_cursor.path()[(v234_14_origin + 1)..(v234_14_origin + 2)]);
        let v237_3: Space = intersect(&(*CONSTANT_1),&(v237_2));
        let v237_4: Space = if has_head(&(v237_3)) { singleton(&[]) } else { Space::new() };
        drop(v237_3);
        let v237_5: Space = subtract(&(*CONSTANT_0),&(v237_4));
        drop(v237_4);
        let v237_8: Space = if (&(v237_5)).is_empty() { Space::new() } else {
          let v238_6: Path = concat_path(&(v236_6),&v234_14_cursor.path()[(v234_14_origin + 1)..(v234_14_origin + 2)]);
          let mut v238_7 = Space::new();
          let mut v238_7_write = v238_7.write_zipper();
          for v238_7_byte in v234_14_cursor.child_mask().iter() {
            v234_14_cursor.descend_to_existing_byte(v238_7_byte);
            {
            let v239_2: Space = singleton(&v234_14_cursor.path()[(v234_14_origin + 2)..(v234_14_origin + 3)]);
            let v239_3: Space = intersect(&(*CONSTANT_1),&(v239_2));
            let v239_4: Space = if has_head(&(v239_3)) { singleton(&[]) } else { Space::new() };
            drop(v239_3);
            let v239_5: Space = subtract(&(*CONSTANT_0),&(v239_4));
            drop(v239_4);
            let v239_8: Space = if (&(v239_5)).is_empty() { Space::new() } else {
              let v240_6: Path = concat_path(&(v238_6),&v234_14_cursor.path()[(v234_14_origin + 2)..(v234_14_origin + 3)]);
              let v240_7: Space = routine_26(c, &(v240_6), &v234_14_cursor);
              compose(&(v239_5),&(v240_7))
            };
            drop(v239_5);
            let v239_9: Space = intersect(&(*CONSTANT_1),&(v239_2));
            drop(v239_2);
            let v239_10: Space = if has_head(&(v239_9)) { singleton(&[]) } else { Space::new() };
            drop(v239_9);
            let v239_12: Space = if (&(v239_10)).is_empty() { Space::new() } else {
              let v241_6: Path = concat_path(&(v238_6),&v234_14_cursor.path()[(v234_14_origin + 2)..(v234_14_origin + 3)]);
              let v241_11: Space = routine_27(c, &(v241_6), &v234_14_cursor);
              drop(v241_6);
              compose(&(v239_10),&(v241_11))
            };
            drop(v239_10);
            let v239_13: Space = unite(&(v239_8),&(v239_12));
            join_wrapped_into(&mut v238_7_write,&((v239_13).read_zipper()),&[]);
            }
            v234_14_cursor.ascend(1);
          }
          drop(v238_7_write);
          compose(&(v237_5),&(v238_7))
        };
        drop(v237_5);
        let v237_9: Space = intersect(&(*CONSTANT_1),&(v237_2));
        drop(v237_2);
        let v237_10: Space = if has_head(&(v237_9)) { singleton(&[]) } else { Space::new() };
        drop(v237_9);
        let v237_12: Space = if (&(v237_10)).is_empty() { Space::new() } else {
          let v242_6: Path = concat_path(&(v236_6),&v234_14_cursor.path()[(v234_14_origin + 1)..(v234_14_origin + 2)]);
          let mut v242_11 = Space::new();
          let mut v242_11_write = v242_11.write_zipper();
          for v242_11_byte in v234_14_cursor.child_mask().iter() {
            v234_14_cursor.descend_to_existing_byte(v242_11_byte);
            {
            let v243_2: Space = singleton(&v234_14_cursor.path()[(v234_14_origin + 2)..(v234_14_origin + 3)]);
            let v243_3: Space = intersect(&(*CONSTANT_1),&(v243_2));
            let v243_4: Space = if has_head(&(v243_3)) { singleton(&[]) } else { Space::new() };
            drop(v243_3);
            let v243_5: Space = subtract(&(*CONSTANT_0),&(v243_4));
            drop(v243_4);
            let v243_8: Space = if (&(v243_5)).is_empty() { Space::new() } else {
              let v244_6: Path = concat_path(&(v242_6),&v234_14_cursor.path()[(v234_14_origin + 2)..(v234_14_origin + 3)]);
              let v244_7: Space = routine_26(c, &(v244_6), &v234_14_cursor);
              compose(&(v243_5),&(v244_7))
            };
            drop(v243_5);
            let v243_9: Space = intersect(&(*CONSTANT_1),&(v243_2));
            drop(v243_2);
            let v243_10: Space = if has_head(&(v243_9)) { singleton(&[]) } else { Space::new() };
            drop(v243_9);
            let v243_12: Space = if (&(v243_10)).is_empty() { Space::new() } else {
              let v245_6: Path = concat_path(&(v242_6),&v234_14_cursor.path()[(v234_14_origin + 2)..(v234_14_origin + 3)]);
              let v245_11: Space = routine_15(c, &(v245_6), &v234_14_cursor);
              drop(v245_6);
              compose(&(v243_10),&(v245_11))
            };
            drop(v243_10);
            let v243_13: Space = unite(&(v243_8),&(v243_12));
            join_wrapped_into(&mut v242_11_write,&((v243_13).read_zipper()),&[]);
            }
            v234_14_cursor.ascend(1);
          }
          drop(v242_11_write);
          drop(v242_6);
          compose(&(v237_10),&(v242_11))
        };
        drop(v237_10);
        let v237_13: Space = unite(&(v237_8),&(v237_12));
        join_wrapped_into(&mut v236_7_write,&((v237_13).read_zipper()),&[]);
        }
        v234_14_cursor.ascend(1);
      }
      drop(v236_7_write);
      drop(v236_6);
      compose(&(v235_5),&(v236_7))
    };
    drop(v235_5);
    let v235_9: Space = intersect(&(*CONSTANT_1),&(v235_2));
    drop(v235_2);
    let v235_10: Space = if has_head(&(v235_9)) { singleton(&[]) } else { Space::new() };
    drop(v235_9);
    let v235_11: Space = compose(&(v235_10),&v234_14_cursor);
    drop(v235_10);
    let v235_12: Space = unite(&(v235_8),&(v235_11));
    drop(v235_11);
    join_wrapped_into(&mut v234_14_write,&((v235_12).read_zipper()),&[]);
    }
    v234_14_cursor.ascend(1);
  }
  drop(v234_14_cursor);
  drop(v234_14_write);
  (v234_14).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_16(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v247_8 = Space::new();
  let mut v247_8_write = v247_8.write_zipper();
  let mut v247_8_cursor = (*s0).read_zipper();
  let v247_8_origin = v247_8_cursor.path().len();
  for v247_8_byte in v247_8_cursor.child_mask().iter() {
    v247_8_cursor.descend_to_existing_byte(v247_8_byte);
    {
    let v248_2: Space = singleton(&v247_8_cursor.path()[v247_8_origin..(v247_8_origin + 1)]);
    let v248_3: Space = intersect(&(*CONSTANT_1),&(v248_2));
    let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
    drop(v248_3);
    let v248_5: Space = subtract(&(*CONSTANT_0),&(v248_4));
    drop(v248_4);
    let v248_8: Space = if (&(v248_5)).is_empty() { Space::new() } else {
      let v249_6: Path = concat_path(&(*p0),&v247_8_cursor.path()[v247_8_origin..(v247_8_origin + 1)]);
      let mut v249_7 = Space::new();
      let mut v249_7_write = v249_7.write_zipper();
      for v249_7_byte in v247_8_cursor.child_mask().iter() {
        v247_8_cursor.descend_to_existing_byte(v249_7_byte);
        {
        let v250_2: Space = singleton(&v247_8_cursor.path()[(v247_8_origin + 1)..(v247_8_origin + 2)]);
        let v250_3: Space = intersect(&(*CONSTANT_1),&(v250_2));
        drop(v250_2);
        let v250_4: Space = if has_head(&(v250_3)) { singleton(&[]) } else { Space::new() };
        drop(v250_3);
        let v250_7: Space = if (&(v250_4)).is_empty() { Space::new() } else {
          let v251_5: Path = concat_path(&(v249_6),&v247_8_cursor.path()[(v247_8_origin + 1)..(v247_8_origin + 2)]);
          let mut v251_6 = Space::new();
          let mut v251_6_write = v251_6.write_zipper();
          for v251_6_byte in v247_8_cursor.child_mask().iter() {
            v247_8_cursor.descend_to_existing_byte(v251_6_byte);
            {
            let v252_2: Space = singleton(&v247_8_cursor.path()[(v247_8_origin + 2)..(v247_8_origin + 3)]);
            let v252_3: Space = intersect(&(*CONSTANT_1),&(v252_2));
            drop(v252_2);
            let v252_4: Space = if has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
            drop(v252_3);
            let v252_7: Space = if (&(v252_4)).is_empty() { Space::new() } else {
              let v253_5: Path = concat_path(&(v251_5),&v247_8_cursor.path()[(v247_8_origin + 2)..(v247_8_origin + 3)]);
              let v253_6: Space = routine_12(c, &(v253_5), &v247_8_cursor);
              drop(v253_5);
              compose(&(v252_4),&(v253_6))
            };
            drop(v252_4);
            join_wrapped_into(&mut v251_6_write,&((v252_7).read_zipper()),&[]);
            }
            v247_8_cursor.ascend(1);
          }
          drop(v251_6_write);
          drop(v251_5);
          compose(&(v250_4),&(v251_6))
        };
        drop(v250_4);
        join_wrapped_into(&mut v249_7_write,&((v250_7).read_zipper()),&[]);
        }
        v247_8_cursor.ascend(1);
      }
      drop(v249_7_write);
      drop(v249_6);
      compose(&(v248_5),&(v249_7))
    };
    drop(v248_5);
    let v248_9: Space = intersect(&(*CONSTANT_1),&(v248_2));
    drop(v248_2);
    let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
    drop(v248_9);
    let v248_12: Space = if (&(v248_10)).is_empty() { Space::new() } else {
      let mut v254_11 = Space::new();
      let mut v254_11_write = v254_11.write_zipper();
      for v254_11_byte in v247_8_cursor.child_mask().iter() {
        v247_8_cursor.descend_to_existing_byte(v254_11_byte);
        {
        let v255_2: Space = singleton(&v247_8_cursor.path()[(v247_8_origin + 1)..(v247_8_origin + 2)]);
        let v255_3: Space = intersect(&(*CONSTANT_1),&(v255_2));
        drop(v255_2);
        let v255_4: Space = if has_head(&(v255_3)) { singleton(&[]) } else { Space::new() };
        drop(v255_3);
        let v255_5: Space = compose(&(v255_4),&v247_8_cursor);
        drop(v255_4);
        join_wrapped_into(&mut v254_11_write,&((v255_5).read_zipper()),&[]);
        }
        v247_8_cursor.ascend(1);
      }
      drop(v254_11_write);
      compose(&(v248_10),&(v254_11))
    };
    drop(v248_10);
    let v248_13: Space = unite(&(v248_8),&(v248_12));
    drop(v248_12);
    join_wrapped_into(&mut v247_8_write,&((v248_13).read_zipper()),&[]);
    }
    v247_8_cursor.ascend(1);
  }
  drop(v247_8_cursor);
  drop(v247_8_write);
  (v247_8).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v256_7 = Space::new();
  let mut v256_7_write = v256_7.write_zipper();
  let mut v256_7_cursor = (*s0).read_zipper();
  let v256_7_origin = v256_7_cursor.path().len();
  for v256_7_byte in v256_7_cursor.child_mask().iter() {
    v256_7_cursor.descend_to_existing_byte(v256_7_byte);
    {
    let v257_2: Space = singleton(&v256_7_cursor.path()[v256_7_origin..(v256_7_origin + 1)]);
    let v257_3: Space = intersect(&(*CONSTANT_1),&(v257_2));
    let v257_4: Space = if has_head(&(v257_3)) { singleton(&[]) } else { Space::new() };
    drop(v257_3);
    let v257_5: Space = subtract(&(*CONSTANT_0),&(v257_4));
    drop(v257_4);
    let v257_8: Space = if (&(v257_5)).is_empty() { Space::new() } else {
      let v258_6: Path = concat_path(&(*p0),&v256_7_cursor.path()[v256_7_origin..(v256_7_origin + 1)]);
      let mut v258_7 = Space::new();
      let mut v258_7_write = v258_7.write_zipper();
      for v258_7_byte in v256_7_cursor.child_mask().iter() {
        v256_7_cursor.descend_to_existing_byte(v258_7_byte);
        {
        let v259_2: Space = singleton(&v256_7_cursor.path()[(v256_7_origin + 1)..(v256_7_origin + 2)]);
        let v259_3: Space = intersect(&(*CONSTANT_1),&(v259_2));
        drop(v259_2);
        let v259_4: Space = if has_head(&(v259_3)) { singleton(&[]) } else { Space::new() };
        drop(v259_3);
        let v259_7: Space = if (&(v259_4)).is_empty() { Space::new() } else {
          let v260_5: Path = concat_path(&(v258_6),&v256_7_cursor.path()[(v256_7_origin + 1)..(v256_7_origin + 2)]);
          let mut v260_6 = Space::new();
          let mut v260_6_write = v260_6.write_zipper();
          for v260_6_byte in v256_7_cursor.child_mask().iter() {
            v256_7_cursor.descend_to_existing_byte(v260_6_byte);
            {
            let v261_2: Space = singleton(&v256_7_cursor.path()[(v256_7_origin + 2)..(v256_7_origin + 3)]);
            let v261_3: Space = intersect(&(*CONSTANT_1),&(v261_2));
            drop(v261_2);
            let v261_4: Space = if has_head(&(v261_3)) { singleton(&[]) } else { Space::new() };
            drop(v261_3);
            let v261_7: Space = if (&(v261_4)).is_empty() { Space::new() } else {
              let v262_5: Path = concat_path(&(v260_5),&v256_7_cursor.path()[(v256_7_origin + 2)..(v256_7_origin + 3)]);
              let v262_6: Space = routine_12(c, &(v262_5), &v256_7_cursor);
              drop(v262_5);
              compose(&(v261_4),&(v262_6))
            };
            drop(v261_4);
            join_wrapped_into(&mut v260_6_write,&((v261_7).read_zipper()),&[]);
            }
            v256_7_cursor.ascend(1);
          }
          drop(v260_6_write);
          drop(v260_5);
          compose(&(v259_4),&(v260_6))
        };
        drop(v259_4);
        join_wrapped_into(&mut v258_7_write,&((v259_7).read_zipper()),&[]);
        }
        v256_7_cursor.ascend(1);
      }
      drop(v258_7_write);
      drop(v258_6);
      compose(&(v257_5),&(v258_7))
    };
    drop(v257_5);
    let v257_9: Space = intersect(&(*CONSTANT_1),&(v257_2));
    drop(v257_2);
    let v257_10: Space = if has_head(&(v257_9)) { singleton(&[]) } else { Space::new() };
    drop(v257_9);
    let v257_11: Space = compose(&(v257_10),&v256_7_cursor);
    drop(v257_10);
    let v257_12: Space = unite(&(v257_8),&(v257_11));
    drop(v257_11);
    join_wrapped_into(&mut v256_7_write,&((v257_12).read_zipper()),&[]);
    }
    v256_7_cursor.ascend(1);
  }
  drop(v256_7_cursor);
  drop(v256_7_write);
  (v256_7).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v263_8 = Space::new();
  let mut v263_8_write = v263_8.write_zipper();
  let mut v263_8_cursor = (*s0).read_zipper();
  let v263_8_origin = v263_8_cursor.path().len();
  for v263_8_byte in v263_8_cursor.child_mask().iter() {
    v263_8_cursor.descend_to_existing_byte(v263_8_byte);
    {
    let v264_2: Space = singleton(&v263_8_cursor.path()[v263_8_origin..(v263_8_origin + 1)]);
    let v264_3: Space = intersect(&(*CONSTANT_1),&(v264_2));
    let v264_4: Space = if has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
    drop(v264_3);
    let v264_5: Space = subtract(&(*CONSTANT_0),&(v264_4));
    drop(v264_4);
    let v264_8: Space = if (&(v264_5)).is_empty() { Space::new() } else {
      let v265_6: Path = concat_path(&(*p0),&v263_8_cursor.path()[v263_8_origin..(v263_8_origin + 1)]);
      let mut v265_7 = Space::new();
      let mut v265_7_write = v265_7.write_zipper();
      for v265_7_byte in v263_8_cursor.child_mask().iter() {
        v263_8_cursor.descend_to_existing_byte(v265_7_byte);
        {
        let v266_2: Space = singleton(&v263_8_cursor.path()[(v263_8_origin + 1)..(v263_8_origin + 2)]);
        let v266_3: Space = intersect(&(*CONSTANT_1),&(v266_2));
        drop(v266_2);
        let v266_4: Space = if has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
        drop(v266_3);
        let v266_7: Space = if (&(v266_4)).is_empty() { Space::new() } else {
          let v267_5: Path = concat_path(&(v265_6),&v263_8_cursor.path()[(v263_8_origin + 1)..(v263_8_origin + 2)]);
          let mut v267_6 = Space::new();
          let mut v267_6_write = v267_6.write_zipper();
          for v267_6_byte in v263_8_cursor.child_mask().iter() {
            v263_8_cursor.descend_to_existing_byte(v267_6_byte);
            {
            let v268_2: Space = singleton(&v263_8_cursor.path()[(v263_8_origin + 2)..(v263_8_origin + 3)]);
            let v268_3: Space = intersect(&(*CONSTANT_1),&(v268_2));
            drop(v268_2);
            let v268_4: Space = if has_head(&(v268_3)) { singleton(&[]) } else { Space::new() };
            drop(v268_3);
            let v268_7: Space = if (&(v268_4)).is_empty() { Space::new() } else {
              let v269_5: Path = concat_path(&(v267_5),&v263_8_cursor.path()[(v263_8_origin + 2)..(v263_8_origin + 3)]);
              let v269_6: Space = routine_15(c, &(v269_5), &v263_8_cursor);
              drop(v269_5);
              compose(&(v268_4),&(v269_6))
            };
            drop(v268_4);
            join_wrapped_into(&mut v267_6_write,&((v268_7).read_zipper()),&[]);
            }
            v263_8_cursor.ascend(1);
          }
          drop(v267_6_write);
          drop(v267_5);
          compose(&(v266_4),&(v267_6))
        };
        drop(v266_4);
        join_wrapped_into(&mut v265_7_write,&((v266_7).read_zipper()),&[]);
        }
        v263_8_cursor.ascend(1);
      }
      drop(v265_7_write);
      drop(v265_6);
      compose(&(v264_5),&(v265_7))
    };
    drop(v264_5);
    let v264_9: Space = intersect(&(*CONSTANT_1),&(v264_2));
    drop(v264_2);
    let v264_10: Space = if has_head(&(v264_9)) { singleton(&[]) } else { Space::new() };
    drop(v264_9);
    let v264_12: Space = if (&(v264_10)).is_empty() { Space::new() } else {
      let mut v270_11 = Space::new();
      let mut v270_11_write = v270_11.write_zipper();
      for v270_11_byte in v263_8_cursor.child_mask().iter() {
        v263_8_cursor.descend_to_existing_byte(v270_11_byte);
        {
        let v271_2: Space = singleton(&v263_8_cursor.path()[(v263_8_origin + 1)..(v263_8_origin + 2)]);
        let v271_3: Space = intersect(&(*CONSTANT_1),&(v271_2));
        drop(v271_2);
        let v271_4: Space = if has_head(&(v271_3)) { singleton(&[]) } else { Space::new() };
        drop(v271_3);
        let v271_5: Space = compose(&(v271_4),&v263_8_cursor);
        drop(v271_4);
        join_wrapped_into(&mut v270_11_write,&((v271_5).read_zipper()),&[]);
        }
        v263_8_cursor.ascend(1);
      }
      drop(v270_11_write);
      compose(&(v264_10),&(v270_11))
    };
    drop(v264_10);
    let v264_13: Space = unite(&(v264_8),&(v264_12));
    drop(v264_12);
    join_wrapped_into(&mut v263_8_write,&((v264_13).read_zipper()),&[]);
    }
    v263_8_cursor.ascend(1);
  }
  drop(v263_8_cursor);
  drop(v263_8_write);
  (v263_8).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v272_7 = Space::new();
  let mut v272_7_write = v272_7.write_zipper();
  let mut v272_7_cursor = (*s0).read_zipper();
  let v272_7_origin = v272_7_cursor.path().len();
  for v272_7_byte in v272_7_cursor.child_mask().iter() {
    v272_7_cursor.descend_to_existing_byte(v272_7_byte);
    {
    let v273_2: Space = singleton(&v272_7_cursor.path()[v272_7_origin..(v272_7_origin + 1)]);
    let v273_3: Space = intersect(&(*CONSTANT_1),&(v273_2));
    let v273_4: Space = if has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
    drop(v273_3);
    let v273_5: Space = subtract(&(*CONSTANT_0),&(v273_4));
    drop(v273_4);
    let v273_8: Space = if (&(v273_5)).is_empty() { Space::new() } else {
      let v274_6: Path = concat_path(&(*p0),&v272_7_cursor.path()[v272_7_origin..(v272_7_origin + 1)]);
      let mut v274_7 = Space::new();
      let mut v274_7_write = v274_7.write_zipper();
      for v274_7_byte in v272_7_cursor.child_mask().iter() {
        v272_7_cursor.descend_to_existing_byte(v274_7_byte);
        {
        let v275_2: Space = singleton(&v272_7_cursor.path()[(v272_7_origin + 1)..(v272_7_origin + 2)]);
        let v275_3: Space = intersect(&(*CONSTANT_1),&(v275_2));
        drop(v275_2);
        let v275_4: Space = if has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
        drop(v275_3);
        let v275_7: Space = if (&(v275_4)).is_empty() { Space::new() } else {
          let v276_5: Path = concat_path(&(v274_6),&v272_7_cursor.path()[(v272_7_origin + 1)..(v272_7_origin + 2)]);
          let mut v276_6 = Space::new();
          let mut v276_6_write = v276_6.write_zipper();
          for v276_6_byte in v272_7_cursor.child_mask().iter() {
            v272_7_cursor.descend_to_existing_byte(v276_6_byte);
            {
            let v277_2: Space = singleton(&v272_7_cursor.path()[(v272_7_origin + 2)..(v272_7_origin + 3)]);
            let v277_3: Space = intersect(&(*CONSTANT_1),&(v277_2));
            drop(v277_2);
            let v277_4: Space = if has_head(&(v277_3)) { singleton(&[]) } else { Space::new() };
            drop(v277_3);
            let v277_7: Space = if (&(v277_4)).is_empty() { Space::new() } else {
              let v278_5: Path = concat_path(&(v276_5),&v272_7_cursor.path()[(v272_7_origin + 2)..(v272_7_origin + 3)]);
              let v278_6: Space = routine_15(c, &(v278_5), &v272_7_cursor);
              drop(v278_5);
              compose(&(v277_4),&(v278_6))
            };
            drop(v277_4);
            join_wrapped_into(&mut v276_6_write,&((v277_7).read_zipper()),&[]);
            }
            v272_7_cursor.ascend(1);
          }
          drop(v276_6_write);
          drop(v276_5);
          compose(&(v275_4),&(v276_6))
        };
        drop(v275_4);
        join_wrapped_into(&mut v274_7_write,&((v275_7).read_zipper()),&[]);
        }
        v272_7_cursor.ascend(1);
      }
      drop(v274_7_write);
      drop(v274_6);
      compose(&(v273_5),&(v274_7))
    };
    drop(v273_5);
    let v273_9: Space = intersect(&(*CONSTANT_1),&(v273_2));
    drop(v273_2);
    let v273_10: Space = if has_head(&(v273_9)) { singleton(&[]) } else { Space::new() };
    drop(v273_9);
    let v273_11: Space = compose(&(v273_10),&v272_7_cursor);
    drop(v273_10);
    let v273_12: Space = unite(&(v273_8),&(v273_11));
    drop(v273_11);
    join_wrapped_into(&mut v272_7_write,&((v273_12).read_zipper()),&[]);
    }
    v272_7_cursor.ascend(1);
  }
  drop(v272_7_cursor);
  drop(v272_7_write);
  (v272_7).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v279_4 = Space::new();
  let mut v279_4_write = v279_4.write_zipper();
  let mut v279_4_cursor = (*s0).read_zipper();
  let v279_4_origin = v279_4_cursor.path().len();
  for v279_4_byte in v279_4_cursor.child_mask().iter() {
    v279_4_cursor.descend_to_existing_byte(v279_4_byte);
    {
    let v280_2: Space = singleton(&v279_4_cursor.path()[v279_4_origin..(v279_4_origin + 1)]);
    let v280_3: Space = intersect(&(*CONSTANT_1),&(v280_2));
    drop(v280_2);
    let v280_4: Space = if has_head(&(v280_3)) { singleton(&[]) } else { Space::new() };
    drop(v280_3);
    let v280_6: Space = if (&(v280_4)).is_empty() { Space::new() } else {
      let mut v281_5 = Space::new();
      let mut v281_5_write = v281_5.write_zipper();
      for v281_5_byte in v279_4_cursor.child_mask().iter() {
        v279_4_cursor.descend_to_existing_byte(v281_5_byte);
        {
        let v282_2: Space = singleton(&v279_4_cursor.path()[(v279_4_origin + 1)..(v279_4_origin + 2)]);
        let v282_3: Space = intersect(&(*CONSTANT_1),&(v282_2));
        drop(v282_2);
        let v282_4: Space = if has_head(&(v282_3)) { singleton(&[]) } else { Space::new() };
        drop(v282_3);
        let v282_5: Space = compose(&(v282_4),&v279_4_cursor);
        drop(v282_4);
        join_wrapped_into(&mut v281_5_write,&((v282_5).read_zipper()),&[]);
        }
        v279_4_cursor.ascend(1);
      }
      drop(v281_5_write);
      compose(&(v280_4),&(v281_5))
    };
    drop(v280_4);
    join_wrapped_into(&mut v279_4_write,&((v280_6).read_zipper()),&[]);
    }
    v279_4_cursor.ascend(1);
  }
  drop(v279_4_cursor);
  drop(v279_4_write);
  (v279_4).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v283_3 = Space::new();
  let mut v283_3_write = v283_3.write_zipper();
  let mut v283_3_cursor = (*s0).read_zipper();
  let v283_3_origin = v283_3_cursor.path().len();
  for v283_3_byte in v283_3_cursor.child_mask().iter() {
    v283_3_cursor.descend_to_existing_byte(v283_3_byte);
    {
    let v284_2: Space = singleton(&v283_3_cursor.path()[v283_3_origin..(v283_3_origin + 1)]);
    let v284_3: Space = intersect(&(*CONSTANT_1),&(v284_2));
    drop(v284_2);
    let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
    drop(v284_3);
    let v284_5: Space = compose(&(v284_4),&v283_3_cursor);
    drop(v284_4);
    join_wrapped_into(&mut v283_3_write,&((v284_5).read_zipper()),&[]);
    }
    v283_3_cursor.ascend(1);
  }
  drop(v283_3_cursor);
  drop(v283_3_write);
  (v283_3).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v285_4 = Space::new();
  let mut v285_4_write = v285_4.write_zipper();
  let mut v285_4_cursor = (*s0).read_zipper();
  let v285_4_origin = v285_4_cursor.path().len();
  for v285_4_byte in v285_4_cursor.child_mask().iter() {
    v285_4_cursor.descend_to_existing_byte(v285_4_byte);
    {
    let v286_2: Space = singleton(&v285_4_cursor.path()[v285_4_origin..(v285_4_origin + 1)]);
    let v286_3: Space = intersect(&(*CONSTANT_1),&(v286_2));
    drop(v286_2);
    let v286_4: Space = if has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
    drop(v286_3);
    let v286_6: Space = if (&(v286_4)).is_empty() { Space::new() } else {
      let mut v287_5 = Space::new();
      let mut v287_5_write = v287_5.write_zipper();
      for v287_5_byte in v285_4_cursor.child_mask().iter() {
        v285_4_cursor.descend_to_existing_byte(v287_5_byte);
        {
        let v288_2: Space = singleton(&v285_4_cursor.path()[(v285_4_origin + 1)..(v285_4_origin + 2)]);
        let v288_3: Space = intersect(&(*CONSTANT_1),&(v288_2));
        drop(v288_2);
        let v288_4: Space = if has_head(&(v288_3)) { singleton(&[]) } else { Space::new() };
        drop(v288_3);
        let v288_5: Space = compose(&(v288_4),&v285_4_cursor);
        drop(v288_4);
        join_wrapped_into(&mut v287_5_write,&((v288_5).read_zipper()),&[]);
        }
        v285_4_cursor.ascend(1);
      }
      drop(v287_5_write);
      compose(&(v286_4),&(v287_5))
    };
    drop(v286_4);
    join_wrapped_into(&mut v285_4_write,&((v286_6).read_zipper()),&[]);
    }
    v285_4_cursor.ascend(1);
  }
  drop(v285_4_cursor);
  drop(v285_4_write);
  (v285_4).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v289_3 = Space::new();
  let mut v289_3_write = v289_3.write_zipper();
  let mut v289_3_cursor = (*s0).read_zipper();
  let v289_3_origin = v289_3_cursor.path().len();
  for v289_3_byte in v289_3_cursor.child_mask().iter() {
    v289_3_cursor.descend_to_existing_byte(v289_3_byte);
    {
    let v290_2: Space = singleton(&v289_3_cursor.path()[v289_3_origin..(v289_3_origin + 1)]);
    let v290_3: Space = intersect(&(*CONSTANT_1),&(v290_2));
    drop(v290_2);
    let v290_4: Space = if has_head(&(v290_3)) { singleton(&[]) } else { Space::new() };
    drop(v290_3);
    let v290_5: Space = compose(&(v290_4),&v289_3_cursor);
    drop(v290_4);
    join_wrapped_into(&mut v289_3_write,&((v290_5).read_zipper()),&[]);
    }
    v289_3_cursor.ascend(1);
  }
  drop(v289_3_cursor);
  drop(v289_3_write);
  (v289_3).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v291_2: Space = Space::new();
  (v291_2).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v292_3 = Space::new();
  let mut v292_3_write = v292_3.write_zipper();
  let mut v292_3_cursor = (*s0).read_zipper();
  let v292_3_origin = v292_3_cursor.path().len();
  for v292_3_byte in v292_3_cursor.child_mask().iter() {
    v292_3_cursor.descend_to_existing_byte(v292_3_byte);
    {
    let v293_2: Space = singleton(&v292_3_cursor.path()[v292_3_origin..(v292_3_origin + 1)]);
    let v293_3: Space = intersect(&(*CONSTANT_1),&(v293_2));
    drop(v293_2);
    let v293_4: Space = if has_head(&(v293_3)) { singleton(&[]) } else { Space::new() };
    drop(v293_3);
    let v293_5: Space = compose(&(v293_4),&v292_3_cursor);
    drop(v293_4);
    join_wrapped_into(&mut v292_3_write,&((v293_5).read_zipper()),&[]);
    }
    v292_3_cursor.ascend(1);
  }
  drop(v292_3_cursor);
  drop(v292_3_write);
  (v292_3).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v294_2: Space = Space::new();
  (v294_2).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v295_3 = Space::new();
  let mut v295_3_write = v295_3.write_zipper();
  let mut v295_3_cursor = (*s0).read_zipper();
  let v295_3_origin = v295_3_cursor.path().len();
  for v295_3_byte in v295_3_cursor.child_mask().iter() {
    v295_3_cursor.descend_to_existing_byte(v295_3_byte);
    {
    let v296_2: Space = singleton(&v295_3_cursor.path()[v295_3_origin..(v295_3_origin + 1)]);
    let v296_3: Space = intersect(&(*CONSTANT_1),&(v296_2));
    drop(v296_2);
    let v296_4: Space = if has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
    drop(v296_3);
    let v296_5: Space = compose(&(v296_4),&v295_3_cursor);
    drop(v296_4);
    join_wrapped_into(&mut v295_3_write,&((v296_5).read_zipper()),&[]);
    }
    v295_3_cursor.ascend(1);
  }
  drop(v295_3_cursor);
  drop(v295_3_write);
  (v295_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
