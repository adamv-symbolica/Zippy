#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 8 0 0 0 1 1 0 1 1 8 0 1 0 1 1 0 1 1 9 0 1 0 1 1 1 0 1 1 8 0 1 1 1 0 0 1 1 5 0 1 1 1 1 9 1 0 0 1 1 0 0 1 1"));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 9 0 0 1 1 1 0 0 1 1 8 0 1 1 0 0 0 1 1 8 0 1 1 0 1 0 1 1 8 1 0 0 1 1 0 1 1 9 1 0 1 1 0 1 0 1 1 5 1 1 0 1 1"));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 5 0 0 0 1 1 5 1 0 0 1 1 4 1 0 1 1 2 1 1"));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_10 = Space::new();
  let mut v0_10_write = v0_10.write_zipper();
  let mut v0_10_cursor = (*s0.expect("unbound native input")).read_zipper();
  let v0_10_origin = v0_10_cursor.path().len();
  for v0_10_byte in v0_10_cursor.child_mask().iter() {
    v0_10_cursor.descend_to_existing_byte(v0_10_byte);
    {
    let v1_2: Space = singleton(&v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 1)]);
    let v1_3: Space = intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (&(v1_5)).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_write = v2_6.write_zipper();
      for v2_6_byte in v0_10_cursor.child_mask().iter() {
        v0_10_cursor.descend_to_existing_byte(v2_6_byte);
        {
        let v3_2: Space = singleton(&v0_10_cursor.path()[(v0_10_origin + 1)..(v0_10_origin + 2)]);
        let v3_3: Space = intersect(&(*CONSTANT_1),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_0),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (&(v3_5)).is_empty() { Space::new() } else {
          let v4_7: Space = routine_1(c, &v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 2)], &v0_10_cursor);
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_1),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (&(v3_10)).is_empty() { Space::new() } else {
          let v5_11: Space = routine_2(c, &v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 2)], &v0_10_cursor);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        join_wrapped_into(&mut v2_6_write,&((v3_13).read_zipper()),&[]);
        }
        v0_10_cursor.ascend(1);
      }
      drop(v2_6_write);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (&(v1_9)).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_write = v6_10.write_zipper();
      for v6_10_byte in v0_10_cursor.child_mask().iter() {
        v0_10_cursor.descend_to_existing_byte(v6_10_byte);
        {
        let v7_2: Space = singleton(&v0_10_cursor.path()[(v0_10_origin + 1)..(v0_10_origin + 2)]);
        let v7_3: Space = intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (&(v7_5)).is_empty() { Space::new() } else {
          let v8_7: Space = routine_1(c, &v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 2)], &v0_10_cursor);
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (&(v7_10)).is_empty() { Space::new() } else {
          let v9_11: Space = routine_3(c, &v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 2)], &v0_10_cursor);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        join_wrapped_into(&mut v6_10_write,&((v7_13).read_zipper()),&[]);
        }
        v0_10_cursor.ascend(1);
      }
      drop(v6_10_write);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    join_wrapped_into(&mut v0_10_write,&((v1_12).read_zipper()),&[]);
    }
    v0_10_cursor.ascend(1);
  }
  drop(v0_10_cursor);
  drop(v0_10_write);
  let v0_12: Space = wrap(&(v0_10),&(*CONSTANT_2));
  (v0_12).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v10_33 = Space::new();
  let mut v10_33_write = v10_33.write_zipper();
  let mut v10_33_cursor = (*s0).read_zipper();
  let v10_33_origin = v10_33_cursor.path().len();
  for v10_33_byte in v10_33_cursor.child_mask().iter() {
    v10_33_cursor.descend_to_existing_byte(v10_33_byte);
    {
    let v11_2: Space = singleton(&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]);
    let v11_3: Space = intersect(&(*CONSTANT_1),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (&(v11_5)).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]);
      let mut v12_7 = Space::new();
      let mut v12_7_write = v12_7.write_zipper();
      for v12_7_byte in v10_33_cursor.child_mask().iter() {
        v10_33_cursor.descend_to_existing_byte(v12_7_byte);
        {
        let v13_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
        let v13_3: Space = intersect(&(*CONSTANT_1),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_0),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (&(v13_5)).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v12_6),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
          let mut v14_7 = Space::new();
          let mut v14_7_write = v14_7.write_zipper();
          for v14_7_byte in v10_33_cursor.child_mask().iter() {
            v10_33_cursor.descend_to_existing_byte(v14_7_byte);
            {
            let v15_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
            let v15_3: Space = intersect(&(*CONSTANT_1),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (&(v15_5)).is_empty() { Space::new() } else {
              let v16_6: Path = concat_path(&(v14_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v16_7: Space = routine_4(c, &(v16_6), &v10_33_cursor);
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_1),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (&(v15_10)).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v14_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v17_11: Space = routine_5(c, &(v17_6), &v10_33_cursor);
              drop(v17_6);
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            join_wrapped_into(&mut v14_7_write,&((v15_13).read_zipper()),&[]);
            }
            v10_33_cursor.ascend(1);
          }
          drop(v14_7_write);
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_1),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (&(v13_10)).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v12_6),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
          let mut v18_11 = Space::new();
          let mut v18_11_write = v18_11.write_zipper();
          for v18_11_byte in v10_33_cursor.child_mask().iter() {
            v10_33_cursor.descend_to_existing_byte(v18_11_byte);
            {
            let v19_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
            let v19_3: Space = intersect(&(*CONSTANT_1),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
            drop(v19_4);
            let v19_8: Space = if (&(v19_5)).is_empty() { Space::new() } else {
              let v20_6: Path = concat_path(&(v18_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v20_7: Space = routine_4(c, &(v20_6), &v10_33_cursor);
              compose(&(v19_5),&(v20_7))
            };
            drop(v19_5);
            let v19_9: Space = intersect(&(*CONSTANT_1),&(v19_2));
            drop(v19_2);
            let v19_10: Space = if has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
            drop(v19_9);
            let v19_12: Space = if (&(v19_10)).is_empty() { Space::new() } else {
              let v21_6: Path = concat_path(&(v18_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v21_11: Space = routine_3(c, &(v21_6), &v10_33_cursor);
              drop(v21_6);
              compose(&(v19_10),&(v21_11))
            };
            drop(v19_10);
            let v19_13: Space = unite(&(v19_8),&(v19_12));
            join_wrapped_into(&mut v18_11_write,&((v19_13).read_zipper()),&[]);
            }
            v10_33_cursor.ascend(1);
          }
          drop(v18_11_write);
          drop(v18_6);
          compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        join_wrapped_into(&mut v12_7_write,&((v13_13).read_zipper()),&[]);
        }
        v10_33_cursor.ascend(1);
      }
      drop(v12_7_write);
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_1),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_14: Space = if (&(v11_10)).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]);
      let mut v22_13 = Space::new();
      let mut v22_13_write = v22_13.write_zipper();
      for v22_13_byte in v10_33_cursor.child_mask().iter() {
        v10_33_cursor.descend_to_existing_byte(v22_13_byte);
        {
        let v23_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
        let v23_3: Space = intersect(&(*CONSTANT_1),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_0),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (&(v23_5)).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v22_6),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
          let mut v24_7 = Space::new();
          let mut v24_7_write = v24_7.write_zipper();
          for v24_7_byte in v10_33_cursor.child_mask().iter() {
            v10_33_cursor.descend_to_existing_byte(v24_7_byte);
            {
            let v25_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
            let v25_3: Space = intersect(&(*CONSTANT_1),&(v25_2));
            let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
            drop(v25_3);
            let v25_5: Space = subtract(&(*CONSTANT_0),&(v25_4));
            drop(v25_4);
            let v25_8: Space = if (&(v25_5)).is_empty() { Space::new() } else {
              let v26_6: Path = concat_path(&(v24_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v26_7: Space = routine_4(c, &(v26_6), &v10_33_cursor);
              compose(&(v25_5),&(v26_7))
            };
            drop(v25_5);
            let v25_9: Space = intersect(&(*CONSTANT_1),&(v25_2));
            drop(v25_2);
            let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
            drop(v25_9);
            let v25_12: Space = if (&(v25_10)).is_empty() { Space::new() } else {
              let v27_6: Path = concat_path(&(v24_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v27_11: Space = routine_5(c, &(v27_6), &v10_33_cursor);
              drop(v27_6);
              compose(&(v25_10),&(v27_11))
            };
            drop(v25_10);
            let v25_13: Space = unite(&(v25_8),&(v25_12));
            join_wrapped_into(&mut v24_7_write,&((v25_13).read_zipper()),&[]);
            }
            v10_33_cursor.ascend(1);
          }
          drop(v24_7_write);
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_1),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_19: Space = if (&(v23_10)).is_empty() { Space::new() } else {
          let v28_12: Space = restrict_to(&(*CONSTANT_4),&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)])));
          let mut v28_13 = Space::new();
          let mut v28_13_write = v28_13.write_zipper();
          let mut v28_13_cursor = (v28_12).read_zipper();
          let v28_13_origin = v28_13_cursor.path().len();
          for v28_13_byte in v28_13_cursor.child_mask().iter() {
            v28_13_cursor.descend_to_existing_byte(v28_13_byte);
            {
            let v29_2: Space = singleton(&v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)]);
            let v29_3: Space = intersect(&(*CONSTANT_1),&(v29_2));
            let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
            drop(v29_3);
            let v29_5: Space = subtract(&(*CONSTANT_0),&(v29_4));
            drop(v29_4);
            let v29_7: Space = if (&(v29_5)).is_empty() { Space::new() } else {
              let v30_6: Space = routine_6(c, &v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)], &v28_13_cursor);
              compose(&(v29_5),&(v30_6))
            };
            drop(v29_5);
            let v29_8: Space = intersect(&(*CONSTANT_1),&(v29_2));
            drop(v29_2);
            let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
            drop(v29_8);
            let v29_11: Space = if (&(v29_9)).is_empty() { Space::new() } else {
              let v31_10: Space = routine_7(c, &v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)], &v28_13_cursor);
              compose(&(v29_9),&(v31_10))
            };
            drop(v29_9);
            let v29_12: Space = unite(&(v29_7),&(v29_11));
            join_wrapped_into(&mut v28_13_write,&((v29_12).read_zipper()),&[]);
            }
            v28_13_cursor.ascend(1);
          }
          drop(v28_13_cursor);
          drop(v28_13_write);
          drop(v28_12);
          let v28_14: Space = restrict_to(&(*CONSTANT_3),&(v28_13));
          let mut v28_15 = Space::new();
          let mut v28_15_write = v28_15.write_zipper();
          let mut v28_15_cursor = (v28_14).read_zipper();
          let v28_15_origin = v28_15_cursor.path().len();
          for v28_15_byte in v28_15_cursor.child_mask().iter() {
            v28_15_cursor.descend_to_existing_byte(v28_15_byte);
            {
            let v32_2: Space = singleton(&v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)]);
            let v32_3: Space = intersect(&(*CONSTANT_1),&(v32_2));
            let v32_4: Space = if has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
            drop(v32_3);
            let v32_5: Space = subtract(&(*CONSTANT_0),&(v32_4));
            drop(v32_4);
            let v32_7: Space = if (&(v32_5)).is_empty() { Space::new() } else {
              let v33_6: Space = routine_8(c, &v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)], &v28_15_cursor);
              compose(&(v32_5),&(v33_6))
            };
            drop(v32_5);
            let v32_8: Space = intersect(&(*CONSTANT_1),&(v32_2));
            drop(v32_2);
            let v32_9: Space = if has_head(&(v32_8)) { singleton(&[]) } else { Space::new() };
            drop(v32_8);
            let v32_11: Space = if (&(v32_9)).is_empty() { Space::new() } else {
              let v34_10: Space = routine_9(c, &v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)], &v28_15_cursor);
              compose(&(v32_9),&(v34_10))
            };
            drop(v32_9);
            let v32_12: Space = unite(&(v32_7),&(v32_11));
            join_wrapped_into(&mut v28_15_write,&((v32_12).read_zipper()),&[]);
            }
            v28_15_cursor.ascend(1);
          }
          drop(v28_15_cursor);
          drop(v28_15_write);
          let v28_17: Space = subtract(&(v28_15),&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)])));
          let v28_18: Space = intersect(&(v28_17),&(*CONSTANT_5));
          compose(&(v23_10),&(v28_18))
        };
        drop(v23_10);
        let v35_6: Path = concat_path(&(v22_6),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
        let v23_20: Space = wrap(&(v23_19),&(v35_6));
        let v23_21: Space = unite(&(v23_8),&(v23_20));
        join_wrapped_into(&mut v22_13_write,&((v23_21).read_zipper()),&[]);
        }
        v10_33_cursor.ascend(1);
      }
      drop(v22_13_write);
      drop(v22_6);
      compose(&(v11_10),&(v22_13))
    };
    drop(v11_10);
    let v11_15: Space = unite(&(v11_8),&(v11_14));
    join_wrapped_into(&mut v10_33_write,&((v11_15).read_zipper()),&[]);
    }
    v10_33_cursor.ascend(1);
  }
  drop(v10_33_cursor);
  drop(v10_33_write);
  (v10_33).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v36_39 = Space::new();
  let mut v36_39_write = v36_39.write_zipper();
  let mut v36_39_cursor = (*s0).read_zipper();
  let v36_39_origin = v36_39_cursor.path().len();
  for v36_39_byte in v36_39_cursor.child_mask().iter() {
    v36_39_cursor.descend_to_existing_byte(v36_39_byte);
    {
    let v37_2: Space = singleton(&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)]);
    let v37_3: Space = intersect(&(*CONSTANT_1),&(v37_2));
    let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
    drop(v37_3);
    let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
    drop(v37_4);
    let v37_8: Space = if (&(v37_5)).is_empty() { Space::new() } else {
      let v38_6: Path = concat_path(&(*p0),&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)]);
      let mut v38_7 = Space::new();
      let mut v38_7_write = v38_7.write_zipper();
      for v38_7_byte in v36_39_cursor.child_mask().iter() {
        v36_39_cursor.descend_to_existing_byte(v38_7_byte);
        {
        let v39_2: Space = singleton(&v36_39_cursor.path()[(v36_39_origin + 1)..(v36_39_origin + 2)]);
        let v39_3: Space = intersect(&(*CONSTANT_1),&(v39_2));
        let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_8: Space = if (&(v39_5)).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v38_6),&v36_39_cursor.path()[(v36_39_origin + 1)..(v36_39_origin + 2)]);
          let mut v40_7 = Space::new();
          let mut v40_7_write = v40_7.write_zipper();
          for v40_7_byte in v36_39_cursor.child_mask().iter() {
            v36_39_cursor.descend_to_existing_byte(v40_7_byte);
            {
            let v41_2: Space = singleton(&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
            let v41_3: Space = intersect(&(*CONSTANT_1),&(v41_2));
            let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
            drop(v41_4);
            let v41_8: Space = if (&(v41_5)).is_empty() { Space::new() } else {
              let v42_6: Path = concat_path(&(v40_6),&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
              let v42_7: Space = routine_4(c, &(v42_6), &v36_39_cursor);
              compose(&(v41_5),&(v42_7))
            };
            drop(v41_5);
            let v41_9: Space = intersect(&(*CONSTANT_1),&(v41_2));
            drop(v41_2);
            let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
            drop(v41_9);
            let v41_12: Space = if (&(v41_10)).is_empty() { Space::new() } else {
              let v43_6: Path = concat_path(&(v40_6),&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
              let v43_11: Space = routine_5(c, &(v43_6), &v36_39_cursor);
              drop(v43_6);
              compose(&(v41_10),&(v43_11))
            };
            drop(v41_10);
            let v41_13: Space = unite(&(v41_8),&(v41_12));
            join_wrapped_into(&mut v40_7_write,&((v41_13).read_zipper()),&[]);
            }
            v36_39_cursor.ascend(1);
          }
          drop(v40_7_write);
          compose(&(v39_5),&(v40_7))
        };
        drop(v39_5);
        let v39_9: Space = intersect(&(*CONSTANT_1),&(v39_2));
        drop(v39_2);
        let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
        drop(v39_9);
        let v39_12: Space = if (&(v39_10)).is_empty() { Space::new() } else {
          let v44_6: Path = concat_path(&(v38_6),&v36_39_cursor.path()[(v36_39_origin + 1)..(v36_39_origin + 2)]);
          let mut v44_11 = Space::new();
          let mut v44_11_write = v44_11.write_zipper();
          for v44_11_byte in v36_39_cursor.child_mask().iter() {
            v36_39_cursor.descend_to_existing_byte(v44_11_byte);
            {
            let v45_2: Space = singleton(&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
            let v45_3: Space = intersect(&(*CONSTANT_1),&(v45_2));
            let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
            drop(v45_3);
            let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
            drop(v45_4);
            let v45_8: Space = if (&(v45_5)).is_empty() { Space::new() } else {
              let v46_6: Path = concat_path(&(v44_6),&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
              let v46_7: Space = routine_4(c, &(v46_6), &v36_39_cursor);
              compose(&(v45_5),&(v46_7))
            };
            drop(v45_5);
            let v45_9: Space = intersect(&(*CONSTANT_1),&(v45_2));
            drop(v45_2);
            let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
            drop(v45_9);
            let v45_12: Space = if (&(v45_10)).is_empty() { Space::new() } else {
              let v47_6: Path = concat_path(&(v44_6),&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
              let v47_11: Space = routine_3(c, &(v47_6), &v36_39_cursor);
              drop(v47_6);
              compose(&(v45_10),&(v47_11))
            };
            drop(v45_10);
            let v45_13: Space = unite(&(v45_8),&(v45_12));
            join_wrapped_into(&mut v44_11_write,&((v45_13).read_zipper()),&[]);
            }
            v36_39_cursor.ascend(1);
          }
          drop(v44_11_write);
          drop(v44_6);
          compose(&(v39_10),&(v44_11))
        };
        drop(v39_10);
        let v39_13: Space = unite(&(v39_8),&(v39_12));
        join_wrapped_into(&mut v38_7_write,&((v39_13).read_zipper()),&[]);
        }
        v36_39_cursor.ascend(1);
      }
      drop(v38_7_write);
      compose(&(v37_5),&(v38_7))
    };
    drop(v37_5);
    let v37_9: Space = intersect(&(*CONSTANT_1),&(v37_2));
    drop(v37_2);
    let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
    drop(v37_9);
    let v37_19: Space = if (&(v37_10)).is_empty() { Space::new() } else {
      let v48_12: Space = restrict_to(&(*CONSTANT_4),&(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)])));
      let mut v48_13 = Space::new();
      let mut v48_13_write = v48_13.write_zipper();
      let mut v48_13_cursor = (v48_12).read_zipper();
      let v48_13_origin = v48_13_cursor.path().len();
      for v48_13_byte in v48_13_cursor.child_mask().iter() {
        v48_13_cursor.descend_to_existing_byte(v48_13_byte);
        {
        let v49_2: Space = singleton(&v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 1)]);
        let v49_3: Space = intersect(&(*CONSTANT_1),&(v49_2));
        let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
        drop(v49_3);
        let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
        drop(v49_4);
        let v49_7: Space = if (&(v49_5)).is_empty() { Space::new() } else {
          let mut v50_6 = Space::new();
          let mut v50_6_write = v50_6.write_zipper();
          for v50_6_byte in v48_13_cursor.child_mask().iter() {
            v48_13_cursor.descend_to_existing_byte(v50_6_byte);
            {
            let v51_2: Space = singleton(&v48_13_cursor.path()[(v48_13_origin + 1)..(v48_13_origin + 2)]);
            let v51_3: Space = intersect(&(*CONSTANT_1),&(v51_2));
            let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
            drop(v51_3);
            let v51_5: Space = subtract(&(*CONSTANT_0),&(v51_4));
            drop(v51_4);
            let v51_8: Space = if (&(v51_5)).is_empty() { Space::new() } else {
              let v52_7: Space = routine_10(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v51_5),&(v52_7))
            };
            drop(v51_5);
            let v51_9: Space = intersect(&(*CONSTANT_1),&(v51_2));
            drop(v51_2);
            let v51_10: Space = if has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
            drop(v51_9);
            let v51_12: Space = if (&(v51_10)).is_empty() { Space::new() } else {
              let v53_11: Space = routine_11(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v51_10),&(v53_11))
            };
            drop(v51_10);
            let v51_13: Space = unite(&(v51_8),&(v51_12));
            join_wrapped_into(&mut v50_6_write,&((v51_13).read_zipper()),&[]);
            }
            v48_13_cursor.ascend(1);
          }
          drop(v50_6_write);
          compose(&(v49_5),&(v50_6))
        };
        drop(v49_5);
        let v49_8: Space = intersect(&(*CONSTANT_1),&(v49_2));
        drop(v49_2);
        let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
        drop(v49_8);
        let v49_11: Space = if (&(v49_9)).is_empty() { Space::new() } else {
          let mut v54_10 = Space::new();
          let mut v54_10_write = v54_10.write_zipper();
          for v54_10_byte in v48_13_cursor.child_mask().iter() {
            v48_13_cursor.descend_to_existing_byte(v54_10_byte);
            {
            let v55_2: Space = singleton(&v48_13_cursor.path()[(v48_13_origin + 1)..(v48_13_origin + 2)]);
            let v55_3: Space = intersect(&(*CONSTANT_1),&(v55_2));
            let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
            drop(v55_3);
            let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
            drop(v55_4);
            let v55_8: Space = if (&(v55_5)).is_empty() { Space::new() } else {
              let v56_7: Space = routine_10(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v55_5),&(v56_7))
            };
            drop(v55_5);
            let v55_9: Space = intersect(&(*CONSTANT_1),&(v55_2));
            drop(v55_2);
            let v55_10: Space = if has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
            drop(v55_9);
            let v55_12: Space = if (&(v55_10)).is_empty() { Space::new() } else {
              let v57_11: Space = routine_12(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v55_10),&(v57_11))
            };
            drop(v55_10);
            let v55_13: Space = unite(&(v55_8),&(v55_12));
            join_wrapped_into(&mut v54_10_write,&((v55_13).read_zipper()),&[]);
            }
            v48_13_cursor.ascend(1);
          }
          drop(v54_10_write);
          compose(&(v49_9),&(v54_10))
        };
        drop(v49_9);
        let v49_12: Space = unite(&(v49_7),&(v49_11));
        join_wrapped_into(&mut v48_13_write,&((v49_12).read_zipper()),&[]);
        }
        v48_13_cursor.ascend(1);
      }
      drop(v48_13_cursor);
      drop(v48_13_write);
      drop(v48_12);
      let v48_14: Space = restrict_to(&(*CONSTANT_3),&(v48_13));
      let mut v48_15 = Space::new();
      let mut v48_15_write = v48_15.write_zipper();
      let mut v48_15_cursor = (v48_14).read_zipper();
      let v48_15_origin = v48_15_cursor.path().len();
      for v48_15_byte in v48_15_cursor.child_mask().iter() {
        v48_15_cursor.descend_to_existing_byte(v48_15_byte);
        {
        let v58_2: Space = singleton(&v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 1)]);
        let v58_3: Space = intersect(&(*CONSTANT_1),&(v58_2));
        let v58_4: Space = if has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
        drop(v58_3);
        let v58_5: Space = subtract(&(*CONSTANT_0),&(v58_4));
        drop(v58_4);
        let v58_7: Space = if (&(v58_5)).is_empty() { Space::new() } else {
          let mut v59_6 = Space::new();
          let mut v59_6_write = v59_6.write_zipper();
          for v59_6_byte in v48_15_cursor.child_mask().iter() {
            v48_15_cursor.descend_to_existing_byte(v59_6_byte);
            {
            let v60_2: Space = singleton(&v48_15_cursor.path()[(v48_15_origin + 1)..(v48_15_origin + 2)]);
            let v60_3: Space = intersect(&(*CONSTANT_1),&(v60_2));
            let v60_4: Space = if has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
            drop(v60_3);
            let v60_5: Space = subtract(&(*CONSTANT_0),&(v60_4));
            drop(v60_4);
            let v60_8: Space = if (&(v60_5)).is_empty() { Space::new() } else {
              let v61_7: Space = routine_13(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v60_5),&(v61_7))
            };
            drop(v60_5);
            let v60_9: Space = intersect(&(*CONSTANT_1),&(v60_2));
            drop(v60_2);
            let v60_10: Space = if has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
            drop(v60_9);
            let v60_12: Space = if (&(v60_10)).is_empty() { Space::new() } else {
              let v62_11: Space = routine_14(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v60_10),&(v62_11))
            };
            drop(v60_10);
            let v60_13: Space = unite(&(v60_8),&(v60_12));
            join_wrapped_into(&mut v59_6_write,&((v60_13).read_zipper()),&[]);
            }
            v48_15_cursor.ascend(1);
          }
          drop(v59_6_write);
          compose(&(v58_5),&(v59_6))
        };
        drop(v58_5);
        let v58_8: Space = intersect(&(*CONSTANT_1),&(v58_2));
        drop(v58_2);
        let v58_9: Space = if has_head(&(v58_8)) { singleton(&[]) } else { Space::new() };
        drop(v58_8);
        let v58_11: Space = if (&(v58_9)).is_empty() { Space::new() } else {
          let mut v63_10 = Space::new();
          let mut v63_10_write = v63_10.write_zipper();
          for v63_10_byte in v48_15_cursor.child_mask().iter() {
            v48_15_cursor.descend_to_existing_byte(v63_10_byte);
            {
            let v64_2: Space = singleton(&v48_15_cursor.path()[(v48_15_origin + 1)..(v48_15_origin + 2)]);
            let v64_3: Space = intersect(&(*CONSTANT_1),&(v64_2));
            let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
            drop(v64_3);
            let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
            drop(v64_4);
            let v64_8: Space = if (&(v64_5)).is_empty() { Space::new() } else {
              let v65_7: Space = routine_13(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v64_5),&(v65_7))
            };
            drop(v64_5);
            let v64_9: Space = intersect(&(*CONSTANT_1),&(v64_2));
            drop(v64_2);
            let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
            drop(v64_9);
            let v64_12: Space = if (&(v64_10)).is_empty() { Space::new() } else {
              let v66_11: Space = routine_15(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v64_10),&(v66_11))
            };
            drop(v64_10);
            let v64_13: Space = unite(&(v64_8),&(v64_12));
            join_wrapped_into(&mut v63_10_write,&((v64_13).read_zipper()),&[]);
            }
            v48_15_cursor.ascend(1);
          }
          drop(v63_10_write);
          compose(&(v58_9),&(v63_10))
        };
        drop(v58_9);
        let v58_12: Space = unite(&(v58_7),&(v58_11));
        join_wrapped_into(&mut v48_15_write,&((v58_12).read_zipper()),&[]);
        }
        v48_15_cursor.ascend(1);
      }
      drop(v48_15_cursor);
      drop(v48_15_write);
      let v48_17: Space = subtract(&(v48_15),&(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)])));
      let v48_18: Space = intersect(&(v48_17),&(*CONSTANT_5));
      compose(&(v37_10),&(v48_18))
    };
    drop(v37_10);
    let v67_6: Path = concat_path(&(*p0),&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)]);
    let v37_20: Space = wrap(&(v37_19),&(v67_6));
    let v37_21: Space = unite(&(v37_8),&(v37_20));
    join_wrapped_into(&mut v36_39_write,&((v37_21).read_zipper()),&[]);
    }
    v36_39_cursor.ascend(1);
  }
  drop(v36_39_cursor);
  drop(v36_39_write);
  (v36_39).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v68_6: Space = restrict_to(&(*CONSTANT_4),&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0))));
  let mut v68_25 = Space::new();
  let mut v68_25_write = v68_25.write_zipper();
  let mut v68_25_cursor = (v68_6).read_zipper();
  let v68_25_origin = v68_25_cursor.path().len();
  for v68_25_byte in v68_25_cursor.child_mask().iter() {
    v68_25_cursor.descend_to_existing_byte(v68_25_byte);
    {
    let v69_2: Space = singleton(&v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 1)]);
    let v69_3: Space = intersect(&(*CONSTANT_1),&(v69_2));
    let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
    drop(v69_3);
    let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
    drop(v69_4);
    let v69_7: Space = if (&(v69_5)).is_empty() { Space::new() } else {
      let mut v70_6 = Space::new();
      let mut v70_6_write = v70_6.write_zipper();
      for v70_6_byte in v68_25_cursor.child_mask().iter() {
        v68_25_cursor.descend_to_existing_byte(v70_6_byte);
        {
        let v71_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 1)..(v68_25_origin + 2)]);
        let v71_3: Space = intersect(&(*CONSTANT_1),&(v71_2));
        let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
        drop(v71_3);
        let v71_5: Space = subtract(&(*CONSTANT_0),&(v71_4));
        drop(v71_4);
        let v71_8: Space = if (&(v71_5)).is_empty() { Space::new() } else {
          let mut v72_7 = Space::new();
          let mut v72_7_write = v72_7.write_zipper();
          for v72_7_byte in v68_25_cursor.child_mask().iter() {
            v68_25_cursor.descend_to_existing_byte(v72_7_byte);
            {
            let v73_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 2)..(v68_25_origin + 3)]);
            let v73_3: Space = intersect(&(*CONSTANT_1),&(v73_2));
            let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
            drop(v73_3);
            let v73_5: Space = subtract(&(*CONSTANT_0),&(v73_4));
            drop(v73_4);
            let v73_8: Space = if (&(v73_5)).is_empty() { Space::new() } else {
              let v74_7: Space = routine_16(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v73_5),&(v74_7))
            };
            drop(v73_5);
            let v73_9: Space = intersect(&(*CONSTANT_1),&(v73_2));
            drop(v73_2);
            let v73_10: Space = if has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
            drop(v73_9);
            let v73_12: Space = if (&(v73_10)).is_empty() { Space::new() } else {
              let v75_11: Space = routine_17(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v73_10),&(v75_11))
            };
            drop(v73_10);
            let v73_13: Space = unite(&(v73_8),&(v73_12));
            join_wrapped_into(&mut v72_7_write,&((v73_13).read_zipper()),&[]);
            }
            v68_25_cursor.ascend(1);
          }
          drop(v72_7_write);
          compose(&(v71_5),&(v72_7))
        };
        drop(v71_5);
        let v71_9: Space = intersect(&(*CONSTANT_1),&(v71_2));
        drop(v71_2);
        let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
        drop(v71_9);
        let v71_12: Space = if (&(v71_10)).is_empty() { Space::new() } else {
          let mut v76_11 = Space::new();
          let mut v76_11_write = v76_11.write_zipper();
          for v76_11_byte in v68_25_cursor.child_mask().iter() {
            v68_25_cursor.descend_to_existing_byte(v76_11_byte);
            {
            let v77_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 2)..(v68_25_origin + 3)]);
            let v77_3: Space = intersect(&(*CONSTANT_1),&(v77_2));
            let v77_4: Space = if has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
            drop(v77_3);
            let v77_5: Space = subtract(&(*CONSTANT_0),&(v77_4));
            drop(v77_4);
            let v77_8: Space = if (&(v77_5)).is_empty() { Space::new() } else {
              let v78_7: Space = routine_16(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v77_5),&(v78_7))
            };
            drop(v77_5);
            let v77_9: Space = intersect(&(*CONSTANT_1),&(v77_2));
            drop(v77_2);
            let v77_10: Space = if has_head(&(v77_9)) { singleton(&[]) } else { Space::new() };
            drop(v77_9);
            let v77_12: Space = if (&(v77_10)).is_empty() { Space::new() } else {
              let v79_11: Space = routine_12(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v77_10),&(v79_11))
            };
            drop(v77_10);
            let v77_13: Space = unite(&(v77_8),&(v77_12));
            join_wrapped_into(&mut v76_11_write,&((v77_13).read_zipper()),&[]);
            }
            v68_25_cursor.ascend(1);
          }
          drop(v76_11_write);
          compose(&(v71_10),&(v76_11))
        };
        drop(v71_10);
        let v71_13: Space = unite(&(v71_8),&(v71_12));
        join_wrapped_into(&mut v70_6_write,&((v71_13).read_zipper()),&[]);
        }
        v68_25_cursor.ascend(1);
      }
      drop(v70_6_write);
      compose(&(v69_5),&(v70_6))
    };
    drop(v69_5);
    let v69_8: Space = intersect(&(*CONSTANT_1),&(v69_2));
    drop(v69_2);
    let v69_9: Space = if has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
    drop(v69_8);
    let v69_11: Space = if (&(v69_9)).is_empty() { Space::new() } else {
      let mut v80_10 = Space::new();
      let mut v80_10_write = v80_10.write_zipper();
      for v80_10_byte in v68_25_cursor.child_mask().iter() {
        v68_25_cursor.descend_to_existing_byte(v80_10_byte);
        {
        let v81_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 1)..(v68_25_origin + 2)]);
        let v81_3: Space = intersect(&(*CONSTANT_1),&(v81_2));
        let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
        drop(v81_3);
        let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
        drop(v81_4);
        let v81_8: Space = if (&(v81_5)).is_empty() { Space::new() } else {
          let mut v82_7 = Space::new();
          let mut v82_7_write = v82_7.write_zipper();
          for v82_7_byte in v68_25_cursor.child_mask().iter() {
            v68_25_cursor.descend_to_existing_byte(v82_7_byte);
            {
            let v83_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 2)..(v68_25_origin + 3)]);
            let v83_3: Space = intersect(&(*CONSTANT_1),&(v83_2));
            let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
            drop(v83_3);
            let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
            drop(v83_4);
            let v83_8: Space = if (&(v83_5)).is_empty() { Space::new() } else {
              let v84_7: Space = routine_16(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v83_5),&(v84_7))
            };
            drop(v83_5);
            let v83_9: Space = intersect(&(*CONSTANT_1),&(v83_2));
            drop(v83_2);
            let v83_10: Space = if has_head(&(v83_9)) { singleton(&[]) } else { Space::new() };
            drop(v83_9);
            let v83_12: Space = if (&(v83_10)).is_empty() { Space::new() } else {
              let v85_11: Space = routine_17(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v83_10),&(v85_11))
            };
            drop(v83_10);
            let v83_13: Space = unite(&(v83_8),&(v83_12));
            join_wrapped_into(&mut v82_7_write,&((v83_13).read_zipper()),&[]);
            }
            v68_25_cursor.ascend(1);
          }
          drop(v82_7_write);
          compose(&(v81_5),&(v82_7))
        };
        drop(v81_5);
        let v81_9: Space = intersect(&(*CONSTANT_1),&(v81_2));
        drop(v81_2);
        let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
        drop(v81_9);
        let v81_11: Space = compose(&(v81_10),&v68_25_cursor);
        drop(v81_10);
        let v81_12: Space = unite(&(v81_8),&(v81_11));
        drop(v81_11);
        join_wrapped_into(&mut v80_10_write,&((v81_12).read_zipper()),&[]);
        }
        v68_25_cursor.ascend(1);
      }
      drop(v80_10_write);
      compose(&(v69_9),&(v80_10))
    };
    drop(v69_9);
    let v69_12: Space = unite(&(v69_7),&(v69_11));
    join_wrapped_into(&mut v68_25_write,&((v69_12).read_zipper()),&[]);
    }
    v68_25_cursor.ascend(1);
  }
  drop(v68_25_cursor);
  drop(v68_25_write);
  drop(v68_6);
  let v68_26: Space = restrict_to(&(*CONSTANT_3),&(v68_25));
  let mut v68_45 = Space::new();
  let mut v68_45_write = v68_45.write_zipper();
  let mut v68_45_cursor = (v68_26).read_zipper();
  let v68_45_origin = v68_45_cursor.path().len();
  for v68_45_byte in v68_45_cursor.child_mask().iter() {
    v68_45_cursor.descend_to_existing_byte(v68_45_byte);
    {
    let v86_2: Space = singleton(&v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 1)]);
    let v86_3: Space = intersect(&(*CONSTANT_1),&(v86_2));
    let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
    drop(v86_3);
    let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
    drop(v86_4);
    let v86_7: Space = if (&(v86_5)).is_empty() { Space::new() } else {
      let mut v87_6 = Space::new();
      let mut v87_6_write = v87_6.write_zipper();
      for v87_6_byte in v68_45_cursor.child_mask().iter() {
        v68_45_cursor.descend_to_existing_byte(v87_6_byte);
        {
        let v88_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 1)..(v68_45_origin + 2)]);
        let v88_3: Space = intersect(&(*CONSTANT_1),&(v88_2));
        let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
        drop(v88_3);
        let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
        drop(v88_4);
        let v88_8: Space = if (&(v88_5)).is_empty() { Space::new() } else {
          let mut v89_7 = Space::new();
          let mut v89_7_write = v89_7.write_zipper();
          for v89_7_byte in v68_45_cursor.child_mask().iter() {
            v68_45_cursor.descend_to_existing_byte(v89_7_byte);
            {
            let v90_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 2)..(v68_45_origin + 3)]);
            let v90_3: Space = intersect(&(*CONSTANT_1),&(v90_2));
            let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
            drop(v90_3);
            let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
            drop(v90_4);
            let v90_8: Space = if (&(v90_5)).is_empty() { Space::new() } else {
              let v91_7: Space = routine_18(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v90_5),&(v91_7))
            };
            drop(v90_5);
            let v90_9: Space = intersect(&(*CONSTANT_1),&(v90_2));
            drop(v90_2);
            let v90_10: Space = if has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
            drop(v90_9);
            let v90_12: Space = if (&(v90_10)).is_empty() { Space::new() } else {
              let v92_11: Space = routine_19(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v90_10),&(v92_11))
            };
            drop(v90_10);
            let v90_13: Space = unite(&(v90_8),&(v90_12));
            join_wrapped_into(&mut v89_7_write,&((v90_13).read_zipper()),&[]);
            }
            v68_45_cursor.ascend(1);
          }
          drop(v89_7_write);
          compose(&(v88_5),&(v89_7))
        };
        drop(v88_5);
        let v88_9: Space = intersect(&(*CONSTANT_1),&(v88_2));
        drop(v88_2);
        let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
        drop(v88_9);
        let v88_12: Space = if (&(v88_10)).is_empty() { Space::new() } else {
          let mut v93_11 = Space::new();
          let mut v93_11_write = v93_11.write_zipper();
          for v93_11_byte in v68_45_cursor.child_mask().iter() {
            v68_45_cursor.descend_to_existing_byte(v93_11_byte);
            {
            let v94_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 2)..(v68_45_origin + 3)]);
            let v94_3: Space = intersect(&(*CONSTANT_1),&(v94_2));
            let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
            drop(v94_3);
            let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
            drop(v94_4);
            let v94_8: Space = if (&(v94_5)).is_empty() { Space::new() } else {
              let v95_7: Space = routine_18(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v94_5),&(v95_7))
            };
            drop(v94_5);
            let v94_9: Space = intersect(&(*CONSTANT_1),&(v94_2));
            drop(v94_2);
            let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
            drop(v94_9);
            let v94_12: Space = if (&(v94_10)).is_empty() { Space::new() } else {
              let v96_11: Space = routine_15(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v94_10),&(v96_11))
            };
            drop(v94_10);
            let v94_13: Space = unite(&(v94_8),&(v94_12));
            join_wrapped_into(&mut v93_11_write,&((v94_13).read_zipper()),&[]);
            }
            v68_45_cursor.ascend(1);
          }
          drop(v93_11_write);
          compose(&(v88_10),&(v93_11))
        };
        drop(v88_10);
        let v88_13: Space = unite(&(v88_8),&(v88_12));
        join_wrapped_into(&mut v87_6_write,&((v88_13).read_zipper()),&[]);
        }
        v68_45_cursor.ascend(1);
      }
      drop(v87_6_write);
      compose(&(v86_5),&(v87_6))
    };
    drop(v86_5);
    let v86_8: Space = intersect(&(*CONSTANT_1),&(v86_2));
    drop(v86_2);
    let v86_9: Space = if has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
    drop(v86_8);
    let v86_11: Space = if (&(v86_9)).is_empty() { Space::new() } else {
      let mut v97_10 = Space::new();
      let mut v97_10_write = v97_10.write_zipper();
      for v97_10_byte in v68_45_cursor.child_mask().iter() {
        v68_45_cursor.descend_to_existing_byte(v97_10_byte);
        {
        let v98_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 1)..(v68_45_origin + 2)]);
        let v98_3: Space = intersect(&(*CONSTANT_1),&(v98_2));
        let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
        drop(v98_3);
        let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
        drop(v98_4);
        let v98_8: Space = if (&(v98_5)).is_empty() { Space::new() } else {
          let mut v99_7 = Space::new();
          let mut v99_7_write = v99_7.write_zipper();
          for v99_7_byte in v68_45_cursor.child_mask().iter() {
            v68_45_cursor.descend_to_existing_byte(v99_7_byte);
            {
            let v100_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 2)..(v68_45_origin + 3)]);
            let v100_3: Space = intersect(&(*CONSTANT_1),&(v100_2));
            let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
            drop(v100_3);
            let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
            drop(v100_4);
            let v100_8: Space = if (&(v100_5)).is_empty() { Space::new() } else {
              let v101_7: Space = routine_18(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v100_5),&(v101_7))
            };
            drop(v100_5);
            let v100_9: Space = intersect(&(*CONSTANT_1),&(v100_2));
            drop(v100_2);
            let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
            drop(v100_9);
            let v100_12: Space = if (&(v100_10)).is_empty() { Space::new() } else {
              let v102_11: Space = routine_19(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v100_10),&(v102_11))
            };
            drop(v100_10);
            let v100_13: Space = unite(&(v100_8),&(v100_12));
            join_wrapped_into(&mut v99_7_write,&((v100_13).read_zipper()),&[]);
            }
            v68_45_cursor.ascend(1);
          }
          drop(v99_7_write);
          compose(&(v98_5),&(v99_7))
        };
        drop(v98_5);
        let v98_9: Space = intersect(&(*CONSTANT_1),&(v98_2));
        drop(v98_2);
        let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
        drop(v98_9);
        let v98_11: Space = compose(&(v98_10),&v68_45_cursor);
        drop(v98_10);
        let v98_12: Space = unite(&(v98_8),&(v98_11));
        drop(v98_11);
        join_wrapped_into(&mut v97_10_write,&((v98_12).read_zipper()),&[]);
        }
        v68_45_cursor.ascend(1);
      }
      drop(v97_10_write);
      compose(&(v86_9),&(v97_10))
    };
    drop(v86_9);
    let v86_12: Space = unite(&(v86_7),&(v86_11));
    join_wrapped_into(&mut v68_45_write,&((v86_12).read_zipper()),&[]);
    }
    v68_45_cursor.ascend(1);
  }
  drop(v68_45_cursor);
  drop(v68_45_write);
  let v68_48: Space = subtract(&(v68_45),&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0))));
  let v68_50: Space = intersect(&(v68_48),&(*CONSTANT_5));
  let v68_51: Space = wrap(&(v68_50),&(*p0));
  (v68_51).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v103_2 = Space::new();
  let mut v103_2_write = v103_2.write_zipper();
  let mut v103_2_cursor = (*s0).read_zipper();
  let v103_2_origin = v103_2_cursor.path().len();
  for v103_2_byte in v103_2_cursor.child_mask().iter() {
    v103_2_cursor.descend_to_existing_byte(v103_2_byte);
    {
    let v104_2: Space = Space::new();
    join_wrapped_into(&mut v103_2_write,&((v104_2).read_zipper()),&[]);
    }
    v103_2_cursor.ascend(1);
  }
  drop(v103_2_cursor);
  drop(v103_2_write);
  (v103_2).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v105_28 = Space::new();
  let mut v105_28_write = v105_28.write_zipper();
  let mut v105_28_cursor = (*s0).read_zipper();
  let v105_28_origin = v105_28_cursor.path().len();
  for v105_28_byte in v105_28_cursor.child_mask().iter() {
    v105_28_cursor.descend_to_existing_byte(v105_28_byte);
    {
    let v106_2: Space = singleton(&v105_28_cursor.path()[v105_28_origin..(v105_28_origin + 1)]);
    let v106_3: Space = intersect(&(*CONSTANT_1),&(v106_2));
    drop(v106_2);
    let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
    drop(v106_3);
    let v106_13: Space = if (&(v106_4)).is_empty() { Space::new() } else {
      let v107_6: Space = restrict_to(&(*CONSTANT_4),&(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v105_28_cursor.path()[v105_28_origin..(v105_28_origin + 1)])));
      let mut v107_7 = Space::new();
      let mut v107_7_write = v107_7.write_zipper();
      let mut v107_7_cursor = (v107_6).read_zipper();
      let v107_7_origin = v107_7_cursor.path().len();
      for v107_7_byte in v107_7_cursor.child_mask().iter() {
        v107_7_cursor.descend_to_existing_byte(v107_7_byte);
        {
        let v108_2: Space = singleton(&v107_7_cursor.path()[v107_7_origin..(v107_7_origin + 1)]);
        let v108_3: Space = intersect(&(*CONSTANT_1),&(v108_2));
        let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
        drop(v108_3);
        let v108_5: Space = subtract(&(*CONSTANT_0),&(v108_4));
        drop(v108_4);
        let v108_7: Space = if (&(v108_5)).is_empty() { Space::new() } else {
          let mut v109_6 = Space::new();
          let mut v109_6_write = v109_6.write_zipper();
          for v109_6_byte in v107_7_cursor.child_mask().iter() {
            v107_7_cursor.descend_to_existing_byte(v109_6_byte);
            {
            let v110_2: Space = singleton(&v107_7_cursor.path()[(v107_7_origin + 1)..(v107_7_origin + 2)]);
            let v110_3: Space = intersect(&(*CONSTANT_1),&(v110_2));
            let v110_4: Space = if has_head(&(v110_3)) { singleton(&[]) } else { Space::new() };
            drop(v110_3);
            let v110_5: Space = subtract(&(*CONSTANT_0),&(v110_4));
            drop(v110_4);
            let v110_8: Space = if (&(v110_5)).is_empty() { Space::new() } else {
              let v111_7: Space = routine_10(c, &v107_7_cursor.path()[v107_7_origin..(v107_7_origin + 2)], &v107_7_cursor);
              compose(&(v110_5),&(v111_7))
            };
            drop(v110_5);
            let v110_9: Space = intersect(&(*CONSTANT_1),&(v110_2));
            drop(v110_2);
            let v110_10: Space = if has_head(&(v110_9)) { singleton(&[]) } else { Space::new() };
            drop(v110_9);
            let v110_12: Space = if (&(v110_10)).is_empty() { Space::new() } else {
              let v112_11: Space = routine_11(c, &v107_7_cursor.path()[v107_7_origin..(v107_7_origin + 2)], &v107_7_cursor);
              compose(&(v110_10),&(v112_11))
            };
            drop(v110_10);
            let v110_13: Space = unite(&(v110_8),&(v110_12));
            join_wrapped_into(&mut v109_6_write,&((v110_13).read_zipper()),&[]);
            }
            v107_7_cursor.ascend(1);
          }
          drop(v109_6_write);
          compose(&(v108_5),&(v109_6))
        };
        drop(v108_5);
        let v108_8: Space = intersect(&(*CONSTANT_1),&(v108_2));
        drop(v108_2);
        let v108_9: Space = if has_head(&(v108_8)) { singleton(&[]) } else { Space::new() };
        drop(v108_8);
        let v108_11: Space = if (&(v108_9)).is_empty() { Space::new() } else {
          let mut v113_10 = Space::new();
          let mut v113_10_write = v113_10.write_zipper();
          for v113_10_byte in v107_7_cursor.child_mask().iter() {
            v107_7_cursor.descend_to_existing_byte(v113_10_byte);
            {
            let v114_2: Space = singleton(&v107_7_cursor.path()[(v107_7_origin + 1)..(v107_7_origin + 2)]);
            let v114_3: Space = intersect(&(*CONSTANT_1),&(v114_2));
            let v114_4: Space = if has_head(&(v114_3)) { singleton(&[]) } else { Space::new() };
            drop(v114_3);
            let v114_5: Space = subtract(&(*CONSTANT_0),&(v114_4));
            drop(v114_4);
            let v114_8: Space = if (&(v114_5)).is_empty() { Space::new() } else {
              let v115_7: Space = routine_10(c, &v107_7_cursor.path()[v107_7_origin..(v107_7_origin + 2)], &v107_7_cursor);
              compose(&(v114_5),&(v115_7))
            };
            drop(v114_5);
            let v114_9: Space = intersect(&(*CONSTANT_1),&(v114_2));
            drop(v114_2);
            let v114_10: Space = if has_head(&(v114_9)) { singleton(&[]) } else { Space::new() };
            drop(v114_9);
            let v114_12: Space = if (&(v114_10)).is_empty() { Space::new() } else {
              let v116_11: Space = routine_12(c, &v107_7_cursor.path()[v107_7_origin..(v107_7_origin + 2)], &v107_7_cursor);
              compose(&(v114_10),&(v116_11))
            };
            drop(v114_10);
            let v114_13: Space = unite(&(v114_8),&(v114_12));
            join_wrapped_into(&mut v113_10_write,&((v114_13).read_zipper()),&[]);
            }
            v107_7_cursor.ascend(1);
          }
          drop(v113_10_write);
          compose(&(v108_9),&(v113_10))
        };
        drop(v108_9);
        let v108_12: Space = unite(&(v108_7),&(v108_11));
        join_wrapped_into(&mut v107_7_write,&((v108_12).read_zipper()),&[]);
        }
        v107_7_cursor.ascend(1);
      }
      drop(v107_7_cursor);
      drop(v107_7_write);
      drop(v107_6);
      let v107_8: Space = restrict_to(&(*CONSTANT_3),&(v107_7));
      let mut v107_9 = Space::new();
      let mut v107_9_write = v107_9.write_zipper();
      let mut v107_9_cursor = (v107_8).read_zipper();
      let v107_9_origin = v107_9_cursor.path().len();
      for v107_9_byte in v107_9_cursor.child_mask().iter() {
        v107_9_cursor.descend_to_existing_byte(v107_9_byte);
        {
        let v117_2: Space = singleton(&v107_9_cursor.path()[v107_9_origin..(v107_9_origin + 1)]);
        let v117_3: Space = intersect(&(*CONSTANT_1),&(v117_2));
        let v117_4: Space = if has_head(&(v117_3)) { singleton(&[]) } else { Space::new() };
        drop(v117_3);
        let v117_5: Space = subtract(&(*CONSTANT_0),&(v117_4));
        drop(v117_4);
        let v117_7: Space = if (&(v117_5)).is_empty() { Space::new() } else {
          let mut v118_6 = Space::new();
          let mut v118_6_write = v118_6.write_zipper();
          for v118_6_byte in v107_9_cursor.child_mask().iter() {
            v107_9_cursor.descend_to_existing_byte(v118_6_byte);
            {
            let v119_2: Space = singleton(&v107_9_cursor.path()[(v107_9_origin + 1)..(v107_9_origin + 2)]);
            let v119_3: Space = intersect(&(*CONSTANT_1),&(v119_2));
            let v119_4: Space = if has_head(&(v119_3)) { singleton(&[]) } else { Space::new() };
            drop(v119_3);
            let v119_5: Space = subtract(&(*CONSTANT_0),&(v119_4));
            drop(v119_4);
            let v119_8: Space = if (&(v119_5)).is_empty() { Space::new() } else {
              let v120_7: Space = routine_13(c, &v107_9_cursor.path()[v107_9_origin..(v107_9_origin + 2)], &v107_9_cursor);
              compose(&(v119_5),&(v120_7))
            };
            drop(v119_5);
            let v119_9: Space = intersect(&(*CONSTANT_1),&(v119_2));
            drop(v119_2);
            let v119_10: Space = if has_head(&(v119_9)) { singleton(&[]) } else { Space::new() };
            drop(v119_9);
            let v119_12: Space = if (&(v119_10)).is_empty() { Space::new() } else {
              let v121_11: Space = routine_14(c, &v107_9_cursor.path()[v107_9_origin..(v107_9_origin + 2)], &v107_9_cursor);
              compose(&(v119_10),&(v121_11))
            };
            drop(v119_10);
            let v119_13: Space = unite(&(v119_8),&(v119_12));
            join_wrapped_into(&mut v118_6_write,&((v119_13).read_zipper()),&[]);
            }
            v107_9_cursor.ascend(1);
          }
          drop(v118_6_write);
          compose(&(v117_5),&(v118_6))
        };
        drop(v117_5);
        let v117_8: Space = intersect(&(*CONSTANT_1),&(v117_2));
        drop(v117_2);
        let v117_9: Space = if has_head(&(v117_8)) { singleton(&[]) } else { Space::new() };
        drop(v117_8);
        let v117_11: Space = if (&(v117_9)).is_empty() { Space::new() } else {
          let mut v122_10 = Space::new();
          let mut v122_10_write = v122_10.write_zipper();
          for v122_10_byte in v107_9_cursor.child_mask().iter() {
            v107_9_cursor.descend_to_existing_byte(v122_10_byte);
            {
            let v123_2: Space = singleton(&v107_9_cursor.path()[(v107_9_origin + 1)..(v107_9_origin + 2)]);
            let v123_3: Space = intersect(&(*CONSTANT_1),&(v123_2));
            let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
            drop(v123_3);
            let v123_5: Space = subtract(&(*CONSTANT_0),&(v123_4));
            drop(v123_4);
            let v123_8: Space = if (&(v123_5)).is_empty() { Space::new() } else {
              let v124_7: Space = routine_13(c, &v107_9_cursor.path()[v107_9_origin..(v107_9_origin + 2)], &v107_9_cursor);
              compose(&(v123_5),&(v124_7))
            };
            drop(v123_5);
            let v123_9: Space = intersect(&(*CONSTANT_1),&(v123_2));
            drop(v123_2);
            let v123_10: Space = if has_head(&(v123_9)) { singleton(&[]) } else { Space::new() };
            drop(v123_9);
            let v123_12: Space = if (&(v123_10)).is_empty() { Space::new() } else {
              let v125_11: Space = routine_15(c, &v107_9_cursor.path()[v107_9_origin..(v107_9_origin + 2)], &v107_9_cursor);
              compose(&(v123_10),&(v125_11))
            };
            drop(v123_10);
            let v123_13: Space = unite(&(v123_8),&(v123_12));
            join_wrapped_into(&mut v122_10_write,&((v123_13).read_zipper()),&[]);
            }
            v107_9_cursor.ascend(1);
          }
          drop(v122_10_write);
          compose(&(v117_9),&(v122_10))
        };
        drop(v117_9);
        let v117_12: Space = unite(&(v117_7),&(v117_11));
        join_wrapped_into(&mut v107_9_write,&((v117_12).read_zipper()),&[]);
        }
        v107_9_cursor.ascend(1);
      }
      drop(v107_9_cursor);
      drop(v107_9_write);
      let v107_11: Space = subtract(&(v107_9),&(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v105_28_cursor.path()[v105_28_origin..(v105_28_origin + 1)])));
      let v107_12: Space = intersect(&(v107_11),&(*CONSTANT_5));
      compose(&(v106_4),&(v107_12))
    };
    drop(v106_4);
    let v106_14: Path = concat_path(&(*p0),&v105_28_cursor.path()[v105_28_origin..(v105_28_origin + 1)]);
    join_wrapped_into(&mut v105_28_write,&((v106_13).read_zipper()),&(v106_14));
    drop(v106_14);
    }
    v105_28_cursor.ascend(1);
  }
  drop(v105_28_cursor);
  drop(v105_28_write);
  (v105_28).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v126_20 = Space::new();
  let mut v126_20_write = v126_20.write_zipper();
  let mut v126_20_cursor = (*s0).read_zipper();
  let v126_20_origin = v126_20_cursor.path().len();
  for v126_20_byte in v126_20_cursor.child_mask().iter() {
    v126_20_cursor.descend_to_existing_byte(v126_20_byte);
    {
    let v127_2: Space = singleton(&v126_20_cursor.path()[v126_20_origin..(v126_20_origin + 1)]);
    let v127_3: Space = intersect(&(*CONSTANT_1),&(v127_2));
    let v127_4: Space = if has_head(&(v127_3)) { singleton(&[]) } else { Space::new() };
    drop(v127_3);
    let v127_5: Space = subtract(&(*CONSTANT_0),&(v127_4));
    drop(v127_4);
    let v127_8: Space = if (&(v127_5)).is_empty() { Space::new() } else {
      let v128_6: Path = concat_path(&(*p0),&v126_20_cursor.path()[v126_20_origin..(v126_20_origin + 1)]);
      let mut v128_7 = Space::new();
      let mut v128_7_write = v128_7.write_zipper();
      for v128_7_byte in v126_20_cursor.child_mask().iter() {
        v126_20_cursor.descend_to_existing_byte(v128_7_byte);
        {
        let v129_2: Space = singleton(&v126_20_cursor.path()[(v126_20_origin + 1)..(v126_20_origin + 2)]);
        let v129_3: Space = intersect(&(*CONSTANT_1),&(v129_2));
        let v129_4: Space = if has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
        drop(v129_3);
        let v129_5: Space = subtract(&(*CONSTANT_0),&(v129_4));
        drop(v129_4);
        let v129_8: Space = if (&(v129_5)).is_empty() { Space::new() } else {
          let v130_6: Path = concat_path(&(v128_6),&v126_20_cursor.path()[(v126_20_origin + 1)..(v126_20_origin + 2)]);
          let mut v130_7 = Space::new();
          let mut v130_7_write = v130_7.write_zipper();
          for v130_7_byte in v126_20_cursor.child_mask().iter() {
            v126_20_cursor.descend_to_existing_byte(v130_7_byte);
            {
            let v131_2: Space = singleton(&v126_20_cursor.path()[(v126_20_origin + 2)..(v126_20_origin + 3)]);
            let v131_3: Space = intersect(&(*CONSTANT_1),&(v131_2));
            let v131_4: Space = if has_head(&(v131_3)) { singleton(&[]) } else { Space::new() };
            drop(v131_3);
            let v131_5: Space = subtract(&(*CONSTANT_0),&(v131_4));
            drop(v131_4);
            let v131_8: Space = if (&(v131_5)).is_empty() { Space::new() } else {
              let v132_6: Path = concat_path(&(v130_6),&v126_20_cursor.path()[(v126_20_origin + 2)..(v126_20_origin + 3)]);
              let v132_7: Space = routine_20(c, &(v132_6), &v126_20_cursor);
              compose(&(v131_5),&(v132_7))
            };
            drop(v131_5);
            let v131_9: Space = intersect(&(*CONSTANT_1),&(v131_2));
            drop(v131_2);
            let v131_10: Space = if has_head(&(v131_9)) { singleton(&[]) } else { Space::new() };
            drop(v131_9);
            let v131_12: Space = if (&(v131_10)).is_empty() { Space::new() } else {
              let v133_6: Path = concat_path(&(v130_6),&v126_20_cursor.path()[(v126_20_origin + 2)..(v126_20_origin + 3)]);
              let v133_11: Space = routine_21(c, &(v133_6), &v126_20_cursor);
              drop(v133_6);
              compose(&(v131_10),&(v133_11))
            };
            drop(v131_10);
            let v131_13: Space = unite(&(v131_8),&(v131_12));
            join_wrapped_into(&mut v130_7_write,&((v131_13).read_zipper()),&[]);
            }
            v126_20_cursor.ascend(1);
          }
          drop(v130_7_write);
          compose(&(v129_5),&(v130_7))
        };
        drop(v129_5);
        let v129_9: Space = intersect(&(*CONSTANT_1),&(v129_2));
        drop(v129_2);
        let v129_10: Space = if has_head(&(v129_9)) { singleton(&[]) } else { Space::new() };
        drop(v129_9);
        let v129_12: Space = if (&(v129_10)).is_empty() { Space::new() } else {
          let v134_6: Path = concat_path(&(v128_6),&v126_20_cursor.path()[(v126_20_origin + 1)..(v126_20_origin + 2)]);
          let mut v134_11 = Space::new();
          let mut v134_11_write = v134_11.write_zipper();
          for v134_11_byte in v126_20_cursor.child_mask().iter() {
            v126_20_cursor.descend_to_existing_byte(v134_11_byte);
            {
            let v135_2: Space = singleton(&v126_20_cursor.path()[(v126_20_origin + 2)..(v126_20_origin + 3)]);
            let v135_3: Space = intersect(&(*CONSTANT_1),&(v135_2));
            let v135_4: Space = if has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
            drop(v135_3);
            let v135_5: Space = subtract(&(*CONSTANT_0),&(v135_4));
            drop(v135_4);
            let v135_8: Space = if (&(v135_5)).is_empty() { Space::new() } else {
              let v136_6: Path = concat_path(&(v134_6),&v126_20_cursor.path()[(v126_20_origin + 2)..(v126_20_origin + 3)]);
              let v136_7: Space = routine_20(c, &(v136_6), &v126_20_cursor);
              compose(&(v135_5),&(v136_7))
            };
            drop(v135_5);
            let v135_9: Space = intersect(&(*CONSTANT_1),&(v135_2));
            drop(v135_2);
            let v135_10: Space = if has_head(&(v135_9)) { singleton(&[]) } else { Space::new() };
            drop(v135_9);
            let v135_12: Space = if (&(v135_10)).is_empty() { Space::new() } else {
              let v137_6: Path = concat_path(&(v134_6),&v126_20_cursor.path()[(v126_20_origin + 2)..(v126_20_origin + 3)]);
              let v137_11: Space = routine_12(c, &(v137_6), &v126_20_cursor);
              drop(v137_6);
              compose(&(v135_10),&(v137_11))
            };
            drop(v135_10);
            let v135_13: Space = unite(&(v135_8),&(v135_12));
            join_wrapped_into(&mut v134_11_write,&((v135_13).read_zipper()),&[]);
            }
            v126_20_cursor.ascend(1);
          }
          drop(v134_11_write);
          drop(v134_6);
          compose(&(v129_10),&(v134_11))
        };
        drop(v129_10);
        let v129_13: Space = unite(&(v129_8),&(v129_12));
        join_wrapped_into(&mut v128_7_write,&((v129_13).read_zipper()),&[]);
        }
        v126_20_cursor.ascend(1);
      }
      drop(v128_7_write);
      compose(&(v127_5),&(v128_7))
    };
    drop(v127_5);
    let v127_9: Space = intersect(&(*CONSTANT_1),&(v127_2));
    drop(v127_2);
    let v127_10: Space = if has_head(&(v127_9)) { singleton(&[]) } else { Space::new() };
    drop(v127_9);
    let v127_12: Space = if (&(v127_10)).is_empty() { Space::new() } else {
      let v138_6: Path = concat_path(&(*p0),&v126_20_cursor.path()[v126_20_origin..(v126_20_origin + 1)]);
      let mut v138_11 = Space::new();
      let mut v138_11_write = v138_11.write_zipper();
      for v138_11_byte in v126_20_cursor.child_mask().iter() {
        v126_20_cursor.descend_to_existing_byte(v138_11_byte);
        {
        let v139_2: Space = singleton(&v126_20_cursor.path()[(v126_20_origin + 1)..(v126_20_origin + 2)]);
        let v139_3: Space = intersect(&(*CONSTANT_1),&(v139_2));
        let v139_4: Space = if has_head(&(v139_3)) { singleton(&[]) } else { Space::new() };
        drop(v139_3);
        let v139_5: Space = subtract(&(*CONSTANT_0),&(v139_4));
        drop(v139_4);
        let v139_8: Space = if (&(v139_5)).is_empty() { Space::new() } else {
          let v140_6: Path = concat_path(&(v138_6),&v126_20_cursor.path()[(v126_20_origin + 1)..(v126_20_origin + 2)]);
          let mut v140_7 = Space::new();
          let mut v140_7_write = v140_7.write_zipper();
          for v140_7_byte in v126_20_cursor.child_mask().iter() {
            v126_20_cursor.descend_to_existing_byte(v140_7_byte);
            {
            let v141_2: Space = singleton(&v126_20_cursor.path()[(v126_20_origin + 2)..(v126_20_origin + 3)]);
            let v141_3: Space = intersect(&(*CONSTANT_1),&(v141_2));
            let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
            drop(v141_3);
            let v141_5: Space = subtract(&(*CONSTANT_0),&(v141_4));
            drop(v141_4);
            let v141_8: Space = if (&(v141_5)).is_empty() { Space::new() } else {
              let v142_6: Path = concat_path(&(v140_6),&v126_20_cursor.path()[(v126_20_origin + 2)..(v126_20_origin + 3)]);
              let v142_7: Space = routine_20(c, &(v142_6), &v126_20_cursor);
              compose(&(v141_5),&(v142_7))
            };
            drop(v141_5);
            let v141_9: Space = intersect(&(*CONSTANT_1),&(v141_2));
            drop(v141_2);
            let v141_10: Space = if has_head(&(v141_9)) { singleton(&[]) } else { Space::new() };
            drop(v141_9);
            let v141_12: Space = if (&(v141_10)).is_empty() { Space::new() } else {
              let v143_6: Path = concat_path(&(v140_6),&v126_20_cursor.path()[(v126_20_origin + 2)..(v126_20_origin + 3)]);
              let v143_11: Space = routine_21(c, &(v143_6), &v126_20_cursor);
              drop(v143_6);
              compose(&(v141_10),&(v143_11))
            };
            drop(v141_10);
            let v141_13: Space = unite(&(v141_8),&(v141_12));
            join_wrapped_into(&mut v140_7_write,&((v141_13).read_zipper()),&[]);
            }
            v126_20_cursor.ascend(1);
          }
          drop(v140_7_write);
          drop(v140_6);
          compose(&(v139_5),&(v140_7))
        };
        drop(v139_5);
        let v139_9: Space = intersect(&(*CONSTANT_1),&(v139_2));
        drop(v139_2);
        let v139_10: Space = if has_head(&(v139_9)) { singleton(&[]) } else { Space::new() };
        drop(v139_9);
        let v139_11: Space = compose(&(v139_10),&v126_20_cursor);
        drop(v139_10);
        let v139_12: Space = unite(&(v139_8),&(v139_11));
        drop(v139_11);
        join_wrapped_into(&mut v138_11_write,&((v139_12).read_zipper()),&[]);
        }
        v126_20_cursor.ascend(1);
      }
      drop(v138_11_write);
      drop(v138_6);
      compose(&(v127_10),&(v138_11))
    };
    drop(v127_10);
    let v127_13: Space = unite(&(v127_8),&(v127_12));
    join_wrapped_into(&mut v126_20_write,&((v127_13).read_zipper()),&[]);
    }
    v126_20_cursor.ascend(1);
  }
  drop(v126_20_cursor);
  drop(v126_20_write);
  (v126_20).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v144_14 = Space::new();
  let mut v144_14_write = v144_14.write_zipper();
  let mut v144_14_cursor = (*s0).read_zipper();
  let v144_14_origin = v144_14_cursor.path().len();
  for v144_14_byte in v144_14_cursor.child_mask().iter() {
    v144_14_cursor.descend_to_existing_byte(v144_14_byte);
    {
    let v145_2: Space = singleton(&v144_14_cursor.path()[v144_14_origin..(v144_14_origin + 1)]);
    let v145_3: Space = intersect(&(*CONSTANT_1),&(v145_2));
    let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
    drop(v145_3);
    let v145_5: Space = subtract(&(*CONSTANT_0),&(v145_4));
    drop(v145_4);
    let v145_8: Space = if (&(v145_5)).is_empty() { Space::new() } else {
      let v146_6: Path = concat_path(&(*p0),&v144_14_cursor.path()[v144_14_origin..(v144_14_origin + 1)]);
      let mut v146_7 = Space::new();
      let mut v146_7_write = v146_7.write_zipper();
      for v146_7_byte in v144_14_cursor.child_mask().iter() {
        v144_14_cursor.descend_to_existing_byte(v146_7_byte);
        {
        let v147_2: Space = singleton(&v144_14_cursor.path()[(v144_14_origin + 1)..(v144_14_origin + 2)]);
        let v147_3: Space = intersect(&(*CONSTANT_1),&(v147_2));
        let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
        drop(v147_3);
        let v147_5: Space = subtract(&(*CONSTANT_0),&(v147_4));
        drop(v147_4);
        let v147_8: Space = if (&(v147_5)).is_empty() { Space::new() } else {
          let v148_6: Path = concat_path(&(v146_6),&v144_14_cursor.path()[(v144_14_origin + 1)..(v144_14_origin + 2)]);
          let mut v148_7 = Space::new();
          let mut v148_7_write = v148_7.write_zipper();
          for v148_7_byte in v144_14_cursor.child_mask().iter() {
            v144_14_cursor.descend_to_existing_byte(v148_7_byte);
            {
            let v149_2: Space = singleton(&v144_14_cursor.path()[(v144_14_origin + 2)..(v144_14_origin + 3)]);
            let v149_3: Space = intersect(&(*CONSTANT_1),&(v149_2));
            let v149_4: Space = if has_head(&(v149_3)) { singleton(&[]) } else { Space::new() };
            drop(v149_3);
            let v149_5: Space = subtract(&(*CONSTANT_0),&(v149_4));
            drop(v149_4);
            let v149_8: Space = if (&(v149_5)).is_empty() { Space::new() } else {
              let v150_6: Path = concat_path(&(v148_6),&v144_14_cursor.path()[(v144_14_origin + 2)..(v144_14_origin + 3)]);
              let v150_7: Space = routine_20(c, &(v150_6), &v144_14_cursor);
              compose(&(v149_5),&(v150_7))
            };
            drop(v149_5);
            let v149_9: Space = intersect(&(*CONSTANT_1),&(v149_2));
            drop(v149_2);
            let v149_10: Space = if has_head(&(v149_9)) { singleton(&[]) } else { Space::new() };
            drop(v149_9);
            let v149_12: Space = if (&(v149_10)).is_empty() { Space::new() } else {
              let v151_6: Path = concat_path(&(v148_6),&v144_14_cursor.path()[(v144_14_origin + 2)..(v144_14_origin + 3)]);
              let v151_11: Space = routine_21(c, &(v151_6), &v144_14_cursor);
              drop(v151_6);
              compose(&(v149_10),&(v151_11))
            };
            drop(v149_10);
            let v149_13: Space = unite(&(v149_8),&(v149_12));
            join_wrapped_into(&mut v148_7_write,&((v149_13).read_zipper()),&[]);
            }
            v144_14_cursor.ascend(1);
          }
          drop(v148_7_write);
          compose(&(v147_5),&(v148_7))
        };
        drop(v147_5);
        let v147_9: Space = intersect(&(*CONSTANT_1),&(v147_2));
        drop(v147_2);
        let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
        drop(v147_9);
        let v147_12: Space = if (&(v147_10)).is_empty() { Space::new() } else {
          let v152_6: Path = concat_path(&(v146_6),&v144_14_cursor.path()[(v144_14_origin + 1)..(v144_14_origin + 2)]);
          let mut v152_11 = Space::new();
          let mut v152_11_write = v152_11.write_zipper();
          for v152_11_byte in v144_14_cursor.child_mask().iter() {
            v144_14_cursor.descend_to_existing_byte(v152_11_byte);
            {
            let v153_2: Space = singleton(&v144_14_cursor.path()[(v144_14_origin + 2)..(v144_14_origin + 3)]);
            let v153_3: Space = intersect(&(*CONSTANT_1),&(v153_2));
            let v153_4: Space = if has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
            drop(v153_3);
            let v153_5: Space = subtract(&(*CONSTANT_0),&(v153_4));
            drop(v153_4);
            let v153_8: Space = if (&(v153_5)).is_empty() { Space::new() } else {
              let v154_6: Path = concat_path(&(v152_6),&v144_14_cursor.path()[(v144_14_origin + 2)..(v144_14_origin + 3)]);
              let v154_7: Space = routine_20(c, &(v154_6), &v144_14_cursor);
              compose(&(v153_5),&(v154_7))
            };
            drop(v153_5);
            let v153_9: Space = intersect(&(*CONSTANT_1),&(v153_2));
            drop(v153_2);
            let v153_10: Space = if has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
            drop(v153_9);
            let v153_12: Space = if (&(v153_10)).is_empty() { Space::new() } else {
              let v155_6: Path = concat_path(&(v152_6),&v144_14_cursor.path()[(v144_14_origin + 2)..(v144_14_origin + 3)]);
              let v155_11: Space = routine_12(c, &(v155_6), &v144_14_cursor);
              drop(v155_6);
              compose(&(v153_10),&(v155_11))
            };
            drop(v153_10);
            let v153_13: Space = unite(&(v153_8),&(v153_12));
            join_wrapped_into(&mut v152_11_write,&((v153_13).read_zipper()),&[]);
            }
            v144_14_cursor.ascend(1);
          }
          drop(v152_11_write);
          drop(v152_6);
          compose(&(v147_10),&(v152_11))
        };
        drop(v147_10);
        let v147_13: Space = unite(&(v147_8),&(v147_12));
        join_wrapped_into(&mut v146_7_write,&((v147_13).read_zipper()),&[]);
        }
        v144_14_cursor.ascend(1);
      }
      drop(v146_7_write);
      drop(v146_6);
      compose(&(v145_5),&(v146_7))
    };
    drop(v145_5);
    let v145_9: Space = intersect(&(*CONSTANT_1),&(v145_2));
    drop(v145_2);
    let v145_10: Space = if has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
    drop(v145_9);
    let v145_11: Space = compose(&(v145_10),&v144_14_cursor);
    drop(v145_10);
    let v145_12: Space = unite(&(v145_8),&(v145_11));
    drop(v145_11);
    join_wrapped_into(&mut v144_14_write,&((v145_12).read_zipper()),&[]);
    }
    v144_14_cursor.ascend(1);
  }
  drop(v144_14_cursor);
  drop(v144_14_write);
  (v144_14).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v156_20 = Space::new();
  let mut v156_20_write = v156_20.write_zipper();
  let mut v156_20_cursor = (*s0).read_zipper();
  let v156_20_origin = v156_20_cursor.path().len();
  for v156_20_byte in v156_20_cursor.child_mask().iter() {
    v156_20_cursor.descend_to_existing_byte(v156_20_byte);
    {
    let v157_2: Space = singleton(&v156_20_cursor.path()[v156_20_origin..(v156_20_origin + 1)]);
    let v157_3: Space = intersect(&(*CONSTANT_1),&(v157_2));
    let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
    drop(v157_3);
    let v157_5: Space = subtract(&(*CONSTANT_0),&(v157_4));
    drop(v157_4);
    let v157_8: Space = if (&(v157_5)).is_empty() { Space::new() } else {
      let v158_6: Path = concat_path(&(*p0),&v156_20_cursor.path()[v156_20_origin..(v156_20_origin + 1)]);
      let mut v158_7 = Space::new();
      let mut v158_7_write = v158_7.write_zipper();
      for v158_7_byte in v156_20_cursor.child_mask().iter() {
        v156_20_cursor.descend_to_existing_byte(v158_7_byte);
        {
        let v159_2: Space = singleton(&v156_20_cursor.path()[(v156_20_origin + 1)..(v156_20_origin + 2)]);
        let v159_3: Space = intersect(&(*CONSTANT_1),&(v159_2));
        let v159_4: Space = if has_head(&(v159_3)) { singleton(&[]) } else { Space::new() };
        drop(v159_3);
        let v159_5: Space = subtract(&(*CONSTANT_0),&(v159_4));
        drop(v159_4);
        let v159_8: Space = if (&(v159_5)).is_empty() { Space::new() } else {
          let v160_6: Path = concat_path(&(v158_6),&v156_20_cursor.path()[(v156_20_origin + 1)..(v156_20_origin + 2)]);
          let mut v160_7 = Space::new();
          let mut v160_7_write = v160_7.write_zipper();
          for v160_7_byte in v156_20_cursor.child_mask().iter() {
            v156_20_cursor.descend_to_existing_byte(v160_7_byte);
            {
            let v161_2: Space = singleton(&v156_20_cursor.path()[(v156_20_origin + 2)..(v156_20_origin + 3)]);
            let v161_3: Space = intersect(&(*CONSTANT_1),&(v161_2));
            let v161_4: Space = if has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
            drop(v161_3);
            let v161_5: Space = subtract(&(*CONSTANT_0),&(v161_4));
            drop(v161_4);
            let v161_8: Space = if (&(v161_5)).is_empty() { Space::new() } else {
              let v162_6: Path = concat_path(&(v160_6),&v156_20_cursor.path()[(v156_20_origin + 2)..(v156_20_origin + 3)]);
              let v162_7: Space = routine_22(c, &(v162_6), &v156_20_cursor);
              compose(&(v161_5),&(v162_7))
            };
            drop(v161_5);
            let v161_9: Space = intersect(&(*CONSTANT_1),&(v161_2));
            drop(v161_2);
            let v161_10: Space = if has_head(&(v161_9)) { singleton(&[]) } else { Space::new() };
            drop(v161_9);
            let v161_12: Space = if (&(v161_10)).is_empty() { Space::new() } else {
              let v163_6: Path = concat_path(&(v160_6),&v156_20_cursor.path()[(v156_20_origin + 2)..(v156_20_origin + 3)]);
              let v163_11: Space = routine_23(c, &(v163_6), &v156_20_cursor);
              drop(v163_6);
              compose(&(v161_10),&(v163_11))
            };
            drop(v161_10);
            let v161_13: Space = unite(&(v161_8),&(v161_12));
            join_wrapped_into(&mut v160_7_write,&((v161_13).read_zipper()),&[]);
            }
            v156_20_cursor.ascend(1);
          }
          drop(v160_7_write);
          compose(&(v159_5),&(v160_7))
        };
        drop(v159_5);
        let v159_9: Space = intersect(&(*CONSTANT_1),&(v159_2));
        drop(v159_2);
        let v159_10: Space = if has_head(&(v159_9)) { singleton(&[]) } else { Space::new() };
        drop(v159_9);
        let v159_12: Space = if (&(v159_10)).is_empty() { Space::new() } else {
          let v164_6: Path = concat_path(&(v158_6),&v156_20_cursor.path()[(v156_20_origin + 1)..(v156_20_origin + 2)]);
          let mut v164_11 = Space::new();
          let mut v164_11_write = v164_11.write_zipper();
          for v164_11_byte in v156_20_cursor.child_mask().iter() {
            v156_20_cursor.descend_to_existing_byte(v164_11_byte);
            {
            let v165_2: Space = singleton(&v156_20_cursor.path()[(v156_20_origin + 2)..(v156_20_origin + 3)]);
            let v165_3: Space = intersect(&(*CONSTANT_1),&(v165_2));
            let v165_4: Space = if has_head(&(v165_3)) { singleton(&[]) } else { Space::new() };
            drop(v165_3);
            let v165_5: Space = subtract(&(*CONSTANT_0),&(v165_4));
            drop(v165_4);
            let v165_8: Space = if (&(v165_5)).is_empty() { Space::new() } else {
              let v166_6: Path = concat_path(&(v164_6),&v156_20_cursor.path()[(v156_20_origin + 2)..(v156_20_origin + 3)]);
              let v166_7: Space = routine_22(c, &(v166_6), &v156_20_cursor);
              compose(&(v165_5),&(v166_7))
            };
            drop(v165_5);
            let v165_9: Space = intersect(&(*CONSTANT_1),&(v165_2));
            drop(v165_2);
            let v165_10: Space = if has_head(&(v165_9)) { singleton(&[]) } else { Space::new() };
            drop(v165_9);
            let v165_12: Space = if (&(v165_10)).is_empty() { Space::new() } else {
              let v167_6: Path = concat_path(&(v164_6),&v156_20_cursor.path()[(v156_20_origin + 2)..(v156_20_origin + 3)]);
              let v167_11: Space = routine_15(c, &(v167_6), &v156_20_cursor);
              drop(v167_6);
              compose(&(v165_10),&(v167_11))
            };
            drop(v165_10);
            let v165_13: Space = unite(&(v165_8),&(v165_12));
            join_wrapped_into(&mut v164_11_write,&((v165_13).read_zipper()),&[]);
            }
            v156_20_cursor.ascend(1);
          }
          drop(v164_11_write);
          drop(v164_6);
          compose(&(v159_10),&(v164_11))
        };
        drop(v159_10);
        let v159_13: Space = unite(&(v159_8),&(v159_12));
        join_wrapped_into(&mut v158_7_write,&((v159_13).read_zipper()),&[]);
        }
        v156_20_cursor.ascend(1);
      }
      drop(v158_7_write);
      compose(&(v157_5),&(v158_7))
    };
    drop(v157_5);
    let v157_9: Space = intersect(&(*CONSTANT_1),&(v157_2));
    drop(v157_2);
    let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
    drop(v157_9);
    let v157_12: Space = if (&(v157_10)).is_empty() { Space::new() } else {
      let v168_6: Path = concat_path(&(*p0),&v156_20_cursor.path()[v156_20_origin..(v156_20_origin + 1)]);
      let mut v168_11 = Space::new();
      let mut v168_11_write = v168_11.write_zipper();
      for v168_11_byte in v156_20_cursor.child_mask().iter() {
        v156_20_cursor.descend_to_existing_byte(v168_11_byte);
        {
        let v169_2: Space = singleton(&v156_20_cursor.path()[(v156_20_origin + 1)..(v156_20_origin + 2)]);
        let v169_3: Space = intersect(&(*CONSTANT_1),&(v169_2));
        let v169_4: Space = if has_head(&(v169_3)) { singleton(&[]) } else { Space::new() };
        drop(v169_3);
        let v169_5: Space = subtract(&(*CONSTANT_0),&(v169_4));
        drop(v169_4);
        let v169_8: Space = if (&(v169_5)).is_empty() { Space::new() } else {
          let v170_6: Path = concat_path(&(v168_6),&v156_20_cursor.path()[(v156_20_origin + 1)..(v156_20_origin + 2)]);
          let mut v170_7 = Space::new();
          let mut v170_7_write = v170_7.write_zipper();
          for v170_7_byte in v156_20_cursor.child_mask().iter() {
            v156_20_cursor.descend_to_existing_byte(v170_7_byte);
            {
            let v171_2: Space = singleton(&v156_20_cursor.path()[(v156_20_origin + 2)..(v156_20_origin + 3)]);
            let v171_3: Space = intersect(&(*CONSTANT_1),&(v171_2));
            let v171_4: Space = if has_head(&(v171_3)) { singleton(&[]) } else { Space::new() };
            drop(v171_3);
            let v171_5: Space = subtract(&(*CONSTANT_0),&(v171_4));
            drop(v171_4);
            let v171_8: Space = if (&(v171_5)).is_empty() { Space::new() } else {
              let v172_6: Path = concat_path(&(v170_6),&v156_20_cursor.path()[(v156_20_origin + 2)..(v156_20_origin + 3)]);
              let v172_7: Space = routine_22(c, &(v172_6), &v156_20_cursor);
              compose(&(v171_5),&(v172_7))
            };
            drop(v171_5);
            let v171_9: Space = intersect(&(*CONSTANT_1),&(v171_2));
            drop(v171_2);
            let v171_10: Space = if has_head(&(v171_9)) { singleton(&[]) } else { Space::new() };
            drop(v171_9);
            let v171_12: Space = if (&(v171_10)).is_empty() { Space::new() } else {
              let v173_6: Path = concat_path(&(v170_6),&v156_20_cursor.path()[(v156_20_origin + 2)..(v156_20_origin + 3)]);
              let v173_11: Space = routine_23(c, &(v173_6), &v156_20_cursor);
              drop(v173_6);
              compose(&(v171_10),&(v173_11))
            };
            drop(v171_10);
            let v171_13: Space = unite(&(v171_8),&(v171_12));
            join_wrapped_into(&mut v170_7_write,&((v171_13).read_zipper()),&[]);
            }
            v156_20_cursor.ascend(1);
          }
          drop(v170_7_write);
          drop(v170_6);
          compose(&(v169_5),&(v170_7))
        };
        drop(v169_5);
        let v169_9: Space = intersect(&(*CONSTANT_1),&(v169_2));
        drop(v169_2);
        let v169_10: Space = if has_head(&(v169_9)) { singleton(&[]) } else { Space::new() };
        drop(v169_9);
        let v169_11: Space = compose(&(v169_10),&v156_20_cursor);
        drop(v169_10);
        let v169_12: Space = unite(&(v169_8),&(v169_11));
        drop(v169_11);
        join_wrapped_into(&mut v168_11_write,&((v169_12).read_zipper()),&[]);
        }
        v156_20_cursor.ascend(1);
      }
      drop(v168_11_write);
      drop(v168_6);
      compose(&(v157_10),&(v168_11))
    };
    drop(v157_10);
    let v157_13: Space = unite(&(v157_8),&(v157_12));
    join_wrapped_into(&mut v156_20_write,&((v157_13).read_zipper()),&[]);
    }
    v156_20_cursor.ascend(1);
  }
  drop(v156_20_cursor);
  drop(v156_20_write);
  (v156_20).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v174_14 = Space::new();
  let mut v174_14_write = v174_14.write_zipper();
  let mut v174_14_cursor = (*s0).read_zipper();
  let v174_14_origin = v174_14_cursor.path().len();
  for v174_14_byte in v174_14_cursor.child_mask().iter() {
    v174_14_cursor.descend_to_existing_byte(v174_14_byte);
    {
    let v175_2: Space = singleton(&v174_14_cursor.path()[v174_14_origin..(v174_14_origin + 1)]);
    let v175_3: Space = intersect(&(*CONSTANT_1),&(v175_2));
    let v175_4: Space = if has_head(&(v175_3)) { singleton(&[]) } else { Space::new() };
    drop(v175_3);
    let v175_5: Space = subtract(&(*CONSTANT_0),&(v175_4));
    drop(v175_4);
    let v175_8: Space = if (&(v175_5)).is_empty() { Space::new() } else {
      let v176_6: Path = concat_path(&(*p0),&v174_14_cursor.path()[v174_14_origin..(v174_14_origin + 1)]);
      let mut v176_7 = Space::new();
      let mut v176_7_write = v176_7.write_zipper();
      for v176_7_byte in v174_14_cursor.child_mask().iter() {
        v174_14_cursor.descend_to_existing_byte(v176_7_byte);
        {
        let v177_2: Space = singleton(&v174_14_cursor.path()[(v174_14_origin + 1)..(v174_14_origin + 2)]);
        let v177_3: Space = intersect(&(*CONSTANT_1),&(v177_2));
        let v177_4: Space = if has_head(&(v177_3)) { singleton(&[]) } else { Space::new() };
        drop(v177_3);
        let v177_5: Space = subtract(&(*CONSTANT_0),&(v177_4));
        drop(v177_4);
        let v177_8: Space = if (&(v177_5)).is_empty() { Space::new() } else {
          let v178_6: Path = concat_path(&(v176_6),&v174_14_cursor.path()[(v174_14_origin + 1)..(v174_14_origin + 2)]);
          let mut v178_7 = Space::new();
          let mut v178_7_write = v178_7.write_zipper();
          for v178_7_byte in v174_14_cursor.child_mask().iter() {
            v174_14_cursor.descend_to_existing_byte(v178_7_byte);
            {
            let v179_2: Space = singleton(&v174_14_cursor.path()[(v174_14_origin + 2)..(v174_14_origin + 3)]);
            let v179_3: Space = intersect(&(*CONSTANT_1),&(v179_2));
            let v179_4: Space = if has_head(&(v179_3)) { singleton(&[]) } else { Space::new() };
            drop(v179_3);
            let v179_5: Space = subtract(&(*CONSTANT_0),&(v179_4));
            drop(v179_4);
            let v179_8: Space = if (&(v179_5)).is_empty() { Space::new() } else {
              let v180_6: Path = concat_path(&(v178_6),&v174_14_cursor.path()[(v174_14_origin + 2)..(v174_14_origin + 3)]);
              let v180_7: Space = routine_22(c, &(v180_6), &v174_14_cursor);
              compose(&(v179_5),&(v180_7))
            };
            drop(v179_5);
            let v179_9: Space = intersect(&(*CONSTANT_1),&(v179_2));
            drop(v179_2);
            let v179_10: Space = if has_head(&(v179_9)) { singleton(&[]) } else { Space::new() };
            drop(v179_9);
            let v179_12: Space = if (&(v179_10)).is_empty() { Space::new() } else {
              let v181_6: Path = concat_path(&(v178_6),&v174_14_cursor.path()[(v174_14_origin + 2)..(v174_14_origin + 3)]);
              let v181_11: Space = routine_23(c, &(v181_6), &v174_14_cursor);
              drop(v181_6);
              compose(&(v179_10),&(v181_11))
            };
            drop(v179_10);
            let v179_13: Space = unite(&(v179_8),&(v179_12));
            join_wrapped_into(&mut v178_7_write,&((v179_13).read_zipper()),&[]);
            }
            v174_14_cursor.ascend(1);
          }
          drop(v178_7_write);
          compose(&(v177_5),&(v178_7))
        };
        drop(v177_5);
        let v177_9: Space = intersect(&(*CONSTANT_1),&(v177_2));
        drop(v177_2);
        let v177_10: Space = if has_head(&(v177_9)) { singleton(&[]) } else { Space::new() };
        drop(v177_9);
        let v177_12: Space = if (&(v177_10)).is_empty() { Space::new() } else {
          let v182_6: Path = concat_path(&(v176_6),&v174_14_cursor.path()[(v174_14_origin + 1)..(v174_14_origin + 2)]);
          let mut v182_11 = Space::new();
          let mut v182_11_write = v182_11.write_zipper();
          for v182_11_byte in v174_14_cursor.child_mask().iter() {
            v174_14_cursor.descend_to_existing_byte(v182_11_byte);
            {
            let v183_2: Space = singleton(&v174_14_cursor.path()[(v174_14_origin + 2)..(v174_14_origin + 3)]);
            let v183_3: Space = intersect(&(*CONSTANT_1),&(v183_2));
            let v183_4: Space = if has_head(&(v183_3)) { singleton(&[]) } else { Space::new() };
            drop(v183_3);
            let v183_5: Space = subtract(&(*CONSTANT_0),&(v183_4));
            drop(v183_4);
            let v183_8: Space = if (&(v183_5)).is_empty() { Space::new() } else {
              let v184_6: Path = concat_path(&(v182_6),&v174_14_cursor.path()[(v174_14_origin + 2)..(v174_14_origin + 3)]);
              let v184_7: Space = routine_22(c, &(v184_6), &v174_14_cursor);
              compose(&(v183_5),&(v184_7))
            };
            drop(v183_5);
            let v183_9: Space = intersect(&(*CONSTANT_1),&(v183_2));
            drop(v183_2);
            let v183_10: Space = if has_head(&(v183_9)) { singleton(&[]) } else { Space::new() };
            drop(v183_9);
            let v183_12: Space = if (&(v183_10)).is_empty() { Space::new() } else {
              let v185_6: Path = concat_path(&(v182_6),&v174_14_cursor.path()[(v174_14_origin + 2)..(v174_14_origin + 3)]);
              let v185_11: Space = routine_15(c, &(v185_6), &v174_14_cursor);
              drop(v185_6);
              compose(&(v183_10),&(v185_11))
            };
            drop(v183_10);
            let v183_13: Space = unite(&(v183_8),&(v183_12));
            join_wrapped_into(&mut v182_11_write,&((v183_13).read_zipper()),&[]);
            }
            v174_14_cursor.ascend(1);
          }
          drop(v182_11_write);
          drop(v182_6);
          compose(&(v177_10),&(v182_11))
        };
        drop(v177_10);
        let v177_13: Space = unite(&(v177_8),&(v177_12));
        join_wrapped_into(&mut v176_7_write,&((v177_13).read_zipper()),&[]);
        }
        v174_14_cursor.ascend(1);
      }
      drop(v176_7_write);
      drop(v176_6);
      compose(&(v175_5),&(v176_7))
    };
    drop(v175_5);
    let v175_9: Space = intersect(&(*CONSTANT_1),&(v175_2));
    drop(v175_2);
    let v175_10: Space = if has_head(&(v175_9)) { singleton(&[]) } else { Space::new() };
    drop(v175_9);
    let v175_11: Space = compose(&(v175_10),&v174_14_cursor);
    drop(v175_10);
    let v175_12: Space = unite(&(v175_8),&(v175_11));
    drop(v175_11);
    join_wrapped_into(&mut v174_14_write,&((v175_12).read_zipper()),&[]);
    }
    v174_14_cursor.ascend(1);
  }
  drop(v174_14_cursor);
  drop(v174_14_write);
  (v174_14).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v186_20 = Space::new();
  let mut v186_20_write = v186_20.write_zipper();
  let mut v186_20_cursor = (*s0).read_zipper();
  let v186_20_origin = v186_20_cursor.path().len();
  for v186_20_byte in v186_20_cursor.child_mask().iter() {
    v186_20_cursor.descend_to_existing_byte(v186_20_byte);
    {
    let v187_2: Space = singleton(&v186_20_cursor.path()[v186_20_origin..(v186_20_origin + 1)]);
    let v187_3: Space = intersect(&(*CONSTANT_1),&(v187_2));
    let v187_4: Space = if has_head(&(v187_3)) { singleton(&[]) } else { Space::new() };
    drop(v187_3);
    let v187_5: Space = subtract(&(*CONSTANT_0),&(v187_4));
    drop(v187_4);
    let v187_8: Space = if (&(v187_5)).is_empty() { Space::new() } else {
      let v188_6: Path = concat_path(&(*p0),&v186_20_cursor.path()[v186_20_origin..(v186_20_origin + 1)]);
      let mut v188_7 = Space::new();
      let mut v188_7_write = v188_7.write_zipper();
      for v188_7_byte in v186_20_cursor.child_mask().iter() {
        v186_20_cursor.descend_to_existing_byte(v188_7_byte);
        {
        let v189_2: Space = singleton(&v186_20_cursor.path()[(v186_20_origin + 1)..(v186_20_origin + 2)]);
        let v189_3: Space = intersect(&(*CONSTANT_1),&(v189_2));
        let v189_4: Space = if has_head(&(v189_3)) { singleton(&[]) } else { Space::new() };
        drop(v189_3);
        let v189_5: Space = subtract(&(*CONSTANT_0),&(v189_4));
        drop(v189_4);
        let v189_8: Space = if (&(v189_5)).is_empty() { Space::new() } else {
          let v190_6: Path = concat_path(&(v188_6),&v186_20_cursor.path()[(v186_20_origin + 1)..(v186_20_origin + 2)]);
          let mut v190_7 = Space::new();
          let mut v190_7_write = v190_7.write_zipper();
          for v190_7_byte in v186_20_cursor.child_mask().iter() {
            v186_20_cursor.descend_to_existing_byte(v190_7_byte);
            {
            let v191_2: Space = singleton(&v186_20_cursor.path()[(v186_20_origin + 2)..(v186_20_origin + 3)]);
            let v191_3: Space = intersect(&(*CONSTANT_1),&(v191_2));
            let v191_4: Space = if has_head(&(v191_3)) { singleton(&[]) } else { Space::new() };
            drop(v191_3);
            let v191_5: Space = subtract(&(*CONSTANT_0),&(v191_4));
            drop(v191_4);
            let v191_8: Space = if (&(v191_5)).is_empty() { Space::new() } else {
              let v192_6: Path = concat_path(&(v190_6),&v186_20_cursor.path()[(v186_20_origin + 2)..(v186_20_origin + 3)]);
              let v192_7: Space = routine_24(c, &(v192_6), &v186_20_cursor);
              compose(&(v191_5),&(v192_7))
            };
            drop(v191_5);
            let v191_9: Space = intersect(&(*CONSTANT_1),&(v191_2));
            drop(v191_2);
            let v191_10: Space = if has_head(&(v191_9)) { singleton(&[]) } else { Space::new() };
            drop(v191_9);
            let v191_12: Space = if (&(v191_10)).is_empty() { Space::new() } else {
              let v193_6: Path = concat_path(&(v190_6),&v186_20_cursor.path()[(v186_20_origin + 2)..(v186_20_origin + 3)]);
              let v193_11: Space = routine_25(c, &(v193_6), &v186_20_cursor);
              drop(v193_6);
              compose(&(v191_10),&(v193_11))
            };
            drop(v191_10);
            let v191_13: Space = unite(&(v191_8),&(v191_12));
            join_wrapped_into(&mut v190_7_write,&((v191_13).read_zipper()),&[]);
            }
            v186_20_cursor.ascend(1);
          }
          drop(v190_7_write);
          compose(&(v189_5),&(v190_7))
        };
        drop(v189_5);
        let v189_9: Space = intersect(&(*CONSTANT_1),&(v189_2));
        drop(v189_2);
        let v189_10: Space = if has_head(&(v189_9)) { singleton(&[]) } else { Space::new() };
        drop(v189_9);
        let v189_12: Space = if (&(v189_10)).is_empty() { Space::new() } else {
          let v194_6: Path = concat_path(&(v188_6),&v186_20_cursor.path()[(v186_20_origin + 1)..(v186_20_origin + 2)]);
          let mut v194_11 = Space::new();
          let mut v194_11_write = v194_11.write_zipper();
          for v194_11_byte in v186_20_cursor.child_mask().iter() {
            v186_20_cursor.descend_to_existing_byte(v194_11_byte);
            {
            let v195_2: Space = singleton(&v186_20_cursor.path()[(v186_20_origin + 2)..(v186_20_origin + 3)]);
            let v195_3: Space = intersect(&(*CONSTANT_1),&(v195_2));
            let v195_4: Space = if has_head(&(v195_3)) { singleton(&[]) } else { Space::new() };
            drop(v195_3);
            let v195_5: Space = subtract(&(*CONSTANT_0),&(v195_4));
            drop(v195_4);
            let v195_8: Space = if (&(v195_5)).is_empty() { Space::new() } else {
              let v196_6: Path = concat_path(&(v194_6),&v186_20_cursor.path()[(v186_20_origin + 2)..(v186_20_origin + 3)]);
              let v196_7: Space = routine_24(c, &(v196_6), &v186_20_cursor);
              compose(&(v195_5),&(v196_7))
            };
            drop(v195_5);
            let v195_9: Space = intersect(&(*CONSTANT_1),&(v195_2));
            drop(v195_2);
            let v195_10: Space = if has_head(&(v195_9)) { singleton(&[]) } else { Space::new() };
            drop(v195_9);
            let v195_12: Space = if (&(v195_10)).is_empty() { Space::new() } else {
              let v197_6: Path = concat_path(&(v194_6),&v186_20_cursor.path()[(v186_20_origin + 2)..(v186_20_origin + 3)]);
              let v197_11: Space = routine_12(c, &(v197_6), &v186_20_cursor);
              drop(v197_6);
              compose(&(v195_10),&(v197_11))
            };
            drop(v195_10);
            let v195_13: Space = unite(&(v195_8),&(v195_12));
            join_wrapped_into(&mut v194_11_write,&((v195_13).read_zipper()),&[]);
            }
            v186_20_cursor.ascend(1);
          }
          drop(v194_11_write);
          drop(v194_6);
          compose(&(v189_10),&(v194_11))
        };
        drop(v189_10);
        let v189_13: Space = unite(&(v189_8),&(v189_12));
        join_wrapped_into(&mut v188_7_write,&((v189_13).read_zipper()),&[]);
        }
        v186_20_cursor.ascend(1);
      }
      drop(v188_7_write);
      compose(&(v187_5),&(v188_7))
    };
    drop(v187_5);
    let v187_9: Space = intersect(&(*CONSTANT_1),&(v187_2));
    drop(v187_2);
    let v187_10: Space = if has_head(&(v187_9)) { singleton(&[]) } else { Space::new() };
    drop(v187_9);
    let v187_12: Space = if (&(v187_10)).is_empty() { Space::new() } else {
      let v198_6: Path = concat_path(&(*p0),&v186_20_cursor.path()[v186_20_origin..(v186_20_origin + 1)]);
      let mut v198_11 = Space::new();
      let mut v198_11_write = v198_11.write_zipper();
      for v198_11_byte in v186_20_cursor.child_mask().iter() {
        v186_20_cursor.descend_to_existing_byte(v198_11_byte);
        {
        let v199_2: Space = singleton(&v186_20_cursor.path()[(v186_20_origin + 1)..(v186_20_origin + 2)]);
        let v199_3: Space = intersect(&(*CONSTANT_1),&(v199_2));
        let v199_4: Space = if has_head(&(v199_3)) { singleton(&[]) } else { Space::new() };
        drop(v199_3);
        let v199_5: Space = subtract(&(*CONSTANT_0),&(v199_4));
        drop(v199_4);
        let v199_8: Space = if (&(v199_5)).is_empty() { Space::new() } else {
          let v200_6: Path = concat_path(&(v198_6),&v186_20_cursor.path()[(v186_20_origin + 1)..(v186_20_origin + 2)]);
          let mut v200_7 = Space::new();
          let mut v200_7_write = v200_7.write_zipper();
          for v200_7_byte in v186_20_cursor.child_mask().iter() {
            v186_20_cursor.descend_to_existing_byte(v200_7_byte);
            {
            let v201_2: Space = singleton(&v186_20_cursor.path()[(v186_20_origin + 2)..(v186_20_origin + 3)]);
            let v201_3: Space = intersect(&(*CONSTANT_1),&(v201_2));
            let v201_4: Space = if has_head(&(v201_3)) { singleton(&[]) } else { Space::new() };
            drop(v201_3);
            let v201_5: Space = subtract(&(*CONSTANT_0),&(v201_4));
            drop(v201_4);
            let v201_8: Space = if (&(v201_5)).is_empty() { Space::new() } else {
              let v202_6: Path = concat_path(&(v200_6),&v186_20_cursor.path()[(v186_20_origin + 2)..(v186_20_origin + 3)]);
              let v202_7: Space = routine_24(c, &(v202_6), &v186_20_cursor);
              compose(&(v201_5),&(v202_7))
            };
            drop(v201_5);
            let v201_9: Space = intersect(&(*CONSTANT_1),&(v201_2));
            drop(v201_2);
            let v201_10: Space = if has_head(&(v201_9)) { singleton(&[]) } else { Space::new() };
            drop(v201_9);
            let v201_12: Space = if (&(v201_10)).is_empty() { Space::new() } else {
              let v203_6: Path = concat_path(&(v200_6),&v186_20_cursor.path()[(v186_20_origin + 2)..(v186_20_origin + 3)]);
              let v203_11: Space = routine_25(c, &(v203_6), &v186_20_cursor);
              drop(v203_6);
              compose(&(v201_10),&(v203_11))
            };
            drop(v201_10);
            let v201_13: Space = unite(&(v201_8),&(v201_12));
            join_wrapped_into(&mut v200_7_write,&((v201_13).read_zipper()),&[]);
            }
            v186_20_cursor.ascend(1);
          }
          drop(v200_7_write);
          drop(v200_6);
          compose(&(v199_5),&(v200_7))
        };
        drop(v199_5);
        let v199_9: Space = intersect(&(*CONSTANT_1),&(v199_2));
        drop(v199_2);
        let v199_10: Space = if has_head(&(v199_9)) { singleton(&[]) } else { Space::new() };
        drop(v199_9);
        let v199_11: Space = compose(&(v199_10),&v186_20_cursor);
        drop(v199_10);
        let v199_12: Space = unite(&(v199_8),&(v199_11));
        drop(v199_11);
        join_wrapped_into(&mut v198_11_write,&((v199_12).read_zipper()),&[]);
        }
        v186_20_cursor.ascend(1);
      }
      drop(v198_11_write);
      drop(v198_6);
      compose(&(v187_10),&(v198_11))
    };
    drop(v187_10);
    let v187_13: Space = unite(&(v187_8),&(v187_12));
    join_wrapped_into(&mut v186_20_write,&((v187_13).read_zipper()),&[]);
    }
    v186_20_cursor.ascend(1);
  }
  drop(v186_20_cursor);
  drop(v186_20_write);
  (v186_20).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v204_14 = Space::new();
  let mut v204_14_write = v204_14.write_zipper();
  let mut v204_14_cursor = (*s0).read_zipper();
  let v204_14_origin = v204_14_cursor.path().len();
  for v204_14_byte in v204_14_cursor.child_mask().iter() {
    v204_14_cursor.descend_to_existing_byte(v204_14_byte);
    {
    let v205_2: Space = singleton(&v204_14_cursor.path()[v204_14_origin..(v204_14_origin + 1)]);
    let v205_3: Space = intersect(&(*CONSTANT_1),&(v205_2));
    let v205_4: Space = if has_head(&(v205_3)) { singleton(&[]) } else { Space::new() };
    drop(v205_3);
    let v205_5: Space = subtract(&(*CONSTANT_0),&(v205_4));
    drop(v205_4);
    let v205_8: Space = if (&(v205_5)).is_empty() { Space::new() } else {
      let v206_6: Path = concat_path(&(*p0),&v204_14_cursor.path()[v204_14_origin..(v204_14_origin + 1)]);
      let mut v206_7 = Space::new();
      let mut v206_7_write = v206_7.write_zipper();
      for v206_7_byte in v204_14_cursor.child_mask().iter() {
        v204_14_cursor.descend_to_existing_byte(v206_7_byte);
        {
        let v207_2: Space = singleton(&v204_14_cursor.path()[(v204_14_origin + 1)..(v204_14_origin + 2)]);
        let v207_3: Space = intersect(&(*CONSTANT_1),&(v207_2));
        let v207_4: Space = if has_head(&(v207_3)) { singleton(&[]) } else { Space::new() };
        drop(v207_3);
        let v207_5: Space = subtract(&(*CONSTANT_0),&(v207_4));
        drop(v207_4);
        let v207_8: Space = if (&(v207_5)).is_empty() { Space::new() } else {
          let v208_6: Path = concat_path(&(v206_6),&v204_14_cursor.path()[(v204_14_origin + 1)..(v204_14_origin + 2)]);
          let mut v208_7 = Space::new();
          let mut v208_7_write = v208_7.write_zipper();
          for v208_7_byte in v204_14_cursor.child_mask().iter() {
            v204_14_cursor.descend_to_existing_byte(v208_7_byte);
            {
            let v209_2: Space = singleton(&v204_14_cursor.path()[(v204_14_origin + 2)..(v204_14_origin + 3)]);
            let v209_3: Space = intersect(&(*CONSTANT_1),&(v209_2));
            let v209_4: Space = if has_head(&(v209_3)) { singleton(&[]) } else { Space::new() };
            drop(v209_3);
            let v209_5: Space = subtract(&(*CONSTANT_0),&(v209_4));
            drop(v209_4);
            let v209_8: Space = if (&(v209_5)).is_empty() { Space::new() } else {
              let v210_6: Path = concat_path(&(v208_6),&v204_14_cursor.path()[(v204_14_origin + 2)..(v204_14_origin + 3)]);
              let v210_7: Space = routine_24(c, &(v210_6), &v204_14_cursor);
              compose(&(v209_5),&(v210_7))
            };
            drop(v209_5);
            let v209_9: Space = intersect(&(*CONSTANT_1),&(v209_2));
            drop(v209_2);
            let v209_10: Space = if has_head(&(v209_9)) { singleton(&[]) } else { Space::new() };
            drop(v209_9);
            let v209_12: Space = if (&(v209_10)).is_empty() { Space::new() } else {
              let v211_6: Path = concat_path(&(v208_6),&v204_14_cursor.path()[(v204_14_origin + 2)..(v204_14_origin + 3)]);
              let v211_11: Space = routine_25(c, &(v211_6), &v204_14_cursor);
              drop(v211_6);
              compose(&(v209_10),&(v211_11))
            };
            drop(v209_10);
            let v209_13: Space = unite(&(v209_8),&(v209_12));
            join_wrapped_into(&mut v208_7_write,&((v209_13).read_zipper()),&[]);
            }
            v204_14_cursor.ascend(1);
          }
          drop(v208_7_write);
          compose(&(v207_5),&(v208_7))
        };
        drop(v207_5);
        let v207_9: Space = intersect(&(*CONSTANT_1),&(v207_2));
        drop(v207_2);
        let v207_10: Space = if has_head(&(v207_9)) { singleton(&[]) } else { Space::new() };
        drop(v207_9);
        let v207_12: Space = if (&(v207_10)).is_empty() { Space::new() } else {
          let v212_6: Path = concat_path(&(v206_6),&v204_14_cursor.path()[(v204_14_origin + 1)..(v204_14_origin + 2)]);
          let mut v212_11 = Space::new();
          let mut v212_11_write = v212_11.write_zipper();
          for v212_11_byte in v204_14_cursor.child_mask().iter() {
            v204_14_cursor.descend_to_existing_byte(v212_11_byte);
            {
            let v213_2: Space = singleton(&v204_14_cursor.path()[(v204_14_origin + 2)..(v204_14_origin + 3)]);
            let v213_3: Space = intersect(&(*CONSTANT_1),&(v213_2));
            let v213_4: Space = if has_head(&(v213_3)) { singleton(&[]) } else { Space::new() };
            drop(v213_3);
            let v213_5: Space = subtract(&(*CONSTANT_0),&(v213_4));
            drop(v213_4);
            let v213_8: Space = if (&(v213_5)).is_empty() { Space::new() } else {
              let v214_6: Path = concat_path(&(v212_6),&v204_14_cursor.path()[(v204_14_origin + 2)..(v204_14_origin + 3)]);
              let v214_7: Space = routine_24(c, &(v214_6), &v204_14_cursor);
              compose(&(v213_5),&(v214_7))
            };
            drop(v213_5);
            let v213_9: Space = intersect(&(*CONSTANT_1),&(v213_2));
            drop(v213_2);
            let v213_10: Space = if has_head(&(v213_9)) { singleton(&[]) } else { Space::new() };
            drop(v213_9);
            let v213_12: Space = if (&(v213_10)).is_empty() { Space::new() } else {
              let v215_6: Path = concat_path(&(v212_6),&v204_14_cursor.path()[(v204_14_origin + 2)..(v204_14_origin + 3)]);
              let v215_11: Space = routine_12(c, &(v215_6), &v204_14_cursor);
              drop(v215_6);
              compose(&(v213_10),&(v215_11))
            };
            drop(v213_10);
            let v213_13: Space = unite(&(v213_8),&(v213_12));
            join_wrapped_into(&mut v212_11_write,&((v213_13).read_zipper()),&[]);
            }
            v204_14_cursor.ascend(1);
          }
          drop(v212_11_write);
          drop(v212_6);
          compose(&(v207_10),&(v212_11))
        };
        drop(v207_10);
        let v207_13: Space = unite(&(v207_8),&(v207_12));
        join_wrapped_into(&mut v206_7_write,&((v207_13).read_zipper()),&[]);
        }
        v204_14_cursor.ascend(1);
      }
      drop(v206_7_write);
      drop(v206_6);
      compose(&(v205_5),&(v206_7))
    };
    drop(v205_5);
    let v205_9: Space = intersect(&(*CONSTANT_1),&(v205_2));
    drop(v205_2);
    let v205_10: Space = if has_head(&(v205_9)) { singleton(&[]) } else { Space::new() };
    drop(v205_9);
    let v205_11: Space = compose(&(v205_10),&v204_14_cursor);
    drop(v205_10);
    let v205_12: Space = unite(&(v205_8),&(v205_11));
    drop(v205_11);
    join_wrapped_into(&mut v204_14_write,&((v205_12).read_zipper()),&[]);
    }
    v204_14_cursor.ascend(1);
  }
  drop(v204_14_cursor);
  drop(v204_14_write);
  (v204_14).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v217_20 = Space::new();
  let mut v217_20_write = v217_20.write_zipper();
  let mut v217_20_cursor = (*s0).read_zipper();
  let v217_20_origin = v217_20_cursor.path().len();
  for v217_20_byte in v217_20_cursor.child_mask().iter() {
    v217_20_cursor.descend_to_existing_byte(v217_20_byte);
    {
    let v218_2: Space = singleton(&v217_20_cursor.path()[v217_20_origin..(v217_20_origin + 1)]);
    let v218_3: Space = intersect(&(*CONSTANT_1),&(v218_2));
    let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
    drop(v218_3);
    let v218_5: Space = subtract(&(*CONSTANT_0),&(v218_4));
    drop(v218_4);
    let v218_8: Space = if (&(v218_5)).is_empty() { Space::new() } else {
      let v219_6: Path = concat_path(&(*p0),&v217_20_cursor.path()[v217_20_origin..(v217_20_origin + 1)]);
      let mut v219_7 = Space::new();
      let mut v219_7_write = v219_7.write_zipper();
      for v219_7_byte in v217_20_cursor.child_mask().iter() {
        v217_20_cursor.descend_to_existing_byte(v219_7_byte);
        {
        let v220_2: Space = singleton(&v217_20_cursor.path()[(v217_20_origin + 1)..(v217_20_origin + 2)]);
        let v220_3: Space = intersect(&(*CONSTANT_1),&(v220_2));
        let v220_4: Space = if has_head(&(v220_3)) { singleton(&[]) } else { Space::new() };
        drop(v220_3);
        let v220_5: Space = subtract(&(*CONSTANT_0),&(v220_4));
        drop(v220_4);
        let v220_8: Space = if (&(v220_5)).is_empty() { Space::new() } else {
          let v221_6: Path = concat_path(&(v219_6),&v217_20_cursor.path()[(v217_20_origin + 1)..(v217_20_origin + 2)]);
          let mut v221_7 = Space::new();
          let mut v221_7_write = v221_7.write_zipper();
          for v221_7_byte in v217_20_cursor.child_mask().iter() {
            v217_20_cursor.descend_to_existing_byte(v221_7_byte);
            {
            let v222_2: Space = singleton(&v217_20_cursor.path()[(v217_20_origin + 2)..(v217_20_origin + 3)]);
            let v222_3: Space = intersect(&(*CONSTANT_1),&(v222_2));
            let v222_4: Space = if has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
            drop(v222_3);
            let v222_5: Space = subtract(&(*CONSTANT_0),&(v222_4));
            drop(v222_4);
            let v222_8: Space = if (&(v222_5)).is_empty() { Space::new() } else {
              let v223_6: Path = concat_path(&(v221_6),&v217_20_cursor.path()[(v217_20_origin + 2)..(v217_20_origin + 3)]);
              let v223_7: Space = routine_26(c, &(v223_6), &v217_20_cursor);
              compose(&(v222_5),&(v223_7))
            };
            drop(v222_5);
            let v222_9: Space = intersect(&(*CONSTANT_1),&(v222_2));
            drop(v222_2);
            let v222_10: Space = if has_head(&(v222_9)) { singleton(&[]) } else { Space::new() };
            drop(v222_9);
            let v222_12: Space = if (&(v222_10)).is_empty() { Space::new() } else {
              let v224_6: Path = concat_path(&(v221_6),&v217_20_cursor.path()[(v217_20_origin + 2)..(v217_20_origin + 3)]);
              let v224_11: Space = routine_27(c, &(v224_6), &v217_20_cursor);
              drop(v224_6);
              compose(&(v222_10),&(v224_11))
            };
            drop(v222_10);
            let v222_13: Space = unite(&(v222_8),&(v222_12));
            join_wrapped_into(&mut v221_7_write,&((v222_13).read_zipper()),&[]);
            }
            v217_20_cursor.ascend(1);
          }
          drop(v221_7_write);
          compose(&(v220_5),&(v221_7))
        };
        drop(v220_5);
        let v220_9: Space = intersect(&(*CONSTANT_1),&(v220_2));
        drop(v220_2);
        let v220_10: Space = if has_head(&(v220_9)) { singleton(&[]) } else { Space::new() };
        drop(v220_9);
        let v220_12: Space = if (&(v220_10)).is_empty() { Space::new() } else {
          let v225_6: Path = concat_path(&(v219_6),&v217_20_cursor.path()[(v217_20_origin + 1)..(v217_20_origin + 2)]);
          let mut v225_11 = Space::new();
          let mut v225_11_write = v225_11.write_zipper();
          for v225_11_byte in v217_20_cursor.child_mask().iter() {
            v217_20_cursor.descend_to_existing_byte(v225_11_byte);
            {
            let v226_2: Space = singleton(&v217_20_cursor.path()[(v217_20_origin + 2)..(v217_20_origin + 3)]);
            let v226_3: Space = intersect(&(*CONSTANT_1),&(v226_2));
            let v226_4: Space = if has_head(&(v226_3)) { singleton(&[]) } else { Space::new() };
            drop(v226_3);
            let v226_5: Space = subtract(&(*CONSTANT_0),&(v226_4));
            drop(v226_4);
            let v226_8: Space = if (&(v226_5)).is_empty() { Space::new() } else {
              let v227_6: Path = concat_path(&(v225_6),&v217_20_cursor.path()[(v217_20_origin + 2)..(v217_20_origin + 3)]);
              let v227_7: Space = routine_26(c, &(v227_6), &v217_20_cursor);
              compose(&(v226_5),&(v227_7))
            };
            drop(v226_5);
            let v226_9: Space = intersect(&(*CONSTANT_1),&(v226_2));
            drop(v226_2);
            let v226_10: Space = if has_head(&(v226_9)) { singleton(&[]) } else { Space::new() };
            drop(v226_9);
            let v226_12: Space = if (&(v226_10)).is_empty() { Space::new() } else {
              let v228_6: Path = concat_path(&(v225_6),&v217_20_cursor.path()[(v217_20_origin + 2)..(v217_20_origin + 3)]);
              let v228_11: Space = routine_15(c, &(v228_6), &v217_20_cursor);
              drop(v228_6);
              compose(&(v226_10),&(v228_11))
            };
            drop(v226_10);
            let v226_13: Space = unite(&(v226_8),&(v226_12));
            join_wrapped_into(&mut v225_11_write,&((v226_13).read_zipper()),&[]);
            }
            v217_20_cursor.ascend(1);
          }
          drop(v225_11_write);
          drop(v225_6);
          compose(&(v220_10),&(v225_11))
        };
        drop(v220_10);
        let v220_13: Space = unite(&(v220_8),&(v220_12));
        join_wrapped_into(&mut v219_7_write,&((v220_13).read_zipper()),&[]);
        }
        v217_20_cursor.ascend(1);
      }
      drop(v219_7_write);
      compose(&(v218_5),&(v219_7))
    };
    drop(v218_5);
    let v218_9: Space = intersect(&(*CONSTANT_1),&(v218_2));
    drop(v218_2);
    let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
    drop(v218_9);
    let v218_12: Space = if (&(v218_10)).is_empty() { Space::new() } else {
      let v229_6: Path = concat_path(&(*p0),&v217_20_cursor.path()[v217_20_origin..(v217_20_origin + 1)]);
      let mut v229_11 = Space::new();
      let mut v229_11_write = v229_11.write_zipper();
      for v229_11_byte in v217_20_cursor.child_mask().iter() {
        v217_20_cursor.descend_to_existing_byte(v229_11_byte);
        {
        let v230_2: Space = singleton(&v217_20_cursor.path()[(v217_20_origin + 1)..(v217_20_origin + 2)]);
        let v230_3: Space = intersect(&(*CONSTANT_1),&(v230_2));
        let v230_4: Space = if has_head(&(v230_3)) { singleton(&[]) } else { Space::new() };
        drop(v230_3);
        let v230_5: Space = subtract(&(*CONSTANT_0),&(v230_4));
        drop(v230_4);
        let v230_8: Space = if (&(v230_5)).is_empty() { Space::new() } else {
          let v231_6: Path = concat_path(&(v229_6),&v217_20_cursor.path()[(v217_20_origin + 1)..(v217_20_origin + 2)]);
          let mut v231_7 = Space::new();
          let mut v231_7_write = v231_7.write_zipper();
          for v231_7_byte in v217_20_cursor.child_mask().iter() {
            v217_20_cursor.descend_to_existing_byte(v231_7_byte);
            {
            let v232_2: Space = singleton(&v217_20_cursor.path()[(v217_20_origin + 2)..(v217_20_origin + 3)]);
            let v232_3: Space = intersect(&(*CONSTANT_1),&(v232_2));
            let v232_4: Space = if has_head(&(v232_3)) { singleton(&[]) } else { Space::new() };
            drop(v232_3);
            let v232_5: Space = subtract(&(*CONSTANT_0),&(v232_4));
            drop(v232_4);
            let v232_8: Space = if (&(v232_5)).is_empty() { Space::new() } else {
              let v233_6: Path = concat_path(&(v231_6),&v217_20_cursor.path()[(v217_20_origin + 2)..(v217_20_origin + 3)]);
              let v233_7: Space = routine_26(c, &(v233_6), &v217_20_cursor);
              compose(&(v232_5),&(v233_7))
            };
            drop(v232_5);
            let v232_9: Space = intersect(&(*CONSTANT_1),&(v232_2));
            drop(v232_2);
            let v232_10: Space = if has_head(&(v232_9)) { singleton(&[]) } else { Space::new() };
            drop(v232_9);
            let v232_12: Space = if (&(v232_10)).is_empty() { Space::new() } else {
              let v234_6: Path = concat_path(&(v231_6),&v217_20_cursor.path()[(v217_20_origin + 2)..(v217_20_origin + 3)]);
              let v234_11: Space = routine_27(c, &(v234_6), &v217_20_cursor);
              drop(v234_6);
              compose(&(v232_10),&(v234_11))
            };
            drop(v232_10);
            let v232_13: Space = unite(&(v232_8),&(v232_12));
            join_wrapped_into(&mut v231_7_write,&((v232_13).read_zipper()),&[]);
            }
            v217_20_cursor.ascend(1);
          }
          drop(v231_7_write);
          drop(v231_6);
          compose(&(v230_5),&(v231_7))
        };
        drop(v230_5);
        let v230_9: Space = intersect(&(*CONSTANT_1),&(v230_2));
        drop(v230_2);
        let v230_10: Space = if has_head(&(v230_9)) { singleton(&[]) } else { Space::new() };
        drop(v230_9);
        let v230_11: Space = compose(&(v230_10),&v217_20_cursor);
        drop(v230_10);
        let v230_12: Space = unite(&(v230_8),&(v230_11));
        drop(v230_11);
        join_wrapped_into(&mut v229_11_write,&((v230_12).read_zipper()),&[]);
        }
        v217_20_cursor.ascend(1);
      }
      drop(v229_11_write);
      drop(v229_6);
      compose(&(v218_10),&(v229_11))
    };
    drop(v218_10);
    let v218_13: Space = unite(&(v218_8),&(v218_12));
    join_wrapped_into(&mut v217_20_write,&((v218_13).read_zipper()),&[]);
    }
    v217_20_cursor.ascend(1);
  }
  drop(v217_20_cursor);
  drop(v217_20_write);
  (v217_20).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v235_14 = Space::new();
  let mut v235_14_write = v235_14.write_zipper();
  let mut v235_14_cursor = (*s0).read_zipper();
  let v235_14_origin = v235_14_cursor.path().len();
  for v235_14_byte in v235_14_cursor.child_mask().iter() {
    v235_14_cursor.descend_to_existing_byte(v235_14_byte);
    {
    let v236_2: Space = singleton(&v235_14_cursor.path()[v235_14_origin..(v235_14_origin + 1)]);
    let v236_3: Space = intersect(&(*CONSTANT_1),&(v236_2));
    let v236_4: Space = if has_head(&(v236_3)) { singleton(&[]) } else { Space::new() };
    drop(v236_3);
    let v236_5: Space = subtract(&(*CONSTANT_0),&(v236_4));
    drop(v236_4);
    let v236_8: Space = if (&(v236_5)).is_empty() { Space::new() } else {
      let v237_6: Path = concat_path(&(*p0),&v235_14_cursor.path()[v235_14_origin..(v235_14_origin + 1)]);
      let mut v237_7 = Space::new();
      let mut v237_7_write = v237_7.write_zipper();
      for v237_7_byte in v235_14_cursor.child_mask().iter() {
        v235_14_cursor.descend_to_existing_byte(v237_7_byte);
        {
        let v238_2: Space = singleton(&v235_14_cursor.path()[(v235_14_origin + 1)..(v235_14_origin + 2)]);
        let v238_3: Space = intersect(&(*CONSTANT_1),&(v238_2));
        let v238_4: Space = if has_head(&(v238_3)) { singleton(&[]) } else { Space::new() };
        drop(v238_3);
        let v238_5: Space = subtract(&(*CONSTANT_0),&(v238_4));
        drop(v238_4);
        let v238_8: Space = if (&(v238_5)).is_empty() { Space::new() } else {
          let v239_6: Path = concat_path(&(v237_6),&v235_14_cursor.path()[(v235_14_origin + 1)..(v235_14_origin + 2)]);
          let mut v239_7 = Space::new();
          let mut v239_7_write = v239_7.write_zipper();
          for v239_7_byte in v235_14_cursor.child_mask().iter() {
            v235_14_cursor.descend_to_existing_byte(v239_7_byte);
            {
            let v240_2: Space = singleton(&v235_14_cursor.path()[(v235_14_origin + 2)..(v235_14_origin + 3)]);
            let v240_3: Space = intersect(&(*CONSTANT_1),&(v240_2));
            let v240_4: Space = if has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
            drop(v240_3);
            let v240_5: Space = subtract(&(*CONSTANT_0),&(v240_4));
            drop(v240_4);
            let v240_8: Space = if (&(v240_5)).is_empty() { Space::new() } else {
              let v241_6: Path = concat_path(&(v239_6),&v235_14_cursor.path()[(v235_14_origin + 2)..(v235_14_origin + 3)]);
              let v241_7: Space = routine_26(c, &(v241_6), &v235_14_cursor);
              compose(&(v240_5),&(v241_7))
            };
            drop(v240_5);
            let v240_9: Space = intersect(&(*CONSTANT_1),&(v240_2));
            drop(v240_2);
            let v240_10: Space = if has_head(&(v240_9)) { singleton(&[]) } else { Space::new() };
            drop(v240_9);
            let v240_12: Space = if (&(v240_10)).is_empty() { Space::new() } else {
              let v242_6: Path = concat_path(&(v239_6),&v235_14_cursor.path()[(v235_14_origin + 2)..(v235_14_origin + 3)]);
              let v242_11: Space = routine_27(c, &(v242_6), &v235_14_cursor);
              drop(v242_6);
              compose(&(v240_10),&(v242_11))
            };
            drop(v240_10);
            let v240_13: Space = unite(&(v240_8),&(v240_12));
            join_wrapped_into(&mut v239_7_write,&((v240_13).read_zipper()),&[]);
            }
            v235_14_cursor.ascend(1);
          }
          drop(v239_7_write);
          compose(&(v238_5),&(v239_7))
        };
        drop(v238_5);
        let v238_9: Space = intersect(&(*CONSTANT_1),&(v238_2));
        drop(v238_2);
        let v238_10: Space = if has_head(&(v238_9)) { singleton(&[]) } else { Space::new() };
        drop(v238_9);
        let v238_12: Space = if (&(v238_10)).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v237_6),&v235_14_cursor.path()[(v235_14_origin + 1)..(v235_14_origin + 2)]);
          let mut v243_11 = Space::new();
          let mut v243_11_write = v243_11.write_zipper();
          for v243_11_byte in v235_14_cursor.child_mask().iter() {
            v235_14_cursor.descend_to_existing_byte(v243_11_byte);
            {
            let v244_2: Space = singleton(&v235_14_cursor.path()[(v235_14_origin + 2)..(v235_14_origin + 3)]);
            let v244_3: Space = intersect(&(*CONSTANT_1),&(v244_2));
            let v244_4: Space = if has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
            drop(v244_3);
            let v244_5: Space = subtract(&(*CONSTANT_0),&(v244_4));
            drop(v244_4);
            let v244_8: Space = if (&(v244_5)).is_empty() { Space::new() } else {
              let v245_6: Path = concat_path(&(v243_6),&v235_14_cursor.path()[(v235_14_origin + 2)..(v235_14_origin + 3)]);
              let v245_7: Space = routine_26(c, &(v245_6), &v235_14_cursor);
              compose(&(v244_5),&(v245_7))
            };
            drop(v244_5);
            let v244_9: Space = intersect(&(*CONSTANT_1),&(v244_2));
            drop(v244_2);
            let v244_10: Space = if has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
            drop(v244_9);
            let v244_12: Space = if (&(v244_10)).is_empty() { Space::new() } else {
              let v246_6: Path = concat_path(&(v243_6),&v235_14_cursor.path()[(v235_14_origin + 2)..(v235_14_origin + 3)]);
              let v246_11: Space = routine_15(c, &(v246_6), &v235_14_cursor);
              drop(v246_6);
              compose(&(v244_10),&(v246_11))
            };
            drop(v244_10);
            let v244_13: Space = unite(&(v244_8),&(v244_12));
            join_wrapped_into(&mut v243_11_write,&((v244_13).read_zipper()),&[]);
            }
            v235_14_cursor.ascend(1);
          }
          drop(v243_11_write);
          drop(v243_6);
          compose(&(v238_10),&(v243_11))
        };
        drop(v238_10);
        let v238_13: Space = unite(&(v238_8),&(v238_12));
        join_wrapped_into(&mut v237_7_write,&((v238_13).read_zipper()),&[]);
        }
        v235_14_cursor.ascend(1);
      }
      drop(v237_7_write);
      drop(v237_6);
      compose(&(v236_5),&(v237_7))
    };
    drop(v236_5);
    let v236_9: Space = intersect(&(*CONSTANT_1),&(v236_2));
    drop(v236_2);
    let v236_10: Space = if has_head(&(v236_9)) { singleton(&[]) } else { Space::new() };
    drop(v236_9);
    let v236_11: Space = compose(&(v236_10),&v235_14_cursor);
    drop(v236_10);
    let v236_12: Space = unite(&(v236_8),&(v236_11));
    drop(v236_11);
    join_wrapped_into(&mut v235_14_write,&((v236_12).read_zipper()),&[]);
    }
    v235_14_cursor.ascend(1);
  }
  drop(v235_14_cursor);
  drop(v235_14_write);
  (v235_14).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_16(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v248_12 = Space::new();
  let mut v248_12_write = v248_12.write_zipper();
  let mut v248_12_cursor = (*s0).read_zipper();
  let v248_12_origin = v248_12_cursor.path().len();
  for v248_12_byte in v248_12_cursor.child_mask().iter() {
    v248_12_cursor.descend_to_existing_byte(v248_12_byte);
    {
    let v249_2: Space = singleton(&v248_12_cursor.path()[v248_12_origin..(v248_12_origin + 1)]);
    let v249_3: Space = intersect(&(*CONSTANT_1),&(v249_2));
    let v249_4: Space = if has_head(&(v249_3)) { singleton(&[]) } else { Space::new() };
    drop(v249_3);
    let v249_5: Space = subtract(&(*CONSTANT_0),&(v249_4));
    drop(v249_4);
    let v249_8: Space = if (&(v249_5)).is_empty() { Space::new() } else {
      let v250_6: Path = concat_path(&(*p0),&v248_12_cursor.path()[v248_12_origin..(v248_12_origin + 1)]);
      let mut v250_7 = Space::new();
      let mut v250_7_write = v250_7.write_zipper();
      for v250_7_byte in v248_12_cursor.child_mask().iter() {
        v248_12_cursor.descend_to_existing_byte(v250_7_byte);
        {
        let v251_2: Space = singleton(&v248_12_cursor.path()[(v248_12_origin + 1)..(v248_12_origin + 2)]);
        let v251_3: Space = intersect(&(*CONSTANT_1),&(v251_2));
        let v251_4: Space = if has_head(&(v251_3)) { singleton(&[]) } else { Space::new() };
        drop(v251_3);
        let v251_5: Space = subtract(&(*CONSTANT_0),&(v251_4));
        drop(v251_4);
        let v251_7: Space = if (&(v251_5)).is_empty() { Space::new() } else {
          let mut v252_6 = Space::new();
          let mut v252_6_write = v252_6.write_zipper();
          for v252_6_byte in v248_12_cursor.child_mask().iter() {
            v248_12_cursor.descend_to_existing_byte(v252_6_byte);
            {
            let v253_2: Space = Space::new();
            join_wrapped_into(&mut v252_6_write,&((v253_2).read_zipper()),&[]);
            }
            v248_12_cursor.ascend(1);
          }
          drop(v252_6_write);
          compose(&(v251_5),&(v252_6))
        };
        drop(v251_5);
        let v251_8: Space = intersect(&(*CONSTANT_1),&(v251_2));
        drop(v251_2);
        let v251_9: Space = if has_head(&(v251_8)) { singleton(&[]) } else { Space::new() };
        drop(v251_8);
        let v251_12: Space = if (&(v251_9)).is_empty() { Space::new() } else {
          let v254_10: Path = concat_path(&(v250_6),&v248_12_cursor.path()[(v248_12_origin + 1)..(v248_12_origin + 2)]);
          let mut v254_11 = Space::new();
          let mut v254_11_write = v254_11.write_zipper();
          for v254_11_byte in v248_12_cursor.child_mask().iter() {
            v248_12_cursor.descend_to_existing_byte(v254_11_byte);
            {
            let v255_2: Space = singleton(&v248_12_cursor.path()[(v248_12_origin + 2)..(v248_12_origin + 3)]);
            let v255_3: Space = intersect(&(*CONSTANT_1),&(v255_2));
            drop(v255_2);
            let v255_4: Space = if has_head(&(v255_3)) { singleton(&[]) } else { Space::new() };
            drop(v255_3);
            let v255_7: Space = if (&(v255_4)).is_empty() { Space::new() } else {
              let v256_5: Path = concat_path(&(v254_10),&v248_12_cursor.path()[(v248_12_origin + 2)..(v248_12_origin + 3)]);
              let v256_6: Space = routine_12(c, &(v256_5), &v248_12_cursor);
              drop(v256_5);
              compose(&(v255_4),&(v256_6))
            };
            drop(v255_4);
            join_wrapped_into(&mut v254_11_write,&((v255_7).read_zipper()),&[]);
            }
            v248_12_cursor.ascend(1);
          }
          drop(v254_11_write);
          drop(v254_10);
          compose(&(v251_9),&(v254_11))
        };
        drop(v251_9);
        let v251_13: Space = unite(&(v251_7),&(v251_12));
        drop(v251_7);
        join_wrapped_into(&mut v250_7_write,&((v251_13).read_zipper()),&[]);
        }
        v248_12_cursor.ascend(1);
      }
      drop(v250_7_write);
      drop(v250_6);
      compose(&(v249_5),&(v250_7))
    };
    drop(v249_5);
    let v249_9: Space = intersect(&(*CONSTANT_1),&(v249_2));
    drop(v249_2);
    let v249_10: Space = if has_head(&(v249_9)) { singleton(&[]) } else { Space::new() };
    drop(v249_9);
    let v249_12: Space = if (&(v249_10)).is_empty() { Space::new() } else {
      let mut v257_11 = Space::new();
      let mut v257_11_write = v257_11.write_zipper();
      for v257_11_byte in v248_12_cursor.child_mask().iter() {
        v248_12_cursor.descend_to_existing_byte(v257_11_byte);
        {
        let v258_2: Space = singleton(&v248_12_cursor.path()[(v248_12_origin + 1)..(v248_12_origin + 2)]);
        let v258_3: Space = intersect(&(*CONSTANT_1),&(v258_2));
        let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
        drop(v258_3);
        let v258_5: Space = subtract(&(*CONSTANT_0),&(v258_4));
        drop(v258_4);
        let v258_7: Space = if (&(v258_5)).is_empty() { Space::new() } else {
          let mut v259_6 = Space::new();
          let mut v259_6_write = v259_6.write_zipper();
          for v259_6_byte in v248_12_cursor.child_mask().iter() {
            v248_12_cursor.descend_to_existing_byte(v259_6_byte);
            {
            let v260_2: Space = Space::new();
            join_wrapped_into(&mut v259_6_write,&((v260_2).read_zipper()),&[]);
            }
            v248_12_cursor.ascend(1);
          }
          drop(v259_6_write);
          compose(&(v258_5),&(v259_6))
        };
        drop(v258_5);
        let v258_8: Space = intersect(&(*CONSTANT_1),&(v258_2));
        drop(v258_2);
        let v258_9: Space = if has_head(&(v258_8)) { singleton(&[]) } else { Space::new() };
        drop(v258_8);
        let v258_10: Space = compose(&(v258_9),&v248_12_cursor);
        drop(v258_9);
        let v258_11: Space = unite(&(v258_7),&(v258_10));
        drop(v258_7);
        drop(v258_10);
        join_wrapped_into(&mut v257_11_write,&((v258_11).read_zipper()),&[]);
        }
        v248_12_cursor.ascend(1);
      }
      drop(v257_11_write);
      compose(&(v249_10),&(v257_11))
    };
    drop(v249_10);
    let v249_13: Space = unite(&(v249_8),&(v249_12));
    drop(v249_12);
    join_wrapped_into(&mut v248_12_write,&((v249_13).read_zipper()),&[]);
    }
    v248_12_cursor.ascend(1);
  }
  drop(v248_12_cursor);
  drop(v248_12_write);
  (v248_12).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v261_9 = Space::new();
  let mut v261_9_write = v261_9.write_zipper();
  let mut v261_9_cursor = (*s0).read_zipper();
  let v261_9_origin = v261_9_cursor.path().len();
  for v261_9_byte in v261_9_cursor.child_mask().iter() {
    v261_9_cursor.descend_to_existing_byte(v261_9_byte);
    {
    let v262_2: Space = singleton(&v261_9_cursor.path()[v261_9_origin..(v261_9_origin + 1)]);
    let v262_3: Space = intersect(&(*CONSTANT_1),&(v262_2));
    let v262_4: Space = if has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
    drop(v262_3);
    let v262_5: Space = subtract(&(*CONSTANT_0),&(v262_4));
    drop(v262_4);
    let v262_8: Space = if (&(v262_5)).is_empty() { Space::new() } else {
      let v263_6: Path = concat_path(&(*p0),&v261_9_cursor.path()[v261_9_origin..(v261_9_origin + 1)]);
      let mut v263_7 = Space::new();
      let mut v263_7_write = v263_7.write_zipper();
      for v263_7_byte in v261_9_cursor.child_mask().iter() {
        v261_9_cursor.descend_to_existing_byte(v263_7_byte);
        {
        let v264_2: Space = singleton(&v261_9_cursor.path()[(v261_9_origin + 1)..(v261_9_origin + 2)]);
        let v264_3: Space = intersect(&(*CONSTANT_1),&(v264_2));
        let v264_4: Space = if has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
        drop(v264_3);
        let v264_5: Space = subtract(&(*CONSTANT_0),&(v264_4));
        drop(v264_4);
        let v264_7: Space = if (&(v264_5)).is_empty() { Space::new() } else {
          let mut v265_6 = Space::new();
          let mut v265_6_write = v265_6.write_zipper();
          for v265_6_byte in v261_9_cursor.child_mask().iter() {
            v261_9_cursor.descend_to_existing_byte(v265_6_byte);
            {
            let v266_2: Space = Space::new();
            join_wrapped_into(&mut v265_6_write,&((v266_2).read_zipper()),&[]);
            }
            v261_9_cursor.ascend(1);
          }
          drop(v265_6_write);
          compose(&(v264_5),&(v265_6))
        };
        drop(v264_5);
        let v264_8: Space = intersect(&(*CONSTANT_1),&(v264_2));
        drop(v264_2);
        let v264_9: Space = if has_head(&(v264_8)) { singleton(&[]) } else { Space::new() };
        drop(v264_8);
        let v264_12: Space = if (&(v264_9)).is_empty() { Space::new() } else {
          let v267_10: Path = concat_path(&(v263_6),&v261_9_cursor.path()[(v261_9_origin + 1)..(v261_9_origin + 2)]);
          let mut v267_11 = Space::new();
          let mut v267_11_write = v267_11.write_zipper();
          for v267_11_byte in v261_9_cursor.child_mask().iter() {
            v261_9_cursor.descend_to_existing_byte(v267_11_byte);
            {
            let v268_2: Space = singleton(&v261_9_cursor.path()[(v261_9_origin + 2)..(v261_9_origin + 3)]);
            let v268_3: Space = intersect(&(*CONSTANT_1),&(v268_2));
            drop(v268_2);
            let v268_4: Space = if has_head(&(v268_3)) { singleton(&[]) } else { Space::new() };
            drop(v268_3);
            let v268_7: Space = if (&(v268_4)).is_empty() { Space::new() } else {
              let v269_5: Path = concat_path(&(v267_10),&v261_9_cursor.path()[(v261_9_origin + 2)..(v261_9_origin + 3)]);
              let v269_6: Space = routine_12(c, &(v269_5), &v261_9_cursor);
              drop(v269_5);
              compose(&(v268_4),&(v269_6))
            };
            drop(v268_4);
            join_wrapped_into(&mut v267_11_write,&((v268_7).read_zipper()),&[]);
            }
            v261_9_cursor.ascend(1);
          }
          drop(v267_11_write);
          drop(v267_10);
          compose(&(v264_9),&(v267_11))
        };
        drop(v264_9);
        let v264_13: Space = unite(&(v264_7),&(v264_12));
        drop(v264_7);
        join_wrapped_into(&mut v263_7_write,&((v264_13).read_zipper()),&[]);
        }
        v261_9_cursor.ascend(1);
      }
      drop(v263_7_write);
      drop(v263_6);
      compose(&(v262_5),&(v263_7))
    };
    drop(v262_5);
    let v262_9: Space = intersect(&(*CONSTANT_1),&(v262_2));
    drop(v262_2);
    let v262_10: Space = if has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
    drop(v262_9);
    let v262_11: Space = compose(&(v262_10),&v261_9_cursor);
    drop(v262_10);
    let v262_12: Space = unite(&(v262_8),&(v262_11));
    drop(v262_11);
    join_wrapped_into(&mut v261_9_write,&((v262_12).read_zipper()),&[]);
    }
    v261_9_cursor.ascend(1);
  }
  drop(v261_9_cursor);
  drop(v261_9_write);
  (v261_9).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v270_12 = Space::new();
  let mut v270_12_write = v270_12.write_zipper();
  let mut v270_12_cursor = (*s0).read_zipper();
  let v270_12_origin = v270_12_cursor.path().len();
  for v270_12_byte in v270_12_cursor.child_mask().iter() {
    v270_12_cursor.descend_to_existing_byte(v270_12_byte);
    {
    let v271_2: Space = singleton(&v270_12_cursor.path()[v270_12_origin..(v270_12_origin + 1)]);
    let v271_3: Space = intersect(&(*CONSTANT_1),&(v271_2));
    let v271_4: Space = if has_head(&(v271_3)) { singleton(&[]) } else { Space::new() };
    drop(v271_3);
    let v271_5: Space = subtract(&(*CONSTANT_0),&(v271_4));
    drop(v271_4);
    let v271_8: Space = if (&(v271_5)).is_empty() { Space::new() } else {
      let v272_6: Path = concat_path(&(*p0),&v270_12_cursor.path()[v270_12_origin..(v270_12_origin + 1)]);
      let mut v272_7 = Space::new();
      let mut v272_7_write = v272_7.write_zipper();
      for v272_7_byte in v270_12_cursor.child_mask().iter() {
        v270_12_cursor.descend_to_existing_byte(v272_7_byte);
        {
        let v273_2: Space = singleton(&v270_12_cursor.path()[(v270_12_origin + 1)..(v270_12_origin + 2)]);
        let v273_3: Space = intersect(&(*CONSTANT_1),&(v273_2));
        let v273_4: Space = if has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
        drop(v273_3);
        let v273_5: Space = subtract(&(*CONSTANT_0),&(v273_4));
        drop(v273_4);
        let v273_7: Space = if (&(v273_5)).is_empty() { Space::new() } else {
          let mut v274_6 = Space::new();
          let mut v274_6_write = v274_6.write_zipper();
          for v274_6_byte in v270_12_cursor.child_mask().iter() {
            v270_12_cursor.descend_to_existing_byte(v274_6_byte);
            {
            let v275_2: Space = Space::new();
            join_wrapped_into(&mut v274_6_write,&((v275_2).read_zipper()),&[]);
            }
            v270_12_cursor.ascend(1);
          }
          drop(v274_6_write);
          compose(&(v273_5),&(v274_6))
        };
        drop(v273_5);
        let v273_8: Space = intersect(&(*CONSTANT_1),&(v273_2));
        drop(v273_2);
        let v273_9: Space = if has_head(&(v273_8)) { singleton(&[]) } else { Space::new() };
        drop(v273_8);
        let v273_12: Space = if (&(v273_9)).is_empty() { Space::new() } else {
          let v276_10: Path = concat_path(&(v272_6),&v270_12_cursor.path()[(v270_12_origin + 1)..(v270_12_origin + 2)]);
          let mut v276_11 = Space::new();
          let mut v276_11_write = v276_11.write_zipper();
          for v276_11_byte in v270_12_cursor.child_mask().iter() {
            v270_12_cursor.descend_to_existing_byte(v276_11_byte);
            {
            let v277_2: Space = singleton(&v270_12_cursor.path()[(v270_12_origin + 2)..(v270_12_origin + 3)]);
            let v277_3: Space = intersect(&(*CONSTANT_1),&(v277_2));
            drop(v277_2);
            let v277_4: Space = if has_head(&(v277_3)) { singleton(&[]) } else { Space::new() };
            drop(v277_3);
            let v277_7: Space = if (&(v277_4)).is_empty() { Space::new() } else {
              let v278_5: Path = concat_path(&(v276_10),&v270_12_cursor.path()[(v270_12_origin + 2)..(v270_12_origin + 3)]);
              let v278_6: Space = routine_15(c, &(v278_5), &v270_12_cursor);
              drop(v278_5);
              compose(&(v277_4),&(v278_6))
            };
            drop(v277_4);
            join_wrapped_into(&mut v276_11_write,&((v277_7).read_zipper()),&[]);
            }
            v270_12_cursor.ascend(1);
          }
          drop(v276_11_write);
          drop(v276_10);
          compose(&(v273_9),&(v276_11))
        };
        drop(v273_9);
        let v273_13: Space = unite(&(v273_7),&(v273_12));
        drop(v273_7);
        join_wrapped_into(&mut v272_7_write,&((v273_13).read_zipper()),&[]);
        }
        v270_12_cursor.ascend(1);
      }
      drop(v272_7_write);
      drop(v272_6);
      compose(&(v271_5),&(v272_7))
    };
    drop(v271_5);
    let v271_9: Space = intersect(&(*CONSTANT_1),&(v271_2));
    drop(v271_2);
    let v271_10: Space = if has_head(&(v271_9)) { singleton(&[]) } else { Space::new() };
    drop(v271_9);
    let v271_12: Space = if (&(v271_10)).is_empty() { Space::new() } else {
      let mut v279_11 = Space::new();
      let mut v279_11_write = v279_11.write_zipper();
      for v279_11_byte in v270_12_cursor.child_mask().iter() {
        v270_12_cursor.descend_to_existing_byte(v279_11_byte);
        {
        let v280_2: Space = singleton(&v270_12_cursor.path()[(v270_12_origin + 1)..(v270_12_origin + 2)]);
        let v280_3: Space = intersect(&(*CONSTANT_1),&(v280_2));
        let v280_4: Space = if has_head(&(v280_3)) { singleton(&[]) } else { Space::new() };
        drop(v280_3);
        let v280_5: Space = subtract(&(*CONSTANT_0),&(v280_4));
        drop(v280_4);
        let v280_7: Space = if (&(v280_5)).is_empty() { Space::new() } else {
          let mut v281_6 = Space::new();
          let mut v281_6_write = v281_6.write_zipper();
          for v281_6_byte in v270_12_cursor.child_mask().iter() {
            v270_12_cursor.descend_to_existing_byte(v281_6_byte);
            {
            let v282_2: Space = Space::new();
            join_wrapped_into(&mut v281_6_write,&((v282_2).read_zipper()),&[]);
            }
            v270_12_cursor.ascend(1);
          }
          drop(v281_6_write);
          compose(&(v280_5),&(v281_6))
        };
        drop(v280_5);
        let v280_8: Space = intersect(&(*CONSTANT_1),&(v280_2));
        drop(v280_2);
        let v280_9: Space = if has_head(&(v280_8)) { singleton(&[]) } else { Space::new() };
        drop(v280_8);
        let v280_10: Space = compose(&(v280_9),&v270_12_cursor);
        drop(v280_9);
        let v280_11: Space = unite(&(v280_7),&(v280_10));
        drop(v280_7);
        drop(v280_10);
        join_wrapped_into(&mut v279_11_write,&((v280_11).read_zipper()),&[]);
        }
        v270_12_cursor.ascend(1);
      }
      drop(v279_11_write);
      compose(&(v271_10),&(v279_11))
    };
    drop(v271_10);
    let v271_13: Space = unite(&(v271_8),&(v271_12));
    drop(v271_12);
    join_wrapped_into(&mut v270_12_write,&((v271_13).read_zipper()),&[]);
    }
    v270_12_cursor.ascend(1);
  }
  drop(v270_12_cursor);
  drop(v270_12_write);
  (v270_12).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v283_9 = Space::new();
  let mut v283_9_write = v283_9.write_zipper();
  let mut v283_9_cursor = (*s0).read_zipper();
  let v283_9_origin = v283_9_cursor.path().len();
  for v283_9_byte in v283_9_cursor.child_mask().iter() {
    v283_9_cursor.descend_to_existing_byte(v283_9_byte);
    {
    let v284_2: Space = singleton(&v283_9_cursor.path()[v283_9_origin..(v283_9_origin + 1)]);
    let v284_3: Space = intersect(&(*CONSTANT_1),&(v284_2));
    let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
    drop(v284_3);
    let v284_5: Space = subtract(&(*CONSTANT_0),&(v284_4));
    drop(v284_4);
    let v284_8: Space = if (&(v284_5)).is_empty() { Space::new() } else {
      let v285_6: Path = concat_path(&(*p0),&v283_9_cursor.path()[v283_9_origin..(v283_9_origin + 1)]);
      let mut v285_7 = Space::new();
      let mut v285_7_write = v285_7.write_zipper();
      for v285_7_byte in v283_9_cursor.child_mask().iter() {
        v283_9_cursor.descend_to_existing_byte(v285_7_byte);
        {
        let v286_2: Space = singleton(&v283_9_cursor.path()[(v283_9_origin + 1)..(v283_9_origin + 2)]);
        let v286_3: Space = intersect(&(*CONSTANT_1),&(v286_2));
        let v286_4: Space = if has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
        drop(v286_3);
        let v286_5: Space = subtract(&(*CONSTANT_0),&(v286_4));
        drop(v286_4);
        let v286_7: Space = if (&(v286_5)).is_empty() { Space::new() } else {
          let mut v287_6 = Space::new();
          let mut v287_6_write = v287_6.write_zipper();
          for v287_6_byte in v283_9_cursor.child_mask().iter() {
            v283_9_cursor.descend_to_existing_byte(v287_6_byte);
            {
            let v288_2: Space = Space::new();
            join_wrapped_into(&mut v287_6_write,&((v288_2).read_zipper()),&[]);
            }
            v283_9_cursor.ascend(1);
          }
          drop(v287_6_write);
          compose(&(v286_5),&(v287_6))
        };
        drop(v286_5);
        let v286_8: Space = intersect(&(*CONSTANT_1),&(v286_2));
        drop(v286_2);
        let v286_9: Space = if has_head(&(v286_8)) { singleton(&[]) } else { Space::new() };
        drop(v286_8);
        let v286_12: Space = if (&(v286_9)).is_empty() { Space::new() } else {
          let v289_10: Path = concat_path(&(v285_6),&v283_9_cursor.path()[(v283_9_origin + 1)..(v283_9_origin + 2)]);
          let mut v289_11 = Space::new();
          let mut v289_11_write = v289_11.write_zipper();
          for v289_11_byte in v283_9_cursor.child_mask().iter() {
            v283_9_cursor.descend_to_existing_byte(v289_11_byte);
            {
            let v290_2: Space = singleton(&v283_9_cursor.path()[(v283_9_origin + 2)..(v283_9_origin + 3)]);
            let v290_3: Space = intersect(&(*CONSTANT_1),&(v290_2));
            drop(v290_2);
            let v290_4: Space = if has_head(&(v290_3)) { singleton(&[]) } else { Space::new() };
            drop(v290_3);
            let v290_7: Space = if (&(v290_4)).is_empty() { Space::new() } else {
              let v291_5: Path = concat_path(&(v289_10),&v283_9_cursor.path()[(v283_9_origin + 2)..(v283_9_origin + 3)]);
              let v291_6: Space = routine_15(c, &(v291_5), &v283_9_cursor);
              drop(v291_5);
              compose(&(v290_4),&(v291_6))
            };
            drop(v290_4);
            join_wrapped_into(&mut v289_11_write,&((v290_7).read_zipper()),&[]);
            }
            v283_9_cursor.ascend(1);
          }
          drop(v289_11_write);
          drop(v289_10);
          compose(&(v286_9),&(v289_11))
        };
        drop(v286_9);
        let v286_13: Space = unite(&(v286_7),&(v286_12));
        drop(v286_7);
        join_wrapped_into(&mut v285_7_write,&((v286_13).read_zipper()),&[]);
        }
        v283_9_cursor.ascend(1);
      }
      drop(v285_7_write);
      drop(v285_6);
      compose(&(v284_5),&(v285_7))
    };
    drop(v284_5);
    let v284_9: Space = intersect(&(*CONSTANT_1),&(v284_2));
    drop(v284_2);
    let v284_10: Space = if has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
    drop(v284_9);
    let v284_11: Space = compose(&(v284_10),&v283_9_cursor);
    drop(v284_10);
    let v284_12: Space = unite(&(v284_8),&(v284_11));
    drop(v284_11);
    join_wrapped_into(&mut v283_9_write,&((v284_12).read_zipper()),&[]);
    }
    v283_9_cursor.ascend(1);
  }
  drop(v283_9_cursor);
  drop(v283_9_write);
  (v283_9).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v292_6 = Space::new();
  let mut v292_6_write = v292_6.write_zipper();
  let mut v292_6_cursor = (*s0).read_zipper();
  let v292_6_origin = v292_6_cursor.path().len();
  for v292_6_byte in v292_6_cursor.child_mask().iter() {
    v292_6_cursor.descend_to_existing_byte(v292_6_byte);
    {
    let v293_2: Space = singleton(&v292_6_cursor.path()[v292_6_origin..(v292_6_origin + 1)]);
    let v293_3: Space = intersect(&(*CONSTANT_1),&(v293_2));
    let v293_4: Space = if has_head(&(v293_3)) { singleton(&[]) } else { Space::new() };
    drop(v293_3);
    let v293_5: Space = subtract(&(*CONSTANT_0),&(v293_4));
    drop(v293_4);
    let v293_7: Space = if (&(v293_5)).is_empty() { Space::new() } else {
      let mut v294_6 = Space::new();
      let mut v294_6_write = v294_6.write_zipper();
      for v294_6_byte in v292_6_cursor.child_mask().iter() {
        v292_6_cursor.descend_to_existing_byte(v294_6_byte);
        {
        let v295_2: Space = Space::new();
        join_wrapped_into(&mut v294_6_write,&((v295_2).read_zipper()),&[]);
        }
        v292_6_cursor.ascend(1);
      }
      drop(v294_6_write);
      compose(&(v293_5),&(v294_6))
    };
    drop(v293_5);
    let v293_8: Space = intersect(&(*CONSTANT_1),&(v293_2));
    drop(v293_2);
    let v293_9: Space = if has_head(&(v293_8)) { singleton(&[]) } else { Space::new() };
    drop(v293_8);
    let v293_11: Space = if (&(v293_9)).is_empty() { Space::new() } else {
      let mut v296_10 = Space::new();
      let mut v296_10_write = v296_10.write_zipper();
      for v296_10_byte in v292_6_cursor.child_mask().iter() {
        v292_6_cursor.descend_to_existing_byte(v296_10_byte);
        {
        let v297_2: Space = singleton(&v292_6_cursor.path()[(v292_6_origin + 1)..(v292_6_origin + 2)]);
        let v297_3: Space = intersect(&(*CONSTANT_1),&(v297_2));
        drop(v297_2);
        let v297_4: Space = if has_head(&(v297_3)) { singleton(&[]) } else { Space::new() };
        drop(v297_3);
        let v297_5: Space = compose(&(v297_4),&v292_6_cursor);
        drop(v297_4);
        join_wrapped_into(&mut v296_10_write,&((v297_5).read_zipper()),&[]);
        }
        v292_6_cursor.ascend(1);
      }
      drop(v296_10_write);
      compose(&(v293_9),&(v296_10))
    };
    drop(v293_9);
    let v293_12: Space = unite(&(v293_7),&(v293_11));
    drop(v293_7);
    drop(v293_11);
    join_wrapped_into(&mut v292_6_write,&((v293_12).read_zipper()),&[]);
    }
    v292_6_cursor.ascend(1);
  }
  drop(v292_6_cursor);
  drop(v292_6_write);
  (v292_6).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v298_5 = Space::new();
  let mut v298_5_write = v298_5.write_zipper();
  let mut v298_5_cursor = (*s0).read_zipper();
  let v298_5_origin = v298_5_cursor.path().len();
  for v298_5_byte in v298_5_cursor.child_mask().iter() {
    v298_5_cursor.descend_to_existing_byte(v298_5_byte);
    {
    let v299_2: Space = singleton(&v298_5_cursor.path()[v298_5_origin..(v298_5_origin + 1)]);
    let v299_3: Space = intersect(&(*CONSTANT_1),&(v299_2));
    let v299_4: Space = if has_head(&(v299_3)) { singleton(&[]) } else { Space::new() };
    drop(v299_3);
    let v299_5: Space = subtract(&(*CONSTANT_0),&(v299_4));
    drop(v299_4);
    let v299_7: Space = if (&(v299_5)).is_empty() { Space::new() } else {
      let mut v300_6 = Space::new();
      let mut v300_6_write = v300_6.write_zipper();
      for v300_6_byte in v298_5_cursor.child_mask().iter() {
        v298_5_cursor.descend_to_existing_byte(v300_6_byte);
        {
        let v301_2: Space = Space::new();
        join_wrapped_into(&mut v300_6_write,&((v301_2).read_zipper()),&[]);
        }
        v298_5_cursor.ascend(1);
      }
      drop(v300_6_write);
      compose(&(v299_5),&(v300_6))
    };
    drop(v299_5);
    let v299_8: Space = intersect(&(*CONSTANT_1),&(v299_2));
    drop(v299_2);
    let v299_9: Space = if has_head(&(v299_8)) { singleton(&[]) } else { Space::new() };
    drop(v299_8);
    let v299_10: Space = compose(&(v299_9),&v298_5_cursor);
    drop(v299_9);
    let v299_11: Space = unite(&(v299_7),&(v299_10));
    drop(v299_7);
    drop(v299_10);
    join_wrapped_into(&mut v298_5_write,&((v299_11).read_zipper()),&[]);
    }
    v298_5_cursor.ascend(1);
  }
  drop(v298_5_cursor);
  drop(v298_5_write);
  (v298_5).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v302_6 = Space::new();
  let mut v302_6_write = v302_6.write_zipper();
  let mut v302_6_cursor = (*s0).read_zipper();
  let v302_6_origin = v302_6_cursor.path().len();
  for v302_6_byte in v302_6_cursor.child_mask().iter() {
    v302_6_cursor.descend_to_existing_byte(v302_6_byte);
    {
    let v303_2: Space = singleton(&v302_6_cursor.path()[v302_6_origin..(v302_6_origin + 1)]);
    let v303_3: Space = intersect(&(*CONSTANT_1),&(v303_2));
    let v303_4: Space = if has_head(&(v303_3)) { singleton(&[]) } else { Space::new() };
    drop(v303_3);
    let v303_5: Space = subtract(&(*CONSTANT_0),&(v303_4));
    drop(v303_4);
    let v303_7: Space = if (&(v303_5)).is_empty() { Space::new() } else {
      let mut v304_6 = Space::new();
      let mut v304_6_write = v304_6.write_zipper();
      for v304_6_byte in v302_6_cursor.child_mask().iter() {
        v302_6_cursor.descend_to_existing_byte(v304_6_byte);
        {
        let v305_2: Space = Space::new();
        join_wrapped_into(&mut v304_6_write,&((v305_2).read_zipper()),&[]);
        }
        v302_6_cursor.ascend(1);
      }
      drop(v304_6_write);
      compose(&(v303_5),&(v304_6))
    };
    drop(v303_5);
    let v303_8: Space = intersect(&(*CONSTANT_1),&(v303_2));
    drop(v303_2);
    let v303_9: Space = if has_head(&(v303_8)) { singleton(&[]) } else { Space::new() };
    drop(v303_8);
    let v303_11: Space = if (&(v303_9)).is_empty() { Space::new() } else {
      let mut v306_10 = Space::new();
      let mut v306_10_write = v306_10.write_zipper();
      for v306_10_byte in v302_6_cursor.child_mask().iter() {
        v302_6_cursor.descend_to_existing_byte(v306_10_byte);
        {
        let v307_2: Space = singleton(&v302_6_cursor.path()[(v302_6_origin + 1)..(v302_6_origin + 2)]);
        let v307_3: Space = intersect(&(*CONSTANT_1),&(v307_2));
        drop(v307_2);
        let v307_4: Space = if has_head(&(v307_3)) { singleton(&[]) } else { Space::new() };
        drop(v307_3);
        let v307_5: Space = compose(&(v307_4),&v302_6_cursor);
        drop(v307_4);
        join_wrapped_into(&mut v306_10_write,&((v307_5).read_zipper()),&[]);
        }
        v302_6_cursor.ascend(1);
      }
      drop(v306_10_write);
      compose(&(v303_9),&(v306_10))
    };
    drop(v303_9);
    let v303_12: Space = unite(&(v303_7),&(v303_11));
    drop(v303_7);
    drop(v303_11);
    join_wrapped_into(&mut v302_6_write,&((v303_12).read_zipper()),&[]);
    }
    v302_6_cursor.ascend(1);
  }
  drop(v302_6_cursor);
  drop(v302_6_write);
  (v302_6).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v308_5 = Space::new();
  let mut v308_5_write = v308_5.write_zipper();
  let mut v308_5_cursor = (*s0).read_zipper();
  let v308_5_origin = v308_5_cursor.path().len();
  for v308_5_byte in v308_5_cursor.child_mask().iter() {
    v308_5_cursor.descend_to_existing_byte(v308_5_byte);
    {
    let v309_2: Space = singleton(&v308_5_cursor.path()[v308_5_origin..(v308_5_origin + 1)]);
    let v309_3: Space = intersect(&(*CONSTANT_1),&(v309_2));
    let v309_4: Space = if has_head(&(v309_3)) { singleton(&[]) } else { Space::new() };
    drop(v309_3);
    let v309_5: Space = subtract(&(*CONSTANT_0),&(v309_4));
    drop(v309_4);
    let v309_7: Space = if (&(v309_5)).is_empty() { Space::new() } else {
      let mut v310_6 = Space::new();
      let mut v310_6_write = v310_6.write_zipper();
      for v310_6_byte in v308_5_cursor.child_mask().iter() {
        v308_5_cursor.descend_to_existing_byte(v310_6_byte);
        {
        let v311_2: Space = Space::new();
        join_wrapped_into(&mut v310_6_write,&((v311_2).read_zipper()),&[]);
        }
        v308_5_cursor.ascend(1);
      }
      drop(v310_6_write);
      compose(&(v309_5),&(v310_6))
    };
    drop(v309_5);
    let v309_8: Space = intersect(&(*CONSTANT_1),&(v309_2));
    drop(v309_2);
    let v309_9: Space = if has_head(&(v309_8)) { singleton(&[]) } else { Space::new() };
    drop(v309_8);
    let v309_10: Space = compose(&(v309_9),&v308_5_cursor);
    drop(v309_9);
    let v309_11: Space = unite(&(v309_7),&(v309_10));
    drop(v309_7);
    drop(v309_10);
    join_wrapped_into(&mut v308_5_write,&((v309_11).read_zipper()),&[]);
    }
    v308_5_cursor.ascend(1);
  }
  drop(v308_5_cursor);
  drop(v308_5_write);
  (v308_5).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v312_2 = Space::new();
  let mut v312_2_write = v312_2.write_zipper();
  let mut v312_2_cursor = (*s0).read_zipper();
  let v312_2_origin = v312_2_cursor.path().len();
  for v312_2_byte in v312_2_cursor.child_mask().iter() {
    v312_2_cursor.descend_to_existing_byte(v312_2_byte);
    {
    let v313_2: Space = Space::new();
    join_wrapped_into(&mut v312_2_write,&((v313_2).read_zipper()),&[]);
    }
    v312_2_cursor.ascend(1);
  }
  drop(v312_2_cursor);
  drop(v312_2_write);
  (v312_2).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v314_3 = Space::new();
  let mut v314_3_write = v314_3.write_zipper();
  let mut v314_3_cursor = (*s0).read_zipper();
  let v314_3_origin = v314_3_cursor.path().len();
  for v314_3_byte in v314_3_cursor.child_mask().iter() {
    v314_3_cursor.descend_to_existing_byte(v314_3_byte);
    {
    let v315_2: Space = singleton(&v314_3_cursor.path()[v314_3_origin..(v314_3_origin + 1)]);
    let v315_3: Space = intersect(&(*CONSTANT_1),&(v315_2));
    drop(v315_2);
    let v315_4: Space = if has_head(&(v315_3)) { singleton(&[]) } else { Space::new() };
    drop(v315_3);
    let v315_5: Space = compose(&(v315_4),&v314_3_cursor);
    drop(v315_4);
    join_wrapped_into(&mut v314_3_write,&((v315_5).read_zipper()),&[]);
    }
    v314_3_cursor.ascend(1);
  }
  drop(v314_3_cursor);
  drop(v314_3_write);
  (v314_3).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v316_2 = Space::new();
  let mut v316_2_write = v316_2.write_zipper();
  let mut v316_2_cursor = (*s0).read_zipper();
  let v316_2_origin = v316_2_cursor.path().len();
  for v316_2_byte in v316_2_cursor.child_mask().iter() {
    v316_2_cursor.descend_to_existing_byte(v316_2_byte);
    {
    let v317_2: Space = Space::new();
    join_wrapped_into(&mut v316_2_write,&((v317_2).read_zipper()),&[]);
    }
    v316_2_cursor.ascend(1);
  }
  drop(v316_2_cursor);
  drop(v316_2_write);
  (v316_2).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v318_3 = Space::new();
  let mut v318_3_write = v318_3.write_zipper();
  let mut v318_3_cursor = (*s0).read_zipper();
  let v318_3_origin = v318_3_cursor.path().len();
  for v318_3_byte in v318_3_cursor.child_mask().iter() {
    v318_3_cursor.descend_to_existing_byte(v318_3_byte);
    {
    let v319_2: Space = singleton(&v318_3_cursor.path()[v318_3_origin..(v318_3_origin + 1)]);
    let v319_3: Space = intersect(&(*CONSTANT_1),&(v319_2));
    drop(v319_2);
    let v319_4: Space = if has_head(&(v319_3)) { singleton(&[]) } else { Space::new() };
    drop(v319_3);
    let v319_5: Space = compose(&(v319_4),&v318_3_cursor);
    drop(v319_4);
    join_wrapped_into(&mut v318_3_write,&((v319_5).read_zipper()),&[]);
    }
    v318_3_cursor.ascend(1);
  }
  drop(v318_3_cursor);
  drop(v318_3_write);
  (v318_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
