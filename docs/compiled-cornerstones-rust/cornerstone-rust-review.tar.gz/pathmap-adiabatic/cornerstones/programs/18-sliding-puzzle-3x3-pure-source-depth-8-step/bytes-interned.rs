#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("13 28 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 8 0 0 0 4 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 3 0 0 0 6 0 0 0 4 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 2 0 0 0 3 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 3 0 0 0 8 28 0 0 0 2 0 0 0 7 0 0 0 4 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 4 0 0 0 3 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 3 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 5 0 0 0 3 0 0 0 2 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 5 0 0 0 3 0 0 0 2 0 0 0 8 0 0 0 6 0 0 0 4 0 0 0 7"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,9]));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("11 28 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 2 0 0 0 3 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 3 0 0 0 8 28 0 0 0 2 0 0 0 7 0 0 0 4 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 4 0 0 0 3 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 3 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 5 0 0 0 3 0 0 0 2 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 5 0 0 0 3 0 0 0 2 0 0 0 8 0 0 0 6 0 0 0 4 0 0 0 7"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,10]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("17 28 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 2 0 0 0 3 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 0 0 0 4 28 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 4 0 0 0 7 28 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 3 0 0 0 8 28 0 0 0 2 0 0 0 7 0 0 0 4 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 4 0 0 0 3 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 3 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 4 0 0 0 3 0 0 0 8 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 4 0 0 0 6 0 0 0 3 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 4 0 0 0 6 0 0 0 5 0 0 0 2 0 0 0 7 0 0 0 3 0 0 0 8 28 0 0 0 4 0 0 0 7 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 3 0 0 0 2 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 5 0 0 0 3 0 0 0 2 0 0 0 8 0 0 0 6 0 0 0 4 0 0 0 7"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,11]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("11 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 4 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 8 0 0 0 3 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 5 0 0 0 8 0 0 0 3 0 0 0 6 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 3 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 4 0 0 0 3 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,12]));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("17 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 4 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 4 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 8 0 0 0 3 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 4 0 0 0 7 0 0 0 3 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 5 0 0 0 8 0 0 0 3 0 0 0 6 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 3 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 4 0 0 0 3 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 6 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 7 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 7 0 0 0 4 0 0 0 3 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 5"));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,13]));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("10 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 4 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 4 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 3 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 4 0 0 0 3 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_13: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,14]));
static CONSTANT_14: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("13 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 7 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 3 0 0 0 8 0 0 0 4 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 7 0 0 0 6 0 0 0 5 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 5 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 6 0 0 0 5 0 0 0 3 0 0 0 8 28 0 0 0 5 0 0 0 4 0 0 0 3 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 3 0 0 0 2 0 0 0 7 0 0 0 8"));
static CONSTANT_15: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,15]));
static CONSTANT_16: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("9 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 7 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 7 0 0 0 6 0 0 0 5 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 5 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 6 0 0 0 5 0 0 0 3 0 0 0 8 28 0 0 0 5 0 0 0 4 0 0 0 3 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8"));
static CONSTANT_17: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,16]));
static CONSTANT_18: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("13 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 7 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 8 0 0 0 7 0 0 0 6 0 0 0 4 28 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 7 0 0 0 6 0 0 0 5 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 5 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 8 0 0 0 7 0 0 0 3 28 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 5 0 0 0 8 0 0 0 3 0 0 0 6 28 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 6 0 0 0 5 0 0 0 3 0 0 0 8 28 0 0 0 5 0 0 0 4 0 0 0 3 0 0 0 2 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 5 0 0 0 4 0 0 0 3 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8"));
static CONSTANT_19: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,2]));
static CONSTANT_20: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 28 0 0 0 5 0 0 0 1 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 5 0 0 0 1 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 4 0 0 0 7 28 0 0 0 5 0 0 0 1 0 0 0 4 0 0 0 8 0 0 0 3 0 0 0 6 0 0 0 7 28 0 0 0 5 0 0 0 1 0 0 0 7 0 0 0 4 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_21: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 28 0 0 0 5 0 0 0 1 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_22: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 28 0 0 0 3 0 0 0 5 0 0 0 1 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_23: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,3]));
static CONSTANT_24: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("11 28 0 0 0 1 0 0 0 4 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 4 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 6 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 6 0 0 0 5 0 0 0 2 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 2 0 0 0 4 0 0 0 1 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 4 0 0 0 1 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 2 0 0 0 4 0 0 0 1 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 2 0 0 0 6 0 0 0 1 0 0 0 4 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 2 0 0 0 6 0 0 0 1 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 2 0 0 0 7 0 0 0 1 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 4 0 0 0 2 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_25: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("13 28 0 0 0 1 0 0 0 4 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 4 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 4 0 0 0 8 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 1 0 0 0 6 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 6 0 0 0 5 0 0 0 2 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 1 0 0 0 7 0 0 0 5 0 0 0 2 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 4 0 0 0 1 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 4 0 0 0 1 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 2 0 0 0 4 0 0 0 1 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 2 0 0 0 6 0 0 0 1 0 0 0 4 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 2 0 0 0 6 0 0 0 1 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 2 0 0 0 7 0 0 0 1 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 4 0 0 0 2 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_26: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("11 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 1 0 0 0 2 0 0 0 5 0 0 0 8 0 0 0 4 0 0 0 6 0 0 0 7 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 7 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 1 0 0 0 4 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 5 0 0 0 2 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 5 0 0 0 1 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_27: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("17 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 1 0 0 0 2 0 0 0 5 0 0 0 8 0 0 0 4 0 0 0 6 0 0 0 7 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 7 0 0 0 5 0 0 0 4 28 0 0 0 1 0 0 0 2 0 0 0 7 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 1 0 0 0 4 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 5 0 0 0 2 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 1 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 1 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 4 0 0 0 1 0 0 0 6 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 5 0 0 0 1 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 5 0 0 0 1 0 0 0 6 0 0 0 2 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 7 0 0 0 1 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 5"));
static CONSTANT_28: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("9 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 7 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 1 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 5 0 0 0 1 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_29: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("17 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 5 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 8 0 0 0 7 0 0 0 6 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 8 0 0 0 5 0 0 0 7 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 8 0 0 0 7 0 0 0 4 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 4 0 0 0 7 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 7 0 0 0 6 0 0 0 4 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 7 0 0 0 6 0 0 0 5 0 0 0 4 0 0 0 8 28 0 0 0 1 0 0 0 4 0 0 0 6 0 0 0 5 0 0 0 2 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 5 0 0 0 6 0 0 0 2 0 0 0 4 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 1 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 7 0 0 0 1 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 4 0 0 0 1 0 0 0 7 0 0 0 8 28 0 0 0 5 0 0 0 1 0 0 0 4 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 1 0 0 0 6 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 8"));
static CONSTANT_30: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("10 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 5 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 8 0 0 0 7 0 0 0 6 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 8 0 0 0 7 0 0 0 4 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 4 0 0 0 7 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 7 0 0 0 6 0 0 0 5 0 0 0 4 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 1 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 7 0 0 0 1 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 1 0 0 0 4 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8"));
static CONSTANT_31: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("13 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 5 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 8 0 0 0 7 0 0 0 6 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 8 0 0 0 7 0 0 0 4 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 4 0 0 0 7 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 7 0 0 0 5 0 0 0 8 0 0 0 4 0 0 0 6 28 0 0 0 1 0 0 0 2 0 0 0 7 0 0 0 6 0 0 0 5 0 0 0 4 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 1 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 7 0 0 0 1 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 1 0 0 0 8 0 0 0 7 0 0 0 4 28 0 0 0 5 0 0 0 1 0 0 0 4 0 0 0 2 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 5 0 0 0 1 0 0 0 4 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8"));
static CONSTANT_32: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,4]));
static CONSTANT_33: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 28 0 0 0 2 0 0 0 1 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 1 0 0 0 3 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 2 0 0 0 1 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 2 0 0 0 1 0 0 0 5 0 0 0 8 0 0 0 3 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 1 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 3 0 0 0 8 28 0 0 0 2 0 0 0 1 0 0 0 7 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8"));
static CONSTANT_34: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 28 0 0 0 2 0 0 0 1 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 1 0 0 0 7 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8"));
static CONSTANT_35: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 28 0 0 0 2 0 0 0 1 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 1 0 0 0 7 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 3 0 0 0 1 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_36: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 28 0 0 0 3 0 0 0 1 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 3 0 0 0 2 0 0 0 1 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_37: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 28 0 0 0 2 0 0 0 5 0 0 0 1 0 0 0 3 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 3 0 0 0 1 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 3 0 0 0 2 0 0 0 1 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 3 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 1 0 0 0 8 28 0 0 0 7 0 0 0 2 0 0 0 1 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8"));
static CONSTANT_38: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 28 0 0 0 2 0 0 0 5 0 0 0 1 0 0 0 3 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 3 0 0 0 2 0 0 0 1 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_39: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 28 0 0 0 3 0 0 0 1 0 0 0 6 0 0 0 5 0 0 0 2 0 0 0 7 0 0 0 8 28 0 0 0 3 0 0 0 2 0 0 0 1 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 28 0 0 0 3 0 0 0 2 0 0 0 6 0 0 0 1 0 0 0 5 0 0 0 7 0 0 0 8"));
static CONSTANT_40: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 28 0 0 0 3 0 0 0 2 0 0 0 1 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 28 0 0 0 3 0 0 0 2 0 0 0 6 0 0 0 1 0 0 0 5 0 0 0 7 0 0 0 8"));
static CONSTANT_41: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 28 0 0 0 2 0 0 0 5 0 0 0 1 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 3 0 0 0 2 0 0 0 1 0 0 0 5 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 3 0 0 0 2 0 0 0 1 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 28 0 0 0 3 0 0 0 2 0 0 0 6 0 0 0 1 0 0 0 5 0 0 0 7 0 0 0 8"));
static CONSTANT_42: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,5]));
static CONSTANT_43: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 28 0 0 0 1 0 0 0 3 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 1 0 0 0 3 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_44: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,6]));
static CONSTANT_45: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 28 0 0 0 3 0 0 0 2 0 0 0 1 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8"));
static CONSTANT_46: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 28 0 0 0 3 0 0 0 2 0 0 0 7 0 0 0 1 0 0 0 5 0 0 0 4 0 0 0 8"));
static CONSTANT_47: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 0"));
static CONSTANT_48: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 9"));
static CONSTANT_49: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 10"));
static CONSTANT_50: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 11"));
static CONSTANT_51: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 12"));
static CONSTANT_52: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 13"));
static CONSTANT_53: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 14"));
static CONSTANT_54: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 15"));
static CONSTANT_55: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 16"));
static CONSTANT_56: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,17]));
static CONSTANT_57: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 0 0 0 0 11 8 0 0 0 11 0 0 0 0"));
static CONSTANT_58: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 9 0 0 0 12 8 0 0 0 12 0 0 0 9"));
static CONSTANT_59: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 10 0 0 0 13 8 0 0 0 13 0 0 0 10"));
static CONSTANT_60: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 11 0 0 0 14 8 0 0 0 14 0 0 0 11"));
static CONSTANT_61: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 12 0 0 0 15 8 0 0 0 15 0 0 0 12"));
static CONSTANT_62: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 13 0 0 0 16 8 0 0 0 16 0 0 0 13"));
static CONSTANT_63: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,18]));
static CONSTANT_64: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 0 0 0 0 9 8 0 0 0 9 0 0 0 0"));
static CONSTANT_65: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 9 0 0 0 10 8 0 0 0 10 0 0 0 9"));
static CONSTANT_66: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 11 0 0 0 12 8 0 0 0 12 0 0 0 11"));
static CONSTANT_67: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 12 0 0 0 13 8 0 0 0 13 0 0 0 12"));
static CONSTANT_68: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 14 0 0 0 15 8 0 0 0 15 0 0 0 14"));
static CONSTANT_69: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 15 0 0 0 16 8 0 0 0 16 0 0 0 15"));
static CONSTANT_70: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,19]));
static CONSTANT_71: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,20]));
static CONSTANT_72: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("9 8 0 0 0 0 0 0 0 0 8 0 0 0 9 0 0 0 9 8 0 0 0 10 0 0 0 10 8 0 0 0 11 0 0 0 11 8 0 0 0 12 0 0 0 12 8 0 0 0 13 0 0 0 13 8 0 0 0 14 0 0 0 14 8 0 0 0 15 0 0 0 15 8 0 0 0 16 0 0 0 16"));
static CONSTANT_73: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 0 0 0 0 21"));
static CONSTANT_74: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 9 0 0 0 21"));
static CONSTANT_75: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 10 0 0 0 21"));
static CONSTANT_76: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 11 0 0 0 21"));
static CONSTANT_77: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 12 0 0 0 21"));
static CONSTANT_78: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 13 0 0 0 21"));
static CONSTANT_79: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 14 0 0 0 21"));
static CONSTANT_80: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 15 0 0 0 21"));
static CONSTANT_81: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 16 0 0 0 21"));
fn routine_0(c: &mut Context) -> Space {
  let v0_3: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
  let v0_6: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
  let v0_7: Space = unite(&(v0_3),&(v0_6));
  let v0_10: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
  let v0_11: Space = unite(&(v0_7),&(v0_10));
  let v0_14: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
  let v0_15: Space = unite(&(v0_11),&(v0_14));
  let v0_18: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_9), &((*CONSTANT_10).read_zipper()));
  let v0_19: Space = unite(&(v0_15),&(v0_18));
  let v0_22: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_11), &((*CONSTANT_12).read_zipper()));
  let v0_23: Space = unite(&(v0_19),&(v0_22));
  let v0_26: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_13), &((*CONSTANT_14).read_zipper()));
  let v0_27: Space = unite(&(v0_23),&(v0_26));
  let v0_30: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_15), &((*CONSTANT_16).read_zipper()));
  let v0_31: Space = unite(&(v0_27),&(v0_30));
  let v0_34: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_17), &((*CONSTANT_18).read_zipper()));
  let v0_35: Space = unite(&(v0_31),&(v0_34));
  let v0_38: Space = routine_1(c, &(*CONSTANT_19), &(*CONSTANT_1), &((*CONSTANT_20).read_zipper()));
  let v0_39: Space = unite(&(v0_35),&(v0_38));
  let v0_41: Space = routine_1(c, &(*CONSTANT_19), &(*CONSTANT_3), &((*CONSTANT_21).read_zipper()));
  let v0_42: Space = unite(&(v0_39),&(v0_41));
  let v0_44: Space = routine_1(c, &(*CONSTANT_19), &(*CONSTANT_5), &((*CONSTANT_21).read_zipper()));
  let v0_45: Space = unite(&(v0_42),&(v0_44));
  let v0_47: Space = routine_1(c, &(*CONSTANT_19), &(*CONSTANT_9), &((*CONSTANT_22).read_zipper()));
  let v0_48: Space = unite(&(v0_45),&(v0_47));
  let v0_51: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_1), &((*CONSTANT_24).read_zipper()));
  let v0_52: Space = unite(&(v0_48),&(v0_51));
  let v0_54: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_3), &((*CONSTANT_24).read_zipper()));
  let v0_55: Space = unite(&(v0_52),&(v0_54));
  let v0_57: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_5), &((*CONSTANT_25).read_zipper()));
  let v0_58: Space = unite(&(v0_55),&(v0_57));
  let v0_60: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_7), &((*CONSTANT_26).read_zipper()));
  let v0_61: Space = unite(&(v0_58),&(v0_60));
  let v0_63: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_9), &((*CONSTANT_27).read_zipper()));
  let v0_64: Space = unite(&(v0_61),&(v0_63));
  let v0_66: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_11), &((*CONSTANT_28).read_zipper()));
  let v0_67: Space = unite(&(v0_64),&(v0_66));
  let v0_69: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_13), &((*CONSTANT_29).read_zipper()));
  let v0_70: Space = unite(&(v0_67),&(v0_69));
  let v0_72: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_15), &((*CONSTANT_30).read_zipper()));
  let v0_73: Space = unite(&(v0_70),&(v0_72));
  let v0_75: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_17), &((*CONSTANT_31).read_zipper()));
  let v0_76: Space = unite(&(v0_73),&(v0_75));
  let v0_79: Space = routine_1(c, &(*CONSTANT_32), &(*CONSTANT_1), &((*CONSTANT_33).read_zipper()));
  let v0_80: Space = unite(&(v0_76),&(v0_79));
  let v0_82: Space = routine_1(c, &(*CONSTANT_32), &(*CONSTANT_3), &((*CONSTANT_34).read_zipper()));
  let v0_83: Space = unite(&(v0_80),&(v0_82));
  let v0_85: Space = routine_1(c, &(*CONSTANT_32), &(*CONSTANT_5), &((*CONSTANT_35).read_zipper()));
  let v0_86: Space = unite(&(v0_83),&(v0_85));
  let v0_88: Space = routine_1(c, &(*CONSTANT_32), &(*CONSTANT_7), &((*CONSTANT_36).read_zipper()));
  let v0_89: Space = unite(&(v0_86),&(v0_88));
  let v0_91: Space = routine_1(c, &(*CONSTANT_32), &(*CONSTANT_9), &((*CONSTANT_37).read_zipper()));
  let v0_92: Space = unite(&(v0_89),&(v0_91));
  let v0_94: Space = routine_1(c, &(*CONSTANT_32), &(*CONSTANT_11), &((*CONSTANT_38).read_zipper()));
  let v0_95: Space = unite(&(v0_92),&(v0_94));
  let v0_97: Space = routine_1(c, &(*CONSTANT_32), &(*CONSTANT_13), &((*CONSTANT_39).read_zipper()));
  let v0_98: Space = unite(&(v0_95),&(v0_97));
  let v0_100: Space = routine_1(c, &(*CONSTANT_32), &(*CONSTANT_15), &((*CONSTANT_40).read_zipper()));
  let v0_101: Space = unite(&(v0_98),&(v0_100));
  let v0_103: Space = routine_1(c, &(*CONSTANT_32), &(*CONSTANT_17), &((*CONSTANT_41).read_zipper()));
  let v0_104: Space = unite(&(v0_101),&(v0_103));
  let v0_107: Space = routine_1(c, &(*CONSTANT_42), &(*CONSTANT_1), &((*CONSTANT_43).read_zipper()));
  let v0_108: Space = unite(&(v0_104),&(v0_107));
  let v0_111: Space = routine_1(c, &(*CONSTANT_44), &(*CONSTANT_7), &((*CONSTANT_45).read_zipper()));
  let v0_112: Space = unite(&(v0_108),&(v0_111));
  let v0_114: Space = routine_1(c, &(*CONSTANT_44), &(*CONSTANT_9), &((*CONSTANT_45).read_zipper()));
  let v0_115: Space = unite(&(v0_112),&(v0_114));
  let v0_117: Space = routine_1(c, &(*CONSTANT_44), &(*CONSTANT_13), &((*CONSTANT_46).read_zipper()));
  let v0_118: Space = unite(&(v0_115),&(v0_117));
  (v0_118).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1_3 = Space::new();
  let mut v1_3_write = v1_3.write_zipper();
  let mut v1_3_cursor = (*s0).read_zipper();
  let v1_3_origin = v1_3_cursor.path().len();
  for v1_3_byte in v1_3_cursor.child_mask().iter() {
    v1_3_cursor.descend_to_existing_byte(v1_3_byte);
    {
    for v2_2_byte in v1_3_cursor.child_mask().iter() {
      v1_3_cursor.descend_to_existing_byte(v2_2_byte);
      {
      for v3_3_byte in v1_3_cursor.child_mask().iter() {
        v1_3_cursor.descend_to_existing_byte(v3_3_byte);
        {
        for v4_3_byte in v1_3_cursor.child_mask().iter() {
          v1_3_cursor.descend_to_existing_byte(v4_3_byte);
          {
          for v5_3_byte in v1_3_cursor.child_mask().iter() {
            v1_3_cursor.descend_to_existing_byte(v5_3_byte);
            {
            for v6_2_byte in v1_3_cursor.child_mask().iter() {
              v1_3_cursor.descend_to_existing_byte(v6_2_byte);
              {
              for v7_3_byte in v1_3_cursor.child_mask().iter() {
                v1_3_cursor.descend_to_existing_byte(v7_3_byte);
                {
                for v8_3_byte in v1_3_cursor.child_mask().iter() {
                  v1_3_cursor.descend_to_existing_byte(v8_3_byte);
                  {
                  let v9_3: Space = routine_2(c, &v1_3_cursor.path()[(v1_3_origin + 4)..(v1_3_origin + 8)], &(*p1), &(*p0), &v1_3_cursor.path()[v1_3_origin..(v1_3_origin + 4)], &v1_3_cursor);
                  join_wrapped_into(&mut v1_3_write,&((v9_3).read_zipper()),&[]);
                  }
                  v1_3_cursor.ascend(1);
                }
                }
                v1_3_cursor.ascend(1);
              }
              }
              v1_3_cursor.ascend(1);
            }
            }
            v1_3_cursor.ascend(1);
          }
          }
          v1_3_cursor.ascend(1);
        }
        }
        v1_3_cursor.ascend(1);
      }
      }
      v1_3_cursor.ascend(1);
    }
    }
    v1_3_cursor.ascend(1);
  }
  drop(v1_3_cursor);
  drop(v1_3_write);
  (v1_3).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v10_5 = Space::new();
  let mut v10_5_write = v10_5.write_zipper();
  let mut v10_5_cursor = (*s0).read_zipper();
  let v10_5_origin = v10_5_cursor.path().len();
  for v10_5_byte in v10_5_cursor.child_mask().iter() {
    v10_5_cursor.descend_to_existing_byte(v10_5_byte);
    {
    for v11_2_byte in v10_5_cursor.child_mask().iter() {
      v10_5_cursor.descend_to_existing_byte(v11_2_byte);
      {
      for v12_3_byte in v10_5_cursor.child_mask().iter() {
        v10_5_cursor.descend_to_existing_byte(v12_3_byte);
        {
        for v13_3_byte in v10_5_cursor.child_mask().iter() {
          v10_5_cursor.descend_to_existing_byte(v13_3_byte);
          {
          for v14_3_byte in v10_5_cursor.child_mask().iter() {
            v10_5_cursor.descend_to_existing_byte(v14_3_byte);
            {
            for v15_2_byte in v10_5_cursor.child_mask().iter() {
              v10_5_cursor.descend_to_existing_byte(v15_2_byte);
              {
              for v16_3_byte in v10_5_cursor.child_mask().iter() {
                v10_5_cursor.descend_to_existing_byte(v16_3_byte);
                {
                for v17_3_byte in v10_5_cursor.child_mask().iter() {
                  v10_5_cursor.descend_to_existing_byte(v17_3_byte);
                  {
                  let v18_3: Space = routine_3(c, &v10_5_cursor.path()[(v10_5_origin + 4)..(v10_5_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p0), &v10_5_cursor.path()[v10_5_origin..(v10_5_origin + 4)], &v10_5_cursor);
                  join_wrapped_into(&mut v10_5_write,&((v18_3).read_zipper()),&[]);
                  }
                  v10_5_cursor.ascend(1);
                }
                }
                v10_5_cursor.ascend(1);
              }
              }
              v10_5_cursor.ascend(1);
            }
            }
            v10_5_cursor.ascend(1);
          }
          }
          v10_5_cursor.ascend(1);
        }
        }
        v10_5_cursor.ascend(1);
      }
      }
      v10_5_cursor.ascend(1);
    }
    }
    v10_5_cursor.ascend(1);
  }
  drop(v10_5_cursor);
  drop(v10_5_write);
  (v10_5).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v19_7 = Space::new();
  let mut v19_7_write = v19_7.write_zipper();
  let mut v19_7_cursor = (*s0).read_zipper();
  let v19_7_origin = v19_7_cursor.path().len();
  for v19_7_byte in v19_7_cursor.child_mask().iter() {
    v19_7_cursor.descend_to_existing_byte(v19_7_byte);
    {
    for v20_2_byte in v19_7_cursor.child_mask().iter() {
      v19_7_cursor.descend_to_existing_byte(v20_2_byte);
      {
      for v21_3_byte in v19_7_cursor.child_mask().iter() {
        v19_7_cursor.descend_to_existing_byte(v21_3_byte);
        {
        for v22_3_byte in v19_7_cursor.child_mask().iter() {
          v19_7_cursor.descend_to_existing_byte(v22_3_byte);
          {
          for v23_3_byte in v19_7_cursor.child_mask().iter() {
            v19_7_cursor.descend_to_existing_byte(v23_3_byte);
            {
            for v24_2_byte in v19_7_cursor.child_mask().iter() {
              v19_7_cursor.descend_to_existing_byte(v24_2_byte);
              {
              for v25_3_byte in v19_7_cursor.child_mask().iter() {
                v19_7_cursor.descend_to_existing_byte(v25_3_byte);
                {
                for v26_3_byte in v19_7_cursor.child_mask().iter() {
                  v19_7_cursor.descend_to_existing_byte(v26_3_byte);
                  {
                  let v27_3: Space = routine_4(c, &v19_7_cursor.path()[(v19_7_origin + 4)..(v19_7_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v19_7_cursor.path()[v19_7_origin..(v19_7_origin + 4)], &v19_7_cursor);
                  join_wrapped_into(&mut v19_7_write,&((v27_3).read_zipper()),&[]);
                  }
                  v19_7_cursor.ascend(1);
                }
                }
                v19_7_cursor.ascend(1);
              }
              }
              v19_7_cursor.ascend(1);
            }
            }
            v19_7_cursor.ascend(1);
          }
          }
          v19_7_cursor.ascend(1);
        }
        }
        v19_7_cursor.ascend(1);
      }
      }
      v19_7_cursor.ascend(1);
    }
    }
    v19_7_cursor.ascend(1);
  }
  drop(v19_7_cursor);
  drop(v19_7_write);
  (v19_7).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v28_9: Path = concat_path(&(*p2),&(*p3));
  let v28_10: Path = concat_path(&(v28_9),&(*p4));
  drop(v28_9);
  let v28_11: Path = concat_path(&(v28_10),&(*p5));
  drop(v28_10);
  let v28_12: Path = concat_path(&(v28_11),&(*p6));
  drop(v28_11);
  let v28_13: Path = concat_path(&(v28_12),&(*p7));
  drop(v28_12);
  let v28_14: Path = concat_path(&(v28_13),&(*p0));
  drop(v28_13);
  let mut v28_15 = Space::new();
  let mut v28_15_write = v28_15.write_zipper();
  let mut v28_15_cursor = (*s0).read_zipper();
  let v28_15_origin = v28_15_cursor.path().len();
  for v28_15_byte in v28_15_cursor.child_mask().iter() {
    v28_15_cursor.descend_to_existing_byte(v28_15_byte);
    {
    for v29_2_byte in v28_15_cursor.child_mask().iter() {
      v28_15_cursor.descend_to_existing_byte(v29_2_byte);
      {
      for v30_3_byte in v28_15_cursor.child_mask().iter() {
        v28_15_cursor.descend_to_existing_byte(v30_3_byte);
        {
        for v31_3_byte in v28_15_cursor.child_mask().iter() {
          v28_15_cursor.descend_to_existing_byte(v31_3_byte);
          {
          let v32_3: Path = concat_path(&(v28_14),&v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 4)]);
          let v32_4: Space = singleton(&(v32_3));
          drop(v32_3);
          let v32_5: Space = routine_5(c, &(*p1), &((v32_4).read_zipper()));
          drop(v32_4);
          let mut v32_6 = Space::new();
          let mut v32_6_write = v32_6.write_zipper();
          let mut v32_6_cursor = (v32_5).read_zipper();
          let v32_6_origin = v32_6_cursor.path().len();
          for v32_6_byte in v32_6_cursor.child_mask().iter() {
            v32_6_cursor.descend_to_existing_byte(v32_6_byte);
            {
            for v33_2_byte in v32_6_cursor.child_mask().iter() {
              v32_6_cursor.descend_to_existing_byte(v33_2_byte);
              {
              for v34_3_byte in v32_6_cursor.child_mask().iter() {
                v32_6_cursor.descend_to_existing_byte(v34_3_byte);
                {
                for v35_3_byte in v32_6_cursor.child_mask().iter() {
                  v32_6_cursor.descend_to_existing_byte(v35_3_byte);
                  {
                  let v36_3: Space = routine_6(c, &v32_6_cursor.path()[v32_6_origin..(v32_6_origin + 4)], &(*p1), &v32_6_cursor);
                  join_wrapped_into(&mut v32_6_write,&((v36_3).read_zipper()),&[]);
                  }
                  v32_6_cursor.ascend(1);
                }
                }
                v32_6_cursor.ascend(1);
              }
              }
              v32_6_cursor.ascend(1);
            }
            }
            v32_6_cursor.ascend(1);
          }
          drop(v32_6_cursor);
          drop(v32_6_write);
          let mut v32_7_cursor = (v32_6).read_zipper();
          let v32_7_origin = v32_7_cursor.path().len();
          for v32_7_byte in v32_7_cursor.child_mask().iter() {
            v32_7_cursor.descend_to_existing_byte(v32_7_byte);
            {
            for v37_2_byte in v32_7_cursor.child_mask().iter() {
              v32_7_cursor.descend_to_existing_byte(v37_2_byte);
              {
              for v38_3_byte in v32_7_cursor.child_mask().iter() {
                v32_7_cursor.descend_to_existing_byte(v38_3_byte);
                {
                for v39_3_byte in v32_7_cursor.child_mask().iter() {
                  v32_7_cursor.descend_to_existing_byte(v39_3_byte);
                  {
                  let v40_3: Space = routine_7(c, &v32_7_cursor.path()[v32_7_origin..(v32_7_origin + 4)], &(*p1), &v32_7_cursor);
                  join_wrapped_into(&mut v28_15_write,&((v40_3).read_zipper()),&[]);
                  }
                  v32_7_cursor.ascend(1);
                }
                }
                v32_7_cursor.ascend(1);
              }
              }
              v32_7_cursor.ascend(1);
            }
            }
            v32_7_cursor.ascend(1);
          }
          drop(v32_7_cursor);
          }
          v28_15_cursor.ascend(1);
        }
        }
        v28_15_cursor.ascend(1);
      }
      }
      v28_15_cursor.ascend(1);
    }
    }
    v28_15_cursor.ascend(1);
  }
  drop(v28_15_cursor);
  drop(v28_15_write);
  drop(v28_14);
  (v28_15).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v41_3: Space = singleton(&(*p0));
  let v41_4: Space = intersect(&(*CONSTANT_47),&(v41_3));
  let mut v41_5 = Space::new();
  let mut v41_5_write = v41_5.write_zipper();
  let mut v41_5_cursor = (v41_4).read_zipper();
  let v41_5_origin = v41_5_cursor.path().len();
  for v41_5_byte in v41_5_cursor.child_mask().iter() {
    v41_5_cursor.descend_to_existing_byte(v41_5_byte);
    {
    for v42_2_byte in v41_5_cursor.child_mask().iter() {
      v41_5_cursor.descend_to_existing_byte(v42_2_byte);
      {
      for v43_2_byte in v41_5_cursor.child_mask().iter() {
        v41_5_cursor.descend_to_existing_byte(v43_2_byte);
        {
        join_tails_into(&mut v41_5_write,&mut v41_5_cursor);
        }
        v41_5_cursor.ascend(1);
      }
      }
      v41_5_cursor.ascend(1);
    }
    }
    v41_5_cursor.ascend(1);
  }
  drop(v41_5_cursor);
  drop(v41_5_write);
  drop(v41_4);
  let v41_7: Space = if (&(v41_5)).is_empty() { Space::new() } else {
    let mut v45_6 = Space::new();
    let mut v45_6_write = v45_6.write_zipper();
    let mut v45_6_cursor = (*s0).read_zipper();
    let v45_6_origin = v45_6_cursor.path().len();
    for v45_6_byte in v45_6_cursor.child_mask().iter() {
      v45_6_cursor.descend_to_existing_byte(v45_6_byte);
      {
      for v46_2_byte in v45_6_cursor.child_mask().iter() {
        v45_6_cursor.descend_to_existing_byte(v46_2_byte);
        {
        for v47_3_byte in v45_6_cursor.child_mask().iter() {
          v45_6_cursor.descend_to_existing_byte(v47_3_byte);
          {
          for v48_3_byte in v45_6_cursor.child_mask().iter() {
            v45_6_cursor.descend_to_existing_byte(v48_3_byte);
            {
            for v49_3_byte in v45_6_cursor.child_mask().iter() {
              v45_6_cursor.descend_to_existing_byte(v49_3_byte);
              {
              for v50_2_byte in v45_6_cursor.child_mask().iter() {
                v45_6_cursor.descend_to_existing_byte(v50_2_byte);
                {
                for v51_3_byte in v45_6_cursor.child_mask().iter() {
                  v45_6_cursor.descend_to_existing_byte(v51_3_byte);
                  {
                  for v52_3_byte in v45_6_cursor.child_mask().iter() {
                    v45_6_cursor.descend_to_existing_byte(v52_3_byte);
                    {
                    let v53_3: Space = routine_8(c, &v45_6_cursor.path()[(v45_6_origin + 4)..(v45_6_origin + 8)], &v45_6_cursor.path()[v45_6_origin..(v45_6_origin + 4)], &v45_6_cursor);
                    join_wrapped_into(&mut v45_6_write,&((v53_3).read_zipper()),&[]);
                    }
                    v45_6_cursor.ascend(1);
                  }
                  }
                  v45_6_cursor.ascend(1);
                }
                }
                v45_6_cursor.ascend(1);
              }
              }
              v45_6_cursor.ascend(1);
            }
            }
            v45_6_cursor.ascend(1);
          }
          }
          v45_6_cursor.ascend(1);
        }
        }
        v45_6_cursor.ascend(1);
      }
      }
      v45_6_cursor.ascend(1);
    }
    drop(v45_6_cursor);
    drop(v45_6_write);
    compose(&(v41_5),&(v45_6))
  };
  drop(v41_5);
  let v41_9: Space = intersect(&(*CONSTANT_48),&(v41_3));
  let mut v41_10 = Space::new();
  let mut v41_10_write = v41_10.write_zipper();
  let mut v41_10_cursor = (v41_9).read_zipper();
  let v41_10_origin = v41_10_cursor.path().len();
  for v41_10_byte in v41_10_cursor.child_mask().iter() {
    v41_10_cursor.descend_to_existing_byte(v41_10_byte);
    {
    for v54_2_byte in v41_10_cursor.child_mask().iter() {
      v41_10_cursor.descend_to_existing_byte(v54_2_byte);
      {
      for v55_2_byte in v41_10_cursor.child_mask().iter() {
        v41_10_cursor.descend_to_existing_byte(v55_2_byte);
        {
        join_tails_into(&mut v41_10_write,&mut v41_10_cursor);
        }
        v41_10_cursor.ascend(1);
      }
      }
      v41_10_cursor.ascend(1);
    }
    }
    v41_10_cursor.ascend(1);
  }
  drop(v41_10_cursor);
  drop(v41_10_write);
  drop(v41_9);
  let v41_12: Space = if (&(v41_10)).is_empty() { Space::new() } else {
    let mut v57_11 = Space::new();
    let mut v57_11_write = v57_11.write_zipper();
    let mut v57_11_cursor = (*s0).read_zipper();
    let v57_11_origin = v57_11_cursor.path().len();
    for v57_11_byte in v57_11_cursor.child_mask().iter() {
      v57_11_cursor.descend_to_existing_byte(v57_11_byte);
      {
      for v58_2_byte in v57_11_cursor.child_mask().iter() {
        v57_11_cursor.descend_to_existing_byte(v58_2_byte);
        {
        for v59_3_byte in v57_11_cursor.child_mask().iter() {
          v57_11_cursor.descend_to_existing_byte(v59_3_byte);
          {
          for v60_3_byte in v57_11_cursor.child_mask().iter() {
            v57_11_cursor.descend_to_existing_byte(v60_3_byte);
            {
            for v61_3_byte in v57_11_cursor.child_mask().iter() {
              v57_11_cursor.descend_to_existing_byte(v61_3_byte);
              {
              for v62_2_byte in v57_11_cursor.child_mask().iter() {
                v57_11_cursor.descend_to_existing_byte(v62_2_byte);
                {
                for v63_3_byte in v57_11_cursor.child_mask().iter() {
                  v57_11_cursor.descend_to_existing_byte(v63_3_byte);
                  {
                  for v64_3_byte in v57_11_cursor.child_mask().iter() {
                    v57_11_cursor.descend_to_existing_byte(v64_3_byte);
                    {
                    let v65_3: Space = routine_9(c, &v57_11_cursor.path()[(v57_11_origin + 4)..(v57_11_origin + 8)], &v57_11_cursor.path()[v57_11_origin..(v57_11_origin + 4)], &v57_11_cursor);
                    join_wrapped_into(&mut v57_11_write,&((v65_3).read_zipper()),&[]);
                    }
                    v57_11_cursor.ascend(1);
                  }
                  }
                  v57_11_cursor.ascend(1);
                }
                }
                v57_11_cursor.ascend(1);
              }
              }
              v57_11_cursor.ascend(1);
            }
            }
            v57_11_cursor.ascend(1);
          }
          }
          v57_11_cursor.ascend(1);
        }
        }
        v57_11_cursor.ascend(1);
      }
      }
      v57_11_cursor.ascend(1);
    }
    drop(v57_11_cursor);
    drop(v57_11_write);
    compose(&(v41_10),&(v57_11))
  };
  drop(v41_10);
  let v41_13: Space = unite(&(v41_7),&(v41_12));
  let v41_15: Space = intersect(&(*CONSTANT_49),&(v41_3));
  let mut v41_16 = Space::new();
  let mut v41_16_write = v41_16.write_zipper();
  let mut v41_16_cursor = (v41_15).read_zipper();
  let v41_16_origin = v41_16_cursor.path().len();
  for v41_16_byte in v41_16_cursor.child_mask().iter() {
    v41_16_cursor.descend_to_existing_byte(v41_16_byte);
    {
    for v66_2_byte in v41_16_cursor.child_mask().iter() {
      v41_16_cursor.descend_to_existing_byte(v66_2_byte);
      {
      for v67_2_byte in v41_16_cursor.child_mask().iter() {
        v41_16_cursor.descend_to_existing_byte(v67_2_byte);
        {
        join_tails_into(&mut v41_16_write,&mut v41_16_cursor);
        }
        v41_16_cursor.ascend(1);
      }
      }
      v41_16_cursor.ascend(1);
    }
    }
    v41_16_cursor.ascend(1);
  }
  drop(v41_16_cursor);
  drop(v41_16_write);
  drop(v41_15);
  let v41_18: Space = if (&(v41_16)).is_empty() { Space::new() } else {
    let mut v69_17 = Space::new();
    let mut v69_17_write = v69_17.write_zipper();
    let mut v69_17_cursor = (*s0).read_zipper();
    let v69_17_origin = v69_17_cursor.path().len();
    for v69_17_byte in v69_17_cursor.child_mask().iter() {
      v69_17_cursor.descend_to_existing_byte(v69_17_byte);
      {
      for v70_2_byte in v69_17_cursor.child_mask().iter() {
        v69_17_cursor.descend_to_existing_byte(v70_2_byte);
        {
        for v71_3_byte in v69_17_cursor.child_mask().iter() {
          v69_17_cursor.descend_to_existing_byte(v71_3_byte);
          {
          for v72_3_byte in v69_17_cursor.child_mask().iter() {
            v69_17_cursor.descend_to_existing_byte(v72_3_byte);
            {
            for v73_3_byte in v69_17_cursor.child_mask().iter() {
              v69_17_cursor.descend_to_existing_byte(v73_3_byte);
              {
              for v74_2_byte in v69_17_cursor.child_mask().iter() {
                v69_17_cursor.descend_to_existing_byte(v74_2_byte);
                {
                for v75_3_byte in v69_17_cursor.child_mask().iter() {
                  v69_17_cursor.descend_to_existing_byte(v75_3_byte);
                  {
                  for v76_3_byte in v69_17_cursor.child_mask().iter() {
                    v69_17_cursor.descend_to_existing_byte(v76_3_byte);
                    {
                    let v77_3: Space = routine_10(c, &v69_17_cursor.path()[(v69_17_origin + 4)..(v69_17_origin + 8)], &v69_17_cursor.path()[v69_17_origin..(v69_17_origin + 4)], &v69_17_cursor);
                    join_wrapped_into(&mut v69_17_write,&((v77_3).read_zipper()),&[]);
                    }
                    v69_17_cursor.ascend(1);
                  }
                  }
                  v69_17_cursor.ascend(1);
                }
                }
                v69_17_cursor.ascend(1);
              }
              }
              v69_17_cursor.ascend(1);
            }
            }
            v69_17_cursor.ascend(1);
          }
          }
          v69_17_cursor.ascend(1);
        }
        }
        v69_17_cursor.ascend(1);
      }
      }
      v69_17_cursor.ascend(1);
    }
    drop(v69_17_cursor);
    drop(v69_17_write);
    compose(&(v41_16),&(v69_17))
  };
  drop(v41_16);
  let v41_19: Space = unite(&(v41_13),&(v41_18));
  let v41_21: Space = intersect(&(*CONSTANT_50),&(v41_3));
  let mut v41_22 = Space::new();
  let mut v41_22_write = v41_22.write_zipper();
  let mut v41_22_cursor = (v41_21).read_zipper();
  let v41_22_origin = v41_22_cursor.path().len();
  for v41_22_byte in v41_22_cursor.child_mask().iter() {
    v41_22_cursor.descend_to_existing_byte(v41_22_byte);
    {
    for v78_2_byte in v41_22_cursor.child_mask().iter() {
      v41_22_cursor.descend_to_existing_byte(v78_2_byte);
      {
      for v79_2_byte in v41_22_cursor.child_mask().iter() {
        v41_22_cursor.descend_to_existing_byte(v79_2_byte);
        {
        join_tails_into(&mut v41_22_write,&mut v41_22_cursor);
        }
        v41_22_cursor.ascend(1);
      }
      }
      v41_22_cursor.ascend(1);
    }
    }
    v41_22_cursor.ascend(1);
  }
  drop(v41_22_cursor);
  drop(v41_22_write);
  drop(v41_21);
  let v41_24: Space = if (&(v41_22)).is_empty() { Space::new() } else {
    let mut v81_23 = Space::new();
    let mut v81_23_write = v81_23.write_zipper();
    let mut v81_23_cursor = (*s0).read_zipper();
    let v81_23_origin = v81_23_cursor.path().len();
    for v81_23_byte in v81_23_cursor.child_mask().iter() {
      v81_23_cursor.descend_to_existing_byte(v81_23_byte);
      {
      for v82_2_byte in v81_23_cursor.child_mask().iter() {
        v81_23_cursor.descend_to_existing_byte(v82_2_byte);
        {
        for v83_3_byte in v81_23_cursor.child_mask().iter() {
          v81_23_cursor.descend_to_existing_byte(v83_3_byte);
          {
          for v84_3_byte in v81_23_cursor.child_mask().iter() {
            v81_23_cursor.descend_to_existing_byte(v84_3_byte);
            {
            for v85_3_byte in v81_23_cursor.child_mask().iter() {
              v81_23_cursor.descend_to_existing_byte(v85_3_byte);
              {
              for v86_2_byte in v81_23_cursor.child_mask().iter() {
                v81_23_cursor.descend_to_existing_byte(v86_2_byte);
                {
                for v87_3_byte in v81_23_cursor.child_mask().iter() {
                  v81_23_cursor.descend_to_existing_byte(v87_3_byte);
                  {
                  for v88_3_byte in v81_23_cursor.child_mask().iter() {
                    v81_23_cursor.descend_to_existing_byte(v88_3_byte);
                    {
                    let v89_3: Space = routine_11(c, &v81_23_cursor.path()[(v81_23_origin + 4)..(v81_23_origin + 8)], &v81_23_cursor.path()[v81_23_origin..(v81_23_origin + 4)], &v81_23_cursor);
                    join_wrapped_into(&mut v81_23_write,&((v89_3).read_zipper()),&[]);
                    }
                    v81_23_cursor.ascend(1);
                  }
                  }
                  v81_23_cursor.ascend(1);
                }
                }
                v81_23_cursor.ascend(1);
              }
              }
              v81_23_cursor.ascend(1);
            }
            }
            v81_23_cursor.ascend(1);
          }
          }
          v81_23_cursor.ascend(1);
        }
        }
        v81_23_cursor.ascend(1);
      }
      }
      v81_23_cursor.ascend(1);
    }
    drop(v81_23_cursor);
    drop(v81_23_write);
    compose(&(v41_22),&(v81_23))
  };
  drop(v41_22);
  let v41_25: Space = unite(&(v41_19),&(v41_24));
  let v41_27: Space = intersect(&(*CONSTANT_51),&(v41_3));
  let mut v41_28 = Space::new();
  let mut v41_28_write = v41_28.write_zipper();
  let mut v41_28_cursor = (v41_27).read_zipper();
  let v41_28_origin = v41_28_cursor.path().len();
  for v41_28_byte in v41_28_cursor.child_mask().iter() {
    v41_28_cursor.descend_to_existing_byte(v41_28_byte);
    {
    for v90_2_byte in v41_28_cursor.child_mask().iter() {
      v41_28_cursor.descend_to_existing_byte(v90_2_byte);
      {
      for v91_2_byte in v41_28_cursor.child_mask().iter() {
        v41_28_cursor.descend_to_existing_byte(v91_2_byte);
        {
        join_tails_into(&mut v41_28_write,&mut v41_28_cursor);
        }
        v41_28_cursor.ascend(1);
      }
      }
      v41_28_cursor.ascend(1);
    }
    }
    v41_28_cursor.ascend(1);
  }
  drop(v41_28_cursor);
  drop(v41_28_write);
  drop(v41_27);
  let v41_30: Space = if (&(v41_28)).is_empty() { Space::new() } else {
    let mut v93_29 = Space::new();
    let mut v93_29_write = v93_29.write_zipper();
    let mut v93_29_cursor = (*s0).read_zipper();
    let v93_29_origin = v93_29_cursor.path().len();
    for v93_29_byte in v93_29_cursor.child_mask().iter() {
      v93_29_cursor.descend_to_existing_byte(v93_29_byte);
      {
      for v94_2_byte in v93_29_cursor.child_mask().iter() {
        v93_29_cursor.descend_to_existing_byte(v94_2_byte);
        {
        for v95_3_byte in v93_29_cursor.child_mask().iter() {
          v93_29_cursor.descend_to_existing_byte(v95_3_byte);
          {
          for v96_3_byte in v93_29_cursor.child_mask().iter() {
            v93_29_cursor.descend_to_existing_byte(v96_3_byte);
            {
            for v97_3_byte in v93_29_cursor.child_mask().iter() {
              v93_29_cursor.descend_to_existing_byte(v97_3_byte);
              {
              for v98_2_byte in v93_29_cursor.child_mask().iter() {
                v93_29_cursor.descend_to_existing_byte(v98_2_byte);
                {
                for v99_3_byte in v93_29_cursor.child_mask().iter() {
                  v93_29_cursor.descend_to_existing_byte(v99_3_byte);
                  {
                  for v100_3_byte in v93_29_cursor.child_mask().iter() {
                    v93_29_cursor.descend_to_existing_byte(v100_3_byte);
                    {
                    let v101_3: Space = routine_12(c, &v93_29_cursor.path()[(v93_29_origin + 4)..(v93_29_origin + 8)], &v93_29_cursor.path()[v93_29_origin..(v93_29_origin + 4)], &v93_29_cursor);
                    join_wrapped_into(&mut v93_29_write,&((v101_3).read_zipper()),&[]);
                    }
                    v93_29_cursor.ascend(1);
                  }
                  }
                  v93_29_cursor.ascend(1);
                }
                }
                v93_29_cursor.ascend(1);
              }
              }
              v93_29_cursor.ascend(1);
            }
            }
            v93_29_cursor.ascend(1);
          }
          }
          v93_29_cursor.ascend(1);
        }
        }
        v93_29_cursor.ascend(1);
      }
      }
      v93_29_cursor.ascend(1);
    }
    drop(v93_29_cursor);
    drop(v93_29_write);
    compose(&(v41_28),&(v93_29))
  };
  drop(v41_28);
  let v41_31: Space = unite(&(v41_25),&(v41_30));
  let v41_33: Space = intersect(&(*CONSTANT_52),&(v41_3));
  let mut v41_34 = Space::new();
  let mut v41_34_write = v41_34.write_zipper();
  let mut v41_34_cursor = (v41_33).read_zipper();
  let v41_34_origin = v41_34_cursor.path().len();
  for v41_34_byte in v41_34_cursor.child_mask().iter() {
    v41_34_cursor.descend_to_existing_byte(v41_34_byte);
    {
    for v102_2_byte in v41_34_cursor.child_mask().iter() {
      v41_34_cursor.descend_to_existing_byte(v102_2_byte);
      {
      for v103_2_byte in v41_34_cursor.child_mask().iter() {
        v41_34_cursor.descend_to_existing_byte(v103_2_byte);
        {
        join_tails_into(&mut v41_34_write,&mut v41_34_cursor);
        }
        v41_34_cursor.ascend(1);
      }
      }
      v41_34_cursor.ascend(1);
    }
    }
    v41_34_cursor.ascend(1);
  }
  drop(v41_34_cursor);
  drop(v41_34_write);
  drop(v41_33);
  let v41_36: Space = if (&(v41_34)).is_empty() { Space::new() } else {
    let mut v105_35 = Space::new();
    let mut v105_35_write = v105_35.write_zipper();
    let mut v105_35_cursor = (*s0).read_zipper();
    let v105_35_origin = v105_35_cursor.path().len();
    for v105_35_byte in v105_35_cursor.child_mask().iter() {
      v105_35_cursor.descend_to_existing_byte(v105_35_byte);
      {
      for v106_2_byte in v105_35_cursor.child_mask().iter() {
        v105_35_cursor.descend_to_existing_byte(v106_2_byte);
        {
        for v107_3_byte in v105_35_cursor.child_mask().iter() {
          v105_35_cursor.descend_to_existing_byte(v107_3_byte);
          {
          for v108_3_byte in v105_35_cursor.child_mask().iter() {
            v105_35_cursor.descend_to_existing_byte(v108_3_byte);
            {
            for v109_3_byte in v105_35_cursor.child_mask().iter() {
              v105_35_cursor.descend_to_existing_byte(v109_3_byte);
              {
              for v110_2_byte in v105_35_cursor.child_mask().iter() {
                v105_35_cursor.descend_to_existing_byte(v110_2_byte);
                {
                for v111_3_byte in v105_35_cursor.child_mask().iter() {
                  v105_35_cursor.descend_to_existing_byte(v111_3_byte);
                  {
                  for v112_3_byte in v105_35_cursor.child_mask().iter() {
                    v105_35_cursor.descend_to_existing_byte(v112_3_byte);
                    {
                    let v113_3: Space = routine_13(c, &v105_35_cursor.path()[(v105_35_origin + 4)..(v105_35_origin + 8)], &v105_35_cursor.path()[v105_35_origin..(v105_35_origin + 4)], &v105_35_cursor);
                    join_wrapped_into(&mut v105_35_write,&((v113_3).read_zipper()),&[]);
                    }
                    v105_35_cursor.ascend(1);
                  }
                  }
                  v105_35_cursor.ascend(1);
                }
                }
                v105_35_cursor.ascend(1);
              }
              }
              v105_35_cursor.ascend(1);
            }
            }
            v105_35_cursor.ascend(1);
          }
          }
          v105_35_cursor.ascend(1);
        }
        }
        v105_35_cursor.ascend(1);
      }
      }
      v105_35_cursor.ascend(1);
    }
    drop(v105_35_cursor);
    drop(v105_35_write);
    compose(&(v41_34),&(v105_35))
  };
  drop(v41_34);
  let v41_37: Space = unite(&(v41_31),&(v41_36));
  let v41_39: Space = intersect(&(*CONSTANT_53),&(v41_3));
  let mut v41_40 = Space::new();
  let mut v41_40_write = v41_40.write_zipper();
  let mut v41_40_cursor = (v41_39).read_zipper();
  let v41_40_origin = v41_40_cursor.path().len();
  for v41_40_byte in v41_40_cursor.child_mask().iter() {
    v41_40_cursor.descend_to_existing_byte(v41_40_byte);
    {
    for v114_2_byte in v41_40_cursor.child_mask().iter() {
      v41_40_cursor.descend_to_existing_byte(v114_2_byte);
      {
      for v115_2_byte in v41_40_cursor.child_mask().iter() {
        v41_40_cursor.descend_to_existing_byte(v115_2_byte);
        {
        join_tails_into(&mut v41_40_write,&mut v41_40_cursor);
        }
        v41_40_cursor.ascend(1);
      }
      }
      v41_40_cursor.ascend(1);
    }
    }
    v41_40_cursor.ascend(1);
  }
  drop(v41_40_cursor);
  drop(v41_40_write);
  drop(v41_39);
  let v41_42: Space = if (&(v41_40)).is_empty() { Space::new() } else {
    let mut v117_41 = Space::new();
    let mut v117_41_write = v117_41.write_zipper();
    let mut v117_41_cursor = (*s0).read_zipper();
    let v117_41_origin = v117_41_cursor.path().len();
    for v117_41_byte in v117_41_cursor.child_mask().iter() {
      v117_41_cursor.descend_to_existing_byte(v117_41_byte);
      {
      for v118_2_byte in v117_41_cursor.child_mask().iter() {
        v117_41_cursor.descend_to_existing_byte(v118_2_byte);
        {
        for v119_3_byte in v117_41_cursor.child_mask().iter() {
          v117_41_cursor.descend_to_existing_byte(v119_3_byte);
          {
          for v120_3_byte in v117_41_cursor.child_mask().iter() {
            v117_41_cursor.descend_to_existing_byte(v120_3_byte);
            {
            for v121_3_byte in v117_41_cursor.child_mask().iter() {
              v117_41_cursor.descend_to_existing_byte(v121_3_byte);
              {
              for v122_2_byte in v117_41_cursor.child_mask().iter() {
                v117_41_cursor.descend_to_existing_byte(v122_2_byte);
                {
                for v123_3_byte in v117_41_cursor.child_mask().iter() {
                  v117_41_cursor.descend_to_existing_byte(v123_3_byte);
                  {
                  for v124_3_byte in v117_41_cursor.child_mask().iter() {
                    v117_41_cursor.descend_to_existing_byte(v124_3_byte);
                    {
                    let v125_3: Space = routine_14(c, &v117_41_cursor.path()[(v117_41_origin + 4)..(v117_41_origin + 8)], &v117_41_cursor.path()[v117_41_origin..(v117_41_origin + 4)], &v117_41_cursor);
                    join_wrapped_into(&mut v117_41_write,&((v125_3).read_zipper()),&[]);
                    }
                    v117_41_cursor.ascend(1);
                  }
                  }
                  v117_41_cursor.ascend(1);
                }
                }
                v117_41_cursor.ascend(1);
              }
              }
              v117_41_cursor.ascend(1);
            }
            }
            v117_41_cursor.ascend(1);
          }
          }
          v117_41_cursor.ascend(1);
        }
        }
        v117_41_cursor.ascend(1);
      }
      }
      v117_41_cursor.ascend(1);
    }
    drop(v117_41_cursor);
    drop(v117_41_write);
    compose(&(v41_40),&(v117_41))
  };
  drop(v41_40);
  let v41_43: Space = unite(&(v41_37),&(v41_42));
  let v41_45: Space = intersect(&(*CONSTANT_54),&(v41_3));
  let mut v41_46 = Space::new();
  let mut v41_46_write = v41_46.write_zipper();
  let mut v41_46_cursor = (v41_45).read_zipper();
  let v41_46_origin = v41_46_cursor.path().len();
  for v41_46_byte in v41_46_cursor.child_mask().iter() {
    v41_46_cursor.descend_to_existing_byte(v41_46_byte);
    {
    for v126_2_byte in v41_46_cursor.child_mask().iter() {
      v41_46_cursor.descend_to_existing_byte(v126_2_byte);
      {
      for v127_2_byte in v41_46_cursor.child_mask().iter() {
        v41_46_cursor.descend_to_existing_byte(v127_2_byte);
        {
        join_tails_into(&mut v41_46_write,&mut v41_46_cursor);
        }
        v41_46_cursor.ascend(1);
      }
      }
      v41_46_cursor.ascend(1);
    }
    }
    v41_46_cursor.ascend(1);
  }
  drop(v41_46_cursor);
  drop(v41_46_write);
  drop(v41_45);
  let v41_48: Space = if (&(v41_46)).is_empty() { Space::new() } else {
    let mut v129_47 = Space::new();
    let mut v129_47_write = v129_47.write_zipper();
    let mut v129_47_cursor = (*s0).read_zipper();
    let v129_47_origin = v129_47_cursor.path().len();
    for v129_47_byte in v129_47_cursor.child_mask().iter() {
      v129_47_cursor.descend_to_existing_byte(v129_47_byte);
      {
      for v130_2_byte in v129_47_cursor.child_mask().iter() {
        v129_47_cursor.descend_to_existing_byte(v130_2_byte);
        {
        for v131_3_byte in v129_47_cursor.child_mask().iter() {
          v129_47_cursor.descend_to_existing_byte(v131_3_byte);
          {
          for v132_3_byte in v129_47_cursor.child_mask().iter() {
            v129_47_cursor.descend_to_existing_byte(v132_3_byte);
            {
            for v133_3_byte in v129_47_cursor.child_mask().iter() {
              v129_47_cursor.descend_to_existing_byte(v133_3_byte);
              {
              for v134_2_byte in v129_47_cursor.child_mask().iter() {
                v129_47_cursor.descend_to_existing_byte(v134_2_byte);
                {
                for v135_3_byte in v129_47_cursor.child_mask().iter() {
                  v129_47_cursor.descend_to_existing_byte(v135_3_byte);
                  {
                  for v136_3_byte in v129_47_cursor.child_mask().iter() {
                    v129_47_cursor.descend_to_existing_byte(v136_3_byte);
                    {
                    let v137_3: Space = routine_15(c, &v129_47_cursor.path()[(v129_47_origin + 4)..(v129_47_origin + 8)], &v129_47_cursor.path()[v129_47_origin..(v129_47_origin + 4)], &v129_47_cursor);
                    join_wrapped_into(&mut v129_47_write,&((v137_3).read_zipper()),&[]);
                    }
                    v129_47_cursor.ascend(1);
                  }
                  }
                  v129_47_cursor.ascend(1);
                }
                }
                v129_47_cursor.ascend(1);
              }
              }
              v129_47_cursor.ascend(1);
            }
            }
            v129_47_cursor.ascend(1);
          }
          }
          v129_47_cursor.ascend(1);
        }
        }
        v129_47_cursor.ascend(1);
      }
      }
      v129_47_cursor.ascend(1);
    }
    drop(v129_47_cursor);
    drop(v129_47_write);
    compose(&(v41_46),&(v129_47))
  };
  drop(v41_46);
  let v41_49: Space = unite(&(v41_43),&(v41_48));
  let v41_51: Space = intersect(&(*CONSTANT_55),&(v41_3));
  drop(v41_3);
  let mut v41_52 = Space::new();
  let mut v41_52_write = v41_52.write_zipper();
  let mut v41_52_cursor = (v41_51).read_zipper();
  let v41_52_origin = v41_52_cursor.path().len();
  for v41_52_byte in v41_52_cursor.child_mask().iter() {
    v41_52_cursor.descend_to_existing_byte(v41_52_byte);
    {
    for v138_2_byte in v41_52_cursor.child_mask().iter() {
      v41_52_cursor.descend_to_existing_byte(v138_2_byte);
      {
      for v139_2_byte in v41_52_cursor.child_mask().iter() {
        v41_52_cursor.descend_to_existing_byte(v139_2_byte);
        {
        join_tails_into(&mut v41_52_write,&mut v41_52_cursor);
        }
        v41_52_cursor.ascend(1);
      }
      }
      v41_52_cursor.ascend(1);
    }
    }
    v41_52_cursor.ascend(1);
  }
  drop(v41_52_cursor);
  drop(v41_52_write);
  drop(v41_51);
  let v41_54: Space = if (&(v41_52)).is_empty() { Space::new() } else {
    let mut v141_53 = Space::new();
    let mut v141_53_write = v141_53.write_zipper();
    let mut v141_53_cursor = (*s0).read_zipper();
    let v141_53_origin = v141_53_cursor.path().len();
    for v141_53_byte in v141_53_cursor.child_mask().iter() {
      v141_53_cursor.descend_to_existing_byte(v141_53_byte);
      {
      for v142_2_byte in v141_53_cursor.child_mask().iter() {
        v141_53_cursor.descend_to_existing_byte(v142_2_byte);
        {
        for v143_3_byte in v141_53_cursor.child_mask().iter() {
          v141_53_cursor.descend_to_existing_byte(v143_3_byte);
          {
          for v144_3_byte in v141_53_cursor.child_mask().iter() {
            v141_53_cursor.descend_to_existing_byte(v144_3_byte);
            {
            for v145_3_byte in v141_53_cursor.child_mask().iter() {
              v141_53_cursor.descend_to_existing_byte(v145_3_byte);
              {
              for v146_2_byte in v141_53_cursor.child_mask().iter() {
                v141_53_cursor.descend_to_existing_byte(v146_2_byte);
                {
                for v147_3_byte in v141_53_cursor.child_mask().iter() {
                  v141_53_cursor.descend_to_existing_byte(v147_3_byte);
                  {
                  for v148_3_byte in v141_53_cursor.child_mask().iter() {
                    v141_53_cursor.descend_to_existing_byte(v148_3_byte);
                    {
                    let v149_3: Space = routine_16(c, &v141_53_cursor.path()[(v141_53_origin + 4)..(v141_53_origin + 8)], &v141_53_cursor.path()[v141_53_origin..(v141_53_origin + 4)], &v141_53_cursor);
                    join_wrapped_into(&mut v141_53_write,&((v149_3).read_zipper()),&[]);
                    }
                    v141_53_cursor.ascend(1);
                  }
                  }
                  v141_53_cursor.ascend(1);
                }
                }
                v141_53_cursor.ascend(1);
              }
              }
              v141_53_cursor.ascend(1);
            }
            }
            v141_53_cursor.ascend(1);
          }
          }
          v141_53_cursor.ascend(1);
        }
        }
        v141_53_cursor.ascend(1);
      }
      }
      v141_53_cursor.ascend(1);
    }
    drop(v141_53_cursor);
    drop(v141_53_write);
    compose(&(v41_52),&(v141_53))
  };
  drop(v41_52);
  let v41_55: Space = unite(&(v41_49),&(v41_54));
  (v41_55).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v150_6: Space = routine_17(c, &(*CONSTANT_56), &(*p1), &(*CONSTANT_1), &((*CONSTANT_57).read_zipper()));
  let v150_9: Space = routine_17(c, &(*CONSTANT_56), &(*p1), &(*CONSTANT_3), &((*CONSTANT_58).read_zipper()));
  let v150_10: Space = unite(&(v150_6),&(v150_9));
  let v150_13: Space = routine_17(c, &(*CONSTANT_56), &(*p1), &(*CONSTANT_5), &((*CONSTANT_59).read_zipper()));
  let v150_14: Space = unite(&(v150_10),&(v150_13));
  let v150_17: Space = routine_17(c, &(*CONSTANT_56), &(*p1), &(*CONSTANT_7), &((*CONSTANT_60).read_zipper()));
  let v150_18: Space = unite(&(v150_14),&(v150_17));
  let v150_21: Space = routine_17(c, &(*CONSTANT_56), &(*p1), &(*CONSTANT_9), &((*CONSTANT_61).read_zipper()));
  let v150_22: Space = unite(&(v150_18),&(v150_21));
  let v150_25: Space = routine_17(c, &(*CONSTANT_56), &(*p1), &(*CONSTANT_11), &((*CONSTANT_62).read_zipper()));
  let v150_26: Space = unite(&(v150_22),&(v150_25));
  let v150_29: Space = routine_17(c, &(*CONSTANT_63), &(*p1), &(*CONSTANT_1), &((*CONSTANT_64).read_zipper()));
  let v150_30: Space = unite(&(v150_26),&(v150_29));
  let v150_32: Space = routine_17(c, &(*CONSTANT_63), &(*p1), &(*CONSTANT_3), &((*CONSTANT_65).read_zipper()));
  let v150_33: Space = unite(&(v150_30),&(v150_32));
  let v150_35: Space = routine_17(c, &(*CONSTANT_63), &(*p1), &(*CONSTANT_7), &((*CONSTANT_66).read_zipper()));
  let v150_36: Space = unite(&(v150_33),&(v150_35));
  let v150_38: Space = routine_17(c, &(*CONSTANT_63), &(*p1), &(*CONSTANT_9), &((*CONSTANT_67).read_zipper()));
  let v150_39: Space = unite(&(v150_36),&(v150_38));
  let v150_42: Space = routine_17(c, &(*CONSTANT_63), &(*p1), &(*CONSTANT_13), &((*CONSTANT_68).read_zipper()));
  let v150_43: Space = unite(&(v150_39),&(v150_42));
  let v150_46: Space = routine_17(c, &(*CONSTANT_63), &(*p1), &(*CONSTANT_15), &((*CONSTANT_69).read_zipper()));
  let v150_47: Space = unite(&(v150_43),&(v150_46));
  let v150_50: Space = routine_17(c, &(*CONSTANT_70), &(*p1), &(*CONSTANT_3), &((*CONSTANT_64).read_zipper()));
  let v150_51: Space = unite(&(v150_47),&(v150_50));
  let v150_53: Space = routine_17(c, &(*CONSTANT_70), &(*p1), &(*CONSTANT_5), &((*CONSTANT_65).read_zipper()));
  let v150_54: Space = unite(&(v150_51),&(v150_53));
  let v150_56: Space = routine_17(c, &(*CONSTANT_70), &(*p1), &(*CONSTANT_9), &((*CONSTANT_66).read_zipper()));
  let v150_57: Space = unite(&(v150_54),&(v150_56));
  let v150_59: Space = routine_17(c, &(*CONSTANT_70), &(*p1), &(*CONSTANT_11), &((*CONSTANT_67).read_zipper()));
  let v150_60: Space = unite(&(v150_57),&(v150_59));
  let v150_62: Space = routine_17(c, &(*CONSTANT_70), &(*p1), &(*CONSTANT_15), &((*CONSTANT_68).read_zipper()));
  let v150_63: Space = unite(&(v150_60),&(v150_62));
  let v150_66: Space = routine_17(c, &(*CONSTANT_70), &(*p1), &(*CONSTANT_17), &((*CONSTANT_69).read_zipper()));
  let v150_67: Space = unite(&(v150_63),&(v150_66));
  let v150_70: Space = routine_17(c, &(*CONSTANT_71), &(*p1), &(*CONSTANT_7), &((*CONSTANT_57).read_zipper()));
  let v150_71: Space = unite(&(v150_67),&(v150_70));
  let v150_73: Space = routine_17(c, &(*CONSTANT_71), &(*p1), &(*CONSTANT_9), &((*CONSTANT_58).read_zipper()));
  let v150_74: Space = unite(&(v150_71),&(v150_73));
  let v150_76: Space = routine_17(c, &(*CONSTANT_71), &(*p1), &(*CONSTANT_11), &((*CONSTANT_59).read_zipper()));
  let v150_77: Space = unite(&(v150_74),&(v150_76));
  let v150_79: Space = routine_17(c, &(*CONSTANT_71), &(*p1), &(*CONSTANT_13), &((*CONSTANT_60).read_zipper()));
  let v150_80: Space = unite(&(v150_77),&(v150_79));
  let v150_82: Space = routine_17(c, &(*CONSTANT_71), &(*p1), &(*CONSTANT_15), &((*CONSTANT_61).read_zipper()));
  let v150_83: Space = unite(&(v150_80),&(v150_82));
  let v150_85: Space = routine_17(c, &(*CONSTANT_71), &(*p1), &(*CONSTANT_17), &((*CONSTANT_62).read_zipper()));
  let v150_86: Space = unite(&(v150_83),&(v150_85));
  let mut v150_87 = Space::new();
  let mut v150_87_write = v150_87.write_zipper();
  let mut v150_87_cursor = (v150_86).read_zipper();
  let v150_87_origin = v150_87_cursor.path().len();
  for v150_87_byte in v150_87_cursor.child_mask().iter() {
    v150_87_cursor.descend_to_existing_byte(v150_87_byte);
    {
    for v151_2_byte in v150_87_cursor.child_mask().iter() {
      v150_87_cursor.descend_to_existing_byte(v151_2_byte);
      {
      for v152_3_byte in v150_87_cursor.child_mask().iter() {
        v150_87_cursor.descend_to_existing_byte(v152_3_byte);
        {
        for v153_3_byte in v150_87_cursor.child_mask().iter() {
          v150_87_cursor.descend_to_existing_byte(v153_3_byte);
          {
          let v154_4: Space = wrap(&(descend_cursor(cursor_at(&v150_87_cursor,(v150_87_origin + 4)),&(*p0))),&v150_87_cursor.path()[v150_87_origin..(v150_87_origin + 4)]);
          let v154_5: Space = compose(&(v154_4),&(*s0));
          drop(v154_4);
          join_wrapped_into(&mut v150_87_write,&((v154_5).read_zipper()),&[]);
          }
          v150_87_cursor.ascend(1);
        }
        }
        v150_87_cursor.ascend(1);
      }
      }
      v150_87_cursor.ascend(1);
    }
    }
    v150_87_cursor.ascend(1);
  }
  drop(v150_87_cursor);
  drop(v150_87_write);
  (v150_87).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v155_6: Space = routine_18(c, &(*CONSTANT_56), &(*p1), &(*p0), &(*CONSTANT_1), &((*CONSTANT_57).read_zipper()));
  let v155_9: Space = routine_18(c, &(*CONSTANT_56), &(*p1), &(*p0), &(*CONSTANT_3), &((*CONSTANT_58).read_zipper()));
  let v155_10: Space = unite(&(v155_6),&(v155_9));
  let v155_13: Space = routine_18(c, &(*CONSTANT_56), &(*p1), &(*p0), &(*CONSTANT_5), &((*CONSTANT_59).read_zipper()));
  let v155_14: Space = unite(&(v155_10),&(v155_13));
  let v155_17: Space = routine_18(c, &(*CONSTANT_56), &(*p1), &(*p0), &(*CONSTANT_7), &((*CONSTANT_60).read_zipper()));
  let v155_18: Space = unite(&(v155_14),&(v155_17));
  let v155_21: Space = routine_18(c, &(*CONSTANT_56), &(*p1), &(*p0), &(*CONSTANT_9), &((*CONSTANT_61).read_zipper()));
  let v155_22: Space = unite(&(v155_18),&(v155_21));
  let v155_25: Space = routine_18(c, &(*CONSTANT_56), &(*p1), &(*p0), &(*CONSTANT_11), &((*CONSTANT_62).read_zipper()));
  let v155_26: Space = unite(&(v155_22),&(v155_25));
  let v155_29: Space = routine_18(c, &(*CONSTANT_63), &(*p1), &(*p0), &(*CONSTANT_1), &((*CONSTANT_64).read_zipper()));
  let v155_30: Space = unite(&(v155_26),&(v155_29));
  let v155_32: Space = routine_18(c, &(*CONSTANT_63), &(*p1), &(*p0), &(*CONSTANT_3), &((*CONSTANT_65).read_zipper()));
  let v155_33: Space = unite(&(v155_30),&(v155_32));
  let v155_35: Space = routine_18(c, &(*CONSTANT_63), &(*p1), &(*p0), &(*CONSTANT_7), &((*CONSTANT_66).read_zipper()));
  let v155_36: Space = unite(&(v155_33),&(v155_35));
  let v155_38: Space = routine_18(c, &(*CONSTANT_63), &(*p1), &(*p0), &(*CONSTANT_9), &((*CONSTANT_67).read_zipper()));
  let v155_39: Space = unite(&(v155_36),&(v155_38));
  let v155_42: Space = routine_18(c, &(*CONSTANT_63), &(*p1), &(*p0), &(*CONSTANT_13), &((*CONSTANT_68).read_zipper()));
  let v155_43: Space = unite(&(v155_39),&(v155_42));
  let v155_46: Space = routine_18(c, &(*CONSTANT_63), &(*p1), &(*p0), &(*CONSTANT_15), &((*CONSTANT_69).read_zipper()));
  let v155_47: Space = unite(&(v155_43),&(v155_46));
  let v155_50: Space = routine_18(c, &(*CONSTANT_70), &(*p1), &(*p0), &(*CONSTANT_3), &((*CONSTANT_64).read_zipper()));
  let v155_51: Space = unite(&(v155_47),&(v155_50));
  let v155_53: Space = routine_18(c, &(*CONSTANT_70), &(*p1), &(*p0), &(*CONSTANT_5), &((*CONSTANT_65).read_zipper()));
  let v155_54: Space = unite(&(v155_51),&(v155_53));
  let v155_56: Space = routine_18(c, &(*CONSTANT_70), &(*p1), &(*p0), &(*CONSTANT_9), &((*CONSTANT_66).read_zipper()));
  let v155_57: Space = unite(&(v155_54),&(v155_56));
  let v155_59: Space = routine_18(c, &(*CONSTANT_70), &(*p1), &(*p0), &(*CONSTANT_11), &((*CONSTANT_67).read_zipper()));
  let v155_60: Space = unite(&(v155_57),&(v155_59));
  let v155_62: Space = routine_18(c, &(*CONSTANT_70), &(*p1), &(*p0), &(*CONSTANT_15), &((*CONSTANT_68).read_zipper()));
  let v155_63: Space = unite(&(v155_60),&(v155_62));
  let v155_66: Space = routine_18(c, &(*CONSTANT_70), &(*p1), &(*p0), &(*CONSTANT_17), &((*CONSTANT_69).read_zipper()));
  let v155_67: Space = unite(&(v155_63),&(v155_66));
  let v155_70: Space = routine_18(c, &(*CONSTANT_71), &(*p1), &(*p0), &(*CONSTANT_7), &((*CONSTANT_57).read_zipper()));
  let v155_71: Space = unite(&(v155_67),&(v155_70));
  let v155_73: Space = routine_18(c, &(*CONSTANT_71), &(*p1), &(*p0), &(*CONSTANT_9), &((*CONSTANT_58).read_zipper()));
  let v155_74: Space = unite(&(v155_71),&(v155_73));
  let v155_76: Space = routine_18(c, &(*CONSTANT_71), &(*p1), &(*p0), &(*CONSTANT_11), &((*CONSTANT_59).read_zipper()));
  let v155_77: Space = unite(&(v155_74),&(v155_76));
  let v155_79: Space = routine_18(c, &(*CONSTANT_71), &(*p1), &(*p0), &(*CONSTANT_13), &((*CONSTANT_60).read_zipper()));
  let v155_80: Space = unite(&(v155_77),&(v155_79));
  let v155_82: Space = routine_18(c, &(*CONSTANT_71), &(*p1), &(*p0), &(*CONSTANT_15), &((*CONSTANT_61).read_zipper()));
  let v155_83: Space = unite(&(v155_80),&(v155_82));
  let v155_85: Space = routine_18(c, &(*CONSTANT_71), &(*p1), &(*p0), &(*CONSTANT_17), &((*CONSTANT_62).read_zipper()));
  let v155_86: Space = unite(&(v155_83),&(v155_85));
  let mut v155_87 = Space::new();
  let mut v155_87_write = v155_87.write_zipper();
  let mut v155_87_cursor = (v155_86).read_zipper();
  let v155_87_origin = v155_87_cursor.path().len();
  for v155_87_byte in v155_87_cursor.child_mask().iter() {
    v155_87_cursor.descend_to_existing_byte(v155_87_byte);
    {
    for v156_2_byte in v155_87_cursor.child_mask().iter() {
      v155_87_cursor.descend_to_existing_byte(v156_2_byte);
      {
      for v157_3_byte in v155_87_cursor.child_mask().iter() {
        v155_87_cursor.descend_to_existing_byte(v157_3_byte);
        {
        for v158_3_byte in v155_87_cursor.child_mask().iter() {
          v155_87_cursor.descend_to_existing_byte(v158_3_byte);
          {
          let v159_3: Space = routine_19(c, &v155_87_cursor.path()[v155_87_origin..(v155_87_origin + 4)], &(*s0));
          join_wrapped_into(&mut v155_87_write,&((v159_3).read_zipper()),&[]);
          }
          v155_87_cursor.ascend(1);
        }
        }
        v155_87_cursor.ascend(1);
      }
      }
      v155_87_cursor.ascend(1);
    }
    }
    v155_87_cursor.ascend(1);
  }
  drop(v155_87_cursor);
  drop(v155_87_write);
  (v155_87).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v160_3 = Space::new();
  let mut v160_3_write = v160_3.write_zipper();
  let mut v160_3_cursor = (*s0).read_zipper();
  let v160_3_origin = v160_3_cursor.path().len();
  for v160_3_byte in v160_3_cursor.child_mask().iter() {
    v160_3_cursor.descend_to_existing_byte(v160_3_byte);
    {
    for v161_2_byte in v160_3_cursor.child_mask().iter() {
      v160_3_cursor.descend_to_existing_byte(v161_2_byte);
      {
      for v162_3_byte in v160_3_cursor.child_mask().iter() {
        v160_3_cursor.descend_to_existing_byte(v162_3_byte);
        {
        for v163_3_byte in v160_3_cursor.child_mask().iter() {
          v160_3_cursor.descend_to_existing_byte(v163_3_byte);
          {
          for v164_3_byte in v160_3_cursor.child_mask().iter() {
            v160_3_cursor.descend_to_existing_byte(v164_3_byte);
            {
            for v165_2_byte in v160_3_cursor.child_mask().iter() {
              v160_3_cursor.descend_to_existing_byte(v165_2_byte);
              {
              for v166_3_byte in v160_3_cursor.child_mask().iter() {
                v160_3_cursor.descend_to_existing_byte(v166_3_byte);
                {
                for v167_3_byte in v160_3_cursor.child_mask().iter() {
                  v160_3_cursor.descend_to_existing_byte(v167_3_byte);
                  {
                  let v168_3: Space = routine_20(c, &v160_3_cursor.path()[(v160_3_origin + 4)..(v160_3_origin + 8)], &(*p1), &(*p0), &v160_3_cursor.path()[v160_3_origin..(v160_3_origin + 4)], &v160_3_cursor);
                  join_wrapped_into(&mut v160_3_write,&((v168_3).read_zipper()),&[]);
                  }
                  v160_3_cursor.ascend(1);
                }
                }
                v160_3_cursor.ascend(1);
              }
              }
              v160_3_cursor.ascend(1);
            }
            }
            v160_3_cursor.ascend(1);
          }
          }
          v160_3_cursor.ascend(1);
        }
        }
        v160_3_cursor.ascend(1);
      }
      }
      v160_3_cursor.ascend(1);
    }
    }
    v160_3_cursor.ascend(1);
  }
  drop(v160_3_cursor);
  drop(v160_3_write);
  (v160_3).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v169_3 = Space::new();
  let mut v169_3_write = v169_3.write_zipper();
  let mut v169_3_cursor = (*s0).read_zipper();
  let v169_3_origin = v169_3_cursor.path().len();
  for v169_3_byte in v169_3_cursor.child_mask().iter() {
    v169_3_cursor.descend_to_existing_byte(v169_3_byte);
    {
    for v170_2_byte in v169_3_cursor.child_mask().iter() {
      v169_3_cursor.descend_to_existing_byte(v170_2_byte);
      {
      for v171_3_byte in v169_3_cursor.child_mask().iter() {
        v169_3_cursor.descend_to_existing_byte(v171_3_byte);
        {
        for v172_3_byte in v169_3_cursor.child_mask().iter() {
          v169_3_cursor.descend_to_existing_byte(v172_3_byte);
          {
          for v173_3_byte in v169_3_cursor.child_mask().iter() {
            v169_3_cursor.descend_to_existing_byte(v173_3_byte);
            {
            for v174_2_byte in v169_3_cursor.child_mask().iter() {
              v169_3_cursor.descend_to_existing_byte(v174_2_byte);
              {
              for v175_3_byte in v169_3_cursor.child_mask().iter() {
                v169_3_cursor.descend_to_existing_byte(v175_3_byte);
                {
                for v176_3_byte in v169_3_cursor.child_mask().iter() {
                  v169_3_cursor.descend_to_existing_byte(v176_3_byte);
                  {
                  let v177_3: Space = routine_21(c, &v169_3_cursor.path()[(v169_3_origin + 4)..(v169_3_origin + 8)], &(*p1), &(*p0), &v169_3_cursor.path()[v169_3_origin..(v169_3_origin + 4)], &v169_3_cursor);
                  join_wrapped_into(&mut v169_3_write,&((v177_3).read_zipper()),&[]);
                  }
                  v169_3_cursor.ascend(1);
                }
                }
                v169_3_cursor.ascend(1);
              }
              }
              v169_3_cursor.ascend(1);
            }
            }
            v169_3_cursor.ascend(1);
          }
          }
          v169_3_cursor.ascend(1);
        }
        }
        v169_3_cursor.ascend(1);
      }
      }
      v169_3_cursor.ascend(1);
    }
    }
    v169_3_cursor.ascend(1);
  }
  drop(v169_3_cursor);
  drop(v169_3_write);
  (v169_3).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v178_3 = Space::new();
  let mut v178_3_write = v178_3.write_zipper();
  let mut v178_3_cursor = (*s0).read_zipper();
  let v178_3_origin = v178_3_cursor.path().len();
  for v178_3_byte in v178_3_cursor.child_mask().iter() {
    v178_3_cursor.descend_to_existing_byte(v178_3_byte);
    {
    for v179_2_byte in v178_3_cursor.child_mask().iter() {
      v178_3_cursor.descend_to_existing_byte(v179_2_byte);
      {
      for v180_3_byte in v178_3_cursor.child_mask().iter() {
        v178_3_cursor.descend_to_existing_byte(v180_3_byte);
        {
        for v181_3_byte in v178_3_cursor.child_mask().iter() {
          v178_3_cursor.descend_to_existing_byte(v181_3_byte);
          {
          for v182_3_byte in v178_3_cursor.child_mask().iter() {
            v178_3_cursor.descend_to_existing_byte(v182_3_byte);
            {
            for v183_2_byte in v178_3_cursor.child_mask().iter() {
              v178_3_cursor.descend_to_existing_byte(v183_2_byte);
              {
              for v184_3_byte in v178_3_cursor.child_mask().iter() {
                v178_3_cursor.descend_to_existing_byte(v184_3_byte);
                {
                for v185_3_byte in v178_3_cursor.child_mask().iter() {
                  v178_3_cursor.descend_to_existing_byte(v185_3_byte);
                  {
                  let v186_3: Space = routine_22(c, &v178_3_cursor.path()[(v178_3_origin + 4)..(v178_3_origin + 8)], &(*p1), &(*p0), &v178_3_cursor.path()[v178_3_origin..(v178_3_origin + 4)], &v178_3_cursor);
                  join_wrapped_into(&mut v178_3_write,&((v186_3).read_zipper()),&[]);
                  }
                  v178_3_cursor.ascend(1);
                }
                }
                v178_3_cursor.ascend(1);
              }
              }
              v178_3_cursor.ascend(1);
            }
            }
            v178_3_cursor.ascend(1);
          }
          }
          v178_3_cursor.ascend(1);
        }
        }
        v178_3_cursor.ascend(1);
      }
      }
      v178_3_cursor.ascend(1);
    }
    }
    v178_3_cursor.ascend(1);
  }
  drop(v178_3_cursor);
  drop(v178_3_write);
  (v178_3).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v187_3 = Space::new();
  let mut v187_3_write = v187_3.write_zipper();
  let mut v187_3_cursor = (*s0).read_zipper();
  let v187_3_origin = v187_3_cursor.path().len();
  for v187_3_byte in v187_3_cursor.child_mask().iter() {
    v187_3_cursor.descend_to_existing_byte(v187_3_byte);
    {
    for v188_2_byte in v187_3_cursor.child_mask().iter() {
      v187_3_cursor.descend_to_existing_byte(v188_2_byte);
      {
      for v189_3_byte in v187_3_cursor.child_mask().iter() {
        v187_3_cursor.descend_to_existing_byte(v189_3_byte);
        {
        for v190_3_byte in v187_3_cursor.child_mask().iter() {
          v187_3_cursor.descend_to_existing_byte(v190_3_byte);
          {
          for v191_3_byte in v187_3_cursor.child_mask().iter() {
            v187_3_cursor.descend_to_existing_byte(v191_3_byte);
            {
            for v192_2_byte in v187_3_cursor.child_mask().iter() {
              v187_3_cursor.descend_to_existing_byte(v192_2_byte);
              {
              for v193_3_byte in v187_3_cursor.child_mask().iter() {
                v187_3_cursor.descend_to_existing_byte(v193_3_byte);
                {
                for v194_3_byte in v187_3_cursor.child_mask().iter() {
                  v187_3_cursor.descend_to_existing_byte(v194_3_byte);
                  {
                  let v195_3: Space = routine_23(c, &v187_3_cursor.path()[(v187_3_origin + 4)..(v187_3_origin + 8)], &(*p1), &(*p0), &v187_3_cursor.path()[v187_3_origin..(v187_3_origin + 4)], &v187_3_cursor);
                  join_wrapped_into(&mut v187_3_write,&((v195_3).read_zipper()),&[]);
                  }
                  v187_3_cursor.ascend(1);
                }
                }
                v187_3_cursor.ascend(1);
              }
              }
              v187_3_cursor.ascend(1);
            }
            }
            v187_3_cursor.ascend(1);
          }
          }
          v187_3_cursor.ascend(1);
        }
        }
        v187_3_cursor.ascend(1);
      }
      }
      v187_3_cursor.ascend(1);
    }
    }
    v187_3_cursor.ascend(1);
  }
  drop(v187_3_cursor);
  drop(v187_3_write);
  (v187_3).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v196_3 = Space::new();
  let mut v196_3_write = v196_3.write_zipper();
  let mut v196_3_cursor = (*s0).read_zipper();
  let v196_3_origin = v196_3_cursor.path().len();
  for v196_3_byte in v196_3_cursor.child_mask().iter() {
    v196_3_cursor.descend_to_existing_byte(v196_3_byte);
    {
    for v197_2_byte in v196_3_cursor.child_mask().iter() {
      v196_3_cursor.descend_to_existing_byte(v197_2_byte);
      {
      for v198_3_byte in v196_3_cursor.child_mask().iter() {
        v196_3_cursor.descend_to_existing_byte(v198_3_byte);
        {
        for v199_3_byte in v196_3_cursor.child_mask().iter() {
          v196_3_cursor.descend_to_existing_byte(v199_3_byte);
          {
          for v200_3_byte in v196_3_cursor.child_mask().iter() {
            v196_3_cursor.descend_to_existing_byte(v200_3_byte);
            {
            for v201_2_byte in v196_3_cursor.child_mask().iter() {
              v196_3_cursor.descend_to_existing_byte(v201_2_byte);
              {
              for v202_3_byte in v196_3_cursor.child_mask().iter() {
                v196_3_cursor.descend_to_existing_byte(v202_3_byte);
                {
                for v203_3_byte in v196_3_cursor.child_mask().iter() {
                  v196_3_cursor.descend_to_existing_byte(v203_3_byte);
                  {
                  let v204_3: Space = routine_24(c, &v196_3_cursor.path()[(v196_3_origin + 4)..(v196_3_origin + 8)], &(*p1), &(*p0), &v196_3_cursor.path()[v196_3_origin..(v196_3_origin + 4)], &v196_3_cursor);
                  join_wrapped_into(&mut v196_3_write,&((v204_3).read_zipper()),&[]);
                  }
                  v196_3_cursor.ascend(1);
                }
                }
                v196_3_cursor.ascend(1);
              }
              }
              v196_3_cursor.ascend(1);
            }
            }
            v196_3_cursor.ascend(1);
          }
          }
          v196_3_cursor.ascend(1);
        }
        }
        v196_3_cursor.ascend(1);
      }
      }
      v196_3_cursor.ascend(1);
    }
    }
    v196_3_cursor.ascend(1);
  }
  drop(v196_3_cursor);
  drop(v196_3_write);
  (v196_3).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v205_3 = Space::new();
  let mut v205_3_write = v205_3.write_zipper();
  let mut v205_3_cursor = (*s0).read_zipper();
  let v205_3_origin = v205_3_cursor.path().len();
  for v205_3_byte in v205_3_cursor.child_mask().iter() {
    v205_3_cursor.descend_to_existing_byte(v205_3_byte);
    {
    for v206_2_byte in v205_3_cursor.child_mask().iter() {
      v205_3_cursor.descend_to_existing_byte(v206_2_byte);
      {
      for v207_3_byte in v205_3_cursor.child_mask().iter() {
        v205_3_cursor.descend_to_existing_byte(v207_3_byte);
        {
        for v208_3_byte in v205_3_cursor.child_mask().iter() {
          v205_3_cursor.descend_to_existing_byte(v208_3_byte);
          {
          for v209_3_byte in v205_3_cursor.child_mask().iter() {
            v205_3_cursor.descend_to_existing_byte(v209_3_byte);
            {
            for v210_2_byte in v205_3_cursor.child_mask().iter() {
              v205_3_cursor.descend_to_existing_byte(v210_2_byte);
              {
              for v211_3_byte in v205_3_cursor.child_mask().iter() {
                v205_3_cursor.descend_to_existing_byte(v211_3_byte);
                {
                for v212_3_byte in v205_3_cursor.child_mask().iter() {
                  v205_3_cursor.descend_to_existing_byte(v212_3_byte);
                  {
                  let v213_3: Space = routine_25(c, &v205_3_cursor.path()[(v205_3_origin + 4)..(v205_3_origin + 8)], &(*p1), &(*p0), &v205_3_cursor.path()[v205_3_origin..(v205_3_origin + 4)], &v205_3_cursor);
                  join_wrapped_into(&mut v205_3_write,&((v213_3).read_zipper()),&[]);
                  }
                  v205_3_cursor.ascend(1);
                }
                }
                v205_3_cursor.ascend(1);
              }
              }
              v205_3_cursor.ascend(1);
            }
            }
            v205_3_cursor.ascend(1);
          }
          }
          v205_3_cursor.ascend(1);
        }
        }
        v205_3_cursor.ascend(1);
      }
      }
      v205_3_cursor.ascend(1);
    }
    }
    v205_3_cursor.ascend(1);
  }
  drop(v205_3_cursor);
  drop(v205_3_write);
  (v205_3).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v214_3 = Space::new();
  let mut v214_3_write = v214_3.write_zipper();
  let mut v214_3_cursor = (*s0).read_zipper();
  let v214_3_origin = v214_3_cursor.path().len();
  for v214_3_byte in v214_3_cursor.child_mask().iter() {
    v214_3_cursor.descend_to_existing_byte(v214_3_byte);
    {
    for v215_2_byte in v214_3_cursor.child_mask().iter() {
      v214_3_cursor.descend_to_existing_byte(v215_2_byte);
      {
      for v216_3_byte in v214_3_cursor.child_mask().iter() {
        v214_3_cursor.descend_to_existing_byte(v216_3_byte);
        {
        for v217_3_byte in v214_3_cursor.child_mask().iter() {
          v214_3_cursor.descend_to_existing_byte(v217_3_byte);
          {
          for v218_3_byte in v214_3_cursor.child_mask().iter() {
            v214_3_cursor.descend_to_existing_byte(v218_3_byte);
            {
            for v219_2_byte in v214_3_cursor.child_mask().iter() {
              v214_3_cursor.descend_to_existing_byte(v219_2_byte);
              {
              for v220_3_byte in v214_3_cursor.child_mask().iter() {
                v214_3_cursor.descend_to_existing_byte(v220_3_byte);
                {
                for v221_3_byte in v214_3_cursor.child_mask().iter() {
                  v214_3_cursor.descend_to_existing_byte(v221_3_byte);
                  {
                  let v222_3: Space = routine_26(c, &v214_3_cursor.path()[(v214_3_origin + 4)..(v214_3_origin + 8)], &(*p1), &(*p0), &v214_3_cursor.path()[v214_3_origin..(v214_3_origin + 4)], &v214_3_cursor);
                  join_wrapped_into(&mut v214_3_write,&((v222_3).read_zipper()),&[]);
                  }
                  v214_3_cursor.ascend(1);
                }
                }
                v214_3_cursor.ascend(1);
              }
              }
              v214_3_cursor.ascend(1);
            }
            }
            v214_3_cursor.ascend(1);
          }
          }
          v214_3_cursor.ascend(1);
        }
        }
        v214_3_cursor.ascend(1);
      }
      }
      v214_3_cursor.ascend(1);
    }
    }
    v214_3_cursor.ascend(1);
  }
  drop(v214_3_cursor);
  drop(v214_3_write);
  (v214_3).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v223_3 = Space::new();
  let mut v223_3_write = v223_3.write_zipper();
  let mut v223_3_cursor = (*s0).read_zipper();
  let v223_3_origin = v223_3_cursor.path().len();
  for v223_3_byte in v223_3_cursor.child_mask().iter() {
    v223_3_cursor.descend_to_existing_byte(v223_3_byte);
    {
    for v224_2_byte in v223_3_cursor.child_mask().iter() {
      v223_3_cursor.descend_to_existing_byte(v224_2_byte);
      {
      for v225_3_byte in v223_3_cursor.child_mask().iter() {
        v223_3_cursor.descend_to_existing_byte(v225_3_byte);
        {
        for v226_3_byte in v223_3_cursor.child_mask().iter() {
          v223_3_cursor.descend_to_existing_byte(v226_3_byte);
          {
          for v227_3_byte in v223_3_cursor.child_mask().iter() {
            v223_3_cursor.descend_to_existing_byte(v227_3_byte);
            {
            for v228_2_byte in v223_3_cursor.child_mask().iter() {
              v223_3_cursor.descend_to_existing_byte(v228_2_byte);
              {
              for v229_3_byte in v223_3_cursor.child_mask().iter() {
                v223_3_cursor.descend_to_existing_byte(v229_3_byte);
                {
                for v230_3_byte in v223_3_cursor.child_mask().iter() {
                  v223_3_cursor.descend_to_existing_byte(v230_3_byte);
                  {
                  let v231_3: Space = routine_27(c, &v223_3_cursor.path()[(v223_3_origin + 4)..(v223_3_origin + 8)], &(*p1), &(*p0), &v223_3_cursor.path()[v223_3_origin..(v223_3_origin + 4)], &v223_3_cursor);
                  join_wrapped_into(&mut v223_3_write,&((v231_3).read_zipper()),&[]);
                  }
                  v223_3_cursor.ascend(1);
                }
                }
                v223_3_cursor.ascend(1);
              }
              }
              v223_3_cursor.ascend(1);
            }
            }
            v223_3_cursor.ascend(1);
          }
          }
          v223_3_cursor.ascend(1);
        }
        }
        v223_3_cursor.ascend(1);
      }
      }
      v223_3_cursor.ascend(1);
    }
    }
    v223_3_cursor.ascend(1);
  }
  drop(v223_3_cursor);
  drop(v223_3_write);
  (v223_3).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v232_3 = Space::new();
  let mut v232_3_write = v232_3.write_zipper();
  let mut v232_3_cursor = (*s0).read_zipper();
  let v232_3_origin = v232_3_cursor.path().len();
  for v232_3_byte in v232_3_cursor.child_mask().iter() {
    v232_3_cursor.descend_to_existing_byte(v232_3_byte);
    {
    for v233_2_byte in v232_3_cursor.child_mask().iter() {
      v232_3_cursor.descend_to_existing_byte(v233_2_byte);
      {
      for v234_3_byte in v232_3_cursor.child_mask().iter() {
        v232_3_cursor.descend_to_existing_byte(v234_3_byte);
        {
        for v235_3_byte in v232_3_cursor.child_mask().iter() {
          v232_3_cursor.descend_to_existing_byte(v235_3_byte);
          {
          for v236_3_byte in v232_3_cursor.child_mask().iter() {
            v232_3_cursor.descend_to_existing_byte(v236_3_byte);
            {
            for v237_2_byte in v232_3_cursor.child_mask().iter() {
              v232_3_cursor.descend_to_existing_byte(v237_2_byte);
              {
              for v238_3_byte in v232_3_cursor.child_mask().iter() {
                v232_3_cursor.descend_to_existing_byte(v238_3_byte);
                {
                for v239_3_byte in v232_3_cursor.child_mask().iter() {
                  v232_3_cursor.descend_to_existing_byte(v239_3_byte);
                  {
                  let v240_3: Space = routine_28(c, &v232_3_cursor.path()[(v232_3_origin + 4)..(v232_3_origin + 8)], &(*p1), &(*p0), &v232_3_cursor.path()[v232_3_origin..(v232_3_origin + 4)], &v232_3_cursor);
                  join_wrapped_into(&mut v232_3_write,&((v240_3).read_zipper()),&[]);
                  }
                  v232_3_cursor.ascend(1);
                }
                }
                v232_3_cursor.ascend(1);
              }
              }
              v232_3_cursor.ascend(1);
            }
            }
            v232_3_cursor.ascend(1);
          }
          }
          v232_3_cursor.ascend(1);
        }
        }
        v232_3_cursor.ascend(1);
      }
      }
      v232_3_cursor.ascend(1);
    }
    }
    v232_3_cursor.ascend(1);
  }
  drop(v232_3_cursor);
  drop(v232_3_write);
  (v232_3).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v241_5 = Space::new();
  let mut v241_5_write = v241_5.write_zipper();
  let mut v241_5_cursor = (*s0).read_zipper();
  let v241_5_origin = v241_5_cursor.path().len();
  for v241_5_byte in v241_5_cursor.child_mask().iter() {
    v241_5_cursor.descend_to_existing_byte(v241_5_byte);
    {
    for v242_2_byte in v241_5_cursor.child_mask().iter() {
      v241_5_cursor.descend_to_existing_byte(v242_2_byte);
      {
      for v243_3_byte in v241_5_cursor.child_mask().iter() {
        v241_5_cursor.descend_to_existing_byte(v243_3_byte);
        {
        write_heads_mask(&mut v241_5_write,(&v241_5_cursor).head_mask(),&v241_5_cursor.path()[v241_5_origin..(v241_5_origin + 3)]);
        }
        v241_5_cursor.ascend(1);
      }
      }
      v241_5_cursor.ascend(1);
    }
    }
    v241_5_cursor.ascend(1);
  }
  drop(v241_5_cursor);
  drop(v241_5_write);
  let v241_6: Space = raffine(&(*CONSTANT_72),&(v241_5));
  drop(v241_5);
  let v241_7: Space = unite(&(v241_6),&(*s0));
  drop(v241_6);
  let v241_8: Path = concat_path(&(*p2),&(*p0));
  let v241_9: Space = wrap(&(v241_7),&(v241_8));
  drop(v241_7);
  drop(v241_8);
  (&(descend_cursor((v241_9).read_zipper(),&(*p1)))).make_map()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v245_6 = Space::new();
  let mut v245_6_write = v245_6.write_zipper();
  let mut v245_6_cursor = (*s0).read_zipper();
  let v245_6_origin = v245_6_cursor.path().len();
  for v245_6_byte in v245_6_cursor.child_mask().iter() {
    v245_6_cursor.descend_to_existing_byte(v245_6_byte);
    {
    for v246_2_byte in v245_6_cursor.child_mask().iter() {
      v245_6_cursor.descend_to_existing_byte(v246_2_byte);
      {
      for v247_3_byte in v245_6_cursor.child_mask().iter() {
        v245_6_cursor.descend_to_existing_byte(v247_3_byte);
        {
        write_heads_mask(&mut v245_6_write,(&v245_6_cursor).head_mask(),&v245_6_cursor.path()[v245_6_origin..(v245_6_origin + 3)]);
        }
        v245_6_cursor.ascend(1);
      }
      }
      v245_6_cursor.ascend(1);
    }
    }
    v245_6_cursor.ascend(1);
  }
  drop(v245_6_cursor);
  drop(v245_6_write);
  let v245_7: Space = raffine(&(*CONSTANT_72),&(v245_6));
  drop(v245_6);
  let v245_8: Space = unite(&(v245_7),&(*s0));
  drop(v245_7);
  let v245_9: Path = concat_path(&(*p3),&(*p0));
  let v245_10: Space = wrap(&(v245_8),&(v245_9));
  drop(v245_8);
  drop(v245_9);
  (&(descend_cursor(descend_cursor(descend_cursor((v245_10).read_zipper(),&(*p1)),&(*p2)),&(*p1)))).make_map()
}

fn routine_19(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v249_3: Space = singleton(&(*p0));
  let v249_4: Space = intersect(&(*CONSTANT_47),&(v249_3));
  let v249_28: Space = if (&(v249_4)).is_empty() { Space::new() } else {
    let v250_9: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_3)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_3))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_5))))
    };
    let v250_12: Space = if (&(v250_9)).is_empty() { Space::new() } else {
      compose(&(v250_9),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v250_9);
    let v250_15: Space = if (&(v250_12)).is_empty() { Space::new() } else {
      compose(&(v250_12),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v250_12);
    let v250_18: Space = if (&(v250_15)).is_empty() { Space::new() } else {
      compose(&(v250_15),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v250_15);
    let v250_21: Space = if (&(v250_18)).is_empty() { Space::new() } else {
      compose(&(v250_18),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v250_18);
    let v250_24: Space = if (&(v250_21)).is_empty() { Space::new() } else {
      compose(&(v250_21),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v250_21);
    let v250_27: Space = if (&(v250_24)).is_empty() { Space::new() } else {
      compose(&(v250_24),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v250_24);
    compose(&(v249_4),&(v250_27))
  };
  drop(v249_4);
  let v249_30: Space = intersect(&(*CONSTANT_48),&(v249_3));
  let v249_40: Space = if (&(v249_30)).is_empty() { Space::new() } else {
    let v258_33: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_5))))
    };
    let v258_34: Space = if (&(v258_33)).is_empty() { Space::new() } else {
      compose(&(v258_33),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v258_33);
    let v258_35: Space = if (&(v258_34)).is_empty() { Space::new() } else {
      compose(&(v258_34),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v258_34);
    let v258_36: Space = if (&(v258_35)).is_empty() { Space::new() } else {
      compose(&(v258_35),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v258_35);
    let v258_37: Space = if (&(v258_36)).is_empty() { Space::new() } else {
      compose(&(v258_36),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v258_36);
    let v258_38: Space = if (&(v258_37)).is_empty() { Space::new() } else {
      compose(&(v258_37),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v258_37);
    let v258_39: Space = if (&(v258_38)).is_empty() { Space::new() } else {
      compose(&(v258_38),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v258_38);
    compose(&(v249_30),&(v258_39))
  };
  drop(v249_30);
  let v249_41: Space = unite(&(v249_28),&(v249_40));
  drop(v249_28);
  drop(v249_40);
  let v249_43: Space = intersect(&(*CONSTANT_49),&(v249_3));
  let v249_51: Space = if (&(v249_43)).is_empty() { Space::new() } else {
    let v266_44: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_3))))
    };
    let v266_45: Space = if (&(v266_44)).is_empty() { Space::new() } else {
      compose(&(v266_44),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_7))))
    };
    let v266_46: Space = if (&(v266_45)).is_empty() { Space::new() } else {
      compose(&(v266_45),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v266_45);
    let v266_47: Space = if (&(v266_46)).is_empty() { Space::new() } else {
      compose(&(v266_46),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v266_46);
    let v266_48: Space = if (&(v266_47)).is_empty() { Space::new() } else {
      compose(&(v266_47),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v266_47);
    let v266_49: Space = if (&(v266_48)).is_empty() { Space::new() } else {
      compose(&(v266_48),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v266_48);
    let v266_50: Space = if (&(v266_49)).is_empty() { Space::new() } else {
      compose(&(v266_49),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v266_49);
    compose(&(v249_43),&(v266_50))
  };
  drop(v249_43);
  let v249_52: Space = unite(&(v249_41),&(v249_51));
  drop(v249_41);
  drop(v249_51);
  let v249_54: Space = intersect(&(*CONSTANT_50),&(v249_3));
  let v249_61: Space = if (&(v249_54)).is_empty() { Space::new() } else {
    let v274_44: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_3))))
    };
    let v274_55: Space = if (&(v274_44)).is_empty() { Space::new() } else {
      compose(&(v274_44),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_5))))
    };
    drop(v274_44);
    let v274_56: Space = if (&(v274_55)).is_empty() { Space::new() } else {
      compose(&(v274_55),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_9))))
    };
    let v274_57: Space = if (&(v274_56)).is_empty() { Space::new() } else {
      compose(&(v274_56),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v274_56);
    let v274_58: Space = if (&(v274_57)).is_empty() { Space::new() } else {
      compose(&(v274_57),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v274_57);
    let v274_59: Space = if (&(v274_58)).is_empty() { Space::new() } else {
      compose(&(v274_58),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v274_58);
    let v274_60: Space = if (&(v274_59)).is_empty() { Space::new() } else {
      compose(&(v274_59),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v274_59);
    compose(&(v249_54),&(v274_60))
  };
  drop(v249_54);
  let v249_62: Space = unite(&(v249_52),&(v249_61));
  drop(v249_52);
  drop(v249_61);
  let v249_64: Space = intersect(&(*CONSTANT_51),&(v249_3));
  let v249_70: Space = if (&(v249_64)).is_empty() { Space::new() } else {
    let v282_44: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_3))))
    };
    let v282_55: Space = if (&(v282_44)).is_empty() { Space::new() } else {
      compose(&(v282_44),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_5))))
    };
    drop(v282_44);
    let v282_65: Space = if (&(v282_55)).is_empty() { Space::new() } else {
      compose(&(v282_55),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v282_55);
    let v282_66: Space = if (&(v282_65)).is_empty() { Space::new() } else {
      compose(&(v282_65),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_11))))
    };
    let v282_67: Space = if (&(v282_66)).is_empty() { Space::new() } else {
      compose(&(v282_66),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v282_66);
    let v282_68: Space = if (&(v282_67)).is_empty() { Space::new() } else {
      compose(&(v282_67),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v282_67);
    let v282_69: Space = if (&(v282_68)).is_empty() { Space::new() } else {
      compose(&(v282_68),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v282_68);
    compose(&(v249_64),&(v282_69))
  };
  drop(v249_64);
  let v249_71: Space = unite(&(v249_62),&(v249_70));
  drop(v249_62);
  drop(v249_70);
  let v249_73: Space = intersect(&(*CONSTANT_52),&(v249_3));
  let v249_78: Space = if (&(v249_73)).is_empty() { Space::new() } else {
    let v290_44: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_3))))
    };
    let v290_55: Space = if (&(v290_44)).is_empty() { Space::new() } else {
      compose(&(v290_44),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_5))))
    };
    drop(v290_44);
    let v290_65: Space = if (&(v290_55)).is_empty() { Space::new() } else {
      compose(&(v290_55),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v290_55);
    let v290_74: Space = if (&(v290_65)).is_empty() { Space::new() } else {
      compose(&(v290_65),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v290_65);
    let v290_75: Space = if (&(v290_74)).is_empty() { Space::new() } else {
      compose(&(v290_74),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_13))))
    };
    let v290_76: Space = if (&(v290_75)).is_empty() { Space::new() } else {
      compose(&(v290_75),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v290_75);
    let v290_77: Space = if (&(v290_76)).is_empty() { Space::new() } else {
      compose(&(v290_76),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v290_76);
    compose(&(v249_73),&(v290_77))
  };
  drop(v249_73);
  let v249_79: Space = unite(&(v249_71),&(v249_78));
  drop(v249_71);
  drop(v249_78);
  let v249_81: Space = intersect(&(*CONSTANT_53),&(v249_3));
  let v249_85: Space = if (&(v249_81)).is_empty() { Space::new() } else {
    let v298_44: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_3))))
    };
    let v298_55: Space = if (&(v298_44)).is_empty() { Space::new() } else {
      compose(&(v298_44),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_5))))
    };
    drop(v298_44);
    let v298_65: Space = if (&(v298_55)).is_empty() { Space::new() } else {
      compose(&(v298_55),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v298_55);
    let v298_74: Space = if (&(v298_65)).is_empty() { Space::new() } else {
      compose(&(v298_65),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v298_65);
    let v298_82: Space = if (&(v298_74)).is_empty() { Space::new() } else {
      compose(&(v298_74),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v298_74);
    let v298_83: Space = if (&(v298_82)).is_empty() { Space::new() } else {
      compose(&(v298_82),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_15))))
    };
    let v298_84: Space = if (&(v298_83)).is_empty() { Space::new() } else {
      compose(&(v298_83),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_17))))
    };
    drop(v298_83);
    compose(&(v249_81),&(v298_84))
  };
  drop(v249_81);
  let v249_86: Space = unite(&(v249_79),&(v249_85));
  drop(v249_79);
  drop(v249_85);
  let v249_88: Space = intersect(&(*CONSTANT_54),&(v249_3));
  let v249_91: Space = if (&(v249_88)).is_empty() { Space::new() } else {
    let v306_44: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_3))))
    };
    let v306_55: Space = if (&(v306_44)).is_empty() { Space::new() } else {
      compose(&(v306_44),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_5))))
    };
    drop(v306_44);
    let v306_65: Space = if (&(v306_55)).is_empty() { Space::new() } else {
      compose(&(v306_55),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v306_55);
    let v306_74: Space = if (&(v306_65)).is_empty() { Space::new() } else {
      compose(&(v306_65),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v306_65);
    let v306_82: Space = if (&(v306_74)).is_empty() { Space::new() } else {
      compose(&(v306_74),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v306_74);
    let v306_89: Space = if (&(v306_82)).is_empty() { Space::new() } else {
      compose(&(v306_82),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v306_82);
    let v306_90: Space = if (&(v306_89)).is_empty() { Space::new() } else {
      compose(&(v306_89),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_17))))
    };
    compose(&(v249_88),&(v306_90))
  };
  drop(v249_88);
  let v249_92: Space = unite(&(v249_86),&(v249_91));
  drop(v249_86);
  drop(v249_91);
  let v249_94: Space = intersect(&(*CONSTANT_55),&(v249_3));
  drop(v249_3);
  let v249_96: Space = if (&(v249_94)).is_empty() { Space::new() } else {
    let v314_44: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_1)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_3))))
    };
    let v314_55: Space = if (&(v314_44)).is_empty() { Space::new() } else {
      compose(&(v314_44),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_5))))
    };
    drop(v314_44);
    let v314_65: Space = if (&(v314_55)).is_empty() { Space::new() } else {
      compose(&(v314_55),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_7))))
    };
    drop(v314_55);
    let v314_74: Space = if (&(v314_65)).is_empty() { Space::new() } else {
      compose(&(v314_65),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_9))))
    };
    drop(v314_65);
    let v314_82: Space = if (&(v314_74)).is_empty() { Space::new() } else {
      compose(&(v314_74),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_11))))
    };
    drop(v314_74);
    let v314_89: Space = if (&(v314_82)).is_empty() { Space::new() } else {
      compose(&(v314_82),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_13))))
    };
    drop(v314_82);
    let v314_95: Space = if (&(v314_89)).is_empty() { Space::new() } else {
      compose(&(v314_89),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_15))))
    };
    drop(v314_89);
    compose(&(v249_94),&(v314_95))
  };
  drop(v249_94);
  let v249_97: Space = unite(&(v249_92),&(v249_96));
  drop(v249_92);
  drop(v249_96);
  (v249_97).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v322_5 = Space::new();
  let mut v322_5_write = v322_5.write_zipper();
  let mut v322_5_cursor = (*s0).read_zipper();
  let v322_5_origin = v322_5_cursor.path().len();
  for v322_5_byte in v322_5_cursor.child_mask().iter() {
    v322_5_cursor.descend_to_existing_byte(v322_5_byte);
    {
    for v323_2_byte in v322_5_cursor.child_mask().iter() {
      v322_5_cursor.descend_to_existing_byte(v323_2_byte);
      {
      for v324_3_byte in v322_5_cursor.child_mask().iter() {
        v322_5_cursor.descend_to_existing_byte(v324_3_byte);
        {
        for v325_3_byte in v322_5_cursor.child_mask().iter() {
          v322_5_cursor.descend_to_existing_byte(v325_3_byte);
          {
          for v326_3_byte in v322_5_cursor.child_mask().iter() {
            v322_5_cursor.descend_to_existing_byte(v326_3_byte);
            {
            for v327_2_byte in v322_5_cursor.child_mask().iter() {
              v322_5_cursor.descend_to_existing_byte(v327_2_byte);
              {
              for v328_3_byte in v322_5_cursor.child_mask().iter() {
                v322_5_cursor.descend_to_existing_byte(v328_3_byte);
                {
                for v329_3_byte in v322_5_cursor.child_mask().iter() {
                  v322_5_cursor.descend_to_existing_byte(v329_3_byte);
                  {
                  let v330_3: Space = routine_29(c, &v322_5_cursor.path()[(v322_5_origin + 4)..(v322_5_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p0), &v322_5_cursor.path()[v322_5_origin..(v322_5_origin + 4)], &v322_5_cursor);
                  join_wrapped_into(&mut v322_5_write,&((v330_3).read_zipper()),&[]);
                  }
                  v322_5_cursor.ascend(1);
                }
                }
                v322_5_cursor.ascend(1);
              }
              }
              v322_5_cursor.ascend(1);
            }
            }
            v322_5_cursor.ascend(1);
          }
          }
          v322_5_cursor.ascend(1);
        }
        }
        v322_5_cursor.ascend(1);
      }
      }
      v322_5_cursor.ascend(1);
    }
    }
    v322_5_cursor.ascend(1);
  }
  drop(v322_5_cursor);
  drop(v322_5_write);
  (v322_5).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v331_5 = Space::new();
  let mut v331_5_write = v331_5.write_zipper();
  let mut v331_5_cursor = (*s0).read_zipper();
  let v331_5_origin = v331_5_cursor.path().len();
  for v331_5_byte in v331_5_cursor.child_mask().iter() {
    v331_5_cursor.descend_to_existing_byte(v331_5_byte);
    {
    for v332_2_byte in v331_5_cursor.child_mask().iter() {
      v331_5_cursor.descend_to_existing_byte(v332_2_byte);
      {
      for v333_3_byte in v331_5_cursor.child_mask().iter() {
        v331_5_cursor.descend_to_existing_byte(v333_3_byte);
        {
        for v334_3_byte in v331_5_cursor.child_mask().iter() {
          v331_5_cursor.descend_to_existing_byte(v334_3_byte);
          {
          for v335_3_byte in v331_5_cursor.child_mask().iter() {
            v331_5_cursor.descend_to_existing_byte(v335_3_byte);
            {
            for v336_2_byte in v331_5_cursor.child_mask().iter() {
              v331_5_cursor.descend_to_existing_byte(v336_2_byte);
              {
              for v337_3_byte in v331_5_cursor.child_mask().iter() {
                v331_5_cursor.descend_to_existing_byte(v337_3_byte);
                {
                for v338_3_byte in v331_5_cursor.child_mask().iter() {
                  v331_5_cursor.descend_to_existing_byte(v338_3_byte);
                  {
                  let v339_3: Space = routine_30(c, &v331_5_cursor.path()[(v331_5_origin + 4)..(v331_5_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p0), &v331_5_cursor.path()[v331_5_origin..(v331_5_origin + 4)], &v331_5_cursor);
                  join_wrapped_into(&mut v331_5_write,&((v339_3).read_zipper()),&[]);
                  }
                  v331_5_cursor.ascend(1);
                }
                }
                v331_5_cursor.ascend(1);
              }
              }
              v331_5_cursor.ascend(1);
            }
            }
            v331_5_cursor.ascend(1);
          }
          }
          v331_5_cursor.ascend(1);
        }
        }
        v331_5_cursor.ascend(1);
      }
      }
      v331_5_cursor.ascend(1);
    }
    }
    v331_5_cursor.ascend(1);
  }
  drop(v331_5_cursor);
  drop(v331_5_write);
  (v331_5).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v340_5 = Space::new();
  let mut v340_5_write = v340_5.write_zipper();
  let mut v340_5_cursor = (*s0).read_zipper();
  let v340_5_origin = v340_5_cursor.path().len();
  for v340_5_byte in v340_5_cursor.child_mask().iter() {
    v340_5_cursor.descend_to_existing_byte(v340_5_byte);
    {
    for v341_2_byte in v340_5_cursor.child_mask().iter() {
      v340_5_cursor.descend_to_existing_byte(v341_2_byte);
      {
      for v342_3_byte in v340_5_cursor.child_mask().iter() {
        v340_5_cursor.descend_to_existing_byte(v342_3_byte);
        {
        for v343_3_byte in v340_5_cursor.child_mask().iter() {
          v340_5_cursor.descend_to_existing_byte(v343_3_byte);
          {
          for v344_3_byte in v340_5_cursor.child_mask().iter() {
            v340_5_cursor.descend_to_existing_byte(v344_3_byte);
            {
            for v345_2_byte in v340_5_cursor.child_mask().iter() {
              v340_5_cursor.descend_to_existing_byte(v345_2_byte);
              {
              for v346_3_byte in v340_5_cursor.child_mask().iter() {
                v340_5_cursor.descend_to_existing_byte(v346_3_byte);
                {
                for v347_3_byte in v340_5_cursor.child_mask().iter() {
                  v340_5_cursor.descend_to_existing_byte(v347_3_byte);
                  {
                  let v348_3: Space = routine_31(c, &v340_5_cursor.path()[(v340_5_origin + 4)..(v340_5_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p0), &v340_5_cursor.path()[v340_5_origin..(v340_5_origin + 4)], &v340_5_cursor);
                  join_wrapped_into(&mut v340_5_write,&((v348_3).read_zipper()),&[]);
                  }
                  v340_5_cursor.ascend(1);
                }
                }
                v340_5_cursor.ascend(1);
              }
              }
              v340_5_cursor.ascend(1);
            }
            }
            v340_5_cursor.ascend(1);
          }
          }
          v340_5_cursor.ascend(1);
        }
        }
        v340_5_cursor.ascend(1);
      }
      }
      v340_5_cursor.ascend(1);
    }
    }
    v340_5_cursor.ascend(1);
  }
  drop(v340_5_cursor);
  drop(v340_5_write);
  (v340_5).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v349_5 = Space::new();
  let mut v349_5_write = v349_5.write_zipper();
  let mut v349_5_cursor = (*s0).read_zipper();
  let v349_5_origin = v349_5_cursor.path().len();
  for v349_5_byte in v349_5_cursor.child_mask().iter() {
    v349_5_cursor.descend_to_existing_byte(v349_5_byte);
    {
    for v350_2_byte in v349_5_cursor.child_mask().iter() {
      v349_5_cursor.descend_to_existing_byte(v350_2_byte);
      {
      for v351_3_byte in v349_5_cursor.child_mask().iter() {
        v349_5_cursor.descend_to_existing_byte(v351_3_byte);
        {
        for v352_3_byte in v349_5_cursor.child_mask().iter() {
          v349_5_cursor.descend_to_existing_byte(v352_3_byte);
          {
          for v353_3_byte in v349_5_cursor.child_mask().iter() {
            v349_5_cursor.descend_to_existing_byte(v353_3_byte);
            {
            for v354_2_byte in v349_5_cursor.child_mask().iter() {
              v349_5_cursor.descend_to_existing_byte(v354_2_byte);
              {
              for v355_3_byte in v349_5_cursor.child_mask().iter() {
                v349_5_cursor.descend_to_existing_byte(v355_3_byte);
                {
                for v356_3_byte in v349_5_cursor.child_mask().iter() {
                  v349_5_cursor.descend_to_existing_byte(v356_3_byte);
                  {
                  let v357_3: Space = routine_32(c, &v349_5_cursor.path()[(v349_5_origin + 4)..(v349_5_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p0), &v349_5_cursor.path()[v349_5_origin..(v349_5_origin + 4)], &v349_5_cursor);
                  join_wrapped_into(&mut v349_5_write,&((v357_3).read_zipper()),&[]);
                  }
                  v349_5_cursor.ascend(1);
                }
                }
                v349_5_cursor.ascend(1);
              }
              }
              v349_5_cursor.ascend(1);
            }
            }
            v349_5_cursor.ascend(1);
          }
          }
          v349_5_cursor.ascend(1);
        }
        }
        v349_5_cursor.ascend(1);
      }
      }
      v349_5_cursor.ascend(1);
    }
    }
    v349_5_cursor.ascend(1);
  }
  drop(v349_5_cursor);
  drop(v349_5_write);
  (v349_5).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v358_5 = Space::new();
  let mut v358_5_write = v358_5.write_zipper();
  let mut v358_5_cursor = (*s0).read_zipper();
  let v358_5_origin = v358_5_cursor.path().len();
  for v358_5_byte in v358_5_cursor.child_mask().iter() {
    v358_5_cursor.descend_to_existing_byte(v358_5_byte);
    {
    for v359_2_byte in v358_5_cursor.child_mask().iter() {
      v358_5_cursor.descend_to_existing_byte(v359_2_byte);
      {
      for v360_3_byte in v358_5_cursor.child_mask().iter() {
        v358_5_cursor.descend_to_existing_byte(v360_3_byte);
        {
        for v361_3_byte in v358_5_cursor.child_mask().iter() {
          v358_5_cursor.descend_to_existing_byte(v361_3_byte);
          {
          for v362_3_byte in v358_5_cursor.child_mask().iter() {
            v358_5_cursor.descend_to_existing_byte(v362_3_byte);
            {
            for v363_2_byte in v358_5_cursor.child_mask().iter() {
              v358_5_cursor.descend_to_existing_byte(v363_2_byte);
              {
              for v364_3_byte in v358_5_cursor.child_mask().iter() {
                v358_5_cursor.descend_to_existing_byte(v364_3_byte);
                {
                for v365_3_byte in v358_5_cursor.child_mask().iter() {
                  v358_5_cursor.descend_to_existing_byte(v365_3_byte);
                  {
                  let v366_3: Space = routine_33(c, &v358_5_cursor.path()[(v358_5_origin + 4)..(v358_5_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p0), &v358_5_cursor.path()[v358_5_origin..(v358_5_origin + 4)], &v358_5_cursor);
                  join_wrapped_into(&mut v358_5_write,&((v366_3).read_zipper()),&[]);
                  }
                  v358_5_cursor.ascend(1);
                }
                }
                v358_5_cursor.ascend(1);
              }
              }
              v358_5_cursor.ascend(1);
            }
            }
            v358_5_cursor.ascend(1);
          }
          }
          v358_5_cursor.ascend(1);
        }
        }
        v358_5_cursor.ascend(1);
      }
      }
      v358_5_cursor.ascend(1);
    }
    }
    v358_5_cursor.ascend(1);
  }
  drop(v358_5_cursor);
  drop(v358_5_write);
  (v358_5).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v367_5 = Space::new();
  let mut v367_5_write = v367_5.write_zipper();
  let mut v367_5_cursor = (*s0).read_zipper();
  let v367_5_origin = v367_5_cursor.path().len();
  for v367_5_byte in v367_5_cursor.child_mask().iter() {
    v367_5_cursor.descend_to_existing_byte(v367_5_byte);
    {
    for v368_2_byte in v367_5_cursor.child_mask().iter() {
      v367_5_cursor.descend_to_existing_byte(v368_2_byte);
      {
      for v369_3_byte in v367_5_cursor.child_mask().iter() {
        v367_5_cursor.descend_to_existing_byte(v369_3_byte);
        {
        for v370_3_byte in v367_5_cursor.child_mask().iter() {
          v367_5_cursor.descend_to_existing_byte(v370_3_byte);
          {
          for v371_3_byte in v367_5_cursor.child_mask().iter() {
            v367_5_cursor.descend_to_existing_byte(v371_3_byte);
            {
            for v372_2_byte in v367_5_cursor.child_mask().iter() {
              v367_5_cursor.descend_to_existing_byte(v372_2_byte);
              {
              for v373_3_byte in v367_5_cursor.child_mask().iter() {
                v367_5_cursor.descend_to_existing_byte(v373_3_byte);
                {
                for v374_3_byte in v367_5_cursor.child_mask().iter() {
                  v367_5_cursor.descend_to_existing_byte(v374_3_byte);
                  {
                  let v375_3: Space = routine_34(c, &v367_5_cursor.path()[(v367_5_origin + 4)..(v367_5_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p0), &v367_5_cursor.path()[v367_5_origin..(v367_5_origin + 4)], &v367_5_cursor);
                  join_wrapped_into(&mut v367_5_write,&((v375_3).read_zipper()),&[]);
                  }
                  v367_5_cursor.ascend(1);
                }
                }
                v367_5_cursor.ascend(1);
              }
              }
              v367_5_cursor.ascend(1);
            }
            }
            v367_5_cursor.ascend(1);
          }
          }
          v367_5_cursor.ascend(1);
        }
        }
        v367_5_cursor.ascend(1);
      }
      }
      v367_5_cursor.ascend(1);
    }
    }
    v367_5_cursor.ascend(1);
  }
  drop(v367_5_cursor);
  drop(v367_5_write);
  (v367_5).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v376_5 = Space::new();
  let mut v376_5_write = v376_5.write_zipper();
  let mut v376_5_cursor = (*s0).read_zipper();
  let v376_5_origin = v376_5_cursor.path().len();
  for v376_5_byte in v376_5_cursor.child_mask().iter() {
    v376_5_cursor.descend_to_existing_byte(v376_5_byte);
    {
    for v377_2_byte in v376_5_cursor.child_mask().iter() {
      v376_5_cursor.descend_to_existing_byte(v377_2_byte);
      {
      for v378_3_byte in v376_5_cursor.child_mask().iter() {
        v376_5_cursor.descend_to_existing_byte(v378_3_byte);
        {
        for v379_3_byte in v376_5_cursor.child_mask().iter() {
          v376_5_cursor.descend_to_existing_byte(v379_3_byte);
          {
          for v380_3_byte in v376_5_cursor.child_mask().iter() {
            v376_5_cursor.descend_to_existing_byte(v380_3_byte);
            {
            for v381_2_byte in v376_5_cursor.child_mask().iter() {
              v376_5_cursor.descend_to_existing_byte(v381_2_byte);
              {
              for v382_3_byte in v376_5_cursor.child_mask().iter() {
                v376_5_cursor.descend_to_existing_byte(v382_3_byte);
                {
                for v383_3_byte in v376_5_cursor.child_mask().iter() {
                  v376_5_cursor.descend_to_existing_byte(v383_3_byte);
                  {
                  let v384_3: Space = routine_35(c, &v376_5_cursor.path()[(v376_5_origin + 4)..(v376_5_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p0), &v376_5_cursor.path()[v376_5_origin..(v376_5_origin + 4)], &v376_5_cursor);
                  join_wrapped_into(&mut v376_5_write,&((v384_3).read_zipper()),&[]);
                  }
                  v376_5_cursor.ascend(1);
                }
                }
                v376_5_cursor.ascend(1);
              }
              }
              v376_5_cursor.ascend(1);
            }
            }
            v376_5_cursor.ascend(1);
          }
          }
          v376_5_cursor.ascend(1);
        }
        }
        v376_5_cursor.ascend(1);
      }
      }
      v376_5_cursor.ascend(1);
    }
    }
    v376_5_cursor.ascend(1);
  }
  drop(v376_5_cursor);
  drop(v376_5_write);
  (v376_5).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v385_5 = Space::new();
  let mut v385_5_write = v385_5.write_zipper();
  let mut v385_5_cursor = (*s0).read_zipper();
  let v385_5_origin = v385_5_cursor.path().len();
  for v385_5_byte in v385_5_cursor.child_mask().iter() {
    v385_5_cursor.descend_to_existing_byte(v385_5_byte);
    {
    for v386_2_byte in v385_5_cursor.child_mask().iter() {
      v385_5_cursor.descend_to_existing_byte(v386_2_byte);
      {
      for v387_3_byte in v385_5_cursor.child_mask().iter() {
        v385_5_cursor.descend_to_existing_byte(v387_3_byte);
        {
        for v388_3_byte in v385_5_cursor.child_mask().iter() {
          v385_5_cursor.descend_to_existing_byte(v388_3_byte);
          {
          for v389_3_byte in v385_5_cursor.child_mask().iter() {
            v385_5_cursor.descend_to_existing_byte(v389_3_byte);
            {
            for v390_2_byte in v385_5_cursor.child_mask().iter() {
              v385_5_cursor.descend_to_existing_byte(v390_2_byte);
              {
              for v391_3_byte in v385_5_cursor.child_mask().iter() {
                v385_5_cursor.descend_to_existing_byte(v391_3_byte);
                {
                for v392_3_byte in v385_5_cursor.child_mask().iter() {
                  v385_5_cursor.descend_to_existing_byte(v392_3_byte);
                  {
                  let v393_3: Space = routine_36(c, &v385_5_cursor.path()[(v385_5_origin + 4)..(v385_5_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p0), &v385_5_cursor.path()[v385_5_origin..(v385_5_origin + 4)], &v385_5_cursor);
                  join_wrapped_into(&mut v385_5_write,&((v393_3).read_zipper()),&[]);
                  }
                  v385_5_cursor.ascend(1);
                }
                }
                v385_5_cursor.ascend(1);
              }
              }
              v385_5_cursor.ascend(1);
            }
            }
            v385_5_cursor.ascend(1);
          }
          }
          v385_5_cursor.ascend(1);
        }
        }
        v385_5_cursor.ascend(1);
      }
      }
      v385_5_cursor.ascend(1);
    }
    }
    v385_5_cursor.ascend(1);
  }
  drop(v385_5_cursor);
  drop(v385_5_write);
  (v385_5).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v394_5 = Space::new();
  let mut v394_5_write = v394_5.write_zipper();
  let mut v394_5_cursor = (*s0).read_zipper();
  let v394_5_origin = v394_5_cursor.path().len();
  for v394_5_byte in v394_5_cursor.child_mask().iter() {
    v394_5_cursor.descend_to_existing_byte(v394_5_byte);
    {
    for v395_2_byte in v394_5_cursor.child_mask().iter() {
      v394_5_cursor.descend_to_existing_byte(v395_2_byte);
      {
      for v396_3_byte in v394_5_cursor.child_mask().iter() {
        v394_5_cursor.descend_to_existing_byte(v396_3_byte);
        {
        for v397_3_byte in v394_5_cursor.child_mask().iter() {
          v394_5_cursor.descend_to_existing_byte(v397_3_byte);
          {
          for v398_3_byte in v394_5_cursor.child_mask().iter() {
            v394_5_cursor.descend_to_existing_byte(v398_3_byte);
            {
            for v399_2_byte in v394_5_cursor.child_mask().iter() {
              v394_5_cursor.descend_to_existing_byte(v399_2_byte);
              {
              for v400_3_byte in v394_5_cursor.child_mask().iter() {
                v394_5_cursor.descend_to_existing_byte(v400_3_byte);
                {
                for v401_3_byte in v394_5_cursor.child_mask().iter() {
                  v394_5_cursor.descend_to_existing_byte(v401_3_byte);
                  {
                  let v402_3: Space = routine_37(c, &v394_5_cursor.path()[(v394_5_origin + 4)..(v394_5_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p0), &v394_5_cursor.path()[v394_5_origin..(v394_5_origin + 4)], &v394_5_cursor);
                  join_wrapped_into(&mut v394_5_write,&((v402_3).read_zipper()),&[]);
                  }
                  v394_5_cursor.ascend(1);
                }
                }
                v394_5_cursor.ascend(1);
              }
              }
              v394_5_cursor.ascend(1);
            }
            }
            v394_5_cursor.ascend(1);
          }
          }
          v394_5_cursor.ascend(1);
        }
        }
        v394_5_cursor.ascend(1);
      }
      }
      v394_5_cursor.ascend(1);
    }
    }
    v394_5_cursor.ascend(1);
  }
  drop(v394_5_cursor);
  drop(v394_5_write);
  (v394_5).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v403_7 = Space::new();
  let mut v403_7_write = v403_7.write_zipper();
  let mut v403_7_cursor = (*s0).read_zipper();
  let v403_7_origin = v403_7_cursor.path().len();
  for v403_7_byte in v403_7_cursor.child_mask().iter() {
    v403_7_cursor.descend_to_existing_byte(v403_7_byte);
    {
    for v404_2_byte in v403_7_cursor.child_mask().iter() {
      v403_7_cursor.descend_to_existing_byte(v404_2_byte);
      {
      for v405_3_byte in v403_7_cursor.child_mask().iter() {
        v403_7_cursor.descend_to_existing_byte(v405_3_byte);
        {
        for v406_3_byte in v403_7_cursor.child_mask().iter() {
          v403_7_cursor.descend_to_existing_byte(v406_3_byte);
          {
          for v407_3_byte in v403_7_cursor.child_mask().iter() {
            v403_7_cursor.descend_to_existing_byte(v407_3_byte);
            {
            for v408_2_byte in v403_7_cursor.child_mask().iter() {
              v403_7_cursor.descend_to_existing_byte(v408_2_byte);
              {
              for v409_3_byte in v403_7_cursor.child_mask().iter() {
                v403_7_cursor.descend_to_existing_byte(v409_3_byte);
                {
                for v410_3_byte in v403_7_cursor.child_mask().iter() {
                  v403_7_cursor.descend_to_existing_byte(v410_3_byte);
                  {
                  let v411_3: Space = routine_38(c, &v403_7_cursor.path()[(v403_7_origin + 4)..(v403_7_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v403_7_cursor.path()[v403_7_origin..(v403_7_origin + 4)], &v403_7_cursor);
                  join_wrapped_into(&mut v403_7_write,&((v411_3).read_zipper()),&[]);
                  }
                  v403_7_cursor.ascend(1);
                }
                }
                v403_7_cursor.ascend(1);
              }
              }
              v403_7_cursor.ascend(1);
            }
            }
            v403_7_cursor.ascend(1);
          }
          }
          v403_7_cursor.ascend(1);
        }
        }
        v403_7_cursor.ascend(1);
      }
      }
      v403_7_cursor.ascend(1);
    }
    }
    v403_7_cursor.ascend(1);
  }
  drop(v403_7_cursor);
  drop(v403_7_write);
  (v403_7).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v412_7 = Space::new();
  let mut v412_7_write = v412_7.write_zipper();
  let mut v412_7_cursor = (*s0).read_zipper();
  let v412_7_origin = v412_7_cursor.path().len();
  for v412_7_byte in v412_7_cursor.child_mask().iter() {
    v412_7_cursor.descend_to_existing_byte(v412_7_byte);
    {
    for v413_2_byte in v412_7_cursor.child_mask().iter() {
      v412_7_cursor.descend_to_existing_byte(v413_2_byte);
      {
      for v414_3_byte in v412_7_cursor.child_mask().iter() {
        v412_7_cursor.descend_to_existing_byte(v414_3_byte);
        {
        for v415_3_byte in v412_7_cursor.child_mask().iter() {
          v412_7_cursor.descend_to_existing_byte(v415_3_byte);
          {
          for v416_3_byte in v412_7_cursor.child_mask().iter() {
            v412_7_cursor.descend_to_existing_byte(v416_3_byte);
            {
            for v417_2_byte in v412_7_cursor.child_mask().iter() {
              v412_7_cursor.descend_to_existing_byte(v417_2_byte);
              {
              for v418_3_byte in v412_7_cursor.child_mask().iter() {
                v412_7_cursor.descend_to_existing_byte(v418_3_byte);
                {
                for v419_3_byte in v412_7_cursor.child_mask().iter() {
                  v412_7_cursor.descend_to_existing_byte(v419_3_byte);
                  {
                  let v420_3: Space = routine_39(c, &v412_7_cursor.path()[(v412_7_origin + 4)..(v412_7_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v412_7_cursor.path()[v412_7_origin..(v412_7_origin + 4)], &v412_7_cursor);
                  join_wrapped_into(&mut v412_7_write,&((v420_3).read_zipper()),&[]);
                  }
                  v412_7_cursor.ascend(1);
                }
                }
                v412_7_cursor.ascend(1);
              }
              }
              v412_7_cursor.ascend(1);
            }
            }
            v412_7_cursor.ascend(1);
          }
          }
          v412_7_cursor.ascend(1);
        }
        }
        v412_7_cursor.ascend(1);
      }
      }
      v412_7_cursor.ascend(1);
    }
    }
    v412_7_cursor.ascend(1);
  }
  drop(v412_7_cursor);
  drop(v412_7_write);
  (v412_7).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v421_7 = Space::new();
  let mut v421_7_write = v421_7.write_zipper();
  let mut v421_7_cursor = (*s0).read_zipper();
  let v421_7_origin = v421_7_cursor.path().len();
  for v421_7_byte in v421_7_cursor.child_mask().iter() {
    v421_7_cursor.descend_to_existing_byte(v421_7_byte);
    {
    for v422_2_byte in v421_7_cursor.child_mask().iter() {
      v421_7_cursor.descend_to_existing_byte(v422_2_byte);
      {
      for v423_3_byte in v421_7_cursor.child_mask().iter() {
        v421_7_cursor.descend_to_existing_byte(v423_3_byte);
        {
        for v424_3_byte in v421_7_cursor.child_mask().iter() {
          v421_7_cursor.descend_to_existing_byte(v424_3_byte);
          {
          for v425_3_byte in v421_7_cursor.child_mask().iter() {
            v421_7_cursor.descend_to_existing_byte(v425_3_byte);
            {
            for v426_2_byte in v421_7_cursor.child_mask().iter() {
              v421_7_cursor.descend_to_existing_byte(v426_2_byte);
              {
              for v427_3_byte in v421_7_cursor.child_mask().iter() {
                v421_7_cursor.descend_to_existing_byte(v427_3_byte);
                {
                for v428_3_byte in v421_7_cursor.child_mask().iter() {
                  v421_7_cursor.descend_to_existing_byte(v428_3_byte);
                  {
                  let v429_3: Space = routine_40(c, &v421_7_cursor.path()[(v421_7_origin + 4)..(v421_7_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v421_7_cursor.path()[v421_7_origin..(v421_7_origin + 4)], &v421_7_cursor);
                  join_wrapped_into(&mut v421_7_write,&((v429_3).read_zipper()),&[]);
                  }
                  v421_7_cursor.ascend(1);
                }
                }
                v421_7_cursor.ascend(1);
              }
              }
              v421_7_cursor.ascend(1);
            }
            }
            v421_7_cursor.ascend(1);
          }
          }
          v421_7_cursor.ascend(1);
        }
        }
        v421_7_cursor.ascend(1);
      }
      }
      v421_7_cursor.ascend(1);
    }
    }
    v421_7_cursor.ascend(1);
  }
  drop(v421_7_cursor);
  drop(v421_7_write);
  (v421_7).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v430_7 = Space::new();
  let mut v430_7_write = v430_7.write_zipper();
  let mut v430_7_cursor = (*s0).read_zipper();
  let v430_7_origin = v430_7_cursor.path().len();
  for v430_7_byte in v430_7_cursor.child_mask().iter() {
    v430_7_cursor.descend_to_existing_byte(v430_7_byte);
    {
    for v431_2_byte in v430_7_cursor.child_mask().iter() {
      v430_7_cursor.descend_to_existing_byte(v431_2_byte);
      {
      for v432_3_byte in v430_7_cursor.child_mask().iter() {
        v430_7_cursor.descend_to_existing_byte(v432_3_byte);
        {
        for v433_3_byte in v430_7_cursor.child_mask().iter() {
          v430_7_cursor.descend_to_existing_byte(v433_3_byte);
          {
          for v434_3_byte in v430_7_cursor.child_mask().iter() {
            v430_7_cursor.descend_to_existing_byte(v434_3_byte);
            {
            for v435_2_byte in v430_7_cursor.child_mask().iter() {
              v430_7_cursor.descend_to_existing_byte(v435_2_byte);
              {
              for v436_3_byte in v430_7_cursor.child_mask().iter() {
                v430_7_cursor.descend_to_existing_byte(v436_3_byte);
                {
                for v437_3_byte in v430_7_cursor.child_mask().iter() {
                  v430_7_cursor.descend_to_existing_byte(v437_3_byte);
                  {
                  let v438_3: Space = routine_41(c, &v430_7_cursor.path()[(v430_7_origin + 4)..(v430_7_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v430_7_cursor.path()[v430_7_origin..(v430_7_origin + 4)], &v430_7_cursor);
                  join_wrapped_into(&mut v430_7_write,&((v438_3).read_zipper()),&[]);
                  }
                  v430_7_cursor.ascend(1);
                }
                }
                v430_7_cursor.ascend(1);
              }
              }
              v430_7_cursor.ascend(1);
            }
            }
            v430_7_cursor.ascend(1);
          }
          }
          v430_7_cursor.ascend(1);
        }
        }
        v430_7_cursor.ascend(1);
      }
      }
      v430_7_cursor.ascend(1);
    }
    }
    v430_7_cursor.ascend(1);
  }
  drop(v430_7_cursor);
  drop(v430_7_write);
  (v430_7).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v439_7 = Space::new();
  let mut v439_7_write = v439_7.write_zipper();
  let mut v439_7_cursor = (*s0).read_zipper();
  let v439_7_origin = v439_7_cursor.path().len();
  for v439_7_byte in v439_7_cursor.child_mask().iter() {
    v439_7_cursor.descend_to_existing_byte(v439_7_byte);
    {
    for v440_2_byte in v439_7_cursor.child_mask().iter() {
      v439_7_cursor.descend_to_existing_byte(v440_2_byte);
      {
      for v441_3_byte in v439_7_cursor.child_mask().iter() {
        v439_7_cursor.descend_to_existing_byte(v441_3_byte);
        {
        for v442_3_byte in v439_7_cursor.child_mask().iter() {
          v439_7_cursor.descend_to_existing_byte(v442_3_byte);
          {
          for v443_3_byte in v439_7_cursor.child_mask().iter() {
            v439_7_cursor.descend_to_existing_byte(v443_3_byte);
            {
            for v444_2_byte in v439_7_cursor.child_mask().iter() {
              v439_7_cursor.descend_to_existing_byte(v444_2_byte);
              {
              for v445_3_byte in v439_7_cursor.child_mask().iter() {
                v439_7_cursor.descend_to_existing_byte(v445_3_byte);
                {
                for v446_3_byte in v439_7_cursor.child_mask().iter() {
                  v439_7_cursor.descend_to_existing_byte(v446_3_byte);
                  {
                  let v447_3: Space = routine_42(c, &v439_7_cursor.path()[(v439_7_origin + 4)..(v439_7_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v439_7_cursor.path()[v439_7_origin..(v439_7_origin + 4)], &v439_7_cursor);
                  join_wrapped_into(&mut v439_7_write,&((v447_3).read_zipper()),&[]);
                  }
                  v439_7_cursor.ascend(1);
                }
                }
                v439_7_cursor.ascend(1);
              }
              }
              v439_7_cursor.ascend(1);
            }
            }
            v439_7_cursor.ascend(1);
          }
          }
          v439_7_cursor.ascend(1);
        }
        }
        v439_7_cursor.ascend(1);
      }
      }
      v439_7_cursor.ascend(1);
    }
    }
    v439_7_cursor.ascend(1);
  }
  drop(v439_7_cursor);
  drop(v439_7_write);
  (v439_7).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v448_7 = Space::new();
  let mut v448_7_write = v448_7.write_zipper();
  let mut v448_7_cursor = (*s0).read_zipper();
  let v448_7_origin = v448_7_cursor.path().len();
  for v448_7_byte in v448_7_cursor.child_mask().iter() {
    v448_7_cursor.descend_to_existing_byte(v448_7_byte);
    {
    for v449_2_byte in v448_7_cursor.child_mask().iter() {
      v448_7_cursor.descend_to_existing_byte(v449_2_byte);
      {
      for v450_3_byte in v448_7_cursor.child_mask().iter() {
        v448_7_cursor.descend_to_existing_byte(v450_3_byte);
        {
        for v451_3_byte in v448_7_cursor.child_mask().iter() {
          v448_7_cursor.descend_to_existing_byte(v451_3_byte);
          {
          for v452_3_byte in v448_7_cursor.child_mask().iter() {
            v448_7_cursor.descend_to_existing_byte(v452_3_byte);
            {
            for v453_2_byte in v448_7_cursor.child_mask().iter() {
              v448_7_cursor.descend_to_existing_byte(v453_2_byte);
              {
              for v454_3_byte in v448_7_cursor.child_mask().iter() {
                v448_7_cursor.descend_to_existing_byte(v454_3_byte);
                {
                for v455_3_byte in v448_7_cursor.child_mask().iter() {
                  v448_7_cursor.descend_to_existing_byte(v455_3_byte);
                  {
                  let v456_3: Space = routine_43(c, &v448_7_cursor.path()[(v448_7_origin + 4)..(v448_7_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v448_7_cursor.path()[v448_7_origin..(v448_7_origin + 4)], &v448_7_cursor);
                  join_wrapped_into(&mut v448_7_write,&((v456_3).read_zipper()),&[]);
                  }
                  v448_7_cursor.ascend(1);
                }
                }
                v448_7_cursor.ascend(1);
              }
              }
              v448_7_cursor.ascend(1);
            }
            }
            v448_7_cursor.ascend(1);
          }
          }
          v448_7_cursor.ascend(1);
        }
        }
        v448_7_cursor.ascend(1);
      }
      }
      v448_7_cursor.ascend(1);
    }
    }
    v448_7_cursor.ascend(1);
  }
  drop(v448_7_cursor);
  drop(v448_7_write);
  (v448_7).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v457_7 = Space::new();
  let mut v457_7_write = v457_7.write_zipper();
  let mut v457_7_cursor = (*s0).read_zipper();
  let v457_7_origin = v457_7_cursor.path().len();
  for v457_7_byte in v457_7_cursor.child_mask().iter() {
    v457_7_cursor.descend_to_existing_byte(v457_7_byte);
    {
    for v458_2_byte in v457_7_cursor.child_mask().iter() {
      v457_7_cursor.descend_to_existing_byte(v458_2_byte);
      {
      for v459_3_byte in v457_7_cursor.child_mask().iter() {
        v457_7_cursor.descend_to_existing_byte(v459_3_byte);
        {
        for v460_3_byte in v457_7_cursor.child_mask().iter() {
          v457_7_cursor.descend_to_existing_byte(v460_3_byte);
          {
          for v461_3_byte in v457_7_cursor.child_mask().iter() {
            v457_7_cursor.descend_to_existing_byte(v461_3_byte);
            {
            for v462_2_byte in v457_7_cursor.child_mask().iter() {
              v457_7_cursor.descend_to_existing_byte(v462_2_byte);
              {
              for v463_3_byte in v457_7_cursor.child_mask().iter() {
                v457_7_cursor.descend_to_existing_byte(v463_3_byte);
                {
                for v464_3_byte in v457_7_cursor.child_mask().iter() {
                  v457_7_cursor.descend_to_existing_byte(v464_3_byte);
                  {
                  let v465_3: Space = routine_44(c, &v457_7_cursor.path()[(v457_7_origin + 4)..(v457_7_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v457_7_cursor.path()[v457_7_origin..(v457_7_origin + 4)], &v457_7_cursor);
                  join_wrapped_into(&mut v457_7_write,&((v465_3).read_zipper()),&[]);
                  }
                  v457_7_cursor.ascend(1);
                }
                }
                v457_7_cursor.ascend(1);
              }
              }
              v457_7_cursor.ascend(1);
            }
            }
            v457_7_cursor.ascend(1);
          }
          }
          v457_7_cursor.ascend(1);
        }
        }
        v457_7_cursor.ascend(1);
      }
      }
      v457_7_cursor.ascend(1);
    }
    }
    v457_7_cursor.ascend(1);
  }
  drop(v457_7_cursor);
  drop(v457_7_write);
  (v457_7).clone()
}

fn routine_36(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v466_7 = Space::new();
  let mut v466_7_write = v466_7.write_zipper();
  let mut v466_7_cursor = (*s0).read_zipper();
  let v466_7_origin = v466_7_cursor.path().len();
  for v466_7_byte in v466_7_cursor.child_mask().iter() {
    v466_7_cursor.descend_to_existing_byte(v466_7_byte);
    {
    for v467_2_byte in v466_7_cursor.child_mask().iter() {
      v466_7_cursor.descend_to_existing_byte(v467_2_byte);
      {
      for v468_3_byte in v466_7_cursor.child_mask().iter() {
        v466_7_cursor.descend_to_existing_byte(v468_3_byte);
        {
        for v469_3_byte in v466_7_cursor.child_mask().iter() {
          v466_7_cursor.descend_to_existing_byte(v469_3_byte);
          {
          for v470_3_byte in v466_7_cursor.child_mask().iter() {
            v466_7_cursor.descend_to_existing_byte(v470_3_byte);
            {
            for v471_2_byte in v466_7_cursor.child_mask().iter() {
              v466_7_cursor.descend_to_existing_byte(v471_2_byte);
              {
              for v472_3_byte in v466_7_cursor.child_mask().iter() {
                v466_7_cursor.descend_to_existing_byte(v472_3_byte);
                {
                for v473_3_byte in v466_7_cursor.child_mask().iter() {
                  v466_7_cursor.descend_to_existing_byte(v473_3_byte);
                  {
                  let v474_3: Space = routine_45(c, &v466_7_cursor.path()[(v466_7_origin + 4)..(v466_7_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v466_7_cursor.path()[v466_7_origin..(v466_7_origin + 4)], &v466_7_cursor);
                  join_wrapped_into(&mut v466_7_write,&((v474_3).read_zipper()),&[]);
                  }
                  v466_7_cursor.ascend(1);
                }
                }
                v466_7_cursor.ascend(1);
              }
              }
              v466_7_cursor.ascend(1);
            }
            }
            v466_7_cursor.ascend(1);
          }
          }
          v466_7_cursor.ascend(1);
        }
        }
        v466_7_cursor.ascend(1);
      }
      }
      v466_7_cursor.ascend(1);
    }
    }
    v466_7_cursor.ascend(1);
  }
  drop(v466_7_cursor);
  drop(v466_7_write);
  (v466_7).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v475_7 = Space::new();
  let mut v475_7_write = v475_7.write_zipper();
  let mut v475_7_cursor = (*s0).read_zipper();
  let v475_7_origin = v475_7_cursor.path().len();
  for v475_7_byte in v475_7_cursor.child_mask().iter() {
    v475_7_cursor.descend_to_existing_byte(v475_7_byte);
    {
    for v476_2_byte in v475_7_cursor.child_mask().iter() {
      v475_7_cursor.descend_to_existing_byte(v476_2_byte);
      {
      for v477_3_byte in v475_7_cursor.child_mask().iter() {
        v475_7_cursor.descend_to_existing_byte(v477_3_byte);
        {
        for v478_3_byte in v475_7_cursor.child_mask().iter() {
          v475_7_cursor.descend_to_existing_byte(v478_3_byte);
          {
          for v479_3_byte in v475_7_cursor.child_mask().iter() {
            v475_7_cursor.descend_to_existing_byte(v479_3_byte);
            {
            for v480_2_byte in v475_7_cursor.child_mask().iter() {
              v475_7_cursor.descend_to_existing_byte(v480_2_byte);
              {
              for v481_3_byte in v475_7_cursor.child_mask().iter() {
                v475_7_cursor.descend_to_existing_byte(v481_3_byte);
                {
                for v482_3_byte in v475_7_cursor.child_mask().iter() {
                  v475_7_cursor.descend_to_existing_byte(v482_3_byte);
                  {
                  let v483_3: Space = routine_46(c, &v475_7_cursor.path()[(v475_7_origin + 4)..(v475_7_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v475_7_cursor.path()[v475_7_origin..(v475_7_origin + 4)], &v475_7_cursor);
                  join_wrapped_into(&mut v475_7_write,&((v483_3).read_zipper()),&[]);
                  }
                  v475_7_cursor.ascend(1);
                }
                }
                v475_7_cursor.ascend(1);
              }
              }
              v475_7_cursor.ascend(1);
            }
            }
            v475_7_cursor.ascend(1);
          }
          }
          v475_7_cursor.ascend(1);
        }
        }
        v475_7_cursor.ascend(1);
      }
      }
      v475_7_cursor.ascend(1);
    }
    }
    v475_7_cursor.ascend(1);
  }
  drop(v475_7_cursor);
  drop(v475_7_write);
  (v475_7).clone()
}

fn routine_38(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v484_11: Path = concat_path(&(*CONSTANT_3),&(*p1));
  let v484_12: Space = singleton(&(v484_11));
  drop(v484_11);
  let v484_13: Space = unite(&(*CONSTANT_73),&(v484_12));
  drop(v484_12);
  let v484_15: Path = concat_path(&(*CONSTANT_5),&(*p2));
  let v484_16: Space = singleton(&(v484_15));
  drop(v484_15);
  let v484_17: Space = unite(&(v484_13),&(v484_16));
  drop(v484_13);
  drop(v484_16);
  let v484_19: Path = concat_path(&(*CONSTANT_7),&(*p3));
  let v484_20: Space = singleton(&(v484_19));
  drop(v484_19);
  let v484_21: Space = unite(&(v484_17),&(v484_20));
  drop(v484_17);
  drop(v484_20);
  let v484_23: Path = concat_path(&(*CONSTANT_9),&(*p4));
  let v484_24: Space = singleton(&(v484_23));
  drop(v484_23);
  let v484_25: Space = unite(&(v484_21),&(v484_24));
  drop(v484_21);
  drop(v484_24);
  let v484_27: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v484_28: Space = singleton(&(v484_27));
  drop(v484_27);
  let v484_29: Space = unite(&(v484_25),&(v484_28));
  drop(v484_25);
  drop(v484_28);
  let v484_31: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v484_32: Space = singleton(&(v484_31));
  drop(v484_31);
  let v484_33: Space = unite(&(v484_29),&(v484_32));
  drop(v484_29);
  drop(v484_32);
  let v484_35: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v484_36: Space = singleton(&(v484_35));
  drop(v484_35);
  let v484_37: Space = unite(&(v484_33),&(v484_36));
  drop(v484_33);
  drop(v484_36);
  let v484_39: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v484_40: Space = singleton(&(v484_39));
  drop(v484_39);
  let v484_41: Space = unite(&(v484_37),&(v484_40));
  drop(v484_37);
  drop(v484_40);
  (v484_41).clone()
}

fn routine_39(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v485_11: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v485_12: Space = singleton(&(v485_11));
  drop(v485_11);
  let v485_13: Space = unite(&(*CONSTANT_74),&(v485_12));
  drop(v485_12);
  let v485_15: Path = concat_path(&(*CONSTANT_5),&(*p2));
  let v485_16: Space = singleton(&(v485_15));
  drop(v485_15);
  let v485_17: Space = unite(&(v485_13),&(v485_16));
  drop(v485_13);
  drop(v485_16);
  let v485_19: Path = concat_path(&(*CONSTANT_7),&(*p3));
  let v485_20: Space = singleton(&(v485_19));
  drop(v485_19);
  let v485_21: Space = unite(&(v485_17),&(v485_20));
  drop(v485_17);
  drop(v485_20);
  let v485_23: Path = concat_path(&(*CONSTANT_9),&(*p4));
  let v485_24: Space = singleton(&(v485_23));
  drop(v485_23);
  let v485_25: Space = unite(&(v485_21),&(v485_24));
  drop(v485_21);
  drop(v485_24);
  let v485_27: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v485_28: Space = singleton(&(v485_27));
  drop(v485_27);
  let v485_29: Space = unite(&(v485_25),&(v485_28));
  drop(v485_25);
  drop(v485_28);
  let v485_31: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v485_32: Space = singleton(&(v485_31));
  drop(v485_31);
  let v485_33: Space = unite(&(v485_29),&(v485_32));
  drop(v485_29);
  drop(v485_32);
  let v485_35: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v485_36: Space = singleton(&(v485_35));
  drop(v485_35);
  let v485_37: Space = unite(&(v485_33),&(v485_36));
  drop(v485_33);
  drop(v485_36);
  let v485_39: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v485_40: Space = singleton(&(v485_39));
  drop(v485_39);
  let v485_41: Space = unite(&(v485_37),&(v485_40));
  drop(v485_37);
  drop(v485_40);
  (v485_41).clone()
}

fn routine_40(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v486_11: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v486_12: Space = singleton(&(v486_11));
  drop(v486_11);
  let v486_13: Space = unite(&(*CONSTANT_75),&(v486_12));
  drop(v486_12);
  let v486_15: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v486_16: Space = singleton(&(v486_15));
  drop(v486_15);
  let v486_17: Space = unite(&(v486_13),&(v486_16));
  drop(v486_13);
  drop(v486_16);
  let v486_19: Path = concat_path(&(*CONSTANT_7),&(*p3));
  let v486_20: Space = singleton(&(v486_19));
  drop(v486_19);
  let v486_21: Space = unite(&(v486_17),&(v486_20));
  drop(v486_17);
  drop(v486_20);
  let v486_23: Path = concat_path(&(*CONSTANT_9),&(*p4));
  let v486_24: Space = singleton(&(v486_23));
  drop(v486_23);
  let v486_25: Space = unite(&(v486_21),&(v486_24));
  drop(v486_21);
  drop(v486_24);
  let v486_27: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v486_28: Space = singleton(&(v486_27));
  drop(v486_27);
  let v486_29: Space = unite(&(v486_25),&(v486_28));
  drop(v486_25);
  drop(v486_28);
  let v486_31: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v486_32: Space = singleton(&(v486_31));
  drop(v486_31);
  let v486_33: Space = unite(&(v486_29),&(v486_32));
  drop(v486_29);
  drop(v486_32);
  let v486_35: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v486_36: Space = singleton(&(v486_35));
  drop(v486_35);
  let v486_37: Space = unite(&(v486_33),&(v486_36));
  drop(v486_33);
  drop(v486_36);
  let v486_39: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v486_40: Space = singleton(&(v486_39));
  drop(v486_39);
  let v486_41: Space = unite(&(v486_37),&(v486_40));
  drop(v486_37);
  drop(v486_40);
  (v486_41).clone()
}

fn routine_41(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v487_11: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v487_12: Space = singleton(&(v487_11));
  drop(v487_11);
  let v487_13: Space = unite(&(*CONSTANT_76),&(v487_12));
  drop(v487_12);
  let v487_15: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v487_16: Space = singleton(&(v487_15));
  drop(v487_15);
  let v487_17: Space = unite(&(v487_13),&(v487_16));
  drop(v487_13);
  drop(v487_16);
  let v487_19: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v487_20: Space = singleton(&(v487_19));
  drop(v487_19);
  let v487_21: Space = unite(&(v487_17),&(v487_20));
  drop(v487_17);
  drop(v487_20);
  let v487_23: Path = concat_path(&(*CONSTANT_9),&(*p4));
  let v487_24: Space = singleton(&(v487_23));
  drop(v487_23);
  let v487_25: Space = unite(&(v487_21),&(v487_24));
  drop(v487_21);
  drop(v487_24);
  let v487_27: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v487_28: Space = singleton(&(v487_27));
  drop(v487_27);
  let v487_29: Space = unite(&(v487_25),&(v487_28));
  drop(v487_25);
  drop(v487_28);
  let v487_31: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v487_32: Space = singleton(&(v487_31));
  drop(v487_31);
  let v487_33: Space = unite(&(v487_29),&(v487_32));
  drop(v487_29);
  drop(v487_32);
  let v487_35: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v487_36: Space = singleton(&(v487_35));
  drop(v487_35);
  let v487_37: Space = unite(&(v487_33),&(v487_36));
  drop(v487_33);
  drop(v487_36);
  let v487_39: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v487_40: Space = singleton(&(v487_39));
  drop(v487_39);
  let v487_41: Space = unite(&(v487_37),&(v487_40));
  drop(v487_37);
  drop(v487_40);
  (v487_41).clone()
}

fn routine_42(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v488_11: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v488_12: Space = singleton(&(v488_11));
  drop(v488_11);
  let v488_13: Space = unite(&(*CONSTANT_77),&(v488_12));
  drop(v488_12);
  let v488_15: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v488_16: Space = singleton(&(v488_15));
  drop(v488_15);
  let v488_17: Space = unite(&(v488_13),&(v488_16));
  drop(v488_13);
  drop(v488_16);
  let v488_19: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v488_20: Space = singleton(&(v488_19));
  drop(v488_19);
  let v488_21: Space = unite(&(v488_17),&(v488_20));
  drop(v488_17);
  drop(v488_20);
  let v488_23: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v488_24: Space = singleton(&(v488_23));
  drop(v488_23);
  let v488_25: Space = unite(&(v488_21),&(v488_24));
  drop(v488_21);
  drop(v488_24);
  let v488_27: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v488_28: Space = singleton(&(v488_27));
  drop(v488_27);
  let v488_29: Space = unite(&(v488_25),&(v488_28));
  drop(v488_25);
  drop(v488_28);
  let v488_31: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v488_32: Space = singleton(&(v488_31));
  drop(v488_31);
  let v488_33: Space = unite(&(v488_29),&(v488_32));
  drop(v488_29);
  drop(v488_32);
  let v488_35: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v488_36: Space = singleton(&(v488_35));
  drop(v488_35);
  let v488_37: Space = unite(&(v488_33),&(v488_36));
  drop(v488_33);
  drop(v488_36);
  let v488_39: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v488_40: Space = singleton(&(v488_39));
  drop(v488_39);
  let v488_41: Space = unite(&(v488_37),&(v488_40));
  drop(v488_37);
  drop(v488_40);
  (v488_41).clone()
}

fn routine_43(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v489_11: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v489_12: Space = singleton(&(v489_11));
  drop(v489_11);
  let v489_13: Space = unite(&(*CONSTANT_78),&(v489_12));
  drop(v489_12);
  let v489_15: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v489_16: Space = singleton(&(v489_15));
  drop(v489_15);
  let v489_17: Space = unite(&(v489_13),&(v489_16));
  drop(v489_13);
  drop(v489_16);
  let v489_19: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v489_20: Space = singleton(&(v489_19));
  drop(v489_19);
  let v489_21: Space = unite(&(v489_17),&(v489_20));
  drop(v489_17);
  drop(v489_20);
  let v489_23: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v489_24: Space = singleton(&(v489_23));
  drop(v489_23);
  let v489_25: Space = unite(&(v489_21),&(v489_24));
  drop(v489_21);
  drop(v489_24);
  let v489_27: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v489_28: Space = singleton(&(v489_27));
  drop(v489_27);
  let v489_29: Space = unite(&(v489_25),&(v489_28));
  drop(v489_25);
  drop(v489_28);
  let v489_31: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v489_32: Space = singleton(&(v489_31));
  drop(v489_31);
  let v489_33: Space = unite(&(v489_29),&(v489_32));
  drop(v489_29);
  drop(v489_32);
  let v489_35: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v489_36: Space = singleton(&(v489_35));
  drop(v489_35);
  let v489_37: Space = unite(&(v489_33),&(v489_36));
  drop(v489_33);
  drop(v489_36);
  let v489_39: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v489_40: Space = singleton(&(v489_39));
  drop(v489_39);
  let v489_41: Space = unite(&(v489_37),&(v489_40));
  drop(v489_37);
  drop(v489_40);
  (v489_41).clone()
}

fn routine_44(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v490_11: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v490_12: Space = singleton(&(v490_11));
  drop(v490_11);
  let v490_13: Space = unite(&(*CONSTANT_79),&(v490_12));
  drop(v490_12);
  let v490_15: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v490_16: Space = singleton(&(v490_15));
  drop(v490_15);
  let v490_17: Space = unite(&(v490_13),&(v490_16));
  drop(v490_13);
  drop(v490_16);
  let v490_19: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v490_20: Space = singleton(&(v490_19));
  drop(v490_19);
  let v490_21: Space = unite(&(v490_17),&(v490_20));
  drop(v490_17);
  drop(v490_20);
  let v490_23: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v490_24: Space = singleton(&(v490_23));
  drop(v490_23);
  let v490_25: Space = unite(&(v490_21),&(v490_24));
  drop(v490_21);
  drop(v490_24);
  let v490_27: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v490_28: Space = singleton(&(v490_27));
  drop(v490_27);
  let v490_29: Space = unite(&(v490_25),&(v490_28));
  drop(v490_25);
  drop(v490_28);
  let v490_31: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v490_32: Space = singleton(&(v490_31));
  drop(v490_31);
  let v490_33: Space = unite(&(v490_29),&(v490_32));
  drop(v490_29);
  drop(v490_32);
  let v490_35: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v490_36: Space = singleton(&(v490_35));
  drop(v490_35);
  let v490_37: Space = unite(&(v490_33),&(v490_36));
  drop(v490_33);
  drop(v490_36);
  let v490_39: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v490_40: Space = singleton(&(v490_39));
  drop(v490_39);
  let v490_41: Space = unite(&(v490_37),&(v490_40));
  drop(v490_37);
  drop(v490_40);
  (v490_41).clone()
}

fn routine_45(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v491_11: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v491_12: Space = singleton(&(v491_11));
  drop(v491_11);
  let v491_13: Space = unite(&(*CONSTANT_80),&(v491_12));
  drop(v491_12);
  let v491_15: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v491_16: Space = singleton(&(v491_15));
  drop(v491_15);
  let v491_17: Space = unite(&(v491_13),&(v491_16));
  drop(v491_13);
  drop(v491_16);
  let v491_19: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v491_20: Space = singleton(&(v491_19));
  drop(v491_19);
  let v491_21: Space = unite(&(v491_17),&(v491_20));
  drop(v491_17);
  drop(v491_20);
  let v491_23: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v491_24: Space = singleton(&(v491_23));
  drop(v491_23);
  let v491_25: Space = unite(&(v491_21),&(v491_24));
  drop(v491_21);
  drop(v491_24);
  let v491_27: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v491_28: Space = singleton(&(v491_27));
  drop(v491_27);
  let v491_29: Space = unite(&(v491_25),&(v491_28));
  drop(v491_25);
  drop(v491_28);
  let v491_31: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v491_32: Space = singleton(&(v491_31));
  drop(v491_31);
  let v491_33: Space = unite(&(v491_29),&(v491_32));
  drop(v491_29);
  drop(v491_32);
  let v491_35: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v491_36: Space = singleton(&(v491_35));
  drop(v491_35);
  let v491_37: Space = unite(&(v491_33),&(v491_36));
  drop(v491_33);
  drop(v491_36);
  let v491_39: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v491_40: Space = singleton(&(v491_39));
  drop(v491_39);
  let v491_41: Space = unite(&(v491_37),&(v491_40));
  drop(v491_37);
  drop(v491_40);
  (v491_41).clone()
}

fn routine_46(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v492_11: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v492_12: Space = singleton(&(v492_11));
  drop(v492_11);
  let v492_13: Space = unite(&(*CONSTANT_81),&(v492_12));
  drop(v492_12);
  let v492_15: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v492_16: Space = singleton(&(v492_15));
  drop(v492_15);
  let v492_17: Space = unite(&(v492_13),&(v492_16));
  drop(v492_13);
  drop(v492_16);
  let v492_19: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v492_20: Space = singleton(&(v492_19));
  drop(v492_19);
  let v492_21: Space = unite(&(v492_17),&(v492_20));
  drop(v492_17);
  drop(v492_20);
  let v492_23: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v492_24: Space = singleton(&(v492_23));
  drop(v492_23);
  let v492_25: Space = unite(&(v492_21),&(v492_24));
  drop(v492_21);
  drop(v492_24);
  let v492_27: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v492_28: Space = singleton(&(v492_27));
  drop(v492_27);
  let v492_29: Space = unite(&(v492_25),&(v492_28));
  drop(v492_25);
  drop(v492_28);
  let v492_31: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v492_32: Space = singleton(&(v492_31));
  drop(v492_31);
  let v492_33: Space = unite(&(v492_29),&(v492_32));
  drop(v492_29);
  drop(v492_32);
  let v492_35: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v492_36: Space = singleton(&(v492_35));
  drop(v492_35);
  let v492_37: Space = unite(&(v492_33),&(v492_36));
  drop(v492_33);
  drop(v492_36);
  let v492_39: Path = concat_path(&(*CONSTANT_15),&(*p0));
  let v492_40: Space = singleton(&(v492_39));
  drop(v492_39);
  let v492_41: Space = unite(&(v492_37),&(v492_40));
  drop(v492_37);
  drop(v492_40);
  (v492_41).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
