#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 3"));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("268 20 82 48 67 48 1 49 1 50 1 51 1 52 1 53 1 54 1 55 1 56 20 82 48 67 48 1 49 1 50 1 51 1 52 1 55 1 54 1 56 1 53 20 82 48 67 48 1 49 1 50 1 51 1 52 1 56 1 54 1 53 1 55 20 82 48 67 48 1 49 1 50 1 51 1 53 1 56 1 52 1 54 1 55 20 82 48 67 48 1 49 1 50 1 51 1 54 1 52 1 55 1 56 1 53 20 82 48 67 48 1 49 1 50 1 51 1 54 1 53 1 55 1 52 1 56 20 82 48 67 48 1 49 1 50 1 51 1 55 1 53 1 52 1 54 1 56 20 82 48 67 48 1 49 1 50 1 54 1 52 1 53 1 55 1 51 1 56 20 82 48 67 48 1 49 1 50 1 55 1 52 1 53 1 51 1 54 1 56 20 82 48 67 48 1 49 1 52 1 51 1 53 1 50 1 54 1 55 1 56 20 82 48 67 48 1 49 1 52 1 51 1 55 1 50 1 54 1 56 1 53 20 82 48 67 48 1 49 1 53 1 51 1 50 1 52 1 54 1 55 1 56 20 82 48 67 48 1 49 1 53 1 51 1 50 1 56 1 54 1 52 1 55 20 82 48 67 48 1 50 1 53 1 49 1 51 1 52 1 54 1 55 1 56 20 82 48 67 48 1 50 1 53 1 49 1 51 1 56 1 54 1 52 1 55 20 82 48 67 48 1 50 1 53 1 49 1 52 1 56 1 51 1 54 1 55 20 82 48 67 48 1 50 1 53 1 49 1 55 1 52 1 51 1 54 1 56 20 82 48 67 48 1 50 1 53 1 51 1 52 1 49 1 54 1 55 1 56 20 82 48 67 48 1 51 1 49 1 52 1 53 1 50 1 54 1 55 1 56 20 82 48 67 48 1 51 1 49 1 52 1 55 1 50 1 54 1 56 1 53 20 82 48 67 48 1 51 1 49 1 54 1 52 1 50 1 55 1 56 1 53 20 82 48 67 48 1 51 1 49 1 54 1 53 1 50 1 55 1 52 1 56 20 82 48 67 48 1 51 1 50 1 52 1 49 1 53 1 54 1 55 1 56 20 82 48 67 48 1 51 1 50 1 52 1 49 1 55 1 54 1 56 1 53 20 82 48 67 48 1 51 1 50 1 52 1 49 1 56 1 54 1 53 1 55 20 82 48 67 48 1 51 1 50 1 54 1 49 1 52 1 55 1 56 1 53 20 82 48 67 48 1 51 1 50 1 54 1 49 1 53 1 55 1 52 1 56 20 82 48 67 48 1 51 1 50 1 55 1 49 1 53 1 52 1 54 1 56 20 82 48 67 48 1 51 1 53 1 52 1 50 1 49 1 54 1 55 1 56 20 82 48 67 48 1 52 1 50 1 49 1 51 1 53 1 54 1 55 1 56 20 82 48 67 48 1 52 1 50 1 49 1 51 1 55 1 54 1 56 1 53 20 82 48 67 48 1 52 1 50 1 49 1 51 1 56 1 54 1 53 1 55 20 82 48 67 48 1 52 1 50 1 49 1 53 1 56 1 51 1 54 1 55 20 82 48 67 48 1 52 1 50 1 49 1 54 1 53 1 55 1 51 1 56 20 82 48 67 48 1 52 1 50 1 49 1 55 1 53 1 51 1 54 1 56 20 82 48 67 48 1 53 1 49 1 51 1 52 1 50 1 54 1 55 1 56 20 82 48 67 48 1 53 1 52 1 49 1 51 1 50 1 54 1 55 1 56 20 82 48 67 49 1 49 1 50 1 51 1 52 1 53 1 54 1 55 1 56 20 82 48 67 49 1 49 1 50 1 51 1 52 1 55 1 54 1 56 1 53 20 82 48 67 49 1 49 1 50 1 51 1 52 1 56 1 54 1 53 1 55 20 82 48 67 49 1 49 1 50 1 51 1 54 1 53 1 55 1 52 1 56 20 82 48 67 49 1 49 1 50 1 51 1 55 1 53 1 52 1 54 1 56 20 82 48 67 49 1 49 1 50 1 54 1 52 1 53 1 55 1 51 1 56 20 82 48 67 49 1 49 1 50 1 55 1 52 1 53 1 51 1 54 1 56 20 82 48 67 49 1 49 1 52 1 51 1 53 1 50 1 54 1 55 1 56 20 82 48 67 49 1 49 1 52 1 51 1 55 1 50 1 54 1 56 1 53 20 82 48 67 49 1 49 1 53 1 51 1 50 1 52 1 54 1 55 1 56 20 82 48 67 49 1 49 1 53 1 51 1 50 1 56 1 54 1 52 1 55 20 82 48 67 49 1 50 1 53 1 49 1 51 1 52 1 54 1 55 1 56 20 82 48 67 49 1 51 1 49 1 52 1 53 1 50 1 54 1 55 1 56 20 82 48 67 49 1 51 1 49 1 52 1 55 1 50 1 54 1 56 1 53 20 82 48 67 49 1 51 1 49 1 54 1 52 1 50 1 55 1 56 1 53 20 82 48 67 49 1 51 1 49 1 54 1 53 1 50 1 55 1 52 1 56 20 82 48 67 49 1 51 1 50 1 52 1 49 1 53 1 54 1 55 1 56 20 82 48 67 49 1 51 1 50 1 52 1 49 1 55 1 54 1 56 1 53 20 82 48 67 49 1 51 1 50 1 52 1 49 1 56 1 54 1 53 1 55 20 82 48 67 49 1 51 1 50 1 54 1 49 1 52 1 55 1 56 1 53 20 82 48 67 49 1 51 1 50 1 54 1 49 1 53 1 55 1 52 1 56 20 82 48 67 49 1 51 1 50 1 55 1 49 1 53 1 52 1 54 1 56 20 82 48 67 49 1 51 1 53 1 52 1 50 1 49 1 54 1 55 1 56 20 82 48 67 49 1 52 1 50 1 49 1 51 1 53 1 54 1 55 1 56 20 82 48 67 49 1 52 1 50 1 49 1 55 1 53 1 51 1 54 1 56 20 82 48 67 50 1 49 1 50 1 51 1 52 1 53 1 54 1 55 1 56 20 82 48 67 50 1 49 1 50 1 51 1 52 1 55 1 54 1 56 1 53 20 82 48 67 50 1 49 1 50 1 51 1 52 1 56 1 54 1 53 1 55 20 82 48 67 50 1 49 1 50 1 51 1 54 1 53 1 55 1 52 1 56 20 82 48 67 50 1 49 1 50 1 51 1 55 1 53 1 52 1 54 1 56 20 82 48 67 50 1 49 1 50 1 51 1 55 1 53 1 54 1 56 1 52 20 82 48 67 50 1 49 1 50 1 51 1 56 1 53 1 54 1 52 1 55 20 82 48 67 50 1 49 1 50 1 54 1 52 1 53 1 55 1 51 1 56 20 82 48 67 50 1 49 1 50 1 55 1 52 1 53 1 51 1 54 1 56 20 82 48 67 50 1 49 1 52 1 51 1 53 1 50 1 54 1 55 1 56 20 82 48 67 50 1 49 1 52 1 51 1 55 1 50 1 54 1 56 1 53 20 82 48 67 50 1 49 1 52 1 51 1 56 1 50 1 54 1 53 1 55 20 82 48 67 50 1 49 1 52 1 54 1 51 1 50 1 55 1 56 1 53 20 82 48 67 50 1 49 1 52 1 54 1 53 1 50 1 55 1 51 1 56 20 82 48 67 50 1 49 1 52 1 55 1 53 1 50 1 51 1 54 1 56 20 82 48 67 50 1 49 1 53 1 51 1 50 1 52 1 54 1 55 1 56 20 82 48 67 50 1 49 1 53 1 51 1 50 1 56 1 54 1 52 1 55 20 82 48 67 50 1 50 1 53 1 49 1 51 1 52 1 54 1 55 1 56 20 82 48 67 50 1 51 1 49 1 52 1 53 1 50 1 54 1 55 1 56 20 82 48 67 50 1 51 1 49 1 52 1 55 1 50 1 54 1 56 1 53 20 82 48 67 50 1 51 1 49 1 52 1 56 1 50 1 54 1 53 1 55 20 82 48 67 50 1 51 1 49 1 54 1 52 1 50 1 55 1 56 1 53 20 82 48 67 50 1 51 1 49 1 54 1 53 1 50 1 55 1 52 1 56 20 82 48 67 50 1 51 1 49 1 55 1 53 1 50 1 52 1 54 1 56 20 82 48 67 50 1 51 1 50 1 52 1 49 1 53 1 54 1 55 1 56 20 82 48 67 50 1 51 1 50 1 52 1 49 1 55 1 54 1 56 1 53 20 82 48 67 50 1 51 1 50 1 52 1 49 1 56 1 54 1 53 1 55 20 82 48 67 50 1 51 1 50 1 54 1 49 1 52 1 55 1 56 1 53 20 82 48 67 50 1 51 1 50 1 54 1 49 1 53 1 55 1 52 1 56 20 82 48 67 50 1 51 1 50 1 55 1 49 1 53 1 52 1 54 1 56 20 82 48 67 50 1 51 1 53 1 52 1 50 1 49 1 54 1 55 1 56 20 82 48 67 50 1 52 1 50 1 49 1 51 1 53 1 54 1 55 1 56 20 82 48 67 50 1 52 1 50 1 49 1 55 1 53 1 51 1 54 1 56 20 82 48 67 50 1 52 1 51 1 49 1 53 1 50 1 54 1 55 1 56 20 82 49 67 48 1 49 1 50 1 53 1 51 1 52 1 54 1 55 1 56 20 82 49 67 48 1 49 1 50 1 53 1 51 1 56 1 54 1 52 1 55 20 82 49 67 48 1 49 1 50 1 53 1 52 1 56 1 51 1 54 1 55 20 82 49 67 48 1 49 1 50 1 53 1 55 1 52 1 51 1 54 1 56 20 82 49 67 48 1 49 1 52 1 50 1 51 1 53 1 54 1 55 1 56 20 82 49 67 48 1 49 1 52 1 50 1 51 1 55 1 54 1 56 1 53 20 82 49 67 48 1 49 1 52 1 50 1 51 1 56 1 54 1 53 1 55 20 82 49 67 48 1 49 1 52 1 50 1 53 1 56 1 51 1 54 1 55 20 82 49 67 48 1 49 1 52 1 50 1 54 1 53 1 55 1 51 1 56 20 82 49 67 48 1 49 1 52 1 50 1 55 1 53 1 51 1 54 1 56 20 82 49 67 48 1 49 1 53 1 52 1 51 1 50 1 54 1 55 1 56 20 82 49 67 48 1 51 1 49 1 50 1 52 1 53 1 54 1 55 1 56 20 82 49 67 48 1 51 1 49 1 50 1 52 1 55 1 54 1 56 1 53 20 82 49 67 48 1 51 1 49 1 50 1 52 1 56 1 54 1 53 1 55 20 82 49 67 48 1 51 1 49 1 50 1 53 1 56 1 52 1 54 1 55 20 82 49 67 48 1 51 1 49 1 50 1 54 1 52 1 55 1 56 1 53 20 82 49 67 48 1 51 1 49 1 50 1 54 1 53 1 55 1 52 1 56 20 82 49 67 48 1 51 1 49 1 50 1 55 1 53 1 52 1 54 1 56 20 82 49 67 48 1 51 1 49 1 52 1 53 1 50 1 54 1 55 1 56 20 82 49 67 48 1 51 1 49 1 53 1 50 1 52 1 54 1 55 1 56 20 82 49 67 48 1 51 1 50 1 53 1 52 1 49 1 54 1 55 1 56 20 82 49 67 48 1 51 1 53 1 49 1 52 1 50 1 54 1 55 1 56 20 82 49 67 48 1 52 1 51 1 49 1 53 1 50 1 54 1 55 1 56 20 82 49 67 48 1 52 1 51 1 50 1 49 1 53 1 54 1 55 1 56 20 82 49 67 48 1 54 1 51 1 50 1 49 1 53 1 55 1 52 1 56 20 82 49 67 49 1 49 1 50 1 53 1 51 1 52 1 54 1 55 1 56 20 82 49 67 49 1 49 1 50 1 53 1 51 1 55 1 54 1 56 1 52 20 82 49 67 49 1 49 1 50 1 53 1 51 1 56 1 54 1 52 1 55 20 82 49 67 49 1 49 1 50 1 53 1 52 1 56 1 51 1 54 1 55 20 82 49 67 49 1 49 1 50 1 53 1 54 1 52 1 55 1 51 1 56 20 82 49 67 49 1 49 1 50 1 53 1 55 1 52 1 51 1 54 1 56 20 82 49 67 49 1 49 1 52 1 50 1 51 1 53 1 54 1 55 1 56 20 82 49 67 49 1 49 1 52 1 50 1 51 1 55 1 54 1 56 1 53 20 82 49 67 49 1 49 1 52 1 50 1 51 1 56 1 54 1 53 1 55 20 82 49 67 49 1 49 1 52 1 50 1 53 1 56 1 51 1 54 1 55 20 82 49 67 49 1 49 1 52 1 50 1 54 1 51 1 55 1 56 1 53 20 82 49 67 49 1 49 1 52 1 50 1 54 1 53 1 55 1 51 1 56 20 82 49 67 49 1 49 1 52 1 50 1 55 1 53 1 51 1 54 1 56 20 82 49 67 49 1 49 1 53 1 52 1 51 1 50 1 54 1 55 1 56 20 82 49 67 49 1 49 1 54 1 50 1 51 1 53 1 55 1 52 1 56 20 82 49 67 49 1 49 1 55 1 50 1 51 1 53 1 52 1 54 1 56 20 82 49 67 49 1 49 1 55 1 52 1 51 1 50 1 54 1 56 1 53 20 82 49 67 49 1 50 1 51 1 53 1 49 1 52 1 54 1 55 1 56 20 82 49 67 49 1 51 1 49 1 50 1 52 1 53 1 54 1 55 1 56 20 82 49 67 49 1 51 1 49 1 50 1 52 1 55 1 54 1 56 1 53 20 82 49 67 49 1 51 1 49 1 50 1 52 1 56 1 54 1 53 1 55 20 82 49 67 49 1 51 1 49 1 50 1 53 1 56 1 52 1 54 1 55 20 82 49 67 49 1 51 1 49 1 50 1 54 1 52 1 55 1 56 1 53 20 82 49 67 49 1 51 1 49 1 50 1 54 1 53 1 55 1 52 1 56 20 82 49 67 49 1 51 1 49 1 50 1 54 1 56 1 55 1 53 1 52 20 82 49 67 49 1 51 1 49 1 50 1 55 1 53 1 52 1 54 1 56 20 82 49 67 49 1 51 1 49 1 52 1 53 1 50 1 54 1 55 1 56 20 82 49 67 49 1 51 1 49 1 53 1 50 1 52 1 54 1 55 1 56 20 82 49 67 49 1 51 1 50 1 53 1 52 1 49 1 54 1 55 1 56 20 82 49 67 49 1 51 1 50 1 53 1 52 1 56 1 54 1 49 1 55 20 82 49 67 49 1 51 1 50 1 53 1 54 1 49 1 55 1 52 1 56 20 82 49 67 49 1 51 1 52 1 49 1 54 1 50 1 55 1 56 1 53 20 82 49 67 49 1 51 1 53 1 49 1 52 1 50 1 54 1 55 1 56 20 82 49 67 49 1 51 1 53 1 49 1 54 1 50 1 55 1 52 1 56 20 82 49 67 49 1 51 1 55 1 49 1 52 1 50 1 54 1 56 1 53 20 82 49 67 49 1 52 1 50 1 53 1 49 1 51 1 54 1 55 1 56 20 82 49 67 49 1 52 1 51 1 49 1 53 1 50 1 54 1 55 1 56 20 82 49 67 49 1 52 1 51 1 50 1 49 1 53 1 54 1 55 1 56 20 82 49 67 49 1 52 1 51 1 50 1 54 1 53 1 55 1 49 1 56 20 82 49 67 49 1 52 1 55 1 50 1 49 1 53 1 51 1 54 1 56 20 82 49 67 49 1 54 1 51 1 50 1 49 1 53 1 55 1 52 1 56 20 82 49 67 50 1 49 1 50 1 53 1 51 1 52 1 54 1 55 1 56 20 82 49 67 50 1 49 1 50 1 53 1 51 1 55 1 54 1 56 1 52 20 82 49 67 50 1 49 1 50 1 53 1 51 1 56 1 54 1 52 1 55 20 82 49 67 50 1 49 1 52 1 50 1 51 1 53 1 54 1 55 1 56 20 82 49 67 50 1 49 1 52 1 50 1 51 1 55 1 54 1 56 1 53 20 82 49 67 50 1 49 1 52 1 50 1 51 1 56 1 54 1 53 1 55 20 82 49 67 50 1 49 1 52 1 50 1 54 1 51 1 55 1 56 1 53 20 82 49 67 50 1 49 1 52 1 50 1 54 1 53 1 55 1 51 1 56 20 82 49 67 50 1 49 1 52 1 50 1 55 1 53 1 51 1 54 1 56 20 82 49 67 50 1 49 1 53 1 52 1 51 1 50 1 54 1 55 1 56 20 82 49 67 50 1 51 1 49 1 50 1 52 1 53 1 54 1 55 1 56 20 82 49 67 50 1 51 1 49 1 50 1 52 1 55 1 54 1 56 1 53 20 82 49 67 50 1 51 1 49 1 50 1 52 1 56 1 54 1 53 1 55 20 82 49 67 50 1 51 1 49 1 50 1 54 1 52 1 55 1 56 1 53 20 82 49 67 50 1 51 1 49 1 50 1 54 1 53 1 55 1 52 1 56 20 82 49 67 50 1 51 1 49 1 50 1 55 1 53 1 52 1 54 1 56 20 82 49 67 50 1 51 1 50 1 53 1 52 1 49 1 54 1 55 1 56 20 82 49 67 50 1 51 1 50 1 53 1 54 1 49 1 55 1 52 1 56 20 82 49 67 50 1 51 1 53 1 49 1 52 1 50 1 54 1 55 1 56 20 82 49 67 50 1 52 1 50 1 53 1 49 1 51 1 54 1 55 1 56 20 82 49 67 50 1 52 1 51 1 50 1 49 1 53 1 54 1 55 1 56 20 82 50 67 48 1 49 1 50 1 53 1 51 1 52 1 56 1 54 1 55 20 82 50 67 48 1 49 1 50 1 53 1 51 1 55 1 52 1 54 1 56 20 82 50 67 48 1 49 1 50 1 53 1 54 1 51 1 52 1 55 1 56 20 82 50 67 48 1 49 1 50 1 53 1 54 1 51 1 56 1 52 1 55 20 82 50 67 48 1 49 1 52 1 50 1 51 1 53 1 56 1 54 1 55 20 82 50 67 48 1 49 1 52 1 50 1 51 1 55 1 53 1 54 1 56 20 82 50 67 48 1 49 1 52 1 50 1 51 1 56 1 55 1 54 1 53 20 82 50 67 48 1 49 1 52 1 50 1 54 1 51 1 53 1 55 1 56 20 82 50 67 48 1 49 1 52 1 50 1 54 1 51 1 55 1 56 1 53 20 82 50 67 48 1 49 1 52 1 50 1 54 1 51 1 56 1 53 1 55 20 82 50 67 48 1 49 1 52 1 50 1 55 1 54 1 53 1 51 1 56 20 82 50 67 48 1 49 1 53 1 52 1 51 1 55 1 50 1 54 1 56 20 82 50 67 48 1 49 1 53 1 52 1 54 1 51 1 50 1 55 1 56 20 82 50 67 48 1 51 1 49 1 50 1 52 1 53 1 56 1 54 1 55 20 82 50 67 48 1 51 1 49 1 50 1 52 1 55 1 53 1 54 1 56 20 82 50 67 48 1 51 1 49 1 50 1 52 1 56 1 55 1 54 1 53 20 82 50 67 48 1 51 1 49 1 50 1 54 1 52 1 53 1 55 1 56 20 82 50 67 48 1 51 1 49 1 50 1 54 1 52 1 55 1 56 1 53 20 82 50 67 48 1 51 1 49 1 50 1 54 1 52 1 56 1 53 1 55 20 82 50 67 48 1 51 1 49 1 50 1 54 1 53 1 56 1 55 1 52 20 82 50 67 48 1 51 1 49 1 50 1 54 1 56 1 52 1 55 1 53 20 82 50 67 48 1 51 1 49 1 50 1 55 1 54 1 52 1 56 1 53 20 82 50 67 48 1 51 1 49 1 50 1 55 1 54 1 53 1 52 1 56 20 82 50 67 48 1 51 1 49 1 52 1 54 1 53 1 50 1 55 1 56 20 82 50 67 48 1 51 1 49 1 53 1 54 1 50 1 52 1 55 1 56 20 82 50 67 48 1 51 1 50 1 53 1 52 1 49 1 56 1 54 1 55 20 82 50 67 48 1 51 1 50 1 53 1 52 1 55 1 49 1 54 1 56 20 82 50 67 48 1 51 1 50 1 53 1 54 1 52 1 49 1 55 1 56 20 82 50 67 48 1 51 1 53 1 49 1 52 1 55 1 50 1 54 1 56 20 82 50 67 48 1 51 1 53 1 49 1 54 1 52 1 50 1 55 1 56 20 82 50 67 48 1 52 1 51 1 49 1 54 1 53 1 50 1 55 1 56 20 82 50 67 48 1 52 1 51 1 50 1 49 1 55 1 53 1 54 1 56 20 82 50 67 48 1 52 1 51 1 50 1 54 1 49 1 53 1 55 1 56 20 82 50 67 48 1 54 1 51 1 50 1 55 1 49 1 53 1 52 1 56 20 82 50 67 49 1 49 1 50 1 53 1 51 1 52 1 56 1 54 1 55 20 82 50 67 49 1 49 1 50 1 53 1 51 1 55 1 52 1 54 1 56 20 82 50 67 49 1 49 1 50 1 53 1 54 1 51 1 52 1 55 1 56 20 82 50 67 49 1 49 1 52 1 50 1 51 1 53 1 56 1 54 1 55 20 82 50 67 49 1 49 1 52 1 50 1 51 1 55 1 53 1 54 1 56 20 82 50 67 49 1 49 1 52 1 50 1 51 1 56 1 55 1 54 1 53 20 82 50 67 49 1 49 1 52 1 50 1 54 1 51 1 53 1 55 1 56 20 82 50 67 49 1 49 1 52 1 50 1 55 1 54 1 53 1 51 1 56 20 82 50 67 49 1 49 1 53 1 52 1 51 1 55 1 50 1 54 1 56 20 82 50 67 49 1 51 1 49 1 50 1 52 1 53 1 56 1 54 1 55 20 82 50 67 49 1 51 1 49 1 50 1 52 1 55 1 53 1 54 1 56 20 82 50 67 49 1 51 1 49 1 50 1 52 1 56 1 55 1 54 1 53 20 82 50 67 49 1 51 1 49 1 50 1 54 1 52 1 53 1 55 1 56 20 82 50 67 49 1 51 1 49 1 50 1 54 1 53 1 56 1 55 1 52 20 82 50 67 49 1 51 1 49 1 50 1 54 1 56 1 52 1 55 1 53 20 82 50 67 49 1 51 1 49 1 50 1 55 1 54 1 53 1 52 1 56 20 82 50 67 49 1 51 1 50 1 53 1 52 1 49 1 56 1 54 1 55 20 82 50 67 49 1 51 1 50 1 53 1 52 1 55 1 49 1 54 1 56 20 82 50 67 49 1 51 1 53 1 49 1 52 1 55 1 50 1 54 1 56 20 82 50 67 49 1 52 1 51 1 50 1 49 1 55 1 53 1 54 1 56 20 82 50 67 49 1 52 1 51 1 50 1 54 1 49 1 53 1 55 1 56 20 82 50 67 50 1 49 1 50 1 53 1 51 1 52 1 56 1 54 1 55 20 82 50 67 50 1 49 1 50 1 53 1 51 1 55 1 52 1 54 1 56 20 82 50 67 50 1 49 1 50 1 53 1 51 1 56 1 55 1 54 1 52 20 82 50 67 50 1 49 1 50 1 53 1 54 1 51 1 52 1 55 1 56 20 82 50 67 50 1 49 1 52 1 50 1 51 1 53 1 56 1 54 1 55 20 82 50 67 50 1 49 1 52 1 50 1 51 1 55 1 53 1 54 1 56 20 82 50 67 50 1 49 1 52 1 50 1 51 1 56 1 55 1 54 1 53 20 82 50 67 50 1 49 1 52 1 50 1 54 1 51 1 53 1 55 1 56 20 82 50 67 50 1 49 1 52 1 50 1 54 1 53 1 56 1 55 1 51 20 82 50 67 50 1 49 1 52 1 50 1 55 1 53 1 56 1 51 1 54 20 82 50 67 50 1 49 1 52 1 50 1 55 1 54 1 53 1 51 1 56 20 82 50 67 50 1 49 1 53 1 52 1 51 1 50 1 56 1 54 1 55 20 82 50 67 50 1 49 1 53 1 52 1 51 1 55 1 50 1 54 1 56 20 82 50 67 50 1 51 1 49 1 50 1 52 1 53 1 56 1 54 1 55 20 82 50 67 50 1 51 1 49 1 50 1 52 1 55 1 53 1 54 1 56 20 82 50 67 50 1 51 1 49 1 50 1 52 1 56 1 55 1 54 1 53 20 82 50 67 50 1 51 1 49 1 50 1 54 1 52 1 53 1 55 1 56 20 82 50 67 50 1 51 1 49 1 50 1 54 1 53 1 56 1 55 1 52 20 82 50 67 50 1 51 1 49 1 50 1 54 1 56 1 52 1 55 1 53 20 82 50 67 50 1 51 1 49 1 50 1 55 1 53 1 56 1 52 1 54 20 82 50 67 50 1 51 1 49 1 50 1 55 1 54 1 53 1 52 1 56 20 82 50 67 50 1 51 1 50 1 53 1 52 1 49 1 56 1 54 1 55 20 82 50 67 50 1 51 1 50 1 53 1 52 1 55 1 49 1 54 1 56 20 82 50 67 50 1 51 1 50 1 53 1 54 1 49 1 56 1 55 1 52 20 82 50 67 50 1 51 1 53 1 49 1 52 1 50 1 56 1 54 1 55 20 82 50 67 50 1 51 1 53 1 49 1 52 1 55 1 50 1 54 1 56 20 82 50 67 50 1 52 1 50 1 53 1 49 1 51 1 56 1 54 1 55 20 82 50 67 50 1 52 1 51 1 50 1 49 1 53 1 56 1 54 1 55 20 82 50 67 50 1 52 1 51 1 50 1 49 1 55 1 53 1 54 1 56 20 82 50 67 50 1 52 1 51 1 50 1 54 1 49 1 53 1 55 1 56"));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("255 2 1 0 2 2 1 2 3 2 2 4 3 2 5 4 2 6 5 2 7 6 2 8 7 2 9 8 2 10 9 2 11 10 2 12 11 2 13 12 2 14 13 2 15 14 2 16 15 2 17 16 2 18 17 2 19 18 2 20 19 2 21 20 2 22 21 2 23 22 2 24 23 2 25 24 2 26 25 2 27 26 2 28 27 2 29 28 2 30 29 2 31 30 2 32 31 2 33 32 2 34 33 2 35 34 2 36 35 2 37 36 2 38 37 2 39 38 2 40 39 2 41 40 2 42 41 2 43 42 2 44 43 2 45 44 2 46 45 2 47 46 2 48 47 2 49 48 2 50 49 2 51 50 2 52 51 2 53 52 2 54 53 2 55 54 2 56 55 2 57 56 2 58 57 2 59 58 2 60 59 2 61 60 2 62 61 2 63 62 2 64 63 2 65 64 2 66 65 2 67 66 2 68 67 2 69 68 2 70 69 2 71 70 2 72 71 2 73 72 2 74 73 2 75 74 2 76 75 2 77 76 2 78 77 2 79 78 2 80 79 2 81 80 2 82 81 2 83 82 2 84 83 2 85 84 2 86 85 2 87 86 2 88 87 2 89 88 2 90 89 2 91 90 2 92 91 2 93 92 2 94 93 2 95 94 2 96 95 2 97 96 2 98 97 2 99 98 2 100 99 2 101 100 2 102 101 2 103 102 2 104 103 2 105 104 2 106 105 2 107 106 2 108 107 2 109 108 2 110 109 2 111 110 2 112 111 2 113 112 2 114 113 2 115 114 2 116 115 2 117 116 2 118 117 2 119 118 2 120 119 2 121 120 2 122 121 2 123 122 2 124 123 2 125 124 2 126 125 2 127 126 2 128 127 2 129 128 2 130 129 2 131 130 2 132 131 2 133 132 2 134 133 2 135 134 2 136 135 2 137 136 2 138 137 2 139 138 2 140 139 2 141 140 2 142 141 2 143 142 2 144 143 2 145 144 2 146 145 2 147 146 2 148 147 2 149 148 2 150 149 2 151 150 2 152 151 2 153 152 2 154 153 2 155 154 2 156 155 2 157 156 2 158 157 2 159 158 2 160 159 2 161 160 2 162 161 2 163 162 2 164 163 2 165 164 2 166 165 2 167 166 2 168 167 2 169 168 2 170 169 2 171 170 2 172 171 2 173 172 2 174 173 2 175 174 2 176 175 2 177 176 2 178 177 2 179 178 2 180 179 2 181 180 2 182 181 2 183 182 2 184 183 2 185 184 2 186 185 2 187 186 2 188 187 2 189 188 2 190 189 2 191 190 2 192 191 2 193 192 2 194 193 2 195 194 2 196 195 2 197 196 2 198 197 2 199 198 2 200 199 2 201 200 2 202 201 2 203 202 2 204 203 2 205 204 2 206 205 2 207 206 2 208 207 2 209 208 2 210 209 2 211 210 2 212 211 2 213 212 2 214 213 2 215 214 2 216 215 2 217 216 2 218 217 2 219 218 2 220 219 2 221 220 2 222 221 2 223 222 2 224 223 2 225 224 2 226 225 2 227 226 2 228 227 2 229 228 2 230 229 2 231 230 2 232 231 2 233 232 2 234 233 2 235 234 2 236 235 2 237 236 2 238 237 2 239 238 2 240 239 2 241 240 2 242 241 2 243 242 2 244 243 2 245 244 2 246 245 2 247 246 2 248 247 2 249 248 2 250 249 2 251 250 2 252 251 2 253 252 2 254 253 2 255 254"));
static CONSTANT_7: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 4 82 48 67 48"));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 4 82 48 67 49"));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 4 82 48 67 50"));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 4 82 49 67 48"));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 4 82 49 67 49"));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 4 82 49 67 50"));
static CONSTANT_13: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 4 82 50 67 48"));
static CONSTANT_14: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 4 82 50 67 49"));
static CONSTANT_15: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 4 82 50 67 50"));
static CONSTANT_16: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("48 16 82 48 67 48 1 68 4 82 48 67 48 4 82 49 67 48 16 82 48 67 48 1 68 4 82 49 67 48 4 82 48 67 48 16 82 48 67 48 1 82 4 82 48 67 48 4 82 48 67 49 16 82 48 67 48 1 82 4 82 48 67 49 4 82 48 67 48 16 82 48 67 49 1 68 4 82 48 67 49 4 82 49 67 49 16 82 48 67 49 1 68 4 82 49 67 49 4 82 48 67 49 16 82 48 67 49 1 76 4 82 48 67 48 4 82 48 67 49 16 82 48 67 49 1 76 4 82 48 67 49 4 82 48 67 48 16 82 48 67 49 1 82 4 82 48 67 49 4 82 48 67 50 16 82 48 67 49 1 82 4 82 48 67 50 4 82 48 67 49 16 82 48 67 50 1 68 4 82 48 67 50 4 82 49 67 50 16 82 48 67 50 1 68 4 82 49 67 50 4 82 48 67 50 16 82 48 67 50 1 76 4 82 48 67 49 4 82 48 67 50 16 82 48 67 50 1 76 4 82 48 67 50 4 82 48 67 49 16 82 49 67 48 1 68 4 82 49 67 48 4 82 50 67 48 16 82 49 67 48 1 68 4 82 50 67 48 4 82 49 67 48 16 82 49 67 48 1 82 4 82 49 67 48 4 82 49 67 49 16 82 49 67 48 1 82 4 82 49 67 49 4 82 49 67 48 16 82 49 67 48 1 85 4 82 48 67 48 4 82 49 67 48 16 82 49 67 48 1 85 4 82 49 67 48 4 82 48 67 48 16 82 49 67 49 1 68 4 82 49 67 49 4 82 50 67 49 16 82 49 67 49 1 68 4 82 50 67 49 4 82 49 67 49 16 82 49 67 49 1 76 4 82 49 67 48 4 82 49 67 49 16 82 49 67 49 1 76 4 82 49 67 49 4 82 49 67 48 16 82 49 67 49 1 82 4 82 49 67 49 4 82 49 67 50 16 82 49 67 49 1 82 4 82 49 67 50 4 82 49 67 49 16 82 49 67 49 1 85 4 82 48 67 49 4 82 49 67 49 16 82 49 67 49 1 85 4 82 49 67 49 4 82 48 67 49 16 82 49 67 50 1 68 4 82 49 67 50 4 82 50 67 50 16 82 49 67 50 1 68 4 82 50 67 50 4 82 49 67 50 16 82 49 67 50 1 76 4 82 49 67 49 4 82 49 67 50 16 82 49 67 50 1 76 4 82 49 67 50 4 82 49 67 49 16 82 49 67 50 1 85 4 82 48 67 50 4 82 49 67 50 16 82 49 67 50 1 85 4 82 49 67 50 4 82 48 67 50 16 82 50 67 48 1 82 4 82 50 67 48 4 82 50 67 49 16 82 50 67 48 1 82 4 82 50 67 49 4 82 50 67 48 16 82 50 67 48 1 85 4 82 49 67 48 4 82 50 67 48 16 82 50 67 48 1 85 4 82 50 67 48 4 82 49 67 48 16 82 50 67 49 1 76 4 82 50 67 48 4 82 50 67 49 16 82 50 67 49 1 76 4 82 50 67 49 4 82 50 67 48 16 82 50 67 49 1 82 4 82 50 67 49 4 82 50 67 50 16 82 50 67 49 1 82 4 82 50 67 50 4 82 50 67 49 16 82 50 67 49 1 85 4 82 49 67 49 4 82 50 67 49 16 82 50 67 49 1 85 4 82 50 67 49 4 82 49 67 49 16 82 50 67 50 1 76 4 82 50 67 49 4 82 50 67 50 16 82 50 67 50 1 76 4 82 50 67 50 4 82 50 67 49 16 82 50 67 50 1 85 4 82 49 67 50 4 82 50 67 50 16 82 50 67 50 1 85 4 82 50 67 50 4 82 49 67 50"));
static CONSTANT_17: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("9 10 4 82 48 67 48 4 82 48 67 48 10 4 82 48 67 49 4 82 48 67 49 10 4 82 48 67 50 4 82 48 67 50 10 4 82 49 67 48 4 82 49 67 48 10 4 82 49 67 49 4 82 49 67 49 10 4 82 49 67 50 4 82 49 67 50 10 4 82 50 67 48 4 82 50 67 48 10 4 82 50 67 49 4 82 50 67 49 10 4 82 50 67 50 4 82 50 67 50"));
static CONSTANT_18: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4,82,48,67,49]));
static CONSTANT_19: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4,82,48,67,50]));
static CONSTANT_20: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4,82,49,67,48]));
static CONSTANT_21: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4,82,49,67,49]));
static CONSTANT_22: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4,82,49,67,50]));
static CONSTANT_23: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4,82,50,67,48]));
static CONSTANT_24: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4,82,50,67,49]));
static CONSTANT_25: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4,82,50,67,50]));
static CONSTANT_26: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4,82,48,67,48]));
static CONSTANT_27: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 4 82 48 67 48 1 95"));
static CONSTANT_28: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 4 82 48 67 49 1 95"));
static CONSTANT_29: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 4 82 48 67 50 1 95"));
static CONSTANT_30: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 4 82 49 67 48 1 95"));
static CONSTANT_31: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 4 82 49 67 49 1 95"));
static CONSTANT_32: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 4 82 49 67 50 1 95"));
static CONSTANT_33: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 4 82 50 67 48 1 95"));
static CONSTANT_34: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 4 82 50 67 49 1 95"));
static CONSTANT_35: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 4 82 50 67 50 1 95"));
#[inline(never)]
fn native_block_0(c: &mut Context,capture_0: &[u8],capture_1: &View<'_, '_>) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v132_3: Space = singleton(&(*capture_0));
  let v132_4: Space = map_map_kernels::intersect(&(*CONSTANT_7),&(v132_3));
  let v132_770: Space = map_kernels::drop_length_prefixes(&(v132_4));
  drop(v132_4);
  let v132_777: Space = if (&(v132_770)).is_empty() { Space::new() } else {
    let mut v133_776 = Space::new();
    let mut v133_776_write = v133_776.write_zipper();
    let mut v133_776_cursor = (*capture_1).read_zipper();
    let v133_776_origin = v133_776_cursor.path().len();
    for v133_776_byte in v133_776_cursor.child_mask().iter() {
      v133_776_cursor.descend_to_existing_byte(v133_776_byte);
      {
      let v134_2: Space = singleton(&v133_776_cursor.path()[v133_776_origin..(v133_776_origin + 1)]);
      let v134_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v134_2));
      let v134_4: Space = if map_kernels::has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
      drop(v134_3);
      let v134_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v134_4));
      drop(v134_4);
      let v134_8: Space = if (&(v134_5)).is_empty() { Space::new() } else {
        let mut v135_7 = Space::new();
        let mut v135_7_write = v135_7.write_zipper();
        let v135_7_arg_0: &[u8] = &(*CONSTANT_1);
        let v135_7_arg_1: &[u8] = &v133_776_cursor.path()[v133_776_origin..(v133_776_origin + 1)];
        let v135_7_arg_3: &Space = &(&v133_776_cursor).make_map();
        let mut v135_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v133_776_cursor.path()[v133_776_origin..(v133_776_origin + 1)]);
        let v135_7_origin = v135_7_cursor.path().len();
        let mut v135_7_more = v135_7_cursor.is_val() || next_value_within(&mut v135_7_cursor,v135_7_origin);
        while v135_7_more {
          {
          let v135_7_depth = v135_7_cursor.path().len();
          let mut v136_4_cursor = (*v135_7_arg_3).read_zipper();
          let v136_4_origin = v136_4_cursor.path().len();
          for v136_4_byte in v136_4_cursor.child_mask().iter() {
            v136_4_cursor.descend_to_existing_byte(v136_4_byte);
            {
            let v137_2: Path = concat_path(&(*v135_7_arg_1),&v136_4_cursor.path()[v136_4_origin..(v136_4_origin + 1)]);
            let v137_3: Space = routine_22(c, &(v137_2), &v135_7_cursor.path()[v135_7_origin..v135_7_depth], &v136_4_cursor);
            drop(v137_2);
            join_wrapped_into(&mut v135_7_write,&((v137_3).read_zipper()),&[]);
            }
            v136_4_cursor.ascend(1);
          }
          drop(v136_4_cursor);
          }
          v135_7_more = next_value_within(&mut v135_7_cursor,v135_7_origin);
        }
        drop(v135_7_cursor);
        drop(v135_7_write);
        map_map_kernels::compose(&(v134_5),&(v135_7))
      };
      drop(v134_5);
      let v134_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v134_2));
      drop(v134_2);
      let v134_10: Space = if map_kernels::has_head(&(v134_9)) { singleton(&[]) } else { Space::new() };
      drop(v134_9);
      let v134_12: Space = if (&(v134_10)).is_empty() { Space::new() } else {
        let v138_11: Space = routine_23(c, &v133_776_cursor.path()[v133_776_origin..(v133_776_origin + 1)], &v133_776_cursor);
        map_map_kernels::compose(&(v134_10),&(v138_11))
      };
      drop(v134_10);
      let v134_13: Space = map_map_kernels::unite(&(v134_8),&(v134_12));
      join_wrapped_into(&mut v133_776_write,&((v134_13).read_zipper()),&[]);
      }
      v133_776_cursor.ascend(1);
    }
    drop(v133_776_cursor);
    drop(v133_776_write);
    map_map_kernels::compose(&(v132_770),&(v133_776))
  };
  drop(v132_770);
  let v132_779: Space = map_map_kernels::intersect(&(*CONSTANT_8),&(v132_3));
  let v132_1545: Space = map_kernels::drop_length_prefixes(&(v132_779));
  drop(v132_779);
  let v132_1551: Space = if (&(v132_1545)).is_empty() { Space::new() } else {
    let mut v139_1550 = Space::new();
    let mut v139_1550_write = v139_1550.write_zipper();
    let mut v139_1550_cursor = (*capture_1).read_zipper();
    let v139_1550_origin = v139_1550_cursor.path().len();
    for v139_1550_byte in v139_1550_cursor.child_mask().iter() {
      v139_1550_cursor.descend_to_existing_byte(v139_1550_byte);
      {
      let v140_2: Space = singleton(&v139_1550_cursor.path()[v139_1550_origin..(v139_1550_origin + 1)]);
      let v140_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v140_2));
      let v140_4: Space = if map_kernels::has_head(&(v140_3)) { singleton(&[]) } else { Space::new() };
      drop(v140_3);
      let v140_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v140_4));
      drop(v140_4);
      let v140_8: Space = if (&(v140_5)).is_empty() { Space::new() } else {
        let mut v141_7 = Space::new();
        let mut v141_7_write = v141_7.write_zipper();
        let v141_7_arg_0: &[u8] = &(*CONSTANT_1);
        let v141_7_arg_1: &[u8] = &v139_1550_cursor.path()[v139_1550_origin..(v139_1550_origin + 1)];
        let v141_7_arg_3: &Space = &(&v139_1550_cursor).make_map();
        let mut v141_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v139_1550_cursor.path()[v139_1550_origin..(v139_1550_origin + 1)]);
        let v141_7_origin = v141_7_cursor.path().len();
        let mut v141_7_more = v141_7_cursor.is_val() || next_value_within(&mut v141_7_cursor,v141_7_origin);
        while v141_7_more {
          {
          let v141_7_depth = v141_7_cursor.path().len();
          let mut v142_4_cursor = (*v141_7_arg_3).read_zipper();
          let v142_4_origin = v142_4_cursor.path().len();
          for v142_4_byte in v142_4_cursor.child_mask().iter() {
            v142_4_cursor.descend_to_existing_byte(v142_4_byte);
            {
            let v143_2: Path = concat_path(&(*v141_7_arg_1),&v142_4_cursor.path()[v142_4_origin..(v142_4_origin + 1)]);
            let v143_3: Space = routine_24(c, &(v143_2), &v141_7_cursor.path()[v141_7_origin..v141_7_depth], &v142_4_cursor);
            drop(v143_2);
            join_wrapped_into(&mut v141_7_write,&((v143_3).read_zipper()),&[]);
            }
            v142_4_cursor.ascend(1);
          }
          drop(v142_4_cursor);
          }
          v141_7_more = next_value_within(&mut v141_7_cursor,v141_7_origin);
        }
        drop(v141_7_cursor);
        drop(v141_7_write);
        map_map_kernels::compose(&(v140_5),&(v141_7))
      };
      drop(v140_5);
      let v140_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v140_2));
      drop(v140_2);
      let v140_10: Space = if map_kernels::has_head(&(v140_9)) { singleton(&[]) } else { Space::new() };
      drop(v140_9);
      let v140_12: Space = if (&(v140_10)).is_empty() { Space::new() } else {
        let v144_11: Space = routine_25(c, &v139_1550_cursor.path()[v139_1550_origin..(v139_1550_origin + 1)], &v139_1550_cursor);
        map_map_kernels::compose(&(v140_10),&(v144_11))
      };
      drop(v140_10);
      let v140_13: Space = map_map_kernels::unite(&(v140_8),&(v140_12));
      join_wrapped_into(&mut v139_1550_write,&((v140_13).read_zipper()),&[]);
      }
      v139_1550_cursor.ascend(1);
    }
    drop(v139_1550_cursor);
    drop(v139_1550_write);
    map_map_kernels::compose(&(v132_1545),&(v139_1550))
  };
  drop(v132_1545);
  let v132_1552: Space = map_map_kernels::unite(&(v132_777),&(v132_1551));
  let v132_1554: Space = map_map_kernels::intersect(&(*CONSTANT_9),&(v132_3));
  let v132_2320: Space = map_kernels::drop_length_prefixes(&(v132_1554));
  drop(v132_1554);
  let v132_2326: Space = if (&(v132_2320)).is_empty() { Space::new() } else {
    let mut v145_2325 = Space::new();
    let mut v145_2325_write = v145_2325.write_zipper();
    let mut v145_2325_cursor = (*capture_1).read_zipper();
    let v145_2325_origin = v145_2325_cursor.path().len();
    for v145_2325_byte in v145_2325_cursor.child_mask().iter() {
      v145_2325_cursor.descend_to_existing_byte(v145_2325_byte);
      {
      let v146_2: Space = singleton(&v145_2325_cursor.path()[v145_2325_origin..(v145_2325_origin + 1)]);
      let v146_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v146_2));
      let v146_4: Space = if map_kernels::has_head(&(v146_3)) { singleton(&[]) } else { Space::new() };
      drop(v146_3);
      let v146_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v146_4));
      drop(v146_4);
      let v146_8: Space = if (&(v146_5)).is_empty() { Space::new() } else {
        let mut v147_7 = Space::new();
        let mut v147_7_write = v147_7.write_zipper();
        let v147_7_arg_0: &[u8] = &(*CONSTANT_1);
        let v147_7_arg_1: &[u8] = &v145_2325_cursor.path()[v145_2325_origin..(v145_2325_origin + 1)];
        let v147_7_arg_3: &Space = &(&v145_2325_cursor).make_map();
        let mut v147_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v145_2325_cursor.path()[v145_2325_origin..(v145_2325_origin + 1)]);
        let v147_7_origin = v147_7_cursor.path().len();
        let mut v147_7_more = v147_7_cursor.is_val() || next_value_within(&mut v147_7_cursor,v147_7_origin);
        while v147_7_more {
          {
          let v147_7_depth = v147_7_cursor.path().len();
          let mut v148_4_cursor = (*v147_7_arg_3).read_zipper();
          let v148_4_origin = v148_4_cursor.path().len();
          for v148_4_byte in v148_4_cursor.child_mask().iter() {
            v148_4_cursor.descend_to_existing_byte(v148_4_byte);
            {
            let v149_2: Path = concat_path(&(*v147_7_arg_1),&v148_4_cursor.path()[v148_4_origin..(v148_4_origin + 1)]);
            let v149_3: Space = routine_26(c, &(v149_2), &v147_7_cursor.path()[v147_7_origin..v147_7_depth], &v148_4_cursor);
            drop(v149_2);
            join_wrapped_into(&mut v147_7_write,&((v149_3).read_zipper()),&[]);
            }
            v148_4_cursor.ascend(1);
          }
          drop(v148_4_cursor);
          }
          v147_7_more = next_value_within(&mut v147_7_cursor,v147_7_origin);
        }
        drop(v147_7_cursor);
        drop(v147_7_write);
        map_map_kernels::compose(&(v146_5),&(v147_7))
      };
      drop(v146_5);
      let v146_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v146_2));
      drop(v146_2);
      let v146_10: Space = if map_kernels::has_head(&(v146_9)) { singleton(&[]) } else { Space::new() };
      drop(v146_9);
      let v146_12: Space = if (&(v146_10)).is_empty() { Space::new() } else {
        let v150_11: Space = routine_27(c, &v145_2325_cursor.path()[v145_2325_origin..(v145_2325_origin + 1)], &v145_2325_cursor);
        map_map_kernels::compose(&(v146_10),&(v150_11))
      };
      drop(v146_10);
      let v146_13: Space = map_map_kernels::unite(&(v146_8),&(v146_12));
      join_wrapped_into(&mut v145_2325_write,&((v146_13).read_zipper()),&[]);
      }
      v145_2325_cursor.ascend(1);
    }
    drop(v145_2325_cursor);
    drop(v145_2325_write);
    map_map_kernels::compose(&(v132_2320),&(v145_2325))
  };
  drop(v132_2320);
  let v132_2327: Space = map_map_kernels::unite(&(v132_1552),&(v132_2326));
  let v132_2329: Space = map_map_kernels::intersect(&(*CONSTANT_10),&(v132_3));
  let v132_3095: Space = map_kernels::drop_length_prefixes(&(v132_2329));
  drop(v132_2329);
  let v132_3101: Space = if (&(v132_3095)).is_empty() { Space::new() } else {
    let mut v151_3100 = Space::new();
    let mut v151_3100_write = v151_3100.write_zipper();
    let mut v151_3100_cursor = (*capture_1).read_zipper();
    let v151_3100_origin = v151_3100_cursor.path().len();
    for v151_3100_byte in v151_3100_cursor.child_mask().iter() {
      v151_3100_cursor.descend_to_existing_byte(v151_3100_byte);
      {
      let v152_2: Space = singleton(&v151_3100_cursor.path()[v151_3100_origin..(v151_3100_origin + 1)]);
      let v152_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v152_2));
      let v152_4: Space = if map_kernels::has_head(&(v152_3)) { singleton(&[]) } else { Space::new() };
      drop(v152_3);
      let v152_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v152_4));
      drop(v152_4);
      let v152_8: Space = if (&(v152_5)).is_empty() { Space::new() } else {
        let mut v153_7 = Space::new();
        let mut v153_7_write = v153_7.write_zipper();
        let v153_7_arg_0: &[u8] = &(*CONSTANT_1);
        let v153_7_arg_1: &[u8] = &v151_3100_cursor.path()[v151_3100_origin..(v151_3100_origin + 1)];
        let v153_7_arg_3: &Space = &(&v151_3100_cursor).make_map();
        let mut v153_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v151_3100_cursor.path()[v151_3100_origin..(v151_3100_origin + 1)]);
        let v153_7_origin = v153_7_cursor.path().len();
        let mut v153_7_more = v153_7_cursor.is_val() || next_value_within(&mut v153_7_cursor,v153_7_origin);
        while v153_7_more {
          {
          let v153_7_depth = v153_7_cursor.path().len();
          let mut v154_4_cursor = (*v153_7_arg_3).read_zipper();
          let v154_4_origin = v154_4_cursor.path().len();
          for v154_4_byte in v154_4_cursor.child_mask().iter() {
            v154_4_cursor.descend_to_existing_byte(v154_4_byte);
            {
            let v155_2: Path = concat_path(&(*v153_7_arg_1),&v154_4_cursor.path()[v154_4_origin..(v154_4_origin + 1)]);
            let v155_3: Space = routine_28(c, &(v155_2), &v153_7_cursor.path()[v153_7_origin..v153_7_depth], &v154_4_cursor);
            drop(v155_2);
            join_wrapped_into(&mut v153_7_write,&((v155_3).read_zipper()),&[]);
            }
            v154_4_cursor.ascend(1);
          }
          drop(v154_4_cursor);
          }
          v153_7_more = next_value_within(&mut v153_7_cursor,v153_7_origin);
        }
        drop(v153_7_cursor);
        drop(v153_7_write);
        map_map_kernels::compose(&(v152_5),&(v153_7))
      };
      drop(v152_5);
      let v152_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v152_2));
      drop(v152_2);
      let v152_10: Space = if map_kernels::has_head(&(v152_9)) { singleton(&[]) } else { Space::new() };
      drop(v152_9);
      let v152_12: Space = if (&(v152_10)).is_empty() { Space::new() } else {
        let v156_11: Space = routine_29(c, &v151_3100_cursor.path()[v151_3100_origin..(v151_3100_origin + 1)], &v151_3100_cursor);
        map_map_kernels::compose(&(v152_10),&(v156_11))
      };
      drop(v152_10);
      let v152_13: Space = map_map_kernels::unite(&(v152_8),&(v152_12));
      join_wrapped_into(&mut v151_3100_write,&((v152_13).read_zipper()),&[]);
      }
      v151_3100_cursor.ascend(1);
    }
    drop(v151_3100_cursor);
    drop(v151_3100_write);
    map_map_kernels::compose(&(v132_3095),&(v151_3100))
  };
  drop(v132_3095);
  let v132_3102: Space = map_map_kernels::unite(&(v132_2327),&(v132_3101));
  let v132_3104: Space = map_map_kernels::intersect(&(*CONSTANT_11),&(v132_3));
  let v132_3870: Space = map_kernels::drop_length_prefixes(&(v132_3104));
  drop(v132_3104);
  let v132_3876: Space = if (&(v132_3870)).is_empty() { Space::new() } else {
    let mut v157_3875 = Space::new();
    let mut v157_3875_write = v157_3875.write_zipper();
    let mut v157_3875_cursor = (*capture_1).read_zipper();
    let v157_3875_origin = v157_3875_cursor.path().len();
    for v157_3875_byte in v157_3875_cursor.child_mask().iter() {
      v157_3875_cursor.descend_to_existing_byte(v157_3875_byte);
      {
      let v158_2: Space = singleton(&v157_3875_cursor.path()[v157_3875_origin..(v157_3875_origin + 1)]);
      let v158_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v158_2));
      let v158_4: Space = if map_kernels::has_head(&(v158_3)) { singleton(&[]) } else { Space::new() };
      drop(v158_3);
      let v158_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v158_4));
      drop(v158_4);
      let v158_8: Space = if (&(v158_5)).is_empty() { Space::new() } else {
        let mut v159_7 = Space::new();
        let mut v159_7_write = v159_7.write_zipper();
        let v159_7_arg_0: &[u8] = &(*CONSTANT_1);
        let v159_7_arg_1: &[u8] = &v157_3875_cursor.path()[v157_3875_origin..(v157_3875_origin + 1)];
        let v159_7_arg_3: &Space = &(&v157_3875_cursor).make_map();
        let mut v159_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v157_3875_cursor.path()[v157_3875_origin..(v157_3875_origin + 1)]);
        let v159_7_origin = v159_7_cursor.path().len();
        let mut v159_7_more = v159_7_cursor.is_val() || next_value_within(&mut v159_7_cursor,v159_7_origin);
        while v159_7_more {
          {
          let v159_7_depth = v159_7_cursor.path().len();
          let mut v160_4_cursor = (*v159_7_arg_3).read_zipper();
          let v160_4_origin = v160_4_cursor.path().len();
          for v160_4_byte in v160_4_cursor.child_mask().iter() {
            v160_4_cursor.descend_to_existing_byte(v160_4_byte);
            {
            let v161_2: Path = concat_path(&(*v159_7_arg_1),&v160_4_cursor.path()[v160_4_origin..(v160_4_origin + 1)]);
            let v161_3: Space = routine_30(c, &(v161_2), &v159_7_cursor.path()[v159_7_origin..v159_7_depth], &v160_4_cursor);
            drop(v161_2);
            join_wrapped_into(&mut v159_7_write,&((v161_3).read_zipper()),&[]);
            }
            v160_4_cursor.ascend(1);
          }
          drop(v160_4_cursor);
          }
          v159_7_more = next_value_within(&mut v159_7_cursor,v159_7_origin);
        }
        drop(v159_7_cursor);
        drop(v159_7_write);
        map_map_kernels::compose(&(v158_5),&(v159_7))
      };
      drop(v158_5);
      let v158_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v158_2));
      drop(v158_2);
      let v158_10: Space = if map_kernels::has_head(&(v158_9)) { singleton(&[]) } else { Space::new() };
      drop(v158_9);
      let v158_12: Space = if (&(v158_10)).is_empty() { Space::new() } else {
        let v162_11: Space = routine_31(c, &v157_3875_cursor.path()[v157_3875_origin..(v157_3875_origin + 1)], &v157_3875_cursor);
        map_map_kernels::compose(&(v158_10),&(v162_11))
      };
      drop(v158_10);
      let v158_13: Space = map_map_kernels::unite(&(v158_8),&(v158_12));
      join_wrapped_into(&mut v157_3875_write,&((v158_13).read_zipper()),&[]);
      }
      v157_3875_cursor.ascend(1);
    }
    drop(v157_3875_cursor);
    drop(v157_3875_write);
    map_map_kernels::compose(&(v132_3870),&(v157_3875))
  };
  drop(v132_3870);
  let v132_3877: Space = map_map_kernels::unite(&(v132_3102),&(v132_3876));
  let v132_3879: Space = map_map_kernels::intersect(&(*CONSTANT_12),&(v132_3));
  let v132_4645: Space = map_kernels::drop_length_prefixes(&(v132_3879));
  drop(v132_3879);
  let v132_4651: Space = if (&(v132_4645)).is_empty() { Space::new() } else {
    let mut v163_4650 = Space::new();
    let mut v163_4650_write = v163_4650.write_zipper();
    let mut v163_4650_cursor = (*capture_1).read_zipper();
    let v163_4650_origin = v163_4650_cursor.path().len();
    for v163_4650_byte in v163_4650_cursor.child_mask().iter() {
      v163_4650_cursor.descend_to_existing_byte(v163_4650_byte);
      {
      let v164_2: Space = singleton(&v163_4650_cursor.path()[v163_4650_origin..(v163_4650_origin + 1)]);
      let v164_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v164_2));
      let v164_4: Space = if map_kernels::has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
      drop(v164_3);
      let v164_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v164_4));
      drop(v164_4);
      let v164_8: Space = if (&(v164_5)).is_empty() { Space::new() } else {
        let mut v165_7 = Space::new();
        let mut v165_7_write = v165_7.write_zipper();
        let v165_7_arg_0: &[u8] = &(*CONSTANT_1);
        let v165_7_arg_1: &[u8] = &v163_4650_cursor.path()[v163_4650_origin..(v163_4650_origin + 1)];
        let v165_7_arg_3: &Space = &(&v163_4650_cursor).make_map();
        let mut v165_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v163_4650_cursor.path()[v163_4650_origin..(v163_4650_origin + 1)]);
        let v165_7_origin = v165_7_cursor.path().len();
        let mut v165_7_more = v165_7_cursor.is_val() || next_value_within(&mut v165_7_cursor,v165_7_origin);
        while v165_7_more {
          {
          let v165_7_depth = v165_7_cursor.path().len();
          let mut v166_4_cursor = (*v165_7_arg_3).read_zipper();
          let v166_4_origin = v166_4_cursor.path().len();
          for v166_4_byte in v166_4_cursor.child_mask().iter() {
            v166_4_cursor.descend_to_existing_byte(v166_4_byte);
            {
            let v167_2: Path = concat_path(&(*v165_7_arg_1),&v166_4_cursor.path()[v166_4_origin..(v166_4_origin + 1)]);
            let v167_3: Space = routine_32(c, &(v167_2), &v165_7_cursor.path()[v165_7_origin..v165_7_depth], &v166_4_cursor);
            drop(v167_2);
            join_wrapped_into(&mut v165_7_write,&((v167_3).read_zipper()),&[]);
            }
            v166_4_cursor.ascend(1);
          }
          drop(v166_4_cursor);
          }
          v165_7_more = next_value_within(&mut v165_7_cursor,v165_7_origin);
        }
        drop(v165_7_cursor);
        drop(v165_7_write);
        map_map_kernels::compose(&(v164_5),&(v165_7))
      };
      drop(v164_5);
      let v164_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v164_2));
      drop(v164_2);
      let v164_10: Space = if map_kernels::has_head(&(v164_9)) { singleton(&[]) } else { Space::new() };
      drop(v164_9);
      let v164_12: Space = if (&(v164_10)).is_empty() { Space::new() } else {
        let v168_11: Space = routine_33(c, &v163_4650_cursor.path()[v163_4650_origin..(v163_4650_origin + 1)], &v163_4650_cursor);
        map_map_kernels::compose(&(v164_10),&(v168_11))
      };
      drop(v164_10);
      let v164_13: Space = map_map_kernels::unite(&(v164_8),&(v164_12));
      join_wrapped_into(&mut v163_4650_write,&((v164_13).read_zipper()),&[]);
      }
      v163_4650_cursor.ascend(1);
    }
    drop(v163_4650_cursor);
    drop(v163_4650_write);
    map_map_kernels::compose(&(v132_4645),&(v163_4650))
  };
  drop(v132_4645);
  let v132_4652: Space = map_map_kernels::unite(&(v132_3877),&(v132_4651));
  let v132_4654: Space = map_map_kernels::intersect(&(*CONSTANT_13),&(v132_3));
  let v132_5420: Space = map_kernels::drop_length_prefixes(&(v132_4654));
  drop(v132_4654);
  let v132_5426: Space = if (&(v132_5420)).is_empty() { Space::new() } else {
    let mut v169_5425 = Space::new();
    let mut v169_5425_write = v169_5425.write_zipper();
    let mut v169_5425_cursor = (*capture_1).read_zipper();
    let v169_5425_origin = v169_5425_cursor.path().len();
    for v169_5425_byte in v169_5425_cursor.child_mask().iter() {
      v169_5425_cursor.descend_to_existing_byte(v169_5425_byte);
      {
      let v170_2: Space = singleton(&v169_5425_cursor.path()[v169_5425_origin..(v169_5425_origin + 1)]);
      let v170_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v170_2));
      let v170_4: Space = if map_kernels::has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
      drop(v170_3);
      let v170_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v170_4));
      drop(v170_4);
      let v170_8: Space = if (&(v170_5)).is_empty() { Space::new() } else {
        let mut v171_7 = Space::new();
        let mut v171_7_write = v171_7.write_zipper();
        let v171_7_arg_0: &[u8] = &(*CONSTANT_1);
        let v171_7_arg_1: &[u8] = &v169_5425_cursor.path()[v169_5425_origin..(v169_5425_origin + 1)];
        let v171_7_arg_3: &Space = &(&v169_5425_cursor).make_map();
        let mut v171_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v169_5425_cursor.path()[v169_5425_origin..(v169_5425_origin + 1)]);
        let v171_7_origin = v171_7_cursor.path().len();
        let mut v171_7_more = v171_7_cursor.is_val() || next_value_within(&mut v171_7_cursor,v171_7_origin);
        while v171_7_more {
          {
          let v171_7_depth = v171_7_cursor.path().len();
          let mut v172_4_cursor = (*v171_7_arg_3).read_zipper();
          let v172_4_origin = v172_4_cursor.path().len();
          for v172_4_byte in v172_4_cursor.child_mask().iter() {
            v172_4_cursor.descend_to_existing_byte(v172_4_byte);
            {
            let v173_2: Path = concat_path(&(*v171_7_arg_1),&v172_4_cursor.path()[v172_4_origin..(v172_4_origin + 1)]);
            let v173_3: Space = routine_34(c, &(v173_2), &v171_7_cursor.path()[v171_7_origin..v171_7_depth], &v172_4_cursor);
            drop(v173_2);
            join_wrapped_into(&mut v171_7_write,&((v173_3).read_zipper()),&[]);
            }
            v172_4_cursor.ascend(1);
          }
          drop(v172_4_cursor);
          }
          v171_7_more = next_value_within(&mut v171_7_cursor,v171_7_origin);
        }
        drop(v171_7_cursor);
        drop(v171_7_write);
        map_map_kernels::compose(&(v170_5),&(v171_7))
      };
      drop(v170_5);
      let v170_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v170_2));
      drop(v170_2);
      let v170_10: Space = if map_kernels::has_head(&(v170_9)) { singleton(&[]) } else { Space::new() };
      drop(v170_9);
      let v170_12: Space = if (&(v170_10)).is_empty() { Space::new() } else {
        let v174_11: Space = routine_35(c, &v169_5425_cursor.path()[v169_5425_origin..(v169_5425_origin + 1)], &v169_5425_cursor);
        map_map_kernels::compose(&(v170_10),&(v174_11))
      };
      drop(v170_10);
      let v170_13: Space = map_map_kernels::unite(&(v170_8),&(v170_12));
      join_wrapped_into(&mut v169_5425_write,&((v170_13).read_zipper()),&[]);
      }
      v169_5425_cursor.ascend(1);
    }
    drop(v169_5425_cursor);
    drop(v169_5425_write);
    map_map_kernels::compose(&(v132_5420),&(v169_5425))
  };
  drop(v132_5420);
  let v132_5427: Space = map_map_kernels::unite(&(v132_4652),&(v132_5426));
  let v132_5429: Space = map_map_kernels::intersect(&(*CONSTANT_14),&(v132_3));
  let v132_6195: Space = map_kernels::drop_length_prefixes(&(v132_5429));
  drop(v132_5429);
  let v132_6201: Space = if (&(v132_6195)).is_empty() { Space::new() } else {
    let mut v175_6200 = Space::new();
    let mut v175_6200_write = v175_6200.write_zipper();
    let mut v175_6200_cursor = (*capture_1).read_zipper();
    let v175_6200_origin = v175_6200_cursor.path().len();
    for v175_6200_byte in v175_6200_cursor.child_mask().iter() {
      v175_6200_cursor.descend_to_existing_byte(v175_6200_byte);
      {
      let v176_2: Space = singleton(&v175_6200_cursor.path()[v175_6200_origin..(v175_6200_origin + 1)]);
      let v176_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v176_2));
      let v176_4: Space = if map_kernels::has_head(&(v176_3)) { singleton(&[]) } else { Space::new() };
      drop(v176_3);
      let v176_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v176_4));
      drop(v176_4);
      let v176_8: Space = if (&(v176_5)).is_empty() { Space::new() } else {
        let mut v177_7 = Space::new();
        let mut v177_7_write = v177_7.write_zipper();
        let v177_7_arg_0: &[u8] = &(*CONSTANT_1);
        let v177_7_arg_1: &[u8] = &v175_6200_cursor.path()[v175_6200_origin..(v175_6200_origin + 1)];
        let v177_7_arg_3: &Space = &(&v175_6200_cursor).make_map();
        let mut v177_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v175_6200_cursor.path()[v175_6200_origin..(v175_6200_origin + 1)]);
        let v177_7_origin = v177_7_cursor.path().len();
        let mut v177_7_more = v177_7_cursor.is_val() || next_value_within(&mut v177_7_cursor,v177_7_origin);
        while v177_7_more {
          {
          let v177_7_depth = v177_7_cursor.path().len();
          let mut v178_4_cursor = (*v177_7_arg_3).read_zipper();
          let v178_4_origin = v178_4_cursor.path().len();
          for v178_4_byte in v178_4_cursor.child_mask().iter() {
            v178_4_cursor.descend_to_existing_byte(v178_4_byte);
            {
            let v179_2: Path = concat_path(&(*v177_7_arg_1),&v178_4_cursor.path()[v178_4_origin..(v178_4_origin + 1)]);
            let v179_3: Space = routine_36(c, &(v179_2), &v177_7_cursor.path()[v177_7_origin..v177_7_depth], &v178_4_cursor);
            drop(v179_2);
            join_wrapped_into(&mut v177_7_write,&((v179_3).read_zipper()),&[]);
            }
            v178_4_cursor.ascend(1);
          }
          drop(v178_4_cursor);
          }
          v177_7_more = next_value_within(&mut v177_7_cursor,v177_7_origin);
        }
        drop(v177_7_cursor);
        drop(v177_7_write);
        map_map_kernels::compose(&(v176_5),&(v177_7))
      };
      drop(v176_5);
      let v176_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v176_2));
      drop(v176_2);
      let v176_10: Space = if map_kernels::has_head(&(v176_9)) { singleton(&[]) } else { Space::new() };
      drop(v176_9);
      let v176_12: Space = if (&(v176_10)).is_empty() { Space::new() } else {
        let v180_11: Space = routine_37(c, &v175_6200_cursor.path()[v175_6200_origin..(v175_6200_origin + 1)], &v175_6200_cursor);
        map_map_kernels::compose(&(v176_10),&(v180_11))
      };
      drop(v176_10);
      let v176_13: Space = map_map_kernels::unite(&(v176_8),&(v176_12));
      join_wrapped_into(&mut v175_6200_write,&((v176_13).read_zipper()),&[]);
      }
      v175_6200_cursor.ascend(1);
    }
    drop(v175_6200_cursor);
    drop(v175_6200_write);
    map_map_kernels::compose(&(v132_6195),&(v175_6200))
  };
  drop(v132_6195);
  let v132_6202: Space = map_map_kernels::unite(&(v132_5427),&(v132_6201));
  let v132_6204: Space = map_map_kernels::intersect(&(*CONSTANT_15),&(v132_3));
  drop(v132_3);
  let v132_6970: Space = map_kernels::drop_length_prefixes(&(v132_6204));
  drop(v132_6204);
  let v132_6976: Space = if (&(v132_6970)).is_empty() { Space::new() } else {
    let mut v181_6975 = Space::new();
    let mut v181_6975_write = v181_6975.write_zipper();
    let mut v181_6975_cursor = (*capture_1).read_zipper();
    let v181_6975_origin = v181_6975_cursor.path().len();
    for v181_6975_byte in v181_6975_cursor.child_mask().iter() {
      v181_6975_cursor.descend_to_existing_byte(v181_6975_byte);
      {
      let v182_2: Space = singleton(&v181_6975_cursor.path()[v181_6975_origin..(v181_6975_origin + 1)]);
      let v182_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v182_2));
      let v182_4: Space = if map_kernels::has_head(&(v182_3)) { singleton(&[]) } else { Space::new() };
      drop(v182_3);
      let v182_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v182_4));
      drop(v182_4);
      let v182_8: Space = if (&(v182_5)).is_empty() { Space::new() } else {
        let mut v183_7 = Space::new();
        let mut v183_7_write = v183_7.write_zipper();
        let v183_7_arg_0: &[u8] = &(*CONSTANT_1);
        let v183_7_arg_1: &[u8] = &v181_6975_cursor.path()[v181_6975_origin..(v181_6975_origin + 1)];
        let v183_7_arg_3: &Space = &(&v181_6975_cursor).make_map();
        let mut v183_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v181_6975_cursor.path()[v181_6975_origin..(v181_6975_origin + 1)]);
        let v183_7_origin = v183_7_cursor.path().len();
        let mut v183_7_more = v183_7_cursor.is_val() || next_value_within(&mut v183_7_cursor,v183_7_origin);
        while v183_7_more {
          {
          let v183_7_depth = v183_7_cursor.path().len();
          let mut v184_4_cursor = (*v183_7_arg_3).read_zipper();
          let v184_4_origin = v184_4_cursor.path().len();
          for v184_4_byte in v184_4_cursor.child_mask().iter() {
            v184_4_cursor.descend_to_existing_byte(v184_4_byte);
            {
            let v185_2: Path = concat_path(&(*v183_7_arg_1),&v184_4_cursor.path()[v184_4_origin..(v184_4_origin + 1)]);
            let v185_3: Space = routine_38(c, &(v185_2), &v183_7_cursor.path()[v183_7_origin..v183_7_depth], &v184_4_cursor);
            drop(v185_2);
            join_wrapped_into(&mut v183_7_write,&((v185_3).read_zipper()),&[]);
            }
            v184_4_cursor.ascend(1);
          }
          drop(v184_4_cursor);
          }
          v183_7_more = next_value_within(&mut v183_7_cursor,v183_7_origin);
        }
        drop(v183_7_cursor);
        drop(v183_7_write);
        map_map_kernels::compose(&(v182_5),&(v183_7))
      };
      drop(v182_5);
      let v182_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v182_2));
      drop(v182_2);
      let v182_10: Space = if map_kernels::has_head(&(v182_9)) { singleton(&[]) } else { Space::new() };
      drop(v182_9);
      let v182_12: Space = if (&(v182_10)).is_empty() { Space::new() } else {
        let v186_11: Space = routine_39(c, &v181_6975_cursor.path()[v181_6975_origin..(v181_6975_origin + 1)], &v181_6975_cursor);
        map_map_kernels::compose(&(v182_10),&(v186_11))
      };
      drop(v182_10);
      let v182_13: Space = map_map_kernels::unite(&(v182_8),&(v182_12));
      join_wrapped_into(&mut v181_6975_write,&((v182_13).read_zipper()),&[]);
      }
      v181_6975_cursor.ascend(1);
    }
    drop(v181_6975_cursor);
    drop(v181_6975_write);
    map_map_kernels::compose(&(v132_6970),&(v181_6975))
  };
  drop(v132_6970);

((v132_1551).clone(),(v132_1552).clone(),(v132_2326).clone(),(v132_2327).clone(),(v132_3101).clone(),(v132_3102).clone(),(v132_3876).clone(),(v132_3877).clone(),(v132_4651).clone(),(v132_4652).clone(),(v132_5426).clone(),(v132_5427).clone(),(v132_6201).clone(),(v132_6202).clone(),(v132_6976).clone(),(v132_777).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let v0_6: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let mut v1_5 = Space::new();
    let mut v1_5_write = v1_5.write_zipper();
    let v1_5_arg_0: &[u8] = &(*CONSTANT_1);
    let v1_5_arg_1: &[u8] = &(*CONSTANT_2);
    let v1_5_arg_3: &Space = &(*CONSTANT_4);
    let mut v1_5_cursor = (*CONSTANT_3).read_zipper();
    let v1_5_origin = v1_5_cursor.path().len();
    let mut v1_5_more = v1_5_cursor.is_val() || next_value_within(&mut v1_5_cursor,v1_5_origin);
    while v1_5_more {
      {
      let v1_5_depth = v1_5_cursor.path().len();
      let mut v2_4_cursor = (*v1_5_arg_3).read_zipper();
      let v2_4_origin = v2_4_cursor.path().len();
      for v2_4_byte in v2_4_cursor.child_mask().iter() {
        v2_4_cursor.descend_to_existing_byte(v2_4_byte);
        {
        let v3_2: Path = concat_path(&(*v1_5_arg_1),&v2_4_cursor.path()[v2_4_origin..(v2_4_origin + 1)]);
        let v3_3: Space = routine_1(c, &(v3_2), &v1_5_cursor.path()[v1_5_origin..v1_5_depth], &v2_4_cursor);
        drop(v3_2);
        join_wrapped_into(&mut v1_5_write,&((v3_3).read_zipper()),&[]);
        }
        v2_4_cursor.ascend(1);
      }
      drop(v2_4_cursor);
      }
      v1_5_more = next_value_within(&mut v1_5_cursor,v1_5_origin);
    }
    drop(v1_5_cursor);
    drop(v1_5_write);
    map_map_kernels::compose(&(*CONSTANT_0),&(v1_5))
  };
  (v0_6).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v4_5: Space = singleton(&(*p1));
  let v4_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v4_5));
  let v4_7: Space = if map_kernels::has_head(&(v4_6)) { singleton(&[]) } else { Space::new() };
  drop(v4_6);
  let v4_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v4_7));
  drop(v4_7);
  let v4_19: Space = if (&(v4_8)).is_empty() { Space::new() } else {
    let v5_11: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v5_14: Space = if (&(v5_11)).is_empty() { Space::new() } else {
      let v6_13: Space = routine_2(c, &(*CONSTANT_1), &(*p0), &(*s0));
      map_map_kernels::compose(&(v5_11),&(v6_13))
    };
    drop(v5_11);
    let mut v5_17 = Space::new();
    let mut v5_17_write = v5_17.write_zipper();
    let mut v5_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v5_17_origin = v5_17_cursor.path().len();
    for v5_17_byte in v5_17_cursor.child_mask().iter() {
      v5_17_cursor.descend_to_existing_byte(v5_17_byte);
      {
      let v7_2_arg_0: &[u8] = &v5_17_cursor.path()[v5_17_origin..(v5_17_origin + 1)];
      let v7_2_arg_1: &[u8] = &(*p0);
      let v7_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v7_2_more = v5_17_cursor.is_val() || next_value_within(&mut v5_17_cursor,(v5_17_origin + 1));
      while v7_2_more {
        {
        let v7_2_depth = v5_17_cursor.path().len();
        let mut v8_4_cursor = (*v7_2_arg_3).read_zipper();
        let v8_4_origin = v8_4_cursor.path().len();
        for v8_4_byte in v8_4_cursor.child_mask().iter() {
          v8_4_cursor.descend_to_existing_byte(v8_4_byte);
          {
          let v9_2: Path = concat_path(&(*v7_2_arg_1),&v8_4_cursor.path()[v8_4_origin..(v8_4_origin + 1)]);
          let v9_3: Space = routine_1(c, &(v9_2), &v5_17_cursor.path()[v5_17_origin..v7_2_depth], &v8_4_cursor);
          drop(v9_2);
          join_wrapped_into(&mut v5_17_write,&((v9_3).read_zipper()),&[]);
          }
          v8_4_cursor.ascend(1);
        }
        drop(v8_4_cursor);
        }
        v7_2_more = next_value_within(&mut v5_17_cursor,(v5_17_origin + 1));
      }
      }
      v5_17_cursor.ascend(1);
    }
    drop(v5_17_cursor);
    drop(v5_17_write);
    let v5_18: Space = map_map_kernels::unite(&(v5_14),&(v5_17));
    map_map_kernels::compose(&(v4_8),&(v5_18))
  };
  drop(v4_8);
  let v4_21: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v4_5));
  drop(v4_5);
  let v4_22: Space = if map_kernels::has_head(&(v4_21)) { singleton(&[]) } else { Space::new() };
  drop(v4_21);
  let v4_24: Space = if (&(v4_22)).is_empty() { Space::new() } else {
    let mut v10_23 = Space::new();
    let mut v10_23_write = v10_23.write_zipper();
    let mut v10_23_cursor = (*s0).read_zipper();
    let v10_23_origin = v10_23_cursor.path().len();
    for v10_23_byte in v10_23_cursor.child_mask().iter() {
      v10_23_cursor.descend_to_existing_byte(v10_23_byte);
      {
      let v11_2: Space = routine_3(c, &v10_23_cursor.path()[v10_23_origin..(v10_23_origin + 1)], &v10_23_cursor.path()[v10_23_origin..(v10_23_origin + 1)], &(*p0), &v10_23_cursor);
      join_wrapped_into(&mut v10_23_write,&((v11_2).read_zipper()),&[]);
      }
      v10_23_cursor.ascend(1);
    }
    drop(v10_23_cursor);
    drop(v10_23_write);
    map_map_kernels::compose(&(v4_22),&(v10_23))
  };
  drop(v4_22);
  let v4_25: Space = map_map_kernels::unite(&(v4_19),&(v4_24));
  (v4_25).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v12_5: Space = singleton(&(*p0));
  let v12_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v12_5));
  let v12_7: Space = if map_kernels::has_head(&(v12_6)) { singleton(&[]) } else { Space::new() };
  drop(v12_6);
  let v12_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v12_7));
  drop(v12_7);
  let v12_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v12_5));
  drop(v12_5);
  let v12_14: Space = if map_kernels::has_head(&(v12_13)) { singleton(&[]) } else { Space::new() };
  drop(v12_13);
  let mut v12_15 = Space::new();
  let mut v12_15_write = v12_15.write_zipper();
  let mut v12_15_cursor = (*s0).read_zipper();
  let v12_15_origin = v12_15_cursor.path().len();
  for v12_15_byte in v12_15_cursor.child_mask().iter() {
    v12_15_cursor.descend_to_existing_byte(v12_15_byte);
    {
    let v13_4: Space = if (&(v12_8)).is_empty() { Space::new() } else {
      let v14_2: Path = concat_path(&(*p1),&v12_15_cursor.path()[v12_15_origin..(v12_15_origin + 1)]);
      let mut v14_3 = Space::new();
      let mut v14_3_write = v14_3.write_zipper();
      let v14_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v14_3_arg_1: &[u8] = &(v14_2);
      let v14_3_arg_3: &Space = &(&v12_15_cursor).make_map();
      let mut v14_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v14_3_origin = v14_3_cursor.path().len();
      let mut v14_3_more = v14_3_cursor.is_val() || next_value_within(&mut v14_3_cursor,v14_3_origin);
      while v14_3_more {
        {
        let v14_3_depth = v14_3_cursor.path().len();
        let v15_4: Space = routine_2(c, &v14_3_cursor.path()[v14_3_origin..v14_3_depth], &(*v14_3_arg_1), &((*v14_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v14_3_write,&((v15_4).read_zipper()),&[]);
        }
        v14_3_more = next_value_within(&mut v14_3_cursor,v14_3_origin);
      }
      drop(v14_3_cursor);
      drop(v14_3_write);
      map_map_kernels::compose(&(v12_8),&(v14_3))
    };
    let v13_6: Space = if (&(v12_14)).is_empty() { Space::new() } else {
      let v16_2: Path = concat_path(&(*p1),&v12_15_cursor.path()[v12_15_origin..(v12_15_origin + 1)]);
      let mut v16_5 = Space::new();
      let mut v16_5_write = v16_5.write_zipper();
      for v16_5_byte in v12_15_cursor.child_mask().iter() {
        v12_15_cursor.descend_to_existing_byte(v16_5_byte);
        {
        let v17_2: Space = routine_3(c, &v12_15_cursor.path()[(v12_15_origin + 1)..(v12_15_origin + 2)], &v12_15_cursor.path()[(v12_15_origin + 1)..(v12_15_origin + 2)], &(v16_2), &v12_15_cursor);
        join_wrapped_into(&mut v16_5_write,&((v17_2).read_zipper()),&[]);
        }
        v12_15_cursor.ascend(1);
      }
      drop(v16_5_write);
      drop(v16_2);
      map_map_kernels::compose(&(v12_14),&(v16_5))
    };
    let v13_7: Space = map_map_kernels::unite(&(v13_4),&(v13_6));
    join_wrapped_into(&mut v12_15_write,&((v13_7).read_zipper()),&[]);
    }
    v12_15_cursor.ascend(1);
  }
  drop(v12_15_cursor);
  drop(v12_15_write);
  drop(v12_8);
  drop(v12_14);
  (v12_15).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v18_6: Space = singleton(&(*p1));
  let v18_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v18_6));
  let v18_8: Space = if map_kernels::has_head(&(v18_7)) { singleton(&[]) } else { Space::new() };
  drop(v18_7);
  let v18_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v18_8));
  drop(v18_8);
  let v18_20: Space = if (&(v18_9)).is_empty() { Space::new() } else {
    let v19_12: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v19_15: Space = if (&(v19_12)).is_empty() { Space::new() } else {
      let v20_14: Space = routine_4(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      map_map_kernels::compose(&(v19_12),&(v20_14))
    };
    drop(v19_12);
    let mut v19_18 = Space::new();
    let mut v19_18_write = v19_18.write_zipper();
    let mut v19_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v19_18_origin = v19_18_cursor.path().len();
    for v19_18_byte in v19_18_cursor.child_mask().iter() {
      v19_18_cursor.descend_to_existing_byte(v19_18_byte);
      {
      let v21_2_arg_0: &[u8] = &v19_18_cursor.path()[v19_18_origin..(v19_18_origin + 1)];
      let v21_2_arg_1: &[u8] = &(*p0);
      let v21_2_arg_2: &[u8] = &(*p2);
      let v21_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v21_2_more = v19_18_cursor.is_val() || next_value_within(&mut v19_18_cursor,(v19_18_origin + 1));
      while v21_2_more {
        {
        let v21_2_depth = v19_18_cursor.path().len();
        let mut v22_5_cursor = (*v21_2_arg_4).read_zipper();
        let v22_5_origin = v22_5_cursor.path().len();
        for v22_5_byte in v22_5_cursor.child_mask().iter() {
          v22_5_cursor.descend_to_existing_byte(v22_5_byte);
          {
          let v23_2: Path = concat_path(&(*v21_2_arg_1),&v22_5_cursor.path()[v22_5_origin..(v22_5_origin + 1)]);
          let v23_3: Space = routine_3(c, &(v23_2), &v19_18_cursor.path()[v19_18_origin..v21_2_depth], &(*v21_2_arg_2), &v22_5_cursor);
          drop(v23_2);
          join_wrapped_into(&mut v19_18_write,&((v23_3).read_zipper()),&[]);
          }
          v22_5_cursor.ascend(1);
        }
        drop(v22_5_cursor);
        }
        v21_2_more = next_value_within(&mut v19_18_cursor,(v19_18_origin + 1));
      }
      }
      v19_18_cursor.ascend(1);
    }
    drop(v19_18_cursor);
    drop(v19_18_write);
    let v19_19: Space = map_map_kernels::unite(&(v19_15),&(v19_18));
    map_map_kernels::compose(&(v18_9),&(v19_19))
  };
  drop(v18_9);
  let v18_22: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v18_6));
  drop(v18_6);
  let v18_23: Space = if map_kernels::has_head(&(v18_22)) { singleton(&[]) } else { Space::new() };
  drop(v18_22);
  let v18_25: Space = if (&(v18_23)).is_empty() { Space::new() } else {
    let mut v24_24 = Space::new();
    let mut v24_24_write = v24_24.write_zipper();
    let mut v24_24_cursor = (*s0).read_zipper();
    let v24_24_origin = v24_24_cursor.path().len();
    for v24_24_byte in v24_24_cursor.child_mask().iter() {
      v24_24_cursor.descend_to_existing_byte(v24_24_byte);
      {
      let v25_2: Space = routine_5(c, &v24_24_cursor.path()[v24_24_origin..(v24_24_origin + 1)], &v24_24_cursor.path()[v24_24_origin..(v24_24_origin + 1)], &(*p2), &(*p0), &v24_24_cursor);
      join_wrapped_into(&mut v24_24_write,&((v25_2).read_zipper()),&[]);
      }
      v24_24_cursor.ascend(1);
    }
    drop(v24_24_cursor);
    drop(v24_24_write);
    map_map_kernels::compose(&(v18_23),&(v24_24))
  };
  drop(v18_23);
  let v18_26: Space = map_map_kernels::unite(&(v18_20),&(v18_25));
  (v18_26).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v26_6: Space = singleton(&(*p0));
  let v26_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v26_6));
  let v26_8: Space = if map_kernels::has_head(&(v26_7)) { singleton(&[]) } else { Space::new() };
  drop(v26_7);
  let v26_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v26_8));
  drop(v26_8);
  let v26_14: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v26_6));
  drop(v26_6);
  let v26_15: Space = if map_kernels::has_head(&(v26_14)) { singleton(&[]) } else { Space::new() };
  drop(v26_14);
  let mut v26_16 = Space::new();
  let mut v26_16_write = v26_16.write_zipper();
  let mut v26_16_cursor = (*s0).read_zipper();
  let v26_16_origin = v26_16_cursor.path().len();
  for v26_16_byte in v26_16_cursor.child_mask().iter() {
    v26_16_cursor.descend_to_existing_byte(v26_16_byte);
    {
    let v27_4: Space = if (&(v26_9)).is_empty() { Space::new() } else {
      let v28_2: Path = concat_path(&(*p1),&v26_16_cursor.path()[v26_16_origin..(v26_16_origin + 1)]);
      let mut v28_3 = Space::new();
      let mut v28_3_write = v28_3.write_zipper();
      let v28_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v28_3_arg_1: &[u8] = &(v28_2);
      let v28_3_arg_2: &[u8] = &(*p2);
      let v28_3_arg_4: &Space = &(&v26_16_cursor).make_map();
      let mut v28_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v28_3_origin = v28_3_cursor.path().len();
      let mut v28_3_more = v28_3_cursor.is_val() || next_value_within(&mut v28_3_cursor,v28_3_origin);
      while v28_3_more {
        {
        let v28_3_depth = v28_3_cursor.path().len();
        let v29_5: Space = routine_4(c, &v28_3_cursor.path()[v28_3_origin..v28_3_depth], &(*v28_3_arg_1), &(*v28_3_arg_2), &((*v28_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v28_3_write,&((v29_5).read_zipper()),&[]);
        }
        v28_3_more = next_value_within(&mut v28_3_cursor,v28_3_origin);
      }
      drop(v28_3_cursor);
      drop(v28_3_write);
      map_map_kernels::compose(&(v26_9),&(v28_3))
    };
    let v27_6: Space = if (&(v26_15)).is_empty() { Space::new() } else {
      let v30_2: Path = concat_path(&(*p1),&v26_16_cursor.path()[v26_16_origin..(v26_16_origin + 1)]);
      let mut v30_5 = Space::new();
      let mut v30_5_write = v30_5.write_zipper();
      for v30_5_byte in v26_16_cursor.child_mask().iter() {
        v26_16_cursor.descend_to_existing_byte(v30_5_byte);
        {
        let v31_2: Space = routine_5(c, &v26_16_cursor.path()[(v26_16_origin + 1)..(v26_16_origin + 2)], &v26_16_cursor.path()[(v26_16_origin + 1)..(v26_16_origin + 2)], &(*p2), &(v30_2), &v26_16_cursor);
        join_wrapped_into(&mut v30_5_write,&((v31_2).read_zipper()),&[]);
        }
        v26_16_cursor.ascend(1);
      }
      drop(v30_5_write);
      drop(v30_2);
      map_map_kernels::compose(&(v26_15),&(v30_5))
    };
    let v27_7: Space = map_map_kernels::unite(&(v27_4),&(v27_6));
    join_wrapped_into(&mut v26_16_write,&((v27_7).read_zipper()),&[]);
    }
    v26_16_cursor.ascend(1);
  }
  drop(v26_16_cursor);
  drop(v26_16_write);
  drop(v26_9);
  drop(v26_15);
  (v26_16).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v32_7: Space = singleton(&(*p1));
  let v32_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v32_7));
  let v32_9: Space = if map_kernels::has_head(&(v32_8)) { singleton(&[]) } else { Space::new() };
  drop(v32_8);
  let v32_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v32_9));
  drop(v32_9);
  let v32_21: Space = if (&(v32_10)).is_empty() { Space::new() } else {
    let v33_13: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v33_16: Space = if (&(v33_13)).is_empty() { Space::new() } else {
      let v34_15: Space = routine_6(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      map_map_kernels::compose(&(v33_13),&(v34_15))
    };
    drop(v33_13);
    let mut v33_19 = Space::new();
    let mut v33_19_write = v33_19.write_zipper();
    let mut v33_19_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v33_19_origin = v33_19_cursor.path().len();
    for v33_19_byte in v33_19_cursor.child_mask().iter() {
      v33_19_cursor.descend_to_existing_byte(v33_19_byte);
      {
      let v35_2_arg_0: &[u8] = &v33_19_cursor.path()[v33_19_origin..(v33_19_origin + 1)];
      let v35_2_arg_1: &[u8] = &(*p0);
      let v35_2_arg_2: &[u8] = &(*p2);
      let v35_2_arg_3: &[u8] = &(*p3);
      let v35_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v35_2_more = v33_19_cursor.is_val() || next_value_within(&mut v33_19_cursor,(v33_19_origin + 1));
      while v35_2_more {
        {
        let v35_2_depth = v33_19_cursor.path().len();
        let mut v36_6_cursor = (*v35_2_arg_5).read_zipper();
        let v36_6_origin = v36_6_cursor.path().len();
        for v36_6_byte in v36_6_cursor.child_mask().iter() {
          v36_6_cursor.descend_to_existing_byte(v36_6_byte);
          {
          let v37_2: Path = concat_path(&(*v35_2_arg_1),&v36_6_cursor.path()[v36_6_origin..(v36_6_origin + 1)]);
          let v37_3: Space = routine_5(c, &(v37_2), &v33_19_cursor.path()[v33_19_origin..v35_2_depth], &(*v35_2_arg_2), &(*v35_2_arg_3), &v36_6_cursor);
          drop(v37_2);
          join_wrapped_into(&mut v33_19_write,&((v37_3).read_zipper()),&[]);
          }
          v36_6_cursor.ascend(1);
        }
        drop(v36_6_cursor);
        }
        v35_2_more = next_value_within(&mut v33_19_cursor,(v33_19_origin + 1));
      }
      }
      v33_19_cursor.ascend(1);
    }
    drop(v33_19_cursor);
    drop(v33_19_write);
    let v33_20: Space = map_map_kernels::unite(&(v33_16),&(v33_19));
    map_map_kernels::compose(&(v32_10),&(v33_20))
  };
  drop(v32_10);
  let v32_23: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v32_7));
  drop(v32_7);
  let v32_24: Space = if map_kernels::has_head(&(v32_23)) { singleton(&[]) } else { Space::new() };
  drop(v32_23);
  let v32_26: Space = if (&(v32_24)).is_empty() { Space::new() } else {
    let mut v38_25 = Space::new();
    let mut v38_25_write = v38_25.write_zipper();
    let mut v38_25_cursor = (*s0).read_zipper();
    let v38_25_origin = v38_25_cursor.path().len();
    for v38_25_byte in v38_25_cursor.child_mask().iter() {
      v38_25_cursor.descend_to_existing_byte(v38_25_byte);
      {
      let v39_2: Space = routine_7(c, &v38_25_cursor.path()[v38_25_origin..(v38_25_origin + 1)], &v38_25_cursor.path()[v38_25_origin..(v38_25_origin + 1)], &(*p2), &(*p3), &(*p0), &v38_25_cursor);
      join_wrapped_into(&mut v38_25_write,&((v39_2).read_zipper()),&[]);
      }
      v38_25_cursor.ascend(1);
    }
    drop(v38_25_cursor);
    drop(v38_25_write);
    map_map_kernels::compose(&(v32_24),&(v38_25))
  };
  drop(v32_24);
  let v32_27: Space = map_map_kernels::unite(&(v32_21),&(v32_26));
  (v32_27).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v40_7: Space = singleton(&(*p0));
  let v40_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v40_7));
  let v40_9: Space = if map_kernels::has_head(&(v40_8)) { singleton(&[]) } else { Space::new() };
  drop(v40_8);
  let v40_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v40_9));
  drop(v40_9);
  let v40_15: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v40_7));
  drop(v40_7);
  let v40_16: Space = if map_kernels::has_head(&(v40_15)) { singleton(&[]) } else { Space::new() };
  drop(v40_15);
  let mut v40_17 = Space::new();
  let mut v40_17_write = v40_17.write_zipper();
  let mut v40_17_cursor = (*s0).read_zipper();
  let v40_17_origin = v40_17_cursor.path().len();
  for v40_17_byte in v40_17_cursor.child_mask().iter() {
    v40_17_cursor.descend_to_existing_byte(v40_17_byte);
    {
    let v41_4: Space = if (&(v40_10)).is_empty() { Space::new() } else {
      let v42_2: Path = concat_path(&(*p1),&v40_17_cursor.path()[v40_17_origin..(v40_17_origin + 1)]);
      let mut v42_3 = Space::new();
      let mut v42_3_write = v42_3.write_zipper();
      let v42_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v42_3_arg_1: &[u8] = &(v42_2);
      let v42_3_arg_2: &[u8] = &(*p2);
      let v42_3_arg_3: &[u8] = &(*p3);
      let v42_3_arg_5: &Space = &(&v40_17_cursor).make_map();
      let mut v42_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v42_3_origin = v42_3_cursor.path().len();
      let mut v42_3_more = v42_3_cursor.is_val() || next_value_within(&mut v42_3_cursor,v42_3_origin);
      while v42_3_more {
        {
        let v42_3_depth = v42_3_cursor.path().len();
        let v43_6: Space = routine_6(c, &v42_3_cursor.path()[v42_3_origin..v42_3_depth], &(*v42_3_arg_1), &(*v42_3_arg_2), &(*v42_3_arg_3), &((*v42_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v42_3_write,&((v43_6).read_zipper()),&[]);
        }
        v42_3_more = next_value_within(&mut v42_3_cursor,v42_3_origin);
      }
      drop(v42_3_cursor);
      drop(v42_3_write);
      map_map_kernels::compose(&(v40_10),&(v42_3))
    };
    let v41_6: Space = if (&(v40_16)).is_empty() { Space::new() } else {
      let v44_2: Path = concat_path(&(*p1),&v40_17_cursor.path()[v40_17_origin..(v40_17_origin + 1)]);
      let mut v44_5 = Space::new();
      let mut v44_5_write = v44_5.write_zipper();
      for v44_5_byte in v40_17_cursor.child_mask().iter() {
        v40_17_cursor.descend_to_existing_byte(v44_5_byte);
        {
        let v45_2: Space = routine_7(c, &v40_17_cursor.path()[(v40_17_origin + 1)..(v40_17_origin + 2)], &v40_17_cursor.path()[(v40_17_origin + 1)..(v40_17_origin + 2)], &(*p2), &(*p3), &(v44_2), &v40_17_cursor);
        join_wrapped_into(&mut v44_5_write,&((v45_2).read_zipper()),&[]);
        }
        v40_17_cursor.ascend(1);
      }
      drop(v44_5_write);
      drop(v44_2);
      map_map_kernels::compose(&(v40_16),&(v44_5))
    };
    let v41_7: Space = map_map_kernels::unite(&(v41_4),&(v41_6));
    join_wrapped_into(&mut v40_17_write,&((v41_7).read_zipper()),&[]);
    }
    v40_17_cursor.ascend(1);
  }
  drop(v40_17_cursor);
  drop(v40_17_write);
  drop(v40_10);
  drop(v40_16);
  (v40_17).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v46_8: Space = singleton(&(*p1));
  let v46_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v46_8));
  let v46_10: Space = if map_kernels::has_head(&(v46_9)) { singleton(&[]) } else { Space::new() };
  drop(v46_9);
  let v46_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v46_10));
  drop(v46_10);
  let v46_22: Space = if (&(v46_11)).is_empty() { Space::new() } else {
    let v47_14: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v47_17: Space = if (&(v47_14)).is_empty() { Space::new() } else {
      let v48_16: Space = routine_8(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*s0));
      map_map_kernels::compose(&(v47_14),&(v48_16))
    };
    drop(v47_14);
    let mut v47_20 = Space::new();
    let mut v47_20_write = v47_20.write_zipper();
    let mut v47_20_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v47_20_origin = v47_20_cursor.path().len();
    for v47_20_byte in v47_20_cursor.child_mask().iter() {
      v47_20_cursor.descend_to_existing_byte(v47_20_byte);
      {
      let v49_2_arg_0: &[u8] = &v47_20_cursor.path()[v47_20_origin..(v47_20_origin + 1)];
      let v49_2_arg_1: &[u8] = &(*p0);
      let v49_2_arg_2: &[u8] = &(*p2);
      let v49_2_arg_3: &[u8] = &(*p3);
      let v49_2_arg_4: &[u8] = &(*p4);
      let v49_2_arg_6: &Space = &(&(*s0)).make_map();
      let mut v49_2_more = v47_20_cursor.is_val() || next_value_within(&mut v47_20_cursor,(v47_20_origin + 1));
      while v49_2_more {
        {
        let v49_2_depth = v47_20_cursor.path().len();
        let mut v50_7_cursor = (*v49_2_arg_6).read_zipper();
        let v50_7_origin = v50_7_cursor.path().len();
        for v50_7_byte in v50_7_cursor.child_mask().iter() {
          v50_7_cursor.descend_to_existing_byte(v50_7_byte);
          {
          let v51_2: Path = concat_path(&(*v49_2_arg_1),&v50_7_cursor.path()[v50_7_origin..(v50_7_origin + 1)]);
          let v51_3: Space = routine_7(c, &(v51_2), &v47_20_cursor.path()[v47_20_origin..v49_2_depth], &(*v49_2_arg_2), &(*v49_2_arg_3), &(*v49_2_arg_4), &v50_7_cursor);
          drop(v51_2);
          join_wrapped_into(&mut v47_20_write,&((v51_3).read_zipper()),&[]);
          }
          v50_7_cursor.ascend(1);
        }
        drop(v50_7_cursor);
        }
        v49_2_more = next_value_within(&mut v47_20_cursor,(v47_20_origin + 1));
      }
      }
      v47_20_cursor.ascend(1);
    }
    drop(v47_20_cursor);
    drop(v47_20_write);
    let v47_21: Space = map_map_kernels::unite(&(v47_17),&(v47_20));
    map_map_kernels::compose(&(v46_11),&(v47_21))
  };
  drop(v46_11);
  let v46_24: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v46_8));
  drop(v46_8);
  let v46_25: Space = if map_kernels::has_head(&(v46_24)) { singleton(&[]) } else { Space::new() };
  drop(v46_24);
  let v46_27: Space = if (&(v46_25)).is_empty() { Space::new() } else {
    let mut v52_26 = Space::new();
    let mut v52_26_write = v52_26.write_zipper();
    let mut v52_26_cursor = (*s0).read_zipper();
    let v52_26_origin = v52_26_cursor.path().len();
    for v52_26_byte in v52_26_cursor.child_mask().iter() {
      v52_26_cursor.descend_to_existing_byte(v52_26_byte);
      {
      let v53_2: Space = routine_9(c, &v52_26_cursor.path()[v52_26_origin..(v52_26_origin + 1)], &v52_26_cursor.path()[v52_26_origin..(v52_26_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p0), &v52_26_cursor);
      join_wrapped_into(&mut v52_26_write,&((v53_2).read_zipper()),&[]);
      }
      v52_26_cursor.ascend(1);
    }
    drop(v52_26_cursor);
    drop(v52_26_write);
    map_map_kernels::compose(&(v46_25),&(v52_26))
  };
  drop(v46_25);
  let v46_28: Space = map_map_kernels::unite(&(v46_22),&(v46_27));
  (v46_28).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v54_8: Space = singleton(&(*p0));
  let v54_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v54_8));
  let v54_10: Space = if map_kernels::has_head(&(v54_9)) { singleton(&[]) } else { Space::new() };
  drop(v54_9);
  let v54_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v54_10));
  drop(v54_10);
  let v54_16: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v54_8));
  drop(v54_8);
  let v54_17: Space = if map_kernels::has_head(&(v54_16)) { singleton(&[]) } else { Space::new() };
  drop(v54_16);
  let mut v54_18 = Space::new();
  let mut v54_18_write = v54_18.write_zipper();
  let mut v54_18_cursor = (*s0).read_zipper();
  let v54_18_origin = v54_18_cursor.path().len();
  for v54_18_byte in v54_18_cursor.child_mask().iter() {
    v54_18_cursor.descend_to_existing_byte(v54_18_byte);
    {
    let v55_4: Space = if (&(v54_11)).is_empty() { Space::new() } else {
      let v56_2: Path = concat_path(&(*p1),&v54_18_cursor.path()[v54_18_origin..(v54_18_origin + 1)]);
      let mut v56_3 = Space::new();
      let mut v56_3_write = v56_3.write_zipper();
      let v56_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v56_3_arg_1: &[u8] = &(v56_2);
      let v56_3_arg_2: &[u8] = &(*p2);
      let v56_3_arg_3: &[u8] = &(*p3);
      let v56_3_arg_4: &[u8] = &(*p4);
      let v56_3_arg_6: &Space = &(&v54_18_cursor).make_map();
      let mut v56_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v56_3_origin = v56_3_cursor.path().len();
      let mut v56_3_more = v56_3_cursor.is_val() || next_value_within(&mut v56_3_cursor,v56_3_origin);
      while v56_3_more {
        {
        let v56_3_depth = v56_3_cursor.path().len();
        let v57_7: Space = routine_8(c, &v56_3_cursor.path()[v56_3_origin..v56_3_depth], &(*v56_3_arg_1), &(*v56_3_arg_2), &(*v56_3_arg_3), &(*v56_3_arg_4), &((*v56_3_arg_6).read_zipper()));
        join_wrapped_into(&mut v56_3_write,&((v57_7).read_zipper()),&[]);
        }
        v56_3_more = next_value_within(&mut v56_3_cursor,v56_3_origin);
      }
      drop(v56_3_cursor);
      drop(v56_3_write);
      map_map_kernels::compose(&(v54_11),&(v56_3))
    };
    let v55_6: Space = if (&(v54_17)).is_empty() { Space::new() } else {
      let v58_2: Path = concat_path(&(*p1),&v54_18_cursor.path()[v54_18_origin..(v54_18_origin + 1)]);
      let mut v58_5 = Space::new();
      let mut v58_5_write = v58_5.write_zipper();
      for v58_5_byte in v54_18_cursor.child_mask().iter() {
        v54_18_cursor.descend_to_existing_byte(v58_5_byte);
        {
        let v59_2: Space = routine_9(c, &v54_18_cursor.path()[(v54_18_origin + 1)..(v54_18_origin + 2)], &v54_18_cursor.path()[(v54_18_origin + 1)..(v54_18_origin + 2)], &(*p2), &(*p3), &(*p4), &(v58_2), &v54_18_cursor);
        join_wrapped_into(&mut v58_5_write,&((v59_2).read_zipper()),&[]);
        }
        v54_18_cursor.ascend(1);
      }
      drop(v58_5_write);
      drop(v58_2);
      map_map_kernels::compose(&(v54_17),&(v58_5))
    };
    let v55_7: Space = map_map_kernels::unite(&(v55_4),&(v55_6));
    join_wrapped_into(&mut v54_18_write,&((v55_7).read_zipper()),&[]);
    }
    v54_18_cursor.ascend(1);
  }
  drop(v54_18_cursor);
  drop(v54_18_write);
  drop(v54_11);
  drop(v54_17);
  (v54_18).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v60_9: Space = singleton(&(*p1));
  let v60_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v60_9));
  let v60_11: Space = if map_kernels::has_head(&(v60_10)) { singleton(&[]) } else { Space::new() };
  drop(v60_10);
  let v60_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v60_11));
  drop(v60_11);
  let v60_23: Space = if (&(v60_12)).is_empty() { Space::new() } else {
    let v61_15: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v61_18: Space = if (&(v61_15)).is_empty() { Space::new() } else {
      let v62_17: Space = routine_10(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*s0));
      map_map_kernels::compose(&(v61_15),&(v62_17))
    };
    drop(v61_15);
    let mut v61_21 = Space::new();
    let mut v61_21_write = v61_21.write_zipper();
    let mut v61_21_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v61_21_origin = v61_21_cursor.path().len();
    for v61_21_byte in v61_21_cursor.child_mask().iter() {
      v61_21_cursor.descend_to_existing_byte(v61_21_byte);
      {
      let v63_2_arg_0: &[u8] = &v61_21_cursor.path()[v61_21_origin..(v61_21_origin + 1)];
      let v63_2_arg_1: &[u8] = &(*p0);
      let v63_2_arg_2: &[u8] = &(*p2);
      let v63_2_arg_3: &[u8] = &(*p3);
      let v63_2_arg_4: &[u8] = &(*p4);
      let v63_2_arg_5: &[u8] = &(*p5);
      let v63_2_arg_7: &Space = &(&(*s0)).make_map();
      let mut v63_2_more = v61_21_cursor.is_val() || next_value_within(&mut v61_21_cursor,(v61_21_origin + 1));
      while v63_2_more {
        {
        let v63_2_depth = v61_21_cursor.path().len();
        let mut v64_8_cursor = (*v63_2_arg_7).read_zipper();
        let v64_8_origin = v64_8_cursor.path().len();
        for v64_8_byte in v64_8_cursor.child_mask().iter() {
          v64_8_cursor.descend_to_existing_byte(v64_8_byte);
          {
          let v65_2: Path = concat_path(&(*v63_2_arg_1),&v64_8_cursor.path()[v64_8_origin..(v64_8_origin + 1)]);
          let v65_3: Space = routine_9(c, &(v65_2), &v61_21_cursor.path()[v61_21_origin..v63_2_depth], &(*v63_2_arg_2), &(*v63_2_arg_3), &(*v63_2_arg_4), &(*v63_2_arg_5), &v64_8_cursor);
          drop(v65_2);
          join_wrapped_into(&mut v61_21_write,&((v65_3).read_zipper()),&[]);
          }
          v64_8_cursor.ascend(1);
        }
        drop(v64_8_cursor);
        }
        v63_2_more = next_value_within(&mut v61_21_cursor,(v61_21_origin + 1));
      }
      }
      v61_21_cursor.ascend(1);
    }
    drop(v61_21_cursor);
    drop(v61_21_write);
    let v61_22: Space = map_map_kernels::unite(&(v61_18),&(v61_21));
    map_map_kernels::compose(&(v60_12),&(v61_22))
  };
  drop(v60_12);
  let v60_25: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v60_9));
  drop(v60_9);
  let v60_26: Space = if map_kernels::has_head(&(v60_25)) { singleton(&[]) } else { Space::new() };
  drop(v60_25);
  let v60_28: Space = if (&(v60_26)).is_empty() { Space::new() } else {
    let mut v66_27 = Space::new();
    let mut v66_27_write = v66_27.write_zipper();
    let mut v66_27_cursor = (*s0).read_zipper();
    let v66_27_origin = v66_27_cursor.path().len();
    for v66_27_byte in v66_27_cursor.child_mask().iter() {
      v66_27_cursor.descend_to_existing_byte(v66_27_byte);
      {
      let v67_2: Space = routine_11(c, &v66_27_cursor.path()[v66_27_origin..(v66_27_origin + 1)], &v66_27_cursor.path()[v66_27_origin..(v66_27_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v66_27_cursor);
      join_wrapped_into(&mut v66_27_write,&((v67_2).read_zipper()),&[]);
      }
      v66_27_cursor.ascend(1);
    }
    drop(v66_27_cursor);
    drop(v66_27_write);
    map_map_kernels::compose(&(v60_26),&(v66_27))
  };
  drop(v60_26);
  let v60_29: Space = map_map_kernels::unite(&(v60_23),&(v60_28));
  (v60_29).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v68_9: Space = singleton(&(*p0));
  let v68_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v68_9));
  let v68_11: Space = if map_kernels::has_head(&(v68_10)) { singleton(&[]) } else { Space::new() };
  drop(v68_10);
  let v68_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v68_11));
  drop(v68_11);
  let v68_17: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v68_9));
  drop(v68_9);
  let v68_18: Space = if map_kernels::has_head(&(v68_17)) { singleton(&[]) } else { Space::new() };
  drop(v68_17);
  let mut v68_19 = Space::new();
  let mut v68_19_write = v68_19.write_zipper();
  let mut v68_19_cursor = (*s0).read_zipper();
  let v68_19_origin = v68_19_cursor.path().len();
  for v68_19_byte in v68_19_cursor.child_mask().iter() {
    v68_19_cursor.descend_to_existing_byte(v68_19_byte);
    {
    let v69_4: Space = if (&(v68_12)).is_empty() { Space::new() } else {
      let v70_2: Path = concat_path(&(*p1),&v68_19_cursor.path()[v68_19_origin..(v68_19_origin + 1)]);
      let mut v70_3 = Space::new();
      let mut v70_3_write = v70_3.write_zipper();
      let v70_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v70_3_arg_1: &[u8] = &(v70_2);
      let v70_3_arg_2: &[u8] = &(*p2);
      let v70_3_arg_3: &[u8] = &(*p3);
      let v70_3_arg_4: &[u8] = &(*p4);
      let v70_3_arg_5: &[u8] = &(*p5);
      let v70_3_arg_7: &Space = &(&v68_19_cursor).make_map();
      let mut v70_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v70_3_origin = v70_3_cursor.path().len();
      let mut v70_3_more = v70_3_cursor.is_val() || next_value_within(&mut v70_3_cursor,v70_3_origin);
      while v70_3_more {
        {
        let v70_3_depth = v70_3_cursor.path().len();
        let v71_8: Space = routine_10(c, &v70_3_cursor.path()[v70_3_origin..v70_3_depth], &(*v70_3_arg_1), &(*v70_3_arg_2), &(*v70_3_arg_3), &(*v70_3_arg_4), &(*v70_3_arg_5), &((*v70_3_arg_7).read_zipper()));
        join_wrapped_into(&mut v70_3_write,&((v71_8).read_zipper()),&[]);
        }
        v70_3_more = next_value_within(&mut v70_3_cursor,v70_3_origin);
      }
      drop(v70_3_cursor);
      drop(v70_3_write);
      map_map_kernels::compose(&(v68_12),&(v70_3))
    };
    let v69_6: Space = if (&(v68_18)).is_empty() { Space::new() } else {
      let v72_2: Path = concat_path(&(*p1),&v68_19_cursor.path()[v68_19_origin..(v68_19_origin + 1)]);
      let mut v72_5 = Space::new();
      let mut v72_5_write = v72_5.write_zipper();
      for v72_5_byte in v68_19_cursor.child_mask().iter() {
        v68_19_cursor.descend_to_existing_byte(v72_5_byte);
        {
        let v73_2: Space = routine_11(c, &v68_19_cursor.path()[(v68_19_origin + 1)..(v68_19_origin + 2)], &v68_19_cursor.path()[(v68_19_origin + 1)..(v68_19_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(v72_2), &v68_19_cursor);
        join_wrapped_into(&mut v72_5_write,&((v73_2).read_zipper()),&[]);
        }
        v68_19_cursor.ascend(1);
      }
      drop(v72_5_write);
      drop(v72_2);
      map_map_kernels::compose(&(v68_18),&(v72_5))
    };
    let v69_7: Space = map_map_kernels::unite(&(v69_4),&(v69_6));
    join_wrapped_into(&mut v68_19_write,&((v69_7).read_zipper()),&[]);
    }
    v68_19_cursor.ascend(1);
  }
  drop(v68_19_cursor);
  drop(v68_19_write);
  drop(v68_12);
  drop(v68_18);
  (v68_19).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v74_10: Space = singleton(&(*p1));
  let v74_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v74_10));
  let v74_12: Space = if map_kernels::has_head(&(v74_11)) { singleton(&[]) } else { Space::new() };
  drop(v74_11);
  let v74_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v74_12));
  drop(v74_12);
  let v74_24: Space = if (&(v74_13)).is_empty() { Space::new() } else {
    let v75_16: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v75_19: Space = if (&(v75_16)).is_empty() { Space::new() } else {
      let v76_18: Space = routine_12(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*s0));
      map_map_kernels::compose(&(v75_16),&(v76_18))
    };
    drop(v75_16);
    let mut v75_22 = Space::new();
    let mut v75_22_write = v75_22.write_zipper();
    let mut v75_22_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v75_22_origin = v75_22_cursor.path().len();
    for v75_22_byte in v75_22_cursor.child_mask().iter() {
      v75_22_cursor.descend_to_existing_byte(v75_22_byte);
      {
      let v77_2_arg_0: &[u8] = &v75_22_cursor.path()[v75_22_origin..(v75_22_origin + 1)];
      let v77_2_arg_1: &[u8] = &(*p0);
      let v77_2_arg_2: &[u8] = &(*p2);
      let v77_2_arg_3: &[u8] = &(*p3);
      let v77_2_arg_4: &[u8] = &(*p4);
      let v77_2_arg_5: &[u8] = &(*p5);
      let v77_2_arg_6: &[u8] = &(*p6);
      let v77_2_arg_8: &Space = &(&(*s0)).make_map();
      let mut v77_2_more = v75_22_cursor.is_val() || next_value_within(&mut v75_22_cursor,(v75_22_origin + 1));
      while v77_2_more {
        {
        let v77_2_depth = v75_22_cursor.path().len();
        let mut v78_9_cursor = (*v77_2_arg_8).read_zipper();
        let v78_9_origin = v78_9_cursor.path().len();
        for v78_9_byte in v78_9_cursor.child_mask().iter() {
          v78_9_cursor.descend_to_existing_byte(v78_9_byte);
          {
          let v79_2: Path = concat_path(&(*v77_2_arg_1),&v78_9_cursor.path()[v78_9_origin..(v78_9_origin + 1)]);
          let v79_3: Space = routine_11(c, &(v79_2), &v75_22_cursor.path()[v75_22_origin..v77_2_depth], &(*v77_2_arg_2), &(*v77_2_arg_3), &(*v77_2_arg_4), &(*v77_2_arg_5), &(*v77_2_arg_6), &v78_9_cursor);
          drop(v79_2);
          join_wrapped_into(&mut v75_22_write,&((v79_3).read_zipper()),&[]);
          }
          v78_9_cursor.ascend(1);
        }
        drop(v78_9_cursor);
        }
        v77_2_more = next_value_within(&mut v75_22_cursor,(v75_22_origin + 1));
      }
      }
      v75_22_cursor.ascend(1);
    }
    drop(v75_22_cursor);
    drop(v75_22_write);
    let v75_23: Space = map_map_kernels::unite(&(v75_19),&(v75_22));
    map_map_kernels::compose(&(v74_13),&(v75_23))
  };
  drop(v74_13);
  let v74_26: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v74_10));
  drop(v74_10);
  let v74_27: Space = if map_kernels::has_head(&(v74_26)) { singleton(&[]) } else { Space::new() };
  drop(v74_26);
  let v74_29: Space = if (&(v74_27)).is_empty() { Space::new() } else {
    let mut v80_28 = Space::new();
    let mut v80_28_write = v80_28.write_zipper();
    let mut v80_28_cursor = (*s0).read_zipper();
    let v80_28_origin = v80_28_cursor.path().len();
    for v80_28_byte in v80_28_cursor.child_mask().iter() {
      v80_28_cursor.descend_to_existing_byte(v80_28_byte);
      {
      let v81_2: Space = routine_13(c, &v80_28_cursor.path()[v80_28_origin..(v80_28_origin + 1)], &v80_28_cursor.path()[v80_28_origin..(v80_28_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v80_28_cursor);
      join_wrapped_into(&mut v80_28_write,&((v81_2).read_zipper()),&[]);
      }
      v80_28_cursor.ascend(1);
    }
    drop(v80_28_cursor);
    drop(v80_28_write);
    map_map_kernels::compose(&(v74_27),&(v80_28))
  };
  drop(v74_27);
  let v74_30: Space = map_map_kernels::unite(&(v74_24),&(v74_29));
  (v74_30).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v82_10: Space = singleton(&(*p0));
  let v82_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v82_10));
  let v82_12: Space = if map_kernels::has_head(&(v82_11)) { singleton(&[]) } else { Space::new() };
  drop(v82_11);
  let v82_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v82_12));
  drop(v82_12);
  let v82_18: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v82_10));
  drop(v82_10);
  let v82_19: Space = if map_kernels::has_head(&(v82_18)) { singleton(&[]) } else { Space::new() };
  drop(v82_18);
  let mut v82_20 = Space::new();
  let mut v82_20_write = v82_20.write_zipper();
  let mut v82_20_cursor = (*s0).read_zipper();
  let v82_20_origin = v82_20_cursor.path().len();
  for v82_20_byte in v82_20_cursor.child_mask().iter() {
    v82_20_cursor.descend_to_existing_byte(v82_20_byte);
    {
    let v83_4: Space = if (&(v82_13)).is_empty() { Space::new() } else {
      let v84_2: Path = concat_path(&(*p1),&v82_20_cursor.path()[v82_20_origin..(v82_20_origin + 1)]);
      let mut v84_3 = Space::new();
      let mut v84_3_write = v84_3.write_zipper();
      let v84_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v84_3_arg_1: &[u8] = &(v84_2);
      let v84_3_arg_2: &[u8] = &(*p2);
      let v84_3_arg_3: &[u8] = &(*p3);
      let v84_3_arg_4: &[u8] = &(*p4);
      let v84_3_arg_5: &[u8] = &(*p5);
      let v84_3_arg_6: &[u8] = &(*p6);
      let v84_3_arg_8: &Space = &(&v82_20_cursor).make_map();
      let mut v84_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v84_3_origin = v84_3_cursor.path().len();
      let mut v84_3_more = v84_3_cursor.is_val() || next_value_within(&mut v84_3_cursor,v84_3_origin);
      while v84_3_more {
        {
        let v84_3_depth = v84_3_cursor.path().len();
        let v85_9: Space = routine_12(c, &v84_3_cursor.path()[v84_3_origin..v84_3_depth], &(*v84_3_arg_1), &(*v84_3_arg_2), &(*v84_3_arg_3), &(*v84_3_arg_4), &(*v84_3_arg_5), &(*v84_3_arg_6), &((*v84_3_arg_8).read_zipper()));
        join_wrapped_into(&mut v84_3_write,&((v85_9).read_zipper()),&[]);
        }
        v84_3_more = next_value_within(&mut v84_3_cursor,v84_3_origin);
      }
      drop(v84_3_cursor);
      drop(v84_3_write);
      map_map_kernels::compose(&(v82_13),&(v84_3))
    };
    let v83_6: Space = if (&(v82_19)).is_empty() { Space::new() } else {
      let v86_2: Path = concat_path(&(*p1),&v82_20_cursor.path()[v82_20_origin..(v82_20_origin + 1)]);
      let mut v86_5 = Space::new();
      let mut v86_5_write = v86_5.write_zipper();
      for v86_5_byte in v82_20_cursor.child_mask().iter() {
        v82_20_cursor.descend_to_existing_byte(v86_5_byte);
        {
        let v87_2: Space = routine_13(c, &v82_20_cursor.path()[(v82_20_origin + 1)..(v82_20_origin + 2)], &v82_20_cursor.path()[(v82_20_origin + 1)..(v82_20_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v86_2), &v82_20_cursor);
        join_wrapped_into(&mut v86_5_write,&((v87_2).read_zipper()),&[]);
        }
        v82_20_cursor.ascend(1);
      }
      drop(v86_5_write);
      drop(v86_2);
      map_map_kernels::compose(&(v82_19),&(v86_5))
    };
    let v83_7: Space = map_map_kernels::unite(&(v83_4),&(v83_6));
    join_wrapped_into(&mut v82_20_write,&((v83_7).read_zipper()),&[]);
    }
    v82_20_cursor.ascend(1);
  }
  drop(v82_20_cursor);
  drop(v82_20_write);
  drop(v82_13);
  drop(v82_19);
  (v82_20).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v88_11: Space = singleton(&(*p1));
  let v88_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v88_11));
  let v88_13: Space = if map_kernels::has_head(&(v88_12)) { singleton(&[]) } else { Space::new() };
  drop(v88_12);
  let v88_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v88_13));
  drop(v88_13);
  let v88_25: Space = if (&(v88_14)).is_empty() { Space::new() } else {
    let v89_17: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v89_20: Space = if (&(v89_17)).is_empty() { Space::new() } else {
      let v90_19: Space = routine_14(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*s0));
      map_map_kernels::compose(&(v89_17),&(v90_19))
    };
    drop(v89_17);
    let mut v89_23 = Space::new();
    let mut v89_23_write = v89_23.write_zipper();
    let mut v89_23_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v89_23_origin = v89_23_cursor.path().len();
    for v89_23_byte in v89_23_cursor.child_mask().iter() {
      v89_23_cursor.descend_to_existing_byte(v89_23_byte);
      {
      let v91_2_arg_0: &[u8] = &v89_23_cursor.path()[v89_23_origin..(v89_23_origin + 1)];
      let v91_2_arg_1: &[u8] = &(*p0);
      let v91_2_arg_2: &[u8] = &(*p2);
      let v91_2_arg_3: &[u8] = &(*p3);
      let v91_2_arg_4: &[u8] = &(*p4);
      let v91_2_arg_5: &[u8] = &(*p5);
      let v91_2_arg_6: &[u8] = &(*p6);
      let v91_2_arg_7: &[u8] = &(*p7);
      let v91_2_arg_9: &Space = &(&(*s0)).make_map();
      let mut v91_2_more = v89_23_cursor.is_val() || next_value_within(&mut v89_23_cursor,(v89_23_origin + 1));
      while v91_2_more {
        {
        let v91_2_depth = v89_23_cursor.path().len();
        let mut v92_10_cursor = (*v91_2_arg_9).read_zipper();
        let v92_10_origin = v92_10_cursor.path().len();
        for v92_10_byte in v92_10_cursor.child_mask().iter() {
          v92_10_cursor.descend_to_existing_byte(v92_10_byte);
          {
          let v93_2: Path = concat_path(&(*v91_2_arg_1),&v92_10_cursor.path()[v92_10_origin..(v92_10_origin + 1)]);
          let v93_3: Space = routine_13(c, &(v93_2), &v89_23_cursor.path()[v89_23_origin..v91_2_depth], &(*v91_2_arg_2), &(*v91_2_arg_3), &(*v91_2_arg_4), &(*v91_2_arg_5), &(*v91_2_arg_6), &(*v91_2_arg_7), &v92_10_cursor);
          drop(v93_2);
          join_wrapped_into(&mut v89_23_write,&((v93_3).read_zipper()),&[]);
          }
          v92_10_cursor.ascend(1);
        }
        drop(v92_10_cursor);
        }
        v91_2_more = next_value_within(&mut v89_23_cursor,(v89_23_origin + 1));
      }
      }
      v89_23_cursor.ascend(1);
    }
    drop(v89_23_cursor);
    drop(v89_23_write);
    let v89_24: Space = map_map_kernels::unite(&(v89_20),&(v89_23));
    map_map_kernels::compose(&(v88_14),&(v89_24))
  };
  drop(v88_14);
  let v88_27: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v88_11));
  drop(v88_11);
  let v88_28: Space = if map_kernels::has_head(&(v88_27)) { singleton(&[]) } else { Space::new() };
  drop(v88_27);
  let v88_30: Space = if (&(v88_28)).is_empty() { Space::new() } else {
    let mut v94_29 = Space::new();
    let mut v94_29_write = v94_29.write_zipper();
    let mut v94_29_cursor = (*s0).read_zipper();
    let v94_29_origin = v94_29_cursor.path().len();
    for v94_29_byte in v94_29_cursor.child_mask().iter() {
      v94_29_cursor.descend_to_existing_byte(v94_29_byte);
      {
      let v95_2: Space = routine_15(c, &v94_29_cursor.path()[v94_29_origin..(v94_29_origin + 1)], &v94_29_cursor.path()[v94_29_origin..(v94_29_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p0), &v94_29_cursor);
      join_wrapped_into(&mut v94_29_write,&((v95_2).read_zipper()),&[]);
      }
      v94_29_cursor.ascend(1);
    }
    drop(v94_29_cursor);
    drop(v94_29_write);
    map_map_kernels::compose(&(v88_28),&(v94_29))
  };
  drop(v88_28);
  let v88_31: Space = map_map_kernels::unite(&(v88_25),&(v88_30));
  (v88_31).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v96_11: Space = singleton(&(*p0));
  let v96_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v96_11));
  let v96_13: Space = if map_kernels::has_head(&(v96_12)) { singleton(&[]) } else { Space::new() };
  drop(v96_12);
  let v96_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v96_13));
  drop(v96_13);
  let v96_19: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v96_11));
  drop(v96_11);
  let v96_20: Space = if map_kernels::has_head(&(v96_19)) { singleton(&[]) } else { Space::new() };
  drop(v96_19);
  let mut v96_21 = Space::new();
  let mut v96_21_write = v96_21.write_zipper();
  let mut v96_21_cursor = (*s0).read_zipper();
  let v96_21_origin = v96_21_cursor.path().len();
  for v96_21_byte in v96_21_cursor.child_mask().iter() {
    v96_21_cursor.descend_to_existing_byte(v96_21_byte);
    {
    let v97_4: Space = if (&(v96_14)).is_empty() { Space::new() } else {
      let v98_2: Path = concat_path(&(*p1),&v96_21_cursor.path()[v96_21_origin..(v96_21_origin + 1)]);
      let mut v98_3 = Space::new();
      let mut v98_3_write = v98_3.write_zipper();
      let v98_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v98_3_arg_1: &[u8] = &(v98_2);
      let v98_3_arg_2: &[u8] = &(*p2);
      let v98_3_arg_3: &[u8] = &(*p3);
      let v98_3_arg_4: &[u8] = &(*p4);
      let v98_3_arg_5: &[u8] = &(*p5);
      let v98_3_arg_6: &[u8] = &(*p6);
      let v98_3_arg_7: &[u8] = &(*p7);
      let v98_3_arg_9: &Space = &(&v96_21_cursor).make_map();
      let mut v98_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v98_3_origin = v98_3_cursor.path().len();
      let mut v98_3_more = v98_3_cursor.is_val() || next_value_within(&mut v98_3_cursor,v98_3_origin);
      while v98_3_more {
        {
        let v98_3_depth = v98_3_cursor.path().len();
        let v99_10: Space = routine_14(c, &v98_3_cursor.path()[v98_3_origin..v98_3_depth], &(*v98_3_arg_1), &(*v98_3_arg_2), &(*v98_3_arg_3), &(*v98_3_arg_4), &(*v98_3_arg_5), &(*v98_3_arg_6), &(*v98_3_arg_7), &((*v98_3_arg_9).read_zipper()));
        join_wrapped_into(&mut v98_3_write,&((v99_10).read_zipper()),&[]);
        }
        v98_3_more = next_value_within(&mut v98_3_cursor,v98_3_origin);
      }
      drop(v98_3_cursor);
      drop(v98_3_write);
      map_map_kernels::compose(&(v96_14),&(v98_3))
    };
    let v97_6: Space = if (&(v96_20)).is_empty() { Space::new() } else {
      let v100_2: Path = concat_path(&(*p1),&v96_21_cursor.path()[v96_21_origin..(v96_21_origin + 1)]);
      let mut v100_5 = Space::new();
      let mut v100_5_write = v100_5.write_zipper();
      for v100_5_byte in v96_21_cursor.child_mask().iter() {
        v96_21_cursor.descend_to_existing_byte(v100_5_byte);
        {
        let v101_2: Space = routine_15(c, &v96_21_cursor.path()[(v96_21_origin + 1)..(v96_21_origin + 2)], &v96_21_cursor.path()[(v96_21_origin + 1)..(v96_21_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v100_2), &v96_21_cursor);
        join_wrapped_into(&mut v100_5_write,&((v101_2).read_zipper()),&[]);
        }
        v96_21_cursor.ascend(1);
      }
      drop(v100_5_write);
      drop(v100_2);
      map_map_kernels::compose(&(v96_20),&(v100_5))
    };
    let v97_7: Space = map_map_kernels::unite(&(v97_4),&(v97_6));
    join_wrapped_into(&mut v96_21_write,&((v97_7).read_zipper()),&[]);
    }
    v96_21_cursor.ascend(1);
  }
  drop(v96_21_cursor);
  drop(v96_21_write);
  drop(v96_14);
  drop(v96_20);
  (v96_21).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v102_12: Space = singleton(&(*p1));
  let v102_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v102_12));
  let v102_14: Space = if map_kernels::has_head(&(v102_13)) { singleton(&[]) } else { Space::new() };
  drop(v102_13);
  let v102_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v102_14));
  drop(v102_14);
  let v102_26: Space = if (&(v102_15)).is_empty() { Space::new() } else {
    let v103_18: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v103_21: Space = if (&(v103_18)).is_empty() { Space::new() } else {
      let v104_20: Space = routine_16(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*s0));
      map_map_kernels::compose(&(v103_18),&(v104_20))
    };
    drop(v103_18);
    let mut v103_24 = Space::new();
    let mut v103_24_write = v103_24.write_zipper();
    let mut v103_24_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v103_24_origin = v103_24_cursor.path().len();
    for v103_24_byte in v103_24_cursor.child_mask().iter() {
      v103_24_cursor.descend_to_existing_byte(v103_24_byte);
      {
      let v105_2_arg_0: &[u8] = &v103_24_cursor.path()[v103_24_origin..(v103_24_origin + 1)];
      let v105_2_arg_1: &[u8] = &(*p0);
      let v105_2_arg_2: &[u8] = &(*p2);
      let v105_2_arg_3: &[u8] = &(*p3);
      let v105_2_arg_4: &[u8] = &(*p4);
      let v105_2_arg_5: &[u8] = &(*p5);
      let v105_2_arg_6: &[u8] = &(*p6);
      let v105_2_arg_7: &[u8] = &(*p7);
      let v105_2_arg_8: &[u8] = &(*p8);
      let v105_2_arg_10: &Space = &(&(*s0)).make_map();
      let mut v105_2_more = v103_24_cursor.is_val() || next_value_within(&mut v103_24_cursor,(v103_24_origin + 1));
      while v105_2_more {
        {
        let v105_2_depth = v103_24_cursor.path().len();
        let mut v106_11_cursor = (*v105_2_arg_10).read_zipper();
        let v106_11_origin = v106_11_cursor.path().len();
        for v106_11_byte in v106_11_cursor.child_mask().iter() {
          v106_11_cursor.descend_to_existing_byte(v106_11_byte);
          {
          let v107_2: Path = concat_path(&(*v105_2_arg_1),&v106_11_cursor.path()[v106_11_origin..(v106_11_origin + 1)]);
          let v107_3: Space = routine_15(c, &(v107_2), &v103_24_cursor.path()[v103_24_origin..v105_2_depth], &(*v105_2_arg_2), &(*v105_2_arg_3), &(*v105_2_arg_4), &(*v105_2_arg_5), &(*v105_2_arg_6), &(*v105_2_arg_7), &(*v105_2_arg_8), &v106_11_cursor);
          drop(v107_2);
          join_wrapped_into(&mut v103_24_write,&((v107_3).read_zipper()),&[]);
          }
          v106_11_cursor.ascend(1);
        }
        drop(v106_11_cursor);
        }
        v105_2_more = next_value_within(&mut v103_24_cursor,(v103_24_origin + 1));
      }
      }
      v103_24_cursor.ascend(1);
    }
    drop(v103_24_cursor);
    drop(v103_24_write);
    let v103_25: Space = map_map_kernels::unite(&(v103_21),&(v103_24));
    map_map_kernels::compose(&(v102_15),&(v103_25))
  };
  drop(v102_15);
  let v102_28: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v102_12));
  drop(v102_12);
  let v102_29: Space = if map_kernels::has_head(&(v102_28)) { singleton(&[]) } else { Space::new() };
  drop(v102_28);
  let v102_31: Space = if (&(v102_29)).is_empty() { Space::new() } else {
    let mut v108_30 = Space::new();
    let mut v108_30_write = v108_30.write_zipper();
    let mut v108_30_cursor = (*s0).read_zipper();
    let v108_30_origin = v108_30_cursor.path().len();
    for v108_30_byte in v108_30_cursor.child_mask().iter() {
      v108_30_cursor.descend_to_existing_byte(v108_30_byte);
      {
      let v109_2: Space = routine_17(c, &v108_30_cursor.path()[v108_30_origin..(v108_30_origin + 1)], &v108_30_cursor.path()[v108_30_origin..(v108_30_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &v108_30_cursor);
      join_wrapped_into(&mut v108_30_write,&((v109_2).read_zipper()),&[]);
      }
      v108_30_cursor.ascend(1);
    }
    drop(v108_30_cursor);
    drop(v108_30_write);
    map_map_kernels::compose(&(v102_29),&(v108_30))
  };
  drop(v102_29);
  let v102_32: Space = map_map_kernels::unite(&(v102_26),&(v102_31));
  (v102_32).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v110_12: Space = singleton(&(*p0));
  let v110_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v110_12));
  let v110_14: Space = if map_kernels::has_head(&(v110_13)) { singleton(&[]) } else { Space::new() };
  drop(v110_13);
  let v110_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v110_14));
  drop(v110_14);
  let v110_20: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v110_12));
  drop(v110_12);
  let v110_21: Space = if map_kernels::has_head(&(v110_20)) { singleton(&[]) } else { Space::new() };
  drop(v110_20);
  let mut v110_22 = Space::new();
  let mut v110_22_write = v110_22.write_zipper();
  let mut v110_22_cursor = (*s0).read_zipper();
  let v110_22_origin = v110_22_cursor.path().len();
  for v110_22_byte in v110_22_cursor.child_mask().iter() {
    v110_22_cursor.descend_to_existing_byte(v110_22_byte);
    {
    let v111_4: Space = if (&(v110_15)).is_empty() { Space::new() } else {
      let v112_2: Path = concat_path(&(*p1),&v110_22_cursor.path()[v110_22_origin..(v110_22_origin + 1)]);
      let mut v112_3 = Space::new();
      let mut v112_3_write = v112_3.write_zipper();
      let v112_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v112_3_arg_1: &[u8] = &(v112_2);
      let v112_3_arg_2: &[u8] = &(*p2);
      let v112_3_arg_3: &[u8] = &(*p3);
      let v112_3_arg_4: &[u8] = &(*p4);
      let v112_3_arg_5: &[u8] = &(*p5);
      let v112_3_arg_6: &[u8] = &(*p6);
      let v112_3_arg_7: &[u8] = &(*p7);
      let v112_3_arg_8: &[u8] = &(*p8);
      let v112_3_arg_10: &Space = &(&v110_22_cursor).make_map();
      let mut v112_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v112_3_origin = v112_3_cursor.path().len();
      let mut v112_3_more = v112_3_cursor.is_val() || next_value_within(&mut v112_3_cursor,v112_3_origin);
      while v112_3_more {
        {
        let v112_3_depth = v112_3_cursor.path().len();
        let v113_11: Space = routine_16(c, &v112_3_cursor.path()[v112_3_origin..v112_3_depth], &(*v112_3_arg_1), &(*v112_3_arg_2), &(*v112_3_arg_3), &(*v112_3_arg_4), &(*v112_3_arg_5), &(*v112_3_arg_6), &(*v112_3_arg_7), &(*v112_3_arg_8), &((*v112_3_arg_10).read_zipper()));
        join_wrapped_into(&mut v112_3_write,&((v113_11).read_zipper()),&[]);
        }
        v112_3_more = next_value_within(&mut v112_3_cursor,v112_3_origin);
      }
      drop(v112_3_cursor);
      drop(v112_3_write);
      map_map_kernels::compose(&(v110_15),&(v112_3))
    };
    let v111_6: Space = if (&(v110_21)).is_empty() { Space::new() } else {
      let v114_2: Path = concat_path(&(*p1),&v110_22_cursor.path()[v110_22_origin..(v110_22_origin + 1)]);
      let mut v114_5 = Space::new();
      let mut v114_5_write = v114_5.write_zipper();
      for v114_5_byte in v110_22_cursor.child_mask().iter() {
        v110_22_cursor.descend_to_existing_byte(v114_5_byte);
        {
        let v115_2: Space = routine_17(c, &v110_22_cursor.path()[(v110_22_origin + 1)..(v110_22_origin + 2)], &v110_22_cursor.path()[(v110_22_origin + 1)..(v110_22_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(v114_2), &v110_22_cursor);
        join_wrapped_into(&mut v114_5_write,&((v115_2).read_zipper()),&[]);
        }
        v110_22_cursor.ascend(1);
      }
      drop(v114_5_write);
      drop(v114_2);
      map_map_kernels::compose(&(v110_21),&(v114_5))
    };
    let v111_7: Space = map_map_kernels::unite(&(v111_4),&(v111_6));
    join_wrapped_into(&mut v110_22_write,&((v111_7).read_zipper()),&[]);
    }
    v110_22_cursor.ascend(1);
  }
  drop(v110_22_cursor);
  drop(v110_22_write);
  drop(v110_15);
  drop(v110_21);
  (v110_22).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], s0: &View<'_, '_>) -> Space {
  let v116_13: Space = singleton(&(*p1));
  let v116_14: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v116_13));
  let v116_15: Space = if map_kernels::has_head(&(v116_14)) { singleton(&[]) } else { Space::new() };
  drop(v116_14);
  let v116_16: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v116_15));
  drop(v116_15);
  let v116_27: Space = if (&(v116_16)).is_empty() { Space::new() } else {
    let v117_19: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v117_22: Space = if (&(v117_19)).is_empty() { Space::new() } else {
      let v118_21: Space = routine_18(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*s0));
      map_map_kernels::compose(&(v117_19),&(v118_21))
    };
    drop(v117_19);
    let mut v117_25 = Space::new();
    let mut v117_25_write = v117_25.write_zipper();
    let mut v117_25_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v117_25_origin = v117_25_cursor.path().len();
    for v117_25_byte in v117_25_cursor.child_mask().iter() {
      v117_25_cursor.descend_to_existing_byte(v117_25_byte);
      {
      let v119_2_arg_0: &[u8] = &v117_25_cursor.path()[v117_25_origin..(v117_25_origin + 1)];
      let v119_2_arg_1: &[u8] = &(*p0);
      let v119_2_arg_2: &[u8] = &(*p2);
      let v119_2_arg_3: &[u8] = &(*p3);
      let v119_2_arg_4: &[u8] = &(*p4);
      let v119_2_arg_5: &[u8] = &(*p5);
      let v119_2_arg_6: &[u8] = &(*p6);
      let v119_2_arg_7: &[u8] = &(*p7);
      let v119_2_arg_8: &[u8] = &(*p8);
      let v119_2_arg_9: &[u8] = &(*p9);
      let v119_2_arg_11: &Space = &(&(*s0)).make_map();
      let mut v119_2_more = v117_25_cursor.is_val() || next_value_within(&mut v117_25_cursor,(v117_25_origin + 1));
      while v119_2_more {
        {
        let v119_2_depth = v117_25_cursor.path().len();
        let mut v120_12_cursor = (*v119_2_arg_11).read_zipper();
        let v120_12_origin = v120_12_cursor.path().len();
        for v120_12_byte in v120_12_cursor.child_mask().iter() {
          v120_12_cursor.descend_to_existing_byte(v120_12_byte);
          {
          let v121_2: Path = concat_path(&(*v119_2_arg_1),&v120_12_cursor.path()[v120_12_origin..(v120_12_origin + 1)]);
          let v121_3: Space = routine_17(c, &(v121_2), &v117_25_cursor.path()[v117_25_origin..v119_2_depth], &(*v119_2_arg_2), &(*v119_2_arg_3), &(*v119_2_arg_4), &(*v119_2_arg_5), &(*v119_2_arg_6), &(*v119_2_arg_7), &(*v119_2_arg_8), &(*v119_2_arg_9), &v120_12_cursor);
          drop(v121_2);
          join_wrapped_into(&mut v117_25_write,&((v121_3).read_zipper()),&[]);
          }
          v120_12_cursor.ascend(1);
        }
        drop(v120_12_cursor);
        }
        v119_2_more = next_value_within(&mut v117_25_cursor,(v117_25_origin + 1));
      }
      }
      v117_25_cursor.ascend(1);
    }
    drop(v117_25_cursor);
    drop(v117_25_write);
    let v117_26: Space = map_map_kernels::unite(&(v117_22),&(v117_25));
    map_map_kernels::compose(&(v116_16),&(v117_26))
  };
  drop(v116_16);
  let v116_29: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v116_13));
  drop(v116_13);
  let v116_30: Space = if map_kernels::has_head(&(v116_29)) { singleton(&[]) } else { Space::new() };
  drop(v116_29);
  let v116_42: Space = if (&(v116_30)).is_empty() { Space::new() } else {
    let v122_31: Path = concat_path(&(*p3),&(*p4));
    let v122_32: Path = concat_path(&(v122_31),&(*p5));
    drop(v122_31);
    let v122_33: Path = concat_path(&(v122_32),&(*p6));
    drop(v122_32);
    let v122_34: Path = concat_path(&(v122_33),&(*p7));
    drop(v122_33);
    let v122_35: Path = concat_path(&(v122_34),&(*p8));
    drop(v122_34);
    let v122_36: Path = concat_path(&(v122_35),&(*p9));
    drop(v122_35);
    let v122_37: Path = concat_path(&(v122_36),&(*p0));
    drop(v122_36);
    let v122_38: Space = singleton(&(v122_37));
    drop(v122_37);
    let v122_39: Space = routine_19(c, &(*p2), &((v122_38).read_zipper()));
    drop(v122_38);
    let mut v122_40 = Space::new();
    let mut v122_40_write = v122_40.write_zipper();
    let mut v122_40_cursor = (v122_39).read_zipper();
    let v122_40_origin = v122_40_cursor.path().len();
    for v122_40_byte in v122_40_cursor.child_mask().iter() {
      v122_40_cursor.descend_to_existing_byte(v122_40_byte);
      {
      let v123_2: Space = routine_20(c, &v122_40_cursor.path()[v122_40_origin..(v122_40_origin + 1)], &v122_40_cursor.path()[v122_40_origin..(v122_40_origin + 1)], &(*p2), &v122_40_cursor);
      join_wrapped_into(&mut v122_40_write,&((v123_2).read_zipper()),&[]);
      }
      v122_40_cursor.ascend(1);
    }
    drop(v122_40_cursor);
    drop(v122_40_write);
    let mut v122_41 = Space::new();
    let mut v122_41_write = v122_41.write_zipper();
    let mut v122_41_cursor = (v122_40).read_zipper();
    let v122_41_origin = v122_41_cursor.path().len();
    for v122_41_byte in v122_41_cursor.child_mask().iter() {
      v122_41_cursor.descend_to_existing_byte(v122_41_byte);
      {
      let v124_2: Space = routine_21(c, &v122_41_cursor.path()[v122_41_origin..(v122_41_origin + 1)], &v122_41_cursor.path()[v122_41_origin..(v122_41_origin + 1)], &(*p2), &v122_41_cursor);
      join_wrapped_into(&mut v122_41_write,&((v124_2).read_zipper()),&[]);
      }
      v122_41_cursor.ascend(1);
    }
    drop(v122_41_cursor);
    drop(v122_41_write);
    map_map_kernels::compose(&(v116_30),&(v122_41))
  };
  drop(v116_30);
  let v116_43: Space = map_map_kernels::unite(&(v116_27),&(v116_42));
  (v116_43).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], p9: &[u8], s0: &View<'_, '_>) -> Space {
  let v125_13: Space = singleton(&(*p0));
  let v125_14: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v125_13));
  let v125_15: Space = if map_kernels::has_head(&(v125_14)) { singleton(&[]) } else { Space::new() };
  drop(v125_14);
  let v125_16: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v125_15));
  drop(v125_15);
  let v125_21: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v125_13));
  drop(v125_13);
  let v125_22: Space = if map_kernels::has_head(&(v125_21)) { singleton(&[]) } else { Space::new() };
  drop(v125_21);
  let v125_23: Path = concat_path(&(*p3),&(*p4));
  let v125_24: Path = concat_path(&(v125_23),&(*p5));
  drop(v125_23);
  let v125_25: Path = concat_path(&(v125_24),&(*p6));
  drop(v125_24);
  let v125_26: Path = concat_path(&(v125_25),&(*p7));
  drop(v125_25);
  let v125_27: Path = concat_path(&(v125_26),&(*p8));
  drop(v125_26);
  let v125_28: Path = concat_path(&(v125_27),&(*p9));
  drop(v125_27);
  let mut v125_29 = Space::new();
  let mut v125_29_write = v125_29.write_zipper();
  let mut v125_29_cursor = (*s0).read_zipper();
  let v125_29_origin = v125_29_cursor.path().len();
  for v125_29_byte in v125_29_cursor.child_mask().iter() {
    v125_29_cursor.descend_to_existing_byte(v125_29_byte);
    {
    let v126_4: Space = if (&(v125_16)).is_empty() { Space::new() } else {
      let v127_2: Path = concat_path(&(*p1),&v125_29_cursor.path()[v125_29_origin..(v125_29_origin + 1)]);
      let mut v127_3 = Space::new();
      let mut v127_3_write = v127_3.write_zipper();
      let v127_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v127_3_arg_1: &[u8] = &(v127_2);
      let v127_3_arg_2: &[u8] = &(*p2);
      let v127_3_arg_3: &[u8] = &(*p3);
      let v127_3_arg_4: &[u8] = &(*p4);
      let v127_3_arg_5: &[u8] = &(*p5);
      let v127_3_arg_6: &[u8] = &(*p6);
      let v127_3_arg_7: &[u8] = &(*p7);
      let v127_3_arg_8: &[u8] = &(*p8);
      let v127_3_arg_9: &[u8] = &(*p9);
      let v127_3_arg_11: &Space = &(&v125_29_cursor).make_map();
      let mut v127_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v127_3_origin = v127_3_cursor.path().len();
      let mut v127_3_more = v127_3_cursor.is_val() || next_value_within(&mut v127_3_cursor,v127_3_origin);
      while v127_3_more {
        {
        let v127_3_depth = v127_3_cursor.path().len();
        let v128_12: Space = routine_18(c, &v127_3_cursor.path()[v127_3_origin..v127_3_depth], &(*v127_3_arg_1), &(*v127_3_arg_2), &(*v127_3_arg_3), &(*v127_3_arg_4), &(*v127_3_arg_5), &(*v127_3_arg_6), &(*v127_3_arg_7), &(*v127_3_arg_8), &(*v127_3_arg_9), &((*v127_3_arg_11).read_zipper()));
        join_wrapped_into(&mut v127_3_write,&((v128_12).read_zipper()),&[]);
        }
        v127_3_more = next_value_within(&mut v127_3_cursor,v127_3_origin);
      }
      drop(v127_3_cursor);
      drop(v127_3_write);
      map_map_kernels::compose(&(v125_16),&(v127_3))
    };
    let v126_10: Space = if (&(v125_22)).is_empty() { Space::new() } else {
      let v129_2: Path = concat_path(&(*p1),&v125_29_cursor.path()[v125_29_origin..(v125_29_origin + 1)]);
      let v129_5: Path = concat_path(&(v125_28),&(v129_2));
      drop(v129_2);
      let v129_6: Space = singleton(&(v129_5));
      drop(v129_5);
      let v129_7: Space = routine_19(c, &(*p2), &((v129_6).read_zipper()));
      drop(v129_6);
      let mut v129_8 = Space::new();
      let mut v129_8_write = v129_8.write_zipper();
      let mut v129_8_cursor = (v129_7).read_zipper();
      let v129_8_origin = v129_8_cursor.path().len();
      for v129_8_byte in v129_8_cursor.child_mask().iter() {
        v129_8_cursor.descend_to_existing_byte(v129_8_byte);
        {
        let v130_2: Space = routine_20(c, &v129_8_cursor.path()[v129_8_origin..(v129_8_origin + 1)], &v129_8_cursor.path()[v129_8_origin..(v129_8_origin + 1)], &(*p2), &v129_8_cursor);
        join_wrapped_into(&mut v129_8_write,&((v130_2).read_zipper()),&[]);
        }
        v129_8_cursor.ascend(1);
      }
      drop(v129_8_cursor);
      drop(v129_8_write);
      let mut v129_9 = Space::new();
      let mut v129_9_write = v129_9.write_zipper();
      let mut v129_9_cursor = (v129_8).read_zipper();
      let v129_9_origin = v129_9_cursor.path().len();
      for v129_9_byte in v129_9_cursor.child_mask().iter() {
        v129_9_cursor.descend_to_existing_byte(v129_9_byte);
        {
        let v131_2: Space = routine_21(c, &v129_9_cursor.path()[v129_9_origin..(v129_9_origin + 1)], &v129_9_cursor.path()[v129_9_origin..(v129_9_origin + 1)], &(*p2), &v129_9_cursor);
        join_wrapped_into(&mut v129_9_write,&((v131_2).read_zipper()),&[]);
        }
        v129_9_cursor.ascend(1);
      }
      drop(v129_9_cursor);
      drop(v129_9_write);
      map_map_kernels::compose(&(v125_22),&(v129_9))
    };
    let v126_11: Space = map_map_kernels::unite(&(v126_4),&(v126_10));
    join_wrapped_into(&mut v125_29_write,&((v126_11).read_zipper()),&[]);
    }
    v125_29_cursor.ascend(1);
  }
  drop(v125_29_cursor);
  drop(v125_29_write);
  drop(v125_16);
  drop(v125_22);
  drop(v125_28);
  (v125_29).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let (mut v132_1551,mut v132_1552,mut v132_2326,mut v132_2327,mut v132_3101,mut v132_3102,mut v132_3876,mut v132_3877,mut v132_4651,mut v132_4652,mut v132_5426,mut v132_5427,mut v132_6201,mut v132_6202,mut v132_6976,mut v132_777,) = native_block_0(c, p0, s0);
  let v132_6977: Space = map_map_kernels::unite(&(v132_6202),&(v132_6976));
  (v132_6977).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v187_6: Space = singleton(&(*p1));
  let v187_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v187_6));
  let v187_8: Space = if map_kernels::has_head(&(v187_7)) { singleton(&[]) } else { Space::new() };
  drop(v187_7);
  let v187_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v187_8));
  drop(v187_8);
  let v187_20: Space = if (&(v187_9)).is_empty() { Space::new() } else {
    let v188_12: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v188_15: Space = if (&(v188_12)).is_empty() { Space::new() } else {
      let v189_14: Space = routine_40(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      map_map_kernels::compose(&(v188_12),&(v189_14))
    };
    drop(v188_12);
    let mut v188_18 = Space::new();
    let mut v188_18_write = v188_18.write_zipper();
    let mut v188_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v188_18_origin = v188_18_cursor.path().len();
    for v188_18_byte in v188_18_cursor.child_mask().iter() {
      v188_18_cursor.descend_to_existing_byte(v188_18_byte);
      {
      let v190_2_arg_0: &[u8] = &v188_18_cursor.path()[v188_18_origin..(v188_18_origin + 1)];
      let v190_2_arg_1: &[u8] = &(*p0);
      let v190_2_arg_2: &[u8] = &(*p2);
      let v190_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v190_2_more = v188_18_cursor.is_val() || next_value_within(&mut v188_18_cursor,(v188_18_origin + 1));
      while v190_2_more {
        {
        let v190_2_depth = v188_18_cursor.path().len();
        let mut v191_5_cursor = (*v190_2_arg_4).read_zipper();
        let v191_5_origin = v191_5_cursor.path().len();
        for v191_5_byte in v191_5_cursor.child_mask().iter() {
          v191_5_cursor.descend_to_existing_byte(v191_5_byte);
          {
          let v192_2: Path = concat_path(&(*v190_2_arg_1),&v191_5_cursor.path()[v191_5_origin..(v191_5_origin + 1)]);
          let v192_3: Space = routine_20(c, &(v192_2), &v188_18_cursor.path()[v188_18_origin..v190_2_depth], &(*v190_2_arg_2), &v191_5_cursor);
          drop(v192_2);
          join_wrapped_into(&mut v188_18_write,&((v192_3).read_zipper()),&[]);
          }
          v191_5_cursor.ascend(1);
        }
        drop(v191_5_cursor);
        }
        v190_2_more = next_value_within(&mut v188_18_cursor,(v188_18_origin + 1));
      }
      }
      v188_18_cursor.ascend(1);
    }
    drop(v188_18_cursor);
    drop(v188_18_write);
    let v188_19: Space = map_map_kernels::unite(&(v188_15),&(v188_18));
    map_map_kernels::compose(&(v187_9),&(v188_19))
  };
  drop(v187_9);
  let v187_22: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v187_6));
  drop(v187_6);
  let v187_23: Space = if map_kernels::has_head(&(v187_22)) { singleton(&[]) } else { Space::new() };
  drop(v187_22);
  let v187_29: Space = if (&(v187_23)).is_empty() { Space::new() } else {
    let v193_26: Space = routine_41(c, &(*CONSTANT_2), &(*CONSTANT_2), &((*CONSTANT_16).read_zipper()));
    let mut v193_28 = Space::new();
    let mut v193_28_write = v193_28.write_zipper();
    let mut v193_28_cursor = descend_cursor((v193_26).read_zipper(),&(*p2));
    let v193_28_origin = v193_28_cursor.path().len();
    for v193_28_byte in v193_28_cursor.child_mask().iter() {
      v193_28_cursor.descend_to_existing_byte(v193_28_byte);
      {
      let v194_2: Space = routine_42(c, &v193_28_cursor.path()[v193_28_origin..(v193_28_origin + 1)], &v193_28_cursor.path()[v193_28_origin..(v193_28_origin + 1)], &(*p0), &v193_28_cursor, &(*s0));
      join_wrapped_into(&mut v193_28_write,&((v194_2).read_zipper()),&[]);
      }
      v193_28_cursor.ascend(1);
    }
    drop(v193_28_cursor);
    drop(v193_28_write);
    map_map_kernels::compose(&(v187_23),&(v193_28))
  };
  drop(v187_23);
  let v187_30: Space = map_map_kernels::unite(&(v187_20),&(v187_29));
  (v187_30).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v195_6: Space = singleton(&(*p1));
  let v195_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v195_6));
  let v195_8: Space = if map_kernels::has_head(&(v195_7)) { singleton(&[]) } else { Space::new() };
  drop(v195_7);
  let v195_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v195_8));
  drop(v195_8);
  let v195_20: Space = if (&(v195_9)).is_empty() { Space::new() } else {
    let v196_12: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v196_15: Space = if (&(v196_12)).is_empty() { Space::new() } else {
      let v197_14: Space = routine_43(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      map_map_kernels::compose(&(v196_12),&(v197_14))
    };
    drop(v196_12);
    let mut v196_18 = Space::new();
    let mut v196_18_write = v196_18.write_zipper();
    let mut v196_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v196_18_origin = v196_18_cursor.path().len();
    for v196_18_byte in v196_18_cursor.child_mask().iter() {
      v196_18_cursor.descend_to_existing_byte(v196_18_byte);
      {
      let v198_2_arg_0: &[u8] = &v196_18_cursor.path()[v196_18_origin..(v196_18_origin + 1)];
      let v198_2_arg_1: &[u8] = &(*p0);
      let v198_2_arg_2: &[u8] = &(*p2);
      let v198_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v198_2_more = v196_18_cursor.is_val() || next_value_within(&mut v196_18_cursor,(v196_18_origin + 1));
      while v198_2_more {
        {
        let v198_2_depth = v196_18_cursor.path().len();
        let mut v199_5_cursor = (*v198_2_arg_4).read_zipper();
        let v199_5_origin = v199_5_cursor.path().len();
        for v199_5_byte in v199_5_cursor.child_mask().iter() {
          v199_5_cursor.descend_to_existing_byte(v199_5_byte);
          {
          let v200_2: Path = concat_path(&(*v198_2_arg_1),&v199_5_cursor.path()[v199_5_origin..(v199_5_origin + 1)]);
          let v200_3: Space = routine_21(c, &(v200_2), &v196_18_cursor.path()[v196_18_origin..v198_2_depth], &(*v198_2_arg_2), &v199_5_cursor);
          drop(v200_2);
          join_wrapped_into(&mut v196_18_write,&((v200_3).read_zipper()),&[]);
          }
          v199_5_cursor.ascend(1);
        }
        drop(v199_5_cursor);
        }
        v198_2_more = next_value_within(&mut v196_18_cursor,(v196_18_origin + 1));
      }
      }
      v196_18_cursor.ascend(1);
    }
    drop(v196_18_cursor);
    drop(v196_18_write);
    let v196_19: Space = map_map_kernels::unite(&(v196_15),&(v196_18));
    map_map_kernels::compose(&(v195_9),&(v196_19))
  };
  drop(v195_9);
  let v195_22: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v195_6));
  drop(v195_6);
  let v195_23: Space = if map_kernels::has_head(&(v195_22)) { singleton(&[]) } else { Space::new() };
  drop(v195_22);
  let v195_31: Space = if (&(v195_23)).is_empty() { Space::new() } else {
    let v201_26: Space = routine_44(c, &(*CONSTANT_2), &(*CONSTANT_2), &((*CONSTANT_16).read_zipper()));
    let mut v201_30 = Space::new();
    let mut v201_30_write = v201_30.write_zipper();
    let mut v201_30_cursor = descend_cursor(descend_cursor(descend_cursor((v201_26).read_zipper(),&(*p2)),&(*p0)),&(*p2));
    let v201_30_origin = v201_30_cursor.path().len();
    for v201_30_byte in v201_30_cursor.child_mask().iter() {
      v201_30_cursor.descend_to_existing_byte(v201_30_byte);
      {
      let v202_2: Space = routine_45(c, &v201_30_cursor.path()[v201_30_origin..(v201_30_origin + 1)], &v201_30_cursor.path()[v201_30_origin..(v201_30_origin + 1)], &v201_30_cursor, &(*s0));
      join_wrapped_into(&mut v201_30_write,&((v202_2).read_zipper()),&[]);
      }
      v201_30_cursor.ascend(1);
    }
    drop(v201_30_cursor);
    drop(v201_30_write);
    map_map_kernels::compose(&(v195_23),&(v201_30))
  };
  drop(v195_23);
  let v195_32: Space = map_map_kernels::unite(&(v195_20),&(v195_31));
  (v195_32).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v203_5: Space = singleton(&(*p1));
  let v203_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v203_5));
  let v203_7: Space = if map_kernels::has_head(&(v203_6)) { singleton(&[]) } else { Space::new() };
  drop(v203_6);
  let v203_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v203_7));
  drop(v203_7);
  let v203_19: Space = if (&(v203_8)).is_empty() { Space::new() } else {
    let v204_11: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v204_14: Space = if (&(v204_11)).is_empty() { Space::new() } else {
      let v205_13: Space = routine_46(c, &(*CONSTANT_1), &(*p0), &(*s0));
      map_map_kernels::compose(&(v204_11),&(v205_13))
    };
    drop(v204_11);
    let mut v204_17 = Space::new();
    let mut v204_17_write = v204_17.write_zipper();
    let mut v204_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v204_17_origin = v204_17_cursor.path().len();
    for v204_17_byte in v204_17_cursor.child_mask().iter() {
      v204_17_cursor.descend_to_existing_byte(v204_17_byte);
      {
      let v206_2_arg_0: &[u8] = &v204_17_cursor.path()[v204_17_origin..(v204_17_origin + 1)];
      let v206_2_arg_1: &[u8] = &(*p0);
      let v206_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v206_2_more = v204_17_cursor.is_val() || next_value_within(&mut v204_17_cursor,(v204_17_origin + 1));
      while v206_2_more {
        {
        let v206_2_depth = v204_17_cursor.path().len();
        let mut v207_4_cursor = (*v206_2_arg_3).read_zipper();
        let v207_4_origin = v207_4_cursor.path().len();
        for v207_4_byte in v207_4_cursor.child_mask().iter() {
          v207_4_cursor.descend_to_existing_byte(v207_4_byte);
          {
          let v208_2: Path = concat_path(&(*v206_2_arg_1),&v207_4_cursor.path()[v207_4_origin..(v207_4_origin + 1)]);
          let v208_3: Space = routine_22(c, &(v208_2), &v204_17_cursor.path()[v204_17_origin..v206_2_depth], &v207_4_cursor);
          drop(v208_2);
          join_wrapped_into(&mut v204_17_write,&((v208_3).read_zipper()),&[]);
          }
          v207_4_cursor.ascend(1);
        }
        drop(v207_4_cursor);
        }
        v206_2_more = next_value_within(&mut v204_17_cursor,(v204_17_origin + 1));
      }
      }
      v204_17_cursor.ascend(1);
    }
    drop(v204_17_cursor);
    drop(v204_17_write);
    let v204_18: Space = map_map_kernels::unite(&(v204_14),&(v204_17));
    map_map_kernels::compose(&(v203_8),&(v204_18))
  };
  drop(v203_8);
  let v203_21: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v203_5));
  drop(v203_5);
  let v203_22: Space = if map_kernels::has_head(&(v203_21)) { singleton(&[]) } else { Space::new() };
  drop(v203_21);
  let v203_24: Space = if (&(v203_22)).is_empty() { Space::new() } else {
    let mut v209_23 = Space::new();
    let mut v209_23_write = v209_23.write_zipper();
    let mut v209_23_cursor = (*s0).read_zipper();
    let v209_23_origin = v209_23_cursor.path().len();
    for v209_23_byte in v209_23_cursor.child_mask().iter() {
      v209_23_cursor.descend_to_existing_byte(v209_23_byte);
      {
      let v210_2: Space = routine_47(c, &v209_23_cursor.path()[v209_23_origin..(v209_23_origin + 1)], &v209_23_cursor.path()[v209_23_origin..(v209_23_origin + 1)], &(*p0), &v209_23_cursor);
      join_wrapped_into(&mut v209_23_write,&((v210_2).read_zipper()),&[]);
      }
      v209_23_cursor.ascend(1);
    }
    drop(v209_23_cursor);
    drop(v209_23_write);
    map_map_kernels::compose(&(v203_22),&(v209_23))
  };
  drop(v203_22);
  let v203_25: Space = map_map_kernels::unite(&(v203_19),&(v203_24));
  (v203_25).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v211_7 = Space::new();
  let mut v211_7_write = v211_7.write_zipper();
  let mut v211_7_cursor = (*s0).read_zipper();
  let v211_7_origin = v211_7_cursor.path().len();
  for v211_7_byte in v211_7_cursor.child_mask().iter() {
    v211_7_cursor.descend_to_existing_byte(v211_7_byte);
    {
    let v212_2: Space = singleton(&v211_7_cursor.path()[v211_7_origin..(v211_7_origin + 1)]);
    let v212_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v212_2));
    let v212_4: Space = if map_kernels::has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
    drop(v212_3);
    let v212_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v212_4));
    drop(v212_4);
    let v212_8: Space = if (&(v212_5)).is_empty() { Space::new() } else {
      let mut v213_7 = Space::new();
      let mut v213_7_write = v213_7.write_zipper();
      let v213_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v213_7_arg_1: &[u8] = &v211_7_cursor.path()[v211_7_origin..(v211_7_origin + 1)];
      let v213_7_arg_2: &[u8] = &(*p0);
      let v213_7_arg_4: &Space = &(&v211_7_cursor).make_map();
      let mut v213_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v211_7_cursor.path()[v211_7_origin..(v211_7_origin + 1)]);
      let v213_7_origin = v213_7_cursor.path().len();
      let mut v213_7_more = v213_7_cursor.is_val() || next_value_within(&mut v213_7_cursor,v213_7_origin);
      while v213_7_more {
        {
        let v213_7_depth = v213_7_cursor.path().len();
        let mut v214_5_cursor = (*v213_7_arg_4).read_zipper();
        let v214_5_origin = v214_5_cursor.path().len();
        for v214_5_byte in v214_5_cursor.child_mask().iter() {
          v214_5_cursor.descend_to_existing_byte(v214_5_byte);
          {
          let v215_2: Path = concat_path(&(*v213_7_arg_1),&v214_5_cursor.path()[v214_5_origin..(v214_5_origin + 1)]);
          let v215_3: Space = routine_47(c, &(v215_2), &v213_7_cursor.path()[v213_7_origin..v213_7_depth], &(*v213_7_arg_2), &v214_5_cursor);
          drop(v215_2);
          join_wrapped_into(&mut v213_7_write,&((v215_3).read_zipper()),&[]);
          }
          v214_5_cursor.ascend(1);
        }
        drop(v214_5_cursor);
        }
        v213_7_more = next_value_within(&mut v213_7_cursor,v213_7_origin);
      }
      drop(v213_7_cursor);
      drop(v213_7_write);
      map_map_kernels::compose(&(v212_5),&(v213_7))
    };
    drop(v212_5);
    let v212_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v212_2));
    drop(v212_2);
    let v212_10: Space = if map_kernels::has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
    drop(v212_9);
    let v212_12: Space = if (&(v212_10)).is_empty() { Space::new() } else {
      let mut v216_11 = Space::new();
      let mut v216_11_write = v216_11.write_zipper();
      for v216_11_byte in v211_7_cursor.child_mask().iter() {
        v211_7_cursor.descend_to_existing_byte(v216_11_byte);
        {
        let v217_2: Space = routine_48(c, &v211_7_cursor.path()[(v211_7_origin + 1)..(v211_7_origin + 2)], &v211_7_cursor.path()[(v211_7_origin + 1)..(v211_7_origin + 2)], &(*p0), &v211_7_cursor.path()[v211_7_origin..(v211_7_origin + 1)], &v211_7_cursor);
        join_wrapped_into(&mut v216_11_write,&((v217_2).read_zipper()),&[]);
        }
        v211_7_cursor.ascend(1);
      }
      drop(v216_11_write);
      map_map_kernels::compose(&(v212_10),&(v216_11))
    };
    drop(v212_10);
    let v212_13: Space = map_map_kernels::unite(&(v212_8),&(v212_12));
    join_wrapped_into(&mut v211_7_write,&((v212_13).read_zipper()),&[]);
    }
    v211_7_cursor.ascend(1);
  }
  drop(v211_7_cursor);
  drop(v211_7_write);
  (v211_7).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v218_5: Space = singleton(&(*p1));
  let v218_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v218_5));
  let v218_7: Space = if map_kernels::has_head(&(v218_6)) { singleton(&[]) } else { Space::new() };
  drop(v218_6);
  let v218_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v218_7));
  drop(v218_7);
  let v218_19: Space = if (&(v218_8)).is_empty() { Space::new() } else {
    let v219_11: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v219_14: Space = if (&(v219_11)).is_empty() { Space::new() } else {
      let v220_13: Space = routine_49(c, &(*CONSTANT_1), &(*p0), &(*s0));
      map_map_kernels::compose(&(v219_11),&(v220_13))
    };
    drop(v219_11);
    let mut v219_17 = Space::new();
    let mut v219_17_write = v219_17.write_zipper();
    let mut v219_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v219_17_origin = v219_17_cursor.path().len();
    for v219_17_byte in v219_17_cursor.child_mask().iter() {
      v219_17_cursor.descend_to_existing_byte(v219_17_byte);
      {
      let v221_2_arg_0: &[u8] = &v219_17_cursor.path()[v219_17_origin..(v219_17_origin + 1)];
      let v221_2_arg_1: &[u8] = &(*p0);
      let v221_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v221_2_more = v219_17_cursor.is_val() || next_value_within(&mut v219_17_cursor,(v219_17_origin + 1));
      while v221_2_more {
        {
        let v221_2_depth = v219_17_cursor.path().len();
        let mut v222_4_cursor = (*v221_2_arg_3).read_zipper();
        let v222_4_origin = v222_4_cursor.path().len();
        for v222_4_byte in v222_4_cursor.child_mask().iter() {
          v222_4_cursor.descend_to_existing_byte(v222_4_byte);
          {
          let v223_2: Path = concat_path(&(*v221_2_arg_1),&v222_4_cursor.path()[v222_4_origin..(v222_4_origin + 1)]);
          let v223_3: Space = routine_24(c, &(v223_2), &v219_17_cursor.path()[v219_17_origin..v221_2_depth], &v222_4_cursor);
          drop(v223_2);
          join_wrapped_into(&mut v219_17_write,&((v223_3).read_zipper()),&[]);
          }
          v222_4_cursor.ascend(1);
        }
        drop(v222_4_cursor);
        }
        v221_2_more = next_value_within(&mut v219_17_cursor,(v219_17_origin + 1));
      }
      }
      v219_17_cursor.ascend(1);
    }
    drop(v219_17_cursor);
    drop(v219_17_write);
    let v219_18: Space = map_map_kernels::unite(&(v219_14),&(v219_17));
    map_map_kernels::compose(&(v218_8),&(v219_18))
  };
  drop(v218_8);
  let v218_21: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v218_5));
  drop(v218_5);
  let v218_22: Space = if map_kernels::has_head(&(v218_21)) { singleton(&[]) } else { Space::new() };
  drop(v218_21);
  let v218_24: Space = if (&(v218_22)).is_empty() { Space::new() } else {
    let mut v224_23 = Space::new();
    let mut v224_23_write = v224_23.write_zipper();
    let mut v224_23_cursor = (*s0).read_zipper();
    let v224_23_origin = v224_23_cursor.path().len();
    for v224_23_byte in v224_23_cursor.child_mask().iter() {
      v224_23_cursor.descend_to_existing_byte(v224_23_byte);
      {
      let v225_2: Space = routine_50(c, &v224_23_cursor.path()[v224_23_origin..(v224_23_origin + 1)], &v224_23_cursor.path()[v224_23_origin..(v224_23_origin + 1)], &(*p0), &v224_23_cursor);
      join_wrapped_into(&mut v224_23_write,&((v225_2).read_zipper()),&[]);
      }
      v224_23_cursor.ascend(1);
    }
    drop(v224_23_cursor);
    drop(v224_23_write);
    map_map_kernels::compose(&(v218_22),&(v224_23))
  };
  drop(v218_22);
  let v218_25: Space = map_map_kernels::unite(&(v218_19),&(v218_24));
  (v218_25).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v226_7 = Space::new();
  let mut v226_7_write = v226_7.write_zipper();
  let mut v226_7_cursor = (*s0).read_zipper();
  let v226_7_origin = v226_7_cursor.path().len();
  for v226_7_byte in v226_7_cursor.child_mask().iter() {
    v226_7_cursor.descend_to_existing_byte(v226_7_byte);
    {
    let v227_2: Space = singleton(&v226_7_cursor.path()[v226_7_origin..(v226_7_origin + 1)]);
    let v227_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v227_2));
    let v227_4: Space = if map_kernels::has_head(&(v227_3)) { singleton(&[]) } else { Space::new() };
    drop(v227_3);
    let v227_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v227_4));
    drop(v227_4);
    let v227_8: Space = if (&(v227_5)).is_empty() { Space::new() } else {
      let mut v228_7 = Space::new();
      let mut v228_7_write = v228_7.write_zipper();
      let v228_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v228_7_arg_1: &[u8] = &v226_7_cursor.path()[v226_7_origin..(v226_7_origin + 1)];
      let v228_7_arg_2: &[u8] = &(*p0);
      let v228_7_arg_4: &Space = &(&v226_7_cursor).make_map();
      let mut v228_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v226_7_cursor.path()[v226_7_origin..(v226_7_origin + 1)]);
      let v228_7_origin = v228_7_cursor.path().len();
      let mut v228_7_more = v228_7_cursor.is_val() || next_value_within(&mut v228_7_cursor,v228_7_origin);
      while v228_7_more {
        {
        let v228_7_depth = v228_7_cursor.path().len();
        let mut v229_5_cursor = (*v228_7_arg_4).read_zipper();
        let v229_5_origin = v229_5_cursor.path().len();
        for v229_5_byte in v229_5_cursor.child_mask().iter() {
          v229_5_cursor.descend_to_existing_byte(v229_5_byte);
          {
          let v230_2: Path = concat_path(&(*v228_7_arg_1),&v229_5_cursor.path()[v229_5_origin..(v229_5_origin + 1)]);
          let v230_3: Space = routine_50(c, &(v230_2), &v228_7_cursor.path()[v228_7_origin..v228_7_depth], &(*v228_7_arg_2), &v229_5_cursor);
          drop(v230_2);
          join_wrapped_into(&mut v228_7_write,&((v230_3).read_zipper()),&[]);
          }
          v229_5_cursor.ascend(1);
        }
        drop(v229_5_cursor);
        }
        v228_7_more = next_value_within(&mut v228_7_cursor,v228_7_origin);
      }
      drop(v228_7_cursor);
      drop(v228_7_write);
      map_map_kernels::compose(&(v227_5),&(v228_7))
    };
    drop(v227_5);
    let v227_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v227_2));
    drop(v227_2);
    let v227_10: Space = if map_kernels::has_head(&(v227_9)) { singleton(&[]) } else { Space::new() };
    drop(v227_9);
    let v227_12: Space = if (&(v227_10)).is_empty() { Space::new() } else {
      let mut v231_11 = Space::new();
      let mut v231_11_write = v231_11.write_zipper();
      for v231_11_byte in v226_7_cursor.child_mask().iter() {
        v226_7_cursor.descend_to_existing_byte(v231_11_byte);
        {
        let v232_2: Space = routine_51(c, &v226_7_cursor.path()[(v226_7_origin + 1)..(v226_7_origin + 2)], &v226_7_cursor.path()[(v226_7_origin + 1)..(v226_7_origin + 2)], &(*p0), &v226_7_cursor.path()[v226_7_origin..(v226_7_origin + 1)], &v226_7_cursor);
        join_wrapped_into(&mut v231_11_write,&((v232_2).read_zipper()),&[]);
        }
        v226_7_cursor.ascend(1);
      }
      drop(v231_11_write);
      map_map_kernels::compose(&(v227_10),&(v231_11))
    };
    drop(v227_10);
    let v227_13: Space = map_map_kernels::unite(&(v227_8),&(v227_12));
    join_wrapped_into(&mut v226_7_write,&((v227_13).read_zipper()),&[]);
    }
    v226_7_cursor.ascend(1);
  }
  drop(v226_7_cursor);
  drop(v226_7_write);
  (v226_7).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v233_5: Space = singleton(&(*p1));
  let v233_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v233_5));
  let v233_7: Space = if map_kernels::has_head(&(v233_6)) { singleton(&[]) } else { Space::new() };
  drop(v233_6);
  let v233_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v233_7));
  drop(v233_7);
  let v233_19: Space = if (&(v233_8)).is_empty() { Space::new() } else {
    let v234_11: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v234_14: Space = if (&(v234_11)).is_empty() { Space::new() } else {
      let v235_13: Space = routine_52(c, &(*CONSTANT_1), &(*p0), &(*s0));
      map_map_kernels::compose(&(v234_11),&(v235_13))
    };
    drop(v234_11);
    let mut v234_17 = Space::new();
    let mut v234_17_write = v234_17.write_zipper();
    let mut v234_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v234_17_origin = v234_17_cursor.path().len();
    for v234_17_byte in v234_17_cursor.child_mask().iter() {
      v234_17_cursor.descend_to_existing_byte(v234_17_byte);
      {
      let v236_2_arg_0: &[u8] = &v234_17_cursor.path()[v234_17_origin..(v234_17_origin + 1)];
      let v236_2_arg_1: &[u8] = &(*p0);
      let v236_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v236_2_more = v234_17_cursor.is_val() || next_value_within(&mut v234_17_cursor,(v234_17_origin + 1));
      while v236_2_more {
        {
        let v236_2_depth = v234_17_cursor.path().len();
        let mut v237_4_cursor = (*v236_2_arg_3).read_zipper();
        let v237_4_origin = v237_4_cursor.path().len();
        for v237_4_byte in v237_4_cursor.child_mask().iter() {
          v237_4_cursor.descend_to_existing_byte(v237_4_byte);
          {
          let v238_2: Path = concat_path(&(*v236_2_arg_1),&v237_4_cursor.path()[v237_4_origin..(v237_4_origin + 1)]);
          let v238_3: Space = routine_26(c, &(v238_2), &v234_17_cursor.path()[v234_17_origin..v236_2_depth], &v237_4_cursor);
          drop(v238_2);
          join_wrapped_into(&mut v234_17_write,&((v238_3).read_zipper()),&[]);
          }
          v237_4_cursor.ascend(1);
        }
        drop(v237_4_cursor);
        }
        v236_2_more = next_value_within(&mut v234_17_cursor,(v234_17_origin + 1));
      }
      }
      v234_17_cursor.ascend(1);
    }
    drop(v234_17_cursor);
    drop(v234_17_write);
    let v234_18: Space = map_map_kernels::unite(&(v234_14),&(v234_17));
    map_map_kernels::compose(&(v233_8),&(v234_18))
  };
  drop(v233_8);
  let v233_21: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v233_5));
  drop(v233_5);
  let v233_22: Space = if map_kernels::has_head(&(v233_21)) { singleton(&[]) } else { Space::new() };
  drop(v233_21);
  let v233_24: Space = if (&(v233_22)).is_empty() { Space::new() } else {
    let mut v239_23 = Space::new();
    let mut v239_23_write = v239_23.write_zipper();
    let mut v239_23_cursor = (*s0).read_zipper();
    let v239_23_origin = v239_23_cursor.path().len();
    for v239_23_byte in v239_23_cursor.child_mask().iter() {
      v239_23_cursor.descend_to_existing_byte(v239_23_byte);
      {
      let v240_2: Space = routine_53(c, &v239_23_cursor.path()[v239_23_origin..(v239_23_origin + 1)], &v239_23_cursor.path()[v239_23_origin..(v239_23_origin + 1)], &(*p0), &v239_23_cursor);
      join_wrapped_into(&mut v239_23_write,&((v240_2).read_zipper()),&[]);
      }
      v239_23_cursor.ascend(1);
    }
    drop(v239_23_cursor);
    drop(v239_23_write);
    map_map_kernels::compose(&(v233_22),&(v239_23))
  };
  drop(v233_22);
  let v233_25: Space = map_map_kernels::unite(&(v233_19),&(v233_24));
  (v233_25).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v241_7 = Space::new();
  let mut v241_7_write = v241_7.write_zipper();
  let mut v241_7_cursor = (*s0).read_zipper();
  let v241_7_origin = v241_7_cursor.path().len();
  for v241_7_byte in v241_7_cursor.child_mask().iter() {
    v241_7_cursor.descend_to_existing_byte(v241_7_byte);
    {
    let v242_2: Space = singleton(&v241_7_cursor.path()[v241_7_origin..(v241_7_origin + 1)]);
    let v242_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v242_2));
    let v242_4: Space = if map_kernels::has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
    drop(v242_3);
    let v242_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v242_4));
    drop(v242_4);
    let v242_8: Space = if (&(v242_5)).is_empty() { Space::new() } else {
      let mut v243_7 = Space::new();
      let mut v243_7_write = v243_7.write_zipper();
      let v243_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v243_7_arg_1: &[u8] = &v241_7_cursor.path()[v241_7_origin..(v241_7_origin + 1)];
      let v243_7_arg_2: &[u8] = &(*p0);
      let v243_7_arg_4: &Space = &(&v241_7_cursor).make_map();
      let mut v243_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v241_7_cursor.path()[v241_7_origin..(v241_7_origin + 1)]);
      let v243_7_origin = v243_7_cursor.path().len();
      let mut v243_7_more = v243_7_cursor.is_val() || next_value_within(&mut v243_7_cursor,v243_7_origin);
      while v243_7_more {
        {
        let v243_7_depth = v243_7_cursor.path().len();
        let mut v244_5_cursor = (*v243_7_arg_4).read_zipper();
        let v244_5_origin = v244_5_cursor.path().len();
        for v244_5_byte in v244_5_cursor.child_mask().iter() {
          v244_5_cursor.descend_to_existing_byte(v244_5_byte);
          {
          let v245_2: Path = concat_path(&(*v243_7_arg_1),&v244_5_cursor.path()[v244_5_origin..(v244_5_origin + 1)]);
          let v245_3: Space = routine_53(c, &(v245_2), &v243_7_cursor.path()[v243_7_origin..v243_7_depth], &(*v243_7_arg_2), &v244_5_cursor);
          drop(v245_2);
          join_wrapped_into(&mut v243_7_write,&((v245_3).read_zipper()),&[]);
          }
          v244_5_cursor.ascend(1);
        }
        drop(v244_5_cursor);
        }
        v243_7_more = next_value_within(&mut v243_7_cursor,v243_7_origin);
      }
      drop(v243_7_cursor);
      drop(v243_7_write);
      map_map_kernels::compose(&(v242_5),&(v243_7))
    };
    drop(v242_5);
    let v242_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v242_2));
    drop(v242_2);
    let v242_10: Space = if map_kernels::has_head(&(v242_9)) { singleton(&[]) } else { Space::new() };
    drop(v242_9);
    let v242_12: Space = if (&(v242_10)).is_empty() { Space::new() } else {
      let mut v246_11 = Space::new();
      let mut v246_11_write = v246_11.write_zipper();
      for v246_11_byte in v241_7_cursor.child_mask().iter() {
        v241_7_cursor.descend_to_existing_byte(v246_11_byte);
        {
        let v247_2: Space = routine_54(c, &v241_7_cursor.path()[(v241_7_origin + 1)..(v241_7_origin + 2)], &v241_7_cursor.path()[(v241_7_origin + 1)..(v241_7_origin + 2)], &(*p0), &v241_7_cursor.path()[v241_7_origin..(v241_7_origin + 1)], &v241_7_cursor);
        join_wrapped_into(&mut v246_11_write,&((v247_2).read_zipper()),&[]);
        }
        v241_7_cursor.ascend(1);
      }
      drop(v246_11_write);
      map_map_kernels::compose(&(v242_10),&(v246_11))
    };
    drop(v242_10);
    let v242_13: Space = map_map_kernels::unite(&(v242_8),&(v242_12));
    join_wrapped_into(&mut v241_7_write,&((v242_13).read_zipper()),&[]);
    }
    v241_7_cursor.ascend(1);
  }
  drop(v241_7_cursor);
  drop(v241_7_write);
  (v241_7).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v248_5: Space = singleton(&(*p1));
  let v248_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v248_5));
  let v248_7: Space = if map_kernels::has_head(&(v248_6)) { singleton(&[]) } else { Space::new() };
  drop(v248_6);
  let v248_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v248_7));
  drop(v248_7);
  let v248_19: Space = if (&(v248_8)).is_empty() { Space::new() } else {
    let v249_11: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v249_14: Space = if (&(v249_11)).is_empty() { Space::new() } else {
      let v250_13: Space = routine_55(c, &(*CONSTANT_1), &(*p0), &(*s0));
      map_map_kernels::compose(&(v249_11),&(v250_13))
    };
    drop(v249_11);
    let mut v249_17 = Space::new();
    let mut v249_17_write = v249_17.write_zipper();
    let mut v249_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v249_17_origin = v249_17_cursor.path().len();
    for v249_17_byte in v249_17_cursor.child_mask().iter() {
      v249_17_cursor.descend_to_existing_byte(v249_17_byte);
      {
      let v251_2_arg_0: &[u8] = &v249_17_cursor.path()[v249_17_origin..(v249_17_origin + 1)];
      let v251_2_arg_1: &[u8] = &(*p0);
      let v251_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v251_2_more = v249_17_cursor.is_val() || next_value_within(&mut v249_17_cursor,(v249_17_origin + 1));
      while v251_2_more {
        {
        let v251_2_depth = v249_17_cursor.path().len();
        let mut v252_4_cursor = (*v251_2_arg_3).read_zipper();
        let v252_4_origin = v252_4_cursor.path().len();
        for v252_4_byte in v252_4_cursor.child_mask().iter() {
          v252_4_cursor.descend_to_existing_byte(v252_4_byte);
          {
          let v253_2: Path = concat_path(&(*v251_2_arg_1),&v252_4_cursor.path()[v252_4_origin..(v252_4_origin + 1)]);
          let v253_3: Space = routine_28(c, &(v253_2), &v249_17_cursor.path()[v249_17_origin..v251_2_depth], &v252_4_cursor);
          drop(v253_2);
          join_wrapped_into(&mut v249_17_write,&((v253_3).read_zipper()),&[]);
          }
          v252_4_cursor.ascend(1);
        }
        drop(v252_4_cursor);
        }
        v251_2_more = next_value_within(&mut v249_17_cursor,(v249_17_origin + 1));
      }
      }
      v249_17_cursor.ascend(1);
    }
    drop(v249_17_cursor);
    drop(v249_17_write);
    let v249_18: Space = map_map_kernels::unite(&(v249_14),&(v249_17));
    map_map_kernels::compose(&(v248_8),&(v249_18))
  };
  drop(v248_8);
  let v248_21: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v248_5));
  drop(v248_5);
  let v248_22: Space = if map_kernels::has_head(&(v248_21)) { singleton(&[]) } else { Space::new() };
  drop(v248_21);
  let v248_24: Space = if (&(v248_22)).is_empty() { Space::new() } else {
    let mut v254_23 = Space::new();
    let mut v254_23_write = v254_23.write_zipper();
    let mut v254_23_cursor = (*s0).read_zipper();
    let v254_23_origin = v254_23_cursor.path().len();
    for v254_23_byte in v254_23_cursor.child_mask().iter() {
      v254_23_cursor.descend_to_existing_byte(v254_23_byte);
      {
      let v255_2: Space = routine_56(c, &v254_23_cursor.path()[v254_23_origin..(v254_23_origin + 1)], &v254_23_cursor.path()[v254_23_origin..(v254_23_origin + 1)], &(*p0), &v254_23_cursor);
      join_wrapped_into(&mut v254_23_write,&((v255_2).read_zipper()),&[]);
      }
      v254_23_cursor.ascend(1);
    }
    drop(v254_23_cursor);
    drop(v254_23_write);
    map_map_kernels::compose(&(v248_22),&(v254_23))
  };
  drop(v248_22);
  let v248_25: Space = map_map_kernels::unite(&(v248_19),&(v248_24));
  (v248_25).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v256_7 = Space::new();
  let mut v256_7_write = v256_7.write_zipper();
  let mut v256_7_cursor = (*s0).read_zipper();
  let v256_7_origin = v256_7_cursor.path().len();
  for v256_7_byte in v256_7_cursor.child_mask().iter() {
    v256_7_cursor.descend_to_existing_byte(v256_7_byte);
    {
    let v257_2: Space = singleton(&v256_7_cursor.path()[v256_7_origin..(v256_7_origin + 1)]);
    let v257_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v257_2));
    let v257_4: Space = if map_kernels::has_head(&(v257_3)) { singleton(&[]) } else { Space::new() };
    drop(v257_3);
    let v257_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v257_4));
    drop(v257_4);
    let v257_8: Space = if (&(v257_5)).is_empty() { Space::new() } else {
      let mut v258_7 = Space::new();
      let mut v258_7_write = v258_7.write_zipper();
      let v258_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v258_7_arg_1: &[u8] = &v256_7_cursor.path()[v256_7_origin..(v256_7_origin + 1)];
      let v258_7_arg_2: &[u8] = &(*p0);
      let v258_7_arg_4: &Space = &(&v256_7_cursor).make_map();
      let mut v258_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v256_7_cursor.path()[v256_7_origin..(v256_7_origin + 1)]);
      let v258_7_origin = v258_7_cursor.path().len();
      let mut v258_7_more = v258_7_cursor.is_val() || next_value_within(&mut v258_7_cursor,v258_7_origin);
      while v258_7_more {
        {
        let v258_7_depth = v258_7_cursor.path().len();
        let mut v259_5_cursor = (*v258_7_arg_4).read_zipper();
        let v259_5_origin = v259_5_cursor.path().len();
        for v259_5_byte in v259_5_cursor.child_mask().iter() {
          v259_5_cursor.descend_to_existing_byte(v259_5_byte);
          {
          let v260_2: Path = concat_path(&(*v258_7_arg_1),&v259_5_cursor.path()[v259_5_origin..(v259_5_origin + 1)]);
          let v260_3: Space = routine_56(c, &(v260_2), &v258_7_cursor.path()[v258_7_origin..v258_7_depth], &(*v258_7_arg_2), &v259_5_cursor);
          drop(v260_2);
          join_wrapped_into(&mut v258_7_write,&((v260_3).read_zipper()),&[]);
          }
          v259_5_cursor.ascend(1);
        }
        drop(v259_5_cursor);
        }
        v258_7_more = next_value_within(&mut v258_7_cursor,v258_7_origin);
      }
      drop(v258_7_cursor);
      drop(v258_7_write);
      map_map_kernels::compose(&(v257_5),&(v258_7))
    };
    drop(v257_5);
    let v257_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v257_2));
    drop(v257_2);
    let v257_10: Space = if map_kernels::has_head(&(v257_9)) { singleton(&[]) } else { Space::new() };
    drop(v257_9);
    let v257_12: Space = if (&(v257_10)).is_empty() { Space::new() } else {
      let mut v261_11 = Space::new();
      let mut v261_11_write = v261_11.write_zipper();
      for v261_11_byte in v256_7_cursor.child_mask().iter() {
        v256_7_cursor.descend_to_existing_byte(v261_11_byte);
        {
        let v262_2: Space = routine_57(c, &v256_7_cursor.path()[(v256_7_origin + 1)..(v256_7_origin + 2)], &v256_7_cursor.path()[(v256_7_origin + 1)..(v256_7_origin + 2)], &(*p0), &v256_7_cursor.path()[v256_7_origin..(v256_7_origin + 1)], &v256_7_cursor);
        join_wrapped_into(&mut v261_11_write,&((v262_2).read_zipper()),&[]);
        }
        v256_7_cursor.ascend(1);
      }
      drop(v261_11_write);
      map_map_kernels::compose(&(v257_10),&(v261_11))
    };
    drop(v257_10);
    let v257_13: Space = map_map_kernels::unite(&(v257_8),&(v257_12));
    join_wrapped_into(&mut v256_7_write,&((v257_13).read_zipper()),&[]);
    }
    v256_7_cursor.ascend(1);
  }
  drop(v256_7_cursor);
  drop(v256_7_write);
  (v256_7).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v263_5: Space = singleton(&(*p1));
  let v263_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v263_5));
  let v263_7: Space = if map_kernels::has_head(&(v263_6)) { singleton(&[]) } else { Space::new() };
  drop(v263_6);
  let v263_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v263_7));
  drop(v263_7);
  let v263_19: Space = if (&(v263_8)).is_empty() { Space::new() } else {
    let v264_11: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v264_14: Space = if (&(v264_11)).is_empty() { Space::new() } else {
      let v265_13: Space = routine_58(c, &(*CONSTANT_1), &(*p0), &(*s0));
      map_map_kernels::compose(&(v264_11),&(v265_13))
    };
    drop(v264_11);
    let mut v264_17 = Space::new();
    let mut v264_17_write = v264_17.write_zipper();
    let mut v264_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v264_17_origin = v264_17_cursor.path().len();
    for v264_17_byte in v264_17_cursor.child_mask().iter() {
      v264_17_cursor.descend_to_existing_byte(v264_17_byte);
      {
      let v266_2_arg_0: &[u8] = &v264_17_cursor.path()[v264_17_origin..(v264_17_origin + 1)];
      let v266_2_arg_1: &[u8] = &(*p0);
      let v266_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v266_2_more = v264_17_cursor.is_val() || next_value_within(&mut v264_17_cursor,(v264_17_origin + 1));
      while v266_2_more {
        {
        let v266_2_depth = v264_17_cursor.path().len();
        let mut v267_4_cursor = (*v266_2_arg_3).read_zipper();
        let v267_4_origin = v267_4_cursor.path().len();
        for v267_4_byte in v267_4_cursor.child_mask().iter() {
          v267_4_cursor.descend_to_existing_byte(v267_4_byte);
          {
          let v268_2: Path = concat_path(&(*v266_2_arg_1),&v267_4_cursor.path()[v267_4_origin..(v267_4_origin + 1)]);
          let v268_3: Space = routine_30(c, &(v268_2), &v264_17_cursor.path()[v264_17_origin..v266_2_depth], &v267_4_cursor);
          drop(v268_2);
          join_wrapped_into(&mut v264_17_write,&((v268_3).read_zipper()),&[]);
          }
          v267_4_cursor.ascend(1);
        }
        drop(v267_4_cursor);
        }
        v266_2_more = next_value_within(&mut v264_17_cursor,(v264_17_origin + 1));
      }
      }
      v264_17_cursor.ascend(1);
    }
    drop(v264_17_cursor);
    drop(v264_17_write);
    let v264_18: Space = map_map_kernels::unite(&(v264_14),&(v264_17));
    map_map_kernels::compose(&(v263_8),&(v264_18))
  };
  drop(v263_8);
  let v263_21: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v263_5));
  drop(v263_5);
  let v263_22: Space = if map_kernels::has_head(&(v263_21)) { singleton(&[]) } else { Space::new() };
  drop(v263_21);
  let v263_24: Space = if (&(v263_22)).is_empty() { Space::new() } else {
    let mut v269_23 = Space::new();
    let mut v269_23_write = v269_23.write_zipper();
    let mut v269_23_cursor = (*s0).read_zipper();
    let v269_23_origin = v269_23_cursor.path().len();
    for v269_23_byte in v269_23_cursor.child_mask().iter() {
      v269_23_cursor.descend_to_existing_byte(v269_23_byte);
      {
      let v270_2: Space = routine_59(c, &v269_23_cursor.path()[v269_23_origin..(v269_23_origin + 1)], &v269_23_cursor.path()[v269_23_origin..(v269_23_origin + 1)], &(*p0), &v269_23_cursor);
      join_wrapped_into(&mut v269_23_write,&((v270_2).read_zipper()),&[]);
      }
      v269_23_cursor.ascend(1);
    }
    drop(v269_23_cursor);
    drop(v269_23_write);
    map_map_kernels::compose(&(v263_22),&(v269_23))
  };
  drop(v263_22);
  let v263_25: Space = map_map_kernels::unite(&(v263_19),&(v263_24));
  (v263_25).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v271_7 = Space::new();
  let mut v271_7_write = v271_7.write_zipper();
  let mut v271_7_cursor = (*s0).read_zipper();
  let v271_7_origin = v271_7_cursor.path().len();
  for v271_7_byte in v271_7_cursor.child_mask().iter() {
    v271_7_cursor.descend_to_existing_byte(v271_7_byte);
    {
    let v272_2: Space = singleton(&v271_7_cursor.path()[v271_7_origin..(v271_7_origin + 1)]);
    let v272_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v272_2));
    let v272_4: Space = if map_kernels::has_head(&(v272_3)) { singleton(&[]) } else { Space::new() };
    drop(v272_3);
    let v272_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v272_4));
    drop(v272_4);
    let v272_8: Space = if (&(v272_5)).is_empty() { Space::new() } else {
      let mut v273_7 = Space::new();
      let mut v273_7_write = v273_7.write_zipper();
      let v273_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v273_7_arg_1: &[u8] = &v271_7_cursor.path()[v271_7_origin..(v271_7_origin + 1)];
      let v273_7_arg_2: &[u8] = &(*p0);
      let v273_7_arg_4: &Space = &(&v271_7_cursor).make_map();
      let mut v273_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v271_7_cursor.path()[v271_7_origin..(v271_7_origin + 1)]);
      let v273_7_origin = v273_7_cursor.path().len();
      let mut v273_7_more = v273_7_cursor.is_val() || next_value_within(&mut v273_7_cursor,v273_7_origin);
      while v273_7_more {
        {
        let v273_7_depth = v273_7_cursor.path().len();
        let mut v274_5_cursor = (*v273_7_arg_4).read_zipper();
        let v274_5_origin = v274_5_cursor.path().len();
        for v274_5_byte in v274_5_cursor.child_mask().iter() {
          v274_5_cursor.descend_to_existing_byte(v274_5_byte);
          {
          let v275_2: Path = concat_path(&(*v273_7_arg_1),&v274_5_cursor.path()[v274_5_origin..(v274_5_origin + 1)]);
          let v275_3: Space = routine_59(c, &(v275_2), &v273_7_cursor.path()[v273_7_origin..v273_7_depth], &(*v273_7_arg_2), &v274_5_cursor);
          drop(v275_2);
          join_wrapped_into(&mut v273_7_write,&((v275_3).read_zipper()),&[]);
          }
          v274_5_cursor.ascend(1);
        }
        drop(v274_5_cursor);
        }
        v273_7_more = next_value_within(&mut v273_7_cursor,v273_7_origin);
      }
      drop(v273_7_cursor);
      drop(v273_7_write);
      map_map_kernels::compose(&(v272_5),&(v273_7))
    };
    drop(v272_5);
    let v272_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v272_2));
    drop(v272_2);
    let v272_10: Space = if map_kernels::has_head(&(v272_9)) { singleton(&[]) } else { Space::new() };
    drop(v272_9);
    let v272_12: Space = if (&(v272_10)).is_empty() { Space::new() } else {
      let mut v276_11 = Space::new();
      let mut v276_11_write = v276_11.write_zipper();
      for v276_11_byte in v271_7_cursor.child_mask().iter() {
        v271_7_cursor.descend_to_existing_byte(v276_11_byte);
        {
        let v277_2: Space = routine_60(c, &v271_7_cursor.path()[(v271_7_origin + 1)..(v271_7_origin + 2)], &v271_7_cursor.path()[(v271_7_origin + 1)..(v271_7_origin + 2)], &(*p0), &v271_7_cursor.path()[v271_7_origin..(v271_7_origin + 1)], &v271_7_cursor);
        join_wrapped_into(&mut v276_11_write,&((v277_2).read_zipper()),&[]);
        }
        v271_7_cursor.ascend(1);
      }
      drop(v276_11_write);
      map_map_kernels::compose(&(v272_10),&(v276_11))
    };
    drop(v272_10);
    let v272_13: Space = map_map_kernels::unite(&(v272_8),&(v272_12));
    join_wrapped_into(&mut v271_7_write,&((v272_13).read_zipper()),&[]);
    }
    v271_7_cursor.ascend(1);
  }
  drop(v271_7_cursor);
  drop(v271_7_write);
  (v271_7).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v278_5: Space = singleton(&(*p1));
  let v278_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v278_5));
  let v278_7: Space = if map_kernels::has_head(&(v278_6)) { singleton(&[]) } else { Space::new() };
  drop(v278_6);
  let v278_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v278_7));
  drop(v278_7);
  let v278_19: Space = if (&(v278_8)).is_empty() { Space::new() } else {
    let v279_11: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v279_14: Space = if (&(v279_11)).is_empty() { Space::new() } else {
      let v280_13: Space = routine_61(c, &(*CONSTANT_1), &(*p0), &(*s0));
      map_map_kernels::compose(&(v279_11),&(v280_13))
    };
    drop(v279_11);
    let mut v279_17 = Space::new();
    let mut v279_17_write = v279_17.write_zipper();
    let mut v279_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v279_17_origin = v279_17_cursor.path().len();
    for v279_17_byte in v279_17_cursor.child_mask().iter() {
      v279_17_cursor.descend_to_existing_byte(v279_17_byte);
      {
      let v281_2_arg_0: &[u8] = &v279_17_cursor.path()[v279_17_origin..(v279_17_origin + 1)];
      let v281_2_arg_1: &[u8] = &(*p0);
      let v281_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v281_2_more = v279_17_cursor.is_val() || next_value_within(&mut v279_17_cursor,(v279_17_origin + 1));
      while v281_2_more {
        {
        let v281_2_depth = v279_17_cursor.path().len();
        let mut v282_4_cursor = (*v281_2_arg_3).read_zipper();
        let v282_4_origin = v282_4_cursor.path().len();
        for v282_4_byte in v282_4_cursor.child_mask().iter() {
          v282_4_cursor.descend_to_existing_byte(v282_4_byte);
          {
          let v283_2: Path = concat_path(&(*v281_2_arg_1),&v282_4_cursor.path()[v282_4_origin..(v282_4_origin + 1)]);
          let v283_3: Space = routine_32(c, &(v283_2), &v279_17_cursor.path()[v279_17_origin..v281_2_depth], &v282_4_cursor);
          drop(v283_2);
          join_wrapped_into(&mut v279_17_write,&((v283_3).read_zipper()),&[]);
          }
          v282_4_cursor.ascend(1);
        }
        drop(v282_4_cursor);
        }
        v281_2_more = next_value_within(&mut v279_17_cursor,(v279_17_origin + 1));
      }
      }
      v279_17_cursor.ascend(1);
    }
    drop(v279_17_cursor);
    drop(v279_17_write);
    let v279_18: Space = map_map_kernels::unite(&(v279_14),&(v279_17));
    map_map_kernels::compose(&(v278_8),&(v279_18))
  };
  drop(v278_8);
  let v278_21: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v278_5));
  drop(v278_5);
  let v278_22: Space = if map_kernels::has_head(&(v278_21)) { singleton(&[]) } else { Space::new() };
  drop(v278_21);
  let v278_24: Space = if (&(v278_22)).is_empty() { Space::new() } else {
    let mut v284_23 = Space::new();
    let mut v284_23_write = v284_23.write_zipper();
    let mut v284_23_cursor = (*s0).read_zipper();
    let v284_23_origin = v284_23_cursor.path().len();
    for v284_23_byte in v284_23_cursor.child_mask().iter() {
      v284_23_cursor.descend_to_existing_byte(v284_23_byte);
      {
      let v285_2: Space = routine_62(c, &v284_23_cursor.path()[v284_23_origin..(v284_23_origin + 1)], &v284_23_cursor.path()[v284_23_origin..(v284_23_origin + 1)], &(*p0), &v284_23_cursor);
      join_wrapped_into(&mut v284_23_write,&((v285_2).read_zipper()),&[]);
      }
      v284_23_cursor.ascend(1);
    }
    drop(v284_23_cursor);
    drop(v284_23_write);
    map_map_kernels::compose(&(v278_22),&(v284_23))
  };
  drop(v278_22);
  let v278_25: Space = map_map_kernels::unite(&(v278_19),&(v278_24));
  (v278_25).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v286_7 = Space::new();
  let mut v286_7_write = v286_7.write_zipper();
  let mut v286_7_cursor = (*s0).read_zipper();
  let v286_7_origin = v286_7_cursor.path().len();
  for v286_7_byte in v286_7_cursor.child_mask().iter() {
    v286_7_cursor.descend_to_existing_byte(v286_7_byte);
    {
    let v287_2: Space = singleton(&v286_7_cursor.path()[v286_7_origin..(v286_7_origin + 1)]);
    let v287_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v287_2));
    let v287_4: Space = if map_kernels::has_head(&(v287_3)) { singleton(&[]) } else { Space::new() };
    drop(v287_3);
    let v287_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v287_4));
    drop(v287_4);
    let v287_8: Space = if (&(v287_5)).is_empty() { Space::new() } else {
      let mut v288_7 = Space::new();
      let mut v288_7_write = v288_7.write_zipper();
      let v288_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v288_7_arg_1: &[u8] = &v286_7_cursor.path()[v286_7_origin..(v286_7_origin + 1)];
      let v288_7_arg_2: &[u8] = &(*p0);
      let v288_7_arg_4: &Space = &(&v286_7_cursor).make_map();
      let mut v288_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v286_7_cursor.path()[v286_7_origin..(v286_7_origin + 1)]);
      let v288_7_origin = v288_7_cursor.path().len();
      let mut v288_7_more = v288_7_cursor.is_val() || next_value_within(&mut v288_7_cursor,v288_7_origin);
      while v288_7_more {
        {
        let v288_7_depth = v288_7_cursor.path().len();
        let mut v289_5_cursor = (*v288_7_arg_4).read_zipper();
        let v289_5_origin = v289_5_cursor.path().len();
        for v289_5_byte in v289_5_cursor.child_mask().iter() {
          v289_5_cursor.descend_to_existing_byte(v289_5_byte);
          {
          let v290_2: Path = concat_path(&(*v288_7_arg_1),&v289_5_cursor.path()[v289_5_origin..(v289_5_origin + 1)]);
          let v290_3: Space = routine_62(c, &(v290_2), &v288_7_cursor.path()[v288_7_origin..v288_7_depth], &(*v288_7_arg_2), &v289_5_cursor);
          drop(v290_2);
          join_wrapped_into(&mut v288_7_write,&((v290_3).read_zipper()),&[]);
          }
          v289_5_cursor.ascend(1);
        }
        drop(v289_5_cursor);
        }
        v288_7_more = next_value_within(&mut v288_7_cursor,v288_7_origin);
      }
      drop(v288_7_cursor);
      drop(v288_7_write);
      map_map_kernels::compose(&(v287_5),&(v288_7))
    };
    drop(v287_5);
    let v287_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v287_2));
    drop(v287_2);
    let v287_10: Space = if map_kernels::has_head(&(v287_9)) { singleton(&[]) } else { Space::new() };
    drop(v287_9);
    let v287_12: Space = if (&(v287_10)).is_empty() { Space::new() } else {
      let mut v291_11 = Space::new();
      let mut v291_11_write = v291_11.write_zipper();
      for v291_11_byte in v286_7_cursor.child_mask().iter() {
        v286_7_cursor.descend_to_existing_byte(v291_11_byte);
        {
        let v292_2: Space = routine_63(c, &v286_7_cursor.path()[(v286_7_origin + 1)..(v286_7_origin + 2)], &v286_7_cursor.path()[(v286_7_origin + 1)..(v286_7_origin + 2)], &(*p0), &v286_7_cursor.path()[v286_7_origin..(v286_7_origin + 1)], &v286_7_cursor);
        join_wrapped_into(&mut v291_11_write,&((v292_2).read_zipper()),&[]);
        }
        v286_7_cursor.ascend(1);
      }
      drop(v291_11_write);
      map_map_kernels::compose(&(v287_10),&(v291_11))
    };
    drop(v287_10);
    let v287_13: Space = map_map_kernels::unite(&(v287_8),&(v287_12));
    join_wrapped_into(&mut v286_7_write,&((v287_13).read_zipper()),&[]);
    }
    v286_7_cursor.ascend(1);
  }
  drop(v286_7_cursor);
  drop(v286_7_write);
  (v286_7).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v293_5: Space = singleton(&(*p1));
  let v293_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v293_5));
  let v293_7: Space = if map_kernels::has_head(&(v293_6)) { singleton(&[]) } else { Space::new() };
  drop(v293_6);
  let v293_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v293_7));
  drop(v293_7);
  let v293_19: Space = if (&(v293_8)).is_empty() { Space::new() } else {
    let v294_11: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v294_14: Space = if (&(v294_11)).is_empty() { Space::new() } else {
      let v295_13: Space = routine_64(c, &(*CONSTANT_1), &(*p0), &(*s0));
      map_map_kernels::compose(&(v294_11),&(v295_13))
    };
    drop(v294_11);
    let mut v294_17 = Space::new();
    let mut v294_17_write = v294_17.write_zipper();
    let mut v294_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v294_17_origin = v294_17_cursor.path().len();
    for v294_17_byte in v294_17_cursor.child_mask().iter() {
      v294_17_cursor.descend_to_existing_byte(v294_17_byte);
      {
      let v296_2_arg_0: &[u8] = &v294_17_cursor.path()[v294_17_origin..(v294_17_origin + 1)];
      let v296_2_arg_1: &[u8] = &(*p0);
      let v296_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v296_2_more = v294_17_cursor.is_val() || next_value_within(&mut v294_17_cursor,(v294_17_origin + 1));
      while v296_2_more {
        {
        let v296_2_depth = v294_17_cursor.path().len();
        let mut v297_4_cursor = (*v296_2_arg_3).read_zipper();
        let v297_4_origin = v297_4_cursor.path().len();
        for v297_4_byte in v297_4_cursor.child_mask().iter() {
          v297_4_cursor.descend_to_existing_byte(v297_4_byte);
          {
          let v298_2: Path = concat_path(&(*v296_2_arg_1),&v297_4_cursor.path()[v297_4_origin..(v297_4_origin + 1)]);
          let v298_3: Space = routine_34(c, &(v298_2), &v294_17_cursor.path()[v294_17_origin..v296_2_depth], &v297_4_cursor);
          drop(v298_2);
          join_wrapped_into(&mut v294_17_write,&((v298_3).read_zipper()),&[]);
          }
          v297_4_cursor.ascend(1);
        }
        drop(v297_4_cursor);
        }
        v296_2_more = next_value_within(&mut v294_17_cursor,(v294_17_origin + 1));
      }
      }
      v294_17_cursor.ascend(1);
    }
    drop(v294_17_cursor);
    drop(v294_17_write);
    let v294_18: Space = map_map_kernels::unite(&(v294_14),&(v294_17));
    map_map_kernels::compose(&(v293_8),&(v294_18))
  };
  drop(v293_8);
  let v293_21: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v293_5));
  drop(v293_5);
  let v293_22: Space = if map_kernels::has_head(&(v293_21)) { singleton(&[]) } else { Space::new() };
  drop(v293_21);
  let v293_24: Space = if (&(v293_22)).is_empty() { Space::new() } else {
    let mut v299_23 = Space::new();
    let mut v299_23_write = v299_23.write_zipper();
    let mut v299_23_cursor = (*s0).read_zipper();
    let v299_23_origin = v299_23_cursor.path().len();
    for v299_23_byte in v299_23_cursor.child_mask().iter() {
      v299_23_cursor.descend_to_existing_byte(v299_23_byte);
      {
      let v300_2: Space = routine_65(c, &v299_23_cursor.path()[v299_23_origin..(v299_23_origin + 1)], &v299_23_cursor.path()[v299_23_origin..(v299_23_origin + 1)], &(*p0), &v299_23_cursor);
      join_wrapped_into(&mut v299_23_write,&((v300_2).read_zipper()),&[]);
      }
      v299_23_cursor.ascend(1);
    }
    drop(v299_23_cursor);
    drop(v299_23_write);
    map_map_kernels::compose(&(v293_22),&(v299_23))
  };
  drop(v293_22);
  let v293_25: Space = map_map_kernels::unite(&(v293_19),&(v293_24));
  (v293_25).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v301_7 = Space::new();
  let mut v301_7_write = v301_7.write_zipper();
  let mut v301_7_cursor = (*s0).read_zipper();
  let v301_7_origin = v301_7_cursor.path().len();
  for v301_7_byte in v301_7_cursor.child_mask().iter() {
    v301_7_cursor.descend_to_existing_byte(v301_7_byte);
    {
    let v302_2: Space = singleton(&v301_7_cursor.path()[v301_7_origin..(v301_7_origin + 1)]);
    let v302_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v302_2));
    let v302_4: Space = if map_kernels::has_head(&(v302_3)) { singleton(&[]) } else { Space::new() };
    drop(v302_3);
    let v302_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v302_4));
    drop(v302_4);
    let v302_8: Space = if (&(v302_5)).is_empty() { Space::new() } else {
      let mut v303_7 = Space::new();
      let mut v303_7_write = v303_7.write_zipper();
      let v303_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v303_7_arg_1: &[u8] = &v301_7_cursor.path()[v301_7_origin..(v301_7_origin + 1)];
      let v303_7_arg_2: &[u8] = &(*p0);
      let v303_7_arg_4: &Space = &(&v301_7_cursor).make_map();
      let mut v303_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v301_7_cursor.path()[v301_7_origin..(v301_7_origin + 1)]);
      let v303_7_origin = v303_7_cursor.path().len();
      let mut v303_7_more = v303_7_cursor.is_val() || next_value_within(&mut v303_7_cursor,v303_7_origin);
      while v303_7_more {
        {
        let v303_7_depth = v303_7_cursor.path().len();
        let mut v304_5_cursor = (*v303_7_arg_4).read_zipper();
        let v304_5_origin = v304_5_cursor.path().len();
        for v304_5_byte in v304_5_cursor.child_mask().iter() {
          v304_5_cursor.descend_to_existing_byte(v304_5_byte);
          {
          let v305_2: Path = concat_path(&(*v303_7_arg_1),&v304_5_cursor.path()[v304_5_origin..(v304_5_origin + 1)]);
          let v305_3: Space = routine_65(c, &(v305_2), &v303_7_cursor.path()[v303_7_origin..v303_7_depth], &(*v303_7_arg_2), &v304_5_cursor);
          drop(v305_2);
          join_wrapped_into(&mut v303_7_write,&((v305_3).read_zipper()),&[]);
          }
          v304_5_cursor.ascend(1);
        }
        drop(v304_5_cursor);
        }
        v303_7_more = next_value_within(&mut v303_7_cursor,v303_7_origin);
      }
      drop(v303_7_cursor);
      drop(v303_7_write);
      map_map_kernels::compose(&(v302_5),&(v303_7))
    };
    drop(v302_5);
    let v302_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v302_2));
    drop(v302_2);
    let v302_10: Space = if map_kernels::has_head(&(v302_9)) { singleton(&[]) } else { Space::new() };
    drop(v302_9);
    let v302_12: Space = if (&(v302_10)).is_empty() { Space::new() } else {
      let mut v306_11 = Space::new();
      let mut v306_11_write = v306_11.write_zipper();
      for v306_11_byte in v301_7_cursor.child_mask().iter() {
        v301_7_cursor.descend_to_existing_byte(v306_11_byte);
        {
        let v307_2: Space = routine_66(c, &v301_7_cursor.path()[(v301_7_origin + 1)..(v301_7_origin + 2)], &v301_7_cursor.path()[(v301_7_origin + 1)..(v301_7_origin + 2)], &(*p0), &v301_7_cursor.path()[v301_7_origin..(v301_7_origin + 1)], &v301_7_cursor);
        join_wrapped_into(&mut v306_11_write,&((v307_2).read_zipper()),&[]);
        }
        v301_7_cursor.ascend(1);
      }
      drop(v306_11_write);
      map_map_kernels::compose(&(v302_10),&(v306_11))
    };
    drop(v302_10);
    let v302_13: Space = map_map_kernels::unite(&(v302_8),&(v302_12));
    join_wrapped_into(&mut v301_7_write,&((v302_13).read_zipper()),&[]);
    }
    v301_7_cursor.ascend(1);
  }
  drop(v301_7_cursor);
  drop(v301_7_write);
  (v301_7).clone()
}

fn routine_36(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v308_5: Space = singleton(&(*p1));
  let v308_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v308_5));
  let v308_7: Space = if map_kernels::has_head(&(v308_6)) { singleton(&[]) } else { Space::new() };
  drop(v308_6);
  let v308_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v308_7));
  drop(v308_7);
  let v308_19: Space = if (&(v308_8)).is_empty() { Space::new() } else {
    let v309_11: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v309_14: Space = if (&(v309_11)).is_empty() { Space::new() } else {
      let v310_13: Space = routine_67(c, &(*CONSTANT_1), &(*p0), &(*s0));
      map_map_kernels::compose(&(v309_11),&(v310_13))
    };
    drop(v309_11);
    let mut v309_17 = Space::new();
    let mut v309_17_write = v309_17.write_zipper();
    let mut v309_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v309_17_origin = v309_17_cursor.path().len();
    for v309_17_byte in v309_17_cursor.child_mask().iter() {
      v309_17_cursor.descend_to_existing_byte(v309_17_byte);
      {
      let v311_2_arg_0: &[u8] = &v309_17_cursor.path()[v309_17_origin..(v309_17_origin + 1)];
      let v311_2_arg_1: &[u8] = &(*p0);
      let v311_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v311_2_more = v309_17_cursor.is_val() || next_value_within(&mut v309_17_cursor,(v309_17_origin + 1));
      while v311_2_more {
        {
        let v311_2_depth = v309_17_cursor.path().len();
        let mut v312_4_cursor = (*v311_2_arg_3).read_zipper();
        let v312_4_origin = v312_4_cursor.path().len();
        for v312_4_byte in v312_4_cursor.child_mask().iter() {
          v312_4_cursor.descend_to_existing_byte(v312_4_byte);
          {
          let v313_2: Path = concat_path(&(*v311_2_arg_1),&v312_4_cursor.path()[v312_4_origin..(v312_4_origin + 1)]);
          let v313_3: Space = routine_36(c, &(v313_2), &v309_17_cursor.path()[v309_17_origin..v311_2_depth], &v312_4_cursor);
          drop(v313_2);
          join_wrapped_into(&mut v309_17_write,&((v313_3).read_zipper()),&[]);
          }
          v312_4_cursor.ascend(1);
        }
        drop(v312_4_cursor);
        }
        v311_2_more = next_value_within(&mut v309_17_cursor,(v309_17_origin + 1));
      }
      }
      v309_17_cursor.ascend(1);
    }
    drop(v309_17_cursor);
    drop(v309_17_write);
    let v309_18: Space = map_map_kernels::unite(&(v309_14),&(v309_17));
    map_map_kernels::compose(&(v308_8),&(v309_18))
  };
  drop(v308_8);
  let v308_21: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v308_5));
  drop(v308_5);
  let v308_22: Space = if map_kernels::has_head(&(v308_21)) { singleton(&[]) } else { Space::new() };
  drop(v308_21);
  let v308_24: Space = if (&(v308_22)).is_empty() { Space::new() } else {
    let mut v314_23 = Space::new();
    let mut v314_23_write = v314_23.write_zipper();
    let mut v314_23_cursor = (*s0).read_zipper();
    let v314_23_origin = v314_23_cursor.path().len();
    for v314_23_byte in v314_23_cursor.child_mask().iter() {
      v314_23_cursor.descend_to_existing_byte(v314_23_byte);
      {
      let v315_2: Space = routine_68(c, &v314_23_cursor.path()[v314_23_origin..(v314_23_origin + 1)], &v314_23_cursor.path()[v314_23_origin..(v314_23_origin + 1)], &(*p0), &v314_23_cursor);
      join_wrapped_into(&mut v314_23_write,&((v315_2).read_zipper()),&[]);
      }
      v314_23_cursor.ascend(1);
    }
    drop(v314_23_cursor);
    drop(v314_23_write);
    map_map_kernels::compose(&(v308_22),&(v314_23))
  };
  drop(v308_22);
  let v308_25: Space = map_map_kernels::unite(&(v308_19),&(v308_24));
  (v308_25).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v316_7 = Space::new();
  let mut v316_7_write = v316_7.write_zipper();
  let mut v316_7_cursor = (*s0).read_zipper();
  let v316_7_origin = v316_7_cursor.path().len();
  for v316_7_byte in v316_7_cursor.child_mask().iter() {
    v316_7_cursor.descend_to_existing_byte(v316_7_byte);
    {
    let v317_2: Space = singleton(&v316_7_cursor.path()[v316_7_origin..(v316_7_origin + 1)]);
    let v317_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v317_2));
    let v317_4: Space = if map_kernels::has_head(&(v317_3)) { singleton(&[]) } else { Space::new() };
    drop(v317_3);
    let v317_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v317_4));
    drop(v317_4);
    let v317_8: Space = if (&(v317_5)).is_empty() { Space::new() } else {
      let mut v318_7 = Space::new();
      let mut v318_7_write = v318_7.write_zipper();
      let v318_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v318_7_arg_1: &[u8] = &v316_7_cursor.path()[v316_7_origin..(v316_7_origin + 1)];
      let v318_7_arg_2: &[u8] = &(*p0);
      let v318_7_arg_4: &Space = &(&v316_7_cursor).make_map();
      let mut v318_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v316_7_cursor.path()[v316_7_origin..(v316_7_origin + 1)]);
      let v318_7_origin = v318_7_cursor.path().len();
      let mut v318_7_more = v318_7_cursor.is_val() || next_value_within(&mut v318_7_cursor,v318_7_origin);
      while v318_7_more {
        {
        let v318_7_depth = v318_7_cursor.path().len();
        let mut v319_5_cursor = (*v318_7_arg_4).read_zipper();
        let v319_5_origin = v319_5_cursor.path().len();
        for v319_5_byte in v319_5_cursor.child_mask().iter() {
          v319_5_cursor.descend_to_existing_byte(v319_5_byte);
          {
          let v320_2: Path = concat_path(&(*v318_7_arg_1),&v319_5_cursor.path()[v319_5_origin..(v319_5_origin + 1)]);
          let v320_3: Space = routine_68(c, &(v320_2), &v318_7_cursor.path()[v318_7_origin..v318_7_depth], &(*v318_7_arg_2), &v319_5_cursor);
          drop(v320_2);
          join_wrapped_into(&mut v318_7_write,&((v320_3).read_zipper()),&[]);
          }
          v319_5_cursor.ascend(1);
        }
        drop(v319_5_cursor);
        }
        v318_7_more = next_value_within(&mut v318_7_cursor,v318_7_origin);
      }
      drop(v318_7_cursor);
      drop(v318_7_write);
      map_map_kernels::compose(&(v317_5),&(v318_7))
    };
    drop(v317_5);
    let v317_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v317_2));
    drop(v317_2);
    let v317_10: Space = if map_kernels::has_head(&(v317_9)) { singleton(&[]) } else { Space::new() };
    drop(v317_9);
    let v317_12: Space = if (&(v317_10)).is_empty() { Space::new() } else {
      let mut v321_11 = Space::new();
      let mut v321_11_write = v321_11.write_zipper();
      for v321_11_byte in v316_7_cursor.child_mask().iter() {
        v316_7_cursor.descend_to_existing_byte(v321_11_byte);
        {
        let v322_2: Space = routine_69(c, &v316_7_cursor.path()[(v316_7_origin + 1)..(v316_7_origin + 2)], &v316_7_cursor.path()[(v316_7_origin + 1)..(v316_7_origin + 2)], &(*p0), &v316_7_cursor.path()[v316_7_origin..(v316_7_origin + 1)], &v316_7_cursor);
        join_wrapped_into(&mut v321_11_write,&((v322_2).read_zipper()),&[]);
        }
        v316_7_cursor.ascend(1);
      }
      drop(v321_11_write);
      map_map_kernels::compose(&(v317_10),&(v321_11))
    };
    drop(v317_10);
    let v317_13: Space = map_map_kernels::unite(&(v317_8),&(v317_12));
    join_wrapped_into(&mut v316_7_write,&((v317_13).read_zipper()),&[]);
    }
    v316_7_cursor.ascend(1);
  }
  drop(v316_7_cursor);
  drop(v316_7_write);
  (v316_7).clone()
}

fn routine_38(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v323_5: Space = singleton(&(*p1));
  let v323_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v323_5));
  let v323_7: Space = if map_kernels::has_head(&(v323_6)) { singleton(&[]) } else { Space::new() };
  drop(v323_6);
  let v323_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v323_7));
  drop(v323_7);
  let v323_19: Space = if (&(v323_8)).is_empty() { Space::new() } else {
    let v324_11: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v324_14: Space = if (&(v324_11)).is_empty() { Space::new() } else {
      let v325_13: Space = routine_70(c, &(*CONSTANT_1), &(*p0), &(*s0));
      map_map_kernels::compose(&(v324_11),&(v325_13))
    };
    drop(v324_11);
    let mut v324_17 = Space::new();
    let mut v324_17_write = v324_17.write_zipper();
    let mut v324_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v324_17_origin = v324_17_cursor.path().len();
    for v324_17_byte in v324_17_cursor.child_mask().iter() {
      v324_17_cursor.descend_to_existing_byte(v324_17_byte);
      {
      let v326_2_arg_0: &[u8] = &v324_17_cursor.path()[v324_17_origin..(v324_17_origin + 1)];
      let v326_2_arg_1: &[u8] = &(*p0);
      let v326_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v326_2_more = v324_17_cursor.is_val() || next_value_within(&mut v324_17_cursor,(v324_17_origin + 1));
      while v326_2_more {
        {
        let v326_2_depth = v324_17_cursor.path().len();
        let mut v327_4_cursor = (*v326_2_arg_3).read_zipper();
        let v327_4_origin = v327_4_cursor.path().len();
        for v327_4_byte in v327_4_cursor.child_mask().iter() {
          v327_4_cursor.descend_to_existing_byte(v327_4_byte);
          {
          let v328_2: Path = concat_path(&(*v326_2_arg_1),&v327_4_cursor.path()[v327_4_origin..(v327_4_origin + 1)]);
          let v328_3: Space = routine_38(c, &(v328_2), &v324_17_cursor.path()[v324_17_origin..v326_2_depth], &v327_4_cursor);
          drop(v328_2);
          join_wrapped_into(&mut v324_17_write,&((v328_3).read_zipper()),&[]);
          }
          v327_4_cursor.ascend(1);
        }
        drop(v327_4_cursor);
        }
        v326_2_more = next_value_within(&mut v324_17_cursor,(v324_17_origin + 1));
      }
      }
      v324_17_cursor.ascend(1);
    }
    drop(v324_17_cursor);
    drop(v324_17_write);
    let v324_18: Space = map_map_kernels::unite(&(v324_14),&(v324_17));
    map_map_kernels::compose(&(v323_8),&(v324_18))
  };
  drop(v323_8);
  let v323_21: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v323_5));
  drop(v323_5);
  let v323_22: Space = if map_kernels::has_head(&(v323_21)) { singleton(&[]) } else { Space::new() };
  drop(v323_21);
  let v323_24: Space = if (&(v323_22)).is_empty() { Space::new() } else {
    let mut v329_23 = Space::new();
    let mut v329_23_write = v329_23.write_zipper();
    let mut v329_23_cursor = (*s0).read_zipper();
    let v329_23_origin = v329_23_cursor.path().len();
    for v329_23_byte in v329_23_cursor.child_mask().iter() {
      v329_23_cursor.descend_to_existing_byte(v329_23_byte);
      {
      let v330_2: Space = routine_71(c, &v329_23_cursor.path()[v329_23_origin..(v329_23_origin + 1)], &v329_23_cursor.path()[v329_23_origin..(v329_23_origin + 1)], &(*p0), &v329_23_cursor);
      join_wrapped_into(&mut v329_23_write,&((v330_2).read_zipper()),&[]);
      }
      v329_23_cursor.ascend(1);
    }
    drop(v329_23_cursor);
    drop(v329_23_write);
    map_map_kernels::compose(&(v323_22),&(v329_23))
  };
  drop(v323_22);
  let v323_25: Space = map_map_kernels::unite(&(v323_19),&(v323_24));
  (v323_25).clone()
}

fn routine_39(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v331_7 = Space::new();
  let mut v331_7_write = v331_7.write_zipper();
  let mut v331_7_cursor = (*s0).read_zipper();
  let v331_7_origin = v331_7_cursor.path().len();
  for v331_7_byte in v331_7_cursor.child_mask().iter() {
    v331_7_cursor.descend_to_existing_byte(v331_7_byte);
    {
    let v332_2: Space = singleton(&v331_7_cursor.path()[v331_7_origin..(v331_7_origin + 1)]);
    let v332_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v332_2));
    let v332_4: Space = if map_kernels::has_head(&(v332_3)) { singleton(&[]) } else { Space::new() };
    drop(v332_3);
    let v332_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v332_4));
    drop(v332_4);
    let v332_8: Space = if (&(v332_5)).is_empty() { Space::new() } else {
      let mut v333_7 = Space::new();
      let mut v333_7_write = v333_7.write_zipper();
      let v333_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v333_7_arg_1: &[u8] = &v331_7_cursor.path()[v331_7_origin..(v331_7_origin + 1)];
      let v333_7_arg_2: &[u8] = &(*p0);
      let v333_7_arg_4: &Space = &(&v331_7_cursor).make_map();
      let mut v333_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v331_7_cursor.path()[v331_7_origin..(v331_7_origin + 1)]);
      let v333_7_origin = v333_7_cursor.path().len();
      let mut v333_7_more = v333_7_cursor.is_val() || next_value_within(&mut v333_7_cursor,v333_7_origin);
      while v333_7_more {
        {
        let v333_7_depth = v333_7_cursor.path().len();
        let mut v334_5_cursor = (*v333_7_arg_4).read_zipper();
        let v334_5_origin = v334_5_cursor.path().len();
        for v334_5_byte in v334_5_cursor.child_mask().iter() {
          v334_5_cursor.descend_to_existing_byte(v334_5_byte);
          {
          let v335_2: Path = concat_path(&(*v333_7_arg_1),&v334_5_cursor.path()[v334_5_origin..(v334_5_origin + 1)]);
          let v335_3: Space = routine_71(c, &(v335_2), &v333_7_cursor.path()[v333_7_origin..v333_7_depth], &(*v333_7_arg_2), &v334_5_cursor);
          drop(v335_2);
          join_wrapped_into(&mut v333_7_write,&((v335_3).read_zipper()),&[]);
          }
          v334_5_cursor.ascend(1);
        }
        drop(v334_5_cursor);
        }
        v333_7_more = next_value_within(&mut v333_7_cursor,v333_7_origin);
      }
      drop(v333_7_cursor);
      drop(v333_7_write);
      map_map_kernels::compose(&(v332_5),&(v333_7))
    };
    drop(v332_5);
    let v332_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v332_2));
    drop(v332_2);
    let v332_10: Space = if map_kernels::has_head(&(v332_9)) { singleton(&[]) } else { Space::new() };
    drop(v332_9);
    let v332_12: Space = if (&(v332_10)).is_empty() { Space::new() } else {
      let mut v336_11 = Space::new();
      let mut v336_11_write = v336_11.write_zipper();
      for v336_11_byte in v331_7_cursor.child_mask().iter() {
        v331_7_cursor.descend_to_existing_byte(v336_11_byte);
        {
        let v337_2: Space = routine_72(c, &v331_7_cursor.path()[(v331_7_origin + 1)..(v331_7_origin + 2)], &v331_7_cursor.path()[(v331_7_origin + 1)..(v331_7_origin + 2)], &(*p0), &v331_7_cursor.path()[v331_7_origin..(v331_7_origin + 1)], &v331_7_cursor);
        join_wrapped_into(&mut v336_11_write,&((v337_2).read_zipper()),&[]);
        }
        v331_7_cursor.ascend(1);
      }
      drop(v336_11_write);
      map_map_kernels::compose(&(v332_10),&(v336_11))
    };
    drop(v332_10);
    let v332_13: Space = map_map_kernels::unite(&(v332_8),&(v332_12));
    join_wrapped_into(&mut v331_7_write,&((v332_13).read_zipper()),&[]);
    }
    v331_7_cursor.ascend(1);
  }
  drop(v331_7_cursor);
  drop(v331_7_write);
  (v331_7).clone()
}

fn routine_40(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v338_6: Space = singleton(&(*p0));
  let v338_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v338_6));
  let v338_8: Space = if map_kernels::has_head(&(v338_7)) { singleton(&[]) } else { Space::new() };
  drop(v338_7);
  let v338_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v338_8));
  drop(v338_8);
  let v338_14: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v338_6));
  drop(v338_6);
  let v338_15: Space = if map_kernels::has_head(&(v338_14)) { singleton(&[]) } else { Space::new() };
  drop(v338_14);
  let mut v338_16 = Space::new();
  let mut v338_16_write = v338_16.write_zipper();
  let mut v338_16_cursor = (*s0).read_zipper();
  let v338_16_origin = v338_16_cursor.path().len();
  for v338_16_byte in v338_16_cursor.child_mask().iter() {
    v338_16_cursor.descend_to_existing_byte(v338_16_byte);
    {
    let v339_4: Space = if (&(v338_9)).is_empty() { Space::new() } else {
      let v340_2: Path = concat_path(&(*p1),&v338_16_cursor.path()[v338_16_origin..(v338_16_origin + 1)]);
      let mut v340_3 = Space::new();
      let mut v340_3_write = v340_3.write_zipper();
      let v340_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v340_3_arg_1: &[u8] = &(v340_2);
      let v340_3_arg_2: &[u8] = &(*p2);
      let v340_3_arg_4: &Space = &(&v338_16_cursor).make_map();
      let mut v340_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v340_3_origin = v340_3_cursor.path().len();
      let mut v340_3_more = v340_3_cursor.is_val() || next_value_within(&mut v340_3_cursor,v340_3_origin);
      while v340_3_more {
        {
        let v340_3_depth = v340_3_cursor.path().len();
        let v341_5: Space = routine_40(c, &v340_3_cursor.path()[v340_3_origin..v340_3_depth], &(*v340_3_arg_1), &(*v340_3_arg_2), &((*v340_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v340_3_write,&((v341_5).read_zipper()),&[]);
        }
        v340_3_more = next_value_within(&mut v340_3_cursor,v340_3_origin);
      }
      drop(v340_3_cursor);
      drop(v340_3_write);
      map_map_kernels::compose(&(v338_9),&(v340_3))
    };
    let v339_6: Space = if (&(v338_15)).is_empty() { Space::new() } else {
      let v342_2: Path = concat_path(&(*p1),&v338_16_cursor.path()[v338_16_origin..(v338_16_origin + 1)]);
      let v342_5: Space = routine_73(c, &(v342_2), &(*p2), &v338_16_cursor);
      drop(v342_2);
      map_map_kernels::compose(&(v338_15),&(v342_5))
    };
    let v339_7: Space = map_map_kernels::unite(&(v339_4),&(v339_6));
    join_wrapped_into(&mut v338_16_write,&((v339_7).read_zipper()),&[]);
    }
    v338_16_cursor.ascend(1);
  }
  drop(v338_16_cursor);
  drop(v338_16_write);
  drop(v338_9);
  drop(v338_15);
  (v338_16).clone()
}

fn routine_41(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v343_5: Space = singleton(&(*p1));
  let v343_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v343_5));
  let v343_7: Space = if map_kernels::has_head(&(v343_6)) { singleton(&[]) } else { Space::new() };
  drop(v343_6);
  let v343_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v343_7));
  drop(v343_7);
  let v343_19: Space = if (&(v343_8)).is_empty() { Space::new() } else {
    let v344_11: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v344_14: Space = if (&(v344_11)).is_empty() { Space::new() } else {
      let v345_13: Space = routine_74(c, &(*CONSTANT_1), &(*p0), &(*s0));
      map_map_kernels::compose(&(v344_11),&(v345_13))
    };
    drop(v344_11);
    let mut v344_17 = Space::new();
    let mut v344_17_write = v344_17.write_zipper();
    let mut v344_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v344_17_origin = v344_17_cursor.path().len();
    for v344_17_byte in v344_17_cursor.child_mask().iter() {
      v344_17_cursor.descend_to_existing_byte(v344_17_byte);
      {
      let v346_2_arg_0: &[u8] = &v344_17_cursor.path()[v344_17_origin..(v344_17_origin + 1)];
      let v346_2_arg_1: &[u8] = &(*p0);
      let v346_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v346_2_more = v344_17_cursor.is_val() || next_value_within(&mut v344_17_cursor,(v344_17_origin + 1));
      while v346_2_more {
        {
        let v346_2_depth = v344_17_cursor.path().len();
        let mut v347_4_cursor = (*v346_2_arg_3).read_zipper();
        let v347_4_origin = v347_4_cursor.path().len();
        for v347_4_byte in v347_4_cursor.child_mask().iter() {
          v347_4_cursor.descend_to_existing_byte(v347_4_byte);
          {
          let v348_2: Path = concat_path(&(*v346_2_arg_1),&v347_4_cursor.path()[v347_4_origin..(v347_4_origin + 1)]);
          let v348_3: Space = routine_41(c, &(v348_2), &v344_17_cursor.path()[v344_17_origin..v346_2_depth], &v347_4_cursor);
          drop(v348_2);
          join_wrapped_into(&mut v344_17_write,&((v348_3).read_zipper()),&[]);
          }
          v347_4_cursor.ascend(1);
        }
        drop(v347_4_cursor);
        }
        v346_2_more = next_value_within(&mut v344_17_cursor,(v344_17_origin + 1));
      }
      }
      v344_17_cursor.ascend(1);
    }
    drop(v344_17_cursor);
    drop(v344_17_write);
    let v344_18: Space = map_map_kernels::unite(&(v344_14),&(v344_17));
    map_map_kernels::compose(&(v343_8),&(v344_18))
  };
  drop(v343_8);
  let v343_21: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v343_5));
  drop(v343_5);
  let v343_22: Space = if map_kernels::has_head(&(v343_21)) { singleton(&[]) } else { Space::new() };
  drop(v343_21);
  let v343_24: Space = if (&(v343_22)).is_empty() { Space::new() } else {
    let mut v349_23 = Space::new();
    let mut v349_23_write = v349_23.write_zipper();
    let mut v349_23_cursor = (*s0).read_zipper();
    let v349_23_origin = v349_23_cursor.path().len();
    for v349_23_byte in v349_23_cursor.child_mask().iter() {
      v349_23_cursor.descend_to_existing_byte(v349_23_byte);
      {
      let v350_2: Space = routine_75(c, &v349_23_cursor.path()[v349_23_origin..(v349_23_origin + 1)], &v349_23_cursor.path()[v349_23_origin..(v349_23_origin + 1)], &(*p0), &v349_23_cursor);
      join_wrapped_into(&mut v349_23_write,&((v350_2).read_zipper()),&[]);
      }
      v349_23_cursor.ascend(1);
    }
    drop(v349_23_cursor);
    drop(v349_23_write);
    map_map_kernels::compose(&(v343_22),&(v349_23))
  };
  drop(v343_22);
  let v343_25: Space = map_map_kernels::unite(&(v343_19),&(v343_24));
  (v343_25).clone()
}

fn routine_42(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v351_7: Space = singleton(&(*p1));
  let v351_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v351_7));
  let v351_9: Space = if map_kernels::has_head(&(v351_8)) { singleton(&[]) } else { Space::new() };
  drop(v351_8);
  let v351_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v351_9));
  drop(v351_9);
  let v351_21: Space = if (&(v351_10)).is_empty() { Space::new() } else {
    let v352_13: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v352_16: Space = if (&(v352_13)).is_empty() { Space::new() } else {
      let v353_15: Space = routine_76(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0), &(*s1));
      map_map_kernels::compose(&(v352_13),&(v353_15))
    };
    drop(v352_13);
    let mut v352_19 = Space::new();
    let mut v352_19_write = v352_19.write_zipper();
    let mut v352_19_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v352_19_origin = v352_19_cursor.path().len();
    for v352_19_byte in v352_19_cursor.child_mask().iter() {
      v352_19_cursor.descend_to_existing_byte(v352_19_byte);
      {
      let v354_2_arg_0: &[u8] = &v352_19_cursor.path()[v352_19_origin..(v352_19_origin + 1)];
      let v354_2_arg_1: &[u8] = &(*p0);
      let v354_2_arg_2: &[u8] = &(*p2);
      let v354_2_arg_4: &Space = &(&(*s0)).make_map();
      let v354_2_arg_5: &Space = &(&(*s1)).make_map();
      let mut v354_2_more = v352_19_cursor.is_val() || next_value_within(&mut v352_19_cursor,(v352_19_origin + 1));
      while v354_2_more {
        {
        let v354_2_depth = v352_19_cursor.path().len();
        let mut v355_6_cursor = (*v354_2_arg_4).read_zipper();
        let v355_6_origin = v355_6_cursor.path().len();
        for v355_6_byte in v355_6_cursor.child_mask().iter() {
          v355_6_cursor.descend_to_existing_byte(v355_6_byte);
          {
          let v356_2: Path = concat_path(&(*v354_2_arg_1),&v355_6_cursor.path()[v355_6_origin..(v355_6_origin + 1)]);
          let v356_3: Space = routine_42(c, &(v356_2), &v352_19_cursor.path()[v352_19_origin..v354_2_depth], &(*v354_2_arg_2), &v355_6_cursor, &((*v354_2_arg_5).read_zipper()));
          drop(v356_2);
          join_wrapped_into(&mut v352_19_write,&((v356_3).read_zipper()),&[]);
          }
          v355_6_cursor.ascend(1);
        }
        drop(v355_6_cursor);
        }
        v354_2_more = next_value_within(&mut v352_19_cursor,(v352_19_origin + 1));
      }
      }
      v352_19_cursor.ascend(1);
    }
    drop(v352_19_cursor);
    drop(v352_19_write);
    let v352_20: Space = map_map_kernels::unite(&(v352_16),&(v352_19));
    map_map_kernels::compose(&(v351_10),&(v352_20))
  };
  drop(v351_10);
  let v351_23: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v351_7));
  drop(v351_7);
  let v351_24: Space = if map_kernels::has_head(&(v351_23)) { singleton(&[]) } else { Space::new() };
  drop(v351_23);
  let v351_28: Space = if (&(v351_24)).is_empty() { Space::new() } else {
    let v357_26: Space = view_kernels::wrap(&(descend_cursor((*s0).read_zipper(),&(*p2))),&(*p0));
    let v357_27: Space = if (&(v357_26)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v357_26),&(*s1))
    };
    drop(v357_26);
    map_map_kernels::compose(&(v351_24),&(v357_27))
  };
  drop(v351_24);
  let v351_29: Space = map_map_kernels::unite(&(v351_21),&(v351_28));
  drop(v351_28);
  (v351_29).clone()
}

fn routine_43(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v359_6: Space = singleton(&(*p0));
  let v359_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v359_6));
  let v359_8: Space = if map_kernels::has_head(&(v359_7)) { singleton(&[]) } else { Space::new() };
  drop(v359_7);
  let v359_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v359_8));
  drop(v359_8);
  let v359_14: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v359_6));
  drop(v359_6);
  let v359_15: Space = if map_kernels::has_head(&(v359_14)) { singleton(&[]) } else { Space::new() };
  drop(v359_14);
  let mut v359_16 = Space::new();
  let mut v359_16_write = v359_16.write_zipper();
  let mut v359_16_cursor = (*s0).read_zipper();
  let v359_16_origin = v359_16_cursor.path().len();
  for v359_16_byte in v359_16_cursor.child_mask().iter() {
    v359_16_cursor.descend_to_existing_byte(v359_16_byte);
    {
    let v360_4: Space = if (&(v359_9)).is_empty() { Space::new() } else {
      let v361_2: Path = concat_path(&(*p1),&v359_16_cursor.path()[v359_16_origin..(v359_16_origin + 1)]);
      let mut v361_3 = Space::new();
      let mut v361_3_write = v361_3.write_zipper();
      let v361_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v361_3_arg_1: &[u8] = &(v361_2);
      let v361_3_arg_2: &[u8] = &(*p2);
      let v361_3_arg_4: &Space = &(&v359_16_cursor).make_map();
      let mut v361_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v361_3_origin = v361_3_cursor.path().len();
      let mut v361_3_more = v361_3_cursor.is_val() || next_value_within(&mut v361_3_cursor,v361_3_origin);
      while v361_3_more {
        {
        let v361_3_depth = v361_3_cursor.path().len();
        let v362_5: Space = routine_43(c, &v361_3_cursor.path()[v361_3_origin..v361_3_depth], &(*v361_3_arg_1), &(*v361_3_arg_2), &((*v361_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v361_3_write,&((v362_5).read_zipper()),&[]);
        }
        v361_3_more = next_value_within(&mut v361_3_cursor,v361_3_origin);
      }
      drop(v361_3_cursor);
      drop(v361_3_write);
      map_map_kernels::compose(&(v359_9),&(v361_3))
    };
    let v360_6: Space = if (&(v359_15)).is_empty() { Space::new() } else {
      let v363_2: Path = concat_path(&(*p1),&v359_16_cursor.path()[v359_16_origin..(v359_16_origin + 1)]);
      let v363_5: Space = routine_77(c, &(v363_2), &(*p2), &v359_16_cursor);
      drop(v363_2);
      map_map_kernels::compose(&(v359_15),&(v363_5))
    };
    let v360_7: Space = map_map_kernels::unite(&(v360_4),&(v360_6));
    join_wrapped_into(&mut v359_16_write,&((v360_7).read_zipper()),&[]);
    }
    v359_16_cursor.ascend(1);
  }
  drop(v359_16_cursor);
  drop(v359_16_write);
  drop(v359_9);
  drop(v359_15);
  (v359_16).clone()
}

fn routine_44(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v364_5: Space = singleton(&(*p1));
  let v364_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v364_5));
  let v364_7: Space = if map_kernels::has_head(&(v364_6)) { singleton(&[]) } else { Space::new() };
  drop(v364_6);
  let v364_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v364_7));
  drop(v364_7);
  let v364_19: Space = if (&(v364_8)).is_empty() { Space::new() } else {
    let v365_11: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v365_14: Space = if (&(v365_11)).is_empty() { Space::new() } else {
      let v366_13: Space = routine_78(c, &(*CONSTANT_1), &(*p0), &(*s0));
      map_map_kernels::compose(&(v365_11),&(v366_13))
    };
    drop(v365_11);
    let mut v365_17 = Space::new();
    let mut v365_17_write = v365_17.write_zipper();
    let mut v365_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v365_17_origin = v365_17_cursor.path().len();
    for v365_17_byte in v365_17_cursor.child_mask().iter() {
      v365_17_cursor.descend_to_existing_byte(v365_17_byte);
      {
      let v367_2_arg_0: &[u8] = &v365_17_cursor.path()[v365_17_origin..(v365_17_origin + 1)];
      let v367_2_arg_1: &[u8] = &(*p0);
      let v367_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v367_2_more = v365_17_cursor.is_val() || next_value_within(&mut v365_17_cursor,(v365_17_origin + 1));
      while v367_2_more {
        {
        let v367_2_depth = v365_17_cursor.path().len();
        let mut v368_4_cursor = (*v367_2_arg_3).read_zipper();
        let v368_4_origin = v368_4_cursor.path().len();
        for v368_4_byte in v368_4_cursor.child_mask().iter() {
          v368_4_cursor.descend_to_existing_byte(v368_4_byte);
          {
          let v369_2: Path = concat_path(&(*v367_2_arg_1),&v368_4_cursor.path()[v368_4_origin..(v368_4_origin + 1)]);
          let v369_3: Space = routine_44(c, &(v369_2), &v365_17_cursor.path()[v365_17_origin..v367_2_depth], &v368_4_cursor);
          drop(v369_2);
          join_wrapped_into(&mut v365_17_write,&((v369_3).read_zipper()),&[]);
          }
          v368_4_cursor.ascend(1);
        }
        drop(v368_4_cursor);
        }
        v367_2_more = next_value_within(&mut v365_17_cursor,(v365_17_origin + 1));
      }
      }
      v365_17_cursor.ascend(1);
    }
    drop(v365_17_cursor);
    drop(v365_17_write);
    let v365_18: Space = map_map_kernels::unite(&(v365_14),&(v365_17));
    map_map_kernels::compose(&(v364_8),&(v365_18))
  };
  drop(v364_8);
  let v364_21: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v364_5));
  drop(v364_5);
  let v364_22: Space = if map_kernels::has_head(&(v364_21)) { singleton(&[]) } else { Space::new() };
  drop(v364_21);
  let v364_24: Space = if (&(v364_22)).is_empty() { Space::new() } else {
    let mut v370_23 = Space::new();
    let mut v370_23_write = v370_23.write_zipper();
    let mut v370_23_cursor = (*s0).read_zipper();
    let v370_23_origin = v370_23_cursor.path().len();
    for v370_23_byte in v370_23_cursor.child_mask().iter() {
      v370_23_cursor.descend_to_existing_byte(v370_23_byte);
      {
      let v371_2: Space = routine_79(c, &v370_23_cursor.path()[v370_23_origin..(v370_23_origin + 1)], &v370_23_cursor.path()[v370_23_origin..(v370_23_origin + 1)], &(*p0), &v370_23_cursor);
      join_wrapped_into(&mut v370_23_write,&((v371_2).read_zipper()),&[]);
      }
      v370_23_cursor.ascend(1);
    }
    drop(v370_23_cursor);
    drop(v370_23_write);
    map_map_kernels::compose(&(v364_22),&(v370_23))
  };
  drop(v364_22);
  let v364_25: Space = map_map_kernels::unite(&(v364_19),&(v364_24));
  (v364_25).clone()
}

fn routine_45(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v372_6: Space = singleton(&(*p1));
  let v372_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v372_6));
  let v372_8: Space = if map_kernels::has_head(&(v372_7)) { singleton(&[]) } else { Space::new() };
  drop(v372_7);
  let v372_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v372_8));
  drop(v372_8);
  let v372_20: Space = if (&(v372_9)).is_empty() { Space::new() } else {
    let v373_12: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v373_15: Space = if (&(v373_12)).is_empty() { Space::new() } else {
      let v374_14: Space = routine_80(c, &(*CONSTANT_1), &(*p0), &(*s0), &(*s1));
      map_map_kernels::compose(&(v373_12),&(v374_14))
    };
    drop(v373_12);
    let mut v373_18 = Space::new();
    let mut v373_18_write = v373_18.write_zipper();
    let mut v373_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v373_18_origin = v373_18_cursor.path().len();
    for v373_18_byte in v373_18_cursor.child_mask().iter() {
      v373_18_cursor.descend_to_existing_byte(v373_18_byte);
      {
      let v375_2_arg_0: &[u8] = &v373_18_cursor.path()[v373_18_origin..(v373_18_origin + 1)];
      let v375_2_arg_1: &[u8] = &(*p0);
      let v375_2_arg_3: &Space = &(&(*s0)).make_map();
      let v375_2_arg_4: &Space = &(&(*s1)).make_map();
      let mut v375_2_more = v373_18_cursor.is_val() || next_value_within(&mut v373_18_cursor,(v373_18_origin + 1));
      while v375_2_more {
        {
        let v375_2_depth = v373_18_cursor.path().len();
        let mut v376_5_cursor = (*v375_2_arg_3).read_zipper();
        let v376_5_origin = v376_5_cursor.path().len();
        for v376_5_byte in v376_5_cursor.child_mask().iter() {
          v376_5_cursor.descend_to_existing_byte(v376_5_byte);
          {
          let v377_2: Path = concat_path(&(*v375_2_arg_1),&v376_5_cursor.path()[v376_5_origin..(v376_5_origin + 1)]);
          let v377_3: Space = routine_45(c, &(v377_2), &v373_18_cursor.path()[v373_18_origin..v375_2_depth], &v376_5_cursor, &((*v375_2_arg_4).read_zipper()));
          drop(v377_2);
          join_wrapped_into(&mut v373_18_write,&((v377_3).read_zipper()),&[]);
          }
          v376_5_cursor.ascend(1);
        }
        drop(v376_5_cursor);
        }
        v375_2_more = next_value_within(&mut v373_18_cursor,(v373_18_origin + 1));
      }
      }
      v373_18_cursor.ascend(1);
    }
    drop(v373_18_cursor);
    drop(v373_18_write);
    let v373_19: Space = map_map_kernels::unite(&(v373_15),&(v373_18));
    map_map_kernels::compose(&(v372_9),&(v373_19))
  };
  drop(v372_9);
  let v372_22: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v372_6));
  drop(v372_6);
  let v372_23: Space = if map_kernels::has_head(&(v372_22)) { singleton(&[]) } else { Space::new() };
  drop(v372_22);
  let v372_25: Space = if (&(v372_23)).is_empty() { Space::new() } else {
    let v378_24: Space = routine_81(c, &(*p0), &(*s1));
    map_map_kernels::compose(&(v372_23),&(v378_24))
  };
  drop(v372_23);
  let v372_26: Space = map_map_kernels::unite(&(v372_20),&(v372_25));
  (v372_26).clone()
}

fn routine_46(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v379_5: Space = singleton(&(*p0));
  let v379_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v379_5));
  let v379_7: Space = if map_kernels::has_head(&(v379_6)) { singleton(&[]) } else { Space::new() };
  drop(v379_6);
  let v379_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v379_7));
  drop(v379_7);
  let v379_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v379_5));
  drop(v379_5);
  let v379_14: Space = if map_kernels::has_head(&(v379_13)) { singleton(&[]) } else { Space::new() };
  drop(v379_13);
  let mut v379_15 = Space::new();
  let mut v379_15_write = v379_15.write_zipper();
  let mut v379_15_cursor = (*s0).read_zipper();
  let v379_15_origin = v379_15_cursor.path().len();
  for v379_15_byte in v379_15_cursor.child_mask().iter() {
    v379_15_cursor.descend_to_existing_byte(v379_15_byte);
    {
    let v380_4: Space = if (&(v379_8)).is_empty() { Space::new() } else {
      let v381_2: Path = concat_path(&(*p1),&v379_15_cursor.path()[v379_15_origin..(v379_15_origin + 1)]);
      let mut v381_3 = Space::new();
      let mut v381_3_write = v381_3.write_zipper();
      let v381_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v381_3_arg_1: &[u8] = &(v381_2);
      let v381_3_arg_3: &Space = &(&v379_15_cursor).make_map();
      let mut v381_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v381_3_origin = v381_3_cursor.path().len();
      let mut v381_3_more = v381_3_cursor.is_val() || next_value_within(&mut v381_3_cursor,v381_3_origin);
      while v381_3_more {
        {
        let v381_3_depth = v381_3_cursor.path().len();
        let v382_4: Space = routine_46(c, &v381_3_cursor.path()[v381_3_origin..v381_3_depth], &(*v381_3_arg_1), &((*v381_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v381_3_write,&((v382_4).read_zipper()),&[]);
        }
        v381_3_more = next_value_within(&mut v381_3_cursor,v381_3_origin);
      }
      drop(v381_3_cursor);
      drop(v381_3_write);
      map_map_kernels::compose(&(v379_8),&(v381_3))
    };
    let v380_6: Space = if (&(v379_14)).is_empty() { Space::new() } else {
      let v383_2: Path = concat_path(&(*p1),&v379_15_cursor.path()[v379_15_origin..(v379_15_origin + 1)]);
      let mut v383_5 = Space::new();
      let mut v383_5_write = v383_5.write_zipper();
      for v383_5_byte in v379_15_cursor.child_mask().iter() {
        v379_15_cursor.descend_to_existing_byte(v383_5_byte);
        {
        let v384_2: Space = routine_47(c, &v379_15_cursor.path()[(v379_15_origin + 1)..(v379_15_origin + 2)], &v379_15_cursor.path()[(v379_15_origin + 1)..(v379_15_origin + 2)], &(v383_2), &v379_15_cursor);
        join_wrapped_into(&mut v383_5_write,&((v384_2).read_zipper()),&[]);
        }
        v379_15_cursor.ascend(1);
      }
      drop(v383_5_write);
      drop(v383_2);
      map_map_kernels::compose(&(v379_14),&(v383_5))
    };
    let v380_7: Space = map_map_kernels::unite(&(v380_4),&(v380_6));
    join_wrapped_into(&mut v379_15_write,&((v380_7).read_zipper()),&[]);
    }
    v379_15_cursor.ascend(1);
  }
  drop(v379_15_cursor);
  drop(v379_15_write);
  drop(v379_8);
  drop(v379_14);
  (v379_15).clone()
}

fn routine_47(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v385_6: Space = singleton(&(*p1));
  let v385_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v385_6));
  let v385_8: Space = if map_kernels::has_head(&(v385_7)) { singleton(&[]) } else { Space::new() };
  drop(v385_7);
  let v385_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v385_8));
  drop(v385_8);
  let v385_20: Space = if (&(v385_9)).is_empty() { Space::new() } else {
    let v386_12: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v386_15: Space = if (&(v386_12)).is_empty() { Space::new() } else {
      let v387_14: Space = routine_82(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      map_map_kernels::compose(&(v386_12),&(v387_14))
    };
    drop(v386_12);
    let mut v386_18 = Space::new();
    let mut v386_18_write = v386_18.write_zipper();
    let mut v386_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v386_18_origin = v386_18_cursor.path().len();
    for v386_18_byte in v386_18_cursor.child_mask().iter() {
      v386_18_cursor.descend_to_existing_byte(v386_18_byte);
      {
      let v388_2_arg_0: &[u8] = &v386_18_cursor.path()[v386_18_origin..(v386_18_origin + 1)];
      let v388_2_arg_1: &[u8] = &(*p0);
      let v388_2_arg_2: &[u8] = &(*p2);
      let v388_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v388_2_more = v386_18_cursor.is_val() || next_value_within(&mut v386_18_cursor,(v386_18_origin + 1));
      while v388_2_more {
        {
        let v388_2_depth = v386_18_cursor.path().len();
        let mut v389_5_cursor = (*v388_2_arg_4).read_zipper();
        let v389_5_origin = v389_5_cursor.path().len();
        for v389_5_byte in v389_5_cursor.child_mask().iter() {
          v389_5_cursor.descend_to_existing_byte(v389_5_byte);
          {
          let v390_2: Path = concat_path(&(*v388_2_arg_1),&v389_5_cursor.path()[v389_5_origin..(v389_5_origin + 1)]);
          let v390_3: Space = routine_47(c, &(v390_2), &v386_18_cursor.path()[v386_18_origin..v388_2_depth], &(*v388_2_arg_2), &v389_5_cursor);
          drop(v390_2);
          join_wrapped_into(&mut v386_18_write,&((v390_3).read_zipper()),&[]);
          }
          v389_5_cursor.ascend(1);
        }
        drop(v389_5_cursor);
        }
        v388_2_more = next_value_within(&mut v386_18_cursor,(v386_18_origin + 1));
      }
      }
      v386_18_cursor.ascend(1);
    }
    drop(v386_18_cursor);
    drop(v386_18_write);
    let v386_19: Space = map_map_kernels::unite(&(v386_15),&(v386_18));
    map_map_kernels::compose(&(v385_9),&(v386_19))
  };
  drop(v385_9);
  let v385_22: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v385_6));
  drop(v385_6);
  let v385_23: Space = if map_kernels::has_head(&(v385_22)) { singleton(&[]) } else { Space::new() };
  drop(v385_22);
  let v385_25: Space = if (&(v385_23)).is_empty() { Space::new() } else {
    let mut v391_24 = Space::new();
    let mut v391_24_write = v391_24.write_zipper();
    let mut v391_24_cursor = (*s0).read_zipper();
    let v391_24_origin = v391_24_cursor.path().len();
    for v391_24_byte in v391_24_cursor.child_mask().iter() {
      v391_24_cursor.descend_to_existing_byte(v391_24_byte);
      {
      let v392_2: Space = routine_48(c, &v391_24_cursor.path()[v391_24_origin..(v391_24_origin + 1)], &v391_24_cursor.path()[v391_24_origin..(v391_24_origin + 1)], &(*p2), &(*p0), &v391_24_cursor);
      join_wrapped_into(&mut v391_24_write,&((v392_2).read_zipper()),&[]);
      }
      v391_24_cursor.ascend(1);
    }
    drop(v391_24_cursor);
    drop(v391_24_write);
    map_map_kernels::compose(&(v385_23),&(v391_24))
  };
  drop(v385_23);
  let v385_26: Space = map_map_kernels::unite(&(v385_20),&(v385_25));
  (v385_26).clone()
}

fn routine_48(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v393_7: Space = singleton(&(*p1));
  let v393_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v393_7));
  let v393_9: Space = if map_kernels::has_head(&(v393_8)) { singleton(&[]) } else { Space::new() };
  drop(v393_8);
  let v393_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v393_9));
  drop(v393_9);
  let v393_21: Space = if (&(v393_10)).is_empty() { Space::new() } else {
    let v394_13: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v394_16: Space = if (&(v394_13)).is_empty() { Space::new() } else {
      let v395_15: Space = routine_83(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      map_map_kernels::compose(&(v394_13),&(v395_15))
    };
    drop(v394_13);
    let mut v394_19 = Space::new();
    let mut v394_19_write = v394_19.write_zipper();
    let mut v394_19_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v394_19_origin = v394_19_cursor.path().len();
    for v394_19_byte in v394_19_cursor.child_mask().iter() {
      v394_19_cursor.descend_to_existing_byte(v394_19_byte);
      {
      let v396_2_arg_0: &[u8] = &v394_19_cursor.path()[v394_19_origin..(v394_19_origin + 1)];
      let v396_2_arg_1: &[u8] = &(*p0);
      let v396_2_arg_2: &[u8] = &(*p2);
      let v396_2_arg_3: &[u8] = &(*p3);
      let v396_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v396_2_more = v394_19_cursor.is_val() || next_value_within(&mut v394_19_cursor,(v394_19_origin + 1));
      while v396_2_more {
        {
        let v396_2_depth = v394_19_cursor.path().len();
        let mut v397_6_cursor = (*v396_2_arg_5).read_zipper();
        let v397_6_origin = v397_6_cursor.path().len();
        for v397_6_byte in v397_6_cursor.child_mask().iter() {
          v397_6_cursor.descend_to_existing_byte(v397_6_byte);
          {
          let v398_2: Path = concat_path(&(*v396_2_arg_1),&v397_6_cursor.path()[v397_6_origin..(v397_6_origin + 1)]);
          let v398_3: Space = routine_48(c, &(v398_2), &v394_19_cursor.path()[v394_19_origin..v396_2_depth], &(*v396_2_arg_2), &(*v396_2_arg_3), &v397_6_cursor);
          drop(v398_2);
          join_wrapped_into(&mut v394_19_write,&((v398_3).read_zipper()),&[]);
          }
          v397_6_cursor.ascend(1);
        }
        drop(v397_6_cursor);
        }
        v396_2_more = next_value_within(&mut v394_19_cursor,(v394_19_origin + 1));
      }
      }
      v394_19_cursor.ascend(1);
    }
    drop(v394_19_cursor);
    drop(v394_19_write);
    let v394_20: Space = map_map_kernels::unite(&(v394_16),&(v394_19));
    map_map_kernels::compose(&(v393_10),&(v394_20))
  };
  drop(v393_10);
  let v393_23: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v393_7));
  drop(v393_7);
  let v393_24: Space = if map_kernels::has_head(&(v393_23)) { singleton(&[]) } else { Space::new() };
  drop(v393_23);
  let v393_26: Space = if (&(v393_24)).is_empty() { Space::new() } else {
    let mut v399_25 = Space::new();
    let mut v399_25_write = v399_25.write_zipper();
    let mut v399_25_cursor = (*s0).read_zipper();
    let v399_25_origin = v399_25_cursor.path().len();
    for v399_25_byte in v399_25_cursor.child_mask().iter() {
      v399_25_cursor.descend_to_existing_byte(v399_25_byte);
      {
      let v400_2: Space = routine_84(c, &v399_25_cursor.path()[v399_25_origin..(v399_25_origin + 1)], &v399_25_cursor.path()[v399_25_origin..(v399_25_origin + 1)], &(*p2), &(*p3), &(*p0), &v399_25_cursor);
      join_wrapped_into(&mut v399_25_write,&((v400_2).read_zipper()),&[]);
      }
      v399_25_cursor.ascend(1);
    }
    drop(v399_25_cursor);
    drop(v399_25_write);
    map_map_kernels::compose(&(v393_24),&(v399_25))
  };
  drop(v393_24);
  let v393_27: Space = map_map_kernels::unite(&(v393_21),&(v393_26));
  (v393_27).clone()
}

fn routine_49(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v401_5: Space = singleton(&(*p0));
  let v401_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v401_5));
  let v401_7: Space = if map_kernels::has_head(&(v401_6)) { singleton(&[]) } else { Space::new() };
  drop(v401_6);
  let v401_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v401_7));
  drop(v401_7);
  let v401_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v401_5));
  drop(v401_5);
  let v401_14: Space = if map_kernels::has_head(&(v401_13)) { singleton(&[]) } else { Space::new() };
  drop(v401_13);
  let mut v401_15 = Space::new();
  let mut v401_15_write = v401_15.write_zipper();
  let mut v401_15_cursor = (*s0).read_zipper();
  let v401_15_origin = v401_15_cursor.path().len();
  for v401_15_byte in v401_15_cursor.child_mask().iter() {
    v401_15_cursor.descend_to_existing_byte(v401_15_byte);
    {
    let v402_4: Space = if (&(v401_8)).is_empty() { Space::new() } else {
      let v403_2: Path = concat_path(&(*p1),&v401_15_cursor.path()[v401_15_origin..(v401_15_origin + 1)]);
      let mut v403_3 = Space::new();
      let mut v403_3_write = v403_3.write_zipper();
      let v403_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v403_3_arg_1: &[u8] = &(v403_2);
      let v403_3_arg_3: &Space = &(&v401_15_cursor).make_map();
      let mut v403_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v403_3_origin = v403_3_cursor.path().len();
      let mut v403_3_more = v403_3_cursor.is_val() || next_value_within(&mut v403_3_cursor,v403_3_origin);
      while v403_3_more {
        {
        let v403_3_depth = v403_3_cursor.path().len();
        let v404_4: Space = routine_49(c, &v403_3_cursor.path()[v403_3_origin..v403_3_depth], &(*v403_3_arg_1), &((*v403_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v403_3_write,&((v404_4).read_zipper()),&[]);
        }
        v403_3_more = next_value_within(&mut v403_3_cursor,v403_3_origin);
      }
      drop(v403_3_cursor);
      drop(v403_3_write);
      map_map_kernels::compose(&(v401_8),&(v403_3))
    };
    let v402_6: Space = if (&(v401_14)).is_empty() { Space::new() } else {
      let v405_2: Path = concat_path(&(*p1),&v401_15_cursor.path()[v401_15_origin..(v401_15_origin + 1)]);
      let mut v405_5 = Space::new();
      let mut v405_5_write = v405_5.write_zipper();
      for v405_5_byte in v401_15_cursor.child_mask().iter() {
        v401_15_cursor.descend_to_existing_byte(v405_5_byte);
        {
        let v406_2: Space = routine_50(c, &v401_15_cursor.path()[(v401_15_origin + 1)..(v401_15_origin + 2)], &v401_15_cursor.path()[(v401_15_origin + 1)..(v401_15_origin + 2)], &(v405_2), &v401_15_cursor);
        join_wrapped_into(&mut v405_5_write,&((v406_2).read_zipper()),&[]);
        }
        v401_15_cursor.ascend(1);
      }
      drop(v405_5_write);
      drop(v405_2);
      map_map_kernels::compose(&(v401_14),&(v405_5))
    };
    let v402_7: Space = map_map_kernels::unite(&(v402_4),&(v402_6));
    join_wrapped_into(&mut v401_15_write,&((v402_7).read_zipper()),&[]);
    }
    v401_15_cursor.ascend(1);
  }
  drop(v401_15_cursor);
  drop(v401_15_write);
  drop(v401_8);
  drop(v401_14);
  (v401_15).clone()
}

fn routine_50(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v407_6: Space = singleton(&(*p1));
  let v407_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v407_6));
  let v407_8: Space = if map_kernels::has_head(&(v407_7)) { singleton(&[]) } else { Space::new() };
  drop(v407_7);
  let v407_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v407_8));
  drop(v407_8);
  let v407_20: Space = if (&(v407_9)).is_empty() { Space::new() } else {
    let v408_12: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v408_15: Space = if (&(v408_12)).is_empty() { Space::new() } else {
      let v409_14: Space = routine_85(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      map_map_kernels::compose(&(v408_12),&(v409_14))
    };
    drop(v408_12);
    let mut v408_18 = Space::new();
    let mut v408_18_write = v408_18.write_zipper();
    let mut v408_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v408_18_origin = v408_18_cursor.path().len();
    for v408_18_byte in v408_18_cursor.child_mask().iter() {
      v408_18_cursor.descend_to_existing_byte(v408_18_byte);
      {
      let v410_2_arg_0: &[u8] = &v408_18_cursor.path()[v408_18_origin..(v408_18_origin + 1)];
      let v410_2_arg_1: &[u8] = &(*p0);
      let v410_2_arg_2: &[u8] = &(*p2);
      let v410_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v410_2_more = v408_18_cursor.is_val() || next_value_within(&mut v408_18_cursor,(v408_18_origin + 1));
      while v410_2_more {
        {
        let v410_2_depth = v408_18_cursor.path().len();
        let mut v411_5_cursor = (*v410_2_arg_4).read_zipper();
        let v411_5_origin = v411_5_cursor.path().len();
        for v411_5_byte in v411_5_cursor.child_mask().iter() {
          v411_5_cursor.descend_to_existing_byte(v411_5_byte);
          {
          let v412_2: Path = concat_path(&(*v410_2_arg_1),&v411_5_cursor.path()[v411_5_origin..(v411_5_origin + 1)]);
          let v412_3: Space = routine_50(c, &(v412_2), &v408_18_cursor.path()[v408_18_origin..v410_2_depth], &(*v410_2_arg_2), &v411_5_cursor);
          drop(v412_2);
          join_wrapped_into(&mut v408_18_write,&((v412_3).read_zipper()),&[]);
          }
          v411_5_cursor.ascend(1);
        }
        drop(v411_5_cursor);
        }
        v410_2_more = next_value_within(&mut v408_18_cursor,(v408_18_origin + 1));
      }
      }
      v408_18_cursor.ascend(1);
    }
    drop(v408_18_cursor);
    drop(v408_18_write);
    let v408_19: Space = map_map_kernels::unite(&(v408_15),&(v408_18));
    map_map_kernels::compose(&(v407_9),&(v408_19))
  };
  drop(v407_9);
  let v407_22: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v407_6));
  drop(v407_6);
  let v407_23: Space = if map_kernels::has_head(&(v407_22)) { singleton(&[]) } else { Space::new() };
  drop(v407_22);
  let v407_25: Space = if (&(v407_23)).is_empty() { Space::new() } else {
    let mut v413_24 = Space::new();
    let mut v413_24_write = v413_24.write_zipper();
    let mut v413_24_cursor = (*s0).read_zipper();
    let v413_24_origin = v413_24_cursor.path().len();
    for v413_24_byte in v413_24_cursor.child_mask().iter() {
      v413_24_cursor.descend_to_existing_byte(v413_24_byte);
      {
      let v414_2: Space = routine_51(c, &v413_24_cursor.path()[v413_24_origin..(v413_24_origin + 1)], &v413_24_cursor.path()[v413_24_origin..(v413_24_origin + 1)], &(*p2), &(*p0), &v413_24_cursor);
      join_wrapped_into(&mut v413_24_write,&((v414_2).read_zipper()),&[]);
      }
      v413_24_cursor.ascend(1);
    }
    drop(v413_24_cursor);
    drop(v413_24_write);
    map_map_kernels::compose(&(v407_23),&(v413_24))
  };
  drop(v407_23);
  let v407_26: Space = map_map_kernels::unite(&(v407_20),&(v407_25));
  (v407_26).clone()
}

fn routine_51(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v415_7: Space = singleton(&(*p1));
  let v415_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v415_7));
  let v415_9: Space = if map_kernels::has_head(&(v415_8)) { singleton(&[]) } else { Space::new() };
  drop(v415_8);
  let v415_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v415_9));
  drop(v415_9);
  let v415_21: Space = if (&(v415_10)).is_empty() { Space::new() } else {
    let v416_13: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v416_16: Space = if (&(v416_13)).is_empty() { Space::new() } else {
      let v417_15: Space = routine_86(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      map_map_kernels::compose(&(v416_13),&(v417_15))
    };
    drop(v416_13);
    let mut v416_19 = Space::new();
    let mut v416_19_write = v416_19.write_zipper();
    let mut v416_19_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v416_19_origin = v416_19_cursor.path().len();
    for v416_19_byte in v416_19_cursor.child_mask().iter() {
      v416_19_cursor.descend_to_existing_byte(v416_19_byte);
      {
      let v418_2_arg_0: &[u8] = &v416_19_cursor.path()[v416_19_origin..(v416_19_origin + 1)];
      let v418_2_arg_1: &[u8] = &(*p0);
      let v418_2_arg_2: &[u8] = &(*p2);
      let v418_2_arg_3: &[u8] = &(*p3);
      let v418_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v418_2_more = v416_19_cursor.is_val() || next_value_within(&mut v416_19_cursor,(v416_19_origin + 1));
      while v418_2_more {
        {
        let v418_2_depth = v416_19_cursor.path().len();
        let mut v419_6_cursor = (*v418_2_arg_5).read_zipper();
        let v419_6_origin = v419_6_cursor.path().len();
        for v419_6_byte in v419_6_cursor.child_mask().iter() {
          v419_6_cursor.descend_to_existing_byte(v419_6_byte);
          {
          let v420_2: Path = concat_path(&(*v418_2_arg_1),&v419_6_cursor.path()[v419_6_origin..(v419_6_origin + 1)]);
          let v420_3: Space = routine_51(c, &(v420_2), &v416_19_cursor.path()[v416_19_origin..v418_2_depth], &(*v418_2_arg_2), &(*v418_2_arg_3), &v419_6_cursor);
          drop(v420_2);
          join_wrapped_into(&mut v416_19_write,&((v420_3).read_zipper()),&[]);
          }
          v419_6_cursor.ascend(1);
        }
        drop(v419_6_cursor);
        }
        v418_2_more = next_value_within(&mut v416_19_cursor,(v416_19_origin + 1));
      }
      }
      v416_19_cursor.ascend(1);
    }
    drop(v416_19_cursor);
    drop(v416_19_write);
    let v416_20: Space = map_map_kernels::unite(&(v416_16),&(v416_19));
    map_map_kernels::compose(&(v415_10),&(v416_20))
  };
  drop(v415_10);
  let v415_23: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v415_7));
  drop(v415_7);
  let v415_24: Space = if map_kernels::has_head(&(v415_23)) { singleton(&[]) } else { Space::new() };
  drop(v415_23);
  let v415_26: Space = if (&(v415_24)).is_empty() { Space::new() } else {
    let mut v421_25 = Space::new();
    let mut v421_25_write = v421_25.write_zipper();
    let mut v421_25_cursor = (*s0).read_zipper();
    let v421_25_origin = v421_25_cursor.path().len();
    for v421_25_byte in v421_25_cursor.child_mask().iter() {
      v421_25_cursor.descend_to_existing_byte(v421_25_byte);
      {
      let v422_2: Space = routine_87(c, &v421_25_cursor.path()[v421_25_origin..(v421_25_origin + 1)], &v421_25_cursor.path()[v421_25_origin..(v421_25_origin + 1)], &(*p2), &(*p3), &(*p0), &v421_25_cursor);
      join_wrapped_into(&mut v421_25_write,&((v422_2).read_zipper()),&[]);
      }
      v421_25_cursor.ascend(1);
    }
    drop(v421_25_cursor);
    drop(v421_25_write);
    map_map_kernels::compose(&(v415_24),&(v421_25))
  };
  drop(v415_24);
  let v415_27: Space = map_map_kernels::unite(&(v415_21),&(v415_26));
  (v415_27).clone()
}

fn routine_52(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v423_5: Space = singleton(&(*p0));
  let v423_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v423_5));
  let v423_7: Space = if map_kernels::has_head(&(v423_6)) { singleton(&[]) } else { Space::new() };
  drop(v423_6);
  let v423_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v423_7));
  drop(v423_7);
  let v423_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v423_5));
  drop(v423_5);
  let v423_14: Space = if map_kernels::has_head(&(v423_13)) { singleton(&[]) } else { Space::new() };
  drop(v423_13);
  let mut v423_15 = Space::new();
  let mut v423_15_write = v423_15.write_zipper();
  let mut v423_15_cursor = (*s0).read_zipper();
  let v423_15_origin = v423_15_cursor.path().len();
  for v423_15_byte in v423_15_cursor.child_mask().iter() {
    v423_15_cursor.descend_to_existing_byte(v423_15_byte);
    {
    let v424_4: Space = if (&(v423_8)).is_empty() { Space::new() } else {
      let v425_2: Path = concat_path(&(*p1),&v423_15_cursor.path()[v423_15_origin..(v423_15_origin + 1)]);
      let mut v425_3 = Space::new();
      let mut v425_3_write = v425_3.write_zipper();
      let v425_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v425_3_arg_1: &[u8] = &(v425_2);
      let v425_3_arg_3: &Space = &(&v423_15_cursor).make_map();
      let mut v425_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v425_3_origin = v425_3_cursor.path().len();
      let mut v425_3_more = v425_3_cursor.is_val() || next_value_within(&mut v425_3_cursor,v425_3_origin);
      while v425_3_more {
        {
        let v425_3_depth = v425_3_cursor.path().len();
        let v426_4: Space = routine_52(c, &v425_3_cursor.path()[v425_3_origin..v425_3_depth], &(*v425_3_arg_1), &((*v425_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v425_3_write,&((v426_4).read_zipper()),&[]);
        }
        v425_3_more = next_value_within(&mut v425_3_cursor,v425_3_origin);
      }
      drop(v425_3_cursor);
      drop(v425_3_write);
      map_map_kernels::compose(&(v423_8),&(v425_3))
    };
    let v424_6: Space = if (&(v423_14)).is_empty() { Space::new() } else {
      let v427_2: Path = concat_path(&(*p1),&v423_15_cursor.path()[v423_15_origin..(v423_15_origin + 1)]);
      let mut v427_5 = Space::new();
      let mut v427_5_write = v427_5.write_zipper();
      for v427_5_byte in v423_15_cursor.child_mask().iter() {
        v423_15_cursor.descend_to_existing_byte(v427_5_byte);
        {
        let v428_2: Space = routine_53(c, &v423_15_cursor.path()[(v423_15_origin + 1)..(v423_15_origin + 2)], &v423_15_cursor.path()[(v423_15_origin + 1)..(v423_15_origin + 2)], &(v427_2), &v423_15_cursor);
        join_wrapped_into(&mut v427_5_write,&((v428_2).read_zipper()),&[]);
        }
        v423_15_cursor.ascend(1);
      }
      drop(v427_5_write);
      drop(v427_2);
      map_map_kernels::compose(&(v423_14),&(v427_5))
    };
    let v424_7: Space = map_map_kernels::unite(&(v424_4),&(v424_6));
    join_wrapped_into(&mut v423_15_write,&((v424_7).read_zipper()),&[]);
    }
    v423_15_cursor.ascend(1);
  }
  drop(v423_15_cursor);
  drop(v423_15_write);
  drop(v423_8);
  drop(v423_14);
  (v423_15).clone()
}

fn routine_53(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v429_6: Space = singleton(&(*p1));
  let v429_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v429_6));
  let v429_8: Space = if map_kernels::has_head(&(v429_7)) { singleton(&[]) } else { Space::new() };
  drop(v429_7);
  let v429_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v429_8));
  drop(v429_8);
  let v429_20: Space = if (&(v429_9)).is_empty() { Space::new() } else {
    let v430_12: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v430_15: Space = if (&(v430_12)).is_empty() { Space::new() } else {
      let v431_14: Space = routine_88(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      map_map_kernels::compose(&(v430_12),&(v431_14))
    };
    drop(v430_12);
    let mut v430_18 = Space::new();
    let mut v430_18_write = v430_18.write_zipper();
    let mut v430_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v430_18_origin = v430_18_cursor.path().len();
    for v430_18_byte in v430_18_cursor.child_mask().iter() {
      v430_18_cursor.descend_to_existing_byte(v430_18_byte);
      {
      let v432_2_arg_0: &[u8] = &v430_18_cursor.path()[v430_18_origin..(v430_18_origin + 1)];
      let v432_2_arg_1: &[u8] = &(*p0);
      let v432_2_arg_2: &[u8] = &(*p2);
      let v432_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v432_2_more = v430_18_cursor.is_val() || next_value_within(&mut v430_18_cursor,(v430_18_origin + 1));
      while v432_2_more {
        {
        let v432_2_depth = v430_18_cursor.path().len();
        let mut v433_5_cursor = (*v432_2_arg_4).read_zipper();
        let v433_5_origin = v433_5_cursor.path().len();
        for v433_5_byte in v433_5_cursor.child_mask().iter() {
          v433_5_cursor.descend_to_existing_byte(v433_5_byte);
          {
          let v434_2: Path = concat_path(&(*v432_2_arg_1),&v433_5_cursor.path()[v433_5_origin..(v433_5_origin + 1)]);
          let v434_3: Space = routine_53(c, &(v434_2), &v430_18_cursor.path()[v430_18_origin..v432_2_depth], &(*v432_2_arg_2), &v433_5_cursor);
          drop(v434_2);
          join_wrapped_into(&mut v430_18_write,&((v434_3).read_zipper()),&[]);
          }
          v433_5_cursor.ascend(1);
        }
        drop(v433_5_cursor);
        }
        v432_2_more = next_value_within(&mut v430_18_cursor,(v430_18_origin + 1));
      }
      }
      v430_18_cursor.ascend(1);
    }
    drop(v430_18_cursor);
    drop(v430_18_write);
    let v430_19: Space = map_map_kernels::unite(&(v430_15),&(v430_18));
    map_map_kernels::compose(&(v429_9),&(v430_19))
  };
  drop(v429_9);
  let v429_22: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v429_6));
  drop(v429_6);
  let v429_23: Space = if map_kernels::has_head(&(v429_22)) { singleton(&[]) } else { Space::new() };
  drop(v429_22);
  let v429_25: Space = if (&(v429_23)).is_empty() { Space::new() } else {
    let mut v435_24 = Space::new();
    let mut v435_24_write = v435_24.write_zipper();
    let mut v435_24_cursor = (*s0).read_zipper();
    let v435_24_origin = v435_24_cursor.path().len();
    for v435_24_byte in v435_24_cursor.child_mask().iter() {
      v435_24_cursor.descend_to_existing_byte(v435_24_byte);
      {
      let v436_2: Space = routine_54(c, &v435_24_cursor.path()[v435_24_origin..(v435_24_origin + 1)], &v435_24_cursor.path()[v435_24_origin..(v435_24_origin + 1)], &(*p2), &(*p0), &v435_24_cursor);
      join_wrapped_into(&mut v435_24_write,&((v436_2).read_zipper()),&[]);
      }
      v435_24_cursor.ascend(1);
    }
    drop(v435_24_cursor);
    drop(v435_24_write);
    map_map_kernels::compose(&(v429_23),&(v435_24))
  };
  drop(v429_23);
  let v429_26: Space = map_map_kernels::unite(&(v429_20),&(v429_25));
  (v429_26).clone()
}

fn routine_54(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v437_7: Space = singleton(&(*p1));
  let v437_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v437_7));
  let v437_9: Space = if map_kernels::has_head(&(v437_8)) { singleton(&[]) } else { Space::new() };
  drop(v437_8);
  let v437_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v437_9));
  drop(v437_9);
  let v437_21: Space = if (&(v437_10)).is_empty() { Space::new() } else {
    let v438_13: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v438_16: Space = if (&(v438_13)).is_empty() { Space::new() } else {
      let v439_15: Space = routine_89(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      map_map_kernels::compose(&(v438_13),&(v439_15))
    };
    drop(v438_13);
    let mut v438_19 = Space::new();
    let mut v438_19_write = v438_19.write_zipper();
    let mut v438_19_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v438_19_origin = v438_19_cursor.path().len();
    for v438_19_byte in v438_19_cursor.child_mask().iter() {
      v438_19_cursor.descend_to_existing_byte(v438_19_byte);
      {
      let v440_2_arg_0: &[u8] = &v438_19_cursor.path()[v438_19_origin..(v438_19_origin + 1)];
      let v440_2_arg_1: &[u8] = &(*p0);
      let v440_2_arg_2: &[u8] = &(*p2);
      let v440_2_arg_3: &[u8] = &(*p3);
      let v440_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v440_2_more = v438_19_cursor.is_val() || next_value_within(&mut v438_19_cursor,(v438_19_origin + 1));
      while v440_2_more {
        {
        let v440_2_depth = v438_19_cursor.path().len();
        let mut v441_6_cursor = (*v440_2_arg_5).read_zipper();
        let v441_6_origin = v441_6_cursor.path().len();
        for v441_6_byte in v441_6_cursor.child_mask().iter() {
          v441_6_cursor.descend_to_existing_byte(v441_6_byte);
          {
          let v442_2: Path = concat_path(&(*v440_2_arg_1),&v441_6_cursor.path()[v441_6_origin..(v441_6_origin + 1)]);
          let v442_3: Space = routine_54(c, &(v442_2), &v438_19_cursor.path()[v438_19_origin..v440_2_depth], &(*v440_2_arg_2), &(*v440_2_arg_3), &v441_6_cursor);
          drop(v442_2);
          join_wrapped_into(&mut v438_19_write,&((v442_3).read_zipper()),&[]);
          }
          v441_6_cursor.ascend(1);
        }
        drop(v441_6_cursor);
        }
        v440_2_more = next_value_within(&mut v438_19_cursor,(v438_19_origin + 1));
      }
      }
      v438_19_cursor.ascend(1);
    }
    drop(v438_19_cursor);
    drop(v438_19_write);
    let v438_20: Space = map_map_kernels::unite(&(v438_16),&(v438_19));
    map_map_kernels::compose(&(v437_10),&(v438_20))
  };
  drop(v437_10);
  let v437_23: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v437_7));
  drop(v437_7);
  let v437_24: Space = if map_kernels::has_head(&(v437_23)) { singleton(&[]) } else { Space::new() };
  drop(v437_23);
  let v437_26: Space = if (&(v437_24)).is_empty() { Space::new() } else {
    let mut v443_25 = Space::new();
    let mut v443_25_write = v443_25.write_zipper();
    let mut v443_25_cursor = (*s0).read_zipper();
    let v443_25_origin = v443_25_cursor.path().len();
    for v443_25_byte in v443_25_cursor.child_mask().iter() {
      v443_25_cursor.descend_to_existing_byte(v443_25_byte);
      {
      let v444_2: Space = routine_90(c, &v443_25_cursor.path()[v443_25_origin..(v443_25_origin + 1)], &v443_25_cursor.path()[v443_25_origin..(v443_25_origin + 1)], &(*p2), &(*p3), &(*p0), &v443_25_cursor);
      join_wrapped_into(&mut v443_25_write,&((v444_2).read_zipper()),&[]);
      }
      v443_25_cursor.ascend(1);
    }
    drop(v443_25_cursor);
    drop(v443_25_write);
    map_map_kernels::compose(&(v437_24),&(v443_25))
  };
  drop(v437_24);
  let v437_27: Space = map_map_kernels::unite(&(v437_21),&(v437_26));
  (v437_27).clone()
}

fn routine_55(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v445_5: Space = singleton(&(*p0));
  let v445_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v445_5));
  let v445_7: Space = if map_kernels::has_head(&(v445_6)) { singleton(&[]) } else { Space::new() };
  drop(v445_6);
  let v445_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v445_7));
  drop(v445_7);
  let v445_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v445_5));
  drop(v445_5);
  let v445_14: Space = if map_kernels::has_head(&(v445_13)) { singleton(&[]) } else { Space::new() };
  drop(v445_13);
  let mut v445_15 = Space::new();
  let mut v445_15_write = v445_15.write_zipper();
  let mut v445_15_cursor = (*s0).read_zipper();
  let v445_15_origin = v445_15_cursor.path().len();
  for v445_15_byte in v445_15_cursor.child_mask().iter() {
    v445_15_cursor.descend_to_existing_byte(v445_15_byte);
    {
    let v446_4: Space = if (&(v445_8)).is_empty() { Space::new() } else {
      let v447_2: Path = concat_path(&(*p1),&v445_15_cursor.path()[v445_15_origin..(v445_15_origin + 1)]);
      let mut v447_3 = Space::new();
      let mut v447_3_write = v447_3.write_zipper();
      let v447_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v447_3_arg_1: &[u8] = &(v447_2);
      let v447_3_arg_3: &Space = &(&v445_15_cursor).make_map();
      let mut v447_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v447_3_origin = v447_3_cursor.path().len();
      let mut v447_3_more = v447_3_cursor.is_val() || next_value_within(&mut v447_3_cursor,v447_3_origin);
      while v447_3_more {
        {
        let v447_3_depth = v447_3_cursor.path().len();
        let v448_4: Space = routine_55(c, &v447_3_cursor.path()[v447_3_origin..v447_3_depth], &(*v447_3_arg_1), &((*v447_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v447_3_write,&((v448_4).read_zipper()),&[]);
        }
        v447_3_more = next_value_within(&mut v447_3_cursor,v447_3_origin);
      }
      drop(v447_3_cursor);
      drop(v447_3_write);
      map_map_kernels::compose(&(v445_8),&(v447_3))
    };
    let v446_6: Space = if (&(v445_14)).is_empty() { Space::new() } else {
      let v449_2: Path = concat_path(&(*p1),&v445_15_cursor.path()[v445_15_origin..(v445_15_origin + 1)]);
      let mut v449_5 = Space::new();
      let mut v449_5_write = v449_5.write_zipper();
      for v449_5_byte in v445_15_cursor.child_mask().iter() {
        v445_15_cursor.descend_to_existing_byte(v449_5_byte);
        {
        let v450_2: Space = routine_56(c, &v445_15_cursor.path()[(v445_15_origin + 1)..(v445_15_origin + 2)], &v445_15_cursor.path()[(v445_15_origin + 1)..(v445_15_origin + 2)], &(v449_2), &v445_15_cursor);
        join_wrapped_into(&mut v449_5_write,&((v450_2).read_zipper()),&[]);
        }
        v445_15_cursor.ascend(1);
      }
      drop(v449_5_write);
      drop(v449_2);
      map_map_kernels::compose(&(v445_14),&(v449_5))
    };
    let v446_7: Space = map_map_kernels::unite(&(v446_4),&(v446_6));
    join_wrapped_into(&mut v445_15_write,&((v446_7).read_zipper()),&[]);
    }
    v445_15_cursor.ascend(1);
  }
  drop(v445_15_cursor);
  drop(v445_15_write);
  drop(v445_8);
  drop(v445_14);
  (v445_15).clone()
}

fn routine_56(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v451_6: Space = singleton(&(*p1));
  let v451_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v451_6));
  let v451_8: Space = if map_kernels::has_head(&(v451_7)) { singleton(&[]) } else { Space::new() };
  drop(v451_7);
  let v451_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v451_8));
  drop(v451_8);
  let v451_20: Space = if (&(v451_9)).is_empty() { Space::new() } else {
    let v452_12: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v452_15: Space = if (&(v452_12)).is_empty() { Space::new() } else {
      let v453_14: Space = routine_91(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      map_map_kernels::compose(&(v452_12),&(v453_14))
    };
    drop(v452_12);
    let mut v452_18 = Space::new();
    let mut v452_18_write = v452_18.write_zipper();
    let mut v452_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v452_18_origin = v452_18_cursor.path().len();
    for v452_18_byte in v452_18_cursor.child_mask().iter() {
      v452_18_cursor.descend_to_existing_byte(v452_18_byte);
      {
      let v454_2_arg_0: &[u8] = &v452_18_cursor.path()[v452_18_origin..(v452_18_origin + 1)];
      let v454_2_arg_1: &[u8] = &(*p0);
      let v454_2_arg_2: &[u8] = &(*p2);
      let v454_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v454_2_more = v452_18_cursor.is_val() || next_value_within(&mut v452_18_cursor,(v452_18_origin + 1));
      while v454_2_more {
        {
        let v454_2_depth = v452_18_cursor.path().len();
        let mut v455_5_cursor = (*v454_2_arg_4).read_zipper();
        let v455_5_origin = v455_5_cursor.path().len();
        for v455_5_byte in v455_5_cursor.child_mask().iter() {
          v455_5_cursor.descend_to_existing_byte(v455_5_byte);
          {
          let v456_2: Path = concat_path(&(*v454_2_arg_1),&v455_5_cursor.path()[v455_5_origin..(v455_5_origin + 1)]);
          let v456_3: Space = routine_56(c, &(v456_2), &v452_18_cursor.path()[v452_18_origin..v454_2_depth], &(*v454_2_arg_2), &v455_5_cursor);
          drop(v456_2);
          join_wrapped_into(&mut v452_18_write,&((v456_3).read_zipper()),&[]);
          }
          v455_5_cursor.ascend(1);
        }
        drop(v455_5_cursor);
        }
        v454_2_more = next_value_within(&mut v452_18_cursor,(v452_18_origin + 1));
      }
      }
      v452_18_cursor.ascend(1);
    }
    drop(v452_18_cursor);
    drop(v452_18_write);
    let v452_19: Space = map_map_kernels::unite(&(v452_15),&(v452_18));
    map_map_kernels::compose(&(v451_9),&(v452_19))
  };
  drop(v451_9);
  let v451_22: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v451_6));
  drop(v451_6);
  let v451_23: Space = if map_kernels::has_head(&(v451_22)) { singleton(&[]) } else { Space::new() };
  drop(v451_22);
  let v451_25: Space = if (&(v451_23)).is_empty() { Space::new() } else {
    let mut v457_24 = Space::new();
    let mut v457_24_write = v457_24.write_zipper();
    let mut v457_24_cursor = (*s0).read_zipper();
    let v457_24_origin = v457_24_cursor.path().len();
    for v457_24_byte in v457_24_cursor.child_mask().iter() {
      v457_24_cursor.descend_to_existing_byte(v457_24_byte);
      {
      let v458_2: Space = routine_57(c, &v457_24_cursor.path()[v457_24_origin..(v457_24_origin + 1)], &v457_24_cursor.path()[v457_24_origin..(v457_24_origin + 1)], &(*p2), &(*p0), &v457_24_cursor);
      join_wrapped_into(&mut v457_24_write,&((v458_2).read_zipper()),&[]);
      }
      v457_24_cursor.ascend(1);
    }
    drop(v457_24_cursor);
    drop(v457_24_write);
    map_map_kernels::compose(&(v451_23),&(v457_24))
  };
  drop(v451_23);
  let v451_26: Space = map_map_kernels::unite(&(v451_20),&(v451_25));
  (v451_26).clone()
}

fn routine_57(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v459_7: Space = singleton(&(*p1));
  let v459_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v459_7));
  let v459_9: Space = if map_kernels::has_head(&(v459_8)) { singleton(&[]) } else { Space::new() };
  drop(v459_8);
  let v459_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v459_9));
  drop(v459_9);
  let v459_21: Space = if (&(v459_10)).is_empty() { Space::new() } else {
    let v460_13: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v460_16: Space = if (&(v460_13)).is_empty() { Space::new() } else {
      let v461_15: Space = routine_92(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      map_map_kernels::compose(&(v460_13),&(v461_15))
    };
    drop(v460_13);
    let mut v460_19 = Space::new();
    let mut v460_19_write = v460_19.write_zipper();
    let mut v460_19_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v460_19_origin = v460_19_cursor.path().len();
    for v460_19_byte in v460_19_cursor.child_mask().iter() {
      v460_19_cursor.descend_to_existing_byte(v460_19_byte);
      {
      let v462_2_arg_0: &[u8] = &v460_19_cursor.path()[v460_19_origin..(v460_19_origin + 1)];
      let v462_2_arg_1: &[u8] = &(*p0);
      let v462_2_arg_2: &[u8] = &(*p2);
      let v462_2_arg_3: &[u8] = &(*p3);
      let v462_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v462_2_more = v460_19_cursor.is_val() || next_value_within(&mut v460_19_cursor,(v460_19_origin + 1));
      while v462_2_more {
        {
        let v462_2_depth = v460_19_cursor.path().len();
        let mut v463_6_cursor = (*v462_2_arg_5).read_zipper();
        let v463_6_origin = v463_6_cursor.path().len();
        for v463_6_byte in v463_6_cursor.child_mask().iter() {
          v463_6_cursor.descend_to_existing_byte(v463_6_byte);
          {
          let v464_2: Path = concat_path(&(*v462_2_arg_1),&v463_6_cursor.path()[v463_6_origin..(v463_6_origin + 1)]);
          let v464_3: Space = routine_57(c, &(v464_2), &v460_19_cursor.path()[v460_19_origin..v462_2_depth], &(*v462_2_arg_2), &(*v462_2_arg_3), &v463_6_cursor);
          drop(v464_2);
          join_wrapped_into(&mut v460_19_write,&((v464_3).read_zipper()),&[]);
          }
          v463_6_cursor.ascend(1);
        }
        drop(v463_6_cursor);
        }
        v462_2_more = next_value_within(&mut v460_19_cursor,(v460_19_origin + 1));
      }
      }
      v460_19_cursor.ascend(1);
    }
    drop(v460_19_cursor);
    drop(v460_19_write);
    let v460_20: Space = map_map_kernels::unite(&(v460_16),&(v460_19));
    map_map_kernels::compose(&(v459_10),&(v460_20))
  };
  drop(v459_10);
  let v459_23: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v459_7));
  drop(v459_7);
  let v459_24: Space = if map_kernels::has_head(&(v459_23)) { singleton(&[]) } else { Space::new() };
  drop(v459_23);
  let v459_26: Space = if (&(v459_24)).is_empty() { Space::new() } else {
    let mut v465_25 = Space::new();
    let mut v465_25_write = v465_25.write_zipper();
    let mut v465_25_cursor = (*s0).read_zipper();
    let v465_25_origin = v465_25_cursor.path().len();
    for v465_25_byte in v465_25_cursor.child_mask().iter() {
      v465_25_cursor.descend_to_existing_byte(v465_25_byte);
      {
      let v466_2: Space = routine_93(c, &v465_25_cursor.path()[v465_25_origin..(v465_25_origin + 1)], &v465_25_cursor.path()[v465_25_origin..(v465_25_origin + 1)], &(*p2), &(*p3), &(*p0), &v465_25_cursor);
      join_wrapped_into(&mut v465_25_write,&((v466_2).read_zipper()),&[]);
      }
      v465_25_cursor.ascend(1);
    }
    drop(v465_25_cursor);
    drop(v465_25_write);
    map_map_kernels::compose(&(v459_24),&(v465_25))
  };
  drop(v459_24);
  let v459_27: Space = map_map_kernels::unite(&(v459_21),&(v459_26));
  (v459_27).clone()
}

fn routine_58(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v467_5: Space = singleton(&(*p0));
  let v467_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v467_5));
  let v467_7: Space = if map_kernels::has_head(&(v467_6)) { singleton(&[]) } else { Space::new() };
  drop(v467_6);
  let v467_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v467_7));
  drop(v467_7);
  let v467_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v467_5));
  drop(v467_5);
  let v467_14: Space = if map_kernels::has_head(&(v467_13)) { singleton(&[]) } else { Space::new() };
  drop(v467_13);
  let mut v467_15 = Space::new();
  let mut v467_15_write = v467_15.write_zipper();
  let mut v467_15_cursor = (*s0).read_zipper();
  let v467_15_origin = v467_15_cursor.path().len();
  for v467_15_byte in v467_15_cursor.child_mask().iter() {
    v467_15_cursor.descend_to_existing_byte(v467_15_byte);
    {
    let v468_4: Space = if (&(v467_8)).is_empty() { Space::new() } else {
      let v469_2: Path = concat_path(&(*p1),&v467_15_cursor.path()[v467_15_origin..(v467_15_origin + 1)]);
      let mut v469_3 = Space::new();
      let mut v469_3_write = v469_3.write_zipper();
      let v469_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v469_3_arg_1: &[u8] = &(v469_2);
      let v469_3_arg_3: &Space = &(&v467_15_cursor).make_map();
      let mut v469_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v469_3_origin = v469_3_cursor.path().len();
      let mut v469_3_more = v469_3_cursor.is_val() || next_value_within(&mut v469_3_cursor,v469_3_origin);
      while v469_3_more {
        {
        let v469_3_depth = v469_3_cursor.path().len();
        let v470_4: Space = routine_58(c, &v469_3_cursor.path()[v469_3_origin..v469_3_depth], &(*v469_3_arg_1), &((*v469_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v469_3_write,&((v470_4).read_zipper()),&[]);
        }
        v469_3_more = next_value_within(&mut v469_3_cursor,v469_3_origin);
      }
      drop(v469_3_cursor);
      drop(v469_3_write);
      map_map_kernels::compose(&(v467_8),&(v469_3))
    };
    let v468_6: Space = if (&(v467_14)).is_empty() { Space::new() } else {
      let v471_2: Path = concat_path(&(*p1),&v467_15_cursor.path()[v467_15_origin..(v467_15_origin + 1)]);
      let mut v471_5 = Space::new();
      let mut v471_5_write = v471_5.write_zipper();
      for v471_5_byte in v467_15_cursor.child_mask().iter() {
        v467_15_cursor.descend_to_existing_byte(v471_5_byte);
        {
        let v472_2: Space = routine_59(c, &v467_15_cursor.path()[(v467_15_origin + 1)..(v467_15_origin + 2)], &v467_15_cursor.path()[(v467_15_origin + 1)..(v467_15_origin + 2)], &(v471_2), &v467_15_cursor);
        join_wrapped_into(&mut v471_5_write,&((v472_2).read_zipper()),&[]);
        }
        v467_15_cursor.ascend(1);
      }
      drop(v471_5_write);
      drop(v471_2);
      map_map_kernels::compose(&(v467_14),&(v471_5))
    };
    let v468_7: Space = map_map_kernels::unite(&(v468_4),&(v468_6));
    join_wrapped_into(&mut v467_15_write,&((v468_7).read_zipper()),&[]);
    }
    v467_15_cursor.ascend(1);
  }
  drop(v467_15_cursor);
  drop(v467_15_write);
  drop(v467_8);
  drop(v467_14);
  (v467_15).clone()
}

fn routine_59(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v473_6: Space = singleton(&(*p1));
  let v473_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v473_6));
  let v473_8: Space = if map_kernels::has_head(&(v473_7)) { singleton(&[]) } else { Space::new() };
  drop(v473_7);
  let v473_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v473_8));
  drop(v473_8);
  let v473_20: Space = if (&(v473_9)).is_empty() { Space::new() } else {
    let v474_12: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v474_15: Space = if (&(v474_12)).is_empty() { Space::new() } else {
      let v475_14: Space = routine_94(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      map_map_kernels::compose(&(v474_12),&(v475_14))
    };
    drop(v474_12);
    let mut v474_18 = Space::new();
    let mut v474_18_write = v474_18.write_zipper();
    let mut v474_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v474_18_origin = v474_18_cursor.path().len();
    for v474_18_byte in v474_18_cursor.child_mask().iter() {
      v474_18_cursor.descend_to_existing_byte(v474_18_byte);
      {
      let v476_2_arg_0: &[u8] = &v474_18_cursor.path()[v474_18_origin..(v474_18_origin + 1)];
      let v476_2_arg_1: &[u8] = &(*p0);
      let v476_2_arg_2: &[u8] = &(*p2);
      let v476_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v476_2_more = v474_18_cursor.is_val() || next_value_within(&mut v474_18_cursor,(v474_18_origin + 1));
      while v476_2_more {
        {
        let v476_2_depth = v474_18_cursor.path().len();
        let mut v477_5_cursor = (*v476_2_arg_4).read_zipper();
        let v477_5_origin = v477_5_cursor.path().len();
        for v477_5_byte in v477_5_cursor.child_mask().iter() {
          v477_5_cursor.descend_to_existing_byte(v477_5_byte);
          {
          let v478_2: Path = concat_path(&(*v476_2_arg_1),&v477_5_cursor.path()[v477_5_origin..(v477_5_origin + 1)]);
          let v478_3: Space = routine_59(c, &(v478_2), &v474_18_cursor.path()[v474_18_origin..v476_2_depth], &(*v476_2_arg_2), &v477_5_cursor);
          drop(v478_2);
          join_wrapped_into(&mut v474_18_write,&((v478_3).read_zipper()),&[]);
          }
          v477_5_cursor.ascend(1);
        }
        drop(v477_5_cursor);
        }
        v476_2_more = next_value_within(&mut v474_18_cursor,(v474_18_origin + 1));
      }
      }
      v474_18_cursor.ascend(1);
    }
    drop(v474_18_cursor);
    drop(v474_18_write);
    let v474_19: Space = map_map_kernels::unite(&(v474_15),&(v474_18));
    map_map_kernels::compose(&(v473_9),&(v474_19))
  };
  drop(v473_9);
  let v473_22: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v473_6));
  drop(v473_6);
  let v473_23: Space = if map_kernels::has_head(&(v473_22)) { singleton(&[]) } else { Space::new() };
  drop(v473_22);
  let v473_25: Space = if (&(v473_23)).is_empty() { Space::new() } else {
    let mut v479_24 = Space::new();
    let mut v479_24_write = v479_24.write_zipper();
    let mut v479_24_cursor = (*s0).read_zipper();
    let v479_24_origin = v479_24_cursor.path().len();
    for v479_24_byte in v479_24_cursor.child_mask().iter() {
      v479_24_cursor.descend_to_existing_byte(v479_24_byte);
      {
      let v480_2: Space = routine_60(c, &v479_24_cursor.path()[v479_24_origin..(v479_24_origin + 1)], &v479_24_cursor.path()[v479_24_origin..(v479_24_origin + 1)], &(*p2), &(*p0), &v479_24_cursor);
      join_wrapped_into(&mut v479_24_write,&((v480_2).read_zipper()),&[]);
      }
      v479_24_cursor.ascend(1);
    }
    drop(v479_24_cursor);
    drop(v479_24_write);
    map_map_kernels::compose(&(v473_23),&(v479_24))
  };
  drop(v473_23);
  let v473_26: Space = map_map_kernels::unite(&(v473_20),&(v473_25));
  (v473_26).clone()
}

fn routine_60(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v481_7: Space = singleton(&(*p1));
  let v481_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v481_7));
  let v481_9: Space = if map_kernels::has_head(&(v481_8)) { singleton(&[]) } else { Space::new() };
  drop(v481_8);
  let v481_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v481_9));
  drop(v481_9);
  let v481_21: Space = if (&(v481_10)).is_empty() { Space::new() } else {
    let v482_13: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v482_16: Space = if (&(v482_13)).is_empty() { Space::new() } else {
      let v483_15: Space = routine_95(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      map_map_kernels::compose(&(v482_13),&(v483_15))
    };
    drop(v482_13);
    let mut v482_19 = Space::new();
    let mut v482_19_write = v482_19.write_zipper();
    let mut v482_19_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v482_19_origin = v482_19_cursor.path().len();
    for v482_19_byte in v482_19_cursor.child_mask().iter() {
      v482_19_cursor.descend_to_existing_byte(v482_19_byte);
      {
      let v484_2_arg_0: &[u8] = &v482_19_cursor.path()[v482_19_origin..(v482_19_origin + 1)];
      let v484_2_arg_1: &[u8] = &(*p0);
      let v484_2_arg_2: &[u8] = &(*p2);
      let v484_2_arg_3: &[u8] = &(*p3);
      let v484_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v484_2_more = v482_19_cursor.is_val() || next_value_within(&mut v482_19_cursor,(v482_19_origin + 1));
      while v484_2_more {
        {
        let v484_2_depth = v482_19_cursor.path().len();
        let mut v485_6_cursor = (*v484_2_arg_5).read_zipper();
        let v485_6_origin = v485_6_cursor.path().len();
        for v485_6_byte in v485_6_cursor.child_mask().iter() {
          v485_6_cursor.descend_to_existing_byte(v485_6_byte);
          {
          let v486_2: Path = concat_path(&(*v484_2_arg_1),&v485_6_cursor.path()[v485_6_origin..(v485_6_origin + 1)]);
          let v486_3: Space = routine_60(c, &(v486_2), &v482_19_cursor.path()[v482_19_origin..v484_2_depth], &(*v484_2_arg_2), &(*v484_2_arg_3), &v485_6_cursor);
          drop(v486_2);
          join_wrapped_into(&mut v482_19_write,&((v486_3).read_zipper()),&[]);
          }
          v485_6_cursor.ascend(1);
        }
        drop(v485_6_cursor);
        }
        v484_2_more = next_value_within(&mut v482_19_cursor,(v482_19_origin + 1));
      }
      }
      v482_19_cursor.ascend(1);
    }
    drop(v482_19_cursor);
    drop(v482_19_write);
    let v482_20: Space = map_map_kernels::unite(&(v482_16),&(v482_19));
    map_map_kernels::compose(&(v481_10),&(v482_20))
  };
  drop(v481_10);
  let v481_23: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v481_7));
  drop(v481_7);
  let v481_24: Space = if map_kernels::has_head(&(v481_23)) { singleton(&[]) } else { Space::new() };
  drop(v481_23);
  let v481_26: Space = if (&(v481_24)).is_empty() { Space::new() } else {
    let mut v487_25 = Space::new();
    let mut v487_25_write = v487_25.write_zipper();
    let mut v487_25_cursor = (*s0).read_zipper();
    let v487_25_origin = v487_25_cursor.path().len();
    for v487_25_byte in v487_25_cursor.child_mask().iter() {
      v487_25_cursor.descend_to_existing_byte(v487_25_byte);
      {
      let v488_2: Space = routine_96(c, &v487_25_cursor.path()[v487_25_origin..(v487_25_origin + 1)], &v487_25_cursor.path()[v487_25_origin..(v487_25_origin + 1)], &(*p2), &(*p3), &(*p0), &v487_25_cursor);
      join_wrapped_into(&mut v487_25_write,&((v488_2).read_zipper()),&[]);
      }
      v487_25_cursor.ascend(1);
    }
    drop(v487_25_cursor);
    drop(v487_25_write);
    map_map_kernels::compose(&(v481_24),&(v487_25))
  };
  drop(v481_24);
  let v481_27: Space = map_map_kernels::unite(&(v481_21),&(v481_26));
  (v481_27).clone()
}

fn routine_61(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v489_5: Space = singleton(&(*p0));
  let v489_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v489_5));
  let v489_7: Space = if map_kernels::has_head(&(v489_6)) { singleton(&[]) } else { Space::new() };
  drop(v489_6);
  let v489_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v489_7));
  drop(v489_7);
  let v489_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v489_5));
  drop(v489_5);
  let v489_14: Space = if map_kernels::has_head(&(v489_13)) { singleton(&[]) } else { Space::new() };
  drop(v489_13);
  let mut v489_15 = Space::new();
  let mut v489_15_write = v489_15.write_zipper();
  let mut v489_15_cursor = (*s0).read_zipper();
  let v489_15_origin = v489_15_cursor.path().len();
  for v489_15_byte in v489_15_cursor.child_mask().iter() {
    v489_15_cursor.descend_to_existing_byte(v489_15_byte);
    {
    let v490_4: Space = if (&(v489_8)).is_empty() { Space::new() } else {
      let v491_2: Path = concat_path(&(*p1),&v489_15_cursor.path()[v489_15_origin..(v489_15_origin + 1)]);
      let mut v491_3 = Space::new();
      let mut v491_3_write = v491_3.write_zipper();
      let v491_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v491_3_arg_1: &[u8] = &(v491_2);
      let v491_3_arg_3: &Space = &(&v489_15_cursor).make_map();
      let mut v491_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v491_3_origin = v491_3_cursor.path().len();
      let mut v491_3_more = v491_3_cursor.is_val() || next_value_within(&mut v491_3_cursor,v491_3_origin);
      while v491_3_more {
        {
        let v491_3_depth = v491_3_cursor.path().len();
        let v492_4: Space = routine_61(c, &v491_3_cursor.path()[v491_3_origin..v491_3_depth], &(*v491_3_arg_1), &((*v491_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v491_3_write,&((v492_4).read_zipper()),&[]);
        }
        v491_3_more = next_value_within(&mut v491_3_cursor,v491_3_origin);
      }
      drop(v491_3_cursor);
      drop(v491_3_write);
      map_map_kernels::compose(&(v489_8),&(v491_3))
    };
    let v490_6: Space = if (&(v489_14)).is_empty() { Space::new() } else {
      let v493_2: Path = concat_path(&(*p1),&v489_15_cursor.path()[v489_15_origin..(v489_15_origin + 1)]);
      let mut v493_5 = Space::new();
      let mut v493_5_write = v493_5.write_zipper();
      for v493_5_byte in v489_15_cursor.child_mask().iter() {
        v489_15_cursor.descend_to_existing_byte(v493_5_byte);
        {
        let v494_2: Space = routine_62(c, &v489_15_cursor.path()[(v489_15_origin + 1)..(v489_15_origin + 2)], &v489_15_cursor.path()[(v489_15_origin + 1)..(v489_15_origin + 2)], &(v493_2), &v489_15_cursor);
        join_wrapped_into(&mut v493_5_write,&((v494_2).read_zipper()),&[]);
        }
        v489_15_cursor.ascend(1);
      }
      drop(v493_5_write);
      drop(v493_2);
      map_map_kernels::compose(&(v489_14),&(v493_5))
    };
    let v490_7: Space = map_map_kernels::unite(&(v490_4),&(v490_6));
    join_wrapped_into(&mut v489_15_write,&((v490_7).read_zipper()),&[]);
    }
    v489_15_cursor.ascend(1);
  }
  drop(v489_15_cursor);
  drop(v489_15_write);
  drop(v489_8);
  drop(v489_14);
  (v489_15).clone()
}

fn routine_62(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v495_6: Space = singleton(&(*p1));
  let v495_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v495_6));
  let v495_8: Space = if map_kernels::has_head(&(v495_7)) { singleton(&[]) } else { Space::new() };
  drop(v495_7);
  let v495_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v495_8));
  drop(v495_8);
  let v495_20: Space = if (&(v495_9)).is_empty() { Space::new() } else {
    let v496_12: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v496_15: Space = if (&(v496_12)).is_empty() { Space::new() } else {
      let v497_14: Space = routine_97(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      map_map_kernels::compose(&(v496_12),&(v497_14))
    };
    drop(v496_12);
    let mut v496_18 = Space::new();
    let mut v496_18_write = v496_18.write_zipper();
    let mut v496_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v496_18_origin = v496_18_cursor.path().len();
    for v496_18_byte in v496_18_cursor.child_mask().iter() {
      v496_18_cursor.descend_to_existing_byte(v496_18_byte);
      {
      let v498_2_arg_0: &[u8] = &v496_18_cursor.path()[v496_18_origin..(v496_18_origin + 1)];
      let v498_2_arg_1: &[u8] = &(*p0);
      let v498_2_arg_2: &[u8] = &(*p2);
      let v498_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v498_2_more = v496_18_cursor.is_val() || next_value_within(&mut v496_18_cursor,(v496_18_origin + 1));
      while v498_2_more {
        {
        let v498_2_depth = v496_18_cursor.path().len();
        let mut v499_5_cursor = (*v498_2_arg_4).read_zipper();
        let v499_5_origin = v499_5_cursor.path().len();
        for v499_5_byte in v499_5_cursor.child_mask().iter() {
          v499_5_cursor.descend_to_existing_byte(v499_5_byte);
          {
          let v500_2: Path = concat_path(&(*v498_2_arg_1),&v499_5_cursor.path()[v499_5_origin..(v499_5_origin + 1)]);
          let v500_3: Space = routine_62(c, &(v500_2), &v496_18_cursor.path()[v496_18_origin..v498_2_depth], &(*v498_2_arg_2), &v499_5_cursor);
          drop(v500_2);
          join_wrapped_into(&mut v496_18_write,&((v500_3).read_zipper()),&[]);
          }
          v499_5_cursor.ascend(1);
        }
        drop(v499_5_cursor);
        }
        v498_2_more = next_value_within(&mut v496_18_cursor,(v496_18_origin + 1));
      }
      }
      v496_18_cursor.ascend(1);
    }
    drop(v496_18_cursor);
    drop(v496_18_write);
    let v496_19: Space = map_map_kernels::unite(&(v496_15),&(v496_18));
    map_map_kernels::compose(&(v495_9),&(v496_19))
  };
  drop(v495_9);
  let v495_22: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v495_6));
  drop(v495_6);
  let v495_23: Space = if map_kernels::has_head(&(v495_22)) { singleton(&[]) } else { Space::new() };
  drop(v495_22);
  let v495_25: Space = if (&(v495_23)).is_empty() { Space::new() } else {
    let mut v501_24 = Space::new();
    let mut v501_24_write = v501_24.write_zipper();
    let mut v501_24_cursor = (*s0).read_zipper();
    let v501_24_origin = v501_24_cursor.path().len();
    for v501_24_byte in v501_24_cursor.child_mask().iter() {
      v501_24_cursor.descend_to_existing_byte(v501_24_byte);
      {
      let v502_2: Space = routine_63(c, &v501_24_cursor.path()[v501_24_origin..(v501_24_origin + 1)], &v501_24_cursor.path()[v501_24_origin..(v501_24_origin + 1)], &(*p2), &(*p0), &v501_24_cursor);
      join_wrapped_into(&mut v501_24_write,&((v502_2).read_zipper()),&[]);
      }
      v501_24_cursor.ascend(1);
    }
    drop(v501_24_cursor);
    drop(v501_24_write);
    map_map_kernels::compose(&(v495_23),&(v501_24))
  };
  drop(v495_23);
  let v495_26: Space = map_map_kernels::unite(&(v495_20),&(v495_25));
  (v495_26).clone()
}

fn routine_63(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v503_7: Space = singleton(&(*p1));
  let v503_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v503_7));
  let v503_9: Space = if map_kernels::has_head(&(v503_8)) { singleton(&[]) } else { Space::new() };
  drop(v503_8);
  let v503_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v503_9));
  drop(v503_9);
  let v503_21: Space = if (&(v503_10)).is_empty() { Space::new() } else {
    let v504_13: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v504_16: Space = if (&(v504_13)).is_empty() { Space::new() } else {
      let v505_15: Space = routine_98(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      map_map_kernels::compose(&(v504_13),&(v505_15))
    };
    drop(v504_13);
    let mut v504_19 = Space::new();
    let mut v504_19_write = v504_19.write_zipper();
    let mut v504_19_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v504_19_origin = v504_19_cursor.path().len();
    for v504_19_byte in v504_19_cursor.child_mask().iter() {
      v504_19_cursor.descend_to_existing_byte(v504_19_byte);
      {
      let v506_2_arg_0: &[u8] = &v504_19_cursor.path()[v504_19_origin..(v504_19_origin + 1)];
      let v506_2_arg_1: &[u8] = &(*p0);
      let v506_2_arg_2: &[u8] = &(*p2);
      let v506_2_arg_3: &[u8] = &(*p3);
      let v506_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v506_2_more = v504_19_cursor.is_val() || next_value_within(&mut v504_19_cursor,(v504_19_origin + 1));
      while v506_2_more {
        {
        let v506_2_depth = v504_19_cursor.path().len();
        let mut v507_6_cursor = (*v506_2_arg_5).read_zipper();
        let v507_6_origin = v507_6_cursor.path().len();
        for v507_6_byte in v507_6_cursor.child_mask().iter() {
          v507_6_cursor.descend_to_existing_byte(v507_6_byte);
          {
          let v508_2: Path = concat_path(&(*v506_2_arg_1),&v507_6_cursor.path()[v507_6_origin..(v507_6_origin + 1)]);
          let v508_3: Space = routine_63(c, &(v508_2), &v504_19_cursor.path()[v504_19_origin..v506_2_depth], &(*v506_2_arg_2), &(*v506_2_arg_3), &v507_6_cursor);
          drop(v508_2);
          join_wrapped_into(&mut v504_19_write,&((v508_3).read_zipper()),&[]);
          }
          v507_6_cursor.ascend(1);
        }
        drop(v507_6_cursor);
        }
        v506_2_more = next_value_within(&mut v504_19_cursor,(v504_19_origin + 1));
      }
      }
      v504_19_cursor.ascend(1);
    }
    drop(v504_19_cursor);
    drop(v504_19_write);
    let v504_20: Space = map_map_kernels::unite(&(v504_16),&(v504_19));
    map_map_kernels::compose(&(v503_10),&(v504_20))
  };
  drop(v503_10);
  let v503_23: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v503_7));
  drop(v503_7);
  let v503_24: Space = if map_kernels::has_head(&(v503_23)) { singleton(&[]) } else { Space::new() };
  drop(v503_23);
  let v503_26: Space = if (&(v503_24)).is_empty() { Space::new() } else {
    let mut v509_25 = Space::new();
    let mut v509_25_write = v509_25.write_zipper();
    let mut v509_25_cursor = (*s0).read_zipper();
    let v509_25_origin = v509_25_cursor.path().len();
    for v509_25_byte in v509_25_cursor.child_mask().iter() {
      v509_25_cursor.descend_to_existing_byte(v509_25_byte);
      {
      let v510_2: Space = routine_99(c, &v509_25_cursor.path()[v509_25_origin..(v509_25_origin + 1)], &v509_25_cursor.path()[v509_25_origin..(v509_25_origin + 1)], &(*p2), &(*p3), &(*p0), &v509_25_cursor);
      join_wrapped_into(&mut v509_25_write,&((v510_2).read_zipper()),&[]);
      }
      v509_25_cursor.ascend(1);
    }
    drop(v509_25_cursor);
    drop(v509_25_write);
    map_map_kernels::compose(&(v503_24),&(v509_25))
  };
  drop(v503_24);
  let v503_27: Space = map_map_kernels::unite(&(v503_21),&(v503_26));
  (v503_27).clone()
}

fn routine_64(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v511_5: Space = singleton(&(*p0));
  let v511_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v511_5));
  let v511_7: Space = if map_kernels::has_head(&(v511_6)) { singleton(&[]) } else { Space::new() };
  drop(v511_6);
  let v511_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v511_7));
  drop(v511_7);
  let v511_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v511_5));
  drop(v511_5);
  let v511_14: Space = if map_kernels::has_head(&(v511_13)) { singleton(&[]) } else { Space::new() };
  drop(v511_13);
  let mut v511_15 = Space::new();
  let mut v511_15_write = v511_15.write_zipper();
  let mut v511_15_cursor = (*s0).read_zipper();
  let v511_15_origin = v511_15_cursor.path().len();
  for v511_15_byte in v511_15_cursor.child_mask().iter() {
    v511_15_cursor.descend_to_existing_byte(v511_15_byte);
    {
    let v512_4: Space = if (&(v511_8)).is_empty() { Space::new() } else {
      let v513_2: Path = concat_path(&(*p1),&v511_15_cursor.path()[v511_15_origin..(v511_15_origin + 1)]);
      let mut v513_3 = Space::new();
      let mut v513_3_write = v513_3.write_zipper();
      let v513_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v513_3_arg_1: &[u8] = &(v513_2);
      let v513_3_arg_3: &Space = &(&v511_15_cursor).make_map();
      let mut v513_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v513_3_origin = v513_3_cursor.path().len();
      let mut v513_3_more = v513_3_cursor.is_val() || next_value_within(&mut v513_3_cursor,v513_3_origin);
      while v513_3_more {
        {
        let v513_3_depth = v513_3_cursor.path().len();
        let v514_4: Space = routine_64(c, &v513_3_cursor.path()[v513_3_origin..v513_3_depth], &(*v513_3_arg_1), &((*v513_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v513_3_write,&((v514_4).read_zipper()),&[]);
        }
        v513_3_more = next_value_within(&mut v513_3_cursor,v513_3_origin);
      }
      drop(v513_3_cursor);
      drop(v513_3_write);
      map_map_kernels::compose(&(v511_8),&(v513_3))
    };
    let v512_6: Space = if (&(v511_14)).is_empty() { Space::new() } else {
      let v515_2: Path = concat_path(&(*p1),&v511_15_cursor.path()[v511_15_origin..(v511_15_origin + 1)]);
      let mut v515_5 = Space::new();
      let mut v515_5_write = v515_5.write_zipper();
      for v515_5_byte in v511_15_cursor.child_mask().iter() {
        v511_15_cursor.descend_to_existing_byte(v515_5_byte);
        {
        let v516_2: Space = routine_65(c, &v511_15_cursor.path()[(v511_15_origin + 1)..(v511_15_origin + 2)], &v511_15_cursor.path()[(v511_15_origin + 1)..(v511_15_origin + 2)], &(v515_2), &v511_15_cursor);
        join_wrapped_into(&mut v515_5_write,&((v516_2).read_zipper()),&[]);
        }
        v511_15_cursor.ascend(1);
      }
      drop(v515_5_write);
      drop(v515_2);
      map_map_kernels::compose(&(v511_14),&(v515_5))
    };
    let v512_7: Space = map_map_kernels::unite(&(v512_4),&(v512_6));
    join_wrapped_into(&mut v511_15_write,&((v512_7).read_zipper()),&[]);
    }
    v511_15_cursor.ascend(1);
  }
  drop(v511_15_cursor);
  drop(v511_15_write);
  drop(v511_8);
  drop(v511_14);
  (v511_15).clone()
}

fn routine_65(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v517_6: Space = singleton(&(*p1));
  let v517_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v517_6));
  let v517_8: Space = if map_kernels::has_head(&(v517_7)) { singleton(&[]) } else { Space::new() };
  drop(v517_7);
  let v517_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v517_8));
  drop(v517_8);
  let v517_20: Space = if (&(v517_9)).is_empty() { Space::new() } else {
    let v518_12: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v518_15: Space = if (&(v518_12)).is_empty() { Space::new() } else {
      let v519_14: Space = routine_100(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      map_map_kernels::compose(&(v518_12),&(v519_14))
    };
    drop(v518_12);
    let mut v518_18 = Space::new();
    let mut v518_18_write = v518_18.write_zipper();
    let mut v518_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v518_18_origin = v518_18_cursor.path().len();
    for v518_18_byte in v518_18_cursor.child_mask().iter() {
      v518_18_cursor.descend_to_existing_byte(v518_18_byte);
      {
      let v520_2_arg_0: &[u8] = &v518_18_cursor.path()[v518_18_origin..(v518_18_origin + 1)];
      let v520_2_arg_1: &[u8] = &(*p0);
      let v520_2_arg_2: &[u8] = &(*p2);
      let v520_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v520_2_more = v518_18_cursor.is_val() || next_value_within(&mut v518_18_cursor,(v518_18_origin + 1));
      while v520_2_more {
        {
        let v520_2_depth = v518_18_cursor.path().len();
        let mut v521_5_cursor = (*v520_2_arg_4).read_zipper();
        let v521_5_origin = v521_5_cursor.path().len();
        for v521_5_byte in v521_5_cursor.child_mask().iter() {
          v521_5_cursor.descend_to_existing_byte(v521_5_byte);
          {
          let v522_2: Path = concat_path(&(*v520_2_arg_1),&v521_5_cursor.path()[v521_5_origin..(v521_5_origin + 1)]);
          let v522_3: Space = routine_65(c, &(v522_2), &v518_18_cursor.path()[v518_18_origin..v520_2_depth], &(*v520_2_arg_2), &v521_5_cursor);
          drop(v522_2);
          join_wrapped_into(&mut v518_18_write,&((v522_3).read_zipper()),&[]);
          }
          v521_5_cursor.ascend(1);
        }
        drop(v521_5_cursor);
        }
        v520_2_more = next_value_within(&mut v518_18_cursor,(v518_18_origin + 1));
      }
      }
      v518_18_cursor.ascend(1);
    }
    drop(v518_18_cursor);
    drop(v518_18_write);
    let v518_19: Space = map_map_kernels::unite(&(v518_15),&(v518_18));
    map_map_kernels::compose(&(v517_9),&(v518_19))
  };
  drop(v517_9);
  let v517_22: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v517_6));
  drop(v517_6);
  let v517_23: Space = if map_kernels::has_head(&(v517_22)) { singleton(&[]) } else { Space::new() };
  drop(v517_22);
  let v517_25: Space = if (&(v517_23)).is_empty() { Space::new() } else {
    let mut v523_24 = Space::new();
    let mut v523_24_write = v523_24.write_zipper();
    let mut v523_24_cursor = (*s0).read_zipper();
    let v523_24_origin = v523_24_cursor.path().len();
    for v523_24_byte in v523_24_cursor.child_mask().iter() {
      v523_24_cursor.descend_to_existing_byte(v523_24_byte);
      {
      let v524_2: Space = routine_66(c, &v523_24_cursor.path()[v523_24_origin..(v523_24_origin + 1)], &v523_24_cursor.path()[v523_24_origin..(v523_24_origin + 1)], &(*p2), &(*p0), &v523_24_cursor);
      join_wrapped_into(&mut v523_24_write,&((v524_2).read_zipper()),&[]);
      }
      v523_24_cursor.ascend(1);
    }
    drop(v523_24_cursor);
    drop(v523_24_write);
    map_map_kernels::compose(&(v517_23),&(v523_24))
  };
  drop(v517_23);
  let v517_26: Space = map_map_kernels::unite(&(v517_20),&(v517_25));
  (v517_26).clone()
}

fn routine_66(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v525_7: Space = singleton(&(*p1));
  let v525_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v525_7));
  let v525_9: Space = if map_kernels::has_head(&(v525_8)) { singleton(&[]) } else { Space::new() };
  drop(v525_8);
  let v525_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v525_9));
  drop(v525_9);
  let v525_21: Space = if (&(v525_10)).is_empty() { Space::new() } else {
    let v526_13: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v526_16: Space = if (&(v526_13)).is_empty() { Space::new() } else {
      let v527_15: Space = routine_101(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      map_map_kernels::compose(&(v526_13),&(v527_15))
    };
    drop(v526_13);
    let mut v526_19 = Space::new();
    let mut v526_19_write = v526_19.write_zipper();
    let mut v526_19_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v526_19_origin = v526_19_cursor.path().len();
    for v526_19_byte in v526_19_cursor.child_mask().iter() {
      v526_19_cursor.descend_to_existing_byte(v526_19_byte);
      {
      let v528_2_arg_0: &[u8] = &v526_19_cursor.path()[v526_19_origin..(v526_19_origin + 1)];
      let v528_2_arg_1: &[u8] = &(*p0);
      let v528_2_arg_2: &[u8] = &(*p2);
      let v528_2_arg_3: &[u8] = &(*p3);
      let v528_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v528_2_more = v526_19_cursor.is_val() || next_value_within(&mut v526_19_cursor,(v526_19_origin + 1));
      while v528_2_more {
        {
        let v528_2_depth = v526_19_cursor.path().len();
        let mut v529_6_cursor = (*v528_2_arg_5).read_zipper();
        let v529_6_origin = v529_6_cursor.path().len();
        for v529_6_byte in v529_6_cursor.child_mask().iter() {
          v529_6_cursor.descend_to_existing_byte(v529_6_byte);
          {
          let v530_2: Path = concat_path(&(*v528_2_arg_1),&v529_6_cursor.path()[v529_6_origin..(v529_6_origin + 1)]);
          let v530_3: Space = routine_66(c, &(v530_2), &v526_19_cursor.path()[v526_19_origin..v528_2_depth], &(*v528_2_arg_2), &(*v528_2_arg_3), &v529_6_cursor);
          drop(v530_2);
          join_wrapped_into(&mut v526_19_write,&((v530_3).read_zipper()),&[]);
          }
          v529_6_cursor.ascend(1);
        }
        drop(v529_6_cursor);
        }
        v528_2_more = next_value_within(&mut v526_19_cursor,(v526_19_origin + 1));
      }
      }
      v526_19_cursor.ascend(1);
    }
    drop(v526_19_cursor);
    drop(v526_19_write);
    let v526_20: Space = map_map_kernels::unite(&(v526_16),&(v526_19));
    map_map_kernels::compose(&(v525_10),&(v526_20))
  };
  drop(v525_10);
  let v525_23: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v525_7));
  drop(v525_7);
  let v525_24: Space = if map_kernels::has_head(&(v525_23)) { singleton(&[]) } else { Space::new() };
  drop(v525_23);
  let v525_26: Space = if (&(v525_24)).is_empty() { Space::new() } else {
    let mut v531_25 = Space::new();
    let mut v531_25_write = v531_25.write_zipper();
    let mut v531_25_cursor = (*s0).read_zipper();
    let v531_25_origin = v531_25_cursor.path().len();
    for v531_25_byte in v531_25_cursor.child_mask().iter() {
      v531_25_cursor.descend_to_existing_byte(v531_25_byte);
      {
      let v532_2: Space = routine_102(c, &v531_25_cursor.path()[v531_25_origin..(v531_25_origin + 1)], &v531_25_cursor.path()[v531_25_origin..(v531_25_origin + 1)], &(*p2), &(*p3), &(*p0), &v531_25_cursor);
      join_wrapped_into(&mut v531_25_write,&((v532_2).read_zipper()),&[]);
      }
      v531_25_cursor.ascend(1);
    }
    drop(v531_25_cursor);
    drop(v531_25_write);
    map_map_kernels::compose(&(v525_24),&(v531_25))
  };
  drop(v525_24);
  let v525_27: Space = map_map_kernels::unite(&(v525_21),&(v525_26));
  (v525_27).clone()
}

fn routine_67(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v533_5: Space = singleton(&(*p0));
  let v533_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v533_5));
  let v533_7: Space = if map_kernels::has_head(&(v533_6)) { singleton(&[]) } else { Space::new() };
  drop(v533_6);
  let v533_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v533_7));
  drop(v533_7);
  let v533_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v533_5));
  drop(v533_5);
  let v533_14: Space = if map_kernels::has_head(&(v533_13)) { singleton(&[]) } else { Space::new() };
  drop(v533_13);
  let mut v533_15 = Space::new();
  let mut v533_15_write = v533_15.write_zipper();
  let mut v533_15_cursor = (*s0).read_zipper();
  let v533_15_origin = v533_15_cursor.path().len();
  for v533_15_byte in v533_15_cursor.child_mask().iter() {
    v533_15_cursor.descend_to_existing_byte(v533_15_byte);
    {
    let v534_4: Space = if (&(v533_8)).is_empty() { Space::new() } else {
      let v535_2: Path = concat_path(&(*p1),&v533_15_cursor.path()[v533_15_origin..(v533_15_origin + 1)]);
      let mut v535_3 = Space::new();
      let mut v535_3_write = v535_3.write_zipper();
      let v535_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v535_3_arg_1: &[u8] = &(v535_2);
      let v535_3_arg_3: &Space = &(&v533_15_cursor).make_map();
      let mut v535_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v535_3_origin = v535_3_cursor.path().len();
      let mut v535_3_more = v535_3_cursor.is_val() || next_value_within(&mut v535_3_cursor,v535_3_origin);
      while v535_3_more {
        {
        let v535_3_depth = v535_3_cursor.path().len();
        let v536_4: Space = routine_67(c, &v535_3_cursor.path()[v535_3_origin..v535_3_depth], &(*v535_3_arg_1), &((*v535_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v535_3_write,&((v536_4).read_zipper()),&[]);
        }
        v535_3_more = next_value_within(&mut v535_3_cursor,v535_3_origin);
      }
      drop(v535_3_cursor);
      drop(v535_3_write);
      map_map_kernels::compose(&(v533_8),&(v535_3))
    };
    let v534_6: Space = if (&(v533_14)).is_empty() { Space::new() } else {
      let v537_2: Path = concat_path(&(*p1),&v533_15_cursor.path()[v533_15_origin..(v533_15_origin + 1)]);
      let mut v537_5 = Space::new();
      let mut v537_5_write = v537_5.write_zipper();
      for v537_5_byte in v533_15_cursor.child_mask().iter() {
        v533_15_cursor.descend_to_existing_byte(v537_5_byte);
        {
        let v538_2: Space = routine_68(c, &v533_15_cursor.path()[(v533_15_origin + 1)..(v533_15_origin + 2)], &v533_15_cursor.path()[(v533_15_origin + 1)..(v533_15_origin + 2)], &(v537_2), &v533_15_cursor);
        join_wrapped_into(&mut v537_5_write,&((v538_2).read_zipper()),&[]);
        }
        v533_15_cursor.ascend(1);
      }
      drop(v537_5_write);
      drop(v537_2);
      map_map_kernels::compose(&(v533_14),&(v537_5))
    };
    let v534_7: Space = map_map_kernels::unite(&(v534_4),&(v534_6));
    join_wrapped_into(&mut v533_15_write,&((v534_7).read_zipper()),&[]);
    }
    v533_15_cursor.ascend(1);
  }
  drop(v533_15_cursor);
  drop(v533_15_write);
  drop(v533_8);
  drop(v533_14);
  (v533_15).clone()
}

fn routine_68(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v539_6: Space = singleton(&(*p1));
  let v539_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v539_6));
  let v539_8: Space = if map_kernels::has_head(&(v539_7)) { singleton(&[]) } else { Space::new() };
  drop(v539_7);
  let v539_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v539_8));
  drop(v539_8);
  let v539_20: Space = if (&(v539_9)).is_empty() { Space::new() } else {
    let v540_12: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v540_15: Space = if (&(v540_12)).is_empty() { Space::new() } else {
      let v541_14: Space = routine_103(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      map_map_kernels::compose(&(v540_12),&(v541_14))
    };
    drop(v540_12);
    let mut v540_18 = Space::new();
    let mut v540_18_write = v540_18.write_zipper();
    let mut v540_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v540_18_origin = v540_18_cursor.path().len();
    for v540_18_byte in v540_18_cursor.child_mask().iter() {
      v540_18_cursor.descend_to_existing_byte(v540_18_byte);
      {
      let v542_2_arg_0: &[u8] = &v540_18_cursor.path()[v540_18_origin..(v540_18_origin + 1)];
      let v542_2_arg_1: &[u8] = &(*p0);
      let v542_2_arg_2: &[u8] = &(*p2);
      let v542_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v542_2_more = v540_18_cursor.is_val() || next_value_within(&mut v540_18_cursor,(v540_18_origin + 1));
      while v542_2_more {
        {
        let v542_2_depth = v540_18_cursor.path().len();
        let mut v543_5_cursor = (*v542_2_arg_4).read_zipper();
        let v543_5_origin = v543_5_cursor.path().len();
        for v543_5_byte in v543_5_cursor.child_mask().iter() {
          v543_5_cursor.descend_to_existing_byte(v543_5_byte);
          {
          let v544_2: Path = concat_path(&(*v542_2_arg_1),&v543_5_cursor.path()[v543_5_origin..(v543_5_origin + 1)]);
          let v544_3: Space = routine_68(c, &(v544_2), &v540_18_cursor.path()[v540_18_origin..v542_2_depth], &(*v542_2_arg_2), &v543_5_cursor);
          drop(v544_2);
          join_wrapped_into(&mut v540_18_write,&((v544_3).read_zipper()),&[]);
          }
          v543_5_cursor.ascend(1);
        }
        drop(v543_5_cursor);
        }
        v542_2_more = next_value_within(&mut v540_18_cursor,(v540_18_origin + 1));
      }
      }
      v540_18_cursor.ascend(1);
    }
    drop(v540_18_cursor);
    drop(v540_18_write);
    let v540_19: Space = map_map_kernels::unite(&(v540_15),&(v540_18));
    map_map_kernels::compose(&(v539_9),&(v540_19))
  };
  drop(v539_9);
  let v539_22: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v539_6));
  drop(v539_6);
  let v539_23: Space = if map_kernels::has_head(&(v539_22)) { singleton(&[]) } else { Space::new() };
  drop(v539_22);
  let v539_25: Space = if (&(v539_23)).is_empty() { Space::new() } else {
    let mut v545_24 = Space::new();
    let mut v545_24_write = v545_24.write_zipper();
    let mut v545_24_cursor = (*s0).read_zipper();
    let v545_24_origin = v545_24_cursor.path().len();
    for v545_24_byte in v545_24_cursor.child_mask().iter() {
      v545_24_cursor.descend_to_existing_byte(v545_24_byte);
      {
      let v546_2: Space = routine_69(c, &v545_24_cursor.path()[v545_24_origin..(v545_24_origin + 1)], &v545_24_cursor.path()[v545_24_origin..(v545_24_origin + 1)], &(*p2), &(*p0), &v545_24_cursor);
      join_wrapped_into(&mut v545_24_write,&((v546_2).read_zipper()),&[]);
      }
      v545_24_cursor.ascend(1);
    }
    drop(v545_24_cursor);
    drop(v545_24_write);
    map_map_kernels::compose(&(v539_23),&(v545_24))
  };
  drop(v539_23);
  let v539_26: Space = map_map_kernels::unite(&(v539_20),&(v539_25));
  (v539_26).clone()
}

fn routine_69(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v547_7: Space = singleton(&(*p1));
  let v547_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v547_7));
  let v547_9: Space = if map_kernels::has_head(&(v547_8)) { singleton(&[]) } else { Space::new() };
  drop(v547_8);
  let v547_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v547_9));
  drop(v547_9);
  let v547_21: Space = if (&(v547_10)).is_empty() { Space::new() } else {
    let v548_13: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v548_16: Space = if (&(v548_13)).is_empty() { Space::new() } else {
      let v549_15: Space = routine_104(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      map_map_kernels::compose(&(v548_13),&(v549_15))
    };
    drop(v548_13);
    let mut v548_19 = Space::new();
    let mut v548_19_write = v548_19.write_zipper();
    let mut v548_19_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v548_19_origin = v548_19_cursor.path().len();
    for v548_19_byte in v548_19_cursor.child_mask().iter() {
      v548_19_cursor.descend_to_existing_byte(v548_19_byte);
      {
      let v550_2_arg_0: &[u8] = &v548_19_cursor.path()[v548_19_origin..(v548_19_origin + 1)];
      let v550_2_arg_1: &[u8] = &(*p0);
      let v550_2_arg_2: &[u8] = &(*p2);
      let v550_2_arg_3: &[u8] = &(*p3);
      let v550_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v550_2_more = v548_19_cursor.is_val() || next_value_within(&mut v548_19_cursor,(v548_19_origin + 1));
      while v550_2_more {
        {
        let v550_2_depth = v548_19_cursor.path().len();
        let mut v551_6_cursor = (*v550_2_arg_5).read_zipper();
        let v551_6_origin = v551_6_cursor.path().len();
        for v551_6_byte in v551_6_cursor.child_mask().iter() {
          v551_6_cursor.descend_to_existing_byte(v551_6_byte);
          {
          let v552_2: Path = concat_path(&(*v550_2_arg_1),&v551_6_cursor.path()[v551_6_origin..(v551_6_origin + 1)]);
          let v552_3: Space = routine_69(c, &(v552_2), &v548_19_cursor.path()[v548_19_origin..v550_2_depth], &(*v550_2_arg_2), &(*v550_2_arg_3), &v551_6_cursor);
          drop(v552_2);
          join_wrapped_into(&mut v548_19_write,&((v552_3).read_zipper()),&[]);
          }
          v551_6_cursor.ascend(1);
        }
        drop(v551_6_cursor);
        }
        v550_2_more = next_value_within(&mut v548_19_cursor,(v548_19_origin + 1));
      }
      }
      v548_19_cursor.ascend(1);
    }
    drop(v548_19_cursor);
    drop(v548_19_write);
    let v548_20: Space = map_map_kernels::unite(&(v548_16),&(v548_19));
    map_map_kernels::compose(&(v547_10),&(v548_20))
  };
  drop(v547_10);
  let v547_23: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v547_7));
  drop(v547_7);
  let v547_24: Space = if map_kernels::has_head(&(v547_23)) { singleton(&[]) } else { Space::new() };
  drop(v547_23);
  let v547_26: Space = if (&(v547_24)).is_empty() { Space::new() } else {
    let mut v553_25 = Space::new();
    let mut v553_25_write = v553_25.write_zipper();
    let mut v553_25_cursor = (*s0).read_zipper();
    let v553_25_origin = v553_25_cursor.path().len();
    for v553_25_byte in v553_25_cursor.child_mask().iter() {
      v553_25_cursor.descend_to_existing_byte(v553_25_byte);
      {
      let v554_2: Space = routine_105(c, &v553_25_cursor.path()[v553_25_origin..(v553_25_origin + 1)], &v553_25_cursor.path()[v553_25_origin..(v553_25_origin + 1)], &(*p2), &(*p3), &(*p0), &v553_25_cursor);
      join_wrapped_into(&mut v553_25_write,&((v554_2).read_zipper()),&[]);
      }
      v553_25_cursor.ascend(1);
    }
    drop(v553_25_cursor);
    drop(v553_25_write);
    map_map_kernels::compose(&(v547_24),&(v553_25))
  };
  drop(v547_24);
  let v547_27: Space = map_map_kernels::unite(&(v547_21),&(v547_26));
  (v547_27).clone()
}

fn routine_70(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v555_5: Space = singleton(&(*p0));
  let v555_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v555_5));
  let v555_7: Space = if map_kernels::has_head(&(v555_6)) { singleton(&[]) } else { Space::new() };
  drop(v555_6);
  let v555_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v555_7));
  drop(v555_7);
  let v555_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v555_5));
  drop(v555_5);
  let v555_14: Space = if map_kernels::has_head(&(v555_13)) { singleton(&[]) } else { Space::new() };
  drop(v555_13);
  let mut v555_15 = Space::new();
  let mut v555_15_write = v555_15.write_zipper();
  let mut v555_15_cursor = (*s0).read_zipper();
  let v555_15_origin = v555_15_cursor.path().len();
  for v555_15_byte in v555_15_cursor.child_mask().iter() {
    v555_15_cursor.descend_to_existing_byte(v555_15_byte);
    {
    let v556_4: Space = if (&(v555_8)).is_empty() { Space::new() } else {
      let v557_2: Path = concat_path(&(*p1),&v555_15_cursor.path()[v555_15_origin..(v555_15_origin + 1)]);
      let mut v557_3 = Space::new();
      let mut v557_3_write = v557_3.write_zipper();
      let v557_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v557_3_arg_1: &[u8] = &(v557_2);
      let v557_3_arg_3: &Space = &(&v555_15_cursor).make_map();
      let mut v557_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v557_3_origin = v557_3_cursor.path().len();
      let mut v557_3_more = v557_3_cursor.is_val() || next_value_within(&mut v557_3_cursor,v557_3_origin);
      while v557_3_more {
        {
        let v557_3_depth = v557_3_cursor.path().len();
        let v558_4: Space = routine_70(c, &v557_3_cursor.path()[v557_3_origin..v557_3_depth], &(*v557_3_arg_1), &((*v557_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v557_3_write,&((v558_4).read_zipper()),&[]);
        }
        v557_3_more = next_value_within(&mut v557_3_cursor,v557_3_origin);
      }
      drop(v557_3_cursor);
      drop(v557_3_write);
      map_map_kernels::compose(&(v555_8),&(v557_3))
    };
    let v556_6: Space = if (&(v555_14)).is_empty() { Space::new() } else {
      let v559_2: Path = concat_path(&(*p1),&v555_15_cursor.path()[v555_15_origin..(v555_15_origin + 1)]);
      let mut v559_5 = Space::new();
      let mut v559_5_write = v559_5.write_zipper();
      for v559_5_byte in v555_15_cursor.child_mask().iter() {
        v555_15_cursor.descend_to_existing_byte(v559_5_byte);
        {
        let v560_2: Space = routine_71(c, &v555_15_cursor.path()[(v555_15_origin + 1)..(v555_15_origin + 2)], &v555_15_cursor.path()[(v555_15_origin + 1)..(v555_15_origin + 2)], &(v559_2), &v555_15_cursor);
        join_wrapped_into(&mut v559_5_write,&((v560_2).read_zipper()),&[]);
        }
        v555_15_cursor.ascend(1);
      }
      drop(v559_5_write);
      drop(v559_2);
      map_map_kernels::compose(&(v555_14),&(v559_5))
    };
    let v556_7: Space = map_map_kernels::unite(&(v556_4),&(v556_6));
    join_wrapped_into(&mut v555_15_write,&((v556_7).read_zipper()),&[]);
    }
    v555_15_cursor.ascend(1);
  }
  drop(v555_15_cursor);
  drop(v555_15_write);
  drop(v555_8);
  drop(v555_14);
  (v555_15).clone()
}

fn routine_71(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v561_6: Space = singleton(&(*p1));
  let v561_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v561_6));
  let v561_8: Space = if map_kernels::has_head(&(v561_7)) { singleton(&[]) } else { Space::new() };
  drop(v561_7);
  let v561_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v561_8));
  drop(v561_8);
  let v561_20: Space = if (&(v561_9)).is_empty() { Space::new() } else {
    let v562_12: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v562_15: Space = if (&(v562_12)).is_empty() { Space::new() } else {
      let v563_14: Space = routine_106(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      map_map_kernels::compose(&(v562_12),&(v563_14))
    };
    drop(v562_12);
    let mut v562_18 = Space::new();
    let mut v562_18_write = v562_18.write_zipper();
    let mut v562_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v562_18_origin = v562_18_cursor.path().len();
    for v562_18_byte in v562_18_cursor.child_mask().iter() {
      v562_18_cursor.descend_to_existing_byte(v562_18_byte);
      {
      let v564_2_arg_0: &[u8] = &v562_18_cursor.path()[v562_18_origin..(v562_18_origin + 1)];
      let v564_2_arg_1: &[u8] = &(*p0);
      let v564_2_arg_2: &[u8] = &(*p2);
      let v564_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v564_2_more = v562_18_cursor.is_val() || next_value_within(&mut v562_18_cursor,(v562_18_origin + 1));
      while v564_2_more {
        {
        let v564_2_depth = v562_18_cursor.path().len();
        let mut v565_5_cursor = (*v564_2_arg_4).read_zipper();
        let v565_5_origin = v565_5_cursor.path().len();
        for v565_5_byte in v565_5_cursor.child_mask().iter() {
          v565_5_cursor.descend_to_existing_byte(v565_5_byte);
          {
          let v566_2: Path = concat_path(&(*v564_2_arg_1),&v565_5_cursor.path()[v565_5_origin..(v565_5_origin + 1)]);
          let v566_3: Space = routine_71(c, &(v566_2), &v562_18_cursor.path()[v562_18_origin..v564_2_depth], &(*v564_2_arg_2), &v565_5_cursor);
          drop(v566_2);
          join_wrapped_into(&mut v562_18_write,&((v566_3).read_zipper()),&[]);
          }
          v565_5_cursor.ascend(1);
        }
        drop(v565_5_cursor);
        }
        v564_2_more = next_value_within(&mut v562_18_cursor,(v562_18_origin + 1));
      }
      }
      v562_18_cursor.ascend(1);
    }
    drop(v562_18_cursor);
    drop(v562_18_write);
    let v562_19: Space = map_map_kernels::unite(&(v562_15),&(v562_18));
    map_map_kernels::compose(&(v561_9),&(v562_19))
  };
  drop(v561_9);
  let v561_22: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v561_6));
  drop(v561_6);
  let v561_23: Space = if map_kernels::has_head(&(v561_22)) { singleton(&[]) } else { Space::new() };
  drop(v561_22);
  let v561_25: Space = if (&(v561_23)).is_empty() { Space::new() } else {
    let mut v567_24 = Space::new();
    let mut v567_24_write = v567_24.write_zipper();
    let mut v567_24_cursor = (*s0).read_zipper();
    let v567_24_origin = v567_24_cursor.path().len();
    for v567_24_byte in v567_24_cursor.child_mask().iter() {
      v567_24_cursor.descend_to_existing_byte(v567_24_byte);
      {
      let v568_2: Space = routine_72(c, &v567_24_cursor.path()[v567_24_origin..(v567_24_origin + 1)], &v567_24_cursor.path()[v567_24_origin..(v567_24_origin + 1)], &(*p2), &(*p0), &v567_24_cursor);
      join_wrapped_into(&mut v567_24_write,&((v568_2).read_zipper()),&[]);
      }
      v567_24_cursor.ascend(1);
    }
    drop(v567_24_cursor);
    drop(v567_24_write);
    map_map_kernels::compose(&(v561_23),&(v567_24))
  };
  drop(v561_23);
  let v561_26: Space = map_map_kernels::unite(&(v561_20),&(v561_25));
  (v561_26).clone()
}

fn routine_72(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v569_7: Space = singleton(&(*p1));
  let v569_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v569_7));
  let v569_9: Space = if map_kernels::has_head(&(v569_8)) { singleton(&[]) } else { Space::new() };
  drop(v569_8);
  let v569_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v569_9));
  drop(v569_9);
  let v569_21: Space = if (&(v569_10)).is_empty() { Space::new() } else {
    let v570_13: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v570_16: Space = if (&(v570_13)).is_empty() { Space::new() } else {
      let v571_15: Space = routine_107(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      map_map_kernels::compose(&(v570_13),&(v571_15))
    };
    drop(v570_13);
    let mut v570_19 = Space::new();
    let mut v570_19_write = v570_19.write_zipper();
    let mut v570_19_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v570_19_origin = v570_19_cursor.path().len();
    for v570_19_byte in v570_19_cursor.child_mask().iter() {
      v570_19_cursor.descend_to_existing_byte(v570_19_byte);
      {
      let v572_2_arg_0: &[u8] = &v570_19_cursor.path()[v570_19_origin..(v570_19_origin + 1)];
      let v572_2_arg_1: &[u8] = &(*p0);
      let v572_2_arg_2: &[u8] = &(*p2);
      let v572_2_arg_3: &[u8] = &(*p3);
      let v572_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v572_2_more = v570_19_cursor.is_val() || next_value_within(&mut v570_19_cursor,(v570_19_origin + 1));
      while v572_2_more {
        {
        let v572_2_depth = v570_19_cursor.path().len();
        let mut v573_6_cursor = (*v572_2_arg_5).read_zipper();
        let v573_6_origin = v573_6_cursor.path().len();
        for v573_6_byte in v573_6_cursor.child_mask().iter() {
          v573_6_cursor.descend_to_existing_byte(v573_6_byte);
          {
          let v574_2: Path = concat_path(&(*v572_2_arg_1),&v573_6_cursor.path()[v573_6_origin..(v573_6_origin + 1)]);
          let v574_3: Space = routine_72(c, &(v574_2), &v570_19_cursor.path()[v570_19_origin..v572_2_depth], &(*v572_2_arg_2), &(*v572_2_arg_3), &v573_6_cursor);
          drop(v574_2);
          join_wrapped_into(&mut v570_19_write,&((v574_3).read_zipper()),&[]);
          }
          v573_6_cursor.ascend(1);
        }
        drop(v573_6_cursor);
        }
        v572_2_more = next_value_within(&mut v570_19_cursor,(v570_19_origin + 1));
      }
      }
      v570_19_cursor.ascend(1);
    }
    drop(v570_19_cursor);
    drop(v570_19_write);
    let v570_20: Space = map_map_kernels::unite(&(v570_16),&(v570_19));
    map_map_kernels::compose(&(v569_10),&(v570_20))
  };
  drop(v569_10);
  let v569_23: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v569_7));
  drop(v569_7);
  let v569_24: Space = if map_kernels::has_head(&(v569_23)) { singleton(&[]) } else { Space::new() };
  drop(v569_23);
  let v569_26: Space = if (&(v569_24)).is_empty() { Space::new() } else {
    let mut v575_25 = Space::new();
    let mut v575_25_write = v575_25.write_zipper();
    let mut v575_25_cursor = (*s0).read_zipper();
    let v575_25_origin = v575_25_cursor.path().len();
    for v575_25_byte in v575_25_cursor.child_mask().iter() {
      v575_25_cursor.descend_to_existing_byte(v575_25_byte);
      {
      let v576_2: Space = routine_108(c, &v575_25_cursor.path()[v575_25_origin..(v575_25_origin + 1)], &v575_25_cursor.path()[v575_25_origin..(v575_25_origin + 1)], &(*p2), &(*p3), &(*p0), &v575_25_cursor);
      join_wrapped_into(&mut v575_25_write,&((v576_2).read_zipper()),&[]);
      }
      v575_25_cursor.ascend(1);
    }
    drop(v575_25_cursor);
    drop(v575_25_write);
    map_map_kernels::compose(&(v569_24),&(v575_25))
  };
  drop(v569_24);
  let v569_27: Space = map_map_kernels::unite(&(v569_21),&(v569_26));
  (v569_27).clone()
}

fn routine_73(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v577_9: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let mut v578_8 = Space::new();
    let mut v578_8_write = v578_8.write_zipper();
    let v578_8_arg_0: &[u8] = &(*CONSTANT_1);
    let v578_8_arg_1: &[u8] = &(*CONSTANT_2);
    let v578_8_arg_3: &Space = &(*CONSTANT_16);
    let mut v578_8_cursor = (*CONSTANT_3).read_zipper();
    let v578_8_origin = v578_8_cursor.path().len();
    let mut v578_8_more = v578_8_cursor.is_val() || next_value_within(&mut v578_8_cursor,v578_8_origin);
    while v578_8_more {
      {
      let v578_8_depth = v578_8_cursor.path().len();
      let mut v579_4_cursor = (*v578_8_arg_3).read_zipper();
      let v579_4_origin = v579_4_cursor.path().len();
      for v579_4_byte in v579_4_cursor.child_mask().iter() {
        v579_4_cursor.descend_to_existing_byte(v579_4_byte);
        {
        let v580_2: Path = concat_path(&(*v578_8_arg_1),&v579_4_cursor.path()[v579_4_origin..(v579_4_origin + 1)]);
        let v580_3: Space = routine_41(c, &(v580_2), &v578_8_cursor.path()[v578_8_origin..v578_8_depth], &v579_4_cursor);
        drop(v580_2);
        join_wrapped_into(&mut v578_8_write,&((v580_3).read_zipper()),&[]);
        }
        v579_4_cursor.ascend(1);
      }
      drop(v579_4_cursor);
      }
      v578_8_more = next_value_within(&mut v578_8_cursor,v578_8_origin);
    }
    drop(v578_8_cursor);
    drop(v578_8_write);
    map_map_kernels::compose(&(*CONSTANT_0),&(v578_8))
  };
  let mut v577_15 = Space::new();
  let mut v577_15_write = v577_15.write_zipper();
  let mut v577_15_cursor = descend_cursor((v577_9).read_zipper(),&(*p1));
  let v577_15_origin = v577_15_cursor.path().len();
  for v577_15_byte in v577_15_cursor.child_mask().iter() {
    v577_15_cursor.descend_to_existing_byte(v577_15_byte);
    {
    let v581_2: Space = singleton(&v577_15_cursor.path()[v577_15_origin..(v577_15_origin + 1)]);
    let v581_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v581_2));
    let v581_4: Space = if map_kernels::has_head(&(v581_3)) { singleton(&[]) } else { Space::new() };
    drop(v581_3);
    let v581_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v581_4));
    drop(v581_4);
    let v581_8: Space = if (&(v581_5)).is_empty() { Space::new() } else {
      let mut v582_7 = Space::new();
      let mut v582_7_write = v582_7.write_zipper();
      let v582_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v582_7_arg_1: &[u8] = &v577_15_cursor.path()[v577_15_origin..(v577_15_origin + 1)];
      let v582_7_arg_2: &[u8] = &(*p0);
      let v582_7_arg_4: &Space = &(&v577_15_cursor).make_map();
      let v582_7_arg_5: &Space = &(&(*s0)).make_map();
      let mut v582_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v577_15_cursor.path()[v577_15_origin..(v577_15_origin + 1)]);
      let v582_7_origin = v582_7_cursor.path().len();
      let mut v582_7_more = v582_7_cursor.is_val() || next_value_within(&mut v582_7_cursor,v582_7_origin);
      while v582_7_more {
        {
        let v582_7_depth = v582_7_cursor.path().len();
        let mut v583_6_cursor = (*v582_7_arg_4).read_zipper();
        let v583_6_origin = v583_6_cursor.path().len();
        for v583_6_byte in v583_6_cursor.child_mask().iter() {
          v583_6_cursor.descend_to_existing_byte(v583_6_byte);
          {
          let v584_2: Path = concat_path(&(*v582_7_arg_1),&v583_6_cursor.path()[v583_6_origin..(v583_6_origin + 1)]);
          let v584_3: Space = routine_42(c, &(v584_2), &v582_7_cursor.path()[v582_7_origin..v582_7_depth], &(*v582_7_arg_2), &v583_6_cursor, &((*v582_7_arg_5).read_zipper()));
          drop(v584_2);
          join_wrapped_into(&mut v582_7_write,&((v584_3).read_zipper()),&[]);
          }
          v583_6_cursor.ascend(1);
        }
        drop(v583_6_cursor);
        }
        v582_7_more = next_value_within(&mut v582_7_cursor,v582_7_origin);
      }
      drop(v582_7_cursor);
      drop(v582_7_write);
      map_map_kernels::compose(&(v581_5),&(v582_7))
    };
    drop(v581_5);
    let v581_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v581_2));
    drop(v581_2);
    let v581_10: Space = if map_kernels::has_head(&(v581_9)) { singleton(&[]) } else { Space::new() };
    drop(v581_9);
    let v581_14: Space = if (&(v581_10)).is_empty() { Space::new() } else {
      let v585_12: Space = view_kernels::wrap(&(descend_cursor(cursor_at(&v577_15_cursor,(v577_15_origin + 1)),&(*p0))),&v577_15_cursor.path()[v577_15_origin..(v577_15_origin + 1)]);
      let v585_13: Space = map_view_kernels::compose(&(v585_12),&(*s0));
      drop(v585_12);
      map_map_kernels::compose(&(v581_10),&(v585_13))
    };
    drop(v581_10);
    let v581_15: Space = map_map_kernels::unite(&(v581_8),&(v581_14));
    drop(v581_14);
    join_wrapped_into(&mut v577_15_write,&((v581_15).read_zipper()),&[]);
    }
    v577_15_cursor.ascend(1);
  }
  drop(v577_15_cursor);
  drop(v577_15_write);
  (v577_15).clone()
}

fn routine_74(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v586_5: Space = singleton(&(*p0));
  let v586_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v586_5));
  let v586_7: Space = if map_kernels::has_head(&(v586_6)) { singleton(&[]) } else { Space::new() };
  drop(v586_6);
  let v586_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v586_7));
  drop(v586_7);
  let v586_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v586_5));
  drop(v586_5);
  let v586_14: Space = if map_kernels::has_head(&(v586_13)) { singleton(&[]) } else { Space::new() };
  drop(v586_13);
  let mut v586_15 = Space::new();
  let mut v586_15_write = v586_15.write_zipper();
  let mut v586_15_cursor = (*s0).read_zipper();
  let v586_15_origin = v586_15_cursor.path().len();
  for v586_15_byte in v586_15_cursor.child_mask().iter() {
    v586_15_cursor.descend_to_existing_byte(v586_15_byte);
    {
    let v587_4: Space = if (&(v586_8)).is_empty() { Space::new() } else {
      let v588_2: Path = concat_path(&(*p1),&v586_15_cursor.path()[v586_15_origin..(v586_15_origin + 1)]);
      let mut v588_3 = Space::new();
      let mut v588_3_write = v588_3.write_zipper();
      let v588_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v588_3_arg_1: &[u8] = &(v588_2);
      let v588_3_arg_3: &Space = &(&v586_15_cursor).make_map();
      let mut v588_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v588_3_origin = v588_3_cursor.path().len();
      let mut v588_3_more = v588_3_cursor.is_val() || next_value_within(&mut v588_3_cursor,v588_3_origin);
      while v588_3_more {
        {
        let v588_3_depth = v588_3_cursor.path().len();
        let v589_4: Space = routine_74(c, &v588_3_cursor.path()[v588_3_origin..v588_3_depth], &(*v588_3_arg_1), &((*v588_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v588_3_write,&((v589_4).read_zipper()),&[]);
        }
        v588_3_more = next_value_within(&mut v588_3_cursor,v588_3_origin);
      }
      drop(v588_3_cursor);
      drop(v588_3_write);
      map_map_kernels::compose(&(v586_8),&(v588_3))
    };
    let v587_6: Space = if (&(v586_14)).is_empty() { Space::new() } else {
      let v590_2: Path = concat_path(&(*p1),&v586_15_cursor.path()[v586_15_origin..(v586_15_origin + 1)]);
      let mut v590_5 = Space::new();
      let mut v590_5_write = v590_5.write_zipper();
      for v590_5_byte in v586_15_cursor.child_mask().iter() {
        v586_15_cursor.descend_to_existing_byte(v590_5_byte);
        {
        let v591_2: Space = routine_75(c, &v586_15_cursor.path()[(v586_15_origin + 1)..(v586_15_origin + 2)], &v586_15_cursor.path()[(v586_15_origin + 1)..(v586_15_origin + 2)], &(v590_2), &v586_15_cursor);
        join_wrapped_into(&mut v590_5_write,&((v591_2).read_zipper()),&[]);
        }
        v586_15_cursor.ascend(1);
      }
      drop(v590_5_write);
      drop(v590_2);
      map_map_kernels::compose(&(v586_14),&(v590_5))
    };
    let v587_7: Space = map_map_kernels::unite(&(v587_4),&(v587_6));
    join_wrapped_into(&mut v586_15_write,&((v587_7).read_zipper()),&[]);
    }
    v586_15_cursor.ascend(1);
  }
  drop(v586_15_cursor);
  drop(v586_15_write);
  drop(v586_8);
  drop(v586_14);
  (v586_15).clone()
}

fn routine_75(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v592_6: Space = singleton(&(*p1));
  let v592_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v592_6));
  let v592_8: Space = if map_kernels::has_head(&(v592_7)) { singleton(&[]) } else { Space::new() };
  drop(v592_7);
  let v592_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v592_8));
  drop(v592_8);
  let v592_20: Space = if (&(v592_9)).is_empty() { Space::new() } else {
    let v593_12: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v593_15: Space = if (&(v593_12)).is_empty() { Space::new() } else {
      let v594_14: Space = routine_109(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      map_map_kernels::compose(&(v593_12),&(v594_14))
    };
    drop(v593_12);
    let mut v593_18 = Space::new();
    let mut v593_18_write = v593_18.write_zipper();
    let mut v593_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v593_18_origin = v593_18_cursor.path().len();
    for v593_18_byte in v593_18_cursor.child_mask().iter() {
      v593_18_cursor.descend_to_existing_byte(v593_18_byte);
      {
      let v595_2_arg_0: &[u8] = &v593_18_cursor.path()[v593_18_origin..(v593_18_origin + 1)];
      let v595_2_arg_1: &[u8] = &(*p0);
      let v595_2_arg_2: &[u8] = &(*p2);
      let v595_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v595_2_more = v593_18_cursor.is_val() || next_value_within(&mut v593_18_cursor,(v593_18_origin + 1));
      while v595_2_more {
        {
        let v595_2_depth = v593_18_cursor.path().len();
        let mut v596_5_cursor = (*v595_2_arg_4).read_zipper();
        let v596_5_origin = v596_5_cursor.path().len();
        for v596_5_byte in v596_5_cursor.child_mask().iter() {
          v596_5_cursor.descend_to_existing_byte(v596_5_byte);
          {
          let v597_2: Path = concat_path(&(*v595_2_arg_1),&v596_5_cursor.path()[v596_5_origin..(v596_5_origin + 1)]);
          let v597_3: Space = routine_75(c, &(v597_2), &v593_18_cursor.path()[v593_18_origin..v595_2_depth], &(*v595_2_arg_2), &v596_5_cursor);
          drop(v597_2);
          join_wrapped_into(&mut v593_18_write,&((v597_3).read_zipper()),&[]);
          }
          v596_5_cursor.ascend(1);
        }
        drop(v596_5_cursor);
        }
        v595_2_more = next_value_within(&mut v593_18_cursor,(v593_18_origin + 1));
      }
      }
      v593_18_cursor.ascend(1);
    }
    drop(v593_18_cursor);
    drop(v593_18_write);
    let v593_19: Space = map_map_kernels::unite(&(v593_15),&(v593_18));
    map_map_kernels::compose(&(v592_9),&(v593_19))
  };
  drop(v592_9);
  let v592_22: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v592_6));
  drop(v592_6);
  let v592_23: Space = if map_kernels::has_head(&(v592_22)) { singleton(&[]) } else { Space::new() };
  drop(v592_22);
  let v592_28: Space = if (&(v592_23)).is_empty() { Space::new() } else {
    let mut v598_25 = Space::new();
    let mut v598_25_write = v598_25.write_zipper();
    let mut v598_25_cursor = (*s0).read_zipper();
    let v598_25_origin = v598_25_cursor.path().len();
    for v598_25_byte in v598_25_cursor.child_mask().iter() {
      v598_25_cursor.descend_to_existing_byte(v598_25_byte);
      {
      let v599_2: Space = routine_110(c, &v598_25_cursor.path()[v598_25_origin..(v598_25_origin + 1)], &v598_25_cursor.path()[v598_25_origin..(v598_25_origin + 1)], &v598_25_cursor);
      join_wrapped_into(&mut v598_25_write,&((v599_2).read_zipper()),&[]);
      }
      v598_25_cursor.ascend(1);
    }
    drop(v598_25_cursor);
    drop(v598_25_write);
    let v598_26: Space = map_map_kernels::raffine(&(*CONSTANT_17),&(v598_25));
    let v598_27: Space = map_view_kernels::unite(&(v598_26),&(*s0));
    map_map_kernels::compose(&(v592_23),&(v598_27))
  };
  drop(v592_23);
  let v592_29: Path = concat_path(&(*p2),&(*p0));
  let v592_30: Space = map_kernels::wrap(&(v592_28),&(v592_29));
  drop(v592_29);
  let v592_31: Space = map_map_kernels::unite(&(v592_20),&(v592_30));
  (v592_31).clone()
}

fn routine_76(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v600_7: Space = singleton(&(*p0));
  let v600_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v600_7));
  let v600_9: Space = if map_kernels::has_head(&(v600_8)) { singleton(&[]) } else { Space::new() };
  drop(v600_8);
  let v600_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v600_9));
  drop(v600_9);
  let v600_15: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v600_7));
  drop(v600_7);
  let v600_16: Space = if map_kernels::has_head(&(v600_15)) { singleton(&[]) } else { Space::new() };
  drop(v600_15);
  let mut v600_17 = Space::new();
  let mut v600_17_write = v600_17.write_zipper();
  let mut v600_17_cursor = (*s0).read_zipper();
  let v600_17_origin = v600_17_cursor.path().len();
  for v600_17_byte in v600_17_cursor.child_mask().iter() {
    v600_17_cursor.descend_to_existing_byte(v600_17_byte);
    {
    let v601_4: Space = if (&(v600_10)).is_empty() { Space::new() } else {
      let v602_2: Path = concat_path(&(*p1),&v600_17_cursor.path()[v600_17_origin..(v600_17_origin + 1)]);
      let mut v602_3 = Space::new();
      let mut v602_3_write = v602_3.write_zipper();
      let v602_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v602_3_arg_1: &[u8] = &(v602_2);
      let v602_3_arg_2: &[u8] = &(*p2);
      let v602_3_arg_4: &Space = &(&v600_17_cursor).make_map();
      let v602_3_arg_5: &Space = &(&(*s1)).make_map();
      let mut v602_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v602_3_origin = v602_3_cursor.path().len();
      let mut v602_3_more = v602_3_cursor.is_val() || next_value_within(&mut v602_3_cursor,v602_3_origin);
      while v602_3_more {
        {
        let v602_3_depth = v602_3_cursor.path().len();
        let v603_6: Space = routine_76(c, &v602_3_cursor.path()[v602_3_origin..v602_3_depth], &(*v602_3_arg_1), &(*v602_3_arg_2), &((*v602_3_arg_4).read_zipper()), &((*v602_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v602_3_write,&((v603_6).read_zipper()),&[]);
        }
        v602_3_more = next_value_within(&mut v602_3_cursor,v602_3_origin);
      }
      drop(v602_3_cursor);
      drop(v602_3_write);
      map_map_kernels::compose(&(v600_10),&(v602_3))
    };
    let v601_8: Space = if (&(v600_16)).is_empty() { Space::new() } else {
      let v604_2: Path = concat_path(&(*p1),&v600_17_cursor.path()[v600_17_origin..(v600_17_origin + 1)]);
      let v604_6: Space = view_kernels::wrap(&(descend_cursor(cursor_at(&v600_17_cursor,(v600_17_origin + 1)),&(*p2))),&(v604_2));
      drop(v604_2);
      let v604_7: Space = map_view_kernels::compose(&(v604_6),&(*s1));
      drop(v604_6);
      map_map_kernels::compose(&(v600_16),&(v604_7))
    };
    let v601_9: Space = map_map_kernels::unite(&(v601_4),&(v601_8));
    drop(v601_8);
    join_wrapped_into(&mut v600_17_write,&((v601_9).read_zipper()),&[]);
    }
    v600_17_cursor.ascend(1);
  }
  drop(v600_17_cursor);
  drop(v600_17_write);
  drop(v600_10);
  drop(v600_16);
  (v600_17).clone()
}

fn routine_77(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v605_9: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let mut v606_8 = Space::new();
    let mut v606_8_write = v606_8.write_zipper();
    let v606_8_arg_0: &[u8] = &(*CONSTANT_1);
    let v606_8_arg_1: &[u8] = &(*CONSTANT_2);
    let v606_8_arg_3: &Space = &(*CONSTANT_16);
    let mut v606_8_cursor = (*CONSTANT_3).read_zipper();
    let v606_8_origin = v606_8_cursor.path().len();
    let mut v606_8_more = v606_8_cursor.is_val() || next_value_within(&mut v606_8_cursor,v606_8_origin);
    while v606_8_more {
      {
      let v606_8_depth = v606_8_cursor.path().len();
      let mut v607_4_cursor = (*v606_8_arg_3).read_zipper();
      let v607_4_origin = v607_4_cursor.path().len();
      for v607_4_byte in v607_4_cursor.child_mask().iter() {
        v607_4_cursor.descend_to_existing_byte(v607_4_byte);
        {
        let v608_2: Path = concat_path(&(*v606_8_arg_1),&v607_4_cursor.path()[v607_4_origin..(v607_4_origin + 1)]);
        let v608_3: Space = routine_44(c, &(v608_2), &v606_8_cursor.path()[v606_8_origin..v606_8_depth], &v607_4_cursor);
        drop(v608_2);
        join_wrapped_into(&mut v606_8_write,&((v608_3).read_zipper()),&[]);
        }
        v607_4_cursor.ascend(1);
      }
      drop(v607_4_cursor);
      }
      v606_8_more = next_value_within(&mut v606_8_cursor,v606_8_origin);
    }
    drop(v606_8_cursor);
    drop(v606_8_write);
    map_map_kernels::compose(&(*CONSTANT_0),&(v606_8))
  };
  let mut v605_17 = Space::new();
  let mut v605_17_write = v605_17.write_zipper();
  let mut v605_17_cursor = descend_cursor(descend_cursor(descend_cursor((v605_9).read_zipper(),&(*p1)),&(*p0)),&(*p1));
  let v605_17_origin = v605_17_cursor.path().len();
  for v605_17_byte in v605_17_cursor.child_mask().iter() {
    v605_17_cursor.descend_to_existing_byte(v605_17_byte);
    {
    let v609_2: Space = singleton(&v605_17_cursor.path()[v605_17_origin..(v605_17_origin + 1)]);
    let v609_3: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v609_2));
    let v609_4: Space = if map_kernels::has_head(&(v609_3)) { singleton(&[]) } else { Space::new() };
    drop(v609_3);
    let v609_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v609_4));
    drop(v609_4);
    let v609_8: Space = if (&(v609_5)).is_empty() { Space::new() } else {
      let mut v610_7 = Space::new();
      let mut v610_7_write = v610_7.write_zipper();
      let v610_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v610_7_arg_1: &[u8] = &v605_17_cursor.path()[v605_17_origin..(v605_17_origin + 1)];
      let v610_7_arg_3: &Space = &(&v605_17_cursor).make_map();
      let v610_7_arg_4: &Space = &(&(*s0)).make_map();
      let mut v610_7_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&v605_17_cursor.path()[v605_17_origin..(v605_17_origin + 1)]);
      let v610_7_origin = v610_7_cursor.path().len();
      let mut v610_7_more = v610_7_cursor.is_val() || next_value_within(&mut v610_7_cursor,v610_7_origin);
      while v610_7_more {
        {
        let v610_7_depth = v610_7_cursor.path().len();
        let mut v611_5_cursor = (*v610_7_arg_3).read_zipper();
        let v611_5_origin = v611_5_cursor.path().len();
        for v611_5_byte in v611_5_cursor.child_mask().iter() {
          v611_5_cursor.descend_to_existing_byte(v611_5_byte);
          {
          let v612_2: Path = concat_path(&(*v610_7_arg_1),&v611_5_cursor.path()[v611_5_origin..(v611_5_origin + 1)]);
          let v612_3: Space = routine_45(c, &(v612_2), &v610_7_cursor.path()[v610_7_origin..v610_7_depth], &v611_5_cursor, &((*v610_7_arg_4).read_zipper()));
          drop(v612_2);
          join_wrapped_into(&mut v610_7_write,&((v612_3).read_zipper()),&[]);
          }
          v611_5_cursor.ascend(1);
        }
        drop(v611_5_cursor);
        }
        v610_7_more = next_value_within(&mut v610_7_cursor,v610_7_origin);
      }
      drop(v610_7_cursor);
      drop(v610_7_write);
      map_map_kernels::compose(&(v609_5),&(v610_7))
    };
    drop(v609_5);
    let v609_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v609_2));
    drop(v609_2);
    let v609_10: Space = if map_kernels::has_head(&(v609_9)) { singleton(&[]) } else { Space::new() };
    drop(v609_9);
    let v609_12: Space = if (&(v609_10)).is_empty() { Space::new() } else {
      let v613_11: Space = routine_81(c, &v605_17_cursor.path()[v605_17_origin..(v605_17_origin + 1)], &(*s0));
      map_map_kernels::compose(&(v609_10),&(v613_11))
    };
    drop(v609_10);
    let v609_13: Space = map_map_kernels::unite(&(v609_8),&(v609_12));
    join_wrapped_into(&mut v605_17_write,&((v609_13).read_zipper()),&[]);
    }
    v605_17_cursor.ascend(1);
  }
  drop(v605_17_cursor);
  drop(v605_17_write);
  (v605_17).clone()
}

fn routine_78(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v614_5: Space = singleton(&(*p0));
  let v614_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v614_5));
  let v614_7: Space = if map_kernels::has_head(&(v614_6)) { singleton(&[]) } else { Space::new() };
  drop(v614_6);
  let v614_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v614_7));
  drop(v614_7);
  let v614_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v614_5));
  drop(v614_5);
  let v614_14: Space = if map_kernels::has_head(&(v614_13)) { singleton(&[]) } else { Space::new() };
  drop(v614_13);
  let mut v614_15 = Space::new();
  let mut v614_15_write = v614_15.write_zipper();
  let mut v614_15_cursor = (*s0).read_zipper();
  let v614_15_origin = v614_15_cursor.path().len();
  for v614_15_byte in v614_15_cursor.child_mask().iter() {
    v614_15_cursor.descend_to_existing_byte(v614_15_byte);
    {
    let v615_4: Space = if (&(v614_8)).is_empty() { Space::new() } else {
      let v616_2: Path = concat_path(&(*p1),&v614_15_cursor.path()[v614_15_origin..(v614_15_origin + 1)]);
      let mut v616_3 = Space::new();
      let mut v616_3_write = v616_3.write_zipper();
      let v616_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v616_3_arg_1: &[u8] = &(v616_2);
      let v616_3_arg_3: &Space = &(&v614_15_cursor).make_map();
      let mut v616_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v616_3_origin = v616_3_cursor.path().len();
      let mut v616_3_more = v616_3_cursor.is_val() || next_value_within(&mut v616_3_cursor,v616_3_origin);
      while v616_3_more {
        {
        let v616_3_depth = v616_3_cursor.path().len();
        let v617_4: Space = routine_78(c, &v616_3_cursor.path()[v616_3_origin..v616_3_depth], &(*v616_3_arg_1), &((*v616_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v616_3_write,&((v617_4).read_zipper()),&[]);
        }
        v616_3_more = next_value_within(&mut v616_3_cursor,v616_3_origin);
      }
      drop(v616_3_cursor);
      drop(v616_3_write);
      map_map_kernels::compose(&(v614_8),&(v616_3))
    };
    let v615_6: Space = if (&(v614_14)).is_empty() { Space::new() } else {
      let v618_2: Path = concat_path(&(*p1),&v614_15_cursor.path()[v614_15_origin..(v614_15_origin + 1)]);
      let mut v618_5 = Space::new();
      let mut v618_5_write = v618_5.write_zipper();
      for v618_5_byte in v614_15_cursor.child_mask().iter() {
        v614_15_cursor.descend_to_existing_byte(v618_5_byte);
        {
        let v619_2: Space = routine_79(c, &v614_15_cursor.path()[(v614_15_origin + 1)..(v614_15_origin + 2)], &v614_15_cursor.path()[(v614_15_origin + 1)..(v614_15_origin + 2)], &(v618_2), &v614_15_cursor);
        join_wrapped_into(&mut v618_5_write,&((v619_2).read_zipper()),&[]);
        }
        v614_15_cursor.ascend(1);
      }
      drop(v618_5_write);
      drop(v618_2);
      map_map_kernels::compose(&(v614_14),&(v618_5))
    };
    let v615_7: Space = map_map_kernels::unite(&(v615_4),&(v615_6));
    join_wrapped_into(&mut v614_15_write,&((v615_7).read_zipper()),&[]);
    }
    v614_15_cursor.ascend(1);
  }
  drop(v614_15_cursor);
  drop(v614_15_write);
  drop(v614_8);
  drop(v614_14);
  (v614_15).clone()
}

fn routine_79(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v620_6: Space = singleton(&(*p1));
  let v620_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v620_6));
  let v620_8: Space = if map_kernels::has_head(&(v620_7)) { singleton(&[]) } else { Space::new() };
  drop(v620_7);
  let v620_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v620_8));
  drop(v620_8);
  let v620_20: Space = if (&(v620_9)).is_empty() { Space::new() } else {
    let v621_12: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v621_15: Space = if (&(v621_12)).is_empty() { Space::new() } else {
      let v622_14: Space = routine_111(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      map_map_kernels::compose(&(v621_12),&(v622_14))
    };
    drop(v621_12);
    let mut v621_18 = Space::new();
    let mut v621_18_write = v621_18.write_zipper();
    let mut v621_18_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v621_18_origin = v621_18_cursor.path().len();
    for v621_18_byte in v621_18_cursor.child_mask().iter() {
      v621_18_cursor.descend_to_existing_byte(v621_18_byte);
      {
      let v623_2_arg_0: &[u8] = &v621_18_cursor.path()[v621_18_origin..(v621_18_origin + 1)];
      let v623_2_arg_1: &[u8] = &(*p0);
      let v623_2_arg_2: &[u8] = &(*p2);
      let v623_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v623_2_more = v621_18_cursor.is_val() || next_value_within(&mut v621_18_cursor,(v621_18_origin + 1));
      while v623_2_more {
        {
        let v623_2_depth = v621_18_cursor.path().len();
        let mut v624_5_cursor = (*v623_2_arg_4).read_zipper();
        let v624_5_origin = v624_5_cursor.path().len();
        for v624_5_byte in v624_5_cursor.child_mask().iter() {
          v624_5_cursor.descend_to_existing_byte(v624_5_byte);
          {
          let v625_2: Path = concat_path(&(*v623_2_arg_1),&v624_5_cursor.path()[v624_5_origin..(v624_5_origin + 1)]);
          let v625_3: Space = routine_79(c, &(v625_2), &v621_18_cursor.path()[v621_18_origin..v623_2_depth], &(*v623_2_arg_2), &v624_5_cursor);
          drop(v625_2);
          join_wrapped_into(&mut v621_18_write,&((v625_3).read_zipper()),&[]);
          }
          v624_5_cursor.ascend(1);
        }
        drop(v624_5_cursor);
        }
        v623_2_more = next_value_within(&mut v621_18_cursor,(v621_18_origin + 1));
      }
      }
      v621_18_cursor.ascend(1);
    }
    drop(v621_18_cursor);
    drop(v621_18_write);
    let v621_19: Space = map_map_kernels::unite(&(v621_15),&(v621_18));
    map_map_kernels::compose(&(v620_9),&(v621_19))
  };
  drop(v620_9);
  let v620_22: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v620_6));
  drop(v620_6);
  let v620_23: Space = if map_kernels::has_head(&(v620_22)) { singleton(&[]) } else { Space::new() };
  drop(v620_22);
  let v620_28: Space = if (&(v620_23)).is_empty() { Space::new() } else {
    let mut v626_25 = Space::new();
    let mut v626_25_write = v626_25.write_zipper();
    let mut v626_25_cursor = (*s0).read_zipper();
    let v626_25_origin = v626_25_cursor.path().len();
    for v626_25_byte in v626_25_cursor.child_mask().iter() {
      v626_25_cursor.descend_to_existing_byte(v626_25_byte);
      {
      let v627_2: Space = routine_112(c, &v626_25_cursor.path()[v626_25_origin..(v626_25_origin + 1)], &v626_25_cursor.path()[v626_25_origin..(v626_25_origin + 1)], &v626_25_cursor);
      join_wrapped_into(&mut v626_25_write,&((v627_2).read_zipper()),&[]);
      }
      v626_25_cursor.ascend(1);
    }
    drop(v626_25_cursor);
    drop(v626_25_write);
    let v626_26: Space = map_map_kernels::raffine(&(*CONSTANT_17),&(v626_25));
    let v626_27: Space = map_view_kernels::unite(&(v626_26),&(*s0));
    map_map_kernels::compose(&(v620_23),&(v626_27))
  };
  drop(v620_23);
  let v620_29: Path = concat_path(&(*p2),&(*p0));
  let v620_30: Space = map_kernels::wrap(&(v620_28),&(v620_29));
  drop(v620_29);
  let v620_31: Space = map_map_kernels::unite(&(v620_20),&(v620_30));
  (v620_31).clone()
}

fn routine_80(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v628_6: Space = singleton(&(*p0));
  let v628_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v628_6));
  let v628_8: Space = if map_kernels::has_head(&(v628_7)) { singleton(&[]) } else { Space::new() };
  drop(v628_7);
  let v628_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v628_8));
  drop(v628_8);
  let v628_14: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v628_6));
  drop(v628_6);
  let v628_15: Space = if map_kernels::has_head(&(v628_14)) { singleton(&[]) } else { Space::new() };
  drop(v628_14);
  let mut v628_16 = Space::new();
  let mut v628_16_write = v628_16.write_zipper();
  let mut v628_16_cursor = (*s0).read_zipper();
  let v628_16_origin = v628_16_cursor.path().len();
  for v628_16_byte in v628_16_cursor.child_mask().iter() {
    v628_16_cursor.descend_to_existing_byte(v628_16_byte);
    {
    let v629_4: Space = if (&(v628_9)).is_empty() { Space::new() } else {
      let v630_2: Path = concat_path(&(*p1),&v628_16_cursor.path()[v628_16_origin..(v628_16_origin + 1)]);
      let mut v630_3 = Space::new();
      let mut v630_3_write = v630_3.write_zipper();
      let v630_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v630_3_arg_1: &[u8] = &(v630_2);
      let v630_3_arg_3: &Space = &(&v628_16_cursor).make_map();
      let v630_3_arg_4: &Space = &(&(*s1)).make_map();
      let mut v630_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v630_3_origin = v630_3_cursor.path().len();
      let mut v630_3_more = v630_3_cursor.is_val() || next_value_within(&mut v630_3_cursor,v630_3_origin);
      while v630_3_more {
        {
        let v630_3_depth = v630_3_cursor.path().len();
        let v631_5: Space = routine_80(c, &v630_3_cursor.path()[v630_3_origin..v630_3_depth], &(*v630_3_arg_1), &((*v630_3_arg_3).read_zipper()), &((*v630_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v630_3_write,&((v631_5).read_zipper()),&[]);
        }
        v630_3_more = next_value_within(&mut v630_3_cursor,v630_3_origin);
      }
      drop(v630_3_cursor);
      drop(v630_3_write);
      map_map_kernels::compose(&(v628_9),&(v630_3))
    };
    let v629_6: Space = if (&(v628_15)).is_empty() { Space::new() } else {
      let v632_2: Path = concat_path(&(*p1),&v628_16_cursor.path()[v628_16_origin..(v628_16_origin + 1)]);
      let v632_5: Space = routine_81(c, &(v632_2), &(*s1));
      drop(v632_2);
      map_map_kernels::compose(&(v628_15),&(v632_5))
    };
    let v629_7: Space = map_map_kernels::unite(&(v629_4),&(v629_6));
    join_wrapped_into(&mut v628_16_write,&((v629_7).read_zipper()),&[]);
    }
    v628_16_cursor.ascend(1);
  }
  drop(v628_16_cursor);
  drop(v628_16_write);
  drop(v628_9);
  drop(v628_15);
  (v628_16).clone()
}

fn routine_81(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v633_3: Space = singleton(&(*p0));
  let v633_4: Space = map_map_kernels::intersect(&(*CONSTANT_7),&(v633_3));
  let v633_28: Space = if (&(v633_4)).is_empty() { Space::new() } else {
    let v634_9: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_18)))).is_empty() { Space::new() } else {
      view_view_kernels::compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_18))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_19))))
    };
    let v634_12: Space = if (&(v634_9)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v634_9),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_20))))
    };
    drop(v634_9);
    let v634_15: Space = if (&(v634_12)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v634_12),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v634_12);
    let v634_18: Space = if (&(v634_15)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v634_15),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_22))))
    };
    drop(v634_15);
    let v634_21: Space = if (&(v634_18)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v634_18),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v634_18);
    let v634_24: Space = if (&(v634_21)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v634_21),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_24))))
    };
    drop(v634_21);
    let v634_27: Space = if (&(v634_24)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v634_24),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v634_24);
    map_map_kernels::compose(&(v633_4),&(v634_27))
  };
  drop(v633_4);
  let v633_30: Space = map_map_kernels::intersect(&(*CONSTANT_8),&(v633_3));
  let v633_40: Space = if (&(v633_30)).is_empty() { Space::new() } else {
    let v642_33: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_26)))).is_empty() { Space::new() } else {
      view_view_kernels::compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_26))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_19))))
    };
    let v642_34: Space = if (&(v642_33)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v642_33),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_20))))
    };
    drop(v642_33);
    let v642_35: Space = if (&(v642_34)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v642_34),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v642_34);
    let v642_36: Space = if (&(v642_35)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v642_35),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_22))))
    };
    drop(v642_35);
    let v642_37: Space = if (&(v642_36)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v642_36),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v642_36);
    let v642_38: Space = if (&(v642_37)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v642_37),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_24))))
    };
    drop(v642_37);
    let v642_39: Space = if (&(v642_38)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v642_38),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v642_38);
    map_map_kernels::compose(&(v633_30),&(v642_39))
  };
  drop(v633_30);
  let v633_41: Space = map_map_kernels::unite(&(v633_28),&(v633_40));
  drop(v633_28);
  drop(v633_40);
  let v633_43: Space = map_map_kernels::intersect(&(*CONSTANT_9),&(v633_3));
  let v633_51: Space = if (&(v633_43)).is_empty() { Space::new() } else {
    let v650_44: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_26)))).is_empty() { Space::new() } else {
      view_view_kernels::compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_26))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_18))))
    };
    let v650_45: Space = if (&(v650_44)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v650_44),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_20))))
    };
    let v650_46: Space = if (&(v650_45)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v650_45),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v650_45);
    let v650_47: Space = if (&(v650_46)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v650_46),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_22))))
    };
    drop(v650_46);
    let v650_48: Space = if (&(v650_47)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v650_47),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v650_47);
    let v650_49: Space = if (&(v650_48)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v650_48),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_24))))
    };
    drop(v650_48);
    let v650_50: Space = if (&(v650_49)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v650_49),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v650_49);
    map_map_kernels::compose(&(v633_43),&(v650_50))
  };
  drop(v633_43);
  let v633_52: Space = map_map_kernels::unite(&(v633_41),&(v633_51));
  drop(v633_41);
  drop(v633_51);
  let v633_54: Space = map_map_kernels::intersect(&(*CONSTANT_10),&(v633_3));
  let v633_61: Space = if (&(v633_54)).is_empty() { Space::new() } else {
    let v658_44: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_26)))).is_empty() { Space::new() } else {
      view_view_kernels::compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_26))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_18))))
    };
    let v658_55: Space = if (&(v658_44)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v658_44),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v658_44);
    let v658_56: Space = if (&(v658_55)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v658_55),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_21))))
    };
    let v658_57: Space = if (&(v658_56)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v658_56),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_22))))
    };
    drop(v658_56);
    let v658_58: Space = if (&(v658_57)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v658_57),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v658_57);
    let v658_59: Space = if (&(v658_58)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v658_58),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_24))))
    };
    drop(v658_58);
    let v658_60: Space = if (&(v658_59)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v658_59),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v658_59);
    map_map_kernels::compose(&(v633_54),&(v658_60))
  };
  drop(v633_54);
  let v633_62: Space = map_map_kernels::unite(&(v633_52),&(v633_61));
  drop(v633_52);
  drop(v633_61);
  let v633_64: Space = map_map_kernels::intersect(&(*CONSTANT_11),&(v633_3));
  let v633_70: Space = if (&(v633_64)).is_empty() { Space::new() } else {
    let v666_44: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_26)))).is_empty() { Space::new() } else {
      view_view_kernels::compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_26))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_18))))
    };
    let v666_55: Space = if (&(v666_44)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v666_44),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v666_44);
    let v666_65: Space = if (&(v666_55)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v666_55),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_20))))
    };
    drop(v666_55);
    let v666_66: Space = if (&(v666_65)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v666_65),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_22))))
    };
    let v666_67: Space = if (&(v666_66)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v666_66),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v666_66);
    let v666_68: Space = if (&(v666_67)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v666_67),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_24))))
    };
    drop(v666_67);
    let v666_69: Space = if (&(v666_68)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v666_68),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v666_68);
    map_map_kernels::compose(&(v633_64),&(v666_69))
  };
  drop(v633_64);
  let v633_71: Space = map_map_kernels::unite(&(v633_62),&(v633_70));
  drop(v633_62);
  drop(v633_70);
  let v633_73: Space = map_map_kernels::intersect(&(*CONSTANT_12),&(v633_3));
  let v633_78: Space = if (&(v633_73)).is_empty() { Space::new() } else {
    let v674_44: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_26)))).is_empty() { Space::new() } else {
      view_view_kernels::compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_26))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_18))))
    };
    let v674_55: Space = if (&(v674_44)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v674_44),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v674_44);
    let v674_65: Space = if (&(v674_55)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v674_55),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_20))))
    };
    drop(v674_55);
    let v674_74: Space = if (&(v674_65)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v674_65),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v674_65);
    let v674_75: Space = if (&(v674_74)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v674_74),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_23))))
    };
    let v674_76: Space = if (&(v674_75)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v674_75),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_24))))
    };
    drop(v674_75);
    let v674_77: Space = if (&(v674_76)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v674_76),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v674_76);
    map_map_kernels::compose(&(v633_73),&(v674_77))
  };
  drop(v633_73);
  let v633_79: Space = map_map_kernels::unite(&(v633_71),&(v633_78));
  drop(v633_71);
  drop(v633_78);
  let v633_81: Space = map_map_kernels::intersect(&(*CONSTANT_13),&(v633_3));
  let v633_85: Space = if (&(v633_81)).is_empty() { Space::new() } else {
    let v682_44: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_26)))).is_empty() { Space::new() } else {
      view_view_kernels::compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_26))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_18))))
    };
    let v682_55: Space = if (&(v682_44)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v682_44),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v682_44);
    let v682_65: Space = if (&(v682_55)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v682_55),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_20))))
    };
    drop(v682_55);
    let v682_74: Space = if (&(v682_65)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v682_65),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v682_65);
    let v682_82: Space = if (&(v682_74)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v682_74),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_22))))
    };
    drop(v682_74);
    let v682_83: Space = if (&(v682_82)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v682_82),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_24))))
    };
    let v682_84: Space = if (&(v682_83)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v682_83),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_25))))
    };
    drop(v682_83);
    map_map_kernels::compose(&(v633_81),&(v682_84))
  };
  drop(v633_81);
  let v633_86: Space = map_map_kernels::unite(&(v633_79),&(v633_85));
  drop(v633_79);
  drop(v633_85);
  let v633_88: Space = map_map_kernels::intersect(&(*CONSTANT_14),&(v633_3));
  let v633_91: Space = if (&(v633_88)).is_empty() { Space::new() } else {
    let v690_44: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_26)))).is_empty() { Space::new() } else {
      view_view_kernels::compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_26))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_18))))
    };
    let v690_55: Space = if (&(v690_44)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v690_44),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v690_44);
    let v690_65: Space = if (&(v690_55)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v690_55),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_20))))
    };
    drop(v690_55);
    let v690_74: Space = if (&(v690_65)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v690_65),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v690_65);
    let v690_82: Space = if (&(v690_74)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v690_74),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_22))))
    };
    drop(v690_74);
    let v690_89: Space = if (&(v690_82)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v690_82),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v690_82);
    let v690_90: Space = if (&(v690_89)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v690_89),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_25))))
    };
    map_map_kernels::compose(&(v633_88),&(v690_90))
  };
  drop(v633_88);
  let v633_92: Space = map_map_kernels::unite(&(v633_86),&(v633_91));
  drop(v633_86);
  drop(v633_91);
  let v633_94: Space = map_map_kernels::intersect(&(*CONSTANT_15),&(v633_3));
  drop(v633_3);
  let v633_96: Space = if (&(v633_94)).is_empty() { Space::new() } else {
    let v698_44: Space = if (&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_26)))).is_empty() { Space::new() } else {
      view_view_kernels::compose(&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_26))),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_18))))
    };
    let v698_55: Space = if (&(v698_44)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v698_44),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_19))))
    };
    drop(v698_44);
    let v698_65: Space = if (&(v698_55)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v698_55),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_20))))
    };
    drop(v698_55);
    let v698_74: Space = if (&(v698_65)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v698_65),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_21))))
    };
    drop(v698_65);
    let v698_82: Space = if (&(v698_74)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v698_74),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_22))))
    };
    drop(v698_74);
    let v698_89: Space = if (&(v698_82)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v698_82),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_23))))
    };
    drop(v698_82);
    let v698_95: Space = if (&(v698_89)).is_empty() { Space::new() } else {
      map_view_kernels::compose(&(v698_89),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_24))))
    };
    drop(v698_89);
    map_map_kernels::compose(&(v633_94),&(v698_95))
  };
  drop(v633_94);
  let v633_97: Space = map_map_kernels::unite(&(v633_92),&(v633_96));
  drop(v633_92);
  drop(v633_96);
  (v633_97).clone()
}

fn routine_82(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v706_6: Space = singleton(&(*p0));
  let v706_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v706_6));
  let v706_8: Space = if map_kernels::has_head(&(v706_7)) { singleton(&[]) } else { Space::new() };
  drop(v706_7);
  let v706_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v706_8));
  drop(v706_8);
  let v706_14: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v706_6));
  drop(v706_6);
  let v706_15: Space = if map_kernels::has_head(&(v706_14)) { singleton(&[]) } else { Space::new() };
  drop(v706_14);
  let mut v706_16 = Space::new();
  let mut v706_16_write = v706_16.write_zipper();
  let mut v706_16_cursor = (*s0).read_zipper();
  let v706_16_origin = v706_16_cursor.path().len();
  for v706_16_byte in v706_16_cursor.child_mask().iter() {
    v706_16_cursor.descend_to_existing_byte(v706_16_byte);
    {
    let v707_4: Space = if (&(v706_9)).is_empty() { Space::new() } else {
      let v708_2: Path = concat_path(&(*p1),&v706_16_cursor.path()[v706_16_origin..(v706_16_origin + 1)]);
      let mut v708_3 = Space::new();
      let mut v708_3_write = v708_3.write_zipper();
      let v708_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v708_3_arg_1: &[u8] = &(v708_2);
      let v708_3_arg_2: &[u8] = &(*p2);
      let v708_3_arg_4: &Space = &(&v706_16_cursor).make_map();
      let mut v708_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v708_3_origin = v708_3_cursor.path().len();
      let mut v708_3_more = v708_3_cursor.is_val() || next_value_within(&mut v708_3_cursor,v708_3_origin);
      while v708_3_more {
        {
        let v708_3_depth = v708_3_cursor.path().len();
        let v709_5: Space = routine_82(c, &v708_3_cursor.path()[v708_3_origin..v708_3_depth], &(*v708_3_arg_1), &(*v708_3_arg_2), &((*v708_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v708_3_write,&((v709_5).read_zipper()),&[]);
        }
        v708_3_more = next_value_within(&mut v708_3_cursor,v708_3_origin);
      }
      drop(v708_3_cursor);
      drop(v708_3_write);
      map_map_kernels::compose(&(v706_9),&(v708_3))
    };
    let v707_6: Space = if (&(v706_15)).is_empty() { Space::new() } else {
      let v710_2: Path = concat_path(&(*p1),&v706_16_cursor.path()[v706_16_origin..(v706_16_origin + 1)]);
      let mut v710_5 = Space::new();
      let mut v710_5_write = v710_5.write_zipper();
      for v710_5_byte in v706_16_cursor.child_mask().iter() {
        v706_16_cursor.descend_to_existing_byte(v710_5_byte);
        {
        let v711_2: Space = routine_48(c, &v706_16_cursor.path()[(v706_16_origin + 1)..(v706_16_origin + 2)], &v706_16_cursor.path()[(v706_16_origin + 1)..(v706_16_origin + 2)], &(*p2), &(v710_2), &v706_16_cursor);
        join_wrapped_into(&mut v710_5_write,&((v711_2).read_zipper()),&[]);
        }
        v706_16_cursor.ascend(1);
      }
      drop(v710_5_write);
      drop(v710_2);
      map_map_kernels::compose(&(v706_15),&(v710_5))
    };
    let v707_7: Space = map_map_kernels::unite(&(v707_4),&(v707_6));
    join_wrapped_into(&mut v706_16_write,&((v707_7).read_zipper()),&[]);
    }
    v706_16_cursor.ascend(1);
  }
  drop(v706_16_cursor);
  drop(v706_16_write);
  drop(v706_9);
  drop(v706_15);
  (v706_16).clone()
}

fn routine_83(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v712_7: Space = singleton(&(*p0));
  let v712_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v712_7));
  let v712_9: Space = if map_kernels::has_head(&(v712_8)) { singleton(&[]) } else { Space::new() };
  drop(v712_8);
  let v712_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v712_9));
  drop(v712_9);
  let v712_15: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v712_7));
  drop(v712_7);
  let v712_16: Space = if map_kernels::has_head(&(v712_15)) { singleton(&[]) } else { Space::new() };
  drop(v712_15);
  let mut v712_17 = Space::new();
  let mut v712_17_write = v712_17.write_zipper();
  let mut v712_17_cursor = (*s0).read_zipper();
  let v712_17_origin = v712_17_cursor.path().len();
  for v712_17_byte in v712_17_cursor.child_mask().iter() {
    v712_17_cursor.descend_to_existing_byte(v712_17_byte);
    {
    let v713_4: Space = if (&(v712_10)).is_empty() { Space::new() } else {
      let v714_2: Path = concat_path(&(*p1),&v712_17_cursor.path()[v712_17_origin..(v712_17_origin + 1)]);
      let mut v714_3 = Space::new();
      let mut v714_3_write = v714_3.write_zipper();
      let v714_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v714_3_arg_1: &[u8] = &(v714_2);
      let v714_3_arg_2: &[u8] = &(*p2);
      let v714_3_arg_3: &[u8] = &(*p3);
      let v714_3_arg_5: &Space = &(&v712_17_cursor).make_map();
      let mut v714_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v714_3_origin = v714_3_cursor.path().len();
      let mut v714_3_more = v714_3_cursor.is_val() || next_value_within(&mut v714_3_cursor,v714_3_origin);
      while v714_3_more {
        {
        let v714_3_depth = v714_3_cursor.path().len();
        let v715_6: Space = routine_83(c, &v714_3_cursor.path()[v714_3_origin..v714_3_depth], &(*v714_3_arg_1), &(*v714_3_arg_2), &(*v714_3_arg_3), &((*v714_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v714_3_write,&((v715_6).read_zipper()),&[]);
        }
        v714_3_more = next_value_within(&mut v714_3_cursor,v714_3_origin);
      }
      drop(v714_3_cursor);
      drop(v714_3_write);
      map_map_kernels::compose(&(v712_10),&(v714_3))
    };
    let v713_6: Space = if (&(v712_16)).is_empty() { Space::new() } else {
      let v716_2: Path = concat_path(&(*p1),&v712_17_cursor.path()[v712_17_origin..(v712_17_origin + 1)]);
      let mut v716_5 = Space::new();
      let mut v716_5_write = v716_5.write_zipper();
      for v716_5_byte in v712_17_cursor.child_mask().iter() {
        v712_17_cursor.descend_to_existing_byte(v716_5_byte);
        {
        let v717_2: Space = routine_84(c, &v712_17_cursor.path()[(v712_17_origin + 1)..(v712_17_origin + 2)], &v712_17_cursor.path()[(v712_17_origin + 1)..(v712_17_origin + 2)], &(*p2), &(*p3), &(v716_2), &v712_17_cursor);
        join_wrapped_into(&mut v716_5_write,&((v717_2).read_zipper()),&[]);
        }
        v712_17_cursor.ascend(1);
      }
      drop(v716_5_write);
      drop(v716_2);
      map_map_kernels::compose(&(v712_16),&(v716_5))
    };
    let v713_7: Space = map_map_kernels::unite(&(v713_4),&(v713_6));
    join_wrapped_into(&mut v712_17_write,&((v713_7).read_zipper()),&[]);
    }
    v712_17_cursor.ascend(1);
  }
  drop(v712_17_cursor);
  drop(v712_17_write);
  drop(v712_10);
  drop(v712_16);
  (v712_17).clone()
}

fn routine_84(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v718_8: Space = singleton(&(*p1));
  let v718_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v718_8));
  let v718_10: Space = if map_kernels::has_head(&(v718_9)) { singleton(&[]) } else { Space::new() };
  drop(v718_9);
  let v718_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v718_10));
  drop(v718_10);
  let v718_22: Space = if (&(v718_11)).is_empty() { Space::new() } else {
    let v719_14: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v719_17: Space = if (&(v719_14)).is_empty() { Space::new() } else {
      let v720_16: Space = routine_113(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*s0));
      map_map_kernels::compose(&(v719_14),&(v720_16))
    };
    drop(v719_14);
    let mut v719_20 = Space::new();
    let mut v719_20_write = v719_20.write_zipper();
    let mut v719_20_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v719_20_origin = v719_20_cursor.path().len();
    for v719_20_byte in v719_20_cursor.child_mask().iter() {
      v719_20_cursor.descend_to_existing_byte(v719_20_byte);
      {
      let v721_2_arg_0: &[u8] = &v719_20_cursor.path()[v719_20_origin..(v719_20_origin + 1)];
      let v721_2_arg_1: &[u8] = &(*p0);
      let v721_2_arg_2: &[u8] = &(*p2);
      let v721_2_arg_3: &[u8] = &(*p3);
      let v721_2_arg_4: &[u8] = &(*p4);
      let v721_2_arg_6: &Space = &(&(*s0)).make_map();
      let mut v721_2_more = v719_20_cursor.is_val() || next_value_within(&mut v719_20_cursor,(v719_20_origin + 1));
      while v721_2_more {
        {
        let v721_2_depth = v719_20_cursor.path().len();
        let mut v722_7_cursor = (*v721_2_arg_6).read_zipper();
        let v722_7_origin = v722_7_cursor.path().len();
        for v722_7_byte in v722_7_cursor.child_mask().iter() {
          v722_7_cursor.descend_to_existing_byte(v722_7_byte);
          {
          let v723_2: Path = concat_path(&(*v721_2_arg_1),&v722_7_cursor.path()[v722_7_origin..(v722_7_origin + 1)]);
          let v723_3: Space = routine_84(c, &(v723_2), &v719_20_cursor.path()[v719_20_origin..v721_2_depth], &(*v721_2_arg_2), &(*v721_2_arg_3), &(*v721_2_arg_4), &v722_7_cursor);
          drop(v723_2);
          join_wrapped_into(&mut v719_20_write,&((v723_3).read_zipper()),&[]);
          }
          v722_7_cursor.ascend(1);
        }
        drop(v722_7_cursor);
        }
        v721_2_more = next_value_within(&mut v719_20_cursor,(v719_20_origin + 1));
      }
      }
      v719_20_cursor.ascend(1);
    }
    drop(v719_20_cursor);
    drop(v719_20_write);
    let v719_21: Space = map_map_kernels::unite(&(v719_17),&(v719_20));
    map_map_kernels::compose(&(v718_11),&(v719_21))
  };
  drop(v718_11);
  let v718_24: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v718_8));
  drop(v718_8);
  let v718_25: Space = if map_kernels::has_head(&(v718_24)) { singleton(&[]) } else { Space::new() };
  drop(v718_24);
  let v718_27: Space = if (&(v718_25)).is_empty() { Space::new() } else {
    let mut v724_26 = Space::new();
    let mut v724_26_write = v724_26.write_zipper();
    let mut v724_26_cursor = (*s0).read_zipper();
    let v724_26_origin = v724_26_cursor.path().len();
    for v724_26_byte in v724_26_cursor.child_mask().iter() {
      v724_26_cursor.descend_to_existing_byte(v724_26_byte);
      {
      let v725_2: Space = routine_114(c, &v724_26_cursor.path()[v724_26_origin..(v724_26_origin + 1)], &v724_26_cursor.path()[v724_26_origin..(v724_26_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p0), &v724_26_cursor);
      join_wrapped_into(&mut v724_26_write,&((v725_2).read_zipper()),&[]);
      }
      v724_26_cursor.ascend(1);
    }
    drop(v724_26_cursor);
    drop(v724_26_write);
    map_map_kernels::compose(&(v718_25),&(v724_26))
  };
  drop(v718_25);
  let v718_28: Space = map_map_kernels::unite(&(v718_22),&(v718_27));
  (v718_28).clone()
}

fn routine_85(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v726_6: Space = singleton(&(*p0));
  let v726_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v726_6));
  let v726_8: Space = if map_kernels::has_head(&(v726_7)) { singleton(&[]) } else { Space::new() };
  drop(v726_7);
  let v726_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v726_8));
  drop(v726_8);
  let v726_14: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v726_6));
  drop(v726_6);
  let v726_15: Space = if map_kernels::has_head(&(v726_14)) { singleton(&[]) } else { Space::new() };
  drop(v726_14);
  let mut v726_16 = Space::new();
  let mut v726_16_write = v726_16.write_zipper();
  let mut v726_16_cursor = (*s0).read_zipper();
  let v726_16_origin = v726_16_cursor.path().len();
  for v726_16_byte in v726_16_cursor.child_mask().iter() {
    v726_16_cursor.descend_to_existing_byte(v726_16_byte);
    {
    let v727_4: Space = if (&(v726_9)).is_empty() { Space::new() } else {
      let v728_2: Path = concat_path(&(*p1),&v726_16_cursor.path()[v726_16_origin..(v726_16_origin + 1)]);
      let mut v728_3 = Space::new();
      let mut v728_3_write = v728_3.write_zipper();
      let v728_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v728_3_arg_1: &[u8] = &(v728_2);
      let v728_3_arg_2: &[u8] = &(*p2);
      let v728_3_arg_4: &Space = &(&v726_16_cursor).make_map();
      let mut v728_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v728_3_origin = v728_3_cursor.path().len();
      let mut v728_3_more = v728_3_cursor.is_val() || next_value_within(&mut v728_3_cursor,v728_3_origin);
      while v728_3_more {
        {
        let v728_3_depth = v728_3_cursor.path().len();
        let v729_5: Space = routine_85(c, &v728_3_cursor.path()[v728_3_origin..v728_3_depth], &(*v728_3_arg_1), &(*v728_3_arg_2), &((*v728_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v728_3_write,&((v729_5).read_zipper()),&[]);
        }
        v728_3_more = next_value_within(&mut v728_3_cursor,v728_3_origin);
      }
      drop(v728_3_cursor);
      drop(v728_3_write);
      map_map_kernels::compose(&(v726_9),&(v728_3))
    };
    let v727_6: Space = if (&(v726_15)).is_empty() { Space::new() } else {
      let v730_2: Path = concat_path(&(*p1),&v726_16_cursor.path()[v726_16_origin..(v726_16_origin + 1)]);
      let mut v730_5 = Space::new();
      let mut v730_5_write = v730_5.write_zipper();
      for v730_5_byte in v726_16_cursor.child_mask().iter() {
        v726_16_cursor.descend_to_existing_byte(v730_5_byte);
        {
        let v731_2: Space = routine_51(c, &v726_16_cursor.path()[(v726_16_origin + 1)..(v726_16_origin + 2)], &v726_16_cursor.path()[(v726_16_origin + 1)..(v726_16_origin + 2)], &(*p2), &(v730_2), &v726_16_cursor);
        join_wrapped_into(&mut v730_5_write,&((v731_2).read_zipper()),&[]);
        }
        v726_16_cursor.ascend(1);
      }
      drop(v730_5_write);
      drop(v730_2);
      map_map_kernels::compose(&(v726_15),&(v730_5))
    };
    let v727_7: Space = map_map_kernels::unite(&(v727_4),&(v727_6));
    join_wrapped_into(&mut v726_16_write,&((v727_7).read_zipper()),&[]);
    }
    v726_16_cursor.ascend(1);
  }
  drop(v726_16_cursor);
  drop(v726_16_write);
  drop(v726_9);
  drop(v726_15);
  (v726_16).clone()
}

fn routine_86(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v732_7: Space = singleton(&(*p0));
  let v732_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v732_7));
  let v732_9: Space = if map_kernels::has_head(&(v732_8)) { singleton(&[]) } else { Space::new() };
  drop(v732_8);
  let v732_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v732_9));
  drop(v732_9);
  let v732_15: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v732_7));
  drop(v732_7);
  let v732_16: Space = if map_kernels::has_head(&(v732_15)) { singleton(&[]) } else { Space::new() };
  drop(v732_15);
  let mut v732_17 = Space::new();
  let mut v732_17_write = v732_17.write_zipper();
  let mut v732_17_cursor = (*s0).read_zipper();
  let v732_17_origin = v732_17_cursor.path().len();
  for v732_17_byte in v732_17_cursor.child_mask().iter() {
    v732_17_cursor.descend_to_existing_byte(v732_17_byte);
    {
    let v733_4: Space = if (&(v732_10)).is_empty() { Space::new() } else {
      let v734_2: Path = concat_path(&(*p1),&v732_17_cursor.path()[v732_17_origin..(v732_17_origin + 1)]);
      let mut v734_3 = Space::new();
      let mut v734_3_write = v734_3.write_zipper();
      let v734_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v734_3_arg_1: &[u8] = &(v734_2);
      let v734_3_arg_2: &[u8] = &(*p2);
      let v734_3_arg_3: &[u8] = &(*p3);
      let v734_3_arg_5: &Space = &(&v732_17_cursor).make_map();
      let mut v734_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v734_3_origin = v734_3_cursor.path().len();
      let mut v734_3_more = v734_3_cursor.is_val() || next_value_within(&mut v734_3_cursor,v734_3_origin);
      while v734_3_more {
        {
        let v734_3_depth = v734_3_cursor.path().len();
        let v735_6: Space = routine_86(c, &v734_3_cursor.path()[v734_3_origin..v734_3_depth], &(*v734_3_arg_1), &(*v734_3_arg_2), &(*v734_3_arg_3), &((*v734_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v734_3_write,&((v735_6).read_zipper()),&[]);
        }
        v734_3_more = next_value_within(&mut v734_3_cursor,v734_3_origin);
      }
      drop(v734_3_cursor);
      drop(v734_3_write);
      map_map_kernels::compose(&(v732_10),&(v734_3))
    };
    let v733_6: Space = if (&(v732_16)).is_empty() { Space::new() } else {
      let v736_2: Path = concat_path(&(*p1),&v732_17_cursor.path()[v732_17_origin..(v732_17_origin + 1)]);
      let mut v736_5 = Space::new();
      let mut v736_5_write = v736_5.write_zipper();
      for v736_5_byte in v732_17_cursor.child_mask().iter() {
        v732_17_cursor.descend_to_existing_byte(v736_5_byte);
        {
        let v737_2: Space = routine_87(c, &v732_17_cursor.path()[(v732_17_origin + 1)..(v732_17_origin + 2)], &v732_17_cursor.path()[(v732_17_origin + 1)..(v732_17_origin + 2)], &(*p2), &(*p3), &(v736_2), &v732_17_cursor);
        join_wrapped_into(&mut v736_5_write,&((v737_2).read_zipper()),&[]);
        }
        v732_17_cursor.ascend(1);
      }
      drop(v736_5_write);
      drop(v736_2);
      map_map_kernels::compose(&(v732_16),&(v736_5))
    };
    let v733_7: Space = map_map_kernels::unite(&(v733_4),&(v733_6));
    join_wrapped_into(&mut v732_17_write,&((v733_7).read_zipper()),&[]);
    }
    v732_17_cursor.ascend(1);
  }
  drop(v732_17_cursor);
  drop(v732_17_write);
  drop(v732_10);
  drop(v732_16);
  (v732_17).clone()
}

fn routine_87(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v738_8: Space = singleton(&(*p1));
  let v738_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v738_8));
  let v738_10: Space = if map_kernels::has_head(&(v738_9)) { singleton(&[]) } else { Space::new() };
  drop(v738_9);
  let v738_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v738_10));
  drop(v738_10);
  let v738_22: Space = if (&(v738_11)).is_empty() { Space::new() } else {
    let v739_14: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v739_17: Space = if (&(v739_14)).is_empty() { Space::new() } else {
      let v740_16: Space = routine_115(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*s0));
      map_map_kernels::compose(&(v739_14),&(v740_16))
    };
    drop(v739_14);
    let mut v739_20 = Space::new();
    let mut v739_20_write = v739_20.write_zipper();
    let mut v739_20_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v739_20_origin = v739_20_cursor.path().len();
    for v739_20_byte in v739_20_cursor.child_mask().iter() {
      v739_20_cursor.descend_to_existing_byte(v739_20_byte);
      {
      let v741_2_arg_0: &[u8] = &v739_20_cursor.path()[v739_20_origin..(v739_20_origin + 1)];
      let v741_2_arg_1: &[u8] = &(*p0);
      let v741_2_arg_2: &[u8] = &(*p2);
      let v741_2_arg_3: &[u8] = &(*p3);
      let v741_2_arg_4: &[u8] = &(*p4);
      let v741_2_arg_6: &Space = &(&(*s0)).make_map();
      let mut v741_2_more = v739_20_cursor.is_val() || next_value_within(&mut v739_20_cursor,(v739_20_origin + 1));
      while v741_2_more {
        {
        let v741_2_depth = v739_20_cursor.path().len();
        let mut v742_7_cursor = (*v741_2_arg_6).read_zipper();
        let v742_7_origin = v742_7_cursor.path().len();
        for v742_7_byte in v742_7_cursor.child_mask().iter() {
          v742_7_cursor.descend_to_existing_byte(v742_7_byte);
          {
          let v743_2: Path = concat_path(&(*v741_2_arg_1),&v742_7_cursor.path()[v742_7_origin..(v742_7_origin + 1)]);
          let v743_3: Space = routine_87(c, &(v743_2), &v739_20_cursor.path()[v739_20_origin..v741_2_depth], &(*v741_2_arg_2), &(*v741_2_arg_3), &(*v741_2_arg_4), &v742_7_cursor);
          drop(v743_2);
          join_wrapped_into(&mut v739_20_write,&((v743_3).read_zipper()),&[]);
          }
          v742_7_cursor.ascend(1);
        }
        drop(v742_7_cursor);
        }
        v741_2_more = next_value_within(&mut v739_20_cursor,(v739_20_origin + 1));
      }
      }
      v739_20_cursor.ascend(1);
    }
    drop(v739_20_cursor);
    drop(v739_20_write);
    let v739_21: Space = map_map_kernels::unite(&(v739_17),&(v739_20));
    map_map_kernels::compose(&(v738_11),&(v739_21))
  };
  drop(v738_11);
  let v738_24: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v738_8));
  drop(v738_8);
  let v738_25: Space = if map_kernels::has_head(&(v738_24)) { singleton(&[]) } else { Space::new() };
  drop(v738_24);
  let v738_27: Space = if (&(v738_25)).is_empty() { Space::new() } else {
    let mut v744_26 = Space::new();
    let mut v744_26_write = v744_26.write_zipper();
    let mut v744_26_cursor = (*s0).read_zipper();
    let v744_26_origin = v744_26_cursor.path().len();
    for v744_26_byte in v744_26_cursor.child_mask().iter() {
      v744_26_cursor.descend_to_existing_byte(v744_26_byte);
      {
      let v745_2: Space = routine_116(c, &v744_26_cursor.path()[v744_26_origin..(v744_26_origin + 1)], &v744_26_cursor.path()[v744_26_origin..(v744_26_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p0), &v744_26_cursor);
      join_wrapped_into(&mut v744_26_write,&((v745_2).read_zipper()),&[]);
      }
      v744_26_cursor.ascend(1);
    }
    drop(v744_26_cursor);
    drop(v744_26_write);
    map_map_kernels::compose(&(v738_25),&(v744_26))
  };
  drop(v738_25);
  let v738_28: Space = map_map_kernels::unite(&(v738_22),&(v738_27));
  (v738_28).clone()
}

fn routine_88(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v746_6: Space = singleton(&(*p0));
  let v746_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v746_6));
  let v746_8: Space = if map_kernels::has_head(&(v746_7)) { singleton(&[]) } else { Space::new() };
  drop(v746_7);
  let v746_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v746_8));
  drop(v746_8);
  let v746_14: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v746_6));
  drop(v746_6);
  let v746_15: Space = if map_kernels::has_head(&(v746_14)) { singleton(&[]) } else { Space::new() };
  drop(v746_14);
  let mut v746_16 = Space::new();
  let mut v746_16_write = v746_16.write_zipper();
  let mut v746_16_cursor = (*s0).read_zipper();
  let v746_16_origin = v746_16_cursor.path().len();
  for v746_16_byte in v746_16_cursor.child_mask().iter() {
    v746_16_cursor.descend_to_existing_byte(v746_16_byte);
    {
    let v747_4: Space = if (&(v746_9)).is_empty() { Space::new() } else {
      let v748_2: Path = concat_path(&(*p1),&v746_16_cursor.path()[v746_16_origin..(v746_16_origin + 1)]);
      let mut v748_3 = Space::new();
      let mut v748_3_write = v748_3.write_zipper();
      let v748_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v748_3_arg_1: &[u8] = &(v748_2);
      let v748_3_arg_2: &[u8] = &(*p2);
      let v748_3_arg_4: &Space = &(&v746_16_cursor).make_map();
      let mut v748_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v748_3_origin = v748_3_cursor.path().len();
      let mut v748_3_more = v748_3_cursor.is_val() || next_value_within(&mut v748_3_cursor,v748_3_origin);
      while v748_3_more {
        {
        let v748_3_depth = v748_3_cursor.path().len();
        let v749_5: Space = routine_88(c, &v748_3_cursor.path()[v748_3_origin..v748_3_depth], &(*v748_3_arg_1), &(*v748_3_arg_2), &((*v748_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v748_3_write,&((v749_5).read_zipper()),&[]);
        }
        v748_3_more = next_value_within(&mut v748_3_cursor,v748_3_origin);
      }
      drop(v748_3_cursor);
      drop(v748_3_write);
      map_map_kernels::compose(&(v746_9),&(v748_3))
    };
    let v747_6: Space = if (&(v746_15)).is_empty() { Space::new() } else {
      let v750_2: Path = concat_path(&(*p1),&v746_16_cursor.path()[v746_16_origin..(v746_16_origin + 1)]);
      let mut v750_5 = Space::new();
      let mut v750_5_write = v750_5.write_zipper();
      for v750_5_byte in v746_16_cursor.child_mask().iter() {
        v746_16_cursor.descend_to_existing_byte(v750_5_byte);
        {
        let v751_2: Space = routine_54(c, &v746_16_cursor.path()[(v746_16_origin + 1)..(v746_16_origin + 2)], &v746_16_cursor.path()[(v746_16_origin + 1)..(v746_16_origin + 2)], &(*p2), &(v750_2), &v746_16_cursor);
        join_wrapped_into(&mut v750_5_write,&((v751_2).read_zipper()),&[]);
        }
        v746_16_cursor.ascend(1);
      }
      drop(v750_5_write);
      drop(v750_2);
      map_map_kernels::compose(&(v746_15),&(v750_5))
    };
    let v747_7: Space = map_map_kernels::unite(&(v747_4),&(v747_6));
    join_wrapped_into(&mut v746_16_write,&((v747_7).read_zipper()),&[]);
    }
    v746_16_cursor.ascend(1);
  }
  drop(v746_16_cursor);
  drop(v746_16_write);
  drop(v746_9);
  drop(v746_15);
  (v746_16).clone()
}

fn routine_89(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v752_7: Space = singleton(&(*p0));
  let v752_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v752_7));
  let v752_9: Space = if map_kernels::has_head(&(v752_8)) { singleton(&[]) } else { Space::new() };
  drop(v752_8);
  let v752_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v752_9));
  drop(v752_9);
  let v752_15: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v752_7));
  drop(v752_7);
  let v752_16: Space = if map_kernels::has_head(&(v752_15)) { singleton(&[]) } else { Space::new() };
  drop(v752_15);
  let mut v752_17 = Space::new();
  let mut v752_17_write = v752_17.write_zipper();
  let mut v752_17_cursor = (*s0).read_zipper();
  let v752_17_origin = v752_17_cursor.path().len();
  for v752_17_byte in v752_17_cursor.child_mask().iter() {
    v752_17_cursor.descend_to_existing_byte(v752_17_byte);
    {
    let v753_4: Space = if (&(v752_10)).is_empty() { Space::new() } else {
      let v754_2: Path = concat_path(&(*p1),&v752_17_cursor.path()[v752_17_origin..(v752_17_origin + 1)]);
      let mut v754_3 = Space::new();
      let mut v754_3_write = v754_3.write_zipper();
      let v754_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v754_3_arg_1: &[u8] = &(v754_2);
      let v754_3_arg_2: &[u8] = &(*p2);
      let v754_3_arg_3: &[u8] = &(*p3);
      let v754_3_arg_5: &Space = &(&v752_17_cursor).make_map();
      let mut v754_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v754_3_origin = v754_3_cursor.path().len();
      let mut v754_3_more = v754_3_cursor.is_val() || next_value_within(&mut v754_3_cursor,v754_3_origin);
      while v754_3_more {
        {
        let v754_3_depth = v754_3_cursor.path().len();
        let v755_6: Space = routine_89(c, &v754_3_cursor.path()[v754_3_origin..v754_3_depth], &(*v754_3_arg_1), &(*v754_3_arg_2), &(*v754_3_arg_3), &((*v754_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v754_3_write,&((v755_6).read_zipper()),&[]);
        }
        v754_3_more = next_value_within(&mut v754_3_cursor,v754_3_origin);
      }
      drop(v754_3_cursor);
      drop(v754_3_write);
      map_map_kernels::compose(&(v752_10),&(v754_3))
    };
    let v753_6: Space = if (&(v752_16)).is_empty() { Space::new() } else {
      let v756_2: Path = concat_path(&(*p1),&v752_17_cursor.path()[v752_17_origin..(v752_17_origin + 1)]);
      let mut v756_5 = Space::new();
      let mut v756_5_write = v756_5.write_zipper();
      for v756_5_byte in v752_17_cursor.child_mask().iter() {
        v752_17_cursor.descend_to_existing_byte(v756_5_byte);
        {
        let v757_2: Space = routine_90(c, &v752_17_cursor.path()[(v752_17_origin + 1)..(v752_17_origin + 2)], &v752_17_cursor.path()[(v752_17_origin + 1)..(v752_17_origin + 2)], &(*p2), &(*p3), &(v756_2), &v752_17_cursor);
        join_wrapped_into(&mut v756_5_write,&((v757_2).read_zipper()),&[]);
        }
        v752_17_cursor.ascend(1);
      }
      drop(v756_5_write);
      drop(v756_2);
      map_map_kernels::compose(&(v752_16),&(v756_5))
    };
    let v753_7: Space = map_map_kernels::unite(&(v753_4),&(v753_6));
    join_wrapped_into(&mut v752_17_write,&((v753_7).read_zipper()),&[]);
    }
    v752_17_cursor.ascend(1);
  }
  drop(v752_17_cursor);
  drop(v752_17_write);
  drop(v752_10);
  drop(v752_16);
  (v752_17).clone()
}

fn routine_90(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v758_8: Space = singleton(&(*p1));
  let v758_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v758_8));
  let v758_10: Space = if map_kernels::has_head(&(v758_9)) { singleton(&[]) } else { Space::new() };
  drop(v758_9);
  let v758_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v758_10));
  drop(v758_10);
  let v758_22: Space = if (&(v758_11)).is_empty() { Space::new() } else {
    let v759_14: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v759_17: Space = if (&(v759_14)).is_empty() { Space::new() } else {
      let v760_16: Space = routine_117(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*s0));
      map_map_kernels::compose(&(v759_14),&(v760_16))
    };
    drop(v759_14);
    let mut v759_20 = Space::new();
    let mut v759_20_write = v759_20.write_zipper();
    let mut v759_20_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v759_20_origin = v759_20_cursor.path().len();
    for v759_20_byte in v759_20_cursor.child_mask().iter() {
      v759_20_cursor.descend_to_existing_byte(v759_20_byte);
      {
      let v761_2_arg_0: &[u8] = &v759_20_cursor.path()[v759_20_origin..(v759_20_origin + 1)];
      let v761_2_arg_1: &[u8] = &(*p0);
      let v761_2_arg_2: &[u8] = &(*p2);
      let v761_2_arg_3: &[u8] = &(*p3);
      let v761_2_arg_4: &[u8] = &(*p4);
      let v761_2_arg_6: &Space = &(&(*s0)).make_map();
      let mut v761_2_more = v759_20_cursor.is_val() || next_value_within(&mut v759_20_cursor,(v759_20_origin + 1));
      while v761_2_more {
        {
        let v761_2_depth = v759_20_cursor.path().len();
        let mut v762_7_cursor = (*v761_2_arg_6).read_zipper();
        let v762_7_origin = v762_7_cursor.path().len();
        for v762_7_byte in v762_7_cursor.child_mask().iter() {
          v762_7_cursor.descend_to_existing_byte(v762_7_byte);
          {
          let v763_2: Path = concat_path(&(*v761_2_arg_1),&v762_7_cursor.path()[v762_7_origin..(v762_7_origin + 1)]);
          let v763_3: Space = routine_90(c, &(v763_2), &v759_20_cursor.path()[v759_20_origin..v761_2_depth], &(*v761_2_arg_2), &(*v761_2_arg_3), &(*v761_2_arg_4), &v762_7_cursor);
          drop(v763_2);
          join_wrapped_into(&mut v759_20_write,&((v763_3).read_zipper()),&[]);
          }
          v762_7_cursor.ascend(1);
        }
        drop(v762_7_cursor);
        }
        v761_2_more = next_value_within(&mut v759_20_cursor,(v759_20_origin + 1));
      }
      }
      v759_20_cursor.ascend(1);
    }
    drop(v759_20_cursor);
    drop(v759_20_write);
    let v759_21: Space = map_map_kernels::unite(&(v759_17),&(v759_20));
    map_map_kernels::compose(&(v758_11),&(v759_21))
  };
  drop(v758_11);
  let v758_24: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v758_8));
  drop(v758_8);
  let v758_25: Space = if map_kernels::has_head(&(v758_24)) { singleton(&[]) } else { Space::new() };
  drop(v758_24);
  let v758_27: Space = if (&(v758_25)).is_empty() { Space::new() } else {
    let mut v764_26 = Space::new();
    let mut v764_26_write = v764_26.write_zipper();
    let mut v764_26_cursor = (*s0).read_zipper();
    let v764_26_origin = v764_26_cursor.path().len();
    for v764_26_byte in v764_26_cursor.child_mask().iter() {
      v764_26_cursor.descend_to_existing_byte(v764_26_byte);
      {
      let v765_2: Space = routine_118(c, &v764_26_cursor.path()[v764_26_origin..(v764_26_origin + 1)], &v764_26_cursor.path()[v764_26_origin..(v764_26_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p0), &v764_26_cursor);
      join_wrapped_into(&mut v764_26_write,&((v765_2).read_zipper()),&[]);
      }
      v764_26_cursor.ascend(1);
    }
    drop(v764_26_cursor);
    drop(v764_26_write);
    map_map_kernels::compose(&(v758_25),&(v764_26))
  };
  drop(v758_25);
  let v758_28: Space = map_map_kernels::unite(&(v758_22),&(v758_27));
  (v758_28).clone()
}

fn routine_91(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v766_6: Space = singleton(&(*p0));
  let v766_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v766_6));
  let v766_8: Space = if map_kernels::has_head(&(v766_7)) { singleton(&[]) } else { Space::new() };
  drop(v766_7);
  let v766_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v766_8));
  drop(v766_8);
  let v766_14: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v766_6));
  drop(v766_6);
  let v766_15: Space = if map_kernels::has_head(&(v766_14)) { singleton(&[]) } else { Space::new() };
  drop(v766_14);
  let mut v766_16 = Space::new();
  let mut v766_16_write = v766_16.write_zipper();
  let mut v766_16_cursor = (*s0).read_zipper();
  let v766_16_origin = v766_16_cursor.path().len();
  for v766_16_byte in v766_16_cursor.child_mask().iter() {
    v766_16_cursor.descend_to_existing_byte(v766_16_byte);
    {
    let v767_4: Space = if (&(v766_9)).is_empty() { Space::new() } else {
      let v768_2: Path = concat_path(&(*p1),&v766_16_cursor.path()[v766_16_origin..(v766_16_origin + 1)]);
      let mut v768_3 = Space::new();
      let mut v768_3_write = v768_3.write_zipper();
      let v768_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v768_3_arg_1: &[u8] = &(v768_2);
      let v768_3_arg_2: &[u8] = &(*p2);
      let v768_3_arg_4: &Space = &(&v766_16_cursor).make_map();
      let mut v768_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v768_3_origin = v768_3_cursor.path().len();
      let mut v768_3_more = v768_3_cursor.is_val() || next_value_within(&mut v768_3_cursor,v768_3_origin);
      while v768_3_more {
        {
        let v768_3_depth = v768_3_cursor.path().len();
        let v769_5: Space = routine_91(c, &v768_3_cursor.path()[v768_3_origin..v768_3_depth], &(*v768_3_arg_1), &(*v768_3_arg_2), &((*v768_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v768_3_write,&((v769_5).read_zipper()),&[]);
        }
        v768_3_more = next_value_within(&mut v768_3_cursor,v768_3_origin);
      }
      drop(v768_3_cursor);
      drop(v768_3_write);
      map_map_kernels::compose(&(v766_9),&(v768_3))
    };
    let v767_6: Space = if (&(v766_15)).is_empty() { Space::new() } else {
      let v770_2: Path = concat_path(&(*p1),&v766_16_cursor.path()[v766_16_origin..(v766_16_origin + 1)]);
      let mut v770_5 = Space::new();
      let mut v770_5_write = v770_5.write_zipper();
      for v770_5_byte in v766_16_cursor.child_mask().iter() {
        v766_16_cursor.descend_to_existing_byte(v770_5_byte);
        {
        let v771_2: Space = routine_57(c, &v766_16_cursor.path()[(v766_16_origin + 1)..(v766_16_origin + 2)], &v766_16_cursor.path()[(v766_16_origin + 1)..(v766_16_origin + 2)], &(*p2), &(v770_2), &v766_16_cursor);
        join_wrapped_into(&mut v770_5_write,&((v771_2).read_zipper()),&[]);
        }
        v766_16_cursor.ascend(1);
      }
      drop(v770_5_write);
      drop(v770_2);
      map_map_kernels::compose(&(v766_15),&(v770_5))
    };
    let v767_7: Space = map_map_kernels::unite(&(v767_4),&(v767_6));
    join_wrapped_into(&mut v766_16_write,&((v767_7).read_zipper()),&[]);
    }
    v766_16_cursor.ascend(1);
  }
  drop(v766_16_cursor);
  drop(v766_16_write);
  drop(v766_9);
  drop(v766_15);
  (v766_16).clone()
}

fn routine_92(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v772_7: Space = singleton(&(*p0));
  let v772_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v772_7));
  let v772_9: Space = if map_kernels::has_head(&(v772_8)) { singleton(&[]) } else { Space::new() };
  drop(v772_8);
  let v772_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v772_9));
  drop(v772_9);
  let v772_15: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v772_7));
  drop(v772_7);
  let v772_16: Space = if map_kernels::has_head(&(v772_15)) { singleton(&[]) } else { Space::new() };
  drop(v772_15);
  let mut v772_17 = Space::new();
  let mut v772_17_write = v772_17.write_zipper();
  let mut v772_17_cursor = (*s0).read_zipper();
  let v772_17_origin = v772_17_cursor.path().len();
  for v772_17_byte in v772_17_cursor.child_mask().iter() {
    v772_17_cursor.descend_to_existing_byte(v772_17_byte);
    {
    let v773_4: Space = if (&(v772_10)).is_empty() { Space::new() } else {
      let v774_2: Path = concat_path(&(*p1),&v772_17_cursor.path()[v772_17_origin..(v772_17_origin + 1)]);
      let mut v774_3 = Space::new();
      let mut v774_3_write = v774_3.write_zipper();
      let v774_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v774_3_arg_1: &[u8] = &(v774_2);
      let v774_3_arg_2: &[u8] = &(*p2);
      let v774_3_arg_3: &[u8] = &(*p3);
      let v774_3_arg_5: &Space = &(&v772_17_cursor).make_map();
      let mut v774_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v774_3_origin = v774_3_cursor.path().len();
      let mut v774_3_more = v774_3_cursor.is_val() || next_value_within(&mut v774_3_cursor,v774_3_origin);
      while v774_3_more {
        {
        let v774_3_depth = v774_3_cursor.path().len();
        let v775_6: Space = routine_92(c, &v774_3_cursor.path()[v774_3_origin..v774_3_depth], &(*v774_3_arg_1), &(*v774_3_arg_2), &(*v774_3_arg_3), &((*v774_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v774_3_write,&((v775_6).read_zipper()),&[]);
        }
        v774_3_more = next_value_within(&mut v774_3_cursor,v774_3_origin);
      }
      drop(v774_3_cursor);
      drop(v774_3_write);
      map_map_kernels::compose(&(v772_10),&(v774_3))
    };
    let v773_6: Space = if (&(v772_16)).is_empty() { Space::new() } else {
      let v776_2: Path = concat_path(&(*p1),&v772_17_cursor.path()[v772_17_origin..(v772_17_origin + 1)]);
      let mut v776_5 = Space::new();
      let mut v776_5_write = v776_5.write_zipper();
      for v776_5_byte in v772_17_cursor.child_mask().iter() {
        v772_17_cursor.descend_to_existing_byte(v776_5_byte);
        {
        let v777_2: Space = routine_93(c, &v772_17_cursor.path()[(v772_17_origin + 1)..(v772_17_origin + 2)], &v772_17_cursor.path()[(v772_17_origin + 1)..(v772_17_origin + 2)], &(*p2), &(*p3), &(v776_2), &v772_17_cursor);
        join_wrapped_into(&mut v776_5_write,&((v777_2).read_zipper()),&[]);
        }
        v772_17_cursor.ascend(1);
      }
      drop(v776_5_write);
      drop(v776_2);
      map_map_kernels::compose(&(v772_16),&(v776_5))
    };
    let v773_7: Space = map_map_kernels::unite(&(v773_4),&(v773_6));
    join_wrapped_into(&mut v772_17_write,&((v773_7).read_zipper()),&[]);
    }
    v772_17_cursor.ascend(1);
  }
  drop(v772_17_cursor);
  drop(v772_17_write);
  drop(v772_10);
  drop(v772_16);
  (v772_17).clone()
}

fn routine_93(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v778_8: Space = singleton(&(*p1));
  let v778_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v778_8));
  let v778_10: Space = if map_kernels::has_head(&(v778_9)) { singleton(&[]) } else { Space::new() };
  drop(v778_9);
  let v778_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v778_10));
  drop(v778_10);
  let v778_22: Space = if (&(v778_11)).is_empty() { Space::new() } else {
    let v779_14: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v779_17: Space = if (&(v779_14)).is_empty() { Space::new() } else {
      let v780_16: Space = routine_119(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*s0));
      map_map_kernels::compose(&(v779_14),&(v780_16))
    };
    drop(v779_14);
    let mut v779_20 = Space::new();
    let mut v779_20_write = v779_20.write_zipper();
    let mut v779_20_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v779_20_origin = v779_20_cursor.path().len();
    for v779_20_byte in v779_20_cursor.child_mask().iter() {
      v779_20_cursor.descend_to_existing_byte(v779_20_byte);
      {
      let v781_2_arg_0: &[u8] = &v779_20_cursor.path()[v779_20_origin..(v779_20_origin + 1)];
      let v781_2_arg_1: &[u8] = &(*p0);
      let v781_2_arg_2: &[u8] = &(*p2);
      let v781_2_arg_3: &[u8] = &(*p3);
      let v781_2_arg_4: &[u8] = &(*p4);
      let v781_2_arg_6: &Space = &(&(*s0)).make_map();
      let mut v781_2_more = v779_20_cursor.is_val() || next_value_within(&mut v779_20_cursor,(v779_20_origin + 1));
      while v781_2_more {
        {
        let v781_2_depth = v779_20_cursor.path().len();
        let mut v782_7_cursor = (*v781_2_arg_6).read_zipper();
        let v782_7_origin = v782_7_cursor.path().len();
        for v782_7_byte in v782_7_cursor.child_mask().iter() {
          v782_7_cursor.descend_to_existing_byte(v782_7_byte);
          {
          let v783_2: Path = concat_path(&(*v781_2_arg_1),&v782_7_cursor.path()[v782_7_origin..(v782_7_origin + 1)]);
          let v783_3: Space = routine_93(c, &(v783_2), &v779_20_cursor.path()[v779_20_origin..v781_2_depth], &(*v781_2_arg_2), &(*v781_2_arg_3), &(*v781_2_arg_4), &v782_7_cursor);
          drop(v783_2);
          join_wrapped_into(&mut v779_20_write,&((v783_3).read_zipper()),&[]);
          }
          v782_7_cursor.ascend(1);
        }
        drop(v782_7_cursor);
        }
        v781_2_more = next_value_within(&mut v779_20_cursor,(v779_20_origin + 1));
      }
      }
      v779_20_cursor.ascend(1);
    }
    drop(v779_20_cursor);
    drop(v779_20_write);
    let v779_21: Space = map_map_kernels::unite(&(v779_17),&(v779_20));
    map_map_kernels::compose(&(v778_11),&(v779_21))
  };
  drop(v778_11);
  let v778_24: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v778_8));
  drop(v778_8);
  let v778_25: Space = if map_kernels::has_head(&(v778_24)) { singleton(&[]) } else { Space::new() };
  drop(v778_24);
  let v778_27: Space = if (&(v778_25)).is_empty() { Space::new() } else {
    let mut v784_26 = Space::new();
    let mut v784_26_write = v784_26.write_zipper();
    let mut v784_26_cursor = (*s0).read_zipper();
    let v784_26_origin = v784_26_cursor.path().len();
    for v784_26_byte in v784_26_cursor.child_mask().iter() {
      v784_26_cursor.descend_to_existing_byte(v784_26_byte);
      {
      let v785_2: Space = routine_120(c, &v784_26_cursor.path()[v784_26_origin..(v784_26_origin + 1)], &v784_26_cursor.path()[v784_26_origin..(v784_26_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p0), &v784_26_cursor);
      join_wrapped_into(&mut v784_26_write,&((v785_2).read_zipper()),&[]);
      }
      v784_26_cursor.ascend(1);
    }
    drop(v784_26_cursor);
    drop(v784_26_write);
    map_map_kernels::compose(&(v778_25),&(v784_26))
  };
  drop(v778_25);
  let v778_28: Space = map_map_kernels::unite(&(v778_22),&(v778_27));
  (v778_28).clone()
}

fn routine_94(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v786_6: Space = singleton(&(*p0));
  let v786_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v786_6));
  let v786_8: Space = if map_kernels::has_head(&(v786_7)) { singleton(&[]) } else { Space::new() };
  drop(v786_7);
  let v786_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v786_8));
  drop(v786_8);
  let v786_14: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v786_6));
  drop(v786_6);
  let v786_15: Space = if map_kernels::has_head(&(v786_14)) { singleton(&[]) } else { Space::new() };
  drop(v786_14);
  let mut v786_16 = Space::new();
  let mut v786_16_write = v786_16.write_zipper();
  let mut v786_16_cursor = (*s0).read_zipper();
  let v786_16_origin = v786_16_cursor.path().len();
  for v786_16_byte in v786_16_cursor.child_mask().iter() {
    v786_16_cursor.descend_to_existing_byte(v786_16_byte);
    {
    let v787_4: Space = if (&(v786_9)).is_empty() { Space::new() } else {
      let v788_2: Path = concat_path(&(*p1),&v786_16_cursor.path()[v786_16_origin..(v786_16_origin + 1)]);
      let mut v788_3 = Space::new();
      let mut v788_3_write = v788_3.write_zipper();
      let v788_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v788_3_arg_1: &[u8] = &(v788_2);
      let v788_3_arg_2: &[u8] = &(*p2);
      let v788_3_arg_4: &Space = &(&v786_16_cursor).make_map();
      let mut v788_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v788_3_origin = v788_3_cursor.path().len();
      let mut v788_3_more = v788_3_cursor.is_val() || next_value_within(&mut v788_3_cursor,v788_3_origin);
      while v788_3_more {
        {
        let v788_3_depth = v788_3_cursor.path().len();
        let v789_5: Space = routine_94(c, &v788_3_cursor.path()[v788_3_origin..v788_3_depth], &(*v788_3_arg_1), &(*v788_3_arg_2), &((*v788_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v788_3_write,&((v789_5).read_zipper()),&[]);
        }
        v788_3_more = next_value_within(&mut v788_3_cursor,v788_3_origin);
      }
      drop(v788_3_cursor);
      drop(v788_3_write);
      map_map_kernels::compose(&(v786_9),&(v788_3))
    };
    let v787_6: Space = if (&(v786_15)).is_empty() { Space::new() } else {
      let v790_2: Path = concat_path(&(*p1),&v786_16_cursor.path()[v786_16_origin..(v786_16_origin + 1)]);
      let mut v790_5 = Space::new();
      let mut v790_5_write = v790_5.write_zipper();
      for v790_5_byte in v786_16_cursor.child_mask().iter() {
        v786_16_cursor.descend_to_existing_byte(v790_5_byte);
        {
        let v791_2: Space = routine_60(c, &v786_16_cursor.path()[(v786_16_origin + 1)..(v786_16_origin + 2)], &v786_16_cursor.path()[(v786_16_origin + 1)..(v786_16_origin + 2)], &(*p2), &(v790_2), &v786_16_cursor);
        join_wrapped_into(&mut v790_5_write,&((v791_2).read_zipper()),&[]);
        }
        v786_16_cursor.ascend(1);
      }
      drop(v790_5_write);
      drop(v790_2);
      map_map_kernels::compose(&(v786_15),&(v790_5))
    };
    let v787_7: Space = map_map_kernels::unite(&(v787_4),&(v787_6));
    join_wrapped_into(&mut v786_16_write,&((v787_7).read_zipper()),&[]);
    }
    v786_16_cursor.ascend(1);
  }
  drop(v786_16_cursor);
  drop(v786_16_write);
  drop(v786_9);
  drop(v786_15);
  (v786_16).clone()
}

fn routine_95(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v792_7: Space = singleton(&(*p0));
  let v792_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v792_7));
  let v792_9: Space = if map_kernels::has_head(&(v792_8)) { singleton(&[]) } else { Space::new() };
  drop(v792_8);
  let v792_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v792_9));
  drop(v792_9);
  let v792_15: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v792_7));
  drop(v792_7);
  let v792_16: Space = if map_kernels::has_head(&(v792_15)) { singleton(&[]) } else { Space::new() };
  drop(v792_15);
  let mut v792_17 = Space::new();
  let mut v792_17_write = v792_17.write_zipper();
  let mut v792_17_cursor = (*s0).read_zipper();
  let v792_17_origin = v792_17_cursor.path().len();
  for v792_17_byte in v792_17_cursor.child_mask().iter() {
    v792_17_cursor.descend_to_existing_byte(v792_17_byte);
    {
    let v793_4: Space = if (&(v792_10)).is_empty() { Space::new() } else {
      let v794_2: Path = concat_path(&(*p1),&v792_17_cursor.path()[v792_17_origin..(v792_17_origin + 1)]);
      let mut v794_3 = Space::new();
      let mut v794_3_write = v794_3.write_zipper();
      let v794_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v794_3_arg_1: &[u8] = &(v794_2);
      let v794_3_arg_2: &[u8] = &(*p2);
      let v794_3_arg_3: &[u8] = &(*p3);
      let v794_3_arg_5: &Space = &(&v792_17_cursor).make_map();
      let mut v794_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v794_3_origin = v794_3_cursor.path().len();
      let mut v794_3_more = v794_3_cursor.is_val() || next_value_within(&mut v794_3_cursor,v794_3_origin);
      while v794_3_more {
        {
        let v794_3_depth = v794_3_cursor.path().len();
        let v795_6: Space = routine_95(c, &v794_3_cursor.path()[v794_3_origin..v794_3_depth], &(*v794_3_arg_1), &(*v794_3_arg_2), &(*v794_3_arg_3), &((*v794_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v794_3_write,&((v795_6).read_zipper()),&[]);
        }
        v794_3_more = next_value_within(&mut v794_3_cursor,v794_3_origin);
      }
      drop(v794_3_cursor);
      drop(v794_3_write);
      map_map_kernels::compose(&(v792_10),&(v794_3))
    };
    let v793_6: Space = if (&(v792_16)).is_empty() { Space::new() } else {
      let v796_2: Path = concat_path(&(*p1),&v792_17_cursor.path()[v792_17_origin..(v792_17_origin + 1)]);
      let mut v796_5 = Space::new();
      let mut v796_5_write = v796_5.write_zipper();
      for v796_5_byte in v792_17_cursor.child_mask().iter() {
        v792_17_cursor.descend_to_existing_byte(v796_5_byte);
        {
        let v797_2: Space = routine_96(c, &v792_17_cursor.path()[(v792_17_origin + 1)..(v792_17_origin + 2)], &v792_17_cursor.path()[(v792_17_origin + 1)..(v792_17_origin + 2)], &(*p2), &(*p3), &(v796_2), &v792_17_cursor);
        join_wrapped_into(&mut v796_5_write,&((v797_2).read_zipper()),&[]);
        }
        v792_17_cursor.ascend(1);
      }
      drop(v796_5_write);
      drop(v796_2);
      map_map_kernels::compose(&(v792_16),&(v796_5))
    };
    let v793_7: Space = map_map_kernels::unite(&(v793_4),&(v793_6));
    join_wrapped_into(&mut v792_17_write,&((v793_7).read_zipper()),&[]);
    }
    v792_17_cursor.ascend(1);
  }
  drop(v792_17_cursor);
  drop(v792_17_write);
  drop(v792_10);
  drop(v792_16);
  (v792_17).clone()
}

fn routine_96(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v798_8: Space = singleton(&(*p1));
  let v798_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v798_8));
  let v798_10: Space = if map_kernels::has_head(&(v798_9)) { singleton(&[]) } else { Space::new() };
  drop(v798_9);
  let v798_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v798_10));
  drop(v798_10);
  let v798_22: Space = if (&(v798_11)).is_empty() { Space::new() } else {
    let v799_14: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v799_17: Space = if (&(v799_14)).is_empty() { Space::new() } else {
      let v800_16: Space = routine_121(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*s0));
      map_map_kernels::compose(&(v799_14),&(v800_16))
    };
    drop(v799_14);
    let mut v799_20 = Space::new();
    let mut v799_20_write = v799_20.write_zipper();
    let mut v799_20_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v799_20_origin = v799_20_cursor.path().len();
    for v799_20_byte in v799_20_cursor.child_mask().iter() {
      v799_20_cursor.descend_to_existing_byte(v799_20_byte);
      {
      let v801_2_arg_0: &[u8] = &v799_20_cursor.path()[v799_20_origin..(v799_20_origin + 1)];
      let v801_2_arg_1: &[u8] = &(*p0);
      let v801_2_arg_2: &[u8] = &(*p2);
      let v801_2_arg_3: &[u8] = &(*p3);
      let v801_2_arg_4: &[u8] = &(*p4);
      let v801_2_arg_6: &Space = &(&(*s0)).make_map();
      let mut v801_2_more = v799_20_cursor.is_val() || next_value_within(&mut v799_20_cursor,(v799_20_origin + 1));
      while v801_2_more {
        {
        let v801_2_depth = v799_20_cursor.path().len();
        let mut v802_7_cursor = (*v801_2_arg_6).read_zipper();
        let v802_7_origin = v802_7_cursor.path().len();
        for v802_7_byte in v802_7_cursor.child_mask().iter() {
          v802_7_cursor.descend_to_existing_byte(v802_7_byte);
          {
          let v803_2: Path = concat_path(&(*v801_2_arg_1),&v802_7_cursor.path()[v802_7_origin..(v802_7_origin + 1)]);
          let v803_3: Space = routine_96(c, &(v803_2), &v799_20_cursor.path()[v799_20_origin..v801_2_depth], &(*v801_2_arg_2), &(*v801_2_arg_3), &(*v801_2_arg_4), &v802_7_cursor);
          drop(v803_2);
          join_wrapped_into(&mut v799_20_write,&((v803_3).read_zipper()),&[]);
          }
          v802_7_cursor.ascend(1);
        }
        drop(v802_7_cursor);
        }
        v801_2_more = next_value_within(&mut v799_20_cursor,(v799_20_origin + 1));
      }
      }
      v799_20_cursor.ascend(1);
    }
    drop(v799_20_cursor);
    drop(v799_20_write);
    let v799_21: Space = map_map_kernels::unite(&(v799_17),&(v799_20));
    map_map_kernels::compose(&(v798_11),&(v799_21))
  };
  drop(v798_11);
  let v798_24: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v798_8));
  drop(v798_8);
  let v798_25: Space = if map_kernels::has_head(&(v798_24)) { singleton(&[]) } else { Space::new() };
  drop(v798_24);
  let v798_27: Space = if (&(v798_25)).is_empty() { Space::new() } else {
    let mut v804_26 = Space::new();
    let mut v804_26_write = v804_26.write_zipper();
    let mut v804_26_cursor = (*s0).read_zipper();
    let v804_26_origin = v804_26_cursor.path().len();
    for v804_26_byte in v804_26_cursor.child_mask().iter() {
      v804_26_cursor.descend_to_existing_byte(v804_26_byte);
      {
      let v805_2: Space = routine_122(c, &v804_26_cursor.path()[v804_26_origin..(v804_26_origin + 1)], &v804_26_cursor.path()[v804_26_origin..(v804_26_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p0), &v804_26_cursor);
      join_wrapped_into(&mut v804_26_write,&((v805_2).read_zipper()),&[]);
      }
      v804_26_cursor.ascend(1);
    }
    drop(v804_26_cursor);
    drop(v804_26_write);
    map_map_kernels::compose(&(v798_25),&(v804_26))
  };
  drop(v798_25);
  let v798_28: Space = map_map_kernels::unite(&(v798_22),&(v798_27));
  (v798_28).clone()
}

fn routine_97(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v806_6: Space = singleton(&(*p0));
  let v806_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v806_6));
  let v806_8: Space = if map_kernels::has_head(&(v806_7)) { singleton(&[]) } else { Space::new() };
  drop(v806_7);
  let v806_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v806_8));
  drop(v806_8);
  let v806_14: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v806_6));
  drop(v806_6);
  let v806_15: Space = if map_kernels::has_head(&(v806_14)) { singleton(&[]) } else { Space::new() };
  drop(v806_14);
  let mut v806_16 = Space::new();
  let mut v806_16_write = v806_16.write_zipper();
  let mut v806_16_cursor = (*s0).read_zipper();
  let v806_16_origin = v806_16_cursor.path().len();
  for v806_16_byte in v806_16_cursor.child_mask().iter() {
    v806_16_cursor.descend_to_existing_byte(v806_16_byte);
    {
    let v807_4: Space = if (&(v806_9)).is_empty() { Space::new() } else {
      let v808_2: Path = concat_path(&(*p1),&v806_16_cursor.path()[v806_16_origin..(v806_16_origin + 1)]);
      let mut v808_3 = Space::new();
      let mut v808_3_write = v808_3.write_zipper();
      let v808_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v808_3_arg_1: &[u8] = &(v808_2);
      let v808_3_arg_2: &[u8] = &(*p2);
      let v808_3_arg_4: &Space = &(&v806_16_cursor).make_map();
      let mut v808_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v808_3_origin = v808_3_cursor.path().len();
      let mut v808_3_more = v808_3_cursor.is_val() || next_value_within(&mut v808_3_cursor,v808_3_origin);
      while v808_3_more {
        {
        let v808_3_depth = v808_3_cursor.path().len();
        let v809_5: Space = routine_97(c, &v808_3_cursor.path()[v808_3_origin..v808_3_depth], &(*v808_3_arg_1), &(*v808_3_arg_2), &((*v808_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v808_3_write,&((v809_5).read_zipper()),&[]);
        }
        v808_3_more = next_value_within(&mut v808_3_cursor,v808_3_origin);
      }
      drop(v808_3_cursor);
      drop(v808_3_write);
      map_map_kernels::compose(&(v806_9),&(v808_3))
    };
    let v807_6: Space = if (&(v806_15)).is_empty() { Space::new() } else {
      let v810_2: Path = concat_path(&(*p1),&v806_16_cursor.path()[v806_16_origin..(v806_16_origin + 1)]);
      let mut v810_5 = Space::new();
      let mut v810_5_write = v810_5.write_zipper();
      for v810_5_byte in v806_16_cursor.child_mask().iter() {
        v806_16_cursor.descend_to_existing_byte(v810_5_byte);
        {
        let v811_2: Space = routine_63(c, &v806_16_cursor.path()[(v806_16_origin + 1)..(v806_16_origin + 2)], &v806_16_cursor.path()[(v806_16_origin + 1)..(v806_16_origin + 2)], &(*p2), &(v810_2), &v806_16_cursor);
        join_wrapped_into(&mut v810_5_write,&((v811_2).read_zipper()),&[]);
        }
        v806_16_cursor.ascend(1);
      }
      drop(v810_5_write);
      drop(v810_2);
      map_map_kernels::compose(&(v806_15),&(v810_5))
    };
    let v807_7: Space = map_map_kernels::unite(&(v807_4),&(v807_6));
    join_wrapped_into(&mut v806_16_write,&((v807_7).read_zipper()),&[]);
    }
    v806_16_cursor.ascend(1);
  }
  drop(v806_16_cursor);
  drop(v806_16_write);
  drop(v806_9);
  drop(v806_15);
  (v806_16).clone()
}

fn routine_98(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v812_7: Space = singleton(&(*p0));
  let v812_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v812_7));
  let v812_9: Space = if map_kernels::has_head(&(v812_8)) { singleton(&[]) } else { Space::new() };
  drop(v812_8);
  let v812_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v812_9));
  drop(v812_9);
  let v812_15: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v812_7));
  drop(v812_7);
  let v812_16: Space = if map_kernels::has_head(&(v812_15)) { singleton(&[]) } else { Space::new() };
  drop(v812_15);
  let mut v812_17 = Space::new();
  let mut v812_17_write = v812_17.write_zipper();
  let mut v812_17_cursor = (*s0).read_zipper();
  let v812_17_origin = v812_17_cursor.path().len();
  for v812_17_byte in v812_17_cursor.child_mask().iter() {
    v812_17_cursor.descend_to_existing_byte(v812_17_byte);
    {
    let v813_4: Space = if (&(v812_10)).is_empty() { Space::new() } else {
      let v814_2: Path = concat_path(&(*p1),&v812_17_cursor.path()[v812_17_origin..(v812_17_origin + 1)]);
      let mut v814_3 = Space::new();
      let mut v814_3_write = v814_3.write_zipper();
      let v814_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v814_3_arg_1: &[u8] = &(v814_2);
      let v814_3_arg_2: &[u8] = &(*p2);
      let v814_3_arg_3: &[u8] = &(*p3);
      let v814_3_arg_5: &Space = &(&v812_17_cursor).make_map();
      let mut v814_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v814_3_origin = v814_3_cursor.path().len();
      let mut v814_3_more = v814_3_cursor.is_val() || next_value_within(&mut v814_3_cursor,v814_3_origin);
      while v814_3_more {
        {
        let v814_3_depth = v814_3_cursor.path().len();
        let v815_6: Space = routine_98(c, &v814_3_cursor.path()[v814_3_origin..v814_3_depth], &(*v814_3_arg_1), &(*v814_3_arg_2), &(*v814_3_arg_3), &((*v814_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v814_3_write,&((v815_6).read_zipper()),&[]);
        }
        v814_3_more = next_value_within(&mut v814_3_cursor,v814_3_origin);
      }
      drop(v814_3_cursor);
      drop(v814_3_write);
      map_map_kernels::compose(&(v812_10),&(v814_3))
    };
    let v813_6: Space = if (&(v812_16)).is_empty() { Space::new() } else {
      let v816_2: Path = concat_path(&(*p1),&v812_17_cursor.path()[v812_17_origin..(v812_17_origin + 1)]);
      let mut v816_5 = Space::new();
      let mut v816_5_write = v816_5.write_zipper();
      for v816_5_byte in v812_17_cursor.child_mask().iter() {
        v812_17_cursor.descend_to_existing_byte(v816_5_byte);
        {
        let v817_2: Space = routine_99(c, &v812_17_cursor.path()[(v812_17_origin + 1)..(v812_17_origin + 2)], &v812_17_cursor.path()[(v812_17_origin + 1)..(v812_17_origin + 2)], &(*p2), &(*p3), &(v816_2), &v812_17_cursor);
        join_wrapped_into(&mut v816_5_write,&((v817_2).read_zipper()),&[]);
        }
        v812_17_cursor.ascend(1);
      }
      drop(v816_5_write);
      drop(v816_2);
      map_map_kernels::compose(&(v812_16),&(v816_5))
    };
    let v813_7: Space = map_map_kernels::unite(&(v813_4),&(v813_6));
    join_wrapped_into(&mut v812_17_write,&((v813_7).read_zipper()),&[]);
    }
    v812_17_cursor.ascend(1);
  }
  drop(v812_17_cursor);
  drop(v812_17_write);
  drop(v812_10);
  drop(v812_16);
  (v812_17).clone()
}

fn routine_99(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v818_8: Space = singleton(&(*p1));
  let v818_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v818_8));
  let v818_10: Space = if map_kernels::has_head(&(v818_9)) { singleton(&[]) } else { Space::new() };
  drop(v818_9);
  let v818_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v818_10));
  drop(v818_10);
  let v818_22: Space = if (&(v818_11)).is_empty() { Space::new() } else {
    let v819_14: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v819_17: Space = if (&(v819_14)).is_empty() { Space::new() } else {
      let v820_16: Space = routine_123(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*s0));
      map_map_kernels::compose(&(v819_14),&(v820_16))
    };
    drop(v819_14);
    let mut v819_20 = Space::new();
    let mut v819_20_write = v819_20.write_zipper();
    let mut v819_20_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v819_20_origin = v819_20_cursor.path().len();
    for v819_20_byte in v819_20_cursor.child_mask().iter() {
      v819_20_cursor.descend_to_existing_byte(v819_20_byte);
      {
      let v821_2_arg_0: &[u8] = &v819_20_cursor.path()[v819_20_origin..(v819_20_origin + 1)];
      let v821_2_arg_1: &[u8] = &(*p0);
      let v821_2_arg_2: &[u8] = &(*p2);
      let v821_2_arg_3: &[u8] = &(*p3);
      let v821_2_arg_4: &[u8] = &(*p4);
      let v821_2_arg_6: &Space = &(&(*s0)).make_map();
      let mut v821_2_more = v819_20_cursor.is_val() || next_value_within(&mut v819_20_cursor,(v819_20_origin + 1));
      while v821_2_more {
        {
        let v821_2_depth = v819_20_cursor.path().len();
        let mut v822_7_cursor = (*v821_2_arg_6).read_zipper();
        let v822_7_origin = v822_7_cursor.path().len();
        for v822_7_byte in v822_7_cursor.child_mask().iter() {
          v822_7_cursor.descend_to_existing_byte(v822_7_byte);
          {
          let v823_2: Path = concat_path(&(*v821_2_arg_1),&v822_7_cursor.path()[v822_7_origin..(v822_7_origin + 1)]);
          let v823_3: Space = routine_99(c, &(v823_2), &v819_20_cursor.path()[v819_20_origin..v821_2_depth], &(*v821_2_arg_2), &(*v821_2_arg_3), &(*v821_2_arg_4), &v822_7_cursor);
          drop(v823_2);
          join_wrapped_into(&mut v819_20_write,&((v823_3).read_zipper()),&[]);
          }
          v822_7_cursor.ascend(1);
        }
        drop(v822_7_cursor);
        }
        v821_2_more = next_value_within(&mut v819_20_cursor,(v819_20_origin + 1));
      }
      }
      v819_20_cursor.ascend(1);
    }
    drop(v819_20_cursor);
    drop(v819_20_write);
    let v819_21: Space = map_map_kernels::unite(&(v819_17),&(v819_20));
    map_map_kernels::compose(&(v818_11),&(v819_21))
  };
  drop(v818_11);
  let v818_24: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v818_8));
  drop(v818_8);
  let v818_25: Space = if map_kernels::has_head(&(v818_24)) { singleton(&[]) } else { Space::new() };
  drop(v818_24);
  let v818_27: Space = if (&(v818_25)).is_empty() { Space::new() } else {
    let mut v824_26 = Space::new();
    let mut v824_26_write = v824_26.write_zipper();
    let mut v824_26_cursor = (*s0).read_zipper();
    let v824_26_origin = v824_26_cursor.path().len();
    for v824_26_byte in v824_26_cursor.child_mask().iter() {
      v824_26_cursor.descend_to_existing_byte(v824_26_byte);
      {
      let v825_2: Space = routine_124(c, &v824_26_cursor.path()[v824_26_origin..(v824_26_origin + 1)], &v824_26_cursor.path()[v824_26_origin..(v824_26_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p0), &v824_26_cursor);
      join_wrapped_into(&mut v824_26_write,&((v825_2).read_zipper()),&[]);
      }
      v824_26_cursor.ascend(1);
    }
    drop(v824_26_cursor);
    drop(v824_26_write);
    map_map_kernels::compose(&(v818_25),&(v824_26))
  };
  drop(v818_25);
  let v818_28: Space = map_map_kernels::unite(&(v818_22),&(v818_27));
  (v818_28).clone()
}

fn routine_100(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v826_6: Space = singleton(&(*p0));
  let v826_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v826_6));
  let v826_8: Space = if map_kernels::has_head(&(v826_7)) { singleton(&[]) } else { Space::new() };
  drop(v826_7);
  let v826_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v826_8));
  drop(v826_8);
  let v826_14: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v826_6));
  drop(v826_6);
  let v826_15: Space = if map_kernels::has_head(&(v826_14)) { singleton(&[]) } else { Space::new() };
  drop(v826_14);
  let mut v826_16 = Space::new();
  let mut v826_16_write = v826_16.write_zipper();
  let mut v826_16_cursor = (*s0).read_zipper();
  let v826_16_origin = v826_16_cursor.path().len();
  for v826_16_byte in v826_16_cursor.child_mask().iter() {
    v826_16_cursor.descend_to_existing_byte(v826_16_byte);
    {
    let v827_4: Space = if (&(v826_9)).is_empty() { Space::new() } else {
      let v828_2: Path = concat_path(&(*p1),&v826_16_cursor.path()[v826_16_origin..(v826_16_origin + 1)]);
      let mut v828_3 = Space::new();
      let mut v828_3_write = v828_3.write_zipper();
      let v828_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v828_3_arg_1: &[u8] = &(v828_2);
      let v828_3_arg_2: &[u8] = &(*p2);
      let v828_3_arg_4: &Space = &(&v826_16_cursor).make_map();
      let mut v828_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v828_3_origin = v828_3_cursor.path().len();
      let mut v828_3_more = v828_3_cursor.is_val() || next_value_within(&mut v828_3_cursor,v828_3_origin);
      while v828_3_more {
        {
        let v828_3_depth = v828_3_cursor.path().len();
        let v829_5: Space = routine_100(c, &v828_3_cursor.path()[v828_3_origin..v828_3_depth], &(*v828_3_arg_1), &(*v828_3_arg_2), &((*v828_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v828_3_write,&((v829_5).read_zipper()),&[]);
        }
        v828_3_more = next_value_within(&mut v828_3_cursor,v828_3_origin);
      }
      drop(v828_3_cursor);
      drop(v828_3_write);
      map_map_kernels::compose(&(v826_9),&(v828_3))
    };
    let v827_6: Space = if (&(v826_15)).is_empty() { Space::new() } else {
      let v830_2: Path = concat_path(&(*p1),&v826_16_cursor.path()[v826_16_origin..(v826_16_origin + 1)]);
      let mut v830_5 = Space::new();
      let mut v830_5_write = v830_5.write_zipper();
      for v830_5_byte in v826_16_cursor.child_mask().iter() {
        v826_16_cursor.descend_to_existing_byte(v830_5_byte);
        {
        let v831_2: Space = routine_66(c, &v826_16_cursor.path()[(v826_16_origin + 1)..(v826_16_origin + 2)], &v826_16_cursor.path()[(v826_16_origin + 1)..(v826_16_origin + 2)], &(*p2), &(v830_2), &v826_16_cursor);
        join_wrapped_into(&mut v830_5_write,&((v831_2).read_zipper()),&[]);
        }
        v826_16_cursor.ascend(1);
      }
      drop(v830_5_write);
      drop(v830_2);
      map_map_kernels::compose(&(v826_15),&(v830_5))
    };
    let v827_7: Space = map_map_kernels::unite(&(v827_4),&(v827_6));
    join_wrapped_into(&mut v826_16_write,&((v827_7).read_zipper()),&[]);
    }
    v826_16_cursor.ascend(1);
  }
  drop(v826_16_cursor);
  drop(v826_16_write);
  drop(v826_9);
  drop(v826_15);
  (v826_16).clone()
}

fn routine_101(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v832_7: Space = singleton(&(*p0));
  let v832_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v832_7));
  let v832_9: Space = if map_kernels::has_head(&(v832_8)) { singleton(&[]) } else { Space::new() };
  drop(v832_8);
  let v832_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v832_9));
  drop(v832_9);
  let v832_15: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v832_7));
  drop(v832_7);
  let v832_16: Space = if map_kernels::has_head(&(v832_15)) { singleton(&[]) } else { Space::new() };
  drop(v832_15);
  let mut v832_17 = Space::new();
  let mut v832_17_write = v832_17.write_zipper();
  let mut v832_17_cursor = (*s0).read_zipper();
  let v832_17_origin = v832_17_cursor.path().len();
  for v832_17_byte in v832_17_cursor.child_mask().iter() {
    v832_17_cursor.descend_to_existing_byte(v832_17_byte);
    {
    let v833_4: Space = if (&(v832_10)).is_empty() { Space::new() } else {
      let v834_2: Path = concat_path(&(*p1),&v832_17_cursor.path()[v832_17_origin..(v832_17_origin + 1)]);
      let mut v834_3 = Space::new();
      let mut v834_3_write = v834_3.write_zipper();
      let v834_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v834_3_arg_1: &[u8] = &(v834_2);
      let v834_3_arg_2: &[u8] = &(*p2);
      let v834_3_arg_3: &[u8] = &(*p3);
      let v834_3_arg_5: &Space = &(&v832_17_cursor).make_map();
      let mut v834_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v834_3_origin = v834_3_cursor.path().len();
      let mut v834_3_more = v834_3_cursor.is_val() || next_value_within(&mut v834_3_cursor,v834_3_origin);
      while v834_3_more {
        {
        let v834_3_depth = v834_3_cursor.path().len();
        let v835_6: Space = routine_101(c, &v834_3_cursor.path()[v834_3_origin..v834_3_depth], &(*v834_3_arg_1), &(*v834_3_arg_2), &(*v834_3_arg_3), &((*v834_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v834_3_write,&((v835_6).read_zipper()),&[]);
        }
        v834_3_more = next_value_within(&mut v834_3_cursor,v834_3_origin);
      }
      drop(v834_3_cursor);
      drop(v834_3_write);
      map_map_kernels::compose(&(v832_10),&(v834_3))
    };
    let v833_6: Space = if (&(v832_16)).is_empty() { Space::new() } else {
      let v836_2: Path = concat_path(&(*p1),&v832_17_cursor.path()[v832_17_origin..(v832_17_origin + 1)]);
      let mut v836_5 = Space::new();
      let mut v836_5_write = v836_5.write_zipper();
      for v836_5_byte in v832_17_cursor.child_mask().iter() {
        v832_17_cursor.descend_to_existing_byte(v836_5_byte);
        {
        let v837_2: Space = routine_102(c, &v832_17_cursor.path()[(v832_17_origin + 1)..(v832_17_origin + 2)], &v832_17_cursor.path()[(v832_17_origin + 1)..(v832_17_origin + 2)], &(*p2), &(*p3), &(v836_2), &v832_17_cursor);
        join_wrapped_into(&mut v836_5_write,&((v837_2).read_zipper()),&[]);
        }
        v832_17_cursor.ascend(1);
      }
      drop(v836_5_write);
      drop(v836_2);
      map_map_kernels::compose(&(v832_16),&(v836_5))
    };
    let v833_7: Space = map_map_kernels::unite(&(v833_4),&(v833_6));
    join_wrapped_into(&mut v832_17_write,&((v833_7).read_zipper()),&[]);
    }
    v832_17_cursor.ascend(1);
  }
  drop(v832_17_cursor);
  drop(v832_17_write);
  drop(v832_10);
  drop(v832_16);
  (v832_17).clone()
}

fn routine_102(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v838_8: Space = singleton(&(*p1));
  let v838_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v838_8));
  let v838_10: Space = if map_kernels::has_head(&(v838_9)) { singleton(&[]) } else { Space::new() };
  drop(v838_9);
  let v838_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v838_10));
  drop(v838_10);
  let v838_22: Space = if (&(v838_11)).is_empty() { Space::new() } else {
    let v839_14: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v839_17: Space = if (&(v839_14)).is_empty() { Space::new() } else {
      let v840_16: Space = routine_125(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*s0));
      map_map_kernels::compose(&(v839_14),&(v840_16))
    };
    drop(v839_14);
    let mut v839_20 = Space::new();
    let mut v839_20_write = v839_20.write_zipper();
    let mut v839_20_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v839_20_origin = v839_20_cursor.path().len();
    for v839_20_byte in v839_20_cursor.child_mask().iter() {
      v839_20_cursor.descend_to_existing_byte(v839_20_byte);
      {
      let v841_2_arg_0: &[u8] = &v839_20_cursor.path()[v839_20_origin..(v839_20_origin + 1)];
      let v841_2_arg_1: &[u8] = &(*p0);
      let v841_2_arg_2: &[u8] = &(*p2);
      let v841_2_arg_3: &[u8] = &(*p3);
      let v841_2_arg_4: &[u8] = &(*p4);
      let v841_2_arg_6: &Space = &(&(*s0)).make_map();
      let mut v841_2_more = v839_20_cursor.is_val() || next_value_within(&mut v839_20_cursor,(v839_20_origin + 1));
      while v841_2_more {
        {
        let v841_2_depth = v839_20_cursor.path().len();
        let mut v842_7_cursor = (*v841_2_arg_6).read_zipper();
        let v842_7_origin = v842_7_cursor.path().len();
        for v842_7_byte in v842_7_cursor.child_mask().iter() {
          v842_7_cursor.descend_to_existing_byte(v842_7_byte);
          {
          let v843_2: Path = concat_path(&(*v841_2_arg_1),&v842_7_cursor.path()[v842_7_origin..(v842_7_origin + 1)]);
          let v843_3: Space = routine_102(c, &(v843_2), &v839_20_cursor.path()[v839_20_origin..v841_2_depth], &(*v841_2_arg_2), &(*v841_2_arg_3), &(*v841_2_arg_4), &v842_7_cursor);
          drop(v843_2);
          join_wrapped_into(&mut v839_20_write,&((v843_3).read_zipper()),&[]);
          }
          v842_7_cursor.ascend(1);
        }
        drop(v842_7_cursor);
        }
        v841_2_more = next_value_within(&mut v839_20_cursor,(v839_20_origin + 1));
      }
      }
      v839_20_cursor.ascend(1);
    }
    drop(v839_20_cursor);
    drop(v839_20_write);
    let v839_21: Space = map_map_kernels::unite(&(v839_17),&(v839_20));
    map_map_kernels::compose(&(v838_11),&(v839_21))
  };
  drop(v838_11);
  let v838_24: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v838_8));
  drop(v838_8);
  let v838_25: Space = if map_kernels::has_head(&(v838_24)) { singleton(&[]) } else { Space::new() };
  drop(v838_24);
  let v838_27: Space = if (&(v838_25)).is_empty() { Space::new() } else {
    let mut v844_26 = Space::new();
    let mut v844_26_write = v844_26.write_zipper();
    let mut v844_26_cursor = (*s0).read_zipper();
    let v844_26_origin = v844_26_cursor.path().len();
    for v844_26_byte in v844_26_cursor.child_mask().iter() {
      v844_26_cursor.descend_to_existing_byte(v844_26_byte);
      {
      let v845_2: Space = routine_126(c, &v844_26_cursor.path()[v844_26_origin..(v844_26_origin + 1)], &v844_26_cursor.path()[v844_26_origin..(v844_26_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p0), &v844_26_cursor);
      join_wrapped_into(&mut v844_26_write,&((v845_2).read_zipper()),&[]);
      }
      v844_26_cursor.ascend(1);
    }
    drop(v844_26_cursor);
    drop(v844_26_write);
    map_map_kernels::compose(&(v838_25),&(v844_26))
  };
  drop(v838_25);
  let v838_28: Space = map_map_kernels::unite(&(v838_22),&(v838_27));
  (v838_28).clone()
}

fn routine_103(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v846_6: Space = singleton(&(*p0));
  let v846_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v846_6));
  let v846_8: Space = if map_kernels::has_head(&(v846_7)) { singleton(&[]) } else { Space::new() };
  drop(v846_7);
  let v846_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v846_8));
  drop(v846_8);
  let v846_14: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v846_6));
  drop(v846_6);
  let v846_15: Space = if map_kernels::has_head(&(v846_14)) { singleton(&[]) } else { Space::new() };
  drop(v846_14);
  let mut v846_16 = Space::new();
  let mut v846_16_write = v846_16.write_zipper();
  let mut v846_16_cursor = (*s0).read_zipper();
  let v846_16_origin = v846_16_cursor.path().len();
  for v846_16_byte in v846_16_cursor.child_mask().iter() {
    v846_16_cursor.descend_to_existing_byte(v846_16_byte);
    {
    let v847_4: Space = if (&(v846_9)).is_empty() { Space::new() } else {
      let v848_2: Path = concat_path(&(*p1),&v846_16_cursor.path()[v846_16_origin..(v846_16_origin + 1)]);
      let mut v848_3 = Space::new();
      let mut v848_3_write = v848_3.write_zipper();
      let v848_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v848_3_arg_1: &[u8] = &(v848_2);
      let v848_3_arg_2: &[u8] = &(*p2);
      let v848_3_arg_4: &Space = &(&v846_16_cursor).make_map();
      let mut v848_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v848_3_origin = v848_3_cursor.path().len();
      let mut v848_3_more = v848_3_cursor.is_val() || next_value_within(&mut v848_3_cursor,v848_3_origin);
      while v848_3_more {
        {
        let v848_3_depth = v848_3_cursor.path().len();
        let v849_5: Space = routine_103(c, &v848_3_cursor.path()[v848_3_origin..v848_3_depth], &(*v848_3_arg_1), &(*v848_3_arg_2), &((*v848_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v848_3_write,&((v849_5).read_zipper()),&[]);
        }
        v848_3_more = next_value_within(&mut v848_3_cursor,v848_3_origin);
      }
      drop(v848_3_cursor);
      drop(v848_3_write);
      map_map_kernels::compose(&(v846_9),&(v848_3))
    };
    let v847_6: Space = if (&(v846_15)).is_empty() { Space::new() } else {
      let v850_2: Path = concat_path(&(*p1),&v846_16_cursor.path()[v846_16_origin..(v846_16_origin + 1)]);
      let mut v850_5 = Space::new();
      let mut v850_5_write = v850_5.write_zipper();
      for v850_5_byte in v846_16_cursor.child_mask().iter() {
        v846_16_cursor.descend_to_existing_byte(v850_5_byte);
        {
        let v851_2: Space = routine_69(c, &v846_16_cursor.path()[(v846_16_origin + 1)..(v846_16_origin + 2)], &v846_16_cursor.path()[(v846_16_origin + 1)..(v846_16_origin + 2)], &(*p2), &(v850_2), &v846_16_cursor);
        join_wrapped_into(&mut v850_5_write,&((v851_2).read_zipper()),&[]);
        }
        v846_16_cursor.ascend(1);
      }
      drop(v850_5_write);
      drop(v850_2);
      map_map_kernels::compose(&(v846_15),&(v850_5))
    };
    let v847_7: Space = map_map_kernels::unite(&(v847_4),&(v847_6));
    join_wrapped_into(&mut v846_16_write,&((v847_7).read_zipper()),&[]);
    }
    v846_16_cursor.ascend(1);
  }
  drop(v846_16_cursor);
  drop(v846_16_write);
  drop(v846_9);
  drop(v846_15);
  (v846_16).clone()
}

fn routine_104(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v852_7: Space = singleton(&(*p0));
  let v852_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v852_7));
  let v852_9: Space = if map_kernels::has_head(&(v852_8)) { singleton(&[]) } else { Space::new() };
  drop(v852_8);
  let v852_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v852_9));
  drop(v852_9);
  let v852_15: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v852_7));
  drop(v852_7);
  let v852_16: Space = if map_kernels::has_head(&(v852_15)) { singleton(&[]) } else { Space::new() };
  drop(v852_15);
  let mut v852_17 = Space::new();
  let mut v852_17_write = v852_17.write_zipper();
  let mut v852_17_cursor = (*s0).read_zipper();
  let v852_17_origin = v852_17_cursor.path().len();
  for v852_17_byte in v852_17_cursor.child_mask().iter() {
    v852_17_cursor.descend_to_existing_byte(v852_17_byte);
    {
    let v853_4: Space = if (&(v852_10)).is_empty() { Space::new() } else {
      let v854_2: Path = concat_path(&(*p1),&v852_17_cursor.path()[v852_17_origin..(v852_17_origin + 1)]);
      let mut v854_3 = Space::new();
      let mut v854_3_write = v854_3.write_zipper();
      let v854_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v854_3_arg_1: &[u8] = &(v854_2);
      let v854_3_arg_2: &[u8] = &(*p2);
      let v854_3_arg_3: &[u8] = &(*p3);
      let v854_3_arg_5: &Space = &(&v852_17_cursor).make_map();
      let mut v854_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v854_3_origin = v854_3_cursor.path().len();
      let mut v854_3_more = v854_3_cursor.is_val() || next_value_within(&mut v854_3_cursor,v854_3_origin);
      while v854_3_more {
        {
        let v854_3_depth = v854_3_cursor.path().len();
        let v855_6: Space = routine_104(c, &v854_3_cursor.path()[v854_3_origin..v854_3_depth], &(*v854_3_arg_1), &(*v854_3_arg_2), &(*v854_3_arg_3), &((*v854_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v854_3_write,&((v855_6).read_zipper()),&[]);
        }
        v854_3_more = next_value_within(&mut v854_3_cursor,v854_3_origin);
      }
      drop(v854_3_cursor);
      drop(v854_3_write);
      map_map_kernels::compose(&(v852_10),&(v854_3))
    };
    let v853_6: Space = if (&(v852_16)).is_empty() { Space::new() } else {
      let v856_2: Path = concat_path(&(*p1),&v852_17_cursor.path()[v852_17_origin..(v852_17_origin + 1)]);
      let mut v856_5 = Space::new();
      let mut v856_5_write = v856_5.write_zipper();
      for v856_5_byte in v852_17_cursor.child_mask().iter() {
        v852_17_cursor.descend_to_existing_byte(v856_5_byte);
        {
        let v857_2: Space = routine_105(c, &v852_17_cursor.path()[(v852_17_origin + 1)..(v852_17_origin + 2)], &v852_17_cursor.path()[(v852_17_origin + 1)..(v852_17_origin + 2)], &(*p2), &(*p3), &(v856_2), &v852_17_cursor);
        join_wrapped_into(&mut v856_5_write,&((v857_2).read_zipper()),&[]);
        }
        v852_17_cursor.ascend(1);
      }
      drop(v856_5_write);
      drop(v856_2);
      map_map_kernels::compose(&(v852_16),&(v856_5))
    };
    let v853_7: Space = map_map_kernels::unite(&(v853_4),&(v853_6));
    join_wrapped_into(&mut v852_17_write,&((v853_7).read_zipper()),&[]);
    }
    v852_17_cursor.ascend(1);
  }
  drop(v852_17_cursor);
  drop(v852_17_write);
  drop(v852_10);
  drop(v852_16);
  (v852_17).clone()
}

fn routine_105(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v858_8: Space = singleton(&(*p1));
  let v858_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v858_8));
  let v858_10: Space = if map_kernels::has_head(&(v858_9)) { singleton(&[]) } else { Space::new() };
  drop(v858_9);
  let v858_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v858_10));
  drop(v858_10);
  let v858_22: Space = if (&(v858_11)).is_empty() { Space::new() } else {
    let v859_14: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v859_17: Space = if (&(v859_14)).is_empty() { Space::new() } else {
      let v860_16: Space = routine_127(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*s0));
      map_map_kernels::compose(&(v859_14),&(v860_16))
    };
    drop(v859_14);
    let mut v859_20 = Space::new();
    let mut v859_20_write = v859_20.write_zipper();
    let mut v859_20_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v859_20_origin = v859_20_cursor.path().len();
    for v859_20_byte in v859_20_cursor.child_mask().iter() {
      v859_20_cursor.descend_to_existing_byte(v859_20_byte);
      {
      let v861_2_arg_0: &[u8] = &v859_20_cursor.path()[v859_20_origin..(v859_20_origin + 1)];
      let v861_2_arg_1: &[u8] = &(*p0);
      let v861_2_arg_2: &[u8] = &(*p2);
      let v861_2_arg_3: &[u8] = &(*p3);
      let v861_2_arg_4: &[u8] = &(*p4);
      let v861_2_arg_6: &Space = &(&(*s0)).make_map();
      let mut v861_2_more = v859_20_cursor.is_val() || next_value_within(&mut v859_20_cursor,(v859_20_origin + 1));
      while v861_2_more {
        {
        let v861_2_depth = v859_20_cursor.path().len();
        let mut v862_7_cursor = (*v861_2_arg_6).read_zipper();
        let v862_7_origin = v862_7_cursor.path().len();
        for v862_7_byte in v862_7_cursor.child_mask().iter() {
          v862_7_cursor.descend_to_existing_byte(v862_7_byte);
          {
          let v863_2: Path = concat_path(&(*v861_2_arg_1),&v862_7_cursor.path()[v862_7_origin..(v862_7_origin + 1)]);
          let v863_3: Space = routine_105(c, &(v863_2), &v859_20_cursor.path()[v859_20_origin..v861_2_depth], &(*v861_2_arg_2), &(*v861_2_arg_3), &(*v861_2_arg_4), &v862_7_cursor);
          drop(v863_2);
          join_wrapped_into(&mut v859_20_write,&((v863_3).read_zipper()),&[]);
          }
          v862_7_cursor.ascend(1);
        }
        drop(v862_7_cursor);
        }
        v861_2_more = next_value_within(&mut v859_20_cursor,(v859_20_origin + 1));
      }
      }
      v859_20_cursor.ascend(1);
    }
    drop(v859_20_cursor);
    drop(v859_20_write);
    let v859_21: Space = map_map_kernels::unite(&(v859_17),&(v859_20));
    map_map_kernels::compose(&(v858_11),&(v859_21))
  };
  drop(v858_11);
  let v858_24: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v858_8));
  drop(v858_8);
  let v858_25: Space = if map_kernels::has_head(&(v858_24)) { singleton(&[]) } else { Space::new() };
  drop(v858_24);
  let v858_27: Space = if (&(v858_25)).is_empty() { Space::new() } else {
    let mut v864_26 = Space::new();
    let mut v864_26_write = v864_26.write_zipper();
    let mut v864_26_cursor = (*s0).read_zipper();
    let v864_26_origin = v864_26_cursor.path().len();
    for v864_26_byte in v864_26_cursor.child_mask().iter() {
      v864_26_cursor.descend_to_existing_byte(v864_26_byte);
      {
      let v865_2: Space = routine_128(c, &v864_26_cursor.path()[v864_26_origin..(v864_26_origin + 1)], &v864_26_cursor.path()[v864_26_origin..(v864_26_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p0), &v864_26_cursor);
      join_wrapped_into(&mut v864_26_write,&((v865_2).read_zipper()),&[]);
      }
      v864_26_cursor.ascend(1);
    }
    drop(v864_26_cursor);
    drop(v864_26_write);
    map_map_kernels::compose(&(v858_25),&(v864_26))
  };
  drop(v858_25);
  let v858_28: Space = map_map_kernels::unite(&(v858_22),&(v858_27));
  (v858_28).clone()
}

fn routine_106(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v866_6: Space = singleton(&(*p0));
  let v866_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v866_6));
  let v866_8: Space = if map_kernels::has_head(&(v866_7)) { singleton(&[]) } else { Space::new() };
  drop(v866_7);
  let v866_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v866_8));
  drop(v866_8);
  let v866_14: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v866_6));
  drop(v866_6);
  let v866_15: Space = if map_kernels::has_head(&(v866_14)) { singleton(&[]) } else { Space::new() };
  drop(v866_14);
  let mut v866_16 = Space::new();
  let mut v866_16_write = v866_16.write_zipper();
  let mut v866_16_cursor = (*s0).read_zipper();
  let v866_16_origin = v866_16_cursor.path().len();
  for v866_16_byte in v866_16_cursor.child_mask().iter() {
    v866_16_cursor.descend_to_existing_byte(v866_16_byte);
    {
    let v867_4: Space = if (&(v866_9)).is_empty() { Space::new() } else {
      let v868_2: Path = concat_path(&(*p1),&v866_16_cursor.path()[v866_16_origin..(v866_16_origin + 1)]);
      let mut v868_3 = Space::new();
      let mut v868_3_write = v868_3.write_zipper();
      let v868_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v868_3_arg_1: &[u8] = &(v868_2);
      let v868_3_arg_2: &[u8] = &(*p2);
      let v868_3_arg_4: &Space = &(&v866_16_cursor).make_map();
      let mut v868_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v868_3_origin = v868_3_cursor.path().len();
      let mut v868_3_more = v868_3_cursor.is_val() || next_value_within(&mut v868_3_cursor,v868_3_origin);
      while v868_3_more {
        {
        let v868_3_depth = v868_3_cursor.path().len();
        let v869_5: Space = routine_106(c, &v868_3_cursor.path()[v868_3_origin..v868_3_depth], &(*v868_3_arg_1), &(*v868_3_arg_2), &((*v868_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v868_3_write,&((v869_5).read_zipper()),&[]);
        }
        v868_3_more = next_value_within(&mut v868_3_cursor,v868_3_origin);
      }
      drop(v868_3_cursor);
      drop(v868_3_write);
      map_map_kernels::compose(&(v866_9),&(v868_3))
    };
    let v867_6: Space = if (&(v866_15)).is_empty() { Space::new() } else {
      let v870_2: Path = concat_path(&(*p1),&v866_16_cursor.path()[v866_16_origin..(v866_16_origin + 1)]);
      let mut v870_5 = Space::new();
      let mut v870_5_write = v870_5.write_zipper();
      for v870_5_byte in v866_16_cursor.child_mask().iter() {
        v866_16_cursor.descend_to_existing_byte(v870_5_byte);
        {
        let v871_2: Space = routine_72(c, &v866_16_cursor.path()[(v866_16_origin + 1)..(v866_16_origin + 2)], &v866_16_cursor.path()[(v866_16_origin + 1)..(v866_16_origin + 2)], &(*p2), &(v870_2), &v866_16_cursor);
        join_wrapped_into(&mut v870_5_write,&((v871_2).read_zipper()),&[]);
        }
        v866_16_cursor.ascend(1);
      }
      drop(v870_5_write);
      drop(v870_2);
      map_map_kernels::compose(&(v866_15),&(v870_5))
    };
    let v867_7: Space = map_map_kernels::unite(&(v867_4),&(v867_6));
    join_wrapped_into(&mut v866_16_write,&((v867_7).read_zipper()),&[]);
    }
    v866_16_cursor.ascend(1);
  }
  drop(v866_16_cursor);
  drop(v866_16_write);
  drop(v866_9);
  drop(v866_15);
  (v866_16).clone()
}

fn routine_107(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v872_7: Space = singleton(&(*p0));
  let v872_8: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v872_7));
  let v872_9: Space = if map_kernels::has_head(&(v872_8)) { singleton(&[]) } else { Space::new() };
  drop(v872_8);
  let v872_10: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v872_9));
  drop(v872_9);
  let v872_15: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v872_7));
  drop(v872_7);
  let v872_16: Space = if map_kernels::has_head(&(v872_15)) { singleton(&[]) } else { Space::new() };
  drop(v872_15);
  let mut v872_17 = Space::new();
  let mut v872_17_write = v872_17.write_zipper();
  let mut v872_17_cursor = (*s0).read_zipper();
  let v872_17_origin = v872_17_cursor.path().len();
  for v872_17_byte in v872_17_cursor.child_mask().iter() {
    v872_17_cursor.descend_to_existing_byte(v872_17_byte);
    {
    let v873_4: Space = if (&(v872_10)).is_empty() { Space::new() } else {
      let v874_2: Path = concat_path(&(*p1),&v872_17_cursor.path()[v872_17_origin..(v872_17_origin + 1)]);
      let mut v874_3 = Space::new();
      let mut v874_3_write = v874_3.write_zipper();
      let v874_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v874_3_arg_1: &[u8] = &(v874_2);
      let v874_3_arg_2: &[u8] = &(*p2);
      let v874_3_arg_3: &[u8] = &(*p3);
      let v874_3_arg_5: &Space = &(&v872_17_cursor).make_map();
      let mut v874_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v874_3_origin = v874_3_cursor.path().len();
      let mut v874_3_more = v874_3_cursor.is_val() || next_value_within(&mut v874_3_cursor,v874_3_origin);
      while v874_3_more {
        {
        let v874_3_depth = v874_3_cursor.path().len();
        let v875_6: Space = routine_107(c, &v874_3_cursor.path()[v874_3_origin..v874_3_depth], &(*v874_3_arg_1), &(*v874_3_arg_2), &(*v874_3_arg_3), &((*v874_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v874_3_write,&((v875_6).read_zipper()),&[]);
        }
        v874_3_more = next_value_within(&mut v874_3_cursor,v874_3_origin);
      }
      drop(v874_3_cursor);
      drop(v874_3_write);
      map_map_kernels::compose(&(v872_10),&(v874_3))
    };
    let v873_6: Space = if (&(v872_16)).is_empty() { Space::new() } else {
      let v876_2: Path = concat_path(&(*p1),&v872_17_cursor.path()[v872_17_origin..(v872_17_origin + 1)]);
      let mut v876_5 = Space::new();
      let mut v876_5_write = v876_5.write_zipper();
      for v876_5_byte in v872_17_cursor.child_mask().iter() {
        v872_17_cursor.descend_to_existing_byte(v876_5_byte);
        {
        let v877_2: Space = routine_108(c, &v872_17_cursor.path()[(v872_17_origin + 1)..(v872_17_origin + 2)], &v872_17_cursor.path()[(v872_17_origin + 1)..(v872_17_origin + 2)], &(*p2), &(*p3), &(v876_2), &v872_17_cursor);
        join_wrapped_into(&mut v876_5_write,&((v877_2).read_zipper()),&[]);
        }
        v872_17_cursor.ascend(1);
      }
      drop(v876_5_write);
      drop(v876_2);
      map_map_kernels::compose(&(v872_16),&(v876_5))
    };
    let v873_7: Space = map_map_kernels::unite(&(v873_4),&(v873_6));
    join_wrapped_into(&mut v872_17_write,&((v873_7).read_zipper()),&[]);
    }
    v872_17_cursor.ascend(1);
  }
  drop(v872_17_cursor);
  drop(v872_17_write);
  drop(v872_10);
  drop(v872_16);
  (v872_17).clone()
}

fn routine_108(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v878_8: Space = singleton(&(*p1));
  let v878_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v878_8));
  let v878_10: Space = if map_kernels::has_head(&(v878_9)) { singleton(&[]) } else { Space::new() };
  drop(v878_9);
  let v878_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v878_10));
  drop(v878_10);
  let v878_22: Space = if (&(v878_11)).is_empty() { Space::new() } else {
    let v879_14: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v879_17: Space = if (&(v879_14)).is_empty() { Space::new() } else {
      let v880_16: Space = routine_129(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*s0));
      map_map_kernels::compose(&(v879_14),&(v880_16))
    };
    drop(v879_14);
    let mut v879_20 = Space::new();
    let mut v879_20_write = v879_20.write_zipper();
    let mut v879_20_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v879_20_origin = v879_20_cursor.path().len();
    for v879_20_byte in v879_20_cursor.child_mask().iter() {
      v879_20_cursor.descend_to_existing_byte(v879_20_byte);
      {
      let v881_2_arg_0: &[u8] = &v879_20_cursor.path()[v879_20_origin..(v879_20_origin + 1)];
      let v881_2_arg_1: &[u8] = &(*p0);
      let v881_2_arg_2: &[u8] = &(*p2);
      let v881_2_arg_3: &[u8] = &(*p3);
      let v881_2_arg_4: &[u8] = &(*p4);
      let v881_2_arg_6: &Space = &(&(*s0)).make_map();
      let mut v881_2_more = v879_20_cursor.is_val() || next_value_within(&mut v879_20_cursor,(v879_20_origin + 1));
      while v881_2_more {
        {
        let v881_2_depth = v879_20_cursor.path().len();
        let mut v882_7_cursor = (*v881_2_arg_6).read_zipper();
        let v882_7_origin = v882_7_cursor.path().len();
        for v882_7_byte in v882_7_cursor.child_mask().iter() {
          v882_7_cursor.descend_to_existing_byte(v882_7_byte);
          {
          let v883_2: Path = concat_path(&(*v881_2_arg_1),&v882_7_cursor.path()[v882_7_origin..(v882_7_origin + 1)]);
          let v883_3: Space = routine_108(c, &(v883_2), &v879_20_cursor.path()[v879_20_origin..v881_2_depth], &(*v881_2_arg_2), &(*v881_2_arg_3), &(*v881_2_arg_4), &v882_7_cursor);
          drop(v883_2);
          join_wrapped_into(&mut v879_20_write,&((v883_3).read_zipper()),&[]);
          }
          v882_7_cursor.ascend(1);
        }
        drop(v882_7_cursor);
        }
        v881_2_more = next_value_within(&mut v879_20_cursor,(v879_20_origin + 1));
      }
      }
      v879_20_cursor.ascend(1);
    }
    drop(v879_20_cursor);
    drop(v879_20_write);
    let v879_21: Space = map_map_kernels::unite(&(v879_17),&(v879_20));
    map_map_kernels::compose(&(v878_11),&(v879_21))
  };
  drop(v878_11);
  let v878_24: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v878_8));
  drop(v878_8);
  let v878_25: Space = if map_kernels::has_head(&(v878_24)) { singleton(&[]) } else { Space::new() };
  drop(v878_24);
  let v878_27: Space = if (&(v878_25)).is_empty() { Space::new() } else {
    let mut v884_26 = Space::new();
    let mut v884_26_write = v884_26.write_zipper();
    let mut v884_26_cursor = (*s0).read_zipper();
    let v884_26_origin = v884_26_cursor.path().len();
    for v884_26_byte in v884_26_cursor.child_mask().iter() {
      v884_26_cursor.descend_to_existing_byte(v884_26_byte);
      {
      let v885_2: Space = routine_130(c, &v884_26_cursor.path()[v884_26_origin..(v884_26_origin + 1)], &v884_26_cursor.path()[v884_26_origin..(v884_26_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p0), &v884_26_cursor);
      join_wrapped_into(&mut v884_26_write,&((v885_2).read_zipper()),&[]);
      }
      v884_26_cursor.ascend(1);
    }
    drop(v884_26_cursor);
    drop(v884_26_write);
    map_map_kernels::compose(&(v878_25),&(v884_26))
  };
  drop(v878_25);
  let v878_28: Space = map_map_kernels::unite(&(v878_22),&(v878_27));
  (v878_28).clone()
}

fn routine_109(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v886_6: Space = singleton(&(*p0));
  let v886_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v886_6));
  let v886_8: Space = if map_kernels::has_head(&(v886_7)) { singleton(&[]) } else { Space::new() };
  drop(v886_7);
  let v886_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v886_8));
  drop(v886_8);
  let v886_14: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v886_6));
  drop(v886_6);
  let v886_15: Space = if map_kernels::has_head(&(v886_14)) { singleton(&[]) } else { Space::new() };
  drop(v886_14);
  let mut v886_17 = Space::new();
  let mut v886_17_write = v886_17.write_zipper();
  let mut v886_17_cursor = (*s0).read_zipper();
  let v886_17_origin = v886_17_cursor.path().len();
  for v886_17_byte in v886_17_cursor.child_mask().iter() {
    v886_17_cursor.descend_to_existing_byte(v886_17_byte);
    {
    let v887_4: Space = if (&(v886_9)).is_empty() { Space::new() } else {
      let v888_2: Path = concat_path(&(*p1),&v886_17_cursor.path()[v886_17_origin..(v886_17_origin + 1)]);
      let mut v888_3 = Space::new();
      let mut v888_3_write = v888_3.write_zipper();
      let v888_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v888_3_arg_1: &[u8] = &(v888_2);
      let v888_3_arg_2: &[u8] = &(*p2);
      let v888_3_arg_4: &Space = &(&v886_17_cursor).make_map();
      let mut v888_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v888_3_origin = v888_3_cursor.path().len();
      let mut v888_3_more = v888_3_cursor.is_val() || next_value_within(&mut v888_3_cursor,v888_3_origin);
      while v888_3_more {
        {
        let v888_3_depth = v888_3_cursor.path().len();
        let v889_5: Space = routine_109(c, &v888_3_cursor.path()[v888_3_origin..v888_3_depth], &(*v888_3_arg_1), &(*v888_3_arg_2), &((*v888_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v888_3_write,&((v889_5).read_zipper()),&[]);
        }
        v888_3_more = next_value_within(&mut v888_3_cursor,v888_3_origin);
      }
      drop(v888_3_cursor);
      drop(v888_3_write);
      map_map_kernels::compose(&(v886_9),&(v888_3))
    };
    let v887_8: Space = if (&(v886_15)).is_empty() { Space::new() } else {
      let mut v890_5 = Space::new();
      let mut v890_5_write = v890_5.write_zipper();
      for v890_5_byte in v886_17_cursor.child_mask().iter() {
        v886_17_cursor.descend_to_existing_byte(v890_5_byte);
        {
        let v891_2: Space = routine_110(c, &v886_17_cursor.path()[(v886_17_origin + 1)..(v886_17_origin + 2)], &v886_17_cursor.path()[(v886_17_origin + 1)..(v886_17_origin + 2)], &v886_17_cursor);
        join_wrapped_into(&mut v890_5_write,&((v891_2).read_zipper()),&[]);
        }
        v886_17_cursor.ascend(1);
      }
      drop(v890_5_write);
      let v890_6: Space = map_map_kernels::raffine(&(*CONSTANT_17),&(v890_5));
      let v890_7: Space = map_view_kernels::unite(&(v890_6),&v886_17_cursor);
      map_map_kernels::compose(&(v886_15),&(v890_7))
    };
    let v892_2: Path = concat_path(&(*p1),&v886_17_cursor.path()[v886_17_origin..(v886_17_origin + 1)]);
    let v887_9: Path = concat_path(&(*p2),&(v892_2));
    let v887_10: Space = map_kernels::wrap(&(v887_8),&(v887_9));
    drop(v887_9);
    let v887_11: Space = map_map_kernels::unite(&(v887_4),&(v887_10));
    join_wrapped_into(&mut v886_17_write,&((v887_11).read_zipper()),&[]);
    }
    v886_17_cursor.ascend(1);
  }
  drop(v886_17_cursor);
  drop(v886_17_write);
  drop(v886_9);
  drop(v886_15);
  (v886_17).clone()
}

fn routine_110(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v893_5: Space = singleton(&(*p1));
  let v893_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v893_5));
  let v893_7: Space = if map_kernels::has_head(&(v893_6)) { singleton(&[]) } else { Space::new() };
  drop(v893_6);
  let v893_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v893_7));
  drop(v893_7);
  let v893_19: Space = if (&(v893_8)).is_empty() { Space::new() } else {
    let v894_11: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v894_14: Space = if (&(v894_11)).is_empty() { Space::new() } else {
      let v895_13: Space = routine_131(c, &(*CONSTANT_1), &(*p0), &(*s0));
      map_map_kernels::compose(&(v894_11),&(v895_13))
    };
    drop(v894_11);
    let mut v894_17 = Space::new();
    let mut v894_17_write = v894_17.write_zipper();
    let mut v894_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v894_17_origin = v894_17_cursor.path().len();
    for v894_17_byte in v894_17_cursor.child_mask().iter() {
      v894_17_cursor.descend_to_existing_byte(v894_17_byte);
      {
      let v896_2_arg_0: &[u8] = &v894_17_cursor.path()[v894_17_origin..(v894_17_origin + 1)];
      let v896_2_arg_1: &[u8] = &(*p0);
      let v896_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v896_2_more = v894_17_cursor.is_val() || next_value_within(&mut v894_17_cursor,(v894_17_origin + 1));
      while v896_2_more {
        {
        let v896_2_depth = v894_17_cursor.path().len();
        let mut v897_4_cursor = (*v896_2_arg_3).read_zipper();
        let v897_4_origin = v897_4_cursor.path().len();
        for v897_4_byte in v897_4_cursor.child_mask().iter() {
          v897_4_cursor.descend_to_existing_byte(v897_4_byte);
          {
          let v898_2: Path = concat_path(&(*v896_2_arg_1),&v897_4_cursor.path()[v897_4_origin..(v897_4_origin + 1)]);
          let v898_3: Space = routine_110(c, &(v898_2), &v894_17_cursor.path()[v894_17_origin..v896_2_depth], &v897_4_cursor);
          drop(v898_2);
          join_wrapped_into(&mut v894_17_write,&((v898_3).read_zipper()),&[]);
          }
          v897_4_cursor.ascend(1);
        }
        drop(v897_4_cursor);
        }
        v896_2_more = next_value_within(&mut v894_17_cursor,(v894_17_origin + 1));
      }
      }
      v894_17_cursor.ascend(1);
    }
    drop(v894_17_cursor);
    drop(v894_17_write);
    let v894_18: Space = map_map_kernels::unite(&(v894_14),&(v894_17));
    map_map_kernels::compose(&(v893_8),&(v894_18))
  };
  drop(v893_8);
  let v893_21: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v893_5));
  drop(v893_5);
  let v893_22: Space = if map_kernels::has_head(&(v893_21)) { singleton(&[]) } else { Space::new() };
  drop(v893_21);
  let v893_24: Space = if (&(v893_22)).is_empty() { Space::new() } else {
    let v899_23: Space = singleton(&(*p0));
    map_map_kernels::compose(&(v893_22),&(v899_23))
  };
  drop(v893_22);
  let v893_25: Space = map_map_kernels::unite(&(v893_19),&(v893_24));
  drop(v893_24);
  (v893_25).clone()
}

fn routine_111(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v900_6: Space = singleton(&(*p0));
  let v900_7: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v900_6));
  let v900_8: Space = if map_kernels::has_head(&(v900_7)) { singleton(&[]) } else { Space::new() };
  drop(v900_7);
  let v900_9: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v900_8));
  drop(v900_8);
  let v900_14: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v900_6));
  drop(v900_6);
  let v900_15: Space = if map_kernels::has_head(&(v900_14)) { singleton(&[]) } else { Space::new() };
  drop(v900_14);
  let mut v900_17 = Space::new();
  let mut v900_17_write = v900_17.write_zipper();
  let mut v900_17_cursor = (*s0).read_zipper();
  let v900_17_origin = v900_17_cursor.path().len();
  for v900_17_byte in v900_17_cursor.child_mask().iter() {
    v900_17_cursor.descend_to_existing_byte(v900_17_byte);
    {
    let v901_4: Space = if (&(v900_9)).is_empty() { Space::new() } else {
      let v902_2: Path = concat_path(&(*p1),&v900_17_cursor.path()[v900_17_origin..(v900_17_origin + 1)]);
      let mut v902_3 = Space::new();
      let mut v902_3_write = v902_3.write_zipper();
      let v902_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v902_3_arg_1: &[u8] = &(v902_2);
      let v902_3_arg_2: &[u8] = &(*p2);
      let v902_3_arg_4: &Space = &(&v900_17_cursor).make_map();
      let mut v902_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v902_3_origin = v902_3_cursor.path().len();
      let mut v902_3_more = v902_3_cursor.is_val() || next_value_within(&mut v902_3_cursor,v902_3_origin);
      while v902_3_more {
        {
        let v902_3_depth = v902_3_cursor.path().len();
        let v903_5: Space = routine_111(c, &v902_3_cursor.path()[v902_3_origin..v902_3_depth], &(*v902_3_arg_1), &(*v902_3_arg_2), &((*v902_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v902_3_write,&((v903_5).read_zipper()),&[]);
        }
        v902_3_more = next_value_within(&mut v902_3_cursor,v902_3_origin);
      }
      drop(v902_3_cursor);
      drop(v902_3_write);
      map_map_kernels::compose(&(v900_9),&(v902_3))
    };
    let v901_8: Space = if (&(v900_15)).is_empty() { Space::new() } else {
      let mut v904_5 = Space::new();
      let mut v904_5_write = v904_5.write_zipper();
      for v904_5_byte in v900_17_cursor.child_mask().iter() {
        v900_17_cursor.descend_to_existing_byte(v904_5_byte);
        {
        let v905_2: Space = routine_112(c, &v900_17_cursor.path()[(v900_17_origin + 1)..(v900_17_origin + 2)], &v900_17_cursor.path()[(v900_17_origin + 1)..(v900_17_origin + 2)], &v900_17_cursor);
        join_wrapped_into(&mut v904_5_write,&((v905_2).read_zipper()),&[]);
        }
        v900_17_cursor.ascend(1);
      }
      drop(v904_5_write);
      let v904_6: Space = map_map_kernels::raffine(&(*CONSTANT_17),&(v904_5));
      let v904_7: Space = map_view_kernels::unite(&(v904_6),&v900_17_cursor);
      map_map_kernels::compose(&(v900_15),&(v904_7))
    };
    let v906_2: Path = concat_path(&(*p1),&v900_17_cursor.path()[v900_17_origin..(v900_17_origin + 1)]);
    let v901_9: Path = concat_path(&(*p2),&(v906_2));
    let v901_10: Space = map_kernels::wrap(&(v901_8),&(v901_9));
    drop(v901_9);
    let v901_11: Space = map_map_kernels::unite(&(v901_4),&(v901_10));
    join_wrapped_into(&mut v900_17_write,&((v901_11).read_zipper()),&[]);
    }
    v900_17_cursor.ascend(1);
  }
  drop(v900_17_cursor);
  drop(v900_17_write);
  drop(v900_9);
  drop(v900_15);
  (v900_17).clone()
}

fn routine_112(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v907_5: Space = singleton(&(*p1));
  let v907_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v907_5));
  let v907_7: Space = if map_kernels::has_head(&(v907_6)) { singleton(&[]) } else { Space::new() };
  drop(v907_6);
  let v907_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v907_7));
  drop(v907_7);
  let v907_19: Space = if (&(v907_8)).is_empty() { Space::new() } else {
    let v908_11: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v908_14: Space = if (&(v908_11)).is_empty() { Space::new() } else {
      let v909_13: Space = routine_132(c, &(*CONSTANT_1), &(*p0), &(*s0));
      map_map_kernels::compose(&(v908_11),&(v909_13))
    };
    drop(v908_11);
    let mut v908_17 = Space::new();
    let mut v908_17_write = v908_17.write_zipper();
    let mut v908_17_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v908_17_origin = v908_17_cursor.path().len();
    for v908_17_byte in v908_17_cursor.child_mask().iter() {
      v908_17_cursor.descend_to_existing_byte(v908_17_byte);
      {
      let v910_2_arg_0: &[u8] = &v908_17_cursor.path()[v908_17_origin..(v908_17_origin + 1)];
      let v910_2_arg_1: &[u8] = &(*p0);
      let v910_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v910_2_more = v908_17_cursor.is_val() || next_value_within(&mut v908_17_cursor,(v908_17_origin + 1));
      while v910_2_more {
        {
        let v910_2_depth = v908_17_cursor.path().len();
        let mut v911_4_cursor = (*v910_2_arg_3).read_zipper();
        let v911_4_origin = v911_4_cursor.path().len();
        for v911_4_byte in v911_4_cursor.child_mask().iter() {
          v911_4_cursor.descend_to_existing_byte(v911_4_byte);
          {
          let v912_2: Path = concat_path(&(*v910_2_arg_1),&v911_4_cursor.path()[v911_4_origin..(v911_4_origin + 1)]);
          let v912_3: Space = routine_112(c, &(v912_2), &v908_17_cursor.path()[v908_17_origin..v910_2_depth], &v911_4_cursor);
          drop(v912_2);
          join_wrapped_into(&mut v908_17_write,&((v912_3).read_zipper()),&[]);
          }
          v911_4_cursor.ascend(1);
        }
        drop(v911_4_cursor);
        }
        v910_2_more = next_value_within(&mut v908_17_cursor,(v908_17_origin + 1));
      }
      }
      v908_17_cursor.ascend(1);
    }
    drop(v908_17_cursor);
    drop(v908_17_write);
    let v908_18: Space = map_map_kernels::unite(&(v908_14),&(v908_17));
    map_map_kernels::compose(&(v907_8),&(v908_18))
  };
  drop(v907_8);
  let v907_21: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v907_5));
  drop(v907_5);
  let v907_22: Space = if map_kernels::has_head(&(v907_21)) { singleton(&[]) } else { Space::new() };
  drop(v907_21);
  let v907_24: Space = if (&(v907_22)).is_empty() { Space::new() } else {
    let v913_23: Space = singleton(&(*p0));
    map_map_kernels::compose(&(v907_22),&(v913_23))
  };
  drop(v907_22);
  let v907_25: Space = map_map_kernels::unite(&(v907_19),&(v907_24));
  drop(v907_24);
  (v907_25).clone()
}

fn routine_113(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v914_8: Space = singleton(&(*p0));
  let v914_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v914_8));
  let v914_10: Space = if map_kernels::has_head(&(v914_9)) { singleton(&[]) } else { Space::new() };
  drop(v914_9);
  let v914_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v914_10));
  drop(v914_10);
  let v914_16: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v914_8));
  drop(v914_8);
  let v914_17: Space = if map_kernels::has_head(&(v914_16)) { singleton(&[]) } else { Space::new() };
  drop(v914_16);
  let mut v914_18 = Space::new();
  let mut v914_18_write = v914_18.write_zipper();
  let mut v914_18_cursor = (*s0).read_zipper();
  let v914_18_origin = v914_18_cursor.path().len();
  for v914_18_byte in v914_18_cursor.child_mask().iter() {
    v914_18_cursor.descend_to_existing_byte(v914_18_byte);
    {
    let v915_4: Space = if (&(v914_11)).is_empty() { Space::new() } else {
      let v916_2: Path = concat_path(&(*p1),&v914_18_cursor.path()[v914_18_origin..(v914_18_origin + 1)]);
      let mut v916_3 = Space::new();
      let mut v916_3_write = v916_3.write_zipper();
      let v916_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v916_3_arg_1: &[u8] = &(v916_2);
      let v916_3_arg_2: &[u8] = &(*p2);
      let v916_3_arg_3: &[u8] = &(*p3);
      let v916_3_arg_4: &[u8] = &(*p4);
      let v916_3_arg_6: &Space = &(&v914_18_cursor).make_map();
      let mut v916_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v916_3_origin = v916_3_cursor.path().len();
      let mut v916_3_more = v916_3_cursor.is_val() || next_value_within(&mut v916_3_cursor,v916_3_origin);
      while v916_3_more {
        {
        let v916_3_depth = v916_3_cursor.path().len();
        let v917_7: Space = routine_113(c, &v916_3_cursor.path()[v916_3_origin..v916_3_depth], &(*v916_3_arg_1), &(*v916_3_arg_2), &(*v916_3_arg_3), &(*v916_3_arg_4), &((*v916_3_arg_6).read_zipper()));
        join_wrapped_into(&mut v916_3_write,&((v917_7).read_zipper()),&[]);
        }
        v916_3_more = next_value_within(&mut v916_3_cursor,v916_3_origin);
      }
      drop(v916_3_cursor);
      drop(v916_3_write);
      map_map_kernels::compose(&(v914_11),&(v916_3))
    };
    let v915_6: Space = if (&(v914_17)).is_empty() { Space::new() } else {
      let v918_2: Path = concat_path(&(*p1),&v914_18_cursor.path()[v914_18_origin..(v914_18_origin + 1)]);
      let mut v918_5 = Space::new();
      let mut v918_5_write = v918_5.write_zipper();
      for v918_5_byte in v914_18_cursor.child_mask().iter() {
        v914_18_cursor.descend_to_existing_byte(v918_5_byte);
        {
        let v919_2: Space = routine_114(c, &v914_18_cursor.path()[(v914_18_origin + 1)..(v914_18_origin + 2)], &v914_18_cursor.path()[(v914_18_origin + 1)..(v914_18_origin + 2)], &(*p2), &(*p3), &(*p4), &(v918_2), &v914_18_cursor);
        join_wrapped_into(&mut v918_5_write,&((v919_2).read_zipper()),&[]);
        }
        v914_18_cursor.ascend(1);
      }
      drop(v918_5_write);
      drop(v918_2);
      map_map_kernels::compose(&(v914_17),&(v918_5))
    };
    let v915_7: Space = map_map_kernels::unite(&(v915_4),&(v915_6));
    join_wrapped_into(&mut v914_18_write,&((v915_7).read_zipper()),&[]);
    }
    v914_18_cursor.ascend(1);
  }
  drop(v914_18_cursor);
  drop(v914_18_write);
  drop(v914_11);
  drop(v914_17);
  (v914_18).clone()
}

fn routine_114(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v920_9: Space = singleton(&(*p1));
  let v920_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v920_9));
  let v920_11: Space = if map_kernels::has_head(&(v920_10)) { singleton(&[]) } else { Space::new() };
  drop(v920_10);
  let v920_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v920_11));
  drop(v920_11);
  let v920_23: Space = if (&(v920_12)).is_empty() { Space::new() } else {
    let v921_15: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v921_18: Space = if (&(v921_15)).is_empty() { Space::new() } else {
      let v922_17: Space = routine_133(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*s0));
      map_map_kernels::compose(&(v921_15),&(v922_17))
    };
    drop(v921_15);
    let mut v921_21 = Space::new();
    let mut v921_21_write = v921_21.write_zipper();
    let mut v921_21_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v921_21_origin = v921_21_cursor.path().len();
    for v921_21_byte in v921_21_cursor.child_mask().iter() {
      v921_21_cursor.descend_to_existing_byte(v921_21_byte);
      {
      let v923_2_arg_0: &[u8] = &v921_21_cursor.path()[v921_21_origin..(v921_21_origin + 1)];
      let v923_2_arg_1: &[u8] = &(*p0);
      let v923_2_arg_2: &[u8] = &(*p2);
      let v923_2_arg_3: &[u8] = &(*p3);
      let v923_2_arg_4: &[u8] = &(*p4);
      let v923_2_arg_5: &[u8] = &(*p5);
      let v923_2_arg_7: &Space = &(&(*s0)).make_map();
      let mut v923_2_more = v921_21_cursor.is_val() || next_value_within(&mut v921_21_cursor,(v921_21_origin + 1));
      while v923_2_more {
        {
        let v923_2_depth = v921_21_cursor.path().len();
        let mut v924_8_cursor = (*v923_2_arg_7).read_zipper();
        let v924_8_origin = v924_8_cursor.path().len();
        for v924_8_byte in v924_8_cursor.child_mask().iter() {
          v924_8_cursor.descend_to_existing_byte(v924_8_byte);
          {
          let v925_2: Path = concat_path(&(*v923_2_arg_1),&v924_8_cursor.path()[v924_8_origin..(v924_8_origin + 1)]);
          let v925_3: Space = routine_114(c, &(v925_2), &v921_21_cursor.path()[v921_21_origin..v923_2_depth], &(*v923_2_arg_2), &(*v923_2_arg_3), &(*v923_2_arg_4), &(*v923_2_arg_5), &v924_8_cursor);
          drop(v925_2);
          join_wrapped_into(&mut v921_21_write,&((v925_3).read_zipper()),&[]);
          }
          v924_8_cursor.ascend(1);
        }
        drop(v924_8_cursor);
        }
        v923_2_more = next_value_within(&mut v921_21_cursor,(v921_21_origin + 1));
      }
      }
      v921_21_cursor.ascend(1);
    }
    drop(v921_21_cursor);
    drop(v921_21_write);
    let v921_22: Space = map_map_kernels::unite(&(v921_18),&(v921_21));
    map_map_kernels::compose(&(v920_12),&(v921_22))
  };
  drop(v920_12);
  let v920_25: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v920_9));
  drop(v920_9);
  let v920_26: Space = if map_kernels::has_head(&(v920_25)) { singleton(&[]) } else { Space::new() };
  drop(v920_25);
  let v920_28: Space = if (&(v920_26)).is_empty() { Space::new() } else {
    let mut v926_27 = Space::new();
    let mut v926_27_write = v926_27.write_zipper();
    let mut v926_27_cursor = (*s0).read_zipper();
    let v926_27_origin = v926_27_cursor.path().len();
    for v926_27_byte in v926_27_cursor.child_mask().iter() {
      v926_27_cursor.descend_to_existing_byte(v926_27_byte);
      {
      let v927_2: Space = routine_134(c, &v926_27_cursor.path()[v926_27_origin..(v926_27_origin + 1)], &v926_27_cursor.path()[v926_27_origin..(v926_27_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v926_27_cursor);
      join_wrapped_into(&mut v926_27_write,&((v927_2).read_zipper()),&[]);
      }
      v926_27_cursor.ascend(1);
    }
    drop(v926_27_cursor);
    drop(v926_27_write);
    map_map_kernels::compose(&(v920_26),&(v926_27))
  };
  drop(v920_26);
  let v920_29: Space = map_map_kernels::unite(&(v920_23),&(v920_28));
  (v920_29).clone()
}

fn routine_115(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v928_8: Space = singleton(&(*p0));
  let v928_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v928_8));
  let v928_10: Space = if map_kernels::has_head(&(v928_9)) { singleton(&[]) } else { Space::new() };
  drop(v928_9);
  let v928_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v928_10));
  drop(v928_10);
  let v928_16: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v928_8));
  drop(v928_8);
  let v928_17: Space = if map_kernels::has_head(&(v928_16)) { singleton(&[]) } else { Space::new() };
  drop(v928_16);
  let mut v928_18 = Space::new();
  let mut v928_18_write = v928_18.write_zipper();
  let mut v928_18_cursor = (*s0).read_zipper();
  let v928_18_origin = v928_18_cursor.path().len();
  for v928_18_byte in v928_18_cursor.child_mask().iter() {
    v928_18_cursor.descend_to_existing_byte(v928_18_byte);
    {
    let v929_4: Space = if (&(v928_11)).is_empty() { Space::new() } else {
      let v930_2: Path = concat_path(&(*p1),&v928_18_cursor.path()[v928_18_origin..(v928_18_origin + 1)]);
      let mut v930_3 = Space::new();
      let mut v930_3_write = v930_3.write_zipper();
      let v930_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v930_3_arg_1: &[u8] = &(v930_2);
      let v930_3_arg_2: &[u8] = &(*p2);
      let v930_3_arg_3: &[u8] = &(*p3);
      let v930_3_arg_4: &[u8] = &(*p4);
      let v930_3_arg_6: &Space = &(&v928_18_cursor).make_map();
      let mut v930_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v930_3_origin = v930_3_cursor.path().len();
      let mut v930_3_more = v930_3_cursor.is_val() || next_value_within(&mut v930_3_cursor,v930_3_origin);
      while v930_3_more {
        {
        let v930_3_depth = v930_3_cursor.path().len();
        let v931_7: Space = routine_115(c, &v930_3_cursor.path()[v930_3_origin..v930_3_depth], &(*v930_3_arg_1), &(*v930_3_arg_2), &(*v930_3_arg_3), &(*v930_3_arg_4), &((*v930_3_arg_6).read_zipper()));
        join_wrapped_into(&mut v930_3_write,&((v931_7).read_zipper()),&[]);
        }
        v930_3_more = next_value_within(&mut v930_3_cursor,v930_3_origin);
      }
      drop(v930_3_cursor);
      drop(v930_3_write);
      map_map_kernels::compose(&(v928_11),&(v930_3))
    };
    let v929_6: Space = if (&(v928_17)).is_empty() { Space::new() } else {
      let v932_2: Path = concat_path(&(*p1),&v928_18_cursor.path()[v928_18_origin..(v928_18_origin + 1)]);
      let mut v932_5 = Space::new();
      let mut v932_5_write = v932_5.write_zipper();
      for v932_5_byte in v928_18_cursor.child_mask().iter() {
        v928_18_cursor.descend_to_existing_byte(v932_5_byte);
        {
        let v933_2: Space = routine_116(c, &v928_18_cursor.path()[(v928_18_origin + 1)..(v928_18_origin + 2)], &v928_18_cursor.path()[(v928_18_origin + 1)..(v928_18_origin + 2)], &(*p2), &(*p3), &(*p4), &(v932_2), &v928_18_cursor);
        join_wrapped_into(&mut v932_5_write,&((v933_2).read_zipper()),&[]);
        }
        v928_18_cursor.ascend(1);
      }
      drop(v932_5_write);
      drop(v932_2);
      map_map_kernels::compose(&(v928_17),&(v932_5))
    };
    let v929_7: Space = map_map_kernels::unite(&(v929_4),&(v929_6));
    join_wrapped_into(&mut v928_18_write,&((v929_7).read_zipper()),&[]);
    }
    v928_18_cursor.ascend(1);
  }
  drop(v928_18_cursor);
  drop(v928_18_write);
  drop(v928_11);
  drop(v928_17);
  (v928_18).clone()
}

fn routine_116(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v934_9: Space = singleton(&(*p1));
  let v934_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v934_9));
  let v934_11: Space = if map_kernels::has_head(&(v934_10)) { singleton(&[]) } else { Space::new() };
  drop(v934_10);
  let v934_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v934_11));
  drop(v934_11);
  let v934_23: Space = if (&(v934_12)).is_empty() { Space::new() } else {
    let v935_15: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v935_18: Space = if (&(v935_15)).is_empty() { Space::new() } else {
      let v936_17: Space = routine_135(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*s0));
      map_map_kernels::compose(&(v935_15),&(v936_17))
    };
    drop(v935_15);
    let mut v935_21 = Space::new();
    let mut v935_21_write = v935_21.write_zipper();
    let mut v935_21_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v935_21_origin = v935_21_cursor.path().len();
    for v935_21_byte in v935_21_cursor.child_mask().iter() {
      v935_21_cursor.descend_to_existing_byte(v935_21_byte);
      {
      let v937_2_arg_0: &[u8] = &v935_21_cursor.path()[v935_21_origin..(v935_21_origin + 1)];
      let v937_2_arg_1: &[u8] = &(*p0);
      let v937_2_arg_2: &[u8] = &(*p2);
      let v937_2_arg_3: &[u8] = &(*p3);
      let v937_2_arg_4: &[u8] = &(*p4);
      let v937_2_arg_5: &[u8] = &(*p5);
      let v937_2_arg_7: &Space = &(&(*s0)).make_map();
      let mut v937_2_more = v935_21_cursor.is_val() || next_value_within(&mut v935_21_cursor,(v935_21_origin + 1));
      while v937_2_more {
        {
        let v937_2_depth = v935_21_cursor.path().len();
        let mut v938_8_cursor = (*v937_2_arg_7).read_zipper();
        let v938_8_origin = v938_8_cursor.path().len();
        for v938_8_byte in v938_8_cursor.child_mask().iter() {
          v938_8_cursor.descend_to_existing_byte(v938_8_byte);
          {
          let v939_2: Path = concat_path(&(*v937_2_arg_1),&v938_8_cursor.path()[v938_8_origin..(v938_8_origin + 1)]);
          let v939_3: Space = routine_116(c, &(v939_2), &v935_21_cursor.path()[v935_21_origin..v937_2_depth], &(*v937_2_arg_2), &(*v937_2_arg_3), &(*v937_2_arg_4), &(*v937_2_arg_5), &v938_8_cursor);
          drop(v939_2);
          join_wrapped_into(&mut v935_21_write,&((v939_3).read_zipper()),&[]);
          }
          v938_8_cursor.ascend(1);
        }
        drop(v938_8_cursor);
        }
        v937_2_more = next_value_within(&mut v935_21_cursor,(v935_21_origin + 1));
      }
      }
      v935_21_cursor.ascend(1);
    }
    drop(v935_21_cursor);
    drop(v935_21_write);
    let v935_22: Space = map_map_kernels::unite(&(v935_18),&(v935_21));
    map_map_kernels::compose(&(v934_12),&(v935_22))
  };
  drop(v934_12);
  let v934_25: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v934_9));
  drop(v934_9);
  let v934_26: Space = if map_kernels::has_head(&(v934_25)) { singleton(&[]) } else { Space::new() };
  drop(v934_25);
  let v934_28: Space = if (&(v934_26)).is_empty() { Space::new() } else {
    let mut v940_27 = Space::new();
    let mut v940_27_write = v940_27.write_zipper();
    let mut v940_27_cursor = (*s0).read_zipper();
    let v940_27_origin = v940_27_cursor.path().len();
    for v940_27_byte in v940_27_cursor.child_mask().iter() {
      v940_27_cursor.descend_to_existing_byte(v940_27_byte);
      {
      let v941_2: Space = routine_136(c, &v940_27_cursor.path()[v940_27_origin..(v940_27_origin + 1)], &v940_27_cursor.path()[v940_27_origin..(v940_27_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v940_27_cursor);
      join_wrapped_into(&mut v940_27_write,&((v941_2).read_zipper()),&[]);
      }
      v940_27_cursor.ascend(1);
    }
    drop(v940_27_cursor);
    drop(v940_27_write);
    map_map_kernels::compose(&(v934_26),&(v940_27))
  };
  drop(v934_26);
  let v934_29: Space = map_map_kernels::unite(&(v934_23),&(v934_28));
  (v934_29).clone()
}

fn routine_117(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v942_8: Space = singleton(&(*p0));
  let v942_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v942_8));
  let v942_10: Space = if map_kernels::has_head(&(v942_9)) { singleton(&[]) } else { Space::new() };
  drop(v942_9);
  let v942_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v942_10));
  drop(v942_10);
  let v942_16: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v942_8));
  drop(v942_8);
  let v942_17: Space = if map_kernels::has_head(&(v942_16)) { singleton(&[]) } else { Space::new() };
  drop(v942_16);
  let mut v942_18 = Space::new();
  let mut v942_18_write = v942_18.write_zipper();
  let mut v942_18_cursor = (*s0).read_zipper();
  let v942_18_origin = v942_18_cursor.path().len();
  for v942_18_byte in v942_18_cursor.child_mask().iter() {
    v942_18_cursor.descend_to_existing_byte(v942_18_byte);
    {
    let v943_4: Space = if (&(v942_11)).is_empty() { Space::new() } else {
      let v944_2: Path = concat_path(&(*p1),&v942_18_cursor.path()[v942_18_origin..(v942_18_origin + 1)]);
      let mut v944_3 = Space::new();
      let mut v944_3_write = v944_3.write_zipper();
      let v944_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v944_3_arg_1: &[u8] = &(v944_2);
      let v944_3_arg_2: &[u8] = &(*p2);
      let v944_3_arg_3: &[u8] = &(*p3);
      let v944_3_arg_4: &[u8] = &(*p4);
      let v944_3_arg_6: &Space = &(&v942_18_cursor).make_map();
      let mut v944_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v944_3_origin = v944_3_cursor.path().len();
      let mut v944_3_more = v944_3_cursor.is_val() || next_value_within(&mut v944_3_cursor,v944_3_origin);
      while v944_3_more {
        {
        let v944_3_depth = v944_3_cursor.path().len();
        let v945_7: Space = routine_117(c, &v944_3_cursor.path()[v944_3_origin..v944_3_depth], &(*v944_3_arg_1), &(*v944_3_arg_2), &(*v944_3_arg_3), &(*v944_3_arg_4), &((*v944_3_arg_6).read_zipper()));
        join_wrapped_into(&mut v944_3_write,&((v945_7).read_zipper()),&[]);
        }
        v944_3_more = next_value_within(&mut v944_3_cursor,v944_3_origin);
      }
      drop(v944_3_cursor);
      drop(v944_3_write);
      map_map_kernels::compose(&(v942_11),&(v944_3))
    };
    let v943_6: Space = if (&(v942_17)).is_empty() { Space::new() } else {
      let v946_2: Path = concat_path(&(*p1),&v942_18_cursor.path()[v942_18_origin..(v942_18_origin + 1)]);
      let mut v946_5 = Space::new();
      let mut v946_5_write = v946_5.write_zipper();
      for v946_5_byte in v942_18_cursor.child_mask().iter() {
        v942_18_cursor.descend_to_existing_byte(v946_5_byte);
        {
        let v947_2: Space = routine_118(c, &v942_18_cursor.path()[(v942_18_origin + 1)..(v942_18_origin + 2)], &v942_18_cursor.path()[(v942_18_origin + 1)..(v942_18_origin + 2)], &(*p2), &(*p3), &(*p4), &(v946_2), &v942_18_cursor);
        join_wrapped_into(&mut v946_5_write,&((v947_2).read_zipper()),&[]);
        }
        v942_18_cursor.ascend(1);
      }
      drop(v946_5_write);
      drop(v946_2);
      map_map_kernels::compose(&(v942_17),&(v946_5))
    };
    let v943_7: Space = map_map_kernels::unite(&(v943_4),&(v943_6));
    join_wrapped_into(&mut v942_18_write,&((v943_7).read_zipper()),&[]);
    }
    v942_18_cursor.ascend(1);
  }
  drop(v942_18_cursor);
  drop(v942_18_write);
  drop(v942_11);
  drop(v942_17);
  (v942_18).clone()
}

fn routine_118(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v948_9: Space = singleton(&(*p1));
  let v948_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v948_9));
  let v948_11: Space = if map_kernels::has_head(&(v948_10)) { singleton(&[]) } else { Space::new() };
  drop(v948_10);
  let v948_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v948_11));
  drop(v948_11);
  let v948_23: Space = if (&(v948_12)).is_empty() { Space::new() } else {
    let v949_15: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v949_18: Space = if (&(v949_15)).is_empty() { Space::new() } else {
      let v950_17: Space = routine_137(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*s0));
      map_map_kernels::compose(&(v949_15),&(v950_17))
    };
    drop(v949_15);
    let mut v949_21 = Space::new();
    let mut v949_21_write = v949_21.write_zipper();
    let mut v949_21_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v949_21_origin = v949_21_cursor.path().len();
    for v949_21_byte in v949_21_cursor.child_mask().iter() {
      v949_21_cursor.descend_to_existing_byte(v949_21_byte);
      {
      let v951_2_arg_0: &[u8] = &v949_21_cursor.path()[v949_21_origin..(v949_21_origin + 1)];
      let v951_2_arg_1: &[u8] = &(*p0);
      let v951_2_arg_2: &[u8] = &(*p2);
      let v951_2_arg_3: &[u8] = &(*p3);
      let v951_2_arg_4: &[u8] = &(*p4);
      let v951_2_arg_5: &[u8] = &(*p5);
      let v951_2_arg_7: &Space = &(&(*s0)).make_map();
      let mut v951_2_more = v949_21_cursor.is_val() || next_value_within(&mut v949_21_cursor,(v949_21_origin + 1));
      while v951_2_more {
        {
        let v951_2_depth = v949_21_cursor.path().len();
        let mut v952_8_cursor = (*v951_2_arg_7).read_zipper();
        let v952_8_origin = v952_8_cursor.path().len();
        for v952_8_byte in v952_8_cursor.child_mask().iter() {
          v952_8_cursor.descend_to_existing_byte(v952_8_byte);
          {
          let v953_2: Path = concat_path(&(*v951_2_arg_1),&v952_8_cursor.path()[v952_8_origin..(v952_8_origin + 1)]);
          let v953_3: Space = routine_118(c, &(v953_2), &v949_21_cursor.path()[v949_21_origin..v951_2_depth], &(*v951_2_arg_2), &(*v951_2_arg_3), &(*v951_2_arg_4), &(*v951_2_arg_5), &v952_8_cursor);
          drop(v953_2);
          join_wrapped_into(&mut v949_21_write,&((v953_3).read_zipper()),&[]);
          }
          v952_8_cursor.ascend(1);
        }
        drop(v952_8_cursor);
        }
        v951_2_more = next_value_within(&mut v949_21_cursor,(v949_21_origin + 1));
      }
      }
      v949_21_cursor.ascend(1);
    }
    drop(v949_21_cursor);
    drop(v949_21_write);
    let v949_22: Space = map_map_kernels::unite(&(v949_18),&(v949_21));
    map_map_kernels::compose(&(v948_12),&(v949_22))
  };
  drop(v948_12);
  let v948_25: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v948_9));
  drop(v948_9);
  let v948_26: Space = if map_kernels::has_head(&(v948_25)) { singleton(&[]) } else { Space::new() };
  drop(v948_25);
  let v948_28: Space = if (&(v948_26)).is_empty() { Space::new() } else {
    let mut v954_27 = Space::new();
    let mut v954_27_write = v954_27.write_zipper();
    let mut v954_27_cursor = (*s0).read_zipper();
    let v954_27_origin = v954_27_cursor.path().len();
    for v954_27_byte in v954_27_cursor.child_mask().iter() {
      v954_27_cursor.descend_to_existing_byte(v954_27_byte);
      {
      let v955_2: Space = routine_138(c, &v954_27_cursor.path()[v954_27_origin..(v954_27_origin + 1)], &v954_27_cursor.path()[v954_27_origin..(v954_27_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v954_27_cursor);
      join_wrapped_into(&mut v954_27_write,&((v955_2).read_zipper()),&[]);
      }
      v954_27_cursor.ascend(1);
    }
    drop(v954_27_cursor);
    drop(v954_27_write);
    map_map_kernels::compose(&(v948_26),&(v954_27))
  };
  drop(v948_26);
  let v948_29: Space = map_map_kernels::unite(&(v948_23),&(v948_28));
  (v948_29).clone()
}

fn routine_119(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v956_8: Space = singleton(&(*p0));
  let v956_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v956_8));
  let v956_10: Space = if map_kernels::has_head(&(v956_9)) { singleton(&[]) } else { Space::new() };
  drop(v956_9);
  let v956_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v956_10));
  drop(v956_10);
  let v956_16: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v956_8));
  drop(v956_8);
  let v956_17: Space = if map_kernels::has_head(&(v956_16)) { singleton(&[]) } else { Space::new() };
  drop(v956_16);
  let mut v956_18 = Space::new();
  let mut v956_18_write = v956_18.write_zipper();
  let mut v956_18_cursor = (*s0).read_zipper();
  let v956_18_origin = v956_18_cursor.path().len();
  for v956_18_byte in v956_18_cursor.child_mask().iter() {
    v956_18_cursor.descend_to_existing_byte(v956_18_byte);
    {
    let v957_4: Space = if (&(v956_11)).is_empty() { Space::new() } else {
      let v958_2: Path = concat_path(&(*p1),&v956_18_cursor.path()[v956_18_origin..(v956_18_origin + 1)]);
      let mut v958_3 = Space::new();
      let mut v958_3_write = v958_3.write_zipper();
      let v958_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v958_3_arg_1: &[u8] = &(v958_2);
      let v958_3_arg_2: &[u8] = &(*p2);
      let v958_3_arg_3: &[u8] = &(*p3);
      let v958_3_arg_4: &[u8] = &(*p4);
      let v958_3_arg_6: &Space = &(&v956_18_cursor).make_map();
      let mut v958_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v958_3_origin = v958_3_cursor.path().len();
      let mut v958_3_more = v958_3_cursor.is_val() || next_value_within(&mut v958_3_cursor,v958_3_origin);
      while v958_3_more {
        {
        let v958_3_depth = v958_3_cursor.path().len();
        let v959_7: Space = routine_119(c, &v958_3_cursor.path()[v958_3_origin..v958_3_depth], &(*v958_3_arg_1), &(*v958_3_arg_2), &(*v958_3_arg_3), &(*v958_3_arg_4), &((*v958_3_arg_6).read_zipper()));
        join_wrapped_into(&mut v958_3_write,&((v959_7).read_zipper()),&[]);
        }
        v958_3_more = next_value_within(&mut v958_3_cursor,v958_3_origin);
      }
      drop(v958_3_cursor);
      drop(v958_3_write);
      map_map_kernels::compose(&(v956_11),&(v958_3))
    };
    let v957_6: Space = if (&(v956_17)).is_empty() { Space::new() } else {
      let v960_2: Path = concat_path(&(*p1),&v956_18_cursor.path()[v956_18_origin..(v956_18_origin + 1)]);
      let mut v960_5 = Space::new();
      let mut v960_5_write = v960_5.write_zipper();
      for v960_5_byte in v956_18_cursor.child_mask().iter() {
        v956_18_cursor.descend_to_existing_byte(v960_5_byte);
        {
        let v961_2: Space = routine_120(c, &v956_18_cursor.path()[(v956_18_origin + 1)..(v956_18_origin + 2)], &v956_18_cursor.path()[(v956_18_origin + 1)..(v956_18_origin + 2)], &(*p2), &(*p3), &(*p4), &(v960_2), &v956_18_cursor);
        join_wrapped_into(&mut v960_5_write,&((v961_2).read_zipper()),&[]);
        }
        v956_18_cursor.ascend(1);
      }
      drop(v960_5_write);
      drop(v960_2);
      map_map_kernels::compose(&(v956_17),&(v960_5))
    };
    let v957_7: Space = map_map_kernels::unite(&(v957_4),&(v957_6));
    join_wrapped_into(&mut v956_18_write,&((v957_7).read_zipper()),&[]);
    }
    v956_18_cursor.ascend(1);
  }
  drop(v956_18_cursor);
  drop(v956_18_write);
  drop(v956_11);
  drop(v956_17);
  (v956_18).clone()
}

fn routine_120(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v962_9: Space = singleton(&(*p1));
  let v962_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v962_9));
  let v962_11: Space = if map_kernels::has_head(&(v962_10)) { singleton(&[]) } else { Space::new() };
  drop(v962_10);
  let v962_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v962_11));
  drop(v962_11);
  let v962_23: Space = if (&(v962_12)).is_empty() { Space::new() } else {
    let v963_15: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v963_18: Space = if (&(v963_15)).is_empty() { Space::new() } else {
      let v964_17: Space = routine_139(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*s0));
      map_map_kernels::compose(&(v963_15),&(v964_17))
    };
    drop(v963_15);
    let mut v963_21 = Space::new();
    let mut v963_21_write = v963_21.write_zipper();
    let mut v963_21_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v963_21_origin = v963_21_cursor.path().len();
    for v963_21_byte in v963_21_cursor.child_mask().iter() {
      v963_21_cursor.descend_to_existing_byte(v963_21_byte);
      {
      let v965_2_arg_0: &[u8] = &v963_21_cursor.path()[v963_21_origin..(v963_21_origin + 1)];
      let v965_2_arg_1: &[u8] = &(*p0);
      let v965_2_arg_2: &[u8] = &(*p2);
      let v965_2_arg_3: &[u8] = &(*p3);
      let v965_2_arg_4: &[u8] = &(*p4);
      let v965_2_arg_5: &[u8] = &(*p5);
      let v965_2_arg_7: &Space = &(&(*s0)).make_map();
      let mut v965_2_more = v963_21_cursor.is_val() || next_value_within(&mut v963_21_cursor,(v963_21_origin + 1));
      while v965_2_more {
        {
        let v965_2_depth = v963_21_cursor.path().len();
        let mut v966_8_cursor = (*v965_2_arg_7).read_zipper();
        let v966_8_origin = v966_8_cursor.path().len();
        for v966_8_byte in v966_8_cursor.child_mask().iter() {
          v966_8_cursor.descend_to_existing_byte(v966_8_byte);
          {
          let v967_2: Path = concat_path(&(*v965_2_arg_1),&v966_8_cursor.path()[v966_8_origin..(v966_8_origin + 1)]);
          let v967_3: Space = routine_120(c, &(v967_2), &v963_21_cursor.path()[v963_21_origin..v965_2_depth], &(*v965_2_arg_2), &(*v965_2_arg_3), &(*v965_2_arg_4), &(*v965_2_arg_5), &v966_8_cursor);
          drop(v967_2);
          join_wrapped_into(&mut v963_21_write,&((v967_3).read_zipper()),&[]);
          }
          v966_8_cursor.ascend(1);
        }
        drop(v966_8_cursor);
        }
        v965_2_more = next_value_within(&mut v963_21_cursor,(v963_21_origin + 1));
      }
      }
      v963_21_cursor.ascend(1);
    }
    drop(v963_21_cursor);
    drop(v963_21_write);
    let v963_22: Space = map_map_kernels::unite(&(v963_18),&(v963_21));
    map_map_kernels::compose(&(v962_12),&(v963_22))
  };
  drop(v962_12);
  let v962_25: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v962_9));
  drop(v962_9);
  let v962_26: Space = if map_kernels::has_head(&(v962_25)) { singleton(&[]) } else { Space::new() };
  drop(v962_25);
  let v962_28: Space = if (&(v962_26)).is_empty() { Space::new() } else {
    let mut v968_27 = Space::new();
    let mut v968_27_write = v968_27.write_zipper();
    let mut v968_27_cursor = (*s0).read_zipper();
    let v968_27_origin = v968_27_cursor.path().len();
    for v968_27_byte in v968_27_cursor.child_mask().iter() {
      v968_27_cursor.descend_to_existing_byte(v968_27_byte);
      {
      let v969_2: Space = routine_140(c, &v968_27_cursor.path()[v968_27_origin..(v968_27_origin + 1)], &v968_27_cursor.path()[v968_27_origin..(v968_27_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v968_27_cursor);
      join_wrapped_into(&mut v968_27_write,&((v969_2).read_zipper()),&[]);
      }
      v968_27_cursor.ascend(1);
    }
    drop(v968_27_cursor);
    drop(v968_27_write);
    map_map_kernels::compose(&(v962_26),&(v968_27))
  };
  drop(v962_26);
  let v962_29: Space = map_map_kernels::unite(&(v962_23),&(v962_28));
  (v962_29).clone()
}

fn routine_121(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v970_8: Space = singleton(&(*p0));
  let v970_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v970_8));
  let v970_10: Space = if map_kernels::has_head(&(v970_9)) { singleton(&[]) } else { Space::new() };
  drop(v970_9);
  let v970_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v970_10));
  drop(v970_10);
  let v970_16: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v970_8));
  drop(v970_8);
  let v970_17: Space = if map_kernels::has_head(&(v970_16)) { singleton(&[]) } else { Space::new() };
  drop(v970_16);
  let mut v970_18 = Space::new();
  let mut v970_18_write = v970_18.write_zipper();
  let mut v970_18_cursor = (*s0).read_zipper();
  let v970_18_origin = v970_18_cursor.path().len();
  for v970_18_byte in v970_18_cursor.child_mask().iter() {
    v970_18_cursor.descend_to_existing_byte(v970_18_byte);
    {
    let v971_4: Space = if (&(v970_11)).is_empty() { Space::new() } else {
      let v972_2: Path = concat_path(&(*p1),&v970_18_cursor.path()[v970_18_origin..(v970_18_origin + 1)]);
      let mut v972_3 = Space::new();
      let mut v972_3_write = v972_3.write_zipper();
      let v972_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v972_3_arg_1: &[u8] = &(v972_2);
      let v972_3_arg_2: &[u8] = &(*p2);
      let v972_3_arg_3: &[u8] = &(*p3);
      let v972_3_arg_4: &[u8] = &(*p4);
      let v972_3_arg_6: &Space = &(&v970_18_cursor).make_map();
      let mut v972_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v972_3_origin = v972_3_cursor.path().len();
      let mut v972_3_more = v972_3_cursor.is_val() || next_value_within(&mut v972_3_cursor,v972_3_origin);
      while v972_3_more {
        {
        let v972_3_depth = v972_3_cursor.path().len();
        let v973_7: Space = routine_121(c, &v972_3_cursor.path()[v972_3_origin..v972_3_depth], &(*v972_3_arg_1), &(*v972_3_arg_2), &(*v972_3_arg_3), &(*v972_3_arg_4), &((*v972_3_arg_6).read_zipper()));
        join_wrapped_into(&mut v972_3_write,&((v973_7).read_zipper()),&[]);
        }
        v972_3_more = next_value_within(&mut v972_3_cursor,v972_3_origin);
      }
      drop(v972_3_cursor);
      drop(v972_3_write);
      map_map_kernels::compose(&(v970_11),&(v972_3))
    };
    let v971_6: Space = if (&(v970_17)).is_empty() { Space::new() } else {
      let v974_2: Path = concat_path(&(*p1),&v970_18_cursor.path()[v970_18_origin..(v970_18_origin + 1)]);
      let mut v974_5 = Space::new();
      let mut v974_5_write = v974_5.write_zipper();
      for v974_5_byte in v970_18_cursor.child_mask().iter() {
        v970_18_cursor.descend_to_existing_byte(v974_5_byte);
        {
        let v975_2: Space = routine_122(c, &v970_18_cursor.path()[(v970_18_origin + 1)..(v970_18_origin + 2)], &v970_18_cursor.path()[(v970_18_origin + 1)..(v970_18_origin + 2)], &(*p2), &(*p3), &(*p4), &(v974_2), &v970_18_cursor);
        join_wrapped_into(&mut v974_5_write,&((v975_2).read_zipper()),&[]);
        }
        v970_18_cursor.ascend(1);
      }
      drop(v974_5_write);
      drop(v974_2);
      map_map_kernels::compose(&(v970_17),&(v974_5))
    };
    let v971_7: Space = map_map_kernels::unite(&(v971_4),&(v971_6));
    join_wrapped_into(&mut v970_18_write,&((v971_7).read_zipper()),&[]);
    }
    v970_18_cursor.ascend(1);
  }
  drop(v970_18_cursor);
  drop(v970_18_write);
  drop(v970_11);
  drop(v970_17);
  (v970_18).clone()
}

fn routine_122(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v976_9: Space = singleton(&(*p1));
  let v976_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v976_9));
  let v976_11: Space = if map_kernels::has_head(&(v976_10)) { singleton(&[]) } else { Space::new() };
  drop(v976_10);
  let v976_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v976_11));
  drop(v976_11);
  let v976_23: Space = if (&(v976_12)).is_empty() { Space::new() } else {
    let v977_15: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v977_18: Space = if (&(v977_15)).is_empty() { Space::new() } else {
      let v978_17: Space = routine_141(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*s0));
      map_map_kernels::compose(&(v977_15),&(v978_17))
    };
    drop(v977_15);
    let mut v977_21 = Space::new();
    let mut v977_21_write = v977_21.write_zipper();
    let mut v977_21_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v977_21_origin = v977_21_cursor.path().len();
    for v977_21_byte in v977_21_cursor.child_mask().iter() {
      v977_21_cursor.descend_to_existing_byte(v977_21_byte);
      {
      let v979_2_arg_0: &[u8] = &v977_21_cursor.path()[v977_21_origin..(v977_21_origin + 1)];
      let v979_2_arg_1: &[u8] = &(*p0);
      let v979_2_arg_2: &[u8] = &(*p2);
      let v979_2_arg_3: &[u8] = &(*p3);
      let v979_2_arg_4: &[u8] = &(*p4);
      let v979_2_arg_5: &[u8] = &(*p5);
      let v979_2_arg_7: &Space = &(&(*s0)).make_map();
      let mut v979_2_more = v977_21_cursor.is_val() || next_value_within(&mut v977_21_cursor,(v977_21_origin + 1));
      while v979_2_more {
        {
        let v979_2_depth = v977_21_cursor.path().len();
        let mut v980_8_cursor = (*v979_2_arg_7).read_zipper();
        let v980_8_origin = v980_8_cursor.path().len();
        for v980_8_byte in v980_8_cursor.child_mask().iter() {
          v980_8_cursor.descend_to_existing_byte(v980_8_byte);
          {
          let v981_2: Path = concat_path(&(*v979_2_arg_1),&v980_8_cursor.path()[v980_8_origin..(v980_8_origin + 1)]);
          let v981_3: Space = routine_122(c, &(v981_2), &v977_21_cursor.path()[v977_21_origin..v979_2_depth], &(*v979_2_arg_2), &(*v979_2_arg_3), &(*v979_2_arg_4), &(*v979_2_arg_5), &v980_8_cursor);
          drop(v981_2);
          join_wrapped_into(&mut v977_21_write,&((v981_3).read_zipper()),&[]);
          }
          v980_8_cursor.ascend(1);
        }
        drop(v980_8_cursor);
        }
        v979_2_more = next_value_within(&mut v977_21_cursor,(v977_21_origin + 1));
      }
      }
      v977_21_cursor.ascend(1);
    }
    drop(v977_21_cursor);
    drop(v977_21_write);
    let v977_22: Space = map_map_kernels::unite(&(v977_18),&(v977_21));
    map_map_kernels::compose(&(v976_12),&(v977_22))
  };
  drop(v976_12);
  let v976_25: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v976_9));
  drop(v976_9);
  let v976_26: Space = if map_kernels::has_head(&(v976_25)) { singleton(&[]) } else { Space::new() };
  drop(v976_25);
  let v976_28: Space = if (&(v976_26)).is_empty() { Space::new() } else {
    let mut v982_27 = Space::new();
    let mut v982_27_write = v982_27.write_zipper();
    let mut v982_27_cursor = (*s0).read_zipper();
    let v982_27_origin = v982_27_cursor.path().len();
    for v982_27_byte in v982_27_cursor.child_mask().iter() {
      v982_27_cursor.descend_to_existing_byte(v982_27_byte);
      {
      let v983_2: Space = routine_142(c, &v982_27_cursor.path()[v982_27_origin..(v982_27_origin + 1)], &v982_27_cursor.path()[v982_27_origin..(v982_27_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v982_27_cursor);
      join_wrapped_into(&mut v982_27_write,&((v983_2).read_zipper()),&[]);
      }
      v982_27_cursor.ascend(1);
    }
    drop(v982_27_cursor);
    drop(v982_27_write);
    map_map_kernels::compose(&(v976_26),&(v982_27))
  };
  drop(v976_26);
  let v976_29: Space = map_map_kernels::unite(&(v976_23),&(v976_28));
  (v976_29).clone()
}

fn routine_123(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v984_8: Space = singleton(&(*p0));
  let v984_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v984_8));
  let v984_10: Space = if map_kernels::has_head(&(v984_9)) { singleton(&[]) } else { Space::new() };
  drop(v984_9);
  let v984_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v984_10));
  drop(v984_10);
  let v984_16: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v984_8));
  drop(v984_8);
  let v984_17: Space = if map_kernels::has_head(&(v984_16)) { singleton(&[]) } else { Space::new() };
  drop(v984_16);
  let mut v984_18 = Space::new();
  let mut v984_18_write = v984_18.write_zipper();
  let mut v984_18_cursor = (*s0).read_zipper();
  let v984_18_origin = v984_18_cursor.path().len();
  for v984_18_byte in v984_18_cursor.child_mask().iter() {
    v984_18_cursor.descend_to_existing_byte(v984_18_byte);
    {
    let v985_4: Space = if (&(v984_11)).is_empty() { Space::new() } else {
      let v986_2: Path = concat_path(&(*p1),&v984_18_cursor.path()[v984_18_origin..(v984_18_origin + 1)]);
      let mut v986_3 = Space::new();
      let mut v986_3_write = v986_3.write_zipper();
      let v986_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v986_3_arg_1: &[u8] = &(v986_2);
      let v986_3_arg_2: &[u8] = &(*p2);
      let v986_3_arg_3: &[u8] = &(*p3);
      let v986_3_arg_4: &[u8] = &(*p4);
      let v986_3_arg_6: &Space = &(&v984_18_cursor).make_map();
      let mut v986_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v986_3_origin = v986_3_cursor.path().len();
      let mut v986_3_more = v986_3_cursor.is_val() || next_value_within(&mut v986_3_cursor,v986_3_origin);
      while v986_3_more {
        {
        let v986_3_depth = v986_3_cursor.path().len();
        let v987_7: Space = routine_123(c, &v986_3_cursor.path()[v986_3_origin..v986_3_depth], &(*v986_3_arg_1), &(*v986_3_arg_2), &(*v986_3_arg_3), &(*v986_3_arg_4), &((*v986_3_arg_6).read_zipper()));
        join_wrapped_into(&mut v986_3_write,&((v987_7).read_zipper()),&[]);
        }
        v986_3_more = next_value_within(&mut v986_3_cursor,v986_3_origin);
      }
      drop(v986_3_cursor);
      drop(v986_3_write);
      map_map_kernels::compose(&(v984_11),&(v986_3))
    };
    let v985_6: Space = if (&(v984_17)).is_empty() { Space::new() } else {
      let v988_2: Path = concat_path(&(*p1),&v984_18_cursor.path()[v984_18_origin..(v984_18_origin + 1)]);
      let mut v988_5 = Space::new();
      let mut v988_5_write = v988_5.write_zipper();
      for v988_5_byte in v984_18_cursor.child_mask().iter() {
        v984_18_cursor.descend_to_existing_byte(v988_5_byte);
        {
        let v989_2: Space = routine_124(c, &v984_18_cursor.path()[(v984_18_origin + 1)..(v984_18_origin + 2)], &v984_18_cursor.path()[(v984_18_origin + 1)..(v984_18_origin + 2)], &(*p2), &(*p3), &(*p4), &(v988_2), &v984_18_cursor);
        join_wrapped_into(&mut v988_5_write,&((v989_2).read_zipper()),&[]);
        }
        v984_18_cursor.ascend(1);
      }
      drop(v988_5_write);
      drop(v988_2);
      map_map_kernels::compose(&(v984_17),&(v988_5))
    };
    let v985_7: Space = map_map_kernels::unite(&(v985_4),&(v985_6));
    join_wrapped_into(&mut v984_18_write,&((v985_7).read_zipper()),&[]);
    }
    v984_18_cursor.ascend(1);
  }
  drop(v984_18_cursor);
  drop(v984_18_write);
  drop(v984_11);
  drop(v984_17);
  (v984_18).clone()
}

fn routine_124(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v990_9: Space = singleton(&(*p1));
  let v990_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v990_9));
  let v990_11: Space = if map_kernels::has_head(&(v990_10)) { singleton(&[]) } else { Space::new() };
  drop(v990_10);
  let v990_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v990_11));
  drop(v990_11);
  let v990_23: Space = if (&(v990_12)).is_empty() { Space::new() } else {
    let v991_15: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v991_18: Space = if (&(v991_15)).is_empty() { Space::new() } else {
      let v992_17: Space = routine_143(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*s0));
      map_map_kernels::compose(&(v991_15),&(v992_17))
    };
    drop(v991_15);
    let mut v991_21 = Space::new();
    let mut v991_21_write = v991_21.write_zipper();
    let mut v991_21_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v991_21_origin = v991_21_cursor.path().len();
    for v991_21_byte in v991_21_cursor.child_mask().iter() {
      v991_21_cursor.descend_to_existing_byte(v991_21_byte);
      {
      let v993_2_arg_0: &[u8] = &v991_21_cursor.path()[v991_21_origin..(v991_21_origin + 1)];
      let v993_2_arg_1: &[u8] = &(*p0);
      let v993_2_arg_2: &[u8] = &(*p2);
      let v993_2_arg_3: &[u8] = &(*p3);
      let v993_2_arg_4: &[u8] = &(*p4);
      let v993_2_arg_5: &[u8] = &(*p5);
      let v993_2_arg_7: &Space = &(&(*s0)).make_map();
      let mut v993_2_more = v991_21_cursor.is_val() || next_value_within(&mut v991_21_cursor,(v991_21_origin + 1));
      while v993_2_more {
        {
        let v993_2_depth = v991_21_cursor.path().len();
        let mut v994_8_cursor = (*v993_2_arg_7).read_zipper();
        let v994_8_origin = v994_8_cursor.path().len();
        for v994_8_byte in v994_8_cursor.child_mask().iter() {
          v994_8_cursor.descend_to_existing_byte(v994_8_byte);
          {
          let v995_2: Path = concat_path(&(*v993_2_arg_1),&v994_8_cursor.path()[v994_8_origin..(v994_8_origin + 1)]);
          let v995_3: Space = routine_124(c, &(v995_2), &v991_21_cursor.path()[v991_21_origin..v993_2_depth], &(*v993_2_arg_2), &(*v993_2_arg_3), &(*v993_2_arg_4), &(*v993_2_arg_5), &v994_8_cursor);
          drop(v995_2);
          join_wrapped_into(&mut v991_21_write,&((v995_3).read_zipper()),&[]);
          }
          v994_8_cursor.ascend(1);
        }
        drop(v994_8_cursor);
        }
        v993_2_more = next_value_within(&mut v991_21_cursor,(v991_21_origin + 1));
      }
      }
      v991_21_cursor.ascend(1);
    }
    drop(v991_21_cursor);
    drop(v991_21_write);
    let v991_22: Space = map_map_kernels::unite(&(v991_18),&(v991_21));
    map_map_kernels::compose(&(v990_12),&(v991_22))
  };
  drop(v990_12);
  let v990_25: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v990_9));
  drop(v990_9);
  let v990_26: Space = if map_kernels::has_head(&(v990_25)) { singleton(&[]) } else { Space::new() };
  drop(v990_25);
  let v990_28: Space = if (&(v990_26)).is_empty() { Space::new() } else {
    let mut v996_27 = Space::new();
    let mut v996_27_write = v996_27.write_zipper();
    let mut v996_27_cursor = (*s0).read_zipper();
    let v996_27_origin = v996_27_cursor.path().len();
    for v996_27_byte in v996_27_cursor.child_mask().iter() {
      v996_27_cursor.descend_to_existing_byte(v996_27_byte);
      {
      let v997_2: Space = routine_144(c, &v996_27_cursor.path()[v996_27_origin..(v996_27_origin + 1)], &v996_27_cursor.path()[v996_27_origin..(v996_27_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v996_27_cursor);
      join_wrapped_into(&mut v996_27_write,&((v997_2).read_zipper()),&[]);
      }
      v996_27_cursor.ascend(1);
    }
    drop(v996_27_cursor);
    drop(v996_27_write);
    map_map_kernels::compose(&(v990_26),&(v996_27))
  };
  drop(v990_26);
  let v990_29: Space = map_map_kernels::unite(&(v990_23),&(v990_28));
  (v990_29).clone()
}

fn routine_125(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v998_8: Space = singleton(&(*p0));
  let v998_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v998_8));
  let v998_10: Space = if map_kernels::has_head(&(v998_9)) { singleton(&[]) } else { Space::new() };
  drop(v998_9);
  let v998_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v998_10));
  drop(v998_10);
  let v998_16: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v998_8));
  drop(v998_8);
  let v998_17: Space = if map_kernels::has_head(&(v998_16)) { singleton(&[]) } else { Space::new() };
  drop(v998_16);
  let mut v998_18 = Space::new();
  let mut v998_18_write = v998_18.write_zipper();
  let mut v998_18_cursor = (*s0).read_zipper();
  let v998_18_origin = v998_18_cursor.path().len();
  for v998_18_byte in v998_18_cursor.child_mask().iter() {
    v998_18_cursor.descend_to_existing_byte(v998_18_byte);
    {
    let v999_4: Space = if (&(v998_11)).is_empty() { Space::new() } else {
      let v1000_2: Path = concat_path(&(*p1),&v998_18_cursor.path()[v998_18_origin..(v998_18_origin + 1)]);
      let mut v1000_3 = Space::new();
      let mut v1000_3_write = v1000_3.write_zipper();
      let v1000_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1000_3_arg_1: &[u8] = &(v1000_2);
      let v1000_3_arg_2: &[u8] = &(*p2);
      let v1000_3_arg_3: &[u8] = &(*p3);
      let v1000_3_arg_4: &[u8] = &(*p4);
      let v1000_3_arg_6: &Space = &(&v998_18_cursor).make_map();
      let mut v1000_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1000_3_origin = v1000_3_cursor.path().len();
      let mut v1000_3_more = v1000_3_cursor.is_val() || next_value_within(&mut v1000_3_cursor,v1000_3_origin);
      while v1000_3_more {
        {
        let v1000_3_depth = v1000_3_cursor.path().len();
        let v1001_7: Space = routine_125(c, &v1000_3_cursor.path()[v1000_3_origin..v1000_3_depth], &(*v1000_3_arg_1), &(*v1000_3_arg_2), &(*v1000_3_arg_3), &(*v1000_3_arg_4), &((*v1000_3_arg_6).read_zipper()));
        join_wrapped_into(&mut v1000_3_write,&((v1001_7).read_zipper()),&[]);
        }
        v1000_3_more = next_value_within(&mut v1000_3_cursor,v1000_3_origin);
      }
      drop(v1000_3_cursor);
      drop(v1000_3_write);
      map_map_kernels::compose(&(v998_11),&(v1000_3))
    };
    let v999_6: Space = if (&(v998_17)).is_empty() { Space::new() } else {
      let v1002_2: Path = concat_path(&(*p1),&v998_18_cursor.path()[v998_18_origin..(v998_18_origin + 1)]);
      let mut v1002_5 = Space::new();
      let mut v1002_5_write = v1002_5.write_zipper();
      for v1002_5_byte in v998_18_cursor.child_mask().iter() {
        v998_18_cursor.descend_to_existing_byte(v1002_5_byte);
        {
        let v1003_2: Space = routine_126(c, &v998_18_cursor.path()[(v998_18_origin + 1)..(v998_18_origin + 2)], &v998_18_cursor.path()[(v998_18_origin + 1)..(v998_18_origin + 2)], &(*p2), &(*p3), &(*p4), &(v1002_2), &v998_18_cursor);
        join_wrapped_into(&mut v1002_5_write,&((v1003_2).read_zipper()),&[]);
        }
        v998_18_cursor.ascend(1);
      }
      drop(v1002_5_write);
      drop(v1002_2);
      map_map_kernels::compose(&(v998_17),&(v1002_5))
    };
    let v999_7: Space = map_map_kernels::unite(&(v999_4),&(v999_6));
    join_wrapped_into(&mut v998_18_write,&((v999_7).read_zipper()),&[]);
    }
    v998_18_cursor.ascend(1);
  }
  drop(v998_18_cursor);
  drop(v998_18_write);
  drop(v998_11);
  drop(v998_17);
  (v998_18).clone()
}

fn routine_126(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v1004_9: Space = singleton(&(*p1));
  let v1004_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1004_9));
  let v1004_11: Space = if map_kernels::has_head(&(v1004_10)) { singleton(&[]) } else { Space::new() };
  drop(v1004_10);
  let v1004_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1004_11));
  drop(v1004_11);
  let v1004_23: Space = if (&(v1004_12)).is_empty() { Space::new() } else {
    let v1005_15: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1005_18: Space = if (&(v1005_15)).is_empty() { Space::new() } else {
      let v1006_17: Space = routine_145(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*s0));
      map_map_kernels::compose(&(v1005_15),&(v1006_17))
    };
    drop(v1005_15);
    let mut v1005_21 = Space::new();
    let mut v1005_21_write = v1005_21.write_zipper();
    let mut v1005_21_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1005_21_origin = v1005_21_cursor.path().len();
    for v1005_21_byte in v1005_21_cursor.child_mask().iter() {
      v1005_21_cursor.descend_to_existing_byte(v1005_21_byte);
      {
      let v1007_2_arg_0: &[u8] = &v1005_21_cursor.path()[v1005_21_origin..(v1005_21_origin + 1)];
      let v1007_2_arg_1: &[u8] = &(*p0);
      let v1007_2_arg_2: &[u8] = &(*p2);
      let v1007_2_arg_3: &[u8] = &(*p3);
      let v1007_2_arg_4: &[u8] = &(*p4);
      let v1007_2_arg_5: &[u8] = &(*p5);
      let v1007_2_arg_7: &Space = &(&(*s0)).make_map();
      let mut v1007_2_more = v1005_21_cursor.is_val() || next_value_within(&mut v1005_21_cursor,(v1005_21_origin + 1));
      while v1007_2_more {
        {
        let v1007_2_depth = v1005_21_cursor.path().len();
        let mut v1008_8_cursor = (*v1007_2_arg_7).read_zipper();
        let v1008_8_origin = v1008_8_cursor.path().len();
        for v1008_8_byte in v1008_8_cursor.child_mask().iter() {
          v1008_8_cursor.descend_to_existing_byte(v1008_8_byte);
          {
          let v1009_2: Path = concat_path(&(*v1007_2_arg_1),&v1008_8_cursor.path()[v1008_8_origin..(v1008_8_origin + 1)]);
          let v1009_3: Space = routine_126(c, &(v1009_2), &v1005_21_cursor.path()[v1005_21_origin..v1007_2_depth], &(*v1007_2_arg_2), &(*v1007_2_arg_3), &(*v1007_2_arg_4), &(*v1007_2_arg_5), &v1008_8_cursor);
          drop(v1009_2);
          join_wrapped_into(&mut v1005_21_write,&((v1009_3).read_zipper()),&[]);
          }
          v1008_8_cursor.ascend(1);
        }
        drop(v1008_8_cursor);
        }
        v1007_2_more = next_value_within(&mut v1005_21_cursor,(v1005_21_origin + 1));
      }
      }
      v1005_21_cursor.ascend(1);
    }
    drop(v1005_21_cursor);
    drop(v1005_21_write);
    let v1005_22: Space = map_map_kernels::unite(&(v1005_18),&(v1005_21));
    map_map_kernels::compose(&(v1004_12),&(v1005_22))
  };
  drop(v1004_12);
  let v1004_25: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1004_9));
  drop(v1004_9);
  let v1004_26: Space = if map_kernels::has_head(&(v1004_25)) { singleton(&[]) } else { Space::new() };
  drop(v1004_25);
  let v1004_28: Space = if (&(v1004_26)).is_empty() { Space::new() } else {
    let mut v1010_27 = Space::new();
    let mut v1010_27_write = v1010_27.write_zipper();
    let mut v1010_27_cursor = (*s0).read_zipper();
    let v1010_27_origin = v1010_27_cursor.path().len();
    for v1010_27_byte in v1010_27_cursor.child_mask().iter() {
      v1010_27_cursor.descend_to_existing_byte(v1010_27_byte);
      {
      let v1011_2: Space = routine_146(c, &v1010_27_cursor.path()[v1010_27_origin..(v1010_27_origin + 1)], &v1010_27_cursor.path()[v1010_27_origin..(v1010_27_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v1010_27_cursor);
      join_wrapped_into(&mut v1010_27_write,&((v1011_2).read_zipper()),&[]);
      }
      v1010_27_cursor.ascend(1);
    }
    drop(v1010_27_cursor);
    drop(v1010_27_write);
    map_map_kernels::compose(&(v1004_26),&(v1010_27))
  };
  drop(v1004_26);
  let v1004_29: Space = map_map_kernels::unite(&(v1004_23),&(v1004_28));
  (v1004_29).clone()
}

fn routine_127(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v1012_8: Space = singleton(&(*p0));
  let v1012_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1012_8));
  let v1012_10: Space = if map_kernels::has_head(&(v1012_9)) { singleton(&[]) } else { Space::new() };
  drop(v1012_9);
  let v1012_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1012_10));
  drop(v1012_10);
  let v1012_16: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1012_8));
  drop(v1012_8);
  let v1012_17: Space = if map_kernels::has_head(&(v1012_16)) { singleton(&[]) } else { Space::new() };
  drop(v1012_16);
  let mut v1012_18 = Space::new();
  let mut v1012_18_write = v1012_18.write_zipper();
  let mut v1012_18_cursor = (*s0).read_zipper();
  let v1012_18_origin = v1012_18_cursor.path().len();
  for v1012_18_byte in v1012_18_cursor.child_mask().iter() {
    v1012_18_cursor.descend_to_existing_byte(v1012_18_byte);
    {
    let v1013_4: Space = if (&(v1012_11)).is_empty() { Space::new() } else {
      let v1014_2: Path = concat_path(&(*p1),&v1012_18_cursor.path()[v1012_18_origin..(v1012_18_origin + 1)]);
      let mut v1014_3 = Space::new();
      let mut v1014_3_write = v1014_3.write_zipper();
      let v1014_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1014_3_arg_1: &[u8] = &(v1014_2);
      let v1014_3_arg_2: &[u8] = &(*p2);
      let v1014_3_arg_3: &[u8] = &(*p3);
      let v1014_3_arg_4: &[u8] = &(*p4);
      let v1014_3_arg_6: &Space = &(&v1012_18_cursor).make_map();
      let mut v1014_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1014_3_origin = v1014_3_cursor.path().len();
      let mut v1014_3_more = v1014_3_cursor.is_val() || next_value_within(&mut v1014_3_cursor,v1014_3_origin);
      while v1014_3_more {
        {
        let v1014_3_depth = v1014_3_cursor.path().len();
        let v1015_7: Space = routine_127(c, &v1014_3_cursor.path()[v1014_3_origin..v1014_3_depth], &(*v1014_3_arg_1), &(*v1014_3_arg_2), &(*v1014_3_arg_3), &(*v1014_3_arg_4), &((*v1014_3_arg_6).read_zipper()));
        join_wrapped_into(&mut v1014_3_write,&((v1015_7).read_zipper()),&[]);
        }
        v1014_3_more = next_value_within(&mut v1014_3_cursor,v1014_3_origin);
      }
      drop(v1014_3_cursor);
      drop(v1014_3_write);
      map_map_kernels::compose(&(v1012_11),&(v1014_3))
    };
    let v1013_6: Space = if (&(v1012_17)).is_empty() { Space::new() } else {
      let v1016_2: Path = concat_path(&(*p1),&v1012_18_cursor.path()[v1012_18_origin..(v1012_18_origin + 1)]);
      let mut v1016_5 = Space::new();
      let mut v1016_5_write = v1016_5.write_zipper();
      for v1016_5_byte in v1012_18_cursor.child_mask().iter() {
        v1012_18_cursor.descend_to_existing_byte(v1016_5_byte);
        {
        let v1017_2: Space = routine_128(c, &v1012_18_cursor.path()[(v1012_18_origin + 1)..(v1012_18_origin + 2)], &v1012_18_cursor.path()[(v1012_18_origin + 1)..(v1012_18_origin + 2)], &(*p2), &(*p3), &(*p4), &(v1016_2), &v1012_18_cursor);
        join_wrapped_into(&mut v1016_5_write,&((v1017_2).read_zipper()),&[]);
        }
        v1012_18_cursor.ascend(1);
      }
      drop(v1016_5_write);
      drop(v1016_2);
      map_map_kernels::compose(&(v1012_17),&(v1016_5))
    };
    let v1013_7: Space = map_map_kernels::unite(&(v1013_4),&(v1013_6));
    join_wrapped_into(&mut v1012_18_write,&((v1013_7).read_zipper()),&[]);
    }
    v1012_18_cursor.ascend(1);
  }
  drop(v1012_18_cursor);
  drop(v1012_18_write);
  drop(v1012_11);
  drop(v1012_17);
  (v1012_18).clone()
}

fn routine_128(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v1018_9: Space = singleton(&(*p1));
  let v1018_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1018_9));
  let v1018_11: Space = if map_kernels::has_head(&(v1018_10)) { singleton(&[]) } else { Space::new() };
  drop(v1018_10);
  let v1018_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1018_11));
  drop(v1018_11);
  let v1018_23: Space = if (&(v1018_12)).is_empty() { Space::new() } else {
    let v1019_15: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1019_18: Space = if (&(v1019_15)).is_empty() { Space::new() } else {
      let v1020_17: Space = routine_147(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*s0));
      map_map_kernels::compose(&(v1019_15),&(v1020_17))
    };
    drop(v1019_15);
    let mut v1019_21 = Space::new();
    let mut v1019_21_write = v1019_21.write_zipper();
    let mut v1019_21_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1019_21_origin = v1019_21_cursor.path().len();
    for v1019_21_byte in v1019_21_cursor.child_mask().iter() {
      v1019_21_cursor.descend_to_existing_byte(v1019_21_byte);
      {
      let v1021_2_arg_0: &[u8] = &v1019_21_cursor.path()[v1019_21_origin..(v1019_21_origin + 1)];
      let v1021_2_arg_1: &[u8] = &(*p0);
      let v1021_2_arg_2: &[u8] = &(*p2);
      let v1021_2_arg_3: &[u8] = &(*p3);
      let v1021_2_arg_4: &[u8] = &(*p4);
      let v1021_2_arg_5: &[u8] = &(*p5);
      let v1021_2_arg_7: &Space = &(&(*s0)).make_map();
      let mut v1021_2_more = v1019_21_cursor.is_val() || next_value_within(&mut v1019_21_cursor,(v1019_21_origin + 1));
      while v1021_2_more {
        {
        let v1021_2_depth = v1019_21_cursor.path().len();
        let mut v1022_8_cursor = (*v1021_2_arg_7).read_zipper();
        let v1022_8_origin = v1022_8_cursor.path().len();
        for v1022_8_byte in v1022_8_cursor.child_mask().iter() {
          v1022_8_cursor.descend_to_existing_byte(v1022_8_byte);
          {
          let v1023_2: Path = concat_path(&(*v1021_2_arg_1),&v1022_8_cursor.path()[v1022_8_origin..(v1022_8_origin + 1)]);
          let v1023_3: Space = routine_128(c, &(v1023_2), &v1019_21_cursor.path()[v1019_21_origin..v1021_2_depth], &(*v1021_2_arg_2), &(*v1021_2_arg_3), &(*v1021_2_arg_4), &(*v1021_2_arg_5), &v1022_8_cursor);
          drop(v1023_2);
          join_wrapped_into(&mut v1019_21_write,&((v1023_3).read_zipper()),&[]);
          }
          v1022_8_cursor.ascend(1);
        }
        drop(v1022_8_cursor);
        }
        v1021_2_more = next_value_within(&mut v1019_21_cursor,(v1019_21_origin + 1));
      }
      }
      v1019_21_cursor.ascend(1);
    }
    drop(v1019_21_cursor);
    drop(v1019_21_write);
    let v1019_22: Space = map_map_kernels::unite(&(v1019_18),&(v1019_21));
    map_map_kernels::compose(&(v1018_12),&(v1019_22))
  };
  drop(v1018_12);
  let v1018_25: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1018_9));
  drop(v1018_9);
  let v1018_26: Space = if map_kernels::has_head(&(v1018_25)) { singleton(&[]) } else { Space::new() };
  drop(v1018_25);
  let v1018_28: Space = if (&(v1018_26)).is_empty() { Space::new() } else {
    let mut v1024_27 = Space::new();
    let mut v1024_27_write = v1024_27.write_zipper();
    let mut v1024_27_cursor = (*s0).read_zipper();
    let v1024_27_origin = v1024_27_cursor.path().len();
    for v1024_27_byte in v1024_27_cursor.child_mask().iter() {
      v1024_27_cursor.descend_to_existing_byte(v1024_27_byte);
      {
      let v1025_2: Space = routine_148(c, &v1024_27_cursor.path()[v1024_27_origin..(v1024_27_origin + 1)], &v1024_27_cursor.path()[v1024_27_origin..(v1024_27_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v1024_27_cursor);
      join_wrapped_into(&mut v1024_27_write,&((v1025_2).read_zipper()),&[]);
      }
      v1024_27_cursor.ascend(1);
    }
    drop(v1024_27_cursor);
    drop(v1024_27_write);
    map_map_kernels::compose(&(v1018_26),&(v1024_27))
  };
  drop(v1018_26);
  let v1018_29: Space = map_map_kernels::unite(&(v1018_23),&(v1018_28));
  (v1018_29).clone()
}

fn routine_129(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v1026_8: Space = singleton(&(*p0));
  let v1026_9: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1026_8));
  let v1026_10: Space = if map_kernels::has_head(&(v1026_9)) { singleton(&[]) } else { Space::new() };
  drop(v1026_9);
  let v1026_11: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1026_10));
  drop(v1026_10);
  let v1026_16: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1026_8));
  drop(v1026_8);
  let v1026_17: Space = if map_kernels::has_head(&(v1026_16)) { singleton(&[]) } else { Space::new() };
  drop(v1026_16);
  let mut v1026_18 = Space::new();
  let mut v1026_18_write = v1026_18.write_zipper();
  let mut v1026_18_cursor = (*s0).read_zipper();
  let v1026_18_origin = v1026_18_cursor.path().len();
  for v1026_18_byte in v1026_18_cursor.child_mask().iter() {
    v1026_18_cursor.descend_to_existing_byte(v1026_18_byte);
    {
    let v1027_4: Space = if (&(v1026_11)).is_empty() { Space::new() } else {
      let v1028_2: Path = concat_path(&(*p1),&v1026_18_cursor.path()[v1026_18_origin..(v1026_18_origin + 1)]);
      let mut v1028_3 = Space::new();
      let mut v1028_3_write = v1028_3.write_zipper();
      let v1028_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1028_3_arg_1: &[u8] = &(v1028_2);
      let v1028_3_arg_2: &[u8] = &(*p2);
      let v1028_3_arg_3: &[u8] = &(*p3);
      let v1028_3_arg_4: &[u8] = &(*p4);
      let v1028_3_arg_6: &Space = &(&v1026_18_cursor).make_map();
      let mut v1028_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1028_3_origin = v1028_3_cursor.path().len();
      let mut v1028_3_more = v1028_3_cursor.is_val() || next_value_within(&mut v1028_3_cursor,v1028_3_origin);
      while v1028_3_more {
        {
        let v1028_3_depth = v1028_3_cursor.path().len();
        let v1029_7: Space = routine_129(c, &v1028_3_cursor.path()[v1028_3_origin..v1028_3_depth], &(*v1028_3_arg_1), &(*v1028_3_arg_2), &(*v1028_3_arg_3), &(*v1028_3_arg_4), &((*v1028_3_arg_6).read_zipper()));
        join_wrapped_into(&mut v1028_3_write,&((v1029_7).read_zipper()),&[]);
        }
        v1028_3_more = next_value_within(&mut v1028_3_cursor,v1028_3_origin);
      }
      drop(v1028_3_cursor);
      drop(v1028_3_write);
      map_map_kernels::compose(&(v1026_11),&(v1028_3))
    };
    let v1027_6: Space = if (&(v1026_17)).is_empty() { Space::new() } else {
      let v1030_2: Path = concat_path(&(*p1),&v1026_18_cursor.path()[v1026_18_origin..(v1026_18_origin + 1)]);
      let mut v1030_5 = Space::new();
      let mut v1030_5_write = v1030_5.write_zipper();
      for v1030_5_byte in v1026_18_cursor.child_mask().iter() {
        v1026_18_cursor.descend_to_existing_byte(v1030_5_byte);
        {
        let v1031_2: Space = routine_130(c, &v1026_18_cursor.path()[(v1026_18_origin + 1)..(v1026_18_origin + 2)], &v1026_18_cursor.path()[(v1026_18_origin + 1)..(v1026_18_origin + 2)], &(*p2), &(*p3), &(*p4), &(v1030_2), &v1026_18_cursor);
        join_wrapped_into(&mut v1030_5_write,&((v1031_2).read_zipper()),&[]);
        }
        v1026_18_cursor.ascend(1);
      }
      drop(v1030_5_write);
      drop(v1030_2);
      map_map_kernels::compose(&(v1026_17),&(v1030_5))
    };
    let v1027_7: Space = map_map_kernels::unite(&(v1027_4),&(v1027_6));
    join_wrapped_into(&mut v1026_18_write,&((v1027_7).read_zipper()),&[]);
    }
    v1026_18_cursor.ascend(1);
  }
  drop(v1026_18_cursor);
  drop(v1026_18_write);
  drop(v1026_11);
  drop(v1026_17);
  (v1026_18).clone()
}

fn routine_130(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v1032_9: Space = singleton(&(*p1));
  let v1032_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1032_9));
  let v1032_11: Space = if map_kernels::has_head(&(v1032_10)) { singleton(&[]) } else { Space::new() };
  drop(v1032_10);
  let v1032_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1032_11));
  drop(v1032_11);
  let v1032_23: Space = if (&(v1032_12)).is_empty() { Space::new() } else {
    let v1033_15: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1033_18: Space = if (&(v1033_15)).is_empty() { Space::new() } else {
      let v1034_17: Space = routine_149(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*s0));
      map_map_kernels::compose(&(v1033_15),&(v1034_17))
    };
    drop(v1033_15);
    let mut v1033_21 = Space::new();
    let mut v1033_21_write = v1033_21.write_zipper();
    let mut v1033_21_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1033_21_origin = v1033_21_cursor.path().len();
    for v1033_21_byte in v1033_21_cursor.child_mask().iter() {
      v1033_21_cursor.descend_to_existing_byte(v1033_21_byte);
      {
      let v1035_2_arg_0: &[u8] = &v1033_21_cursor.path()[v1033_21_origin..(v1033_21_origin + 1)];
      let v1035_2_arg_1: &[u8] = &(*p0);
      let v1035_2_arg_2: &[u8] = &(*p2);
      let v1035_2_arg_3: &[u8] = &(*p3);
      let v1035_2_arg_4: &[u8] = &(*p4);
      let v1035_2_arg_5: &[u8] = &(*p5);
      let v1035_2_arg_7: &Space = &(&(*s0)).make_map();
      let mut v1035_2_more = v1033_21_cursor.is_val() || next_value_within(&mut v1033_21_cursor,(v1033_21_origin + 1));
      while v1035_2_more {
        {
        let v1035_2_depth = v1033_21_cursor.path().len();
        let mut v1036_8_cursor = (*v1035_2_arg_7).read_zipper();
        let v1036_8_origin = v1036_8_cursor.path().len();
        for v1036_8_byte in v1036_8_cursor.child_mask().iter() {
          v1036_8_cursor.descend_to_existing_byte(v1036_8_byte);
          {
          let v1037_2: Path = concat_path(&(*v1035_2_arg_1),&v1036_8_cursor.path()[v1036_8_origin..(v1036_8_origin + 1)]);
          let v1037_3: Space = routine_130(c, &(v1037_2), &v1033_21_cursor.path()[v1033_21_origin..v1035_2_depth], &(*v1035_2_arg_2), &(*v1035_2_arg_3), &(*v1035_2_arg_4), &(*v1035_2_arg_5), &v1036_8_cursor);
          drop(v1037_2);
          join_wrapped_into(&mut v1033_21_write,&((v1037_3).read_zipper()),&[]);
          }
          v1036_8_cursor.ascend(1);
        }
        drop(v1036_8_cursor);
        }
        v1035_2_more = next_value_within(&mut v1033_21_cursor,(v1033_21_origin + 1));
      }
      }
      v1033_21_cursor.ascend(1);
    }
    drop(v1033_21_cursor);
    drop(v1033_21_write);
    let v1033_22: Space = map_map_kernels::unite(&(v1033_18),&(v1033_21));
    map_map_kernels::compose(&(v1032_12),&(v1033_22))
  };
  drop(v1032_12);
  let v1032_25: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1032_9));
  drop(v1032_9);
  let v1032_26: Space = if map_kernels::has_head(&(v1032_25)) { singleton(&[]) } else { Space::new() };
  drop(v1032_25);
  let v1032_28: Space = if (&(v1032_26)).is_empty() { Space::new() } else {
    let mut v1038_27 = Space::new();
    let mut v1038_27_write = v1038_27.write_zipper();
    let mut v1038_27_cursor = (*s0).read_zipper();
    let v1038_27_origin = v1038_27_cursor.path().len();
    for v1038_27_byte in v1038_27_cursor.child_mask().iter() {
      v1038_27_cursor.descend_to_existing_byte(v1038_27_byte);
      {
      let v1039_2: Space = routine_150(c, &v1038_27_cursor.path()[v1038_27_origin..(v1038_27_origin + 1)], &v1038_27_cursor.path()[v1038_27_origin..(v1038_27_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v1038_27_cursor);
      join_wrapped_into(&mut v1038_27_write,&((v1039_2).read_zipper()),&[]);
      }
      v1038_27_cursor.ascend(1);
    }
    drop(v1038_27_cursor);
    drop(v1038_27_write);
    map_map_kernels::compose(&(v1032_26),&(v1038_27))
  };
  drop(v1032_26);
  let v1032_29: Space = map_map_kernels::unite(&(v1032_23),&(v1032_28));
  (v1032_29).clone()
}

fn routine_131(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v1040_5: Space = singleton(&(*p0));
  let v1040_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1040_5));
  let v1040_7: Space = if map_kernels::has_head(&(v1040_6)) { singleton(&[]) } else { Space::new() };
  drop(v1040_6);
  let v1040_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1040_7));
  drop(v1040_7);
  let v1040_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1040_5));
  drop(v1040_5);
  let v1040_14: Space = if map_kernels::has_head(&(v1040_13)) { singleton(&[]) } else { Space::new() };
  drop(v1040_13);
  let mut v1040_15 = Space::new();
  let mut v1040_15_write = v1040_15.write_zipper();
  let mut v1040_15_cursor = (*s0).read_zipper();
  let v1040_15_origin = v1040_15_cursor.path().len();
  for v1040_15_byte in v1040_15_cursor.child_mask().iter() {
    v1040_15_cursor.descend_to_existing_byte(v1040_15_byte);
    {
    let v1041_4: Space = if (&(v1040_8)).is_empty() { Space::new() } else {
      let v1042_2: Path = concat_path(&(*p1),&v1040_15_cursor.path()[v1040_15_origin..(v1040_15_origin + 1)]);
      let mut v1042_3 = Space::new();
      let mut v1042_3_write = v1042_3.write_zipper();
      let v1042_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1042_3_arg_1: &[u8] = &(v1042_2);
      let v1042_3_arg_3: &Space = &(&v1040_15_cursor).make_map();
      let mut v1042_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1042_3_origin = v1042_3_cursor.path().len();
      let mut v1042_3_more = v1042_3_cursor.is_val() || next_value_within(&mut v1042_3_cursor,v1042_3_origin);
      while v1042_3_more {
        {
        let v1042_3_depth = v1042_3_cursor.path().len();
        let v1043_4: Space = routine_131(c, &v1042_3_cursor.path()[v1042_3_origin..v1042_3_depth], &(*v1042_3_arg_1), &((*v1042_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v1042_3_write,&((v1043_4).read_zipper()),&[]);
        }
        v1042_3_more = next_value_within(&mut v1042_3_cursor,v1042_3_origin);
      }
      drop(v1042_3_cursor);
      drop(v1042_3_write);
      map_map_kernels::compose(&(v1040_8),&(v1042_3))
    };
    let v1041_6: Space = if (&(v1040_14)).is_empty() { Space::new() } else {
      let v1044_2: Path = concat_path(&(*p1),&v1040_15_cursor.path()[v1040_15_origin..(v1040_15_origin + 1)]);
      let v1044_5: Space = singleton(&(v1044_2));
      drop(v1044_2);
      map_map_kernels::compose(&(v1040_14),&(v1044_5))
    };
    let v1041_7: Space = map_map_kernels::unite(&(v1041_4),&(v1041_6));
    drop(v1041_6);
    join_wrapped_into(&mut v1040_15_write,&((v1041_7).read_zipper()),&[]);
    }
    v1040_15_cursor.ascend(1);
  }
  drop(v1040_15_cursor);
  drop(v1040_15_write);
  drop(v1040_8);
  drop(v1040_14);
  (v1040_15).clone()
}

fn routine_132(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v1045_5: Space = singleton(&(*p0));
  let v1045_6: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1045_5));
  let v1045_7: Space = if map_kernels::has_head(&(v1045_6)) { singleton(&[]) } else { Space::new() };
  drop(v1045_6);
  let v1045_8: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1045_7));
  drop(v1045_7);
  let v1045_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1045_5));
  drop(v1045_5);
  let v1045_14: Space = if map_kernels::has_head(&(v1045_13)) { singleton(&[]) } else { Space::new() };
  drop(v1045_13);
  let mut v1045_15 = Space::new();
  let mut v1045_15_write = v1045_15.write_zipper();
  let mut v1045_15_cursor = (*s0).read_zipper();
  let v1045_15_origin = v1045_15_cursor.path().len();
  for v1045_15_byte in v1045_15_cursor.child_mask().iter() {
    v1045_15_cursor.descend_to_existing_byte(v1045_15_byte);
    {
    let v1046_4: Space = if (&(v1045_8)).is_empty() { Space::new() } else {
      let v1047_2: Path = concat_path(&(*p1),&v1045_15_cursor.path()[v1045_15_origin..(v1045_15_origin + 1)]);
      let mut v1047_3 = Space::new();
      let mut v1047_3_write = v1047_3.write_zipper();
      let v1047_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1047_3_arg_1: &[u8] = &(v1047_2);
      let v1047_3_arg_3: &Space = &(&v1045_15_cursor).make_map();
      let mut v1047_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1047_3_origin = v1047_3_cursor.path().len();
      let mut v1047_3_more = v1047_3_cursor.is_val() || next_value_within(&mut v1047_3_cursor,v1047_3_origin);
      while v1047_3_more {
        {
        let v1047_3_depth = v1047_3_cursor.path().len();
        let v1048_4: Space = routine_132(c, &v1047_3_cursor.path()[v1047_3_origin..v1047_3_depth], &(*v1047_3_arg_1), &((*v1047_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v1047_3_write,&((v1048_4).read_zipper()),&[]);
        }
        v1047_3_more = next_value_within(&mut v1047_3_cursor,v1047_3_origin);
      }
      drop(v1047_3_cursor);
      drop(v1047_3_write);
      map_map_kernels::compose(&(v1045_8),&(v1047_3))
    };
    let v1046_6: Space = if (&(v1045_14)).is_empty() { Space::new() } else {
      let v1049_2: Path = concat_path(&(*p1),&v1045_15_cursor.path()[v1045_15_origin..(v1045_15_origin + 1)]);
      let v1049_5: Space = singleton(&(v1049_2));
      drop(v1049_2);
      map_map_kernels::compose(&(v1045_14),&(v1049_5))
    };
    let v1046_7: Space = map_map_kernels::unite(&(v1046_4),&(v1046_6));
    drop(v1046_6);
    join_wrapped_into(&mut v1045_15_write,&((v1046_7).read_zipper()),&[]);
    }
    v1045_15_cursor.ascend(1);
  }
  drop(v1045_15_cursor);
  drop(v1045_15_write);
  drop(v1045_8);
  drop(v1045_14);
  (v1045_15).clone()
}

fn routine_133(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v1050_9: Space = singleton(&(*p0));
  let v1050_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1050_9));
  let v1050_11: Space = if map_kernels::has_head(&(v1050_10)) { singleton(&[]) } else { Space::new() };
  drop(v1050_10);
  let v1050_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1050_11));
  drop(v1050_11);
  let v1050_17: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1050_9));
  drop(v1050_9);
  let v1050_18: Space = if map_kernels::has_head(&(v1050_17)) { singleton(&[]) } else { Space::new() };
  drop(v1050_17);
  let mut v1050_19 = Space::new();
  let mut v1050_19_write = v1050_19.write_zipper();
  let mut v1050_19_cursor = (*s0).read_zipper();
  let v1050_19_origin = v1050_19_cursor.path().len();
  for v1050_19_byte in v1050_19_cursor.child_mask().iter() {
    v1050_19_cursor.descend_to_existing_byte(v1050_19_byte);
    {
    let v1051_4: Space = if (&(v1050_12)).is_empty() { Space::new() } else {
      let v1052_2: Path = concat_path(&(*p1),&v1050_19_cursor.path()[v1050_19_origin..(v1050_19_origin + 1)]);
      let mut v1052_3 = Space::new();
      let mut v1052_3_write = v1052_3.write_zipper();
      let v1052_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1052_3_arg_1: &[u8] = &(v1052_2);
      let v1052_3_arg_2: &[u8] = &(*p2);
      let v1052_3_arg_3: &[u8] = &(*p3);
      let v1052_3_arg_4: &[u8] = &(*p4);
      let v1052_3_arg_5: &[u8] = &(*p5);
      let v1052_3_arg_7: &Space = &(&v1050_19_cursor).make_map();
      let mut v1052_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1052_3_origin = v1052_3_cursor.path().len();
      let mut v1052_3_more = v1052_3_cursor.is_val() || next_value_within(&mut v1052_3_cursor,v1052_3_origin);
      while v1052_3_more {
        {
        let v1052_3_depth = v1052_3_cursor.path().len();
        let v1053_8: Space = routine_133(c, &v1052_3_cursor.path()[v1052_3_origin..v1052_3_depth], &(*v1052_3_arg_1), &(*v1052_3_arg_2), &(*v1052_3_arg_3), &(*v1052_3_arg_4), &(*v1052_3_arg_5), &((*v1052_3_arg_7).read_zipper()));
        join_wrapped_into(&mut v1052_3_write,&((v1053_8).read_zipper()),&[]);
        }
        v1052_3_more = next_value_within(&mut v1052_3_cursor,v1052_3_origin);
      }
      drop(v1052_3_cursor);
      drop(v1052_3_write);
      map_map_kernels::compose(&(v1050_12),&(v1052_3))
    };
    let v1051_6: Space = if (&(v1050_18)).is_empty() { Space::new() } else {
      let v1054_2: Path = concat_path(&(*p1),&v1050_19_cursor.path()[v1050_19_origin..(v1050_19_origin + 1)]);
      let mut v1054_5 = Space::new();
      let mut v1054_5_write = v1054_5.write_zipper();
      for v1054_5_byte in v1050_19_cursor.child_mask().iter() {
        v1050_19_cursor.descend_to_existing_byte(v1054_5_byte);
        {
        let v1055_2: Space = routine_134(c, &v1050_19_cursor.path()[(v1050_19_origin + 1)..(v1050_19_origin + 2)], &v1050_19_cursor.path()[(v1050_19_origin + 1)..(v1050_19_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(v1054_2), &v1050_19_cursor);
        join_wrapped_into(&mut v1054_5_write,&((v1055_2).read_zipper()),&[]);
        }
        v1050_19_cursor.ascend(1);
      }
      drop(v1054_5_write);
      drop(v1054_2);
      map_map_kernels::compose(&(v1050_18),&(v1054_5))
    };
    let v1051_7: Space = map_map_kernels::unite(&(v1051_4),&(v1051_6));
    join_wrapped_into(&mut v1050_19_write,&((v1051_7).read_zipper()),&[]);
    }
    v1050_19_cursor.ascend(1);
  }
  drop(v1050_19_cursor);
  drop(v1050_19_write);
  drop(v1050_12);
  drop(v1050_18);
  (v1050_19).clone()
}

fn routine_134(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v1056_10: Space = singleton(&(*p1));
  let v1056_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1056_10));
  let v1056_12: Space = if map_kernels::has_head(&(v1056_11)) { singleton(&[]) } else { Space::new() };
  drop(v1056_11);
  let v1056_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1056_12));
  drop(v1056_12);
  let v1056_24: Space = if (&(v1056_13)).is_empty() { Space::new() } else {
    let v1057_16: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1057_19: Space = if (&(v1057_16)).is_empty() { Space::new() } else {
      let v1058_18: Space = routine_151(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*s0));
      map_map_kernels::compose(&(v1057_16),&(v1058_18))
    };
    drop(v1057_16);
    let mut v1057_22 = Space::new();
    let mut v1057_22_write = v1057_22.write_zipper();
    let mut v1057_22_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1057_22_origin = v1057_22_cursor.path().len();
    for v1057_22_byte in v1057_22_cursor.child_mask().iter() {
      v1057_22_cursor.descend_to_existing_byte(v1057_22_byte);
      {
      let v1059_2_arg_0: &[u8] = &v1057_22_cursor.path()[v1057_22_origin..(v1057_22_origin + 1)];
      let v1059_2_arg_1: &[u8] = &(*p0);
      let v1059_2_arg_2: &[u8] = &(*p2);
      let v1059_2_arg_3: &[u8] = &(*p3);
      let v1059_2_arg_4: &[u8] = &(*p4);
      let v1059_2_arg_5: &[u8] = &(*p5);
      let v1059_2_arg_6: &[u8] = &(*p6);
      let v1059_2_arg_8: &Space = &(&(*s0)).make_map();
      let mut v1059_2_more = v1057_22_cursor.is_val() || next_value_within(&mut v1057_22_cursor,(v1057_22_origin + 1));
      while v1059_2_more {
        {
        let v1059_2_depth = v1057_22_cursor.path().len();
        let mut v1060_9_cursor = (*v1059_2_arg_8).read_zipper();
        let v1060_9_origin = v1060_9_cursor.path().len();
        for v1060_9_byte in v1060_9_cursor.child_mask().iter() {
          v1060_9_cursor.descend_to_existing_byte(v1060_9_byte);
          {
          let v1061_2: Path = concat_path(&(*v1059_2_arg_1),&v1060_9_cursor.path()[v1060_9_origin..(v1060_9_origin + 1)]);
          let v1061_3: Space = routine_134(c, &(v1061_2), &v1057_22_cursor.path()[v1057_22_origin..v1059_2_depth], &(*v1059_2_arg_2), &(*v1059_2_arg_3), &(*v1059_2_arg_4), &(*v1059_2_arg_5), &(*v1059_2_arg_6), &v1060_9_cursor);
          drop(v1061_2);
          join_wrapped_into(&mut v1057_22_write,&((v1061_3).read_zipper()),&[]);
          }
          v1060_9_cursor.ascend(1);
        }
        drop(v1060_9_cursor);
        }
        v1059_2_more = next_value_within(&mut v1057_22_cursor,(v1057_22_origin + 1));
      }
      }
      v1057_22_cursor.ascend(1);
    }
    drop(v1057_22_cursor);
    drop(v1057_22_write);
    let v1057_23: Space = map_map_kernels::unite(&(v1057_19),&(v1057_22));
    map_map_kernels::compose(&(v1056_13),&(v1057_23))
  };
  drop(v1056_13);
  let v1056_26: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1056_10));
  drop(v1056_10);
  let v1056_27: Space = if map_kernels::has_head(&(v1056_26)) { singleton(&[]) } else { Space::new() };
  drop(v1056_26);
  let v1056_29: Space = if (&(v1056_27)).is_empty() { Space::new() } else {
    let mut v1062_28 = Space::new();
    let mut v1062_28_write = v1062_28.write_zipper();
    let mut v1062_28_cursor = (*s0).read_zipper();
    let v1062_28_origin = v1062_28_cursor.path().len();
    for v1062_28_byte in v1062_28_cursor.child_mask().iter() {
      v1062_28_cursor.descend_to_existing_byte(v1062_28_byte);
      {
      let v1063_2: Space = routine_152(c, &v1062_28_cursor.path()[v1062_28_origin..(v1062_28_origin + 1)], &v1062_28_cursor.path()[v1062_28_origin..(v1062_28_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v1062_28_cursor);
      join_wrapped_into(&mut v1062_28_write,&((v1063_2).read_zipper()),&[]);
      }
      v1062_28_cursor.ascend(1);
    }
    drop(v1062_28_cursor);
    drop(v1062_28_write);
    map_map_kernels::compose(&(v1056_27),&(v1062_28))
  };
  drop(v1056_27);
  let v1056_30: Space = map_map_kernels::unite(&(v1056_24),&(v1056_29));
  (v1056_30).clone()
}

fn routine_135(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v1064_9: Space = singleton(&(*p0));
  let v1064_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1064_9));
  let v1064_11: Space = if map_kernels::has_head(&(v1064_10)) { singleton(&[]) } else { Space::new() };
  drop(v1064_10);
  let v1064_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1064_11));
  drop(v1064_11);
  let v1064_17: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1064_9));
  drop(v1064_9);
  let v1064_18: Space = if map_kernels::has_head(&(v1064_17)) { singleton(&[]) } else { Space::new() };
  drop(v1064_17);
  let mut v1064_19 = Space::new();
  let mut v1064_19_write = v1064_19.write_zipper();
  let mut v1064_19_cursor = (*s0).read_zipper();
  let v1064_19_origin = v1064_19_cursor.path().len();
  for v1064_19_byte in v1064_19_cursor.child_mask().iter() {
    v1064_19_cursor.descend_to_existing_byte(v1064_19_byte);
    {
    let v1065_4: Space = if (&(v1064_12)).is_empty() { Space::new() } else {
      let v1066_2: Path = concat_path(&(*p1),&v1064_19_cursor.path()[v1064_19_origin..(v1064_19_origin + 1)]);
      let mut v1066_3 = Space::new();
      let mut v1066_3_write = v1066_3.write_zipper();
      let v1066_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1066_3_arg_1: &[u8] = &(v1066_2);
      let v1066_3_arg_2: &[u8] = &(*p2);
      let v1066_3_arg_3: &[u8] = &(*p3);
      let v1066_3_arg_4: &[u8] = &(*p4);
      let v1066_3_arg_5: &[u8] = &(*p5);
      let v1066_3_arg_7: &Space = &(&v1064_19_cursor).make_map();
      let mut v1066_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1066_3_origin = v1066_3_cursor.path().len();
      let mut v1066_3_more = v1066_3_cursor.is_val() || next_value_within(&mut v1066_3_cursor,v1066_3_origin);
      while v1066_3_more {
        {
        let v1066_3_depth = v1066_3_cursor.path().len();
        let v1067_8: Space = routine_135(c, &v1066_3_cursor.path()[v1066_3_origin..v1066_3_depth], &(*v1066_3_arg_1), &(*v1066_3_arg_2), &(*v1066_3_arg_3), &(*v1066_3_arg_4), &(*v1066_3_arg_5), &((*v1066_3_arg_7).read_zipper()));
        join_wrapped_into(&mut v1066_3_write,&((v1067_8).read_zipper()),&[]);
        }
        v1066_3_more = next_value_within(&mut v1066_3_cursor,v1066_3_origin);
      }
      drop(v1066_3_cursor);
      drop(v1066_3_write);
      map_map_kernels::compose(&(v1064_12),&(v1066_3))
    };
    let v1065_6: Space = if (&(v1064_18)).is_empty() { Space::new() } else {
      let v1068_2: Path = concat_path(&(*p1),&v1064_19_cursor.path()[v1064_19_origin..(v1064_19_origin + 1)]);
      let mut v1068_5 = Space::new();
      let mut v1068_5_write = v1068_5.write_zipper();
      for v1068_5_byte in v1064_19_cursor.child_mask().iter() {
        v1064_19_cursor.descend_to_existing_byte(v1068_5_byte);
        {
        let v1069_2: Space = routine_136(c, &v1064_19_cursor.path()[(v1064_19_origin + 1)..(v1064_19_origin + 2)], &v1064_19_cursor.path()[(v1064_19_origin + 1)..(v1064_19_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(v1068_2), &v1064_19_cursor);
        join_wrapped_into(&mut v1068_5_write,&((v1069_2).read_zipper()),&[]);
        }
        v1064_19_cursor.ascend(1);
      }
      drop(v1068_5_write);
      drop(v1068_2);
      map_map_kernels::compose(&(v1064_18),&(v1068_5))
    };
    let v1065_7: Space = map_map_kernels::unite(&(v1065_4),&(v1065_6));
    join_wrapped_into(&mut v1064_19_write,&((v1065_7).read_zipper()),&[]);
    }
    v1064_19_cursor.ascend(1);
  }
  drop(v1064_19_cursor);
  drop(v1064_19_write);
  drop(v1064_12);
  drop(v1064_18);
  (v1064_19).clone()
}

fn routine_136(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v1070_10: Space = singleton(&(*p1));
  let v1070_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1070_10));
  let v1070_12: Space = if map_kernels::has_head(&(v1070_11)) { singleton(&[]) } else { Space::new() };
  drop(v1070_11);
  let v1070_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1070_12));
  drop(v1070_12);
  let v1070_24: Space = if (&(v1070_13)).is_empty() { Space::new() } else {
    let v1071_16: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1071_19: Space = if (&(v1071_16)).is_empty() { Space::new() } else {
      let v1072_18: Space = routine_153(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*s0));
      map_map_kernels::compose(&(v1071_16),&(v1072_18))
    };
    drop(v1071_16);
    let mut v1071_22 = Space::new();
    let mut v1071_22_write = v1071_22.write_zipper();
    let mut v1071_22_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1071_22_origin = v1071_22_cursor.path().len();
    for v1071_22_byte in v1071_22_cursor.child_mask().iter() {
      v1071_22_cursor.descend_to_existing_byte(v1071_22_byte);
      {
      let v1073_2_arg_0: &[u8] = &v1071_22_cursor.path()[v1071_22_origin..(v1071_22_origin + 1)];
      let v1073_2_arg_1: &[u8] = &(*p0);
      let v1073_2_arg_2: &[u8] = &(*p2);
      let v1073_2_arg_3: &[u8] = &(*p3);
      let v1073_2_arg_4: &[u8] = &(*p4);
      let v1073_2_arg_5: &[u8] = &(*p5);
      let v1073_2_arg_6: &[u8] = &(*p6);
      let v1073_2_arg_8: &Space = &(&(*s0)).make_map();
      let mut v1073_2_more = v1071_22_cursor.is_val() || next_value_within(&mut v1071_22_cursor,(v1071_22_origin + 1));
      while v1073_2_more {
        {
        let v1073_2_depth = v1071_22_cursor.path().len();
        let mut v1074_9_cursor = (*v1073_2_arg_8).read_zipper();
        let v1074_9_origin = v1074_9_cursor.path().len();
        for v1074_9_byte in v1074_9_cursor.child_mask().iter() {
          v1074_9_cursor.descend_to_existing_byte(v1074_9_byte);
          {
          let v1075_2: Path = concat_path(&(*v1073_2_arg_1),&v1074_9_cursor.path()[v1074_9_origin..(v1074_9_origin + 1)]);
          let v1075_3: Space = routine_136(c, &(v1075_2), &v1071_22_cursor.path()[v1071_22_origin..v1073_2_depth], &(*v1073_2_arg_2), &(*v1073_2_arg_3), &(*v1073_2_arg_4), &(*v1073_2_arg_5), &(*v1073_2_arg_6), &v1074_9_cursor);
          drop(v1075_2);
          join_wrapped_into(&mut v1071_22_write,&((v1075_3).read_zipper()),&[]);
          }
          v1074_9_cursor.ascend(1);
        }
        drop(v1074_9_cursor);
        }
        v1073_2_more = next_value_within(&mut v1071_22_cursor,(v1071_22_origin + 1));
      }
      }
      v1071_22_cursor.ascend(1);
    }
    drop(v1071_22_cursor);
    drop(v1071_22_write);
    let v1071_23: Space = map_map_kernels::unite(&(v1071_19),&(v1071_22));
    map_map_kernels::compose(&(v1070_13),&(v1071_23))
  };
  drop(v1070_13);
  let v1070_26: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1070_10));
  drop(v1070_10);
  let v1070_27: Space = if map_kernels::has_head(&(v1070_26)) { singleton(&[]) } else { Space::new() };
  drop(v1070_26);
  let v1070_29: Space = if (&(v1070_27)).is_empty() { Space::new() } else {
    let mut v1076_28 = Space::new();
    let mut v1076_28_write = v1076_28.write_zipper();
    let mut v1076_28_cursor = (*s0).read_zipper();
    let v1076_28_origin = v1076_28_cursor.path().len();
    for v1076_28_byte in v1076_28_cursor.child_mask().iter() {
      v1076_28_cursor.descend_to_existing_byte(v1076_28_byte);
      {
      let v1077_2: Space = routine_154(c, &v1076_28_cursor.path()[v1076_28_origin..(v1076_28_origin + 1)], &v1076_28_cursor.path()[v1076_28_origin..(v1076_28_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v1076_28_cursor);
      join_wrapped_into(&mut v1076_28_write,&((v1077_2).read_zipper()),&[]);
      }
      v1076_28_cursor.ascend(1);
    }
    drop(v1076_28_cursor);
    drop(v1076_28_write);
    map_map_kernels::compose(&(v1070_27),&(v1076_28))
  };
  drop(v1070_27);
  let v1070_30: Space = map_map_kernels::unite(&(v1070_24),&(v1070_29));
  (v1070_30).clone()
}

fn routine_137(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v1078_9: Space = singleton(&(*p0));
  let v1078_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1078_9));
  let v1078_11: Space = if map_kernels::has_head(&(v1078_10)) { singleton(&[]) } else { Space::new() };
  drop(v1078_10);
  let v1078_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1078_11));
  drop(v1078_11);
  let v1078_17: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1078_9));
  drop(v1078_9);
  let v1078_18: Space = if map_kernels::has_head(&(v1078_17)) { singleton(&[]) } else { Space::new() };
  drop(v1078_17);
  let mut v1078_19 = Space::new();
  let mut v1078_19_write = v1078_19.write_zipper();
  let mut v1078_19_cursor = (*s0).read_zipper();
  let v1078_19_origin = v1078_19_cursor.path().len();
  for v1078_19_byte in v1078_19_cursor.child_mask().iter() {
    v1078_19_cursor.descend_to_existing_byte(v1078_19_byte);
    {
    let v1079_4: Space = if (&(v1078_12)).is_empty() { Space::new() } else {
      let v1080_2: Path = concat_path(&(*p1),&v1078_19_cursor.path()[v1078_19_origin..(v1078_19_origin + 1)]);
      let mut v1080_3 = Space::new();
      let mut v1080_3_write = v1080_3.write_zipper();
      let v1080_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1080_3_arg_1: &[u8] = &(v1080_2);
      let v1080_3_arg_2: &[u8] = &(*p2);
      let v1080_3_arg_3: &[u8] = &(*p3);
      let v1080_3_arg_4: &[u8] = &(*p4);
      let v1080_3_arg_5: &[u8] = &(*p5);
      let v1080_3_arg_7: &Space = &(&v1078_19_cursor).make_map();
      let mut v1080_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1080_3_origin = v1080_3_cursor.path().len();
      let mut v1080_3_more = v1080_3_cursor.is_val() || next_value_within(&mut v1080_3_cursor,v1080_3_origin);
      while v1080_3_more {
        {
        let v1080_3_depth = v1080_3_cursor.path().len();
        let v1081_8: Space = routine_137(c, &v1080_3_cursor.path()[v1080_3_origin..v1080_3_depth], &(*v1080_3_arg_1), &(*v1080_3_arg_2), &(*v1080_3_arg_3), &(*v1080_3_arg_4), &(*v1080_3_arg_5), &((*v1080_3_arg_7).read_zipper()));
        join_wrapped_into(&mut v1080_3_write,&((v1081_8).read_zipper()),&[]);
        }
        v1080_3_more = next_value_within(&mut v1080_3_cursor,v1080_3_origin);
      }
      drop(v1080_3_cursor);
      drop(v1080_3_write);
      map_map_kernels::compose(&(v1078_12),&(v1080_3))
    };
    let v1079_6: Space = if (&(v1078_18)).is_empty() { Space::new() } else {
      let v1082_2: Path = concat_path(&(*p1),&v1078_19_cursor.path()[v1078_19_origin..(v1078_19_origin + 1)]);
      let mut v1082_5 = Space::new();
      let mut v1082_5_write = v1082_5.write_zipper();
      for v1082_5_byte in v1078_19_cursor.child_mask().iter() {
        v1078_19_cursor.descend_to_existing_byte(v1082_5_byte);
        {
        let v1083_2: Space = routine_138(c, &v1078_19_cursor.path()[(v1078_19_origin + 1)..(v1078_19_origin + 2)], &v1078_19_cursor.path()[(v1078_19_origin + 1)..(v1078_19_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(v1082_2), &v1078_19_cursor);
        join_wrapped_into(&mut v1082_5_write,&((v1083_2).read_zipper()),&[]);
        }
        v1078_19_cursor.ascend(1);
      }
      drop(v1082_5_write);
      drop(v1082_2);
      map_map_kernels::compose(&(v1078_18),&(v1082_5))
    };
    let v1079_7: Space = map_map_kernels::unite(&(v1079_4),&(v1079_6));
    join_wrapped_into(&mut v1078_19_write,&((v1079_7).read_zipper()),&[]);
    }
    v1078_19_cursor.ascend(1);
  }
  drop(v1078_19_cursor);
  drop(v1078_19_write);
  drop(v1078_12);
  drop(v1078_18);
  (v1078_19).clone()
}

fn routine_138(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v1084_10: Space = singleton(&(*p1));
  let v1084_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1084_10));
  let v1084_12: Space = if map_kernels::has_head(&(v1084_11)) { singleton(&[]) } else { Space::new() };
  drop(v1084_11);
  let v1084_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1084_12));
  drop(v1084_12);
  let v1084_24: Space = if (&(v1084_13)).is_empty() { Space::new() } else {
    let v1085_16: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1085_19: Space = if (&(v1085_16)).is_empty() { Space::new() } else {
      let v1086_18: Space = routine_155(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*s0));
      map_map_kernels::compose(&(v1085_16),&(v1086_18))
    };
    drop(v1085_16);
    let mut v1085_22 = Space::new();
    let mut v1085_22_write = v1085_22.write_zipper();
    let mut v1085_22_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1085_22_origin = v1085_22_cursor.path().len();
    for v1085_22_byte in v1085_22_cursor.child_mask().iter() {
      v1085_22_cursor.descend_to_existing_byte(v1085_22_byte);
      {
      let v1087_2_arg_0: &[u8] = &v1085_22_cursor.path()[v1085_22_origin..(v1085_22_origin + 1)];
      let v1087_2_arg_1: &[u8] = &(*p0);
      let v1087_2_arg_2: &[u8] = &(*p2);
      let v1087_2_arg_3: &[u8] = &(*p3);
      let v1087_2_arg_4: &[u8] = &(*p4);
      let v1087_2_arg_5: &[u8] = &(*p5);
      let v1087_2_arg_6: &[u8] = &(*p6);
      let v1087_2_arg_8: &Space = &(&(*s0)).make_map();
      let mut v1087_2_more = v1085_22_cursor.is_val() || next_value_within(&mut v1085_22_cursor,(v1085_22_origin + 1));
      while v1087_2_more {
        {
        let v1087_2_depth = v1085_22_cursor.path().len();
        let mut v1088_9_cursor = (*v1087_2_arg_8).read_zipper();
        let v1088_9_origin = v1088_9_cursor.path().len();
        for v1088_9_byte in v1088_9_cursor.child_mask().iter() {
          v1088_9_cursor.descend_to_existing_byte(v1088_9_byte);
          {
          let v1089_2: Path = concat_path(&(*v1087_2_arg_1),&v1088_9_cursor.path()[v1088_9_origin..(v1088_9_origin + 1)]);
          let v1089_3: Space = routine_138(c, &(v1089_2), &v1085_22_cursor.path()[v1085_22_origin..v1087_2_depth], &(*v1087_2_arg_2), &(*v1087_2_arg_3), &(*v1087_2_arg_4), &(*v1087_2_arg_5), &(*v1087_2_arg_6), &v1088_9_cursor);
          drop(v1089_2);
          join_wrapped_into(&mut v1085_22_write,&((v1089_3).read_zipper()),&[]);
          }
          v1088_9_cursor.ascend(1);
        }
        drop(v1088_9_cursor);
        }
        v1087_2_more = next_value_within(&mut v1085_22_cursor,(v1085_22_origin + 1));
      }
      }
      v1085_22_cursor.ascend(1);
    }
    drop(v1085_22_cursor);
    drop(v1085_22_write);
    let v1085_23: Space = map_map_kernels::unite(&(v1085_19),&(v1085_22));
    map_map_kernels::compose(&(v1084_13),&(v1085_23))
  };
  drop(v1084_13);
  let v1084_26: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1084_10));
  drop(v1084_10);
  let v1084_27: Space = if map_kernels::has_head(&(v1084_26)) { singleton(&[]) } else { Space::new() };
  drop(v1084_26);
  let v1084_29: Space = if (&(v1084_27)).is_empty() { Space::new() } else {
    let mut v1090_28 = Space::new();
    let mut v1090_28_write = v1090_28.write_zipper();
    let mut v1090_28_cursor = (*s0).read_zipper();
    let v1090_28_origin = v1090_28_cursor.path().len();
    for v1090_28_byte in v1090_28_cursor.child_mask().iter() {
      v1090_28_cursor.descend_to_existing_byte(v1090_28_byte);
      {
      let v1091_2: Space = routine_156(c, &v1090_28_cursor.path()[v1090_28_origin..(v1090_28_origin + 1)], &v1090_28_cursor.path()[v1090_28_origin..(v1090_28_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v1090_28_cursor);
      join_wrapped_into(&mut v1090_28_write,&((v1091_2).read_zipper()),&[]);
      }
      v1090_28_cursor.ascend(1);
    }
    drop(v1090_28_cursor);
    drop(v1090_28_write);
    map_map_kernels::compose(&(v1084_27),&(v1090_28))
  };
  drop(v1084_27);
  let v1084_30: Space = map_map_kernels::unite(&(v1084_24),&(v1084_29));
  (v1084_30).clone()
}

fn routine_139(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v1092_9: Space = singleton(&(*p0));
  let v1092_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1092_9));
  let v1092_11: Space = if map_kernels::has_head(&(v1092_10)) { singleton(&[]) } else { Space::new() };
  drop(v1092_10);
  let v1092_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1092_11));
  drop(v1092_11);
  let v1092_17: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1092_9));
  drop(v1092_9);
  let v1092_18: Space = if map_kernels::has_head(&(v1092_17)) { singleton(&[]) } else { Space::new() };
  drop(v1092_17);
  let mut v1092_19 = Space::new();
  let mut v1092_19_write = v1092_19.write_zipper();
  let mut v1092_19_cursor = (*s0).read_zipper();
  let v1092_19_origin = v1092_19_cursor.path().len();
  for v1092_19_byte in v1092_19_cursor.child_mask().iter() {
    v1092_19_cursor.descend_to_existing_byte(v1092_19_byte);
    {
    let v1093_4: Space = if (&(v1092_12)).is_empty() { Space::new() } else {
      let v1094_2: Path = concat_path(&(*p1),&v1092_19_cursor.path()[v1092_19_origin..(v1092_19_origin + 1)]);
      let mut v1094_3 = Space::new();
      let mut v1094_3_write = v1094_3.write_zipper();
      let v1094_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1094_3_arg_1: &[u8] = &(v1094_2);
      let v1094_3_arg_2: &[u8] = &(*p2);
      let v1094_3_arg_3: &[u8] = &(*p3);
      let v1094_3_arg_4: &[u8] = &(*p4);
      let v1094_3_arg_5: &[u8] = &(*p5);
      let v1094_3_arg_7: &Space = &(&v1092_19_cursor).make_map();
      let mut v1094_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1094_3_origin = v1094_3_cursor.path().len();
      let mut v1094_3_more = v1094_3_cursor.is_val() || next_value_within(&mut v1094_3_cursor,v1094_3_origin);
      while v1094_3_more {
        {
        let v1094_3_depth = v1094_3_cursor.path().len();
        let v1095_8: Space = routine_139(c, &v1094_3_cursor.path()[v1094_3_origin..v1094_3_depth], &(*v1094_3_arg_1), &(*v1094_3_arg_2), &(*v1094_3_arg_3), &(*v1094_3_arg_4), &(*v1094_3_arg_5), &((*v1094_3_arg_7).read_zipper()));
        join_wrapped_into(&mut v1094_3_write,&((v1095_8).read_zipper()),&[]);
        }
        v1094_3_more = next_value_within(&mut v1094_3_cursor,v1094_3_origin);
      }
      drop(v1094_3_cursor);
      drop(v1094_3_write);
      map_map_kernels::compose(&(v1092_12),&(v1094_3))
    };
    let v1093_6: Space = if (&(v1092_18)).is_empty() { Space::new() } else {
      let v1096_2: Path = concat_path(&(*p1),&v1092_19_cursor.path()[v1092_19_origin..(v1092_19_origin + 1)]);
      let mut v1096_5 = Space::new();
      let mut v1096_5_write = v1096_5.write_zipper();
      for v1096_5_byte in v1092_19_cursor.child_mask().iter() {
        v1092_19_cursor.descend_to_existing_byte(v1096_5_byte);
        {
        let v1097_2: Space = routine_140(c, &v1092_19_cursor.path()[(v1092_19_origin + 1)..(v1092_19_origin + 2)], &v1092_19_cursor.path()[(v1092_19_origin + 1)..(v1092_19_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(v1096_2), &v1092_19_cursor);
        join_wrapped_into(&mut v1096_5_write,&((v1097_2).read_zipper()),&[]);
        }
        v1092_19_cursor.ascend(1);
      }
      drop(v1096_5_write);
      drop(v1096_2);
      map_map_kernels::compose(&(v1092_18),&(v1096_5))
    };
    let v1093_7: Space = map_map_kernels::unite(&(v1093_4),&(v1093_6));
    join_wrapped_into(&mut v1092_19_write,&((v1093_7).read_zipper()),&[]);
    }
    v1092_19_cursor.ascend(1);
  }
  drop(v1092_19_cursor);
  drop(v1092_19_write);
  drop(v1092_12);
  drop(v1092_18);
  (v1092_19).clone()
}

fn routine_140(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v1098_10: Space = singleton(&(*p1));
  let v1098_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1098_10));
  let v1098_12: Space = if map_kernels::has_head(&(v1098_11)) { singleton(&[]) } else { Space::new() };
  drop(v1098_11);
  let v1098_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1098_12));
  drop(v1098_12);
  let v1098_24: Space = if (&(v1098_13)).is_empty() { Space::new() } else {
    let v1099_16: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1099_19: Space = if (&(v1099_16)).is_empty() { Space::new() } else {
      let v1100_18: Space = routine_157(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*s0));
      map_map_kernels::compose(&(v1099_16),&(v1100_18))
    };
    drop(v1099_16);
    let mut v1099_22 = Space::new();
    let mut v1099_22_write = v1099_22.write_zipper();
    let mut v1099_22_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1099_22_origin = v1099_22_cursor.path().len();
    for v1099_22_byte in v1099_22_cursor.child_mask().iter() {
      v1099_22_cursor.descend_to_existing_byte(v1099_22_byte);
      {
      let v1101_2_arg_0: &[u8] = &v1099_22_cursor.path()[v1099_22_origin..(v1099_22_origin + 1)];
      let v1101_2_arg_1: &[u8] = &(*p0);
      let v1101_2_arg_2: &[u8] = &(*p2);
      let v1101_2_arg_3: &[u8] = &(*p3);
      let v1101_2_arg_4: &[u8] = &(*p4);
      let v1101_2_arg_5: &[u8] = &(*p5);
      let v1101_2_arg_6: &[u8] = &(*p6);
      let v1101_2_arg_8: &Space = &(&(*s0)).make_map();
      let mut v1101_2_more = v1099_22_cursor.is_val() || next_value_within(&mut v1099_22_cursor,(v1099_22_origin + 1));
      while v1101_2_more {
        {
        let v1101_2_depth = v1099_22_cursor.path().len();
        let mut v1102_9_cursor = (*v1101_2_arg_8).read_zipper();
        let v1102_9_origin = v1102_9_cursor.path().len();
        for v1102_9_byte in v1102_9_cursor.child_mask().iter() {
          v1102_9_cursor.descend_to_existing_byte(v1102_9_byte);
          {
          let v1103_2: Path = concat_path(&(*v1101_2_arg_1),&v1102_9_cursor.path()[v1102_9_origin..(v1102_9_origin + 1)]);
          let v1103_3: Space = routine_140(c, &(v1103_2), &v1099_22_cursor.path()[v1099_22_origin..v1101_2_depth], &(*v1101_2_arg_2), &(*v1101_2_arg_3), &(*v1101_2_arg_4), &(*v1101_2_arg_5), &(*v1101_2_arg_6), &v1102_9_cursor);
          drop(v1103_2);
          join_wrapped_into(&mut v1099_22_write,&((v1103_3).read_zipper()),&[]);
          }
          v1102_9_cursor.ascend(1);
        }
        drop(v1102_9_cursor);
        }
        v1101_2_more = next_value_within(&mut v1099_22_cursor,(v1099_22_origin + 1));
      }
      }
      v1099_22_cursor.ascend(1);
    }
    drop(v1099_22_cursor);
    drop(v1099_22_write);
    let v1099_23: Space = map_map_kernels::unite(&(v1099_19),&(v1099_22));
    map_map_kernels::compose(&(v1098_13),&(v1099_23))
  };
  drop(v1098_13);
  let v1098_26: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1098_10));
  drop(v1098_10);
  let v1098_27: Space = if map_kernels::has_head(&(v1098_26)) { singleton(&[]) } else { Space::new() };
  drop(v1098_26);
  let v1098_29: Space = if (&(v1098_27)).is_empty() { Space::new() } else {
    let mut v1104_28 = Space::new();
    let mut v1104_28_write = v1104_28.write_zipper();
    let mut v1104_28_cursor = (*s0).read_zipper();
    let v1104_28_origin = v1104_28_cursor.path().len();
    for v1104_28_byte in v1104_28_cursor.child_mask().iter() {
      v1104_28_cursor.descend_to_existing_byte(v1104_28_byte);
      {
      let v1105_2: Space = routine_158(c, &v1104_28_cursor.path()[v1104_28_origin..(v1104_28_origin + 1)], &v1104_28_cursor.path()[v1104_28_origin..(v1104_28_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v1104_28_cursor);
      join_wrapped_into(&mut v1104_28_write,&((v1105_2).read_zipper()),&[]);
      }
      v1104_28_cursor.ascend(1);
    }
    drop(v1104_28_cursor);
    drop(v1104_28_write);
    map_map_kernels::compose(&(v1098_27),&(v1104_28))
  };
  drop(v1098_27);
  let v1098_30: Space = map_map_kernels::unite(&(v1098_24),&(v1098_29));
  (v1098_30).clone()
}

fn routine_141(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v1106_9: Space = singleton(&(*p0));
  let v1106_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1106_9));
  let v1106_11: Space = if map_kernels::has_head(&(v1106_10)) { singleton(&[]) } else { Space::new() };
  drop(v1106_10);
  let v1106_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1106_11));
  drop(v1106_11);
  let v1106_17: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1106_9));
  drop(v1106_9);
  let v1106_18: Space = if map_kernels::has_head(&(v1106_17)) { singleton(&[]) } else { Space::new() };
  drop(v1106_17);
  let mut v1106_19 = Space::new();
  let mut v1106_19_write = v1106_19.write_zipper();
  let mut v1106_19_cursor = (*s0).read_zipper();
  let v1106_19_origin = v1106_19_cursor.path().len();
  for v1106_19_byte in v1106_19_cursor.child_mask().iter() {
    v1106_19_cursor.descend_to_existing_byte(v1106_19_byte);
    {
    let v1107_4: Space = if (&(v1106_12)).is_empty() { Space::new() } else {
      let v1108_2: Path = concat_path(&(*p1),&v1106_19_cursor.path()[v1106_19_origin..(v1106_19_origin + 1)]);
      let mut v1108_3 = Space::new();
      let mut v1108_3_write = v1108_3.write_zipper();
      let v1108_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1108_3_arg_1: &[u8] = &(v1108_2);
      let v1108_3_arg_2: &[u8] = &(*p2);
      let v1108_3_arg_3: &[u8] = &(*p3);
      let v1108_3_arg_4: &[u8] = &(*p4);
      let v1108_3_arg_5: &[u8] = &(*p5);
      let v1108_3_arg_7: &Space = &(&v1106_19_cursor).make_map();
      let mut v1108_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1108_3_origin = v1108_3_cursor.path().len();
      let mut v1108_3_more = v1108_3_cursor.is_val() || next_value_within(&mut v1108_3_cursor,v1108_3_origin);
      while v1108_3_more {
        {
        let v1108_3_depth = v1108_3_cursor.path().len();
        let v1109_8: Space = routine_141(c, &v1108_3_cursor.path()[v1108_3_origin..v1108_3_depth], &(*v1108_3_arg_1), &(*v1108_3_arg_2), &(*v1108_3_arg_3), &(*v1108_3_arg_4), &(*v1108_3_arg_5), &((*v1108_3_arg_7).read_zipper()));
        join_wrapped_into(&mut v1108_3_write,&((v1109_8).read_zipper()),&[]);
        }
        v1108_3_more = next_value_within(&mut v1108_3_cursor,v1108_3_origin);
      }
      drop(v1108_3_cursor);
      drop(v1108_3_write);
      map_map_kernels::compose(&(v1106_12),&(v1108_3))
    };
    let v1107_6: Space = if (&(v1106_18)).is_empty() { Space::new() } else {
      let v1110_2: Path = concat_path(&(*p1),&v1106_19_cursor.path()[v1106_19_origin..(v1106_19_origin + 1)]);
      let mut v1110_5 = Space::new();
      let mut v1110_5_write = v1110_5.write_zipper();
      for v1110_5_byte in v1106_19_cursor.child_mask().iter() {
        v1106_19_cursor.descend_to_existing_byte(v1110_5_byte);
        {
        let v1111_2: Space = routine_142(c, &v1106_19_cursor.path()[(v1106_19_origin + 1)..(v1106_19_origin + 2)], &v1106_19_cursor.path()[(v1106_19_origin + 1)..(v1106_19_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(v1110_2), &v1106_19_cursor);
        join_wrapped_into(&mut v1110_5_write,&((v1111_2).read_zipper()),&[]);
        }
        v1106_19_cursor.ascend(1);
      }
      drop(v1110_5_write);
      drop(v1110_2);
      map_map_kernels::compose(&(v1106_18),&(v1110_5))
    };
    let v1107_7: Space = map_map_kernels::unite(&(v1107_4),&(v1107_6));
    join_wrapped_into(&mut v1106_19_write,&((v1107_7).read_zipper()),&[]);
    }
    v1106_19_cursor.ascend(1);
  }
  drop(v1106_19_cursor);
  drop(v1106_19_write);
  drop(v1106_12);
  drop(v1106_18);
  (v1106_19).clone()
}

fn routine_142(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v1112_10: Space = singleton(&(*p1));
  let v1112_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1112_10));
  let v1112_12: Space = if map_kernels::has_head(&(v1112_11)) { singleton(&[]) } else { Space::new() };
  drop(v1112_11);
  let v1112_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1112_12));
  drop(v1112_12);
  let v1112_24: Space = if (&(v1112_13)).is_empty() { Space::new() } else {
    let v1113_16: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1113_19: Space = if (&(v1113_16)).is_empty() { Space::new() } else {
      let v1114_18: Space = routine_159(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*s0));
      map_map_kernels::compose(&(v1113_16),&(v1114_18))
    };
    drop(v1113_16);
    let mut v1113_22 = Space::new();
    let mut v1113_22_write = v1113_22.write_zipper();
    let mut v1113_22_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1113_22_origin = v1113_22_cursor.path().len();
    for v1113_22_byte in v1113_22_cursor.child_mask().iter() {
      v1113_22_cursor.descend_to_existing_byte(v1113_22_byte);
      {
      let v1115_2_arg_0: &[u8] = &v1113_22_cursor.path()[v1113_22_origin..(v1113_22_origin + 1)];
      let v1115_2_arg_1: &[u8] = &(*p0);
      let v1115_2_arg_2: &[u8] = &(*p2);
      let v1115_2_arg_3: &[u8] = &(*p3);
      let v1115_2_arg_4: &[u8] = &(*p4);
      let v1115_2_arg_5: &[u8] = &(*p5);
      let v1115_2_arg_6: &[u8] = &(*p6);
      let v1115_2_arg_8: &Space = &(&(*s0)).make_map();
      let mut v1115_2_more = v1113_22_cursor.is_val() || next_value_within(&mut v1113_22_cursor,(v1113_22_origin + 1));
      while v1115_2_more {
        {
        let v1115_2_depth = v1113_22_cursor.path().len();
        let mut v1116_9_cursor = (*v1115_2_arg_8).read_zipper();
        let v1116_9_origin = v1116_9_cursor.path().len();
        for v1116_9_byte in v1116_9_cursor.child_mask().iter() {
          v1116_9_cursor.descend_to_existing_byte(v1116_9_byte);
          {
          let v1117_2: Path = concat_path(&(*v1115_2_arg_1),&v1116_9_cursor.path()[v1116_9_origin..(v1116_9_origin + 1)]);
          let v1117_3: Space = routine_142(c, &(v1117_2), &v1113_22_cursor.path()[v1113_22_origin..v1115_2_depth], &(*v1115_2_arg_2), &(*v1115_2_arg_3), &(*v1115_2_arg_4), &(*v1115_2_arg_5), &(*v1115_2_arg_6), &v1116_9_cursor);
          drop(v1117_2);
          join_wrapped_into(&mut v1113_22_write,&((v1117_3).read_zipper()),&[]);
          }
          v1116_9_cursor.ascend(1);
        }
        drop(v1116_9_cursor);
        }
        v1115_2_more = next_value_within(&mut v1113_22_cursor,(v1113_22_origin + 1));
      }
      }
      v1113_22_cursor.ascend(1);
    }
    drop(v1113_22_cursor);
    drop(v1113_22_write);
    let v1113_23: Space = map_map_kernels::unite(&(v1113_19),&(v1113_22));
    map_map_kernels::compose(&(v1112_13),&(v1113_23))
  };
  drop(v1112_13);
  let v1112_26: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1112_10));
  drop(v1112_10);
  let v1112_27: Space = if map_kernels::has_head(&(v1112_26)) { singleton(&[]) } else { Space::new() };
  drop(v1112_26);
  let v1112_29: Space = if (&(v1112_27)).is_empty() { Space::new() } else {
    let mut v1118_28 = Space::new();
    let mut v1118_28_write = v1118_28.write_zipper();
    let mut v1118_28_cursor = (*s0).read_zipper();
    let v1118_28_origin = v1118_28_cursor.path().len();
    for v1118_28_byte in v1118_28_cursor.child_mask().iter() {
      v1118_28_cursor.descend_to_existing_byte(v1118_28_byte);
      {
      let v1119_2: Space = routine_160(c, &v1118_28_cursor.path()[v1118_28_origin..(v1118_28_origin + 1)], &v1118_28_cursor.path()[v1118_28_origin..(v1118_28_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v1118_28_cursor);
      join_wrapped_into(&mut v1118_28_write,&((v1119_2).read_zipper()),&[]);
      }
      v1118_28_cursor.ascend(1);
    }
    drop(v1118_28_cursor);
    drop(v1118_28_write);
    map_map_kernels::compose(&(v1112_27),&(v1118_28))
  };
  drop(v1112_27);
  let v1112_30: Space = map_map_kernels::unite(&(v1112_24),&(v1112_29));
  (v1112_30).clone()
}

fn routine_143(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v1120_9: Space = singleton(&(*p0));
  let v1120_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1120_9));
  let v1120_11: Space = if map_kernels::has_head(&(v1120_10)) { singleton(&[]) } else { Space::new() };
  drop(v1120_10);
  let v1120_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1120_11));
  drop(v1120_11);
  let v1120_17: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1120_9));
  drop(v1120_9);
  let v1120_18: Space = if map_kernels::has_head(&(v1120_17)) { singleton(&[]) } else { Space::new() };
  drop(v1120_17);
  let mut v1120_19 = Space::new();
  let mut v1120_19_write = v1120_19.write_zipper();
  let mut v1120_19_cursor = (*s0).read_zipper();
  let v1120_19_origin = v1120_19_cursor.path().len();
  for v1120_19_byte in v1120_19_cursor.child_mask().iter() {
    v1120_19_cursor.descend_to_existing_byte(v1120_19_byte);
    {
    let v1121_4: Space = if (&(v1120_12)).is_empty() { Space::new() } else {
      let v1122_2: Path = concat_path(&(*p1),&v1120_19_cursor.path()[v1120_19_origin..(v1120_19_origin + 1)]);
      let mut v1122_3 = Space::new();
      let mut v1122_3_write = v1122_3.write_zipper();
      let v1122_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1122_3_arg_1: &[u8] = &(v1122_2);
      let v1122_3_arg_2: &[u8] = &(*p2);
      let v1122_3_arg_3: &[u8] = &(*p3);
      let v1122_3_arg_4: &[u8] = &(*p4);
      let v1122_3_arg_5: &[u8] = &(*p5);
      let v1122_3_arg_7: &Space = &(&v1120_19_cursor).make_map();
      let mut v1122_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1122_3_origin = v1122_3_cursor.path().len();
      let mut v1122_3_more = v1122_3_cursor.is_val() || next_value_within(&mut v1122_3_cursor,v1122_3_origin);
      while v1122_3_more {
        {
        let v1122_3_depth = v1122_3_cursor.path().len();
        let v1123_8: Space = routine_143(c, &v1122_3_cursor.path()[v1122_3_origin..v1122_3_depth], &(*v1122_3_arg_1), &(*v1122_3_arg_2), &(*v1122_3_arg_3), &(*v1122_3_arg_4), &(*v1122_3_arg_5), &((*v1122_3_arg_7).read_zipper()));
        join_wrapped_into(&mut v1122_3_write,&((v1123_8).read_zipper()),&[]);
        }
        v1122_3_more = next_value_within(&mut v1122_3_cursor,v1122_3_origin);
      }
      drop(v1122_3_cursor);
      drop(v1122_3_write);
      map_map_kernels::compose(&(v1120_12),&(v1122_3))
    };
    let v1121_6: Space = if (&(v1120_18)).is_empty() { Space::new() } else {
      let v1124_2: Path = concat_path(&(*p1),&v1120_19_cursor.path()[v1120_19_origin..(v1120_19_origin + 1)]);
      let mut v1124_5 = Space::new();
      let mut v1124_5_write = v1124_5.write_zipper();
      for v1124_5_byte in v1120_19_cursor.child_mask().iter() {
        v1120_19_cursor.descend_to_existing_byte(v1124_5_byte);
        {
        let v1125_2: Space = routine_144(c, &v1120_19_cursor.path()[(v1120_19_origin + 1)..(v1120_19_origin + 2)], &v1120_19_cursor.path()[(v1120_19_origin + 1)..(v1120_19_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(v1124_2), &v1120_19_cursor);
        join_wrapped_into(&mut v1124_5_write,&((v1125_2).read_zipper()),&[]);
        }
        v1120_19_cursor.ascend(1);
      }
      drop(v1124_5_write);
      drop(v1124_2);
      map_map_kernels::compose(&(v1120_18),&(v1124_5))
    };
    let v1121_7: Space = map_map_kernels::unite(&(v1121_4),&(v1121_6));
    join_wrapped_into(&mut v1120_19_write,&((v1121_7).read_zipper()),&[]);
    }
    v1120_19_cursor.ascend(1);
  }
  drop(v1120_19_cursor);
  drop(v1120_19_write);
  drop(v1120_12);
  drop(v1120_18);
  (v1120_19).clone()
}

fn routine_144(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v1126_10: Space = singleton(&(*p1));
  let v1126_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1126_10));
  let v1126_12: Space = if map_kernels::has_head(&(v1126_11)) { singleton(&[]) } else { Space::new() };
  drop(v1126_11);
  let v1126_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1126_12));
  drop(v1126_12);
  let v1126_24: Space = if (&(v1126_13)).is_empty() { Space::new() } else {
    let v1127_16: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1127_19: Space = if (&(v1127_16)).is_empty() { Space::new() } else {
      let v1128_18: Space = routine_161(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*s0));
      map_map_kernels::compose(&(v1127_16),&(v1128_18))
    };
    drop(v1127_16);
    let mut v1127_22 = Space::new();
    let mut v1127_22_write = v1127_22.write_zipper();
    let mut v1127_22_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1127_22_origin = v1127_22_cursor.path().len();
    for v1127_22_byte in v1127_22_cursor.child_mask().iter() {
      v1127_22_cursor.descend_to_existing_byte(v1127_22_byte);
      {
      let v1129_2_arg_0: &[u8] = &v1127_22_cursor.path()[v1127_22_origin..(v1127_22_origin + 1)];
      let v1129_2_arg_1: &[u8] = &(*p0);
      let v1129_2_arg_2: &[u8] = &(*p2);
      let v1129_2_arg_3: &[u8] = &(*p3);
      let v1129_2_arg_4: &[u8] = &(*p4);
      let v1129_2_arg_5: &[u8] = &(*p5);
      let v1129_2_arg_6: &[u8] = &(*p6);
      let v1129_2_arg_8: &Space = &(&(*s0)).make_map();
      let mut v1129_2_more = v1127_22_cursor.is_val() || next_value_within(&mut v1127_22_cursor,(v1127_22_origin + 1));
      while v1129_2_more {
        {
        let v1129_2_depth = v1127_22_cursor.path().len();
        let mut v1130_9_cursor = (*v1129_2_arg_8).read_zipper();
        let v1130_9_origin = v1130_9_cursor.path().len();
        for v1130_9_byte in v1130_9_cursor.child_mask().iter() {
          v1130_9_cursor.descend_to_existing_byte(v1130_9_byte);
          {
          let v1131_2: Path = concat_path(&(*v1129_2_arg_1),&v1130_9_cursor.path()[v1130_9_origin..(v1130_9_origin + 1)]);
          let v1131_3: Space = routine_144(c, &(v1131_2), &v1127_22_cursor.path()[v1127_22_origin..v1129_2_depth], &(*v1129_2_arg_2), &(*v1129_2_arg_3), &(*v1129_2_arg_4), &(*v1129_2_arg_5), &(*v1129_2_arg_6), &v1130_9_cursor);
          drop(v1131_2);
          join_wrapped_into(&mut v1127_22_write,&((v1131_3).read_zipper()),&[]);
          }
          v1130_9_cursor.ascend(1);
        }
        drop(v1130_9_cursor);
        }
        v1129_2_more = next_value_within(&mut v1127_22_cursor,(v1127_22_origin + 1));
      }
      }
      v1127_22_cursor.ascend(1);
    }
    drop(v1127_22_cursor);
    drop(v1127_22_write);
    let v1127_23: Space = map_map_kernels::unite(&(v1127_19),&(v1127_22));
    map_map_kernels::compose(&(v1126_13),&(v1127_23))
  };
  drop(v1126_13);
  let v1126_26: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1126_10));
  drop(v1126_10);
  let v1126_27: Space = if map_kernels::has_head(&(v1126_26)) { singleton(&[]) } else { Space::new() };
  drop(v1126_26);
  let v1126_29: Space = if (&(v1126_27)).is_empty() { Space::new() } else {
    let mut v1132_28 = Space::new();
    let mut v1132_28_write = v1132_28.write_zipper();
    let mut v1132_28_cursor = (*s0).read_zipper();
    let v1132_28_origin = v1132_28_cursor.path().len();
    for v1132_28_byte in v1132_28_cursor.child_mask().iter() {
      v1132_28_cursor.descend_to_existing_byte(v1132_28_byte);
      {
      let v1133_2: Space = routine_162(c, &v1132_28_cursor.path()[v1132_28_origin..(v1132_28_origin + 1)], &v1132_28_cursor.path()[v1132_28_origin..(v1132_28_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v1132_28_cursor);
      join_wrapped_into(&mut v1132_28_write,&((v1133_2).read_zipper()),&[]);
      }
      v1132_28_cursor.ascend(1);
    }
    drop(v1132_28_cursor);
    drop(v1132_28_write);
    map_map_kernels::compose(&(v1126_27),&(v1132_28))
  };
  drop(v1126_27);
  let v1126_30: Space = map_map_kernels::unite(&(v1126_24),&(v1126_29));
  (v1126_30).clone()
}

fn routine_145(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v1134_9: Space = singleton(&(*p0));
  let v1134_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1134_9));
  let v1134_11: Space = if map_kernels::has_head(&(v1134_10)) { singleton(&[]) } else { Space::new() };
  drop(v1134_10);
  let v1134_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1134_11));
  drop(v1134_11);
  let v1134_17: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1134_9));
  drop(v1134_9);
  let v1134_18: Space = if map_kernels::has_head(&(v1134_17)) { singleton(&[]) } else { Space::new() };
  drop(v1134_17);
  let mut v1134_19 = Space::new();
  let mut v1134_19_write = v1134_19.write_zipper();
  let mut v1134_19_cursor = (*s0).read_zipper();
  let v1134_19_origin = v1134_19_cursor.path().len();
  for v1134_19_byte in v1134_19_cursor.child_mask().iter() {
    v1134_19_cursor.descend_to_existing_byte(v1134_19_byte);
    {
    let v1135_4: Space = if (&(v1134_12)).is_empty() { Space::new() } else {
      let v1136_2: Path = concat_path(&(*p1),&v1134_19_cursor.path()[v1134_19_origin..(v1134_19_origin + 1)]);
      let mut v1136_3 = Space::new();
      let mut v1136_3_write = v1136_3.write_zipper();
      let v1136_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1136_3_arg_1: &[u8] = &(v1136_2);
      let v1136_3_arg_2: &[u8] = &(*p2);
      let v1136_3_arg_3: &[u8] = &(*p3);
      let v1136_3_arg_4: &[u8] = &(*p4);
      let v1136_3_arg_5: &[u8] = &(*p5);
      let v1136_3_arg_7: &Space = &(&v1134_19_cursor).make_map();
      let mut v1136_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1136_3_origin = v1136_3_cursor.path().len();
      let mut v1136_3_more = v1136_3_cursor.is_val() || next_value_within(&mut v1136_3_cursor,v1136_3_origin);
      while v1136_3_more {
        {
        let v1136_3_depth = v1136_3_cursor.path().len();
        let v1137_8: Space = routine_145(c, &v1136_3_cursor.path()[v1136_3_origin..v1136_3_depth], &(*v1136_3_arg_1), &(*v1136_3_arg_2), &(*v1136_3_arg_3), &(*v1136_3_arg_4), &(*v1136_3_arg_5), &((*v1136_3_arg_7).read_zipper()));
        join_wrapped_into(&mut v1136_3_write,&((v1137_8).read_zipper()),&[]);
        }
        v1136_3_more = next_value_within(&mut v1136_3_cursor,v1136_3_origin);
      }
      drop(v1136_3_cursor);
      drop(v1136_3_write);
      map_map_kernels::compose(&(v1134_12),&(v1136_3))
    };
    let v1135_6: Space = if (&(v1134_18)).is_empty() { Space::new() } else {
      let v1138_2: Path = concat_path(&(*p1),&v1134_19_cursor.path()[v1134_19_origin..(v1134_19_origin + 1)]);
      let mut v1138_5 = Space::new();
      let mut v1138_5_write = v1138_5.write_zipper();
      for v1138_5_byte in v1134_19_cursor.child_mask().iter() {
        v1134_19_cursor.descend_to_existing_byte(v1138_5_byte);
        {
        let v1139_2: Space = routine_146(c, &v1134_19_cursor.path()[(v1134_19_origin + 1)..(v1134_19_origin + 2)], &v1134_19_cursor.path()[(v1134_19_origin + 1)..(v1134_19_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(v1138_2), &v1134_19_cursor);
        join_wrapped_into(&mut v1138_5_write,&((v1139_2).read_zipper()),&[]);
        }
        v1134_19_cursor.ascend(1);
      }
      drop(v1138_5_write);
      drop(v1138_2);
      map_map_kernels::compose(&(v1134_18),&(v1138_5))
    };
    let v1135_7: Space = map_map_kernels::unite(&(v1135_4),&(v1135_6));
    join_wrapped_into(&mut v1134_19_write,&((v1135_7).read_zipper()),&[]);
    }
    v1134_19_cursor.ascend(1);
  }
  drop(v1134_19_cursor);
  drop(v1134_19_write);
  drop(v1134_12);
  drop(v1134_18);
  (v1134_19).clone()
}

fn routine_146(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v1140_10: Space = singleton(&(*p1));
  let v1140_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1140_10));
  let v1140_12: Space = if map_kernels::has_head(&(v1140_11)) { singleton(&[]) } else { Space::new() };
  drop(v1140_11);
  let v1140_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1140_12));
  drop(v1140_12);
  let v1140_24: Space = if (&(v1140_13)).is_empty() { Space::new() } else {
    let v1141_16: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1141_19: Space = if (&(v1141_16)).is_empty() { Space::new() } else {
      let v1142_18: Space = routine_163(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*s0));
      map_map_kernels::compose(&(v1141_16),&(v1142_18))
    };
    drop(v1141_16);
    let mut v1141_22 = Space::new();
    let mut v1141_22_write = v1141_22.write_zipper();
    let mut v1141_22_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1141_22_origin = v1141_22_cursor.path().len();
    for v1141_22_byte in v1141_22_cursor.child_mask().iter() {
      v1141_22_cursor.descend_to_existing_byte(v1141_22_byte);
      {
      let v1143_2_arg_0: &[u8] = &v1141_22_cursor.path()[v1141_22_origin..(v1141_22_origin + 1)];
      let v1143_2_arg_1: &[u8] = &(*p0);
      let v1143_2_arg_2: &[u8] = &(*p2);
      let v1143_2_arg_3: &[u8] = &(*p3);
      let v1143_2_arg_4: &[u8] = &(*p4);
      let v1143_2_arg_5: &[u8] = &(*p5);
      let v1143_2_arg_6: &[u8] = &(*p6);
      let v1143_2_arg_8: &Space = &(&(*s0)).make_map();
      let mut v1143_2_more = v1141_22_cursor.is_val() || next_value_within(&mut v1141_22_cursor,(v1141_22_origin + 1));
      while v1143_2_more {
        {
        let v1143_2_depth = v1141_22_cursor.path().len();
        let mut v1144_9_cursor = (*v1143_2_arg_8).read_zipper();
        let v1144_9_origin = v1144_9_cursor.path().len();
        for v1144_9_byte in v1144_9_cursor.child_mask().iter() {
          v1144_9_cursor.descend_to_existing_byte(v1144_9_byte);
          {
          let v1145_2: Path = concat_path(&(*v1143_2_arg_1),&v1144_9_cursor.path()[v1144_9_origin..(v1144_9_origin + 1)]);
          let v1145_3: Space = routine_146(c, &(v1145_2), &v1141_22_cursor.path()[v1141_22_origin..v1143_2_depth], &(*v1143_2_arg_2), &(*v1143_2_arg_3), &(*v1143_2_arg_4), &(*v1143_2_arg_5), &(*v1143_2_arg_6), &v1144_9_cursor);
          drop(v1145_2);
          join_wrapped_into(&mut v1141_22_write,&((v1145_3).read_zipper()),&[]);
          }
          v1144_9_cursor.ascend(1);
        }
        drop(v1144_9_cursor);
        }
        v1143_2_more = next_value_within(&mut v1141_22_cursor,(v1141_22_origin + 1));
      }
      }
      v1141_22_cursor.ascend(1);
    }
    drop(v1141_22_cursor);
    drop(v1141_22_write);
    let v1141_23: Space = map_map_kernels::unite(&(v1141_19),&(v1141_22));
    map_map_kernels::compose(&(v1140_13),&(v1141_23))
  };
  drop(v1140_13);
  let v1140_26: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1140_10));
  drop(v1140_10);
  let v1140_27: Space = if map_kernels::has_head(&(v1140_26)) { singleton(&[]) } else { Space::new() };
  drop(v1140_26);
  let v1140_29: Space = if (&(v1140_27)).is_empty() { Space::new() } else {
    let mut v1146_28 = Space::new();
    let mut v1146_28_write = v1146_28.write_zipper();
    let mut v1146_28_cursor = (*s0).read_zipper();
    let v1146_28_origin = v1146_28_cursor.path().len();
    for v1146_28_byte in v1146_28_cursor.child_mask().iter() {
      v1146_28_cursor.descend_to_existing_byte(v1146_28_byte);
      {
      let v1147_2: Space = routine_164(c, &v1146_28_cursor.path()[v1146_28_origin..(v1146_28_origin + 1)], &v1146_28_cursor.path()[v1146_28_origin..(v1146_28_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v1146_28_cursor);
      join_wrapped_into(&mut v1146_28_write,&((v1147_2).read_zipper()),&[]);
      }
      v1146_28_cursor.ascend(1);
    }
    drop(v1146_28_cursor);
    drop(v1146_28_write);
    map_map_kernels::compose(&(v1140_27),&(v1146_28))
  };
  drop(v1140_27);
  let v1140_30: Space = map_map_kernels::unite(&(v1140_24),&(v1140_29));
  (v1140_30).clone()
}

fn routine_147(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v1148_9: Space = singleton(&(*p0));
  let v1148_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1148_9));
  let v1148_11: Space = if map_kernels::has_head(&(v1148_10)) { singleton(&[]) } else { Space::new() };
  drop(v1148_10);
  let v1148_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1148_11));
  drop(v1148_11);
  let v1148_17: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1148_9));
  drop(v1148_9);
  let v1148_18: Space = if map_kernels::has_head(&(v1148_17)) { singleton(&[]) } else { Space::new() };
  drop(v1148_17);
  let mut v1148_19 = Space::new();
  let mut v1148_19_write = v1148_19.write_zipper();
  let mut v1148_19_cursor = (*s0).read_zipper();
  let v1148_19_origin = v1148_19_cursor.path().len();
  for v1148_19_byte in v1148_19_cursor.child_mask().iter() {
    v1148_19_cursor.descend_to_existing_byte(v1148_19_byte);
    {
    let v1149_4: Space = if (&(v1148_12)).is_empty() { Space::new() } else {
      let v1150_2: Path = concat_path(&(*p1),&v1148_19_cursor.path()[v1148_19_origin..(v1148_19_origin + 1)]);
      let mut v1150_3 = Space::new();
      let mut v1150_3_write = v1150_3.write_zipper();
      let v1150_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1150_3_arg_1: &[u8] = &(v1150_2);
      let v1150_3_arg_2: &[u8] = &(*p2);
      let v1150_3_arg_3: &[u8] = &(*p3);
      let v1150_3_arg_4: &[u8] = &(*p4);
      let v1150_3_arg_5: &[u8] = &(*p5);
      let v1150_3_arg_7: &Space = &(&v1148_19_cursor).make_map();
      let mut v1150_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1150_3_origin = v1150_3_cursor.path().len();
      let mut v1150_3_more = v1150_3_cursor.is_val() || next_value_within(&mut v1150_3_cursor,v1150_3_origin);
      while v1150_3_more {
        {
        let v1150_3_depth = v1150_3_cursor.path().len();
        let v1151_8: Space = routine_147(c, &v1150_3_cursor.path()[v1150_3_origin..v1150_3_depth], &(*v1150_3_arg_1), &(*v1150_3_arg_2), &(*v1150_3_arg_3), &(*v1150_3_arg_4), &(*v1150_3_arg_5), &((*v1150_3_arg_7).read_zipper()));
        join_wrapped_into(&mut v1150_3_write,&((v1151_8).read_zipper()),&[]);
        }
        v1150_3_more = next_value_within(&mut v1150_3_cursor,v1150_3_origin);
      }
      drop(v1150_3_cursor);
      drop(v1150_3_write);
      map_map_kernels::compose(&(v1148_12),&(v1150_3))
    };
    let v1149_6: Space = if (&(v1148_18)).is_empty() { Space::new() } else {
      let v1152_2: Path = concat_path(&(*p1),&v1148_19_cursor.path()[v1148_19_origin..(v1148_19_origin + 1)]);
      let mut v1152_5 = Space::new();
      let mut v1152_5_write = v1152_5.write_zipper();
      for v1152_5_byte in v1148_19_cursor.child_mask().iter() {
        v1148_19_cursor.descend_to_existing_byte(v1152_5_byte);
        {
        let v1153_2: Space = routine_148(c, &v1148_19_cursor.path()[(v1148_19_origin + 1)..(v1148_19_origin + 2)], &v1148_19_cursor.path()[(v1148_19_origin + 1)..(v1148_19_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(v1152_2), &v1148_19_cursor);
        join_wrapped_into(&mut v1152_5_write,&((v1153_2).read_zipper()),&[]);
        }
        v1148_19_cursor.ascend(1);
      }
      drop(v1152_5_write);
      drop(v1152_2);
      map_map_kernels::compose(&(v1148_18),&(v1152_5))
    };
    let v1149_7: Space = map_map_kernels::unite(&(v1149_4),&(v1149_6));
    join_wrapped_into(&mut v1148_19_write,&((v1149_7).read_zipper()),&[]);
    }
    v1148_19_cursor.ascend(1);
  }
  drop(v1148_19_cursor);
  drop(v1148_19_write);
  drop(v1148_12);
  drop(v1148_18);
  (v1148_19).clone()
}

fn routine_148(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v1154_10: Space = singleton(&(*p1));
  let v1154_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1154_10));
  let v1154_12: Space = if map_kernels::has_head(&(v1154_11)) { singleton(&[]) } else { Space::new() };
  drop(v1154_11);
  let v1154_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1154_12));
  drop(v1154_12);
  let v1154_24: Space = if (&(v1154_13)).is_empty() { Space::new() } else {
    let v1155_16: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1155_19: Space = if (&(v1155_16)).is_empty() { Space::new() } else {
      let v1156_18: Space = routine_165(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*s0));
      map_map_kernels::compose(&(v1155_16),&(v1156_18))
    };
    drop(v1155_16);
    let mut v1155_22 = Space::new();
    let mut v1155_22_write = v1155_22.write_zipper();
    let mut v1155_22_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1155_22_origin = v1155_22_cursor.path().len();
    for v1155_22_byte in v1155_22_cursor.child_mask().iter() {
      v1155_22_cursor.descend_to_existing_byte(v1155_22_byte);
      {
      let v1157_2_arg_0: &[u8] = &v1155_22_cursor.path()[v1155_22_origin..(v1155_22_origin + 1)];
      let v1157_2_arg_1: &[u8] = &(*p0);
      let v1157_2_arg_2: &[u8] = &(*p2);
      let v1157_2_arg_3: &[u8] = &(*p3);
      let v1157_2_arg_4: &[u8] = &(*p4);
      let v1157_2_arg_5: &[u8] = &(*p5);
      let v1157_2_arg_6: &[u8] = &(*p6);
      let v1157_2_arg_8: &Space = &(&(*s0)).make_map();
      let mut v1157_2_more = v1155_22_cursor.is_val() || next_value_within(&mut v1155_22_cursor,(v1155_22_origin + 1));
      while v1157_2_more {
        {
        let v1157_2_depth = v1155_22_cursor.path().len();
        let mut v1158_9_cursor = (*v1157_2_arg_8).read_zipper();
        let v1158_9_origin = v1158_9_cursor.path().len();
        for v1158_9_byte in v1158_9_cursor.child_mask().iter() {
          v1158_9_cursor.descend_to_existing_byte(v1158_9_byte);
          {
          let v1159_2: Path = concat_path(&(*v1157_2_arg_1),&v1158_9_cursor.path()[v1158_9_origin..(v1158_9_origin + 1)]);
          let v1159_3: Space = routine_148(c, &(v1159_2), &v1155_22_cursor.path()[v1155_22_origin..v1157_2_depth], &(*v1157_2_arg_2), &(*v1157_2_arg_3), &(*v1157_2_arg_4), &(*v1157_2_arg_5), &(*v1157_2_arg_6), &v1158_9_cursor);
          drop(v1159_2);
          join_wrapped_into(&mut v1155_22_write,&((v1159_3).read_zipper()),&[]);
          }
          v1158_9_cursor.ascend(1);
        }
        drop(v1158_9_cursor);
        }
        v1157_2_more = next_value_within(&mut v1155_22_cursor,(v1155_22_origin + 1));
      }
      }
      v1155_22_cursor.ascend(1);
    }
    drop(v1155_22_cursor);
    drop(v1155_22_write);
    let v1155_23: Space = map_map_kernels::unite(&(v1155_19),&(v1155_22));
    map_map_kernels::compose(&(v1154_13),&(v1155_23))
  };
  drop(v1154_13);
  let v1154_26: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1154_10));
  drop(v1154_10);
  let v1154_27: Space = if map_kernels::has_head(&(v1154_26)) { singleton(&[]) } else { Space::new() };
  drop(v1154_26);
  let v1154_29: Space = if (&(v1154_27)).is_empty() { Space::new() } else {
    let mut v1160_28 = Space::new();
    let mut v1160_28_write = v1160_28.write_zipper();
    let mut v1160_28_cursor = (*s0).read_zipper();
    let v1160_28_origin = v1160_28_cursor.path().len();
    for v1160_28_byte in v1160_28_cursor.child_mask().iter() {
      v1160_28_cursor.descend_to_existing_byte(v1160_28_byte);
      {
      let v1161_2: Space = routine_166(c, &v1160_28_cursor.path()[v1160_28_origin..(v1160_28_origin + 1)], &v1160_28_cursor.path()[v1160_28_origin..(v1160_28_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v1160_28_cursor);
      join_wrapped_into(&mut v1160_28_write,&((v1161_2).read_zipper()),&[]);
      }
      v1160_28_cursor.ascend(1);
    }
    drop(v1160_28_cursor);
    drop(v1160_28_write);
    map_map_kernels::compose(&(v1154_27),&(v1160_28))
  };
  drop(v1154_27);
  let v1154_30: Space = map_map_kernels::unite(&(v1154_24),&(v1154_29));
  (v1154_30).clone()
}

fn routine_149(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v1162_9: Space = singleton(&(*p0));
  let v1162_10: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1162_9));
  let v1162_11: Space = if map_kernels::has_head(&(v1162_10)) { singleton(&[]) } else { Space::new() };
  drop(v1162_10);
  let v1162_12: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1162_11));
  drop(v1162_11);
  let v1162_17: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1162_9));
  drop(v1162_9);
  let v1162_18: Space = if map_kernels::has_head(&(v1162_17)) { singleton(&[]) } else { Space::new() };
  drop(v1162_17);
  let mut v1162_19 = Space::new();
  let mut v1162_19_write = v1162_19.write_zipper();
  let mut v1162_19_cursor = (*s0).read_zipper();
  let v1162_19_origin = v1162_19_cursor.path().len();
  for v1162_19_byte in v1162_19_cursor.child_mask().iter() {
    v1162_19_cursor.descend_to_existing_byte(v1162_19_byte);
    {
    let v1163_4: Space = if (&(v1162_12)).is_empty() { Space::new() } else {
      let v1164_2: Path = concat_path(&(*p1),&v1162_19_cursor.path()[v1162_19_origin..(v1162_19_origin + 1)]);
      let mut v1164_3 = Space::new();
      let mut v1164_3_write = v1164_3.write_zipper();
      let v1164_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1164_3_arg_1: &[u8] = &(v1164_2);
      let v1164_3_arg_2: &[u8] = &(*p2);
      let v1164_3_arg_3: &[u8] = &(*p3);
      let v1164_3_arg_4: &[u8] = &(*p4);
      let v1164_3_arg_5: &[u8] = &(*p5);
      let v1164_3_arg_7: &Space = &(&v1162_19_cursor).make_map();
      let mut v1164_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1164_3_origin = v1164_3_cursor.path().len();
      let mut v1164_3_more = v1164_3_cursor.is_val() || next_value_within(&mut v1164_3_cursor,v1164_3_origin);
      while v1164_3_more {
        {
        let v1164_3_depth = v1164_3_cursor.path().len();
        let v1165_8: Space = routine_149(c, &v1164_3_cursor.path()[v1164_3_origin..v1164_3_depth], &(*v1164_3_arg_1), &(*v1164_3_arg_2), &(*v1164_3_arg_3), &(*v1164_3_arg_4), &(*v1164_3_arg_5), &((*v1164_3_arg_7).read_zipper()));
        join_wrapped_into(&mut v1164_3_write,&((v1165_8).read_zipper()),&[]);
        }
        v1164_3_more = next_value_within(&mut v1164_3_cursor,v1164_3_origin);
      }
      drop(v1164_3_cursor);
      drop(v1164_3_write);
      map_map_kernels::compose(&(v1162_12),&(v1164_3))
    };
    let v1163_6: Space = if (&(v1162_18)).is_empty() { Space::new() } else {
      let v1166_2: Path = concat_path(&(*p1),&v1162_19_cursor.path()[v1162_19_origin..(v1162_19_origin + 1)]);
      let mut v1166_5 = Space::new();
      let mut v1166_5_write = v1166_5.write_zipper();
      for v1166_5_byte in v1162_19_cursor.child_mask().iter() {
        v1162_19_cursor.descend_to_existing_byte(v1166_5_byte);
        {
        let v1167_2: Space = routine_150(c, &v1162_19_cursor.path()[(v1162_19_origin + 1)..(v1162_19_origin + 2)], &v1162_19_cursor.path()[(v1162_19_origin + 1)..(v1162_19_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(v1166_2), &v1162_19_cursor);
        join_wrapped_into(&mut v1166_5_write,&((v1167_2).read_zipper()),&[]);
        }
        v1162_19_cursor.ascend(1);
      }
      drop(v1166_5_write);
      drop(v1166_2);
      map_map_kernels::compose(&(v1162_18),&(v1166_5))
    };
    let v1163_7: Space = map_map_kernels::unite(&(v1163_4),&(v1163_6));
    join_wrapped_into(&mut v1162_19_write,&((v1163_7).read_zipper()),&[]);
    }
    v1162_19_cursor.ascend(1);
  }
  drop(v1162_19_cursor);
  drop(v1162_19_write);
  drop(v1162_12);
  drop(v1162_18);
  (v1162_19).clone()
}

fn routine_150(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v1168_10: Space = singleton(&(*p1));
  let v1168_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1168_10));
  let v1168_12: Space = if map_kernels::has_head(&(v1168_11)) { singleton(&[]) } else { Space::new() };
  drop(v1168_11);
  let v1168_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1168_12));
  drop(v1168_12);
  let v1168_24: Space = if (&(v1168_13)).is_empty() { Space::new() } else {
    let v1169_16: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1169_19: Space = if (&(v1169_16)).is_empty() { Space::new() } else {
      let v1170_18: Space = routine_167(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*s0));
      map_map_kernels::compose(&(v1169_16),&(v1170_18))
    };
    drop(v1169_16);
    let mut v1169_22 = Space::new();
    let mut v1169_22_write = v1169_22.write_zipper();
    let mut v1169_22_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1169_22_origin = v1169_22_cursor.path().len();
    for v1169_22_byte in v1169_22_cursor.child_mask().iter() {
      v1169_22_cursor.descend_to_existing_byte(v1169_22_byte);
      {
      let v1171_2_arg_0: &[u8] = &v1169_22_cursor.path()[v1169_22_origin..(v1169_22_origin + 1)];
      let v1171_2_arg_1: &[u8] = &(*p0);
      let v1171_2_arg_2: &[u8] = &(*p2);
      let v1171_2_arg_3: &[u8] = &(*p3);
      let v1171_2_arg_4: &[u8] = &(*p4);
      let v1171_2_arg_5: &[u8] = &(*p5);
      let v1171_2_arg_6: &[u8] = &(*p6);
      let v1171_2_arg_8: &Space = &(&(*s0)).make_map();
      let mut v1171_2_more = v1169_22_cursor.is_val() || next_value_within(&mut v1169_22_cursor,(v1169_22_origin + 1));
      while v1171_2_more {
        {
        let v1171_2_depth = v1169_22_cursor.path().len();
        let mut v1172_9_cursor = (*v1171_2_arg_8).read_zipper();
        let v1172_9_origin = v1172_9_cursor.path().len();
        for v1172_9_byte in v1172_9_cursor.child_mask().iter() {
          v1172_9_cursor.descend_to_existing_byte(v1172_9_byte);
          {
          let v1173_2: Path = concat_path(&(*v1171_2_arg_1),&v1172_9_cursor.path()[v1172_9_origin..(v1172_9_origin + 1)]);
          let v1173_3: Space = routine_150(c, &(v1173_2), &v1169_22_cursor.path()[v1169_22_origin..v1171_2_depth], &(*v1171_2_arg_2), &(*v1171_2_arg_3), &(*v1171_2_arg_4), &(*v1171_2_arg_5), &(*v1171_2_arg_6), &v1172_9_cursor);
          drop(v1173_2);
          join_wrapped_into(&mut v1169_22_write,&((v1173_3).read_zipper()),&[]);
          }
          v1172_9_cursor.ascend(1);
        }
        drop(v1172_9_cursor);
        }
        v1171_2_more = next_value_within(&mut v1169_22_cursor,(v1169_22_origin + 1));
      }
      }
      v1169_22_cursor.ascend(1);
    }
    drop(v1169_22_cursor);
    drop(v1169_22_write);
    let v1169_23: Space = map_map_kernels::unite(&(v1169_19),&(v1169_22));
    map_map_kernels::compose(&(v1168_13),&(v1169_23))
  };
  drop(v1168_13);
  let v1168_26: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1168_10));
  drop(v1168_10);
  let v1168_27: Space = if map_kernels::has_head(&(v1168_26)) { singleton(&[]) } else { Space::new() };
  drop(v1168_26);
  let v1168_29: Space = if (&(v1168_27)).is_empty() { Space::new() } else {
    let mut v1174_28 = Space::new();
    let mut v1174_28_write = v1174_28.write_zipper();
    let mut v1174_28_cursor = (*s0).read_zipper();
    let v1174_28_origin = v1174_28_cursor.path().len();
    for v1174_28_byte in v1174_28_cursor.child_mask().iter() {
      v1174_28_cursor.descend_to_existing_byte(v1174_28_byte);
      {
      let v1175_2: Space = routine_168(c, &v1174_28_cursor.path()[v1174_28_origin..(v1174_28_origin + 1)], &v1174_28_cursor.path()[v1174_28_origin..(v1174_28_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v1174_28_cursor);
      join_wrapped_into(&mut v1174_28_write,&((v1175_2).read_zipper()),&[]);
      }
      v1174_28_cursor.ascend(1);
    }
    drop(v1174_28_cursor);
    drop(v1174_28_write);
    map_map_kernels::compose(&(v1168_27),&(v1174_28))
  };
  drop(v1168_27);
  let v1168_30: Space = map_map_kernels::unite(&(v1168_24),&(v1168_29));
  (v1168_30).clone()
}

fn routine_151(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v1176_10: Space = singleton(&(*p0));
  let v1176_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1176_10));
  let v1176_12: Space = if map_kernels::has_head(&(v1176_11)) { singleton(&[]) } else { Space::new() };
  drop(v1176_11);
  let v1176_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1176_12));
  drop(v1176_12);
  let v1176_18: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1176_10));
  drop(v1176_10);
  let v1176_19: Space = if map_kernels::has_head(&(v1176_18)) { singleton(&[]) } else { Space::new() };
  drop(v1176_18);
  let mut v1176_20 = Space::new();
  let mut v1176_20_write = v1176_20.write_zipper();
  let mut v1176_20_cursor = (*s0).read_zipper();
  let v1176_20_origin = v1176_20_cursor.path().len();
  for v1176_20_byte in v1176_20_cursor.child_mask().iter() {
    v1176_20_cursor.descend_to_existing_byte(v1176_20_byte);
    {
    let v1177_4: Space = if (&(v1176_13)).is_empty() { Space::new() } else {
      let v1178_2: Path = concat_path(&(*p1),&v1176_20_cursor.path()[v1176_20_origin..(v1176_20_origin + 1)]);
      let mut v1178_3 = Space::new();
      let mut v1178_3_write = v1178_3.write_zipper();
      let v1178_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1178_3_arg_1: &[u8] = &(v1178_2);
      let v1178_3_arg_2: &[u8] = &(*p2);
      let v1178_3_arg_3: &[u8] = &(*p3);
      let v1178_3_arg_4: &[u8] = &(*p4);
      let v1178_3_arg_5: &[u8] = &(*p5);
      let v1178_3_arg_6: &[u8] = &(*p6);
      let v1178_3_arg_8: &Space = &(&v1176_20_cursor).make_map();
      let mut v1178_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1178_3_origin = v1178_3_cursor.path().len();
      let mut v1178_3_more = v1178_3_cursor.is_val() || next_value_within(&mut v1178_3_cursor,v1178_3_origin);
      while v1178_3_more {
        {
        let v1178_3_depth = v1178_3_cursor.path().len();
        let v1179_9: Space = routine_151(c, &v1178_3_cursor.path()[v1178_3_origin..v1178_3_depth], &(*v1178_3_arg_1), &(*v1178_3_arg_2), &(*v1178_3_arg_3), &(*v1178_3_arg_4), &(*v1178_3_arg_5), &(*v1178_3_arg_6), &((*v1178_3_arg_8).read_zipper()));
        join_wrapped_into(&mut v1178_3_write,&((v1179_9).read_zipper()),&[]);
        }
        v1178_3_more = next_value_within(&mut v1178_3_cursor,v1178_3_origin);
      }
      drop(v1178_3_cursor);
      drop(v1178_3_write);
      map_map_kernels::compose(&(v1176_13),&(v1178_3))
    };
    let v1177_6: Space = if (&(v1176_19)).is_empty() { Space::new() } else {
      let v1180_2: Path = concat_path(&(*p1),&v1176_20_cursor.path()[v1176_20_origin..(v1176_20_origin + 1)]);
      let mut v1180_5 = Space::new();
      let mut v1180_5_write = v1180_5.write_zipper();
      for v1180_5_byte in v1176_20_cursor.child_mask().iter() {
        v1176_20_cursor.descend_to_existing_byte(v1180_5_byte);
        {
        let v1181_2: Space = routine_152(c, &v1176_20_cursor.path()[(v1176_20_origin + 1)..(v1176_20_origin + 2)], &v1176_20_cursor.path()[(v1176_20_origin + 1)..(v1176_20_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1180_2), &v1176_20_cursor);
        join_wrapped_into(&mut v1180_5_write,&((v1181_2).read_zipper()),&[]);
        }
        v1176_20_cursor.ascend(1);
      }
      drop(v1180_5_write);
      drop(v1180_2);
      map_map_kernels::compose(&(v1176_19),&(v1180_5))
    };
    let v1177_7: Space = map_map_kernels::unite(&(v1177_4),&(v1177_6));
    join_wrapped_into(&mut v1176_20_write,&((v1177_7).read_zipper()),&[]);
    }
    v1176_20_cursor.ascend(1);
  }
  drop(v1176_20_cursor);
  drop(v1176_20_write);
  drop(v1176_13);
  drop(v1176_19);
  (v1176_20).clone()
}

fn routine_152(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v1182_11: Space = singleton(&(*p1));
  let v1182_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1182_11));
  let v1182_13: Space = if map_kernels::has_head(&(v1182_12)) { singleton(&[]) } else { Space::new() };
  drop(v1182_12);
  let v1182_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1182_13));
  drop(v1182_13);
  let v1182_25: Space = if (&(v1182_14)).is_empty() { Space::new() } else {
    let v1183_17: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1183_20: Space = if (&(v1183_17)).is_empty() { Space::new() } else {
      let v1184_19: Space = routine_169(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*s0));
      map_map_kernels::compose(&(v1183_17),&(v1184_19))
    };
    drop(v1183_17);
    let mut v1183_23 = Space::new();
    let mut v1183_23_write = v1183_23.write_zipper();
    let mut v1183_23_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1183_23_origin = v1183_23_cursor.path().len();
    for v1183_23_byte in v1183_23_cursor.child_mask().iter() {
      v1183_23_cursor.descend_to_existing_byte(v1183_23_byte);
      {
      let v1185_2_arg_0: &[u8] = &v1183_23_cursor.path()[v1183_23_origin..(v1183_23_origin + 1)];
      let v1185_2_arg_1: &[u8] = &(*p0);
      let v1185_2_arg_2: &[u8] = &(*p2);
      let v1185_2_arg_3: &[u8] = &(*p3);
      let v1185_2_arg_4: &[u8] = &(*p4);
      let v1185_2_arg_5: &[u8] = &(*p5);
      let v1185_2_arg_6: &[u8] = &(*p6);
      let v1185_2_arg_7: &[u8] = &(*p7);
      let v1185_2_arg_9: &Space = &(&(*s0)).make_map();
      let mut v1185_2_more = v1183_23_cursor.is_val() || next_value_within(&mut v1183_23_cursor,(v1183_23_origin + 1));
      while v1185_2_more {
        {
        let v1185_2_depth = v1183_23_cursor.path().len();
        let mut v1186_10_cursor = (*v1185_2_arg_9).read_zipper();
        let v1186_10_origin = v1186_10_cursor.path().len();
        for v1186_10_byte in v1186_10_cursor.child_mask().iter() {
          v1186_10_cursor.descend_to_existing_byte(v1186_10_byte);
          {
          let v1187_2: Path = concat_path(&(*v1185_2_arg_1),&v1186_10_cursor.path()[v1186_10_origin..(v1186_10_origin + 1)]);
          let v1187_3: Space = routine_152(c, &(v1187_2), &v1183_23_cursor.path()[v1183_23_origin..v1185_2_depth], &(*v1185_2_arg_2), &(*v1185_2_arg_3), &(*v1185_2_arg_4), &(*v1185_2_arg_5), &(*v1185_2_arg_6), &(*v1185_2_arg_7), &v1186_10_cursor);
          drop(v1187_2);
          join_wrapped_into(&mut v1183_23_write,&((v1187_3).read_zipper()),&[]);
          }
          v1186_10_cursor.ascend(1);
        }
        drop(v1186_10_cursor);
        }
        v1185_2_more = next_value_within(&mut v1183_23_cursor,(v1183_23_origin + 1));
      }
      }
      v1183_23_cursor.ascend(1);
    }
    drop(v1183_23_cursor);
    drop(v1183_23_write);
    let v1183_24: Space = map_map_kernels::unite(&(v1183_20),&(v1183_23));
    map_map_kernels::compose(&(v1182_14),&(v1183_24))
  };
  drop(v1182_14);
  let v1182_27: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1182_11));
  drop(v1182_11);
  let v1182_28: Space = if map_kernels::has_head(&(v1182_27)) { singleton(&[]) } else { Space::new() };
  drop(v1182_27);
  let v1182_30: Space = if (&(v1182_28)).is_empty() { Space::new() } else {
    let mut v1188_29 = Space::new();
    let mut v1188_29_write = v1188_29.write_zipper();
    let mut v1188_29_cursor = (*s0).read_zipper();
    let v1188_29_origin = v1188_29_cursor.path().len();
    for v1188_29_byte in v1188_29_cursor.child_mask().iter() {
      v1188_29_cursor.descend_to_existing_byte(v1188_29_byte);
      {
      let v1189_2: Space = routine_170(c, &v1188_29_cursor.path()[v1188_29_origin..(v1188_29_origin + 1)], &v1188_29_cursor.path()[v1188_29_origin..(v1188_29_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p0), &v1188_29_cursor);
      join_wrapped_into(&mut v1188_29_write,&((v1189_2).read_zipper()),&[]);
      }
      v1188_29_cursor.ascend(1);
    }
    drop(v1188_29_cursor);
    drop(v1188_29_write);
    map_map_kernels::compose(&(v1182_28),&(v1188_29))
  };
  drop(v1182_28);
  let v1182_31: Space = map_map_kernels::unite(&(v1182_25),&(v1182_30));
  (v1182_31).clone()
}

fn routine_153(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v1190_10: Space = singleton(&(*p0));
  let v1190_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1190_10));
  let v1190_12: Space = if map_kernels::has_head(&(v1190_11)) { singleton(&[]) } else { Space::new() };
  drop(v1190_11);
  let v1190_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1190_12));
  drop(v1190_12);
  let v1190_18: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1190_10));
  drop(v1190_10);
  let v1190_19: Space = if map_kernels::has_head(&(v1190_18)) { singleton(&[]) } else { Space::new() };
  drop(v1190_18);
  let mut v1190_20 = Space::new();
  let mut v1190_20_write = v1190_20.write_zipper();
  let mut v1190_20_cursor = (*s0).read_zipper();
  let v1190_20_origin = v1190_20_cursor.path().len();
  for v1190_20_byte in v1190_20_cursor.child_mask().iter() {
    v1190_20_cursor.descend_to_existing_byte(v1190_20_byte);
    {
    let v1191_4: Space = if (&(v1190_13)).is_empty() { Space::new() } else {
      let v1192_2: Path = concat_path(&(*p1),&v1190_20_cursor.path()[v1190_20_origin..(v1190_20_origin + 1)]);
      let mut v1192_3 = Space::new();
      let mut v1192_3_write = v1192_3.write_zipper();
      let v1192_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1192_3_arg_1: &[u8] = &(v1192_2);
      let v1192_3_arg_2: &[u8] = &(*p2);
      let v1192_3_arg_3: &[u8] = &(*p3);
      let v1192_3_arg_4: &[u8] = &(*p4);
      let v1192_3_arg_5: &[u8] = &(*p5);
      let v1192_3_arg_6: &[u8] = &(*p6);
      let v1192_3_arg_8: &Space = &(&v1190_20_cursor).make_map();
      let mut v1192_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1192_3_origin = v1192_3_cursor.path().len();
      let mut v1192_3_more = v1192_3_cursor.is_val() || next_value_within(&mut v1192_3_cursor,v1192_3_origin);
      while v1192_3_more {
        {
        let v1192_3_depth = v1192_3_cursor.path().len();
        let v1193_9: Space = routine_153(c, &v1192_3_cursor.path()[v1192_3_origin..v1192_3_depth], &(*v1192_3_arg_1), &(*v1192_3_arg_2), &(*v1192_3_arg_3), &(*v1192_3_arg_4), &(*v1192_3_arg_5), &(*v1192_3_arg_6), &((*v1192_3_arg_8).read_zipper()));
        join_wrapped_into(&mut v1192_3_write,&((v1193_9).read_zipper()),&[]);
        }
        v1192_3_more = next_value_within(&mut v1192_3_cursor,v1192_3_origin);
      }
      drop(v1192_3_cursor);
      drop(v1192_3_write);
      map_map_kernels::compose(&(v1190_13),&(v1192_3))
    };
    let v1191_6: Space = if (&(v1190_19)).is_empty() { Space::new() } else {
      let v1194_2: Path = concat_path(&(*p1),&v1190_20_cursor.path()[v1190_20_origin..(v1190_20_origin + 1)]);
      let mut v1194_5 = Space::new();
      let mut v1194_5_write = v1194_5.write_zipper();
      for v1194_5_byte in v1190_20_cursor.child_mask().iter() {
        v1190_20_cursor.descend_to_existing_byte(v1194_5_byte);
        {
        let v1195_2: Space = routine_154(c, &v1190_20_cursor.path()[(v1190_20_origin + 1)..(v1190_20_origin + 2)], &v1190_20_cursor.path()[(v1190_20_origin + 1)..(v1190_20_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1194_2), &v1190_20_cursor);
        join_wrapped_into(&mut v1194_5_write,&((v1195_2).read_zipper()),&[]);
        }
        v1190_20_cursor.ascend(1);
      }
      drop(v1194_5_write);
      drop(v1194_2);
      map_map_kernels::compose(&(v1190_19),&(v1194_5))
    };
    let v1191_7: Space = map_map_kernels::unite(&(v1191_4),&(v1191_6));
    join_wrapped_into(&mut v1190_20_write,&((v1191_7).read_zipper()),&[]);
    }
    v1190_20_cursor.ascend(1);
  }
  drop(v1190_20_cursor);
  drop(v1190_20_write);
  drop(v1190_13);
  drop(v1190_19);
  (v1190_20).clone()
}

fn routine_154(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v1196_11: Space = singleton(&(*p1));
  let v1196_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1196_11));
  let v1196_13: Space = if map_kernels::has_head(&(v1196_12)) { singleton(&[]) } else { Space::new() };
  drop(v1196_12);
  let v1196_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1196_13));
  drop(v1196_13);
  let v1196_25: Space = if (&(v1196_14)).is_empty() { Space::new() } else {
    let v1197_17: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1197_20: Space = if (&(v1197_17)).is_empty() { Space::new() } else {
      let v1198_19: Space = routine_171(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*s0));
      map_map_kernels::compose(&(v1197_17),&(v1198_19))
    };
    drop(v1197_17);
    let mut v1197_23 = Space::new();
    let mut v1197_23_write = v1197_23.write_zipper();
    let mut v1197_23_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1197_23_origin = v1197_23_cursor.path().len();
    for v1197_23_byte in v1197_23_cursor.child_mask().iter() {
      v1197_23_cursor.descend_to_existing_byte(v1197_23_byte);
      {
      let v1199_2_arg_0: &[u8] = &v1197_23_cursor.path()[v1197_23_origin..(v1197_23_origin + 1)];
      let v1199_2_arg_1: &[u8] = &(*p0);
      let v1199_2_arg_2: &[u8] = &(*p2);
      let v1199_2_arg_3: &[u8] = &(*p3);
      let v1199_2_arg_4: &[u8] = &(*p4);
      let v1199_2_arg_5: &[u8] = &(*p5);
      let v1199_2_arg_6: &[u8] = &(*p6);
      let v1199_2_arg_7: &[u8] = &(*p7);
      let v1199_2_arg_9: &Space = &(&(*s0)).make_map();
      let mut v1199_2_more = v1197_23_cursor.is_val() || next_value_within(&mut v1197_23_cursor,(v1197_23_origin + 1));
      while v1199_2_more {
        {
        let v1199_2_depth = v1197_23_cursor.path().len();
        let mut v1200_10_cursor = (*v1199_2_arg_9).read_zipper();
        let v1200_10_origin = v1200_10_cursor.path().len();
        for v1200_10_byte in v1200_10_cursor.child_mask().iter() {
          v1200_10_cursor.descend_to_existing_byte(v1200_10_byte);
          {
          let v1201_2: Path = concat_path(&(*v1199_2_arg_1),&v1200_10_cursor.path()[v1200_10_origin..(v1200_10_origin + 1)]);
          let v1201_3: Space = routine_154(c, &(v1201_2), &v1197_23_cursor.path()[v1197_23_origin..v1199_2_depth], &(*v1199_2_arg_2), &(*v1199_2_arg_3), &(*v1199_2_arg_4), &(*v1199_2_arg_5), &(*v1199_2_arg_6), &(*v1199_2_arg_7), &v1200_10_cursor);
          drop(v1201_2);
          join_wrapped_into(&mut v1197_23_write,&((v1201_3).read_zipper()),&[]);
          }
          v1200_10_cursor.ascend(1);
        }
        drop(v1200_10_cursor);
        }
        v1199_2_more = next_value_within(&mut v1197_23_cursor,(v1197_23_origin + 1));
      }
      }
      v1197_23_cursor.ascend(1);
    }
    drop(v1197_23_cursor);
    drop(v1197_23_write);
    let v1197_24: Space = map_map_kernels::unite(&(v1197_20),&(v1197_23));
    map_map_kernels::compose(&(v1196_14),&(v1197_24))
  };
  drop(v1196_14);
  let v1196_27: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1196_11));
  drop(v1196_11);
  let v1196_28: Space = if map_kernels::has_head(&(v1196_27)) { singleton(&[]) } else { Space::new() };
  drop(v1196_27);
  let v1196_30: Space = if (&(v1196_28)).is_empty() { Space::new() } else {
    let mut v1202_29 = Space::new();
    let mut v1202_29_write = v1202_29.write_zipper();
    let mut v1202_29_cursor = (*s0).read_zipper();
    let v1202_29_origin = v1202_29_cursor.path().len();
    for v1202_29_byte in v1202_29_cursor.child_mask().iter() {
      v1202_29_cursor.descend_to_existing_byte(v1202_29_byte);
      {
      let v1203_2: Space = routine_172(c, &v1202_29_cursor.path()[v1202_29_origin..(v1202_29_origin + 1)], &v1202_29_cursor.path()[v1202_29_origin..(v1202_29_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p0), &v1202_29_cursor);
      join_wrapped_into(&mut v1202_29_write,&((v1203_2).read_zipper()),&[]);
      }
      v1202_29_cursor.ascend(1);
    }
    drop(v1202_29_cursor);
    drop(v1202_29_write);
    map_map_kernels::compose(&(v1196_28),&(v1202_29))
  };
  drop(v1196_28);
  let v1196_31: Space = map_map_kernels::unite(&(v1196_25),&(v1196_30));
  (v1196_31).clone()
}

fn routine_155(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v1204_10: Space = singleton(&(*p0));
  let v1204_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1204_10));
  let v1204_12: Space = if map_kernels::has_head(&(v1204_11)) { singleton(&[]) } else { Space::new() };
  drop(v1204_11);
  let v1204_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1204_12));
  drop(v1204_12);
  let v1204_18: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1204_10));
  drop(v1204_10);
  let v1204_19: Space = if map_kernels::has_head(&(v1204_18)) { singleton(&[]) } else { Space::new() };
  drop(v1204_18);
  let mut v1204_20 = Space::new();
  let mut v1204_20_write = v1204_20.write_zipper();
  let mut v1204_20_cursor = (*s0).read_zipper();
  let v1204_20_origin = v1204_20_cursor.path().len();
  for v1204_20_byte in v1204_20_cursor.child_mask().iter() {
    v1204_20_cursor.descend_to_existing_byte(v1204_20_byte);
    {
    let v1205_4: Space = if (&(v1204_13)).is_empty() { Space::new() } else {
      let v1206_2: Path = concat_path(&(*p1),&v1204_20_cursor.path()[v1204_20_origin..(v1204_20_origin + 1)]);
      let mut v1206_3 = Space::new();
      let mut v1206_3_write = v1206_3.write_zipper();
      let v1206_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1206_3_arg_1: &[u8] = &(v1206_2);
      let v1206_3_arg_2: &[u8] = &(*p2);
      let v1206_3_arg_3: &[u8] = &(*p3);
      let v1206_3_arg_4: &[u8] = &(*p4);
      let v1206_3_arg_5: &[u8] = &(*p5);
      let v1206_3_arg_6: &[u8] = &(*p6);
      let v1206_3_arg_8: &Space = &(&v1204_20_cursor).make_map();
      let mut v1206_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1206_3_origin = v1206_3_cursor.path().len();
      let mut v1206_3_more = v1206_3_cursor.is_val() || next_value_within(&mut v1206_3_cursor,v1206_3_origin);
      while v1206_3_more {
        {
        let v1206_3_depth = v1206_3_cursor.path().len();
        let v1207_9: Space = routine_155(c, &v1206_3_cursor.path()[v1206_3_origin..v1206_3_depth], &(*v1206_3_arg_1), &(*v1206_3_arg_2), &(*v1206_3_arg_3), &(*v1206_3_arg_4), &(*v1206_3_arg_5), &(*v1206_3_arg_6), &((*v1206_3_arg_8).read_zipper()));
        join_wrapped_into(&mut v1206_3_write,&((v1207_9).read_zipper()),&[]);
        }
        v1206_3_more = next_value_within(&mut v1206_3_cursor,v1206_3_origin);
      }
      drop(v1206_3_cursor);
      drop(v1206_3_write);
      map_map_kernels::compose(&(v1204_13),&(v1206_3))
    };
    let v1205_6: Space = if (&(v1204_19)).is_empty() { Space::new() } else {
      let v1208_2: Path = concat_path(&(*p1),&v1204_20_cursor.path()[v1204_20_origin..(v1204_20_origin + 1)]);
      let mut v1208_5 = Space::new();
      let mut v1208_5_write = v1208_5.write_zipper();
      for v1208_5_byte in v1204_20_cursor.child_mask().iter() {
        v1204_20_cursor.descend_to_existing_byte(v1208_5_byte);
        {
        let v1209_2: Space = routine_156(c, &v1204_20_cursor.path()[(v1204_20_origin + 1)..(v1204_20_origin + 2)], &v1204_20_cursor.path()[(v1204_20_origin + 1)..(v1204_20_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1208_2), &v1204_20_cursor);
        join_wrapped_into(&mut v1208_5_write,&((v1209_2).read_zipper()),&[]);
        }
        v1204_20_cursor.ascend(1);
      }
      drop(v1208_5_write);
      drop(v1208_2);
      map_map_kernels::compose(&(v1204_19),&(v1208_5))
    };
    let v1205_7: Space = map_map_kernels::unite(&(v1205_4),&(v1205_6));
    join_wrapped_into(&mut v1204_20_write,&((v1205_7).read_zipper()),&[]);
    }
    v1204_20_cursor.ascend(1);
  }
  drop(v1204_20_cursor);
  drop(v1204_20_write);
  drop(v1204_13);
  drop(v1204_19);
  (v1204_20).clone()
}

fn routine_156(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v1210_11: Space = singleton(&(*p1));
  let v1210_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1210_11));
  let v1210_13: Space = if map_kernels::has_head(&(v1210_12)) { singleton(&[]) } else { Space::new() };
  drop(v1210_12);
  let v1210_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1210_13));
  drop(v1210_13);
  let v1210_25: Space = if (&(v1210_14)).is_empty() { Space::new() } else {
    let v1211_17: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1211_20: Space = if (&(v1211_17)).is_empty() { Space::new() } else {
      let v1212_19: Space = routine_173(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*s0));
      map_map_kernels::compose(&(v1211_17),&(v1212_19))
    };
    drop(v1211_17);
    let mut v1211_23 = Space::new();
    let mut v1211_23_write = v1211_23.write_zipper();
    let mut v1211_23_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1211_23_origin = v1211_23_cursor.path().len();
    for v1211_23_byte in v1211_23_cursor.child_mask().iter() {
      v1211_23_cursor.descend_to_existing_byte(v1211_23_byte);
      {
      let v1213_2_arg_0: &[u8] = &v1211_23_cursor.path()[v1211_23_origin..(v1211_23_origin + 1)];
      let v1213_2_arg_1: &[u8] = &(*p0);
      let v1213_2_arg_2: &[u8] = &(*p2);
      let v1213_2_arg_3: &[u8] = &(*p3);
      let v1213_2_arg_4: &[u8] = &(*p4);
      let v1213_2_arg_5: &[u8] = &(*p5);
      let v1213_2_arg_6: &[u8] = &(*p6);
      let v1213_2_arg_7: &[u8] = &(*p7);
      let v1213_2_arg_9: &Space = &(&(*s0)).make_map();
      let mut v1213_2_more = v1211_23_cursor.is_val() || next_value_within(&mut v1211_23_cursor,(v1211_23_origin + 1));
      while v1213_2_more {
        {
        let v1213_2_depth = v1211_23_cursor.path().len();
        let mut v1214_10_cursor = (*v1213_2_arg_9).read_zipper();
        let v1214_10_origin = v1214_10_cursor.path().len();
        for v1214_10_byte in v1214_10_cursor.child_mask().iter() {
          v1214_10_cursor.descend_to_existing_byte(v1214_10_byte);
          {
          let v1215_2: Path = concat_path(&(*v1213_2_arg_1),&v1214_10_cursor.path()[v1214_10_origin..(v1214_10_origin + 1)]);
          let v1215_3: Space = routine_156(c, &(v1215_2), &v1211_23_cursor.path()[v1211_23_origin..v1213_2_depth], &(*v1213_2_arg_2), &(*v1213_2_arg_3), &(*v1213_2_arg_4), &(*v1213_2_arg_5), &(*v1213_2_arg_6), &(*v1213_2_arg_7), &v1214_10_cursor);
          drop(v1215_2);
          join_wrapped_into(&mut v1211_23_write,&((v1215_3).read_zipper()),&[]);
          }
          v1214_10_cursor.ascend(1);
        }
        drop(v1214_10_cursor);
        }
        v1213_2_more = next_value_within(&mut v1211_23_cursor,(v1211_23_origin + 1));
      }
      }
      v1211_23_cursor.ascend(1);
    }
    drop(v1211_23_cursor);
    drop(v1211_23_write);
    let v1211_24: Space = map_map_kernels::unite(&(v1211_20),&(v1211_23));
    map_map_kernels::compose(&(v1210_14),&(v1211_24))
  };
  drop(v1210_14);
  let v1210_27: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1210_11));
  drop(v1210_11);
  let v1210_28: Space = if map_kernels::has_head(&(v1210_27)) { singleton(&[]) } else { Space::new() };
  drop(v1210_27);
  let v1210_30: Space = if (&(v1210_28)).is_empty() { Space::new() } else {
    let mut v1216_29 = Space::new();
    let mut v1216_29_write = v1216_29.write_zipper();
    let mut v1216_29_cursor = (*s0).read_zipper();
    let v1216_29_origin = v1216_29_cursor.path().len();
    for v1216_29_byte in v1216_29_cursor.child_mask().iter() {
      v1216_29_cursor.descend_to_existing_byte(v1216_29_byte);
      {
      let v1217_2: Space = routine_174(c, &v1216_29_cursor.path()[v1216_29_origin..(v1216_29_origin + 1)], &v1216_29_cursor.path()[v1216_29_origin..(v1216_29_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p0), &v1216_29_cursor);
      join_wrapped_into(&mut v1216_29_write,&((v1217_2).read_zipper()),&[]);
      }
      v1216_29_cursor.ascend(1);
    }
    drop(v1216_29_cursor);
    drop(v1216_29_write);
    map_map_kernels::compose(&(v1210_28),&(v1216_29))
  };
  drop(v1210_28);
  let v1210_31: Space = map_map_kernels::unite(&(v1210_25),&(v1210_30));
  (v1210_31).clone()
}

fn routine_157(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v1218_10: Space = singleton(&(*p0));
  let v1218_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1218_10));
  let v1218_12: Space = if map_kernels::has_head(&(v1218_11)) { singleton(&[]) } else { Space::new() };
  drop(v1218_11);
  let v1218_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1218_12));
  drop(v1218_12);
  let v1218_18: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1218_10));
  drop(v1218_10);
  let v1218_19: Space = if map_kernels::has_head(&(v1218_18)) { singleton(&[]) } else { Space::new() };
  drop(v1218_18);
  let mut v1218_20 = Space::new();
  let mut v1218_20_write = v1218_20.write_zipper();
  let mut v1218_20_cursor = (*s0).read_zipper();
  let v1218_20_origin = v1218_20_cursor.path().len();
  for v1218_20_byte in v1218_20_cursor.child_mask().iter() {
    v1218_20_cursor.descend_to_existing_byte(v1218_20_byte);
    {
    let v1219_4: Space = if (&(v1218_13)).is_empty() { Space::new() } else {
      let v1220_2: Path = concat_path(&(*p1),&v1218_20_cursor.path()[v1218_20_origin..(v1218_20_origin + 1)]);
      let mut v1220_3 = Space::new();
      let mut v1220_3_write = v1220_3.write_zipper();
      let v1220_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1220_3_arg_1: &[u8] = &(v1220_2);
      let v1220_3_arg_2: &[u8] = &(*p2);
      let v1220_3_arg_3: &[u8] = &(*p3);
      let v1220_3_arg_4: &[u8] = &(*p4);
      let v1220_3_arg_5: &[u8] = &(*p5);
      let v1220_3_arg_6: &[u8] = &(*p6);
      let v1220_3_arg_8: &Space = &(&v1218_20_cursor).make_map();
      let mut v1220_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1220_3_origin = v1220_3_cursor.path().len();
      let mut v1220_3_more = v1220_3_cursor.is_val() || next_value_within(&mut v1220_3_cursor,v1220_3_origin);
      while v1220_3_more {
        {
        let v1220_3_depth = v1220_3_cursor.path().len();
        let v1221_9: Space = routine_157(c, &v1220_3_cursor.path()[v1220_3_origin..v1220_3_depth], &(*v1220_3_arg_1), &(*v1220_3_arg_2), &(*v1220_3_arg_3), &(*v1220_3_arg_4), &(*v1220_3_arg_5), &(*v1220_3_arg_6), &((*v1220_3_arg_8).read_zipper()));
        join_wrapped_into(&mut v1220_3_write,&((v1221_9).read_zipper()),&[]);
        }
        v1220_3_more = next_value_within(&mut v1220_3_cursor,v1220_3_origin);
      }
      drop(v1220_3_cursor);
      drop(v1220_3_write);
      map_map_kernels::compose(&(v1218_13),&(v1220_3))
    };
    let v1219_6: Space = if (&(v1218_19)).is_empty() { Space::new() } else {
      let v1222_2: Path = concat_path(&(*p1),&v1218_20_cursor.path()[v1218_20_origin..(v1218_20_origin + 1)]);
      let mut v1222_5 = Space::new();
      let mut v1222_5_write = v1222_5.write_zipper();
      for v1222_5_byte in v1218_20_cursor.child_mask().iter() {
        v1218_20_cursor.descend_to_existing_byte(v1222_5_byte);
        {
        let v1223_2: Space = routine_158(c, &v1218_20_cursor.path()[(v1218_20_origin + 1)..(v1218_20_origin + 2)], &v1218_20_cursor.path()[(v1218_20_origin + 1)..(v1218_20_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1222_2), &v1218_20_cursor);
        join_wrapped_into(&mut v1222_5_write,&((v1223_2).read_zipper()),&[]);
        }
        v1218_20_cursor.ascend(1);
      }
      drop(v1222_5_write);
      drop(v1222_2);
      map_map_kernels::compose(&(v1218_19),&(v1222_5))
    };
    let v1219_7: Space = map_map_kernels::unite(&(v1219_4),&(v1219_6));
    join_wrapped_into(&mut v1218_20_write,&((v1219_7).read_zipper()),&[]);
    }
    v1218_20_cursor.ascend(1);
  }
  drop(v1218_20_cursor);
  drop(v1218_20_write);
  drop(v1218_13);
  drop(v1218_19);
  (v1218_20).clone()
}

fn routine_158(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v1224_11: Space = singleton(&(*p1));
  let v1224_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1224_11));
  let v1224_13: Space = if map_kernels::has_head(&(v1224_12)) { singleton(&[]) } else { Space::new() };
  drop(v1224_12);
  let v1224_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1224_13));
  drop(v1224_13);
  let v1224_25: Space = if (&(v1224_14)).is_empty() { Space::new() } else {
    let v1225_17: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1225_20: Space = if (&(v1225_17)).is_empty() { Space::new() } else {
      let v1226_19: Space = routine_175(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*s0));
      map_map_kernels::compose(&(v1225_17),&(v1226_19))
    };
    drop(v1225_17);
    let mut v1225_23 = Space::new();
    let mut v1225_23_write = v1225_23.write_zipper();
    let mut v1225_23_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1225_23_origin = v1225_23_cursor.path().len();
    for v1225_23_byte in v1225_23_cursor.child_mask().iter() {
      v1225_23_cursor.descend_to_existing_byte(v1225_23_byte);
      {
      let v1227_2_arg_0: &[u8] = &v1225_23_cursor.path()[v1225_23_origin..(v1225_23_origin + 1)];
      let v1227_2_arg_1: &[u8] = &(*p0);
      let v1227_2_arg_2: &[u8] = &(*p2);
      let v1227_2_arg_3: &[u8] = &(*p3);
      let v1227_2_arg_4: &[u8] = &(*p4);
      let v1227_2_arg_5: &[u8] = &(*p5);
      let v1227_2_arg_6: &[u8] = &(*p6);
      let v1227_2_arg_7: &[u8] = &(*p7);
      let v1227_2_arg_9: &Space = &(&(*s0)).make_map();
      let mut v1227_2_more = v1225_23_cursor.is_val() || next_value_within(&mut v1225_23_cursor,(v1225_23_origin + 1));
      while v1227_2_more {
        {
        let v1227_2_depth = v1225_23_cursor.path().len();
        let mut v1228_10_cursor = (*v1227_2_arg_9).read_zipper();
        let v1228_10_origin = v1228_10_cursor.path().len();
        for v1228_10_byte in v1228_10_cursor.child_mask().iter() {
          v1228_10_cursor.descend_to_existing_byte(v1228_10_byte);
          {
          let v1229_2: Path = concat_path(&(*v1227_2_arg_1),&v1228_10_cursor.path()[v1228_10_origin..(v1228_10_origin + 1)]);
          let v1229_3: Space = routine_158(c, &(v1229_2), &v1225_23_cursor.path()[v1225_23_origin..v1227_2_depth], &(*v1227_2_arg_2), &(*v1227_2_arg_3), &(*v1227_2_arg_4), &(*v1227_2_arg_5), &(*v1227_2_arg_6), &(*v1227_2_arg_7), &v1228_10_cursor);
          drop(v1229_2);
          join_wrapped_into(&mut v1225_23_write,&((v1229_3).read_zipper()),&[]);
          }
          v1228_10_cursor.ascend(1);
        }
        drop(v1228_10_cursor);
        }
        v1227_2_more = next_value_within(&mut v1225_23_cursor,(v1225_23_origin + 1));
      }
      }
      v1225_23_cursor.ascend(1);
    }
    drop(v1225_23_cursor);
    drop(v1225_23_write);
    let v1225_24: Space = map_map_kernels::unite(&(v1225_20),&(v1225_23));
    map_map_kernels::compose(&(v1224_14),&(v1225_24))
  };
  drop(v1224_14);
  let v1224_27: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1224_11));
  drop(v1224_11);
  let v1224_28: Space = if map_kernels::has_head(&(v1224_27)) { singleton(&[]) } else { Space::new() };
  drop(v1224_27);
  let v1224_30: Space = if (&(v1224_28)).is_empty() { Space::new() } else {
    let mut v1230_29 = Space::new();
    let mut v1230_29_write = v1230_29.write_zipper();
    let mut v1230_29_cursor = (*s0).read_zipper();
    let v1230_29_origin = v1230_29_cursor.path().len();
    for v1230_29_byte in v1230_29_cursor.child_mask().iter() {
      v1230_29_cursor.descend_to_existing_byte(v1230_29_byte);
      {
      let v1231_2: Space = routine_176(c, &v1230_29_cursor.path()[v1230_29_origin..(v1230_29_origin + 1)], &v1230_29_cursor.path()[v1230_29_origin..(v1230_29_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p0), &v1230_29_cursor);
      join_wrapped_into(&mut v1230_29_write,&((v1231_2).read_zipper()),&[]);
      }
      v1230_29_cursor.ascend(1);
    }
    drop(v1230_29_cursor);
    drop(v1230_29_write);
    map_map_kernels::compose(&(v1224_28),&(v1230_29))
  };
  drop(v1224_28);
  let v1224_31: Space = map_map_kernels::unite(&(v1224_25),&(v1224_30));
  (v1224_31).clone()
}

fn routine_159(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v1232_10: Space = singleton(&(*p0));
  let v1232_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1232_10));
  let v1232_12: Space = if map_kernels::has_head(&(v1232_11)) { singleton(&[]) } else { Space::new() };
  drop(v1232_11);
  let v1232_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1232_12));
  drop(v1232_12);
  let v1232_18: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1232_10));
  drop(v1232_10);
  let v1232_19: Space = if map_kernels::has_head(&(v1232_18)) { singleton(&[]) } else { Space::new() };
  drop(v1232_18);
  let mut v1232_20 = Space::new();
  let mut v1232_20_write = v1232_20.write_zipper();
  let mut v1232_20_cursor = (*s0).read_zipper();
  let v1232_20_origin = v1232_20_cursor.path().len();
  for v1232_20_byte in v1232_20_cursor.child_mask().iter() {
    v1232_20_cursor.descend_to_existing_byte(v1232_20_byte);
    {
    let v1233_4: Space = if (&(v1232_13)).is_empty() { Space::new() } else {
      let v1234_2: Path = concat_path(&(*p1),&v1232_20_cursor.path()[v1232_20_origin..(v1232_20_origin + 1)]);
      let mut v1234_3 = Space::new();
      let mut v1234_3_write = v1234_3.write_zipper();
      let v1234_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1234_3_arg_1: &[u8] = &(v1234_2);
      let v1234_3_arg_2: &[u8] = &(*p2);
      let v1234_3_arg_3: &[u8] = &(*p3);
      let v1234_3_arg_4: &[u8] = &(*p4);
      let v1234_3_arg_5: &[u8] = &(*p5);
      let v1234_3_arg_6: &[u8] = &(*p6);
      let v1234_3_arg_8: &Space = &(&v1232_20_cursor).make_map();
      let mut v1234_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1234_3_origin = v1234_3_cursor.path().len();
      let mut v1234_3_more = v1234_3_cursor.is_val() || next_value_within(&mut v1234_3_cursor,v1234_3_origin);
      while v1234_3_more {
        {
        let v1234_3_depth = v1234_3_cursor.path().len();
        let v1235_9: Space = routine_159(c, &v1234_3_cursor.path()[v1234_3_origin..v1234_3_depth], &(*v1234_3_arg_1), &(*v1234_3_arg_2), &(*v1234_3_arg_3), &(*v1234_3_arg_4), &(*v1234_3_arg_5), &(*v1234_3_arg_6), &((*v1234_3_arg_8).read_zipper()));
        join_wrapped_into(&mut v1234_3_write,&((v1235_9).read_zipper()),&[]);
        }
        v1234_3_more = next_value_within(&mut v1234_3_cursor,v1234_3_origin);
      }
      drop(v1234_3_cursor);
      drop(v1234_3_write);
      map_map_kernels::compose(&(v1232_13),&(v1234_3))
    };
    let v1233_6: Space = if (&(v1232_19)).is_empty() { Space::new() } else {
      let v1236_2: Path = concat_path(&(*p1),&v1232_20_cursor.path()[v1232_20_origin..(v1232_20_origin + 1)]);
      let mut v1236_5 = Space::new();
      let mut v1236_5_write = v1236_5.write_zipper();
      for v1236_5_byte in v1232_20_cursor.child_mask().iter() {
        v1232_20_cursor.descend_to_existing_byte(v1236_5_byte);
        {
        let v1237_2: Space = routine_160(c, &v1232_20_cursor.path()[(v1232_20_origin + 1)..(v1232_20_origin + 2)], &v1232_20_cursor.path()[(v1232_20_origin + 1)..(v1232_20_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1236_2), &v1232_20_cursor);
        join_wrapped_into(&mut v1236_5_write,&((v1237_2).read_zipper()),&[]);
        }
        v1232_20_cursor.ascend(1);
      }
      drop(v1236_5_write);
      drop(v1236_2);
      map_map_kernels::compose(&(v1232_19),&(v1236_5))
    };
    let v1233_7: Space = map_map_kernels::unite(&(v1233_4),&(v1233_6));
    join_wrapped_into(&mut v1232_20_write,&((v1233_7).read_zipper()),&[]);
    }
    v1232_20_cursor.ascend(1);
  }
  drop(v1232_20_cursor);
  drop(v1232_20_write);
  drop(v1232_13);
  drop(v1232_19);
  (v1232_20).clone()
}

fn routine_160(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v1238_11: Space = singleton(&(*p1));
  let v1238_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1238_11));
  let v1238_13: Space = if map_kernels::has_head(&(v1238_12)) { singleton(&[]) } else { Space::new() };
  drop(v1238_12);
  let v1238_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1238_13));
  drop(v1238_13);
  let v1238_25: Space = if (&(v1238_14)).is_empty() { Space::new() } else {
    let v1239_17: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1239_20: Space = if (&(v1239_17)).is_empty() { Space::new() } else {
      let v1240_19: Space = routine_177(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*s0));
      map_map_kernels::compose(&(v1239_17),&(v1240_19))
    };
    drop(v1239_17);
    let mut v1239_23 = Space::new();
    let mut v1239_23_write = v1239_23.write_zipper();
    let mut v1239_23_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1239_23_origin = v1239_23_cursor.path().len();
    for v1239_23_byte in v1239_23_cursor.child_mask().iter() {
      v1239_23_cursor.descend_to_existing_byte(v1239_23_byte);
      {
      let v1241_2_arg_0: &[u8] = &v1239_23_cursor.path()[v1239_23_origin..(v1239_23_origin + 1)];
      let v1241_2_arg_1: &[u8] = &(*p0);
      let v1241_2_arg_2: &[u8] = &(*p2);
      let v1241_2_arg_3: &[u8] = &(*p3);
      let v1241_2_arg_4: &[u8] = &(*p4);
      let v1241_2_arg_5: &[u8] = &(*p5);
      let v1241_2_arg_6: &[u8] = &(*p6);
      let v1241_2_arg_7: &[u8] = &(*p7);
      let v1241_2_arg_9: &Space = &(&(*s0)).make_map();
      let mut v1241_2_more = v1239_23_cursor.is_val() || next_value_within(&mut v1239_23_cursor,(v1239_23_origin + 1));
      while v1241_2_more {
        {
        let v1241_2_depth = v1239_23_cursor.path().len();
        let mut v1242_10_cursor = (*v1241_2_arg_9).read_zipper();
        let v1242_10_origin = v1242_10_cursor.path().len();
        for v1242_10_byte in v1242_10_cursor.child_mask().iter() {
          v1242_10_cursor.descend_to_existing_byte(v1242_10_byte);
          {
          let v1243_2: Path = concat_path(&(*v1241_2_arg_1),&v1242_10_cursor.path()[v1242_10_origin..(v1242_10_origin + 1)]);
          let v1243_3: Space = routine_160(c, &(v1243_2), &v1239_23_cursor.path()[v1239_23_origin..v1241_2_depth], &(*v1241_2_arg_2), &(*v1241_2_arg_3), &(*v1241_2_arg_4), &(*v1241_2_arg_5), &(*v1241_2_arg_6), &(*v1241_2_arg_7), &v1242_10_cursor);
          drop(v1243_2);
          join_wrapped_into(&mut v1239_23_write,&((v1243_3).read_zipper()),&[]);
          }
          v1242_10_cursor.ascend(1);
        }
        drop(v1242_10_cursor);
        }
        v1241_2_more = next_value_within(&mut v1239_23_cursor,(v1239_23_origin + 1));
      }
      }
      v1239_23_cursor.ascend(1);
    }
    drop(v1239_23_cursor);
    drop(v1239_23_write);
    let v1239_24: Space = map_map_kernels::unite(&(v1239_20),&(v1239_23));
    map_map_kernels::compose(&(v1238_14),&(v1239_24))
  };
  drop(v1238_14);
  let v1238_27: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1238_11));
  drop(v1238_11);
  let v1238_28: Space = if map_kernels::has_head(&(v1238_27)) { singleton(&[]) } else { Space::new() };
  drop(v1238_27);
  let v1238_30: Space = if (&(v1238_28)).is_empty() { Space::new() } else {
    let mut v1244_29 = Space::new();
    let mut v1244_29_write = v1244_29.write_zipper();
    let mut v1244_29_cursor = (*s0).read_zipper();
    let v1244_29_origin = v1244_29_cursor.path().len();
    for v1244_29_byte in v1244_29_cursor.child_mask().iter() {
      v1244_29_cursor.descend_to_existing_byte(v1244_29_byte);
      {
      let v1245_2: Space = routine_178(c, &v1244_29_cursor.path()[v1244_29_origin..(v1244_29_origin + 1)], &v1244_29_cursor.path()[v1244_29_origin..(v1244_29_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p0), &v1244_29_cursor);
      join_wrapped_into(&mut v1244_29_write,&((v1245_2).read_zipper()),&[]);
      }
      v1244_29_cursor.ascend(1);
    }
    drop(v1244_29_cursor);
    drop(v1244_29_write);
    map_map_kernels::compose(&(v1238_28),&(v1244_29))
  };
  drop(v1238_28);
  let v1238_31: Space = map_map_kernels::unite(&(v1238_25),&(v1238_30));
  (v1238_31).clone()
}

fn routine_161(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v1246_10: Space = singleton(&(*p0));
  let v1246_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1246_10));
  let v1246_12: Space = if map_kernels::has_head(&(v1246_11)) { singleton(&[]) } else { Space::new() };
  drop(v1246_11);
  let v1246_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1246_12));
  drop(v1246_12);
  let v1246_18: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1246_10));
  drop(v1246_10);
  let v1246_19: Space = if map_kernels::has_head(&(v1246_18)) { singleton(&[]) } else { Space::new() };
  drop(v1246_18);
  let mut v1246_20 = Space::new();
  let mut v1246_20_write = v1246_20.write_zipper();
  let mut v1246_20_cursor = (*s0).read_zipper();
  let v1246_20_origin = v1246_20_cursor.path().len();
  for v1246_20_byte in v1246_20_cursor.child_mask().iter() {
    v1246_20_cursor.descend_to_existing_byte(v1246_20_byte);
    {
    let v1247_4: Space = if (&(v1246_13)).is_empty() { Space::new() } else {
      let v1248_2: Path = concat_path(&(*p1),&v1246_20_cursor.path()[v1246_20_origin..(v1246_20_origin + 1)]);
      let mut v1248_3 = Space::new();
      let mut v1248_3_write = v1248_3.write_zipper();
      let v1248_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1248_3_arg_1: &[u8] = &(v1248_2);
      let v1248_3_arg_2: &[u8] = &(*p2);
      let v1248_3_arg_3: &[u8] = &(*p3);
      let v1248_3_arg_4: &[u8] = &(*p4);
      let v1248_3_arg_5: &[u8] = &(*p5);
      let v1248_3_arg_6: &[u8] = &(*p6);
      let v1248_3_arg_8: &Space = &(&v1246_20_cursor).make_map();
      let mut v1248_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1248_3_origin = v1248_3_cursor.path().len();
      let mut v1248_3_more = v1248_3_cursor.is_val() || next_value_within(&mut v1248_3_cursor,v1248_3_origin);
      while v1248_3_more {
        {
        let v1248_3_depth = v1248_3_cursor.path().len();
        let v1249_9: Space = routine_161(c, &v1248_3_cursor.path()[v1248_3_origin..v1248_3_depth], &(*v1248_3_arg_1), &(*v1248_3_arg_2), &(*v1248_3_arg_3), &(*v1248_3_arg_4), &(*v1248_3_arg_5), &(*v1248_3_arg_6), &((*v1248_3_arg_8).read_zipper()));
        join_wrapped_into(&mut v1248_3_write,&((v1249_9).read_zipper()),&[]);
        }
        v1248_3_more = next_value_within(&mut v1248_3_cursor,v1248_3_origin);
      }
      drop(v1248_3_cursor);
      drop(v1248_3_write);
      map_map_kernels::compose(&(v1246_13),&(v1248_3))
    };
    let v1247_6: Space = if (&(v1246_19)).is_empty() { Space::new() } else {
      let v1250_2: Path = concat_path(&(*p1),&v1246_20_cursor.path()[v1246_20_origin..(v1246_20_origin + 1)]);
      let mut v1250_5 = Space::new();
      let mut v1250_5_write = v1250_5.write_zipper();
      for v1250_5_byte in v1246_20_cursor.child_mask().iter() {
        v1246_20_cursor.descend_to_existing_byte(v1250_5_byte);
        {
        let v1251_2: Space = routine_162(c, &v1246_20_cursor.path()[(v1246_20_origin + 1)..(v1246_20_origin + 2)], &v1246_20_cursor.path()[(v1246_20_origin + 1)..(v1246_20_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1250_2), &v1246_20_cursor);
        join_wrapped_into(&mut v1250_5_write,&((v1251_2).read_zipper()),&[]);
        }
        v1246_20_cursor.ascend(1);
      }
      drop(v1250_5_write);
      drop(v1250_2);
      map_map_kernels::compose(&(v1246_19),&(v1250_5))
    };
    let v1247_7: Space = map_map_kernels::unite(&(v1247_4),&(v1247_6));
    join_wrapped_into(&mut v1246_20_write,&((v1247_7).read_zipper()),&[]);
    }
    v1246_20_cursor.ascend(1);
  }
  drop(v1246_20_cursor);
  drop(v1246_20_write);
  drop(v1246_13);
  drop(v1246_19);
  (v1246_20).clone()
}

fn routine_162(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v1252_11: Space = singleton(&(*p1));
  let v1252_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1252_11));
  let v1252_13: Space = if map_kernels::has_head(&(v1252_12)) { singleton(&[]) } else { Space::new() };
  drop(v1252_12);
  let v1252_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1252_13));
  drop(v1252_13);
  let v1252_25: Space = if (&(v1252_14)).is_empty() { Space::new() } else {
    let v1253_17: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1253_20: Space = if (&(v1253_17)).is_empty() { Space::new() } else {
      let v1254_19: Space = routine_179(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*s0));
      map_map_kernels::compose(&(v1253_17),&(v1254_19))
    };
    drop(v1253_17);
    let mut v1253_23 = Space::new();
    let mut v1253_23_write = v1253_23.write_zipper();
    let mut v1253_23_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1253_23_origin = v1253_23_cursor.path().len();
    for v1253_23_byte in v1253_23_cursor.child_mask().iter() {
      v1253_23_cursor.descend_to_existing_byte(v1253_23_byte);
      {
      let v1255_2_arg_0: &[u8] = &v1253_23_cursor.path()[v1253_23_origin..(v1253_23_origin + 1)];
      let v1255_2_arg_1: &[u8] = &(*p0);
      let v1255_2_arg_2: &[u8] = &(*p2);
      let v1255_2_arg_3: &[u8] = &(*p3);
      let v1255_2_arg_4: &[u8] = &(*p4);
      let v1255_2_arg_5: &[u8] = &(*p5);
      let v1255_2_arg_6: &[u8] = &(*p6);
      let v1255_2_arg_7: &[u8] = &(*p7);
      let v1255_2_arg_9: &Space = &(&(*s0)).make_map();
      let mut v1255_2_more = v1253_23_cursor.is_val() || next_value_within(&mut v1253_23_cursor,(v1253_23_origin + 1));
      while v1255_2_more {
        {
        let v1255_2_depth = v1253_23_cursor.path().len();
        let mut v1256_10_cursor = (*v1255_2_arg_9).read_zipper();
        let v1256_10_origin = v1256_10_cursor.path().len();
        for v1256_10_byte in v1256_10_cursor.child_mask().iter() {
          v1256_10_cursor.descend_to_existing_byte(v1256_10_byte);
          {
          let v1257_2: Path = concat_path(&(*v1255_2_arg_1),&v1256_10_cursor.path()[v1256_10_origin..(v1256_10_origin + 1)]);
          let v1257_3: Space = routine_162(c, &(v1257_2), &v1253_23_cursor.path()[v1253_23_origin..v1255_2_depth], &(*v1255_2_arg_2), &(*v1255_2_arg_3), &(*v1255_2_arg_4), &(*v1255_2_arg_5), &(*v1255_2_arg_6), &(*v1255_2_arg_7), &v1256_10_cursor);
          drop(v1257_2);
          join_wrapped_into(&mut v1253_23_write,&((v1257_3).read_zipper()),&[]);
          }
          v1256_10_cursor.ascend(1);
        }
        drop(v1256_10_cursor);
        }
        v1255_2_more = next_value_within(&mut v1253_23_cursor,(v1253_23_origin + 1));
      }
      }
      v1253_23_cursor.ascend(1);
    }
    drop(v1253_23_cursor);
    drop(v1253_23_write);
    let v1253_24: Space = map_map_kernels::unite(&(v1253_20),&(v1253_23));
    map_map_kernels::compose(&(v1252_14),&(v1253_24))
  };
  drop(v1252_14);
  let v1252_27: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1252_11));
  drop(v1252_11);
  let v1252_28: Space = if map_kernels::has_head(&(v1252_27)) { singleton(&[]) } else { Space::new() };
  drop(v1252_27);
  let v1252_30: Space = if (&(v1252_28)).is_empty() { Space::new() } else {
    let mut v1258_29 = Space::new();
    let mut v1258_29_write = v1258_29.write_zipper();
    let mut v1258_29_cursor = (*s0).read_zipper();
    let v1258_29_origin = v1258_29_cursor.path().len();
    for v1258_29_byte in v1258_29_cursor.child_mask().iter() {
      v1258_29_cursor.descend_to_existing_byte(v1258_29_byte);
      {
      let v1259_2: Space = routine_180(c, &v1258_29_cursor.path()[v1258_29_origin..(v1258_29_origin + 1)], &v1258_29_cursor.path()[v1258_29_origin..(v1258_29_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p0), &v1258_29_cursor);
      join_wrapped_into(&mut v1258_29_write,&((v1259_2).read_zipper()),&[]);
      }
      v1258_29_cursor.ascend(1);
    }
    drop(v1258_29_cursor);
    drop(v1258_29_write);
    map_map_kernels::compose(&(v1252_28),&(v1258_29))
  };
  drop(v1252_28);
  let v1252_31: Space = map_map_kernels::unite(&(v1252_25),&(v1252_30));
  (v1252_31).clone()
}

fn routine_163(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v1260_10: Space = singleton(&(*p0));
  let v1260_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1260_10));
  let v1260_12: Space = if map_kernels::has_head(&(v1260_11)) { singleton(&[]) } else { Space::new() };
  drop(v1260_11);
  let v1260_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1260_12));
  drop(v1260_12);
  let v1260_18: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1260_10));
  drop(v1260_10);
  let v1260_19: Space = if map_kernels::has_head(&(v1260_18)) { singleton(&[]) } else { Space::new() };
  drop(v1260_18);
  let mut v1260_20 = Space::new();
  let mut v1260_20_write = v1260_20.write_zipper();
  let mut v1260_20_cursor = (*s0).read_zipper();
  let v1260_20_origin = v1260_20_cursor.path().len();
  for v1260_20_byte in v1260_20_cursor.child_mask().iter() {
    v1260_20_cursor.descend_to_existing_byte(v1260_20_byte);
    {
    let v1261_4: Space = if (&(v1260_13)).is_empty() { Space::new() } else {
      let v1262_2: Path = concat_path(&(*p1),&v1260_20_cursor.path()[v1260_20_origin..(v1260_20_origin + 1)]);
      let mut v1262_3 = Space::new();
      let mut v1262_3_write = v1262_3.write_zipper();
      let v1262_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1262_3_arg_1: &[u8] = &(v1262_2);
      let v1262_3_arg_2: &[u8] = &(*p2);
      let v1262_3_arg_3: &[u8] = &(*p3);
      let v1262_3_arg_4: &[u8] = &(*p4);
      let v1262_3_arg_5: &[u8] = &(*p5);
      let v1262_3_arg_6: &[u8] = &(*p6);
      let v1262_3_arg_8: &Space = &(&v1260_20_cursor).make_map();
      let mut v1262_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1262_3_origin = v1262_3_cursor.path().len();
      let mut v1262_3_more = v1262_3_cursor.is_val() || next_value_within(&mut v1262_3_cursor,v1262_3_origin);
      while v1262_3_more {
        {
        let v1262_3_depth = v1262_3_cursor.path().len();
        let v1263_9: Space = routine_163(c, &v1262_3_cursor.path()[v1262_3_origin..v1262_3_depth], &(*v1262_3_arg_1), &(*v1262_3_arg_2), &(*v1262_3_arg_3), &(*v1262_3_arg_4), &(*v1262_3_arg_5), &(*v1262_3_arg_6), &((*v1262_3_arg_8).read_zipper()));
        join_wrapped_into(&mut v1262_3_write,&((v1263_9).read_zipper()),&[]);
        }
        v1262_3_more = next_value_within(&mut v1262_3_cursor,v1262_3_origin);
      }
      drop(v1262_3_cursor);
      drop(v1262_3_write);
      map_map_kernels::compose(&(v1260_13),&(v1262_3))
    };
    let v1261_6: Space = if (&(v1260_19)).is_empty() { Space::new() } else {
      let v1264_2: Path = concat_path(&(*p1),&v1260_20_cursor.path()[v1260_20_origin..(v1260_20_origin + 1)]);
      let mut v1264_5 = Space::new();
      let mut v1264_5_write = v1264_5.write_zipper();
      for v1264_5_byte in v1260_20_cursor.child_mask().iter() {
        v1260_20_cursor.descend_to_existing_byte(v1264_5_byte);
        {
        let v1265_2: Space = routine_164(c, &v1260_20_cursor.path()[(v1260_20_origin + 1)..(v1260_20_origin + 2)], &v1260_20_cursor.path()[(v1260_20_origin + 1)..(v1260_20_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1264_2), &v1260_20_cursor);
        join_wrapped_into(&mut v1264_5_write,&((v1265_2).read_zipper()),&[]);
        }
        v1260_20_cursor.ascend(1);
      }
      drop(v1264_5_write);
      drop(v1264_2);
      map_map_kernels::compose(&(v1260_19),&(v1264_5))
    };
    let v1261_7: Space = map_map_kernels::unite(&(v1261_4),&(v1261_6));
    join_wrapped_into(&mut v1260_20_write,&((v1261_7).read_zipper()),&[]);
    }
    v1260_20_cursor.ascend(1);
  }
  drop(v1260_20_cursor);
  drop(v1260_20_write);
  drop(v1260_13);
  drop(v1260_19);
  (v1260_20).clone()
}

fn routine_164(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v1266_11: Space = singleton(&(*p1));
  let v1266_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1266_11));
  let v1266_13: Space = if map_kernels::has_head(&(v1266_12)) { singleton(&[]) } else { Space::new() };
  drop(v1266_12);
  let v1266_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1266_13));
  drop(v1266_13);
  let v1266_25: Space = if (&(v1266_14)).is_empty() { Space::new() } else {
    let v1267_17: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1267_20: Space = if (&(v1267_17)).is_empty() { Space::new() } else {
      let v1268_19: Space = routine_181(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*s0));
      map_map_kernels::compose(&(v1267_17),&(v1268_19))
    };
    drop(v1267_17);
    let mut v1267_23 = Space::new();
    let mut v1267_23_write = v1267_23.write_zipper();
    let mut v1267_23_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1267_23_origin = v1267_23_cursor.path().len();
    for v1267_23_byte in v1267_23_cursor.child_mask().iter() {
      v1267_23_cursor.descend_to_existing_byte(v1267_23_byte);
      {
      let v1269_2_arg_0: &[u8] = &v1267_23_cursor.path()[v1267_23_origin..(v1267_23_origin + 1)];
      let v1269_2_arg_1: &[u8] = &(*p0);
      let v1269_2_arg_2: &[u8] = &(*p2);
      let v1269_2_arg_3: &[u8] = &(*p3);
      let v1269_2_arg_4: &[u8] = &(*p4);
      let v1269_2_arg_5: &[u8] = &(*p5);
      let v1269_2_arg_6: &[u8] = &(*p6);
      let v1269_2_arg_7: &[u8] = &(*p7);
      let v1269_2_arg_9: &Space = &(&(*s0)).make_map();
      let mut v1269_2_more = v1267_23_cursor.is_val() || next_value_within(&mut v1267_23_cursor,(v1267_23_origin + 1));
      while v1269_2_more {
        {
        let v1269_2_depth = v1267_23_cursor.path().len();
        let mut v1270_10_cursor = (*v1269_2_arg_9).read_zipper();
        let v1270_10_origin = v1270_10_cursor.path().len();
        for v1270_10_byte in v1270_10_cursor.child_mask().iter() {
          v1270_10_cursor.descend_to_existing_byte(v1270_10_byte);
          {
          let v1271_2: Path = concat_path(&(*v1269_2_arg_1),&v1270_10_cursor.path()[v1270_10_origin..(v1270_10_origin + 1)]);
          let v1271_3: Space = routine_164(c, &(v1271_2), &v1267_23_cursor.path()[v1267_23_origin..v1269_2_depth], &(*v1269_2_arg_2), &(*v1269_2_arg_3), &(*v1269_2_arg_4), &(*v1269_2_arg_5), &(*v1269_2_arg_6), &(*v1269_2_arg_7), &v1270_10_cursor);
          drop(v1271_2);
          join_wrapped_into(&mut v1267_23_write,&((v1271_3).read_zipper()),&[]);
          }
          v1270_10_cursor.ascend(1);
        }
        drop(v1270_10_cursor);
        }
        v1269_2_more = next_value_within(&mut v1267_23_cursor,(v1267_23_origin + 1));
      }
      }
      v1267_23_cursor.ascend(1);
    }
    drop(v1267_23_cursor);
    drop(v1267_23_write);
    let v1267_24: Space = map_map_kernels::unite(&(v1267_20),&(v1267_23));
    map_map_kernels::compose(&(v1266_14),&(v1267_24))
  };
  drop(v1266_14);
  let v1266_27: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1266_11));
  drop(v1266_11);
  let v1266_28: Space = if map_kernels::has_head(&(v1266_27)) { singleton(&[]) } else { Space::new() };
  drop(v1266_27);
  let v1266_30: Space = if (&(v1266_28)).is_empty() { Space::new() } else {
    let mut v1272_29 = Space::new();
    let mut v1272_29_write = v1272_29.write_zipper();
    let mut v1272_29_cursor = (*s0).read_zipper();
    let v1272_29_origin = v1272_29_cursor.path().len();
    for v1272_29_byte in v1272_29_cursor.child_mask().iter() {
      v1272_29_cursor.descend_to_existing_byte(v1272_29_byte);
      {
      let v1273_2: Space = routine_182(c, &v1272_29_cursor.path()[v1272_29_origin..(v1272_29_origin + 1)], &v1272_29_cursor.path()[v1272_29_origin..(v1272_29_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p0), &v1272_29_cursor);
      join_wrapped_into(&mut v1272_29_write,&((v1273_2).read_zipper()),&[]);
      }
      v1272_29_cursor.ascend(1);
    }
    drop(v1272_29_cursor);
    drop(v1272_29_write);
    map_map_kernels::compose(&(v1266_28),&(v1272_29))
  };
  drop(v1266_28);
  let v1266_31: Space = map_map_kernels::unite(&(v1266_25),&(v1266_30));
  (v1266_31).clone()
}

fn routine_165(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v1274_10: Space = singleton(&(*p0));
  let v1274_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1274_10));
  let v1274_12: Space = if map_kernels::has_head(&(v1274_11)) { singleton(&[]) } else { Space::new() };
  drop(v1274_11);
  let v1274_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1274_12));
  drop(v1274_12);
  let v1274_18: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1274_10));
  drop(v1274_10);
  let v1274_19: Space = if map_kernels::has_head(&(v1274_18)) { singleton(&[]) } else { Space::new() };
  drop(v1274_18);
  let mut v1274_20 = Space::new();
  let mut v1274_20_write = v1274_20.write_zipper();
  let mut v1274_20_cursor = (*s0).read_zipper();
  let v1274_20_origin = v1274_20_cursor.path().len();
  for v1274_20_byte in v1274_20_cursor.child_mask().iter() {
    v1274_20_cursor.descend_to_existing_byte(v1274_20_byte);
    {
    let v1275_4: Space = if (&(v1274_13)).is_empty() { Space::new() } else {
      let v1276_2: Path = concat_path(&(*p1),&v1274_20_cursor.path()[v1274_20_origin..(v1274_20_origin + 1)]);
      let mut v1276_3 = Space::new();
      let mut v1276_3_write = v1276_3.write_zipper();
      let v1276_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1276_3_arg_1: &[u8] = &(v1276_2);
      let v1276_3_arg_2: &[u8] = &(*p2);
      let v1276_3_arg_3: &[u8] = &(*p3);
      let v1276_3_arg_4: &[u8] = &(*p4);
      let v1276_3_arg_5: &[u8] = &(*p5);
      let v1276_3_arg_6: &[u8] = &(*p6);
      let v1276_3_arg_8: &Space = &(&v1274_20_cursor).make_map();
      let mut v1276_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1276_3_origin = v1276_3_cursor.path().len();
      let mut v1276_3_more = v1276_3_cursor.is_val() || next_value_within(&mut v1276_3_cursor,v1276_3_origin);
      while v1276_3_more {
        {
        let v1276_3_depth = v1276_3_cursor.path().len();
        let v1277_9: Space = routine_165(c, &v1276_3_cursor.path()[v1276_3_origin..v1276_3_depth], &(*v1276_3_arg_1), &(*v1276_3_arg_2), &(*v1276_3_arg_3), &(*v1276_3_arg_4), &(*v1276_3_arg_5), &(*v1276_3_arg_6), &((*v1276_3_arg_8).read_zipper()));
        join_wrapped_into(&mut v1276_3_write,&((v1277_9).read_zipper()),&[]);
        }
        v1276_3_more = next_value_within(&mut v1276_3_cursor,v1276_3_origin);
      }
      drop(v1276_3_cursor);
      drop(v1276_3_write);
      map_map_kernels::compose(&(v1274_13),&(v1276_3))
    };
    let v1275_6: Space = if (&(v1274_19)).is_empty() { Space::new() } else {
      let v1278_2: Path = concat_path(&(*p1),&v1274_20_cursor.path()[v1274_20_origin..(v1274_20_origin + 1)]);
      let mut v1278_5 = Space::new();
      let mut v1278_5_write = v1278_5.write_zipper();
      for v1278_5_byte in v1274_20_cursor.child_mask().iter() {
        v1274_20_cursor.descend_to_existing_byte(v1278_5_byte);
        {
        let v1279_2: Space = routine_166(c, &v1274_20_cursor.path()[(v1274_20_origin + 1)..(v1274_20_origin + 2)], &v1274_20_cursor.path()[(v1274_20_origin + 1)..(v1274_20_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1278_2), &v1274_20_cursor);
        join_wrapped_into(&mut v1278_5_write,&((v1279_2).read_zipper()),&[]);
        }
        v1274_20_cursor.ascend(1);
      }
      drop(v1278_5_write);
      drop(v1278_2);
      map_map_kernels::compose(&(v1274_19),&(v1278_5))
    };
    let v1275_7: Space = map_map_kernels::unite(&(v1275_4),&(v1275_6));
    join_wrapped_into(&mut v1274_20_write,&((v1275_7).read_zipper()),&[]);
    }
    v1274_20_cursor.ascend(1);
  }
  drop(v1274_20_cursor);
  drop(v1274_20_write);
  drop(v1274_13);
  drop(v1274_19);
  (v1274_20).clone()
}

fn routine_166(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v1280_11: Space = singleton(&(*p1));
  let v1280_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1280_11));
  let v1280_13: Space = if map_kernels::has_head(&(v1280_12)) { singleton(&[]) } else { Space::new() };
  drop(v1280_12);
  let v1280_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1280_13));
  drop(v1280_13);
  let v1280_25: Space = if (&(v1280_14)).is_empty() { Space::new() } else {
    let v1281_17: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1281_20: Space = if (&(v1281_17)).is_empty() { Space::new() } else {
      let v1282_19: Space = routine_183(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*s0));
      map_map_kernels::compose(&(v1281_17),&(v1282_19))
    };
    drop(v1281_17);
    let mut v1281_23 = Space::new();
    let mut v1281_23_write = v1281_23.write_zipper();
    let mut v1281_23_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1281_23_origin = v1281_23_cursor.path().len();
    for v1281_23_byte in v1281_23_cursor.child_mask().iter() {
      v1281_23_cursor.descend_to_existing_byte(v1281_23_byte);
      {
      let v1283_2_arg_0: &[u8] = &v1281_23_cursor.path()[v1281_23_origin..(v1281_23_origin + 1)];
      let v1283_2_arg_1: &[u8] = &(*p0);
      let v1283_2_arg_2: &[u8] = &(*p2);
      let v1283_2_arg_3: &[u8] = &(*p3);
      let v1283_2_arg_4: &[u8] = &(*p4);
      let v1283_2_arg_5: &[u8] = &(*p5);
      let v1283_2_arg_6: &[u8] = &(*p6);
      let v1283_2_arg_7: &[u8] = &(*p7);
      let v1283_2_arg_9: &Space = &(&(*s0)).make_map();
      let mut v1283_2_more = v1281_23_cursor.is_val() || next_value_within(&mut v1281_23_cursor,(v1281_23_origin + 1));
      while v1283_2_more {
        {
        let v1283_2_depth = v1281_23_cursor.path().len();
        let mut v1284_10_cursor = (*v1283_2_arg_9).read_zipper();
        let v1284_10_origin = v1284_10_cursor.path().len();
        for v1284_10_byte in v1284_10_cursor.child_mask().iter() {
          v1284_10_cursor.descend_to_existing_byte(v1284_10_byte);
          {
          let v1285_2: Path = concat_path(&(*v1283_2_arg_1),&v1284_10_cursor.path()[v1284_10_origin..(v1284_10_origin + 1)]);
          let v1285_3: Space = routine_166(c, &(v1285_2), &v1281_23_cursor.path()[v1281_23_origin..v1283_2_depth], &(*v1283_2_arg_2), &(*v1283_2_arg_3), &(*v1283_2_arg_4), &(*v1283_2_arg_5), &(*v1283_2_arg_6), &(*v1283_2_arg_7), &v1284_10_cursor);
          drop(v1285_2);
          join_wrapped_into(&mut v1281_23_write,&((v1285_3).read_zipper()),&[]);
          }
          v1284_10_cursor.ascend(1);
        }
        drop(v1284_10_cursor);
        }
        v1283_2_more = next_value_within(&mut v1281_23_cursor,(v1281_23_origin + 1));
      }
      }
      v1281_23_cursor.ascend(1);
    }
    drop(v1281_23_cursor);
    drop(v1281_23_write);
    let v1281_24: Space = map_map_kernels::unite(&(v1281_20),&(v1281_23));
    map_map_kernels::compose(&(v1280_14),&(v1281_24))
  };
  drop(v1280_14);
  let v1280_27: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1280_11));
  drop(v1280_11);
  let v1280_28: Space = if map_kernels::has_head(&(v1280_27)) { singleton(&[]) } else { Space::new() };
  drop(v1280_27);
  let v1280_30: Space = if (&(v1280_28)).is_empty() { Space::new() } else {
    let mut v1286_29 = Space::new();
    let mut v1286_29_write = v1286_29.write_zipper();
    let mut v1286_29_cursor = (*s0).read_zipper();
    let v1286_29_origin = v1286_29_cursor.path().len();
    for v1286_29_byte in v1286_29_cursor.child_mask().iter() {
      v1286_29_cursor.descend_to_existing_byte(v1286_29_byte);
      {
      let v1287_2: Space = routine_184(c, &v1286_29_cursor.path()[v1286_29_origin..(v1286_29_origin + 1)], &v1286_29_cursor.path()[v1286_29_origin..(v1286_29_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p0), &v1286_29_cursor);
      join_wrapped_into(&mut v1286_29_write,&((v1287_2).read_zipper()),&[]);
      }
      v1286_29_cursor.ascend(1);
    }
    drop(v1286_29_cursor);
    drop(v1286_29_write);
    map_map_kernels::compose(&(v1280_28),&(v1286_29))
  };
  drop(v1280_28);
  let v1280_31: Space = map_map_kernels::unite(&(v1280_25),&(v1280_30));
  (v1280_31).clone()
}

fn routine_167(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v1288_10: Space = singleton(&(*p0));
  let v1288_11: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1288_10));
  let v1288_12: Space = if map_kernels::has_head(&(v1288_11)) { singleton(&[]) } else { Space::new() };
  drop(v1288_11);
  let v1288_13: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1288_12));
  drop(v1288_12);
  let v1288_18: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1288_10));
  drop(v1288_10);
  let v1288_19: Space = if map_kernels::has_head(&(v1288_18)) { singleton(&[]) } else { Space::new() };
  drop(v1288_18);
  let mut v1288_20 = Space::new();
  let mut v1288_20_write = v1288_20.write_zipper();
  let mut v1288_20_cursor = (*s0).read_zipper();
  let v1288_20_origin = v1288_20_cursor.path().len();
  for v1288_20_byte in v1288_20_cursor.child_mask().iter() {
    v1288_20_cursor.descend_to_existing_byte(v1288_20_byte);
    {
    let v1289_4: Space = if (&(v1288_13)).is_empty() { Space::new() } else {
      let v1290_2: Path = concat_path(&(*p1),&v1288_20_cursor.path()[v1288_20_origin..(v1288_20_origin + 1)]);
      let mut v1290_3 = Space::new();
      let mut v1290_3_write = v1290_3.write_zipper();
      let v1290_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1290_3_arg_1: &[u8] = &(v1290_2);
      let v1290_3_arg_2: &[u8] = &(*p2);
      let v1290_3_arg_3: &[u8] = &(*p3);
      let v1290_3_arg_4: &[u8] = &(*p4);
      let v1290_3_arg_5: &[u8] = &(*p5);
      let v1290_3_arg_6: &[u8] = &(*p6);
      let v1290_3_arg_8: &Space = &(&v1288_20_cursor).make_map();
      let mut v1290_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1290_3_origin = v1290_3_cursor.path().len();
      let mut v1290_3_more = v1290_3_cursor.is_val() || next_value_within(&mut v1290_3_cursor,v1290_3_origin);
      while v1290_3_more {
        {
        let v1290_3_depth = v1290_3_cursor.path().len();
        let v1291_9: Space = routine_167(c, &v1290_3_cursor.path()[v1290_3_origin..v1290_3_depth], &(*v1290_3_arg_1), &(*v1290_3_arg_2), &(*v1290_3_arg_3), &(*v1290_3_arg_4), &(*v1290_3_arg_5), &(*v1290_3_arg_6), &((*v1290_3_arg_8).read_zipper()));
        join_wrapped_into(&mut v1290_3_write,&((v1291_9).read_zipper()),&[]);
        }
        v1290_3_more = next_value_within(&mut v1290_3_cursor,v1290_3_origin);
      }
      drop(v1290_3_cursor);
      drop(v1290_3_write);
      map_map_kernels::compose(&(v1288_13),&(v1290_3))
    };
    let v1289_6: Space = if (&(v1288_19)).is_empty() { Space::new() } else {
      let v1292_2: Path = concat_path(&(*p1),&v1288_20_cursor.path()[v1288_20_origin..(v1288_20_origin + 1)]);
      let mut v1292_5 = Space::new();
      let mut v1292_5_write = v1292_5.write_zipper();
      for v1292_5_byte in v1288_20_cursor.child_mask().iter() {
        v1288_20_cursor.descend_to_existing_byte(v1292_5_byte);
        {
        let v1293_2: Space = routine_168(c, &v1288_20_cursor.path()[(v1288_20_origin + 1)..(v1288_20_origin + 2)], &v1288_20_cursor.path()[(v1288_20_origin + 1)..(v1288_20_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1292_2), &v1288_20_cursor);
        join_wrapped_into(&mut v1292_5_write,&((v1293_2).read_zipper()),&[]);
        }
        v1288_20_cursor.ascend(1);
      }
      drop(v1292_5_write);
      drop(v1292_2);
      map_map_kernels::compose(&(v1288_19),&(v1292_5))
    };
    let v1289_7: Space = map_map_kernels::unite(&(v1289_4),&(v1289_6));
    join_wrapped_into(&mut v1288_20_write,&((v1289_7).read_zipper()),&[]);
    }
    v1288_20_cursor.ascend(1);
  }
  drop(v1288_20_cursor);
  drop(v1288_20_write);
  drop(v1288_13);
  drop(v1288_19);
  (v1288_20).clone()
}

fn routine_168(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v1294_11: Space = singleton(&(*p1));
  let v1294_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1294_11));
  let v1294_13: Space = if map_kernels::has_head(&(v1294_12)) { singleton(&[]) } else { Space::new() };
  drop(v1294_12);
  let v1294_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1294_13));
  drop(v1294_13);
  let v1294_25: Space = if (&(v1294_14)).is_empty() { Space::new() } else {
    let v1295_17: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1295_20: Space = if (&(v1295_17)).is_empty() { Space::new() } else {
      let v1296_19: Space = routine_185(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*s0));
      map_map_kernels::compose(&(v1295_17),&(v1296_19))
    };
    drop(v1295_17);
    let mut v1295_23 = Space::new();
    let mut v1295_23_write = v1295_23.write_zipper();
    let mut v1295_23_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1295_23_origin = v1295_23_cursor.path().len();
    for v1295_23_byte in v1295_23_cursor.child_mask().iter() {
      v1295_23_cursor.descend_to_existing_byte(v1295_23_byte);
      {
      let v1297_2_arg_0: &[u8] = &v1295_23_cursor.path()[v1295_23_origin..(v1295_23_origin + 1)];
      let v1297_2_arg_1: &[u8] = &(*p0);
      let v1297_2_arg_2: &[u8] = &(*p2);
      let v1297_2_arg_3: &[u8] = &(*p3);
      let v1297_2_arg_4: &[u8] = &(*p4);
      let v1297_2_arg_5: &[u8] = &(*p5);
      let v1297_2_arg_6: &[u8] = &(*p6);
      let v1297_2_arg_7: &[u8] = &(*p7);
      let v1297_2_arg_9: &Space = &(&(*s0)).make_map();
      let mut v1297_2_more = v1295_23_cursor.is_val() || next_value_within(&mut v1295_23_cursor,(v1295_23_origin + 1));
      while v1297_2_more {
        {
        let v1297_2_depth = v1295_23_cursor.path().len();
        let mut v1298_10_cursor = (*v1297_2_arg_9).read_zipper();
        let v1298_10_origin = v1298_10_cursor.path().len();
        for v1298_10_byte in v1298_10_cursor.child_mask().iter() {
          v1298_10_cursor.descend_to_existing_byte(v1298_10_byte);
          {
          let v1299_2: Path = concat_path(&(*v1297_2_arg_1),&v1298_10_cursor.path()[v1298_10_origin..(v1298_10_origin + 1)]);
          let v1299_3: Space = routine_168(c, &(v1299_2), &v1295_23_cursor.path()[v1295_23_origin..v1297_2_depth], &(*v1297_2_arg_2), &(*v1297_2_arg_3), &(*v1297_2_arg_4), &(*v1297_2_arg_5), &(*v1297_2_arg_6), &(*v1297_2_arg_7), &v1298_10_cursor);
          drop(v1299_2);
          join_wrapped_into(&mut v1295_23_write,&((v1299_3).read_zipper()),&[]);
          }
          v1298_10_cursor.ascend(1);
        }
        drop(v1298_10_cursor);
        }
        v1297_2_more = next_value_within(&mut v1295_23_cursor,(v1295_23_origin + 1));
      }
      }
      v1295_23_cursor.ascend(1);
    }
    drop(v1295_23_cursor);
    drop(v1295_23_write);
    let v1295_24: Space = map_map_kernels::unite(&(v1295_20),&(v1295_23));
    map_map_kernels::compose(&(v1294_14),&(v1295_24))
  };
  drop(v1294_14);
  let v1294_27: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1294_11));
  drop(v1294_11);
  let v1294_28: Space = if map_kernels::has_head(&(v1294_27)) { singleton(&[]) } else { Space::new() };
  drop(v1294_27);
  let v1294_30: Space = if (&(v1294_28)).is_empty() { Space::new() } else {
    let mut v1300_29 = Space::new();
    let mut v1300_29_write = v1300_29.write_zipper();
    let mut v1300_29_cursor = (*s0).read_zipper();
    let v1300_29_origin = v1300_29_cursor.path().len();
    for v1300_29_byte in v1300_29_cursor.child_mask().iter() {
      v1300_29_cursor.descend_to_existing_byte(v1300_29_byte);
      {
      let v1301_2: Space = routine_186(c, &v1300_29_cursor.path()[v1300_29_origin..(v1300_29_origin + 1)], &v1300_29_cursor.path()[v1300_29_origin..(v1300_29_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p0), &v1300_29_cursor);
      join_wrapped_into(&mut v1300_29_write,&((v1301_2).read_zipper()),&[]);
      }
      v1300_29_cursor.ascend(1);
    }
    drop(v1300_29_cursor);
    drop(v1300_29_write);
    map_map_kernels::compose(&(v1294_28),&(v1300_29))
  };
  drop(v1294_28);
  let v1294_31: Space = map_map_kernels::unite(&(v1294_25),&(v1294_30));
  (v1294_31).clone()
}

fn routine_169(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v1302_11: Space = singleton(&(*p0));
  let v1302_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1302_11));
  let v1302_13: Space = if map_kernels::has_head(&(v1302_12)) { singleton(&[]) } else { Space::new() };
  drop(v1302_12);
  let v1302_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1302_13));
  drop(v1302_13);
  let v1302_19: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1302_11));
  drop(v1302_11);
  let v1302_20: Space = if map_kernels::has_head(&(v1302_19)) { singleton(&[]) } else { Space::new() };
  drop(v1302_19);
  let mut v1302_21 = Space::new();
  let mut v1302_21_write = v1302_21.write_zipper();
  let mut v1302_21_cursor = (*s0).read_zipper();
  let v1302_21_origin = v1302_21_cursor.path().len();
  for v1302_21_byte in v1302_21_cursor.child_mask().iter() {
    v1302_21_cursor.descend_to_existing_byte(v1302_21_byte);
    {
    let v1303_4: Space = if (&(v1302_14)).is_empty() { Space::new() } else {
      let v1304_2: Path = concat_path(&(*p1),&v1302_21_cursor.path()[v1302_21_origin..(v1302_21_origin + 1)]);
      let mut v1304_3 = Space::new();
      let mut v1304_3_write = v1304_3.write_zipper();
      let v1304_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1304_3_arg_1: &[u8] = &(v1304_2);
      let v1304_3_arg_2: &[u8] = &(*p2);
      let v1304_3_arg_3: &[u8] = &(*p3);
      let v1304_3_arg_4: &[u8] = &(*p4);
      let v1304_3_arg_5: &[u8] = &(*p5);
      let v1304_3_arg_6: &[u8] = &(*p6);
      let v1304_3_arg_7: &[u8] = &(*p7);
      let v1304_3_arg_9: &Space = &(&v1302_21_cursor).make_map();
      let mut v1304_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1304_3_origin = v1304_3_cursor.path().len();
      let mut v1304_3_more = v1304_3_cursor.is_val() || next_value_within(&mut v1304_3_cursor,v1304_3_origin);
      while v1304_3_more {
        {
        let v1304_3_depth = v1304_3_cursor.path().len();
        let v1305_10: Space = routine_169(c, &v1304_3_cursor.path()[v1304_3_origin..v1304_3_depth], &(*v1304_3_arg_1), &(*v1304_3_arg_2), &(*v1304_3_arg_3), &(*v1304_3_arg_4), &(*v1304_3_arg_5), &(*v1304_3_arg_6), &(*v1304_3_arg_7), &((*v1304_3_arg_9).read_zipper()));
        join_wrapped_into(&mut v1304_3_write,&((v1305_10).read_zipper()),&[]);
        }
        v1304_3_more = next_value_within(&mut v1304_3_cursor,v1304_3_origin);
      }
      drop(v1304_3_cursor);
      drop(v1304_3_write);
      map_map_kernels::compose(&(v1302_14),&(v1304_3))
    };
    let v1303_6: Space = if (&(v1302_20)).is_empty() { Space::new() } else {
      let v1306_2: Path = concat_path(&(*p1),&v1302_21_cursor.path()[v1302_21_origin..(v1302_21_origin + 1)]);
      let mut v1306_5 = Space::new();
      let mut v1306_5_write = v1306_5.write_zipper();
      for v1306_5_byte in v1302_21_cursor.child_mask().iter() {
        v1302_21_cursor.descend_to_existing_byte(v1306_5_byte);
        {
        let v1307_2: Space = routine_170(c, &v1302_21_cursor.path()[(v1302_21_origin + 1)..(v1302_21_origin + 2)], &v1302_21_cursor.path()[(v1302_21_origin + 1)..(v1302_21_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v1306_2), &v1302_21_cursor);
        join_wrapped_into(&mut v1306_5_write,&((v1307_2).read_zipper()),&[]);
        }
        v1302_21_cursor.ascend(1);
      }
      drop(v1306_5_write);
      drop(v1306_2);
      map_map_kernels::compose(&(v1302_20),&(v1306_5))
    };
    let v1303_7: Space = map_map_kernels::unite(&(v1303_4),&(v1303_6));
    join_wrapped_into(&mut v1302_21_write,&((v1303_7).read_zipper()),&[]);
    }
    v1302_21_cursor.ascend(1);
  }
  drop(v1302_21_cursor);
  drop(v1302_21_write);
  drop(v1302_14);
  drop(v1302_20);
  (v1302_21).clone()
}

fn routine_170(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v1308_12: Space = singleton(&(*p1));
  let v1308_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1308_12));
  let v1308_14: Space = if map_kernels::has_head(&(v1308_13)) { singleton(&[]) } else { Space::new() };
  drop(v1308_13);
  let v1308_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1308_14));
  drop(v1308_14);
  let v1308_26: Space = if (&(v1308_15)).is_empty() { Space::new() } else {
    let v1309_18: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1309_21: Space = if (&(v1309_18)).is_empty() { Space::new() } else {
      let v1310_20: Space = routine_187(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*s0));
      map_map_kernels::compose(&(v1309_18),&(v1310_20))
    };
    drop(v1309_18);
    let mut v1309_24 = Space::new();
    let mut v1309_24_write = v1309_24.write_zipper();
    let mut v1309_24_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1309_24_origin = v1309_24_cursor.path().len();
    for v1309_24_byte in v1309_24_cursor.child_mask().iter() {
      v1309_24_cursor.descend_to_existing_byte(v1309_24_byte);
      {
      let v1311_2_arg_0: &[u8] = &v1309_24_cursor.path()[v1309_24_origin..(v1309_24_origin + 1)];
      let v1311_2_arg_1: &[u8] = &(*p0);
      let v1311_2_arg_2: &[u8] = &(*p2);
      let v1311_2_arg_3: &[u8] = &(*p3);
      let v1311_2_arg_4: &[u8] = &(*p4);
      let v1311_2_arg_5: &[u8] = &(*p5);
      let v1311_2_arg_6: &[u8] = &(*p6);
      let v1311_2_arg_7: &[u8] = &(*p7);
      let v1311_2_arg_8: &[u8] = &(*p8);
      let v1311_2_arg_10: &Space = &(&(*s0)).make_map();
      let mut v1311_2_more = v1309_24_cursor.is_val() || next_value_within(&mut v1309_24_cursor,(v1309_24_origin + 1));
      while v1311_2_more {
        {
        let v1311_2_depth = v1309_24_cursor.path().len();
        let mut v1312_11_cursor = (*v1311_2_arg_10).read_zipper();
        let v1312_11_origin = v1312_11_cursor.path().len();
        for v1312_11_byte in v1312_11_cursor.child_mask().iter() {
          v1312_11_cursor.descend_to_existing_byte(v1312_11_byte);
          {
          let v1313_2: Path = concat_path(&(*v1311_2_arg_1),&v1312_11_cursor.path()[v1312_11_origin..(v1312_11_origin + 1)]);
          let v1313_3: Space = routine_170(c, &(v1313_2), &v1309_24_cursor.path()[v1309_24_origin..v1311_2_depth], &(*v1311_2_arg_2), &(*v1311_2_arg_3), &(*v1311_2_arg_4), &(*v1311_2_arg_5), &(*v1311_2_arg_6), &(*v1311_2_arg_7), &(*v1311_2_arg_8), &v1312_11_cursor);
          drop(v1313_2);
          join_wrapped_into(&mut v1309_24_write,&((v1313_3).read_zipper()),&[]);
          }
          v1312_11_cursor.ascend(1);
        }
        drop(v1312_11_cursor);
        }
        v1311_2_more = next_value_within(&mut v1309_24_cursor,(v1309_24_origin + 1));
      }
      }
      v1309_24_cursor.ascend(1);
    }
    drop(v1309_24_cursor);
    drop(v1309_24_write);
    let v1309_25: Space = map_map_kernels::unite(&(v1309_21),&(v1309_24));
    map_map_kernels::compose(&(v1308_15),&(v1309_25))
  };
  drop(v1308_15);
  let v1308_28: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1308_12));
  drop(v1308_12);
  let v1308_29: Space = if map_kernels::has_head(&(v1308_28)) { singleton(&[]) } else { Space::new() };
  drop(v1308_28);
  let v1308_63: Space = if (&(v1308_29)).is_empty() { Space::new() } else {
    let v1314_32: Path = concat_path(&(*CONSTANT_18),&(*p2));
    let v1314_33: Space = singleton(&(v1314_32));
    drop(v1314_32);
    let v1314_34: Space = map_map_kernels::unite(&(*CONSTANT_27),&(v1314_33));
    drop(v1314_33);
    let v1314_36: Path = concat_path(&(*CONSTANT_19),&(*p3));
    let v1314_37: Space = singleton(&(v1314_36));
    drop(v1314_36);
    let v1314_38: Space = map_map_kernels::unite(&(v1314_34),&(v1314_37));
    drop(v1314_34);
    drop(v1314_37);
    let v1314_40: Path = concat_path(&(*CONSTANT_20),&(*p4));
    let v1314_41: Space = singleton(&(v1314_40));
    drop(v1314_40);
    let v1314_42: Space = map_map_kernels::unite(&(v1314_38),&(v1314_41));
    drop(v1314_38);
    drop(v1314_41);
    let v1314_44: Path = concat_path(&(*CONSTANT_21),&(*p5));
    let v1314_45: Space = singleton(&(v1314_44));
    drop(v1314_44);
    let v1314_46: Space = map_map_kernels::unite(&(v1314_42),&(v1314_45));
    drop(v1314_42);
    drop(v1314_45);
    let v1314_48: Path = concat_path(&(*CONSTANT_22),&(*p6));
    let v1314_49: Space = singleton(&(v1314_48));
    drop(v1314_48);
    let v1314_50: Space = map_map_kernels::unite(&(v1314_46),&(v1314_49));
    drop(v1314_46);
    drop(v1314_49);
    let v1314_52: Path = concat_path(&(*CONSTANT_23),&(*p7));
    let v1314_53: Space = singleton(&(v1314_52));
    drop(v1314_52);
    let v1314_54: Space = map_map_kernels::unite(&(v1314_50),&(v1314_53));
    drop(v1314_50);
    drop(v1314_53);
    let v1314_56: Path = concat_path(&(*CONSTANT_24),&(*p8));
    let v1314_57: Space = singleton(&(v1314_56));
    drop(v1314_56);
    let v1314_58: Space = map_map_kernels::unite(&(v1314_54),&(v1314_57));
    drop(v1314_54);
    drop(v1314_57);
    let v1314_60: Path = concat_path(&(*CONSTANT_25),&(*p0));
    let v1314_61: Space = singleton(&(v1314_60));
    drop(v1314_60);
    let v1314_62: Space = map_map_kernels::unite(&(v1314_58),&(v1314_61));
    drop(v1314_58);
    drop(v1314_61);
    map_map_kernels::compose(&(v1308_29),&(v1314_62))
  };
  drop(v1308_29);
  let v1308_64: Space = map_map_kernels::unite(&(v1308_26),&(v1308_63));
  drop(v1308_63);
  (v1308_64).clone()
}

fn routine_171(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v1315_11: Space = singleton(&(*p0));
  let v1315_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1315_11));
  let v1315_13: Space = if map_kernels::has_head(&(v1315_12)) { singleton(&[]) } else { Space::new() };
  drop(v1315_12);
  let v1315_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1315_13));
  drop(v1315_13);
  let v1315_19: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1315_11));
  drop(v1315_11);
  let v1315_20: Space = if map_kernels::has_head(&(v1315_19)) { singleton(&[]) } else { Space::new() };
  drop(v1315_19);
  let mut v1315_21 = Space::new();
  let mut v1315_21_write = v1315_21.write_zipper();
  let mut v1315_21_cursor = (*s0).read_zipper();
  let v1315_21_origin = v1315_21_cursor.path().len();
  for v1315_21_byte in v1315_21_cursor.child_mask().iter() {
    v1315_21_cursor.descend_to_existing_byte(v1315_21_byte);
    {
    let v1316_4: Space = if (&(v1315_14)).is_empty() { Space::new() } else {
      let v1317_2: Path = concat_path(&(*p1),&v1315_21_cursor.path()[v1315_21_origin..(v1315_21_origin + 1)]);
      let mut v1317_3 = Space::new();
      let mut v1317_3_write = v1317_3.write_zipper();
      let v1317_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1317_3_arg_1: &[u8] = &(v1317_2);
      let v1317_3_arg_2: &[u8] = &(*p2);
      let v1317_3_arg_3: &[u8] = &(*p3);
      let v1317_3_arg_4: &[u8] = &(*p4);
      let v1317_3_arg_5: &[u8] = &(*p5);
      let v1317_3_arg_6: &[u8] = &(*p6);
      let v1317_3_arg_7: &[u8] = &(*p7);
      let v1317_3_arg_9: &Space = &(&v1315_21_cursor).make_map();
      let mut v1317_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1317_3_origin = v1317_3_cursor.path().len();
      let mut v1317_3_more = v1317_3_cursor.is_val() || next_value_within(&mut v1317_3_cursor,v1317_3_origin);
      while v1317_3_more {
        {
        let v1317_3_depth = v1317_3_cursor.path().len();
        let v1318_10: Space = routine_171(c, &v1317_3_cursor.path()[v1317_3_origin..v1317_3_depth], &(*v1317_3_arg_1), &(*v1317_3_arg_2), &(*v1317_3_arg_3), &(*v1317_3_arg_4), &(*v1317_3_arg_5), &(*v1317_3_arg_6), &(*v1317_3_arg_7), &((*v1317_3_arg_9).read_zipper()));
        join_wrapped_into(&mut v1317_3_write,&((v1318_10).read_zipper()),&[]);
        }
        v1317_3_more = next_value_within(&mut v1317_3_cursor,v1317_3_origin);
      }
      drop(v1317_3_cursor);
      drop(v1317_3_write);
      map_map_kernels::compose(&(v1315_14),&(v1317_3))
    };
    let v1316_6: Space = if (&(v1315_20)).is_empty() { Space::new() } else {
      let v1319_2: Path = concat_path(&(*p1),&v1315_21_cursor.path()[v1315_21_origin..(v1315_21_origin + 1)]);
      let mut v1319_5 = Space::new();
      let mut v1319_5_write = v1319_5.write_zipper();
      for v1319_5_byte in v1315_21_cursor.child_mask().iter() {
        v1315_21_cursor.descend_to_existing_byte(v1319_5_byte);
        {
        let v1320_2: Space = routine_172(c, &v1315_21_cursor.path()[(v1315_21_origin + 1)..(v1315_21_origin + 2)], &v1315_21_cursor.path()[(v1315_21_origin + 1)..(v1315_21_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v1319_2), &v1315_21_cursor);
        join_wrapped_into(&mut v1319_5_write,&((v1320_2).read_zipper()),&[]);
        }
        v1315_21_cursor.ascend(1);
      }
      drop(v1319_5_write);
      drop(v1319_2);
      map_map_kernels::compose(&(v1315_20),&(v1319_5))
    };
    let v1316_7: Space = map_map_kernels::unite(&(v1316_4),&(v1316_6));
    join_wrapped_into(&mut v1315_21_write,&((v1316_7).read_zipper()),&[]);
    }
    v1315_21_cursor.ascend(1);
  }
  drop(v1315_21_cursor);
  drop(v1315_21_write);
  drop(v1315_14);
  drop(v1315_20);
  (v1315_21).clone()
}

fn routine_172(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v1321_12: Space = singleton(&(*p1));
  let v1321_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1321_12));
  let v1321_14: Space = if map_kernels::has_head(&(v1321_13)) { singleton(&[]) } else { Space::new() };
  drop(v1321_13);
  let v1321_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1321_14));
  drop(v1321_14);
  let v1321_26: Space = if (&(v1321_15)).is_empty() { Space::new() } else {
    let v1322_18: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1322_21: Space = if (&(v1322_18)).is_empty() { Space::new() } else {
      let v1323_20: Space = routine_188(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*s0));
      map_map_kernels::compose(&(v1322_18),&(v1323_20))
    };
    drop(v1322_18);
    let mut v1322_24 = Space::new();
    let mut v1322_24_write = v1322_24.write_zipper();
    let mut v1322_24_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1322_24_origin = v1322_24_cursor.path().len();
    for v1322_24_byte in v1322_24_cursor.child_mask().iter() {
      v1322_24_cursor.descend_to_existing_byte(v1322_24_byte);
      {
      let v1324_2_arg_0: &[u8] = &v1322_24_cursor.path()[v1322_24_origin..(v1322_24_origin + 1)];
      let v1324_2_arg_1: &[u8] = &(*p0);
      let v1324_2_arg_2: &[u8] = &(*p2);
      let v1324_2_arg_3: &[u8] = &(*p3);
      let v1324_2_arg_4: &[u8] = &(*p4);
      let v1324_2_arg_5: &[u8] = &(*p5);
      let v1324_2_arg_6: &[u8] = &(*p6);
      let v1324_2_arg_7: &[u8] = &(*p7);
      let v1324_2_arg_8: &[u8] = &(*p8);
      let v1324_2_arg_10: &Space = &(&(*s0)).make_map();
      let mut v1324_2_more = v1322_24_cursor.is_val() || next_value_within(&mut v1322_24_cursor,(v1322_24_origin + 1));
      while v1324_2_more {
        {
        let v1324_2_depth = v1322_24_cursor.path().len();
        let mut v1325_11_cursor = (*v1324_2_arg_10).read_zipper();
        let v1325_11_origin = v1325_11_cursor.path().len();
        for v1325_11_byte in v1325_11_cursor.child_mask().iter() {
          v1325_11_cursor.descend_to_existing_byte(v1325_11_byte);
          {
          let v1326_2: Path = concat_path(&(*v1324_2_arg_1),&v1325_11_cursor.path()[v1325_11_origin..(v1325_11_origin + 1)]);
          let v1326_3: Space = routine_172(c, &(v1326_2), &v1322_24_cursor.path()[v1322_24_origin..v1324_2_depth], &(*v1324_2_arg_2), &(*v1324_2_arg_3), &(*v1324_2_arg_4), &(*v1324_2_arg_5), &(*v1324_2_arg_6), &(*v1324_2_arg_7), &(*v1324_2_arg_8), &v1325_11_cursor);
          drop(v1326_2);
          join_wrapped_into(&mut v1322_24_write,&((v1326_3).read_zipper()),&[]);
          }
          v1325_11_cursor.ascend(1);
        }
        drop(v1325_11_cursor);
        }
        v1324_2_more = next_value_within(&mut v1322_24_cursor,(v1322_24_origin + 1));
      }
      }
      v1322_24_cursor.ascend(1);
    }
    drop(v1322_24_cursor);
    drop(v1322_24_write);
    let v1322_25: Space = map_map_kernels::unite(&(v1322_21),&(v1322_24));
    map_map_kernels::compose(&(v1321_15),&(v1322_25))
  };
  drop(v1321_15);
  let v1321_28: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1321_12));
  drop(v1321_12);
  let v1321_29: Space = if map_kernels::has_head(&(v1321_28)) { singleton(&[]) } else { Space::new() };
  drop(v1321_28);
  let v1321_63: Space = if (&(v1321_29)).is_empty() { Space::new() } else {
    let v1327_32: Path = concat_path(&(*CONSTANT_26),&(*p2));
    let v1327_33: Space = singleton(&(v1327_32));
    drop(v1327_32);
    let v1327_34: Space = map_map_kernels::unite(&(*CONSTANT_28),&(v1327_33));
    drop(v1327_33);
    let v1327_36: Path = concat_path(&(*CONSTANT_19),&(*p3));
    let v1327_37: Space = singleton(&(v1327_36));
    drop(v1327_36);
    let v1327_38: Space = map_map_kernels::unite(&(v1327_34),&(v1327_37));
    drop(v1327_34);
    drop(v1327_37);
    let v1327_40: Path = concat_path(&(*CONSTANT_20),&(*p4));
    let v1327_41: Space = singleton(&(v1327_40));
    drop(v1327_40);
    let v1327_42: Space = map_map_kernels::unite(&(v1327_38),&(v1327_41));
    drop(v1327_38);
    drop(v1327_41);
    let v1327_44: Path = concat_path(&(*CONSTANT_21),&(*p5));
    let v1327_45: Space = singleton(&(v1327_44));
    drop(v1327_44);
    let v1327_46: Space = map_map_kernels::unite(&(v1327_42),&(v1327_45));
    drop(v1327_42);
    drop(v1327_45);
    let v1327_48: Path = concat_path(&(*CONSTANT_22),&(*p6));
    let v1327_49: Space = singleton(&(v1327_48));
    drop(v1327_48);
    let v1327_50: Space = map_map_kernels::unite(&(v1327_46),&(v1327_49));
    drop(v1327_46);
    drop(v1327_49);
    let v1327_52: Path = concat_path(&(*CONSTANT_23),&(*p7));
    let v1327_53: Space = singleton(&(v1327_52));
    drop(v1327_52);
    let v1327_54: Space = map_map_kernels::unite(&(v1327_50),&(v1327_53));
    drop(v1327_50);
    drop(v1327_53);
    let v1327_56: Path = concat_path(&(*CONSTANT_24),&(*p8));
    let v1327_57: Space = singleton(&(v1327_56));
    drop(v1327_56);
    let v1327_58: Space = map_map_kernels::unite(&(v1327_54),&(v1327_57));
    drop(v1327_54);
    drop(v1327_57);
    let v1327_60: Path = concat_path(&(*CONSTANT_25),&(*p0));
    let v1327_61: Space = singleton(&(v1327_60));
    drop(v1327_60);
    let v1327_62: Space = map_map_kernels::unite(&(v1327_58),&(v1327_61));
    drop(v1327_58);
    drop(v1327_61);
    map_map_kernels::compose(&(v1321_29),&(v1327_62))
  };
  drop(v1321_29);
  let v1321_64: Space = map_map_kernels::unite(&(v1321_26),&(v1321_63));
  drop(v1321_63);
  (v1321_64).clone()
}

fn routine_173(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v1328_11: Space = singleton(&(*p0));
  let v1328_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1328_11));
  let v1328_13: Space = if map_kernels::has_head(&(v1328_12)) { singleton(&[]) } else { Space::new() };
  drop(v1328_12);
  let v1328_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1328_13));
  drop(v1328_13);
  let v1328_19: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1328_11));
  drop(v1328_11);
  let v1328_20: Space = if map_kernels::has_head(&(v1328_19)) { singleton(&[]) } else { Space::new() };
  drop(v1328_19);
  let mut v1328_21 = Space::new();
  let mut v1328_21_write = v1328_21.write_zipper();
  let mut v1328_21_cursor = (*s0).read_zipper();
  let v1328_21_origin = v1328_21_cursor.path().len();
  for v1328_21_byte in v1328_21_cursor.child_mask().iter() {
    v1328_21_cursor.descend_to_existing_byte(v1328_21_byte);
    {
    let v1329_4: Space = if (&(v1328_14)).is_empty() { Space::new() } else {
      let v1330_2: Path = concat_path(&(*p1),&v1328_21_cursor.path()[v1328_21_origin..(v1328_21_origin + 1)]);
      let mut v1330_3 = Space::new();
      let mut v1330_3_write = v1330_3.write_zipper();
      let v1330_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1330_3_arg_1: &[u8] = &(v1330_2);
      let v1330_3_arg_2: &[u8] = &(*p2);
      let v1330_3_arg_3: &[u8] = &(*p3);
      let v1330_3_arg_4: &[u8] = &(*p4);
      let v1330_3_arg_5: &[u8] = &(*p5);
      let v1330_3_arg_6: &[u8] = &(*p6);
      let v1330_3_arg_7: &[u8] = &(*p7);
      let v1330_3_arg_9: &Space = &(&v1328_21_cursor).make_map();
      let mut v1330_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1330_3_origin = v1330_3_cursor.path().len();
      let mut v1330_3_more = v1330_3_cursor.is_val() || next_value_within(&mut v1330_3_cursor,v1330_3_origin);
      while v1330_3_more {
        {
        let v1330_3_depth = v1330_3_cursor.path().len();
        let v1331_10: Space = routine_173(c, &v1330_3_cursor.path()[v1330_3_origin..v1330_3_depth], &(*v1330_3_arg_1), &(*v1330_3_arg_2), &(*v1330_3_arg_3), &(*v1330_3_arg_4), &(*v1330_3_arg_5), &(*v1330_3_arg_6), &(*v1330_3_arg_7), &((*v1330_3_arg_9).read_zipper()));
        join_wrapped_into(&mut v1330_3_write,&((v1331_10).read_zipper()),&[]);
        }
        v1330_3_more = next_value_within(&mut v1330_3_cursor,v1330_3_origin);
      }
      drop(v1330_3_cursor);
      drop(v1330_3_write);
      map_map_kernels::compose(&(v1328_14),&(v1330_3))
    };
    let v1329_6: Space = if (&(v1328_20)).is_empty() { Space::new() } else {
      let v1332_2: Path = concat_path(&(*p1),&v1328_21_cursor.path()[v1328_21_origin..(v1328_21_origin + 1)]);
      let mut v1332_5 = Space::new();
      let mut v1332_5_write = v1332_5.write_zipper();
      for v1332_5_byte in v1328_21_cursor.child_mask().iter() {
        v1328_21_cursor.descend_to_existing_byte(v1332_5_byte);
        {
        let v1333_2: Space = routine_174(c, &v1328_21_cursor.path()[(v1328_21_origin + 1)..(v1328_21_origin + 2)], &v1328_21_cursor.path()[(v1328_21_origin + 1)..(v1328_21_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v1332_2), &v1328_21_cursor);
        join_wrapped_into(&mut v1332_5_write,&((v1333_2).read_zipper()),&[]);
        }
        v1328_21_cursor.ascend(1);
      }
      drop(v1332_5_write);
      drop(v1332_2);
      map_map_kernels::compose(&(v1328_20),&(v1332_5))
    };
    let v1329_7: Space = map_map_kernels::unite(&(v1329_4),&(v1329_6));
    join_wrapped_into(&mut v1328_21_write,&((v1329_7).read_zipper()),&[]);
    }
    v1328_21_cursor.ascend(1);
  }
  drop(v1328_21_cursor);
  drop(v1328_21_write);
  drop(v1328_14);
  drop(v1328_20);
  (v1328_21).clone()
}

fn routine_174(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v1334_12: Space = singleton(&(*p1));
  let v1334_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1334_12));
  let v1334_14: Space = if map_kernels::has_head(&(v1334_13)) { singleton(&[]) } else { Space::new() };
  drop(v1334_13);
  let v1334_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1334_14));
  drop(v1334_14);
  let v1334_26: Space = if (&(v1334_15)).is_empty() { Space::new() } else {
    let v1335_18: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1335_21: Space = if (&(v1335_18)).is_empty() { Space::new() } else {
      let v1336_20: Space = routine_189(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*s0));
      map_map_kernels::compose(&(v1335_18),&(v1336_20))
    };
    drop(v1335_18);
    let mut v1335_24 = Space::new();
    let mut v1335_24_write = v1335_24.write_zipper();
    let mut v1335_24_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1335_24_origin = v1335_24_cursor.path().len();
    for v1335_24_byte in v1335_24_cursor.child_mask().iter() {
      v1335_24_cursor.descend_to_existing_byte(v1335_24_byte);
      {
      let v1337_2_arg_0: &[u8] = &v1335_24_cursor.path()[v1335_24_origin..(v1335_24_origin + 1)];
      let v1337_2_arg_1: &[u8] = &(*p0);
      let v1337_2_arg_2: &[u8] = &(*p2);
      let v1337_2_arg_3: &[u8] = &(*p3);
      let v1337_2_arg_4: &[u8] = &(*p4);
      let v1337_2_arg_5: &[u8] = &(*p5);
      let v1337_2_arg_6: &[u8] = &(*p6);
      let v1337_2_arg_7: &[u8] = &(*p7);
      let v1337_2_arg_8: &[u8] = &(*p8);
      let v1337_2_arg_10: &Space = &(&(*s0)).make_map();
      let mut v1337_2_more = v1335_24_cursor.is_val() || next_value_within(&mut v1335_24_cursor,(v1335_24_origin + 1));
      while v1337_2_more {
        {
        let v1337_2_depth = v1335_24_cursor.path().len();
        let mut v1338_11_cursor = (*v1337_2_arg_10).read_zipper();
        let v1338_11_origin = v1338_11_cursor.path().len();
        for v1338_11_byte in v1338_11_cursor.child_mask().iter() {
          v1338_11_cursor.descend_to_existing_byte(v1338_11_byte);
          {
          let v1339_2: Path = concat_path(&(*v1337_2_arg_1),&v1338_11_cursor.path()[v1338_11_origin..(v1338_11_origin + 1)]);
          let v1339_3: Space = routine_174(c, &(v1339_2), &v1335_24_cursor.path()[v1335_24_origin..v1337_2_depth], &(*v1337_2_arg_2), &(*v1337_2_arg_3), &(*v1337_2_arg_4), &(*v1337_2_arg_5), &(*v1337_2_arg_6), &(*v1337_2_arg_7), &(*v1337_2_arg_8), &v1338_11_cursor);
          drop(v1339_2);
          join_wrapped_into(&mut v1335_24_write,&((v1339_3).read_zipper()),&[]);
          }
          v1338_11_cursor.ascend(1);
        }
        drop(v1338_11_cursor);
        }
        v1337_2_more = next_value_within(&mut v1335_24_cursor,(v1335_24_origin + 1));
      }
      }
      v1335_24_cursor.ascend(1);
    }
    drop(v1335_24_cursor);
    drop(v1335_24_write);
    let v1335_25: Space = map_map_kernels::unite(&(v1335_21),&(v1335_24));
    map_map_kernels::compose(&(v1334_15),&(v1335_25))
  };
  drop(v1334_15);
  let v1334_28: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1334_12));
  drop(v1334_12);
  let v1334_29: Space = if map_kernels::has_head(&(v1334_28)) { singleton(&[]) } else { Space::new() };
  drop(v1334_28);
  let v1334_63: Space = if (&(v1334_29)).is_empty() { Space::new() } else {
    let v1340_32: Path = concat_path(&(*CONSTANT_26),&(*p2));
    let v1340_33: Space = singleton(&(v1340_32));
    drop(v1340_32);
    let v1340_34: Space = map_map_kernels::unite(&(*CONSTANT_29),&(v1340_33));
    drop(v1340_33);
    let v1340_36: Path = concat_path(&(*CONSTANT_18),&(*p3));
    let v1340_37: Space = singleton(&(v1340_36));
    drop(v1340_36);
    let v1340_38: Space = map_map_kernels::unite(&(v1340_34),&(v1340_37));
    drop(v1340_34);
    drop(v1340_37);
    let v1340_40: Path = concat_path(&(*CONSTANT_20),&(*p4));
    let v1340_41: Space = singleton(&(v1340_40));
    drop(v1340_40);
    let v1340_42: Space = map_map_kernels::unite(&(v1340_38),&(v1340_41));
    drop(v1340_38);
    drop(v1340_41);
    let v1340_44: Path = concat_path(&(*CONSTANT_21),&(*p5));
    let v1340_45: Space = singleton(&(v1340_44));
    drop(v1340_44);
    let v1340_46: Space = map_map_kernels::unite(&(v1340_42),&(v1340_45));
    drop(v1340_42);
    drop(v1340_45);
    let v1340_48: Path = concat_path(&(*CONSTANT_22),&(*p6));
    let v1340_49: Space = singleton(&(v1340_48));
    drop(v1340_48);
    let v1340_50: Space = map_map_kernels::unite(&(v1340_46),&(v1340_49));
    drop(v1340_46);
    drop(v1340_49);
    let v1340_52: Path = concat_path(&(*CONSTANT_23),&(*p7));
    let v1340_53: Space = singleton(&(v1340_52));
    drop(v1340_52);
    let v1340_54: Space = map_map_kernels::unite(&(v1340_50),&(v1340_53));
    drop(v1340_50);
    drop(v1340_53);
    let v1340_56: Path = concat_path(&(*CONSTANT_24),&(*p8));
    let v1340_57: Space = singleton(&(v1340_56));
    drop(v1340_56);
    let v1340_58: Space = map_map_kernels::unite(&(v1340_54),&(v1340_57));
    drop(v1340_54);
    drop(v1340_57);
    let v1340_60: Path = concat_path(&(*CONSTANT_25),&(*p0));
    let v1340_61: Space = singleton(&(v1340_60));
    drop(v1340_60);
    let v1340_62: Space = map_map_kernels::unite(&(v1340_58),&(v1340_61));
    drop(v1340_58);
    drop(v1340_61);
    map_map_kernels::compose(&(v1334_29),&(v1340_62))
  };
  drop(v1334_29);
  let v1334_64: Space = map_map_kernels::unite(&(v1334_26),&(v1334_63));
  drop(v1334_63);
  (v1334_64).clone()
}

fn routine_175(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v1341_11: Space = singleton(&(*p0));
  let v1341_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1341_11));
  let v1341_13: Space = if map_kernels::has_head(&(v1341_12)) { singleton(&[]) } else { Space::new() };
  drop(v1341_12);
  let v1341_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1341_13));
  drop(v1341_13);
  let v1341_19: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1341_11));
  drop(v1341_11);
  let v1341_20: Space = if map_kernels::has_head(&(v1341_19)) { singleton(&[]) } else { Space::new() };
  drop(v1341_19);
  let mut v1341_21 = Space::new();
  let mut v1341_21_write = v1341_21.write_zipper();
  let mut v1341_21_cursor = (*s0).read_zipper();
  let v1341_21_origin = v1341_21_cursor.path().len();
  for v1341_21_byte in v1341_21_cursor.child_mask().iter() {
    v1341_21_cursor.descend_to_existing_byte(v1341_21_byte);
    {
    let v1342_4: Space = if (&(v1341_14)).is_empty() { Space::new() } else {
      let v1343_2: Path = concat_path(&(*p1),&v1341_21_cursor.path()[v1341_21_origin..(v1341_21_origin + 1)]);
      let mut v1343_3 = Space::new();
      let mut v1343_3_write = v1343_3.write_zipper();
      let v1343_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1343_3_arg_1: &[u8] = &(v1343_2);
      let v1343_3_arg_2: &[u8] = &(*p2);
      let v1343_3_arg_3: &[u8] = &(*p3);
      let v1343_3_arg_4: &[u8] = &(*p4);
      let v1343_3_arg_5: &[u8] = &(*p5);
      let v1343_3_arg_6: &[u8] = &(*p6);
      let v1343_3_arg_7: &[u8] = &(*p7);
      let v1343_3_arg_9: &Space = &(&v1341_21_cursor).make_map();
      let mut v1343_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1343_3_origin = v1343_3_cursor.path().len();
      let mut v1343_3_more = v1343_3_cursor.is_val() || next_value_within(&mut v1343_3_cursor,v1343_3_origin);
      while v1343_3_more {
        {
        let v1343_3_depth = v1343_3_cursor.path().len();
        let v1344_10: Space = routine_175(c, &v1343_3_cursor.path()[v1343_3_origin..v1343_3_depth], &(*v1343_3_arg_1), &(*v1343_3_arg_2), &(*v1343_3_arg_3), &(*v1343_3_arg_4), &(*v1343_3_arg_5), &(*v1343_3_arg_6), &(*v1343_3_arg_7), &((*v1343_3_arg_9).read_zipper()));
        join_wrapped_into(&mut v1343_3_write,&((v1344_10).read_zipper()),&[]);
        }
        v1343_3_more = next_value_within(&mut v1343_3_cursor,v1343_3_origin);
      }
      drop(v1343_3_cursor);
      drop(v1343_3_write);
      map_map_kernels::compose(&(v1341_14),&(v1343_3))
    };
    let v1342_6: Space = if (&(v1341_20)).is_empty() { Space::new() } else {
      let v1345_2: Path = concat_path(&(*p1),&v1341_21_cursor.path()[v1341_21_origin..(v1341_21_origin + 1)]);
      let mut v1345_5 = Space::new();
      let mut v1345_5_write = v1345_5.write_zipper();
      for v1345_5_byte in v1341_21_cursor.child_mask().iter() {
        v1341_21_cursor.descend_to_existing_byte(v1345_5_byte);
        {
        let v1346_2: Space = routine_176(c, &v1341_21_cursor.path()[(v1341_21_origin + 1)..(v1341_21_origin + 2)], &v1341_21_cursor.path()[(v1341_21_origin + 1)..(v1341_21_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v1345_2), &v1341_21_cursor);
        join_wrapped_into(&mut v1345_5_write,&((v1346_2).read_zipper()),&[]);
        }
        v1341_21_cursor.ascend(1);
      }
      drop(v1345_5_write);
      drop(v1345_2);
      map_map_kernels::compose(&(v1341_20),&(v1345_5))
    };
    let v1342_7: Space = map_map_kernels::unite(&(v1342_4),&(v1342_6));
    join_wrapped_into(&mut v1341_21_write,&((v1342_7).read_zipper()),&[]);
    }
    v1341_21_cursor.ascend(1);
  }
  drop(v1341_21_cursor);
  drop(v1341_21_write);
  drop(v1341_14);
  drop(v1341_20);
  (v1341_21).clone()
}

fn routine_176(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v1347_12: Space = singleton(&(*p1));
  let v1347_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1347_12));
  let v1347_14: Space = if map_kernels::has_head(&(v1347_13)) { singleton(&[]) } else { Space::new() };
  drop(v1347_13);
  let v1347_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1347_14));
  drop(v1347_14);
  let v1347_26: Space = if (&(v1347_15)).is_empty() { Space::new() } else {
    let v1348_18: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1348_21: Space = if (&(v1348_18)).is_empty() { Space::new() } else {
      let v1349_20: Space = routine_190(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*s0));
      map_map_kernels::compose(&(v1348_18),&(v1349_20))
    };
    drop(v1348_18);
    let mut v1348_24 = Space::new();
    let mut v1348_24_write = v1348_24.write_zipper();
    let mut v1348_24_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1348_24_origin = v1348_24_cursor.path().len();
    for v1348_24_byte in v1348_24_cursor.child_mask().iter() {
      v1348_24_cursor.descend_to_existing_byte(v1348_24_byte);
      {
      let v1350_2_arg_0: &[u8] = &v1348_24_cursor.path()[v1348_24_origin..(v1348_24_origin + 1)];
      let v1350_2_arg_1: &[u8] = &(*p0);
      let v1350_2_arg_2: &[u8] = &(*p2);
      let v1350_2_arg_3: &[u8] = &(*p3);
      let v1350_2_arg_4: &[u8] = &(*p4);
      let v1350_2_arg_5: &[u8] = &(*p5);
      let v1350_2_arg_6: &[u8] = &(*p6);
      let v1350_2_arg_7: &[u8] = &(*p7);
      let v1350_2_arg_8: &[u8] = &(*p8);
      let v1350_2_arg_10: &Space = &(&(*s0)).make_map();
      let mut v1350_2_more = v1348_24_cursor.is_val() || next_value_within(&mut v1348_24_cursor,(v1348_24_origin + 1));
      while v1350_2_more {
        {
        let v1350_2_depth = v1348_24_cursor.path().len();
        let mut v1351_11_cursor = (*v1350_2_arg_10).read_zipper();
        let v1351_11_origin = v1351_11_cursor.path().len();
        for v1351_11_byte in v1351_11_cursor.child_mask().iter() {
          v1351_11_cursor.descend_to_existing_byte(v1351_11_byte);
          {
          let v1352_2: Path = concat_path(&(*v1350_2_arg_1),&v1351_11_cursor.path()[v1351_11_origin..(v1351_11_origin + 1)]);
          let v1352_3: Space = routine_176(c, &(v1352_2), &v1348_24_cursor.path()[v1348_24_origin..v1350_2_depth], &(*v1350_2_arg_2), &(*v1350_2_arg_3), &(*v1350_2_arg_4), &(*v1350_2_arg_5), &(*v1350_2_arg_6), &(*v1350_2_arg_7), &(*v1350_2_arg_8), &v1351_11_cursor);
          drop(v1352_2);
          join_wrapped_into(&mut v1348_24_write,&((v1352_3).read_zipper()),&[]);
          }
          v1351_11_cursor.ascend(1);
        }
        drop(v1351_11_cursor);
        }
        v1350_2_more = next_value_within(&mut v1348_24_cursor,(v1348_24_origin + 1));
      }
      }
      v1348_24_cursor.ascend(1);
    }
    drop(v1348_24_cursor);
    drop(v1348_24_write);
    let v1348_25: Space = map_map_kernels::unite(&(v1348_21),&(v1348_24));
    map_map_kernels::compose(&(v1347_15),&(v1348_25))
  };
  drop(v1347_15);
  let v1347_28: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1347_12));
  drop(v1347_12);
  let v1347_29: Space = if map_kernels::has_head(&(v1347_28)) { singleton(&[]) } else { Space::new() };
  drop(v1347_28);
  let v1347_63: Space = if (&(v1347_29)).is_empty() { Space::new() } else {
    let v1353_32: Path = concat_path(&(*CONSTANT_26),&(*p2));
    let v1353_33: Space = singleton(&(v1353_32));
    drop(v1353_32);
    let v1353_34: Space = map_map_kernels::unite(&(*CONSTANT_30),&(v1353_33));
    drop(v1353_33);
    let v1353_36: Path = concat_path(&(*CONSTANT_18),&(*p3));
    let v1353_37: Space = singleton(&(v1353_36));
    drop(v1353_36);
    let v1353_38: Space = map_map_kernels::unite(&(v1353_34),&(v1353_37));
    drop(v1353_34);
    drop(v1353_37);
    let v1353_40: Path = concat_path(&(*CONSTANT_19),&(*p4));
    let v1353_41: Space = singleton(&(v1353_40));
    drop(v1353_40);
    let v1353_42: Space = map_map_kernels::unite(&(v1353_38),&(v1353_41));
    drop(v1353_38);
    drop(v1353_41);
    let v1353_44: Path = concat_path(&(*CONSTANT_21),&(*p5));
    let v1353_45: Space = singleton(&(v1353_44));
    drop(v1353_44);
    let v1353_46: Space = map_map_kernels::unite(&(v1353_42),&(v1353_45));
    drop(v1353_42);
    drop(v1353_45);
    let v1353_48: Path = concat_path(&(*CONSTANT_22),&(*p6));
    let v1353_49: Space = singleton(&(v1353_48));
    drop(v1353_48);
    let v1353_50: Space = map_map_kernels::unite(&(v1353_46),&(v1353_49));
    drop(v1353_46);
    drop(v1353_49);
    let v1353_52: Path = concat_path(&(*CONSTANT_23),&(*p7));
    let v1353_53: Space = singleton(&(v1353_52));
    drop(v1353_52);
    let v1353_54: Space = map_map_kernels::unite(&(v1353_50),&(v1353_53));
    drop(v1353_50);
    drop(v1353_53);
    let v1353_56: Path = concat_path(&(*CONSTANT_24),&(*p8));
    let v1353_57: Space = singleton(&(v1353_56));
    drop(v1353_56);
    let v1353_58: Space = map_map_kernels::unite(&(v1353_54),&(v1353_57));
    drop(v1353_54);
    drop(v1353_57);
    let v1353_60: Path = concat_path(&(*CONSTANT_25),&(*p0));
    let v1353_61: Space = singleton(&(v1353_60));
    drop(v1353_60);
    let v1353_62: Space = map_map_kernels::unite(&(v1353_58),&(v1353_61));
    drop(v1353_58);
    drop(v1353_61);
    map_map_kernels::compose(&(v1347_29),&(v1353_62))
  };
  drop(v1347_29);
  let v1347_64: Space = map_map_kernels::unite(&(v1347_26),&(v1347_63));
  drop(v1347_63);
  (v1347_64).clone()
}

fn routine_177(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v1354_11: Space = singleton(&(*p0));
  let v1354_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1354_11));
  let v1354_13: Space = if map_kernels::has_head(&(v1354_12)) { singleton(&[]) } else { Space::new() };
  drop(v1354_12);
  let v1354_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1354_13));
  drop(v1354_13);
  let v1354_19: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1354_11));
  drop(v1354_11);
  let v1354_20: Space = if map_kernels::has_head(&(v1354_19)) { singleton(&[]) } else { Space::new() };
  drop(v1354_19);
  let mut v1354_21 = Space::new();
  let mut v1354_21_write = v1354_21.write_zipper();
  let mut v1354_21_cursor = (*s0).read_zipper();
  let v1354_21_origin = v1354_21_cursor.path().len();
  for v1354_21_byte in v1354_21_cursor.child_mask().iter() {
    v1354_21_cursor.descend_to_existing_byte(v1354_21_byte);
    {
    let v1355_4: Space = if (&(v1354_14)).is_empty() { Space::new() } else {
      let v1356_2: Path = concat_path(&(*p1),&v1354_21_cursor.path()[v1354_21_origin..(v1354_21_origin + 1)]);
      let mut v1356_3 = Space::new();
      let mut v1356_3_write = v1356_3.write_zipper();
      let v1356_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1356_3_arg_1: &[u8] = &(v1356_2);
      let v1356_3_arg_2: &[u8] = &(*p2);
      let v1356_3_arg_3: &[u8] = &(*p3);
      let v1356_3_arg_4: &[u8] = &(*p4);
      let v1356_3_arg_5: &[u8] = &(*p5);
      let v1356_3_arg_6: &[u8] = &(*p6);
      let v1356_3_arg_7: &[u8] = &(*p7);
      let v1356_3_arg_9: &Space = &(&v1354_21_cursor).make_map();
      let mut v1356_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1356_3_origin = v1356_3_cursor.path().len();
      let mut v1356_3_more = v1356_3_cursor.is_val() || next_value_within(&mut v1356_3_cursor,v1356_3_origin);
      while v1356_3_more {
        {
        let v1356_3_depth = v1356_3_cursor.path().len();
        let v1357_10: Space = routine_177(c, &v1356_3_cursor.path()[v1356_3_origin..v1356_3_depth], &(*v1356_3_arg_1), &(*v1356_3_arg_2), &(*v1356_3_arg_3), &(*v1356_3_arg_4), &(*v1356_3_arg_5), &(*v1356_3_arg_6), &(*v1356_3_arg_7), &((*v1356_3_arg_9).read_zipper()));
        join_wrapped_into(&mut v1356_3_write,&((v1357_10).read_zipper()),&[]);
        }
        v1356_3_more = next_value_within(&mut v1356_3_cursor,v1356_3_origin);
      }
      drop(v1356_3_cursor);
      drop(v1356_3_write);
      map_map_kernels::compose(&(v1354_14),&(v1356_3))
    };
    let v1355_6: Space = if (&(v1354_20)).is_empty() { Space::new() } else {
      let v1358_2: Path = concat_path(&(*p1),&v1354_21_cursor.path()[v1354_21_origin..(v1354_21_origin + 1)]);
      let mut v1358_5 = Space::new();
      let mut v1358_5_write = v1358_5.write_zipper();
      for v1358_5_byte in v1354_21_cursor.child_mask().iter() {
        v1354_21_cursor.descend_to_existing_byte(v1358_5_byte);
        {
        let v1359_2: Space = routine_178(c, &v1354_21_cursor.path()[(v1354_21_origin + 1)..(v1354_21_origin + 2)], &v1354_21_cursor.path()[(v1354_21_origin + 1)..(v1354_21_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v1358_2), &v1354_21_cursor);
        join_wrapped_into(&mut v1358_5_write,&((v1359_2).read_zipper()),&[]);
        }
        v1354_21_cursor.ascend(1);
      }
      drop(v1358_5_write);
      drop(v1358_2);
      map_map_kernels::compose(&(v1354_20),&(v1358_5))
    };
    let v1355_7: Space = map_map_kernels::unite(&(v1355_4),&(v1355_6));
    join_wrapped_into(&mut v1354_21_write,&((v1355_7).read_zipper()),&[]);
    }
    v1354_21_cursor.ascend(1);
  }
  drop(v1354_21_cursor);
  drop(v1354_21_write);
  drop(v1354_14);
  drop(v1354_20);
  (v1354_21).clone()
}

fn routine_178(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v1360_12: Space = singleton(&(*p1));
  let v1360_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1360_12));
  let v1360_14: Space = if map_kernels::has_head(&(v1360_13)) { singleton(&[]) } else { Space::new() };
  drop(v1360_13);
  let v1360_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1360_14));
  drop(v1360_14);
  let v1360_26: Space = if (&(v1360_15)).is_empty() { Space::new() } else {
    let v1361_18: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1361_21: Space = if (&(v1361_18)).is_empty() { Space::new() } else {
      let v1362_20: Space = routine_191(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*s0));
      map_map_kernels::compose(&(v1361_18),&(v1362_20))
    };
    drop(v1361_18);
    let mut v1361_24 = Space::new();
    let mut v1361_24_write = v1361_24.write_zipper();
    let mut v1361_24_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1361_24_origin = v1361_24_cursor.path().len();
    for v1361_24_byte in v1361_24_cursor.child_mask().iter() {
      v1361_24_cursor.descend_to_existing_byte(v1361_24_byte);
      {
      let v1363_2_arg_0: &[u8] = &v1361_24_cursor.path()[v1361_24_origin..(v1361_24_origin + 1)];
      let v1363_2_arg_1: &[u8] = &(*p0);
      let v1363_2_arg_2: &[u8] = &(*p2);
      let v1363_2_arg_3: &[u8] = &(*p3);
      let v1363_2_arg_4: &[u8] = &(*p4);
      let v1363_2_arg_5: &[u8] = &(*p5);
      let v1363_2_arg_6: &[u8] = &(*p6);
      let v1363_2_arg_7: &[u8] = &(*p7);
      let v1363_2_arg_8: &[u8] = &(*p8);
      let v1363_2_arg_10: &Space = &(&(*s0)).make_map();
      let mut v1363_2_more = v1361_24_cursor.is_val() || next_value_within(&mut v1361_24_cursor,(v1361_24_origin + 1));
      while v1363_2_more {
        {
        let v1363_2_depth = v1361_24_cursor.path().len();
        let mut v1364_11_cursor = (*v1363_2_arg_10).read_zipper();
        let v1364_11_origin = v1364_11_cursor.path().len();
        for v1364_11_byte in v1364_11_cursor.child_mask().iter() {
          v1364_11_cursor.descend_to_existing_byte(v1364_11_byte);
          {
          let v1365_2: Path = concat_path(&(*v1363_2_arg_1),&v1364_11_cursor.path()[v1364_11_origin..(v1364_11_origin + 1)]);
          let v1365_3: Space = routine_178(c, &(v1365_2), &v1361_24_cursor.path()[v1361_24_origin..v1363_2_depth], &(*v1363_2_arg_2), &(*v1363_2_arg_3), &(*v1363_2_arg_4), &(*v1363_2_arg_5), &(*v1363_2_arg_6), &(*v1363_2_arg_7), &(*v1363_2_arg_8), &v1364_11_cursor);
          drop(v1365_2);
          join_wrapped_into(&mut v1361_24_write,&((v1365_3).read_zipper()),&[]);
          }
          v1364_11_cursor.ascend(1);
        }
        drop(v1364_11_cursor);
        }
        v1363_2_more = next_value_within(&mut v1361_24_cursor,(v1361_24_origin + 1));
      }
      }
      v1361_24_cursor.ascend(1);
    }
    drop(v1361_24_cursor);
    drop(v1361_24_write);
    let v1361_25: Space = map_map_kernels::unite(&(v1361_21),&(v1361_24));
    map_map_kernels::compose(&(v1360_15),&(v1361_25))
  };
  drop(v1360_15);
  let v1360_28: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1360_12));
  drop(v1360_12);
  let v1360_29: Space = if map_kernels::has_head(&(v1360_28)) { singleton(&[]) } else { Space::new() };
  drop(v1360_28);
  let v1360_63: Space = if (&(v1360_29)).is_empty() { Space::new() } else {
    let v1366_32: Path = concat_path(&(*CONSTANT_26),&(*p2));
    let v1366_33: Space = singleton(&(v1366_32));
    drop(v1366_32);
    let v1366_34: Space = map_map_kernels::unite(&(*CONSTANT_31),&(v1366_33));
    drop(v1366_33);
    let v1366_36: Path = concat_path(&(*CONSTANT_18),&(*p3));
    let v1366_37: Space = singleton(&(v1366_36));
    drop(v1366_36);
    let v1366_38: Space = map_map_kernels::unite(&(v1366_34),&(v1366_37));
    drop(v1366_34);
    drop(v1366_37);
    let v1366_40: Path = concat_path(&(*CONSTANT_19),&(*p4));
    let v1366_41: Space = singleton(&(v1366_40));
    drop(v1366_40);
    let v1366_42: Space = map_map_kernels::unite(&(v1366_38),&(v1366_41));
    drop(v1366_38);
    drop(v1366_41);
    let v1366_44: Path = concat_path(&(*CONSTANT_20),&(*p5));
    let v1366_45: Space = singleton(&(v1366_44));
    drop(v1366_44);
    let v1366_46: Space = map_map_kernels::unite(&(v1366_42),&(v1366_45));
    drop(v1366_42);
    drop(v1366_45);
    let v1366_48: Path = concat_path(&(*CONSTANT_22),&(*p6));
    let v1366_49: Space = singleton(&(v1366_48));
    drop(v1366_48);
    let v1366_50: Space = map_map_kernels::unite(&(v1366_46),&(v1366_49));
    drop(v1366_46);
    drop(v1366_49);
    let v1366_52: Path = concat_path(&(*CONSTANT_23),&(*p7));
    let v1366_53: Space = singleton(&(v1366_52));
    drop(v1366_52);
    let v1366_54: Space = map_map_kernels::unite(&(v1366_50),&(v1366_53));
    drop(v1366_50);
    drop(v1366_53);
    let v1366_56: Path = concat_path(&(*CONSTANT_24),&(*p8));
    let v1366_57: Space = singleton(&(v1366_56));
    drop(v1366_56);
    let v1366_58: Space = map_map_kernels::unite(&(v1366_54),&(v1366_57));
    drop(v1366_54);
    drop(v1366_57);
    let v1366_60: Path = concat_path(&(*CONSTANT_25),&(*p0));
    let v1366_61: Space = singleton(&(v1366_60));
    drop(v1366_60);
    let v1366_62: Space = map_map_kernels::unite(&(v1366_58),&(v1366_61));
    drop(v1366_58);
    drop(v1366_61);
    map_map_kernels::compose(&(v1360_29),&(v1366_62))
  };
  drop(v1360_29);
  let v1360_64: Space = map_map_kernels::unite(&(v1360_26),&(v1360_63));
  drop(v1360_63);
  (v1360_64).clone()
}

fn routine_179(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v1367_11: Space = singleton(&(*p0));
  let v1367_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1367_11));
  let v1367_13: Space = if map_kernels::has_head(&(v1367_12)) { singleton(&[]) } else { Space::new() };
  drop(v1367_12);
  let v1367_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1367_13));
  drop(v1367_13);
  let v1367_19: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1367_11));
  drop(v1367_11);
  let v1367_20: Space = if map_kernels::has_head(&(v1367_19)) { singleton(&[]) } else { Space::new() };
  drop(v1367_19);
  let mut v1367_21 = Space::new();
  let mut v1367_21_write = v1367_21.write_zipper();
  let mut v1367_21_cursor = (*s0).read_zipper();
  let v1367_21_origin = v1367_21_cursor.path().len();
  for v1367_21_byte in v1367_21_cursor.child_mask().iter() {
    v1367_21_cursor.descend_to_existing_byte(v1367_21_byte);
    {
    let v1368_4: Space = if (&(v1367_14)).is_empty() { Space::new() } else {
      let v1369_2: Path = concat_path(&(*p1),&v1367_21_cursor.path()[v1367_21_origin..(v1367_21_origin + 1)]);
      let mut v1369_3 = Space::new();
      let mut v1369_3_write = v1369_3.write_zipper();
      let v1369_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1369_3_arg_1: &[u8] = &(v1369_2);
      let v1369_3_arg_2: &[u8] = &(*p2);
      let v1369_3_arg_3: &[u8] = &(*p3);
      let v1369_3_arg_4: &[u8] = &(*p4);
      let v1369_3_arg_5: &[u8] = &(*p5);
      let v1369_3_arg_6: &[u8] = &(*p6);
      let v1369_3_arg_7: &[u8] = &(*p7);
      let v1369_3_arg_9: &Space = &(&v1367_21_cursor).make_map();
      let mut v1369_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1369_3_origin = v1369_3_cursor.path().len();
      let mut v1369_3_more = v1369_3_cursor.is_val() || next_value_within(&mut v1369_3_cursor,v1369_3_origin);
      while v1369_3_more {
        {
        let v1369_3_depth = v1369_3_cursor.path().len();
        let v1370_10: Space = routine_179(c, &v1369_3_cursor.path()[v1369_3_origin..v1369_3_depth], &(*v1369_3_arg_1), &(*v1369_3_arg_2), &(*v1369_3_arg_3), &(*v1369_3_arg_4), &(*v1369_3_arg_5), &(*v1369_3_arg_6), &(*v1369_3_arg_7), &((*v1369_3_arg_9).read_zipper()));
        join_wrapped_into(&mut v1369_3_write,&((v1370_10).read_zipper()),&[]);
        }
        v1369_3_more = next_value_within(&mut v1369_3_cursor,v1369_3_origin);
      }
      drop(v1369_3_cursor);
      drop(v1369_3_write);
      map_map_kernels::compose(&(v1367_14),&(v1369_3))
    };
    let v1368_6: Space = if (&(v1367_20)).is_empty() { Space::new() } else {
      let v1371_2: Path = concat_path(&(*p1),&v1367_21_cursor.path()[v1367_21_origin..(v1367_21_origin + 1)]);
      let mut v1371_5 = Space::new();
      let mut v1371_5_write = v1371_5.write_zipper();
      for v1371_5_byte in v1367_21_cursor.child_mask().iter() {
        v1367_21_cursor.descend_to_existing_byte(v1371_5_byte);
        {
        let v1372_2: Space = routine_180(c, &v1367_21_cursor.path()[(v1367_21_origin + 1)..(v1367_21_origin + 2)], &v1367_21_cursor.path()[(v1367_21_origin + 1)..(v1367_21_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v1371_2), &v1367_21_cursor);
        join_wrapped_into(&mut v1371_5_write,&((v1372_2).read_zipper()),&[]);
        }
        v1367_21_cursor.ascend(1);
      }
      drop(v1371_5_write);
      drop(v1371_2);
      map_map_kernels::compose(&(v1367_20),&(v1371_5))
    };
    let v1368_7: Space = map_map_kernels::unite(&(v1368_4),&(v1368_6));
    join_wrapped_into(&mut v1367_21_write,&((v1368_7).read_zipper()),&[]);
    }
    v1367_21_cursor.ascend(1);
  }
  drop(v1367_21_cursor);
  drop(v1367_21_write);
  drop(v1367_14);
  drop(v1367_20);
  (v1367_21).clone()
}

fn routine_180(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v1373_12: Space = singleton(&(*p1));
  let v1373_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1373_12));
  let v1373_14: Space = if map_kernels::has_head(&(v1373_13)) { singleton(&[]) } else { Space::new() };
  drop(v1373_13);
  let v1373_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1373_14));
  drop(v1373_14);
  let v1373_26: Space = if (&(v1373_15)).is_empty() { Space::new() } else {
    let v1374_18: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1374_21: Space = if (&(v1374_18)).is_empty() { Space::new() } else {
      let v1375_20: Space = routine_192(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*s0));
      map_map_kernels::compose(&(v1374_18),&(v1375_20))
    };
    drop(v1374_18);
    let mut v1374_24 = Space::new();
    let mut v1374_24_write = v1374_24.write_zipper();
    let mut v1374_24_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1374_24_origin = v1374_24_cursor.path().len();
    for v1374_24_byte in v1374_24_cursor.child_mask().iter() {
      v1374_24_cursor.descend_to_existing_byte(v1374_24_byte);
      {
      let v1376_2_arg_0: &[u8] = &v1374_24_cursor.path()[v1374_24_origin..(v1374_24_origin + 1)];
      let v1376_2_arg_1: &[u8] = &(*p0);
      let v1376_2_arg_2: &[u8] = &(*p2);
      let v1376_2_arg_3: &[u8] = &(*p3);
      let v1376_2_arg_4: &[u8] = &(*p4);
      let v1376_2_arg_5: &[u8] = &(*p5);
      let v1376_2_arg_6: &[u8] = &(*p6);
      let v1376_2_arg_7: &[u8] = &(*p7);
      let v1376_2_arg_8: &[u8] = &(*p8);
      let v1376_2_arg_10: &Space = &(&(*s0)).make_map();
      let mut v1376_2_more = v1374_24_cursor.is_val() || next_value_within(&mut v1374_24_cursor,(v1374_24_origin + 1));
      while v1376_2_more {
        {
        let v1376_2_depth = v1374_24_cursor.path().len();
        let mut v1377_11_cursor = (*v1376_2_arg_10).read_zipper();
        let v1377_11_origin = v1377_11_cursor.path().len();
        for v1377_11_byte in v1377_11_cursor.child_mask().iter() {
          v1377_11_cursor.descend_to_existing_byte(v1377_11_byte);
          {
          let v1378_2: Path = concat_path(&(*v1376_2_arg_1),&v1377_11_cursor.path()[v1377_11_origin..(v1377_11_origin + 1)]);
          let v1378_3: Space = routine_180(c, &(v1378_2), &v1374_24_cursor.path()[v1374_24_origin..v1376_2_depth], &(*v1376_2_arg_2), &(*v1376_2_arg_3), &(*v1376_2_arg_4), &(*v1376_2_arg_5), &(*v1376_2_arg_6), &(*v1376_2_arg_7), &(*v1376_2_arg_8), &v1377_11_cursor);
          drop(v1378_2);
          join_wrapped_into(&mut v1374_24_write,&((v1378_3).read_zipper()),&[]);
          }
          v1377_11_cursor.ascend(1);
        }
        drop(v1377_11_cursor);
        }
        v1376_2_more = next_value_within(&mut v1374_24_cursor,(v1374_24_origin + 1));
      }
      }
      v1374_24_cursor.ascend(1);
    }
    drop(v1374_24_cursor);
    drop(v1374_24_write);
    let v1374_25: Space = map_map_kernels::unite(&(v1374_21),&(v1374_24));
    map_map_kernels::compose(&(v1373_15),&(v1374_25))
  };
  drop(v1373_15);
  let v1373_28: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1373_12));
  drop(v1373_12);
  let v1373_29: Space = if map_kernels::has_head(&(v1373_28)) { singleton(&[]) } else { Space::new() };
  drop(v1373_28);
  let v1373_63: Space = if (&(v1373_29)).is_empty() { Space::new() } else {
    let v1379_32: Path = concat_path(&(*CONSTANT_26),&(*p2));
    let v1379_33: Space = singleton(&(v1379_32));
    drop(v1379_32);
    let v1379_34: Space = map_map_kernels::unite(&(*CONSTANT_32),&(v1379_33));
    drop(v1379_33);
    let v1379_36: Path = concat_path(&(*CONSTANT_18),&(*p3));
    let v1379_37: Space = singleton(&(v1379_36));
    drop(v1379_36);
    let v1379_38: Space = map_map_kernels::unite(&(v1379_34),&(v1379_37));
    drop(v1379_34);
    drop(v1379_37);
    let v1379_40: Path = concat_path(&(*CONSTANT_19),&(*p4));
    let v1379_41: Space = singleton(&(v1379_40));
    drop(v1379_40);
    let v1379_42: Space = map_map_kernels::unite(&(v1379_38),&(v1379_41));
    drop(v1379_38);
    drop(v1379_41);
    let v1379_44: Path = concat_path(&(*CONSTANT_20),&(*p5));
    let v1379_45: Space = singleton(&(v1379_44));
    drop(v1379_44);
    let v1379_46: Space = map_map_kernels::unite(&(v1379_42),&(v1379_45));
    drop(v1379_42);
    drop(v1379_45);
    let v1379_48: Path = concat_path(&(*CONSTANT_21),&(*p6));
    let v1379_49: Space = singleton(&(v1379_48));
    drop(v1379_48);
    let v1379_50: Space = map_map_kernels::unite(&(v1379_46),&(v1379_49));
    drop(v1379_46);
    drop(v1379_49);
    let v1379_52: Path = concat_path(&(*CONSTANT_23),&(*p7));
    let v1379_53: Space = singleton(&(v1379_52));
    drop(v1379_52);
    let v1379_54: Space = map_map_kernels::unite(&(v1379_50),&(v1379_53));
    drop(v1379_50);
    drop(v1379_53);
    let v1379_56: Path = concat_path(&(*CONSTANT_24),&(*p8));
    let v1379_57: Space = singleton(&(v1379_56));
    drop(v1379_56);
    let v1379_58: Space = map_map_kernels::unite(&(v1379_54),&(v1379_57));
    drop(v1379_54);
    drop(v1379_57);
    let v1379_60: Path = concat_path(&(*CONSTANT_25),&(*p0));
    let v1379_61: Space = singleton(&(v1379_60));
    drop(v1379_60);
    let v1379_62: Space = map_map_kernels::unite(&(v1379_58),&(v1379_61));
    drop(v1379_58);
    drop(v1379_61);
    map_map_kernels::compose(&(v1373_29),&(v1379_62))
  };
  drop(v1373_29);
  let v1373_64: Space = map_map_kernels::unite(&(v1373_26),&(v1373_63));
  drop(v1373_63);
  (v1373_64).clone()
}

fn routine_181(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v1380_11: Space = singleton(&(*p0));
  let v1380_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1380_11));
  let v1380_13: Space = if map_kernels::has_head(&(v1380_12)) { singleton(&[]) } else { Space::new() };
  drop(v1380_12);
  let v1380_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1380_13));
  drop(v1380_13);
  let v1380_19: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1380_11));
  drop(v1380_11);
  let v1380_20: Space = if map_kernels::has_head(&(v1380_19)) { singleton(&[]) } else { Space::new() };
  drop(v1380_19);
  let mut v1380_21 = Space::new();
  let mut v1380_21_write = v1380_21.write_zipper();
  let mut v1380_21_cursor = (*s0).read_zipper();
  let v1380_21_origin = v1380_21_cursor.path().len();
  for v1380_21_byte in v1380_21_cursor.child_mask().iter() {
    v1380_21_cursor.descend_to_existing_byte(v1380_21_byte);
    {
    let v1381_4: Space = if (&(v1380_14)).is_empty() { Space::new() } else {
      let v1382_2: Path = concat_path(&(*p1),&v1380_21_cursor.path()[v1380_21_origin..(v1380_21_origin + 1)]);
      let mut v1382_3 = Space::new();
      let mut v1382_3_write = v1382_3.write_zipper();
      let v1382_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1382_3_arg_1: &[u8] = &(v1382_2);
      let v1382_3_arg_2: &[u8] = &(*p2);
      let v1382_3_arg_3: &[u8] = &(*p3);
      let v1382_3_arg_4: &[u8] = &(*p4);
      let v1382_3_arg_5: &[u8] = &(*p5);
      let v1382_3_arg_6: &[u8] = &(*p6);
      let v1382_3_arg_7: &[u8] = &(*p7);
      let v1382_3_arg_9: &Space = &(&v1380_21_cursor).make_map();
      let mut v1382_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1382_3_origin = v1382_3_cursor.path().len();
      let mut v1382_3_more = v1382_3_cursor.is_val() || next_value_within(&mut v1382_3_cursor,v1382_3_origin);
      while v1382_3_more {
        {
        let v1382_3_depth = v1382_3_cursor.path().len();
        let v1383_10: Space = routine_181(c, &v1382_3_cursor.path()[v1382_3_origin..v1382_3_depth], &(*v1382_3_arg_1), &(*v1382_3_arg_2), &(*v1382_3_arg_3), &(*v1382_3_arg_4), &(*v1382_3_arg_5), &(*v1382_3_arg_6), &(*v1382_3_arg_7), &((*v1382_3_arg_9).read_zipper()));
        join_wrapped_into(&mut v1382_3_write,&((v1383_10).read_zipper()),&[]);
        }
        v1382_3_more = next_value_within(&mut v1382_3_cursor,v1382_3_origin);
      }
      drop(v1382_3_cursor);
      drop(v1382_3_write);
      map_map_kernels::compose(&(v1380_14),&(v1382_3))
    };
    let v1381_6: Space = if (&(v1380_20)).is_empty() { Space::new() } else {
      let v1384_2: Path = concat_path(&(*p1),&v1380_21_cursor.path()[v1380_21_origin..(v1380_21_origin + 1)]);
      let mut v1384_5 = Space::new();
      let mut v1384_5_write = v1384_5.write_zipper();
      for v1384_5_byte in v1380_21_cursor.child_mask().iter() {
        v1380_21_cursor.descend_to_existing_byte(v1384_5_byte);
        {
        let v1385_2: Space = routine_182(c, &v1380_21_cursor.path()[(v1380_21_origin + 1)..(v1380_21_origin + 2)], &v1380_21_cursor.path()[(v1380_21_origin + 1)..(v1380_21_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v1384_2), &v1380_21_cursor);
        join_wrapped_into(&mut v1384_5_write,&((v1385_2).read_zipper()),&[]);
        }
        v1380_21_cursor.ascend(1);
      }
      drop(v1384_5_write);
      drop(v1384_2);
      map_map_kernels::compose(&(v1380_20),&(v1384_5))
    };
    let v1381_7: Space = map_map_kernels::unite(&(v1381_4),&(v1381_6));
    join_wrapped_into(&mut v1380_21_write,&((v1381_7).read_zipper()),&[]);
    }
    v1380_21_cursor.ascend(1);
  }
  drop(v1380_21_cursor);
  drop(v1380_21_write);
  drop(v1380_14);
  drop(v1380_20);
  (v1380_21).clone()
}

fn routine_182(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v1386_12: Space = singleton(&(*p1));
  let v1386_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1386_12));
  let v1386_14: Space = if map_kernels::has_head(&(v1386_13)) { singleton(&[]) } else { Space::new() };
  drop(v1386_13);
  let v1386_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1386_14));
  drop(v1386_14);
  let v1386_26: Space = if (&(v1386_15)).is_empty() { Space::new() } else {
    let v1387_18: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1387_21: Space = if (&(v1387_18)).is_empty() { Space::new() } else {
      let v1388_20: Space = routine_193(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*s0));
      map_map_kernels::compose(&(v1387_18),&(v1388_20))
    };
    drop(v1387_18);
    let mut v1387_24 = Space::new();
    let mut v1387_24_write = v1387_24.write_zipper();
    let mut v1387_24_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1387_24_origin = v1387_24_cursor.path().len();
    for v1387_24_byte in v1387_24_cursor.child_mask().iter() {
      v1387_24_cursor.descend_to_existing_byte(v1387_24_byte);
      {
      let v1389_2_arg_0: &[u8] = &v1387_24_cursor.path()[v1387_24_origin..(v1387_24_origin + 1)];
      let v1389_2_arg_1: &[u8] = &(*p0);
      let v1389_2_arg_2: &[u8] = &(*p2);
      let v1389_2_arg_3: &[u8] = &(*p3);
      let v1389_2_arg_4: &[u8] = &(*p4);
      let v1389_2_arg_5: &[u8] = &(*p5);
      let v1389_2_arg_6: &[u8] = &(*p6);
      let v1389_2_arg_7: &[u8] = &(*p7);
      let v1389_2_arg_8: &[u8] = &(*p8);
      let v1389_2_arg_10: &Space = &(&(*s0)).make_map();
      let mut v1389_2_more = v1387_24_cursor.is_val() || next_value_within(&mut v1387_24_cursor,(v1387_24_origin + 1));
      while v1389_2_more {
        {
        let v1389_2_depth = v1387_24_cursor.path().len();
        let mut v1390_11_cursor = (*v1389_2_arg_10).read_zipper();
        let v1390_11_origin = v1390_11_cursor.path().len();
        for v1390_11_byte in v1390_11_cursor.child_mask().iter() {
          v1390_11_cursor.descend_to_existing_byte(v1390_11_byte);
          {
          let v1391_2: Path = concat_path(&(*v1389_2_arg_1),&v1390_11_cursor.path()[v1390_11_origin..(v1390_11_origin + 1)]);
          let v1391_3: Space = routine_182(c, &(v1391_2), &v1387_24_cursor.path()[v1387_24_origin..v1389_2_depth], &(*v1389_2_arg_2), &(*v1389_2_arg_3), &(*v1389_2_arg_4), &(*v1389_2_arg_5), &(*v1389_2_arg_6), &(*v1389_2_arg_7), &(*v1389_2_arg_8), &v1390_11_cursor);
          drop(v1391_2);
          join_wrapped_into(&mut v1387_24_write,&((v1391_3).read_zipper()),&[]);
          }
          v1390_11_cursor.ascend(1);
        }
        drop(v1390_11_cursor);
        }
        v1389_2_more = next_value_within(&mut v1387_24_cursor,(v1387_24_origin + 1));
      }
      }
      v1387_24_cursor.ascend(1);
    }
    drop(v1387_24_cursor);
    drop(v1387_24_write);
    let v1387_25: Space = map_map_kernels::unite(&(v1387_21),&(v1387_24));
    map_map_kernels::compose(&(v1386_15),&(v1387_25))
  };
  drop(v1386_15);
  let v1386_28: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1386_12));
  drop(v1386_12);
  let v1386_29: Space = if map_kernels::has_head(&(v1386_28)) { singleton(&[]) } else { Space::new() };
  drop(v1386_28);
  let v1386_63: Space = if (&(v1386_29)).is_empty() { Space::new() } else {
    let v1392_32: Path = concat_path(&(*CONSTANT_26),&(*p2));
    let v1392_33: Space = singleton(&(v1392_32));
    drop(v1392_32);
    let v1392_34: Space = map_map_kernels::unite(&(*CONSTANT_33),&(v1392_33));
    drop(v1392_33);
    let v1392_36: Path = concat_path(&(*CONSTANT_18),&(*p3));
    let v1392_37: Space = singleton(&(v1392_36));
    drop(v1392_36);
    let v1392_38: Space = map_map_kernels::unite(&(v1392_34),&(v1392_37));
    drop(v1392_34);
    drop(v1392_37);
    let v1392_40: Path = concat_path(&(*CONSTANT_19),&(*p4));
    let v1392_41: Space = singleton(&(v1392_40));
    drop(v1392_40);
    let v1392_42: Space = map_map_kernels::unite(&(v1392_38),&(v1392_41));
    drop(v1392_38);
    drop(v1392_41);
    let v1392_44: Path = concat_path(&(*CONSTANT_20),&(*p5));
    let v1392_45: Space = singleton(&(v1392_44));
    drop(v1392_44);
    let v1392_46: Space = map_map_kernels::unite(&(v1392_42),&(v1392_45));
    drop(v1392_42);
    drop(v1392_45);
    let v1392_48: Path = concat_path(&(*CONSTANT_21),&(*p6));
    let v1392_49: Space = singleton(&(v1392_48));
    drop(v1392_48);
    let v1392_50: Space = map_map_kernels::unite(&(v1392_46),&(v1392_49));
    drop(v1392_46);
    drop(v1392_49);
    let v1392_52: Path = concat_path(&(*CONSTANT_22),&(*p7));
    let v1392_53: Space = singleton(&(v1392_52));
    drop(v1392_52);
    let v1392_54: Space = map_map_kernels::unite(&(v1392_50),&(v1392_53));
    drop(v1392_50);
    drop(v1392_53);
    let v1392_56: Path = concat_path(&(*CONSTANT_24),&(*p8));
    let v1392_57: Space = singleton(&(v1392_56));
    drop(v1392_56);
    let v1392_58: Space = map_map_kernels::unite(&(v1392_54),&(v1392_57));
    drop(v1392_54);
    drop(v1392_57);
    let v1392_60: Path = concat_path(&(*CONSTANT_25),&(*p0));
    let v1392_61: Space = singleton(&(v1392_60));
    drop(v1392_60);
    let v1392_62: Space = map_map_kernels::unite(&(v1392_58),&(v1392_61));
    drop(v1392_58);
    drop(v1392_61);
    map_map_kernels::compose(&(v1386_29),&(v1392_62))
  };
  drop(v1386_29);
  let v1386_64: Space = map_map_kernels::unite(&(v1386_26),&(v1386_63));
  drop(v1386_63);
  (v1386_64).clone()
}

fn routine_183(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v1393_11: Space = singleton(&(*p0));
  let v1393_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1393_11));
  let v1393_13: Space = if map_kernels::has_head(&(v1393_12)) { singleton(&[]) } else { Space::new() };
  drop(v1393_12);
  let v1393_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1393_13));
  drop(v1393_13);
  let v1393_19: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1393_11));
  drop(v1393_11);
  let v1393_20: Space = if map_kernels::has_head(&(v1393_19)) { singleton(&[]) } else { Space::new() };
  drop(v1393_19);
  let mut v1393_21 = Space::new();
  let mut v1393_21_write = v1393_21.write_zipper();
  let mut v1393_21_cursor = (*s0).read_zipper();
  let v1393_21_origin = v1393_21_cursor.path().len();
  for v1393_21_byte in v1393_21_cursor.child_mask().iter() {
    v1393_21_cursor.descend_to_existing_byte(v1393_21_byte);
    {
    let v1394_4: Space = if (&(v1393_14)).is_empty() { Space::new() } else {
      let v1395_2: Path = concat_path(&(*p1),&v1393_21_cursor.path()[v1393_21_origin..(v1393_21_origin + 1)]);
      let mut v1395_3 = Space::new();
      let mut v1395_3_write = v1395_3.write_zipper();
      let v1395_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1395_3_arg_1: &[u8] = &(v1395_2);
      let v1395_3_arg_2: &[u8] = &(*p2);
      let v1395_3_arg_3: &[u8] = &(*p3);
      let v1395_3_arg_4: &[u8] = &(*p4);
      let v1395_3_arg_5: &[u8] = &(*p5);
      let v1395_3_arg_6: &[u8] = &(*p6);
      let v1395_3_arg_7: &[u8] = &(*p7);
      let v1395_3_arg_9: &Space = &(&v1393_21_cursor).make_map();
      let mut v1395_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1395_3_origin = v1395_3_cursor.path().len();
      let mut v1395_3_more = v1395_3_cursor.is_val() || next_value_within(&mut v1395_3_cursor,v1395_3_origin);
      while v1395_3_more {
        {
        let v1395_3_depth = v1395_3_cursor.path().len();
        let v1396_10: Space = routine_183(c, &v1395_3_cursor.path()[v1395_3_origin..v1395_3_depth], &(*v1395_3_arg_1), &(*v1395_3_arg_2), &(*v1395_3_arg_3), &(*v1395_3_arg_4), &(*v1395_3_arg_5), &(*v1395_3_arg_6), &(*v1395_3_arg_7), &((*v1395_3_arg_9).read_zipper()));
        join_wrapped_into(&mut v1395_3_write,&((v1396_10).read_zipper()),&[]);
        }
        v1395_3_more = next_value_within(&mut v1395_3_cursor,v1395_3_origin);
      }
      drop(v1395_3_cursor);
      drop(v1395_3_write);
      map_map_kernels::compose(&(v1393_14),&(v1395_3))
    };
    let v1394_6: Space = if (&(v1393_20)).is_empty() { Space::new() } else {
      let v1397_2: Path = concat_path(&(*p1),&v1393_21_cursor.path()[v1393_21_origin..(v1393_21_origin + 1)]);
      let mut v1397_5 = Space::new();
      let mut v1397_5_write = v1397_5.write_zipper();
      for v1397_5_byte in v1393_21_cursor.child_mask().iter() {
        v1393_21_cursor.descend_to_existing_byte(v1397_5_byte);
        {
        let v1398_2: Space = routine_184(c, &v1393_21_cursor.path()[(v1393_21_origin + 1)..(v1393_21_origin + 2)], &v1393_21_cursor.path()[(v1393_21_origin + 1)..(v1393_21_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v1397_2), &v1393_21_cursor);
        join_wrapped_into(&mut v1397_5_write,&((v1398_2).read_zipper()),&[]);
        }
        v1393_21_cursor.ascend(1);
      }
      drop(v1397_5_write);
      drop(v1397_2);
      map_map_kernels::compose(&(v1393_20),&(v1397_5))
    };
    let v1394_7: Space = map_map_kernels::unite(&(v1394_4),&(v1394_6));
    join_wrapped_into(&mut v1393_21_write,&((v1394_7).read_zipper()),&[]);
    }
    v1393_21_cursor.ascend(1);
  }
  drop(v1393_21_cursor);
  drop(v1393_21_write);
  drop(v1393_14);
  drop(v1393_20);
  (v1393_21).clone()
}

fn routine_184(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v1399_12: Space = singleton(&(*p1));
  let v1399_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1399_12));
  let v1399_14: Space = if map_kernels::has_head(&(v1399_13)) { singleton(&[]) } else { Space::new() };
  drop(v1399_13);
  let v1399_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1399_14));
  drop(v1399_14);
  let v1399_26: Space = if (&(v1399_15)).is_empty() { Space::new() } else {
    let v1400_18: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1400_21: Space = if (&(v1400_18)).is_empty() { Space::new() } else {
      let v1401_20: Space = routine_194(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*s0));
      map_map_kernels::compose(&(v1400_18),&(v1401_20))
    };
    drop(v1400_18);
    let mut v1400_24 = Space::new();
    let mut v1400_24_write = v1400_24.write_zipper();
    let mut v1400_24_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1400_24_origin = v1400_24_cursor.path().len();
    for v1400_24_byte in v1400_24_cursor.child_mask().iter() {
      v1400_24_cursor.descend_to_existing_byte(v1400_24_byte);
      {
      let v1402_2_arg_0: &[u8] = &v1400_24_cursor.path()[v1400_24_origin..(v1400_24_origin + 1)];
      let v1402_2_arg_1: &[u8] = &(*p0);
      let v1402_2_arg_2: &[u8] = &(*p2);
      let v1402_2_arg_3: &[u8] = &(*p3);
      let v1402_2_arg_4: &[u8] = &(*p4);
      let v1402_2_arg_5: &[u8] = &(*p5);
      let v1402_2_arg_6: &[u8] = &(*p6);
      let v1402_2_arg_7: &[u8] = &(*p7);
      let v1402_2_arg_8: &[u8] = &(*p8);
      let v1402_2_arg_10: &Space = &(&(*s0)).make_map();
      let mut v1402_2_more = v1400_24_cursor.is_val() || next_value_within(&mut v1400_24_cursor,(v1400_24_origin + 1));
      while v1402_2_more {
        {
        let v1402_2_depth = v1400_24_cursor.path().len();
        let mut v1403_11_cursor = (*v1402_2_arg_10).read_zipper();
        let v1403_11_origin = v1403_11_cursor.path().len();
        for v1403_11_byte in v1403_11_cursor.child_mask().iter() {
          v1403_11_cursor.descend_to_existing_byte(v1403_11_byte);
          {
          let v1404_2: Path = concat_path(&(*v1402_2_arg_1),&v1403_11_cursor.path()[v1403_11_origin..(v1403_11_origin + 1)]);
          let v1404_3: Space = routine_184(c, &(v1404_2), &v1400_24_cursor.path()[v1400_24_origin..v1402_2_depth], &(*v1402_2_arg_2), &(*v1402_2_arg_3), &(*v1402_2_arg_4), &(*v1402_2_arg_5), &(*v1402_2_arg_6), &(*v1402_2_arg_7), &(*v1402_2_arg_8), &v1403_11_cursor);
          drop(v1404_2);
          join_wrapped_into(&mut v1400_24_write,&((v1404_3).read_zipper()),&[]);
          }
          v1403_11_cursor.ascend(1);
        }
        drop(v1403_11_cursor);
        }
        v1402_2_more = next_value_within(&mut v1400_24_cursor,(v1400_24_origin + 1));
      }
      }
      v1400_24_cursor.ascend(1);
    }
    drop(v1400_24_cursor);
    drop(v1400_24_write);
    let v1400_25: Space = map_map_kernels::unite(&(v1400_21),&(v1400_24));
    map_map_kernels::compose(&(v1399_15),&(v1400_25))
  };
  drop(v1399_15);
  let v1399_28: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1399_12));
  drop(v1399_12);
  let v1399_29: Space = if map_kernels::has_head(&(v1399_28)) { singleton(&[]) } else { Space::new() };
  drop(v1399_28);
  let v1399_63: Space = if (&(v1399_29)).is_empty() { Space::new() } else {
    let v1405_32: Path = concat_path(&(*CONSTANT_26),&(*p2));
    let v1405_33: Space = singleton(&(v1405_32));
    drop(v1405_32);
    let v1405_34: Space = map_map_kernels::unite(&(*CONSTANT_34),&(v1405_33));
    drop(v1405_33);
    let v1405_36: Path = concat_path(&(*CONSTANT_18),&(*p3));
    let v1405_37: Space = singleton(&(v1405_36));
    drop(v1405_36);
    let v1405_38: Space = map_map_kernels::unite(&(v1405_34),&(v1405_37));
    drop(v1405_34);
    drop(v1405_37);
    let v1405_40: Path = concat_path(&(*CONSTANT_19),&(*p4));
    let v1405_41: Space = singleton(&(v1405_40));
    drop(v1405_40);
    let v1405_42: Space = map_map_kernels::unite(&(v1405_38),&(v1405_41));
    drop(v1405_38);
    drop(v1405_41);
    let v1405_44: Path = concat_path(&(*CONSTANT_20),&(*p5));
    let v1405_45: Space = singleton(&(v1405_44));
    drop(v1405_44);
    let v1405_46: Space = map_map_kernels::unite(&(v1405_42),&(v1405_45));
    drop(v1405_42);
    drop(v1405_45);
    let v1405_48: Path = concat_path(&(*CONSTANT_21),&(*p6));
    let v1405_49: Space = singleton(&(v1405_48));
    drop(v1405_48);
    let v1405_50: Space = map_map_kernels::unite(&(v1405_46),&(v1405_49));
    drop(v1405_46);
    drop(v1405_49);
    let v1405_52: Path = concat_path(&(*CONSTANT_22),&(*p7));
    let v1405_53: Space = singleton(&(v1405_52));
    drop(v1405_52);
    let v1405_54: Space = map_map_kernels::unite(&(v1405_50),&(v1405_53));
    drop(v1405_50);
    drop(v1405_53);
    let v1405_56: Path = concat_path(&(*CONSTANT_23),&(*p8));
    let v1405_57: Space = singleton(&(v1405_56));
    drop(v1405_56);
    let v1405_58: Space = map_map_kernels::unite(&(v1405_54),&(v1405_57));
    drop(v1405_54);
    drop(v1405_57);
    let v1405_60: Path = concat_path(&(*CONSTANT_25),&(*p0));
    let v1405_61: Space = singleton(&(v1405_60));
    drop(v1405_60);
    let v1405_62: Space = map_map_kernels::unite(&(v1405_58),&(v1405_61));
    drop(v1405_58);
    drop(v1405_61);
    map_map_kernels::compose(&(v1399_29),&(v1405_62))
  };
  drop(v1399_29);
  let v1399_64: Space = map_map_kernels::unite(&(v1399_26),&(v1399_63));
  drop(v1399_63);
  (v1399_64).clone()
}

fn routine_185(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v1406_11: Space = singleton(&(*p0));
  let v1406_12: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1406_11));
  let v1406_13: Space = if map_kernels::has_head(&(v1406_12)) { singleton(&[]) } else { Space::new() };
  drop(v1406_12);
  let v1406_14: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1406_13));
  drop(v1406_13);
  let v1406_19: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1406_11));
  drop(v1406_11);
  let v1406_20: Space = if map_kernels::has_head(&(v1406_19)) { singleton(&[]) } else { Space::new() };
  drop(v1406_19);
  let mut v1406_21 = Space::new();
  let mut v1406_21_write = v1406_21.write_zipper();
  let mut v1406_21_cursor = (*s0).read_zipper();
  let v1406_21_origin = v1406_21_cursor.path().len();
  for v1406_21_byte in v1406_21_cursor.child_mask().iter() {
    v1406_21_cursor.descend_to_existing_byte(v1406_21_byte);
    {
    let v1407_4: Space = if (&(v1406_14)).is_empty() { Space::new() } else {
      let v1408_2: Path = concat_path(&(*p1),&v1406_21_cursor.path()[v1406_21_origin..(v1406_21_origin + 1)]);
      let mut v1408_3 = Space::new();
      let mut v1408_3_write = v1408_3.write_zipper();
      let v1408_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1408_3_arg_1: &[u8] = &(v1408_2);
      let v1408_3_arg_2: &[u8] = &(*p2);
      let v1408_3_arg_3: &[u8] = &(*p3);
      let v1408_3_arg_4: &[u8] = &(*p4);
      let v1408_3_arg_5: &[u8] = &(*p5);
      let v1408_3_arg_6: &[u8] = &(*p6);
      let v1408_3_arg_7: &[u8] = &(*p7);
      let v1408_3_arg_9: &Space = &(&v1406_21_cursor).make_map();
      let mut v1408_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1408_3_origin = v1408_3_cursor.path().len();
      let mut v1408_3_more = v1408_3_cursor.is_val() || next_value_within(&mut v1408_3_cursor,v1408_3_origin);
      while v1408_3_more {
        {
        let v1408_3_depth = v1408_3_cursor.path().len();
        let v1409_10: Space = routine_185(c, &v1408_3_cursor.path()[v1408_3_origin..v1408_3_depth], &(*v1408_3_arg_1), &(*v1408_3_arg_2), &(*v1408_3_arg_3), &(*v1408_3_arg_4), &(*v1408_3_arg_5), &(*v1408_3_arg_6), &(*v1408_3_arg_7), &((*v1408_3_arg_9).read_zipper()));
        join_wrapped_into(&mut v1408_3_write,&((v1409_10).read_zipper()),&[]);
        }
        v1408_3_more = next_value_within(&mut v1408_3_cursor,v1408_3_origin);
      }
      drop(v1408_3_cursor);
      drop(v1408_3_write);
      map_map_kernels::compose(&(v1406_14),&(v1408_3))
    };
    let v1407_6: Space = if (&(v1406_20)).is_empty() { Space::new() } else {
      let v1410_2: Path = concat_path(&(*p1),&v1406_21_cursor.path()[v1406_21_origin..(v1406_21_origin + 1)]);
      let mut v1410_5 = Space::new();
      let mut v1410_5_write = v1410_5.write_zipper();
      for v1410_5_byte in v1406_21_cursor.child_mask().iter() {
        v1406_21_cursor.descend_to_existing_byte(v1410_5_byte);
        {
        let v1411_2: Space = routine_186(c, &v1406_21_cursor.path()[(v1406_21_origin + 1)..(v1406_21_origin + 2)], &v1406_21_cursor.path()[(v1406_21_origin + 1)..(v1406_21_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v1410_2), &v1406_21_cursor);
        join_wrapped_into(&mut v1410_5_write,&((v1411_2).read_zipper()),&[]);
        }
        v1406_21_cursor.ascend(1);
      }
      drop(v1410_5_write);
      drop(v1410_2);
      map_map_kernels::compose(&(v1406_20),&(v1410_5))
    };
    let v1407_7: Space = map_map_kernels::unite(&(v1407_4),&(v1407_6));
    join_wrapped_into(&mut v1406_21_write,&((v1407_7).read_zipper()),&[]);
    }
    v1406_21_cursor.ascend(1);
  }
  drop(v1406_21_cursor);
  drop(v1406_21_write);
  drop(v1406_14);
  drop(v1406_20);
  (v1406_21).clone()
}

fn routine_186(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v1412_12: Space = singleton(&(*p1));
  let v1412_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1412_12));
  let v1412_14: Space = if map_kernels::has_head(&(v1412_13)) { singleton(&[]) } else { Space::new() };
  drop(v1412_13);
  let v1412_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1412_14));
  drop(v1412_14);
  let v1412_26: Space = if (&(v1412_15)).is_empty() { Space::new() } else {
    let v1413_18: Space = view_map_kernels::first_matching(&(descend_cursor((*CONSTANT_6).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v1413_21: Space = if (&(v1413_18)).is_empty() { Space::new() } else {
      let v1414_20: Space = routine_195(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*s0));
      map_map_kernels::compose(&(v1413_18),&(v1414_20))
    };
    drop(v1413_18);
    let mut v1413_24 = Space::new();
    let mut v1413_24_write = v1413_24.write_zipper();
    let mut v1413_24_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p1));
    let v1413_24_origin = v1413_24_cursor.path().len();
    for v1413_24_byte in v1413_24_cursor.child_mask().iter() {
      v1413_24_cursor.descend_to_existing_byte(v1413_24_byte);
      {
      let v1415_2_arg_0: &[u8] = &v1413_24_cursor.path()[v1413_24_origin..(v1413_24_origin + 1)];
      let v1415_2_arg_1: &[u8] = &(*p0);
      let v1415_2_arg_2: &[u8] = &(*p2);
      let v1415_2_arg_3: &[u8] = &(*p3);
      let v1415_2_arg_4: &[u8] = &(*p4);
      let v1415_2_arg_5: &[u8] = &(*p5);
      let v1415_2_arg_6: &[u8] = &(*p6);
      let v1415_2_arg_7: &[u8] = &(*p7);
      let v1415_2_arg_8: &[u8] = &(*p8);
      let v1415_2_arg_10: &Space = &(&(*s0)).make_map();
      let mut v1415_2_more = v1413_24_cursor.is_val() || next_value_within(&mut v1413_24_cursor,(v1413_24_origin + 1));
      while v1415_2_more {
        {
        let v1415_2_depth = v1413_24_cursor.path().len();
        let mut v1416_11_cursor = (*v1415_2_arg_10).read_zipper();
        let v1416_11_origin = v1416_11_cursor.path().len();
        for v1416_11_byte in v1416_11_cursor.child_mask().iter() {
          v1416_11_cursor.descend_to_existing_byte(v1416_11_byte);
          {
          let v1417_2: Path = concat_path(&(*v1415_2_arg_1),&v1416_11_cursor.path()[v1416_11_origin..(v1416_11_origin + 1)]);
          let v1417_3: Space = routine_186(c, &(v1417_2), &v1413_24_cursor.path()[v1413_24_origin..v1415_2_depth], &(*v1415_2_arg_2), &(*v1415_2_arg_3), &(*v1415_2_arg_4), &(*v1415_2_arg_5), &(*v1415_2_arg_6), &(*v1415_2_arg_7), &(*v1415_2_arg_8), &v1416_11_cursor);
          drop(v1417_2);
          join_wrapped_into(&mut v1413_24_write,&((v1417_3).read_zipper()),&[]);
          }
          v1416_11_cursor.ascend(1);
        }
        drop(v1416_11_cursor);
        }
        v1415_2_more = next_value_within(&mut v1413_24_cursor,(v1413_24_origin + 1));
      }
      }
      v1413_24_cursor.ascend(1);
    }
    drop(v1413_24_cursor);
    drop(v1413_24_write);
    let v1413_25: Space = map_map_kernels::unite(&(v1413_21),&(v1413_24));
    map_map_kernels::compose(&(v1412_15),&(v1413_25))
  };
  drop(v1412_15);
  let v1412_28: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1412_12));
  drop(v1412_12);
  let v1412_29: Space = if map_kernels::has_head(&(v1412_28)) { singleton(&[]) } else { Space::new() };
  drop(v1412_28);
  let v1412_63: Space = if (&(v1412_29)).is_empty() { Space::new() } else {
    let v1418_32: Path = concat_path(&(*CONSTANT_26),&(*p2));
    let v1418_33: Space = singleton(&(v1418_32));
    drop(v1418_32);
    let v1418_34: Space = map_map_kernels::unite(&(*CONSTANT_35),&(v1418_33));
    drop(v1418_33);
    let v1418_36: Path = concat_path(&(*CONSTANT_18),&(*p3));
    let v1418_37: Space = singleton(&(v1418_36));
    drop(v1418_36);
    let v1418_38: Space = map_map_kernels::unite(&(v1418_34),&(v1418_37));
    drop(v1418_34);
    drop(v1418_37);
    let v1418_40: Path = concat_path(&(*CONSTANT_19),&(*p4));
    let v1418_41: Space = singleton(&(v1418_40));
    drop(v1418_40);
    let v1418_42: Space = map_map_kernels::unite(&(v1418_38),&(v1418_41));
    drop(v1418_38);
    drop(v1418_41);
    let v1418_44: Path = concat_path(&(*CONSTANT_20),&(*p5));
    let v1418_45: Space = singleton(&(v1418_44));
    drop(v1418_44);
    let v1418_46: Space = map_map_kernels::unite(&(v1418_42),&(v1418_45));
    drop(v1418_42);
    drop(v1418_45);
    let v1418_48: Path = concat_path(&(*CONSTANT_21),&(*p6));
    let v1418_49: Space = singleton(&(v1418_48));
    drop(v1418_48);
    let v1418_50: Space = map_map_kernels::unite(&(v1418_46),&(v1418_49));
    drop(v1418_46);
    drop(v1418_49);
    let v1418_52: Path = concat_path(&(*CONSTANT_22),&(*p7));
    let v1418_53: Space = singleton(&(v1418_52));
    drop(v1418_52);
    let v1418_54: Space = map_map_kernels::unite(&(v1418_50),&(v1418_53));
    drop(v1418_50);
    drop(v1418_53);
    let v1418_56: Path = concat_path(&(*CONSTANT_23),&(*p8));
    let v1418_57: Space = singleton(&(v1418_56));
    drop(v1418_56);
    let v1418_58: Space = map_map_kernels::unite(&(v1418_54),&(v1418_57));
    drop(v1418_54);
    drop(v1418_57);
    let v1418_60: Path = concat_path(&(*CONSTANT_24),&(*p0));
    let v1418_61: Space = singleton(&(v1418_60));
    drop(v1418_60);
    let v1418_62: Space = map_map_kernels::unite(&(v1418_58),&(v1418_61));
    drop(v1418_58);
    drop(v1418_61);
    map_map_kernels::compose(&(v1412_29),&(v1418_62))
  };
  drop(v1412_29);
  let v1412_64: Space = map_map_kernels::unite(&(v1412_26),&(v1412_63));
  drop(v1412_63);
  (v1412_64).clone()
}

fn routine_187(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v1419_12: Space = singleton(&(*p0));
  let v1419_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1419_12));
  let v1419_14: Space = if map_kernels::has_head(&(v1419_13)) { singleton(&[]) } else { Space::new() };
  drop(v1419_13);
  let v1419_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1419_14));
  drop(v1419_14);
  let v1419_20: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1419_12));
  drop(v1419_12);
  let v1419_21: Space = if map_kernels::has_head(&(v1419_20)) { singleton(&[]) } else { Space::new() };
  drop(v1419_20);
  let v1419_24: Path = concat_path(&(*CONSTANT_18),&(*p2));
  let v1419_25: Space = singleton(&(v1419_24));
  drop(v1419_24);
  let v1419_26: Space = map_map_kernels::unite(&(*CONSTANT_27),&(v1419_25));
  drop(v1419_25);
  let v1419_28: Path = concat_path(&(*CONSTANT_19),&(*p3));
  let v1419_29: Space = singleton(&(v1419_28));
  drop(v1419_28);
  let v1419_30: Space = map_map_kernels::unite(&(v1419_26),&(v1419_29));
  drop(v1419_26);
  drop(v1419_29);
  let v1419_32: Path = concat_path(&(*CONSTANT_20),&(*p4));
  let v1419_33: Space = singleton(&(v1419_32));
  drop(v1419_32);
  let v1419_34: Space = map_map_kernels::unite(&(v1419_30),&(v1419_33));
  drop(v1419_30);
  drop(v1419_33);
  let v1419_36: Path = concat_path(&(*CONSTANT_21),&(*p5));
  let v1419_37: Space = singleton(&(v1419_36));
  drop(v1419_36);
  let v1419_38: Space = map_map_kernels::unite(&(v1419_34),&(v1419_37));
  drop(v1419_34);
  drop(v1419_37);
  let v1419_40: Path = concat_path(&(*CONSTANT_22),&(*p6));
  let v1419_41: Space = singleton(&(v1419_40));
  drop(v1419_40);
  let v1419_42: Space = map_map_kernels::unite(&(v1419_38),&(v1419_41));
  drop(v1419_38);
  drop(v1419_41);
  let v1419_44: Path = concat_path(&(*CONSTANT_23),&(*p7));
  let v1419_45: Space = singleton(&(v1419_44));
  drop(v1419_44);
  let v1419_46: Space = map_map_kernels::unite(&(v1419_42),&(v1419_45));
  drop(v1419_42);
  drop(v1419_45);
  let v1419_48: Path = concat_path(&(*CONSTANT_24),&(*p8));
  let v1419_49: Space = singleton(&(v1419_48));
  drop(v1419_48);
  let v1419_50: Space = map_map_kernels::unite(&(v1419_46),&(v1419_49));
  drop(v1419_46);
  drop(v1419_49);
  let mut v1419_52 = Space::new();
  let mut v1419_52_write = v1419_52.write_zipper();
  let mut v1419_52_cursor = (*s0).read_zipper();
  let v1419_52_origin = v1419_52_cursor.path().len();
  for v1419_52_byte in v1419_52_cursor.child_mask().iter() {
    v1419_52_cursor.descend_to_existing_byte(v1419_52_byte);
    {
    let v1420_4: Space = if (&(v1419_15)).is_empty() { Space::new() } else {
      let v1421_2: Path = concat_path(&(*p1),&v1419_52_cursor.path()[v1419_52_origin..(v1419_52_origin + 1)]);
      let mut v1421_3 = Space::new();
      let mut v1421_3_write = v1421_3.write_zipper();
      let v1421_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1421_3_arg_1: &[u8] = &(v1421_2);
      let v1421_3_arg_2: &[u8] = &(*p2);
      let v1421_3_arg_3: &[u8] = &(*p3);
      let v1421_3_arg_4: &[u8] = &(*p4);
      let v1421_3_arg_5: &[u8] = &(*p5);
      let v1421_3_arg_6: &[u8] = &(*p6);
      let v1421_3_arg_7: &[u8] = &(*p7);
      let v1421_3_arg_8: &[u8] = &(*p8);
      let v1421_3_arg_10: &Space = &(&v1419_52_cursor).make_map();
      let mut v1421_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1421_3_origin = v1421_3_cursor.path().len();
      let mut v1421_3_more = v1421_3_cursor.is_val() || next_value_within(&mut v1421_3_cursor,v1421_3_origin);
      while v1421_3_more {
        {
        let v1421_3_depth = v1421_3_cursor.path().len();
        let v1422_11: Space = routine_187(c, &v1421_3_cursor.path()[v1421_3_origin..v1421_3_depth], &(*v1421_3_arg_1), &(*v1421_3_arg_2), &(*v1421_3_arg_3), &(*v1421_3_arg_4), &(*v1421_3_arg_5), &(*v1421_3_arg_6), &(*v1421_3_arg_7), &(*v1421_3_arg_8), &((*v1421_3_arg_10).read_zipper()));
        join_wrapped_into(&mut v1421_3_write,&((v1422_11).read_zipper()),&[]);
        }
        v1421_3_more = next_value_within(&mut v1421_3_cursor,v1421_3_origin);
      }
      drop(v1421_3_cursor);
      drop(v1421_3_write);
      map_map_kernels::compose(&(v1419_15),&(v1421_3))
    };
    let v1420_8: Space = if (&(v1419_21)).is_empty() { Space::new() } else {
      let v1423_2: Path = concat_path(&(*p1),&v1419_52_cursor.path()[v1419_52_origin..(v1419_52_origin + 1)]);
      let v1423_5: Path = concat_path(&(*CONSTANT_25),&(v1423_2));
      drop(v1423_2);
      let v1423_6: Space = singleton(&(v1423_5));
      drop(v1423_5);
      let v1423_7: Space = map_map_kernels::unite(&(v1419_50),&(v1423_6));
      drop(v1423_6);
      map_map_kernels::compose(&(v1419_21),&(v1423_7))
    };
    let v1420_9: Space = map_map_kernels::unite(&(v1420_4),&(v1420_8));
    drop(v1420_8);
    join_wrapped_into(&mut v1419_52_write,&((v1420_9).read_zipper()),&[]);
    }
    v1419_52_cursor.ascend(1);
  }
  drop(v1419_52_cursor);
  drop(v1419_52_write);
  drop(v1419_15);
  drop(v1419_21);
  drop(v1419_50);
  (v1419_52).clone()
}

fn routine_188(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v1424_12: Space = singleton(&(*p0));
  let v1424_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1424_12));
  let v1424_14: Space = if map_kernels::has_head(&(v1424_13)) { singleton(&[]) } else { Space::new() };
  drop(v1424_13);
  let v1424_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1424_14));
  drop(v1424_14);
  let v1424_20: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1424_12));
  drop(v1424_12);
  let v1424_21: Space = if map_kernels::has_head(&(v1424_20)) { singleton(&[]) } else { Space::new() };
  drop(v1424_20);
  let v1424_24: Path = concat_path(&(*CONSTANT_26),&(*p2));
  let v1424_25: Space = singleton(&(v1424_24));
  drop(v1424_24);
  let v1424_26: Space = map_map_kernels::unite(&(*CONSTANT_28),&(v1424_25));
  drop(v1424_25);
  let v1424_28: Path = concat_path(&(*CONSTANT_19),&(*p3));
  let v1424_29: Space = singleton(&(v1424_28));
  drop(v1424_28);
  let v1424_30: Space = map_map_kernels::unite(&(v1424_26),&(v1424_29));
  drop(v1424_26);
  drop(v1424_29);
  let v1424_32: Path = concat_path(&(*CONSTANT_20),&(*p4));
  let v1424_33: Space = singleton(&(v1424_32));
  drop(v1424_32);
  let v1424_34: Space = map_map_kernels::unite(&(v1424_30),&(v1424_33));
  drop(v1424_30);
  drop(v1424_33);
  let v1424_36: Path = concat_path(&(*CONSTANT_21),&(*p5));
  let v1424_37: Space = singleton(&(v1424_36));
  drop(v1424_36);
  let v1424_38: Space = map_map_kernels::unite(&(v1424_34),&(v1424_37));
  drop(v1424_34);
  drop(v1424_37);
  let v1424_40: Path = concat_path(&(*CONSTANT_22),&(*p6));
  let v1424_41: Space = singleton(&(v1424_40));
  drop(v1424_40);
  let v1424_42: Space = map_map_kernels::unite(&(v1424_38),&(v1424_41));
  drop(v1424_38);
  drop(v1424_41);
  let v1424_44: Path = concat_path(&(*CONSTANT_23),&(*p7));
  let v1424_45: Space = singleton(&(v1424_44));
  drop(v1424_44);
  let v1424_46: Space = map_map_kernels::unite(&(v1424_42),&(v1424_45));
  drop(v1424_42);
  drop(v1424_45);
  let v1424_48: Path = concat_path(&(*CONSTANT_24),&(*p8));
  let v1424_49: Space = singleton(&(v1424_48));
  drop(v1424_48);
  let v1424_50: Space = map_map_kernels::unite(&(v1424_46),&(v1424_49));
  drop(v1424_46);
  drop(v1424_49);
  let mut v1424_52 = Space::new();
  let mut v1424_52_write = v1424_52.write_zipper();
  let mut v1424_52_cursor = (*s0).read_zipper();
  let v1424_52_origin = v1424_52_cursor.path().len();
  for v1424_52_byte in v1424_52_cursor.child_mask().iter() {
    v1424_52_cursor.descend_to_existing_byte(v1424_52_byte);
    {
    let v1425_4: Space = if (&(v1424_15)).is_empty() { Space::new() } else {
      let v1426_2: Path = concat_path(&(*p1),&v1424_52_cursor.path()[v1424_52_origin..(v1424_52_origin + 1)]);
      let mut v1426_3 = Space::new();
      let mut v1426_3_write = v1426_3.write_zipper();
      let v1426_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1426_3_arg_1: &[u8] = &(v1426_2);
      let v1426_3_arg_2: &[u8] = &(*p2);
      let v1426_3_arg_3: &[u8] = &(*p3);
      let v1426_3_arg_4: &[u8] = &(*p4);
      let v1426_3_arg_5: &[u8] = &(*p5);
      let v1426_3_arg_6: &[u8] = &(*p6);
      let v1426_3_arg_7: &[u8] = &(*p7);
      let v1426_3_arg_8: &[u8] = &(*p8);
      let v1426_3_arg_10: &Space = &(&v1424_52_cursor).make_map();
      let mut v1426_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1426_3_origin = v1426_3_cursor.path().len();
      let mut v1426_3_more = v1426_3_cursor.is_val() || next_value_within(&mut v1426_3_cursor,v1426_3_origin);
      while v1426_3_more {
        {
        let v1426_3_depth = v1426_3_cursor.path().len();
        let v1427_11: Space = routine_188(c, &v1426_3_cursor.path()[v1426_3_origin..v1426_3_depth], &(*v1426_3_arg_1), &(*v1426_3_arg_2), &(*v1426_3_arg_3), &(*v1426_3_arg_4), &(*v1426_3_arg_5), &(*v1426_3_arg_6), &(*v1426_3_arg_7), &(*v1426_3_arg_8), &((*v1426_3_arg_10).read_zipper()));
        join_wrapped_into(&mut v1426_3_write,&((v1427_11).read_zipper()),&[]);
        }
        v1426_3_more = next_value_within(&mut v1426_3_cursor,v1426_3_origin);
      }
      drop(v1426_3_cursor);
      drop(v1426_3_write);
      map_map_kernels::compose(&(v1424_15),&(v1426_3))
    };
    let v1425_8: Space = if (&(v1424_21)).is_empty() { Space::new() } else {
      let v1428_2: Path = concat_path(&(*p1),&v1424_52_cursor.path()[v1424_52_origin..(v1424_52_origin + 1)]);
      let v1428_5: Path = concat_path(&(*CONSTANT_25),&(v1428_2));
      drop(v1428_2);
      let v1428_6: Space = singleton(&(v1428_5));
      drop(v1428_5);
      let v1428_7: Space = map_map_kernels::unite(&(v1424_50),&(v1428_6));
      drop(v1428_6);
      map_map_kernels::compose(&(v1424_21),&(v1428_7))
    };
    let v1425_9: Space = map_map_kernels::unite(&(v1425_4),&(v1425_8));
    drop(v1425_8);
    join_wrapped_into(&mut v1424_52_write,&((v1425_9).read_zipper()),&[]);
    }
    v1424_52_cursor.ascend(1);
  }
  drop(v1424_52_cursor);
  drop(v1424_52_write);
  drop(v1424_15);
  drop(v1424_21);
  drop(v1424_50);
  (v1424_52).clone()
}

fn routine_189(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v1429_12: Space = singleton(&(*p0));
  let v1429_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1429_12));
  let v1429_14: Space = if map_kernels::has_head(&(v1429_13)) { singleton(&[]) } else { Space::new() };
  drop(v1429_13);
  let v1429_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1429_14));
  drop(v1429_14);
  let v1429_20: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1429_12));
  drop(v1429_12);
  let v1429_21: Space = if map_kernels::has_head(&(v1429_20)) { singleton(&[]) } else { Space::new() };
  drop(v1429_20);
  let v1429_24: Path = concat_path(&(*CONSTANT_26),&(*p2));
  let v1429_25: Space = singleton(&(v1429_24));
  drop(v1429_24);
  let v1429_26: Space = map_map_kernels::unite(&(*CONSTANT_29),&(v1429_25));
  drop(v1429_25);
  let v1429_28: Path = concat_path(&(*CONSTANT_18),&(*p3));
  let v1429_29: Space = singleton(&(v1429_28));
  drop(v1429_28);
  let v1429_30: Space = map_map_kernels::unite(&(v1429_26),&(v1429_29));
  drop(v1429_26);
  drop(v1429_29);
  let v1429_32: Path = concat_path(&(*CONSTANT_20),&(*p4));
  let v1429_33: Space = singleton(&(v1429_32));
  drop(v1429_32);
  let v1429_34: Space = map_map_kernels::unite(&(v1429_30),&(v1429_33));
  drop(v1429_30);
  drop(v1429_33);
  let v1429_36: Path = concat_path(&(*CONSTANT_21),&(*p5));
  let v1429_37: Space = singleton(&(v1429_36));
  drop(v1429_36);
  let v1429_38: Space = map_map_kernels::unite(&(v1429_34),&(v1429_37));
  drop(v1429_34);
  drop(v1429_37);
  let v1429_40: Path = concat_path(&(*CONSTANT_22),&(*p6));
  let v1429_41: Space = singleton(&(v1429_40));
  drop(v1429_40);
  let v1429_42: Space = map_map_kernels::unite(&(v1429_38),&(v1429_41));
  drop(v1429_38);
  drop(v1429_41);
  let v1429_44: Path = concat_path(&(*CONSTANT_23),&(*p7));
  let v1429_45: Space = singleton(&(v1429_44));
  drop(v1429_44);
  let v1429_46: Space = map_map_kernels::unite(&(v1429_42),&(v1429_45));
  drop(v1429_42);
  drop(v1429_45);
  let v1429_48: Path = concat_path(&(*CONSTANT_24),&(*p8));
  let v1429_49: Space = singleton(&(v1429_48));
  drop(v1429_48);
  let v1429_50: Space = map_map_kernels::unite(&(v1429_46),&(v1429_49));
  drop(v1429_46);
  drop(v1429_49);
  let mut v1429_52 = Space::new();
  let mut v1429_52_write = v1429_52.write_zipper();
  let mut v1429_52_cursor = (*s0).read_zipper();
  let v1429_52_origin = v1429_52_cursor.path().len();
  for v1429_52_byte in v1429_52_cursor.child_mask().iter() {
    v1429_52_cursor.descend_to_existing_byte(v1429_52_byte);
    {
    let v1430_4: Space = if (&(v1429_15)).is_empty() { Space::new() } else {
      let v1431_2: Path = concat_path(&(*p1),&v1429_52_cursor.path()[v1429_52_origin..(v1429_52_origin + 1)]);
      let mut v1431_3 = Space::new();
      let mut v1431_3_write = v1431_3.write_zipper();
      let v1431_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1431_3_arg_1: &[u8] = &(v1431_2);
      let v1431_3_arg_2: &[u8] = &(*p2);
      let v1431_3_arg_3: &[u8] = &(*p3);
      let v1431_3_arg_4: &[u8] = &(*p4);
      let v1431_3_arg_5: &[u8] = &(*p5);
      let v1431_3_arg_6: &[u8] = &(*p6);
      let v1431_3_arg_7: &[u8] = &(*p7);
      let v1431_3_arg_8: &[u8] = &(*p8);
      let v1431_3_arg_10: &Space = &(&v1429_52_cursor).make_map();
      let mut v1431_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1431_3_origin = v1431_3_cursor.path().len();
      let mut v1431_3_more = v1431_3_cursor.is_val() || next_value_within(&mut v1431_3_cursor,v1431_3_origin);
      while v1431_3_more {
        {
        let v1431_3_depth = v1431_3_cursor.path().len();
        let v1432_11: Space = routine_189(c, &v1431_3_cursor.path()[v1431_3_origin..v1431_3_depth], &(*v1431_3_arg_1), &(*v1431_3_arg_2), &(*v1431_3_arg_3), &(*v1431_3_arg_4), &(*v1431_3_arg_5), &(*v1431_3_arg_6), &(*v1431_3_arg_7), &(*v1431_3_arg_8), &((*v1431_3_arg_10).read_zipper()));
        join_wrapped_into(&mut v1431_3_write,&((v1432_11).read_zipper()),&[]);
        }
        v1431_3_more = next_value_within(&mut v1431_3_cursor,v1431_3_origin);
      }
      drop(v1431_3_cursor);
      drop(v1431_3_write);
      map_map_kernels::compose(&(v1429_15),&(v1431_3))
    };
    let v1430_8: Space = if (&(v1429_21)).is_empty() { Space::new() } else {
      let v1433_2: Path = concat_path(&(*p1),&v1429_52_cursor.path()[v1429_52_origin..(v1429_52_origin + 1)]);
      let v1433_5: Path = concat_path(&(*CONSTANT_25),&(v1433_2));
      drop(v1433_2);
      let v1433_6: Space = singleton(&(v1433_5));
      drop(v1433_5);
      let v1433_7: Space = map_map_kernels::unite(&(v1429_50),&(v1433_6));
      drop(v1433_6);
      map_map_kernels::compose(&(v1429_21),&(v1433_7))
    };
    let v1430_9: Space = map_map_kernels::unite(&(v1430_4),&(v1430_8));
    drop(v1430_8);
    join_wrapped_into(&mut v1429_52_write,&((v1430_9).read_zipper()),&[]);
    }
    v1429_52_cursor.ascend(1);
  }
  drop(v1429_52_cursor);
  drop(v1429_52_write);
  drop(v1429_15);
  drop(v1429_21);
  drop(v1429_50);
  (v1429_52).clone()
}

fn routine_190(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v1434_12: Space = singleton(&(*p0));
  let v1434_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1434_12));
  let v1434_14: Space = if map_kernels::has_head(&(v1434_13)) { singleton(&[]) } else { Space::new() };
  drop(v1434_13);
  let v1434_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1434_14));
  drop(v1434_14);
  let v1434_20: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1434_12));
  drop(v1434_12);
  let v1434_21: Space = if map_kernels::has_head(&(v1434_20)) { singleton(&[]) } else { Space::new() };
  drop(v1434_20);
  let v1434_24: Path = concat_path(&(*CONSTANT_26),&(*p2));
  let v1434_25: Space = singleton(&(v1434_24));
  drop(v1434_24);
  let v1434_26: Space = map_map_kernels::unite(&(*CONSTANT_30),&(v1434_25));
  drop(v1434_25);
  let v1434_28: Path = concat_path(&(*CONSTANT_18),&(*p3));
  let v1434_29: Space = singleton(&(v1434_28));
  drop(v1434_28);
  let v1434_30: Space = map_map_kernels::unite(&(v1434_26),&(v1434_29));
  drop(v1434_26);
  drop(v1434_29);
  let v1434_32: Path = concat_path(&(*CONSTANT_19),&(*p4));
  let v1434_33: Space = singleton(&(v1434_32));
  drop(v1434_32);
  let v1434_34: Space = map_map_kernels::unite(&(v1434_30),&(v1434_33));
  drop(v1434_30);
  drop(v1434_33);
  let v1434_36: Path = concat_path(&(*CONSTANT_21),&(*p5));
  let v1434_37: Space = singleton(&(v1434_36));
  drop(v1434_36);
  let v1434_38: Space = map_map_kernels::unite(&(v1434_34),&(v1434_37));
  drop(v1434_34);
  drop(v1434_37);
  let v1434_40: Path = concat_path(&(*CONSTANT_22),&(*p6));
  let v1434_41: Space = singleton(&(v1434_40));
  drop(v1434_40);
  let v1434_42: Space = map_map_kernels::unite(&(v1434_38),&(v1434_41));
  drop(v1434_38);
  drop(v1434_41);
  let v1434_44: Path = concat_path(&(*CONSTANT_23),&(*p7));
  let v1434_45: Space = singleton(&(v1434_44));
  drop(v1434_44);
  let v1434_46: Space = map_map_kernels::unite(&(v1434_42),&(v1434_45));
  drop(v1434_42);
  drop(v1434_45);
  let v1434_48: Path = concat_path(&(*CONSTANT_24),&(*p8));
  let v1434_49: Space = singleton(&(v1434_48));
  drop(v1434_48);
  let v1434_50: Space = map_map_kernels::unite(&(v1434_46),&(v1434_49));
  drop(v1434_46);
  drop(v1434_49);
  let mut v1434_52 = Space::new();
  let mut v1434_52_write = v1434_52.write_zipper();
  let mut v1434_52_cursor = (*s0).read_zipper();
  let v1434_52_origin = v1434_52_cursor.path().len();
  for v1434_52_byte in v1434_52_cursor.child_mask().iter() {
    v1434_52_cursor.descend_to_existing_byte(v1434_52_byte);
    {
    let v1435_4: Space = if (&(v1434_15)).is_empty() { Space::new() } else {
      let v1436_2: Path = concat_path(&(*p1),&v1434_52_cursor.path()[v1434_52_origin..(v1434_52_origin + 1)]);
      let mut v1436_3 = Space::new();
      let mut v1436_3_write = v1436_3.write_zipper();
      let v1436_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1436_3_arg_1: &[u8] = &(v1436_2);
      let v1436_3_arg_2: &[u8] = &(*p2);
      let v1436_3_arg_3: &[u8] = &(*p3);
      let v1436_3_arg_4: &[u8] = &(*p4);
      let v1436_3_arg_5: &[u8] = &(*p5);
      let v1436_3_arg_6: &[u8] = &(*p6);
      let v1436_3_arg_7: &[u8] = &(*p7);
      let v1436_3_arg_8: &[u8] = &(*p8);
      let v1436_3_arg_10: &Space = &(&v1434_52_cursor).make_map();
      let mut v1436_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1436_3_origin = v1436_3_cursor.path().len();
      let mut v1436_3_more = v1436_3_cursor.is_val() || next_value_within(&mut v1436_3_cursor,v1436_3_origin);
      while v1436_3_more {
        {
        let v1436_3_depth = v1436_3_cursor.path().len();
        let v1437_11: Space = routine_190(c, &v1436_3_cursor.path()[v1436_3_origin..v1436_3_depth], &(*v1436_3_arg_1), &(*v1436_3_arg_2), &(*v1436_3_arg_3), &(*v1436_3_arg_4), &(*v1436_3_arg_5), &(*v1436_3_arg_6), &(*v1436_3_arg_7), &(*v1436_3_arg_8), &((*v1436_3_arg_10).read_zipper()));
        join_wrapped_into(&mut v1436_3_write,&((v1437_11).read_zipper()),&[]);
        }
        v1436_3_more = next_value_within(&mut v1436_3_cursor,v1436_3_origin);
      }
      drop(v1436_3_cursor);
      drop(v1436_3_write);
      map_map_kernels::compose(&(v1434_15),&(v1436_3))
    };
    let v1435_8: Space = if (&(v1434_21)).is_empty() { Space::new() } else {
      let v1438_2: Path = concat_path(&(*p1),&v1434_52_cursor.path()[v1434_52_origin..(v1434_52_origin + 1)]);
      let v1438_5: Path = concat_path(&(*CONSTANT_25),&(v1438_2));
      drop(v1438_2);
      let v1438_6: Space = singleton(&(v1438_5));
      drop(v1438_5);
      let v1438_7: Space = map_map_kernels::unite(&(v1434_50),&(v1438_6));
      drop(v1438_6);
      map_map_kernels::compose(&(v1434_21),&(v1438_7))
    };
    let v1435_9: Space = map_map_kernels::unite(&(v1435_4),&(v1435_8));
    drop(v1435_8);
    join_wrapped_into(&mut v1434_52_write,&((v1435_9).read_zipper()),&[]);
    }
    v1434_52_cursor.ascend(1);
  }
  drop(v1434_52_cursor);
  drop(v1434_52_write);
  drop(v1434_15);
  drop(v1434_21);
  drop(v1434_50);
  (v1434_52).clone()
}

fn routine_191(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v1439_12: Space = singleton(&(*p0));
  let v1439_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1439_12));
  let v1439_14: Space = if map_kernels::has_head(&(v1439_13)) { singleton(&[]) } else { Space::new() };
  drop(v1439_13);
  let v1439_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1439_14));
  drop(v1439_14);
  let v1439_20: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1439_12));
  drop(v1439_12);
  let v1439_21: Space = if map_kernels::has_head(&(v1439_20)) { singleton(&[]) } else { Space::new() };
  drop(v1439_20);
  let v1439_24: Path = concat_path(&(*CONSTANT_26),&(*p2));
  let v1439_25: Space = singleton(&(v1439_24));
  drop(v1439_24);
  let v1439_26: Space = map_map_kernels::unite(&(*CONSTANT_31),&(v1439_25));
  drop(v1439_25);
  let v1439_28: Path = concat_path(&(*CONSTANT_18),&(*p3));
  let v1439_29: Space = singleton(&(v1439_28));
  drop(v1439_28);
  let v1439_30: Space = map_map_kernels::unite(&(v1439_26),&(v1439_29));
  drop(v1439_26);
  drop(v1439_29);
  let v1439_32: Path = concat_path(&(*CONSTANT_19),&(*p4));
  let v1439_33: Space = singleton(&(v1439_32));
  drop(v1439_32);
  let v1439_34: Space = map_map_kernels::unite(&(v1439_30),&(v1439_33));
  drop(v1439_30);
  drop(v1439_33);
  let v1439_36: Path = concat_path(&(*CONSTANT_20),&(*p5));
  let v1439_37: Space = singleton(&(v1439_36));
  drop(v1439_36);
  let v1439_38: Space = map_map_kernels::unite(&(v1439_34),&(v1439_37));
  drop(v1439_34);
  drop(v1439_37);
  let v1439_40: Path = concat_path(&(*CONSTANT_22),&(*p6));
  let v1439_41: Space = singleton(&(v1439_40));
  drop(v1439_40);
  let v1439_42: Space = map_map_kernels::unite(&(v1439_38),&(v1439_41));
  drop(v1439_38);
  drop(v1439_41);
  let v1439_44: Path = concat_path(&(*CONSTANT_23),&(*p7));
  let v1439_45: Space = singleton(&(v1439_44));
  drop(v1439_44);
  let v1439_46: Space = map_map_kernels::unite(&(v1439_42),&(v1439_45));
  drop(v1439_42);
  drop(v1439_45);
  let v1439_48: Path = concat_path(&(*CONSTANT_24),&(*p8));
  let v1439_49: Space = singleton(&(v1439_48));
  drop(v1439_48);
  let v1439_50: Space = map_map_kernels::unite(&(v1439_46),&(v1439_49));
  drop(v1439_46);
  drop(v1439_49);
  let mut v1439_52 = Space::new();
  let mut v1439_52_write = v1439_52.write_zipper();
  let mut v1439_52_cursor = (*s0).read_zipper();
  let v1439_52_origin = v1439_52_cursor.path().len();
  for v1439_52_byte in v1439_52_cursor.child_mask().iter() {
    v1439_52_cursor.descend_to_existing_byte(v1439_52_byte);
    {
    let v1440_4: Space = if (&(v1439_15)).is_empty() { Space::new() } else {
      let v1441_2: Path = concat_path(&(*p1),&v1439_52_cursor.path()[v1439_52_origin..(v1439_52_origin + 1)]);
      let mut v1441_3 = Space::new();
      let mut v1441_3_write = v1441_3.write_zipper();
      let v1441_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1441_3_arg_1: &[u8] = &(v1441_2);
      let v1441_3_arg_2: &[u8] = &(*p2);
      let v1441_3_arg_3: &[u8] = &(*p3);
      let v1441_3_arg_4: &[u8] = &(*p4);
      let v1441_3_arg_5: &[u8] = &(*p5);
      let v1441_3_arg_6: &[u8] = &(*p6);
      let v1441_3_arg_7: &[u8] = &(*p7);
      let v1441_3_arg_8: &[u8] = &(*p8);
      let v1441_3_arg_10: &Space = &(&v1439_52_cursor).make_map();
      let mut v1441_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1441_3_origin = v1441_3_cursor.path().len();
      let mut v1441_3_more = v1441_3_cursor.is_val() || next_value_within(&mut v1441_3_cursor,v1441_3_origin);
      while v1441_3_more {
        {
        let v1441_3_depth = v1441_3_cursor.path().len();
        let v1442_11: Space = routine_191(c, &v1441_3_cursor.path()[v1441_3_origin..v1441_3_depth], &(*v1441_3_arg_1), &(*v1441_3_arg_2), &(*v1441_3_arg_3), &(*v1441_3_arg_4), &(*v1441_3_arg_5), &(*v1441_3_arg_6), &(*v1441_3_arg_7), &(*v1441_3_arg_8), &((*v1441_3_arg_10).read_zipper()));
        join_wrapped_into(&mut v1441_3_write,&((v1442_11).read_zipper()),&[]);
        }
        v1441_3_more = next_value_within(&mut v1441_3_cursor,v1441_3_origin);
      }
      drop(v1441_3_cursor);
      drop(v1441_3_write);
      map_map_kernels::compose(&(v1439_15),&(v1441_3))
    };
    let v1440_8: Space = if (&(v1439_21)).is_empty() { Space::new() } else {
      let v1443_2: Path = concat_path(&(*p1),&v1439_52_cursor.path()[v1439_52_origin..(v1439_52_origin + 1)]);
      let v1443_5: Path = concat_path(&(*CONSTANT_25),&(v1443_2));
      drop(v1443_2);
      let v1443_6: Space = singleton(&(v1443_5));
      drop(v1443_5);
      let v1443_7: Space = map_map_kernels::unite(&(v1439_50),&(v1443_6));
      drop(v1443_6);
      map_map_kernels::compose(&(v1439_21),&(v1443_7))
    };
    let v1440_9: Space = map_map_kernels::unite(&(v1440_4),&(v1440_8));
    drop(v1440_8);
    join_wrapped_into(&mut v1439_52_write,&((v1440_9).read_zipper()),&[]);
    }
    v1439_52_cursor.ascend(1);
  }
  drop(v1439_52_cursor);
  drop(v1439_52_write);
  drop(v1439_15);
  drop(v1439_21);
  drop(v1439_50);
  (v1439_52).clone()
}

fn routine_192(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v1444_12: Space = singleton(&(*p0));
  let v1444_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1444_12));
  let v1444_14: Space = if map_kernels::has_head(&(v1444_13)) { singleton(&[]) } else { Space::new() };
  drop(v1444_13);
  let v1444_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1444_14));
  drop(v1444_14);
  let v1444_20: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1444_12));
  drop(v1444_12);
  let v1444_21: Space = if map_kernels::has_head(&(v1444_20)) { singleton(&[]) } else { Space::new() };
  drop(v1444_20);
  let v1444_24: Path = concat_path(&(*CONSTANT_26),&(*p2));
  let v1444_25: Space = singleton(&(v1444_24));
  drop(v1444_24);
  let v1444_26: Space = map_map_kernels::unite(&(*CONSTANT_32),&(v1444_25));
  drop(v1444_25);
  let v1444_28: Path = concat_path(&(*CONSTANT_18),&(*p3));
  let v1444_29: Space = singleton(&(v1444_28));
  drop(v1444_28);
  let v1444_30: Space = map_map_kernels::unite(&(v1444_26),&(v1444_29));
  drop(v1444_26);
  drop(v1444_29);
  let v1444_32: Path = concat_path(&(*CONSTANT_19),&(*p4));
  let v1444_33: Space = singleton(&(v1444_32));
  drop(v1444_32);
  let v1444_34: Space = map_map_kernels::unite(&(v1444_30),&(v1444_33));
  drop(v1444_30);
  drop(v1444_33);
  let v1444_36: Path = concat_path(&(*CONSTANT_20),&(*p5));
  let v1444_37: Space = singleton(&(v1444_36));
  drop(v1444_36);
  let v1444_38: Space = map_map_kernels::unite(&(v1444_34),&(v1444_37));
  drop(v1444_34);
  drop(v1444_37);
  let v1444_40: Path = concat_path(&(*CONSTANT_21),&(*p6));
  let v1444_41: Space = singleton(&(v1444_40));
  drop(v1444_40);
  let v1444_42: Space = map_map_kernels::unite(&(v1444_38),&(v1444_41));
  drop(v1444_38);
  drop(v1444_41);
  let v1444_44: Path = concat_path(&(*CONSTANT_23),&(*p7));
  let v1444_45: Space = singleton(&(v1444_44));
  drop(v1444_44);
  let v1444_46: Space = map_map_kernels::unite(&(v1444_42),&(v1444_45));
  drop(v1444_42);
  drop(v1444_45);
  let v1444_48: Path = concat_path(&(*CONSTANT_24),&(*p8));
  let v1444_49: Space = singleton(&(v1444_48));
  drop(v1444_48);
  let v1444_50: Space = map_map_kernels::unite(&(v1444_46),&(v1444_49));
  drop(v1444_46);
  drop(v1444_49);
  let mut v1444_52 = Space::new();
  let mut v1444_52_write = v1444_52.write_zipper();
  let mut v1444_52_cursor = (*s0).read_zipper();
  let v1444_52_origin = v1444_52_cursor.path().len();
  for v1444_52_byte in v1444_52_cursor.child_mask().iter() {
    v1444_52_cursor.descend_to_existing_byte(v1444_52_byte);
    {
    let v1445_4: Space = if (&(v1444_15)).is_empty() { Space::new() } else {
      let v1446_2: Path = concat_path(&(*p1),&v1444_52_cursor.path()[v1444_52_origin..(v1444_52_origin + 1)]);
      let mut v1446_3 = Space::new();
      let mut v1446_3_write = v1446_3.write_zipper();
      let v1446_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1446_3_arg_1: &[u8] = &(v1446_2);
      let v1446_3_arg_2: &[u8] = &(*p2);
      let v1446_3_arg_3: &[u8] = &(*p3);
      let v1446_3_arg_4: &[u8] = &(*p4);
      let v1446_3_arg_5: &[u8] = &(*p5);
      let v1446_3_arg_6: &[u8] = &(*p6);
      let v1446_3_arg_7: &[u8] = &(*p7);
      let v1446_3_arg_8: &[u8] = &(*p8);
      let v1446_3_arg_10: &Space = &(&v1444_52_cursor).make_map();
      let mut v1446_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1446_3_origin = v1446_3_cursor.path().len();
      let mut v1446_3_more = v1446_3_cursor.is_val() || next_value_within(&mut v1446_3_cursor,v1446_3_origin);
      while v1446_3_more {
        {
        let v1446_3_depth = v1446_3_cursor.path().len();
        let v1447_11: Space = routine_192(c, &v1446_3_cursor.path()[v1446_3_origin..v1446_3_depth], &(*v1446_3_arg_1), &(*v1446_3_arg_2), &(*v1446_3_arg_3), &(*v1446_3_arg_4), &(*v1446_3_arg_5), &(*v1446_3_arg_6), &(*v1446_3_arg_7), &(*v1446_3_arg_8), &((*v1446_3_arg_10).read_zipper()));
        join_wrapped_into(&mut v1446_3_write,&((v1447_11).read_zipper()),&[]);
        }
        v1446_3_more = next_value_within(&mut v1446_3_cursor,v1446_3_origin);
      }
      drop(v1446_3_cursor);
      drop(v1446_3_write);
      map_map_kernels::compose(&(v1444_15),&(v1446_3))
    };
    let v1445_8: Space = if (&(v1444_21)).is_empty() { Space::new() } else {
      let v1448_2: Path = concat_path(&(*p1),&v1444_52_cursor.path()[v1444_52_origin..(v1444_52_origin + 1)]);
      let v1448_5: Path = concat_path(&(*CONSTANT_25),&(v1448_2));
      drop(v1448_2);
      let v1448_6: Space = singleton(&(v1448_5));
      drop(v1448_5);
      let v1448_7: Space = map_map_kernels::unite(&(v1444_50),&(v1448_6));
      drop(v1448_6);
      map_map_kernels::compose(&(v1444_21),&(v1448_7))
    };
    let v1445_9: Space = map_map_kernels::unite(&(v1445_4),&(v1445_8));
    drop(v1445_8);
    join_wrapped_into(&mut v1444_52_write,&((v1445_9).read_zipper()),&[]);
    }
    v1444_52_cursor.ascend(1);
  }
  drop(v1444_52_cursor);
  drop(v1444_52_write);
  drop(v1444_15);
  drop(v1444_21);
  drop(v1444_50);
  (v1444_52).clone()
}

fn routine_193(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v1449_12: Space = singleton(&(*p0));
  let v1449_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1449_12));
  let v1449_14: Space = if map_kernels::has_head(&(v1449_13)) { singleton(&[]) } else { Space::new() };
  drop(v1449_13);
  let v1449_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1449_14));
  drop(v1449_14);
  let v1449_20: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1449_12));
  drop(v1449_12);
  let v1449_21: Space = if map_kernels::has_head(&(v1449_20)) { singleton(&[]) } else { Space::new() };
  drop(v1449_20);
  let v1449_24: Path = concat_path(&(*CONSTANT_26),&(*p2));
  let v1449_25: Space = singleton(&(v1449_24));
  drop(v1449_24);
  let v1449_26: Space = map_map_kernels::unite(&(*CONSTANT_33),&(v1449_25));
  drop(v1449_25);
  let v1449_28: Path = concat_path(&(*CONSTANT_18),&(*p3));
  let v1449_29: Space = singleton(&(v1449_28));
  drop(v1449_28);
  let v1449_30: Space = map_map_kernels::unite(&(v1449_26),&(v1449_29));
  drop(v1449_26);
  drop(v1449_29);
  let v1449_32: Path = concat_path(&(*CONSTANT_19),&(*p4));
  let v1449_33: Space = singleton(&(v1449_32));
  drop(v1449_32);
  let v1449_34: Space = map_map_kernels::unite(&(v1449_30),&(v1449_33));
  drop(v1449_30);
  drop(v1449_33);
  let v1449_36: Path = concat_path(&(*CONSTANT_20),&(*p5));
  let v1449_37: Space = singleton(&(v1449_36));
  drop(v1449_36);
  let v1449_38: Space = map_map_kernels::unite(&(v1449_34),&(v1449_37));
  drop(v1449_34);
  drop(v1449_37);
  let v1449_40: Path = concat_path(&(*CONSTANT_21),&(*p6));
  let v1449_41: Space = singleton(&(v1449_40));
  drop(v1449_40);
  let v1449_42: Space = map_map_kernels::unite(&(v1449_38),&(v1449_41));
  drop(v1449_38);
  drop(v1449_41);
  let v1449_44: Path = concat_path(&(*CONSTANT_22),&(*p7));
  let v1449_45: Space = singleton(&(v1449_44));
  drop(v1449_44);
  let v1449_46: Space = map_map_kernels::unite(&(v1449_42),&(v1449_45));
  drop(v1449_42);
  drop(v1449_45);
  let v1449_48: Path = concat_path(&(*CONSTANT_24),&(*p8));
  let v1449_49: Space = singleton(&(v1449_48));
  drop(v1449_48);
  let v1449_50: Space = map_map_kernels::unite(&(v1449_46),&(v1449_49));
  drop(v1449_46);
  drop(v1449_49);
  let mut v1449_52 = Space::new();
  let mut v1449_52_write = v1449_52.write_zipper();
  let mut v1449_52_cursor = (*s0).read_zipper();
  let v1449_52_origin = v1449_52_cursor.path().len();
  for v1449_52_byte in v1449_52_cursor.child_mask().iter() {
    v1449_52_cursor.descend_to_existing_byte(v1449_52_byte);
    {
    let v1450_4: Space = if (&(v1449_15)).is_empty() { Space::new() } else {
      let v1451_2: Path = concat_path(&(*p1),&v1449_52_cursor.path()[v1449_52_origin..(v1449_52_origin + 1)]);
      let mut v1451_3 = Space::new();
      let mut v1451_3_write = v1451_3.write_zipper();
      let v1451_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1451_3_arg_1: &[u8] = &(v1451_2);
      let v1451_3_arg_2: &[u8] = &(*p2);
      let v1451_3_arg_3: &[u8] = &(*p3);
      let v1451_3_arg_4: &[u8] = &(*p4);
      let v1451_3_arg_5: &[u8] = &(*p5);
      let v1451_3_arg_6: &[u8] = &(*p6);
      let v1451_3_arg_7: &[u8] = &(*p7);
      let v1451_3_arg_8: &[u8] = &(*p8);
      let v1451_3_arg_10: &Space = &(&v1449_52_cursor).make_map();
      let mut v1451_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1451_3_origin = v1451_3_cursor.path().len();
      let mut v1451_3_more = v1451_3_cursor.is_val() || next_value_within(&mut v1451_3_cursor,v1451_3_origin);
      while v1451_3_more {
        {
        let v1451_3_depth = v1451_3_cursor.path().len();
        let v1452_11: Space = routine_193(c, &v1451_3_cursor.path()[v1451_3_origin..v1451_3_depth], &(*v1451_3_arg_1), &(*v1451_3_arg_2), &(*v1451_3_arg_3), &(*v1451_3_arg_4), &(*v1451_3_arg_5), &(*v1451_3_arg_6), &(*v1451_3_arg_7), &(*v1451_3_arg_8), &((*v1451_3_arg_10).read_zipper()));
        join_wrapped_into(&mut v1451_3_write,&((v1452_11).read_zipper()),&[]);
        }
        v1451_3_more = next_value_within(&mut v1451_3_cursor,v1451_3_origin);
      }
      drop(v1451_3_cursor);
      drop(v1451_3_write);
      map_map_kernels::compose(&(v1449_15),&(v1451_3))
    };
    let v1450_8: Space = if (&(v1449_21)).is_empty() { Space::new() } else {
      let v1453_2: Path = concat_path(&(*p1),&v1449_52_cursor.path()[v1449_52_origin..(v1449_52_origin + 1)]);
      let v1453_5: Path = concat_path(&(*CONSTANT_25),&(v1453_2));
      drop(v1453_2);
      let v1453_6: Space = singleton(&(v1453_5));
      drop(v1453_5);
      let v1453_7: Space = map_map_kernels::unite(&(v1449_50),&(v1453_6));
      drop(v1453_6);
      map_map_kernels::compose(&(v1449_21),&(v1453_7))
    };
    let v1450_9: Space = map_map_kernels::unite(&(v1450_4),&(v1450_8));
    drop(v1450_8);
    join_wrapped_into(&mut v1449_52_write,&((v1450_9).read_zipper()),&[]);
    }
    v1449_52_cursor.ascend(1);
  }
  drop(v1449_52_cursor);
  drop(v1449_52_write);
  drop(v1449_15);
  drop(v1449_21);
  drop(v1449_50);
  (v1449_52).clone()
}

fn routine_194(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v1454_12: Space = singleton(&(*p0));
  let v1454_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1454_12));
  let v1454_14: Space = if map_kernels::has_head(&(v1454_13)) { singleton(&[]) } else { Space::new() };
  drop(v1454_13);
  let v1454_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1454_14));
  drop(v1454_14);
  let v1454_20: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1454_12));
  drop(v1454_12);
  let v1454_21: Space = if map_kernels::has_head(&(v1454_20)) { singleton(&[]) } else { Space::new() };
  drop(v1454_20);
  let v1454_24: Path = concat_path(&(*CONSTANT_26),&(*p2));
  let v1454_25: Space = singleton(&(v1454_24));
  drop(v1454_24);
  let v1454_26: Space = map_map_kernels::unite(&(*CONSTANT_34),&(v1454_25));
  drop(v1454_25);
  let v1454_28: Path = concat_path(&(*CONSTANT_18),&(*p3));
  let v1454_29: Space = singleton(&(v1454_28));
  drop(v1454_28);
  let v1454_30: Space = map_map_kernels::unite(&(v1454_26),&(v1454_29));
  drop(v1454_26);
  drop(v1454_29);
  let v1454_32: Path = concat_path(&(*CONSTANT_19),&(*p4));
  let v1454_33: Space = singleton(&(v1454_32));
  drop(v1454_32);
  let v1454_34: Space = map_map_kernels::unite(&(v1454_30),&(v1454_33));
  drop(v1454_30);
  drop(v1454_33);
  let v1454_36: Path = concat_path(&(*CONSTANT_20),&(*p5));
  let v1454_37: Space = singleton(&(v1454_36));
  drop(v1454_36);
  let v1454_38: Space = map_map_kernels::unite(&(v1454_34),&(v1454_37));
  drop(v1454_34);
  drop(v1454_37);
  let v1454_40: Path = concat_path(&(*CONSTANT_21),&(*p6));
  let v1454_41: Space = singleton(&(v1454_40));
  drop(v1454_40);
  let v1454_42: Space = map_map_kernels::unite(&(v1454_38),&(v1454_41));
  drop(v1454_38);
  drop(v1454_41);
  let v1454_44: Path = concat_path(&(*CONSTANT_22),&(*p7));
  let v1454_45: Space = singleton(&(v1454_44));
  drop(v1454_44);
  let v1454_46: Space = map_map_kernels::unite(&(v1454_42),&(v1454_45));
  drop(v1454_42);
  drop(v1454_45);
  let v1454_48: Path = concat_path(&(*CONSTANT_23),&(*p8));
  let v1454_49: Space = singleton(&(v1454_48));
  drop(v1454_48);
  let v1454_50: Space = map_map_kernels::unite(&(v1454_46),&(v1454_49));
  drop(v1454_46);
  drop(v1454_49);
  let mut v1454_52 = Space::new();
  let mut v1454_52_write = v1454_52.write_zipper();
  let mut v1454_52_cursor = (*s0).read_zipper();
  let v1454_52_origin = v1454_52_cursor.path().len();
  for v1454_52_byte in v1454_52_cursor.child_mask().iter() {
    v1454_52_cursor.descend_to_existing_byte(v1454_52_byte);
    {
    let v1455_4: Space = if (&(v1454_15)).is_empty() { Space::new() } else {
      let v1456_2: Path = concat_path(&(*p1),&v1454_52_cursor.path()[v1454_52_origin..(v1454_52_origin + 1)]);
      let mut v1456_3 = Space::new();
      let mut v1456_3_write = v1456_3.write_zipper();
      let v1456_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1456_3_arg_1: &[u8] = &(v1456_2);
      let v1456_3_arg_2: &[u8] = &(*p2);
      let v1456_3_arg_3: &[u8] = &(*p3);
      let v1456_3_arg_4: &[u8] = &(*p4);
      let v1456_3_arg_5: &[u8] = &(*p5);
      let v1456_3_arg_6: &[u8] = &(*p6);
      let v1456_3_arg_7: &[u8] = &(*p7);
      let v1456_3_arg_8: &[u8] = &(*p8);
      let v1456_3_arg_10: &Space = &(&v1454_52_cursor).make_map();
      let mut v1456_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1456_3_origin = v1456_3_cursor.path().len();
      let mut v1456_3_more = v1456_3_cursor.is_val() || next_value_within(&mut v1456_3_cursor,v1456_3_origin);
      while v1456_3_more {
        {
        let v1456_3_depth = v1456_3_cursor.path().len();
        let v1457_11: Space = routine_194(c, &v1456_3_cursor.path()[v1456_3_origin..v1456_3_depth], &(*v1456_3_arg_1), &(*v1456_3_arg_2), &(*v1456_3_arg_3), &(*v1456_3_arg_4), &(*v1456_3_arg_5), &(*v1456_3_arg_6), &(*v1456_3_arg_7), &(*v1456_3_arg_8), &((*v1456_3_arg_10).read_zipper()));
        join_wrapped_into(&mut v1456_3_write,&((v1457_11).read_zipper()),&[]);
        }
        v1456_3_more = next_value_within(&mut v1456_3_cursor,v1456_3_origin);
      }
      drop(v1456_3_cursor);
      drop(v1456_3_write);
      map_map_kernels::compose(&(v1454_15),&(v1456_3))
    };
    let v1455_8: Space = if (&(v1454_21)).is_empty() { Space::new() } else {
      let v1458_2: Path = concat_path(&(*p1),&v1454_52_cursor.path()[v1454_52_origin..(v1454_52_origin + 1)]);
      let v1458_5: Path = concat_path(&(*CONSTANT_25),&(v1458_2));
      drop(v1458_2);
      let v1458_6: Space = singleton(&(v1458_5));
      drop(v1458_5);
      let v1458_7: Space = map_map_kernels::unite(&(v1454_50),&(v1458_6));
      drop(v1458_6);
      map_map_kernels::compose(&(v1454_21),&(v1458_7))
    };
    let v1455_9: Space = map_map_kernels::unite(&(v1455_4),&(v1455_8));
    drop(v1455_8);
    join_wrapped_into(&mut v1454_52_write,&((v1455_9).read_zipper()),&[]);
    }
    v1454_52_cursor.ascend(1);
  }
  drop(v1454_52_cursor);
  drop(v1454_52_write);
  drop(v1454_15);
  drop(v1454_21);
  drop(v1454_50);
  (v1454_52).clone()
}

fn routine_195(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v1459_12: Space = singleton(&(*p0));
  let v1459_13: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1459_12));
  let v1459_14: Space = if map_kernels::has_head(&(v1459_13)) { singleton(&[]) } else { Space::new() };
  drop(v1459_13);
  let v1459_15: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1459_14));
  drop(v1459_14);
  let v1459_20: Space = map_map_kernels::intersect(&(*CONSTANT_5),&(v1459_12));
  drop(v1459_12);
  let v1459_21: Space = if map_kernels::has_head(&(v1459_20)) { singleton(&[]) } else { Space::new() };
  drop(v1459_20);
  let v1459_24: Path = concat_path(&(*CONSTANT_26),&(*p2));
  let v1459_25: Space = singleton(&(v1459_24));
  drop(v1459_24);
  let v1459_26: Space = map_map_kernels::unite(&(*CONSTANT_35),&(v1459_25));
  drop(v1459_25);
  let v1459_28: Path = concat_path(&(*CONSTANT_18),&(*p3));
  let v1459_29: Space = singleton(&(v1459_28));
  drop(v1459_28);
  let v1459_30: Space = map_map_kernels::unite(&(v1459_26),&(v1459_29));
  drop(v1459_26);
  drop(v1459_29);
  let v1459_32: Path = concat_path(&(*CONSTANT_19),&(*p4));
  let v1459_33: Space = singleton(&(v1459_32));
  drop(v1459_32);
  let v1459_34: Space = map_map_kernels::unite(&(v1459_30),&(v1459_33));
  drop(v1459_30);
  drop(v1459_33);
  let v1459_36: Path = concat_path(&(*CONSTANT_20),&(*p5));
  let v1459_37: Space = singleton(&(v1459_36));
  drop(v1459_36);
  let v1459_38: Space = map_map_kernels::unite(&(v1459_34),&(v1459_37));
  drop(v1459_34);
  drop(v1459_37);
  let v1459_40: Path = concat_path(&(*CONSTANT_21),&(*p6));
  let v1459_41: Space = singleton(&(v1459_40));
  drop(v1459_40);
  let v1459_42: Space = map_map_kernels::unite(&(v1459_38),&(v1459_41));
  drop(v1459_38);
  drop(v1459_41);
  let v1459_44: Path = concat_path(&(*CONSTANT_22),&(*p7));
  let v1459_45: Space = singleton(&(v1459_44));
  drop(v1459_44);
  let v1459_46: Space = map_map_kernels::unite(&(v1459_42),&(v1459_45));
  drop(v1459_42);
  drop(v1459_45);
  let v1459_48: Path = concat_path(&(*CONSTANT_23),&(*p8));
  let v1459_49: Space = singleton(&(v1459_48));
  drop(v1459_48);
  let v1459_50: Space = map_map_kernels::unite(&(v1459_46),&(v1459_49));
  drop(v1459_46);
  drop(v1459_49);
  let mut v1459_52 = Space::new();
  let mut v1459_52_write = v1459_52.write_zipper();
  let mut v1459_52_cursor = (*s0).read_zipper();
  let v1459_52_origin = v1459_52_cursor.path().len();
  for v1459_52_byte in v1459_52_cursor.child_mask().iter() {
    v1459_52_cursor.descend_to_existing_byte(v1459_52_byte);
    {
    let v1460_4: Space = if (&(v1459_15)).is_empty() { Space::new() } else {
      let v1461_2: Path = concat_path(&(*p1),&v1459_52_cursor.path()[v1459_52_origin..(v1459_52_origin + 1)]);
      let mut v1461_3 = Space::new();
      let mut v1461_3_write = v1461_3.write_zipper();
      let v1461_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v1461_3_arg_1: &[u8] = &(v1461_2);
      let v1461_3_arg_2: &[u8] = &(*p2);
      let v1461_3_arg_3: &[u8] = &(*p3);
      let v1461_3_arg_4: &[u8] = &(*p4);
      let v1461_3_arg_5: &[u8] = &(*p5);
      let v1461_3_arg_6: &[u8] = &(*p6);
      let v1461_3_arg_7: &[u8] = &(*p7);
      let v1461_3_arg_8: &[u8] = &(*p8);
      let v1461_3_arg_10: &Space = &(&v1459_52_cursor).make_map();
      let mut v1461_3_cursor = descend_cursor((*CONSTANT_6).read_zipper(),&(*p0));
      let v1461_3_origin = v1461_3_cursor.path().len();
      let mut v1461_3_more = v1461_3_cursor.is_val() || next_value_within(&mut v1461_3_cursor,v1461_3_origin);
      while v1461_3_more {
        {
        let v1461_3_depth = v1461_3_cursor.path().len();
        let v1462_11: Space = routine_195(c, &v1461_3_cursor.path()[v1461_3_origin..v1461_3_depth], &(*v1461_3_arg_1), &(*v1461_3_arg_2), &(*v1461_3_arg_3), &(*v1461_3_arg_4), &(*v1461_3_arg_5), &(*v1461_3_arg_6), &(*v1461_3_arg_7), &(*v1461_3_arg_8), &((*v1461_3_arg_10).read_zipper()));
        join_wrapped_into(&mut v1461_3_write,&((v1462_11).read_zipper()),&[]);
        }
        v1461_3_more = next_value_within(&mut v1461_3_cursor,v1461_3_origin);
      }
      drop(v1461_3_cursor);
      drop(v1461_3_write);
      map_map_kernels::compose(&(v1459_15),&(v1461_3))
    };
    let v1460_8: Space = if (&(v1459_21)).is_empty() { Space::new() } else {
      let v1463_2: Path = concat_path(&(*p1),&v1459_52_cursor.path()[v1459_52_origin..(v1459_52_origin + 1)]);
      let v1463_5: Path = concat_path(&(*CONSTANT_24),&(v1463_2));
      drop(v1463_2);
      let v1463_6: Space = singleton(&(v1463_5));
      drop(v1463_5);
      let v1463_7: Space = map_map_kernels::unite(&(v1459_50),&(v1463_6));
      drop(v1463_6);
      map_map_kernels::compose(&(v1459_21),&(v1463_7))
    };
    let v1460_9: Space = map_map_kernels::unite(&(v1460_4),&(v1460_8));
    drop(v1460_8);
    join_wrapped_into(&mut v1459_52_write,&((v1460_9).read_zipper()),&[]);
    }
    v1459_52_cursor.ascend(1);
  }
  drop(v1459_52_cursor);
  drop(v1459_52_write);
  drop(v1459_15);
  drop(v1459_21);
  drop(v1459_50);
  (v1459_52).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
