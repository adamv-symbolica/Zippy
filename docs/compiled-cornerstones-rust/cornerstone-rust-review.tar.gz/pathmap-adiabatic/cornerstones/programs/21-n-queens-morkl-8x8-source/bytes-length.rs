#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 1 49 1 50 1 51 1 52 1 53 1 54 1 55 1 56"));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("255 2 1 0 2 2 1 2 3 2 2 4 3 2 5 4 2 6 5 2 7 6 2 8 7 2 9 8 2 10 9 2 11 10 2 12 11 2 13 12 2 14 13 2 15 14 2 16 15 2 17 16 2 18 17 2 19 18 2 20 19 2 21 20 2 22 21 2 23 22 2 24 23 2 25 24 2 26 25 2 27 26 2 28 27 2 29 28 2 30 29 2 31 30 2 32 31 2 33 32 2 34 33 2 35 34 2 36 35 2 37 36 2 38 37 2 39 38 2 40 39 2 41 40 2 42 41 2 43 42 2 44 43 2 45 44 2 46 45 2 47 46 2 48 47 2 49 48 2 50 49 2 51 50 2 52 51 2 53 52 2 54 53 2 55 54 2 56 55 2 57 56 2 58 57 2 59 58 2 60 59 2 61 60 2 62 61 2 63 62 2 64 63 2 65 64 2 66 65 2 67 66 2 68 67 2 69 68 2 70 69 2 71 70 2 72 71 2 73 72 2 74 73 2 75 74 2 76 75 2 77 76 2 78 77 2 79 78 2 80 79 2 81 80 2 82 81 2 83 82 2 84 83 2 85 84 2 86 85 2 87 86 2 88 87 2 89 88 2 90 89 2 91 90 2 92 91 2 93 92 2 94 93 2 95 94 2 96 95 2 97 96 2 98 97 2 99 98 2 100 99 2 101 100 2 102 101 2 103 102 2 104 103 2 105 104 2 106 105 2 107 106 2 108 107 2 109 108 2 110 109 2 111 110 2 112 111 2 113 112 2 114 113 2 115 114 2 116 115 2 117 116 2 118 117 2 119 118 2 120 119 2 121 120 2 122 121 2 123 122 2 124 123 2 125 124 2 126 125 2 127 126 2 128 127 2 129 128 2 130 129 2 131 130 2 132 131 2 133 132 2 134 133 2 135 134 2 136 135 2 137 136 2 138 137 2 139 138 2 140 139 2 141 140 2 142 141 2 143 142 2 144 143 2 145 144 2 146 145 2 147 146 2 148 147 2 149 148 2 150 149 2 151 150 2 152 151 2 153 152 2 154 153 2 155 154 2 156 155 2 157 156 2 158 157 2 159 158 2 160 159 2 161 160 2 162 161 2 163 162 2 164 163 2 165 164 2 166 165 2 167 166 2 168 167 2 169 168 2 170 169 2 171 170 2 172 171 2 173 172 2 174 173 2 175 174 2 176 175 2 177 176 2 178 177 2 179 178 2 180 179 2 181 180 2 182 181 2 183 182 2 184 183 2 185 184 2 186 185 2 187 186 2 188 187 2 189 188 2 190 189 2 191 190 2 192 191 2 193 192 2 194 193 2 195 194 2 196 195 2 197 196 2 198 197 2 199 198 2 200 199 2 201 200 2 202 201 2 203 202 2 204 203 2 205 204 2 206 205 2 207 206 2 208 207 2 209 208 2 210 209 2 211 210 2 212 211 2 213 212 2 214 213 2 215 214 2 216 215 2 217 216 2 218 217 2 219 218 2 220 219 2 221 220 2 222 221 2 223 222 2 224 223 2 225 224 2 226 225 2 227 226 2 228 227 2 229 228 2 230 229 2 231 230 2 232 231 2 233 232 2 234 233 2 235 234 2 236 235 2 237 236 2 238 237 2 239 238 2 240 239 2 241 240 2 242 241 2 243 242 2 244 243 2 245 244 2 246 245 2 247 246 2 248 247 2 249 248 2 250 249 2 251 250 2 252 251 2 253 252 2 254 253 2 255 254"));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 2 1 49 2 1 50 2 1 51 2 1 52 2 1 53 2 1 54 2 1 55 2 1 56"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,50]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("64 4 1 49 1 49 4 1 49 1 50 4 1 49 1 51 4 1 49 1 52 4 1 49 1 53 4 1 49 1 54 4 1 49 1 55 4 1 49 1 56 4 1 50 1 49 4 1 50 1 50 4 1 50 1 51 4 1 50 1 52 4 1 50 1 53 4 1 50 1 54 4 1 50 1 55 4 1 50 1 56 4 1 51 1 49 4 1 51 1 50 4 1 51 1 51 4 1 51 1 52 4 1 51 1 53 4 1 51 1 54 4 1 51 1 55 4 1 51 1 56 4 1 52 1 49 4 1 52 1 50 4 1 52 1 51 4 1 52 1 52 4 1 52 1 53 4 1 52 1 54 4 1 52 1 55 4 1 52 1 56 4 1 53 1 49 4 1 53 1 50 4 1 53 1 51 4 1 53 1 52 4 1 53 1 53 4 1 53 1 54 4 1 53 1 55 4 1 53 1 56 4 1 54 1 49 4 1 54 1 50 4 1 54 1 51 4 1 54 1 52 4 1 54 1 53 4 1 54 1 54 4 1 54 1 55 4 1 54 1 56 4 1 55 1 49 4 1 55 1 50 4 1 55 1 51 4 1 55 1 52 4 1 55 1 53 4 1 55 1 54 4 1 55 1 55 4 1 55 1 56 4 1 56 1 49 4 1 56 1 50 4 1 56 1 51 4 1 56 1 52 4 1 56 1 53 4 1 56 1 54 4 1 56 1 55 4 1 56 1 56"));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,49]));
static CONSTANT_10: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,51]));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,56]));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("100 6 1 49 1 49 1 48 6 1 49 1 49 1 50 6 1 49 1 50 1 51 6 1 49 1 51 1 52 6 1 49 1 52 1 53 6 1 49 1 53 1 54 6 1 49 1 54 1 55 6 1 49 1 55 1 56 6 1 49 1 56 1 57 6 1 50 1 49 1 49 6 1 50 1 49 1 51 6 1 50 1 50 1 48 6 1 50 1 50 1 52 6 1 50 1 51 1 53 6 1 50 1 52 1 54 6 1 50 1 53 1 55 6 1 50 1 54 1 56 6 1 50 1 55 1 57 7 1 50 1 56 2 49 48 6 1 51 1 49 1 50 6 1 51 1 49 1 52 6 1 51 1 50 1 49 6 1 51 1 50 1 53 6 1 51 1 51 1 48 6 1 51 1 51 1 54 6 1 51 1 52 1 55 6 1 51 1 53 1 56 6 1 51 1 54 1 57 7 1 51 1 55 2 49 48 7 1 51 1 56 2 49 49 6 1 52 1 49 1 51 6 1 52 1 49 1 53 6 1 52 1 50 1 50 6 1 52 1 50 1 54 6 1 52 1 51 1 49 6 1 52 1 51 1 55 6 1 52 1 52 1 48 6 1 52 1 52 1 56 6 1 52 1 53 1 57 7 1 52 1 54 2 49 48 7 1 52 1 55 2 49 49 7 1 52 1 56 2 49 50 6 1 53 1 49 1 52 6 1 53 1 49 1 54 6 1 53 1 50 1 51 6 1 53 1 50 1 55 6 1 53 1 51 1 50 6 1 53 1 51 1 56 6 1 53 1 52 1 49 6 1 53 1 52 1 57 6 1 53 1 53 1 48 7 1 53 1 53 2 49 48 7 1 53 1 54 2 49 49 7 1 53 1 55 2 49 50 7 1 53 1 56 2 49 51 6 1 54 1 49 1 53 6 1 54 1 49 1 55 6 1 54 1 50 1 52 6 1 54 1 50 1 56 6 1 54 1 51 1 51 6 1 54 1 51 1 57 6 1 54 1 52 1 50 7 1 54 1 52 2 49 48 6 1 54 1 53 1 49 7 1 54 1 53 2 49 49 6 1 54 1 54 1 48 7 1 54 1 54 2 49 50 7 1 54 1 55 2 49 51 7 1 54 1 56 2 49 52 6 1 55 1 49 1 54 6 1 55 1 49 1 56 6 1 55 1 50 1 53 6 1 55 1 50 1 57 6 1 55 1 51 1 52 7 1 55 1 51 2 49 48 6 1 55 1 52 1 51 7 1 55 1 52 2 49 49 6 1 55 1 53 1 50 7 1 55 1 53 2 49 50 6 1 55 1 54 1 49 7 1 55 1 54 2 49 51 6 1 55 1 55 1 48 7 1 55 1 55 2 49 52 7 1 55 1 56 2 49 53 6 1 56 1 49 1 55 6 1 56 1 49 1 57 6 1 56 1 50 1 54 7 1 56 1 50 2 49 48 6 1 56 1 51 1 53 7 1 56 1 51 2 49 49 6 1 56 1 52 1 52 7 1 56 1 52 2 49 50 6 1 56 1 53 1 51 7 1 56 1 53 2 49 51 6 1 56 1 54 1 50 7 1 56 1 54 2 49 52 6 1 56 1 55 1 49 7 1 56 1 55 2 49 53 6 1 56 1 56 1 48 7 1 56 1 56 2 49 54"));
static CONSTANT_13: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,52]));
static CONSTANT_14: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("36 4 1 49 1 49 4 1 50 1 49 4 1 50 1 50 4 1 51 1 49 4 1 51 1 50 4 1 51 1 51 4 1 52 1 49 4 1 52 1 50 4 1 52 1 51 4 1 52 1 52 4 1 53 1 49 4 1 53 1 50 4 1 53 1 51 4 1 53 1 52 4 1 53 1 53 4 1 54 1 49 4 1 54 1 50 4 1 54 1 51 4 1 54 1 52 4 1 54 1 53 4 1 54 1 54 4 1 55 1 49 4 1 55 1 50 4 1 55 1 51 4 1 55 1 52 4 1 55 1 53 4 1 55 1 54 4 1 55 1 55 4 1 56 1 49 4 1 56 1 50 4 1 56 1 51 4 1 56 1 52 4 1 56 1 53 4 1 56 1 54 4 1 56 1 55 4 1 56 1 56"));
static CONSTANT_15: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,53]));
static CONSTANT_16: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,54]));
static CONSTANT_17: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,55]));
fn routine_0(c: &mut Context) -> Space {
  let v0_6: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let mut v1_5 = Space::new();
    let mut v1_5_write = v1_5.write_zipper();
    let v1_5_arg_0: &[u8] = &(*CONSTANT_1);
    let v1_5_arg_1: &[u8] = &(*CONSTANT_2);
    let v1_5_arg_3: &Space = &(*CONSTANT_4);
    let mut v1_5_cursor = (*CONSTANT_3).read_zipper();
    let v1_5_origin = v1_5_cursor.path().len();
    let mut v1_5_more = v1_5_cursor.is_val() || next_value_within(&mut v1_5_cursor,v1_5_origin);
    while v1_5_more {
      {
      let v1_5_depth = v1_5_cursor.path().len();
      let mut v2_4_cursor = (*v1_5_arg_3).read_zipper();
      let v2_4_origin = v2_4_cursor.path().len();
      for v2_4_byte in v2_4_cursor.child_mask().iter() {
        v2_4_cursor.descend_to_existing_byte(v2_4_byte);
        {
        let v3_2: Path = concat_path(&(*v1_5_arg_1),&v2_4_cursor.path()[v2_4_origin..(v2_4_origin + 1)]);
        let v3_3: Space = routine_1(c, &(v3_2), &v1_5_cursor.path()[v1_5_origin..v1_5_depth], &v2_4_cursor);
        drop(v3_2);
        join_wrapped_into(&mut v1_5_write,&((v3_3).read_zipper()),&[]);
        }
        v2_4_cursor.ascend(1);
      }
      drop(v2_4_cursor);
      }
      v1_5_more = next_value_within(&mut v1_5_cursor,v1_5_origin);
    }
    drop(v1_5_cursor);
    drop(v1_5_write);
    compose(&(*CONSTANT_0),&(v1_5))
  };
  let mut v0_13 = Space::new();
  let mut v0_13_write = v0_13.write_zipper();
  let mut v0_13_cursor = (v0_6).read_zipper();
  let v0_13_origin = v0_13_cursor.path().len();
  for v0_13_byte in v0_13_cursor.child_mask().iter() {
    v0_13_cursor.descend_to_existing_byte(v0_13_byte);
    {
    let v4_2: Space = singleton(&v0_13_cursor.path()[v0_13_origin..(v0_13_origin + 1)]);
    let v4_3: Space = intersect(&(*CONSTANT_3),&(v4_2));
    let v4_4: Space = if has_head(&(v4_3)) { singleton(&[]) } else { Space::new() };
    drop(v4_3);
    let v4_5: Space = subtract(&(*CONSTANT_0),&(v4_4));
    drop(v4_4);
    let v4_8: Space = if (&(v4_5)).is_empty() { Space::new() } else {
      let mut v5_7 = Space::new();
      let mut v5_7_write = v5_7.write_zipper();
      let v5_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v5_7_arg_1: &[u8] = &v0_13_cursor.path()[v0_13_origin..(v0_13_origin + 1)];
      let v5_7_arg_3: &Space = &(&v0_13_cursor).make_map();
      let mut v5_7_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&v0_13_cursor.path()[v0_13_origin..(v0_13_origin + 1)]);
      let v5_7_origin = v5_7_cursor.path().len();
      let mut v5_7_more = v5_7_cursor.is_val() || next_value_within(&mut v5_7_cursor,v5_7_origin);
      while v5_7_more {
        {
        let v5_7_depth = v5_7_cursor.path().len();
        let mut v6_4_cursor = (*v5_7_arg_3).read_zipper();
        let v6_4_origin = v6_4_cursor.path().len();
        for v6_4_byte in v6_4_cursor.child_mask().iter() {
          v6_4_cursor.descend_to_existing_byte(v6_4_byte);
          {
          let v7_2: Path = concat_path(&(*v5_7_arg_1),&v6_4_cursor.path()[v6_4_origin..(v6_4_origin + 1)]);
          let v7_3: Space = routine_2(c, &(v7_2), &v5_7_cursor.path()[v5_7_origin..v5_7_depth], &v6_4_cursor);
          drop(v7_2);
          join_wrapped_into(&mut v5_7_write,&((v7_3).read_zipper()),&[]);
          }
          v6_4_cursor.ascend(1);
        }
        drop(v6_4_cursor);
        }
        v5_7_more = next_value_within(&mut v5_7_cursor,v5_7_origin);
      }
      drop(v5_7_cursor);
      drop(v5_7_write);
      compose(&(v4_5),&(v5_7))
    };
    drop(v4_5);
    let v4_9: Space = intersect(&(*CONSTANT_3),&(v4_2));
    drop(v4_2);
    let v4_10: Space = if has_head(&(v4_9)) { singleton(&[]) } else { Space::new() };
    drop(v4_9);
    let v4_14: Space = if (&(v4_10)).is_empty() { Space::new() } else {
      let v8_12: Space = subtract(&(*CONSTANT_6),&(descend_cursor(cursor_at(&v0_13_cursor,(v0_13_origin + 1)),&(*CONSTANT_7))));
      let mut v8_13 = Space::new();
      let mut v8_13_write = v8_13.write_zipper();
      let mut v8_13_cursor = (v8_12).read_zipper();
      let v8_13_origin = v8_13_cursor.path().len();
      for v8_13_byte in v8_13_cursor.child_mask().iter() {
        v8_13_cursor.descend_to_existing_byte(v8_13_byte);
        {
        let v9_2: Space = routine_3(c, &v8_13_cursor.path()[v8_13_origin..(v8_13_origin + 1)], &v8_13_cursor.path()[v8_13_origin..(v8_13_origin + 1)], &v0_13_cursor.path()[v0_13_origin..(v0_13_origin + 1)], &v8_13_cursor, &v0_13_cursor);
        join_wrapped_into(&mut v8_13_write,&((v9_2).read_zipper()),&[]);
        }
        v8_13_cursor.ascend(1);
      }
      drop(v8_13_cursor);
      drop(v8_13_write);
      drop(v8_12);
      compose(&(v4_10),&(v8_13))
    };
    drop(v4_10);
    let v4_15: Space = unite(&(v4_8),&(v4_14));
    join_wrapped_into(&mut v0_13_write,&((v4_15).read_zipper()),&[]);
    }
    v0_13_cursor.ascend(1);
  }
  drop(v0_13_cursor);
  drop(v0_13_write);
  let mut v0_18 = Space::new();
  let mut v0_18_write = v0_18.write_zipper();
  let mut v0_18_cursor = (v0_13).read_zipper();
  let v0_18_origin = v0_18_cursor.path().len();
  for v0_18_byte in v0_18_cursor.child_mask().iter() {
    v0_18_cursor.descend_to_existing_byte(v0_18_byte);
    {
    let v10_2: Space = singleton(&v0_18_cursor.path()[v0_18_origin..(v0_18_origin + 1)]);
    let v10_3: Space = intersect(&(*CONSTANT_3),&(v10_2));
    let v10_4: Space = if has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
    drop(v10_3);
    let v10_5: Space = subtract(&(*CONSTANT_0),&(v10_4));
    drop(v10_4);
    let v10_8: Space = if (&(v10_5)).is_empty() { Space::new() } else {
      let mut v11_7 = Space::new();
      let mut v11_7_write = v11_7.write_zipper();
      let v11_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v11_7_arg_1: &[u8] = &v0_18_cursor.path()[v0_18_origin..(v0_18_origin + 1)];
      let v11_7_arg_3: &Space = &(&v0_18_cursor).make_map();
      let mut v11_7_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&v0_18_cursor.path()[v0_18_origin..(v0_18_origin + 1)]);
      let v11_7_origin = v11_7_cursor.path().len();
      let mut v11_7_more = v11_7_cursor.is_val() || next_value_within(&mut v11_7_cursor,v11_7_origin);
      while v11_7_more {
        {
        let v11_7_depth = v11_7_cursor.path().len();
        let mut v12_4_cursor = (*v11_7_arg_3).read_zipper();
        let v12_4_origin = v12_4_cursor.path().len();
        for v12_4_byte in v12_4_cursor.child_mask().iter() {
          v12_4_cursor.descend_to_existing_byte(v12_4_byte);
          {
          let v13_2: Path = concat_path(&(*v11_7_arg_1),&v12_4_cursor.path()[v12_4_origin..(v12_4_origin + 1)]);
          let v13_3: Space = routine_4(c, &(v13_2), &v11_7_cursor.path()[v11_7_origin..v11_7_depth], &v12_4_cursor);
          drop(v13_2);
          join_wrapped_into(&mut v11_7_write,&((v13_3).read_zipper()),&[]);
          }
          v12_4_cursor.ascend(1);
        }
        drop(v12_4_cursor);
        }
        v11_7_more = next_value_within(&mut v11_7_cursor,v11_7_origin);
      }
      drop(v11_7_cursor);
      drop(v11_7_write);
      compose(&(v10_5),&(v11_7))
    };
    drop(v10_5);
    let v10_9: Space = intersect(&(*CONSTANT_3),&(v10_2));
    drop(v10_2);
    let v10_10: Space = if has_head(&(v10_9)) { singleton(&[]) } else { Space::new() };
    drop(v10_9);
    let v10_12: Space = if (&(v10_10)).is_empty() { Space::new() } else {
      let mut v14_11 = Space::new();
      let mut v14_11_write = v14_11.write_zipper();
      for v14_11_byte in v0_18_cursor.child_mask().iter() {
        v0_18_cursor.descend_to_existing_byte(v14_11_byte);
        {
        let v15_2: Space = routine_5(c, &v0_18_cursor.path()[(v0_18_origin + 1)..(v0_18_origin + 2)], &v0_18_cursor.path()[(v0_18_origin + 1)..(v0_18_origin + 2)], &v0_18_cursor.path()[v0_18_origin..(v0_18_origin + 1)], &v0_18_cursor);
        join_wrapped_into(&mut v14_11_write,&((v15_2).read_zipper()),&[]);
        }
        v0_18_cursor.ascend(1);
      }
      drop(v14_11_write);
      compose(&(v10_10),&(v14_11))
    };
    drop(v10_10);
    let v10_13: Space = unite(&(v10_8),&(v10_12));
    join_wrapped_into(&mut v0_18_write,&((v10_13).read_zipper()),&[]);
    }
    v0_18_cursor.ascend(1);
  }
  drop(v0_18_cursor);
  drop(v0_18_write);
  let mut v0_23 = Space::new();
  let mut v0_23_write = v0_23.write_zipper();
  let mut v0_23_cursor = (v0_18).read_zipper();
  let v0_23_origin = v0_23_cursor.path().len();
  for v0_23_byte in v0_23_cursor.child_mask().iter() {
    v0_23_cursor.descend_to_existing_byte(v0_23_byte);
    {
    let v16_2: Space = singleton(&v0_23_cursor.path()[v0_23_origin..(v0_23_origin + 1)]);
    let v16_3: Space = intersect(&(*CONSTANT_3),&(v16_2));
    let v16_4: Space = if has_head(&(v16_3)) { singleton(&[]) } else { Space::new() };
    drop(v16_3);
    let v16_5: Space = subtract(&(*CONSTANT_0),&(v16_4));
    drop(v16_4);
    let v16_8: Space = if (&(v16_5)).is_empty() { Space::new() } else {
      let mut v17_7 = Space::new();
      let mut v17_7_write = v17_7.write_zipper();
      let v17_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v17_7_arg_1: &[u8] = &v0_23_cursor.path()[v0_23_origin..(v0_23_origin + 1)];
      let v17_7_arg_3: &Space = &(&v0_23_cursor).make_map();
      let mut v17_7_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&v0_23_cursor.path()[v0_23_origin..(v0_23_origin + 1)]);
      let v17_7_origin = v17_7_cursor.path().len();
      let mut v17_7_more = v17_7_cursor.is_val() || next_value_within(&mut v17_7_cursor,v17_7_origin);
      while v17_7_more {
        {
        let v17_7_depth = v17_7_cursor.path().len();
        let mut v18_4_cursor = (*v17_7_arg_3).read_zipper();
        let v18_4_origin = v18_4_cursor.path().len();
        for v18_4_byte in v18_4_cursor.child_mask().iter() {
          v18_4_cursor.descend_to_existing_byte(v18_4_byte);
          {
          let v19_2: Path = concat_path(&(*v17_7_arg_1),&v18_4_cursor.path()[v18_4_origin..(v18_4_origin + 1)]);
          let v19_3: Space = routine_6(c, &(v19_2), &v17_7_cursor.path()[v17_7_origin..v17_7_depth], &v18_4_cursor);
          drop(v19_2);
          join_wrapped_into(&mut v17_7_write,&((v19_3).read_zipper()),&[]);
          }
          v18_4_cursor.ascend(1);
        }
        drop(v18_4_cursor);
        }
        v17_7_more = next_value_within(&mut v17_7_cursor,v17_7_origin);
      }
      drop(v17_7_cursor);
      drop(v17_7_write);
      compose(&(v16_5),&(v17_7))
    };
    drop(v16_5);
    let v16_9: Space = intersect(&(*CONSTANT_3),&(v16_2));
    drop(v16_2);
    let v16_10: Space = if has_head(&(v16_9)) { singleton(&[]) } else { Space::new() };
    drop(v16_9);
    let v16_12: Space = if (&(v16_10)).is_empty() { Space::new() } else {
      let mut v20_11 = Space::new();
      let mut v20_11_write = v20_11.write_zipper();
      for v20_11_byte in v0_23_cursor.child_mask().iter() {
        v0_23_cursor.descend_to_existing_byte(v20_11_byte);
        {
        let v21_2: Space = routine_7(c, &v0_23_cursor.path()[(v0_23_origin + 1)..(v0_23_origin + 2)], &v0_23_cursor.path()[(v0_23_origin + 1)..(v0_23_origin + 2)], &v0_23_cursor.path()[v0_23_origin..(v0_23_origin + 1)], &v0_23_cursor);
        join_wrapped_into(&mut v20_11_write,&((v21_2).read_zipper()),&[]);
        }
        v0_23_cursor.ascend(1);
      }
      drop(v20_11_write);
      compose(&(v16_10),&(v20_11))
    };
    drop(v16_10);
    let v16_13: Space = unite(&(v16_8),&(v16_12));
    join_wrapped_into(&mut v0_23_write,&((v16_13).read_zipper()),&[]);
    }
    v0_23_cursor.ascend(1);
  }
  drop(v0_23_cursor);
  drop(v0_23_write);
  let mut v0_28 = Space::new();
  let mut v0_28_write = v0_28.write_zipper();
  let mut v0_28_cursor = (v0_23).read_zipper();
  let v0_28_origin = v0_28_cursor.path().len();
  for v0_28_byte in v0_28_cursor.child_mask().iter() {
    v0_28_cursor.descend_to_existing_byte(v0_28_byte);
    {
    let v22_2: Space = singleton(&v0_28_cursor.path()[v0_28_origin..(v0_28_origin + 1)]);
    let v22_3: Space = intersect(&(*CONSTANT_3),&(v22_2));
    let v22_4: Space = if has_head(&(v22_3)) { singleton(&[]) } else { Space::new() };
    drop(v22_3);
    let v22_5: Space = subtract(&(*CONSTANT_0),&(v22_4));
    drop(v22_4);
    let v22_8: Space = if (&(v22_5)).is_empty() { Space::new() } else {
      let mut v23_7 = Space::new();
      let mut v23_7_write = v23_7.write_zipper();
      let v23_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v23_7_arg_1: &[u8] = &v0_28_cursor.path()[v0_28_origin..(v0_28_origin + 1)];
      let v23_7_arg_3: &Space = &(&v0_28_cursor).make_map();
      let mut v23_7_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&v0_28_cursor.path()[v0_28_origin..(v0_28_origin + 1)]);
      let v23_7_origin = v23_7_cursor.path().len();
      let mut v23_7_more = v23_7_cursor.is_val() || next_value_within(&mut v23_7_cursor,v23_7_origin);
      while v23_7_more {
        {
        let v23_7_depth = v23_7_cursor.path().len();
        let mut v24_4_cursor = (*v23_7_arg_3).read_zipper();
        let v24_4_origin = v24_4_cursor.path().len();
        for v24_4_byte in v24_4_cursor.child_mask().iter() {
          v24_4_cursor.descend_to_existing_byte(v24_4_byte);
          {
          let v25_2: Path = concat_path(&(*v23_7_arg_1),&v24_4_cursor.path()[v24_4_origin..(v24_4_origin + 1)]);
          let v25_3: Space = routine_8(c, &(v25_2), &v23_7_cursor.path()[v23_7_origin..v23_7_depth], &v24_4_cursor);
          drop(v25_2);
          join_wrapped_into(&mut v23_7_write,&((v25_3).read_zipper()),&[]);
          }
          v24_4_cursor.ascend(1);
        }
        drop(v24_4_cursor);
        }
        v23_7_more = next_value_within(&mut v23_7_cursor,v23_7_origin);
      }
      drop(v23_7_cursor);
      drop(v23_7_write);
      compose(&(v22_5),&(v23_7))
    };
    drop(v22_5);
    let v22_9: Space = intersect(&(*CONSTANT_3),&(v22_2));
    drop(v22_2);
    let v22_10: Space = if has_head(&(v22_9)) { singleton(&[]) } else { Space::new() };
    drop(v22_9);
    let v22_12: Space = if (&(v22_10)).is_empty() { Space::new() } else {
      let mut v26_11 = Space::new();
      let mut v26_11_write = v26_11.write_zipper();
      for v26_11_byte in v0_28_cursor.child_mask().iter() {
        v0_28_cursor.descend_to_existing_byte(v26_11_byte);
        {
        let v27_2: Space = routine_9(c, &v0_28_cursor.path()[(v0_28_origin + 1)..(v0_28_origin + 2)], &v0_28_cursor.path()[(v0_28_origin + 1)..(v0_28_origin + 2)], &v0_28_cursor.path()[v0_28_origin..(v0_28_origin + 1)], &v0_28_cursor);
        join_wrapped_into(&mut v26_11_write,&((v27_2).read_zipper()),&[]);
        }
        v0_28_cursor.ascend(1);
      }
      drop(v26_11_write);
      compose(&(v22_10),&(v26_11))
    };
    drop(v22_10);
    let v22_13: Space = unite(&(v22_8),&(v22_12));
    join_wrapped_into(&mut v0_28_write,&((v22_13).read_zipper()),&[]);
    }
    v0_28_cursor.ascend(1);
  }
  drop(v0_28_cursor);
  drop(v0_28_write);
  let mut v0_33 = Space::new();
  let mut v0_33_write = v0_33.write_zipper();
  let mut v0_33_cursor = (v0_28).read_zipper();
  let v0_33_origin = v0_33_cursor.path().len();
  for v0_33_byte in v0_33_cursor.child_mask().iter() {
    v0_33_cursor.descend_to_existing_byte(v0_33_byte);
    {
    let v28_2: Space = singleton(&v0_33_cursor.path()[v0_33_origin..(v0_33_origin + 1)]);
    let v28_3: Space = intersect(&(*CONSTANT_3),&(v28_2));
    let v28_4: Space = if has_head(&(v28_3)) { singleton(&[]) } else { Space::new() };
    drop(v28_3);
    let v28_5: Space = subtract(&(*CONSTANT_0),&(v28_4));
    drop(v28_4);
    let v28_8: Space = if (&(v28_5)).is_empty() { Space::new() } else {
      let mut v29_7 = Space::new();
      let mut v29_7_write = v29_7.write_zipper();
      let v29_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v29_7_arg_1: &[u8] = &v0_33_cursor.path()[v0_33_origin..(v0_33_origin + 1)];
      let v29_7_arg_3: &Space = &(&v0_33_cursor).make_map();
      let mut v29_7_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&v0_33_cursor.path()[v0_33_origin..(v0_33_origin + 1)]);
      let v29_7_origin = v29_7_cursor.path().len();
      let mut v29_7_more = v29_7_cursor.is_val() || next_value_within(&mut v29_7_cursor,v29_7_origin);
      while v29_7_more {
        {
        let v29_7_depth = v29_7_cursor.path().len();
        let mut v30_4_cursor = (*v29_7_arg_3).read_zipper();
        let v30_4_origin = v30_4_cursor.path().len();
        for v30_4_byte in v30_4_cursor.child_mask().iter() {
          v30_4_cursor.descend_to_existing_byte(v30_4_byte);
          {
          let v31_2: Path = concat_path(&(*v29_7_arg_1),&v30_4_cursor.path()[v30_4_origin..(v30_4_origin + 1)]);
          let v31_3: Space = routine_10(c, &(v31_2), &v29_7_cursor.path()[v29_7_origin..v29_7_depth], &v30_4_cursor);
          drop(v31_2);
          join_wrapped_into(&mut v29_7_write,&((v31_3).read_zipper()),&[]);
          }
          v30_4_cursor.ascend(1);
        }
        drop(v30_4_cursor);
        }
        v29_7_more = next_value_within(&mut v29_7_cursor,v29_7_origin);
      }
      drop(v29_7_cursor);
      drop(v29_7_write);
      compose(&(v28_5),&(v29_7))
    };
    drop(v28_5);
    let v28_9: Space = intersect(&(*CONSTANT_3),&(v28_2));
    drop(v28_2);
    let v28_10: Space = if has_head(&(v28_9)) { singleton(&[]) } else { Space::new() };
    drop(v28_9);
    let v28_12: Space = if (&(v28_10)).is_empty() { Space::new() } else {
      let mut v32_11 = Space::new();
      let mut v32_11_write = v32_11.write_zipper();
      for v32_11_byte in v0_33_cursor.child_mask().iter() {
        v0_33_cursor.descend_to_existing_byte(v32_11_byte);
        {
        let v33_2: Space = routine_11(c, &v0_33_cursor.path()[(v0_33_origin + 1)..(v0_33_origin + 2)], &v0_33_cursor.path()[(v0_33_origin + 1)..(v0_33_origin + 2)], &v0_33_cursor.path()[v0_33_origin..(v0_33_origin + 1)], &v0_33_cursor);
        join_wrapped_into(&mut v32_11_write,&((v33_2).read_zipper()),&[]);
        }
        v0_33_cursor.ascend(1);
      }
      drop(v32_11_write);
      compose(&(v28_10),&(v32_11))
    };
    drop(v28_10);
    let v28_13: Space = unite(&(v28_8),&(v28_12));
    join_wrapped_into(&mut v0_33_write,&((v28_13).read_zipper()),&[]);
    }
    v0_33_cursor.ascend(1);
  }
  drop(v0_33_cursor);
  drop(v0_33_write);
  let mut v0_38 = Space::new();
  let mut v0_38_write = v0_38.write_zipper();
  let mut v0_38_cursor = (v0_33).read_zipper();
  let v0_38_origin = v0_38_cursor.path().len();
  for v0_38_byte in v0_38_cursor.child_mask().iter() {
    v0_38_cursor.descend_to_existing_byte(v0_38_byte);
    {
    let v34_2: Space = singleton(&v0_38_cursor.path()[v0_38_origin..(v0_38_origin + 1)]);
    let v34_3: Space = intersect(&(*CONSTANT_3),&(v34_2));
    let v34_4: Space = if has_head(&(v34_3)) { singleton(&[]) } else { Space::new() };
    drop(v34_3);
    let v34_5: Space = subtract(&(*CONSTANT_0),&(v34_4));
    drop(v34_4);
    let v34_8: Space = if (&(v34_5)).is_empty() { Space::new() } else {
      let mut v35_7 = Space::new();
      let mut v35_7_write = v35_7.write_zipper();
      let v35_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v35_7_arg_1: &[u8] = &v0_38_cursor.path()[v0_38_origin..(v0_38_origin + 1)];
      let v35_7_arg_3: &Space = &(&v0_38_cursor).make_map();
      let mut v35_7_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&v0_38_cursor.path()[v0_38_origin..(v0_38_origin + 1)]);
      let v35_7_origin = v35_7_cursor.path().len();
      let mut v35_7_more = v35_7_cursor.is_val() || next_value_within(&mut v35_7_cursor,v35_7_origin);
      while v35_7_more {
        {
        let v35_7_depth = v35_7_cursor.path().len();
        let mut v36_4_cursor = (*v35_7_arg_3).read_zipper();
        let v36_4_origin = v36_4_cursor.path().len();
        for v36_4_byte in v36_4_cursor.child_mask().iter() {
          v36_4_cursor.descend_to_existing_byte(v36_4_byte);
          {
          let v37_2: Path = concat_path(&(*v35_7_arg_1),&v36_4_cursor.path()[v36_4_origin..(v36_4_origin + 1)]);
          let v37_3: Space = routine_12(c, &(v37_2), &v35_7_cursor.path()[v35_7_origin..v35_7_depth], &v36_4_cursor);
          drop(v37_2);
          join_wrapped_into(&mut v35_7_write,&((v37_3).read_zipper()),&[]);
          }
          v36_4_cursor.ascend(1);
        }
        drop(v36_4_cursor);
        }
        v35_7_more = next_value_within(&mut v35_7_cursor,v35_7_origin);
      }
      drop(v35_7_cursor);
      drop(v35_7_write);
      compose(&(v34_5),&(v35_7))
    };
    drop(v34_5);
    let v34_9: Space = intersect(&(*CONSTANT_3),&(v34_2));
    drop(v34_2);
    let v34_10: Space = if has_head(&(v34_9)) { singleton(&[]) } else { Space::new() };
    drop(v34_9);
    let v34_12: Space = if (&(v34_10)).is_empty() { Space::new() } else {
      let mut v38_11 = Space::new();
      let mut v38_11_write = v38_11.write_zipper();
      for v38_11_byte in v0_38_cursor.child_mask().iter() {
        v0_38_cursor.descend_to_existing_byte(v38_11_byte);
        {
        let v39_2: Space = routine_13(c, &v0_38_cursor.path()[(v0_38_origin + 1)..(v0_38_origin + 2)], &v0_38_cursor.path()[(v0_38_origin + 1)..(v0_38_origin + 2)], &v0_38_cursor.path()[v0_38_origin..(v0_38_origin + 1)], &v0_38_cursor);
        join_wrapped_into(&mut v38_11_write,&((v39_2).read_zipper()),&[]);
        }
        v0_38_cursor.ascend(1);
      }
      drop(v38_11_write);
      compose(&(v34_10),&(v38_11))
    };
    drop(v34_10);
    let v34_13: Space = unite(&(v34_8),&(v34_12));
    join_wrapped_into(&mut v0_38_write,&((v34_13).read_zipper()),&[]);
    }
    v0_38_cursor.ascend(1);
  }
  drop(v0_38_cursor);
  drop(v0_38_write);
  let mut v0_43 = Space::new();
  let mut v0_43_write = v0_43.write_zipper();
  let mut v0_43_cursor = (v0_38).read_zipper();
  let v0_43_origin = v0_43_cursor.path().len();
  for v0_43_byte in v0_43_cursor.child_mask().iter() {
    v0_43_cursor.descend_to_existing_byte(v0_43_byte);
    {
    let v40_2: Space = singleton(&v0_43_cursor.path()[v0_43_origin..(v0_43_origin + 1)]);
    let v40_3: Space = intersect(&(*CONSTANT_3),&(v40_2));
    let v40_4: Space = if has_head(&(v40_3)) { singleton(&[]) } else { Space::new() };
    drop(v40_3);
    let v40_5: Space = subtract(&(*CONSTANT_0),&(v40_4));
    drop(v40_4);
    let v40_8: Space = if (&(v40_5)).is_empty() { Space::new() } else {
      let mut v41_7 = Space::new();
      let mut v41_7_write = v41_7.write_zipper();
      let v41_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v41_7_arg_1: &[u8] = &v0_43_cursor.path()[v0_43_origin..(v0_43_origin + 1)];
      let v41_7_arg_3: &Space = &(&v0_43_cursor).make_map();
      let mut v41_7_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&v0_43_cursor.path()[v0_43_origin..(v0_43_origin + 1)]);
      let v41_7_origin = v41_7_cursor.path().len();
      let mut v41_7_more = v41_7_cursor.is_val() || next_value_within(&mut v41_7_cursor,v41_7_origin);
      while v41_7_more {
        {
        let v41_7_depth = v41_7_cursor.path().len();
        let mut v42_4_cursor = (*v41_7_arg_3).read_zipper();
        let v42_4_origin = v42_4_cursor.path().len();
        for v42_4_byte in v42_4_cursor.child_mask().iter() {
          v42_4_cursor.descend_to_existing_byte(v42_4_byte);
          {
          let v43_2: Path = concat_path(&(*v41_7_arg_1),&v42_4_cursor.path()[v42_4_origin..(v42_4_origin + 1)]);
          let v43_3: Space = routine_14(c, &(v43_2), &v41_7_cursor.path()[v41_7_origin..v41_7_depth], &v42_4_cursor);
          drop(v43_2);
          join_wrapped_into(&mut v41_7_write,&((v43_3).read_zipper()),&[]);
          }
          v42_4_cursor.ascend(1);
        }
        drop(v42_4_cursor);
        }
        v41_7_more = next_value_within(&mut v41_7_cursor,v41_7_origin);
      }
      drop(v41_7_cursor);
      drop(v41_7_write);
      compose(&(v40_5),&(v41_7))
    };
    drop(v40_5);
    let v40_9: Space = intersect(&(*CONSTANT_3),&(v40_2));
    drop(v40_2);
    let v40_10: Space = if has_head(&(v40_9)) { singleton(&[]) } else { Space::new() };
    drop(v40_9);
    let v40_12: Space = if (&(v40_10)).is_empty() { Space::new() } else {
      let mut v44_11 = Space::new();
      let mut v44_11_write = v44_11.write_zipper();
      for v44_11_byte in v0_43_cursor.child_mask().iter() {
        v0_43_cursor.descend_to_existing_byte(v44_11_byte);
        {
        let v45_2: Space = routine_15(c, &v0_43_cursor.path()[(v0_43_origin + 1)..(v0_43_origin + 2)], &v0_43_cursor.path()[(v0_43_origin + 1)..(v0_43_origin + 2)], &v0_43_cursor.path()[v0_43_origin..(v0_43_origin + 1)], &v0_43_cursor);
        join_wrapped_into(&mut v44_11_write,&((v45_2).read_zipper()),&[]);
        }
        v0_43_cursor.ascend(1);
      }
      drop(v44_11_write);
      compose(&(v40_10),&(v44_11))
    };
    drop(v40_10);
    let v40_13: Space = unite(&(v40_8),&(v40_12));
    join_wrapped_into(&mut v0_43_write,&((v40_13).read_zipper()),&[]);
    }
    v0_43_cursor.ascend(1);
  }
  drop(v0_43_cursor);
  drop(v0_43_write);
  let mut v0_48 = Space::new();
  let mut v0_48_write = v0_48.write_zipper();
  let mut v0_48_cursor = (v0_43).read_zipper();
  let v0_48_origin = v0_48_cursor.path().len();
  for v0_48_byte in v0_48_cursor.child_mask().iter() {
    v0_48_cursor.descend_to_existing_byte(v0_48_byte);
    {
    let v46_2: Space = singleton(&v0_48_cursor.path()[v0_48_origin..(v0_48_origin + 1)]);
    let v46_3: Space = intersect(&(*CONSTANT_3),&(v46_2));
    let v46_4: Space = if has_head(&(v46_3)) { singleton(&[]) } else { Space::new() };
    drop(v46_3);
    let v46_5: Space = subtract(&(*CONSTANT_0),&(v46_4));
    drop(v46_4);
    let v46_8: Space = if (&(v46_5)).is_empty() { Space::new() } else {
      let mut v47_7 = Space::new();
      let mut v47_7_write = v47_7.write_zipper();
      let v47_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v47_7_arg_1: &[u8] = &v0_48_cursor.path()[v0_48_origin..(v0_48_origin + 1)];
      let v47_7_arg_3: &Space = &(&v0_48_cursor).make_map();
      let mut v47_7_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&v0_48_cursor.path()[v0_48_origin..(v0_48_origin + 1)]);
      let v47_7_origin = v47_7_cursor.path().len();
      let mut v47_7_more = v47_7_cursor.is_val() || next_value_within(&mut v47_7_cursor,v47_7_origin);
      while v47_7_more {
        {
        let v47_7_depth = v47_7_cursor.path().len();
        let mut v48_4_cursor = (*v47_7_arg_3).read_zipper();
        let v48_4_origin = v48_4_cursor.path().len();
        for v48_4_byte in v48_4_cursor.child_mask().iter() {
          v48_4_cursor.descend_to_existing_byte(v48_4_byte);
          {
          let v49_2: Path = concat_path(&(*v47_7_arg_1),&v48_4_cursor.path()[v48_4_origin..(v48_4_origin + 1)]);
          let v49_3: Space = routine_16(c, &(v49_2), &v47_7_cursor.path()[v47_7_origin..v47_7_depth], &v48_4_cursor);
          drop(v49_2);
          join_wrapped_into(&mut v47_7_write,&((v49_3).read_zipper()),&[]);
          }
          v48_4_cursor.ascend(1);
        }
        drop(v48_4_cursor);
        }
        v47_7_more = next_value_within(&mut v47_7_cursor,v47_7_origin);
      }
      drop(v47_7_cursor);
      drop(v47_7_write);
      compose(&(v46_5),&(v47_7))
    };
    drop(v46_5);
    let v46_9: Space = intersect(&(*CONSTANT_3),&(v46_2));
    drop(v46_2);
    let v46_10: Space = if has_head(&(v46_9)) { singleton(&[]) } else { Space::new() };
    drop(v46_9);
    let v46_12: Space = if (&(v46_10)).is_empty() { Space::new() } else {
      let mut v50_11 = Space::new();
      let mut v50_11_write = v50_11.write_zipper();
      for v50_11_byte in v0_48_cursor.child_mask().iter() {
        v0_48_cursor.descend_to_existing_byte(v50_11_byte);
        {
        let v51_2: Space = routine_17(c, &v0_48_cursor.path()[(v0_48_origin + 1)..(v0_48_origin + 2)], &v0_48_cursor.path()[(v0_48_origin + 1)..(v0_48_origin + 2)], &v0_48_cursor.path()[v0_48_origin..(v0_48_origin + 1)], &v0_48_cursor);
        join_wrapped_into(&mut v50_11_write,&((v51_2).read_zipper()),&[]);
        }
        v0_48_cursor.ascend(1);
      }
      drop(v50_11_write);
      compose(&(v46_10),&(v50_11))
    };
    drop(v46_10);
    let v46_13: Space = unite(&(v46_8),&(v46_12));
    join_wrapped_into(&mut v0_48_write,&((v46_13).read_zipper()),&[]);
    }
    v0_48_cursor.ascend(1);
  }
  drop(v0_48_cursor);
  drop(v0_48_write);
  (v0_48).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v52_5: Space = singleton(&(*p1));
  let v52_6: Space = intersect(&(*CONSTANT_3),&(v52_5));
  let v52_7: Space = if has_head(&(v52_6)) { singleton(&[]) } else { Space::new() };
  drop(v52_6);
  let v52_8: Space = subtract(&(*CONSTANT_0),&(v52_7));
  drop(v52_7);
  let v52_19: Space = if (&(v52_8)).is_empty() { Space::new() } else {
    let v53_11: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v53_14: Space = if (&(v53_11)).is_empty() { Space::new() } else {
      let v54_13: Space = routine_18(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v53_11),&(v54_13))
    };
    drop(v53_11);
    let mut v53_17 = Space::new();
    let mut v53_17_write = v53_17.write_zipper();
    let mut v53_17_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v53_17_origin = v53_17_cursor.path().len();
    for v53_17_byte in v53_17_cursor.child_mask().iter() {
      v53_17_cursor.descend_to_existing_byte(v53_17_byte);
      {
      let v55_2_arg_0: &[u8] = &v53_17_cursor.path()[v53_17_origin..(v53_17_origin + 1)];
      let v55_2_arg_1: &[u8] = &(*p0);
      let v55_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v55_2_more = v53_17_cursor.is_val() || next_value_within(&mut v53_17_cursor,(v53_17_origin + 1));
      while v55_2_more {
        {
        let v55_2_depth = v53_17_cursor.path().len();
        let mut v56_4_cursor = (*v55_2_arg_3).read_zipper();
        let v56_4_origin = v56_4_cursor.path().len();
        for v56_4_byte in v56_4_cursor.child_mask().iter() {
          v56_4_cursor.descend_to_existing_byte(v56_4_byte);
          {
          let v57_2: Path = concat_path(&(*v55_2_arg_1),&v56_4_cursor.path()[v56_4_origin..(v56_4_origin + 1)]);
          let v57_3: Space = routine_1(c, &(v57_2), &v53_17_cursor.path()[v53_17_origin..v55_2_depth], &v56_4_cursor);
          drop(v57_2);
          join_wrapped_into(&mut v53_17_write,&((v57_3).read_zipper()),&[]);
          }
          v56_4_cursor.ascend(1);
        }
        drop(v56_4_cursor);
        }
        v55_2_more = next_value_within(&mut v53_17_cursor,(v53_17_origin + 1));
      }
      }
      v53_17_cursor.ascend(1);
    }
    drop(v53_17_cursor);
    drop(v53_17_write);
    let v53_18: Space = unite(&(v53_14),&(v53_17));
    compose(&(v52_8),&(v53_18))
  };
  drop(v52_8);
  let v52_21: Space = intersect(&(*CONSTANT_3),&(v52_5));
  drop(v52_5);
  let v52_22: Space = if has_head(&(v52_21)) { singleton(&[]) } else { Space::new() };
  drop(v52_21);
  let v52_29: Space = if (&(v52_22)).is_empty() { Space::new() } else {
    let v58_27: Space = routine_19(c, &(*CONSTANT_2), &(*CONSTANT_2), &(*CONSTANT_9), &(*p0), &((*CONSTANT_4).read_zipper()));
    let v58_28: Space = intersect(&(*CONSTANT_8),&(v58_27));
    compose(&(v52_22),&(v58_28))
  };
  drop(v52_22);
  let v52_30: Space = wrap(&(v52_29),&(*CONSTANT_1));
  let v52_31: Space = wrap(&(v52_30),&(*p0));
  let v52_32: Space = unite(&(v52_19),&(v52_31));
  (v52_32).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v59_5: Space = singleton(&(*p1));
  let v59_6: Space = intersect(&(*CONSTANT_3),&(v59_5));
  let v59_7: Space = if has_head(&(v59_6)) { singleton(&[]) } else { Space::new() };
  drop(v59_6);
  let v59_8: Space = subtract(&(*CONSTANT_0),&(v59_7));
  drop(v59_7);
  let v59_19: Space = if (&(v59_8)).is_empty() { Space::new() } else {
    let v60_11: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v60_14: Space = if (&(v60_11)).is_empty() { Space::new() } else {
      let v61_13: Space = routine_20(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v60_11),&(v61_13))
    };
    drop(v60_11);
    let mut v60_17 = Space::new();
    let mut v60_17_write = v60_17.write_zipper();
    let mut v60_17_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v60_17_origin = v60_17_cursor.path().len();
    for v60_17_byte in v60_17_cursor.child_mask().iter() {
      v60_17_cursor.descend_to_existing_byte(v60_17_byte);
      {
      let v62_2_arg_0: &[u8] = &v60_17_cursor.path()[v60_17_origin..(v60_17_origin + 1)];
      let v62_2_arg_1: &[u8] = &(*p0);
      let v62_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v62_2_more = v60_17_cursor.is_val() || next_value_within(&mut v60_17_cursor,(v60_17_origin + 1));
      while v62_2_more {
        {
        let v62_2_depth = v60_17_cursor.path().len();
        let mut v63_4_cursor = (*v62_2_arg_3).read_zipper();
        let v63_4_origin = v63_4_cursor.path().len();
        for v63_4_byte in v63_4_cursor.child_mask().iter() {
          v63_4_cursor.descend_to_existing_byte(v63_4_byte);
          {
          let v64_2: Path = concat_path(&(*v62_2_arg_1),&v63_4_cursor.path()[v63_4_origin..(v63_4_origin + 1)]);
          let v64_3: Space = routine_2(c, &(v64_2), &v60_17_cursor.path()[v60_17_origin..v62_2_depth], &v63_4_cursor);
          drop(v64_2);
          join_wrapped_into(&mut v60_17_write,&((v64_3).read_zipper()),&[]);
          }
          v63_4_cursor.ascend(1);
        }
        drop(v63_4_cursor);
        }
        v62_2_more = next_value_within(&mut v60_17_cursor,(v60_17_origin + 1));
      }
      }
      v60_17_cursor.ascend(1);
    }
    drop(v60_17_cursor);
    drop(v60_17_write);
    let v60_18: Space = unite(&(v60_14),&(v60_17));
    compose(&(v59_8),&(v60_18))
  };
  drop(v59_8);
  let v59_21: Space = intersect(&(*CONSTANT_3),&(v59_5));
  drop(v59_5);
  let v59_22: Space = if has_head(&(v59_21)) { singleton(&[]) } else { Space::new() };
  drop(v59_21);
  let v59_28: Space = if (&(v59_22)).is_empty() { Space::new() } else {
    let v65_26: Space = subtract(&(*CONSTANT_6),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_7))));
    let mut v65_27 = Space::new();
    let mut v65_27_write = v65_27.write_zipper();
    let mut v65_27_cursor = (v65_26).read_zipper();
    let v65_27_origin = v65_27_cursor.path().len();
    for v65_27_byte in v65_27_cursor.child_mask().iter() {
      v65_27_cursor.descend_to_existing_byte(v65_27_byte);
      {
      let v66_2: Space = routine_3(c, &v65_27_cursor.path()[v65_27_origin..(v65_27_origin + 1)], &v65_27_cursor.path()[v65_27_origin..(v65_27_origin + 1)], &(*p0), &v65_27_cursor, &(*s0));
      join_wrapped_into(&mut v65_27_write,&((v66_2).read_zipper()),&[]);
      }
      v65_27_cursor.ascend(1);
    }
    drop(v65_27_cursor);
    drop(v65_27_write);
    drop(v65_26);
    compose(&(v59_22),&(v65_27))
  };
  drop(v59_22);
  let v59_29: Space = unite(&(v59_19),&(v59_28));
  (v59_29).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v67_7: Space = singleton(&(*p1));
  let v67_8: Space = intersect(&(*CONSTANT_3),&(v67_7));
  let v67_9: Space = if has_head(&(v67_8)) { singleton(&[]) } else { Space::new() };
  drop(v67_8);
  let v67_10: Space = subtract(&(*CONSTANT_0),&(v67_9));
  drop(v67_9);
  let v67_21: Space = if (&(v67_10)).is_empty() { Space::new() } else {
    let v68_13: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v68_16: Space = if (&(v68_13)).is_empty() { Space::new() } else {
      let v69_15: Space = routine_21(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0), &(*s1));
      compose(&(v68_13),&(v69_15))
    };
    drop(v68_13);
    let mut v68_19 = Space::new();
    let mut v68_19_write = v68_19.write_zipper();
    let mut v68_19_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v68_19_origin = v68_19_cursor.path().len();
    for v68_19_byte in v68_19_cursor.child_mask().iter() {
      v68_19_cursor.descend_to_existing_byte(v68_19_byte);
      {
      let v70_2_arg_0: &[u8] = &v68_19_cursor.path()[v68_19_origin..(v68_19_origin + 1)];
      let v70_2_arg_1: &[u8] = &(*p0);
      let v70_2_arg_2: &[u8] = &(*p2);
      let v70_2_arg_4: &Space = &(&(*s0)).make_map();
      let v70_2_arg_5: &Space = &(&(*s1)).make_map();
      let mut v70_2_more = v68_19_cursor.is_val() || next_value_within(&mut v68_19_cursor,(v68_19_origin + 1));
      while v70_2_more {
        {
        let v70_2_depth = v68_19_cursor.path().len();
        let mut v71_6_cursor = (*v70_2_arg_4).read_zipper();
        let v71_6_origin = v71_6_cursor.path().len();
        for v71_6_byte in v71_6_cursor.child_mask().iter() {
          v71_6_cursor.descend_to_existing_byte(v71_6_byte);
          {
          let v72_2: Path = concat_path(&(*v70_2_arg_1),&v71_6_cursor.path()[v71_6_origin..(v71_6_origin + 1)]);
          let v72_3: Space = routine_3(c, &(v72_2), &v68_19_cursor.path()[v68_19_origin..v70_2_depth], &(*v70_2_arg_2), &v71_6_cursor, &((*v70_2_arg_5).read_zipper()));
          drop(v72_2);
          join_wrapped_into(&mut v68_19_write,&((v72_3).read_zipper()),&[]);
          }
          v71_6_cursor.ascend(1);
        }
        drop(v71_6_cursor);
        }
        v70_2_more = next_value_within(&mut v68_19_cursor,(v68_19_origin + 1));
      }
      }
      v68_19_cursor.ascend(1);
    }
    drop(v68_19_cursor);
    drop(v68_19_write);
    let v68_20: Space = unite(&(v68_16),&(v68_19));
    compose(&(v67_10),&(v68_20))
  };
  drop(v67_10);
  let v67_23: Space = intersect(&(*CONSTANT_3),&(v67_7));
  drop(v67_7);
  let v67_24: Space = if has_head(&(v67_23)) { singleton(&[]) } else { Space::new() };
  drop(v67_23);
  let v67_32: Space = if (&(v67_24)).is_empty() { Space::new() } else {
    let v73_29: Space = routine_19(c, &(*CONSTANT_2), &(*CONSTANT_2), &(*CONSTANT_7), &(*p0), &((*CONSTANT_4).read_zipper()));
    let v73_30: Space = intersect(&(*CONSTANT_8),&(v73_29));
    let v73_31: Space = unite(&(v73_30),&(*s1));
    compose(&(v67_24),&(v73_31))
  };
  drop(v67_24);
  let v67_33: Space = wrap(&(v67_32),&(*p2));
  let v67_34: Space = wrap(&(v67_33),&(*p0));
  let v67_35: Space = unite(&(v67_21),&(v67_34));
  (v67_35).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v74_5: Space = singleton(&(*p1));
  let v74_6: Space = intersect(&(*CONSTANT_3),&(v74_5));
  let v74_7: Space = if has_head(&(v74_6)) { singleton(&[]) } else { Space::new() };
  drop(v74_6);
  let v74_8: Space = subtract(&(*CONSTANT_0),&(v74_7));
  drop(v74_7);
  let v74_19: Space = if (&(v74_8)).is_empty() { Space::new() } else {
    let v75_11: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v75_14: Space = if (&(v75_11)).is_empty() { Space::new() } else {
      let v76_13: Space = routine_22(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v75_11),&(v76_13))
    };
    drop(v75_11);
    let mut v75_17 = Space::new();
    let mut v75_17_write = v75_17.write_zipper();
    let mut v75_17_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v75_17_origin = v75_17_cursor.path().len();
    for v75_17_byte in v75_17_cursor.child_mask().iter() {
      v75_17_cursor.descend_to_existing_byte(v75_17_byte);
      {
      let v77_2_arg_0: &[u8] = &v75_17_cursor.path()[v75_17_origin..(v75_17_origin + 1)];
      let v77_2_arg_1: &[u8] = &(*p0);
      let v77_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v77_2_more = v75_17_cursor.is_val() || next_value_within(&mut v75_17_cursor,(v75_17_origin + 1));
      while v77_2_more {
        {
        let v77_2_depth = v75_17_cursor.path().len();
        let mut v78_4_cursor = (*v77_2_arg_3).read_zipper();
        let v78_4_origin = v78_4_cursor.path().len();
        for v78_4_byte in v78_4_cursor.child_mask().iter() {
          v78_4_cursor.descend_to_existing_byte(v78_4_byte);
          {
          let v79_2: Path = concat_path(&(*v77_2_arg_1),&v78_4_cursor.path()[v78_4_origin..(v78_4_origin + 1)]);
          let v79_3: Space = routine_4(c, &(v79_2), &v75_17_cursor.path()[v75_17_origin..v77_2_depth], &v78_4_cursor);
          drop(v79_2);
          join_wrapped_into(&mut v75_17_write,&((v79_3).read_zipper()),&[]);
          }
          v78_4_cursor.ascend(1);
        }
        drop(v78_4_cursor);
        }
        v77_2_more = next_value_within(&mut v75_17_cursor,(v75_17_origin + 1));
      }
      }
      v75_17_cursor.ascend(1);
    }
    drop(v75_17_cursor);
    drop(v75_17_write);
    let v75_18: Space = unite(&(v75_14),&(v75_17));
    compose(&(v74_8),&(v75_18))
  };
  drop(v74_8);
  let v74_21: Space = intersect(&(*CONSTANT_3),&(v74_5));
  drop(v74_5);
  let v74_22: Space = if has_head(&(v74_21)) { singleton(&[]) } else { Space::new() };
  drop(v74_21);
  let v74_24: Space = if (&(v74_22)).is_empty() { Space::new() } else {
    let mut v80_23 = Space::new();
    let mut v80_23_write = v80_23.write_zipper();
    let mut v80_23_cursor = (*s0).read_zipper();
    let v80_23_origin = v80_23_cursor.path().len();
    for v80_23_byte in v80_23_cursor.child_mask().iter() {
      v80_23_cursor.descend_to_existing_byte(v80_23_byte);
      {
      let v81_2: Space = routine_5(c, &v80_23_cursor.path()[v80_23_origin..(v80_23_origin + 1)], &v80_23_cursor.path()[v80_23_origin..(v80_23_origin + 1)], &(*p0), &v80_23_cursor);
      join_wrapped_into(&mut v80_23_write,&((v81_2).read_zipper()),&[]);
      }
      v80_23_cursor.ascend(1);
    }
    drop(v80_23_cursor);
    drop(v80_23_write);
    compose(&(v74_22),&(v80_23))
  };
  drop(v74_22);
  let v74_25: Space = unite(&(v74_19),&(v74_24));
  (v74_25).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v82_6: Space = singleton(&(*p1));
  let v82_7: Space = intersect(&(*CONSTANT_3),&(v82_6));
  let v82_8: Space = if has_head(&(v82_7)) { singleton(&[]) } else { Space::new() };
  drop(v82_7);
  let v82_9: Space = subtract(&(*CONSTANT_0),&(v82_8));
  drop(v82_8);
  let v82_20: Space = if (&(v82_9)).is_empty() { Space::new() } else {
    let v83_12: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v83_15: Space = if (&(v83_12)).is_empty() { Space::new() } else {
      let v84_14: Space = routine_23(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v83_12),&(v84_14))
    };
    drop(v83_12);
    let mut v83_18 = Space::new();
    let mut v83_18_write = v83_18.write_zipper();
    let mut v83_18_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v83_18_origin = v83_18_cursor.path().len();
    for v83_18_byte in v83_18_cursor.child_mask().iter() {
      v83_18_cursor.descend_to_existing_byte(v83_18_byte);
      {
      let v85_2_arg_0: &[u8] = &v83_18_cursor.path()[v83_18_origin..(v83_18_origin + 1)];
      let v85_2_arg_1: &[u8] = &(*p0);
      let v85_2_arg_2: &[u8] = &(*p2);
      let v85_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v85_2_more = v83_18_cursor.is_val() || next_value_within(&mut v83_18_cursor,(v83_18_origin + 1));
      while v85_2_more {
        {
        let v85_2_depth = v83_18_cursor.path().len();
        let mut v86_5_cursor = (*v85_2_arg_4).read_zipper();
        let v86_5_origin = v86_5_cursor.path().len();
        for v86_5_byte in v86_5_cursor.child_mask().iter() {
          v86_5_cursor.descend_to_existing_byte(v86_5_byte);
          {
          let v87_2: Path = concat_path(&(*v85_2_arg_1),&v86_5_cursor.path()[v86_5_origin..(v86_5_origin + 1)]);
          let v87_3: Space = routine_5(c, &(v87_2), &v83_18_cursor.path()[v83_18_origin..v85_2_depth], &(*v85_2_arg_2), &v86_5_cursor);
          drop(v87_2);
          join_wrapped_into(&mut v83_18_write,&((v87_3).read_zipper()),&[]);
          }
          v86_5_cursor.ascend(1);
        }
        drop(v86_5_cursor);
        }
        v85_2_more = next_value_within(&mut v83_18_cursor,(v83_18_origin + 1));
      }
      }
      v83_18_cursor.ascend(1);
    }
    drop(v83_18_cursor);
    drop(v83_18_write);
    let v83_19: Space = unite(&(v83_15),&(v83_18));
    compose(&(v82_9),&(v83_19))
  };
  drop(v82_9);
  let v82_22: Space = intersect(&(*CONSTANT_3),&(v82_6));
  drop(v82_6);
  let v82_23: Space = if has_head(&(v82_22)) { singleton(&[]) } else { Space::new() };
  drop(v82_22);
  let v82_29: Space = if (&(v82_23)).is_empty() { Space::new() } else {
    let v88_27: Space = subtract(&(*CONSTANT_6),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_10))));
    let mut v88_28 = Space::new();
    let mut v88_28_write = v88_28.write_zipper();
    let mut v88_28_cursor = (v88_27).read_zipper();
    let v88_28_origin = v88_28_cursor.path().len();
    for v88_28_byte in v88_28_cursor.child_mask().iter() {
      v88_28_cursor.descend_to_existing_byte(v88_28_byte);
      {
      let v89_2: Space = routine_24(c, &v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)], &v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)], &(*p2), &(*p0), &v88_28_cursor, &(*s0));
      join_wrapped_into(&mut v88_28_write,&((v89_2).read_zipper()),&[]);
      }
      v88_28_cursor.ascend(1);
    }
    drop(v88_28_cursor);
    drop(v88_28_write);
    drop(v88_27);
    compose(&(v82_23),&(v88_28))
  };
  drop(v82_23);
  let v82_30: Space = unite(&(v82_20),&(v82_29));
  (v82_30).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v90_5: Space = singleton(&(*p1));
  let v90_6: Space = intersect(&(*CONSTANT_3),&(v90_5));
  let v90_7: Space = if has_head(&(v90_6)) { singleton(&[]) } else { Space::new() };
  drop(v90_6);
  let v90_8: Space = subtract(&(*CONSTANT_0),&(v90_7));
  drop(v90_7);
  let v90_19: Space = if (&(v90_8)).is_empty() { Space::new() } else {
    let v91_11: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v91_14: Space = if (&(v91_11)).is_empty() { Space::new() } else {
      let v92_13: Space = routine_25(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v91_11),&(v92_13))
    };
    drop(v91_11);
    let mut v91_17 = Space::new();
    let mut v91_17_write = v91_17.write_zipper();
    let mut v91_17_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v91_17_origin = v91_17_cursor.path().len();
    for v91_17_byte in v91_17_cursor.child_mask().iter() {
      v91_17_cursor.descend_to_existing_byte(v91_17_byte);
      {
      let v93_2_arg_0: &[u8] = &v91_17_cursor.path()[v91_17_origin..(v91_17_origin + 1)];
      let v93_2_arg_1: &[u8] = &(*p0);
      let v93_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v93_2_more = v91_17_cursor.is_val() || next_value_within(&mut v91_17_cursor,(v91_17_origin + 1));
      while v93_2_more {
        {
        let v93_2_depth = v91_17_cursor.path().len();
        let mut v94_4_cursor = (*v93_2_arg_3).read_zipper();
        let v94_4_origin = v94_4_cursor.path().len();
        for v94_4_byte in v94_4_cursor.child_mask().iter() {
          v94_4_cursor.descend_to_existing_byte(v94_4_byte);
          {
          let v95_2: Path = concat_path(&(*v93_2_arg_1),&v94_4_cursor.path()[v94_4_origin..(v94_4_origin + 1)]);
          let v95_3: Space = routine_6(c, &(v95_2), &v91_17_cursor.path()[v91_17_origin..v93_2_depth], &v94_4_cursor);
          drop(v95_2);
          join_wrapped_into(&mut v91_17_write,&((v95_3).read_zipper()),&[]);
          }
          v94_4_cursor.ascend(1);
        }
        drop(v94_4_cursor);
        }
        v93_2_more = next_value_within(&mut v91_17_cursor,(v91_17_origin + 1));
      }
      }
      v91_17_cursor.ascend(1);
    }
    drop(v91_17_cursor);
    drop(v91_17_write);
    let v91_18: Space = unite(&(v91_14),&(v91_17));
    compose(&(v90_8),&(v91_18))
  };
  drop(v90_8);
  let v90_21: Space = intersect(&(*CONSTANT_3),&(v90_5));
  drop(v90_5);
  let v90_22: Space = if has_head(&(v90_21)) { singleton(&[]) } else { Space::new() };
  drop(v90_21);
  let v90_24: Space = if (&(v90_22)).is_empty() { Space::new() } else {
    let mut v96_23 = Space::new();
    let mut v96_23_write = v96_23.write_zipper();
    let mut v96_23_cursor = (*s0).read_zipper();
    let v96_23_origin = v96_23_cursor.path().len();
    for v96_23_byte in v96_23_cursor.child_mask().iter() {
      v96_23_cursor.descend_to_existing_byte(v96_23_byte);
      {
      let v97_2: Space = routine_7(c, &v96_23_cursor.path()[v96_23_origin..(v96_23_origin + 1)], &v96_23_cursor.path()[v96_23_origin..(v96_23_origin + 1)], &(*p0), &v96_23_cursor);
      join_wrapped_into(&mut v96_23_write,&((v97_2).read_zipper()),&[]);
      }
      v96_23_cursor.ascend(1);
    }
    drop(v96_23_cursor);
    drop(v96_23_write);
    compose(&(v90_22),&(v96_23))
  };
  drop(v90_22);
  let v90_25: Space = unite(&(v90_19),&(v90_24));
  (v90_25).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v98_6: Space = singleton(&(*p1));
  let v98_7: Space = intersect(&(*CONSTANT_3),&(v98_6));
  let v98_8: Space = if has_head(&(v98_7)) { singleton(&[]) } else { Space::new() };
  drop(v98_7);
  let v98_9: Space = subtract(&(*CONSTANT_0),&(v98_8));
  drop(v98_8);
  let v98_20: Space = if (&(v98_9)).is_empty() { Space::new() } else {
    let v99_12: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v99_15: Space = if (&(v99_12)).is_empty() { Space::new() } else {
      let v100_14: Space = routine_26(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v99_12),&(v100_14))
    };
    drop(v99_12);
    let mut v99_18 = Space::new();
    let mut v99_18_write = v99_18.write_zipper();
    let mut v99_18_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v99_18_origin = v99_18_cursor.path().len();
    for v99_18_byte in v99_18_cursor.child_mask().iter() {
      v99_18_cursor.descend_to_existing_byte(v99_18_byte);
      {
      let v101_2_arg_0: &[u8] = &v99_18_cursor.path()[v99_18_origin..(v99_18_origin + 1)];
      let v101_2_arg_1: &[u8] = &(*p0);
      let v101_2_arg_2: &[u8] = &(*p2);
      let v101_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v101_2_more = v99_18_cursor.is_val() || next_value_within(&mut v99_18_cursor,(v99_18_origin + 1));
      while v101_2_more {
        {
        let v101_2_depth = v99_18_cursor.path().len();
        let mut v102_5_cursor = (*v101_2_arg_4).read_zipper();
        let v102_5_origin = v102_5_cursor.path().len();
        for v102_5_byte in v102_5_cursor.child_mask().iter() {
          v102_5_cursor.descend_to_existing_byte(v102_5_byte);
          {
          let v103_2: Path = concat_path(&(*v101_2_arg_1),&v102_5_cursor.path()[v102_5_origin..(v102_5_origin + 1)]);
          let v103_3: Space = routine_7(c, &(v103_2), &v99_18_cursor.path()[v99_18_origin..v101_2_depth], &(*v101_2_arg_2), &v102_5_cursor);
          drop(v103_2);
          join_wrapped_into(&mut v99_18_write,&((v103_3).read_zipper()),&[]);
          }
          v102_5_cursor.ascend(1);
        }
        drop(v102_5_cursor);
        }
        v101_2_more = next_value_within(&mut v99_18_cursor,(v99_18_origin + 1));
      }
      }
      v99_18_cursor.ascend(1);
    }
    drop(v99_18_cursor);
    drop(v99_18_write);
    let v99_19: Space = unite(&(v99_15),&(v99_18));
    compose(&(v98_9),&(v99_19))
  };
  drop(v98_9);
  let v98_22: Space = intersect(&(*CONSTANT_3),&(v98_6));
  drop(v98_6);
  let v98_23: Space = if has_head(&(v98_22)) { singleton(&[]) } else { Space::new() };
  drop(v98_22);
  let v98_25: Space = if (&(v98_23)).is_empty() { Space::new() } else {
    let mut v104_24 = Space::new();
    let mut v104_24_write = v104_24.write_zipper();
    let mut v104_24_cursor = (*s0).read_zipper();
    let v104_24_origin = v104_24_cursor.path().len();
    for v104_24_byte in v104_24_cursor.child_mask().iter() {
      v104_24_cursor.descend_to_existing_byte(v104_24_byte);
      {
      let v105_2: Space = routine_27(c, &v104_24_cursor.path()[v104_24_origin..(v104_24_origin + 1)], &v104_24_cursor.path()[v104_24_origin..(v104_24_origin + 1)], &(*p0), &(*p2), &v104_24_cursor);
      join_wrapped_into(&mut v104_24_write,&((v105_2).read_zipper()),&[]);
      }
      v104_24_cursor.ascend(1);
    }
    drop(v104_24_cursor);
    drop(v104_24_write);
    compose(&(v98_23),&(v104_24))
  };
  drop(v98_23);
  let v98_26: Space = unite(&(v98_20),&(v98_25));
  (v98_26).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v106_5: Space = singleton(&(*p1));
  let v106_6: Space = intersect(&(*CONSTANT_3),&(v106_5));
  let v106_7: Space = if has_head(&(v106_6)) { singleton(&[]) } else { Space::new() };
  drop(v106_6);
  let v106_8: Space = subtract(&(*CONSTANT_0),&(v106_7));
  drop(v106_7);
  let v106_19: Space = if (&(v106_8)).is_empty() { Space::new() } else {
    let v107_11: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v107_14: Space = if (&(v107_11)).is_empty() { Space::new() } else {
      let v108_13: Space = routine_28(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v107_11),&(v108_13))
    };
    drop(v107_11);
    let mut v107_17 = Space::new();
    let mut v107_17_write = v107_17.write_zipper();
    let mut v107_17_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v107_17_origin = v107_17_cursor.path().len();
    for v107_17_byte in v107_17_cursor.child_mask().iter() {
      v107_17_cursor.descend_to_existing_byte(v107_17_byte);
      {
      let v109_2_arg_0: &[u8] = &v107_17_cursor.path()[v107_17_origin..(v107_17_origin + 1)];
      let v109_2_arg_1: &[u8] = &(*p0);
      let v109_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v109_2_more = v107_17_cursor.is_val() || next_value_within(&mut v107_17_cursor,(v107_17_origin + 1));
      while v109_2_more {
        {
        let v109_2_depth = v107_17_cursor.path().len();
        let mut v110_4_cursor = (*v109_2_arg_3).read_zipper();
        let v110_4_origin = v110_4_cursor.path().len();
        for v110_4_byte in v110_4_cursor.child_mask().iter() {
          v110_4_cursor.descend_to_existing_byte(v110_4_byte);
          {
          let v111_2: Path = concat_path(&(*v109_2_arg_1),&v110_4_cursor.path()[v110_4_origin..(v110_4_origin + 1)]);
          let v111_3: Space = routine_8(c, &(v111_2), &v107_17_cursor.path()[v107_17_origin..v109_2_depth], &v110_4_cursor);
          drop(v111_2);
          join_wrapped_into(&mut v107_17_write,&((v111_3).read_zipper()),&[]);
          }
          v110_4_cursor.ascend(1);
        }
        drop(v110_4_cursor);
        }
        v109_2_more = next_value_within(&mut v107_17_cursor,(v107_17_origin + 1));
      }
      }
      v107_17_cursor.ascend(1);
    }
    drop(v107_17_cursor);
    drop(v107_17_write);
    let v107_18: Space = unite(&(v107_14),&(v107_17));
    compose(&(v106_8),&(v107_18))
  };
  drop(v106_8);
  let v106_21: Space = intersect(&(*CONSTANT_3),&(v106_5));
  drop(v106_5);
  let v106_22: Space = if has_head(&(v106_21)) { singleton(&[]) } else { Space::new() };
  drop(v106_21);
  let v106_24: Space = if (&(v106_22)).is_empty() { Space::new() } else {
    let mut v112_23 = Space::new();
    let mut v112_23_write = v112_23.write_zipper();
    let mut v112_23_cursor = (*s0).read_zipper();
    let v112_23_origin = v112_23_cursor.path().len();
    for v112_23_byte in v112_23_cursor.child_mask().iter() {
      v112_23_cursor.descend_to_existing_byte(v112_23_byte);
      {
      let v113_2: Space = routine_9(c, &v112_23_cursor.path()[v112_23_origin..(v112_23_origin + 1)], &v112_23_cursor.path()[v112_23_origin..(v112_23_origin + 1)], &(*p0), &v112_23_cursor);
      join_wrapped_into(&mut v112_23_write,&((v113_2).read_zipper()),&[]);
      }
      v112_23_cursor.ascend(1);
    }
    drop(v112_23_cursor);
    drop(v112_23_write);
    compose(&(v106_22),&(v112_23))
  };
  drop(v106_22);
  let v106_25: Space = unite(&(v106_19),&(v106_24));
  (v106_25).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v114_6: Space = singleton(&(*p1));
  let v114_7: Space = intersect(&(*CONSTANT_3),&(v114_6));
  let v114_8: Space = if has_head(&(v114_7)) { singleton(&[]) } else { Space::new() };
  drop(v114_7);
  let v114_9: Space = subtract(&(*CONSTANT_0),&(v114_8));
  drop(v114_8);
  let v114_20: Space = if (&(v114_9)).is_empty() { Space::new() } else {
    let v115_12: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v115_15: Space = if (&(v115_12)).is_empty() { Space::new() } else {
      let v116_14: Space = routine_29(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v115_12),&(v116_14))
    };
    drop(v115_12);
    let mut v115_18 = Space::new();
    let mut v115_18_write = v115_18.write_zipper();
    let mut v115_18_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v115_18_origin = v115_18_cursor.path().len();
    for v115_18_byte in v115_18_cursor.child_mask().iter() {
      v115_18_cursor.descend_to_existing_byte(v115_18_byte);
      {
      let v117_2_arg_0: &[u8] = &v115_18_cursor.path()[v115_18_origin..(v115_18_origin + 1)];
      let v117_2_arg_1: &[u8] = &(*p0);
      let v117_2_arg_2: &[u8] = &(*p2);
      let v117_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v117_2_more = v115_18_cursor.is_val() || next_value_within(&mut v115_18_cursor,(v115_18_origin + 1));
      while v117_2_more {
        {
        let v117_2_depth = v115_18_cursor.path().len();
        let mut v118_5_cursor = (*v117_2_arg_4).read_zipper();
        let v118_5_origin = v118_5_cursor.path().len();
        for v118_5_byte in v118_5_cursor.child_mask().iter() {
          v118_5_cursor.descend_to_existing_byte(v118_5_byte);
          {
          let v119_2: Path = concat_path(&(*v117_2_arg_1),&v118_5_cursor.path()[v118_5_origin..(v118_5_origin + 1)]);
          let v119_3: Space = routine_9(c, &(v119_2), &v115_18_cursor.path()[v115_18_origin..v117_2_depth], &(*v117_2_arg_2), &v118_5_cursor);
          drop(v119_2);
          join_wrapped_into(&mut v115_18_write,&((v119_3).read_zipper()),&[]);
          }
          v118_5_cursor.ascend(1);
        }
        drop(v118_5_cursor);
        }
        v117_2_more = next_value_within(&mut v115_18_cursor,(v115_18_origin + 1));
      }
      }
      v115_18_cursor.ascend(1);
    }
    drop(v115_18_cursor);
    drop(v115_18_write);
    let v115_19: Space = unite(&(v115_15),&(v115_18));
    compose(&(v114_9),&(v115_19))
  };
  drop(v114_9);
  let v114_22: Space = intersect(&(*CONSTANT_3),&(v114_6));
  drop(v114_6);
  let v114_23: Space = if has_head(&(v114_22)) { singleton(&[]) } else { Space::new() };
  drop(v114_22);
  let v114_25: Space = if (&(v114_23)).is_empty() { Space::new() } else {
    let mut v120_24 = Space::new();
    let mut v120_24_write = v120_24.write_zipper();
    let mut v120_24_cursor = (*s0).read_zipper();
    let v120_24_origin = v120_24_cursor.path().len();
    for v120_24_byte in v120_24_cursor.child_mask().iter() {
      v120_24_cursor.descend_to_existing_byte(v120_24_byte);
      {
      let v121_2: Space = routine_30(c, &v120_24_cursor.path()[v120_24_origin..(v120_24_origin + 1)], &v120_24_cursor.path()[v120_24_origin..(v120_24_origin + 1)], &(*p0), &(*p2), &v120_24_cursor);
      join_wrapped_into(&mut v120_24_write,&((v121_2).read_zipper()),&[]);
      }
      v120_24_cursor.ascend(1);
    }
    drop(v120_24_cursor);
    drop(v120_24_write);
    compose(&(v114_23),&(v120_24))
  };
  drop(v114_23);
  let v114_26: Space = unite(&(v114_20),&(v114_25));
  (v114_26).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v122_5: Space = singleton(&(*p1));
  let v122_6: Space = intersect(&(*CONSTANT_3),&(v122_5));
  let v122_7: Space = if has_head(&(v122_6)) { singleton(&[]) } else { Space::new() };
  drop(v122_6);
  let v122_8: Space = subtract(&(*CONSTANT_0),&(v122_7));
  drop(v122_7);
  let v122_19: Space = if (&(v122_8)).is_empty() { Space::new() } else {
    let v123_11: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v123_14: Space = if (&(v123_11)).is_empty() { Space::new() } else {
      let v124_13: Space = routine_31(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v123_11),&(v124_13))
    };
    drop(v123_11);
    let mut v123_17 = Space::new();
    let mut v123_17_write = v123_17.write_zipper();
    let mut v123_17_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v123_17_origin = v123_17_cursor.path().len();
    for v123_17_byte in v123_17_cursor.child_mask().iter() {
      v123_17_cursor.descend_to_existing_byte(v123_17_byte);
      {
      let v125_2_arg_0: &[u8] = &v123_17_cursor.path()[v123_17_origin..(v123_17_origin + 1)];
      let v125_2_arg_1: &[u8] = &(*p0);
      let v125_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v125_2_more = v123_17_cursor.is_val() || next_value_within(&mut v123_17_cursor,(v123_17_origin + 1));
      while v125_2_more {
        {
        let v125_2_depth = v123_17_cursor.path().len();
        let mut v126_4_cursor = (*v125_2_arg_3).read_zipper();
        let v126_4_origin = v126_4_cursor.path().len();
        for v126_4_byte in v126_4_cursor.child_mask().iter() {
          v126_4_cursor.descend_to_existing_byte(v126_4_byte);
          {
          let v127_2: Path = concat_path(&(*v125_2_arg_1),&v126_4_cursor.path()[v126_4_origin..(v126_4_origin + 1)]);
          let v127_3: Space = routine_10(c, &(v127_2), &v123_17_cursor.path()[v123_17_origin..v125_2_depth], &v126_4_cursor);
          drop(v127_2);
          join_wrapped_into(&mut v123_17_write,&((v127_3).read_zipper()),&[]);
          }
          v126_4_cursor.ascend(1);
        }
        drop(v126_4_cursor);
        }
        v125_2_more = next_value_within(&mut v123_17_cursor,(v123_17_origin + 1));
      }
      }
      v123_17_cursor.ascend(1);
    }
    drop(v123_17_cursor);
    drop(v123_17_write);
    let v123_18: Space = unite(&(v123_14),&(v123_17));
    compose(&(v122_8),&(v123_18))
  };
  drop(v122_8);
  let v122_21: Space = intersect(&(*CONSTANT_3),&(v122_5));
  drop(v122_5);
  let v122_22: Space = if has_head(&(v122_21)) { singleton(&[]) } else { Space::new() };
  drop(v122_21);
  let v122_24: Space = if (&(v122_22)).is_empty() { Space::new() } else {
    let mut v128_23 = Space::new();
    let mut v128_23_write = v128_23.write_zipper();
    let mut v128_23_cursor = (*s0).read_zipper();
    let v128_23_origin = v128_23_cursor.path().len();
    for v128_23_byte in v128_23_cursor.child_mask().iter() {
      v128_23_cursor.descend_to_existing_byte(v128_23_byte);
      {
      let v129_2: Space = routine_11(c, &v128_23_cursor.path()[v128_23_origin..(v128_23_origin + 1)], &v128_23_cursor.path()[v128_23_origin..(v128_23_origin + 1)], &(*p0), &v128_23_cursor);
      join_wrapped_into(&mut v128_23_write,&((v129_2).read_zipper()),&[]);
      }
      v128_23_cursor.ascend(1);
    }
    drop(v128_23_cursor);
    drop(v128_23_write);
    compose(&(v122_22),&(v128_23))
  };
  drop(v122_22);
  let v122_25: Space = unite(&(v122_19),&(v122_24));
  (v122_25).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v130_6: Space = singleton(&(*p1));
  let v130_7: Space = intersect(&(*CONSTANT_3),&(v130_6));
  let v130_8: Space = if has_head(&(v130_7)) { singleton(&[]) } else { Space::new() };
  drop(v130_7);
  let v130_9: Space = subtract(&(*CONSTANT_0),&(v130_8));
  drop(v130_8);
  let v130_20: Space = if (&(v130_9)).is_empty() { Space::new() } else {
    let v131_12: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v131_15: Space = if (&(v131_12)).is_empty() { Space::new() } else {
      let v132_14: Space = routine_32(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v131_12),&(v132_14))
    };
    drop(v131_12);
    let mut v131_18 = Space::new();
    let mut v131_18_write = v131_18.write_zipper();
    let mut v131_18_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v131_18_origin = v131_18_cursor.path().len();
    for v131_18_byte in v131_18_cursor.child_mask().iter() {
      v131_18_cursor.descend_to_existing_byte(v131_18_byte);
      {
      let v133_2_arg_0: &[u8] = &v131_18_cursor.path()[v131_18_origin..(v131_18_origin + 1)];
      let v133_2_arg_1: &[u8] = &(*p0);
      let v133_2_arg_2: &[u8] = &(*p2);
      let v133_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v133_2_more = v131_18_cursor.is_val() || next_value_within(&mut v131_18_cursor,(v131_18_origin + 1));
      while v133_2_more {
        {
        let v133_2_depth = v131_18_cursor.path().len();
        let mut v134_5_cursor = (*v133_2_arg_4).read_zipper();
        let v134_5_origin = v134_5_cursor.path().len();
        for v134_5_byte in v134_5_cursor.child_mask().iter() {
          v134_5_cursor.descend_to_existing_byte(v134_5_byte);
          {
          let v135_2: Path = concat_path(&(*v133_2_arg_1),&v134_5_cursor.path()[v134_5_origin..(v134_5_origin + 1)]);
          let v135_3: Space = routine_11(c, &(v135_2), &v131_18_cursor.path()[v131_18_origin..v133_2_depth], &(*v133_2_arg_2), &v134_5_cursor);
          drop(v135_2);
          join_wrapped_into(&mut v131_18_write,&((v135_3).read_zipper()),&[]);
          }
          v134_5_cursor.ascend(1);
        }
        drop(v134_5_cursor);
        }
        v133_2_more = next_value_within(&mut v131_18_cursor,(v131_18_origin + 1));
      }
      }
      v131_18_cursor.ascend(1);
    }
    drop(v131_18_cursor);
    drop(v131_18_write);
    let v131_19: Space = unite(&(v131_15),&(v131_18));
    compose(&(v130_9),&(v131_19))
  };
  drop(v130_9);
  let v130_22: Space = intersect(&(*CONSTANT_3),&(v130_6));
  drop(v130_6);
  let v130_23: Space = if has_head(&(v130_22)) { singleton(&[]) } else { Space::new() };
  drop(v130_22);
  let v130_25: Space = if (&(v130_23)).is_empty() { Space::new() } else {
    let mut v136_24 = Space::new();
    let mut v136_24_write = v136_24.write_zipper();
    let mut v136_24_cursor = (*s0).read_zipper();
    let v136_24_origin = v136_24_cursor.path().len();
    for v136_24_byte in v136_24_cursor.child_mask().iter() {
      v136_24_cursor.descend_to_existing_byte(v136_24_byte);
      {
      let v137_2: Space = routine_33(c, &v136_24_cursor.path()[v136_24_origin..(v136_24_origin + 1)], &v136_24_cursor.path()[v136_24_origin..(v136_24_origin + 1)], &(*p2), &(*p0), &v136_24_cursor);
      join_wrapped_into(&mut v136_24_write,&((v137_2).read_zipper()),&[]);
      }
      v136_24_cursor.ascend(1);
    }
    drop(v136_24_cursor);
    drop(v136_24_write);
    compose(&(v130_23),&(v136_24))
  };
  drop(v130_23);
  let v130_26: Space = unite(&(v130_20),&(v130_25));
  (v130_26).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v138_5: Space = singleton(&(*p1));
  let v138_6: Space = intersect(&(*CONSTANT_3),&(v138_5));
  let v138_7: Space = if has_head(&(v138_6)) { singleton(&[]) } else { Space::new() };
  drop(v138_6);
  let v138_8: Space = subtract(&(*CONSTANT_0),&(v138_7));
  drop(v138_7);
  let v138_19: Space = if (&(v138_8)).is_empty() { Space::new() } else {
    let v139_11: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v139_14: Space = if (&(v139_11)).is_empty() { Space::new() } else {
      let v140_13: Space = routine_34(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v139_11),&(v140_13))
    };
    drop(v139_11);
    let mut v139_17 = Space::new();
    let mut v139_17_write = v139_17.write_zipper();
    let mut v139_17_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v139_17_origin = v139_17_cursor.path().len();
    for v139_17_byte in v139_17_cursor.child_mask().iter() {
      v139_17_cursor.descend_to_existing_byte(v139_17_byte);
      {
      let v141_2_arg_0: &[u8] = &v139_17_cursor.path()[v139_17_origin..(v139_17_origin + 1)];
      let v141_2_arg_1: &[u8] = &(*p0);
      let v141_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v141_2_more = v139_17_cursor.is_val() || next_value_within(&mut v139_17_cursor,(v139_17_origin + 1));
      while v141_2_more {
        {
        let v141_2_depth = v139_17_cursor.path().len();
        let mut v142_4_cursor = (*v141_2_arg_3).read_zipper();
        let v142_4_origin = v142_4_cursor.path().len();
        for v142_4_byte in v142_4_cursor.child_mask().iter() {
          v142_4_cursor.descend_to_existing_byte(v142_4_byte);
          {
          let v143_2: Path = concat_path(&(*v141_2_arg_1),&v142_4_cursor.path()[v142_4_origin..(v142_4_origin + 1)]);
          let v143_3: Space = routine_12(c, &(v143_2), &v139_17_cursor.path()[v139_17_origin..v141_2_depth], &v142_4_cursor);
          drop(v143_2);
          join_wrapped_into(&mut v139_17_write,&((v143_3).read_zipper()),&[]);
          }
          v142_4_cursor.ascend(1);
        }
        drop(v142_4_cursor);
        }
        v141_2_more = next_value_within(&mut v139_17_cursor,(v139_17_origin + 1));
      }
      }
      v139_17_cursor.ascend(1);
    }
    drop(v139_17_cursor);
    drop(v139_17_write);
    let v139_18: Space = unite(&(v139_14),&(v139_17));
    compose(&(v138_8),&(v139_18))
  };
  drop(v138_8);
  let v138_21: Space = intersect(&(*CONSTANT_3),&(v138_5));
  drop(v138_5);
  let v138_22: Space = if has_head(&(v138_21)) { singleton(&[]) } else { Space::new() };
  drop(v138_21);
  let v138_24: Space = if (&(v138_22)).is_empty() { Space::new() } else {
    let mut v144_23 = Space::new();
    let mut v144_23_write = v144_23.write_zipper();
    let mut v144_23_cursor = (*s0).read_zipper();
    let v144_23_origin = v144_23_cursor.path().len();
    for v144_23_byte in v144_23_cursor.child_mask().iter() {
      v144_23_cursor.descend_to_existing_byte(v144_23_byte);
      {
      let v145_2: Space = routine_13(c, &v144_23_cursor.path()[v144_23_origin..(v144_23_origin + 1)], &v144_23_cursor.path()[v144_23_origin..(v144_23_origin + 1)], &(*p0), &v144_23_cursor);
      join_wrapped_into(&mut v144_23_write,&((v145_2).read_zipper()),&[]);
      }
      v144_23_cursor.ascend(1);
    }
    drop(v144_23_cursor);
    drop(v144_23_write);
    compose(&(v138_22),&(v144_23))
  };
  drop(v138_22);
  let v138_25: Space = unite(&(v138_19),&(v138_24));
  (v138_25).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v146_6: Space = singleton(&(*p1));
  let v146_7: Space = intersect(&(*CONSTANT_3),&(v146_6));
  let v146_8: Space = if has_head(&(v146_7)) { singleton(&[]) } else { Space::new() };
  drop(v146_7);
  let v146_9: Space = subtract(&(*CONSTANT_0),&(v146_8));
  drop(v146_8);
  let v146_20: Space = if (&(v146_9)).is_empty() { Space::new() } else {
    let v147_12: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v147_15: Space = if (&(v147_12)).is_empty() { Space::new() } else {
      let v148_14: Space = routine_35(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v147_12),&(v148_14))
    };
    drop(v147_12);
    let mut v147_18 = Space::new();
    let mut v147_18_write = v147_18.write_zipper();
    let mut v147_18_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v147_18_origin = v147_18_cursor.path().len();
    for v147_18_byte in v147_18_cursor.child_mask().iter() {
      v147_18_cursor.descend_to_existing_byte(v147_18_byte);
      {
      let v149_2_arg_0: &[u8] = &v147_18_cursor.path()[v147_18_origin..(v147_18_origin + 1)];
      let v149_2_arg_1: &[u8] = &(*p0);
      let v149_2_arg_2: &[u8] = &(*p2);
      let v149_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v149_2_more = v147_18_cursor.is_val() || next_value_within(&mut v147_18_cursor,(v147_18_origin + 1));
      while v149_2_more {
        {
        let v149_2_depth = v147_18_cursor.path().len();
        let mut v150_5_cursor = (*v149_2_arg_4).read_zipper();
        let v150_5_origin = v150_5_cursor.path().len();
        for v150_5_byte in v150_5_cursor.child_mask().iter() {
          v150_5_cursor.descend_to_existing_byte(v150_5_byte);
          {
          let v151_2: Path = concat_path(&(*v149_2_arg_1),&v150_5_cursor.path()[v150_5_origin..(v150_5_origin + 1)]);
          let v151_3: Space = routine_13(c, &(v151_2), &v147_18_cursor.path()[v147_18_origin..v149_2_depth], &(*v149_2_arg_2), &v150_5_cursor);
          drop(v151_2);
          join_wrapped_into(&mut v147_18_write,&((v151_3).read_zipper()),&[]);
          }
          v150_5_cursor.ascend(1);
        }
        drop(v150_5_cursor);
        }
        v149_2_more = next_value_within(&mut v147_18_cursor,(v147_18_origin + 1));
      }
      }
      v147_18_cursor.ascend(1);
    }
    drop(v147_18_cursor);
    drop(v147_18_write);
    let v147_19: Space = unite(&(v147_15),&(v147_18));
    compose(&(v146_9),&(v147_19))
  };
  drop(v146_9);
  let v146_22: Space = intersect(&(*CONSTANT_3),&(v146_6));
  drop(v146_6);
  let v146_23: Space = if has_head(&(v146_22)) { singleton(&[]) } else { Space::new() };
  drop(v146_22);
  let v146_25: Space = if (&(v146_23)).is_empty() { Space::new() } else {
    let mut v152_24 = Space::new();
    let mut v152_24_write = v152_24.write_zipper();
    let mut v152_24_cursor = (*s0).read_zipper();
    let v152_24_origin = v152_24_cursor.path().len();
    for v152_24_byte in v152_24_cursor.child_mask().iter() {
      v152_24_cursor.descend_to_existing_byte(v152_24_byte);
      {
      let v153_2: Space = routine_36(c, &v152_24_cursor.path()[v152_24_origin..(v152_24_origin + 1)], &v152_24_cursor.path()[v152_24_origin..(v152_24_origin + 1)], &(*p2), &(*p0), &v152_24_cursor);
      join_wrapped_into(&mut v152_24_write,&((v153_2).read_zipper()),&[]);
      }
      v152_24_cursor.ascend(1);
    }
    drop(v152_24_cursor);
    drop(v152_24_write);
    compose(&(v146_23),&(v152_24))
  };
  drop(v146_23);
  let v146_26: Space = unite(&(v146_20),&(v146_25));
  (v146_26).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v154_5: Space = singleton(&(*p1));
  let v154_6: Space = intersect(&(*CONSTANT_3),&(v154_5));
  let v154_7: Space = if has_head(&(v154_6)) { singleton(&[]) } else { Space::new() };
  drop(v154_6);
  let v154_8: Space = subtract(&(*CONSTANT_0),&(v154_7));
  drop(v154_7);
  let v154_19: Space = if (&(v154_8)).is_empty() { Space::new() } else {
    let v155_11: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v155_14: Space = if (&(v155_11)).is_empty() { Space::new() } else {
      let v156_13: Space = routine_37(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v155_11),&(v156_13))
    };
    drop(v155_11);
    let mut v155_17 = Space::new();
    let mut v155_17_write = v155_17.write_zipper();
    let mut v155_17_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v155_17_origin = v155_17_cursor.path().len();
    for v155_17_byte in v155_17_cursor.child_mask().iter() {
      v155_17_cursor.descend_to_existing_byte(v155_17_byte);
      {
      let v157_2_arg_0: &[u8] = &v155_17_cursor.path()[v155_17_origin..(v155_17_origin + 1)];
      let v157_2_arg_1: &[u8] = &(*p0);
      let v157_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v157_2_more = v155_17_cursor.is_val() || next_value_within(&mut v155_17_cursor,(v155_17_origin + 1));
      while v157_2_more {
        {
        let v157_2_depth = v155_17_cursor.path().len();
        let mut v158_4_cursor = (*v157_2_arg_3).read_zipper();
        let v158_4_origin = v158_4_cursor.path().len();
        for v158_4_byte in v158_4_cursor.child_mask().iter() {
          v158_4_cursor.descend_to_existing_byte(v158_4_byte);
          {
          let v159_2: Path = concat_path(&(*v157_2_arg_1),&v158_4_cursor.path()[v158_4_origin..(v158_4_origin + 1)]);
          let v159_3: Space = routine_14(c, &(v159_2), &v155_17_cursor.path()[v155_17_origin..v157_2_depth], &v158_4_cursor);
          drop(v159_2);
          join_wrapped_into(&mut v155_17_write,&((v159_3).read_zipper()),&[]);
          }
          v158_4_cursor.ascend(1);
        }
        drop(v158_4_cursor);
        }
        v157_2_more = next_value_within(&mut v155_17_cursor,(v155_17_origin + 1));
      }
      }
      v155_17_cursor.ascend(1);
    }
    drop(v155_17_cursor);
    drop(v155_17_write);
    let v155_18: Space = unite(&(v155_14),&(v155_17));
    compose(&(v154_8),&(v155_18))
  };
  drop(v154_8);
  let v154_21: Space = intersect(&(*CONSTANT_3),&(v154_5));
  drop(v154_5);
  let v154_22: Space = if has_head(&(v154_21)) { singleton(&[]) } else { Space::new() };
  drop(v154_21);
  let v154_24: Space = if (&(v154_22)).is_empty() { Space::new() } else {
    let mut v160_23 = Space::new();
    let mut v160_23_write = v160_23.write_zipper();
    let mut v160_23_cursor = (*s0).read_zipper();
    let v160_23_origin = v160_23_cursor.path().len();
    for v160_23_byte in v160_23_cursor.child_mask().iter() {
      v160_23_cursor.descend_to_existing_byte(v160_23_byte);
      {
      let v161_2: Space = routine_15(c, &v160_23_cursor.path()[v160_23_origin..(v160_23_origin + 1)], &v160_23_cursor.path()[v160_23_origin..(v160_23_origin + 1)], &(*p0), &v160_23_cursor);
      join_wrapped_into(&mut v160_23_write,&((v161_2).read_zipper()),&[]);
      }
      v160_23_cursor.ascend(1);
    }
    drop(v160_23_cursor);
    drop(v160_23_write);
    compose(&(v154_22),&(v160_23))
  };
  drop(v154_22);
  let v154_25: Space = unite(&(v154_19),&(v154_24));
  (v154_25).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v162_6: Space = singleton(&(*p1));
  let v162_7: Space = intersect(&(*CONSTANT_3),&(v162_6));
  let v162_8: Space = if has_head(&(v162_7)) { singleton(&[]) } else { Space::new() };
  drop(v162_7);
  let v162_9: Space = subtract(&(*CONSTANT_0),&(v162_8));
  drop(v162_8);
  let v162_20: Space = if (&(v162_9)).is_empty() { Space::new() } else {
    let v163_12: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v163_15: Space = if (&(v163_12)).is_empty() { Space::new() } else {
      let v164_14: Space = routine_38(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v163_12),&(v164_14))
    };
    drop(v163_12);
    let mut v163_18 = Space::new();
    let mut v163_18_write = v163_18.write_zipper();
    let mut v163_18_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v163_18_origin = v163_18_cursor.path().len();
    for v163_18_byte in v163_18_cursor.child_mask().iter() {
      v163_18_cursor.descend_to_existing_byte(v163_18_byte);
      {
      let v165_2_arg_0: &[u8] = &v163_18_cursor.path()[v163_18_origin..(v163_18_origin + 1)];
      let v165_2_arg_1: &[u8] = &(*p0);
      let v165_2_arg_2: &[u8] = &(*p2);
      let v165_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v165_2_more = v163_18_cursor.is_val() || next_value_within(&mut v163_18_cursor,(v163_18_origin + 1));
      while v165_2_more {
        {
        let v165_2_depth = v163_18_cursor.path().len();
        let mut v166_5_cursor = (*v165_2_arg_4).read_zipper();
        let v166_5_origin = v166_5_cursor.path().len();
        for v166_5_byte in v166_5_cursor.child_mask().iter() {
          v166_5_cursor.descend_to_existing_byte(v166_5_byte);
          {
          let v167_2: Path = concat_path(&(*v165_2_arg_1),&v166_5_cursor.path()[v166_5_origin..(v166_5_origin + 1)]);
          let v167_3: Space = routine_15(c, &(v167_2), &v163_18_cursor.path()[v163_18_origin..v165_2_depth], &(*v165_2_arg_2), &v166_5_cursor);
          drop(v167_2);
          join_wrapped_into(&mut v163_18_write,&((v167_3).read_zipper()),&[]);
          }
          v166_5_cursor.ascend(1);
        }
        drop(v166_5_cursor);
        }
        v165_2_more = next_value_within(&mut v163_18_cursor,(v163_18_origin + 1));
      }
      }
      v163_18_cursor.ascend(1);
    }
    drop(v163_18_cursor);
    drop(v163_18_write);
    let v163_19: Space = unite(&(v163_15),&(v163_18));
    compose(&(v162_9),&(v163_19))
  };
  drop(v162_9);
  let v162_22: Space = intersect(&(*CONSTANT_3),&(v162_6));
  drop(v162_6);
  let v162_23: Space = if has_head(&(v162_22)) { singleton(&[]) } else { Space::new() };
  drop(v162_22);
  let v162_25: Space = if (&(v162_23)).is_empty() { Space::new() } else {
    let mut v168_24 = Space::new();
    let mut v168_24_write = v168_24.write_zipper();
    let mut v168_24_cursor = (*s0).read_zipper();
    let v168_24_origin = v168_24_cursor.path().len();
    for v168_24_byte in v168_24_cursor.child_mask().iter() {
      v168_24_cursor.descend_to_existing_byte(v168_24_byte);
      {
      let v169_2: Space = routine_39(c, &v168_24_cursor.path()[v168_24_origin..(v168_24_origin + 1)], &v168_24_cursor.path()[v168_24_origin..(v168_24_origin + 1)], &(*p2), &(*p0), &v168_24_cursor);
      join_wrapped_into(&mut v168_24_write,&((v169_2).read_zipper()),&[]);
      }
      v168_24_cursor.ascend(1);
    }
    drop(v168_24_cursor);
    drop(v168_24_write);
    compose(&(v162_23),&(v168_24))
  };
  drop(v162_23);
  let v162_26: Space = unite(&(v162_20),&(v162_25));
  (v162_26).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v170_5: Space = singleton(&(*p1));
  let v170_6: Space = intersect(&(*CONSTANT_3),&(v170_5));
  let v170_7: Space = if has_head(&(v170_6)) { singleton(&[]) } else { Space::new() };
  drop(v170_6);
  let v170_8: Space = subtract(&(*CONSTANT_0),&(v170_7));
  drop(v170_7);
  let v170_19: Space = if (&(v170_8)).is_empty() { Space::new() } else {
    let v171_11: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v171_14: Space = if (&(v171_11)).is_empty() { Space::new() } else {
      let v172_13: Space = routine_40(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v171_11),&(v172_13))
    };
    drop(v171_11);
    let mut v171_17 = Space::new();
    let mut v171_17_write = v171_17.write_zipper();
    let mut v171_17_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v171_17_origin = v171_17_cursor.path().len();
    for v171_17_byte in v171_17_cursor.child_mask().iter() {
      v171_17_cursor.descend_to_existing_byte(v171_17_byte);
      {
      let v173_2_arg_0: &[u8] = &v171_17_cursor.path()[v171_17_origin..(v171_17_origin + 1)];
      let v173_2_arg_1: &[u8] = &(*p0);
      let v173_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v173_2_more = v171_17_cursor.is_val() || next_value_within(&mut v171_17_cursor,(v171_17_origin + 1));
      while v173_2_more {
        {
        let v173_2_depth = v171_17_cursor.path().len();
        let mut v174_4_cursor = (*v173_2_arg_3).read_zipper();
        let v174_4_origin = v174_4_cursor.path().len();
        for v174_4_byte in v174_4_cursor.child_mask().iter() {
          v174_4_cursor.descend_to_existing_byte(v174_4_byte);
          {
          let v175_2: Path = concat_path(&(*v173_2_arg_1),&v174_4_cursor.path()[v174_4_origin..(v174_4_origin + 1)]);
          let v175_3: Space = routine_16(c, &(v175_2), &v171_17_cursor.path()[v171_17_origin..v173_2_depth], &v174_4_cursor);
          drop(v175_2);
          join_wrapped_into(&mut v171_17_write,&((v175_3).read_zipper()),&[]);
          }
          v174_4_cursor.ascend(1);
        }
        drop(v174_4_cursor);
        }
        v173_2_more = next_value_within(&mut v171_17_cursor,(v171_17_origin + 1));
      }
      }
      v171_17_cursor.ascend(1);
    }
    drop(v171_17_cursor);
    drop(v171_17_write);
    let v171_18: Space = unite(&(v171_14),&(v171_17));
    compose(&(v170_8),&(v171_18))
  };
  drop(v170_8);
  let v170_21: Space = intersect(&(*CONSTANT_3),&(v170_5));
  drop(v170_5);
  let v170_22: Space = if has_head(&(v170_21)) { singleton(&[]) } else { Space::new() };
  drop(v170_21);
  let v170_24: Space = if (&(v170_22)).is_empty() { Space::new() } else {
    let mut v176_23 = Space::new();
    let mut v176_23_write = v176_23.write_zipper();
    let mut v176_23_cursor = (*s0).read_zipper();
    let v176_23_origin = v176_23_cursor.path().len();
    for v176_23_byte in v176_23_cursor.child_mask().iter() {
      v176_23_cursor.descend_to_existing_byte(v176_23_byte);
      {
      let v177_2: Space = routine_17(c, &v176_23_cursor.path()[v176_23_origin..(v176_23_origin + 1)], &v176_23_cursor.path()[v176_23_origin..(v176_23_origin + 1)], &(*p0), &v176_23_cursor);
      join_wrapped_into(&mut v176_23_write,&((v177_2).read_zipper()),&[]);
      }
      v176_23_cursor.ascend(1);
    }
    drop(v176_23_cursor);
    drop(v176_23_write);
    compose(&(v170_22),&(v176_23))
  };
  drop(v170_22);
  let v170_25: Space = unite(&(v170_19),&(v170_24));
  (v170_25).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v178_6: Space = singleton(&(*p1));
  let v178_7: Space = intersect(&(*CONSTANT_3),&(v178_6));
  let v178_8: Space = if has_head(&(v178_7)) { singleton(&[]) } else { Space::new() };
  drop(v178_7);
  let v178_9: Space = subtract(&(*CONSTANT_0),&(v178_8));
  drop(v178_8);
  let v178_20: Space = if (&(v178_9)).is_empty() { Space::new() } else {
    let v179_12: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v179_15: Space = if (&(v179_12)).is_empty() { Space::new() } else {
      let v180_14: Space = routine_41(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v179_12),&(v180_14))
    };
    drop(v179_12);
    let mut v179_18 = Space::new();
    let mut v179_18_write = v179_18.write_zipper();
    let mut v179_18_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v179_18_origin = v179_18_cursor.path().len();
    for v179_18_byte in v179_18_cursor.child_mask().iter() {
      v179_18_cursor.descend_to_existing_byte(v179_18_byte);
      {
      let v181_2_arg_0: &[u8] = &v179_18_cursor.path()[v179_18_origin..(v179_18_origin + 1)];
      let v181_2_arg_1: &[u8] = &(*p0);
      let v181_2_arg_2: &[u8] = &(*p2);
      let v181_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v181_2_more = v179_18_cursor.is_val() || next_value_within(&mut v179_18_cursor,(v179_18_origin + 1));
      while v181_2_more {
        {
        let v181_2_depth = v179_18_cursor.path().len();
        let mut v182_5_cursor = (*v181_2_arg_4).read_zipper();
        let v182_5_origin = v182_5_cursor.path().len();
        for v182_5_byte in v182_5_cursor.child_mask().iter() {
          v182_5_cursor.descend_to_existing_byte(v182_5_byte);
          {
          let v183_2: Path = concat_path(&(*v181_2_arg_1),&v182_5_cursor.path()[v182_5_origin..(v182_5_origin + 1)]);
          let v183_3: Space = routine_17(c, &(v183_2), &v179_18_cursor.path()[v179_18_origin..v181_2_depth], &(*v181_2_arg_2), &v182_5_cursor);
          drop(v183_2);
          join_wrapped_into(&mut v179_18_write,&((v183_3).read_zipper()),&[]);
          }
          v182_5_cursor.ascend(1);
        }
        drop(v182_5_cursor);
        }
        v181_2_more = next_value_within(&mut v179_18_cursor,(v179_18_origin + 1));
      }
      }
      v179_18_cursor.ascend(1);
    }
    drop(v179_18_cursor);
    drop(v179_18_write);
    let v179_19: Space = unite(&(v179_15),&(v179_18));
    compose(&(v178_9),&(v179_19))
  };
  drop(v178_9);
  let v178_22: Space = intersect(&(*CONSTANT_3),&(v178_6));
  drop(v178_6);
  let v178_23: Space = if has_head(&(v178_22)) { singleton(&[]) } else { Space::new() };
  drop(v178_22);
  let v178_25: Space = if (&(v178_23)).is_empty() { Space::new() } else {
    let mut v184_24 = Space::new();
    let mut v184_24_write = v184_24.write_zipper();
    let mut v184_24_cursor = (*s0).read_zipper();
    let v184_24_origin = v184_24_cursor.path().len();
    for v184_24_byte in v184_24_cursor.child_mask().iter() {
      v184_24_cursor.descend_to_existing_byte(v184_24_byte);
      {
      let v185_2: Space = routine_42(c, &v184_24_cursor.path()[v184_24_origin..(v184_24_origin + 1)], &v184_24_cursor.path()[v184_24_origin..(v184_24_origin + 1)], &(*p2), &(*p0), &v184_24_cursor);
      join_wrapped_into(&mut v184_24_write,&((v185_2).read_zipper()),&[]);
      }
      v184_24_cursor.ascend(1);
    }
    drop(v184_24_cursor);
    drop(v184_24_write);
    compose(&(v178_23),&(v184_24))
  };
  drop(v178_23);
  let v178_26: Space = unite(&(v178_20),&(v178_25));
  (v178_26).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v186_5: Space = singleton(&(*p0));
  let v186_6: Space = intersect(&(*CONSTANT_3),&(v186_5));
  let v186_7: Space = if has_head(&(v186_6)) { singleton(&[]) } else { Space::new() };
  drop(v186_6);
  let v186_8: Space = subtract(&(*CONSTANT_0),&(v186_7));
  drop(v186_7);
  let v186_13: Space = intersect(&(*CONSTANT_3),&(v186_5));
  drop(v186_5);
  let v186_14: Space = if has_head(&(v186_13)) { singleton(&[]) } else { Space::new() };
  drop(v186_13);
  let mut v186_17 = Space::new();
  let mut v186_17_write = v186_17.write_zipper();
  let mut v186_17_cursor = (*s0).read_zipper();
  let v186_17_origin = v186_17_cursor.path().len();
  for v186_17_byte in v186_17_cursor.child_mask().iter() {
    v186_17_cursor.descend_to_existing_byte(v186_17_byte);
    {
    let v187_4: Space = if (&(v186_8)).is_empty() { Space::new() } else {
      let v188_2: Path = concat_path(&(*p1),&v186_17_cursor.path()[v186_17_origin..(v186_17_origin + 1)]);
      let mut v188_3 = Space::new();
      let mut v188_3_write = v188_3.write_zipper();
      let v188_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v188_3_arg_1: &[u8] = &(v188_2);
      let v188_3_arg_3: &Space = &(&v186_17_cursor).make_map();
      let mut v188_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v188_3_origin = v188_3_cursor.path().len();
      let mut v188_3_more = v188_3_cursor.is_val() || next_value_within(&mut v188_3_cursor,v188_3_origin);
      while v188_3_more {
        {
        let v188_3_depth = v188_3_cursor.path().len();
        let v189_4: Space = routine_18(c, &v188_3_cursor.path()[v188_3_origin..v188_3_depth], &(*v188_3_arg_1), &((*v188_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v188_3_write,&((v189_4).read_zipper()),&[]);
        }
        v188_3_more = next_value_within(&mut v188_3_cursor,v188_3_origin);
      }
      drop(v188_3_cursor);
      drop(v188_3_write);
      compose(&(v186_8),&(v188_3))
    };
    let v187_6: Space = if (&(v186_14)).is_empty() { Space::new() } else {
      let v190_2: Path = concat_path(&(*p1),&v186_17_cursor.path()[v186_17_origin..(v186_17_origin + 1)]);
      let v190_5: Space = routine_43(c, &(v190_2), &(*CONSTANT_9), &(*CONSTANT_11));
      compose(&(v186_14),&(v190_5))
    };
    let v187_7: Space = wrap(&(v187_6),&(*CONSTANT_1));
    let v191_2: Path = concat_path(&(*p1),&v186_17_cursor.path()[v186_17_origin..(v186_17_origin + 1)]);
    let v187_8: Space = wrap(&(v187_7),&(v191_2));
    let v187_9: Space = unite(&(v187_4),&(v187_8));
    join_wrapped_into(&mut v186_17_write,&((v187_9).read_zipper()),&[]);
    }
    v186_17_cursor.ascend(1);
  }
  drop(v186_17_cursor);
  drop(v186_17_write);
  drop(v186_8);
  drop(v186_14);
  (v186_17).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v192_7: Space = singleton(&(*p1));
  let v192_8: Space = intersect(&(*CONSTANT_3),&(v192_7));
  let v192_9: Space = if has_head(&(v192_8)) { singleton(&[]) } else { Space::new() };
  drop(v192_8);
  let v192_10: Space = subtract(&(*CONSTANT_0),&(v192_9));
  drop(v192_9);
  let v192_21: Space = if (&(v192_10)).is_empty() { Space::new() } else {
    let v193_13: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v193_16: Space = if (&(v193_13)).is_empty() { Space::new() } else {
      let v194_15: Space = routine_44(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      compose(&(v193_13),&(v194_15))
    };
    drop(v193_13);
    let mut v193_19 = Space::new();
    let mut v193_19_write = v193_19.write_zipper();
    let mut v193_19_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v193_19_origin = v193_19_cursor.path().len();
    for v193_19_byte in v193_19_cursor.child_mask().iter() {
      v193_19_cursor.descend_to_existing_byte(v193_19_byte);
      {
      let v195_2_arg_0: &[u8] = &v193_19_cursor.path()[v193_19_origin..(v193_19_origin + 1)];
      let v195_2_arg_1: &[u8] = &(*p0);
      let v195_2_arg_2: &[u8] = &(*p2);
      let v195_2_arg_3: &[u8] = &(*p3);
      let v195_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v195_2_more = v193_19_cursor.is_val() || next_value_within(&mut v193_19_cursor,(v193_19_origin + 1));
      while v195_2_more {
        {
        let v195_2_depth = v193_19_cursor.path().len();
        let mut v196_6_cursor = (*v195_2_arg_5).read_zipper();
        let v196_6_origin = v196_6_cursor.path().len();
        for v196_6_byte in v196_6_cursor.child_mask().iter() {
          v196_6_cursor.descend_to_existing_byte(v196_6_byte);
          {
          let v197_2: Path = concat_path(&(*v195_2_arg_1),&v196_6_cursor.path()[v196_6_origin..(v196_6_origin + 1)]);
          let v197_3: Space = routine_19(c, &(v197_2), &v193_19_cursor.path()[v193_19_origin..v195_2_depth], &(*v195_2_arg_2), &(*v195_2_arg_3), &v196_6_cursor);
          drop(v197_2);
          join_wrapped_into(&mut v193_19_write,&((v197_3).read_zipper()),&[]);
          }
          v196_6_cursor.ascend(1);
        }
        drop(v196_6_cursor);
        }
        v195_2_more = next_value_within(&mut v193_19_cursor,(v193_19_origin + 1));
      }
      }
      v193_19_cursor.ascend(1);
    }
    drop(v193_19_cursor);
    drop(v193_19_write);
    let v193_20: Space = unite(&(v193_16),&(v193_19));
    compose(&(v192_10),&(v193_20))
  };
  drop(v192_10);
  let v192_23: Space = intersect(&(*CONSTANT_3),&(v192_7));
  drop(v192_7);
  let v192_24: Space = if has_head(&(v192_23)) { singleton(&[]) } else { Space::new() };
  drop(v192_23);
  let v192_38: Space = if (&(v192_24)).is_empty() { Space::new() } else {
    let v198_31: Space = if (&(descend_cursor(descend_cursor((*CONSTANT_12).read_zipper(),&(*p2)),&(*p0)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor(descend_cursor((*CONSTANT_12).read_zipper(),&(*p2)),&(*p0))),&(descend_cursor(descend_cursor((*CONSTANT_12).read_zipper(),&(*p3)),&(*p0))))
    };
    let v198_32: Path = concat_path(&(*p0),&(*p3));
    let v198_33: Space = singleton(&(v198_32));
    drop(v198_32);
    let v198_34: Space = unite(&(v198_31),&(v198_33));
    drop(v198_31);
    drop(v198_33);
    let v198_35: Path = concat_path(&(*p2),&(*p0));
    let v198_36: Space = singleton(&(v198_35));
    drop(v198_35);
    let v198_37: Space = unite(&(v198_34),&(v198_36));
    drop(v198_34);
    drop(v198_36);
    compose(&(v192_24),&(v198_37))
  };
  drop(v192_24);
  let v192_39: Space = unite(&(v192_21),&(v192_38));
  drop(v192_38);
  (v192_39).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v200_5: Space = singleton(&(*p0));
  let v200_6: Space = intersect(&(*CONSTANT_3),&(v200_5));
  let v200_7: Space = if has_head(&(v200_6)) { singleton(&[]) } else { Space::new() };
  drop(v200_6);
  let v200_8: Space = subtract(&(*CONSTANT_0),&(v200_7));
  drop(v200_7);
  let v200_13: Space = intersect(&(*CONSTANT_3),&(v200_5));
  drop(v200_5);
  let v200_14: Space = if has_head(&(v200_13)) { singleton(&[]) } else { Space::new() };
  drop(v200_13);
  let mut v200_17 = Space::new();
  let mut v200_17_write = v200_17.write_zipper();
  let mut v200_17_cursor = (*s0).read_zipper();
  let v200_17_origin = v200_17_cursor.path().len();
  for v200_17_byte in v200_17_cursor.child_mask().iter() {
    v200_17_cursor.descend_to_existing_byte(v200_17_byte);
    {
    let v201_4: Space = if (&(v200_8)).is_empty() { Space::new() } else {
      let v202_2: Path = concat_path(&(*p1),&v200_17_cursor.path()[v200_17_origin..(v200_17_origin + 1)]);
      let mut v202_3 = Space::new();
      let mut v202_3_write = v202_3.write_zipper();
      let v202_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v202_3_arg_1: &[u8] = &(v202_2);
      let v202_3_arg_3: &Space = &(&v200_17_cursor).make_map();
      let mut v202_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v202_3_origin = v202_3_cursor.path().len();
      let mut v202_3_more = v202_3_cursor.is_val() || next_value_within(&mut v202_3_cursor,v202_3_origin);
      while v202_3_more {
        {
        let v202_3_depth = v202_3_cursor.path().len();
        let v203_4: Space = routine_20(c, &v202_3_cursor.path()[v202_3_origin..v202_3_depth], &(*v202_3_arg_1), &((*v202_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v202_3_write,&((v203_4).read_zipper()),&[]);
        }
        v202_3_more = next_value_within(&mut v202_3_cursor,v202_3_origin);
      }
      drop(v202_3_cursor);
      drop(v202_3_write);
      compose(&(v200_8),&(v202_3))
    };
    let v201_8: Space = if (&(v200_14)).is_empty() { Space::new() } else {
      let v204_2: Path = concat_path(&(*p1),&v200_17_cursor.path()[v200_17_origin..(v200_17_origin + 1)]);
      let v204_6: Space = subtract(&(*CONSTANT_6),&(descend_cursor(cursor_at(&v200_17_cursor,(v200_17_origin + 1)),&(*CONSTANT_7))));
      let mut v204_7 = Space::new();
      let mut v204_7_write = v204_7.write_zipper();
      let mut v204_7_cursor = (v204_6).read_zipper();
      let v204_7_origin = v204_7_cursor.path().len();
      for v204_7_byte in v204_7_cursor.child_mask().iter() {
        v204_7_cursor.descend_to_existing_byte(v204_7_byte);
        {
        let v205_2: Space = routine_3(c, &v204_7_cursor.path()[v204_7_origin..(v204_7_origin + 1)], &v204_7_cursor.path()[v204_7_origin..(v204_7_origin + 1)], &(v204_2), &v204_7_cursor, &v200_17_cursor);
        join_wrapped_into(&mut v204_7_write,&((v205_2).read_zipper()),&[]);
        }
        v204_7_cursor.ascend(1);
      }
      drop(v204_7_cursor);
      drop(v204_7_write);
      drop(v204_2);
      drop(v204_6);
      compose(&(v200_14),&(v204_7))
    };
    let v201_9: Space = unite(&(v201_4),&(v201_8));
    join_wrapped_into(&mut v200_17_write,&((v201_9).read_zipper()),&[]);
    }
    v200_17_cursor.ascend(1);
  }
  drop(v200_17_cursor);
  drop(v200_17_write);
  drop(v200_8);
  drop(v200_14);
  (v200_17).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v206_7: Space = singleton(&(*p0));
  let v206_8: Space = intersect(&(*CONSTANT_3),&(v206_7));
  let v206_9: Space = if has_head(&(v206_8)) { singleton(&[]) } else { Space::new() };
  drop(v206_8);
  let v206_10: Space = subtract(&(*CONSTANT_0),&(v206_9));
  drop(v206_9);
  let v206_15: Space = intersect(&(*CONSTANT_3),&(v206_7));
  drop(v206_7);
  let v206_16: Space = if has_head(&(v206_15)) { singleton(&[]) } else { Space::new() };
  drop(v206_15);
  let mut v206_19 = Space::new();
  let mut v206_19_write = v206_19.write_zipper();
  let mut v206_19_cursor = (*s0).read_zipper();
  let v206_19_origin = v206_19_cursor.path().len();
  for v206_19_byte in v206_19_cursor.child_mask().iter() {
    v206_19_cursor.descend_to_existing_byte(v206_19_byte);
    {
    let v207_4: Space = if (&(v206_10)).is_empty() { Space::new() } else {
      let v208_2: Path = concat_path(&(*p1),&v206_19_cursor.path()[v206_19_origin..(v206_19_origin + 1)]);
      let mut v208_3 = Space::new();
      let mut v208_3_write = v208_3.write_zipper();
      let v208_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v208_3_arg_1: &[u8] = &(v208_2);
      let v208_3_arg_2: &[u8] = &(*p2);
      let v208_3_arg_4: &Space = &(&v206_19_cursor).make_map();
      let v208_3_arg_5: &Space = &(&(*s1)).make_map();
      let mut v208_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v208_3_origin = v208_3_cursor.path().len();
      let mut v208_3_more = v208_3_cursor.is_val() || next_value_within(&mut v208_3_cursor,v208_3_origin);
      while v208_3_more {
        {
        let v208_3_depth = v208_3_cursor.path().len();
        let v209_6: Space = routine_21(c, &v208_3_cursor.path()[v208_3_origin..v208_3_depth], &(*v208_3_arg_1), &(*v208_3_arg_2), &((*v208_3_arg_4).read_zipper()), &((*v208_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v208_3_write,&((v209_6).read_zipper()),&[]);
        }
        v208_3_more = next_value_within(&mut v208_3_cursor,v208_3_origin);
      }
      drop(v208_3_cursor);
      drop(v208_3_write);
      compose(&(v206_10),&(v208_3))
    };
    let v207_7: Space = if (&(v206_16)).is_empty() { Space::new() } else {
      let v210_2: Path = concat_path(&(*p1),&v206_19_cursor.path()[v206_19_origin..(v206_19_origin + 1)]);
      let v210_5: Space = routine_43(c, &(v210_2), &(*CONSTANT_7), &(*CONSTANT_11));
      let v210_6: Space = unite(&(*s1),&(v210_5));
      compose(&(v206_16),&(v210_6))
    };
    let v207_8: Space = wrap(&(v207_7),&(*p2));
    let v211_2: Path = concat_path(&(*p1),&v206_19_cursor.path()[v206_19_origin..(v206_19_origin + 1)]);
    let v207_9: Space = wrap(&(v207_8),&(v211_2));
    let v207_10: Space = unite(&(v207_4),&(v207_9));
    join_wrapped_into(&mut v206_19_write,&((v207_10).read_zipper()),&[]);
    }
    v206_19_cursor.ascend(1);
  }
  drop(v206_19_cursor);
  drop(v206_19_write);
  drop(v206_10);
  drop(v206_16);
  (v206_19).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v212_5: Space = singleton(&(*p0));
  let v212_6: Space = intersect(&(*CONSTANT_3),&(v212_5));
  let v212_7: Space = if has_head(&(v212_6)) { singleton(&[]) } else { Space::new() };
  drop(v212_6);
  let v212_8: Space = subtract(&(*CONSTANT_0),&(v212_7));
  drop(v212_7);
  let v212_13: Space = intersect(&(*CONSTANT_3),&(v212_5));
  drop(v212_5);
  let v212_14: Space = if has_head(&(v212_13)) { singleton(&[]) } else { Space::new() };
  drop(v212_13);
  let mut v212_15 = Space::new();
  let mut v212_15_write = v212_15.write_zipper();
  let mut v212_15_cursor = (*s0).read_zipper();
  let v212_15_origin = v212_15_cursor.path().len();
  for v212_15_byte in v212_15_cursor.child_mask().iter() {
    v212_15_cursor.descend_to_existing_byte(v212_15_byte);
    {
    let v213_4: Space = if (&(v212_8)).is_empty() { Space::new() } else {
      let v214_2: Path = concat_path(&(*p1),&v212_15_cursor.path()[v212_15_origin..(v212_15_origin + 1)]);
      let mut v214_3 = Space::new();
      let mut v214_3_write = v214_3.write_zipper();
      let v214_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v214_3_arg_1: &[u8] = &(v214_2);
      let v214_3_arg_3: &Space = &(&v212_15_cursor).make_map();
      let mut v214_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v214_3_origin = v214_3_cursor.path().len();
      let mut v214_3_more = v214_3_cursor.is_val() || next_value_within(&mut v214_3_cursor,v214_3_origin);
      while v214_3_more {
        {
        let v214_3_depth = v214_3_cursor.path().len();
        let v215_4: Space = routine_22(c, &v214_3_cursor.path()[v214_3_origin..v214_3_depth], &(*v214_3_arg_1), &((*v214_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v214_3_write,&((v215_4).read_zipper()),&[]);
        }
        v214_3_more = next_value_within(&mut v214_3_cursor,v214_3_origin);
      }
      drop(v214_3_cursor);
      drop(v214_3_write);
      compose(&(v212_8),&(v214_3))
    };
    let v213_6: Space = if (&(v212_14)).is_empty() { Space::new() } else {
      let v216_2: Path = concat_path(&(*p1),&v212_15_cursor.path()[v212_15_origin..(v212_15_origin + 1)]);
      let mut v216_5 = Space::new();
      let mut v216_5_write = v216_5.write_zipper();
      for v216_5_byte in v212_15_cursor.child_mask().iter() {
        v212_15_cursor.descend_to_existing_byte(v216_5_byte);
        {
        let v217_2: Space = routine_5(c, &v212_15_cursor.path()[(v212_15_origin + 1)..(v212_15_origin + 2)], &v212_15_cursor.path()[(v212_15_origin + 1)..(v212_15_origin + 2)], &(v216_2), &v212_15_cursor);
        join_wrapped_into(&mut v216_5_write,&((v217_2).read_zipper()),&[]);
        }
        v212_15_cursor.ascend(1);
      }
      drop(v216_5_write);
      drop(v216_2);
      compose(&(v212_14),&(v216_5))
    };
    let v213_7: Space = unite(&(v213_4),&(v213_6));
    join_wrapped_into(&mut v212_15_write,&((v213_7).read_zipper()),&[]);
    }
    v212_15_cursor.ascend(1);
  }
  drop(v212_15_cursor);
  drop(v212_15_write);
  drop(v212_8);
  drop(v212_14);
  (v212_15).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v218_6: Space = singleton(&(*p0));
  let v218_7: Space = intersect(&(*CONSTANT_3),&(v218_6));
  let v218_8: Space = if has_head(&(v218_7)) { singleton(&[]) } else { Space::new() };
  drop(v218_7);
  let v218_9: Space = subtract(&(*CONSTANT_0),&(v218_8));
  drop(v218_8);
  let v218_14: Space = intersect(&(*CONSTANT_3),&(v218_6));
  drop(v218_6);
  let v218_15: Space = if has_head(&(v218_14)) { singleton(&[]) } else { Space::new() };
  drop(v218_14);
  let mut v218_18 = Space::new();
  let mut v218_18_write = v218_18.write_zipper();
  let mut v218_18_cursor = (*s0).read_zipper();
  let v218_18_origin = v218_18_cursor.path().len();
  for v218_18_byte in v218_18_cursor.child_mask().iter() {
    v218_18_cursor.descend_to_existing_byte(v218_18_byte);
    {
    let v219_4: Space = if (&(v218_9)).is_empty() { Space::new() } else {
      let v220_2: Path = concat_path(&(*p1),&v218_18_cursor.path()[v218_18_origin..(v218_18_origin + 1)]);
      let mut v220_3 = Space::new();
      let mut v220_3_write = v220_3.write_zipper();
      let v220_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v220_3_arg_1: &[u8] = &(v220_2);
      let v220_3_arg_2: &[u8] = &(*p2);
      let v220_3_arg_4: &Space = &(&v218_18_cursor).make_map();
      let mut v220_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v220_3_origin = v220_3_cursor.path().len();
      let mut v220_3_more = v220_3_cursor.is_val() || next_value_within(&mut v220_3_cursor,v220_3_origin);
      while v220_3_more {
        {
        let v220_3_depth = v220_3_cursor.path().len();
        let v221_5: Space = routine_23(c, &v220_3_cursor.path()[v220_3_origin..v220_3_depth], &(*v220_3_arg_1), &(*v220_3_arg_2), &((*v220_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v220_3_write,&((v221_5).read_zipper()),&[]);
        }
        v220_3_more = next_value_within(&mut v220_3_cursor,v220_3_origin);
      }
      drop(v220_3_cursor);
      drop(v220_3_write);
      compose(&(v218_9),&(v220_3))
    };
    let v219_8: Space = if (&(v218_15)).is_empty() { Space::new() } else {
      let v222_2: Path = concat_path(&(*p1),&v218_18_cursor.path()[v218_18_origin..(v218_18_origin + 1)]);
      let v222_6: Space = subtract(&(*CONSTANT_6),&(descend_cursor(cursor_at(&v218_18_cursor,(v218_18_origin + 1)),&(*CONSTANT_10))));
      let mut v222_7 = Space::new();
      let mut v222_7_write = v222_7.write_zipper();
      let mut v222_7_cursor = (v222_6).read_zipper();
      let v222_7_origin = v222_7_cursor.path().len();
      for v222_7_byte in v222_7_cursor.child_mask().iter() {
        v222_7_cursor.descend_to_existing_byte(v222_7_byte);
        {
        let v223_2: Space = routine_24(c, &v222_7_cursor.path()[v222_7_origin..(v222_7_origin + 1)], &v222_7_cursor.path()[v222_7_origin..(v222_7_origin + 1)], &(*p2), &(v222_2), &v222_7_cursor, &v218_18_cursor);
        join_wrapped_into(&mut v222_7_write,&((v223_2).read_zipper()),&[]);
        }
        v222_7_cursor.ascend(1);
      }
      drop(v222_7_cursor);
      drop(v222_7_write);
      drop(v222_2);
      drop(v222_6);
      compose(&(v218_15),&(v222_7))
    };
    let v219_9: Space = unite(&(v219_4),&(v219_8));
    join_wrapped_into(&mut v218_18_write,&((v219_9).read_zipper()),&[]);
    }
    v218_18_cursor.ascend(1);
  }
  drop(v218_18_cursor);
  drop(v218_18_write);
  drop(v218_9);
  drop(v218_15);
  (v218_18).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v224_8: Space = singleton(&(*p1));
  let v224_9: Space = intersect(&(*CONSTANT_3),&(v224_8));
  let v224_10: Space = if has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
  drop(v224_9);
  let v224_11: Space = subtract(&(*CONSTANT_0),&(v224_10));
  drop(v224_10);
  let v224_22: Space = if (&(v224_11)).is_empty() { Space::new() } else {
    let v225_14: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v225_17: Space = if (&(v225_14)).is_empty() { Space::new() } else {
      let v226_16: Space = routine_45(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0), &(*s1));
      compose(&(v225_14),&(v226_16))
    };
    drop(v225_14);
    let mut v225_20 = Space::new();
    let mut v225_20_write = v225_20.write_zipper();
    let mut v225_20_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v225_20_origin = v225_20_cursor.path().len();
    for v225_20_byte in v225_20_cursor.child_mask().iter() {
      v225_20_cursor.descend_to_existing_byte(v225_20_byte);
      {
      let v227_2_arg_0: &[u8] = &v225_20_cursor.path()[v225_20_origin..(v225_20_origin + 1)];
      let v227_2_arg_1: &[u8] = &(*p0);
      let v227_2_arg_2: &[u8] = &(*p2);
      let v227_2_arg_3: &[u8] = &(*p3);
      let v227_2_arg_5: &Space = &(&(*s0)).make_map();
      let v227_2_arg_6: &Space = &(&(*s1)).make_map();
      let mut v227_2_more = v225_20_cursor.is_val() || next_value_within(&mut v225_20_cursor,(v225_20_origin + 1));
      while v227_2_more {
        {
        let v227_2_depth = v225_20_cursor.path().len();
        let mut v228_7_cursor = (*v227_2_arg_5).read_zipper();
        let v228_7_origin = v228_7_cursor.path().len();
        for v228_7_byte in v228_7_cursor.child_mask().iter() {
          v228_7_cursor.descend_to_existing_byte(v228_7_byte);
          {
          let v229_2: Path = concat_path(&(*v227_2_arg_1),&v228_7_cursor.path()[v228_7_origin..(v228_7_origin + 1)]);
          let v229_3: Space = routine_24(c, &(v229_2), &v225_20_cursor.path()[v225_20_origin..v227_2_depth], &(*v227_2_arg_2), &(*v227_2_arg_3), &v228_7_cursor, &((*v227_2_arg_6).read_zipper()));
          drop(v229_2);
          join_wrapped_into(&mut v225_20_write,&((v229_3).read_zipper()),&[]);
          }
          v228_7_cursor.ascend(1);
        }
        drop(v228_7_cursor);
        }
        v227_2_more = next_value_within(&mut v225_20_cursor,(v225_20_origin + 1));
      }
      }
      v225_20_cursor.ascend(1);
    }
    drop(v225_20_cursor);
    drop(v225_20_write);
    let v225_21: Space = unite(&(v225_17),&(v225_20));
    compose(&(v224_11),&(v225_21))
  };
  drop(v224_11);
  let v224_24: Space = intersect(&(*CONSTANT_3),&(v224_8));
  drop(v224_8);
  let v224_25: Space = if has_head(&(v224_24)) { singleton(&[]) } else { Space::new() };
  drop(v224_24);
  let v224_33: Space = if (&(v224_25)).is_empty() { Space::new() } else {
    let v230_30: Space = routine_19(c, &(*CONSTANT_2), &(*CONSTANT_2), &(*CONSTANT_10), &(*p0), &((*CONSTANT_4).read_zipper()));
    let v230_31: Space = intersect(&(*CONSTANT_8),&(v230_30));
    let v230_32: Space = unite(&(v230_31),&(*s1));
    compose(&(v224_25),&(v230_32))
  };
  drop(v224_25);
  let v224_34: Path = concat_path(&(*p2),&(*p3));
  let v224_35: Space = wrap(&(v224_33),&(v224_34));
  drop(v224_34);
  let v224_36: Space = wrap(&(v224_35),&(*p0));
  let v224_37: Space = unite(&(v224_22),&(v224_36));
  (v224_37).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v231_5: Space = singleton(&(*p0));
  let v231_6: Space = intersect(&(*CONSTANT_3),&(v231_5));
  let v231_7: Space = if has_head(&(v231_6)) { singleton(&[]) } else { Space::new() };
  drop(v231_6);
  let v231_8: Space = subtract(&(*CONSTANT_0),&(v231_7));
  drop(v231_7);
  let v231_13: Space = intersect(&(*CONSTANT_3),&(v231_5));
  drop(v231_5);
  let v231_14: Space = if has_head(&(v231_13)) { singleton(&[]) } else { Space::new() };
  drop(v231_13);
  let mut v231_15 = Space::new();
  let mut v231_15_write = v231_15.write_zipper();
  let mut v231_15_cursor = (*s0).read_zipper();
  let v231_15_origin = v231_15_cursor.path().len();
  for v231_15_byte in v231_15_cursor.child_mask().iter() {
    v231_15_cursor.descend_to_existing_byte(v231_15_byte);
    {
    let v232_4: Space = if (&(v231_8)).is_empty() { Space::new() } else {
      let v233_2: Path = concat_path(&(*p1),&v231_15_cursor.path()[v231_15_origin..(v231_15_origin + 1)]);
      let mut v233_3 = Space::new();
      let mut v233_3_write = v233_3.write_zipper();
      let v233_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v233_3_arg_1: &[u8] = &(v233_2);
      let v233_3_arg_3: &Space = &(&v231_15_cursor).make_map();
      let mut v233_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v233_3_origin = v233_3_cursor.path().len();
      let mut v233_3_more = v233_3_cursor.is_val() || next_value_within(&mut v233_3_cursor,v233_3_origin);
      while v233_3_more {
        {
        let v233_3_depth = v233_3_cursor.path().len();
        let v234_4: Space = routine_25(c, &v233_3_cursor.path()[v233_3_origin..v233_3_depth], &(*v233_3_arg_1), &((*v233_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v233_3_write,&((v234_4).read_zipper()),&[]);
        }
        v233_3_more = next_value_within(&mut v233_3_cursor,v233_3_origin);
      }
      drop(v233_3_cursor);
      drop(v233_3_write);
      compose(&(v231_8),&(v233_3))
    };
    let v232_6: Space = if (&(v231_14)).is_empty() { Space::new() } else {
      let v235_2: Path = concat_path(&(*p1),&v231_15_cursor.path()[v231_15_origin..(v231_15_origin + 1)]);
      let mut v235_5 = Space::new();
      let mut v235_5_write = v235_5.write_zipper();
      for v235_5_byte in v231_15_cursor.child_mask().iter() {
        v231_15_cursor.descend_to_existing_byte(v235_5_byte);
        {
        let v236_2: Space = routine_7(c, &v231_15_cursor.path()[(v231_15_origin + 1)..(v231_15_origin + 2)], &v231_15_cursor.path()[(v231_15_origin + 1)..(v231_15_origin + 2)], &(v235_2), &v231_15_cursor);
        join_wrapped_into(&mut v235_5_write,&((v236_2).read_zipper()),&[]);
        }
        v231_15_cursor.ascend(1);
      }
      drop(v235_5_write);
      drop(v235_2);
      compose(&(v231_14),&(v235_5))
    };
    let v232_7: Space = unite(&(v232_4),&(v232_6));
    join_wrapped_into(&mut v231_15_write,&((v232_7).read_zipper()),&[]);
    }
    v231_15_cursor.ascend(1);
  }
  drop(v231_15_cursor);
  drop(v231_15_write);
  drop(v231_8);
  drop(v231_14);
  (v231_15).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v237_6: Space = singleton(&(*p0));
  let v237_7: Space = intersect(&(*CONSTANT_3),&(v237_6));
  let v237_8: Space = if has_head(&(v237_7)) { singleton(&[]) } else { Space::new() };
  drop(v237_7);
  let v237_9: Space = subtract(&(*CONSTANT_0),&(v237_8));
  drop(v237_8);
  let v237_14: Space = intersect(&(*CONSTANT_3),&(v237_6));
  drop(v237_6);
  let v237_15: Space = if has_head(&(v237_14)) { singleton(&[]) } else { Space::new() };
  drop(v237_14);
  let mut v237_16 = Space::new();
  let mut v237_16_write = v237_16.write_zipper();
  let mut v237_16_cursor = (*s0).read_zipper();
  let v237_16_origin = v237_16_cursor.path().len();
  for v237_16_byte in v237_16_cursor.child_mask().iter() {
    v237_16_cursor.descend_to_existing_byte(v237_16_byte);
    {
    let v238_4: Space = if (&(v237_9)).is_empty() { Space::new() } else {
      let v239_2: Path = concat_path(&(*p1),&v237_16_cursor.path()[v237_16_origin..(v237_16_origin + 1)]);
      let mut v239_3 = Space::new();
      let mut v239_3_write = v239_3.write_zipper();
      let v239_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v239_3_arg_1: &[u8] = &(v239_2);
      let v239_3_arg_2: &[u8] = &(*p2);
      let v239_3_arg_4: &Space = &(&v237_16_cursor).make_map();
      let mut v239_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v239_3_origin = v239_3_cursor.path().len();
      let mut v239_3_more = v239_3_cursor.is_val() || next_value_within(&mut v239_3_cursor,v239_3_origin);
      while v239_3_more {
        {
        let v239_3_depth = v239_3_cursor.path().len();
        let v240_5: Space = routine_26(c, &v239_3_cursor.path()[v239_3_origin..v239_3_depth], &(*v239_3_arg_1), &(*v239_3_arg_2), &((*v239_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v239_3_write,&((v240_5).read_zipper()),&[]);
        }
        v239_3_more = next_value_within(&mut v239_3_cursor,v239_3_origin);
      }
      drop(v239_3_cursor);
      drop(v239_3_write);
      compose(&(v237_9),&(v239_3))
    };
    let v238_6: Space = if (&(v237_15)).is_empty() { Space::new() } else {
      let v241_2: Path = concat_path(&(*p1),&v237_16_cursor.path()[v237_16_origin..(v237_16_origin + 1)]);
      let mut v241_5 = Space::new();
      let mut v241_5_write = v241_5.write_zipper();
      for v241_5_byte in v237_16_cursor.child_mask().iter() {
        v237_16_cursor.descend_to_existing_byte(v241_5_byte);
        {
        let v242_2: Space = routine_27(c, &v237_16_cursor.path()[(v237_16_origin + 1)..(v237_16_origin + 2)], &v237_16_cursor.path()[(v237_16_origin + 1)..(v237_16_origin + 2)], &(v241_2), &(*p2), &v237_16_cursor);
        join_wrapped_into(&mut v241_5_write,&((v242_2).read_zipper()),&[]);
        }
        v237_16_cursor.ascend(1);
      }
      drop(v241_5_write);
      drop(v241_2);
      compose(&(v237_15),&(v241_5))
    };
    let v238_7: Space = unite(&(v238_4),&(v238_6));
    join_wrapped_into(&mut v237_16_write,&((v238_7).read_zipper()),&[]);
    }
    v237_16_cursor.ascend(1);
  }
  drop(v237_16_cursor);
  drop(v237_16_write);
  drop(v237_9);
  drop(v237_15);
  (v237_16).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v243_7: Space = singleton(&(*p1));
  let v243_8: Space = intersect(&(*CONSTANT_3),&(v243_7));
  let v243_9: Space = if has_head(&(v243_8)) { singleton(&[]) } else { Space::new() };
  drop(v243_8);
  let v243_10: Space = subtract(&(*CONSTANT_0),&(v243_9));
  drop(v243_9);
  let v243_21: Space = if (&(v243_10)).is_empty() { Space::new() } else {
    let v244_13: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v244_16: Space = if (&(v244_13)).is_empty() { Space::new() } else {
      let v245_15: Space = routine_46(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      compose(&(v244_13),&(v245_15))
    };
    drop(v244_13);
    let mut v244_19 = Space::new();
    let mut v244_19_write = v244_19.write_zipper();
    let mut v244_19_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v244_19_origin = v244_19_cursor.path().len();
    for v244_19_byte in v244_19_cursor.child_mask().iter() {
      v244_19_cursor.descend_to_existing_byte(v244_19_byte);
      {
      let v246_2_arg_0: &[u8] = &v244_19_cursor.path()[v244_19_origin..(v244_19_origin + 1)];
      let v246_2_arg_1: &[u8] = &(*p0);
      let v246_2_arg_2: &[u8] = &(*p2);
      let v246_2_arg_3: &[u8] = &(*p3);
      let v246_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v246_2_more = v244_19_cursor.is_val() || next_value_within(&mut v244_19_cursor,(v244_19_origin + 1));
      while v246_2_more {
        {
        let v246_2_depth = v244_19_cursor.path().len();
        let mut v247_6_cursor = (*v246_2_arg_5).read_zipper();
        let v247_6_origin = v247_6_cursor.path().len();
        for v247_6_byte in v247_6_cursor.child_mask().iter() {
          v247_6_cursor.descend_to_existing_byte(v247_6_byte);
          {
          let v248_2: Path = concat_path(&(*v246_2_arg_1),&v247_6_cursor.path()[v247_6_origin..(v247_6_origin + 1)]);
          let v248_3: Space = routine_27(c, &(v248_2), &v244_19_cursor.path()[v244_19_origin..v246_2_depth], &(*v246_2_arg_2), &(*v246_2_arg_3), &v247_6_cursor);
          drop(v248_2);
          join_wrapped_into(&mut v244_19_write,&((v248_3).read_zipper()),&[]);
          }
          v247_6_cursor.ascend(1);
        }
        drop(v247_6_cursor);
        }
        v246_2_more = next_value_within(&mut v244_19_cursor,(v244_19_origin + 1));
      }
      }
      v244_19_cursor.ascend(1);
    }
    drop(v244_19_cursor);
    drop(v244_19_write);
    let v244_20: Space = unite(&(v244_16),&(v244_19));
    compose(&(v243_10),&(v244_20))
  };
  drop(v243_10);
  let v243_23: Space = intersect(&(*CONSTANT_3),&(v243_7));
  drop(v243_7);
  let v243_24: Space = if has_head(&(v243_23)) { singleton(&[]) } else { Space::new() };
  drop(v243_23);
  let v243_30: Space = if (&(v243_24)).is_empty() { Space::new() } else {
    let v249_28: Space = subtract(&(*CONSTANT_6),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_13))));
    let mut v249_29 = Space::new();
    let mut v249_29_write = v249_29.write_zipper();
    let mut v249_29_cursor = (v249_28).read_zipper();
    let v249_29_origin = v249_29_cursor.path().len();
    for v249_29_byte in v249_29_cursor.child_mask().iter() {
      v249_29_cursor.descend_to_existing_byte(v249_29_byte);
      {
      let v250_2: Space = routine_47(c, &v249_29_cursor.path()[v249_29_origin..(v249_29_origin + 1)], &v249_29_cursor.path()[v249_29_origin..(v249_29_origin + 1)], &(*p2), &(*p0), &(*p3), &v249_29_cursor, &(*s0));
      join_wrapped_into(&mut v249_29_write,&((v250_2).read_zipper()),&[]);
      }
      v249_29_cursor.ascend(1);
    }
    drop(v249_29_cursor);
    drop(v249_29_write);
    drop(v249_28);
    compose(&(v243_24),&(v249_29))
  };
  drop(v243_24);
  let v243_31: Space = unite(&(v243_21),&(v243_30));
  (v243_31).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v251_5: Space = singleton(&(*p0));
  let v251_6: Space = intersect(&(*CONSTANT_3),&(v251_5));
  let v251_7: Space = if has_head(&(v251_6)) { singleton(&[]) } else { Space::new() };
  drop(v251_6);
  let v251_8: Space = subtract(&(*CONSTANT_0),&(v251_7));
  drop(v251_7);
  let v251_13: Space = intersect(&(*CONSTANT_3),&(v251_5));
  drop(v251_5);
  let v251_14: Space = if has_head(&(v251_13)) { singleton(&[]) } else { Space::new() };
  drop(v251_13);
  let mut v251_15 = Space::new();
  let mut v251_15_write = v251_15.write_zipper();
  let mut v251_15_cursor = (*s0).read_zipper();
  let v251_15_origin = v251_15_cursor.path().len();
  for v251_15_byte in v251_15_cursor.child_mask().iter() {
    v251_15_cursor.descend_to_existing_byte(v251_15_byte);
    {
    let v252_4: Space = if (&(v251_8)).is_empty() { Space::new() } else {
      let v253_2: Path = concat_path(&(*p1),&v251_15_cursor.path()[v251_15_origin..(v251_15_origin + 1)]);
      let mut v253_3 = Space::new();
      let mut v253_3_write = v253_3.write_zipper();
      let v253_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v253_3_arg_1: &[u8] = &(v253_2);
      let v253_3_arg_3: &Space = &(&v251_15_cursor).make_map();
      let mut v253_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v253_3_origin = v253_3_cursor.path().len();
      let mut v253_3_more = v253_3_cursor.is_val() || next_value_within(&mut v253_3_cursor,v253_3_origin);
      while v253_3_more {
        {
        let v253_3_depth = v253_3_cursor.path().len();
        let v254_4: Space = routine_28(c, &v253_3_cursor.path()[v253_3_origin..v253_3_depth], &(*v253_3_arg_1), &((*v253_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v253_3_write,&((v254_4).read_zipper()),&[]);
        }
        v253_3_more = next_value_within(&mut v253_3_cursor,v253_3_origin);
      }
      drop(v253_3_cursor);
      drop(v253_3_write);
      compose(&(v251_8),&(v253_3))
    };
    let v252_6: Space = if (&(v251_14)).is_empty() { Space::new() } else {
      let v255_2: Path = concat_path(&(*p1),&v251_15_cursor.path()[v251_15_origin..(v251_15_origin + 1)]);
      let mut v255_5 = Space::new();
      let mut v255_5_write = v255_5.write_zipper();
      for v255_5_byte in v251_15_cursor.child_mask().iter() {
        v251_15_cursor.descend_to_existing_byte(v255_5_byte);
        {
        let v256_2: Space = routine_9(c, &v251_15_cursor.path()[(v251_15_origin + 1)..(v251_15_origin + 2)], &v251_15_cursor.path()[(v251_15_origin + 1)..(v251_15_origin + 2)], &(v255_2), &v251_15_cursor);
        join_wrapped_into(&mut v255_5_write,&((v256_2).read_zipper()),&[]);
        }
        v251_15_cursor.ascend(1);
      }
      drop(v255_5_write);
      drop(v255_2);
      compose(&(v251_14),&(v255_5))
    };
    let v252_7: Space = unite(&(v252_4),&(v252_6));
    join_wrapped_into(&mut v251_15_write,&((v252_7).read_zipper()),&[]);
    }
    v251_15_cursor.ascend(1);
  }
  drop(v251_15_cursor);
  drop(v251_15_write);
  drop(v251_8);
  drop(v251_14);
  (v251_15).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v257_6: Space = singleton(&(*p0));
  let v257_7: Space = intersect(&(*CONSTANT_3),&(v257_6));
  let v257_8: Space = if has_head(&(v257_7)) { singleton(&[]) } else { Space::new() };
  drop(v257_7);
  let v257_9: Space = subtract(&(*CONSTANT_0),&(v257_8));
  drop(v257_8);
  let v257_14: Space = intersect(&(*CONSTANT_3),&(v257_6));
  drop(v257_6);
  let v257_15: Space = if has_head(&(v257_14)) { singleton(&[]) } else { Space::new() };
  drop(v257_14);
  let mut v257_16 = Space::new();
  let mut v257_16_write = v257_16.write_zipper();
  let mut v257_16_cursor = (*s0).read_zipper();
  let v257_16_origin = v257_16_cursor.path().len();
  for v257_16_byte in v257_16_cursor.child_mask().iter() {
    v257_16_cursor.descend_to_existing_byte(v257_16_byte);
    {
    let v258_4: Space = if (&(v257_9)).is_empty() { Space::new() } else {
      let v259_2: Path = concat_path(&(*p1),&v257_16_cursor.path()[v257_16_origin..(v257_16_origin + 1)]);
      let mut v259_3 = Space::new();
      let mut v259_3_write = v259_3.write_zipper();
      let v259_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v259_3_arg_1: &[u8] = &(v259_2);
      let v259_3_arg_2: &[u8] = &(*p2);
      let v259_3_arg_4: &Space = &(&v257_16_cursor).make_map();
      let mut v259_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v259_3_origin = v259_3_cursor.path().len();
      let mut v259_3_more = v259_3_cursor.is_val() || next_value_within(&mut v259_3_cursor,v259_3_origin);
      while v259_3_more {
        {
        let v259_3_depth = v259_3_cursor.path().len();
        let v260_5: Space = routine_29(c, &v259_3_cursor.path()[v259_3_origin..v259_3_depth], &(*v259_3_arg_1), &(*v259_3_arg_2), &((*v259_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v259_3_write,&((v260_5).read_zipper()),&[]);
        }
        v259_3_more = next_value_within(&mut v259_3_cursor,v259_3_origin);
      }
      drop(v259_3_cursor);
      drop(v259_3_write);
      compose(&(v257_9),&(v259_3))
    };
    let v258_6: Space = if (&(v257_15)).is_empty() { Space::new() } else {
      let v261_2: Path = concat_path(&(*p1),&v257_16_cursor.path()[v257_16_origin..(v257_16_origin + 1)]);
      let mut v261_5 = Space::new();
      let mut v261_5_write = v261_5.write_zipper();
      for v261_5_byte in v257_16_cursor.child_mask().iter() {
        v257_16_cursor.descend_to_existing_byte(v261_5_byte);
        {
        let v262_2: Space = routine_30(c, &v257_16_cursor.path()[(v257_16_origin + 1)..(v257_16_origin + 2)], &v257_16_cursor.path()[(v257_16_origin + 1)..(v257_16_origin + 2)], &(v261_2), &(*p2), &v257_16_cursor);
        join_wrapped_into(&mut v261_5_write,&((v262_2).read_zipper()),&[]);
        }
        v257_16_cursor.ascend(1);
      }
      drop(v261_5_write);
      drop(v261_2);
      compose(&(v257_15),&(v261_5))
    };
    let v258_7: Space = unite(&(v258_4),&(v258_6));
    join_wrapped_into(&mut v257_16_write,&((v258_7).read_zipper()),&[]);
    }
    v257_16_cursor.ascend(1);
  }
  drop(v257_16_cursor);
  drop(v257_16_write);
  drop(v257_9);
  drop(v257_15);
  (v257_16).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v263_7: Space = singleton(&(*p1));
  let v263_8: Space = intersect(&(*CONSTANT_3),&(v263_7));
  let v263_9: Space = if has_head(&(v263_8)) { singleton(&[]) } else { Space::new() };
  drop(v263_8);
  let v263_10: Space = subtract(&(*CONSTANT_0),&(v263_9));
  drop(v263_9);
  let v263_21: Space = if (&(v263_10)).is_empty() { Space::new() } else {
    let v264_13: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v264_16: Space = if (&(v264_13)).is_empty() { Space::new() } else {
      let v265_15: Space = routine_48(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      compose(&(v264_13),&(v265_15))
    };
    drop(v264_13);
    let mut v264_19 = Space::new();
    let mut v264_19_write = v264_19.write_zipper();
    let mut v264_19_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v264_19_origin = v264_19_cursor.path().len();
    for v264_19_byte in v264_19_cursor.child_mask().iter() {
      v264_19_cursor.descend_to_existing_byte(v264_19_byte);
      {
      let v266_2_arg_0: &[u8] = &v264_19_cursor.path()[v264_19_origin..(v264_19_origin + 1)];
      let v266_2_arg_1: &[u8] = &(*p0);
      let v266_2_arg_2: &[u8] = &(*p2);
      let v266_2_arg_3: &[u8] = &(*p3);
      let v266_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v266_2_more = v264_19_cursor.is_val() || next_value_within(&mut v264_19_cursor,(v264_19_origin + 1));
      while v266_2_more {
        {
        let v266_2_depth = v264_19_cursor.path().len();
        let mut v267_6_cursor = (*v266_2_arg_5).read_zipper();
        let v267_6_origin = v267_6_cursor.path().len();
        for v267_6_byte in v267_6_cursor.child_mask().iter() {
          v267_6_cursor.descend_to_existing_byte(v267_6_byte);
          {
          let v268_2: Path = concat_path(&(*v266_2_arg_1),&v267_6_cursor.path()[v267_6_origin..(v267_6_origin + 1)]);
          let v268_3: Space = routine_30(c, &(v268_2), &v264_19_cursor.path()[v264_19_origin..v266_2_depth], &(*v266_2_arg_2), &(*v266_2_arg_3), &v267_6_cursor);
          drop(v268_2);
          join_wrapped_into(&mut v264_19_write,&((v268_3).read_zipper()),&[]);
          }
          v267_6_cursor.ascend(1);
        }
        drop(v267_6_cursor);
        }
        v266_2_more = next_value_within(&mut v264_19_cursor,(v264_19_origin + 1));
      }
      }
      v264_19_cursor.ascend(1);
    }
    drop(v264_19_cursor);
    drop(v264_19_write);
    let v264_20: Space = unite(&(v264_16),&(v264_19));
    compose(&(v263_10),&(v264_20))
  };
  drop(v263_10);
  let v263_23: Space = intersect(&(*CONSTANT_3),&(v263_7));
  drop(v263_7);
  let v263_24: Space = if has_head(&(v263_23)) { singleton(&[]) } else { Space::new() };
  drop(v263_23);
  let v263_26: Space = if (&(v263_24)).is_empty() { Space::new() } else {
    let mut v269_25 = Space::new();
    let mut v269_25_write = v269_25.write_zipper();
    let mut v269_25_cursor = (*s0).read_zipper();
    let v269_25_origin = v269_25_cursor.path().len();
    for v269_25_byte in v269_25_cursor.child_mask().iter() {
      v269_25_cursor.descend_to_existing_byte(v269_25_byte);
      {
      let v270_2: Space = routine_49(c, &v269_25_cursor.path()[v269_25_origin..(v269_25_origin + 1)], &v269_25_cursor.path()[v269_25_origin..(v269_25_origin + 1)], &(*p2), &(*p0), &(*p3), &v269_25_cursor);
      join_wrapped_into(&mut v269_25_write,&((v270_2).read_zipper()),&[]);
      }
      v269_25_cursor.ascend(1);
    }
    drop(v269_25_cursor);
    drop(v269_25_write);
    compose(&(v263_24),&(v269_25))
  };
  drop(v263_24);
  let v263_27: Space = unite(&(v263_21),&(v263_26));
  (v263_27).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v271_5: Space = singleton(&(*p0));
  let v271_6: Space = intersect(&(*CONSTANT_3),&(v271_5));
  let v271_7: Space = if has_head(&(v271_6)) { singleton(&[]) } else { Space::new() };
  drop(v271_6);
  let v271_8: Space = subtract(&(*CONSTANT_0),&(v271_7));
  drop(v271_7);
  let v271_13: Space = intersect(&(*CONSTANT_3),&(v271_5));
  drop(v271_5);
  let v271_14: Space = if has_head(&(v271_13)) { singleton(&[]) } else { Space::new() };
  drop(v271_13);
  let mut v271_15 = Space::new();
  let mut v271_15_write = v271_15.write_zipper();
  let mut v271_15_cursor = (*s0).read_zipper();
  let v271_15_origin = v271_15_cursor.path().len();
  for v271_15_byte in v271_15_cursor.child_mask().iter() {
    v271_15_cursor.descend_to_existing_byte(v271_15_byte);
    {
    let v272_4: Space = if (&(v271_8)).is_empty() { Space::new() } else {
      let v273_2: Path = concat_path(&(*p1),&v271_15_cursor.path()[v271_15_origin..(v271_15_origin + 1)]);
      let mut v273_3 = Space::new();
      let mut v273_3_write = v273_3.write_zipper();
      let v273_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v273_3_arg_1: &[u8] = &(v273_2);
      let v273_3_arg_3: &Space = &(&v271_15_cursor).make_map();
      let mut v273_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v273_3_origin = v273_3_cursor.path().len();
      let mut v273_3_more = v273_3_cursor.is_val() || next_value_within(&mut v273_3_cursor,v273_3_origin);
      while v273_3_more {
        {
        let v273_3_depth = v273_3_cursor.path().len();
        let v274_4: Space = routine_31(c, &v273_3_cursor.path()[v273_3_origin..v273_3_depth], &(*v273_3_arg_1), &((*v273_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v273_3_write,&((v274_4).read_zipper()),&[]);
        }
        v273_3_more = next_value_within(&mut v273_3_cursor,v273_3_origin);
      }
      drop(v273_3_cursor);
      drop(v273_3_write);
      compose(&(v271_8),&(v273_3))
    };
    let v272_6: Space = if (&(v271_14)).is_empty() { Space::new() } else {
      let v275_2: Path = concat_path(&(*p1),&v271_15_cursor.path()[v271_15_origin..(v271_15_origin + 1)]);
      let mut v275_5 = Space::new();
      let mut v275_5_write = v275_5.write_zipper();
      for v275_5_byte in v271_15_cursor.child_mask().iter() {
        v271_15_cursor.descend_to_existing_byte(v275_5_byte);
        {
        let v276_2: Space = routine_11(c, &v271_15_cursor.path()[(v271_15_origin + 1)..(v271_15_origin + 2)], &v271_15_cursor.path()[(v271_15_origin + 1)..(v271_15_origin + 2)], &(v275_2), &v271_15_cursor);
        join_wrapped_into(&mut v275_5_write,&((v276_2).read_zipper()),&[]);
        }
        v271_15_cursor.ascend(1);
      }
      drop(v275_5_write);
      drop(v275_2);
      compose(&(v271_14),&(v275_5))
    };
    let v272_7: Space = unite(&(v272_4),&(v272_6));
    join_wrapped_into(&mut v271_15_write,&((v272_7).read_zipper()),&[]);
    }
    v271_15_cursor.ascend(1);
  }
  drop(v271_15_cursor);
  drop(v271_15_write);
  drop(v271_8);
  drop(v271_14);
  (v271_15).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v277_6: Space = singleton(&(*p0));
  let v277_7: Space = intersect(&(*CONSTANT_3),&(v277_6));
  let v277_8: Space = if has_head(&(v277_7)) { singleton(&[]) } else { Space::new() };
  drop(v277_7);
  let v277_9: Space = subtract(&(*CONSTANT_0),&(v277_8));
  drop(v277_8);
  let v277_14: Space = intersect(&(*CONSTANT_3),&(v277_6));
  drop(v277_6);
  let v277_15: Space = if has_head(&(v277_14)) { singleton(&[]) } else { Space::new() };
  drop(v277_14);
  let mut v277_16 = Space::new();
  let mut v277_16_write = v277_16.write_zipper();
  let mut v277_16_cursor = (*s0).read_zipper();
  let v277_16_origin = v277_16_cursor.path().len();
  for v277_16_byte in v277_16_cursor.child_mask().iter() {
    v277_16_cursor.descend_to_existing_byte(v277_16_byte);
    {
    let v278_4: Space = if (&(v277_9)).is_empty() { Space::new() } else {
      let v279_2: Path = concat_path(&(*p1),&v277_16_cursor.path()[v277_16_origin..(v277_16_origin + 1)]);
      let mut v279_3 = Space::new();
      let mut v279_3_write = v279_3.write_zipper();
      let v279_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v279_3_arg_1: &[u8] = &(v279_2);
      let v279_3_arg_2: &[u8] = &(*p2);
      let v279_3_arg_4: &Space = &(&v277_16_cursor).make_map();
      let mut v279_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v279_3_origin = v279_3_cursor.path().len();
      let mut v279_3_more = v279_3_cursor.is_val() || next_value_within(&mut v279_3_cursor,v279_3_origin);
      while v279_3_more {
        {
        let v279_3_depth = v279_3_cursor.path().len();
        let v280_5: Space = routine_32(c, &v279_3_cursor.path()[v279_3_origin..v279_3_depth], &(*v279_3_arg_1), &(*v279_3_arg_2), &((*v279_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v279_3_write,&((v280_5).read_zipper()),&[]);
        }
        v279_3_more = next_value_within(&mut v279_3_cursor,v279_3_origin);
      }
      drop(v279_3_cursor);
      drop(v279_3_write);
      compose(&(v277_9),&(v279_3))
    };
    let v278_6: Space = if (&(v277_15)).is_empty() { Space::new() } else {
      let v281_2: Path = concat_path(&(*p1),&v277_16_cursor.path()[v277_16_origin..(v277_16_origin + 1)]);
      let mut v281_5 = Space::new();
      let mut v281_5_write = v281_5.write_zipper();
      for v281_5_byte in v277_16_cursor.child_mask().iter() {
        v277_16_cursor.descend_to_existing_byte(v281_5_byte);
        {
        let v282_2: Space = routine_33(c, &v277_16_cursor.path()[(v277_16_origin + 1)..(v277_16_origin + 2)], &v277_16_cursor.path()[(v277_16_origin + 1)..(v277_16_origin + 2)], &(*p2), &(v281_2), &v277_16_cursor);
        join_wrapped_into(&mut v281_5_write,&((v282_2).read_zipper()),&[]);
        }
        v277_16_cursor.ascend(1);
      }
      drop(v281_5_write);
      drop(v281_2);
      compose(&(v277_15),&(v281_5))
    };
    let v278_7: Space = unite(&(v278_4),&(v278_6));
    join_wrapped_into(&mut v277_16_write,&((v278_7).read_zipper()),&[]);
    }
    v277_16_cursor.ascend(1);
  }
  drop(v277_16_cursor);
  drop(v277_16_write);
  drop(v277_9);
  drop(v277_15);
  (v277_16).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v283_7: Space = singleton(&(*p1));
  let v283_8: Space = intersect(&(*CONSTANT_3),&(v283_7));
  let v283_9: Space = if has_head(&(v283_8)) { singleton(&[]) } else { Space::new() };
  drop(v283_8);
  let v283_10: Space = subtract(&(*CONSTANT_0),&(v283_9));
  drop(v283_9);
  let v283_21: Space = if (&(v283_10)).is_empty() { Space::new() } else {
    let v284_13: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v284_16: Space = if (&(v284_13)).is_empty() { Space::new() } else {
      let v285_15: Space = routine_50(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      compose(&(v284_13),&(v285_15))
    };
    drop(v284_13);
    let mut v284_19 = Space::new();
    let mut v284_19_write = v284_19.write_zipper();
    let mut v284_19_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v284_19_origin = v284_19_cursor.path().len();
    for v284_19_byte in v284_19_cursor.child_mask().iter() {
      v284_19_cursor.descend_to_existing_byte(v284_19_byte);
      {
      let v286_2_arg_0: &[u8] = &v284_19_cursor.path()[v284_19_origin..(v284_19_origin + 1)];
      let v286_2_arg_1: &[u8] = &(*p0);
      let v286_2_arg_2: &[u8] = &(*p2);
      let v286_2_arg_3: &[u8] = &(*p3);
      let v286_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v286_2_more = v284_19_cursor.is_val() || next_value_within(&mut v284_19_cursor,(v284_19_origin + 1));
      while v286_2_more {
        {
        let v286_2_depth = v284_19_cursor.path().len();
        let mut v287_6_cursor = (*v286_2_arg_5).read_zipper();
        let v287_6_origin = v287_6_cursor.path().len();
        for v287_6_byte in v287_6_cursor.child_mask().iter() {
          v287_6_cursor.descend_to_existing_byte(v287_6_byte);
          {
          let v288_2: Path = concat_path(&(*v286_2_arg_1),&v287_6_cursor.path()[v287_6_origin..(v287_6_origin + 1)]);
          let v288_3: Space = routine_33(c, &(v288_2), &v284_19_cursor.path()[v284_19_origin..v286_2_depth], &(*v286_2_arg_2), &(*v286_2_arg_3), &v287_6_cursor);
          drop(v288_2);
          join_wrapped_into(&mut v284_19_write,&((v288_3).read_zipper()),&[]);
          }
          v287_6_cursor.ascend(1);
        }
        drop(v287_6_cursor);
        }
        v286_2_more = next_value_within(&mut v284_19_cursor,(v284_19_origin + 1));
      }
      }
      v284_19_cursor.ascend(1);
    }
    drop(v284_19_cursor);
    drop(v284_19_write);
    let v284_20: Space = unite(&(v284_16),&(v284_19));
    compose(&(v283_10),&(v284_20))
  };
  drop(v283_10);
  let v283_23: Space = intersect(&(*CONSTANT_3),&(v283_7));
  drop(v283_7);
  let v283_24: Space = if has_head(&(v283_23)) { singleton(&[]) } else { Space::new() };
  drop(v283_23);
  let v283_26: Space = if (&(v283_24)).is_empty() { Space::new() } else {
    let mut v289_25 = Space::new();
    let mut v289_25_write = v289_25.write_zipper();
    let mut v289_25_cursor = (*s0).read_zipper();
    let v289_25_origin = v289_25_cursor.path().len();
    for v289_25_byte in v289_25_cursor.child_mask().iter() {
      v289_25_cursor.descend_to_existing_byte(v289_25_byte);
      {
      let v290_2: Space = routine_51(c, &v289_25_cursor.path()[v289_25_origin..(v289_25_origin + 1)], &v289_25_cursor.path()[v289_25_origin..(v289_25_origin + 1)], &(*p2), &(*p3), &(*p0), &v289_25_cursor);
      join_wrapped_into(&mut v289_25_write,&((v290_2).read_zipper()),&[]);
      }
      v289_25_cursor.ascend(1);
    }
    drop(v289_25_cursor);
    drop(v289_25_write);
    compose(&(v283_24),&(v289_25))
  };
  drop(v283_24);
  let v283_27: Space = unite(&(v283_21),&(v283_26));
  (v283_27).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v291_5: Space = singleton(&(*p0));
  let v291_6: Space = intersect(&(*CONSTANT_3),&(v291_5));
  let v291_7: Space = if has_head(&(v291_6)) { singleton(&[]) } else { Space::new() };
  drop(v291_6);
  let v291_8: Space = subtract(&(*CONSTANT_0),&(v291_7));
  drop(v291_7);
  let v291_13: Space = intersect(&(*CONSTANT_3),&(v291_5));
  drop(v291_5);
  let v291_14: Space = if has_head(&(v291_13)) { singleton(&[]) } else { Space::new() };
  drop(v291_13);
  let mut v291_15 = Space::new();
  let mut v291_15_write = v291_15.write_zipper();
  let mut v291_15_cursor = (*s0).read_zipper();
  let v291_15_origin = v291_15_cursor.path().len();
  for v291_15_byte in v291_15_cursor.child_mask().iter() {
    v291_15_cursor.descend_to_existing_byte(v291_15_byte);
    {
    let v292_4: Space = if (&(v291_8)).is_empty() { Space::new() } else {
      let v293_2: Path = concat_path(&(*p1),&v291_15_cursor.path()[v291_15_origin..(v291_15_origin + 1)]);
      let mut v293_3 = Space::new();
      let mut v293_3_write = v293_3.write_zipper();
      let v293_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v293_3_arg_1: &[u8] = &(v293_2);
      let v293_3_arg_3: &Space = &(&v291_15_cursor).make_map();
      let mut v293_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v293_3_origin = v293_3_cursor.path().len();
      let mut v293_3_more = v293_3_cursor.is_val() || next_value_within(&mut v293_3_cursor,v293_3_origin);
      while v293_3_more {
        {
        let v293_3_depth = v293_3_cursor.path().len();
        let v294_4: Space = routine_34(c, &v293_3_cursor.path()[v293_3_origin..v293_3_depth], &(*v293_3_arg_1), &((*v293_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v293_3_write,&((v294_4).read_zipper()),&[]);
        }
        v293_3_more = next_value_within(&mut v293_3_cursor,v293_3_origin);
      }
      drop(v293_3_cursor);
      drop(v293_3_write);
      compose(&(v291_8),&(v293_3))
    };
    let v292_6: Space = if (&(v291_14)).is_empty() { Space::new() } else {
      let v295_2: Path = concat_path(&(*p1),&v291_15_cursor.path()[v291_15_origin..(v291_15_origin + 1)]);
      let mut v295_5 = Space::new();
      let mut v295_5_write = v295_5.write_zipper();
      for v295_5_byte in v291_15_cursor.child_mask().iter() {
        v291_15_cursor.descend_to_existing_byte(v295_5_byte);
        {
        let v296_2: Space = routine_13(c, &v291_15_cursor.path()[(v291_15_origin + 1)..(v291_15_origin + 2)], &v291_15_cursor.path()[(v291_15_origin + 1)..(v291_15_origin + 2)], &(v295_2), &v291_15_cursor);
        join_wrapped_into(&mut v295_5_write,&((v296_2).read_zipper()),&[]);
        }
        v291_15_cursor.ascend(1);
      }
      drop(v295_5_write);
      drop(v295_2);
      compose(&(v291_14),&(v295_5))
    };
    let v292_7: Space = unite(&(v292_4),&(v292_6));
    join_wrapped_into(&mut v291_15_write,&((v292_7).read_zipper()),&[]);
    }
    v291_15_cursor.ascend(1);
  }
  drop(v291_15_cursor);
  drop(v291_15_write);
  drop(v291_8);
  drop(v291_14);
  (v291_15).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v297_6: Space = singleton(&(*p0));
  let v297_7: Space = intersect(&(*CONSTANT_3),&(v297_6));
  let v297_8: Space = if has_head(&(v297_7)) { singleton(&[]) } else { Space::new() };
  drop(v297_7);
  let v297_9: Space = subtract(&(*CONSTANT_0),&(v297_8));
  drop(v297_8);
  let v297_14: Space = intersect(&(*CONSTANT_3),&(v297_6));
  drop(v297_6);
  let v297_15: Space = if has_head(&(v297_14)) { singleton(&[]) } else { Space::new() };
  drop(v297_14);
  let mut v297_16 = Space::new();
  let mut v297_16_write = v297_16.write_zipper();
  let mut v297_16_cursor = (*s0).read_zipper();
  let v297_16_origin = v297_16_cursor.path().len();
  for v297_16_byte in v297_16_cursor.child_mask().iter() {
    v297_16_cursor.descend_to_existing_byte(v297_16_byte);
    {
    let v298_4: Space = if (&(v297_9)).is_empty() { Space::new() } else {
      let v299_2: Path = concat_path(&(*p1),&v297_16_cursor.path()[v297_16_origin..(v297_16_origin + 1)]);
      let mut v299_3 = Space::new();
      let mut v299_3_write = v299_3.write_zipper();
      let v299_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v299_3_arg_1: &[u8] = &(v299_2);
      let v299_3_arg_2: &[u8] = &(*p2);
      let v299_3_arg_4: &Space = &(&v297_16_cursor).make_map();
      let mut v299_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v299_3_origin = v299_3_cursor.path().len();
      let mut v299_3_more = v299_3_cursor.is_val() || next_value_within(&mut v299_3_cursor,v299_3_origin);
      while v299_3_more {
        {
        let v299_3_depth = v299_3_cursor.path().len();
        let v300_5: Space = routine_35(c, &v299_3_cursor.path()[v299_3_origin..v299_3_depth], &(*v299_3_arg_1), &(*v299_3_arg_2), &((*v299_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v299_3_write,&((v300_5).read_zipper()),&[]);
        }
        v299_3_more = next_value_within(&mut v299_3_cursor,v299_3_origin);
      }
      drop(v299_3_cursor);
      drop(v299_3_write);
      compose(&(v297_9),&(v299_3))
    };
    let v298_6: Space = if (&(v297_15)).is_empty() { Space::new() } else {
      let v301_2: Path = concat_path(&(*p1),&v297_16_cursor.path()[v297_16_origin..(v297_16_origin + 1)]);
      let mut v301_5 = Space::new();
      let mut v301_5_write = v301_5.write_zipper();
      for v301_5_byte in v297_16_cursor.child_mask().iter() {
        v297_16_cursor.descend_to_existing_byte(v301_5_byte);
        {
        let v302_2: Space = routine_36(c, &v297_16_cursor.path()[(v297_16_origin + 1)..(v297_16_origin + 2)], &v297_16_cursor.path()[(v297_16_origin + 1)..(v297_16_origin + 2)], &(*p2), &(v301_2), &v297_16_cursor);
        join_wrapped_into(&mut v301_5_write,&((v302_2).read_zipper()),&[]);
        }
        v297_16_cursor.ascend(1);
      }
      drop(v301_5_write);
      drop(v301_2);
      compose(&(v297_15),&(v301_5))
    };
    let v298_7: Space = unite(&(v298_4),&(v298_6));
    join_wrapped_into(&mut v297_16_write,&((v298_7).read_zipper()),&[]);
    }
    v297_16_cursor.ascend(1);
  }
  drop(v297_16_cursor);
  drop(v297_16_write);
  drop(v297_9);
  drop(v297_15);
  (v297_16).clone()
}

fn routine_36(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v303_7: Space = singleton(&(*p1));
  let v303_8: Space = intersect(&(*CONSTANT_3),&(v303_7));
  let v303_9: Space = if has_head(&(v303_8)) { singleton(&[]) } else { Space::new() };
  drop(v303_8);
  let v303_10: Space = subtract(&(*CONSTANT_0),&(v303_9));
  drop(v303_9);
  let v303_21: Space = if (&(v303_10)).is_empty() { Space::new() } else {
    let v304_13: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v304_16: Space = if (&(v304_13)).is_empty() { Space::new() } else {
      let v305_15: Space = routine_52(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      compose(&(v304_13),&(v305_15))
    };
    drop(v304_13);
    let mut v304_19 = Space::new();
    let mut v304_19_write = v304_19.write_zipper();
    let mut v304_19_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v304_19_origin = v304_19_cursor.path().len();
    for v304_19_byte in v304_19_cursor.child_mask().iter() {
      v304_19_cursor.descend_to_existing_byte(v304_19_byte);
      {
      let v306_2_arg_0: &[u8] = &v304_19_cursor.path()[v304_19_origin..(v304_19_origin + 1)];
      let v306_2_arg_1: &[u8] = &(*p0);
      let v306_2_arg_2: &[u8] = &(*p2);
      let v306_2_arg_3: &[u8] = &(*p3);
      let v306_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v306_2_more = v304_19_cursor.is_val() || next_value_within(&mut v304_19_cursor,(v304_19_origin + 1));
      while v306_2_more {
        {
        let v306_2_depth = v304_19_cursor.path().len();
        let mut v307_6_cursor = (*v306_2_arg_5).read_zipper();
        let v307_6_origin = v307_6_cursor.path().len();
        for v307_6_byte in v307_6_cursor.child_mask().iter() {
          v307_6_cursor.descend_to_existing_byte(v307_6_byte);
          {
          let v308_2: Path = concat_path(&(*v306_2_arg_1),&v307_6_cursor.path()[v307_6_origin..(v307_6_origin + 1)]);
          let v308_3: Space = routine_36(c, &(v308_2), &v304_19_cursor.path()[v304_19_origin..v306_2_depth], &(*v306_2_arg_2), &(*v306_2_arg_3), &v307_6_cursor);
          drop(v308_2);
          join_wrapped_into(&mut v304_19_write,&((v308_3).read_zipper()),&[]);
          }
          v307_6_cursor.ascend(1);
        }
        drop(v307_6_cursor);
        }
        v306_2_more = next_value_within(&mut v304_19_cursor,(v304_19_origin + 1));
      }
      }
      v304_19_cursor.ascend(1);
    }
    drop(v304_19_cursor);
    drop(v304_19_write);
    let v304_20: Space = unite(&(v304_16),&(v304_19));
    compose(&(v303_10),&(v304_20))
  };
  drop(v303_10);
  let v303_23: Space = intersect(&(*CONSTANT_3),&(v303_7));
  drop(v303_7);
  let v303_24: Space = if has_head(&(v303_23)) { singleton(&[]) } else { Space::new() };
  drop(v303_23);
  let v303_26: Space = if (&(v303_24)).is_empty() { Space::new() } else {
    let mut v309_25 = Space::new();
    let mut v309_25_write = v309_25.write_zipper();
    let mut v309_25_cursor = (*s0).read_zipper();
    let v309_25_origin = v309_25_cursor.path().len();
    for v309_25_byte in v309_25_cursor.child_mask().iter() {
      v309_25_cursor.descend_to_existing_byte(v309_25_byte);
      {
      let v310_2: Space = routine_53(c, &v309_25_cursor.path()[v309_25_origin..(v309_25_origin + 1)], &v309_25_cursor.path()[v309_25_origin..(v309_25_origin + 1)], &(*p2), &(*p3), &(*p0), &v309_25_cursor);
      join_wrapped_into(&mut v309_25_write,&((v310_2).read_zipper()),&[]);
      }
      v309_25_cursor.ascend(1);
    }
    drop(v309_25_cursor);
    drop(v309_25_write);
    compose(&(v303_24),&(v309_25))
  };
  drop(v303_24);
  let v303_27: Space = unite(&(v303_21),&(v303_26));
  (v303_27).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v311_5: Space = singleton(&(*p0));
  let v311_6: Space = intersect(&(*CONSTANT_3),&(v311_5));
  let v311_7: Space = if has_head(&(v311_6)) { singleton(&[]) } else { Space::new() };
  drop(v311_6);
  let v311_8: Space = subtract(&(*CONSTANT_0),&(v311_7));
  drop(v311_7);
  let v311_13: Space = intersect(&(*CONSTANT_3),&(v311_5));
  drop(v311_5);
  let v311_14: Space = if has_head(&(v311_13)) { singleton(&[]) } else { Space::new() };
  drop(v311_13);
  let mut v311_15 = Space::new();
  let mut v311_15_write = v311_15.write_zipper();
  let mut v311_15_cursor = (*s0).read_zipper();
  let v311_15_origin = v311_15_cursor.path().len();
  for v311_15_byte in v311_15_cursor.child_mask().iter() {
    v311_15_cursor.descend_to_existing_byte(v311_15_byte);
    {
    let v312_4: Space = if (&(v311_8)).is_empty() { Space::new() } else {
      let v313_2: Path = concat_path(&(*p1),&v311_15_cursor.path()[v311_15_origin..(v311_15_origin + 1)]);
      let mut v313_3 = Space::new();
      let mut v313_3_write = v313_3.write_zipper();
      let v313_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v313_3_arg_1: &[u8] = &(v313_2);
      let v313_3_arg_3: &Space = &(&v311_15_cursor).make_map();
      let mut v313_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v313_3_origin = v313_3_cursor.path().len();
      let mut v313_3_more = v313_3_cursor.is_val() || next_value_within(&mut v313_3_cursor,v313_3_origin);
      while v313_3_more {
        {
        let v313_3_depth = v313_3_cursor.path().len();
        let v314_4: Space = routine_37(c, &v313_3_cursor.path()[v313_3_origin..v313_3_depth], &(*v313_3_arg_1), &((*v313_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v313_3_write,&((v314_4).read_zipper()),&[]);
        }
        v313_3_more = next_value_within(&mut v313_3_cursor,v313_3_origin);
      }
      drop(v313_3_cursor);
      drop(v313_3_write);
      compose(&(v311_8),&(v313_3))
    };
    let v312_6: Space = if (&(v311_14)).is_empty() { Space::new() } else {
      let v315_2: Path = concat_path(&(*p1),&v311_15_cursor.path()[v311_15_origin..(v311_15_origin + 1)]);
      let mut v315_5 = Space::new();
      let mut v315_5_write = v315_5.write_zipper();
      for v315_5_byte in v311_15_cursor.child_mask().iter() {
        v311_15_cursor.descend_to_existing_byte(v315_5_byte);
        {
        let v316_2: Space = routine_15(c, &v311_15_cursor.path()[(v311_15_origin + 1)..(v311_15_origin + 2)], &v311_15_cursor.path()[(v311_15_origin + 1)..(v311_15_origin + 2)], &(v315_2), &v311_15_cursor);
        join_wrapped_into(&mut v315_5_write,&((v316_2).read_zipper()),&[]);
        }
        v311_15_cursor.ascend(1);
      }
      drop(v315_5_write);
      drop(v315_2);
      compose(&(v311_14),&(v315_5))
    };
    let v312_7: Space = unite(&(v312_4),&(v312_6));
    join_wrapped_into(&mut v311_15_write,&((v312_7).read_zipper()),&[]);
    }
    v311_15_cursor.ascend(1);
  }
  drop(v311_15_cursor);
  drop(v311_15_write);
  drop(v311_8);
  drop(v311_14);
  (v311_15).clone()
}

fn routine_38(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v317_6: Space = singleton(&(*p0));
  let v317_7: Space = intersect(&(*CONSTANT_3),&(v317_6));
  let v317_8: Space = if has_head(&(v317_7)) { singleton(&[]) } else { Space::new() };
  drop(v317_7);
  let v317_9: Space = subtract(&(*CONSTANT_0),&(v317_8));
  drop(v317_8);
  let v317_14: Space = intersect(&(*CONSTANT_3),&(v317_6));
  drop(v317_6);
  let v317_15: Space = if has_head(&(v317_14)) { singleton(&[]) } else { Space::new() };
  drop(v317_14);
  let mut v317_16 = Space::new();
  let mut v317_16_write = v317_16.write_zipper();
  let mut v317_16_cursor = (*s0).read_zipper();
  let v317_16_origin = v317_16_cursor.path().len();
  for v317_16_byte in v317_16_cursor.child_mask().iter() {
    v317_16_cursor.descend_to_existing_byte(v317_16_byte);
    {
    let v318_4: Space = if (&(v317_9)).is_empty() { Space::new() } else {
      let v319_2: Path = concat_path(&(*p1),&v317_16_cursor.path()[v317_16_origin..(v317_16_origin + 1)]);
      let mut v319_3 = Space::new();
      let mut v319_3_write = v319_3.write_zipper();
      let v319_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v319_3_arg_1: &[u8] = &(v319_2);
      let v319_3_arg_2: &[u8] = &(*p2);
      let v319_3_arg_4: &Space = &(&v317_16_cursor).make_map();
      let mut v319_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v319_3_origin = v319_3_cursor.path().len();
      let mut v319_3_more = v319_3_cursor.is_val() || next_value_within(&mut v319_3_cursor,v319_3_origin);
      while v319_3_more {
        {
        let v319_3_depth = v319_3_cursor.path().len();
        let v320_5: Space = routine_38(c, &v319_3_cursor.path()[v319_3_origin..v319_3_depth], &(*v319_3_arg_1), &(*v319_3_arg_2), &((*v319_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v319_3_write,&((v320_5).read_zipper()),&[]);
        }
        v319_3_more = next_value_within(&mut v319_3_cursor,v319_3_origin);
      }
      drop(v319_3_cursor);
      drop(v319_3_write);
      compose(&(v317_9),&(v319_3))
    };
    let v318_6: Space = if (&(v317_15)).is_empty() { Space::new() } else {
      let v321_2: Path = concat_path(&(*p1),&v317_16_cursor.path()[v317_16_origin..(v317_16_origin + 1)]);
      let mut v321_5 = Space::new();
      let mut v321_5_write = v321_5.write_zipper();
      for v321_5_byte in v317_16_cursor.child_mask().iter() {
        v317_16_cursor.descend_to_existing_byte(v321_5_byte);
        {
        let v322_2: Space = routine_39(c, &v317_16_cursor.path()[(v317_16_origin + 1)..(v317_16_origin + 2)], &v317_16_cursor.path()[(v317_16_origin + 1)..(v317_16_origin + 2)], &(*p2), &(v321_2), &v317_16_cursor);
        join_wrapped_into(&mut v321_5_write,&((v322_2).read_zipper()),&[]);
        }
        v317_16_cursor.ascend(1);
      }
      drop(v321_5_write);
      drop(v321_2);
      compose(&(v317_15),&(v321_5))
    };
    let v318_7: Space = unite(&(v318_4),&(v318_6));
    join_wrapped_into(&mut v317_16_write,&((v318_7).read_zipper()),&[]);
    }
    v317_16_cursor.ascend(1);
  }
  drop(v317_16_cursor);
  drop(v317_16_write);
  drop(v317_9);
  drop(v317_15);
  (v317_16).clone()
}

fn routine_39(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v323_7: Space = singleton(&(*p1));
  let v323_8: Space = intersect(&(*CONSTANT_3),&(v323_7));
  let v323_9: Space = if has_head(&(v323_8)) { singleton(&[]) } else { Space::new() };
  drop(v323_8);
  let v323_10: Space = subtract(&(*CONSTANT_0),&(v323_9));
  drop(v323_9);
  let v323_21: Space = if (&(v323_10)).is_empty() { Space::new() } else {
    let v324_13: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v324_16: Space = if (&(v324_13)).is_empty() { Space::new() } else {
      let v325_15: Space = routine_54(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      compose(&(v324_13),&(v325_15))
    };
    drop(v324_13);
    let mut v324_19 = Space::new();
    let mut v324_19_write = v324_19.write_zipper();
    let mut v324_19_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v324_19_origin = v324_19_cursor.path().len();
    for v324_19_byte in v324_19_cursor.child_mask().iter() {
      v324_19_cursor.descend_to_existing_byte(v324_19_byte);
      {
      let v326_2_arg_0: &[u8] = &v324_19_cursor.path()[v324_19_origin..(v324_19_origin + 1)];
      let v326_2_arg_1: &[u8] = &(*p0);
      let v326_2_arg_2: &[u8] = &(*p2);
      let v326_2_arg_3: &[u8] = &(*p3);
      let v326_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v326_2_more = v324_19_cursor.is_val() || next_value_within(&mut v324_19_cursor,(v324_19_origin + 1));
      while v326_2_more {
        {
        let v326_2_depth = v324_19_cursor.path().len();
        let mut v327_6_cursor = (*v326_2_arg_5).read_zipper();
        let v327_6_origin = v327_6_cursor.path().len();
        for v327_6_byte in v327_6_cursor.child_mask().iter() {
          v327_6_cursor.descend_to_existing_byte(v327_6_byte);
          {
          let v328_2: Path = concat_path(&(*v326_2_arg_1),&v327_6_cursor.path()[v327_6_origin..(v327_6_origin + 1)]);
          let v328_3: Space = routine_39(c, &(v328_2), &v324_19_cursor.path()[v324_19_origin..v326_2_depth], &(*v326_2_arg_2), &(*v326_2_arg_3), &v327_6_cursor);
          drop(v328_2);
          join_wrapped_into(&mut v324_19_write,&((v328_3).read_zipper()),&[]);
          }
          v327_6_cursor.ascend(1);
        }
        drop(v327_6_cursor);
        }
        v326_2_more = next_value_within(&mut v324_19_cursor,(v324_19_origin + 1));
      }
      }
      v324_19_cursor.ascend(1);
    }
    drop(v324_19_cursor);
    drop(v324_19_write);
    let v324_20: Space = unite(&(v324_16),&(v324_19));
    compose(&(v323_10),&(v324_20))
  };
  drop(v323_10);
  let v323_23: Space = intersect(&(*CONSTANT_3),&(v323_7));
  drop(v323_7);
  let v323_24: Space = if has_head(&(v323_23)) { singleton(&[]) } else { Space::new() };
  drop(v323_23);
  let v323_26: Space = if (&(v323_24)).is_empty() { Space::new() } else {
    let mut v329_25 = Space::new();
    let mut v329_25_write = v329_25.write_zipper();
    let mut v329_25_cursor = (*s0).read_zipper();
    let v329_25_origin = v329_25_cursor.path().len();
    for v329_25_byte in v329_25_cursor.child_mask().iter() {
      v329_25_cursor.descend_to_existing_byte(v329_25_byte);
      {
      let v330_2: Space = routine_55(c, &v329_25_cursor.path()[v329_25_origin..(v329_25_origin + 1)], &v329_25_cursor.path()[v329_25_origin..(v329_25_origin + 1)], &(*p2), &(*p3), &(*p0), &v329_25_cursor);
      join_wrapped_into(&mut v329_25_write,&((v330_2).read_zipper()),&[]);
      }
      v329_25_cursor.ascend(1);
    }
    drop(v329_25_cursor);
    drop(v329_25_write);
    compose(&(v323_24),&(v329_25))
  };
  drop(v323_24);
  let v323_27: Space = unite(&(v323_21),&(v323_26));
  (v323_27).clone()
}

fn routine_40(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v331_5: Space = singleton(&(*p0));
  let v331_6: Space = intersect(&(*CONSTANT_3),&(v331_5));
  let v331_7: Space = if has_head(&(v331_6)) { singleton(&[]) } else { Space::new() };
  drop(v331_6);
  let v331_8: Space = subtract(&(*CONSTANT_0),&(v331_7));
  drop(v331_7);
  let v331_13: Space = intersect(&(*CONSTANT_3),&(v331_5));
  drop(v331_5);
  let v331_14: Space = if has_head(&(v331_13)) { singleton(&[]) } else { Space::new() };
  drop(v331_13);
  let mut v331_15 = Space::new();
  let mut v331_15_write = v331_15.write_zipper();
  let mut v331_15_cursor = (*s0).read_zipper();
  let v331_15_origin = v331_15_cursor.path().len();
  for v331_15_byte in v331_15_cursor.child_mask().iter() {
    v331_15_cursor.descend_to_existing_byte(v331_15_byte);
    {
    let v332_4: Space = if (&(v331_8)).is_empty() { Space::new() } else {
      let v333_2: Path = concat_path(&(*p1),&v331_15_cursor.path()[v331_15_origin..(v331_15_origin + 1)]);
      let mut v333_3 = Space::new();
      let mut v333_3_write = v333_3.write_zipper();
      let v333_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v333_3_arg_1: &[u8] = &(v333_2);
      let v333_3_arg_3: &Space = &(&v331_15_cursor).make_map();
      let mut v333_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v333_3_origin = v333_3_cursor.path().len();
      let mut v333_3_more = v333_3_cursor.is_val() || next_value_within(&mut v333_3_cursor,v333_3_origin);
      while v333_3_more {
        {
        let v333_3_depth = v333_3_cursor.path().len();
        let v334_4: Space = routine_40(c, &v333_3_cursor.path()[v333_3_origin..v333_3_depth], &(*v333_3_arg_1), &((*v333_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v333_3_write,&((v334_4).read_zipper()),&[]);
        }
        v333_3_more = next_value_within(&mut v333_3_cursor,v333_3_origin);
      }
      drop(v333_3_cursor);
      drop(v333_3_write);
      compose(&(v331_8),&(v333_3))
    };
    let v332_6: Space = if (&(v331_14)).is_empty() { Space::new() } else {
      let v335_2: Path = concat_path(&(*p1),&v331_15_cursor.path()[v331_15_origin..(v331_15_origin + 1)]);
      let mut v335_5 = Space::new();
      let mut v335_5_write = v335_5.write_zipper();
      for v335_5_byte in v331_15_cursor.child_mask().iter() {
        v331_15_cursor.descend_to_existing_byte(v335_5_byte);
        {
        let v336_2: Space = routine_17(c, &v331_15_cursor.path()[(v331_15_origin + 1)..(v331_15_origin + 2)], &v331_15_cursor.path()[(v331_15_origin + 1)..(v331_15_origin + 2)], &(v335_2), &v331_15_cursor);
        join_wrapped_into(&mut v335_5_write,&((v336_2).read_zipper()),&[]);
        }
        v331_15_cursor.ascend(1);
      }
      drop(v335_5_write);
      drop(v335_2);
      compose(&(v331_14),&(v335_5))
    };
    let v332_7: Space = unite(&(v332_4),&(v332_6));
    join_wrapped_into(&mut v331_15_write,&((v332_7).read_zipper()),&[]);
    }
    v331_15_cursor.ascend(1);
  }
  drop(v331_15_cursor);
  drop(v331_15_write);
  drop(v331_8);
  drop(v331_14);
  (v331_15).clone()
}

fn routine_41(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v337_6: Space = singleton(&(*p0));
  let v337_7: Space = intersect(&(*CONSTANT_3),&(v337_6));
  let v337_8: Space = if has_head(&(v337_7)) { singleton(&[]) } else { Space::new() };
  drop(v337_7);
  let v337_9: Space = subtract(&(*CONSTANT_0),&(v337_8));
  drop(v337_8);
  let v337_14: Space = intersect(&(*CONSTANT_3),&(v337_6));
  drop(v337_6);
  let v337_15: Space = if has_head(&(v337_14)) { singleton(&[]) } else { Space::new() };
  drop(v337_14);
  let mut v337_16 = Space::new();
  let mut v337_16_write = v337_16.write_zipper();
  let mut v337_16_cursor = (*s0).read_zipper();
  let v337_16_origin = v337_16_cursor.path().len();
  for v337_16_byte in v337_16_cursor.child_mask().iter() {
    v337_16_cursor.descend_to_existing_byte(v337_16_byte);
    {
    let v338_4: Space = if (&(v337_9)).is_empty() { Space::new() } else {
      let v339_2: Path = concat_path(&(*p1),&v337_16_cursor.path()[v337_16_origin..(v337_16_origin + 1)]);
      let mut v339_3 = Space::new();
      let mut v339_3_write = v339_3.write_zipper();
      let v339_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v339_3_arg_1: &[u8] = &(v339_2);
      let v339_3_arg_2: &[u8] = &(*p2);
      let v339_3_arg_4: &Space = &(&v337_16_cursor).make_map();
      let mut v339_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v339_3_origin = v339_3_cursor.path().len();
      let mut v339_3_more = v339_3_cursor.is_val() || next_value_within(&mut v339_3_cursor,v339_3_origin);
      while v339_3_more {
        {
        let v339_3_depth = v339_3_cursor.path().len();
        let v340_5: Space = routine_41(c, &v339_3_cursor.path()[v339_3_origin..v339_3_depth], &(*v339_3_arg_1), &(*v339_3_arg_2), &((*v339_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v339_3_write,&((v340_5).read_zipper()),&[]);
        }
        v339_3_more = next_value_within(&mut v339_3_cursor,v339_3_origin);
      }
      drop(v339_3_cursor);
      drop(v339_3_write);
      compose(&(v337_9),&(v339_3))
    };
    let v338_6: Space = if (&(v337_15)).is_empty() { Space::new() } else {
      let v341_2: Path = concat_path(&(*p1),&v337_16_cursor.path()[v337_16_origin..(v337_16_origin + 1)]);
      let mut v341_5 = Space::new();
      let mut v341_5_write = v341_5.write_zipper();
      for v341_5_byte in v337_16_cursor.child_mask().iter() {
        v337_16_cursor.descend_to_existing_byte(v341_5_byte);
        {
        let v342_2: Space = routine_42(c, &v337_16_cursor.path()[(v337_16_origin + 1)..(v337_16_origin + 2)], &v337_16_cursor.path()[(v337_16_origin + 1)..(v337_16_origin + 2)], &(*p2), &(v341_2), &v337_16_cursor);
        join_wrapped_into(&mut v341_5_write,&((v342_2).read_zipper()),&[]);
        }
        v337_16_cursor.ascend(1);
      }
      drop(v341_5_write);
      drop(v341_2);
      compose(&(v337_15),&(v341_5))
    };
    let v338_7: Space = unite(&(v338_4),&(v338_6));
    join_wrapped_into(&mut v337_16_write,&((v338_7).read_zipper()),&[]);
    }
    v337_16_cursor.ascend(1);
  }
  drop(v337_16_cursor);
  drop(v337_16_write);
  drop(v337_9);
  drop(v337_15);
  (v337_16).clone()
}

fn routine_42(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v343_7: Space = singleton(&(*p1));
  let v343_8: Space = intersect(&(*CONSTANT_3),&(v343_7));
  let v343_9: Space = if has_head(&(v343_8)) { singleton(&[]) } else { Space::new() };
  drop(v343_8);
  let v343_10: Space = subtract(&(*CONSTANT_0),&(v343_9));
  drop(v343_9);
  let v343_21: Space = if (&(v343_10)).is_empty() { Space::new() } else {
    let v344_13: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v344_16: Space = if (&(v344_13)).is_empty() { Space::new() } else {
      let v345_15: Space = routine_56(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*s0));
      compose(&(v344_13),&(v345_15))
    };
    drop(v344_13);
    let mut v344_19 = Space::new();
    let mut v344_19_write = v344_19.write_zipper();
    let mut v344_19_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v344_19_origin = v344_19_cursor.path().len();
    for v344_19_byte in v344_19_cursor.child_mask().iter() {
      v344_19_cursor.descend_to_existing_byte(v344_19_byte);
      {
      let v346_2_arg_0: &[u8] = &v344_19_cursor.path()[v344_19_origin..(v344_19_origin + 1)];
      let v346_2_arg_1: &[u8] = &(*p0);
      let v346_2_arg_2: &[u8] = &(*p2);
      let v346_2_arg_3: &[u8] = &(*p3);
      let v346_2_arg_5: &Space = &(&(*s0)).make_map();
      let mut v346_2_more = v344_19_cursor.is_val() || next_value_within(&mut v344_19_cursor,(v344_19_origin + 1));
      while v346_2_more {
        {
        let v346_2_depth = v344_19_cursor.path().len();
        let mut v347_6_cursor = (*v346_2_arg_5).read_zipper();
        let v347_6_origin = v347_6_cursor.path().len();
        for v347_6_byte in v347_6_cursor.child_mask().iter() {
          v347_6_cursor.descend_to_existing_byte(v347_6_byte);
          {
          let v348_2: Path = concat_path(&(*v346_2_arg_1),&v347_6_cursor.path()[v347_6_origin..(v347_6_origin + 1)]);
          let v348_3: Space = routine_42(c, &(v348_2), &v344_19_cursor.path()[v344_19_origin..v346_2_depth], &(*v346_2_arg_2), &(*v346_2_arg_3), &v347_6_cursor);
          drop(v348_2);
          join_wrapped_into(&mut v344_19_write,&((v348_3).read_zipper()),&[]);
          }
          v347_6_cursor.ascend(1);
        }
        drop(v347_6_cursor);
        }
        v346_2_more = next_value_within(&mut v344_19_cursor,(v344_19_origin + 1));
      }
      }
      v344_19_cursor.ascend(1);
    }
    drop(v344_19_cursor);
    drop(v344_19_write);
    let v344_20: Space = unite(&(v344_16),&(v344_19));
    compose(&(v343_10),&(v344_20))
  };
  drop(v343_10);
  let v343_23: Space = intersect(&(*CONSTANT_3),&(v343_7));
  drop(v343_7);
  let v343_24: Space = if has_head(&(v343_23)) { singleton(&[]) } else { Space::new() };
  drop(v343_23);
  let v343_26: Space = if (&(v343_24)).is_empty() { Space::new() } else {
    let mut v349_25 = Space::new();
    let mut v349_25_write = v349_25.write_zipper();
    let mut v349_25_cursor = (*s0).read_zipper();
    let v349_25_origin = v349_25_cursor.path().len();
    for v349_25_byte in v349_25_cursor.child_mask().iter() {
      v349_25_cursor.descend_to_existing_byte(v349_25_byte);
      {
      let v350_2: Space = routine_57(c, &v349_25_cursor.path()[v349_25_origin..(v349_25_origin + 1)], &v349_25_cursor.path()[v349_25_origin..(v349_25_origin + 1)], &(*p2), &(*p3), &(*p0), &v349_25_cursor);
      join_wrapped_into(&mut v349_25_write,&((v350_2).read_zipper()),&[]);
      }
      v349_25_cursor.ascend(1);
    }
    drop(v349_25_cursor);
    drop(v349_25_write);
    compose(&(v343_24),&(v349_25))
  };
  drop(v343_24);
  let v343_27: Space = unite(&(v343_21),&(v343_26));
  (v343_27).clone()
}

fn routine_43(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8]) -> Space {
  let v351_7: Space = if (&(descend_cursor((*CONSTANT_14).read_zipper(),&(*p2)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_14).read_zipper(),&(*p2))),&(descend_cursor((*CONSTANT_14).read_zipper(),&(*p2))))
  };
  let mut v351_19 = Space::new();
  let mut v351_19_write = v351_19.write_zipper();
  let mut v351_19_cursor = descend_cursor((*CONSTANT_14).read_zipper(),&(*p2));
  let v351_19_origin = v351_19_cursor.path().len();
  for v351_19_byte in v351_19_cursor.child_mask().iter() {
    v351_19_cursor.descend_to_existing_byte(v351_19_byte);
    {
    let v353_2: Space = singleton(&v351_19_cursor.path()[v351_19_origin..(v351_19_origin + 1)]);
    let v353_3: Space = intersect(&(*CONSTANT_3),&(v353_2));
    let v353_4: Space = if has_head(&(v353_3)) { singleton(&[]) } else { Space::new() };
    drop(v353_3);
    let v353_5: Space = subtract(&(*CONSTANT_0),&(v353_4));
    drop(v353_4);
    let v353_8: Space = if (&(v353_5)).is_empty() { Space::new() } else {
      let mut v354_7 = Space::new();
      let mut v354_7_write = v354_7.write_zipper();
      let v354_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v354_7_arg_1: &[u8] = &v351_19_cursor.path()[v351_19_origin..(v351_19_origin + 1)];
      let v354_7_arg_2: &[u8] = &(*p1);
      let v354_7_arg_3: &[u8] = &(*p0);
      let v354_7_arg_5: &Space = &(&v351_19_cursor).make_map();
      let mut v354_7_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&v351_19_cursor.path()[v351_19_origin..(v351_19_origin + 1)]);
      let v354_7_origin = v354_7_cursor.path().len();
      let mut v354_7_more = v354_7_cursor.is_val() || next_value_within(&mut v354_7_cursor,v354_7_origin);
      while v354_7_more {
        {
        let v354_7_depth = v354_7_cursor.path().len();
        let mut v355_6_cursor = (*v354_7_arg_5).read_zipper();
        let v355_6_origin = v355_6_cursor.path().len();
        for v355_6_byte in v355_6_cursor.child_mask().iter() {
          v355_6_cursor.descend_to_existing_byte(v355_6_byte);
          {
          let v356_2: Path = concat_path(&(*v354_7_arg_1),&v355_6_cursor.path()[v355_6_origin..(v355_6_origin + 1)]);
          let v356_3: Space = routine_19(c, &(v356_2), &v354_7_cursor.path()[v354_7_origin..v354_7_depth], &(*v354_7_arg_2), &(*v354_7_arg_3), &v355_6_cursor);
          drop(v356_2);
          join_wrapped_into(&mut v354_7_write,&((v356_3).read_zipper()),&[]);
          }
          v355_6_cursor.ascend(1);
        }
        drop(v355_6_cursor);
        }
        v354_7_more = next_value_within(&mut v354_7_cursor,v354_7_origin);
      }
      drop(v354_7_cursor);
      drop(v354_7_write);
      compose(&(v353_5),&(v354_7))
    };
    drop(v353_5);
    let v353_9: Space = intersect(&(*CONSTANT_3),&(v353_2));
    drop(v353_2);
    let v353_10: Space = if has_head(&(v353_9)) { singleton(&[]) } else { Space::new() };
    drop(v353_9);
    let v353_20: Space = if (&(v353_10)).is_empty() { Space::new() } else {
      let v357_13: Space = if (&(descend_cursor(descend_cursor((*CONSTANT_12).read_zipper(),&(*p1)),&v351_19_cursor.path()[v351_19_origin..(v351_19_origin + 1)]))).is_empty() { Space::new() } else {
        compose(&(descend_cursor(descend_cursor((*CONSTANT_12).read_zipper(),&(*p1)),&v351_19_cursor.path()[v351_19_origin..(v351_19_origin + 1)])),&(descend_cursor(descend_cursor((*CONSTANT_12).read_zipper(),&(*p0)),&v351_19_cursor.path()[v351_19_origin..(v351_19_origin + 1)])))
      };
      let v357_14: Path = concat_path(&v351_19_cursor.path()[v351_19_origin..(v351_19_origin + 1)],&(*p0));
      let v357_15: Space = singleton(&(v357_14));
      drop(v357_14);
      let v357_16: Space = unite(&(v357_13),&(v357_15));
      drop(v357_13);
      drop(v357_15);
      let v357_17: Path = concat_path(&(*p1),&v351_19_cursor.path()[v351_19_origin..(v351_19_origin + 1)]);
      let v357_18: Space = singleton(&(v357_17));
      drop(v357_17);
      let v357_19: Space = unite(&(v357_16),&(v357_18));
      drop(v357_16);
      drop(v357_18);
      compose(&(v353_10),&(v357_19))
    };
    drop(v353_10);
    let v353_21: Space = unite(&(v353_8),&(v353_20));
    drop(v353_20);
    join_wrapped_into(&mut v351_19_write,&((v353_21).read_zipper()),&[]);
    }
    v351_19_cursor.ascend(1);
  }
  drop(v351_19_cursor);
  drop(v351_19_write);
  let v351_20: Space = intersect(&(v351_7),&(v351_19));
  drop(v351_7);
  (v351_20).clone()
}

fn routine_44(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v359_7: Space = singleton(&(*p0));
  let v359_8: Space = intersect(&(*CONSTANT_3),&(v359_7));
  let v359_9: Space = if has_head(&(v359_8)) { singleton(&[]) } else { Space::new() };
  drop(v359_8);
  let v359_10: Space = subtract(&(*CONSTANT_0),&(v359_9));
  drop(v359_9);
  let v359_15: Space = intersect(&(*CONSTANT_3),&(v359_7));
  drop(v359_7);
  let v359_16: Space = if has_head(&(v359_15)) { singleton(&[]) } else { Space::new() };
  drop(v359_15);
  let mut v359_23 = Space::new();
  let mut v359_23_write = v359_23.write_zipper();
  let mut v359_23_cursor = (*s0).read_zipper();
  let v359_23_origin = v359_23_cursor.path().len();
  for v359_23_byte in v359_23_cursor.child_mask().iter() {
    v359_23_cursor.descend_to_existing_byte(v359_23_byte);
    {
    let v360_4: Space = if (&(v359_10)).is_empty() { Space::new() } else {
      let v361_2: Path = concat_path(&(*p1),&v359_23_cursor.path()[v359_23_origin..(v359_23_origin + 1)]);
      let mut v361_3 = Space::new();
      let mut v361_3_write = v361_3.write_zipper();
      let v361_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v361_3_arg_1: &[u8] = &(v361_2);
      let v361_3_arg_2: &[u8] = &(*p2);
      let v361_3_arg_3: &[u8] = &(*p3);
      let v361_3_arg_5: &Space = &(&v359_23_cursor).make_map();
      let mut v361_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v361_3_origin = v361_3_cursor.path().len();
      let mut v361_3_more = v361_3_cursor.is_val() || next_value_within(&mut v361_3_cursor,v361_3_origin);
      while v361_3_more {
        {
        let v361_3_depth = v361_3_cursor.path().len();
        let v362_6: Space = routine_44(c, &v361_3_cursor.path()[v361_3_origin..v361_3_depth], &(*v361_3_arg_1), &(*v361_3_arg_2), &(*v361_3_arg_3), &((*v361_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v361_3_write,&((v362_6).read_zipper()),&[]);
        }
        v361_3_more = next_value_within(&mut v361_3_cursor,v361_3_origin);
      }
      drop(v361_3_cursor);
      drop(v361_3_write);
      compose(&(v359_10),&(v361_3))
    };
    let v360_14: Space = if (&(v359_16)).is_empty() { Space::new() } else {
      let v363_2: Path = concat_path(&(*p1),&v359_23_cursor.path()[v359_23_origin..(v359_23_origin + 1)]);
      let v363_7: Space = if (&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_12).read_zipper(),&(*p2)),&(*p1)),&v359_23_cursor.path()[v359_23_origin..(v359_23_origin + 1)]))).is_empty() { Space::new() } else {
        compose(&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_12).read_zipper(),&(*p2)),&(*p1)),&v359_23_cursor.path()[v359_23_origin..(v359_23_origin + 1)])),&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_12).read_zipper(),&(*p3)),&(*p1)),&v359_23_cursor.path()[v359_23_origin..(v359_23_origin + 1)])))
      };
      let v363_8: Path = concat_path(&(v363_2),&(*p3));
      let v363_9: Space = singleton(&(v363_8));
      drop(v363_8);
      let v363_10: Space = unite(&(v363_7),&(v363_9));
      drop(v363_7);
      drop(v363_9);
      let v363_11: Path = concat_path(&(*p2),&(v363_2));
      drop(v363_2);
      let v363_12: Space = singleton(&(v363_11));
      drop(v363_11);
      let v363_13: Space = unite(&(v363_10),&(v363_12));
      drop(v363_10);
      drop(v363_12);
      compose(&(v359_16),&(v363_13))
    };
    let v360_15: Space = unite(&(v360_4),&(v360_14));
    drop(v360_14);
    join_wrapped_into(&mut v359_23_write,&((v360_15).read_zipper()),&[]);
    }
    v359_23_cursor.ascend(1);
  }
  drop(v359_23_cursor);
  drop(v359_23_write);
  drop(v359_10);
  drop(v359_16);
  (v359_23).clone()
}

fn routine_45(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v365_8: Space = singleton(&(*p0));
  let v365_9: Space = intersect(&(*CONSTANT_3),&(v365_8));
  let v365_10: Space = if has_head(&(v365_9)) { singleton(&[]) } else { Space::new() };
  drop(v365_9);
  let v365_11: Space = subtract(&(*CONSTANT_0),&(v365_10));
  drop(v365_10);
  let v365_16: Space = intersect(&(*CONSTANT_3),&(v365_8));
  drop(v365_8);
  let v365_17: Space = if has_head(&(v365_16)) { singleton(&[]) } else { Space::new() };
  drop(v365_16);
  let v365_20: Path = concat_path(&(*p2),&(*p3));
  let mut v365_21 = Space::new();
  let mut v365_21_write = v365_21.write_zipper();
  let mut v365_21_cursor = (*s0).read_zipper();
  let v365_21_origin = v365_21_cursor.path().len();
  for v365_21_byte in v365_21_cursor.child_mask().iter() {
    v365_21_cursor.descend_to_existing_byte(v365_21_byte);
    {
    let v366_4: Space = if (&(v365_11)).is_empty() { Space::new() } else {
      let v367_2: Path = concat_path(&(*p1),&v365_21_cursor.path()[v365_21_origin..(v365_21_origin + 1)]);
      let mut v367_3 = Space::new();
      let mut v367_3_write = v367_3.write_zipper();
      let v367_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v367_3_arg_1: &[u8] = &(v367_2);
      let v367_3_arg_2: &[u8] = &(*p2);
      let v367_3_arg_3: &[u8] = &(*p3);
      let v367_3_arg_5: &Space = &(&v365_21_cursor).make_map();
      let v367_3_arg_6: &Space = &(&(*s1)).make_map();
      let mut v367_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v367_3_origin = v367_3_cursor.path().len();
      let mut v367_3_more = v367_3_cursor.is_val() || next_value_within(&mut v367_3_cursor,v367_3_origin);
      while v367_3_more {
        {
        let v367_3_depth = v367_3_cursor.path().len();
        let v368_7: Space = routine_45(c, &v367_3_cursor.path()[v367_3_origin..v367_3_depth], &(*v367_3_arg_1), &(*v367_3_arg_2), &(*v367_3_arg_3), &((*v367_3_arg_5).read_zipper()), &((*v367_3_arg_6).read_zipper()));
        join_wrapped_into(&mut v367_3_write,&((v368_7).read_zipper()),&[]);
        }
        v367_3_more = next_value_within(&mut v367_3_cursor,v367_3_origin);
      }
      drop(v367_3_cursor);
      drop(v367_3_write);
      compose(&(v365_11),&(v367_3))
    };
    let v366_7: Space = if (&(v365_17)).is_empty() { Space::new() } else {
      let v369_2: Path = concat_path(&(*p1),&v365_21_cursor.path()[v365_21_origin..(v365_21_origin + 1)]);
      let v369_5: Space = routine_43(c, &(v369_2), &(*CONSTANT_10), &(*CONSTANT_11));
      let v369_6: Space = unite(&(*s1),&(v369_5));
      compose(&(v365_17),&(v369_6))
    };
    let v366_8: Space = wrap(&(v366_7),&(v365_20));
    let v370_2: Path = concat_path(&(*p1),&v365_21_cursor.path()[v365_21_origin..(v365_21_origin + 1)]);
    let v366_9: Space = wrap(&(v366_8),&(v370_2));
    let v366_10: Space = unite(&(v366_4),&(v366_9));
    join_wrapped_into(&mut v365_21_write,&((v366_10).read_zipper()),&[]);
    }
    v365_21_cursor.ascend(1);
  }
  drop(v365_21_cursor);
  drop(v365_21_write);
  drop(v365_11);
  drop(v365_17);
  drop(v365_20);
  (v365_21).clone()
}

fn routine_46(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v371_7: Space = singleton(&(*p0));
  let v371_8: Space = intersect(&(*CONSTANT_3),&(v371_7));
  let v371_9: Space = if has_head(&(v371_8)) { singleton(&[]) } else { Space::new() };
  drop(v371_8);
  let v371_10: Space = subtract(&(*CONSTANT_0),&(v371_9));
  drop(v371_9);
  let v371_15: Space = intersect(&(*CONSTANT_3),&(v371_7));
  drop(v371_7);
  let v371_16: Space = if has_head(&(v371_15)) { singleton(&[]) } else { Space::new() };
  drop(v371_15);
  let mut v371_19 = Space::new();
  let mut v371_19_write = v371_19.write_zipper();
  let mut v371_19_cursor = (*s0).read_zipper();
  let v371_19_origin = v371_19_cursor.path().len();
  for v371_19_byte in v371_19_cursor.child_mask().iter() {
    v371_19_cursor.descend_to_existing_byte(v371_19_byte);
    {
    let v372_4: Space = if (&(v371_10)).is_empty() { Space::new() } else {
      let v373_2: Path = concat_path(&(*p1),&v371_19_cursor.path()[v371_19_origin..(v371_19_origin + 1)]);
      let mut v373_3 = Space::new();
      let mut v373_3_write = v373_3.write_zipper();
      let v373_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v373_3_arg_1: &[u8] = &(v373_2);
      let v373_3_arg_2: &[u8] = &(*p2);
      let v373_3_arg_3: &[u8] = &(*p3);
      let v373_3_arg_5: &Space = &(&v371_19_cursor).make_map();
      let mut v373_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v373_3_origin = v373_3_cursor.path().len();
      let mut v373_3_more = v373_3_cursor.is_val() || next_value_within(&mut v373_3_cursor,v373_3_origin);
      while v373_3_more {
        {
        let v373_3_depth = v373_3_cursor.path().len();
        let v374_6: Space = routine_46(c, &v373_3_cursor.path()[v373_3_origin..v373_3_depth], &(*v373_3_arg_1), &(*v373_3_arg_2), &(*v373_3_arg_3), &((*v373_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v373_3_write,&((v374_6).read_zipper()),&[]);
        }
        v373_3_more = next_value_within(&mut v373_3_cursor,v373_3_origin);
      }
      drop(v373_3_cursor);
      drop(v373_3_write);
      compose(&(v371_10),&(v373_3))
    };
    let v372_8: Space = if (&(v371_16)).is_empty() { Space::new() } else {
      let v375_2: Path = concat_path(&(*p1),&v371_19_cursor.path()[v371_19_origin..(v371_19_origin + 1)]);
      let v375_6: Space = subtract(&(*CONSTANT_6),&(descend_cursor(cursor_at(&v371_19_cursor,(v371_19_origin + 1)),&(*CONSTANT_13))));
      let mut v375_7 = Space::new();
      let mut v375_7_write = v375_7.write_zipper();
      let mut v375_7_cursor = (v375_6).read_zipper();
      let v375_7_origin = v375_7_cursor.path().len();
      for v375_7_byte in v375_7_cursor.child_mask().iter() {
        v375_7_cursor.descend_to_existing_byte(v375_7_byte);
        {
        let v376_2: Space = routine_47(c, &v375_7_cursor.path()[v375_7_origin..(v375_7_origin + 1)], &v375_7_cursor.path()[v375_7_origin..(v375_7_origin + 1)], &(*p2), &(v375_2), &(*p3), &v375_7_cursor, &v371_19_cursor);
        join_wrapped_into(&mut v375_7_write,&((v376_2).read_zipper()),&[]);
        }
        v375_7_cursor.ascend(1);
      }
      drop(v375_7_cursor);
      drop(v375_7_write);
      drop(v375_2);
      drop(v375_6);
      compose(&(v371_16),&(v375_7))
    };
    let v372_9: Space = unite(&(v372_4),&(v372_8));
    join_wrapped_into(&mut v371_19_write,&((v372_9).read_zipper()),&[]);
    }
    v371_19_cursor.ascend(1);
  }
  drop(v371_19_cursor);
  drop(v371_19_write);
  drop(v371_10);
  drop(v371_16);
  (v371_19).clone()
}

fn routine_47(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v377_9: Space = singleton(&(*p1));
  let v377_10: Space = intersect(&(*CONSTANT_3),&(v377_9));
  let v377_11: Space = if has_head(&(v377_10)) { singleton(&[]) } else { Space::new() };
  drop(v377_10);
  let v377_12: Space = subtract(&(*CONSTANT_0),&(v377_11));
  drop(v377_11);
  let v377_23: Space = if (&(v377_12)).is_empty() { Space::new() } else {
    let v378_15: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v378_18: Space = if (&(v378_15)).is_empty() { Space::new() } else {
      let v379_17: Space = routine_58(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*s0), &(*s1));
      compose(&(v378_15),&(v379_17))
    };
    drop(v378_15);
    let mut v378_21 = Space::new();
    let mut v378_21_write = v378_21.write_zipper();
    let mut v378_21_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v378_21_origin = v378_21_cursor.path().len();
    for v378_21_byte in v378_21_cursor.child_mask().iter() {
      v378_21_cursor.descend_to_existing_byte(v378_21_byte);
      {
      let v380_2_arg_0: &[u8] = &v378_21_cursor.path()[v378_21_origin..(v378_21_origin + 1)];
      let v380_2_arg_1: &[u8] = &(*p0);
      let v380_2_arg_2: &[u8] = &(*p2);
      let v380_2_arg_3: &[u8] = &(*p3);
      let v380_2_arg_4: &[u8] = &(*p4);
      let v380_2_arg_6: &Space = &(&(*s0)).make_map();
      let v380_2_arg_7: &Space = &(&(*s1)).make_map();
      let mut v380_2_more = v378_21_cursor.is_val() || next_value_within(&mut v378_21_cursor,(v378_21_origin + 1));
      while v380_2_more {
        {
        let v380_2_depth = v378_21_cursor.path().len();
        let mut v381_8_cursor = (*v380_2_arg_6).read_zipper();
        let v381_8_origin = v381_8_cursor.path().len();
        for v381_8_byte in v381_8_cursor.child_mask().iter() {
          v381_8_cursor.descend_to_existing_byte(v381_8_byte);
          {
          let v382_2: Path = concat_path(&(*v380_2_arg_1),&v381_8_cursor.path()[v381_8_origin..(v381_8_origin + 1)]);
          let v382_3: Space = routine_47(c, &(v382_2), &v378_21_cursor.path()[v378_21_origin..v380_2_depth], &(*v380_2_arg_2), &(*v380_2_arg_3), &(*v380_2_arg_4), &v381_8_cursor, &((*v380_2_arg_7).read_zipper()));
          drop(v382_2);
          join_wrapped_into(&mut v378_21_write,&((v382_3).read_zipper()),&[]);
          }
          v381_8_cursor.ascend(1);
        }
        drop(v381_8_cursor);
        }
        v380_2_more = next_value_within(&mut v378_21_cursor,(v378_21_origin + 1));
      }
      }
      v378_21_cursor.ascend(1);
    }
    drop(v378_21_cursor);
    drop(v378_21_write);
    let v378_22: Space = unite(&(v378_18),&(v378_21));
    compose(&(v377_12),&(v378_22))
  };
  drop(v377_12);
  let v377_25: Space = intersect(&(*CONSTANT_3),&(v377_9));
  drop(v377_9);
  let v377_26: Space = if has_head(&(v377_25)) { singleton(&[]) } else { Space::new() };
  drop(v377_25);
  let v377_34: Space = if (&(v377_26)).is_empty() { Space::new() } else {
    let v383_31: Space = routine_19(c, &(*CONSTANT_2), &(*CONSTANT_2), &(*CONSTANT_13), &(*p0), &((*CONSTANT_4).read_zipper()));
    let v383_32: Space = intersect(&(*CONSTANT_8),&(v383_31));
    let v383_33: Space = unite(&(v383_32),&(*s1));
    compose(&(v377_26),&(v383_33))
  };
  drop(v377_26);
  let v377_35: Path = concat_path(&(*p4),&(*p2));
  let v377_36: Path = concat_path(&(v377_35),&(*p3));
  drop(v377_35);
  let v377_37: Space = wrap(&(v377_34),&(v377_36));
  drop(v377_36);
  let v377_38: Space = wrap(&(v377_37),&(*p0));
  let v377_39: Space = unite(&(v377_23),&(v377_38));
  (v377_39).clone()
}

fn routine_48(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v384_7: Space = singleton(&(*p0));
  let v384_8: Space = intersect(&(*CONSTANT_3),&(v384_7));
  let v384_9: Space = if has_head(&(v384_8)) { singleton(&[]) } else { Space::new() };
  drop(v384_8);
  let v384_10: Space = subtract(&(*CONSTANT_0),&(v384_9));
  drop(v384_9);
  let v384_15: Space = intersect(&(*CONSTANT_3),&(v384_7));
  drop(v384_7);
  let v384_16: Space = if has_head(&(v384_15)) { singleton(&[]) } else { Space::new() };
  drop(v384_15);
  let mut v384_17 = Space::new();
  let mut v384_17_write = v384_17.write_zipper();
  let mut v384_17_cursor = (*s0).read_zipper();
  let v384_17_origin = v384_17_cursor.path().len();
  for v384_17_byte in v384_17_cursor.child_mask().iter() {
    v384_17_cursor.descend_to_existing_byte(v384_17_byte);
    {
    let v385_4: Space = if (&(v384_10)).is_empty() { Space::new() } else {
      let v386_2: Path = concat_path(&(*p1),&v384_17_cursor.path()[v384_17_origin..(v384_17_origin + 1)]);
      let mut v386_3 = Space::new();
      let mut v386_3_write = v386_3.write_zipper();
      let v386_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v386_3_arg_1: &[u8] = &(v386_2);
      let v386_3_arg_2: &[u8] = &(*p2);
      let v386_3_arg_3: &[u8] = &(*p3);
      let v386_3_arg_5: &Space = &(&v384_17_cursor).make_map();
      let mut v386_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v386_3_origin = v386_3_cursor.path().len();
      let mut v386_3_more = v386_3_cursor.is_val() || next_value_within(&mut v386_3_cursor,v386_3_origin);
      while v386_3_more {
        {
        let v386_3_depth = v386_3_cursor.path().len();
        let v387_6: Space = routine_48(c, &v386_3_cursor.path()[v386_3_origin..v386_3_depth], &(*v386_3_arg_1), &(*v386_3_arg_2), &(*v386_3_arg_3), &((*v386_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v386_3_write,&((v387_6).read_zipper()),&[]);
        }
        v386_3_more = next_value_within(&mut v386_3_cursor,v386_3_origin);
      }
      drop(v386_3_cursor);
      drop(v386_3_write);
      compose(&(v384_10),&(v386_3))
    };
    let v385_6: Space = if (&(v384_16)).is_empty() { Space::new() } else {
      let v388_2: Path = concat_path(&(*p1),&v384_17_cursor.path()[v384_17_origin..(v384_17_origin + 1)]);
      let mut v388_5 = Space::new();
      let mut v388_5_write = v388_5.write_zipper();
      for v388_5_byte in v384_17_cursor.child_mask().iter() {
        v384_17_cursor.descend_to_existing_byte(v388_5_byte);
        {
        let v389_2: Space = routine_49(c, &v384_17_cursor.path()[(v384_17_origin + 1)..(v384_17_origin + 2)], &v384_17_cursor.path()[(v384_17_origin + 1)..(v384_17_origin + 2)], &(*p2), &(v388_2), &(*p3), &v384_17_cursor);
        join_wrapped_into(&mut v388_5_write,&((v389_2).read_zipper()),&[]);
        }
        v384_17_cursor.ascend(1);
      }
      drop(v388_5_write);
      drop(v388_2);
      compose(&(v384_16),&(v388_5))
    };
    let v385_7: Space = unite(&(v385_4),&(v385_6));
    join_wrapped_into(&mut v384_17_write,&((v385_7).read_zipper()),&[]);
    }
    v384_17_cursor.ascend(1);
  }
  drop(v384_17_cursor);
  drop(v384_17_write);
  drop(v384_10);
  drop(v384_16);
  (v384_17).clone()
}

fn routine_49(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v390_8: Space = singleton(&(*p1));
  let v390_9: Space = intersect(&(*CONSTANT_3),&(v390_8));
  let v390_10: Space = if has_head(&(v390_9)) { singleton(&[]) } else { Space::new() };
  drop(v390_9);
  let v390_11: Space = subtract(&(*CONSTANT_0),&(v390_10));
  drop(v390_10);
  let v390_22: Space = if (&(v390_11)).is_empty() { Space::new() } else {
    let v391_14: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v391_17: Space = if (&(v391_14)).is_empty() { Space::new() } else {
      let v392_16: Space = routine_59(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*s0));
      compose(&(v391_14),&(v392_16))
    };
    drop(v391_14);
    let mut v391_20 = Space::new();
    let mut v391_20_write = v391_20.write_zipper();
    let mut v391_20_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v391_20_origin = v391_20_cursor.path().len();
    for v391_20_byte in v391_20_cursor.child_mask().iter() {
      v391_20_cursor.descend_to_existing_byte(v391_20_byte);
      {
      let v393_2_arg_0: &[u8] = &v391_20_cursor.path()[v391_20_origin..(v391_20_origin + 1)];
      let v393_2_arg_1: &[u8] = &(*p0);
      let v393_2_arg_2: &[u8] = &(*p2);
      let v393_2_arg_3: &[u8] = &(*p3);
      let v393_2_arg_4: &[u8] = &(*p4);
      let v393_2_arg_6: &Space = &(&(*s0)).make_map();
      let mut v393_2_more = v391_20_cursor.is_val() || next_value_within(&mut v391_20_cursor,(v391_20_origin + 1));
      while v393_2_more {
        {
        let v393_2_depth = v391_20_cursor.path().len();
        let mut v394_7_cursor = (*v393_2_arg_6).read_zipper();
        let v394_7_origin = v394_7_cursor.path().len();
        for v394_7_byte in v394_7_cursor.child_mask().iter() {
          v394_7_cursor.descend_to_existing_byte(v394_7_byte);
          {
          let v395_2: Path = concat_path(&(*v393_2_arg_1),&v394_7_cursor.path()[v394_7_origin..(v394_7_origin + 1)]);
          let v395_3: Space = routine_49(c, &(v395_2), &v391_20_cursor.path()[v391_20_origin..v393_2_depth], &(*v393_2_arg_2), &(*v393_2_arg_3), &(*v393_2_arg_4), &v394_7_cursor);
          drop(v395_2);
          join_wrapped_into(&mut v391_20_write,&((v395_3).read_zipper()),&[]);
          }
          v394_7_cursor.ascend(1);
        }
        drop(v394_7_cursor);
        }
        v393_2_more = next_value_within(&mut v391_20_cursor,(v391_20_origin + 1));
      }
      }
      v391_20_cursor.ascend(1);
    }
    drop(v391_20_cursor);
    drop(v391_20_write);
    let v391_21: Space = unite(&(v391_17),&(v391_20));
    compose(&(v390_11),&(v391_21))
  };
  drop(v390_11);
  let v390_24: Space = intersect(&(*CONSTANT_3),&(v390_8));
  drop(v390_8);
  let v390_25: Space = if has_head(&(v390_24)) { singleton(&[]) } else { Space::new() };
  drop(v390_24);
  let v390_31: Space = if (&(v390_25)).is_empty() { Space::new() } else {
    let v396_29: Space = subtract(&(*CONSTANT_6),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_15))));
    let mut v396_30 = Space::new();
    let mut v396_30_write = v396_30.write_zipper();
    let mut v396_30_cursor = (v396_29).read_zipper();
    let v396_30_origin = v396_30_cursor.path().len();
    for v396_30_byte in v396_30_cursor.child_mask().iter() {
      v396_30_cursor.descend_to_existing_byte(v396_30_byte);
      {
      let v397_2: Space = routine_60(c, &v396_30_cursor.path()[v396_30_origin..(v396_30_origin + 1)], &v396_30_cursor.path()[v396_30_origin..(v396_30_origin + 1)], &(*p2), &(*p3), &(*p0), &(*p4), &v396_30_cursor, &(*s0));
      join_wrapped_into(&mut v396_30_write,&((v397_2).read_zipper()),&[]);
      }
      v396_30_cursor.ascend(1);
    }
    drop(v396_30_cursor);
    drop(v396_30_write);
    drop(v396_29);
    compose(&(v390_25),&(v396_30))
  };
  drop(v390_25);
  let v390_32: Space = unite(&(v390_22),&(v390_31));
  (v390_32).clone()
}

fn routine_50(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v398_7: Space = singleton(&(*p0));
  let v398_8: Space = intersect(&(*CONSTANT_3),&(v398_7));
  let v398_9: Space = if has_head(&(v398_8)) { singleton(&[]) } else { Space::new() };
  drop(v398_8);
  let v398_10: Space = subtract(&(*CONSTANT_0),&(v398_9));
  drop(v398_9);
  let v398_15: Space = intersect(&(*CONSTANT_3),&(v398_7));
  drop(v398_7);
  let v398_16: Space = if has_head(&(v398_15)) { singleton(&[]) } else { Space::new() };
  drop(v398_15);
  let mut v398_17 = Space::new();
  let mut v398_17_write = v398_17.write_zipper();
  let mut v398_17_cursor = (*s0).read_zipper();
  let v398_17_origin = v398_17_cursor.path().len();
  for v398_17_byte in v398_17_cursor.child_mask().iter() {
    v398_17_cursor.descend_to_existing_byte(v398_17_byte);
    {
    let v399_4: Space = if (&(v398_10)).is_empty() { Space::new() } else {
      let v400_2: Path = concat_path(&(*p1),&v398_17_cursor.path()[v398_17_origin..(v398_17_origin + 1)]);
      let mut v400_3 = Space::new();
      let mut v400_3_write = v400_3.write_zipper();
      let v400_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v400_3_arg_1: &[u8] = &(v400_2);
      let v400_3_arg_2: &[u8] = &(*p2);
      let v400_3_arg_3: &[u8] = &(*p3);
      let v400_3_arg_5: &Space = &(&v398_17_cursor).make_map();
      let mut v400_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v400_3_origin = v400_3_cursor.path().len();
      let mut v400_3_more = v400_3_cursor.is_val() || next_value_within(&mut v400_3_cursor,v400_3_origin);
      while v400_3_more {
        {
        let v400_3_depth = v400_3_cursor.path().len();
        let v401_6: Space = routine_50(c, &v400_3_cursor.path()[v400_3_origin..v400_3_depth], &(*v400_3_arg_1), &(*v400_3_arg_2), &(*v400_3_arg_3), &((*v400_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v400_3_write,&((v401_6).read_zipper()),&[]);
        }
        v400_3_more = next_value_within(&mut v400_3_cursor,v400_3_origin);
      }
      drop(v400_3_cursor);
      drop(v400_3_write);
      compose(&(v398_10),&(v400_3))
    };
    let v399_6: Space = if (&(v398_16)).is_empty() { Space::new() } else {
      let v402_2: Path = concat_path(&(*p1),&v398_17_cursor.path()[v398_17_origin..(v398_17_origin + 1)]);
      let mut v402_5 = Space::new();
      let mut v402_5_write = v402_5.write_zipper();
      for v402_5_byte in v398_17_cursor.child_mask().iter() {
        v398_17_cursor.descend_to_existing_byte(v402_5_byte);
        {
        let v403_2: Space = routine_51(c, &v398_17_cursor.path()[(v398_17_origin + 1)..(v398_17_origin + 2)], &v398_17_cursor.path()[(v398_17_origin + 1)..(v398_17_origin + 2)], &(*p2), &(*p3), &(v402_2), &v398_17_cursor);
        join_wrapped_into(&mut v402_5_write,&((v403_2).read_zipper()),&[]);
        }
        v398_17_cursor.ascend(1);
      }
      drop(v402_5_write);
      drop(v402_2);
      compose(&(v398_16),&(v402_5))
    };
    let v399_7: Space = unite(&(v399_4),&(v399_6));
    join_wrapped_into(&mut v398_17_write,&((v399_7).read_zipper()),&[]);
    }
    v398_17_cursor.ascend(1);
  }
  drop(v398_17_cursor);
  drop(v398_17_write);
  drop(v398_10);
  drop(v398_16);
  (v398_17).clone()
}

fn routine_51(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v404_8: Space = singleton(&(*p1));
  let v404_9: Space = intersect(&(*CONSTANT_3),&(v404_8));
  let v404_10: Space = if has_head(&(v404_9)) { singleton(&[]) } else { Space::new() };
  drop(v404_9);
  let v404_11: Space = subtract(&(*CONSTANT_0),&(v404_10));
  drop(v404_10);
  let v404_22: Space = if (&(v404_11)).is_empty() { Space::new() } else {
    let v405_14: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v405_17: Space = if (&(v405_14)).is_empty() { Space::new() } else {
      let v406_16: Space = routine_61(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*s0));
      compose(&(v405_14),&(v406_16))
    };
    drop(v405_14);
    let mut v405_20 = Space::new();
    let mut v405_20_write = v405_20.write_zipper();
    let mut v405_20_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v405_20_origin = v405_20_cursor.path().len();
    for v405_20_byte in v405_20_cursor.child_mask().iter() {
      v405_20_cursor.descend_to_existing_byte(v405_20_byte);
      {
      let v407_2_arg_0: &[u8] = &v405_20_cursor.path()[v405_20_origin..(v405_20_origin + 1)];
      let v407_2_arg_1: &[u8] = &(*p0);
      let v407_2_arg_2: &[u8] = &(*p2);
      let v407_2_arg_3: &[u8] = &(*p3);
      let v407_2_arg_4: &[u8] = &(*p4);
      let v407_2_arg_6: &Space = &(&(*s0)).make_map();
      let mut v407_2_more = v405_20_cursor.is_val() || next_value_within(&mut v405_20_cursor,(v405_20_origin + 1));
      while v407_2_more {
        {
        let v407_2_depth = v405_20_cursor.path().len();
        let mut v408_7_cursor = (*v407_2_arg_6).read_zipper();
        let v408_7_origin = v408_7_cursor.path().len();
        for v408_7_byte in v408_7_cursor.child_mask().iter() {
          v408_7_cursor.descend_to_existing_byte(v408_7_byte);
          {
          let v409_2: Path = concat_path(&(*v407_2_arg_1),&v408_7_cursor.path()[v408_7_origin..(v408_7_origin + 1)]);
          let v409_3: Space = routine_51(c, &(v409_2), &v405_20_cursor.path()[v405_20_origin..v407_2_depth], &(*v407_2_arg_2), &(*v407_2_arg_3), &(*v407_2_arg_4), &v408_7_cursor);
          drop(v409_2);
          join_wrapped_into(&mut v405_20_write,&((v409_3).read_zipper()),&[]);
          }
          v408_7_cursor.ascend(1);
        }
        drop(v408_7_cursor);
        }
        v407_2_more = next_value_within(&mut v405_20_cursor,(v405_20_origin + 1));
      }
      }
      v405_20_cursor.ascend(1);
    }
    drop(v405_20_cursor);
    drop(v405_20_write);
    let v405_21: Space = unite(&(v405_17),&(v405_20));
    compose(&(v404_11),&(v405_21))
  };
  drop(v404_11);
  let v404_24: Space = intersect(&(*CONSTANT_3),&(v404_8));
  drop(v404_8);
  let v404_25: Space = if has_head(&(v404_24)) { singleton(&[]) } else { Space::new() };
  drop(v404_24);
  let v404_27: Space = if (&(v404_25)).is_empty() { Space::new() } else {
    let mut v410_26 = Space::new();
    let mut v410_26_write = v410_26.write_zipper();
    let mut v410_26_cursor = (*s0).read_zipper();
    let v410_26_origin = v410_26_cursor.path().len();
    for v410_26_byte in v410_26_cursor.child_mask().iter() {
      v410_26_cursor.descend_to_existing_byte(v410_26_byte);
      {
      let v411_2: Space = routine_62(c, &v410_26_cursor.path()[v410_26_origin..(v410_26_origin + 1)], &v410_26_cursor.path()[v410_26_origin..(v410_26_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p0), &v410_26_cursor);
      join_wrapped_into(&mut v410_26_write,&((v411_2).read_zipper()),&[]);
      }
      v410_26_cursor.ascend(1);
    }
    drop(v410_26_cursor);
    drop(v410_26_write);
    compose(&(v404_25),&(v410_26))
  };
  drop(v404_25);
  let v404_28: Space = unite(&(v404_22),&(v404_27));
  (v404_28).clone()
}

fn routine_52(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v412_7: Space = singleton(&(*p0));
  let v412_8: Space = intersect(&(*CONSTANT_3),&(v412_7));
  let v412_9: Space = if has_head(&(v412_8)) { singleton(&[]) } else { Space::new() };
  drop(v412_8);
  let v412_10: Space = subtract(&(*CONSTANT_0),&(v412_9));
  drop(v412_9);
  let v412_15: Space = intersect(&(*CONSTANT_3),&(v412_7));
  drop(v412_7);
  let v412_16: Space = if has_head(&(v412_15)) { singleton(&[]) } else { Space::new() };
  drop(v412_15);
  let mut v412_17 = Space::new();
  let mut v412_17_write = v412_17.write_zipper();
  let mut v412_17_cursor = (*s0).read_zipper();
  let v412_17_origin = v412_17_cursor.path().len();
  for v412_17_byte in v412_17_cursor.child_mask().iter() {
    v412_17_cursor.descend_to_existing_byte(v412_17_byte);
    {
    let v413_4: Space = if (&(v412_10)).is_empty() { Space::new() } else {
      let v414_2: Path = concat_path(&(*p1),&v412_17_cursor.path()[v412_17_origin..(v412_17_origin + 1)]);
      let mut v414_3 = Space::new();
      let mut v414_3_write = v414_3.write_zipper();
      let v414_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v414_3_arg_1: &[u8] = &(v414_2);
      let v414_3_arg_2: &[u8] = &(*p2);
      let v414_3_arg_3: &[u8] = &(*p3);
      let v414_3_arg_5: &Space = &(&v412_17_cursor).make_map();
      let mut v414_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v414_3_origin = v414_3_cursor.path().len();
      let mut v414_3_more = v414_3_cursor.is_val() || next_value_within(&mut v414_3_cursor,v414_3_origin);
      while v414_3_more {
        {
        let v414_3_depth = v414_3_cursor.path().len();
        let v415_6: Space = routine_52(c, &v414_3_cursor.path()[v414_3_origin..v414_3_depth], &(*v414_3_arg_1), &(*v414_3_arg_2), &(*v414_3_arg_3), &((*v414_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v414_3_write,&((v415_6).read_zipper()),&[]);
        }
        v414_3_more = next_value_within(&mut v414_3_cursor,v414_3_origin);
      }
      drop(v414_3_cursor);
      drop(v414_3_write);
      compose(&(v412_10),&(v414_3))
    };
    let v413_6: Space = if (&(v412_16)).is_empty() { Space::new() } else {
      let v416_2: Path = concat_path(&(*p1),&v412_17_cursor.path()[v412_17_origin..(v412_17_origin + 1)]);
      let mut v416_5 = Space::new();
      let mut v416_5_write = v416_5.write_zipper();
      for v416_5_byte in v412_17_cursor.child_mask().iter() {
        v412_17_cursor.descend_to_existing_byte(v416_5_byte);
        {
        let v417_2: Space = routine_53(c, &v412_17_cursor.path()[(v412_17_origin + 1)..(v412_17_origin + 2)], &v412_17_cursor.path()[(v412_17_origin + 1)..(v412_17_origin + 2)], &(*p2), &(*p3), &(v416_2), &v412_17_cursor);
        join_wrapped_into(&mut v416_5_write,&((v417_2).read_zipper()),&[]);
        }
        v412_17_cursor.ascend(1);
      }
      drop(v416_5_write);
      drop(v416_2);
      compose(&(v412_16),&(v416_5))
    };
    let v413_7: Space = unite(&(v413_4),&(v413_6));
    join_wrapped_into(&mut v412_17_write,&((v413_7).read_zipper()),&[]);
    }
    v412_17_cursor.ascend(1);
  }
  drop(v412_17_cursor);
  drop(v412_17_write);
  drop(v412_10);
  drop(v412_16);
  (v412_17).clone()
}

fn routine_53(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v418_8: Space = singleton(&(*p1));
  let v418_9: Space = intersect(&(*CONSTANT_3),&(v418_8));
  let v418_10: Space = if has_head(&(v418_9)) { singleton(&[]) } else { Space::new() };
  drop(v418_9);
  let v418_11: Space = subtract(&(*CONSTANT_0),&(v418_10));
  drop(v418_10);
  let v418_22: Space = if (&(v418_11)).is_empty() { Space::new() } else {
    let v419_14: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v419_17: Space = if (&(v419_14)).is_empty() { Space::new() } else {
      let v420_16: Space = routine_63(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*s0));
      compose(&(v419_14),&(v420_16))
    };
    drop(v419_14);
    let mut v419_20 = Space::new();
    let mut v419_20_write = v419_20.write_zipper();
    let mut v419_20_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v419_20_origin = v419_20_cursor.path().len();
    for v419_20_byte in v419_20_cursor.child_mask().iter() {
      v419_20_cursor.descend_to_existing_byte(v419_20_byte);
      {
      let v421_2_arg_0: &[u8] = &v419_20_cursor.path()[v419_20_origin..(v419_20_origin + 1)];
      let v421_2_arg_1: &[u8] = &(*p0);
      let v421_2_arg_2: &[u8] = &(*p2);
      let v421_2_arg_3: &[u8] = &(*p3);
      let v421_2_arg_4: &[u8] = &(*p4);
      let v421_2_arg_6: &Space = &(&(*s0)).make_map();
      let mut v421_2_more = v419_20_cursor.is_val() || next_value_within(&mut v419_20_cursor,(v419_20_origin + 1));
      while v421_2_more {
        {
        let v421_2_depth = v419_20_cursor.path().len();
        let mut v422_7_cursor = (*v421_2_arg_6).read_zipper();
        let v422_7_origin = v422_7_cursor.path().len();
        for v422_7_byte in v422_7_cursor.child_mask().iter() {
          v422_7_cursor.descend_to_existing_byte(v422_7_byte);
          {
          let v423_2: Path = concat_path(&(*v421_2_arg_1),&v422_7_cursor.path()[v422_7_origin..(v422_7_origin + 1)]);
          let v423_3: Space = routine_53(c, &(v423_2), &v419_20_cursor.path()[v419_20_origin..v421_2_depth], &(*v421_2_arg_2), &(*v421_2_arg_3), &(*v421_2_arg_4), &v422_7_cursor);
          drop(v423_2);
          join_wrapped_into(&mut v419_20_write,&((v423_3).read_zipper()),&[]);
          }
          v422_7_cursor.ascend(1);
        }
        drop(v422_7_cursor);
        }
        v421_2_more = next_value_within(&mut v419_20_cursor,(v419_20_origin + 1));
      }
      }
      v419_20_cursor.ascend(1);
    }
    drop(v419_20_cursor);
    drop(v419_20_write);
    let v419_21: Space = unite(&(v419_17),&(v419_20));
    compose(&(v418_11),&(v419_21))
  };
  drop(v418_11);
  let v418_24: Space = intersect(&(*CONSTANT_3),&(v418_8));
  drop(v418_8);
  let v418_25: Space = if has_head(&(v418_24)) { singleton(&[]) } else { Space::new() };
  drop(v418_24);
  let v418_27: Space = if (&(v418_25)).is_empty() { Space::new() } else {
    let mut v424_26 = Space::new();
    let mut v424_26_write = v424_26.write_zipper();
    let mut v424_26_cursor = (*s0).read_zipper();
    let v424_26_origin = v424_26_cursor.path().len();
    for v424_26_byte in v424_26_cursor.child_mask().iter() {
      v424_26_cursor.descend_to_existing_byte(v424_26_byte);
      {
      let v425_2: Space = routine_64(c, &v424_26_cursor.path()[v424_26_origin..(v424_26_origin + 1)], &v424_26_cursor.path()[v424_26_origin..(v424_26_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p0), &v424_26_cursor);
      join_wrapped_into(&mut v424_26_write,&((v425_2).read_zipper()),&[]);
      }
      v424_26_cursor.ascend(1);
    }
    drop(v424_26_cursor);
    drop(v424_26_write);
    compose(&(v418_25),&(v424_26))
  };
  drop(v418_25);
  let v418_28: Space = unite(&(v418_22),&(v418_27));
  (v418_28).clone()
}

fn routine_54(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v426_7: Space = singleton(&(*p0));
  let v426_8: Space = intersect(&(*CONSTANT_3),&(v426_7));
  let v426_9: Space = if has_head(&(v426_8)) { singleton(&[]) } else { Space::new() };
  drop(v426_8);
  let v426_10: Space = subtract(&(*CONSTANT_0),&(v426_9));
  drop(v426_9);
  let v426_15: Space = intersect(&(*CONSTANT_3),&(v426_7));
  drop(v426_7);
  let v426_16: Space = if has_head(&(v426_15)) { singleton(&[]) } else { Space::new() };
  drop(v426_15);
  let mut v426_17 = Space::new();
  let mut v426_17_write = v426_17.write_zipper();
  let mut v426_17_cursor = (*s0).read_zipper();
  let v426_17_origin = v426_17_cursor.path().len();
  for v426_17_byte in v426_17_cursor.child_mask().iter() {
    v426_17_cursor.descend_to_existing_byte(v426_17_byte);
    {
    let v427_4: Space = if (&(v426_10)).is_empty() { Space::new() } else {
      let v428_2: Path = concat_path(&(*p1),&v426_17_cursor.path()[v426_17_origin..(v426_17_origin + 1)]);
      let mut v428_3 = Space::new();
      let mut v428_3_write = v428_3.write_zipper();
      let v428_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v428_3_arg_1: &[u8] = &(v428_2);
      let v428_3_arg_2: &[u8] = &(*p2);
      let v428_3_arg_3: &[u8] = &(*p3);
      let v428_3_arg_5: &Space = &(&v426_17_cursor).make_map();
      let mut v428_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v428_3_origin = v428_3_cursor.path().len();
      let mut v428_3_more = v428_3_cursor.is_val() || next_value_within(&mut v428_3_cursor,v428_3_origin);
      while v428_3_more {
        {
        let v428_3_depth = v428_3_cursor.path().len();
        let v429_6: Space = routine_54(c, &v428_3_cursor.path()[v428_3_origin..v428_3_depth], &(*v428_3_arg_1), &(*v428_3_arg_2), &(*v428_3_arg_3), &((*v428_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v428_3_write,&((v429_6).read_zipper()),&[]);
        }
        v428_3_more = next_value_within(&mut v428_3_cursor,v428_3_origin);
      }
      drop(v428_3_cursor);
      drop(v428_3_write);
      compose(&(v426_10),&(v428_3))
    };
    let v427_6: Space = if (&(v426_16)).is_empty() { Space::new() } else {
      let v430_2: Path = concat_path(&(*p1),&v426_17_cursor.path()[v426_17_origin..(v426_17_origin + 1)]);
      let mut v430_5 = Space::new();
      let mut v430_5_write = v430_5.write_zipper();
      for v430_5_byte in v426_17_cursor.child_mask().iter() {
        v426_17_cursor.descend_to_existing_byte(v430_5_byte);
        {
        let v431_2: Space = routine_55(c, &v426_17_cursor.path()[(v426_17_origin + 1)..(v426_17_origin + 2)], &v426_17_cursor.path()[(v426_17_origin + 1)..(v426_17_origin + 2)], &(*p2), &(*p3), &(v430_2), &v426_17_cursor);
        join_wrapped_into(&mut v430_5_write,&((v431_2).read_zipper()),&[]);
        }
        v426_17_cursor.ascend(1);
      }
      drop(v430_5_write);
      drop(v430_2);
      compose(&(v426_16),&(v430_5))
    };
    let v427_7: Space = unite(&(v427_4),&(v427_6));
    join_wrapped_into(&mut v426_17_write,&((v427_7).read_zipper()),&[]);
    }
    v426_17_cursor.ascend(1);
  }
  drop(v426_17_cursor);
  drop(v426_17_write);
  drop(v426_10);
  drop(v426_16);
  (v426_17).clone()
}

fn routine_55(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v432_8: Space = singleton(&(*p1));
  let v432_9: Space = intersect(&(*CONSTANT_3),&(v432_8));
  let v432_10: Space = if has_head(&(v432_9)) { singleton(&[]) } else { Space::new() };
  drop(v432_9);
  let v432_11: Space = subtract(&(*CONSTANT_0),&(v432_10));
  drop(v432_10);
  let v432_22: Space = if (&(v432_11)).is_empty() { Space::new() } else {
    let v433_14: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v433_17: Space = if (&(v433_14)).is_empty() { Space::new() } else {
      let v434_16: Space = routine_65(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*s0));
      compose(&(v433_14),&(v434_16))
    };
    drop(v433_14);
    let mut v433_20 = Space::new();
    let mut v433_20_write = v433_20.write_zipper();
    let mut v433_20_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v433_20_origin = v433_20_cursor.path().len();
    for v433_20_byte in v433_20_cursor.child_mask().iter() {
      v433_20_cursor.descend_to_existing_byte(v433_20_byte);
      {
      let v435_2_arg_0: &[u8] = &v433_20_cursor.path()[v433_20_origin..(v433_20_origin + 1)];
      let v435_2_arg_1: &[u8] = &(*p0);
      let v435_2_arg_2: &[u8] = &(*p2);
      let v435_2_arg_3: &[u8] = &(*p3);
      let v435_2_arg_4: &[u8] = &(*p4);
      let v435_2_arg_6: &Space = &(&(*s0)).make_map();
      let mut v435_2_more = v433_20_cursor.is_val() || next_value_within(&mut v433_20_cursor,(v433_20_origin + 1));
      while v435_2_more {
        {
        let v435_2_depth = v433_20_cursor.path().len();
        let mut v436_7_cursor = (*v435_2_arg_6).read_zipper();
        let v436_7_origin = v436_7_cursor.path().len();
        for v436_7_byte in v436_7_cursor.child_mask().iter() {
          v436_7_cursor.descend_to_existing_byte(v436_7_byte);
          {
          let v437_2: Path = concat_path(&(*v435_2_arg_1),&v436_7_cursor.path()[v436_7_origin..(v436_7_origin + 1)]);
          let v437_3: Space = routine_55(c, &(v437_2), &v433_20_cursor.path()[v433_20_origin..v435_2_depth], &(*v435_2_arg_2), &(*v435_2_arg_3), &(*v435_2_arg_4), &v436_7_cursor);
          drop(v437_2);
          join_wrapped_into(&mut v433_20_write,&((v437_3).read_zipper()),&[]);
          }
          v436_7_cursor.ascend(1);
        }
        drop(v436_7_cursor);
        }
        v435_2_more = next_value_within(&mut v433_20_cursor,(v433_20_origin + 1));
      }
      }
      v433_20_cursor.ascend(1);
    }
    drop(v433_20_cursor);
    drop(v433_20_write);
    let v433_21: Space = unite(&(v433_17),&(v433_20));
    compose(&(v432_11),&(v433_21))
  };
  drop(v432_11);
  let v432_24: Space = intersect(&(*CONSTANT_3),&(v432_8));
  drop(v432_8);
  let v432_25: Space = if has_head(&(v432_24)) { singleton(&[]) } else { Space::new() };
  drop(v432_24);
  let v432_27: Space = if (&(v432_25)).is_empty() { Space::new() } else {
    let mut v438_26 = Space::new();
    let mut v438_26_write = v438_26.write_zipper();
    let mut v438_26_cursor = (*s0).read_zipper();
    let v438_26_origin = v438_26_cursor.path().len();
    for v438_26_byte in v438_26_cursor.child_mask().iter() {
      v438_26_cursor.descend_to_existing_byte(v438_26_byte);
      {
      let v439_2: Space = routine_66(c, &v438_26_cursor.path()[v438_26_origin..(v438_26_origin + 1)], &v438_26_cursor.path()[v438_26_origin..(v438_26_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p0), &v438_26_cursor);
      join_wrapped_into(&mut v438_26_write,&((v439_2).read_zipper()),&[]);
      }
      v438_26_cursor.ascend(1);
    }
    drop(v438_26_cursor);
    drop(v438_26_write);
    compose(&(v432_25),&(v438_26))
  };
  drop(v432_25);
  let v432_28: Space = unite(&(v432_22),&(v432_27));
  (v432_28).clone()
}

fn routine_56(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v440_7: Space = singleton(&(*p0));
  let v440_8: Space = intersect(&(*CONSTANT_3),&(v440_7));
  let v440_9: Space = if has_head(&(v440_8)) { singleton(&[]) } else { Space::new() };
  drop(v440_8);
  let v440_10: Space = subtract(&(*CONSTANT_0),&(v440_9));
  drop(v440_9);
  let v440_15: Space = intersect(&(*CONSTANT_3),&(v440_7));
  drop(v440_7);
  let v440_16: Space = if has_head(&(v440_15)) { singleton(&[]) } else { Space::new() };
  drop(v440_15);
  let mut v440_17 = Space::new();
  let mut v440_17_write = v440_17.write_zipper();
  let mut v440_17_cursor = (*s0).read_zipper();
  let v440_17_origin = v440_17_cursor.path().len();
  for v440_17_byte in v440_17_cursor.child_mask().iter() {
    v440_17_cursor.descend_to_existing_byte(v440_17_byte);
    {
    let v441_4: Space = if (&(v440_10)).is_empty() { Space::new() } else {
      let v442_2: Path = concat_path(&(*p1),&v440_17_cursor.path()[v440_17_origin..(v440_17_origin + 1)]);
      let mut v442_3 = Space::new();
      let mut v442_3_write = v442_3.write_zipper();
      let v442_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v442_3_arg_1: &[u8] = &(v442_2);
      let v442_3_arg_2: &[u8] = &(*p2);
      let v442_3_arg_3: &[u8] = &(*p3);
      let v442_3_arg_5: &Space = &(&v440_17_cursor).make_map();
      let mut v442_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v442_3_origin = v442_3_cursor.path().len();
      let mut v442_3_more = v442_3_cursor.is_val() || next_value_within(&mut v442_3_cursor,v442_3_origin);
      while v442_3_more {
        {
        let v442_3_depth = v442_3_cursor.path().len();
        let v443_6: Space = routine_56(c, &v442_3_cursor.path()[v442_3_origin..v442_3_depth], &(*v442_3_arg_1), &(*v442_3_arg_2), &(*v442_3_arg_3), &((*v442_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v442_3_write,&((v443_6).read_zipper()),&[]);
        }
        v442_3_more = next_value_within(&mut v442_3_cursor,v442_3_origin);
      }
      drop(v442_3_cursor);
      drop(v442_3_write);
      compose(&(v440_10),&(v442_3))
    };
    let v441_6: Space = if (&(v440_16)).is_empty() { Space::new() } else {
      let v444_2: Path = concat_path(&(*p1),&v440_17_cursor.path()[v440_17_origin..(v440_17_origin + 1)]);
      let mut v444_5 = Space::new();
      let mut v444_5_write = v444_5.write_zipper();
      for v444_5_byte in v440_17_cursor.child_mask().iter() {
        v440_17_cursor.descend_to_existing_byte(v444_5_byte);
        {
        let v445_2: Space = routine_57(c, &v440_17_cursor.path()[(v440_17_origin + 1)..(v440_17_origin + 2)], &v440_17_cursor.path()[(v440_17_origin + 1)..(v440_17_origin + 2)], &(*p2), &(*p3), &(v444_2), &v440_17_cursor);
        join_wrapped_into(&mut v444_5_write,&((v445_2).read_zipper()),&[]);
        }
        v440_17_cursor.ascend(1);
      }
      drop(v444_5_write);
      drop(v444_2);
      compose(&(v440_16),&(v444_5))
    };
    let v441_7: Space = unite(&(v441_4),&(v441_6));
    join_wrapped_into(&mut v440_17_write,&((v441_7).read_zipper()),&[]);
    }
    v440_17_cursor.ascend(1);
  }
  drop(v440_17_cursor);
  drop(v440_17_write);
  drop(v440_10);
  drop(v440_16);
  (v440_17).clone()
}

fn routine_57(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v446_8: Space = singleton(&(*p1));
  let v446_9: Space = intersect(&(*CONSTANT_3),&(v446_8));
  let v446_10: Space = if has_head(&(v446_9)) { singleton(&[]) } else { Space::new() };
  drop(v446_9);
  let v446_11: Space = subtract(&(*CONSTANT_0),&(v446_10));
  drop(v446_10);
  let v446_22: Space = if (&(v446_11)).is_empty() { Space::new() } else {
    let v447_14: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v447_17: Space = if (&(v447_14)).is_empty() { Space::new() } else {
      let v448_16: Space = routine_67(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*s0));
      compose(&(v447_14),&(v448_16))
    };
    drop(v447_14);
    let mut v447_20 = Space::new();
    let mut v447_20_write = v447_20.write_zipper();
    let mut v447_20_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v447_20_origin = v447_20_cursor.path().len();
    for v447_20_byte in v447_20_cursor.child_mask().iter() {
      v447_20_cursor.descend_to_existing_byte(v447_20_byte);
      {
      let v449_2_arg_0: &[u8] = &v447_20_cursor.path()[v447_20_origin..(v447_20_origin + 1)];
      let v449_2_arg_1: &[u8] = &(*p0);
      let v449_2_arg_2: &[u8] = &(*p2);
      let v449_2_arg_3: &[u8] = &(*p3);
      let v449_2_arg_4: &[u8] = &(*p4);
      let v449_2_arg_6: &Space = &(&(*s0)).make_map();
      let mut v449_2_more = v447_20_cursor.is_val() || next_value_within(&mut v447_20_cursor,(v447_20_origin + 1));
      while v449_2_more {
        {
        let v449_2_depth = v447_20_cursor.path().len();
        let mut v450_7_cursor = (*v449_2_arg_6).read_zipper();
        let v450_7_origin = v450_7_cursor.path().len();
        for v450_7_byte in v450_7_cursor.child_mask().iter() {
          v450_7_cursor.descend_to_existing_byte(v450_7_byte);
          {
          let v451_2: Path = concat_path(&(*v449_2_arg_1),&v450_7_cursor.path()[v450_7_origin..(v450_7_origin + 1)]);
          let v451_3: Space = routine_57(c, &(v451_2), &v447_20_cursor.path()[v447_20_origin..v449_2_depth], &(*v449_2_arg_2), &(*v449_2_arg_3), &(*v449_2_arg_4), &v450_7_cursor);
          drop(v451_2);
          join_wrapped_into(&mut v447_20_write,&((v451_3).read_zipper()),&[]);
          }
          v450_7_cursor.ascend(1);
        }
        drop(v450_7_cursor);
        }
        v449_2_more = next_value_within(&mut v447_20_cursor,(v447_20_origin + 1));
      }
      }
      v447_20_cursor.ascend(1);
    }
    drop(v447_20_cursor);
    drop(v447_20_write);
    let v447_21: Space = unite(&(v447_17),&(v447_20));
    compose(&(v446_11),&(v447_21))
  };
  drop(v446_11);
  let v446_24: Space = intersect(&(*CONSTANT_3),&(v446_8));
  drop(v446_8);
  let v446_25: Space = if has_head(&(v446_24)) { singleton(&[]) } else { Space::new() };
  drop(v446_24);
  let v446_27: Space = if (&(v446_25)).is_empty() { Space::new() } else {
    let mut v452_26 = Space::new();
    let mut v452_26_write = v452_26.write_zipper();
    let mut v452_26_cursor = (*s0).read_zipper();
    let v452_26_origin = v452_26_cursor.path().len();
    for v452_26_byte in v452_26_cursor.child_mask().iter() {
      v452_26_cursor.descend_to_existing_byte(v452_26_byte);
      {
      let v453_2: Space = routine_68(c, &v452_26_cursor.path()[v452_26_origin..(v452_26_origin + 1)], &v452_26_cursor.path()[v452_26_origin..(v452_26_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p0), &v452_26_cursor);
      join_wrapped_into(&mut v452_26_write,&((v453_2).read_zipper()),&[]);
      }
      v452_26_cursor.ascend(1);
    }
    drop(v452_26_cursor);
    drop(v452_26_write);
    compose(&(v446_25),&(v452_26))
  };
  drop(v446_25);
  let v446_28: Space = unite(&(v446_22),&(v446_27));
  (v446_28).clone()
}

fn routine_58(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v454_9: Space = singleton(&(*p0));
  let v454_10: Space = intersect(&(*CONSTANT_3),&(v454_9));
  let v454_11: Space = if has_head(&(v454_10)) { singleton(&[]) } else { Space::new() };
  drop(v454_10);
  let v454_12: Space = subtract(&(*CONSTANT_0),&(v454_11));
  drop(v454_11);
  let v454_17: Space = intersect(&(*CONSTANT_3),&(v454_9));
  drop(v454_9);
  let v454_18: Space = if has_head(&(v454_17)) { singleton(&[]) } else { Space::new() };
  drop(v454_17);
  let v454_21: Path = concat_path(&(*p4),&(*p2));
  let v454_22: Path = concat_path(&(v454_21),&(*p3));
  drop(v454_21);
  let mut v454_23 = Space::new();
  let mut v454_23_write = v454_23.write_zipper();
  let mut v454_23_cursor = (*s0).read_zipper();
  let v454_23_origin = v454_23_cursor.path().len();
  for v454_23_byte in v454_23_cursor.child_mask().iter() {
    v454_23_cursor.descend_to_existing_byte(v454_23_byte);
    {
    let v455_4: Space = if (&(v454_12)).is_empty() { Space::new() } else {
      let v456_2: Path = concat_path(&(*p1),&v454_23_cursor.path()[v454_23_origin..(v454_23_origin + 1)]);
      let mut v456_3 = Space::new();
      let mut v456_3_write = v456_3.write_zipper();
      let v456_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v456_3_arg_1: &[u8] = &(v456_2);
      let v456_3_arg_2: &[u8] = &(*p2);
      let v456_3_arg_3: &[u8] = &(*p3);
      let v456_3_arg_4: &[u8] = &(*p4);
      let v456_3_arg_6: &Space = &(&v454_23_cursor).make_map();
      let v456_3_arg_7: &Space = &(&(*s1)).make_map();
      let mut v456_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v456_3_origin = v456_3_cursor.path().len();
      let mut v456_3_more = v456_3_cursor.is_val() || next_value_within(&mut v456_3_cursor,v456_3_origin);
      while v456_3_more {
        {
        let v456_3_depth = v456_3_cursor.path().len();
        let v457_8: Space = routine_58(c, &v456_3_cursor.path()[v456_3_origin..v456_3_depth], &(*v456_3_arg_1), &(*v456_3_arg_2), &(*v456_3_arg_3), &(*v456_3_arg_4), &((*v456_3_arg_6).read_zipper()), &((*v456_3_arg_7).read_zipper()));
        join_wrapped_into(&mut v456_3_write,&((v457_8).read_zipper()),&[]);
        }
        v456_3_more = next_value_within(&mut v456_3_cursor,v456_3_origin);
      }
      drop(v456_3_cursor);
      drop(v456_3_write);
      compose(&(v454_12),&(v456_3))
    };
    let v455_7: Space = if (&(v454_18)).is_empty() { Space::new() } else {
      let v458_2: Path = concat_path(&(*p1),&v454_23_cursor.path()[v454_23_origin..(v454_23_origin + 1)]);
      let v458_5: Space = routine_43(c, &(v458_2), &(*CONSTANT_13), &(*CONSTANT_11));
      let v458_6: Space = unite(&(*s1),&(v458_5));
      compose(&(v454_18),&(v458_6))
    };
    let v455_8: Space = wrap(&(v455_7),&(v454_22));
    let v459_2: Path = concat_path(&(*p1),&v454_23_cursor.path()[v454_23_origin..(v454_23_origin + 1)]);
    let v455_9: Space = wrap(&(v455_8),&(v459_2));
    let v455_10: Space = unite(&(v455_4),&(v455_9));
    join_wrapped_into(&mut v454_23_write,&((v455_10).read_zipper()),&[]);
    }
    v454_23_cursor.ascend(1);
  }
  drop(v454_23_cursor);
  drop(v454_23_write);
  drop(v454_12);
  drop(v454_18);
  drop(v454_22);
  (v454_23).clone()
}

fn routine_59(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v460_8: Space = singleton(&(*p0));
  let v460_9: Space = intersect(&(*CONSTANT_3),&(v460_8));
  let v460_10: Space = if has_head(&(v460_9)) { singleton(&[]) } else { Space::new() };
  drop(v460_9);
  let v460_11: Space = subtract(&(*CONSTANT_0),&(v460_10));
  drop(v460_10);
  let v460_16: Space = intersect(&(*CONSTANT_3),&(v460_8));
  drop(v460_8);
  let v460_17: Space = if has_head(&(v460_16)) { singleton(&[]) } else { Space::new() };
  drop(v460_16);
  let mut v460_20 = Space::new();
  let mut v460_20_write = v460_20.write_zipper();
  let mut v460_20_cursor = (*s0).read_zipper();
  let v460_20_origin = v460_20_cursor.path().len();
  for v460_20_byte in v460_20_cursor.child_mask().iter() {
    v460_20_cursor.descend_to_existing_byte(v460_20_byte);
    {
    let v461_4: Space = if (&(v460_11)).is_empty() { Space::new() } else {
      let v462_2: Path = concat_path(&(*p1),&v460_20_cursor.path()[v460_20_origin..(v460_20_origin + 1)]);
      let mut v462_3 = Space::new();
      let mut v462_3_write = v462_3.write_zipper();
      let v462_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v462_3_arg_1: &[u8] = &(v462_2);
      let v462_3_arg_2: &[u8] = &(*p2);
      let v462_3_arg_3: &[u8] = &(*p3);
      let v462_3_arg_4: &[u8] = &(*p4);
      let v462_3_arg_6: &Space = &(&v460_20_cursor).make_map();
      let mut v462_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v462_3_origin = v462_3_cursor.path().len();
      let mut v462_3_more = v462_3_cursor.is_val() || next_value_within(&mut v462_3_cursor,v462_3_origin);
      while v462_3_more {
        {
        let v462_3_depth = v462_3_cursor.path().len();
        let v463_7: Space = routine_59(c, &v462_3_cursor.path()[v462_3_origin..v462_3_depth], &(*v462_3_arg_1), &(*v462_3_arg_2), &(*v462_3_arg_3), &(*v462_3_arg_4), &((*v462_3_arg_6).read_zipper()));
        join_wrapped_into(&mut v462_3_write,&((v463_7).read_zipper()),&[]);
        }
        v462_3_more = next_value_within(&mut v462_3_cursor,v462_3_origin);
      }
      drop(v462_3_cursor);
      drop(v462_3_write);
      compose(&(v460_11),&(v462_3))
    };
    let v461_8: Space = if (&(v460_17)).is_empty() { Space::new() } else {
      let v464_2: Path = concat_path(&(*p1),&v460_20_cursor.path()[v460_20_origin..(v460_20_origin + 1)]);
      let v464_6: Space = subtract(&(*CONSTANT_6),&(descend_cursor(cursor_at(&v460_20_cursor,(v460_20_origin + 1)),&(*CONSTANT_15))));
      let mut v464_7 = Space::new();
      let mut v464_7_write = v464_7.write_zipper();
      let mut v464_7_cursor = (v464_6).read_zipper();
      let v464_7_origin = v464_7_cursor.path().len();
      for v464_7_byte in v464_7_cursor.child_mask().iter() {
        v464_7_cursor.descend_to_existing_byte(v464_7_byte);
        {
        let v465_2: Space = routine_60(c, &v464_7_cursor.path()[v464_7_origin..(v464_7_origin + 1)], &v464_7_cursor.path()[v464_7_origin..(v464_7_origin + 1)], &(*p2), &(*p3), &(v464_2), &(*p4), &v464_7_cursor, &v460_20_cursor);
        join_wrapped_into(&mut v464_7_write,&((v465_2).read_zipper()),&[]);
        }
        v464_7_cursor.ascend(1);
      }
      drop(v464_7_cursor);
      drop(v464_7_write);
      drop(v464_2);
      drop(v464_6);
      compose(&(v460_17),&(v464_7))
    };
    let v461_9: Space = unite(&(v461_4),&(v461_8));
    join_wrapped_into(&mut v460_20_write,&((v461_9).read_zipper()),&[]);
    }
    v460_20_cursor.ascend(1);
  }
  drop(v460_20_cursor);
  drop(v460_20_write);
  drop(v460_11);
  drop(v460_17);
  (v460_20).clone()
}

fn routine_60(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v466_10: Space = singleton(&(*p1));
  let v466_11: Space = intersect(&(*CONSTANT_3),&(v466_10));
  let v466_12: Space = if has_head(&(v466_11)) { singleton(&[]) } else { Space::new() };
  drop(v466_11);
  let v466_13: Space = subtract(&(*CONSTANT_0),&(v466_12));
  drop(v466_12);
  let v466_24: Space = if (&(v466_13)).is_empty() { Space::new() } else {
    let v467_16: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v467_19: Space = if (&(v467_16)).is_empty() { Space::new() } else {
      let v468_18: Space = routine_69(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*s0), &(*s1));
      compose(&(v467_16),&(v468_18))
    };
    drop(v467_16);
    let mut v467_22 = Space::new();
    let mut v467_22_write = v467_22.write_zipper();
    let mut v467_22_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v467_22_origin = v467_22_cursor.path().len();
    for v467_22_byte in v467_22_cursor.child_mask().iter() {
      v467_22_cursor.descend_to_existing_byte(v467_22_byte);
      {
      let v469_2_arg_0: &[u8] = &v467_22_cursor.path()[v467_22_origin..(v467_22_origin + 1)];
      let v469_2_arg_1: &[u8] = &(*p0);
      let v469_2_arg_2: &[u8] = &(*p2);
      let v469_2_arg_3: &[u8] = &(*p3);
      let v469_2_arg_4: &[u8] = &(*p4);
      let v469_2_arg_5: &[u8] = &(*p5);
      let v469_2_arg_7: &Space = &(&(*s0)).make_map();
      let v469_2_arg_8: &Space = &(&(*s1)).make_map();
      let mut v469_2_more = v467_22_cursor.is_val() || next_value_within(&mut v467_22_cursor,(v467_22_origin + 1));
      while v469_2_more {
        {
        let v469_2_depth = v467_22_cursor.path().len();
        let mut v470_9_cursor = (*v469_2_arg_7).read_zipper();
        let v470_9_origin = v470_9_cursor.path().len();
        for v470_9_byte in v470_9_cursor.child_mask().iter() {
          v470_9_cursor.descend_to_existing_byte(v470_9_byte);
          {
          let v471_2: Path = concat_path(&(*v469_2_arg_1),&v470_9_cursor.path()[v470_9_origin..(v470_9_origin + 1)]);
          let v471_3: Space = routine_60(c, &(v471_2), &v467_22_cursor.path()[v467_22_origin..v469_2_depth], &(*v469_2_arg_2), &(*v469_2_arg_3), &(*v469_2_arg_4), &(*v469_2_arg_5), &v470_9_cursor, &((*v469_2_arg_8).read_zipper()));
          drop(v471_2);
          join_wrapped_into(&mut v467_22_write,&((v471_3).read_zipper()),&[]);
          }
          v470_9_cursor.ascend(1);
        }
        drop(v470_9_cursor);
        }
        v469_2_more = next_value_within(&mut v467_22_cursor,(v467_22_origin + 1));
      }
      }
      v467_22_cursor.ascend(1);
    }
    drop(v467_22_cursor);
    drop(v467_22_write);
    let v467_23: Space = unite(&(v467_19),&(v467_22));
    compose(&(v466_13),&(v467_23))
  };
  drop(v466_13);
  let v466_26: Space = intersect(&(*CONSTANT_3),&(v466_10));
  drop(v466_10);
  let v466_27: Space = if has_head(&(v466_26)) { singleton(&[]) } else { Space::new() };
  drop(v466_26);
  let v466_35: Space = if (&(v466_27)).is_empty() { Space::new() } else {
    let v472_32: Space = routine_19(c, &(*CONSTANT_2), &(*CONSTANT_2), &(*CONSTANT_15), &(*p0), &((*CONSTANT_4).read_zipper()));
    let v472_33: Space = intersect(&(*CONSTANT_8),&(v472_32));
    let v472_34: Space = unite(&(v472_33),&(*s1));
    compose(&(v466_27),&(v472_34))
  };
  drop(v466_27);
  let v466_36: Path = concat_path(&(*p5),&(*p2));
  let v466_37: Path = concat_path(&(v466_36),&(*p3));
  drop(v466_36);
  let v466_38: Path = concat_path(&(v466_37),&(*p4));
  drop(v466_37);
  let v466_39: Space = wrap(&(v466_35),&(v466_38));
  drop(v466_38);
  let v466_40: Space = wrap(&(v466_39),&(*p0));
  let v466_41: Space = unite(&(v466_24),&(v466_40));
  (v466_41).clone()
}

fn routine_61(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v473_8: Space = singleton(&(*p0));
  let v473_9: Space = intersect(&(*CONSTANT_3),&(v473_8));
  let v473_10: Space = if has_head(&(v473_9)) { singleton(&[]) } else { Space::new() };
  drop(v473_9);
  let v473_11: Space = subtract(&(*CONSTANT_0),&(v473_10));
  drop(v473_10);
  let v473_16: Space = intersect(&(*CONSTANT_3),&(v473_8));
  drop(v473_8);
  let v473_17: Space = if has_head(&(v473_16)) { singleton(&[]) } else { Space::new() };
  drop(v473_16);
  let mut v473_18 = Space::new();
  let mut v473_18_write = v473_18.write_zipper();
  let mut v473_18_cursor = (*s0).read_zipper();
  let v473_18_origin = v473_18_cursor.path().len();
  for v473_18_byte in v473_18_cursor.child_mask().iter() {
    v473_18_cursor.descend_to_existing_byte(v473_18_byte);
    {
    let v474_4: Space = if (&(v473_11)).is_empty() { Space::new() } else {
      let v475_2: Path = concat_path(&(*p1),&v473_18_cursor.path()[v473_18_origin..(v473_18_origin + 1)]);
      let mut v475_3 = Space::new();
      let mut v475_3_write = v475_3.write_zipper();
      let v475_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v475_3_arg_1: &[u8] = &(v475_2);
      let v475_3_arg_2: &[u8] = &(*p2);
      let v475_3_arg_3: &[u8] = &(*p3);
      let v475_3_arg_4: &[u8] = &(*p4);
      let v475_3_arg_6: &Space = &(&v473_18_cursor).make_map();
      let mut v475_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v475_3_origin = v475_3_cursor.path().len();
      let mut v475_3_more = v475_3_cursor.is_val() || next_value_within(&mut v475_3_cursor,v475_3_origin);
      while v475_3_more {
        {
        let v475_3_depth = v475_3_cursor.path().len();
        let v476_7: Space = routine_61(c, &v475_3_cursor.path()[v475_3_origin..v475_3_depth], &(*v475_3_arg_1), &(*v475_3_arg_2), &(*v475_3_arg_3), &(*v475_3_arg_4), &((*v475_3_arg_6).read_zipper()));
        join_wrapped_into(&mut v475_3_write,&((v476_7).read_zipper()),&[]);
        }
        v475_3_more = next_value_within(&mut v475_3_cursor,v475_3_origin);
      }
      drop(v475_3_cursor);
      drop(v475_3_write);
      compose(&(v473_11),&(v475_3))
    };
    let v474_6: Space = if (&(v473_17)).is_empty() { Space::new() } else {
      let v477_2: Path = concat_path(&(*p1),&v473_18_cursor.path()[v473_18_origin..(v473_18_origin + 1)]);
      let mut v477_5 = Space::new();
      let mut v477_5_write = v477_5.write_zipper();
      for v477_5_byte in v473_18_cursor.child_mask().iter() {
        v473_18_cursor.descend_to_existing_byte(v477_5_byte);
        {
        let v478_2: Space = routine_62(c, &v473_18_cursor.path()[(v473_18_origin + 1)..(v473_18_origin + 2)], &v473_18_cursor.path()[(v473_18_origin + 1)..(v473_18_origin + 2)], &(*p2), &(*p3), &(*p4), &(v477_2), &v473_18_cursor);
        join_wrapped_into(&mut v477_5_write,&((v478_2).read_zipper()),&[]);
        }
        v473_18_cursor.ascend(1);
      }
      drop(v477_5_write);
      drop(v477_2);
      compose(&(v473_17),&(v477_5))
    };
    let v474_7: Space = unite(&(v474_4),&(v474_6));
    join_wrapped_into(&mut v473_18_write,&((v474_7).read_zipper()),&[]);
    }
    v473_18_cursor.ascend(1);
  }
  drop(v473_18_cursor);
  drop(v473_18_write);
  drop(v473_11);
  drop(v473_17);
  (v473_18).clone()
}

fn routine_62(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v479_9: Space = singleton(&(*p1));
  let v479_10: Space = intersect(&(*CONSTANT_3),&(v479_9));
  let v479_11: Space = if has_head(&(v479_10)) { singleton(&[]) } else { Space::new() };
  drop(v479_10);
  let v479_12: Space = subtract(&(*CONSTANT_0),&(v479_11));
  drop(v479_11);
  let v479_23: Space = if (&(v479_12)).is_empty() { Space::new() } else {
    let v480_15: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v480_18: Space = if (&(v480_15)).is_empty() { Space::new() } else {
      let v481_17: Space = routine_70(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*s0));
      compose(&(v480_15),&(v481_17))
    };
    drop(v480_15);
    let mut v480_21 = Space::new();
    let mut v480_21_write = v480_21.write_zipper();
    let mut v480_21_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v480_21_origin = v480_21_cursor.path().len();
    for v480_21_byte in v480_21_cursor.child_mask().iter() {
      v480_21_cursor.descend_to_existing_byte(v480_21_byte);
      {
      let v482_2_arg_0: &[u8] = &v480_21_cursor.path()[v480_21_origin..(v480_21_origin + 1)];
      let v482_2_arg_1: &[u8] = &(*p0);
      let v482_2_arg_2: &[u8] = &(*p2);
      let v482_2_arg_3: &[u8] = &(*p3);
      let v482_2_arg_4: &[u8] = &(*p4);
      let v482_2_arg_5: &[u8] = &(*p5);
      let v482_2_arg_7: &Space = &(&(*s0)).make_map();
      let mut v482_2_more = v480_21_cursor.is_val() || next_value_within(&mut v480_21_cursor,(v480_21_origin + 1));
      while v482_2_more {
        {
        let v482_2_depth = v480_21_cursor.path().len();
        let mut v483_8_cursor = (*v482_2_arg_7).read_zipper();
        let v483_8_origin = v483_8_cursor.path().len();
        for v483_8_byte in v483_8_cursor.child_mask().iter() {
          v483_8_cursor.descend_to_existing_byte(v483_8_byte);
          {
          let v484_2: Path = concat_path(&(*v482_2_arg_1),&v483_8_cursor.path()[v483_8_origin..(v483_8_origin + 1)]);
          let v484_3: Space = routine_62(c, &(v484_2), &v480_21_cursor.path()[v480_21_origin..v482_2_depth], &(*v482_2_arg_2), &(*v482_2_arg_3), &(*v482_2_arg_4), &(*v482_2_arg_5), &v483_8_cursor);
          drop(v484_2);
          join_wrapped_into(&mut v480_21_write,&((v484_3).read_zipper()),&[]);
          }
          v483_8_cursor.ascend(1);
        }
        drop(v483_8_cursor);
        }
        v482_2_more = next_value_within(&mut v480_21_cursor,(v480_21_origin + 1));
      }
      }
      v480_21_cursor.ascend(1);
    }
    drop(v480_21_cursor);
    drop(v480_21_write);
    let v480_22: Space = unite(&(v480_18),&(v480_21));
    compose(&(v479_12),&(v480_22))
  };
  drop(v479_12);
  let v479_25: Space = intersect(&(*CONSTANT_3),&(v479_9));
  drop(v479_9);
  let v479_26: Space = if has_head(&(v479_25)) { singleton(&[]) } else { Space::new() };
  drop(v479_25);
  let v479_32: Space = if (&(v479_26)).is_empty() { Space::new() } else {
    let v485_30: Space = subtract(&(*CONSTANT_6),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_16))));
    let mut v485_31 = Space::new();
    let mut v485_31_write = v485_31.write_zipper();
    let mut v485_31_cursor = (v485_30).read_zipper();
    let v485_31_origin = v485_31_cursor.path().len();
    for v485_31_byte in v485_31_cursor.child_mask().iter() {
      v485_31_cursor.descend_to_existing_byte(v485_31_byte);
      {
      let v486_2: Space = routine_71(c, &v485_31_cursor.path()[v485_31_origin..(v485_31_origin + 1)], &v485_31_cursor.path()[v485_31_origin..(v485_31_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v485_31_cursor, &(*s0));
      join_wrapped_into(&mut v485_31_write,&((v486_2).read_zipper()),&[]);
      }
      v485_31_cursor.ascend(1);
    }
    drop(v485_31_cursor);
    drop(v485_31_write);
    drop(v485_30);
    compose(&(v479_26),&(v485_31))
  };
  drop(v479_26);
  let v479_33: Space = unite(&(v479_23),&(v479_32));
  (v479_33).clone()
}

fn routine_63(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v487_8: Space = singleton(&(*p0));
  let v487_9: Space = intersect(&(*CONSTANT_3),&(v487_8));
  let v487_10: Space = if has_head(&(v487_9)) { singleton(&[]) } else { Space::new() };
  drop(v487_9);
  let v487_11: Space = subtract(&(*CONSTANT_0),&(v487_10));
  drop(v487_10);
  let v487_16: Space = intersect(&(*CONSTANT_3),&(v487_8));
  drop(v487_8);
  let v487_17: Space = if has_head(&(v487_16)) { singleton(&[]) } else { Space::new() };
  drop(v487_16);
  let mut v487_18 = Space::new();
  let mut v487_18_write = v487_18.write_zipper();
  let mut v487_18_cursor = (*s0).read_zipper();
  let v487_18_origin = v487_18_cursor.path().len();
  for v487_18_byte in v487_18_cursor.child_mask().iter() {
    v487_18_cursor.descend_to_existing_byte(v487_18_byte);
    {
    let v488_4: Space = if (&(v487_11)).is_empty() { Space::new() } else {
      let v489_2: Path = concat_path(&(*p1),&v487_18_cursor.path()[v487_18_origin..(v487_18_origin + 1)]);
      let mut v489_3 = Space::new();
      let mut v489_3_write = v489_3.write_zipper();
      let v489_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v489_3_arg_1: &[u8] = &(v489_2);
      let v489_3_arg_2: &[u8] = &(*p2);
      let v489_3_arg_3: &[u8] = &(*p3);
      let v489_3_arg_4: &[u8] = &(*p4);
      let v489_3_arg_6: &Space = &(&v487_18_cursor).make_map();
      let mut v489_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v489_3_origin = v489_3_cursor.path().len();
      let mut v489_3_more = v489_3_cursor.is_val() || next_value_within(&mut v489_3_cursor,v489_3_origin);
      while v489_3_more {
        {
        let v489_3_depth = v489_3_cursor.path().len();
        let v490_7: Space = routine_63(c, &v489_3_cursor.path()[v489_3_origin..v489_3_depth], &(*v489_3_arg_1), &(*v489_3_arg_2), &(*v489_3_arg_3), &(*v489_3_arg_4), &((*v489_3_arg_6).read_zipper()));
        join_wrapped_into(&mut v489_3_write,&((v490_7).read_zipper()),&[]);
        }
        v489_3_more = next_value_within(&mut v489_3_cursor,v489_3_origin);
      }
      drop(v489_3_cursor);
      drop(v489_3_write);
      compose(&(v487_11),&(v489_3))
    };
    let v488_6: Space = if (&(v487_17)).is_empty() { Space::new() } else {
      let v491_2: Path = concat_path(&(*p1),&v487_18_cursor.path()[v487_18_origin..(v487_18_origin + 1)]);
      let mut v491_5 = Space::new();
      let mut v491_5_write = v491_5.write_zipper();
      for v491_5_byte in v487_18_cursor.child_mask().iter() {
        v487_18_cursor.descend_to_existing_byte(v491_5_byte);
        {
        let v492_2: Space = routine_64(c, &v487_18_cursor.path()[(v487_18_origin + 1)..(v487_18_origin + 2)], &v487_18_cursor.path()[(v487_18_origin + 1)..(v487_18_origin + 2)], &(*p2), &(*p3), &(*p4), &(v491_2), &v487_18_cursor);
        join_wrapped_into(&mut v491_5_write,&((v492_2).read_zipper()),&[]);
        }
        v487_18_cursor.ascend(1);
      }
      drop(v491_5_write);
      drop(v491_2);
      compose(&(v487_17),&(v491_5))
    };
    let v488_7: Space = unite(&(v488_4),&(v488_6));
    join_wrapped_into(&mut v487_18_write,&((v488_7).read_zipper()),&[]);
    }
    v487_18_cursor.ascend(1);
  }
  drop(v487_18_cursor);
  drop(v487_18_write);
  drop(v487_11);
  drop(v487_17);
  (v487_18).clone()
}

fn routine_64(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v493_9: Space = singleton(&(*p1));
  let v493_10: Space = intersect(&(*CONSTANT_3),&(v493_9));
  let v493_11: Space = if has_head(&(v493_10)) { singleton(&[]) } else { Space::new() };
  drop(v493_10);
  let v493_12: Space = subtract(&(*CONSTANT_0),&(v493_11));
  drop(v493_11);
  let v493_23: Space = if (&(v493_12)).is_empty() { Space::new() } else {
    let v494_15: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v494_18: Space = if (&(v494_15)).is_empty() { Space::new() } else {
      let v495_17: Space = routine_72(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*s0));
      compose(&(v494_15),&(v495_17))
    };
    drop(v494_15);
    let mut v494_21 = Space::new();
    let mut v494_21_write = v494_21.write_zipper();
    let mut v494_21_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v494_21_origin = v494_21_cursor.path().len();
    for v494_21_byte in v494_21_cursor.child_mask().iter() {
      v494_21_cursor.descend_to_existing_byte(v494_21_byte);
      {
      let v496_2_arg_0: &[u8] = &v494_21_cursor.path()[v494_21_origin..(v494_21_origin + 1)];
      let v496_2_arg_1: &[u8] = &(*p0);
      let v496_2_arg_2: &[u8] = &(*p2);
      let v496_2_arg_3: &[u8] = &(*p3);
      let v496_2_arg_4: &[u8] = &(*p4);
      let v496_2_arg_5: &[u8] = &(*p5);
      let v496_2_arg_7: &Space = &(&(*s0)).make_map();
      let mut v496_2_more = v494_21_cursor.is_val() || next_value_within(&mut v494_21_cursor,(v494_21_origin + 1));
      while v496_2_more {
        {
        let v496_2_depth = v494_21_cursor.path().len();
        let mut v497_8_cursor = (*v496_2_arg_7).read_zipper();
        let v497_8_origin = v497_8_cursor.path().len();
        for v497_8_byte in v497_8_cursor.child_mask().iter() {
          v497_8_cursor.descend_to_existing_byte(v497_8_byte);
          {
          let v498_2: Path = concat_path(&(*v496_2_arg_1),&v497_8_cursor.path()[v497_8_origin..(v497_8_origin + 1)]);
          let v498_3: Space = routine_64(c, &(v498_2), &v494_21_cursor.path()[v494_21_origin..v496_2_depth], &(*v496_2_arg_2), &(*v496_2_arg_3), &(*v496_2_arg_4), &(*v496_2_arg_5), &v497_8_cursor);
          drop(v498_2);
          join_wrapped_into(&mut v494_21_write,&((v498_3).read_zipper()),&[]);
          }
          v497_8_cursor.ascend(1);
        }
        drop(v497_8_cursor);
        }
        v496_2_more = next_value_within(&mut v494_21_cursor,(v494_21_origin + 1));
      }
      }
      v494_21_cursor.ascend(1);
    }
    drop(v494_21_cursor);
    drop(v494_21_write);
    let v494_22: Space = unite(&(v494_18),&(v494_21));
    compose(&(v493_12),&(v494_22))
  };
  drop(v493_12);
  let v493_25: Space = intersect(&(*CONSTANT_3),&(v493_9));
  drop(v493_9);
  let v493_26: Space = if has_head(&(v493_25)) { singleton(&[]) } else { Space::new() };
  drop(v493_25);
  let v493_28: Space = if (&(v493_26)).is_empty() { Space::new() } else {
    let mut v499_27 = Space::new();
    let mut v499_27_write = v499_27.write_zipper();
    let mut v499_27_cursor = (*s0).read_zipper();
    let v499_27_origin = v499_27_cursor.path().len();
    for v499_27_byte in v499_27_cursor.child_mask().iter() {
      v499_27_cursor.descend_to_existing_byte(v499_27_byte);
      {
      let v500_2: Space = routine_73(c, &v499_27_cursor.path()[v499_27_origin..(v499_27_origin + 1)], &v499_27_cursor.path()[v499_27_origin..(v499_27_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v499_27_cursor);
      join_wrapped_into(&mut v499_27_write,&((v500_2).read_zipper()),&[]);
      }
      v499_27_cursor.ascend(1);
    }
    drop(v499_27_cursor);
    drop(v499_27_write);
    compose(&(v493_26),&(v499_27))
  };
  drop(v493_26);
  let v493_29: Space = unite(&(v493_23),&(v493_28));
  (v493_29).clone()
}

fn routine_65(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v501_8: Space = singleton(&(*p0));
  let v501_9: Space = intersect(&(*CONSTANT_3),&(v501_8));
  let v501_10: Space = if has_head(&(v501_9)) { singleton(&[]) } else { Space::new() };
  drop(v501_9);
  let v501_11: Space = subtract(&(*CONSTANT_0),&(v501_10));
  drop(v501_10);
  let v501_16: Space = intersect(&(*CONSTANT_3),&(v501_8));
  drop(v501_8);
  let v501_17: Space = if has_head(&(v501_16)) { singleton(&[]) } else { Space::new() };
  drop(v501_16);
  let mut v501_18 = Space::new();
  let mut v501_18_write = v501_18.write_zipper();
  let mut v501_18_cursor = (*s0).read_zipper();
  let v501_18_origin = v501_18_cursor.path().len();
  for v501_18_byte in v501_18_cursor.child_mask().iter() {
    v501_18_cursor.descend_to_existing_byte(v501_18_byte);
    {
    let v502_4: Space = if (&(v501_11)).is_empty() { Space::new() } else {
      let v503_2: Path = concat_path(&(*p1),&v501_18_cursor.path()[v501_18_origin..(v501_18_origin + 1)]);
      let mut v503_3 = Space::new();
      let mut v503_3_write = v503_3.write_zipper();
      let v503_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v503_3_arg_1: &[u8] = &(v503_2);
      let v503_3_arg_2: &[u8] = &(*p2);
      let v503_3_arg_3: &[u8] = &(*p3);
      let v503_3_arg_4: &[u8] = &(*p4);
      let v503_3_arg_6: &Space = &(&v501_18_cursor).make_map();
      let mut v503_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v503_3_origin = v503_3_cursor.path().len();
      let mut v503_3_more = v503_3_cursor.is_val() || next_value_within(&mut v503_3_cursor,v503_3_origin);
      while v503_3_more {
        {
        let v503_3_depth = v503_3_cursor.path().len();
        let v504_7: Space = routine_65(c, &v503_3_cursor.path()[v503_3_origin..v503_3_depth], &(*v503_3_arg_1), &(*v503_3_arg_2), &(*v503_3_arg_3), &(*v503_3_arg_4), &((*v503_3_arg_6).read_zipper()));
        join_wrapped_into(&mut v503_3_write,&((v504_7).read_zipper()),&[]);
        }
        v503_3_more = next_value_within(&mut v503_3_cursor,v503_3_origin);
      }
      drop(v503_3_cursor);
      drop(v503_3_write);
      compose(&(v501_11),&(v503_3))
    };
    let v502_6: Space = if (&(v501_17)).is_empty() { Space::new() } else {
      let v505_2: Path = concat_path(&(*p1),&v501_18_cursor.path()[v501_18_origin..(v501_18_origin + 1)]);
      let mut v505_5 = Space::new();
      let mut v505_5_write = v505_5.write_zipper();
      for v505_5_byte in v501_18_cursor.child_mask().iter() {
        v501_18_cursor.descend_to_existing_byte(v505_5_byte);
        {
        let v506_2: Space = routine_66(c, &v501_18_cursor.path()[(v501_18_origin + 1)..(v501_18_origin + 2)], &v501_18_cursor.path()[(v501_18_origin + 1)..(v501_18_origin + 2)], &(*p2), &(*p3), &(*p4), &(v505_2), &v501_18_cursor);
        join_wrapped_into(&mut v505_5_write,&((v506_2).read_zipper()),&[]);
        }
        v501_18_cursor.ascend(1);
      }
      drop(v505_5_write);
      drop(v505_2);
      compose(&(v501_17),&(v505_5))
    };
    let v502_7: Space = unite(&(v502_4),&(v502_6));
    join_wrapped_into(&mut v501_18_write,&((v502_7).read_zipper()),&[]);
    }
    v501_18_cursor.ascend(1);
  }
  drop(v501_18_cursor);
  drop(v501_18_write);
  drop(v501_11);
  drop(v501_17);
  (v501_18).clone()
}

fn routine_66(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v507_9: Space = singleton(&(*p1));
  let v507_10: Space = intersect(&(*CONSTANT_3),&(v507_9));
  let v507_11: Space = if has_head(&(v507_10)) { singleton(&[]) } else { Space::new() };
  drop(v507_10);
  let v507_12: Space = subtract(&(*CONSTANT_0),&(v507_11));
  drop(v507_11);
  let v507_23: Space = if (&(v507_12)).is_empty() { Space::new() } else {
    let v508_15: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v508_18: Space = if (&(v508_15)).is_empty() { Space::new() } else {
      let v509_17: Space = routine_74(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*s0));
      compose(&(v508_15),&(v509_17))
    };
    drop(v508_15);
    let mut v508_21 = Space::new();
    let mut v508_21_write = v508_21.write_zipper();
    let mut v508_21_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v508_21_origin = v508_21_cursor.path().len();
    for v508_21_byte in v508_21_cursor.child_mask().iter() {
      v508_21_cursor.descend_to_existing_byte(v508_21_byte);
      {
      let v510_2_arg_0: &[u8] = &v508_21_cursor.path()[v508_21_origin..(v508_21_origin + 1)];
      let v510_2_arg_1: &[u8] = &(*p0);
      let v510_2_arg_2: &[u8] = &(*p2);
      let v510_2_arg_3: &[u8] = &(*p3);
      let v510_2_arg_4: &[u8] = &(*p4);
      let v510_2_arg_5: &[u8] = &(*p5);
      let v510_2_arg_7: &Space = &(&(*s0)).make_map();
      let mut v510_2_more = v508_21_cursor.is_val() || next_value_within(&mut v508_21_cursor,(v508_21_origin + 1));
      while v510_2_more {
        {
        let v510_2_depth = v508_21_cursor.path().len();
        let mut v511_8_cursor = (*v510_2_arg_7).read_zipper();
        let v511_8_origin = v511_8_cursor.path().len();
        for v511_8_byte in v511_8_cursor.child_mask().iter() {
          v511_8_cursor.descend_to_existing_byte(v511_8_byte);
          {
          let v512_2: Path = concat_path(&(*v510_2_arg_1),&v511_8_cursor.path()[v511_8_origin..(v511_8_origin + 1)]);
          let v512_3: Space = routine_66(c, &(v512_2), &v508_21_cursor.path()[v508_21_origin..v510_2_depth], &(*v510_2_arg_2), &(*v510_2_arg_3), &(*v510_2_arg_4), &(*v510_2_arg_5), &v511_8_cursor);
          drop(v512_2);
          join_wrapped_into(&mut v508_21_write,&((v512_3).read_zipper()),&[]);
          }
          v511_8_cursor.ascend(1);
        }
        drop(v511_8_cursor);
        }
        v510_2_more = next_value_within(&mut v508_21_cursor,(v508_21_origin + 1));
      }
      }
      v508_21_cursor.ascend(1);
    }
    drop(v508_21_cursor);
    drop(v508_21_write);
    let v508_22: Space = unite(&(v508_18),&(v508_21));
    compose(&(v507_12),&(v508_22))
  };
  drop(v507_12);
  let v507_25: Space = intersect(&(*CONSTANT_3),&(v507_9));
  drop(v507_9);
  let v507_26: Space = if has_head(&(v507_25)) { singleton(&[]) } else { Space::new() };
  drop(v507_25);
  let v507_28: Space = if (&(v507_26)).is_empty() { Space::new() } else {
    let mut v513_27 = Space::new();
    let mut v513_27_write = v513_27.write_zipper();
    let mut v513_27_cursor = (*s0).read_zipper();
    let v513_27_origin = v513_27_cursor.path().len();
    for v513_27_byte in v513_27_cursor.child_mask().iter() {
      v513_27_cursor.descend_to_existing_byte(v513_27_byte);
      {
      let v514_2: Space = routine_75(c, &v513_27_cursor.path()[v513_27_origin..(v513_27_origin + 1)], &v513_27_cursor.path()[v513_27_origin..(v513_27_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v513_27_cursor);
      join_wrapped_into(&mut v513_27_write,&((v514_2).read_zipper()),&[]);
      }
      v513_27_cursor.ascend(1);
    }
    drop(v513_27_cursor);
    drop(v513_27_write);
    compose(&(v507_26),&(v513_27))
  };
  drop(v507_26);
  let v507_29: Space = unite(&(v507_23),&(v507_28));
  (v507_29).clone()
}

fn routine_67(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v515_8: Space = singleton(&(*p0));
  let v515_9: Space = intersect(&(*CONSTANT_3),&(v515_8));
  let v515_10: Space = if has_head(&(v515_9)) { singleton(&[]) } else { Space::new() };
  drop(v515_9);
  let v515_11: Space = subtract(&(*CONSTANT_0),&(v515_10));
  drop(v515_10);
  let v515_16: Space = intersect(&(*CONSTANT_3),&(v515_8));
  drop(v515_8);
  let v515_17: Space = if has_head(&(v515_16)) { singleton(&[]) } else { Space::new() };
  drop(v515_16);
  let mut v515_18 = Space::new();
  let mut v515_18_write = v515_18.write_zipper();
  let mut v515_18_cursor = (*s0).read_zipper();
  let v515_18_origin = v515_18_cursor.path().len();
  for v515_18_byte in v515_18_cursor.child_mask().iter() {
    v515_18_cursor.descend_to_existing_byte(v515_18_byte);
    {
    let v516_4: Space = if (&(v515_11)).is_empty() { Space::new() } else {
      let v517_2: Path = concat_path(&(*p1),&v515_18_cursor.path()[v515_18_origin..(v515_18_origin + 1)]);
      let mut v517_3 = Space::new();
      let mut v517_3_write = v517_3.write_zipper();
      let v517_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v517_3_arg_1: &[u8] = &(v517_2);
      let v517_3_arg_2: &[u8] = &(*p2);
      let v517_3_arg_3: &[u8] = &(*p3);
      let v517_3_arg_4: &[u8] = &(*p4);
      let v517_3_arg_6: &Space = &(&v515_18_cursor).make_map();
      let mut v517_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v517_3_origin = v517_3_cursor.path().len();
      let mut v517_3_more = v517_3_cursor.is_val() || next_value_within(&mut v517_3_cursor,v517_3_origin);
      while v517_3_more {
        {
        let v517_3_depth = v517_3_cursor.path().len();
        let v518_7: Space = routine_67(c, &v517_3_cursor.path()[v517_3_origin..v517_3_depth], &(*v517_3_arg_1), &(*v517_3_arg_2), &(*v517_3_arg_3), &(*v517_3_arg_4), &((*v517_3_arg_6).read_zipper()));
        join_wrapped_into(&mut v517_3_write,&((v518_7).read_zipper()),&[]);
        }
        v517_3_more = next_value_within(&mut v517_3_cursor,v517_3_origin);
      }
      drop(v517_3_cursor);
      drop(v517_3_write);
      compose(&(v515_11),&(v517_3))
    };
    let v516_6: Space = if (&(v515_17)).is_empty() { Space::new() } else {
      let v519_2: Path = concat_path(&(*p1),&v515_18_cursor.path()[v515_18_origin..(v515_18_origin + 1)]);
      let mut v519_5 = Space::new();
      let mut v519_5_write = v519_5.write_zipper();
      for v519_5_byte in v515_18_cursor.child_mask().iter() {
        v515_18_cursor.descend_to_existing_byte(v519_5_byte);
        {
        let v520_2: Space = routine_68(c, &v515_18_cursor.path()[(v515_18_origin + 1)..(v515_18_origin + 2)], &v515_18_cursor.path()[(v515_18_origin + 1)..(v515_18_origin + 2)], &(*p2), &(*p3), &(*p4), &(v519_2), &v515_18_cursor);
        join_wrapped_into(&mut v519_5_write,&((v520_2).read_zipper()),&[]);
        }
        v515_18_cursor.ascend(1);
      }
      drop(v519_5_write);
      drop(v519_2);
      compose(&(v515_17),&(v519_5))
    };
    let v516_7: Space = unite(&(v516_4),&(v516_6));
    join_wrapped_into(&mut v515_18_write,&((v516_7).read_zipper()),&[]);
    }
    v515_18_cursor.ascend(1);
  }
  drop(v515_18_cursor);
  drop(v515_18_write);
  drop(v515_11);
  drop(v515_17);
  (v515_18).clone()
}

fn routine_68(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v521_9: Space = singleton(&(*p1));
  let v521_10: Space = intersect(&(*CONSTANT_3),&(v521_9));
  let v521_11: Space = if has_head(&(v521_10)) { singleton(&[]) } else { Space::new() };
  drop(v521_10);
  let v521_12: Space = subtract(&(*CONSTANT_0),&(v521_11));
  drop(v521_11);
  let v521_23: Space = if (&(v521_12)).is_empty() { Space::new() } else {
    let v522_15: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v522_18: Space = if (&(v522_15)).is_empty() { Space::new() } else {
      let v523_17: Space = routine_76(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*s0));
      compose(&(v522_15),&(v523_17))
    };
    drop(v522_15);
    let mut v522_21 = Space::new();
    let mut v522_21_write = v522_21.write_zipper();
    let mut v522_21_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v522_21_origin = v522_21_cursor.path().len();
    for v522_21_byte in v522_21_cursor.child_mask().iter() {
      v522_21_cursor.descend_to_existing_byte(v522_21_byte);
      {
      let v524_2_arg_0: &[u8] = &v522_21_cursor.path()[v522_21_origin..(v522_21_origin + 1)];
      let v524_2_arg_1: &[u8] = &(*p0);
      let v524_2_arg_2: &[u8] = &(*p2);
      let v524_2_arg_3: &[u8] = &(*p3);
      let v524_2_arg_4: &[u8] = &(*p4);
      let v524_2_arg_5: &[u8] = &(*p5);
      let v524_2_arg_7: &Space = &(&(*s0)).make_map();
      let mut v524_2_more = v522_21_cursor.is_val() || next_value_within(&mut v522_21_cursor,(v522_21_origin + 1));
      while v524_2_more {
        {
        let v524_2_depth = v522_21_cursor.path().len();
        let mut v525_8_cursor = (*v524_2_arg_7).read_zipper();
        let v525_8_origin = v525_8_cursor.path().len();
        for v525_8_byte in v525_8_cursor.child_mask().iter() {
          v525_8_cursor.descend_to_existing_byte(v525_8_byte);
          {
          let v526_2: Path = concat_path(&(*v524_2_arg_1),&v525_8_cursor.path()[v525_8_origin..(v525_8_origin + 1)]);
          let v526_3: Space = routine_68(c, &(v526_2), &v522_21_cursor.path()[v522_21_origin..v524_2_depth], &(*v524_2_arg_2), &(*v524_2_arg_3), &(*v524_2_arg_4), &(*v524_2_arg_5), &v525_8_cursor);
          drop(v526_2);
          join_wrapped_into(&mut v522_21_write,&((v526_3).read_zipper()),&[]);
          }
          v525_8_cursor.ascend(1);
        }
        drop(v525_8_cursor);
        }
        v524_2_more = next_value_within(&mut v522_21_cursor,(v522_21_origin + 1));
      }
      }
      v522_21_cursor.ascend(1);
    }
    drop(v522_21_cursor);
    drop(v522_21_write);
    let v522_22: Space = unite(&(v522_18),&(v522_21));
    compose(&(v521_12),&(v522_22))
  };
  drop(v521_12);
  let v521_25: Space = intersect(&(*CONSTANT_3),&(v521_9));
  drop(v521_9);
  let v521_26: Space = if has_head(&(v521_25)) { singleton(&[]) } else { Space::new() };
  drop(v521_25);
  let v521_28: Space = if (&(v521_26)).is_empty() { Space::new() } else {
    let mut v527_27 = Space::new();
    let mut v527_27_write = v527_27.write_zipper();
    let mut v527_27_cursor = (*s0).read_zipper();
    let v527_27_origin = v527_27_cursor.path().len();
    for v527_27_byte in v527_27_cursor.child_mask().iter() {
      v527_27_cursor.descend_to_existing_byte(v527_27_byte);
      {
      let v528_2: Space = routine_77(c, &v527_27_cursor.path()[v527_27_origin..(v527_27_origin + 1)], &v527_27_cursor.path()[v527_27_origin..(v527_27_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v527_27_cursor);
      join_wrapped_into(&mut v527_27_write,&((v528_2).read_zipper()),&[]);
      }
      v527_27_cursor.ascend(1);
    }
    drop(v527_27_cursor);
    drop(v527_27_write);
    compose(&(v521_26),&(v527_27))
  };
  drop(v521_26);
  let v521_29: Space = unite(&(v521_23),&(v521_28));
  (v521_29).clone()
}

fn routine_69(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v529_10: Space = singleton(&(*p0));
  let v529_11: Space = intersect(&(*CONSTANT_3),&(v529_10));
  let v529_12: Space = if has_head(&(v529_11)) { singleton(&[]) } else { Space::new() };
  drop(v529_11);
  let v529_13: Space = subtract(&(*CONSTANT_0),&(v529_12));
  drop(v529_12);
  let v529_18: Space = intersect(&(*CONSTANT_3),&(v529_10));
  drop(v529_10);
  let v529_19: Space = if has_head(&(v529_18)) { singleton(&[]) } else { Space::new() };
  drop(v529_18);
  let v529_22: Path = concat_path(&(*p5),&(*p2));
  let v529_23: Path = concat_path(&(v529_22),&(*p3));
  drop(v529_22);
  let v529_24: Path = concat_path(&(v529_23),&(*p4));
  drop(v529_23);
  let mut v529_25 = Space::new();
  let mut v529_25_write = v529_25.write_zipper();
  let mut v529_25_cursor = (*s0).read_zipper();
  let v529_25_origin = v529_25_cursor.path().len();
  for v529_25_byte in v529_25_cursor.child_mask().iter() {
    v529_25_cursor.descend_to_existing_byte(v529_25_byte);
    {
    let v530_4: Space = if (&(v529_13)).is_empty() { Space::new() } else {
      let v531_2: Path = concat_path(&(*p1),&v529_25_cursor.path()[v529_25_origin..(v529_25_origin + 1)]);
      let mut v531_3 = Space::new();
      let mut v531_3_write = v531_3.write_zipper();
      let v531_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v531_3_arg_1: &[u8] = &(v531_2);
      let v531_3_arg_2: &[u8] = &(*p2);
      let v531_3_arg_3: &[u8] = &(*p3);
      let v531_3_arg_4: &[u8] = &(*p4);
      let v531_3_arg_5: &[u8] = &(*p5);
      let v531_3_arg_7: &Space = &(&v529_25_cursor).make_map();
      let v531_3_arg_8: &Space = &(&(*s1)).make_map();
      let mut v531_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v531_3_origin = v531_3_cursor.path().len();
      let mut v531_3_more = v531_3_cursor.is_val() || next_value_within(&mut v531_3_cursor,v531_3_origin);
      while v531_3_more {
        {
        let v531_3_depth = v531_3_cursor.path().len();
        let v532_9: Space = routine_69(c, &v531_3_cursor.path()[v531_3_origin..v531_3_depth], &(*v531_3_arg_1), &(*v531_3_arg_2), &(*v531_3_arg_3), &(*v531_3_arg_4), &(*v531_3_arg_5), &((*v531_3_arg_7).read_zipper()), &((*v531_3_arg_8).read_zipper()));
        join_wrapped_into(&mut v531_3_write,&((v532_9).read_zipper()),&[]);
        }
        v531_3_more = next_value_within(&mut v531_3_cursor,v531_3_origin);
      }
      drop(v531_3_cursor);
      drop(v531_3_write);
      compose(&(v529_13),&(v531_3))
    };
    let v530_7: Space = if (&(v529_19)).is_empty() { Space::new() } else {
      let v533_2: Path = concat_path(&(*p1),&v529_25_cursor.path()[v529_25_origin..(v529_25_origin + 1)]);
      let v533_5: Space = routine_43(c, &(v533_2), &(*CONSTANT_15), &(*CONSTANT_11));
      let v533_6: Space = unite(&(*s1),&(v533_5));
      compose(&(v529_19),&(v533_6))
    };
    let v530_8: Space = wrap(&(v530_7),&(v529_24));
    let v534_2: Path = concat_path(&(*p1),&v529_25_cursor.path()[v529_25_origin..(v529_25_origin + 1)]);
    let v530_9: Space = wrap(&(v530_8),&(v534_2));
    let v530_10: Space = unite(&(v530_4),&(v530_9));
    join_wrapped_into(&mut v529_25_write,&((v530_10).read_zipper()),&[]);
    }
    v529_25_cursor.ascend(1);
  }
  drop(v529_25_cursor);
  drop(v529_25_write);
  drop(v529_13);
  drop(v529_19);
  drop(v529_24);
  (v529_25).clone()
}

fn routine_70(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v535_9: Space = singleton(&(*p0));
  let v535_10: Space = intersect(&(*CONSTANT_3),&(v535_9));
  let v535_11: Space = if has_head(&(v535_10)) { singleton(&[]) } else { Space::new() };
  drop(v535_10);
  let v535_12: Space = subtract(&(*CONSTANT_0),&(v535_11));
  drop(v535_11);
  let v535_17: Space = intersect(&(*CONSTANT_3),&(v535_9));
  drop(v535_9);
  let v535_18: Space = if has_head(&(v535_17)) { singleton(&[]) } else { Space::new() };
  drop(v535_17);
  let mut v535_21 = Space::new();
  let mut v535_21_write = v535_21.write_zipper();
  let mut v535_21_cursor = (*s0).read_zipper();
  let v535_21_origin = v535_21_cursor.path().len();
  for v535_21_byte in v535_21_cursor.child_mask().iter() {
    v535_21_cursor.descend_to_existing_byte(v535_21_byte);
    {
    let v536_4: Space = if (&(v535_12)).is_empty() { Space::new() } else {
      let v537_2: Path = concat_path(&(*p1),&v535_21_cursor.path()[v535_21_origin..(v535_21_origin + 1)]);
      let mut v537_3 = Space::new();
      let mut v537_3_write = v537_3.write_zipper();
      let v537_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v537_3_arg_1: &[u8] = &(v537_2);
      let v537_3_arg_2: &[u8] = &(*p2);
      let v537_3_arg_3: &[u8] = &(*p3);
      let v537_3_arg_4: &[u8] = &(*p4);
      let v537_3_arg_5: &[u8] = &(*p5);
      let v537_3_arg_7: &Space = &(&v535_21_cursor).make_map();
      let mut v537_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v537_3_origin = v537_3_cursor.path().len();
      let mut v537_3_more = v537_3_cursor.is_val() || next_value_within(&mut v537_3_cursor,v537_3_origin);
      while v537_3_more {
        {
        let v537_3_depth = v537_3_cursor.path().len();
        let v538_8: Space = routine_70(c, &v537_3_cursor.path()[v537_3_origin..v537_3_depth], &(*v537_3_arg_1), &(*v537_3_arg_2), &(*v537_3_arg_3), &(*v537_3_arg_4), &(*v537_3_arg_5), &((*v537_3_arg_7).read_zipper()));
        join_wrapped_into(&mut v537_3_write,&((v538_8).read_zipper()),&[]);
        }
        v537_3_more = next_value_within(&mut v537_3_cursor,v537_3_origin);
      }
      drop(v537_3_cursor);
      drop(v537_3_write);
      compose(&(v535_12),&(v537_3))
    };
    let v536_8: Space = if (&(v535_18)).is_empty() { Space::new() } else {
      let v539_2: Path = concat_path(&(*p1),&v535_21_cursor.path()[v535_21_origin..(v535_21_origin + 1)]);
      let v539_6: Space = subtract(&(*CONSTANT_6),&(descend_cursor(cursor_at(&v535_21_cursor,(v535_21_origin + 1)),&(*CONSTANT_16))));
      let mut v539_7 = Space::new();
      let mut v539_7_write = v539_7.write_zipper();
      let mut v539_7_cursor = (v539_6).read_zipper();
      let v539_7_origin = v539_7_cursor.path().len();
      for v539_7_byte in v539_7_cursor.child_mask().iter() {
        v539_7_cursor.descend_to_existing_byte(v539_7_byte);
        {
        let v540_2: Space = routine_71(c, &v539_7_cursor.path()[v539_7_origin..(v539_7_origin + 1)], &v539_7_cursor.path()[v539_7_origin..(v539_7_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(v539_2), &v539_7_cursor, &v535_21_cursor);
        join_wrapped_into(&mut v539_7_write,&((v540_2).read_zipper()),&[]);
        }
        v539_7_cursor.ascend(1);
      }
      drop(v539_7_cursor);
      drop(v539_7_write);
      drop(v539_2);
      drop(v539_6);
      compose(&(v535_18),&(v539_7))
    };
    let v536_9: Space = unite(&(v536_4),&(v536_8));
    join_wrapped_into(&mut v535_21_write,&((v536_9).read_zipper()),&[]);
    }
    v535_21_cursor.ascend(1);
  }
  drop(v535_21_cursor);
  drop(v535_21_write);
  drop(v535_12);
  drop(v535_18);
  (v535_21).clone()
}

fn routine_71(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v541_11: Space = singleton(&(*p1));
  let v541_12: Space = intersect(&(*CONSTANT_3),&(v541_11));
  let v541_13: Space = if has_head(&(v541_12)) { singleton(&[]) } else { Space::new() };
  drop(v541_12);
  let v541_14: Space = subtract(&(*CONSTANT_0),&(v541_13));
  drop(v541_13);
  let v541_25: Space = if (&(v541_14)).is_empty() { Space::new() } else {
    let v542_17: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v542_20: Space = if (&(v542_17)).is_empty() { Space::new() } else {
      let v543_19: Space = routine_78(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*s0), &(*s1));
      compose(&(v542_17),&(v543_19))
    };
    drop(v542_17);
    let mut v542_23 = Space::new();
    let mut v542_23_write = v542_23.write_zipper();
    let mut v542_23_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v542_23_origin = v542_23_cursor.path().len();
    for v542_23_byte in v542_23_cursor.child_mask().iter() {
      v542_23_cursor.descend_to_existing_byte(v542_23_byte);
      {
      let v544_2_arg_0: &[u8] = &v542_23_cursor.path()[v542_23_origin..(v542_23_origin + 1)];
      let v544_2_arg_1: &[u8] = &(*p0);
      let v544_2_arg_2: &[u8] = &(*p2);
      let v544_2_arg_3: &[u8] = &(*p3);
      let v544_2_arg_4: &[u8] = &(*p4);
      let v544_2_arg_5: &[u8] = &(*p5);
      let v544_2_arg_6: &[u8] = &(*p6);
      let v544_2_arg_8: &Space = &(&(*s0)).make_map();
      let v544_2_arg_9: &Space = &(&(*s1)).make_map();
      let mut v544_2_more = v542_23_cursor.is_val() || next_value_within(&mut v542_23_cursor,(v542_23_origin + 1));
      while v544_2_more {
        {
        let v544_2_depth = v542_23_cursor.path().len();
        let mut v545_10_cursor = (*v544_2_arg_8).read_zipper();
        let v545_10_origin = v545_10_cursor.path().len();
        for v545_10_byte in v545_10_cursor.child_mask().iter() {
          v545_10_cursor.descend_to_existing_byte(v545_10_byte);
          {
          let v546_2: Path = concat_path(&(*v544_2_arg_1),&v545_10_cursor.path()[v545_10_origin..(v545_10_origin + 1)]);
          let v546_3: Space = routine_71(c, &(v546_2), &v542_23_cursor.path()[v542_23_origin..v544_2_depth], &(*v544_2_arg_2), &(*v544_2_arg_3), &(*v544_2_arg_4), &(*v544_2_arg_5), &(*v544_2_arg_6), &v545_10_cursor, &((*v544_2_arg_9).read_zipper()));
          drop(v546_2);
          join_wrapped_into(&mut v542_23_write,&((v546_3).read_zipper()),&[]);
          }
          v545_10_cursor.ascend(1);
        }
        drop(v545_10_cursor);
        }
        v544_2_more = next_value_within(&mut v542_23_cursor,(v542_23_origin + 1));
      }
      }
      v542_23_cursor.ascend(1);
    }
    drop(v542_23_cursor);
    drop(v542_23_write);
    let v542_24: Space = unite(&(v542_20),&(v542_23));
    compose(&(v541_14),&(v542_24))
  };
  drop(v541_14);
  let v541_27: Space = intersect(&(*CONSTANT_3),&(v541_11));
  drop(v541_11);
  let v541_28: Space = if has_head(&(v541_27)) { singleton(&[]) } else { Space::new() };
  drop(v541_27);
  let v541_36: Space = if (&(v541_28)).is_empty() { Space::new() } else {
    let v547_33: Space = routine_19(c, &(*CONSTANT_2), &(*CONSTANT_2), &(*CONSTANT_16), &(*p0), &((*CONSTANT_4).read_zipper()));
    let v547_34: Space = intersect(&(*CONSTANT_8),&(v547_33));
    let v547_35: Space = unite(&(v547_34),&(*s1));
    compose(&(v541_28),&(v547_35))
  };
  drop(v541_28);
  let v541_37: Path = concat_path(&(*p2),&(*p3));
  let v541_38: Path = concat_path(&(v541_37),&(*p4));
  drop(v541_37);
  let v541_39: Path = concat_path(&(v541_38),&(*p5));
  drop(v541_38);
  let v541_40: Path = concat_path(&(v541_39),&(*p6));
  drop(v541_39);
  let v541_41: Space = wrap(&(v541_36),&(v541_40));
  drop(v541_40);
  let v541_42: Space = wrap(&(v541_41),&(*p0));
  let v541_43: Space = unite(&(v541_25),&(v541_42));
  (v541_43).clone()
}

fn routine_72(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v548_9: Space = singleton(&(*p0));
  let v548_10: Space = intersect(&(*CONSTANT_3),&(v548_9));
  let v548_11: Space = if has_head(&(v548_10)) { singleton(&[]) } else { Space::new() };
  drop(v548_10);
  let v548_12: Space = subtract(&(*CONSTANT_0),&(v548_11));
  drop(v548_11);
  let v548_17: Space = intersect(&(*CONSTANT_3),&(v548_9));
  drop(v548_9);
  let v548_18: Space = if has_head(&(v548_17)) { singleton(&[]) } else { Space::new() };
  drop(v548_17);
  let mut v548_19 = Space::new();
  let mut v548_19_write = v548_19.write_zipper();
  let mut v548_19_cursor = (*s0).read_zipper();
  let v548_19_origin = v548_19_cursor.path().len();
  for v548_19_byte in v548_19_cursor.child_mask().iter() {
    v548_19_cursor.descend_to_existing_byte(v548_19_byte);
    {
    let v549_4: Space = if (&(v548_12)).is_empty() { Space::new() } else {
      let v550_2: Path = concat_path(&(*p1),&v548_19_cursor.path()[v548_19_origin..(v548_19_origin + 1)]);
      let mut v550_3 = Space::new();
      let mut v550_3_write = v550_3.write_zipper();
      let v550_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v550_3_arg_1: &[u8] = &(v550_2);
      let v550_3_arg_2: &[u8] = &(*p2);
      let v550_3_arg_3: &[u8] = &(*p3);
      let v550_3_arg_4: &[u8] = &(*p4);
      let v550_3_arg_5: &[u8] = &(*p5);
      let v550_3_arg_7: &Space = &(&v548_19_cursor).make_map();
      let mut v550_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v550_3_origin = v550_3_cursor.path().len();
      let mut v550_3_more = v550_3_cursor.is_val() || next_value_within(&mut v550_3_cursor,v550_3_origin);
      while v550_3_more {
        {
        let v550_3_depth = v550_3_cursor.path().len();
        let v551_8: Space = routine_72(c, &v550_3_cursor.path()[v550_3_origin..v550_3_depth], &(*v550_3_arg_1), &(*v550_3_arg_2), &(*v550_3_arg_3), &(*v550_3_arg_4), &(*v550_3_arg_5), &((*v550_3_arg_7).read_zipper()));
        join_wrapped_into(&mut v550_3_write,&((v551_8).read_zipper()),&[]);
        }
        v550_3_more = next_value_within(&mut v550_3_cursor,v550_3_origin);
      }
      drop(v550_3_cursor);
      drop(v550_3_write);
      compose(&(v548_12),&(v550_3))
    };
    let v549_6: Space = if (&(v548_18)).is_empty() { Space::new() } else {
      let v552_2: Path = concat_path(&(*p1),&v548_19_cursor.path()[v548_19_origin..(v548_19_origin + 1)]);
      let mut v552_5 = Space::new();
      let mut v552_5_write = v552_5.write_zipper();
      for v552_5_byte in v548_19_cursor.child_mask().iter() {
        v548_19_cursor.descend_to_existing_byte(v552_5_byte);
        {
        let v553_2: Space = routine_73(c, &v548_19_cursor.path()[(v548_19_origin + 1)..(v548_19_origin + 2)], &v548_19_cursor.path()[(v548_19_origin + 1)..(v548_19_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(v552_2), &v548_19_cursor);
        join_wrapped_into(&mut v552_5_write,&((v553_2).read_zipper()),&[]);
        }
        v548_19_cursor.ascend(1);
      }
      drop(v552_5_write);
      drop(v552_2);
      compose(&(v548_18),&(v552_5))
    };
    let v549_7: Space = unite(&(v549_4),&(v549_6));
    join_wrapped_into(&mut v548_19_write,&((v549_7).read_zipper()),&[]);
    }
    v548_19_cursor.ascend(1);
  }
  drop(v548_19_cursor);
  drop(v548_19_write);
  drop(v548_12);
  drop(v548_18);
  (v548_19).clone()
}

fn routine_73(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v554_10: Space = singleton(&(*p1));
  let v554_11: Space = intersect(&(*CONSTANT_3),&(v554_10));
  let v554_12: Space = if has_head(&(v554_11)) { singleton(&[]) } else { Space::new() };
  drop(v554_11);
  let v554_13: Space = subtract(&(*CONSTANT_0),&(v554_12));
  drop(v554_12);
  let v554_24: Space = if (&(v554_13)).is_empty() { Space::new() } else {
    let v555_16: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v555_19: Space = if (&(v555_16)).is_empty() { Space::new() } else {
      let v556_18: Space = routine_79(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*s0));
      compose(&(v555_16),&(v556_18))
    };
    drop(v555_16);
    let mut v555_22 = Space::new();
    let mut v555_22_write = v555_22.write_zipper();
    let mut v555_22_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v555_22_origin = v555_22_cursor.path().len();
    for v555_22_byte in v555_22_cursor.child_mask().iter() {
      v555_22_cursor.descend_to_existing_byte(v555_22_byte);
      {
      let v557_2_arg_0: &[u8] = &v555_22_cursor.path()[v555_22_origin..(v555_22_origin + 1)];
      let v557_2_arg_1: &[u8] = &(*p0);
      let v557_2_arg_2: &[u8] = &(*p2);
      let v557_2_arg_3: &[u8] = &(*p3);
      let v557_2_arg_4: &[u8] = &(*p4);
      let v557_2_arg_5: &[u8] = &(*p5);
      let v557_2_arg_6: &[u8] = &(*p6);
      let v557_2_arg_8: &Space = &(&(*s0)).make_map();
      let mut v557_2_more = v555_22_cursor.is_val() || next_value_within(&mut v555_22_cursor,(v555_22_origin + 1));
      while v557_2_more {
        {
        let v557_2_depth = v555_22_cursor.path().len();
        let mut v558_9_cursor = (*v557_2_arg_8).read_zipper();
        let v558_9_origin = v558_9_cursor.path().len();
        for v558_9_byte in v558_9_cursor.child_mask().iter() {
          v558_9_cursor.descend_to_existing_byte(v558_9_byte);
          {
          let v559_2: Path = concat_path(&(*v557_2_arg_1),&v558_9_cursor.path()[v558_9_origin..(v558_9_origin + 1)]);
          let v559_3: Space = routine_73(c, &(v559_2), &v555_22_cursor.path()[v555_22_origin..v557_2_depth], &(*v557_2_arg_2), &(*v557_2_arg_3), &(*v557_2_arg_4), &(*v557_2_arg_5), &(*v557_2_arg_6), &v558_9_cursor);
          drop(v559_2);
          join_wrapped_into(&mut v555_22_write,&((v559_3).read_zipper()),&[]);
          }
          v558_9_cursor.ascend(1);
        }
        drop(v558_9_cursor);
        }
        v557_2_more = next_value_within(&mut v555_22_cursor,(v555_22_origin + 1));
      }
      }
      v555_22_cursor.ascend(1);
    }
    drop(v555_22_cursor);
    drop(v555_22_write);
    let v555_23: Space = unite(&(v555_19),&(v555_22));
    compose(&(v554_13),&(v555_23))
  };
  drop(v554_13);
  let v554_26: Space = intersect(&(*CONSTANT_3),&(v554_10));
  drop(v554_10);
  let v554_27: Space = if has_head(&(v554_26)) { singleton(&[]) } else { Space::new() };
  drop(v554_26);
  let v554_33: Space = if (&(v554_27)).is_empty() { Space::new() } else {
    let v560_31: Space = subtract(&(*CONSTANT_6),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_17))));
    let mut v560_32 = Space::new();
    let mut v560_32_write = v560_32.write_zipper();
    let mut v560_32_cursor = (v560_31).read_zipper();
    let v560_32_origin = v560_32_cursor.path().len();
    for v560_32_byte in v560_32_cursor.child_mask().iter() {
      v560_32_cursor.descend_to_existing_byte(v560_32_byte);
      {
      let v561_2: Space = routine_80(c, &v560_32_cursor.path()[v560_32_origin..(v560_32_origin + 1)], &v560_32_cursor.path()[v560_32_origin..(v560_32_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v560_32_cursor, &(*s0));
      join_wrapped_into(&mut v560_32_write,&((v561_2).read_zipper()),&[]);
      }
      v560_32_cursor.ascend(1);
    }
    drop(v560_32_cursor);
    drop(v560_32_write);
    drop(v560_31);
    compose(&(v554_27),&(v560_32))
  };
  drop(v554_27);
  let v554_34: Space = unite(&(v554_24),&(v554_33));
  (v554_34).clone()
}

fn routine_74(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v562_9: Space = singleton(&(*p0));
  let v562_10: Space = intersect(&(*CONSTANT_3),&(v562_9));
  let v562_11: Space = if has_head(&(v562_10)) { singleton(&[]) } else { Space::new() };
  drop(v562_10);
  let v562_12: Space = subtract(&(*CONSTANT_0),&(v562_11));
  drop(v562_11);
  let v562_17: Space = intersect(&(*CONSTANT_3),&(v562_9));
  drop(v562_9);
  let v562_18: Space = if has_head(&(v562_17)) { singleton(&[]) } else { Space::new() };
  drop(v562_17);
  let mut v562_19 = Space::new();
  let mut v562_19_write = v562_19.write_zipper();
  let mut v562_19_cursor = (*s0).read_zipper();
  let v562_19_origin = v562_19_cursor.path().len();
  for v562_19_byte in v562_19_cursor.child_mask().iter() {
    v562_19_cursor.descend_to_existing_byte(v562_19_byte);
    {
    let v563_4: Space = if (&(v562_12)).is_empty() { Space::new() } else {
      let v564_2: Path = concat_path(&(*p1),&v562_19_cursor.path()[v562_19_origin..(v562_19_origin + 1)]);
      let mut v564_3 = Space::new();
      let mut v564_3_write = v564_3.write_zipper();
      let v564_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v564_3_arg_1: &[u8] = &(v564_2);
      let v564_3_arg_2: &[u8] = &(*p2);
      let v564_3_arg_3: &[u8] = &(*p3);
      let v564_3_arg_4: &[u8] = &(*p4);
      let v564_3_arg_5: &[u8] = &(*p5);
      let v564_3_arg_7: &Space = &(&v562_19_cursor).make_map();
      let mut v564_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v564_3_origin = v564_3_cursor.path().len();
      let mut v564_3_more = v564_3_cursor.is_val() || next_value_within(&mut v564_3_cursor,v564_3_origin);
      while v564_3_more {
        {
        let v564_3_depth = v564_3_cursor.path().len();
        let v565_8: Space = routine_74(c, &v564_3_cursor.path()[v564_3_origin..v564_3_depth], &(*v564_3_arg_1), &(*v564_3_arg_2), &(*v564_3_arg_3), &(*v564_3_arg_4), &(*v564_3_arg_5), &((*v564_3_arg_7).read_zipper()));
        join_wrapped_into(&mut v564_3_write,&((v565_8).read_zipper()),&[]);
        }
        v564_3_more = next_value_within(&mut v564_3_cursor,v564_3_origin);
      }
      drop(v564_3_cursor);
      drop(v564_3_write);
      compose(&(v562_12),&(v564_3))
    };
    let v563_6: Space = if (&(v562_18)).is_empty() { Space::new() } else {
      let v566_2: Path = concat_path(&(*p1),&v562_19_cursor.path()[v562_19_origin..(v562_19_origin + 1)]);
      let mut v566_5 = Space::new();
      let mut v566_5_write = v566_5.write_zipper();
      for v566_5_byte in v562_19_cursor.child_mask().iter() {
        v562_19_cursor.descend_to_existing_byte(v566_5_byte);
        {
        let v567_2: Space = routine_75(c, &v562_19_cursor.path()[(v562_19_origin + 1)..(v562_19_origin + 2)], &v562_19_cursor.path()[(v562_19_origin + 1)..(v562_19_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(v566_2), &v562_19_cursor);
        join_wrapped_into(&mut v566_5_write,&((v567_2).read_zipper()),&[]);
        }
        v562_19_cursor.ascend(1);
      }
      drop(v566_5_write);
      drop(v566_2);
      compose(&(v562_18),&(v566_5))
    };
    let v563_7: Space = unite(&(v563_4),&(v563_6));
    join_wrapped_into(&mut v562_19_write,&((v563_7).read_zipper()),&[]);
    }
    v562_19_cursor.ascend(1);
  }
  drop(v562_19_cursor);
  drop(v562_19_write);
  drop(v562_12);
  drop(v562_18);
  (v562_19).clone()
}

fn routine_75(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v568_10: Space = singleton(&(*p1));
  let v568_11: Space = intersect(&(*CONSTANT_3),&(v568_10));
  let v568_12: Space = if has_head(&(v568_11)) { singleton(&[]) } else { Space::new() };
  drop(v568_11);
  let v568_13: Space = subtract(&(*CONSTANT_0),&(v568_12));
  drop(v568_12);
  let v568_24: Space = if (&(v568_13)).is_empty() { Space::new() } else {
    let v569_16: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v569_19: Space = if (&(v569_16)).is_empty() { Space::new() } else {
      let v570_18: Space = routine_81(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*s0));
      compose(&(v569_16),&(v570_18))
    };
    drop(v569_16);
    let mut v569_22 = Space::new();
    let mut v569_22_write = v569_22.write_zipper();
    let mut v569_22_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v569_22_origin = v569_22_cursor.path().len();
    for v569_22_byte in v569_22_cursor.child_mask().iter() {
      v569_22_cursor.descend_to_existing_byte(v569_22_byte);
      {
      let v571_2_arg_0: &[u8] = &v569_22_cursor.path()[v569_22_origin..(v569_22_origin + 1)];
      let v571_2_arg_1: &[u8] = &(*p0);
      let v571_2_arg_2: &[u8] = &(*p2);
      let v571_2_arg_3: &[u8] = &(*p3);
      let v571_2_arg_4: &[u8] = &(*p4);
      let v571_2_arg_5: &[u8] = &(*p5);
      let v571_2_arg_6: &[u8] = &(*p6);
      let v571_2_arg_8: &Space = &(&(*s0)).make_map();
      let mut v571_2_more = v569_22_cursor.is_val() || next_value_within(&mut v569_22_cursor,(v569_22_origin + 1));
      while v571_2_more {
        {
        let v571_2_depth = v569_22_cursor.path().len();
        let mut v572_9_cursor = (*v571_2_arg_8).read_zipper();
        let v572_9_origin = v572_9_cursor.path().len();
        for v572_9_byte in v572_9_cursor.child_mask().iter() {
          v572_9_cursor.descend_to_existing_byte(v572_9_byte);
          {
          let v573_2: Path = concat_path(&(*v571_2_arg_1),&v572_9_cursor.path()[v572_9_origin..(v572_9_origin + 1)]);
          let v573_3: Space = routine_75(c, &(v573_2), &v569_22_cursor.path()[v569_22_origin..v571_2_depth], &(*v571_2_arg_2), &(*v571_2_arg_3), &(*v571_2_arg_4), &(*v571_2_arg_5), &(*v571_2_arg_6), &v572_9_cursor);
          drop(v573_2);
          join_wrapped_into(&mut v569_22_write,&((v573_3).read_zipper()),&[]);
          }
          v572_9_cursor.ascend(1);
        }
        drop(v572_9_cursor);
        }
        v571_2_more = next_value_within(&mut v569_22_cursor,(v569_22_origin + 1));
      }
      }
      v569_22_cursor.ascend(1);
    }
    drop(v569_22_cursor);
    drop(v569_22_write);
    let v569_23: Space = unite(&(v569_19),&(v569_22));
    compose(&(v568_13),&(v569_23))
  };
  drop(v568_13);
  let v568_26: Space = intersect(&(*CONSTANT_3),&(v568_10));
  drop(v568_10);
  let v568_27: Space = if has_head(&(v568_26)) { singleton(&[]) } else { Space::new() };
  drop(v568_26);
  let v568_29: Space = if (&(v568_27)).is_empty() { Space::new() } else {
    let mut v574_28 = Space::new();
    let mut v574_28_write = v574_28.write_zipper();
    let mut v574_28_cursor = (*s0).read_zipper();
    let v574_28_origin = v574_28_cursor.path().len();
    for v574_28_byte in v574_28_cursor.child_mask().iter() {
      v574_28_cursor.descend_to_existing_byte(v574_28_byte);
      {
      let v575_2: Space = routine_82(c, &v574_28_cursor.path()[v574_28_origin..(v574_28_origin + 1)], &v574_28_cursor.path()[v574_28_origin..(v574_28_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v574_28_cursor);
      join_wrapped_into(&mut v574_28_write,&((v575_2).read_zipper()),&[]);
      }
      v574_28_cursor.ascend(1);
    }
    drop(v574_28_cursor);
    drop(v574_28_write);
    compose(&(v568_27),&(v574_28))
  };
  drop(v568_27);
  let v568_30: Space = unite(&(v568_24),&(v568_29));
  (v568_30).clone()
}

fn routine_76(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v576_9: Space = singleton(&(*p0));
  let v576_10: Space = intersect(&(*CONSTANT_3),&(v576_9));
  let v576_11: Space = if has_head(&(v576_10)) { singleton(&[]) } else { Space::new() };
  drop(v576_10);
  let v576_12: Space = subtract(&(*CONSTANT_0),&(v576_11));
  drop(v576_11);
  let v576_17: Space = intersect(&(*CONSTANT_3),&(v576_9));
  drop(v576_9);
  let v576_18: Space = if has_head(&(v576_17)) { singleton(&[]) } else { Space::new() };
  drop(v576_17);
  let mut v576_19 = Space::new();
  let mut v576_19_write = v576_19.write_zipper();
  let mut v576_19_cursor = (*s0).read_zipper();
  let v576_19_origin = v576_19_cursor.path().len();
  for v576_19_byte in v576_19_cursor.child_mask().iter() {
    v576_19_cursor.descend_to_existing_byte(v576_19_byte);
    {
    let v577_4: Space = if (&(v576_12)).is_empty() { Space::new() } else {
      let v578_2: Path = concat_path(&(*p1),&v576_19_cursor.path()[v576_19_origin..(v576_19_origin + 1)]);
      let mut v578_3 = Space::new();
      let mut v578_3_write = v578_3.write_zipper();
      let v578_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v578_3_arg_1: &[u8] = &(v578_2);
      let v578_3_arg_2: &[u8] = &(*p2);
      let v578_3_arg_3: &[u8] = &(*p3);
      let v578_3_arg_4: &[u8] = &(*p4);
      let v578_3_arg_5: &[u8] = &(*p5);
      let v578_3_arg_7: &Space = &(&v576_19_cursor).make_map();
      let mut v578_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v578_3_origin = v578_3_cursor.path().len();
      let mut v578_3_more = v578_3_cursor.is_val() || next_value_within(&mut v578_3_cursor,v578_3_origin);
      while v578_3_more {
        {
        let v578_3_depth = v578_3_cursor.path().len();
        let v579_8: Space = routine_76(c, &v578_3_cursor.path()[v578_3_origin..v578_3_depth], &(*v578_3_arg_1), &(*v578_3_arg_2), &(*v578_3_arg_3), &(*v578_3_arg_4), &(*v578_3_arg_5), &((*v578_3_arg_7).read_zipper()));
        join_wrapped_into(&mut v578_3_write,&((v579_8).read_zipper()),&[]);
        }
        v578_3_more = next_value_within(&mut v578_3_cursor,v578_3_origin);
      }
      drop(v578_3_cursor);
      drop(v578_3_write);
      compose(&(v576_12),&(v578_3))
    };
    let v577_6: Space = if (&(v576_18)).is_empty() { Space::new() } else {
      let v580_2: Path = concat_path(&(*p1),&v576_19_cursor.path()[v576_19_origin..(v576_19_origin + 1)]);
      let mut v580_5 = Space::new();
      let mut v580_5_write = v580_5.write_zipper();
      for v580_5_byte in v576_19_cursor.child_mask().iter() {
        v576_19_cursor.descend_to_existing_byte(v580_5_byte);
        {
        let v581_2: Space = routine_77(c, &v576_19_cursor.path()[(v576_19_origin + 1)..(v576_19_origin + 2)], &v576_19_cursor.path()[(v576_19_origin + 1)..(v576_19_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(v580_2), &v576_19_cursor);
        join_wrapped_into(&mut v580_5_write,&((v581_2).read_zipper()),&[]);
        }
        v576_19_cursor.ascend(1);
      }
      drop(v580_5_write);
      drop(v580_2);
      compose(&(v576_18),&(v580_5))
    };
    let v577_7: Space = unite(&(v577_4),&(v577_6));
    join_wrapped_into(&mut v576_19_write,&((v577_7).read_zipper()),&[]);
    }
    v576_19_cursor.ascend(1);
  }
  drop(v576_19_cursor);
  drop(v576_19_write);
  drop(v576_12);
  drop(v576_18);
  (v576_19).clone()
}

fn routine_77(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v582_10: Space = singleton(&(*p1));
  let v582_11: Space = intersect(&(*CONSTANT_3),&(v582_10));
  let v582_12: Space = if has_head(&(v582_11)) { singleton(&[]) } else { Space::new() };
  drop(v582_11);
  let v582_13: Space = subtract(&(*CONSTANT_0),&(v582_12));
  drop(v582_12);
  let v582_24: Space = if (&(v582_13)).is_empty() { Space::new() } else {
    let v583_16: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v583_19: Space = if (&(v583_16)).is_empty() { Space::new() } else {
      let v584_18: Space = routine_83(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*s0));
      compose(&(v583_16),&(v584_18))
    };
    drop(v583_16);
    let mut v583_22 = Space::new();
    let mut v583_22_write = v583_22.write_zipper();
    let mut v583_22_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v583_22_origin = v583_22_cursor.path().len();
    for v583_22_byte in v583_22_cursor.child_mask().iter() {
      v583_22_cursor.descend_to_existing_byte(v583_22_byte);
      {
      let v585_2_arg_0: &[u8] = &v583_22_cursor.path()[v583_22_origin..(v583_22_origin + 1)];
      let v585_2_arg_1: &[u8] = &(*p0);
      let v585_2_arg_2: &[u8] = &(*p2);
      let v585_2_arg_3: &[u8] = &(*p3);
      let v585_2_arg_4: &[u8] = &(*p4);
      let v585_2_arg_5: &[u8] = &(*p5);
      let v585_2_arg_6: &[u8] = &(*p6);
      let v585_2_arg_8: &Space = &(&(*s0)).make_map();
      let mut v585_2_more = v583_22_cursor.is_val() || next_value_within(&mut v583_22_cursor,(v583_22_origin + 1));
      while v585_2_more {
        {
        let v585_2_depth = v583_22_cursor.path().len();
        let mut v586_9_cursor = (*v585_2_arg_8).read_zipper();
        let v586_9_origin = v586_9_cursor.path().len();
        for v586_9_byte in v586_9_cursor.child_mask().iter() {
          v586_9_cursor.descend_to_existing_byte(v586_9_byte);
          {
          let v587_2: Path = concat_path(&(*v585_2_arg_1),&v586_9_cursor.path()[v586_9_origin..(v586_9_origin + 1)]);
          let v587_3: Space = routine_77(c, &(v587_2), &v583_22_cursor.path()[v583_22_origin..v585_2_depth], &(*v585_2_arg_2), &(*v585_2_arg_3), &(*v585_2_arg_4), &(*v585_2_arg_5), &(*v585_2_arg_6), &v586_9_cursor);
          drop(v587_2);
          join_wrapped_into(&mut v583_22_write,&((v587_3).read_zipper()),&[]);
          }
          v586_9_cursor.ascend(1);
        }
        drop(v586_9_cursor);
        }
        v585_2_more = next_value_within(&mut v583_22_cursor,(v583_22_origin + 1));
      }
      }
      v583_22_cursor.ascend(1);
    }
    drop(v583_22_cursor);
    drop(v583_22_write);
    let v583_23: Space = unite(&(v583_19),&(v583_22));
    compose(&(v582_13),&(v583_23))
  };
  drop(v582_13);
  let v582_26: Space = intersect(&(*CONSTANT_3),&(v582_10));
  drop(v582_10);
  let v582_27: Space = if has_head(&(v582_26)) { singleton(&[]) } else { Space::new() };
  drop(v582_26);
  let v582_29: Space = if (&(v582_27)).is_empty() { Space::new() } else {
    let mut v588_28 = Space::new();
    let mut v588_28_write = v588_28.write_zipper();
    let mut v588_28_cursor = (*s0).read_zipper();
    let v588_28_origin = v588_28_cursor.path().len();
    for v588_28_byte in v588_28_cursor.child_mask().iter() {
      v588_28_cursor.descend_to_existing_byte(v588_28_byte);
      {
      let v589_2: Space = routine_84(c, &v588_28_cursor.path()[v588_28_origin..(v588_28_origin + 1)], &v588_28_cursor.path()[v588_28_origin..(v588_28_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v588_28_cursor);
      join_wrapped_into(&mut v588_28_write,&((v589_2).read_zipper()),&[]);
      }
      v588_28_cursor.ascend(1);
    }
    drop(v588_28_cursor);
    drop(v588_28_write);
    compose(&(v582_27),&(v588_28))
  };
  drop(v582_27);
  let v582_30: Space = unite(&(v582_24),&(v582_29));
  (v582_30).clone()
}

fn routine_78(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v590_11: Space = singleton(&(*p0));
  let v590_12: Space = intersect(&(*CONSTANT_3),&(v590_11));
  let v590_13: Space = if has_head(&(v590_12)) { singleton(&[]) } else { Space::new() };
  drop(v590_12);
  let v590_14: Space = subtract(&(*CONSTANT_0),&(v590_13));
  drop(v590_13);
  let v590_19: Space = intersect(&(*CONSTANT_3),&(v590_11));
  drop(v590_11);
  let v590_20: Space = if has_head(&(v590_19)) { singleton(&[]) } else { Space::new() };
  drop(v590_19);
  let v590_23: Path = concat_path(&(*p2),&(*p3));
  let v590_24: Path = concat_path(&(v590_23),&(*p4));
  drop(v590_23);
  let v590_25: Path = concat_path(&(v590_24),&(*p5));
  drop(v590_24);
  let v590_26: Path = concat_path(&(v590_25),&(*p6));
  drop(v590_25);
  let mut v590_27 = Space::new();
  let mut v590_27_write = v590_27.write_zipper();
  let mut v590_27_cursor = (*s0).read_zipper();
  let v590_27_origin = v590_27_cursor.path().len();
  for v590_27_byte in v590_27_cursor.child_mask().iter() {
    v590_27_cursor.descend_to_existing_byte(v590_27_byte);
    {
    let v591_4: Space = if (&(v590_14)).is_empty() { Space::new() } else {
      let v592_2: Path = concat_path(&(*p1),&v590_27_cursor.path()[v590_27_origin..(v590_27_origin + 1)]);
      let mut v592_3 = Space::new();
      let mut v592_3_write = v592_3.write_zipper();
      let v592_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v592_3_arg_1: &[u8] = &(v592_2);
      let v592_3_arg_2: &[u8] = &(*p2);
      let v592_3_arg_3: &[u8] = &(*p3);
      let v592_3_arg_4: &[u8] = &(*p4);
      let v592_3_arg_5: &[u8] = &(*p5);
      let v592_3_arg_6: &[u8] = &(*p6);
      let v592_3_arg_8: &Space = &(&v590_27_cursor).make_map();
      let v592_3_arg_9: &Space = &(&(*s1)).make_map();
      let mut v592_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v592_3_origin = v592_3_cursor.path().len();
      let mut v592_3_more = v592_3_cursor.is_val() || next_value_within(&mut v592_3_cursor,v592_3_origin);
      while v592_3_more {
        {
        let v592_3_depth = v592_3_cursor.path().len();
        let v593_10: Space = routine_78(c, &v592_3_cursor.path()[v592_3_origin..v592_3_depth], &(*v592_3_arg_1), &(*v592_3_arg_2), &(*v592_3_arg_3), &(*v592_3_arg_4), &(*v592_3_arg_5), &(*v592_3_arg_6), &((*v592_3_arg_8).read_zipper()), &((*v592_3_arg_9).read_zipper()));
        join_wrapped_into(&mut v592_3_write,&((v593_10).read_zipper()),&[]);
        }
        v592_3_more = next_value_within(&mut v592_3_cursor,v592_3_origin);
      }
      drop(v592_3_cursor);
      drop(v592_3_write);
      compose(&(v590_14),&(v592_3))
    };
    let v591_7: Space = if (&(v590_20)).is_empty() { Space::new() } else {
      let v594_2: Path = concat_path(&(*p1),&v590_27_cursor.path()[v590_27_origin..(v590_27_origin + 1)]);
      let v594_5: Space = routine_43(c, &(v594_2), &(*CONSTANT_16), &(*CONSTANT_11));
      let v594_6: Space = unite(&(*s1),&(v594_5));
      compose(&(v590_20),&(v594_6))
    };
    let v591_8: Space = wrap(&(v591_7),&(v590_26));
    let v595_2: Path = concat_path(&(*p1),&v590_27_cursor.path()[v590_27_origin..(v590_27_origin + 1)]);
    let v591_9: Space = wrap(&(v591_8),&(v595_2));
    let v591_10: Space = unite(&(v591_4),&(v591_9));
    join_wrapped_into(&mut v590_27_write,&((v591_10).read_zipper()),&[]);
    }
    v590_27_cursor.ascend(1);
  }
  drop(v590_27_cursor);
  drop(v590_27_write);
  drop(v590_14);
  drop(v590_20);
  drop(v590_26);
  (v590_27).clone()
}

fn routine_79(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v596_10: Space = singleton(&(*p0));
  let v596_11: Space = intersect(&(*CONSTANT_3),&(v596_10));
  let v596_12: Space = if has_head(&(v596_11)) { singleton(&[]) } else { Space::new() };
  drop(v596_11);
  let v596_13: Space = subtract(&(*CONSTANT_0),&(v596_12));
  drop(v596_12);
  let v596_18: Space = intersect(&(*CONSTANT_3),&(v596_10));
  drop(v596_10);
  let v596_19: Space = if has_head(&(v596_18)) { singleton(&[]) } else { Space::new() };
  drop(v596_18);
  let mut v596_22 = Space::new();
  let mut v596_22_write = v596_22.write_zipper();
  let mut v596_22_cursor = (*s0).read_zipper();
  let v596_22_origin = v596_22_cursor.path().len();
  for v596_22_byte in v596_22_cursor.child_mask().iter() {
    v596_22_cursor.descend_to_existing_byte(v596_22_byte);
    {
    let v597_4: Space = if (&(v596_13)).is_empty() { Space::new() } else {
      let v598_2: Path = concat_path(&(*p1),&v596_22_cursor.path()[v596_22_origin..(v596_22_origin + 1)]);
      let mut v598_3 = Space::new();
      let mut v598_3_write = v598_3.write_zipper();
      let v598_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v598_3_arg_1: &[u8] = &(v598_2);
      let v598_3_arg_2: &[u8] = &(*p2);
      let v598_3_arg_3: &[u8] = &(*p3);
      let v598_3_arg_4: &[u8] = &(*p4);
      let v598_3_arg_5: &[u8] = &(*p5);
      let v598_3_arg_6: &[u8] = &(*p6);
      let v598_3_arg_8: &Space = &(&v596_22_cursor).make_map();
      let mut v598_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v598_3_origin = v598_3_cursor.path().len();
      let mut v598_3_more = v598_3_cursor.is_val() || next_value_within(&mut v598_3_cursor,v598_3_origin);
      while v598_3_more {
        {
        let v598_3_depth = v598_3_cursor.path().len();
        let v599_9: Space = routine_79(c, &v598_3_cursor.path()[v598_3_origin..v598_3_depth], &(*v598_3_arg_1), &(*v598_3_arg_2), &(*v598_3_arg_3), &(*v598_3_arg_4), &(*v598_3_arg_5), &(*v598_3_arg_6), &((*v598_3_arg_8).read_zipper()));
        join_wrapped_into(&mut v598_3_write,&((v599_9).read_zipper()),&[]);
        }
        v598_3_more = next_value_within(&mut v598_3_cursor,v598_3_origin);
      }
      drop(v598_3_cursor);
      drop(v598_3_write);
      compose(&(v596_13),&(v598_3))
    };
    let v597_8: Space = if (&(v596_19)).is_empty() { Space::new() } else {
      let v600_2: Path = concat_path(&(*p1),&v596_22_cursor.path()[v596_22_origin..(v596_22_origin + 1)]);
      let v600_6: Space = subtract(&(*CONSTANT_6),&(descend_cursor(cursor_at(&v596_22_cursor,(v596_22_origin + 1)),&(*CONSTANT_17))));
      let mut v600_7 = Space::new();
      let mut v600_7_write = v600_7.write_zipper();
      let mut v600_7_cursor = (v600_6).read_zipper();
      let v600_7_origin = v600_7_cursor.path().len();
      for v600_7_byte in v600_7_cursor.child_mask().iter() {
        v600_7_cursor.descend_to_existing_byte(v600_7_byte);
        {
        let v601_2: Space = routine_80(c, &v600_7_cursor.path()[v600_7_origin..(v600_7_origin + 1)], &v600_7_cursor.path()[v600_7_origin..(v600_7_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v600_2), &v600_7_cursor, &v596_22_cursor);
        join_wrapped_into(&mut v600_7_write,&((v601_2).read_zipper()),&[]);
        }
        v600_7_cursor.ascend(1);
      }
      drop(v600_7_cursor);
      drop(v600_7_write);
      drop(v600_2);
      drop(v600_6);
      compose(&(v596_19),&(v600_7))
    };
    let v597_9: Space = unite(&(v597_4),&(v597_8));
    join_wrapped_into(&mut v596_22_write,&((v597_9).read_zipper()),&[]);
    }
    v596_22_cursor.ascend(1);
  }
  drop(v596_22_cursor);
  drop(v596_22_write);
  drop(v596_13);
  drop(v596_19);
  (v596_22).clone()
}

fn routine_80(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v602_12: Space = singleton(&(*p1));
  let v602_13: Space = intersect(&(*CONSTANT_3),&(v602_12));
  let v602_14: Space = if has_head(&(v602_13)) { singleton(&[]) } else { Space::new() };
  drop(v602_13);
  let v602_15: Space = subtract(&(*CONSTANT_0),&(v602_14));
  drop(v602_14);
  let v602_26: Space = if (&(v602_15)).is_empty() { Space::new() } else {
    let v603_18: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v603_21: Space = if (&(v603_18)).is_empty() { Space::new() } else {
      let v604_20: Space = routine_85(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*s0), &(*s1));
      compose(&(v603_18),&(v604_20))
    };
    drop(v603_18);
    let mut v603_24 = Space::new();
    let mut v603_24_write = v603_24.write_zipper();
    let mut v603_24_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v603_24_origin = v603_24_cursor.path().len();
    for v603_24_byte in v603_24_cursor.child_mask().iter() {
      v603_24_cursor.descend_to_existing_byte(v603_24_byte);
      {
      let v605_2_arg_0: &[u8] = &v603_24_cursor.path()[v603_24_origin..(v603_24_origin + 1)];
      let v605_2_arg_1: &[u8] = &(*p0);
      let v605_2_arg_2: &[u8] = &(*p2);
      let v605_2_arg_3: &[u8] = &(*p3);
      let v605_2_arg_4: &[u8] = &(*p4);
      let v605_2_arg_5: &[u8] = &(*p5);
      let v605_2_arg_6: &[u8] = &(*p6);
      let v605_2_arg_7: &[u8] = &(*p7);
      let v605_2_arg_9: &Space = &(&(*s0)).make_map();
      let v605_2_arg_10: &Space = &(&(*s1)).make_map();
      let mut v605_2_more = v603_24_cursor.is_val() || next_value_within(&mut v603_24_cursor,(v603_24_origin + 1));
      while v605_2_more {
        {
        let v605_2_depth = v603_24_cursor.path().len();
        let mut v606_11_cursor = (*v605_2_arg_9).read_zipper();
        let v606_11_origin = v606_11_cursor.path().len();
        for v606_11_byte in v606_11_cursor.child_mask().iter() {
          v606_11_cursor.descend_to_existing_byte(v606_11_byte);
          {
          let v607_2: Path = concat_path(&(*v605_2_arg_1),&v606_11_cursor.path()[v606_11_origin..(v606_11_origin + 1)]);
          let v607_3: Space = routine_80(c, &(v607_2), &v603_24_cursor.path()[v603_24_origin..v605_2_depth], &(*v605_2_arg_2), &(*v605_2_arg_3), &(*v605_2_arg_4), &(*v605_2_arg_5), &(*v605_2_arg_6), &(*v605_2_arg_7), &v606_11_cursor, &((*v605_2_arg_10).read_zipper()));
          drop(v607_2);
          join_wrapped_into(&mut v603_24_write,&((v607_3).read_zipper()),&[]);
          }
          v606_11_cursor.ascend(1);
        }
        drop(v606_11_cursor);
        }
        v605_2_more = next_value_within(&mut v603_24_cursor,(v603_24_origin + 1));
      }
      }
      v603_24_cursor.ascend(1);
    }
    drop(v603_24_cursor);
    drop(v603_24_write);
    let v603_25: Space = unite(&(v603_21),&(v603_24));
    compose(&(v602_15),&(v603_25))
  };
  drop(v602_15);
  let v602_28: Space = intersect(&(*CONSTANT_3),&(v602_12));
  drop(v602_12);
  let v602_29: Space = if has_head(&(v602_28)) { singleton(&[]) } else { Space::new() };
  drop(v602_28);
  let v602_37: Space = if (&(v602_29)).is_empty() { Space::new() } else {
    let v608_34: Space = routine_19(c, &(*CONSTANT_2), &(*CONSTANT_2), &(*CONSTANT_17), &(*p0), &((*CONSTANT_4).read_zipper()));
    let v608_35: Space = intersect(&(*CONSTANT_8),&(v608_34));
    let v608_36: Space = unite(&(v608_35),&(*s1));
    compose(&(v602_29),&(v608_36))
  };
  drop(v602_29);
  let v602_38: Path = concat_path(&(*p2),&(*p3));
  let v602_39: Path = concat_path(&(v602_38),&(*p4));
  drop(v602_38);
  let v602_40: Path = concat_path(&(v602_39),&(*p5));
  drop(v602_39);
  let v602_41: Path = concat_path(&(v602_40),&(*p6));
  drop(v602_40);
  let v602_42: Path = concat_path(&(v602_41),&(*p7));
  drop(v602_41);
  let v602_43: Space = wrap(&(v602_37),&(v602_42));
  drop(v602_42);
  let v602_44: Space = wrap(&(v602_43),&(*p0));
  let v602_45: Space = unite(&(v602_26),&(v602_44));
  (v602_45).clone()
}

fn routine_81(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v609_10: Space = singleton(&(*p0));
  let v609_11: Space = intersect(&(*CONSTANT_3),&(v609_10));
  let v609_12: Space = if has_head(&(v609_11)) { singleton(&[]) } else { Space::new() };
  drop(v609_11);
  let v609_13: Space = subtract(&(*CONSTANT_0),&(v609_12));
  drop(v609_12);
  let v609_18: Space = intersect(&(*CONSTANT_3),&(v609_10));
  drop(v609_10);
  let v609_19: Space = if has_head(&(v609_18)) { singleton(&[]) } else { Space::new() };
  drop(v609_18);
  let mut v609_20 = Space::new();
  let mut v609_20_write = v609_20.write_zipper();
  let mut v609_20_cursor = (*s0).read_zipper();
  let v609_20_origin = v609_20_cursor.path().len();
  for v609_20_byte in v609_20_cursor.child_mask().iter() {
    v609_20_cursor.descend_to_existing_byte(v609_20_byte);
    {
    let v610_4: Space = if (&(v609_13)).is_empty() { Space::new() } else {
      let v611_2: Path = concat_path(&(*p1),&v609_20_cursor.path()[v609_20_origin..(v609_20_origin + 1)]);
      let mut v611_3 = Space::new();
      let mut v611_3_write = v611_3.write_zipper();
      let v611_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v611_3_arg_1: &[u8] = &(v611_2);
      let v611_3_arg_2: &[u8] = &(*p2);
      let v611_3_arg_3: &[u8] = &(*p3);
      let v611_3_arg_4: &[u8] = &(*p4);
      let v611_3_arg_5: &[u8] = &(*p5);
      let v611_3_arg_6: &[u8] = &(*p6);
      let v611_3_arg_8: &Space = &(&v609_20_cursor).make_map();
      let mut v611_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v611_3_origin = v611_3_cursor.path().len();
      let mut v611_3_more = v611_3_cursor.is_val() || next_value_within(&mut v611_3_cursor,v611_3_origin);
      while v611_3_more {
        {
        let v611_3_depth = v611_3_cursor.path().len();
        let v612_9: Space = routine_81(c, &v611_3_cursor.path()[v611_3_origin..v611_3_depth], &(*v611_3_arg_1), &(*v611_3_arg_2), &(*v611_3_arg_3), &(*v611_3_arg_4), &(*v611_3_arg_5), &(*v611_3_arg_6), &((*v611_3_arg_8).read_zipper()));
        join_wrapped_into(&mut v611_3_write,&((v612_9).read_zipper()),&[]);
        }
        v611_3_more = next_value_within(&mut v611_3_cursor,v611_3_origin);
      }
      drop(v611_3_cursor);
      drop(v611_3_write);
      compose(&(v609_13),&(v611_3))
    };
    let v610_6: Space = if (&(v609_19)).is_empty() { Space::new() } else {
      let v613_2: Path = concat_path(&(*p1),&v609_20_cursor.path()[v609_20_origin..(v609_20_origin + 1)]);
      let mut v613_5 = Space::new();
      let mut v613_5_write = v613_5.write_zipper();
      for v613_5_byte in v609_20_cursor.child_mask().iter() {
        v609_20_cursor.descend_to_existing_byte(v613_5_byte);
        {
        let v614_2: Space = routine_82(c, &v609_20_cursor.path()[(v609_20_origin + 1)..(v609_20_origin + 2)], &v609_20_cursor.path()[(v609_20_origin + 1)..(v609_20_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v613_2), &v609_20_cursor);
        join_wrapped_into(&mut v613_5_write,&((v614_2).read_zipper()),&[]);
        }
        v609_20_cursor.ascend(1);
      }
      drop(v613_5_write);
      drop(v613_2);
      compose(&(v609_19),&(v613_5))
    };
    let v610_7: Space = unite(&(v610_4),&(v610_6));
    join_wrapped_into(&mut v609_20_write,&((v610_7).read_zipper()),&[]);
    }
    v609_20_cursor.ascend(1);
  }
  drop(v609_20_cursor);
  drop(v609_20_write);
  drop(v609_13);
  drop(v609_19);
  (v609_20).clone()
}

fn routine_82(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v615_11: Space = singleton(&(*p1));
  let v615_12: Space = intersect(&(*CONSTANT_3),&(v615_11));
  let v615_13: Space = if has_head(&(v615_12)) { singleton(&[]) } else { Space::new() };
  drop(v615_12);
  let v615_14: Space = subtract(&(*CONSTANT_0),&(v615_13));
  drop(v615_13);
  let v615_25: Space = if (&(v615_14)).is_empty() { Space::new() } else {
    let v616_17: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v616_20: Space = if (&(v616_17)).is_empty() { Space::new() } else {
      let v617_19: Space = routine_86(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*s0));
      compose(&(v616_17),&(v617_19))
    };
    drop(v616_17);
    let mut v616_23 = Space::new();
    let mut v616_23_write = v616_23.write_zipper();
    let mut v616_23_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v616_23_origin = v616_23_cursor.path().len();
    for v616_23_byte in v616_23_cursor.child_mask().iter() {
      v616_23_cursor.descend_to_existing_byte(v616_23_byte);
      {
      let v618_2_arg_0: &[u8] = &v616_23_cursor.path()[v616_23_origin..(v616_23_origin + 1)];
      let v618_2_arg_1: &[u8] = &(*p0);
      let v618_2_arg_2: &[u8] = &(*p2);
      let v618_2_arg_3: &[u8] = &(*p3);
      let v618_2_arg_4: &[u8] = &(*p4);
      let v618_2_arg_5: &[u8] = &(*p5);
      let v618_2_arg_6: &[u8] = &(*p6);
      let v618_2_arg_7: &[u8] = &(*p7);
      let v618_2_arg_9: &Space = &(&(*s0)).make_map();
      let mut v618_2_more = v616_23_cursor.is_val() || next_value_within(&mut v616_23_cursor,(v616_23_origin + 1));
      while v618_2_more {
        {
        let v618_2_depth = v616_23_cursor.path().len();
        let mut v619_10_cursor = (*v618_2_arg_9).read_zipper();
        let v619_10_origin = v619_10_cursor.path().len();
        for v619_10_byte in v619_10_cursor.child_mask().iter() {
          v619_10_cursor.descend_to_existing_byte(v619_10_byte);
          {
          let v620_2: Path = concat_path(&(*v618_2_arg_1),&v619_10_cursor.path()[v619_10_origin..(v619_10_origin + 1)]);
          let v620_3: Space = routine_82(c, &(v620_2), &v616_23_cursor.path()[v616_23_origin..v618_2_depth], &(*v618_2_arg_2), &(*v618_2_arg_3), &(*v618_2_arg_4), &(*v618_2_arg_5), &(*v618_2_arg_6), &(*v618_2_arg_7), &v619_10_cursor);
          drop(v620_2);
          join_wrapped_into(&mut v616_23_write,&((v620_3).read_zipper()),&[]);
          }
          v619_10_cursor.ascend(1);
        }
        drop(v619_10_cursor);
        }
        v618_2_more = next_value_within(&mut v616_23_cursor,(v616_23_origin + 1));
      }
      }
      v616_23_cursor.ascend(1);
    }
    drop(v616_23_cursor);
    drop(v616_23_write);
    let v616_24: Space = unite(&(v616_20),&(v616_23));
    compose(&(v615_14),&(v616_24))
  };
  drop(v615_14);
  let v615_27: Space = intersect(&(*CONSTANT_3),&(v615_11));
  drop(v615_11);
  let v615_28: Space = if has_head(&(v615_27)) { singleton(&[]) } else { Space::new() };
  drop(v615_27);
  let v615_34: Space = if (&(v615_28)).is_empty() { Space::new() } else {
    let v621_32: Space = subtract(&(*CONSTANT_6),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_11))));
    let mut v621_33 = Space::new();
    let mut v621_33_write = v621_33.write_zipper();
    let mut v621_33_cursor = (v621_32).read_zipper();
    let v621_33_origin = v621_33_cursor.path().len();
    for v621_33_byte in v621_33_cursor.child_mask().iter() {
      v621_33_cursor.descend_to_existing_byte(v621_33_byte);
      {
      let v622_2: Space = routine_87(c, &v621_33_cursor.path()[v621_33_origin..(v621_33_origin + 1)], &v621_33_cursor.path()[v621_33_origin..(v621_33_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p0), &v621_33_cursor, &(*s0));
      join_wrapped_into(&mut v621_33_write,&((v622_2).read_zipper()),&[]);
      }
      v621_33_cursor.ascend(1);
    }
    drop(v621_33_cursor);
    drop(v621_33_write);
    drop(v621_32);
    compose(&(v615_28),&(v621_33))
  };
  drop(v615_28);
  let v615_35: Space = unite(&(v615_25),&(v615_34));
  (v615_35).clone()
}

fn routine_83(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v623_10: Space = singleton(&(*p0));
  let v623_11: Space = intersect(&(*CONSTANT_3),&(v623_10));
  let v623_12: Space = if has_head(&(v623_11)) { singleton(&[]) } else { Space::new() };
  drop(v623_11);
  let v623_13: Space = subtract(&(*CONSTANT_0),&(v623_12));
  drop(v623_12);
  let v623_18: Space = intersect(&(*CONSTANT_3),&(v623_10));
  drop(v623_10);
  let v623_19: Space = if has_head(&(v623_18)) { singleton(&[]) } else { Space::new() };
  drop(v623_18);
  let mut v623_20 = Space::new();
  let mut v623_20_write = v623_20.write_zipper();
  let mut v623_20_cursor = (*s0).read_zipper();
  let v623_20_origin = v623_20_cursor.path().len();
  for v623_20_byte in v623_20_cursor.child_mask().iter() {
    v623_20_cursor.descend_to_existing_byte(v623_20_byte);
    {
    let v624_4: Space = if (&(v623_13)).is_empty() { Space::new() } else {
      let v625_2: Path = concat_path(&(*p1),&v623_20_cursor.path()[v623_20_origin..(v623_20_origin + 1)]);
      let mut v625_3 = Space::new();
      let mut v625_3_write = v625_3.write_zipper();
      let v625_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v625_3_arg_1: &[u8] = &(v625_2);
      let v625_3_arg_2: &[u8] = &(*p2);
      let v625_3_arg_3: &[u8] = &(*p3);
      let v625_3_arg_4: &[u8] = &(*p4);
      let v625_3_arg_5: &[u8] = &(*p5);
      let v625_3_arg_6: &[u8] = &(*p6);
      let v625_3_arg_8: &Space = &(&v623_20_cursor).make_map();
      let mut v625_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v625_3_origin = v625_3_cursor.path().len();
      let mut v625_3_more = v625_3_cursor.is_val() || next_value_within(&mut v625_3_cursor,v625_3_origin);
      while v625_3_more {
        {
        let v625_3_depth = v625_3_cursor.path().len();
        let v626_9: Space = routine_83(c, &v625_3_cursor.path()[v625_3_origin..v625_3_depth], &(*v625_3_arg_1), &(*v625_3_arg_2), &(*v625_3_arg_3), &(*v625_3_arg_4), &(*v625_3_arg_5), &(*v625_3_arg_6), &((*v625_3_arg_8).read_zipper()));
        join_wrapped_into(&mut v625_3_write,&((v626_9).read_zipper()),&[]);
        }
        v625_3_more = next_value_within(&mut v625_3_cursor,v625_3_origin);
      }
      drop(v625_3_cursor);
      drop(v625_3_write);
      compose(&(v623_13),&(v625_3))
    };
    let v624_6: Space = if (&(v623_19)).is_empty() { Space::new() } else {
      let v627_2: Path = concat_path(&(*p1),&v623_20_cursor.path()[v623_20_origin..(v623_20_origin + 1)]);
      let mut v627_5 = Space::new();
      let mut v627_5_write = v627_5.write_zipper();
      for v627_5_byte in v623_20_cursor.child_mask().iter() {
        v623_20_cursor.descend_to_existing_byte(v627_5_byte);
        {
        let v628_2: Space = routine_84(c, &v623_20_cursor.path()[(v623_20_origin + 1)..(v623_20_origin + 2)], &v623_20_cursor.path()[(v623_20_origin + 1)..(v623_20_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v627_2), &v623_20_cursor);
        join_wrapped_into(&mut v627_5_write,&((v628_2).read_zipper()),&[]);
        }
        v623_20_cursor.ascend(1);
      }
      drop(v627_5_write);
      drop(v627_2);
      compose(&(v623_19),&(v627_5))
    };
    let v624_7: Space = unite(&(v624_4),&(v624_6));
    join_wrapped_into(&mut v623_20_write,&((v624_7).read_zipper()),&[]);
    }
    v623_20_cursor.ascend(1);
  }
  drop(v623_20_cursor);
  drop(v623_20_write);
  drop(v623_13);
  drop(v623_19);
  (v623_20).clone()
}

fn routine_84(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v629_11: Space = singleton(&(*p1));
  let v629_12: Space = intersect(&(*CONSTANT_3),&(v629_11));
  let v629_13: Space = if has_head(&(v629_12)) { singleton(&[]) } else { Space::new() };
  drop(v629_12);
  let v629_14: Space = subtract(&(*CONSTANT_0),&(v629_13));
  drop(v629_13);
  let v629_25: Space = if (&(v629_14)).is_empty() { Space::new() } else {
    let v630_17: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v630_20: Space = if (&(v630_17)).is_empty() { Space::new() } else {
      let v631_19: Space = routine_88(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*s0));
      compose(&(v630_17),&(v631_19))
    };
    drop(v630_17);
    let mut v630_23 = Space::new();
    let mut v630_23_write = v630_23.write_zipper();
    let mut v630_23_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v630_23_origin = v630_23_cursor.path().len();
    for v630_23_byte in v630_23_cursor.child_mask().iter() {
      v630_23_cursor.descend_to_existing_byte(v630_23_byte);
      {
      let v632_2_arg_0: &[u8] = &v630_23_cursor.path()[v630_23_origin..(v630_23_origin + 1)];
      let v632_2_arg_1: &[u8] = &(*p0);
      let v632_2_arg_2: &[u8] = &(*p2);
      let v632_2_arg_3: &[u8] = &(*p3);
      let v632_2_arg_4: &[u8] = &(*p4);
      let v632_2_arg_5: &[u8] = &(*p5);
      let v632_2_arg_6: &[u8] = &(*p6);
      let v632_2_arg_7: &[u8] = &(*p7);
      let v632_2_arg_9: &Space = &(&(*s0)).make_map();
      let mut v632_2_more = v630_23_cursor.is_val() || next_value_within(&mut v630_23_cursor,(v630_23_origin + 1));
      while v632_2_more {
        {
        let v632_2_depth = v630_23_cursor.path().len();
        let mut v633_10_cursor = (*v632_2_arg_9).read_zipper();
        let v633_10_origin = v633_10_cursor.path().len();
        for v633_10_byte in v633_10_cursor.child_mask().iter() {
          v633_10_cursor.descend_to_existing_byte(v633_10_byte);
          {
          let v634_2: Path = concat_path(&(*v632_2_arg_1),&v633_10_cursor.path()[v633_10_origin..(v633_10_origin + 1)]);
          let v634_3: Space = routine_84(c, &(v634_2), &v630_23_cursor.path()[v630_23_origin..v632_2_depth], &(*v632_2_arg_2), &(*v632_2_arg_3), &(*v632_2_arg_4), &(*v632_2_arg_5), &(*v632_2_arg_6), &(*v632_2_arg_7), &v633_10_cursor);
          drop(v634_2);
          join_wrapped_into(&mut v630_23_write,&((v634_3).read_zipper()),&[]);
          }
          v633_10_cursor.ascend(1);
        }
        drop(v633_10_cursor);
        }
        v632_2_more = next_value_within(&mut v630_23_cursor,(v630_23_origin + 1));
      }
      }
      v630_23_cursor.ascend(1);
    }
    drop(v630_23_cursor);
    drop(v630_23_write);
    let v630_24: Space = unite(&(v630_20),&(v630_23));
    compose(&(v629_14),&(v630_24))
  };
  drop(v629_14);
  let v629_27: Space = intersect(&(*CONSTANT_3),&(v629_11));
  drop(v629_11);
  let v629_28: Space = if has_head(&(v629_27)) { singleton(&[]) } else { Space::new() };
  drop(v629_27);
  let v629_30: Space = if (&(v629_28)).is_empty() { Space::new() } else {
    let mut v635_29 = Space::new();
    let mut v635_29_write = v635_29.write_zipper();
    let mut v635_29_cursor = (*s0).read_zipper();
    let v635_29_origin = v635_29_cursor.path().len();
    for v635_29_byte in v635_29_cursor.child_mask().iter() {
      v635_29_cursor.descend_to_existing_byte(v635_29_byte);
      {
      let v636_2: Space = routine_89(c, &v635_29_cursor.path()[v635_29_origin..(v635_29_origin + 1)], &v635_29_cursor.path()[v635_29_origin..(v635_29_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p0), &v635_29_cursor);
      join_wrapped_into(&mut v635_29_write,&((v636_2).read_zipper()),&[]);
      }
      v635_29_cursor.ascend(1);
    }
    drop(v635_29_cursor);
    drop(v635_29_write);
    compose(&(v629_28),&(v635_29))
  };
  drop(v629_28);
  let v629_31: Space = unite(&(v629_25),&(v629_30));
  (v629_31).clone()
}

fn routine_85(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v637_12: Space = singleton(&(*p0));
  let v637_13: Space = intersect(&(*CONSTANT_3),&(v637_12));
  let v637_14: Space = if has_head(&(v637_13)) { singleton(&[]) } else { Space::new() };
  drop(v637_13);
  let v637_15: Space = subtract(&(*CONSTANT_0),&(v637_14));
  drop(v637_14);
  let v637_20: Space = intersect(&(*CONSTANT_3),&(v637_12));
  drop(v637_12);
  let v637_21: Space = if has_head(&(v637_20)) { singleton(&[]) } else { Space::new() };
  drop(v637_20);
  let v637_24: Path = concat_path(&(*p2),&(*p3));
  let v637_25: Path = concat_path(&(v637_24),&(*p4));
  drop(v637_24);
  let v637_26: Path = concat_path(&(v637_25),&(*p5));
  drop(v637_25);
  let v637_27: Path = concat_path(&(v637_26),&(*p6));
  drop(v637_26);
  let v637_28: Path = concat_path(&(v637_27),&(*p7));
  drop(v637_27);
  let mut v637_29 = Space::new();
  let mut v637_29_write = v637_29.write_zipper();
  let mut v637_29_cursor = (*s0).read_zipper();
  let v637_29_origin = v637_29_cursor.path().len();
  for v637_29_byte in v637_29_cursor.child_mask().iter() {
    v637_29_cursor.descend_to_existing_byte(v637_29_byte);
    {
    let v638_4: Space = if (&(v637_15)).is_empty() { Space::new() } else {
      let v639_2: Path = concat_path(&(*p1),&v637_29_cursor.path()[v637_29_origin..(v637_29_origin + 1)]);
      let mut v639_3 = Space::new();
      let mut v639_3_write = v639_3.write_zipper();
      let v639_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v639_3_arg_1: &[u8] = &(v639_2);
      let v639_3_arg_2: &[u8] = &(*p2);
      let v639_3_arg_3: &[u8] = &(*p3);
      let v639_3_arg_4: &[u8] = &(*p4);
      let v639_3_arg_5: &[u8] = &(*p5);
      let v639_3_arg_6: &[u8] = &(*p6);
      let v639_3_arg_7: &[u8] = &(*p7);
      let v639_3_arg_9: &Space = &(&v637_29_cursor).make_map();
      let v639_3_arg_10: &Space = &(&(*s1)).make_map();
      let mut v639_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v639_3_origin = v639_3_cursor.path().len();
      let mut v639_3_more = v639_3_cursor.is_val() || next_value_within(&mut v639_3_cursor,v639_3_origin);
      while v639_3_more {
        {
        let v639_3_depth = v639_3_cursor.path().len();
        let v640_11: Space = routine_85(c, &v639_3_cursor.path()[v639_3_origin..v639_3_depth], &(*v639_3_arg_1), &(*v639_3_arg_2), &(*v639_3_arg_3), &(*v639_3_arg_4), &(*v639_3_arg_5), &(*v639_3_arg_6), &(*v639_3_arg_7), &((*v639_3_arg_9).read_zipper()), &((*v639_3_arg_10).read_zipper()));
        join_wrapped_into(&mut v639_3_write,&((v640_11).read_zipper()),&[]);
        }
        v639_3_more = next_value_within(&mut v639_3_cursor,v639_3_origin);
      }
      drop(v639_3_cursor);
      drop(v639_3_write);
      compose(&(v637_15),&(v639_3))
    };
    let v638_7: Space = if (&(v637_21)).is_empty() { Space::new() } else {
      let v641_2: Path = concat_path(&(*p1),&v637_29_cursor.path()[v637_29_origin..(v637_29_origin + 1)]);
      let v641_5: Space = routine_43(c, &(v641_2), &(*CONSTANT_17), &(*CONSTANT_11));
      let v641_6: Space = unite(&(*s1),&(v641_5));
      compose(&(v637_21),&(v641_6))
    };
    let v638_8: Space = wrap(&(v638_7),&(v637_28));
    let v642_2: Path = concat_path(&(*p1),&v637_29_cursor.path()[v637_29_origin..(v637_29_origin + 1)]);
    let v638_9: Space = wrap(&(v638_8),&(v642_2));
    let v638_10: Space = unite(&(v638_4),&(v638_9));
    join_wrapped_into(&mut v637_29_write,&((v638_10).read_zipper()),&[]);
    }
    v637_29_cursor.ascend(1);
  }
  drop(v637_29_cursor);
  drop(v637_29_write);
  drop(v637_15);
  drop(v637_21);
  drop(v637_28);
  (v637_29).clone()
}

fn routine_86(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v643_11: Space = singleton(&(*p0));
  let v643_12: Space = intersect(&(*CONSTANT_3),&(v643_11));
  let v643_13: Space = if has_head(&(v643_12)) { singleton(&[]) } else { Space::new() };
  drop(v643_12);
  let v643_14: Space = subtract(&(*CONSTANT_0),&(v643_13));
  drop(v643_13);
  let v643_19: Space = intersect(&(*CONSTANT_3),&(v643_11));
  drop(v643_11);
  let v643_20: Space = if has_head(&(v643_19)) { singleton(&[]) } else { Space::new() };
  drop(v643_19);
  let mut v643_23 = Space::new();
  let mut v643_23_write = v643_23.write_zipper();
  let mut v643_23_cursor = (*s0).read_zipper();
  let v643_23_origin = v643_23_cursor.path().len();
  for v643_23_byte in v643_23_cursor.child_mask().iter() {
    v643_23_cursor.descend_to_existing_byte(v643_23_byte);
    {
    let v644_4: Space = if (&(v643_14)).is_empty() { Space::new() } else {
      let v645_2: Path = concat_path(&(*p1),&v643_23_cursor.path()[v643_23_origin..(v643_23_origin + 1)]);
      let mut v645_3 = Space::new();
      let mut v645_3_write = v645_3.write_zipper();
      let v645_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v645_3_arg_1: &[u8] = &(v645_2);
      let v645_3_arg_2: &[u8] = &(*p2);
      let v645_3_arg_3: &[u8] = &(*p3);
      let v645_3_arg_4: &[u8] = &(*p4);
      let v645_3_arg_5: &[u8] = &(*p5);
      let v645_3_arg_6: &[u8] = &(*p6);
      let v645_3_arg_7: &[u8] = &(*p7);
      let v645_3_arg_9: &Space = &(&v643_23_cursor).make_map();
      let mut v645_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v645_3_origin = v645_3_cursor.path().len();
      let mut v645_3_more = v645_3_cursor.is_val() || next_value_within(&mut v645_3_cursor,v645_3_origin);
      while v645_3_more {
        {
        let v645_3_depth = v645_3_cursor.path().len();
        let v646_10: Space = routine_86(c, &v645_3_cursor.path()[v645_3_origin..v645_3_depth], &(*v645_3_arg_1), &(*v645_3_arg_2), &(*v645_3_arg_3), &(*v645_3_arg_4), &(*v645_3_arg_5), &(*v645_3_arg_6), &(*v645_3_arg_7), &((*v645_3_arg_9).read_zipper()));
        join_wrapped_into(&mut v645_3_write,&((v646_10).read_zipper()),&[]);
        }
        v645_3_more = next_value_within(&mut v645_3_cursor,v645_3_origin);
      }
      drop(v645_3_cursor);
      drop(v645_3_write);
      compose(&(v643_14),&(v645_3))
    };
    let v644_8: Space = if (&(v643_20)).is_empty() { Space::new() } else {
      let v647_2: Path = concat_path(&(*p1),&v643_23_cursor.path()[v643_23_origin..(v643_23_origin + 1)]);
      let v647_6: Space = subtract(&(*CONSTANT_6),&(descend_cursor(cursor_at(&v643_23_cursor,(v643_23_origin + 1)),&(*CONSTANT_11))));
      let mut v647_7 = Space::new();
      let mut v647_7_write = v647_7.write_zipper();
      let mut v647_7_cursor = (v647_6).read_zipper();
      let v647_7_origin = v647_7_cursor.path().len();
      for v647_7_byte in v647_7_cursor.child_mask().iter() {
        v647_7_cursor.descend_to_existing_byte(v647_7_byte);
        {
        let v648_2: Space = routine_87(c, &v647_7_cursor.path()[v647_7_origin..(v647_7_origin + 1)], &v647_7_cursor.path()[v647_7_origin..(v647_7_origin + 1)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v647_2), &v647_7_cursor, &v643_23_cursor);
        join_wrapped_into(&mut v647_7_write,&((v648_2).read_zipper()),&[]);
        }
        v647_7_cursor.ascend(1);
      }
      drop(v647_7_cursor);
      drop(v647_7_write);
      drop(v647_2);
      drop(v647_6);
      compose(&(v643_20),&(v647_7))
    };
    let v644_9: Space = unite(&(v644_4),&(v644_8));
    join_wrapped_into(&mut v643_23_write,&((v644_9).read_zipper()),&[]);
    }
    v643_23_cursor.ascend(1);
  }
  drop(v643_23_cursor);
  drop(v643_23_write);
  drop(v643_14);
  drop(v643_20);
  (v643_23).clone()
}

fn routine_87(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v649_13: Space = singleton(&(*p1));
  let v649_14: Space = intersect(&(*CONSTANT_3),&(v649_13));
  let v649_15: Space = if has_head(&(v649_14)) { singleton(&[]) } else { Space::new() };
  drop(v649_14);
  let v649_16: Space = subtract(&(*CONSTANT_0),&(v649_15));
  drop(v649_15);
  let v649_27: Space = if (&(v649_16)).is_empty() { Space::new() } else {
    let v650_19: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v650_22: Space = if (&(v650_19)).is_empty() { Space::new() } else {
      let v651_21: Space = routine_90(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*s0), &(*s1));
      compose(&(v650_19),&(v651_21))
    };
    drop(v650_19);
    let mut v650_25 = Space::new();
    let mut v650_25_write = v650_25.write_zipper();
    let mut v650_25_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v650_25_origin = v650_25_cursor.path().len();
    for v650_25_byte in v650_25_cursor.child_mask().iter() {
      v650_25_cursor.descend_to_existing_byte(v650_25_byte);
      {
      let v652_2_arg_0: &[u8] = &v650_25_cursor.path()[v650_25_origin..(v650_25_origin + 1)];
      let v652_2_arg_1: &[u8] = &(*p0);
      let v652_2_arg_2: &[u8] = &(*p2);
      let v652_2_arg_3: &[u8] = &(*p3);
      let v652_2_arg_4: &[u8] = &(*p4);
      let v652_2_arg_5: &[u8] = &(*p5);
      let v652_2_arg_6: &[u8] = &(*p6);
      let v652_2_arg_7: &[u8] = &(*p7);
      let v652_2_arg_8: &[u8] = &(*p8);
      let v652_2_arg_10: &Space = &(&(*s0)).make_map();
      let v652_2_arg_11: &Space = &(&(*s1)).make_map();
      let mut v652_2_more = v650_25_cursor.is_val() || next_value_within(&mut v650_25_cursor,(v650_25_origin + 1));
      while v652_2_more {
        {
        let v652_2_depth = v650_25_cursor.path().len();
        let mut v653_12_cursor = (*v652_2_arg_10).read_zipper();
        let v653_12_origin = v653_12_cursor.path().len();
        for v653_12_byte in v653_12_cursor.child_mask().iter() {
          v653_12_cursor.descend_to_existing_byte(v653_12_byte);
          {
          let v654_2: Path = concat_path(&(*v652_2_arg_1),&v653_12_cursor.path()[v653_12_origin..(v653_12_origin + 1)]);
          let v654_3: Space = routine_87(c, &(v654_2), &v650_25_cursor.path()[v650_25_origin..v652_2_depth], &(*v652_2_arg_2), &(*v652_2_arg_3), &(*v652_2_arg_4), &(*v652_2_arg_5), &(*v652_2_arg_6), &(*v652_2_arg_7), &(*v652_2_arg_8), &v653_12_cursor, &((*v652_2_arg_11).read_zipper()));
          drop(v654_2);
          join_wrapped_into(&mut v650_25_write,&((v654_3).read_zipper()),&[]);
          }
          v653_12_cursor.ascend(1);
        }
        drop(v653_12_cursor);
        }
        v652_2_more = next_value_within(&mut v650_25_cursor,(v650_25_origin + 1));
      }
      }
      v650_25_cursor.ascend(1);
    }
    drop(v650_25_cursor);
    drop(v650_25_write);
    let v650_26: Space = unite(&(v650_22),&(v650_25));
    compose(&(v649_16),&(v650_26))
  };
  drop(v649_16);
  let v649_29: Space = intersect(&(*CONSTANT_3),&(v649_13));
  drop(v649_13);
  let v649_30: Space = if has_head(&(v649_29)) { singleton(&[]) } else { Space::new() };
  drop(v649_29);
  let v649_38: Space = if (&(v649_30)).is_empty() { Space::new() } else {
    let v655_35: Space = routine_19(c, &(*CONSTANT_2), &(*CONSTANT_2), &(*CONSTANT_11), &(*p0), &((*CONSTANT_4).read_zipper()));
    let v655_36: Space = intersect(&(*CONSTANT_8),&(v655_35));
    let v655_37: Space = unite(&(v655_36),&(*s1));
    compose(&(v649_30),&(v655_37))
  };
  drop(v649_30);
  let v649_39: Path = concat_path(&(*p2),&(*p3));
  let v649_40: Path = concat_path(&(v649_39),&(*p4));
  drop(v649_39);
  let v649_41: Path = concat_path(&(v649_40),&(*p5));
  drop(v649_40);
  let v649_42: Path = concat_path(&(v649_41),&(*p6));
  drop(v649_41);
  let v649_43: Path = concat_path(&(v649_42),&(*p7));
  drop(v649_42);
  let v649_44: Path = concat_path(&(v649_43),&(*p8));
  drop(v649_43);
  let v649_45: Space = wrap(&(v649_38),&(v649_44));
  drop(v649_44);
  let v649_46: Space = wrap(&(v649_45),&(*p0));
  let v649_47: Space = unite(&(v649_27),&(v649_46));
  (v649_47).clone()
}

fn routine_88(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v656_11: Space = singleton(&(*p0));
  let v656_12: Space = intersect(&(*CONSTANT_3),&(v656_11));
  let v656_13: Space = if has_head(&(v656_12)) { singleton(&[]) } else { Space::new() };
  drop(v656_12);
  let v656_14: Space = subtract(&(*CONSTANT_0),&(v656_13));
  drop(v656_13);
  let v656_19: Space = intersect(&(*CONSTANT_3),&(v656_11));
  drop(v656_11);
  let v656_20: Space = if has_head(&(v656_19)) { singleton(&[]) } else { Space::new() };
  drop(v656_19);
  let mut v656_21 = Space::new();
  let mut v656_21_write = v656_21.write_zipper();
  let mut v656_21_cursor = (*s0).read_zipper();
  let v656_21_origin = v656_21_cursor.path().len();
  for v656_21_byte in v656_21_cursor.child_mask().iter() {
    v656_21_cursor.descend_to_existing_byte(v656_21_byte);
    {
    let v657_4: Space = if (&(v656_14)).is_empty() { Space::new() } else {
      let v658_2: Path = concat_path(&(*p1),&v656_21_cursor.path()[v656_21_origin..(v656_21_origin + 1)]);
      let mut v658_3 = Space::new();
      let mut v658_3_write = v658_3.write_zipper();
      let v658_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v658_3_arg_1: &[u8] = &(v658_2);
      let v658_3_arg_2: &[u8] = &(*p2);
      let v658_3_arg_3: &[u8] = &(*p3);
      let v658_3_arg_4: &[u8] = &(*p4);
      let v658_3_arg_5: &[u8] = &(*p5);
      let v658_3_arg_6: &[u8] = &(*p6);
      let v658_3_arg_7: &[u8] = &(*p7);
      let v658_3_arg_9: &Space = &(&v656_21_cursor).make_map();
      let mut v658_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v658_3_origin = v658_3_cursor.path().len();
      let mut v658_3_more = v658_3_cursor.is_val() || next_value_within(&mut v658_3_cursor,v658_3_origin);
      while v658_3_more {
        {
        let v658_3_depth = v658_3_cursor.path().len();
        let v659_10: Space = routine_88(c, &v658_3_cursor.path()[v658_3_origin..v658_3_depth], &(*v658_3_arg_1), &(*v658_3_arg_2), &(*v658_3_arg_3), &(*v658_3_arg_4), &(*v658_3_arg_5), &(*v658_3_arg_6), &(*v658_3_arg_7), &((*v658_3_arg_9).read_zipper()));
        join_wrapped_into(&mut v658_3_write,&((v659_10).read_zipper()),&[]);
        }
        v658_3_more = next_value_within(&mut v658_3_cursor,v658_3_origin);
      }
      drop(v658_3_cursor);
      drop(v658_3_write);
      compose(&(v656_14),&(v658_3))
    };
    let v657_6: Space = if (&(v656_20)).is_empty() { Space::new() } else {
      let v660_2: Path = concat_path(&(*p1),&v656_21_cursor.path()[v656_21_origin..(v656_21_origin + 1)]);
      let mut v660_5 = Space::new();
      let mut v660_5_write = v660_5.write_zipper();
      for v660_5_byte in v656_21_cursor.child_mask().iter() {
        v656_21_cursor.descend_to_existing_byte(v660_5_byte);
        {
        let v661_2: Space = routine_89(c, &v656_21_cursor.path()[(v656_21_origin + 1)..(v656_21_origin + 2)], &v656_21_cursor.path()[(v656_21_origin + 1)..(v656_21_origin + 2)], &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v660_2), &v656_21_cursor);
        join_wrapped_into(&mut v660_5_write,&((v661_2).read_zipper()),&[]);
        }
        v656_21_cursor.ascend(1);
      }
      drop(v660_5_write);
      drop(v660_2);
      compose(&(v656_20),&(v660_5))
    };
    let v657_7: Space = unite(&(v657_4),&(v657_6));
    join_wrapped_into(&mut v656_21_write,&((v657_7).read_zipper()),&[]);
    }
    v656_21_cursor.ascend(1);
  }
  drop(v656_21_cursor);
  drop(v656_21_write);
  drop(v656_14);
  drop(v656_20);
  (v656_21).clone()
}

fn routine_89(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v662_12: Space = singleton(&(*p1));
  let v662_13: Space = intersect(&(*CONSTANT_3),&(v662_12));
  let v662_14: Space = if has_head(&(v662_13)) { singleton(&[]) } else { Space::new() };
  drop(v662_13);
  let v662_15: Space = subtract(&(*CONSTANT_0),&(v662_14));
  drop(v662_14);
  let v662_26: Space = if (&(v662_15)).is_empty() { Space::new() } else {
    let v663_18: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v663_21: Space = if (&(v663_18)).is_empty() { Space::new() } else {
      let v664_20: Space = routine_91(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*s0));
      compose(&(v663_18),&(v664_20))
    };
    drop(v663_18);
    let mut v663_24 = Space::new();
    let mut v663_24_write = v663_24.write_zipper();
    let mut v663_24_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v663_24_origin = v663_24_cursor.path().len();
    for v663_24_byte in v663_24_cursor.child_mask().iter() {
      v663_24_cursor.descend_to_existing_byte(v663_24_byte);
      {
      let v665_2_arg_0: &[u8] = &v663_24_cursor.path()[v663_24_origin..(v663_24_origin + 1)];
      let v665_2_arg_1: &[u8] = &(*p0);
      let v665_2_arg_2: &[u8] = &(*p2);
      let v665_2_arg_3: &[u8] = &(*p3);
      let v665_2_arg_4: &[u8] = &(*p4);
      let v665_2_arg_5: &[u8] = &(*p5);
      let v665_2_arg_6: &[u8] = &(*p6);
      let v665_2_arg_7: &[u8] = &(*p7);
      let v665_2_arg_8: &[u8] = &(*p8);
      let v665_2_arg_10: &Space = &(&(*s0)).make_map();
      let mut v665_2_more = v663_24_cursor.is_val() || next_value_within(&mut v663_24_cursor,(v663_24_origin + 1));
      while v665_2_more {
        {
        let v665_2_depth = v663_24_cursor.path().len();
        let mut v666_11_cursor = (*v665_2_arg_10).read_zipper();
        let v666_11_origin = v666_11_cursor.path().len();
        for v666_11_byte in v666_11_cursor.child_mask().iter() {
          v666_11_cursor.descend_to_existing_byte(v666_11_byte);
          {
          let v667_2: Path = concat_path(&(*v665_2_arg_1),&v666_11_cursor.path()[v666_11_origin..(v666_11_origin + 1)]);
          let v667_3: Space = routine_89(c, &(v667_2), &v663_24_cursor.path()[v663_24_origin..v665_2_depth], &(*v665_2_arg_2), &(*v665_2_arg_3), &(*v665_2_arg_4), &(*v665_2_arg_5), &(*v665_2_arg_6), &(*v665_2_arg_7), &(*v665_2_arg_8), &v666_11_cursor);
          drop(v667_2);
          join_wrapped_into(&mut v663_24_write,&((v667_3).read_zipper()),&[]);
          }
          v666_11_cursor.ascend(1);
        }
        drop(v666_11_cursor);
        }
        v665_2_more = next_value_within(&mut v663_24_cursor,(v663_24_origin + 1));
      }
      }
      v663_24_cursor.ascend(1);
    }
    drop(v663_24_cursor);
    drop(v663_24_write);
    let v663_25: Space = unite(&(v663_21),&(v663_24));
    compose(&(v662_15),&(v663_25))
  };
  drop(v662_15);
  let v662_28: Space = intersect(&(*CONSTANT_3),&(v662_12));
  drop(v662_12);
  let v662_29: Space = if has_head(&(v662_28)) { singleton(&[]) } else { Space::new() };
  drop(v662_28);
  let v662_38: Space = if (&(v662_29)).is_empty() { Space::new() } else {
    let v668_30: Path = concat_path(&(*p2),&(*p3));
    let v668_31: Path = concat_path(&(v668_30),&(*p4));
    drop(v668_30);
    let v668_32: Path = concat_path(&(v668_31),&(*p5));
    drop(v668_31);
    let v668_33: Path = concat_path(&(v668_32),&(*p6));
    drop(v668_32);
    let v668_34: Path = concat_path(&(v668_33),&(*p7));
    drop(v668_33);
    let v668_35: Path = concat_path(&(v668_34),&(*p8));
    drop(v668_34);
    let v668_36: Path = concat_path(&(v668_35),&(*p0));
    drop(v668_35);
    let v668_37: Space = singleton(&(v668_36));
    drop(v668_36);
    compose(&(v662_29),&(v668_37))
  };
  drop(v662_29);
  let v662_39: Space = unite(&(v662_26),&(v662_38));
  drop(v662_38);
  (v662_39).clone()
}

fn routine_90(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v669_13: Space = singleton(&(*p0));
  let v669_14: Space = intersect(&(*CONSTANT_3),&(v669_13));
  let v669_15: Space = if has_head(&(v669_14)) { singleton(&[]) } else { Space::new() };
  drop(v669_14);
  let v669_16: Space = subtract(&(*CONSTANT_0),&(v669_15));
  drop(v669_15);
  let v669_21: Space = intersect(&(*CONSTANT_3),&(v669_13));
  drop(v669_13);
  let v669_22: Space = if has_head(&(v669_21)) { singleton(&[]) } else { Space::new() };
  drop(v669_21);
  let v669_24: Path = concat_path(&(*p2),&(*p3));
  let v669_25: Path = concat_path(&(v669_24),&(*p4));
  drop(v669_24);
  let v669_26: Path = concat_path(&(v669_25),&(*p5));
  drop(v669_25);
  let v669_27: Path = concat_path(&(v669_26),&(*p6));
  drop(v669_26);
  let v669_28: Path = concat_path(&(v669_27),&(*p7));
  drop(v669_27);
  let v669_29: Path = concat_path(&(v669_28),&(*p8));
  drop(v669_28);
  let mut v669_30 = Space::new();
  let mut v669_30_write = v669_30.write_zipper();
  let mut v669_30_cursor = (*s0).read_zipper();
  let v669_30_origin = v669_30_cursor.path().len();
  for v669_30_byte in v669_30_cursor.child_mask().iter() {
    v669_30_cursor.descend_to_existing_byte(v669_30_byte);
    {
    let v670_4: Space = if (&(v669_16)).is_empty() { Space::new() } else {
      let v671_2: Path = concat_path(&(*p1),&v669_30_cursor.path()[v669_30_origin..(v669_30_origin + 1)]);
      let mut v671_3 = Space::new();
      let mut v671_3_write = v671_3.write_zipper();
      let v671_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v671_3_arg_1: &[u8] = &(v671_2);
      let v671_3_arg_2: &[u8] = &(*p2);
      let v671_3_arg_3: &[u8] = &(*p3);
      let v671_3_arg_4: &[u8] = &(*p4);
      let v671_3_arg_5: &[u8] = &(*p5);
      let v671_3_arg_6: &[u8] = &(*p6);
      let v671_3_arg_7: &[u8] = &(*p7);
      let v671_3_arg_8: &[u8] = &(*p8);
      let v671_3_arg_10: &Space = &(&v669_30_cursor).make_map();
      let v671_3_arg_11: &Space = &(&(*s1)).make_map();
      let mut v671_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v671_3_origin = v671_3_cursor.path().len();
      let mut v671_3_more = v671_3_cursor.is_val() || next_value_within(&mut v671_3_cursor,v671_3_origin);
      while v671_3_more {
        {
        let v671_3_depth = v671_3_cursor.path().len();
        let v672_12: Space = routine_90(c, &v671_3_cursor.path()[v671_3_origin..v671_3_depth], &(*v671_3_arg_1), &(*v671_3_arg_2), &(*v671_3_arg_3), &(*v671_3_arg_4), &(*v671_3_arg_5), &(*v671_3_arg_6), &(*v671_3_arg_7), &(*v671_3_arg_8), &((*v671_3_arg_10).read_zipper()), &((*v671_3_arg_11).read_zipper()));
        join_wrapped_into(&mut v671_3_write,&((v672_12).read_zipper()),&[]);
        }
        v671_3_more = next_value_within(&mut v671_3_cursor,v671_3_origin);
      }
      drop(v671_3_cursor);
      drop(v671_3_write);
      compose(&(v669_16),&(v671_3))
    };
    let v670_7: Space = if (&(v669_22)).is_empty() { Space::new() } else {
      let v673_2: Path = concat_path(&(*p1),&v669_30_cursor.path()[v669_30_origin..(v669_30_origin + 1)]);
      let v673_5: Space = routine_43(c, &(v673_2), &(*CONSTANT_11), &(*CONSTANT_11));
      let v673_6: Space = unite(&(*s1),&(v673_5));
      compose(&(v669_22),&(v673_6))
    };
    let v670_8: Space = wrap(&(v670_7),&(v669_29));
    let v674_2: Path = concat_path(&(*p1),&v669_30_cursor.path()[v669_30_origin..(v669_30_origin + 1)]);
    let v670_9: Space = wrap(&(v670_8),&(v674_2));
    let v670_10: Space = unite(&(v670_4),&(v670_9));
    join_wrapped_into(&mut v669_30_write,&((v670_10).read_zipper()),&[]);
    }
    v669_30_cursor.ascend(1);
  }
  drop(v669_30_cursor);
  drop(v669_30_write);
  drop(v669_16);
  drop(v669_22);
  drop(v669_29);
  (v669_30).clone()
}

fn routine_91(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], p8: &[u8], s0: &View<'_, '_>) -> Space {
  let v675_12: Space = singleton(&(*p0));
  let v675_13: Space = intersect(&(*CONSTANT_3),&(v675_12));
  let v675_14: Space = if has_head(&(v675_13)) { singleton(&[]) } else { Space::new() };
  drop(v675_13);
  let v675_15: Space = subtract(&(*CONSTANT_0),&(v675_14));
  drop(v675_14);
  let v675_20: Space = intersect(&(*CONSTANT_3),&(v675_12));
  drop(v675_12);
  let v675_21: Space = if has_head(&(v675_20)) { singleton(&[]) } else { Space::new() };
  drop(v675_20);
  let v675_22: Path = concat_path(&(*p2),&(*p3));
  let v675_23: Path = concat_path(&(v675_22),&(*p4));
  drop(v675_22);
  let v675_24: Path = concat_path(&(v675_23),&(*p5));
  drop(v675_23);
  let v675_25: Path = concat_path(&(v675_24),&(*p6));
  drop(v675_24);
  let v675_26: Path = concat_path(&(v675_25),&(*p7));
  drop(v675_25);
  let v675_27: Path = concat_path(&(v675_26),&(*p8));
  drop(v675_26);
  let mut v675_28 = Space::new();
  let mut v675_28_write = v675_28.write_zipper();
  let mut v675_28_cursor = (*s0).read_zipper();
  let v675_28_origin = v675_28_cursor.path().len();
  for v675_28_byte in v675_28_cursor.child_mask().iter() {
    v675_28_cursor.descend_to_existing_byte(v675_28_byte);
    {
    let v676_4: Space = if (&(v675_15)).is_empty() { Space::new() } else {
      let v677_2: Path = concat_path(&(*p1),&v675_28_cursor.path()[v675_28_origin..(v675_28_origin + 1)]);
      let mut v677_3 = Space::new();
      let mut v677_3_write = v677_3.write_zipper();
      let v677_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v677_3_arg_1: &[u8] = &(v677_2);
      let v677_3_arg_2: &[u8] = &(*p2);
      let v677_3_arg_3: &[u8] = &(*p3);
      let v677_3_arg_4: &[u8] = &(*p4);
      let v677_3_arg_5: &[u8] = &(*p5);
      let v677_3_arg_6: &[u8] = &(*p6);
      let v677_3_arg_7: &[u8] = &(*p7);
      let v677_3_arg_8: &[u8] = &(*p8);
      let v677_3_arg_10: &Space = &(&v675_28_cursor).make_map();
      let mut v677_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v677_3_origin = v677_3_cursor.path().len();
      let mut v677_3_more = v677_3_cursor.is_val() || next_value_within(&mut v677_3_cursor,v677_3_origin);
      while v677_3_more {
        {
        let v677_3_depth = v677_3_cursor.path().len();
        let v678_11: Space = routine_91(c, &v677_3_cursor.path()[v677_3_origin..v677_3_depth], &(*v677_3_arg_1), &(*v677_3_arg_2), &(*v677_3_arg_3), &(*v677_3_arg_4), &(*v677_3_arg_5), &(*v677_3_arg_6), &(*v677_3_arg_7), &(*v677_3_arg_8), &((*v677_3_arg_10).read_zipper()));
        join_wrapped_into(&mut v677_3_write,&((v678_11).read_zipper()),&[]);
        }
        v677_3_more = next_value_within(&mut v677_3_cursor,v677_3_origin);
      }
      drop(v677_3_cursor);
      drop(v677_3_write);
      compose(&(v675_15),&(v677_3))
    };
    let v676_7: Space = if (&(v675_21)).is_empty() { Space::new() } else {
      let v679_2: Path = concat_path(&(*p1),&v675_28_cursor.path()[v675_28_origin..(v675_28_origin + 1)]);
      let v679_5: Path = concat_path(&(v675_27),&(v679_2));
      drop(v679_2);
      let v679_6: Space = singleton(&(v679_5));
      drop(v679_5);
      compose(&(v675_21),&(v679_6))
    };
    let v676_8: Space = unite(&(v676_4),&(v676_7));
    drop(v676_7);
    join_wrapped_into(&mut v675_28_write,&((v676_8).read_zipper()),&[]);
    }
    v675_28_cursor.ascend(1);
  }
  drop(v675_28_cursor);
  drop(v675_28_write);
  drop(v675_15);
  drop(v675_21);
  drop(v675_27);
  (v675_28).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
