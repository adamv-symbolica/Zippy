#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[49,0]));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[56,0]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[50,0]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[51,0]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[52,0]));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[53,0]));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[54,0]));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[55,0]));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 2 49 0 2 50 0 2 51 0 2 52 0 2 53 0 2 54 0 2 55 0 2 56 0"));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("36 4 49 0 49 0 4 50 0 49 0 4 50 0 50 0 4 51 0 49 0 4 51 0 50 0 4 51 0 51 0 4 52 0 49 0 4 52 0 50 0 4 52 0 51 0 4 52 0 52 0 4 53 0 49 0 4 53 0 50 0 4 53 0 51 0 4 53 0 52 0 4 53 0 53 0 4 54 0 49 0 4 54 0 50 0 4 54 0 51 0 4 54 0 52 0 4 54 0 53 0 4 54 0 54 0 4 55 0 49 0 4 55 0 50 0 4 55 0 51 0 4 55 0 52 0 4 55 0 53 0 4 55 0 54 0 4 55 0 55 0 4 56 0 49 0 4 56 0 50 0 4 56 0 51 0 4 56 0 52 0 4 56 0 53 0 4 56 0 54 0 4 56 0 55 0 4 56 0 56 0"));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("100 6 49 0 49 0 48 0 6 49 0 49 0 50 0 6 49 0 50 0 51 0 6 49 0 51 0 52 0 6 49 0 52 0 53 0 6 49 0 53 0 54 0 6 49 0 54 0 55 0 6 49 0 55 0 56 0 6 49 0 56 0 57 0 6 50 0 49 0 49 0 6 50 0 49 0 51 0 6 50 0 50 0 48 0 6 50 0 50 0 52 0 6 50 0 51 0 53 0 6 50 0 52 0 54 0 6 50 0 53 0 55 0 6 50 0 54 0 56 0 6 50 0 55 0 57 0 7 50 0 56 0 49 48 0 6 51 0 49 0 50 0 6 51 0 49 0 52 0 6 51 0 50 0 49 0 6 51 0 50 0 53 0 6 51 0 51 0 48 0 6 51 0 51 0 54 0 6 51 0 52 0 55 0 6 51 0 53 0 56 0 6 51 0 54 0 57 0 7 51 0 55 0 49 48 0 7 51 0 56 0 49 49 0 6 52 0 49 0 51 0 6 52 0 49 0 53 0 6 52 0 50 0 50 0 6 52 0 50 0 54 0 6 52 0 51 0 49 0 6 52 0 51 0 55 0 6 52 0 52 0 48 0 6 52 0 52 0 56 0 6 52 0 53 0 57 0 7 52 0 54 0 49 48 0 7 52 0 55 0 49 49 0 7 52 0 56 0 49 50 0 6 53 0 49 0 52 0 6 53 0 49 0 54 0 6 53 0 50 0 51 0 6 53 0 50 0 55 0 6 53 0 51 0 50 0 6 53 0 51 0 56 0 6 53 0 52 0 49 0 6 53 0 52 0 57 0 6 53 0 53 0 48 0 7 53 0 53 0 49 48 0 7 53 0 54 0 49 49 0 7 53 0 55 0 49 50 0 7 53 0 56 0 49 51 0 6 54 0 49 0 53 0 6 54 0 49 0 55 0 6 54 0 50 0 52 0 6 54 0 50 0 56 0 6 54 0 51 0 51 0 6 54 0 51 0 57 0 7 54 0 52 0 49 48 0 6 54 0 52 0 50 0 6 54 0 53 0 49 0 7 54 0 53 0 49 49 0 6 54 0 54 0 48 0 7 54 0 54 0 49 50 0 7 54 0 55 0 49 51 0 7 54 0 56 0 49 52 0 6 55 0 49 0 54 0 6 55 0 49 0 56 0 6 55 0 50 0 53 0 6 55 0 50 0 57 0 7 55 0 51 0 49 48 0 6 55 0 51 0 52 0 7 55 0 52 0 49 49 0 6 55 0 52 0 51 0 7 55 0 53 0 49 50 0 6 55 0 53 0 50 0 6 55 0 54 0 49 0 7 55 0 54 0 49 51 0 6 55 0 55 0 48 0 7 55 0 55 0 49 52 0 7 55 0 56 0 49 53 0 6 56 0 49 0 55 0 6 56 0 49 0 57 0 7 56 0 50 0 49 48 0 6 56 0 50 0 54 0 7 56 0 51 0 49 49 0 6 56 0 51 0 53 0 7 56 0 52 0 49 50 0 6 56 0 52 0 52 0 7 56 0 53 0 49 51 0 6 56 0 53 0 51 0 7 56 0 54 0 49 52 0 6 56 0 54 0 50 0 6 56 0 55 0 49 0 7 56 0 55 0 49 53 0 6 56 0 56 0 48 0 7 56 0 56 0 49 54 0"));
static CONSTANT_13: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[49]));
static CONSTANT_14: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[50]));
static CONSTANT_15: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[51]));
static CONSTANT_16: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[52]));
static CONSTANT_17: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[53]));
static CONSTANT_18: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[54]));
static CONSTANT_19: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[55]));
static CONSTANT_20: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[56]));
static CONSTANT_21: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("64 4 49 0 49 0 4 49 0 50 0 4 49 0 51 0 4 49 0 52 0 4 49 0 53 0 4 49 0 54 0 4 49 0 55 0 4 49 0 56 0 4 50 0 49 0 4 50 0 50 0 4 50 0 51 0 4 50 0 52 0 4 50 0 53 0 4 50 0 54 0 4 50 0 55 0 4 50 0 56 0 4 51 0 49 0 4 51 0 50 0 4 51 0 51 0 4 51 0 52 0 4 51 0 53 0 4 51 0 54 0 4 51 0 55 0 4 51 0 56 0 4 52 0 49 0 4 52 0 50 0 4 52 0 51 0 4 52 0 52 0 4 52 0 53 0 4 52 0 54 0 4 52 0 55 0 4 52 0 56 0 4 53 0 49 0 4 53 0 50 0 4 53 0 51 0 4 53 0 52 0 4 53 0 53 0 4 53 0 54 0 4 53 0 55 0 4 53 0 56 0 4 54 0 49 0 4 54 0 50 0 4 54 0 51 0 4 54 0 52 0 4 54 0 53 0 4 54 0 54 0 4 54 0 55 0 4 54 0 56 0 4 55 0 49 0 4 55 0 50 0 4 55 0 51 0 4 55 0 52 0 4 55 0 53 0 4 55 0 54 0 4 55 0 55 0 4 55 0 56 0 4 56 0 49 0 4 56 0 50 0 4 56 0 51 0 4 56 0 52 0 4 56 0 53 0 4 56 0 54 0 4 56 0 55 0 4 56 0 56 0"));
#[inline(never)]
fn native_block_0(c: &mut Context) -> (Space,Space,Space,Space,Space,) {
  let v0_48: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v1_5: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
      let v2_4: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_1), &(*CONSTANT_2));
      compose(&(*CONSTANT_0),&(v2_4))
    };
    let v1_6: Space = wrap(&(v1_5),&(*CONSTANT_1));
    let v1_10: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
      let v3_9: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_1), &(*CONSTANT_2));
      compose(&(*CONSTANT_0),&(v3_9))
    };
    let v1_11: Space = wrap(&(v1_10),&(*CONSTANT_3));
    let v1_12: Space = unite(&(v1_6),&(v1_11));
    let v1_16: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
      let v4_15: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_1), &(*CONSTANT_2));
      compose(&(*CONSTANT_0),&(v4_15))
    };
    let v1_17: Space = wrap(&(v1_16),&(*CONSTANT_4));
    let v1_18: Space = unite(&(v1_12),&(v1_17));
    let v1_22: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
      let v5_21: Space = routine_1(c, &(*CONSTANT_5), &(*CONSTANT_1), &(*CONSTANT_2));
      compose(&(*CONSTANT_0),&(v5_21))
    };
    let v1_23: Space = wrap(&(v1_22),&(*CONSTANT_5));
    let v1_24: Space = unite(&(v1_18),&(v1_23));
    let v1_28: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
      let v6_27: Space = routine_1(c, &(*CONSTANT_6), &(*CONSTANT_1), &(*CONSTANT_2));
      compose(&(*CONSTANT_0),&(v6_27))
    };
    let v1_29: Space = wrap(&(v1_28),&(*CONSTANT_6));
    let v1_30: Space = unite(&(v1_24),&(v1_29));
    let v1_34: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
      let v7_33: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_1), &(*CONSTANT_2));
      compose(&(*CONSTANT_0),&(v7_33))
    };
    let v1_35: Space = wrap(&(v1_34),&(*CONSTANT_7));
    let v1_36: Space = unite(&(v1_30),&(v1_35));
    let v1_40: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
      let v8_39: Space = routine_1(c, &(*CONSTANT_8), &(*CONSTANT_1), &(*CONSTANT_2));
      compose(&(*CONSTANT_0),&(v8_39))
    };
    let v1_41: Space = wrap(&(v1_40),&(*CONSTANT_8));
    let v1_42: Space = unite(&(v1_36),&(v1_41));
    let v1_45: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
      let v9_44: Space = routine_1(c, &(*CONSTANT_2), &(*CONSTANT_1), &(*CONSTANT_2));
      compose(&(*CONSTANT_0),&(v9_44))
    };
    let v1_46: Space = wrap(&(v1_45),&(*CONSTANT_2));
    let v1_47: Space = unite(&(v1_42),&(v1_46));
    compose(&(*CONSTANT_0),&(v1_47))
  };
  let mut v0_63 = Space::new();
  let mut v0_63_write = v0_63.write_zipper();
  let mut v0_63_cursor = (v0_48).read_zipper();
  let v0_63_origin = v0_63_cursor.path().len();
  for v0_63_byte in v0_63_cursor.child_mask().iter() {
    v0_63_cursor.descend_to_existing_byte(v0_63_byte);
    {
    let v10_2: Space = singleton(&v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 1)]);
    let v10_3: Space = intersect(&(*CONSTANT_9),&(v10_2));
    let v10_4: Space = if has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
    drop(v10_3);
    let v10_5: Space = subtract(&(*CONSTANT_0),&(v10_4));
    drop(v10_4);
    let v10_7: Space = if (&(v10_5)).is_empty() { Space::new() } else {
      let mut v11_6 = Space::new();
      let mut v11_6_write = v11_6.write_zipper();
      for v11_6_byte in v0_63_cursor.child_mask().iter() {
        v0_63_cursor.descend_to_existing_byte(v11_6_byte);
        {
        let v12_2: Space = singleton(&v0_63_cursor.path()[(v0_63_origin + 1)..(v0_63_origin + 2)]);
        let v12_3: Space = intersect(&(*CONSTANT_9),&(v12_2));
        let v12_4: Space = if has_head(&(v12_3)) { singleton(&[]) } else { Space::new() };
        drop(v12_3);
        let v12_5: Space = subtract(&(*CONSTANT_0),&(v12_4));
        drop(v12_4);
        let v12_8: Space = if (&(v12_5)).is_empty() { Space::new() } else {
          let v13_7: Space = routine_2(c, &v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 2)], &v0_63_cursor);
          compose(&(v12_5),&(v13_7))
        };
        drop(v12_5);
        let v12_9: Space = intersect(&(*CONSTANT_9),&(v12_2));
        drop(v12_2);
        let v12_10: Space = if has_head(&(v12_9)) { singleton(&[]) } else { Space::new() };
        drop(v12_9);
        let v12_14: Space = if (&(v12_10)).is_empty() { Space::new() } else {
          let v14_12: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v0_63_cursor,(v0_63_origin + 2)),&(*CONSTANT_3))));
          let mut v14_13 = Space::new();
          let mut v14_13_write = v14_13.write_zipper();
          let mut v14_13_cursor = (v14_12).read_zipper();
          let v14_13_origin = v14_13_cursor.path().len();
          for v14_13_byte in v14_13_cursor.child_mask().iter() {
            v14_13_cursor.descend_to_existing_byte(v14_13_byte);
            {
            let v15_2: Space = singleton(&v14_13_cursor.path()[v14_13_origin..(v14_13_origin + 1)]);
            let v15_3: Space = intersect(&(*CONSTANT_9),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
            drop(v15_4);
            let v15_7: Space = if (&(v15_5)).is_empty() { Space::new() } else {
              let v16_6: Space = routine_3(c, &v14_13_cursor.path()[v14_13_origin..(v14_13_origin + 1)], &v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 2)], &v14_13_cursor, &v0_63_cursor);
              compose(&(v15_5),&(v16_6))
            };
            drop(v15_5);
            let v15_8: Space = intersect(&(*CONSTANT_9),&(v15_2));
            drop(v15_2);
            let v15_9: Space = if has_head(&(v15_8)) { singleton(&[]) } else { Space::new() };
            drop(v15_8);
            let v15_11: Space = if (&(v15_9)).is_empty() { Space::new() } else {
              let v17_10: Space = routine_4(c, &v14_13_cursor.path()[v14_13_origin..(v14_13_origin + 1)], &v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 2)], &v14_13_cursor, &v0_63_cursor);
              compose(&(v15_9),&(v17_10))
            };
            drop(v15_9);
            let v15_12: Space = unite(&(v15_7),&(v15_11));
            join_wrapped_into(&mut v14_13_write,&((v15_12).read_zipper()),&[]);
            }
            v14_13_cursor.ascend(1);
          }
          drop(v14_13_cursor);
          drop(v14_13_write);
          drop(v14_12);
          compose(&(v12_10),&(v14_13))
        };
        drop(v12_10);
        let v12_15: Space = unite(&(v12_8),&(v12_14));
        join_wrapped_into(&mut v11_6_write,&((v12_15).read_zipper()),&[]);
        }
        v0_63_cursor.ascend(1);
      }
      drop(v11_6_write);
      compose(&(v10_5),&(v11_6))
    };
    drop(v10_5);
    let v10_8: Space = intersect(&(*CONSTANT_9),&(v10_2));
    drop(v10_2);
    let v10_9: Space = if has_head(&(v10_8)) { singleton(&[]) } else { Space::new() };
    drop(v10_8);
    let v10_13: Space = if (&(v10_9)).is_empty() { Space::new() } else {
      let v18_11: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v0_63_cursor,(v0_63_origin + 1)),&(*CONSTANT_3))));
      let mut v18_12 = Space::new();
      let mut v18_12_write = v18_12.write_zipper();
      let mut v18_12_cursor = (v18_11).read_zipper();
      let v18_12_origin = v18_12_cursor.path().len();
      for v18_12_byte in v18_12_cursor.child_mask().iter() {
        v18_12_cursor.descend_to_existing_byte(v18_12_byte);
        {
        let v19_2: Space = singleton(&v18_12_cursor.path()[v18_12_origin..(v18_12_origin + 1)]);
        let v19_3: Space = intersect(&(*CONSTANT_9),&(v19_2));
        let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
        drop(v19_3);
        let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
        drop(v19_4);
        let v19_7: Space = if (&(v19_5)).is_empty() { Space::new() } else {
          let v20_6: Space = routine_3(c, &v18_12_cursor.path()[v18_12_origin..(v18_12_origin + 1)], &v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 1)], &v18_12_cursor, &v0_63_cursor);
          compose(&(v19_5),&(v20_6))
        };
        drop(v19_5);
        let v19_8: Space = intersect(&(*CONSTANT_9),&(v19_2));
        drop(v19_2);
        let v19_9: Space = if has_head(&(v19_8)) { singleton(&[]) } else { Space::new() };
        drop(v19_8);
        let v19_12: Space = if (&(v19_9)).is_empty() { Space::new() } else {
          let v21_10: Space = routine_1(c, &v18_12_cursor.path()[v18_12_origin..(v18_12_origin + 1)], &(*CONSTANT_3), &(*CONSTANT_2));
          let v21_11: Space = unite(&v0_63_cursor,&(v21_10));
          compose(&(v19_9),&(v21_11))
        };
        drop(v19_9);
        let v19_13: Space = wrap(&(v19_12),&v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 1)]);
        let v19_14: Space = wrap(&(v19_13),&v18_12_cursor.path()[v18_12_origin..(v18_12_origin + 1)]);
        let v19_15: Space = unite(&(v19_7),&(v19_14));
        join_wrapped_into(&mut v18_12_write,&((v19_15).read_zipper()),&[]);
        }
        v18_12_cursor.ascend(1);
      }
      drop(v18_12_cursor);
      drop(v18_12_write);
      drop(v18_11);
      compose(&(v10_9),&(v18_12))
    };
    drop(v10_9);
    let v10_14: Space = unite(&(v10_7),&(v10_13));
    join_wrapped_into(&mut v0_63_write,&((v10_14).read_zipper()),&[]);
    }
    v0_63_cursor.ascend(1);
  }
  drop(v0_63_cursor);
  drop(v0_63_write);
  let mut v0_80 = Space::new();
  let mut v0_80_write = v0_80.write_zipper();
  let mut v0_80_cursor = (v0_63).read_zipper();
  let v0_80_origin = v0_80_cursor.path().len();
  for v0_80_byte in v0_80_cursor.child_mask().iter() {
    v0_80_cursor.descend_to_existing_byte(v0_80_byte);
    {
    let v22_2: Space = singleton(&v0_80_cursor.path()[v0_80_origin..(v0_80_origin + 1)]);
    let v22_3: Space = intersect(&(*CONSTANT_9),&(v22_2));
    let v22_4: Space = if has_head(&(v22_3)) { singleton(&[]) } else { Space::new() };
    drop(v22_3);
    let v22_5: Space = subtract(&(*CONSTANT_0),&(v22_4));
    drop(v22_4);
    let v22_7: Space = if (&(v22_5)).is_empty() { Space::new() } else {
      let mut v23_6 = Space::new();
      let mut v23_6_write = v23_6.write_zipper();
      for v23_6_byte in v0_80_cursor.child_mask().iter() {
        v0_80_cursor.descend_to_existing_byte(v23_6_byte);
        {
        let v24_2: Space = singleton(&v0_80_cursor.path()[(v0_80_origin + 1)..(v0_80_origin + 2)]);
        let v24_3: Space = intersect(&(*CONSTANT_9),&(v24_2));
        let v24_4: Space = if has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
        drop(v24_3);
        let v24_5: Space = subtract(&(*CONSTANT_0),&(v24_4));
        drop(v24_4);
        let v24_8: Space = if (&(v24_5)).is_empty() { Space::new() } else {
          let v25_7: Space = routine_5(c, &v0_80_cursor.path()[v0_80_origin..(v0_80_origin + 2)], &v0_80_cursor);
          compose(&(v24_5),&(v25_7))
        };
        drop(v24_5);
        let v24_9: Space = intersect(&(*CONSTANT_9),&(v24_2));
        drop(v24_2);
        let v24_10: Space = if has_head(&(v24_9)) { singleton(&[]) } else { Space::new() };
        drop(v24_9);
        let v24_12: Space = if (&(v24_10)).is_empty() { Space::new() } else {
          let mut v26_11 = Space::new();
          let mut v26_11_write = v26_11.write_zipper();
          for v26_11_byte in v0_80_cursor.child_mask().iter() {
            v0_80_cursor.descend_to_existing_byte(v26_11_byte);
            {
            let v27_2: Space = singleton(&v0_80_cursor.path()[(v0_80_origin + 2)..(v0_80_origin + 3)]);
            let v27_3: Space = intersect(&(*CONSTANT_9),&(v27_2));
            let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
            drop(v27_3);
            let v27_5: Space = subtract(&(*CONSTANT_0),&(v27_4));
            drop(v27_4);
            let v27_7: Space = if (&(v27_5)).is_empty() { Space::new() } else {
              let v28_6: Space = routine_6(c, &v0_80_cursor.path()[(v0_80_origin + 2)..(v0_80_origin + 3)], &v0_80_cursor.path()[v0_80_origin..(v0_80_origin + 2)], &v0_80_cursor);
              compose(&(v27_5),&(v28_6))
            };
            drop(v27_5);
            let v27_8: Space = intersect(&(*CONSTANT_9),&(v27_2));
            drop(v27_2);
            let v27_9: Space = if has_head(&(v27_8)) { singleton(&[]) } else { Space::new() };
            drop(v27_8);
            let v27_11: Space = if (&(v27_9)).is_empty() { Space::new() } else {
              let v29_10: Space = routine_7(c, &v0_80_cursor.path()[(v0_80_origin + 2)..(v0_80_origin + 3)], &v0_80_cursor.path()[v0_80_origin..(v0_80_origin + 2)], &v0_80_cursor);
              compose(&(v27_9),&(v29_10))
            };
            drop(v27_9);
            let v27_12: Space = unite(&(v27_7),&(v27_11));
            join_wrapped_into(&mut v26_11_write,&((v27_12).read_zipper()),&[]);
            }
            v0_80_cursor.ascend(1);
          }
          drop(v26_11_write);
          compose(&(v24_10),&(v26_11))
        };
        drop(v24_10);
        let v24_13: Space = unite(&(v24_8),&(v24_12));
        join_wrapped_into(&mut v23_6_write,&((v24_13).read_zipper()),&[]);
        }
        v0_80_cursor.ascend(1);
      }
      drop(v23_6_write);
      compose(&(v22_5),&(v23_6))
    };
    drop(v22_5);
    let v22_8: Space = intersect(&(*CONSTANT_9),&(v22_2));
    drop(v22_2);
    let v22_9: Space = if has_head(&(v22_8)) { singleton(&[]) } else { Space::new() };
    drop(v22_8);
    let v22_11: Space = if (&(v22_9)).is_empty() { Space::new() } else {
      let mut v30_10 = Space::new();
      let mut v30_10_write = v30_10.write_zipper();
      for v30_10_byte in v0_80_cursor.child_mask().iter() {
        v0_80_cursor.descend_to_existing_byte(v30_10_byte);
        {
        let v31_2: Space = singleton(&v0_80_cursor.path()[(v0_80_origin + 1)..(v0_80_origin + 2)]);
        let v31_3: Space = intersect(&(*CONSTANT_9),&(v31_2));
        let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
        drop(v31_3);
        let v31_5: Space = subtract(&(*CONSTANT_0),&(v31_4));
        drop(v31_4);
        let v31_7: Space = if (&(v31_5)).is_empty() { Space::new() } else {
          let v32_6: Space = routine_6(c, &v0_80_cursor.path()[(v0_80_origin + 1)..(v0_80_origin + 2)], &v0_80_cursor.path()[v0_80_origin..(v0_80_origin + 1)], &v0_80_cursor);
          compose(&(v31_5),&(v32_6))
        };
        drop(v31_5);
        let v31_8: Space = intersect(&(*CONSTANT_9),&(v31_2));
        drop(v31_2);
        let v31_9: Space = if has_head(&(v31_8)) { singleton(&[]) } else { Space::new() };
        drop(v31_8);
        let v31_13: Space = if (&(v31_9)).is_empty() { Space::new() } else {
          let v33_11: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v0_80_cursor,(v0_80_origin + 2)),&(*CONSTANT_4))));
          let mut v33_12 = Space::new();
          let mut v33_12_write = v33_12.write_zipper();
          let mut v33_12_cursor = (v33_11).read_zipper();
          let v33_12_origin = v33_12_cursor.path().len();
          for v33_12_byte in v33_12_cursor.child_mask().iter() {
            v33_12_cursor.descend_to_existing_byte(v33_12_byte);
            {
            let v34_2: Space = singleton(&v33_12_cursor.path()[v33_12_origin..(v33_12_origin + 1)]);
            let v34_3: Space = intersect(&(*CONSTANT_9),&(v34_2));
            let v34_4: Space = if has_head(&(v34_3)) { singleton(&[]) } else { Space::new() };
            drop(v34_3);
            let v34_5: Space = subtract(&(*CONSTANT_0),&(v34_4));
            drop(v34_4);
            let v34_7: Space = if (&(v34_5)).is_empty() { Space::new() } else {
              let v35_6: Space = routine_8(c, &v33_12_cursor.path()[v33_12_origin..(v33_12_origin + 1)], &v0_80_cursor.path()[v0_80_origin..(v0_80_origin + 1)], &v0_80_cursor.path()[(v0_80_origin + 1)..(v0_80_origin + 2)], &v33_12_cursor, &v0_80_cursor);
              compose(&(v34_5),&(v35_6))
            };
            drop(v34_5);
            let v34_8: Space = intersect(&(*CONSTANT_9),&(v34_2));
            drop(v34_2);
            let v34_9: Space = if has_head(&(v34_8)) { singleton(&[]) } else { Space::new() };
            drop(v34_8);
            let v34_11: Space = if (&(v34_9)).is_empty() { Space::new() } else {
              let v36_10: Space = routine_9(c, &v33_12_cursor.path()[v33_12_origin..(v33_12_origin + 1)], &v0_80_cursor.path()[v0_80_origin..(v0_80_origin + 1)], &v0_80_cursor.path()[(v0_80_origin + 1)..(v0_80_origin + 2)], &v33_12_cursor, &v0_80_cursor);
              compose(&(v34_9),&(v36_10))
            };
            drop(v34_9);
            let v34_12: Space = unite(&(v34_7),&(v34_11));
            join_wrapped_into(&mut v33_12_write,&((v34_12).read_zipper()),&[]);
            }
            v33_12_cursor.ascend(1);
          }
          drop(v33_12_cursor);
          drop(v33_12_write);
          drop(v33_11);
          compose(&(v31_9),&(v33_12))
        };
        drop(v31_9);
        let v31_14: Space = unite(&(v31_7),&(v31_13));
        join_wrapped_into(&mut v30_10_write,&((v31_14).read_zipper()),&[]);
        }
        v0_80_cursor.ascend(1);
      }
      drop(v30_10_write);
      compose(&(v22_9),&(v30_10))
    };
    drop(v22_9);
    let v22_12: Space = unite(&(v22_7),&(v22_11));
    join_wrapped_into(&mut v0_80_write,&((v22_12).read_zipper()),&[]);
    }
    v0_80_cursor.ascend(1);
  }
  drop(v0_80_cursor);
  drop(v0_80_write);
  let mut v0_96 = Space::new();
  let mut v0_96_write = v0_96.write_zipper();
  let mut v0_96_cursor = (v0_80).read_zipper();
  let v0_96_origin = v0_96_cursor.path().len();
  for v0_96_byte in v0_96_cursor.child_mask().iter() {
    v0_96_cursor.descend_to_existing_byte(v0_96_byte);
    {
    let v37_2: Space = singleton(&v0_96_cursor.path()[v0_96_origin..(v0_96_origin + 1)]);
    let v37_3: Space = intersect(&(*CONSTANT_9),&(v37_2));
    let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
    drop(v37_3);
    let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
    drop(v37_4);
    let v37_7: Space = if (&(v37_5)).is_empty() { Space::new() } else {
      let mut v38_6 = Space::new();
      let mut v38_6_write = v38_6.write_zipper();
      for v38_6_byte in v0_96_cursor.child_mask().iter() {
        v0_96_cursor.descend_to_existing_byte(v38_6_byte);
        {
        let v39_2: Space = singleton(&v0_96_cursor.path()[(v0_96_origin + 1)..(v0_96_origin + 2)]);
        let v39_3: Space = intersect(&(*CONSTANT_9),&(v39_2));
        let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_8: Space = if (&(v39_5)).is_empty() { Space::new() } else {
          let v40_7: Space = routine_10(c, &v0_96_cursor.path()[v0_96_origin..(v0_96_origin + 2)], &v0_96_cursor);
          compose(&(v39_5),&(v40_7))
        };
        drop(v39_5);
        let v39_9: Space = intersect(&(*CONSTANT_9),&(v39_2));
        drop(v39_2);
        let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
        drop(v39_9);
        let v39_12: Space = if (&(v39_10)).is_empty() { Space::new() } else {
          let mut v41_11 = Space::new();
          let mut v41_11_write = v41_11.write_zipper();
          for v41_11_byte in v0_96_cursor.child_mask().iter() {
            v0_96_cursor.descend_to_existing_byte(v41_11_byte);
            {
            let v42_2: Space = singleton(&v0_96_cursor.path()[(v0_96_origin + 2)..(v0_96_origin + 3)]);
            let v42_3: Space = intersect(&(*CONSTANT_9),&(v42_2));
            let v42_4: Space = if has_head(&(v42_3)) { singleton(&[]) } else { Space::new() };
            drop(v42_3);
            let v42_5: Space = subtract(&(*CONSTANT_0),&(v42_4));
            drop(v42_4);
            let v42_7: Space = if (&(v42_5)).is_empty() { Space::new() } else {
              let v43_6: Space = routine_11(c, &v0_96_cursor.path()[(v0_96_origin + 2)..(v0_96_origin + 3)], &v0_96_cursor.path()[v0_96_origin..(v0_96_origin + 2)], &v0_96_cursor);
              compose(&(v42_5),&(v43_6))
            };
            drop(v42_5);
            let v42_8: Space = intersect(&(*CONSTANT_9),&(v42_2));
            drop(v42_2);
            let v42_9: Space = if has_head(&(v42_8)) { singleton(&[]) } else { Space::new() };
            drop(v42_8);
            let v42_11: Space = if (&(v42_9)).is_empty() { Space::new() } else {
              let v44_10: Space = routine_12(c, &v0_96_cursor.path()[(v0_96_origin + 2)..(v0_96_origin + 3)], &v0_96_cursor.path()[v0_96_origin..(v0_96_origin + 2)], &v0_96_cursor);
              compose(&(v42_9),&(v44_10))
            };
            drop(v42_9);
            let v42_12: Space = unite(&(v42_7),&(v42_11));
            join_wrapped_into(&mut v41_11_write,&((v42_12).read_zipper()),&[]);
            }
            v0_96_cursor.ascend(1);
          }
          drop(v41_11_write);
          compose(&(v39_10),&(v41_11))
        };
        drop(v39_10);
        let v39_13: Space = unite(&(v39_8),&(v39_12));
        join_wrapped_into(&mut v38_6_write,&((v39_13).read_zipper()),&[]);
        }
        v0_96_cursor.ascend(1);
      }
      drop(v38_6_write);
      compose(&(v37_5),&(v38_6))
    };
    drop(v37_5);
    let v37_8: Space = intersect(&(*CONSTANT_9),&(v37_2));
    drop(v37_2);
    let v37_9: Space = if has_head(&(v37_8)) { singleton(&[]) } else { Space::new() };
    drop(v37_8);
    let v37_11: Space = if (&(v37_9)).is_empty() { Space::new() } else {
      let mut v45_10 = Space::new();
      let mut v45_10_write = v45_10.write_zipper();
      for v45_10_byte in v0_96_cursor.child_mask().iter() {
        v0_96_cursor.descend_to_existing_byte(v45_10_byte);
        {
        let v46_2: Space = singleton(&v0_96_cursor.path()[(v0_96_origin + 1)..(v0_96_origin + 2)]);
        let v46_3: Space = intersect(&(*CONSTANT_9),&(v46_2));
        let v46_4: Space = if has_head(&(v46_3)) { singleton(&[]) } else { Space::new() };
        drop(v46_3);
        let v46_5: Space = subtract(&(*CONSTANT_0),&(v46_4));
        drop(v46_4);
        let v46_7: Space = if (&(v46_5)).is_empty() { Space::new() } else {
          let v47_6: Space = routine_11(c, &v0_96_cursor.path()[(v0_96_origin + 1)..(v0_96_origin + 2)], &v0_96_cursor.path()[v0_96_origin..(v0_96_origin + 1)], &v0_96_cursor);
          compose(&(v46_5),&(v47_6))
        };
        drop(v46_5);
        let v46_8: Space = intersect(&(*CONSTANT_9),&(v46_2));
        drop(v46_2);
        let v46_9: Space = if has_head(&(v46_8)) { singleton(&[]) } else { Space::new() };
        drop(v46_8);
        let v46_11: Space = if (&(v46_9)).is_empty() { Space::new() } else {
          let mut v48_10 = Space::new();
          let mut v48_10_write = v48_10.write_zipper();
          for v48_10_byte in v0_96_cursor.child_mask().iter() {
            v0_96_cursor.descend_to_existing_byte(v48_10_byte);
            {
            let v49_2: Space = singleton(&v0_96_cursor.path()[(v0_96_origin + 2)..(v0_96_origin + 3)]);
            let v49_3: Space = intersect(&(*CONSTANT_9),&(v49_2));
            let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
            drop(v49_3);
            let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
            drop(v49_4);
            let v49_7: Space = if (&(v49_5)).is_empty() { Space::new() } else {
              let v50_6: Space = routine_13(c, &v0_96_cursor.path()[(v0_96_origin + 2)..(v0_96_origin + 3)], &v0_96_cursor.path()[v0_96_origin..(v0_96_origin + 1)], &v0_96_cursor.path()[(v0_96_origin + 1)..(v0_96_origin + 2)], &v0_96_cursor);
              compose(&(v49_5),&(v50_6))
            };
            drop(v49_5);
            let v49_8: Space = intersect(&(*CONSTANT_9),&(v49_2));
            drop(v49_2);
            let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
            drop(v49_8);
            let v49_11: Space = if (&(v49_9)).is_empty() { Space::new() } else {
              let v51_10: Space = routine_14(c, &v0_96_cursor.path()[(v0_96_origin + 2)..(v0_96_origin + 3)], &v0_96_cursor.path()[v0_96_origin..(v0_96_origin + 1)], &v0_96_cursor.path()[(v0_96_origin + 1)..(v0_96_origin + 2)], &v0_96_cursor);
              compose(&(v49_9),&(v51_10))
            };
            drop(v49_9);
            let v49_12: Space = unite(&(v49_7),&(v49_11));
            join_wrapped_into(&mut v48_10_write,&((v49_12).read_zipper()),&[]);
            }
            v0_96_cursor.ascend(1);
          }
          drop(v48_10_write);
          compose(&(v46_9),&(v48_10))
        };
        drop(v46_9);
        let v46_12: Space = unite(&(v46_7),&(v46_11));
        join_wrapped_into(&mut v45_10_write,&((v46_12).read_zipper()),&[]);
        }
        v0_96_cursor.ascend(1);
      }
      drop(v45_10_write);
      compose(&(v37_9),&(v45_10))
    };
    drop(v37_9);
    let v37_12: Space = unite(&(v37_7),&(v37_11));
    join_wrapped_into(&mut v0_96_write,&((v37_12).read_zipper()),&[]);
    }
    v0_96_cursor.ascend(1);
  }
  drop(v0_96_cursor);
  drop(v0_96_write);
  let mut v0_112 = Space::new();
  let mut v0_112_write = v0_112.write_zipper();
  let mut v0_112_cursor = (v0_96).read_zipper();
  let v0_112_origin = v0_112_cursor.path().len();
  for v0_112_byte in v0_112_cursor.child_mask().iter() {
    v0_112_cursor.descend_to_existing_byte(v0_112_byte);
    {
    let v52_2: Space = singleton(&v0_112_cursor.path()[v0_112_origin..(v0_112_origin + 1)]);
    let v52_3: Space = intersect(&(*CONSTANT_9),&(v52_2));
    let v52_4: Space = if has_head(&(v52_3)) { singleton(&[]) } else { Space::new() };
    drop(v52_3);
    let v52_5: Space = subtract(&(*CONSTANT_0),&(v52_4));
    drop(v52_4);
    let v52_7: Space = if (&(v52_5)).is_empty() { Space::new() } else {
      let mut v53_6 = Space::new();
      let mut v53_6_write = v53_6.write_zipper();
      for v53_6_byte in v0_112_cursor.child_mask().iter() {
        v0_112_cursor.descend_to_existing_byte(v53_6_byte);
        {
        let v54_2: Space = singleton(&v0_112_cursor.path()[(v0_112_origin + 1)..(v0_112_origin + 2)]);
        let v54_3: Space = intersect(&(*CONSTANT_9),&(v54_2));
        let v54_4: Space = if has_head(&(v54_3)) { singleton(&[]) } else { Space::new() };
        drop(v54_3);
        let v54_5: Space = subtract(&(*CONSTANT_0),&(v54_4));
        drop(v54_4);
        let v54_8: Space = if (&(v54_5)).is_empty() { Space::new() } else {
          let v55_7: Space = routine_15(c, &v0_112_cursor.path()[v0_112_origin..(v0_112_origin + 2)], &v0_112_cursor);
          compose(&(v54_5),&(v55_7))
        };
        drop(v54_5);
        let v54_9: Space = intersect(&(*CONSTANT_9),&(v54_2));
        drop(v54_2);
        let v54_10: Space = if has_head(&(v54_9)) { singleton(&[]) } else { Space::new() };
        drop(v54_9);
        let v54_12: Space = if (&(v54_10)).is_empty() { Space::new() } else {
          let mut v56_11 = Space::new();
          let mut v56_11_write = v56_11.write_zipper();
          for v56_11_byte in v0_112_cursor.child_mask().iter() {
            v0_112_cursor.descend_to_existing_byte(v56_11_byte);
            {
            let v57_2: Space = singleton(&v0_112_cursor.path()[(v0_112_origin + 2)..(v0_112_origin + 3)]);
            let v57_3: Space = intersect(&(*CONSTANT_9),&(v57_2));
            let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
            drop(v57_3);
            let v57_5: Space = subtract(&(*CONSTANT_0),&(v57_4));
            drop(v57_4);
            let v57_7: Space = if (&(v57_5)).is_empty() { Space::new() } else {
              let v58_6: Space = routine_16(c, &v0_112_cursor.path()[(v0_112_origin + 2)..(v0_112_origin + 3)], &v0_112_cursor.path()[v0_112_origin..(v0_112_origin + 2)], &v0_112_cursor);
              compose(&(v57_5),&(v58_6))
            };
            drop(v57_5);
            let v57_8: Space = intersect(&(*CONSTANT_9),&(v57_2));
            drop(v57_2);
            let v57_9: Space = if has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
            drop(v57_8);
            let v57_11: Space = if (&(v57_9)).is_empty() { Space::new() } else {
              let v59_10: Space = routine_17(c, &v0_112_cursor.path()[(v0_112_origin + 2)..(v0_112_origin + 3)], &v0_112_cursor.path()[v0_112_origin..(v0_112_origin + 2)], &v0_112_cursor);
              compose(&(v57_9),&(v59_10))
            };
            drop(v57_9);
            let v57_12: Space = unite(&(v57_7),&(v57_11));
            join_wrapped_into(&mut v56_11_write,&((v57_12).read_zipper()),&[]);
            }
            v0_112_cursor.ascend(1);
          }
          drop(v56_11_write);
          compose(&(v54_10),&(v56_11))
        };
        drop(v54_10);
        let v54_13: Space = unite(&(v54_8),&(v54_12));
        join_wrapped_into(&mut v53_6_write,&((v54_13).read_zipper()),&[]);
        }
        v0_112_cursor.ascend(1);
      }
      drop(v53_6_write);
      compose(&(v52_5),&(v53_6))
    };
    drop(v52_5);
    let v52_8: Space = intersect(&(*CONSTANT_9),&(v52_2));
    drop(v52_2);
    let v52_9: Space = if has_head(&(v52_8)) { singleton(&[]) } else { Space::new() };
    drop(v52_8);
    let v52_11: Space = if (&(v52_9)).is_empty() { Space::new() } else {
      let mut v60_10 = Space::new();
      let mut v60_10_write = v60_10.write_zipper();
      for v60_10_byte in v0_112_cursor.child_mask().iter() {
        v0_112_cursor.descend_to_existing_byte(v60_10_byte);
        {
        let v61_2: Space = singleton(&v0_112_cursor.path()[(v0_112_origin + 1)..(v0_112_origin + 2)]);
        let v61_3: Space = intersect(&(*CONSTANT_9),&(v61_2));
        let v61_4: Space = if has_head(&(v61_3)) { singleton(&[]) } else { Space::new() };
        drop(v61_3);
        let v61_5: Space = subtract(&(*CONSTANT_0),&(v61_4));
        drop(v61_4);
        let v61_7: Space = if (&(v61_5)).is_empty() { Space::new() } else {
          let v62_6: Space = routine_16(c, &v0_112_cursor.path()[(v0_112_origin + 1)..(v0_112_origin + 2)], &v0_112_cursor.path()[v0_112_origin..(v0_112_origin + 1)], &v0_112_cursor);
          compose(&(v61_5),&(v62_6))
        };
        drop(v61_5);
        let v61_8: Space = intersect(&(*CONSTANT_9),&(v61_2));
        drop(v61_2);
        let v61_9: Space = if has_head(&(v61_8)) { singleton(&[]) } else { Space::new() };
        drop(v61_8);
        let v61_11: Space = if (&(v61_9)).is_empty() { Space::new() } else {
          let mut v63_10 = Space::new();
          let mut v63_10_write = v63_10.write_zipper();
          for v63_10_byte in v0_112_cursor.child_mask().iter() {
            v0_112_cursor.descend_to_existing_byte(v63_10_byte);
            {
            let v64_2: Space = singleton(&v0_112_cursor.path()[(v0_112_origin + 2)..(v0_112_origin + 3)]);
            let v64_3: Space = intersect(&(*CONSTANT_9),&(v64_2));
            let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
            drop(v64_3);
            let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
            drop(v64_4);
            let v64_7: Space = if (&(v64_5)).is_empty() { Space::new() } else {
              let v65_6: Space = routine_18(c, &v0_112_cursor.path()[(v0_112_origin + 2)..(v0_112_origin + 3)], &v0_112_cursor.path()[(v0_112_origin + 1)..(v0_112_origin + 2)], &v0_112_cursor.path()[v0_112_origin..(v0_112_origin + 1)], &v0_112_cursor);
              compose(&(v64_5),&(v65_6))
            };
            drop(v64_5);
            let v64_8: Space = intersect(&(*CONSTANT_9),&(v64_2));
            drop(v64_2);
            let v64_9: Space = if has_head(&(v64_8)) { singleton(&[]) } else { Space::new() };
            drop(v64_8);
            let v64_11: Space = if (&(v64_9)).is_empty() { Space::new() } else {
              let v66_10: Space = routine_19(c, &v0_112_cursor.path()[(v0_112_origin + 2)..(v0_112_origin + 3)], &v0_112_cursor.path()[(v0_112_origin + 1)..(v0_112_origin + 2)], &v0_112_cursor.path()[v0_112_origin..(v0_112_origin + 1)], &v0_112_cursor);
              compose(&(v64_9),&(v66_10))
            };
            drop(v64_9);
            let v64_12: Space = unite(&(v64_7),&(v64_11));
            join_wrapped_into(&mut v63_10_write,&((v64_12).read_zipper()),&[]);
            }
            v0_112_cursor.ascend(1);
          }
          drop(v63_10_write);
          compose(&(v61_9),&(v63_10))
        };
        drop(v61_9);
        let v61_12: Space = unite(&(v61_7),&(v61_11));
        join_wrapped_into(&mut v60_10_write,&((v61_12).read_zipper()),&[]);
        }
        v0_112_cursor.ascend(1);
      }
      drop(v60_10_write);
      compose(&(v52_9),&(v60_10))
    };
    drop(v52_9);
    let v52_12: Space = unite(&(v52_7),&(v52_11));
    join_wrapped_into(&mut v0_112_write,&((v52_12).read_zipper()),&[]);
    }
    v0_112_cursor.ascend(1);
  }
  drop(v0_112_cursor);
  drop(v0_112_write);

((v0_112).clone(),(v0_48).clone(),(v0_63).clone(),(v0_80).clone(),(v0_96).clone(),)
}

#[inline(never)]
fn native_block_1(c: &mut Context,capture_0: &Space) -> (Space,Space,Space,Space,) {
  let mut v0_128 = Space::new();
  let mut v0_128_write = v0_128.write_zipper();
  let mut v0_128_cursor = ((*capture_0)).read_zipper();
  let v0_128_origin = v0_128_cursor.path().len();
  for v0_128_byte in v0_128_cursor.child_mask().iter() {
    v0_128_cursor.descend_to_existing_byte(v0_128_byte);
    {
    let v67_2: Space = singleton(&v0_128_cursor.path()[v0_128_origin..(v0_128_origin + 1)]);
    let v67_3: Space = intersect(&(*CONSTANT_9),&(v67_2));
    let v67_4: Space = if has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
    drop(v67_3);
    let v67_5: Space = subtract(&(*CONSTANT_0),&(v67_4));
    drop(v67_4);
    let v67_7: Space = if (&(v67_5)).is_empty() { Space::new() } else {
      let mut v68_6 = Space::new();
      let mut v68_6_write = v68_6.write_zipper();
      for v68_6_byte in v0_128_cursor.child_mask().iter() {
        v0_128_cursor.descend_to_existing_byte(v68_6_byte);
        {
        let v69_2: Space = singleton(&v0_128_cursor.path()[(v0_128_origin + 1)..(v0_128_origin + 2)]);
        let v69_3: Space = intersect(&(*CONSTANT_9),&(v69_2));
        let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
        drop(v69_3);
        let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
        drop(v69_4);
        let v69_8: Space = if (&(v69_5)).is_empty() { Space::new() } else {
          let v70_7: Space = routine_20(c, &v0_128_cursor.path()[v0_128_origin..(v0_128_origin + 2)], &v0_128_cursor);
          compose(&(v69_5),&(v70_7))
        };
        drop(v69_5);
        let v69_9: Space = intersect(&(*CONSTANT_9),&(v69_2));
        drop(v69_2);
        let v69_10: Space = if has_head(&(v69_9)) { singleton(&[]) } else { Space::new() };
        drop(v69_9);
        let v69_12: Space = if (&(v69_10)).is_empty() { Space::new() } else {
          let mut v71_11 = Space::new();
          let mut v71_11_write = v71_11.write_zipper();
          for v71_11_byte in v0_128_cursor.child_mask().iter() {
            v0_128_cursor.descend_to_existing_byte(v71_11_byte);
            {
            let v72_2: Space = singleton(&v0_128_cursor.path()[(v0_128_origin + 2)..(v0_128_origin + 3)]);
            let v72_3: Space = intersect(&(*CONSTANT_9),&(v72_2));
            let v72_4: Space = if has_head(&(v72_3)) { singleton(&[]) } else { Space::new() };
            drop(v72_3);
            let v72_5: Space = subtract(&(*CONSTANT_0),&(v72_4));
            drop(v72_4);
            let v72_7: Space = if (&(v72_5)).is_empty() { Space::new() } else {
              let v73_6: Space = routine_21(c, &v0_128_cursor.path()[(v0_128_origin + 2)..(v0_128_origin + 3)], &v0_128_cursor.path()[v0_128_origin..(v0_128_origin + 2)], &v0_128_cursor);
              compose(&(v72_5),&(v73_6))
            };
            drop(v72_5);
            let v72_8: Space = intersect(&(*CONSTANT_9),&(v72_2));
            drop(v72_2);
            let v72_9: Space = if has_head(&(v72_8)) { singleton(&[]) } else { Space::new() };
            drop(v72_8);
            let v72_11: Space = if (&(v72_9)).is_empty() { Space::new() } else {
              let v74_10: Space = routine_22(c, &v0_128_cursor.path()[(v0_128_origin + 2)..(v0_128_origin + 3)], &v0_128_cursor.path()[v0_128_origin..(v0_128_origin + 2)], &v0_128_cursor);
              compose(&(v72_9),&(v74_10))
            };
            drop(v72_9);
            let v72_12: Space = unite(&(v72_7),&(v72_11));
            join_wrapped_into(&mut v71_11_write,&((v72_12).read_zipper()),&[]);
            }
            v0_128_cursor.ascend(1);
          }
          drop(v71_11_write);
          compose(&(v69_10),&(v71_11))
        };
        drop(v69_10);
        let v69_13: Space = unite(&(v69_8),&(v69_12));
        join_wrapped_into(&mut v68_6_write,&((v69_13).read_zipper()),&[]);
        }
        v0_128_cursor.ascend(1);
      }
      drop(v68_6_write);
      compose(&(v67_5),&(v68_6))
    };
    drop(v67_5);
    let v67_8: Space = intersect(&(*CONSTANT_9),&(v67_2));
    drop(v67_2);
    let v67_9: Space = if has_head(&(v67_8)) { singleton(&[]) } else { Space::new() };
    drop(v67_8);
    let v67_11: Space = if (&(v67_9)).is_empty() { Space::new() } else {
      let mut v75_10 = Space::new();
      let mut v75_10_write = v75_10.write_zipper();
      for v75_10_byte in v0_128_cursor.child_mask().iter() {
        v0_128_cursor.descend_to_existing_byte(v75_10_byte);
        {
        let v76_2: Space = singleton(&v0_128_cursor.path()[(v0_128_origin + 1)..(v0_128_origin + 2)]);
        let v76_3: Space = intersect(&(*CONSTANT_9),&(v76_2));
        let v76_4: Space = if has_head(&(v76_3)) { singleton(&[]) } else { Space::new() };
        drop(v76_3);
        let v76_5: Space = subtract(&(*CONSTANT_0),&(v76_4));
        drop(v76_4);
        let v76_7: Space = if (&(v76_5)).is_empty() { Space::new() } else {
          let v77_6: Space = routine_21(c, &v0_128_cursor.path()[(v0_128_origin + 1)..(v0_128_origin + 2)], &v0_128_cursor.path()[v0_128_origin..(v0_128_origin + 1)], &v0_128_cursor);
          compose(&(v76_5),&(v77_6))
        };
        drop(v76_5);
        let v76_8: Space = intersect(&(*CONSTANT_9),&(v76_2));
        drop(v76_2);
        let v76_9: Space = if has_head(&(v76_8)) { singleton(&[]) } else { Space::new() };
        drop(v76_8);
        let v76_11: Space = if (&(v76_9)).is_empty() { Space::new() } else {
          let mut v78_10 = Space::new();
          let mut v78_10_write = v78_10.write_zipper();
          for v78_10_byte in v0_128_cursor.child_mask().iter() {
            v0_128_cursor.descend_to_existing_byte(v78_10_byte);
            {
            let v79_2: Space = singleton(&v0_128_cursor.path()[(v0_128_origin + 2)..(v0_128_origin + 3)]);
            let v79_3: Space = intersect(&(*CONSTANT_9),&(v79_2));
            let v79_4: Space = if has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
            drop(v79_3);
            let v79_5: Space = subtract(&(*CONSTANT_0),&(v79_4));
            drop(v79_4);
            let v79_7: Space = if (&(v79_5)).is_empty() { Space::new() } else {
              let v80_6: Space = routine_23(c, &v0_128_cursor.path()[(v0_128_origin + 2)..(v0_128_origin + 3)], &v0_128_cursor.path()[v0_128_origin..(v0_128_origin + 1)], &v0_128_cursor.path()[(v0_128_origin + 1)..(v0_128_origin + 2)], &v0_128_cursor);
              compose(&(v79_5),&(v80_6))
            };
            drop(v79_5);
            let v79_8: Space = intersect(&(*CONSTANT_9),&(v79_2));
            drop(v79_2);
            let v79_9: Space = if has_head(&(v79_8)) { singleton(&[]) } else { Space::new() };
            drop(v79_8);
            let v79_11: Space = if (&(v79_9)).is_empty() { Space::new() } else {
              let v81_10: Space = routine_24(c, &v0_128_cursor.path()[(v0_128_origin + 2)..(v0_128_origin + 3)], &v0_128_cursor.path()[v0_128_origin..(v0_128_origin + 1)], &v0_128_cursor.path()[(v0_128_origin + 1)..(v0_128_origin + 2)], &v0_128_cursor);
              compose(&(v79_9),&(v81_10))
            };
            drop(v79_9);
            let v79_12: Space = unite(&(v79_7),&(v79_11));
            join_wrapped_into(&mut v78_10_write,&((v79_12).read_zipper()),&[]);
            }
            v0_128_cursor.ascend(1);
          }
          drop(v78_10_write);
          compose(&(v76_9),&(v78_10))
        };
        drop(v76_9);
        let v76_12: Space = unite(&(v76_7),&(v76_11));
        join_wrapped_into(&mut v75_10_write,&((v76_12).read_zipper()),&[]);
        }
        v0_128_cursor.ascend(1);
      }
      drop(v75_10_write);
      compose(&(v67_9),&(v75_10))
    };
    drop(v67_9);
    let v67_12: Space = unite(&(v67_7),&(v67_11));
    join_wrapped_into(&mut v0_128_write,&((v67_12).read_zipper()),&[]);
    }
    v0_128_cursor.ascend(1);
  }
  drop(v0_128_cursor);
  drop(v0_128_write);
  let mut v0_144 = Space::new();
  let mut v0_144_write = v0_144.write_zipper();
  let mut v0_144_cursor = (v0_128).read_zipper();
  let v0_144_origin = v0_144_cursor.path().len();
  for v0_144_byte in v0_144_cursor.child_mask().iter() {
    v0_144_cursor.descend_to_existing_byte(v0_144_byte);
    {
    let v82_2: Space = singleton(&v0_144_cursor.path()[v0_144_origin..(v0_144_origin + 1)]);
    let v82_3: Space = intersect(&(*CONSTANT_9),&(v82_2));
    let v82_4: Space = if has_head(&(v82_3)) { singleton(&[]) } else { Space::new() };
    drop(v82_3);
    let v82_5: Space = subtract(&(*CONSTANT_0),&(v82_4));
    drop(v82_4);
    let v82_7: Space = if (&(v82_5)).is_empty() { Space::new() } else {
      let mut v83_6 = Space::new();
      let mut v83_6_write = v83_6.write_zipper();
      for v83_6_byte in v0_144_cursor.child_mask().iter() {
        v0_144_cursor.descend_to_existing_byte(v83_6_byte);
        {
        let v84_2: Space = singleton(&v0_144_cursor.path()[(v0_144_origin + 1)..(v0_144_origin + 2)]);
        let v84_3: Space = intersect(&(*CONSTANT_9),&(v84_2));
        let v84_4: Space = if has_head(&(v84_3)) { singleton(&[]) } else { Space::new() };
        drop(v84_3);
        let v84_5: Space = subtract(&(*CONSTANT_0),&(v84_4));
        drop(v84_4);
        let v84_8: Space = if (&(v84_5)).is_empty() { Space::new() } else {
          let v85_7: Space = routine_25(c, &v0_144_cursor.path()[v0_144_origin..(v0_144_origin + 2)], &v0_144_cursor);
          compose(&(v84_5),&(v85_7))
        };
        drop(v84_5);
        let v84_9: Space = intersect(&(*CONSTANT_9),&(v84_2));
        drop(v84_2);
        let v84_10: Space = if has_head(&(v84_9)) { singleton(&[]) } else { Space::new() };
        drop(v84_9);
        let v84_12: Space = if (&(v84_10)).is_empty() { Space::new() } else {
          let mut v86_11 = Space::new();
          let mut v86_11_write = v86_11.write_zipper();
          for v86_11_byte in v0_144_cursor.child_mask().iter() {
            v0_144_cursor.descend_to_existing_byte(v86_11_byte);
            {
            let v87_2: Space = singleton(&v0_144_cursor.path()[(v0_144_origin + 2)..(v0_144_origin + 3)]);
            let v87_3: Space = intersect(&(*CONSTANT_9),&(v87_2));
            let v87_4: Space = if has_head(&(v87_3)) { singleton(&[]) } else { Space::new() };
            drop(v87_3);
            let v87_5: Space = subtract(&(*CONSTANT_0),&(v87_4));
            drop(v87_4);
            let v87_7: Space = if (&(v87_5)).is_empty() { Space::new() } else {
              let v88_6: Space = routine_26(c, &v0_144_cursor.path()[(v0_144_origin + 2)..(v0_144_origin + 3)], &v0_144_cursor.path()[v0_144_origin..(v0_144_origin + 2)], &v0_144_cursor);
              compose(&(v87_5),&(v88_6))
            };
            drop(v87_5);
            let v87_8: Space = intersect(&(*CONSTANT_9),&(v87_2));
            drop(v87_2);
            let v87_9: Space = if has_head(&(v87_8)) { singleton(&[]) } else { Space::new() };
            drop(v87_8);
            let v87_11: Space = if (&(v87_9)).is_empty() { Space::new() } else {
              let v89_10: Space = routine_27(c, &v0_144_cursor.path()[(v0_144_origin + 2)..(v0_144_origin + 3)], &v0_144_cursor.path()[v0_144_origin..(v0_144_origin + 2)], &v0_144_cursor);
              compose(&(v87_9),&(v89_10))
            };
            drop(v87_9);
            let v87_12: Space = unite(&(v87_7),&(v87_11));
            join_wrapped_into(&mut v86_11_write,&((v87_12).read_zipper()),&[]);
            }
            v0_144_cursor.ascend(1);
          }
          drop(v86_11_write);
          compose(&(v84_10),&(v86_11))
        };
        drop(v84_10);
        let v84_13: Space = unite(&(v84_8),&(v84_12));
        join_wrapped_into(&mut v83_6_write,&((v84_13).read_zipper()),&[]);
        }
        v0_144_cursor.ascend(1);
      }
      drop(v83_6_write);
      compose(&(v82_5),&(v83_6))
    };
    drop(v82_5);
    let v82_8: Space = intersect(&(*CONSTANT_9),&(v82_2));
    drop(v82_2);
    let v82_9: Space = if has_head(&(v82_8)) { singleton(&[]) } else { Space::new() };
    drop(v82_8);
    let v82_11: Space = if (&(v82_9)).is_empty() { Space::new() } else {
      let mut v90_10 = Space::new();
      let mut v90_10_write = v90_10.write_zipper();
      for v90_10_byte in v0_144_cursor.child_mask().iter() {
        v0_144_cursor.descend_to_existing_byte(v90_10_byte);
        {
        let v91_2: Space = singleton(&v0_144_cursor.path()[(v0_144_origin + 1)..(v0_144_origin + 2)]);
        let v91_3: Space = intersect(&(*CONSTANT_9),&(v91_2));
        let v91_4: Space = if has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
        drop(v91_3);
        let v91_5: Space = subtract(&(*CONSTANT_0),&(v91_4));
        drop(v91_4);
        let v91_7: Space = if (&(v91_5)).is_empty() { Space::new() } else {
          let v92_6: Space = routine_26(c, &v0_144_cursor.path()[(v0_144_origin + 1)..(v0_144_origin + 2)], &v0_144_cursor.path()[v0_144_origin..(v0_144_origin + 1)], &v0_144_cursor);
          compose(&(v91_5),&(v92_6))
        };
        drop(v91_5);
        let v91_8: Space = intersect(&(*CONSTANT_9),&(v91_2));
        drop(v91_2);
        let v91_9: Space = if has_head(&(v91_8)) { singleton(&[]) } else { Space::new() };
        drop(v91_8);
        let v91_11: Space = if (&(v91_9)).is_empty() { Space::new() } else {
          let mut v93_10 = Space::new();
          let mut v93_10_write = v93_10.write_zipper();
          for v93_10_byte in v0_144_cursor.child_mask().iter() {
            v0_144_cursor.descend_to_existing_byte(v93_10_byte);
            {
            let v94_2: Space = singleton(&v0_144_cursor.path()[(v0_144_origin + 2)..(v0_144_origin + 3)]);
            let v94_3: Space = intersect(&(*CONSTANT_9),&(v94_2));
            let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
            drop(v94_3);
            let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
            drop(v94_4);
            let v94_7: Space = if (&(v94_5)).is_empty() { Space::new() } else {
              let v95_6: Space = routine_28(c, &v0_144_cursor.path()[(v0_144_origin + 2)..(v0_144_origin + 3)], &v0_144_cursor.path()[v0_144_origin..(v0_144_origin + 1)], &v0_144_cursor.path()[(v0_144_origin + 1)..(v0_144_origin + 2)], &v0_144_cursor);
              compose(&(v94_5),&(v95_6))
            };
            drop(v94_5);
            let v94_8: Space = intersect(&(*CONSTANT_9),&(v94_2));
            drop(v94_2);
            let v94_9: Space = if has_head(&(v94_8)) { singleton(&[]) } else { Space::new() };
            drop(v94_8);
            let v94_11: Space = if (&(v94_9)).is_empty() { Space::new() } else {
              let v96_10: Space = routine_29(c, &v0_144_cursor.path()[(v0_144_origin + 2)..(v0_144_origin + 3)], &v0_144_cursor.path()[v0_144_origin..(v0_144_origin + 1)], &v0_144_cursor.path()[(v0_144_origin + 1)..(v0_144_origin + 2)], &v0_144_cursor);
              compose(&(v94_9),&(v96_10))
            };
            drop(v94_9);
            let v94_12: Space = unite(&(v94_7),&(v94_11));
            join_wrapped_into(&mut v93_10_write,&((v94_12).read_zipper()),&[]);
            }
            v0_144_cursor.ascend(1);
          }
          drop(v93_10_write);
          compose(&(v91_9),&(v93_10))
        };
        drop(v91_9);
        let v91_12: Space = unite(&(v91_7),&(v91_11));
        join_wrapped_into(&mut v90_10_write,&((v91_12).read_zipper()),&[]);
        }
        v0_144_cursor.ascend(1);
      }
      drop(v90_10_write);
      compose(&(v82_9),&(v90_10))
    };
    drop(v82_9);
    let v82_12: Space = unite(&(v82_7),&(v82_11));
    join_wrapped_into(&mut v0_144_write,&((v82_12).read_zipper()),&[]);
    }
    v0_144_cursor.ascend(1);
  }
  drop(v0_144_cursor);
  drop(v0_144_write);
  let mut v0_160 = Space::new();
  let mut v0_160_write = v0_160.write_zipper();
  let mut v0_160_cursor = (v0_144).read_zipper();
  let v0_160_origin = v0_160_cursor.path().len();
  for v0_160_byte in v0_160_cursor.child_mask().iter() {
    v0_160_cursor.descend_to_existing_byte(v0_160_byte);
    {
    let v97_2: Space = singleton(&v0_160_cursor.path()[v0_160_origin..(v0_160_origin + 1)]);
    let v97_3: Space = intersect(&(*CONSTANT_9),&(v97_2));
    let v97_4: Space = if has_head(&(v97_3)) { singleton(&[]) } else { Space::new() };
    drop(v97_3);
    let v97_5: Space = subtract(&(*CONSTANT_0),&(v97_4));
    drop(v97_4);
    let v97_7: Space = if (&(v97_5)).is_empty() { Space::new() } else {
      let mut v98_6 = Space::new();
      let mut v98_6_write = v98_6.write_zipper();
      for v98_6_byte in v0_160_cursor.child_mask().iter() {
        v0_160_cursor.descend_to_existing_byte(v98_6_byte);
        {
        let v99_2: Space = singleton(&v0_160_cursor.path()[(v0_160_origin + 1)..(v0_160_origin + 2)]);
        let v99_3: Space = intersect(&(*CONSTANT_9),&(v99_2));
        let v99_4: Space = if has_head(&(v99_3)) { singleton(&[]) } else { Space::new() };
        drop(v99_3);
        let v99_5: Space = subtract(&(*CONSTANT_0),&(v99_4));
        drop(v99_4);
        let v99_8: Space = if (&(v99_5)).is_empty() { Space::new() } else {
          let v100_7: Space = routine_30(c, &v0_160_cursor.path()[v0_160_origin..(v0_160_origin + 2)], &v0_160_cursor);
          compose(&(v99_5),&(v100_7))
        };
        drop(v99_5);
        let v99_9: Space = intersect(&(*CONSTANT_9),&(v99_2));
        drop(v99_2);
        let v99_10: Space = if has_head(&(v99_9)) { singleton(&[]) } else { Space::new() };
        drop(v99_9);
        let v99_12: Space = if (&(v99_10)).is_empty() { Space::new() } else {
          let mut v101_11 = Space::new();
          let mut v101_11_write = v101_11.write_zipper();
          for v101_11_byte in v0_160_cursor.child_mask().iter() {
            v0_160_cursor.descend_to_existing_byte(v101_11_byte);
            {
            let v102_2: Space = singleton(&v0_160_cursor.path()[(v0_160_origin + 2)..(v0_160_origin + 3)]);
            let v102_3: Space = intersect(&(*CONSTANT_9),&(v102_2));
            let v102_4: Space = if has_head(&(v102_3)) { singleton(&[]) } else { Space::new() };
            drop(v102_3);
            let v102_5: Space = subtract(&(*CONSTANT_0),&(v102_4));
            drop(v102_4);
            let v102_7: Space = if (&(v102_5)).is_empty() { Space::new() } else {
              let v103_6: Space = routine_31(c, &v0_160_cursor.path()[(v0_160_origin + 2)..(v0_160_origin + 3)], &v0_160_cursor.path()[v0_160_origin..(v0_160_origin + 2)], &v0_160_cursor);
              compose(&(v102_5),&(v103_6))
            };
            drop(v102_5);
            let v102_8: Space = intersect(&(*CONSTANT_9),&(v102_2));
            drop(v102_2);
            let v102_9: Space = if has_head(&(v102_8)) { singleton(&[]) } else { Space::new() };
            drop(v102_8);
            let v102_11: Space = if (&(v102_9)).is_empty() { Space::new() } else {
              let v104_10: Space = routine_32(c, &v0_160_cursor.path()[(v0_160_origin + 2)..(v0_160_origin + 3)], &v0_160_cursor.path()[v0_160_origin..(v0_160_origin + 2)], &v0_160_cursor);
              compose(&(v102_9),&(v104_10))
            };
            drop(v102_9);
            let v102_12: Space = unite(&(v102_7),&(v102_11));
            join_wrapped_into(&mut v101_11_write,&((v102_12).read_zipper()),&[]);
            }
            v0_160_cursor.ascend(1);
          }
          drop(v101_11_write);
          compose(&(v99_10),&(v101_11))
        };
        drop(v99_10);
        let v99_13: Space = unite(&(v99_8),&(v99_12));
        join_wrapped_into(&mut v98_6_write,&((v99_13).read_zipper()),&[]);
        }
        v0_160_cursor.ascend(1);
      }
      drop(v98_6_write);
      compose(&(v97_5),&(v98_6))
    };
    drop(v97_5);
    let v97_8: Space = intersect(&(*CONSTANT_9),&(v97_2));
    drop(v97_2);
    let v97_9: Space = if has_head(&(v97_8)) { singleton(&[]) } else { Space::new() };
    drop(v97_8);
    let v97_11: Space = if (&(v97_9)).is_empty() { Space::new() } else {
      let mut v105_10 = Space::new();
      let mut v105_10_write = v105_10.write_zipper();
      for v105_10_byte in v0_160_cursor.child_mask().iter() {
        v0_160_cursor.descend_to_existing_byte(v105_10_byte);
        {
        let v106_2: Space = singleton(&v0_160_cursor.path()[(v0_160_origin + 1)..(v0_160_origin + 2)]);
        let v106_3: Space = intersect(&(*CONSTANT_9),&(v106_2));
        let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
        drop(v106_3);
        let v106_5: Space = subtract(&(*CONSTANT_0),&(v106_4));
        drop(v106_4);
        let v106_7: Space = if (&(v106_5)).is_empty() { Space::new() } else {
          let v107_6: Space = routine_31(c, &v0_160_cursor.path()[(v0_160_origin + 1)..(v0_160_origin + 2)], &v0_160_cursor.path()[v0_160_origin..(v0_160_origin + 1)], &v0_160_cursor);
          compose(&(v106_5),&(v107_6))
        };
        drop(v106_5);
        let v106_8: Space = intersect(&(*CONSTANT_9),&(v106_2));
        drop(v106_2);
        let v106_9: Space = if has_head(&(v106_8)) { singleton(&[]) } else { Space::new() };
        drop(v106_8);
        let v106_11: Space = if (&(v106_9)).is_empty() { Space::new() } else {
          let mut v108_10 = Space::new();
          let mut v108_10_write = v108_10.write_zipper();
          for v108_10_byte in v0_160_cursor.child_mask().iter() {
            v0_160_cursor.descend_to_existing_byte(v108_10_byte);
            {
            let v109_2: Space = singleton(&v0_160_cursor.path()[(v0_160_origin + 2)..(v0_160_origin + 3)]);
            let v109_3: Space = intersect(&(*CONSTANT_9),&(v109_2));
            let v109_4: Space = if has_head(&(v109_3)) { singleton(&[]) } else { Space::new() };
            drop(v109_3);
            let v109_5: Space = subtract(&(*CONSTANT_0),&(v109_4));
            drop(v109_4);
            let v109_7: Space = if (&(v109_5)).is_empty() { Space::new() } else {
              let v110_6: Space = routine_33(c, &v0_160_cursor.path()[(v0_160_origin + 2)..(v0_160_origin + 3)], &v0_160_cursor.path()[v0_160_origin..(v0_160_origin + 1)], &v0_160_cursor.path()[(v0_160_origin + 1)..(v0_160_origin + 2)], &v0_160_cursor);
              compose(&(v109_5),&(v110_6))
            };
            drop(v109_5);
            let v109_8: Space = intersect(&(*CONSTANT_9),&(v109_2));
            drop(v109_2);
            let v109_9: Space = if has_head(&(v109_8)) { singleton(&[]) } else { Space::new() };
            drop(v109_8);
            let v109_11: Space = if (&(v109_9)).is_empty() { Space::new() } else {
              let v111_10: Space = routine_34(c, &v0_160_cursor.path()[(v0_160_origin + 2)..(v0_160_origin + 3)], &v0_160_cursor.path()[v0_160_origin..(v0_160_origin + 1)], &v0_160_cursor.path()[(v0_160_origin + 1)..(v0_160_origin + 2)], &v0_160_cursor);
              compose(&(v109_9),&(v111_10))
            };
            drop(v109_9);
            let v109_12: Space = unite(&(v109_7),&(v109_11));
            join_wrapped_into(&mut v108_10_write,&((v109_12).read_zipper()),&[]);
            }
            v0_160_cursor.ascend(1);
          }
          drop(v108_10_write);
          compose(&(v106_9),&(v108_10))
        };
        drop(v106_9);
        let v106_12: Space = unite(&(v106_7),&(v106_11));
        join_wrapped_into(&mut v105_10_write,&((v106_12).read_zipper()),&[]);
        }
        v0_160_cursor.ascend(1);
      }
      drop(v105_10_write);
      compose(&(v97_9),&(v105_10))
    };
    drop(v97_9);
    let v97_12: Space = unite(&(v97_7),&(v97_11));
    join_wrapped_into(&mut v0_160_write,&((v97_12).read_zipper()),&[]);
    }
    v0_160_cursor.ascend(1);
  }
  drop(v0_160_cursor);
  drop(v0_160_write);
  let mut v0_176 = Space::new();
  let mut v0_176_write = v0_176.write_zipper();
  let mut v0_176_cursor = (v0_160).read_zipper();
  let v0_176_origin = v0_176_cursor.path().len();
  for v0_176_byte in v0_176_cursor.child_mask().iter() {
    v0_176_cursor.descend_to_existing_byte(v0_176_byte);
    {
    let v112_2: Space = singleton(&v0_176_cursor.path()[v0_176_origin..(v0_176_origin + 1)]);
    let v112_3: Space = intersect(&(*CONSTANT_9),&(v112_2));
    let v112_4: Space = if has_head(&(v112_3)) { singleton(&[]) } else { Space::new() };
    drop(v112_3);
    let v112_5: Space = subtract(&(*CONSTANT_0),&(v112_4));
    drop(v112_4);
    let v112_7: Space = if (&(v112_5)).is_empty() { Space::new() } else {
      let mut v113_6 = Space::new();
      let mut v113_6_write = v113_6.write_zipper();
      for v113_6_byte in v0_176_cursor.child_mask().iter() {
        v0_176_cursor.descend_to_existing_byte(v113_6_byte);
        {
        let v114_2: Space = singleton(&v0_176_cursor.path()[(v0_176_origin + 1)..(v0_176_origin + 2)]);
        let v114_3: Space = intersect(&(*CONSTANT_9),&(v114_2));
        let v114_4: Space = if has_head(&(v114_3)) { singleton(&[]) } else { Space::new() };
        drop(v114_3);
        let v114_5: Space = subtract(&(*CONSTANT_0),&(v114_4));
        drop(v114_4);
        let v114_8: Space = if (&(v114_5)).is_empty() { Space::new() } else {
          let v115_7: Space = routine_35(c, &v0_176_cursor.path()[v0_176_origin..(v0_176_origin + 2)], &v0_176_cursor);
          compose(&(v114_5),&(v115_7))
        };
        drop(v114_5);
        let v114_9: Space = intersect(&(*CONSTANT_9),&(v114_2));
        drop(v114_2);
        let v114_10: Space = if has_head(&(v114_9)) { singleton(&[]) } else { Space::new() };
        drop(v114_9);
        let v114_12: Space = if (&(v114_10)).is_empty() { Space::new() } else {
          let mut v116_11 = Space::new();
          let mut v116_11_write = v116_11.write_zipper();
          for v116_11_byte in v0_176_cursor.child_mask().iter() {
            v0_176_cursor.descend_to_existing_byte(v116_11_byte);
            {
            let v117_2: Space = singleton(&v0_176_cursor.path()[(v0_176_origin + 2)..(v0_176_origin + 3)]);
            let v117_3: Space = intersect(&(*CONSTANT_9),&(v117_2));
            let v117_4: Space = if has_head(&(v117_3)) { singleton(&[]) } else { Space::new() };
            drop(v117_3);
            let v117_5: Space = subtract(&(*CONSTANT_0),&(v117_4));
            drop(v117_4);
            let v117_7: Space = if (&(v117_5)).is_empty() { Space::new() } else {
              let v118_6: Space = routine_36(c, &v0_176_cursor.path()[(v0_176_origin + 2)..(v0_176_origin + 3)], &v0_176_cursor.path()[v0_176_origin..(v0_176_origin + 2)], &v0_176_cursor);
              compose(&(v117_5),&(v118_6))
            };
            drop(v117_5);
            let v117_8: Space = intersect(&(*CONSTANT_9),&(v117_2));
            drop(v117_2);
            let v117_9: Space = if has_head(&(v117_8)) { singleton(&[]) } else { Space::new() };
            drop(v117_8);
            let v117_11: Space = if (&(v117_9)).is_empty() { Space::new() } else {
              let v119_10: Space = routine_37(c, &v0_176_cursor.path()[(v0_176_origin + 2)..(v0_176_origin + 3)], &v0_176_cursor.path()[v0_176_origin..(v0_176_origin + 2)], &v0_176_cursor);
              compose(&(v117_9),&(v119_10))
            };
            drop(v117_9);
            let v117_12: Space = unite(&(v117_7),&(v117_11));
            join_wrapped_into(&mut v116_11_write,&((v117_12).read_zipper()),&[]);
            }
            v0_176_cursor.ascend(1);
          }
          drop(v116_11_write);
          compose(&(v114_10),&(v116_11))
        };
        drop(v114_10);
        let v114_13: Space = unite(&(v114_8),&(v114_12));
        join_wrapped_into(&mut v113_6_write,&((v114_13).read_zipper()),&[]);
        }
        v0_176_cursor.ascend(1);
      }
      drop(v113_6_write);
      compose(&(v112_5),&(v113_6))
    };
    drop(v112_5);
    let v112_8: Space = intersect(&(*CONSTANT_9),&(v112_2));
    drop(v112_2);
    let v112_9: Space = if has_head(&(v112_8)) { singleton(&[]) } else { Space::new() };
    drop(v112_8);
    let v112_11: Space = if (&(v112_9)).is_empty() { Space::new() } else {
      let mut v120_10 = Space::new();
      let mut v120_10_write = v120_10.write_zipper();
      for v120_10_byte in v0_176_cursor.child_mask().iter() {
        v0_176_cursor.descend_to_existing_byte(v120_10_byte);
        {
        let v121_2: Space = singleton(&v0_176_cursor.path()[(v0_176_origin + 1)..(v0_176_origin + 2)]);
        let v121_3: Space = intersect(&(*CONSTANT_9),&(v121_2));
        let v121_4: Space = if has_head(&(v121_3)) { singleton(&[]) } else { Space::new() };
        drop(v121_3);
        let v121_5: Space = subtract(&(*CONSTANT_0),&(v121_4));
        drop(v121_4);
        let v121_7: Space = if (&(v121_5)).is_empty() { Space::new() } else {
          let v122_6: Space = routine_36(c, &v0_176_cursor.path()[(v0_176_origin + 1)..(v0_176_origin + 2)], &v0_176_cursor.path()[v0_176_origin..(v0_176_origin + 1)], &v0_176_cursor);
          compose(&(v121_5),&(v122_6))
        };
        drop(v121_5);
        let v121_8: Space = intersect(&(*CONSTANT_9),&(v121_2));
        drop(v121_2);
        let v121_9: Space = if has_head(&(v121_8)) { singleton(&[]) } else { Space::new() };
        drop(v121_8);
        let v121_11: Space = if (&(v121_9)).is_empty() { Space::new() } else {
          let mut v123_10 = Space::new();
          let mut v123_10_write = v123_10.write_zipper();
          for v123_10_byte in v0_176_cursor.child_mask().iter() {
            v0_176_cursor.descend_to_existing_byte(v123_10_byte);
            {
            let v124_2: Space = singleton(&v0_176_cursor.path()[(v0_176_origin + 2)..(v0_176_origin + 3)]);
            let v124_3: Space = intersect(&(*CONSTANT_9),&(v124_2));
            let v124_4: Space = if has_head(&(v124_3)) { singleton(&[]) } else { Space::new() };
            drop(v124_3);
            let v124_5: Space = subtract(&(*CONSTANT_0),&(v124_4));
            drop(v124_4);
            let v124_7: Space = if (&(v124_5)).is_empty() { Space::new() } else {
              let v125_6: Space = routine_38(c, &v0_176_cursor.path()[(v0_176_origin + 2)..(v0_176_origin + 3)], &v0_176_cursor.path()[v0_176_origin..(v0_176_origin + 1)], &v0_176_cursor.path()[(v0_176_origin + 1)..(v0_176_origin + 2)], &v0_176_cursor);
              compose(&(v124_5),&(v125_6))
            };
            drop(v124_5);
            let v124_8: Space = intersect(&(*CONSTANT_9),&(v124_2));
            drop(v124_2);
            let v124_9: Space = if has_head(&(v124_8)) { singleton(&[]) } else { Space::new() };
            drop(v124_8);
            let v124_11: Space = if (&(v124_9)).is_empty() { Space::new() } else {
              let v126_10: Space = routine_39(c, &v0_176_cursor.path()[(v0_176_origin + 2)..(v0_176_origin + 3)], &v0_176_cursor.path()[v0_176_origin..(v0_176_origin + 1)], &v0_176_cursor.path()[(v0_176_origin + 1)..(v0_176_origin + 2)], &v0_176_cursor);
              compose(&(v124_9),&(v126_10))
            };
            drop(v124_9);
            let v124_12: Space = unite(&(v124_7),&(v124_11));
            join_wrapped_into(&mut v123_10_write,&((v124_12).read_zipper()),&[]);
            }
            v0_176_cursor.ascend(1);
          }
          drop(v123_10_write);
          compose(&(v121_9),&(v123_10))
        };
        drop(v121_9);
        let v121_12: Space = unite(&(v121_7),&(v121_11));
        join_wrapped_into(&mut v120_10_write,&((v121_12).read_zipper()),&[]);
        }
        v0_176_cursor.ascend(1);
      }
      drop(v120_10_write);
      compose(&(v112_9),&(v120_10))
    };
    drop(v112_9);
    let v112_12: Space = unite(&(v112_7),&(v112_11));
    join_wrapped_into(&mut v0_176_write,&((v112_12).read_zipper()),&[]);
    }
    v0_176_cursor.ascend(1);
  }
  drop(v0_176_cursor);
  drop(v0_176_write);

((v0_128).clone(),(v0_144).clone(),(v0_160).clone(),(v0_176).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let (mut v0_112,mut v0_48,mut v0_63,mut v0_80,mut v0_96,) = native_block_0(c);
  let (mut v0_128,mut v0_144,mut v0_160,mut v0_176,) = native_block_1(c, &v0_112);
  (v0_176).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8]) -> Space {
  let v127_7: Space = if (&(descend_cursor((*CONSTANT_11).read_zipper(),&(*p2)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_11).read_zipper(),&(*p2))),&(descend_cursor((*CONSTANT_11).read_zipper(),&(*p2))))
  };
  let mut v127_24 = Space::new();
  let mut v127_24_write = v127_24.write_zipper();
  let mut v127_24_cursor = descend_cursor((*CONSTANT_11).read_zipper(),&(*p2));
  let v127_24_origin = v127_24_cursor.path().len();
  for v127_24_byte in v127_24_cursor.child_mask().iter() {
    v127_24_cursor.descend_to_existing_byte(v127_24_byte);
    {
    let v129_2: Space = singleton(&v127_24_cursor.path()[v127_24_origin..(v127_24_origin + 1)]);
    let v129_3: Space = intersect(&(*CONSTANT_9),&(v129_2));
    let v129_4: Space = if has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
    drop(v129_3);
    let v129_5: Space = subtract(&(*CONSTANT_0),&(v129_4));
    drop(v129_4);
    let v129_9: Space = if (&(v129_5)).is_empty() { Space::new() } else {
      let mut v130_8 = Space::new();
      let mut v130_8_write = v130_8.write_zipper();
      for v130_8_byte in v127_24_cursor.child_mask().iter() {
        v127_24_cursor.descend_to_existing_byte(v130_8_byte);
        {
        let v131_2: Space = singleton(&v127_24_cursor.path()[(v127_24_origin + 1)..(v127_24_origin + 2)]);
        let v131_3: Space = intersect(&(*CONSTANT_9),&(v131_2));
        let v131_4: Space = if has_head(&(v131_3)) { singleton(&[]) } else { Space::new() };
        drop(v131_3);
        let v131_5: Space = subtract(&(*CONSTANT_0),&(v131_4));
        drop(v131_4);
        let v131_8: Space = if (&(v131_5)).is_empty() { Space::new() } else {
          let v132_7: Space = routine_40(c, &v127_24_cursor.path()[v127_24_origin..(v127_24_origin + 2)], &(*p1), &(*p0), &v127_24_cursor);
          compose(&(v131_5),&(v132_7))
        };
        drop(v131_5);
        let v131_9: Space = intersect(&(*CONSTANT_9),&(v131_2));
        drop(v131_2);
        let v131_10: Space = if has_head(&(v131_9)) { singleton(&[]) } else { Space::new() };
        drop(v131_9);
        let v131_20: Space = if (&(v131_10)).is_empty() { Space::new() } else {
          let v133_13: Space = if (&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_12).read_zipper(),&(*p1)),&v127_24_cursor.path()[v127_24_origin..(v127_24_origin + 1)]),&v127_24_cursor.path()[(v127_24_origin + 1)..(v127_24_origin + 2)]))).is_empty() { Space::new() } else {
            compose(&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_12).read_zipper(),&(*p1)),&v127_24_cursor.path()[v127_24_origin..(v127_24_origin + 1)]),&v127_24_cursor.path()[(v127_24_origin + 1)..(v127_24_origin + 2)])),&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_12).read_zipper(),&(*p0)),&v127_24_cursor.path()[v127_24_origin..(v127_24_origin + 1)]),&v127_24_cursor.path()[(v127_24_origin + 1)..(v127_24_origin + 2)])))
          };
          let v133_14: Path = concat_path(&v127_24_cursor.path()[v127_24_origin..(v127_24_origin + 2)],&(*p0));
          let v133_15: Space = singleton(&(v133_14));
          drop(v133_14);
          let v133_16: Space = unite(&(v133_13),&(v133_15));
          drop(v133_13);
          drop(v133_15);
          let v133_17: Path = concat_path(&(*p1),&v127_24_cursor.path()[v127_24_origin..(v127_24_origin + 2)]);
          let v133_18: Space = singleton(&(v133_17));
          drop(v133_17);
          let v133_19: Space = unite(&(v133_16),&(v133_18));
          drop(v133_16);
          drop(v133_18);
          compose(&(v131_10),&(v133_19))
        };
        drop(v131_10);
        let v131_21: Space = unite(&(v131_8),&(v131_20));
        drop(v131_20);
        join_wrapped_into(&mut v130_8_write,&((v131_21).read_zipper()),&[]);
        }
        v127_24_cursor.ascend(1);
      }
      drop(v130_8_write);
      compose(&(v129_5),&(v130_8))
    };
    drop(v129_5);
    let v129_10: Space = intersect(&(*CONSTANT_9),&(v129_2));
    drop(v129_2);
    let v129_11: Space = if has_head(&(v129_10)) { singleton(&[]) } else { Space::new() };
    drop(v129_10);
    let v129_21: Space = if (&(v129_11)).is_empty() { Space::new() } else {
      let v135_14: Space = if (&(descend_cursor(descend_cursor((*CONSTANT_12).read_zipper(),&(*p1)),&v127_24_cursor.path()[v127_24_origin..(v127_24_origin + 1)]))).is_empty() { Space::new() } else {
        compose(&(descend_cursor(descend_cursor((*CONSTANT_12).read_zipper(),&(*p1)),&v127_24_cursor.path()[v127_24_origin..(v127_24_origin + 1)])),&(descend_cursor(descend_cursor((*CONSTANT_12).read_zipper(),&(*p0)),&v127_24_cursor.path()[v127_24_origin..(v127_24_origin + 1)])))
      };
      let v135_15: Path = concat_path(&v127_24_cursor.path()[v127_24_origin..(v127_24_origin + 1)],&(*p0));
      let v135_16: Space = singleton(&(v135_15));
      drop(v135_15);
      let v135_17: Space = unite(&(v135_14),&(v135_16));
      drop(v135_14);
      drop(v135_16);
      let v135_18: Path = concat_path(&(*p1),&v127_24_cursor.path()[v127_24_origin..(v127_24_origin + 1)]);
      let v135_19: Space = singleton(&(v135_18));
      drop(v135_18);
      let v135_20: Space = unite(&(v135_17),&(v135_19));
      drop(v135_17);
      drop(v135_19);
      compose(&(v129_11),&(v135_20))
    };
    drop(v129_11);
    let v129_22: Space = unite(&(v129_9),&(v129_21));
    drop(v129_21);
    join_wrapped_into(&mut v127_24_write,&((v129_22).read_zipper()),&[]);
    }
    v127_24_cursor.ascend(1);
  }
  drop(v127_24_cursor);
  drop(v127_24_write);
  let v127_25: Space = intersect(&(v127_7),&(v127_24));
  drop(v127_7);
  (v127_25).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v137_11 = Space::new();
  let mut v137_11_write = v137_11.write_zipper();
  let mut v137_11_cursor = (*s0).read_zipper();
  let v137_11_origin = v137_11_cursor.path().len();
  for v137_11_byte in v137_11_cursor.child_mask().iter() {
    v137_11_cursor.descend_to_existing_byte(v137_11_byte);
    {
    let v138_2: Space = singleton(&v137_11_cursor.path()[v137_11_origin..(v137_11_origin + 1)]);
    let v138_3: Space = intersect(&(*CONSTANT_9),&(v138_2));
    let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
    drop(v138_3);
    let v138_5: Space = subtract(&(*CONSTANT_0),&(v138_4));
    drop(v138_4);
    let v138_8: Space = if (&(v138_5)).is_empty() { Space::new() } else {
      let v139_6: Path = concat_path(&(*p0),&v137_11_cursor.path()[v137_11_origin..(v137_11_origin + 1)]);
      let v139_7: Space = routine_2(c, &(v139_6), &v137_11_cursor);
      compose(&(v138_5),&(v139_7))
    };
    drop(v138_5);
    let v138_9: Space = intersect(&(*CONSTANT_9),&(v138_2));
    drop(v138_2);
    let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
    drop(v138_9);
    let v138_14: Space = if (&(v138_10)).is_empty() { Space::new() } else {
      let v140_6: Path = concat_path(&(*p0),&v137_11_cursor.path()[v137_11_origin..(v137_11_origin + 1)]);
      let v140_12: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v137_11_cursor,(v137_11_origin + 1)),&(*CONSTANT_3))));
      let mut v140_13 = Space::new();
      let mut v140_13_write = v140_13.write_zipper();
      let mut v140_13_cursor = (v140_12).read_zipper();
      let v140_13_origin = v140_13_cursor.path().len();
      for v140_13_byte in v140_13_cursor.child_mask().iter() {
        v140_13_cursor.descend_to_existing_byte(v140_13_byte);
        {
        let v141_2: Space = singleton(&v140_13_cursor.path()[v140_13_origin..(v140_13_origin + 1)]);
        let v141_3: Space = intersect(&(*CONSTANT_9),&(v141_2));
        let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
        drop(v141_3);
        let v141_5: Space = subtract(&(*CONSTANT_0),&(v141_4));
        drop(v141_4);
        let v141_7: Space = if (&(v141_5)).is_empty() { Space::new() } else {
          let v142_6: Space = routine_3(c, &v140_13_cursor.path()[v140_13_origin..(v140_13_origin + 1)], &(v140_6), &v140_13_cursor, &v137_11_cursor);
          compose(&(v141_5),&(v142_6))
        };
        drop(v141_5);
        let v141_8: Space = intersect(&(*CONSTANT_9),&(v141_2));
        drop(v141_2);
        let v141_9: Space = if has_head(&(v141_8)) { singleton(&[]) } else { Space::new() };
        drop(v141_8);
        let v141_12: Space = if (&(v141_9)).is_empty() { Space::new() } else {
          let v143_10: Space = routine_1(c, &v140_13_cursor.path()[v140_13_origin..(v140_13_origin + 1)], &(*CONSTANT_3), &(*CONSTANT_2));
          let v143_11: Space = unite(&v137_11_cursor,&(v143_10));
          compose(&(v141_9),&(v143_11))
        };
        drop(v141_9);
        let v141_13: Space = wrap(&(v141_12),&(v140_6));
        let v141_14: Space = wrap(&(v141_13),&v140_13_cursor.path()[v140_13_origin..(v140_13_origin + 1)]);
        let v141_15: Space = unite(&(v141_7),&(v141_14));
        join_wrapped_into(&mut v140_13_write,&((v141_15).read_zipper()),&[]);
        }
        v140_13_cursor.ascend(1);
      }
      drop(v140_13_cursor);
      drop(v140_13_write);
      drop(v140_6);
      drop(v140_12);
      compose(&(v138_10),&(v140_13))
    };
    drop(v138_10);
    let v138_15: Space = unite(&(v138_8),&(v138_14));
    join_wrapped_into(&mut v137_11_write,&((v138_15).read_zipper()),&[]);
    }
    v137_11_cursor.ascend(1);
  }
  drop(v137_11_cursor);
  drop(v137_11_write);
  (v137_11).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v144_26 = Space::new();
  let mut v144_26_write = v144_26.write_zipper();
  let mut v144_26_cursor = (*s0).read_zipper();
  let v144_26_origin = v144_26_cursor.path().len();
  for v144_26_byte in v144_26_cursor.child_mask().iter() {
    v144_26_cursor.descend_to_existing_byte(v144_26_byte);
    {
    let v145_2: Space = singleton(&v144_26_cursor.path()[v144_26_origin..(v144_26_origin + 1)]);
    let v145_3: Space = intersect(&(*CONSTANT_9),&(v145_2));
    let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
    drop(v145_3);
    let v145_5: Space = subtract(&(*CONSTANT_0),&(v145_4));
    drop(v145_4);
    let v145_8: Space = if (&(v145_5)).is_empty() { Space::new() } else {
      let v146_6: Path = concat_path(&(*p0),&v144_26_cursor.path()[v144_26_origin..(v144_26_origin + 1)]);
      let v146_7: Space = routine_3(c, &(v146_6), &(*p1), &v144_26_cursor, &(*s1));
      compose(&(v145_5),&(v146_7))
    };
    drop(v145_5);
    let v145_9: Space = intersect(&(*CONSTANT_9),&(v145_2));
    drop(v145_2);
    let v145_10: Space = if has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
    drop(v145_9);
    let v145_29: Space = if (&(v145_10)).is_empty() { Space::new() } else {
      let v147_26: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v148_6: Path = concat_path(&(*p0),&v144_26_cursor.path()[v144_26_origin..(v144_26_origin + 1)]);
        let v148_11: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_3), &(v148_6), &((*CONSTANT_9).read_zipper()));
        let v148_12: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_3), &(v148_6), &((*CONSTANT_9).read_zipper()));
        let v148_13: Space = unite(&(v148_11),&(v148_12));
        let v148_14: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_3), &(v148_6), &((*CONSTANT_9).read_zipper()));
        let v148_15: Space = unite(&(v148_13),&(v148_14));
        let v148_16: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_3), &(v148_6), &((*CONSTANT_9).read_zipper()));
        let v148_17: Space = unite(&(v148_15),&(v148_16));
        let v148_18: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_3), &(v148_6), &((*CONSTANT_9).read_zipper()));
        let v148_19: Space = unite(&(v148_17),&(v148_18));
        let v148_20: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_3), &(v148_6), &((*CONSTANT_9).read_zipper()));
        let v148_21: Space = unite(&(v148_19),&(v148_20));
        let v148_22: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_3), &(v148_6), &((*CONSTANT_9).read_zipper()));
        let v148_23: Space = unite(&(v148_21),&(v148_22));
        let v148_24: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_3), &(v148_6), &((*CONSTANT_9).read_zipper()));
        let v148_25: Space = unite(&(v148_23),&(v148_24));
        compose(&(*CONSTANT_0),&(v148_25))
      };
      let v147_27: Space = intersect(&(v147_26),&(*CONSTANT_21));
      let v147_28: Space = unite(&(v147_27),&(*s1));
      compose(&(v145_10),&(v147_28))
    };
    drop(v145_10);
    let v145_30: Space = wrap(&(v145_29),&(*p1));
    let v149_6: Path = concat_path(&(*p0),&v144_26_cursor.path()[v144_26_origin..(v144_26_origin + 1)]);
    let v145_31: Space = wrap(&(v145_30),&(v149_6));
    let v145_32: Space = unite(&(v145_8),&(v145_31));
    join_wrapped_into(&mut v144_26_write,&((v145_32).read_zipper()),&[]);
    }
    v144_26_cursor.ascend(1);
  }
  drop(v144_26_cursor);
  drop(v144_26_write);
  (v144_26).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v150_37: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v151_8: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_3), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v151_11: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_3), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v151_12: Space = unite(&(v151_8),&(v151_11));
    let v151_15: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_3), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v151_16: Space = unite(&(v151_12),&(v151_15));
    let v151_19: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_3), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v151_20: Space = unite(&(v151_16),&(v151_19));
    let v151_23: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_3), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v151_24: Space = unite(&(v151_20),&(v151_23));
    let v151_27: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_3), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v151_28: Space = unite(&(v151_24),&(v151_27));
    let v151_31: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_3), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v151_32: Space = unite(&(v151_28),&(v151_31));
    let v151_35: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_3), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v151_36: Space = unite(&(v151_32),&(v151_35));
    compose(&(*CONSTANT_0),&(v151_36))
  };
  let v150_39: Space = intersect(&(v150_37),&(*CONSTANT_21));
  let v150_40: Space = unite(&(v150_39),&(*s1));
  let v150_41: Space = wrap(&(v150_40),&(*p1));
  let v150_42: Space = wrap(&(v150_41),&(*p0));
  (v150_42).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v152_13 = Space::new();
  let mut v152_13_write = v152_13.write_zipper();
  let mut v152_13_cursor = (*s0).read_zipper();
  let v152_13_origin = v152_13_cursor.path().len();
  for v152_13_byte in v152_13_cursor.child_mask().iter() {
    v152_13_cursor.descend_to_existing_byte(v152_13_byte);
    {
    let v153_2: Space = singleton(&v152_13_cursor.path()[v152_13_origin..(v152_13_origin + 1)]);
    let v153_3: Space = intersect(&(*CONSTANT_9),&(v153_2));
    let v153_4: Space = if has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
    drop(v153_3);
    let v153_5: Space = subtract(&(*CONSTANT_0),&(v153_4));
    drop(v153_4);
    let v153_8: Space = if (&(v153_5)).is_empty() { Space::new() } else {
      let v154_6: Path = concat_path(&(*p0),&v152_13_cursor.path()[v152_13_origin..(v152_13_origin + 1)]);
      let v154_7: Space = routine_5(c, &(v154_6), &v152_13_cursor);
      compose(&(v153_5),&(v154_7))
    };
    drop(v153_5);
    let v153_9: Space = intersect(&(*CONSTANT_9),&(v153_2));
    drop(v153_2);
    let v153_10: Space = if has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
    drop(v153_9);
    let v153_12: Space = if (&(v153_10)).is_empty() { Space::new() } else {
      let v155_6: Path = concat_path(&(*p0),&v152_13_cursor.path()[v152_13_origin..(v152_13_origin + 1)]);
      let mut v155_11 = Space::new();
      let mut v155_11_write = v155_11.write_zipper();
      for v155_11_byte in v152_13_cursor.child_mask().iter() {
        v152_13_cursor.descend_to_existing_byte(v155_11_byte);
        {
        let v156_2: Space = singleton(&v152_13_cursor.path()[(v152_13_origin + 1)..(v152_13_origin + 2)]);
        let v156_3: Space = intersect(&(*CONSTANT_9),&(v156_2));
        let v156_4: Space = if has_head(&(v156_3)) { singleton(&[]) } else { Space::new() };
        drop(v156_3);
        let v156_5: Space = subtract(&(*CONSTANT_0),&(v156_4));
        drop(v156_4);
        let v156_7: Space = if (&(v156_5)).is_empty() { Space::new() } else {
          let v157_6: Space = routine_6(c, &v152_13_cursor.path()[(v152_13_origin + 1)..(v152_13_origin + 2)], &(v155_6), &v152_13_cursor);
          compose(&(v156_5),&(v157_6))
        };
        drop(v156_5);
        let v156_8: Space = intersect(&(*CONSTANT_9),&(v156_2));
        drop(v156_2);
        let v156_9: Space = if has_head(&(v156_8)) { singleton(&[]) } else { Space::new() };
        drop(v156_8);
        let v156_13: Space = if (&(v156_9)).is_empty() { Space::new() } else {
          let v158_11: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v152_13_cursor,(v152_13_origin + 2)),&(*CONSTANT_4))));
          let mut v158_12 = Space::new();
          let mut v158_12_write = v158_12.write_zipper();
          let mut v158_12_cursor = (v158_11).read_zipper();
          let v158_12_origin = v158_12_cursor.path().len();
          for v158_12_byte in v158_12_cursor.child_mask().iter() {
            v158_12_cursor.descend_to_existing_byte(v158_12_byte);
            {
            let v159_2: Space = singleton(&v158_12_cursor.path()[v158_12_origin..(v158_12_origin + 1)]);
            let v159_3: Space = intersect(&(*CONSTANT_9),&(v159_2));
            let v159_4: Space = if has_head(&(v159_3)) { singleton(&[]) } else { Space::new() };
            drop(v159_3);
            let v159_5: Space = subtract(&(*CONSTANT_0),&(v159_4));
            drop(v159_4);
            let v159_7: Space = if (&(v159_5)).is_empty() { Space::new() } else {
              let v160_6: Space = routine_8(c, &v158_12_cursor.path()[v158_12_origin..(v158_12_origin + 1)], &(v155_6), &v152_13_cursor.path()[(v152_13_origin + 1)..(v152_13_origin + 2)], &v158_12_cursor, &v152_13_cursor);
              compose(&(v159_5),&(v160_6))
            };
            drop(v159_5);
            let v159_8: Space = intersect(&(*CONSTANT_9),&(v159_2));
            drop(v159_2);
            let v159_9: Space = if has_head(&(v159_8)) { singleton(&[]) } else { Space::new() };
            drop(v159_8);
            let v159_11: Space = if (&(v159_9)).is_empty() { Space::new() } else {
              let v161_10: Space = routine_9(c, &v158_12_cursor.path()[v158_12_origin..(v158_12_origin + 1)], &(v155_6), &v152_13_cursor.path()[(v152_13_origin + 1)..(v152_13_origin + 2)], &v158_12_cursor, &v152_13_cursor);
              compose(&(v159_9),&(v161_10))
            };
            drop(v159_9);
            let v159_12: Space = unite(&(v159_7),&(v159_11));
            join_wrapped_into(&mut v158_12_write,&((v159_12).read_zipper()),&[]);
            }
            v158_12_cursor.ascend(1);
          }
          drop(v158_12_cursor);
          drop(v158_12_write);
          drop(v158_11);
          compose(&(v156_9),&(v158_12))
        };
        drop(v156_9);
        let v156_14: Space = unite(&(v156_7),&(v156_13));
        join_wrapped_into(&mut v155_11_write,&((v156_14).read_zipper()),&[]);
        }
        v152_13_cursor.ascend(1);
      }
      drop(v155_11_write);
      drop(v155_6);
      compose(&(v153_10),&(v155_11))
    };
    drop(v153_10);
    let v153_13: Space = unite(&(v153_8),&(v153_12));
    join_wrapped_into(&mut v152_13_write,&((v153_13).read_zipper()),&[]);
    }
    v152_13_cursor.ascend(1);
  }
  drop(v152_13_cursor);
  drop(v152_13_write);
  (v152_13).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v162_12 = Space::new();
  let mut v162_12_write = v162_12.write_zipper();
  let mut v162_12_cursor = (*s0).read_zipper();
  let v162_12_origin = v162_12_cursor.path().len();
  for v162_12_byte in v162_12_cursor.child_mask().iter() {
    v162_12_cursor.descend_to_existing_byte(v162_12_byte);
    {
    let v163_2: Space = singleton(&v162_12_cursor.path()[v162_12_origin..(v162_12_origin + 1)]);
    let v163_3: Space = intersect(&(*CONSTANT_9),&(v163_2));
    let v163_4: Space = if has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
    drop(v163_3);
    let v163_5: Space = subtract(&(*CONSTANT_0),&(v163_4));
    drop(v163_4);
    let v163_8: Space = if (&(v163_5)).is_empty() { Space::new() } else {
      let v164_6: Path = concat_path(&(*p0),&v162_12_cursor.path()[v162_12_origin..(v162_12_origin + 1)]);
      let v164_7: Space = routine_6(c, &(v164_6), &(*p1), &v162_12_cursor);
      compose(&(v163_5),&(v164_7))
    };
    drop(v163_5);
    let v163_9: Space = intersect(&(*CONSTANT_9),&(v163_2));
    drop(v163_2);
    let v163_10: Space = if has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
    drop(v163_9);
    let v163_15: Space = if (&(v163_10)).is_empty() { Space::new() } else {
      let v165_6: Path = concat_path(&(*p0),&v162_12_cursor.path()[v162_12_origin..(v162_12_origin + 1)]);
      let v165_12: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v162_12_cursor,(v162_12_origin + 1)),&(*CONSTANT_4))));
      let v165_13: Path = concat_path(&(*p1),&(v165_6));
      let mut v165_14 = Space::new();
      let mut v165_14_write = v165_14.write_zipper();
      let mut v165_14_cursor = (v165_12).read_zipper();
      let v165_14_origin = v165_14_cursor.path().len();
      for v165_14_byte in v165_14_cursor.child_mask().iter() {
        v165_14_cursor.descend_to_existing_byte(v165_14_byte);
        {
        let v166_2: Space = singleton(&v165_14_cursor.path()[v165_14_origin..(v165_14_origin + 1)]);
        let v166_3: Space = intersect(&(*CONSTANT_9),&(v166_2));
        let v166_4: Space = if has_head(&(v166_3)) { singleton(&[]) } else { Space::new() };
        drop(v166_3);
        let v166_5: Space = subtract(&(*CONSTANT_0),&(v166_4));
        drop(v166_4);
        let v166_7: Space = if (&(v166_5)).is_empty() { Space::new() } else {
          let v167_6: Space = routine_8(c, &v165_14_cursor.path()[v165_14_origin..(v165_14_origin + 1)], &(*p1), &(v165_6), &v165_14_cursor, &v162_12_cursor);
          compose(&(v166_5),&(v167_6))
        };
        drop(v166_5);
        let v166_8: Space = intersect(&(*CONSTANT_9),&(v166_2));
        drop(v166_2);
        let v166_9: Space = if has_head(&(v166_8)) { singleton(&[]) } else { Space::new() };
        drop(v166_8);
        let v166_12: Space = if (&(v166_9)).is_empty() { Space::new() } else {
          let v168_10: Space = routine_1(c, &v165_14_cursor.path()[v165_14_origin..(v165_14_origin + 1)], &(*CONSTANT_4), &(*CONSTANT_2));
          let v168_11: Space = unite(&v162_12_cursor,&(v168_10));
          compose(&(v166_9),&(v168_11))
        };
        drop(v166_9);
        let v166_13: Space = wrap(&(v166_12),&(v165_13));
        let v166_14: Space = wrap(&(v166_13),&v165_14_cursor.path()[v165_14_origin..(v165_14_origin + 1)]);
        let v166_15: Space = unite(&(v166_7),&(v166_14));
        join_wrapped_into(&mut v165_14_write,&((v166_15).read_zipper()),&[]);
        }
        v165_14_cursor.ascend(1);
      }
      drop(v165_14_cursor);
      drop(v165_14_write);
      drop(v165_6);
      drop(v165_12);
      drop(v165_13);
      compose(&(v163_10),&(v165_14))
    };
    drop(v163_10);
    let v163_16: Space = unite(&(v163_8),&(v163_15));
    join_wrapped_into(&mut v162_12_write,&((v163_16).read_zipper()),&[]);
    }
    v162_12_cursor.ascend(1);
  }
  drop(v162_12_cursor);
  drop(v162_12_write);
  (v162_12).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v169_6: Space = subtract(&(*CONSTANT_10),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_4))));
  let v169_28: Path = concat_path(&(*p1),&(*p0));
  let mut v169_33 = Space::new();
  let mut v169_33_write = v169_33.write_zipper();
  let mut v169_33_cursor = (v169_6).read_zipper();
  let v169_33_origin = v169_33_cursor.path().len();
  for v169_33_byte in v169_33_cursor.child_mask().iter() {
    v169_33_cursor.descend_to_existing_byte(v169_33_byte);
    {
    let v170_2: Space = singleton(&v169_33_cursor.path()[v169_33_origin..(v169_33_origin + 1)]);
    let v170_3: Space = intersect(&(*CONSTANT_9),&(v170_2));
    let v170_4: Space = if has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
    drop(v170_3);
    let v170_5: Space = subtract(&(*CONSTANT_0),&(v170_4));
    drop(v170_4);
    let v170_7: Space = if (&(v170_5)).is_empty() { Space::new() } else {
      let mut v171_6 = Space::new();
      let mut v171_6_write = v171_6.write_zipper();
      for v171_6_byte in v169_33_cursor.child_mask().iter() {
        v169_33_cursor.descend_to_existing_byte(v171_6_byte);
        {
        let v172_2: Space = singleton(&v169_33_cursor.path()[(v169_33_origin + 1)..(v169_33_origin + 2)]);
        let v172_3: Space = intersect(&(*CONSTANT_9),&(v172_2));
        let v172_4: Space = if has_head(&(v172_3)) { singleton(&[]) } else { Space::new() };
        drop(v172_3);
        let v172_5: Space = subtract(&(*CONSTANT_0),&(v172_4));
        drop(v172_4);
        let v172_8: Space = if (&(v172_5)).is_empty() { Space::new() } else {
          let v173_7: Space = routine_8(c, &v169_33_cursor.path()[v169_33_origin..(v169_33_origin + 2)], &(*p1), &(*p0), &v169_33_cursor, &(*s0));
          compose(&(v172_5),&(v173_7))
        };
        drop(v172_5);
        let v172_9: Space = intersect(&(*CONSTANT_9),&(v172_2));
        drop(v172_2);
        let v172_10: Space = if has_head(&(v172_9)) { singleton(&[]) } else { Space::new() };
        drop(v172_9);
        let v172_13: Space = if (&(v172_10)).is_empty() { Space::new() } else {
          let v174_11: Space = routine_1(c, &v169_33_cursor.path()[v169_33_origin..(v169_33_origin + 2)], &(*CONSTANT_4), &(*CONSTANT_2));
          let v174_12: Space = unite(&(*s0),&(v174_11));
          compose(&(v172_10),&(v174_12))
        };
        drop(v172_10);
        let v172_14: Space = wrap(&(v172_13),&(v169_28));
        let v172_15: Space = wrap(&(v172_14),&v169_33_cursor.path()[v169_33_origin..(v169_33_origin + 2)]);
        let v172_16: Space = unite(&(v172_8),&(v172_15));
        join_wrapped_into(&mut v171_6_write,&((v172_16).read_zipper()),&[]);
        }
        v169_33_cursor.ascend(1);
      }
      drop(v171_6_write);
      compose(&(v170_5),&(v171_6))
    };
    drop(v170_5);
    let v170_8: Space = intersect(&(*CONSTANT_9),&(v170_2));
    drop(v170_2);
    let v170_9: Space = if has_head(&(v170_8)) { singleton(&[]) } else { Space::new() };
    drop(v170_8);
    let v170_28: Space = if (&(v170_9)).is_empty() { Space::new() } else {
      let v176_25: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v177_10: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_4), &v169_33_cursor.path()[v169_33_origin..(v169_33_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v177_11: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_4), &v169_33_cursor.path()[v169_33_origin..(v169_33_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v177_12: Space = unite(&(v177_10),&(v177_11));
        let v177_13: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_4), &v169_33_cursor.path()[v169_33_origin..(v169_33_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v177_14: Space = unite(&(v177_12),&(v177_13));
        let v177_15: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_4), &v169_33_cursor.path()[v169_33_origin..(v169_33_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v177_16: Space = unite(&(v177_14),&(v177_15));
        let v177_17: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_4), &v169_33_cursor.path()[v169_33_origin..(v169_33_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v177_18: Space = unite(&(v177_16),&(v177_17));
        let v177_19: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_4), &v169_33_cursor.path()[v169_33_origin..(v169_33_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v177_20: Space = unite(&(v177_18),&(v177_19));
        let v177_21: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_4), &v169_33_cursor.path()[v169_33_origin..(v169_33_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v177_22: Space = unite(&(v177_20),&(v177_21));
        let v177_23: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_4), &v169_33_cursor.path()[v169_33_origin..(v169_33_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v177_24: Space = unite(&(v177_22),&(v177_23));
        compose(&(*CONSTANT_0),&(v177_24))
      };
      let v176_26: Space = intersect(&(v176_25),&(*CONSTANT_21));
      let v176_27: Space = unite(&(v176_26),&(*s0));
      compose(&(v170_9),&(v176_27))
    };
    drop(v170_9);
    let v170_29: Space = wrap(&(v170_28),&(v169_28));
    let v170_30: Space = wrap(&(v170_29),&v169_33_cursor.path()[v169_33_origin..(v169_33_origin + 1)]);
    let v170_31: Space = unite(&(v170_7),&(v170_30));
    join_wrapped_into(&mut v169_33_write,&((v170_31).read_zipper()),&[]);
    }
    v169_33_cursor.ascend(1);
  }
  drop(v169_33_cursor);
  drop(v169_33_write);
  drop(v169_6);
  drop(v169_28);
  (v169_33).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v178_27: Path = concat_path(&(*p1),&(*p2));
  let mut v178_28 = Space::new();
  let mut v178_28_write = v178_28.write_zipper();
  let mut v178_28_cursor = (*s0).read_zipper();
  let v178_28_origin = v178_28_cursor.path().len();
  for v178_28_byte in v178_28_cursor.child_mask().iter() {
    v178_28_cursor.descend_to_existing_byte(v178_28_byte);
    {
    let v179_2: Space = singleton(&v178_28_cursor.path()[v178_28_origin..(v178_28_origin + 1)]);
    let v179_3: Space = intersect(&(*CONSTANT_9),&(v179_2));
    let v179_4: Space = if has_head(&(v179_3)) { singleton(&[]) } else { Space::new() };
    drop(v179_3);
    let v179_5: Space = subtract(&(*CONSTANT_0),&(v179_4));
    drop(v179_4);
    let v179_8: Space = if (&(v179_5)).is_empty() { Space::new() } else {
      let v180_6: Path = concat_path(&(*p0),&v178_28_cursor.path()[v178_28_origin..(v178_28_origin + 1)]);
      let v180_7: Space = routine_8(c, &(v180_6), &(*p1), &(*p2), &v178_28_cursor, &(*s1));
      compose(&(v179_5),&(v180_7))
    };
    drop(v179_5);
    let v179_9: Space = intersect(&(*CONSTANT_9),&(v179_2));
    drop(v179_2);
    let v179_10: Space = if has_head(&(v179_9)) { singleton(&[]) } else { Space::new() };
    drop(v179_9);
    let v179_29: Space = if (&(v179_10)).is_empty() { Space::new() } else {
      let v181_26: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v182_6: Path = concat_path(&(*p0),&v178_28_cursor.path()[v178_28_origin..(v178_28_origin + 1)]);
        let v182_11: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_4), &(v182_6), &((*CONSTANT_9).read_zipper()));
        let v182_12: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_4), &(v182_6), &((*CONSTANT_9).read_zipper()));
        let v182_13: Space = unite(&(v182_11),&(v182_12));
        let v182_14: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_4), &(v182_6), &((*CONSTANT_9).read_zipper()));
        let v182_15: Space = unite(&(v182_13),&(v182_14));
        let v182_16: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_4), &(v182_6), &((*CONSTANT_9).read_zipper()));
        let v182_17: Space = unite(&(v182_15),&(v182_16));
        let v182_18: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_4), &(v182_6), &((*CONSTANT_9).read_zipper()));
        let v182_19: Space = unite(&(v182_17),&(v182_18));
        let v182_20: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_4), &(v182_6), &((*CONSTANT_9).read_zipper()));
        let v182_21: Space = unite(&(v182_19),&(v182_20));
        let v182_22: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_4), &(v182_6), &((*CONSTANT_9).read_zipper()));
        let v182_23: Space = unite(&(v182_21),&(v182_22));
        let v182_24: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_4), &(v182_6), &((*CONSTANT_9).read_zipper()));
        let v182_25: Space = unite(&(v182_23),&(v182_24));
        compose(&(*CONSTANT_0),&(v182_25))
      };
      let v181_27: Space = intersect(&(v181_26),&(*CONSTANT_21));
      let v181_28: Space = unite(&(v181_27),&(*s1));
      compose(&(v179_10),&(v181_28))
    };
    drop(v179_10);
    let v179_30: Space = wrap(&(v179_29),&(v178_27));
    let v183_6: Path = concat_path(&(*p0),&v178_28_cursor.path()[v178_28_origin..(v178_28_origin + 1)]);
    let v179_31: Space = wrap(&(v179_30),&(v183_6));
    let v179_32: Space = unite(&(v179_8),&(v179_31));
    join_wrapped_into(&mut v178_28_write,&((v179_32).read_zipper()),&[]);
    }
    v178_28_cursor.ascend(1);
  }
  drop(v178_28_cursor);
  drop(v178_28_write);
  drop(v178_27);
  (v178_28).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v184_38: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v185_9: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_4), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v185_12: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_4), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v185_13: Space = unite(&(v185_9),&(v185_12));
    let v185_16: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_4), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v185_17: Space = unite(&(v185_13),&(v185_16));
    let v185_20: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_4), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v185_21: Space = unite(&(v185_17),&(v185_20));
    let v185_24: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_4), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v185_25: Space = unite(&(v185_21),&(v185_24));
    let v185_28: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_4), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v185_29: Space = unite(&(v185_25),&(v185_28));
    let v185_32: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_4), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v185_33: Space = unite(&(v185_29),&(v185_32));
    let v185_36: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_4), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v185_37: Space = unite(&(v185_33),&(v185_36));
    compose(&(*CONSTANT_0),&(v185_37))
  };
  let v184_40: Space = intersect(&(v184_38),&(*CONSTANT_21));
  let v184_41: Space = unite(&(v184_40),&(*s1));
  let v184_42: Path = concat_path(&(*p1),&(*p2));
  let v184_43: Space = wrap(&(v184_41),&(v184_42));
  drop(v184_42);
  let v184_44: Space = wrap(&(v184_43),&(*p0));
  (v184_44).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v186_11 = Space::new();
  let mut v186_11_write = v186_11.write_zipper();
  let mut v186_11_cursor = (*s0).read_zipper();
  let v186_11_origin = v186_11_cursor.path().len();
  for v186_11_byte in v186_11_cursor.child_mask().iter() {
    v186_11_cursor.descend_to_existing_byte(v186_11_byte);
    {
    let v187_2: Space = singleton(&v186_11_cursor.path()[v186_11_origin..(v186_11_origin + 1)]);
    let v187_3: Space = intersect(&(*CONSTANT_9),&(v187_2));
    let v187_4: Space = if has_head(&(v187_3)) { singleton(&[]) } else { Space::new() };
    drop(v187_3);
    let v187_5: Space = subtract(&(*CONSTANT_0),&(v187_4));
    drop(v187_4);
    let v187_8: Space = if (&(v187_5)).is_empty() { Space::new() } else {
      let v188_6: Path = concat_path(&(*p0),&v186_11_cursor.path()[v186_11_origin..(v186_11_origin + 1)]);
      let v188_7: Space = routine_10(c, &(v188_6), &v186_11_cursor);
      compose(&(v187_5),&(v188_7))
    };
    drop(v187_5);
    let v187_9: Space = intersect(&(*CONSTANT_9),&(v187_2));
    drop(v187_2);
    let v187_10: Space = if has_head(&(v187_9)) { singleton(&[]) } else { Space::new() };
    drop(v187_9);
    let v187_12: Space = if (&(v187_10)).is_empty() { Space::new() } else {
      let v189_6: Path = concat_path(&(*p0),&v186_11_cursor.path()[v186_11_origin..(v186_11_origin + 1)]);
      let mut v189_11 = Space::new();
      let mut v189_11_write = v189_11.write_zipper();
      for v189_11_byte in v186_11_cursor.child_mask().iter() {
        v186_11_cursor.descend_to_existing_byte(v189_11_byte);
        {
        let v190_2: Space = singleton(&v186_11_cursor.path()[(v186_11_origin + 1)..(v186_11_origin + 2)]);
        let v190_3: Space = intersect(&(*CONSTANT_9),&(v190_2));
        let v190_4: Space = if has_head(&(v190_3)) { singleton(&[]) } else { Space::new() };
        drop(v190_3);
        let v190_5: Space = subtract(&(*CONSTANT_0),&(v190_4));
        drop(v190_4);
        let v190_7: Space = if (&(v190_5)).is_empty() { Space::new() } else {
          let v191_6: Space = routine_11(c, &v186_11_cursor.path()[(v186_11_origin + 1)..(v186_11_origin + 2)], &(v189_6), &v186_11_cursor);
          compose(&(v190_5),&(v191_6))
        };
        drop(v190_5);
        let v190_8: Space = intersect(&(*CONSTANT_9),&(v190_2));
        drop(v190_2);
        let v190_9: Space = if has_head(&(v190_8)) { singleton(&[]) } else { Space::new() };
        drop(v190_8);
        let v190_11: Space = if (&(v190_9)).is_empty() { Space::new() } else {
          let mut v192_10 = Space::new();
          let mut v192_10_write = v192_10.write_zipper();
          for v192_10_byte in v186_11_cursor.child_mask().iter() {
            v186_11_cursor.descend_to_existing_byte(v192_10_byte);
            {
            let v193_2: Space = singleton(&v186_11_cursor.path()[(v186_11_origin + 2)..(v186_11_origin + 3)]);
            let v193_3: Space = intersect(&(*CONSTANT_9),&(v193_2));
            let v193_4: Space = if has_head(&(v193_3)) { singleton(&[]) } else { Space::new() };
            drop(v193_3);
            let v193_5: Space = subtract(&(*CONSTANT_0),&(v193_4));
            drop(v193_4);
            let v193_7: Space = if (&(v193_5)).is_empty() { Space::new() } else {
              let v194_6: Space = routine_13(c, &v186_11_cursor.path()[(v186_11_origin + 2)..(v186_11_origin + 3)], &(v189_6), &v186_11_cursor.path()[(v186_11_origin + 1)..(v186_11_origin + 2)], &v186_11_cursor);
              compose(&(v193_5),&(v194_6))
            };
            drop(v193_5);
            let v193_8: Space = intersect(&(*CONSTANT_9),&(v193_2));
            drop(v193_2);
            let v193_9: Space = if has_head(&(v193_8)) { singleton(&[]) } else { Space::new() };
            drop(v193_8);
            let v193_11: Space = if (&(v193_9)).is_empty() { Space::new() } else {
              let v195_10: Space = routine_14(c, &v186_11_cursor.path()[(v186_11_origin + 2)..(v186_11_origin + 3)], &(v189_6), &v186_11_cursor.path()[(v186_11_origin + 1)..(v186_11_origin + 2)], &v186_11_cursor);
              compose(&(v193_9),&(v195_10))
            };
            drop(v193_9);
            let v193_12: Space = unite(&(v193_7),&(v193_11));
            join_wrapped_into(&mut v192_10_write,&((v193_12).read_zipper()),&[]);
            }
            v186_11_cursor.ascend(1);
          }
          drop(v192_10_write);
          compose(&(v190_9),&(v192_10))
        };
        drop(v190_9);
        let v190_12: Space = unite(&(v190_7),&(v190_11));
        join_wrapped_into(&mut v189_11_write,&((v190_12).read_zipper()),&[]);
        }
        v186_11_cursor.ascend(1);
      }
      drop(v189_11_write);
      drop(v189_6);
      compose(&(v187_10),&(v189_11))
    };
    drop(v187_10);
    let v187_13: Space = unite(&(v187_8),&(v187_12));
    join_wrapped_into(&mut v186_11_write,&((v187_13).read_zipper()),&[]);
    }
    v186_11_cursor.ascend(1);
  }
  drop(v186_11_cursor);
  drop(v186_11_write);
  (v186_11).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v196_14 = Space::new();
  let mut v196_14_write = v196_14.write_zipper();
  let mut v196_14_cursor = (*s0).read_zipper();
  let v196_14_origin = v196_14_cursor.path().len();
  for v196_14_byte in v196_14_cursor.child_mask().iter() {
    v196_14_cursor.descend_to_existing_byte(v196_14_byte);
    {
    let v197_2: Space = singleton(&v196_14_cursor.path()[v196_14_origin..(v196_14_origin + 1)]);
    let v197_3: Space = intersect(&(*CONSTANT_9),&(v197_2));
    let v197_4: Space = if has_head(&(v197_3)) { singleton(&[]) } else { Space::new() };
    drop(v197_3);
    let v197_5: Space = subtract(&(*CONSTANT_0),&(v197_4));
    drop(v197_4);
    let v197_8: Space = if (&(v197_5)).is_empty() { Space::new() } else {
      let v198_6: Path = concat_path(&(*p0),&v196_14_cursor.path()[v196_14_origin..(v196_14_origin + 1)]);
      let v198_7: Space = routine_11(c, &(v198_6), &(*p1), &v196_14_cursor);
      compose(&(v197_5),&(v198_7))
    };
    drop(v197_5);
    let v197_9: Space = intersect(&(*CONSTANT_9),&(v197_2));
    drop(v197_2);
    let v197_10: Space = if has_head(&(v197_9)) { singleton(&[]) } else { Space::new() };
    drop(v197_9);
    let v197_12: Space = if (&(v197_10)).is_empty() { Space::new() } else {
      let v199_6: Path = concat_path(&(*p0),&v196_14_cursor.path()[v196_14_origin..(v196_14_origin + 1)]);
      let mut v199_11 = Space::new();
      let mut v199_11_write = v199_11.write_zipper();
      for v199_11_byte in v196_14_cursor.child_mask().iter() {
        v196_14_cursor.descend_to_existing_byte(v199_11_byte);
        {
        let v200_2: Space = singleton(&v196_14_cursor.path()[(v196_14_origin + 1)..(v196_14_origin + 2)]);
        let v200_3: Space = intersect(&(*CONSTANT_9),&(v200_2));
        let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
        drop(v200_3);
        let v200_5: Space = subtract(&(*CONSTANT_0),&(v200_4));
        drop(v200_4);
        let v200_7: Space = if (&(v200_5)).is_empty() { Space::new() } else {
          let v201_6: Space = routine_13(c, &v196_14_cursor.path()[(v196_14_origin + 1)..(v196_14_origin + 2)], &(*p1), &(v199_6), &v196_14_cursor);
          compose(&(v200_5),&(v201_6))
        };
        drop(v200_5);
        let v200_8: Space = intersect(&(*CONSTANT_9),&(v200_2));
        drop(v200_2);
        let v200_9: Space = if has_head(&(v200_8)) { singleton(&[]) } else { Space::new() };
        drop(v200_8);
        let v200_13: Space = if (&(v200_9)).is_empty() { Space::new() } else {
          let v202_11: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v196_14_cursor,(v196_14_origin + 2)),&(*CONSTANT_5))));
          let mut v202_12 = Space::new();
          let mut v202_12_write = v202_12.write_zipper();
          let mut v202_12_cursor = (v202_11).read_zipper();
          let v202_12_origin = v202_12_cursor.path().len();
          for v202_12_byte in v202_12_cursor.child_mask().iter() {
            v202_12_cursor.descend_to_existing_byte(v202_12_byte);
            {
            let v203_2: Space = singleton(&v202_12_cursor.path()[v202_12_origin..(v202_12_origin + 1)]);
            let v203_3: Space = intersect(&(*CONSTANT_9),&(v203_2));
            let v203_4: Space = if has_head(&(v203_3)) { singleton(&[]) } else { Space::new() };
            drop(v203_3);
            let v203_5: Space = subtract(&(*CONSTANT_0),&(v203_4));
            drop(v203_4);
            let v203_7: Space = if (&(v203_5)).is_empty() { Space::new() } else {
              let v204_6: Space = routine_41(c, &v202_12_cursor.path()[v202_12_origin..(v202_12_origin + 1)], &(*p1), &(v199_6), &v196_14_cursor.path()[(v196_14_origin + 1)..(v196_14_origin + 2)], &v202_12_cursor, &v196_14_cursor);
              compose(&(v203_5),&(v204_6))
            };
            drop(v203_5);
            let v203_8: Space = intersect(&(*CONSTANT_9),&(v203_2));
            drop(v203_2);
            let v203_9: Space = if has_head(&(v203_8)) { singleton(&[]) } else { Space::new() };
            drop(v203_8);
            let v203_11: Space = if (&(v203_9)).is_empty() { Space::new() } else {
              let v205_10: Space = routine_42(c, &v202_12_cursor.path()[v202_12_origin..(v202_12_origin + 1)], &(*p1), &(v199_6), &v196_14_cursor.path()[(v196_14_origin + 1)..(v196_14_origin + 2)], &v202_12_cursor, &v196_14_cursor);
              compose(&(v203_9),&(v205_10))
            };
            drop(v203_9);
            let v203_12: Space = unite(&(v203_7),&(v203_11));
            join_wrapped_into(&mut v202_12_write,&((v203_12).read_zipper()),&[]);
            }
            v202_12_cursor.ascend(1);
          }
          drop(v202_12_cursor);
          drop(v202_12_write);
          drop(v202_11);
          compose(&(v200_9),&(v202_12))
        };
        drop(v200_9);
        let v200_14: Space = unite(&(v200_7),&(v200_13));
        join_wrapped_into(&mut v199_11_write,&((v200_14).read_zipper()),&[]);
        }
        v196_14_cursor.ascend(1);
      }
      drop(v199_11_write);
      drop(v199_6);
      compose(&(v197_10),&(v199_11))
    };
    drop(v197_10);
    let v197_13: Space = unite(&(v197_8),&(v197_12));
    join_wrapped_into(&mut v196_14_write,&((v197_13).read_zipper()),&[]);
    }
    v196_14_cursor.ascend(1);
  }
  drop(v196_14_cursor);
  drop(v196_14_write);
  (v196_14).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v206_16: Path = concat_path(&(*p1),&(*p0));
  let mut v206_20 = Space::new();
  let mut v206_20_write = v206_20.write_zipper();
  let mut v206_20_cursor = (*s0).read_zipper();
  let v206_20_origin = v206_20_cursor.path().len();
  for v206_20_byte in v206_20_cursor.child_mask().iter() {
    v206_20_cursor.descend_to_existing_byte(v206_20_byte);
    {
    let v207_2: Space = singleton(&v206_20_cursor.path()[v206_20_origin..(v206_20_origin + 1)]);
    let v207_3: Space = intersect(&(*CONSTANT_9),&(v207_2));
    let v207_4: Space = if has_head(&(v207_3)) { singleton(&[]) } else { Space::new() };
    drop(v207_3);
    let v207_5: Space = subtract(&(*CONSTANT_0),&(v207_4));
    drop(v207_4);
    let v207_7: Space = if (&(v207_5)).is_empty() { Space::new() } else {
      let mut v208_6 = Space::new();
      let mut v208_6_write = v208_6.write_zipper();
      for v208_6_byte in v206_20_cursor.child_mask().iter() {
        v206_20_cursor.descend_to_existing_byte(v208_6_byte);
        {
        let v209_2: Space = singleton(&v206_20_cursor.path()[(v206_20_origin + 1)..(v206_20_origin + 2)]);
        let v209_3: Space = intersect(&(*CONSTANT_9),&(v209_2));
        let v209_4: Space = if has_head(&(v209_3)) { singleton(&[]) } else { Space::new() };
        drop(v209_3);
        let v209_5: Space = subtract(&(*CONSTANT_0),&(v209_4));
        drop(v209_4);
        let v209_8: Space = if (&(v209_5)).is_empty() { Space::new() } else {
          let v210_7: Space = routine_13(c, &v206_20_cursor.path()[v206_20_origin..(v206_20_origin + 2)], &(*p1), &(*p0), &v206_20_cursor);
          compose(&(v209_5),&(v210_7))
        };
        drop(v209_5);
        let v209_9: Space = intersect(&(*CONSTANT_9),&(v209_2));
        drop(v209_2);
        let v209_10: Space = if has_head(&(v209_9)) { singleton(&[]) } else { Space::new() };
        drop(v209_9);
        let v209_14: Space = if (&(v209_10)).is_empty() { Space::new() } else {
          let v211_12: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v206_20_cursor,(v206_20_origin + 2)),&(*CONSTANT_5))));
          let mut v211_13 = Space::new();
          let mut v211_13_write = v211_13.write_zipper();
          let mut v211_13_cursor = (v211_12).read_zipper();
          let v211_13_origin = v211_13_cursor.path().len();
          for v211_13_byte in v211_13_cursor.child_mask().iter() {
            v211_13_cursor.descend_to_existing_byte(v211_13_byte);
            {
            let v212_2: Space = singleton(&v211_13_cursor.path()[v211_13_origin..(v211_13_origin + 1)]);
            let v212_3: Space = intersect(&(*CONSTANT_9),&(v212_2));
            let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
            drop(v212_3);
            let v212_5: Space = subtract(&(*CONSTANT_0),&(v212_4));
            drop(v212_4);
            let v212_7: Space = if (&(v212_5)).is_empty() { Space::new() } else {
              let v213_6: Space = routine_41(c, &v211_13_cursor.path()[v211_13_origin..(v211_13_origin + 1)], &(*p1), &(*p0), &v206_20_cursor.path()[v206_20_origin..(v206_20_origin + 2)], &v211_13_cursor, &v206_20_cursor);
              compose(&(v212_5),&(v213_6))
            };
            drop(v212_5);
            let v212_8: Space = intersect(&(*CONSTANT_9),&(v212_2));
            drop(v212_2);
            let v212_9: Space = if has_head(&(v212_8)) { singleton(&[]) } else { Space::new() };
            drop(v212_8);
            let v212_11: Space = if (&(v212_9)).is_empty() { Space::new() } else {
              let v214_10: Space = routine_42(c, &v211_13_cursor.path()[v211_13_origin..(v211_13_origin + 1)], &(*p1), &(*p0), &v206_20_cursor.path()[v206_20_origin..(v206_20_origin + 2)], &v211_13_cursor, &v206_20_cursor);
              compose(&(v212_9),&(v214_10))
            };
            drop(v212_9);
            let v212_12: Space = unite(&(v212_7),&(v212_11));
            join_wrapped_into(&mut v211_13_write,&((v212_12).read_zipper()),&[]);
            }
            v211_13_cursor.ascend(1);
          }
          drop(v211_13_cursor);
          drop(v211_13_write);
          drop(v211_12);
          compose(&(v209_10),&(v211_13))
        };
        drop(v209_10);
        let v209_15: Space = unite(&(v209_8),&(v209_14));
        join_wrapped_into(&mut v208_6_write,&((v209_15).read_zipper()),&[]);
        }
        v206_20_cursor.ascend(1);
      }
      drop(v208_6_write);
      compose(&(v207_5),&(v208_6))
    };
    drop(v207_5);
    let v207_8: Space = intersect(&(*CONSTANT_9),&(v207_2));
    drop(v207_2);
    let v207_9: Space = if has_head(&(v207_8)) { singleton(&[]) } else { Space::new() };
    drop(v207_8);
    let v207_14: Space = if (&(v207_9)).is_empty() { Space::new() } else {
      let v215_11: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v206_20_cursor,(v206_20_origin + 1)),&(*CONSTANT_5))));
      let v215_12: Path = concat_path(&(v206_16),&v206_20_cursor.path()[v206_20_origin..(v206_20_origin + 1)]);
      let mut v215_13 = Space::new();
      let mut v215_13_write = v215_13.write_zipper();
      let mut v215_13_cursor = (v215_11).read_zipper();
      let v215_13_origin = v215_13_cursor.path().len();
      for v215_13_byte in v215_13_cursor.child_mask().iter() {
        v215_13_cursor.descend_to_existing_byte(v215_13_byte);
        {
        let v216_2: Space = singleton(&v215_13_cursor.path()[v215_13_origin..(v215_13_origin + 1)]);
        let v216_3: Space = intersect(&(*CONSTANT_9),&(v216_2));
        let v216_4: Space = if has_head(&(v216_3)) { singleton(&[]) } else { Space::new() };
        drop(v216_3);
        let v216_5: Space = subtract(&(*CONSTANT_0),&(v216_4));
        drop(v216_4);
        let v216_7: Space = if (&(v216_5)).is_empty() { Space::new() } else {
          let v217_6: Space = routine_41(c, &v215_13_cursor.path()[v215_13_origin..(v215_13_origin + 1)], &(*p1), &(*p0), &v206_20_cursor.path()[v206_20_origin..(v206_20_origin + 1)], &v215_13_cursor, &v206_20_cursor);
          compose(&(v216_5),&(v217_6))
        };
        drop(v216_5);
        let v216_8: Space = intersect(&(*CONSTANT_9),&(v216_2));
        drop(v216_2);
        let v216_9: Space = if has_head(&(v216_8)) { singleton(&[]) } else { Space::new() };
        drop(v216_8);
        let v216_12: Space = if (&(v216_9)).is_empty() { Space::new() } else {
          let v218_10: Space = routine_1(c, &v215_13_cursor.path()[v215_13_origin..(v215_13_origin + 1)], &(*CONSTANT_5), &(*CONSTANT_2));
          let v218_11: Space = unite(&v206_20_cursor,&(v218_10));
          compose(&(v216_9),&(v218_11))
        };
        drop(v216_9);
        let v216_13: Space = wrap(&(v216_12),&(v215_12));
        let v216_14: Space = wrap(&(v216_13),&v215_13_cursor.path()[v215_13_origin..(v215_13_origin + 1)]);
        let v216_15: Space = unite(&(v216_7),&(v216_14));
        join_wrapped_into(&mut v215_13_write,&((v216_15).read_zipper()),&[]);
        }
        v215_13_cursor.ascend(1);
      }
      drop(v215_13_cursor);
      drop(v215_13_write);
      drop(v215_11);
      drop(v215_12);
      compose(&(v207_9),&(v215_13))
    };
    drop(v207_9);
    let v207_15: Space = unite(&(v207_7),&(v207_14));
    join_wrapped_into(&mut v206_20_write,&((v207_15).read_zipper()),&[]);
    }
    v206_20_cursor.ascend(1);
  }
  drop(v206_20_cursor);
  drop(v206_20_write);
  drop(v206_16);
  (v206_20).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v219_13: Path = concat_path(&(*p1),&(*p2));
  let mut v219_14 = Space::new();
  let mut v219_14_write = v219_14.write_zipper();
  let mut v219_14_cursor = (*s0).read_zipper();
  let v219_14_origin = v219_14_cursor.path().len();
  for v219_14_byte in v219_14_cursor.child_mask().iter() {
    v219_14_cursor.descend_to_existing_byte(v219_14_byte);
    {
    let v220_2: Space = singleton(&v219_14_cursor.path()[v219_14_origin..(v219_14_origin + 1)]);
    let v220_3: Space = intersect(&(*CONSTANT_9),&(v220_2));
    let v220_4: Space = if has_head(&(v220_3)) { singleton(&[]) } else { Space::new() };
    drop(v220_3);
    let v220_5: Space = subtract(&(*CONSTANT_0),&(v220_4));
    drop(v220_4);
    let v220_8: Space = if (&(v220_5)).is_empty() { Space::new() } else {
      let v221_6: Path = concat_path(&(*p0),&v219_14_cursor.path()[v219_14_origin..(v219_14_origin + 1)]);
      let v221_7: Space = routine_13(c, &(v221_6), &(*p1), &(*p2), &v219_14_cursor);
      compose(&(v220_5),&(v221_7))
    };
    drop(v220_5);
    let v220_9: Space = intersect(&(*CONSTANT_9),&(v220_2));
    drop(v220_2);
    let v220_10: Space = if has_head(&(v220_9)) { singleton(&[]) } else { Space::new() };
    drop(v220_9);
    let v220_15: Space = if (&(v220_10)).is_empty() { Space::new() } else {
      let v222_6: Path = concat_path(&(*p0),&v219_14_cursor.path()[v219_14_origin..(v219_14_origin + 1)]);
      let v222_12: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v219_14_cursor,(v219_14_origin + 1)),&(*CONSTANT_5))));
      let v222_13: Path = concat_path(&(v219_13),&(v222_6));
      let mut v222_14 = Space::new();
      let mut v222_14_write = v222_14.write_zipper();
      let mut v222_14_cursor = (v222_12).read_zipper();
      let v222_14_origin = v222_14_cursor.path().len();
      for v222_14_byte in v222_14_cursor.child_mask().iter() {
        v222_14_cursor.descend_to_existing_byte(v222_14_byte);
        {
        let v223_2: Space = singleton(&v222_14_cursor.path()[v222_14_origin..(v222_14_origin + 1)]);
        let v223_3: Space = intersect(&(*CONSTANT_9),&(v223_2));
        let v223_4: Space = if has_head(&(v223_3)) { singleton(&[]) } else { Space::new() };
        drop(v223_3);
        let v223_5: Space = subtract(&(*CONSTANT_0),&(v223_4));
        drop(v223_4);
        let v223_7: Space = if (&(v223_5)).is_empty() { Space::new() } else {
          let v224_6: Space = routine_41(c, &v222_14_cursor.path()[v222_14_origin..(v222_14_origin + 1)], &(*p1), &(*p2), &(v222_6), &v222_14_cursor, &v219_14_cursor);
          compose(&(v223_5),&(v224_6))
        };
        drop(v223_5);
        let v223_8: Space = intersect(&(*CONSTANT_9),&(v223_2));
        drop(v223_2);
        let v223_9: Space = if has_head(&(v223_8)) { singleton(&[]) } else { Space::new() };
        drop(v223_8);
        let v223_12: Space = if (&(v223_9)).is_empty() { Space::new() } else {
          let v225_10: Space = routine_1(c, &v222_14_cursor.path()[v222_14_origin..(v222_14_origin + 1)], &(*CONSTANT_5), &(*CONSTANT_2));
          let v225_11: Space = unite(&v219_14_cursor,&(v225_10));
          compose(&(v223_9),&(v225_11))
        };
        drop(v223_9);
        let v223_13: Space = wrap(&(v223_12),&(v222_13));
        let v223_14: Space = wrap(&(v223_13),&v222_14_cursor.path()[v222_14_origin..(v222_14_origin + 1)]);
        let v223_15: Space = unite(&(v223_7),&(v223_14));
        join_wrapped_into(&mut v222_14_write,&((v223_15).read_zipper()),&[]);
        }
        v222_14_cursor.ascend(1);
      }
      drop(v222_14_cursor);
      drop(v222_14_write);
      drop(v222_6);
      drop(v222_12);
      drop(v222_13);
      compose(&(v220_10),&(v222_14))
    };
    drop(v220_10);
    let v220_16: Space = unite(&(v220_8),&(v220_15));
    join_wrapped_into(&mut v219_14_write,&((v220_16).read_zipper()),&[]);
    }
    v219_14_cursor.ascend(1);
  }
  drop(v219_14_cursor);
  drop(v219_14_write);
  drop(v219_13);
  (v219_14).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v226_7: Space = subtract(&(*CONSTANT_10),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_5))));
  let v226_29: Path = concat_path(&(*p1),&(*p2));
  let v226_30: Path = concat_path(&(v226_29),&(*p0));
  drop(v226_29);
  let mut v226_35 = Space::new();
  let mut v226_35_write = v226_35.write_zipper();
  let mut v226_35_cursor = (v226_7).read_zipper();
  let v226_35_origin = v226_35_cursor.path().len();
  for v226_35_byte in v226_35_cursor.child_mask().iter() {
    v226_35_cursor.descend_to_existing_byte(v226_35_byte);
    {
    let v227_2: Space = singleton(&v226_35_cursor.path()[v226_35_origin..(v226_35_origin + 1)]);
    let v227_3: Space = intersect(&(*CONSTANT_9),&(v227_2));
    let v227_4: Space = if has_head(&(v227_3)) { singleton(&[]) } else { Space::new() };
    drop(v227_3);
    let v227_5: Space = subtract(&(*CONSTANT_0),&(v227_4));
    drop(v227_4);
    let v227_7: Space = if (&(v227_5)).is_empty() { Space::new() } else {
      let mut v228_6 = Space::new();
      let mut v228_6_write = v228_6.write_zipper();
      for v228_6_byte in v226_35_cursor.child_mask().iter() {
        v226_35_cursor.descend_to_existing_byte(v228_6_byte);
        {
        let v229_2: Space = singleton(&v226_35_cursor.path()[(v226_35_origin + 1)..(v226_35_origin + 2)]);
        let v229_3: Space = intersect(&(*CONSTANT_9),&(v229_2));
        let v229_4: Space = if has_head(&(v229_3)) { singleton(&[]) } else { Space::new() };
        drop(v229_3);
        let v229_5: Space = subtract(&(*CONSTANT_0),&(v229_4));
        drop(v229_4);
        let v229_8: Space = if (&(v229_5)).is_empty() { Space::new() } else {
          let v230_7: Space = routine_41(c, &v226_35_cursor.path()[v226_35_origin..(v226_35_origin + 2)], &(*p1), &(*p2), &(*p0), &v226_35_cursor, &(*s0));
          compose(&(v229_5),&(v230_7))
        };
        drop(v229_5);
        let v229_9: Space = intersect(&(*CONSTANT_9),&(v229_2));
        drop(v229_2);
        let v229_10: Space = if has_head(&(v229_9)) { singleton(&[]) } else { Space::new() };
        drop(v229_9);
        let v229_13: Space = if (&(v229_10)).is_empty() { Space::new() } else {
          let v231_11: Space = routine_1(c, &v226_35_cursor.path()[v226_35_origin..(v226_35_origin + 2)], &(*CONSTANT_5), &(*CONSTANT_2));
          let v231_12: Space = unite(&(*s0),&(v231_11));
          compose(&(v229_10),&(v231_12))
        };
        drop(v229_10);
        let v229_14: Space = wrap(&(v229_13),&(v226_30));
        let v229_15: Space = wrap(&(v229_14),&v226_35_cursor.path()[v226_35_origin..(v226_35_origin + 2)]);
        let v229_16: Space = unite(&(v229_8),&(v229_15));
        join_wrapped_into(&mut v228_6_write,&((v229_16).read_zipper()),&[]);
        }
        v226_35_cursor.ascend(1);
      }
      drop(v228_6_write);
      compose(&(v227_5),&(v228_6))
    };
    drop(v227_5);
    let v227_8: Space = intersect(&(*CONSTANT_9),&(v227_2));
    drop(v227_2);
    let v227_9: Space = if has_head(&(v227_8)) { singleton(&[]) } else { Space::new() };
    drop(v227_8);
    let v227_28: Space = if (&(v227_9)).is_empty() { Space::new() } else {
      let v233_25: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v234_10: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_5), &v226_35_cursor.path()[v226_35_origin..(v226_35_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v234_11: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_5), &v226_35_cursor.path()[v226_35_origin..(v226_35_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v234_12: Space = unite(&(v234_10),&(v234_11));
        let v234_13: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_5), &v226_35_cursor.path()[v226_35_origin..(v226_35_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v234_14: Space = unite(&(v234_12),&(v234_13));
        let v234_15: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_5), &v226_35_cursor.path()[v226_35_origin..(v226_35_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v234_16: Space = unite(&(v234_14),&(v234_15));
        let v234_17: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_5), &v226_35_cursor.path()[v226_35_origin..(v226_35_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v234_18: Space = unite(&(v234_16),&(v234_17));
        let v234_19: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_5), &v226_35_cursor.path()[v226_35_origin..(v226_35_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v234_20: Space = unite(&(v234_18),&(v234_19));
        let v234_21: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_5), &v226_35_cursor.path()[v226_35_origin..(v226_35_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v234_22: Space = unite(&(v234_20),&(v234_21));
        let v234_23: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_5), &v226_35_cursor.path()[v226_35_origin..(v226_35_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v234_24: Space = unite(&(v234_22),&(v234_23));
        compose(&(*CONSTANT_0),&(v234_24))
      };
      let v233_26: Space = intersect(&(v233_25),&(*CONSTANT_21));
      let v233_27: Space = unite(&(v233_26),&(*s0));
      compose(&(v227_9),&(v233_27))
    };
    drop(v227_9);
    let v227_29: Space = wrap(&(v227_28),&(v226_30));
    let v227_30: Space = wrap(&(v227_29),&v226_35_cursor.path()[v226_35_origin..(v226_35_origin + 1)]);
    let v227_31: Space = unite(&(v227_7),&(v227_30));
    join_wrapped_into(&mut v226_35_write,&((v227_31).read_zipper()),&[]);
    }
    v226_35_cursor.ascend(1);
  }
  drop(v226_35_cursor);
  drop(v226_35_write);
  drop(v226_7);
  drop(v226_30);
  (v226_35).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v235_11 = Space::new();
  let mut v235_11_write = v235_11.write_zipper();
  let mut v235_11_cursor = (*s0).read_zipper();
  let v235_11_origin = v235_11_cursor.path().len();
  for v235_11_byte in v235_11_cursor.child_mask().iter() {
    v235_11_cursor.descend_to_existing_byte(v235_11_byte);
    {
    let v236_2: Space = singleton(&v235_11_cursor.path()[v235_11_origin..(v235_11_origin + 1)]);
    let v236_3: Space = intersect(&(*CONSTANT_9),&(v236_2));
    let v236_4: Space = if has_head(&(v236_3)) { singleton(&[]) } else { Space::new() };
    drop(v236_3);
    let v236_5: Space = subtract(&(*CONSTANT_0),&(v236_4));
    drop(v236_4);
    let v236_8: Space = if (&(v236_5)).is_empty() { Space::new() } else {
      let v237_6: Path = concat_path(&(*p0),&v235_11_cursor.path()[v235_11_origin..(v235_11_origin + 1)]);
      let v237_7: Space = routine_15(c, &(v237_6), &v235_11_cursor);
      compose(&(v236_5),&(v237_7))
    };
    drop(v236_5);
    let v236_9: Space = intersect(&(*CONSTANT_9),&(v236_2));
    drop(v236_2);
    let v236_10: Space = if has_head(&(v236_9)) { singleton(&[]) } else { Space::new() };
    drop(v236_9);
    let v236_12: Space = if (&(v236_10)).is_empty() { Space::new() } else {
      let v238_6: Path = concat_path(&(*p0),&v235_11_cursor.path()[v235_11_origin..(v235_11_origin + 1)]);
      let mut v238_11 = Space::new();
      let mut v238_11_write = v238_11.write_zipper();
      for v238_11_byte in v235_11_cursor.child_mask().iter() {
        v235_11_cursor.descend_to_existing_byte(v238_11_byte);
        {
        let v239_2: Space = singleton(&v235_11_cursor.path()[(v235_11_origin + 1)..(v235_11_origin + 2)]);
        let v239_3: Space = intersect(&(*CONSTANT_9),&(v239_2));
        let v239_4: Space = if has_head(&(v239_3)) { singleton(&[]) } else { Space::new() };
        drop(v239_3);
        let v239_5: Space = subtract(&(*CONSTANT_0),&(v239_4));
        drop(v239_4);
        let v239_7: Space = if (&(v239_5)).is_empty() { Space::new() } else {
          let v240_6: Space = routine_16(c, &v235_11_cursor.path()[(v235_11_origin + 1)..(v235_11_origin + 2)], &(v238_6), &v235_11_cursor);
          compose(&(v239_5),&(v240_6))
        };
        drop(v239_5);
        let v239_8: Space = intersect(&(*CONSTANT_9),&(v239_2));
        drop(v239_2);
        let v239_9: Space = if has_head(&(v239_8)) { singleton(&[]) } else { Space::new() };
        drop(v239_8);
        let v239_11: Space = if (&(v239_9)).is_empty() { Space::new() } else {
          let mut v241_10 = Space::new();
          let mut v241_10_write = v241_10.write_zipper();
          for v241_10_byte in v235_11_cursor.child_mask().iter() {
            v235_11_cursor.descend_to_existing_byte(v241_10_byte);
            {
            let v242_2: Space = singleton(&v235_11_cursor.path()[(v235_11_origin + 2)..(v235_11_origin + 3)]);
            let v242_3: Space = intersect(&(*CONSTANT_9),&(v242_2));
            let v242_4: Space = if has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
            drop(v242_3);
            let v242_5: Space = subtract(&(*CONSTANT_0),&(v242_4));
            drop(v242_4);
            let v242_7: Space = if (&(v242_5)).is_empty() { Space::new() } else {
              let v243_6: Space = routine_18(c, &v235_11_cursor.path()[(v235_11_origin + 2)..(v235_11_origin + 3)], &v235_11_cursor.path()[(v235_11_origin + 1)..(v235_11_origin + 2)], &(v238_6), &v235_11_cursor);
              compose(&(v242_5),&(v243_6))
            };
            drop(v242_5);
            let v242_8: Space = intersect(&(*CONSTANT_9),&(v242_2));
            drop(v242_2);
            let v242_9: Space = if has_head(&(v242_8)) { singleton(&[]) } else { Space::new() };
            drop(v242_8);
            let v242_11: Space = if (&(v242_9)).is_empty() { Space::new() } else {
              let v244_10: Space = routine_19(c, &v235_11_cursor.path()[(v235_11_origin + 2)..(v235_11_origin + 3)], &v235_11_cursor.path()[(v235_11_origin + 1)..(v235_11_origin + 2)], &(v238_6), &v235_11_cursor);
              compose(&(v242_9),&(v244_10))
            };
            drop(v242_9);
            let v242_12: Space = unite(&(v242_7),&(v242_11));
            join_wrapped_into(&mut v241_10_write,&((v242_12).read_zipper()),&[]);
            }
            v235_11_cursor.ascend(1);
          }
          drop(v241_10_write);
          compose(&(v239_9),&(v241_10))
        };
        drop(v239_9);
        let v239_12: Space = unite(&(v239_7),&(v239_11));
        join_wrapped_into(&mut v238_11_write,&((v239_12).read_zipper()),&[]);
        }
        v235_11_cursor.ascend(1);
      }
      drop(v238_11_write);
      drop(v238_6);
      compose(&(v236_10),&(v238_11))
    };
    drop(v236_10);
    let v236_13: Space = unite(&(v236_8),&(v236_12));
    join_wrapped_into(&mut v235_11_write,&((v236_13).read_zipper()),&[]);
    }
    v235_11_cursor.ascend(1);
  }
  drop(v235_11_cursor);
  drop(v235_11_write);
  (v235_11).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v245_12 = Space::new();
  let mut v245_12_write = v245_12.write_zipper();
  let mut v245_12_cursor = (*s0).read_zipper();
  let v245_12_origin = v245_12_cursor.path().len();
  for v245_12_byte in v245_12_cursor.child_mask().iter() {
    v245_12_cursor.descend_to_existing_byte(v245_12_byte);
    {
    let v246_2: Space = singleton(&v245_12_cursor.path()[v245_12_origin..(v245_12_origin + 1)]);
    let v246_3: Space = intersect(&(*CONSTANT_9),&(v246_2));
    let v246_4: Space = if has_head(&(v246_3)) { singleton(&[]) } else { Space::new() };
    drop(v246_3);
    let v246_5: Space = subtract(&(*CONSTANT_0),&(v246_4));
    drop(v246_4);
    let v246_8: Space = if (&(v246_5)).is_empty() { Space::new() } else {
      let v247_6: Path = concat_path(&(*p0),&v245_12_cursor.path()[v245_12_origin..(v245_12_origin + 1)]);
      let v247_7: Space = routine_16(c, &(v247_6), &(*p1), &v245_12_cursor);
      compose(&(v246_5),&(v247_7))
    };
    drop(v246_5);
    let v246_9: Space = intersect(&(*CONSTANT_9),&(v246_2));
    drop(v246_2);
    let v246_10: Space = if has_head(&(v246_9)) { singleton(&[]) } else { Space::new() };
    drop(v246_9);
    let v246_12: Space = if (&(v246_10)).is_empty() { Space::new() } else {
      let v248_6: Path = concat_path(&(*p0),&v245_12_cursor.path()[v245_12_origin..(v245_12_origin + 1)]);
      let mut v248_11 = Space::new();
      let mut v248_11_write = v248_11.write_zipper();
      for v248_11_byte in v245_12_cursor.child_mask().iter() {
        v245_12_cursor.descend_to_existing_byte(v248_11_byte);
        {
        let v249_2: Space = singleton(&v245_12_cursor.path()[(v245_12_origin + 1)..(v245_12_origin + 2)]);
        let v249_3: Space = intersect(&(*CONSTANT_9),&(v249_2));
        let v249_4: Space = if has_head(&(v249_3)) { singleton(&[]) } else { Space::new() };
        drop(v249_3);
        let v249_5: Space = subtract(&(*CONSTANT_0),&(v249_4));
        drop(v249_4);
        let v249_7: Space = if (&(v249_5)).is_empty() { Space::new() } else {
          let v250_6: Space = routine_18(c, &v245_12_cursor.path()[(v245_12_origin + 1)..(v245_12_origin + 2)], &(v248_6), &(*p1), &v245_12_cursor);
          compose(&(v249_5),&(v250_6))
        };
        drop(v249_5);
        let v249_8: Space = intersect(&(*CONSTANT_9),&(v249_2));
        drop(v249_2);
        let v249_9: Space = if has_head(&(v249_8)) { singleton(&[]) } else { Space::new() };
        drop(v249_8);
        let v249_11: Space = if (&(v249_9)).is_empty() { Space::new() } else {
          let mut v251_10 = Space::new();
          let mut v251_10_write = v251_10.write_zipper();
          for v251_10_byte in v245_12_cursor.child_mask().iter() {
            v245_12_cursor.descend_to_existing_byte(v251_10_byte);
            {
            let v252_2: Space = singleton(&v245_12_cursor.path()[(v245_12_origin + 2)..(v245_12_origin + 3)]);
            let v252_3: Space = intersect(&(*CONSTANT_9),&(v252_2));
            let v252_4: Space = if has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
            drop(v252_3);
            let v252_5: Space = subtract(&(*CONSTANT_0),&(v252_4));
            drop(v252_4);
            let v252_7: Space = if (&(v252_5)).is_empty() { Space::new() } else {
              let v253_6: Space = routine_43(c, &v245_12_cursor.path()[(v245_12_origin + 2)..(v245_12_origin + 3)], &(v248_6), &v245_12_cursor.path()[(v245_12_origin + 1)..(v245_12_origin + 2)], &(*p1), &v245_12_cursor);
              compose(&(v252_5),&(v253_6))
            };
            drop(v252_5);
            let v252_8: Space = intersect(&(*CONSTANT_9),&(v252_2));
            drop(v252_2);
            let v252_9: Space = if has_head(&(v252_8)) { singleton(&[]) } else { Space::new() };
            drop(v252_8);
            let v252_11: Space = if (&(v252_9)).is_empty() { Space::new() } else {
              let v254_10: Space = routine_44(c, &v245_12_cursor.path()[(v245_12_origin + 2)..(v245_12_origin + 3)], &(v248_6), &v245_12_cursor.path()[(v245_12_origin + 1)..(v245_12_origin + 2)], &(*p1), &v245_12_cursor);
              compose(&(v252_9),&(v254_10))
            };
            drop(v252_9);
            let v252_12: Space = unite(&(v252_7),&(v252_11));
            join_wrapped_into(&mut v251_10_write,&((v252_12).read_zipper()),&[]);
            }
            v245_12_cursor.ascend(1);
          }
          drop(v251_10_write);
          compose(&(v249_9),&(v251_10))
        };
        drop(v249_9);
        let v249_12: Space = unite(&(v249_7),&(v249_11));
        join_wrapped_into(&mut v248_11_write,&((v249_12).read_zipper()),&[]);
        }
        v245_12_cursor.ascend(1);
      }
      drop(v248_11_write);
      drop(v248_6);
      compose(&(v246_10),&(v248_11))
    };
    drop(v246_10);
    let v246_13: Space = unite(&(v246_8),&(v246_12));
    join_wrapped_into(&mut v245_12_write,&((v246_13).read_zipper()),&[]);
    }
    v245_12_cursor.ascend(1);
  }
  drop(v245_12_cursor);
  drop(v245_12_write);
  (v245_12).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v255_20 = Space::new();
  let mut v255_20_write = v255_20.write_zipper();
  let mut v255_20_cursor = (*s0).read_zipper();
  let v255_20_origin = v255_20_cursor.path().len();
  for v255_20_byte in v255_20_cursor.child_mask().iter() {
    v255_20_cursor.descend_to_existing_byte(v255_20_byte);
    {
    let v256_2: Space = singleton(&v255_20_cursor.path()[v255_20_origin..(v255_20_origin + 1)]);
    let v256_3: Space = intersect(&(*CONSTANT_9),&(v256_2));
    let v256_4: Space = if has_head(&(v256_3)) { singleton(&[]) } else { Space::new() };
    drop(v256_3);
    let v256_5: Space = subtract(&(*CONSTANT_0),&(v256_4));
    drop(v256_4);
    let v256_7: Space = if (&(v256_5)).is_empty() { Space::new() } else {
      let mut v257_6 = Space::new();
      let mut v257_6_write = v257_6.write_zipper();
      for v257_6_byte in v255_20_cursor.child_mask().iter() {
        v255_20_cursor.descend_to_existing_byte(v257_6_byte);
        {
        let v258_2: Space = singleton(&v255_20_cursor.path()[(v255_20_origin + 1)..(v255_20_origin + 2)]);
        let v258_3: Space = intersect(&(*CONSTANT_9),&(v258_2));
        let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
        drop(v258_3);
        let v258_5: Space = subtract(&(*CONSTANT_0),&(v258_4));
        drop(v258_4);
        let v258_8: Space = if (&(v258_5)).is_empty() { Space::new() } else {
          let v259_7: Space = routine_18(c, &v255_20_cursor.path()[v255_20_origin..(v255_20_origin + 2)], &(*p0), &(*p1), &v255_20_cursor);
          compose(&(v258_5),&(v259_7))
        };
        drop(v258_5);
        let v258_9: Space = intersect(&(*CONSTANT_9),&(v258_2));
        drop(v258_2);
        let v258_10: Space = if has_head(&(v258_9)) { singleton(&[]) } else { Space::new() };
        drop(v258_9);
        let v258_12: Space = if (&(v258_10)).is_empty() { Space::new() } else {
          let mut v260_11 = Space::new();
          let mut v260_11_write = v260_11.write_zipper();
          for v260_11_byte in v255_20_cursor.child_mask().iter() {
            v255_20_cursor.descend_to_existing_byte(v260_11_byte);
            {
            let v261_2: Space = singleton(&v255_20_cursor.path()[(v255_20_origin + 2)..(v255_20_origin + 3)]);
            let v261_3: Space = intersect(&(*CONSTANT_9),&(v261_2));
            let v261_4: Space = if has_head(&(v261_3)) { singleton(&[]) } else { Space::new() };
            drop(v261_3);
            let v261_5: Space = subtract(&(*CONSTANT_0),&(v261_4));
            drop(v261_4);
            let v261_7: Space = if (&(v261_5)).is_empty() { Space::new() } else {
              let v262_6: Space = routine_43(c, &v255_20_cursor.path()[(v255_20_origin + 2)..(v255_20_origin + 3)], &(*p0), &v255_20_cursor.path()[v255_20_origin..(v255_20_origin + 2)], &(*p1), &v255_20_cursor);
              compose(&(v261_5),&(v262_6))
            };
            drop(v261_5);
            let v261_8: Space = intersect(&(*CONSTANT_9),&(v261_2));
            drop(v261_2);
            let v261_9: Space = if has_head(&(v261_8)) { singleton(&[]) } else { Space::new() };
            drop(v261_8);
            let v261_11: Space = if (&(v261_9)).is_empty() { Space::new() } else {
              let v263_10: Space = routine_44(c, &v255_20_cursor.path()[(v255_20_origin + 2)..(v255_20_origin + 3)], &(*p0), &v255_20_cursor.path()[v255_20_origin..(v255_20_origin + 2)], &(*p1), &v255_20_cursor);
              compose(&(v261_9),&(v263_10))
            };
            drop(v261_9);
            let v261_12: Space = unite(&(v261_7),&(v261_11));
            join_wrapped_into(&mut v260_11_write,&((v261_12).read_zipper()),&[]);
            }
            v255_20_cursor.ascend(1);
          }
          drop(v260_11_write);
          compose(&(v258_10),&(v260_11))
        };
        drop(v258_10);
        let v258_13: Space = unite(&(v258_8),&(v258_12));
        join_wrapped_into(&mut v257_6_write,&((v258_13).read_zipper()),&[]);
        }
        v255_20_cursor.ascend(1);
      }
      drop(v257_6_write);
      compose(&(v256_5),&(v257_6))
    };
    drop(v256_5);
    let v256_8: Space = intersect(&(*CONSTANT_9),&(v256_2));
    drop(v256_2);
    let v256_9: Space = if has_head(&(v256_8)) { singleton(&[]) } else { Space::new() };
    drop(v256_8);
    let v256_11: Space = if (&(v256_9)).is_empty() { Space::new() } else {
      let mut v264_10 = Space::new();
      let mut v264_10_write = v264_10.write_zipper();
      for v264_10_byte in v255_20_cursor.child_mask().iter() {
        v255_20_cursor.descend_to_existing_byte(v264_10_byte);
        {
        let v265_2: Space = singleton(&v255_20_cursor.path()[(v255_20_origin + 1)..(v255_20_origin + 2)]);
        let v265_3: Space = intersect(&(*CONSTANT_9),&(v265_2));
        let v265_4: Space = if has_head(&(v265_3)) { singleton(&[]) } else { Space::new() };
        drop(v265_3);
        let v265_5: Space = subtract(&(*CONSTANT_0),&(v265_4));
        drop(v265_4);
        let v265_7: Space = if (&(v265_5)).is_empty() { Space::new() } else {
          let v266_6: Space = routine_43(c, &v255_20_cursor.path()[(v255_20_origin + 1)..(v255_20_origin + 2)], &(*p0), &v255_20_cursor.path()[v255_20_origin..(v255_20_origin + 1)], &(*p1), &v255_20_cursor);
          compose(&(v265_5),&(v266_6))
        };
        drop(v265_5);
        let v265_8: Space = intersect(&(*CONSTANT_9),&(v265_2));
        drop(v265_2);
        let v265_9: Space = if has_head(&(v265_8)) { singleton(&[]) } else { Space::new() };
        drop(v265_8);
        let v265_13: Space = if (&(v265_9)).is_empty() { Space::new() } else {
          let v267_11: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v255_20_cursor,(v255_20_origin + 2)),&(*CONSTANT_6))));
          let mut v267_12 = Space::new();
          let mut v267_12_write = v267_12.write_zipper();
          let mut v267_12_cursor = (v267_11).read_zipper();
          let v267_12_origin = v267_12_cursor.path().len();
          for v267_12_byte in v267_12_cursor.child_mask().iter() {
            v267_12_cursor.descend_to_existing_byte(v267_12_byte);
            {
            let v268_2: Space = singleton(&v267_12_cursor.path()[v267_12_origin..(v267_12_origin + 1)]);
            let v268_3: Space = intersect(&(*CONSTANT_9),&(v268_2));
            let v268_4: Space = if has_head(&(v268_3)) { singleton(&[]) } else { Space::new() };
            drop(v268_3);
            let v268_5: Space = subtract(&(*CONSTANT_0),&(v268_4));
            drop(v268_4);
            let v268_7: Space = if (&(v268_5)).is_empty() { Space::new() } else {
              let v269_6: Space = routine_45(c, &v267_12_cursor.path()[v267_12_origin..(v267_12_origin + 1)], &(*p0), &v255_20_cursor.path()[v255_20_origin..(v255_20_origin + 1)], &v255_20_cursor.path()[(v255_20_origin + 1)..(v255_20_origin + 2)], &(*p1), &v267_12_cursor, &v255_20_cursor);
              compose(&(v268_5),&(v269_6))
            };
            drop(v268_5);
            let v268_8: Space = intersect(&(*CONSTANT_9),&(v268_2));
            drop(v268_2);
            let v268_9: Space = if has_head(&(v268_8)) { singleton(&[]) } else { Space::new() };
            drop(v268_8);
            let v268_11: Space = if (&(v268_9)).is_empty() { Space::new() } else {
              let v270_10: Space = routine_46(c, &v267_12_cursor.path()[v267_12_origin..(v267_12_origin + 1)], &(*p0), &v255_20_cursor.path()[v255_20_origin..(v255_20_origin + 1)], &v255_20_cursor.path()[(v255_20_origin + 1)..(v255_20_origin + 2)], &(*p1), &v267_12_cursor, &v255_20_cursor);
              compose(&(v268_9),&(v270_10))
            };
            drop(v268_9);
            let v268_12: Space = unite(&(v268_7),&(v268_11));
            join_wrapped_into(&mut v267_12_write,&((v268_12).read_zipper()),&[]);
            }
            v267_12_cursor.ascend(1);
          }
          drop(v267_12_cursor);
          drop(v267_12_write);
          drop(v267_11);
          compose(&(v265_9),&(v267_12))
        };
        drop(v265_9);
        let v265_14: Space = unite(&(v265_7),&(v265_13));
        join_wrapped_into(&mut v264_10_write,&((v265_14).read_zipper()),&[]);
        }
        v255_20_cursor.ascend(1);
      }
      drop(v264_10_write);
      compose(&(v256_9),&(v264_10))
    };
    drop(v256_9);
    let v256_12: Space = unite(&(v256_7),&(v256_11));
    join_wrapped_into(&mut v255_20_write,&((v256_12).read_zipper()),&[]);
    }
    v255_20_cursor.ascend(1);
  }
  drop(v255_20_cursor);
  drop(v255_20_write);
  (v255_20).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v271_15 = Space::new();
  let mut v271_15_write = v271_15.write_zipper();
  let mut v271_15_cursor = (*s0).read_zipper();
  let v271_15_origin = v271_15_cursor.path().len();
  for v271_15_byte in v271_15_cursor.child_mask().iter() {
    v271_15_cursor.descend_to_existing_byte(v271_15_byte);
    {
    let v272_2: Space = singleton(&v271_15_cursor.path()[v271_15_origin..(v271_15_origin + 1)]);
    let v272_3: Space = intersect(&(*CONSTANT_9),&(v272_2));
    let v272_4: Space = if has_head(&(v272_3)) { singleton(&[]) } else { Space::new() };
    drop(v272_3);
    let v272_5: Space = subtract(&(*CONSTANT_0),&(v272_4));
    drop(v272_4);
    let v272_8: Space = if (&(v272_5)).is_empty() { Space::new() } else {
      let v273_6: Path = concat_path(&(*p0),&v271_15_cursor.path()[v271_15_origin..(v271_15_origin + 1)]);
      let v273_7: Space = routine_18(c, &(v273_6), &(*p1), &(*p2), &v271_15_cursor);
      compose(&(v272_5),&(v273_7))
    };
    drop(v272_5);
    let v272_9: Space = intersect(&(*CONSTANT_9),&(v272_2));
    drop(v272_2);
    let v272_10: Space = if has_head(&(v272_9)) { singleton(&[]) } else { Space::new() };
    drop(v272_9);
    let v272_12: Space = if (&(v272_10)).is_empty() { Space::new() } else {
      let v274_6: Path = concat_path(&(*p0),&v271_15_cursor.path()[v271_15_origin..(v271_15_origin + 1)]);
      let mut v274_11 = Space::new();
      let mut v274_11_write = v274_11.write_zipper();
      for v274_11_byte in v271_15_cursor.child_mask().iter() {
        v271_15_cursor.descend_to_existing_byte(v274_11_byte);
        {
        let v275_2: Space = singleton(&v271_15_cursor.path()[(v271_15_origin + 1)..(v271_15_origin + 2)]);
        let v275_3: Space = intersect(&(*CONSTANT_9),&(v275_2));
        let v275_4: Space = if has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
        drop(v275_3);
        let v275_5: Space = subtract(&(*CONSTANT_0),&(v275_4));
        drop(v275_4);
        let v275_7: Space = if (&(v275_5)).is_empty() { Space::new() } else {
          let v276_6: Space = routine_43(c, &v271_15_cursor.path()[(v271_15_origin + 1)..(v271_15_origin + 2)], &(*p1), &(v274_6), &(*p2), &v271_15_cursor);
          compose(&(v275_5),&(v276_6))
        };
        drop(v275_5);
        let v275_8: Space = intersect(&(*CONSTANT_9),&(v275_2));
        drop(v275_2);
        let v275_9: Space = if has_head(&(v275_8)) { singleton(&[]) } else { Space::new() };
        drop(v275_8);
        let v275_13: Space = if (&(v275_9)).is_empty() { Space::new() } else {
          let v277_11: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v271_15_cursor,(v271_15_origin + 2)),&(*CONSTANT_6))));
          let mut v277_12 = Space::new();
          let mut v277_12_write = v277_12.write_zipper();
          let mut v277_12_cursor = (v277_11).read_zipper();
          let v277_12_origin = v277_12_cursor.path().len();
          for v277_12_byte in v277_12_cursor.child_mask().iter() {
            v277_12_cursor.descend_to_existing_byte(v277_12_byte);
            {
            let v278_2: Space = singleton(&v277_12_cursor.path()[v277_12_origin..(v277_12_origin + 1)]);
            let v278_3: Space = intersect(&(*CONSTANT_9),&(v278_2));
            let v278_4: Space = if has_head(&(v278_3)) { singleton(&[]) } else { Space::new() };
            drop(v278_3);
            let v278_5: Space = subtract(&(*CONSTANT_0),&(v278_4));
            drop(v278_4);
            let v278_7: Space = if (&(v278_5)).is_empty() { Space::new() } else {
              let v279_6: Space = routine_45(c, &v277_12_cursor.path()[v277_12_origin..(v277_12_origin + 1)], &(*p1), &(v274_6), &v271_15_cursor.path()[(v271_15_origin + 1)..(v271_15_origin + 2)], &(*p2), &v277_12_cursor, &v271_15_cursor);
              compose(&(v278_5),&(v279_6))
            };
            drop(v278_5);
            let v278_8: Space = intersect(&(*CONSTANT_9),&(v278_2));
            drop(v278_2);
            let v278_9: Space = if has_head(&(v278_8)) { singleton(&[]) } else { Space::new() };
            drop(v278_8);
            let v278_11: Space = if (&(v278_9)).is_empty() { Space::new() } else {
              let v280_10: Space = routine_46(c, &v277_12_cursor.path()[v277_12_origin..(v277_12_origin + 1)], &(*p1), &(v274_6), &v271_15_cursor.path()[(v271_15_origin + 1)..(v271_15_origin + 2)], &(*p2), &v277_12_cursor, &v271_15_cursor);
              compose(&(v278_9),&(v280_10))
            };
            drop(v278_9);
            let v278_12: Space = unite(&(v278_7),&(v278_11));
            join_wrapped_into(&mut v277_12_write,&((v278_12).read_zipper()),&[]);
            }
            v277_12_cursor.ascend(1);
          }
          drop(v277_12_cursor);
          drop(v277_12_write);
          drop(v277_11);
          compose(&(v275_9),&(v277_12))
        };
        drop(v275_9);
        let v275_14: Space = unite(&(v275_7),&(v275_13));
        join_wrapped_into(&mut v274_11_write,&((v275_14).read_zipper()),&[]);
        }
        v271_15_cursor.ascend(1);
      }
      drop(v274_11_write);
      drop(v274_6);
      compose(&(v272_10),&(v274_11))
    };
    drop(v272_10);
    let v272_13: Space = unite(&(v272_8),&(v272_12));
    join_wrapped_into(&mut v271_15_write,&((v272_13).read_zipper()),&[]);
    }
    v271_15_cursor.ascend(1);
  }
  drop(v271_15_cursor);
  drop(v271_15_write);
  (v271_15).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v281_17: Path = concat_path(&(*p2),&(*p1));
  let v281_21: Path = concat_path(&(v281_17),&(*p0));
  drop(v281_17);
  let mut v281_22 = Space::new();
  let mut v281_22_write = v281_22.write_zipper();
  let mut v281_22_cursor = (*s0).read_zipper();
  let v281_22_origin = v281_22_cursor.path().len();
  for v281_22_byte in v281_22_cursor.child_mask().iter() {
    v281_22_cursor.descend_to_existing_byte(v281_22_byte);
    {
    let v282_2: Space = singleton(&v281_22_cursor.path()[v281_22_origin..(v281_22_origin + 1)]);
    let v282_3: Space = intersect(&(*CONSTANT_9),&(v282_2));
    let v282_4: Space = if has_head(&(v282_3)) { singleton(&[]) } else { Space::new() };
    drop(v282_3);
    let v282_5: Space = subtract(&(*CONSTANT_0),&(v282_4));
    drop(v282_4);
    let v282_7: Space = if (&(v282_5)).is_empty() { Space::new() } else {
      let mut v283_6 = Space::new();
      let mut v283_6_write = v283_6.write_zipper();
      for v283_6_byte in v281_22_cursor.child_mask().iter() {
        v281_22_cursor.descend_to_existing_byte(v283_6_byte);
        {
        let v284_2: Space = singleton(&v281_22_cursor.path()[(v281_22_origin + 1)..(v281_22_origin + 2)]);
        let v284_3: Space = intersect(&(*CONSTANT_9),&(v284_2));
        let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
        drop(v284_3);
        let v284_5: Space = subtract(&(*CONSTANT_0),&(v284_4));
        drop(v284_4);
        let v284_8: Space = if (&(v284_5)).is_empty() { Space::new() } else {
          let v285_7: Space = routine_43(c, &v281_22_cursor.path()[v281_22_origin..(v281_22_origin + 2)], &(*p1), &(*p0), &(*p2), &v281_22_cursor);
          compose(&(v284_5),&(v285_7))
        };
        drop(v284_5);
        let v284_9: Space = intersect(&(*CONSTANT_9),&(v284_2));
        drop(v284_2);
        let v284_10: Space = if has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
        drop(v284_9);
        let v284_14: Space = if (&(v284_10)).is_empty() { Space::new() } else {
          let v286_12: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v281_22_cursor,(v281_22_origin + 2)),&(*CONSTANT_6))));
          let mut v286_13 = Space::new();
          let mut v286_13_write = v286_13.write_zipper();
          let mut v286_13_cursor = (v286_12).read_zipper();
          let v286_13_origin = v286_13_cursor.path().len();
          for v286_13_byte in v286_13_cursor.child_mask().iter() {
            v286_13_cursor.descend_to_existing_byte(v286_13_byte);
            {
            let v287_2: Space = singleton(&v286_13_cursor.path()[v286_13_origin..(v286_13_origin + 1)]);
            let v287_3: Space = intersect(&(*CONSTANT_9),&(v287_2));
            let v287_4: Space = if has_head(&(v287_3)) { singleton(&[]) } else { Space::new() };
            drop(v287_3);
            let v287_5: Space = subtract(&(*CONSTANT_0),&(v287_4));
            drop(v287_4);
            let v287_7: Space = if (&(v287_5)).is_empty() { Space::new() } else {
              let v288_6: Space = routine_45(c, &v286_13_cursor.path()[v286_13_origin..(v286_13_origin + 1)], &(*p1), &(*p0), &v281_22_cursor.path()[v281_22_origin..(v281_22_origin + 2)], &(*p2), &v286_13_cursor, &v281_22_cursor);
              compose(&(v287_5),&(v288_6))
            };
            drop(v287_5);
            let v287_8: Space = intersect(&(*CONSTANT_9),&(v287_2));
            drop(v287_2);
            let v287_9: Space = if has_head(&(v287_8)) { singleton(&[]) } else { Space::new() };
            drop(v287_8);
            let v287_11: Space = if (&(v287_9)).is_empty() { Space::new() } else {
              let v289_10: Space = routine_46(c, &v286_13_cursor.path()[v286_13_origin..(v286_13_origin + 1)], &(*p1), &(*p0), &v281_22_cursor.path()[v281_22_origin..(v281_22_origin + 2)], &(*p2), &v286_13_cursor, &v281_22_cursor);
              compose(&(v287_9),&(v289_10))
            };
            drop(v287_9);
            let v287_12: Space = unite(&(v287_7),&(v287_11));
            join_wrapped_into(&mut v286_13_write,&((v287_12).read_zipper()),&[]);
            }
            v286_13_cursor.ascend(1);
          }
          drop(v286_13_cursor);
          drop(v286_13_write);
          drop(v286_12);
          compose(&(v284_10),&(v286_13))
        };
        drop(v284_10);
        let v284_15: Space = unite(&(v284_8),&(v284_14));
        join_wrapped_into(&mut v283_6_write,&((v284_15).read_zipper()),&[]);
        }
        v281_22_cursor.ascend(1);
      }
      drop(v283_6_write);
      compose(&(v282_5),&(v283_6))
    };
    drop(v282_5);
    let v282_8: Space = intersect(&(*CONSTANT_9),&(v282_2));
    drop(v282_2);
    let v282_9: Space = if has_head(&(v282_8)) { singleton(&[]) } else { Space::new() };
    drop(v282_8);
    let v282_14: Space = if (&(v282_9)).is_empty() { Space::new() } else {
      let v290_11: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v281_22_cursor,(v281_22_origin + 1)),&(*CONSTANT_6))));
      let v290_12: Path = concat_path(&(v281_21),&v281_22_cursor.path()[v281_22_origin..(v281_22_origin + 1)]);
      let mut v290_13 = Space::new();
      let mut v290_13_write = v290_13.write_zipper();
      let mut v290_13_cursor = (v290_11).read_zipper();
      let v290_13_origin = v290_13_cursor.path().len();
      for v290_13_byte in v290_13_cursor.child_mask().iter() {
        v290_13_cursor.descend_to_existing_byte(v290_13_byte);
        {
        let v291_2: Space = singleton(&v290_13_cursor.path()[v290_13_origin..(v290_13_origin + 1)]);
        let v291_3: Space = intersect(&(*CONSTANT_9),&(v291_2));
        let v291_4: Space = if has_head(&(v291_3)) { singleton(&[]) } else { Space::new() };
        drop(v291_3);
        let v291_5: Space = subtract(&(*CONSTANT_0),&(v291_4));
        drop(v291_4);
        let v291_7: Space = if (&(v291_5)).is_empty() { Space::new() } else {
          let v292_6: Space = routine_45(c, &v290_13_cursor.path()[v290_13_origin..(v290_13_origin + 1)], &(*p1), &(*p0), &v281_22_cursor.path()[v281_22_origin..(v281_22_origin + 1)], &(*p2), &v290_13_cursor, &v281_22_cursor);
          compose(&(v291_5),&(v292_6))
        };
        drop(v291_5);
        let v291_8: Space = intersect(&(*CONSTANT_9),&(v291_2));
        drop(v291_2);
        let v291_9: Space = if has_head(&(v291_8)) { singleton(&[]) } else { Space::new() };
        drop(v291_8);
        let v291_12: Space = if (&(v291_9)).is_empty() { Space::new() } else {
          let v293_10: Space = routine_1(c, &v290_13_cursor.path()[v290_13_origin..(v290_13_origin + 1)], &(*CONSTANT_6), &(*CONSTANT_2));
          let v293_11: Space = unite(&v281_22_cursor,&(v293_10));
          compose(&(v291_9),&(v293_11))
        };
        drop(v291_9);
        let v291_13: Space = wrap(&(v291_12),&(v290_12));
        let v291_14: Space = wrap(&(v291_13),&v290_13_cursor.path()[v290_13_origin..(v290_13_origin + 1)]);
        let v291_15: Space = unite(&(v291_7),&(v291_14));
        join_wrapped_into(&mut v290_13_write,&((v291_15).read_zipper()),&[]);
        }
        v290_13_cursor.ascend(1);
      }
      drop(v290_13_cursor);
      drop(v290_13_write);
      drop(v290_11);
      drop(v290_12);
      compose(&(v282_9),&(v290_13))
    };
    drop(v282_9);
    let v282_15: Space = unite(&(v282_7),&(v282_14));
    join_wrapped_into(&mut v281_22_write,&((v282_15).read_zipper()),&[]);
    }
    v281_22_cursor.ascend(1);
  }
  drop(v281_22_cursor);
  drop(v281_22_write);
  drop(v281_21);
  (v281_22).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v294_11 = Space::new();
  let mut v294_11_write = v294_11.write_zipper();
  let mut v294_11_cursor = (*s0).read_zipper();
  let v294_11_origin = v294_11_cursor.path().len();
  for v294_11_byte in v294_11_cursor.child_mask().iter() {
    v294_11_cursor.descend_to_existing_byte(v294_11_byte);
    {
    let v295_2: Space = singleton(&v294_11_cursor.path()[v294_11_origin..(v294_11_origin + 1)]);
    let v295_3: Space = intersect(&(*CONSTANT_9),&(v295_2));
    let v295_4: Space = if has_head(&(v295_3)) { singleton(&[]) } else { Space::new() };
    drop(v295_3);
    let v295_5: Space = subtract(&(*CONSTANT_0),&(v295_4));
    drop(v295_4);
    let v295_8: Space = if (&(v295_5)).is_empty() { Space::new() } else {
      let v296_6: Path = concat_path(&(*p0),&v294_11_cursor.path()[v294_11_origin..(v294_11_origin + 1)]);
      let v296_7: Space = routine_20(c, &(v296_6), &v294_11_cursor);
      compose(&(v295_5),&(v296_7))
    };
    drop(v295_5);
    let v295_9: Space = intersect(&(*CONSTANT_9),&(v295_2));
    drop(v295_2);
    let v295_10: Space = if has_head(&(v295_9)) { singleton(&[]) } else { Space::new() };
    drop(v295_9);
    let v295_12: Space = if (&(v295_10)).is_empty() { Space::new() } else {
      let v297_6: Path = concat_path(&(*p0),&v294_11_cursor.path()[v294_11_origin..(v294_11_origin + 1)]);
      let mut v297_11 = Space::new();
      let mut v297_11_write = v297_11.write_zipper();
      for v297_11_byte in v294_11_cursor.child_mask().iter() {
        v294_11_cursor.descend_to_existing_byte(v297_11_byte);
        {
        let v298_2: Space = singleton(&v294_11_cursor.path()[(v294_11_origin + 1)..(v294_11_origin + 2)]);
        let v298_3: Space = intersect(&(*CONSTANT_9),&(v298_2));
        let v298_4: Space = if has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
        drop(v298_3);
        let v298_5: Space = subtract(&(*CONSTANT_0),&(v298_4));
        drop(v298_4);
        let v298_7: Space = if (&(v298_5)).is_empty() { Space::new() } else {
          let v299_6: Space = routine_21(c, &v294_11_cursor.path()[(v294_11_origin + 1)..(v294_11_origin + 2)], &(v297_6), &v294_11_cursor);
          compose(&(v298_5),&(v299_6))
        };
        drop(v298_5);
        let v298_8: Space = intersect(&(*CONSTANT_9),&(v298_2));
        drop(v298_2);
        let v298_9: Space = if has_head(&(v298_8)) { singleton(&[]) } else { Space::new() };
        drop(v298_8);
        let v298_11: Space = if (&(v298_9)).is_empty() { Space::new() } else {
          let mut v300_10 = Space::new();
          let mut v300_10_write = v300_10.write_zipper();
          for v300_10_byte in v294_11_cursor.child_mask().iter() {
            v294_11_cursor.descend_to_existing_byte(v300_10_byte);
            {
            let v301_2: Space = singleton(&v294_11_cursor.path()[(v294_11_origin + 2)..(v294_11_origin + 3)]);
            let v301_3: Space = intersect(&(*CONSTANT_9),&(v301_2));
            let v301_4: Space = if has_head(&(v301_3)) { singleton(&[]) } else { Space::new() };
            drop(v301_3);
            let v301_5: Space = subtract(&(*CONSTANT_0),&(v301_4));
            drop(v301_4);
            let v301_7: Space = if (&(v301_5)).is_empty() { Space::new() } else {
              let v302_6: Space = routine_23(c, &v294_11_cursor.path()[(v294_11_origin + 2)..(v294_11_origin + 3)], &(v297_6), &v294_11_cursor.path()[(v294_11_origin + 1)..(v294_11_origin + 2)], &v294_11_cursor);
              compose(&(v301_5),&(v302_6))
            };
            drop(v301_5);
            let v301_8: Space = intersect(&(*CONSTANT_9),&(v301_2));
            drop(v301_2);
            let v301_9: Space = if has_head(&(v301_8)) { singleton(&[]) } else { Space::new() };
            drop(v301_8);
            let v301_11: Space = if (&(v301_9)).is_empty() { Space::new() } else {
              let v303_10: Space = routine_24(c, &v294_11_cursor.path()[(v294_11_origin + 2)..(v294_11_origin + 3)], &(v297_6), &v294_11_cursor.path()[(v294_11_origin + 1)..(v294_11_origin + 2)], &v294_11_cursor);
              compose(&(v301_9),&(v303_10))
            };
            drop(v301_9);
            let v301_12: Space = unite(&(v301_7),&(v301_11));
            join_wrapped_into(&mut v300_10_write,&((v301_12).read_zipper()),&[]);
            }
            v294_11_cursor.ascend(1);
          }
          drop(v300_10_write);
          compose(&(v298_9),&(v300_10))
        };
        drop(v298_9);
        let v298_12: Space = unite(&(v298_7),&(v298_11));
        join_wrapped_into(&mut v297_11_write,&((v298_12).read_zipper()),&[]);
        }
        v294_11_cursor.ascend(1);
      }
      drop(v297_11_write);
      drop(v297_6);
      compose(&(v295_10),&(v297_11))
    };
    drop(v295_10);
    let v295_13: Space = unite(&(v295_8),&(v295_12));
    join_wrapped_into(&mut v294_11_write,&((v295_13).read_zipper()),&[]);
    }
    v294_11_cursor.ascend(1);
  }
  drop(v294_11_cursor);
  drop(v294_11_write);
  (v294_11).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v304_12 = Space::new();
  let mut v304_12_write = v304_12.write_zipper();
  let mut v304_12_cursor = (*s0).read_zipper();
  let v304_12_origin = v304_12_cursor.path().len();
  for v304_12_byte in v304_12_cursor.child_mask().iter() {
    v304_12_cursor.descend_to_existing_byte(v304_12_byte);
    {
    let v305_2: Space = singleton(&v304_12_cursor.path()[v304_12_origin..(v304_12_origin + 1)]);
    let v305_3: Space = intersect(&(*CONSTANT_9),&(v305_2));
    let v305_4: Space = if has_head(&(v305_3)) { singleton(&[]) } else { Space::new() };
    drop(v305_3);
    let v305_5: Space = subtract(&(*CONSTANT_0),&(v305_4));
    drop(v305_4);
    let v305_8: Space = if (&(v305_5)).is_empty() { Space::new() } else {
      let v306_6: Path = concat_path(&(*p0),&v304_12_cursor.path()[v304_12_origin..(v304_12_origin + 1)]);
      let v306_7: Space = routine_21(c, &(v306_6), &(*p1), &v304_12_cursor);
      compose(&(v305_5),&(v306_7))
    };
    drop(v305_5);
    let v305_9: Space = intersect(&(*CONSTANT_9),&(v305_2));
    drop(v305_2);
    let v305_10: Space = if has_head(&(v305_9)) { singleton(&[]) } else { Space::new() };
    drop(v305_9);
    let v305_12: Space = if (&(v305_10)).is_empty() { Space::new() } else {
      let v307_6: Path = concat_path(&(*p0),&v304_12_cursor.path()[v304_12_origin..(v304_12_origin + 1)]);
      let mut v307_11 = Space::new();
      let mut v307_11_write = v307_11.write_zipper();
      for v307_11_byte in v304_12_cursor.child_mask().iter() {
        v304_12_cursor.descend_to_existing_byte(v307_11_byte);
        {
        let v308_2: Space = singleton(&v304_12_cursor.path()[(v304_12_origin + 1)..(v304_12_origin + 2)]);
        let v308_3: Space = intersect(&(*CONSTANT_9),&(v308_2));
        let v308_4: Space = if has_head(&(v308_3)) { singleton(&[]) } else { Space::new() };
        drop(v308_3);
        let v308_5: Space = subtract(&(*CONSTANT_0),&(v308_4));
        drop(v308_4);
        let v308_7: Space = if (&(v308_5)).is_empty() { Space::new() } else {
          let v309_6: Space = routine_23(c, &v304_12_cursor.path()[(v304_12_origin + 1)..(v304_12_origin + 2)], &(*p1), &(v307_6), &v304_12_cursor);
          compose(&(v308_5),&(v309_6))
        };
        drop(v308_5);
        let v308_8: Space = intersect(&(*CONSTANT_9),&(v308_2));
        drop(v308_2);
        let v308_9: Space = if has_head(&(v308_8)) { singleton(&[]) } else { Space::new() };
        drop(v308_8);
        let v308_11: Space = if (&(v308_9)).is_empty() { Space::new() } else {
          let mut v310_10 = Space::new();
          let mut v310_10_write = v310_10.write_zipper();
          for v310_10_byte in v304_12_cursor.child_mask().iter() {
            v304_12_cursor.descend_to_existing_byte(v310_10_byte);
            {
            let v311_2: Space = singleton(&v304_12_cursor.path()[(v304_12_origin + 2)..(v304_12_origin + 3)]);
            let v311_3: Space = intersect(&(*CONSTANT_9),&(v311_2));
            let v311_4: Space = if has_head(&(v311_3)) { singleton(&[]) } else { Space::new() };
            drop(v311_3);
            let v311_5: Space = subtract(&(*CONSTANT_0),&(v311_4));
            drop(v311_4);
            let v311_7: Space = if (&(v311_5)).is_empty() { Space::new() } else {
              let v312_6: Space = routine_47(c, &v304_12_cursor.path()[(v304_12_origin + 2)..(v304_12_origin + 3)], &(*p1), &(v307_6), &v304_12_cursor.path()[(v304_12_origin + 1)..(v304_12_origin + 2)], &v304_12_cursor);
              compose(&(v311_5),&(v312_6))
            };
            drop(v311_5);
            let v311_8: Space = intersect(&(*CONSTANT_9),&(v311_2));
            drop(v311_2);
            let v311_9: Space = if has_head(&(v311_8)) { singleton(&[]) } else { Space::new() };
            drop(v311_8);
            let v311_11: Space = if (&(v311_9)).is_empty() { Space::new() } else {
              let v313_10: Space = routine_48(c, &v304_12_cursor.path()[(v304_12_origin + 2)..(v304_12_origin + 3)], &(*p1), &(v307_6), &v304_12_cursor.path()[(v304_12_origin + 1)..(v304_12_origin + 2)], &v304_12_cursor);
              compose(&(v311_9),&(v313_10))
            };
            drop(v311_9);
            let v311_12: Space = unite(&(v311_7),&(v311_11));
            join_wrapped_into(&mut v310_10_write,&((v311_12).read_zipper()),&[]);
            }
            v304_12_cursor.ascend(1);
          }
          drop(v310_10_write);
          compose(&(v308_9),&(v310_10))
        };
        drop(v308_9);
        let v308_12: Space = unite(&(v308_7),&(v308_11));
        join_wrapped_into(&mut v307_11_write,&((v308_12).read_zipper()),&[]);
        }
        v304_12_cursor.ascend(1);
      }
      drop(v307_11_write);
      drop(v307_6);
      compose(&(v305_10),&(v307_11))
    };
    drop(v305_10);
    let v305_13: Space = unite(&(v305_8),&(v305_12));
    join_wrapped_into(&mut v304_12_write,&((v305_13).read_zipper()),&[]);
    }
    v304_12_cursor.ascend(1);
  }
  drop(v304_12_cursor);
  drop(v304_12_write);
  (v304_12).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v314_18 = Space::new();
  let mut v314_18_write = v314_18.write_zipper();
  let mut v314_18_cursor = (*s0).read_zipper();
  let v314_18_origin = v314_18_cursor.path().len();
  for v314_18_byte in v314_18_cursor.child_mask().iter() {
    v314_18_cursor.descend_to_existing_byte(v314_18_byte);
    {
    let v315_2: Space = singleton(&v314_18_cursor.path()[v314_18_origin..(v314_18_origin + 1)]);
    let v315_3: Space = intersect(&(*CONSTANT_9),&(v315_2));
    let v315_4: Space = if has_head(&(v315_3)) { singleton(&[]) } else { Space::new() };
    drop(v315_3);
    let v315_5: Space = subtract(&(*CONSTANT_0),&(v315_4));
    drop(v315_4);
    let v315_7: Space = if (&(v315_5)).is_empty() { Space::new() } else {
      let mut v316_6 = Space::new();
      let mut v316_6_write = v316_6.write_zipper();
      for v316_6_byte in v314_18_cursor.child_mask().iter() {
        v314_18_cursor.descend_to_existing_byte(v316_6_byte);
        {
        let v317_2: Space = singleton(&v314_18_cursor.path()[(v314_18_origin + 1)..(v314_18_origin + 2)]);
        let v317_3: Space = intersect(&(*CONSTANT_9),&(v317_2));
        let v317_4: Space = if has_head(&(v317_3)) { singleton(&[]) } else { Space::new() };
        drop(v317_3);
        let v317_5: Space = subtract(&(*CONSTANT_0),&(v317_4));
        drop(v317_4);
        let v317_8: Space = if (&(v317_5)).is_empty() { Space::new() } else {
          let v318_7: Space = routine_23(c, &v314_18_cursor.path()[v314_18_origin..(v314_18_origin + 2)], &(*p1), &(*p0), &v314_18_cursor);
          compose(&(v317_5),&(v318_7))
        };
        drop(v317_5);
        let v317_9: Space = intersect(&(*CONSTANT_9),&(v317_2));
        drop(v317_2);
        let v317_10: Space = if has_head(&(v317_9)) { singleton(&[]) } else { Space::new() };
        drop(v317_9);
        let v317_12: Space = if (&(v317_10)).is_empty() { Space::new() } else {
          let mut v319_11 = Space::new();
          let mut v319_11_write = v319_11.write_zipper();
          for v319_11_byte in v314_18_cursor.child_mask().iter() {
            v314_18_cursor.descend_to_existing_byte(v319_11_byte);
            {
            let v320_2: Space = singleton(&v314_18_cursor.path()[(v314_18_origin + 2)..(v314_18_origin + 3)]);
            let v320_3: Space = intersect(&(*CONSTANT_9),&(v320_2));
            let v320_4: Space = if has_head(&(v320_3)) { singleton(&[]) } else { Space::new() };
            drop(v320_3);
            let v320_5: Space = subtract(&(*CONSTANT_0),&(v320_4));
            drop(v320_4);
            let v320_7: Space = if (&(v320_5)).is_empty() { Space::new() } else {
              let v321_6: Space = routine_47(c, &v314_18_cursor.path()[(v314_18_origin + 2)..(v314_18_origin + 3)], &(*p1), &(*p0), &v314_18_cursor.path()[v314_18_origin..(v314_18_origin + 2)], &v314_18_cursor);
              compose(&(v320_5),&(v321_6))
            };
            drop(v320_5);
            let v320_8: Space = intersect(&(*CONSTANT_9),&(v320_2));
            drop(v320_2);
            let v320_9: Space = if has_head(&(v320_8)) { singleton(&[]) } else { Space::new() };
            drop(v320_8);
            let v320_11: Space = if (&(v320_9)).is_empty() { Space::new() } else {
              let v322_10: Space = routine_48(c, &v314_18_cursor.path()[(v314_18_origin + 2)..(v314_18_origin + 3)], &(*p1), &(*p0), &v314_18_cursor.path()[v314_18_origin..(v314_18_origin + 2)], &v314_18_cursor);
              compose(&(v320_9),&(v322_10))
            };
            drop(v320_9);
            let v320_12: Space = unite(&(v320_7),&(v320_11));
            join_wrapped_into(&mut v319_11_write,&((v320_12).read_zipper()),&[]);
            }
            v314_18_cursor.ascend(1);
          }
          drop(v319_11_write);
          compose(&(v317_10),&(v319_11))
        };
        drop(v317_10);
        let v317_13: Space = unite(&(v317_8),&(v317_12));
        join_wrapped_into(&mut v316_6_write,&((v317_13).read_zipper()),&[]);
        }
        v314_18_cursor.ascend(1);
      }
      drop(v316_6_write);
      compose(&(v315_5),&(v316_6))
    };
    drop(v315_5);
    let v315_8: Space = intersect(&(*CONSTANT_9),&(v315_2));
    drop(v315_2);
    let v315_9: Space = if has_head(&(v315_8)) { singleton(&[]) } else { Space::new() };
    drop(v315_8);
    let v315_11: Space = if (&(v315_9)).is_empty() { Space::new() } else {
      let mut v323_10 = Space::new();
      let mut v323_10_write = v323_10.write_zipper();
      for v323_10_byte in v314_18_cursor.child_mask().iter() {
        v314_18_cursor.descend_to_existing_byte(v323_10_byte);
        {
        let v324_2: Space = singleton(&v314_18_cursor.path()[(v314_18_origin + 1)..(v314_18_origin + 2)]);
        let v324_3: Space = intersect(&(*CONSTANT_9),&(v324_2));
        let v324_4: Space = if has_head(&(v324_3)) { singleton(&[]) } else { Space::new() };
        drop(v324_3);
        let v324_5: Space = subtract(&(*CONSTANT_0),&(v324_4));
        drop(v324_4);
        let v324_7: Space = if (&(v324_5)).is_empty() { Space::new() } else {
          let v325_6: Space = routine_47(c, &v314_18_cursor.path()[(v314_18_origin + 1)..(v314_18_origin + 2)], &(*p1), &(*p0), &v314_18_cursor.path()[v314_18_origin..(v314_18_origin + 1)], &v314_18_cursor);
          compose(&(v324_5),&(v325_6))
        };
        drop(v324_5);
        let v324_8: Space = intersect(&(*CONSTANT_9),&(v324_2));
        drop(v324_2);
        let v324_9: Space = if has_head(&(v324_8)) { singleton(&[]) } else { Space::new() };
        drop(v324_8);
        let v324_11: Space = if (&(v324_9)).is_empty() { Space::new() } else {
          let mut v326_10 = Space::new();
          let mut v326_10_write = v326_10.write_zipper();
          for v326_10_byte in v314_18_cursor.child_mask().iter() {
            v314_18_cursor.descend_to_existing_byte(v326_10_byte);
            {
            let v327_2: Space = singleton(&v314_18_cursor.path()[(v314_18_origin + 2)..(v314_18_origin + 3)]);
            let v327_3: Space = intersect(&(*CONSTANT_9),&(v327_2));
            let v327_4: Space = if has_head(&(v327_3)) { singleton(&[]) } else { Space::new() };
            drop(v327_3);
            let v327_5: Space = subtract(&(*CONSTANT_0),&(v327_4));
            drop(v327_4);
            let v327_7: Space = if (&(v327_5)).is_empty() { Space::new() } else {
              let v328_6: Space = routine_49(c, &v314_18_cursor.path()[(v314_18_origin + 2)..(v314_18_origin + 3)], &(*p1), &(*p0), &v314_18_cursor.path()[v314_18_origin..(v314_18_origin + 1)], &v314_18_cursor.path()[(v314_18_origin + 1)..(v314_18_origin + 2)], &v314_18_cursor);
              compose(&(v327_5),&(v328_6))
            };
            drop(v327_5);
            let v327_8: Space = intersect(&(*CONSTANT_9),&(v327_2));
            drop(v327_2);
            let v327_9: Space = if has_head(&(v327_8)) { singleton(&[]) } else { Space::new() };
            drop(v327_8);
            let v327_11: Space = if (&(v327_9)).is_empty() { Space::new() } else {
              let v329_10: Space = routine_50(c, &v314_18_cursor.path()[(v314_18_origin + 2)..(v314_18_origin + 3)], &(*p1), &(*p0), &v314_18_cursor.path()[v314_18_origin..(v314_18_origin + 1)], &v314_18_cursor.path()[(v314_18_origin + 1)..(v314_18_origin + 2)], &v314_18_cursor);
              compose(&(v327_9),&(v329_10))
            };
            drop(v327_9);
            let v327_12: Space = unite(&(v327_7),&(v327_11));
            join_wrapped_into(&mut v326_10_write,&((v327_12).read_zipper()),&[]);
            }
            v314_18_cursor.ascend(1);
          }
          drop(v326_10_write);
          compose(&(v324_9),&(v326_10))
        };
        drop(v324_9);
        let v324_12: Space = unite(&(v324_7),&(v324_11));
        join_wrapped_into(&mut v323_10_write,&((v324_12).read_zipper()),&[]);
        }
        v314_18_cursor.ascend(1);
      }
      drop(v323_10_write);
      compose(&(v315_9),&(v323_10))
    };
    drop(v315_9);
    let v315_12: Space = unite(&(v315_7),&(v315_11));
    join_wrapped_into(&mut v314_18_write,&((v315_12).read_zipper()),&[]);
    }
    v314_18_cursor.ascend(1);
  }
  drop(v314_18_cursor);
  drop(v314_18_write);
  (v314_18).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v330_13 = Space::new();
  let mut v330_13_write = v330_13.write_zipper();
  let mut v330_13_cursor = (*s0).read_zipper();
  let v330_13_origin = v330_13_cursor.path().len();
  for v330_13_byte in v330_13_cursor.child_mask().iter() {
    v330_13_cursor.descend_to_existing_byte(v330_13_byte);
    {
    let v331_2: Space = singleton(&v330_13_cursor.path()[v330_13_origin..(v330_13_origin + 1)]);
    let v331_3: Space = intersect(&(*CONSTANT_9),&(v331_2));
    let v331_4: Space = if has_head(&(v331_3)) { singleton(&[]) } else { Space::new() };
    drop(v331_3);
    let v331_5: Space = subtract(&(*CONSTANT_0),&(v331_4));
    drop(v331_4);
    let v331_8: Space = if (&(v331_5)).is_empty() { Space::new() } else {
      let v332_6: Path = concat_path(&(*p0),&v330_13_cursor.path()[v330_13_origin..(v330_13_origin + 1)]);
      let v332_7: Space = routine_23(c, &(v332_6), &(*p1), &(*p2), &v330_13_cursor);
      compose(&(v331_5),&(v332_7))
    };
    drop(v331_5);
    let v331_9: Space = intersect(&(*CONSTANT_9),&(v331_2));
    drop(v331_2);
    let v331_10: Space = if has_head(&(v331_9)) { singleton(&[]) } else { Space::new() };
    drop(v331_9);
    let v331_12: Space = if (&(v331_10)).is_empty() { Space::new() } else {
      let v333_6: Path = concat_path(&(*p0),&v330_13_cursor.path()[v330_13_origin..(v330_13_origin + 1)]);
      let mut v333_11 = Space::new();
      let mut v333_11_write = v333_11.write_zipper();
      for v333_11_byte in v330_13_cursor.child_mask().iter() {
        v330_13_cursor.descend_to_existing_byte(v333_11_byte);
        {
        let v334_2: Space = singleton(&v330_13_cursor.path()[(v330_13_origin + 1)..(v330_13_origin + 2)]);
        let v334_3: Space = intersect(&(*CONSTANT_9),&(v334_2));
        let v334_4: Space = if has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
        drop(v334_3);
        let v334_5: Space = subtract(&(*CONSTANT_0),&(v334_4));
        drop(v334_4);
        let v334_7: Space = if (&(v334_5)).is_empty() { Space::new() } else {
          let v335_6: Space = routine_47(c, &v330_13_cursor.path()[(v330_13_origin + 1)..(v330_13_origin + 2)], &(*p1), &(*p2), &(v333_6), &v330_13_cursor);
          compose(&(v334_5),&(v335_6))
        };
        drop(v334_5);
        let v334_8: Space = intersect(&(*CONSTANT_9),&(v334_2));
        drop(v334_2);
        let v334_9: Space = if has_head(&(v334_8)) { singleton(&[]) } else { Space::new() };
        drop(v334_8);
        let v334_11: Space = if (&(v334_9)).is_empty() { Space::new() } else {
          let mut v336_10 = Space::new();
          let mut v336_10_write = v336_10.write_zipper();
          for v336_10_byte in v330_13_cursor.child_mask().iter() {
            v330_13_cursor.descend_to_existing_byte(v336_10_byte);
            {
            let v337_2: Space = singleton(&v330_13_cursor.path()[(v330_13_origin + 2)..(v330_13_origin + 3)]);
            let v337_3: Space = intersect(&(*CONSTANT_9),&(v337_2));
            let v337_4: Space = if has_head(&(v337_3)) { singleton(&[]) } else { Space::new() };
            drop(v337_3);
            let v337_5: Space = subtract(&(*CONSTANT_0),&(v337_4));
            drop(v337_4);
            let v337_7: Space = if (&(v337_5)).is_empty() { Space::new() } else {
              let v338_6: Space = routine_49(c, &v330_13_cursor.path()[(v330_13_origin + 2)..(v330_13_origin + 3)], &(*p1), &(*p2), &(v333_6), &v330_13_cursor.path()[(v330_13_origin + 1)..(v330_13_origin + 2)], &v330_13_cursor);
              compose(&(v337_5),&(v338_6))
            };
            drop(v337_5);
            let v337_8: Space = intersect(&(*CONSTANT_9),&(v337_2));
            drop(v337_2);
            let v337_9: Space = if has_head(&(v337_8)) { singleton(&[]) } else { Space::new() };
            drop(v337_8);
            let v337_11: Space = if (&(v337_9)).is_empty() { Space::new() } else {
              let v339_10: Space = routine_50(c, &v330_13_cursor.path()[(v330_13_origin + 2)..(v330_13_origin + 3)], &(*p1), &(*p2), &(v333_6), &v330_13_cursor.path()[(v330_13_origin + 1)..(v330_13_origin + 2)], &v330_13_cursor);
              compose(&(v337_9),&(v339_10))
            };
            drop(v337_9);
            let v337_12: Space = unite(&(v337_7),&(v337_11));
            join_wrapped_into(&mut v336_10_write,&((v337_12).read_zipper()),&[]);
            }
            v330_13_cursor.ascend(1);
          }
          drop(v336_10_write);
          compose(&(v334_9),&(v336_10))
        };
        drop(v334_9);
        let v334_12: Space = unite(&(v334_7),&(v334_11));
        join_wrapped_into(&mut v333_11_write,&((v334_12).read_zipper()),&[]);
        }
        v330_13_cursor.ascend(1);
      }
      drop(v333_11_write);
      drop(v333_6);
      compose(&(v331_10),&(v333_11))
    };
    drop(v331_10);
    let v331_13: Space = unite(&(v331_8),&(v331_12));
    join_wrapped_into(&mut v330_13_write,&((v331_13).read_zipper()),&[]);
    }
    v330_13_cursor.ascend(1);
  }
  drop(v330_13_cursor);
  drop(v330_13_write);
  (v330_13).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v340_21 = Space::new();
  let mut v340_21_write = v340_21.write_zipper();
  let mut v340_21_cursor = (*s0).read_zipper();
  let v340_21_origin = v340_21_cursor.path().len();
  for v340_21_byte in v340_21_cursor.child_mask().iter() {
    v340_21_cursor.descend_to_existing_byte(v340_21_byte);
    {
    let v341_2: Space = singleton(&v340_21_cursor.path()[v340_21_origin..(v340_21_origin + 1)]);
    let v341_3: Space = intersect(&(*CONSTANT_9),&(v341_2));
    let v341_4: Space = if has_head(&(v341_3)) { singleton(&[]) } else { Space::new() };
    drop(v341_3);
    let v341_5: Space = subtract(&(*CONSTANT_0),&(v341_4));
    drop(v341_4);
    let v341_7: Space = if (&(v341_5)).is_empty() { Space::new() } else {
      let mut v342_6 = Space::new();
      let mut v342_6_write = v342_6.write_zipper();
      for v342_6_byte in v340_21_cursor.child_mask().iter() {
        v340_21_cursor.descend_to_existing_byte(v342_6_byte);
        {
        let v343_2: Space = singleton(&v340_21_cursor.path()[(v340_21_origin + 1)..(v340_21_origin + 2)]);
        let v343_3: Space = intersect(&(*CONSTANT_9),&(v343_2));
        let v343_4: Space = if has_head(&(v343_3)) { singleton(&[]) } else { Space::new() };
        drop(v343_3);
        let v343_5: Space = subtract(&(*CONSTANT_0),&(v343_4));
        drop(v343_4);
        let v343_8: Space = if (&(v343_5)).is_empty() { Space::new() } else {
          let v344_7: Space = routine_47(c, &v340_21_cursor.path()[v340_21_origin..(v340_21_origin + 2)], &(*p1), &(*p2), &(*p0), &v340_21_cursor);
          compose(&(v343_5),&(v344_7))
        };
        drop(v343_5);
        let v343_9: Space = intersect(&(*CONSTANT_9),&(v343_2));
        drop(v343_2);
        let v343_10: Space = if has_head(&(v343_9)) { singleton(&[]) } else { Space::new() };
        drop(v343_9);
        let v343_12: Space = if (&(v343_10)).is_empty() { Space::new() } else {
          let mut v345_11 = Space::new();
          let mut v345_11_write = v345_11.write_zipper();
          for v345_11_byte in v340_21_cursor.child_mask().iter() {
            v340_21_cursor.descend_to_existing_byte(v345_11_byte);
            {
            let v346_2: Space = singleton(&v340_21_cursor.path()[(v340_21_origin + 2)..(v340_21_origin + 3)]);
            let v346_3: Space = intersect(&(*CONSTANT_9),&(v346_2));
            let v346_4: Space = if has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
            drop(v346_3);
            let v346_5: Space = subtract(&(*CONSTANT_0),&(v346_4));
            drop(v346_4);
            let v346_7: Space = if (&(v346_5)).is_empty() { Space::new() } else {
              let v347_6: Space = routine_49(c, &v340_21_cursor.path()[(v340_21_origin + 2)..(v340_21_origin + 3)], &(*p1), &(*p2), &(*p0), &v340_21_cursor.path()[v340_21_origin..(v340_21_origin + 2)], &v340_21_cursor);
              compose(&(v346_5),&(v347_6))
            };
            drop(v346_5);
            let v346_8: Space = intersect(&(*CONSTANT_9),&(v346_2));
            drop(v346_2);
            let v346_9: Space = if has_head(&(v346_8)) { singleton(&[]) } else { Space::new() };
            drop(v346_8);
            let v346_11: Space = if (&(v346_9)).is_empty() { Space::new() } else {
              let v348_10: Space = routine_50(c, &v340_21_cursor.path()[(v340_21_origin + 2)..(v340_21_origin + 3)], &(*p1), &(*p2), &(*p0), &v340_21_cursor.path()[v340_21_origin..(v340_21_origin + 2)], &v340_21_cursor);
              compose(&(v346_9),&(v348_10))
            };
            drop(v346_9);
            let v346_12: Space = unite(&(v346_7),&(v346_11));
            join_wrapped_into(&mut v345_11_write,&((v346_12).read_zipper()),&[]);
            }
            v340_21_cursor.ascend(1);
          }
          drop(v345_11_write);
          compose(&(v343_10),&(v345_11))
        };
        drop(v343_10);
        let v343_13: Space = unite(&(v343_8),&(v343_12));
        join_wrapped_into(&mut v342_6_write,&((v343_13).read_zipper()),&[]);
        }
        v340_21_cursor.ascend(1);
      }
      drop(v342_6_write);
      compose(&(v341_5),&(v342_6))
    };
    drop(v341_5);
    let v341_8: Space = intersect(&(*CONSTANT_9),&(v341_2));
    drop(v341_2);
    let v341_9: Space = if has_head(&(v341_8)) { singleton(&[]) } else { Space::new() };
    drop(v341_8);
    let v341_11: Space = if (&(v341_9)).is_empty() { Space::new() } else {
      let mut v349_10 = Space::new();
      let mut v349_10_write = v349_10.write_zipper();
      for v349_10_byte in v340_21_cursor.child_mask().iter() {
        v340_21_cursor.descend_to_existing_byte(v349_10_byte);
        {
        let v350_2: Space = singleton(&v340_21_cursor.path()[(v340_21_origin + 1)..(v340_21_origin + 2)]);
        let v350_3: Space = intersect(&(*CONSTANT_9),&(v350_2));
        let v350_4: Space = if has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
        drop(v350_3);
        let v350_5: Space = subtract(&(*CONSTANT_0),&(v350_4));
        drop(v350_4);
        let v350_7: Space = if (&(v350_5)).is_empty() { Space::new() } else {
          let v351_6: Space = routine_49(c, &v340_21_cursor.path()[(v340_21_origin + 1)..(v340_21_origin + 2)], &(*p1), &(*p2), &(*p0), &v340_21_cursor.path()[v340_21_origin..(v340_21_origin + 1)], &v340_21_cursor);
          compose(&(v350_5),&(v351_6))
        };
        drop(v350_5);
        let v350_8: Space = intersect(&(*CONSTANT_9),&(v350_2));
        drop(v350_2);
        let v350_9: Space = if has_head(&(v350_8)) { singleton(&[]) } else { Space::new() };
        drop(v350_8);
        let v350_13: Space = if (&(v350_9)).is_empty() { Space::new() } else {
          let v352_11: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v340_21_cursor,(v340_21_origin + 2)),&(*CONSTANT_7))));
          let mut v352_12 = Space::new();
          let mut v352_12_write = v352_12.write_zipper();
          let mut v352_12_cursor = (v352_11).read_zipper();
          let v352_12_origin = v352_12_cursor.path().len();
          for v352_12_byte in v352_12_cursor.child_mask().iter() {
            v352_12_cursor.descend_to_existing_byte(v352_12_byte);
            {
            let v353_2: Space = singleton(&v352_12_cursor.path()[v352_12_origin..(v352_12_origin + 1)]);
            let v353_3: Space = intersect(&(*CONSTANT_9),&(v353_2));
            let v353_4: Space = if has_head(&(v353_3)) { singleton(&[]) } else { Space::new() };
            drop(v353_3);
            let v353_5: Space = subtract(&(*CONSTANT_0),&(v353_4));
            drop(v353_4);
            let v353_7: Space = if (&(v353_5)).is_empty() { Space::new() } else {
              let v354_6: Space = routine_51(c, &v352_12_cursor.path()[v352_12_origin..(v352_12_origin + 1)], &(*p1), &(*p2), &(*p0), &v340_21_cursor.path()[v340_21_origin..(v340_21_origin + 1)], &v340_21_cursor.path()[(v340_21_origin + 1)..(v340_21_origin + 2)], &v352_12_cursor, &v340_21_cursor);
              compose(&(v353_5),&(v354_6))
            };
            drop(v353_5);
            let v353_8: Space = intersect(&(*CONSTANT_9),&(v353_2));
            drop(v353_2);
            let v353_9: Space = if has_head(&(v353_8)) { singleton(&[]) } else { Space::new() };
            drop(v353_8);
            let v353_11: Space = if (&(v353_9)).is_empty() { Space::new() } else {
              let v355_10: Space = routine_52(c, &v352_12_cursor.path()[v352_12_origin..(v352_12_origin + 1)], &(*p1), &(*p2), &(*p0), &v340_21_cursor.path()[v340_21_origin..(v340_21_origin + 1)], &v340_21_cursor.path()[(v340_21_origin + 1)..(v340_21_origin + 2)], &v352_12_cursor, &v340_21_cursor);
              compose(&(v353_9),&(v355_10))
            };
            drop(v353_9);
            let v353_12: Space = unite(&(v353_7),&(v353_11));
            join_wrapped_into(&mut v352_12_write,&((v353_12).read_zipper()),&[]);
            }
            v352_12_cursor.ascend(1);
          }
          drop(v352_12_cursor);
          drop(v352_12_write);
          drop(v352_11);
          compose(&(v350_9),&(v352_12))
        };
        drop(v350_9);
        let v350_14: Space = unite(&(v350_7),&(v350_13));
        join_wrapped_into(&mut v349_10_write,&((v350_14).read_zipper()),&[]);
        }
        v340_21_cursor.ascend(1);
      }
      drop(v349_10_write);
      compose(&(v341_9),&(v349_10))
    };
    drop(v341_9);
    let v341_12: Space = unite(&(v341_7),&(v341_11));
    join_wrapped_into(&mut v340_21_write,&((v341_12).read_zipper()),&[]);
    }
    v340_21_cursor.ascend(1);
  }
  drop(v340_21_cursor);
  drop(v340_21_write);
  (v340_21).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v356_11 = Space::new();
  let mut v356_11_write = v356_11.write_zipper();
  let mut v356_11_cursor = (*s0).read_zipper();
  let v356_11_origin = v356_11_cursor.path().len();
  for v356_11_byte in v356_11_cursor.child_mask().iter() {
    v356_11_cursor.descend_to_existing_byte(v356_11_byte);
    {
    let v357_2: Space = singleton(&v356_11_cursor.path()[v356_11_origin..(v356_11_origin + 1)]);
    let v357_3: Space = intersect(&(*CONSTANT_9),&(v357_2));
    let v357_4: Space = if has_head(&(v357_3)) { singleton(&[]) } else { Space::new() };
    drop(v357_3);
    let v357_5: Space = subtract(&(*CONSTANT_0),&(v357_4));
    drop(v357_4);
    let v357_8: Space = if (&(v357_5)).is_empty() { Space::new() } else {
      let v358_6: Path = concat_path(&(*p0),&v356_11_cursor.path()[v356_11_origin..(v356_11_origin + 1)]);
      let v358_7: Space = routine_25(c, &(v358_6), &v356_11_cursor);
      compose(&(v357_5),&(v358_7))
    };
    drop(v357_5);
    let v357_9: Space = intersect(&(*CONSTANT_9),&(v357_2));
    drop(v357_2);
    let v357_10: Space = if has_head(&(v357_9)) { singleton(&[]) } else { Space::new() };
    drop(v357_9);
    let v357_12: Space = if (&(v357_10)).is_empty() { Space::new() } else {
      let v359_6: Path = concat_path(&(*p0),&v356_11_cursor.path()[v356_11_origin..(v356_11_origin + 1)]);
      let mut v359_11 = Space::new();
      let mut v359_11_write = v359_11.write_zipper();
      for v359_11_byte in v356_11_cursor.child_mask().iter() {
        v356_11_cursor.descend_to_existing_byte(v359_11_byte);
        {
        let v360_2: Space = singleton(&v356_11_cursor.path()[(v356_11_origin + 1)..(v356_11_origin + 2)]);
        let v360_3: Space = intersect(&(*CONSTANT_9),&(v360_2));
        let v360_4: Space = if has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
        drop(v360_3);
        let v360_5: Space = subtract(&(*CONSTANT_0),&(v360_4));
        drop(v360_4);
        let v360_7: Space = if (&(v360_5)).is_empty() { Space::new() } else {
          let v361_6: Space = routine_26(c, &v356_11_cursor.path()[(v356_11_origin + 1)..(v356_11_origin + 2)], &(v359_6), &v356_11_cursor);
          compose(&(v360_5),&(v361_6))
        };
        drop(v360_5);
        let v360_8: Space = intersect(&(*CONSTANT_9),&(v360_2));
        drop(v360_2);
        let v360_9: Space = if has_head(&(v360_8)) { singleton(&[]) } else { Space::new() };
        drop(v360_8);
        let v360_11: Space = if (&(v360_9)).is_empty() { Space::new() } else {
          let mut v362_10 = Space::new();
          let mut v362_10_write = v362_10.write_zipper();
          for v362_10_byte in v356_11_cursor.child_mask().iter() {
            v356_11_cursor.descend_to_existing_byte(v362_10_byte);
            {
            let v363_2: Space = singleton(&v356_11_cursor.path()[(v356_11_origin + 2)..(v356_11_origin + 3)]);
            let v363_3: Space = intersect(&(*CONSTANT_9),&(v363_2));
            let v363_4: Space = if has_head(&(v363_3)) { singleton(&[]) } else { Space::new() };
            drop(v363_3);
            let v363_5: Space = subtract(&(*CONSTANT_0),&(v363_4));
            drop(v363_4);
            let v363_7: Space = if (&(v363_5)).is_empty() { Space::new() } else {
              let v364_6: Space = routine_28(c, &v356_11_cursor.path()[(v356_11_origin + 2)..(v356_11_origin + 3)], &(v359_6), &v356_11_cursor.path()[(v356_11_origin + 1)..(v356_11_origin + 2)], &v356_11_cursor);
              compose(&(v363_5),&(v364_6))
            };
            drop(v363_5);
            let v363_8: Space = intersect(&(*CONSTANT_9),&(v363_2));
            drop(v363_2);
            let v363_9: Space = if has_head(&(v363_8)) { singleton(&[]) } else { Space::new() };
            drop(v363_8);
            let v363_11: Space = if (&(v363_9)).is_empty() { Space::new() } else {
              let v365_10: Space = routine_29(c, &v356_11_cursor.path()[(v356_11_origin + 2)..(v356_11_origin + 3)], &(v359_6), &v356_11_cursor.path()[(v356_11_origin + 1)..(v356_11_origin + 2)], &v356_11_cursor);
              compose(&(v363_9),&(v365_10))
            };
            drop(v363_9);
            let v363_12: Space = unite(&(v363_7),&(v363_11));
            join_wrapped_into(&mut v362_10_write,&((v363_12).read_zipper()),&[]);
            }
            v356_11_cursor.ascend(1);
          }
          drop(v362_10_write);
          compose(&(v360_9),&(v362_10))
        };
        drop(v360_9);
        let v360_12: Space = unite(&(v360_7),&(v360_11));
        join_wrapped_into(&mut v359_11_write,&((v360_12).read_zipper()),&[]);
        }
        v356_11_cursor.ascend(1);
      }
      drop(v359_11_write);
      drop(v359_6);
      compose(&(v357_10),&(v359_11))
    };
    drop(v357_10);
    let v357_13: Space = unite(&(v357_8),&(v357_12));
    join_wrapped_into(&mut v356_11_write,&((v357_13).read_zipper()),&[]);
    }
    v356_11_cursor.ascend(1);
  }
  drop(v356_11_cursor);
  drop(v356_11_write);
  (v356_11).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v366_12 = Space::new();
  let mut v366_12_write = v366_12.write_zipper();
  let mut v366_12_cursor = (*s0).read_zipper();
  let v366_12_origin = v366_12_cursor.path().len();
  for v366_12_byte in v366_12_cursor.child_mask().iter() {
    v366_12_cursor.descend_to_existing_byte(v366_12_byte);
    {
    let v367_2: Space = singleton(&v366_12_cursor.path()[v366_12_origin..(v366_12_origin + 1)]);
    let v367_3: Space = intersect(&(*CONSTANT_9),&(v367_2));
    let v367_4: Space = if has_head(&(v367_3)) { singleton(&[]) } else { Space::new() };
    drop(v367_3);
    let v367_5: Space = subtract(&(*CONSTANT_0),&(v367_4));
    drop(v367_4);
    let v367_8: Space = if (&(v367_5)).is_empty() { Space::new() } else {
      let v368_6: Path = concat_path(&(*p0),&v366_12_cursor.path()[v366_12_origin..(v366_12_origin + 1)]);
      let v368_7: Space = routine_26(c, &(v368_6), &(*p1), &v366_12_cursor);
      compose(&(v367_5),&(v368_7))
    };
    drop(v367_5);
    let v367_9: Space = intersect(&(*CONSTANT_9),&(v367_2));
    drop(v367_2);
    let v367_10: Space = if has_head(&(v367_9)) { singleton(&[]) } else { Space::new() };
    drop(v367_9);
    let v367_12: Space = if (&(v367_10)).is_empty() { Space::new() } else {
      let v369_6: Path = concat_path(&(*p0),&v366_12_cursor.path()[v366_12_origin..(v366_12_origin + 1)]);
      let mut v369_11 = Space::new();
      let mut v369_11_write = v369_11.write_zipper();
      for v369_11_byte in v366_12_cursor.child_mask().iter() {
        v366_12_cursor.descend_to_existing_byte(v369_11_byte);
        {
        let v370_2: Space = singleton(&v366_12_cursor.path()[(v366_12_origin + 1)..(v366_12_origin + 2)]);
        let v370_3: Space = intersect(&(*CONSTANT_9),&(v370_2));
        let v370_4: Space = if has_head(&(v370_3)) { singleton(&[]) } else { Space::new() };
        drop(v370_3);
        let v370_5: Space = subtract(&(*CONSTANT_0),&(v370_4));
        drop(v370_4);
        let v370_7: Space = if (&(v370_5)).is_empty() { Space::new() } else {
          let v371_6: Space = routine_28(c, &v366_12_cursor.path()[(v366_12_origin + 1)..(v366_12_origin + 2)], &(*p1), &(v369_6), &v366_12_cursor);
          compose(&(v370_5),&(v371_6))
        };
        drop(v370_5);
        let v370_8: Space = intersect(&(*CONSTANT_9),&(v370_2));
        drop(v370_2);
        let v370_9: Space = if has_head(&(v370_8)) { singleton(&[]) } else { Space::new() };
        drop(v370_8);
        let v370_11: Space = if (&(v370_9)).is_empty() { Space::new() } else {
          let mut v372_10 = Space::new();
          let mut v372_10_write = v372_10.write_zipper();
          for v372_10_byte in v366_12_cursor.child_mask().iter() {
            v366_12_cursor.descend_to_existing_byte(v372_10_byte);
            {
            let v373_2: Space = singleton(&v366_12_cursor.path()[(v366_12_origin + 2)..(v366_12_origin + 3)]);
            let v373_3: Space = intersect(&(*CONSTANT_9),&(v373_2));
            let v373_4: Space = if has_head(&(v373_3)) { singleton(&[]) } else { Space::new() };
            drop(v373_3);
            let v373_5: Space = subtract(&(*CONSTANT_0),&(v373_4));
            drop(v373_4);
            let v373_7: Space = if (&(v373_5)).is_empty() { Space::new() } else {
              let v374_6: Space = routine_53(c, &v366_12_cursor.path()[(v366_12_origin + 2)..(v366_12_origin + 3)], &(*p1), &(v369_6), &v366_12_cursor.path()[(v366_12_origin + 1)..(v366_12_origin + 2)], &v366_12_cursor);
              compose(&(v373_5),&(v374_6))
            };
            drop(v373_5);
            let v373_8: Space = intersect(&(*CONSTANT_9),&(v373_2));
            drop(v373_2);
            let v373_9: Space = if has_head(&(v373_8)) { singleton(&[]) } else { Space::new() };
            drop(v373_8);
            let v373_11: Space = if (&(v373_9)).is_empty() { Space::new() } else {
              let v375_10: Space = routine_54(c, &v366_12_cursor.path()[(v366_12_origin + 2)..(v366_12_origin + 3)], &(*p1), &(v369_6), &v366_12_cursor.path()[(v366_12_origin + 1)..(v366_12_origin + 2)], &v366_12_cursor);
              compose(&(v373_9),&(v375_10))
            };
            drop(v373_9);
            let v373_12: Space = unite(&(v373_7),&(v373_11));
            join_wrapped_into(&mut v372_10_write,&((v373_12).read_zipper()),&[]);
            }
            v366_12_cursor.ascend(1);
          }
          drop(v372_10_write);
          compose(&(v370_9),&(v372_10))
        };
        drop(v370_9);
        let v370_12: Space = unite(&(v370_7),&(v370_11));
        join_wrapped_into(&mut v369_11_write,&((v370_12).read_zipper()),&[]);
        }
        v366_12_cursor.ascend(1);
      }
      drop(v369_11_write);
      drop(v369_6);
      compose(&(v367_10),&(v369_11))
    };
    drop(v367_10);
    let v367_13: Space = unite(&(v367_8),&(v367_12));
    join_wrapped_into(&mut v366_12_write,&((v367_13).read_zipper()),&[]);
    }
    v366_12_cursor.ascend(1);
  }
  drop(v366_12_cursor);
  drop(v366_12_write);
  (v366_12).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v376_18 = Space::new();
  let mut v376_18_write = v376_18.write_zipper();
  let mut v376_18_cursor = (*s0).read_zipper();
  let v376_18_origin = v376_18_cursor.path().len();
  for v376_18_byte in v376_18_cursor.child_mask().iter() {
    v376_18_cursor.descend_to_existing_byte(v376_18_byte);
    {
    let v377_2: Space = singleton(&v376_18_cursor.path()[v376_18_origin..(v376_18_origin + 1)]);
    let v377_3: Space = intersect(&(*CONSTANT_9),&(v377_2));
    let v377_4: Space = if has_head(&(v377_3)) { singleton(&[]) } else { Space::new() };
    drop(v377_3);
    let v377_5: Space = subtract(&(*CONSTANT_0),&(v377_4));
    drop(v377_4);
    let v377_7: Space = if (&(v377_5)).is_empty() { Space::new() } else {
      let mut v378_6 = Space::new();
      let mut v378_6_write = v378_6.write_zipper();
      for v378_6_byte in v376_18_cursor.child_mask().iter() {
        v376_18_cursor.descend_to_existing_byte(v378_6_byte);
        {
        let v379_2: Space = singleton(&v376_18_cursor.path()[(v376_18_origin + 1)..(v376_18_origin + 2)]);
        let v379_3: Space = intersect(&(*CONSTANT_9),&(v379_2));
        let v379_4: Space = if has_head(&(v379_3)) { singleton(&[]) } else { Space::new() };
        drop(v379_3);
        let v379_5: Space = subtract(&(*CONSTANT_0),&(v379_4));
        drop(v379_4);
        let v379_8: Space = if (&(v379_5)).is_empty() { Space::new() } else {
          let v380_7: Space = routine_28(c, &v376_18_cursor.path()[v376_18_origin..(v376_18_origin + 2)], &(*p1), &(*p0), &v376_18_cursor);
          compose(&(v379_5),&(v380_7))
        };
        drop(v379_5);
        let v379_9: Space = intersect(&(*CONSTANT_9),&(v379_2));
        drop(v379_2);
        let v379_10: Space = if has_head(&(v379_9)) { singleton(&[]) } else { Space::new() };
        drop(v379_9);
        let v379_12: Space = if (&(v379_10)).is_empty() { Space::new() } else {
          let mut v381_11 = Space::new();
          let mut v381_11_write = v381_11.write_zipper();
          for v381_11_byte in v376_18_cursor.child_mask().iter() {
            v376_18_cursor.descend_to_existing_byte(v381_11_byte);
            {
            let v382_2: Space = singleton(&v376_18_cursor.path()[(v376_18_origin + 2)..(v376_18_origin + 3)]);
            let v382_3: Space = intersect(&(*CONSTANT_9),&(v382_2));
            let v382_4: Space = if has_head(&(v382_3)) { singleton(&[]) } else { Space::new() };
            drop(v382_3);
            let v382_5: Space = subtract(&(*CONSTANT_0),&(v382_4));
            drop(v382_4);
            let v382_7: Space = if (&(v382_5)).is_empty() { Space::new() } else {
              let v383_6: Space = routine_53(c, &v376_18_cursor.path()[(v376_18_origin + 2)..(v376_18_origin + 3)], &(*p1), &(*p0), &v376_18_cursor.path()[v376_18_origin..(v376_18_origin + 2)], &v376_18_cursor);
              compose(&(v382_5),&(v383_6))
            };
            drop(v382_5);
            let v382_8: Space = intersect(&(*CONSTANT_9),&(v382_2));
            drop(v382_2);
            let v382_9: Space = if has_head(&(v382_8)) { singleton(&[]) } else { Space::new() };
            drop(v382_8);
            let v382_11: Space = if (&(v382_9)).is_empty() { Space::new() } else {
              let v384_10: Space = routine_54(c, &v376_18_cursor.path()[(v376_18_origin + 2)..(v376_18_origin + 3)], &(*p1), &(*p0), &v376_18_cursor.path()[v376_18_origin..(v376_18_origin + 2)], &v376_18_cursor);
              compose(&(v382_9),&(v384_10))
            };
            drop(v382_9);
            let v382_12: Space = unite(&(v382_7),&(v382_11));
            join_wrapped_into(&mut v381_11_write,&((v382_12).read_zipper()),&[]);
            }
            v376_18_cursor.ascend(1);
          }
          drop(v381_11_write);
          compose(&(v379_10),&(v381_11))
        };
        drop(v379_10);
        let v379_13: Space = unite(&(v379_8),&(v379_12));
        join_wrapped_into(&mut v378_6_write,&((v379_13).read_zipper()),&[]);
        }
        v376_18_cursor.ascend(1);
      }
      drop(v378_6_write);
      compose(&(v377_5),&(v378_6))
    };
    drop(v377_5);
    let v377_8: Space = intersect(&(*CONSTANT_9),&(v377_2));
    drop(v377_2);
    let v377_9: Space = if has_head(&(v377_8)) { singleton(&[]) } else { Space::new() };
    drop(v377_8);
    let v377_11: Space = if (&(v377_9)).is_empty() { Space::new() } else {
      let mut v385_10 = Space::new();
      let mut v385_10_write = v385_10.write_zipper();
      for v385_10_byte in v376_18_cursor.child_mask().iter() {
        v376_18_cursor.descend_to_existing_byte(v385_10_byte);
        {
        let v386_2: Space = singleton(&v376_18_cursor.path()[(v376_18_origin + 1)..(v376_18_origin + 2)]);
        let v386_3: Space = intersect(&(*CONSTANT_9),&(v386_2));
        let v386_4: Space = if has_head(&(v386_3)) { singleton(&[]) } else { Space::new() };
        drop(v386_3);
        let v386_5: Space = subtract(&(*CONSTANT_0),&(v386_4));
        drop(v386_4);
        let v386_7: Space = if (&(v386_5)).is_empty() { Space::new() } else {
          let v387_6: Space = routine_53(c, &v376_18_cursor.path()[(v376_18_origin + 1)..(v376_18_origin + 2)], &(*p1), &(*p0), &v376_18_cursor.path()[v376_18_origin..(v376_18_origin + 1)], &v376_18_cursor);
          compose(&(v386_5),&(v387_6))
        };
        drop(v386_5);
        let v386_8: Space = intersect(&(*CONSTANT_9),&(v386_2));
        drop(v386_2);
        let v386_9: Space = if has_head(&(v386_8)) { singleton(&[]) } else { Space::new() };
        drop(v386_8);
        let v386_11: Space = if (&(v386_9)).is_empty() { Space::new() } else {
          let mut v388_10 = Space::new();
          let mut v388_10_write = v388_10.write_zipper();
          for v388_10_byte in v376_18_cursor.child_mask().iter() {
            v376_18_cursor.descend_to_existing_byte(v388_10_byte);
            {
            let v389_2: Space = singleton(&v376_18_cursor.path()[(v376_18_origin + 2)..(v376_18_origin + 3)]);
            let v389_3: Space = intersect(&(*CONSTANT_9),&(v389_2));
            let v389_4: Space = if has_head(&(v389_3)) { singleton(&[]) } else { Space::new() };
            drop(v389_3);
            let v389_5: Space = subtract(&(*CONSTANT_0),&(v389_4));
            drop(v389_4);
            let v389_7: Space = if (&(v389_5)).is_empty() { Space::new() } else {
              let v390_6: Space = routine_55(c, &v376_18_cursor.path()[(v376_18_origin + 2)..(v376_18_origin + 3)], &(*p1), &(*p0), &v376_18_cursor.path()[v376_18_origin..(v376_18_origin + 1)], &v376_18_cursor.path()[(v376_18_origin + 1)..(v376_18_origin + 2)], &v376_18_cursor);
              compose(&(v389_5),&(v390_6))
            };
            drop(v389_5);
            let v389_8: Space = intersect(&(*CONSTANT_9),&(v389_2));
            drop(v389_2);
            let v389_9: Space = if has_head(&(v389_8)) { singleton(&[]) } else { Space::new() };
            drop(v389_8);
            let v389_11: Space = if (&(v389_9)).is_empty() { Space::new() } else {
              let v391_10: Space = routine_56(c, &v376_18_cursor.path()[(v376_18_origin + 2)..(v376_18_origin + 3)], &(*p1), &(*p0), &v376_18_cursor.path()[v376_18_origin..(v376_18_origin + 1)], &v376_18_cursor.path()[(v376_18_origin + 1)..(v376_18_origin + 2)], &v376_18_cursor);
              compose(&(v389_9),&(v391_10))
            };
            drop(v389_9);
            let v389_12: Space = unite(&(v389_7),&(v389_11));
            join_wrapped_into(&mut v388_10_write,&((v389_12).read_zipper()),&[]);
            }
            v376_18_cursor.ascend(1);
          }
          drop(v388_10_write);
          compose(&(v386_9),&(v388_10))
        };
        drop(v386_9);
        let v386_12: Space = unite(&(v386_7),&(v386_11));
        join_wrapped_into(&mut v385_10_write,&((v386_12).read_zipper()),&[]);
        }
        v376_18_cursor.ascend(1);
      }
      drop(v385_10_write);
      compose(&(v377_9),&(v385_10))
    };
    drop(v377_9);
    let v377_12: Space = unite(&(v377_7),&(v377_11));
    join_wrapped_into(&mut v376_18_write,&((v377_12).read_zipper()),&[]);
    }
    v376_18_cursor.ascend(1);
  }
  drop(v376_18_cursor);
  drop(v376_18_write);
  (v376_18).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v392_13 = Space::new();
  let mut v392_13_write = v392_13.write_zipper();
  let mut v392_13_cursor = (*s0).read_zipper();
  let v392_13_origin = v392_13_cursor.path().len();
  for v392_13_byte in v392_13_cursor.child_mask().iter() {
    v392_13_cursor.descend_to_existing_byte(v392_13_byte);
    {
    let v393_2: Space = singleton(&v392_13_cursor.path()[v392_13_origin..(v392_13_origin + 1)]);
    let v393_3: Space = intersect(&(*CONSTANT_9),&(v393_2));
    let v393_4: Space = if has_head(&(v393_3)) { singleton(&[]) } else { Space::new() };
    drop(v393_3);
    let v393_5: Space = subtract(&(*CONSTANT_0),&(v393_4));
    drop(v393_4);
    let v393_8: Space = if (&(v393_5)).is_empty() { Space::new() } else {
      let v394_6: Path = concat_path(&(*p0),&v392_13_cursor.path()[v392_13_origin..(v392_13_origin + 1)]);
      let v394_7: Space = routine_28(c, &(v394_6), &(*p1), &(*p2), &v392_13_cursor);
      compose(&(v393_5),&(v394_7))
    };
    drop(v393_5);
    let v393_9: Space = intersect(&(*CONSTANT_9),&(v393_2));
    drop(v393_2);
    let v393_10: Space = if has_head(&(v393_9)) { singleton(&[]) } else { Space::new() };
    drop(v393_9);
    let v393_12: Space = if (&(v393_10)).is_empty() { Space::new() } else {
      let v395_6: Path = concat_path(&(*p0),&v392_13_cursor.path()[v392_13_origin..(v392_13_origin + 1)]);
      let mut v395_11 = Space::new();
      let mut v395_11_write = v395_11.write_zipper();
      for v395_11_byte in v392_13_cursor.child_mask().iter() {
        v392_13_cursor.descend_to_existing_byte(v395_11_byte);
        {
        let v396_2: Space = singleton(&v392_13_cursor.path()[(v392_13_origin + 1)..(v392_13_origin + 2)]);
        let v396_3: Space = intersect(&(*CONSTANT_9),&(v396_2));
        let v396_4: Space = if has_head(&(v396_3)) { singleton(&[]) } else { Space::new() };
        drop(v396_3);
        let v396_5: Space = subtract(&(*CONSTANT_0),&(v396_4));
        drop(v396_4);
        let v396_7: Space = if (&(v396_5)).is_empty() { Space::new() } else {
          let v397_6: Space = routine_53(c, &v392_13_cursor.path()[(v392_13_origin + 1)..(v392_13_origin + 2)], &(*p1), &(*p2), &(v395_6), &v392_13_cursor);
          compose(&(v396_5),&(v397_6))
        };
        drop(v396_5);
        let v396_8: Space = intersect(&(*CONSTANT_9),&(v396_2));
        drop(v396_2);
        let v396_9: Space = if has_head(&(v396_8)) { singleton(&[]) } else { Space::new() };
        drop(v396_8);
        let v396_11: Space = if (&(v396_9)).is_empty() { Space::new() } else {
          let mut v398_10 = Space::new();
          let mut v398_10_write = v398_10.write_zipper();
          for v398_10_byte in v392_13_cursor.child_mask().iter() {
            v392_13_cursor.descend_to_existing_byte(v398_10_byte);
            {
            let v399_2: Space = singleton(&v392_13_cursor.path()[(v392_13_origin + 2)..(v392_13_origin + 3)]);
            let v399_3: Space = intersect(&(*CONSTANT_9),&(v399_2));
            let v399_4: Space = if has_head(&(v399_3)) { singleton(&[]) } else { Space::new() };
            drop(v399_3);
            let v399_5: Space = subtract(&(*CONSTANT_0),&(v399_4));
            drop(v399_4);
            let v399_7: Space = if (&(v399_5)).is_empty() { Space::new() } else {
              let v400_6: Space = routine_55(c, &v392_13_cursor.path()[(v392_13_origin + 2)..(v392_13_origin + 3)], &(*p1), &(*p2), &(v395_6), &v392_13_cursor.path()[(v392_13_origin + 1)..(v392_13_origin + 2)], &v392_13_cursor);
              compose(&(v399_5),&(v400_6))
            };
            drop(v399_5);
            let v399_8: Space = intersect(&(*CONSTANT_9),&(v399_2));
            drop(v399_2);
            let v399_9: Space = if has_head(&(v399_8)) { singleton(&[]) } else { Space::new() };
            drop(v399_8);
            let v399_11: Space = if (&(v399_9)).is_empty() { Space::new() } else {
              let v401_10: Space = routine_56(c, &v392_13_cursor.path()[(v392_13_origin + 2)..(v392_13_origin + 3)], &(*p1), &(*p2), &(v395_6), &v392_13_cursor.path()[(v392_13_origin + 1)..(v392_13_origin + 2)], &v392_13_cursor);
              compose(&(v399_9),&(v401_10))
            };
            drop(v399_9);
            let v399_12: Space = unite(&(v399_7),&(v399_11));
            join_wrapped_into(&mut v398_10_write,&((v399_12).read_zipper()),&[]);
            }
            v392_13_cursor.ascend(1);
          }
          drop(v398_10_write);
          compose(&(v396_9),&(v398_10))
        };
        drop(v396_9);
        let v396_12: Space = unite(&(v396_7),&(v396_11));
        join_wrapped_into(&mut v395_11_write,&((v396_12).read_zipper()),&[]);
        }
        v392_13_cursor.ascend(1);
      }
      drop(v395_11_write);
      drop(v395_6);
      compose(&(v393_10),&(v395_11))
    };
    drop(v393_10);
    let v393_13: Space = unite(&(v393_8),&(v393_12));
    join_wrapped_into(&mut v392_13_write,&((v393_13).read_zipper()),&[]);
    }
    v392_13_cursor.ascend(1);
  }
  drop(v392_13_cursor);
  drop(v392_13_write);
  (v392_13).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v402_19 = Space::new();
  let mut v402_19_write = v402_19.write_zipper();
  let mut v402_19_cursor = (*s0).read_zipper();
  let v402_19_origin = v402_19_cursor.path().len();
  for v402_19_byte in v402_19_cursor.child_mask().iter() {
    v402_19_cursor.descend_to_existing_byte(v402_19_byte);
    {
    let v403_2: Space = singleton(&v402_19_cursor.path()[v402_19_origin..(v402_19_origin + 1)]);
    let v403_3: Space = intersect(&(*CONSTANT_9),&(v403_2));
    let v403_4: Space = if has_head(&(v403_3)) { singleton(&[]) } else { Space::new() };
    drop(v403_3);
    let v403_5: Space = subtract(&(*CONSTANT_0),&(v403_4));
    drop(v403_4);
    let v403_7: Space = if (&(v403_5)).is_empty() { Space::new() } else {
      let mut v404_6 = Space::new();
      let mut v404_6_write = v404_6.write_zipper();
      for v404_6_byte in v402_19_cursor.child_mask().iter() {
        v402_19_cursor.descend_to_existing_byte(v404_6_byte);
        {
        let v405_2: Space = singleton(&v402_19_cursor.path()[(v402_19_origin + 1)..(v402_19_origin + 2)]);
        let v405_3: Space = intersect(&(*CONSTANT_9),&(v405_2));
        let v405_4: Space = if has_head(&(v405_3)) { singleton(&[]) } else { Space::new() };
        drop(v405_3);
        let v405_5: Space = subtract(&(*CONSTANT_0),&(v405_4));
        drop(v405_4);
        let v405_8: Space = if (&(v405_5)).is_empty() { Space::new() } else {
          let v406_7: Space = routine_53(c, &v402_19_cursor.path()[v402_19_origin..(v402_19_origin + 2)], &(*p1), &(*p2), &(*p0), &v402_19_cursor);
          compose(&(v405_5),&(v406_7))
        };
        drop(v405_5);
        let v405_9: Space = intersect(&(*CONSTANT_9),&(v405_2));
        drop(v405_2);
        let v405_10: Space = if has_head(&(v405_9)) { singleton(&[]) } else { Space::new() };
        drop(v405_9);
        let v405_12: Space = if (&(v405_10)).is_empty() { Space::new() } else {
          let mut v407_11 = Space::new();
          let mut v407_11_write = v407_11.write_zipper();
          for v407_11_byte in v402_19_cursor.child_mask().iter() {
            v402_19_cursor.descend_to_existing_byte(v407_11_byte);
            {
            let v408_2: Space = singleton(&v402_19_cursor.path()[(v402_19_origin + 2)..(v402_19_origin + 3)]);
            let v408_3: Space = intersect(&(*CONSTANT_9),&(v408_2));
            let v408_4: Space = if has_head(&(v408_3)) { singleton(&[]) } else { Space::new() };
            drop(v408_3);
            let v408_5: Space = subtract(&(*CONSTANT_0),&(v408_4));
            drop(v408_4);
            let v408_7: Space = if (&(v408_5)).is_empty() { Space::new() } else {
              let v409_6: Space = routine_55(c, &v402_19_cursor.path()[(v402_19_origin + 2)..(v402_19_origin + 3)], &(*p1), &(*p2), &(*p0), &v402_19_cursor.path()[v402_19_origin..(v402_19_origin + 2)], &v402_19_cursor);
              compose(&(v408_5),&(v409_6))
            };
            drop(v408_5);
            let v408_8: Space = intersect(&(*CONSTANT_9),&(v408_2));
            drop(v408_2);
            let v408_9: Space = if has_head(&(v408_8)) { singleton(&[]) } else { Space::new() };
            drop(v408_8);
            let v408_11: Space = if (&(v408_9)).is_empty() { Space::new() } else {
              let v410_10: Space = routine_56(c, &v402_19_cursor.path()[(v402_19_origin + 2)..(v402_19_origin + 3)], &(*p1), &(*p2), &(*p0), &v402_19_cursor.path()[v402_19_origin..(v402_19_origin + 2)], &v402_19_cursor);
              compose(&(v408_9),&(v410_10))
            };
            drop(v408_9);
            let v408_12: Space = unite(&(v408_7),&(v408_11));
            join_wrapped_into(&mut v407_11_write,&((v408_12).read_zipper()),&[]);
            }
            v402_19_cursor.ascend(1);
          }
          drop(v407_11_write);
          compose(&(v405_10),&(v407_11))
        };
        drop(v405_10);
        let v405_13: Space = unite(&(v405_8),&(v405_12));
        join_wrapped_into(&mut v404_6_write,&((v405_13).read_zipper()),&[]);
        }
        v402_19_cursor.ascend(1);
      }
      drop(v404_6_write);
      compose(&(v403_5),&(v404_6))
    };
    drop(v403_5);
    let v403_8: Space = intersect(&(*CONSTANT_9),&(v403_2));
    drop(v403_2);
    let v403_9: Space = if has_head(&(v403_8)) { singleton(&[]) } else { Space::new() };
    drop(v403_8);
    let v403_11: Space = if (&(v403_9)).is_empty() { Space::new() } else {
      let mut v411_10 = Space::new();
      let mut v411_10_write = v411_10.write_zipper();
      for v411_10_byte in v402_19_cursor.child_mask().iter() {
        v402_19_cursor.descend_to_existing_byte(v411_10_byte);
        {
        let v412_2: Space = singleton(&v402_19_cursor.path()[(v402_19_origin + 1)..(v402_19_origin + 2)]);
        let v412_3: Space = intersect(&(*CONSTANT_9),&(v412_2));
        let v412_4: Space = if has_head(&(v412_3)) { singleton(&[]) } else { Space::new() };
        drop(v412_3);
        let v412_5: Space = subtract(&(*CONSTANT_0),&(v412_4));
        drop(v412_4);
        let v412_7: Space = if (&(v412_5)).is_empty() { Space::new() } else {
          let v413_6: Space = routine_55(c, &v402_19_cursor.path()[(v402_19_origin + 1)..(v402_19_origin + 2)], &(*p1), &(*p2), &(*p0), &v402_19_cursor.path()[v402_19_origin..(v402_19_origin + 1)], &v402_19_cursor);
          compose(&(v412_5),&(v413_6))
        };
        drop(v412_5);
        let v412_8: Space = intersect(&(*CONSTANT_9),&(v412_2));
        drop(v412_2);
        let v412_9: Space = if has_head(&(v412_8)) { singleton(&[]) } else { Space::new() };
        drop(v412_8);
        let v412_11: Space = if (&(v412_9)).is_empty() { Space::new() } else {
          let mut v414_10 = Space::new();
          let mut v414_10_write = v414_10.write_zipper();
          for v414_10_byte in v402_19_cursor.child_mask().iter() {
            v402_19_cursor.descend_to_existing_byte(v414_10_byte);
            {
            let v415_2: Space = singleton(&v402_19_cursor.path()[(v402_19_origin + 2)..(v402_19_origin + 3)]);
            let v415_3: Space = intersect(&(*CONSTANT_9),&(v415_2));
            let v415_4: Space = if has_head(&(v415_3)) { singleton(&[]) } else { Space::new() };
            drop(v415_3);
            let v415_5: Space = subtract(&(*CONSTANT_0),&(v415_4));
            drop(v415_4);
            let v415_7: Space = if (&(v415_5)).is_empty() { Space::new() } else {
              let v416_6: Space = routine_57(c, &v402_19_cursor.path()[(v402_19_origin + 2)..(v402_19_origin + 3)], &(*p1), &(*p2), &(*p0), &v402_19_cursor.path()[v402_19_origin..(v402_19_origin + 1)], &v402_19_cursor.path()[(v402_19_origin + 1)..(v402_19_origin + 2)], &v402_19_cursor);
              compose(&(v415_5),&(v416_6))
            };
            drop(v415_5);
            let v415_8: Space = intersect(&(*CONSTANT_9),&(v415_2));
            drop(v415_2);
            let v415_9: Space = if has_head(&(v415_8)) { singleton(&[]) } else { Space::new() };
            drop(v415_8);
            let v415_11: Space = if (&(v415_9)).is_empty() { Space::new() } else {
              let v417_10: Space = routine_58(c, &v402_19_cursor.path()[(v402_19_origin + 2)..(v402_19_origin + 3)], &(*p1), &(*p2), &(*p0), &v402_19_cursor.path()[v402_19_origin..(v402_19_origin + 1)], &v402_19_cursor.path()[(v402_19_origin + 1)..(v402_19_origin + 2)], &v402_19_cursor);
              compose(&(v415_9),&(v417_10))
            };
            drop(v415_9);
            let v415_12: Space = unite(&(v415_7),&(v415_11));
            join_wrapped_into(&mut v414_10_write,&((v415_12).read_zipper()),&[]);
            }
            v402_19_cursor.ascend(1);
          }
          drop(v414_10_write);
          compose(&(v412_9),&(v414_10))
        };
        drop(v412_9);
        let v412_12: Space = unite(&(v412_7),&(v412_11));
        join_wrapped_into(&mut v411_10_write,&((v412_12).read_zipper()),&[]);
        }
        v402_19_cursor.ascend(1);
      }
      drop(v411_10_write);
      compose(&(v403_9),&(v411_10))
    };
    drop(v403_9);
    let v403_12: Space = unite(&(v403_7),&(v403_11));
    join_wrapped_into(&mut v402_19_write,&((v403_12).read_zipper()),&[]);
    }
    v402_19_cursor.ascend(1);
  }
  drop(v402_19_cursor);
  drop(v402_19_write);
  (v402_19).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v418_11 = Space::new();
  let mut v418_11_write = v418_11.write_zipper();
  let mut v418_11_cursor = (*s0).read_zipper();
  let v418_11_origin = v418_11_cursor.path().len();
  for v418_11_byte in v418_11_cursor.child_mask().iter() {
    v418_11_cursor.descend_to_existing_byte(v418_11_byte);
    {
    let v419_2: Space = singleton(&v418_11_cursor.path()[v418_11_origin..(v418_11_origin + 1)]);
    let v419_3: Space = intersect(&(*CONSTANT_9),&(v419_2));
    let v419_4: Space = if has_head(&(v419_3)) { singleton(&[]) } else { Space::new() };
    drop(v419_3);
    let v419_5: Space = subtract(&(*CONSTANT_0),&(v419_4));
    drop(v419_4);
    let v419_8: Space = if (&(v419_5)).is_empty() { Space::new() } else {
      let v420_6: Path = concat_path(&(*p0),&v418_11_cursor.path()[v418_11_origin..(v418_11_origin + 1)]);
      let v420_7: Space = routine_30(c, &(v420_6), &v418_11_cursor);
      compose(&(v419_5),&(v420_7))
    };
    drop(v419_5);
    let v419_9: Space = intersect(&(*CONSTANT_9),&(v419_2));
    drop(v419_2);
    let v419_10: Space = if has_head(&(v419_9)) { singleton(&[]) } else { Space::new() };
    drop(v419_9);
    let v419_12: Space = if (&(v419_10)).is_empty() { Space::new() } else {
      let v421_6: Path = concat_path(&(*p0),&v418_11_cursor.path()[v418_11_origin..(v418_11_origin + 1)]);
      let mut v421_11 = Space::new();
      let mut v421_11_write = v421_11.write_zipper();
      for v421_11_byte in v418_11_cursor.child_mask().iter() {
        v418_11_cursor.descend_to_existing_byte(v421_11_byte);
        {
        let v422_2: Space = singleton(&v418_11_cursor.path()[(v418_11_origin + 1)..(v418_11_origin + 2)]);
        let v422_3: Space = intersect(&(*CONSTANT_9),&(v422_2));
        let v422_4: Space = if has_head(&(v422_3)) { singleton(&[]) } else { Space::new() };
        drop(v422_3);
        let v422_5: Space = subtract(&(*CONSTANT_0),&(v422_4));
        drop(v422_4);
        let v422_7: Space = if (&(v422_5)).is_empty() { Space::new() } else {
          let v423_6: Space = routine_31(c, &v418_11_cursor.path()[(v418_11_origin + 1)..(v418_11_origin + 2)], &(v421_6), &v418_11_cursor);
          compose(&(v422_5),&(v423_6))
        };
        drop(v422_5);
        let v422_8: Space = intersect(&(*CONSTANT_9),&(v422_2));
        drop(v422_2);
        let v422_9: Space = if has_head(&(v422_8)) { singleton(&[]) } else { Space::new() };
        drop(v422_8);
        let v422_11: Space = if (&(v422_9)).is_empty() { Space::new() } else {
          let mut v424_10 = Space::new();
          let mut v424_10_write = v424_10.write_zipper();
          for v424_10_byte in v418_11_cursor.child_mask().iter() {
            v418_11_cursor.descend_to_existing_byte(v424_10_byte);
            {
            let v425_2: Space = singleton(&v418_11_cursor.path()[(v418_11_origin + 2)..(v418_11_origin + 3)]);
            let v425_3: Space = intersect(&(*CONSTANT_9),&(v425_2));
            let v425_4: Space = if has_head(&(v425_3)) { singleton(&[]) } else { Space::new() };
            drop(v425_3);
            let v425_5: Space = subtract(&(*CONSTANT_0),&(v425_4));
            drop(v425_4);
            let v425_7: Space = if (&(v425_5)).is_empty() { Space::new() } else {
              let v426_6: Space = routine_33(c, &v418_11_cursor.path()[(v418_11_origin + 2)..(v418_11_origin + 3)], &(v421_6), &v418_11_cursor.path()[(v418_11_origin + 1)..(v418_11_origin + 2)], &v418_11_cursor);
              compose(&(v425_5),&(v426_6))
            };
            drop(v425_5);
            let v425_8: Space = intersect(&(*CONSTANT_9),&(v425_2));
            drop(v425_2);
            let v425_9: Space = if has_head(&(v425_8)) { singleton(&[]) } else { Space::new() };
            drop(v425_8);
            let v425_11: Space = if (&(v425_9)).is_empty() { Space::new() } else {
              let v427_10: Space = routine_34(c, &v418_11_cursor.path()[(v418_11_origin + 2)..(v418_11_origin + 3)], &(v421_6), &v418_11_cursor.path()[(v418_11_origin + 1)..(v418_11_origin + 2)], &v418_11_cursor);
              compose(&(v425_9),&(v427_10))
            };
            drop(v425_9);
            let v425_12: Space = unite(&(v425_7),&(v425_11));
            join_wrapped_into(&mut v424_10_write,&((v425_12).read_zipper()),&[]);
            }
            v418_11_cursor.ascend(1);
          }
          drop(v424_10_write);
          compose(&(v422_9),&(v424_10))
        };
        drop(v422_9);
        let v422_12: Space = unite(&(v422_7),&(v422_11));
        join_wrapped_into(&mut v421_11_write,&((v422_12).read_zipper()),&[]);
        }
        v418_11_cursor.ascend(1);
      }
      drop(v421_11_write);
      drop(v421_6);
      compose(&(v419_10),&(v421_11))
    };
    drop(v419_10);
    let v419_13: Space = unite(&(v419_8),&(v419_12));
    join_wrapped_into(&mut v418_11_write,&((v419_13).read_zipper()),&[]);
    }
    v418_11_cursor.ascend(1);
  }
  drop(v418_11_cursor);
  drop(v418_11_write);
  (v418_11).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v428_12 = Space::new();
  let mut v428_12_write = v428_12.write_zipper();
  let mut v428_12_cursor = (*s0).read_zipper();
  let v428_12_origin = v428_12_cursor.path().len();
  for v428_12_byte in v428_12_cursor.child_mask().iter() {
    v428_12_cursor.descend_to_existing_byte(v428_12_byte);
    {
    let v429_2: Space = singleton(&v428_12_cursor.path()[v428_12_origin..(v428_12_origin + 1)]);
    let v429_3: Space = intersect(&(*CONSTANT_9),&(v429_2));
    let v429_4: Space = if has_head(&(v429_3)) { singleton(&[]) } else { Space::new() };
    drop(v429_3);
    let v429_5: Space = subtract(&(*CONSTANT_0),&(v429_4));
    drop(v429_4);
    let v429_8: Space = if (&(v429_5)).is_empty() { Space::new() } else {
      let v430_6: Path = concat_path(&(*p0),&v428_12_cursor.path()[v428_12_origin..(v428_12_origin + 1)]);
      let v430_7: Space = routine_31(c, &(v430_6), &(*p1), &v428_12_cursor);
      compose(&(v429_5),&(v430_7))
    };
    drop(v429_5);
    let v429_9: Space = intersect(&(*CONSTANT_9),&(v429_2));
    drop(v429_2);
    let v429_10: Space = if has_head(&(v429_9)) { singleton(&[]) } else { Space::new() };
    drop(v429_9);
    let v429_12: Space = if (&(v429_10)).is_empty() { Space::new() } else {
      let v431_6: Path = concat_path(&(*p0),&v428_12_cursor.path()[v428_12_origin..(v428_12_origin + 1)]);
      let mut v431_11 = Space::new();
      let mut v431_11_write = v431_11.write_zipper();
      for v431_11_byte in v428_12_cursor.child_mask().iter() {
        v428_12_cursor.descend_to_existing_byte(v431_11_byte);
        {
        let v432_2: Space = singleton(&v428_12_cursor.path()[(v428_12_origin + 1)..(v428_12_origin + 2)]);
        let v432_3: Space = intersect(&(*CONSTANT_9),&(v432_2));
        let v432_4: Space = if has_head(&(v432_3)) { singleton(&[]) } else { Space::new() };
        drop(v432_3);
        let v432_5: Space = subtract(&(*CONSTANT_0),&(v432_4));
        drop(v432_4);
        let v432_7: Space = if (&(v432_5)).is_empty() { Space::new() } else {
          let v433_6: Space = routine_33(c, &v428_12_cursor.path()[(v428_12_origin + 1)..(v428_12_origin + 2)], &(*p1), &(v431_6), &v428_12_cursor);
          compose(&(v432_5),&(v433_6))
        };
        drop(v432_5);
        let v432_8: Space = intersect(&(*CONSTANT_9),&(v432_2));
        drop(v432_2);
        let v432_9: Space = if has_head(&(v432_8)) { singleton(&[]) } else { Space::new() };
        drop(v432_8);
        let v432_11: Space = if (&(v432_9)).is_empty() { Space::new() } else {
          let mut v434_10 = Space::new();
          let mut v434_10_write = v434_10.write_zipper();
          for v434_10_byte in v428_12_cursor.child_mask().iter() {
            v428_12_cursor.descend_to_existing_byte(v434_10_byte);
            {
            let v435_2: Space = singleton(&v428_12_cursor.path()[(v428_12_origin + 2)..(v428_12_origin + 3)]);
            let v435_3: Space = intersect(&(*CONSTANT_9),&(v435_2));
            let v435_4: Space = if has_head(&(v435_3)) { singleton(&[]) } else { Space::new() };
            drop(v435_3);
            let v435_5: Space = subtract(&(*CONSTANT_0),&(v435_4));
            drop(v435_4);
            let v435_7: Space = if (&(v435_5)).is_empty() { Space::new() } else {
              let v436_6: Space = routine_59(c, &v428_12_cursor.path()[(v428_12_origin + 2)..(v428_12_origin + 3)], &(*p1), &(v431_6), &v428_12_cursor.path()[(v428_12_origin + 1)..(v428_12_origin + 2)], &v428_12_cursor);
              compose(&(v435_5),&(v436_6))
            };
            drop(v435_5);
            let v435_8: Space = intersect(&(*CONSTANT_9),&(v435_2));
            drop(v435_2);
            let v435_9: Space = if has_head(&(v435_8)) { singleton(&[]) } else { Space::new() };
            drop(v435_8);
            let v435_11: Space = if (&(v435_9)).is_empty() { Space::new() } else {
              let v437_10: Space = routine_60(c, &v428_12_cursor.path()[(v428_12_origin + 2)..(v428_12_origin + 3)], &(*p1), &(v431_6), &v428_12_cursor.path()[(v428_12_origin + 1)..(v428_12_origin + 2)], &v428_12_cursor);
              compose(&(v435_9),&(v437_10))
            };
            drop(v435_9);
            let v435_12: Space = unite(&(v435_7),&(v435_11));
            join_wrapped_into(&mut v434_10_write,&((v435_12).read_zipper()),&[]);
            }
            v428_12_cursor.ascend(1);
          }
          drop(v434_10_write);
          compose(&(v432_9),&(v434_10))
        };
        drop(v432_9);
        let v432_12: Space = unite(&(v432_7),&(v432_11));
        join_wrapped_into(&mut v431_11_write,&((v432_12).read_zipper()),&[]);
        }
        v428_12_cursor.ascend(1);
      }
      drop(v431_11_write);
      drop(v431_6);
      compose(&(v429_10),&(v431_11))
    };
    drop(v429_10);
    let v429_13: Space = unite(&(v429_8),&(v429_12));
    join_wrapped_into(&mut v428_12_write,&((v429_13).read_zipper()),&[]);
    }
    v428_12_cursor.ascend(1);
  }
  drop(v428_12_cursor);
  drop(v428_12_write);
  (v428_12).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v438_18 = Space::new();
  let mut v438_18_write = v438_18.write_zipper();
  let mut v438_18_cursor = (*s0).read_zipper();
  let v438_18_origin = v438_18_cursor.path().len();
  for v438_18_byte in v438_18_cursor.child_mask().iter() {
    v438_18_cursor.descend_to_existing_byte(v438_18_byte);
    {
    let v439_2: Space = singleton(&v438_18_cursor.path()[v438_18_origin..(v438_18_origin + 1)]);
    let v439_3: Space = intersect(&(*CONSTANT_9),&(v439_2));
    let v439_4: Space = if has_head(&(v439_3)) { singleton(&[]) } else { Space::new() };
    drop(v439_3);
    let v439_5: Space = subtract(&(*CONSTANT_0),&(v439_4));
    drop(v439_4);
    let v439_7: Space = if (&(v439_5)).is_empty() { Space::new() } else {
      let mut v440_6 = Space::new();
      let mut v440_6_write = v440_6.write_zipper();
      for v440_6_byte in v438_18_cursor.child_mask().iter() {
        v438_18_cursor.descend_to_existing_byte(v440_6_byte);
        {
        let v441_2: Space = singleton(&v438_18_cursor.path()[(v438_18_origin + 1)..(v438_18_origin + 2)]);
        let v441_3: Space = intersect(&(*CONSTANT_9),&(v441_2));
        let v441_4: Space = if has_head(&(v441_3)) { singleton(&[]) } else { Space::new() };
        drop(v441_3);
        let v441_5: Space = subtract(&(*CONSTANT_0),&(v441_4));
        drop(v441_4);
        let v441_8: Space = if (&(v441_5)).is_empty() { Space::new() } else {
          let v442_7: Space = routine_33(c, &v438_18_cursor.path()[v438_18_origin..(v438_18_origin + 2)], &(*p1), &(*p0), &v438_18_cursor);
          compose(&(v441_5),&(v442_7))
        };
        drop(v441_5);
        let v441_9: Space = intersect(&(*CONSTANT_9),&(v441_2));
        drop(v441_2);
        let v441_10: Space = if has_head(&(v441_9)) { singleton(&[]) } else { Space::new() };
        drop(v441_9);
        let v441_12: Space = if (&(v441_10)).is_empty() { Space::new() } else {
          let mut v443_11 = Space::new();
          let mut v443_11_write = v443_11.write_zipper();
          for v443_11_byte in v438_18_cursor.child_mask().iter() {
            v438_18_cursor.descend_to_existing_byte(v443_11_byte);
            {
            let v444_2: Space = singleton(&v438_18_cursor.path()[(v438_18_origin + 2)..(v438_18_origin + 3)]);
            let v444_3: Space = intersect(&(*CONSTANT_9),&(v444_2));
            let v444_4: Space = if has_head(&(v444_3)) { singleton(&[]) } else { Space::new() };
            drop(v444_3);
            let v444_5: Space = subtract(&(*CONSTANT_0),&(v444_4));
            drop(v444_4);
            let v444_7: Space = if (&(v444_5)).is_empty() { Space::new() } else {
              let v445_6: Space = routine_59(c, &v438_18_cursor.path()[(v438_18_origin + 2)..(v438_18_origin + 3)], &(*p1), &(*p0), &v438_18_cursor.path()[v438_18_origin..(v438_18_origin + 2)], &v438_18_cursor);
              compose(&(v444_5),&(v445_6))
            };
            drop(v444_5);
            let v444_8: Space = intersect(&(*CONSTANT_9),&(v444_2));
            drop(v444_2);
            let v444_9: Space = if has_head(&(v444_8)) { singleton(&[]) } else { Space::new() };
            drop(v444_8);
            let v444_11: Space = if (&(v444_9)).is_empty() { Space::new() } else {
              let v446_10: Space = routine_60(c, &v438_18_cursor.path()[(v438_18_origin + 2)..(v438_18_origin + 3)], &(*p1), &(*p0), &v438_18_cursor.path()[v438_18_origin..(v438_18_origin + 2)], &v438_18_cursor);
              compose(&(v444_9),&(v446_10))
            };
            drop(v444_9);
            let v444_12: Space = unite(&(v444_7),&(v444_11));
            join_wrapped_into(&mut v443_11_write,&((v444_12).read_zipper()),&[]);
            }
            v438_18_cursor.ascend(1);
          }
          drop(v443_11_write);
          compose(&(v441_10),&(v443_11))
        };
        drop(v441_10);
        let v441_13: Space = unite(&(v441_8),&(v441_12));
        join_wrapped_into(&mut v440_6_write,&((v441_13).read_zipper()),&[]);
        }
        v438_18_cursor.ascend(1);
      }
      drop(v440_6_write);
      compose(&(v439_5),&(v440_6))
    };
    drop(v439_5);
    let v439_8: Space = intersect(&(*CONSTANT_9),&(v439_2));
    drop(v439_2);
    let v439_9: Space = if has_head(&(v439_8)) { singleton(&[]) } else { Space::new() };
    drop(v439_8);
    let v439_11: Space = if (&(v439_9)).is_empty() { Space::new() } else {
      let mut v447_10 = Space::new();
      let mut v447_10_write = v447_10.write_zipper();
      for v447_10_byte in v438_18_cursor.child_mask().iter() {
        v438_18_cursor.descend_to_existing_byte(v447_10_byte);
        {
        let v448_2: Space = singleton(&v438_18_cursor.path()[(v438_18_origin + 1)..(v438_18_origin + 2)]);
        let v448_3: Space = intersect(&(*CONSTANT_9),&(v448_2));
        let v448_4: Space = if has_head(&(v448_3)) { singleton(&[]) } else { Space::new() };
        drop(v448_3);
        let v448_5: Space = subtract(&(*CONSTANT_0),&(v448_4));
        drop(v448_4);
        let v448_7: Space = if (&(v448_5)).is_empty() { Space::new() } else {
          let v449_6: Space = routine_59(c, &v438_18_cursor.path()[(v438_18_origin + 1)..(v438_18_origin + 2)], &(*p1), &(*p0), &v438_18_cursor.path()[v438_18_origin..(v438_18_origin + 1)], &v438_18_cursor);
          compose(&(v448_5),&(v449_6))
        };
        drop(v448_5);
        let v448_8: Space = intersect(&(*CONSTANT_9),&(v448_2));
        drop(v448_2);
        let v448_9: Space = if has_head(&(v448_8)) { singleton(&[]) } else { Space::new() };
        drop(v448_8);
        let v448_11: Space = if (&(v448_9)).is_empty() { Space::new() } else {
          let mut v450_10 = Space::new();
          let mut v450_10_write = v450_10.write_zipper();
          for v450_10_byte in v438_18_cursor.child_mask().iter() {
            v438_18_cursor.descend_to_existing_byte(v450_10_byte);
            {
            let v451_2: Space = singleton(&v438_18_cursor.path()[(v438_18_origin + 2)..(v438_18_origin + 3)]);
            let v451_3: Space = intersect(&(*CONSTANT_9),&(v451_2));
            let v451_4: Space = if has_head(&(v451_3)) { singleton(&[]) } else { Space::new() };
            drop(v451_3);
            let v451_5: Space = subtract(&(*CONSTANT_0),&(v451_4));
            drop(v451_4);
            let v451_7: Space = if (&(v451_5)).is_empty() { Space::new() } else {
              let v452_6: Space = routine_61(c, &v438_18_cursor.path()[(v438_18_origin + 2)..(v438_18_origin + 3)], &(*p1), &(*p0), &v438_18_cursor.path()[v438_18_origin..(v438_18_origin + 1)], &v438_18_cursor.path()[(v438_18_origin + 1)..(v438_18_origin + 2)], &v438_18_cursor);
              compose(&(v451_5),&(v452_6))
            };
            drop(v451_5);
            let v451_8: Space = intersect(&(*CONSTANT_9),&(v451_2));
            drop(v451_2);
            let v451_9: Space = if has_head(&(v451_8)) { singleton(&[]) } else { Space::new() };
            drop(v451_8);
            let v451_11: Space = if (&(v451_9)).is_empty() { Space::new() } else {
              let v453_10: Space = routine_62(c, &v438_18_cursor.path()[(v438_18_origin + 2)..(v438_18_origin + 3)], &(*p1), &(*p0), &v438_18_cursor.path()[v438_18_origin..(v438_18_origin + 1)], &v438_18_cursor.path()[(v438_18_origin + 1)..(v438_18_origin + 2)], &v438_18_cursor);
              compose(&(v451_9),&(v453_10))
            };
            drop(v451_9);
            let v451_12: Space = unite(&(v451_7),&(v451_11));
            join_wrapped_into(&mut v450_10_write,&((v451_12).read_zipper()),&[]);
            }
            v438_18_cursor.ascend(1);
          }
          drop(v450_10_write);
          compose(&(v448_9),&(v450_10))
        };
        drop(v448_9);
        let v448_12: Space = unite(&(v448_7),&(v448_11));
        join_wrapped_into(&mut v447_10_write,&((v448_12).read_zipper()),&[]);
        }
        v438_18_cursor.ascend(1);
      }
      drop(v447_10_write);
      compose(&(v439_9),&(v447_10))
    };
    drop(v439_9);
    let v439_12: Space = unite(&(v439_7),&(v439_11));
    join_wrapped_into(&mut v438_18_write,&((v439_12).read_zipper()),&[]);
    }
    v438_18_cursor.ascend(1);
  }
  drop(v438_18_cursor);
  drop(v438_18_write);
  (v438_18).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v454_13 = Space::new();
  let mut v454_13_write = v454_13.write_zipper();
  let mut v454_13_cursor = (*s0).read_zipper();
  let v454_13_origin = v454_13_cursor.path().len();
  for v454_13_byte in v454_13_cursor.child_mask().iter() {
    v454_13_cursor.descend_to_existing_byte(v454_13_byte);
    {
    let v455_2: Space = singleton(&v454_13_cursor.path()[v454_13_origin..(v454_13_origin + 1)]);
    let v455_3: Space = intersect(&(*CONSTANT_9),&(v455_2));
    let v455_4: Space = if has_head(&(v455_3)) { singleton(&[]) } else { Space::new() };
    drop(v455_3);
    let v455_5: Space = subtract(&(*CONSTANT_0),&(v455_4));
    drop(v455_4);
    let v455_8: Space = if (&(v455_5)).is_empty() { Space::new() } else {
      let v456_6: Path = concat_path(&(*p0),&v454_13_cursor.path()[v454_13_origin..(v454_13_origin + 1)]);
      let v456_7: Space = routine_33(c, &(v456_6), &(*p1), &(*p2), &v454_13_cursor);
      compose(&(v455_5),&(v456_7))
    };
    drop(v455_5);
    let v455_9: Space = intersect(&(*CONSTANT_9),&(v455_2));
    drop(v455_2);
    let v455_10: Space = if has_head(&(v455_9)) { singleton(&[]) } else { Space::new() };
    drop(v455_9);
    let v455_12: Space = if (&(v455_10)).is_empty() { Space::new() } else {
      let v457_6: Path = concat_path(&(*p0),&v454_13_cursor.path()[v454_13_origin..(v454_13_origin + 1)]);
      let mut v457_11 = Space::new();
      let mut v457_11_write = v457_11.write_zipper();
      for v457_11_byte in v454_13_cursor.child_mask().iter() {
        v454_13_cursor.descend_to_existing_byte(v457_11_byte);
        {
        let v458_2: Space = singleton(&v454_13_cursor.path()[(v454_13_origin + 1)..(v454_13_origin + 2)]);
        let v458_3: Space = intersect(&(*CONSTANT_9),&(v458_2));
        let v458_4: Space = if has_head(&(v458_3)) { singleton(&[]) } else { Space::new() };
        drop(v458_3);
        let v458_5: Space = subtract(&(*CONSTANT_0),&(v458_4));
        drop(v458_4);
        let v458_7: Space = if (&(v458_5)).is_empty() { Space::new() } else {
          let v459_6: Space = routine_59(c, &v454_13_cursor.path()[(v454_13_origin + 1)..(v454_13_origin + 2)], &(*p1), &(*p2), &(v457_6), &v454_13_cursor);
          compose(&(v458_5),&(v459_6))
        };
        drop(v458_5);
        let v458_8: Space = intersect(&(*CONSTANT_9),&(v458_2));
        drop(v458_2);
        let v458_9: Space = if has_head(&(v458_8)) { singleton(&[]) } else { Space::new() };
        drop(v458_8);
        let v458_11: Space = if (&(v458_9)).is_empty() { Space::new() } else {
          let mut v460_10 = Space::new();
          let mut v460_10_write = v460_10.write_zipper();
          for v460_10_byte in v454_13_cursor.child_mask().iter() {
            v454_13_cursor.descend_to_existing_byte(v460_10_byte);
            {
            let v461_2: Space = singleton(&v454_13_cursor.path()[(v454_13_origin + 2)..(v454_13_origin + 3)]);
            let v461_3: Space = intersect(&(*CONSTANT_9),&(v461_2));
            let v461_4: Space = if has_head(&(v461_3)) { singleton(&[]) } else { Space::new() };
            drop(v461_3);
            let v461_5: Space = subtract(&(*CONSTANT_0),&(v461_4));
            drop(v461_4);
            let v461_7: Space = if (&(v461_5)).is_empty() { Space::new() } else {
              let v462_6: Space = routine_61(c, &v454_13_cursor.path()[(v454_13_origin + 2)..(v454_13_origin + 3)], &(*p1), &(*p2), &(v457_6), &v454_13_cursor.path()[(v454_13_origin + 1)..(v454_13_origin + 2)], &v454_13_cursor);
              compose(&(v461_5),&(v462_6))
            };
            drop(v461_5);
            let v461_8: Space = intersect(&(*CONSTANT_9),&(v461_2));
            drop(v461_2);
            let v461_9: Space = if has_head(&(v461_8)) { singleton(&[]) } else { Space::new() };
            drop(v461_8);
            let v461_11: Space = if (&(v461_9)).is_empty() { Space::new() } else {
              let v463_10: Space = routine_62(c, &v454_13_cursor.path()[(v454_13_origin + 2)..(v454_13_origin + 3)], &(*p1), &(*p2), &(v457_6), &v454_13_cursor.path()[(v454_13_origin + 1)..(v454_13_origin + 2)], &v454_13_cursor);
              compose(&(v461_9),&(v463_10))
            };
            drop(v461_9);
            let v461_12: Space = unite(&(v461_7),&(v461_11));
            join_wrapped_into(&mut v460_10_write,&((v461_12).read_zipper()),&[]);
            }
            v454_13_cursor.ascend(1);
          }
          drop(v460_10_write);
          compose(&(v458_9),&(v460_10))
        };
        drop(v458_9);
        let v458_12: Space = unite(&(v458_7),&(v458_11));
        join_wrapped_into(&mut v457_11_write,&((v458_12).read_zipper()),&[]);
        }
        v454_13_cursor.ascend(1);
      }
      drop(v457_11_write);
      drop(v457_6);
      compose(&(v455_10),&(v457_11))
    };
    drop(v455_10);
    let v455_13: Space = unite(&(v455_8),&(v455_12));
    join_wrapped_into(&mut v454_13_write,&((v455_13).read_zipper()),&[]);
    }
    v454_13_cursor.ascend(1);
  }
  drop(v454_13_cursor);
  drop(v454_13_write);
  (v454_13).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v464_19 = Space::new();
  let mut v464_19_write = v464_19.write_zipper();
  let mut v464_19_cursor = (*s0).read_zipper();
  let v464_19_origin = v464_19_cursor.path().len();
  for v464_19_byte in v464_19_cursor.child_mask().iter() {
    v464_19_cursor.descend_to_existing_byte(v464_19_byte);
    {
    let v465_2: Space = singleton(&v464_19_cursor.path()[v464_19_origin..(v464_19_origin + 1)]);
    let v465_3: Space = intersect(&(*CONSTANT_9),&(v465_2));
    let v465_4: Space = if has_head(&(v465_3)) { singleton(&[]) } else { Space::new() };
    drop(v465_3);
    let v465_5: Space = subtract(&(*CONSTANT_0),&(v465_4));
    drop(v465_4);
    let v465_7: Space = if (&(v465_5)).is_empty() { Space::new() } else {
      let mut v466_6 = Space::new();
      let mut v466_6_write = v466_6.write_zipper();
      for v466_6_byte in v464_19_cursor.child_mask().iter() {
        v464_19_cursor.descend_to_existing_byte(v466_6_byte);
        {
        let v467_2: Space = singleton(&v464_19_cursor.path()[(v464_19_origin + 1)..(v464_19_origin + 2)]);
        let v467_3: Space = intersect(&(*CONSTANT_9),&(v467_2));
        let v467_4: Space = if has_head(&(v467_3)) { singleton(&[]) } else { Space::new() };
        drop(v467_3);
        let v467_5: Space = subtract(&(*CONSTANT_0),&(v467_4));
        drop(v467_4);
        let v467_8: Space = if (&(v467_5)).is_empty() { Space::new() } else {
          let v468_7: Space = routine_59(c, &v464_19_cursor.path()[v464_19_origin..(v464_19_origin + 2)], &(*p1), &(*p2), &(*p0), &v464_19_cursor);
          compose(&(v467_5),&(v468_7))
        };
        drop(v467_5);
        let v467_9: Space = intersect(&(*CONSTANT_9),&(v467_2));
        drop(v467_2);
        let v467_10: Space = if has_head(&(v467_9)) { singleton(&[]) } else { Space::new() };
        drop(v467_9);
        let v467_12: Space = if (&(v467_10)).is_empty() { Space::new() } else {
          let mut v469_11 = Space::new();
          let mut v469_11_write = v469_11.write_zipper();
          for v469_11_byte in v464_19_cursor.child_mask().iter() {
            v464_19_cursor.descend_to_existing_byte(v469_11_byte);
            {
            let v470_2: Space = singleton(&v464_19_cursor.path()[(v464_19_origin + 2)..(v464_19_origin + 3)]);
            let v470_3: Space = intersect(&(*CONSTANT_9),&(v470_2));
            let v470_4: Space = if has_head(&(v470_3)) { singleton(&[]) } else { Space::new() };
            drop(v470_3);
            let v470_5: Space = subtract(&(*CONSTANT_0),&(v470_4));
            drop(v470_4);
            let v470_7: Space = if (&(v470_5)).is_empty() { Space::new() } else {
              let v471_6: Space = routine_61(c, &v464_19_cursor.path()[(v464_19_origin + 2)..(v464_19_origin + 3)], &(*p1), &(*p2), &(*p0), &v464_19_cursor.path()[v464_19_origin..(v464_19_origin + 2)], &v464_19_cursor);
              compose(&(v470_5),&(v471_6))
            };
            drop(v470_5);
            let v470_8: Space = intersect(&(*CONSTANT_9),&(v470_2));
            drop(v470_2);
            let v470_9: Space = if has_head(&(v470_8)) { singleton(&[]) } else { Space::new() };
            drop(v470_8);
            let v470_11: Space = if (&(v470_9)).is_empty() { Space::new() } else {
              let v472_10: Space = routine_62(c, &v464_19_cursor.path()[(v464_19_origin + 2)..(v464_19_origin + 3)], &(*p1), &(*p2), &(*p0), &v464_19_cursor.path()[v464_19_origin..(v464_19_origin + 2)], &v464_19_cursor);
              compose(&(v470_9),&(v472_10))
            };
            drop(v470_9);
            let v470_12: Space = unite(&(v470_7),&(v470_11));
            join_wrapped_into(&mut v469_11_write,&((v470_12).read_zipper()),&[]);
            }
            v464_19_cursor.ascend(1);
          }
          drop(v469_11_write);
          compose(&(v467_10),&(v469_11))
        };
        drop(v467_10);
        let v467_13: Space = unite(&(v467_8),&(v467_12));
        join_wrapped_into(&mut v466_6_write,&((v467_13).read_zipper()),&[]);
        }
        v464_19_cursor.ascend(1);
      }
      drop(v466_6_write);
      compose(&(v465_5),&(v466_6))
    };
    drop(v465_5);
    let v465_8: Space = intersect(&(*CONSTANT_9),&(v465_2));
    drop(v465_2);
    let v465_9: Space = if has_head(&(v465_8)) { singleton(&[]) } else { Space::new() };
    drop(v465_8);
    let v465_11: Space = if (&(v465_9)).is_empty() { Space::new() } else {
      let mut v473_10 = Space::new();
      let mut v473_10_write = v473_10.write_zipper();
      for v473_10_byte in v464_19_cursor.child_mask().iter() {
        v464_19_cursor.descend_to_existing_byte(v473_10_byte);
        {
        let v474_2: Space = singleton(&v464_19_cursor.path()[(v464_19_origin + 1)..(v464_19_origin + 2)]);
        let v474_3: Space = intersect(&(*CONSTANT_9),&(v474_2));
        let v474_4: Space = if has_head(&(v474_3)) { singleton(&[]) } else { Space::new() };
        drop(v474_3);
        let v474_5: Space = subtract(&(*CONSTANT_0),&(v474_4));
        drop(v474_4);
        let v474_7: Space = if (&(v474_5)).is_empty() { Space::new() } else {
          let v475_6: Space = routine_61(c, &v464_19_cursor.path()[(v464_19_origin + 1)..(v464_19_origin + 2)], &(*p1), &(*p2), &(*p0), &v464_19_cursor.path()[v464_19_origin..(v464_19_origin + 1)], &v464_19_cursor);
          compose(&(v474_5),&(v475_6))
        };
        drop(v474_5);
        let v474_8: Space = intersect(&(*CONSTANT_9),&(v474_2));
        drop(v474_2);
        let v474_9: Space = if has_head(&(v474_8)) { singleton(&[]) } else { Space::new() };
        drop(v474_8);
        let v474_11: Space = if (&(v474_9)).is_empty() { Space::new() } else {
          let mut v476_10 = Space::new();
          let mut v476_10_write = v476_10.write_zipper();
          for v476_10_byte in v464_19_cursor.child_mask().iter() {
            v464_19_cursor.descend_to_existing_byte(v476_10_byte);
            {
            let v477_2: Space = singleton(&v464_19_cursor.path()[(v464_19_origin + 2)..(v464_19_origin + 3)]);
            let v477_3: Space = intersect(&(*CONSTANT_9),&(v477_2));
            let v477_4: Space = if has_head(&(v477_3)) { singleton(&[]) } else { Space::new() };
            drop(v477_3);
            let v477_5: Space = subtract(&(*CONSTANT_0),&(v477_4));
            drop(v477_4);
            let v477_7: Space = if (&(v477_5)).is_empty() { Space::new() } else {
              let v478_6: Space = routine_63(c, &v464_19_cursor.path()[(v464_19_origin + 2)..(v464_19_origin + 3)], &(*p1), &(*p2), &(*p0), &v464_19_cursor.path()[v464_19_origin..(v464_19_origin + 1)], &v464_19_cursor.path()[(v464_19_origin + 1)..(v464_19_origin + 2)], &v464_19_cursor);
              compose(&(v477_5),&(v478_6))
            };
            drop(v477_5);
            let v477_8: Space = intersect(&(*CONSTANT_9),&(v477_2));
            drop(v477_2);
            let v477_9: Space = if has_head(&(v477_8)) { singleton(&[]) } else { Space::new() };
            drop(v477_8);
            let v477_11: Space = if (&(v477_9)).is_empty() { Space::new() } else {
              let v479_10: Space = routine_64(c, &v464_19_cursor.path()[(v464_19_origin + 2)..(v464_19_origin + 3)], &(*p1), &(*p2), &(*p0), &v464_19_cursor.path()[v464_19_origin..(v464_19_origin + 1)], &v464_19_cursor.path()[(v464_19_origin + 1)..(v464_19_origin + 2)], &v464_19_cursor);
              compose(&(v477_9),&(v479_10))
            };
            drop(v477_9);
            let v477_12: Space = unite(&(v477_7),&(v477_11));
            join_wrapped_into(&mut v476_10_write,&((v477_12).read_zipper()),&[]);
            }
            v464_19_cursor.ascend(1);
          }
          drop(v476_10_write);
          compose(&(v474_9),&(v476_10))
        };
        drop(v474_9);
        let v474_12: Space = unite(&(v474_7),&(v474_11));
        join_wrapped_into(&mut v473_10_write,&((v474_12).read_zipper()),&[]);
        }
        v464_19_cursor.ascend(1);
      }
      drop(v473_10_write);
      compose(&(v465_9),&(v473_10))
    };
    drop(v465_9);
    let v465_12: Space = unite(&(v465_7),&(v465_11));
    join_wrapped_into(&mut v464_19_write,&((v465_12).read_zipper()),&[]);
    }
    v464_19_cursor.ascend(1);
  }
  drop(v464_19_cursor);
  drop(v464_19_write);
  (v464_19).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v480_11 = Space::new();
  let mut v480_11_write = v480_11.write_zipper();
  let mut v480_11_cursor = (*s0).read_zipper();
  let v480_11_origin = v480_11_cursor.path().len();
  for v480_11_byte in v480_11_cursor.child_mask().iter() {
    v480_11_cursor.descend_to_existing_byte(v480_11_byte);
    {
    let v481_2: Space = singleton(&v480_11_cursor.path()[v480_11_origin..(v480_11_origin + 1)]);
    let v481_3: Space = intersect(&(*CONSTANT_9),&(v481_2));
    let v481_4: Space = if has_head(&(v481_3)) { singleton(&[]) } else { Space::new() };
    drop(v481_3);
    let v481_5: Space = subtract(&(*CONSTANT_0),&(v481_4));
    drop(v481_4);
    let v481_8: Space = if (&(v481_5)).is_empty() { Space::new() } else {
      let v482_6: Path = concat_path(&(*p0),&v480_11_cursor.path()[v480_11_origin..(v480_11_origin + 1)]);
      let v482_7: Space = routine_35(c, &(v482_6), &v480_11_cursor);
      compose(&(v481_5),&(v482_7))
    };
    drop(v481_5);
    let v481_9: Space = intersect(&(*CONSTANT_9),&(v481_2));
    drop(v481_2);
    let v481_10: Space = if has_head(&(v481_9)) { singleton(&[]) } else { Space::new() };
    drop(v481_9);
    let v481_12: Space = if (&(v481_10)).is_empty() { Space::new() } else {
      let v483_6: Path = concat_path(&(*p0),&v480_11_cursor.path()[v480_11_origin..(v480_11_origin + 1)]);
      let mut v483_11 = Space::new();
      let mut v483_11_write = v483_11.write_zipper();
      for v483_11_byte in v480_11_cursor.child_mask().iter() {
        v480_11_cursor.descend_to_existing_byte(v483_11_byte);
        {
        let v484_2: Space = singleton(&v480_11_cursor.path()[(v480_11_origin + 1)..(v480_11_origin + 2)]);
        let v484_3: Space = intersect(&(*CONSTANT_9),&(v484_2));
        let v484_4: Space = if has_head(&(v484_3)) { singleton(&[]) } else { Space::new() };
        drop(v484_3);
        let v484_5: Space = subtract(&(*CONSTANT_0),&(v484_4));
        drop(v484_4);
        let v484_7: Space = if (&(v484_5)).is_empty() { Space::new() } else {
          let v485_6: Space = routine_36(c, &v480_11_cursor.path()[(v480_11_origin + 1)..(v480_11_origin + 2)], &(v483_6), &v480_11_cursor);
          compose(&(v484_5),&(v485_6))
        };
        drop(v484_5);
        let v484_8: Space = intersect(&(*CONSTANT_9),&(v484_2));
        drop(v484_2);
        let v484_9: Space = if has_head(&(v484_8)) { singleton(&[]) } else { Space::new() };
        drop(v484_8);
        let v484_11: Space = if (&(v484_9)).is_empty() { Space::new() } else {
          let mut v486_10 = Space::new();
          let mut v486_10_write = v486_10.write_zipper();
          for v486_10_byte in v480_11_cursor.child_mask().iter() {
            v480_11_cursor.descend_to_existing_byte(v486_10_byte);
            {
            let v487_2: Space = singleton(&v480_11_cursor.path()[(v480_11_origin + 2)..(v480_11_origin + 3)]);
            let v487_3: Space = intersect(&(*CONSTANT_9),&(v487_2));
            let v487_4: Space = if has_head(&(v487_3)) { singleton(&[]) } else { Space::new() };
            drop(v487_3);
            let v487_5: Space = subtract(&(*CONSTANT_0),&(v487_4));
            drop(v487_4);
            let v487_7: Space = if (&(v487_5)).is_empty() { Space::new() } else {
              let v488_6: Space = routine_38(c, &v480_11_cursor.path()[(v480_11_origin + 2)..(v480_11_origin + 3)], &(v483_6), &v480_11_cursor.path()[(v480_11_origin + 1)..(v480_11_origin + 2)], &v480_11_cursor);
              compose(&(v487_5),&(v488_6))
            };
            drop(v487_5);
            let v487_8: Space = intersect(&(*CONSTANT_9),&(v487_2));
            drop(v487_2);
            let v487_9: Space = if has_head(&(v487_8)) { singleton(&[]) } else { Space::new() };
            drop(v487_8);
            let v487_11: Space = if (&(v487_9)).is_empty() { Space::new() } else {
              let v489_10: Space = routine_39(c, &v480_11_cursor.path()[(v480_11_origin + 2)..(v480_11_origin + 3)], &(v483_6), &v480_11_cursor.path()[(v480_11_origin + 1)..(v480_11_origin + 2)], &v480_11_cursor);
              compose(&(v487_9),&(v489_10))
            };
            drop(v487_9);
            let v487_12: Space = unite(&(v487_7),&(v487_11));
            join_wrapped_into(&mut v486_10_write,&((v487_12).read_zipper()),&[]);
            }
            v480_11_cursor.ascend(1);
          }
          drop(v486_10_write);
          compose(&(v484_9),&(v486_10))
        };
        drop(v484_9);
        let v484_12: Space = unite(&(v484_7),&(v484_11));
        join_wrapped_into(&mut v483_11_write,&((v484_12).read_zipper()),&[]);
        }
        v480_11_cursor.ascend(1);
      }
      drop(v483_11_write);
      drop(v483_6);
      compose(&(v481_10),&(v483_11))
    };
    drop(v481_10);
    let v481_13: Space = unite(&(v481_8),&(v481_12));
    join_wrapped_into(&mut v480_11_write,&((v481_13).read_zipper()),&[]);
    }
    v480_11_cursor.ascend(1);
  }
  drop(v480_11_cursor);
  drop(v480_11_write);
  (v480_11).clone()
}

fn routine_36(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v490_12 = Space::new();
  let mut v490_12_write = v490_12.write_zipper();
  let mut v490_12_cursor = (*s0).read_zipper();
  let v490_12_origin = v490_12_cursor.path().len();
  for v490_12_byte in v490_12_cursor.child_mask().iter() {
    v490_12_cursor.descend_to_existing_byte(v490_12_byte);
    {
    let v491_2: Space = singleton(&v490_12_cursor.path()[v490_12_origin..(v490_12_origin + 1)]);
    let v491_3: Space = intersect(&(*CONSTANT_9),&(v491_2));
    let v491_4: Space = if has_head(&(v491_3)) { singleton(&[]) } else { Space::new() };
    drop(v491_3);
    let v491_5: Space = subtract(&(*CONSTANT_0),&(v491_4));
    drop(v491_4);
    let v491_8: Space = if (&(v491_5)).is_empty() { Space::new() } else {
      let v492_6: Path = concat_path(&(*p0),&v490_12_cursor.path()[v490_12_origin..(v490_12_origin + 1)]);
      let v492_7: Space = routine_36(c, &(v492_6), &(*p1), &v490_12_cursor);
      compose(&(v491_5),&(v492_7))
    };
    drop(v491_5);
    let v491_9: Space = intersect(&(*CONSTANT_9),&(v491_2));
    drop(v491_2);
    let v491_10: Space = if has_head(&(v491_9)) { singleton(&[]) } else { Space::new() };
    drop(v491_9);
    let v491_12: Space = if (&(v491_10)).is_empty() { Space::new() } else {
      let v493_6: Path = concat_path(&(*p0),&v490_12_cursor.path()[v490_12_origin..(v490_12_origin + 1)]);
      let mut v493_11 = Space::new();
      let mut v493_11_write = v493_11.write_zipper();
      for v493_11_byte in v490_12_cursor.child_mask().iter() {
        v490_12_cursor.descend_to_existing_byte(v493_11_byte);
        {
        let v494_2: Space = singleton(&v490_12_cursor.path()[(v490_12_origin + 1)..(v490_12_origin + 2)]);
        let v494_3: Space = intersect(&(*CONSTANT_9),&(v494_2));
        let v494_4: Space = if has_head(&(v494_3)) { singleton(&[]) } else { Space::new() };
        drop(v494_3);
        let v494_5: Space = subtract(&(*CONSTANT_0),&(v494_4));
        drop(v494_4);
        let v494_7: Space = if (&(v494_5)).is_empty() { Space::new() } else {
          let v495_6: Space = routine_38(c, &v490_12_cursor.path()[(v490_12_origin + 1)..(v490_12_origin + 2)], &(*p1), &(v493_6), &v490_12_cursor);
          compose(&(v494_5),&(v495_6))
        };
        drop(v494_5);
        let v494_8: Space = intersect(&(*CONSTANT_9),&(v494_2));
        drop(v494_2);
        let v494_9: Space = if has_head(&(v494_8)) { singleton(&[]) } else { Space::new() };
        drop(v494_8);
        let v494_11: Space = if (&(v494_9)).is_empty() { Space::new() } else {
          let mut v496_10 = Space::new();
          let mut v496_10_write = v496_10.write_zipper();
          for v496_10_byte in v490_12_cursor.child_mask().iter() {
            v490_12_cursor.descend_to_existing_byte(v496_10_byte);
            {
            let v497_2: Space = singleton(&v490_12_cursor.path()[(v490_12_origin + 2)..(v490_12_origin + 3)]);
            let v497_3: Space = intersect(&(*CONSTANT_9),&(v497_2));
            let v497_4: Space = if has_head(&(v497_3)) { singleton(&[]) } else { Space::new() };
            drop(v497_3);
            let v497_5: Space = subtract(&(*CONSTANT_0),&(v497_4));
            drop(v497_4);
            let v497_7: Space = if (&(v497_5)).is_empty() { Space::new() } else {
              let v498_6: Space = routine_65(c, &v490_12_cursor.path()[(v490_12_origin + 2)..(v490_12_origin + 3)], &(*p1), &(v493_6), &v490_12_cursor.path()[(v490_12_origin + 1)..(v490_12_origin + 2)], &v490_12_cursor);
              compose(&(v497_5),&(v498_6))
            };
            drop(v497_5);
            let v497_8: Space = intersect(&(*CONSTANT_9),&(v497_2));
            drop(v497_2);
            let v497_9: Space = if has_head(&(v497_8)) { singleton(&[]) } else { Space::new() };
            drop(v497_8);
            let v497_11: Space = if (&(v497_9)).is_empty() { Space::new() } else {
              let v499_10: Space = routine_66(c, &v490_12_cursor.path()[(v490_12_origin + 2)..(v490_12_origin + 3)], &(*p1), &(v493_6), &v490_12_cursor.path()[(v490_12_origin + 1)..(v490_12_origin + 2)], &v490_12_cursor);
              compose(&(v497_9),&(v499_10))
            };
            drop(v497_9);
            let v497_12: Space = unite(&(v497_7),&(v497_11));
            join_wrapped_into(&mut v496_10_write,&((v497_12).read_zipper()),&[]);
            }
            v490_12_cursor.ascend(1);
          }
          drop(v496_10_write);
          compose(&(v494_9),&(v496_10))
        };
        drop(v494_9);
        let v494_12: Space = unite(&(v494_7),&(v494_11));
        join_wrapped_into(&mut v493_11_write,&((v494_12).read_zipper()),&[]);
        }
        v490_12_cursor.ascend(1);
      }
      drop(v493_11_write);
      drop(v493_6);
      compose(&(v491_10),&(v493_11))
    };
    drop(v491_10);
    let v491_13: Space = unite(&(v491_8),&(v491_12));
    join_wrapped_into(&mut v490_12_write,&((v491_13).read_zipper()),&[]);
    }
    v490_12_cursor.ascend(1);
  }
  drop(v490_12_cursor);
  drop(v490_12_write);
  (v490_12).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v500_18 = Space::new();
  let mut v500_18_write = v500_18.write_zipper();
  let mut v500_18_cursor = (*s0).read_zipper();
  let v500_18_origin = v500_18_cursor.path().len();
  for v500_18_byte in v500_18_cursor.child_mask().iter() {
    v500_18_cursor.descend_to_existing_byte(v500_18_byte);
    {
    let v501_2: Space = singleton(&v500_18_cursor.path()[v500_18_origin..(v500_18_origin + 1)]);
    let v501_3: Space = intersect(&(*CONSTANT_9),&(v501_2));
    let v501_4: Space = if has_head(&(v501_3)) { singleton(&[]) } else { Space::new() };
    drop(v501_3);
    let v501_5: Space = subtract(&(*CONSTANT_0),&(v501_4));
    drop(v501_4);
    let v501_7: Space = if (&(v501_5)).is_empty() { Space::new() } else {
      let mut v502_6 = Space::new();
      let mut v502_6_write = v502_6.write_zipper();
      for v502_6_byte in v500_18_cursor.child_mask().iter() {
        v500_18_cursor.descend_to_existing_byte(v502_6_byte);
        {
        let v503_2: Space = singleton(&v500_18_cursor.path()[(v500_18_origin + 1)..(v500_18_origin + 2)]);
        let v503_3: Space = intersect(&(*CONSTANT_9),&(v503_2));
        let v503_4: Space = if has_head(&(v503_3)) { singleton(&[]) } else { Space::new() };
        drop(v503_3);
        let v503_5: Space = subtract(&(*CONSTANT_0),&(v503_4));
        drop(v503_4);
        let v503_8: Space = if (&(v503_5)).is_empty() { Space::new() } else {
          let v504_7: Space = routine_38(c, &v500_18_cursor.path()[v500_18_origin..(v500_18_origin + 2)], &(*p1), &(*p0), &v500_18_cursor);
          compose(&(v503_5),&(v504_7))
        };
        drop(v503_5);
        let v503_9: Space = intersect(&(*CONSTANT_9),&(v503_2));
        drop(v503_2);
        let v503_10: Space = if has_head(&(v503_9)) { singleton(&[]) } else { Space::new() };
        drop(v503_9);
        let v503_12: Space = if (&(v503_10)).is_empty() { Space::new() } else {
          let mut v505_11 = Space::new();
          let mut v505_11_write = v505_11.write_zipper();
          for v505_11_byte in v500_18_cursor.child_mask().iter() {
            v500_18_cursor.descend_to_existing_byte(v505_11_byte);
            {
            let v506_2: Space = singleton(&v500_18_cursor.path()[(v500_18_origin + 2)..(v500_18_origin + 3)]);
            let v506_3: Space = intersect(&(*CONSTANT_9),&(v506_2));
            let v506_4: Space = if has_head(&(v506_3)) { singleton(&[]) } else { Space::new() };
            drop(v506_3);
            let v506_5: Space = subtract(&(*CONSTANT_0),&(v506_4));
            drop(v506_4);
            let v506_7: Space = if (&(v506_5)).is_empty() { Space::new() } else {
              let v507_6: Space = routine_65(c, &v500_18_cursor.path()[(v500_18_origin + 2)..(v500_18_origin + 3)], &(*p1), &(*p0), &v500_18_cursor.path()[v500_18_origin..(v500_18_origin + 2)], &v500_18_cursor);
              compose(&(v506_5),&(v507_6))
            };
            drop(v506_5);
            let v506_8: Space = intersect(&(*CONSTANT_9),&(v506_2));
            drop(v506_2);
            let v506_9: Space = if has_head(&(v506_8)) { singleton(&[]) } else { Space::new() };
            drop(v506_8);
            let v506_11: Space = if (&(v506_9)).is_empty() { Space::new() } else {
              let v508_10: Space = routine_66(c, &v500_18_cursor.path()[(v500_18_origin + 2)..(v500_18_origin + 3)], &(*p1), &(*p0), &v500_18_cursor.path()[v500_18_origin..(v500_18_origin + 2)], &v500_18_cursor);
              compose(&(v506_9),&(v508_10))
            };
            drop(v506_9);
            let v506_12: Space = unite(&(v506_7),&(v506_11));
            join_wrapped_into(&mut v505_11_write,&((v506_12).read_zipper()),&[]);
            }
            v500_18_cursor.ascend(1);
          }
          drop(v505_11_write);
          compose(&(v503_10),&(v505_11))
        };
        drop(v503_10);
        let v503_13: Space = unite(&(v503_8),&(v503_12));
        join_wrapped_into(&mut v502_6_write,&((v503_13).read_zipper()),&[]);
        }
        v500_18_cursor.ascend(1);
      }
      drop(v502_6_write);
      compose(&(v501_5),&(v502_6))
    };
    drop(v501_5);
    let v501_8: Space = intersect(&(*CONSTANT_9),&(v501_2));
    drop(v501_2);
    let v501_9: Space = if has_head(&(v501_8)) { singleton(&[]) } else { Space::new() };
    drop(v501_8);
    let v501_11: Space = if (&(v501_9)).is_empty() { Space::new() } else {
      let mut v509_10 = Space::new();
      let mut v509_10_write = v509_10.write_zipper();
      for v509_10_byte in v500_18_cursor.child_mask().iter() {
        v500_18_cursor.descend_to_existing_byte(v509_10_byte);
        {
        let v510_2: Space = singleton(&v500_18_cursor.path()[(v500_18_origin + 1)..(v500_18_origin + 2)]);
        let v510_3: Space = intersect(&(*CONSTANT_9),&(v510_2));
        let v510_4: Space = if has_head(&(v510_3)) { singleton(&[]) } else { Space::new() };
        drop(v510_3);
        let v510_5: Space = subtract(&(*CONSTANT_0),&(v510_4));
        drop(v510_4);
        let v510_7: Space = if (&(v510_5)).is_empty() { Space::new() } else {
          let v511_6: Space = routine_65(c, &v500_18_cursor.path()[(v500_18_origin + 1)..(v500_18_origin + 2)], &(*p1), &(*p0), &v500_18_cursor.path()[v500_18_origin..(v500_18_origin + 1)], &v500_18_cursor);
          compose(&(v510_5),&(v511_6))
        };
        drop(v510_5);
        let v510_8: Space = intersect(&(*CONSTANT_9),&(v510_2));
        drop(v510_2);
        let v510_9: Space = if has_head(&(v510_8)) { singleton(&[]) } else { Space::new() };
        drop(v510_8);
        let v510_11: Space = if (&(v510_9)).is_empty() { Space::new() } else {
          let mut v512_10 = Space::new();
          let mut v512_10_write = v512_10.write_zipper();
          for v512_10_byte in v500_18_cursor.child_mask().iter() {
            v500_18_cursor.descend_to_existing_byte(v512_10_byte);
            {
            let v513_2: Space = singleton(&v500_18_cursor.path()[(v500_18_origin + 2)..(v500_18_origin + 3)]);
            let v513_3: Space = intersect(&(*CONSTANT_9),&(v513_2));
            let v513_4: Space = if has_head(&(v513_3)) { singleton(&[]) } else { Space::new() };
            drop(v513_3);
            let v513_5: Space = subtract(&(*CONSTANT_0),&(v513_4));
            drop(v513_4);
            let v513_7: Space = if (&(v513_5)).is_empty() { Space::new() } else {
              let v514_6: Space = routine_67(c, &v500_18_cursor.path()[(v500_18_origin + 2)..(v500_18_origin + 3)], &(*p1), &(*p0), &v500_18_cursor.path()[v500_18_origin..(v500_18_origin + 1)], &v500_18_cursor.path()[(v500_18_origin + 1)..(v500_18_origin + 2)], &v500_18_cursor);
              compose(&(v513_5),&(v514_6))
            };
            drop(v513_5);
            let v513_8: Space = intersect(&(*CONSTANT_9),&(v513_2));
            drop(v513_2);
            let v513_9: Space = if has_head(&(v513_8)) { singleton(&[]) } else { Space::new() };
            drop(v513_8);
            let v513_11: Space = if (&(v513_9)).is_empty() { Space::new() } else {
              let v515_10: Space = routine_68(c, &v500_18_cursor.path()[(v500_18_origin + 2)..(v500_18_origin + 3)], &(*p1), &(*p0), &v500_18_cursor.path()[v500_18_origin..(v500_18_origin + 1)], &v500_18_cursor.path()[(v500_18_origin + 1)..(v500_18_origin + 2)], &v500_18_cursor);
              compose(&(v513_9),&(v515_10))
            };
            drop(v513_9);
            let v513_12: Space = unite(&(v513_7),&(v513_11));
            join_wrapped_into(&mut v512_10_write,&((v513_12).read_zipper()),&[]);
            }
            v500_18_cursor.ascend(1);
          }
          drop(v512_10_write);
          compose(&(v510_9),&(v512_10))
        };
        drop(v510_9);
        let v510_12: Space = unite(&(v510_7),&(v510_11));
        join_wrapped_into(&mut v509_10_write,&((v510_12).read_zipper()),&[]);
        }
        v500_18_cursor.ascend(1);
      }
      drop(v509_10_write);
      compose(&(v501_9),&(v509_10))
    };
    drop(v501_9);
    let v501_12: Space = unite(&(v501_7),&(v501_11));
    join_wrapped_into(&mut v500_18_write,&((v501_12).read_zipper()),&[]);
    }
    v500_18_cursor.ascend(1);
  }
  drop(v500_18_cursor);
  drop(v500_18_write);
  (v500_18).clone()
}

fn routine_38(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v516_13 = Space::new();
  let mut v516_13_write = v516_13.write_zipper();
  let mut v516_13_cursor = (*s0).read_zipper();
  let v516_13_origin = v516_13_cursor.path().len();
  for v516_13_byte in v516_13_cursor.child_mask().iter() {
    v516_13_cursor.descend_to_existing_byte(v516_13_byte);
    {
    let v517_2: Space = singleton(&v516_13_cursor.path()[v516_13_origin..(v516_13_origin + 1)]);
    let v517_3: Space = intersect(&(*CONSTANT_9),&(v517_2));
    let v517_4: Space = if has_head(&(v517_3)) { singleton(&[]) } else { Space::new() };
    drop(v517_3);
    let v517_5: Space = subtract(&(*CONSTANT_0),&(v517_4));
    drop(v517_4);
    let v517_8: Space = if (&(v517_5)).is_empty() { Space::new() } else {
      let v518_6: Path = concat_path(&(*p0),&v516_13_cursor.path()[v516_13_origin..(v516_13_origin + 1)]);
      let v518_7: Space = routine_38(c, &(v518_6), &(*p1), &(*p2), &v516_13_cursor);
      compose(&(v517_5),&(v518_7))
    };
    drop(v517_5);
    let v517_9: Space = intersect(&(*CONSTANT_9),&(v517_2));
    drop(v517_2);
    let v517_10: Space = if has_head(&(v517_9)) { singleton(&[]) } else { Space::new() };
    drop(v517_9);
    let v517_12: Space = if (&(v517_10)).is_empty() { Space::new() } else {
      let v519_6: Path = concat_path(&(*p0),&v516_13_cursor.path()[v516_13_origin..(v516_13_origin + 1)]);
      let mut v519_11 = Space::new();
      let mut v519_11_write = v519_11.write_zipper();
      for v519_11_byte in v516_13_cursor.child_mask().iter() {
        v516_13_cursor.descend_to_existing_byte(v519_11_byte);
        {
        let v520_2: Space = singleton(&v516_13_cursor.path()[(v516_13_origin + 1)..(v516_13_origin + 2)]);
        let v520_3: Space = intersect(&(*CONSTANT_9),&(v520_2));
        let v520_4: Space = if has_head(&(v520_3)) { singleton(&[]) } else { Space::new() };
        drop(v520_3);
        let v520_5: Space = subtract(&(*CONSTANT_0),&(v520_4));
        drop(v520_4);
        let v520_7: Space = if (&(v520_5)).is_empty() { Space::new() } else {
          let v521_6: Space = routine_65(c, &v516_13_cursor.path()[(v516_13_origin + 1)..(v516_13_origin + 2)], &(*p1), &(*p2), &(v519_6), &v516_13_cursor);
          compose(&(v520_5),&(v521_6))
        };
        drop(v520_5);
        let v520_8: Space = intersect(&(*CONSTANT_9),&(v520_2));
        drop(v520_2);
        let v520_9: Space = if has_head(&(v520_8)) { singleton(&[]) } else { Space::new() };
        drop(v520_8);
        let v520_11: Space = if (&(v520_9)).is_empty() { Space::new() } else {
          let mut v522_10 = Space::new();
          let mut v522_10_write = v522_10.write_zipper();
          for v522_10_byte in v516_13_cursor.child_mask().iter() {
            v516_13_cursor.descend_to_existing_byte(v522_10_byte);
            {
            let v523_2: Space = singleton(&v516_13_cursor.path()[(v516_13_origin + 2)..(v516_13_origin + 3)]);
            let v523_3: Space = intersect(&(*CONSTANT_9),&(v523_2));
            let v523_4: Space = if has_head(&(v523_3)) { singleton(&[]) } else { Space::new() };
            drop(v523_3);
            let v523_5: Space = subtract(&(*CONSTANT_0),&(v523_4));
            drop(v523_4);
            let v523_7: Space = if (&(v523_5)).is_empty() { Space::new() } else {
              let v524_6: Space = routine_67(c, &v516_13_cursor.path()[(v516_13_origin + 2)..(v516_13_origin + 3)], &(*p1), &(*p2), &(v519_6), &v516_13_cursor.path()[(v516_13_origin + 1)..(v516_13_origin + 2)], &v516_13_cursor);
              compose(&(v523_5),&(v524_6))
            };
            drop(v523_5);
            let v523_8: Space = intersect(&(*CONSTANT_9),&(v523_2));
            drop(v523_2);
            let v523_9: Space = if has_head(&(v523_8)) { singleton(&[]) } else { Space::new() };
            drop(v523_8);
            let v523_11: Space = if (&(v523_9)).is_empty() { Space::new() } else {
              let v525_10: Space = routine_68(c, &v516_13_cursor.path()[(v516_13_origin + 2)..(v516_13_origin + 3)], &(*p1), &(*p2), &(v519_6), &v516_13_cursor.path()[(v516_13_origin + 1)..(v516_13_origin + 2)], &v516_13_cursor);
              compose(&(v523_9),&(v525_10))
            };
            drop(v523_9);
            let v523_12: Space = unite(&(v523_7),&(v523_11));
            join_wrapped_into(&mut v522_10_write,&((v523_12).read_zipper()),&[]);
            }
            v516_13_cursor.ascend(1);
          }
          drop(v522_10_write);
          compose(&(v520_9),&(v522_10))
        };
        drop(v520_9);
        let v520_12: Space = unite(&(v520_7),&(v520_11));
        join_wrapped_into(&mut v519_11_write,&((v520_12).read_zipper()),&[]);
        }
        v516_13_cursor.ascend(1);
      }
      drop(v519_11_write);
      drop(v519_6);
      compose(&(v517_10),&(v519_11))
    };
    drop(v517_10);
    let v517_13: Space = unite(&(v517_8),&(v517_12));
    join_wrapped_into(&mut v516_13_write,&((v517_13).read_zipper()),&[]);
    }
    v516_13_cursor.ascend(1);
  }
  drop(v516_13_cursor);
  drop(v516_13_write);
  (v516_13).clone()
}

fn routine_39(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v526_19 = Space::new();
  let mut v526_19_write = v526_19.write_zipper();
  let mut v526_19_cursor = (*s0).read_zipper();
  let v526_19_origin = v526_19_cursor.path().len();
  for v526_19_byte in v526_19_cursor.child_mask().iter() {
    v526_19_cursor.descend_to_existing_byte(v526_19_byte);
    {
    let v527_2: Space = singleton(&v526_19_cursor.path()[v526_19_origin..(v526_19_origin + 1)]);
    let v527_3: Space = intersect(&(*CONSTANT_9),&(v527_2));
    let v527_4: Space = if has_head(&(v527_3)) { singleton(&[]) } else { Space::new() };
    drop(v527_3);
    let v527_5: Space = subtract(&(*CONSTANT_0),&(v527_4));
    drop(v527_4);
    let v527_7: Space = if (&(v527_5)).is_empty() { Space::new() } else {
      let mut v528_6 = Space::new();
      let mut v528_6_write = v528_6.write_zipper();
      for v528_6_byte in v526_19_cursor.child_mask().iter() {
        v526_19_cursor.descend_to_existing_byte(v528_6_byte);
        {
        let v529_2: Space = singleton(&v526_19_cursor.path()[(v526_19_origin + 1)..(v526_19_origin + 2)]);
        let v529_3: Space = intersect(&(*CONSTANT_9),&(v529_2));
        let v529_4: Space = if has_head(&(v529_3)) { singleton(&[]) } else { Space::new() };
        drop(v529_3);
        let v529_5: Space = subtract(&(*CONSTANT_0),&(v529_4));
        drop(v529_4);
        let v529_8: Space = if (&(v529_5)).is_empty() { Space::new() } else {
          let v530_7: Space = routine_65(c, &v526_19_cursor.path()[v526_19_origin..(v526_19_origin + 2)], &(*p1), &(*p2), &(*p0), &v526_19_cursor);
          compose(&(v529_5),&(v530_7))
        };
        drop(v529_5);
        let v529_9: Space = intersect(&(*CONSTANT_9),&(v529_2));
        drop(v529_2);
        let v529_10: Space = if has_head(&(v529_9)) { singleton(&[]) } else { Space::new() };
        drop(v529_9);
        let v529_12: Space = if (&(v529_10)).is_empty() { Space::new() } else {
          let mut v531_11 = Space::new();
          let mut v531_11_write = v531_11.write_zipper();
          for v531_11_byte in v526_19_cursor.child_mask().iter() {
            v526_19_cursor.descend_to_existing_byte(v531_11_byte);
            {
            let v532_2: Space = singleton(&v526_19_cursor.path()[(v526_19_origin + 2)..(v526_19_origin + 3)]);
            let v532_3: Space = intersect(&(*CONSTANT_9),&(v532_2));
            let v532_4: Space = if has_head(&(v532_3)) { singleton(&[]) } else { Space::new() };
            drop(v532_3);
            let v532_5: Space = subtract(&(*CONSTANT_0),&(v532_4));
            drop(v532_4);
            let v532_7: Space = if (&(v532_5)).is_empty() { Space::new() } else {
              let v533_6: Space = routine_67(c, &v526_19_cursor.path()[(v526_19_origin + 2)..(v526_19_origin + 3)], &(*p1), &(*p2), &(*p0), &v526_19_cursor.path()[v526_19_origin..(v526_19_origin + 2)], &v526_19_cursor);
              compose(&(v532_5),&(v533_6))
            };
            drop(v532_5);
            let v532_8: Space = intersect(&(*CONSTANT_9),&(v532_2));
            drop(v532_2);
            let v532_9: Space = if has_head(&(v532_8)) { singleton(&[]) } else { Space::new() };
            drop(v532_8);
            let v532_11: Space = if (&(v532_9)).is_empty() { Space::new() } else {
              let v534_10: Space = routine_68(c, &v526_19_cursor.path()[(v526_19_origin + 2)..(v526_19_origin + 3)], &(*p1), &(*p2), &(*p0), &v526_19_cursor.path()[v526_19_origin..(v526_19_origin + 2)], &v526_19_cursor);
              compose(&(v532_9),&(v534_10))
            };
            drop(v532_9);
            let v532_12: Space = unite(&(v532_7),&(v532_11));
            join_wrapped_into(&mut v531_11_write,&((v532_12).read_zipper()),&[]);
            }
            v526_19_cursor.ascend(1);
          }
          drop(v531_11_write);
          compose(&(v529_10),&(v531_11))
        };
        drop(v529_10);
        let v529_13: Space = unite(&(v529_8),&(v529_12));
        join_wrapped_into(&mut v528_6_write,&((v529_13).read_zipper()),&[]);
        }
        v526_19_cursor.ascend(1);
      }
      drop(v528_6_write);
      compose(&(v527_5),&(v528_6))
    };
    drop(v527_5);
    let v527_8: Space = intersect(&(*CONSTANT_9),&(v527_2));
    drop(v527_2);
    let v527_9: Space = if has_head(&(v527_8)) { singleton(&[]) } else { Space::new() };
    drop(v527_8);
    let v527_11: Space = if (&(v527_9)).is_empty() { Space::new() } else {
      let mut v535_10 = Space::new();
      let mut v535_10_write = v535_10.write_zipper();
      for v535_10_byte in v526_19_cursor.child_mask().iter() {
        v526_19_cursor.descend_to_existing_byte(v535_10_byte);
        {
        let v536_2: Space = singleton(&v526_19_cursor.path()[(v526_19_origin + 1)..(v526_19_origin + 2)]);
        let v536_3: Space = intersect(&(*CONSTANT_9),&(v536_2));
        let v536_4: Space = if has_head(&(v536_3)) { singleton(&[]) } else { Space::new() };
        drop(v536_3);
        let v536_5: Space = subtract(&(*CONSTANT_0),&(v536_4));
        drop(v536_4);
        let v536_7: Space = if (&(v536_5)).is_empty() { Space::new() } else {
          let v537_6: Space = routine_67(c, &v526_19_cursor.path()[(v526_19_origin + 1)..(v526_19_origin + 2)], &(*p1), &(*p2), &(*p0), &v526_19_cursor.path()[v526_19_origin..(v526_19_origin + 1)], &v526_19_cursor);
          compose(&(v536_5),&(v537_6))
        };
        drop(v536_5);
        let v536_8: Space = intersect(&(*CONSTANT_9),&(v536_2));
        drop(v536_2);
        let v536_9: Space = if has_head(&(v536_8)) { singleton(&[]) } else { Space::new() };
        drop(v536_8);
        let v536_11: Space = if (&(v536_9)).is_empty() { Space::new() } else {
          let mut v538_10 = Space::new();
          let mut v538_10_write = v538_10.write_zipper();
          for v538_10_byte in v526_19_cursor.child_mask().iter() {
            v526_19_cursor.descend_to_existing_byte(v538_10_byte);
            {
            let v539_2: Space = singleton(&v526_19_cursor.path()[(v526_19_origin + 2)..(v526_19_origin + 3)]);
            let v539_3: Space = intersect(&(*CONSTANT_9),&(v539_2));
            let v539_4: Space = if has_head(&(v539_3)) { singleton(&[]) } else { Space::new() };
            drop(v539_3);
            let v539_5: Space = subtract(&(*CONSTANT_0),&(v539_4));
            drop(v539_4);
            let v539_7: Space = if (&(v539_5)).is_empty() { Space::new() } else {
              let v540_6: Space = routine_69(c, &v526_19_cursor.path()[(v526_19_origin + 2)..(v526_19_origin + 3)], &(*p1), &(*p2), &(*p0), &v526_19_cursor.path()[v526_19_origin..(v526_19_origin + 1)], &v526_19_cursor.path()[(v526_19_origin + 1)..(v526_19_origin + 2)], &v526_19_cursor);
              compose(&(v539_5),&(v540_6))
            };
            drop(v539_5);
            let v539_8: Space = intersect(&(*CONSTANT_9),&(v539_2));
            drop(v539_2);
            let v539_9: Space = if has_head(&(v539_8)) { singleton(&[]) } else { Space::new() };
            drop(v539_8);
            let v539_11: Space = if (&(v539_9)).is_empty() { Space::new() } else {
              let v541_10: Space = routine_70(c, &v526_19_cursor.path()[(v526_19_origin + 2)..(v526_19_origin + 3)], &(*p1), &(*p2), &(*p0), &v526_19_cursor.path()[v526_19_origin..(v526_19_origin + 1)], &v526_19_cursor.path()[(v526_19_origin + 1)..(v526_19_origin + 2)], &v526_19_cursor);
              compose(&(v539_9),&(v541_10))
            };
            drop(v539_9);
            let v539_12: Space = unite(&(v539_7),&(v539_11));
            join_wrapped_into(&mut v538_10_write,&((v539_12).read_zipper()),&[]);
            }
            v526_19_cursor.ascend(1);
          }
          drop(v538_10_write);
          compose(&(v536_9),&(v538_10))
        };
        drop(v536_9);
        let v536_12: Space = unite(&(v536_7),&(v536_11));
        join_wrapped_into(&mut v535_10_write,&((v536_12).read_zipper()),&[]);
        }
        v526_19_cursor.ascend(1);
      }
      drop(v535_10_write);
      compose(&(v527_9),&(v535_10))
    };
    drop(v527_9);
    let v527_12: Space = unite(&(v527_7),&(v527_11));
    join_wrapped_into(&mut v526_19_write,&((v527_12).read_zipper()),&[]);
    }
    v526_19_cursor.ascend(1);
  }
  drop(v526_19_cursor);
  drop(v526_19_write);
  (v526_19).clone()
}

fn routine_40(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v542_13 = Space::new();
  let mut v542_13_write = v542_13.write_zipper();
  let mut v542_13_cursor = (*s0).read_zipper();
  let v542_13_origin = v542_13_cursor.path().len();
  for v542_13_byte in v542_13_cursor.child_mask().iter() {
    v542_13_cursor.descend_to_existing_byte(v542_13_byte);
    {
    let v543_2: Space = singleton(&v542_13_cursor.path()[v542_13_origin..(v542_13_origin + 1)]);
    let v543_3: Space = intersect(&(*CONSTANT_9),&(v543_2));
    let v543_4: Space = if has_head(&(v543_3)) { singleton(&[]) } else { Space::new() };
    drop(v543_3);
    let v543_5: Space = subtract(&(*CONSTANT_0),&(v543_4));
    drop(v543_4);
    let v543_8: Space = if (&(v543_5)).is_empty() { Space::new() } else {
      let v544_6: Path = concat_path(&(*p0),&v542_13_cursor.path()[v542_13_origin..(v542_13_origin + 1)]);
      let v544_7: Space = routine_40(c, &(v544_6), &(*p1), &(*p2), &v542_13_cursor);
      compose(&(v543_5),&(v544_7))
    };
    drop(v543_5);
    let v543_9: Space = intersect(&(*CONSTANT_9),&(v543_2));
    drop(v543_2);
    let v543_10: Space = if has_head(&(v543_9)) { singleton(&[]) } else { Space::new() };
    drop(v543_9);
    let v543_20: Space = if (&(v543_10)).is_empty() { Space::new() } else {
      let v545_6: Path = concat_path(&(*p0),&v542_13_cursor.path()[v542_13_origin..(v542_13_origin + 1)]);
      let v545_13: Space = if (&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_12).read_zipper(),&(*p1)),&(*p0)),&v542_13_cursor.path()[v542_13_origin..(v542_13_origin + 1)]))).is_empty() { Space::new() } else {
        compose(&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_12).read_zipper(),&(*p1)),&(*p0)),&v542_13_cursor.path()[v542_13_origin..(v542_13_origin + 1)])),&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_12).read_zipper(),&(*p2)),&(*p0)),&v542_13_cursor.path()[v542_13_origin..(v542_13_origin + 1)])))
      };
      let v545_14: Path = concat_path(&(v545_6),&(*p2));
      let v545_15: Space = singleton(&(v545_14));
      drop(v545_14);
      let v545_16: Space = unite(&(v545_13),&(v545_15));
      drop(v545_13);
      drop(v545_15);
      let v545_17: Path = concat_path(&(*p1),&(v545_6));
      drop(v545_6);
      let v545_18: Space = singleton(&(v545_17));
      drop(v545_17);
      let v545_19: Space = unite(&(v545_16),&(v545_18));
      drop(v545_16);
      drop(v545_18);
      compose(&(v543_10),&(v545_19))
    };
    drop(v543_10);
    let v543_21: Space = unite(&(v543_8),&(v543_20));
    drop(v543_20);
    join_wrapped_into(&mut v542_13_write,&((v543_21).read_zipper()),&[]);
    }
    v542_13_cursor.ascend(1);
  }
  drop(v542_13_cursor);
  drop(v542_13_write);
  (v542_13).clone()
}

fn routine_41(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v547_28: Path = concat_path(&(*p1),&(*p2));
  let v547_29: Path = concat_path(&(v547_28),&(*p3));
  drop(v547_28);
  let mut v547_30 = Space::new();
  let mut v547_30_write = v547_30.write_zipper();
  let mut v547_30_cursor = (*s0).read_zipper();
  let v547_30_origin = v547_30_cursor.path().len();
  for v547_30_byte in v547_30_cursor.child_mask().iter() {
    v547_30_cursor.descend_to_existing_byte(v547_30_byte);
    {
    let v548_2: Space = singleton(&v547_30_cursor.path()[v547_30_origin..(v547_30_origin + 1)]);
    let v548_3: Space = intersect(&(*CONSTANT_9),&(v548_2));
    let v548_4: Space = if has_head(&(v548_3)) { singleton(&[]) } else { Space::new() };
    drop(v548_3);
    let v548_5: Space = subtract(&(*CONSTANT_0),&(v548_4));
    drop(v548_4);
    let v548_8: Space = if (&(v548_5)).is_empty() { Space::new() } else {
      let v549_6: Path = concat_path(&(*p0),&v547_30_cursor.path()[v547_30_origin..(v547_30_origin + 1)]);
      let v549_7: Space = routine_41(c, &(v549_6), &(*p1), &(*p2), &(*p3), &v547_30_cursor, &(*s1));
      compose(&(v548_5),&(v549_7))
    };
    drop(v548_5);
    let v548_9: Space = intersect(&(*CONSTANT_9),&(v548_2));
    drop(v548_2);
    let v548_10: Space = if has_head(&(v548_9)) { singleton(&[]) } else { Space::new() };
    drop(v548_9);
    let v548_29: Space = if (&(v548_10)).is_empty() { Space::new() } else {
      let v550_26: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v551_6: Path = concat_path(&(*p0),&v547_30_cursor.path()[v547_30_origin..(v547_30_origin + 1)]);
        let v551_11: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_5), &(v551_6), &((*CONSTANT_9).read_zipper()));
        let v551_12: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_5), &(v551_6), &((*CONSTANT_9).read_zipper()));
        let v551_13: Space = unite(&(v551_11),&(v551_12));
        let v551_14: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_5), &(v551_6), &((*CONSTANT_9).read_zipper()));
        let v551_15: Space = unite(&(v551_13),&(v551_14));
        let v551_16: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_5), &(v551_6), &((*CONSTANT_9).read_zipper()));
        let v551_17: Space = unite(&(v551_15),&(v551_16));
        let v551_18: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_5), &(v551_6), &((*CONSTANT_9).read_zipper()));
        let v551_19: Space = unite(&(v551_17),&(v551_18));
        let v551_20: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_5), &(v551_6), &((*CONSTANT_9).read_zipper()));
        let v551_21: Space = unite(&(v551_19),&(v551_20));
        let v551_22: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_5), &(v551_6), &((*CONSTANT_9).read_zipper()));
        let v551_23: Space = unite(&(v551_21),&(v551_22));
        let v551_24: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_5), &(v551_6), &((*CONSTANT_9).read_zipper()));
        let v551_25: Space = unite(&(v551_23),&(v551_24));
        compose(&(*CONSTANT_0),&(v551_25))
      };
      let v550_27: Space = intersect(&(v550_26),&(*CONSTANT_21));
      let v550_28: Space = unite(&(v550_27),&(*s1));
      compose(&(v548_10),&(v550_28))
    };
    drop(v548_10);
    let v548_30: Space = wrap(&(v548_29),&(v547_29));
    let v552_6: Path = concat_path(&(*p0),&v547_30_cursor.path()[v547_30_origin..(v547_30_origin + 1)]);
    let v548_31: Space = wrap(&(v548_30),&(v552_6));
    let v548_32: Space = unite(&(v548_8),&(v548_31));
    join_wrapped_into(&mut v547_30_write,&((v548_32).read_zipper()),&[]);
    }
    v547_30_cursor.ascend(1);
  }
  drop(v547_30_cursor);
  drop(v547_30_write);
  drop(v547_29);
  (v547_30).clone()
}

fn routine_42(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v553_39: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v554_10: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_5), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v554_13: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_5), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v554_14: Space = unite(&(v554_10),&(v554_13));
    let v554_17: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_5), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v554_18: Space = unite(&(v554_14),&(v554_17));
    let v554_21: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_5), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v554_22: Space = unite(&(v554_18),&(v554_21));
    let v554_25: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_5), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v554_26: Space = unite(&(v554_22),&(v554_25));
    let v554_29: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_5), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v554_30: Space = unite(&(v554_26),&(v554_29));
    let v554_33: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_5), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v554_34: Space = unite(&(v554_30),&(v554_33));
    let v554_37: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_5), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v554_38: Space = unite(&(v554_34),&(v554_37));
    compose(&(*CONSTANT_0),&(v554_38))
  };
  let v553_41: Space = intersect(&(v553_39),&(*CONSTANT_21));
  let v553_42: Space = unite(&(v553_41),&(*s1));
  let v553_43: Path = concat_path(&(*p1),&(*p2));
  let v553_44: Path = concat_path(&(v553_43),&(*p3));
  drop(v553_43);
  let v553_45: Space = wrap(&(v553_42),&(v553_44));
  drop(v553_44);
  let v553_46: Space = wrap(&(v553_45),&(*p0));
  (v553_46).clone()
}

fn routine_43(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v555_14: Path = concat_path(&(*p3),&(*p1));
  let v555_15: Path = concat_path(&(v555_14),&(*p2));
  drop(v555_14);
  let mut v555_16 = Space::new();
  let mut v555_16_write = v555_16.write_zipper();
  let mut v555_16_cursor = (*s0).read_zipper();
  let v555_16_origin = v555_16_cursor.path().len();
  for v555_16_byte in v555_16_cursor.child_mask().iter() {
    v555_16_cursor.descend_to_existing_byte(v555_16_byte);
    {
    let v556_2: Space = singleton(&v555_16_cursor.path()[v555_16_origin..(v555_16_origin + 1)]);
    let v556_3: Space = intersect(&(*CONSTANT_9),&(v556_2));
    let v556_4: Space = if has_head(&(v556_3)) { singleton(&[]) } else { Space::new() };
    drop(v556_3);
    let v556_5: Space = subtract(&(*CONSTANT_0),&(v556_4));
    drop(v556_4);
    let v556_8: Space = if (&(v556_5)).is_empty() { Space::new() } else {
      let v557_6: Path = concat_path(&(*p0),&v555_16_cursor.path()[v555_16_origin..(v555_16_origin + 1)]);
      let v557_7: Space = routine_43(c, &(v557_6), &(*p1), &(*p2), &(*p3), &v555_16_cursor);
      compose(&(v556_5),&(v557_7))
    };
    drop(v556_5);
    let v556_9: Space = intersect(&(*CONSTANT_9),&(v556_2));
    drop(v556_2);
    let v556_10: Space = if has_head(&(v556_9)) { singleton(&[]) } else { Space::new() };
    drop(v556_9);
    let v556_15: Space = if (&(v556_10)).is_empty() { Space::new() } else {
      let v558_6: Path = concat_path(&(*p0),&v555_16_cursor.path()[v555_16_origin..(v555_16_origin + 1)]);
      let v558_12: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v555_16_cursor,(v555_16_origin + 1)),&(*CONSTANT_6))));
      let v558_13: Path = concat_path(&(v555_15),&(v558_6));
      let mut v558_14 = Space::new();
      let mut v558_14_write = v558_14.write_zipper();
      let mut v558_14_cursor = (v558_12).read_zipper();
      let v558_14_origin = v558_14_cursor.path().len();
      for v558_14_byte in v558_14_cursor.child_mask().iter() {
        v558_14_cursor.descend_to_existing_byte(v558_14_byte);
        {
        let v559_2: Space = singleton(&v558_14_cursor.path()[v558_14_origin..(v558_14_origin + 1)]);
        let v559_3: Space = intersect(&(*CONSTANT_9),&(v559_2));
        let v559_4: Space = if has_head(&(v559_3)) { singleton(&[]) } else { Space::new() };
        drop(v559_3);
        let v559_5: Space = subtract(&(*CONSTANT_0),&(v559_4));
        drop(v559_4);
        let v559_7: Space = if (&(v559_5)).is_empty() { Space::new() } else {
          let v560_6: Space = routine_45(c, &v558_14_cursor.path()[v558_14_origin..(v558_14_origin + 1)], &(*p1), &(*p2), &(v558_6), &(*p3), &v558_14_cursor, &v555_16_cursor);
          compose(&(v559_5),&(v560_6))
        };
        drop(v559_5);
        let v559_8: Space = intersect(&(*CONSTANT_9),&(v559_2));
        drop(v559_2);
        let v559_9: Space = if has_head(&(v559_8)) { singleton(&[]) } else { Space::new() };
        drop(v559_8);
        let v559_12: Space = if (&(v559_9)).is_empty() { Space::new() } else {
          let v561_10: Space = routine_1(c, &v558_14_cursor.path()[v558_14_origin..(v558_14_origin + 1)], &(*CONSTANT_6), &(*CONSTANT_2));
          let v561_11: Space = unite(&v555_16_cursor,&(v561_10));
          compose(&(v559_9),&(v561_11))
        };
        drop(v559_9);
        let v559_13: Space = wrap(&(v559_12),&(v558_13));
        let v559_14: Space = wrap(&(v559_13),&v558_14_cursor.path()[v558_14_origin..(v558_14_origin + 1)]);
        let v559_15: Space = unite(&(v559_7),&(v559_14));
        join_wrapped_into(&mut v558_14_write,&((v559_15).read_zipper()),&[]);
        }
        v558_14_cursor.ascend(1);
      }
      drop(v558_14_cursor);
      drop(v558_14_write);
      drop(v558_6);
      drop(v558_12);
      drop(v558_13);
      compose(&(v556_10),&(v558_14))
    };
    drop(v556_10);
    let v556_16: Space = unite(&(v556_8),&(v556_15));
    join_wrapped_into(&mut v555_16_write,&((v556_16).read_zipper()),&[]);
    }
    v555_16_cursor.ascend(1);
  }
  drop(v555_16_cursor);
  drop(v555_16_write);
  drop(v555_15);
  (v555_16).clone()
}

fn routine_44(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v562_8: Space = subtract(&(*CONSTANT_10),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_6))));
  let v562_30: Path = concat_path(&(*p3),&(*p1));
  let v562_31: Path = concat_path(&(v562_30),&(*p2));
  drop(v562_30);
  let v562_32: Path = concat_path(&(v562_31),&(*p0));
  drop(v562_31);
  let mut v562_37 = Space::new();
  let mut v562_37_write = v562_37.write_zipper();
  let mut v562_37_cursor = (v562_8).read_zipper();
  let v562_37_origin = v562_37_cursor.path().len();
  for v562_37_byte in v562_37_cursor.child_mask().iter() {
    v562_37_cursor.descend_to_existing_byte(v562_37_byte);
    {
    let v563_2: Space = singleton(&v562_37_cursor.path()[v562_37_origin..(v562_37_origin + 1)]);
    let v563_3: Space = intersect(&(*CONSTANT_9),&(v563_2));
    let v563_4: Space = if has_head(&(v563_3)) { singleton(&[]) } else { Space::new() };
    drop(v563_3);
    let v563_5: Space = subtract(&(*CONSTANT_0),&(v563_4));
    drop(v563_4);
    let v563_7: Space = if (&(v563_5)).is_empty() { Space::new() } else {
      let mut v564_6 = Space::new();
      let mut v564_6_write = v564_6.write_zipper();
      for v564_6_byte in v562_37_cursor.child_mask().iter() {
        v562_37_cursor.descend_to_existing_byte(v564_6_byte);
        {
        let v565_2: Space = singleton(&v562_37_cursor.path()[(v562_37_origin + 1)..(v562_37_origin + 2)]);
        let v565_3: Space = intersect(&(*CONSTANT_9),&(v565_2));
        let v565_4: Space = if has_head(&(v565_3)) { singleton(&[]) } else { Space::new() };
        drop(v565_3);
        let v565_5: Space = subtract(&(*CONSTANT_0),&(v565_4));
        drop(v565_4);
        let v565_8: Space = if (&(v565_5)).is_empty() { Space::new() } else {
          let v566_7: Space = routine_45(c, &v562_37_cursor.path()[v562_37_origin..(v562_37_origin + 2)], &(*p1), &(*p2), &(*p0), &(*p3), &v562_37_cursor, &(*s0));
          compose(&(v565_5),&(v566_7))
        };
        drop(v565_5);
        let v565_9: Space = intersect(&(*CONSTANT_9),&(v565_2));
        drop(v565_2);
        let v565_10: Space = if has_head(&(v565_9)) { singleton(&[]) } else { Space::new() };
        drop(v565_9);
        let v565_13: Space = if (&(v565_10)).is_empty() { Space::new() } else {
          let v567_11: Space = routine_1(c, &v562_37_cursor.path()[v562_37_origin..(v562_37_origin + 2)], &(*CONSTANT_6), &(*CONSTANT_2));
          let v567_12: Space = unite(&(*s0),&(v567_11));
          compose(&(v565_10),&(v567_12))
        };
        drop(v565_10);
        let v565_14: Space = wrap(&(v565_13),&(v562_32));
        let v565_15: Space = wrap(&(v565_14),&v562_37_cursor.path()[v562_37_origin..(v562_37_origin + 2)]);
        let v565_16: Space = unite(&(v565_8),&(v565_15));
        join_wrapped_into(&mut v564_6_write,&((v565_16).read_zipper()),&[]);
        }
        v562_37_cursor.ascend(1);
      }
      drop(v564_6_write);
      compose(&(v563_5),&(v564_6))
    };
    drop(v563_5);
    let v563_8: Space = intersect(&(*CONSTANT_9),&(v563_2));
    drop(v563_2);
    let v563_9: Space = if has_head(&(v563_8)) { singleton(&[]) } else { Space::new() };
    drop(v563_8);
    let v563_28: Space = if (&(v563_9)).is_empty() { Space::new() } else {
      let v569_25: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v570_10: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_6), &v562_37_cursor.path()[v562_37_origin..(v562_37_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v570_11: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_6), &v562_37_cursor.path()[v562_37_origin..(v562_37_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v570_12: Space = unite(&(v570_10),&(v570_11));
        let v570_13: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_6), &v562_37_cursor.path()[v562_37_origin..(v562_37_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v570_14: Space = unite(&(v570_12),&(v570_13));
        let v570_15: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_6), &v562_37_cursor.path()[v562_37_origin..(v562_37_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v570_16: Space = unite(&(v570_14),&(v570_15));
        let v570_17: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_6), &v562_37_cursor.path()[v562_37_origin..(v562_37_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v570_18: Space = unite(&(v570_16),&(v570_17));
        let v570_19: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_6), &v562_37_cursor.path()[v562_37_origin..(v562_37_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v570_20: Space = unite(&(v570_18),&(v570_19));
        let v570_21: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_6), &v562_37_cursor.path()[v562_37_origin..(v562_37_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v570_22: Space = unite(&(v570_20),&(v570_21));
        let v570_23: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_6), &v562_37_cursor.path()[v562_37_origin..(v562_37_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v570_24: Space = unite(&(v570_22),&(v570_23));
        compose(&(*CONSTANT_0),&(v570_24))
      };
      let v569_26: Space = intersect(&(v569_25),&(*CONSTANT_21));
      let v569_27: Space = unite(&(v569_26),&(*s0));
      compose(&(v563_9),&(v569_27))
    };
    drop(v563_9);
    let v563_29: Space = wrap(&(v563_28),&(v562_32));
    let v563_30: Space = wrap(&(v563_29),&v562_37_cursor.path()[v562_37_origin..(v562_37_origin + 1)]);
    let v563_31: Space = unite(&(v563_7),&(v563_30));
    join_wrapped_into(&mut v562_37_write,&((v563_31).read_zipper()),&[]);
    }
    v562_37_cursor.ascend(1);
  }
  drop(v562_37_cursor);
  drop(v562_37_write);
  drop(v562_8);
  drop(v562_32);
  (v562_37).clone()
}

fn routine_45(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v571_29: Path = concat_path(&(*p4),&(*p1));
  let v571_30: Path = concat_path(&(v571_29),&(*p2));
  drop(v571_29);
  let v571_31: Path = concat_path(&(v571_30),&(*p3));
  drop(v571_30);
  let mut v571_32 = Space::new();
  let mut v571_32_write = v571_32.write_zipper();
  let mut v571_32_cursor = (*s0).read_zipper();
  let v571_32_origin = v571_32_cursor.path().len();
  for v571_32_byte in v571_32_cursor.child_mask().iter() {
    v571_32_cursor.descend_to_existing_byte(v571_32_byte);
    {
    let v572_2: Space = singleton(&v571_32_cursor.path()[v571_32_origin..(v571_32_origin + 1)]);
    let v572_3: Space = intersect(&(*CONSTANT_9),&(v572_2));
    let v572_4: Space = if has_head(&(v572_3)) { singleton(&[]) } else { Space::new() };
    drop(v572_3);
    let v572_5: Space = subtract(&(*CONSTANT_0),&(v572_4));
    drop(v572_4);
    let v572_8: Space = if (&(v572_5)).is_empty() { Space::new() } else {
      let v573_6: Path = concat_path(&(*p0),&v571_32_cursor.path()[v571_32_origin..(v571_32_origin + 1)]);
      let v573_7: Space = routine_45(c, &(v573_6), &(*p1), &(*p2), &(*p3), &(*p4), &v571_32_cursor, &(*s1));
      compose(&(v572_5),&(v573_7))
    };
    drop(v572_5);
    let v572_9: Space = intersect(&(*CONSTANT_9),&(v572_2));
    drop(v572_2);
    let v572_10: Space = if has_head(&(v572_9)) { singleton(&[]) } else { Space::new() };
    drop(v572_9);
    let v572_29: Space = if (&(v572_10)).is_empty() { Space::new() } else {
      let v574_26: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v575_6: Path = concat_path(&(*p0),&v571_32_cursor.path()[v571_32_origin..(v571_32_origin + 1)]);
        let v575_11: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_6), &(v575_6), &((*CONSTANT_9).read_zipper()));
        let v575_12: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_6), &(v575_6), &((*CONSTANT_9).read_zipper()));
        let v575_13: Space = unite(&(v575_11),&(v575_12));
        let v575_14: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_6), &(v575_6), &((*CONSTANT_9).read_zipper()));
        let v575_15: Space = unite(&(v575_13),&(v575_14));
        let v575_16: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_6), &(v575_6), &((*CONSTANT_9).read_zipper()));
        let v575_17: Space = unite(&(v575_15),&(v575_16));
        let v575_18: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_6), &(v575_6), &((*CONSTANT_9).read_zipper()));
        let v575_19: Space = unite(&(v575_17),&(v575_18));
        let v575_20: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_6), &(v575_6), &((*CONSTANT_9).read_zipper()));
        let v575_21: Space = unite(&(v575_19),&(v575_20));
        let v575_22: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_6), &(v575_6), &((*CONSTANT_9).read_zipper()));
        let v575_23: Space = unite(&(v575_21),&(v575_22));
        let v575_24: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_6), &(v575_6), &((*CONSTANT_9).read_zipper()));
        let v575_25: Space = unite(&(v575_23),&(v575_24));
        compose(&(*CONSTANT_0),&(v575_25))
      };
      let v574_27: Space = intersect(&(v574_26),&(*CONSTANT_21));
      let v574_28: Space = unite(&(v574_27),&(*s1));
      compose(&(v572_10),&(v574_28))
    };
    drop(v572_10);
    let v572_30: Space = wrap(&(v572_29),&(v571_31));
    let v576_6: Path = concat_path(&(*p0),&v571_32_cursor.path()[v571_32_origin..(v571_32_origin + 1)]);
    let v572_31: Space = wrap(&(v572_30),&(v576_6));
    let v572_32: Space = unite(&(v572_8),&(v572_31));
    join_wrapped_into(&mut v571_32_write,&((v572_32).read_zipper()),&[]);
    }
    v571_32_cursor.ascend(1);
  }
  drop(v571_32_cursor);
  drop(v571_32_write);
  drop(v571_31);
  (v571_32).clone()
}

fn routine_46(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v577_40: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v578_11: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_6), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v578_14: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_6), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v578_15: Space = unite(&(v578_11),&(v578_14));
    let v578_18: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_6), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v578_19: Space = unite(&(v578_15),&(v578_18));
    let v578_22: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_6), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v578_23: Space = unite(&(v578_19),&(v578_22));
    let v578_26: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_6), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v578_27: Space = unite(&(v578_23),&(v578_26));
    let v578_30: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_6), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v578_31: Space = unite(&(v578_27),&(v578_30));
    let v578_34: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_6), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v578_35: Space = unite(&(v578_31),&(v578_34));
    let v578_38: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_6), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v578_39: Space = unite(&(v578_35),&(v578_38));
    compose(&(*CONSTANT_0),&(v578_39))
  };
  let v577_42: Space = intersect(&(v577_40),&(*CONSTANT_21));
  let v577_43: Space = unite(&(v577_42),&(*s1));
  let v577_44: Path = concat_path(&(*p4),&(*p1));
  let v577_45: Path = concat_path(&(v577_44),&(*p2));
  drop(v577_44);
  let v577_46: Path = concat_path(&(v577_45),&(*p3));
  drop(v577_45);
  let v577_47: Space = wrap(&(v577_43),&(v577_46));
  drop(v577_46);
  let v577_48: Space = wrap(&(v577_47),&(*p0));
  (v577_48).clone()
}

fn routine_47(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v579_16 = Space::new();
  let mut v579_16_write = v579_16.write_zipper();
  let mut v579_16_cursor = (*s0).read_zipper();
  let v579_16_origin = v579_16_cursor.path().len();
  for v579_16_byte in v579_16_cursor.child_mask().iter() {
    v579_16_cursor.descend_to_existing_byte(v579_16_byte);
    {
    let v580_2: Space = singleton(&v579_16_cursor.path()[v579_16_origin..(v579_16_origin + 1)]);
    let v580_3: Space = intersect(&(*CONSTANT_9),&(v580_2));
    let v580_4: Space = if has_head(&(v580_3)) { singleton(&[]) } else { Space::new() };
    drop(v580_3);
    let v580_5: Space = subtract(&(*CONSTANT_0),&(v580_4));
    drop(v580_4);
    let v580_8: Space = if (&(v580_5)).is_empty() { Space::new() } else {
      let v581_6: Path = concat_path(&(*p0),&v579_16_cursor.path()[v579_16_origin..(v579_16_origin + 1)]);
      let v581_7: Space = routine_47(c, &(v581_6), &(*p1), &(*p2), &(*p3), &v579_16_cursor);
      compose(&(v580_5),&(v581_7))
    };
    drop(v580_5);
    let v580_9: Space = intersect(&(*CONSTANT_9),&(v580_2));
    drop(v580_2);
    let v580_10: Space = if has_head(&(v580_9)) { singleton(&[]) } else { Space::new() };
    drop(v580_9);
    let v580_12: Space = if (&(v580_10)).is_empty() { Space::new() } else {
      let v582_6: Path = concat_path(&(*p0),&v579_16_cursor.path()[v579_16_origin..(v579_16_origin + 1)]);
      let mut v582_11 = Space::new();
      let mut v582_11_write = v582_11.write_zipper();
      for v582_11_byte in v579_16_cursor.child_mask().iter() {
        v579_16_cursor.descend_to_existing_byte(v582_11_byte);
        {
        let v583_2: Space = singleton(&v579_16_cursor.path()[(v579_16_origin + 1)..(v579_16_origin + 2)]);
        let v583_3: Space = intersect(&(*CONSTANT_9),&(v583_2));
        let v583_4: Space = if has_head(&(v583_3)) { singleton(&[]) } else { Space::new() };
        drop(v583_3);
        let v583_5: Space = subtract(&(*CONSTANT_0),&(v583_4));
        drop(v583_4);
        let v583_7: Space = if (&(v583_5)).is_empty() { Space::new() } else {
          let v584_6: Space = routine_49(c, &v579_16_cursor.path()[(v579_16_origin + 1)..(v579_16_origin + 2)], &(*p1), &(*p2), &(*p3), &(v582_6), &v579_16_cursor);
          compose(&(v583_5),&(v584_6))
        };
        drop(v583_5);
        let v583_8: Space = intersect(&(*CONSTANT_9),&(v583_2));
        drop(v583_2);
        let v583_9: Space = if has_head(&(v583_8)) { singleton(&[]) } else { Space::new() };
        drop(v583_8);
        let v583_13: Space = if (&(v583_9)).is_empty() { Space::new() } else {
          let v585_11: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v579_16_cursor,(v579_16_origin + 2)),&(*CONSTANT_7))));
          let mut v585_12 = Space::new();
          let mut v585_12_write = v585_12.write_zipper();
          let mut v585_12_cursor = (v585_11).read_zipper();
          let v585_12_origin = v585_12_cursor.path().len();
          for v585_12_byte in v585_12_cursor.child_mask().iter() {
            v585_12_cursor.descend_to_existing_byte(v585_12_byte);
            {
            let v586_2: Space = singleton(&v585_12_cursor.path()[v585_12_origin..(v585_12_origin + 1)]);
            let v586_3: Space = intersect(&(*CONSTANT_9),&(v586_2));
            let v586_4: Space = if has_head(&(v586_3)) { singleton(&[]) } else { Space::new() };
            drop(v586_3);
            let v586_5: Space = subtract(&(*CONSTANT_0),&(v586_4));
            drop(v586_4);
            let v586_7: Space = if (&(v586_5)).is_empty() { Space::new() } else {
              let v587_6: Space = routine_51(c, &v585_12_cursor.path()[v585_12_origin..(v585_12_origin + 1)], &(*p1), &(*p2), &(*p3), &(v582_6), &v579_16_cursor.path()[(v579_16_origin + 1)..(v579_16_origin + 2)], &v585_12_cursor, &v579_16_cursor);
              compose(&(v586_5),&(v587_6))
            };
            drop(v586_5);
            let v586_8: Space = intersect(&(*CONSTANT_9),&(v586_2));
            drop(v586_2);
            let v586_9: Space = if has_head(&(v586_8)) { singleton(&[]) } else { Space::new() };
            drop(v586_8);
            let v586_11: Space = if (&(v586_9)).is_empty() { Space::new() } else {
              let v588_10: Space = routine_52(c, &v585_12_cursor.path()[v585_12_origin..(v585_12_origin + 1)], &(*p1), &(*p2), &(*p3), &(v582_6), &v579_16_cursor.path()[(v579_16_origin + 1)..(v579_16_origin + 2)], &v585_12_cursor, &v579_16_cursor);
              compose(&(v586_9),&(v588_10))
            };
            drop(v586_9);
            let v586_12: Space = unite(&(v586_7),&(v586_11));
            join_wrapped_into(&mut v585_12_write,&((v586_12).read_zipper()),&[]);
            }
            v585_12_cursor.ascend(1);
          }
          drop(v585_12_cursor);
          drop(v585_12_write);
          drop(v585_11);
          compose(&(v583_9),&(v585_12))
        };
        drop(v583_9);
        let v583_14: Space = unite(&(v583_7),&(v583_13));
        join_wrapped_into(&mut v582_11_write,&((v583_14).read_zipper()),&[]);
        }
        v579_16_cursor.ascend(1);
      }
      drop(v582_11_write);
      drop(v582_6);
      compose(&(v580_10),&(v582_11))
    };
    drop(v580_10);
    let v580_13: Space = unite(&(v580_8),&(v580_12));
    join_wrapped_into(&mut v579_16_write,&((v580_13).read_zipper()),&[]);
    }
    v579_16_cursor.ascend(1);
  }
  drop(v579_16_cursor);
  drop(v579_16_write);
  (v579_16).clone()
}

fn routine_48(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v589_18: Path = concat_path(&(*p1),&(*p2));
  let v589_22: Path = concat_path(&(v589_18),&(*p3));
  drop(v589_18);
  let v589_23: Path = concat_path(&(v589_22),&(*p0));
  drop(v589_22);
  let mut v589_24 = Space::new();
  let mut v589_24_write = v589_24.write_zipper();
  let mut v589_24_cursor = (*s0).read_zipper();
  let v589_24_origin = v589_24_cursor.path().len();
  for v589_24_byte in v589_24_cursor.child_mask().iter() {
    v589_24_cursor.descend_to_existing_byte(v589_24_byte);
    {
    let v590_2: Space = singleton(&v589_24_cursor.path()[v589_24_origin..(v589_24_origin + 1)]);
    let v590_3: Space = intersect(&(*CONSTANT_9),&(v590_2));
    let v590_4: Space = if has_head(&(v590_3)) { singleton(&[]) } else { Space::new() };
    drop(v590_3);
    let v590_5: Space = subtract(&(*CONSTANT_0),&(v590_4));
    drop(v590_4);
    let v590_7: Space = if (&(v590_5)).is_empty() { Space::new() } else {
      let mut v591_6 = Space::new();
      let mut v591_6_write = v591_6.write_zipper();
      for v591_6_byte in v589_24_cursor.child_mask().iter() {
        v589_24_cursor.descend_to_existing_byte(v591_6_byte);
        {
        let v592_2: Space = singleton(&v589_24_cursor.path()[(v589_24_origin + 1)..(v589_24_origin + 2)]);
        let v592_3: Space = intersect(&(*CONSTANT_9),&(v592_2));
        let v592_4: Space = if has_head(&(v592_3)) { singleton(&[]) } else { Space::new() };
        drop(v592_3);
        let v592_5: Space = subtract(&(*CONSTANT_0),&(v592_4));
        drop(v592_4);
        let v592_8: Space = if (&(v592_5)).is_empty() { Space::new() } else {
          let v593_7: Space = routine_49(c, &v589_24_cursor.path()[v589_24_origin..(v589_24_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p0), &v589_24_cursor);
          compose(&(v592_5),&(v593_7))
        };
        drop(v592_5);
        let v592_9: Space = intersect(&(*CONSTANT_9),&(v592_2));
        drop(v592_2);
        let v592_10: Space = if has_head(&(v592_9)) { singleton(&[]) } else { Space::new() };
        drop(v592_9);
        let v592_14: Space = if (&(v592_10)).is_empty() { Space::new() } else {
          let v594_12: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v589_24_cursor,(v589_24_origin + 2)),&(*CONSTANT_7))));
          let mut v594_13 = Space::new();
          let mut v594_13_write = v594_13.write_zipper();
          let mut v594_13_cursor = (v594_12).read_zipper();
          let v594_13_origin = v594_13_cursor.path().len();
          for v594_13_byte in v594_13_cursor.child_mask().iter() {
            v594_13_cursor.descend_to_existing_byte(v594_13_byte);
            {
            let v595_2: Space = singleton(&v594_13_cursor.path()[v594_13_origin..(v594_13_origin + 1)]);
            let v595_3: Space = intersect(&(*CONSTANT_9),&(v595_2));
            let v595_4: Space = if has_head(&(v595_3)) { singleton(&[]) } else { Space::new() };
            drop(v595_3);
            let v595_5: Space = subtract(&(*CONSTANT_0),&(v595_4));
            drop(v595_4);
            let v595_7: Space = if (&(v595_5)).is_empty() { Space::new() } else {
              let v596_6: Space = routine_51(c, &v594_13_cursor.path()[v594_13_origin..(v594_13_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p0), &v589_24_cursor.path()[v589_24_origin..(v589_24_origin + 2)], &v594_13_cursor, &v589_24_cursor);
              compose(&(v595_5),&(v596_6))
            };
            drop(v595_5);
            let v595_8: Space = intersect(&(*CONSTANT_9),&(v595_2));
            drop(v595_2);
            let v595_9: Space = if has_head(&(v595_8)) { singleton(&[]) } else { Space::new() };
            drop(v595_8);
            let v595_11: Space = if (&(v595_9)).is_empty() { Space::new() } else {
              let v597_10: Space = routine_52(c, &v594_13_cursor.path()[v594_13_origin..(v594_13_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p0), &v589_24_cursor.path()[v589_24_origin..(v589_24_origin + 2)], &v594_13_cursor, &v589_24_cursor);
              compose(&(v595_9),&(v597_10))
            };
            drop(v595_9);
            let v595_12: Space = unite(&(v595_7),&(v595_11));
            join_wrapped_into(&mut v594_13_write,&((v595_12).read_zipper()),&[]);
            }
            v594_13_cursor.ascend(1);
          }
          drop(v594_13_cursor);
          drop(v594_13_write);
          drop(v594_12);
          compose(&(v592_10),&(v594_13))
        };
        drop(v592_10);
        let v592_15: Space = unite(&(v592_8),&(v592_14));
        join_wrapped_into(&mut v591_6_write,&((v592_15).read_zipper()),&[]);
        }
        v589_24_cursor.ascend(1);
      }
      drop(v591_6_write);
      compose(&(v590_5),&(v591_6))
    };
    drop(v590_5);
    let v590_8: Space = intersect(&(*CONSTANT_9),&(v590_2));
    drop(v590_2);
    let v590_9: Space = if has_head(&(v590_8)) { singleton(&[]) } else { Space::new() };
    drop(v590_8);
    let v590_14: Space = if (&(v590_9)).is_empty() { Space::new() } else {
      let v598_11: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v589_24_cursor,(v589_24_origin + 1)),&(*CONSTANT_7))));
      let v598_12: Path = concat_path(&(v589_23),&v589_24_cursor.path()[v589_24_origin..(v589_24_origin + 1)]);
      let mut v598_13 = Space::new();
      let mut v598_13_write = v598_13.write_zipper();
      let mut v598_13_cursor = (v598_11).read_zipper();
      let v598_13_origin = v598_13_cursor.path().len();
      for v598_13_byte in v598_13_cursor.child_mask().iter() {
        v598_13_cursor.descend_to_existing_byte(v598_13_byte);
        {
        let v599_2: Space = singleton(&v598_13_cursor.path()[v598_13_origin..(v598_13_origin + 1)]);
        let v599_3: Space = intersect(&(*CONSTANT_9),&(v599_2));
        let v599_4: Space = if has_head(&(v599_3)) { singleton(&[]) } else { Space::new() };
        drop(v599_3);
        let v599_5: Space = subtract(&(*CONSTANT_0),&(v599_4));
        drop(v599_4);
        let v599_7: Space = if (&(v599_5)).is_empty() { Space::new() } else {
          let v600_6: Space = routine_51(c, &v598_13_cursor.path()[v598_13_origin..(v598_13_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p0), &v589_24_cursor.path()[v589_24_origin..(v589_24_origin + 1)], &v598_13_cursor, &v589_24_cursor);
          compose(&(v599_5),&(v600_6))
        };
        drop(v599_5);
        let v599_8: Space = intersect(&(*CONSTANT_9),&(v599_2));
        drop(v599_2);
        let v599_9: Space = if has_head(&(v599_8)) { singleton(&[]) } else { Space::new() };
        drop(v599_8);
        let v599_12: Space = if (&(v599_9)).is_empty() { Space::new() } else {
          let v601_10: Space = routine_1(c, &v598_13_cursor.path()[v598_13_origin..(v598_13_origin + 1)], &(*CONSTANT_7), &(*CONSTANT_2));
          let v601_11: Space = unite(&v589_24_cursor,&(v601_10));
          compose(&(v599_9),&(v601_11))
        };
        drop(v599_9);
        let v599_13: Space = wrap(&(v599_12),&(v598_12));
        let v599_14: Space = wrap(&(v599_13),&v598_13_cursor.path()[v598_13_origin..(v598_13_origin + 1)]);
        let v599_15: Space = unite(&(v599_7),&(v599_14));
        join_wrapped_into(&mut v598_13_write,&((v599_15).read_zipper()),&[]);
        }
        v598_13_cursor.ascend(1);
      }
      drop(v598_13_cursor);
      drop(v598_13_write);
      drop(v598_11);
      drop(v598_12);
      compose(&(v590_9),&(v598_13))
    };
    drop(v590_9);
    let v590_15: Space = unite(&(v590_7),&(v590_14));
    join_wrapped_into(&mut v589_24_write,&((v590_15).read_zipper()),&[]);
    }
    v589_24_cursor.ascend(1);
  }
  drop(v589_24_cursor);
  drop(v589_24_write);
  drop(v589_23);
  (v589_24).clone()
}

fn routine_49(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v602_15: Path = concat_path(&(*p1),&(*p2));
  let v602_16: Path = concat_path(&(v602_15),&(*p3));
  drop(v602_15);
  let v602_17: Path = concat_path(&(v602_16),&(*p4));
  drop(v602_16);
  let mut v602_18 = Space::new();
  let mut v602_18_write = v602_18.write_zipper();
  let mut v602_18_cursor = (*s0).read_zipper();
  let v602_18_origin = v602_18_cursor.path().len();
  for v602_18_byte in v602_18_cursor.child_mask().iter() {
    v602_18_cursor.descend_to_existing_byte(v602_18_byte);
    {
    let v603_2: Space = singleton(&v602_18_cursor.path()[v602_18_origin..(v602_18_origin + 1)]);
    let v603_3: Space = intersect(&(*CONSTANT_9),&(v603_2));
    let v603_4: Space = if has_head(&(v603_3)) { singleton(&[]) } else { Space::new() };
    drop(v603_3);
    let v603_5: Space = subtract(&(*CONSTANT_0),&(v603_4));
    drop(v603_4);
    let v603_8: Space = if (&(v603_5)).is_empty() { Space::new() } else {
      let v604_6: Path = concat_path(&(*p0),&v602_18_cursor.path()[v602_18_origin..(v602_18_origin + 1)]);
      let v604_7: Space = routine_49(c, &(v604_6), &(*p1), &(*p2), &(*p3), &(*p4), &v602_18_cursor);
      compose(&(v603_5),&(v604_7))
    };
    drop(v603_5);
    let v603_9: Space = intersect(&(*CONSTANT_9),&(v603_2));
    drop(v603_2);
    let v603_10: Space = if has_head(&(v603_9)) { singleton(&[]) } else { Space::new() };
    drop(v603_9);
    let v603_15: Space = if (&(v603_10)).is_empty() { Space::new() } else {
      let v605_6: Path = concat_path(&(*p0),&v602_18_cursor.path()[v602_18_origin..(v602_18_origin + 1)]);
      let v605_12: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v602_18_cursor,(v602_18_origin + 1)),&(*CONSTANT_7))));
      let v605_13: Path = concat_path(&(v602_17),&(v605_6));
      let mut v605_14 = Space::new();
      let mut v605_14_write = v605_14.write_zipper();
      let mut v605_14_cursor = (v605_12).read_zipper();
      let v605_14_origin = v605_14_cursor.path().len();
      for v605_14_byte in v605_14_cursor.child_mask().iter() {
        v605_14_cursor.descend_to_existing_byte(v605_14_byte);
        {
        let v606_2: Space = singleton(&v605_14_cursor.path()[v605_14_origin..(v605_14_origin + 1)]);
        let v606_3: Space = intersect(&(*CONSTANT_9),&(v606_2));
        let v606_4: Space = if has_head(&(v606_3)) { singleton(&[]) } else { Space::new() };
        drop(v606_3);
        let v606_5: Space = subtract(&(*CONSTANT_0),&(v606_4));
        drop(v606_4);
        let v606_7: Space = if (&(v606_5)).is_empty() { Space::new() } else {
          let v607_6: Space = routine_51(c, &v605_14_cursor.path()[v605_14_origin..(v605_14_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p4), &(v605_6), &v605_14_cursor, &v602_18_cursor);
          compose(&(v606_5),&(v607_6))
        };
        drop(v606_5);
        let v606_8: Space = intersect(&(*CONSTANT_9),&(v606_2));
        drop(v606_2);
        let v606_9: Space = if has_head(&(v606_8)) { singleton(&[]) } else { Space::new() };
        drop(v606_8);
        let v606_12: Space = if (&(v606_9)).is_empty() { Space::new() } else {
          let v608_10: Space = routine_1(c, &v605_14_cursor.path()[v605_14_origin..(v605_14_origin + 1)], &(*CONSTANT_7), &(*CONSTANT_2));
          let v608_11: Space = unite(&v602_18_cursor,&(v608_10));
          compose(&(v606_9),&(v608_11))
        };
        drop(v606_9);
        let v606_13: Space = wrap(&(v606_12),&(v605_13));
        let v606_14: Space = wrap(&(v606_13),&v605_14_cursor.path()[v605_14_origin..(v605_14_origin + 1)]);
        let v606_15: Space = unite(&(v606_7),&(v606_14));
        join_wrapped_into(&mut v605_14_write,&((v606_15).read_zipper()),&[]);
        }
        v605_14_cursor.ascend(1);
      }
      drop(v605_14_cursor);
      drop(v605_14_write);
      drop(v605_6);
      drop(v605_12);
      drop(v605_13);
      compose(&(v603_10),&(v605_14))
    };
    drop(v603_10);
    let v603_16: Space = unite(&(v603_8),&(v603_15));
    join_wrapped_into(&mut v602_18_write,&((v603_16).read_zipper()),&[]);
    }
    v602_18_cursor.ascend(1);
  }
  drop(v602_18_cursor);
  drop(v602_18_write);
  drop(v602_17);
  (v602_18).clone()
}

fn routine_50(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v609_9: Space = subtract(&(*CONSTANT_10),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_7))));
  let v609_31: Path = concat_path(&(*p1),&(*p2));
  let v609_32: Path = concat_path(&(v609_31),&(*p3));
  drop(v609_31);
  let v609_33: Path = concat_path(&(v609_32),&(*p4));
  drop(v609_32);
  let v609_34: Path = concat_path(&(v609_33),&(*p0));
  drop(v609_33);
  let mut v609_39 = Space::new();
  let mut v609_39_write = v609_39.write_zipper();
  let mut v609_39_cursor = (v609_9).read_zipper();
  let v609_39_origin = v609_39_cursor.path().len();
  for v609_39_byte in v609_39_cursor.child_mask().iter() {
    v609_39_cursor.descend_to_existing_byte(v609_39_byte);
    {
    let v610_2: Space = singleton(&v609_39_cursor.path()[v609_39_origin..(v609_39_origin + 1)]);
    let v610_3: Space = intersect(&(*CONSTANT_9),&(v610_2));
    let v610_4: Space = if has_head(&(v610_3)) { singleton(&[]) } else { Space::new() };
    drop(v610_3);
    let v610_5: Space = subtract(&(*CONSTANT_0),&(v610_4));
    drop(v610_4);
    let v610_7: Space = if (&(v610_5)).is_empty() { Space::new() } else {
      let mut v611_6 = Space::new();
      let mut v611_6_write = v611_6.write_zipper();
      for v611_6_byte in v609_39_cursor.child_mask().iter() {
        v609_39_cursor.descend_to_existing_byte(v611_6_byte);
        {
        let v612_2: Space = singleton(&v609_39_cursor.path()[(v609_39_origin + 1)..(v609_39_origin + 2)]);
        let v612_3: Space = intersect(&(*CONSTANT_9),&(v612_2));
        let v612_4: Space = if has_head(&(v612_3)) { singleton(&[]) } else { Space::new() };
        drop(v612_3);
        let v612_5: Space = subtract(&(*CONSTANT_0),&(v612_4));
        drop(v612_4);
        let v612_8: Space = if (&(v612_5)).is_empty() { Space::new() } else {
          let v613_7: Space = routine_51(c, &v609_39_cursor.path()[v609_39_origin..(v609_39_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v609_39_cursor, &(*s0));
          compose(&(v612_5),&(v613_7))
        };
        drop(v612_5);
        let v612_9: Space = intersect(&(*CONSTANT_9),&(v612_2));
        drop(v612_2);
        let v612_10: Space = if has_head(&(v612_9)) { singleton(&[]) } else { Space::new() };
        drop(v612_9);
        let v612_13: Space = if (&(v612_10)).is_empty() { Space::new() } else {
          let v614_11: Space = routine_1(c, &v609_39_cursor.path()[v609_39_origin..(v609_39_origin + 2)], &(*CONSTANT_7), &(*CONSTANT_2));
          let v614_12: Space = unite(&(*s0),&(v614_11));
          compose(&(v612_10),&(v614_12))
        };
        drop(v612_10);
        let v612_14: Space = wrap(&(v612_13),&(v609_34));
        let v612_15: Space = wrap(&(v612_14),&v609_39_cursor.path()[v609_39_origin..(v609_39_origin + 2)]);
        let v612_16: Space = unite(&(v612_8),&(v612_15));
        join_wrapped_into(&mut v611_6_write,&((v612_16).read_zipper()),&[]);
        }
        v609_39_cursor.ascend(1);
      }
      drop(v611_6_write);
      compose(&(v610_5),&(v611_6))
    };
    drop(v610_5);
    let v610_8: Space = intersect(&(*CONSTANT_9),&(v610_2));
    drop(v610_2);
    let v610_9: Space = if has_head(&(v610_8)) { singleton(&[]) } else { Space::new() };
    drop(v610_8);
    let v610_28: Space = if (&(v610_9)).is_empty() { Space::new() } else {
      let v616_25: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v617_10: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_7), &v609_39_cursor.path()[v609_39_origin..(v609_39_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v617_11: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_7), &v609_39_cursor.path()[v609_39_origin..(v609_39_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v617_12: Space = unite(&(v617_10),&(v617_11));
        let v617_13: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_7), &v609_39_cursor.path()[v609_39_origin..(v609_39_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v617_14: Space = unite(&(v617_12),&(v617_13));
        let v617_15: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_7), &v609_39_cursor.path()[v609_39_origin..(v609_39_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v617_16: Space = unite(&(v617_14),&(v617_15));
        let v617_17: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_7), &v609_39_cursor.path()[v609_39_origin..(v609_39_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v617_18: Space = unite(&(v617_16),&(v617_17));
        let v617_19: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_7), &v609_39_cursor.path()[v609_39_origin..(v609_39_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v617_20: Space = unite(&(v617_18),&(v617_19));
        let v617_21: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_7), &v609_39_cursor.path()[v609_39_origin..(v609_39_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v617_22: Space = unite(&(v617_20),&(v617_21));
        let v617_23: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_7), &v609_39_cursor.path()[v609_39_origin..(v609_39_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v617_24: Space = unite(&(v617_22),&(v617_23));
        compose(&(*CONSTANT_0),&(v617_24))
      };
      let v616_26: Space = intersect(&(v616_25),&(*CONSTANT_21));
      let v616_27: Space = unite(&(v616_26),&(*s0));
      compose(&(v610_9),&(v616_27))
    };
    drop(v610_9);
    let v610_29: Space = wrap(&(v610_28),&(v609_34));
    let v610_30: Space = wrap(&(v610_29),&v609_39_cursor.path()[v609_39_origin..(v609_39_origin + 1)]);
    let v610_31: Space = unite(&(v610_7),&(v610_30));
    join_wrapped_into(&mut v609_39_write,&((v610_31).read_zipper()),&[]);
    }
    v609_39_cursor.ascend(1);
  }
  drop(v609_39_cursor);
  drop(v609_39_write);
  drop(v609_9);
  drop(v609_34);
  (v609_39).clone()
}

fn routine_51(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v618_30: Path = concat_path(&(*p1),&(*p2));
  let v618_31: Path = concat_path(&(v618_30),&(*p3));
  drop(v618_30);
  let v618_32: Path = concat_path(&(v618_31),&(*p4));
  drop(v618_31);
  let v618_33: Path = concat_path(&(v618_32),&(*p5));
  drop(v618_32);
  let mut v618_34 = Space::new();
  let mut v618_34_write = v618_34.write_zipper();
  let mut v618_34_cursor = (*s0).read_zipper();
  let v618_34_origin = v618_34_cursor.path().len();
  for v618_34_byte in v618_34_cursor.child_mask().iter() {
    v618_34_cursor.descend_to_existing_byte(v618_34_byte);
    {
    let v619_2: Space = singleton(&v618_34_cursor.path()[v618_34_origin..(v618_34_origin + 1)]);
    let v619_3: Space = intersect(&(*CONSTANT_9),&(v619_2));
    let v619_4: Space = if has_head(&(v619_3)) { singleton(&[]) } else { Space::new() };
    drop(v619_3);
    let v619_5: Space = subtract(&(*CONSTANT_0),&(v619_4));
    drop(v619_4);
    let v619_8: Space = if (&(v619_5)).is_empty() { Space::new() } else {
      let v620_6: Path = concat_path(&(*p0),&v618_34_cursor.path()[v618_34_origin..(v618_34_origin + 1)]);
      let v620_7: Space = routine_51(c, &(v620_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &v618_34_cursor, &(*s1));
      compose(&(v619_5),&(v620_7))
    };
    drop(v619_5);
    let v619_9: Space = intersect(&(*CONSTANT_9),&(v619_2));
    drop(v619_2);
    let v619_10: Space = if has_head(&(v619_9)) { singleton(&[]) } else { Space::new() };
    drop(v619_9);
    let v619_29: Space = if (&(v619_10)).is_empty() { Space::new() } else {
      let v621_26: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v622_6: Path = concat_path(&(*p0),&v618_34_cursor.path()[v618_34_origin..(v618_34_origin + 1)]);
        let v622_11: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_7), &(v622_6), &((*CONSTANT_9).read_zipper()));
        let v622_12: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_7), &(v622_6), &((*CONSTANT_9).read_zipper()));
        let v622_13: Space = unite(&(v622_11),&(v622_12));
        let v622_14: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_7), &(v622_6), &((*CONSTANT_9).read_zipper()));
        let v622_15: Space = unite(&(v622_13),&(v622_14));
        let v622_16: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_7), &(v622_6), &((*CONSTANT_9).read_zipper()));
        let v622_17: Space = unite(&(v622_15),&(v622_16));
        let v622_18: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_7), &(v622_6), &((*CONSTANT_9).read_zipper()));
        let v622_19: Space = unite(&(v622_17),&(v622_18));
        let v622_20: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_7), &(v622_6), &((*CONSTANT_9).read_zipper()));
        let v622_21: Space = unite(&(v622_19),&(v622_20));
        let v622_22: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_7), &(v622_6), &((*CONSTANT_9).read_zipper()));
        let v622_23: Space = unite(&(v622_21),&(v622_22));
        let v622_24: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_7), &(v622_6), &((*CONSTANT_9).read_zipper()));
        let v622_25: Space = unite(&(v622_23),&(v622_24));
        compose(&(*CONSTANT_0),&(v622_25))
      };
      let v621_27: Space = intersect(&(v621_26),&(*CONSTANT_21));
      let v621_28: Space = unite(&(v621_27),&(*s1));
      compose(&(v619_10),&(v621_28))
    };
    drop(v619_10);
    let v619_30: Space = wrap(&(v619_29),&(v618_33));
    let v623_6: Path = concat_path(&(*p0),&v618_34_cursor.path()[v618_34_origin..(v618_34_origin + 1)]);
    let v619_31: Space = wrap(&(v619_30),&(v623_6));
    let v619_32: Space = unite(&(v619_8),&(v619_31));
    join_wrapped_into(&mut v618_34_write,&((v619_32).read_zipper()),&[]);
    }
    v618_34_cursor.ascend(1);
  }
  drop(v618_34_cursor);
  drop(v618_34_write);
  drop(v618_33);
  (v618_34).clone()
}

fn routine_52(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v624_41: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v625_12: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_7), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v625_15: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_7), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v625_16: Space = unite(&(v625_12),&(v625_15));
    let v625_19: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_7), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v625_20: Space = unite(&(v625_16),&(v625_19));
    let v625_23: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_7), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v625_24: Space = unite(&(v625_20),&(v625_23));
    let v625_27: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_7), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v625_28: Space = unite(&(v625_24),&(v625_27));
    let v625_31: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_7), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v625_32: Space = unite(&(v625_28),&(v625_31));
    let v625_35: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_7), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v625_36: Space = unite(&(v625_32),&(v625_35));
    let v625_39: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_7), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v625_40: Space = unite(&(v625_36),&(v625_39));
    compose(&(*CONSTANT_0),&(v625_40))
  };
  let v624_43: Space = intersect(&(v624_41),&(*CONSTANT_21));
  let v624_44: Space = unite(&(v624_43),&(*s1));
  let v624_45: Path = concat_path(&(*p1),&(*p2));
  let v624_46: Path = concat_path(&(v624_45),&(*p3));
  drop(v624_45);
  let v624_47: Path = concat_path(&(v624_46),&(*p4));
  drop(v624_46);
  let v624_48: Path = concat_path(&(v624_47),&(*p5));
  drop(v624_47);
  let v624_49: Space = wrap(&(v624_44),&(v624_48));
  drop(v624_48);
  let v624_50: Space = wrap(&(v624_49),&(*p0));
  (v624_50).clone()
}

fn routine_53(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v626_14 = Space::new();
  let mut v626_14_write = v626_14.write_zipper();
  let mut v626_14_cursor = (*s0).read_zipper();
  let v626_14_origin = v626_14_cursor.path().len();
  for v626_14_byte in v626_14_cursor.child_mask().iter() {
    v626_14_cursor.descend_to_existing_byte(v626_14_byte);
    {
    let v627_2: Space = singleton(&v626_14_cursor.path()[v626_14_origin..(v626_14_origin + 1)]);
    let v627_3: Space = intersect(&(*CONSTANT_9),&(v627_2));
    let v627_4: Space = if has_head(&(v627_3)) { singleton(&[]) } else { Space::new() };
    drop(v627_3);
    let v627_5: Space = subtract(&(*CONSTANT_0),&(v627_4));
    drop(v627_4);
    let v627_8: Space = if (&(v627_5)).is_empty() { Space::new() } else {
      let v628_6: Path = concat_path(&(*p0),&v626_14_cursor.path()[v626_14_origin..(v626_14_origin + 1)]);
      let v628_7: Space = routine_53(c, &(v628_6), &(*p1), &(*p2), &(*p3), &v626_14_cursor);
      compose(&(v627_5),&(v628_7))
    };
    drop(v627_5);
    let v627_9: Space = intersect(&(*CONSTANT_9),&(v627_2));
    drop(v627_2);
    let v627_10: Space = if has_head(&(v627_9)) { singleton(&[]) } else { Space::new() };
    drop(v627_9);
    let v627_12: Space = if (&(v627_10)).is_empty() { Space::new() } else {
      let v629_6: Path = concat_path(&(*p0),&v626_14_cursor.path()[v626_14_origin..(v626_14_origin + 1)]);
      let mut v629_11 = Space::new();
      let mut v629_11_write = v629_11.write_zipper();
      for v629_11_byte in v626_14_cursor.child_mask().iter() {
        v626_14_cursor.descend_to_existing_byte(v629_11_byte);
        {
        let v630_2: Space = singleton(&v626_14_cursor.path()[(v626_14_origin + 1)..(v626_14_origin + 2)]);
        let v630_3: Space = intersect(&(*CONSTANT_9),&(v630_2));
        let v630_4: Space = if has_head(&(v630_3)) { singleton(&[]) } else { Space::new() };
        drop(v630_3);
        let v630_5: Space = subtract(&(*CONSTANT_0),&(v630_4));
        drop(v630_4);
        let v630_7: Space = if (&(v630_5)).is_empty() { Space::new() } else {
          let v631_6: Space = routine_55(c, &v626_14_cursor.path()[(v626_14_origin + 1)..(v626_14_origin + 2)], &(*p1), &(*p2), &(*p3), &(v629_6), &v626_14_cursor);
          compose(&(v630_5),&(v631_6))
        };
        drop(v630_5);
        let v630_8: Space = intersect(&(*CONSTANT_9),&(v630_2));
        drop(v630_2);
        let v630_9: Space = if has_head(&(v630_8)) { singleton(&[]) } else { Space::new() };
        drop(v630_8);
        let v630_11: Space = if (&(v630_9)).is_empty() { Space::new() } else {
          let mut v632_10 = Space::new();
          let mut v632_10_write = v632_10.write_zipper();
          for v632_10_byte in v626_14_cursor.child_mask().iter() {
            v626_14_cursor.descend_to_existing_byte(v632_10_byte);
            {
            let v633_2: Space = singleton(&v626_14_cursor.path()[(v626_14_origin + 2)..(v626_14_origin + 3)]);
            let v633_3: Space = intersect(&(*CONSTANT_9),&(v633_2));
            let v633_4: Space = if has_head(&(v633_3)) { singleton(&[]) } else { Space::new() };
            drop(v633_3);
            let v633_5: Space = subtract(&(*CONSTANT_0),&(v633_4));
            drop(v633_4);
            let v633_7: Space = if (&(v633_5)).is_empty() { Space::new() } else {
              let v634_6: Space = routine_57(c, &v626_14_cursor.path()[(v626_14_origin + 2)..(v626_14_origin + 3)], &(*p1), &(*p2), &(*p3), &(v629_6), &v626_14_cursor.path()[(v626_14_origin + 1)..(v626_14_origin + 2)], &v626_14_cursor);
              compose(&(v633_5),&(v634_6))
            };
            drop(v633_5);
            let v633_8: Space = intersect(&(*CONSTANT_9),&(v633_2));
            drop(v633_2);
            let v633_9: Space = if has_head(&(v633_8)) { singleton(&[]) } else { Space::new() };
            drop(v633_8);
            let v633_11: Space = if (&(v633_9)).is_empty() { Space::new() } else {
              let v635_10: Space = routine_58(c, &v626_14_cursor.path()[(v626_14_origin + 2)..(v626_14_origin + 3)], &(*p1), &(*p2), &(*p3), &(v629_6), &v626_14_cursor.path()[(v626_14_origin + 1)..(v626_14_origin + 2)], &v626_14_cursor);
              compose(&(v633_9),&(v635_10))
            };
            drop(v633_9);
            let v633_12: Space = unite(&(v633_7),&(v633_11));
            join_wrapped_into(&mut v632_10_write,&((v633_12).read_zipper()),&[]);
            }
            v626_14_cursor.ascend(1);
          }
          drop(v632_10_write);
          compose(&(v630_9),&(v632_10))
        };
        drop(v630_9);
        let v630_12: Space = unite(&(v630_7),&(v630_11));
        join_wrapped_into(&mut v629_11_write,&((v630_12).read_zipper()),&[]);
        }
        v626_14_cursor.ascend(1);
      }
      drop(v629_11_write);
      drop(v629_6);
      compose(&(v627_10),&(v629_11))
    };
    drop(v627_10);
    let v627_13: Space = unite(&(v627_8),&(v627_12));
    join_wrapped_into(&mut v626_14_write,&((v627_13).read_zipper()),&[]);
    }
    v626_14_cursor.ascend(1);
  }
  drop(v626_14_cursor);
  drop(v626_14_write);
  (v626_14).clone()
}

fn routine_54(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v636_22 = Space::new();
  let mut v636_22_write = v636_22.write_zipper();
  let mut v636_22_cursor = (*s0).read_zipper();
  let v636_22_origin = v636_22_cursor.path().len();
  for v636_22_byte in v636_22_cursor.child_mask().iter() {
    v636_22_cursor.descend_to_existing_byte(v636_22_byte);
    {
    let v637_2: Space = singleton(&v636_22_cursor.path()[v636_22_origin..(v636_22_origin + 1)]);
    let v637_3: Space = intersect(&(*CONSTANT_9),&(v637_2));
    let v637_4: Space = if has_head(&(v637_3)) { singleton(&[]) } else { Space::new() };
    drop(v637_3);
    let v637_5: Space = subtract(&(*CONSTANT_0),&(v637_4));
    drop(v637_4);
    let v637_7: Space = if (&(v637_5)).is_empty() { Space::new() } else {
      let mut v638_6 = Space::new();
      let mut v638_6_write = v638_6.write_zipper();
      for v638_6_byte in v636_22_cursor.child_mask().iter() {
        v636_22_cursor.descend_to_existing_byte(v638_6_byte);
        {
        let v639_2: Space = singleton(&v636_22_cursor.path()[(v636_22_origin + 1)..(v636_22_origin + 2)]);
        let v639_3: Space = intersect(&(*CONSTANT_9),&(v639_2));
        let v639_4: Space = if has_head(&(v639_3)) { singleton(&[]) } else { Space::new() };
        drop(v639_3);
        let v639_5: Space = subtract(&(*CONSTANT_0),&(v639_4));
        drop(v639_4);
        let v639_8: Space = if (&(v639_5)).is_empty() { Space::new() } else {
          let v640_7: Space = routine_55(c, &v636_22_cursor.path()[v636_22_origin..(v636_22_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p0), &v636_22_cursor);
          compose(&(v639_5),&(v640_7))
        };
        drop(v639_5);
        let v639_9: Space = intersect(&(*CONSTANT_9),&(v639_2));
        drop(v639_2);
        let v639_10: Space = if has_head(&(v639_9)) { singleton(&[]) } else { Space::new() };
        drop(v639_9);
        let v639_12: Space = if (&(v639_10)).is_empty() { Space::new() } else {
          let mut v641_11 = Space::new();
          let mut v641_11_write = v641_11.write_zipper();
          for v641_11_byte in v636_22_cursor.child_mask().iter() {
            v636_22_cursor.descend_to_existing_byte(v641_11_byte);
            {
            let v642_2: Space = singleton(&v636_22_cursor.path()[(v636_22_origin + 2)..(v636_22_origin + 3)]);
            let v642_3: Space = intersect(&(*CONSTANT_9),&(v642_2));
            let v642_4: Space = if has_head(&(v642_3)) { singleton(&[]) } else { Space::new() };
            drop(v642_3);
            let v642_5: Space = subtract(&(*CONSTANT_0),&(v642_4));
            drop(v642_4);
            let v642_7: Space = if (&(v642_5)).is_empty() { Space::new() } else {
              let v643_6: Space = routine_57(c, &v636_22_cursor.path()[(v636_22_origin + 2)..(v636_22_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p0), &v636_22_cursor.path()[v636_22_origin..(v636_22_origin + 2)], &v636_22_cursor);
              compose(&(v642_5),&(v643_6))
            };
            drop(v642_5);
            let v642_8: Space = intersect(&(*CONSTANT_9),&(v642_2));
            drop(v642_2);
            let v642_9: Space = if has_head(&(v642_8)) { singleton(&[]) } else { Space::new() };
            drop(v642_8);
            let v642_11: Space = if (&(v642_9)).is_empty() { Space::new() } else {
              let v644_10: Space = routine_58(c, &v636_22_cursor.path()[(v636_22_origin + 2)..(v636_22_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p0), &v636_22_cursor.path()[v636_22_origin..(v636_22_origin + 2)], &v636_22_cursor);
              compose(&(v642_9),&(v644_10))
            };
            drop(v642_9);
            let v642_12: Space = unite(&(v642_7),&(v642_11));
            join_wrapped_into(&mut v641_11_write,&((v642_12).read_zipper()),&[]);
            }
            v636_22_cursor.ascend(1);
          }
          drop(v641_11_write);
          compose(&(v639_10),&(v641_11))
        };
        drop(v639_10);
        let v639_13: Space = unite(&(v639_8),&(v639_12));
        join_wrapped_into(&mut v638_6_write,&((v639_13).read_zipper()),&[]);
        }
        v636_22_cursor.ascend(1);
      }
      drop(v638_6_write);
      compose(&(v637_5),&(v638_6))
    };
    drop(v637_5);
    let v637_8: Space = intersect(&(*CONSTANT_9),&(v637_2));
    drop(v637_2);
    let v637_9: Space = if has_head(&(v637_8)) { singleton(&[]) } else { Space::new() };
    drop(v637_8);
    let v637_11: Space = if (&(v637_9)).is_empty() { Space::new() } else {
      let mut v645_10 = Space::new();
      let mut v645_10_write = v645_10.write_zipper();
      for v645_10_byte in v636_22_cursor.child_mask().iter() {
        v636_22_cursor.descend_to_existing_byte(v645_10_byte);
        {
        let v646_2: Space = singleton(&v636_22_cursor.path()[(v636_22_origin + 1)..(v636_22_origin + 2)]);
        let v646_3: Space = intersect(&(*CONSTANT_9),&(v646_2));
        let v646_4: Space = if has_head(&(v646_3)) { singleton(&[]) } else { Space::new() };
        drop(v646_3);
        let v646_5: Space = subtract(&(*CONSTANT_0),&(v646_4));
        drop(v646_4);
        let v646_7: Space = if (&(v646_5)).is_empty() { Space::new() } else {
          let v647_6: Space = routine_57(c, &v636_22_cursor.path()[(v636_22_origin + 1)..(v636_22_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p0), &v636_22_cursor.path()[v636_22_origin..(v636_22_origin + 1)], &v636_22_cursor);
          compose(&(v646_5),&(v647_6))
        };
        drop(v646_5);
        let v646_8: Space = intersect(&(*CONSTANT_9),&(v646_2));
        drop(v646_2);
        let v646_9: Space = if has_head(&(v646_8)) { singleton(&[]) } else { Space::new() };
        drop(v646_8);
        let v646_13: Space = if (&(v646_9)).is_empty() { Space::new() } else {
          let v648_11: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v636_22_cursor,(v636_22_origin + 2)),&(*CONSTANT_8))));
          let mut v648_12 = Space::new();
          let mut v648_12_write = v648_12.write_zipper();
          let mut v648_12_cursor = (v648_11).read_zipper();
          let v648_12_origin = v648_12_cursor.path().len();
          for v648_12_byte in v648_12_cursor.child_mask().iter() {
            v648_12_cursor.descend_to_existing_byte(v648_12_byte);
            {
            let v649_2: Space = singleton(&v648_12_cursor.path()[v648_12_origin..(v648_12_origin + 1)]);
            let v649_3: Space = intersect(&(*CONSTANT_9),&(v649_2));
            let v649_4: Space = if has_head(&(v649_3)) { singleton(&[]) } else { Space::new() };
            drop(v649_3);
            let v649_5: Space = subtract(&(*CONSTANT_0),&(v649_4));
            drop(v649_4);
            let v649_7: Space = if (&(v649_5)).is_empty() { Space::new() } else {
              let v650_6: Space = routine_71(c, &v648_12_cursor.path()[v648_12_origin..(v648_12_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p0), &v636_22_cursor.path()[v636_22_origin..(v636_22_origin + 1)], &v636_22_cursor.path()[(v636_22_origin + 1)..(v636_22_origin + 2)], &v648_12_cursor, &v636_22_cursor);
              compose(&(v649_5),&(v650_6))
            };
            drop(v649_5);
            let v649_8: Space = intersect(&(*CONSTANT_9),&(v649_2));
            drop(v649_2);
            let v649_9: Space = if has_head(&(v649_8)) { singleton(&[]) } else { Space::new() };
            drop(v649_8);
            let v649_11: Space = if (&(v649_9)).is_empty() { Space::new() } else {
              let v651_10: Space = routine_72(c, &v648_12_cursor.path()[v648_12_origin..(v648_12_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p0), &v636_22_cursor.path()[v636_22_origin..(v636_22_origin + 1)], &v636_22_cursor.path()[(v636_22_origin + 1)..(v636_22_origin + 2)], &v648_12_cursor, &v636_22_cursor);
              compose(&(v649_9),&(v651_10))
            };
            drop(v649_9);
            let v649_12: Space = unite(&(v649_7),&(v649_11));
            join_wrapped_into(&mut v648_12_write,&((v649_12).read_zipper()),&[]);
            }
            v648_12_cursor.ascend(1);
          }
          drop(v648_12_cursor);
          drop(v648_12_write);
          drop(v648_11);
          compose(&(v646_9),&(v648_12))
        };
        drop(v646_9);
        let v646_14: Space = unite(&(v646_7),&(v646_13));
        join_wrapped_into(&mut v645_10_write,&((v646_14).read_zipper()),&[]);
        }
        v636_22_cursor.ascend(1);
      }
      drop(v645_10_write);
      compose(&(v637_9),&(v645_10))
    };
    drop(v637_9);
    let v637_12: Space = unite(&(v637_7),&(v637_11));
    join_wrapped_into(&mut v636_22_write,&((v637_12).read_zipper()),&[]);
    }
    v636_22_cursor.ascend(1);
  }
  drop(v636_22_cursor);
  drop(v636_22_write);
  (v636_22).clone()
}

fn routine_55(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v652_17 = Space::new();
  let mut v652_17_write = v652_17.write_zipper();
  let mut v652_17_cursor = (*s0).read_zipper();
  let v652_17_origin = v652_17_cursor.path().len();
  for v652_17_byte in v652_17_cursor.child_mask().iter() {
    v652_17_cursor.descend_to_existing_byte(v652_17_byte);
    {
    let v653_2: Space = singleton(&v652_17_cursor.path()[v652_17_origin..(v652_17_origin + 1)]);
    let v653_3: Space = intersect(&(*CONSTANT_9),&(v653_2));
    let v653_4: Space = if has_head(&(v653_3)) { singleton(&[]) } else { Space::new() };
    drop(v653_3);
    let v653_5: Space = subtract(&(*CONSTANT_0),&(v653_4));
    drop(v653_4);
    let v653_8: Space = if (&(v653_5)).is_empty() { Space::new() } else {
      let v654_6: Path = concat_path(&(*p0),&v652_17_cursor.path()[v652_17_origin..(v652_17_origin + 1)]);
      let v654_7: Space = routine_55(c, &(v654_6), &(*p1), &(*p2), &(*p3), &(*p4), &v652_17_cursor);
      compose(&(v653_5),&(v654_7))
    };
    drop(v653_5);
    let v653_9: Space = intersect(&(*CONSTANT_9),&(v653_2));
    drop(v653_2);
    let v653_10: Space = if has_head(&(v653_9)) { singleton(&[]) } else { Space::new() };
    drop(v653_9);
    let v653_12: Space = if (&(v653_10)).is_empty() { Space::new() } else {
      let v655_6: Path = concat_path(&(*p0),&v652_17_cursor.path()[v652_17_origin..(v652_17_origin + 1)]);
      let mut v655_11 = Space::new();
      let mut v655_11_write = v655_11.write_zipper();
      for v655_11_byte in v652_17_cursor.child_mask().iter() {
        v652_17_cursor.descend_to_existing_byte(v655_11_byte);
        {
        let v656_2: Space = singleton(&v652_17_cursor.path()[(v652_17_origin + 1)..(v652_17_origin + 2)]);
        let v656_3: Space = intersect(&(*CONSTANT_9),&(v656_2));
        let v656_4: Space = if has_head(&(v656_3)) { singleton(&[]) } else { Space::new() };
        drop(v656_3);
        let v656_5: Space = subtract(&(*CONSTANT_0),&(v656_4));
        drop(v656_4);
        let v656_7: Space = if (&(v656_5)).is_empty() { Space::new() } else {
          let v657_6: Space = routine_57(c, &v652_17_cursor.path()[(v652_17_origin + 1)..(v652_17_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p4), &(v655_6), &v652_17_cursor);
          compose(&(v656_5),&(v657_6))
        };
        drop(v656_5);
        let v656_8: Space = intersect(&(*CONSTANT_9),&(v656_2));
        drop(v656_2);
        let v656_9: Space = if has_head(&(v656_8)) { singleton(&[]) } else { Space::new() };
        drop(v656_8);
        let v656_13: Space = if (&(v656_9)).is_empty() { Space::new() } else {
          let v658_11: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v652_17_cursor,(v652_17_origin + 2)),&(*CONSTANT_8))));
          let mut v658_12 = Space::new();
          let mut v658_12_write = v658_12.write_zipper();
          let mut v658_12_cursor = (v658_11).read_zipper();
          let v658_12_origin = v658_12_cursor.path().len();
          for v658_12_byte in v658_12_cursor.child_mask().iter() {
            v658_12_cursor.descend_to_existing_byte(v658_12_byte);
            {
            let v659_2: Space = singleton(&v658_12_cursor.path()[v658_12_origin..(v658_12_origin + 1)]);
            let v659_3: Space = intersect(&(*CONSTANT_9),&(v659_2));
            let v659_4: Space = if has_head(&(v659_3)) { singleton(&[]) } else { Space::new() };
            drop(v659_3);
            let v659_5: Space = subtract(&(*CONSTANT_0),&(v659_4));
            drop(v659_4);
            let v659_7: Space = if (&(v659_5)).is_empty() { Space::new() } else {
              let v660_6: Space = routine_71(c, &v658_12_cursor.path()[v658_12_origin..(v658_12_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p4), &(v655_6), &v652_17_cursor.path()[(v652_17_origin + 1)..(v652_17_origin + 2)], &v658_12_cursor, &v652_17_cursor);
              compose(&(v659_5),&(v660_6))
            };
            drop(v659_5);
            let v659_8: Space = intersect(&(*CONSTANT_9),&(v659_2));
            drop(v659_2);
            let v659_9: Space = if has_head(&(v659_8)) { singleton(&[]) } else { Space::new() };
            drop(v659_8);
            let v659_11: Space = if (&(v659_9)).is_empty() { Space::new() } else {
              let v661_10: Space = routine_72(c, &v658_12_cursor.path()[v658_12_origin..(v658_12_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p4), &(v655_6), &v652_17_cursor.path()[(v652_17_origin + 1)..(v652_17_origin + 2)], &v658_12_cursor, &v652_17_cursor);
              compose(&(v659_9),&(v661_10))
            };
            drop(v659_9);
            let v659_12: Space = unite(&(v659_7),&(v659_11));
            join_wrapped_into(&mut v658_12_write,&((v659_12).read_zipper()),&[]);
            }
            v658_12_cursor.ascend(1);
          }
          drop(v658_12_cursor);
          drop(v658_12_write);
          drop(v658_11);
          compose(&(v656_9),&(v658_12))
        };
        drop(v656_9);
        let v656_14: Space = unite(&(v656_7),&(v656_13));
        join_wrapped_into(&mut v655_11_write,&((v656_14).read_zipper()),&[]);
        }
        v652_17_cursor.ascend(1);
      }
      drop(v655_11_write);
      drop(v655_6);
      compose(&(v653_10),&(v655_11))
    };
    drop(v653_10);
    let v653_13: Space = unite(&(v653_8),&(v653_12));
    join_wrapped_into(&mut v652_17_write,&((v653_13).read_zipper()),&[]);
    }
    v652_17_cursor.ascend(1);
  }
  drop(v652_17_cursor);
  drop(v652_17_write);
  (v652_17).clone()
}

fn routine_56(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let v662_19: Path = concat_path(&(*p1),&(*p2));
  let v662_23: Path = concat_path(&(v662_19),&(*p3));
  drop(v662_19);
  let v662_24: Path = concat_path(&(v662_23),&(*p4));
  drop(v662_23);
  let v662_25: Path = concat_path(&(v662_24),&(*p0));
  drop(v662_24);
  let mut v662_26 = Space::new();
  let mut v662_26_write = v662_26.write_zipper();
  let mut v662_26_cursor = (*s0).read_zipper();
  let v662_26_origin = v662_26_cursor.path().len();
  for v662_26_byte in v662_26_cursor.child_mask().iter() {
    v662_26_cursor.descend_to_existing_byte(v662_26_byte);
    {
    let v663_2: Space = singleton(&v662_26_cursor.path()[v662_26_origin..(v662_26_origin + 1)]);
    let v663_3: Space = intersect(&(*CONSTANT_9),&(v663_2));
    let v663_4: Space = if has_head(&(v663_3)) { singleton(&[]) } else { Space::new() };
    drop(v663_3);
    let v663_5: Space = subtract(&(*CONSTANT_0),&(v663_4));
    drop(v663_4);
    let v663_7: Space = if (&(v663_5)).is_empty() { Space::new() } else {
      let mut v664_6 = Space::new();
      let mut v664_6_write = v664_6.write_zipper();
      for v664_6_byte in v662_26_cursor.child_mask().iter() {
        v662_26_cursor.descend_to_existing_byte(v664_6_byte);
        {
        let v665_2: Space = singleton(&v662_26_cursor.path()[(v662_26_origin + 1)..(v662_26_origin + 2)]);
        let v665_3: Space = intersect(&(*CONSTANT_9),&(v665_2));
        let v665_4: Space = if has_head(&(v665_3)) { singleton(&[]) } else { Space::new() };
        drop(v665_3);
        let v665_5: Space = subtract(&(*CONSTANT_0),&(v665_4));
        drop(v665_4);
        let v665_8: Space = if (&(v665_5)).is_empty() { Space::new() } else {
          let v666_7: Space = routine_57(c, &v662_26_cursor.path()[v662_26_origin..(v662_26_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v662_26_cursor);
          compose(&(v665_5),&(v666_7))
        };
        drop(v665_5);
        let v665_9: Space = intersect(&(*CONSTANT_9),&(v665_2));
        drop(v665_2);
        let v665_10: Space = if has_head(&(v665_9)) { singleton(&[]) } else { Space::new() };
        drop(v665_9);
        let v665_14: Space = if (&(v665_10)).is_empty() { Space::new() } else {
          let v667_12: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v662_26_cursor,(v662_26_origin + 2)),&(*CONSTANT_8))));
          let mut v667_13 = Space::new();
          let mut v667_13_write = v667_13.write_zipper();
          let mut v667_13_cursor = (v667_12).read_zipper();
          let v667_13_origin = v667_13_cursor.path().len();
          for v667_13_byte in v667_13_cursor.child_mask().iter() {
            v667_13_cursor.descend_to_existing_byte(v667_13_byte);
            {
            let v668_2: Space = singleton(&v667_13_cursor.path()[v667_13_origin..(v667_13_origin + 1)]);
            let v668_3: Space = intersect(&(*CONSTANT_9),&(v668_2));
            let v668_4: Space = if has_head(&(v668_3)) { singleton(&[]) } else { Space::new() };
            drop(v668_3);
            let v668_5: Space = subtract(&(*CONSTANT_0),&(v668_4));
            drop(v668_4);
            let v668_7: Space = if (&(v668_5)).is_empty() { Space::new() } else {
              let v669_6: Space = routine_71(c, &v667_13_cursor.path()[v667_13_origin..(v667_13_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v662_26_cursor.path()[v662_26_origin..(v662_26_origin + 2)], &v667_13_cursor, &v662_26_cursor);
              compose(&(v668_5),&(v669_6))
            };
            drop(v668_5);
            let v668_8: Space = intersect(&(*CONSTANT_9),&(v668_2));
            drop(v668_2);
            let v668_9: Space = if has_head(&(v668_8)) { singleton(&[]) } else { Space::new() };
            drop(v668_8);
            let v668_11: Space = if (&(v668_9)).is_empty() { Space::new() } else {
              let v670_10: Space = routine_72(c, &v667_13_cursor.path()[v667_13_origin..(v667_13_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v662_26_cursor.path()[v662_26_origin..(v662_26_origin + 2)], &v667_13_cursor, &v662_26_cursor);
              compose(&(v668_9),&(v670_10))
            };
            drop(v668_9);
            let v668_12: Space = unite(&(v668_7),&(v668_11));
            join_wrapped_into(&mut v667_13_write,&((v668_12).read_zipper()),&[]);
            }
            v667_13_cursor.ascend(1);
          }
          drop(v667_13_cursor);
          drop(v667_13_write);
          drop(v667_12);
          compose(&(v665_10),&(v667_13))
        };
        drop(v665_10);
        let v665_15: Space = unite(&(v665_8),&(v665_14));
        join_wrapped_into(&mut v664_6_write,&((v665_15).read_zipper()),&[]);
        }
        v662_26_cursor.ascend(1);
      }
      drop(v664_6_write);
      compose(&(v663_5),&(v664_6))
    };
    drop(v663_5);
    let v663_8: Space = intersect(&(*CONSTANT_9),&(v663_2));
    drop(v663_2);
    let v663_9: Space = if has_head(&(v663_8)) { singleton(&[]) } else { Space::new() };
    drop(v663_8);
    let v663_14: Space = if (&(v663_9)).is_empty() { Space::new() } else {
      let v671_11: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v662_26_cursor,(v662_26_origin + 1)),&(*CONSTANT_8))));
      let v671_12: Path = concat_path(&(v662_25),&v662_26_cursor.path()[v662_26_origin..(v662_26_origin + 1)]);
      let mut v671_13 = Space::new();
      let mut v671_13_write = v671_13.write_zipper();
      let mut v671_13_cursor = (v671_11).read_zipper();
      let v671_13_origin = v671_13_cursor.path().len();
      for v671_13_byte in v671_13_cursor.child_mask().iter() {
        v671_13_cursor.descend_to_existing_byte(v671_13_byte);
        {
        let v672_2: Space = singleton(&v671_13_cursor.path()[v671_13_origin..(v671_13_origin + 1)]);
        let v672_3: Space = intersect(&(*CONSTANT_9),&(v672_2));
        let v672_4: Space = if has_head(&(v672_3)) { singleton(&[]) } else { Space::new() };
        drop(v672_3);
        let v672_5: Space = subtract(&(*CONSTANT_0),&(v672_4));
        drop(v672_4);
        let v672_7: Space = if (&(v672_5)).is_empty() { Space::new() } else {
          let v673_6: Space = routine_71(c, &v671_13_cursor.path()[v671_13_origin..(v671_13_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v662_26_cursor.path()[v662_26_origin..(v662_26_origin + 1)], &v671_13_cursor, &v662_26_cursor);
          compose(&(v672_5),&(v673_6))
        };
        drop(v672_5);
        let v672_8: Space = intersect(&(*CONSTANT_9),&(v672_2));
        drop(v672_2);
        let v672_9: Space = if has_head(&(v672_8)) { singleton(&[]) } else { Space::new() };
        drop(v672_8);
        let v672_12: Space = if (&(v672_9)).is_empty() { Space::new() } else {
          let v674_10: Space = routine_1(c, &v671_13_cursor.path()[v671_13_origin..(v671_13_origin + 1)], &(*CONSTANT_8), &(*CONSTANT_2));
          let v674_11: Space = unite(&v662_26_cursor,&(v674_10));
          compose(&(v672_9),&(v674_11))
        };
        drop(v672_9);
        let v672_13: Space = wrap(&(v672_12),&(v671_12));
        let v672_14: Space = wrap(&(v672_13),&v671_13_cursor.path()[v671_13_origin..(v671_13_origin + 1)]);
        let v672_15: Space = unite(&(v672_7),&(v672_14));
        join_wrapped_into(&mut v671_13_write,&((v672_15).read_zipper()),&[]);
        }
        v671_13_cursor.ascend(1);
      }
      drop(v671_13_cursor);
      drop(v671_13_write);
      drop(v671_11);
      drop(v671_12);
      compose(&(v663_9),&(v671_13))
    };
    drop(v663_9);
    let v663_15: Space = unite(&(v663_7),&(v663_14));
    join_wrapped_into(&mut v662_26_write,&((v663_15).read_zipper()),&[]);
    }
    v662_26_cursor.ascend(1);
  }
  drop(v662_26_cursor);
  drop(v662_26_write);
  drop(v662_25);
  (v662_26).clone()
}

fn routine_57(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v675_16: Path = concat_path(&(*p1),&(*p2));
  let v675_17: Path = concat_path(&(v675_16),&(*p3));
  drop(v675_16);
  let v675_18: Path = concat_path(&(v675_17),&(*p4));
  drop(v675_17);
  let v675_19: Path = concat_path(&(v675_18),&(*p5));
  drop(v675_18);
  let mut v675_20 = Space::new();
  let mut v675_20_write = v675_20.write_zipper();
  let mut v675_20_cursor = (*s0).read_zipper();
  let v675_20_origin = v675_20_cursor.path().len();
  for v675_20_byte in v675_20_cursor.child_mask().iter() {
    v675_20_cursor.descend_to_existing_byte(v675_20_byte);
    {
    let v676_2: Space = singleton(&v675_20_cursor.path()[v675_20_origin..(v675_20_origin + 1)]);
    let v676_3: Space = intersect(&(*CONSTANT_9),&(v676_2));
    let v676_4: Space = if has_head(&(v676_3)) { singleton(&[]) } else { Space::new() };
    drop(v676_3);
    let v676_5: Space = subtract(&(*CONSTANT_0),&(v676_4));
    drop(v676_4);
    let v676_8: Space = if (&(v676_5)).is_empty() { Space::new() } else {
      let v677_6: Path = concat_path(&(*p0),&v675_20_cursor.path()[v675_20_origin..(v675_20_origin + 1)]);
      let v677_7: Space = routine_57(c, &(v677_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &v675_20_cursor);
      compose(&(v676_5),&(v677_7))
    };
    drop(v676_5);
    let v676_9: Space = intersect(&(*CONSTANT_9),&(v676_2));
    drop(v676_2);
    let v676_10: Space = if has_head(&(v676_9)) { singleton(&[]) } else { Space::new() };
    drop(v676_9);
    let v676_15: Space = if (&(v676_10)).is_empty() { Space::new() } else {
      let v678_6: Path = concat_path(&(*p0),&v675_20_cursor.path()[v675_20_origin..(v675_20_origin + 1)]);
      let v678_12: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v675_20_cursor,(v675_20_origin + 1)),&(*CONSTANT_8))));
      let v678_13: Path = concat_path(&(v675_19),&(v678_6));
      let mut v678_14 = Space::new();
      let mut v678_14_write = v678_14.write_zipper();
      let mut v678_14_cursor = (v678_12).read_zipper();
      let v678_14_origin = v678_14_cursor.path().len();
      for v678_14_byte in v678_14_cursor.child_mask().iter() {
        v678_14_cursor.descend_to_existing_byte(v678_14_byte);
        {
        let v679_2: Space = singleton(&v678_14_cursor.path()[v678_14_origin..(v678_14_origin + 1)]);
        let v679_3: Space = intersect(&(*CONSTANT_9),&(v679_2));
        let v679_4: Space = if has_head(&(v679_3)) { singleton(&[]) } else { Space::new() };
        drop(v679_3);
        let v679_5: Space = subtract(&(*CONSTANT_0),&(v679_4));
        drop(v679_4);
        let v679_7: Space = if (&(v679_5)).is_empty() { Space::new() } else {
          let v680_6: Space = routine_71(c, &v678_14_cursor.path()[v678_14_origin..(v678_14_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v678_6), &v678_14_cursor, &v675_20_cursor);
          compose(&(v679_5),&(v680_6))
        };
        drop(v679_5);
        let v679_8: Space = intersect(&(*CONSTANT_9),&(v679_2));
        drop(v679_2);
        let v679_9: Space = if has_head(&(v679_8)) { singleton(&[]) } else { Space::new() };
        drop(v679_8);
        let v679_12: Space = if (&(v679_9)).is_empty() { Space::new() } else {
          let v681_10: Space = routine_1(c, &v678_14_cursor.path()[v678_14_origin..(v678_14_origin + 1)], &(*CONSTANT_8), &(*CONSTANT_2));
          let v681_11: Space = unite(&v675_20_cursor,&(v681_10));
          compose(&(v679_9),&(v681_11))
        };
        drop(v679_9);
        let v679_13: Space = wrap(&(v679_12),&(v678_13));
        let v679_14: Space = wrap(&(v679_13),&v678_14_cursor.path()[v678_14_origin..(v678_14_origin + 1)]);
        let v679_15: Space = unite(&(v679_7),&(v679_14));
        join_wrapped_into(&mut v678_14_write,&((v679_15).read_zipper()),&[]);
        }
        v678_14_cursor.ascend(1);
      }
      drop(v678_14_cursor);
      drop(v678_14_write);
      drop(v678_6);
      drop(v678_12);
      drop(v678_13);
      compose(&(v676_10),&(v678_14))
    };
    drop(v676_10);
    let v676_16: Space = unite(&(v676_8),&(v676_15));
    join_wrapped_into(&mut v675_20_write,&((v676_16).read_zipper()),&[]);
    }
    v675_20_cursor.ascend(1);
  }
  drop(v675_20_cursor);
  drop(v675_20_write);
  drop(v675_19);
  (v675_20).clone()
}

fn routine_58(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v682_10: Space = subtract(&(*CONSTANT_10),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_8))));
  let v682_32: Path = concat_path(&(*p1),&(*p2));
  let v682_33: Path = concat_path(&(v682_32),&(*p3));
  drop(v682_32);
  let v682_34: Path = concat_path(&(v682_33),&(*p4));
  drop(v682_33);
  let v682_35: Path = concat_path(&(v682_34),&(*p5));
  drop(v682_34);
  let v682_36: Path = concat_path(&(v682_35),&(*p0));
  drop(v682_35);
  let mut v682_41 = Space::new();
  let mut v682_41_write = v682_41.write_zipper();
  let mut v682_41_cursor = (v682_10).read_zipper();
  let v682_41_origin = v682_41_cursor.path().len();
  for v682_41_byte in v682_41_cursor.child_mask().iter() {
    v682_41_cursor.descend_to_existing_byte(v682_41_byte);
    {
    let v683_2: Space = singleton(&v682_41_cursor.path()[v682_41_origin..(v682_41_origin + 1)]);
    let v683_3: Space = intersect(&(*CONSTANT_9),&(v683_2));
    let v683_4: Space = if has_head(&(v683_3)) { singleton(&[]) } else { Space::new() };
    drop(v683_3);
    let v683_5: Space = subtract(&(*CONSTANT_0),&(v683_4));
    drop(v683_4);
    let v683_7: Space = if (&(v683_5)).is_empty() { Space::new() } else {
      let mut v684_6 = Space::new();
      let mut v684_6_write = v684_6.write_zipper();
      for v684_6_byte in v682_41_cursor.child_mask().iter() {
        v682_41_cursor.descend_to_existing_byte(v684_6_byte);
        {
        let v685_2: Space = singleton(&v682_41_cursor.path()[(v682_41_origin + 1)..(v682_41_origin + 2)]);
        let v685_3: Space = intersect(&(*CONSTANT_9),&(v685_2));
        let v685_4: Space = if has_head(&(v685_3)) { singleton(&[]) } else { Space::new() };
        drop(v685_3);
        let v685_5: Space = subtract(&(*CONSTANT_0),&(v685_4));
        drop(v685_4);
        let v685_8: Space = if (&(v685_5)).is_empty() { Space::new() } else {
          let v686_7: Space = routine_71(c, &v682_41_cursor.path()[v682_41_origin..(v682_41_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v682_41_cursor, &(*s0));
          compose(&(v685_5),&(v686_7))
        };
        drop(v685_5);
        let v685_9: Space = intersect(&(*CONSTANT_9),&(v685_2));
        drop(v685_2);
        let v685_10: Space = if has_head(&(v685_9)) { singleton(&[]) } else { Space::new() };
        drop(v685_9);
        let v685_13: Space = if (&(v685_10)).is_empty() { Space::new() } else {
          let v687_11: Space = routine_1(c, &v682_41_cursor.path()[v682_41_origin..(v682_41_origin + 2)], &(*CONSTANT_8), &(*CONSTANT_2));
          let v687_12: Space = unite(&(*s0),&(v687_11));
          compose(&(v685_10),&(v687_12))
        };
        drop(v685_10);
        let v685_14: Space = wrap(&(v685_13),&(v682_36));
        let v685_15: Space = wrap(&(v685_14),&v682_41_cursor.path()[v682_41_origin..(v682_41_origin + 2)]);
        let v685_16: Space = unite(&(v685_8),&(v685_15));
        join_wrapped_into(&mut v684_6_write,&((v685_16).read_zipper()),&[]);
        }
        v682_41_cursor.ascend(1);
      }
      drop(v684_6_write);
      compose(&(v683_5),&(v684_6))
    };
    drop(v683_5);
    let v683_8: Space = intersect(&(*CONSTANT_9),&(v683_2));
    drop(v683_2);
    let v683_9: Space = if has_head(&(v683_8)) { singleton(&[]) } else { Space::new() };
    drop(v683_8);
    let v683_28: Space = if (&(v683_9)).is_empty() { Space::new() } else {
      let v689_25: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v690_10: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_8), &v682_41_cursor.path()[v682_41_origin..(v682_41_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v690_11: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_8), &v682_41_cursor.path()[v682_41_origin..(v682_41_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v690_12: Space = unite(&(v690_10),&(v690_11));
        let v690_13: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_8), &v682_41_cursor.path()[v682_41_origin..(v682_41_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v690_14: Space = unite(&(v690_12),&(v690_13));
        let v690_15: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_8), &v682_41_cursor.path()[v682_41_origin..(v682_41_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v690_16: Space = unite(&(v690_14),&(v690_15));
        let v690_17: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_8), &v682_41_cursor.path()[v682_41_origin..(v682_41_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v690_18: Space = unite(&(v690_16),&(v690_17));
        let v690_19: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_8), &v682_41_cursor.path()[v682_41_origin..(v682_41_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v690_20: Space = unite(&(v690_18),&(v690_19));
        let v690_21: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_8), &v682_41_cursor.path()[v682_41_origin..(v682_41_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v690_22: Space = unite(&(v690_20),&(v690_21));
        let v690_23: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_8), &v682_41_cursor.path()[v682_41_origin..(v682_41_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v690_24: Space = unite(&(v690_22),&(v690_23));
        compose(&(*CONSTANT_0),&(v690_24))
      };
      let v689_26: Space = intersect(&(v689_25),&(*CONSTANT_21));
      let v689_27: Space = unite(&(v689_26),&(*s0));
      compose(&(v683_9),&(v689_27))
    };
    drop(v683_9);
    let v683_29: Space = wrap(&(v683_28),&(v682_36));
    let v683_30: Space = wrap(&(v683_29),&v682_41_cursor.path()[v682_41_origin..(v682_41_origin + 1)]);
    let v683_31: Space = unite(&(v683_7),&(v683_30));
    join_wrapped_into(&mut v682_41_write,&((v683_31).read_zipper()),&[]);
    }
    v682_41_cursor.ascend(1);
  }
  drop(v682_41_cursor);
  drop(v682_41_write);
  drop(v682_10);
  drop(v682_36);
  (v682_41).clone()
}

fn routine_59(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v691_14 = Space::new();
  let mut v691_14_write = v691_14.write_zipper();
  let mut v691_14_cursor = (*s0).read_zipper();
  let v691_14_origin = v691_14_cursor.path().len();
  for v691_14_byte in v691_14_cursor.child_mask().iter() {
    v691_14_cursor.descend_to_existing_byte(v691_14_byte);
    {
    let v692_2: Space = singleton(&v691_14_cursor.path()[v691_14_origin..(v691_14_origin + 1)]);
    let v692_3: Space = intersect(&(*CONSTANT_9),&(v692_2));
    let v692_4: Space = if has_head(&(v692_3)) { singleton(&[]) } else { Space::new() };
    drop(v692_3);
    let v692_5: Space = subtract(&(*CONSTANT_0),&(v692_4));
    drop(v692_4);
    let v692_8: Space = if (&(v692_5)).is_empty() { Space::new() } else {
      let v693_6: Path = concat_path(&(*p0),&v691_14_cursor.path()[v691_14_origin..(v691_14_origin + 1)]);
      let v693_7: Space = routine_59(c, &(v693_6), &(*p1), &(*p2), &(*p3), &v691_14_cursor);
      compose(&(v692_5),&(v693_7))
    };
    drop(v692_5);
    let v692_9: Space = intersect(&(*CONSTANT_9),&(v692_2));
    drop(v692_2);
    let v692_10: Space = if has_head(&(v692_9)) { singleton(&[]) } else { Space::new() };
    drop(v692_9);
    let v692_12: Space = if (&(v692_10)).is_empty() { Space::new() } else {
      let v694_6: Path = concat_path(&(*p0),&v691_14_cursor.path()[v691_14_origin..(v691_14_origin + 1)]);
      let mut v694_11 = Space::new();
      let mut v694_11_write = v694_11.write_zipper();
      for v694_11_byte in v691_14_cursor.child_mask().iter() {
        v691_14_cursor.descend_to_existing_byte(v694_11_byte);
        {
        let v695_2: Space = singleton(&v691_14_cursor.path()[(v691_14_origin + 1)..(v691_14_origin + 2)]);
        let v695_3: Space = intersect(&(*CONSTANT_9),&(v695_2));
        let v695_4: Space = if has_head(&(v695_3)) { singleton(&[]) } else { Space::new() };
        drop(v695_3);
        let v695_5: Space = subtract(&(*CONSTANT_0),&(v695_4));
        drop(v695_4);
        let v695_7: Space = if (&(v695_5)).is_empty() { Space::new() } else {
          let v696_6: Space = routine_61(c, &v691_14_cursor.path()[(v691_14_origin + 1)..(v691_14_origin + 2)], &(*p1), &(*p2), &(*p3), &(v694_6), &v691_14_cursor);
          compose(&(v695_5),&(v696_6))
        };
        drop(v695_5);
        let v695_8: Space = intersect(&(*CONSTANT_9),&(v695_2));
        drop(v695_2);
        let v695_9: Space = if has_head(&(v695_8)) { singleton(&[]) } else { Space::new() };
        drop(v695_8);
        let v695_11: Space = if (&(v695_9)).is_empty() { Space::new() } else {
          let mut v697_10 = Space::new();
          let mut v697_10_write = v697_10.write_zipper();
          for v697_10_byte in v691_14_cursor.child_mask().iter() {
            v691_14_cursor.descend_to_existing_byte(v697_10_byte);
            {
            let v698_2: Space = singleton(&v691_14_cursor.path()[(v691_14_origin + 2)..(v691_14_origin + 3)]);
            let v698_3: Space = intersect(&(*CONSTANT_9),&(v698_2));
            let v698_4: Space = if has_head(&(v698_3)) { singleton(&[]) } else { Space::new() };
            drop(v698_3);
            let v698_5: Space = subtract(&(*CONSTANT_0),&(v698_4));
            drop(v698_4);
            let v698_7: Space = if (&(v698_5)).is_empty() { Space::new() } else {
              let v699_6: Space = routine_63(c, &v691_14_cursor.path()[(v691_14_origin + 2)..(v691_14_origin + 3)], &(*p1), &(*p2), &(*p3), &(v694_6), &v691_14_cursor.path()[(v691_14_origin + 1)..(v691_14_origin + 2)], &v691_14_cursor);
              compose(&(v698_5),&(v699_6))
            };
            drop(v698_5);
            let v698_8: Space = intersect(&(*CONSTANT_9),&(v698_2));
            drop(v698_2);
            let v698_9: Space = if has_head(&(v698_8)) { singleton(&[]) } else { Space::new() };
            drop(v698_8);
            let v698_11: Space = if (&(v698_9)).is_empty() { Space::new() } else {
              let v700_10: Space = routine_64(c, &v691_14_cursor.path()[(v691_14_origin + 2)..(v691_14_origin + 3)], &(*p1), &(*p2), &(*p3), &(v694_6), &v691_14_cursor.path()[(v691_14_origin + 1)..(v691_14_origin + 2)], &v691_14_cursor);
              compose(&(v698_9),&(v700_10))
            };
            drop(v698_9);
            let v698_12: Space = unite(&(v698_7),&(v698_11));
            join_wrapped_into(&mut v697_10_write,&((v698_12).read_zipper()),&[]);
            }
            v691_14_cursor.ascend(1);
          }
          drop(v697_10_write);
          compose(&(v695_9),&(v697_10))
        };
        drop(v695_9);
        let v695_12: Space = unite(&(v695_7),&(v695_11));
        join_wrapped_into(&mut v694_11_write,&((v695_12).read_zipper()),&[]);
        }
        v691_14_cursor.ascend(1);
      }
      drop(v694_11_write);
      drop(v694_6);
      compose(&(v692_10),&(v694_11))
    };
    drop(v692_10);
    let v692_13: Space = unite(&(v692_8),&(v692_12));
    join_wrapped_into(&mut v691_14_write,&((v692_13).read_zipper()),&[]);
    }
    v691_14_cursor.ascend(1);
  }
  drop(v691_14_cursor);
  drop(v691_14_write);
  (v691_14).clone()
}

fn routine_60(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v701_20 = Space::new();
  let mut v701_20_write = v701_20.write_zipper();
  let mut v701_20_cursor = (*s0).read_zipper();
  let v701_20_origin = v701_20_cursor.path().len();
  for v701_20_byte in v701_20_cursor.child_mask().iter() {
    v701_20_cursor.descend_to_existing_byte(v701_20_byte);
    {
    let v702_2: Space = singleton(&v701_20_cursor.path()[v701_20_origin..(v701_20_origin + 1)]);
    let v702_3: Space = intersect(&(*CONSTANT_9),&(v702_2));
    let v702_4: Space = if has_head(&(v702_3)) { singleton(&[]) } else { Space::new() };
    drop(v702_3);
    let v702_5: Space = subtract(&(*CONSTANT_0),&(v702_4));
    drop(v702_4);
    let v702_7: Space = if (&(v702_5)).is_empty() { Space::new() } else {
      let mut v703_6 = Space::new();
      let mut v703_6_write = v703_6.write_zipper();
      for v703_6_byte in v701_20_cursor.child_mask().iter() {
        v701_20_cursor.descend_to_existing_byte(v703_6_byte);
        {
        let v704_2: Space = singleton(&v701_20_cursor.path()[(v701_20_origin + 1)..(v701_20_origin + 2)]);
        let v704_3: Space = intersect(&(*CONSTANT_9),&(v704_2));
        let v704_4: Space = if has_head(&(v704_3)) { singleton(&[]) } else { Space::new() };
        drop(v704_3);
        let v704_5: Space = subtract(&(*CONSTANT_0),&(v704_4));
        drop(v704_4);
        let v704_8: Space = if (&(v704_5)).is_empty() { Space::new() } else {
          let v705_7: Space = routine_61(c, &v701_20_cursor.path()[v701_20_origin..(v701_20_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p0), &v701_20_cursor);
          compose(&(v704_5),&(v705_7))
        };
        drop(v704_5);
        let v704_9: Space = intersect(&(*CONSTANT_9),&(v704_2));
        drop(v704_2);
        let v704_10: Space = if has_head(&(v704_9)) { singleton(&[]) } else { Space::new() };
        drop(v704_9);
        let v704_12: Space = if (&(v704_10)).is_empty() { Space::new() } else {
          let mut v706_11 = Space::new();
          let mut v706_11_write = v706_11.write_zipper();
          for v706_11_byte in v701_20_cursor.child_mask().iter() {
            v701_20_cursor.descend_to_existing_byte(v706_11_byte);
            {
            let v707_2: Space = singleton(&v701_20_cursor.path()[(v701_20_origin + 2)..(v701_20_origin + 3)]);
            let v707_3: Space = intersect(&(*CONSTANT_9),&(v707_2));
            let v707_4: Space = if has_head(&(v707_3)) { singleton(&[]) } else { Space::new() };
            drop(v707_3);
            let v707_5: Space = subtract(&(*CONSTANT_0),&(v707_4));
            drop(v707_4);
            let v707_7: Space = if (&(v707_5)).is_empty() { Space::new() } else {
              let v708_6: Space = routine_63(c, &v701_20_cursor.path()[(v701_20_origin + 2)..(v701_20_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p0), &v701_20_cursor.path()[v701_20_origin..(v701_20_origin + 2)], &v701_20_cursor);
              compose(&(v707_5),&(v708_6))
            };
            drop(v707_5);
            let v707_8: Space = intersect(&(*CONSTANT_9),&(v707_2));
            drop(v707_2);
            let v707_9: Space = if has_head(&(v707_8)) { singleton(&[]) } else { Space::new() };
            drop(v707_8);
            let v707_11: Space = if (&(v707_9)).is_empty() { Space::new() } else {
              let v709_10: Space = routine_64(c, &v701_20_cursor.path()[(v701_20_origin + 2)..(v701_20_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p0), &v701_20_cursor.path()[v701_20_origin..(v701_20_origin + 2)], &v701_20_cursor);
              compose(&(v707_9),&(v709_10))
            };
            drop(v707_9);
            let v707_12: Space = unite(&(v707_7),&(v707_11));
            join_wrapped_into(&mut v706_11_write,&((v707_12).read_zipper()),&[]);
            }
            v701_20_cursor.ascend(1);
          }
          drop(v706_11_write);
          compose(&(v704_10),&(v706_11))
        };
        drop(v704_10);
        let v704_13: Space = unite(&(v704_8),&(v704_12));
        join_wrapped_into(&mut v703_6_write,&((v704_13).read_zipper()),&[]);
        }
        v701_20_cursor.ascend(1);
      }
      drop(v703_6_write);
      compose(&(v702_5),&(v703_6))
    };
    drop(v702_5);
    let v702_8: Space = intersect(&(*CONSTANT_9),&(v702_2));
    drop(v702_2);
    let v702_9: Space = if has_head(&(v702_8)) { singleton(&[]) } else { Space::new() };
    drop(v702_8);
    let v702_11: Space = if (&(v702_9)).is_empty() { Space::new() } else {
      let mut v710_10 = Space::new();
      let mut v710_10_write = v710_10.write_zipper();
      for v710_10_byte in v701_20_cursor.child_mask().iter() {
        v701_20_cursor.descend_to_existing_byte(v710_10_byte);
        {
        let v711_2: Space = singleton(&v701_20_cursor.path()[(v701_20_origin + 1)..(v701_20_origin + 2)]);
        let v711_3: Space = intersect(&(*CONSTANT_9),&(v711_2));
        let v711_4: Space = if has_head(&(v711_3)) { singleton(&[]) } else { Space::new() };
        drop(v711_3);
        let v711_5: Space = subtract(&(*CONSTANT_0),&(v711_4));
        drop(v711_4);
        let v711_7: Space = if (&(v711_5)).is_empty() { Space::new() } else {
          let v712_6: Space = routine_63(c, &v701_20_cursor.path()[(v701_20_origin + 1)..(v701_20_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p0), &v701_20_cursor.path()[v701_20_origin..(v701_20_origin + 1)], &v701_20_cursor);
          compose(&(v711_5),&(v712_6))
        };
        drop(v711_5);
        let v711_8: Space = intersect(&(*CONSTANT_9),&(v711_2));
        drop(v711_2);
        let v711_9: Space = if has_head(&(v711_8)) { singleton(&[]) } else { Space::new() };
        drop(v711_8);
        let v711_11: Space = if (&(v711_9)).is_empty() { Space::new() } else {
          let mut v713_10 = Space::new();
          let mut v713_10_write = v713_10.write_zipper();
          for v713_10_byte in v701_20_cursor.child_mask().iter() {
            v701_20_cursor.descend_to_existing_byte(v713_10_byte);
            {
            let v714_2: Space = singleton(&v701_20_cursor.path()[(v701_20_origin + 2)..(v701_20_origin + 3)]);
            let v714_3: Space = intersect(&(*CONSTANT_9),&(v714_2));
            let v714_4: Space = if has_head(&(v714_3)) { singleton(&[]) } else { Space::new() };
            drop(v714_3);
            let v714_5: Space = subtract(&(*CONSTANT_0),&(v714_4));
            drop(v714_4);
            let v714_7: Space = if (&(v714_5)).is_empty() { Space::new() } else {
              let v715_6: Space = routine_73(c, &v701_20_cursor.path()[(v701_20_origin + 2)..(v701_20_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p0), &v701_20_cursor.path()[v701_20_origin..(v701_20_origin + 1)], &v701_20_cursor.path()[(v701_20_origin + 1)..(v701_20_origin + 2)], &v701_20_cursor);
              compose(&(v714_5),&(v715_6))
            };
            drop(v714_5);
            let v714_8: Space = intersect(&(*CONSTANT_9),&(v714_2));
            drop(v714_2);
            let v714_9: Space = if has_head(&(v714_8)) { singleton(&[]) } else { Space::new() };
            drop(v714_8);
            let v714_11: Space = if (&(v714_9)).is_empty() { Space::new() } else {
              let v716_10: Space = routine_74(c, &v701_20_cursor.path()[(v701_20_origin + 2)..(v701_20_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p0), &v701_20_cursor.path()[v701_20_origin..(v701_20_origin + 1)], &v701_20_cursor.path()[(v701_20_origin + 1)..(v701_20_origin + 2)], &v701_20_cursor);
              compose(&(v714_9),&(v716_10))
            };
            drop(v714_9);
            let v714_12: Space = unite(&(v714_7),&(v714_11));
            join_wrapped_into(&mut v713_10_write,&((v714_12).read_zipper()),&[]);
            }
            v701_20_cursor.ascend(1);
          }
          drop(v713_10_write);
          compose(&(v711_9),&(v713_10))
        };
        drop(v711_9);
        let v711_12: Space = unite(&(v711_7),&(v711_11));
        join_wrapped_into(&mut v710_10_write,&((v711_12).read_zipper()),&[]);
        }
        v701_20_cursor.ascend(1);
      }
      drop(v710_10_write);
      compose(&(v702_9),&(v710_10))
    };
    drop(v702_9);
    let v702_12: Space = unite(&(v702_7),&(v702_11));
    join_wrapped_into(&mut v701_20_write,&((v702_12).read_zipper()),&[]);
    }
    v701_20_cursor.ascend(1);
  }
  drop(v701_20_cursor);
  drop(v701_20_write);
  (v701_20).clone()
}

fn routine_61(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v717_15 = Space::new();
  let mut v717_15_write = v717_15.write_zipper();
  let mut v717_15_cursor = (*s0).read_zipper();
  let v717_15_origin = v717_15_cursor.path().len();
  for v717_15_byte in v717_15_cursor.child_mask().iter() {
    v717_15_cursor.descend_to_existing_byte(v717_15_byte);
    {
    let v718_2: Space = singleton(&v717_15_cursor.path()[v717_15_origin..(v717_15_origin + 1)]);
    let v718_3: Space = intersect(&(*CONSTANT_9),&(v718_2));
    let v718_4: Space = if has_head(&(v718_3)) { singleton(&[]) } else { Space::new() };
    drop(v718_3);
    let v718_5: Space = subtract(&(*CONSTANT_0),&(v718_4));
    drop(v718_4);
    let v718_8: Space = if (&(v718_5)).is_empty() { Space::new() } else {
      let v719_6: Path = concat_path(&(*p0),&v717_15_cursor.path()[v717_15_origin..(v717_15_origin + 1)]);
      let v719_7: Space = routine_61(c, &(v719_6), &(*p1), &(*p2), &(*p3), &(*p4), &v717_15_cursor);
      compose(&(v718_5),&(v719_7))
    };
    drop(v718_5);
    let v718_9: Space = intersect(&(*CONSTANT_9),&(v718_2));
    drop(v718_2);
    let v718_10: Space = if has_head(&(v718_9)) { singleton(&[]) } else { Space::new() };
    drop(v718_9);
    let v718_12: Space = if (&(v718_10)).is_empty() { Space::new() } else {
      let v720_6: Path = concat_path(&(*p0),&v717_15_cursor.path()[v717_15_origin..(v717_15_origin + 1)]);
      let mut v720_11 = Space::new();
      let mut v720_11_write = v720_11.write_zipper();
      for v720_11_byte in v717_15_cursor.child_mask().iter() {
        v717_15_cursor.descend_to_existing_byte(v720_11_byte);
        {
        let v721_2: Space = singleton(&v717_15_cursor.path()[(v717_15_origin + 1)..(v717_15_origin + 2)]);
        let v721_3: Space = intersect(&(*CONSTANT_9),&(v721_2));
        let v721_4: Space = if has_head(&(v721_3)) { singleton(&[]) } else { Space::new() };
        drop(v721_3);
        let v721_5: Space = subtract(&(*CONSTANT_0),&(v721_4));
        drop(v721_4);
        let v721_7: Space = if (&(v721_5)).is_empty() { Space::new() } else {
          let v722_6: Space = routine_63(c, &v717_15_cursor.path()[(v717_15_origin + 1)..(v717_15_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p4), &(v720_6), &v717_15_cursor);
          compose(&(v721_5),&(v722_6))
        };
        drop(v721_5);
        let v721_8: Space = intersect(&(*CONSTANT_9),&(v721_2));
        drop(v721_2);
        let v721_9: Space = if has_head(&(v721_8)) { singleton(&[]) } else { Space::new() };
        drop(v721_8);
        let v721_11: Space = if (&(v721_9)).is_empty() { Space::new() } else {
          let mut v723_10 = Space::new();
          let mut v723_10_write = v723_10.write_zipper();
          for v723_10_byte in v717_15_cursor.child_mask().iter() {
            v717_15_cursor.descend_to_existing_byte(v723_10_byte);
            {
            let v724_2: Space = singleton(&v717_15_cursor.path()[(v717_15_origin + 2)..(v717_15_origin + 3)]);
            let v724_3: Space = intersect(&(*CONSTANT_9),&(v724_2));
            let v724_4: Space = if has_head(&(v724_3)) { singleton(&[]) } else { Space::new() };
            drop(v724_3);
            let v724_5: Space = subtract(&(*CONSTANT_0),&(v724_4));
            drop(v724_4);
            let v724_7: Space = if (&(v724_5)).is_empty() { Space::new() } else {
              let v725_6: Space = routine_73(c, &v717_15_cursor.path()[(v717_15_origin + 2)..(v717_15_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p4), &(v720_6), &v717_15_cursor.path()[(v717_15_origin + 1)..(v717_15_origin + 2)], &v717_15_cursor);
              compose(&(v724_5),&(v725_6))
            };
            drop(v724_5);
            let v724_8: Space = intersect(&(*CONSTANT_9),&(v724_2));
            drop(v724_2);
            let v724_9: Space = if has_head(&(v724_8)) { singleton(&[]) } else { Space::new() };
            drop(v724_8);
            let v724_11: Space = if (&(v724_9)).is_empty() { Space::new() } else {
              let v726_10: Space = routine_74(c, &v717_15_cursor.path()[(v717_15_origin + 2)..(v717_15_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p4), &(v720_6), &v717_15_cursor.path()[(v717_15_origin + 1)..(v717_15_origin + 2)], &v717_15_cursor);
              compose(&(v724_9),&(v726_10))
            };
            drop(v724_9);
            let v724_12: Space = unite(&(v724_7),&(v724_11));
            join_wrapped_into(&mut v723_10_write,&((v724_12).read_zipper()),&[]);
            }
            v717_15_cursor.ascend(1);
          }
          drop(v723_10_write);
          compose(&(v721_9),&(v723_10))
        };
        drop(v721_9);
        let v721_12: Space = unite(&(v721_7),&(v721_11));
        join_wrapped_into(&mut v720_11_write,&((v721_12).read_zipper()),&[]);
        }
        v717_15_cursor.ascend(1);
      }
      drop(v720_11_write);
      drop(v720_6);
      compose(&(v718_10),&(v720_11))
    };
    drop(v718_10);
    let v718_13: Space = unite(&(v718_8),&(v718_12));
    join_wrapped_into(&mut v717_15_write,&((v718_13).read_zipper()),&[]);
    }
    v717_15_cursor.ascend(1);
  }
  drop(v717_15_cursor);
  drop(v717_15_write);
  (v717_15).clone()
}

fn routine_62(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v727_23 = Space::new();
  let mut v727_23_write = v727_23.write_zipper();
  let mut v727_23_cursor = (*s0).read_zipper();
  let v727_23_origin = v727_23_cursor.path().len();
  for v727_23_byte in v727_23_cursor.child_mask().iter() {
    v727_23_cursor.descend_to_existing_byte(v727_23_byte);
    {
    let v728_2: Space = singleton(&v727_23_cursor.path()[v727_23_origin..(v727_23_origin + 1)]);
    let v728_3: Space = intersect(&(*CONSTANT_9),&(v728_2));
    let v728_4: Space = if has_head(&(v728_3)) { singleton(&[]) } else { Space::new() };
    drop(v728_3);
    let v728_5: Space = subtract(&(*CONSTANT_0),&(v728_4));
    drop(v728_4);
    let v728_7: Space = if (&(v728_5)).is_empty() { Space::new() } else {
      let mut v729_6 = Space::new();
      let mut v729_6_write = v729_6.write_zipper();
      for v729_6_byte in v727_23_cursor.child_mask().iter() {
        v727_23_cursor.descend_to_existing_byte(v729_6_byte);
        {
        let v730_2: Space = singleton(&v727_23_cursor.path()[(v727_23_origin + 1)..(v727_23_origin + 2)]);
        let v730_3: Space = intersect(&(*CONSTANT_9),&(v730_2));
        let v730_4: Space = if has_head(&(v730_3)) { singleton(&[]) } else { Space::new() };
        drop(v730_3);
        let v730_5: Space = subtract(&(*CONSTANT_0),&(v730_4));
        drop(v730_4);
        let v730_8: Space = if (&(v730_5)).is_empty() { Space::new() } else {
          let v731_7: Space = routine_63(c, &v727_23_cursor.path()[v727_23_origin..(v727_23_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v727_23_cursor);
          compose(&(v730_5),&(v731_7))
        };
        drop(v730_5);
        let v730_9: Space = intersect(&(*CONSTANT_9),&(v730_2));
        drop(v730_2);
        let v730_10: Space = if has_head(&(v730_9)) { singleton(&[]) } else { Space::new() };
        drop(v730_9);
        let v730_12: Space = if (&(v730_10)).is_empty() { Space::new() } else {
          let mut v732_11 = Space::new();
          let mut v732_11_write = v732_11.write_zipper();
          for v732_11_byte in v727_23_cursor.child_mask().iter() {
            v727_23_cursor.descend_to_existing_byte(v732_11_byte);
            {
            let v733_2: Space = singleton(&v727_23_cursor.path()[(v727_23_origin + 2)..(v727_23_origin + 3)]);
            let v733_3: Space = intersect(&(*CONSTANT_9),&(v733_2));
            let v733_4: Space = if has_head(&(v733_3)) { singleton(&[]) } else { Space::new() };
            drop(v733_3);
            let v733_5: Space = subtract(&(*CONSTANT_0),&(v733_4));
            drop(v733_4);
            let v733_7: Space = if (&(v733_5)).is_empty() { Space::new() } else {
              let v734_6: Space = routine_73(c, &v727_23_cursor.path()[(v727_23_origin + 2)..(v727_23_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v727_23_cursor.path()[v727_23_origin..(v727_23_origin + 2)], &v727_23_cursor);
              compose(&(v733_5),&(v734_6))
            };
            drop(v733_5);
            let v733_8: Space = intersect(&(*CONSTANT_9),&(v733_2));
            drop(v733_2);
            let v733_9: Space = if has_head(&(v733_8)) { singleton(&[]) } else { Space::new() };
            drop(v733_8);
            let v733_11: Space = if (&(v733_9)).is_empty() { Space::new() } else {
              let v735_10: Space = routine_74(c, &v727_23_cursor.path()[(v727_23_origin + 2)..(v727_23_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v727_23_cursor.path()[v727_23_origin..(v727_23_origin + 2)], &v727_23_cursor);
              compose(&(v733_9),&(v735_10))
            };
            drop(v733_9);
            let v733_12: Space = unite(&(v733_7),&(v733_11));
            join_wrapped_into(&mut v732_11_write,&((v733_12).read_zipper()),&[]);
            }
            v727_23_cursor.ascend(1);
          }
          drop(v732_11_write);
          compose(&(v730_10),&(v732_11))
        };
        drop(v730_10);
        let v730_13: Space = unite(&(v730_8),&(v730_12));
        join_wrapped_into(&mut v729_6_write,&((v730_13).read_zipper()),&[]);
        }
        v727_23_cursor.ascend(1);
      }
      drop(v729_6_write);
      compose(&(v728_5),&(v729_6))
    };
    drop(v728_5);
    let v728_8: Space = intersect(&(*CONSTANT_9),&(v728_2));
    drop(v728_2);
    let v728_9: Space = if has_head(&(v728_8)) { singleton(&[]) } else { Space::new() };
    drop(v728_8);
    let v728_11: Space = if (&(v728_9)).is_empty() { Space::new() } else {
      let mut v736_10 = Space::new();
      let mut v736_10_write = v736_10.write_zipper();
      for v736_10_byte in v727_23_cursor.child_mask().iter() {
        v727_23_cursor.descend_to_existing_byte(v736_10_byte);
        {
        let v737_2: Space = singleton(&v727_23_cursor.path()[(v727_23_origin + 1)..(v727_23_origin + 2)]);
        let v737_3: Space = intersect(&(*CONSTANT_9),&(v737_2));
        let v737_4: Space = if has_head(&(v737_3)) { singleton(&[]) } else { Space::new() };
        drop(v737_3);
        let v737_5: Space = subtract(&(*CONSTANT_0),&(v737_4));
        drop(v737_4);
        let v737_7: Space = if (&(v737_5)).is_empty() { Space::new() } else {
          let v738_6: Space = routine_73(c, &v727_23_cursor.path()[(v727_23_origin + 1)..(v727_23_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v727_23_cursor.path()[v727_23_origin..(v727_23_origin + 1)], &v727_23_cursor);
          compose(&(v737_5),&(v738_6))
        };
        drop(v737_5);
        let v737_8: Space = intersect(&(*CONSTANT_9),&(v737_2));
        drop(v737_2);
        let v737_9: Space = if has_head(&(v737_8)) { singleton(&[]) } else { Space::new() };
        drop(v737_8);
        let v737_13: Space = if (&(v737_9)).is_empty() { Space::new() } else {
          let v739_11: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v727_23_cursor,(v727_23_origin + 2)),&(*CONSTANT_2))));
          let mut v739_12 = Space::new();
          let mut v739_12_write = v739_12.write_zipper();
          let mut v739_12_cursor = (v739_11).read_zipper();
          let v739_12_origin = v739_12_cursor.path().len();
          for v739_12_byte in v739_12_cursor.child_mask().iter() {
            v739_12_cursor.descend_to_existing_byte(v739_12_byte);
            {
            let v740_2: Space = singleton(&v739_12_cursor.path()[v739_12_origin..(v739_12_origin + 1)]);
            let v740_3: Space = intersect(&(*CONSTANT_9),&(v740_2));
            let v740_4: Space = if has_head(&(v740_3)) { singleton(&[]) } else { Space::new() };
            drop(v740_3);
            let v740_5: Space = subtract(&(*CONSTANT_0),&(v740_4));
            drop(v740_4);
            let v740_7: Space = if (&(v740_5)).is_empty() { Space::new() } else {
              let v741_6: Space = routine_75(c, &v739_12_cursor.path()[v739_12_origin..(v739_12_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v727_23_cursor.path()[v727_23_origin..(v727_23_origin + 1)], &v727_23_cursor.path()[(v727_23_origin + 1)..(v727_23_origin + 2)], &v739_12_cursor, &v727_23_cursor);
              compose(&(v740_5),&(v741_6))
            };
            drop(v740_5);
            let v740_8: Space = intersect(&(*CONSTANT_9),&(v740_2));
            drop(v740_2);
            let v740_9: Space = if has_head(&(v740_8)) { singleton(&[]) } else { Space::new() };
            drop(v740_8);
            let v740_11: Space = if (&(v740_9)).is_empty() { Space::new() } else {
              let v742_10: Space = routine_76(c, &v739_12_cursor.path()[v739_12_origin..(v739_12_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v727_23_cursor.path()[v727_23_origin..(v727_23_origin + 1)], &v727_23_cursor.path()[(v727_23_origin + 1)..(v727_23_origin + 2)], &v739_12_cursor, &v727_23_cursor);
              compose(&(v740_9),&(v742_10))
            };
            drop(v740_9);
            let v740_12: Space = unite(&(v740_7),&(v740_11));
            join_wrapped_into(&mut v739_12_write,&((v740_12).read_zipper()),&[]);
            }
            v739_12_cursor.ascend(1);
          }
          drop(v739_12_cursor);
          drop(v739_12_write);
          drop(v739_11);
          compose(&(v737_9),&(v739_12))
        };
        drop(v737_9);
        let v737_14: Space = unite(&(v737_7),&(v737_13));
        join_wrapped_into(&mut v736_10_write,&((v737_14).read_zipper()),&[]);
        }
        v727_23_cursor.ascend(1);
      }
      drop(v736_10_write);
      compose(&(v728_9),&(v736_10))
    };
    drop(v728_9);
    let v728_12: Space = unite(&(v728_7),&(v728_11));
    join_wrapped_into(&mut v727_23_write,&((v728_12).read_zipper()),&[]);
    }
    v727_23_cursor.ascend(1);
  }
  drop(v727_23_cursor);
  drop(v727_23_write);
  (v727_23).clone()
}

fn routine_63(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v743_18 = Space::new();
  let mut v743_18_write = v743_18.write_zipper();
  let mut v743_18_cursor = (*s0).read_zipper();
  let v743_18_origin = v743_18_cursor.path().len();
  for v743_18_byte in v743_18_cursor.child_mask().iter() {
    v743_18_cursor.descend_to_existing_byte(v743_18_byte);
    {
    let v744_2: Space = singleton(&v743_18_cursor.path()[v743_18_origin..(v743_18_origin + 1)]);
    let v744_3: Space = intersect(&(*CONSTANT_9),&(v744_2));
    let v744_4: Space = if has_head(&(v744_3)) { singleton(&[]) } else { Space::new() };
    drop(v744_3);
    let v744_5: Space = subtract(&(*CONSTANT_0),&(v744_4));
    drop(v744_4);
    let v744_8: Space = if (&(v744_5)).is_empty() { Space::new() } else {
      let v745_6: Path = concat_path(&(*p0),&v743_18_cursor.path()[v743_18_origin..(v743_18_origin + 1)]);
      let v745_7: Space = routine_63(c, &(v745_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &v743_18_cursor);
      compose(&(v744_5),&(v745_7))
    };
    drop(v744_5);
    let v744_9: Space = intersect(&(*CONSTANT_9),&(v744_2));
    drop(v744_2);
    let v744_10: Space = if has_head(&(v744_9)) { singleton(&[]) } else { Space::new() };
    drop(v744_9);
    let v744_12: Space = if (&(v744_10)).is_empty() { Space::new() } else {
      let v746_6: Path = concat_path(&(*p0),&v743_18_cursor.path()[v743_18_origin..(v743_18_origin + 1)]);
      let mut v746_11 = Space::new();
      let mut v746_11_write = v746_11.write_zipper();
      for v746_11_byte in v743_18_cursor.child_mask().iter() {
        v743_18_cursor.descend_to_existing_byte(v746_11_byte);
        {
        let v747_2: Space = singleton(&v743_18_cursor.path()[(v743_18_origin + 1)..(v743_18_origin + 2)]);
        let v747_3: Space = intersect(&(*CONSTANT_9),&(v747_2));
        let v747_4: Space = if has_head(&(v747_3)) { singleton(&[]) } else { Space::new() };
        drop(v747_3);
        let v747_5: Space = subtract(&(*CONSTANT_0),&(v747_4));
        drop(v747_4);
        let v747_7: Space = if (&(v747_5)).is_empty() { Space::new() } else {
          let v748_6: Space = routine_73(c, &v743_18_cursor.path()[(v743_18_origin + 1)..(v743_18_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v746_6), &v743_18_cursor);
          compose(&(v747_5),&(v748_6))
        };
        drop(v747_5);
        let v747_8: Space = intersect(&(*CONSTANT_9),&(v747_2));
        drop(v747_2);
        let v747_9: Space = if has_head(&(v747_8)) { singleton(&[]) } else { Space::new() };
        drop(v747_8);
        let v747_13: Space = if (&(v747_9)).is_empty() { Space::new() } else {
          let v749_11: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v743_18_cursor,(v743_18_origin + 2)),&(*CONSTANT_2))));
          let mut v749_12 = Space::new();
          let mut v749_12_write = v749_12.write_zipper();
          let mut v749_12_cursor = (v749_11).read_zipper();
          let v749_12_origin = v749_12_cursor.path().len();
          for v749_12_byte in v749_12_cursor.child_mask().iter() {
            v749_12_cursor.descend_to_existing_byte(v749_12_byte);
            {
            let v750_2: Space = singleton(&v749_12_cursor.path()[v749_12_origin..(v749_12_origin + 1)]);
            let v750_3: Space = intersect(&(*CONSTANT_9),&(v750_2));
            let v750_4: Space = if has_head(&(v750_3)) { singleton(&[]) } else { Space::new() };
            drop(v750_3);
            let v750_5: Space = subtract(&(*CONSTANT_0),&(v750_4));
            drop(v750_4);
            let v750_7: Space = if (&(v750_5)).is_empty() { Space::new() } else {
              let v751_6: Space = routine_75(c, &v749_12_cursor.path()[v749_12_origin..(v749_12_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v746_6), &v743_18_cursor.path()[(v743_18_origin + 1)..(v743_18_origin + 2)], &v749_12_cursor, &v743_18_cursor);
              compose(&(v750_5),&(v751_6))
            };
            drop(v750_5);
            let v750_8: Space = intersect(&(*CONSTANT_9),&(v750_2));
            drop(v750_2);
            let v750_9: Space = if has_head(&(v750_8)) { singleton(&[]) } else { Space::new() };
            drop(v750_8);
            let v750_11: Space = if (&(v750_9)).is_empty() { Space::new() } else {
              let v752_10: Space = routine_76(c, &v749_12_cursor.path()[v749_12_origin..(v749_12_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v746_6), &v743_18_cursor.path()[(v743_18_origin + 1)..(v743_18_origin + 2)], &v749_12_cursor, &v743_18_cursor);
              compose(&(v750_9),&(v752_10))
            };
            drop(v750_9);
            let v750_12: Space = unite(&(v750_7),&(v750_11));
            join_wrapped_into(&mut v749_12_write,&((v750_12).read_zipper()),&[]);
            }
            v749_12_cursor.ascend(1);
          }
          drop(v749_12_cursor);
          drop(v749_12_write);
          drop(v749_11);
          compose(&(v747_9),&(v749_12))
        };
        drop(v747_9);
        let v747_14: Space = unite(&(v747_7),&(v747_13));
        join_wrapped_into(&mut v746_11_write,&((v747_14).read_zipper()),&[]);
        }
        v743_18_cursor.ascend(1);
      }
      drop(v746_11_write);
      drop(v746_6);
      compose(&(v744_10),&(v746_11))
    };
    drop(v744_10);
    let v744_13: Space = unite(&(v744_8),&(v744_12));
    join_wrapped_into(&mut v743_18_write,&((v744_13).read_zipper()),&[]);
    }
    v743_18_cursor.ascend(1);
  }
  drop(v743_18_cursor);
  drop(v743_18_write);
  (v743_18).clone()
}

fn routine_64(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v753_19: Path = concat_path(&(*p1),&(*p2));
  let v753_23: Path = concat_path(&(v753_19),&(*p3));
  drop(v753_19);
  let v753_24: Path = concat_path(&(v753_23),&(*p4));
  drop(v753_23);
  let v753_25: Path = concat_path(&(v753_24),&(*p5));
  drop(v753_24);
  let v753_26: Path = concat_path(&(v753_25),&(*p0));
  drop(v753_25);
  let mut v753_27 = Space::new();
  let mut v753_27_write = v753_27.write_zipper();
  let mut v753_27_cursor = (*s0).read_zipper();
  let v753_27_origin = v753_27_cursor.path().len();
  for v753_27_byte in v753_27_cursor.child_mask().iter() {
    v753_27_cursor.descend_to_existing_byte(v753_27_byte);
    {
    let v754_2: Space = singleton(&v753_27_cursor.path()[v753_27_origin..(v753_27_origin + 1)]);
    let v754_3: Space = intersect(&(*CONSTANT_9),&(v754_2));
    let v754_4: Space = if has_head(&(v754_3)) { singleton(&[]) } else { Space::new() };
    drop(v754_3);
    let v754_5: Space = subtract(&(*CONSTANT_0),&(v754_4));
    drop(v754_4);
    let v754_7: Space = if (&(v754_5)).is_empty() { Space::new() } else {
      let mut v755_6 = Space::new();
      let mut v755_6_write = v755_6.write_zipper();
      for v755_6_byte in v753_27_cursor.child_mask().iter() {
        v753_27_cursor.descend_to_existing_byte(v755_6_byte);
        {
        let v756_2: Space = singleton(&v753_27_cursor.path()[(v753_27_origin + 1)..(v753_27_origin + 2)]);
        let v756_3: Space = intersect(&(*CONSTANT_9),&(v756_2));
        let v756_4: Space = if has_head(&(v756_3)) { singleton(&[]) } else { Space::new() };
        drop(v756_3);
        let v756_5: Space = subtract(&(*CONSTANT_0),&(v756_4));
        drop(v756_4);
        let v756_8: Space = if (&(v756_5)).is_empty() { Space::new() } else {
          let v757_7: Space = routine_73(c, &v753_27_cursor.path()[v753_27_origin..(v753_27_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v753_27_cursor);
          compose(&(v756_5),&(v757_7))
        };
        drop(v756_5);
        let v756_9: Space = intersect(&(*CONSTANT_9),&(v756_2));
        drop(v756_2);
        let v756_10: Space = if has_head(&(v756_9)) { singleton(&[]) } else { Space::new() };
        drop(v756_9);
        let v756_14: Space = if (&(v756_10)).is_empty() { Space::new() } else {
          let v758_12: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v753_27_cursor,(v753_27_origin + 2)),&(*CONSTANT_2))));
          let mut v758_13 = Space::new();
          let mut v758_13_write = v758_13.write_zipper();
          let mut v758_13_cursor = (v758_12).read_zipper();
          let v758_13_origin = v758_13_cursor.path().len();
          for v758_13_byte in v758_13_cursor.child_mask().iter() {
            v758_13_cursor.descend_to_existing_byte(v758_13_byte);
            {
            let v759_2: Space = singleton(&v758_13_cursor.path()[v758_13_origin..(v758_13_origin + 1)]);
            let v759_3: Space = intersect(&(*CONSTANT_9),&(v759_2));
            let v759_4: Space = if has_head(&(v759_3)) { singleton(&[]) } else { Space::new() };
            drop(v759_3);
            let v759_5: Space = subtract(&(*CONSTANT_0),&(v759_4));
            drop(v759_4);
            let v759_7: Space = if (&(v759_5)).is_empty() { Space::new() } else {
              let v760_6: Space = routine_75(c, &v758_13_cursor.path()[v758_13_origin..(v758_13_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v753_27_cursor.path()[v753_27_origin..(v753_27_origin + 2)], &v758_13_cursor, &v753_27_cursor);
              compose(&(v759_5),&(v760_6))
            };
            drop(v759_5);
            let v759_8: Space = intersect(&(*CONSTANT_9),&(v759_2));
            drop(v759_2);
            let v759_9: Space = if has_head(&(v759_8)) { singleton(&[]) } else { Space::new() };
            drop(v759_8);
            let v759_11: Space = if (&(v759_9)).is_empty() { Space::new() } else {
              let v761_10: Space = routine_76(c, &v758_13_cursor.path()[v758_13_origin..(v758_13_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v753_27_cursor.path()[v753_27_origin..(v753_27_origin + 2)], &v758_13_cursor, &v753_27_cursor);
              compose(&(v759_9),&(v761_10))
            };
            drop(v759_9);
            let v759_12: Space = unite(&(v759_7),&(v759_11));
            join_wrapped_into(&mut v758_13_write,&((v759_12).read_zipper()),&[]);
            }
            v758_13_cursor.ascend(1);
          }
          drop(v758_13_cursor);
          drop(v758_13_write);
          drop(v758_12);
          compose(&(v756_10),&(v758_13))
        };
        drop(v756_10);
        let v756_15: Space = unite(&(v756_8),&(v756_14));
        join_wrapped_into(&mut v755_6_write,&((v756_15).read_zipper()),&[]);
        }
        v753_27_cursor.ascend(1);
      }
      drop(v755_6_write);
      compose(&(v754_5),&(v755_6))
    };
    drop(v754_5);
    let v754_8: Space = intersect(&(*CONSTANT_9),&(v754_2));
    drop(v754_2);
    let v754_9: Space = if has_head(&(v754_8)) { singleton(&[]) } else { Space::new() };
    drop(v754_8);
    let v754_14: Space = if (&(v754_9)).is_empty() { Space::new() } else {
      let v762_11: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v753_27_cursor,(v753_27_origin + 1)),&(*CONSTANT_2))));
      let v762_12: Path = concat_path(&(v753_26),&v753_27_cursor.path()[v753_27_origin..(v753_27_origin + 1)]);
      let mut v762_13 = Space::new();
      let mut v762_13_write = v762_13.write_zipper();
      let mut v762_13_cursor = (v762_11).read_zipper();
      let v762_13_origin = v762_13_cursor.path().len();
      for v762_13_byte in v762_13_cursor.child_mask().iter() {
        v762_13_cursor.descend_to_existing_byte(v762_13_byte);
        {
        let v763_2: Space = singleton(&v762_13_cursor.path()[v762_13_origin..(v762_13_origin + 1)]);
        let v763_3: Space = intersect(&(*CONSTANT_9),&(v763_2));
        let v763_4: Space = if has_head(&(v763_3)) { singleton(&[]) } else { Space::new() };
        drop(v763_3);
        let v763_5: Space = subtract(&(*CONSTANT_0),&(v763_4));
        drop(v763_4);
        let v763_7: Space = if (&(v763_5)).is_empty() { Space::new() } else {
          let v764_6: Space = routine_75(c, &v762_13_cursor.path()[v762_13_origin..(v762_13_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v753_27_cursor.path()[v753_27_origin..(v753_27_origin + 1)], &v762_13_cursor, &v753_27_cursor);
          compose(&(v763_5),&(v764_6))
        };
        drop(v763_5);
        let v763_8: Space = intersect(&(*CONSTANT_9),&(v763_2));
        drop(v763_2);
        let v763_9: Space = if has_head(&(v763_8)) { singleton(&[]) } else { Space::new() };
        drop(v763_8);
        let v763_12: Space = if (&(v763_9)).is_empty() { Space::new() } else {
          let v765_10: Space = routine_1(c, &v762_13_cursor.path()[v762_13_origin..(v762_13_origin + 1)], &(*CONSTANT_2), &(*CONSTANT_2));
          let v765_11: Space = unite(&v753_27_cursor,&(v765_10));
          compose(&(v763_9),&(v765_11))
        };
        drop(v763_9);
        let v763_13: Space = wrap(&(v763_12),&(v762_12));
        let v763_14: Space = wrap(&(v763_13),&v762_13_cursor.path()[v762_13_origin..(v762_13_origin + 1)]);
        let v763_15: Space = unite(&(v763_7),&(v763_14));
        join_wrapped_into(&mut v762_13_write,&((v763_15).read_zipper()),&[]);
        }
        v762_13_cursor.ascend(1);
      }
      drop(v762_13_cursor);
      drop(v762_13_write);
      drop(v762_11);
      drop(v762_12);
      compose(&(v754_9),&(v762_13))
    };
    drop(v754_9);
    let v754_15: Space = unite(&(v754_7),&(v754_14));
    join_wrapped_into(&mut v753_27_write,&((v754_15).read_zipper()),&[]);
    }
    v753_27_cursor.ascend(1);
  }
  drop(v753_27_cursor);
  drop(v753_27_write);
  drop(v753_26);
  (v753_27).clone()
}

fn routine_65(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v766_14 = Space::new();
  let mut v766_14_write = v766_14.write_zipper();
  let mut v766_14_cursor = (*s0).read_zipper();
  let v766_14_origin = v766_14_cursor.path().len();
  for v766_14_byte in v766_14_cursor.child_mask().iter() {
    v766_14_cursor.descend_to_existing_byte(v766_14_byte);
    {
    let v767_2: Space = singleton(&v766_14_cursor.path()[v766_14_origin..(v766_14_origin + 1)]);
    let v767_3: Space = intersect(&(*CONSTANT_9),&(v767_2));
    let v767_4: Space = if has_head(&(v767_3)) { singleton(&[]) } else { Space::new() };
    drop(v767_3);
    let v767_5: Space = subtract(&(*CONSTANT_0),&(v767_4));
    drop(v767_4);
    let v767_8: Space = if (&(v767_5)).is_empty() { Space::new() } else {
      let v768_6: Path = concat_path(&(*p0),&v766_14_cursor.path()[v766_14_origin..(v766_14_origin + 1)]);
      let v768_7: Space = routine_65(c, &(v768_6), &(*p1), &(*p2), &(*p3), &v766_14_cursor);
      compose(&(v767_5),&(v768_7))
    };
    drop(v767_5);
    let v767_9: Space = intersect(&(*CONSTANT_9),&(v767_2));
    drop(v767_2);
    let v767_10: Space = if has_head(&(v767_9)) { singleton(&[]) } else { Space::new() };
    drop(v767_9);
    let v767_12: Space = if (&(v767_10)).is_empty() { Space::new() } else {
      let v769_6: Path = concat_path(&(*p0),&v766_14_cursor.path()[v766_14_origin..(v766_14_origin + 1)]);
      let mut v769_11 = Space::new();
      let mut v769_11_write = v769_11.write_zipper();
      for v769_11_byte in v766_14_cursor.child_mask().iter() {
        v766_14_cursor.descend_to_existing_byte(v769_11_byte);
        {
        let v770_2: Space = singleton(&v766_14_cursor.path()[(v766_14_origin + 1)..(v766_14_origin + 2)]);
        let v770_3: Space = intersect(&(*CONSTANT_9),&(v770_2));
        let v770_4: Space = if has_head(&(v770_3)) { singleton(&[]) } else { Space::new() };
        drop(v770_3);
        let v770_5: Space = subtract(&(*CONSTANT_0),&(v770_4));
        drop(v770_4);
        let v770_7: Space = if (&(v770_5)).is_empty() { Space::new() } else {
          let v771_6: Space = routine_67(c, &v766_14_cursor.path()[(v766_14_origin + 1)..(v766_14_origin + 2)], &(*p1), &(*p2), &(*p3), &(v769_6), &v766_14_cursor);
          compose(&(v770_5),&(v771_6))
        };
        drop(v770_5);
        let v770_8: Space = intersect(&(*CONSTANT_9),&(v770_2));
        drop(v770_2);
        let v770_9: Space = if has_head(&(v770_8)) { singleton(&[]) } else { Space::new() };
        drop(v770_8);
        let v770_11: Space = if (&(v770_9)).is_empty() { Space::new() } else {
          let mut v772_10 = Space::new();
          let mut v772_10_write = v772_10.write_zipper();
          for v772_10_byte in v766_14_cursor.child_mask().iter() {
            v766_14_cursor.descend_to_existing_byte(v772_10_byte);
            {
            let v773_2: Space = singleton(&v766_14_cursor.path()[(v766_14_origin + 2)..(v766_14_origin + 3)]);
            let v773_3: Space = intersect(&(*CONSTANT_9),&(v773_2));
            let v773_4: Space = if has_head(&(v773_3)) { singleton(&[]) } else { Space::new() };
            drop(v773_3);
            let v773_5: Space = subtract(&(*CONSTANT_0),&(v773_4));
            drop(v773_4);
            let v773_7: Space = if (&(v773_5)).is_empty() { Space::new() } else {
              let v774_6: Space = routine_69(c, &v766_14_cursor.path()[(v766_14_origin + 2)..(v766_14_origin + 3)], &(*p1), &(*p2), &(*p3), &(v769_6), &v766_14_cursor.path()[(v766_14_origin + 1)..(v766_14_origin + 2)], &v766_14_cursor);
              compose(&(v773_5),&(v774_6))
            };
            drop(v773_5);
            let v773_8: Space = intersect(&(*CONSTANT_9),&(v773_2));
            drop(v773_2);
            let v773_9: Space = if has_head(&(v773_8)) { singleton(&[]) } else { Space::new() };
            drop(v773_8);
            let v773_11: Space = if (&(v773_9)).is_empty() { Space::new() } else {
              let v775_10: Space = routine_70(c, &v766_14_cursor.path()[(v766_14_origin + 2)..(v766_14_origin + 3)], &(*p1), &(*p2), &(*p3), &(v769_6), &v766_14_cursor.path()[(v766_14_origin + 1)..(v766_14_origin + 2)], &v766_14_cursor);
              compose(&(v773_9),&(v775_10))
            };
            drop(v773_9);
            let v773_12: Space = unite(&(v773_7),&(v773_11));
            join_wrapped_into(&mut v772_10_write,&((v773_12).read_zipper()),&[]);
            }
            v766_14_cursor.ascend(1);
          }
          drop(v772_10_write);
          compose(&(v770_9),&(v772_10))
        };
        drop(v770_9);
        let v770_12: Space = unite(&(v770_7),&(v770_11));
        join_wrapped_into(&mut v769_11_write,&((v770_12).read_zipper()),&[]);
        }
        v766_14_cursor.ascend(1);
      }
      drop(v769_11_write);
      drop(v769_6);
      compose(&(v767_10),&(v769_11))
    };
    drop(v767_10);
    let v767_13: Space = unite(&(v767_8),&(v767_12));
    join_wrapped_into(&mut v766_14_write,&((v767_13).read_zipper()),&[]);
    }
    v766_14_cursor.ascend(1);
  }
  drop(v766_14_cursor);
  drop(v766_14_write);
  (v766_14).clone()
}

fn routine_66(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v776_20 = Space::new();
  let mut v776_20_write = v776_20.write_zipper();
  let mut v776_20_cursor = (*s0).read_zipper();
  let v776_20_origin = v776_20_cursor.path().len();
  for v776_20_byte in v776_20_cursor.child_mask().iter() {
    v776_20_cursor.descend_to_existing_byte(v776_20_byte);
    {
    let v777_2: Space = singleton(&v776_20_cursor.path()[v776_20_origin..(v776_20_origin + 1)]);
    let v777_3: Space = intersect(&(*CONSTANT_9),&(v777_2));
    let v777_4: Space = if has_head(&(v777_3)) { singleton(&[]) } else { Space::new() };
    drop(v777_3);
    let v777_5: Space = subtract(&(*CONSTANT_0),&(v777_4));
    drop(v777_4);
    let v777_7: Space = if (&(v777_5)).is_empty() { Space::new() } else {
      let mut v778_6 = Space::new();
      let mut v778_6_write = v778_6.write_zipper();
      for v778_6_byte in v776_20_cursor.child_mask().iter() {
        v776_20_cursor.descend_to_existing_byte(v778_6_byte);
        {
        let v779_2: Space = singleton(&v776_20_cursor.path()[(v776_20_origin + 1)..(v776_20_origin + 2)]);
        let v779_3: Space = intersect(&(*CONSTANT_9),&(v779_2));
        let v779_4: Space = if has_head(&(v779_3)) { singleton(&[]) } else { Space::new() };
        drop(v779_3);
        let v779_5: Space = subtract(&(*CONSTANT_0),&(v779_4));
        drop(v779_4);
        let v779_8: Space = if (&(v779_5)).is_empty() { Space::new() } else {
          let v780_7: Space = routine_67(c, &v776_20_cursor.path()[v776_20_origin..(v776_20_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p0), &v776_20_cursor);
          compose(&(v779_5),&(v780_7))
        };
        drop(v779_5);
        let v779_9: Space = intersect(&(*CONSTANT_9),&(v779_2));
        drop(v779_2);
        let v779_10: Space = if has_head(&(v779_9)) { singleton(&[]) } else { Space::new() };
        drop(v779_9);
        let v779_12: Space = if (&(v779_10)).is_empty() { Space::new() } else {
          let mut v781_11 = Space::new();
          let mut v781_11_write = v781_11.write_zipper();
          for v781_11_byte in v776_20_cursor.child_mask().iter() {
            v776_20_cursor.descend_to_existing_byte(v781_11_byte);
            {
            let v782_2: Space = singleton(&v776_20_cursor.path()[(v776_20_origin + 2)..(v776_20_origin + 3)]);
            let v782_3: Space = intersect(&(*CONSTANT_9),&(v782_2));
            let v782_4: Space = if has_head(&(v782_3)) { singleton(&[]) } else { Space::new() };
            drop(v782_3);
            let v782_5: Space = subtract(&(*CONSTANT_0),&(v782_4));
            drop(v782_4);
            let v782_7: Space = if (&(v782_5)).is_empty() { Space::new() } else {
              let v783_6: Space = routine_69(c, &v776_20_cursor.path()[(v776_20_origin + 2)..(v776_20_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p0), &v776_20_cursor.path()[v776_20_origin..(v776_20_origin + 2)], &v776_20_cursor);
              compose(&(v782_5),&(v783_6))
            };
            drop(v782_5);
            let v782_8: Space = intersect(&(*CONSTANT_9),&(v782_2));
            drop(v782_2);
            let v782_9: Space = if has_head(&(v782_8)) { singleton(&[]) } else { Space::new() };
            drop(v782_8);
            let v782_11: Space = if (&(v782_9)).is_empty() { Space::new() } else {
              let v784_10: Space = routine_70(c, &v776_20_cursor.path()[(v776_20_origin + 2)..(v776_20_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p0), &v776_20_cursor.path()[v776_20_origin..(v776_20_origin + 2)], &v776_20_cursor);
              compose(&(v782_9),&(v784_10))
            };
            drop(v782_9);
            let v782_12: Space = unite(&(v782_7),&(v782_11));
            join_wrapped_into(&mut v781_11_write,&((v782_12).read_zipper()),&[]);
            }
            v776_20_cursor.ascend(1);
          }
          drop(v781_11_write);
          compose(&(v779_10),&(v781_11))
        };
        drop(v779_10);
        let v779_13: Space = unite(&(v779_8),&(v779_12));
        join_wrapped_into(&mut v778_6_write,&((v779_13).read_zipper()),&[]);
        }
        v776_20_cursor.ascend(1);
      }
      drop(v778_6_write);
      compose(&(v777_5),&(v778_6))
    };
    drop(v777_5);
    let v777_8: Space = intersect(&(*CONSTANT_9),&(v777_2));
    drop(v777_2);
    let v777_9: Space = if has_head(&(v777_8)) { singleton(&[]) } else { Space::new() };
    drop(v777_8);
    let v777_11: Space = if (&(v777_9)).is_empty() { Space::new() } else {
      let mut v785_10 = Space::new();
      let mut v785_10_write = v785_10.write_zipper();
      for v785_10_byte in v776_20_cursor.child_mask().iter() {
        v776_20_cursor.descend_to_existing_byte(v785_10_byte);
        {
        let v786_2: Space = singleton(&v776_20_cursor.path()[(v776_20_origin + 1)..(v776_20_origin + 2)]);
        let v786_3: Space = intersect(&(*CONSTANT_9),&(v786_2));
        let v786_4: Space = if has_head(&(v786_3)) { singleton(&[]) } else { Space::new() };
        drop(v786_3);
        let v786_5: Space = subtract(&(*CONSTANT_0),&(v786_4));
        drop(v786_4);
        let v786_7: Space = if (&(v786_5)).is_empty() { Space::new() } else {
          let v787_6: Space = routine_69(c, &v776_20_cursor.path()[(v776_20_origin + 1)..(v776_20_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p0), &v776_20_cursor.path()[v776_20_origin..(v776_20_origin + 1)], &v776_20_cursor);
          compose(&(v786_5),&(v787_6))
        };
        drop(v786_5);
        let v786_8: Space = intersect(&(*CONSTANT_9),&(v786_2));
        drop(v786_2);
        let v786_9: Space = if has_head(&(v786_8)) { singleton(&[]) } else { Space::new() };
        drop(v786_8);
        let v786_11: Space = if (&(v786_9)).is_empty() { Space::new() } else {
          let mut v788_10 = Space::new();
          let mut v788_10_write = v788_10.write_zipper();
          for v788_10_byte in v776_20_cursor.child_mask().iter() {
            v776_20_cursor.descend_to_existing_byte(v788_10_byte);
            {
            let v789_2: Space = singleton(&v776_20_cursor.path()[(v776_20_origin + 2)..(v776_20_origin + 3)]);
            let v789_3: Space = intersect(&(*CONSTANT_9),&(v789_2));
            let v789_4: Space = if has_head(&(v789_3)) { singleton(&[]) } else { Space::new() };
            drop(v789_3);
            let v789_5: Space = subtract(&(*CONSTANT_0),&(v789_4));
            drop(v789_4);
            let v789_7: Space = if (&(v789_5)).is_empty() { Space::new() } else {
              let v790_6: Space = routine_77(c, &v776_20_cursor.path()[(v776_20_origin + 2)..(v776_20_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p0), &v776_20_cursor.path()[v776_20_origin..(v776_20_origin + 1)], &v776_20_cursor.path()[(v776_20_origin + 1)..(v776_20_origin + 2)], &v776_20_cursor);
              compose(&(v789_5),&(v790_6))
            };
            drop(v789_5);
            let v789_8: Space = intersect(&(*CONSTANT_9),&(v789_2));
            drop(v789_2);
            let v789_9: Space = if has_head(&(v789_8)) { singleton(&[]) } else { Space::new() };
            drop(v789_8);
            let v789_11: Space = if (&(v789_9)).is_empty() { Space::new() } else {
              let v791_10: Space = routine_78(c, &v776_20_cursor.path()[(v776_20_origin + 2)..(v776_20_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p0), &v776_20_cursor.path()[v776_20_origin..(v776_20_origin + 1)], &v776_20_cursor.path()[(v776_20_origin + 1)..(v776_20_origin + 2)], &v776_20_cursor);
              compose(&(v789_9),&(v791_10))
            };
            drop(v789_9);
            let v789_12: Space = unite(&(v789_7),&(v789_11));
            join_wrapped_into(&mut v788_10_write,&((v789_12).read_zipper()),&[]);
            }
            v776_20_cursor.ascend(1);
          }
          drop(v788_10_write);
          compose(&(v786_9),&(v788_10))
        };
        drop(v786_9);
        let v786_12: Space = unite(&(v786_7),&(v786_11));
        join_wrapped_into(&mut v785_10_write,&((v786_12).read_zipper()),&[]);
        }
        v776_20_cursor.ascend(1);
      }
      drop(v785_10_write);
      compose(&(v777_9),&(v785_10))
    };
    drop(v777_9);
    let v777_12: Space = unite(&(v777_7),&(v777_11));
    join_wrapped_into(&mut v776_20_write,&((v777_12).read_zipper()),&[]);
    }
    v776_20_cursor.ascend(1);
  }
  drop(v776_20_cursor);
  drop(v776_20_write);
  (v776_20).clone()
}

fn routine_67(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v792_15 = Space::new();
  let mut v792_15_write = v792_15.write_zipper();
  let mut v792_15_cursor = (*s0).read_zipper();
  let v792_15_origin = v792_15_cursor.path().len();
  for v792_15_byte in v792_15_cursor.child_mask().iter() {
    v792_15_cursor.descend_to_existing_byte(v792_15_byte);
    {
    let v793_2: Space = singleton(&v792_15_cursor.path()[v792_15_origin..(v792_15_origin + 1)]);
    let v793_3: Space = intersect(&(*CONSTANT_9),&(v793_2));
    let v793_4: Space = if has_head(&(v793_3)) { singleton(&[]) } else { Space::new() };
    drop(v793_3);
    let v793_5: Space = subtract(&(*CONSTANT_0),&(v793_4));
    drop(v793_4);
    let v793_8: Space = if (&(v793_5)).is_empty() { Space::new() } else {
      let v794_6: Path = concat_path(&(*p0),&v792_15_cursor.path()[v792_15_origin..(v792_15_origin + 1)]);
      let v794_7: Space = routine_67(c, &(v794_6), &(*p1), &(*p2), &(*p3), &(*p4), &v792_15_cursor);
      compose(&(v793_5),&(v794_7))
    };
    drop(v793_5);
    let v793_9: Space = intersect(&(*CONSTANT_9),&(v793_2));
    drop(v793_2);
    let v793_10: Space = if has_head(&(v793_9)) { singleton(&[]) } else { Space::new() };
    drop(v793_9);
    let v793_12: Space = if (&(v793_10)).is_empty() { Space::new() } else {
      let v795_6: Path = concat_path(&(*p0),&v792_15_cursor.path()[v792_15_origin..(v792_15_origin + 1)]);
      let mut v795_11 = Space::new();
      let mut v795_11_write = v795_11.write_zipper();
      for v795_11_byte in v792_15_cursor.child_mask().iter() {
        v792_15_cursor.descend_to_existing_byte(v795_11_byte);
        {
        let v796_2: Space = singleton(&v792_15_cursor.path()[(v792_15_origin + 1)..(v792_15_origin + 2)]);
        let v796_3: Space = intersect(&(*CONSTANT_9),&(v796_2));
        let v796_4: Space = if has_head(&(v796_3)) { singleton(&[]) } else { Space::new() };
        drop(v796_3);
        let v796_5: Space = subtract(&(*CONSTANT_0),&(v796_4));
        drop(v796_4);
        let v796_7: Space = if (&(v796_5)).is_empty() { Space::new() } else {
          let v797_6: Space = routine_69(c, &v792_15_cursor.path()[(v792_15_origin + 1)..(v792_15_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p4), &(v795_6), &v792_15_cursor);
          compose(&(v796_5),&(v797_6))
        };
        drop(v796_5);
        let v796_8: Space = intersect(&(*CONSTANT_9),&(v796_2));
        drop(v796_2);
        let v796_9: Space = if has_head(&(v796_8)) { singleton(&[]) } else { Space::new() };
        drop(v796_8);
        let v796_11: Space = if (&(v796_9)).is_empty() { Space::new() } else {
          let mut v798_10 = Space::new();
          let mut v798_10_write = v798_10.write_zipper();
          for v798_10_byte in v792_15_cursor.child_mask().iter() {
            v792_15_cursor.descend_to_existing_byte(v798_10_byte);
            {
            let v799_2: Space = singleton(&v792_15_cursor.path()[(v792_15_origin + 2)..(v792_15_origin + 3)]);
            let v799_3: Space = intersect(&(*CONSTANT_9),&(v799_2));
            let v799_4: Space = if has_head(&(v799_3)) { singleton(&[]) } else { Space::new() };
            drop(v799_3);
            let v799_5: Space = subtract(&(*CONSTANT_0),&(v799_4));
            drop(v799_4);
            let v799_7: Space = if (&(v799_5)).is_empty() { Space::new() } else {
              let v800_6: Space = routine_77(c, &v792_15_cursor.path()[(v792_15_origin + 2)..(v792_15_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p4), &(v795_6), &v792_15_cursor.path()[(v792_15_origin + 1)..(v792_15_origin + 2)], &v792_15_cursor);
              compose(&(v799_5),&(v800_6))
            };
            drop(v799_5);
            let v799_8: Space = intersect(&(*CONSTANT_9),&(v799_2));
            drop(v799_2);
            let v799_9: Space = if has_head(&(v799_8)) { singleton(&[]) } else { Space::new() };
            drop(v799_8);
            let v799_11: Space = if (&(v799_9)).is_empty() { Space::new() } else {
              let v801_10: Space = routine_78(c, &v792_15_cursor.path()[(v792_15_origin + 2)..(v792_15_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p4), &(v795_6), &v792_15_cursor.path()[(v792_15_origin + 1)..(v792_15_origin + 2)], &v792_15_cursor);
              compose(&(v799_9),&(v801_10))
            };
            drop(v799_9);
            let v799_12: Space = unite(&(v799_7),&(v799_11));
            join_wrapped_into(&mut v798_10_write,&((v799_12).read_zipper()),&[]);
            }
            v792_15_cursor.ascend(1);
          }
          drop(v798_10_write);
          compose(&(v796_9),&(v798_10))
        };
        drop(v796_9);
        let v796_12: Space = unite(&(v796_7),&(v796_11));
        join_wrapped_into(&mut v795_11_write,&((v796_12).read_zipper()),&[]);
        }
        v792_15_cursor.ascend(1);
      }
      drop(v795_11_write);
      drop(v795_6);
      compose(&(v793_10),&(v795_11))
    };
    drop(v793_10);
    let v793_13: Space = unite(&(v793_8),&(v793_12));
    join_wrapped_into(&mut v792_15_write,&((v793_13).read_zipper()),&[]);
    }
    v792_15_cursor.ascend(1);
  }
  drop(v792_15_cursor);
  drop(v792_15_write);
  (v792_15).clone()
}

fn routine_68(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v802_21 = Space::new();
  let mut v802_21_write = v802_21.write_zipper();
  let mut v802_21_cursor = (*s0).read_zipper();
  let v802_21_origin = v802_21_cursor.path().len();
  for v802_21_byte in v802_21_cursor.child_mask().iter() {
    v802_21_cursor.descend_to_existing_byte(v802_21_byte);
    {
    let v803_2: Space = singleton(&v802_21_cursor.path()[v802_21_origin..(v802_21_origin + 1)]);
    let v803_3: Space = intersect(&(*CONSTANT_9),&(v803_2));
    let v803_4: Space = if has_head(&(v803_3)) { singleton(&[]) } else { Space::new() };
    drop(v803_3);
    let v803_5: Space = subtract(&(*CONSTANT_0),&(v803_4));
    drop(v803_4);
    let v803_7: Space = if (&(v803_5)).is_empty() { Space::new() } else {
      let mut v804_6 = Space::new();
      let mut v804_6_write = v804_6.write_zipper();
      for v804_6_byte in v802_21_cursor.child_mask().iter() {
        v802_21_cursor.descend_to_existing_byte(v804_6_byte);
        {
        let v805_2: Space = singleton(&v802_21_cursor.path()[(v802_21_origin + 1)..(v802_21_origin + 2)]);
        let v805_3: Space = intersect(&(*CONSTANT_9),&(v805_2));
        let v805_4: Space = if has_head(&(v805_3)) { singleton(&[]) } else { Space::new() };
        drop(v805_3);
        let v805_5: Space = subtract(&(*CONSTANT_0),&(v805_4));
        drop(v805_4);
        let v805_8: Space = if (&(v805_5)).is_empty() { Space::new() } else {
          let v806_7: Space = routine_69(c, &v802_21_cursor.path()[v802_21_origin..(v802_21_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v802_21_cursor);
          compose(&(v805_5),&(v806_7))
        };
        drop(v805_5);
        let v805_9: Space = intersect(&(*CONSTANT_9),&(v805_2));
        drop(v805_2);
        let v805_10: Space = if has_head(&(v805_9)) { singleton(&[]) } else { Space::new() };
        drop(v805_9);
        let v805_12: Space = if (&(v805_10)).is_empty() { Space::new() } else {
          let mut v807_11 = Space::new();
          let mut v807_11_write = v807_11.write_zipper();
          for v807_11_byte in v802_21_cursor.child_mask().iter() {
            v802_21_cursor.descend_to_existing_byte(v807_11_byte);
            {
            let v808_2: Space = singleton(&v802_21_cursor.path()[(v802_21_origin + 2)..(v802_21_origin + 3)]);
            let v808_3: Space = intersect(&(*CONSTANT_9),&(v808_2));
            let v808_4: Space = if has_head(&(v808_3)) { singleton(&[]) } else { Space::new() };
            drop(v808_3);
            let v808_5: Space = subtract(&(*CONSTANT_0),&(v808_4));
            drop(v808_4);
            let v808_7: Space = if (&(v808_5)).is_empty() { Space::new() } else {
              let v809_6: Space = routine_77(c, &v802_21_cursor.path()[(v802_21_origin + 2)..(v802_21_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v802_21_cursor.path()[v802_21_origin..(v802_21_origin + 2)], &v802_21_cursor);
              compose(&(v808_5),&(v809_6))
            };
            drop(v808_5);
            let v808_8: Space = intersect(&(*CONSTANT_9),&(v808_2));
            drop(v808_2);
            let v808_9: Space = if has_head(&(v808_8)) { singleton(&[]) } else { Space::new() };
            drop(v808_8);
            let v808_11: Space = if (&(v808_9)).is_empty() { Space::new() } else {
              let v810_10: Space = routine_78(c, &v802_21_cursor.path()[(v802_21_origin + 2)..(v802_21_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v802_21_cursor.path()[v802_21_origin..(v802_21_origin + 2)], &v802_21_cursor);
              compose(&(v808_9),&(v810_10))
            };
            drop(v808_9);
            let v808_12: Space = unite(&(v808_7),&(v808_11));
            join_wrapped_into(&mut v807_11_write,&((v808_12).read_zipper()),&[]);
            }
            v802_21_cursor.ascend(1);
          }
          drop(v807_11_write);
          compose(&(v805_10),&(v807_11))
        };
        drop(v805_10);
        let v805_13: Space = unite(&(v805_8),&(v805_12));
        join_wrapped_into(&mut v804_6_write,&((v805_13).read_zipper()),&[]);
        }
        v802_21_cursor.ascend(1);
      }
      drop(v804_6_write);
      compose(&(v803_5),&(v804_6))
    };
    drop(v803_5);
    let v803_8: Space = intersect(&(*CONSTANT_9),&(v803_2));
    drop(v803_2);
    let v803_9: Space = if has_head(&(v803_8)) { singleton(&[]) } else { Space::new() };
    drop(v803_8);
    let v803_11: Space = if (&(v803_9)).is_empty() { Space::new() } else {
      let mut v811_10 = Space::new();
      let mut v811_10_write = v811_10.write_zipper();
      for v811_10_byte in v802_21_cursor.child_mask().iter() {
        v802_21_cursor.descend_to_existing_byte(v811_10_byte);
        {
        let v812_2: Space = singleton(&v802_21_cursor.path()[(v802_21_origin + 1)..(v802_21_origin + 2)]);
        let v812_3: Space = intersect(&(*CONSTANT_9),&(v812_2));
        let v812_4: Space = if has_head(&(v812_3)) { singleton(&[]) } else { Space::new() };
        drop(v812_3);
        let v812_5: Space = subtract(&(*CONSTANT_0),&(v812_4));
        drop(v812_4);
        let v812_7: Space = if (&(v812_5)).is_empty() { Space::new() } else {
          let v813_6: Space = routine_77(c, &v802_21_cursor.path()[(v802_21_origin + 1)..(v802_21_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v802_21_cursor.path()[v802_21_origin..(v802_21_origin + 1)], &v802_21_cursor);
          compose(&(v812_5),&(v813_6))
        };
        drop(v812_5);
        let v812_8: Space = intersect(&(*CONSTANT_9),&(v812_2));
        drop(v812_2);
        let v812_9: Space = if has_head(&(v812_8)) { singleton(&[]) } else { Space::new() };
        drop(v812_8);
        let v812_11: Space = if (&(v812_9)).is_empty() { Space::new() } else {
          let mut v814_10 = Space::new();
          let mut v814_10_write = v814_10.write_zipper();
          for v814_10_byte in v802_21_cursor.child_mask().iter() {
            v802_21_cursor.descend_to_existing_byte(v814_10_byte);
            {
            let v815_2: Space = singleton(&v802_21_cursor.path()[(v802_21_origin + 2)..(v802_21_origin + 3)]);
            let v815_3: Space = intersect(&(*CONSTANT_9),&(v815_2));
            let v815_4: Space = if has_head(&(v815_3)) { singleton(&[]) } else { Space::new() };
            drop(v815_3);
            let v815_5: Space = subtract(&(*CONSTANT_0),&(v815_4));
            drop(v815_4);
            let v815_7: Space = if (&(v815_5)).is_empty() { Space::new() } else {
              let v816_6: Space = routine_79(c, &v802_21_cursor.path()[(v802_21_origin + 2)..(v802_21_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v802_21_cursor.path()[v802_21_origin..(v802_21_origin + 1)], &v802_21_cursor.path()[(v802_21_origin + 1)..(v802_21_origin + 2)], &v802_21_cursor);
              compose(&(v815_5),&(v816_6))
            };
            drop(v815_5);
            let v815_8: Space = intersect(&(*CONSTANT_9),&(v815_2));
            drop(v815_2);
            let v815_9: Space = if has_head(&(v815_8)) { singleton(&[]) } else { Space::new() };
            drop(v815_8);
            let v815_11: Space = if (&(v815_9)).is_empty() { Space::new() } else {
              let v817_10: Space = routine_80(c, &v802_21_cursor.path()[(v802_21_origin + 2)..(v802_21_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &v802_21_cursor.path()[v802_21_origin..(v802_21_origin + 1)], &v802_21_cursor.path()[(v802_21_origin + 1)..(v802_21_origin + 2)], &v802_21_cursor);
              compose(&(v815_9),&(v817_10))
            };
            drop(v815_9);
            let v815_12: Space = unite(&(v815_7),&(v815_11));
            join_wrapped_into(&mut v814_10_write,&((v815_12).read_zipper()),&[]);
            }
            v802_21_cursor.ascend(1);
          }
          drop(v814_10_write);
          compose(&(v812_9),&(v814_10))
        };
        drop(v812_9);
        let v812_12: Space = unite(&(v812_7),&(v812_11));
        join_wrapped_into(&mut v811_10_write,&((v812_12).read_zipper()),&[]);
        }
        v802_21_cursor.ascend(1);
      }
      drop(v811_10_write);
      compose(&(v803_9),&(v811_10))
    };
    drop(v803_9);
    let v803_12: Space = unite(&(v803_7),&(v803_11));
    join_wrapped_into(&mut v802_21_write,&((v803_12).read_zipper()),&[]);
    }
    v802_21_cursor.ascend(1);
  }
  drop(v802_21_cursor);
  drop(v802_21_write);
  (v802_21).clone()
}

fn routine_69(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v818_16 = Space::new();
  let mut v818_16_write = v818_16.write_zipper();
  let mut v818_16_cursor = (*s0).read_zipper();
  let v818_16_origin = v818_16_cursor.path().len();
  for v818_16_byte in v818_16_cursor.child_mask().iter() {
    v818_16_cursor.descend_to_existing_byte(v818_16_byte);
    {
    let v819_2: Space = singleton(&v818_16_cursor.path()[v818_16_origin..(v818_16_origin + 1)]);
    let v819_3: Space = intersect(&(*CONSTANT_9),&(v819_2));
    let v819_4: Space = if has_head(&(v819_3)) { singleton(&[]) } else { Space::new() };
    drop(v819_3);
    let v819_5: Space = subtract(&(*CONSTANT_0),&(v819_4));
    drop(v819_4);
    let v819_8: Space = if (&(v819_5)).is_empty() { Space::new() } else {
      let v820_6: Path = concat_path(&(*p0),&v818_16_cursor.path()[v818_16_origin..(v818_16_origin + 1)]);
      let v820_7: Space = routine_69(c, &(v820_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &v818_16_cursor);
      compose(&(v819_5),&(v820_7))
    };
    drop(v819_5);
    let v819_9: Space = intersect(&(*CONSTANT_9),&(v819_2));
    drop(v819_2);
    let v819_10: Space = if has_head(&(v819_9)) { singleton(&[]) } else { Space::new() };
    drop(v819_9);
    let v819_12: Space = if (&(v819_10)).is_empty() { Space::new() } else {
      let v821_6: Path = concat_path(&(*p0),&v818_16_cursor.path()[v818_16_origin..(v818_16_origin + 1)]);
      let mut v821_11 = Space::new();
      let mut v821_11_write = v821_11.write_zipper();
      for v821_11_byte in v818_16_cursor.child_mask().iter() {
        v818_16_cursor.descend_to_existing_byte(v821_11_byte);
        {
        let v822_2: Space = singleton(&v818_16_cursor.path()[(v818_16_origin + 1)..(v818_16_origin + 2)]);
        let v822_3: Space = intersect(&(*CONSTANT_9),&(v822_2));
        let v822_4: Space = if has_head(&(v822_3)) { singleton(&[]) } else { Space::new() };
        drop(v822_3);
        let v822_5: Space = subtract(&(*CONSTANT_0),&(v822_4));
        drop(v822_4);
        let v822_7: Space = if (&(v822_5)).is_empty() { Space::new() } else {
          let v823_6: Space = routine_77(c, &v818_16_cursor.path()[(v818_16_origin + 1)..(v818_16_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v821_6), &v818_16_cursor);
          compose(&(v822_5),&(v823_6))
        };
        drop(v822_5);
        let v822_8: Space = intersect(&(*CONSTANT_9),&(v822_2));
        drop(v822_2);
        let v822_9: Space = if has_head(&(v822_8)) { singleton(&[]) } else { Space::new() };
        drop(v822_8);
        let v822_11: Space = if (&(v822_9)).is_empty() { Space::new() } else {
          let mut v824_10 = Space::new();
          let mut v824_10_write = v824_10.write_zipper();
          for v824_10_byte in v818_16_cursor.child_mask().iter() {
            v818_16_cursor.descend_to_existing_byte(v824_10_byte);
            {
            let v825_2: Space = singleton(&v818_16_cursor.path()[(v818_16_origin + 2)..(v818_16_origin + 3)]);
            let v825_3: Space = intersect(&(*CONSTANT_9),&(v825_2));
            let v825_4: Space = if has_head(&(v825_3)) { singleton(&[]) } else { Space::new() };
            drop(v825_3);
            let v825_5: Space = subtract(&(*CONSTANT_0),&(v825_4));
            drop(v825_4);
            let v825_7: Space = if (&(v825_5)).is_empty() { Space::new() } else {
              let v826_6: Space = routine_79(c, &v818_16_cursor.path()[(v818_16_origin + 2)..(v818_16_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v821_6), &v818_16_cursor.path()[(v818_16_origin + 1)..(v818_16_origin + 2)], &v818_16_cursor);
              compose(&(v825_5),&(v826_6))
            };
            drop(v825_5);
            let v825_8: Space = intersect(&(*CONSTANT_9),&(v825_2));
            drop(v825_2);
            let v825_9: Space = if has_head(&(v825_8)) { singleton(&[]) } else { Space::new() };
            drop(v825_8);
            let v825_11: Space = if (&(v825_9)).is_empty() { Space::new() } else {
              let v827_10: Space = routine_80(c, &v818_16_cursor.path()[(v818_16_origin + 2)..(v818_16_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v821_6), &v818_16_cursor.path()[(v818_16_origin + 1)..(v818_16_origin + 2)], &v818_16_cursor);
              compose(&(v825_9),&(v827_10))
            };
            drop(v825_9);
            let v825_12: Space = unite(&(v825_7),&(v825_11));
            join_wrapped_into(&mut v824_10_write,&((v825_12).read_zipper()),&[]);
            }
            v818_16_cursor.ascend(1);
          }
          drop(v824_10_write);
          compose(&(v822_9),&(v824_10))
        };
        drop(v822_9);
        let v822_12: Space = unite(&(v822_7),&(v822_11));
        join_wrapped_into(&mut v821_11_write,&((v822_12).read_zipper()),&[]);
        }
        v818_16_cursor.ascend(1);
      }
      drop(v821_11_write);
      drop(v821_6);
      compose(&(v819_10),&(v821_11))
    };
    drop(v819_10);
    let v819_13: Space = unite(&(v819_8),&(v819_12));
    join_wrapped_into(&mut v818_16_write,&((v819_13).read_zipper()),&[]);
    }
    v818_16_cursor.ascend(1);
  }
  drop(v818_16_cursor);
  drop(v818_16_write);
  (v818_16).clone()
}

fn routine_70(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v828_16: Path = concat_path(&(*p1),&(*p2));
  let v828_20: Path = concat_path(&(v828_16),&(*p3));
  drop(v828_16);
  let v828_21: Path = concat_path(&(v828_20),&(*p4));
  drop(v828_20);
  let v828_22: Path = concat_path(&(v828_21),&(*p5));
  drop(v828_21);
  let v828_23: Path = concat_path(&(v828_22),&(*p0));
  drop(v828_22);
  let mut v828_24 = Space::new();
  let mut v828_24_write = v828_24.write_zipper();
  let mut v828_24_cursor = (*s0).read_zipper();
  let v828_24_origin = v828_24_cursor.path().len();
  for v828_24_byte in v828_24_cursor.child_mask().iter() {
    v828_24_cursor.descend_to_existing_byte(v828_24_byte);
    {
    let v829_2: Space = singleton(&v828_24_cursor.path()[v828_24_origin..(v828_24_origin + 1)]);
    let v829_3: Space = intersect(&(*CONSTANT_9),&(v829_2));
    let v829_4: Space = if has_head(&(v829_3)) { singleton(&[]) } else { Space::new() };
    drop(v829_3);
    let v829_5: Space = subtract(&(*CONSTANT_0),&(v829_4));
    drop(v829_4);
    let v829_7: Space = if (&(v829_5)).is_empty() { Space::new() } else {
      let mut v830_6 = Space::new();
      let mut v830_6_write = v830_6.write_zipper();
      for v830_6_byte in v828_24_cursor.child_mask().iter() {
        v828_24_cursor.descend_to_existing_byte(v830_6_byte);
        {
        let v831_2: Space = singleton(&v828_24_cursor.path()[(v828_24_origin + 1)..(v828_24_origin + 2)]);
        let v831_3: Space = intersect(&(*CONSTANT_9),&(v831_2));
        let v831_4: Space = if has_head(&(v831_3)) { singleton(&[]) } else { Space::new() };
        drop(v831_3);
        let v831_5: Space = subtract(&(*CONSTANT_0),&(v831_4));
        drop(v831_4);
        let v831_8: Space = if (&(v831_5)).is_empty() { Space::new() } else {
          let v832_7: Space = routine_77(c, &v828_24_cursor.path()[v828_24_origin..(v828_24_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v828_24_cursor);
          compose(&(v831_5),&(v832_7))
        };
        drop(v831_5);
        let v831_9: Space = intersect(&(*CONSTANT_9),&(v831_2));
        drop(v831_2);
        let v831_10: Space = if has_head(&(v831_9)) { singleton(&[]) } else { Space::new() };
        drop(v831_9);
        let v831_12: Space = if (&(v831_10)).is_empty() { Space::new() } else {
          let mut v833_11 = Space::new();
          let mut v833_11_write = v833_11.write_zipper();
          for v833_11_byte in v828_24_cursor.child_mask().iter() {
            v828_24_cursor.descend_to_existing_byte(v833_11_byte);
            {
            let v834_2: Space = singleton(&v828_24_cursor.path()[(v828_24_origin + 2)..(v828_24_origin + 3)]);
            let v834_3: Space = intersect(&(*CONSTANT_9),&(v834_2));
            let v834_4: Space = if has_head(&(v834_3)) { singleton(&[]) } else { Space::new() };
            drop(v834_3);
            let v834_5: Space = subtract(&(*CONSTANT_0),&(v834_4));
            drop(v834_4);
            let v834_7: Space = if (&(v834_5)).is_empty() { Space::new() } else {
              let v835_6: Space = routine_79(c, &v828_24_cursor.path()[(v828_24_origin + 2)..(v828_24_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v828_24_cursor.path()[v828_24_origin..(v828_24_origin + 2)], &v828_24_cursor);
              compose(&(v834_5),&(v835_6))
            };
            drop(v834_5);
            let v834_8: Space = intersect(&(*CONSTANT_9),&(v834_2));
            drop(v834_2);
            let v834_9: Space = if has_head(&(v834_8)) { singleton(&[]) } else { Space::new() };
            drop(v834_8);
            let v834_11: Space = if (&(v834_9)).is_empty() { Space::new() } else {
              let v836_10: Space = routine_80(c, &v828_24_cursor.path()[(v828_24_origin + 2)..(v828_24_origin + 3)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v828_24_cursor.path()[v828_24_origin..(v828_24_origin + 2)], &v828_24_cursor);
              compose(&(v834_9),&(v836_10))
            };
            drop(v834_9);
            let v834_12: Space = unite(&(v834_7),&(v834_11));
            join_wrapped_into(&mut v833_11_write,&((v834_12).read_zipper()),&[]);
            }
            v828_24_cursor.ascend(1);
          }
          drop(v833_11_write);
          compose(&(v831_10),&(v833_11))
        };
        drop(v831_10);
        let v831_13: Space = unite(&(v831_8),&(v831_12));
        join_wrapped_into(&mut v830_6_write,&((v831_13).read_zipper()),&[]);
        }
        v828_24_cursor.ascend(1);
      }
      drop(v830_6_write);
      compose(&(v829_5),&(v830_6))
    };
    drop(v829_5);
    let v829_8: Space = intersect(&(*CONSTANT_9),&(v829_2));
    drop(v829_2);
    let v829_9: Space = if has_head(&(v829_8)) { singleton(&[]) } else { Space::new() };
    drop(v829_8);
    let v829_12: Space = if (&(v829_9)).is_empty() { Space::new() } else {
      let v837_10: Path = concat_path(&(v828_23),&v828_24_cursor.path()[v828_24_origin..(v828_24_origin + 1)]);
      let mut v837_11 = Space::new();
      let mut v837_11_write = v837_11.write_zipper();
      for v837_11_byte in v828_24_cursor.child_mask().iter() {
        v828_24_cursor.descend_to_existing_byte(v837_11_byte);
        {
        let v838_2: Space = singleton(&v828_24_cursor.path()[(v828_24_origin + 1)..(v828_24_origin + 2)]);
        let v838_3: Space = intersect(&(*CONSTANT_9),&(v838_2));
        let v838_4: Space = if has_head(&(v838_3)) { singleton(&[]) } else { Space::new() };
        drop(v838_3);
        let v838_5: Space = subtract(&(*CONSTANT_0),&(v838_4));
        drop(v838_4);
        let v838_7: Space = if (&(v838_5)).is_empty() { Space::new() } else {
          let v839_6: Space = routine_79(c, &v828_24_cursor.path()[(v828_24_origin + 1)..(v828_24_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v828_24_cursor.path()[v828_24_origin..(v828_24_origin + 1)], &v828_24_cursor);
          compose(&(v838_5),&(v839_6))
        };
        drop(v838_5);
        let v838_8: Space = intersect(&(*CONSTANT_9),&(v838_2));
        drop(v838_2);
        let v838_9: Space = if has_head(&(v838_8)) { singleton(&[]) } else { Space::new() };
        drop(v838_8);
        let v838_12: Space = if (&(v838_9)).is_empty() { Space::new() } else {
          let v840_10: Path = concat_path(&(v837_10),&v828_24_cursor.path()[(v828_24_origin + 1)..(v828_24_origin + 2)]);
          let v840_11: Space = singleton(&(v840_10));
          drop(v840_10);
          compose(&(v838_9),&(v840_11))
        };
        drop(v838_9);
        let v838_13: Space = unite(&(v838_7),&(v838_12));
        drop(v838_12);
        join_wrapped_into(&mut v837_11_write,&((v838_13).read_zipper()),&[]);
        }
        v828_24_cursor.ascend(1);
      }
      drop(v837_11_write);
      drop(v837_10);
      compose(&(v829_9),&(v837_11))
    };
    drop(v829_9);
    let v829_13: Space = unite(&(v829_7),&(v829_12));
    join_wrapped_into(&mut v828_24_write,&((v829_13).read_zipper()),&[]);
    }
    v828_24_cursor.ascend(1);
  }
  drop(v828_24_cursor);
  drop(v828_24_write);
  drop(v828_23);
  (v828_24).clone()
}

fn routine_71(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v841_31: Path = concat_path(&(*p1),&(*p2));
  let v841_32: Path = concat_path(&(v841_31),&(*p3));
  drop(v841_31);
  let v841_33: Path = concat_path(&(v841_32),&(*p4));
  drop(v841_32);
  let v841_34: Path = concat_path(&(v841_33),&(*p5));
  drop(v841_33);
  let v841_35: Path = concat_path(&(v841_34),&(*p6));
  drop(v841_34);
  let mut v841_36 = Space::new();
  let mut v841_36_write = v841_36.write_zipper();
  let mut v841_36_cursor = (*s0).read_zipper();
  let v841_36_origin = v841_36_cursor.path().len();
  for v841_36_byte in v841_36_cursor.child_mask().iter() {
    v841_36_cursor.descend_to_existing_byte(v841_36_byte);
    {
    let v842_2: Space = singleton(&v841_36_cursor.path()[v841_36_origin..(v841_36_origin + 1)]);
    let v842_3: Space = intersect(&(*CONSTANT_9),&(v842_2));
    let v842_4: Space = if has_head(&(v842_3)) { singleton(&[]) } else { Space::new() };
    drop(v842_3);
    let v842_5: Space = subtract(&(*CONSTANT_0),&(v842_4));
    drop(v842_4);
    let v842_8: Space = if (&(v842_5)).is_empty() { Space::new() } else {
      let v843_6: Path = concat_path(&(*p0),&v841_36_cursor.path()[v841_36_origin..(v841_36_origin + 1)]);
      let v843_7: Space = routine_71(c, &(v843_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &v841_36_cursor, &(*s1));
      compose(&(v842_5),&(v843_7))
    };
    drop(v842_5);
    let v842_9: Space = intersect(&(*CONSTANT_9),&(v842_2));
    drop(v842_2);
    let v842_10: Space = if has_head(&(v842_9)) { singleton(&[]) } else { Space::new() };
    drop(v842_9);
    let v842_29: Space = if (&(v842_10)).is_empty() { Space::new() } else {
      let v844_26: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v845_6: Path = concat_path(&(*p0),&v841_36_cursor.path()[v841_36_origin..(v841_36_origin + 1)]);
        let v845_11: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_8), &(v845_6), &((*CONSTANT_9).read_zipper()));
        let v845_12: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_8), &(v845_6), &((*CONSTANT_9).read_zipper()));
        let v845_13: Space = unite(&(v845_11),&(v845_12));
        let v845_14: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_8), &(v845_6), &((*CONSTANT_9).read_zipper()));
        let v845_15: Space = unite(&(v845_13),&(v845_14));
        let v845_16: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_8), &(v845_6), &((*CONSTANT_9).read_zipper()));
        let v845_17: Space = unite(&(v845_15),&(v845_16));
        let v845_18: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_8), &(v845_6), &((*CONSTANT_9).read_zipper()));
        let v845_19: Space = unite(&(v845_17),&(v845_18));
        let v845_20: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_8), &(v845_6), &((*CONSTANT_9).read_zipper()));
        let v845_21: Space = unite(&(v845_19),&(v845_20));
        let v845_22: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_8), &(v845_6), &((*CONSTANT_9).read_zipper()));
        let v845_23: Space = unite(&(v845_21),&(v845_22));
        let v845_24: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_8), &(v845_6), &((*CONSTANT_9).read_zipper()));
        let v845_25: Space = unite(&(v845_23),&(v845_24));
        compose(&(*CONSTANT_0),&(v845_25))
      };
      let v844_27: Space = intersect(&(v844_26),&(*CONSTANT_21));
      let v844_28: Space = unite(&(v844_27),&(*s1));
      compose(&(v842_10),&(v844_28))
    };
    drop(v842_10);
    let v842_30: Space = wrap(&(v842_29),&(v841_35));
    let v846_6: Path = concat_path(&(*p0),&v841_36_cursor.path()[v841_36_origin..(v841_36_origin + 1)]);
    let v842_31: Space = wrap(&(v842_30),&(v846_6));
    let v842_32: Space = unite(&(v842_8),&(v842_31));
    join_wrapped_into(&mut v841_36_write,&((v842_32).read_zipper()),&[]);
    }
    v841_36_cursor.ascend(1);
  }
  drop(v841_36_cursor);
  drop(v841_36_write);
  drop(v841_35);
  (v841_36).clone()
}

fn routine_72(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v847_42: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v848_13: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_8), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v848_16: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_8), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v848_17: Space = unite(&(v848_13),&(v848_16));
    let v848_20: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_8), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v848_21: Space = unite(&(v848_17),&(v848_20));
    let v848_24: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_8), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v848_25: Space = unite(&(v848_21),&(v848_24));
    let v848_28: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_8), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v848_29: Space = unite(&(v848_25),&(v848_28));
    let v848_32: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_8), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v848_33: Space = unite(&(v848_29),&(v848_32));
    let v848_36: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_8), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v848_37: Space = unite(&(v848_33),&(v848_36));
    let v848_40: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_8), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v848_41: Space = unite(&(v848_37),&(v848_40));
    compose(&(*CONSTANT_0),&(v848_41))
  };
  let v847_44: Space = intersect(&(v847_42),&(*CONSTANT_21));
  let v847_45: Space = unite(&(v847_44),&(*s1));
  let v847_46: Path = concat_path(&(*p1),&(*p2));
  let v847_47: Path = concat_path(&(v847_46),&(*p3));
  drop(v847_46);
  let v847_48: Path = concat_path(&(v847_47),&(*p4));
  drop(v847_47);
  let v847_49: Path = concat_path(&(v847_48),&(*p5));
  drop(v847_48);
  let v847_50: Path = concat_path(&(v847_49),&(*p6));
  drop(v847_49);
  let v847_51: Space = wrap(&(v847_45),&(v847_50));
  drop(v847_50);
  let v847_52: Space = wrap(&(v847_51),&(*p0));
  (v847_52).clone()
}

fn routine_73(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v849_16: Path = concat_path(&(*p1),&(*p2));
  let v849_17: Path = concat_path(&(v849_16),&(*p3));
  drop(v849_16);
  let v849_18: Path = concat_path(&(v849_17),&(*p4));
  drop(v849_17);
  let v849_19: Path = concat_path(&(v849_18),&(*p5));
  drop(v849_18);
  let v849_20: Path = concat_path(&(v849_19),&(*p6));
  drop(v849_19);
  let mut v849_21 = Space::new();
  let mut v849_21_write = v849_21.write_zipper();
  let mut v849_21_cursor = (*s0).read_zipper();
  let v849_21_origin = v849_21_cursor.path().len();
  for v849_21_byte in v849_21_cursor.child_mask().iter() {
    v849_21_cursor.descend_to_existing_byte(v849_21_byte);
    {
    let v850_2: Space = singleton(&v849_21_cursor.path()[v849_21_origin..(v849_21_origin + 1)]);
    let v850_3: Space = intersect(&(*CONSTANT_9),&(v850_2));
    let v850_4: Space = if has_head(&(v850_3)) { singleton(&[]) } else { Space::new() };
    drop(v850_3);
    let v850_5: Space = subtract(&(*CONSTANT_0),&(v850_4));
    drop(v850_4);
    let v850_8: Space = if (&(v850_5)).is_empty() { Space::new() } else {
      let v851_6: Path = concat_path(&(*p0),&v849_21_cursor.path()[v849_21_origin..(v849_21_origin + 1)]);
      let v851_7: Space = routine_73(c, &(v851_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &v849_21_cursor);
      compose(&(v850_5),&(v851_7))
    };
    drop(v850_5);
    let v850_9: Space = intersect(&(*CONSTANT_9),&(v850_2));
    drop(v850_2);
    let v850_10: Space = if has_head(&(v850_9)) { singleton(&[]) } else { Space::new() };
    drop(v850_9);
    let v850_15: Space = if (&(v850_10)).is_empty() { Space::new() } else {
      let v852_6: Path = concat_path(&(*p0),&v849_21_cursor.path()[v849_21_origin..(v849_21_origin + 1)]);
      let v852_12: Space = subtract(&(*CONSTANT_10),&(descend_cursor(cursor_at(&v849_21_cursor,(v849_21_origin + 1)),&(*CONSTANT_2))));
      let v852_13: Path = concat_path(&(v849_20),&(v852_6));
      let mut v852_14 = Space::new();
      let mut v852_14_write = v852_14.write_zipper();
      let mut v852_14_cursor = (v852_12).read_zipper();
      let v852_14_origin = v852_14_cursor.path().len();
      for v852_14_byte in v852_14_cursor.child_mask().iter() {
        v852_14_cursor.descend_to_existing_byte(v852_14_byte);
        {
        let v853_2: Space = singleton(&v852_14_cursor.path()[v852_14_origin..(v852_14_origin + 1)]);
        let v853_3: Space = intersect(&(*CONSTANT_9),&(v853_2));
        let v853_4: Space = if has_head(&(v853_3)) { singleton(&[]) } else { Space::new() };
        drop(v853_3);
        let v853_5: Space = subtract(&(*CONSTANT_0),&(v853_4));
        drop(v853_4);
        let v853_7: Space = if (&(v853_5)).is_empty() { Space::new() } else {
          let v854_6: Space = routine_75(c, &v852_14_cursor.path()[v852_14_origin..(v852_14_origin + 1)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v852_6), &v852_14_cursor, &v849_21_cursor);
          compose(&(v853_5),&(v854_6))
        };
        drop(v853_5);
        let v853_8: Space = intersect(&(*CONSTANT_9),&(v853_2));
        drop(v853_2);
        let v853_9: Space = if has_head(&(v853_8)) { singleton(&[]) } else { Space::new() };
        drop(v853_8);
        let v853_12: Space = if (&(v853_9)).is_empty() { Space::new() } else {
          let v855_10: Space = routine_1(c, &v852_14_cursor.path()[v852_14_origin..(v852_14_origin + 1)], &(*CONSTANT_2), &(*CONSTANT_2));
          let v855_11: Space = unite(&v849_21_cursor,&(v855_10));
          compose(&(v853_9),&(v855_11))
        };
        drop(v853_9);
        let v853_13: Space = wrap(&(v853_12),&(v852_13));
        let v853_14: Space = wrap(&(v853_13),&v852_14_cursor.path()[v852_14_origin..(v852_14_origin + 1)]);
        let v853_15: Space = unite(&(v853_7),&(v853_14));
        join_wrapped_into(&mut v852_14_write,&((v853_15).read_zipper()),&[]);
        }
        v852_14_cursor.ascend(1);
      }
      drop(v852_14_cursor);
      drop(v852_14_write);
      drop(v852_6);
      drop(v852_12);
      drop(v852_13);
      compose(&(v850_10),&(v852_14))
    };
    drop(v850_10);
    let v850_16: Space = unite(&(v850_8),&(v850_15));
    join_wrapped_into(&mut v849_21_write,&((v850_16).read_zipper()),&[]);
    }
    v849_21_cursor.ascend(1);
  }
  drop(v849_21_cursor);
  drop(v849_21_write);
  drop(v849_20);
  (v849_21).clone()
}

fn routine_74(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v856_11: Space = subtract(&(*CONSTANT_10),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_2))));
  let v856_33: Path = concat_path(&(*p1),&(*p2));
  let v856_34: Path = concat_path(&(v856_33),&(*p3));
  drop(v856_33);
  let v856_35: Path = concat_path(&(v856_34),&(*p4));
  drop(v856_34);
  let v856_36: Path = concat_path(&(v856_35),&(*p5));
  drop(v856_35);
  let v856_37: Path = concat_path(&(v856_36),&(*p6));
  drop(v856_36);
  let v856_38: Path = concat_path(&(v856_37),&(*p0));
  drop(v856_37);
  let mut v856_42 = Space::new();
  let mut v856_42_write = v856_42.write_zipper();
  let mut v856_42_cursor = (v856_11).read_zipper();
  let v856_42_origin = v856_42_cursor.path().len();
  for v856_42_byte in v856_42_cursor.child_mask().iter() {
    v856_42_cursor.descend_to_existing_byte(v856_42_byte);
    {
    let v857_2: Space = singleton(&v856_42_cursor.path()[v856_42_origin..(v856_42_origin + 1)]);
    let v857_3: Space = intersect(&(*CONSTANT_9),&(v857_2));
    let v857_4: Space = if has_head(&(v857_3)) { singleton(&[]) } else { Space::new() };
    drop(v857_3);
    let v857_5: Space = subtract(&(*CONSTANT_0),&(v857_4));
    drop(v857_4);
    let v857_7: Space = if (&(v857_5)).is_empty() { Space::new() } else {
      let mut v858_6 = Space::new();
      let mut v858_6_write = v858_6.write_zipper();
      for v858_6_byte in v856_42_cursor.child_mask().iter() {
        v856_42_cursor.descend_to_existing_byte(v858_6_byte);
        {
        let v859_2: Space = singleton(&v856_42_cursor.path()[(v856_42_origin + 1)..(v856_42_origin + 2)]);
        let v859_3: Space = intersect(&(*CONSTANT_9),&(v859_2));
        let v859_4: Space = if has_head(&(v859_3)) { singleton(&[]) } else { Space::new() };
        drop(v859_3);
        let v859_5: Space = subtract(&(*CONSTANT_0),&(v859_4));
        drop(v859_4);
        let v859_8: Space = if (&(v859_5)).is_empty() { Space::new() } else {
          let v860_7: Space = routine_75(c, &v856_42_cursor.path()[v856_42_origin..(v856_42_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v856_42_cursor, &(*s0));
          compose(&(v859_5),&(v860_7))
        };
        drop(v859_5);
        let v859_9: Space = intersect(&(*CONSTANT_9),&(v859_2));
        drop(v859_2);
        let v859_10: Space = if has_head(&(v859_9)) { singleton(&[]) } else { Space::new() };
        drop(v859_9);
        let v859_13: Space = if (&(v859_10)).is_empty() { Space::new() } else {
          let v861_11: Space = routine_1(c, &v856_42_cursor.path()[v856_42_origin..(v856_42_origin + 2)], &(*CONSTANT_2), &(*CONSTANT_2));
          let v861_12: Space = unite(&(*s0),&(v861_11));
          compose(&(v859_10),&(v861_12))
        };
        drop(v859_10);
        let v859_14: Space = wrap(&(v859_13),&(v856_38));
        let v859_15: Space = wrap(&(v859_14),&v856_42_cursor.path()[v856_42_origin..(v856_42_origin + 2)]);
        let v859_16: Space = unite(&(v859_8),&(v859_15));
        join_wrapped_into(&mut v858_6_write,&((v859_16).read_zipper()),&[]);
        }
        v856_42_cursor.ascend(1);
      }
      drop(v858_6_write);
      compose(&(v857_5),&(v858_6))
    };
    drop(v857_5);
    let v857_8: Space = intersect(&(*CONSTANT_9),&(v857_2));
    drop(v857_2);
    let v857_9: Space = if has_head(&(v857_8)) { singleton(&[]) } else { Space::new() };
    drop(v857_8);
    let v857_28: Space = if (&(v857_9)).is_empty() { Space::new() } else {
      let v863_25: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v864_10: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_2), &v856_42_cursor.path()[v856_42_origin..(v856_42_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v864_11: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_2), &v856_42_cursor.path()[v856_42_origin..(v856_42_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v864_12: Space = unite(&(v864_10),&(v864_11));
        let v864_13: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_2), &v856_42_cursor.path()[v856_42_origin..(v856_42_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v864_14: Space = unite(&(v864_12),&(v864_13));
        let v864_15: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_2), &v856_42_cursor.path()[v856_42_origin..(v856_42_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v864_16: Space = unite(&(v864_14),&(v864_15));
        let v864_17: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_2), &v856_42_cursor.path()[v856_42_origin..(v856_42_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v864_18: Space = unite(&(v864_16),&(v864_17));
        let v864_19: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_2), &v856_42_cursor.path()[v856_42_origin..(v856_42_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v864_20: Space = unite(&(v864_18),&(v864_19));
        let v864_21: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_2), &v856_42_cursor.path()[v856_42_origin..(v856_42_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v864_22: Space = unite(&(v864_20),&(v864_21));
        let v864_23: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_2), &v856_42_cursor.path()[v856_42_origin..(v856_42_origin + 1)], &((*CONSTANT_9).read_zipper()));
        let v864_24: Space = unite(&(v864_22),&(v864_23));
        compose(&(*CONSTANT_0),&(v864_24))
      };
      let v863_26: Space = intersect(&(v863_25),&(*CONSTANT_21));
      let v863_27: Space = unite(&(v863_26),&(*s0));
      compose(&(v857_9),&(v863_27))
    };
    drop(v857_9);
    let v857_29: Space = wrap(&(v857_28),&(v856_38));
    let v857_30: Space = wrap(&(v857_29),&v856_42_cursor.path()[v856_42_origin..(v856_42_origin + 1)]);
    let v857_31: Space = unite(&(v857_7),&(v857_30));
    join_wrapped_into(&mut v856_42_write,&((v857_31).read_zipper()),&[]);
    }
    v856_42_cursor.ascend(1);
  }
  drop(v856_42_cursor);
  drop(v856_42_write);
  drop(v856_11);
  drop(v856_38);
  (v856_42).clone()
}

fn routine_75(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v865_32: Path = concat_path(&(*p1),&(*p2));
  let v865_33: Path = concat_path(&(v865_32),&(*p3));
  drop(v865_32);
  let v865_34: Path = concat_path(&(v865_33),&(*p4));
  drop(v865_33);
  let v865_35: Path = concat_path(&(v865_34),&(*p5));
  drop(v865_34);
  let v865_36: Path = concat_path(&(v865_35),&(*p6));
  drop(v865_35);
  let v865_37: Path = concat_path(&(v865_36),&(*p7));
  drop(v865_36);
  let mut v865_38 = Space::new();
  let mut v865_38_write = v865_38.write_zipper();
  let mut v865_38_cursor = (*s0).read_zipper();
  let v865_38_origin = v865_38_cursor.path().len();
  for v865_38_byte in v865_38_cursor.child_mask().iter() {
    v865_38_cursor.descend_to_existing_byte(v865_38_byte);
    {
    let v866_2: Space = singleton(&v865_38_cursor.path()[v865_38_origin..(v865_38_origin + 1)]);
    let v866_3: Space = intersect(&(*CONSTANT_9),&(v866_2));
    let v866_4: Space = if has_head(&(v866_3)) { singleton(&[]) } else { Space::new() };
    drop(v866_3);
    let v866_5: Space = subtract(&(*CONSTANT_0),&(v866_4));
    drop(v866_4);
    let v866_8: Space = if (&(v866_5)).is_empty() { Space::new() } else {
      let v867_6: Path = concat_path(&(*p0),&v865_38_cursor.path()[v865_38_origin..(v865_38_origin + 1)]);
      let v867_7: Space = routine_75(c, &(v867_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &v865_38_cursor, &(*s1));
      compose(&(v866_5),&(v867_7))
    };
    drop(v866_5);
    let v866_9: Space = intersect(&(*CONSTANT_9),&(v866_2));
    drop(v866_2);
    let v866_10: Space = if has_head(&(v866_9)) { singleton(&[]) } else { Space::new() };
    drop(v866_9);
    let v866_29: Space = if (&(v866_10)).is_empty() { Space::new() } else {
      let v868_26: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v869_6: Path = concat_path(&(*p0),&v865_38_cursor.path()[v865_38_origin..(v865_38_origin + 1)]);
        let v869_11: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_2), &(v869_6), &((*CONSTANT_9).read_zipper()));
        let v869_12: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_2), &(v869_6), &((*CONSTANT_9).read_zipper()));
        let v869_13: Space = unite(&(v869_11),&(v869_12));
        let v869_14: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_2), &(v869_6), &((*CONSTANT_9).read_zipper()));
        let v869_15: Space = unite(&(v869_13),&(v869_14));
        let v869_16: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_2), &(v869_6), &((*CONSTANT_9).read_zipper()));
        let v869_17: Space = unite(&(v869_15),&(v869_16));
        let v869_18: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_2), &(v869_6), &((*CONSTANT_9).read_zipper()));
        let v869_19: Space = unite(&(v869_17),&(v869_18));
        let v869_20: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_2), &(v869_6), &((*CONSTANT_9).read_zipper()));
        let v869_21: Space = unite(&(v869_19),&(v869_20));
        let v869_22: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_2), &(v869_6), &((*CONSTANT_9).read_zipper()));
        let v869_23: Space = unite(&(v869_21),&(v869_22));
        let v869_24: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_2), &(v869_6), &((*CONSTANT_9).read_zipper()));
        let v869_25: Space = unite(&(v869_23),&(v869_24));
        compose(&(*CONSTANT_0),&(v869_25))
      };
      let v868_27: Space = intersect(&(v868_26),&(*CONSTANT_21));
      let v868_28: Space = unite(&(v868_27),&(*s1));
      compose(&(v866_10),&(v868_28))
    };
    drop(v866_10);
    let v866_30: Space = wrap(&(v866_29),&(v865_37));
    let v870_6: Path = concat_path(&(*p0),&v865_38_cursor.path()[v865_38_origin..(v865_38_origin + 1)]);
    let v866_31: Space = wrap(&(v866_30),&(v870_6));
    let v866_32: Space = unite(&(v866_8),&(v866_31));
    join_wrapped_into(&mut v865_38_write,&((v866_32).read_zipper()),&[]);
    }
    v865_38_cursor.ascend(1);
  }
  drop(v865_38_cursor);
  drop(v865_38_write);
  drop(v865_37);
  (v865_38).clone()
}

fn routine_76(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v871_43: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v872_14: Space = routine_40(c, &(*CONSTANT_13), &(*CONSTANT_2), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v872_17: Space = routine_40(c, &(*CONSTANT_14), &(*CONSTANT_2), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v872_18: Space = unite(&(v872_14),&(v872_17));
    let v872_21: Space = routine_40(c, &(*CONSTANT_15), &(*CONSTANT_2), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v872_22: Space = unite(&(v872_18),&(v872_21));
    let v872_25: Space = routine_40(c, &(*CONSTANT_16), &(*CONSTANT_2), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v872_26: Space = unite(&(v872_22),&(v872_25));
    let v872_29: Space = routine_40(c, &(*CONSTANT_17), &(*CONSTANT_2), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v872_30: Space = unite(&(v872_26),&(v872_29));
    let v872_33: Space = routine_40(c, &(*CONSTANT_18), &(*CONSTANT_2), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v872_34: Space = unite(&(v872_30),&(v872_33));
    let v872_37: Space = routine_40(c, &(*CONSTANT_19), &(*CONSTANT_2), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v872_38: Space = unite(&(v872_34),&(v872_37));
    let v872_41: Space = routine_40(c, &(*CONSTANT_20), &(*CONSTANT_2), &(*p0), &((*CONSTANT_9).read_zipper()));
    let v872_42: Space = unite(&(v872_38),&(v872_41));
    compose(&(*CONSTANT_0),&(v872_42))
  };
  let v871_45: Space = intersect(&(v871_43),&(*CONSTANT_21));
  let v871_46: Space = unite(&(v871_45),&(*s1));
  let v871_47: Path = concat_path(&(*p1),&(*p2));
  let v871_48: Path = concat_path(&(v871_47),&(*p3));
  drop(v871_47);
  let v871_49: Path = concat_path(&(v871_48),&(*p4));
  drop(v871_48);
  let v871_50: Path = concat_path(&(v871_49),&(*p5));
  drop(v871_49);
  let v871_51: Path = concat_path(&(v871_50),&(*p6));
  drop(v871_50);
  let v871_52: Path = concat_path(&(v871_51),&(*p7));
  drop(v871_51);
  let v871_53: Space = wrap(&(v871_46),&(v871_52));
  drop(v871_52);
  let v871_54: Space = wrap(&(v871_53),&(*p0));
  (v871_54).clone()
}

fn routine_77(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v873_14: Path = concat_path(&(*p1),&(*p2));
  let v873_15: Path = concat_path(&(v873_14),&(*p3));
  drop(v873_14);
  let v873_16: Path = concat_path(&(v873_15),&(*p4));
  drop(v873_15);
  let v873_17: Path = concat_path(&(v873_16),&(*p5));
  drop(v873_16);
  let v873_18: Path = concat_path(&(v873_17),&(*p6));
  drop(v873_17);
  let mut v873_19 = Space::new();
  let mut v873_19_write = v873_19.write_zipper();
  let mut v873_19_cursor = (*s0).read_zipper();
  let v873_19_origin = v873_19_cursor.path().len();
  for v873_19_byte in v873_19_cursor.child_mask().iter() {
    v873_19_cursor.descend_to_existing_byte(v873_19_byte);
    {
    let v874_2: Space = singleton(&v873_19_cursor.path()[v873_19_origin..(v873_19_origin + 1)]);
    let v874_3: Space = intersect(&(*CONSTANT_9),&(v874_2));
    let v874_4: Space = if has_head(&(v874_3)) { singleton(&[]) } else { Space::new() };
    drop(v874_3);
    let v874_5: Space = subtract(&(*CONSTANT_0),&(v874_4));
    drop(v874_4);
    let v874_8: Space = if (&(v874_5)).is_empty() { Space::new() } else {
      let v875_6: Path = concat_path(&(*p0),&v873_19_cursor.path()[v873_19_origin..(v873_19_origin + 1)]);
      let v875_7: Space = routine_77(c, &(v875_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &v873_19_cursor);
      compose(&(v874_5),&(v875_7))
    };
    drop(v874_5);
    let v874_9: Space = intersect(&(*CONSTANT_9),&(v874_2));
    drop(v874_2);
    let v874_10: Space = if has_head(&(v874_9)) { singleton(&[]) } else { Space::new() };
    drop(v874_9);
    let v874_13: Space = if (&(v874_10)).is_empty() { Space::new() } else {
      let v876_6: Path = concat_path(&(*p0),&v873_19_cursor.path()[v873_19_origin..(v873_19_origin + 1)]);
      let v876_11: Path = concat_path(&(v873_18),&(v876_6));
      let mut v876_12 = Space::new();
      let mut v876_12_write = v876_12.write_zipper();
      for v876_12_byte in v873_19_cursor.child_mask().iter() {
        v873_19_cursor.descend_to_existing_byte(v876_12_byte);
        {
        let v877_2: Space = singleton(&v873_19_cursor.path()[(v873_19_origin + 1)..(v873_19_origin + 2)]);
        let v877_3: Space = intersect(&(*CONSTANT_9),&(v877_2));
        let v877_4: Space = if has_head(&(v877_3)) { singleton(&[]) } else { Space::new() };
        drop(v877_3);
        let v877_5: Space = subtract(&(*CONSTANT_0),&(v877_4));
        drop(v877_4);
        let v877_7: Space = if (&(v877_5)).is_empty() { Space::new() } else {
          let v878_6: Space = routine_79(c, &v873_19_cursor.path()[(v873_19_origin + 1)..(v873_19_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v876_6), &v873_19_cursor);
          compose(&(v877_5),&(v878_6))
        };
        drop(v877_5);
        let v877_8: Space = intersect(&(*CONSTANT_9),&(v877_2));
        drop(v877_2);
        let v877_9: Space = if has_head(&(v877_8)) { singleton(&[]) } else { Space::new() };
        drop(v877_8);
        let v877_12: Space = if (&(v877_9)).is_empty() { Space::new() } else {
          let v879_10: Path = concat_path(&(v876_11),&v873_19_cursor.path()[(v873_19_origin + 1)..(v873_19_origin + 2)]);
          let v879_11: Space = singleton(&(v879_10));
          drop(v879_10);
          compose(&(v877_9),&(v879_11))
        };
        drop(v877_9);
        let v877_13: Space = unite(&(v877_7),&(v877_12));
        drop(v877_12);
        join_wrapped_into(&mut v876_12_write,&((v877_13).read_zipper()),&[]);
        }
        v873_19_cursor.ascend(1);
      }
      drop(v876_12_write);
      drop(v876_6);
      drop(v876_11);
      compose(&(v874_10),&(v876_12))
    };
    drop(v874_10);
    let v874_14: Space = unite(&(v874_8),&(v874_13));
    join_wrapped_into(&mut v873_19_write,&((v874_14).read_zipper()),&[]);
    }
    v873_19_cursor.ascend(1);
  }
  drop(v873_19_cursor);
  drop(v873_19_write);
  drop(v873_18);
  (v873_19).clone()
}

fn routine_78(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], s0: &View<'_, '_>) -> Space {
  let v880_11: Path = concat_path(&(*p1),&(*p2));
  let v880_12: Path = concat_path(&(v880_11),&(*p3));
  drop(v880_11);
  let v880_13: Path = concat_path(&(v880_12),&(*p4));
  drop(v880_12);
  let v880_14: Path = concat_path(&(v880_13),&(*p5));
  drop(v880_13);
  let v880_15: Path = concat_path(&(v880_14),&(*p6));
  drop(v880_14);
  let v880_16: Path = concat_path(&(v880_15),&(*p0));
  drop(v880_15);
  let mut v880_20 = Space::new();
  let mut v880_20_write = v880_20.write_zipper();
  let mut v880_20_cursor = (*s0).read_zipper();
  let v880_20_origin = v880_20_cursor.path().len();
  for v880_20_byte in v880_20_cursor.child_mask().iter() {
    v880_20_cursor.descend_to_existing_byte(v880_20_byte);
    {
    let v881_2: Space = singleton(&v880_20_cursor.path()[v880_20_origin..(v880_20_origin + 1)]);
    let v881_3: Space = intersect(&(*CONSTANT_9),&(v881_2));
    let v881_4: Space = if has_head(&(v881_3)) { singleton(&[]) } else { Space::new() };
    drop(v881_3);
    let v881_5: Space = subtract(&(*CONSTANT_0),&(v881_4));
    drop(v881_4);
    let v881_7: Space = if (&(v881_5)).is_empty() { Space::new() } else {
      let mut v882_6 = Space::new();
      let mut v882_6_write = v882_6.write_zipper();
      for v882_6_byte in v880_20_cursor.child_mask().iter() {
        v880_20_cursor.descend_to_existing_byte(v882_6_byte);
        {
        let v883_2: Space = singleton(&v880_20_cursor.path()[(v880_20_origin + 1)..(v880_20_origin + 2)]);
        let v883_3: Space = intersect(&(*CONSTANT_9),&(v883_2));
        let v883_4: Space = if has_head(&(v883_3)) { singleton(&[]) } else { Space::new() };
        drop(v883_3);
        let v883_5: Space = subtract(&(*CONSTANT_0),&(v883_4));
        drop(v883_4);
        let v883_8: Space = if (&(v883_5)).is_empty() { Space::new() } else {
          let v884_7: Space = routine_79(c, &v880_20_cursor.path()[v880_20_origin..(v880_20_origin + 2)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &v880_20_cursor);
          compose(&(v883_5),&(v884_7))
        };
        drop(v883_5);
        let v883_9: Space = intersect(&(*CONSTANT_9),&(v883_2));
        drop(v883_2);
        let v883_10: Space = if has_head(&(v883_9)) { singleton(&[]) } else { Space::new() };
        drop(v883_9);
        let v883_13: Space = if (&(v883_10)).is_empty() { Space::new() } else {
          let v885_11: Path = concat_path(&(v880_16),&v880_20_cursor.path()[v880_20_origin..(v880_20_origin + 2)]);
          let v885_12: Space = singleton(&(v885_11));
          drop(v885_11);
          compose(&(v883_10),&(v885_12))
        };
        drop(v883_10);
        let v883_14: Space = unite(&(v883_8),&(v883_13));
        drop(v883_13);
        join_wrapped_into(&mut v882_6_write,&((v883_14).read_zipper()),&[]);
        }
        v880_20_cursor.ascend(1);
      }
      drop(v882_6_write);
      compose(&(v881_5),&(v882_6))
    };
    drop(v881_5);
    let v881_8: Space = intersect(&(*CONSTANT_9),&(v881_2));
    drop(v881_2);
    let v881_9: Space = if has_head(&(v881_8)) { singleton(&[]) } else { Space::new() };
    drop(v881_8);
    let v881_12: Space = if (&(v881_9)).is_empty() { Space::new() } else {
      let v886_10: Path = concat_path(&(v880_16),&v880_20_cursor.path()[v880_20_origin..(v880_20_origin + 1)]);
      let v886_11: Space = singleton(&(v886_10));
      drop(v886_10);
      compose(&(v881_9),&(v886_11))
    };
    drop(v881_9);
    let v881_13: Space = unite(&(v881_7),&(v881_12));
    drop(v881_12);
    join_wrapped_into(&mut v880_20_write,&((v881_13).read_zipper()),&[]);
    }
    v880_20_cursor.ascend(1);
  }
  drop(v880_20_cursor);
  drop(v880_20_write);
  drop(v880_16);
  (v880_20).clone()
}

fn routine_79(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v887_12: Path = concat_path(&(*p1),&(*p2));
  let v887_13: Path = concat_path(&(v887_12),&(*p3));
  drop(v887_12);
  let v887_14: Path = concat_path(&(v887_13),&(*p4));
  drop(v887_13);
  let v887_15: Path = concat_path(&(v887_14),&(*p5));
  drop(v887_14);
  let v887_16: Path = concat_path(&(v887_15),&(*p6));
  drop(v887_15);
  let v887_17: Path = concat_path(&(v887_16),&(*p7));
  drop(v887_16);
  let mut v887_18 = Space::new();
  let mut v887_18_write = v887_18.write_zipper();
  let mut v887_18_cursor = (*s0).read_zipper();
  let v887_18_origin = v887_18_cursor.path().len();
  for v887_18_byte in v887_18_cursor.child_mask().iter() {
    v887_18_cursor.descend_to_existing_byte(v887_18_byte);
    {
    let v888_2: Space = singleton(&v887_18_cursor.path()[v887_18_origin..(v887_18_origin + 1)]);
    let v888_3: Space = intersect(&(*CONSTANT_9),&(v888_2));
    let v888_4: Space = if has_head(&(v888_3)) { singleton(&[]) } else { Space::new() };
    drop(v888_3);
    let v888_5: Space = subtract(&(*CONSTANT_0),&(v888_4));
    drop(v888_4);
    let v888_8: Space = if (&(v888_5)).is_empty() { Space::new() } else {
      let v889_6: Path = concat_path(&(*p0),&v887_18_cursor.path()[v887_18_origin..(v887_18_origin + 1)]);
      let v889_7: Space = routine_79(c, &(v889_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &v887_18_cursor);
      compose(&(v888_5),&(v889_7))
    };
    drop(v888_5);
    let v888_9: Space = intersect(&(*CONSTANT_9),&(v888_2));
    drop(v888_2);
    let v888_10: Space = if has_head(&(v888_9)) { singleton(&[]) } else { Space::new() };
    drop(v888_9);
    let v888_13: Space = if (&(v888_10)).is_empty() { Space::new() } else {
      let v890_6: Path = concat_path(&(*p0),&v887_18_cursor.path()[v887_18_origin..(v887_18_origin + 1)]);
      let v890_11: Path = concat_path(&(v887_17),&(v890_6));
      drop(v890_6);
      let v890_12: Space = singleton(&(v890_11));
      drop(v890_11);
      compose(&(v888_10),&(v890_12))
    };
    drop(v888_10);
    let v888_14: Space = unite(&(v888_8),&(v888_13));
    drop(v888_13);
    join_wrapped_into(&mut v887_18_write,&((v888_14).read_zipper()),&[]);
    }
    v887_18_cursor.ascend(1);
  }
  drop(v887_18_cursor);
  drop(v887_18_write);
  drop(v887_17);
  (v887_18).clone()
}

fn routine_80(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v891_9: Path = concat_path(&(*p1),&(*p2));
  let v891_10: Path = concat_path(&(v891_9),&(*p3));
  drop(v891_9);
  let v891_11: Path = concat_path(&(v891_10),&(*p4));
  drop(v891_10);
  let v891_12: Path = concat_path(&(v891_11),&(*p5));
  drop(v891_11);
  let v891_13: Path = concat_path(&(v891_12),&(*p6));
  drop(v891_12);
  let v891_14: Path = concat_path(&(v891_13),&(*p7));
  drop(v891_13);
  let v891_15: Path = concat_path(&(v891_14),&(*p0));
  drop(v891_14);
  let v891_16: Space = singleton(&(v891_15));
  drop(v891_15);
  (v891_16).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
