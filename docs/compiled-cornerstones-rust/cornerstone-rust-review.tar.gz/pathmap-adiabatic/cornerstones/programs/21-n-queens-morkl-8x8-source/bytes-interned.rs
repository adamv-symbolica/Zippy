#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,7]));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,2]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,3]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,4]));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,5]));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,6]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 4 0 0 0 0 4 0 0 0 1 4 0 0 0 2 4 0 0 0 3 4 0 0 0 4 4 0 0 0 5 4 0 0 0 6 4 0 0 0 7"));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("36 8 0 0 0 0 0 0 0 0 8 0 0 0 1 0 0 0 0 8 0 0 0 1 0 0 0 1 8 0 0 0 2 0 0 0 0 8 0 0 0 2 0 0 0 1 8 0 0 0 2 0 0 0 2 8 0 0 0 3 0 0 0 0 8 0 0 0 3 0 0 0 1 8 0 0 0 3 0 0 0 2 8 0 0 0 3 0 0 0 3 8 0 0 0 4 0 0 0 0 8 0 0 0 4 0 0 0 1 8 0 0 0 4 0 0 0 2 8 0 0 0 4 0 0 0 3 8 0 0 0 4 0 0 0 4 8 0 0 0 5 0 0 0 0 8 0 0 0 5 0 0 0 1 8 0 0 0 5 0 0 0 2 8 0 0 0 5 0 0 0 3 8 0 0 0 5 0 0 0 4 8 0 0 0 5 0 0 0 5 8 0 0 0 6 0 0 0 0 8 0 0 0 6 0 0 0 1 8 0 0 0 6 0 0 0 2 8 0 0 0 6 0 0 0 3 8 0 0 0 6 0 0 0 4 8 0 0 0 6 0 0 0 5 8 0 0 0 6 0 0 0 6 8 0 0 0 7 0 0 0 0 8 0 0 0 7 0 0 0 1 8 0 0 0 7 0 0 0 2 8 0 0 0 7 0 0 0 3 8 0 0 0 7 0 0 0 4 8 0 0 0 7 0 0 0 5 8 0 0 0 7 0 0 0 6 8 0 0 0 7 0 0 0 7"));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("100 12 0 0 0 0 0 0 0 0 0 0 0 1 12 0 0 0 0 0 0 0 0 0 0 0 16 12 0 0 0 0 0 0 0 1 0 0 0 2 12 0 0 0 0 0 0 0 2 0 0 0 3 12 0 0 0 0 0 0 0 3 0 0 0 4 12 0 0 0 0 0 0 0 4 0 0 0 5 12 0 0 0 0 0 0 0 5 0 0 0 6 12 0 0 0 0 0 0 0 6 0 0 0 7 12 0 0 0 0 0 0 0 7 0 0 0 8 12 0 0 0 1 0 0 0 0 0 0 0 0 12 0 0 0 1 0 0 0 0 0 0 0 2 12 0 0 0 1 0 0 0 1 0 0 0 3 12 0 0 0 1 0 0 0 1 0 0 0 16 12 0 0 0 1 0 0 0 2 0 0 0 4 12 0 0 0 1 0 0 0 3 0 0 0 5 12 0 0 0 1 0 0 0 4 0 0 0 6 12 0 0 0 1 0 0 0 5 0 0 0 7 12 0 0 0 1 0 0 0 6 0 0 0 8 12 0 0 0 1 0 0 0 7 0 0 0 9 12 0 0 0 2 0 0 0 0 0 0 0 1 12 0 0 0 2 0 0 0 0 0 0 0 3 12 0 0 0 2 0 0 0 1 0 0 0 0 12 0 0 0 2 0 0 0 1 0 0 0 4 12 0 0 0 2 0 0 0 2 0 0 0 5 12 0 0 0 2 0 0 0 2 0 0 0 16 12 0 0 0 2 0 0 0 3 0 0 0 6 12 0 0 0 2 0 0 0 4 0 0 0 7 12 0 0 0 2 0 0 0 5 0 0 0 8 12 0 0 0 2 0 0 0 6 0 0 0 9 12 0 0 0 2 0 0 0 7 0 0 0 10 12 0 0 0 3 0 0 0 0 0 0 0 2 12 0 0 0 3 0 0 0 0 0 0 0 4 12 0 0 0 3 0 0 0 1 0 0 0 1 12 0 0 0 3 0 0 0 1 0 0 0 5 12 0 0 0 3 0 0 0 2 0 0 0 0 12 0 0 0 3 0 0 0 2 0 0 0 6 12 0 0 0 3 0 0 0 3 0 0 0 7 12 0 0 0 3 0 0 0 3 0 0 0 16 12 0 0 0 3 0 0 0 4 0 0 0 8 12 0 0 0 3 0 0 0 5 0 0 0 9 12 0 0 0 3 0 0 0 6 0 0 0 10 12 0 0 0 3 0 0 0 7 0 0 0 11 12 0 0 0 4 0 0 0 0 0 0 0 3 12 0 0 0 4 0 0 0 0 0 0 0 5 12 0 0 0 4 0 0 0 1 0 0 0 2 12 0 0 0 4 0 0 0 1 0 0 0 6 12 0 0 0 4 0 0 0 2 0 0 0 1 12 0 0 0 4 0 0 0 2 0 0 0 7 12 0 0 0 4 0 0 0 3 0 0 0 0 12 0 0 0 4 0 0 0 3 0 0 0 8 12 0 0 0 4 0 0 0 4 0 0 0 9 12 0 0 0 4 0 0 0 4 0 0 0 16 12 0 0 0 4 0 0 0 5 0 0 0 10 12 0 0 0 4 0 0 0 6 0 0 0 11 12 0 0 0 4 0 0 0 7 0 0 0 12 12 0 0 0 5 0 0 0 0 0 0 0 4 12 0 0 0 5 0 0 0 0 0 0 0 6 12 0 0 0 5 0 0 0 1 0 0 0 3 12 0 0 0 5 0 0 0 1 0 0 0 7 12 0 0 0 5 0 0 0 2 0 0 0 2 12 0 0 0 5 0 0 0 2 0 0 0 8 12 0 0 0 5 0 0 0 3 0 0 0 1 12 0 0 0 5 0 0 0 3 0 0 0 9 12 0 0 0 5 0 0 0 4 0 0 0 0 12 0 0 0 5 0 0 0 4 0 0 0 10 12 0 0 0 5 0 0 0 5 0 0 0 11 12 0 0 0 5 0 0 0 5 0 0 0 16 12 0 0 0 5 0 0 0 6 0 0 0 12 12 0 0 0 5 0 0 0 7 0 0 0 13 12 0 0 0 6 0 0 0 0 0 0 0 5 12 0 0 0 6 0 0 0 0 0 0 0 7 12 0 0 0 6 0 0 0 1 0 0 0 4 12 0 0 0 6 0 0 0 1 0 0 0 8 12 0 0 0 6 0 0 0 2 0 0 0 3 12 0 0 0 6 0 0 0 2 0 0 0 9 12 0 0 0 6 0 0 0 3 0 0 0 2 12 0 0 0 6 0 0 0 3 0 0 0 10 12 0 0 0 6 0 0 0 4 0 0 0 1 12 0 0 0 6 0 0 0 4 0 0 0 11 12 0 0 0 6 0 0 0 5 0 0 0 0 12 0 0 0 6 0 0 0 5 0 0 0 12 12 0 0 0 6 0 0 0 6 0 0 0 13 12 0 0 0 6 0 0 0 6 0 0 0 16 12 0 0 0 6 0 0 0 7 0 0 0 14 12 0 0 0 7 0 0 0 0 0 0 0 6 12 0 0 0 7 0 0 0 0 0 0 0 8 12 0 0 0 7 0 0 0 1 0 0 0 5 12 0 0 0 7 0 0 0 1 0 0 0 9 12 0 0 0 7 0 0 0 2 0 0 0 4 12 0 0 0 7 0 0 0 2 0 0 0 10 12 0 0 0 7 0 0 0 3 0 0 0 3 12 0 0 0 7 0 0 0 3 0 0 0 11 12 0 0 0 7 0 0 0 4 0 0 0 2 12 0 0 0 7 0 0 0 4 0 0 0 12 12 0 0 0 7 0 0 0 5 0 0 0 1 12 0 0 0 7 0 0 0 5 0 0 0 13 12 0 0 0 7 0 0 0 6 0 0 0 0 12 0 0 0 7 0 0 0 6 0 0 0 14 12 0 0 0 7 0 0 0 7 0 0 0 15 12 0 0 0 7 0 0 0 7 0 0 0 16"));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("64 8 0 0 0 0 0 0 0 0 8 0 0 0 0 0 0 0 1 8 0 0 0 0 0 0 0 2 8 0 0 0 0 0 0 0 3 8 0 0 0 0 0 0 0 4 8 0 0 0 0 0 0 0 5 8 0 0 0 0 0 0 0 6 8 0 0 0 0 0 0 0 7 8 0 0 0 1 0 0 0 0 8 0 0 0 1 0 0 0 1 8 0 0 0 1 0 0 0 2 8 0 0 0 1 0 0 0 3 8 0 0 0 1 0 0 0 4 8 0 0 0 1 0 0 0 5 8 0 0 0 1 0 0 0 6 8 0 0 0 1 0 0 0 7 8 0 0 0 2 0 0 0 0 8 0 0 0 2 0 0 0 1 8 0 0 0 2 0 0 0 2 8 0 0 0 2 0 0 0 3 8 0 0 0 2 0 0 0 4 8 0 0 0 2 0 0 0 5 8 0 0 0 2 0 0 0 6 8 0 0 0 2 0 0 0 7 8 0 0 0 3 0 0 0 0 8 0 0 0 3 0 0 0 1 8 0 0 0 3 0 0 0 2 8 0 0 0 3 0 0 0 3 8 0 0 0 3 0 0 0 4 8 0 0 0 3 0 0 0 5 8 0 0 0 3 0 0 0 6 8 0 0 0 3 0 0 0 7 8 0 0 0 4 0 0 0 0 8 0 0 0 4 0 0 0 1 8 0 0 0 4 0 0 0 2 8 0 0 0 4 0 0 0 3 8 0 0 0 4 0 0 0 4 8 0 0 0 4 0 0 0 5 8 0 0 0 4 0 0 0 6 8 0 0 0 4 0 0 0 7 8 0 0 0 5 0 0 0 0 8 0 0 0 5 0 0 0 1 8 0 0 0 5 0 0 0 2 8 0 0 0 5 0 0 0 3 8 0 0 0 5 0 0 0 4 8 0 0 0 5 0 0 0 5 8 0 0 0 5 0 0 0 6 8 0 0 0 5 0 0 0 7 8 0 0 0 6 0 0 0 0 8 0 0 0 6 0 0 0 1 8 0 0 0 6 0 0 0 2 8 0 0 0 6 0 0 0 3 8 0 0 0 6 0 0 0 4 8 0 0 0 6 0 0 0 5 8 0 0 0 6 0 0 0 6 8 0 0 0 6 0 0 0 7 8 0 0 0 7 0 0 0 0 8 0 0 0 7 0 0 0 1 8 0 0 0 7 0 0 0 2 8 0 0 0 7 0 0 0 3 8 0 0 0 7 0 0 0 4 8 0 0 0 7 0 0 0 5 8 0 0 0 7 0 0 0 6 8 0 0 0 7 0 0 0 7"));
fn routine_0(c: &mut Context) -> Space {
  let v0_2: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_0), &(*CONSTANT_1));
  let v0_3: Space = wrap(&(v0_2),&(*CONSTANT_0));
  let v0_5: Space = routine_1(c, &(*CONSTANT_2), &(*CONSTANT_0), &(*CONSTANT_1));
  let v0_6: Space = wrap(&(v0_5),&(*CONSTANT_2));
  let v0_7: Space = unite(&(v0_3),&(v0_6));
  let v0_9: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_0), &(*CONSTANT_1));
  let v0_10: Space = wrap(&(v0_9),&(*CONSTANT_3));
  let v0_11: Space = unite(&(v0_7),&(v0_10));
  let v0_13: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_0), &(*CONSTANT_1));
  let v0_14: Space = wrap(&(v0_13),&(*CONSTANT_4));
  let v0_15: Space = unite(&(v0_11),&(v0_14));
  let v0_17: Space = routine_1(c, &(*CONSTANT_5), &(*CONSTANT_0), &(*CONSTANT_1));
  let v0_18: Space = wrap(&(v0_17),&(*CONSTANT_5));
  let v0_19: Space = unite(&(v0_15),&(v0_18));
  let v0_21: Space = routine_1(c, &(*CONSTANT_6), &(*CONSTANT_0), &(*CONSTANT_1));
  let v0_22: Space = wrap(&(v0_21),&(*CONSTANT_6));
  let v0_23: Space = unite(&(v0_19),&(v0_22));
  let v0_25: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_0), &(*CONSTANT_1));
  let v0_26: Space = wrap(&(v0_25),&(*CONSTANT_7));
  let v0_27: Space = unite(&(v0_23),&(v0_26));
  let v0_28: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_0), &(*CONSTANT_1));
  let v0_29: Space = wrap(&(v0_28),&(*CONSTANT_1));
  let v0_30: Space = unite(&(v0_27),&(v0_29));
  let mut v0_32 = Space::new();
  let mut v0_32_write = v0_32.write_zipper();
  let mut v0_32_cursor = (v0_30).read_zipper();
  let v0_32_origin = v0_32_cursor.path().len();
  for v0_32_byte in v0_32_cursor.child_mask().iter() {
    v0_32_cursor.descend_to_existing_byte(v0_32_byte);
    {
    for v1_2_byte in v0_32_cursor.child_mask().iter() {
      v0_32_cursor.descend_to_existing_byte(v1_2_byte);
      {
      for v2_3_byte in v0_32_cursor.child_mask().iter() {
        v0_32_cursor.descend_to_existing_byte(v2_3_byte);
        {
        for v3_3_byte in v0_32_cursor.child_mask().iter() {
          v0_32_cursor.descend_to_existing_byte(v3_3_byte);
          {
          let v4_3: Space = subtract(&(*CONSTANT_8),&(descend_cursor(cursor_at(&v0_32_cursor,(v0_32_origin + 4)),&(*CONSTANT_2))));
          let mut v4_5_cursor = (v4_3).read_zipper();
          let v4_5_origin = v4_5_cursor.path().len();
          for v4_5_byte in v4_5_cursor.child_mask().iter() {
            v4_5_cursor.descend_to_existing_byte(v4_5_byte);
            {
            for v5_2_byte in v4_5_cursor.child_mask().iter() {
              v4_5_cursor.descend_to_existing_byte(v5_2_byte);
              {
              for v6_3_byte in v4_5_cursor.child_mask().iter() {
                v4_5_cursor.descend_to_existing_byte(v6_3_byte);
                {
                for v7_3_byte in v4_5_cursor.child_mask().iter() {
                  v4_5_cursor.descend_to_existing_byte(v7_3_byte);
                  {
                  let v8_3: Space = routine_2(c, &v4_5_cursor.path()[v4_5_origin..(v4_5_origin + 4)], &v0_32_cursor.path()[v0_32_origin..(v0_32_origin + 4)], &v4_5_cursor, &v0_32_cursor);
                  join_wrapped_into(&mut v0_32_write,&((v8_3).read_zipper()),&[]);
                  }
                  v4_5_cursor.ascend(1);
                }
                }
                v4_5_cursor.ascend(1);
              }
              }
              v4_5_cursor.ascend(1);
            }
            }
            v4_5_cursor.ascend(1);
          }
          drop(v4_5_cursor);
          drop(v4_3);
          }
          v0_32_cursor.ascend(1);
        }
        }
        v0_32_cursor.ascend(1);
      }
      }
      v0_32_cursor.ascend(1);
    }
    }
    v0_32_cursor.ascend(1);
  }
  drop(v0_32_cursor);
  drop(v0_32_write);
  let mut v0_33 = Space::new();
  let mut v0_33_write = v0_33.write_zipper();
  let mut v0_33_cursor = (v0_32).read_zipper();
  let v0_33_origin = v0_33_cursor.path().len();
  for v0_33_byte in v0_33_cursor.child_mask().iter() {
    v0_33_cursor.descend_to_existing_byte(v0_33_byte);
    {
    for v9_2_byte in v0_33_cursor.child_mask().iter() {
      v0_33_cursor.descend_to_existing_byte(v9_2_byte);
      {
      for v10_3_byte in v0_33_cursor.child_mask().iter() {
        v0_33_cursor.descend_to_existing_byte(v10_3_byte);
        {
        for v11_3_byte in v0_33_cursor.child_mask().iter() {
          v0_33_cursor.descend_to_existing_byte(v11_3_byte);
          {
          for v12_3_byte in v0_33_cursor.child_mask().iter() {
            v0_33_cursor.descend_to_existing_byte(v12_3_byte);
            {
            for v13_2_byte in v0_33_cursor.child_mask().iter() {
              v0_33_cursor.descend_to_existing_byte(v13_2_byte);
              {
              for v14_3_byte in v0_33_cursor.child_mask().iter() {
                v0_33_cursor.descend_to_existing_byte(v14_3_byte);
                {
                for v15_3_byte in v0_33_cursor.child_mask().iter() {
                  v0_33_cursor.descend_to_existing_byte(v15_3_byte);
                  {
                  let v16_3: Space = routine_3(c, &v0_33_cursor.path()[(v0_33_origin + 4)..(v0_33_origin + 8)], &v0_33_cursor.path()[v0_33_origin..(v0_33_origin + 4)], &v0_33_cursor);
                  join_wrapped_into(&mut v0_33_write,&((v16_3).read_zipper()),&[]);
                  }
                  v0_33_cursor.ascend(1);
                }
                }
                v0_33_cursor.ascend(1);
              }
              }
              v0_33_cursor.ascend(1);
            }
            }
            v0_33_cursor.ascend(1);
          }
          }
          v0_33_cursor.ascend(1);
        }
        }
        v0_33_cursor.ascend(1);
      }
      }
      v0_33_cursor.ascend(1);
    }
    }
    v0_33_cursor.ascend(1);
  }
  drop(v0_33_cursor);
  drop(v0_33_write);
  let mut v0_34 = Space::new();
  let mut v0_34_write = v0_34.write_zipper();
  let mut v0_34_cursor = (v0_33).read_zipper();
  let v0_34_origin = v0_34_cursor.path().len();
  for v0_34_byte in v0_34_cursor.child_mask().iter() {
    v0_34_cursor.descend_to_existing_byte(v0_34_byte);
    {
    for v17_2_byte in v0_34_cursor.child_mask().iter() {
      v0_34_cursor.descend_to_existing_byte(v17_2_byte);
      {
      for v18_3_byte in v0_34_cursor.child_mask().iter() {
        v0_34_cursor.descend_to_existing_byte(v18_3_byte);
        {
        for v19_3_byte in v0_34_cursor.child_mask().iter() {
          v0_34_cursor.descend_to_existing_byte(v19_3_byte);
          {
          for v20_3_byte in v0_34_cursor.child_mask().iter() {
            v0_34_cursor.descend_to_existing_byte(v20_3_byte);
            {
            for v21_2_byte in v0_34_cursor.child_mask().iter() {
              v0_34_cursor.descend_to_existing_byte(v21_2_byte);
              {
              for v22_3_byte in v0_34_cursor.child_mask().iter() {
                v0_34_cursor.descend_to_existing_byte(v22_3_byte);
                {
                for v23_3_byte in v0_34_cursor.child_mask().iter() {
                  v0_34_cursor.descend_to_existing_byte(v23_3_byte);
                  {
                  let v24_3: Space = routine_4(c, &v0_34_cursor.path()[(v0_34_origin + 4)..(v0_34_origin + 8)], &v0_34_cursor.path()[v0_34_origin..(v0_34_origin + 4)], &v0_34_cursor);
                  join_wrapped_into(&mut v0_34_write,&((v24_3).read_zipper()),&[]);
                  }
                  v0_34_cursor.ascend(1);
                }
                }
                v0_34_cursor.ascend(1);
              }
              }
              v0_34_cursor.ascend(1);
            }
            }
            v0_34_cursor.ascend(1);
          }
          }
          v0_34_cursor.ascend(1);
        }
        }
        v0_34_cursor.ascend(1);
      }
      }
      v0_34_cursor.ascend(1);
    }
    }
    v0_34_cursor.ascend(1);
  }
  drop(v0_34_cursor);
  drop(v0_34_write);
  let mut v0_35 = Space::new();
  let mut v0_35_write = v0_35.write_zipper();
  let mut v0_35_cursor = (v0_34).read_zipper();
  let v0_35_origin = v0_35_cursor.path().len();
  for v0_35_byte in v0_35_cursor.child_mask().iter() {
    v0_35_cursor.descend_to_existing_byte(v0_35_byte);
    {
    for v25_2_byte in v0_35_cursor.child_mask().iter() {
      v0_35_cursor.descend_to_existing_byte(v25_2_byte);
      {
      for v26_3_byte in v0_35_cursor.child_mask().iter() {
        v0_35_cursor.descend_to_existing_byte(v26_3_byte);
        {
        for v27_3_byte in v0_35_cursor.child_mask().iter() {
          v0_35_cursor.descend_to_existing_byte(v27_3_byte);
          {
          for v28_3_byte in v0_35_cursor.child_mask().iter() {
            v0_35_cursor.descend_to_existing_byte(v28_3_byte);
            {
            for v29_2_byte in v0_35_cursor.child_mask().iter() {
              v0_35_cursor.descend_to_existing_byte(v29_2_byte);
              {
              for v30_3_byte in v0_35_cursor.child_mask().iter() {
                v0_35_cursor.descend_to_existing_byte(v30_3_byte);
                {
                for v31_3_byte in v0_35_cursor.child_mask().iter() {
                  v0_35_cursor.descend_to_existing_byte(v31_3_byte);
                  {
                  let v32_3: Space = routine_5(c, &v0_35_cursor.path()[(v0_35_origin + 4)..(v0_35_origin + 8)], &v0_35_cursor.path()[v0_35_origin..(v0_35_origin + 4)], &v0_35_cursor);
                  join_wrapped_into(&mut v0_35_write,&((v32_3).read_zipper()),&[]);
                  }
                  v0_35_cursor.ascend(1);
                }
                }
                v0_35_cursor.ascend(1);
              }
              }
              v0_35_cursor.ascend(1);
            }
            }
            v0_35_cursor.ascend(1);
          }
          }
          v0_35_cursor.ascend(1);
        }
        }
        v0_35_cursor.ascend(1);
      }
      }
      v0_35_cursor.ascend(1);
    }
    }
    v0_35_cursor.ascend(1);
  }
  drop(v0_35_cursor);
  drop(v0_35_write);
  let mut v0_36 = Space::new();
  let mut v0_36_write = v0_36.write_zipper();
  let mut v0_36_cursor = (v0_35).read_zipper();
  let v0_36_origin = v0_36_cursor.path().len();
  for v0_36_byte in v0_36_cursor.child_mask().iter() {
    v0_36_cursor.descend_to_existing_byte(v0_36_byte);
    {
    for v33_2_byte in v0_36_cursor.child_mask().iter() {
      v0_36_cursor.descend_to_existing_byte(v33_2_byte);
      {
      for v34_3_byte in v0_36_cursor.child_mask().iter() {
        v0_36_cursor.descend_to_existing_byte(v34_3_byte);
        {
        for v35_3_byte in v0_36_cursor.child_mask().iter() {
          v0_36_cursor.descend_to_existing_byte(v35_3_byte);
          {
          for v36_3_byte in v0_36_cursor.child_mask().iter() {
            v0_36_cursor.descend_to_existing_byte(v36_3_byte);
            {
            for v37_2_byte in v0_36_cursor.child_mask().iter() {
              v0_36_cursor.descend_to_existing_byte(v37_2_byte);
              {
              for v38_3_byte in v0_36_cursor.child_mask().iter() {
                v0_36_cursor.descend_to_existing_byte(v38_3_byte);
                {
                for v39_3_byte in v0_36_cursor.child_mask().iter() {
                  v0_36_cursor.descend_to_existing_byte(v39_3_byte);
                  {
                  let v40_3: Space = routine_6(c, &v0_36_cursor.path()[(v0_36_origin + 4)..(v0_36_origin + 8)], &v0_36_cursor.path()[v0_36_origin..(v0_36_origin + 4)], &v0_36_cursor);
                  join_wrapped_into(&mut v0_36_write,&((v40_3).read_zipper()),&[]);
                  }
                  v0_36_cursor.ascend(1);
                }
                }
                v0_36_cursor.ascend(1);
              }
              }
              v0_36_cursor.ascend(1);
            }
            }
            v0_36_cursor.ascend(1);
          }
          }
          v0_36_cursor.ascend(1);
        }
        }
        v0_36_cursor.ascend(1);
      }
      }
      v0_36_cursor.ascend(1);
    }
    }
    v0_36_cursor.ascend(1);
  }
  drop(v0_36_cursor);
  drop(v0_36_write);
  let mut v0_37 = Space::new();
  let mut v0_37_write = v0_37.write_zipper();
  let mut v0_37_cursor = (v0_36).read_zipper();
  let v0_37_origin = v0_37_cursor.path().len();
  for v0_37_byte in v0_37_cursor.child_mask().iter() {
    v0_37_cursor.descend_to_existing_byte(v0_37_byte);
    {
    for v41_2_byte in v0_37_cursor.child_mask().iter() {
      v0_37_cursor.descend_to_existing_byte(v41_2_byte);
      {
      for v42_3_byte in v0_37_cursor.child_mask().iter() {
        v0_37_cursor.descend_to_existing_byte(v42_3_byte);
        {
        for v43_3_byte in v0_37_cursor.child_mask().iter() {
          v0_37_cursor.descend_to_existing_byte(v43_3_byte);
          {
          for v44_3_byte in v0_37_cursor.child_mask().iter() {
            v0_37_cursor.descend_to_existing_byte(v44_3_byte);
            {
            for v45_2_byte in v0_37_cursor.child_mask().iter() {
              v0_37_cursor.descend_to_existing_byte(v45_2_byte);
              {
              for v46_3_byte in v0_37_cursor.child_mask().iter() {
                v0_37_cursor.descend_to_existing_byte(v46_3_byte);
                {
                for v47_3_byte in v0_37_cursor.child_mask().iter() {
                  v0_37_cursor.descend_to_existing_byte(v47_3_byte);
                  {
                  let v48_3: Space = routine_7(c, &v0_37_cursor.path()[(v0_37_origin + 4)..(v0_37_origin + 8)], &v0_37_cursor.path()[v0_37_origin..(v0_37_origin + 4)], &v0_37_cursor);
                  join_wrapped_into(&mut v0_37_write,&((v48_3).read_zipper()),&[]);
                  }
                  v0_37_cursor.ascend(1);
                }
                }
                v0_37_cursor.ascend(1);
              }
              }
              v0_37_cursor.ascend(1);
            }
            }
            v0_37_cursor.ascend(1);
          }
          }
          v0_37_cursor.ascend(1);
        }
        }
        v0_37_cursor.ascend(1);
      }
      }
      v0_37_cursor.ascend(1);
    }
    }
    v0_37_cursor.ascend(1);
  }
  drop(v0_37_cursor);
  drop(v0_37_write);
  let mut v0_38 = Space::new();
  let mut v0_38_write = v0_38.write_zipper();
  let mut v0_38_cursor = (v0_37).read_zipper();
  let v0_38_origin = v0_38_cursor.path().len();
  for v0_38_byte in v0_38_cursor.child_mask().iter() {
    v0_38_cursor.descend_to_existing_byte(v0_38_byte);
    {
    for v49_2_byte in v0_38_cursor.child_mask().iter() {
      v0_38_cursor.descend_to_existing_byte(v49_2_byte);
      {
      for v50_3_byte in v0_38_cursor.child_mask().iter() {
        v0_38_cursor.descend_to_existing_byte(v50_3_byte);
        {
        for v51_3_byte in v0_38_cursor.child_mask().iter() {
          v0_38_cursor.descend_to_existing_byte(v51_3_byte);
          {
          for v52_3_byte in v0_38_cursor.child_mask().iter() {
            v0_38_cursor.descend_to_existing_byte(v52_3_byte);
            {
            for v53_2_byte in v0_38_cursor.child_mask().iter() {
              v0_38_cursor.descend_to_existing_byte(v53_2_byte);
              {
              for v54_3_byte in v0_38_cursor.child_mask().iter() {
                v0_38_cursor.descend_to_existing_byte(v54_3_byte);
                {
                for v55_3_byte in v0_38_cursor.child_mask().iter() {
                  v0_38_cursor.descend_to_existing_byte(v55_3_byte);
                  {
                  let v56_3: Space = routine_8(c, &v0_38_cursor.path()[(v0_38_origin + 4)..(v0_38_origin + 8)], &v0_38_cursor.path()[v0_38_origin..(v0_38_origin + 4)], &v0_38_cursor);
                  join_wrapped_into(&mut v0_38_write,&((v56_3).read_zipper()),&[]);
                  }
                  v0_38_cursor.ascend(1);
                }
                }
                v0_38_cursor.ascend(1);
              }
              }
              v0_38_cursor.ascend(1);
            }
            }
            v0_38_cursor.ascend(1);
          }
          }
          v0_38_cursor.ascend(1);
        }
        }
        v0_38_cursor.ascend(1);
      }
      }
      v0_38_cursor.ascend(1);
    }
    }
    v0_38_cursor.ascend(1);
  }
  drop(v0_38_cursor);
  drop(v0_38_write);
  let mut v0_39 = Space::new();
  let mut v0_39_write = v0_39.write_zipper();
  let mut v0_39_cursor = (v0_38).read_zipper();
  let v0_39_origin = v0_39_cursor.path().len();
  for v0_39_byte in v0_39_cursor.child_mask().iter() {
    v0_39_cursor.descend_to_existing_byte(v0_39_byte);
    {
    for v57_2_byte in v0_39_cursor.child_mask().iter() {
      v0_39_cursor.descend_to_existing_byte(v57_2_byte);
      {
      for v58_3_byte in v0_39_cursor.child_mask().iter() {
        v0_39_cursor.descend_to_existing_byte(v58_3_byte);
        {
        for v59_3_byte in v0_39_cursor.child_mask().iter() {
          v0_39_cursor.descend_to_existing_byte(v59_3_byte);
          {
          for v60_3_byte in v0_39_cursor.child_mask().iter() {
            v0_39_cursor.descend_to_existing_byte(v60_3_byte);
            {
            for v61_2_byte in v0_39_cursor.child_mask().iter() {
              v0_39_cursor.descend_to_existing_byte(v61_2_byte);
              {
              for v62_3_byte in v0_39_cursor.child_mask().iter() {
                v0_39_cursor.descend_to_existing_byte(v62_3_byte);
                {
                for v63_3_byte in v0_39_cursor.child_mask().iter() {
                  v0_39_cursor.descend_to_existing_byte(v63_3_byte);
                  {
                  let v64_3: Space = routine_9(c, &v0_39_cursor.path()[(v0_39_origin + 4)..(v0_39_origin + 8)], &v0_39_cursor.path()[v0_39_origin..(v0_39_origin + 4)], &v0_39_cursor);
                  join_wrapped_into(&mut v0_39_write,&((v64_3).read_zipper()),&[]);
                  }
                  v0_39_cursor.ascend(1);
                }
                }
                v0_39_cursor.ascend(1);
              }
              }
              v0_39_cursor.ascend(1);
            }
            }
            v0_39_cursor.ascend(1);
          }
          }
          v0_39_cursor.ascend(1);
        }
        }
        v0_39_cursor.ascend(1);
      }
      }
      v0_39_cursor.ascend(1);
    }
    }
    v0_39_cursor.ascend(1);
  }
  drop(v0_39_cursor);
  drop(v0_39_write);
  (v0_39).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8]) -> Space {
  let v65_7: Space = if (&(descend_cursor((*CONSTANT_9).read_zipper(),&(*p2)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_9).read_zipper(),&(*p2))),&(descend_cursor((*CONSTANT_9).read_zipper(),&(*p2))))
  };
  let mut v65_14 = Space::new();
  let mut v65_14_write = v65_14.write_zipper();
  let mut v65_14_cursor = descend_cursor((*CONSTANT_9).read_zipper(),&(*p2));
  let v65_14_origin = v65_14_cursor.path().len();
  for v65_14_byte in v65_14_cursor.child_mask().iter() {
    v65_14_cursor.descend_to_existing_byte(v65_14_byte);
    {
    for v67_4_byte in v65_14_cursor.child_mask().iter() {
      v65_14_cursor.descend_to_existing_byte(v67_4_byte);
      {
      for v68_5_byte in v65_14_cursor.child_mask().iter() {
        v65_14_cursor.descend_to_existing_byte(v68_5_byte);
        {
        for v69_5_byte in v65_14_cursor.child_mask().iter() {
          v65_14_cursor.descend_to_existing_byte(v69_5_byte);
          {
          let v70_4: Space = if (&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1)),&v65_14_cursor.path()[v65_14_origin..(v65_14_origin + 1)]),&v65_14_cursor.path()[(v65_14_origin + 1)..(v65_14_origin + 2)]),&v65_14_cursor.path()[(v65_14_origin + 2)..(v65_14_origin + 3)]),&v65_14_cursor.path()[(v65_14_origin + 3)..(v65_14_origin + 4)]))).is_empty() { Space::new() } else {
            compose(&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1)),&v65_14_cursor.path()[v65_14_origin..(v65_14_origin + 1)]),&v65_14_cursor.path()[(v65_14_origin + 1)..(v65_14_origin + 2)]),&v65_14_cursor.path()[(v65_14_origin + 2)..(v65_14_origin + 3)]),&v65_14_cursor.path()[(v65_14_origin + 3)..(v65_14_origin + 4)])),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_10).read_zipper(),&(*p0)),&v65_14_cursor.path()[v65_14_origin..(v65_14_origin + 1)]),&v65_14_cursor.path()[(v65_14_origin + 1)..(v65_14_origin + 2)]),&v65_14_cursor.path()[(v65_14_origin + 2)..(v65_14_origin + 3)]),&v65_14_cursor.path()[(v65_14_origin + 3)..(v65_14_origin + 4)])))
          };
          let v70_6: Path = concat_path(&v65_14_cursor.path()[v65_14_origin..(v65_14_origin + 4)],&(*p0));
          let v70_7: Space = singleton(&(v70_6));
          drop(v70_6);
          let v70_8: Space = unite(&(v70_4),&(v70_7));
          drop(v70_4);
          drop(v70_7);
          let v70_9: Path = concat_path(&(*p1),&v65_14_cursor.path()[v65_14_origin..(v65_14_origin + 4)]);
          let v70_10: Space = singleton(&(v70_9));
          drop(v70_9);
          let v70_11: Space = unite(&(v70_8),&(v70_10));
          drop(v70_8);
          drop(v70_10);
          join_wrapped_into(&mut v65_14_write,&((v70_11).read_zipper()),&[]);
          }
          v65_14_cursor.ascend(1);
        }
        }
        v65_14_cursor.ascend(1);
      }
      }
      v65_14_cursor.ascend(1);
    }
    }
    v65_14_cursor.ascend(1);
  }
  drop(v65_14_cursor);
  drop(v65_14_write);
  let v65_15: Space = intersect(&(v65_7),&(v65_14));
  drop(v65_7);
  drop(v65_14);
  (v65_15).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v72_7: Space = routine_10(c, &(*CONSTANT_0), &(*CONSTANT_2), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v72_9: Space = routine_10(c, &(*CONSTANT_2), &(*CONSTANT_2), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v72_10: Space = unite(&(v72_7),&(v72_9));
  let v72_13: Space = routine_10(c, &(*CONSTANT_3), &(*CONSTANT_2), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v72_14: Space = unite(&(v72_10),&(v72_13));
  let v72_17: Space = routine_10(c, &(*CONSTANT_4), &(*CONSTANT_2), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v72_18: Space = unite(&(v72_14),&(v72_17));
  let v72_21: Space = routine_10(c, &(*CONSTANT_5), &(*CONSTANT_2), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v72_22: Space = unite(&(v72_18),&(v72_21));
  let v72_25: Space = routine_10(c, &(*CONSTANT_6), &(*CONSTANT_2), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v72_26: Space = unite(&(v72_22),&(v72_25));
  let v72_29: Space = routine_10(c, &(*CONSTANT_7), &(*CONSTANT_2), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v72_30: Space = unite(&(v72_26),&(v72_29));
  let v72_33: Space = routine_10(c, &(*CONSTANT_1), &(*CONSTANT_2), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v72_34: Space = unite(&(v72_30),&(v72_33));
  let v72_36: Space = intersect(&(v72_34),&(*CONSTANT_12));
  let v72_37: Space = unite(&(v72_36),&(*s1));
  let v72_38: Space = wrap(&(v72_37),&(*p1));
  let v72_39: Space = wrap(&(v72_38),&(*p0));
  (v72_39).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v73_6: Space = subtract(&(*CONSTANT_8),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_3))));
  let v73_8: Path = concat_path(&(*p1),&(*p0));
  let mut v73_9 = Space::new();
  let mut v73_9_write = v73_9.write_zipper();
  let mut v73_9_cursor = (v73_6).read_zipper();
  let v73_9_origin = v73_9_cursor.path().len();
  for v73_9_byte in v73_9_cursor.child_mask().iter() {
    v73_9_cursor.descend_to_existing_byte(v73_9_byte);
    {
    for v74_2_byte in v73_9_cursor.child_mask().iter() {
      v73_9_cursor.descend_to_existing_byte(v74_2_byte);
      {
      for v75_3_byte in v73_9_cursor.child_mask().iter() {
        v73_9_cursor.descend_to_existing_byte(v75_3_byte);
        {
        for v76_3_byte in v73_9_cursor.child_mask().iter() {
          v73_9_cursor.descend_to_existing_byte(v76_3_byte);
          {
          let v77_3: Space = routine_1(c, &v73_9_cursor.path()[v73_9_origin..(v73_9_origin + 4)], &(*CONSTANT_3), &(*CONSTANT_1));
          let v77_4: Space = unite(&(*s0),&(v77_3));
          let v77_5: Space = wrap(&(v77_4),&(v73_8));
          join_wrapped_into(&mut v73_9_write,&((v77_5).read_zipper()),&v73_9_cursor.path()[v73_9_origin..(v73_9_origin + 4)]);
          }
          v73_9_cursor.ascend(1);
        }
        }
        v73_9_cursor.ascend(1);
      }
      }
      v73_9_cursor.ascend(1);
    }
    }
    v73_9_cursor.ascend(1);
  }
  drop(v73_9_cursor);
  drop(v73_9_write);
  drop(v73_6);
  drop(v73_8);
  (v73_9).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v78_5 = Space::new();
  let mut v78_5_write = v78_5.write_zipper();
  let mut v78_5_cursor = (*s0).read_zipper();
  let v78_5_origin = v78_5_cursor.path().len();
  for v78_5_byte in v78_5_cursor.child_mask().iter() {
    v78_5_cursor.descend_to_existing_byte(v78_5_byte);
    {
    for v79_2_byte in v78_5_cursor.child_mask().iter() {
      v78_5_cursor.descend_to_existing_byte(v79_2_byte);
      {
      for v80_3_byte in v78_5_cursor.child_mask().iter() {
        v78_5_cursor.descend_to_existing_byte(v80_3_byte);
        {
        for v81_3_byte in v78_5_cursor.child_mask().iter() {
          v78_5_cursor.descend_to_existing_byte(v81_3_byte);
          {
          let v82_3: Space = subtract(&(*CONSTANT_8),&(descend_cursor(cursor_at(&v78_5_cursor,(v78_5_origin + 4)),&(*CONSTANT_4))));
          let mut v82_5_cursor = (v82_3).read_zipper();
          let v82_5_origin = v82_5_cursor.path().len();
          for v82_5_byte in v82_5_cursor.child_mask().iter() {
            v82_5_cursor.descend_to_existing_byte(v82_5_byte);
            {
            for v83_2_byte in v82_5_cursor.child_mask().iter() {
              v82_5_cursor.descend_to_existing_byte(v83_2_byte);
              {
              for v84_3_byte in v82_5_cursor.child_mask().iter() {
                v82_5_cursor.descend_to_existing_byte(v84_3_byte);
                {
                for v85_3_byte in v82_5_cursor.child_mask().iter() {
                  v82_5_cursor.descend_to_existing_byte(v85_3_byte);
                  {
                  let v86_3: Space = routine_11(c, &v82_5_cursor.path()[v82_5_origin..(v82_5_origin + 4)], &(*p1), &(*p0), &v78_5_cursor.path()[v78_5_origin..(v78_5_origin + 4)], &v82_5_cursor, &v78_5_cursor);
                  join_wrapped_into(&mut v78_5_write,&((v86_3).read_zipper()),&[]);
                  }
                  v82_5_cursor.ascend(1);
                }
                }
                v82_5_cursor.ascend(1);
              }
              }
              v82_5_cursor.ascend(1);
            }
            }
            v82_5_cursor.ascend(1);
          }
          drop(v82_5_cursor);
          drop(v82_3);
          }
          v78_5_cursor.ascend(1);
        }
        }
        v78_5_cursor.ascend(1);
      }
      }
      v78_5_cursor.ascend(1);
    }
    }
    v78_5_cursor.ascend(1);
  }
  drop(v78_5_cursor);
  drop(v78_5_write);
  (v78_5).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v87_3 = Space::new();
  let mut v87_3_write = v87_3.write_zipper();
  let mut v87_3_cursor = (*s0).read_zipper();
  let v87_3_origin = v87_3_cursor.path().len();
  for v87_3_byte in v87_3_cursor.child_mask().iter() {
    v87_3_cursor.descend_to_existing_byte(v87_3_byte);
    {
    for v88_2_byte in v87_3_cursor.child_mask().iter() {
      v87_3_cursor.descend_to_existing_byte(v88_2_byte);
      {
      for v89_3_byte in v87_3_cursor.child_mask().iter() {
        v87_3_cursor.descend_to_existing_byte(v89_3_byte);
        {
        for v90_3_byte in v87_3_cursor.child_mask().iter() {
          v87_3_cursor.descend_to_existing_byte(v90_3_byte);
          {
          for v91_3_byte in v87_3_cursor.child_mask().iter() {
            v87_3_cursor.descend_to_existing_byte(v91_3_byte);
            {
            for v92_2_byte in v87_3_cursor.child_mask().iter() {
              v87_3_cursor.descend_to_existing_byte(v92_2_byte);
              {
              for v93_3_byte in v87_3_cursor.child_mask().iter() {
                v87_3_cursor.descend_to_existing_byte(v93_3_byte);
                {
                for v94_3_byte in v87_3_cursor.child_mask().iter() {
                  v87_3_cursor.descend_to_existing_byte(v94_3_byte);
                  {
                  let v95_3: Space = routine_12(c, &v87_3_cursor.path()[(v87_3_origin + 4)..(v87_3_origin + 8)], &(*p0), &v87_3_cursor.path()[v87_3_origin..(v87_3_origin + 4)], &(*p1), &v87_3_cursor);
                  join_wrapped_into(&mut v87_3_write,&((v95_3).read_zipper()),&[]);
                  }
                  v87_3_cursor.ascend(1);
                }
                }
                v87_3_cursor.ascend(1);
              }
              }
              v87_3_cursor.ascend(1);
            }
            }
            v87_3_cursor.ascend(1);
          }
          }
          v87_3_cursor.ascend(1);
        }
        }
        v87_3_cursor.ascend(1);
      }
      }
      v87_3_cursor.ascend(1);
    }
    }
    v87_3_cursor.ascend(1);
  }
  drop(v87_3_cursor);
  drop(v87_3_write);
  (v87_3).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v96_3 = Space::new();
  let mut v96_3_write = v96_3.write_zipper();
  let mut v96_3_cursor = (*s0).read_zipper();
  let v96_3_origin = v96_3_cursor.path().len();
  for v96_3_byte in v96_3_cursor.child_mask().iter() {
    v96_3_cursor.descend_to_existing_byte(v96_3_byte);
    {
    for v97_2_byte in v96_3_cursor.child_mask().iter() {
      v96_3_cursor.descend_to_existing_byte(v97_2_byte);
      {
      for v98_3_byte in v96_3_cursor.child_mask().iter() {
        v96_3_cursor.descend_to_existing_byte(v98_3_byte);
        {
        for v99_3_byte in v96_3_cursor.child_mask().iter() {
          v96_3_cursor.descend_to_existing_byte(v99_3_byte);
          {
          for v100_3_byte in v96_3_cursor.child_mask().iter() {
            v96_3_cursor.descend_to_existing_byte(v100_3_byte);
            {
            for v101_2_byte in v96_3_cursor.child_mask().iter() {
              v96_3_cursor.descend_to_existing_byte(v101_2_byte);
              {
              for v102_3_byte in v96_3_cursor.child_mask().iter() {
                v96_3_cursor.descend_to_existing_byte(v102_3_byte);
                {
                for v103_3_byte in v96_3_cursor.child_mask().iter() {
                  v96_3_cursor.descend_to_existing_byte(v103_3_byte);
                  {
                  let v104_3: Space = routine_13(c, &v96_3_cursor.path()[(v96_3_origin + 4)..(v96_3_origin + 8)], &(*p1), &(*p0), &v96_3_cursor.path()[v96_3_origin..(v96_3_origin + 4)], &v96_3_cursor);
                  join_wrapped_into(&mut v96_3_write,&((v104_3).read_zipper()),&[]);
                  }
                  v96_3_cursor.ascend(1);
                }
                }
                v96_3_cursor.ascend(1);
              }
              }
              v96_3_cursor.ascend(1);
            }
            }
            v96_3_cursor.ascend(1);
          }
          }
          v96_3_cursor.ascend(1);
        }
        }
        v96_3_cursor.ascend(1);
      }
      }
      v96_3_cursor.ascend(1);
    }
    }
    v96_3_cursor.ascend(1);
  }
  drop(v96_3_cursor);
  drop(v96_3_write);
  (v96_3).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v105_3 = Space::new();
  let mut v105_3_write = v105_3.write_zipper();
  let mut v105_3_cursor = (*s0).read_zipper();
  let v105_3_origin = v105_3_cursor.path().len();
  for v105_3_byte in v105_3_cursor.child_mask().iter() {
    v105_3_cursor.descend_to_existing_byte(v105_3_byte);
    {
    for v106_2_byte in v105_3_cursor.child_mask().iter() {
      v105_3_cursor.descend_to_existing_byte(v106_2_byte);
      {
      for v107_3_byte in v105_3_cursor.child_mask().iter() {
        v105_3_cursor.descend_to_existing_byte(v107_3_byte);
        {
        for v108_3_byte in v105_3_cursor.child_mask().iter() {
          v105_3_cursor.descend_to_existing_byte(v108_3_byte);
          {
          for v109_3_byte in v105_3_cursor.child_mask().iter() {
            v105_3_cursor.descend_to_existing_byte(v109_3_byte);
            {
            for v110_2_byte in v105_3_cursor.child_mask().iter() {
              v105_3_cursor.descend_to_existing_byte(v110_2_byte);
              {
              for v111_3_byte in v105_3_cursor.child_mask().iter() {
                v105_3_cursor.descend_to_existing_byte(v111_3_byte);
                {
                for v112_3_byte in v105_3_cursor.child_mask().iter() {
                  v105_3_cursor.descend_to_existing_byte(v112_3_byte);
                  {
                  let v113_3: Space = routine_14(c, &v105_3_cursor.path()[(v105_3_origin + 4)..(v105_3_origin + 8)], &(*p1), &(*p0), &v105_3_cursor.path()[v105_3_origin..(v105_3_origin + 4)], &v105_3_cursor);
                  join_wrapped_into(&mut v105_3_write,&((v113_3).read_zipper()),&[]);
                  }
                  v105_3_cursor.ascend(1);
                }
                }
                v105_3_cursor.ascend(1);
              }
              }
              v105_3_cursor.ascend(1);
            }
            }
            v105_3_cursor.ascend(1);
          }
          }
          v105_3_cursor.ascend(1);
        }
        }
        v105_3_cursor.ascend(1);
      }
      }
      v105_3_cursor.ascend(1);
    }
    }
    v105_3_cursor.ascend(1);
  }
  drop(v105_3_cursor);
  drop(v105_3_write);
  (v105_3).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v114_3 = Space::new();
  let mut v114_3_write = v114_3.write_zipper();
  let mut v114_3_cursor = (*s0).read_zipper();
  let v114_3_origin = v114_3_cursor.path().len();
  for v114_3_byte in v114_3_cursor.child_mask().iter() {
    v114_3_cursor.descend_to_existing_byte(v114_3_byte);
    {
    for v115_2_byte in v114_3_cursor.child_mask().iter() {
      v114_3_cursor.descend_to_existing_byte(v115_2_byte);
      {
      for v116_3_byte in v114_3_cursor.child_mask().iter() {
        v114_3_cursor.descend_to_existing_byte(v116_3_byte);
        {
        for v117_3_byte in v114_3_cursor.child_mask().iter() {
          v114_3_cursor.descend_to_existing_byte(v117_3_byte);
          {
          for v118_3_byte in v114_3_cursor.child_mask().iter() {
            v114_3_cursor.descend_to_existing_byte(v118_3_byte);
            {
            for v119_2_byte in v114_3_cursor.child_mask().iter() {
              v114_3_cursor.descend_to_existing_byte(v119_2_byte);
              {
              for v120_3_byte in v114_3_cursor.child_mask().iter() {
                v114_3_cursor.descend_to_existing_byte(v120_3_byte);
                {
                for v121_3_byte in v114_3_cursor.child_mask().iter() {
                  v114_3_cursor.descend_to_existing_byte(v121_3_byte);
                  {
                  let v122_3: Space = routine_15(c, &v114_3_cursor.path()[(v114_3_origin + 4)..(v114_3_origin + 8)], &(*p1), &(*p0), &v114_3_cursor.path()[v114_3_origin..(v114_3_origin + 4)], &v114_3_cursor);
                  join_wrapped_into(&mut v114_3_write,&((v122_3).read_zipper()),&[]);
                  }
                  v114_3_cursor.ascend(1);
                }
                }
                v114_3_cursor.ascend(1);
              }
              }
              v114_3_cursor.ascend(1);
            }
            }
            v114_3_cursor.ascend(1);
          }
          }
          v114_3_cursor.ascend(1);
        }
        }
        v114_3_cursor.ascend(1);
      }
      }
      v114_3_cursor.ascend(1);
    }
    }
    v114_3_cursor.ascend(1);
  }
  drop(v114_3_cursor);
  drop(v114_3_write);
  (v114_3).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v123_3 = Space::new();
  let mut v123_3_write = v123_3.write_zipper();
  let mut v123_3_cursor = (*s0).read_zipper();
  let v123_3_origin = v123_3_cursor.path().len();
  for v123_3_byte in v123_3_cursor.child_mask().iter() {
    v123_3_cursor.descend_to_existing_byte(v123_3_byte);
    {
    for v124_2_byte in v123_3_cursor.child_mask().iter() {
      v123_3_cursor.descend_to_existing_byte(v124_2_byte);
      {
      for v125_3_byte in v123_3_cursor.child_mask().iter() {
        v123_3_cursor.descend_to_existing_byte(v125_3_byte);
        {
        for v126_3_byte in v123_3_cursor.child_mask().iter() {
          v123_3_cursor.descend_to_existing_byte(v126_3_byte);
          {
          for v127_3_byte in v123_3_cursor.child_mask().iter() {
            v123_3_cursor.descend_to_existing_byte(v127_3_byte);
            {
            for v128_2_byte in v123_3_cursor.child_mask().iter() {
              v123_3_cursor.descend_to_existing_byte(v128_2_byte);
              {
              for v129_3_byte in v123_3_cursor.child_mask().iter() {
                v123_3_cursor.descend_to_existing_byte(v129_3_byte);
                {
                for v130_3_byte in v123_3_cursor.child_mask().iter() {
                  v123_3_cursor.descend_to_existing_byte(v130_3_byte);
                  {
                  let v131_3: Space = routine_16(c, &v123_3_cursor.path()[(v123_3_origin + 4)..(v123_3_origin + 8)], &(*p1), &(*p0), &v123_3_cursor.path()[v123_3_origin..(v123_3_origin + 4)], &v123_3_cursor);
                  join_wrapped_into(&mut v123_3_write,&((v131_3).read_zipper()),&[]);
                  }
                  v123_3_cursor.ascend(1);
                }
                }
                v123_3_cursor.ascend(1);
              }
              }
              v123_3_cursor.ascend(1);
            }
            }
            v123_3_cursor.ascend(1);
          }
          }
          v123_3_cursor.ascend(1);
        }
        }
        v123_3_cursor.ascend(1);
      }
      }
      v123_3_cursor.ascend(1);
    }
    }
    v123_3_cursor.ascend(1);
  }
  drop(v123_3_cursor);
  drop(v123_3_write);
  (v123_3).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v132_10: Space = if (&(descend_cursor(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1)),&(*p0)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1)),&(*p0))),&(descend_cursor(descend_cursor((*CONSTANT_10).read_zipper(),&(*p2)),&(*p0))))
  };
  let v132_11: Path = concat_path(&(*p0),&(*p2));
  let v132_12: Space = singleton(&(v132_11));
  drop(v132_11);
  let v132_13: Space = unite(&(v132_10),&(v132_12));
  drop(v132_10);
  drop(v132_12);
  let v132_14: Path = concat_path(&(*p1),&(*p0));
  let v132_15: Space = singleton(&(v132_14));
  drop(v132_14);
  let v132_16: Space = unite(&(v132_13),&(v132_15));
  drop(v132_13);
  drop(v132_15);
  (v132_16).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v134_9: Space = routine_10(c, &(*CONSTANT_0), &(*CONSTANT_4), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v134_12: Space = routine_10(c, &(*CONSTANT_2), &(*CONSTANT_4), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v134_13: Space = unite(&(v134_9),&(v134_12));
  let v134_16: Space = routine_10(c, &(*CONSTANT_3), &(*CONSTANT_4), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v134_17: Space = unite(&(v134_13),&(v134_16));
  let v134_19: Space = routine_10(c, &(*CONSTANT_4), &(*CONSTANT_4), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v134_20: Space = unite(&(v134_17),&(v134_19));
  let v134_23: Space = routine_10(c, &(*CONSTANT_5), &(*CONSTANT_4), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v134_24: Space = unite(&(v134_20),&(v134_23));
  let v134_27: Space = routine_10(c, &(*CONSTANT_6), &(*CONSTANT_4), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v134_28: Space = unite(&(v134_24),&(v134_27));
  let v134_31: Space = routine_10(c, &(*CONSTANT_7), &(*CONSTANT_4), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v134_32: Space = unite(&(v134_28),&(v134_31));
  let v134_35: Space = routine_10(c, &(*CONSTANT_1), &(*CONSTANT_4), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v134_36: Space = unite(&(v134_32),&(v134_35));
  let v134_38: Space = intersect(&(v134_36),&(*CONSTANT_12));
  let v134_39: Space = unite(&(v134_38),&(*s1));
  let v134_40: Path = concat_path(&(*p1),&(*p2));
  let v134_41: Path = concat_path(&(v134_40),&(*p3));
  drop(v134_40);
  let v134_42: Space = wrap(&(v134_39),&(v134_41));
  drop(v134_41);
  let v134_43: Space = wrap(&(v134_42),&(*p0));
  (v134_43).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let v135_8: Space = subtract(&(*CONSTANT_8),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_5))));
  let v135_10: Path = concat_path(&(*p3),&(*p1));
  let v135_11: Path = concat_path(&(v135_10),&(*p2));
  drop(v135_10);
  let v135_12: Path = concat_path(&(v135_11),&(*p0));
  drop(v135_11);
  let mut v135_13 = Space::new();
  let mut v135_13_write = v135_13.write_zipper();
  let mut v135_13_cursor = (v135_8).read_zipper();
  let v135_13_origin = v135_13_cursor.path().len();
  for v135_13_byte in v135_13_cursor.child_mask().iter() {
    v135_13_cursor.descend_to_existing_byte(v135_13_byte);
    {
    for v136_2_byte in v135_13_cursor.child_mask().iter() {
      v135_13_cursor.descend_to_existing_byte(v136_2_byte);
      {
      for v137_3_byte in v135_13_cursor.child_mask().iter() {
        v135_13_cursor.descend_to_existing_byte(v137_3_byte);
        {
        for v138_3_byte in v135_13_cursor.child_mask().iter() {
          v135_13_cursor.descend_to_existing_byte(v138_3_byte);
          {
          let v139_3: Space = routine_1(c, &v135_13_cursor.path()[v135_13_origin..(v135_13_origin + 4)], &(*CONSTANT_5), &(*CONSTANT_1));
          let v139_4: Space = unite(&(*s0),&(v139_3));
          let v139_5: Space = wrap(&(v139_4),&(v135_12));
          join_wrapped_into(&mut v135_13_write,&((v139_5).read_zipper()),&v135_13_cursor.path()[v135_13_origin..(v135_13_origin + 4)]);
          }
          v135_13_cursor.ascend(1);
        }
        }
        v135_13_cursor.ascend(1);
      }
      }
      v135_13_cursor.ascend(1);
    }
    }
    v135_13_cursor.ascend(1);
  }
  drop(v135_13_cursor);
  drop(v135_13_write);
  drop(v135_8);
  drop(v135_12);
  (v135_13).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v140_7 = Space::new();
  let mut v140_7_write = v140_7.write_zipper();
  let mut v140_7_cursor = (*s0).read_zipper();
  let v140_7_origin = v140_7_cursor.path().len();
  for v140_7_byte in v140_7_cursor.child_mask().iter() {
    v140_7_cursor.descend_to_existing_byte(v140_7_byte);
    {
    for v141_2_byte in v140_7_cursor.child_mask().iter() {
      v140_7_cursor.descend_to_existing_byte(v141_2_byte);
      {
      for v142_3_byte in v140_7_cursor.child_mask().iter() {
        v140_7_cursor.descend_to_existing_byte(v142_3_byte);
        {
        for v143_3_byte in v140_7_cursor.child_mask().iter() {
          v140_7_cursor.descend_to_existing_byte(v143_3_byte);
          {
          let v144_3: Space = subtract(&(*CONSTANT_8),&(descend_cursor(cursor_at(&v140_7_cursor,(v140_7_origin + 4)),&(*CONSTANT_6))));
          let mut v144_5_cursor = (v144_3).read_zipper();
          let v144_5_origin = v144_5_cursor.path().len();
          for v144_5_byte in v144_5_cursor.child_mask().iter() {
            v144_5_cursor.descend_to_existing_byte(v144_5_byte);
            {
            for v145_2_byte in v144_5_cursor.child_mask().iter() {
              v144_5_cursor.descend_to_existing_byte(v145_2_byte);
              {
              for v146_3_byte in v144_5_cursor.child_mask().iter() {
                v144_5_cursor.descend_to_existing_byte(v146_3_byte);
                {
                for v147_3_byte in v144_5_cursor.child_mask().iter() {
                  v144_5_cursor.descend_to_existing_byte(v147_3_byte);
                  {
                  let v148_3: Space = routine_17(c, &v144_5_cursor.path()[v144_5_origin..(v144_5_origin + 4)], &(*p1), &(*p2), &(*p3), &(*p0), &v140_7_cursor.path()[v140_7_origin..(v140_7_origin + 4)], &v144_5_cursor, &v140_7_cursor);
                  join_wrapped_into(&mut v140_7_write,&((v148_3).read_zipper()),&[]);
                  }
                  v144_5_cursor.ascend(1);
                }
                }
                v144_5_cursor.ascend(1);
              }
              }
              v144_5_cursor.ascend(1);
            }
            }
            v144_5_cursor.ascend(1);
          }
          drop(v144_5_cursor);
          drop(v144_3);
          }
          v140_7_cursor.ascend(1);
        }
        }
        v140_7_cursor.ascend(1);
      }
      }
      v140_7_cursor.ascend(1);
    }
    }
    v140_7_cursor.ascend(1);
  }
  drop(v140_7_cursor);
  drop(v140_7_write);
  (v140_7).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v149_5 = Space::new();
  let mut v149_5_write = v149_5.write_zipper();
  let mut v149_5_cursor = (*s0).read_zipper();
  let v149_5_origin = v149_5_cursor.path().len();
  for v149_5_byte in v149_5_cursor.child_mask().iter() {
    v149_5_cursor.descend_to_existing_byte(v149_5_byte);
    {
    for v150_2_byte in v149_5_cursor.child_mask().iter() {
      v149_5_cursor.descend_to_existing_byte(v150_2_byte);
      {
      for v151_3_byte in v149_5_cursor.child_mask().iter() {
        v149_5_cursor.descend_to_existing_byte(v151_3_byte);
        {
        for v152_3_byte in v149_5_cursor.child_mask().iter() {
          v149_5_cursor.descend_to_existing_byte(v152_3_byte);
          {
          for v153_3_byte in v149_5_cursor.child_mask().iter() {
            v149_5_cursor.descend_to_existing_byte(v153_3_byte);
            {
            for v154_2_byte in v149_5_cursor.child_mask().iter() {
              v149_5_cursor.descend_to_existing_byte(v154_2_byte);
              {
              for v155_3_byte in v149_5_cursor.child_mask().iter() {
                v149_5_cursor.descend_to_existing_byte(v155_3_byte);
                {
                for v156_3_byte in v149_5_cursor.child_mask().iter() {
                  v149_5_cursor.descend_to_existing_byte(v156_3_byte);
                  {
                  let v157_3: Space = routine_18(c, &v149_5_cursor.path()[(v149_5_origin + 4)..(v149_5_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p0), &v149_5_cursor.path()[v149_5_origin..(v149_5_origin + 4)], &v149_5_cursor);
                  join_wrapped_into(&mut v149_5_write,&((v157_3).read_zipper()),&[]);
                  }
                  v149_5_cursor.ascend(1);
                }
                }
                v149_5_cursor.ascend(1);
              }
              }
              v149_5_cursor.ascend(1);
            }
            }
            v149_5_cursor.ascend(1);
          }
          }
          v149_5_cursor.ascend(1);
        }
        }
        v149_5_cursor.ascend(1);
      }
      }
      v149_5_cursor.ascend(1);
    }
    }
    v149_5_cursor.ascend(1);
  }
  drop(v149_5_cursor);
  drop(v149_5_write);
  (v149_5).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v158_5 = Space::new();
  let mut v158_5_write = v158_5.write_zipper();
  let mut v158_5_cursor = (*s0).read_zipper();
  let v158_5_origin = v158_5_cursor.path().len();
  for v158_5_byte in v158_5_cursor.child_mask().iter() {
    v158_5_cursor.descend_to_existing_byte(v158_5_byte);
    {
    for v159_2_byte in v158_5_cursor.child_mask().iter() {
      v158_5_cursor.descend_to_existing_byte(v159_2_byte);
      {
      for v160_3_byte in v158_5_cursor.child_mask().iter() {
        v158_5_cursor.descend_to_existing_byte(v160_3_byte);
        {
        for v161_3_byte in v158_5_cursor.child_mask().iter() {
          v158_5_cursor.descend_to_existing_byte(v161_3_byte);
          {
          for v162_3_byte in v158_5_cursor.child_mask().iter() {
            v158_5_cursor.descend_to_existing_byte(v162_3_byte);
            {
            for v163_2_byte in v158_5_cursor.child_mask().iter() {
              v158_5_cursor.descend_to_existing_byte(v163_2_byte);
              {
              for v164_3_byte in v158_5_cursor.child_mask().iter() {
                v158_5_cursor.descend_to_existing_byte(v164_3_byte);
                {
                for v165_3_byte in v158_5_cursor.child_mask().iter() {
                  v158_5_cursor.descend_to_existing_byte(v165_3_byte);
                  {
                  let v166_3: Space = routine_19(c, &v158_5_cursor.path()[(v158_5_origin + 4)..(v158_5_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p0), &v158_5_cursor.path()[v158_5_origin..(v158_5_origin + 4)], &v158_5_cursor);
                  join_wrapped_into(&mut v158_5_write,&((v166_3).read_zipper()),&[]);
                  }
                  v158_5_cursor.ascend(1);
                }
                }
                v158_5_cursor.ascend(1);
              }
              }
              v158_5_cursor.ascend(1);
            }
            }
            v158_5_cursor.ascend(1);
          }
          }
          v158_5_cursor.ascend(1);
        }
        }
        v158_5_cursor.ascend(1);
      }
      }
      v158_5_cursor.ascend(1);
    }
    }
    v158_5_cursor.ascend(1);
  }
  drop(v158_5_cursor);
  drop(v158_5_write);
  (v158_5).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v167_5 = Space::new();
  let mut v167_5_write = v167_5.write_zipper();
  let mut v167_5_cursor = (*s0).read_zipper();
  let v167_5_origin = v167_5_cursor.path().len();
  for v167_5_byte in v167_5_cursor.child_mask().iter() {
    v167_5_cursor.descend_to_existing_byte(v167_5_byte);
    {
    for v168_2_byte in v167_5_cursor.child_mask().iter() {
      v167_5_cursor.descend_to_existing_byte(v168_2_byte);
      {
      for v169_3_byte in v167_5_cursor.child_mask().iter() {
        v167_5_cursor.descend_to_existing_byte(v169_3_byte);
        {
        for v170_3_byte in v167_5_cursor.child_mask().iter() {
          v167_5_cursor.descend_to_existing_byte(v170_3_byte);
          {
          for v171_3_byte in v167_5_cursor.child_mask().iter() {
            v167_5_cursor.descend_to_existing_byte(v171_3_byte);
            {
            for v172_2_byte in v167_5_cursor.child_mask().iter() {
              v167_5_cursor.descend_to_existing_byte(v172_2_byte);
              {
              for v173_3_byte in v167_5_cursor.child_mask().iter() {
                v167_5_cursor.descend_to_existing_byte(v173_3_byte);
                {
                for v174_3_byte in v167_5_cursor.child_mask().iter() {
                  v167_5_cursor.descend_to_existing_byte(v174_3_byte);
                  {
                  let v175_3: Space = routine_20(c, &v167_5_cursor.path()[(v167_5_origin + 4)..(v167_5_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p0), &v167_5_cursor.path()[v167_5_origin..(v167_5_origin + 4)], &v167_5_cursor);
                  join_wrapped_into(&mut v167_5_write,&((v175_3).read_zipper()),&[]);
                  }
                  v167_5_cursor.ascend(1);
                }
                }
                v167_5_cursor.ascend(1);
              }
              }
              v167_5_cursor.ascend(1);
            }
            }
            v167_5_cursor.ascend(1);
          }
          }
          v167_5_cursor.ascend(1);
        }
        }
        v167_5_cursor.ascend(1);
      }
      }
      v167_5_cursor.ascend(1);
    }
    }
    v167_5_cursor.ascend(1);
  }
  drop(v167_5_cursor);
  drop(v167_5_write);
  (v167_5).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v176_11: Space = routine_10(c, &(*CONSTANT_0), &(*CONSTANT_6), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v176_14: Space = routine_10(c, &(*CONSTANT_2), &(*CONSTANT_6), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v176_15: Space = unite(&(v176_11),&(v176_14));
  let v176_18: Space = routine_10(c, &(*CONSTANT_3), &(*CONSTANT_6), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v176_19: Space = unite(&(v176_15),&(v176_18));
  let v176_22: Space = routine_10(c, &(*CONSTANT_4), &(*CONSTANT_6), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v176_23: Space = unite(&(v176_19),&(v176_22));
  let v176_26: Space = routine_10(c, &(*CONSTANT_5), &(*CONSTANT_6), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v176_27: Space = unite(&(v176_23),&(v176_26));
  let v176_29: Space = routine_10(c, &(*CONSTANT_6), &(*CONSTANT_6), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v176_30: Space = unite(&(v176_27),&(v176_29));
  let v176_33: Space = routine_10(c, &(*CONSTANT_7), &(*CONSTANT_6), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v176_34: Space = unite(&(v176_30),&(v176_33));
  let v176_37: Space = routine_10(c, &(*CONSTANT_1), &(*CONSTANT_6), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v176_38: Space = unite(&(v176_34),&(v176_37));
  let v176_40: Space = intersect(&(v176_38),&(*CONSTANT_12));
  let v176_41: Space = unite(&(v176_40),&(*s1));
  let v176_42: Path = concat_path(&(*p1),&(*p2));
  let v176_43: Path = concat_path(&(v176_42),&(*p3));
  drop(v176_42);
  let v176_44: Path = concat_path(&(v176_43),&(*p4));
  drop(v176_43);
  let v176_45: Path = concat_path(&(v176_44),&(*p5));
  drop(v176_44);
  let v176_46: Space = wrap(&(v176_41),&(v176_45));
  drop(v176_45);
  let v176_47: Space = wrap(&(v176_46),&(*p0));
  (v176_47).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let v177_10: Space = subtract(&(*CONSTANT_8),&(descend_cursor((*s0).read_zipper(),&(*CONSTANT_7))));
  let v177_12: Path = concat_path(&(*p1),&(*p2));
  let v177_13: Path = concat_path(&(v177_12),&(*p3));
  drop(v177_12);
  let v177_14: Path = concat_path(&(v177_13),&(*p4));
  drop(v177_13);
  let v177_15: Path = concat_path(&(v177_14),&(*p5));
  drop(v177_14);
  let v177_16: Path = concat_path(&(v177_15),&(*p0));
  drop(v177_15);
  let mut v177_17 = Space::new();
  let mut v177_17_write = v177_17.write_zipper();
  let mut v177_17_cursor = (v177_10).read_zipper();
  let v177_17_origin = v177_17_cursor.path().len();
  for v177_17_byte in v177_17_cursor.child_mask().iter() {
    v177_17_cursor.descend_to_existing_byte(v177_17_byte);
    {
    for v178_2_byte in v177_17_cursor.child_mask().iter() {
      v177_17_cursor.descend_to_existing_byte(v178_2_byte);
      {
      for v179_3_byte in v177_17_cursor.child_mask().iter() {
        v177_17_cursor.descend_to_existing_byte(v179_3_byte);
        {
        for v180_3_byte in v177_17_cursor.child_mask().iter() {
          v177_17_cursor.descend_to_existing_byte(v180_3_byte);
          {
          let v181_3: Space = routine_1(c, &v177_17_cursor.path()[v177_17_origin..(v177_17_origin + 4)], &(*CONSTANT_7), &(*CONSTANT_1));
          let v181_4: Space = unite(&(*s0),&(v181_3));
          let v181_5: Space = wrap(&(v181_4),&(v177_16));
          join_wrapped_into(&mut v177_17_write,&((v181_5).read_zipper()),&v177_17_cursor.path()[v177_17_origin..(v177_17_origin + 4)]);
          }
          v177_17_cursor.ascend(1);
        }
        }
        v177_17_cursor.ascend(1);
      }
      }
      v177_17_cursor.ascend(1);
    }
    }
    v177_17_cursor.ascend(1);
  }
  drop(v177_17_cursor);
  drop(v177_17_write);
  drop(v177_10);
  drop(v177_16);
  (v177_17).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v182_9 = Space::new();
  let mut v182_9_write = v182_9.write_zipper();
  let mut v182_9_cursor = (*s0).read_zipper();
  let v182_9_origin = v182_9_cursor.path().len();
  for v182_9_byte in v182_9_cursor.child_mask().iter() {
    v182_9_cursor.descend_to_existing_byte(v182_9_byte);
    {
    for v183_2_byte in v182_9_cursor.child_mask().iter() {
      v182_9_cursor.descend_to_existing_byte(v183_2_byte);
      {
      for v184_3_byte in v182_9_cursor.child_mask().iter() {
        v182_9_cursor.descend_to_existing_byte(v184_3_byte);
        {
        for v185_3_byte in v182_9_cursor.child_mask().iter() {
          v182_9_cursor.descend_to_existing_byte(v185_3_byte);
          {
          let v186_3: Space = subtract(&(*CONSTANT_8),&(descend_cursor(cursor_at(&v182_9_cursor,(v182_9_origin + 4)),&(*CONSTANT_1))));
          let mut v186_5_cursor = (v186_3).read_zipper();
          let v186_5_origin = v186_5_cursor.path().len();
          for v186_5_byte in v186_5_cursor.child_mask().iter() {
            v186_5_cursor.descend_to_existing_byte(v186_5_byte);
            {
            for v187_2_byte in v186_5_cursor.child_mask().iter() {
              v186_5_cursor.descend_to_existing_byte(v187_2_byte);
              {
              for v188_3_byte in v186_5_cursor.child_mask().iter() {
                v186_5_cursor.descend_to_existing_byte(v188_3_byte);
                {
                for v189_3_byte in v186_5_cursor.child_mask().iter() {
                  v186_5_cursor.descend_to_existing_byte(v189_3_byte);
                  {
                  let v190_3: Space = routine_21(c, &v186_5_cursor.path()[v186_5_origin..(v186_5_origin + 4)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v182_9_cursor.path()[v182_9_origin..(v182_9_origin + 4)], &v186_5_cursor, &v182_9_cursor);
                  join_wrapped_into(&mut v182_9_write,&((v190_3).read_zipper()),&[]);
                  }
                  v186_5_cursor.ascend(1);
                }
                }
                v186_5_cursor.ascend(1);
              }
              }
              v186_5_cursor.ascend(1);
            }
            }
            v186_5_cursor.ascend(1);
          }
          drop(v186_5_cursor);
          drop(v186_3);
          }
          v182_9_cursor.ascend(1);
        }
        }
        v182_9_cursor.ascend(1);
      }
      }
      v182_9_cursor.ascend(1);
    }
    }
    v182_9_cursor.ascend(1);
  }
  drop(v182_9_cursor);
  drop(v182_9_write);
  (v182_9).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v191_7 = Space::new();
  let mut v191_7_write = v191_7.write_zipper();
  let mut v191_7_cursor = (*s0).read_zipper();
  let v191_7_origin = v191_7_cursor.path().len();
  for v191_7_byte in v191_7_cursor.child_mask().iter() {
    v191_7_cursor.descend_to_existing_byte(v191_7_byte);
    {
    for v192_2_byte in v191_7_cursor.child_mask().iter() {
      v191_7_cursor.descend_to_existing_byte(v192_2_byte);
      {
      for v193_3_byte in v191_7_cursor.child_mask().iter() {
        v191_7_cursor.descend_to_existing_byte(v193_3_byte);
        {
        for v194_3_byte in v191_7_cursor.child_mask().iter() {
          v191_7_cursor.descend_to_existing_byte(v194_3_byte);
          {
          for v195_3_byte in v191_7_cursor.child_mask().iter() {
            v191_7_cursor.descend_to_existing_byte(v195_3_byte);
            {
            for v196_2_byte in v191_7_cursor.child_mask().iter() {
              v191_7_cursor.descend_to_existing_byte(v196_2_byte);
              {
              for v197_3_byte in v191_7_cursor.child_mask().iter() {
                v191_7_cursor.descend_to_existing_byte(v197_3_byte);
                {
                for v198_3_byte in v191_7_cursor.child_mask().iter() {
                  v191_7_cursor.descend_to_existing_byte(v198_3_byte);
                  {
                  let v199_3: Space = routine_22(c, &v191_7_cursor.path()[(v191_7_origin + 4)..(v191_7_origin + 8)], &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &v191_7_cursor.path()[v191_7_origin..(v191_7_origin + 4)], &v191_7_cursor);
                  join_wrapped_into(&mut v191_7_write,&((v199_3).read_zipper()),&[]);
                  }
                  v191_7_cursor.ascend(1);
                }
                }
                v191_7_cursor.ascend(1);
              }
              }
              v191_7_cursor.ascend(1);
            }
            }
            v191_7_cursor.ascend(1);
          }
          }
          v191_7_cursor.ascend(1);
        }
        }
        v191_7_cursor.ascend(1);
      }
      }
      v191_7_cursor.ascend(1);
    }
    }
    v191_7_cursor.ascend(1);
  }
  drop(v191_7_cursor);
  drop(v191_7_write);
  (v191_7).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v200_13: Space = routine_10(c, &(*CONSTANT_0), &(*CONSTANT_1), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v200_16: Space = routine_10(c, &(*CONSTANT_2), &(*CONSTANT_1), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v200_17: Space = unite(&(v200_13),&(v200_16));
  let v200_20: Space = routine_10(c, &(*CONSTANT_3), &(*CONSTANT_1), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v200_21: Space = unite(&(v200_17),&(v200_20));
  let v200_24: Space = routine_10(c, &(*CONSTANT_4), &(*CONSTANT_1), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v200_25: Space = unite(&(v200_21),&(v200_24));
  let v200_28: Space = routine_10(c, &(*CONSTANT_5), &(*CONSTANT_1), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v200_29: Space = unite(&(v200_25),&(v200_28));
  let v200_32: Space = routine_10(c, &(*CONSTANT_6), &(*CONSTANT_1), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v200_33: Space = unite(&(v200_29),&(v200_32));
  let v200_36: Space = routine_10(c, &(*CONSTANT_7), &(*CONSTANT_1), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v200_37: Space = unite(&(v200_33),&(v200_36));
  let v200_39: Space = routine_10(c, &(*CONSTANT_1), &(*CONSTANT_1), &(*p0), &((*CONSTANT_11).read_zipper()));
  let v200_40: Space = unite(&(v200_37),&(v200_39));
  let v200_42: Space = intersect(&(v200_40),&(*CONSTANT_12));
  let v200_43: Space = unite(&(v200_42),&(*s1));
  let v200_44: Path = concat_path(&(*p1),&(*p2));
  let v200_45: Path = concat_path(&(v200_44),&(*p3));
  drop(v200_44);
  let v200_46: Path = concat_path(&(v200_45),&(*p4));
  drop(v200_45);
  let v200_47: Path = concat_path(&(v200_46),&(*p5));
  drop(v200_46);
  let v200_48: Path = concat_path(&(v200_47),&(*p6));
  drop(v200_47);
  let v200_49: Path = concat_path(&(v200_48),&(*p7));
  drop(v200_48);
  let v200_50: Space = wrap(&(v200_43),&(v200_49));
  drop(v200_49);
  let v200_51: Space = wrap(&(v200_50),&(*p0));
  (v200_51).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], p3: &[u8], p4: &[u8], p5: &[u8], p6: &[u8], p7: &[u8], s0: &View<'_, '_>) -> Space {
  let v201_9: Path = concat_path(&(*p1),&(*p2));
  let v201_10: Path = concat_path(&(v201_9),&(*p3));
  drop(v201_9);
  let v201_11: Path = concat_path(&(v201_10),&(*p4));
  drop(v201_10);
  let v201_12: Path = concat_path(&(v201_11),&(*p5));
  drop(v201_11);
  let v201_13: Path = concat_path(&(v201_12),&(*p6));
  drop(v201_12);
  let v201_14: Path = concat_path(&(v201_13),&(*p7));
  drop(v201_13);
  let v201_15: Path = concat_path(&(v201_14),&(*p0));
  drop(v201_14);
  let v201_16: Space = singleton(&(v201_15));
  drop(v201_15);
  (v201_16).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
