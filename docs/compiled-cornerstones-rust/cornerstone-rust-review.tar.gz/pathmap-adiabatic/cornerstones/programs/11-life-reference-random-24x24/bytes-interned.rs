#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 0 0 2 4 0 0 0 3"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,2]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 8 4 0 0 0 9 4 0 0 0 10 4 0 0 0 11 4 0 0 0 12"));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,3]));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 3 4 0 0 0 8 4 0 0 0 10 4 0 0 0 13 4 0 0 0 14"));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,4]));
static CONSTANT_7: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 4 0 0 0 5 4 0 0 0 6 4 0 0 0 7"));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,5]));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 4 0 0 0 6 4 0 0 0 7 4 0 0 0 12 4 0 0 0 18"));
static CONSTANT_10: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,6]));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 1 4 0 0 0 9 4 0 0 0 11 4 0 0 0 12 4 0 0 0 19"));
static CONSTANT_12: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,7]));
static CONSTANT_13: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 12 4 0 0 0 14 4 0 0 0 17 4 0 0 0 20 4 0 0 0 23"));
static CONSTANT_14: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,8]));
static CONSTANT_15: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 4 0 0 0 15 4 0 0 0 16 4 0 0 0 17"));
static CONSTANT_16: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,9]));
static CONSTANT_17: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 4 0 0 0 2 4 0 0 0 5 4 0 0 0 8 4 0 0 0 14 4 0 0 0 20 4 0 0 0 21 4 0 0 0 24"));
static CONSTANT_18: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,10]));
static CONSTANT_19: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 4 4 0 0 0 12 4 0 0 0 14 4 0 0 0 17 4 0 0 0 23"));
static CONSTANT_20: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,11]));
static CONSTANT_21: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 4 0 0 0 4 4 0 0 0 6 4 0 0 0 7 4 0 0 0 11 4 0 0 0 17 4 0 0 0 22"));
static CONSTANT_22: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,12]));
static CONSTANT_23: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 4 0 0 0 8 4 0 0 0 10 4 0 0 0 13 4 0 0 0 14 4 0 0 0 16 4 0 0 0 21 4 0 0 0 22 4 0 0 0 23"));
static CONSTANT_24: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,13]));
static CONSTANT_25: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 4 4 0 0 0 14 4 0 0 0 17 4 0 0 0 18 4 0 0 0 23"));
static CONSTANT_26: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,14]));
static CONSTANT_27: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 2 4 0 0 0 8 4 0 0 0 9 4 0 0 0 16 4 0 0 0 23"));
static CONSTANT_28: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,15]));
static CONSTANT_29: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 1"));
static CONSTANT_30: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,16]));
static CONSTANT_31: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 4 0 0 0 9 4 0 0 0 13 4 0 0 0 18"));
static CONSTANT_32: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,17]));
static CONSTANT_33: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 4 0 0 0 2 4 0 0 0 5 4 0 0 0 18"));
static CONSTANT_34: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,18]));
static CONSTANT_35: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 5 4 0 0 0 12 4 0 0 0 19 4 0 0 0 20 4 0 0 0 22"));
static CONSTANT_36: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,19]));
static CONSTANT_37: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 4 0 0 0 3 4 0 0 0 11 4 0 0 0 12 4 0 0 0 14 4 0 0 0 16 4 0 0 0 18"));
static CONSTANT_38: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,20]));
static CONSTANT_39: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 4 0 0 0 4 4 0 0 0 7 4 0 0 0 11 4 0 0 0 13 4 0 0 0 14 4 0 0 0 15 4 0 0 0 16 4 0 0 0 21"));
static CONSTANT_40: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,21]));
static CONSTANT_41: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("9 4 0 0 0 8 4 0 0 0 9 4 0 0 0 11 4 0 0 0 12 4 0 0 0 13 4 0 0 0 15 4 0 0 0 17 4 0 0 0 22 4 0 0 0 23"));
static CONSTANT_42: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,22]));
static CONSTANT_43: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 4 0 0 0 3 4 0 0 0 7 4 0 0 0 10 4 0 0 0 15 4 0 0 0 16 4 0 0 0 19 4 0 0 0 20"));
static CONSTANT_44: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,23]));
static CONSTANT_45: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 4 0 0 0 2 4 0 0 0 4 4 0 0 0 6 4 0 0 0 7 4 0 0 0 14 4 0 0 0 16 4 0 0 0 22"));
static CONSTANT_46: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,24]));
static CONSTANT_47: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 4 0 0 0 15 4 0 0 0 17 4 0 0 0 24"));
static CONSTANT_48: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("120 12 0 0 0 0 0 0 0 1 0 0 0 2 12 0 0 0 0 0 0 0 1 0 0 0 3 12 0 0 0 0 0 0 0 2 0 0 0 8 12 0 0 0 0 0 0 0 2 0 0 0 9 12 0 0 0 0 0 0 0 2 0 0 0 10 12 0 0 0 0 0 0 0 2 0 0 0 11 12 0 0 0 0 0 0 0 2 0 0 0 12 12 0 0 0 0 0 0 0 3 0 0 0 3 12 0 0 0 0 0 0 0 3 0 0 0 8 12 0 0 0 0 0 0 0 3 0 0 0 10 12 0 0 0 0 0 0 0 3 0 0 0 13 12 0 0 0 0 0 0 0 3 0 0 0 14 12 0 0 0 0 0 0 0 4 0 0 0 5 12 0 0 0 0 0 0 0 4 0 0 0 6 12 0 0 0 0 0 0 0 4 0 0 0 7 12 0 0 0 0 0 0 0 5 0 0 0 6 12 0 0 0 0 0 0 0 5 0 0 0 7 12 0 0 0 0 0 0 0 5 0 0 0 12 12 0 0 0 0 0 0 0 5 0 0 0 18 12 0 0 0 0 0 0 0 6 0 0 0 1 12 0 0 0 0 0 0 0 6 0 0 0 9 12 0 0 0 0 0 0 0 6 0 0 0 11 12 0 0 0 0 0 0 0 6 0 0 0 12 12 0 0 0 0 0 0 0 6 0 0 0 19 12 0 0 0 0 0 0 0 7 0 0 0 12 12 0 0 0 0 0 0 0 7 0 0 0 14 12 0 0 0 0 0 0 0 7 0 0 0 17 12 0 0 0 0 0 0 0 7 0 0 0 20 12 0 0 0 0 0 0 0 7 0 0 0 23 12 0 0 0 0 0 0 0 8 0 0 0 15 12 0 0 0 0 0 0 0 8 0 0 0 16 12 0 0 0 0 0 0 0 8 0 0 0 17 12 0 0 0 0 0 0 0 9 0 0 0 2 12 0 0 0 0 0 0 0 9 0 0 0 5 12 0 0 0 0 0 0 0 9 0 0 0 8 12 0 0 0 0 0 0 0 9 0 0 0 14 12 0 0 0 0 0 0 0 9 0 0 0 20 12 0 0 0 0 0 0 0 9 0 0 0 21 12 0 0 0 0 0 0 0 9 0 0 0 24 12 0 0 0 0 0 0 0 10 0 0 0 4 12 0 0 0 0 0 0 0 10 0 0 0 12 12 0 0 0 0 0 0 0 10 0 0 0 14 12 0 0 0 0 0 0 0 10 0 0 0 17 12 0 0 0 0 0 0 0 10 0 0 0 23 12 0 0 0 0 0 0 0 11 0 0 0 4 12 0 0 0 0 0 0 0 11 0 0 0 6 12 0 0 0 0 0 0 0 11 0 0 0 7 12 0 0 0 0 0 0 0 11 0 0 0 11 12 0 0 0 0 0 0 0 11 0 0 0 17 12 0 0 0 0 0 0 0 11 0 0 0 22 12 0 0 0 0 0 0 0 12 0 0 0 8 12 0 0 0 0 0 0 0 12 0 0 0 10 12 0 0 0 0 0 0 0 12 0 0 0 13 12 0 0 0 0 0 0 0 12 0 0 0 14 12 0 0 0 0 0 0 0 12 0 0 0 16 12 0 0 0 0 0 0 0 12 0 0 0 21 12 0 0 0 0 0 0 0 12 0 0 0 22 12 0 0 0 0 0 0 0 12 0 0 0 23 12 0 0 0 0 0 0 0 13 0 0 0 4 12 0 0 0 0 0 0 0 13 0 0 0 14 12 0 0 0 0 0 0 0 13 0 0 0 17 12 0 0 0 0 0 0 0 13 0 0 0 18 12 0 0 0 0 0 0 0 13 0 0 0 23 12 0 0 0 0 0 0 0 14 0 0 0 2 12 0 0 0 0 0 0 0 14 0 0 0 8 12 0 0 0 0 0 0 0 14 0 0 0 9 12 0 0 0 0 0 0 0 14 0 0 0 16 12 0 0 0 0 0 0 0 14 0 0 0 23 12 0 0 0 0 0 0 0 15 0 0 0 1 12 0 0 0 0 0 0 0 16 0 0 0 9 12 0 0 0 0 0 0 0 16 0 0 0 13 12 0 0 0 0 0 0 0 16 0 0 0 18 12 0 0 0 0 0 0 0 17 0 0 0 2 12 0 0 0 0 0 0 0 17 0 0 0 5 12 0 0 0 0 0 0 0 17 0 0 0 18 12 0 0 0 0 0 0 0 18 0 0 0 5 12 0 0 0 0 0 0 0 18 0 0 0 12 12 0 0 0 0 0 0 0 18 0 0 0 19 12 0 0 0 0 0 0 0 18 0 0 0 20 12 0 0 0 0 0 0 0 18 0 0 0 22 12 0 0 0 0 0 0 0 19 0 0 0 3 12 0 0 0 0 0 0 0 19 0 0 0 11 12 0 0 0 0 0 0 0 19 0 0 0 12 12 0 0 0 0 0 0 0 19 0 0 0 14 12 0 0 0 0 0 0 0 19 0 0 0 16 12 0 0 0 0 0 0 0 19 0 0 0 18 12 0 0 0 0 0 0 0 20 0 0 0 4 12 0 0 0 0 0 0 0 20 0 0 0 7 12 0 0 0 0 0 0 0 20 0 0 0 11 12 0 0 0 0 0 0 0 20 0 0 0 13 12 0 0 0 0 0 0 0 20 0 0 0 14 12 0 0 0 0 0 0 0 20 0 0 0 15 12 0 0 0 0 0 0 0 20 0 0 0 16 12 0 0 0 0 0 0 0 20 0 0 0 21 12 0 0 0 0 0 0 0 21 0 0 0 8 12 0 0 0 0 0 0 0 21 0 0 0 9 12 0 0 0 0 0 0 0 21 0 0 0 11 12 0 0 0 0 0 0 0 21 0 0 0 12 12 0 0 0 0 0 0 0 21 0 0 0 13 12 0 0 0 0 0 0 0 21 0 0 0 15 12 0 0 0 0 0 0 0 21 0 0 0 17 12 0 0 0 0 0 0 0 21 0 0 0 22 12 0 0 0 0 0 0 0 21 0 0 0 23 12 0 0 0 0 0 0 0 22 0 0 0 3 12 0 0 0 0 0 0 0 22 0 0 0 7 12 0 0 0 0 0 0 0 22 0 0 0 10 12 0 0 0 0 0 0 0 22 0 0 0 15 12 0 0 0 0 0 0 0 22 0 0 0 16 12 0 0 0 0 0 0 0 22 0 0 0 19 12 0 0 0 0 0 0 0 22 0 0 0 20 12 0 0 0 0 0 0 0 23 0 0 0 2 12 0 0 0 0 0 0 0 23 0 0 0 4 12 0 0 0 0 0 0 0 23 0 0 0 6 12 0 0 0 0 0 0 0 23 0 0 0 7 12 0 0 0 0 0 0 0 23 0 0 0 14 12 0 0 0 0 0 0 0 23 0 0 0 16 12 0 0 0 0 0 0 0 23 0 0 0 22 12 0 0 0 0 0 0 0 24 0 0 0 15 12 0 0 0 0 0 0 0 24 0 0 0 17 12 0 0 0 0 0 0 0 24 0 0 0 24"));
static CONSTANT_49: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_50: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_51: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 132"));
static CONSTANT_52: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("387 8 0 0 0 1 0 0 0 1 8 0 0 0 1 0 0 0 4 8 0 0 0 1 0 0 0 25 8 0 0 0 2 0 0 0 2 8 0 0 0 2 0 0 0 3 8 0 0 0 2 0 0 0 12 8 0 0 0 3 0 0 0 2 8 0 0 0 3 0 0 0 3 8 0 0 0 3 0 0 0 8 8 0 0 0 4 0 0 0 1 8 0 0 0 4 0 0 0 4 8 0 0 0 4 0 0 0 17 8 0 0 0 5 0 0 0 5 8 0 0 0 5 0 0 0 6 8 0 0 0 5 0 0 0 8 8 0 0 0 6 0 0 0 5 8 0 0 0 6 0 0 0 6 8 0 0 0 6 0 0 0 20 8 0 0 0 7 0 0 0 7 8 0 0 0 7 0 0 0 16 8 0 0 0 7 0 0 0 18 8 0 0 0 8 0 0 0 3 8 0 0 0 8 0 0 0 5 8 0 0 0 8 0 0 0 8 8 0 0 0 9 0 0 0 9 8 0 0 0 9 0 0 0 16 8 0 0 0 9 0 0 0 21 8 0 0 0 10 0 0 0 10 8 0 0 0 10 0 0 0 24 8 0 0 0 10 0 0 0 90 8 0 0 0 11 0 0 0 11 8 0 0 0 11 0 0 0 14 8 0 0 0 11 0 0 0 23 8 0 0 0 12 0 0 0 2 8 0 0 0 12 0 0 0 12 8 0 0 0 12 0 0 0 19 8 0 0 0 13 0 0 0 13 8 0 0 0 13 0 0 0 17 8 0 0 0 13 0 0 0 22 8 0 0 0 14 0 0 0 11 8 0 0 0 14 0 0 0 14 8 0 0 0 14 0 0 0 22 8 0 0 0 15 0 0 0 15 8 0 0 0 15 0 0 0 20 8 0 0 0 15 0 0 0 21 8 0 0 0 16 0 0 0 7 8 0 0 0 16 0 0 0 9 8 0 0 0 16 0 0 0 16 8 0 0 0 17 0 0 0 4 8 0 0 0 17 0 0 0 13 8 0 0 0 17 0 0 0 17 8 0 0 0 18 0 0 0 7 8 0 0 0 18 0 0 0 18 8 0 0 0 18 0 0 0 24 8 0 0 0 19 0 0 0 12 8 0 0 0 19 0 0 0 19 8 0 0 0 19 0 0 0 23 8 0 0 0 20 0 0 0 6 8 0 0 0 20 0 0 0 15 8 0 0 0 20 0 0 0 20 8 0 0 0 21 0 0 0 9 8 0 0 0 21 0 0 0 15 8 0 0 0 21 0 0 0 21 8 0 0 0 22 0 0 0 13 8 0 0 0 22 0 0 0 14 8 0 0 0 22 0 0 0 22 8 0 0 0 23 0 0 0 11 8 0 0 0 23 0 0 0 19 8 0 0 0 23 0 0 0 23 8 0 0 0 24 0 0 0 10 8 0 0 0 24 0 0 0 18 8 0 0 0 24 0 0 0 24 8 0 0 0 25 0 0 0 1 8 0 0 0 25 0 0 0 25 8 0 0 0 25 0 0 0 26 8 0 0 0 26 0 0 0 25 8 0 0 0 26 0 0 0 26 8 0 0 0 26 0 0 0 38 8 0 0 0 27 0 0 0 27 8 0 0 0 27 0 0 0 28 8 0 0 0 27 0 0 0 89 8 0 0 0 28 0 0 0 27 8 0 0 0 28 0 0 0 28 8 0 0 0 28 0 0 0 29 8 0 0 0 29 0 0 0 28 8 0 0 0 29 0 0 0 29 8 0 0 0 29 0 0 0 30 8 0 0 0 30 0 0 0 29 8 0 0 0 30 0 0 0 30 8 0 0 0 30 0 0 0 31 8 0 0 0 31 0 0 0 30 8 0 0 0 31 0 0 0 31 8 0 0 0 31 0 0 0 32 8 0 0 0 32 0 0 0 31 8 0 0 0 32 0 0 0 32 8 0 0 0 32 0 0 0 33 8 0 0 0 33 0 0 0 32 8 0 0 0 33 0 0 0 33 8 0 0 0 33 0 0 0 34 8 0 0 0 34 0 0 0 33 8 0 0 0 34 0 0 0 34 8 0 0 0 34 0 0 0 35 8 0 0 0 35 0 0 0 34 8 0 0 0 35 0 0 0 35 8 0 0 0 35 0 0 0 36 8 0 0 0 36 0 0 0 35 8 0 0 0 36 0 0 0 36 8 0 0 0 36 0 0 0 37 8 0 0 0 37 0 0 0 36 8 0 0 0 37 0 0 0 37 8 0 0 0 37 0 0 0 39 8 0 0 0 38 0 0 0 26 8 0 0 0 38 0 0 0 38 8 0 0 0 38 0 0 0 49 8 0 0 0 39 0 0 0 37 8 0 0 0 39 0 0 0 39 8 0 0 0 39 0 0 0 40 8 0 0 0 40 0 0 0 39 8 0 0 0 40 0 0 0 40 8 0 0 0 40 0 0 0 41 8 0 0 0 41 0 0 0 40 8 0 0 0 41 0 0 0 41 8 0 0 0 41 0 0 0 42 8 0 0 0 42 0 0 0 41 8 0 0 0 42 0 0 0 42 8 0 0 0 42 0 0 0 43 8 0 0 0 43 0 0 0 42 8 0 0 0 43 0 0 0 43 8 0 0 0 43 0 0 0 44 8 0 0 0 44 0 0 0 43 8 0 0 0 44 0 0 0 44 8 0 0 0 44 0 0 0 45 8 0 0 0 45 0 0 0 44 8 0 0 0 45 0 0 0 45 8 0 0 0 45 0 0 0 46 8 0 0 0 46 0 0 0 45 8 0 0 0 46 0 0 0 46 8 0 0 0 46 0 0 0 47 8 0 0 0 47 0 0 0 46 8 0 0 0 47 0 0 0 47 8 0 0 0 47 0 0 0 48 8 0 0 0 48 0 0 0 47 8 0 0 0 48 0 0 0 48 8 0 0 0 48 0 0 0 50 8 0 0 0 49 0 0 0 38 8 0 0 0 49 0 0 0 49 8 0 0 0 49 0 0 0 60 8 0 0 0 50 0 0 0 48 8 0 0 0 50 0 0 0 50 8 0 0 0 50 0 0 0 51 8 0 0 0 51 0 0 0 50 8 0 0 0 51 0 0 0 51 8 0 0 0 51 0 0 0 52 8 0 0 0 52 0 0 0 51 8 0 0 0 52 0 0 0 52 8 0 0 0 52 0 0 0 53 8 0 0 0 53 0 0 0 52 8 0 0 0 53 0 0 0 53 8 0 0 0 53 0 0 0 54 8 0 0 0 54 0 0 0 53 8 0 0 0 54 0 0 0 54 8 0 0 0 54 0 0 0 55 8 0 0 0 55 0 0 0 54 8 0 0 0 55 0 0 0 55 8 0 0 0 55 0 0 0 56 8 0 0 0 56 0 0 0 55 8 0 0 0 56 0 0 0 56 8 0 0 0 56 0 0 0 57 8 0 0 0 57 0 0 0 56 8 0 0 0 57 0 0 0 57 8 0 0 0 57 0 0 0 58 8 0 0 0 58 0 0 0 57 8 0 0 0 58 0 0 0 58 8 0 0 0 58 0 0 0 59 8 0 0 0 59 0 0 0 58 8 0 0 0 59 0 0 0 59 8 0 0 0 59 0 0 0 61 8 0 0 0 60 0 0 0 49 8 0 0 0 60 0 0 0 60 8 0 0 0 60 0 0 0 71 8 0 0 0 61 0 0 0 59 8 0 0 0 61 0 0 0 61 8 0 0 0 61 0 0 0 62 8 0 0 0 62 0 0 0 61 8 0 0 0 62 0 0 0 62 8 0 0 0 62 0 0 0 63 8 0 0 0 63 0 0 0 62 8 0 0 0 63 0 0 0 63 8 0 0 0 63 0 0 0 64 8 0 0 0 64 0 0 0 63 8 0 0 0 64 0 0 0 64 8 0 0 0 64 0 0 0 65 8 0 0 0 65 0 0 0 64 8 0 0 0 65 0 0 0 65 8 0 0 0 65 0 0 0 66 8 0 0 0 66 0 0 0 65 8 0 0 0 66 0 0 0 66 8 0 0 0 66 0 0 0 67 8 0 0 0 67 0 0 0 66 8 0 0 0 67 0 0 0 67 8 0 0 0 67 0 0 0 68 8 0 0 0 68 0 0 0 67 8 0 0 0 68 0 0 0 68 8 0 0 0 68 0 0 0 69 8 0 0 0 69 0 0 0 68 8 0 0 0 69 0 0 0 69 8 0 0 0 69 0 0 0 70 8 0 0 0 70 0 0 0 69 8 0 0 0 70 0 0 0 70 8 0 0 0 70 0 0 0 72 8 0 0 0 71 0 0 0 60 8 0 0 0 71 0 0 0 71 8 0 0 0 71 0 0 0 82 8 0 0 0 72 0 0 0 70 8 0 0 0 72 0 0 0 72 8 0 0 0 72 0 0 0 73 8 0 0 0 73 0 0 0 72 8 0 0 0 73 0 0 0 73 8 0 0 0 73 0 0 0 74 8 0 0 0 74 0 0 0 73 8 0 0 0 74 0 0 0 74 8 0 0 0 74 0 0 0 75 8 0 0 0 75 0 0 0 74 8 0 0 0 75 0 0 0 75 8 0 0 0 75 0 0 0 76 8 0 0 0 76 0 0 0 75 8 0 0 0 76 0 0 0 76 8 0 0 0 76 0 0 0 77 8 0 0 0 77 0 0 0 76 8 0 0 0 77 0 0 0 77 8 0 0 0 77 0 0 0 78 8 0 0 0 78 0 0 0 77 8 0 0 0 78 0 0 0 78 8 0 0 0 78 0 0 0 79 8 0 0 0 79 0 0 0 78 8 0 0 0 79 0 0 0 79 8 0 0 0 79 0 0 0 80 8 0 0 0 80 0 0 0 79 8 0 0 0 80 0 0 0 80 8 0 0 0 80 0 0 0 81 8 0 0 0 81 0 0 0 80 8 0 0 0 81 0 0 0 81 8 0 0 0 81 0 0 0 83 8 0 0 0 82 0 0 0 71 8 0 0 0 82 0 0 0 82 8 0 0 0 82 0 0 0 88 8 0 0 0 83 0 0 0 81 8 0 0 0 83 0 0 0 83 8 0 0 0 83 0 0 0 84 8 0 0 0 84 0 0 0 83 8 0 0 0 84 0 0 0 84 8 0 0 0 84 0 0 0 85 8 0 0 0 85 0 0 0 84 8 0 0 0 85 0 0 0 85 8 0 0 0 85 0 0 0 86 8 0 0 0 86 0 0 0 85 8 0 0 0 86 0 0 0 86 8 0 0 0 86 0 0 0 87 8 0 0 0 88 0 0 0 82 8 0 0 0 88 0 0 0 88 8 0 0 0 88 0 0 0 89 8 0 0 0 89 0 0 0 27 8 0 0 0 89 0 0 0 88 8 0 0 0 89 0 0 0 89 8 0 0 0 90 0 0 0 10 8 0 0 0 90 0 0 0 90 8 0 0 0 90 0 0 0 91 8 0 0 0 91 0 0 0 90 8 0 0 0 91 0 0 0 91 8 0 0 0 91 0 0 0 92 8 0 0 0 92 0 0 0 91 8 0 0 0 92 0 0 0 92 8 0 0 0 92 0 0 0 93 8 0 0 0 93 0 0 0 92 8 0 0 0 93 0 0 0 93 8 0 0 0 93 0 0 0 94 8 0 0 0 94 0 0 0 93 8 0 0 0 94 0 0 0 94 8 0 0 0 94 0 0 0 95 8 0 0 0 95 0 0 0 94 8 0 0 0 95 0 0 0 95 8 0 0 0 95 0 0 0 96 8 0 0 0 96 0 0 0 95 8 0 0 0 96 0 0 0 96 8 0 0 0 96 0 0 0 97 8 0 0 0 97 0 0 0 96 8 0 0 0 97 0 0 0 97 8 0 0 0 97 0 0 0 98 8 0 0 0 98 0 0 0 97 8 0 0 0 98 0 0 0 98 8 0 0 0 98 0 0 0 99 8 0 0 0 99 0 0 0 98 8 0 0 0 99 0 0 0 99 8 0 0 0 99 0 0 0 100 8 0 0 0 100 0 0 0 99 8 0 0 0 100 0 0 0 100 8 0 0 0 100 0 0 0 101 8 0 0 0 101 0 0 0 100 8 0 0 0 101 0 0 0 101 8 0 0 0 101 0 0 0 102 8 0 0 0 102 0 0 0 101 8 0 0 0 102 0 0 0 102 8 0 0 0 102 0 0 0 103 8 0 0 0 103 0 0 0 102 8 0 0 0 103 0 0 0 103 8 0 0 0 103 0 0 0 104 8 0 0 0 104 0 0 0 103 8 0 0 0 104 0 0 0 104 8 0 0 0 104 0 0 0 105 8 0 0 0 105 0 0 0 104 8 0 0 0 105 0 0 0 105 8 0 0 0 105 0 0 0 106 8 0 0 0 106 0 0 0 105 8 0 0 0 106 0 0 0 106 8 0 0 0 106 0 0 0 107 8 0 0 0 107 0 0 0 106 8 0 0 0 107 0 0 0 107 8 0 0 0 107 0 0 0 108 8 0 0 0 108 0 0 0 107 8 0 0 0 108 0 0 0 108 8 0 0 0 108 0 0 0 109 8 0 0 0 109 0 0 0 108 8 0 0 0 109 0 0 0 109 8 0 0 0 109 0 0 0 110 8 0 0 0 110 0 0 0 109 8 0 0 0 110 0 0 0 110 8 0 0 0 110 0 0 0 111 8 0 0 0 111 0 0 0 110 8 0 0 0 111 0 0 0 111 8 0 0 0 111 0 0 0 112 8 0 0 0 112 0 0 0 111 8 0 0 0 112 0 0 0 112 8 0 0 0 112 0 0 0 113 8 0 0 0 113 0 0 0 112 8 0 0 0 113 0 0 0 113 8 0 0 0 113 0 0 0 114 8 0 0 0 114 0 0 0 113 8 0 0 0 114 0 0 0 114 8 0 0 0 114 0 0 0 115 8 0 0 0 115 0 0 0 114 8 0 0 0 115 0 0 0 115 8 0 0 0 115 0 0 0 116 8 0 0 0 116 0 0 0 115 8 0 0 0 116 0 0 0 116 8 0 0 0 116 0 0 0 117 8 0 0 0 117 0 0 0 116 8 0 0 0 117 0 0 0 117 8 0 0 0 117 0 0 0 118 8 0 0 0 118 0 0 0 117 8 0 0 0 118 0 0 0 118 8 0 0 0 118 0 0 0 119 8 0 0 0 119 0 0 0 118 8 0 0 0 119 0 0 0 119 8 0 0 0 119 0 0 0 120 8 0 0 0 120 0 0 0 119 8 0 0 0 120 0 0 0 120 8 0 0 0 120 0 0 0 121 8 0 0 0 121 0 0 0 120 8 0 0 0 121 0 0 0 121 8 0 0 0 121 0 0 0 122 8 0 0 0 122 0 0 0 121 8 0 0 0 122 0 0 0 122 8 0 0 0 122 0 0 0 123 8 0 0 0 123 0 0 0 122 8 0 0 0 123 0 0 0 123 8 0 0 0 123 0 0 0 124 8 0 0 0 124 0 0 0 123 8 0 0 0 124 0 0 0 124 8 0 0 0 124 0 0 0 125 8 0 0 0 125 0 0 0 124 8 0 0 0 125 0 0 0 125 8 0 0 0 125 0 0 0 126 8 0 0 0 126 0 0 0 125 8 0 0 0 126 0 0 0 126 8 0 0 0 126 0 0 0 127 8 0 0 0 127 0 0 0 126 8 0 0 0 127 0 0 0 127 8 0 0 0 127 0 0 0 128 8 0 0 0 128 0 0 0 127 8 0 0 0 128 0 0 0 128 8 0 0 0 128 0 0 0 129 8 0 0 0 129 0 0 0 128 8 0 0 0 129 0 0 0 129 8 0 0 0 129 0 0 0 130 8 0 0 0 130 0 0 0 129 8 0 0 0 130 0 0 0 130 8 0 0 0 130 0 0 0 131"));
static CONSTANT_53: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
static CONSTANT_54: std::sync::LazyLock<&'static [&'static [u8]]> = std::sync::LazyLock::new(|| &[&[0,0,0,25],&[0,0,0,27],&[0,0,0,28],&[0,0,0,29],&[0,0,0,30],&[0,0,0,31],&[0,0,0,32],&[0,0,0,33],&[0,0,0,34],&[0,0,0,35],&[0,0,0,36],&[0,0,0,26],&[0,0,0,37],&[0,0,0,39],&[0,0,0,40],&[0,0,0,41],&[0,0,0,42],&[0,0,0,43],&[0,0,0,44],&[0,0,0,45],&[0,0,0,46],&[0,0,0,47],&[0,0,0,38],&[0,0,0,48],&[0,0,0,50],&[0,0,0,51],&[0,0,0,52],&[0,0,0,53],&[0,0,0,54],&[0,0,0,55],&[0,0,0,56],&[0,0,0,57],&[0,0,0,58],&[0,0,0,49],&[0,0,0,59],&[0,0,0,61],&[0,0,0,62],&[0,0,0,63],&[0,0,0,64],&[0,0,0,65],&[0,0,0,66],&[0,0,0,67],&[0,0,0,68],&[0,0,0,69],&[0,0,0,60],&[0,0,0,70],&[0,0,0,72],&[0,0,0,73],&[0,0,0,74],&[0,0,0,75],&[0,0,0,76],&[0,0,0,77],&[0,0,0,78],&[0,0,0,79],&[0,0,0,80],&[0,0,0,71],&[0,0,0,81],&[0,0,0,83],&[0,0,0,84],&[0,0,0,85],&[0,0,0,86],&[0,0,0,87],&[0,0,0,82],&[0,0,0,88],&[0,0,0,89],&[0,0,0,1],&[0,0,0,4],&[0,0,0,2],&[0,0,0,3],&[0,0,0,8],&[0,0,0,5],&[0,0,0,6],&[0,0,0,20],&[0,0,0,15],&[0,0,0,21],&[0,0,0,9],&[0,0,0,16],&[0,0,0,17],&[0,0,0,7],&[0,0,0,18],&[0,0,0,24],&[0,0,0,10],&[0,0,0,90],&[0,0,0,91],&[0,0,0,92],&[0,0,0,93],&[0,0,0,94],&[0,0,0,95],&[0,0,0,13],&[0,0,0,96],&[0,0,0,97],&[0,0,0,98],&[0,0,0,99],&[0,0,0,100],&[0,0,0,101],&[0,0,0,102],&[0,0,0,103],&[0,0,0,104],&[0,0,0,105],&[0,0,0,22],&[0,0,0,106],&[0,0,0,107],&[0,0,0,108],&[0,0,0,109],&[0,0,0,110],&[0,0,0,111],&[0,0,0,112],&[0,0,0,113],&[0,0,0,114],&[0,0,0,115],&[0,0,0,14],&[0,0,0,116],&[0,0,0,117],&[0,0,0,118],&[0,0,0,119],&[0,0,0,120],&[0,0,0,121],&[0,0,0,122],&[0,0,0,123],&[0,0,0,124],&[0,0,0,125],&[0,0,0,11],&[0,0,0,126],&[0,0,0,127],&[0,0,0,128],&[0,0,0,129],&[0,0,0,130],&[0,0,0,131],&[0,0,0,23],&[0,0,0,19],&[0,0,0,12],&[0,0,0,0],&[0,0,0,132]]);
fn routine_0(c: &mut Context) -> Space {
  let v0_2: Space = routine_1(c, &(*CONSTANT_0), &((*CONSTANT_1).read_zipper()));
  let v0_5: Space = routine_1(c, &(*CONSTANT_2), &((*CONSTANT_3).read_zipper()));
  let v0_6: Space = unite(&(v0_2),&(v0_5));
  let v0_9: Space = routine_1(c, &(*CONSTANT_4), &((*CONSTANT_5).read_zipper()));
  let v0_10: Space = unite(&(v0_6),&(v0_9));
  let v0_13: Space = routine_1(c, &(*CONSTANT_6), &((*CONSTANT_7).read_zipper()));
  let v0_14: Space = unite(&(v0_10),&(v0_13));
  let v0_17: Space = routine_1(c, &(*CONSTANT_8), &((*CONSTANT_9).read_zipper()));
  let v0_18: Space = unite(&(v0_14),&(v0_17));
  let v0_21: Space = routine_1(c, &(*CONSTANT_10), &((*CONSTANT_11).read_zipper()));
  let v0_22: Space = unite(&(v0_18),&(v0_21));
  let v0_25: Space = routine_1(c, &(*CONSTANT_12), &((*CONSTANT_13).read_zipper()));
  let v0_26: Space = unite(&(v0_22),&(v0_25));
  let v0_29: Space = routine_1(c, &(*CONSTANT_14), &((*CONSTANT_15).read_zipper()));
  let v0_30: Space = unite(&(v0_26),&(v0_29));
  let v0_33: Space = routine_1(c, &(*CONSTANT_16), &((*CONSTANT_17).read_zipper()));
  let v0_34: Space = unite(&(v0_30),&(v0_33));
  let v0_37: Space = routine_1(c, &(*CONSTANT_18), &((*CONSTANT_19).read_zipper()));
  let v0_38: Space = unite(&(v0_34),&(v0_37));
  let v0_41: Space = routine_1(c, &(*CONSTANT_20), &((*CONSTANT_21).read_zipper()));
  let v0_42: Space = unite(&(v0_38),&(v0_41));
  let v0_45: Space = routine_1(c, &(*CONSTANT_22), &((*CONSTANT_23).read_zipper()));
  let v0_46: Space = unite(&(v0_42),&(v0_45));
  let v0_49: Space = routine_1(c, &(*CONSTANT_24), &((*CONSTANT_25).read_zipper()));
  let v0_50: Space = unite(&(v0_46),&(v0_49));
  let v0_53: Space = routine_1(c, &(*CONSTANT_26), &((*CONSTANT_27).read_zipper()));
  let v0_54: Space = unite(&(v0_50),&(v0_53));
  let v0_57: Space = routine_1(c, &(*CONSTANT_28), &((*CONSTANT_29).read_zipper()));
  let v0_58: Space = unite(&(v0_54),&(v0_57));
  let v0_61: Space = routine_1(c, &(*CONSTANT_30), &((*CONSTANT_31).read_zipper()));
  let v0_62: Space = unite(&(v0_58),&(v0_61));
  let v0_65: Space = routine_1(c, &(*CONSTANT_32), &((*CONSTANT_33).read_zipper()));
  let v0_66: Space = unite(&(v0_62),&(v0_65));
  let v0_69: Space = routine_1(c, &(*CONSTANT_34), &((*CONSTANT_35).read_zipper()));
  let v0_70: Space = unite(&(v0_66),&(v0_69));
  let v0_73: Space = routine_1(c, &(*CONSTANT_36), &((*CONSTANT_37).read_zipper()));
  let v0_74: Space = unite(&(v0_70),&(v0_73));
  let v0_77: Space = routine_1(c, &(*CONSTANT_38), &((*CONSTANT_39).read_zipper()));
  let v0_78: Space = unite(&(v0_74),&(v0_77));
  let v0_81: Space = routine_1(c, &(*CONSTANT_40), &((*CONSTANT_41).read_zipper()));
  let v0_82: Space = unite(&(v0_78),&(v0_81));
  let v0_85: Space = routine_1(c, &(*CONSTANT_42), &((*CONSTANT_43).read_zipper()));
  let v0_86: Space = unite(&(v0_82),&(v0_85));
  let v0_89: Space = routine_1(c, &(*CONSTANT_44), &((*CONSTANT_45).read_zipper()));
  let v0_90: Space = unite(&(v0_86),&(v0_89));
  let v0_93: Space = routine_1(c, &(*CONSTANT_46), &((*CONSTANT_47).read_zipper()));
  let v0_94: Space = unite(&(v0_90),&(v0_93));
  let mut v0_96 = Space::new();
  let mut v0_96_write = v0_96.write_zipper();
  let mut v0_96_cursor = (v0_94).read_zipper();
  let v0_96_origin = v0_96_cursor.path().len();
  for v0_96_byte in v0_96_cursor.child_mask().iter() {
    v0_96_cursor.descend_to_existing_byte(v0_96_byte);
    {
    for v1_2_byte in v0_96_cursor.child_mask().iter() {
      v0_96_cursor.descend_to_existing_byte(v1_2_byte);
      {
      for v2_3_byte in v0_96_cursor.child_mask().iter() {
        v0_96_cursor.descend_to_existing_byte(v2_3_byte);
        {
        for v3_3_byte in v0_96_cursor.child_mask().iter() {
          v0_96_cursor.descend_to_existing_byte(v3_3_byte);
          {
          let v4_3: Space = routine_2(c, &v0_96_cursor.path()[v0_96_origin..(v0_96_origin + 4)], &v0_96_cursor, &((*CONSTANT_48).read_zipper()));
          join_wrapped_into(&mut v0_96_write,&((v4_3).read_zipper()),&[]);
          }
          v0_96_cursor.ascend(1);
        }
        }
        v0_96_cursor.ascend(1);
      }
      }
      v0_96_cursor.ascend(1);
    }
    }
    v0_96_cursor.ascend(1);
  }
  drop(v0_96_cursor);
  drop(v0_96_write);
  let v0_99: Space = routine_3(c, &(*CONSTANT_0), &((*CONSTANT_1).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_100: Space = unite(&(v0_96),&(v0_99));
  let v0_103: Space = routine_3(c, &(*CONSTANT_2), &((*CONSTANT_3).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_104: Space = unite(&(v0_100),&(v0_103));
  let v0_107: Space = routine_3(c, &(*CONSTANT_4), &((*CONSTANT_5).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_108: Space = unite(&(v0_104),&(v0_107));
  let v0_111: Space = routine_3(c, &(*CONSTANT_6), &((*CONSTANT_7).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_112: Space = unite(&(v0_108),&(v0_111));
  let v0_115: Space = routine_3(c, &(*CONSTANT_8), &((*CONSTANT_9).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_116: Space = unite(&(v0_112),&(v0_115));
  let v0_119: Space = routine_3(c, &(*CONSTANT_10), &((*CONSTANT_11).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_120: Space = unite(&(v0_116),&(v0_119));
  let v0_123: Space = routine_3(c, &(*CONSTANT_12), &((*CONSTANT_13).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_124: Space = unite(&(v0_120),&(v0_123));
  let v0_127: Space = routine_3(c, &(*CONSTANT_14), &((*CONSTANT_15).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_128: Space = unite(&(v0_124),&(v0_127));
  let v0_131: Space = routine_3(c, &(*CONSTANT_16), &((*CONSTANT_17).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_132: Space = unite(&(v0_128),&(v0_131));
  let v0_135: Space = routine_3(c, &(*CONSTANT_18), &((*CONSTANT_19).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_136: Space = unite(&(v0_132),&(v0_135));
  let v0_139: Space = routine_3(c, &(*CONSTANT_20), &((*CONSTANT_21).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_140: Space = unite(&(v0_136),&(v0_139));
  let v0_143: Space = routine_3(c, &(*CONSTANT_22), &((*CONSTANT_23).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_144: Space = unite(&(v0_140),&(v0_143));
  let v0_147: Space = routine_3(c, &(*CONSTANT_24), &((*CONSTANT_25).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_148: Space = unite(&(v0_144),&(v0_147));
  let v0_151: Space = routine_3(c, &(*CONSTANT_26), &((*CONSTANT_27).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_152: Space = unite(&(v0_148),&(v0_151));
  let v0_155: Space = routine_3(c, &(*CONSTANT_28), &((*CONSTANT_29).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_156: Space = unite(&(v0_152),&(v0_155));
  let v0_159: Space = routine_3(c, &(*CONSTANT_30), &((*CONSTANT_31).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_160: Space = unite(&(v0_156),&(v0_159));
  let v0_163: Space = routine_3(c, &(*CONSTANT_32), &((*CONSTANT_33).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_164: Space = unite(&(v0_160),&(v0_163));
  let v0_167: Space = routine_3(c, &(*CONSTANT_34), &((*CONSTANT_35).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_168: Space = unite(&(v0_164),&(v0_167));
  let v0_171: Space = routine_3(c, &(*CONSTANT_36), &((*CONSTANT_37).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_172: Space = unite(&(v0_168),&(v0_171));
  let v0_175: Space = routine_3(c, &(*CONSTANT_38), &((*CONSTANT_39).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_176: Space = unite(&(v0_172),&(v0_175));
  let v0_179: Space = routine_3(c, &(*CONSTANT_40), &((*CONSTANT_41).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_180: Space = unite(&(v0_176),&(v0_179));
  let v0_183: Space = routine_3(c, &(*CONSTANT_42), &((*CONSTANT_43).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_184: Space = unite(&(v0_180),&(v0_183));
  let v0_187: Space = routine_3(c, &(*CONSTANT_44), &((*CONSTANT_45).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_188: Space = unite(&(v0_184),&(v0_187));
  let v0_191: Space = routine_3(c, &(*CONSTANT_46), &((*CONSTANT_47).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_192: Space = unite(&(v0_188),&(v0_191));
  let v0_194: Space = wrap(&(v0_192),&(*CONSTANT_49));
  (v0_194).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v5_2 = Space::new();
  let mut v5_2_write = v5_2.write_zipper();
  let mut v5_2_cursor = (*s0).read_zipper();
  let v5_2_origin = v5_2_cursor.path().len();
  for v5_2_byte in v5_2_cursor.child_mask().iter() {
    v5_2_cursor.descend_to_existing_byte(v5_2_byte);
    {
    for v6_2_byte in v5_2_cursor.child_mask().iter() {
      v5_2_cursor.descend_to_existing_byte(v6_2_byte);
      {
      for v7_3_byte in v5_2_cursor.child_mask().iter() {
        v5_2_cursor.descend_to_existing_byte(v7_3_byte);
        {
        for v8_3_byte in v5_2_cursor.child_mask().iter() {
          v5_2_cursor.descend_to_existing_byte(v8_3_byte);
          {
          let v9_3: Path = concat_path(&(*p0),&v5_2_cursor.path()[v5_2_origin..(v5_2_origin + 4)]);
          let v9_4: Space = routine_4(c, &(v9_3));
          drop(v9_3);
          join_wrapped_into(&mut v5_2_write,&((v9_4).read_zipper()),&[]);
          }
          v5_2_cursor.ascend(1);
        }
        }
        v5_2_cursor.ascend(1);
      }
      }
      v5_2_cursor.ascend(1);
    }
    }
    v5_2_cursor.ascend(1);
  }
  drop(v5_2_cursor);
  drop(v5_2_write);
  (v5_2).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v10_5 = Space::new();
  let mut v10_5_write = v10_5.write_zipper();
  let mut v10_5_cursor = (*s0).read_zipper();
  let v10_5_origin = v10_5_cursor.path().len();
  for v10_5_byte in v10_5_cursor.child_mask().iter() {
    v10_5_cursor.descend_to_existing_byte(v10_5_byte);
    {
    for v11_2_byte in v10_5_cursor.child_mask().iter() {
      v10_5_cursor.descend_to_existing_byte(v11_2_byte);
      {
      for v12_3_byte in v10_5_cursor.child_mask().iter() {
        v10_5_cursor.descend_to_existing_byte(v12_3_byte);
        {
        for v13_3_byte in v10_5_cursor.child_mask().iter() {
          v10_5_cursor.descend_to_existing_byte(v13_3_byte);
          {
          let v14_3: Path = concat_path(&(*p0),&v10_5_cursor.path()[v10_5_origin..(v10_5_origin + 4)]);
          let v14_4: Space = routine_4(c, &(v14_3));
          let v14_5: Space = intersect(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_49))),&(v14_4));
          let v14_6: Space = routine_5(c, &((v14_5).read_zipper()));
          let mut v14_7 = Space::new();
          let mut v14_7_write = v14_7.write_zipper();
          let mut v14_7_cursor = (v14_6).read_zipper();
          let v14_7_origin = v14_7_cursor.path().len();
          for v14_7_byte in v14_7_cursor.child_mask().iter() {
            v14_7_cursor.descend_to_existing_byte(v14_7_byte);
            {
            for v15_2_byte in v14_7_cursor.child_mask().iter() {
              v14_7_cursor.descend_to_existing_byte(v15_2_byte);
              {
              for v16_3_byte in v14_7_cursor.child_mask().iter() {
                v14_7_cursor.descend_to_existing_byte(v16_3_byte);
                {
                for v17_3_byte in v14_7_cursor.child_mask().iter() {
                  v14_7_cursor.descend_to_existing_byte(v17_3_byte);
                  {
                  let v18_3: Space = routine_6(c, &v14_7_cursor.path()[v14_7_origin..(v14_7_origin + 4)], &v14_7_cursor);
                  join_wrapped_into(&mut v14_7_write,&((v18_3).read_zipper()),&[]);
                  }
                  v14_7_cursor.ascend(1);
                }
                }
                v14_7_cursor.ascend(1);
              }
              }
              v14_7_cursor.ascend(1);
            }
            }
            v14_7_cursor.ascend(1);
          }
          drop(v14_7_cursor);
          drop(v14_7_write);
          let v14_8: Space = routine_7(c, &((v14_5).read_zipper()));
          let mut v14_9 = Space::new();
          let mut v14_9_write = v14_9.write_zipper();
          let mut v14_9_cursor = (v14_8).read_zipper();
          let v14_9_origin = v14_9_cursor.path().len();
          for v14_9_byte in v14_9_cursor.child_mask().iter() {
            v14_9_cursor.descend_to_existing_byte(v14_9_byte);
            {
            for v19_2_byte in v14_9_cursor.child_mask().iter() {
              v14_9_cursor.descend_to_existing_byte(v19_2_byte);
              {
              for v20_3_byte in v14_9_cursor.child_mask().iter() {
                v14_9_cursor.descend_to_existing_byte(v20_3_byte);
                {
                for v21_3_byte in v14_9_cursor.child_mask().iter() {
                  v14_9_cursor.descend_to_existing_byte(v21_3_byte);
                  {
                  let v22_3: Space = routine_8(c, &v14_9_cursor.path()[v14_9_origin..(v14_9_origin + 4)], &v14_9_cursor);
                  join_wrapped_into(&mut v14_9_write,&((v22_3).read_zipper()),&[]);
                  }
                  v14_9_cursor.ascend(1);
                }
                }
                v14_9_cursor.ascend(1);
              }
              }
              v14_9_cursor.ascend(1);
            }
            }
            v14_9_cursor.ascend(1);
          }
          drop(v14_9_cursor);
          drop(v14_9_write);
          let v14_10: Space = subtract(&(v14_7),&(v14_9));
          let v14_12: Space = if (&(v14_10)).is_empty() { Space::new() } else {
            let v23_11: Space = singleton(&(v14_3));
            compose(&(v14_10),&(v23_11))
          };
          let mut v14_13_cursor = (v14_12).read_zipper();
          let v14_13_origin = v14_13_cursor.path().len();
          for v14_13_byte in v14_13_cursor.child_mask().iter() {
            v14_13_cursor.descend_to_existing_byte(v14_13_byte);
            {
            for v24_2_byte in v14_13_cursor.child_mask().iter() {
              v14_13_cursor.descend_to_existing_byte(v24_2_byte);
              {
              for v25_3_byte in v14_13_cursor.child_mask().iter() {
                v14_13_cursor.descend_to_existing_byte(v25_3_byte);
                {
                for v26_3_byte in v14_13_cursor.child_mask().iter() {
                  v14_13_cursor.descend_to_existing_byte(v26_3_byte);
                  {
                  let v27_3: Space = routine_9(c, &v14_13_cursor.path()[v14_13_origin..(v14_13_origin + 4)], &v14_13_cursor);
                  join_wrapped_into(&mut v10_5_write,&((v27_3).read_zipper()),&[]);
                  }
                  v14_13_cursor.ascend(1);
                }
                }
                v14_13_cursor.ascend(1);
              }
              }
              v14_13_cursor.ascend(1);
            }
            }
            v14_13_cursor.ascend(1);
          }
          drop(v14_13_cursor);
          }
          v10_5_cursor.ascend(1);
        }
        }
        v10_5_cursor.ascend(1);
      }
      }
      v10_5_cursor.ascend(1);
    }
    }
    v10_5_cursor.ascend(1);
  }
  drop(v10_5_cursor);
  drop(v10_5_write);
  (v10_5).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v28_5 = Space::new();
  let mut v28_5_write = v28_5.write_zipper();
  let mut v28_5_cursor = (*s0).read_zipper();
  let v28_5_origin = v28_5_cursor.path().len();
  for v28_5_byte in v28_5_cursor.child_mask().iter() {
    v28_5_cursor.descend_to_existing_byte(v28_5_byte);
    {
    for v29_2_byte in v28_5_cursor.child_mask().iter() {
      v28_5_cursor.descend_to_existing_byte(v29_2_byte);
      {
      for v30_3_byte in v28_5_cursor.child_mask().iter() {
        v28_5_cursor.descend_to_existing_byte(v30_3_byte);
        {
        for v31_3_byte in v28_5_cursor.child_mask().iter() {
          v28_5_cursor.descend_to_existing_byte(v31_3_byte);
          {
          let v32_3: Path = concat_path(&(*p0),&v28_5_cursor.path()[v28_5_origin..(v28_5_origin + 4)]);
          let v32_4: Space = routine_4(c, &(v32_3));
          let v32_5: Space = intersect(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_49))),&(v32_4));
          let v32_6: Space = routine_10(c, &((v32_5).read_zipper()));
          let mut v32_7 = Space::new();
          let mut v32_7_write = v32_7.write_zipper();
          let mut v32_7_cursor = (v32_6).read_zipper();
          let v32_7_origin = v32_7_cursor.path().len();
          for v32_7_byte in v32_7_cursor.child_mask().iter() {
            v32_7_cursor.descend_to_existing_byte(v32_7_byte);
            {
            for v33_2_byte in v32_7_cursor.child_mask().iter() {
              v32_7_cursor.descend_to_existing_byte(v33_2_byte);
              {
              for v34_3_byte in v32_7_cursor.child_mask().iter() {
                v32_7_cursor.descend_to_existing_byte(v34_3_byte);
                {
                for v35_3_byte in v32_7_cursor.child_mask().iter() {
                  v32_7_cursor.descend_to_existing_byte(v35_3_byte);
                  {
                  let v36_3: Space = routine_11(c, &v32_7_cursor.path()[v32_7_origin..(v32_7_origin + 4)], &v32_7_cursor);
                  join_wrapped_into(&mut v32_7_write,&((v36_3).read_zipper()),&[]);
                  }
                  v32_7_cursor.ascend(1);
                }
                }
                v32_7_cursor.ascend(1);
              }
              }
              v32_7_cursor.ascend(1);
            }
            }
            v32_7_cursor.ascend(1);
          }
          drop(v32_7_cursor);
          drop(v32_7_write);
          let v32_8: Space = routine_5(c, &((v32_5).read_zipper()));
          let mut v32_9 = Space::new();
          let mut v32_9_write = v32_9.write_zipper();
          let mut v32_9_cursor = (v32_8).read_zipper();
          let v32_9_origin = v32_9_cursor.path().len();
          for v32_9_byte in v32_9_cursor.child_mask().iter() {
            v32_9_cursor.descend_to_existing_byte(v32_9_byte);
            {
            for v37_2_byte in v32_9_cursor.child_mask().iter() {
              v32_9_cursor.descend_to_existing_byte(v37_2_byte);
              {
              for v38_3_byte in v32_9_cursor.child_mask().iter() {
                v32_9_cursor.descend_to_existing_byte(v38_3_byte);
                {
                for v39_3_byte in v32_9_cursor.child_mask().iter() {
                  v32_9_cursor.descend_to_existing_byte(v39_3_byte);
                  {
                  let v40_3: Space = routine_12(c, &v32_9_cursor.path()[v32_9_origin..(v32_9_origin + 4)], &v32_9_cursor);
                  join_wrapped_into(&mut v32_9_write,&((v40_3).read_zipper()),&[]);
                  }
                  v32_9_cursor.ascend(1);
                }
                }
                v32_9_cursor.ascend(1);
              }
              }
              v32_9_cursor.ascend(1);
            }
            }
            v32_9_cursor.ascend(1);
          }
          drop(v32_9_cursor);
          drop(v32_9_write);
          let v32_10: Space = subtract(&(v32_7),&(v32_9));
          let v32_12: Space = if (&(v32_10)).is_empty() { Space::new() } else {
            let v41_11: Space = singleton(&(v32_3));
            compose(&(v32_10),&(v41_11))
          };
          let mut v32_13_cursor = (v32_12).read_zipper();
          let v32_13_origin = v32_13_cursor.path().len();
          for v32_13_byte in v32_13_cursor.child_mask().iter() {
            v32_13_cursor.descend_to_existing_byte(v32_13_byte);
            {
            for v42_2_byte in v32_13_cursor.child_mask().iter() {
              v32_13_cursor.descend_to_existing_byte(v42_2_byte);
              {
              for v43_3_byte in v32_13_cursor.child_mask().iter() {
                v32_13_cursor.descend_to_existing_byte(v43_3_byte);
                {
                for v44_3_byte in v32_13_cursor.child_mask().iter() {
                  v32_13_cursor.descend_to_existing_byte(v44_3_byte);
                  {
                  let v45_3: Space = routine_13(c, &v32_13_cursor.path()[v32_13_origin..(v32_13_origin + 4)], &v32_13_cursor);
                  join_wrapped_into(&mut v28_5_write,&((v45_3).read_zipper()),&[]);
                  }
                  v32_13_cursor.ascend(1);
                }
                }
                v32_13_cursor.ascend(1);
              }
              }
              v32_13_cursor.ascend(1);
            }
            }
            v32_13_cursor.ascend(1);
          }
          drop(v32_13_cursor);
          }
          v28_5_cursor.ascend(1);
        }
        }
        v28_5_cursor.ascend(1);
      }
      }
      v28_5_cursor.ascend(1);
    }
    }
    v28_5_cursor.ascend(1);
  }
  drop(v28_5_cursor);
  drop(v28_5_write);
  (v28_5).clone()
}

#[inline(always)]
fn routine_4(c: &mut Context, p0: &[u8]) -> Space {
  let v46_1: Space = singleton(&(*p0));
  let mut v46_2 = Space::new();
  let mut v46_2_write = v46_2.write_zipper();
  let mut v46_2_cursor = (v46_1).read_zipper();
  let v46_2_origin = v46_2_cursor.path().len();
  for v46_2_byte in v46_2_cursor.child_mask().iter() {
    v46_2_cursor.descend_to_existing_byte(v46_2_byte);
    {
    for v47_2_byte in v46_2_cursor.child_mask().iter() {
      v46_2_cursor.descend_to_existing_byte(v47_2_byte);
      {
      for v48_3_byte in v46_2_cursor.child_mask().iter() {
        v46_2_cursor.descend_to_existing_byte(v48_3_byte);
        {
        for v49_3_byte in v46_2_cursor.child_mask().iter() {
          v46_2_cursor.descend_to_existing_byte(v49_3_byte);
          {
          for v50_3_byte in v46_2_cursor.child_mask().iter() {
            v46_2_cursor.descend_to_existing_byte(v50_3_byte);
            {
            for v51_2_byte in v46_2_cursor.child_mask().iter() {
              v46_2_cursor.descend_to_existing_byte(v51_2_byte);
              {
              for v52_3_byte in v46_2_cursor.child_mask().iter() {
                v46_2_cursor.descend_to_existing_byte(v52_3_byte);
                {
                for v53_3_byte in v46_2_cursor.child_mask().iter() {
                  v46_2_cursor.descend_to_existing_byte(v53_3_byte);
                  {
                  let v54_3: Space = routine_14(c, &v46_2_cursor.path()[(v46_2_origin + 4)..(v46_2_origin + 8)], &v46_2_cursor.path()[v46_2_origin..(v46_2_origin + 4)], &v46_2_cursor);
                  join_wrapped_into(&mut v46_2_write,&((v54_3).read_zipper()),&[]);
                  }
                  v46_2_cursor.ascend(1);
                }
                }
                v46_2_cursor.ascend(1);
              }
              }
              v46_2_cursor.ascend(1);
            }
            }
            v46_2_cursor.ascend(1);
          }
          }
          v46_2_cursor.ascend(1);
        }
        }
        v46_2_cursor.ascend(1);
      }
      }
      v46_2_cursor.ascend(1);
    }
    }
    v46_2_cursor.ascend(1);
  }
  drop(v46_2_cursor);
  drop(v46_2_write);
  drop(v46_1);
  (v46_2).clone()
}

fn routine_5(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v55_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v55_2: Space = first_matching(&(*s0),&(*CONSTANT_50),false);
  let v55_3: Space = unite(&(v55_1),&(v55_2));
  drop(v55_1);
  drop(v55_2);
  let v55_8: Space = if (&(v55_3)).is_empty() { Space::new() } else {
    let v56_6: Space = if (&(v55_3)).is_empty() { Space::new() } else {
      let v57_4: Space = routine_15(c, &(*s0));
      let v57_5: Space = subtract(&(*s0),&(v57_4));
      compose(&(v55_3),&(v57_5))
    };
    let v56_7: Space = routine_16(c, &((v56_6).read_zipper()));
    compose(&(v55_3),&(v56_7))
  };
  drop(v55_3);
  let v58_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v58_2: Space = first_matching(&(*s0),&(*CONSTANT_50),false);
  let v58_3: Space = unite(&(v58_1),&(v58_2));
  drop(v58_1);
  drop(v58_2);
  let v58_6: Space = if (&(v58_3)).is_empty() { Space::new() } else {
    let v59_4: Space = routine_15(c, &(*s0));
    let v59_5: Space = subtract(&(*s0),&(v59_4));
    compose(&(v58_3),&(v59_5))
  };
  let v55_9: Space = if has_head(&(v58_6)) { singleton(&[]) } else { Space::new() };
  let v55_10: Space = first_matching(&(v58_6),&(*CONSTANT_50),false);
  let v55_11: Space = unite(&(v55_9),&(v55_10));
  let v55_13: Space = if (&(v55_11)).is_empty() { Space::new() } else {
    let v60_7: Space = routine_16(c, &((v58_6).read_zipper()));
    let v60_12: Space = routine_16(c, &((v60_7).read_zipper()));
    compose(&(v55_11),&(v60_12))
  };
  let v55_14: Space = subtract(&(*s0),&(v55_13));
  let v55_15: Space = intersect(&(v55_8),&(v55_14));
  (v55_15).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (*CONSTANT_51).clone()
}

fn routine_7(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v62_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v62_2: Space = first_matching(&(*s0),&(*CONSTANT_50),false);
  let v62_3: Space = unite(&(v62_1),&(v62_2));
  drop(v62_1);
  drop(v62_2);
  let v62_6: Space = if (&(v62_3)).is_empty() { Space::new() } else {
    let v63_4: Space = routine_15(c, &(*s0));
    let v63_5: Space = subtract(&(*s0),&(v63_4));
    compose(&(v62_3),&(v63_5))
  };
  let v62_7: Space = if has_head(&(v62_6)) { singleton(&[]) } else { Space::new() };
  let v62_8: Space = first_matching(&(v62_6),&(*CONSTANT_50),false);
  let v62_9: Space = unite(&(v62_7),&(v62_8));
  let v62_12: Space = if (&(v62_9)).is_empty() { Space::new() } else {
    let v64_10: Space = routine_16(c, &((v62_6).read_zipper()));
    let v64_11: Space = routine_16(c, &((v64_10).read_zipper()));
    compose(&(v62_9),&(v64_11))
  };
  let v62_17: Space = if (&(v62_3)).is_empty() { Space::new() } else {
    let v65_15: Space = if (&(v62_3)).is_empty() { Space::new() } else {
      let v66_13: Space = routine_16(c, &(*s0));
      let v66_14: Space = routine_16(c, &((v66_13).read_zipper()));
      compose(&(v62_3),&(v66_14))
    };
    let v65_16: Space = routine_17(c, &((v65_15).read_zipper()));
    compose(&(v62_3),&(v65_16))
  };
  drop(v62_3);
  let v62_18: Space = subtract(&(*s0),&(v62_17));
  let v62_19: Space = intersect(&(v62_12),&(v62_18));
  (v62_19).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (*CONSTANT_51).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_10(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v69_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v69_2: Space = first_matching(&(*s0),&(*CONSTANT_50),false);
  let v69_3: Space = unite(&(v69_1),&(v69_2));
  drop(v69_1);
  drop(v69_2);
  let v69_8: Space = if (&(v69_3)).is_empty() { Space::new() } else {
    let v70_6: Space = if (&(v69_3)).is_empty() { Space::new() } else {
      let v71_4: Space = routine_15(c, &(*s0));
      let v71_5: Space = subtract(&(*s0),&(v71_4));
      compose(&(v69_3),&(v71_5))
    };
    let v70_7: Space = routine_16(c, &((v70_6).read_zipper()));
    compose(&(v69_3),&(v70_7))
  };
  drop(v69_3);
  let v69_9: Space = subtract(&(*s0),&(v69_8));
  let v72_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v72_2: Space = first_matching(&(*s0),&(*CONSTANT_50),false);
  let v72_3: Space = unite(&(v72_1),&(v72_2));
  drop(v72_1);
  drop(v72_2);
  let v72_6: Space = if (&(v72_3)).is_empty() { Space::new() } else {
    let v73_4: Space = routine_15(c, &(*s0));
    let v73_5: Space = subtract(&(*s0),&(v73_4));
    compose(&(v72_3),&(v73_5))
  };
  let v69_10: Space = intersect(&(v72_6),&(v69_9));
  (v69_10).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (*CONSTANT_51).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (*CONSTANT_51).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_14(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v77_7: Space = if (&(descend_cursor((*CONSTANT_52).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_52).read_zipper(),&(*p1))),&(descend_cursor((*CONSTANT_52).read_zipper(),&(*p0))))
  };
  let v77_8: Path = concat_path(&(*p1),&(*p0));
  let v77_9: Space = singleton(&(v77_8));
  drop(v77_8);
  let v77_10: Space = subtract(&(v77_7),&(v77_9));
  drop(v77_7);
  drop(v77_9);
  (v77_10).clone()
}

fn routine_15(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v79_2: Space = first_matching(&(*s0),&(*CONSTANT_50),false);
  let v79_3: Space = intersect(&(*CONSTANT_50),&(v79_2));
  let v79_4: Space = if has_head(&(v79_2)) { singleton(&[]) } else { Space::new() };
  let v79_5: Space = unite(&(v79_3),&(v79_4));
  drop(v79_3);
  let v79_7: Space = compose(&(v79_5),&(*CONSTANT_50));
  drop(v79_5);
  let v79_9: Space = subtract(&(*CONSTANT_50),&(v79_2));
  drop(v79_2);
  let v79_10: Space = subtract(&(v79_9),&(v79_4));
  drop(v79_4);
  drop(v79_9);
  let v79_18: Space = if (&(v79_10)).is_empty() { Space::new() } else {
    let v80_11: Space = first_listed(&(*s0),&(*CONSTANT_54),true);
    let v80_12: Space = first_matching(&(v80_11),&(*CONSTANT_50),false);
    let v80_15: Space = if (&(v80_12)).is_empty() { Space::new() } else {
      let v81_14: Space = routine_18(c, &(*CONSTANT_53), &(*s0));
      compose(&(v80_12),&(v81_14))
    };
    drop(v80_12);
    let mut v80_16 = Space::new();
    let mut v80_16_write = v80_16.write_zipper();
    let mut v80_16_cursor = (v80_11).read_zipper();
    let v80_16_origin = v80_16_cursor.path().len();
    for v80_16_byte in v80_16_cursor.child_mask().iter() {
      v80_16_cursor.descend_to_existing_byte(v80_16_byte);
      {
      let v82_2_arg_0: &[u8] = &v80_16_cursor.path()[v80_16_origin..(v80_16_origin + 1)];
      let v82_2_arg_2: &Space = &(&(*s0)).make_map();
      let mut v82_2_more = v80_16_cursor.is_val() || next_value_within(&mut v80_16_cursor,(v80_16_origin + 1));
      while v82_2_more {
        {
        let v82_2_depth = v80_16_cursor.path().len();
        let v83_4: Space = routine_15(c, &(descend_cursor((*v82_2_arg_2).read_zipper(),&v80_16_cursor.path()[v80_16_origin..v82_2_depth])));
        join_wrapped_into(&mut v80_16_write,&((v83_4).read_zipper()),&v80_16_cursor.path()[v80_16_origin..v82_2_depth]);
        }
        v82_2_more = next_value_within(&mut v80_16_cursor,(v80_16_origin + 1));
      }
      }
      v80_16_cursor.ascend(1);
    }
    drop(v80_16_cursor);
    drop(v80_16_write);
    drop(v80_11);
    let v80_17: Space = unite(&(v80_15),&(v80_16));
    compose(&(v79_10),&(v80_17))
  };
  drop(v79_10);
  let v79_19: Space = unite(&(v79_7),&(v79_18));
  drop(v79_7);
  (v79_19).clone()
}

fn routine_16(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v84_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v84_2: Space = first_matching(&(*s0),&(*CONSTANT_50),false);
  let v84_3: Space = unite(&(v84_1),&(v84_2));
  drop(v84_1);
  let v84_19: Space = if (&(v84_3)).is_empty() { Space::new() } else {
    let v85_5: Space = intersect(&(*CONSTANT_50),&(v84_2));
    let v85_6: Space = if has_head(&(v84_2)) { singleton(&[]) } else { Space::new() };
    let v85_7: Space = unite(&(v85_5),&(v85_6));
    drop(v85_5);
    let v85_9: Space = compose(&(v85_7),&(*CONSTANT_50));
    drop(v85_7);
    let v85_10: Space = subtract(&(*s0),&(v85_9));
    drop(v85_9);
    let v85_12: Space = subtract(&(*CONSTANT_50),&(v84_2));
    let v85_13: Space = subtract(&(v85_12),&(v85_6));
    drop(v85_6);
    drop(v85_12);
    let v85_17: Space = if (&(v85_13)).is_empty() { Space::new() } else {
      let v86_15: Space = first_listed(&(*s0),&(*CONSTANT_54),true);
      let mut v86_16 = Space::new();
      let mut v86_16_write = v86_16.write_zipper();
      let v86_16_arg_0: &[u8] = &(*CONSTANT_53);
      let v86_16_arg_2: &Space = &(&(*s0)).make_map();
      let mut v86_16_cursor = (v86_15).read_zipper();
      let v86_16_origin = v86_16_cursor.path().len();
      let mut v86_16_more = v86_16_cursor.is_val() || next_value_within(&mut v86_16_cursor,v86_16_origin);
      while v86_16_more {
        {
        let v86_16_depth = v86_16_cursor.path().len();
        let v87_4: Space = routine_15(c, &(descend_cursor((*v86_16_arg_2).read_zipper(),&v86_16_cursor.path()[v86_16_origin..v86_16_depth])));
        join_wrapped_into(&mut v86_16_write,&((v87_4).read_zipper()),&v86_16_cursor.path()[v86_16_origin..v86_16_depth]);
        }
        v86_16_more = next_value_within(&mut v86_16_cursor,v86_16_origin);
      }
      drop(v86_16_cursor);
      drop(v86_16_write);
      drop(v86_15);
      compose(&(v85_13),&(v86_16))
    };
    drop(v85_13);
    let v85_18: Space = subtract(&(v85_10),&(v85_17));
    drop(v85_10);
    compose(&(v84_3),&(v85_18))
  };
  drop(v84_3);
  (v84_19).clone()
}

fn routine_17(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v88_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v88_2: Space = first_matching(&(*s0),&(*CONSTANT_50),false);
  let v88_3: Space = unite(&(v88_1),&(v88_2));
  drop(v88_1);
  drop(v88_2);
  let v88_13: Space = if (&(v88_3)).is_empty() { Space::new() } else {
    let v89_6: Space = if (&(v88_3)).is_empty() { Space::new() } else {
      let v90_4: Space = routine_15(c, &(*s0));
      let v90_5: Space = subtract(&(*s0),&(v90_4));
      compose(&(v88_3),&(v90_5))
    };
    let v89_7: Space = if has_head(&(v89_6)) { singleton(&[]) } else { Space::new() };
    let v89_8: Space = first_matching(&(v89_6),&(*CONSTANT_50),false);
    let v89_9: Space = unite(&(v89_7),&(v89_8));
    let v89_12: Space = if (&(v89_9)).is_empty() { Space::new() } else {
      let v91_10: Space = routine_15(c, &((v89_6).read_zipper()));
      let v91_11: Space = subtract(&(v89_6),&(v91_10));
      compose(&(v89_9),&(v91_11))
    };
    compose(&(v88_3),&(v89_12))
  };
  drop(v88_3);
  (v88_13).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v92_4: Space = first_matching(&(descend_cursor((*s0).read_zipper(),&(*p0))),&(*CONSTANT_50),false);
  let v92_5: Space = intersect(&(*CONSTANT_50),&(v92_4));
  let v92_6: Space = if has_head(&(v92_4)) { singleton(&[]) } else { Space::new() };
  let v92_7: Space = unite(&(v92_5),&(v92_6));
  drop(v92_5);
  let v92_9: Space = compose(&(v92_7),&(*CONSTANT_50));
  drop(v92_7);
  let v92_11: Space = subtract(&(*CONSTANT_50),&(v92_4));
  drop(v92_4);
  let v92_12: Space = subtract(&(v92_11),&(v92_6));
  drop(v92_6);
  drop(v92_11);
  let v92_16: Space = if (&(v92_12)).is_empty() { Space::new() } else {
    let v93_14: Space = first_listed(&(descend_cursor((*s0).read_zipper(),&(*p0))),&(*CONSTANT_54),true);
    let mut v93_15 = Space::new();
    let mut v93_15_write = v93_15.write_zipper();
    let v93_15_arg_0: &[u8] = &(*CONSTANT_53);
    let v93_15_arg_2: &Space = &(&(descend_cursor((*s0).read_zipper(),&(*p0)))).make_map();
    let mut v93_15_cursor = (v93_14).read_zipper();
    let v93_15_origin = v93_15_cursor.path().len();
    let mut v93_15_more = v93_15_cursor.is_val() || next_value_within(&mut v93_15_cursor,v93_15_origin);
    while v93_15_more {
      {
      let v93_15_depth = v93_15_cursor.path().len();
      let v94_3: Space = routine_18(c, &v93_15_cursor.path()[v93_15_origin..v93_15_depth], &((*v93_15_arg_2).read_zipper()));
      join_wrapped_into(&mut v93_15_write,&((v94_3).read_zipper()),&[]);
      }
      v93_15_more = next_value_within(&mut v93_15_cursor,v93_15_origin);
    }
    drop(v93_15_cursor);
    drop(v93_15_write);
    drop(v93_14);
    compose(&(v92_12),&(v93_15))
  };
  drop(v92_12);
  let v92_17: Space = unite(&(v92_9),&(v92_16));
  drop(v92_9);
  let v92_18: Space = wrap(&(v92_17),&(*p0));
  (v92_18).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
