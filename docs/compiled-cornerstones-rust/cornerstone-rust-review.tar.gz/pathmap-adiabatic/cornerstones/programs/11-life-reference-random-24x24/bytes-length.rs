#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("52 4 48 2 49 48 4 48 2 49 49 4 49 2 49 51 4 49 2 49 52 4 49 2 50 48 4 50 2 49 48 4 50 2 49 51 4 50 2 50 49 3 51 1 49 3 51 1 50 3 51 1 53 3 51 1 55 4 51 2 50 49 3 52 1 56 4 52 2 49 49 4 52 2 49 53 4 52 2 49 54 4 52 2 49 57 4 52 2 50 48 4 52 2 50 51 3 53 1 55 4 53 2 49 48 4 53 2 49 50 4 53 2 49 56 4 53 2 49 57 3 54 1 49 3 54 1 50 3 54 1 52 3 54 1 54 4 54 2 49 52 4 54 2 50 48 3 55 1 49 3 55 1 52 3 55 1 53 4 55 2 49 48 4 55 2 49 52 4 55 2 49 57 4 55 2 50 48 3 56 1 53 3 56 1 54 3 56 1 57 4 56 2 49 49 4 56 2 49 57 4 56 2 50 49 3 57 1 51 3 57 1 52 3 57 1 53 3 57 1 55 4 57 2 49 50 4 57 2 49 55 4 57 2 49 57 4 57 2 50 51"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[2]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("68 4 49 48 1 54 4 49 48 1 57 5 49 48 2 49 50 5 49 48 2 49 56 5 49 48 2 50 51 4 49 49 1 51 4 49 49 1 53 5 49 49 2 49 49 5 49 49 2 49 50 5 49 49 2 50 51 4 49 50 1 50 5 49 50 2 49 54 5 49 50 2 49 57 4 49 51 1 57 5 49 51 2 49 52 5 49 51 2 50 48 5 49 51 2 50 49 4 49 52 1 48 4 49 52 1 54 4 49 52 1 56 4 49 52 1 57 5 49 52 2 49 56 4 49 53 1 49 4 49 53 1 51 4 49 53 1 53 4 49 53 1 54 5 49 53 2 49 54 5 49 53 2 49 55 5 49 53 2 49 57 5 49 53 2 50 48 4 49 54 1 48 4 49 55 1 50 4 49 55 1 51 4 49 55 1 52 4 49 55 1 54 4 49 55 1 55 4 49 55 1 57 5 49 55 2 49 50 5 49 55 2 49 54 5 49 55 2 49 56 4 49 56 1 53 5 49 56 2 49 48 5 49 56 2 49 50 5 49 56 2 49 51 5 49 56 2 49 53 5 49 56 2 49 55 5 49 56 2 50 50 4 49 57 1 51 5 49 57 2 49 56 5 49 57 2 50 49 4 50 48 1 50 4 50 48 1 53 4 50 48 1 55 4 50 48 1 57 5 50 48 2 49 53 4 50 49 1 52 4 50 49 1 56 4 50 49 1 57 5 50 49 2 49 51 5 50 49 2 49 53 4 50 50 1 50 5 50 50 2 49 54 5 50 50 2 50 50 4 50 51 1 49 4 50 51 1 50 4 50 51 1 53 4 50 51 1 55 4 50 51 1 57"));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("120 10 4 67 101 108 108 1 48 2 49 48 10 4 67 101 108 108 1 48 2 49 49 10 4 67 101 108 108 1 49 2 49 51 10 4 67 101 108 108 1 49 2 49 52 10 4 67 101 108 108 1 49 2 50 48 10 4 67 101 108 108 1 50 2 49 48 10 4 67 101 108 108 1 50 2 49 51 10 4 67 101 108 108 1 50 2 50 49 9 4 67 101 108 108 1 51 1 49 9 4 67 101 108 108 1 51 1 50 9 4 67 101 108 108 1 51 1 53 9 4 67 101 108 108 1 51 1 55 10 4 67 101 108 108 1 51 2 50 49 9 4 67 101 108 108 1 52 1 56 10 4 67 101 108 108 1 52 2 49 49 10 4 67 101 108 108 1 52 2 49 53 10 4 67 101 108 108 1 52 2 49 54 10 4 67 101 108 108 1 52 2 49 57 10 4 67 101 108 108 1 52 2 50 48 10 4 67 101 108 108 1 52 2 50 51 9 4 67 101 108 108 1 53 1 55 10 4 67 101 108 108 1 53 2 49 48 10 4 67 101 108 108 1 53 2 49 50 10 4 67 101 108 108 1 53 2 49 56 10 4 67 101 108 108 1 53 2 49 57 9 4 67 101 108 108 1 54 1 49 9 4 67 101 108 108 1 54 1 50 9 4 67 101 108 108 1 54 1 52 9 4 67 101 108 108 1 54 1 54 10 4 67 101 108 108 1 54 2 49 52 10 4 67 101 108 108 1 54 2 50 48 9 4 67 101 108 108 1 55 1 49 9 4 67 101 108 108 1 55 1 52 9 4 67 101 108 108 1 55 1 53 10 4 67 101 108 108 1 55 2 49 48 10 4 67 101 108 108 1 55 2 49 52 10 4 67 101 108 108 1 55 2 49 57 10 4 67 101 108 108 1 55 2 50 48 9 4 67 101 108 108 1 56 1 53 9 4 67 101 108 108 1 56 1 54 9 4 67 101 108 108 1 56 1 57 10 4 67 101 108 108 1 56 2 49 49 10 4 67 101 108 108 1 56 2 49 57 10 4 67 101 108 108 1 56 2 50 49 9 4 67 101 108 108 1 57 1 51 9 4 67 101 108 108 1 57 1 52 9 4 67 101 108 108 1 57 1 53 9 4 67 101 108 108 1 57 1 55 10 4 67 101 108 108 1 57 2 49 50 10 4 67 101 108 108 1 57 2 49 55 10 4 67 101 108 108 1 57 2 49 57 10 4 67 101 108 108 1 57 2 50 51 10 4 67 101 108 108 2 49 48 1 54 10 4 67 101 108 108 2 49 48 1 57 11 4 67 101 108 108 2 49 48 2 49 50 11 4 67 101 108 108 2 49 48 2 49 56 11 4 67 101 108 108 2 49 48 2 50 51 10 4 67 101 108 108 2 49 49 1 51 10 4 67 101 108 108 2 49 49 1 53 11 4 67 101 108 108 2 49 49 2 49 49 11 4 67 101 108 108 2 49 49 2 49 50 11 4 67 101 108 108 2 49 49 2 50 51 10 4 67 101 108 108 2 49 50 1 50 11 4 67 101 108 108 2 49 50 2 49 54 11 4 67 101 108 108 2 49 50 2 49 57 10 4 67 101 108 108 2 49 51 1 57 11 4 67 101 108 108 2 49 51 2 49 52 11 4 67 101 108 108 2 49 51 2 50 48 11 4 67 101 108 108 2 49 51 2 50 49 10 4 67 101 108 108 2 49 52 1 48 10 4 67 101 108 108 2 49 52 1 54 10 4 67 101 108 108 2 49 52 1 56 10 4 67 101 108 108 2 49 52 1 57 11 4 67 101 108 108 2 49 52 2 49 56 10 4 67 101 108 108 2 49 53 1 49 10 4 67 101 108 108 2 49 53 1 51 10 4 67 101 108 108 2 49 53 1 53 10 4 67 101 108 108 2 49 53 1 54 11 4 67 101 108 108 2 49 53 2 49 54 11 4 67 101 108 108 2 49 53 2 49 55 11 4 67 101 108 108 2 49 53 2 49 57 11 4 67 101 108 108 2 49 53 2 50 48 10 4 67 101 108 108 2 49 54 1 48 10 4 67 101 108 108 2 49 55 1 50 10 4 67 101 108 108 2 49 55 1 51 10 4 67 101 108 108 2 49 55 1 52 10 4 67 101 108 108 2 49 55 1 54 10 4 67 101 108 108 2 49 55 1 55 10 4 67 101 108 108 2 49 55 1 57 11 4 67 101 108 108 2 49 55 2 49 50 11 4 67 101 108 108 2 49 55 2 49 54 11 4 67 101 108 108 2 49 55 2 49 56 10 4 67 101 108 108 2 49 56 1 53 11 4 67 101 108 108 2 49 56 2 49 48 11 4 67 101 108 108 2 49 56 2 49 50 11 4 67 101 108 108 2 49 56 2 49 51 11 4 67 101 108 108 2 49 56 2 49 53 11 4 67 101 108 108 2 49 56 2 49 55 11 4 67 101 108 108 2 49 56 2 50 50 10 4 67 101 108 108 2 49 57 1 51 11 4 67 101 108 108 2 49 57 2 49 56 11 4 67 101 108 108 2 49 57 2 50 49 10 4 67 101 108 108 2 50 48 1 50 10 4 67 101 108 108 2 50 48 1 53 10 4 67 101 108 108 2 50 48 1 55 10 4 67 101 108 108 2 50 48 1 57 11 4 67 101 108 108 2 50 48 2 49 53 10 4 67 101 108 108 2 50 49 1 52 10 4 67 101 108 108 2 50 49 1 56 10 4 67 101 108 108 2 50 49 1 57 11 4 67 101 108 108 2 50 49 2 49 51 11 4 67 101 108 108 2 50 49 2 49 53 10 4 67 101 108 108 2 50 50 1 50 11 4 67 101 108 108 2 50 50 2 49 54 11 4 67 101 108 108 2 50 50 2 50 50 10 4 67 101 108 108 2 50 51 1 49 10 4 67 101 108 108 2 50 51 1 50 10 4 67 101 108 108 2 50 51 1 53 10 4 67 101 108 108 2 50 51 1 55 10 4 67 101 108 108 2 50 51 1 57"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4,67,101,108,108]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_7: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("255 2 1 0 2 2 1 2 3 2 2 4 3 2 5 4 2 6 5 2 7 6 2 8 7 2 9 8 2 10 9 2 11 10 2 12 11 2 13 12 2 14 13 2 15 14 2 16 15 2 17 16 2 18 17 2 19 18 2 20 19 2 21 20 2 22 21 2 23 22 2 24 23 2 25 24 2 26 25 2 27 26 2 28 27 2 29 28 2 30 29 2 31 30 2 32 31 2 33 32 2 34 33 2 35 34 2 36 35 2 37 36 2 38 37 2 39 38 2 40 39 2 41 40 2 42 41 2 43 42 2 44 43 2 45 44 2 46 45 2 47 46 2 48 47 2 49 48 2 50 49 2 51 50 2 52 51 2 53 52 2 54 53 2 55 54 2 56 55 2 57 56 2 58 57 2 59 58 2 60 59 2 61 60 2 62 61 2 63 62 2 64 63 2 65 64 2 66 65 2 67 66 2 68 67 2 69 68 2 70 69 2 71 70 2 72 71 2 73 72 2 74 73 2 75 74 2 76 75 2 77 76 2 78 77 2 79 78 2 80 79 2 81 80 2 82 81 2 83 82 2 84 83 2 85 84 2 86 85 2 87 86 2 88 87 2 89 88 2 90 89 2 91 90 2 92 91 2 93 92 2 94 93 2 95 94 2 96 95 2 97 96 2 98 97 2 99 98 2 100 99 2 101 100 2 102 101 2 103 102 2 104 103 2 105 104 2 106 105 2 107 106 2 108 107 2 109 108 2 110 109 2 111 110 2 112 111 2 113 112 2 114 113 2 115 114 2 116 115 2 117 116 2 118 117 2 119 118 2 120 119 2 121 120 2 122 121 2 123 122 2 124 123 2 125 124 2 126 125 2 127 126 2 128 127 2 129 128 2 130 129 2 131 130 2 132 131 2 133 132 2 134 133 2 135 134 2 136 135 2 137 136 2 138 137 2 139 138 2 140 139 2 141 140 2 142 141 2 143 142 2 144 143 2 145 144 2 146 145 2 147 146 2 148 147 2 149 148 2 150 149 2 151 150 2 152 151 2 153 152 2 154 153 2 155 154 2 156 155 2 157 156 2 158 157 2 159 158 2 160 159 2 161 160 2 162 161 2 163 162 2 164 163 2 165 164 2 166 165 2 167 166 2 168 167 2 169 168 2 170 169 2 171 170 2 172 171 2 173 172 2 174 173 2 175 174 2 176 175 2 177 176 2 178 177 2 179 178 2 180 179 2 181 180 2 182 181 2 183 182 2 184 183 2 185 184 2 186 185 2 187 186 2 188 187 2 189 188 2 190 189 2 191 190 2 192 191 2 193 192 2 194 193 2 195 194 2 196 195 2 197 196 2 198 197 2 199 198 2 200 199 2 201 200 2 202 201 2 203 202 2 204 203 2 205 204 2 206 205 2 207 206 2 208 207 2 209 208 2 210 209 2 211 210 2 212 211 2 213 212 2 214 213 2 215 214 2 216 215 2 217 216 2 218 217 2 219 218 2 220 219 2 221 220 2 222 221 2 223 222 2 224 223 2 225 224 2 226 225 2 227 226 2 228 227 2 229 228 2 230 229 2 231 230 2 232 231 2 233 232 2 234 233 2 235 234 2 236 235 2 237 236 2 238 237 2 239 238 2 240 239 2 241 240 2 242 241 2 243 242 2 244 243 2 245 244 2 246 245 2 247 246 2 248 247 2 249 248 2 250 249 2 251 250 2 252 251 2 253 252 2 254 253 2 255 254"));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 3 104 105 116"));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("387 4 1 48 1 48 4 1 48 1 49 5 1 48 2 45 49 4 1 49 1 48 4 1 49 1 49 4 1 49 1 50 4 1 50 1 49 4 1 50 1 50 4 1 50 1 51 4 1 51 1 50 4 1 51 1 51 4 1 51 1 52 4 1 52 1 51 4 1 52 1 52 4 1 52 1 53 4 1 53 1 52 4 1 53 1 53 4 1 53 1 54 4 1 54 1 53 4 1 54 1 54 4 1 54 1 55 4 1 55 1 54 4 1 55 1 55 4 1 55 1 56 4 1 56 1 55 4 1 56 1 56 4 1 56 1 57 4 1 57 1 56 4 1 57 1 57 5 1 57 2 49 48 5 2 45 49 1 48 6 2 45 49 2 45 49 6 2 45 49 2 45 50 6 2 45 50 2 45 49 6 2 45 50 2 45 50 6 2 45 50 2 45 51 6 2 45 51 2 45 50 6 2 45 51 2 45 51 6 2 45 51 2 45 52 6 2 45 52 2 45 51 6 2 45 52 2 45 52 6 2 45 52 2 45 53 6 2 45 53 2 45 52 6 2 45 53 2 45 53 6 2 45 53 2 45 54 6 2 45 54 2 45 53 6 2 45 54 2 45 54 6 2 45 54 2 45 55 6 2 45 55 2 45 54 6 2 45 55 2 45 55 6 2 45 55 2 45 56 6 2 45 56 2 45 55 6 2 45 56 2 45 56 6 2 45 56 2 45 57 6 2 45 57 2 45 56 6 2 45 57 2 45 57 7 2 45 57 3 45 49 48 5 2 49 48 1 57 6 2 49 48 2 49 48 6 2 49 48 2 49 49 6 2 49 49 2 49 48 6 2 49 49 2 49 49 6 2 49 49 2 49 50 6 2 49 50 2 49 49 6 2 49 50 2 49 50 6 2 49 50 2 49 51 6 2 49 51 2 49 50 6 2 49 51 2 49 51 6 2 49 51 2 49 52 6 2 49 52 2 49 51 6 2 49 52 2 49 52 6 2 49 52 2 49 53 6 2 49 53 2 49 52 6 2 49 53 2 49 53 6 2 49 53 2 49 54 6 2 49 54 2 49 53 6 2 49 54 2 49 54 6 2 49 54 2 49 55 6 2 49 55 2 49 54 6 2 49 55 2 49 55 6 2 49 55 2 49 56 6 2 49 56 2 49 55 6 2 49 56 2 49 56 6 2 49 56 2 49 57 6 2 49 57 2 49 56 6 2 49 57 2 49 57 6 2 49 57 2 50 48 6 2 50 48 2 49 57 6 2 50 48 2 50 48 6 2 50 48 2 50 49 6 2 50 49 2 50 48 6 2 50 49 2 50 49 6 2 50 49 2 50 50 6 2 50 50 2 50 49 6 2 50 50 2 50 50 6 2 50 50 2 50 51 6 2 50 51 2 50 50 6 2 50 51 2 50 51 6 2 50 51 2 50 52 6 2 50 52 2 50 51 6 2 50 52 2 50 52 6 2 50 52 2 50 53 6 2 50 53 2 50 52 6 2 50 53 2 50 53 6 2 50 53 2 50 54 6 2 50 54 2 50 53 6 2 50 54 2 50 54 6 2 50 54 2 50 55 6 2 50 55 2 50 54 6 2 50 55 2 50 55 6 2 50 55 2 50 56 6 2 50 56 2 50 55 6 2 50 56 2 50 56 6 2 50 56 2 50 57 6 2 50 57 2 50 56 6 2 50 57 2 50 57 6 2 50 57 2 51 48 6 2 51 48 2 50 57 6 2 51 48 2 51 48 6 2 51 48 2 51 49 6 2 51 49 2 51 48 6 2 51 49 2 51 49 6 2 51 49 2 51 50 6 2 51 50 2 51 49 6 2 51 50 2 51 50 6 2 51 50 2 51 51 6 2 51 51 2 51 50 6 2 51 51 2 51 51 6 2 51 51 2 51 52 6 2 51 52 2 51 51 6 2 51 52 2 51 52 6 2 51 52 2 51 53 6 2 51 53 2 51 52 6 2 51 53 2 51 53 6 2 51 53 2 51 54 6 2 51 54 2 51 53 6 2 51 54 2 51 54 6 2 51 54 2 51 55 6 2 51 55 2 51 54 6 2 51 55 2 51 55 6 2 51 55 2 51 56 6 2 51 56 2 51 55 6 2 51 56 2 51 56 6 2 51 56 2 51 57 6 2 51 57 2 51 56 6 2 51 57 2 51 57 6 2 51 57 2 52 48 6 2 52 48 2 51 57 6 2 52 48 2 52 48 6 2 52 48 2 52 49 6 2 52 49 2 52 48 6 2 52 49 2 52 49 6 2 52 49 2 52 50 6 2 52 50 2 52 49 6 2 52 50 2 52 50 6 2 52 50 2 52 51 6 2 52 51 2 52 50 6 2 52 51 2 52 51 6 2 52 51 2 52 52 6 2 52 52 2 52 51 6 2 52 52 2 52 52 6 2 52 52 2 52 53 6 2 52 53 2 52 52 6 2 52 53 2 52 53 6 2 52 53 2 52 54 6 2 52 54 2 52 53 6 2 52 54 2 52 54 6 2 52 54 2 52 55 6 2 52 55 2 52 54 6 2 52 55 2 52 55 6 2 52 55 2 52 56 6 2 52 56 2 52 55 6 2 52 56 2 52 56 6 2 52 56 2 52 57 6 2 52 57 2 52 56 6 2 52 57 2 52 57 6 2 52 57 2 53 48 6 2 53 48 2 52 57 6 2 53 48 2 53 48 6 2 53 48 2 53 49 6 2 53 49 2 53 48 6 2 53 49 2 53 49 6 2 53 49 2 53 50 6 2 53 50 2 53 49 6 2 53 50 2 53 50 6 2 53 50 2 53 51 6 2 53 51 2 53 50 6 2 53 51 2 53 51 6 2 53 51 2 53 52 6 2 53 52 2 53 51 6 2 53 52 2 53 52 6 2 53 52 2 53 53 6 2 53 53 2 53 52 6 2 53 53 2 53 53 6 2 53 53 2 53 54 6 2 53 54 2 53 53 6 2 53 54 2 53 54 6 2 53 54 2 53 55 6 2 53 55 2 53 54 6 2 53 55 2 53 55 6 2 53 55 2 53 56 6 2 53 56 2 53 55 6 2 53 56 2 53 56 6 2 53 56 2 53 57 6 2 53 57 2 53 56 6 2 53 57 2 53 57 6 2 53 57 2 54 48 6 2 54 48 2 53 57 6 2 54 48 2 54 48 6 2 54 48 2 54 49 6 2 54 49 2 54 48 6 2 54 49 2 54 49 6 2 54 49 2 54 50 6 2 54 50 2 54 49 6 2 54 50 2 54 50 6 2 54 50 2 54 51 6 2 54 51 2 54 50 6 2 54 51 2 54 51 6 2 54 51 2 54 52 6 2 54 52 2 54 51 6 2 54 52 2 54 52 6 2 54 52 2 54 53 7 3 45 49 48 2 45 57 8 3 45 49 48 3 45 49 48 8 3 45 49 48 3 45 49 49 8 3 45 49 49 3 45 49 48 8 3 45 49 49 3 45 49 49 8 3 45 49 49 3 45 49 50 8 3 45 49 50 3 45 49 49 8 3 45 49 50 3 45 49 50 8 3 45 49 50 3 45 49 51 8 3 45 49 51 3 45 49 50 8 3 45 49 51 3 45 49 51 8 3 45 49 51 3 45 49 52 8 3 45 49 52 3 45 49 51 8 3 45 49 52 3 45 49 52 8 3 45 49 52 3 45 49 53 8 3 45 49 53 3 45 49 52 8 3 45 49 53 3 45 49 53 8 3 45 49 53 3 45 49 54 8 3 45 49 54 3 45 49 53 8 3 45 49 54 3 45 49 54 8 3 45 49 54 3 45 49 55 8 3 45 49 55 3 45 49 54 8 3 45 49 55 3 45 49 55 8 3 45 49 55 3 45 49 56 8 3 45 49 56 3 45 49 55 8 3 45 49 56 3 45 49 56 8 3 45 49 56 3 45 49 57 8 3 45 49 57 3 45 49 56 8 3 45 49 57 3 45 49 57 8 3 45 49 57 3 45 50 48 8 3 45 50 48 3 45 49 57 8 3 45 50 48 3 45 50 48 8 3 45 50 48 3 45 50 49 8 3 45 50 49 3 45 50 48 8 3 45 50 49 3 45 50 49 8 3 45 50 49 3 45 50 50 8 3 45 50 50 3 45 50 49 8 3 45 50 50 3 45 50 50 8 3 45 50 50 3 45 50 51 8 3 45 50 51 3 45 50 50 8 3 45 50 51 3 45 50 51 8 3 45 50 51 3 45 50 52 8 3 45 50 52 3 45 50 51 8 3 45 50 52 3 45 50 52 8 3 45 50 52 3 45 50 53 8 3 45 50 53 3 45 50 52 8 3 45 50 53 3 45 50 53 8 3 45 50 53 3 45 50 54 8 3 45 50 54 3 45 50 53 8 3 45 50 54 3 45 50 54 8 3 45 50 54 3 45 50 55 8 3 45 50 55 3 45 50 54 8 3 45 50 55 3 45 50 55 8 3 45 50 55 3 45 50 56 8 3 45 50 56 3 45 50 55 8 3 45 50 56 3 45 50 56 8 3 45 50 56 3 45 50 57 8 3 45 50 57 3 45 50 56 8 3 45 50 57 3 45 50 57 8 3 45 50 57 3 45 51 48 8 3 45 51 48 3 45 50 57 8 3 45 51 48 3 45 51 48 8 3 45 51 48 3 45 51 49 8 3 45 51 49 3 45 51 48 8 3 45 51 49 3 45 51 49 8 3 45 51 49 3 45 51 50 8 3 45 51 50 3 45 51 49 8 3 45 51 50 3 45 51 50 8 3 45 51 50 3 45 51 51 8 3 45 51 51 3 45 51 50 8 3 45 51 51 3 45 51 51 8 3 45 51 51 3 45 51 52 8 3 45 51 52 3 45 51 51 8 3 45 51 52 3 45 51 52 8 3 45 51 52 3 45 51 53 8 3 45 51 53 3 45 51 52 8 3 45 51 53 3 45 51 53 8 3 45 51 53 3 45 51 54 8 3 45 51 54 3 45 51 53 8 3 45 51 54 3 45 51 54 8 3 45 51 54 3 45 51 55 8 3 45 51 55 3 45 51 54 8 3 45 51 55 3 45 51 55 8 3 45 51 55 3 45 51 56 8 3 45 51 56 3 45 51 55 8 3 45 51 56 3 45 51 56 8 3 45 51 56 3 45 51 57 8 3 45 51 57 3 45 51 56 8 3 45 51 57 3 45 51 57 8 3 45 51 57 3 45 52 48 8 3 45 52 48 3 45 51 57 8 3 45 52 48 3 45 52 48 8 3 45 52 48 3 45 52 49 8 3 45 52 49 3 45 52 48 8 3 45 52 49 3 45 52 49 8 3 45 52 49 3 45 52 50 8 3 45 52 50 3 45 52 49 8 3 45 52 50 3 45 52 50 8 3 45 52 50 3 45 52 51 8 3 45 52 51 3 45 52 50 8 3 45 52 51 3 45 52 51 8 3 45 52 51 3 45 52 52 8 3 45 52 52 3 45 52 51 8 3 45 52 52 3 45 52 52 8 3 45 52 52 3 45 52 53 8 3 45 52 53 3 45 52 52 8 3 45 52 53 3 45 52 53 8 3 45 52 53 3 45 52 54 8 3 45 52 54 3 45 52 53 8 3 45 52 54 3 45 52 54 8 3 45 52 54 3 45 52 55 8 3 45 52 55 3 45 52 54 8 3 45 52 55 3 45 52 55 8 3 45 52 55 3 45 52 56 8 3 45 52 56 3 45 52 55 8 3 45 52 56 3 45 52 56 8 3 45 52 56 3 45 52 57 8 3 45 52 57 3 45 52 56 8 3 45 52 57 3 45 52 57 8 3 45 52 57 3 45 53 48 8 3 45 53 48 3 45 52 57 8 3 45 53 48 3 45 53 48 8 3 45 53 48 3 45 53 49 8 3 45 53 49 3 45 53 48 8 3 45 53 49 3 45 53 49 8 3 45 53 49 3 45 53 50 8 3 45 53 50 3 45 53 49 8 3 45 53 50 3 45 53 50 8 3 45 53 50 3 45 53 51 8 3 45 53 51 3 45 53 50 8 3 45 53 51 3 45 53 51 8 3 45 53 51 3 45 53 52 8 3 45 53 52 3 45 53 51 8 3 45 53 52 3 45 53 52 8 3 45 53 52 3 45 53 53 8 3 45 53 53 3 45 53 52 8 3 45 53 53 3 45 53 53 8 3 45 53 53 3 45 53 54 8 3 45 53 54 3 45 53 53 8 3 45 53 54 3 45 53 54 8 3 45 53 54 3 45 53 55 8 3 45 53 55 3 45 53 54 8 3 45 53 55 3 45 53 55 8 3 45 53 55 3 45 53 56 8 3 45 53 56 3 45 53 55 8 3 45 53 56 3 45 53 56 8 3 45 53 56 3 45 53 57 8 3 45 53 57 3 45 53 56 8 3 45 53 57 3 45 53 57 8 3 45 53 57 3 45 54 48 8 3 45 54 48 3 45 53 57 8 3 45 54 48 3 45 54 48 8 3 45 54 48 3 45 54 49 8 3 45 54 49 3 45 54 48 8 3 45 54 49 3 45 54 49 8 3 45 54 49 3 45 54 50 8 3 45 54 50 3 45 54 49 8 3 45 54 50 3 45 54 50 8 3 45 54 50 3 45 54 51 8 3 45 54 51 3 45 54 50 8 3 45 54 51 3 45 54 51 8 3 45 54 51 3 45 54 52 8 3 45 54 52 3 45 54 51 8 3 45 54 52 3 45 54 52 8 3 45 54 52 3 45 54 53"));
fn routine_0(c: &mut Context) -> Space {
  let v0_2: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_0), &((*CONSTANT_1).read_zipper()));
  let v0_5: Space = routine_1(c, &(*CONSTANT_2), &(*CONSTANT_2), &((*CONSTANT_3).read_zipper()));
  let v0_6: Space = unite(&(v0_2),&(v0_5));
  let mut v0_8 = Space::new();
  let mut v0_8_write = v0_8.write_zipper();
  let mut v0_8_cursor = (v0_6).read_zipper();
  let v0_8_origin = v0_8_cursor.path().len();
  for v0_8_byte in v0_8_cursor.child_mask().iter() {
    v0_8_cursor.descend_to_existing_byte(v0_8_byte);
    {
    let v1_2: Space = routine_2(c, &v0_8_cursor.path()[v0_8_origin..(v0_8_origin + 1)], &v0_8_cursor.path()[v0_8_origin..(v0_8_origin + 1)], &v0_8_cursor, &((*CONSTANT_4).read_zipper()));
    join_wrapped_into(&mut v0_8_write,&((v1_2).read_zipper()),&[]);
    }
    v0_8_cursor.ascend(1);
  }
  drop(v0_8_cursor);
  drop(v0_8_write);
  let v0_11: Space = routine_3(c, &(*CONSTANT_0), &(*CONSTANT_0), &((*CONSTANT_1).read_zipper()), &((*CONSTANT_4).read_zipper()));
  let v0_12: Space = unite(&(v0_8),&(v0_11));
  let v0_15: Space = routine_3(c, &(*CONSTANT_2), &(*CONSTANT_2), &((*CONSTANT_3).read_zipper()), &((*CONSTANT_4).read_zipper()));
  let v0_16: Space = unite(&(v0_12),&(v0_15));
  let v0_18: Space = wrap(&(v0_16),&(*CONSTANT_5));
  (v0_18).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v2_5: Space = singleton(&(*p1));
  let v2_6: Space = intersect(&(*CONSTANT_7),&(v2_5));
  let v2_7: Space = if has_head(&(v2_6)) { singleton(&[]) } else { Space::new() };
  drop(v2_6);
  let v2_8: Space = subtract(&(*CONSTANT_6),&(v2_7));
  drop(v2_7);
  let v2_19: Space = if (&(v2_8)).is_empty() { Space::new() } else {
    let v3_11: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v3_14: Space = if (&(v3_11)).is_empty() { Space::new() } else {
      let v4_13: Space = routine_4(c, &(*CONSTANT_9), &(*p0), &(*s0));
      compose(&(v3_11),&(v4_13))
    };
    drop(v3_11);
    let mut v3_17 = Space::new();
    let mut v3_17_write = v3_17.write_zipper();
    let mut v3_17_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v3_17_origin = v3_17_cursor.path().len();
    for v3_17_byte in v3_17_cursor.child_mask().iter() {
      v3_17_cursor.descend_to_existing_byte(v3_17_byte);
      {
      let v5_2_arg_0: &[u8] = &v3_17_cursor.path()[v3_17_origin..(v3_17_origin + 1)];
      let v5_2_arg_1: &[u8] = &(*p0);
      let v5_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v5_2_more = v3_17_cursor.is_val() || next_value_within(&mut v3_17_cursor,(v3_17_origin + 1));
      while v5_2_more {
        {
        let v5_2_depth = v3_17_cursor.path().len();
        let mut v6_4_cursor = (*v5_2_arg_3).read_zipper();
        let v6_4_origin = v6_4_cursor.path().len();
        for v6_4_byte in v6_4_cursor.child_mask().iter() {
          v6_4_cursor.descend_to_existing_byte(v6_4_byte);
          {
          let v7_2: Path = concat_path(&(*v5_2_arg_1),&v6_4_cursor.path()[v6_4_origin..(v6_4_origin + 1)]);
          let v7_3: Space = routine_1(c, &(v7_2), &v3_17_cursor.path()[v3_17_origin..v5_2_depth], &v6_4_cursor);
          drop(v7_2);
          join_wrapped_into(&mut v3_17_write,&((v7_3).read_zipper()),&[]);
          }
          v6_4_cursor.ascend(1);
        }
        drop(v6_4_cursor);
        }
        v5_2_more = next_value_within(&mut v3_17_cursor,(v3_17_origin + 1));
      }
      }
      v3_17_cursor.ascend(1);
    }
    drop(v3_17_cursor);
    drop(v3_17_write);
    let v3_18: Space = unite(&(v3_14),&(v3_17));
    compose(&(v2_8),&(v3_18))
  };
  drop(v2_8);
  let v2_21: Space = intersect(&(*CONSTANT_7),&(v2_5));
  drop(v2_5);
  let v2_22: Space = if has_head(&(v2_21)) { singleton(&[]) } else { Space::new() };
  drop(v2_21);
  let v2_24: Space = if (&(v2_22)).is_empty() { Space::new() } else {
    let mut v8_23 = Space::new();
    let mut v8_23_write = v8_23.write_zipper();
    let mut v8_23_cursor = (*s0).read_zipper();
    let v8_23_origin = v8_23_cursor.path().len();
    for v8_23_byte in v8_23_cursor.child_mask().iter() {
      v8_23_cursor.descend_to_existing_byte(v8_23_byte);
      {
      let v9_2: Space = routine_5(c, &v8_23_cursor.path()[v8_23_origin..(v8_23_origin + 1)], &v8_23_cursor.path()[v8_23_origin..(v8_23_origin + 1)], &(*p0), &v8_23_cursor);
      join_wrapped_into(&mut v8_23_write,&((v9_2).read_zipper()),&[]);
      }
      v8_23_cursor.ascend(1);
    }
    drop(v8_23_cursor);
    drop(v8_23_write);
    compose(&(v2_22),&(v8_23))
  };
  drop(v2_22);
  let v2_25: Space = unite(&(v2_19),&(v2_24));
  (v2_25).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v10_6: Space = singleton(&(*p1));
  let v10_7: Space = intersect(&(*CONSTANT_7),&(v10_6));
  let v10_8: Space = if has_head(&(v10_7)) { singleton(&[]) } else { Space::new() };
  drop(v10_7);
  let v10_9: Space = subtract(&(*CONSTANT_6),&(v10_8));
  drop(v10_8);
  let v10_20: Space = if (&(v10_9)).is_empty() { Space::new() } else {
    let v11_12: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v11_15: Space = if (&(v11_12)).is_empty() { Space::new() } else {
      let v12_14: Space = routine_6(c, &(*CONSTANT_9), &(*p0), &(*s0), &(*s1));
      compose(&(v11_12),&(v12_14))
    };
    drop(v11_12);
    let mut v11_18 = Space::new();
    let mut v11_18_write = v11_18.write_zipper();
    let mut v11_18_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v11_18_origin = v11_18_cursor.path().len();
    for v11_18_byte in v11_18_cursor.child_mask().iter() {
      v11_18_cursor.descend_to_existing_byte(v11_18_byte);
      {
      let v13_2_arg_0: &[u8] = &v11_18_cursor.path()[v11_18_origin..(v11_18_origin + 1)];
      let v13_2_arg_1: &[u8] = &(*p0);
      let v13_2_arg_3: &Space = &(&(*s0)).make_map();
      let v13_2_arg_4: &Space = &(&(*s1)).make_map();
      let mut v13_2_more = v11_18_cursor.is_val() || next_value_within(&mut v11_18_cursor,(v11_18_origin + 1));
      while v13_2_more {
        {
        let v13_2_depth = v11_18_cursor.path().len();
        let mut v14_5_cursor = (*v13_2_arg_3).read_zipper();
        let v14_5_origin = v14_5_cursor.path().len();
        for v14_5_byte in v14_5_cursor.child_mask().iter() {
          v14_5_cursor.descend_to_existing_byte(v14_5_byte);
          {
          let v15_2: Path = concat_path(&(*v13_2_arg_1),&v14_5_cursor.path()[v14_5_origin..(v14_5_origin + 1)]);
          let v15_3: Space = routine_2(c, &(v15_2), &v11_18_cursor.path()[v11_18_origin..v13_2_depth], &v14_5_cursor, &((*v13_2_arg_4).read_zipper()));
          drop(v15_2);
          join_wrapped_into(&mut v11_18_write,&((v15_3).read_zipper()),&[]);
          }
          v14_5_cursor.ascend(1);
        }
        drop(v14_5_cursor);
        }
        v13_2_more = next_value_within(&mut v11_18_cursor,(v11_18_origin + 1));
      }
      }
      v11_18_cursor.ascend(1);
    }
    drop(v11_18_cursor);
    drop(v11_18_write);
    let v11_19: Space = unite(&(v11_15),&(v11_18));
    compose(&(v10_9),&(v11_19))
  };
  drop(v10_9);
  let v10_22: Space = intersect(&(*CONSTANT_7),&(v10_6));
  drop(v10_6);
  let v10_23: Space = if has_head(&(v10_22)) { singleton(&[]) } else { Space::new() };
  drop(v10_22);
  let v10_25: Space = if (&(v10_23)).is_empty() { Space::new() } else {
    let mut v16_24 = Space::new();
    let mut v16_24_write = v16_24.write_zipper();
    let mut v16_24_cursor = (*s0).read_zipper();
    let v16_24_origin = v16_24_cursor.path().len();
    for v16_24_byte in v16_24_cursor.child_mask().iter() {
      v16_24_cursor.descend_to_existing_byte(v16_24_byte);
      {
      let v17_2: Space = routine_7(c, &v16_24_cursor.path()[v16_24_origin..(v16_24_origin + 1)], &v16_24_cursor.path()[v16_24_origin..(v16_24_origin + 1)], &(*p0), &v16_24_cursor, &(*s1));
      join_wrapped_into(&mut v16_24_write,&((v17_2).read_zipper()),&[]);
      }
      v16_24_cursor.ascend(1);
    }
    drop(v16_24_cursor);
    drop(v16_24_write);
    compose(&(v10_23),&(v16_24))
  };
  drop(v10_23);
  let v10_26: Space = unite(&(v10_20),&(v10_25));
  (v10_26).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v18_6: Space = singleton(&(*p1));
  let v18_7: Space = intersect(&(*CONSTANT_7),&(v18_6));
  let v18_8: Space = if has_head(&(v18_7)) { singleton(&[]) } else { Space::new() };
  drop(v18_7);
  let v18_9: Space = subtract(&(*CONSTANT_6),&(v18_8));
  drop(v18_8);
  let v18_20: Space = if (&(v18_9)).is_empty() { Space::new() } else {
    let v19_12: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v19_15: Space = if (&(v19_12)).is_empty() { Space::new() } else {
      let v20_14: Space = routine_8(c, &(*CONSTANT_9), &(*p0), &(*s0), &(*s1));
      compose(&(v19_12),&(v20_14))
    };
    drop(v19_12);
    let mut v19_18 = Space::new();
    let mut v19_18_write = v19_18.write_zipper();
    let mut v19_18_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v19_18_origin = v19_18_cursor.path().len();
    for v19_18_byte in v19_18_cursor.child_mask().iter() {
      v19_18_cursor.descend_to_existing_byte(v19_18_byte);
      {
      let v21_2_arg_0: &[u8] = &v19_18_cursor.path()[v19_18_origin..(v19_18_origin + 1)];
      let v21_2_arg_1: &[u8] = &(*p0);
      let v21_2_arg_3: &Space = &(&(*s0)).make_map();
      let v21_2_arg_4: &Space = &(&(*s1)).make_map();
      let mut v21_2_more = v19_18_cursor.is_val() || next_value_within(&mut v19_18_cursor,(v19_18_origin + 1));
      while v21_2_more {
        {
        let v21_2_depth = v19_18_cursor.path().len();
        let mut v22_5_cursor = (*v21_2_arg_3).read_zipper();
        let v22_5_origin = v22_5_cursor.path().len();
        for v22_5_byte in v22_5_cursor.child_mask().iter() {
          v22_5_cursor.descend_to_existing_byte(v22_5_byte);
          {
          let v23_2: Path = concat_path(&(*v21_2_arg_1),&v22_5_cursor.path()[v22_5_origin..(v22_5_origin + 1)]);
          let v23_3: Space = routine_3(c, &(v23_2), &v19_18_cursor.path()[v19_18_origin..v21_2_depth], &v22_5_cursor, &((*v21_2_arg_4).read_zipper()));
          drop(v23_2);
          join_wrapped_into(&mut v19_18_write,&((v23_3).read_zipper()),&[]);
          }
          v22_5_cursor.ascend(1);
        }
        drop(v22_5_cursor);
        }
        v21_2_more = next_value_within(&mut v19_18_cursor,(v19_18_origin + 1));
      }
      }
      v19_18_cursor.ascend(1);
    }
    drop(v19_18_cursor);
    drop(v19_18_write);
    let v19_19: Space = unite(&(v19_15),&(v19_18));
    compose(&(v18_9),&(v19_19))
  };
  drop(v18_9);
  let v18_22: Space = intersect(&(*CONSTANT_7),&(v18_6));
  drop(v18_6);
  let v18_23: Space = if has_head(&(v18_22)) { singleton(&[]) } else { Space::new() };
  drop(v18_22);
  let v18_25: Space = if (&(v18_23)).is_empty() { Space::new() } else {
    let mut v24_24 = Space::new();
    let mut v24_24_write = v24_24.write_zipper();
    let mut v24_24_cursor = (*s0).read_zipper();
    let v24_24_origin = v24_24_cursor.path().len();
    for v24_24_byte in v24_24_cursor.child_mask().iter() {
      v24_24_cursor.descend_to_existing_byte(v24_24_byte);
      {
      let v25_2: Space = routine_9(c, &v24_24_cursor.path()[v24_24_origin..(v24_24_origin + 1)], &v24_24_cursor.path()[v24_24_origin..(v24_24_origin + 1)], &(*p0), &v24_24_cursor, &(*s1));
      join_wrapped_into(&mut v24_24_write,&((v25_2).read_zipper()),&[]);
      }
      v24_24_cursor.ascend(1);
    }
    drop(v24_24_cursor);
    drop(v24_24_write);
    compose(&(v18_23),&(v24_24))
  };
  drop(v18_23);
  let v18_26: Space = unite(&(v18_20),&(v18_25));
  (v18_26).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v26_5: Space = singleton(&(*p0));
  let v26_6: Space = intersect(&(*CONSTANT_7),&(v26_5));
  let v26_7: Space = if has_head(&(v26_6)) { singleton(&[]) } else { Space::new() };
  drop(v26_6);
  let v26_8: Space = subtract(&(*CONSTANT_6),&(v26_7));
  drop(v26_7);
  let v26_13: Space = intersect(&(*CONSTANT_7),&(v26_5));
  drop(v26_5);
  let v26_14: Space = if has_head(&(v26_13)) { singleton(&[]) } else { Space::new() };
  drop(v26_13);
  let mut v26_15 = Space::new();
  let mut v26_15_write = v26_15.write_zipper();
  let mut v26_15_cursor = (*s0).read_zipper();
  let v26_15_origin = v26_15_cursor.path().len();
  for v26_15_byte in v26_15_cursor.child_mask().iter() {
    v26_15_cursor.descend_to_existing_byte(v26_15_byte);
    {
    let v27_4: Space = if (&(v26_8)).is_empty() { Space::new() } else {
      let v28_2: Path = concat_path(&(*p1),&v26_15_cursor.path()[v26_15_origin..(v26_15_origin + 1)]);
      let mut v28_3 = Space::new();
      let mut v28_3_write = v28_3.write_zipper();
      let v28_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v28_3_arg_1: &[u8] = &(v28_2);
      let v28_3_arg_3: &Space = &(&v26_15_cursor).make_map();
      let mut v28_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v28_3_origin = v28_3_cursor.path().len();
      let mut v28_3_more = v28_3_cursor.is_val() || next_value_within(&mut v28_3_cursor,v28_3_origin);
      while v28_3_more {
        {
        let v28_3_depth = v28_3_cursor.path().len();
        let v29_4: Space = routine_4(c, &v28_3_cursor.path()[v28_3_origin..v28_3_depth], &(*v28_3_arg_1), &((*v28_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v28_3_write,&((v29_4).read_zipper()),&[]);
        }
        v28_3_more = next_value_within(&mut v28_3_cursor,v28_3_origin);
      }
      drop(v28_3_cursor);
      drop(v28_3_write);
      compose(&(v26_8),&(v28_3))
    };
    let v27_6: Space = if (&(v26_14)).is_empty() { Space::new() } else {
      let v30_2: Path = concat_path(&(*p1),&v26_15_cursor.path()[v26_15_origin..(v26_15_origin + 1)]);
      let mut v30_5 = Space::new();
      let mut v30_5_write = v30_5.write_zipper();
      for v30_5_byte in v26_15_cursor.child_mask().iter() {
        v26_15_cursor.descend_to_existing_byte(v30_5_byte);
        {
        let v31_2: Space = routine_5(c, &v26_15_cursor.path()[(v26_15_origin + 1)..(v26_15_origin + 2)], &v26_15_cursor.path()[(v26_15_origin + 1)..(v26_15_origin + 2)], &(v30_2), &v26_15_cursor);
        join_wrapped_into(&mut v30_5_write,&((v31_2).read_zipper()),&[]);
        }
        v26_15_cursor.ascend(1);
      }
      drop(v30_5_write);
      drop(v30_2);
      compose(&(v26_14),&(v30_5))
    };
    let v27_7: Space = unite(&(v27_4),&(v27_6));
    join_wrapped_into(&mut v26_15_write,&((v27_7).read_zipper()),&[]);
    }
    v26_15_cursor.ascend(1);
  }
  drop(v26_15_cursor);
  drop(v26_15_write);
  drop(v26_8);
  drop(v26_14);
  (v26_15).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v32_6: Space = singleton(&(*p1));
  let v32_7: Space = intersect(&(*CONSTANT_7),&(v32_6));
  let v32_8: Space = if has_head(&(v32_7)) { singleton(&[]) } else { Space::new() };
  drop(v32_7);
  let v32_9: Space = subtract(&(*CONSTANT_6),&(v32_8));
  drop(v32_8);
  let v32_20: Space = if (&(v32_9)).is_empty() { Space::new() } else {
    let v33_12: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v33_15: Space = if (&(v33_12)).is_empty() { Space::new() } else {
      let v34_14: Space = routine_10(c, &(*CONSTANT_9), &(*p0), &(*p2), &(*s0));
      compose(&(v33_12),&(v34_14))
    };
    drop(v33_12);
    let mut v33_18 = Space::new();
    let mut v33_18_write = v33_18.write_zipper();
    let mut v33_18_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v33_18_origin = v33_18_cursor.path().len();
    for v33_18_byte in v33_18_cursor.child_mask().iter() {
      v33_18_cursor.descend_to_existing_byte(v33_18_byte);
      {
      let v35_2_arg_0: &[u8] = &v33_18_cursor.path()[v33_18_origin..(v33_18_origin + 1)];
      let v35_2_arg_1: &[u8] = &(*p0);
      let v35_2_arg_2: &[u8] = &(*p2);
      let v35_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v35_2_more = v33_18_cursor.is_val() || next_value_within(&mut v33_18_cursor,(v33_18_origin + 1));
      while v35_2_more {
        {
        let v35_2_depth = v33_18_cursor.path().len();
        let mut v36_5_cursor = (*v35_2_arg_4).read_zipper();
        let v36_5_origin = v36_5_cursor.path().len();
        for v36_5_byte in v36_5_cursor.child_mask().iter() {
          v36_5_cursor.descend_to_existing_byte(v36_5_byte);
          {
          let v37_2: Path = concat_path(&(*v35_2_arg_1),&v36_5_cursor.path()[v36_5_origin..(v36_5_origin + 1)]);
          let v37_3: Space = routine_5(c, &(v37_2), &v33_18_cursor.path()[v33_18_origin..v35_2_depth], &(*v35_2_arg_2), &v36_5_cursor);
          drop(v37_2);
          join_wrapped_into(&mut v33_18_write,&((v37_3).read_zipper()),&[]);
          }
          v36_5_cursor.ascend(1);
        }
        drop(v36_5_cursor);
        }
        v35_2_more = next_value_within(&mut v33_18_cursor,(v33_18_origin + 1));
      }
      }
      v33_18_cursor.ascend(1);
    }
    drop(v33_18_cursor);
    drop(v33_18_write);
    let v33_19: Space = unite(&(v33_15),&(v33_18));
    compose(&(v32_9),&(v33_19))
  };
  drop(v32_9);
  let v32_22: Space = intersect(&(*CONSTANT_7),&(v32_6));
  drop(v32_6);
  let v32_23: Space = if has_head(&(v32_22)) { singleton(&[]) } else { Space::new() };
  drop(v32_22);
  let v32_27: Space = if (&(v32_23)).is_empty() { Space::new() } else {
    let v38_24: Path = concat_path(&(*p2),&(*p0));
    let v38_25: Space = singleton(&(v38_24));
    drop(v38_24);
    let mut v38_26 = Space::new();
    let mut v38_26_write = v38_26.write_zipper();
    let mut v38_26_cursor = (v38_25).read_zipper();
    let v38_26_origin = v38_26_cursor.path().len();
    for v38_26_byte in v38_26_cursor.child_mask().iter() {
      v38_26_cursor.descend_to_existing_byte(v38_26_byte);
      {
      let v39_2: Space = routine_11(c, &v38_26_cursor.path()[v38_26_origin..(v38_26_origin + 1)], &v38_26_cursor.path()[v38_26_origin..(v38_26_origin + 1)], &v38_26_cursor);
      join_wrapped_into(&mut v38_26_write,&((v39_2).read_zipper()),&[]);
      }
      v38_26_cursor.ascend(1);
    }
    drop(v38_26_cursor);
    drop(v38_26_write);
    drop(v38_25);
    compose(&(v32_23),&(v38_26))
  };
  drop(v32_23);
  let v32_28: Space = unite(&(v32_20),&(v32_27));
  (v32_28).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v40_6: Space = singleton(&(*p0));
  let v40_7: Space = intersect(&(*CONSTANT_7),&(v40_6));
  let v40_8: Space = if has_head(&(v40_7)) { singleton(&[]) } else { Space::new() };
  drop(v40_7);
  let v40_9: Space = subtract(&(*CONSTANT_6),&(v40_8));
  drop(v40_8);
  let v40_14: Space = intersect(&(*CONSTANT_7),&(v40_6));
  drop(v40_6);
  let v40_15: Space = if has_head(&(v40_14)) { singleton(&[]) } else { Space::new() };
  drop(v40_14);
  let mut v40_16 = Space::new();
  let mut v40_16_write = v40_16.write_zipper();
  let mut v40_16_cursor = (*s0).read_zipper();
  let v40_16_origin = v40_16_cursor.path().len();
  for v40_16_byte in v40_16_cursor.child_mask().iter() {
    v40_16_cursor.descend_to_existing_byte(v40_16_byte);
    {
    let v41_4: Space = if (&(v40_9)).is_empty() { Space::new() } else {
      let v42_2: Path = concat_path(&(*p1),&v40_16_cursor.path()[v40_16_origin..(v40_16_origin + 1)]);
      let mut v42_3 = Space::new();
      let mut v42_3_write = v42_3.write_zipper();
      let v42_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v42_3_arg_1: &[u8] = &(v42_2);
      let v42_3_arg_3: &Space = &(&v40_16_cursor).make_map();
      let v42_3_arg_4: &Space = &(&(*s1)).make_map();
      let mut v42_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v42_3_origin = v42_3_cursor.path().len();
      let mut v42_3_more = v42_3_cursor.is_val() || next_value_within(&mut v42_3_cursor,v42_3_origin);
      while v42_3_more {
        {
        let v42_3_depth = v42_3_cursor.path().len();
        let v43_5: Space = routine_6(c, &v42_3_cursor.path()[v42_3_origin..v42_3_depth], &(*v42_3_arg_1), &((*v42_3_arg_3).read_zipper()), &((*v42_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v42_3_write,&((v43_5).read_zipper()),&[]);
        }
        v42_3_more = next_value_within(&mut v42_3_cursor,v42_3_origin);
      }
      drop(v42_3_cursor);
      drop(v42_3_write);
      compose(&(v40_9),&(v42_3))
    };
    let v41_6: Space = if (&(v40_15)).is_empty() { Space::new() } else {
      let v44_2: Path = concat_path(&(*p1),&v40_16_cursor.path()[v40_16_origin..(v40_16_origin + 1)]);
      let mut v44_5 = Space::new();
      let mut v44_5_write = v44_5.write_zipper();
      for v44_5_byte in v40_16_cursor.child_mask().iter() {
        v40_16_cursor.descend_to_existing_byte(v44_5_byte);
        {
        let v45_2: Space = routine_7(c, &v40_16_cursor.path()[(v40_16_origin + 1)..(v40_16_origin + 2)], &v40_16_cursor.path()[(v40_16_origin + 1)..(v40_16_origin + 2)], &(v44_2), &v40_16_cursor, &(*s1));
        join_wrapped_into(&mut v44_5_write,&((v45_2).read_zipper()),&[]);
        }
        v40_16_cursor.ascend(1);
      }
      drop(v44_5_write);
      drop(v44_2);
      compose(&(v40_15),&(v44_5))
    };
    let v41_7: Space = unite(&(v41_4),&(v41_6));
    join_wrapped_into(&mut v40_16_write,&((v41_7).read_zipper()),&[]);
    }
    v40_16_cursor.ascend(1);
  }
  drop(v40_16_cursor);
  drop(v40_16_write);
  drop(v40_9);
  drop(v40_15);
  (v40_16).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v46_7: Space = singleton(&(*p1));
  let v46_8: Space = intersect(&(*CONSTANT_7),&(v46_7));
  let v46_9: Space = if has_head(&(v46_8)) { singleton(&[]) } else { Space::new() };
  drop(v46_8);
  let v46_10: Space = subtract(&(*CONSTANT_6),&(v46_9));
  drop(v46_9);
  let v46_21: Space = if (&(v46_10)).is_empty() { Space::new() } else {
    let v47_13: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v47_16: Space = if (&(v47_13)).is_empty() { Space::new() } else {
      let v48_15: Space = routine_12(c, &(*CONSTANT_9), &(*p0), &(*p2), &(*s0), &(*s1));
      compose(&(v47_13),&(v48_15))
    };
    drop(v47_13);
    let mut v47_19 = Space::new();
    let mut v47_19_write = v47_19.write_zipper();
    let mut v47_19_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v47_19_origin = v47_19_cursor.path().len();
    for v47_19_byte in v47_19_cursor.child_mask().iter() {
      v47_19_cursor.descend_to_existing_byte(v47_19_byte);
      {
      let v49_2_arg_0: &[u8] = &v47_19_cursor.path()[v47_19_origin..(v47_19_origin + 1)];
      let v49_2_arg_1: &[u8] = &(*p0);
      let v49_2_arg_2: &[u8] = &(*p2);
      let v49_2_arg_4: &Space = &(&(*s0)).make_map();
      let v49_2_arg_5: &Space = &(&(*s1)).make_map();
      let mut v49_2_more = v47_19_cursor.is_val() || next_value_within(&mut v47_19_cursor,(v47_19_origin + 1));
      while v49_2_more {
        {
        let v49_2_depth = v47_19_cursor.path().len();
        let mut v50_6_cursor = (*v49_2_arg_4).read_zipper();
        let v50_6_origin = v50_6_cursor.path().len();
        for v50_6_byte in v50_6_cursor.child_mask().iter() {
          v50_6_cursor.descend_to_existing_byte(v50_6_byte);
          {
          let v51_2: Path = concat_path(&(*v49_2_arg_1),&v50_6_cursor.path()[v50_6_origin..(v50_6_origin + 1)]);
          let v51_3: Space = routine_7(c, &(v51_2), &v47_19_cursor.path()[v47_19_origin..v49_2_depth], &(*v49_2_arg_2), &v50_6_cursor, &((*v49_2_arg_5).read_zipper()));
          drop(v51_2);
          join_wrapped_into(&mut v47_19_write,&((v51_3).read_zipper()),&[]);
          }
          v50_6_cursor.ascend(1);
        }
        drop(v50_6_cursor);
        }
        v49_2_more = next_value_within(&mut v47_19_cursor,(v47_19_origin + 1));
      }
      }
      v47_19_cursor.ascend(1);
    }
    drop(v47_19_cursor);
    drop(v47_19_write);
    let v47_20: Space = unite(&(v47_16),&(v47_19));
    compose(&(v46_10),&(v47_20))
  };
  drop(v46_10);
  let v46_23: Space = intersect(&(*CONSTANT_7),&(v46_7));
  drop(v46_7);
  let v46_24: Space = if has_head(&(v46_23)) { singleton(&[]) } else { Space::new() };
  drop(v46_23);
  let v46_803: Space = if (&(v46_24)).is_empty() { Space::new() } else {
    let v52_27: Path = concat_path(&(*p2),&(*p0));
    let v52_28: Space = routine_13(c, &(v52_27));
    let v52_29: Space = intersect(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))),&(v52_28));
    let v52_30: Space = routine_14(c, &((v52_29).read_zipper()));
    let mut v52_31 = Space::new();
    let mut v52_31_write = v52_31.write_zipper();
    let mut v52_31_cursor = (v52_30).read_zipper();
    let v52_31_origin = v52_31_cursor.path().len();
    for v52_31_byte in v52_31_cursor.child_mask().iter() {
      v52_31_cursor.descend_to_existing_byte(v52_31_byte);
      {
      let v53_2: Space = routine_15(c, &v52_31_cursor.path()[v52_31_origin..(v52_31_origin + 1)], &v52_31_cursor.path()[v52_31_origin..(v52_31_origin + 1)], &v52_31_cursor);
      join_wrapped_into(&mut v52_31_write,&((v53_2).read_zipper()),&[]);
      }
      v52_31_cursor.ascend(1);
    }
    drop(v52_31_cursor);
    drop(v52_31_write);
    let v52_32: Space = routine_16(c, &((v52_29).read_zipper()));
    let mut v52_33 = Space::new();
    let mut v52_33_write = v52_33.write_zipper();
    let mut v52_33_cursor = (v52_32).read_zipper();
    let v52_33_origin = v52_33_cursor.path().len();
    for v52_33_byte in v52_33_cursor.child_mask().iter() {
      v52_33_cursor.descend_to_existing_byte(v52_33_byte);
      {
      let v54_2: Space = routine_17(c, &v52_33_cursor.path()[v52_33_origin..(v52_33_origin + 1)], &v52_33_cursor.path()[v52_33_origin..(v52_33_origin + 1)], &v52_33_cursor);
      join_wrapped_into(&mut v52_33_write,&((v54_2).read_zipper()),&[]);
      }
      v52_33_cursor.ascend(1);
    }
    drop(v52_33_cursor);
    drop(v52_33_write);
    let v52_34: Space = subtract(&(v52_31),&(v52_33));
    let v52_36: Space = if (&(v52_34)).is_empty() { Space::new() } else {
      let v55_35: Space = singleton(&(v52_27));
      compose(&(v52_34),&(v55_35))
    };
    let v52_802: Space = drop_length_prefixes(&(v52_36));
    compose(&(v46_24),&(v52_802))
  };
  drop(v46_24);
  let v46_804: Space = unite(&(v46_21),&(v46_803));
  (v46_804).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v56_6: Space = singleton(&(*p0));
  let v56_7: Space = intersect(&(*CONSTANT_7),&(v56_6));
  let v56_8: Space = if has_head(&(v56_7)) { singleton(&[]) } else { Space::new() };
  drop(v56_7);
  let v56_9: Space = subtract(&(*CONSTANT_6),&(v56_8));
  drop(v56_8);
  let v56_14: Space = intersect(&(*CONSTANT_7),&(v56_6));
  drop(v56_6);
  let v56_15: Space = if has_head(&(v56_14)) { singleton(&[]) } else { Space::new() };
  drop(v56_14);
  let mut v56_16 = Space::new();
  let mut v56_16_write = v56_16.write_zipper();
  let mut v56_16_cursor = (*s0).read_zipper();
  let v56_16_origin = v56_16_cursor.path().len();
  for v56_16_byte in v56_16_cursor.child_mask().iter() {
    v56_16_cursor.descend_to_existing_byte(v56_16_byte);
    {
    let v57_4: Space = if (&(v56_9)).is_empty() { Space::new() } else {
      let v58_2: Path = concat_path(&(*p1),&v56_16_cursor.path()[v56_16_origin..(v56_16_origin + 1)]);
      let mut v58_3 = Space::new();
      let mut v58_3_write = v58_3.write_zipper();
      let v58_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v58_3_arg_1: &[u8] = &(v58_2);
      let v58_3_arg_3: &Space = &(&v56_16_cursor).make_map();
      let v58_3_arg_4: &Space = &(&(*s1)).make_map();
      let mut v58_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v58_3_origin = v58_3_cursor.path().len();
      let mut v58_3_more = v58_3_cursor.is_val() || next_value_within(&mut v58_3_cursor,v58_3_origin);
      while v58_3_more {
        {
        let v58_3_depth = v58_3_cursor.path().len();
        let v59_5: Space = routine_8(c, &v58_3_cursor.path()[v58_3_origin..v58_3_depth], &(*v58_3_arg_1), &((*v58_3_arg_3).read_zipper()), &((*v58_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v58_3_write,&((v59_5).read_zipper()),&[]);
        }
        v58_3_more = next_value_within(&mut v58_3_cursor,v58_3_origin);
      }
      drop(v58_3_cursor);
      drop(v58_3_write);
      compose(&(v56_9),&(v58_3))
    };
    let v57_6: Space = if (&(v56_15)).is_empty() { Space::new() } else {
      let v60_2: Path = concat_path(&(*p1),&v56_16_cursor.path()[v56_16_origin..(v56_16_origin + 1)]);
      let mut v60_5 = Space::new();
      let mut v60_5_write = v60_5.write_zipper();
      for v60_5_byte in v56_16_cursor.child_mask().iter() {
        v56_16_cursor.descend_to_existing_byte(v60_5_byte);
        {
        let v61_2: Space = routine_9(c, &v56_16_cursor.path()[(v56_16_origin + 1)..(v56_16_origin + 2)], &v56_16_cursor.path()[(v56_16_origin + 1)..(v56_16_origin + 2)], &(v60_2), &v56_16_cursor, &(*s1));
        join_wrapped_into(&mut v60_5_write,&((v61_2).read_zipper()),&[]);
        }
        v56_16_cursor.ascend(1);
      }
      drop(v60_5_write);
      drop(v60_2);
      compose(&(v56_15),&(v60_5))
    };
    let v57_7: Space = unite(&(v57_4),&(v57_6));
    join_wrapped_into(&mut v56_16_write,&((v57_7).read_zipper()),&[]);
    }
    v56_16_cursor.ascend(1);
  }
  drop(v56_16_cursor);
  drop(v56_16_write);
  drop(v56_9);
  drop(v56_15);
  (v56_16).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v62_7: Space = singleton(&(*p1));
  let v62_8: Space = intersect(&(*CONSTANT_7),&(v62_7));
  let v62_9: Space = if has_head(&(v62_8)) { singleton(&[]) } else { Space::new() };
  drop(v62_8);
  let v62_10: Space = subtract(&(*CONSTANT_6),&(v62_9));
  drop(v62_9);
  let v62_21: Space = if (&(v62_10)).is_empty() { Space::new() } else {
    let v63_13: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v63_16: Space = if (&(v63_13)).is_empty() { Space::new() } else {
      let v64_15: Space = routine_18(c, &(*CONSTANT_9), &(*p0), &(*p2), &(*s0), &(*s1));
      compose(&(v63_13),&(v64_15))
    };
    drop(v63_13);
    let mut v63_19 = Space::new();
    let mut v63_19_write = v63_19.write_zipper();
    let mut v63_19_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v63_19_origin = v63_19_cursor.path().len();
    for v63_19_byte in v63_19_cursor.child_mask().iter() {
      v63_19_cursor.descend_to_existing_byte(v63_19_byte);
      {
      let v65_2_arg_0: &[u8] = &v63_19_cursor.path()[v63_19_origin..(v63_19_origin + 1)];
      let v65_2_arg_1: &[u8] = &(*p0);
      let v65_2_arg_2: &[u8] = &(*p2);
      let v65_2_arg_4: &Space = &(&(*s0)).make_map();
      let v65_2_arg_5: &Space = &(&(*s1)).make_map();
      let mut v65_2_more = v63_19_cursor.is_val() || next_value_within(&mut v63_19_cursor,(v63_19_origin + 1));
      while v65_2_more {
        {
        let v65_2_depth = v63_19_cursor.path().len();
        let mut v66_6_cursor = (*v65_2_arg_4).read_zipper();
        let v66_6_origin = v66_6_cursor.path().len();
        for v66_6_byte in v66_6_cursor.child_mask().iter() {
          v66_6_cursor.descend_to_existing_byte(v66_6_byte);
          {
          let v67_2: Path = concat_path(&(*v65_2_arg_1),&v66_6_cursor.path()[v66_6_origin..(v66_6_origin + 1)]);
          let v67_3: Space = routine_9(c, &(v67_2), &v63_19_cursor.path()[v63_19_origin..v65_2_depth], &(*v65_2_arg_2), &v66_6_cursor, &((*v65_2_arg_5).read_zipper()));
          drop(v67_2);
          join_wrapped_into(&mut v63_19_write,&((v67_3).read_zipper()),&[]);
          }
          v66_6_cursor.ascend(1);
        }
        drop(v66_6_cursor);
        }
        v65_2_more = next_value_within(&mut v63_19_cursor,(v63_19_origin + 1));
      }
      }
      v63_19_cursor.ascend(1);
    }
    drop(v63_19_cursor);
    drop(v63_19_write);
    let v63_20: Space = unite(&(v63_16),&(v63_19));
    compose(&(v62_10),&(v63_20))
  };
  drop(v62_10);
  let v62_23: Space = intersect(&(*CONSTANT_7),&(v62_7));
  drop(v62_7);
  let v62_24: Space = if has_head(&(v62_23)) { singleton(&[]) } else { Space::new() };
  drop(v62_23);
  let v62_803: Space = if (&(v62_24)).is_empty() { Space::new() } else {
    let v68_27: Path = concat_path(&(*p2),&(*p0));
    let v68_28: Space = routine_13(c, &(v68_27));
    let v68_29: Space = intersect(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))),&(v68_28));
    let v68_30: Space = routine_19(c, &((v68_29).read_zipper()));
    let mut v68_31 = Space::new();
    let mut v68_31_write = v68_31.write_zipper();
    let mut v68_31_cursor = (v68_30).read_zipper();
    let v68_31_origin = v68_31_cursor.path().len();
    for v68_31_byte in v68_31_cursor.child_mask().iter() {
      v68_31_cursor.descend_to_existing_byte(v68_31_byte);
      {
      let v69_2: Space = routine_20(c, &v68_31_cursor.path()[v68_31_origin..(v68_31_origin + 1)], &v68_31_cursor.path()[v68_31_origin..(v68_31_origin + 1)], &v68_31_cursor);
      join_wrapped_into(&mut v68_31_write,&((v69_2).read_zipper()),&[]);
      }
      v68_31_cursor.ascend(1);
    }
    drop(v68_31_cursor);
    drop(v68_31_write);
    let v68_32: Space = routine_14(c, &((v68_29).read_zipper()));
    let mut v68_33 = Space::new();
    let mut v68_33_write = v68_33.write_zipper();
    let mut v68_33_cursor = (v68_32).read_zipper();
    let v68_33_origin = v68_33_cursor.path().len();
    for v68_33_byte in v68_33_cursor.child_mask().iter() {
      v68_33_cursor.descend_to_existing_byte(v68_33_byte);
      {
      let v70_2: Space = routine_21(c, &v68_33_cursor.path()[v68_33_origin..(v68_33_origin + 1)], &v68_33_cursor.path()[v68_33_origin..(v68_33_origin + 1)], &v68_33_cursor);
      join_wrapped_into(&mut v68_33_write,&((v70_2).read_zipper()),&[]);
      }
      v68_33_cursor.ascend(1);
    }
    drop(v68_33_cursor);
    drop(v68_33_write);
    let v68_34: Space = subtract(&(v68_31),&(v68_33));
    let v68_36: Space = if (&(v68_34)).is_empty() { Space::new() } else {
      let v71_35: Space = singleton(&(v68_27));
      compose(&(v68_34),&(v71_35))
    };
    let v68_802: Space = drop_length_prefixes(&(v68_36));
    compose(&(v62_24),&(v68_802))
  };
  drop(v62_24);
  let v62_804: Space = unite(&(v62_21),&(v62_803));
  (v62_804).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v72_6: Space = singleton(&(*p0));
  let v72_7: Space = intersect(&(*CONSTANT_7),&(v72_6));
  let v72_8: Space = if has_head(&(v72_7)) { singleton(&[]) } else { Space::new() };
  drop(v72_7);
  let v72_9: Space = subtract(&(*CONSTANT_6),&(v72_8));
  drop(v72_8);
  let v72_14: Space = intersect(&(*CONSTANT_7),&(v72_6));
  drop(v72_6);
  let v72_15: Space = if has_head(&(v72_14)) { singleton(&[]) } else { Space::new() };
  drop(v72_14);
  let mut v72_16 = Space::new();
  let mut v72_16_write = v72_16.write_zipper();
  let mut v72_16_cursor = (*s0).read_zipper();
  let v72_16_origin = v72_16_cursor.path().len();
  for v72_16_byte in v72_16_cursor.child_mask().iter() {
    v72_16_cursor.descend_to_existing_byte(v72_16_byte);
    {
    let v73_4: Space = if (&(v72_9)).is_empty() { Space::new() } else {
      let v74_2: Path = concat_path(&(*p1),&v72_16_cursor.path()[v72_16_origin..(v72_16_origin + 1)]);
      let mut v74_3 = Space::new();
      let mut v74_3_write = v74_3.write_zipper();
      let v74_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v74_3_arg_1: &[u8] = &(v74_2);
      let v74_3_arg_2: &[u8] = &(*p2);
      let v74_3_arg_4: &Space = &(&v72_16_cursor).make_map();
      let mut v74_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v74_3_origin = v74_3_cursor.path().len();
      let mut v74_3_more = v74_3_cursor.is_val() || next_value_within(&mut v74_3_cursor,v74_3_origin);
      while v74_3_more {
        {
        let v74_3_depth = v74_3_cursor.path().len();
        let v75_5: Space = routine_10(c, &v74_3_cursor.path()[v74_3_origin..v74_3_depth], &(*v74_3_arg_1), &(*v74_3_arg_2), &((*v74_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v74_3_write,&((v75_5).read_zipper()),&[]);
        }
        v74_3_more = next_value_within(&mut v74_3_cursor,v74_3_origin);
      }
      drop(v74_3_cursor);
      drop(v74_3_write);
      compose(&(v72_9),&(v74_3))
    };
    let v73_7: Space = if (&(v72_15)).is_empty() { Space::new() } else {
      let v76_2: Path = concat_path(&(*p1),&v72_16_cursor.path()[v72_16_origin..(v72_16_origin + 1)]);
      let v76_5: Path = concat_path(&(*p2),&(v76_2));
      drop(v76_2);
      let v76_6: Space = routine_13(c, &(v76_5));
      drop(v76_5);
      compose(&(v72_15),&(v76_6))
    };
    let v73_8: Space = unite(&(v73_4),&(v73_7));
    join_wrapped_into(&mut v72_16_write,&((v73_8).read_zipper()),&[]);
    }
    v72_16_cursor.ascend(1);
  }
  drop(v72_16_cursor);
  drop(v72_16_write);
  drop(v72_9);
  drop(v72_15);
  (v72_16).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v77_5: Space = singleton(&(*p1));
  let v77_6: Space = intersect(&(*CONSTANT_7),&(v77_5));
  let v77_7: Space = if has_head(&(v77_6)) { singleton(&[]) } else { Space::new() };
  drop(v77_6);
  let v77_8: Space = subtract(&(*CONSTANT_6),&(v77_7));
  drop(v77_7);
  let v77_19: Space = if (&(v77_8)).is_empty() { Space::new() } else {
    let v78_11: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v78_14: Space = if (&(v78_11)).is_empty() { Space::new() } else {
      let v79_13: Space = routine_22(c, &(*CONSTANT_9), &(*p0), &(*s0));
      compose(&(v78_11),&(v79_13))
    };
    drop(v78_11);
    let mut v78_17 = Space::new();
    let mut v78_17_write = v78_17.write_zipper();
    let mut v78_17_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v78_17_origin = v78_17_cursor.path().len();
    for v78_17_byte in v78_17_cursor.child_mask().iter() {
      v78_17_cursor.descend_to_existing_byte(v78_17_byte);
      {
      let v80_2_arg_0: &[u8] = &v78_17_cursor.path()[v78_17_origin..(v78_17_origin + 1)];
      let v80_2_arg_1: &[u8] = &(*p0);
      let v80_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v80_2_more = v78_17_cursor.is_val() || next_value_within(&mut v78_17_cursor,(v78_17_origin + 1));
      while v80_2_more {
        {
        let v80_2_depth = v78_17_cursor.path().len();
        let mut v81_4_cursor = (*v80_2_arg_3).read_zipper();
        let v81_4_origin = v81_4_cursor.path().len();
        for v81_4_byte in v81_4_cursor.child_mask().iter() {
          v81_4_cursor.descend_to_existing_byte(v81_4_byte);
          {
          let v82_2: Path = concat_path(&(*v80_2_arg_1),&v81_4_cursor.path()[v81_4_origin..(v81_4_origin + 1)]);
          let v82_3: Space = routine_11(c, &(v82_2), &v78_17_cursor.path()[v78_17_origin..v80_2_depth], &v81_4_cursor);
          drop(v82_2);
          join_wrapped_into(&mut v78_17_write,&((v82_3).read_zipper()),&[]);
          }
          v81_4_cursor.ascend(1);
        }
        drop(v81_4_cursor);
        }
        v80_2_more = next_value_within(&mut v78_17_cursor,(v78_17_origin + 1));
      }
      }
      v78_17_cursor.ascend(1);
    }
    drop(v78_17_cursor);
    drop(v78_17_write);
    let v78_18: Space = unite(&(v78_14),&(v78_17));
    compose(&(v77_8),&(v78_18))
  };
  drop(v77_8);
  let v77_21: Space = intersect(&(*CONSTANT_7),&(v77_5));
  drop(v77_5);
  let v77_22: Space = if has_head(&(v77_21)) { singleton(&[]) } else { Space::new() };
  drop(v77_21);
  let v77_24: Space = if (&(v77_22)).is_empty() { Space::new() } else {
    let mut v83_23 = Space::new();
    let mut v83_23_write = v83_23.write_zipper();
    let mut v83_23_cursor = (*s0).read_zipper();
    let v83_23_origin = v83_23_cursor.path().len();
    for v83_23_byte in v83_23_cursor.child_mask().iter() {
      v83_23_cursor.descend_to_existing_byte(v83_23_byte);
      {
      let v84_2: Space = routine_23(c, &v83_23_cursor.path()[v83_23_origin..(v83_23_origin + 1)], &v83_23_cursor.path()[v83_23_origin..(v83_23_origin + 1)], &(*p0), &v83_23_cursor);
      join_wrapped_into(&mut v83_23_write,&((v84_2).read_zipper()),&[]);
      }
      v83_23_cursor.ascend(1);
    }
    drop(v83_23_cursor);
    drop(v83_23_write);
    compose(&(v77_22),&(v83_23))
  };
  drop(v77_22);
  let v77_25: Space = unite(&(v77_19),&(v77_24));
  (v77_25).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v85_7: Space = singleton(&(*p0));
  let v85_8: Space = intersect(&(*CONSTANT_7),&(v85_7));
  let v85_9: Space = if has_head(&(v85_8)) { singleton(&[]) } else { Space::new() };
  drop(v85_8);
  let v85_10: Space = subtract(&(*CONSTANT_6),&(v85_9));
  drop(v85_9);
  let v85_15: Space = intersect(&(*CONSTANT_7),&(v85_7));
  drop(v85_7);
  let v85_16: Space = if has_head(&(v85_15)) { singleton(&[]) } else { Space::new() };
  drop(v85_15);
  let mut v85_17 = Space::new();
  let mut v85_17_write = v85_17.write_zipper();
  let mut v85_17_cursor = (*s0).read_zipper();
  let v85_17_origin = v85_17_cursor.path().len();
  for v85_17_byte in v85_17_cursor.child_mask().iter() {
    v85_17_cursor.descend_to_existing_byte(v85_17_byte);
    {
    let v86_4: Space = if (&(v85_10)).is_empty() { Space::new() } else {
      let v87_2: Path = concat_path(&(*p1),&v85_17_cursor.path()[v85_17_origin..(v85_17_origin + 1)]);
      let mut v87_3 = Space::new();
      let mut v87_3_write = v87_3.write_zipper();
      let v87_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v87_3_arg_1: &[u8] = &(v87_2);
      let v87_3_arg_2: &[u8] = &(*p2);
      let v87_3_arg_4: &Space = &(&v85_17_cursor).make_map();
      let v87_3_arg_5: &Space = &(&(*s1)).make_map();
      let mut v87_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v87_3_origin = v87_3_cursor.path().len();
      let mut v87_3_more = v87_3_cursor.is_val() || next_value_within(&mut v87_3_cursor,v87_3_origin);
      while v87_3_more {
        {
        let v87_3_depth = v87_3_cursor.path().len();
        let v88_6: Space = routine_12(c, &v87_3_cursor.path()[v87_3_origin..v87_3_depth], &(*v87_3_arg_1), &(*v87_3_arg_2), &((*v87_3_arg_4).read_zipper()), &((*v87_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v87_3_write,&((v88_6).read_zipper()),&[]);
        }
        v87_3_more = next_value_within(&mut v87_3_cursor,v87_3_origin);
      }
      drop(v87_3_cursor);
      drop(v87_3_write);
      compose(&(v85_10),&(v87_3))
    };
    let v86_6: Space = if (&(v85_16)).is_empty() { Space::new() } else {
      let v89_2: Path = concat_path(&(*p1),&v85_17_cursor.path()[v85_17_origin..(v85_17_origin + 1)]);
      let v89_5: Space = routine_24(c, &(v89_2), &(*p2), &v85_17_cursor, &(*s1));
      drop(v89_2);
      compose(&(v85_16),&(v89_5))
    };
    let v86_7: Space = unite(&(v86_4),&(v86_6));
    join_wrapped_into(&mut v85_17_write,&((v86_7).read_zipper()),&[]);
    }
    v85_17_cursor.ascend(1);
  }
  drop(v85_17_cursor);
  drop(v85_17_write);
  drop(v85_10);
  drop(v85_16);
  (v85_17).clone()
}

#[inline(always)]
fn routine_13(c: &mut Context, p0: &[u8]) -> Space {
  let v90_1: Space = singleton(&(*p0));
  let mut v90_7 = Space::new();
  let mut v90_7_write = v90_7.write_zipper();
  let mut v90_7_cursor = (v90_1).read_zipper();
  let v90_7_origin = v90_7_cursor.path().len();
  for v90_7_byte in v90_7_cursor.child_mask().iter() {
    v90_7_cursor.descend_to_existing_byte(v90_7_byte);
    {
    let v91_2: Space = singleton(&v90_7_cursor.path()[v90_7_origin..(v90_7_origin + 1)]);
    let v91_3: Space = intersect(&(*CONSTANT_7),&(v91_2));
    let v91_4: Space = if has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
    drop(v91_3);
    let v91_5: Space = subtract(&(*CONSTANT_6),&(v91_4));
    drop(v91_4);
    let v91_8: Space = if (&(v91_5)).is_empty() { Space::new() } else {
      let mut v92_7 = Space::new();
      let mut v92_7_write = v92_7.write_zipper();
      let v92_7_arg_0: &[u8] = &(*CONSTANT_9);
      let v92_7_arg_1: &[u8] = &v90_7_cursor.path()[v90_7_origin..(v90_7_origin + 1)];
      let v92_7_arg_3: &Space = &(&v90_7_cursor).make_map();
      let mut v92_7_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&v90_7_cursor.path()[v90_7_origin..(v90_7_origin + 1)]);
      let v92_7_origin = v92_7_cursor.path().len();
      let mut v92_7_more = v92_7_cursor.is_val() || next_value_within(&mut v92_7_cursor,v92_7_origin);
      while v92_7_more {
        {
        let v92_7_depth = v92_7_cursor.path().len();
        let mut v93_4_cursor = (*v92_7_arg_3).read_zipper();
        let v93_4_origin = v93_4_cursor.path().len();
        for v93_4_byte in v93_4_cursor.child_mask().iter() {
          v93_4_cursor.descend_to_existing_byte(v93_4_byte);
          {
          let v94_2: Path = concat_path(&(*v92_7_arg_1),&v93_4_cursor.path()[v93_4_origin..(v93_4_origin + 1)]);
          let v94_3: Space = routine_11(c, &(v94_2), &v92_7_cursor.path()[v92_7_origin..v92_7_depth], &v93_4_cursor);
          drop(v94_2);
          join_wrapped_into(&mut v92_7_write,&((v94_3).read_zipper()),&[]);
          }
          v93_4_cursor.ascend(1);
        }
        drop(v93_4_cursor);
        }
        v92_7_more = next_value_within(&mut v92_7_cursor,v92_7_origin);
      }
      drop(v92_7_cursor);
      drop(v92_7_write);
      compose(&(v91_5),&(v92_7))
    };
    drop(v91_5);
    let v91_9: Space = intersect(&(*CONSTANT_7),&(v91_2));
    drop(v91_2);
    let v91_10: Space = if has_head(&(v91_9)) { singleton(&[]) } else { Space::new() };
    drop(v91_9);
    let v91_12: Space = if (&(v91_10)).is_empty() { Space::new() } else {
      let mut v95_11 = Space::new();
      let mut v95_11_write = v95_11.write_zipper();
      for v95_11_byte in v90_7_cursor.child_mask().iter() {
        v90_7_cursor.descend_to_existing_byte(v95_11_byte);
        {
        let v96_2: Space = routine_23(c, &v90_7_cursor.path()[(v90_7_origin + 1)..(v90_7_origin + 2)], &v90_7_cursor.path()[(v90_7_origin + 1)..(v90_7_origin + 2)], &v90_7_cursor.path()[v90_7_origin..(v90_7_origin + 1)], &v90_7_cursor);
        join_wrapped_into(&mut v95_11_write,&((v96_2).read_zipper()),&[]);
        }
        v90_7_cursor.ascend(1);
      }
      drop(v95_11_write);
      compose(&(v91_10),&(v95_11))
    };
    drop(v91_10);
    let v91_13: Space = unite(&(v91_8),&(v91_12));
    join_wrapped_into(&mut v90_7_write,&((v91_13).read_zipper()),&[]);
    }
    v90_7_cursor.ascend(1);
  }
  drop(v90_7_cursor);
  drop(v90_7_write);
  drop(v90_1);
  (v90_7).clone()
}

fn routine_14(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v97_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v97_2: Space = first_matching(&(*s0),&(*CONSTANT_6),false);
  let v97_3: Space = unite(&(v97_1),&(v97_2));
  drop(v97_1);
  drop(v97_2);
  let v97_8: Space = if (&(v97_3)).is_empty() { Space::new() } else {
    let v98_6: Space = if (&(v97_3)).is_empty() { Space::new() } else {
      let v99_4: Space = routine_25(c, &(*s0));
      let v99_5: Space = subtract(&(*s0),&(v99_4));
      compose(&(v97_3),&(v99_5))
    };
    let v98_7: Space = routine_26(c, &((v98_6).read_zipper()));
    compose(&(v97_3),&(v98_7))
  };
  drop(v97_3);
  let v100_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v100_2: Space = first_matching(&(*s0),&(*CONSTANT_6),false);
  let v100_3: Space = unite(&(v100_1),&(v100_2));
  drop(v100_1);
  drop(v100_2);
  let v100_6: Space = if (&(v100_3)).is_empty() { Space::new() } else {
    let v101_4: Space = routine_25(c, &(*s0));
    let v101_5: Space = subtract(&(*s0),&(v101_4));
    compose(&(v100_3),&(v101_5))
  };
  let v97_9: Space = if has_head(&(v100_6)) { singleton(&[]) } else { Space::new() };
  let v97_10: Space = first_matching(&(v100_6),&(*CONSTANT_6),false);
  let v97_11: Space = unite(&(v97_9),&(v97_10));
  let v97_13: Space = if (&(v97_11)).is_empty() { Space::new() } else {
    let v102_7: Space = routine_26(c, &((v100_6).read_zipper()));
    let v102_12: Space = routine_26(c, &((v102_7).read_zipper()));
    compose(&(v97_11),&(v102_12))
  };
  let v97_14: Space = subtract(&(*s0),&(v97_13));
  let v97_15: Space = intersect(&(v97_8),&(v97_14));
  (v97_15).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v103_5: Space = singleton(&(*p1));
  let v103_6: Space = intersect(&(*CONSTANT_7),&(v103_5));
  let v103_7: Space = if has_head(&(v103_6)) { singleton(&[]) } else { Space::new() };
  drop(v103_6);
  let v103_8: Space = subtract(&(*CONSTANT_6),&(v103_7));
  drop(v103_7);
  let v103_19: Space = if (&(v103_8)).is_empty() { Space::new() } else {
    let v104_11: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v104_14: Space = if (&(v104_11)).is_empty() { Space::new() } else {
      let v105_13: Space = routine_27(c, &(*CONSTANT_9), &(*p0), &(*s0));
      compose(&(v104_11),&(v105_13))
    };
    drop(v104_11);
    let mut v104_17 = Space::new();
    let mut v104_17_write = v104_17.write_zipper();
    let mut v104_17_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v104_17_origin = v104_17_cursor.path().len();
    for v104_17_byte in v104_17_cursor.child_mask().iter() {
      v104_17_cursor.descend_to_existing_byte(v104_17_byte);
      {
      let v106_2_arg_0: &[u8] = &v104_17_cursor.path()[v104_17_origin..(v104_17_origin + 1)];
      let v106_2_arg_1: &[u8] = &(*p0);
      let v106_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v106_2_more = v104_17_cursor.is_val() || next_value_within(&mut v104_17_cursor,(v104_17_origin + 1));
      while v106_2_more {
        {
        let v106_2_depth = v104_17_cursor.path().len();
        let mut v107_4_cursor = (*v106_2_arg_3).read_zipper();
        let v107_4_origin = v107_4_cursor.path().len();
        for v107_4_byte in v107_4_cursor.child_mask().iter() {
          v107_4_cursor.descend_to_existing_byte(v107_4_byte);
          {
          let v108_2: Path = concat_path(&(*v106_2_arg_1),&v107_4_cursor.path()[v107_4_origin..(v107_4_origin + 1)]);
          let v108_3: Space = routine_15(c, &(v108_2), &v104_17_cursor.path()[v104_17_origin..v106_2_depth], &v107_4_cursor);
          drop(v108_2);
          join_wrapped_into(&mut v104_17_write,&((v108_3).read_zipper()),&[]);
          }
          v107_4_cursor.ascend(1);
        }
        drop(v107_4_cursor);
        }
        v106_2_more = next_value_within(&mut v104_17_cursor,(v104_17_origin + 1));
      }
      }
      v104_17_cursor.ascend(1);
    }
    drop(v104_17_cursor);
    drop(v104_17_write);
    let v104_18: Space = unite(&(v104_14),&(v104_17));
    compose(&(v103_8),&(v104_18))
  };
  drop(v103_8);
  let v103_21: Space = intersect(&(*CONSTANT_7),&(v103_5));
  drop(v103_5);
  let v103_22: Space = if has_head(&(v103_21)) { singleton(&[]) } else { Space::new() };
  drop(v103_21);
  let v103_24: Space = compose(&(v103_22),&(*CONSTANT_10));
  drop(v103_22);
  let v103_25: Space = unite(&(v103_19),&(v103_24));
  drop(v103_24);
  (v103_25).clone()
}

fn routine_16(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v109_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v109_2: Space = first_matching(&(*s0),&(*CONSTANT_6),false);
  let v109_3: Space = unite(&(v109_1),&(v109_2));
  drop(v109_1);
  drop(v109_2);
  let v109_6: Space = if (&(v109_3)).is_empty() { Space::new() } else {
    let v110_4: Space = routine_25(c, &(*s0));
    let v110_5: Space = subtract(&(*s0),&(v110_4));
    compose(&(v109_3),&(v110_5))
  };
  let v109_7: Space = if has_head(&(v109_6)) { singleton(&[]) } else { Space::new() };
  let v109_8: Space = first_matching(&(v109_6),&(*CONSTANT_6),false);
  let v109_9: Space = unite(&(v109_7),&(v109_8));
  let v109_12: Space = if (&(v109_9)).is_empty() { Space::new() } else {
    let v111_10: Space = routine_26(c, &((v109_6).read_zipper()));
    let v111_11: Space = routine_26(c, &((v111_10).read_zipper()));
    compose(&(v109_9),&(v111_11))
  };
  let v109_17: Space = if (&(v109_3)).is_empty() { Space::new() } else {
    let v112_15: Space = if (&(v109_3)).is_empty() { Space::new() } else {
      let v113_13: Space = routine_26(c, &(*s0));
      let v113_14: Space = routine_26(c, &((v113_13).read_zipper()));
      compose(&(v109_3),&(v113_14))
    };
    let v112_16: Space = routine_28(c, &((v112_15).read_zipper()));
    compose(&(v109_3),&(v112_16))
  };
  drop(v109_3);
  let v109_18: Space = subtract(&(*s0),&(v109_17));
  let v109_19: Space = intersect(&(v109_12),&(v109_18));
  (v109_19).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v114_5: Space = singleton(&(*p1));
  let v114_6: Space = intersect(&(*CONSTANT_7),&(v114_5));
  let v114_7: Space = if has_head(&(v114_6)) { singleton(&[]) } else { Space::new() };
  drop(v114_6);
  let v114_8: Space = subtract(&(*CONSTANT_6),&(v114_7));
  drop(v114_7);
  let v114_19: Space = if (&(v114_8)).is_empty() { Space::new() } else {
    let v115_11: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v115_14: Space = if (&(v115_11)).is_empty() { Space::new() } else {
      let v116_13: Space = routine_29(c, &(*CONSTANT_9), &(*p0), &(*s0));
      compose(&(v115_11),&(v116_13))
    };
    drop(v115_11);
    let mut v115_17 = Space::new();
    let mut v115_17_write = v115_17.write_zipper();
    let mut v115_17_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v115_17_origin = v115_17_cursor.path().len();
    for v115_17_byte in v115_17_cursor.child_mask().iter() {
      v115_17_cursor.descend_to_existing_byte(v115_17_byte);
      {
      let v117_2_arg_0: &[u8] = &v115_17_cursor.path()[v115_17_origin..(v115_17_origin + 1)];
      let v117_2_arg_1: &[u8] = &(*p0);
      let v117_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v117_2_more = v115_17_cursor.is_val() || next_value_within(&mut v115_17_cursor,(v115_17_origin + 1));
      while v117_2_more {
        {
        let v117_2_depth = v115_17_cursor.path().len();
        let mut v118_4_cursor = (*v117_2_arg_3).read_zipper();
        let v118_4_origin = v118_4_cursor.path().len();
        for v118_4_byte in v118_4_cursor.child_mask().iter() {
          v118_4_cursor.descend_to_existing_byte(v118_4_byte);
          {
          let v119_2: Path = concat_path(&(*v117_2_arg_1),&v118_4_cursor.path()[v118_4_origin..(v118_4_origin + 1)]);
          let v119_3: Space = routine_17(c, &(v119_2), &v115_17_cursor.path()[v115_17_origin..v117_2_depth], &v118_4_cursor);
          drop(v119_2);
          join_wrapped_into(&mut v115_17_write,&((v119_3).read_zipper()),&[]);
          }
          v118_4_cursor.ascend(1);
        }
        drop(v118_4_cursor);
        }
        v117_2_more = next_value_within(&mut v115_17_cursor,(v115_17_origin + 1));
      }
      }
      v115_17_cursor.ascend(1);
    }
    drop(v115_17_cursor);
    drop(v115_17_write);
    let v115_18: Space = unite(&(v115_14),&(v115_17));
    compose(&(v114_8),&(v115_18))
  };
  drop(v114_8);
  let v114_21: Space = intersect(&(*CONSTANT_7),&(v114_5));
  drop(v114_5);
  let v114_22: Space = if has_head(&(v114_21)) { singleton(&[]) } else { Space::new() };
  drop(v114_21);
  let v114_24: Space = compose(&(v114_22),&(*CONSTANT_10));
  drop(v114_22);
  let v114_25: Space = unite(&(v114_19),&(v114_24));
  drop(v114_24);
  (v114_25).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v120_7: Space = singleton(&(*p0));
  let v120_8: Space = intersect(&(*CONSTANT_7),&(v120_7));
  let v120_9: Space = if has_head(&(v120_8)) { singleton(&[]) } else { Space::new() };
  drop(v120_8);
  let v120_10: Space = subtract(&(*CONSTANT_6),&(v120_9));
  drop(v120_9);
  let v120_15: Space = intersect(&(*CONSTANT_7),&(v120_7));
  drop(v120_7);
  let v120_16: Space = if has_head(&(v120_15)) { singleton(&[]) } else { Space::new() };
  drop(v120_15);
  let mut v120_17 = Space::new();
  let mut v120_17_write = v120_17.write_zipper();
  let mut v120_17_cursor = (*s0).read_zipper();
  let v120_17_origin = v120_17_cursor.path().len();
  for v120_17_byte in v120_17_cursor.child_mask().iter() {
    v120_17_cursor.descend_to_existing_byte(v120_17_byte);
    {
    let v121_4: Space = if (&(v120_10)).is_empty() { Space::new() } else {
      let v122_2: Path = concat_path(&(*p1),&v120_17_cursor.path()[v120_17_origin..(v120_17_origin + 1)]);
      let mut v122_3 = Space::new();
      let mut v122_3_write = v122_3.write_zipper();
      let v122_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v122_3_arg_1: &[u8] = &(v122_2);
      let v122_3_arg_2: &[u8] = &(*p2);
      let v122_3_arg_4: &Space = &(&v120_17_cursor).make_map();
      let v122_3_arg_5: &Space = &(&(*s1)).make_map();
      let mut v122_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v122_3_origin = v122_3_cursor.path().len();
      let mut v122_3_more = v122_3_cursor.is_val() || next_value_within(&mut v122_3_cursor,v122_3_origin);
      while v122_3_more {
        {
        let v122_3_depth = v122_3_cursor.path().len();
        let v123_6: Space = routine_18(c, &v122_3_cursor.path()[v122_3_origin..v122_3_depth], &(*v122_3_arg_1), &(*v122_3_arg_2), &((*v122_3_arg_4).read_zipper()), &((*v122_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v122_3_write,&((v123_6).read_zipper()),&[]);
        }
        v122_3_more = next_value_within(&mut v122_3_cursor,v122_3_origin);
      }
      drop(v122_3_cursor);
      drop(v122_3_write);
      compose(&(v120_10),&(v122_3))
    };
    let v121_6: Space = if (&(v120_16)).is_empty() { Space::new() } else {
      let v124_2: Path = concat_path(&(*p1),&v120_17_cursor.path()[v120_17_origin..(v120_17_origin + 1)]);
      let v124_5: Space = routine_30(c, &(v124_2), &(*p2), &v120_17_cursor, &(*s1));
      drop(v124_2);
      compose(&(v120_16),&(v124_5))
    };
    let v121_7: Space = unite(&(v121_4),&(v121_6));
    join_wrapped_into(&mut v120_17_write,&((v121_7).read_zipper()),&[]);
    }
    v120_17_cursor.ascend(1);
  }
  drop(v120_17_cursor);
  drop(v120_17_write);
  drop(v120_10);
  drop(v120_16);
  (v120_17).clone()
}

fn routine_19(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v125_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v125_2: Space = first_matching(&(*s0),&(*CONSTANT_6),false);
  let v125_3: Space = unite(&(v125_1),&(v125_2));
  drop(v125_1);
  drop(v125_2);
  let v125_8: Space = if (&(v125_3)).is_empty() { Space::new() } else {
    let v126_6: Space = if (&(v125_3)).is_empty() { Space::new() } else {
      let v127_4: Space = routine_25(c, &(*s0));
      let v127_5: Space = subtract(&(*s0),&(v127_4));
      compose(&(v125_3),&(v127_5))
    };
    let v126_7: Space = routine_26(c, &((v126_6).read_zipper()));
    compose(&(v125_3),&(v126_7))
  };
  drop(v125_3);
  let v125_9: Space = subtract(&(*s0),&(v125_8));
  let v128_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v128_2: Space = first_matching(&(*s0),&(*CONSTANT_6),false);
  let v128_3: Space = unite(&(v128_1),&(v128_2));
  drop(v128_1);
  drop(v128_2);
  let v128_6: Space = if (&(v128_3)).is_empty() { Space::new() } else {
    let v129_4: Space = routine_25(c, &(*s0));
    let v129_5: Space = subtract(&(*s0),&(v129_4));
    compose(&(v128_3),&(v129_5))
  };
  let v125_10: Space = intersect(&(v128_6),&(v125_9));
  (v125_10).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v130_5: Space = singleton(&(*p1));
  let v130_6: Space = intersect(&(*CONSTANT_7),&(v130_5));
  let v130_7: Space = if has_head(&(v130_6)) { singleton(&[]) } else { Space::new() };
  drop(v130_6);
  let v130_8: Space = subtract(&(*CONSTANT_6),&(v130_7));
  drop(v130_7);
  let v130_19: Space = if (&(v130_8)).is_empty() { Space::new() } else {
    let v131_11: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v131_14: Space = if (&(v131_11)).is_empty() { Space::new() } else {
      let v132_13: Space = routine_31(c, &(*CONSTANT_9), &(*p0), &(*s0));
      compose(&(v131_11),&(v132_13))
    };
    drop(v131_11);
    let mut v131_17 = Space::new();
    let mut v131_17_write = v131_17.write_zipper();
    let mut v131_17_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v131_17_origin = v131_17_cursor.path().len();
    for v131_17_byte in v131_17_cursor.child_mask().iter() {
      v131_17_cursor.descend_to_existing_byte(v131_17_byte);
      {
      let v133_2_arg_0: &[u8] = &v131_17_cursor.path()[v131_17_origin..(v131_17_origin + 1)];
      let v133_2_arg_1: &[u8] = &(*p0);
      let v133_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v133_2_more = v131_17_cursor.is_val() || next_value_within(&mut v131_17_cursor,(v131_17_origin + 1));
      while v133_2_more {
        {
        let v133_2_depth = v131_17_cursor.path().len();
        let mut v134_4_cursor = (*v133_2_arg_3).read_zipper();
        let v134_4_origin = v134_4_cursor.path().len();
        for v134_4_byte in v134_4_cursor.child_mask().iter() {
          v134_4_cursor.descend_to_existing_byte(v134_4_byte);
          {
          let v135_2: Path = concat_path(&(*v133_2_arg_1),&v134_4_cursor.path()[v134_4_origin..(v134_4_origin + 1)]);
          let v135_3: Space = routine_20(c, &(v135_2), &v131_17_cursor.path()[v131_17_origin..v133_2_depth], &v134_4_cursor);
          drop(v135_2);
          join_wrapped_into(&mut v131_17_write,&((v135_3).read_zipper()),&[]);
          }
          v134_4_cursor.ascend(1);
        }
        drop(v134_4_cursor);
        }
        v133_2_more = next_value_within(&mut v131_17_cursor,(v131_17_origin + 1));
      }
      }
      v131_17_cursor.ascend(1);
    }
    drop(v131_17_cursor);
    drop(v131_17_write);
    let v131_18: Space = unite(&(v131_14),&(v131_17));
    compose(&(v130_8),&(v131_18))
  };
  drop(v130_8);
  let v130_21: Space = intersect(&(*CONSTANT_7),&(v130_5));
  drop(v130_5);
  let v130_22: Space = if has_head(&(v130_21)) { singleton(&[]) } else { Space::new() };
  drop(v130_21);
  let v130_24: Space = compose(&(v130_22),&(*CONSTANT_10));
  drop(v130_22);
  let v130_25: Space = unite(&(v130_19),&(v130_24));
  drop(v130_24);
  (v130_25).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v136_5: Space = singleton(&(*p1));
  let v136_6: Space = intersect(&(*CONSTANT_7),&(v136_5));
  let v136_7: Space = if has_head(&(v136_6)) { singleton(&[]) } else { Space::new() };
  drop(v136_6);
  let v136_8: Space = subtract(&(*CONSTANT_6),&(v136_7));
  drop(v136_7);
  let v136_19: Space = if (&(v136_8)).is_empty() { Space::new() } else {
    let v137_11: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v137_14: Space = if (&(v137_11)).is_empty() { Space::new() } else {
      let v138_13: Space = routine_32(c, &(*CONSTANT_9), &(*p0), &(*s0));
      compose(&(v137_11),&(v138_13))
    };
    drop(v137_11);
    let mut v137_17 = Space::new();
    let mut v137_17_write = v137_17.write_zipper();
    let mut v137_17_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v137_17_origin = v137_17_cursor.path().len();
    for v137_17_byte in v137_17_cursor.child_mask().iter() {
      v137_17_cursor.descend_to_existing_byte(v137_17_byte);
      {
      let v139_2_arg_0: &[u8] = &v137_17_cursor.path()[v137_17_origin..(v137_17_origin + 1)];
      let v139_2_arg_1: &[u8] = &(*p0);
      let v139_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v139_2_more = v137_17_cursor.is_val() || next_value_within(&mut v137_17_cursor,(v137_17_origin + 1));
      while v139_2_more {
        {
        let v139_2_depth = v137_17_cursor.path().len();
        let mut v140_4_cursor = (*v139_2_arg_3).read_zipper();
        let v140_4_origin = v140_4_cursor.path().len();
        for v140_4_byte in v140_4_cursor.child_mask().iter() {
          v140_4_cursor.descend_to_existing_byte(v140_4_byte);
          {
          let v141_2: Path = concat_path(&(*v139_2_arg_1),&v140_4_cursor.path()[v140_4_origin..(v140_4_origin + 1)]);
          let v141_3: Space = routine_21(c, &(v141_2), &v137_17_cursor.path()[v137_17_origin..v139_2_depth], &v140_4_cursor);
          drop(v141_2);
          join_wrapped_into(&mut v137_17_write,&((v141_3).read_zipper()),&[]);
          }
          v140_4_cursor.ascend(1);
        }
        drop(v140_4_cursor);
        }
        v139_2_more = next_value_within(&mut v137_17_cursor,(v137_17_origin + 1));
      }
      }
      v137_17_cursor.ascend(1);
    }
    drop(v137_17_cursor);
    drop(v137_17_write);
    let v137_18: Space = unite(&(v137_14),&(v137_17));
    compose(&(v136_8),&(v137_18))
  };
  drop(v136_8);
  let v136_21: Space = intersect(&(*CONSTANT_7),&(v136_5));
  drop(v136_5);
  let v136_22: Space = if has_head(&(v136_21)) { singleton(&[]) } else { Space::new() };
  drop(v136_21);
  let v136_24: Space = compose(&(v136_22),&(*CONSTANT_10));
  drop(v136_22);
  let v136_25: Space = unite(&(v136_19),&(v136_24));
  drop(v136_24);
  (v136_25).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v142_5: Space = singleton(&(*p0));
  let v142_6: Space = intersect(&(*CONSTANT_7),&(v142_5));
  let v142_7: Space = if has_head(&(v142_6)) { singleton(&[]) } else { Space::new() };
  drop(v142_6);
  let v142_8: Space = subtract(&(*CONSTANT_6),&(v142_7));
  drop(v142_7);
  let v142_13: Space = intersect(&(*CONSTANT_7),&(v142_5));
  drop(v142_5);
  let v142_14: Space = if has_head(&(v142_13)) { singleton(&[]) } else { Space::new() };
  drop(v142_13);
  let mut v142_15 = Space::new();
  let mut v142_15_write = v142_15.write_zipper();
  let mut v142_15_cursor = (*s0).read_zipper();
  let v142_15_origin = v142_15_cursor.path().len();
  for v142_15_byte in v142_15_cursor.child_mask().iter() {
    v142_15_cursor.descend_to_existing_byte(v142_15_byte);
    {
    let v143_4: Space = if (&(v142_8)).is_empty() { Space::new() } else {
      let v144_2: Path = concat_path(&(*p1),&v142_15_cursor.path()[v142_15_origin..(v142_15_origin + 1)]);
      let mut v144_3 = Space::new();
      let mut v144_3_write = v144_3.write_zipper();
      let v144_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v144_3_arg_1: &[u8] = &(v144_2);
      let v144_3_arg_3: &Space = &(&v142_15_cursor).make_map();
      let mut v144_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v144_3_origin = v144_3_cursor.path().len();
      let mut v144_3_more = v144_3_cursor.is_val() || next_value_within(&mut v144_3_cursor,v144_3_origin);
      while v144_3_more {
        {
        let v144_3_depth = v144_3_cursor.path().len();
        let v145_4: Space = routine_22(c, &v144_3_cursor.path()[v144_3_origin..v144_3_depth], &(*v144_3_arg_1), &((*v144_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v144_3_write,&((v145_4).read_zipper()),&[]);
        }
        v144_3_more = next_value_within(&mut v144_3_cursor,v144_3_origin);
      }
      drop(v144_3_cursor);
      drop(v144_3_write);
      compose(&(v142_8),&(v144_3))
    };
    let v143_6: Space = if (&(v142_14)).is_empty() { Space::new() } else {
      let v146_2: Path = concat_path(&(*p1),&v142_15_cursor.path()[v142_15_origin..(v142_15_origin + 1)]);
      let mut v146_5 = Space::new();
      let mut v146_5_write = v146_5.write_zipper();
      for v146_5_byte in v142_15_cursor.child_mask().iter() {
        v142_15_cursor.descend_to_existing_byte(v146_5_byte);
        {
        let v147_2: Space = routine_23(c, &v142_15_cursor.path()[(v142_15_origin + 1)..(v142_15_origin + 2)], &v142_15_cursor.path()[(v142_15_origin + 1)..(v142_15_origin + 2)], &(v146_2), &v142_15_cursor);
        join_wrapped_into(&mut v146_5_write,&((v147_2).read_zipper()),&[]);
        }
        v142_15_cursor.ascend(1);
      }
      drop(v146_5_write);
      drop(v146_2);
      compose(&(v142_14),&(v146_5))
    };
    let v143_7: Space = unite(&(v143_4),&(v143_6));
    join_wrapped_into(&mut v142_15_write,&((v143_7).read_zipper()),&[]);
    }
    v142_15_cursor.ascend(1);
  }
  drop(v142_15_cursor);
  drop(v142_15_write);
  drop(v142_8);
  drop(v142_14);
  (v142_15).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v148_6: Space = singleton(&(*p1));
  let v148_7: Space = intersect(&(*CONSTANT_7),&(v148_6));
  let v148_8: Space = if has_head(&(v148_7)) { singleton(&[]) } else { Space::new() };
  drop(v148_7);
  let v148_9: Space = subtract(&(*CONSTANT_6),&(v148_8));
  drop(v148_8);
  let v148_20: Space = if (&(v148_9)).is_empty() { Space::new() } else {
    let v149_12: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v149_15: Space = if (&(v149_12)).is_empty() { Space::new() } else {
      let v150_14: Space = routine_33(c, &(*CONSTANT_9), &(*p0), &(*p2), &(*s0));
      compose(&(v149_12),&(v150_14))
    };
    drop(v149_12);
    let mut v149_18 = Space::new();
    let mut v149_18_write = v149_18.write_zipper();
    let mut v149_18_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v149_18_origin = v149_18_cursor.path().len();
    for v149_18_byte in v149_18_cursor.child_mask().iter() {
      v149_18_cursor.descend_to_existing_byte(v149_18_byte);
      {
      let v151_2_arg_0: &[u8] = &v149_18_cursor.path()[v149_18_origin..(v149_18_origin + 1)];
      let v151_2_arg_1: &[u8] = &(*p0);
      let v151_2_arg_2: &[u8] = &(*p2);
      let v151_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v151_2_more = v149_18_cursor.is_val() || next_value_within(&mut v149_18_cursor,(v149_18_origin + 1));
      while v151_2_more {
        {
        let v151_2_depth = v149_18_cursor.path().len();
        let mut v152_5_cursor = (*v151_2_arg_4).read_zipper();
        let v152_5_origin = v152_5_cursor.path().len();
        for v152_5_byte in v152_5_cursor.child_mask().iter() {
          v152_5_cursor.descend_to_existing_byte(v152_5_byte);
          {
          let v153_2: Path = concat_path(&(*v151_2_arg_1),&v152_5_cursor.path()[v152_5_origin..(v152_5_origin + 1)]);
          let v153_3: Space = routine_23(c, &(v153_2), &v149_18_cursor.path()[v149_18_origin..v151_2_depth], &(*v151_2_arg_2), &v152_5_cursor);
          drop(v153_2);
          join_wrapped_into(&mut v149_18_write,&((v153_3).read_zipper()),&[]);
          }
          v152_5_cursor.ascend(1);
        }
        drop(v152_5_cursor);
        }
        v151_2_more = next_value_within(&mut v149_18_cursor,(v149_18_origin + 1));
      }
      }
      v149_18_cursor.ascend(1);
    }
    drop(v149_18_cursor);
    drop(v149_18_write);
    let v149_19: Space = unite(&(v149_15),&(v149_18));
    compose(&(v148_9),&(v149_19))
  };
  drop(v148_9);
  let v148_22: Space = intersect(&(*CONSTANT_7),&(v148_6));
  drop(v148_6);
  let v148_23: Space = if has_head(&(v148_22)) { singleton(&[]) } else { Space::new() };
  drop(v148_22);
  let v148_32: Space = if (&(v148_23)).is_empty() { Space::new() } else {
    let v154_28: Space = if (&(descend_cursor((*CONSTANT_11).read_zipper(),&(*p2)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*CONSTANT_11).read_zipper(),&(*p2))),&(descend_cursor((*CONSTANT_11).read_zipper(),&(*p0))))
    };
    let v154_29: Path = concat_path(&(*p2),&(*p0));
    let v154_30: Space = singleton(&(v154_29));
    drop(v154_29);
    let v154_31: Space = subtract(&(v154_28),&(v154_30));
    drop(v154_28);
    drop(v154_30);
    compose(&(v148_23),&(v154_31))
  };
  drop(v148_23);
  let v148_33: Space = unite(&(v148_20),&(v148_32));
  drop(v148_32);
  (v148_33).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v156_6: Path = concat_path(&(*p1),&(*p0));
  let v156_7: Space = singleton(&(v156_6));
  drop(v156_6);
  let mut v156_8 = Space::new();
  let mut v156_8_write = v156_8.write_zipper();
  let mut v156_8_cursor = (v156_7).read_zipper();
  let v156_8_origin = v156_8_cursor.path().len();
  for v156_8_byte in v156_8_cursor.child_mask().iter() {
    v156_8_cursor.descend_to_existing_byte(v156_8_byte);
    {
    let v157_2: Space = routine_11(c, &v156_8_cursor.path()[v156_8_origin..(v156_8_origin + 1)], &v156_8_cursor.path()[v156_8_origin..(v156_8_origin + 1)], &v156_8_cursor);
    join_wrapped_into(&mut v156_8_write,&((v157_2).read_zipper()),&[]);
    }
    v156_8_cursor.ascend(1);
  }
  drop(v156_8_cursor);
  drop(v156_8_write);
  let v156_9: Space = intersect(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))),&(v156_8));
  let v156_10: Space = routine_26(c, &((v156_9).read_zipper()));
  let v156_11: Space = routine_28(c, &((v156_10).read_zipper()));
  let v156_12: Space = subtract(&(v156_9),&(v156_11));
  let v156_13: Space = routine_28(c, &((v156_9).read_zipper()));
  let v156_14: Space = intersect(&(v156_12),&(v156_13));
  let mut v156_20 = Space::new();
  let mut v156_20_write = v156_20.write_zipper();
  let mut v156_20_cursor = (v156_14).read_zipper();
  let v156_20_origin = v156_20_cursor.path().len();
  for v156_20_byte in v156_20_cursor.child_mask().iter() {
    v156_20_cursor.descend_to_existing_byte(v156_20_byte);
    {
    let v158_2: Space = singleton(&v156_20_cursor.path()[v156_20_origin..(v156_20_origin + 1)]);
    let v158_3: Space = intersect(&(*CONSTANT_7),&(v158_2));
    let v158_4: Space = if has_head(&(v158_3)) { singleton(&[]) } else { Space::new() };
    drop(v158_3);
    let v158_5: Space = subtract(&(*CONSTANT_6),&(v158_4));
    drop(v158_4);
    let v158_8: Space = if (&(v158_5)).is_empty() { Space::new() } else {
      let mut v159_7 = Space::new();
      let mut v159_7_write = v159_7.write_zipper();
      let v159_7_arg_0: &[u8] = &(*CONSTANT_9);
      let v159_7_arg_1: &[u8] = &v156_20_cursor.path()[v156_20_origin..(v156_20_origin + 1)];
      let v159_7_arg_3: &Space = &(&v156_20_cursor).make_map();
      let mut v159_7_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&v156_20_cursor.path()[v156_20_origin..(v156_20_origin + 1)]);
      let v159_7_origin = v159_7_cursor.path().len();
      let mut v159_7_more = v159_7_cursor.is_val() || next_value_within(&mut v159_7_cursor,v159_7_origin);
      while v159_7_more {
        {
        let v159_7_depth = v159_7_cursor.path().len();
        let mut v160_4_cursor = (*v159_7_arg_3).read_zipper();
        let v160_4_origin = v160_4_cursor.path().len();
        for v160_4_byte in v160_4_cursor.child_mask().iter() {
          v160_4_cursor.descend_to_existing_byte(v160_4_byte);
          {
          let v161_2: Path = concat_path(&(*v159_7_arg_1),&v160_4_cursor.path()[v160_4_origin..(v160_4_origin + 1)]);
          let v161_3: Space = routine_15(c, &(v161_2), &v159_7_cursor.path()[v159_7_origin..v159_7_depth], &v160_4_cursor);
          drop(v161_2);
          join_wrapped_into(&mut v159_7_write,&((v161_3).read_zipper()),&[]);
          }
          v160_4_cursor.ascend(1);
        }
        drop(v160_4_cursor);
        }
        v159_7_more = next_value_within(&mut v159_7_cursor,v159_7_origin);
      }
      drop(v159_7_cursor);
      drop(v159_7_write);
      compose(&(v158_5),&(v159_7))
    };
    drop(v158_5);
    let v158_9: Space = intersect(&(*CONSTANT_7),&(v158_2));
    drop(v158_2);
    let v158_10: Space = if has_head(&(v158_9)) { singleton(&[]) } else { Space::new() };
    drop(v158_9);
    let v158_12: Space = if (&(v158_10)).is_empty() { Space::new() } else {
      let v162_11: Space = routine_34(c, &v156_20_cursor.path()[v156_20_origin..(v156_20_origin + 1)], &v156_20_cursor);
      compose(&(v158_10),&(v162_11))
    };
    drop(v158_10);
    let v158_13: Space = unite(&(v158_8),&(v158_12));
    join_wrapped_into(&mut v156_20_write,&((v158_13).read_zipper()),&[]);
    }
    v156_20_cursor.ascend(1);
  }
  drop(v156_20_cursor);
  drop(v156_20_write);
  let v156_21: Space = routine_35(c, &((v156_9).read_zipper()));
  let v156_22: Space = subtract(&(v156_9),&(v156_21));
  let v156_23: Space = intersect(&(v156_22),&(v156_11));
  let mut v156_28 = Space::new();
  let mut v156_28_write = v156_28.write_zipper();
  let mut v156_28_cursor = (v156_23).read_zipper();
  let v156_28_origin = v156_28_cursor.path().len();
  for v156_28_byte in v156_28_cursor.child_mask().iter() {
    v156_28_cursor.descend_to_existing_byte(v156_28_byte);
    {
    let v163_2: Space = singleton(&v156_28_cursor.path()[v156_28_origin..(v156_28_origin + 1)]);
    let v163_3: Space = intersect(&(*CONSTANT_7),&(v163_2));
    let v163_4: Space = if has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
    drop(v163_3);
    let v163_5: Space = subtract(&(*CONSTANT_6),&(v163_4));
    drop(v163_4);
    let v163_8: Space = if (&(v163_5)).is_empty() { Space::new() } else {
      let mut v164_7 = Space::new();
      let mut v164_7_write = v164_7.write_zipper();
      let v164_7_arg_0: &[u8] = &(*CONSTANT_9);
      let v164_7_arg_1: &[u8] = &v156_28_cursor.path()[v156_28_origin..(v156_28_origin + 1)];
      let v164_7_arg_3: &Space = &(&v156_28_cursor).make_map();
      let mut v164_7_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&v156_28_cursor.path()[v156_28_origin..(v156_28_origin + 1)]);
      let v164_7_origin = v164_7_cursor.path().len();
      let mut v164_7_more = v164_7_cursor.is_val() || next_value_within(&mut v164_7_cursor,v164_7_origin);
      while v164_7_more {
        {
        let v164_7_depth = v164_7_cursor.path().len();
        let mut v165_4_cursor = (*v164_7_arg_3).read_zipper();
        let v165_4_origin = v165_4_cursor.path().len();
        for v165_4_byte in v165_4_cursor.child_mask().iter() {
          v165_4_cursor.descend_to_existing_byte(v165_4_byte);
          {
          let v166_2: Path = concat_path(&(*v164_7_arg_1),&v165_4_cursor.path()[v165_4_origin..(v165_4_origin + 1)]);
          let v166_3: Space = routine_17(c, &(v166_2), &v164_7_cursor.path()[v164_7_origin..v164_7_depth], &v165_4_cursor);
          drop(v166_2);
          join_wrapped_into(&mut v164_7_write,&((v166_3).read_zipper()),&[]);
          }
          v165_4_cursor.ascend(1);
        }
        drop(v165_4_cursor);
        }
        v164_7_more = next_value_within(&mut v164_7_cursor,v164_7_origin);
      }
      drop(v164_7_cursor);
      drop(v164_7_write);
      compose(&(v163_5),&(v164_7))
    };
    drop(v163_5);
    let v163_9: Space = intersect(&(*CONSTANT_7),&(v163_2));
    drop(v163_2);
    let v163_10: Space = if has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
    drop(v163_9);
    let v163_12: Space = if (&(v163_10)).is_empty() { Space::new() } else {
      let v167_11: Space = routine_36(c, &v156_28_cursor.path()[v156_28_origin..(v156_28_origin + 1)], &v156_28_cursor);
      compose(&(v163_10),&(v167_11))
    };
    drop(v163_10);
    let v163_13: Space = unite(&(v163_8),&(v163_12));
    join_wrapped_into(&mut v156_28_write,&((v163_13).read_zipper()),&[]);
    }
    v156_28_cursor.ascend(1);
  }
  drop(v156_28_cursor);
  drop(v156_28_write);
  let v156_29: Space = subtract(&(v156_20),&(v156_28));
  let v156_30: Space = if (&(v156_29)).is_empty() { Space::new() } else {
    compose(&(v156_29),&(v156_7))
  };
  drop(v156_7);
  let v156_796: Space = drop_length_prefixes(&(v156_30));
  (v156_796).clone()
}

fn routine_25(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v169_2: Space = first_matching(&(*s0),&(*CONSTANT_6),false);
  let v169_3: Space = intersect(&(*CONSTANT_6),&(v169_2));
  let v169_4: Space = if has_head(&(v169_2)) { singleton(&[]) } else { Space::new() };
  let v169_5: Space = unite(&(v169_3),&(v169_4));
  drop(v169_3);
  let v169_7: Space = compose(&(v169_5),&(*CONSTANT_6));
  drop(v169_5);
  let v169_9: Space = subtract(&(*CONSTANT_6),&(v169_2));
  drop(v169_2);
  let v169_10: Space = subtract(&(v169_9),&(v169_4));
  drop(v169_4);
  drop(v169_9);
  let v169_18: Space = if (&(v169_10)).is_empty() { Space::new() } else {
    let v170_11: Space = first_length_prefixed(&(*s0));
    let v170_12: Space = first_matching(&(v170_11),&(*CONSTANT_6),false);
    let v170_15: Space = if (&(v170_12)).is_empty() { Space::new() } else {
      let v171_14: Space = routine_37(c, &(*CONSTANT_9), &(*s0));
      compose(&(v170_12),&(v171_14))
    };
    drop(v170_12);
    let mut v170_16 = Space::new();
    let mut v170_16_write = v170_16.write_zipper();
    let mut v170_16_cursor = (v170_11).read_zipper();
    let v170_16_origin = v170_16_cursor.path().len();
    for v170_16_byte in v170_16_cursor.child_mask().iter() {
      v170_16_cursor.descend_to_existing_byte(v170_16_byte);
      {
      let v172_2_arg_0: &[u8] = &v170_16_cursor.path()[v170_16_origin..(v170_16_origin + 1)];
      let v172_2_arg_2: &Space = &(&(*s0)).make_map();
      let mut v172_2_more = v170_16_cursor.is_val() || next_value_within(&mut v170_16_cursor,(v170_16_origin + 1));
      while v172_2_more {
        {
        let v172_2_depth = v170_16_cursor.path().len();
        let v173_4: Space = routine_25(c, &(descend_cursor((*v172_2_arg_2).read_zipper(),&v170_16_cursor.path()[v170_16_origin..v172_2_depth])));
        join_wrapped_into(&mut v170_16_write,&((v173_4).read_zipper()),&v170_16_cursor.path()[v170_16_origin..v172_2_depth]);
        }
        v172_2_more = next_value_within(&mut v170_16_cursor,(v170_16_origin + 1));
      }
      }
      v170_16_cursor.ascend(1);
    }
    drop(v170_16_cursor);
    drop(v170_16_write);
    drop(v170_11);
    let v170_17: Space = unite(&(v170_15),&(v170_16));
    compose(&(v169_10),&(v170_17))
  };
  drop(v169_10);
  let v169_19: Space = unite(&(v169_7),&(v169_18));
  drop(v169_7);
  (v169_19).clone()
}

fn routine_26(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v174_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v174_2: Space = first_matching(&(*s0),&(*CONSTANT_6),false);
  let v174_3: Space = unite(&(v174_1),&(v174_2));
  drop(v174_1);
  let v174_19: Space = if (&(v174_3)).is_empty() { Space::new() } else {
    let v175_5: Space = intersect(&(*CONSTANT_6),&(v174_2));
    let v175_6: Space = if has_head(&(v174_2)) { singleton(&[]) } else { Space::new() };
    let v175_7: Space = unite(&(v175_5),&(v175_6));
    drop(v175_5);
    let v175_9: Space = compose(&(v175_7),&(*CONSTANT_6));
    drop(v175_7);
    let v175_10: Space = subtract(&(*s0),&(v175_9));
    drop(v175_9);
    let v175_12: Space = subtract(&(*CONSTANT_6),&(v174_2));
    let v175_13: Space = subtract(&(v175_12),&(v175_6));
    drop(v175_6);
    drop(v175_12);
    let v175_17: Space = if (&(v175_13)).is_empty() { Space::new() } else {
      let v176_15: Space = first_length_prefixed(&(*s0));
      let mut v176_16 = Space::new();
      let mut v176_16_write = v176_16.write_zipper();
      let v176_16_arg_0: &[u8] = &(*CONSTANT_9);
      let v176_16_arg_2: &Space = &(&(*s0)).make_map();
      let mut v176_16_cursor = (v176_15).read_zipper();
      let v176_16_origin = v176_16_cursor.path().len();
      let mut v176_16_more = v176_16_cursor.is_val() || next_value_within(&mut v176_16_cursor,v176_16_origin);
      while v176_16_more {
        {
        let v176_16_depth = v176_16_cursor.path().len();
        let v177_4: Space = routine_25(c, &(descend_cursor((*v176_16_arg_2).read_zipper(),&v176_16_cursor.path()[v176_16_origin..v176_16_depth])));
        join_wrapped_into(&mut v176_16_write,&((v177_4).read_zipper()),&v176_16_cursor.path()[v176_16_origin..v176_16_depth]);
        }
        v176_16_more = next_value_within(&mut v176_16_cursor,v176_16_origin);
      }
      drop(v176_16_cursor);
      drop(v176_16_write);
      drop(v176_15);
      compose(&(v175_13),&(v176_16))
    };
    drop(v175_13);
    let v175_18: Space = subtract(&(v175_10),&(v175_17));
    drop(v175_10);
    compose(&(v174_3),&(v175_18))
  };
  drop(v174_3);
  (v174_19).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v178_5: Space = singleton(&(*p0));
  let v178_6: Space = intersect(&(*CONSTANT_7),&(v178_5));
  let v178_7: Space = if has_head(&(v178_6)) { singleton(&[]) } else { Space::new() };
  drop(v178_6);
  let v178_8: Space = subtract(&(*CONSTANT_6),&(v178_7));
  drop(v178_7);
  let v178_13: Space = intersect(&(*CONSTANT_7),&(v178_5));
  drop(v178_5);
  let v178_14: Space = if has_head(&(v178_13)) { singleton(&[]) } else { Space::new() };
  drop(v178_13);
  let v178_16: Space = compose(&(v178_14),&(*CONSTANT_10));
  drop(v178_14);
  let mut v178_17 = Space::new();
  let mut v178_17_write = v178_17.write_zipper();
  let mut v178_17_cursor = (*s0).read_zipper();
  let v178_17_origin = v178_17_cursor.path().len();
  for v178_17_byte in v178_17_cursor.child_mask().iter() {
    v178_17_cursor.descend_to_existing_byte(v178_17_byte);
    {
    let v179_4: Space = if (&(v178_8)).is_empty() { Space::new() } else {
      let v180_2: Path = concat_path(&(*p1),&v178_17_cursor.path()[v178_17_origin..(v178_17_origin + 1)]);
      let mut v180_3 = Space::new();
      let mut v180_3_write = v180_3.write_zipper();
      let v180_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v180_3_arg_1: &[u8] = &(v180_2);
      let v180_3_arg_3: &Space = &(&v178_17_cursor).make_map();
      let mut v180_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v180_3_origin = v180_3_cursor.path().len();
      let mut v180_3_more = v180_3_cursor.is_val() || next_value_within(&mut v180_3_cursor,v180_3_origin);
      while v180_3_more {
        {
        let v180_3_depth = v180_3_cursor.path().len();
        let v181_4: Space = routine_27(c, &v180_3_cursor.path()[v180_3_origin..v180_3_depth], &(*v180_3_arg_1), &((*v180_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v180_3_write,&((v181_4).read_zipper()),&[]);
        }
        v180_3_more = next_value_within(&mut v180_3_cursor,v180_3_origin);
      }
      drop(v180_3_cursor);
      drop(v180_3_write);
      drop(v180_2);
      compose(&(v178_8),&(v180_3))
    };
    let v179_5: Space = unite(&(v179_4),&(v178_16));
    join_wrapped_into(&mut v178_17_write,&((v179_5).read_zipper()),&[]);
    }
    v178_17_cursor.ascend(1);
  }
  drop(v178_17_cursor);
  drop(v178_17_write);
  drop(v178_8);
  drop(v178_16);
  (v178_17).clone()
}

fn routine_28(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v182_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v182_2: Space = first_matching(&(*s0),&(*CONSTANT_6),false);
  let v182_3: Space = unite(&(v182_1),&(v182_2));
  drop(v182_1);
  drop(v182_2);
  let v182_13: Space = if (&(v182_3)).is_empty() { Space::new() } else {
    let v183_6: Space = if (&(v182_3)).is_empty() { Space::new() } else {
      let v184_4: Space = routine_25(c, &(*s0));
      let v184_5: Space = subtract(&(*s0),&(v184_4));
      compose(&(v182_3),&(v184_5))
    };
    let v183_7: Space = if has_head(&(v183_6)) { singleton(&[]) } else { Space::new() };
    let v183_8: Space = first_matching(&(v183_6),&(*CONSTANT_6),false);
    let v183_9: Space = unite(&(v183_7),&(v183_8));
    let v183_12: Space = if (&(v183_9)).is_empty() { Space::new() } else {
      let v185_10: Space = routine_25(c, &((v183_6).read_zipper()));
      let v185_11: Space = subtract(&(v183_6),&(v185_10));
      compose(&(v183_9),&(v185_11))
    };
    compose(&(v182_3),&(v183_12))
  };
  drop(v182_3);
  (v182_13).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v186_5: Space = singleton(&(*p0));
  let v186_6: Space = intersect(&(*CONSTANT_7),&(v186_5));
  let v186_7: Space = if has_head(&(v186_6)) { singleton(&[]) } else { Space::new() };
  drop(v186_6);
  let v186_8: Space = subtract(&(*CONSTANT_6),&(v186_7));
  drop(v186_7);
  let v186_13: Space = intersect(&(*CONSTANT_7),&(v186_5));
  drop(v186_5);
  let v186_14: Space = if has_head(&(v186_13)) { singleton(&[]) } else { Space::new() };
  drop(v186_13);
  let v186_16: Space = compose(&(v186_14),&(*CONSTANT_10));
  drop(v186_14);
  let mut v186_17 = Space::new();
  let mut v186_17_write = v186_17.write_zipper();
  let mut v186_17_cursor = (*s0).read_zipper();
  let v186_17_origin = v186_17_cursor.path().len();
  for v186_17_byte in v186_17_cursor.child_mask().iter() {
    v186_17_cursor.descend_to_existing_byte(v186_17_byte);
    {
    let v187_4: Space = if (&(v186_8)).is_empty() { Space::new() } else {
      let v188_2: Path = concat_path(&(*p1),&v186_17_cursor.path()[v186_17_origin..(v186_17_origin + 1)]);
      let mut v188_3 = Space::new();
      let mut v188_3_write = v188_3.write_zipper();
      let v188_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v188_3_arg_1: &[u8] = &(v188_2);
      let v188_3_arg_3: &Space = &(&v186_17_cursor).make_map();
      let mut v188_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v188_3_origin = v188_3_cursor.path().len();
      let mut v188_3_more = v188_3_cursor.is_val() || next_value_within(&mut v188_3_cursor,v188_3_origin);
      while v188_3_more {
        {
        let v188_3_depth = v188_3_cursor.path().len();
        let v189_4: Space = routine_29(c, &v188_3_cursor.path()[v188_3_origin..v188_3_depth], &(*v188_3_arg_1), &((*v188_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v188_3_write,&((v189_4).read_zipper()),&[]);
        }
        v188_3_more = next_value_within(&mut v188_3_cursor,v188_3_origin);
      }
      drop(v188_3_cursor);
      drop(v188_3_write);
      drop(v188_2);
      compose(&(v186_8),&(v188_3))
    };
    let v187_5: Space = unite(&(v187_4),&(v186_16));
    join_wrapped_into(&mut v186_17_write,&((v187_5).read_zipper()),&[]);
    }
    v186_17_cursor.ascend(1);
  }
  drop(v186_17_cursor);
  drop(v186_17_write);
  drop(v186_8);
  drop(v186_16);
  (v186_17).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v190_6: Path = concat_path(&(*p1),&(*p0));
  let v190_7: Space = singleton(&(v190_6));
  drop(v190_6);
  let mut v190_8 = Space::new();
  let mut v190_8_write = v190_8.write_zipper();
  let mut v190_8_cursor = (v190_7).read_zipper();
  let v190_8_origin = v190_8_cursor.path().len();
  for v190_8_byte in v190_8_cursor.child_mask().iter() {
    v190_8_cursor.descend_to_existing_byte(v190_8_byte);
    {
    let v191_2: Space = routine_11(c, &v190_8_cursor.path()[v190_8_origin..(v190_8_origin + 1)], &v190_8_cursor.path()[v190_8_origin..(v190_8_origin + 1)], &v190_8_cursor);
    join_wrapped_into(&mut v190_8_write,&((v191_2).read_zipper()),&[]);
    }
    v190_8_cursor.ascend(1);
  }
  drop(v190_8_cursor);
  drop(v190_8_write);
  let v190_9: Space = intersect(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))),&(v190_8));
  let v190_10: Space = routine_28(c, &((v190_9).read_zipper()));
  let v190_11: Space = subtract(&(v190_9),&(v190_10));
  let v190_12: Space = routine_26(c, &((v190_9).read_zipper()));
  let v190_13: Space = intersect(&(v190_11),&(v190_12));
  let mut v190_19 = Space::new();
  let mut v190_19_write = v190_19.write_zipper();
  let mut v190_19_cursor = (v190_13).read_zipper();
  let v190_19_origin = v190_19_cursor.path().len();
  for v190_19_byte in v190_19_cursor.child_mask().iter() {
    v190_19_cursor.descend_to_existing_byte(v190_19_byte);
    {
    let v192_2: Space = singleton(&v190_19_cursor.path()[v190_19_origin..(v190_19_origin + 1)]);
    let v192_3: Space = intersect(&(*CONSTANT_7),&(v192_2));
    let v192_4: Space = if has_head(&(v192_3)) { singleton(&[]) } else { Space::new() };
    drop(v192_3);
    let v192_5: Space = subtract(&(*CONSTANT_6),&(v192_4));
    drop(v192_4);
    let v192_8: Space = if (&(v192_5)).is_empty() { Space::new() } else {
      let mut v193_7 = Space::new();
      let mut v193_7_write = v193_7.write_zipper();
      let v193_7_arg_0: &[u8] = &(*CONSTANT_9);
      let v193_7_arg_1: &[u8] = &v190_19_cursor.path()[v190_19_origin..(v190_19_origin + 1)];
      let v193_7_arg_3: &Space = &(&v190_19_cursor).make_map();
      let mut v193_7_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&v190_19_cursor.path()[v190_19_origin..(v190_19_origin + 1)]);
      let v193_7_origin = v193_7_cursor.path().len();
      let mut v193_7_more = v193_7_cursor.is_val() || next_value_within(&mut v193_7_cursor,v193_7_origin);
      while v193_7_more {
        {
        let v193_7_depth = v193_7_cursor.path().len();
        let mut v194_4_cursor = (*v193_7_arg_3).read_zipper();
        let v194_4_origin = v194_4_cursor.path().len();
        for v194_4_byte in v194_4_cursor.child_mask().iter() {
          v194_4_cursor.descend_to_existing_byte(v194_4_byte);
          {
          let v195_2: Path = concat_path(&(*v193_7_arg_1),&v194_4_cursor.path()[v194_4_origin..(v194_4_origin + 1)]);
          let v195_3: Space = routine_20(c, &(v195_2), &v193_7_cursor.path()[v193_7_origin..v193_7_depth], &v194_4_cursor);
          drop(v195_2);
          join_wrapped_into(&mut v193_7_write,&((v195_3).read_zipper()),&[]);
          }
          v194_4_cursor.ascend(1);
        }
        drop(v194_4_cursor);
        }
        v193_7_more = next_value_within(&mut v193_7_cursor,v193_7_origin);
      }
      drop(v193_7_cursor);
      drop(v193_7_write);
      compose(&(v192_5),&(v193_7))
    };
    drop(v192_5);
    let v192_9: Space = intersect(&(*CONSTANT_7),&(v192_2));
    drop(v192_2);
    let v192_10: Space = if has_head(&(v192_9)) { singleton(&[]) } else { Space::new() };
    drop(v192_9);
    let v192_12: Space = if (&(v192_10)).is_empty() { Space::new() } else {
      let v196_11: Space = routine_38(c, &v190_19_cursor.path()[v190_19_origin..(v190_19_origin + 1)], &v190_19_cursor);
      compose(&(v192_10),&(v196_11))
    };
    drop(v192_10);
    let v192_13: Space = unite(&(v192_8),&(v192_12));
    join_wrapped_into(&mut v190_19_write,&((v192_13).read_zipper()),&[]);
    }
    v190_19_cursor.ascend(1);
  }
  drop(v190_19_cursor);
  drop(v190_19_write);
  let v190_20: Space = routine_28(c, &((v190_12).read_zipper()));
  let v190_21: Space = subtract(&(v190_9),&(v190_20));
  let v190_22: Space = intersect(&(v190_21),&(v190_10));
  let mut v190_27 = Space::new();
  let mut v190_27_write = v190_27.write_zipper();
  let mut v190_27_cursor = (v190_22).read_zipper();
  let v190_27_origin = v190_27_cursor.path().len();
  for v190_27_byte in v190_27_cursor.child_mask().iter() {
    v190_27_cursor.descend_to_existing_byte(v190_27_byte);
    {
    let v197_2: Space = singleton(&v190_27_cursor.path()[v190_27_origin..(v190_27_origin + 1)]);
    let v197_3: Space = intersect(&(*CONSTANT_7),&(v197_2));
    let v197_4: Space = if has_head(&(v197_3)) { singleton(&[]) } else { Space::new() };
    drop(v197_3);
    let v197_5: Space = subtract(&(*CONSTANT_6),&(v197_4));
    drop(v197_4);
    let v197_8: Space = if (&(v197_5)).is_empty() { Space::new() } else {
      let mut v198_7 = Space::new();
      let mut v198_7_write = v198_7.write_zipper();
      let v198_7_arg_0: &[u8] = &(*CONSTANT_9);
      let v198_7_arg_1: &[u8] = &v190_27_cursor.path()[v190_27_origin..(v190_27_origin + 1)];
      let v198_7_arg_3: &Space = &(&v190_27_cursor).make_map();
      let mut v198_7_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&v190_27_cursor.path()[v190_27_origin..(v190_27_origin + 1)]);
      let v198_7_origin = v198_7_cursor.path().len();
      let mut v198_7_more = v198_7_cursor.is_val() || next_value_within(&mut v198_7_cursor,v198_7_origin);
      while v198_7_more {
        {
        let v198_7_depth = v198_7_cursor.path().len();
        let mut v199_4_cursor = (*v198_7_arg_3).read_zipper();
        let v199_4_origin = v199_4_cursor.path().len();
        for v199_4_byte in v199_4_cursor.child_mask().iter() {
          v199_4_cursor.descend_to_existing_byte(v199_4_byte);
          {
          let v200_2: Path = concat_path(&(*v198_7_arg_1),&v199_4_cursor.path()[v199_4_origin..(v199_4_origin + 1)]);
          let v200_3: Space = routine_21(c, &(v200_2), &v198_7_cursor.path()[v198_7_origin..v198_7_depth], &v199_4_cursor);
          drop(v200_2);
          join_wrapped_into(&mut v198_7_write,&((v200_3).read_zipper()),&[]);
          }
          v199_4_cursor.ascend(1);
        }
        drop(v199_4_cursor);
        }
        v198_7_more = next_value_within(&mut v198_7_cursor,v198_7_origin);
      }
      drop(v198_7_cursor);
      drop(v198_7_write);
      compose(&(v197_5),&(v198_7))
    };
    drop(v197_5);
    let v197_9: Space = intersect(&(*CONSTANT_7),&(v197_2));
    drop(v197_2);
    let v197_10: Space = if has_head(&(v197_9)) { singleton(&[]) } else { Space::new() };
    drop(v197_9);
    let v197_12: Space = if (&(v197_10)).is_empty() { Space::new() } else {
      let v201_11: Space = routine_39(c, &v190_27_cursor.path()[v190_27_origin..(v190_27_origin + 1)], &v190_27_cursor);
      compose(&(v197_10),&(v201_11))
    };
    drop(v197_10);
    let v197_13: Space = unite(&(v197_8),&(v197_12));
    join_wrapped_into(&mut v190_27_write,&((v197_13).read_zipper()),&[]);
    }
    v190_27_cursor.ascend(1);
  }
  drop(v190_27_cursor);
  drop(v190_27_write);
  let v190_28: Space = subtract(&(v190_19),&(v190_27));
  let v190_29: Space = if (&(v190_28)).is_empty() { Space::new() } else {
    compose(&(v190_28),&(v190_7))
  };
  drop(v190_7);
  let v190_795: Space = drop_length_prefixes(&(v190_29));
  (v190_795).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v203_5: Space = singleton(&(*p0));
  let v203_6: Space = intersect(&(*CONSTANT_7),&(v203_5));
  let v203_7: Space = if has_head(&(v203_6)) { singleton(&[]) } else { Space::new() };
  drop(v203_6);
  let v203_8: Space = subtract(&(*CONSTANT_6),&(v203_7));
  drop(v203_7);
  let v203_13: Space = intersect(&(*CONSTANT_7),&(v203_5));
  drop(v203_5);
  let v203_14: Space = if has_head(&(v203_13)) { singleton(&[]) } else { Space::new() };
  drop(v203_13);
  let v203_16: Space = compose(&(v203_14),&(*CONSTANT_10));
  drop(v203_14);
  let mut v203_17 = Space::new();
  let mut v203_17_write = v203_17.write_zipper();
  let mut v203_17_cursor = (*s0).read_zipper();
  let v203_17_origin = v203_17_cursor.path().len();
  for v203_17_byte in v203_17_cursor.child_mask().iter() {
    v203_17_cursor.descend_to_existing_byte(v203_17_byte);
    {
    let v204_4: Space = if (&(v203_8)).is_empty() { Space::new() } else {
      let v205_2: Path = concat_path(&(*p1),&v203_17_cursor.path()[v203_17_origin..(v203_17_origin + 1)]);
      let mut v205_3 = Space::new();
      let mut v205_3_write = v205_3.write_zipper();
      let v205_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v205_3_arg_1: &[u8] = &(v205_2);
      let v205_3_arg_3: &Space = &(&v203_17_cursor).make_map();
      let mut v205_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v205_3_origin = v205_3_cursor.path().len();
      let mut v205_3_more = v205_3_cursor.is_val() || next_value_within(&mut v205_3_cursor,v205_3_origin);
      while v205_3_more {
        {
        let v205_3_depth = v205_3_cursor.path().len();
        let v206_4: Space = routine_31(c, &v205_3_cursor.path()[v205_3_origin..v205_3_depth], &(*v205_3_arg_1), &((*v205_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v205_3_write,&((v206_4).read_zipper()),&[]);
        }
        v205_3_more = next_value_within(&mut v205_3_cursor,v205_3_origin);
      }
      drop(v205_3_cursor);
      drop(v205_3_write);
      drop(v205_2);
      compose(&(v203_8),&(v205_3))
    };
    let v204_5: Space = unite(&(v204_4),&(v203_16));
    join_wrapped_into(&mut v203_17_write,&((v204_5).read_zipper()),&[]);
    }
    v203_17_cursor.ascend(1);
  }
  drop(v203_17_cursor);
  drop(v203_17_write);
  drop(v203_8);
  drop(v203_16);
  (v203_17).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v207_5: Space = singleton(&(*p0));
  let v207_6: Space = intersect(&(*CONSTANT_7),&(v207_5));
  let v207_7: Space = if has_head(&(v207_6)) { singleton(&[]) } else { Space::new() };
  drop(v207_6);
  let v207_8: Space = subtract(&(*CONSTANT_6),&(v207_7));
  drop(v207_7);
  let v207_13: Space = intersect(&(*CONSTANT_7),&(v207_5));
  drop(v207_5);
  let v207_14: Space = if has_head(&(v207_13)) { singleton(&[]) } else { Space::new() };
  drop(v207_13);
  let v207_16: Space = compose(&(v207_14),&(*CONSTANT_10));
  drop(v207_14);
  let mut v207_17 = Space::new();
  let mut v207_17_write = v207_17.write_zipper();
  let mut v207_17_cursor = (*s0).read_zipper();
  let v207_17_origin = v207_17_cursor.path().len();
  for v207_17_byte in v207_17_cursor.child_mask().iter() {
    v207_17_cursor.descend_to_existing_byte(v207_17_byte);
    {
    let v208_4: Space = if (&(v207_8)).is_empty() { Space::new() } else {
      let v209_2: Path = concat_path(&(*p1),&v207_17_cursor.path()[v207_17_origin..(v207_17_origin + 1)]);
      let mut v209_3 = Space::new();
      let mut v209_3_write = v209_3.write_zipper();
      let v209_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v209_3_arg_1: &[u8] = &(v209_2);
      let v209_3_arg_3: &Space = &(&v207_17_cursor).make_map();
      let mut v209_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v209_3_origin = v209_3_cursor.path().len();
      let mut v209_3_more = v209_3_cursor.is_val() || next_value_within(&mut v209_3_cursor,v209_3_origin);
      while v209_3_more {
        {
        let v209_3_depth = v209_3_cursor.path().len();
        let v210_4: Space = routine_32(c, &v209_3_cursor.path()[v209_3_origin..v209_3_depth], &(*v209_3_arg_1), &((*v209_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v209_3_write,&((v210_4).read_zipper()),&[]);
        }
        v209_3_more = next_value_within(&mut v209_3_cursor,v209_3_origin);
      }
      drop(v209_3_cursor);
      drop(v209_3_write);
      drop(v209_2);
      compose(&(v207_8),&(v209_3))
    };
    let v208_5: Space = unite(&(v208_4),&(v207_16));
    join_wrapped_into(&mut v207_17_write,&((v208_5).read_zipper()),&[]);
    }
    v207_17_cursor.ascend(1);
  }
  drop(v207_17_cursor);
  drop(v207_17_write);
  drop(v207_8);
  drop(v207_16);
  (v207_17).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v211_6: Space = singleton(&(*p0));
  let v211_7: Space = intersect(&(*CONSTANT_7),&(v211_6));
  let v211_8: Space = if has_head(&(v211_7)) { singleton(&[]) } else { Space::new() };
  drop(v211_7);
  let v211_9: Space = subtract(&(*CONSTANT_6),&(v211_8));
  drop(v211_8);
  let v211_14: Space = intersect(&(*CONSTANT_7),&(v211_6));
  drop(v211_6);
  let v211_15: Space = if has_head(&(v211_14)) { singleton(&[]) } else { Space::new() };
  drop(v211_14);
  let mut v211_20 = Space::new();
  let mut v211_20_write = v211_20.write_zipper();
  let mut v211_20_cursor = (*s0).read_zipper();
  let v211_20_origin = v211_20_cursor.path().len();
  for v211_20_byte in v211_20_cursor.child_mask().iter() {
    v211_20_cursor.descend_to_existing_byte(v211_20_byte);
    {
    let v212_4: Space = if (&(v211_9)).is_empty() { Space::new() } else {
      let v213_2: Path = concat_path(&(*p1),&v211_20_cursor.path()[v211_20_origin..(v211_20_origin + 1)]);
      let mut v213_3 = Space::new();
      let mut v213_3_write = v213_3.write_zipper();
      let v213_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v213_3_arg_1: &[u8] = &(v213_2);
      let v213_3_arg_2: &[u8] = &(*p2);
      let v213_3_arg_4: &Space = &(&v211_20_cursor).make_map();
      let mut v213_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v213_3_origin = v213_3_cursor.path().len();
      let mut v213_3_more = v213_3_cursor.is_val() || next_value_within(&mut v213_3_cursor,v213_3_origin);
      while v213_3_more {
        {
        let v213_3_depth = v213_3_cursor.path().len();
        let v214_5: Space = routine_33(c, &v213_3_cursor.path()[v213_3_origin..v213_3_depth], &(*v213_3_arg_1), &(*v213_3_arg_2), &((*v213_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v213_3_write,&((v214_5).read_zipper()),&[]);
        }
        v213_3_more = next_value_within(&mut v213_3_cursor,v213_3_origin);
      }
      drop(v213_3_cursor);
      drop(v213_3_write);
      compose(&(v211_9),&(v213_3))
    };
    let v212_10: Space = if (&(v211_15)).is_empty() { Space::new() } else {
      let v215_2: Path = concat_path(&(*p1),&v211_20_cursor.path()[v211_20_origin..(v211_20_origin + 1)]);
      let v215_6: Space = if (&(descend_cursor((*CONSTANT_11).read_zipper(),&(*p2)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor((*CONSTANT_11).read_zipper(),&(*p2))),&(descend_cursor(descend_cursor((*CONSTANT_11).read_zipper(),&(*p1)),&v211_20_cursor.path()[v211_20_origin..(v211_20_origin + 1)])))
      };
      let v215_7: Path = concat_path(&(*p2),&(v215_2));
      drop(v215_2);
      let v215_8: Space = singleton(&(v215_7));
      drop(v215_7);
      let v215_9: Space = subtract(&(v215_6),&(v215_8));
      drop(v215_6);
      drop(v215_8);
      compose(&(v211_15),&(v215_9))
    };
    let v212_11: Space = unite(&(v212_4),&(v212_10));
    drop(v212_10);
    join_wrapped_into(&mut v211_20_write,&((v212_11).read_zipper()),&[]);
    }
    v211_20_cursor.ascend(1);
  }
  drop(v211_20_cursor);
  drop(v211_20_write);
  drop(v211_9);
  drop(v211_15);
  (v211_20).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (*CONSTANT_10).clone()
}

fn routine_35(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v218_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v218_2: Space = first_matching(&(*s0),&(*CONSTANT_6),false);
  let v218_3: Space = unite(&(v218_1),&(v218_2));
  drop(v218_1);
  drop(v218_2);
  let v218_15: Space = if (&(v218_3)).is_empty() { Space::new() } else {
    let v219_8: Space = if (&(v218_3)).is_empty() { Space::new() } else {
      let v220_6: Space = if (&(v218_3)).is_empty() { Space::new() } else {
        let v221_4: Space = routine_25(c, &(*s0));
        let v221_5: Space = subtract(&(*s0),&(v221_4));
        compose(&(v218_3),&(v221_5))
      };
      let v220_7: Space = routine_26(c, &((v220_6).read_zipper()));
      compose(&(v218_3),&(v220_7))
    };
    let v219_9: Space = if has_head(&(v219_8)) { singleton(&[]) } else { Space::new() };
    let v219_10: Space = first_matching(&(v219_8),&(*CONSTANT_6),false);
    let v219_11: Space = unite(&(v219_9),&(v219_10));
    let v219_14: Space = if (&(v219_11)).is_empty() { Space::new() } else {
      let v222_12: Space = routine_26(c, &((v219_8).read_zipper()));
      let v222_13: Space = routine_26(c, &((v222_12).read_zipper()));
      compose(&(v219_11),&(v222_13))
    };
    compose(&(v218_3),&(v219_14))
  };
  drop(v218_3);
  (v218_15).clone()
}

fn routine_36(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (*CONSTANT_10).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v224_4: Space = first_matching(&(descend_cursor((*s0).read_zipper(),&(*p0))),&(*CONSTANT_6),false);
  let v224_5: Space = intersect(&(*CONSTANT_6),&(v224_4));
  let v224_6: Space = if has_head(&(v224_4)) { singleton(&[]) } else { Space::new() };
  let v224_7: Space = unite(&(v224_5),&(v224_6));
  drop(v224_5);
  let v224_9: Space = compose(&(v224_7),&(*CONSTANT_6));
  drop(v224_7);
  let v224_11: Space = subtract(&(*CONSTANT_6),&(v224_4));
  drop(v224_4);
  let v224_12: Space = subtract(&(v224_11),&(v224_6));
  drop(v224_6);
  drop(v224_11);
  let v224_16: Space = if (&(v224_12)).is_empty() { Space::new() } else {
    let v225_14: Space = first_length_prefixed(&(descend_cursor((*s0).read_zipper(),&(*p0))));
    let mut v225_15 = Space::new();
    let mut v225_15_write = v225_15.write_zipper();
    let v225_15_arg_0: &[u8] = &(*CONSTANT_9);
    let v225_15_arg_2: &Space = &(&(descend_cursor((*s0).read_zipper(),&(*p0)))).make_map();
    let mut v225_15_cursor = (v225_14).read_zipper();
    let v225_15_origin = v225_15_cursor.path().len();
    let mut v225_15_more = v225_15_cursor.is_val() || next_value_within(&mut v225_15_cursor,v225_15_origin);
    while v225_15_more {
      {
      let v225_15_depth = v225_15_cursor.path().len();
      let v226_3: Space = routine_37(c, &v225_15_cursor.path()[v225_15_origin..v225_15_depth], &((*v225_15_arg_2).read_zipper()));
      join_wrapped_into(&mut v225_15_write,&((v226_3).read_zipper()),&[]);
      }
      v225_15_more = next_value_within(&mut v225_15_cursor,v225_15_origin);
    }
    drop(v225_15_cursor);
    drop(v225_15_write);
    drop(v225_14);
    compose(&(v224_12),&(v225_15))
  };
  drop(v224_12);
  let v224_17: Space = unite(&(v224_9),&(v224_16));
  drop(v224_9);
  let v224_18: Space = wrap(&(v224_17),&(*p0));
  (v224_18).clone()
}

fn routine_38(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (*CONSTANT_10).clone()
}

fn routine_39(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (*CONSTANT_10).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
