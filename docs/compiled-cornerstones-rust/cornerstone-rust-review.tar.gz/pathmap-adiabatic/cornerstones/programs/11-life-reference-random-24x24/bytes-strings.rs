#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[48]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 49 48 0 4 0 49 49 0"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[49]));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("53 4 0 49 51 0 4 0 49 52 0 4 0 50 48 0 5 48 0 49 50 0 5 48 0 49 56 0 5 48 0 50 51 0 4 48 0 54 0 4 48 0 57 0 5 49 0 49 49 0 5 49 0 49 50 0 5 49 0 50 51 0 4 49 0 51 0 4 49 0 53 0 5 50 0 49 54 0 5 50 0 49 57 0 4 50 0 50 0 5 51 0 49 52 0 5 51 0 50 48 0 5 51 0 50 49 0 4 51 0 57 0 4 52 0 48 0 5 52 0 49 56 0 4 52 0 54 0 4 52 0 56 0 4 52 0 57 0 4 53 0 49 0 5 53 0 49 54 0 5 53 0 49 55 0 5 53 0 49 57 0 5 53 0 50 48 0 4 53 0 51 0 4 53 0 53 0 4 53 0 54 0 4 54 0 48 0 5 55 0 49 50 0 5 55 0 49 54 0 5 55 0 49 56 0 4 55 0 50 0 4 55 0 51 0 4 55 0 52 0 4 55 0 54 0 4 55 0 55 0 4 55 0 57 0 5 56 0 49 48 0 5 56 0 49 50 0 5 56 0 49 51 0 5 56 0 49 53 0 5 56 0 49 55 0 5 56 0 50 50 0 4 56 0 53 0 5 57 0 49 56 0 5 57 0 50 49 0 4 57 0 51 0"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[50]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("21 4 0 49 48 0 4 0 49 51 0 4 0 50 49 0 5 48 0 49 53 0 4 48 0 50 0 4 48 0 53 0 4 48 0 55 0 4 48 0 57 0 5 49 0 49 51 0 5 49 0 49 53 0 4 49 0 52 0 4 49 0 56 0 4 49 0 57 0 5 50 0 49 54 0 4 50 0 50 0 5 50 0 50 50 0 4 51 0 49 0 4 51 0 50 0 4 51 0 53 0 4 51 0 55 0 4 51 0 57 0"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[51]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 3 0 49 0 3 0 50 0 4 0 50 49 0 3 0 53 0 3 0 55 0"));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[52]));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 4 0 49 49 0 4 0 49 53 0 4 0 49 54 0 4 0 49 57 0 4 0 50 48 0 4 0 50 51 0 3 0 56 0"));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[53]));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 49 48 0 4 0 49 50 0 4 0 49 56 0 4 0 49 57 0 3 0 55 0"));
static CONSTANT_13: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[54]));
static CONSTANT_14: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 3 0 49 0 4 0 49 52 0 3 0 50 0 4 0 50 48 0 3 0 52 0 3 0 54 0"));
static CONSTANT_15: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[55]));
static CONSTANT_16: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 3 0 49 0 4 0 49 48 0 4 0 49 52 0 4 0 49 57 0 4 0 50 48 0 3 0 52 0 3 0 53 0"));
static CONSTANT_17: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[56]));
static CONSTANT_18: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 4 0 49 49 0 4 0 49 57 0 4 0 50 49 0 3 0 53 0 3 0 54 0 3 0 57 0"));
static CONSTANT_19: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[57]));
static CONSTANT_20: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 4 0 49 50 0 4 0 49 55 0 4 0 49 57 0 4 0 50 51 0 3 0 51 0 3 0 52 0 3 0 53 0 3 0 55 0"));
static CONSTANT_21: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_22: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("120 10 67 101 108 108 0 48 0 49 48 0 10 67 101 108 108 0 48 0 49 49 0 10 67 101 108 108 0 49 0 49 51 0 10 67 101 108 108 0 49 0 49 52 0 10 67 101 108 108 0 49 0 50 48 0 11 67 101 108 108 0 49 48 0 49 50 0 11 67 101 108 108 0 49 48 0 49 56 0 11 67 101 108 108 0 49 48 0 50 51 0 10 67 101 108 108 0 49 48 0 54 0 10 67 101 108 108 0 49 48 0 57 0 11 67 101 108 108 0 49 49 0 49 49 0 11 67 101 108 108 0 49 49 0 49 50 0 11 67 101 108 108 0 49 49 0 50 51 0 10 67 101 108 108 0 49 49 0 51 0 10 67 101 108 108 0 49 49 0 53 0 11 67 101 108 108 0 49 50 0 49 54 0 11 67 101 108 108 0 49 50 0 49 57 0 10 67 101 108 108 0 49 50 0 50 0 11 67 101 108 108 0 49 51 0 49 52 0 11 67 101 108 108 0 49 51 0 50 48 0 11 67 101 108 108 0 49 51 0 50 49 0 10 67 101 108 108 0 49 51 0 57 0 10 67 101 108 108 0 49 52 0 48 0 11 67 101 108 108 0 49 52 0 49 56 0 10 67 101 108 108 0 49 52 0 54 0 10 67 101 108 108 0 49 52 0 56 0 10 67 101 108 108 0 49 52 0 57 0 10 67 101 108 108 0 49 53 0 49 0 11 67 101 108 108 0 49 53 0 49 54 0 11 67 101 108 108 0 49 53 0 49 55 0 11 67 101 108 108 0 49 53 0 49 57 0 11 67 101 108 108 0 49 53 0 50 48 0 10 67 101 108 108 0 49 53 0 51 0 10 67 101 108 108 0 49 53 0 53 0 10 67 101 108 108 0 49 53 0 54 0 10 67 101 108 108 0 49 54 0 48 0 11 67 101 108 108 0 49 55 0 49 50 0 11 67 101 108 108 0 49 55 0 49 54 0 11 67 101 108 108 0 49 55 0 49 56 0 10 67 101 108 108 0 49 55 0 50 0 10 67 101 108 108 0 49 55 0 51 0 10 67 101 108 108 0 49 55 0 52 0 10 67 101 108 108 0 49 55 0 54 0 10 67 101 108 108 0 49 55 0 55 0 10 67 101 108 108 0 49 55 0 57 0 11 67 101 108 108 0 49 56 0 49 48 0 11 67 101 108 108 0 49 56 0 49 50 0 11 67 101 108 108 0 49 56 0 49 51 0 11 67 101 108 108 0 49 56 0 49 53 0 11 67 101 108 108 0 49 56 0 49 55 0 11 67 101 108 108 0 49 56 0 50 50 0 10 67 101 108 108 0 49 56 0 53 0 11 67 101 108 108 0 49 57 0 49 56 0 11 67 101 108 108 0 49 57 0 50 49 0 10 67 101 108 108 0 49 57 0 51 0 10 67 101 108 108 0 50 0 49 48 0 10 67 101 108 108 0 50 0 49 51 0 10 67 101 108 108 0 50 0 50 49 0 11 67 101 108 108 0 50 48 0 49 53 0 10 67 101 108 108 0 50 48 0 50 0 10 67 101 108 108 0 50 48 0 53 0 10 67 101 108 108 0 50 48 0 55 0 10 67 101 108 108 0 50 48 0 57 0 11 67 101 108 108 0 50 49 0 49 51 0 11 67 101 108 108 0 50 49 0 49 53 0 10 67 101 108 108 0 50 49 0 52 0 10 67 101 108 108 0 50 49 0 56 0 10 67 101 108 108 0 50 49 0 57 0 11 67 101 108 108 0 50 50 0 49 54 0 10 67 101 108 108 0 50 50 0 50 0 11 67 101 108 108 0 50 50 0 50 50 0 10 67 101 108 108 0 50 51 0 49 0 10 67 101 108 108 0 50 51 0 50 0 10 67 101 108 108 0 50 51 0 53 0 10 67 101 108 108 0 50 51 0 55 0 10 67 101 108 108 0 50 51 0 57 0 9 67 101 108 108 0 51 0 49 0 9 67 101 108 108 0 51 0 50 0 10 67 101 108 108 0 51 0 50 49 0 9 67 101 108 108 0 51 0 53 0 9 67 101 108 108 0 51 0 55 0 10 67 101 108 108 0 52 0 49 49 0 10 67 101 108 108 0 52 0 49 53 0 10 67 101 108 108 0 52 0 49 54 0 10 67 101 108 108 0 52 0 49 57 0 10 67 101 108 108 0 52 0 50 48 0 10 67 101 108 108 0 52 0 50 51 0 9 67 101 108 108 0 52 0 56 0 10 67 101 108 108 0 53 0 49 48 0 10 67 101 108 108 0 53 0 49 50 0 10 67 101 108 108 0 53 0 49 56 0 10 67 101 108 108 0 53 0 49 57 0 9 67 101 108 108 0 53 0 55 0 9 67 101 108 108 0 54 0 49 0 10 67 101 108 108 0 54 0 49 52 0 9 67 101 108 108 0 54 0 50 0 10 67 101 108 108 0 54 0 50 48 0 9 67 101 108 108 0 54 0 52 0 9 67 101 108 108 0 54 0 54 0 9 67 101 108 108 0 55 0 49 0 10 67 101 108 108 0 55 0 49 48 0 10 67 101 108 108 0 55 0 49 52 0 10 67 101 108 108 0 55 0 49 57 0 10 67 101 108 108 0 55 0 50 48 0 9 67 101 108 108 0 55 0 52 0 9 67 101 108 108 0 55 0 53 0 10 67 101 108 108 0 56 0 49 49 0 10 67 101 108 108 0 56 0 49 57 0 10 67 101 108 108 0 56 0 50 49 0 9 67 101 108 108 0 56 0 53 0 9 67 101 108 108 0 56 0 54 0 9 67 101 108 108 0 56 0 57 0 10 67 101 108 108 0 57 0 49 50 0 10 67 101 108 108 0 57 0 49 55 0 10 67 101 108 108 0 57 0 49 57 0 10 67 101 108 108 0 57 0 50 51 0 9 67 101 108 108 0 57 0 51 0 9 67 101 108 108 0 57 0 52 0 9 67 101 108 108 0 57 0 53 0 9 67 101 108 108 0 57 0 55 0"));
static CONSTANT_23: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[67,101,108,108,0]));
static CONSTANT_24: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 104 105 116 0"));
static CONSTANT_25: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("387 6 45 49 0 45 49 0 6 45 49 0 45 50 0 5 45 49 0 48 0 8 45 49 48 0 45 49 48 0 8 45 49 48 0 45 49 49 0 7 45 49 48 0 45 57 0 8 45 49 49 0 45 49 48 0 8 45 49 49 0 45 49 49 0 8 45 49 49 0 45 49 50 0 8 45 49 50 0 45 49 49 0 8 45 49 50 0 45 49 50 0 8 45 49 50 0 45 49 51 0 8 45 49 51 0 45 49 50 0 8 45 49 51 0 45 49 51 0 8 45 49 51 0 45 49 52 0 8 45 49 52 0 45 49 51 0 8 45 49 52 0 45 49 52 0 8 45 49 52 0 45 49 53 0 8 45 49 53 0 45 49 52 0 8 45 49 53 0 45 49 53 0 8 45 49 53 0 45 49 54 0 8 45 49 54 0 45 49 53 0 8 45 49 54 0 45 49 54 0 8 45 49 54 0 45 49 55 0 8 45 49 55 0 45 49 54 0 8 45 49 55 0 45 49 55 0 8 45 49 55 0 45 49 56 0 8 45 49 56 0 45 49 55 0 8 45 49 56 0 45 49 56 0 8 45 49 56 0 45 49 57 0 8 45 49 57 0 45 49 56 0 8 45 49 57 0 45 49 57 0 8 45 49 57 0 45 50 48 0 6 45 50 0 45 49 0 6 45 50 0 45 50 0 6 45 50 0 45 51 0 8 45 50 48 0 45 49 57 0 8 45 50 48 0 45 50 48 0 8 45 50 48 0 45 50 49 0 8 45 50 49 0 45 50 48 0 8 45 50 49 0 45 50 49 0 8 45 50 49 0 45 50 50 0 8 45 50 50 0 45 50 49 0 8 45 50 50 0 45 50 50 0 8 45 50 50 0 45 50 51 0 8 45 50 51 0 45 50 50 0 8 45 50 51 0 45 50 51 0 8 45 50 51 0 45 50 52 0 8 45 50 52 0 45 50 51 0 8 45 50 52 0 45 50 52 0 8 45 50 52 0 45 50 53 0 8 45 50 53 0 45 50 52 0 8 45 50 53 0 45 50 53 0 8 45 50 53 0 45 50 54 0 8 45 50 54 0 45 50 53 0 8 45 50 54 0 45 50 54 0 8 45 50 54 0 45 50 55 0 8 45 50 55 0 45 50 54 0 8 45 50 55 0 45 50 55 0 8 45 50 55 0 45 50 56 0 8 45 50 56 0 45 50 55 0 8 45 50 56 0 45 50 56 0 8 45 50 56 0 45 50 57 0 8 45 50 57 0 45 50 56 0 8 45 50 57 0 45 50 57 0 8 45 50 57 0 45 51 48 0 6 45 51 0 45 50 0 6 45 51 0 45 51 0 6 45 51 0 45 52 0 8 45 51 48 0 45 50 57 0 8 45 51 48 0 45 51 48 0 8 45 51 48 0 45 51 49 0 8 45 51 49 0 45 51 48 0 8 45 51 49 0 45 51 49 0 8 45 51 49 0 45 51 50 0 8 45 51 50 0 45 51 49 0 8 45 51 50 0 45 51 50 0 8 45 51 50 0 45 51 51 0 8 45 51 51 0 45 51 50 0 8 45 51 51 0 45 51 51 0 8 45 51 51 0 45 51 52 0 8 45 51 52 0 45 51 51 0 8 45 51 52 0 45 51 52 0 8 45 51 52 0 45 51 53 0 8 45 51 53 0 45 51 52 0 8 45 51 53 0 45 51 53 0 8 45 51 53 0 45 51 54 0 8 45 51 54 0 45 51 53 0 8 45 51 54 0 45 51 54 0 8 45 51 54 0 45 51 55 0 8 45 51 55 0 45 51 54 0 8 45 51 55 0 45 51 55 0 8 45 51 55 0 45 51 56 0 8 45 51 56 0 45 51 55 0 8 45 51 56 0 45 51 56 0 8 45 51 56 0 45 51 57 0 8 45 51 57 0 45 51 56 0 8 45 51 57 0 45 51 57 0 8 45 51 57 0 45 52 48 0 6 45 52 0 45 51 0 6 45 52 0 45 52 0 6 45 52 0 45 53 0 8 45 52 48 0 45 51 57 0 8 45 52 48 0 45 52 48 0 8 45 52 48 0 45 52 49 0 8 45 52 49 0 45 52 48 0 8 45 52 49 0 45 52 49 0 8 45 52 49 0 45 52 50 0 8 45 52 50 0 45 52 49 0 8 45 52 50 0 45 52 50 0 8 45 52 50 0 45 52 51 0 8 45 52 51 0 45 52 50 0 8 45 52 51 0 45 52 51 0 8 45 52 51 0 45 52 52 0 8 45 52 52 0 45 52 51 0 8 45 52 52 0 45 52 52 0 8 45 52 52 0 45 52 53 0 8 45 52 53 0 45 52 52 0 8 45 52 53 0 45 52 53 0 8 45 52 53 0 45 52 54 0 8 45 52 54 0 45 52 53 0 8 45 52 54 0 45 52 54 0 8 45 52 54 0 45 52 55 0 8 45 52 55 0 45 52 54 0 8 45 52 55 0 45 52 55 0 8 45 52 55 0 45 52 56 0 8 45 52 56 0 45 52 55 0 8 45 52 56 0 45 52 56 0 8 45 52 56 0 45 52 57 0 8 45 52 57 0 45 52 56 0 8 45 52 57 0 45 52 57 0 8 45 52 57 0 45 53 48 0 6 45 53 0 45 52 0 6 45 53 0 45 53 0 6 45 53 0 45 54 0 8 45 53 48 0 45 52 57 0 8 45 53 48 0 45 53 48 0 8 45 53 48 0 45 53 49 0 8 45 53 49 0 45 53 48 0 8 45 53 49 0 45 53 49 0 8 45 53 49 0 45 53 50 0 8 45 53 50 0 45 53 49 0 8 45 53 50 0 45 53 50 0 8 45 53 50 0 45 53 51 0 8 45 53 51 0 45 53 50 0 8 45 53 51 0 45 53 51 0 8 45 53 51 0 45 53 52 0 8 45 53 52 0 45 53 51 0 8 45 53 52 0 45 53 52 0 8 45 53 52 0 45 53 53 0 8 45 53 53 0 45 53 52 0 8 45 53 53 0 45 53 53 0 8 45 53 53 0 45 53 54 0 8 45 53 54 0 45 53 53 0 8 45 53 54 0 45 53 54 0 8 45 53 54 0 45 53 55 0 8 45 53 55 0 45 53 54 0 8 45 53 55 0 45 53 55 0 8 45 53 55 0 45 53 56 0 8 45 53 56 0 45 53 55 0 8 45 53 56 0 45 53 56 0 8 45 53 56 0 45 53 57 0 8 45 53 57 0 45 53 56 0 8 45 53 57 0 45 53 57 0 8 45 53 57 0 45 54 48 0 6 45 54 0 45 53 0 6 45 54 0 45 54 0 6 45 54 0 45 55 0 8 45 54 48 0 45 53 57 0 8 45 54 48 0 45 54 48 0 8 45 54 48 0 45 54 49 0 8 45 54 49 0 45 54 48 0 8 45 54 49 0 45 54 49 0 8 45 54 49 0 45 54 50 0 8 45 54 50 0 45 54 49 0 8 45 54 50 0 45 54 50 0 8 45 54 50 0 45 54 51 0 8 45 54 51 0 45 54 50 0 8 45 54 51 0 45 54 51 0 8 45 54 51 0 45 54 52 0 8 45 54 52 0 45 54 51 0 8 45 54 52 0 45 54 52 0 8 45 54 52 0 45 54 53 0 6 45 55 0 45 54 0 6 45 55 0 45 55 0 6 45 55 0 45 56 0 6 45 56 0 45 55 0 6 45 56 0 45 56 0 6 45 56 0 45 57 0 7 45 57 0 45 49 48 0 6 45 57 0 45 56 0 6 45 57 0 45 57 0 5 48 0 45 49 0 4 48 0 48 0 4 48 0 49 0 4 49 0 48 0 4 49 0 49 0 4 49 0 50 0 6 49 48 0 49 48 0 6 49 48 0 49 49 0 5 49 48 0 57 0 6 49 49 0 49 48 0 6 49 49 0 49 49 0 6 49 49 0 49 50 0 6 49 50 0 49 49 0 6 49 50 0 49 50 0 6 49 50 0 49 51 0 6 49 51 0 49 50 0 6 49 51 0 49 51 0 6 49 51 0 49 52 0 6 49 52 0 49 51 0 6 49 52 0 49 52 0 6 49 52 0 49 53 0 6 49 53 0 49 52 0 6 49 53 0 49 53 0 6 49 53 0 49 54 0 6 49 54 0 49 53 0 6 49 54 0 49 54 0 6 49 54 0 49 55 0 6 49 55 0 49 54 0 6 49 55 0 49 55 0 6 49 55 0 49 56 0 6 49 56 0 49 55 0 6 49 56 0 49 56 0 6 49 56 0 49 57 0 6 49 57 0 49 56 0 6 49 57 0 49 57 0 6 49 57 0 50 48 0 4 50 0 49 0 4 50 0 50 0 4 50 0 51 0 6 50 48 0 49 57 0 6 50 48 0 50 48 0 6 50 48 0 50 49 0 6 50 49 0 50 48 0 6 50 49 0 50 49 0 6 50 49 0 50 50 0 6 50 50 0 50 49 0 6 50 50 0 50 50 0 6 50 50 0 50 51 0 6 50 51 0 50 50 0 6 50 51 0 50 51 0 6 50 51 0 50 52 0 6 50 52 0 50 51 0 6 50 52 0 50 52 0 6 50 52 0 50 53 0 6 50 53 0 50 52 0 6 50 53 0 50 53 0 6 50 53 0 50 54 0 6 50 54 0 50 53 0 6 50 54 0 50 54 0 6 50 54 0 50 55 0 6 50 55 0 50 54 0 6 50 55 0 50 55 0 6 50 55 0 50 56 0 6 50 56 0 50 55 0 6 50 56 0 50 56 0 6 50 56 0 50 57 0 6 50 57 0 50 56 0 6 50 57 0 50 57 0 6 50 57 0 51 48 0 4 51 0 50 0 4 51 0 51 0 4 51 0 52 0 6 51 48 0 50 57 0 6 51 48 0 51 48 0 6 51 48 0 51 49 0 6 51 49 0 51 48 0 6 51 49 0 51 49 0 6 51 49 0 51 50 0 6 51 50 0 51 49 0 6 51 50 0 51 50 0 6 51 50 0 51 51 0 6 51 51 0 51 50 0 6 51 51 0 51 51 0 6 51 51 0 51 52 0 6 51 52 0 51 51 0 6 51 52 0 51 52 0 6 51 52 0 51 53 0 6 51 53 0 51 52 0 6 51 53 0 51 53 0 6 51 53 0 51 54 0 6 51 54 0 51 53 0 6 51 54 0 51 54 0 6 51 54 0 51 55 0 6 51 55 0 51 54 0 6 51 55 0 51 55 0 6 51 55 0 51 56 0 6 51 56 0 51 55 0 6 51 56 0 51 56 0 6 51 56 0 51 57 0 6 51 57 0 51 56 0 6 51 57 0 51 57 0 6 51 57 0 52 48 0 4 52 0 51 0 4 52 0 52 0 4 52 0 53 0 6 52 48 0 51 57 0 6 52 48 0 52 48 0 6 52 48 0 52 49 0 6 52 49 0 52 48 0 6 52 49 0 52 49 0 6 52 49 0 52 50 0 6 52 50 0 52 49 0 6 52 50 0 52 50 0 6 52 50 0 52 51 0 6 52 51 0 52 50 0 6 52 51 0 52 51 0 6 52 51 0 52 52 0 6 52 52 0 52 51 0 6 52 52 0 52 52 0 6 52 52 0 52 53 0 6 52 53 0 52 52 0 6 52 53 0 52 53 0 6 52 53 0 52 54 0 6 52 54 0 52 53 0 6 52 54 0 52 54 0 6 52 54 0 52 55 0 6 52 55 0 52 54 0 6 52 55 0 52 55 0 6 52 55 0 52 56 0 6 52 56 0 52 55 0 6 52 56 0 52 56 0 6 52 56 0 52 57 0 6 52 57 0 52 56 0 6 52 57 0 52 57 0 6 52 57 0 53 48 0 4 53 0 52 0 4 53 0 53 0 4 53 0 54 0 6 53 48 0 52 57 0 6 53 48 0 53 48 0 6 53 48 0 53 49 0 6 53 49 0 53 48 0 6 53 49 0 53 49 0 6 53 49 0 53 50 0 6 53 50 0 53 49 0 6 53 50 0 53 50 0 6 53 50 0 53 51 0 6 53 51 0 53 50 0 6 53 51 0 53 51 0 6 53 51 0 53 52 0 6 53 52 0 53 51 0 6 53 52 0 53 52 0 6 53 52 0 53 53 0 6 53 53 0 53 52 0 6 53 53 0 53 53 0 6 53 53 0 53 54 0 6 53 54 0 53 53 0 6 53 54 0 53 54 0 6 53 54 0 53 55 0 6 53 55 0 53 54 0 6 53 55 0 53 55 0 6 53 55 0 53 56 0 6 53 56 0 53 55 0 6 53 56 0 53 56 0 6 53 56 0 53 57 0 6 53 57 0 53 56 0 6 53 57 0 53 57 0 6 53 57 0 54 48 0 4 54 0 53 0 4 54 0 54 0 4 54 0 55 0 6 54 48 0 53 57 0 6 54 48 0 54 48 0 6 54 48 0 54 49 0 6 54 49 0 54 48 0 6 54 49 0 54 49 0 6 54 49 0 54 50 0 6 54 50 0 54 49 0 6 54 50 0 54 50 0 6 54 50 0 54 51 0 6 54 51 0 54 50 0 6 54 51 0 54 51 0 6 54 51 0 54 52 0 6 54 52 0 54 51 0 6 54 52 0 54 52 0 6 54 52 0 54 53 0 4 55 0 54 0 4 55 0 55 0 4 55 0 56 0 4 56 0 55 0 4 56 0 56 0 4 56 0 57 0 5 57 0 49 48 0 4 57 0 56 0 4 57 0 57 0"));
fn routine_0(c: &mut Context) -> Space {
  let v0_40: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v1_3: Space = routine_1(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
    let v1_6: Space = routine_1(c, &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
    let v1_7: Space = unite(&(v1_3),&(v1_6));
    let v1_10: Space = routine_1(c, &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
    let v1_11: Space = unite(&(v1_7),&(v1_10));
    let v1_14: Space = routine_1(c, &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
    let v1_15: Space = unite(&(v1_11),&(v1_14));
    let v1_18: Space = routine_1(c, &(*CONSTANT_9), &((*CONSTANT_10).read_zipper()));
    let v1_19: Space = unite(&(v1_15),&(v1_18));
    let v1_22: Space = routine_1(c, &(*CONSTANT_11), &((*CONSTANT_12).read_zipper()));
    let v1_23: Space = unite(&(v1_19),&(v1_22));
    let v1_26: Space = routine_1(c, &(*CONSTANT_13), &((*CONSTANT_14).read_zipper()));
    let v1_27: Space = unite(&(v1_23),&(v1_26));
    let v1_30: Space = routine_1(c, &(*CONSTANT_15), &((*CONSTANT_16).read_zipper()));
    let v1_31: Space = unite(&(v1_27),&(v1_30));
    let v1_34: Space = routine_1(c, &(*CONSTANT_17), &((*CONSTANT_18).read_zipper()));
    let v1_35: Space = unite(&(v1_31),&(v1_34));
    let v1_38: Space = routine_1(c, &(*CONSTANT_19), &((*CONSTANT_20).read_zipper()));
    let v1_39: Space = unite(&(v1_35),&(v1_38));
    compose(&(*CONSTANT_0),&(v1_39))
  };
  let mut v0_46 = Space::new();
  let mut v0_46_write = v0_46.write_zipper();
  let mut v0_46_cursor = (v0_40).read_zipper();
  let v0_46_origin = v0_46_cursor.path().len();
  for v0_46_byte in v0_46_cursor.child_mask().iter() {
    v0_46_cursor.descend_to_existing_byte(v0_46_byte);
    {
    let v2_2: Space = singleton(&v0_46_cursor.path()[v0_46_origin..(v0_46_origin + 1)]);
    let v2_3: Space = intersect(&(*CONSTANT_21),&(v2_2));
    let v2_4: Space = if has_head(&(v2_3)) { singleton(&[]) } else { Space::new() };
    drop(v2_3);
    let v2_5: Space = subtract(&(*CONSTANT_0),&(v2_4));
    drop(v2_4);
    let v2_7: Space = if (&(v2_5)).is_empty() { Space::new() } else {
      let v3_6: Space = routine_2(c, &v0_46_cursor.path()[v0_46_origin..(v0_46_origin + 1)], &v0_46_cursor, &((*CONSTANT_22).read_zipper()));
      compose(&(v2_5),&(v3_6))
    };
    drop(v2_5);
    let v2_8: Space = intersect(&(*CONSTANT_21),&(v2_2));
    drop(v2_2);
    let v2_9: Space = if has_head(&(v2_8)) { singleton(&[]) } else { Space::new() };
    drop(v2_8);
    let v2_11: Space = if (&(v2_9)).is_empty() { Space::new() } else {
      let v4_10: Space = routine_3(c, &v0_46_cursor.path()[v0_46_origin..(v0_46_origin + 1)], &v0_46_cursor, &((*CONSTANT_22).read_zipper()));
      compose(&(v2_9),&(v4_10))
    };
    drop(v2_9);
    let v2_12: Space = unite(&(v2_7),&(v2_11));
    join_wrapped_into(&mut v0_46_write,&((v2_12).read_zipper()),&[]);
    }
    v0_46_cursor.ascend(1);
  }
  drop(v0_46_cursor);
  drop(v0_46_write);
  let v0_87: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v5_50: Space = routine_4(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()), &((*CONSTANT_22).read_zipper()));
    let v5_53: Space = routine_4(c, &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()), &((*CONSTANT_22).read_zipper()));
    let v5_54: Space = unite(&(v5_50),&(v5_53));
    let v5_57: Space = routine_4(c, &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()), &((*CONSTANT_22).read_zipper()));
    let v5_58: Space = unite(&(v5_54),&(v5_57));
    let v5_61: Space = routine_4(c, &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()), &((*CONSTANT_22).read_zipper()));
    let v5_62: Space = unite(&(v5_58),&(v5_61));
    let v5_65: Space = routine_4(c, &(*CONSTANT_9), &((*CONSTANT_10).read_zipper()), &((*CONSTANT_22).read_zipper()));
    let v5_66: Space = unite(&(v5_62),&(v5_65));
    let v5_69: Space = routine_4(c, &(*CONSTANT_11), &((*CONSTANT_12).read_zipper()), &((*CONSTANT_22).read_zipper()));
    let v5_70: Space = unite(&(v5_66),&(v5_69));
    let v5_73: Space = routine_4(c, &(*CONSTANT_13), &((*CONSTANT_14).read_zipper()), &((*CONSTANT_22).read_zipper()));
    let v5_74: Space = unite(&(v5_70),&(v5_73));
    let v5_77: Space = routine_4(c, &(*CONSTANT_15), &((*CONSTANT_16).read_zipper()), &((*CONSTANT_22).read_zipper()));
    let v5_78: Space = unite(&(v5_74),&(v5_77));
    let v5_81: Space = routine_4(c, &(*CONSTANT_17), &((*CONSTANT_18).read_zipper()), &((*CONSTANT_22).read_zipper()));
    let v5_82: Space = unite(&(v5_78),&(v5_81));
    let v5_85: Space = routine_4(c, &(*CONSTANT_19), &((*CONSTANT_20).read_zipper()), &((*CONSTANT_22).read_zipper()));
    let v5_86: Space = unite(&(v5_82),&(v5_85));
    compose(&(*CONSTANT_0),&(v5_86))
  };
  let v0_88: Space = unite(&(v0_46),&(v0_87));
  let v0_90: Space = wrap(&(v0_88),&(*CONSTANT_23));
  (v0_90).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v6_8 = Space::new();
  let mut v6_8_write = v6_8.write_zipper();
  let mut v6_8_cursor = (*s0).read_zipper();
  let v6_8_origin = v6_8_cursor.path().len();
  for v6_8_byte in v6_8_cursor.child_mask().iter() {
    v6_8_cursor.descend_to_existing_byte(v6_8_byte);
    {
    let v7_2: Space = singleton(&v6_8_cursor.path()[v6_8_origin..(v6_8_origin + 1)]);
    let v7_3: Space = intersect(&(*CONSTANT_21),&(v7_2));
    let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
    drop(v7_3);
    let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
    drop(v7_4);
    let v7_8: Space = if (&(v7_5)).is_empty() { Space::new() } else {
      let v8_6: Path = concat_path(&(*p0),&v6_8_cursor.path()[v6_8_origin..(v6_8_origin + 1)]);
      let v8_7: Space = routine_1(c, &(v8_6), &v6_8_cursor);
      compose(&(v7_5),&(v8_7))
    };
    drop(v7_5);
    let v7_9: Space = intersect(&(*CONSTANT_21),&(v7_2));
    drop(v7_2);
    let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
    drop(v7_9);
    let v7_12: Space = if (&(v7_10)).is_empty() { Space::new() } else {
      let v9_6: Path = concat_path(&(*p0),&v6_8_cursor.path()[v6_8_origin..(v6_8_origin + 1)]);
      let mut v9_11 = Space::new();
      let mut v9_11_write = v9_11.write_zipper();
      for v9_11_byte in v6_8_cursor.child_mask().iter() {
        v6_8_cursor.descend_to_existing_byte(v9_11_byte);
        {
        let v10_2: Space = singleton(&v6_8_cursor.path()[(v6_8_origin + 1)..(v6_8_origin + 2)]);
        let v10_3: Space = intersect(&(*CONSTANT_21),&(v10_2));
        let v10_4: Space = if has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
        drop(v10_3);
        let v10_5: Space = subtract(&(*CONSTANT_0),&(v10_4));
        drop(v10_4);
        let v10_7: Space = if (&(v10_5)).is_empty() { Space::new() } else {
          let v11_6: Space = routine_5(c, &v6_8_cursor.path()[(v6_8_origin + 1)..(v6_8_origin + 2)], &(v9_6), &v6_8_cursor);
          compose(&(v10_5),&(v11_6))
        };
        drop(v10_5);
        let v10_8: Space = intersect(&(*CONSTANT_21),&(v10_2));
        drop(v10_2);
        let v10_9: Space = if has_head(&(v10_8)) { singleton(&[]) } else { Space::new() };
        drop(v10_8);
        let v10_12: Space = if (&(v10_9)).is_empty() { Space::new() } else {
          let v12_10: Path = concat_path(&(v9_6),&v6_8_cursor.path()[(v6_8_origin + 1)..(v6_8_origin + 2)]);
          let v12_11: Space = routine_6(c, &(v12_10));
          drop(v12_10);
          compose(&(v10_9),&(v12_11))
        };
        drop(v10_9);
        let v10_13: Space = unite(&(v10_7),&(v10_12));
        join_wrapped_into(&mut v9_11_write,&((v10_13).read_zipper()),&[]);
        }
        v6_8_cursor.ascend(1);
      }
      drop(v9_11_write);
      drop(v9_6);
      compose(&(v7_10),&(v9_11))
    };
    drop(v7_10);
    let v7_13: Space = unite(&(v7_8),&(v7_12));
    join_wrapped_into(&mut v6_8_write,&((v7_13).read_zipper()),&[]);
    }
    v6_8_cursor.ascend(1);
  }
  drop(v6_8_cursor);
  drop(v6_8_write);
  (v6_8).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v13_9 = Space::new();
  let mut v13_9_write = v13_9.write_zipper();
  let mut v13_9_cursor = (*s0).read_zipper();
  let v13_9_origin = v13_9_cursor.path().len();
  for v13_9_byte in v13_9_cursor.child_mask().iter() {
    v13_9_cursor.descend_to_existing_byte(v13_9_byte);
    {
    let v14_2: Space = singleton(&v13_9_cursor.path()[v13_9_origin..(v13_9_origin + 1)]);
    let v14_3: Space = intersect(&(*CONSTANT_21),&(v14_2));
    let v14_4: Space = if has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
    drop(v14_3);
    let v14_5: Space = subtract(&(*CONSTANT_0),&(v14_4));
    drop(v14_4);
    let v14_8: Space = if (&(v14_5)).is_empty() { Space::new() } else {
      let v15_6: Path = concat_path(&(*p0),&v13_9_cursor.path()[v13_9_origin..(v13_9_origin + 1)]);
      let v15_7: Space = routine_2(c, &(v15_6), &v13_9_cursor, &(*s1));
      compose(&(v14_5),&(v15_7))
    };
    drop(v14_5);
    let v14_9: Space = intersect(&(*CONSTANT_21),&(v14_2));
    drop(v14_2);
    let v14_10: Space = if has_head(&(v14_9)) { singleton(&[]) } else { Space::new() };
    drop(v14_9);
    let v14_12: Space = if (&(v14_10)).is_empty() { Space::new() } else {
      let v16_6: Path = concat_path(&(*p0),&v13_9_cursor.path()[v13_9_origin..(v13_9_origin + 1)]);
      let mut v16_11 = Space::new();
      let mut v16_11_write = v16_11.write_zipper();
      for v16_11_byte in v13_9_cursor.child_mask().iter() {
        v13_9_cursor.descend_to_existing_byte(v16_11_byte);
        {
        let v17_2: Space = singleton(&v13_9_cursor.path()[(v13_9_origin + 1)..(v13_9_origin + 2)]);
        let v17_3: Space = intersect(&(*CONSTANT_21),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_0),&(v17_4));
        drop(v17_4);
        let v17_7: Space = if (&(v17_5)).is_empty() { Space::new() } else {
          let v18_6: Space = routine_7(c, &v13_9_cursor.path()[(v13_9_origin + 1)..(v13_9_origin + 2)], &(v16_6), &v13_9_cursor, &(*s1));
          compose(&(v17_5),&(v18_6))
        };
        drop(v17_5);
        let v17_8: Space = intersect(&(*CONSTANT_21),&(v17_2));
        drop(v17_2);
        let v17_9: Space = if has_head(&(v17_8)) { singleton(&[]) } else { Space::new() };
        drop(v17_8);
        let v17_11: Space = if (&(v17_9)).is_empty() { Space::new() } else {
          let v19_10: Space = routine_8(c, &v13_9_cursor.path()[(v13_9_origin + 1)..(v13_9_origin + 2)], &(v16_6), &v13_9_cursor, &(*s1));
          compose(&(v17_9),&(v19_10))
        };
        drop(v17_9);
        let v17_12: Space = unite(&(v17_7),&(v17_11));
        join_wrapped_into(&mut v16_11_write,&((v17_12).read_zipper()),&[]);
        }
        v13_9_cursor.ascend(1);
      }
      drop(v16_11_write);
      drop(v16_6);
      compose(&(v14_10),&(v16_11))
    };
    drop(v14_10);
    let v14_13: Space = unite(&(v14_8),&(v14_12));
    join_wrapped_into(&mut v13_9_write,&((v14_13).read_zipper()),&[]);
    }
    v13_9_cursor.ascend(1);
  }
  drop(v13_9_cursor);
  drop(v13_9_write);
  (v13_9).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v20_28 = Space::new();
  let mut v20_28_write = v20_28.write_zipper();
  let mut v20_28_cursor = (*s0).read_zipper();
  let v20_28_origin = v20_28_cursor.path().len();
  for v20_28_byte in v20_28_cursor.child_mask().iter() {
    v20_28_cursor.descend_to_existing_byte(v20_28_byte);
    {
    let v21_2: Space = singleton(&v20_28_cursor.path()[v20_28_origin..(v20_28_origin + 1)]);
    let v21_3: Space = intersect(&(*CONSTANT_21),&(v21_2));
    let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
    drop(v21_3);
    let v21_5: Space = subtract(&(*CONSTANT_0),&(v21_4));
    drop(v21_4);
    let v21_7: Space = if (&(v21_5)).is_empty() { Space::new() } else {
      let mut v22_6 = Space::new();
      let mut v22_6_write = v22_6.write_zipper();
      for v22_6_byte in v20_28_cursor.child_mask().iter() {
        v20_28_cursor.descend_to_existing_byte(v22_6_byte);
        {
        let v23_2: Space = singleton(&v20_28_cursor.path()[(v20_28_origin + 1)..(v20_28_origin + 2)]);
        let v23_3: Space = intersect(&(*CONSTANT_21),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_0),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (&(v23_5)).is_empty() { Space::new() } else {
          let v24_7: Space = routine_7(c, &v20_28_cursor.path()[v20_28_origin..(v20_28_origin + 2)], &(*p0), &v20_28_cursor, &(*s1));
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_21),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_12: Space = if (&(v23_10)).is_empty() { Space::new() } else {
          let v25_11: Space = routine_8(c, &v20_28_cursor.path()[v20_28_origin..(v20_28_origin + 2)], &(*p0), &v20_28_cursor, &(*s1));
          compose(&(v23_10),&(v25_11))
        };
        drop(v23_10);
        let v23_13: Space = unite(&(v23_8),&(v23_12));
        join_wrapped_into(&mut v22_6_write,&((v23_13).read_zipper()),&[]);
        }
        v20_28_cursor.ascend(1);
      }
      drop(v22_6_write);
      compose(&(v21_5),&(v22_6))
    };
    drop(v21_5);
    let v21_8: Space = intersect(&(*CONSTANT_21),&(v21_2));
    drop(v21_2);
    let v21_9: Space = if has_head(&(v21_8)) { singleton(&[]) } else { Space::new() };
    drop(v21_8);
    let v21_23: Space = if (&(v21_9)).is_empty() { Space::new() } else {
      let v26_10: Path = concat_path(&(*p0),&v20_28_cursor.path()[v20_28_origin..(v20_28_origin + 1)]);
      let v26_11: Space = singleton(&(v26_10));
      drop(v26_10);
      let mut v26_12 = Space::new();
      let mut v26_12_write = v26_12.write_zipper();
      let mut v26_12_cursor = (v26_11).read_zipper();
      let v26_12_origin = v26_12_cursor.path().len();
      for v26_12_byte in v26_12_cursor.child_mask().iter() {
        v26_12_cursor.descend_to_existing_byte(v26_12_byte);
        {
        let v27_2: Space = singleton(&v26_12_cursor.path()[v26_12_origin..(v26_12_origin + 1)]);
        let v27_3: Space = intersect(&(*CONSTANT_21),&(v27_2));
        let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
        drop(v27_3);
        let v27_5: Space = subtract(&(*CONSTANT_0),&(v27_4));
        drop(v27_4);
        let v27_7: Space = if (&(v27_5)).is_empty() { Space::new() } else {
          let v28_6: Space = routine_9(c, &v26_12_cursor.path()[v26_12_origin..(v26_12_origin + 1)], &v26_12_cursor);
          compose(&(v27_5),&(v28_6))
        };
        drop(v27_5);
        let v27_8: Space = intersect(&(*CONSTANT_21),&(v27_2));
        drop(v27_2);
        let v27_9: Space = if has_head(&(v27_8)) { singleton(&[]) } else { Space::new() };
        drop(v27_8);
        let v27_11: Space = if (&(v27_9)).is_empty() { Space::new() } else {
          let v29_10: Space = routine_10(c, &v26_12_cursor.path()[v26_12_origin..(v26_12_origin + 1)], &v26_12_cursor);
          compose(&(v27_9),&(v29_10))
        };
        drop(v27_9);
        let v27_12: Space = unite(&(v27_7),&(v27_11));
        join_wrapped_into(&mut v26_12_write,&((v27_12).read_zipper()),&[]);
        }
        v26_12_cursor.ascend(1);
      }
      drop(v26_12_cursor);
      drop(v26_12_write);
      let v26_13: Space = intersect(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))),&(v26_12));
      let v26_14: Space = range_const::<{3},{4}>(&(v26_13));
      let mut v26_15 = Space::new();
      let mut v26_15_write = v26_15.write_zipper();
      let mut v26_15_cursor = (v26_14).read_zipper();
      let v26_15_origin = v26_15_cursor.path().len();
      for v26_15_byte in v26_15_cursor.child_mask().iter() {
        v26_15_cursor.descend_to_existing_byte(v26_15_byte);
        {
        let v30_2: Space = singleton(&v26_15_cursor.path()[v26_15_origin..(v26_15_origin + 1)]);
        let v30_3: Space = intersect(&(*CONSTANT_21),&(v30_2));
        let v30_4: Space = if has_head(&(v30_3)) { singleton(&[]) } else { Space::new() };
        drop(v30_3);
        let v30_5: Space = subtract(&(*CONSTANT_0),&(v30_4));
        drop(v30_4);
        let v30_7: Space = if (&(v30_5)).is_empty() { Space::new() } else {
          let v31_6: Space = routine_11(c, &v26_15_cursor.path()[v26_15_origin..(v26_15_origin + 1)], &v26_15_cursor);
          compose(&(v30_5),&(v31_6))
        };
        drop(v30_5);
        let v30_8: Space = intersect(&(*CONSTANT_21),&(v30_2));
        drop(v30_2);
        let v30_9: Space = if has_head(&(v30_8)) { singleton(&[]) } else { Space::new() };
        drop(v30_8);
        let v30_10: Space = compose(&(v30_9),&(*CONSTANT_24));
        drop(v30_9);
        let v30_11: Space = unite(&(v30_7),&(v30_10));
        drop(v30_10);
        join_wrapped_into(&mut v26_15_write,&((v30_11).read_zipper()),&[]);
        }
        v26_15_cursor.ascend(1);
      }
      drop(v26_15_cursor);
      drop(v26_15_write);
      let mut v26_16 = Space::new();
      let mut v26_16_write = v26_16.write_zipper();
      let mut v26_16_cursor = (v26_11).read_zipper();
      let v26_16_origin = v26_16_cursor.path().len();
      for v26_16_byte in v26_16_cursor.child_mask().iter() {
        v26_16_cursor.descend_to_existing_byte(v26_16_byte);
        {
        let v32_2: Space = singleton(&v26_16_cursor.path()[v26_16_origin..(v26_16_origin + 1)]);
        let v32_3: Space = intersect(&(*CONSTANT_21),&(v32_2));
        let v32_4: Space = if has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
        drop(v32_3);
        let v32_5: Space = subtract(&(*CONSTANT_0),&(v32_4));
        drop(v32_4);
        let v32_7: Space = if (&(v32_5)).is_empty() { Space::new() } else {
          let v33_6: Space = routine_9(c, &v26_16_cursor.path()[v26_16_origin..(v26_16_origin + 1)], &v26_16_cursor);
          compose(&(v32_5),&(v33_6))
        };
        drop(v32_5);
        let v32_8: Space = intersect(&(*CONSTANT_21),&(v32_2));
        drop(v32_2);
        let v32_9: Space = if has_head(&(v32_8)) { singleton(&[]) } else { Space::new() };
        drop(v32_8);
        let v32_11: Space = if (&(v32_9)).is_empty() { Space::new() } else {
          let v34_10: Space = routine_10(c, &v26_16_cursor.path()[v26_16_origin..(v26_16_origin + 1)], &v26_16_cursor);
          compose(&(v32_9),&(v34_10))
        };
        drop(v32_9);
        let v32_12: Space = unite(&(v32_7),&(v32_11));
        join_wrapped_into(&mut v26_16_write,&((v32_12).read_zipper()),&[]);
        }
        v26_16_cursor.ascend(1);
      }
      drop(v26_16_cursor);
      drop(v26_16_write);
      let v26_17: Space = intersect(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))),&(v26_16));
      let v26_18: Space = range_const::<{4},{5}>(&(v26_17));
      let mut v26_19 = Space::new();
      let mut v26_19_write = v26_19.write_zipper();
      let mut v26_19_cursor = (v26_18).read_zipper();
      let v26_19_origin = v26_19_cursor.path().len();
      for v26_19_byte in v26_19_cursor.child_mask().iter() {
        v26_19_cursor.descend_to_existing_byte(v26_19_byte);
        {
        let v35_2: Space = singleton(&v26_19_cursor.path()[v26_19_origin..(v26_19_origin + 1)]);
        let v35_3: Space = intersect(&(*CONSTANT_21),&(v35_2));
        let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
        drop(v35_3);
        let v35_5: Space = subtract(&(*CONSTANT_0),&(v35_4));
        drop(v35_4);
        let v35_7: Space = if (&(v35_5)).is_empty() { Space::new() } else {
          let v36_6: Space = routine_12(c, &v26_19_cursor.path()[v26_19_origin..(v26_19_origin + 1)], &v26_19_cursor);
          compose(&(v35_5),&(v36_6))
        };
        drop(v35_5);
        let v35_8: Space = intersect(&(*CONSTANT_21),&(v35_2));
        drop(v35_2);
        let v35_9: Space = if has_head(&(v35_8)) { singleton(&[]) } else { Space::new() };
        drop(v35_8);
        let v35_10: Space = compose(&(v35_9),&(*CONSTANT_24));
        drop(v35_9);
        let v35_11: Space = unite(&(v35_7),&(v35_10));
        drop(v35_10);
        join_wrapped_into(&mut v26_19_write,&((v35_11).read_zipper()),&[]);
        }
        v26_19_cursor.ascend(1);
      }
      drop(v26_19_cursor);
      drop(v26_19_write);
      let v26_20: Space = subtract(&(v26_15),&(v26_19));
      let v26_21: Space = if (&(v26_20)).is_empty() { Space::new() } else {
        compose(&(v26_20),&(v26_11))
      };
      drop(v26_11);
      let mut v26_22 = Space::new();
      let mut v26_22_write = v26_22.write_zipper();
      let mut v26_22_cursor = (v26_21).read_zipper();
      let v26_22_origin = v26_22_cursor.path().len();
      for v26_22_byte in v26_22_cursor.child_mask().iter() {
        v26_22_cursor.descend_to_existing_byte(v26_22_byte);
        {
        let v38_2: Space = singleton(&v26_22_cursor.path()[v26_22_origin..(v26_22_origin + 1)]);
        let v38_3: Space = intersect(&(*CONSTANT_21),&(v38_2));
        let v38_4: Space = if has_head(&(v38_3)) { singleton(&[]) } else { Space::new() };
        drop(v38_3);
        let v38_5: Space = subtract(&(*CONSTANT_0),&(v38_4));
        drop(v38_4);
        let v38_7: Space = if (&(v38_5)).is_empty() { Space::new() } else {
          let v39_6: Space = routine_13(c, &v26_22_cursor.path()[v26_22_origin..(v26_22_origin + 1)], &v26_22_cursor);
          compose(&(v38_5),&(v39_6))
        };
        drop(v38_5);
        let v38_8: Space = intersect(&(*CONSTANT_21),&(v38_2));
        drop(v38_2);
        let v38_9: Space = if has_head(&(v38_8)) { singleton(&[]) } else { Space::new() };
        drop(v38_8);
        let v38_10: Space = compose(&(v38_9),&v26_22_cursor);
        drop(v38_9);
        let v38_11: Space = unite(&(v38_7),&(v38_10));
        drop(v38_10);
        join_wrapped_into(&mut v26_22_write,&((v38_11).read_zipper()),&[]);
        }
        v26_22_cursor.ascend(1);
      }
      drop(v26_22_cursor);
      drop(v26_22_write);
      compose(&(v21_9),&(v26_22))
    };
    drop(v21_9);
    let v21_24: Space = unite(&(v21_7),&(v21_23));
    join_wrapped_into(&mut v20_28_write,&((v21_24).read_zipper()),&[]);
    }
    v20_28_cursor.ascend(1);
  }
  drop(v20_28_cursor);
  drop(v20_28_write);
  (v20_28).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v40_9 = Space::new();
  let mut v40_9_write = v40_9.write_zipper();
  let mut v40_9_cursor = (*s0).read_zipper();
  let v40_9_origin = v40_9_cursor.path().len();
  for v40_9_byte in v40_9_cursor.child_mask().iter() {
    v40_9_cursor.descend_to_existing_byte(v40_9_byte);
    {
    let v41_2: Space = singleton(&v40_9_cursor.path()[v40_9_origin..(v40_9_origin + 1)]);
    let v41_3: Space = intersect(&(*CONSTANT_21),&(v41_2));
    let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
    drop(v41_3);
    let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
    drop(v41_4);
    let v41_8: Space = if (&(v41_5)).is_empty() { Space::new() } else {
      let v42_6: Path = concat_path(&(*p0),&v40_9_cursor.path()[v40_9_origin..(v40_9_origin + 1)]);
      let v42_7: Space = routine_4(c, &(v42_6), &v40_9_cursor, &(*s1));
      compose(&(v41_5),&(v42_7))
    };
    drop(v41_5);
    let v41_9: Space = intersect(&(*CONSTANT_21),&(v41_2));
    drop(v41_2);
    let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
    drop(v41_9);
    let v41_12: Space = if (&(v41_10)).is_empty() { Space::new() } else {
      let v43_6: Path = concat_path(&(*p0),&v40_9_cursor.path()[v40_9_origin..(v40_9_origin + 1)]);
      let mut v43_11 = Space::new();
      let mut v43_11_write = v43_11.write_zipper();
      for v43_11_byte in v40_9_cursor.child_mask().iter() {
        v40_9_cursor.descend_to_existing_byte(v43_11_byte);
        {
        let v44_2: Space = singleton(&v40_9_cursor.path()[(v40_9_origin + 1)..(v40_9_origin + 2)]);
        let v44_3: Space = intersect(&(*CONSTANT_21),&(v44_2));
        let v44_4: Space = if has_head(&(v44_3)) { singleton(&[]) } else { Space::new() };
        drop(v44_3);
        let v44_5: Space = subtract(&(*CONSTANT_0),&(v44_4));
        drop(v44_4);
        let v44_7: Space = if (&(v44_5)).is_empty() { Space::new() } else {
          let v45_6: Space = routine_14(c, &v40_9_cursor.path()[(v40_9_origin + 1)..(v40_9_origin + 2)], &(v43_6), &v40_9_cursor, &(*s1));
          compose(&(v44_5),&(v45_6))
        };
        drop(v44_5);
        let v44_8: Space = intersect(&(*CONSTANT_21),&(v44_2));
        drop(v44_2);
        let v44_9: Space = if has_head(&(v44_8)) { singleton(&[]) } else { Space::new() };
        drop(v44_8);
        let v44_11: Space = if (&(v44_9)).is_empty() { Space::new() } else {
          let v46_10: Space = routine_15(c, &v40_9_cursor.path()[(v40_9_origin + 1)..(v40_9_origin + 2)], &(v43_6), &v40_9_cursor, &(*s1));
          compose(&(v44_9),&(v46_10))
        };
        drop(v44_9);
        let v44_12: Space = unite(&(v44_7),&(v44_11));
        join_wrapped_into(&mut v43_11_write,&((v44_12).read_zipper()),&[]);
        }
        v40_9_cursor.ascend(1);
      }
      drop(v43_11_write);
      drop(v43_6);
      compose(&(v41_10),&(v43_11))
    };
    drop(v41_10);
    let v41_13: Space = unite(&(v41_8),&(v41_12));
    join_wrapped_into(&mut v40_9_write,&((v41_13).read_zipper()),&[]);
    }
    v40_9_cursor.ascend(1);
  }
  drop(v40_9_cursor);
  drop(v40_9_write);
  (v40_9).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v47_9 = Space::new();
  let mut v47_9_write = v47_9.write_zipper();
  let mut v47_9_cursor = (*s0).read_zipper();
  let v47_9_origin = v47_9_cursor.path().len();
  for v47_9_byte in v47_9_cursor.child_mask().iter() {
    v47_9_cursor.descend_to_existing_byte(v47_9_byte);
    {
    let v48_2: Space = singleton(&v47_9_cursor.path()[v47_9_origin..(v47_9_origin + 1)]);
    let v48_3: Space = intersect(&(*CONSTANT_21),&(v48_2));
    let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
    drop(v48_3);
    let v48_5: Space = subtract(&(*CONSTANT_0),&(v48_4));
    drop(v48_4);
    let v48_8: Space = if (&(v48_5)).is_empty() { Space::new() } else {
      let v49_6: Path = concat_path(&(*p0),&v47_9_cursor.path()[v47_9_origin..(v47_9_origin + 1)]);
      let v49_7: Space = routine_5(c, &(v49_6), &(*p1), &v47_9_cursor);
      compose(&(v48_5),&(v49_7))
    };
    drop(v48_5);
    let v48_9: Space = intersect(&(*CONSTANT_21),&(v48_2));
    drop(v48_2);
    let v48_10: Space = if has_head(&(v48_9)) { singleton(&[]) } else { Space::new() };
    drop(v48_9);
    let v48_14: Space = if (&(v48_10)).is_empty() { Space::new() } else {
      let v50_6: Path = concat_path(&(*p0),&v47_9_cursor.path()[v47_9_origin..(v47_9_origin + 1)]);
      let v50_11: Path = concat_path(&(*p1),&(v50_6));
      drop(v50_6);
      let v50_12: Space = singleton(&(v50_11));
      drop(v50_11);
      let mut v50_13 = Space::new();
      let mut v50_13_write = v50_13.write_zipper();
      let mut v50_13_cursor = (v50_12).read_zipper();
      let v50_13_origin = v50_13_cursor.path().len();
      for v50_13_byte in v50_13_cursor.child_mask().iter() {
        v50_13_cursor.descend_to_existing_byte(v50_13_byte);
        {
        let v51_2: Space = singleton(&v50_13_cursor.path()[v50_13_origin..(v50_13_origin + 1)]);
        let v51_3: Space = intersect(&(*CONSTANT_21),&(v51_2));
        let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
        drop(v51_3);
        let v51_5: Space = subtract(&(*CONSTANT_0),&(v51_4));
        drop(v51_4);
        let v51_7: Space = if (&(v51_5)).is_empty() { Space::new() } else {
          let v52_6: Space = routine_9(c, &v50_13_cursor.path()[v50_13_origin..(v50_13_origin + 1)], &v50_13_cursor);
          compose(&(v51_5),&(v52_6))
        };
        drop(v51_5);
        let v51_8: Space = intersect(&(*CONSTANT_21),&(v51_2));
        drop(v51_2);
        let v51_9: Space = if has_head(&(v51_8)) { singleton(&[]) } else { Space::new() };
        drop(v51_8);
        let v51_11: Space = if (&(v51_9)).is_empty() { Space::new() } else {
          let v53_10: Space = routine_10(c, &v50_13_cursor.path()[v50_13_origin..(v50_13_origin + 1)], &v50_13_cursor);
          compose(&(v51_9),&(v53_10))
        };
        drop(v51_9);
        let v51_12: Space = unite(&(v51_7),&(v51_11));
        join_wrapped_into(&mut v50_13_write,&((v51_12).read_zipper()),&[]);
        }
        v50_13_cursor.ascend(1);
      }
      drop(v50_13_cursor);
      drop(v50_13_write);
      drop(v50_12);
      compose(&(v48_10),&(v50_13))
    };
    drop(v48_10);
    let v48_15: Space = unite(&(v48_8),&(v48_14));
    join_wrapped_into(&mut v47_9_write,&((v48_15).read_zipper()),&[]);
    }
    v47_9_cursor.ascend(1);
  }
  drop(v47_9_cursor);
  drop(v47_9_write);
  (v47_9).clone()
}

#[inline(always)]
fn routine_6(c: &mut Context, p0: &[u8]) -> Space {
  let v54_1: Space = singleton(&(*p0));
  let mut v54_16 = Space::new();
  let mut v54_16_write = v54_16.write_zipper();
  let mut v54_16_cursor = (v54_1).read_zipper();
  let v54_16_origin = v54_16_cursor.path().len();
  for v54_16_byte in v54_16_cursor.child_mask().iter() {
    v54_16_cursor.descend_to_existing_byte(v54_16_byte);
    {
    let v55_2: Space = singleton(&v54_16_cursor.path()[v54_16_origin..(v54_16_origin + 1)]);
    let v55_3: Space = intersect(&(*CONSTANT_21),&(v55_2));
    let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
    drop(v55_3);
    let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
    drop(v55_4);
    let v55_7: Space = if (&(v55_5)).is_empty() { Space::new() } else {
      let mut v56_6 = Space::new();
      let mut v56_6_write = v56_6.write_zipper();
      for v56_6_byte in v54_16_cursor.child_mask().iter() {
        v54_16_cursor.descend_to_existing_byte(v56_6_byte);
        {
        let v57_2: Space = singleton(&v54_16_cursor.path()[(v54_16_origin + 1)..(v54_16_origin + 2)]);
        let v57_3: Space = intersect(&(*CONSTANT_21),&(v57_2));
        let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = subtract(&(*CONSTANT_0),&(v57_4));
        drop(v57_4);
        let v57_8: Space = if (&(v57_5)).is_empty() { Space::new() } else {
          let v58_7: Space = routine_9(c, &v54_16_cursor.path()[v54_16_origin..(v54_16_origin + 2)], &v54_16_cursor);
          compose(&(v57_5),&(v58_7))
        };
        drop(v57_5);
        let v57_9: Space = intersect(&(*CONSTANT_21),&(v57_2));
        drop(v57_2);
        let v57_10: Space = if has_head(&(v57_9)) { singleton(&[]) } else { Space::new() };
        drop(v57_9);
        let v57_12: Space = if (&(v57_10)).is_empty() { Space::new() } else {
          let mut v59_11 = Space::new();
          let mut v59_11_write = v59_11.write_zipper();
          for v59_11_byte in v54_16_cursor.child_mask().iter() {
            v54_16_cursor.descend_to_existing_byte(v59_11_byte);
            {
            let v60_2: Space = singleton(&v54_16_cursor.path()[(v54_16_origin + 2)..(v54_16_origin + 3)]);
            let v60_3: Space = intersect(&(*CONSTANT_21),&(v60_2));
            let v60_4: Space = if has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
            drop(v60_3);
            let v60_5: Space = subtract(&(*CONSTANT_0),&(v60_4));
            drop(v60_4);
            let v60_7: Space = if (&(v60_5)).is_empty() { Space::new() } else {
              let v61_6: Space = routine_16(c, &v54_16_cursor.path()[(v54_16_origin + 2)..(v54_16_origin + 3)], &v54_16_cursor.path()[v54_16_origin..(v54_16_origin + 2)], &v54_16_cursor);
              compose(&(v60_5),&(v61_6))
            };
            drop(v60_5);
            let v60_8: Space = intersect(&(*CONSTANT_21),&(v60_2));
            drop(v60_2);
            let v60_9: Space = if has_head(&(v60_8)) { singleton(&[]) } else { Space::new() };
            drop(v60_8);
            let v60_11: Space = if (&(v60_9)).is_empty() { Space::new() } else {
              let v62_10: Space = routine_17(c, &v54_16_cursor.path()[(v54_16_origin + 2)..(v54_16_origin + 3)], &v54_16_cursor.path()[v54_16_origin..(v54_16_origin + 2)], &v54_16_cursor);
              compose(&(v60_9),&(v62_10))
            };
            drop(v60_9);
            let v60_12: Space = unite(&(v60_7),&(v60_11));
            join_wrapped_into(&mut v59_11_write,&((v60_12).read_zipper()),&[]);
            }
            v54_16_cursor.ascend(1);
          }
          drop(v59_11_write);
          compose(&(v57_10),&(v59_11))
        };
        drop(v57_10);
        let v57_13: Space = unite(&(v57_8),&(v57_12));
        join_wrapped_into(&mut v56_6_write,&((v57_13).read_zipper()),&[]);
        }
        v54_16_cursor.ascend(1);
      }
      drop(v56_6_write);
      compose(&(v55_5),&(v56_6))
    };
    drop(v55_5);
    let v55_8: Space = intersect(&(*CONSTANT_21),&(v55_2));
    drop(v55_2);
    let v55_9: Space = if has_head(&(v55_8)) { singleton(&[]) } else { Space::new() };
    drop(v55_8);
    let v55_12: Space = if (&(v55_9)).is_empty() { Space::new() } else {
      let mut v63_11 = Space::new();
      let mut v63_11_write = v63_11.write_zipper();
      for v63_11_byte in v54_16_cursor.child_mask().iter() {
        v54_16_cursor.descend_to_existing_byte(v63_11_byte);
        {
        let v64_2: Space = singleton(&v54_16_cursor.path()[(v54_16_origin + 1)..(v54_16_origin + 2)]);
        let v64_3: Space = intersect(&(*CONSTANT_21),&(v64_2));
        let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
        drop(v64_3);
        let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
        drop(v64_4);
        let v64_7: Space = if (&(v64_5)).is_empty() { Space::new() } else {
          let v65_6: Space = routine_16(c, &v54_16_cursor.path()[(v54_16_origin + 1)..(v54_16_origin + 2)], &v54_16_cursor.path()[v54_16_origin..(v54_16_origin + 1)], &v54_16_cursor);
          compose(&(v64_5),&(v65_6))
        };
        drop(v64_5);
        let v64_8: Space = intersect(&(*CONSTANT_21),&(v64_2));
        drop(v64_2);
        let v64_9: Space = if has_head(&(v64_8)) { singleton(&[]) } else { Space::new() };
        drop(v64_8);
        let v64_15: Space = if (&(v64_9)).is_empty() { Space::new() } else {
          let v66_11: Space = if (&(descend_cursor((*CONSTANT_25).read_zipper(),&v54_16_cursor.path()[v54_16_origin..(v54_16_origin + 1)]))).is_empty() { Space::new() } else {
            compose(&(descend_cursor((*CONSTANT_25).read_zipper(),&v54_16_cursor.path()[v54_16_origin..(v54_16_origin + 1)])),&(descend_cursor((*CONSTANT_25).read_zipper(),&v54_16_cursor.path()[(v54_16_origin + 1)..(v54_16_origin + 2)])))
          };
          let v66_13: Space = singleton(&v54_16_cursor.path()[v54_16_origin..(v54_16_origin + 2)]);
          let v66_14: Space = subtract(&(v66_11),&(v66_13));
          drop(v66_11);
          drop(v66_13);
          compose(&(v64_9),&(v66_14))
        };
        drop(v64_9);
        let v64_16: Space = unite(&(v64_7),&(v64_15));
        drop(v64_15);
        join_wrapped_into(&mut v63_11_write,&((v64_16).read_zipper()),&[]);
        }
        v54_16_cursor.ascend(1);
      }
      drop(v63_11_write);
      compose(&(v55_9),&(v63_11))
    };
    drop(v55_9);
    let v55_13: Space = unite(&(v55_7),&(v55_12));
    join_wrapped_into(&mut v54_16_write,&((v55_13).read_zipper()),&[]);
    }
    v54_16_cursor.ascend(1);
  }
  drop(v54_16_cursor);
  drop(v54_16_write);
  drop(v54_1);
  (v54_16).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v68_26 = Space::new();
  let mut v68_26_write = v68_26.write_zipper();
  let mut v68_26_cursor = (*s0).read_zipper();
  let v68_26_origin = v68_26_cursor.path().len();
  for v68_26_byte in v68_26_cursor.child_mask().iter() {
    v68_26_cursor.descend_to_existing_byte(v68_26_byte);
    {
    let v69_2: Space = singleton(&v68_26_cursor.path()[v68_26_origin..(v68_26_origin + 1)]);
    let v69_3: Space = intersect(&(*CONSTANT_21),&(v69_2));
    let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
    drop(v69_3);
    let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
    drop(v69_4);
    let v69_8: Space = if (&(v69_5)).is_empty() { Space::new() } else {
      let v70_6: Path = concat_path(&(*p0),&v68_26_cursor.path()[v68_26_origin..(v68_26_origin + 1)]);
      let v70_7: Space = routine_7(c, &(v70_6), &(*p1), &v68_26_cursor, &(*s1));
      compose(&(v69_5),&(v70_7))
    };
    drop(v69_5);
    let v69_9: Space = intersect(&(*CONSTANT_21),&(v69_2));
    drop(v69_2);
    let v69_10: Space = if has_head(&(v69_9)) { singleton(&[]) } else { Space::new() };
    drop(v69_9);
    let v69_24: Space = if (&(v69_10)).is_empty() { Space::new() } else {
      let v71_6: Path = concat_path(&(*p0),&v68_26_cursor.path()[v68_26_origin..(v68_26_origin + 1)]);
      let v71_11: Path = concat_path(&(*p1),&(v71_6));
      drop(v71_6);
      let v71_12: Space = singleton(&(v71_11));
      drop(v71_11);
      let mut v71_13 = Space::new();
      let mut v71_13_write = v71_13.write_zipper();
      let mut v71_13_cursor = (v71_12).read_zipper();
      let v71_13_origin = v71_13_cursor.path().len();
      for v71_13_byte in v71_13_cursor.child_mask().iter() {
        v71_13_cursor.descend_to_existing_byte(v71_13_byte);
        {
        let v72_2: Space = singleton(&v71_13_cursor.path()[v71_13_origin..(v71_13_origin + 1)]);
        let v72_3: Space = intersect(&(*CONSTANT_21),&(v72_2));
        let v72_4: Space = if has_head(&(v72_3)) { singleton(&[]) } else { Space::new() };
        drop(v72_3);
        let v72_5: Space = subtract(&(*CONSTANT_0),&(v72_4));
        drop(v72_4);
        let v72_7: Space = if (&(v72_5)).is_empty() { Space::new() } else {
          let v73_6: Space = routine_9(c, &v71_13_cursor.path()[v71_13_origin..(v71_13_origin + 1)], &v71_13_cursor);
          compose(&(v72_5),&(v73_6))
        };
        drop(v72_5);
        let v72_8: Space = intersect(&(*CONSTANT_21),&(v72_2));
        drop(v72_2);
        let v72_9: Space = if has_head(&(v72_8)) { singleton(&[]) } else { Space::new() };
        drop(v72_8);
        let v72_11: Space = if (&(v72_9)).is_empty() { Space::new() } else {
          let v74_10: Space = routine_10(c, &v71_13_cursor.path()[v71_13_origin..(v71_13_origin + 1)], &v71_13_cursor);
          compose(&(v72_9),&(v74_10))
        };
        drop(v72_9);
        let v72_12: Space = unite(&(v72_7),&(v72_11));
        join_wrapped_into(&mut v71_13_write,&((v72_12).read_zipper()),&[]);
        }
        v71_13_cursor.ascend(1);
      }
      drop(v71_13_cursor);
      drop(v71_13_write);
      let v71_14: Space = intersect(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))),&(v71_13));
      let v71_15: Space = range_const::<{3},{4}>(&(v71_14));
      let mut v71_16 = Space::new();
      let mut v71_16_write = v71_16.write_zipper();
      let mut v71_16_cursor = (v71_15).read_zipper();
      let v71_16_origin = v71_16_cursor.path().len();
      for v71_16_byte in v71_16_cursor.child_mask().iter() {
        v71_16_cursor.descend_to_existing_byte(v71_16_byte);
        {
        let v75_2: Space = singleton(&v71_16_cursor.path()[v71_16_origin..(v71_16_origin + 1)]);
        let v75_3: Space = intersect(&(*CONSTANT_21),&(v75_2));
        let v75_4: Space = if has_head(&(v75_3)) { singleton(&[]) } else { Space::new() };
        drop(v75_3);
        let v75_5: Space = subtract(&(*CONSTANT_0),&(v75_4));
        drop(v75_4);
        let v75_7: Space = if (&(v75_5)).is_empty() { Space::new() } else {
          let v76_6: Space = routine_11(c, &v71_16_cursor.path()[v71_16_origin..(v71_16_origin + 1)], &v71_16_cursor);
          compose(&(v75_5),&(v76_6))
        };
        drop(v75_5);
        let v75_8: Space = intersect(&(*CONSTANT_21),&(v75_2));
        drop(v75_2);
        let v75_9: Space = if has_head(&(v75_8)) { singleton(&[]) } else { Space::new() };
        drop(v75_8);
        let v75_10: Space = compose(&(v75_9),&(*CONSTANT_24));
        drop(v75_9);
        let v75_11: Space = unite(&(v75_7),&(v75_10));
        drop(v75_10);
        join_wrapped_into(&mut v71_16_write,&((v75_11).read_zipper()),&[]);
        }
        v71_16_cursor.ascend(1);
      }
      drop(v71_16_cursor);
      drop(v71_16_write);
      let mut v71_17 = Space::new();
      let mut v71_17_write = v71_17.write_zipper();
      let mut v71_17_cursor = (v71_12).read_zipper();
      let v71_17_origin = v71_17_cursor.path().len();
      for v71_17_byte in v71_17_cursor.child_mask().iter() {
        v71_17_cursor.descend_to_existing_byte(v71_17_byte);
        {
        let v77_2: Space = singleton(&v71_17_cursor.path()[v71_17_origin..(v71_17_origin + 1)]);
        let v77_3: Space = intersect(&(*CONSTANT_21),&(v77_2));
        let v77_4: Space = if has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
        drop(v77_3);
        let v77_5: Space = subtract(&(*CONSTANT_0),&(v77_4));
        drop(v77_4);
        let v77_7: Space = if (&(v77_5)).is_empty() { Space::new() } else {
          let v78_6: Space = routine_9(c, &v71_17_cursor.path()[v71_17_origin..(v71_17_origin + 1)], &v71_17_cursor);
          compose(&(v77_5),&(v78_6))
        };
        drop(v77_5);
        let v77_8: Space = intersect(&(*CONSTANT_21),&(v77_2));
        drop(v77_2);
        let v77_9: Space = if has_head(&(v77_8)) { singleton(&[]) } else { Space::new() };
        drop(v77_8);
        let v77_11: Space = if (&(v77_9)).is_empty() { Space::new() } else {
          let v79_10: Space = routine_10(c, &v71_17_cursor.path()[v71_17_origin..(v71_17_origin + 1)], &v71_17_cursor);
          compose(&(v77_9),&(v79_10))
        };
        drop(v77_9);
        let v77_12: Space = unite(&(v77_7),&(v77_11));
        join_wrapped_into(&mut v71_17_write,&((v77_12).read_zipper()),&[]);
        }
        v71_17_cursor.ascend(1);
      }
      drop(v71_17_cursor);
      drop(v71_17_write);
      let v71_18: Space = intersect(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))),&(v71_17));
      let v71_19: Space = range_const::<{4},{5}>(&(v71_18));
      let mut v71_20 = Space::new();
      let mut v71_20_write = v71_20.write_zipper();
      let mut v71_20_cursor = (v71_19).read_zipper();
      let v71_20_origin = v71_20_cursor.path().len();
      for v71_20_byte in v71_20_cursor.child_mask().iter() {
        v71_20_cursor.descend_to_existing_byte(v71_20_byte);
        {
        let v80_2: Space = singleton(&v71_20_cursor.path()[v71_20_origin..(v71_20_origin + 1)]);
        let v80_3: Space = intersect(&(*CONSTANT_21),&(v80_2));
        let v80_4: Space = if has_head(&(v80_3)) { singleton(&[]) } else { Space::new() };
        drop(v80_3);
        let v80_5: Space = subtract(&(*CONSTANT_0),&(v80_4));
        drop(v80_4);
        let v80_7: Space = if (&(v80_5)).is_empty() { Space::new() } else {
          let v81_6: Space = routine_12(c, &v71_20_cursor.path()[v71_20_origin..(v71_20_origin + 1)], &v71_20_cursor);
          compose(&(v80_5),&(v81_6))
        };
        drop(v80_5);
        let v80_8: Space = intersect(&(*CONSTANT_21),&(v80_2));
        drop(v80_2);
        let v80_9: Space = if has_head(&(v80_8)) { singleton(&[]) } else { Space::new() };
        drop(v80_8);
        let v80_10: Space = compose(&(v80_9),&(*CONSTANT_24));
        drop(v80_9);
        let v80_11: Space = unite(&(v80_7),&(v80_10));
        drop(v80_10);
        join_wrapped_into(&mut v71_20_write,&((v80_11).read_zipper()),&[]);
        }
        v71_20_cursor.ascend(1);
      }
      drop(v71_20_cursor);
      drop(v71_20_write);
      let v71_21: Space = subtract(&(v71_16),&(v71_20));
      let v71_22: Space = if (&(v71_21)).is_empty() { Space::new() } else {
        compose(&(v71_21),&(v71_12))
      };
      drop(v71_12);
      let mut v71_23 = Space::new();
      let mut v71_23_write = v71_23.write_zipper();
      let mut v71_23_cursor = (v71_22).read_zipper();
      let v71_23_origin = v71_23_cursor.path().len();
      for v71_23_byte in v71_23_cursor.child_mask().iter() {
        v71_23_cursor.descend_to_existing_byte(v71_23_byte);
        {
        let v83_2: Space = singleton(&v71_23_cursor.path()[v71_23_origin..(v71_23_origin + 1)]);
        let v83_3: Space = intersect(&(*CONSTANT_21),&(v83_2));
        let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
        drop(v83_3);
        let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
        drop(v83_4);
        let v83_7: Space = if (&(v83_5)).is_empty() { Space::new() } else {
          let v84_6: Space = routine_13(c, &v71_23_cursor.path()[v71_23_origin..(v71_23_origin + 1)], &v71_23_cursor);
          compose(&(v83_5),&(v84_6))
        };
        drop(v83_5);
        let v83_8: Space = intersect(&(*CONSTANT_21),&(v83_2));
        drop(v83_2);
        let v83_9: Space = if has_head(&(v83_8)) { singleton(&[]) } else { Space::new() };
        drop(v83_8);
        let v83_10: Space = compose(&(v83_9),&v71_23_cursor);
        drop(v83_9);
        let v83_11: Space = unite(&(v83_7),&(v83_10));
        drop(v83_10);
        join_wrapped_into(&mut v71_23_write,&((v83_11).read_zipper()),&[]);
        }
        v71_23_cursor.ascend(1);
      }
      drop(v71_23_cursor);
      drop(v71_23_write);
      compose(&(v69_10),&(v71_23))
    };
    drop(v69_10);
    let v69_25: Space = unite(&(v69_8),&(v69_24));
    join_wrapped_into(&mut v68_26_write,&((v69_25).read_zipper()),&[]);
    }
    v68_26_cursor.ascend(1);
  }
  drop(v68_26_cursor);
  drop(v68_26_write);
  (v68_26).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v85_6: Path = concat_path(&(*p1),&(*p0));
  let v85_7: Space = singleton(&(v85_6));
  drop(v85_6);
  let mut v85_14 = Space::new();
  let mut v85_14_write = v85_14.write_zipper();
  let mut v85_14_cursor = (v85_7).read_zipper();
  let v85_14_origin = v85_14_cursor.path().len();
  for v85_14_byte in v85_14_cursor.child_mask().iter() {
    v85_14_cursor.descend_to_existing_byte(v85_14_byte);
    {
    let v86_2: Space = singleton(&v85_14_cursor.path()[v85_14_origin..(v85_14_origin + 1)]);
    let v86_3: Space = intersect(&(*CONSTANT_21),&(v86_2));
    let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
    drop(v86_3);
    let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
    drop(v86_4);
    let v86_7: Space = if (&(v86_5)).is_empty() { Space::new() } else {
      let v87_6: Space = routine_9(c, &v85_14_cursor.path()[v85_14_origin..(v85_14_origin + 1)], &v85_14_cursor);
      compose(&(v86_5),&(v87_6))
    };
    drop(v86_5);
    let v86_8: Space = intersect(&(*CONSTANT_21),&(v86_2));
    drop(v86_2);
    let v86_9: Space = if has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
    drop(v86_8);
    let v86_11: Space = if (&(v86_9)).is_empty() { Space::new() } else {
      let mut v88_10 = Space::new();
      let mut v88_10_write = v88_10.write_zipper();
      for v88_10_byte in v85_14_cursor.child_mask().iter() {
        v85_14_cursor.descend_to_existing_byte(v88_10_byte);
        {
        let v89_2: Space = singleton(&v85_14_cursor.path()[(v85_14_origin + 1)..(v85_14_origin + 2)]);
        let v89_3: Space = intersect(&(*CONSTANT_21),&(v89_2));
        let v89_4: Space = if has_head(&(v89_3)) { singleton(&[]) } else { Space::new() };
        drop(v89_3);
        let v89_5: Space = subtract(&(*CONSTANT_0),&(v89_4));
        drop(v89_4);
        let v89_7: Space = if (&(v89_5)).is_empty() { Space::new() } else {
          let v90_6: Space = routine_16(c, &v85_14_cursor.path()[(v85_14_origin + 1)..(v85_14_origin + 2)], &v85_14_cursor.path()[v85_14_origin..(v85_14_origin + 1)], &v85_14_cursor);
          compose(&(v89_5),&(v90_6))
        };
        drop(v89_5);
        let v89_8: Space = intersect(&(*CONSTANT_21),&(v89_2));
        drop(v89_2);
        let v89_9: Space = if has_head(&(v89_8)) { singleton(&[]) } else { Space::new() };
        drop(v89_8);
        let v89_11: Space = if (&(v89_9)).is_empty() { Space::new() } else {
          let v91_10: Space = routine_17(c, &v85_14_cursor.path()[(v85_14_origin + 1)..(v85_14_origin + 2)], &v85_14_cursor.path()[v85_14_origin..(v85_14_origin + 1)], &v85_14_cursor);
          compose(&(v89_9),&(v91_10))
        };
        drop(v89_9);
        let v89_12: Space = unite(&(v89_7),&(v89_11));
        join_wrapped_into(&mut v88_10_write,&((v89_12).read_zipper()),&[]);
        }
        v85_14_cursor.ascend(1);
      }
      drop(v88_10_write);
      compose(&(v86_9),&(v88_10))
    };
    drop(v86_9);
    let v86_12: Space = unite(&(v86_7),&(v86_11));
    join_wrapped_into(&mut v85_14_write,&((v86_12).read_zipper()),&[]);
    }
    v85_14_cursor.ascend(1);
  }
  drop(v85_14_cursor);
  drop(v85_14_write);
  let v85_15: Space = intersect(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))),&(v85_14));
  let v85_16: Space = range_const::<{3},{4}>(&(v85_15));
  let mut v85_25 = Space::new();
  let mut v85_25_write = v85_25.write_zipper();
  let mut v85_25_cursor = (v85_16).read_zipper();
  let v85_25_origin = v85_25_cursor.path().len();
  for v85_25_byte in v85_25_cursor.child_mask().iter() {
    v85_25_cursor.descend_to_existing_byte(v85_25_byte);
    {
    let v92_2: Space = singleton(&v85_25_cursor.path()[v85_25_origin..(v85_25_origin + 1)]);
    let v92_3: Space = intersect(&(*CONSTANT_21),&(v92_2));
    let v92_4: Space = if has_head(&(v92_3)) { singleton(&[]) } else { Space::new() };
    drop(v92_3);
    let v92_5: Space = subtract(&(*CONSTANT_0),&(v92_4));
    drop(v92_4);
    let v92_7: Space = if (&(v92_5)).is_empty() { Space::new() } else {
      let mut v93_6 = Space::new();
      let mut v93_6_write = v93_6.write_zipper();
      for v93_6_byte in v85_25_cursor.child_mask().iter() {
        v85_25_cursor.descend_to_existing_byte(v93_6_byte);
        {
        let v94_2: Space = singleton(&v85_25_cursor.path()[(v85_25_origin + 1)..(v85_25_origin + 2)]);
        let v94_3: Space = intersect(&(*CONSTANT_21),&(v94_2));
        let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
        drop(v94_3);
        let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
        drop(v94_4);
        let v94_8: Space = if (&(v94_5)).is_empty() { Space::new() } else {
          let v95_7: Space = routine_11(c, &v85_25_cursor.path()[v85_25_origin..(v85_25_origin + 2)], &v85_25_cursor);
          compose(&(v94_5),&(v95_7))
        };
        drop(v94_5);
        let v94_9: Space = intersect(&(*CONSTANT_21),&(v94_2));
        drop(v94_2);
        let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
        drop(v94_9);
        let v94_11: Space = compose(&(v94_10),&(*CONSTANT_24));
        drop(v94_10);
        let v94_12: Space = unite(&(v94_8),&(v94_11));
        drop(v94_11);
        join_wrapped_into(&mut v93_6_write,&((v94_12).read_zipper()),&[]);
        }
        v85_25_cursor.ascend(1);
      }
      drop(v93_6_write);
      compose(&(v92_5),&(v93_6))
    };
    drop(v92_5);
    let v92_8: Space = intersect(&(*CONSTANT_21),&(v92_2));
    drop(v92_2);
    let v92_9: Space = if has_head(&(v92_8)) { singleton(&[]) } else { Space::new() };
    drop(v92_8);
    let v92_10: Space = compose(&(v92_9),&(*CONSTANT_24));
    drop(v92_9);
    let v92_11: Space = unite(&(v92_7),&(v92_10));
    drop(v92_10);
    join_wrapped_into(&mut v85_25_write,&((v92_11).read_zipper()),&[]);
    }
    v85_25_cursor.ascend(1);
  }
  drop(v85_25_cursor);
  drop(v85_25_write);
  let mut v85_32 = Space::new();
  let mut v85_32_write = v85_32.write_zipper();
  let mut v85_32_cursor = (v85_7).read_zipper();
  let v85_32_origin = v85_32_cursor.path().len();
  for v85_32_byte in v85_32_cursor.child_mask().iter() {
    v85_32_cursor.descend_to_existing_byte(v85_32_byte);
    {
    let v96_2: Space = singleton(&v85_32_cursor.path()[v85_32_origin..(v85_32_origin + 1)]);
    let v96_3: Space = intersect(&(*CONSTANT_21),&(v96_2));
    let v96_4: Space = if has_head(&(v96_3)) { singleton(&[]) } else { Space::new() };
    drop(v96_3);
    let v96_5: Space = subtract(&(*CONSTANT_0),&(v96_4));
    drop(v96_4);
    let v96_7: Space = if (&(v96_5)).is_empty() { Space::new() } else {
      let v97_6: Space = routine_9(c, &v85_32_cursor.path()[v85_32_origin..(v85_32_origin + 1)], &v85_32_cursor);
      compose(&(v96_5),&(v97_6))
    };
    drop(v96_5);
    let v96_8: Space = intersect(&(*CONSTANT_21),&(v96_2));
    drop(v96_2);
    let v96_9: Space = if has_head(&(v96_8)) { singleton(&[]) } else { Space::new() };
    drop(v96_8);
    let v96_11: Space = if (&(v96_9)).is_empty() { Space::new() } else {
      let mut v98_10 = Space::new();
      let mut v98_10_write = v98_10.write_zipper();
      for v98_10_byte in v85_32_cursor.child_mask().iter() {
        v85_32_cursor.descend_to_existing_byte(v98_10_byte);
        {
        let v99_2: Space = singleton(&v85_32_cursor.path()[(v85_32_origin + 1)..(v85_32_origin + 2)]);
        let v99_3: Space = intersect(&(*CONSTANT_21),&(v99_2));
        let v99_4: Space = if has_head(&(v99_3)) { singleton(&[]) } else { Space::new() };
        drop(v99_3);
        let v99_5: Space = subtract(&(*CONSTANT_0),&(v99_4));
        drop(v99_4);
        let v99_7: Space = if (&(v99_5)).is_empty() { Space::new() } else {
          let v100_6: Space = routine_16(c, &v85_32_cursor.path()[(v85_32_origin + 1)..(v85_32_origin + 2)], &v85_32_cursor.path()[v85_32_origin..(v85_32_origin + 1)], &v85_32_cursor);
          compose(&(v99_5),&(v100_6))
        };
        drop(v99_5);
        let v99_8: Space = intersect(&(*CONSTANT_21),&(v99_2));
        drop(v99_2);
        let v99_9: Space = if has_head(&(v99_8)) { singleton(&[]) } else { Space::new() };
        drop(v99_8);
        let v99_11: Space = if (&(v99_9)).is_empty() { Space::new() } else {
          let v101_10: Space = routine_17(c, &v85_32_cursor.path()[(v85_32_origin + 1)..(v85_32_origin + 2)], &v85_32_cursor.path()[v85_32_origin..(v85_32_origin + 1)], &v85_32_cursor);
          compose(&(v99_9),&(v101_10))
        };
        drop(v99_9);
        let v99_12: Space = unite(&(v99_7),&(v99_11));
        join_wrapped_into(&mut v98_10_write,&((v99_12).read_zipper()),&[]);
        }
        v85_32_cursor.ascend(1);
      }
      drop(v98_10_write);
      compose(&(v96_9),&(v98_10))
    };
    drop(v96_9);
    let v96_12: Space = unite(&(v96_7),&(v96_11));
    join_wrapped_into(&mut v85_32_write,&((v96_12).read_zipper()),&[]);
    }
    v85_32_cursor.ascend(1);
  }
  drop(v85_32_cursor);
  drop(v85_32_write);
  let v85_33: Space = intersect(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))),&(v85_32));
  let v85_34: Space = range_const::<{4},{5}>(&(v85_33));
  let mut v85_43 = Space::new();
  let mut v85_43_write = v85_43.write_zipper();
  let mut v85_43_cursor = (v85_34).read_zipper();
  let v85_43_origin = v85_43_cursor.path().len();
  for v85_43_byte in v85_43_cursor.child_mask().iter() {
    v85_43_cursor.descend_to_existing_byte(v85_43_byte);
    {
    let v102_2: Space = singleton(&v85_43_cursor.path()[v85_43_origin..(v85_43_origin + 1)]);
    let v102_3: Space = intersect(&(*CONSTANT_21),&(v102_2));
    let v102_4: Space = if has_head(&(v102_3)) { singleton(&[]) } else { Space::new() };
    drop(v102_3);
    let v102_5: Space = subtract(&(*CONSTANT_0),&(v102_4));
    drop(v102_4);
    let v102_7: Space = if (&(v102_5)).is_empty() { Space::new() } else {
      let mut v103_6 = Space::new();
      let mut v103_6_write = v103_6.write_zipper();
      for v103_6_byte in v85_43_cursor.child_mask().iter() {
        v85_43_cursor.descend_to_existing_byte(v103_6_byte);
        {
        let v104_2: Space = singleton(&v85_43_cursor.path()[(v85_43_origin + 1)..(v85_43_origin + 2)]);
        let v104_3: Space = intersect(&(*CONSTANT_21),&(v104_2));
        let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
        drop(v104_3);
        let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
        drop(v104_4);
        let v104_8: Space = if (&(v104_5)).is_empty() { Space::new() } else {
          let v105_7: Space = routine_12(c, &v85_43_cursor.path()[v85_43_origin..(v85_43_origin + 2)], &v85_43_cursor);
          compose(&(v104_5),&(v105_7))
        };
        drop(v104_5);
        let v104_9: Space = intersect(&(*CONSTANT_21),&(v104_2));
        drop(v104_2);
        let v104_10: Space = if has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
        drop(v104_9);
        let v104_11: Space = compose(&(v104_10),&(*CONSTANT_24));
        drop(v104_10);
        let v104_12: Space = unite(&(v104_8),&(v104_11));
        drop(v104_11);
        join_wrapped_into(&mut v103_6_write,&((v104_12).read_zipper()),&[]);
        }
        v85_43_cursor.ascend(1);
      }
      drop(v103_6_write);
      compose(&(v102_5),&(v103_6))
    };
    drop(v102_5);
    let v102_8: Space = intersect(&(*CONSTANT_21),&(v102_2));
    drop(v102_2);
    let v102_9: Space = if has_head(&(v102_8)) { singleton(&[]) } else { Space::new() };
    drop(v102_8);
    let v102_10: Space = compose(&(v102_9),&(*CONSTANT_24));
    drop(v102_9);
    let v102_11: Space = unite(&(v102_7),&(v102_10));
    drop(v102_10);
    join_wrapped_into(&mut v85_43_write,&((v102_11).read_zipper()),&[]);
    }
    v85_43_cursor.ascend(1);
  }
  drop(v85_43_cursor);
  drop(v85_43_write);
  let v85_44: Space = subtract(&(v85_25),&(v85_43));
  let v85_45: Space = if (&(v85_44)).is_empty() { Space::new() } else {
    compose(&(v85_44),&(v85_7))
  };
  drop(v85_7);
  let mut v85_52 = Space::new();
  let mut v85_52_write = v85_52.write_zipper();
  let mut v85_52_cursor = (v85_45).read_zipper();
  let v85_52_origin = v85_52_cursor.path().len();
  for v85_52_byte in v85_52_cursor.child_mask().iter() {
    v85_52_cursor.descend_to_existing_byte(v85_52_byte);
    {
    let v107_2: Space = singleton(&v85_52_cursor.path()[v85_52_origin..(v85_52_origin + 1)]);
    let v107_3: Space = intersect(&(*CONSTANT_21),&(v107_2));
    let v107_4: Space = if has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
    drop(v107_3);
    let v107_5: Space = subtract(&(*CONSTANT_0),&(v107_4));
    drop(v107_4);
    let v107_7: Space = if (&(v107_5)).is_empty() { Space::new() } else {
      let mut v108_6 = Space::new();
      let mut v108_6_write = v108_6.write_zipper();
      for v108_6_byte in v85_52_cursor.child_mask().iter() {
        v85_52_cursor.descend_to_existing_byte(v108_6_byte);
        {
        let v109_2: Space = singleton(&v85_52_cursor.path()[(v85_52_origin + 1)..(v85_52_origin + 2)]);
        let v109_3: Space = intersect(&(*CONSTANT_21),&(v109_2));
        let v109_4: Space = if has_head(&(v109_3)) { singleton(&[]) } else { Space::new() };
        drop(v109_3);
        let v109_5: Space = subtract(&(*CONSTANT_0),&(v109_4));
        drop(v109_4);
        let v109_8: Space = if (&(v109_5)).is_empty() { Space::new() } else {
          let v110_7: Space = routine_13(c, &v85_52_cursor.path()[v85_52_origin..(v85_52_origin + 2)], &v85_52_cursor);
          compose(&(v109_5),&(v110_7))
        };
        drop(v109_5);
        let v109_9: Space = intersect(&(*CONSTANT_21),&(v109_2));
        drop(v109_2);
        let v109_10: Space = if has_head(&(v109_9)) { singleton(&[]) } else { Space::new() };
        drop(v109_9);
        let v109_11: Space = compose(&(v109_10),&v85_52_cursor);
        drop(v109_10);
        let v109_12: Space = unite(&(v109_8),&(v109_11));
        drop(v109_11);
        join_wrapped_into(&mut v108_6_write,&((v109_12).read_zipper()),&[]);
        }
        v85_52_cursor.ascend(1);
      }
      drop(v108_6_write);
      compose(&(v107_5),&(v108_6))
    };
    drop(v107_5);
    let v107_8: Space = intersect(&(*CONSTANT_21),&(v107_2));
    drop(v107_2);
    let v107_9: Space = if has_head(&(v107_8)) { singleton(&[]) } else { Space::new() };
    drop(v107_8);
    let v107_10: Space = compose(&(v107_9),&v85_52_cursor);
    drop(v107_9);
    let v107_11: Space = unite(&(v107_7),&(v107_10));
    drop(v107_10);
    join_wrapped_into(&mut v85_52_write,&((v107_11).read_zipper()),&[]);
    }
    v85_52_cursor.ascend(1);
  }
  drop(v85_52_cursor);
  drop(v85_52_write);
  (v85_52).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v111_11 = Space::new();
  let mut v111_11_write = v111_11.write_zipper();
  let mut v111_11_cursor = (*s0).read_zipper();
  let v111_11_origin = v111_11_cursor.path().len();
  for v111_11_byte in v111_11_cursor.child_mask().iter() {
    v111_11_cursor.descend_to_existing_byte(v111_11_byte);
    {
    let v112_2: Space = singleton(&v111_11_cursor.path()[v111_11_origin..(v111_11_origin + 1)]);
    let v112_3: Space = intersect(&(*CONSTANT_21),&(v112_2));
    let v112_4: Space = if has_head(&(v112_3)) { singleton(&[]) } else { Space::new() };
    drop(v112_3);
    let v112_5: Space = subtract(&(*CONSTANT_0),&(v112_4));
    drop(v112_4);
    let v112_8: Space = if (&(v112_5)).is_empty() { Space::new() } else {
      let v113_6: Path = concat_path(&(*p0),&v111_11_cursor.path()[v111_11_origin..(v111_11_origin + 1)]);
      let v113_7: Space = routine_9(c, &(v113_6), &v111_11_cursor);
      compose(&(v112_5),&(v113_7))
    };
    drop(v112_5);
    let v112_9: Space = intersect(&(*CONSTANT_21),&(v112_2));
    drop(v112_2);
    let v112_10: Space = if has_head(&(v112_9)) { singleton(&[]) } else { Space::new() };
    drop(v112_9);
    let v112_13: Space = if (&(v112_10)).is_empty() { Space::new() } else {
      let v114_6: Path = concat_path(&(*p0),&v111_11_cursor.path()[v111_11_origin..(v111_11_origin + 1)]);
      let mut v114_12 = Space::new();
      let mut v114_12_write = v114_12.write_zipper();
      for v114_12_byte in v111_11_cursor.child_mask().iter() {
        v111_11_cursor.descend_to_existing_byte(v114_12_byte);
        {
        let v115_2: Space = singleton(&v111_11_cursor.path()[(v111_11_origin + 1)..(v111_11_origin + 2)]);
        let v115_3: Space = intersect(&(*CONSTANT_21),&(v115_2));
        let v115_4: Space = if has_head(&(v115_3)) { singleton(&[]) } else { Space::new() };
        drop(v115_3);
        let v115_5: Space = subtract(&(*CONSTANT_0),&(v115_4));
        drop(v115_4);
        let v115_7: Space = if (&(v115_5)).is_empty() { Space::new() } else {
          let v116_6: Space = routine_16(c, &v111_11_cursor.path()[(v111_11_origin + 1)..(v111_11_origin + 2)], &(v114_6), &v111_11_cursor);
          compose(&(v115_5),&(v116_6))
        };
        drop(v115_5);
        let v115_8: Space = intersect(&(*CONSTANT_21),&(v115_2));
        drop(v115_2);
        let v115_9: Space = if has_head(&(v115_8)) { singleton(&[]) } else { Space::new() };
        drop(v115_8);
        let v115_15: Space = if (&(v115_9)).is_empty() { Space::new() } else {
          let v117_11: Space = if (&(descend_cursor(descend_cursor((*CONSTANT_25).read_zipper(),&(*p0)),&v111_11_cursor.path()[v111_11_origin..(v111_11_origin + 1)]))).is_empty() { Space::new() } else {
            compose(&(descend_cursor(descend_cursor((*CONSTANT_25).read_zipper(),&(*p0)),&v111_11_cursor.path()[v111_11_origin..(v111_11_origin + 1)])),&(descend_cursor((*CONSTANT_25).read_zipper(),&v111_11_cursor.path()[(v111_11_origin + 1)..(v111_11_origin + 2)])))
          };
          let v117_12: Path = concat_path(&(v114_6),&v111_11_cursor.path()[(v111_11_origin + 1)..(v111_11_origin + 2)]);
          let v117_13: Space = singleton(&(v117_12));
          drop(v117_12);
          let v117_14: Space = subtract(&(v117_11),&(v117_13));
          drop(v117_11);
          drop(v117_13);
          compose(&(v115_9),&(v117_14))
        };
        drop(v115_9);
        let v115_16: Space = unite(&(v115_7),&(v115_15));
        drop(v115_15);
        join_wrapped_into(&mut v114_12_write,&((v115_16).read_zipper()),&[]);
        }
        v111_11_cursor.ascend(1);
      }
      drop(v114_12_write);
      drop(v114_6);
      compose(&(v112_10),&(v114_12))
    };
    drop(v112_10);
    let v112_14: Space = unite(&(v112_8),&(v112_13));
    join_wrapped_into(&mut v111_11_write,&((v112_14).read_zipper()),&[]);
    }
    v111_11_cursor.ascend(1);
  }
  drop(v111_11_cursor);
  drop(v111_11_write);
  (v111_11).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v119_14 = Space::new();
  let mut v119_14_write = v119_14.write_zipper();
  let mut v119_14_cursor = (*s0).read_zipper();
  let v119_14_origin = v119_14_cursor.path().len();
  for v119_14_byte in v119_14_cursor.child_mask().iter() {
    v119_14_cursor.descend_to_existing_byte(v119_14_byte);
    {
    let v120_2: Space = singleton(&v119_14_cursor.path()[v119_14_origin..(v119_14_origin + 1)]);
    let v120_3: Space = intersect(&(*CONSTANT_21),&(v120_2));
    let v120_4: Space = if has_head(&(v120_3)) { singleton(&[]) } else { Space::new() };
    drop(v120_3);
    let v120_5: Space = subtract(&(*CONSTANT_0),&(v120_4));
    drop(v120_4);
    let v120_8: Space = if (&(v120_5)).is_empty() { Space::new() } else {
      let mut v121_7 = Space::new();
      let mut v121_7_write = v121_7.write_zipper();
      for v121_7_byte in v119_14_cursor.child_mask().iter() {
        v119_14_cursor.descend_to_existing_byte(v121_7_byte);
        {
        let v122_2: Space = singleton(&v119_14_cursor.path()[(v119_14_origin + 1)..(v119_14_origin + 2)]);
        let v122_3: Space = intersect(&(*CONSTANT_21),&(v122_2));
        let v122_4: Space = if has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
        drop(v122_3);
        let v122_5: Space = subtract(&(*CONSTANT_0),&(v122_4));
        drop(v122_4);
        let v122_8: Space = if (&(v122_5)).is_empty() { Space::new() } else {
          let v123_7: Space = routine_16(c, &v119_14_cursor.path()[v119_14_origin..(v119_14_origin + 2)], &(*p0), &v119_14_cursor);
          compose(&(v122_5),&(v123_7))
        };
        drop(v122_5);
        let v122_9: Space = intersect(&(*CONSTANT_21),&(v122_2));
        drop(v122_2);
        let v122_10: Space = if has_head(&(v122_9)) { singleton(&[]) } else { Space::new() };
        drop(v122_9);
        let v122_16: Space = if (&(v122_10)).is_empty() { Space::new() } else {
          let v124_12: Space = if (&(descend_cursor((*CONSTANT_25).read_zipper(),&(*p0)))).is_empty() { Space::new() } else {
            compose(&(descend_cursor((*CONSTANT_25).read_zipper(),&(*p0))),&(descend_cursor(descend_cursor((*CONSTANT_25).read_zipper(),&v119_14_cursor.path()[v119_14_origin..(v119_14_origin + 1)]),&v119_14_cursor.path()[(v119_14_origin + 1)..(v119_14_origin + 2)])))
          };
          let v124_13: Path = concat_path(&(*p0),&v119_14_cursor.path()[v119_14_origin..(v119_14_origin + 2)]);
          let v124_14: Space = singleton(&(v124_13));
          drop(v124_13);
          let v124_15: Space = subtract(&(v124_12),&(v124_14));
          drop(v124_12);
          drop(v124_14);
          compose(&(v122_10),&(v124_15))
        };
        drop(v122_10);
        let v122_17: Space = unite(&(v122_8),&(v122_16));
        drop(v122_16);
        join_wrapped_into(&mut v121_7_write,&((v122_17).read_zipper()),&[]);
        }
        v119_14_cursor.ascend(1);
      }
      drop(v121_7_write);
      compose(&(v120_5),&(v121_7))
    };
    drop(v120_5);
    let v120_9: Space = intersect(&(*CONSTANT_21),&(v120_2));
    drop(v120_2);
    let v120_10: Space = if has_head(&(v120_9)) { singleton(&[]) } else { Space::new() };
    drop(v120_9);
    let v120_16: Space = if (&(v120_10)).is_empty() { Space::new() } else {
      let v126_12: Space = if (&(descend_cursor((*CONSTANT_25).read_zipper(),&(*p0)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor((*CONSTANT_25).read_zipper(),&(*p0))),&(descend_cursor((*CONSTANT_25).read_zipper(),&v119_14_cursor.path()[v119_14_origin..(v119_14_origin + 1)])))
      };
      let v126_13: Path = concat_path(&(*p0),&v119_14_cursor.path()[v119_14_origin..(v119_14_origin + 1)]);
      let v126_14: Space = singleton(&(v126_13));
      drop(v126_13);
      let v126_15: Space = subtract(&(v126_12),&(v126_14));
      drop(v126_12);
      drop(v126_14);
      compose(&(v120_10),&(v126_15))
    };
    drop(v120_10);
    let v120_17: Space = unite(&(v120_8),&(v120_16));
    drop(v120_16);
    join_wrapped_into(&mut v119_14_write,&((v120_17).read_zipper()),&[]);
    }
    v119_14_cursor.ascend(1);
  }
  drop(v119_14_cursor);
  drop(v119_14_write);
  (v119_14).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v128_6 = Space::new();
  let mut v128_6_write = v128_6.write_zipper();
  let mut v128_6_cursor = (*s0).read_zipper();
  let v128_6_origin = v128_6_cursor.path().len();
  for v128_6_byte in v128_6_cursor.child_mask().iter() {
    v128_6_cursor.descend_to_existing_byte(v128_6_byte);
    {
    let v129_2: Space = singleton(&v128_6_cursor.path()[v128_6_origin..(v128_6_origin + 1)]);
    let v129_3: Space = intersect(&(*CONSTANT_21),&(v129_2));
    let v129_4: Space = if has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
    drop(v129_3);
    let v129_5: Space = subtract(&(*CONSTANT_0),&(v129_4));
    drop(v129_4);
    let v129_8: Space = if (&(v129_5)).is_empty() { Space::new() } else {
      let v130_6: Path = concat_path(&(*p0),&v128_6_cursor.path()[v128_6_origin..(v128_6_origin + 1)]);
      let v130_7: Space = routine_11(c, &(v130_6), &v128_6_cursor);
      drop(v130_6);
      compose(&(v129_5),&(v130_7))
    };
    drop(v129_5);
    let v129_9: Space = intersect(&(*CONSTANT_21),&(v129_2));
    drop(v129_2);
    let v129_10: Space = if has_head(&(v129_9)) { singleton(&[]) } else { Space::new() };
    drop(v129_9);
    let v129_11: Space = compose(&(v129_10),&(*CONSTANT_24));
    drop(v129_10);
    let v129_12: Space = unite(&(v129_8),&(v129_11));
    drop(v129_11);
    join_wrapped_into(&mut v128_6_write,&((v129_12).read_zipper()),&[]);
    }
    v128_6_cursor.ascend(1);
  }
  drop(v128_6_cursor);
  drop(v128_6_write);
  (v128_6).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v131_6 = Space::new();
  let mut v131_6_write = v131_6.write_zipper();
  let mut v131_6_cursor = (*s0).read_zipper();
  let v131_6_origin = v131_6_cursor.path().len();
  for v131_6_byte in v131_6_cursor.child_mask().iter() {
    v131_6_cursor.descend_to_existing_byte(v131_6_byte);
    {
    let v132_2: Space = singleton(&v131_6_cursor.path()[v131_6_origin..(v131_6_origin + 1)]);
    let v132_3: Space = intersect(&(*CONSTANT_21),&(v132_2));
    let v132_4: Space = if has_head(&(v132_3)) { singleton(&[]) } else { Space::new() };
    drop(v132_3);
    let v132_5: Space = subtract(&(*CONSTANT_0),&(v132_4));
    drop(v132_4);
    let v132_8: Space = if (&(v132_5)).is_empty() { Space::new() } else {
      let v133_6: Path = concat_path(&(*p0),&v131_6_cursor.path()[v131_6_origin..(v131_6_origin + 1)]);
      let v133_7: Space = routine_12(c, &(v133_6), &v131_6_cursor);
      drop(v133_6);
      compose(&(v132_5),&(v133_7))
    };
    drop(v132_5);
    let v132_9: Space = intersect(&(*CONSTANT_21),&(v132_2));
    drop(v132_2);
    let v132_10: Space = if has_head(&(v132_9)) { singleton(&[]) } else { Space::new() };
    drop(v132_9);
    let v132_11: Space = compose(&(v132_10),&(*CONSTANT_24));
    drop(v132_10);
    let v132_12: Space = unite(&(v132_8),&(v132_11));
    drop(v132_11);
    join_wrapped_into(&mut v131_6_write,&((v132_12).read_zipper()),&[]);
    }
    v131_6_cursor.ascend(1);
  }
  drop(v131_6_cursor);
  drop(v131_6_write);
  (v131_6).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v134_5 = Space::new();
  let mut v134_5_write = v134_5.write_zipper();
  let mut v134_5_cursor = (*s0).read_zipper();
  let v134_5_origin = v134_5_cursor.path().len();
  for v134_5_byte in v134_5_cursor.child_mask().iter() {
    v134_5_cursor.descend_to_existing_byte(v134_5_byte);
    {
    let v135_2: Space = singleton(&v134_5_cursor.path()[v134_5_origin..(v134_5_origin + 1)]);
    let v135_3: Space = intersect(&(*CONSTANT_21),&(v135_2));
    let v135_4: Space = if has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
    drop(v135_3);
    let v135_5: Space = subtract(&(*CONSTANT_0),&(v135_4));
    drop(v135_4);
    let v135_8: Space = if (&(v135_5)).is_empty() { Space::new() } else {
      let v136_6: Path = concat_path(&(*p0),&v134_5_cursor.path()[v134_5_origin..(v134_5_origin + 1)]);
      let v136_7: Space = routine_13(c, &(v136_6), &v134_5_cursor);
      drop(v136_6);
      compose(&(v135_5),&(v136_7))
    };
    drop(v135_5);
    let v135_9: Space = intersect(&(*CONSTANT_21),&(v135_2));
    drop(v135_2);
    let v135_10: Space = if has_head(&(v135_9)) { singleton(&[]) } else { Space::new() };
    drop(v135_9);
    let v135_11: Space = compose(&(v135_10),&v134_5_cursor);
    drop(v135_10);
    let v135_12: Space = unite(&(v135_8),&(v135_11));
    drop(v135_11);
    join_wrapped_into(&mut v134_5_write,&((v135_12).read_zipper()),&[]);
    }
    v134_5_cursor.ascend(1);
  }
  drop(v134_5_cursor);
  drop(v134_5_write);
  (v134_5).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v137_26 = Space::new();
  let mut v137_26_write = v137_26.write_zipper();
  let mut v137_26_cursor = (*s0).read_zipper();
  let v137_26_origin = v137_26_cursor.path().len();
  for v137_26_byte in v137_26_cursor.child_mask().iter() {
    v137_26_cursor.descend_to_existing_byte(v137_26_byte);
    {
    let v138_2: Space = singleton(&v137_26_cursor.path()[v137_26_origin..(v137_26_origin + 1)]);
    let v138_3: Space = intersect(&(*CONSTANT_21),&(v138_2));
    let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
    drop(v138_3);
    let v138_5: Space = subtract(&(*CONSTANT_0),&(v138_4));
    drop(v138_4);
    let v138_8: Space = if (&(v138_5)).is_empty() { Space::new() } else {
      let v139_6: Path = concat_path(&(*p0),&v137_26_cursor.path()[v137_26_origin..(v137_26_origin + 1)]);
      let v139_7: Space = routine_14(c, &(v139_6), &(*p1), &v137_26_cursor, &(*s1));
      compose(&(v138_5),&(v139_7))
    };
    drop(v138_5);
    let v138_9: Space = intersect(&(*CONSTANT_21),&(v138_2));
    drop(v138_2);
    let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
    drop(v138_9);
    let v138_24: Space = if (&(v138_10)).is_empty() { Space::new() } else {
      let v140_6: Path = concat_path(&(*p0),&v137_26_cursor.path()[v137_26_origin..(v137_26_origin + 1)]);
      let v140_11: Path = concat_path(&(*p1),&(v140_6));
      drop(v140_6);
      let v140_12: Space = singleton(&(v140_11));
      drop(v140_11);
      let mut v140_13 = Space::new();
      let mut v140_13_write = v140_13.write_zipper();
      let mut v140_13_cursor = (v140_12).read_zipper();
      let v140_13_origin = v140_13_cursor.path().len();
      for v140_13_byte in v140_13_cursor.child_mask().iter() {
        v140_13_cursor.descend_to_existing_byte(v140_13_byte);
        {
        let v141_2: Space = singleton(&v140_13_cursor.path()[v140_13_origin..(v140_13_origin + 1)]);
        let v141_3: Space = intersect(&(*CONSTANT_21),&(v141_2));
        let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
        drop(v141_3);
        let v141_5: Space = subtract(&(*CONSTANT_0),&(v141_4));
        drop(v141_4);
        let v141_7: Space = if (&(v141_5)).is_empty() { Space::new() } else {
          let v142_6: Space = routine_9(c, &v140_13_cursor.path()[v140_13_origin..(v140_13_origin + 1)], &v140_13_cursor);
          compose(&(v141_5),&(v142_6))
        };
        drop(v141_5);
        let v141_8: Space = intersect(&(*CONSTANT_21),&(v141_2));
        drop(v141_2);
        let v141_9: Space = if has_head(&(v141_8)) { singleton(&[]) } else { Space::new() };
        drop(v141_8);
        let v141_11: Space = if (&(v141_9)).is_empty() { Space::new() } else {
          let v143_10: Space = routine_10(c, &v140_13_cursor.path()[v140_13_origin..(v140_13_origin + 1)], &v140_13_cursor);
          compose(&(v141_9),&(v143_10))
        };
        drop(v141_9);
        let v141_12: Space = unite(&(v141_7),&(v141_11));
        join_wrapped_into(&mut v140_13_write,&((v141_12).read_zipper()),&[]);
        }
        v140_13_cursor.ascend(1);
      }
      drop(v140_13_cursor);
      drop(v140_13_write);
      let v140_14: Space = intersect(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))),&(v140_13));
      let v140_15: Space = range_const::<{2},{3}>(&(v140_14));
      let mut v140_16 = Space::new();
      let mut v140_16_write = v140_16.write_zipper();
      let mut v140_16_cursor = (v140_15).read_zipper();
      let v140_16_origin = v140_16_cursor.path().len();
      for v140_16_byte in v140_16_cursor.child_mask().iter() {
        v140_16_cursor.descend_to_existing_byte(v140_16_byte);
        {
        let v144_2: Space = singleton(&v140_16_cursor.path()[v140_16_origin..(v140_16_origin + 1)]);
        let v144_3: Space = intersect(&(*CONSTANT_21),&(v144_2));
        let v144_4: Space = if has_head(&(v144_3)) { singleton(&[]) } else { Space::new() };
        drop(v144_3);
        let v144_5: Space = subtract(&(*CONSTANT_0),&(v144_4));
        drop(v144_4);
        let v144_7: Space = if (&(v144_5)).is_empty() { Space::new() } else {
          let v145_6: Space = routine_18(c, &v140_16_cursor.path()[v140_16_origin..(v140_16_origin + 1)], &v140_16_cursor);
          compose(&(v144_5),&(v145_6))
        };
        drop(v144_5);
        let v144_8: Space = intersect(&(*CONSTANT_21),&(v144_2));
        drop(v144_2);
        let v144_9: Space = if has_head(&(v144_8)) { singleton(&[]) } else { Space::new() };
        drop(v144_8);
        let v144_10: Space = compose(&(v144_9),&(*CONSTANT_24));
        drop(v144_9);
        let v144_11: Space = unite(&(v144_7),&(v144_10));
        drop(v144_10);
        join_wrapped_into(&mut v140_16_write,&((v144_11).read_zipper()),&[]);
        }
        v140_16_cursor.ascend(1);
      }
      drop(v140_16_cursor);
      drop(v140_16_write);
      let mut v140_17 = Space::new();
      let mut v140_17_write = v140_17.write_zipper();
      let mut v140_17_cursor = (v140_12).read_zipper();
      let v140_17_origin = v140_17_cursor.path().len();
      for v140_17_byte in v140_17_cursor.child_mask().iter() {
        v140_17_cursor.descend_to_existing_byte(v140_17_byte);
        {
        let v146_2: Space = singleton(&v140_17_cursor.path()[v140_17_origin..(v140_17_origin + 1)]);
        let v146_3: Space = intersect(&(*CONSTANT_21),&(v146_2));
        let v146_4: Space = if has_head(&(v146_3)) { singleton(&[]) } else { Space::new() };
        drop(v146_3);
        let v146_5: Space = subtract(&(*CONSTANT_0),&(v146_4));
        drop(v146_4);
        let v146_7: Space = if (&(v146_5)).is_empty() { Space::new() } else {
          let v147_6: Space = routine_9(c, &v140_17_cursor.path()[v140_17_origin..(v140_17_origin + 1)], &v140_17_cursor);
          compose(&(v146_5),&(v147_6))
        };
        drop(v146_5);
        let v146_8: Space = intersect(&(*CONSTANT_21),&(v146_2));
        drop(v146_2);
        let v146_9: Space = if has_head(&(v146_8)) { singleton(&[]) } else { Space::new() };
        drop(v146_8);
        let v146_11: Space = if (&(v146_9)).is_empty() { Space::new() } else {
          let v148_10: Space = routine_10(c, &v140_17_cursor.path()[v140_17_origin..(v140_17_origin + 1)], &v140_17_cursor);
          compose(&(v146_9),&(v148_10))
        };
        drop(v146_9);
        let v146_12: Space = unite(&(v146_7),&(v146_11));
        join_wrapped_into(&mut v140_17_write,&((v146_12).read_zipper()),&[]);
        }
        v140_17_cursor.ascend(1);
      }
      drop(v140_17_cursor);
      drop(v140_17_write);
      let v140_18: Space = intersect(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))),&(v140_17));
      let v140_19: Space = range_const::<{3},{4}>(&(v140_18));
      let mut v140_20 = Space::new();
      let mut v140_20_write = v140_20.write_zipper();
      let mut v140_20_cursor = (v140_19).read_zipper();
      let v140_20_origin = v140_20_cursor.path().len();
      for v140_20_byte in v140_20_cursor.child_mask().iter() {
        v140_20_cursor.descend_to_existing_byte(v140_20_byte);
        {
        let v149_2: Space = singleton(&v140_20_cursor.path()[v140_20_origin..(v140_20_origin + 1)]);
        let v149_3: Space = intersect(&(*CONSTANT_21),&(v149_2));
        let v149_4: Space = if has_head(&(v149_3)) { singleton(&[]) } else { Space::new() };
        drop(v149_3);
        let v149_5: Space = subtract(&(*CONSTANT_0),&(v149_4));
        drop(v149_4);
        let v149_7: Space = if (&(v149_5)).is_empty() { Space::new() } else {
          let v150_6: Space = routine_19(c, &v140_20_cursor.path()[v140_20_origin..(v140_20_origin + 1)], &v140_20_cursor);
          compose(&(v149_5),&(v150_6))
        };
        drop(v149_5);
        let v149_8: Space = intersect(&(*CONSTANT_21),&(v149_2));
        drop(v149_2);
        let v149_9: Space = if has_head(&(v149_8)) { singleton(&[]) } else { Space::new() };
        drop(v149_8);
        let v149_10: Space = compose(&(v149_9),&(*CONSTANT_24));
        drop(v149_9);
        let v149_11: Space = unite(&(v149_7),&(v149_10));
        drop(v149_10);
        join_wrapped_into(&mut v140_20_write,&((v149_11).read_zipper()),&[]);
        }
        v140_20_cursor.ascend(1);
      }
      drop(v140_20_cursor);
      drop(v140_20_write);
      let v140_21: Space = subtract(&(v140_16),&(v140_20));
      let v140_22: Space = if (&(v140_21)).is_empty() { Space::new() } else {
        compose(&(v140_21),&(v140_12))
      };
      drop(v140_12);
      let mut v140_23 = Space::new();
      let mut v140_23_write = v140_23.write_zipper();
      let mut v140_23_cursor = (v140_22).read_zipper();
      let v140_23_origin = v140_23_cursor.path().len();
      for v140_23_byte in v140_23_cursor.child_mask().iter() {
        v140_23_cursor.descend_to_existing_byte(v140_23_byte);
        {
        let v152_2: Space = singleton(&v140_23_cursor.path()[v140_23_origin..(v140_23_origin + 1)]);
        let v152_3: Space = intersect(&(*CONSTANT_21),&(v152_2));
        let v152_4: Space = if has_head(&(v152_3)) { singleton(&[]) } else { Space::new() };
        drop(v152_3);
        let v152_5: Space = subtract(&(*CONSTANT_0),&(v152_4));
        drop(v152_4);
        let v152_7: Space = if (&(v152_5)).is_empty() { Space::new() } else {
          let v153_6: Space = routine_20(c, &v140_23_cursor.path()[v140_23_origin..(v140_23_origin + 1)], &v140_23_cursor);
          compose(&(v152_5),&(v153_6))
        };
        drop(v152_5);
        let v152_8: Space = intersect(&(*CONSTANT_21),&(v152_2));
        drop(v152_2);
        let v152_9: Space = if has_head(&(v152_8)) { singleton(&[]) } else { Space::new() };
        drop(v152_8);
        let v152_10: Space = compose(&(v152_9),&v140_23_cursor);
        drop(v152_9);
        let v152_11: Space = unite(&(v152_7),&(v152_10));
        drop(v152_10);
        join_wrapped_into(&mut v140_23_write,&((v152_11).read_zipper()),&[]);
        }
        v140_23_cursor.ascend(1);
      }
      drop(v140_23_cursor);
      drop(v140_23_write);
      compose(&(v138_10),&(v140_23))
    };
    drop(v138_10);
    let v138_25: Space = unite(&(v138_8),&(v138_24));
    join_wrapped_into(&mut v137_26_write,&((v138_25).read_zipper()),&[]);
    }
    v137_26_cursor.ascend(1);
  }
  drop(v137_26_cursor);
  drop(v137_26_write);
  (v137_26).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v154_6: Path = concat_path(&(*p1),&(*p0));
  let v154_7: Space = singleton(&(v154_6));
  drop(v154_6);
  let mut v154_14 = Space::new();
  let mut v154_14_write = v154_14.write_zipper();
  let mut v154_14_cursor = (v154_7).read_zipper();
  let v154_14_origin = v154_14_cursor.path().len();
  for v154_14_byte in v154_14_cursor.child_mask().iter() {
    v154_14_cursor.descend_to_existing_byte(v154_14_byte);
    {
    let v155_2: Space = singleton(&v154_14_cursor.path()[v154_14_origin..(v154_14_origin + 1)]);
    let v155_3: Space = intersect(&(*CONSTANT_21),&(v155_2));
    let v155_4: Space = if has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
    drop(v155_3);
    let v155_5: Space = subtract(&(*CONSTANT_0),&(v155_4));
    drop(v155_4);
    let v155_7: Space = if (&(v155_5)).is_empty() { Space::new() } else {
      let v156_6: Space = routine_9(c, &v154_14_cursor.path()[v154_14_origin..(v154_14_origin + 1)], &v154_14_cursor);
      compose(&(v155_5),&(v156_6))
    };
    drop(v155_5);
    let v155_8: Space = intersect(&(*CONSTANT_21),&(v155_2));
    drop(v155_2);
    let v155_9: Space = if has_head(&(v155_8)) { singleton(&[]) } else { Space::new() };
    drop(v155_8);
    let v155_11: Space = if (&(v155_9)).is_empty() { Space::new() } else {
      let mut v157_10 = Space::new();
      let mut v157_10_write = v157_10.write_zipper();
      for v157_10_byte in v154_14_cursor.child_mask().iter() {
        v154_14_cursor.descend_to_existing_byte(v157_10_byte);
        {
        let v158_2: Space = singleton(&v154_14_cursor.path()[(v154_14_origin + 1)..(v154_14_origin + 2)]);
        let v158_3: Space = intersect(&(*CONSTANT_21),&(v158_2));
        let v158_4: Space = if has_head(&(v158_3)) { singleton(&[]) } else { Space::new() };
        drop(v158_3);
        let v158_5: Space = subtract(&(*CONSTANT_0),&(v158_4));
        drop(v158_4);
        let v158_7: Space = if (&(v158_5)).is_empty() { Space::new() } else {
          let v159_6: Space = routine_16(c, &v154_14_cursor.path()[(v154_14_origin + 1)..(v154_14_origin + 2)], &v154_14_cursor.path()[v154_14_origin..(v154_14_origin + 1)], &v154_14_cursor);
          compose(&(v158_5),&(v159_6))
        };
        drop(v158_5);
        let v158_8: Space = intersect(&(*CONSTANT_21),&(v158_2));
        drop(v158_2);
        let v158_9: Space = if has_head(&(v158_8)) { singleton(&[]) } else { Space::new() };
        drop(v158_8);
        let v158_11: Space = if (&(v158_9)).is_empty() { Space::new() } else {
          let v160_10: Space = routine_17(c, &v154_14_cursor.path()[(v154_14_origin + 1)..(v154_14_origin + 2)], &v154_14_cursor.path()[v154_14_origin..(v154_14_origin + 1)], &v154_14_cursor);
          compose(&(v158_9),&(v160_10))
        };
        drop(v158_9);
        let v158_12: Space = unite(&(v158_7),&(v158_11));
        join_wrapped_into(&mut v157_10_write,&((v158_12).read_zipper()),&[]);
        }
        v154_14_cursor.ascend(1);
      }
      drop(v157_10_write);
      compose(&(v155_9),&(v157_10))
    };
    drop(v155_9);
    let v155_12: Space = unite(&(v155_7),&(v155_11));
    join_wrapped_into(&mut v154_14_write,&((v155_12).read_zipper()),&[]);
    }
    v154_14_cursor.ascend(1);
  }
  drop(v154_14_cursor);
  drop(v154_14_write);
  let v154_15: Space = intersect(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))),&(v154_14));
  let v154_16: Space = range_const::<{2},{3}>(&(v154_15));
  let mut v154_25 = Space::new();
  let mut v154_25_write = v154_25.write_zipper();
  let mut v154_25_cursor = (v154_16).read_zipper();
  let v154_25_origin = v154_25_cursor.path().len();
  for v154_25_byte in v154_25_cursor.child_mask().iter() {
    v154_25_cursor.descend_to_existing_byte(v154_25_byte);
    {
    let v161_2: Space = singleton(&v154_25_cursor.path()[v154_25_origin..(v154_25_origin + 1)]);
    let v161_3: Space = intersect(&(*CONSTANT_21),&(v161_2));
    let v161_4: Space = if has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
    drop(v161_3);
    let v161_5: Space = subtract(&(*CONSTANT_0),&(v161_4));
    drop(v161_4);
    let v161_7: Space = if (&(v161_5)).is_empty() { Space::new() } else {
      let mut v162_6 = Space::new();
      let mut v162_6_write = v162_6.write_zipper();
      for v162_6_byte in v154_25_cursor.child_mask().iter() {
        v154_25_cursor.descend_to_existing_byte(v162_6_byte);
        {
        let v163_2: Space = singleton(&v154_25_cursor.path()[(v154_25_origin + 1)..(v154_25_origin + 2)]);
        let v163_3: Space = intersect(&(*CONSTANT_21),&(v163_2));
        let v163_4: Space = if has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
        drop(v163_3);
        let v163_5: Space = subtract(&(*CONSTANT_0),&(v163_4));
        drop(v163_4);
        let v163_8: Space = if (&(v163_5)).is_empty() { Space::new() } else {
          let v164_7: Space = routine_18(c, &v154_25_cursor.path()[v154_25_origin..(v154_25_origin + 2)], &v154_25_cursor);
          compose(&(v163_5),&(v164_7))
        };
        drop(v163_5);
        let v163_9: Space = intersect(&(*CONSTANT_21),&(v163_2));
        drop(v163_2);
        let v163_10: Space = if has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
        drop(v163_9);
        let v163_11: Space = compose(&(v163_10),&(*CONSTANT_24));
        drop(v163_10);
        let v163_12: Space = unite(&(v163_8),&(v163_11));
        drop(v163_11);
        join_wrapped_into(&mut v162_6_write,&((v163_12).read_zipper()),&[]);
        }
        v154_25_cursor.ascend(1);
      }
      drop(v162_6_write);
      compose(&(v161_5),&(v162_6))
    };
    drop(v161_5);
    let v161_8: Space = intersect(&(*CONSTANT_21),&(v161_2));
    drop(v161_2);
    let v161_9: Space = if has_head(&(v161_8)) { singleton(&[]) } else { Space::new() };
    drop(v161_8);
    let v161_10: Space = compose(&(v161_9),&(*CONSTANT_24));
    drop(v161_9);
    let v161_11: Space = unite(&(v161_7),&(v161_10));
    drop(v161_10);
    join_wrapped_into(&mut v154_25_write,&((v161_11).read_zipper()),&[]);
    }
    v154_25_cursor.ascend(1);
  }
  drop(v154_25_cursor);
  drop(v154_25_write);
  let mut v154_32 = Space::new();
  let mut v154_32_write = v154_32.write_zipper();
  let mut v154_32_cursor = (v154_7).read_zipper();
  let v154_32_origin = v154_32_cursor.path().len();
  for v154_32_byte in v154_32_cursor.child_mask().iter() {
    v154_32_cursor.descend_to_existing_byte(v154_32_byte);
    {
    let v165_2: Space = singleton(&v154_32_cursor.path()[v154_32_origin..(v154_32_origin + 1)]);
    let v165_3: Space = intersect(&(*CONSTANT_21),&(v165_2));
    let v165_4: Space = if has_head(&(v165_3)) { singleton(&[]) } else { Space::new() };
    drop(v165_3);
    let v165_5: Space = subtract(&(*CONSTANT_0),&(v165_4));
    drop(v165_4);
    let v165_7: Space = if (&(v165_5)).is_empty() { Space::new() } else {
      let v166_6: Space = routine_9(c, &v154_32_cursor.path()[v154_32_origin..(v154_32_origin + 1)], &v154_32_cursor);
      compose(&(v165_5),&(v166_6))
    };
    drop(v165_5);
    let v165_8: Space = intersect(&(*CONSTANT_21),&(v165_2));
    drop(v165_2);
    let v165_9: Space = if has_head(&(v165_8)) { singleton(&[]) } else { Space::new() };
    drop(v165_8);
    let v165_11: Space = if (&(v165_9)).is_empty() { Space::new() } else {
      let mut v167_10 = Space::new();
      let mut v167_10_write = v167_10.write_zipper();
      for v167_10_byte in v154_32_cursor.child_mask().iter() {
        v154_32_cursor.descend_to_existing_byte(v167_10_byte);
        {
        let v168_2: Space = singleton(&v154_32_cursor.path()[(v154_32_origin + 1)..(v154_32_origin + 2)]);
        let v168_3: Space = intersect(&(*CONSTANT_21),&(v168_2));
        let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
        drop(v168_3);
        let v168_5: Space = subtract(&(*CONSTANT_0),&(v168_4));
        drop(v168_4);
        let v168_7: Space = if (&(v168_5)).is_empty() { Space::new() } else {
          let v169_6: Space = routine_16(c, &v154_32_cursor.path()[(v154_32_origin + 1)..(v154_32_origin + 2)], &v154_32_cursor.path()[v154_32_origin..(v154_32_origin + 1)], &v154_32_cursor);
          compose(&(v168_5),&(v169_6))
        };
        drop(v168_5);
        let v168_8: Space = intersect(&(*CONSTANT_21),&(v168_2));
        drop(v168_2);
        let v168_9: Space = if has_head(&(v168_8)) { singleton(&[]) } else { Space::new() };
        drop(v168_8);
        let v168_11: Space = if (&(v168_9)).is_empty() { Space::new() } else {
          let v170_10: Space = routine_17(c, &v154_32_cursor.path()[(v154_32_origin + 1)..(v154_32_origin + 2)], &v154_32_cursor.path()[v154_32_origin..(v154_32_origin + 1)], &v154_32_cursor);
          compose(&(v168_9),&(v170_10))
        };
        drop(v168_9);
        let v168_12: Space = unite(&(v168_7),&(v168_11));
        join_wrapped_into(&mut v167_10_write,&((v168_12).read_zipper()),&[]);
        }
        v154_32_cursor.ascend(1);
      }
      drop(v167_10_write);
      compose(&(v165_9),&(v167_10))
    };
    drop(v165_9);
    let v165_12: Space = unite(&(v165_7),&(v165_11));
    join_wrapped_into(&mut v154_32_write,&((v165_12).read_zipper()),&[]);
    }
    v154_32_cursor.ascend(1);
  }
  drop(v154_32_cursor);
  drop(v154_32_write);
  let v154_33: Space = intersect(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))),&(v154_32));
  let v154_34: Space = range_const::<{3},{4}>(&(v154_33));
  let mut v154_43 = Space::new();
  let mut v154_43_write = v154_43.write_zipper();
  let mut v154_43_cursor = (v154_34).read_zipper();
  let v154_43_origin = v154_43_cursor.path().len();
  for v154_43_byte in v154_43_cursor.child_mask().iter() {
    v154_43_cursor.descend_to_existing_byte(v154_43_byte);
    {
    let v171_2: Space = singleton(&v154_43_cursor.path()[v154_43_origin..(v154_43_origin + 1)]);
    let v171_3: Space = intersect(&(*CONSTANT_21),&(v171_2));
    let v171_4: Space = if has_head(&(v171_3)) { singleton(&[]) } else { Space::new() };
    drop(v171_3);
    let v171_5: Space = subtract(&(*CONSTANT_0),&(v171_4));
    drop(v171_4);
    let v171_7: Space = if (&(v171_5)).is_empty() { Space::new() } else {
      let mut v172_6 = Space::new();
      let mut v172_6_write = v172_6.write_zipper();
      for v172_6_byte in v154_43_cursor.child_mask().iter() {
        v154_43_cursor.descend_to_existing_byte(v172_6_byte);
        {
        let v173_2: Space = singleton(&v154_43_cursor.path()[(v154_43_origin + 1)..(v154_43_origin + 2)]);
        let v173_3: Space = intersect(&(*CONSTANT_21),&(v173_2));
        let v173_4: Space = if has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
        drop(v173_3);
        let v173_5: Space = subtract(&(*CONSTANT_0),&(v173_4));
        drop(v173_4);
        let v173_8: Space = if (&(v173_5)).is_empty() { Space::new() } else {
          let v174_7: Space = routine_19(c, &v154_43_cursor.path()[v154_43_origin..(v154_43_origin + 2)], &v154_43_cursor);
          compose(&(v173_5),&(v174_7))
        };
        drop(v173_5);
        let v173_9: Space = intersect(&(*CONSTANT_21),&(v173_2));
        drop(v173_2);
        let v173_10: Space = if has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
        drop(v173_9);
        let v173_11: Space = compose(&(v173_10),&(*CONSTANT_24));
        drop(v173_10);
        let v173_12: Space = unite(&(v173_8),&(v173_11));
        drop(v173_11);
        join_wrapped_into(&mut v172_6_write,&((v173_12).read_zipper()),&[]);
        }
        v154_43_cursor.ascend(1);
      }
      drop(v172_6_write);
      compose(&(v171_5),&(v172_6))
    };
    drop(v171_5);
    let v171_8: Space = intersect(&(*CONSTANT_21),&(v171_2));
    drop(v171_2);
    let v171_9: Space = if has_head(&(v171_8)) { singleton(&[]) } else { Space::new() };
    drop(v171_8);
    let v171_10: Space = compose(&(v171_9),&(*CONSTANT_24));
    drop(v171_9);
    let v171_11: Space = unite(&(v171_7),&(v171_10));
    drop(v171_10);
    join_wrapped_into(&mut v154_43_write,&((v171_11).read_zipper()),&[]);
    }
    v154_43_cursor.ascend(1);
  }
  drop(v154_43_cursor);
  drop(v154_43_write);
  let v154_44: Space = subtract(&(v154_25),&(v154_43));
  let v154_45: Space = if (&(v154_44)).is_empty() { Space::new() } else {
    compose(&(v154_44),&(v154_7))
  };
  drop(v154_7);
  let mut v154_52 = Space::new();
  let mut v154_52_write = v154_52.write_zipper();
  let mut v154_52_cursor = (v154_45).read_zipper();
  let v154_52_origin = v154_52_cursor.path().len();
  for v154_52_byte in v154_52_cursor.child_mask().iter() {
    v154_52_cursor.descend_to_existing_byte(v154_52_byte);
    {
    let v176_2: Space = singleton(&v154_52_cursor.path()[v154_52_origin..(v154_52_origin + 1)]);
    let v176_3: Space = intersect(&(*CONSTANT_21),&(v176_2));
    let v176_4: Space = if has_head(&(v176_3)) { singleton(&[]) } else { Space::new() };
    drop(v176_3);
    let v176_5: Space = subtract(&(*CONSTANT_0),&(v176_4));
    drop(v176_4);
    let v176_7: Space = if (&(v176_5)).is_empty() { Space::new() } else {
      let mut v177_6 = Space::new();
      let mut v177_6_write = v177_6.write_zipper();
      for v177_6_byte in v154_52_cursor.child_mask().iter() {
        v154_52_cursor.descend_to_existing_byte(v177_6_byte);
        {
        let v178_2: Space = singleton(&v154_52_cursor.path()[(v154_52_origin + 1)..(v154_52_origin + 2)]);
        let v178_3: Space = intersect(&(*CONSTANT_21),&(v178_2));
        let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
        drop(v178_3);
        let v178_5: Space = subtract(&(*CONSTANT_0),&(v178_4));
        drop(v178_4);
        let v178_8: Space = if (&(v178_5)).is_empty() { Space::new() } else {
          let v179_7: Space = routine_20(c, &v154_52_cursor.path()[v154_52_origin..(v154_52_origin + 2)], &v154_52_cursor);
          compose(&(v178_5),&(v179_7))
        };
        drop(v178_5);
        let v178_9: Space = intersect(&(*CONSTANT_21),&(v178_2));
        drop(v178_2);
        let v178_10: Space = if has_head(&(v178_9)) { singleton(&[]) } else { Space::new() };
        drop(v178_9);
        let v178_11: Space = compose(&(v178_10),&v154_52_cursor);
        drop(v178_10);
        let v178_12: Space = unite(&(v178_8),&(v178_11));
        drop(v178_11);
        join_wrapped_into(&mut v177_6_write,&((v178_12).read_zipper()),&[]);
        }
        v154_52_cursor.ascend(1);
      }
      drop(v177_6_write);
      compose(&(v176_5),&(v177_6))
    };
    drop(v176_5);
    let v176_8: Space = intersect(&(*CONSTANT_21),&(v176_2));
    drop(v176_2);
    let v176_9: Space = if has_head(&(v176_8)) { singleton(&[]) } else { Space::new() };
    drop(v176_8);
    let v176_10: Space = compose(&(v176_9),&v154_52_cursor);
    drop(v176_9);
    let v176_11: Space = unite(&(v176_7),&(v176_10));
    drop(v176_10);
    join_wrapped_into(&mut v154_52_write,&((v176_11).read_zipper()),&[]);
    }
    v154_52_cursor.ascend(1);
  }
  drop(v154_52_cursor);
  drop(v154_52_write);
  (v154_52).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v180_10 = Space::new();
  let mut v180_10_write = v180_10.write_zipper();
  let mut v180_10_cursor = (*s0).read_zipper();
  let v180_10_origin = v180_10_cursor.path().len();
  for v180_10_byte in v180_10_cursor.child_mask().iter() {
    v180_10_cursor.descend_to_existing_byte(v180_10_byte);
    {
    let v181_2: Space = singleton(&v180_10_cursor.path()[v180_10_origin..(v180_10_origin + 1)]);
    let v181_3: Space = intersect(&(*CONSTANT_21),&(v181_2));
    let v181_4: Space = if has_head(&(v181_3)) { singleton(&[]) } else { Space::new() };
    drop(v181_3);
    let v181_5: Space = subtract(&(*CONSTANT_0),&(v181_4));
    drop(v181_4);
    let v181_8: Space = if (&(v181_5)).is_empty() { Space::new() } else {
      let v182_6: Path = concat_path(&(*p0),&v180_10_cursor.path()[v180_10_origin..(v180_10_origin + 1)]);
      let v182_7: Space = routine_16(c, &(v182_6), &(*p1), &v180_10_cursor);
      compose(&(v181_5),&(v182_7))
    };
    drop(v181_5);
    let v181_9: Space = intersect(&(*CONSTANT_21),&(v181_2));
    drop(v181_2);
    let v181_10: Space = if has_head(&(v181_9)) { singleton(&[]) } else { Space::new() };
    drop(v181_9);
    let v181_16: Space = if (&(v181_10)).is_empty() { Space::new() } else {
      let v183_6: Path = concat_path(&(*p0),&v180_10_cursor.path()[v180_10_origin..(v180_10_origin + 1)]);
      let v183_12: Space = if (&(descend_cursor((*CONSTANT_25).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor((*CONSTANT_25).read_zipper(),&(*p1))),&(descend_cursor(descend_cursor((*CONSTANT_25).read_zipper(),&(*p0)),&v180_10_cursor.path()[v180_10_origin..(v180_10_origin + 1)])))
      };
      let v183_13: Path = concat_path(&(*p1),&(v183_6));
      drop(v183_6);
      let v183_14: Space = singleton(&(v183_13));
      drop(v183_13);
      let v183_15: Space = subtract(&(v183_12),&(v183_14));
      drop(v183_12);
      drop(v183_14);
      compose(&(v181_10),&(v183_15))
    };
    drop(v181_10);
    let v181_17: Space = unite(&(v181_8),&(v181_16));
    drop(v181_16);
    join_wrapped_into(&mut v180_10_write,&((v181_17).read_zipper()),&[]);
    }
    v180_10_cursor.ascend(1);
  }
  drop(v180_10_cursor);
  drop(v180_10_write);
  (v180_10).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v185_7: Space = if (&(descend_cursor((*CONSTANT_25).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_25).read_zipper(),&(*p1))),&(descend_cursor((*CONSTANT_25).read_zipper(),&(*p0))))
  };
  let v185_8: Path = concat_path(&(*p1),&(*p0));
  let v185_9: Space = singleton(&(v185_8));
  drop(v185_8);
  let v185_10: Space = subtract(&(v185_7),&(v185_9));
  drop(v185_7);
  drop(v185_9);
  (v185_10).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v187_6 = Space::new();
  let mut v187_6_write = v187_6.write_zipper();
  let mut v187_6_cursor = (*s0).read_zipper();
  let v187_6_origin = v187_6_cursor.path().len();
  for v187_6_byte in v187_6_cursor.child_mask().iter() {
    v187_6_cursor.descend_to_existing_byte(v187_6_byte);
    {
    let v188_2: Space = singleton(&v187_6_cursor.path()[v187_6_origin..(v187_6_origin + 1)]);
    let v188_3: Space = intersect(&(*CONSTANT_21),&(v188_2));
    let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
    drop(v188_3);
    let v188_5: Space = subtract(&(*CONSTANT_0),&(v188_4));
    drop(v188_4);
    let v188_8: Space = if (&(v188_5)).is_empty() { Space::new() } else {
      let v189_6: Path = concat_path(&(*p0),&v187_6_cursor.path()[v187_6_origin..(v187_6_origin + 1)]);
      let v189_7: Space = routine_18(c, &(v189_6), &v187_6_cursor);
      drop(v189_6);
      compose(&(v188_5),&(v189_7))
    };
    drop(v188_5);
    let v188_9: Space = intersect(&(*CONSTANT_21),&(v188_2));
    drop(v188_2);
    let v188_10: Space = if has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
    drop(v188_9);
    let v188_11: Space = compose(&(v188_10),&(*CONSTANT_24));
    drop(v188_10);
    let v188_12: Space = unite(&(v188_8),&(v188_11));
    drop(v188_11);
    join_wrapped_into(&mut v187_6_write,&((v188_12).read_zipper()),&[]);
    }
    v187_6_cursor.ascend(1);
  }
  drop(v187_6_cursor);
  drop(v187_6_write);
  (v187_6).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v190_6 = Space::new();
  let mut v190_6_write = v190_6.write_zipper();
  let mut v190_6_cursor = (*s0).read_zipper();
  let v190_6_origin = v190_6_cursor.path().len();
  for v190_6_byte in v190_6_cursor.child_mask().iter() {
    v190_6_cursor.descend_to_existing_byte(v190_6_byte);
    {
    let v191_2: Space = singleton(&v190_6_cursor.path()[v190_6_origin..(v190_6_origin + 1)]);
    let v191_3: Space = intersect(&(*CONSTANT_21),&(v191_2));
    let v191_4: Space = if has_head(&(v191_3)) { singleton(&[]) } else { Space::new() };
    drop(v191_3);
    let v191_5: Space = subtract(&(*CONSTANT_0),&(v191_4));
    drop(v191_4);
    let v191_8: Space = if (&(v191_5)).is_empty() { Space::new() } else {
      let v192_6: Path = concat_path(&(*p0),&v190_6_cursor.path()[v190_6_origin..(v190_6_origin + 1)]);
      let v192_7: Space = routine_19(c, &(v192_6), &v190_6_cursor);
      drop(v192_6);
      compose(&(v191_5),&(v192_7))
    };
    drop(v191_5);
    let v191_9: Space = intersect(&(*CONSTANT_21),&(v191_2));
    drop(v191_2);
    let v191_10: Space = if has_head(&(v191_9)) { singleton(&[]) } else { Space::new() };
    drop(v191_9);
    let v191_11: Space = compose(&(v191_10),&(*CONSTANT_24));
    drop(v191_10);
    let v191_12: Space = unite(&(v191_8),&(v191_11));
    drop(v191_11);
    join_wrapped_into(&mut v190_6_write,&((v191_12).read_zipper()),&[]);
    }
    v190_6_cursor.ascend(1);
  }
  drop(v190_6_cursor);
  drop(v190_6_write);
  (v190_6).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v193_5 = Space::new();
  let mut v193_5_write = v193_5.write_zipper();
  let mut v193_5_cursor = (*s0).read_zipper();
  let v193_5_origin = v193_5_cursor.path().len();
  for v193_5_byte in v193_5_cursor.child_mask().iter() {
    v193_5_cursor.descend_to_existing_byte(v193_5_byte);
    {
    let v194_2: Space = singleton(&v193_5_cursor.path()[v193_5_origin..(v193_5_origin + 1)]);
    let v194_3: Space = intersect(&(*CONSTANT_21),&(v194_2));
    let v194_4: Space = if has_head(&(v194_3)) { singleton(&[]) } else { Space::new() };
    drop(v194_3);
    let v194_5: Space = subtract(&(*CONSTANT_0),&(v194_4));
    drop(v194_4);
    let v194_8: Space = if (&(v194_5)).is_empty() { Space::new() } else {
      let v195_6: Path = concat_path(&(*p0),&v193_5_cursor.path()[v193_5_origin..(v193_5_origin + 1)]);
      let v195_7: Space = routine_20(c, &(v195_6), &v193_5_cursor);
      drop(v195_6);
      compose(&(v194_5),&(v195_7))
    };
    drop(v194_5);
    let v194_9: Space = intersect(&(*CONSTANT_21),&(v194_2));
    drop(v194_2);
    let v194_10: Space = if has_head(&(v194_9)) { singleton(&[]) } else { Space::new() };
    drop(v194_9);
    let v194_11: Space = compose(&(v194_10),&v193_5_cursor);
    drop(v194_10);
    let v194_12: Space = unite(&(v194_8),&(v194_11));
    drop(v194_11);
    join_wrapped_into(&mut v193_5_write,&((v194_12).read_zipper()),&[]);
    }
    v193_5_cursor.ascend(1);
  }
  drop(v193_5_cursor);
  drop(v193_5_write);
  (v193_5).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
