#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("12 16 0 0 0 0 0 0 0 1 0 0 0 2 0 0 0 3 16 0 0 0 0 0 0 0 2 0 0 0 3 0 0 0 1 16 0 0 0 0 0 0 0 3 0 0 0 1 0 0 0 2 16 0 0 0 4 0 0 0 1 0 0 0 2 0 0 0 3 16 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 1 16 0 0 0 4 0 0 0 3 0 0 0 1 0 0 0 2 16 0 0 0 5 0 0 0 1 0 0 0 3 0 0 0 2 16 0 0 0 5 0 0 0 2 0 0 0 1 0 0 0 3 16 0 0 0 5 0 0 0 3 0 0 0 2 0 0 0 1 16 0 0 0 6 0 0 0 1 0 0 0 3 0 0 0 2 16 0 0 0 6 0 0 0 2 0 0 0 1 0 0 0 3 16 0 0 0 6 0 0 0 3 0 0 0 2 0 0 0 1"));
fn routine_0(c: &mut Context) -> Space {
  (*CONSTANT_0).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
