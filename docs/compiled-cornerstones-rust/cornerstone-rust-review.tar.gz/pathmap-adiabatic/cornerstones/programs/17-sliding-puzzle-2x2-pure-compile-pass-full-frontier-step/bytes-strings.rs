#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("12 9 66 76 0 49 0 51 0 50 0 9 66 76 0 50 0 49 0 51 0 9 66 76 0 51 0 50 0 49 0 9 66 82 0 49 0 51 0 50 0 9 66 82 0 50 0 49 0 51 0 9 66 82 0 51 0 50 0 49 0 9 84 76 0 49 0 50 0 51 0 9 84 76 0 50 0 51 0 49 0 9 84 76 0 51 0 49 0 50 0 9 84 82 0 49 0 50 0 51 0 9 84 82 0 50 0 51 0 49 0 9 84 82 0 51 0 49 0 50 0"));
fn routine_0(c: &mut Context) -> Space {
  (*CONSTANT_0).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
