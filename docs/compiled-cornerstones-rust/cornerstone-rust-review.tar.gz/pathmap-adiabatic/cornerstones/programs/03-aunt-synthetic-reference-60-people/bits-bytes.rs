#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1,0,1,0,0,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,0,0,1,0,0,0,1,1]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>, s1: Option<&Space>) -> Space {
  let mut v0_11 = Space::new();
  let mut v0_11_write = v0_11.write_zipper();
  let mut v0_11_cursor = (*s1.expect("unbound native input")).read_zipper();
  let v0_11_origin = v0_11_cursor.path().len();
  for v0_11_byte in v0_11_cursor.child_mask().iter() {
    v0_11_cursor.descend_to_existing_byte(v0_11_byte);
    {
    let v1_2: Space = singleton(&v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 1)]);
    let v1_3: Space = intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (&(v1_5)).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_write = v2_6.write_zipper();
      for v2_6_byte in v0_11_cursor.child_mask().iter() {
        v0_11_cursor.descend_to_existing_byte(v2_6_byte);
        {
        let v3_2: Space = singleton(&v0_11_cursor.path()[(v0_11_origin + 1)..(v0_11_origin + 2)]);
        let v3_3: Space = intersect(&(*CONSTANT_1),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_0),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (&(v3_5)).is_empty() { Space::new() } else {
          let v4_7: Space = routine_1(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_1),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (&(v3_10)).is_empty() { Space::new() } else {
          let v5_11: Space = routine_2(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        join_wrapped_into(&mut v2_6_write,&((v3_13).read_zipper()),&[]);
        }
        v0_11_cursor.ascend(1);
      }
      drop(v2_6_write);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (&(v1_9)).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_write = v6_10.write_zipper();
      for v6_10_byte in v0_11_cursor.child_mask().iter() {
        v0_11_cursor.descend_to_existing_byte(v6_10_byte);
        {
        let v7_2: Space = singleton(&v0_11_cursor.path()[(v0_11_origin + 1)..(v0_11_origin + 2)]);
        let v7_3: Space = intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (&(v7_5)).is_empty() { Space::new() } else {
          let v8_7: Space = routine_1(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (&(v7_10)).is_empty() { Space::new() } else {
          let v9_11: Space = routine_3(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        join_wrapped_into(&mut v6_10_write,&((v7_13).read_zipper()),&[]);
        }
        v0_11_cursor.ascend(1);
      }
      drop(v6_10_write);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    join_wrapped_into(&mut v0_11_write,&((v1_12).read_zipper()),&[]);
    }
    v0_11_cursor.ascend(1);
  }
  drop(v0_11_cursor);
  drop(v0_11_write);
  let v0_13: Space = wrap(&(v0_11),&(*CONSTANT_2));
  (v0_13).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v10_34 = Space::new();
  let mut v10_34_write = v10_34.write_zipper();
  let mut v10_34_cursor = (*s0).read_zipper();
  let v10_34_origin = v10_34_cursor.path().len();
  for v10_34_byte in v10_34_cursor.child_mask().iter() {
    v10_34_cursor.descend_to_existing_byte(v10_34_byte);
    {
    let v11_2: Space = singleton(&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]);
    let v11_3: Space = intersect(&(*CONSTANT_1),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (&(v11_5)).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]);
      let mut v12_7 = Space::new();
      let mut v12_7_write = v12_7.write_zipper();
      for v12_7_byte in v10_34_cursor.child_mask().iter() {
        v10_34_cursor.descend_to_existing_byte(v12_7_byte);
        {
        let v13_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
        let v13_3: Space = intersect(&(*CONSTANT_1),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_0),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (&(v13_5)).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v12_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
          let mut v14_7 = Space::new();
          let mut v14_7_write = v14_7.write_zipper();
          for v14_7_byte in v10_34_cursor.child_mask().iter() {
            v10_34_cursor.descend_to_existing_byte(v14_7_byte);
            {
            let v15_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
            let v15_3: Space = intersect(&(*CONSTANT_1),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (&(v15_5)).is_empty() { Space::new() } else {
              let v16_6: Path = concat_path(&(v14_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v16_7: Space = routine_4(c, &(v16_6), &v10_34_cursor, &(*s1));
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_1),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (&(v15_10)).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v14_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v17_11: Space = routine_5(c, &(v17_6), &v10_34_cursor, &(*s1));
              drop(v17_6);
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            join_wrapped_into(&mut v14_7_write,&((v15_13).read_zipper()),&[]);
            }
            v10_34_cursor.ascend(1);
          }
          drop(v14_7_write);
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_1),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (&(v13_10)).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v12_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
          let mut v18_11 = Space::new();
          let mut v18_11_write = v18_11.write_zipper();
          for v18_11_byte in v10_34_cursor.child_mask().iter() {
            v10_34_cursor.descend_to_existing_byte(v18_11_byte);
            {
            let v19_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
            let v19_3: Space = intersect(&(*CONSTANT_1),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
            drop(v19_4);
            let v19_8: Space = if (&(v19_5)).is_empty() { Space::new() } else {
              let v20_6: Path = concat_path(&(v18_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v20_7: Space = routine_4(c, &(v20_6), &v10_34_cursor, &(*s1));
              compose(&(v19_5),&(v20_7))
            };
            drop(v19_5);
            let v19_9: Space = intersect(&(*CONSTANT_1),&(v19_2));
            drop(v19_2);
            let v19_10: Space = if has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
            drop(v19_9);
            let v19_12: Space = if (&(v19_10)).is_empty() { Space::new() } else {
              let v21_6: Path = concat_path(&(v18_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v21_11: Space = routine_3(c, &(v21_6), &v10_34_cursor, &(*s1));
              drop(v21_6);
              compose(&(v19_10),&(v21_11))
            };
            drop(v19_10);
            let v19_13: Space = unite(&(v19_8),&(v19_12));
            join_wrapped_into(&mut v18_11_write,&((v19_13).read_zipper()),&[]);
            }
            v10_34_cursor.ascend(1);
          }
          drop(v18_11_write);
          drop(v18_6);
          compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        join_wrapped_into(&mut v12_7_write,&((v13_13).read_zipper()),&[]);
        }
        v10_34_cursor.ascend(1);
      }
      drop(v12_7_write);
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_1),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_13: Space = if (&(v11_10)).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]);
      let mut v22_12 = Space::new();
      let mut v22_12_write = v22_12.write_zipper();
      for v22_12_byte in v10_34_cursor.child_mask().iter() {
        v10_34_cursor.descend_to_existing_byte(v22_12_byte);
        {
        let v23_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
        let v23_3: Space = intersect(&(*CONSTANT_1),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_0),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (&(v23_5)).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v22_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
          let mut v24_7 = Space::new();
          let mut v24_7_write = v24_7.write_zipper();
          for v24_7_byte in v10_34_cursor.child_mask().iter() {
            v10_34_cursor.descend_to_existing_byte(v24_7_byte);
            {
            let v25_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
            let v25_3: Space = intersect(&(*CONSTANT_1),&(v25_2));
            let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
            drop(v25_3);
            let v25_5: Space = subtract(&(*CONSTANT_0),&(v25_4));
            drop(v25_4);
            let v25_8: Space = if (&(v25_5)).is_empty() { Space::new() } else {
              let v26_6: Path = concat_path(&(v24_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v26_7: Space = routine_4(c, &(v26_6), &v10_34_cursor, &(*s1));
              compose(&(v25_5),&(v26_7))
            };
            drop(v25_5);
            let v25_9: Space = intersect(&(*CONSTANT_1),&(v25_2));
            drop(v25_2);
            let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
            drop(v25_9);
            let v25_12: Space = if (&(v25_10)).is_empty() { Space::new() } else {
              let v27_6: Path = concat_path(&(v24_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v27_11: Space = routine_5(c, &(v27_6), &v10_34_cursor, &(*s1));
              drop(v27_6);
              compose(&(v25_10),&(v27_11))
            };
            drop(v25_10);
            let v25_13: Space = unite(&(v25_8),&(v25_12));
            join_wrapped_into(&mut v24_7_write,&((v25_13).read_zipper()),&[]);
            }
            v10_34_cursor.ascend(1);
          }
          drop(v24_7_write);
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_1),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_18: Space = if (&(v23_10)).is_empty() { Space::new() } else {
          let v28_12: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)])));
          let mut v28_13 = Space::new();
          let mut v28_13_write = v28_13.write_zipper();
          let mut v28_13_cursor = (v28_12).read_zipper();
          let v28_13_origin = v28_13_cursor.path().len();
          for v28_13_byte in v28_13_cursor.child_mask().iter() {
            v28_13_cursor.descend_to_existing_byte(v28_13_byte);
            {
            let v29_2: Space = singleton(&v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)]);
            let v29_3: Space = intersect(&(*CONSTANT_1),&(v29_2));
            let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
            drop(v29_3);
            let v29_5: Space = subtract(&(*CONSTANT_0),&(v29_4));
            drop(v29_4);
            let v29_7: Space = if (&(v29_5)).is_empty() { Space::new() } else {
              let v30_6: Space = routine_6(c, &v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)], &v28_13_cursor);
              compose(&(v29_5),&(v30_6))
            };
            drop(v29_5);
            let v29_8: Space = intersect(&(*CONSTANT_1),&(v29_2));
            drop(v29_2);
            let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
            drop(v29_8);
            let v29_11: Space = if (&(v29_9)).is_empty() { Space::new() } else {
              let v31_10: Space = routine_7(c, &v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)], &v28_13_cursor);
              compose(&(v29_9),&(v31_10))
            };
            drop(v29_9);
            let v29_12: Space = unite(&(v29_7),&(v29_11));
            join_wrapped_into(&mut v28_13_write,&((v29_12).read_zipper()),&[]);
            }
            v28_13_cursor.ascend(1);
          }
          drop(v28_13_cursor);
          drop(v28_13_write);
          drop(v28_12);
          let v28_14: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v28_13));
          let mut v28_15 = Space::new();
          let mut v28_15_write = v28_15.write_zipper();
          let mut v28_15_cursor = (v28_14).read_zipper();
          let v28_15_origin = v28_15_cursor.path().len();
          for v28_15_byte in v28_15_cursor.child_mask().iter() {
            v28_15_cursor.descend_to_existing_byte(v28_15_byte);
            {
            let v32_2: Space = singleton(&v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)]);
            let v32_3: Space = intersect(&(*CONSTANT_1),&(v32_2));
            let v32_4: Space = if has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
            drop(v32_3);
            let v32_5: Space = subtract(&(*CONSTANT_0),&(v32_4));
            drop(v32_4);
            let v32_7: Space = if (&(v32_5)).is_empty() { Space::new() } else {
              let v33_6: Space = routine_8(c, &v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)], &v28_15_cursor);
              compose(&(v32_5),&(v33_6))
            };
            drop(v32_5);
            let v32_8: Space = intersect(&(*CONSTANT_1),&(v32_2));
            drop(v32_2);
            let v32_9: Space = if has_head(&(v32_8)) { singleton(&[]) } else { Space::new() };
            drop(v32_8);
            let v32_11: Space = if (&(v32_9)).is_empty() { Space::new() } else {
              let v34_10: Space = routine_9(c, &v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)], &v28_15_cursor);
              compose(&(v32_9),&(v34_10))
            };
            drop(v32_9);
            let v32_12: Space = unite(&(v32_7),&(v32_11));
            join_wrapped_into(&mut v28_15_write,&((v32_12).read_zipper()),&[]);
            }
            v28_15_cursor.ascend(1);
          }
          drop(v28_15_cursor);
          drop(v28_15_write);
          let v28_16: Space = subtract(&(v28_15),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)])));
          let v28_17: Space = intersect(&(v28_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
          compose(&(v23_10),&(v28_17))
        };
        drop(v23_10);
        let v35_6: Path = concat_path(&(v22_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
        let v23_19: Space = wrap(&(v23_18),&(v35_6));
        let v23_20: Space = unite(&(v23_8),&(v23_19));
        join_wrapped_into(&mut v22_12_write,&((v23_20).read_zipper()),&[]);
        }
        v10_34_cursor.ascend(1);
      }
      drop(v22_12_write);
      drop(v22_6);
      compose(&(v11_10),&(v22_12))
    };
    drop(v11_10);
    let v11_14: Space = unite(&(v11_8),&(v11_13));
    join_wrapped_into(&mut v10_34_write,&((v11_14).read_zipper()),&[]);
    }
    v10_34_cursor.ascend(1);
  }
  drop(v10_34_cursor);
  drop(v10_34_write);
  (v10_34).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v36_40 = Space::new();
  let mut v36_40_write = v36_40.write_zipper();
  let mut v36_40_cursor = (*s0).read_zipper();
  let v36_40_origin = v36_40_cursor.path().len();
  for v36_40_byte in v36_40_cursor.child_mask().iter() {
    v36_40_cursor.descend_to_existing_byte(v36_40_byte);
    {
    let v37_2: Space = singleton(&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)]);
    let v37_3: Space = intersect(&(*CONSTANT_1),&(v37_2));
    let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
    drop(v37_3);
    let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
    drop(v37_4);
    let v37_8: Space = if (&(v37_5)).is_empty() { Space::new() } else {
      let v38_6: Path = concat_path(&(*p0),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)]);
      let mut v38_7 = Space::new();
      let mut v38_7_write = v38_7.write_zipper();
      for v38_7_byte in v36_40_cursor.child_mask().iter() {
        v36_40_cursor.descend_to_existing_byte(v38_7_byte);
        {
        let v39_2: Space = singleton(&v36_40_cursor.path()[(v36_40_origin + 1)..(v36_40_origin + 2)]);
        let v39_3: Space = intersect(&(*CONSTANT_1),&(v39_2));
        let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_8: Space = if (&(v39_5)).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v38_6),&v36_40_cursor.path()[(v36_40_origin + 1)..(v36_40_origin + 2)]);
          let mut v40_7 = Space::new();
          let mut v40_7_write = v40_7.write_zipper();
          for v40_7_byte in v36_40_cursor.child_mask().iter() {
            v36_40_cursor.descend_to_existing_byte(v40_7_byte);
            {
            let v41_2: Space = singleton(&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
            let v41_3: Space = intersect(&(*CONSTANT_1),&(v41_2));
            let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
            drop(v41_4);
            let v41_8: Space = if (&(v41_5)).is_empty() { Space::new() } else {
              let v42_6: Path = concat_path(&(v40_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v42_7: Space = routine_4(c, &(v42_6), &v36_40_cursor, &(*s1));
              compose(&(v41_5),&(v42_7))
            };
            drop(v41_5);
            let v41_9: Space = intersect(&(*CONSTANT_1),&(v41_2));
            drop(v41_2);
            let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
            drop(v41_9);
            let v41_12: Space = if (&(v41_10)).is_empty() { Space::new() } else {
              let v43_6: Path = concat_path(&(v40_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v43_11: Space = routine_5(c, &(v43_6), &v36_40_cursor, &(*s1));
              drop(v43_6);
              compose(&(v41_10),&(v43_11))
            };
            drop(v41_10);
            let v41_13: Space = unite(&(v41_8),&(v41_12));
            join_wrapped_into(&mut v40_7_write,&((v41_13).read_zipper()),&[]);
            }
            v36_40_cursor.ascend(1);
          }
          drop(v40_7_write);
          compose(&(v39_5),&(v40_7))
        };
        drop(v39_5);
        let v39_9: Space = intersect(&(*CONSTANT_1),&(v39_2));
        drop(v39_2);
        let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
        drop(v39_9);
        let v39_12: Space = if (&(v39_10)).is_empty() { Space::new() } else {
          let v44_6: Path = concat_path(&(v38_6),&v36_40_cursor.path()[(v36_40_origin + 1)..(v36_40_origin + 2)]);
          let mut v44_11 = Space::new();
          let mut v44_11_write = v44_11.write_zipper();
          for v44_11_byte in v36_40_cursor.child_mask().iter() {
            v36_40_cursor.descend_to_existing_byte(v44_11_byte);
            {
            let v45_2: Space = singleton(&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
            let v45_3: Space = intersect(&(*CONSTANT_1),&(v45_2));
            let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
            drop(v45_3);
            let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
            drop(v45_4);
            let v45_8: Space = if (&(v45_5)).is_empty() { Space::new() } else {
              let v46_6: Path = concat_path(&(v44_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v46_7: Space = routine_4(c, &(v46_6), &v36_40_cursor, &(*s1));
              compose(&(v45_5),&(v46_7))
            };
            drop(v45_5);
            let v45_9: Space = intersect(&(*CONSTANT_1),&(v45_2));
            drop(v45_2);
            let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
            drop(v45_9);
            let v45_12: Space = if (&(v45_10)).is_empty() { Space::new() } else {
              let v47_6: Path = concat_path(&(v44_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v47_11: Space = routine_3(c, &(v47_6), &v36_40_cursor, &(*s1));
              drop(v47_6);
              compose(&(v45_10),&(v47_11))
            };
            drop(v45_10);
            let v45_13: Space = unite(&(v45_8),&(v45_12));
            join_wrapped_into(&mut v44_11_write,&((v45_13).read_zipper()),&[]);
            }
            v36_40_cursor.ascend(1);
          }
          drop(v44_11_write);
          drop(v44_6);
          compose(&(v39_10),&(v44_11))
        };
        drop(v39_10);
        let v39_13: Space = unite(&(v39_8),&(v39_12));
        join_wrapped_into(&mut v38_7_write,&((v39_13).read_zipper()),&[]);
        }
        v36_40_cursor.ascend(1);
      }
      drop(v38_7_write);
      compose(&(v37_5),&(v38_7))
    };
    drop(v37_5);
    let v37_9: Space = intersect(&(*CONSTANT_1),&(v37_2));
    drop(v37_2);
    let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
    drop(v37_9);
    let v37_18: Space = if (&(v37_10)).is_empty() { Space::new() } else {
      let v48_12: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)])));
      let mut v48_13 = Space::new();
      let mut v48_13_write = v48_13.write_zipper();
      let mut v48_13_cursor = (v48_12).read_zipper();
      let v48_13_origin = v48_13_cursor.path().len();
      for v48_13_byte in v48_13_cursor.child_mask().iter() {
        v48_13_cursor.descend_to_existing_byte(v48_13_byte);
        {
        let v49_2: Space = singleton(&v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 1)]);
        let v49_3: Space = intersect(&(*CONSTANT_1),&(v49_2));
        let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
        drop(v49_3);
        let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
        drop(v49_4);
        let v49_7: Space = if (&(v49_5)).is_empty() { Space::new() } else {
          let mut v50_6 = Space::new();
          let mut v50_6_write = v50_6.write_zipper();
          for v50_6_byte in v48_13_cursor.child_mask().iter() {
            v48_13_cursor.descend_to_existing_byte(v50_6_byte);
            {
            let v51_2: Space = singleton(&v48_13_cursor.path()[(v48_13_origin + 1)..(v48_13_origin + 2)]);
            let v51_3: Space = intersect(&(*CONSTANT_1),&(v51_2));
            let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
            drop(v51_3);
            let v51_5: Space = subtract(&(*CONSTANT_0),&(v51_4));
            drop(v51_4);
            let v51_8: Space = if (&(v51_5)).is_empty() { Space::new() } else {
              let v52_7: Space = routine_10(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v51_5),&(v52_7))
            };
            drop(v51_5);
            let v51_9: Space = intersect(&(*CONSTANT_1),&(v51_2));
            drop(v51_2);
            let v51_10: Space = if has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
            drop(v51_9);
            let v51_12: Space = if (&(v51_10)).is_empty() { Space::new() } else {
              let v53_11: Space = routine_11(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v51_10),&(v53_11))
            };
            drop(v51_10);
            let v51_13: Space = unite(&(v51_8),&(v51_12));
            join_wrapped_into(&mut v50_6_write,&((v51_13).read_zipper()),&[]);
            }
            v48_13_cursor.ascend(1);
          }
          drop(v50_6_write);
          compose(&(v49_5),&(v50_6))
        };
        drop(v49_5);
        let v49_8: Space = intersect(&(*CONSTANT_1),&(v49_2));
        drop(v49_2);
        let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
        drop(v49_8);
        let v49_11: Space = if (&(v49_9)).is_empty() { Space::new() } else {
          let mut v54_10 = Space::new();
          let mut v54_10_write = v54_10.write_zipper();
          for v54_10_byte in v48_13_cursor.child_mask().iter() {
            v48_13_cursor.descend_to_existing_byte(v54_10_byte);
            {
            let v55_2: Space = singleton(&v48_13_cursor.path()[(v48_13_origin + 1)..(v48_13_origin + 2)]);
            let v55_3: Space = intersect(&(*CONSTANT_1),&(v55_2));
            let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
            drop(v55_3);
            let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
            drop(v55_4);
            let v55_8: Space = if (&(v55_5)).is_empty() { Space::new() } else {
              let v56_7: Space = routine_10(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v55_5),&(v56_7))
            };
            drop(v55_5);
            let v55_9: Space = intersect(&(*CONSTANT_1),&(v55_2));
            drop(v55_2);
            let v55_10: Space = if has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
            drop(v55_9);
            let v55_12: Space = if (&(v55_10)).is_empty() { Space::new() } else {
              let v57_11: Space = routine_12(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v55_10),&(v57_11))
            };
            drop(v55_10);
            let v55_13: Space = unite(&(v55_8),&(v55_12));
            join_wrapped_into(&mut v54_10_write,&((v55_13).read_zipper()),&[]);
            }
            v48_13_cursor.ascend(1);
          }
          drop(v54_10_write);
          compose(&(v49_9),&(v54_10))
        };
        drop(v49_9);
        let v49_12: Space = unite(&(v49_7),&(v49_11));
        join_wrapped_into(&mut v48_13_write,&((v49_12).read_zipper()),&[]);
        }
        v48_13_cursor.ascend(1);
      }
      drop(v48_13_cursor);
      drop(v48_13_write);
      drop(v48_12);
      let v48_14: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v48_13));
      let mut v48_15 = Space::new();
      let mut v48_15_write = v48_15.write_zipper();
      let mut v48_15_cursor = (v48_14).read_zipper();
      let v48_15_origin = v48_15_cursor.path().len();
      for v48_15_byte in v48_15_cursor.child_mask().iter() {
        v48_15_cursor.descend_to_existing_byte(v48_15_byte);
        {
        let v58_2: Space = singleton(&v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 1)]);
        let v58_3: Space = intersect(&(*CONSTANT_1),&(v58_2));
        let v58_4: Space = if has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
        drop(v58_3);
        let v58_5: Space = subtract(&(*CONSTANT_0),&(v58_4));
        drop(v58_4);
        let v58_7: Space = if (&(v58_5)).is_empty() { Space::new() } else {
          let mut v59_6 = Space::new();
          let mut v59_6_write = v59_6.write_zipper();
          for v59_6_byte in v48_15_cursor.child_mask().iter() {
            v48_15_cursor.descend_to_existing_byte(v59_6_byte);
            {
            let v60_2: Space = singleton(&v48_15_cursor.path()[(v48_15_origin + 1)..(v48_15_origin + 2)]);
            let v60_3: Space = intersect(&(*CONSTANT_1),&(v60_2));
            let v60_4: Space = if has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
            drop(v60_3);
            let v60_5: Space = subtract(&(*CONSTANT_0),&(v60_4));
            drop(v60_4);
            let v60_8: Space = if (&(v60_5)).is_empty() { Space::new() } else {
              let v61_7: Space = routine_13(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v60_5),&(v61_7))
            };
            drop(v60_5);
            let v60_9: Space = intersect(&(*CONSTANT_1),&(v60_2));
            drop(v60_2);
            let v60_10: Space = if has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
            drop(v60_9);
            let v60_12: Space = if (&(v60_10)).is_empty() { Space::new() } else {
              let v62_11: Space = routine_14(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v60_10),&(v62_11))
            };
            drop(v60_10);
            let v60_13: Space = unite(&(v60_8),&(v60_12));
            join_wrapped_into(&mut v59_6_write,&((v60_13).read_zipper()),&[]);
            }
            v48_15_cursor.ascend(1);
          }
          drop(v59_6_write);
          compose(&(v58_5),&(v59_6))
        };
        drop(v58_5);
        let v58_8: Space = intersect(&(*CONSTANT_1),&(v58_2));
        drop(v58_2);
        let v58_9: Space = if has_head(&(v58_8)) { singleton(&[]) } else { Space::new() };
        drop(v58_8);
        let v58_11: Space = if (&(v58_9)).is_empty() { Space::new() } else {
          let mut v63_10 = Space::new();
          let mut v63_10_write = v63_10.write_zipper();
          for v63_10_byte in v48_15_cursor.child_mask().iter() {
            v48_15_cursor.descend_to_existing_byte(v63_10_byte);
            {
            let v64_2: Space = singleton(&v48_15_cursor.path()[(v48_15_origin + 1)..(v48_15_origin + 2)]);
            let v64_3: Space = intersect(&(*CONSTANT_1),&(v64_2));
            let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
            drop(v64_3);
            let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
            drop(v64_4);
            let v64_8: Space = if (&(v64_5)).is_empty() { Space::new() } else {
              let v65_7: Space = routine_13(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v64_5),&(v65_7))
            };
            drop(v64_5);
            let v64_9: Space = intersect(&(*CONSTANT_1),&(v64_2));
            drop(v64_2);
            let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
            drop(v64_9);
            let v64_12: Space = if (&(v64_10)).is_empty() { Space::new() } else {
              let v66_11: Space = routine_15(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v64_10),&(v66_11))
            };
            drop(v64_10);
            let v64_13: Space = unite(&(v64_8),&(v64_12));
            join_wrapped_into(&mut v63_10_write,&((v64_13).read_zipper()),&[]);
            }
            v48_15_cursor.ascend(1);
          }
          drop(v63_10_write);
          compose(&(v58_9),&(v63_10))
        };
        drop(v58_9);
        let v58_12: Space = unite(&(v58_7),&(v58_11));
        join_wrapped_into(&mut v48_15_write,&((v58_12).read_zipper()),&[]);
        }
        v48_15_cursor.ascend(1);
      }
      drop(v48_15_cursor);
      drop(v48_15_write);
      let v48_16: Space = subtract(&(v48_15),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)])));
      let v48_17: Space = intersect(&(v48_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
      compose(&(v37_10),&(v48_17))
    };
    drop(v37_10);
    let v67_6: Path = concat_path(&(*p0),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)]);
    let v37_19: Space = wrap(&(v37_18),&(v67_6));
    let v37_20: Space = unite(&(v37_8),&(v37_19));
    join_wrapped_into(&mut v36_40_write,&((v37_20).read_zipper()),&[]);
    }
    v36_40_cursor.ascend(1);
  }
  drop(v36_40_cursor);
  drop(v36_40_write);
  (v36_40).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v68_8: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0))));
  let mut v68_27 = Space::new();
  let mut v68_27_write = v68_27.write_zipper();
  let mut v68_27_cursor = (v68_8).read_zipper();
  let v68_27_origin = v68_27_cursor.path().len();
  for v68_27_byte in v68_27_cursor.child_mask().iter() {
    v68_27_cursor.descend_to_existing_byte(v68_27_byte);
    {
    let v69_2: Space = singleton(&v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 1)]);
    let v69_3: Space = intersect(&(*CONSTANT_1),&(v69_2));
    let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
    drop(v69_3);
    let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
    drop(v69_4);
    let v69_7: Space = if (&(v69_5)).is_empty() { Space::new() } else {
      let mut v70_6 = Space::new();
      let mut v70_6_write = v70_6.write_zipper();
      for v70_6_byte in v68_27_cursor.child_mask().iter() {
        v68_27_cursor.descend_to_existing_byte(v70_6_byte);
        {
        let v71_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 1)..(v68_27_origin + 2)]);
        let v71_3: Space = intersect(&(*CONSTANT_1),&(v71_2));
        let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
        drop(v71_3);
        let v71_5: Space = subtract(&(*CONSTANT_0),&(v71_4));
        drop(v71_4);
        let v71_8: Space = if (&(v71_5)).is_empty() { Space::new() } else {
          let mut v72_7 = Space::new();
          let mut v72_7_write = v72_7.write_zipper();
          for v72_7_byte in v68_27_cursor.child_mask().iter() {
            v68_27_cursor.descend_to_existing_byte(v72_7_byte);
            {
            let v73_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 2)..(v68_27_origin + 3)]);
            let v73_3: Space = intersect(&(*CONSTANT_1),&(v73_2));
            let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
            drop(v73_3);
            let v73_5: Space = subtract(&(*CONSTANT_0),&(v73_4));
            drop(v73_4);
            let v73_8: Space = if (&(v73_5)).is_empty() { Space::new() } else {
              let v74_7: Space = routine_16(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v73_5),&(v74_7))
            };
            drop(v73_5);
            let v73_9: Space = intersect(&(*CONSTANT_1),&(v73_2));
            drop(v73_2);
            let v73_10: Space = if has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
            drop(v73_9);
            let v73_12: Space = if (&(v73_10)).is_empty() { Space::new() } else {
              let v75_11: Space = routine_17(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v73_10),&(v75_11))
            };
            drop(v73_10);
            let v73_13: Space = unite(&(v73_8),&(v73_12));
            join_wrapped_into(&mut v72_7_write,&((v73_13).read_zipper()),&[]);
            }
            v68_27_cursor.ascend(1);
          }
          drop(v72_7_write);
          compose(&(v71_5),&(v72_7))
        };
        drop(v71_5);
        let v71_9: Space = intersect(&(*CONSTANT_1),&(v71_2));
        drop(v71_2);
        let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
        drop(v71_9);
        let v71_12: Space = if (&(v71_10)).is_empty() { Space::new() } else {
          let mut v76_11 = Space::new();
          let mut v76_11_write = v76_11.write_zipper();
          for v76_11_byte in v68_27_cursor.child_mask().iter() {
            v68_27_cursor.descend_to_existing_byte(v76_11_byte);
            {
            let v77_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 2)..(v68_27_origin + 3)]);
            let v77_3: Space = intersect(&(*CONSTANT_1),&(v77_2));
            let v77_4: Space = if has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
            drop(v77_3);
            let v77_5: Space = subtract(&(*CONSTANT_0),&(v77_4));
            drop(v77_4);
            let v77_8: Space = if (&(v77_5)).is_empty() { Space::new() } else {
              let v78_7: Space = routine_16(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v77_5),&(v78_7))
            };
            drop(v77_5);
            let v77_9: Space = intersect(&(*CONSTANT_1),&(v77_2));
            drop(v77_2);
            let v77_10: Space = if has_head(&(v77_9)) { singleton(&[]) } else { Space::new() };
            drop(v77_9);
            let v77_12: Space = if (&(v77_10)).is_empty() { Space::new() } else {
              let v79_11: Space = routine_12(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v77_10),&(v79_11))
            };
            drop(v77_10);
            let v77_13: Space = unite(&(v77_8),&(v77_12));
            join_wrapped_into(&mut v76_11_write,&((v77_13).read_zipper()),&[]);
            }
            v68_27_cursor.ascend(1);
          }
          drop(v76_11_write);
          compose(&(v71_10),&(v76_11))
        };
        drop(v71_10);
        let v71_13: Space = unite(&(v71_8),&(v71_12));
        join_wrapped_into(&mut v70_6_write,&((v71_13).read_zipper()),&[]);
        }
        v68_27_cursor.ascend(1);
      }
      drop(v70_6_write);
      compose(&(v69_5),&(v70_6))
    };
    drop(v69_5);
    let v69_8: Space = intersect(&(*CONSTANT_1),&(v69_2));
    drop(v69_2);
    let v69_9: Space = if has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
    drop(v69_8);
    let v69_11: Space = if (&(v69_9)).is_empty() { Space::new() } else {
      let mut v80_10 = Space::new();
      let mut v80_10_write = v80_10.write_zipper();
      for v80_10_byte in v68_27_cursor.child_mask().iter() {
        v68_27_cursor.descend_to_existing_byte(v80_10_byte);
        {
        let v81_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 1)..(v68_27_origin + 2)]);
        let v81_3: Space = intersect(&(*CONSTANT_1),&(v81_2));
        let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
        drop(v81_3);
        let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
        drop(v81_4);
        let v81_8: Space = if (&(v81_5)).is_empty() { Space::new() } else {
          let mut v82_7 = Space::new();
          let mut v82_7_write = v82_7.write_zipper();
          for v82_7_byte in v68_27_cursor.child_mask().iter() {
            v68_27_cursor.descend_to_existing_byte(v82_7_byte);
            {
            let v83_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 2)..(v68_27_origin + 3)]);
            let v83_3: Space = intersect(&(*CONSTANT_1),&(v83_2));
            let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
            drop(v83_3);
            let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
            drop(v83_4);
            let v83_8: Space = if (&(v83_5)).is_empty() { Space::new() } else {
              let v84_7: Space = routine_16(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v83_5),&(v84_7))
            };
            drop(v83_5);
            let v83_9: Space = intersect(&(*CONSTANT_1),&(v83_2));
            drop(v83_2);
            let v83_10: Space = if has_head(&(v83_9)) { singleton(&[]) } else { Space::new() };
            drop(v83_9);
            let v83_12: Space = if (&(v83_10)).is_empty() { Space::new() } else {
              let v85_11: Space = routine_17(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v83_10),&(v85_11))
            };
            drop(v83_10);
            let v83_13: Space = unite(&(v83_8),&(v83_12));
            join_wrapped_into(&mut v82_7_write,&((v83_13).read_zipper()),&[]);
            }
            v68_27_cursor.ascend(1);
          }
          drop(v82_7_write);
          compose(&(v81_5),&(v82_7))
        };
        drop(v81_5);
        let v81_9: Space = intersect(&(*CONSTANT_1),&(v81_2));
        drop(v81_2);
        let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
        drop(v81_9);
        let v81_11: Space = compose(&(v81_10),&v68_27_cursor);
        drop(v81_10);
        let v81_12: Space = unite(&(v81_8),&(v81_11));
        drop(v81_11);
        join_wrapped_into(&mut v80_10_write,&((v81_12).read_zipper()),&[]);
        }
        v68_27_cursor.ascend(1);
      }
      drop(v80_10_write);
      compose(&(v69_9),&(v80_10))
    };
    drop(v69_9);
    let v69_12: Space = unite(&(v69_7),&(v69_11));
    join_wrapped_into(&mut v68_27_write,&((v69_12).read_zipper()),&[]);
    }
    v68_27_cursor.ascend(1);
  }
  drop(v68_27_cursor);
  drop(v68_27_write);
  drop(v68_8);
  let v68_28: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v68_27));
  let mut v68_47 = Space::new();
  let mut v68_47_write = v68_47.write_zipper();
  let mut v68_47_cursor = (v68_28).read_zipper();
  let v68_47_origin = v68_47_cursor.path().len();
  for v68_47_byte in v68_47_cursor.child_mask().iter() {
    v68_47_cursor.descend_to_existing_byte(v68_47_byte);
    {
    let v86_2: Space = singleton(&v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 1)]);
    let v86_3: Space = intersect(&(*CONSTANT_1),&(v86_2));
    let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
    drop(v86_3);
    let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
    drop(v86_4);
    let v86_7: Space = if (&(v86_5)).is_empty() { Space::new() } else {
      let mut v87_6 = Space::new();
      let mut v87_6_write = v87_6.write_zipper();
      for v87_6_byte in v68_47_cursor.child_mask().iter() {
        v68_47_cursor.descend_to_existing_byte(v87_6_byte);
        {
        let v88_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 1)..(v68_47_origin + 2)]);
        let v88_3: Space = intersect(&(*CONSTANT_1),&(v88_2));
        let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
        drop(v88_3);
        let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
        drop(v88_4);
        let v88_8: Space = if (&(v88_5)).is_empty() { Space::new() } else {
          let mut v89_7 = Space::new();
          let mut v89_7_write = v89_7.write_zipper();
          for v89_7_byte in v68_47_cursor.child_mask().iter() {
            v68_47_cursor.descend_to_existing_byte(v89_7_byte);
            {
            let v90_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 2)..(v68_47_origin + 3)]);
            let v90_3: Space = intersect(&(*CONSTANT_1),&(v90_2));
            let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
            drop(v90_3);
            let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
            drop(v90_4);
            let v90_8: Space = if (&(v90_5)).is_empty() { Space::new() } else {
              let v91_7: Space = routine_18(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v90_5),&(v91_7))
            };
            drop(v90_5);
            let v90_9: Space = intersect(&(*CONSTANT_1),&(v90_2));
            drop(v90_2);
            let v90_10: Space = if has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
            drop(v90_9);
            let v90_12: Space = if (&(v90_10)).is_empty() { Space::new() } else {
              let v92_11: Space = routine_19(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v90_10),&(v92_11))
            };
            drop(v90_10);
            let v90_13: Space = unite(&(v90_8),&(v90_12));
            join_wrapped_into(&mut v89_7_write,&((v90_13).read_zipper()),&[]);
            }
            v68_47_cursor.ascend(1);
          }
          drop(v89_7_write);
          compose(&(v88_5),&(v89_7))
        };
        drop(v88_5);
        let v88_9: Space = intersect(&(*CONSTANT_1),&(v88_2));
        drop(v88_2);
        let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
        drop(v88_9);
        let v88_12: Space = if (&(v88_10)).is_empty() { Space::new() } else {
          let mut v93_11 = Space::new();
          let mut v93_11_write = v93_11.write_zipper();
          for v93_11_byte in v68_47_cursor.child_mask().iter() {
            v68_47_cursor.descend_to_existing_byte(v93_11_byte);
            {
            let v94_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 2)..(v68_47_origin + 3)]);
            let v94_3: Space = intersect(&(*CONSTANT_1),&(v94_2));
            let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
            drop(v94_3);
            let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
            drop(v94_4);
            let v94_8: Space = if (&(v94_5)).is_empty() { Space::new() } else {
              let v95_7: Space = routine_18(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v94_5),&(v95_7))
            };
            drop(v94_5);
            let v94_9: Space = intersect(&(*CONSTANT_1),&(v94_2));
            drop(v94_2);
            let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
            drop(v94_9);
            let v94_12: Space = if (&(v94_10)).is_empty() { Space::new() } else {
              let v96_11: Space = routine_15(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v94_10),&(v96_11))
            };
            drop(v94_10);
            let v94_13: Space = unite(&(v94_8),&(v94_12));
            join_wrapped_into(&mut v93_11_write,&((v94_13).read_zipper()),&[]);
            }
            v68_47_cursor.ascend(1);
          }
          drop(v93_11_write);
          compose(&(v88_10),&(v93_11))
        };
        drop(v88_10);
        let v88_13: Space = unite(&(v88_8),&(v88_12));
        join_wrapped_into(&mut v87_6_write,&((v88_13).read_zipper()),&[]);
        }
        v68_47_cursor.ascend(1);
      }
      drop(v87_6_write);
      compose(&(v86_5),&(v87_6))
    };
    drop(v86_5);
    let v86_8: Space = intersect(&(*CONSTANT_1),&(v86_2));
    drop(v86_2);
    let v86_9: Space = if has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
    drop(v86_8);
    let v86_11: Space = if (&(v86_9)).is_empty() { Space::new() } else {
      let mut v97_10 = Space::new();
      let mut v97_10_write = v97_10.write_zipper();
      for v97_10_byte in v68_47_cursor.child_mask().iter() {
        v68_47_cursor.descend_to_existing_byte(v97_10_byte);
        {
        let v98_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 1)..(v68_47_origin + 2)]);
        let v98_3: Space = intersect(&(*CONSTANT_1),&(v98_2));
        let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
        drop(v98_3);
        let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
        drop(v98_4);
        let v98_8: Space = if (&(v98_5)).is_empty() { Space::new() } else {
          let mut v99_7 = Space::new();
          let mut v99_7_write = v99_7.write_zipper();
          for v99_7_byte in v68_47_cursor.child_mask().iter() {
            v68_47_cursor.descend_to_existing_byte(v99_7_byte);
            {
            let v100_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 2)..(v68_47_origin + 3)]);
            let v100_3: Space = intersect(&(*CONSTANT_1),&(v100_2));
            let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
            drop(v100_3);
            let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
            drop(v100_4);
            let v100_8: Space = if (&(v100_5)).is_empty() { Space::new() } else {
              let v101_7: Space = routine_18(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v100_5),&(v101_7))
            };
            drop(v100_5);
            let v100_9: Space = intersect(&(*CONSTANT_1),&(v100_2));
            drop(v100_2);
            let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
            drop(v100_9);
            let v100_12: Space = if (&(v100_10)).is_empty() { Space::new() } else {
              let v102_11: Space = routine_19(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v100_10),&(v102_11))
            };
            drop(v100_10);
            let v100_13: Space = unite(&(v100_8),&(v100_12));
            join_wrapped_into(&mut v99_7_write,&((v100_13).read_zipper()),&[]);
            }
            v68_47_cursor.ascend(1);
          }
          drop(v99_7_write);
          compose(&(v98_5),&(v99_7))
        };
        drop(v98_5);
        let v98_9: Space = intersect(&(*CONSTANT_1),&(v98_2));
        drop(v98_2);
        let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
        drop(v98_9);
        let v98_11: Space = compose(&(v98_10),&v68_47_cursor);
        drop(v98_10);
        let v98_12: Space = unite(&(v98_8),&(v98_11));
        drop(v98_11);
        join_wrapped_into(&mut v97_10_write,&((v98_12).read_zipper()),&[]);
        }
        v68_47_cursor.ascend(1);
      }
      drop(v97_10_write);
      compose(&(v86_9),&(v97_10))
    };
    drop(v86_9);
    let v86_12: Space = unite(&(v86_7),&(v86_11));
    join_wrapped_into(&mut v68_47_write,&((v86_12).read_zipper()),&[]);
    }
    v68_47_cursor.ascend(1);
  }
  drop(v68_47_cursor);
  drop(v68_47_write);
  let v68_48: Space = subtract(&(v68_47),&(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0))));
  let v68_51: Space = intersect(&(v68_48),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
  let v68_52: Space = wrap(&(v68_51),&(*p0));
  (v68_52).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v103_34 = Space::new();
  let mut v103_34_write = v103_34.write_zipper();
  let mut v103_34_cursor = (*s0).read_zipper();
  let v103_34_origin = v103_34_cursor.path().len();
  for v103_34_byte in v103_34_cursor.child_mask().iter() {
    v103_34_cursor.descend_to_existing_byte(v103_34_byte);
    {
    let v104_2: Space = singleton(&v103_34_cursor.path()[v103_34_origin..(v103_34_origin + 1)]);
    let v104_3: Space = intersect(&(*CONSTANT_1),&(v104_2));
    let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
    drop(v104_3);
    let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
    drop(v104_4);
    let v104_8: Space = if (&(v104_5)).is_empty() { Space::new() } else {
      let v105_6: Path = concat_path(&(*p0),&v103_34_cursor.path()[v103_34_origin..(v103_34_origin + 1)]);
      let mut v105_7 = Space::new();
      let mut v105_7_write = v105_7.write_zipper();
      for v105_7_byte in v103_34_cursor.child_mask().iter() {
        v103_34_cursor.descend_to_existing_byte(v105_7_byte);
        {
        let v106_2: Space = singleton(&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)]);
        let v106_3: Space = intersect(&(*CONSTANT_1),&(v106_2));
        let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
        drop(v106_3);
        let v106_5: Space = subtract(&(*CONSTANT_0),&(v106_4));
        drop(v106_4);
        let v106_8: Space = if (&(v106_5)).is_empty() { Space::new() } else {
          let v107_6: Path = concat_path(&(v105_6),&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)]);
          let mut v107_7 = Space::new();
          let mut v107_7_write = v107_7.write_zipper();
          for v107_7_byte in v103_34_cursor.child_mask().iter() {
            v103_34_cursor.descend_to_existing_byte(v107_7_byte);
            {
            let v108_2: Space = singleton(&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
            let v108_3: Space = intersect(&(*CONSTANT_1),&(v108_2));
            let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
            drop(v108_3);
            let v108_5: Space = subtract(&(*CONSTANT_0),&(v108_4));
            drop(v108_4);
            let v108_8: Space = if (&(v108_5)).is_empty() { Space::new() } else {
              let v109_6: Path = concat_path(&(v107_6),&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
              let v109_7: Space = routine_20(c, &(v109_6), &v103_34_cursor, &(*s1));
              compose(&(v108_5),&(v109_7))
            };
            drop(v108_5);
            let v108_9: Space = intersect(&(*CONSTANT_1),&(v108_2));
            drop(v108_2);
            let v108_10: Space = if has_head(&(v108_9)) { singleton(&[]) } else { Space::new() };
            drop(v108_9);
            let v108_12: Space = if (&(v108_10)).is_empty() { Space::new() } else {
              let v110_6: Path = concat_path(&(v107_6),&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
              let v110_11: Space = routine_21(c, &(v110_6), &v103_34_cursor, &(*s1));
              drop(v110_6);
              compose(&(v108_10),&(v110_11))
            };
            drop(v108_10);
            let v108_13: Space = unite(&(v108_8),&(v108_12));
            join_wrapped_into(&mut v107_7_write,&((v108_13).read_zipper()),&[]);
            }
            v103_34_cursor.ascend(1);
          }
          drop(v107_7_write);
          compose(&(v106_5),&(v107_7))
        };
        drop(v106_5);
        let v106_9: Space = intersect(&(*CONSTANT_1),&(v106_2));
        drop(v106_2);
        let v106_10: Space = if has_head(&(v106_9)) { singleton(&[]) } else { Space::new() };
        drop(v106_9);
        let v106_12: Space = if (&(v106_10)).is_empty() { Space::new() } else {
          let v111_6: Path = concat_path(&(v105_6),&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)]);
          let mut v111_11 = Space::new();
          let mut v111_11_write = v111_11.write_zipper();
          for v111_11_byte in v103_34_cursor.child_mask().iter() {
            v103_34_cursor.descend_to_existing_byte(v111_11_byte);
            {
            let v112_2: Space = singleton(&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
            let v112_3: Space = intersect(&(*CONSTANT_1),&(v112_2));
            let v112_4: Space = if has_head(&(v112_3)) { singleton(&[]) } else { Space::new() };
            drop(v112_3);
            let v112_5: Space = subtract(&(*CONSTANT_0),&(v112_4));
            drop(v112_4);
            let v112_8: Space = if (&(v112_5)).is_empty() { Space::new() } else {
              let v113_6: Path = concat_path(&(v111_6),&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
              let v113_7: Space = routine_20(c, &(v113_6), &v103_34_cursor, &(*s1));
              compose(&(v112_5),&(v113_7))
            };
            drop(v112_5);
            let v112_9: Space = intersect(&(*CONSTANT_1),&(v112_2));
            drop(v112_2);
            let v112_10: Space = if has_head(&(v112_9)) { singleton(&[]) } else { Space::new() };
            drop(v112_9);
            let v112_12: Space = if (&(v112_10)).is_empty() { Space::new() } else {
              let v114_6: Path = concat_path(&(v111_6),&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
              let v114_11: Space = routine_3(c, &(v114_6), &v103_34_cursor, &(*s1));
              drop(v114_6);
              compose(&(v112_10),&(v114_11))
            };
            drop(v112_10);
            let v112_13: Space = unite(&(v112_8),&(v112_12));
            join_wrapped_into(&mut v111_11_write,&((v112_13).read_zipper()),&[]);
            }
            v103_34_cursor.ascend(1);
          }
          drop(v111_11_write);
          drop(v111_6);
          compose(&(v106_10),&(v111_11))
        };
        drop(v106_10);
        let v106_13: Space = unite(&(v106_8),&(v106_12));
        join_wrapped_into(&mut v105_7_write,&((v106_13).read_zipper()),&[]);
        }
        v103_34_cursor.ascend(1);
      }
      drop(v105_7_write);
      compose(&(v104_5),&(v105_7))
    };
    drop(v104_5);
    let v104_9: Space = intersect(&(*CONSTANT_1),&(v104_2));
    drop(v104_2);
    let v104_10: Space = if has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
    drop(v104_9);
    let v104_13: Space = if (&(v104_10)).is_empty() { Space::new() } else {
      let v115_6: Path = concat_path(&(*p0),&v103_34_cursor.path()[v103_34_origin..(v103_34_origin + 1)]);
      let mut v115_12 = Space::new();
      let mut v115_12_write = v115_12.write_zipper();
      for v115_12_byte in v103_34_cursor.child_mask().iter() {
        v103_34_cursor.descend_to_existing_byte(v115_12_byte);
        {
        let v116_2: Space = singleton(&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)]);
        let v116_3: Space = intersect(&(*CONSTANT_1),&(v116_2));
        let v116_4: Space = if has_head(&(v116_3)) { singleton(&[]) } else { Space::new() };
        drop(v116_3);
        let v116_5: Space = subtract(&(*CONSTANT_0),&(v116_4));
        drop(v116_4);
        let v116_8: Space = if (&(v116_5)).is_empty() { Space::new() } else {
          let v117_6: Path = concat_path(&(v115_6),&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)]);
          let mut v117_7 = Space::new();
          let mut v117_7_write = v117_7.write_zipper();
          for v117_7_byte in v103_34_cursor.child_mask().iter() {
            v103_34_cursor.descend_to_existing_byte(v117_7_byte);
            {
            let v118_2: Space = singleton(&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
            let v118_3: Space = intersect(&(*CONSTANT_1),&(v118_2));
            let v118_4: Space = if has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
            drop(v118_3);
            let v118_5: Space = subtract(&(*CONSTANT_0),&(v118_4));
            drop(v118_4);
            let v118_8: Space = if (&(v118_5)).is_empty() { Space::new() } else {
              let v119_6: Path = concat_path(&(v117_6),&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
              let v119_7: Space = routine_20(c, &(v119_6), &v103_34_cursor, &(*s1));
              compose(&(v118_5),&(v119_7))
            };
            drop(v118_5);
            let v118_9: Space = intersect(&(*CONSTANT_1),&(v118_2));
            drop(v118_2);
            let v118_10: Space = if has_head(&(v118_9)) { singleton(&[]) } else { Space::new() };
            drop(v118_9);
            let v118_12: Space = if (&(v118_10)).is_empty() { Space::new() } else {
              let v120_6: Path = concat_path(&(v117_6),&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
              let v120_11: Space = routine_21(c, &(v120_6), &v103_34_cursor, &(*s1));
              drop(v120_6);
              compose(&(v118_10),&(v120_11))
            };
            drop(v118_10);
            let v118_13: Space = unite(&(v118_8),&(v118_12));
            join_wrapped_into(&mut v117_7_write,&((v118_13).read_zipper()),&[]);
            }
            v103_34_cursor.ascend(1);
          }
          drop(v117_7_write);
          compose(&(v116_5),&(v117_7))
        };
        drop(v116_5);
        let v116_9: Space = intersect(&(*CONSTANT_1),&(v116_2));
        drop(v116_2);
        let v116_10: Space = if has_head(&(v116_9)) { singleton(&[]) } else { Space::new() };
        drop(v116_9);
        let v116_18: Space = if (&(v116_10)).is_empty() { Space::new() } else {
          let v121_12: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v103_34_cursor.path()[v103_34_origin..(v103_34_origin + 1)]),&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)])));
          let mut v121_13 = Space::new();
          let mut v121_13_write = v121_13.write_zipper();
          let mut v121_13_cursor = (v121_12).read_zipper();
          let v121_13_origin = v121_13_cursor.path().len();
          for v121_13_byte in v121_13_cursor.child_mask().iter() {
            v121_13_cursor.descend_to_existing_byte(v121_13_byte);
            {
            let v122_2: Space = singleton(&v121_13_cursor.path()[v121_13_origin..(v121_13_origin + 1)]);
            let v122_3: Space = intersect(&(*CONSTANT_1),&(v122_2));
            let v122_4: Space = if has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
            drop(v122_3);
            let v122_5: Space = subtract(&(*CONSTANT_0),&(v122_4));
            drop(v122_4);
            let v122_7: Space = if (&(v122_5)).is_empty() { Space::new() } else {
              let v123_6: Space = routine_6(c, &v121_13_cursor.path()[v121_13_origin..(v121_13_origin + 1)], &v121_13_cursor);
              compose(&(v122_5),&(v123_6))
            };
            drop(v122_5);
            let v122_8: Space = intersect(&(*CONSTANT_1),&(v122_2));
            drop(v122_2);
            let v122_9: Space = if has_head(&(v122_8)) { singleton(&[]) } else { Space::new() };
            drop(v122_8);
            let v122_11: Space = if (&(v122_9)).is_empty() { Space::new() } else {
              let v124_10: Space = routine_7(c, &v121_13_cursor.path()[v121_13_origin..(v121_13_origin + 1)], &v121_13_cursor);
              compose(&(v122_9),&(v124_10))
            };
            drop(v122_9);
            let v122_12: Space = unite(&(v122_7),&(v122_11));
            join_wrapped_into(&mut v121_13_write,&((v122_12).read_zipper()),&[]);
            }
            v121_13_cursor.ascend(1);
          }
          drop(v121_13_cursor);
          drop(v121_13_write);
          drop(v121_12);
          let v121_14: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v121_13));
          let mut v121_15 = Space::new();
          let mut v121_15_write = v121_15.write_zipper();
          let mut v121_15_cursor = (v121_14).read_zipper();
          let v121_15_origin = v121_15_cursor.path().len();
          for v121_15_byte in v121_15_cursor.child_mask().iter() {
            v121_15_cursor.descend_to_existing_byte(v121_15_byte);
            {
            let v125_2: Space = singleton(&v121_15_cursor.path()[v121_15_origin..(v121_15_origin + 1)]);
            let v125_3: Space = intersect(&(*CONSTANT_1),&(v125_2));
            let v125_4: Space = if has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
            drop(v125_3);
            let v125_5: Space = subtract(&(*CONSTANT_0),&(v125_4));
            drop(v125_4);
            let v125_7: Space = if (&(v125_5)).is_empty() { Space::new() } else {
              let v126_6: Space = routine_8(c, &v121_15_cursor.path()[v121_15_origin..(v121_15_origin + 1)], &v121_15_cursor);
              compose(&(v125_5),&(v126_6))
            };
            drop(v125_5);
            let v125_8: Space = intersect(&(*CONSTANT_1),&(v125_2));
            drop(v125_2);
            let v125_9: Space = if has_head(&(v125_8)) { singleton(&[]) } else { Space::new() };
            drop(v125_8);
            let v125_11: Space = if (&(v125_9)).is_empty() { Space::new() } else {
              let v127_10: Space = routine_9(c, &v121_15_cursor.path()[v121_15_origin..(v121_15_origin + 1)], &v121_15_cursor);
              compose(&(v125_9),&(v127_10))
            };
            drop(v125_9);
            let v125_12: Space = unite(&(v125_7),&(v125_11));
            join_wrapped_into(&mut v121_15_write,&((v125_12).read_zipper()),&[]);
            }
            v121_15_cursor.ascend(1);
          }
          drop(v121_15_cursor);
          drop(v121_15_write);
          let v121_16: Space = subtract(&(v121_15),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v103_34_cursor.path()[v103_34_origin..(v103_34_origin + 1)]),&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)])));
          let v121_17: Space = intersect(&(v121_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
          compose(&(v116_10),&(v121_17))
        };
        drop(v116_10);
        let v128_6: Path = concat_path(&(v115_6),&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)]);
        let v116_19: Space = wrap(&(v116_18),&(v128_6));
        let v116_20: Space = unite(&(v116_8),&(v116_19));
        join_wrapped_into(&mut v115_12_write,&((v116_20).read_zipper()),&[]);
        }
        v103_34_cursor.ascend(1);
      }
      drop(v115_12_write);
      drop(v115_6);
      compose(&(v104_10),&(v115_12))
    };
    drop(v104_10);
    let v104_14: Space = unite(&(v104_8),&(v104_13));
    join_wrapped_into(&mut v103_34_write,&((v104_14).read_zipper()),&[]);
    }
    v103_34_cursor.ascend(1);
  }
  drop(v103_34_cursor);
  drop(v103_34_write);
  (v103_34).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v129_40 = Space::new();
  let mut v129_40_write = v129_40.write_zipper();
  let mut v129_40_cursor = (*s0).read_zipper();
  let v129_40_origin = v129_40_cursor.path().len();
  for v129_40_byte in v129_40_cursor.child_mask().iter() {
    v129_40_cursor.descend_to_existing_byte(v129_40_byte);
    {
    let v130_2: Space = singleton(&v129_40_cursor.path()[v129_40_origin..(v129_40_origin + 1)]);
    let v130_3: Space = intersect(&(*CONSTANT_1),&(v130_2));
    let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
    drop(v130_3);
    let v130_5: Space = subtract(&(*CONSTANT_0),&(v130_4));
    drop(v130_4);
    let v130_8: Space = if (&(v130_5)).is_empty() { Space::new() } else {
      let v131_6: Path = concat_path(&(*p0),&v129_40_cursor.path()[v129_40_origin..(v129_40_origin + 1)]);
      let mut v131_7 = Space::new();
      let mut v131_7_write = v131_7.write_zipper();
      for v131_7_byte in v129_40_cursor.child_mask().iter() {
        v129_40_cursor.descend_to_existing_byte(v131_7_byte);
        {
        let v132_2: Space = singleton(&v129_40_cursor.path()[(v129_40_origin + 1)..(v129_40_origin + 2)]);
        let v132_3: Space = intersect(&(*CONSTANT_1),&(v132_2));
        let v132_4: Space = if has_head(&(v132_3)) { singleton(&[]) } else { Space::new() };
        drop(v132_3);
        let v132_5: Space = subtract(&(*CONSTANT_0),&(v132_4));
        drop(v132_4);
        let v132_8: Space = if (&(v132_5)).is_empty() { Space::new() } else {
          let v133_6: Path = concat_path(&(v131_6),&v129_40_cursor.path()[(v129_40_origin + 1)..(v129_40_origin + 2)]);
          let mut v133_7 = Space::new();
          let mut v133_7_write = v133_7.write_zipper();
          for v133_7_byte in v129_40_cursor.child_mask().iter() {
            v129_40_cursor.descend_to_existing_byte(v133_7_byte);
            {
            let v134_2: Space = singleton(&v129_40_cursor.path()[(v129_40_origin + 2)..(v129_40_origin + 3)]);
            let v134_3: Space = intersect(&(*CONSTANT_1),&(v134_2));
            let v134_4: Space = if has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
            drop(v134_3);
            let v134_5: Space = subtract(&(*CONSTANT_0),&(v134_4));
            drop(v134_4);
            let v134_8: Space = if (&(v134_5)).is_empty() { Space::new() } else {
              let v135_6: Path = concat_path(&(v133_6),&v129_40_cursor.path()[(v129_40_origin + 2)..(v129_40_origin + 3)]);
              let v135_7: Space = routine_20(c, &(v135_6), &v129_40_cursor, &(*s1));
              compose(&(v134_5),&(v135_7))
            };
            drop(v134_5);
            let v134_9: Space = intersect(&(*CONSTANT_1),&(v134_2));
            drop(v134_2);
            let v134_10: Space = if has_head(&(v134_9)) { singleton(&[]) } else { Space::new() };
            drop(v134_9);
            let v134_12: Space = if (&(v134_10)).is_empty() { Space::new() } else {
              let v136_6: Path = concat_path(&(v133_6),&v129_40_cursor.path()[(v129_40_origin + 2)..(v129_40_origin + 3)]);
              let v136_11: Space = routine_21(c, &(v136_6), &v129_40_cursor, &(*s1));
              drop(v136_6);
              compose(&(v134_10),&(v136_11))
            };
            drop(v134_10);
            let v134_13: Space = unite(&(v134_8),&(v134_12));
            join_wrapped_into(&mut v133_7_write,&((v134_13).read_zipper()),&[]);
            }
            v129_40_cursor.ascend(1);
          }
          drop(v133_7_write);
          compose(&(v132_5),&(v133_7))
        };
        drop(v132_5);
        let v132_9: Space = intersect(&(*CONSTANT_1),&(v132_2));
        drop(v132_2);
        let v132_10: Space = if has_head(&(v132_9)) { singleton(&[]) } else { Space::new() };
        drop(v132_9);
        let v132_12: Space = if (&(v132_10)).is_empty() { Space::new() } else {
          let v137_6: Path = concat_path(&(v131_6),&v129_40_cursor.path()[(v129_40_origin + 1)..(v129_40_origin + 2)]);
          let mut v137_11 = Space::new();
          let mut v137_11_write = v137_11.write_zipper();
          for v137_11_byte in v129_40_cursor.child_mask().iter() {
            v129_40_cursor.descend_to_existing_byte(v137_11_byte);
            {
            let v138_2: Space = singleton(&v129_40_cursor.path()[(v129_40_origin + 2)..(v129_40_origin + 3)]);
            let v138_3: Space = intersect(&(*CONSTANT_1),&(v138_2));
            let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
            drop(v138_3);
            let v138_5: Space = subtract(&(*CONSTANT_0),&(v138_4));
            drop(v138_4);
            let v138_8: Space = if (&(v138_5)).is_empty() { Space::new() } else {
              let v139_6: Path = concat_path(&(v137_6),&v129_40_cursor.path()[(v129_40_origin + 2)..(v129_40_origin + 3)]);
              let v139_7: Space = routine_20(c, &(v139_6), &v129_40_cursor, &(*s1));
              compose(&(v138_5),&(v139_7))
            };
            drop(v138_5);
            let v138_9: Space = intersect(&(*CONSTANT_1),&(v138_2));
            drop(v138_2);
            let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
            drop(v138_9);
            let v138_12: Space = if (&(v138_10)).is_empty() { Space::new() } else {
              let v140_6: Path = concat_path(&(v137_6),&v129_40_cursor.path()[(v129_40_origin + 2)..(v129_40_origin + 3)]);
              let v140_11: Space = routine_3(c, &(v140_6), &v129_40_cursor, &(*s1));
              drop(v140_6);
              compose(&(v138_10),&(v140_11))
            };
            drop(v138_10);
            let v138_13: Space = unite(&(v138_8),&(v138_12));
            join_wrapped_into(&mut v137_11_write,&((v138_13).read_zipper()),&[]);
            }
            v129_40_cursor.ascend(1);
          }
          drop(v137_11_write);
          drop(v137_6);
          compose(&(v132_10),&(v137_11))
        };
        drop(v132_10);
        let v132_13: Space = unite(&(v132_8),&(v132_12));
        join_wrapped_into(&mut v131_7_write,&((v132_13).read_zipper()),&[]);
        }
        v129_40_cursor.ascend(1);
      }
      drop(v131_7_write);
      compose(&(v130_5),&(v131_7))
    };
    drop(v130_5);
    let v130_9: Space = intersect(&(*CONSTANT_1),&(v130_2));
    drop(v130_2);
    let v130_10: Space = if has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
    drop(v130_9);
    let v130_18: Space = if (&(v130_10)).is_empty() { Space::new() } else {
      let v141_12: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v129_40_cursor.path()[v129_40_origin..(v129_40_origin + 1)])));
      let mut v141_13 = Space::new();
      let mut v141_13_write = v141_13.write_zipper();
      let mut v141_13_cursor = (v141_12).read_zipper();
      let v141_13_origin = v141_13_cursor.path().len();
      for v141_13_byte in v141_13_cursor.child_mask().iter() {
        v141_13_cursor.descend_to_existing_byte(v141_13_byte);
        {
        let v142_2: Space = singleton(&v141_13_cursor.path()[v141_13_origin..(v141_13_origin + 1)]);
        let v142_3: Space = intersect(&(*CONSTANT_1),&(v142_2));
        let v142_4: Space = if has_head(&(v142_3)) { singleton(&[]) } else { Space::new() };
        drop(v142_3);
        let v142_5: Space = subtract(&(*CONSTANT_0),&(v142_4));
        drop(v142_4);
        let v142_7: Space = if (&(v142_5)).is_empty() { Space::new() } else {
          let mut v143_6 = Space::new();
          let mut v143_6_write = v143_6.write_zipper();
          for v143_6_byte in v141_13_cursor.child_mask().iter() {
            v141_13_cursor.descend_to_existing_byte(v143_6_byte);
            {
            let v144_2: Space = singleton(&v141_13_cursor.path()[(v141_13_origin + 1)..(v141_13_origin + 2)]);
            let v144_3: Space = intersect(&(*CONSTANT_1),&(v144_2));
            let v144_4: Space = if has_head(&(v144_3)) { singleton(&[]) } else { Space::new() };
            drop(v144_3);
            let v144_5: Space = subtract(&(*CONSTANT_0),&(v144_4));
            drop(v144_4);
            let v144_8: Space = if (&(v144_5)).is_empty() { Space::new() } else {
              let v145_7: Space = routine_10(c, &v141_13_cursor.path()[v141_13_origin..(v141_13_origin + 2)], &v141_13_cursor);
              compose(&(v144_5),&(v145_7))
            };
            drop(v144_5);
            let v144_9: Space = intersect(&(*CONSTANT_1),&(v144_2));
            drop(v144_2);
            let v144_10: Space = if has_head(&(v144_9)) { singleton(&[]) } else { Space::new() };
            drop(v144_9);
            let v144_12: Space = if (&(v144_10)).is_empty() { Space::new() } else {
              let v146_11: Space = routine_11(c, &v141_13_cursor.path()[v141_13_origin..(v141_13_origin + 2)], &v141_13_cursor);
              compose(&(v144_10),&(v146_11))
            };
            drop(v144_10);
            let v144_13: Space = unite(&(v144_8),&(v144_12));
            join_wrapped_into(&mut v143_6_write,&((v144_13).read_zipper()),&[]);
            }
            v141_13_cursor.ascend(1);
          }
          drop(v143_6_write);
          compose(&(v142_5),&(v143_6))
        };
        drop(v142_5);
        let v142_8: Space = intersect(&(*CONSTANT_1),&(v142_2));
        drop(v142_2);
        let v142_9: Space = if has_head(&(v142_8)) { singleton(&[]) } else { Space::new() };
        drop(v142_8);
        let v142_11: Space = if (&(v142_9)).is_empty() { Space::new() } else {
          let mut v147_10 = Space::new();
          let mut v147_10_write = v147_10.write_zipper();
          for v147_10_byte in v141_13_cursor.child_mask().iter() {
            v141_13_cursor.descend_to_existing_byte(v147_10_byte);
            {
            let v148_2: Space = singleton(&v141_13_cursor.path()[(v141_13_origin + 1)..(v141_13_origin + 2)]);
            let v148_3: Space = intersect(&(*CONSTANT_1),&(v148_2));
            let v148_4: Space = if has_head(&(v148_3)) { singleton(&[]) } else { Space::new() };
            drop(v148_3);
            let v148_5: Space = subtract(&(*CONSTANT_0),&(v148_4));
            drop(v148_4);
            let v148_8: Space = if (&(v148_5)).is_empty() { Space::new() } else {
              let v149_7: Space = routine_10(c, &v141_13_cursor.path()[v141_13_origin..(v141_13_origin + 2)], &v141_13_cursor);
              compose(&(v148_5),&(v149_7))
            };
            drop(v148_5);
            let v148_9: Space = intersect(&(*CONSTANT_1),&(v148_2));
            drop(v148_2);
            let v148_10: Space = if has_head(&(v148_9)) { singleton(&[]) } else { Space::new() };
            drop(v148_9);
            let v148_12: Space = if (&(v148_10)).is_empty() { Space::new() } else {
              let v150_11: Space = routine_12(c, &v141_13_cursor.path()[v141_13_origin..(v141_13_origin + 2)], &v141_13_cursor);
              compose(&(v148_10),&(v150_11))
            };
            drop(v148_10);
            let v148_13: Space = unite(&(v148_8),&(v148_12));
            join_wrapped_into(&mut v147_10_write,&((v148_13).read_zipper()),&[]);
            }
            v141_13_cursor.ascend(1);
          }
          drop(v147_10_write);
          compose(&(v142_9),&(v147_10))
        };
        drop(v142_9);
        let v142_12: Space = unite(&(v142_7),&(v142_11));
        join_wrapped_into(&mut v141_13_write,&((v142_12).read_zipper()),&[]);
        }
        v141_13_cursor.ascend(1);
      }
      drop(v141_13_cursor);
      drop(v141_13_write);
      drop(v141_12);
      let v141_14: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v141_13));
      let mut v141_15 = Space::new();
      let mut v141_15_write = v141_15.write_zipper();
      let mut v141_15_cursor = (v141_14).read_zipper();
      let v141_15_origin = v141_15_cursor.path().len();
      for v141_15_byte in v141_15_cursor.child_mask().iter() {
        v141_15_cursor.descend_to_existing_byte(v141_15_byte);
        {
        let v151_2: Space = singleton(&v141_15_cursor.path()[v141_15_origin..(v141_15_origin + 1)]);
        let v151_3: Space = intersect(&(*CONSTANT_1),&(v151_2));
        let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
        drop(v151_3);
        let v151_5: Space = subtract(&(*CONSTANT_0),&(v151_4));
        drop(v151_4);
        let v151_7: Space = if (&(v151_5)).is_empty() { Space::new() } else {
          let mut v152_6 = Space::new();
          let mut v152_6_write = v152_6.write_zipper();
          for v152_6_byte in v141_15_cursor.child_mask().iter() {
            v141_15_cursor.descend_to_existing_byte(v152_6_byte);
            {
            let v153_2: Space = singleton(&v141_15_cursor.path()[(v141_15_origin + 1)..(v141_15_origin + 2)]);
            let v153_3: Space = intersect(&(*CONSTANT_1),&(v153_2));
            let v153_4: Space = if has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
            drop(v153_3);
            let v153_5: Space = subtract(&(*CONSTANT_0),&(v153_4));
            drop(v153_4);
            let v153_8: Space = if (&(v153_5)).is_empty() { Space::new() } else {
              let v154_7: Space = routine_13(c, &v141_15_cursor.path()[v141_15_origin..(v141_15_origin + 2)], &v141_15_cursor);
              compose(&(v153_5),&(v154_7))
            };
            drop(v153_5);
            let v153_9: Space = intersect(&(*CONSTANT_1),&(v153_2));
            drop(v153_2);
            let v153_10: Space = if has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
            drop(v153_9);
            let v153_12: Space = if (&(v153_10)).is_empty() { Space::new() } else {
              let v155_11: Space = routine_14(c, &v141_15_cursor.path()[v141_15_origin..(v141_15_origin + 2)], &v141_15_cursor);
              compose(&(v153_10),&(v155_11))
            };
            drop(v153_10);
            let v153_13: Space = unite(&(v153_8),&(v153_12));
            join_wrapped_into(&mut v152_6_write,&((v153_13).read_zipper()),&[]);
            }
            v141_15_cursor.ascend(1);
          }
          drop(v152_6_write);
          compose(&(v151_5),&(v152_6))
        };
        drop(v151_5);
        let v151_8: Space = intersect(&(*CONSTANT_1),&(v151_2));
        drop(v151_2);
        let v151_9: Space = if has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
        drop(v151_8);
        let v151_11: Space = if (&(v151_9)).is_empty() { Space::new() } else {
          let mut v156_10 = Space::new();
          let mut v156_10_write = v156_10.write_zipper();
          for v156_10_byte in v141_15_cursor.child_mask().iter() {
            v141_15_cursor.descend_to_existing_byte(v156_10_byte);
            {
            let v157_2: Space = singleton(&v141_15_cursor.path()[(v141_15_origin + 1)..(v141_15_origin + 2)]);
            let v157_3: Space = intersect(&(*CONSTANT_1),&(v157_2));
            let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
            drop(v157_3);
            let v157_5: Space = subtract(&(*CONSTANT_0),&(v157_4));
            drop(v157_4);
            let v157_8: Space = if (&(v157_5)).is_empty() { Space::new() } else {
              let v158_7: Space = routine_13(c, &v141_15_cursor.path()[v141_15_origin..(v141_15_origin + 2)], &v141_15_cursor);
              compose(&(v157_5),&(v158_7))
            };
            drop(v157_5);
            let v157_9: Space = intersect(&(*CONSTANT_1),&(v157_2));
            drop(v157_2);
            let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
            drop(v157_9);
            let v157_12: Space = if (&(v157_10)).is_empty() { Space::new() } else {
              let v159_11: Space = routine_15(c, &v141_15_cursor.path()[v141_15_origin..(v141_15_origin + 2)], &v141_15_cursor);
              compose(&(v157_10),&(v159_11))
            };
            drop(v157_10);
            let v157_13: Space = unite(&(v157_8),&(v157_12));
            join_wrapped_into(&mut v156_10_write,&((v157_13).read_zipper()),&[]);
            }
            v141_15_cursor.ascend(1);
          }
          drop(v156_10_write);
          compose(&(v151_9),&(v156_10))
        };
        drop(v151_9);
        let v151_12: Space = unite(&(v151_7),&(v151_11));
        join_wrapped_into(&mut v141_15_write,&((v151_12).read_zipper()),&[]);
        }
        v141_15_cursor.ascend(1);
      }
      drop(v141_15_cursor);
      drop(v141_15_write);
      let v141_16: Space = subtract(&(v141_15),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v129_40_cursor.path()[v129_40_origin..(v129_40_origin + 1)])));
      let v141_17: Space = intersect(&(v141_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
      compose(&(v130_10),&(v141_17))
    };
    drop(v130_10);
    let v160_6: Path = concat_path(&(*p0),&v129_40_cursor.path()[v129_40_origin..(v129_40_origin + 1)]);
    let v130_19: Space = wrap(&(v130_18),&(v160_6));
    let v130_20: Space = unite(&(v130_8),&(v130_19));
    join_wrapped_into(&mut v129_40_write,&((v130_20).read_zipper()),&[]);
    }
    v129_40_cursor.ascend(1);
  }
  drop(v129_40_cursor);
  drop(v129_40_write);
  (v129_40).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v161_20 = Space::new();
  let mut v161_20_write = v161_20.write_zipper();
  let mut v161_20_cursor = (*s0).read_zipper();
  let v161_20_origin = v161_20_cursor.path().len();
  for v161_20_byte in v161_20_cursor.child_mask().iter() {
    v161_20_cursor.descend_to_existing_byte(v161_20_byte);
    {
    let v162_2: Space = singleton(&v161_20_cursor.path()[v161_20_origin..(v161_20_origin + 1)]);
    let v162_3: Space = intersect(&(*CONSTANT_1),&(v162_2));
    let v162_4: Space = if has_head(&(v162_3)) { singleton(&[]) } else { Space::new() };
    drop(v162_3);
    let v162_5: Space = subtract(&(*CONSTANT_0),&(v162_4));
    drop(v162_4);
    let v162_8: Space = if (&(v162_5)).is_empty() { Space::new() } else {
      let v163_6: Path = concat_path(&(*p0),&v161_20_cursor.path()[v161_20_origin..(v161_20_origin + 1)]);
      let mut v163_7 = Space::new();
      let mut v163_7_write = v163_7.write_zipper();
      for v163_7_byte in v161_20_cursor.child_mask().iter() {
        v161_20_cursor.descend_to_existing_byte(v163_7_byte);
        {
        let v164_2: Space = singleton(&v161_20_cursor.path()[(v161_20_origin + 1)..(v161_20_origin + 2)]);
        let v164_3: Space = intersect(&(*CONSTANT_1),&(v164_2));
        let v164_4: Space = if has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
        drop(v164_3);
        let v164_5: Space = subtract(&(*CONSTANT_0),&(v164_4));
        drop(v164_4);
        let v164_8: Space = if (&(v164_5)).is_empty() { Space::new() } else {
          let v165_6: Path = concat_path(&(v163_6),&v161_20_cursor.path()[(v161_20_origin + 1)..(v161_20_origin + 2)]);
          let mut v165_7 = Space::new();
          let mut v165_7_write = v165_7.write_zipper();
          for v165_7_byte in v161_20_cursor.child_mask().iter() {
            v161_20_cursor.descend_to_existing_byte(v165_7_byte);
            {
            let v166_2: Space = singleton(&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
            let v166_3: Space = intersect(&(*CONSTANT_1),&(v166_2));
            let v166_4: Space = if has_head(&(v166_3)) { singleton(&[]) } else { Space::new() };
            drop(v166_3);
            let v166_5: Space = subtract(&(*CONSTANT_0),&(v166_4));
            drop(v166_4);
            let v166_8: Space = if (&(v166_5)).is_empty() { Space::new() } else {
              let v167_6: Path = concat_path(&(v165_6),&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
              let v167_7: Space = routine_22(c, &(v167_6), &v161_20_cursor);
              compose(&(v166_5),&(v167_7))
            };
            drop(v166_5);
            let v166_9: Space = intersect(&(*CONSTANT_1),&(v166_2));
            drop(v166_2);
            let v166_10: Space = if has_head(&(v166_9)) { singleton(&[]) } else { Space::new() };
            drop(v166_9);
            let v166_12: Space = if (&(v166_10)).is_empty() { Space::new() } else {
              let v168_6: Path = concat_path(&(v165_6),&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
              let v168_11: Space = routine_23(c, &(v168_6), &v161_20_cursor);
              drop(v168_6);
              compose(&(v166_10),&(v168_11))
            };
            drop(v166_10);
            let v166_13: Space = unite(&(v166_8),&(v166_12));
            join_wrapped_into(&mut v165_7_write,&((v166_13).read_zipper()),&[]);
            }
            v161_20_cursor.ascend(1);
          }
          drop(v165_7_write);
          compose(&(v164_5),&(v165_7))
        };
        drop(v164_5);
        let v164_9: Space = intersect(&(*CONSTANT_1),&(v164_2));
        drop(v164_2);
        let v164_10: Space = if has_head(&(v164_9)) { singleton(&[]) } else { Space::new() };
        drop(v164_9);
        let v164_12: Space = if (&(v164_10)).is_empty() { Space::new() } else {
          let v169_6: Path = concat_path(&(v163_6),&v161_20_cursor.path()[(v161_20_origin + 1)..(v161_20_origin + 2)]);
          let mut v169_11 = Space::new();
          let mut v169_11_write = v169_11.write_zipper();
          for v169_11_byte in v161_20_cursor.child_mask().iter() {
            v161_20_cursor.descend_to_existing_byte(v169_11_byte);
            {
            let v170_2: Space = singleton(&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
            let v170_3: Space = intersect(&(*CONSTANT_1),&(v170_2));
            let v170_4: Space = if has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
            drop(v170_3);
            let v170_5: Space = subtract(&(*CONSTANT_0),&(v170_4));
            drop(v170_4);
            let v170_8: Space = if (&(v170_5)).is_empty() { Space::new() } else {
              let v171_6: Path = concat_path(&(v169_6),&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
              let v171_7: Space = routine_22(c, &(v171_6), &v161_20_cursor);
              compose(&(v170_5),&(v171_7))
            };
            drop(v170_5);
            let v170_9: Space = intersect(&(*CONSTANT_1),&(v170_2));
            drop(v170_2);
            let v170_10: Space = if has_head(&(v170_9)) { singleton(&[]) } else { Space::new() };
            drop(v170_9);
            let v170_12: Space = if (&(v170_10)).is_empty() { Space::new() } else {
              let v172_6: Path = concat_path(&(v169_6),&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
              let v172_11: Space = routine_12(c, &(v172_6), &v161_20_cursor);
              drop(v172_6);
              compose(&(v170_10),&(v172_11))
            };
            drop(v170_10);
            let v170_13: Space = unite(&(v170_8),&(v170_12));
            join_wrapped_into(&mut v169_11_write,&((v170_13).read_zipper()),&[]);
            }
            v161_20_cursor.ascend(1);
          }
          drop(v169_11_write);
          drop(v169_6);
          compose(&(v164_10),&(v169_11))
        };
        drop(v164_10);
        let v164_13: Space = unite(&(v164_8),&(v164_12));
        join_wrapped_into(&mut v163_7_write,&((v164_13).read_zipper()),&[]);
        }
        v161_20_cursor.ascend(1);
      }
      drop(v163_7_write);
      compose(&(v162_5),&(v163_7))
    };
    drop(v162_5);
    let v162_9: Space = intersect(&(*CONSTANT_1),&(v162_2));
    drop(v162_2);
    let v162_10: Space = if has_head(&(v162_9)) { singleton(&[]) } else { Space::new() };
    drop(v162_9);
    let v162_12: Space = if (&(v162_10)).is_empty() { Space::new() } else {
      let v173_6: Path = concat_path(&(*p0),&v161_20_cursor.path()[v161_20_origin..(v161_20_origin + 1)]);
      let mut v173_11 = Space::new();
      let mut v173_11_write = v173_11.write_zipper();
      for v173_11_byte in v161_20_cursor.child_mask().iter() {
        v161_20_cursor.descend_to_existing_byte(v173_11_byte);
        {
        let v174_2: Space = singleton(&v161_20_cursor.path()[(v161_20_origin + 1)..(v161_20_origin + 2)]);
        let v174_3: Space = intersect(&(*CONSTANT_1),&(v174_2));
        let v174_4: Space = if has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
        drop(v174_3);
        let v174_5: Space = subtract(&(*CONSTANT_0),&(v174_4));
        drop(v174_4);
        let v174_8: Space = if (&(v174_5)).is_empty() { Space::new() } else {
          let v175_6: Path = concat_path(&(v173_6),&v161_20_cursor.path()[(v161_20_origin + 1)..(v161_20_origin + 2)]);
          let mut v175_7 = Space::new();
          let mut v175_7_write = v175_7.write_zipper();
          for v175_7_byte in v161_20_cursor.child_mask().iter() {
            v161_20_cursor.descend_to_existing_byte(v175_7_byte);
            {
            let v176_2: Space = singleton(&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
            let v176_3: Space = intersect(&(*CONSTANT_1),&(v176_2));
            let v176_4: Space = if has_head(&(v176_3)) { singleton(&[]) } else { Space::new() };
            drop(v176_3);
            let v176_5: Space = subtract(&(*CONSTANT_0),&(v176_4));
            drop(v176_4);
            let v176_8: Space = if (&(v176_5)).is_empty() { Space::new() } else {
              let v177_6: Path = concat_path(&(v175_6),&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
              let v177_7: Space = routine_22(c, &(v177_6), &v161_20_cursor);
              compose(&(v176_5),&(v177_7))
            };
            drop(v176_5);
            let v176_9: Space = intersect(&(*CONSTANT_1),&(v176_2));
            drop(v176_2);
            let v176_10: Space = if has_head(&(v176_9)) { singleton(&[]) } else { Space::new() };
            drop(v176_9);
            let v176_12: Space = if (&(v176_10)).is_empty() { Space::new() } else {
              let v178_6: Path = concat_path(&(v175_6),&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
              let v178_11: Space = routine_23(c, &(v178_6), &v161_20_cursor);
              drop(v178_6);
              compose(&(v176_10),&(v178_11))
            };
            drop(v176_10);
            let v176_13: Space = unite(&(v176_8),&(v176_12));
            join_wrapped_into(&mut v175_7_write,&((v176_13).read_zipper()),&[]);
            }
            v161_20_cursor.ascend(1);
          }
          drop(v175_7_write);
          drop(v175_6);
          compose(&(v174_5),&(v175_7))
        };
        drop(v174_5);
        let v174_9: Space = intersect(&(*CONSTANT_1),&(v174_2));
        drop(v174_2);
        let v174_10: Space = if has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
        drop(v174_9);
        let v174_11: Space = compose(&(v174_10),&v161_20_cursor);
        drop(v174_10);
        let v174_12: Space = unite(&(v174_8),&(v174_11));
        drop(v174_11);
        join_wrapped_into(&mut v173_11_write,&((v174_12).read_zipper()),&[]);
        }
        v161_20_cursor.ascend(1);
      }
      drop(v173_11_write);
      drop(v173_6);
      compose(&(v162_10),&(v173_11))
    };
    drop(v162_10);
    let v162_13: Space = unite(&(v162_8),&(v162_12));
    join_wrapped_into(&mut v161_20_write,&((v162_13).read_zipper()),&[]);
    }
    v161_20_cursor.ascend(1);
  }
  drop(v161_20_cursor);
  drop(v161_20_write);
  (v161_20).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v179_14 = Space::new();
  let mut v179_14_write = v179_14.write_zipper();
  let mut v179_14_cursor = (*s0).read_zipper();
  let v179_14_origin = v179_14_cursor.path().len();
  for v179_14_byte in v179_14_cursor.child_mask().iter() {
    v179_14_cursor.descend_to_existing_byte(v179_14_byte);
    {
    let v180_2: Space = singleton(&v179_14_cursor.path()[v179_14_origin..(v179_14_origin + 1)]);
    let v180_3: Space = intersect(&(*CONSTANT_1),&(v180_2));
    let v180_4: Space = if has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
    drop(v180_3);
    let v180_5: Space = subtract(&(*CONSTANT_0),&(v180_4));
    drop(v180_4);
    let v180_8: Space = if (&(v180_5)).is_empty() { Space::new() } else {
      let v181_6: Path = concat_path(&(*p0),&v179_14_cursor.path()[v179_14_origin..(v179_14_origin + 1)]);
      let mut v181_7 = Space::new();
      let mut v181_7_write = v181_7.write_zipper();
      for v181_7_byte in v179_14_cursor.child_mask().iter() {
        v179_14_cursor.descend_to_existing_byte(v181_7_byte);
        {
        let v182_2: Space = singleton(&v179_14_cursor.path()[(v179_14_origin + 1)..(v179_14_origin + 2)]);
        let v182_3: Space = intersect(&(*CONSTANT_1),&(v182_2));
        let v182_4: Space = if has_head(&(v182_3)) { singleton(&[]) } else { Space::new() };
        drop(v182_3);
        let v182_5: Space = subtract(&(*CONSTANT_0),&(v182_4));
        drop(v182_4);
        let v182_8: Space = if (&(v182_5)).is_empty() { Space::new() } else {
          let v183_6: Path = concat_path(&(v181_6),&v179_14_cursor.path()[(v179_14_origin + 1)..(v179_14_origin + 2)]);
          let mut v183_7 = Space::new();
          let mut v183_7_write = v183_7.write_zipper();
          for v183_7_byte in v179_14_cursor.child_mask().iter() {
            v179_14_cursor.descend_to_existing_byte(v183_7_byte);
            {
            let v184_2: Space = singleton(&v179_14_cursor.path()[(v179_14_origin + 2)..(v179_14_origin + 3)]);
            let v184_3: Space = intersect(&(*CONSTANT_1),&(v184_2));
            let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
            drop(v184_3);
            let v184_5: Space = subtract(&(*CONSTANT_0),&(v184_4));
            drop(v184_4);
            let v184_8: Space = if (&(v184_5)).is_empty() { Space::new() } else {
              let v185_6: Path = concat_path(&(v183_6),&v179_14_cursor.path()[(v179_14_origin + 2)..(v179_14_origin + 3)]);
              let v185_7: Space = routine_22(c, &(v185_6), &v179_14_cursor);
              compose(&(v184_5),&(v185_7))
            };
            drop(v184_5);
            let v184_9: Space = intersect(&(*CONSTANT_1),&(v184_2));
            drop(v184_2);
            let v184_10: Space = if has_head(&(v184_9)) { singleton(&[]) } else { Space::new() };
            drop(v184_9);
            let v184_12: Space = if (&(v184_10)).is_empty() { Space::new() } else {
              let v186_6: Path = concat_path(&(v183_6),&v179_14_cursor.path()[(v179_14_origin + 2)..(v179_14_origin + 3)]);
              let v186_11: Space = routine_23(c, &(v186_6), &v179_14_cursor);
              drop(v186_6);
              compose(&(v184_10),&(v186_11))
            };
            drop(v184_10);
            let v184_13: Space = unite(&(v184_8),&(v184_12));
            join_wrapped_into(&mut v183_7_write,&((v184_13).read_zipper()),&[]);
            }
            v179_14_cursor.ascend(1);
          }
          drop(v183_7_write);
          compose(&(v182_5),&(v183_7))
        };
        drop(v182_5);
        let v182_9: Space = intersect(&(*CONSTANT_1),&(v182_2));
        drop(v182_2);
        let v182_10: Space = if has_head(&(v182_9)) { singleton(&[]) } else { Space::new() };
        drop(v182_9);
        let v182_12: Space = if (&(v182_10)).is_empty() { Space::new() } else {
          let v187_6: Path = concat_path(&(v181_6),&v179_14_cursor.path()[(v179_14_origin + 1)..(v179_14_origin + 2)]);
          let mut v187_11 = Space::new();
          let mut v187_11_write = v187_11.write_zipper();
          for v187_11_byte in v179_14_cursor.child_mask().iter() {
            v179_14_cursor.descend_to_existing_byte(v187_11_byte);
            {
            let v188_2: Space = singleton(&v179_14_cursor.path()[(v179_14_origin + 2)..(v179_14_origin + 3)]);
            let v188_3: Space = intersect(&(*CONSTANT_1),&(v188_2));
            let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
            drop(v188_3);
            let v188_5: Space = subtract(&(*CONSTANT_0),&(v188_4));
            drop(v188_4);
            let v188_8: Space = if (&(v188_5)).is_empty() { Space::new() } else {
              let v189_6: Path = concat_path(&(v187_6),&v179_14_cursor.path()[(v179_14_origin + 2)..(v179_14_origin + 3)]);
              let v189_7: Space = routine_22(c, &(v189_6), &v179_14_cursor);
              compose(&(v188_5),&(v189_7))
            };
            drop(v188_5);
            let v188_9: Space = intersect(&(*CONSTANT_1),&(v188_2));
            drop(v188_2);
            let v188_10: Space = if has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
            drop(v188_9);
            let v188_12: Space = if (&(v188_10)).is_empty() { Space::new() } else {
              let v190_6: Path = concat_path(&(v187_6),&v179_14_cursor.path()[(v179_14_origin + 2)..(v179_14_origin + 3)]);
              let v190_11: Space = routine_12(c, &(v190_6), &v179_14_cursor);
              drop(v190_6);
              compose(&(v188_10),&(v190_11))
            };
            drop(v188_10);
            let v188_13: Space = unite(&(v188_8),&(v188_12));
            join_wrapped_into(&mut v187_11_write,&((v188_13).read_zipper()),&[]);
            }
            v179_14_cursor.ascend(1);
          }
          drop(v187_11_write);
          drop(v187_6);
          compose(&(v182_10),&(v187_11))
        };
        drop(v182_10);
        let v182_13: Space = unite(&(v182_8),&(v182_12));
        join_wrapped_into(&mut v181_7_write,&((v182_13).read_zipper()),&[]);
        }
        v179_14_cursor.ascend(1);
      }
      drop(v181_7_write);
      drop(v181_6);
      compose(&(v180_5),&(v181_7))
    };
    drop(v180_5);
    let v180_9: Space = intersect(&(*CONSTANT_1),&(v180_2));
    drop(v180_2);
    let v180_10: Space = if has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
    drop(v180_9);
    let v180_11: Space = compose(&(v180_10),&v179_14_cursor);
    drop(v180_10);
    let v180_12: Space = unite(&(v180_8),&(v180_11));
    drop(v180_11);
    join_wrapped_into(&mut v179_14_write,&((v180_12).read_zipper()),&[]);
    }
    v179_14_cursor.ascend(1);
  }
  drop(v179_14_cursor);
  drop(v179_14_write);
  (v179_14).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v191_20 = Space::new();
  let mut v191_20_write = v191_20.write_zipper();
  let mut v191_20_cursor = (*s0).read_zipper();
  let v191_20_origin = v191_20_cursor.path().len();
  for v191_20_byte in v191_20_cursor.child_mask().iter() {
    v191_20_cursor.descend_to_existing_byte(v191_20_byte);
    {
    let v192_2: Space = singleton(&v191_20_cursor.path()[v191_20_origin..(v191_20_origin + 1)]);
    let v192_3: Space = intersect(&(*CONSTANT_1),&(v192_2));
    let v192_4: Space = if has_head(&(v192_3)) { singleton(&[]) } else { Space::new() };
    drop(v192_3);
    let v192_5: Space = subtract(&(*CONSTANT_0),&(v192_4));
    drop(v192_4);
    let v192_8: Space = if (&(v192_5)).is_empty() { Space::new() } else {
      let v193_6: Path = concat_path(&(*p0),&v191_20_cursor.path()[v191_20_origin..(v191_20_origin + 1)]);
      let mut v193_7 = Space::new();
      let mut v193_7_write = v193_7.write_zipper();
      for v193_7_byte in v191_20_cursor.child_mask().iter() {
        v191_20_cursor.descend_to_existing_byte(v193_7_byte);
        {
        let v194_2: Space = singleton(&v191_20_cursor.path()[(v191_20_origin + 1)..(v191_20_origin + 2)]);
        let v194_3: Space = intersect(&(*CONSTANT_1),&(v194_2));
        let v194_4: Space = if has_head(&(v194_3)) { singleton(&[]) } else { Space::new() };
        drop(v194_3);
        let v194_5: Space = subtract(&(*CONSTANT_0),&(v194_4));
        drop(v194_4);
        let v194_8: Space = if (&(v194_5)).is_empty() { Space::new() } else {
          let v195_6: Path = concat_path(&(v193_6),&v191_20_cursor.path()[(v191_20_origin + 1)..(v191_20_origin + 2)]);
          let mut v195_7 = Space::new();
          let mut v195_7_write = v195_7.write_zipper();
          for v195_7_byte in v191_20_cursor.child_mask().iter() {
            v191_20_cursor.descend_to_existing_byte(v195_7_byte);
            {
            let v196_2: Space = singleton(&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
            let v196_3: Space = intersect(&(*CONSTANT_1),&(v196_2));
            let v196_4: Space = if has_head(&(v196_3)) { singleton(&[]) } else { Space::new() };
            drop(v196_3);
            let v196_5: Space = subtract(&(*CONSTANT_0),&(v196_4));
            drop(v196_4);
            let v196_8: Space = if (&(v196_5)).is_empty() { Space::new() } else {
              let v197_6: Path = concat_path(&(v195_6),&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
              let v197_7: Space = routine_24(c, &(v197_6), &v191_20_cursor);
              compose(&(v196_5),&(v197_7))
            };
            drop(v196_5);
            let v196_9: Space = intersect(&(*CONSTANT_1),&(v196_2));
            drop(v196_2);
            let v196_10: Space = if has_head(&(v196_9)) { singleton(&[]) } else { Space::new() };
            drop(v196_9);
            let v196_12: Space = if (&(v196_10)).is_empty() { Space::new() } else {
              let v198_6: Path = concat_path(&(v195_6),&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
              let v198_11: Space = routine_25(c, &(v198_6), &v191_20_cursor);
              drop(v198_6);
              compose(&(v196_10),&(v198_11))
            };
            drop(v196_10);
            let v196_13: Space = unite(&(v196_8),&(v196_12));
            join_wrapped_into(&mut v195_7_write,&((v196_13).read_zipper()),&[]);
            }
            v191_20_cursor.ascend(1);
          }
          drop(v195_7_write);
          compose(&(v194_5),&(v195_7))
        };
        drop(v194_5);
        let v194_9: Space = intersect(&(*CONSTANT_1),&(v194_2));
        drop(v194_2);
        let v194_10: Space = if has_head(&(v194_9)) { singleton(&[]) } else { Space::new() };
        drop(v194_9);
        let v194_12: Space = if (&(v194_10)).is_empty() { Space::new() } else {
          let v199_6: Path = concat_path(&(v193_6),&v191_20_cursor.path()[(v191_20_origin + 1)..(v191_20_origin + 2)]);
          let mut v199_11 = Space::new();
          let mut v199_11_write = v199_11.write_zipper();
          for v199_11_byte in v191_20_cursor.child_mask().iter() {
            v191_20_cursor.descend_to_existing_byte(v199_11_byte);
            {
            let v200_2: Space = singleton(&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
            let v200_3: Space = intersect(&(*CONSTANT_1),&(v200_2));
            let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
            drop(v200_3);
            let v200_5: Space = subtract(&(*CONSTANT_0),&(v200_4));
            drop(v200_4);
            let v200_8: Space = if (&(v200_5)).is_empty() { Space::new() } else {
              let v201_6: Path = concat_path(&(v199_6),&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
              let v201_7: Space = routine_24(c, &(v201_6), &v191_20_cursor);
              compose(&(v200_5),&(v201_7))
            };
            drop(v200_5);
            let v200_9: Space = intersect(&(*CONSTANT_1),&(v200_2));
            drop(v200_2);
            let v200_10: Space = if has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
            drop(v200_9);
            let v200_12: Space = if (&(v200_10)).is_empty() { Space::new() } else {
              let v202_6: Path = concat_path(&(v199_6),&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
              let v202_11: Space = routine_15(c, &(v202_6), &v191_20_cursor);
              drop(v202_6);
              compose(&(v200_10),&(v202_11))
            };
            drop(v200_10);
            let v200_13: Space = unite(&(v200_8),&(v200_12));
            join_wrapped_into(&mut v199_11_write,&((v200_13).read_zipper()),&[]);
            }
            v191_20_cursor.ascend(1);
          }
          drop(v199_11_write);
          drop(v199_6);
          compose(&(v194_10),&(v199_11))
        };
        drop(v194_10);
        let v194_13: Space = unite(&(v194_8),&(v194_12));
        join_wrapped_into(&mut v193_7_write,&((v194_13).read_zipper()),&[]);
        }
        v191_20_cursor.ascend(1);
      }
      drop(v193_7_write);
      compose(&(v192_5),&(v193_7))
    };
    drop(v192_5);
    let v192_9: Space = intersect(&(*CONSTANT_1),&(v192_2));
    drop(v192_2);
    let v192_10: Space = if has_head(&(v192_9)) { singleton(&[]) } else { Space::new() };
    drop(v192_9);
    let v192_12: Space = if (&(v192_10)).is_empty() { Space::new() } else {
      let v203_6: Path = concat_path(&(*p0),&v191_20_cursor.path()[v191_20_origin..(v191_20_origin + 1)]);
      let mut v203_11 = Space::new();
      let mut v203_11_write = v203_11.write_zipper();
      for v203_11_byte in v191_20_cursor.child_mask().iter() {
        v191_20_cursor.descend_to_existing_byte(v203_11_byte);
        {
        let v204_2: Space = singleton(&v191_20_cursor.path()[(v191_20_origin + 1)..(v191_20_origin + 2)]);
        let v204_3: Space = intersect(&(*CONSTANT_1),&(v204_2));
        let v204_4: Space = if has_head(&(v204_3)) { singleton(&[]) } else { Space::new() };
        drop(v204_3);
        let v204_5: Space = subtract(&(*CONSTANT_0),&(v204_4));
        drop(v204_4);
        let v204_8: Space = if (&(v204_5)).is_empty() { Space::new() } else {
          let v205_6: Path = concat_path(&(v203_6),&v191_20_cursor.path()[(v191_20_origin + 1)..(v191_20_origin + 2)]);
          let mut v205_7 = Space::new();
          let mut v205_7_write = v205_7.write_zipper();
          for v205_7_byte in v191_20_cursor.child_mask().iter() {
            v191_20_cursor.descend_to_existing_byte(v205_7_byte);
            {
            let v206_2: Space = singleton(&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
            let v206_3: Space = intersect(&(*CONSTANT_1),&(v206_2));
            let v206_4: Space = if has_head(&(v206_3)) { singleton(&[]) } else { Space::new() };
            drop(v206_3);
            let v206_5: Space = subtract(&(*CONSTANT_0),&(v206_4));
            drop(v206_4);
            let v206_8: Space = if (&(v206_5)).is_empty() { Space::new() } else {
              let v207_6: Path = concat_path(&(v205_6),&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
              let v207_7: Space = routine_24(c, &(v207_6), &v191_20_cursor);
              compose(&(v206_5),&(v207_7))
            };
            drop(v206_5);
            let v206_9: Space = intersect(&(*CONSTANT_1),&(v206_2));
            drop(v206_2);
            let v206_10: Space = if has_head(&(v206_9)) { singleton(&[]) } else { Space::new() };
            drop(v206_9);
            let v206_12: Space = if (&(v206_10)).is_empty() { Space::new() } else {
              let v208_6: Path = concat_path(&(v205_6),&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
              let v208_11: Space = routine_25(c, &(v208_6), &v191_20_cursor);
              drop(v208_6);
              compose(&(v206_10),&(v208_11))
            };
            drop(v206_10);
            let v206_13: Space = unite(&(v206_8),&(v206_12));
            join_wrapped_into(&mut v205_7_write,&((v206_13).read_zipper()),&[]);
            }
            v191_20_cursor.ascend(1);
          }
          drop(v205_7_write);
          drop(v205_6);
          compose(&(v204_5),&(v205_7))
        };
        drop(v204_5);
        let v204_9: Space = intersect(&(*CONSTANT_1),&(v204_2));
        drop(v204_2);
        let v204_10: Space = if has_head(&(v204_9)) { singleton(&[]) } else { Space::new() };
        drop(v204_9);
        let v204_11: Space = compose(&(v204_10),&v191_20_cursor);
        drop(v204_10);
        let v204_12: Space = unite(&(v204_8),&(v204_11));
        drop(v204_11);
        join_wrapped_into(&mut v203_11_write,&((v204_12).read_zipper()),&[]);
        }
        v191_20_cursor.ascend(1);
      }
      drop(v203_11_write);
      drop(v203_6);
      compose(&(v192_10),&(v203_11))
    };
    drop(v192_10);
    let v192_13: Space = unite(&(v192_8),&(v192_12));
    join_wrapped_into(&mut v191_20_write,&((v192_13).read_zipper()),&[]);
    }
    v191_20_cursor.ascend(1);
  }
  drop(v191_20_cursor);
  drop(v191_20_write);
  (v191_20).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v209_14 = Space::new();
  let mut v209_14_write = v209_14.write_zipper();
  let mut v209_14_cursor = (*s0).read_zipper();
  let v209_14_origin = v209_14_cursor.path().len();
  for v209_14_byte in v209_14_cursor.child_mask().iter() {
    v209_14_cursor.descend_to_existing_byte(v209_14_byte);
    {
    let v210_2: Space = singleton(&v209_14_cursor.path()[v209_14_origin..(v209_14_origin + 1)]);
    let v210_3: Space = intersect(&(*CONSTANT_1),&(v210_2));
    let v210_4: Space = if has_head(&(v210_3)) { singleton(&[]) } else { Space::new() };
    drop(v210_3);
    let v210_5: Space = subtract(&(*CONSTANT_0),&(v210_4));
    drop(v210_4);
    let v210_8: Space = if (&(v210_5)).is_empty() { Space::new() } else {
      let v211_6: Path = concat_path(&(*p0),&v209_14_cursor.path()[v209_14_origin..(v209_14_origin + 1)]);
      let mut v211_7 = Space::new();
      let mut v211_7_write = v211_7.write_zipper();
      for v211_7_byte in v209_14_cursor.child_mask().iter() {
        v209_14_cursor.descend_to_existing_byte(v211_7_byte);
        {
        let v212_2: Space = singleton(&v209_14_cursor.path()[(v209_14_origin + 1)..(v209_14_origin + 2)]);
        let v212_3: Space = intersect(&(*CONSTANT_1),&(v212_2));
        let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
        drop(v212_3);
        let v212_5: Space = subtract(&(*CONSTANT_0),&(v212_4));
        drop(v212_4);
        let v212_8: Space = if (&(v212_5)).is_empty() { Space::new() } else {
          let v213_6: Path = concat_path(&(v211_6),&v209_14_cursor.path()[(v209_14_origin + 1)..(v209_14_origin + 2)]);
          let mut v213_7 = Space::new();
          let mut v213_7_write = v213_7.write_zipper();
          for v213_7_byte in v209_14_cursor.child_mask().iter() {
            v209_14_cursor.descend_to_existing_byte(v213_7_byte);
            {
            let v214_2: Space = singleton(&v209_14_cursor.path()[(v209_14_origin + 2)..(v209_14_origin + 3)]);
            let v214_3: Space = intersect(&(*CONSTANT_1),&(v214_2));
            let v214_4: Space = if has_head(&(v214_3)) { singleton(&[]) } else { Space::new() };
            drop(v214_3);
            let v214_5: Space = subtract(&(*CONSTANT_0),&(v214_4));
            drop(v214_4);
            let v214_8: Space = if (&(v214_5)).is_empty() { Space::new() } else {
              let v215_6: Path = concat_path(&(v213_6),&v209_14_cursor.path()[(v209_14_origin + 2)..(v209_14_origin + 3)]);
              let v215_7: Space = routine_24(c, &(v215_6), &v209_14_cursor);
              compose(&(v214_5),&(v215_7))
            };
            drop(v214_5);
            let v214_9: Space = intersect(&(*CONSTANT_1),&(v214_2));
            drop(v214_2);
            let v214_10: Space = if has_head(&(v214_9)) { singleton(&[]) } else { Space::new() };
            drop(v214_9);
            let v214_12: Space = if (&(v214_10)).is_empty() { Space::new() } else {
              let v216_6: Path = concat_path(&(v213_6),&v209_14_cursor.path()[(v209_14_origin + 2)..(v209_14_origin + 3)]);
              let v216_11: Space = routine_25(c, &(v216_6), &v209_14_cursor);
              drop(v216_6);
              compose(&(v214_10),&(v216_11))
            };
            drop(v214_10);
            let v214_13: Space = unite(&(v214_8),&(v214_12));
            join_wrapped_into(&mut v213_7_write,&((v214_13).read_zipper()),&[]);
            }
            v209_14_cursor.ascend(1);
          }
          drop(v213_7_write);
          compose(&(v212_5),&(v213_7))
        };
        drop(v212_5);
        let v212_9: Space = intersect(&(*CONSTANT_1),&(v212_2));
        drop(v212_2);
        let v212_10: Space = if has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
        drop(v212_9);
        let v212_12: Space = if (&(v212_10)).is_empty() { Space::new() } else {
          let v217_6: Path = concat_path(&(v211_6),&v209_14_cursor.path()[(v209_14_origin + 1)..(v209_14_origin + 2)]);
          let mut v217_11 = Space::new();
          let mut v217_11_write = v217_11.write_zipper();
          for v217_11_byte in v209_14_cursor.child_mask().iter() {
            v209_14_cursor.descend_to_existing_byte(v217_11_byte);
            {
            let v218_2: Space = singleton(&v209_14_cursor.path()[(v209_14_origin + 2)..(v209_14_origin + 3)]);
            let v218_3: Space = intersect(&(*CONSTANT_1),&(v218_2));
            let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
            drop(v218_3);
            let v218_5: Space = subtract(&(*CONSTANT_0),&(v218_4));
            drop(v218_4);
            let v218_8: Space = if (&(v218_5)).is_empty() { Space::new() } else {
              let v219_6: Path = concat_path(&(v217_6),&v209_14_cursor.path()[(v209_14_origin + 2)..(v209_14_origin + 3)]);
              let v219_7: Space = routine_24(c, &(v219_6), &v209_14_cursor);
              compose(&(v218_5),&(v219_7))
            };
            drop(v218_5);
            let v218_9: Space = intersect(&(*CONSTANT_1),&(v218_2));
            drop(v218_2);
            let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
            drop(v218_9);
            let v218_12: Space = if (&(v218_10)).is_empty() { Space::new() } else {
              let v220_6: Path = concat_path(&(v217_6),&v209_14_cursor.path()[(v209_14_origin + 2)..(v209_14_origin + 3)]);
              let v220_11: Space = routine_15(c, &(v220_6), &v209_14_cursor);
              drop(v220_6);
              compose(&(v218_10),&(v220_11))
            };
            drop(v218_10);
            let v218_13: Space = unite(&(v218_8),&(v218_12));
            join_wrapped_into(&mut v217_11_write,&((v218_13).read_zipper()),&[]);
            }
            v209_14_cursor.ascend(1);
          }
          drop(v217_11_write);
          drop(v217_6);
          compose(&(v212_10),&(v217_11))
        };
        drop(v212_10);
        let v212_13: Space = unite(&(v212_8),&(v212_12));
        join_wrapped_into(&mut v211_7_write,&((v212_13).read_zipper()),&[]);
        }
        v209_14_cursor.ascend(1);
      }
      drop(v211_7_write);
      drop(v211_6);
      compose(&(v210_5),&(v211_7))
    };
    drop(v210_5);
    let v210_9: Space = intersect(&(*CONSTANT_1),&(v210_2));
    drop(v210_2);
    let v210_10: Space = if has_head(&(v210_9)) { singleton(&[]) } else { Space::new() };
    drop(v210_9);
    let v210_11: Space = compose(&(v210_10),&v209_14_cursor);
    drop(v210_10);
    let v210_12: Space = unite(&(v210_8),&(v210_11));
    drop(v210_11);
    join_wrapped_into(&mut v209_14_write,&((v210_12).read_zipper()),&[]);
    }
    v209_14_cursor.ascend(1);
  }
  drop(v209_14_cursor);
  drop(v209_14_write);
  (v209_14).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v221_20 = Space::new();
  let mut v221_20_write = v221_20.write_zipper();
  let mut v221_20_cursor = (*s0).read_zipper();
  let v221_20_origin = v221_20_cursor.path().len();
  for v221_20_byte in v221_20_cursor.child_mask().iter() {
    v221_20_cursor.descend_to_existing_byte(v221_20_byte);
    {
    let v222_2: Space = singleton(&v221_20_cursor.path()[v221_20_origin..(v221_20_origin + 1)]);
    let v222_3: Space = intersect(&(*CONSTANT_1),&(v222_2));
    let v222_4: Space = if has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
    drop(v222_3);
    let v222_5: Space = subtract(&(*CONSTANT_0),&(v222_4));
    drop(v222_4);
    let v222_8: Space = if (&(v222_5)).is_empty() { Space::new() } else {
      let v223_6: Path = concat_path(&(*p0),&v221_20_cursor.path()[v221_20_origin..(v221_20_origin + 1)]);
      let mut v223_7 = Space::new();
      let mut v223_7_write = v223_7.write_zipper();
      for v223_7_byte in v221_20_cursor.child_mask().iter() {
        v221_20_cursor.descend_to_existing_byte(v223_7_byte);
        {
        let v224_2: Space = singleton(&v221_20_cursor.path()[(v221_20_origin + 1)..(v221_20_origin + 2)]);
        let v224_3: Space = intersect(&(*CONSTANT_1),&(v224_2));
        let v224_4: Space = if has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
        drop(v224_3);
        let v224_5: Space = subtract(&(*CONSTANT_0),&(v224_4));
        drop(v224_4);
        let v224_8: Space = if (&(v224_5)).is_empty() { Space::new() } else {
          let v225_6: Path = concat_path(&(v223_6),&v221_20_cursor.path()[(v221_20_origin + 1)..(v221_20_origin + 2)]);
          let mut v225_7 = Space::new();
          let mut v225_7_write = v225_7.write_zipper();
          for v225_7_byte in v221_20_cursor.child_mask().iter() {
            v221_20_cursor.descend_to_existing_byte(v225_7_byte);
            {
            let v226_2: Space = singleton(&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
            let v226_3: Space = intersect(&(*CONSTANT_1),&(v226_2));
            let v226_4: Space = if has_head(&(v226_3)) { singleton(&[]) } else { Space::new() };
            drop(v226_3);
            let v226_5: Space = subtract(&(*CONSTANT_0),&(v226_4));
            drop(v226_4);
            let v226_8: Space = if (&(v226_5)).is_empty() { Space::new() } else {
              let v227_6: Path = concat_path(&(v225_6),&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
              let v227_7: Space = routine_26(c, &(v227_6), &v221_20_cursor);
              compose(&(v226_5),&(v227_7))
            };
            drop(v226_5);
            let v226_9: Space = intersect(&(*CONSTANT_1),&(v226_2));
            drop(v226_2);
            let v226_10: Space = if has_head(&(v226_9)) { singleton(&[]) } else { Space::new() };
            drop(v226_9);
            let v226_12: Space = if (&(v226_10)).is_empty() { Space::new() } else {
              let v228_6: Path = concat_path(&(v225_6),&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
              let v228_11: Space = routine_27(c, &(v228_6), &v221_20_cursor);
              drop(v228_6);
              compose(&(v226_10),&(v228_11))
            };
            drop(v226_10);
            let v226_13: Space = unite(&(v226_8),&(v226_12));
            join_wrapped_into(&mut v225_7_write,&((v226_13).read_zipper()),&[]);
            }
            v221_20_cursor.ascend(1);
          }
          drop(v225_7_write);
          compose(&(v224_5),&(v225_7))
        };
        drop(v224_5);
        let v224_9: Space = intersect(&(*CONSTANT_1),&(v224_2));
        drop(v224_2);
        let v224_10: Space = if has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
        drop(v224_9);
        let v224_12: Space = if (&(v224_10)).is_empty() { Space::new() } else {
          let v229_6: Path = concat_path(&(v223_6),&v221_20_cursor.path()[(v221_20_origin + 1)..(v221_20_origin + 2)]);
          let mut v229_11 = Space::new();
          let mut v229_11_write = v229_11.write_zipper();
          for v229_11_byte in v221_20_cursor.child_mask().iter() {
            v221_20_cursor.descend_to_existing_byte(v229_11_byte);
            {
            let v230_2: Space = singleton(&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
            let v230_3: Space = intersect(&(*CONSTANT_1),&(v230_2));
            let v230_4: Space = if has_head(&(v230_3)) { singleton(&[]) } else { Space::new() };
            drop(v230_3);
            let v230_5: Space = subtract(&(*CONSTANT_0),&(v230_4));
            drop(v230_4);
            let v230_8: Space = if (&(v230_5)).is_empty() { Space::new() } else {
              let v231_6: Path = concat_path(&(v229_6),&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
              let v231_7: Space = routine_26(c, &(v231_6), &v221_20_cursor);
              compose(&(v230_5),&(v231_7))
            };
            drop(v230_5);
            let v230_9: Space = intersect(&(*CONSTANT_1),&(v230_2));
            drop(v230_2);
            let v230_10: Space = if has_head(&(v230_9)) { singleton(&[]) } else { Space::new() };
            drop(v230_9);
            let v230_12: Space = if (&(v230_10)).is_empty() { Space::new() } else {
              let v232_6: Path = concat_path(&(v229_6),&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
              let v232_11: Space = routine_12(c, &(v232_6), &v221_20_cursor);
              drop(v232_6);
              compose(&(v230_10),&(v232_11))
            };
            drop(v230_10);
            let v230_13: Space = unite(&(v230_8),&(v230_12));
            join_wrapped_into(&mut v229_11_write,&((v230_13).read_zipper()),&[]);
            }
            v221_20_cursor.ascend(1);
          }
          drop(v229_11_write);
          drop(v229_6);
          compose(&(v224_10),&(v229_11))
        };
        drop(v224_10);
        let v224_13: Space = unite(&(v224_8),&(v224_12));
        join_wrapped_into(&mut v223_7_write,&((v224_13).read_zipper()),&[]);
        }
        v221_20_cursor.ascend(1);
      }
      drop(v223_7_write);
      compose(&(v222_5),&(v223_7))
    };
    drop(v222_5);
    let v222_9: Space = intersect(&(*CONSTANT_1),&(v222_2));
    drop(v222_2);
    let v222_10: Space = if has_head(&(v222_9)) { singleton(&[]) } else { Space::new() };
    drop(v222_9);
    let v222_12: Space = if (&(v222_10)).is_empty() { Space::new() } else {
      let v233_6: Path = concat_path(&(*p0),&v221_20_cursor.path()[v221_20_origin..(v221_20_origin + 1)]);
      let mut v233_11 = Space::new();
      let mut v233_11_write = v233_11.write_zipper();
      for v233_11_byte in v221_20_cursor.child_mask().iter() {
        v221_20_cursor.descend_to_existing_byte(v233_11_byte);
        {
        let v234_2: Space = singleton(&v221_20_cursor.path()[(v221_20_origin + 1)..(v221_20_origin + 2)]);
        let v234_3: Space = intersect(&(*CONSTANT_1),&(v234_2));
        let v234_4: Space = if has_head(&(v234_3)) { singleton(&[]) } else { Space::new() };
        drop(v234_3);
        let v234_5: Space = subtract(&(*CONSTANT_0),&(v234_4));
        drop(v234_4);
        let v234_8: Space = if (&(v234_5)).is_empty() { Space::new() } else {
          let v235_6: Path = concat_path(&(v233_6),&v221_20_cursor.path()[(v221_20_origin + 1)..(v221_20_origin + 2)]);
          let mut v235_7 = Space::new();
          let mut v235_7_write = v235_7.write_zipper();
          for v235_7_byte in v221_20_cursor.child_mask().iter() {
            v221_20_cursor.descend_to_existing_byte(v235_7_byte);
            {
            let v236_2: Space = singleton(&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
            let v236_3: Space = intersect(&(*CONSTANT_1),&(v236_2));
            let v236_4: Space = if has_head(&(v236_3)) { singleton(&[]) } else { Space::new() };
            drop(v236_3);
            let v236_5: Space = subtract(&(*CONSTANT_0),&(v236_4));
            drop(v236_4);
            let v236_8: Space = if (&(v236_5)).is_empty() { Space::new() } else {
              let v237_6: Path = concat_path(&(v235_6),&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
              let v237_7: Space = routine_26(c, &(v237_6), &v221_20_cursor);
              compose(&(v236_5),&(v237_7))
            };
            drop(v236_5);
            let v236_9: Space = intersect(&(*CONSTANT_1),&(v236_2));
            drop(v236_2);
            let v236_10: Space = if has_head(&(v236_9)) { singleton(&[]) } else { Space::new() };
            drop(v236_9);
            let v236_12: Space = if (&(v236_10)).is_empty() { Space::new() } else {
              let v238_6: Path = concat_path(&(v235_6),&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
              let v238_11: Space = routine_27(c, &(v238_6), &v221_20_cursor);
              drop(v238_6);
              compose(&(v236_10),&(v238_11))
            };
            drop(v236_10);
            let v236_13: Space = unite(&(v236_8),&(v236_12));
            join_wrapped_into(&mut v235_7_write,&((v236_13).read_zipper()),&[]);
            }
            v221_20_cursor.ascend(1);
          }
          drop(v235_7_write);
          drop(v235_6);
          compose(&(v234_5),&(v235_7))
        };
        drop(v234_5);
        let v234_9: Space = intersect(&(*CONSTANT_1),&(v234_2));
        drop(v234_2);
        let v234_10: Space = if has_head(&(v234_9)) { singleton(&[]) } else { Space::new() };
        drop(v234_9);
        let v234_11: Space = compose(&(v234_10),&v221_20_cursor);
        drop(v234_10);
        let v234_12: Space = unite(&(v234_8),&(v234_11));
        drop(v234_11);
        join_wrapped_into(&mut v233_11_write,&((v234_12).read_zipper()),&[]);
        }
        v221_20_cursor.ascend(1);
      }
      drop(v233_11_write);
      drop(v233_6);
      compose(&(v222_10),&(v233_11))
    };
    drop(v222_10);
    let v222_13: Space = unite(&(v222_8),&(v222_12));
    join_wrapped_into(&mut v221_20_write,&((v222_13).read_zipper()),&[]);
    }
    v221_20_cursor.ascend(1);
  }
  drop(v221_20_cursor);
  drop(v221_20_write);
  (v221_20).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v239_14 = Space::new();
  let mut v239_14_write = v239_14.write_zipper();
  let mut v239_14_cursor = (*s0).read_zipper();
  let v239_14_origin = v239_14_cursor.path().len();
  for v239_14_byte in v239_14_cursor.child_mask().iter() {
    v239_14_cursor.descend_to_existing_byte(v239_14_byte);
    {
    let v240_2: Space = singleton(&v239_14_cursor.path()[v239_14_origin..(v239_14_origin + 1)]);
    let v240_3: Space = intersect(&(*CONSTANT_1),&(v240_2));
    let v240_4: Space = if has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
    drop(v240_3);
    let v240_5: Space = subtract(&(*CONSTANT_0),&(v240_4));
    drop(v240_4);
    let v240_8: Space = if (&(v240_5)).is_empty() { Space::new() } else {
      let v241_6: Path = concat_path(&(*p0),&v239_14_cursor.path()[v239_14_origin..(v239_14_origin + 1)]);
      let mut v241_7 = Space::new();
      let mut v241_7_write = v241_7.write_zipper();
      for v241_7_byte in v239_14_cursor.child_mask().iter() {
        v239_14_cursor.descend_to_existing_byte(v241_7_byte);
        {
        let v242_2: Space = singleton(&v239_14_cursor.path()[(v239_14_origin + 1)..(v239_14_origin + 2)]);
        let v242_3: Space = intersect(&(*CONSTANT_1),&(v242_2));
        let v242_4: Space = if has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
        drop(v242_3);
        let v242_5: Space = subtract(&(*CONSTANT_0),&(v242_4));
        drop(v242_4);
        let v242_8: Space = if (&(v242_5)).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v241_6),&v239_14_cursor.path()[(v239_14_origin + 1)..(v239_14_origin + 2)]);
          let mut v243_7 = Space::new();
          let mut v243_7_write = v243_7.write_zipper();
          for v243_7_byte in v239_14_cursor.child_mask().iter() {
            v239_14_cursor.descend_to_existing_byte(v243_7_byte);
            {
            let v244_2: Space = singleton(&v239_14_cursor.path()[(v239_14_origin + 2)..(v239_14_origin + 3)]);
            let v244_3: Space = intersect(&(*CONSTANT_1),&(v244_2));
            let v244_4: Space = if has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
            drop(v244_3);
            let v244_5: Space = subtract(&(*CONSTANT_0),&(v244_4));
            drop(v244_4);
            let v244_8: Space = if (&(v244_5)).is_empty() { Space::new() } else {
              let v245_6: Path = concat_path(&(v243_6),&v239_14_cursor.path()[(v239_14_origin + 2)..(v239_14_origin + 3)]);
              let v245_7: Space = routine_26(c, &(v245_6), &v239_14_cursor);
              compose(&(v244_5),&(v245_7))
            };
            drop(v244_5);
            let v244_9: Space = intersect(&(*CONSTANT_1),&(v244_2));
            drop(v244_2);
            let v244_10: Space = if has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
            drop(v244_9);
            let v244_12: Space = if (&(v244_10)).is_empty() { Space::new() } else {
              let v246_6: Path = concat_path(&(v243_6),&v239_14_cursor.path()[(v239_14_origin + 2)..(v239_14_origin + 3)]);
              let v246_11: Space = routine_27(c, &(v246_6), &v239_14_cursor);
              drop(v246_6);
              compose(&(v244_10),&(v246_11))
            };
            drop(v244_10);
            let v244_13: Space = unite(&(v244_8),&(v244_12));
            join_wrapped_into(&mut v243_7_write,&((v244_13).read_zipper()),&[]);
            }
            v239_14_cursor.ascend(1);
          }
          drop(v243_7_write);
          compose(&(v242_5),&(v243_7))
        };
        drop(v242_5);
        let v242_9: Space = intersect(&(*CONSTANT_1),&(v242_2));
        drop(v242_2);
        let v242_10: Space = if has_head(&(v242_9)) { singleton(&[]) } else { Space::new() };
        drop(v242_9);
        let v242_12: Space = if (&(v242_10)).is_empty() { Space::new() } else {
          let v247_6: Path = concat_path(&(v241_6),&v239_14_cursor.path()[(v239_14_origin + 1)..(v239_14_origin + 2)]);
          let mut v247_11 = Space::new();
          let mut v247_11_write = v247_11.write_zipper();
          for v247_11_byte in v239_14_cursor.child_mask().iter() {
            v239_14_cursor.descend_to_existing_byte(v247_11_byte);
            {
            let v248_2: Space = singleton(&v239_14_cursor.path()[(v239_14_origin + 2)..(v239_14_origin + 3)]);
            let v248_3: Space = intersect(&(*CONSTANT_1),&(v248_2));
            let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
            drop(v248_3);
            let v248_5: Space = subtract(&(*CONSTANT_0),&(v248_4));
            drop(v248_4);
            let v248_8: Space = if (&(v248_5)).is_empty() { Space::new() } else {
              let v249_6: Path = concat_path(&(v247_6),&v239_14_cursor.path()[(v239_14_origin + 2)..(v239_14_origin + 3)]);
              let v249_7: Space = routine_26(c, &(v249_6), &v239_14_cursor);
              compose(&(v248_5),&(v249_7))
            };
            drop(v248_5);
            let v248_9: Space = intersect(&(*CONSTANT_1),&(v248_2));
            drop(v248_2);
            let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
            drop(v248_9);
            let v248_12: Space = if (&(v248_10)).is_empty() { Space::new() } else {
              let v250_6: Path = concat_path(&(v247_6),&v239_14_cursor.path()[(v239_14_origin + 2)..(v239_14_origin + 3)]);
              let v250_11: Space = routine_12(c, &(v250_6), &v239_14_cursor);
              drop(v250_6);
              compose(&(v248_10),&(v250_11))
            };
            drop(v248_10);
            let v248_13: Space = unite(&(v248_8),&(v248_12));
            join_wrapped_into(&mut v247_11_write,&((v248_13).read_zipper()),&[]);
            }
            v239_14_cursor.ascend(1);
          }
          drop(v247_11_write);
          drop(v247_6);
          compose(&(v242_10),&(v247_11))
        };
        drop(v242_10);
        let v242_13: Space = unite(&(v242_8),&(v242_12));
        join_wrapped_into(&mut v241_7_write,&((v242_13).read_zipper()),&[]);
        }
        v239_14_cursor.ascend(1);
      }
      drop(v241_7_write);
      drop(v241_6);
      compose(&(v240_5),&(v241_7))
    };
    drop(v240_5);
    let v240_9: Space = intersect(&(*CONSTANT_1),&(v240_2));
    drop(v240_2);
    let v240_10: Space = if has_head(&(v240_9)) { singleton(&[]) } else { Space::new() };
    drop(v240_9);
    let v240_11: Space = compose(&(v240_10),&v239_14_cursor);
    drop(v240_10);
    let v240_12: Space = unite(&(v240_8),&(v240_11));
    drop(v240_11);
    join_wrapped_into(&mut v239_14_write,&((v240_12).read_zipper()),&[]);
    }
    v239_14_cursor.ascend(1);
  }
  drop(v239_14_cursor);
  drop(v239_14_write);
  (v239_14).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v252_20 = Space::new();
  let mut v252_20_write = v252_20.write_zipper();
  let mut v252_20_cursor = (*s0).read_zipper();
  let v252_20_origin = v252_20_cursor.path().len();
  for v252_20_byte in v252_20_cursor.child_mask().iter() {
    v252_20_cursor.descend_to_existing_byte(v252_20_byte);
    {
    let v253_2: Space = singleton(&v252_20_cursor.path()[v252_20_origin..(v252_20_origin + 1)]);
    let v253_3: Space = intersect(&(*CONSTANT_1),&(v253_2));
    let v253_4: Space = if has_head(&(v253_3)) { singleton(&[]) } else { Space::new() };
    drop(v253_3);
    let v253_5: Space = subtract(&(*CONSTANT_0),&(v253_4));
    drop(v253_4);
    let v253_8: Space = if (&(v253_5)).is_empty() { Space::new() } else {
      let v254_6: Path = concat_path(&(*p0),&v252_20_cursor.path()[v252_20_origin..(v252_20_origin + 1)]);
      let mut v254_7 = Space::new();
      let mut v254_7_write = v254_7.write_zipper();
      for v254_7_byte in v252_20_cursor.child_mask().iter() {
        v252_20_cursor.descend_to_existing_byte(v254_7_byte);
        {
        let v255_2: Space = singleton(&v252_20_cursor.path()[(v252_20_origin + 1)..(v252_20_origin + 2)]);
        let v255_3: Space = intersect(&(*CONSTANT_1),&(v255_2));
        let v255_4: Space = if has_head(&(v255_3)) { singleton(&[]) } else { Space::new() };
        drop(v255_3);
        let v255_5: Space = subtract(&(*CONSTANT_0),&(v255_4));
        drop(v255_4);
        let v255_8: Space = if (&(v255_5)).is_empty() { Space::new() } else {
          let v256_6: Path = concat_path(&(v254_6),&v252_20_cursor.path()[(v252_20_origin + 1)..(v252_20_origin + 2)]);
          let mut v256_7 = Space::new();
          let mut v256_7_write = v256_7.write_zipper();
          for v256_7_byte in v252_20_cursor.child_mask().iter() {
            v252_20_cursor.descend_to_existing_byte(v256_7_byte);
            {
            let v257_2: Space = singleton(&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
            let v257_3: Space = intersect(&(*CONSTANT_1),&(v257_2));
            let v257_4: Space = if has_head(&(v257_3)) { singleton(&[]) } else { Space::new() };
            drop(v257_3);
            let v257_5: Space = subtract(&(*CONSTANT_0),&(v257_4));
            drop(v257_4);
            let v257_8: Space = if (&(v257_5)).is_empty() { Space::new() } else {
              let v258_6: Path = concat_path(&(v256_6),&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
              let v258_7: Space = routine_28(c, &(v258_6), &v252_20_cursor);
              compose(&(v257_5),&(v258_7))
            };
            drop(v257_5);
            let v257_9: Space = intersect(&(*CONSTANT_1),&(v257_2));
            drop(v257_2);
            let v257_10: Space = if has_head(&(v257_9)) { singleton(&[]) } else { Space::new() };
            drop(v257_9);
            let v257_12: Space = if (&(v257_10)).is_empty() { Space::new() } else {
              let v259_6: Path = concat_path(&(v256_6),&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
              let v259_11: Space = routine_29(c, &(v259_6), &v252_20_cursor);
              drop(v259_6);
              compose(&(v257_10),&(v259_11))
            };
            drop(v257_10);
            let v257_13: Space = unite(&(v257_8),&(v257_12));
            join_wrapped_into(&mut v256_7_write,&((v257_13).read_zipper()),&[]);
            }
            v252_20_cursor.ascend(1);
          }
          drop(v256_7_write);
          compose(&(v255_5),&(v256_7))
        };
        drop(v255_5);
        let v255_9: Space = intersect(&(*CONSTANT_1),&(v255_2));
        drop(v255_2);
        let v255_10: Space = if has_head(&(v255_9)) { singleton(&[]) } else { Space::new() };
        drop(v255_9);
        let v255_12: Space = if (&(v255_10)).is_empty() { Space::new() } else {
          let v260_6: Path = concat_path(&(v254_6),&v252_20_cursor.path()[(v252_20_origin + 1)..(v252_20_origin + 2)]);
          let mut v260_11 = Space::new();
          let mut v260_11_write = v260_11.write_zipper();
          for v260_11_byte in v252_20_cursor.child_mask().iter() {
            v252_20_cursor.descend_to_existing_byte(v260_11_byte);
            {
            let v261_2: Space = singleton(&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
            let v261_3: Space = intersect(&(*CONSTANT_1),&(v261_2));
            let v261_4: Space = if has_head(&(v261_3)) { singleton(&[]) } else { Space::new() };
            drop(v261_3);
            let v261_5: Space = subtract(&(*CONSTANT_0),&(v261_4));
            drop(v261_4);
            let v261_8: Space = if (&(v261_5)).is_empty() { Space::new() } else {
              let v262_6: Path = concat_path(&(v260_6),&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
              let v262_7: Space = routine_28(c, &(v262_6), &v252_20_cursor);
              compose(&(v261_5),&(v262_7))
            };
            drop(v261_5);
            let v261_9: Space = intersect(&(*CONSTANT_1),&(v261_2));
            drop(v261_2);
            let v261_10: Space = if has_head(&(v261_9)) { singleton(&[]) } else { Space::new() };
            drop(v261_9);
            let v261_12: Space = if (&(v261_10)).is_empty() { Space::new() } else {
              let v263_6: Path = concat_path(&(v260_6),&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
              let v263_11: Space = routine_15(c, &(v263_6), &v252_20_cursor);
              drop(v263_6);
              compose(&(v261_10),&(v263_11))
            };
            drop(v261_10);
            let v261_13: Space = unite(&(v261_8),&(v261_12));
            join_wrapped_into(&mut v260_11_write,&((v261_13).read_zipper()),&[]);
            }
            v252_20_cursor.ascend(1);
          }
          drop(v260_11_write);
          drop(v260_6);
          compose(&(v255_10),&(v260_11))
        };
        drop(v255_10);
        let v255_13: Space = unite(&(v255_8),&(v255_12));
        join_wrapped_into(&mut v254_7_write,&((v255_13).read_zipper()),&[]);
        }
        v252_20_cursor.ascend(1);
      }
      drop(v254_7_write);
      compose(&(v253_5),&(v254_7))
    };
    drop(v253_5);
    let v253_9: Space = intersect(&(*CONSTANT_1),&(v253_2));
    drop(v253_2);
    let v253_10: Space = if has_head(&(v253_9)) { singleton(&[]) } else { Space::new() };
    drop(v253_9);
    let v253_12: Space = if (&(v253_10)).is_empty() { Space::new() } else {
      let v264_6: Path = concat_path(&(*p0),&v252_20_cursor.path()[v252_20_origin..(v252_20_origin + 1)]);
      let mut v264_11 = Space::new();
      let mut v264_11_write = v264_11.write_zipper();
      for v264_11_byte in v252_20_cursor.child_mask().iter() {
        v252_20_cursor.descend_to_existing_byte(v264_11_byte);
        {
        let v265_2: Space = singleton(&v252_20_cursor.path()[(v252_20_origin + 1)..(v252_20_origin + 2)]);
        let v265_3: Space = intersect(&(*CONSTANT_1),&(v265_2));
        let v265_4: Space = if has_head(&(v265_3)) { singleton(&[]) } else { Space::new() };
        drop(v265_3);
        let v265_5: Space = subtract(&(*CONSTANT_0),&(v265_4));
        drop(v265_4);
        let v265_8: Space = if (&(v265_5)).is_empty() { Space::new() } else {
          let v266_6: Path = concat_path(&(v264_6),&v252_20_cursor.path()[(v252_20_origin + 1)..(v252_20_origin + 2)]);
          let mut v266_7 = Space::new();
          let mut v266_7_write = v266_7.write_zipper();
          for v266_7_byte in v252_20_cursor.child_mask().iter() {
            v252_20_cursor.descend_to_existing_byte(v266_7_byte);
            {
            let v267_2: Space = singleton(&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
            let v267_3: Space = intersect(&(*CONSTANT_1),&(v267_2));
            let v267_4: Space = if has_head(&(v267_3)) { singleton(&[]) } else { Space::new() };
            drop(v267_3);
            let v267_5: Space = subtract(&(*CONSTANT_0),&(v267_4));
            drop(v267_4);
            let v267_8: Space = if (&(v267_5)).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v266_6),&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
              let v268_7: Space = routine_28(c, &(v268_6), &v252_20_cursor);
              compose(&(v267_5),&(v268_7))
            };
            drop(v267_5);
            let v267_9: Space = intersect(&(*CONSTANT_1),&(v267_2));
            drop(v267_2);
            let v267_10: Space = if has_head(&(v267_9)) { singleton(&[]) } else { Space::new() };
            drop(v267_9);
            let v267_12: Space = if (&(v267_10)).is_empty() { Space::new() } else {
              let v269_6: Path = concat_path(&(v266_6),&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
              let v269_11: Space = routine_29(c, &(v269_6), &v252_20_cursor);
              drop(v269_6);
              compose(&(v267_10),&(v269_11))
            };
            drop(v267_10);
            let v267_13: Space = unite(&(v267_8),&(v267_12));
            join_wrapped_into(&mut v266_7_write,&((v267_13).read_zipper()),&[]);
            }
            v252_20_cursor.ascend(1);
          }
          drop(v266_7_write);
          drop(v266_6);
          compose(&(v265_5),&(v266_7))
        };
        drop(v265_5);
        let v265_9: Space = intersect(&(*CONSTANT_1),&(v265_2));
        drop(v265_2);
        let v265_10: Space = if has_head(&(v265_9)) { singleton(&[]) } else { Space::new() };
        drop(v265_9);
        let v265_11: Space = compose(&(v265_10),&v252_20_cursor);
        drop(v265_10);
        let v265_12: Space = unite(&(v265_8),&(v265_11));
        drop(v265_11);
        join_wrapped_into(&mut v264_11_write,&((v265_12).read_zipper()),&[]);
        }
        v252_20_cursor.ascend(1);
      }
      drop(v264_11_write);
      drop(v264_6);
      compose(&(v253_10),&(v264_11))
    };
    drop(v253_10);
    let v253_13: Space = unite(&(v253_8),&(v253_12));
    join_wrapped_into(&mut v252_20_write,&((v253_13).read_zipper()),&[]);
    }
    v252_20_cursor.ascend(1);
  }
  drop(v252_20_cursor);
  drop(v252_20_write);
  (v252_20).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v270_14 = Space::new();
  let mut v270_14_write = v270_14.write_zipper();
  let mut v270_14_cursor = (*s0).read_zipper();
  let v270_14_origin = v270_14_cursor.path().len();
  for v270_14_byte in v270_14_cursor.child_mask().iter() {
    v270_14_cursor.descend_to_existing_byte(v270_14_byte);
    {
    let v271_2: Space = singleton(&v270_14_cursor.path()[v270_14_origin..(v270_14_origin + 1)]);
    let v271_3: Space = intersect(&(*CONSTANT_1),&(v271_2));
    let v271_4: Space = if has_head(&(v271_3)) { singleton(&[]) } else { Space::new() };
    drop(v271_3);
    let v271_5: Space = subtract(&(*CONSTANT_0),&(v271_4));
    drop(v271_4);
    let v271_8: Space = if (&(v271_5)).is_empty() { Space::new() } else {
      let v272_6: Path = concat_path(&(*p0),&v270_14_cursor.path()[v270_14_origin..(v270_14_origin + 1)]);
      let mut v272_7 = Space::new();
      let mut v272_7_write = v272_7.write_zipper();
      for v272_7_byte in v270_14_cursor.child_mask().iter() {
        v270_14_cursor.descend_to_existing_byte(v272_7_byte);
        {
        let v273_2: Space = singleton(&v270_14_cursor.path()[(v270_14_origin + 1)..(v270_14_origin + 2)]);
        let v273_3: Space = intersect(&(*CONSTANT_1),&(v273_2));
        let v273_4: Space = if has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
        drop(v273_3);
        let v273_5: Space = subtract(&(*CONSTANT_0),&(v273_4));
        drop(v273_4);
        let v273_8: Space = if (&(v273_5)).is_empty() { Space::new() } else {
          let v274_6: Path = concat_path(&(v272_6),&v270_14_cursor.path()[(v270_14_origin + 1)..(v270_14_origin + 2)]);
          let mut v274_7 = Space::new();
          let mut v274_7_write = v274_7.write_zipper();
          for v274_7_byte in v270_14_cursor.child_mask().iter() {
            v270_14_cursor.descend_to_existing_byte(v274_7_byte);
            {
            let v275_2: Space = singleton(&v270_14_cursor.path()[(v270_14_origin + 2)..(v270_14_origin + 3)]);
            let v275_3: Space = intersect(&(*CONSTANT_1),&(v275_2));
            let v275_4: Space = if has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
            drop(v275_3);
            let v275_5: Space = subtract(&(*CONSTANT_0),&(v275_4));
            drop(v275_4);
            let v275_8: Space = if (&(v275_5)).is_empty() { Space::new() } else {
              let v276_6: Path = concat_path(&(v274_6),&v270_14_cursor.path()[(v270_14_origin + 2)..(v270_14_origin + 3)]);
              let v276_7: Space = routine_28(c, &(v276_6), &v270_14_cursor);
              compose(&(v275_5),&(v276_7))
            };
            drop(v275_5);
            let v275_9: Space = intersect(&(*CONSTANT_1),&(v275_2));
            drop(v275_2);
            let v275_10: Space = if has_head(&(v275_9)) { singleton(&[]) } else { Space::new() };
            drop(v275_9);
            let v275_12: Space = if (&(v275_10)).is_empty() { Space::new() } else {
              let v277_6: Path = concat_path(&(v274_6),&v270_14_cursor.path()[(v270_14_origin + 2)..(v270_14_origin + 3)]);
              let v277_11: Space = routine_29(c, &(v277_6), &v270_14_cursor);
              drop(v277_6);
              compose(&(v275_10),&(v277_11))
            };
            drop(v275_10);
            let v275_13: Space = unite(&(v275_8),&(v275_12));
            join_wrapped_into(&mut v274_7_write,&((v275_13).read_zipper()),&[]);
            }
            v270_14_cursor.ascend(1);
          }
          drop(v274_7_write);
          compose(&(v273_5),&(v274_7))
        };
        drop(v273_5);
        let v273_9: Space = intersect(&(*CONSTANT_1),&(v273_2));
        drop(v273_2);
        let v273_10: Space = if has_head(&(v273_9)) { singleton(&[]) } else { Space::new() };
        drop(v273_9);
        let v273_12: Space = if (&(v273_10)).is_empty() { Space::new() } else {
          let v278_6: Path = concat_path(&(v272_6),&v270_14_cursor.path()[(v270_14_origin + 1)..(v270_14_origin + 2)]);
          let mut v278_11 = Space::new();
          let mut v278_11_write = v278_11.write_zipper();
          for v278_11_byte in v270_14_cursor.child_mask().iter() {
            v270_14_cursor.descend_to_existing_byte(v278_11_byte);
            {
            let v279_2: Space = singleton(&v270_14_cursor.path()[(v270_14_origin + 2)..(v270_14_origin + 3)]);
            let v279_3: Space = intersect(&(*CONSTANT_1),&(v279_2));
            let v279_4: Space = if has_head(&(v279_3)) { singleton(&[]) } else { Space::new() };
            drop(v279_3);
            let v279_5: Space = subtract(&(*CONSTANT_0),&(v279_4));
            drop(v279_4);
            let v279_8: Space = if (&(v279_5)).is_empty() { Space::new() } else {
              let v280_6: Path = concat_path(&(v278_6),&v270_14_cursor.path()[(v270_14_origin + 2)..(v270_14_origin + 3)]);
              let v280_7: Space = routine_28(c, &(v280_6), &v270_14_cursor);
              compose(&(v279_5),&(v280_7))
            };
            drop(v279_5);
            let v279_9: Space = intersect(&(*CONSTANT_1),&(v279_2));
            drop(v279_2);
            let v279_10: Space = if has_head(&(v279_9)) { singleton(&[]) } else { Space::new() };
            drop(v279_9);
            let v279_12: Space = if (&(v279_10)).is_empty() { Space::new() } else {
              let v281_6: Path = concat_path(&(v278_6),&v270_14_cursor.path()[(v270_14_origin + 2)..(v270_14_origin + 3)]);
              let v281_11: Space = routine_15(c, &(v281_6), &v270_14_cursor);
              drop(v281_6);
              compose(&(v279_10),&(v281_11))
            };
            drop(v279_10);
            let v279_13: Space = unite(&(v279_8),&(v279_12));
            join_wrapped_into(&mut v278_11_write,&((v279_13).read_zipper()),&[]);
            }
            v270_14_cursor.ascend(1);
          }
          drop(v278_11_write);
          drop(v278_6);
          compose(&(v273_10),&(v278_11))
        };
        drop(v273_10);
        let v273_13: Space = unite(&(v273_8),&(v273_12));
        join_wrapped_into(&mut v272_7_write,&((v273_13).read_zipper()),&[]);
        }
        v270_14_cursor.ascend(1);
      }
      drop(v272_7_write);
      drop(v272_6);
      compose(&(v271_5),&(v272_7))
    };
    drop(v271_5);
    let v271_9: Space = intersect(&(*CONSTANT_1),&(v271_2));
    drop(v271_2);
    let v271_10: Space = if has_head(&(v271_9)) { singleton(&[]) } else { Space::new() };
    drop(v271_9);
    let v271_11: Space = compose(&(v271_10),&v270_14_cursor);
    drop(v271_10);
    let v271_12: Space = unite(&(v271_8),&(v271_11));
    drop(v271_11);
    join_wrapped_into(&mut v270_14_write,&((v271_12).read_zipper()),&[]);
    }
    v270_14_cursor.ascend(1);
  }
  drop(v270_14_cursor);
  drop(v270_14_write);
  (v270_14).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_16(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v283_20 = Space::new();
  let mut v283_20_write = v283_20.write_zipper();
  let mut v283_20_cursor = (*s0).read_zipper();
  let v283_20_origin = v283_20_cursor.path().len();
  for v283_20_byte in v283_20_cursor.child_mask().iter() {
    v283_20_cursor.descend_to_existing_byte(v283_20_byte);
    {
    let v284_2: Space = singleton(&v283_20_cursor.path()[v283_20_origin..(v283_20_origin + 1)]);
    let v284_3: Space = intersect(&(*CONSTANT_1),&(v284_2));
    let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
    drop(v284_3);
    let v284_5: Space = subtract(&(*CONSTANT_0),&(v284_4));
    drop(v284_4);
    let v284_8: Space = if (&(v284_5)).is_empty() { Space::new() } else {
      let v285_6: Path = concat_path(&(*p0),&v283_20_cursor.path()[v283_20_origin..(v283_20_origin + 1)]);
      let mut v285_7 = Space::new();
      let mut v285_7_write = v285_7.write_zipper();
      for v285_7_byte in v283_20_cursor.child_mask().iter() {
        v283_20_cursor.descend_to_existing_byte(v285_7_byte);
        {
        let v286_2: Space = singleton(&v283_20_cursor.path()[(v283_20_origin + 1)..(v283_20_origin + 2)]);
        let v286_3: Space = intersect(&(*CONSTANT_1),&(v286_2));
        let v286_4: Space = if has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
        drop(v286_3);
        let v286_5: Space = subtract(&(*CONSTANT_0),&(v286_4));
        drop(v286_4);
        let v286_8: Space = if (&(v286_5)).is_empty() { Space::new() } else {
          let v287_6: Path = concat_path(&(v285_6),&v283_20_cursor.path()[(v283_20_origin + 1)..(v283_20_origin + 2)]);
          let mut v287_7 = Space::new();
          let mut v287_7_write = v287_7.write_zipper();
          for v287_7_byte in v283_20_cursor.child_mask().iter() {
            v283_20_cursor.descend_to_existing_byte(v287_7_byte);
            {
            let v288_2: Space = singleton(&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
            let v288_3: Space = intersect(&(*CONSTANT_1),&(v288_2));
            let v288_4: Space = if has_head(&(v288_3)) { singleton(&[]) } else { Space::new() };
            drop(v288_3);
            let v288_5: Space = subtract(&(*CONSTANT_0),&(v288_4));
            drop(v288_4);
            let v288_8: Space = if (&(v288_5)).is_empty() { Space::new() } else {
              let v289_6: Path = concat_path(&(v287_6),&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
              let v289_7: Space = routine_30(c, &(v289_6), &v283_20_cursor);
              compose(&(v288_5),&(v289_7))
            };
            drop(v288_5);
            let v288_9: Space = intersect(&(*CONSTANT_1),&(v288_2));
            drop(v288_2);
            let v288_10: Space = if has_head(&(v288_9)) { singleton(&[]) } else { Space::new() };
            drop(v288_9);
            let v288_12: Space = if (&(v288_10)).is_empty() { Space::new() } else {
              let v290_6: Path = concat_path(&(v287_6),&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
              let v290_11: Space = routine_31(c, &(v290_6), &v283_20_cursor);
              drop(v290_6);
              compose(&(v288_10),&(v290_11))
            };
            drop(v288_10);
            let v288_13: Space = unite(&(v288_8),&(v288_12));
            join_wrapped_into(&mut v287_7_write,&((v288_13).read_zipper()),&[]);
            }
            v283_20_cursor.ascend(1);
          }
          drop(v287_7_write);
          compose(&(v286_5),&(v287_7))
        };
        drop(v286_5);
        let v286_9: Space = intersect(&(*CONSTANT_1),&(v286_2));
        drop(v286_2);
        let v286_10: Space = if has_head(&(v286_9)) { singleton(&[]) } else { Space::new() };
        drop(v286_9);
        let v286_12: Space = if (&(v286_10)).is_empty() { Space::new() } else {
          let v291_6: Path = concat_path(&(v285_6),&v283_20_cursor.path()[(v283_20_origin + 1)..(v283_20_origin + 2)]);
          let mut v291_11 = Space::new();
          let mut v291_11_write = v291_11.write_zipper();
          for v291_11_byte in v283_20_cursor.child_mask().iter() {
            v283_20_cursor.descend_to_existing_byte(v291_11_byte);
            {
            let v292_2: Space = singleton(&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
            let v292_3: Space = intersect(&(*CONSTANT_1),&(v292_2));
            let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
            drop(v292_3);
            let v292_5: Space = subtract(&(*CONSTANT_0),&(v292_4));
            drop(v292_4);
            let v292_8: Space = if (&(v292_5)).is_empty() { Space::new() } else {
              let v293_6: Path = concat_path(&(v291_6),&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
              let v293_7: Space = routine_30(c, &(v293_6), &v283_20_cursor);
              compose(&(v292_5),&(v293_7))
            };
            drop(v292_5);
            let v292_9: Space = intersect(&(*CONSTANT_1),&(v292_2));
            drop(v292_2);
            let v292_10: Space = if has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
            drop(v292_9);
            let v292_12: Space = if (&(v292_10)).is_empty() { Space::new() } else {
              let v294_6: Path = concat_path(&(v291_6),&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
              let v294_11: Space = routine_12(c, &(v294_6), &v283_20_cursor);
              drop(v294_6);
              compose(&(v292_10),&(v294_11))
            };
            drop(v292_10);
            let v292_13: Space = unite(&(v292_8),&(v292_12));
            join_wrapped_into(&mut v291_11_write,&((v292_13).read_zipper()),&[]);
            }
            v283_20_cursor.ascend(1);
          }
          drop(v291_11_write);
          drop(v291_6);
          compose(&(v286_10),&(v291_11))
        };
        drop(v286_10);
        let v286_13: Space = unite(&(v286_8),&(v286_12));
        join_wrapped_into(&mut v285_7_write,&((v286_13).read_zipper()),&[]);
        }
        v283_20_cursor.ascend(1);
      }
      drop(v285_7_write);
      compose(&(v284_5),&(v285_7))
    };
    drop(v284_5);
    let v284_9: Space = intersect(&(*CONSTANT_1),&(v284_2));
    drop(v284_2);
    let v284_10: Space = if has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
    drop(v284_9);
    let v284_12: Space = if (&(v284_10)).is_empty() { Space::new() } else {
      let v295_6: Path = concat_path(&(*p0),&v283_20_cursor.path()[v283_20_origin..(v283_20_origin + 1)]);
      let mut v295_11 = Space::new();
      let mut v295_11_write = v295_11.write_zipper();
      for v295_11_byte in v283_20_cursor.child_mask().iter() {
        v283_20_cursor.descend_to_existing_byte(v295_11_byte);
        {
        let v296_2: Space = singleton(&v283_20_cursor.path()[(v283_20_origin + 1)..(v283_20_origin + 2)]);
        let v296_3: Space = intersect(&(*CONSTANT_1),&(v296_2));
        let v296_4: Space = if has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
        drop(v296_3);
        let v296_5: Space = subtract(&(*CONSTANT_0),&(v296_4));
        drop(v296_4);
        let v296_8: Space = if (&(v296_5)).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v295_6),&v283_20_cursor.path()[(v283_20_origin + 1)..(v283_20_origin + 2)]);
          let mut v297_7 = Space::new();
          let mut v297_7_write = v297_7.write_zipper();
          for v297_7_byte in v283_20_cursor.child_mask().iter() {
            v283_20_cursor.descend_to_existing_byte(v297_7_byte);
            {
            let v298_2: Space = singleton(&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
            let v298_3: Space = intersect(&(*CONSTANT_1),&(v298_2));
            let v298_4: Space = if has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = subtract(&(*CONSTANT_0),&(v298_4));
            drop(v298_4);
            let v298_8: Space = if (&(v298_5)).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v297_6),&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
              let v299_7: Space = routine_30(c, &(v299_6), &v283_20_cursor);
              compose(&(v298_5),&(v299_7))
            };
            drop(v298_5);
            let v298_9: Space = intersect(&(*CONSTANT_1),&(v298_2));
            drop(v298_2);
            let v298_10: Space = if has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
            drop(v298_9);
            let v298_12: Space = if (&(v298_10)).is_empty() { Space::new() } else {
              let v300_6: Path = concat_path(&(v297_6),&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
              let v300_11: Space = routine_31(c, &(v300_6), &v283_20_cursor);
              drop(v300_6);
              compose(&(v298_10),&(v300_11))
            };
            drop(v298_10);
            let v298_13: Space = unite(&(v298_8),&(v298_12));
            join_wrapped_into(&mut v297_7_write,&((v298_13).read_zipper()),&[]);
            }
            v283_20_cursor.ascend(1);
          }
          drop(v297_7_write);
          drop(v297_6);
          compose(&(v296_5),&(v297_7))
        };
        drop(v296_5);
        let v296_9: Space = intersect(&(*CONSTANT_1),&(v296_2));
        drop(v296_2);
        let v296_10: Space = if has_head(&(v296_9)) { singleton(&[]) } else { Space::new() };
        drop(v296_9);
        let v296_11: Space = compose(&(v296_10),&v283_20_cursor);
        drop(v296_10);
        let v296_12: Space = unite(&(v296_8),&(v296_11));
        drop(v296_11);
        join_wrapped_into(&mut v295_11_write,&((v296_12).read_zipper()),&[]);
        }
        v283_20_cursor.ascend(1);
      }
      drop(v295_11_write);
      drop(v295_6);
      compose(&(v284_10),&(v295_11))
    };
    drop(v284_10);
    let v284_13: Space = unite(&(v284_8),&(v284_12));
    join_wrapped_into(&mut v283_20_write,&((v284_13).read_zipper()),&[]);
    }
    v283_20_cursor.ascend(1);
  }
  drop(v283_20_cursor);
  drop(v283_20_write);
  (v283_20).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v301_14 = Space::new();
  let mut v301_14_write = v301_14.write_zipper();
  let mut v301_14_cursor = (*s0).read_zipper();
  let v301_14_origin = v301_14_cursor.path().len();
  for v301_14_byte in v301_14_cursor.child_mask().iter() {
    v301_14_cursor.descend_to_existing_byte(v301_14_byte);
    {
    let v302_2: Space = singleton(&v301_14_cursor.path()[v301_14_origin..(v301_14_origin + 1)]);
    let v302_3: Space = intersect(&(*CONSTANT_1),&(v302_2));
    let v302_4: Space = if has_head(&(v302_3)) { singleton(&[]) } else { Space::new() };
    drop(v302_3);
    let v302_5: Space = subtract(&(*CONSTANT_0),&(v302_4));
    drop(v302_4);
    let v302_8: Space = if (&(v302_5)).is_empty() { Space::new() } else {
      let v303_6: Path = concat_path(&(*p0),&v301_14_cursor.path()[v301_14_origin..(v301_14_origin + 1)]);
      let mut v303_7 = Space::new();
      let mut v303_7_write = v303_7.write_zipper();
      for v303_7_byte in v301_14_cursor.child_mask().iter() {
        v301_14_cursor.descend_to_existing_byte(v303_7_byte);
        {
        let v304_2: Space = singleton(&v301_14_cursor.path()[(v301_14_origin + 1)..(v301_14_origin + 2)]);
        let v304_3: Space = intersect(&(*CONSTANT_1),&(v304_2));
        let v304_4: Space = if has_head(&(v304_3)) { singleton(&[]) } else { Space::new() };
        drop(v304_3);
        let v304_5: Space = subtract(&(*CONSTANT_0),&(v304_4));
        drop(v304_4);
        let v304_8: Space = if (&(v304_5)).is_empty() { Space::new() } else {
          let v305_6: Path = concat_path(&(v303_6),&v301_14_cursor.path()[(v301_14_origin + 1)..(v301_14_origin + 2)]);
          let mut v305_7 = Space::new();
          let mut v305_7_write = v305_7.write_zipper();
          for v305_7_byte in v301_14_cursor.child_mask().iter() {
            v301_14_cursor.descend_to_existing_byte(v305_7_byte);
            {
            let v306_2: Space = singleton(&v301_14_cursor.path()[(v301_14_origin + 2)..(v301_14_origin + 3)]);
            let v306_3: Space = intersect(&(*CONSTANT_1),&(v306_2));
            let v306_4: Space = if has_head(&(v306_3)) { singleton(&[]) } else { Space::new() };
            drop(v306_3);
            let v306_5: Space = subtract(&(*CONSTANT_0),&(v306_4));
            drop(v306_4);
            let v306_8: Space = if (&(v306_5)).is_empty() { Space::new() } else {
              let v307_6: Path = concat_path(&(v305_6),&v301_14_cursor.path()[(v301_14_origin + 2)..(v301_14_origin + 3)]);
              let v307_7: Space = routine_30(c, &(v307_6), &v301_14_cursor);
              compose(&(v306_5),&(v307_7))
            };
            drop(v306_5);
            let v306_9: Space = intersect(&(*CONSTANT_1),&(v306_2));
            drop(v306_2);
            let v306_10: Space = if has_head(&(v306_9)) { singleton(&[]) } else { Space::new() };
            drop(v306_9);
            let v306_12: Space = if (&(v306_10)).is_empty() { Space::new() } else {
              let v308_6: Path = concat_path(&(v305_6),&v301_14_cursor.path()[(v301_14_origin + 2)..(v301_14_origin + 3)]);
              let v308_11: Space = routine_31(c, &(v308_6), &v301_14_cursor);
              drop(v308_6);
              compose(&(v306_10),&(v308_11))
            };
            drop(v306_10);
            let v306_13: Space = unite(&(v306_8),&(v306_12));
            join_wrapped_into(&mut v305_7_write,&((v306_13).read_zipper()),&[]);
            }
            v301_14_cursor.ascend(1);
          }
          drop(v305_7_write);
          compose(&(v304_5),&(v305_7))
        };
        drop(v304_5);
        let v304_9: Space = intersect(&(*CONSTANT_1),&(v304_2));
        drop(v304_2);
        let v304_10: Space = if has_head(&(v304_9)) { singleton(&[]) } else { Space::new() };
        drop(v304_9);
        let v304_12: Space = if (&(v304_10)).is_empty() { Space::new() } else {
          let v309_6: Path = concat_path(&(v303_6),&v301_14_cursor.path()[(v301_14_origin + 1)..(v301_14_origin + 2)]);
          let mut v309_11 = Space::new();
          let mut v309_11_write = v309_11.write_zipper();
          for v309_11_byte in v301_14_cursor.child_mask().iter() {
            v301_14_cursor.descend_to_existing_byte(v309_11_byte);
            {
            let v310_2: Space = singleton(&v301_14_cursor.path()[(v301_14_origin + 2)..(v301_14_origin + 3)]);
            let v310_3: Space = intersect(&(*CONSTANT_1),&(v310_2));
            let v310_4: Space = if has_head(&(v310_3)) { singleton(&[]) } else { Space::new() };
            drop(v310_3);
            let v310_5: Space = subtract(&(*CONSTANT_0),&(v310_4));
            drop(v310_4);
            let v310_8: Space = if (&(v310_5)).is_empty() { Space::new() } else {
              let v311_6: Path = concat_path(&(v309_6),&v301_14_cursor.path()[(v301_14_origin + 2)..(v301_14_origin + 3)]);
              let v311_7: Space = routine_30(c, &(v311_6), &v301_14_cursor);
              compose(&(v310_5),&(v311_7))
            };
            drop(v310_5);
            let v310_9: Space = intersect(&(*CONSTANT_1),&(v310_2));
            drop(v310_2);
            let v310_10: Space = if has_head(&(v310_9)) { singleton(&[]) } else { Space::new() };
            drop(v310_9);
            let v310_12: Space = if (&(v310_10)).is_empty() { Space::new() } else {
              let v312_6: Path = concat_path(&(v309_6),&v301_14_cursor.path()[(v301_14_origin + 2)..(v301_14_origin + 3)]);
              let v312_11: Space = routine_12(c, &(v312_6), &v301_14_cursor);
              drop(v312_6);
              compose(&(v310_10),&(v312_11))
            };
            drop(v310_10);
            let v310_13: Space = unite(&(v310_8),&(v310_12));
            join_wrapped_into(&mut v309_11_write,&((v310_13).read_zipper()),&[]);
            }
            v301_14_cursor.ascend(1);
          }
          drop(v309_11_write);
          drop(v309_6);
          compose(&(v304_10),&(v309_11))
        };
        drop(v304_10);
        let v304_13: Space = unite(&(v304_8),&(v304_12));
        join_wrapped_into(&mut v303_7_write,&((v304_13).read_zipper()),&[]);
        }
        v301_14_cursor.ascend(1);
      }
      drop(v303_7_write);
      drop(v303_6);
      compose(&(v302_5),&(v303_7))
    };
    drop(v302_5);
    let v302_9: Space = intersect(&(*CONSTANT_1),&(v302_2));
    drop(v302_2);
    let v302_10: Space = if has_head(&(v302_9)) { singleton(&[]) } else { Space::new() };
    drop(v302_9);
    let v302_11: Space = compose(&(v302_10),&v301_14_cursor);
    drop(v302_10);
    let v302_12: Space = unite(&(v302_8),&(v302_11));
    drop(v302_11);
    join_wrapped_into(&mut v301_14_write,&((v302_12).read_zipper()),&[]);
    }
    v301_14_cursor.ascend(1);
  }
  drop(v301_14_cursor);
  drop(v301_14_write);
  (v301_14).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v313_20 = Space::new();
  let mut v313_20_write = v313_20.write_zipper();
  let mut v313_20_cursor = (*s0).read_zipper();
  let v313_20_origin = v313_20_cursor.path().len();
  for v313_20_byte in v313_20_cursor.child_mask().iter() {
    v313_20_cursor.descend_to_existing_byte(v313_20_byte);
    {
    let v314_2: Space = singleton(&v313_20_cursor.path()[v313_20_origin..(v313_20_origin + 1)]);
    let v314_3: Space = intersect(&(*CONSTANT_1),&(v314_2));
    let v314_4: Space = if has_head(&(v314_3)) { singleton(&[]) } else { Space::new() };
    drop(v314_3);
    let v314_5: Space = subtract(&(*CONSTANT_0),&(v314_4));
    drop(v314_4);
    let v314_8: Space = if (&(v314_5)).is_empty() { Space::new() } else {
      let v315_6: Path = concat_path(&(*p0),&v313_20_cursor.path()[v313_20_origin..(v313_20_origin + 1)]);
      let mut v315_7 = Space::new();
      let mut v315_7_write = v315_7.write_zipper();
      for v315_7_byte in v313_20_cursor.child_mask().iter() {
        v313_20_cursor.descend_to_existing_byte(v315_7_byte);
        {
        let v316_2: Space = singleton(&v313_20_cursor.path()[(v313_20_origin + 1)..(v313_20_origin + 2)]);
        let v316_3: Space = intersect(&(*CONSTANT_1),&(v316_2));
        let v316_4: Space = if has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
        drop(v316_3);
        let v316_5: Space = subtract(&(*CONSTANT_0),&(v316_4));
        drop(v316_4);
        let v316_8: Space = if (&(v316_5)).is_empty() { Space::new() } else {
          let v317_6: Path = concat_path(&(v315_6),&v313_20_cursor.path()[(v313_20_origin + 1)..(v313_20_origin + 2)]);
          let mut v317_7 = Space::new();
          let mut v317_7_write = v317_7.write_zipper();
          for v317_7_byte in v313_20_cursor.child_mask().iter() {
            v313_20_cursor.descend_to_existing_byte(v317_7_byte);
            {
            let v318_2: Space = singleton(&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
            let v318_3: Space = intersect(&(*CONSTANT_1),&(v318_2));
            let v318_4: Space = if has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
            drop(v318_3);
            let v318_5: Space = subtract(&(*CONSTANT_0),&(v318_4));
            drop(v318_4);
            let v318_8: Space = if (&(v318_5)).is_empty() { Space::new() } else {
              let v319_6: Path = concat_path(&(v317_6),&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
              let v319_7: Space = routine_32(c, &(v319_6), &v313_20_cursor);
              compose(&(v318_5),&(v319_7))
            };
            drop(v318_5);
            let v318_9: Space = intersect(&(*CONSTANT_1),&(v318_2));
            drop(v318_2);
            let v318_10: Space = if has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
            drop(v318_9);
            let v318_12: Space = if (&(v318_10)).is_empty() { Space::new() } else {
              let v320_6: Path = concat_path(&(v317_6),&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
              let v320_11: Space = routine_33(c, &(v320_6), &v313_20_cursor);
              drop(v320_6);
              compose(&(v318_10),&(v320_11))
            };
            drop(v318_10);
            let v318_13: Space = unite(&(v318_8),&(v318_12));
            join_wrapped_into(&mut v317_7_write,&((v318_13).read_zipper()),&[]);
            }
            v313_20_cursor.ascend(1);
          }
          drop(v317_7_write);
          compose(&(v316_5),&(v317_7))
        };
        drop(v316_5);
        let v316_9: Space = intersect(&(*CONSTANT_1),&(v316_2));
        drop(v316_2);
        let v316_10: Space = if has_head(&(v316_9)) { singleton(&[]) } else { Space::new() };
        drop(v316_9);
        let v316_12: Space = if (&(v316_10)).is_empty() { Space::new() } else {
          let v321_6: Path = concat_path(&(v315_6),&v313_20_cursor.path()[(v313_20_origin + 1)..(v313_20_origin + 2)]);
          let mut v321_11 = Space::new();
          let mut v321_11_write = v321_11.write_zipper();
          for v321_11_byte in v313_20_cursor.child_mask().iter() {
            v313_20_cursor.descend_to_existing_byte(v321_11_byte);
            {
            let v322_2: Space = singleton(&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
            let v322_3: Space = intersect(&(*CONSTANT_1),&(v322_2));
            let v322_4: Space = if has_head(&(v322_3)) { singleton(&[]) } else { Space::new() };
            drop(v322_3);
            let v322_5: Space = subtract(&(*CONSTANT_0),&(v322_4));
            drop(v322_4);
            let v322_8: Space = if (&(v322_5)).is_empty() { Space::new() } else {
              let v323_6: Path = concat_path(&(v321_6),&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
              let v323_7: Space = routine_32(c, &(v323_6), &v313_20_cursor);
              compose(&(v322_5),&(v323_7))
            };
            drop(v322_5);
            let v322_9: Space = intersect(&(*CONSTANT_1),&(v322_2));
            drop(v322_2);
            let v322_10: Space = if has_head(&(v322_9)) { singleton(&[]) } else { Space::new() };
            drop(v322_9);
            let v322_12: Space = if (&(v322_10)).is_empty() { Space::new() } else {
              let v324_6: Path = concat_path(&(v321_6),&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
              let v324_11: Space = routine_15(c, &(v324_6), &v313_20_cursor);
              drop(v324_6);
              compose(&(v322_10),&(v324_11))
            };
            drop(v322_10);
            let v322_13: Space = unite(&(v322_8),&(v322_12));
            join_wrapped_into(&mut v321_11_write,&((v322_13).read_zipper()),&[]);
            }
            v313_20_cursor.ascend(1);
          }
          drop(v321_11_write);
          drop(v321_6);
          compose(&(v316_10),&(v321_11))
        };
        drop(v316_10);
        let v316_13: Space = unite(&(v316_8),&(v316_12));
        join_wrapped_into(&mut v315_7_write,&((v316_13).read_zipper()),&[]);
        }
        v313_20_cursor.ascend(1);
      }
      drop(v315_7_write);
      compose(&(v314_5),&(v315_7))
    };
    drop(v314_5);
    let v314_9: Space = intersect(&(*CONSTANT_1),&(v314_2));
    drop(v314_2);
    let v314_10: Space = if has_head(&(v314_9)) { singleton(&[]) } else { Space::new() };
    drop(v314_9);
    let v314_12: Space = if (&(v314_10)).is_empty() { Space::new() } else {
      let v325_6: Path = concat_path(&(*p0),&v313_20_cursor.path()[v313_20_origin..(v313_20_origin + 1)]);
      let mut v325_11 = Space::new();
      let mut v325_11_write = v325_11.write_zipper();
      for v325_11_byte in v313_20_cursor.child_mask().iter() {
        v313_20_cursor.descend_to_existing_byte(v325_11_byte);
        {
        let v326_2: Space = singleton(&v313_20_cursor.path()[(v313_20_origin + 1)..(v313_20_origin + 2)]);
        let v326_3: Space = intersect(&(*CONSTANT_1),&(v326_2));
        let v326_4: Space = if has_head(&(v326_3)) { singleton(&[]) } else { Space::new() };
        drop(v326_3);
        let v326_5: Space = subtract(&(*CONSTANT_0),&(v326_4));
        drop(v326_4);
        let v326_8: Space = if (&(v326_5)).is_empty() { Space::new() } else {
          let v327_6: Path = concat_path(&(v325_6),&v313_20_cursor.path()[(v313_20_origin + 1)..(v313_20_origin + 2)]);
          let mut v327_7 = Space::new();
          let mut v327_7_write = v327_7.write_zipper();
          for v327_7_byte in v313_20_cursor.child_mask().iter() {
            v313_20_cursor.descend_to_existing_byte(v327_7_byte);
            {
            let v328_2: Space = singleton(&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
            let v328_3: Space = intersect(&(*CONSTANT_1),&(v328_2));
            let v328_4: Space = if has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
            drop(v328_3);
            let v328_5: Space = subtract(&(*CONSTANT_0),&(v328_4));
            drop(v328_4);
            let v328_8: Space = if (&(v328_5)).is_empty() { Space::new() } else {
              let v329_6: Path = concat_path(&(v327_6),&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
              let v329_7: Space = routine_32(c, &(v329_6), &v313_20_cursor);
              compose(&(v328_5),&(v329_7))
            };
            drop(v328_5);
            let v328_9: Space = intersect(&(*CONSTANT_1),&(v328_2));
            drop(v328_2);
            let v328_10: Space = if has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
            drop(v328_9);
            let v328_12: Space = if (&(v328_10)).is_empty() { Space::new() } else {
              let v330_6: Path = concat_path(&(v327_6),&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
              let v330_11: Space = routine_33(c, &(v330_6), &v313_20_cursor);
              drop(v330_6);
              compose(&(v328_10),&(v330_11))
            };
            drop(v328_10);
            let v328_13: Space = unite(&(v328_8),&(v328_12));
            join_wrapped_into(&mut v327_7_write,&((v328_13).read_zipper()),&[]);
            }
            v313_20_cursor.ascend(1);
          }
          drop(v327_7_write);
          drop(v327_6);
          compose(&(v326_5),&(v327_7))
        };
        drop(v326_5);
        let v326_9: Space = intersect(&(*CONSTANT_1),&(v326_2));
        drop(v326_2);
        let v326_10: Space = if has_head(&(v326_9)) { singleton(&[]) } else { Space::new() };
        drop(v326_9);
        let v326_11: Space = compose(&(v326_10),&v313_20_cursor);
        drop(v326_10);
        let v326_12: Space = unite(&(v326_8),&(v326_11));
        drop(v326_11);
        join_wrapped_into(&mut v325_11_write,&((v326_12).read_zipper()),&[]);
        }
        v313_20_cursor.ascend(1);
      }
      drop(v325_11_write);
      drop(v325_6);
      compose(&(v314_10),&(v325_11))
    };
    drop(v314_10);
    let v314_13: Space = unite(&(v314_8),&(v314_12));
    join_wrapped_into(&mut v313_20_write,&((v314_13).read_zipper()),&[]);
    }
    v313_20_cursor.ascend(1);
  }
  drop(v313_20_cursor);
  drop(v313_20_write);
  (v313_20).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v331_14 = Space::new();
  let mut v331_14_write = v331_14.write_zipper();
  let mut v331_14_cursor = (*s0).read_zipper();
  let v331_14_origin = v331_14_cursor.path().len();
  for v331_14_byte in v331_14_cursor.child_mask().iter() {
    v331_14_cursor.descend_to_existing_byte(v331_14_byte);
    {
    let v332_2: Space = singleton(&v331_14_cursor.path()[v331_14_origin..(v331_14_origin + 1)]);
    let v332_3: Space = intersect(&(*CONSTANT_1),&(v332_2));
    let v332_4: Space = if has_head(&(v332_3)) { singleton(&[]) } else { Space::new() };
    drop(v332_3);
    let v332_5: Space = subtract(&(*CONSTANT_0),&(v332_4));
    drop(v332_4);
    let v332_8: Space = if (&(v332_5)).is_empty() { Space::new() } else {
      let v333_6: Path = concat_path(&(*p0),&v331_14_cursor.path()[v331_14_origin..(v331_14_origin + 1)]);
      let mut v333_7 = Space::new();
      let mut v333_7_write = v333_7.write_zipper();
      for v333_7_byte in v331_14_cursor.child_mask().iter() {
        v331_14_cursor.descend_to_existing_byte(v333_7_byte);
        {
        let v334_2: Space = singleton(&v331_14_cursor.path()[(v331_14_origin + 1)..(v331_14_origin + 2)]);
        let v334_3: Space = intersect(&(*CONSTANT_1),&(v334_2));
        let v334_4: Space = if has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
        drop(v334_3);
        let v334_5: Space = subtract(&(*CONSTANT_0),&(v334_4));
        drop(v334_4);
        let v334_8: Space = if (&(v334_5)).is_empty() { Space::new() } else {
          let v335_6: Path = concat_path(&(v333_6),&v331_14_cursor.path()[(v331_14_origin + 1)..(v331_14_origin + 2)]);
          let mut v335_7 = Space::new();
          let mut v335_7_write = v335_7.write_zipper();
          for v335_7_byte in v331_14_cursor.child_mask().iter() {
            v331_14_cursor.descend_to_existing_byte(v335_7_byte);
            {
            let v336_2: Space = singleton(&v331_14_cursor.path()[(v331_14_origin + 2)..(v331_14_origin + 3)]);
            let v336_3: Space = intersect(&(*CONSTANT_1),&(v336_2));
            let v336_4: Space = if has_head(&(v336_3)) { singleton(&[]) } else { Space::new() };
            drop(v336_3);
            let v336_5: Space = subtract(&(*CONSTANT_0),&(v336_4));
            drop(v336_4);
            let v336_8: Space = if (&(v336_5)).is_empty() { Space::new() } else {
              let v337_6: Path = concat_path(&(v335_6),&v331_14_cursor.path()[(v331_14_origin + 2)..(v331_14_origin + 3)]);
              let v337_7: Space = routine_32(c, &(v337_6), &v331_14_cursor);
              compose(&(v336_5),&(v337_7))
            };
            drop(v336_5);
            let v336_9: Space = intersect(&(*CONSTANT_1),&(v336_2));
            drop(v336_2);
            let v336_10: Space = if has_head(&(v336_9)) { singleton(&[]) } else { Space::new() };
            drop(v336_9);
            let v336_12: Space = if (&(v336_10)).is_empty() { Space::new() } else {
              let v338_6: Path = concat_path(&(v335_6),&v331_14_cursor.path()[(v331_14_origin + 2)..(v331_14_origin + 3)]);
              let v338_11: Space = routine_33(c, &(v338_6), &v331_14_cursor);
              drop(v338_6);
              compose(&(v336_10),&(v338_11))
            };
            drop(v336_10);
            let v336_13: Space = unite(&(v336_8),&(v336_12));
            join_wrapped_into(&mut v335_7_write,&((v336_13).read_zipper()),&[]);
            }
            v331_14_cursor.ascend(1);
          }
          drop(v335_7_write);
          compose(&(v334_5),&(v335_7))
        };
        drop(v334_5);
        let v334_9: Space = intersect(&(*CONSTANT_1),&(v334_2));
        drop(v334_2);
        let v334_10: Space = if has_head(&(v334_9)) { singleton(&[]) } else { Space::new() };
        drop(v334_9);
        let v334_12: Space = if (&(v334_10)).is_empty() { Space::new() } else {
          let v339_6: Path = concat_path(&(v333_6),&v331_14_cursor.path()[(v331_14_origin + 1)..(v331_14_origin + 2)]);
          let mut v339_11 = Space::new();
          let mut v339_11_write = v339_11.write_zipper();
          for v339_11_byte in v331_14_cursor.child_mask().iter() {
            v331_14_cursor.descend_to_existing_byte(v339_11_byte);
            {
            let v340_2: Space = singleton(&v331_14_cursor.path()[(v331_14_origin + 2)..(v331_14_origin + 3)]);
            let v340_3: Space = intersect(&(*CONSTANT_1),&(v340_2));
            let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
            drop(v340_3);
            let v340_5: Space = subtract(&(*CONSTANT_0),&(v340_4));
            drop(v340_4);
            let v340_8: Space = if (&(v340_5)).is_empty() { Space::new() } else {
              let v341_6: Path = concat_path(&(v339_6),&v331_14_cursor.path()[(v331_14_origin + 2)..(v331_14_origin + 3)]);
              let v341_7: Space = routine_32(c, &(v341_6), &v331_14_cursor);
              compose(&(v340_5),&(v341_7))
            };
            drop(v340_5);
            let v340_9: Space = intersect(&(*CONSTANT_1),&(v340_2));
            drop(v340_2);
            let v340_10: Space = if has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
            drop(v340_9);
            let v340_12: Space = if (&(v340_10)).is_empty() { Space::new() } else {
              let v342_6: Path = concat_path(&(v339_6),&v331_14_cursor.path()[(v331_14_origin + 2)..(v331_14_origin + 3)]);
              let v342_11: Space = routine_15(c, &(v342_6), &v331_14_cursor);
              drop(v342_6);
              compose(&(v340_10),&(v342_11))
            };
            drop(v340_10);
            let v340_13: Space = unite(&(v340_8),&(v340_12));
            join_wrapped_into(&mut v339_11_write,&((v340_13).read_zipper()),&[]);
            }
            v331_14_cursor.ascend(1);
          }
          drop(v339_11_write);
          drop(v339_6);
          compose(&(v334_10),&(v339_11))
        };
        drop(v334_10);
        let v334_13: Space = unite(&(v334_8),&(v334_12));
        join_wrapped_into(&mut v333_7_write,&((v334_13).read_zipper()),&[]);
        }
        v331_14_cursor.ascend(1);
      }
      drop(v333_7_write);
      drop(v333_6);
      compose(&(v332_5),&(v333_7))
    };
    drop(v332_5);
    let v332_9: Space = intersect(&(*CONSTANT_1),&(v332_2));
    drop(v332_2);
    let v332_10: Space = if has_head(&(v332_9)) { singleton(&[]) } else { Space::new() };
    drop(v332_9);
    let v332_11: Space = compose(&(v332_10),&v331_14_cursor);
    drop(v332_10);
    let v332_12: Space = unite(&(v332_8),&(v332_11));
    drop(v332_11);
    join_wrapped_into(&mut v331_14_write,&((v332_12).read_zipper()),&[]);
    }
    v331_14_cursor.ascend(1);
  }
  drop(v331_14_cursor);
  drop(v331_14_write);
  (v331_14).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v343_20 = Space::new();
  let mut v343_20_write = v343_20.write_zipper();
  let mut v343_20_cursor = (*s0).read_zipper();
  let v343_20_origin = v343_20_cursor.path().len();
  for v343_20_byte in v343_20_cursor.child_mask().iter() {
    v343_20_cursor.descend_to_existing_byte(v343_20_byte);
    {
    let v344_2: Space = singleton(&v343_20_cursor.path()[v343_20_origin..(v343_20_origin + 1)]);
    let v344_3: Space = intersect(&(*CONSTANT_1),&(v344_2));
    let v344_4: Space = if has_head(&(v344_3)) { singleton(&[]) } else { Space::new() };
    drop(v344_3);
    let v344_5: Space = subtract(&(*CONSTANT_0),&(v344_4));
    drop(v344_4);
    let v344_7: Space = if (&(v344_5)).is_empty() { Space::new() } else {
      let mut v345_6 = Space::new();
      let mut v345_6_write = v345_6.write_zipper();
      for v345_6_byte in v343_20_cursor.child_mask().iter() {
        v343_20_cursor.descend_to_existing_byte(v345_6_byte);
        {
        let v346_2: Space = Space::new();
        join_wrapped_into(&mut v345_6_write,&((v346_2).read_zipper()),&[]);
        }
        v343_20_cursor.ascend(1);
      }
      drop(v345_6_write);
      compose(&(v344_5),&(v345_6))
    };
    drop(v344_5);
    let v344_8: Space = intersect(&(*CONSTANT_1),&(v344_2));
    drop(v344_2);
    let v344_9: Space = if has_head(&(v344_8)) { singleton(&[]) } else { Space::new() };
    drop(v344_8);
    let v344_13: Space = if (&(v344_9)).is_empty() { Space::new() } else {
      let v347_11: Path = concat_path(&(*p0),&v343_20_cursor.path()[v343_20_origin..(v343_20_origin + 1)]);
      let mut v347_12 = Space::new();
      let mut v347_12_write = v347_12.write_zipper();
      for v347_12_byte in v343_20_cursor.child_mask().iter() {
        v343_20_cursor.descend_to_existing_byte(v347_12_byte);
        {
        let v348_2: Space = singleton(&v343_20_cursor.path()[(v343_20_origin + 1)..(v343_20_origin + 2)]);
        let v348_3: Space = intersect(&(*CONSTANT_1),&(v348_2));
        drop(v348_2);
        let v348_4: Space = if has_head(&(v348_3)) { singleton(&[]) } else { Space::new() };
        drop(v348_3);
        let v348_12: Space = if (&(v348_4)).is_empty() { Space::new() } else {
          let v349_6: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v343_20_cursor.path()[v343_20_origin..(v343_20_origin + 1)]),&v343_20_cursor.path()[(v343_20_origin + 1)..(v343_20_origin + 2)])));
          let mut v349_7 = Space::new();
          let mut v349_7_write = v349_7.write_zipper();
          let mut v349_7_cursor = (v349_6).read_zipper();
          let v349_7_origin = v349_7_cursor.path().len();
          for v349_7_byte in v349_7_cursor.child_mask().iter() {
            v349_7_cursor.descend_to_existing_byte(v349_7_byte);
            {
            let v350_2: Space = singleton(&v349_7_cursor.path()[v349_7_origin..(v349_7_origin + 1)]);
            let v350_3: Space = intersect(&(*CONSTANT_1),&(v350_2));
            let v350_4: Space = if has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
            drop(v350_3);
            let v350_5: Space = subtract(&(*CONSTANT_0),&(v350_4));
            drop(v350_4);
            let v350_7: Space = if (&(v350_5)).is_empty() { Space::new() } else {
              let v351_6: Space = routine_6(c, &v349_7_cursor.path()[v349_7_origin..(v349_7_origin + 1)], &v349_7_cursor);
              compose(&(v350_5),&(v351_6))
            };
            drop(v350_5);
            let v350_8: Space = intersect(&(*CONSTANT_1),&(v350_2));
            drop(v350_2);
            let v350_9: Space = if has_head(&(v350_8)) { singleton(&[]) } else { Space::new() };
            drop(v350_8);
            let v350_11: Space = if (&(v350_9)).is_empty() { Space::new() } else {
              let v352_10: Space = routine_7(c, &v349_7_cursor.path()[v349_7_origin..(v349_7_origin + 1)], &v349_7_cursor);
              compose(&(v350_9),&(v352_10))
            };
            drop(v350_9);
            let v350_12: Space = unite(&(v350_7),&(v350_11));
            join_wrapped_into(&mut v349_7_write,&((v350_12).read_zipper()),&[]);
            }
            v349_7_cursor.ascend(1);
          }
          drop(v349_7_cursor);
          drop(v349_7_write);
          drop(v349_6);
          let v349_8: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v349_7));
          let mut v349_9 = Space::new();
          let mut v349_9_write = v349_9.write_zipper();
          let mut v349_9_cursor = (v349_8).read_zipper();
          let v349_9_origin = v349_9_cursor.path().len();
          for v349_9_byte in v349_9_cursor.child_mask().iter() {
            v349_9_cursor.descend_to_existing_byte(v349_9_byte);
            {
            let v353_2: Space = singleton(&v349_9_cursor.path()[v349_9_origin..(v349_9_origin + 1)]);
            let v353_3: Space = intersect(&(*CONSTANT_1),&(v353_2));
            let v353_4: Space = if has_head(&(v353_3)) { singleton(&[]) } else { Space::new() };
            drop(v353_3);
            let v353_5: Space = subtract(&(*CONSTANT_0),&(v353_4));
            drop(v353_4);
            let v353_7: Space = if (&(v353_5)).is_empty() { Space::new() } else {
              let v354_6: Space = routine_8(c, &v349_9_cursor.path()[v349_9_origin..(v349_9_origin + 1)], &v349_9_cursor);
              compose(&(v353_5),&(v354_6))
            };
            drop(v353_5);
            let v353_8: Space = intersect(&(*CONSTANT_1),&(v353_2));
            drop(v353_2);
            let v353_9: Space = if has_head(&(v353_8)) { singleton(&[]) } else { Space::new() };
            drop(v353_8);
            let v353_11: Space = if (&(v353_9)).is_empty() { Space::new() } else {
              let v355_10: Space = routine_9(c, &v349_9_cursor.path()[v349_9_origin..(v349_9_origin + 1)], &v349_9_cursor);
              compose(&(v353_9),&(v355_10))
            };
            drop(v353_9);
            let v353_12: Space = unite(&(v353_7),&(v353_11));
            join_wrapped_into(&mut v349_9_write,&((v353_12).read_zipper()),&[]);
            }
            v349_9_cursor.ascend(1);
          }
          drop(v349_9_cursor);
          drop(v349_9_write);
          let v349_10: Space = subtract(&(v349_9),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v343_20_cursor.path()[v343_20_origin..(v343_20_origin + 1)]),&v343_20_cursor.path()[(v343_20_origin + 1)..(v343_20_origin + 2)])));
          let v349_11: Space = intersect(&(v349_10),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
          compose(&(v348_4),&(v349_11))
        };
        drop(v348_4);
        let v348_13: Path = concat_path(&(v347_11),&v343_20_cursor.path()[(v343_20_origin + 1)..(v343_20_origin + 2)]);
        join_wrapped_into(&mut v347_12_write,&((v348_12).read_zipper()),&(v348_13));
        drop(v348_13);
        }
        v343_20_cursor.ascend(1);
      }
      drop(v347_12_write);
      drop(v347_11);
      compose(&(v344_9),&(v347_12))
    };
    drop(v344_9);
    let v344_14: Space = unite(&(v344_7),&(v344_13));
    drop(v344_7);
    join_wrapped_into(&mut v343_20_write,&((v344_14).read_zipper()),&[]);
    }
    v343_20_cursor.ascend(1);
  }
  drop(v343_20_cursor);
  drop(v343_20_write);
  (v343_20).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v356_31 = Space::new();
  let mut v356_31_write = v356_31.write_zipper();
  let mut v356_31_cursor = (*s0).read_zipper();
  let v356_31_origin = v356_31_cursor.path().len();
  for v356_31_byte in v356_31_cursor.child_mask().iter() {
    v356_31_cursor.descend_to_existing_byte(v356_31_byte);
    {
    let v357_2: Space = singleton(&v356_31_cursor.path()[v356_31_origin..(v356_31_origin + 1)]);
    let v357_3: Space = intersect(&(*CONSTANT_1),&(v357_2));
    let v357_4: Space = if has_head(&(v357_3)) { singleton(&[]) } else { Space::new() };
    drop(v357_3);
    let v357_5: Space = subtract(&(*CONSTANT_0),&(v357_4));
    drop(v357_4);
    let v357_7: Space = if (&(v357_5)).is_empty() { Space::new() } else {
      let mut v358_6 = Space::new();
      let mut v358_6_write = v358_6.write_zipper();
      for v358_6_byte in v356_31_cursor.child_mask().iter() {
        v356_31_cursor.descend_to_existing_byte(v358_6_byte);
        {
        let v359_2: Space = Space::new();
        join_wrapped_into(&mut v358_6_write,&((v359_2).read_zipper()),&[]);
        }
        v356_31_cursor.ascend(1);
      }
      drop(v358_6_write);
      compose(&(v357_5),&(v358_6))
    };
    drop(v357_5);
    let v357_8: Space = intersect(&(*CONSTANT_1),&(v357_2));
    drop(v357_2);
    let v357_9: Space = if has_head(&(v357_8)) { singleton(&[]) } else { Space::new() };
    drop(v357_8);
    let v357_17: Space = if (&(v357_9)).is_empty() { Space::new() } else {
      let v360_11: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v356_31_cursor.path()[v356_31_origin..(v356_31_origin + 1)])));
      let mut v360_12 = Space::new();
      let mut v360_12_write = v360_12.write_zipper();
      let mut v360_12_cursor = (v360_11).read_zipper();
      let v360_12_origin = v360_12_cursor.path().len();
      for v360_12_byte in v360_12_cursor.child_mask().iter() {
        v360_12_cursor.descend_to_existing_byte(v360_12_byte);
        {
        let v361_2: Space = singleton(&v360_12_cursor.path()[v360_12_origin..(v360_12_origin + 1)]);
        let v361_3: Space = intersect(&(*CONSTANT_1),&(v361_2));
        let v361_4: Space = if has_head(&(v361_3)) { singleton(&[]) } else { Space::new() };
        drop(v361_3);
        let v361_5: Space = subtract(&(*CONSTANT_0),&(v361_4));
        drop(v361_4);
        let v361_7: Space = if (&(v361_5)).is_empty() { Space::new() } else {
          let mut v362_6 = Space::new();
          let mut v362_6_write = v362_6.write_zipper();
          for v362_6_byte in v360_12_cursor.child_mask().iter() {
            v360_12_cursor.descend_to_existing_byte(v362_6_byte);
            {
            let v363_2: Space = singleton(&v360_12_cursor.path()[(v360_12_origin + 1)..(v360_12_origin + 2)]);
            let v363_3: Space = intersect(&(*CONSTANT_1),&(v363_2));
            let v363_4: Space = if has_head(&(v363_3)) { singleton(&[]) } else { Space::new() };
            drop(v363_3);
            let v363_5: Space = subtract(&(*CONSTANT_0),&(v363_4));
            drop(v363_4);
            let v363_8: Space = if (&(v363_5)).is_empty() { Space::new() } else {
              let v364_7: Space = routine_10(c, &v360_12_cursor.path()[v360_12_origin..(v360_12_origin + 2)], &v360_12_cursor);
              compose(&(v363_5),&(v364_7))
            };
            drop(v363_5);
            let v363_9: Space = intersect(&(*CONSTANT_1),&(v363_2));
            drop(v363_2);
            let v363_10: Space = if has_head(&(v363_9)) { singleton(&[]) } else { Space::new() };
            drop(v363_9);
            let v363_12: Space = if (&(v363_10)).is_empty() { Space::new() } else {
              let v365_11: Space = routine_11(c, &v360_12_cursor.path()[v360_12_origin..(v360_12_origin + 2)], &v360_12_cursor);
              compose(&(v363_10),&(v365_11))
            };
            drop(v363_10);
            let v363_13: Space = unite(&(v363_8),&(v363_12));
            join_wrapped_into(&mut v362_6_write,&((v363_13).read_zipper()),&[]);
            }
            v360_12_cursor.ascend(1);
          }
          drop(v362_6_write);
          compose(&(v361_5),&(v362_6))
        };
        drop(v361_5);
        let v361_8: Space = intersect(&(*CONSTANT_1),&(v361_2));
        drop(v361_2);
        let v361_9: Space = if has_head(&(v361_8)) { singleton(&[]) } else { Space::new() };
        drop(v361_8);
        let v361_11: Space = if (&(v361_9)).is_empty() { Space::new() } else {
          let mut v366_10 = Space::new();
          let mut v366_10_write = v366_10.write_zipper();
          for v366_10_byte in v360_12_cursor.child_mask().iter() {
            v360_12_cursor.descend_to_existing_byte(v366_10_byte);
            {
            let v367_2: Space = singleton(&v360_12_cursor.path()[(v360_12_origin + 1)..(v360_12_origin + 2)]);
            let v367_3: Space = intersect(&(*CONSTANT_1),&(v367_2));
            let v367_4: Space = if has_head(&(v367_3)) { singleton(&[]) } else { Space::new() };
            drop(v367_3);
            let v367_5: Space = subtract(&(*CONSTANT_0),&(v367_4));
            drop(v367_4);
            let v367_8: Space = if (&(v367_5)).is_empty() { Space::new() } else {
              let v368_7: Space = routine_10(c, &v360_12_cursor.path()[v360_12_origin..(v360_12_origin + 2)], &v360_12_cursor);
              compose(&(v367_5),&(v368_7))
            };
            drop(v367_5);
            let v367_9: Space = intersect(&(*CONSTANT_1),&(v367_2));
            drop(v367_2);
            let v367_10: Space = if has_head(&(v367_9)) { singleton(&[]) } else { Space::new() };
            drop(v367_9);
            let v367_12: Space = if (&(v367_10)).is_empty() { Space::new() } else {
              let v369_11: Space = routine_12(c, &v360_12_cursor.path()[v360_12_origin..(v360_12_origin + 2)], &v360_12_cursor);
              compose(&(v367_10),&(v369_11))
            };
            drop(v367_10);
            let v367_13: Space = unite(&(v367_8),&(v367_12));
            join_wrapped_into(&mut v366_10_write,&((v367_13).read_zipper()),&[]);
            }
            v360_12_cursor.ascend(1);
          }
          drop(v366_10_write);
          compose(&(v361_9),&(v366_10))
        };
        drop(v361_9);
        let v361_12: Space = unite(&(v361_7),&(v361_11));
        join_wrapped_into(&mut v360_12_write,&((v361_12).read_zipper()),&[]);
        }
        v360_12_cursor.ascend(1);
      }
      drop(v360_12_cursor);
      drop(v360_12_write);
      drop(v360_11);
      let v360_13: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v360_12));
      let mut v360_14 = Space::new();
      let mut v360_14_write = v360_14.write_zipper();
      let mut v360_14_cursor = (v360_13).read_zipper();
      let v360_14_origin = v360_14_cursor.path().len();
      for v360_14_byte in v360_14_cursor.child_mask().iter() {
        v360_14_cursor.descend_to_existing_byte(v360_14_byte);
        {
        let v370_2: Space = singleton(&v360_14_cursor.path()[v360_14_origin..(v360_14_origin + 1)]);
        let v370_3: Space = intersect(&(*CONSTANT_1),&(v370_2));
        let v370_4: Space = if has_head(&(v370_3)) { singleton(&[]) } else { Space::new() };
        drop(v370_3);
        let v370_5: Space = subtract(&(*CONSTANT_0),&(v370_4));
        drop(v370_4);
        let v370_7: Space = if (&(v370_5)).is_empty() { Space::new() } else {
          let mut v371_6 = Space::new();
          let mut v371_6_write = v371_6.write_zipper();
          for v371_6_byte in v360_14_cursor.child_mask().iter() {
            v360_14_cursor.descend_to_existing_byte(v371_6_byte);
            {
            let v372_2: Space = singleton(&v360_14_cursor.path()[(v360_14_origin + 1)..(v360_14_origin + 2)]);
            let v372_3: Space = intersect(&(*CONSTANT_1),&(v372_2));
            let v372_4: Space = if has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
            drop(v372_3);
            let v372_5: Space = subtract(&(*CONSTANT_0),&(v372_4));
            drop(v372_4);
            let v372_8: Space = if (&(v372_5)).is_empty() { Space::new() } else {
              let v373_7: Space = routine_13(c, &v360_14_cursor.path()[v360_14_origin..(v360_14_origin + 2)], &v360_14_cursor);
              compose(&(v372_5),&(v373_7))
            };
            drop(v372_5);
            let v372_9: Space = intersect(&(*CONSTANT_1),&(v372_2));
            drop(v372_2);
            let v372_10: Space = if has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
            drop(v372_9);
            let v372_12: Space = if (&(v372_10)).is_empty() { Space::new() } else {
              let v374_11: Space = routine_14(c, &v360_14_cursor.path()[v360_14_origin..(v360_14_origin + 2)], &v360_14_cursor);
              compose(&(v372_10),&(v374_11))
            };
            drop(v372_10);
            let v372_13: Space = unite(&(v372_8),&(v372_12));
            join_wrapped_into(&mut v371_6_write,&((v372_13).read_zipper()),&[]);
            }
            v360_14_cursor.ascend(1);
          }
          drop(v371_6_write);
          compose(&(v370_5),&(v371_6))
        };
        drop(v370_5);
        let v370_8: Space = intersect(&(*CONSTANT_1),&(v370_2));
        drop(v370_2);
        let v370_9: Space = if has_head(&(v370_8)) { singleton(&[]) } else { Space::new() };
        drop(v370_8);
        let v370_11: Space = if (&(v370_9)).is_empty() { Space::new() } else {
          let mut v375_10 = Space::new();
          let mut v375_10_write = v375_10.write_zipper();
          for v375_10_byte in v360_14_cursor.child_mask().iter() {
            v360_14_cursor.descend_to_existing_byte(v375_10_byte);
            {
            let v376_2: Space = singleton(&v360_14_cursor.path()[(v360_14_origin + 1)..(v360_14_origin + 2)]);
            let v376_3: Space = intersect(&(*CONSTANT_1),&(v376_2));
            let v376_4: Space = if has_head(&(v376_3)) { singleton(&[]) } else { Space::new() };
            drop(v376_3);
            let v376_5: Space = subtract(&(*CONSTANT_0),&(v376_4));
            drop(v376_4);
            let v376_8: Space = if (&(v376_5)).is_empty() { Space::new() } else {
              let v377_7: Space = routine_13(c, &v360_14_cursor.path()[v360_14_origin..(v360_14_origin + 2)], &v360_14_cursor);
              compose(&(v376_5),&(v377_7))
            };
            drop(v376_5);
            let v376_9: Space = intersect(&(*CONSTANT_1),&(v376_2));
            drop(v376_2);
            let v376_10: Space = if has_head(&(v376_9)) { singleton(&[]) } else { Space::new() };
            drop(v376_9);
            let v376_12: Space = if (&(v376_10)).is_empty() { Space::new() } else {
              let v378_11: Space = routine_15(c, &v360_14_cursor.path()[v360_14_origin..(v360_14_origin + 2)], &v360_14_cursor);
              compose(&(v376_10),&(v378_11))
            };
            drop(v376_10);
            let v376_13: Space = unite(&(v376_8),&(v376_12));
            join_wrapped_into(&mut v375_10_write,&((v376_13).read_zipper()),&[]);
            }
            v360_14_cursor.ascend(1);
          }
          drop(v375_10_write);
          compose(&(v370_9),&(v375_10))
        };
        drop(v370_9);
        let v370_12: Space = unite(&(v370_7),&(v370_11));
        join_wrapped_into(&mut v360_14_write,&((v370_12).read_zipper()),&[]);
        }
        v360_14_cursor.ascend(1);
      }
      drop(v360_14_cursor);
      drop(v360_14_write);
      let v360_15: Space = subtract(&(v360_14),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v356_31_cursor.path()[v356_31_origin..(v356_31_origin + 1)])));
      let v360_16: Space = intersect(&(v360_15),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
      compose(&(v357_9),&(v360_16))
    };
    drop(v357_9);
    let v357_18: Path = concat_path(&(*p0),&v356_31_cursor.path()[v356_31_origin..(v356_31_origin + 1)]);
    let v357_19: Space = wrap(&(v357_17),&(v357_18));
    drop(v357_18);
    let v357_20: Space = unite(&(v357_7),&(v357_19));
    drop(v357_7);
    join_wrapped_into(&mut v356_31_write,&((v357_20).read_zipper()),&[]);
    }
    v356_31_cursor.ascend(1);
  }
  drop(v356_31_cursor);
  drop(v356_31_write);
  (v356_31).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v379_20 = Space::new();
  let mut v379_20_write = v379_20.write_zipper();
  let mut v379_20_cursor = (*s0).read_zipper();
  let v379_20_origin = v379_20_cursor.path().len();
  for v379_20_byte in v379_20_cursor.child_mask().iter() {
    v379_20_cursor.descend_to_existing_byte(v379_20_byte);
    {
    let v380_2: Space = singleton(&v379_20_cursor.path()[v379_20_origin..(v379_20_origin + 1)]);
    let v380_3: Space = intersect(&(*CONSTANT_1),&(v380_2));
    let v380_4: Space = if has_head(&(v380_3)) { singleton(&[]) } else { Space::new() };
    drop(v380_3);
    let v380_5: Space = subtract(&(*CONSTANT_0),&(v380_4));
    drop(v380_4);
    let v380_8: Space = if (&(v380_5)).is_empty() { Space::new() } else {
      let v381_6: Path = concat_path(&(*p0),&v379_20_cursor.path()[v379_20_origin..(v379_20_origin + 1)]);
      let mut v381_7 = Space::new();
      let mut v381_7_write = v381_7.write_zipper();
      for v381_7_byte in v379_20_cursor.child_mask().iter() {
        v379_20_cursor.descend_to_existing_byte(v381_7_byte);
        {
        let v382_2: Space = singleton(&v379_20_cursor.path()[(v379_20_origin + 1)..(v379_20_origin + 2)]);
        let v382_3: Space = intersect(&(*CONSTANT_1),&(v382_2));
        let v382_4: Space = if has_head(&(v382_3)) { singleton(&[]) } else { Space::new() };
        drop(v382_3);
        let v382_5: Space = subtract(&(*CONSTANT_0),&(v382_4));
        drop(v382_4);
        let v382_8: Space = if (&(v382_5)).is_empty() { Space::new() } else {
          let v383_6: Path = concat_path(&(v381_6),&v379_20_cursor.path()[(v379_20_origin + 1)..(v379_20_origin + 2)]);
          let mut v383_7 = Space::new();
          let mut v383_7_write = v383_7.write_zipper();
          for v383_7_byte in v379_20_cursor.child_mask().iter() {
            v379_20_cursor.descend_to_existing_byte(v383_7_byte);
            {
            let v384_2: Space = singleton(&v379_20_cursor.path()[(v379_20_origin + 2)..(v379_20_origin + 3)]);
            let v384_3: Space = intersect(&(*CONSTANT_1),&(v384_2));
            let v384_4: Space = if has_head(&(v384_3)) { singleton(&[]) } else { Space::new() };
            drop(v384_3);
            let v384_5: Space = subtract(&(*CONSTANT_0),&(v384_4));
            drop(v384_4);
            let v384_8: Space = if (&(v384_5)).is_empty() { Space::new() } else {
              let v385_6: Path = concat_path(&(v383_6),&v379_20_cursor.path()[(v379_20_origin + 2)..(v379_20_origin + 3)]);
              let v385_7: Space = routine_34(c, &(v385_6), &v379_20_cursor);
              compose(&(v384_5),&(v385_7))
            };
            drop(v384_5);
            let v384_9: Space = intersect(&(*CONSTANT_1),&(v384_2));
            drop(v384_2);
            let v384_10: Space = if has_head(&(v384_9)) { singleton(&[]) } else { Space::new() };
            drop(v384_9);
            let v384_12: Space = if (&(v384_10)).is_empty() { Space::new() } else {
              let v386_6: Path = concat_path(&(v383_6),&v379_20_cursor.path()[(v379_20_origin + 2)..(v379_20_origin + 3)]);
              let v386_11: Space = routine_35(c, &(v386_6), &v379_20_cursor);
              drop(v386_6);
              compose(&(v384_10),&(v386_11))
            };
            drop(v384_10);
            let v384_13: Space = unite(&(v384_8),&(v384_12));
            join_wrapped_into(&mut v383_7_write,&((v384_13).read_zipper()),&[]);
            }
            v379_20_cursor.ascend(1);
          }
          drop(v383_7_write);
          compose(&(v382_5),&(v383_7))
        };
        drop(v382_5);
        let v382_9: Space = intersect(&(*CONSTANT_1),&(v382_2));
        drop(v382_2);
        let v382_10: Space = if has_head(&(v382_9)) { singleton(&[]) } else { Space::new() };
        drop(v382_9);
        let v382_12: Space = if (&(v382_10)).is_empty() { Space::new() } else {
          let v387_6: Path = concat_path(&(v381_6),&v379_20_cursor.path()[(v379_20_origin + 1)..(v379_20_origin + 2)]);
          let mut v387_11 = Space::new();
          let mut v387_11_write = v387_11.write_zipper();
          for v387_11_byte in v379_20_cursor.child_mask().iter() {
            v379_20_cursor.descend_to_existing_byte(v387_11_byte);
            {
            let v388_2: Space = singleton(&v379_20_cursor.path()[(v379_20_origin + 2)..(v379_20_origin + 3)]);
            let v388_3: Space = intersect(&(*CONSTANT_1),&(v388_2));
            let v388_4: Space = if has_head(&(v388_3)) { singleton(&[]) } else { Space::new() };
            drop(v388_3);
            let v388_5: Space = subtract(&(*CONSTANT_0),&(v388_4));
            drop(v388_4);
            let v388_8: Space = if (&(v388_5)).is_empty() { Space::new() } else {
              let v389_6: Path = concat_path(&(v387_6),&v379_20_cursor.path()[(v379_20_origin + 2)..(v379_20_origin + 3)]);
              let v389_7: Space = routine_34(c, &(v389_6), &v379_20_cursor);
              compose(&(v388_5),&(v389_7))
            };
            drop(v388_5);
            let v388_9: Space = intersect(&(*CONSTANT_1),&(v388_2));
            drop(v388_2);
            let v388_10: Space = if has_head(&(v388_9)) { singleton(&[]) } else { Space::new() };
            drop(v388_9);
            let v388_12: Space = if (&(v388_10)).is_empty() { Space::new() } else {
              let v390_6: Path = concat_path(&(v387_6),&v379_20_cursor.path()[(v379_20_origin + 2)..(v379_20_origin + 3)]);
              let v390_11: Space = routine_12(c, &(v390_6), &v379_20_cursor);
              drop(v390_6);
              compose(&(v388_10),&(v390_11))
            };
            drop(v388_10);
            let v388_13: Space = unite(&(v388_8),&(v388_12));
            join_wrapped_into(&mut v387_11_write,&((v388_13).read_zipper()),&[]);
            }
            v379_20_cursor.ascend(1);
          }
          drop(v387_11_write);
          drop(v387_6);
          compose(&(v382_10),&(v387_11))
        };
        drop(v382_10);
        let v382_13: Space = unite(&(v382_8),&(v382_12));
        join_wrapped_into(&mut v381_7_write,&((v382_13).read_zipper()),&[]);
        }
        v379_20_cursor.ascend(1);
      }
      drop(v381_7_write);
      compose(&(v380_5),&(v381_7))
    };
    drop(v380_5);
    let v380_9: Space = intersect(&(*CONSTANT_1),&(v380_2));
    drop(v380_2);
    let v380_10: Space = if has_head(&(v380_9)) { singleton(&[]) } else { Space::new() };
    drop(v380_9);
    let v380_12: Space = if (&(v380_10)).is_empty() { Space::new() } else {
      let v391_6: Path = concat_path(&(*p0),&v379_20_cursor.path()[v379_20_origin..(v379_20_origin + 1)]);
      let mut v391_11 = Space::new();
      let mut v391_11_write = v391_11.write_zipper();
      for v391_11_byte in v379_20_cursor.child_mask().iter() {
        v379_20_cursor.descend_to_existing_byte(v391_11_byte);
        {
        let v392_2: Space = singleton(&v379_20_cursor.path()[(v379_20_origin + 1)..(v379_20_origin + 2)]);
        let v392_3: Space = intersect(&(*CONSTANT_1),&(v392_2));
        let v392_4: Space = if has_head(&(v392_3)) { singleton(&[]) } else { Space::new() };
        drop(v392_3);
        let v392_5: Space = subtract(&(*CONSTANT_0),&(v392_4));
        drop(v392_4);
        let v392_8: Space = if (&(v392_5)).is_empty() { Space::new() } else {
          let v393_6: Path = concat_path(&(v391_6),&v379_20_cursor.path()[(v379_20_origin + 1)..(v379_20_origin + 2)]);
          let mut v393_7 = Space::new();
          let mut v393_7_write = v393_7.write_zipper();
          for v393_7_byte in v379_20_cursor.child_mask().iter() {
            v379_20_cursor.descend_to_existing_byte(v393_7_byte);
            {
            let v394_2: Space = singleton(&v379_20_cursor.path()[(v379_20_origin + 2)..(v379_20_origin + 3)]);
            let v394_3: Space = intersect(&(*CONSTANT_1),&(v394_2));
            let v394_4: Space = if has_head(&(v394_3)) { singleton(&[]) } else { Space::new() };
            drop(v394_3);
            let v394_5: Space = subtract(&(*CONSTANT_0),&(v394_4));
            drop(v394_4);
            let v394_8: Space = if (&(v394_5)).is_empty() { Space::new() } else {
              let v395_6: Path = concat_path(&(v393_6),&v379_20_cursor.path()[(v379_20_origin + 2)..(v379_20_origin + 3)]);
              let v395_7: Space = routine_34(c, &(v395_6), &v379_20_cursor);
              compose(&(v394_5),&(v395_7))
            };
            drop(v394_5);
            let v394_9: Space = intersect(&(*CONSTANT_1),&(v394_2));
            drop(v394_2);
            let v394_10: Space = if has_head(&(v394_9)) { singleton(&[]) } else { Space::new() };
            drop(v394_9);
            let v394_12: Space = if (&(v394_10)).is_empty() { Space::new() } else {
              let v396_6: Path = concat_path(&(v393_6),&v379_20_cursor.path()[(v379_20_origin + 2)..(v379_20_origin + 3)]);
              let v396_11: Space = routine_35(c, &(v396_6), &v379_20_cursor);
              drop(v396_6);
              compose(&(v394_10),&(v396_11))
            };
            drop(v394_10);
            let v394_13: Space = unite(&(v394_8),&(v394_12));
            join_wrapped_into(&mut v393_7_write,&((v394_13).read_zipper()),&[]);
            }
            v379_20_cursor.ascend(1);
          }
          drop(v393_7_write);
          drop(v393_6);
          compose(&(v392_5),&(v393_7))
        };
        drop(v392_5);
        let v392_9: Space = intersect(&(*CONSTANT_1),&(v392_2));
        drop(v392_2);
        let v392_10: Space = if has_head(&(v392_9)) { singleton(&[]) } else { Space::new() };
        drop(v392_9);
        let v392_11: Space = compose(&(v392_10),&v379_20_cursor);
        drop(v392_10);
        let v392_12: Space = unite(&(v392_8),&(v392_11));
        drop(v392_11);
        join_wrapped_into(&mut v391_11_write,&((v392_12).read_zipper()),&[]);
        }
        v379_20_cursor.ascend(1);
      }
      drop(v391_11_write);
      drop(v391_6);
      compose(&(v380_10),&(v391_11))
    };
    drop(v380_10);
    let v380_13: Space = unite(&(v380_8),&(v380_12));
    join_wrapped_into(&mut v379_20_write,&((v380_13).read_zipper()),&[]);
    }
    v379_20_cursor.ascend(1);
  }
  drop(v379_20_cursor);
  drop(v379_20_write);
  (v379_20).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v397_14 = Space::new();
  let mut v397_14_write = v397_14.write_zipper();
  let mut v397_14_cursor = (*s0).read_zipper();
  let v397_14_origin = v397_14_cursor.path().len();
  for v397_14_byte in v397_14_cursor.child_mask().iter() {
    v397_14_cursor.descend_to_existing_byte(v397_14_byte);
    {
    let v398_2: Space = singleton(&v397_14_cursor.path()[v397_14_origin..(v397_14_origin + 1)]);
    let v398_3: Space = intersect(&(*CONSTANT_1),&(v398_2));
    let v398_4: Space = if has_head(&(v398_3)) { singleton(&[]) } else { Space::new() };
    drop(v398_3);
    let v398_5: Space = subtract(&(*CONSTANT_0),&(v398_4));
    drop(v398_4);
    let v398_8: Space = if (&(v398_5)).is_empty() { Space::new() } else {
      let v399_6: Path = concat_path(&(*p0),&v397_14_cursor.path()[v397_14_origin..(v397_14_origin + 1)]);
      let mut v399_7 = Space::new();
      let mut v399_7_write = v399_7.write_zipper();
      for v399_7_byte in v397_14_cursor.child_mask().iter() {
        v397_14_cursor.descend_to_existing_byte(v399_7_byte);
        {
        let v400_2: Space = singleton(&v397_14_cursor.path()[(v397_14_origin + 1)..(v397_14_origin + 2)]);
        let v400_3: Space = intersect(&(*CONSTANT_1),&(v400_2));
        let v400_4: Space = if has_head(&(v400_3)) { singleton(&[]) } else { Space::new() };
        drop(v400_3);
        let v400_5: Space = subtract(&(*CONSTANT_0),&(v400_4));
        drop(v400_4);
        let v400_8: Space = if (&(v400_5)).is_empty() { Space::new() } else {
          let v401_6: Path = concat_path(&(v399_6),&v397_14_cursor.path()[(v397_14_origin + 1)..(v397_14_origin + 2)]);
          let mut v401_7 = Space::new();
          let mut v401_7_write = v401_7.write_zipper();
          for v401_7_byte in v397_14_cursor.child_mask().iter() {
            v397_14_cursor.descend_to_existing_byte(v401_7_byte);
            {
            let v402_2: Space = singleton(&v397_14_cursor.path()[(v397_14_origin + 2)..(v397_14_origin + 3)]);
            let v402_3: Space = intersect(&(*CONSTANT_1),&(v402_2));
            let v402_4: Space = if has_head(&(v402_3)) { singleton(&[]) } else { Space::new() };
            drop(v402_3);
            let v402_5: Space = subtract(&(*CONSTANT_0),&(v402_4));
            drop(v402_4);
            let v402_8: Space = if (&(v402_5)).is_empty() { Space::new() } else {
              let v403_6: Path = concat_path(&(v401_6),&v397_14_cursor.path()[(v397_14_origin + 2)..(v397_14_origin + 3)]);
              let v403_7: Space = routine_34(c, &(v403_6), &v397_14_cursor);
              compose(&(v402_5),&(v403_7))
            };
            drop(v402_5);
            let v402_9: Space = intersect(&(*CONSTANT_1),&(v402_2));
            drop(v402_2);
            let v402_10: Space = if has_head(&(v402_9)) { singleton(&[]) } else { Space::new() };
            drop(v402_9);
            let v402_12: Space = if (&(v402_10)).is_empty() { Space::new() } else {
              let v404_6: Path = concat_path(&(v401_6),&v397_14_cursor.path()[(v397_14_origin + 2)..(v397_14_origin + 3)]);
              let v404_11: Space = routine_35(c, &(v404_6), &v397_14_cursor);
              drop(v404_6);
              compose(&(v402_10),&(v404_11))
            };
            drop(v402_10);
            let v402_13: Space = unite(&(v402_8),&(v402_12));
            join_wrapped_into(&mut v401_7_write,&((v402_13).read_zipper()),&[]);
            }
            v397_14_cursor.ascend(1);
          }
          drop(v401_7_write);
          compose(&(v400_5),&(v401_7))
        };
        drop(v400_5);
        let v400_9: Space = intersect(&(*CONSTANT_1),&(v400_2));
        drop(v400_2);
        let v400_10: Space = if has_head(&(v400_9)) { singleton(&[]) } else { Space::new() };
        drop(v400_9);
        let v400_12: Space = if (&(v400_10)).is_empty() { Space::new() } else {
          let v405_6: Path = concat_path(&(v399_6),&v397_14_cursor.path()[(v397_14_origin + 1)..(v397_14_origin + 2)]);
          let mut v405_11 = Space::new();
          let mut v405_11_write = v405_11.write_zipper();
          for v405_11_byte in v397_14_cursor.child_mask().iter() {
            v397_14_cursor.descend_to_existing_byte(v405_11_byte);
            {
            let v406_2: Space = singleton(&v397_14_cursor.path()[(v397_14_origin + 2)..(v397_14_origin + 3)]);
            let v406_3: Space = intersect(&(*CONSTANT_1),&(v406_2));
            let v406_4: Space = if has_head(&(v406_3)) { singleton(&[]) } else { Space::new() };
            drop(v406_3);
            let v406_5: Space = subtract(&(*CONSTANT_0),&(v406_4));
            drop(v406_4);
            let v406_8: Space = if (&(v406_5)).is_empty() { Space::new() } else {
              let v407_6: Path = concat_path(&(v405_6),&v397_14_cursor.path()[(v397_14_origin + 2)..(v397_14_origin + 3)]);
              let v407_7: Space = routine_34(c, &(v407_6), &v397_14_cursor);
              compose(&(v406_5),&(v407_7))
            };
            drop(v406_5);
            let v406_9: Space = intersect(&(*CONSTANT_1),&(v406_2));
            drop(v406_2);
            let v406_10: Space = if has_head(&(v406_9)) { singleton(&[]) } else { Space::new() };
            drop(v406_9);
            let v406_12: Space = if (&(v406_10)).is_empty() { Space::new() } else {
              let v408_6: Path = concat_path(&(v405_6),&v397_14_cursor.path()[(v397_14_origin + 2)..(v397_14_origin + 3)]);
              let v408_11: Space = routine_12(c, &(v408_6), &v397_14_cursor);
              drop(v408_6);
              compose(&(v406_10),&(v408_11))
            };
            drop(v406_10);
            let v406_13: Space = unite(&(v406_8),&(v406_12));
            join_wrapped_into(&mut v405_11_write,&((v406_13).read_zipper()),&[]);
            }
            v397_14_cursor.ascend(1);
          }
          drop(v405_11_write);
          drop(v405_6);
          compose(&(v400_10),&(v405_11))
        };
        drop(v400_10);
        let v400_13: Space = unite(&(v400_8),&(v400_12));
        join_wrapped_into(&mut v399_7_write,&((v400_13).read_zipper()),&[]);
        }
        v397_14_cursor.ascend(1);
      }
      drop(v399_7_write);
      drop(v399_6);
      compose(&(v398_5),&(v399_7))
    };
    drop(v398_5);
    let v398_9: Space = intersect(&(*CONSTANT_1),&(v398_2));
    drop(v398_2);
    let v398_10: Space = if has_head(&(v398_9)) { singleton(&[]) } else { Space::new() };
    drop(v398_9);
    let v398_11: Space = compose(&(v398_10),&v397_14_cursor);
    drop(v398_10);
    let v398_12: Space = unite(&(v398_8),&(v398_11));
    drop(v398_11);
    join_wrapped_into(&mut v397_14_write,&((v398_12).read_zipper()),&[]);
    }
    v397_14_cursor.ascend(1);
  }
  drop(v397_14_cursor);
  drop(v397_14_write);
  (v397_14).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v409_20 = Space::new();
  let mut v409_20_write = v409_20.write_zipper();
  let mut v409_20_cursor = (*s0).read_zipper();
  let v409_20_origin = v409_20_cursor.path().len();
  for v409_20_byte in v409_20_cursor.child_mask().iter() {
    v409_20_cursor.descend_to_existing_byte(v409_20_byte);
    {
    let v410_2: Space = singleton(&v409_20_cursor.path()[v409_20_origin..(v409_20_origin + 1)]);
    let v410_3: Space = intersect(&(*CONSTANT_1),&(v410_2));
    let v410_4: Space = if has_head(&(v410_3)) { singleton(&[]) } else { Space::new() };
    drop(v410_3);
    let v410_5: Space = subtract(&(*CONSTANT_0),&(v410_4));
    drop(v410_4);
    let v410_8: Space = if (&(v410_5)).is_empty() { Space::new() } else {
      let v411_6: Path = concat_path(&(*p0),&v409_20_cursor.path()[v409_20_origin..(v409_20_origin + 1)]);
      let mut v411_7 = Space::new();
      let mut v411_7_write = v411_7.write_zipper();
      for v411_7_byte in v409_20_cursor.child_mask().iter() {
        v409_20_cursor.descend_to_existing_byte(v411_7_byte);
        {
        let v412_2: Space = singleton(&v409_20_cursor.path()[(v409_20_origin + 1)..(v409_20_origin + 2)]);
        let v412_3: Space = intersect(&(*CONSTANT_1),&(v412_2));
        let v412_4: Space = if has_head(&(v412_3)) { singleton(&[]) } else { Space::new() };
        drop(v412_3);
        let v412_5: Space = subtract(&(*CONSTANT_0),&(v412_4));
        drop(v412_4);
        let v412_8: Space = if (&(v412_5)).is_empty() { Space::new() } else {
          let v413_6: Path = concat_path(&(v411_6),&v409_20_cursor.path()[(v409_20_origin + 1)..(v409_20_origin + 2)]);
          let mut v413_7 = Space::new();
          let mut v413_7_write = v413_7.write_zipper();
          for v413_7_byte in v409_20_cursor.child_mask().iter() {
            v409_20_cursor.descend_to_existing_byte(v413_7_byte);
            {
            let v414_2: Space = singleton(&v409_20_cursor.path()[(v409_20_origin + 2)..(v409_20_origin + 3)]);
            let v414_3: Space = intersect(&(*CONSTANT_1),&(v414_2));
            let v414_4: Space = if has_head(&(v414_3)) { singleton(&[]) } else { Space::new() };
            drop(v414_3);
            let v414_5: Space = subtract(&(*CONSTANT_0),&(v414_4));
            drop(v414_4);
            let v414_8: Space = if (&(v414_5)).is_empty() { Space::new() } else {
              let v415_6: Path = concat_path(&(v413_6),&v409_20_cursor.path()[(v409_20_origin + 2)..(v409_20_origin + 3)]);
              let v415_7: Space = routine_36(c, &(v415_6), &v409_20_cursor);
              compose(&(v414_5),&(v415_7))
            };
            drop(v414_5);
            let v414_9: Space = intersect(&(*CONSTANT_1),&(v414_2));
            drop(v414_2);
            let v414_10: Space = if has_head(&(v414_9)) { singleton(&[]) } else { Space::new() };
            drop(v414_9);
            let v414_12: Space = if (&(v414_10)).is_empty() { Space::new() } else {
              let v416_6: Path = concat_path(&(v413_6),&v409_20_cursor.path()[(v409_20_origin + 2)..(v409_20_origin + 3)]);
              let v416_11: Space = routine_37(c, &(v416_6), &v409_20_cursor);
              drop(v416_6);
              compose(&(v414_10),&(v416_11))
            };
            drop(v414_10);
            let v414_13: Space = unite(&(v414_8),&(v414_12));
            join_wrapped_into(&mut v413_7_write,&((v414_13).read_zipper()),&[]);
            }
            v409_20_cursor.ascend(1);
          }
          drop(v413_7_write);
          compose(&(v412_5),&(v413_7))
        };
        drop(v412_5);
        let v412_9: Space = intersect(&(*CONSTANT_1),&(v412_2));
        drop(v412_2);
        let v412_10: Space = if has_head(&(v412_9)) { singleton(&[]) } else { Space::new() };
        drop(v412_9);
        let v412_12: Space = if (&(v412_10)).is_empty() { Space::new() } else {
          let v417_6: Path = concat_path(&(v411_6),&v409_20_cursor.path()[(v409_20_origin + 1)..(v409_20_origin + 2)]);
          let mut v417_11 = Space::new();
          let mut v417_11_write = v417_11.write_zipper();
          for v417_11_byte in v409_20_cursor.child_mask().iter() {
            v409_20_cursor.descend_to_existing_byte(v417_11_byte);
            {
            let v418_2: Space = singleton(&v409_20_cursor.path()[(v409_20_origin + 2)..(v409_20_origin + 3)]);
            let v418_3: Space = intersect(&(*CONSTANT_1),&(v418_2));
            let v418_4: Space = if has_head(&(v418_3)) { singleton(&[]) } else { Space::new() };
            drop(v418_3);
            let v418_5: Space = subtract(&(*CONSTANT_0),&(v418_4));
            drop(v418_4);
            let v418_8: Space = if (&(v418_5)).is_empty() { Space::new() } else {
              let v419_6: Path = concat_path(&(v417_6),&v409_20_cursor.path()[(v409_20_origin + 2)..(v409_20_origin + 3)]);
              let v419_7: Space = routine_36(c, &(v419_6), &v409_20_cursor);
              compose(&(v418_5),&(v419_7))
            };
            drop(v418_5);
            let v418_9: Space = intersect(&(*CONSTANT_1),&(v418_2));
            drop(v418_2);
            let v418_10: Space = if has_head(&(v418_9)) { singleton(&[]) } else { Space::new() };
            drop(v418_9);
            let v418_12: Space = if (&(v418_10)).is_empty() { Space::new() } else {
              let v420_6: Path = concat_path(&(v417_6),&v409_20_cursor.path()[(v409_20_origin + 2)..(v409_20_origin + 3)]);
              let v420_11: Space = routine_15(c, &(v420_6), &v409_20_cursor);
              drop(v420_6);
              compose(&(v418_10),&(v420_11))
            };
            drop(v418_10);
            let v418_13: Space = unite(&(v418_8),&(v418_12));
            join_wrapped_into(&mut v417_11_write,&((v418_13).read_zipper()),&[]);
            }
            v409_20_cursor.ascend(1);
          }
          drop(v417_11_write);
          drop(v417_6);
          compose(&(v412_10),&(v417_11))
        };
        drop(v412_10);
        let v412_13: Space = unite(&(v412_8),&(v412_12));
        join_wrapped_into(&mut v411_7_write,&((v412_13).read_zipper()),&[]);
        }
        v409_20_cursor.ascend(1);
      }
      drop(v411_7_write);
      compose(&(v410_5),&(v411_7))
    };
    drop(v410_5);
    let v410_9: Space = intersect(&(*CONSTANT_1),&(v410_2));
    drop(v410_2);
    let v410_10: Space = if has_head(&(v410_9)) { singleton(&[]) } else { Space::new() };
    drop(v410_9);
    let v410_12: Space = if (&(v410_10)).is_empty() { Space::new() } else {
      let v421_6: Path = concat_path(&(*p0),&v409_20_cursor.path()[v409_20_origin..(v409_20_origin + 1)]);
      let mut v421_11 = Space::new();
      let mut v421_11_write = v421_11.write_zipper();
      for v421_11_byte in v409_20_cursor.child_mask().iter() {
        v409_20_cursor.descend_to_existing_byte(v421_11_byte);
        {
        let v422_2: Space = singleton(&v409_20_cursor.path()[(v409_20_origin + 1)..(v409_20_origin + 2)]);
        let v422_3: Space = intersect(&(*CONSTANT_1),&(v422_2));
        let v422_4: Space = if has_head(&(v422_3)) { singleton(&[]) } else { Space::new() };
        drop(v422_3);
        let v422_5: Space = subtract(&(*CONSTANT_0),&(v422_4));
        drop(v422_4);
        let v422_8: Space = if (&(v422_5)).is_empty() { Space::new() } else {
          let v423_6: Path = concat_path(&(v421_6),&v409_20_cursor.path()[(v409_20_origin + 1)..(v409_20_origin + 2)]);
          let mut v423_7 = Space::new();
          let mut v423_7_write = v423_7.write_zipper();
          for v423_7_byte in v409_20_cursor.child_mask().iter() {
            v409_20_cursor.descend_to_existing_byte(v423_7_byte);
            {
            let v424_2: Space = singleton(&v409_20_cursor.path()[(v409_20_origin + 2)..(v409_20_origin + 3)]);
            let v424_3: Space = intersect(&(*CONSTANT_1),&(v424_2));
            let v424_4: Space = if has_head(&(v424_3)) { singleton(&[]) } else { Space::new() };
            drop(v424_3);
            let v424_5: Space = subtract(&(*CONSTANT_0),&(v424_4));
            drop(v424_4);
            let v424_8: Space = if (&(v424_5)).is_empty() { Space::new() } else {
              let v425_6: Path = concat_path(&(v423_6),&v409_20_cursor.path()[(v409_20_origin + 2)..(v409_20_origin + 3)]);
              let v425_7: Space = routine_36(c, &(v425_6), &v409_20_cursor);
              compose(&(v424_5),&(v425_7))
            };
            drop(v424_5);
            let v424_9: Space = intersect(&(*CONSTANT_1),&(v424_2));
            drop(v424_2);
            let v424_10: Space = if has_head(&(v424_9)) { singleton(&[]) } else { Space::new() };
            drop(v424_9);
            let v424_12: Space = if (&(v424_10)).is_empty() { Space::new() } else {
              let v426_6: Path = concat_path(&(v423_6),&v409_20_cursor.path()[(v409_20_origin + 2)..(v409_20_origin + 3)]);
              let v426_11: Space = routine_37(c, &(v426_6), &v409_20_cursor);
              drop(v426_6);
              compose(&(v424_10),&(v426_11))
            };
            drop(v424_10);
            let v424_13: Space = unite(&(v424_8),&(v424_12));
            join_wrapped_into(&mut v423_7_write,&((v424_13).read_zipper()),&[]);
            }
            v409_20_cursor.ascend(1);
          }
          drop(v423_7_write);
          drop(v423_6);
          compose(&(v422_5),&(v423_7))
        };
        drop(v422_5);
        let v422_9: Space = intersect(&(*CONSTANT_1),&(v422_2));
        drop(v422_2);
        let v422_10: Space = if has_head(&(v422_9)) { singleton(&[]) } else { Space::new() };
        drop(v422_9);
        let v422_11: Space = compose(&(v422_10),&v409_20_cursor);
        drop(v422_10);
        let v422_12: Space = unite(&(v422_8),&(v422_11));
        drop(v422_11);
        join_wrapped_into(&mut v421_11_write,&((v422_12).read_zipper()),&[]);
        }
        v409_20_cursor.ascend(1);
      }
      drop(v421_11_write);
      drop(v421_6);
      compose(&(v410_10),&(v421_11))
    };
    drop(v410_10);
    let v410_13: Space = unite(&(v410_8),&(v410_12));
    join_wrapped_into(&mut v409_20_write,&((v410_13).read_zipper()),&[]);
    }
    v409_20_cursor.ascend(1);
  }
  drop(v409_20_cursor);
  drop(v409_20_write);
  (v409_20).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v427_14 = Space::new();
  let mut v427_14_write = v427_14.write_zipper();
  let mut v427_14_cursor = (*s0).read_zipper();
  let v427_14_origin = v427_14_cursor.path().len();
  for v427_14_byte in v427_14_cursor.child_mask().iter() {
    v427_14_cursor.descend_to_existing_byte(v427_14_byte);
    {
    let v428_2: Space = singleton(&v427_14_cursor.path()[v427_14_origin..(v427_14_origin + 1)]);
    let v428_3: Space = intersect(&(*CONSTANT_1),&(v428_2));
    let v428_4: Space = if has_head(&(v428_3)) { singleton(&[]) } else { Space::new() };
    drop(v428_3);
    let v428_5: Space = subtract(&(*CONSTANT_0),&(v428_4));
    drop(v428_4);
    let v428_8: Space = if (&(v428_5)).is_empty() { Space::new() } else {
      let v429_6: Path = concat_path(&(*p0),&v427_14_cursor.path()[v427_14_origin..(v427_14_origin + 1)]);
      let mut v429_7 = Space::new();
      let mut v429_7_write = v429_7.write_zipper();
      for v429_7_byte in v427_14_cursor.child_mask().iter() {
        v427_14_cursor.descend_to_existing_byte(v429_7_byte);
        {
        let v430_2: Space = singleton(&v427_14_cursor.path()[(v427_14_origin + 1)..(v427_14_origin + 2)]);
        let v430_3: Space = intersect(&(*CONSTANT_1),&(v430_2));
        let v430_4: Space = if has_head(&(v430_3)) { singleton(&[]) } else { Space::new() };
        drop(v430_3);
        let v430_5: Space = subtract(&(*CONSTANT_0),&(v430_4));
        drop(v430_4);
        let v430_8: Space = if (&(v430_5)).is_empty() { Space::new() } else {
          let v431_6: Path = concat_path(&(v429_6),&v427_14_cursor.path()[(v427_14_origin + 1)..(v427_14_origin + 2)]);
          let mut v431_7 = Space::new();
          let mut v431_7_write = v431_7.write_zipper();
          for v431_7_byte in v427_14_cursor.child_mask().iter() {
            v427_14_cursor.descend_to_existing_byte(v431_7_byte);
            {
            let v432_2: Space = singleton(&v427_14_cursor.path()[(v427_14_origin + 2)..(v427_14_origin + 3)]);
            let v432_3: Space = intersect(&(*CONSTANT_1),&(v432_2));
            let v432_4: Space = if has_head(&(v432_3)) { singleton(&[]) } else { Space::new() };
            drop(v432_3);
            let v432_5: Space = subtract(&(*CONSTANT_0),&(v432_4));
            drop(v432_4);
            let v432_8: Space = if (&(v432_5)).is_empty() { Space::new() } else {
              let v433_6: Path = concat_path(&(v431_6),&v427_14_cursor.path()[(v427_14_origin + 2)..(v427_14_origin + 3)]);
              let v433_7: Space = routine_36(c, &(v433_6), &v427_14_cursor);
              compose(&(v432_5),&(v433_7))
            };
            drop(v432_5);
            let v432_9: Space = intersect(&(*CONSTANT_1),&(v432_2));
            drop(v432_2);
            let v432_10: Space = if has_head(&(v432_9)) { singleton(&[]) } else { Space::new() };
            drop(v432_9);
            let v432_12: Space = if (&(v432_10)).is_empty() { Space::new() } else {
              let v434_6: Path = concat_path(&(v431_6),&v427_14_cursor.path()[(v427_14_origin + 2)..(v427_14_origin + 3)]);
              let v434_11: Space = routine_37(c, &(v434_6), &v427_14_cursor);
              drop(v434_6);
              compose(&(v432_10),&(v434_11))
            };
            drop(v432_10);
            let v432_13: Space = unite(&(v432_8),&(v432_12));
            join_wrapped_into(&mut v431_7_write,&((v432_13).read_zipper()),&[]);
            }
            v427_14_cursor.ascend(1);
          }
          drop(v431_7_write);
          compose(&(v430_5),&(v431_7))
        };
        drop(v430_5);
        let v430_9: Space = intersect(&(*CONSTANT_1),&(v430_2));
        drop(v430_2);
        let v430_10: Space = if has_head(&(v430_9)) { singleton(&[]) } else { Space::new() };
        drop(v430_9);
        let v430_12: Space = if (&(v430_10)).is_empty() { Space::new() } else {
          let v435_6: Path = concat_path(&(v429_6),&v427_14_cursor.path()[(v427_14_origin + 1)..(v427_14_origin + 2)]);
          let mut v435_11 = Space::new();
          let mut v435_11_write = v435_11.write_zipper();
          for v435_11_byte in v427_14_cursor.child_mask().iter() {
            v427_14_cursor.descend_to_existing_byte(v435_11_byte);
            {
            let v436_2: Space = singleton(&v427_14_cursor.path()[(v427_14_origin + 2)..(v427_14_origin + 3)]);
            let v436_3: Space = intersect(&(*CONSTANT_1),&(v436_2));
            let v436_4: Space = if has_head(&(v436_3)) { singleton(&[]) } else { Space::new() };
            drop(v436_3);
            let v436_5: Space = subtract(&(*CONSTANT_0),&(v436_4));
            drop(v436_4);
            let v436_8: Space = if (&(v436_5)).is_empty() { Space::new() } else {
              let v437_6: Path = concat_path(&(v435_6),&v427_14_cursor.path()[(v427_14_origin + 2)..(v427_14_origin + 3)]);
              let v437_7: Space = routine_36(c, &(v437_6), &v427_14_cursor);
              compose(&(v436_5),&(v437_7))
            };
            drop(v436_5);
            let v436_9: Space = intersect(&(*CONSTANT_1),&(v436_2));
            drop(v436_2);
            let v436_10: Space = if has_head(&(v436_9)) { singleton(&[]) } else { Space::new() };
            drop(v436_9);
            let v436_12: Space = if (&(v436_10)).is_empty() { Space::new() } else {
              let v438_6: Path = concat_path(&(v435_6),&v427_14_cursor.path()[(v427_14_origin + 2)..(v427_14_origin + 3)]);
              let v438_11: Space = routine_15(c, &(v438_6), &v427_14_cursor);
              drop(v438_6);
              compose(&(v436_10),&(v438_11))
            };
            drop(v436_10);
            let v436_13: Space = unite(&(v436_8),&(v436_12));
            join_wrapped_into(&mut v435_11_write,&((v436_13).read_zipper()),&[]);
            }
            v427_14_cursor.ascend(1);
          }
          drop(v435_11_write);
          drop(v435_6);
          compose(&(v430_10),&(v435_11))
        };
        drop(v430_10);
        let v430_13: Space = unite(&(v430_8),&(v430_12));
        join_wrapped_into(&mut v429_7_write,&((v430_13).read_zipper()),&[]);
        }
        v427_14_cursor.ascend(1);
      }
      drop(v429_7_write);
      drop(v429_6);
      compose(&(v428_5),&(v429_7))
    };
    drop(v428_5);
    let v428_9: Space = intersect(&(*CONSTANT_1),&(v428_2));
    drop(v428_2);
    let v428_10: Space = if has_head(&(v428_9)) { singleton(&[]) } else { Space::new() };
    drop(v428_9);
    let v428_11: Space = compose(&(v428_10),&v427_14_cursor);
    drop(v428_10);
    let v428_12: Space = unite(&(v428_8),&(v428_11));
    drop(v428_11);
    join_wrapped_into(&mut v427_14_write,&((v428_12).read_zipper()),&[]);
    }
    v427_14_cursor.ascend(1);
  }
  drop(v427_14_cursor);
  drop(v427_14_write);
  (v427_14).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v439_20 = Space::new();
  let mut v439_20_write = v439_20.write_zipper();
  let mut v439_20_cursor = (*s0).read_zipper();
  let v439_20_origin = v439_20_cursor.path().len();
  for v439_20_byte in v439_20_cursor.child_mask().iter() {
    v439_20_cursor.descend_to_existing_byte(v439_20_byte);
    {
    let v440_2: Space = singleton(&v439_20_cursor.path()[v439_20_origin..(v439_20_origin + 1)]);
    let v440_3: Space = intersect(&(*CONSTANT_1),&(v440_2));
    let v440_4: Space = if has_head(&(v440_3)) { singleton(&[]) } else { Space::new() };
    drop(v440_3);
    let v440_5: Space = subtract(&(*CONSTANT_0),&(v440_4));
    drop(v440_4);
    let v440_8: Space = if (&(v440_5)).is_empty() { Space::new() } else {
      let v441_6: Path = concat_path(&(*p0),&v439_20_cursor.path()[v439_20_origin..(v439_20_origin + 1)]);
      let mut v441_7 = Space::new();
      let mut v441_7_write = v441_7.write_zipper();
      for v441_7_byte in v439_20_cursor.child_mask().iter() {
        v439_20_cursor.descend_to_existing_byte(v441_7_byte);
        {
        let v442_2: Space = singleton(&v439_20_cursor.path()[(v439_20_origin + 1)..(v439_20_origin + 2)]);
        let v442_3: Space = intersect(&(*CONSTANT_1),&(v442_2));
        let v442_4: Space = if has_head(&(v442_3)) { singleton(&[]) } else { Space::new() };
        drop(v442_3);
        let v442_5: Space = subtract(&(*CONSTANT_0),&(v442_4));
        drop(v442_4);
        let v442_8: Space = if (&(v442_5)).is_empty() { Space::new() } else {
          let v443_6: Path = concat_path(&(v441_6),&v439_20_cursor.path()[(v439_20_origin + 1)..(v439_20_origin + 2)]);
          let mut v443_7 = Space::new();
          let mut v443_7_write = v443_7.write_zipper();
          for v443_7_byte in v439_20_cursor.child_mask().iter() {
            v439_20_cursor.descend_to_existing_byte(v443_7_byte);
            {
            let v444_2: Space = singleton(&v439_20_cursor.path()[(v439_20_origin + 2)..(v439_20_origin + 3)]);
            let v444_3: Space = intersect(&(*CONSTANT_1),&(v444_2));
            let v444_4: Space = if has_head(&(v444_3)) { singleton(&[]) } else { Space::new() };
            drop(v444_3);
            let v444_5: Space = subtract(&(*CONSTANT_0),&(v444_4));
            drop(v444_4);
            let v444_8: Space = if (&(v444_5)).is_empty() { Space::new() } else {
              let v445_6: Path = concat_path(&(v443_6),&v439_20_cursor.path()[(v439_20_origin + 2)..(v439_20_origin + 3)]);
              let v445_7: Space = routine_38(c, &(v445_6), &v439_20_cursor);
              compose(&(v444_5),&(v445_7))
            };
            drop(v444_5);
            let v444_9: Space = intersect(&(*CONSTANT_1),&(v444_2));
            drop(v444_2);
            let v444_10: Space = if has_head(&(v444_9)) { singleton(&[]) } else { Space::new() };
            drop(v444_9);
            let v444_12: Space = if (&(v444_10)).is_empty() { Space::new() } else {
              let v446_6: Path = concat_path(&(v443_6),&v439_20_cursor.path()[(v439_20_origin + 2)..(v439_20_origin + 3)]);
              let v446_11: Space = routine_39(c, &(v446_6), &v439_20_cursor);
              drop(v446_6);
              compose(&(v444_10),&(v446_11))
            };
            drop(v444_10);
            let v444_13: Space = unite(&(v444_8),&(v444_12));
            join_wrapped_into(&mut v443_7_write,&((v444_13).read_zipper()),&[]);
            }
            v439_20_cursor.ascend(1);
          }
          drop(v443_7_write);
          compose(&(v442_5),&(v443_7))
        };
        drop(v442_5);
        let v442_9: Space = intersect(&(*CONSTANT_1),&(v442_2));
        drop(v442_2);
        let v442_10: Space = if has_head(&(v442_9)) { singleton(&[]) } else { Space::new() };
        drop(v442_9);
        let v442_12: Space = if (&(v442_10)).is_empty() { Space::new() } else {
          let v447_6: Path = concat_path(&(v441_6),&v439_20_cursor.path()[(v439_20_origin + 1)..(v439_20_origin + 2)]);
          let mut v447_11 = Space::new();
          let mut v447_11_write = v447_11.write_zipper();
          for v447_11_byte in v439_20_cursor.child_mask().iter() {
            v439_20_cursor.descend_to_existing_byte(v447_11_byte);
            {
            let v448_2: Space = singleton(&v439_20_cursor.path()[(v439_20_origin + 2)..(v439_20_origin + 3)]);
            let v448_3: Space = intersect(&(*CONSTANT_1),&(v448_2));
            let v448_4: Space = if has_head(&(v448_3)) { singleton(&[]) } else { Space::new() };
            drop(v448_3);
            let v448_5: Space = subtract(&(*CONSTANT_0),&(v448_4));
            drop(v448_4);
            let v448_8: Space = if (&(v448_5)).is_empty() { Space::new() } else {
              let v449_6: Path = concat_path(&(v447_6),&v439_20_cursor.path()[(v439_20_origin + 2)..(v439_20_origin + 3)]);
              let v449_7: Space = routine_38(c, &(v449_6), &v439_20_cursor);
              compose(&(v448_5),&(v449_7))
            };
            drop(v448_5);
            let v448_9: Space = intersect(&(*CONSTANT_1),&(v448_2));
            drop(v448_2);
            let v448_10: Space = if has_head(&(v448_9)) { singleton(&[]) } else { Space::new() };
            drop(v448_9);
            let v448_12: Space = if (&(v448_10)).is_empty() { Space::new() } else {
              let v450_6: Path = concat_path(&(v447_6),&v439_20_cursor.path()[(v439_20_origin + 2)..(v439_20_origin + 3)]);
              let v450_11: Space = routine_12(c, &(v450_6), &v439_20_cursor);
              drop(v450_6);
              compose(&(v448_10),&(v450_11))
            };
            drop(v448_10);
            let v448_13: Space = unite(&(v448_8),&(v448_12));
            join_wrapped_into(&mut v447_11_write,&((v448_13).read_zipper()),&[]);
            }
            v439_20_cursor.ascend(1);
          }
          drop(v447_11_write);
          drop(v447_6);
          compose(&(v442_10),&(v447_11))
        };
        drop(v442_10);
        let v442_13: Space = unite(&(v442_8),&(v442_12));
        join_wrapped_into(&mut v441_7_write,&((v442_13).read_zipper()),&[]);
        }
        v439_20_cursor.ascend(1);
      }
      drop(v441_7_write);
      compose(&(v440_5),&(v441_7))
    };
    drop(v440_5);
    let v440_9: Space = intersect(&(*CONSTANT_1),&(v440_2));
    drop(v440_2);
    let v440_10: Space = if has_head(&(v440_9)) { singleton(&[]) } else { Space::new() };
    drop(v440_9);
    let v440_12: Space = if (&(v440_10)).is_empty() { Space::new() } else {
      let v451_6: Path = concat_path(&(*p0),&v439_20_cursor.path()[v439_20_origin..(v439_20_origin + 1)]);
      let mut v451_11 = Space::new();
      let mut v451_11_write = v451_11.write_zipper();
      for v451_11_byte in v439_20_cursor.child_mask().iter() {
        v439_20_cursor.descend_to_existing_byte(v451_11_byte);
        {
        let v452_2: Space = singleton(&v439_20_cursor.path()[(v439_20_origin + 1)..(v439_20_origin + 2)]);
        let v452_3: Space = intersect(&(*CONSTANT_1),&(v452_2));
        let v452_4: Space = if has_head(&(v452_3)) { singleton(&[]) } else { Space::new() };
        drop(v452_3);
        let v452_5: Space = subtract(&(*CONSTANT_0),&(v452_4));
        drop(v452_4);
        let v452_8: Space = if (&(v452_5)).is_empty() { Space::new() } else {
          let v453_6: Path = concat_path(&(v451_6),&v439_20_cursor.path()[(v439_20_origin + 1)..(v439_20_origin + 2)]);
          let mut v453_7 = Space::new();
          let mut v453_7_write = v453_7.write_zipper();
          for v453_7_byte in v439_20_cursor.child_mask().iter() {
            v439_20_cursor.descend_to_existing_byte(v453_7_byte);
            {
            let v454_2: Space = singleton(&v439_20_cursor.path()[(v439_20_origin + 2)..(v439_20_origin + 3)]);
            let v454_3: Space = intersect(&(*CONSTANT_1),&(v454_2));
            let v454_4: Space = if has_head(&(v454_3)) { singleton(&[]) } else { Space::new() };
            drop(v454_3);
            let v454_5: Space = subtract(&(*CONSTANT_0),&(v454_4));
            drop(v454_4);
            let v454_8: Space = if (&(v454_5)).is_empty() { Space::new() } else {
              let v455_6: Path = concat_path(&(v453_6),&v439_20_cursor.path()[(v439_20_origin + 2)..(v439_20_origin + 3)]);
              let v455_7: Space = routine_38(c, &(v455_6), &v439_20_cursor);
              compose(&(v454_5),&(v455_7))
            };
            drop(v454_5);
            let v454_9: Space = intersect(&(*CONSTANT_1),&(v454_2));
            drop(v454_2);
            let v454_10: Space = if has_head(&(v454_9)) { singleton(&[]) } else { Space::new() };
            drop(v454_9);
            let v454_12: Space = if (&(v454_10)).is_empty() { Space::new() } else {
              let v456_6: Path = concat_path(&(v453_6),&v439_20_cursor.path()[(v439_20_origin + 2)..(v439_20_origin + 3)]);
              let v456_11: Space = routine_39(c, &(v456_6), &v439_20_cursor);
              drop(v456_6);
              compose(&(v454_10),&(v456_11))
            };
            drop(v454_10);
            let v454_13: Space = unite(&(v454_8),&(v454_12));
            join_wrapped_into(&mut v453_7_write,&((v454_13).read_zipper()),&[]);
            }
            v439_20_cursor.ascend(1);
          }
          drop(v453_7_write);
          drop(v453_6);
          compose(&(v452_5),&(v453_7))
        };
        drop(v452_5);
        let v452_9: Space = intersect(&(*CONSTANT_1),&(v452_2));
        drop(v452_2);
        let v452_10: Space = if has_head(&(v452_9)) { singleton(&[]) } else { Space::new() };
        drop(v452_9);
        let v452_11: Space = compose(&(v452_10),&v439_20_cursor);
        drop(v452_10);
        let v452_12: Space = unite(&(v452_8),&(v452_11));
        drop(v452_11);
        join_wrapped_into(&mut v451_11_write,&((v452_12).read_zipper()),&[]);
        }
        v439_20_cursor.ascend(1);
      }
      drop(v451_11_write);
      drop(v451_6);
      compose(&(v440_10),&(v451_11))
    };
    drop(v440_10);
    let v440_13: Space = unite(&(v440_8),&(v440_12));
    join_wrapped_into(&mut v439_20_write,&((v440_13).read_zipper()),&[]);
    }
    v439_20_cursor.ascend(1);
  }
  drop(v439_20_cursor);
  drop(v439_20_write);
  (v439_20).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v457_14 = Space::new();
  let mut v457_14_write = v457_14.write_zipper();
  let mut v457_14_cursor = (*s0).read_zipper();
  let v457_14_origin = v457_14_cursor.path().len();
  for v457_14_byte in v457_14_cursor.child_mask().iter() {
    v457_14_cursor.descend_to_existing_byte(v457_14_byte);
    {
    let v458_2: Space = singleton(&v457_14_cursor.path()[v457_14_origin..(v457_14_origin + 1)]);
    let v458_3: Space = intersect(&(*CONSTANT_1),&(v458_2));
    let v458_4: Space = if has_head(&(v458_3)) { singleton(&[]) } else { Space::new() };
    drop(v458_3);
    let v458_5: Space = subtract(&(*CONSTANT_0),&(v458_4));
    drop(v458_4);
    let v458_8: Space = if (&(v458_5)).is_empty() { Space::new() } else {
      let v459_6: Path = concat_path(&(*p0),&v457_14_cursor.path()[v457_14_origin..(v457_14_origin + 1)]);
      let mut v459_7 = Space::new();
      let mut v459_7_write = v459_7.write_zipper();
      for v459_7_byte in v457_14_cursor.child_mask().iter() {
        v457_14_cursor.descend_to_existing_byte(v459_7_byte);
        {
        let v460_2: Space = singleton(&v457_14_cursor.path()[(v457_14_origin + 1)..(v457_14_origin + 2)]);
        let v460_3: Space = intersect(&(*CONSTANT_1),&(v460_2));
        let v460_4: Space = if has_head(&(v460_3)) { singleton(&[]) } else { Space::new() };
        drop(v460_3);
        let v460_5: Space = subtract(&(*CONSTANT_0),&(v460_4));
        drop(v460_4);
        let v460_8: Space = if (&(v460_5)).is_empty() { Space::new() } else {
          let v461_6: Path = concat_path(&(v459_6),&v457_14_cursor.path()[(v457_14_origin + 1)..(v457_14_origin + 2)]);
          let mut v461_7 = Space::new();
          let mut v461_7_write = v461_7.write_zipper();
          for v461_7_byte in v457_14_cursor.child_mask().iter() {
            v457_14_cursor.descend_to_existing_byte(v461_7_byte);
            {
            let v462_2: Space = singleton(&v457_14_cursor.path()[(v457_14_origin + 2)..(v457_14_origin + 3)]);
            let v462_3: Space = intersect(&(*CONSTANT_1),&(v462_2));
            let v462_4: Space = if has_head(&(v462_3)) { singleton(&[]) } else { Space::new() };
            drop(v462_3);
            let v462_5: Space = subtract(&(*CONSTANT_0),&(v462_4));
            drop(v462_4);
            let v462_8: Space = if (&(v462_5)).is_empty() { Space::new() } else {
              let v463_6: Path = concat_path(&(v461_6),&v457_14_cursor.path()[(v457_14_origin + 2)..(v457_14_origin + 3)]);
              let v463_7: Space = routine_38(c, &(v463_6), &v457_14_cursor);
              compose(&(v462_5),&(v463_7))
            };
            drop(v462_5);
            let v462_9: Space = intersect(&(*CONSTANT_1),&(v462_2));
            drop(v462_2);
            let v462_10: Space = if has_head(&(v462_9)) { singleton(&[]) } else { Space::new() };
            drop(v462_9);
            let v462_12: Space = if (&(v462_10)).is_empty() { Space::new() } else {
              let v464_6: Path = concat_path(&(v461_6),&v457_14_cursor.path()[(v457_14_origin + 2)..(v457_14_origin + 3)]);
              let v464_11: Space = routine_39(c, &(v464_6), &v457_14_cursor);
              drop(v464_6);
              compose(&(v462_10),&(v464_11))
            };
            drop(v462_10);
            let v462_13: Space = unite(&(v462_8),&(v462_12));
            join_wrapped_into(&mut v461_7_write,&((v462_13).read_zipper()),&[]);
            }
            v457_14_cursor.ascend(1);
          }
          drop(v461_7_write);
          compose(&(v460_5),&(v461_7))
        };
        drop(v460_5);
        let v460_9: Space = intersect(&(*CONSTANT_1),&(v460_2));
        drop(v460_2);
        let v460_10: Space = if has_head(&(v460_9)) { singleton(&[]) } else { Space::new() };
        drop(v460_9);
        let v460_12: Space = if (&(v460_10)).is_empty() { Space::new() } else {
          let v465_6: Path = concat_path(&(v459_6),&v457_14_cursor.path()[(v457_14_origin + 1)..(v457_14_origin + 2)]);
          let mut v465_11 = Space::new();
          let mut v465_11_write = v465_11.write_zipper();
          for v465_11_byte in v457_14_cursor.child_mask().iter() {
            v457_14_cursor.descend_to_existing_byte(v465_11_byte);
            {
            let v466_2: Space = singleton(&v457_14_cursor.path()[(v457_14_origin + 2)..(v457_14_origin + 3)]);
            let v466_3: Space = intersect(&(*CONSTANT_1),&(v466_2));
            let v466_4: Space = if has_head(&(v466_3)) { singleton(&[]) } else { Space::new() };
            drop(v466_3);
            let v466_5: Space = subtract(&(*CONSTANT_0),&(v466_4));
            drop(v466_4);
            let v466_8: Space = if (&(v466_5)).is_empty() { Space::new() } else {
              let v467_6: Path = concat_path(&(v465_6),&v457_14_cursor.path()[(v457_14_origin + 2)..(v457_14_origin + 3)]);
              let v467_7: Space = routine_38(c, &(v467_6), &v457_14_cursor);
              compose(&(v466_5),&(v467_7))
            };
            drop(v466_5);
            let v466_9: Space = intersect(&(*CONSTANT_1),&(v466_2));
            drop(v466_2);
            let v466_10: Space = if has_head(&(v466_9)) { singleton(&[]) } else { Space::new() };
            drop(v466_9);
            let v466_12: Space = if (&(v466_10)).is_empty() { Space::new() } else {
              let v468_6: Path = concat_path(&(v465_6),&v457_14_cursor.path()[(v457_14_origin + 2)..(v457_14_origin + 3)]);
              let v468_11: Space = routine_12(c, &(v468_6), &v457_14_cursor);
              drop(v468_6);
              compose(&(v466_10),&(v468_11))
            };
            drop(v466_10);
            let v466_13: Space = unite(&(v466_8),&(v466_12));
            join_wrapped_into(&mut v465_11_write,&((v466_13).read_zipper()),&[]);
            }
            v457_14_cursor.ascend(1);
          }
          drop(v465_11_write);
          drop(v465_6);
          compose(&(v460_10),&(v465_11))
        };
        drop(v460_10);
        let v460_13: Space = unite(&(v460_8),&(v460_12));
        join_wrapped_into(&mut v459_7_write,&((v460_13).read_zipper()),&[]);
        }
        v457_14_cursor.ascend(1);
      }
      drop(v459_7_write);
      drop(v459_6);
      compose(&(v458_5),&(v459_7))
    };
    drop(v458_5);
    let v458_9: Space = intersect(&(*CONSTANT_1),&(v458_2));
    drop(v458_2);
    let v458_10: Space = if has_head(&(v458_9)) { singleton(&[]) } else { Space::new() };
    drop(v458_9);
    let v458_11: Space = compose(&(v458_10),&v457_14_cursor);
    drop(v458_10);
    let v458_12: Space = unite(&(v458_8),&(v458_11));
    drop(v458_11);
    join_wrapped_into(&mut v457_14_write,&((v458_12).read_zipper()),&[]);
    }
    v457_14_cursor.ascend(1);
  }
  drop(v457_14_cursor);
  drop(v457_14_write);
  (v457_14).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v469_20 = Space::new();
  let mut v469_20_write = v469_20.write_zipper();
  let mut v469_20_cursor = (*s0).read_zipper();
  let v469_20_origin = v469_20_cursor.path().len();
  for v469_20_byte in v469_20_cursor.child_mask().iter() {
    v469_20_cursor.descend_to_existing_byte(v469_20_byte);
    {
    let v470_2: Space = singleton(&v469_20_cursor.path()[v469_20_origin..(v469_20_origin + 1)]);
    let v470_3: Space = intersect(&(*CONSTANT_1),&(v470_2));
    let v470_4: Space = if has_head(&(v470_3)) { singleton(&[]) } else { Space::new() };
    drop(v470_3);
    let v470_5: Space = subtract(&(*CONSTANT_0),&(v470_4));
    drop(v470_4);
    let v470_8: Space = if (&(v470_5)).is_empty() { Space::new() } else {
      let v471_6: Path = concat_path(&(*p0),&v469_20_cursor.path()[v469_20_origin..(v469_20_origin + 1)]);
      let mut v471_7 = Space::new();
      let mut v471_7_write = v471_7.write_zipper();
      for v471_7_byte in v469_20_cursor.child_mask().iter() {
        v469_20_cursor.descend_to_existing_byte(v471_7_byte);
        {
        let v472_2: Space = singleton(&v469_20_cursor.path()[(v469_20_origin + 1)..(v469_20_origin + 2)]);
        let v472_3: Space = intersect(&(*CONSTANT_1),&(v472_2));
        let v472_4: Space = if has_head(&(v472_3)) { singleton(&[]) } else { Space::new() };
        drop(v472_3);
        let v472_5: Space = subtract(&(*CONSTANT_0),&(v472_4));
        drop(v472_4);
        let v472_8: Space = if (&(v472_5)).is_empty() { Space::new() } else {
          let v473_6: Path = concat_path(&(v471_6),&v469_20_cursor.path()[(v469_20_origin + 1)..(v469_20_origin + 2)]);
          let mut v473_7 = Space::new();
          let mut v473_7_write = v473_7.write_zipper();
          for v473_7_byte in v469_20_cursor.child_mask().iter() {
            v469_20_cursor.descend_to_existing_byte(v473_7_byte);
            {
            let v474_2: Space = singleton(&v469_20_cursor.path()[(v469_20_origin + 2)..(v469_20_origin + 3)]);
            let v474_3: Space = intersect(&(*CONSTANT_1),&(v474_2));
            let v474_4: Space = if has_head(&(v474_3)) { singleton(&[]) } else { Space::new() };
            drop(v474_3);
            let v474_5: Space = subtract(&(*CONSTANT_0),&(v474_4));
            drop(v474_4);
            let v474_8: Space = if (&(v474_5)).is_empty() { Space::new() } else {
              let v475_6: Path = concat_path(&(v473_6),&v469_20_cursor.path()[(v469_20_origin + 2)..(v469_20_origin + 3)]);
              let v475_7: Space = routine_40(c, &(v475_6), &v469_20_cursor);
              compose(&(v474_5),&(v475_7))
            };
            drop(v474_5);
            let v474_9: Space = intersect(&(*CONSTANT_1),&(v474_2));
            drop(v474_2);
            let v474_10: Space = if has_head(&(v474_9)) { singleton(&[]) } else { Space::new() };
            drop(v474_9);
            let v474_12: Space = if (&(v474_10)).is_empty() { Space::new() } else {
              let v476_6: Path = concat_path(&(v473_6),&v469_20_cursor.path()[(v469_20_origin + 2)..(v469_20_origin + 3)]);
              let v476_11: Space = routine_41(c, &(v476_6), &v469_20_cursor);
              drop(v476_6);
              compose(&(v474_10),&(v476_11))
            };
            drop(v474_10);
            let v474_13: Space = unite(&(v474_8),&(v474_12));
            join_wrapped_into(&mut v473_7_write,&((v474_13).read_zipper()),&[]);
            }
            v469_20_cursor.ascend(1);
          }
          drop(v473_7_write);
          compose(&(v472_5),&(v473_7))
        };
        drop(v472_5);
        let v472_9: Space = intersect(&(*CONSTANT_1),&(v472_2));
        drop(v472_2);
        let v472_10: Space = if has_head(&(v472_9)) { singleton(&[]) } else { Space::new() };
        drop(v472_9);
        let v472_12: Space = if (&(v472_10)).is_empty() { Space::new() } else {
          let v477_6: Path = concat_path(&(v471_6),&v469_20_cursor.path()[(v469_20_origin + 1)..(v469_20_origin + 2)]);
          let mut v477_11 = Space::new();
          let mut v477_11_write = v477_11.write_zipper();
          for v477_11_byte in v469_20_cursor.child_mask().iter() {
            v469_20_cursor.descend_to_existing_byte(v477_11_byte);
            {
            let v478_2: Space = singleton(&v469_20_cursor.path()[(v469_20_origin + 2)..(v469_20_origin + 3)]);
            let v478_3: Space = intersect(&(*CONSTANT_1),&(v478_2));
            let v478_4: Space = if has_head(&(v478_3)) { singleton(&[]) } else { Space::new() };
            drop(v478_3);
            let v478_5: Space = subtract(&(*CONSTANT_0),&(v478_4));
            drop(v478_4);
            let v478_8: Space = if (&(v478_5)).is_empty() { Space::new() } else {
              let v479_6: Path = concat_path(&(v477_6),&v469_20_cursor.path()[(v469_20_origin + 2)..(v469_20_origin + 3)]);
              let v479_7: Space = routine_40(c, &(v479_6), &v469_20_cursor);
              compose(&(v478_5),&(v479_7))
            };
            drop(v478_5);
            let v478_9: Space = intersect(&(*CONSTANT_1),&(v478_2));
            drop(v478_2);
            let v478_10: Space = if has_head(&(v478_9)) { singleton(&[]) } else { Space::new() };
            drop(v478_9);
            let v478_12: Space = if (&(v478_10)).is_empty() { Space::new() } else {
              let v480_6: Path = concat_path(&(v477_6),&v469_20_cursor.path()[(v469_20_origin + 2)..(v469_20_origin + 3)]);
              let v480_11: Space = routine_15(c, &(v480_6), &v469_20_cursor);
              drop(v480_6);
              compose(&(v478_10),&(v480_11))
            };
            drop(v478_10);
            let v478_13: Space = unite(&(v478_8),&(v478_12));
            join_wrapped_into(&mut v477_11_write,&((v478_13).read_zipper()),&[]);
            }
            v469_20_cursor.ascend(1);
          }
          drop(v477_11_write);
          drop(v477_6);
          compose(&(v472_10),&(v477_11))
        };
        drop(v472_10);
        let v472_13: Space = unite(&(v472_8),&(v472_12));
        join_wrapped_into(&mut v471_7_write,&((v472_13).read_zipper()),&[]);
        }
        v469_20_cursor.ascend(1);
      }
      drop(v471_7_write);
      compose(&(v470_5),&(v471_7))
    };
    drop(v470_5);
    let v470_9: Space = intersect(&(*CONSTANT_1),&(v470_2));
    drop(v470_2);
    let v470_10: Space = if has_head(&(v470_9)) { singleton(&[]) } else { Space::new() };
    drop(v470_9);
    let v470_12: Space = if (&(v470_10)).is_empty() { Space::new() } else {
      let v481_6: Path = concat_path(&(*p0),&v469_20_cursor.path()[v469_20_origin..(v469_20_origin + 1)]);
      let mut v481_11 = Space::new();
      let mut v481_11_write = v481_11.write_zipper();
      for v481_11_byte in v469_20_cursor.child_mask().iter() {
        v469_20_cursor.descend_to_existing_byte(v481_11_byte);
        {
        let v482_2: Space = singleton(&v469_20_cursor.path()[(v469_20_origin + 1)..(v469_20_origin + 2)]);
        let v482_3: Space = intersect(&(*CONSTANT_1),&(v482_2));
        let v482_4: Space = if has_head(&(v482_3)) { singleton(&[]) } else { Space::new() };
        drop(v482_3);
        let v482_5: Space = subtract(&(*CONSTANT_0),&(v482_4));
        drop(v482_4);
        let v482_8: Space = if (&(v482_5)).is_empty() { Space::new() } else {
          let v483_6: Path = concat_path(&(v481_6),&v469_20_cursor.path()[(v469_20_origin + 1)..(v469_20_origin + 2)]);
          let mut v483_7 = Space::new();
          let mut v483_7_write = v483_7.write_zipper();
          for v483_7_byte in v469_20_cursor.child_mask().iter() {
            v469_20_cursor.descend_to_existing_byte(v483_7_byte);
            {
            let v484_2: Space = singleton(&v469_20_cursor.path()[(v469_20_origin + 2)..(v469_20_origin + 3)]);
            let v484_3: Space = intersect(&(*CONSTANT_1),&(v484_2));
            let v484_4: Space = if has_head(&(v484_3)) { singleton(&[]) } else { Space::new() };
            drop(v484_3);
            let v484_5: Space = subtract(&(*CONSTANT_0),&(v484_4));
            drop(v484_4);
            let v484_8: Space = if (&(v484_5)).is_empty() { Space::new() } else {
              let v485_6: Path = concat_path(&(v483_6),&v469_20_cursor.path()[(v469_20_origin + 2)..(v469_20_origin + 3)]);
              let v485_7: Space = routine_40(c, &(v485_6), &v469_20_cursor);
              compose(&(v484_5),&(v485_7))
            };
            drop(v484_5);
            let v484_9: Space = intersect(&(*CONSTANT_1),&(v484_2));
            drop(v484_2);
            let v484_10: Space = if has_head(&(v484_9)) { singleton(&[]) } else { Space::new() };
            drop(v484_9);
            let v484_12: Space = if (&(v484_10)).is_empty() { Space::new() } else {
              let v486_6: Path = concat_path(&(v483_6),&v469_20_cursor.path()[(v469_20_origin + 2)..(v469_20_origin + 3)]);
              let v486_11: Space = routine_41(c, &(v486_6), &v469_20_cursor);
              drop(v486_6);
              compose(&(v484_10),&(v486_11))
            };
            drop(v484_10);
            let v484_13: Space = unite(&(v484_8),&(v484_12));
            join_wrapped_into(&mut v483_7_write,&((v484_13).read_zipper()),&[]);
            }
            v469_20_cursor.ascend(1);
          }
          drop(v483_7_write);
          drop(v483_6);
          compose(&(v482_5),&(v483_7))
        };
        drop(v482_5);
        let v482_9: Space = intersect(&(*CONSTANT_1),&(v482_2));
        drop(v482_2);
        let v482_10: Space = if has_head(&(v482_9)) { singleton(&[]) } else { Space::new() };
        drop(v482_9);
        let v482_11: Space = compose(&(v482_10),&v469_20_cursor);
        drop(v482_10);
        let v482_12: Space = unite(&(v482_8),&(v482_11));
        drop(v482_11);
        join_wrapped_into(&mut v481_11_write,&((v482_12).read_zipper()),&[]);
        }
        v469_20_cursor.ascend(1);
      }
      drop(v481_11_write);
      drop(v481_6);
      compose(&(v470_10),&(v481_11))
    };
    drop(v470_10);
    let v470_13: Space = unite(&(v470_8),&(v470_12));
    join_wrapped_into(&mut v469_20_write,&((v470_13).read_zipper()),&[]);
    }
    v469_20_cursor.ascend(1);
  }
  drop(v469_20_cursor);
  drop(v469_20_write);
  (v469_20).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v487_14 = Space::new();
  let mut v487_14_write = v487_14.write_zipper();
  let mut v487_14_cursor = (*s0).read_zipper();
  let v487_14_origin = v487_14_cursor.path().len();
  for v487_14_byte in v487_14_cursor.child_mask().iter() {
    v487_14_cursor.descend_to_existing_byte(v487_14_byte);
    {
    let v488_2: Space = singleton(&v487_14_cursor.path()[v487_14_origin..(v487_14_origin + 1)]);
    let v488_3: Space = intersect(&(*CONSTANT_1),&(v488_2));
    let v488_4: Space = if has_head(&(v488_3)) { singleton(&[]) } else { Space::new() };
    drop(v488_3);
    let v488_5: Space = subtract(&(*CONSTANT_0),&(v488_4));
    drop(v488_4);
    let v488_8: Space = if (&(v488_5)).is_empty() { Space::new() } else {
      let v489_6: Path = concat_path(&(*p0),&v487_14_cursor.path()[v487_14_origin..(v487_14_origin + 1)]);
      let mut v489_7 = Space::new();
      let mut v489_7_write = v489_7.write_zipper();
      for v489_7_byte in v487_14_cursor.child_mask().iter() {
        v487_14_cursor.descend_to_existing_byte(v489_7_byte);
        {
        let v490_2: Space = singleton(&v487_14_cursor.path()[(v487_14_origin + 1)..(v487_14_origin + 2)]);
        let v490_3: Space = intersect(&(*CONSTANT_1),&(v490_2));
        let v490_4: Space = if has_head(&(v490_3)) { singleton(&[]) } else { Space::new() };
        drop(v490_3);
        let v490_5: Space = subtract(&(*CONSTANT_0),&(v490_4));
        drop(v490_4);
        let v490_8: Space = if (&(v490_5)).is_empty() { Space::new() } else {
          let v491_6: Path = concat_path(&(v489_6),&v487_14_cursor.path()[(v487_14_origin + 1)..(v487_14_origin + 2)]);
          let mut v491_7 = Space::new();
          let mut v491_7_write = v491_7.write_zipper();
          for v491_7_byte in v487_14_cursor.child_mask().iter() {
            v487_14_cursor.descend_to_existing_byte(v491_7_byte);
            {
            let v492_2: Space = singleton(&v487_14_cursor.path()[(v487_14_origin + 2)..(v487_14_origin + 3)]);
            let v492_3: Space = intersect(&(*CONSTANT_1),&(v492_2));
            let v492_4: Space = if has_head(&(v492_3)) { singleton(&[]) } else { Space::new() };
            drop(v492_3);
            let v492_5: Space = subtract(&(*CONSTANT_0),&(v492_4));
            drop(v492_4);
            let v492_8: Space = if (&(v492_5)).is_empty() { Space::new() } else {
              let v493_6: Path = concat_path(&(v491_6),&v487_14_cursor.path()[(v487_14_origin + 2)..(v487_14_origin + 3)]);
              let v493_7: Space = routine_40(c, &(v493_6), &v487_14_cursor);
              compose(&(v492_5),&(v493_7))
            };
            drop(v492_5);
            let v492_9: Space = intersect(&(*CONSTANT_1),&(v492_2));
            drop(v492_2);
            let v492_10: Space = if has_head(&(v492_9)) { singleton(&[]) } else { Space::new() };
            drop(v492_9);
            let v492_12: Space = if (&(v492_10)).is_empty() { Space::new() } else {
              let v494_6: Path = concat_path(&(v491_6),&v487_14_cursor.path()[(v487_14_origin + 2)..(v487_14_origin + 3)]);
              let v494_11: Space = routine_41(c, &(v494_6), &v487_14_cursor);
              drop(v494_6);
              compose(&(v492_10),&(v494_11))
            };
            drop(v492_10);
            let v492_13: Space = unite(&(v492_8),&(v492_12));
            join_wrapped_into(&mut v491_7_write,&((v492_13).read_zipper()),&[]);
            }
            v487_14_cursor.ascend(1);
          }
          drop(v491_7_write);
          compose(&(v490_5),&(v491_7))
        };
        drop(v490_5);
        let v490_9: Space = intersect(&(*CONSTANT_1),&(v490_2));
        drop(v490_2);
        let v490_10: Space = if has_head(&(v490_9)) { singleton(&[]) } else { Space::new() };
        drop(v490_9);
        let v490_12: Space = if (&(v490_10)).is_empty() { Space::new() } else {
          let v495_6: Path = concat_path(&(v489_6),&v487_14_cursor.path()[(v487_14_origin + 1)..(v487_14_origin + 2)]);
          let mut v495_11 = Space::new();
          let mut v495_11_write = v495_11.write_zipper();
          for v495_11_byte in v487_14_cursor.child_mask().iter() {
            v487_14_cursor.descend_to_existing_byte(v495_11_byte);
            {
            let v496_2: Space = singleton(&v487_14_cursor.path()[(v487_14_origin + 2)..(v487_14_origin + 3)]);
            let v496_3: Space = intersect(&(*CONSTANT_1),&(v496_2));
            let v496_4: Space = if has_head(&(v496_3)) { singleton(&[]) } else { Space::new() };
            drop(v496_3);
            let v496_5: Space = subtract(&(*CONSTANT_0),&(v496_4));
            drop(v496_4);
            let v496_8: Space = if (&(v496_5)).is_empty() { Space::new() } else {
              let v497_6: Path = concat_path(&(v495_6),&v487_14_cursor.path()[(v487_14_origin + 2)..(v487_14_origin + 3)]);
              let v497_7: Space = routine_40(c, &(v497_6), &v487_14_cursor);
              compose(&(v496_5),&(v497_7))
            };
            drop(v496_5);
            let v496_9: Space = intersect(&(*CONSTANT_1),&(v496_2));
            drop(v496_2);
            let v496_10: Space = if has_head(&(v496_9)) { singleton(&[]) } else { Space::new() };
            drop(v496_9);
            let v496_12: Space = if (&(v496_10)).is_empty() { Space::new() } else {
              let v498_6: Path = concat_path(&(v495_6),&v487_14_cursor.path()[(v487_14_origin + 2)..(v487_14_origin + 3)]);
              let v498_11: Space = routine_15(c, &(v498_6), &v487_14_cursor);
              drop(v498_6);
              compose(&(v496_10),&(v498_11))
            };
            drop(v496_10);
            let v496_13: Space = unite(&(v496_8),&(v496_12));
            join_wrapped_into(&mut v495_11_write,&((v496_13).read_zipper()),&[]);
            }
            v487_14_cursor.ascend(1);
          }
          drop(v495_11_write);
          drop(v495_6);
          compose(&(v490_10),&(v495_11))
        };
        drop(v490_10);
        let v490_13: Space = unite(&(v490_8),&(v490_12));
        join_wrapped_into(&mut v489_7_write,&((v490_13).read_zipper()),&[]);
        }
        v487_14_cursor.ascend(1);
      }
      drop(v489_7_write);
      drop(v489_6);
      compose(&(v488_5),&(v489_7))
    };
    drop(v488_5);
    let v488_9: Space = intersect(&(*CONSTANT_1),&(v488_2));
    drop(v488_2);
    let v488_10: Space = if has_head(&(v488_9)) { singleton(&[]) } else { Space::new() };
    drop(v488_9);
    let v488_11: Space = compose(&(v488_10),&v487_14_cursor);
    drop(v488_10);
    let v488_12: Space = unite(&(v488_8),&(v488_11));
    drop(v488_11);
    join_wrapped_into(&mut v487_14_write,&((v488_12).read_zipper()),&[]);
    }
    v487_14_cursor.ascend(1);
  }
  drop(v487_14_cursor);
  drop(v487_14_write);
  (v487_14).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v499_20 = Space::new();
  let mut v499_20_write = v499_20.write_zipper();
  let mut v499_20_cursor = (*s0).read_zipper();
  let v499_20_origin = v499_20_cursor.path().len();
  for v499_20_byte in v499_20_cursor.child_mask().iter() {
    v499_20_cursor.descend_to_existing_byte(v499_20_byte);
    {
    let v500_2: Space = singleton(&v499_20_cursor.path()[v499_20_origin..(v499_20_origin + 1)]);
    let v500_3: Space = intersect(&(*CONSTANT_1),&(v500_2));
    let v500_4: Space = if has_head(&(v500_3)) { singleton(&[]) } else { Space::new() };
    drop(v500_3);
    let v500_5: Space = subtract(&(*CONSTANT_0),&(v500_4));
    drop(v500_4);
    let v500_8: Space = if (&(v500_5)).is_empty() { Space::new() } else {
      let v501_6: Path = concat_path(&(*p0),&v499_20_cursor.path()[v499_20_origin..(v499_20_origin + 1)]);
      let mut v501_7 = Space::new();
      let mut v501_7_write = v501_7.write_zipper();
      for v501_7_byte in v499_20_cursor.child_mask().iter() {
        v499_20_cursor.descend_to_existing_byte(v501_7_byte);
        {
        let v502_2: Space = singleton(&v499_20_cursor.path()[(v499_20_origin + 1)..(v499_20_origin + 2)]);
        let v502_3: Space = intersect(&(*CONSTANT_1),&(v502_2));
        let v502_4: Space = if has_head(&(v502_3)) { singleton(&[]) } else { Space::new() };
        drop(v502_3);
        let v502_5: Space = subtract(&(*CONSTANT_0),&(v502_4));
        drop(v502_4);
        let v502_8: Space = if (&(v502_5)).is_empty() { Space::new() } else {
          let v503_6: Path = concat_path(&(v501_6),&v499_20_cursor.path()[(v499_20_origin + 1)..(v499_20_origin + 2)]);
          let mut v503_7 = Space::new();
          let mut v503_7_write = v503_7.write_zipper();
          for v503_7_byte in v499_20_cursor.child_mask().iter() {
            v499_20_cursor.descend_to_existing_byte(v503_7_byte);
            {
            let v504_2: Space = singleton(&v499_20_cursor.path()[(v499_20_origin + 2)..(v499_20_origin + 3)]);
            let v504_3: Space = intersect(&(*CONSTANT_1),&(v504_2));
            let v504_4: Space = if has_head(&(v504_3)) { singleton(&[]) } else { Space::new() };
            drop(v504_3);
            let v504_5: Space = subtract(&(*CONSTANT_0),&(v504_4));
            drop(v504_4);
            let v504_8: Space = if (&(v504_5)).is_empty() { Space::new() } else {
              let v505_6: Path = concat_path(&(v503_6),&v499_20_cursor.path()[(v499_20_origin + 2)..(v499_20_origin + 3)]);
              let v505_7: Space = routine_42(c, &(v505_6), &v499_20_cursor);
              compose(&(v504_5),&(v505_7))
            };
            drop(v504_5);
            let v504_9: Space = intersect(&(*CONSTANT_1),&(v504_2));
            drop(v504_2);
            let v504_10: Space = if has_head(&(v504_9)) { singleton(&[]) } else { Space::new() };
            drop(v504_9);
            let v504_12: Space = if (&(v504_10)).is_empty() { Space::new() } else {
              let v506_6: Path = concat_path(&(v503_6),&v499_20_cursor.path()[(v499_20_origin + 2)..(v499_20_origin + 3)]);
              let v506_11: Space = routine_43(c, &(v506_6), &v499_20_cursor);
              drop(v506_6);
              compose(&(v504_10),&(v506_11))
            };
            drop(v504_10);
            let v504_13: Space = unite(&(v504_8),&(v504_12));
            join_wrapped_into(&mut v503_7_write,&((v504_13).read_zipper()),&[]);
            }
            v499_20_cursor.ascend(1);
          }
          drop(v503_7_write);
          compose(&(v502_5),&(v503_7))
        };
        drop(v502_5);
        let v502_9: Space = intersect(&(*CONSTANT_1),&(v502_2));
        drop(v502_2);
        let v502_10: Space = if has_head(&(v502_9)) { singleton(&[]) } else { Space::new() };
        drop(v502_9);
        let v502_12: Space = if (&(v502_10)).is_empty() { Space::new() } else {
          let v507_6: Path = concat_path(&(v501_6),&v499_20_cursor.path()[(v499_20_origin + 1)..(v499_20_origin + 2)]);
          let mut v507_11 = Space::new();
          let mut v507_11_write = v507_11.write_zipper();
          for v507_11_byte in v499_20_cursor.child_mask().iter() {
            v499_20_cursor.descend_to_existing_byte(v507_11_byte);
            {
            let v508_2: Space = singleton(&v499_20_cursor.path()[(v499_20_origin + 2)..(v499_20_origin + 3)]);
            let v508_3: Space = intersect(&(*CONSTANT_1),&(v508_2));
            let v508_4: Space = if has_head(&(v508_3)) { singleton(&[]) } else { Space::new() };
            drop(v508_3);
            let v508_5: Space = subtract(&(*CONSTANT_0),&(v508_4));
            drop(v508_4);
            let v508_8: Space = if (&(v508_5)).is_empty() { Space::new() } else {
              let v509_6: Path = concat_path(&(v507_6),&v499_20_cursor.path()[(v499_20_origin + 2)..(v499_20_origin + 3)]);
              let v509_7: Space = routine_42(c, &(v509_6), &v499_20_cursor);
              compose(&(v508_5),&(v509_7))
            };
            drop(v508_5);
            let v508_9: Space = intersect(&(*CONSTANT_1),&(v508_2));
            drop(v508_2);
            let v508_10: Space = if has_head(&(v508_9)) { singleton(&[]) } else { Space::new() };
            drop(v508_9);
            let v508_12: Space = if (&(v508_10)).is_empty() { Space::new() } else {
              let v510_6: Path = concat_path(&(v507_6),&v499_20_cursor.path()[(v499_20_origin + 2)..(v499_20_origin + 3)]);
              let v510_11: Space = routine_12(c, &(v510_6), &v499_20_cursor);
              drop(v510_6);
              compose(&(v508_10),&(v510_11))
            };
            drop(v508_10);
            let v508_13: Space = unite(&(v508_8),&(v508_12));
            join_wrapped_into(&mut v507_11_write,&((v508_13).read_zipper()),&[]);
            }
            v499_20_cursor.ascend(1);
          }
          drop(v507_11_write);
          drop(v507_6);
          compose(&(v502_10),&(v507_11))
        };
        drop(v502_10);
        let v502_13: Space = unite(&(v502_8),&(v502_12));
        join_wrapped_into(&mut v501_7_write,&((v502_13).read_zipper()),&[]);
        }
        v499_20_cursor.ascend(1);
      }
      drop(v501_7_write);
      compose(&(v500_5),&(v501_7))
    };
    drop(v500_5);
    let v500_9: Space = intersect(&(*CONSTANT_1),&(v500_2));
    drop(v500_2);
    let v500_10: Space = if has_head(&(v500_9)) { singleton(&[]) } else { Space::new() };
    drop(v500_9);
    let v500_12: Space = if (&(v500_10)).is_empty() { Space::new() } else {
      let v511_6: Path = concat_path(&(*p0),&v499_20_cursor.path()[v499_20_origin..(v499_20_origin + 1)]);
      let mut v511_11 = Space::new();
      let mut v511_11_write = v511_11.write_zipper();
      for v511_11_byte in v499_20_cursor.child_mask().iter() {
        v499_20_cursor.descend_to_existing_byte(v511_11_byte);
        {
        let v512_2: Space = singleton(&v499_20_cursor.path()[(v499_20_origin + 1)..(v499_20_origin + 2)]);
        let v512_3: Space = intersect(&(*CONSTANT_1),&(v512_2));
        let v512_4: Space = if has_head(&(v512_3)) { singleton(&[]) } else { Space::new() };
        drop(v512_3);
        let v512_5: Space = subtract(&(*CONSTANT_0),&(v512_4));
        drop(v512_4);
        let v512_8: Space = if (&(v512_5)).is_empty() { Space::new() } else {
          let v513_6: Path = concat_path(&(v511_6),&v499_20_cursor.path()[(v499_20_origin + 1)..(v499_20_origin + 2)]);
          let mut v513_7 = Space::new();
          let mut v513_7_write = v513_7.write_zipper();
          for v513_7_byte in v499_20_cursor.child_mask().iter() {
            v499_20_cursor.descend_to_existing_byte(v513_7_byte);
            {
            let v514_2: Space = singleton(&v499_20_cursor.path()[(v499_20_origin + 2)..(v499_20_origin + 3)]);
            let v514_3: Space = intersect(&(*CONSTANT_1),&(v514_2));
            let v514_4: Space = if has_head(&(v514_3)) { singleton(&[]) } else { Space::new() };
            drop(v514_3);
            let v514_5: Space = subtract(&(*CONSTANT_0),&(v514_4));
            drop(v514_4);
            let v514_8: Space = if (&(v514_5)).is_empty() { Space::new() } else {
              let v515_6: Path = concat_path(&(v513_6),&v499_20_cursor.path()[(v499_20_origin + 2)..(v499_20_origin + 3)]);
              let v515_7: Space = routine_42(c, &(v515_6), &v499_20_cursor);
              compose(&(v514_5),&(v515_7))
            };
            drop(v514_5);
            let v514_9: Space = intersect(&(*CONSTANT_1),&(v514_2));
            drop(v514_2);
            let v514_10: Space = if has_head(&(v514_9)) { singleton(&[]) } else { Space::new() };
            drop(v514_9);
            let v514_12: Space = if (&(v514_10)).is_empty() { Space::new() } else {
              let v516_6: Path = concat_path(&(v513_6),&v499_20_cursor.path()[(v499_20_origin + 2)..(v499_20_origin + 3)]);
              let v516_11: Space = routine_43(c, &(v516_6), &v499_20_cursor);
              drop(v516_6);
              compose(&(v514_10),&(v516_11))
            };
            drop(v514_10);
            let v514_13: Space = unite(&(v514_8),&(v514_12));
            join_wrapped_into(&mut v513_7_write,&((v514_13).read_zipper()),&[]);
            }
            v499_20_cursor.ascend(1);
          }
          drop(v513_7_write);
          drop(v513_6);
          compose(&(v512_5),&(v513_7))
        };
        drop(v512_5);
        let v512_9: Space = intersect(&(*CONSTANT_1),&(v512_2));
        drop(v512_2);
        let v512_10: Space = if has_head(&(v512_9)) { singleton(&[]) } else { Space::new() };
        drop(v512_9);
        let v512_11: Space = compose(&(v512_10),&v499_20_cursor);
        drop(v512_10);
        let v512_12: Space = unite(&(v512_8),&(v512_11));
        drop(v512_11);
        join_wrapped_into(&mut v511_11_write,&((v512_12).read_zipper()),&[]);
        }
        v499_20_cursor.ascend(1);
      }
      drop(v511_11_write);
      drop(v511_6);
      compose(&(v500_10),&(v511_11))
    };
    drop(v500_10);
    let v500_13: Space = unite(&(v500_8),&(v500_12));
    join_wrapped_into(&mut v499_20_write,&((v500_13).read_zipper()),&[]);
    }
    v499_20_cursor.ascend(1);
  }
  drop(v499_20_cursor);
  drop(v499_20_write);
  (v499_20).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v517_14 = Space::new();
  let mut v517_14_write = v517_14.write_zipper();
  let mut v517_14_cursor = (*s0).read_zipper();
  let v517_14_origin = v517_14_cursor.path().len();
  for v517_14_byte in v517_14_cursor.child_mask().iter() {
    v517_14_cursor.descend_to_existing_byte(v517_14_byte);
    {
    let v518_2: Space = singleton(&v517_14_cursor.path()[v517_14_origin..(v517_14_origin + 1)]);
    let v518_3: Space = intersect(&(*CONSTANT_1),&(v518_2));
    let v518_4: Space = if has_head(&(v518_3)) { singleton(&[]) } else { Space::new() };
    drop(v518_3);
    let v518_5: Space = subtract(&(*CONSTANT_0),&(v518_4));
    drop(v518_4);
    let v518_8: Space = if (&(v518_5)).is_empty() { Space::new() } else {
      let v519_6: Path = concat_path(&(*p0),&v517_14_cursor.path()[v517_14_origin..(v517_14_origin + 1)]);
      let mut v519_7 = Space::new();
      let mut v519_7_write = v519_7.write_zipper();
      for v519_7_byte in v517_14_cursor.child_mask().iter() {
        v517_14_cursor.descend_to_existing_byte(v519_7_byte);
        {
        let v520_2: Space = singleton(&v517_14_cursor.path()[(v517_14_origin + 1)..(v517_14_origin + 2)]);
        let v520_3: Space = intersect(&(*CONSTANT_1),&(v520_2));
        let v520_4: Space = if has_head(&(v520_3)) { singleton(&[]) } else { Space::new() };
        drop(v520_3);
        let v520_5: Space = subtract(&(*CONSTANT_0),&(v520_4));
        drop(v520_4);
        let v520_8: Space = if (&(v520_5)).is_empty() { Space::new() } else {
          let v521_6: Path = concat_path(&(v519_6),&v517_14_cursor.path()[(v517_14_origin + 1)..(v517_14_origin + 2)]);
          let mut v521_7 = Space::new();
          let mut v521_7_write = v521_7.write_zipper();
          for v521_7_byte in v517_14_cursor.child_mask().iter() {
            v517_14_cursor.descend_to_existing_byte(v521_7_byte);
            {
            let v522_2: Space = singleton(&v517_14_cursor.path()[(v517_14_origin + 2)..(v517_14_origin + 3)]);
            let v522_3: Space = intersect(&(*CONSTANT_1),&(v522_2));
            let v522_4: Space = if has_head(&(v522_3)) { singleton(&[]) } else { Space::new() };
            drop(v522_3);
            let v522_5: Space = subtract(&(*CONSTANT_0),&(v522_4));
            drop(v522_4);
            let v522_8: Space = if (&(v522_5)).is_empty() { Space::new() } else {
              let v523_6: Path = concat_path(&(v521_6),&v517_14_cursor.path()[(v517_14_origin + 2)..(v517_14_origin + 3)]);
              let v523_7: Space = routine_42(c, &(v523_6), &v517_14_cursor);
              compose(&(v522_5),&(v523_7))
            };
            drop(v522_5);
            let v522_9: Space = intersect(&(*CONSTANT_1),&(v522_2));
            drop(v522_2);
            let v522_10: Space = if has_head(&(v522_9)) { singleton(&[]) } else { Space::new() };
            drop(v522_9);
            let v522_12: Space = if (&(v522_10)).is_empty() { Space::new() } else {
              let v524_6: Path = concat_path(&(v521_6),&v517_14_cursor.path()[(v517_14_origin + 2)..(v517_14_origin + 3)]);
              let v524_11: Space = routine_43(c, &(v524_6), &v517_14_cursor);
              drop(v524_6);
              compose(&(v522_10),&(v524_11))
            };
            drop(v522_10);
            let v522_13: Space = unite(&(v522_8),&(v522_12));
            join_wrapped_into(&mut v521_7_write,&((v522_13).read_zipper()),&[]);
            }
            v517_14_cursor.ascend(1);
          }
          drop(v521_7_write);
          compose(&(v520_5),&(v521_7))
        };
        drop(v520_5);
        let v520_9: Space = intersect(&(*CONSTANT_1),&(v520_2));
        drop(v520_2);
        let v520_10: Space = if has_head(&(v520_9)) { singleton(&[]) } else { Space::new() };
        drop(v520_9);
        let v520_12: Space = if (&(v520_10)).is_empty() { Space::new() } else {
          let v525_6: Path = concat_path(&(v519_6),&v517_14_cursor.path()[(v517_14_origin + 1)..(v517_14_origin + 2)]);
          let mut v525_11 = Space::new();
          let mut v525_11_write = v525_11.write_zipper();
          for v525_11_byte in v517_14_cursor.child_mask().iter() {
            v517_14_cursor.descend_to_existing_byte(v525_11_byte);
            {
            let v526_2: Space = singleton(&v517_14_cursor.path()[(v517_14_origin + 2)..(v517_14_origin + 3)]);
            let v526_3: Space = intersect(&(*CONSTANT_1),&(v526_2));
            let v526_4: Space = if has_head(&(v526_3)) { singleton(&[]) } else { Space::new() };
            drop(v526_3);
            let v526_5: Space = subtract(&(*CONSTANT_0),&(v526_4));
            drop(v526_4);
            let v526_8: Space = if (&(v526_5)).is_empty() { Space::new() } else {
              let v527_6: Path = concat_path(&(v525_6),&v517_14_cursor.path()[(v517_14_origin + 2)..(v517_14_origin + 3)]);
              let v527_7: Space = routine_42(c, &(v527_6), &v517_14_cursor);
              compose(&(v526_5),&(v527_7))
            };
            drop(v526_5);
            let v526_9: Space = intersect(&(*CONSTANT_1),&(v526_2));
            drop(v526_2);
            let v526_10: Space = if has_head(&(v526_9)) { singleton(&[]) } else { Space::new() };
            drop(v526_9);
            let v526_12: Space = if (&(v526_10)).is_empty() { Space::new() } else {
              let v528_6: Path = concat_path(&(v525_6),&v517_14_cursor.path()[(v517_14_origin + 2)..(v517_14_origin + 3)]);
              let v528_11: Space = routine_12(c, &(v528_6), &v517_14_cursor);
              drop(v528_6);
              compose(&(v526_10),&(v528_11))
            };
            drop(v526_10);
            let v526_13: Space = unite(&(v526_8),&(v526_12));
            join_wrapped_into(&mut v525_11_write,&((v526_13).read_zipper()),&[]);
            }
            v517_14_cursor.ascend(1);
          }
          drop(v525_11_write);
          drop(v525_6);
          compose(&(v520_10),&(v525_11))
        };
        drop(v520_10);
        let v520_13: Space = unite(&(v520_8),&(v520_12));
        join_wrapped_into(&mut v519_7_write,&((v520_13).read_zipper()),&[]);
        }
        v517_14_cursor.ascend(1);
      }
      drop(v519_7_write);
      drop(v519_6);
      compose(&(v518_5),&(v519_7))
    };
    drop(v518_5);
    let v518_9: Space = intersect(&(*CONSTANT_1),&(v518_2));
    drop(v518_2);
    let v518_10: Space = if has_head(&(v518_9)) { singleton(&[]) } else { Space::new() };
    drop(v518_9);
    let v518_11: Space = compose(&(v518_10),&v517_14_cursor);
    drop(v518_10);
    let v518_12: Space = unite(&(v518_8),&(v518_11));
    drop(v518_11);
    join_wrapped_into(&mut v517_14_write,&((v518_12).read_zipper()),&[]);
    }
    v517_14_cursor.ascend(1);
  }
  drop(v517_14_cursor);
  drop(v517_14_write);
  (v517_14).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v529_20 = Space::new();
  let mut v529_20_write = v529_20.write_zipper();
  let mut v529_20_cursor = (*s0).read_zipper();
  let v529_20_origin = v529_20_cursor.path().len();
  for v529_20_byte in v529_20_cursor.child_mask().iter() {
    v529_20_cursor.descend_to_existing_byte(v529_20_byte);
    {
    let v530_2: Space = singleton(&v529_20_cursor.path()[v529_20_origin..(v529_20_origin + 1)]);
    let v530_3: Space = intersect(&(*CONSTANT_1),&(v530_2));
    let v530_4: Space = if has_head(&(v530_3)) { singleton(&[]) } else { Space::new() };
    drop(v530_3);
    let v530_5: Space = subtract(&(*CONSTANT_0),&(v530_4));
    drop(v530_4);
    let v530_8: Space = if (&(v530_5)).is_empty() { Space::new() } else {
      let v531_6: Path = concat_path(&(*p0),&v529_20_cursor.path()[v529_20_origin..(v529_20_origin + 1)]);
      let mut v531_7 = Space::new();
      let mut v531_7_write = v531_7.write_zipper();
      for v531_7_byte in v529_20_cursor.child_mask().iter() {
        v529_20_cursor.descend_to_existing_byte(v531_7_byte);
        {
        let v532_2: Space = singleton(&v529_20_cursor.path()[(v529_20_origin + 1)..(v529_20_origin + 2)]);
        let v532_3: Space = intersect(&(*CONSTANT_1),&(v532_2));
        let v532_4: Space = if has_head(&(v532_3)) { singleton(&[]) } else { Space::new() };
        drop(v532_3);
        let v532_5: Space = subtract(&(*CONSTANT_0),&(v532_4));
        drop(v532_4);
        let v532_8: Space = if (&(v532_5)).is_empty() { Space::new() } else {
          let v533_6: Path = concat_path(&(v531_6),&v529_20_cursor.path()[(v529_20_origin + 1)..(v529_20_origin + 2)]);
          let mut v533_7 = Space::new();
          let mut v533_7_write = v533_7.write_zipper();
          for v533_7_byte in v529_20_cursor.child_mask().iter() {
            v529_20_cursor.descend_to_existing_byte(v533_7_byte);
            {
            let v534_2: Space = singleton(&v529_20_cursor.path()[(v529_20_origin + 2)..(v529_20_origin + 3)]);
            let v534_3: Space = intersect(&(*CONSTANT_1),&(v534_2));
            let v534_4: Space = if has_head(&(v534_3)) { singleton(&[]) } else { Space::new() };
            drop(v534_3);
            let v534_5: Space = subtract(&(*CONSTANT_0),&(v534_4));
            drop(v534_4);
            let v534_8: Space = if (&(v534_5)).is_empty() { Space::new() } else {
              let v535_6: Path = concat_path(&(v533_6),&v529_20_cursor.path()[(v529_20_origin + 2)..(v529_20_origin + 3)]);
              let v535_7: Space = routine_44(c, &(v535_6), &v529_20_cursor);
              compose(&(v534_5),&(v535_7))
            };
            drop(v534_5);
            let v534_9: Space = intersect(&(*CONSTANT_1),&(v534_2));
            drop(v534_2);
            let v534_10: Space = if has_head(&(v534_9)) { singleton(&[]) } else { Space::new() };
            drop(v534_9);
            let v534_12: Space = if (&(v534_10)).is_empty() { Space::new() } else {
              let v536_6: Path = concat_path(&(v533_6),&v529_20_cursor.path()[(v529_20_origin + 2)..(v529_20_origin + 3)]);
              let v536_11: Space = routine_45(c, &(v536_6), &v529_20_cursor);
              drop(v536_6);
              compose(&(v534_10),&(v536_11))
            };
            drop(v534_10);
            let v534_13: Space = unite(&(v534_8),&(v534_12));
            join_wrapped_into(&mut v533_7_write,&((v534_13).read_zipper()),&[]);
            }
            v529_20_cursor.ascend(1);
          }
          drop(v533_7_write);
          compose(&(v532_5),&(v533_7))
        };
        drop(v532_5);
        let v532_9: Space = intersect(&(*CONSTANT_1),&(v532_2));
        drop(v532_2);
        let v532_10: Space = if has_head(&(v532_9)) { singleton(&[]) } else { Space::new() };
        drop(v532_9);
        let v532_12: Space = if (&(v532_10)).is_empty() { Space::new() } else {
          let v537_6: Path = concat_path(&(v531_6),&v529_20_cursor.path()[(v529_20_origin + 1)..(v529_20_origin + 2)]);
          let mut v537_11 = Space::new();
          let mut v537_11_write = v537_11.write_zipper();
          for v537_11_byte in v529_20_cursor.child_mask().iter() {
            v529_20_cursor.descend_to_existing_byte(v537_11_byte);
            {
            let v538_2: Space = singleton(&v529_20_cursor.path()[(v529_20_origin + 2)..(v529_20_origin + 3)]);
            let v538_3: Space = intersect(&(*CONSTANT_1),&(v538_2));
            let v538_4: Space = if has_head(&(v538_3)) { singleton(&[]) } else { Space::new() };
            drop(v538_3);
            let v538_5: Space = subtract(&(*CONSTANT_0),&(v538_4));
            drop(v538_4);
            let v538_8: Space = if (&(v538_5)).is_empty() { Space::new() } else {
              let v539_6: Path = concat_path(&(v537_6),&v529_20_cursor.path()[(v529_20_origin + 2)..(v529_20_origin + 3)]);
              let v539_7: Space = routine_44(c, &(v539_6), &v529_20_cursor);
              compose(&(v538_5),&(v539_7))
            };
            drop(v538_5);
            let v538_9: Space = intersect(&(*CONSTANT_1),&(v538_2));
            drop(v538_2);
            let v538_10: Space = if has_head(&(v538_9)) { singleton(&[]) } else { Space::new() };
            drop(v538_9);
            let v538_12: Space = if (&(v538_10)).is_empty() { Space::new() } else {
              let v540_6: Path = concat_path(&(v537_6),&v529_20_cursor.path()[(v529_20_origin + 2)..(v529_20_origin + 3)]);
              let v540_11: Space = routine_15(c, &(v540_6), &v529_20_cursor);
              drop(v540_6);
              compose(&(v538_10),&(v540_11))
            };
            drop(v538_10);
            let v538_13: Space = unite(&(v538_8),&(v538_12));
            join_wrapped_into(&mut v537_11_write,&((v538_13).read_zipper()),&[]);
            }
            v529_20_cursor.ascend(1);
          }
          drop(v537_11_write);
          drop(v537_6);
          compose(&(v532_10),&(v537_11))
        };
        drop(v532_10);
        let v532_13: Space = unite(&(v532_8),&(v532_12));
        join_wrapped_into(&mut v531_7_write,&((v532_13).read_zipper()),&[]);
        }
        v529_20_cursor.ascend(1);
      }
      drop(v531_7_write);
      compose(&(v530_5),&(v531_7))
    };
    drop(v530_5);
    let v530_9: Space = intersect(&(*CONSTANT_1),&(v530_2));
    drop(v530_2);
    let v530_10: Space = if has_head(&(v530_9)) { singleton(&[]) } else { Space::new() };
    drop(v530_9);
    let v530_12: Space = if (&(v530_10)).is_empty() { Space::new() } else {
      let v541_6: Path = concat_path(&(*p0),&v529_20_cursor.path()[v529_20_origin..(v529_20_origin + 1)]);
      let mut v541_11 = Space::new();
      let mut v541_11_write = v541_11.write_zipper();
      for v541_11_byte in v529_20_cursor.child_mask().iter() {
        v529_20_cursor.descend_to_existing_byte(v541_11_byte);
        {
        let v542_2: Space = singleton(&v529_20_cursor.path()[(v529_20_origin + 1)..(v529_20_origin + 2)]);
        let v542_3: Space = intersect(&(*CONSTANT_1),&(v542_2));
        let v542_4: Space = if has_head(&(v542_3)) { singleton(&[]) } else { Space::new() };
        drop(v542_3);
        let v542_5: Space = subtract(&(*CONSTANT_0),&(v542_4));
        drop(v542_4);
        let v542_8: Space = if (&(v542_5)).is_empty() { Space::new() } else {
          let v543_6: Path = concat_path(&(v541_6),&v529_20_cursor.path()[(v529_20_origin + 1)..(v529_20_origin + 2)]);
          let mut v543_7 = Space::new();
          let mut v543_7_write = v543_7.write_zipper();
          for v543_7_byte in v529_20_cursor.child_mask().iter() {
            v529_20_cursor.descend_to_existing_byte(v543_7_byte);
            {
            let v544_2: Space = singleton(&v529_20_cursor.path()[(v529_20_origin + 2)..(v529_20_origin + 3)]);
            let v544_3: Space = intersect(&(*CONSTANT_1),&(v544_2));
            let v544_4: Space = if has_head(&(v544_3)) { singleton(&[]) } else { Space::new() };
            drop(v544_3);
            let v544_5: Space = subtract(&(*CONSTANT_0),&(v544_4));
            drop(v544_4);
            let v544_8: Space = if (&(v544_5)).is_empty() { Space::new() } else {
              let v545_6: Path = concat_path(&(v543_6),&v529_20_cursor.path()[(v529_20_origin + 2)..(v529_20_origin + 3)]);
              let v545_7: Space = routine_44(c, &(v545_6), &v529_20_cursor);
              compose(&(v544_5),&(v545_7))
            };
            drop(v544_5);
            let v544_9: Space = intersect(&(*CONSTANT_1),&(v544_2));
            drop(v544_2);
            let v544_10: Space = if has_head(&(v544_9)) { singleton(&[]) } else { Space::new() };
            drop(v544_9);
            let v544_12: Space = if (&(v544_10)).is_empty() { Space::new() } else {
              let v546_6: Path = concat_path(&(v543_6),&v529_20_cursor.path()[(v529_20_origin + 2)..(v529_20_origin + 3)]);
              let v546_11: Space = routine_45(c, &(v546_6), &v529_20_cursor);
              drop(v546_6);
              compose(&(v544_10),&(v546_11))
            };
            drop(v544_10);
            let v544_13: Space = unite(&(v544_8),&(v544_12));
            join_wrapped_into(&mut v543_7_write,&((v544_13).read_zipper()),&[]);
            }
            v529_20_cursor.ascend(1);
          }
          drop(v543_7_write);
          drop(v543_6);
          compose(&(v542_5),&(v543_7))
        };
        drop(v542_5);
        let v542_9: Space = intersect(&(*CONSTANT_1),&(v542_2));
        drop(v542_2);
        let v542_10: Space = if has_head(&(v542_9)) { singleton(&[]) } else { Space::new() };
        drop(v542_9);
        let v542_11: Space = compose(&(v542_10),&v529_20_cursor);
        drop(v542_10);
        let v542_12: Space = unite(&(v542_8),&(v542_11));
        drop(v542_11);
        join_wrapped_into(&mut v541_11_write,&((v542_12).read_zipper()),&[]);
        }
        v529_20_cursor.ascend(1);
      }
      drop(v541_11_write);
      drop(v541_6);
      compose(&(v530_10),&(v541_11))
    };
    drop(v530_10);
    let v530_13: Space = unite(&(v530_8),&(v530_12));
    join_wrapped_into(&mut v529_20_write,&((v530_13).read_zipper()),&[]);
    }
    v529_20_cursor.ascend(1);
  }
  drop(v529_20_cursor);
  drop(v529_20_write);
  (v529_20).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v547_14 = Space::new();
  let mut v547_14_write = v547_14.write_zipper();
  let mut v547_14_cursor = (*s0).read_zipper();
  let v547_14_origin = v547_14_cursor.path().len();
  for v547_14_byte in v547_14_cursor.child_mask().iter() {
    v547_14_cursor.descend_to_existing_byte(v547_14_byte);
    {
    let v548_2: Space = singleton(&v547_14_cursor.path()[v547_14_origin..(v547_14_origin + 1)]);
    let v548_3: Space = intersect(&(*CONSTANT_1),&(v548_2));
    let v548_4: Space = if has_head(&(v548_3)) { singleton(&[]) } else { Space::new() };
    drop(v548_3);
    let v548_5: Space = subtract(&(*CONSTANT_0),&(v548_4));
    drop(v548_4);
    let v548_8: Space = if (&(v548_5)).is_empty() { Space::new() } else {
      let v549_6: Path = concat_path(&(*p0),&v547_14_cursor.path()[v547_14_origin..(v547_14_origin + 1)]);
      let mut v549_7 = Space::new();
      let mut v549_7_write = v549_7.write_zipper();
      for v549_7_byte in v547_14_cursor.child_mask().iter() {
        v547_14_cursor.descend_to_existing_byte(v549_7_byte);
        {
        let v550_2: Space = singleton(&v547_14_cursor.path()[(v547_14_origin + 1)..(v547_14_origin + 2)]);
        let v550_3: Space = intersect(&(*CONSTANT_1),&(v550_2));
        let v550_4: Space = if has_head(&(v550_3)) { singleton(&[]) } else { Space::new() };
        drop(v550_3);
        let v550_5: Space = subtract(&(*CONSTANT_0),&(v550_4));
        drop(v550_4);
        let v550_8: Space = if (&(v550_5)).is_empty() { Space::new() } else {
          let v551_6: Path = concat_path(&(v549_6),&v547_14_cursor.path()[(v547_14_origin + 1)..(v547_14_origin + 2)]);
          let mut v551_7 = Space::new();
          let mut v551_7_write = v551_7.write_zipper();
          for v551_7_byte in v547_14_cursor.child_mask().iter() {
            v547_14_cursor.descend_to_existing_byte(v551_7_byte);
            {
            let v552_2: Space = singleton(&v547_14_cursor.path()[(v547_14_origin + 2)..(v547_14_origin + 3)]);
            let v552_3: Space = intersect(&(*CONSTANT_1),&(v552_2));
            let v552_4: Space = if has_head(&(v552_3)) { singleton(&[]) } else { Space::new() };
            drop(v552_3);
            let v552_5: Space = subtract(&(*CONSTANT_0),&(v552_4));
            drop(v552_4);
            let v552_8: Space = if (&(v552_5)).is_empty() { Space::new() } else {
              let v553_6: Path = concat_path(&(v551_6),&v547_14_cursor.path()[(v547_14_origin + 2)..(v547_14_origin + 3)]);
              let v553_7: Space = routine_44(c, &(v553_6), &v547_14_cursor);
              compose(&(v552_5),&(v553_7))
            };
            drop(v552_5);
            let v552_9: Space = intersect(&(*CONSTANT_1),&(v552_2));
            drop(v552_2);
            let v552_10: Space = if has_head(&(v552_9)) { singleton(&[]) } else { Space::new() };
            drop(v552_9);
            let v552_12: Space = if (&(v552_10)).is_empty() { Space::new() } else {
              let v554_6: Path = concat_path(&(v551_6),&v547_14_cursor.path()[(v547_14_origin + 2)..(v547_14_origin + 3)]);
              let v554_11: Space = routine_45(c, &(v554_6), &v547_14_cursor);
              drop(v554_6);
              compose(&(v552_10),&(v554_11))
            };
            drop(v552_10);
            let v552_13: Space = unite(&(v552_8),&(v552_12));
            join_wrapped_into(&mut v551_7_write,&((v552_13).read_zipper()),&[]);
            }
            v547_14_cursor.ascend(1);
          }
          drop(v551_7_write);
          compose(&(v550_5),&(v551_7))
        };
        drop(v550_5);
        let v550_9: Space = intersect(&(*CONSTANT_1),&(v550_2));
        drop(v550_2);
        let v550_10: Space = if has_head(&(v550_9)) { singleton(&[]) } else { Space::new() };
        drop(v550_9);
        let v550_12: Space = if (&(v550_10)).is_empty() { Space::new() } else {
          let v555_6: Path = concat_path(&(v549_6),&v547_14_cursor.path()[(v547_14_origin + 1)..(v547_14_origin + 2)]);
          let mut v555_11 = Space::new();
          let mut v555_11_write = v555_11.write_zipper();
          for v555_11_byte in v547_14_cursor.child_mask().iter() {
            v547_14_cursor.descend_to_existing_byte(v555_11_byte);
            {
            let v556_2: Space = singleton(&v547_14_cursor.path()[(v547_14_origin + 2)..(v547_14_origin + 3)]);
            let v556_3: Space = intersect(&(*CONSTANT_1),&(v556_2));
            let v556_4: Space = if has_head(&(v556_3)) { singleton(&[]) } else { Space::new() };
            drop(v556_3);
            let v556_5: Space = subtract(&(*CONSTANT_0),&(v556_4));
            drop(v556_4);
            let v556_8: Space = if (&(v556_5)).is_empty() { Space::new() } else {
              let v557_6: Path = concat_path(&(v555_6),&v547_14_cursor.path()[(v547_14_origin + 2)..(v547_14_origin + 3)]);
              let v557_7: Space = routine_44(c, &(v557_6), &v547_14_cursor);
              compose(&(v556_5),&(v557_7))
            };
            drop(v556_5);
            let v556_9: Space = intersect(&(*CONSTANT_1),&(v556_2));
            drop(v556_2);
            let v556_10: Space = if has_head(&(v556_9)) { singleton(&[]) } else { Space::new() };
            drop(v556_9);
            let v556_12: Space = if (&(v556_10)).is_empty() { Space::new() } else {
              let v558_6: Path = concat_path(&(v555_6),&v547_14_cursor.path()[(v547_14_origin + 2)..(v547_14_origin + 3)]);
              let v558_11: Space = routine_15(c, &(v558_6), &v547_14_cursor);
              drop(v558_6);
              compose(&(v556_10),&(v558_11))
            };
            drop(v556_10);
            let v556_13: Space = unite(&(v556_8),&(v556_12));
            join_wrapped_into(&mut v555_11_write,&((v556_13).read_zipper()),&[]);
            }
            v547_14_cursor.ascend(1);
          }
          drop(v555_11_write);
          drop(v555_6);
          compose(&(v550_10),&(v555_11))
        };
        drop(v550_10);
        let v550_13: Space = unite(&(v550_8),&(v550_12));
        join_wrapped_into(&mut v549_7_write,&((v550_13).read_zipper()),&[]);
        }
        v547_14_cursor.ascend(1);
      }
      drop(v549_7_write);
      drop(v549_6);
      compose(&(v548_5),&(v549_7))
    };
    drop(v548_5);
    let v548_9: Space = intersect(&(*CONSTANT_1),&(v548_2));
    drop(v548_2);
    let v548_10: Space = if has_head(&(v548_9)) { singleton(&[]) } else { Space::new() };
    drop(v548_9);
    let v548_11: Space = compose(&(v548_10),&v547_14_cursor);
    drop(v548_10);
    let v548_12: Space = unite(&(v548_8),&(v548_11));
    drop(v548_11);
    join_wrapped_into(&mut v547_14_write,&((v548_12).read_zipper()),&[]);
    }
    v547_14_cursor.ascend(1);
  }
  drop(v547_14_cursor);
  drop(v547_14_write);
  (v547_14).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v559_12 = Space::new();
  let mut v559_12_write = v559_12.write_zipper();
  let mut v559_12_cursor = (*s0).read_zipper();
  let v559_12_origin = v559_12_cursor.path().len();
  for v559_12_byte in v559_12_cursor.child_mask().iter() {
    v559_12_cursor.descend_to_existing_byte(v559_12_byte);
    {
    let v560_2: Space = singleton(&v559_12_cursor.path()[v559_12_origin..(v559_12_origin + 1)]);
    let v560_3: Space = intersect(&(*CONSTANT_1),&(v560_2));
    let v560_4: Space = if has_head(&(v560_3)) { singleton(&[]) } else { Space::new() };
    drop(v560_3);
    let v560_5: Space = subtract(&(*CONSTANT_0),&(v560_4));
    drop(v560_4);
    let v560_8: Space = if (&(v560_5)).is_empty() { Space::new() } else {
      let v561_6: Path = concat_path(&(*p0),&v559_12_cursor.path()[v559_12_origin..(v559_12_origin + 1)]);
      let mut v561_7 = Space::new();
      let mut v561_7_write = v561_7.write_zipper();
      for v561_7_byte in v559_12_cursor.child_mask().iter() {
        v559_12_cursor.descend_to_existing_byte(v561_7_byte);
        {
        let v562_2: Space = singleton(&v559_12_cursor.path()[(v559_12_origin + 1)..(v559_12_origin + 2)]);
        let v562_3: Space = intersect(&(*CONSTANT_1),&(v562_2));
        let v562_4: Space = if has_head(&(v562_3)) { singleton(&[]) } else { Space::new() };
        drop(v562_3);
        let v562_5: Space = subtract(&(*CONSTANT_0),&(v562_4));
        drop(v562_4);
        let v562_7: Space = if (&(v562_5)).is_empty() { Space::new() } else {
          let mut v563_6 = Space::new();
          let mut v563_6_write = v563_6.write_zipper();
          for v563_6_byte in v559_12_cursor.child_mask().iter() {
            v559_12_cursor.descend_to_existing_byte(v563_6_byte);
            {
            let v564_2: Space = Space::new();
            join_wrapped_into(&mut v563_6_write,&((v564_2).read_zipper()),&[]);
            }
            v559_12_cursor.ascend(1);
          }
          drop(v563_6_write);
          compose(&(v562_5),&(v563_6))
        };
        drop(v562_5);
        let v562_8: Space = intersect(&(*CONSTANT_1),&(v562_2));
        drop(v562_2);
        let v562_9: Space = if has_head(&(v562_8)) { singleton(&[]) } else { Space::new() };
        drop(v562_8);
        let v562_12: Space = if (&(v562_9)).is_empty() { Space::new() } else {
          let v565_10: Path = concat_path(&(v561_6),&v559_12_cursor.path()[(v559_12_origin + 1)..(v559_12_origin + 2)]);
          let mut v565_11 = Space::new();
          let mut v565_11_write = v565_11.write_zipper();
          for v565_11_byte in v559_12_cursor.child_mask().iter() {
            v559_12_cursor.descend_to_existing_byte(v565_11_byte);
            {
            let v566_2: Space = singleton(&v559_12_cursor.path()[(v559_12_origin + 2)..(v559_12_origin + 3)]);
            let v566_3: Space = intersect(&(*CONSTANT_1),&(v566_2));
            drop(v566_2);
            let v566_4: Space = if has_head(&(v566_3)) { singleton(&[]) } else { Space::new() };
            drop(v566_3);
            let v566_7: Space = if (&(v566_4)).is_empty() { Space::new() } else {
              let v567_5: Path = concat_path(&(v565_10),&v559_12_cursor.path()[(v559_12_origin + 2)..(v559_12_origin + 3)]);
              let v567_6: Space = routine_12(c, &(v567_5), &v559_12_cursor);
              drop(v567_5);
              compose(&(v566_4),&(v567_6))
            };
            drop(v566_4);
            join_wrapped_into(&mut v565_11_write,&((v566_7).read_zipper()),&[]);
            }
            v559_12_cursor.ascend(1);
          }
          drop(v565_11_write);
          drop(v565_10);
          compose(&(v562_9),&(v565_11))
        };
        drop(v562_9);
        let v562_13: Space = unite(&(v562_7),&(v562_12));
        drop(v562_7);
        join_wrapped_into(&mut v561_7_write,&((v562_13).read_zipper()),&[]);
        }
        v559_12_cursor.ascend(1);
      }
      drop(v561_7_write);
      drop(v561_6);
      compose(&(v560_5),&(v561_7))
    };
    drop(v560_5);
    let v560_9: Space = intersect(&(*CONSTANT_1),&(v560_2));
    drop(v560_2);
    let v560_10: Space = if has_head(&(v560_9)) { singleton(&[]) } else { Space::new() };
    drop(v560_9);
    let v560_12: Space = if (&(v560_10)).is_empty() { Space::new() } else {
      let mut v568_11 = Space::new();
      let mut v568_11_write = v568_11.write_zipper();
      for v568_11_byte in v559_12_cursor.child_mask().iter() {
        v559_12_cursor.descend_to_existing_byte(v568_11_byte);
        {
        let v569_2: Space = singleton(&v559_12_cursor.path()[(v559_12_origin + 1)..(v559_12_origin + 2)]);
        let v569_3: Space = intersect(&(*CONSTANT_1),&(v569_2));
        let v569_4: Space = if has_head(&(v569_3)) { singleton(&[]) } else { Space::new() };
        drop(v569_3);
        let v569_5: Space = subtract(&(*CONSTANT_0),&(v569_4));
        drop(v569_4);
        let v569_7: Space = if (&(v569_5)).is_empty() { Space::new() } else {
          let mut v570_6 = Space::new();
          let mut v570_6_write = v570_6.write_zipper();
          for v570_6_byte in v559_12_cursor.child_mask().iter() {
            v559_12_cursor.descend_to_existing_byte(v570_6_byte);
            {
            let v571_2: Space = Space::new();
            join_wrapped_into(&mut v570_6_write,&((v571_2).read_zipper()),&[]);
            }
            v559_12_cursor.ascend(1);
          }
          drop(v570_6_write);
          compose(&(v569_5),&(v570_6))
        };
        drop(v569_5);
        let v569_8: Space = intersect(&(*CONSTANT_1),&(v569_2));
        drop(v569_2);
        let v569_9: Space = if has_head(&(v569_8)) { singleton(&[]) } else { Space::new() };
        drop(v569_8);
        let v569_10: Space = compose(&(v569_9),&v559_12_cursor);
        drop(v569_9);
        let v569_11: Space = unite(&(v569_7),&(v569_10));
        drop(v569_7);
        drop(v569_10);
        join_wrapped_into(&mut v568_11_write,&((v569_11).read_zipper()),&[]);
        }
        v559_12_cursor.ascend(1);
      }
      drop(v568_11_write);
      compose(&(v560_10),&(v568_11))
    };
    drop(v560_10);
    let v560_13: Space = unite(&(v560_8),&(v560_12));
    drop(v560_12);
    join_wrapped_into(&mut v559_12_write,&((v560_13).read_zipper()),&[]);
    }
    v559_12_cursor.ascend(1);
  }
  drop(v559_12_cursor);
  drop(v559_12_write);
  (v559_12).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v572_9 = Space::new();
  let mut v572_9_write = v572_9.write_zipper();
  let mut v572_9_cursor = (*s0).read_zipper();
  let v572_9_origin = v572_9_cursor.path().len();
  for v572_9_byte in v572_9_cursor.child_mask().iter() {
    v572_9_cursor.descend_to_existing_byte(v572_9_byte);
    {
    let v573_2: Space = singleton(&v572_9_cursor.path()[v572_9_origin..(v572_9_origin + 1)]);
    let v573_3: Space = intersect(&(*CONSTANT_1),&(v573_2));
    let v573_4: Space = if has_head(&(v573_3)) { singleton(&[]) } else { Space::new() };
    drop(v573_3);
    let v573_5: Space = subtract(&(*CONSTANT_0),&(v573_4));
    drop(v573_4);
    let v573_8: Space = if (&(v573_5)).is_empty() { Space::new() } else {
      let v574_6: Path = concat_path(&(*p0),&v572_9_cursor.path()[v572_9_origin..(v572_9_origin + 1)]);
      let mut v574_7 = Space::new();
      let mut v574_7_write = v574_7.write_zipper();
      for v574_7_byte in v572_9_cursor.child_mask().iter() {
        v572_9_cursor.descend_to_existing_byte(v574_7_byte);
        {
        let v575_2: Space = singleton(&v572_9_cursor.path()[(v572_9_origin + 1)..(v572_9_origin + 2)]);
        let v575_3: Space = intersect(&(*CONSTANT_1),&(v575_2));
        let v575_4: Space = if has_head(&(v575_3)) { singleton(&[]) } else { Space::new() };
        drop(v575_3);
        let v575_5: Space = subtract(&(*CONSTANT_0),&(v575_4));
        drop(v575_4);
        let v575_7: Space = if (&(v575_5)).is_empty() { Space::new() } else {
          let mut v576_6 = Space::new();
          let mut v576_6_write = v576_6.write_zipper();
          for v576_6_byte in v572_9_cursor.child_mask().iter() {
            v572_9_cursor.descend_to_existing_byte(v576_6_byte);
            {
            let v577_2: Space = Space::new();
            join_wrapped_into(&mut v576_6_write,&((v577_2).read_zipper()),&[]);
            }
            v572_9_cursor.ascend(1);
          }
          drop(v576_6_write);
          compose(&(v575_5),&(v576_6))
        };
        drop(v575_5);
        let v575_8: Space = intersect(&(*CONSTANT_1),&(v575_2));
        drop(v575_2);
        let v575_9: Space = if has_head(&(v575_8)) { singleton(&[]) } else { Space::new() };
        drop(v575_8);
        let v575_12: Space = if (&(v575_9)).is_empty() { Space::new() } else {
          let v578_10: Path = concat_path(&(v574_6),&v572_9_cursor.path()[(v572_9_origin + 1)..(v572_9_origin + 2)]);
          let mut v578_11 = Space::new();
          let mut v578_11_write = v578_11.write_zipper();
          for v578_11_byte in v572_9_cursor.child_mask().iter() {
            v572_9_cursor.descend_to_existing_byte(v578_11_byte);
            {
            let v579_2: Space = singleton(&v572_9_cursor.path()[(v572_9_origin + 2)..(v572_9_origin + 3)]);
            let v579_3: Space = intersect(&(*CONSTANT_1),&(v579_2));
            drop(v579_2);
            let v579_4: Space = if has_head(&(v579_3)) { singleton(&[]) } else { Space::new() };
            drop(v579_3);
            let v579_7: Space = if (&(v579_4)).is_empty() { Space::new() } else {
              let v580_5: Path = concat_path(&(v578_10),&v572_9_cursor.path()[(v572_9_origin + 2)..(v572_9_origin + 3)]);
              let v580_6: Space = routine_12(c, &(v580_5), &v572_9_cursor);
              drop(v580_5);
              compose(&(v579_4),&(v580_6))
            };
            drop(v579_4);
            join_wrapped_into(&mut v578_11_write,&((v579_7).read_zipper()),&[]);
            }
            v572_9_cursor.ascend(1);
          }
          drop(v578_11_write);
          drop(v578_10);
          compose(&(v575_9),&(v578_11))
        };
        drop(v575_9);
        let v575_13: Space = unite(&(v575_7),&(v575_12));
        drop(v575_7);
        join_wrapped_into(&mut v574_7_write,&((v575_13).read_zipper()),&[]);
        }
        v572_9_cursor.ascend(1);
      }
      drop(v574_7_write);
      drop(v574_6);
      compose(&(v573_5),&(v574_7))
    };
    drop(v573_5);
    let v573_9: Space = intersect(&(*CONSTANT_1),&(v573_2));
    drop(v573_2);
    let v573_10: Space = if has_head(&(v573_9)) { singleton(&[]) } else { Space::new() };
    drop(v573_9);
    let v573_11: Space = compose(&(v573_10),&v572_9_cursor);
    drop(v573_10);
    let v573_12: Space = unite(&(v573_8),&(v573_11));
    drop(v573_11);
    join_wrapped_into(&mut v572_9_write,&((v573_12).read_zipper()),&[]);
    }
    v572_9_cursor.ascend(1);
  }
  drop(v572_9_cursor);
  drop(v572_9_write);
  (v572_9).clone()
}

fn routine_36(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v581_12 = Space::new();
  let mut v581_12_write = v581_12.write_zipper();
  let mut v581_12_cursor = (*s0).read_zipper();
  let v581_12_origin = v581_12_cursor.path().len();
  for v581_12_byte in v581_12_cursor.child_mask().iter() {
    v581_12_cursor.descend_to_existing_byte(v581_12_byte);
    {
    let v582_2: Space = singleton(&v581_12_cursor.path()[v581_12_origin..(v581_12_origin + 1)]);
    let v582_3: Space = intersect(&(*CONSTANT_1),&(v582_2));
    let v582_4: Space = if has_head(&(v582_3)) { singleton(&[]) } else { Space::new() };
    drop(v582_3);
    let v582_5: Space = subtract(&(*CONSTANT_0),&(v582_4));
    drop(v582_4);
    let v582_8: Space = if (&(v582_5)).is_empty() { Space::new() } else {
      let v583_6: Path = concat_path(&(*p0),&v581_12_cursor.path()[v581_12_origin..(v581_12_origin + 1)]);
      let mut v583_7 = Space::new();
      let mut v583_7_write = v583_7.write_zipper();
      for v583_7_byte in v581_12_cursor.child_mask().iter() {
        v581_12_cursor.descend_to_existing_byte(v583_7_byte);
        {
        let v584_2: Space = singleton(&v581_12_cursor.path()[(v581_12_origin + 1)..(v581_12_origin + 2)]);
        let v584_3: Space = intersect(&(*CONSTANT_1),&(v584_2));
        let v584_4: Space = if has_head(&(v584_3)) { singleton(&[]) } else { Space::new() };
        drop(v584_3);
        let v584_5: Space = subtract(&(*CONSTANT_0),&(v584_4));
        drop(v584_4);
        let v584_7: Space = if (&(v584_5)).is_empty() { Space::new() } else {
          let mut v585_6 = Space::new();
          let mut v585_6_write = v585_6.write_zipper();
          for v585_6_byte in v581_12_cursor.child_mask().iter() {
            v581_12_cursor.descend_to_existing_byte(v585_6_byte);
            {
            let v586_2: Space = Space::new();
            join_wrapped_into(&mut v585_6_write,&((v586_2).read_zipper()),&[]);
            }
            v581_12_cursor.ascend(1);
          }
          drop(v585_6_write);
          compose(&(v584_5),&(v585_6))
        };
        drop(v584_5);
        let v584_8: Space = intersect(&(*CONSTANT_1),&(v584_2));
        drop(v584_2);
        let v584_9: Space = if has_head(&(v584_8)) { singleton(&[]) } else { Space::new() };
        drop(v584_8);
        let v584_12: Space = if (&(v584_9)).is_empty() { Space::new() } else {
          let v587_10: Path = concat_path(&(v583_6),&v581_12_cursor.path()[(v581_12_origin + 1)..(v581_12_origin + 2)]);
          let mut v587_11 = Space::new();
          let mut v587_11_write = v587_11.write_zipper();
          for v587_11_byte in v581_12_cursor.child_mask().iter() {
            v581_12_cursor.descend_to_existing_byte(v587_11_byte);
            {
            let v588_2: Space = singleton(&v581_12_cursor.path()[(v581_12_origin + 2)..(v581_12_origin + 3)]);
            let v588_3: Space = intersect(&(*CONSTANT_1),&(v588_2));
            drop(v588_2);
            let v588_4: Space = if has_head(&(v588_3)) { singleton(&[]) } else { Space::new() };
            drop(v588_3);
            let v588_7: Space = if (&(v588_4)).is_empty() { Space::new() } else {
              let v589_5: Path = concat_path(&(v587_10),&v581_12_cursor.path()[(v581_12_origin + 2)..(v581_12_origin + 3)]);
              let v589_6: Space = routine_15(c, &(v589_5), &v581_12_cursor);
              drop(v589_5);
              compose(&(v588_4),&(v589_6))
            };
            drop(v588_4);
            join_wrapped_into(&mut v587_11_write,&((v588_7).read_zipper()),&[]);
            }
            v581_12_cursor.ascend(1);
          }
          drop(v587_11_write);
          drop(v587_10);
          compose(&(v584_9),&(v587_11))
        };
        drop(v584_9);
        let v584_13: Space = unite(&(v584_7),&(v584_12));
        drop(v584_7);
        join_wrapped_into(&mut v583_7_write,&((v584_13).read_zipper()),&[]);
        }
        v581_12_cursor.ascend(1);
      }
      drop(v583_7_write);
      drop(v583_6);
      compose(&(v582_5),&(v583_7))
    };
    drop(v582_5);
    let v582_9: Space = intersect(&(*CONSTANT_1),&(v582_2));
    drop(v582_2);
    let v582_10: Space = if has_head(&(v582_9)) { singleton(&[]) } else { Space::new() };
    drop(v582_9);
    let v582_12: Space = if (&(v582_10)).is_empty() { Space::new() } else {
      let mut v590_11 = Space::new();
      let mut v590_11_write = v590_11.write_zipper();
      for v590_11_byte in v581_12_cursor.child_mask().iter() {
        v581_12_cursor.descend_to_existing_byte(v590_11_byte);
        {
        let v591_2: Space = singleton(&v581_12_cursor.path()[(v581_12_origin + 1)..(v581_12_origin + 2)]);
        let v591_3: Space = intersect(&(*CONSTANT_1),&(v591_2));
        let v591_4: Space = if has_head(&(v591_3)) { singleton(&[]) } else { Space::new() };
        drop(v591_3);
        let v591_5: Space = subtract(&(*CONSTANT_0),&(v591_4));
        drop(v591_4);
        let v591_7: Space = if (&(v591_5)).is_empty() { Space::new() } else {
          let mut v592_6 = Space::new();
          let mut v592_6_write = v592_6.write_zipper();
          for v592_6_byte in v581_12_cursor.child_mask().iter() {
            v581_12_cursor.descend_to_existing_byte(v592_6_byte);
            {
            let v593_2: Space = Space::new();
            join_wrapped_into(&mut v592_6_write,&((v593_2).read_zipper()),&[]);
            }
            v581_12_cursor.ascend(1);
          }
          drop(v592_6_write);
          compose(&(v591_5),&(v592_6))
        };
        drop(v591_5);
        let v591_8: Space = intersect(&(*CONSTANT_1),&(v591_2));
        drop(v591_2);
        let v591_9: Space = if has_head(&(v591_8)) { singleton(&[]) } else { Space::new() };
        drop(v591_8);
        let v591_10: Space = compose(&(v591_9),&v581_12_cursor);
        drop(v591_9);
        let v591_11: Space = unite(&(v591_7),&(v591_10));
        drop(v591_7);
        drop(v591_10);
        join_wrapped_into(&mut v590_11_write,&((v591_11).read_zipper()),&[]);
        }
        v581_12_cursor.ascend(1);
      }
      drop(v590_11_write);
      compose(&(v582_10),&(v590_11))
    };
    drop(v582_10);
    let v582_13: Space = unite(&(v582_8),&(v582_12));
    drop(v582_12);
    join_wrapped_into(&mut v581_12_write,&((v582_13).read_zipper()),&[]);
    }
    v581_12_cursor.ascend(1);
  }
  drop(v581_12_cursor);
  drop(v581_12_write);
  (v581_12).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v594_9 = Space::new();
  let mut v594_9_write = v594_9.write_zipper();
  let mut v594_9_cursor = (*s0).read_zipper();
  let v594_9_origin = v594_9_cursor.path().len();
  for v594_9_byte in v594_9_cursor.child_mask().iter() {
    v594_9_cursor.descend_to_existing_byte(v594_9_byte);
    {
    let v595_2: Space = singleton(&v594_9_cursor.path()[v594_9_origin..(v594_9_origin + 1)]);
    let v595_3: Space = intersect(&(*CONSTANT_1),&(v595_2));
    let v595_4: Space = if has_head(&(v595_3)) { singleton(&[]) } else { Space::new() };
    drop(v595_3);
    let v595_5: Space = subtract(&(*CONSTANT_0),&(v595_4));
    drop(v595_4);
    let v595_8: Space = if (&(v595_5)).is_empty() { Space::new() } else {
      let v596_6: Path = concat_path(&(*p0),&v594_9_cursor.path()[v594_9_origin..(v594_9_origin + 1)]);
      let mut v596_7 = Space::new();
      let mut v596_7_write = v596_7.write_zipper();
      for v596_7_byte in v594_9_cursor.child_mask().iter() {
        v594_9_cursor.descend_to_existing_byte(v596_7_byte);
        {
        let v597_2: Space = singleton(&v594_9_cursor.path()[(v594_9_origin + 1)..(v594_9_origin + 2)]);
        let v597_3: Space = intersect(&(*CONSTANT_1),&(v597_2));
        let v597_4: Space = if has_head(&(v597_3)) { singleton(&[]) } else { Space::new() };
        drop(v597_3);
        let v597_5: Space = subtract(&(*CONSTANT_0),&(v597_4));
        drop(v597_4);
        let v597_7: Space = if (&(v597_5)).is_empty() { Space::new() } else {
          let mut v598_6 = Space::new();
          let mut v598_6_write = v598_6.write_zipper();
          for v598_6_byte in v594_9_cursor.child_mask().iter() {
            v594_9_cursor.descend_to_existing_byte(v598_6_byte);
            {
            let v599_2: Space = Space::new();
            join_wrapped_into(&mut v598_6_write,&((v599_2).read_zipper()),&[]);
            }
            v594_9_cursor.ascend(1);
          }
          drop(v598_6_write);
          compose(&(v597_5),&(v598_6))
        };
        drop(v597_5);
        let v597_8: Space = intersect(&(*CONSTANT_1),&(v597_2));
        drop(v597_2);
        let v597_9: Space = if has_head(&(v597_8)) { singleton(&[]) } else { Space::new() };
        drop(v597_8);
        let v597_12: Space = if (&(v597_9)).is_empty() { Space::new() } else {
          let v600_10: Path = concat_path(&(v596_6),&v594_9_cursor.path()[(v594_9_origin + 1)..(v594_9_origin + 2)]);
          let mut v600_11 = Space::new();
          let mut v600_11_write = v600_11.write_zipper();
          for v600_11_byte in v594_9_cursor.child_mask().iter() {
            v594_9_cursor.descend_to_existing_byte(v600_11_byte);
            {
            let v601_2: Space = singleton(&v594_9_cursor.path()[(v594_9_origin + 2)..(v594_9_origin + 3)]);
            let v601_3: Space = intersect(&(*CONSTANT_1),&(v601_2));
            drop(v601_2);
            let v601_4: Space = if has_head(&(v601_3)) { singleton(&[]) } else { Space::new() };
            drop(v601_3);
            let v601_7: Space = if (&(v601_4)).is_empty() { Space::new() } else {
              let v602_5: Path = concat_path(&(v600_10),&v594_9_cursor.path()[(v594_9_origin + 2)..(v594_9_origin + 3)]);
              let v602_6: Space = routine_15(c, &(v602_5), &v594_9_cursor);
              drop(v602_5);
              compose(&(v601_4),&(v602_6))
            };
            drop(v601_4);
            join_wrapped_into(&mut v600_11_write,&((v601_7).read_zipper()),&[]);
            }
            v594_9_cursor.ascend(1);
          }
          drop(v600_11_write);
          drop(v600_10);
          compose(&(v597_9),&(v600_11))
        };
        drop(v597_9);
        let v597_13: Space = unite(&(v597_7),&(v597_12));
        drop(v597_7);
        join_wrapped_into(&mut v596_7_write,&((v597_13).read_zipper()),&[]);
        }
        v594_9_cursor.ascend(1);
      }
      drop(v596_7_write);
      drop(v596_6);
      compose(&(v595_5),&(v596_7))
    };
    drop(v595_5);
    let v595_9: Space = intersect(&(*CONSTANT_1),&(v595_2));
    drop(v595_2);
    let v595_10: Space = if has_head(&(v595_9)) { singleton(&[]) } else { Space::new() };
    drop(v595_9);
    let v595_11: Space = compose(&(v595_10),&v594_9_cursor);
    drop(v595_10);
    let v595_12: Space = unite(&(v595_8),&(v595_11));
    drop(v595_11);
    join_wrapped_into(&mut v594_9_write,&((v595_12).read_zipper()),&[]);
    }
    v594_9_cursor.ascend(1);
  }
  drop(v594_9_cursor);
  drop(v594_9_write);
  (v594_9).clone()
}

fn routine_38(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v603_6 = Space::new();
  let mut v603_6_write = v603_6.write_zipper();
  let mut v603_6_cursor = (*s0).read_zipper();
  let v603_6_origin = v603_6_cursor.path().len();
  for v603_6_byte in v603_6_cursor.child_mask().iter() {
    v603_6_cursor.descend_to_existing_byte(v603_6_byte);
    {
    let v604_2: Space = singleton(&v603_6_cursor.path()[v603_6_origin..(v603_6_origin + 1)]);
    let v604_3: Space = intersect(&(*CONSTANT_1),&(v604_2));
    let v604_4: Space = if has_head(&(v604_3)) { singleton(&[]) } else { Space::new() };
    drop(v604_3);
    let v604_5: Space = subtract(&(*CONSTANT_0),&(v604_4));
    drop(v604_4);
    let v604_7: Space = if (&(v604_5)).is_empty() { Space::new() } else {
      let mut v605_6 = Space::new();
      let mut v605_6_write = v605_6.write_zipper();
      for v605_6_byte in v603_6_cursor.child_mask().iter() {
        v603_6_cursor.descend_to_existing_byte(v605_6_byte);
        {
        let v606_2: Space = Space::new();
        join_wrapped_into(&mut v605_6_write,&((v606_2).read_zipper()),&[]);
        }
        v603_6_cursor.ascend(1);
      }
      drop(v605_6_write);
      compose(&(v604_5),&(v605_6))
    };
    drop(v604_5);
    let v604_8: Space = intersect(&(*CONSTANT_1),&(v604_2));
    drop(v604_2);
    let v604_9: Space = if has_head(&(v604_8)) { singleton(&[]) } else { Space::new() };
    drop(v604_8);
    let v604_11: Space = if (&(v604_9)).is_empty() { Space::new() } else {
      let mut v607_10 = Space::new();
      let mut v607_10_write = v607_10.write_zipper();
      for v607_10_byte in v603_6_cursor.child_mask().iter() {
        v603_6_cursor.descend_to_existing_byte(v607_10_byte);
        {
        let v608_2: Space = singleton(&v603_6_cursor.path()[(v603_6_origin + 1)..(v603_6_origin + 2)]);
        let v608_3: Space = intersect(&(*CONSTANT_1),&(v608_2));
        drop(v608_2);
        let v608_4: Space = if has_head(&(v608_3)) { singleton(&[]) } else { Space::new() };
        drop(v608_3);
        let v608_5: Space = compose(&(v608_4),&v603_6_cursor);
        drop(v608_4);
        join_wrapped_into(&mut v607_10_write,&((v608_5).read_zipper()),&[]);
        }
        v603_6_cursor.ascend(1);
      }
      drop(v607_10_write);
      compose(&(v604_9),&(v607_10))
    };
    drop(v604_9);
    let v604_12: Space = unite(&(v604_7),&(v604_11));
    drop(v604_7);
    drop(v604_11);
    join_wrapped_into(&mut v603_6_write,&((v604_12).read_zipper()),&[]);
    }
    v603_6_cursor.ascend(1);
  }
  drop(v603_6_cursor);
  drop(v603_6_write);
  (v603_6).clone()
}

fn routine_39(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v609_5 = Space::new();
  let mut v609_5_write = v609_5.write_zipper();
  let mut v609_5_cursor = (*s0).read_zipper();
  let v609_5_origin = v609_5_cursor.path().len();
  for v609_5_byte in v609_5_cursor.child_mask().iter() {
    v609_5_cursor.descend_to_existing_byte(v609_5_byte);
    {
    let v610_2: Space = singleton(&v609_5_cursor.path()[v609_5_origin..(v609_5_origin + 1)]);
    let v610_3: Space = intersect(&(*CONSTANT_1),&(v610_2));
    let v610_4: Space = if has_head(&(v610_3)) { singleton(&[]) } else { Space::new() };
    drop(v610_3);
    let v610_5: Space = subtract(&(*CONSTANT_0),&(v610_4));
    drop(v610_4);
    let v610_7: Space = if (&(v610_5)).is_empty() { Space::new() } else {
      let mut v611_6 = Space::new();
      let mut v611_6_write = v611_6.write_zipper();
      for v611_6_byte in v609_5_cursor.child_mask().iter() {
        v609_5_cursor.descend_to_existing_byte(v611_6_byte);
        {
        let v612_2: Space = Space::new();
        join_wrapped_into(&mut v611_6_write,&((v612_2).read_zipper()),&[]);
        }
        v609_5_cursor.ascend(1);
      }
      drop(v611_6_write);
      compose(&(v610_5),&(v611_6))
    };
    drop(v610_5);
    let v610_8: Space = intersect(&(*CONSTANT_1),&(v610_2));
    drop(v610_2);
    let v610_9: Space = if has_head(&(v610_8)) { singleton(&[]) } else { Space::new() };
    drop(v610_8);
    let v610_10: Space = compose(&(v610_9),&v609_5_cursor);
    drop(v610_9);
    let v610_11: Space = unite(&(v610_7),&(v610_10));
    drop(v610_7);
    drop(v610_10);
    join_wrapped_into(&mut v609_5_write,&((v610_11).read_zipper()),&[]);
    }
    v609_5_cursor.ascend(1);
  }
  drop(v609_5_cursor);
  drop(v609_5_write);
  (v609_5).clone()
}

fn routine_40(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v613_6 = Space::new();
  let mut v613_6_write = v613_6.write_zipper();
  let mut v613_6_cursor = (*s0).read_zipper();
  let v613_6_origin = v613_6_cursor.path().len();
  for v613_6_byte in v613_6_cursor.child_mask().iter() {
    v613_6_cursor.descend_to_existing_byte(v613_6_byte);
    {
    let v614_2: Space = singleton(&v613_6_cursor.path()[v613_6_origin..(v613_6_origin + 1)]);
    let v614_3: Space = intersect(&(*CONSTANT_1),&(v614_2));
    let v614_4: Space = if has_head(&(v614_3)) { singleton(&[]) } else { Space::new() };
    drop(v614_3);
    let v614_5: Space = subtract(&(*CONSTANT_0),&(v614_4));
    drop(v614_4);
    let v614_7: Space = if (&(v614_5)).is_empty() { Space::new() } else {
      let mut v615_6 = Space::new();
      let mut v615_6_write = v615_6.write_zipper();
      for v615_6_byte in v613_6_cursor.child_mask().iter() {
        v613_6_cursor.descend_to_existing_byte(v615_6_byte);
        {
        let v616_2: Space = Space::new();
        join_wrapped_into(&mut v615_6_write,&((v616_2).read_zipper()),&[]);
        }
        v613_6_cursor.ascend(1);
      }
      drop(v615_6_write);
      compose(&(v614_5),&(v615_6))
    };
    drop(v614_5);
    let v614_8: Space = intersect(&(*CONSTANT_1),&(v614_2));
    drop(v614_2);
    let v614_9: Space = if has_head(&(v614_8)) { singleton(&[]) } else { Space::new() };
    drop(v614_8);
    let v614_11: Space = if (&(v614_9)).is_empty() { Space::new() } else {
      let mut v617_10 = Space::new();
      let mut v617_10_write = v617_10.write_zipper();
      for v617_10_byte in v613_6_cursor.child_mask().iter() {
        v613_6_cursor.descend_to_existing_byte(v617_10_byte);
        {
        let v618_2: Space = singleton(&v613_6_cursor.path()[(v613_6_origin + 1)..(v613_6_origin + 2)]);
        let v618_3: Space = intersect(&(*CONSTANT_1),&(v618_2));
        drop(v618_2);
        let v618_4: Space = if has_head(&(v618_3)) { singleton(&[]) } else { Space::new() };
        drop(v618_3);
        let v618_5: Space = compose(&(v618_4),&v613_6_cursor);
        drop(v618_4);
        join_wrapped_into(&mut v617_10_write,&((v618_5).read_zipper()),&[]);
        }
        v613_6_cursor.ascend(1);
      }
      drop(v617_10_write);
      compose(&(v614_9),&(v617_10))
    };
    drop(v614_9);
    let v614_12: Space = unite(&(v614_7),&(v614_11));
    drop(v614_7);
    drop(v614_11);
    join_wrapped_into(&mut v613_6_write,&((v614_12).read_zipper()),&[]);
    }
    v613_6_cursor.ascend(1);
  }
  drop(v613_6_cursor);
  drop(v613_6_write);
  (v613_6).clone()
}

fn routine_41(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v619_5 = Space::new();
  let mut v619_5_write = v619_5.write_zipper();
  let mut v619_5_cursor = (*s0).read_zipper();
  let v619_5_origin = v619_5_cursor.path().len();
  for v619_5_byte in v619_5_cursor.child_mask().iter() {
    v619_5_cursor.descend_to_existing_byte(v619_5_byte);
    {
    let v620_2: Space = singleton(&v619_5_cursor.path()[v619_5_origin..(v619_5_origin + 1)]);
    let v620_3: Space = intersect(&(*CONSTANT_1),&(v620_2));
    let v620_4: Space = if has_head(&(v620_3)) { singleton(&[]) } else { Space::new() };
    drop(v620_3);
    let v620_5: Space = subtract(&(*CONSTANT_0),&(v620_4));
    drop(v620_4);
    let v620_7: Space = if (&(v620_5)).is_empty() { Space::new() } else {
      let mut v621_6 = Space::new();
      let mut v621_6_write = v621_6.write_zipper();
      for v621_6_byte in v619_5_cursor.child_mask().iter() {
        v619_5_cursor.descend_to_existing_byte(v621_6_byte);
        {
        let v622_2: Space = Space::new();
        join_wrapped_into(&mut v621_6_write,&((v622_2).read_zipper()),&[]);
        }
        v619_5_cursor.ascend(1);
      }
      drop(v621_6_write);
      compose(&(v620_5),&(v621_6))
    };
    drop(v620_5);
    let v620_8: Space = intersect(&(*CONSTANT_1),&(v620_2));
    drop(v620_2);
    let v620_9: Space = if has_head(&(v620_8)) { singleton(&[]) } else { Space::new() };
    drop(v620_8);
    let v620_10: Space = compose(&(v620_9),&v619_5_cursor);
    drop(v620_9);
    let v620_11: Space = unite(&(v620_7),&(v620_10));
    drop(v620_7);
    drop(v620_10);
    join_wrapped_into(&mut v619_5_write,&((v620_11).read_zipper()),&[]);
    }
    v619_5_cursor.ascend(1);
  }
  drop(v619_5_cursor);
  drop(v619_5_write);
  (v619_5).clone()
}

fn routine_42(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v623_2 = Space::new();
  let mut v623_2_write = v623_2.write_zipper();
  let mut v623_2_cursor = (*s0).read_zipper();
  let v623_2_origin = v623_2_cursor.path().len();
  for v623_2_byte in v623_2_cursor.child_mask().iter() {
    v623_2_cursor.descend_to_existing_byte(v623_2_byte);
    {
    let v624_2: Space = Space::new();
    join_wrapped_into(&mut v623_2_write,&((v624_2).read_zipper()),&[]);
    }
    v623_2_cursor.ascend(1);
  }
  drop(v623_2_cursor);
  drop(v623_2_write);
  (v623_2).clone()
}

fn routine_43(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v625_3 = Space::new();
  let mut v625_3_write = v625_3.write_zipper();
  let mut v625_3_cursor = (*s0).read_zipper();
  let v625_3_origin = v625_3_cursor.path().len();
  for v625_3_byte in v625_3_cursor.child_mask().iter() {
    v625_3_cursor.descend_to_existing_byte(v625_3_byte);
    {
    let v626_2: Space = singleton(&v625_3_cursor.path()[v625_3_origin..(v625_3_origin + 1)]);
    let v626_3: Space = intersect(&(*CONSTANT_1),&(v626_2));
    drop(v626_2);
    let v626_4: Space = if has_head(&(v626_3)) { singleton(&[]) } else { Space::new() };
    drop(v626_3);
    let v626_5: Space = compose(&(v626_4),&v625_3_cursor);
    drop(v626_4);
    join_wrapped_into(&mut v625_3_write,&((v626_5).read_zipper()),&[]);
    }
    v625_3_cursor.ascend(1);
  }
  drop(v625_3_cursor);
  drop(v625_3_write);
  (v625_3).clone()
}

fn routine_44(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v627_2 = Space::new();
  let mut v627_2_write = v627_2.write_zipper();
  let mut v627_2_cursor = (*s0).read_zipper();
  let v627_2_origin = v627_2_cursor.path().len();
  for v627_2_byte in v627_2_cursor.child_mask().iter() {
    v627_2_cursor.descend_to_existing_byte(v627_2_byte);
    {
    let v628_2: Space = Space::new();
    join_wrapped_into(&mut v627_2_write,&((v628_2).read_zipper()),&[]);
    }
    v627_2_cursor.ascend(1);
  }
  drop(v627_2_cursor);
  drop(v627_2_write);
  (v627_2).clone()
}

fn routine_45(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v629_3 = Space::new();
  let mut v629_3_write = v629_3.write_zipper();
  let mut v629_3_cursor = (*s0).read_zipper();
  let v629_3_origin = v629_3_cursor.path().len();
  for v629_3_byte in v629_3_cursor.child_mask().iter() {
    v629_3_cursor.descend_to_existing_byte(v629_3_byte);
    {
    let v630_2: Space = singleton(&v629_3_cursor.path()[v629_3_origin..(v629_3_origin + 1)]);
    let v630_3: Space = intersect(&(*CONSTANT_1),&(v630_2));
    drop(v630_2);
    let v630_4: Space = if has_head(&(v630_3)) { singleton(&[]) } else { Space::new() };
    drop(v630_3);
    let v630_5: Space = compose(&(v630_4),&v629_3_cursor);
    drop(v630_4);
    join_wrapped_into(&mut v629_3_write,&((v630_5).read_zipper()),&[]);
    }
    v629_3_cursor.ascend(1);
  }
  drop(v629_3_cursor);
  drop(v629_3_write);
  (v629_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0),e.space(1)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
