#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1,0,1,0,0,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,0,0,1,0,0,0,1,1]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>, s1: Option<&Space>) -> Space {
  let mut v0_11 = Space::new();
  let mut v0_11_write = v0_11.write_zipper();
  let mut v0_11_cursor = (*s1.expect("unbound native input")).read_zipper();
  let v0_11_origin = v0_11_cursor.path().len();
  for v0_11_byte in v0_11_cursor.child_mask().iter() {
    v0_11_cursor.descend_to_existing_byte(v0_11_byte);
    {
    let v1_2: Space = singleton(&v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 1)]);
    let v1_3: Space = intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (&(v1_5)).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_write = v2_6.write_zipper();
      for v2_6_byte in v0_11_cursor.child_mask().iter() {
        v0_11_cursor.descend_to_existing_byte(v2_6_byte);
        {
        let v3_2: Space = singleton(&v0_11_cursor.path()[(v0_11_origin + 1)..(v0_11_origin + 2)]);
        let v3_3: Space = intersect(&(*CONSTANT_1),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_0),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (&(v3_5)).is_empty() { Space::new() } else {
          let v4_7: Space = routine_1(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_1),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (&(v3_10)).is_empty() { Space::new() } else {
          let v5_11: Space = routine_2(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        join_wrapped_into(&mut v2_6_write,&((v3_13).read_zipper()),&[]);
        }
        v0_11_cursor.ascend(1);
      }
      drop(v2_6_write);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (&(v1_9)).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_write = v6_10.write_zipper();
      for v6_10_byte in v0_11_cursor.child_mask().iter() {
        v0_11_cursor.descend_to_existing_byte(v6_10_byte);
        {
        let v7_2: Space = singleton(&v0_11_cursor.path()[(v0_11_origin + 1)..(v0_11_origin + 2)]);
        let v7_3: Space = intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (&(v7_5)).is_empty() { Space::new() } else {
          let v8_7: Space = routine_1(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (&(v7_10)).is_empty() { Space::new() } else {
          let v9_11: Space = routine_3(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        join_wrapped_into(&mut v6_10_write,&((v7_13).read_zipper()),&[]);
        }
        v0_11_cursor.ascend(1);
      }
      drop(v6_10_write);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    join_wrapped_into(&mut v0_11_write,&((v1_12).read_zipper()),&[]);
    }
    v0_11_cursor.ascend(1);
  }
  drop(v0_11_cursor);
  drop(v0_11_write);
  let v0_13: Space = wrap(&(v0_11),&(*CONSTANT_2));
  (v0_13).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v10_34 = Space::new();
  let mut v10_34_write = v10_34.write_zipper();
  let mut v10_34_cursor = (*s0).read_zipper();
  let v10_34_origin = v10_34_cursor.path().len();
  for v10_34_byte in v10_34_cursor.child_mask().iter() {
    v10_34_cursor.descend_to_existing_byte(v10_34_byte);
    {
    let v11_2: Space = singleton(&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]);
    let v11_3: Space = intersect(&(*CONSTANT_1),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (&(v11_5)).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]);
      let mut v12_7 = Space::new();
      let mut v12_7_write = v12_7.write_zipper();
      for v12_7_byte in v10_34_cursor.child_mask().iter() {
        v10_34_cursor.descend_to_existing_byte(v12_7_byte);
        {
        let v13_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
        let v13_3: Space = intersect(&(*CONSTANT_1),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_0),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (&(v13_5)).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v12_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
          let mut v14_7 = Space::new();
          let mut v14_7_write = v14_7.write_zipper();
          for v14_7_byte in v10_34_cursor.child_mask().iter() {
            v10_34_cursor.descend_to_existing_byte(v14_7_byte);
            {
            let v15_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
            let v15_3: Space = intersect(&(*CONSTANT_1),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (&(v15_5)).is_empty() { Space::new() } else {
              let v16_6: Path = concat_path(&(v14_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v16_7: Space = routine_4(c, &(v16_6), &v10_34_cursor, &(*s1));
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_1),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (&(v15_10)).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v14_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v17_11: Space = routine_5(c, &(v17_6), &v10_34_cursor, &(*s1));
              drop(v17_6);
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            join_wrapped_into(&mut v14_7_write,&((v15_13).read_zipper()),&[]);
            }
            v10_34_cursor.ascend(1);
          }
          drop(v14_7_write);
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_1),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (&(v13_10)).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v12_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
          let mut v18_11 = Space::new();
          let mut v18_11_write = v18_11.write_zipper();
          for v18_11_byte in v10_34_cursor.child_mask().iter() {
            v10_34_cursor.descend_to_existing_byte(v18_11_byte);
            {
            let v19_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
            let v19_3: Space = intersect(&(*CONSTANT_1),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
            drop(v19_4);
            let v19_8: Space = if (&(v19_5)).is_empty() { Space::new() } else {
              let v20_6: Path = concat_path(&(v18_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v20_7: Space = routine_4(c, &(v20_6), &v10_34_cursor, &(*s1));
              compose(&(v19_5),&(v20_7))
            };
            drop(v19_5);
            let v19_9: Space = intersect(&(*CONSTANT_1),&(v19_2));
            drop(v19_2);
            let v19_10: Space = if has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
            drop(v19_9);
            let v19_12: Space = if (&(v19_10)).is_empty() { Space::new() } else {
              let v21_6: Path = concat_path(&(v18_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v21_11: Space = routine_3(c, &(v21_6), &v10_34_cursor, &(*s1));
              drop(v21_6);
              compose(&(v19_10),&(v21_11))
            };
            drop(v19_10);
            let v19_13: Space = unite(&(v19_8),&(v19_12));
            join_wrapped_into(&mut v18_11_write,&((v19_13).read_zipper()),&[]);
            }
            v10_34_cursor.ascend(1);
          }
          drop(v18_11_write);
          drop(v18_6);
          compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        join_wrapped_into(&mut v12_7_write,&((v13_13).read_zipper()),&[]);
        }
        v10_34_cursor.ascend(1);
      }
      drop(v12_7_write);
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_1),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_13: Space = if (&(v11_10)).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]);
      let mut v22_12 = Space::new();
      let mut v22_12_write = v22_12.write_zipper();
      for v22_12_byte in v10_34_cursor.child_mask().iter() {
        v10_34_cursor.descend_to_existing_byte(v22_12_byte);
        {
        let v23_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
        let v23_3: Space = intersect(&(*CONSTANT_1),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_0),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (&(v23_5)).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v22_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
          let mut v24_7 = Space::new();
          let mut v24_7_write = v24_7.write_zipper();
          for v24_7_byte in v10_34_cursor.child_mask().iter() {
            v10_34_cursor.descend_to_existing_byte(v24_7_byte);
            {
            let v25_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
            let v25_3: Space = intersect(&(*CONSTANT_1),&(v25_2));
            let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
            drop(v25_3);
            let v25_5: Space = subtract(&(*CONSTANT_0),&(v25_4));
            drop(v25_4);
            let v25_8: Space = if (&(v25_5)).is_empty() { Space::new() } else {
              let v26_6: Path = concat_path(&(v24_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v26_7: Space = routine_4(c, &(v26_6), &v10_34_cursor, &(*s1));
              compose(&(v25_5),&(v26_7))
            };
            drop(v25_5);
            let v25_9: Space = intersect(&(*CONSTANT_1),&(v25_2));
            drop(v25_2);
            let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
            drop(v25_9);
            let v25_12: Space = if (&(v25_10)).is_empty() { Space::new() } else {
              let v27_6: Path = concat_path(&(v24_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v27_11: Space = routine_5(c, &(v27_6), &v10_34_cursor, &(*s1));
              drop(v27_6);
              compose(&(v25_10),&(v27_11))
            };
            drop(v25_10);
            let v25_13: Space = unite(&(v25_8),&(v25_12));
            join_wrapped_into(&mut v24_7_write,&((v25_13).read_zipper()),&[]);
            }
            v10_34_cursor.ascend(1);
          }
          drop(v24_7_write);
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_1),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_18: Space = if (&(v23_10)).is_empty() { Space::new() } else {
          let v28_12: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)])));
          let mut v28_13 = Space::new();
          let mut v28_13_write = v28_13.write_zipper();
          let mut v28_13_cursor = (v28_12).read_zipper();
          let v28_13_origin = v28_13_cursor.path().len();
          for v28_13_byte in v28_13_cursor.child_mask().iter() {
            v28_13_cursor.descend_to_existing_byte(v28_13_byte);
            {
            let v29_2: Space = singleton(&v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)]);
            let v29_3: Space = intersect(&(*CONSTANT_1),&(v29_2));
            let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
            drop(v29_3);
            let v29_5: Space = subtract(&(*CONSTANT_0),&(v29_4));
            drop(v29_4);
            let v29_7: Space = if (&(v29_5)).is_empty() { Space::new() } else {
              let v30_6: Space = routine_6(c, &v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)], &v28_13_cursor);
              compose(&(v29_5),&(v30_6))
            };
            drop(v29_5);
            let v29_8: Space = intersect(&(*CONSTANT_1),&(v29_2));
            drop(v29_2);
            let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
            drop(v29_8);
            let v29_11: Space = if (&(v29_9)).is_empty() { Space::new() } else {
              let v31_10: Space = routine_7(c, &v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)], &v28_13_cursor);
              compose(&(v29_9),&(v31_10))
            };
            drop(v29_9);
            let v29_12: Space = unite(&(v29_7),&(v29_11));
            join_wrapped_into(&mut v28_13_write,&((v29_12).read_zipper()),&[]);
            }
            v28_13_cursor.ascend(1);
          }
          drop(v28_13_cursor);
          drop(v28_13_write);
          drop(v28_12);
          let v28_14: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v28_13));
          let mut v28_15 = Space::new();
          let mut v28_15_write = v28_15.write_zipper();
          let mut v28_15_cursor = (v28_14).read_zipper();
          let v28_15_origin = v28_15_cursor.path().len();
          for v28_15_byte in v28_15_cursor.child_mask().iter() {
            v28_15_cursor.descend_to_existing_byte(v28_15_byte);
            {
            let v32_2: Space = singleton(&v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)]);
            let v32_3: Space = intersect(&(*CONSTANT_1),&(v32_2));
            let v32_4: Space = if has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
            drop(v32_3);
            let v32_5: Space = subtract(&(*CONSTANT_0),&(v32_4));
            drop(v32_4);
            let v32_7: Space = if (&(v32_5)).is_empty() { Space::new() } else {
              let v33_6: Space = routine_8(c, &v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)], &v28_15_cursor);
              compose(&(v32_5),&(v33_6))
            };
            drop(v32_5);
            let v32_8: Space = intersect(&(*CONSTANT_1),&(v32_2));
            drop(v32_2);
            let v32_9: Space = if has_head(&(v32_8)) { singleton(&[]) } else { Space::new() };
            drop(v32_8);
            let v32_11: Space = if (&(v32_9)).is_empty() { Space::new() } else {
              let v34_10: Space = routine_9(c, &v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)], &v28_15_cursor);
              compose(&(v32_9),&(v34_10))
            };
            drop(v32_9);
            let v32_12: Space = unite(&(v32_7),&(v32_11));
            join_wrapped_into(&mut v28_15_write,&((v32_12).read_zipper()),&[]);
            }
            v28_15_cursor.ascend(1);
          }
          drop(v28_15_cursor);
          drop(v28_15_write);
          let v28_16: Space = subtract(&(v28_15),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)])));
          let v28_17: Space = intersect(&(v28_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
          compose(&(v23_10),&(v28_17))
        };
        drop(v23_10);
        let v35_6: Path = concat_path(&(v22_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
        let v23_19: Space = wrap(&(v23_18),&(v35_6));
        let v23_20: Space = unite(&(v23_8),&(v23_19));
        join_wrapped_into(&mut v22_12_write,&((v23_20).read_zipper()),&[]);
        }
        v10_34_cursor.ascend(1);
      }
      drop(v22_12_write);
      drop(v22_6);
      compose(&(v11_10),&(v22_12))
    };
    drop(v11_10);
    let v11_14: Space = unite(&(v11_8),&(v11_13));
    join_wrapped_into(&mut v10_34_write,&((v11_14).read_zipper()),&[]);
    }
    v10_34_cursor.ascend(1);
  }
  drop(v10_34_cursor);
  drop(v10_34_write);
  (v10_34).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v36_40 = Space::new();
  let mut v36_40_write = v36_40.write_zipper();
  let mut v36_40_cursor = (*s0).read_zipper();
  let v36_40_origin = v36_40_cursor.path().len();
  for v36_40_byte in v36_40_cursor.child_mask().iter() {
    v36_40_cursor.descend_to_existing_byte(v36_40_byte);
    {
    let v37_2: Space = singleton(&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)]);
    let v37_3: Space = intersect(&(*CONSTANT_1),&(v37_2));
    let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
    drop(v37_3);
    let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
    drop(v37_4);
    let v37_8: Space = if (&(v37_5)).is_empty() { Space::new() } else {
      let v38_6: Path = concat_path(&(*p0),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)]);
      let mut v38_7 = Space::new();
      let mut v38_7_write = v38_7.write_zipper();
      for v38_7_byte in v36_40_cursor.child_mask().iter() {
        v36_40_cursor.descend_to_existing_byte(v38_7_byte);
        {
        let v39_2: Space = singleton(&v36_40_cursor.path()[(v36_40_origin + 1)..(v36_40_origin + 2)]);
        let v39_3: Space = intersect(&(*CONSTANT_1),&(v39_2));
        let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_8: Space = if (&(v39_5)).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v38_6),&v36_40_cursor.path()[(v36_40_origin + 1)..(v36_40_origin + 2)]);
          let mut v40_7 = Space::new();
          let mut v40_7_write = v40_7.write_zipper();
          for v40_7_byte in v36_40_cursor.child_mask().iter() {
            v36_40_cursor.descend_to_existing_byte(v40_7_byte);
            {
            let v41_2: Space = singleton(&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
            let v41_3: Space = intersect(&(*CONSTANT_1),&(v41_2));
            let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
            drop(v41_4);
            let v41_8: Space = if (&(v41_5)).is_empty() { Space::new() } else {
              let v42_6: Path = concat_path(&(v40_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v42_7: Space = routine_4(c, &(v42_6), &v36_40_cursor, &(*s1));
              compose(&(v41_5),&(v42_7))
            };
            drop(v41_5);
            let v41_9: Space = intersect(&(*CONSTANT_1),&(v41_2));
            drop(v41_2);
            let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
            drop(v41_9);
            let v41_12: Space = if (&(v41_10)).is_empty() { Space::new() } else {
              let v43_6: Path = concat_path(&(v40_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v43_11: Space = routine_5(c, &(v43_6), &v36_40_cursor, &(*s1));
              drop(v43_6);
              compose(&(v41_10),&(v43_11))
            };
            drop(v41_10);
            let v41_13: Space = unite(&(v41_8),&(v41_12));
            join_wrapped_into(&mut v40_7_write,&((v41_13).read_zipper()),&[]);
            }
            v36_40_cursor.ascend(1);
          }
          drop(v40_7_write);
          compose(&(v39_5),&(v40_7))
        };
        drop(v39_5);
        let v39_9: Space = intersect(&(*CONSTANT_1),&(v39_2));
        drop(v39_2);
        let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
        drop(v39_9);
        let v39_12: Space = if (&(v39_10)).is_empty() { Space::new() } else {
          let v44_6: Path = concat_path(&(v38_6),&v36_40_cursor.path()[(v36_40_origin + 1)..(v36_40_origin + 2)]);
          let mut v44_11 = Space::new();
          let mut v44_11_write = v44_11.write_zipper();
          for v44_11_byte in v36_40_cursor.child_mask().iter() {
            v36_40_cursor.descend_to_existing_byte(v44_11_byte);
            {
            let v45_2: Space = singleton(&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
            let v45_3: Space = intersect(&(*CONSTANT_1),&(v45_2));
            let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
            drop(v45_3);
            let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
            drop(v45_4);
            let v45_8: Space = if (&(v45_5)).is_empty() { Space::new() } else {
              let v46_6: Path = concat_path(&(v44_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v46_7: Space = routine_4(c, &(v46_6), &v36_40_cursor, &(*s1));
              compose(&(v45_5),&(v46_7))
            };
            drop(v45_5);
            let v45_9: Space = intersect(&(*CONSTANT_1),&(v45_2));
            drop(v45_2);
            let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
            drop(v45_9);
            let v45_12: Space = if (&(v45_10)).is_empty() { Space::new() } else {
              let v47_6: Path = concat_path(&(v44_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v47_11: Space = routine_3(c, &(v47_6), &v36_40_cursor, &(*s1));
              drop(v47_6);
              compose(&(v45_10),&(v47_11))
            };
            drop(v45_10);
            let v45_13: Space = unite(&(v45_8),&(v45_12));
            join_wrapped_into(&mut v44_11_write,&((v45_13).read_zipper()),&[]);
            }
            v36_40_cursor.ascend(1);
          }
          drop(v44_11_write);
          drop(v44_6);
          compose(&(v39_10),&(v44_11))
        };
        drop(v39_10);
        let v39_13: Space = unite(&(v39_8),&(v39_12));
        join_wrapped_into(&mut v38_7_write,&((v39_13).read_zipper()),&[]);
        }
        v36_40_cursor.ascend(1);
      }
      drop(v38_7_write);
      compose(&(v37_5),&(v38_7))
    };
    drop(v37_5);
    let v37_9: Space = intersect(&(*CONSTANT_1),&(v37_2));
    drop(v37_2);
    let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
    drop(v37_9);
    let v37_18: Space = if (&(v37_10)).is_empty() { Space::new() } else {
      let v48_12: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)])));
      let mut v48_13 = Space::new();
      let mut v48_13_write = v48_13.write_zipper();
      let mut v48_13_cursor = (v48_12).read_zipper();
      let v48_13_origin = v48_13_cursor.path().len();
      for v48_13_byte in v48_13_cursor.child_mask().iter() {
        v48_13_cursor.descend_to_existing_byte(v48_13_byte);
        {
        let v49_2: Space = singleton(&v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 1)]);
        let v49_3: Space = intersect(&(*CONSTANT_1),&(v49_2));
        let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
        drop(v49_3);
        let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
        drop(v49_4);
        let v49_7: Space = if (&(v49_5)).is_empty() { Space::new() } else {
          let mut v50_6 = Space::new();
          let mut v50_6_write = v50_6.write_zipper();
          for v50_6_byte in v48_13_cursor.child_mask().iter() {
            v48_13_cursor.descend_to_existing_byte(v50_6_byte);
            {
            let v51_2: Space = singleton(&v48_13_cursor.path()[(v48_13_origin + 1)..(v48_13_origin + 2)]);
            let v51_3: Space = intersect(&(*CONSTANT_1),&(v51_2));
            let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
            drop(v51_3);
            let v51_5: Space = subtract(&(*CONSTANT_0),&(v51_4));
            drop(v51_4);
            let v51_8: Space = if (&(v51_5)).is_empty() { Space::new() } else {
              let v52_7: Space = routine_10(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v51_5),&(v52_7))
            };
            drop(v51_5);
            let v51_9: Space = intersect(&(*CONSTANT_1),&(v51_2));
            drop(v51_2);
            let v51_10: Space = if has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
            drop(v51_9);
            let v51_12: Space = if (&(v51_10)).is_empty() { Space::new() } else {
              let v53_11: Space = routine_11(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v51_10),&(v53_11))
            };
            drop(v51_10);
            let v51_13: Space = unite(&(v51_8),&(v51_12));
            join_wrapped_into(&mut v50_6_write,&((v51_13).read_zipper()),&[]);
            }
            v48_13_cursor.ascend(1);
          }
          drop(v50_6_write);
          compose(&(v49_5),&(v50_6))
        };
        drop(v49_5);
        let v49_8: Space = intersect(&(*CONSTANT_1),&(v49_2));
        drop(v49_2);
        let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
        drop(v49_8);
        let v49_11: Space = if (&(v49_9)).is_empty() { Space::new() } else {
          let mut v54_10 = Space::new();
          let mut v54_10_write = v54_10.write_zipper();
          for v54_10_byte in v48_13_cursor.child_mask().iter() {
            v48_13_cursor.descend_to_existing_byte(v54_10_byte);
            {
            let v55_2: Space = singleton(&v48_13_cursor.path()[(v48_13_origin + 1)..(v48_13_origin + 2)]);
            let v55_3: Space = intersect(&(*CONSTANT_1),&(v55_2));
            let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
            drop(v55_3);
            let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
            drop(v55_4);
            let v55_8: Space = if (&(v55_5)).is_empty() { Space::new() } else {
              let v56_7: Space = routine_10(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v55_5),&(v56_7))
            };
            drop(v55_5);
            let v55_9: Space = intersect(&(*CONSTANT_1),&(v55_2));
            drop(v55_2);
            let v55_10: Space = if has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
            drop(v55_9);
            let v55_12: Space = if (&(v55_10)).is_empty() { Space::new() } else {
              let v57_11: Space = routine_12(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v55_10),&(v57_11))
            };
            drop(v55_10);
            let v55_13: Space = unite(&(v55_8),&(v55_12));
            join_wrapped_into(&mut v54_10_write,&((v55_13).read_zipper()),&[]);
            }
            v48_13_cursor.ascend(1);
          }
          drop(v54_10_write);
          compose(&(v49_9),&(v54_10))
        };
        drop(v49_9);
        let v49_12: Space = unite(&(v49_7),&(v49_11));
        join_wrapped_into(&mut v48_13_write,&((v49_12).read_zipper()),&[]);
        }
        v48_13_cursor.ascend(1);
      }
      drop(v48_13_cursor);
      drop(v48_13_write);
      drop(v48_12);
      let v48_14: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v48_13));
      let mut v48_15 = Space::new();
      let mut v48_15_write = v48_15.write_zipper();
      let mut v48_15_cursor = (v48_14).read_zipper();
      let v48_15_origin = v48_15_cursor.path().len();
      for v48_15_byte in v48_15_cursor.child_mask().iter() {
        v48_15_cursor.descend_to_existing_byte(v48_15_byte);
        {
        let v58_2: Space = singleton(&v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 1)]);
        let v58_3: Space = intersect(&(*CONSTANT_1),&(v58_2));
        let v58_4: Space = if has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
        drop(v58_3);
        let v58_5: Space = subtract(&(*CONSTANT_0),&(v58_4));
        drop(v58_4);
        let v58_7: Space = if (&(v58_5)).is_empty() { Space::new() } else {
          let mut v59_6 = Space::new();
          let mut v59_6_write = v59_6.write_zipper();
          for v59_6_byte in v48_15_cursor.child_mask().iter() {
            v48_15_cursor.descend_to_existing_byte(v59_6_byte);
            {
            let v60_2: Space = singleton(&v48_15_cursor.path()[(v48_15_origin + 1)..(v48_15_origin + 2)]);
            let v60_3: Space = intersect(&(*CONSTANT_1),&(v60_2));
            let v60_4: Space = if has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
            drop(v60_3);
            let v60_5: Space = subtract(&(*CONSTANT_0),&(v60_4));
            drop(v60_4);
            let v60_8: Space = if (&(v60_5)).is_empty() { Space::new() } else {
              let v61_7: Space = routine_13(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v60_5),&(v61_7))
            };
            drop(v60_5);
            let v60_9: Space = intersect(&(*CONSTANT_1),&(v60_2));
            drop(v60_2);
            let v60_10: Space = if has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
            drop(v60_9);
            let v60_12: Space = if (&(v60_10)).is_empty() { Space::new() } else {
              let v62_11: Space = routine_14(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v60_10),&(v62_11))
            };
            drop(v60_10);
            let v60_13: Space = unite(&(v60_8),&(v60_12));
            join_wrapped_into(&mut v59_6_write,&((v60_13).read_zipper()),&[]);
            }
            v48_15_cursor.ascend(1);
          }
          drop(v59_6_write);
          compose(&(v58_5),&(v59_6))
        };
        drop(v58_5);
        let v58_8: Space = intersect(&(*CONSTANT_1),&(v58_2));
        drop(v58_2);
        let v58_9: Space = if has_head(&(v58_8)) { singleton(&[]) } else { Space::new() };
        drop(v58_8);
        let v58_11: Space = if (&(v58_9)).is_empty() { Space::new() } else {
          let mut v63_10 = Space::new();
          let mut v63_10_write = v63_10.write_zipper();
          for v63_10_byte in v48_15_cursor.child_mask().iter() {
            v48_15_cursor.descend_to_existing_byte(v63_10_byte);
            {
            let v64_2: Space = singleton(&v48_15_cursor.path()[(v48_15_origin + 1)..(v48_15_origin + 2)]);
            let v64_3: Space = intersect(&(*CONSTANT_1),&(v64_2));
            let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
            drop(v64_3);
            let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
            drop(v64_4);
            let v64_8: Space = if (&(v64_5)).is_empty() { Space::new() } else {
              let v65_7: Space = routine_13(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v64_5),&(v65_7))
            };
            drop(v64_5);
            let v64_9: Space = intersect(&(*CONSTANT_1),&(v64_2));
            drop(v64_2);
            let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
            drop(v64_9);
            let v64_12: Space = if (&(v64_10)).is_empty() { Space::new() } else {
              let v66_11: Space = routine_15(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v64_10),&(v66_11))
            };
            drop(v64_10);
            let v64_13: Space = unite(&(v64_8),&(v64_12));
            join_wrapped_into(&mut v63_10_write,&((v64_13).read_zipper()),&[]);
            }
            v48_15_cursor.ascend(1);
          }
          drop(v63_10_write);
          compose(&(v58_9),&(v63_10))
        };
        drop(v58_9);
        let v58_12: Space = unite(&(v58_7),&(v58_11));
        join_wrapped_into(&mut v48_15_write,&((v58_12).read_zipper()),&[]);
        }
        v48_15_cursor.ascend(1);
      }
      drop(v48_15_cursor);
      drop(v48_15_write);
      let v48_16: Space = subtract(&(v48_15),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)])));
      let v48_17: Space = intersect(&(v48_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
      compose(&(v37_10),&(v48_17))
    };
    drop(v37_10);
    let v67_6: Path = concat_path(&(*p0),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)]);
    let v37_19: Space = wrap(&(v37_18),&(v67_6));
    let v37_20: Space = unite(&(v37_8),&(v37_19));
    join_wrapped_into(&mut v36_40_write,&((v37_20).read_zipper()),&[]);
    }
    v36_40_cursor.ascend(1);
  }
  drop(v36_40_cursor);
  drop(v36_40_write);
  (v36_40).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v68_8: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0))));
  let mut v68_27 = Space::new();
  let mut v68_27_write = v68_27.write_zipper();
  let mut v68_27_cursor = (v68_8).read_zipper();
  let v68_27_origin = v68_27_cursor.path().len();
  for v68_27_byte in v68_27_cursor.child_mask().iter() {
    v68_27_cursor.descend_to_existing_byte(v68_27_byte);
    {
    let v69_2: Space = singleton(&v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 1)]);
    let v69_3: Space = intersect(&(*CONSTANT_1),&(v69_2));
    let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
    drop(v69_3);
    let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
    drop(v69_4);
    let v69_7: Space = if (&(v69_5)).is_empty() { Space::new() } else {
      let mut v70_6 = Space::new();
      let mut v70_6_write = v70_6.write_zipper();
      for v70_6_byte in v68_27_cursor.child_mask().iter() {
        v68_27_cursor.descend_to_existing_byte(v70_6_byte);
        {
        let v71_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 1)..(v68_27_origin + 2)]);
        let v71_3: Space = intersect(&(*CONSTANT_1),&(v71_2));
        let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
        drop(v71_3);
        let v71_5: Space = subtract(&(*CONSTANT_0),&(v71_4));
        drop(v71_4);
        let v71_8: Space = if (&(v71_5)).is_empty() { Space::new() } else {
          let mut v72_7 = Space::new();
          let mut v72_7_write = v72_7.write_zipper();
          for v72_7_byte in v68_27_cursor.child_mask().iter() {
            v68_27_cursor.descend_to_existing_byte(v72_7_byte);
            {
            let v73_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 2)..(v68_27_origin + 3)]);
            let v73_3: Space = intersect(&(*CONSTANT_1),&(v73_2));
            let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
            drop(v73_3);
            let v73_5: Space = subtract(&(*CONSTANT_0),&(v73_4));
            drop(v73_4);
            let v73_8: Space = if (&(v73_5)).is_empty() { Space::new() } else {
              let v74_7: Space = routine_16(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v73_5),&(v74_7))
            };
            drop(v73_5);
            let v73_9: Space = intersect(&(*CONSTANT_1),&(v73_2));
            drop(v73_2);
            let v73_10: Space = if has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
            drop(v73_9);
            let v73_12: Space = if (&(v73_10)).is_empty() { Space::new() } else {
              let v75_11: Space = routine_17(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v73_10),&(v75_11))
            };
            drop(v73_10);
            let v73_13: Space = unite(&(v73_8),&(v73_12));
            join_wrapped_into(&mut v72_7_write,&((v73_13).read_zipper()),&[]);
            }
            v68_27_cursor.ascend(1);
          }
          drop(v72_7_write);
          compose(&(v71_5),&(v72_7))
        };
        drop(v71_5);
        let v71_9: Space = intersect(&(*CONSTANT_1),&(v71_2));
        drop(v71_2);
        let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
        drop(v71_9);
        let v71_12: Space = if (&(v71_10)).is_empty() { Space::new() } else {
          let mut v76_11 = Space::new();
          let mut v76_11_write = v76_11.write_zipper();
          for v76_11_byte in v68_27_cursor.child_mask().iter() {
            v68_27_cursor.descend_to_existing_byte(v76_11_byte);
            {
            let v77_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 2)..(v68_27_origin + 3)]);
            let v77_3: Space = intersect(&(*CONSTANT_1),&(v77_2));
            let v77_4: Space = if has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
            drop(v77_3);
            let v77_5: Space = subtract(&(*CONSTANT_0),&(v77_4));
            drop(v77_4);
            let v77_8: Space = if (&(v77_5)).is_empty() { Space::new() } else {
              let v78_7: Space = routine_16(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v77_5),&(v78_7))
            };
            drop(v77_5);
            let v77_9: Space = intersect(&(*CONSTANT_1),&(v77_2));
            drop(v77_2);
            let v77_10: Space = if has_head(&(v77_9)) { singleton(&[]) } else { Space::new() };
            drop(v77_9);
            let v77_12: Space = if (&(v77_10)).is_empty() { Space::new() } else {
              let v79_11: Space = routine_12(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v77_10),&(v79_11))
            };
            drop(v77_10);
            let v77_13: Space = unite(&(v77_8),&(v77_12));
            join_wrapped_into(&mut v76_11_write,&((v77_13).read_zipper()),&[]);
            }
            v68_27_cursor.ascend(1);
          }
          drop(v76_11_write);
          compose(&(v71_10),&(v76_11))
        };
        drop(v71_10);
        let v71_13: Space = unite(&(v71_8),&(v71_12));
        join_wrapped_into(&mut v70_6_write,&((v71_13).read_zipper()),&[]);
        }
        v68_27_cursor.ascend(1);
      }
      drop(v70_6_write);
      compose(&(v69_5),&(v70_6))
    };
    drop(v69_5);
    let v69_8: Space = intersect(&(*CONSTANT_1),&(v69_2));
    drop(v69_2);
    let v69_9: Space = if has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
    drop(v69_8);
    let v69_11: Space = if (&(v69_9)).is_empty() { Space::new() } else {
      let mut v80_10 = Space::new();
      let mut v80_10_write = v80_10.write_zipper();
      for v80_10_byte in v68_27_cursor.child_mask().iter() {
        v68_27_cursor.descend_to_existing_byte(v80_10_byte);
        {
        let v81_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 1)..(v68_27_origin + 2)]);
        let v81_3: Space = intersect(&(*CONSTANT_1),&(v81_2));
        let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
        drop(v81_3);
        let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
        drop(v81_4);
        let v81_8: Space = if (&(v81_5)).is_empty() { Space::new() } else {
          let mut v82_7 = Space::new();
          let mut v82_7_write = v82_7.write_zipper();
          for v82_7_byte in v68_27_cursor.child_mask().iter() {
            v68_27_cursor.descend_to_existing_byte(v82_7_byte);
            {
            let v83_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 2)..(v68_27_origin + 3)]);
            let v83_3: Space = intersect(&(*CONSTANT_1),&(v83_2));
            let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
            drop(v83_3);
            let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
            drop(v83_4);
            let v83_8: Space = if (&(v83_5)).is_empty() { Space::new() } else {
              let v84_7: Space = routine_16(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v83_5),&(v84_7))
            };
            drop(v83_5);
            let v83_9: Space = intersect(&(*CONSTANT_1),&(v83_2));
            drop(v83_2);
            let v83_10: Space = if has_head(&(v83_9)) { singleton(&[]) } else { Space::new() };
            drop(v83_9);
            let v83_12: Space = if (&(v83_10)).is_empty() { Space::new() } else {
              let v85_11: Space = routine_17(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              compose(&(v83_10),&(v85_11))
            };
            drop(v83_10);
            let v83_13: Space = unite(&(v83_8),&(v83_12));
            join_wrapped_into(&mut v82_7_write,&((v83_13).read_zipper()),&[]);
            }
            v68_27_cursor.ascend(1);
          }
          drop(v82_7_write);
          compose(&(v81_5),&(v82_7))
        };
        drop(v81_5);
        let v81_9: Space = intersect(&(*CONSTANT_1),&(v81_2));
        drop(v81_2);
        let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
        drop(v81_9);
        let v81_11: Space = compose(&(v81_10),&v68_27_cursor);
        drop(v81_10);
        let v81_12: Space = unite(&(v81_8),&(v81_11));
        drop(v81_11);
        join_wrapped_into(&mut v80_10_write,&((v81_12).read_zipper()),&[]);
        }
        v68_27_cursor.ascend(1);
      }
      drop(v80_10_write);
      compose(&(v69_9),&(v80_10))
    };
    drop(v69_9);
    let v69_12: Space = unite(&(v69_7),&(v69_11));
    join_wrapped_into(&mut v68_27_write,&((v69_12).read_zipper()),&[]);
    }
    v68_27_cursor.ascend(1);
  }
  drop(v68_27_cursor);
  drop(v68_27_write);
  drop(v68_8);
  let v68_28: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v68_27));
  let mut v68_47 = Space::new();
  let mut v68_47_write = v68_47.write_zipper();
  let mut v68_47_cursor = (v68_28).read_zipper();
  let v68_47_origin = v68_47_cursor.path().len();
  for v68_47_byte in v68_47_cursor.child_mask().iter() {
    v68_47_cursor.descend_to_existing_byte(v68_47_byte);
    {
    let v86_2: Space = singleton(&v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 1)]);
    let v86_3: Space = intersect(&(*CONSTANT_1),&(v86_2));
    let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
    drop(v86_3);
    let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
    drop(v86_4);
    let v86_7: Space = if (&(v86_5)).is_empty() { Space::new() } else {
      let mut v87_6 = Space::new();
      let mut v87_6_write = v87_6.write_zipper();
      for v87_6_byte in v68_47_cursor.child_mask().iter() {
        v68_47_cursor.descend_to_existing_byte(v87_6_byte);
        {
        let v88_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 1)..(v68_47_origin + 2)]);
        let v88_3: Space = intersect(&(*CONSTANT_1),&(v88_2));
        let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
        drop(v88_3);
        let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
        drop(v88_4);
        let v88_8: Space = if (&(v88_5)).is_empty() { Space::new() } else {
          let mut v89_7 = Space::new();
          let mut v89_7_write = v89_7.write_zipper();
          for v89_7_byte in v68_47_cursor.child_mask().iter() {
            v68_47_cursor.descend_to_existing_byte(v89_7_byte);
            {
            let v90_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 2)..(v68_47_origin + 3)]);
            let v90_3: Space = intersect(&(*CONSTANT_1),&(v90_2));
            let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
            drop(v90_3);
            let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
            drop(v90_4);
            let v90_8: Space = if (&(v90_5)).is_empty() { Space::new() } else {
              let v91_7: Space = routine_18(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v90_5),&(v91_7))
            };
            drop(v90_5);
            let v90_9: Space = intersect(&(*CONSTANT_1),&(v90_2));
            drop(v90_2);
            let v90_10: Space = if has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
            drop(v90_9);
            let v90_12: Space = if (&(v90_10)).is_empty() { Space::new() } else {
              let v92_11: Space = routine_19(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v90_10),&(v92_11))
            };
            drop(v90_10);
            let v90_13: Space = unite(&(v90_8),&(v90_12));
            join_wrapped_into(&mut v89_7_write,&((v90_13).read_zipper()),&[]);
            }
            v68_47_cursor.ascend(1);
          }
          drop(v89_7_write);
          compose(&(v88_5),&(v89_7))
        };
        drop(v88_5);
        let v88_9: Space = intersect(&(*CONSTANT_1),&(v88_2));
        drop(v88_2);
        let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
        drop(v88_9);
        let v88_12: Space = if (&(v88_10)).is_empty() { Space::new() } else {
          let mut v93_11 = Space::new();
          let mut v93_11_write = v93_11.write_zipper();
          for v93_11_byte in v68_47_cursor.child_mask().iter() {
            v68_47_cursor.descend_to_existing_byte(v93_11_byte);
            {
            let v94_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 2)..(v68_47_origin + 3)]);
            let v94_3: Space = intersect(&(*CONSTANT_1),&(v94_2));
            let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
            drop(v94_3);
            let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
            drop(v94_4);
            let v94_8: Space = if (&(v94_5)).is_empty() { Space::new() } else {
              let v95_7: Space = routine_18(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v94_5),&(v95_7))
            };
            drop(v94_5);
            let v94_9: Space = intersect(&(*CONSTANT_1),&(v94_2));
            drop(v94_2);
            let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
            drop(v94_9);
            let v94_12: Space = if (&(v94_10)).is_empty() { Space::new() } else {
              let v96_11: Space = routine_15(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v94_10),&(v96_11))
            };
            drop(v94_10);
            let v94_13: Space = unite(&(v94_8),&(v94_12));
            join_wrapped_into(&mut v93_11_write,&((v94_13).read_zipper()),&[]);
            }
            v68_47_cursor.ascend(1);
          }
          drop(v93_11_write);
          compose(&(v88_10),&(v93_11))
        };
        drop(v88_10);
        let v88_13: Space = unite(&(v88_8),&(v88_12));
        join_wrapped_into(&mut v87_6_write,&((v88_13).read_zipper()),&[]);
        }
        v68_47_cursor.ascend(1);
      }
      drop(v87_6_write);
      compose(&(v86_5),&(v87_6))
    };
    drop(v86_5);
    let v86_8: Space = intersect(&(*CONSTANT_1),&(v86_2));
    drop(v86_2);
    let v86_9: Space = if has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
    drop(v86_8);
    let v86_11: Space = if (&(v86_9)).is_empty() { Space::new() } else {
      let mut v97_10 = Space::new();
      let mut v97_10_write = v97_10.write_zipper();
      for v97_10_byte in v68_47_cursor.child_mask().iter() {
        v68_47_cursor.descend_to_existing_byte(v97_10_byte);
        {
        let v98_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 1)..(v68_47_origin + 2)]);
        let v98_3: Space = intersect(&(*CONSTANT_1),&(v98_2));
        let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
        drop(v98_3);
        let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
        drop(v98_4);
        let v98_8: Space = if (&(v98_5)).is_empty() { Space::new() } else {
          let mut v99_7 = Space::new();
          let mut v99_7_write = v99_7.write_zipper();
          for v99_7_byte in v68_47_cursor.child_mask().iter() {
            v68_47_cursor.descend_to_existing_byte(v99_7_byte);
            {
            let v100_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 2)..(v68_47_origin + 3)]);
            let v100_3: Space = intersect(&(*CONSTANT_1),&(v100_2));
            let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
            drop(v100_3);
            let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
            drop(v100_4);
            let v100_8: Space = if (&(v100_5)).is_empty() { Space::new() } else {
              let v101_7: Space = routine_18(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v100_5),&(v101_7))
            };
            drop(v100_5);
            let v100_9: Space = intersect(&(*CONSTANT_1),&(v100_2));
            drop(v100_2);
            let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
            drop(v100_9);
            let v100_12: Space = if (&(v100_10)).is_empty() { Space::new() } else {
              let v102_11: Space = routine_19(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              compose(&(v100_10),&(v102_11))
            };
            drop(v100_10);
            let v100_13: Space = unite(&(v100_8),&(v100_12));
            join_wrapped_into(&mut v99_7_write,&((v100_13).read_zipper()),&[]);
            }
            v68_47_cursor.ascend(1);
          }
          drop(v99_7_write);
          compose(&(v98_5),&(v99_7))
        };
        drop(v98_5);
        let v98_9: Space = intersect(&(*CONSTANT_1),&(v98_2));
        drop(v98_2);
        let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
        drop(v98_9);
        let v98_11: Space = compose(&(v98_10),&v68_47_cursor);
        drop(v98_10);
        let v98_12: Space = unite(&(v98_8),&(v98_11));
        drop(v98_11);
        join_wrapped_into(&mut v97_10_write,&((v98_12).read_zipper()),&[]);
        }
        v68_47_cursor.ascend(1);
      }
      drop(v97_10_write);
      compose(&(v86_9),&(v97_10))
    };
    drop(v86_9);
    let v86_12: Space = unite(&(v86_7),&(v86_11));
    join_wrapped_into(&mut v68_47_write,&((v86_12).read_zipper()),&[]);
    }
    v68_47_cursor.ascend(1);
  }
  drop(v68_47_cursor);
  drop(v68_47_write);
  let v68_48: Space = subtract(&(v68_47),&(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0))));
  let v68_51: Space = intersect(&(v68_48),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
  let v68_52: Space = wrap(&(v68_51),&(*p0));
  (v68_52).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v103_34 = Space::new();
  let mut v103_34_write = v103_34.write_zipper();
  let mut v103_34_cursor = (*s0).read_zipper();
  let v103_34_origin = v103_34_cursor.path().len();
  for v103_34_byte in v103_34_cursor.child_mask().iter() {
    v103_34_cursor.descend_to_existing_byte(v103_34_byte);
    {
    let v104_2: Space = singleton(&v103_34_cursor.path()[v103_34_origin..(v103_34_origin + 1)]);
    let v104_3: Space = intersect(&(*CONSTANT_1),&(v104_2));
    let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
    drop(v104_3);
    let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
    drop(v104_4);
    let v104_8: Space = if (&(v104_5)).is_empty() { Space::new() } else {
      let v105_6: Path = concat_path(&(*p0),&v103_34_cursor.path()[v103_34_origin..(v103_34_origin + 1)]);
      let mut v105_7 = Space::new();
      let mut v105_7_write = v105_7.write_zipper();
      for v105_7_byte in v103_34_cursor.child_mask().iter() {
        v103_34_cursor.descend_to_existing_byte(v105_7_byte);
        {
        let v106_2: Space = singleton(&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)]);
        let v106_3: Space = intersect(&(*CONSTANT_1),&(v106_2));
        let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
        drop(v106_3);
        let v106_5: Space = subtract(&(*CONSTANT_0),&(v106_4));
        drop(v106_4);
        let v106_8: Space = if (&(v106_5)).is_empty() { Space::new() } else {
          let v107_6: Path = concat_path(&(v105_6),&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)]);
          let mut v107_7 = Space::new();
          let mut v107_7_write = v107_7.write_zipper();
          for v107_7_byte in v103_34_cursor.child_mask().iter() {
            v103_34_cursor.descend_to_existing_byte(v107_7_byte);
            {
            let v108_2: Space = singleton(&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
            let v108_3: Space = intersect(&(*CONSTANT_1),&(v108_2));
            let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
            drop(v108_3);
            let v108_5: Space = subtract(&(*CONSTANT_0),&(v108_4));
            drop(v108_4);
            let v108_8: Space = if (&(v108_5)).is_empty() { Space::new() } else {
              let v109_6: Path = concat_path(&(v107_6),&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
              let v109_7: Space = routine_20(c, &(v109_6), &v103_34_cursor, &(*s1));
              compose(&(v108_5),&(v109_7))
            };
            drop(v108_5);
            let v108_9: Space = intersect(&(*CONSTANT_1),&(v108_2));
            drop(v108_2);
            let v108_10: Space = if has_head(&(v108_9)) { singleton(&[]) } else { Space::new() };
            drop(v108_9);
            let v108_12: Space = if (&(v108_10)).is_empty() { Space::new() } else {
              let v110_6: Path = concat_path(&(v107_6),&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
              let v110_11: Space = routine_21(c, &(v110_6), &v103_34_cursor, &(*s1));
              drop(v110_6);
              compose(&(v108_10),&(v110_11))
            };
            drop(v108_10);
            let v108_13: Space = unite(&(v108_8),&(v108_12));
            join_wrapped_into(&mut v107_7_write,&((v108_13).read_zipper()),&[]);
            }
            v103_34_cursor.ascend(1);
          }
          drop(v107_7_write);
          compose(&(v106_5),&(v107_7))
        };
        drop(v106_5);
        let v106_9: Space = intersect(&(*CONSTANT_1),&(v106_2));
        drop(v106_2);
        let v106_10: Space = if has_head(&(v106_9)) { singleton(&[]) } else { Space::new() };
        drop(v106_9);
        let v106_12: Space = if (&(v106_10)).is_empty() { Space::new() } else {
          let v111_6: Path = concat_path(&(v105_6),&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)]);
          let mut v111_11 = Space::new();
          let mut v111_11_write = v111_11.write_zipper();
          for v111_11_byte in v103_34_cursor.child_mask().iter() {
            v103_34_cursor.descend_to_existing_byte(v111_11_byte);
            {
            let v112_2: Space = singleton(&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
            let v112_3: Space = intersect(&(*CONSTANT_1),&(v112_2));
            let v112_4: Space = if has_head(&(v112_3)) { singleton(&[]) } else { Space::new() };
            drop(v112_3);
            let v112_5: Space = subtract(&(*CONSTANT_0),&(v112_4));
            drop(v112_4);
            let v112_8: Space = if (&(v112_5)).is_empty() { Space::new() } else {
              let v113_6: Path = concat_path(&(v111_6),&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
              let v113_7: Space = routine_20(c, &(v113_6), &v103_34_cursor, &(*s1));
              compose(&(v112_5),&(v113_7))
            };
            drop(v112_5);
            let v112_9: Space = intersect(&(*CONSTANT_1),&(v112_2));
            drop(v112_2);
            let v112_10: Space = if has_head(&(v112_9)) { singleton(&[]) } else { Space::new() };
            drop(v112_9);
            let v112_12: Space = if (&(v112_10)).is_empty() { Space::new() } else {
              let v114_6: Path = concat_path(&(v111_6),&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
              let v114_11: Space = routine_3(c, &(v114_6), &v103_34_cursor, &(*s1));
              drop(v114_6);
              compose(&(v112_10),&(v114_11))
            };
            drop(v112_10);
            let v112_13: Space = unite(&(v112_8),&(v112_12));
            join_wrapped_into(&mut v111_11_write,&((v112_13).read_zipper()),&[]);
            }
            v103_34_cursor.ascend(1);
          }
          drop(v111_11_write);
          drop(v111_6);
          compose(&(v106_10),&(v111_11))
        };
        drop(v106_10);
        let v106_13: Space = unite(&(v106_8),&(v106_12));
        join_wrapped_into(&mut v105_7_write,&((v106_13).read_zipper()),&[]);
        }
        v103_34_cursor.ascend(1);
      }
      drop(v105_7_write);
      compose(&(v104_5),&(v105_7))
    };
    drop(v104_5);
    let v104_9: Space = intersect(&(*CONSTANT_1),&(v104_2));
    drop(v104_2);
    let v104_10: Space = if has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
    drop(v104_9);
    let v104_13: Space = if (&(v104_10)).is_empty() { Space::new() } else {
      let v115_6: Path = concat_path(&(*p0),&v103_34_cursor.path()[v103_34_origin..(v103_34_origin + 1)]);
      let mut v115_12 = Space::new();
      let mut v115_12_write = v115_12.write_zipper();
      for v115_12_byte in v103_34_cursor.child_mask().iter() {
        v103_34_cursor.descend_to_existing_byte(v115_12_byte);
        {
        let v116_2: Space = singleton(&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)]);
        let v116_3: Space = intersect(&(*CONSTANT_1),&(v116_2));
        let v116_4: Space = if has_head(&(v116_3)) { singleton(&[]) } else { Space::new() };
        drop(v116_3);
        let v116_5: Space = subtract(&(*CONSTANT_0),&(v116_4));
        drop(v116_4);
        let v116_8: Space = if (&(v116_5)).is_empty() { Space::new() } else {
          let v117_6: Path = concat_path(&(v115_6),&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)]);
          let mut v117_7 = Space::new();
          let mut v117_7_write = v117_7.write_zipper();
          for v117_7_byte in v103_34_cursor.child_mask().iter() {
            v103_34_cursor.descend_to_existing_byte(v117_7_byte);
            {
            let v118_2: Space = singleton(&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
            let v118_3: Space = intersect(&(*CONSTANT_1),&(v118_2));
            let v118_4: Space = if has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
            drop(v118_3);
            let v118_5: Space = subtract(&(*CONSTANT_0),&(v118_4));
            drop(v118_4);
            let v118_8: Space = if (&(v118_5)).is_empty() { Space::new() } else {
              let v119_6: Path = concat_path(&(v117_6),&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
              let v119_7: Space = routine_20(c, &(v119_6), &v103_34_cursor, &(*s1));
              compose(&(v118_5),&(v119_7))
            };
            drop(v118_5);
            let v118_9: Space = intersect(&(*CONSTANT_1),&(v118_2));
            drop(v118_2);
            let v118_10: Space = if has_head(&(v118_9)) { singleton(&[]) } else { Space::new() };
            drop(v118_9);
            let v118_12: Space = if (&(v118_10)).is_empty() { Space::new() } else {
              let v120_6: Path = concat_path(&(v117_6),&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
              let v120_11: Space = routine_21(c, &(v120_6), &v103_34_cursor, &(*s1));
              drop(v120_6);
              compose(&(v118_10),&(v120_11))
            };
            drop(v118_10);
            let v118_13: Space = unite(&(v118_8),&(v118_12));
            join_wrapped_into(&mut v117_7_write,&((v118_13).read_zipper()),&[]);
            }
            v103_34_cursor.ascend(1);
          }
          drop(v117_7_write);
          compose(&(v116_5),&(v117_7))
        };
        drop(v116_5);
        let v116_9: Space = intersect(&(*CONSTANT_1),&(v116_2));
        drop(v116_2);
        let v116_10: Space = if has_head(&(v116_9)) { singleton(&[]) } else { Space::new() };
        drop(v116_9);
        let v116_18: Space = if (&(v116_10)).is_empty() { Space::new() } else {
          let v121_12: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v103_34_cursor.path()[v103_34_origin..(v103_34_origin + 1)]),&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)])));
          let mut v121_13 = Space::new();
          let mut v121_13_write = v121_13.write_zipper();
          let mut v121_13_cursor = (v121_12).read_zipper();
          let v121_13_origin = v121_13_cursor.path().len();
          for v121_13_byte in v121_13_cursor.child_mask().iter() {
            v121_13_cursor.descend_to_existing_byte(v121_13_byte);
            {
            let v122_2: Space = singleton(&v121_13_cursor.path()[v121_13_origin..(v121_13_origin + 1)]);
            let v122_3: Space = intersect(&(*CONSTANT_1),&(v122_2));
            let v122_4: Space = if has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
            drop(v122_3);
            let v122_5: Space = subtract(&(*CONSTANT_0),&(v122_4));
            drop(v122_4);
            let v122_7: Space = if (&(v122_5)).is_empty() { Space::new() } else {
              let v123_6: Space = routine_6(c, &v121_13_cursor.path()[v121_13_origin..(v121_13_origin + 1)], &v121_13_cursor);
              compose(&(v122_5),&(v123_6))
            };
            drop(v122_5);
            let v122_8: Space = intersect(&(*CONSTANT_1),&(v122_2));
            drop(v122_2);
            let v122_9: Space = if has_head(&(v122_8)) { singleton(&[]) } else { Space::new() };
            drop(v122_8);
            let v122_11: Space = if (&(v122_9)).is_empty() { Space::new() } else {
              let v124_10: Space = routine_7(c, &v121_13_cursor.path()[v121_13_origin..(v121_13_origin + 1)], &v121_13_cursor);
              compose(&(v122_9),&(v124_10))
            };
            drop(v122_9);
            let v122_12: Space = unite(&(v122_7),&(v122_11));
            join_wrapped_into(&mut v121_13_write,&((v122_12).read_zipper()),&[]);
            }
            v121_13_cursor.ascend(1);
          }
          drop(v121_13_cursor);
          drop(v121_13_write);
          drop(v121_12);
          let v121_14: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v121_13));
          let mut v121_15 = Space::new();
          let mut v121_15_write = v121_15.write_zipper();
          let mut v121_15_cursor = (v121_14).read_zipper();
          let v121_15_origin = v121_15_cursor.path().len();
          for v121_15_byte in v121_15_cursor.child_mask().iter() {
            v121_15_cursor.descend_to_existing_byte(v121_15_byte);
            {
            let v125_2: Space = singleton(&v121_15_cursor.path()[v121_15_origin..(v121_15_origin + 1)]);
            let v125_3: Space = intersect(&(*CONSTANT_1),&(v125_2));
            let v125_4: Space = if has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
            drop(v125_3);
            let v125_5: Space = subtract(&(*CONSTANT_0),&(v125_4));
            drop(v125_4);
            let v125_7: Space = if (&(v125_5)).is_empty() { Space::new() } else {
              let v126_6: Space = routine_8(c, &v121_15_cursor.path()[v121_15_origin..(v121_15_origin + 1)], &v121_15_cursor);
              compose(&(v125_5),&(v126_6))
            };
            drop(v125_5);
            let v125_8: Space = intersect(&(*CONSTANT_1),&(v125_2));
            drop(v125_2);
            let v125_9: Space = if has_head(&(v125_8)) { singleton(&[]) } else { Space::new() };
            drop(v125_8);
            let v125_11: Space = if (&(v125_9)).is_empty() { Space::new() } else {
              let v127_10: Space = routine_9(c, &v121_15_cursor.path()[v121_15_origin..(v121_15_origin + 1)], &v121_15_cursor);
              compose(&(v125_9),&(v127_10))
            };
            drop(v125_9);
            let v125_12: Space = unite(&(v125_7),&(v125_11));
            join_wrapped_into(&mut v121_15_write,&((v125_12).read_zipper()),&[]);
            }
            v121_15_cursor.ascend(1);
          }
          drop(v121_15_cursor);
          drop(v121_15_write);
          let v121_16: Space = subtract(&(v121_15),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v103_34_cursor.path()[v103_34_origin..(v103_34_origin + 1)]),&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)])));
          let v121_17: Space = intersect(&(v121_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
          compose(&(v116_10),&(v121_17))
        };
        drop(v116_10);
        let v128_6: Path = concat_path(&(v115_6),&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)]);
        let v116_19: Space = wrap(&(v116_18),&(v128_6));
        let v116_20: Space = unite(&(v116_8),&(v116_19));
        join_wrapped_into(&mut v115_12_write,&((v116_20).read_zipper()),&[]);
        }
        v103_34_cursor.ascend(1);
      }
      drop(v115_12_write);
      drop(v115_6);
      compose(&(v104_10),&(v115_12))
    };
    drop(v104_10);
    let v104_14: Space = unite(&(v104_8),&(v104_13));
    join_wrapped_into(&mut v103_34_write,&((v104_14).read_zipper()),&[]);
    }
    v103_34_cursor.ascend(1);
  }
  drop(v103_34_cursor);
  drop(v103_34_write);
  (v103_34).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v129_40 = Space::new();
  let mut v129_40_write = v129_40.write_zipper();
  let mut v129_40_cursor = (*s0).read_zipper();
  let v129_40_origin = v129_40_cursor.path().len();
  for v129_40_byte in v129_40_cursor.child_mask().iter() {
    v129_40_cursor.descend_to_existing_byte(v129_40_byte);
    {
    let v130_2: Space = singleton(&v129_40_cursor.path()[v129_40_origin..(v129_40_origin + 1)]);
    let v130_3: Space = intersect(&(*CONSTANT_1),&(v130_2));
    let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
    drop(v130_3);
    let v130_5: Space = subtract(&(*CONSTANT_0),&(v130_4));
    drop(v130_4);
    let v130_8: Space = if (&(v130_5)).is_empty() { Space::new() } else {
      let v131_6: Path = concat_path(&(*p0),&v129_40_cursor.path()[v129_40_origin..(v129_40_origin + 1)]);
      let mut v131_7 = Space::new();
      let mut v131_7_write = v131_7.write_zipper();
      for v131_7_byte in v129_40_cursor.child_mask().iter() {
        v129_40_cursor.descend_to_existing_byte(v131_7_byte);
        {
        let v132_2: Space = singleton(&v129_40_cursor.path()[(v129_40_origin + 1)..(v129_40_origin + 2)]);
        let v132_3: Space = intersect(&(*CONSTANT_1),&(v132_2));
        let v132_4: Space = if has_head(&(v132_3)) { singleton(&[]) } else { Space::new() };
        drop(v132_3);
        let v132_5: Space = subtract(&(*CONSTANT_0),&(v132_4));
        drop(v132_4);
        let v132_8: Space = if (&(v132_5)).is_empty() { Space::new() } else {
          let v133_6: Path = concat_path(&(v131_6),&v129_40_cursor.path()[(v129_40_origin + 1)..(v129_40_origin + 2)]);
          let mut v133_7 = Space::new();
          let mut v133_7_write = v133_7.write_zipper();
          for v133_7_byte in v129_40_cursor.child_mask().iter() {
            v129_40_cursor.descend_to_existing_byte(v133_7_byte);
            {
            let v134_2: Space = singleton(&v129_40_cursor.path()[(v129_40_origin + 2)..(v129_40_origin + 3)]);
            let v134_3: Space = intersect(&(*CONSTANT_1),&(v134_2));
            let v134_4: Space = if has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
            drop(v134_3);
            let v134_5: Space = subtract(&(*CONSTANT_0),&(v134_4));
            drop(v134_4);
            let v134_8: Space = if (&(v134_5)).is_empty() { Space::new() } else {
              let v135_6: Path = concat_path(&(v133_6),&v129_40_cursor.path()[(v129_40_origin + 2)..(v129_40_origin + 3)]);
              let v135_7: Space = routine_20(c, &(v135_6), &v129_40_cursor, &(*s1));
              compose(&(v134_5),&(v135_7))
            };
            drop(v134_5);
            let v134_9: Space = intersect(&(*CONSTANT_1),&(v134_2));
            drop(v134_2);
            let v134_10: Space = if has_head(&(v134_9)) { singleton(&[]) } else { Space::new() };
            drop(v134_9);
            let v134_12: Space = if (&(v134_10)).is_empty() { Space::new() } else {
              let v136_6: Path = concat_path(&(v133_6),&v129_40_cursor.path()[(v129_40_origin + 2)..(v129_40_origin + 3)]);
              let v136_11: Space = routine_21(c, &(v136_6), &v129_40_cursor, &(*s1));
              drop(v136_6);
              compose(&(v134_10),&(v136_11))
            };
            drop(v134_10);
            let v134_13: Space = unite(&(v134_8),&(v134_12));
            join_wrapped_into(&mut v133_7_write,&((v134_13).read_zipper()),&[]);
            }
            v129_40_cursor.ascend(1);
          }
          drop(v133_7_write);
          compose(&(v132_5),&(v133_7))
        };
        drop(v132_5);
        let v132_9: Space = intersect(&(*CONSTANT_1),&(v132_2));
        drop(v132_2);
        let v132_10: Space = if has_head(&(v132_9)) { singleton(&[]) } else { Space::new() };
        drop(v132_9);
        let v132_12: Space = if (&(v132_10)).is_empty() { Space::new() } else {
          let v137_6: Path = concat_path(&(v131_6),&v129_40_cursor.path()[(v129_40_origin + 1)..(v129_40_origin + 2)]);
          let mut v137_11 = Space::new();
          let mut v137_11_write = v137_11.write_zipper();
          for v137_11_byte in v129_40_cursor.child_mask().iter() {
            v129_40_cursor.descend_to_existing_byte(v137_11_byte);
            {
            let v138_2: Space = singleton(&v129_40_cursor.path()[(v129_40_origin + 2)..(v129_40_origin + 3)]);
            let v138_3: Space = intersect(&(*CONSTANT_1),&(v138_2));
            let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
            drop(v138_3);
            let v138_5: Space = subtract(&(*CONSTANT_0),&(v138_4));
            drop(v138_4);
            let v138_8: Space = if (&(v138_5)).is_empty() { Space::new() } else {
              let v139_6: Path = concat_path(&(v137_6),&v129_40_cursor.path()[(v129_40_origin + 2)..(v129_40_origin + 3)]);
              let v139_7: Space = routine_20(c, &(v139_6), &v129_40_cursor, &(*s1));
              compose(&(v138_5),&(v139_7))
            };
            drop(v138_5);
            let v138_9: Space = intersect(&(*CONSTANT_1),&(v138_2));
            drop(v138_2);
            let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
            drop(v138_9);
            let v138_12: Space = if (&(v138_10)).is_empty() { Space::new() } else {
              let v140_6: Path = concat_path(&(v137_6),&v129_40_cursor.path()[(v129_40_origin + 2)..(v129_40_origin + 3)]);
              let v140_11: Space = routine_3(c, &(v140_6), &v129_40_cursor, &(*s1));
              drop(v140_6);
              compose(&(v138_10),&(v140_11))
            };
            drop(v138_10);
            let v138_13: Space = unite(&(v138_8),&(v138_12));
            join_wrapped_into(&mut v137_11_write,&((v138_13).read_zipper()),&[]);
            }
            v129_40_cursor.ascend(1);
          }
          drop(v137_11_write);
          drop(v137_6);
          compose(&(v132_10),&(v137_11))
        };
        drop(v132_10);
        let v132_13: Space = unite(&(v132_8),&(v132_12));
        join_wrapped_into(&mut v131_7_write,&((v132_13).read_zipper()),&[]);
        }
        v129_40_cursor.ascend(1);
      }
      drop(v131_7_write);
      compose(&(v130_5),&(v131_7))
    };
    drop(v130_5);
    let v130_9: Space = intersect(&(*CONSTANT_1),&(v130_2));
    drop(v130_2);
    let v130_10: Space = if has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
    drop(v130_9);
    let v130_18: Space = if (&(v130_10)).is_empty() { Space::new() } else {
      let v141_12: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v129_40_cursor.path()[v129_40_origin..(v129_40_origin + 1)])));
      let mut v141_13 = Space::new();
      let mut v141_13_write = v141_13.write_zipper();
      let mut v141_13_cursor = (v141_12).read_zipper();
      let v141_13_origin = v141_13_cursor.path().len();
      for v141_13_byte in v141_13_cursor.child_mask().iter() {
        v141_13_cursor.descend_to_existing_byte(v141_13_byte);
        {
        let v142_2: Space = singleton(&v141_13_cursor.path()[v141_13_origin..(v141_13_origin + 1)]);
        let v142_3: Space = intersect(&(*CONSTANT_1),&(v142_2));
        let v142_4: Space = if has_head(&(v142_3)) { singleton(&[]) } else { Space::new() };
        drop(v142_3);
        let v142_5: Space = subtract(&(*CONSTANT_0),&(v142_4));
        drop(v142_4);
        let v142_7: Space = if (&(v142_5)).is_empty() { Space::new() } else {
          let mut v143_6 = Space::new();
          let mut v143_6_write = v143_6.write_zipper();
          for v143_6_byte in v141_13_cursor.child_mask().iter() {
            v141_13_cursor.descend_to_existing_byte(v143_6_byte);
            {
            let v144_2: Space = singleton(&v141_13_cursor.path()[(v141_13_origin + 1)..(v141_13_origin + 2)]);
            let v144_3: Space = intersect(&(*CONSTANT_1),&(v144_2));
            let v144_4: Space = if has_head(&(v144_3)) { singleton(&[]) } else { Space::new() };
            drop(v144_3);
            let v144_5: Space = subtract(&(*CONSTANT_0),&(v144_4));
            drop(v144_4);
            let v144_8: Space = if (&(v144_5)).is_empty() { Space::new() } else {
              let v145_7: Space = routine_10(c, &v141_13_cursor.path()[v141_13_origin..(v141_13_origin + 2)], &v141_13_cursor);
              compose(&(v144_5),&(v145_7))
            };
            drop(v144_5);
            let v144_9: Space = intersect(&(*CONSTANT_1),&(v144_2));
            drop(v144_2);
            let v144_10: Space = if has_head(&(v144_9)) { singleton(&[]) } else { Space::new() };
            drop(v144_9);
            let v144_12: Space = if (&(v144_10)).is_empty() { Space::new() } else {
              let v146_11: Space = routine_11(c, &v141_13_cursor.path()[v141_13_origin..(v141_13_origin + 2)], &v141_13_cursor);
              compose(&(v144_10),&(v146_11))
            };
            drop(v144_10);
            let v144_13: Space = unite(&(v144_8),&(v144_12));
            join_wrapped_into(&mut v143_6_write,&((v144_13).read_zipper()),&[]);
            }
            v141_13_cursor.ascend(1);
          }
          drop(v143_6_write);
          compose(&(v142_5),&(v143_6))
        };
        drop(v142_5);
        let v142_8: Space = intersect(&(*CONSTANT_1),&(v142_2));
        drop(v142_2);
        let v142_9: Space = if has_head(&(v142_8)) { singleton(&[]) } else { Space::new() };
        drop(v142_8);
        let v142_11: Space = if (&(v142_9)).is_empty() { Space::new() } else {
          let mut v147_10 = Space::new();
          let mut v147_10_write = v147_10.write_zipper();
          for v147_10_byte in v141_13_cursor.child_mask().iter() {
            v141_13_cursor.descend_to_existing_byte(v147_10_byte);
            {
            let v148_2: Space = singleton(&v141_13_cursor.path()[(v141_13_origin + 1)..(v141_13_origin + 2)]);
            let v148_3: Space = intersect(&(*CONSTANT_1),&(v148_2));
            let v148_4: Space = if has_head(&(v148_3)) { singleton(&[]) } else { Space::new() };
            drop(v148_3);
            let v148_5: Space = subtract(&(*CONSTANT_0),&(v148_4));
            drop(v148_4);
            let v148_8: Space = if (&(v148_5)).is_empty() { Space::new() } else {
              let v149_7: Space = routine_10(c, &v141_13_cursor.path()[v141_13_origin..(v141_13_origin + 2)], &v141_13_cursor);
              compose(&(v148_5),&(v149_7))
            };
            drop(v148_5);
            let v148_9: Space = intersect(&(*CONSTANT_1),&(v148_2));
            drop(v148_2);
            let v148_10: Space = if has_head(&(v148_9)) { singleton(&[]) } else { Space::new() };
            drop(v148_9);
            let v148_12: Space = if (&(v148_10)).is_empty() { Space::new() } else {
              let v150_11: Space = routine_12(c, &v141_13_cursor.path()[v141_13_origin..(v141_13_origin + 2)], &v141_13_cursor);
              compose(&(v148_10),&(v150_11))
            };
            drop(v148_10);
            let v148_13: Space = unite(&(v148_8),&(v148_12));
            join_wrapped_into(&mut v147_10_write,&((v148_13).read_zipper()),&[]);
            }
            v141_13_cursor.ascend(1);
          }
          drop(v147_10_write);
          compose(&(v142_9),&(v147_10))
        };
        drop(v142_9);
        let v142_12: Space = unite(&(v142_7),&(v142_11));
        join_wrapped_into(&mut v141_13_write,&((v142_12).read_zipper()),&[]);
        }
        v141_13_cursor.ascend(1);
      }
      drop(v141_13_cursor);
      drop(v141_13_write);
      drop(v141_12);
      let v141_14: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v141_13));
      let mut v141_15 = Space::new();
      let mut v141_15_write = v141_15.write_zipper();
      let mut v141_15_cursor = (v141_14).read_zipper();
      let v141_15_origin = v141_15_cursor.path().len();
      for v141_15_byte in v141_15_cursor.child_mask().iter() {
        v141_15_cursor.descend_to_existing_byte(v141_15_byte);
        {
        let v151_2: Space = singleton(&v141_15_cursor.path()[v141_15_origin..(v141_15_origin + 1)]);
        let v151_3: Space = intersect(&(*CONSTANT_1),&(v151_2));
        let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
        drop(v151_3);
        let v151_5: Space = subtract(&(*CONSTANT_0),&(v151_4));
        drop(v151_4);
        let v151_7: Space = if (&(v151_5)).is_empty() { Space::new() } else {
          let mut v152_6 = Space::new();
          let mut v152_6_write = v152_6.write_zipper();
          for v152_6_byte in v141_15_cursor.child_mask().iter() {
            v141_15_cursor.descend_to_existing_byte(v152_6_byte);
            {
            let v153_2: Space = singleton(&v141_15_cursor.path()[(v141_15_origin + 1)..(v141_15_origin + 2)]);
            let v153_3: Space = intersect(&(*CONSTANT_1),&(v153_2));
            let v153_4: Space = if has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
            drop(v153_3);
            let v153_5: Space = subtract(&(*CONSTANT_0),&(v153_4));
            drop(v153_4);
            let v153_8: Space = if (&(v153_5)).is_empty() { Space::new() } else {
              let v154_7: Space = routine_13(c, &v141_15_cursor.path()[v141_15_origin..(v141_15_origin + 2)], &v141_15_cursor);
              compose(&(v153_5),&(v154_7))
            };
            drop(v153_5);
            let v153_9: Space = intersect(&(*CONSTANT_1),&(v153_2));
            drop(v153_2);
            let v153_10: Space = if has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
            drop(v153_9);
            let v153_12: Space = if (&(v153_10)).is_empty() { Space::new() } else {
              let v155_11: Space = routine_14(c, &v141_15_cursor.path()[v141_15_origin..(v141_15_origin + 2)], &v141_15_cursor);
              compose(&(v153_10),&(v155_11))
            };
            drop(v153_10);
            let v153_13: Space = unite(&(v153_8),&(v153_12));
            join_wrapped_into(&mut v152_6_write,&((v153_13).read_zipper()),&[]);
            }
            v141_15_cursor.ascend(1);
          }
          drop(v152_6_write);
          compose(&(v151_5),&(v152_6))
        };
        drop(v151_5);
        let v151_8: Space = intersect(&(*CONSTANT_1),&(v151_2));
        drop(v151_2);
        let v151_9: Space = if has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
        drop(v151_8);
        let v151_11: Space = if (&(v151_9)).is_empty() { Space::new() } else {
          let mut v156_10 = Space::new();
          let mut v156_10_write = v156_10.write_zipper();
          for v156_10_byte in v141_15_cursor.child_mask().iter() {
            v141_15_cursor.descend_to_existing_byte(v156_10_byte);
            {
            let v157_2: Space = singleton(&v141_15_cursor.path()[(v141_15_origin + 1)..(v141_15_origin + 2)]);
            let v157_3: Space = intersect(&(*CONSTANT_1),&(v157_2));
            let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
            drop(v157_3);
            let v157_5: Space = subtract(&(*CONSTANT_0),&(v157_4));
            drop(v157_4);
            let v157_8: Space = if (&(v157_5)).is_empty() { Space::new() } else {
              let v158_7: Space = routine_13(c, &v141_15_cursor.path()[v141_15_origin..(v141_15_origin + 2)], &v141_15_cursor);
              compose(&(v157_5),&(v158_7))
            };
            drop(v157_5);
            let v157_9: Space = intersect(&(*CONSTANT_1),&(v157_2));
            drop(v157_2);
            let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
            drop(v157_9);
            let v157_12: Space = if (&(v157_10)).is_empty() { Space::new() } else {
              let v159_11: Space = routine_15(c, &v141_15_cursor.path()[v141_15_origin..(v141_15_origin + 2)], &v141_15_cursor);
              compose(&(v157_10),&(v159_11))
            };
            drop(v157_10);
            let v157_13: Space = unite(&(v157_8),&(v157_12));
            join_wrapped_into(&mut v156_10_write,&((v157_13).read_zipper()),&[]);
            }
            v141_15_cursor.ascend(1);
          }
          drop(v156_10_write);
          compose(&(v151_9),&(v156_10))
        };
        drop(v151_9);
        let v151_12: Space = unite(&(v151_7),&(v151_11));
        join_wrapped_into(&mut v141_15_write,&((v151_12).read_zipper()),&[]);
        }
        v141_15_cursor.ascend(1);
      }
      drop(v141_15_cursor);
      drop(v141_15_write);
      let v141_16: Space = subtract(&(v141_15),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v129_40_cursor.path()[v129_40_origin..(v129_40_origin + 1)])));
      let v141_17: Space = intersect(&(v141_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
      compose(&(v130_10),&(v141_17))
    };
    drop(v130_10);
    let v160_6: Path = concat_path(&(*p0),&v129_40_cursor.path()[v129_40_origin..(v129_40_origin + 1)]);
    let v130_19: Space = wrap(&(v130_18),&(v160_6));
    let v130_20: Space = unite(&(v130_8),&(v130_19));
    join_wrapped_into(&mut v129_40_write,&((v130_20).read_zipper()),&[]);
    }
    v129_40_cursor.ascend(1);
  }
  drop(v129_40_cursor);
  drop(v129_40_write);
  (v129_40).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v161_20 = Space::new();
  let mut v161_20_write = v161_20.write_zipper();
  let mut v161_20_cursor = (*s0).read_zipper();
  let v161_20_origin = v161_20_cursor.path().len();
  for v161_20_byte in v161_20_cursor.child_mask().iter() {
    v161_20_cursor.descend_to_existing_byte(v161_20_byte);
    {
    let v162_2: Space = singleton(&v161_20_cursor.path()[v161_20_origin..(v161_20_origin + 1)]);
    let v162_3: Space = intersect(&(*CONSTANT_1),&(v162_2));
    let v162_4: Space = if has_head(&(v162_3)) { singleton(&[]) } else { Space::new() };
    drop(v162_3);
    let v162_5: Space = subtract(&(*CONSTANT_0),&(v162_4));
    drop(v162_4);
    let v162_8: Space = if (&(v162_5)).is_empty() { Space::new() } else {
      let v163_6: Path = concat_path(&(*p0),&v161_20_cursor.path()[v161_20_origin..(v161_20_origin + 1)]);
      let mut v163_7 = Space::new();
      let mut v163_7_write = v163_7.write_zipper();
      for v163_7_byte in v161_20_cursor.child_mask().iter() {
        v161_20_cursor.descend_to_existing_byte(v163_7_byte);
        {
        let v164_2: Space = singleton(&v161_20_cursor.path()[(v161_20_origin + 1)..(v161_20_origin + 2)]);
        let v164_3: Space = intersect(&(*CONSTANT_1),&(v164_2));
        let v164_4: Space = if has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
        drop(v164_3);
        let v164_5: Space = subtract(&(*CONSTANT_0),&(v164_4));
        drop(v164_4);
        let v164_8: Space = if (&(v164_5)).is_empty() { Space::new() } else {
          let v165_6: Path = concat_path(&(v163_6),&v161_20_cursor.path()[(v161_20_origin + 1)..(v161_20_origin + 2)]);
          let mut v165_7 = Space::new();
          let mut v165_7_write = v165_7.write_zipper();
          for v165_7_byte in v161_20_cursor.child_mask().iter() {
            v161_20_cursor.descend_to_existing_byte(v165_7_byte);
            {
            let v166_2: Space = singleton(&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
            let v166_3: Space = intersect(&(*CONSTANT_1),&(v166_2));
            let v166_4: Space = if has_head(&(v166_3)) { singleton(&[]) } else { Space::new() };
            drop(v166_3);
            let v166_5: Space = subtract(&(*CONSTANT_0),&(v166_4));
            drop(v166_4);
            let v166_8: Space = if (&(v166_5)).is_empty() { Space::new() } else {
              let v167_6: Path = concat_path(&(v165_6),&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
              let v167_7: Space = routine_22(c, &(v167_6), &v161_20_cursor);
              compose(&(v166_5),&(v167_7))
            };
            drop(v166_5);
            let v166_9: Space = intersect(&(*CONSTANT_1),&(v166_2));
            drop(v166_2);
            let v166_10: Space = if has_head(&(v166_9)) { singleton(&[]) } else { Space::new() };
            drop(v166_9);
            let v166_12: Space = if (&(v166_10)).is_empty() { Space::new() } else {
              let v168_6: Path = concat_path(&(v165_6),&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
              let v168_11: Space = routine_23(c, &(v168_6), &v161_20_cursor);
              drop(v168_6);
              compose(&(v166_10),&(v168_11))
            };
            drop(v166_10);
            let v166_13: Space = unite(&(v166_8),&(v166_12));
            join_wrapped_into(&mut v165_7_write,&((v166_13).read_zipper()),&[]);
            }
            v161_20_cursor.ascend(1);
          }
          drop(v165_7_write);
          compose(&(v164_5),&(v165_7))
        };
        drop(v164_5);
        let v164_9: Space = intersect(&(*CONSTANT_1),&(v164_2));
        drop(v164_2);
        let v164_10: Space = if has_head(&(v164_9)) { singleton(&[]) } else { Space::new() };
        drop(v164_9);
        let v164_12: Space = if (&(v164_10)).is_empty() { Space::new() } else {
          let v169_6: Path = concat_path(&(v163_6),&v161_20_cursor.path()[(v161_20_origin + 1)..(v161_20_origin + 2)]);
          let mut v169_11 = Space::new();
          let mut v169_11_write = v169_11.write_zipper();
          for v169_11_byte in v161_20_cursor.child_mask().iter() {
            v161_20_cursor.descend_to_existing_byte(v169_11_byte);
            {
            let v170_2: Space = singleton(&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
            let v170_3: Space = intersect(&(*CONSTANT_1),&(v170_2));
            let v170_4: Space = if has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
            drop(v170_3);
            let v170_5: Space = subtract(&(*CONSTANT_0),&(v170_4));
            drop(v170_4);
            let v170_8: Space = if (&(v170_5)).is_empty() { Space::new() } else {
              let v171_6: Path = concat_path(&(v169_6),&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
              let v171_7: Space = routine_22(c, &(v171_6), &v161_20_cursor);
              compose(&(v170_5),&(v171_7))
            };
            drop(v170_5);
            let v170_9: Space = intersect(&(*CONSTANT_1),&(v170_2));
            drop(v170_2);
            let v170_10: Space = if has_head(&(v170_9)) { singleton(&[]) } else { Space::new() };
            drop(v170_9);
            let v170_12: Space = if (&(v170_10)).is_empty() { Space::new() } else {
              let v172_6: Path = concat_path(&(v169_6),&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
              let v172_11: Space = routine_12(c, &(v172_6), &v161_20_cursor);
              drop(v172_6);
              compose(&(v170_10),&(v172_11))
            };
            drop(v170_10);
            let v170_13: Space = unite(&(v170_8),&(v170_12));
            join_wrapped_into(&mut v169_11_write,&((v170_13).read_zipper()),&[]);
            }
            v161_20_cursor.ascend(1);
          }
          drop(v169_11_write);
          drop(v169_6);
          compose(&(v164_10),&(v169_11))
        };
        drop(v164_10);
        let v164_13: Space = unite(&(v164_8),&(v164_12));
        join_wrapped_into(&mut v163_7_write,&((v164_13).read_zipper()),&[]);
        }
        v161_20_cursor.ascend(1);
      }
      drop(v163_7_write);
      compose(&(v162_5),&(v163_7))
    };
    drop(v162_5);
    let v162_9: Space = intersect(&(*CONSTANT_1),&(v162_2));
    drop(v162_2);
    let v162_10: Space = if has_head(&(v162_9)) { singleton(&[]) } else { Space::new() };
    drop(v162_9);
    let v162_12: Space = if (&(v162_10)).is_empty() { Space::new() } else {
      let v173_6: Path = concat_path(&(*p0),&v161_20_cursor.path()[v161_20_origin..(v161_20_origin + 1)]);
      let mut v173_11 = Space::new();
      let mut v173_11_write = v173_11.write_zipper();
      for v173_11_byte in v161_20_cursor.child_mask().iter() {
        v161_20_cursor.descend_to_existing_byte(v173_11_byte);
        {
        let v174_2: Space = singleton(&v161_20_cursor.path()[(v161_20_origin + 1)..(v161_20_origin + 2)]);
        let v174_3: Space = intersect(&(*CONSTANT_1),&(v174_2));
        let v174_4: Space = if has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
        drop(v174_3);
        let v174_5: Space = subtract(&(*CONSTANT_0),&(v174_4));
        drop(v174_4);
        let v174_8: Space = if (&(v174_5)).is_empty() { Space::new() } else {
          let v175_6: Path = concat_path(&(v173_6),&v161_20_cursor.path()[(v161_20_origin + 1)..(v161_20_origin + 2)]);
          let mut v175_7 = Space::new();
          let mut v175_7_write = v175_7.write_zipper();
          for v175_7_byte in v161_20_cursor.child_mask().iter() {
            v161_20_cursor.descend_to_existing_byte(v175_7_byte);
            {
            let v176_2: Space = singleton(&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
            let v176_3: Space = intersect(&(*CONSTANT_1),&(v176_2));
            let v176_4: Space = if has_head(&(v176_3)) { singleton(&[]) } else { Space::new() };
            drop(v176_3);
            let v176_5: Space = subtract(&(*CONSTANT_0),&(v176_4));
            drop(v176_4);
            let v176_8: Space = if (&(v176_5)).is_empty() { Space::new() } else {
              let v177_6: Path = concat_path(&(v175_6),&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
              let v177_7: Space = routine_22(c, &(v177_6), &v161_20_cursor);
              compose(&(v176_5),&(v177_7))
            };
            drop(v176_5);
            let v176_9: Space = intersect(&(*CONSTANT_1),&(v176_2));
            drop(v176_2);
            let v176_10: Space = if has_head(&(v176_9)) { singleton(&[]) } else { Space::new() };
            drop(v176_9);
            let v176_12: Space = if (&(v176_10)).is_empty() { Space::new() } else {
              let v178_6: Path = concat_path(&(v175_6),&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
              let v178_11: Space = routine_23(c, &(v178_6), &v161_20_cursor);
              drop(v178_6);
              compose(&(v176_10),&(v178_11))
            };
            drop(v176_10);
            let v176_13: Space = unite(&(v176_8),&(v176_12));
            join_wrapped_into(&mut v175_7_write,&((v176_13).read_zipper()),&[]);
            }
            v161_20_cursor.ascend(1);
          }
          drop(v175_7_write);
          drop(v175_6);
          compose(&(v174_5),&(v175_7))
        };
        drop(v174_5);
        let v174_9: Space = intersect(&(*CONSTANT_1),&(v174_2));
        drop(v174_2);
        let v174_10: Space = if has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
        drop(v174_9);
        let v174_11: Space = compose(&(v174_10),&v161_20_cursor);
        drop(v174_10);
        let v174_12: Space = unite(&(v174_8),&(v174_11));
        drop(v174_11);
        join_wrapped_into(&mut v173_11_write,&((v174_12).read_zipper()),&[]);
        }
        v161_20_cursor.ascend(1);
      }
      drop(v173_11_write);
      drop(v173_6);
      compose(&(v162_10),&(v173_11))
    };
    drop(v162_10);
    let v162_13: Space = unite(&(v162_8),&(v162_12));
    join_wrapped_into(&mut v161_20_write,&((v162_13).read_zipper()),&[]);
    }
    v161_20_cursor.ascend(1);
  }
  drop(v161_20_cursor);
  drop(v161_20_write);
  (v161_20).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v179_14 = Space::new();
  let mut v179_14_write = v179_14.write_zipper();
  let mut v179_14_cursor = (*s0).read_zipper();
  let v179_14_origin = v179_14_cursor.path().len();
  for v179_14_byte in v179_14_cursor.child_mask().iter() {
    v179_14_cursor.descend_to_existing_byte(v179_14_byte);
    {
    let v180_2: Space = singleton(&v179_14_cursor.path()[v179_14_origin..(v179_14_origin + 1)]);
    let v180_3: Space = intersect(&(*CONSTANT_1),&(v180_2));
    let v180_4: Space = if has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
    drop(v180_3);
    let v180_5: Space = subtract(&(*CONSTANT_0),&(v180_4));
    drop(v180_4);
    let v180_8: Space = if (&(v180_5)).is_empty() { Space::new() } else {
      let v181_6: Path = concat_path(&(*p0),&v179_14_cursor.path()[v179_14_origin..(v179_14_origin + 1)]);
      let mut v181_7 = Space::new();
      let mut v181_7_write = v181_7.write_zipper();
      for v181_7_byte in v179_14_cursor.child_mask().iter() {
        v179_14_cursor.descend_to_existing_byte(v181_7_byte);
        {
        let v182_2: Space = singleton(&v179_14_cursor.path()[(v179_14_origin + 1)..(v179_14_origin + 2)]);
        let v182_3: Space = intersect(&(*CONSTANT_1),&(v182_2));
        let v182_4: Space = if has_head(&(v182_3)) { singleton(&[]) } else { Space::new() };
        drop(v182_3);
        let v182_5: Space = subtract(&(*CONSTANT_0),&(v182_4));
        drop(v182_4);
        let v182_8: Space = if (&(v182_5)).is_empty() { Space::new() } else {
          let v183_6: Path = concat_path(&(v181_6),&v179_14_cursor.path()[(v179_14_origin + 1)..(v179_14_origin + 2)]);
          let mut v183_7 = Space::new();
          let mut v183_7_write = v183_7.write_zipper();
          for v183_7_byte in v179_14_cursor.child_mask().iter() {
            v179_14_cursor.descend_to_existing_byte(v183_7_byte);
            {
            let v184_2: Space = singleton(&v179_14_cursor.path()[(v179_14_origin + 2)..(v179_14_origin + 3)]);
            let v184_3: Space = intersect(&(*CONSTANT_1),&(v184_2));
            let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
            drop(v184_3);
            let v184_5: Space = subtract(&(*CONSTANT_0),&(v184_4));
            drop(v184_4);
            let v184_8: Space = if (&(v184_5)).is_empty() { Space::new() } else {
              let v185_6: Path = concat_path(&(v183_6),&v179_14_cursor.path()[(v179_14_origin + 2)..(v179_14_origin + 3)]);
              let v185_7: Space = routine_22(c, &(v185_6), &v179_14_cursor);
              compose(&(v184_5),&(v185_7))
            };
            drop(v184_5);
            let v184_9: Space = intersect(&(*CONSTANT_1),&(v184_2));
            drop(v184_2);
            let v184_10: Space = if has_head(&(v184_9)) { singleton(&[]) } else { Space::new() };
            drop(v184_9);
            let v184_12: Space = if (&(v184_10)).is_empty() { Space::new() } else {
              let v186_6: Path = concat_path(&(v183_6),&v179_14_cursor.path()[(v179_14_origin + 2)..(v179_14_origin + 3)]);
              let v186_11: Space = routine_23(c, &(v186_6), &v179_14_cursor);
              drop(v186_6);
              compose(&(v184_10),&(v186_11))
            };
            drop(v184_10);
            let v184_13: Space = unite(&(v184_8),&(v184_12));
            join_wrapped_into(&mut v183_7_write,&((v184_13).read_zipper()),&[]);
            }
            v179_14_cursor.ascend(1);
          }
          drop(v183_7_write);
          compose(&(v182_5),&(v183_7))
        };
        drop(v182_5);
        let v182_9: Space = intersect(&(*CONSTANT_1),&(v182_2));
        drop(v182_2);
        let v182_10: Space = if has_head(&(v182_9)) { singleton(&[]) } else { Space::new() };
        drop(v182_9);
        let v182_12: Space = if (&(v182_10)).is_empty() { Space::new() } else {
          let v187_6: Path = concat_path(&(v181_6),&v179_14_cursor.path()[(v179_14_origin + 1)..(v179_14_origin + 2)]);
          let mut v187_11 = Space::new();
          let mut v187_11_write = v187_11.write_zipper();
          for v187_11_byte in v179_14_cursor.child_mask().iter() {
            v179_14_cursor.descend_to_existing_byte(v187_11_byte);
            {
            let v188_2: Space = singleton(&v179_14_cursor.path()[(v179_14_origin + 2)..(v179_14_origin + 3)]);
            let v188_3: Space = intersect(&(*CONSTANT_1),&(v188_2));
            let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
            drop(v188_3);
            let v188_5: Space = subtract(&(*CONSTANT_0),&(v188_4));
            drop(v188_4);
            let v188_8: Space = if (&(v188_5)).is_empty() { Space::new() } else {
              let v189_6: Path = concat_path(&(v187_6),&v179_14_cursor.path()[(v179_14_origin + 2)..(v179_14_origin + 3)]);
              let v189_7: Space = routine_22(c, &(v189_6), &v179_14_cursor);
              compose(&(v188_5),&(v189_7))
            };
            drop(v188_5);
            let v188_9: Space = intersect(&(*CONSTANT_1),&(v188_2));
            drop(v188_2);
            let v188_10: Space = if has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
            drop(v188_9);
            let v188_12: Space = if (&(v188_10)).is_empty() { Space::new() } else {
              let v190_6: Path = concat_path(&(v187_6),&v179_14_cursor.path()[(v179_14_origin + 2)..(v179_14_origin + 3)]);
              let v190_11: Space = routine_12(c, &(v190_6), &v179_14_cursor);
              drop(v190_6);
              compose(&(v188_10),&(v190_11))
            };
            drop(v188_10);
            let v188_13: Space = unite(&(v188_8),&(v188_12));
            join_wrapped_into(&mut v187_11_write,&((v188_13).read_zipper()),&[]);
            }
            v179_14_cursor.ascend(1);
          }
          drop(v187_11_write);
          drop(v187_6);
          compose(&(v182_10),&(v187_11))
        };
        drop(v182_10);
        let v182_13: Space = unite(&(v182_8),&(v182_12));
        join_wrapped_into(&mut v181_7_write,&((v182_13).read_zipper()),&[]);
        }
        v179_14_cursor.ascend(1);
      }
      drop(v181_7_write);
      drop(v181_6);
      compose(&(v180_5),&(v181_7))
    };
    drop(v180_5);
    let v180_9: Space = intersect(&(*CONSTANT_1),&(v180_2));
    drop(v180_2);
    let v180_10: Space = if has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
    drop(v180_9);
    let v180_11: Space = compose(&(v180_10),&v179_14_cursor);
    drop(v180_10);
    let v180_12: Space = unite(&(v180_8),&(v180_11));
    drop(v180_11);
    join_wrapped_into(&mut v179_14_write,&((v180_12).read_zipper()),&[]);
    }
    v179_14_cursor.ascend(1);
  }
  drop(v179_14_cursor);
  drop(v179_14_write);
  (v179_14).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v191_20 = Space::new();
  let mut v191_20_write = v191_20.write_zipper();
  let mut v191_20_cursor = (*s0).read_zipper();
  let v191_20_origin = v191_20_cursor.path().len();
  for v191_20_byte in v191_20_cursor.child_mask().iter() {
    v191_20_cursor.descend_to_existing_byte(v191_20_byte);
    {
    let v192_2: Space = singleton(&v191_20_cursor.path()[v191_20_origin..(v191_20_origin + 1)]);
    let v192_3: Space = intersect(&(*CONSTANT_1),&(v192_2));
    let v192_4: Space = if has_head(&(v192_3)) { singleton(&[]) } else { Space::new() };
    drop(v192_3);
    let v192_5: Space = subtract(&(*CONSTANT_0),&(v192_4));
    drop(v192_4);
    let v192_8: Space = if (&(v192_5)).is_empty() { Space::new() } else {
      let v193_6: Path = concat_path(&(*p0),&v191_20_cursor.path()[v191_20_origin..(v191_20_origin + 1)]);
      let mut v193_7 = Space::new();
      let mut v193_7_write = v193_7.write_zipper();
      for v193_7_byte in v191_20_cursor.child_mask().iter() {
        v191_20_cursor.descend_to_existing_byte(v193_7_byte);
        {
        let v194_2: Space = singleton(&v191_20_cursor.path()[(v191_20_origin + 1)..(v191_20_origin + 2)]);
        let v194_3: Space = intersect(&(*CONSTANT_1),&(v194_2));
        let v194_4: Space = if has_head(&(v194_3)) { singleton(&[]) } else { Space::new() };
        drop(v194_3);
        let v194_5: Space = subtract(&(*CONSTANT_0),&(v194_4));
        drop(v194_4);
        let v194_8: Space = if (&(v194_5)).is_empty() { Space::new() } else {
          let v195_6: Path = concat_path(&(v193_6),&v191_20_cursor.path()[(v191_20_origin + 1)..(v191_20_origin + 2)]);
          let mut v195_7 = Space::new();
          let mut v195_7_write = v195_7.write_zipper();
          for v195_7_byte in v191_20_cursor.child_mask().iter() {
            v191_20_cursor.descend_to_existing_byte(v195_7_byte);
            {
            let v196_2: Space = singleton(&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
            let v196_3: Space = intersect(&(*CONSTANT_1),&(v196_2));
            let v196_4: Space = if has_head(&(v196_3)) { singleton(&[]) } else { Space::new() };
            drop(v196_3);
            let v196_5: Space = subtract(&(*CONSTANT_0),&(v196_4));
            drop(v196_4);
            let v196_8: Space = if (&(v196_5)).is_empty() { Space::new() } else {
              let v197_6: Path = concat_path(&(v195_6),&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
              let v197_7: Space = routine_24(c, &(v197_6), &v191_20_cursor);
              compose(&(v196_5),&(v197_7))
            };
            drop(v196_5);
            let v196_9: Space = intersect(&(*CONSTANT_1),&(v196_2));
            drop(v196_2);
            let v196_10: Space = if has_head(&(v196_9)) { singleton(&[]) } else { Space::new() };
            drop(v196_9);
            let v196_12: Space = if (&(v196_10)).is_empty() { Space::new() } else {
              let v198_6: Path = concat_path(&(v195_6),&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
              let v198_11: Space = routine_25(c, &(v198_6), &v191_20_cursor);
              drop(v198_6);
              compose(&(v196_10),&(v198_11))
            };
            drop(v196_10);
            let v196_13: Space = unite(&(v196_8),&(v196_12));
            join_wrapped_into(&mut v195_7_write,&((v196_13).read_zipper()),&[]);
            }
            v191_20_cursor.ascend(1);
          }
          drop(v195_7_write);
          compose(&(v194_5),&(v195_7))
        };
        drop(v194_5);
        let v194_9: Space = intersect(&(*CONSTANT_1),&(v194_2));
        drop(v194_2);
        let v194_10: Space = if has_head(&(v194_9)) { singleton(&[]) } else { Space::new() };
        drop(v194_9);
        let v194_12: Space = if (&(v194_10)).is_empty() { Space::new() } else {
          let v199_6: Path = concat_path(&(v193_6),&v191_20_cursor.path()[(v191_20_origin + 1)..(v191_20_origin + 2)]);
          let mut v199_11 = Space::new();
          let mut v199_11_write = v199_11.write_zipper();
          for v199_11_byte in v191_20_cursor.child_mask().iter() {
            v191_20_cursor.descend_to_existing_byte(v199_11_byte);
            {
            let v200_2: Space = singleton(&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
            let v200_3: Space = intersect(&(*CONSTANT_1),&(v200_2));
            let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
            drop(v200_3);
            let v200_5: Space = subtract(&(*CONSTANT_0),&(v200_4));
            drop(v200_4);
            let v200_8: Space = if (&(v200_5)).is_empty() { Space::new() } else {
              let v201_6: Path = concat_path(&(v199_6),&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
              let v201_7: Space = routine_24(c, &(v201_6), &v191_20_cursor);
              compose(&(v200_5),&(v201_7))
            };
            drop(v200_5);
            let v200_9: Space = intersect(&(*CONSTANT_1),&(v200_2));
            drop(v200_2);
            let v200_10: Space = if has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
            drop(v200_9);
            let v200_12: Space = if (&(v200_10)).is_empty() { Space::new() } else {
              let v202_6: Path = concat_path(&(v199_6),&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
              let v202_11: Space = routine_15(c, &(v202_6), &v191_20_cursor);
              drop(v202_6);
              compose(&(v200_10),&(v202_11))
            };
            drop(v200_10);
            let v200_13: Space = unite(&(v200_8),&(v200_12));
            join_wrapped_into(&mut v199_11_write,&((v200_13).read_zipper()),&[]);
            }
            v191_20_cursor.ascend(1);
          }
          drop(v199_11_write);
          drop(v199_6);
          compose(&(v194_10),&(v199_11))
        };
        drop(v194_10);
        let v194_13: Space = unite(&(v194_8),&(v194_12));
        join_wrapped_into(&mut v193_7_write,&((v194_13).read_zipper()),&[]);
        }
        v191_20_cursor.ascend(1);
      }
      drop(v193_7_write);
      compose(&(v192_5),&(v193_7))
    };
    drop(v192_5);
    let v192_9: Space = intersect(&(*CONSTANT_1),&(v192_2));
    drop(v192_2);
    let v192_10: Space = if has_head(&(v192_9)) { singleton(&[]) } else { Space::new() };
    drop(v192_9);
    let v192_12: Space = if (&(v192_10)).is_empty() { Space::new() } else {
      let v203_6: Path = concat_path(&(*p0),&v191_20_cursor.path()[v191_20_origin..(v191_20_origin + 1)]);
      let mut v203_11 = Space::new();
      let mut v203_11_write = v203_11.write_zipper();
      for v203_11_byte in v191_20_cursor.child_mask().iter() {
        v191_20_cursor.descend_to_existing_byte(v203_11_byte);
        {
        let v204_2: Space = singleton(&v191_20_cursor.path()[(v191_20_origin + 1)..(v191_20_origin + 2)]);
        let v204_3: Space = intersect(&(*CONSTANT_1),&(v204_2));
        let v204_4: Space = if has_head(&(v204_3)) { singleton(&[]) } else { Space::new() };
        drop(v204_3);
        let v204_5: Space = subtract(&(*CONSTANT_0),&(v204_4));
        drop(v204_4);
        let v204_8: Space = if (&(v204_5)).is_empty() { Space::new() } else {
          let v205_6: Path = concat_path(&(v203_6),&v191_20_cursor.path()[(v191_20_origin + 1)..(v191_20_origin + 2)]);
          let mut v205_7 = Space::new();
          let mut v205_7_write = v205_7.write_zipper();
          for v205_7_byte in v191_20_cursor.child_mask().iter() {
            v191_20_cursor.descend_to_existing_byte(v205_7_byte);
            {
            let v206_2: Space = singleton(&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
            let v206_3: Space = intersect(&(*CONSTANT_1),&(v206_2));
            let v206_4: Space = if has_head(&(v206_3)) { singleton(&[]) } else { Space::new() };
            drop(v206_3);
            let v206_5: Space = subtract(&(*CONSTANT_0),&(v206_4));
            drop(v206_4);
            let v206_8: Space = if (&(v206_5)).is_empty() { Space::new() } else {
              let v207_6: Path = concat_path(&(v205_6),&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
              let v207_7: Space = routine_24(c, &(v207_6), &v191_20_cursor);
              compose(&(v206_5),&(v207_7))
            };
            drop(v206_5);
            let v206_9: Space = intersect(&(*CONSTANT_1),&(v206_2));
            drop(v206_2);
            let v206_10: Space = if has_head(&(v206_9)) { singleton(&[]) } else { Space::new() };
            drop(v206_9);
            let v206_12: Space = if (&(v206_10)).is_empty() { Space::new() } else {
              let v208_6: Path = concat_path(&(v205_6),&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
              let v208_11: Space = routine_25(c, &(v208_6), &v191_20_cursor);
              drop(v208_6);
              compose(&(v206_10),&(v208_11))
            };
            drop(v206_10);
            let v206_13: Space = unite(&(v206_8),&(v206_12));
            join_wrapped_into(&mut v205_7_write,&((v206_13).read_zipper()),&[]);
            }
            v191_20_cursor.ascend(1);
          }
          drop(v205_7_write);
          drop(v205_6);
          compose(&(v204_5),&(v205_7))
        };
        drop(v204_5);
        let v204_9: Space = intersect(&(*CONSTANT_1),&(v204_2));
        drop(v204_2);
        let v204_10: Space = if has_head(&(v204_9)) { singleton(&[]) } else { Space::new() };
        drop(v204_9);
        let v204_11: Space = compose(&(v204_10),&v191_20_cursor);
        drop(v204_10);
        let v204_12: Space = unite(&(v204_8),&(v204_11));
        drop(v204_11);
        join_wrapped_into(&mut v203_11_write,&((v204_12).read_zipper()),&[]);
        }
        v191_20_cursor.ascend(1);
      }
      drop(v203_11_write);
      drop(v203_6);
      compose(&(v192_10),&(v203_11))
    };
    drop(v192_10);
    let v192_13: Space = unite(&(v192_8),&(v192_12));
    join_wrapped_into(&mut v191_20_write,&((v192_13).read_zipper()),&[]);
    }
    v191_20_cursor.ascend(1);
  }
  drop(v191_20_cursor);
  drop(v191_20_write);
  (v191_20).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v209_14 = Space::new();
  let mut v209_14_write = v209_14.write_zipper();
  let mut v209_14_cursor = (*s0).read_zipper();
  let v209_14_origin = v209_14_cursor.path().len();
  for v209_14_byte in v209_14_cursor.child_mask().iter() {
    v209_14_cursor.descend_to_existing_byte(v209_14_byte);
    {
    let v210_2: Space = singleton(&v209_14_cursor.path()[v209_14_origin..(v209_14_origin + 1)]);
    let v210_3: Space = intersect(&(*CONSTANT_1),&(v210_2));
    let v210_4: Space = if has_head(&(v210_3)) { singleton(&[]) } else { Space::new() };
    drop(v210_3);
    let v210_5: Space = subtract(&(*CONSTANT_0),&(v210_4));
    drop(v210_4);
    let v210_8: Space = if (&(v210_5)).is_empty() { Space::new() } else {
      let v211_6: Path = concat_path(&(*p0),&v209_14_cursor.path()[v209_14_origin..(v209_14_origin + 1)]);
      let mut v211_7 = Space::new();
      let mut v211_7_write = v211_7.write_zipper();
      for v211_7_byte in v209_14_cursor.child_mask().iter() {
        v209_14_cursor.descend_to_existing_byte(v211_7_byte);
        {
        let v212_2: Space = singleton(&v209_14_cursor.path()[(v209_14_origin + 1)..(v209_14_origin + 2)]);
        let v212_3: Space = intersect(&(*CONSTANT_1),&(v212_2));
        let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
        drop(v212_3);
        let v212_5: Space = subtract(&(*CONSTANT_0),&(v212_4));
        drop(v212_4);
        let v212_8: Space = if (&(v212_5)).is_empty() { Space::new() } else {
          let v213_6: Path = concat_path(&(v211_6),&v209_14_cursor.path()[(v209_14_origin + 1)..(v209_14_origin + 2)]);
          let mut v213_7 = Space::new();
          let mut v213_7_write = v213_7.write_zipper();
          for v213_7_byte in v209_14_cursor.child_mask().iter() {
            v209_14_cursor.descend_to_existing_byte(v213_7_byte);
            {
            let v214_2: Space = singleton(&v209_14_cursor.path()[(v209_14_origin + 2)..(v209_14_origin + 3)]);
            let v214_3: Space = intersect(&(*CONSTANT_1),&(v214_2));
            let v214_4: Space = if has_head(&(v214_3)) { singleton(&[]) } else { Space::new() };
            drop(v214_3);
            let v214_5: Space = subtract(&(*CONSTANT_0),&(v214_4));
            drop(v214_4);
            let v214_8: Space = if (&(v214_5)).is_empty() { Space::new() } else {
              let v215_6: Path = concat_path(&(v213_6),&v209_14_cursor.path()[(v209_14_origin + 2)..(v209_14_origin + 3)]);
              let v215_7: Space = routine_24(c, &(v215_6), &v209_14_cursor);
              compose(&(v214_5),&(v215_7))
            };
            drop(v214_5);
            let v214_9: Space = intersect(&(*CONSTANT_1),&(v214_2));
            drop(v214_2);
            let v214_10: Space = if has_head(&(v214_9)) { singleton(&[]) } else { Space::new() };
            drop(v214_9);
            let v214_12: Space = if (&(v214_10)).is_empty() { Space::new() } else {
              let v216_6: Path = concat_path(&(v213_6),&v209_14_cursor.path()[(v209_14_origin + 2)..(v209_14_origin + 3)]);
              let v216_11: Space = routine_25(c, &(v216_6), &v209_14_cursor);
              drop(v216_6);
              compose(&(v214_10),&(v216_11))
            };
            drop(v214_10);
            let v214_13: Space = unite(&(v214_8),&(v214_12));
            join_wrapped_into(&mut v213_7_write,&((v214_13).read_zipper()),&[]);
            }
            v209_14_cursor.ascend(1);
          }
          drop(v213_7_write);
          compose(&(v212_5),&(v213_7))
        };
        drop(v212_5);
        let v212_9: Space = intersect(&(*CONSTANT_1),&(v212_2));
        drop(v212_2);
        let v212_10: Space = if has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
        drop(v212_9);
        let v212_12: Space = if (&(v212_10)).is_empty() { Space::new() } else {
          let v217_6: Path = concat_path(&(v211_6),&v209_14_cursor.path()[(v209_14_origin + 1)..(v209_14_origin + 2)]);
          let mut v217_11 = Space::new();
          let mut v217_11_write = v217_11.write_zipper();
          for v217_11_byte in v209_14_cursor.child_mask().iter() {
            v209_14_cursor.descend_to_existing_byte(v217_11_byte);
            {
            let v218_2: Space = singleton(&v209_14_cursor.path()[(v209_14_origin + 2)..(v209_14_origin + 3)]);
            let v218_3: Space = intersect(&(*CONSTANT_1),&(v218_2));
            let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
            drop(v218_3);
            let v218_5: Space = subtract(&(*CONSTANT_0),&(v218_4));
            drop(v218_4);
            let v218_8: Space = if (&(v218_5)).is_empty() { Space::new() } else {
              let v219_6: Path = concat_path(&(v217_6),&v209_14_cursor.path()[(v209_14_origin + 2)..(v209_14_origin + 3)]);
              let v219_7: Space = routine_24(c, &(v219_6), &v209_14_cursor);
              compose(&(v218_5),&(v219_7))
            };
            drop(v218_5);
            let v218_9: Space = intersect(&(*CONSTANT_1),&(v218_2));
            drop(v218_2);
            let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
            drop(v218_9);
            let v218_12: Space = if (&(v218_10)).is_empty() { Space::new() } else {
              let v220_6: Path = concat_path(&(v217_6),&v209_14_cursor.path()[(v209_14_origin + 2)..(v209_14_origin + 3)]);
              let v220_11: Space = routine_15(c, &(v220_6), &v209_14_cursor);
              drop(v220_6);
              compose(&(v218_10),&(v220_11))
            };
            drop(v218_10);
            let v218_13: Space = unite(&(v218_8),&(v218_12));
            join_wrapped_into(&mut v217_11_write,&((v218_13).read_zipper()),&[]);
            }
            v209_14_cursor.ascend(1);
          }
          drop(v217_11_write);
          drop(v217_6);
          compose(&(v212_10),&(v217_11))
        };
        drop(v212_10);
        let v212_13: Space = unite(&(v212_8),&(v212_12));
        join_wrapped_into(&mut v211_7_write,&((v212_13).read_zipper()),&[]);
        }
        v209_14_cursor.ascend(1);
      }
      drop(v211_7_write);
      drop(v211_6);
      compose(&(v210_5),&(v211_7))
    };
    drop(v210_5);
    let v210_9: Space = intersect(&(*CONSTANT_1),&(v210_2));
    drop(v210_2);
    let v210_10: Space = if has_head(&(v210_9)) { singleton(&[]) } else { Space::new() };
    drop(v210_9);
    let v210_11: Space = compose(&(v210_10),&v209_14_cursor);
    drop(v210_10);
    let v210_12: Space = unite(&(v210_8),&(v210_11));
    drop(v210_11);
    join_wrapped_into(&mut v209_14_write,&((v210_12).read_zipper()),&[]);
    }
    v209_14_cursor.ascend(1);
  }
  drop(v209_14_cursor);
  drop(v209_14_write);
  (v209_14).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v221_20 = Space::new();
  let mut v221_20_write = v221_20.write_zipper();
  let mut v221_20_cursor = (*s0).read_zipper();
  let v221_20_origin = v221_20_cursor.path().len();
  for v221_20_byte in v221_20_cursor.child_mask().iter() {
    v221_20_cursor.descend_to_existing_byte(v221_20_byte);
    {
    let v222_2: Space = singleton(&v221_20_cursor.path()[v221_20_origin..(v221_20_origin + 1)]);
    let v222_3: Space = intersect(&(*CONSTANT_1),&(v222_2));
    let v222_4: Space = if has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
    drop(v222_3);
    let v222_5: Space = subtract(&(*CONSTANT_0),&(v222_4));
    drop(v222_4);
    let v222_8: Space = if (&(v222_5)).is_empty() { Space::new() } else {
      let v223_6: Path = concat_path(&(*p0),&v221_20_cursor.path()[v221_20_origin..(v221_20_origin + 1)]);
      let mut v223_7 = Space::new();
      let mut v223_7_write = v223_7.write_zipper();
      for v223_7_byte in v221_20_cursor.child_mask().iter() {
        v221_20_cursor.descend_to_existing_byte(v223_7_byte);
        {
        let v224_2: Space = singleton(&v221_20_cursor.path()[(v221_20_origin + 1)..(v221_20_origin + 2)]);
        let v224_3: Space = intersect(&(*CONSTANT_1),&(v224_2));
        let v224_4: Space = if has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
        drop(v224_3);
        let v224_5: Space = subtract(&(*CONSTANT_0),&(v224_4));
        drop(v224_4);
        let v224_8: Space = if (&(v224_5)).is_empty() { Space::new() } else {
          let v225_6: Path = concat_path(&(v223_6),&v221_20_cursor.path()[(v221_20_origin + 1)..(v221_20_origin + 2)]);
          let mut v225_7 = Space::new();
          let mut v225_7_write = v225_7.write_zipper();
          for v225_7_byte in v221_20_cursor.child_mask().iter() {
            v221_20_cursor.descend_to_existing_byte(v225_7_byte);
            {
            let v226_2: Space = singleton(&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
            let v226_3: Space = intersect(&(*CONSTANT_1),&(v226_2));
            let v226_4: Space = if has_head(&(v226_3)) { singleton(&[]) } else { Space::new() };
            drop(v226_3);
            let v226_5: Space = subtract(&(*CONSTANT_0),&(v226_4));
            drop(v226_4);
            let v226_8: Space = if (&(v226_5)).is_empty() { Space::new() } else {
              let v227_6: Path = concat_path(&(v225_6),&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
              let v227_7: Space = routine_26(c, &(v227_6), &v221_20_cursor);
              compose(&(v226_5),&(v227_7))
            };
            drop(v226_5);
            let v226_9: Space = intersect(&(*CONSTANT_1),&(v226_2));
            drop(v226_2);
            let v226_10: Space = if has_head(&(v226_9)) { singleton(&[]) } else { Space::new() };
            drop(v226_9);
            let v226_12: Space = if (&(v226_10)).is_empty() { Space::new() } else {
              let v228_6: Path = concat_path(&(v225_6),&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
              let v228_11: Space = routine_27(c, &(v228_6), &v221_20_cursor);
              drop(v228_6);
              compose(&(v226_10),&(v228_11))
            };
            drop(v226_10);
            let v226_13: Space = unite(&(v226_8),&(v226_12));
            join_wrapped_into(&mut v225_7_write,&((v226_13).read_zipper()),&[]);
            }
            v221_20_cursor.ascend(1);
          }
          drop(v225_7_write);
          compose(&(v224_5),&(v225_7))
        };
        drop(v224_5);
        let v224_9: Space = intersect(&(*CONSTANT_1),&(v224_2));
        drop(v224_2);
        let v224_10: Space = if has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
        drop(v224_9);
        let v224_12: Space = if (&(v224_10)).is_empty() { Space::new() } else {
          let v229_6: Path = concat_path(&(v223_6),&v221_20_cursor.path()[(v221_20_origin + 1)..(v221_20_origin + 2)]);
          let mut v229_11 = Space::new();
          let mut v229_11_write = v229_11.write_zipper();
          for v229_11_byte in v221_20_cursor.child_mask().iter() {
            v221_20_cursor.descend_to_existing_byte(v229_11_byte);
            {
            let v230_2: Space = singleton(&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
            let v230_3: Space = intersect(&(*CONSTANT_1),&(v230_2));
            let v230_4: Space = if has_head(&(v230_3)) { singleton(&[]) } else { Space::new() };
            drop(v230_3);
            let v230_5: Space = subtract(&(*CONSTANT_0),&(v230_4));
            drop(v230_4);
            let v230_8: Space = if (&(v230_5)).is_empty() { Space::new() } else {
              let v231_6: Path = concat_path(&(v229_6),&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
              let v231_7: Space = routine_26(c, &(v231_6), &v221_20_cursor);
              compose(&(v230_5),&(v231_7))
            };
            drop(v230_5);
            let v230_9: Space = intersect(&(*CONSTANT_1),&(v230_2));
            drop(v230_2);
            let v230_10: Space = if has_head(&(v230_9)) { singleton(&[]) } else { Space::new() };
            drop(v230_9);
            let v230_12: Space = if (&(v230_10)).is_empty() { Space::new() } else {
              let v232_6: Path = concat_path(&(v229_6),&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
              let v232_11: Space = routine_12(c, &(v232_6), &v221_20_cursor);
              drop(v232_6);
              compose(&(v230_10),&(v232_11))
            };
            drop(v230_10);
            let v230_13: Space = unite(&(v230_8),&(v230_12));
            join_wrapped_into(&mut v229_11_write,&((v230_13).read_zipper()),&[]);
            }
            v221_20_cursor.ascend(1);
          }
          drop(v229_11_write);
          drop(v229_6);
          compose(&(v224_10),&(v229_11))
        };
        drop(v224_10);
        let v224_13: Space = unite(&(v224_8),&(v224_12));
        join_wrapped_into(&mut v223_7_write,&((v224_13).read_zipper()),&[]);
        }
        v221_20_cursor.ascend(1);
      }
      drop(v223_7_write);
      compose(&(v222_5),&(v223_7))
    };
    drop(v222_5);
    let v222_9: Space = intersect(&(*CONSTANT_1),&(v222_2));
    drop(v222_2);
    let v222_10: Space = if has_head(&(v222_9)) { singleton(&[]) } else { Space::new() };
    drop(v222_9);
    let v222_12: Space = if (&(v222_10)).is_empty() { Space::new() } else {
      let v233_6: Path = concat_path(&(*p0),&v221_20_cursor.path()[v221_20_origin..(v221_20_origin + 1)]);
      let mut v233_11 = Space::new();
      let mut v233_11_write = v233_11.write_zipper();
      for v233_11_byte in v221_20_cursor.child_mask().iter() {
        v221_20_cursor.descend_to_existing_byte(v233_11_byte);
        {
        let v234_2: Space = singleton(&v221_20_cursor.path()[(v221_20_origin + 1)..(v221_20_origin + 2)]);
        let v234_3: Space = intersect(&(*CONSTANT_1),&(v234_2));
        let v234_4: Space = if has_head(&(v234_3)) { singleton(&[]) } else { Space::new() };
        drop(v234_3);
        let v234_5: Space = subtract(&(*CONSTANT_0),&(v234_4));
        drop(v234_4);
        let v234_8: Space = if (&(v234_5)).is_empty() { Space::new() } else {
          let v235_6: Path = concat_path(&(v233_6),&v221_20_cursor.path()[(v221_20_origin + 1)..(v221_20_origin + 2)]);
          let mut v235_7 = Space::new();
          let mut v235_7_write = v235_7.write_zipper();
          for v235_7_byte in v221_20_cursor.child_mask().iter() {
            v221_20_cursor.descend_to_existing_byte(v235_7_byte);
            {
            let v236_2: Space = singleton(&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
            let v236_3: Space = intersect(&(*CONSTANT_1),&(v236_2));
            let v236_4: Space = if has_head(&(v236_3)) { singleton(&[]) } else { Space::new() };
            drop(v236_3);
            let v236_5: Space = subtract(&(*CONSTANT_0),&(v236_4));
            drop(v236_4);
            let v236_8: Space = if (&(v236_5)).is_empty() { Space::new() } else {
              let v237_6: Path = concat_path(&(v235_6),&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
              let v237_7: Space = routine_26(c, &(v237_6), &v221_20_cursor);
              compose(&(v236_5),&(v237_7))
            };
            drop(v236_5);
            let v236_9: Space = intersect(&(*CONSTANT_1),&(v236_2));
            drop(v236_2);
            let v236_10: Space = if has_head(&(v236_9)) { singleton(&[]) } else { Space::new() };
            drop(v236_9);
            let v236_12: Space = if (&(v236_10)).is_empty() { Space::new() } else {
              let v238_6: Path = concat_path(&(v235_6),&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
              let v238_11: Space = routine_27(c, &(v238_6), &v221_20_cursor);
              drop(v238_6);
              compose(&(v236_10),&(v238_11))
            };
            drop(v236_10);
            let v236_13: Space = unite(&(v236_8),&(v236_12));
            join_wrapped_into(&mut v235_7_write,&((v236_13).read_zipper()),&[]);
            }
            v221_20_cursor.ascend(1);
          }
          drop(v235_7_write);
          drop(v235_6);
          compose(&(v234_5),&(v235_7))
        };
        drop(v234_5);
        let v234_9: Space = intersect(&(*CONSTANT_1),&(v234_2));
        drop(v234_2);
        let v234_10: Space = if has_head(&(v234_9)) { singleton(&[]) } else { Space::new() };
        drop(v234_9);
        let v234_11: Space = compose(&(v234_10),&v221_20_cursor);
        drop(v234_10);
        let v234_12: Space = unite(&(v234_8),&(v234_11));
        drop(v234_11);
        join_wrapped_into(&mut v233_11_write,&((v234_12).read_zipper()),&[]);
        }
        v221_20_cursor.ascend(1);
      }
      drop(v233_11_write);
      drop(v233_6);
      compose(&(v222_10),&(v233_11))
    };
    drop(v222_10);
    let v222_13: Space = unite(&(v222_8),&(v222_12));
    join_wrapped_into(&mut v221_20_write,&((v222_13).read_zipper()),&[]);
    }
    v221_20_cursor.ascend(1);
  }
  drop(v221_20_cursor);
  drop(v221_20_write);
  (v221_20).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v239_14 = Space::new();
  let mut v239_14_write = v239_14.write_zipper();
  let mut v239_14_cursor = (*s0).read_zipper();
  let v239_14_origin = v239_14_cursor.path().len();
  for v239_14_byte in v239_14_cursor.child_mask().iter() {
    v239_14_cursor.descend_to_existing_byte(v239_14_byte);
    {
    let v240_2: Space = singleton(&v239_14_cursor.path()[v239_14_origin..(v239_14_origin + 1)]);
    let v240_3: Space = intersect(&(*CONSTANT_1),&(v240_2));
    let v240_4: Space = if has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
    drop(v240_3);
    let v240_5: Space = subtract(&(*CONSTANT_0),&(v240_4));
    drop(v240_4);
    let v240_8: Space = if (&(v240_5)).is_empty() { Space::new() } else {
      let v241_6: Path = concat_path(&(*p0),&v239_14_cursor.path()[v239_14_origin..(v239_14_origin + 1)]);
      let mut v241_7 = Space::new();
      let mut v241_7_write = v241_7.write_zipper();
      for v241_7_byte in v239_14_cursor.child_mask().iter() {
        v239_14_cursor.descend_to_existing_byte(v241_7_byte);
        {
        let v242_2: Space = singleton(&v239_14_cursor.path()[(v239_14_origin + 1)..(v239_14_origin + 2)]);
        let v242_3: Space = intersect(&(*CONSTANT_1),&(v242_2));
        let v242_4: Space = if has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
        drop(v242_3);
        let v242_5: Space = subtract(&(*CONSTANT_0),&(v242_4));
        drop(v242_4);
        let v242_8: Space = if (&(v242_5)).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v241_6),&v239_14_cursor.path()[(v239_14_origin + 1)..(v239_14_origin + 2)]);
          let mut v243_7 = Space::new();
          let mut v243_7_write = v243_7.write_zipper();
          for v243_7_byte in v239_14_cursor.child_mask().iter() {
            v239_14_cursor.descend_to_existing_byte(v243_7_byte);
            {
            let v244_2: Space = singleton(&v239_14_cursor.path()[(v239_14_origin + 2)..(v239_14_origin + 3)]);
            let v244_3: Space = intersect(&(*CONSTANT_1),&(v244_2));
            let v244_4: Space = if has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
            drop(v244_3);
            let v244_5: Space = subtract(&(*CONSTANT_0),&(v244_4));
            drop(v244_4);
            let v244_8: Space = if (&(v244_5)).is_empty() { Space::new() } else {
              let v245_6: Path = concat_path(&(v243_6),&v239_14_cursor.path()[(v239_14_origin + 2)..(v239_14_origin + 3)]);
              let v245_7: Space = routine_26(c, &(v245_6), &v239_14_cursor);
              compose(&(v244_5),&(v245_7))
            };
            drop(v244_5);
            let v244_9: Space = intersect(&(*CONSTANT_1),&(v244_2));
            drop(v244_2);
            let v244_10: Space = if has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
            drop(v244_9);
            let v244_12: Space = if (&(v244_10)).is_empty() { Space::new() } else {
              let v246_6: Path = concat_path(&(v243_6),&v239_14_cursor.path()[(v239_14_origin + 2)..(v239_14_origin + 3)]);
              let v246_11: Space = routine_27(c, &(v246_6), &v239_14_cursor);
              drop(v246_6);
              compose(&(v244_10),&(v246_11))
            };
            drop(v244_10);
            let v244_13: Space = unite(&(v244_8),&(v244_12));
            join_wrapped_into(&mut v243_7_write,&((v244_13).read_zipper()),&[]);
            }
            v239_14_cursor.ascend(1);
          }
          drop(v243_7_write);
          compose(&(v242_5),&(v243_7))
        };
        drop(v242_5);
        let v242_9: Space = intersect(&(*CONSTANT_1),&(v242_2));
        drop(v242_2);
        let v242_10: Space = if has_head(&(v242_9)) { singleton(&[]) } else { Space::new() };
        drop(v242_9);
        let v242_12: Space = if (&(v242_10)).is_empty() { Space::new() } else {
          let v247_6: Path = concat_path(&(v241_6),&v239_14_cursor.path()[(v239_14_origin + 1)..(v239_14_origin + 2)]);
          let mut v247_11 = Space::new();
          let mut v247_11_write = v247_11.write_zipper();
          for v247_11_byte in v239_14_cursor.child_mask().iter() {
            v239_14_cursor.descend_to_existing_byte(v247_11_byte);
            {
            let v248_2: Space = singleton(&v239_14_cursor.path()[(v239_14_origin + 2)..(v239_14_origin + 3)]);
            let v248_3: Space = intersect(&(*CONSTANT_1),&(v248_2));
            let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
            drop(v248_3);
            let v248_5: Space = subtract(&(*CONSTANT_0),&(v248_4));
            drop(v248_4);
            let v248_8: Space = if (&(v248_5)).is_empty() { Space::new() } else {
              let v249_6: Path = concat_path(&(v247_6),&v239_14_cursor.path()[(v239_14_origin + 2)..(v239_14_origin + 3)]);
              let v249_7: Space = routine_26(c, &(v249_6), &v239_14_cursor);
              compose(&(v248_5),&(v249_7))
            };
            drop(v248_5);
            let v248_9: Space = intersect(&(*CONSTANT_1),&(v248_2));
            drop(v248_2);
            let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
            drop(v248_9);
            let v248_12: Space = if (&(v248_10)).is_empty() { Space::new() } else {
              let v250_6: Path = concat_path(&(v247_6),&v239_14_cursor.path()[(v239_14_origin + 2)..(v239_14_origin + 3)]);
              let v250_11: Space = routine_12(c, &(v250_6), &v239_14_cursor);
              drop(v250_6);
              compose(&(v248_10),&(v250_11))
            };
            drop(v248_10);
            let v248_13: Space = unite(&(v248_8),&(v248_12));
            join_wrapped_into(&mut v247_11_write,&((v248_13).read_zipper()),&[]);
            }
            v239_14_cursor.ascend(1);
          }
          drop(v247_11_write);
          drop(v247_6);
          compose(&(v242_10),&(v247_11))
        };
        drop(v242_10);
        let v242_13: Space = unite(&(v242_8),&(v242_12));
        join_wrapped_into(&mut v241_7_write,&((v242_13).read_zipper()),&[]);
        }
        v239_14_cursor.ascend(1);
      }
      drop(v241_7_write);
      drop(v241_6);
      compose(&(v240_5),&(v241_7))
    };
    drop(v240_5);
    let v240_9: Space = intersect(&(*CONSTANT_1),&(v240_2));
    drop(v240_2);
    let v240_10: Space = if has_head(&(v240_9)) { singleton(&[]) } else { Space::new() };
    drop(v240_9);
    let v240_11: Space = compose(&(v240_10),&v239_14_cursor);
    drop(v240_10);
    let v240_12: Space = unite(&(v240_8),&(v240_11));
    drop(v240_11);
    join_wrapped_into(&mut v239_14_write,&((v240_12).read_zipper()),&[]);
    }
    v239_14_cursor.ascend(1);
  }
  drop(v239_14_cursor);
  drop(v239_14_write);
  (v239_14).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v252_20 = Space::new();
  let mut v252_20_write = v252_20.write_zipper();
  let mut v252_20_cursor = (*s0).read_zipper();
  let v252_20_origin = v252_20_cursor.path().len();
  for v252_20_byte in v252_20_cursor.child_mask().iter() {
    v252_20_cursor.descend_to_existing_byte(v252_20_byte);
    {
    let v253_2: Space = singleton(&v252_20_cursor.path()[v252_20_origin..(v252_20_origin + 1)]);
    let v253_3: Space = intersect(&(*CONSTANT_1),&(v253_2));
    let v253_4: Space = if has_head(&(v253_3)) { singleton(&[]) } else { Space::new() };
    drop(v253_3);
    let v253_5: Space = subtract(&(*CONSTANT_0),&(v253_4));
    drop(v253_4);
    let v253_8: Space = if (&(v253_5)).is_empty() { Space::new() } else {
      let v254_6: Path = concat_path(&(*p0),&v252_20_cursor.path()[v252_20_origin..(v252_20_origin + 1)]);
      let mut v254_7 = Space::new();
      let mut v254_7_write = v254_7.write_zipper();
      for v254_7_byte in v252_20_cursor.child_mask().iter() {
        v252_20_cursor.descend_to_existing_byte(v254_7_byte);
        {
        let v255_2: Space = singleton(&v252_20_cursor.path()[(v252_20_origin + 1)..(v252_20_origin + 2)]);
        let v255_3: Space = intersect(&(*CONSTANT_1),&(v255_2));
        let v255_4: Space = if has_head(&(v255_3)) { singleton(&[]) } else { Space::new() };
        drop(v255_3);
        let v255_5: Space = subtract(&(*CONSTANT_0),&(v255_4));
        drop(v255_4);
        let v255_8: Space = if (&(v255_5)).is_empty() { Space::new() } else {
          let v256_6: Path = concat_path(&(v254_6),&v252_20_cursor.path()[(v252_20_origin + 1)..(v252_20_origin + 2)]);
          let mut v256_7 = Space::new();
          let mut v256_7_write = v256_7.write_zipper();
          for v256_7_byte in v252_20_cursor.child_mask().iter() {
            v252_20_cursor.descend_to_existing_byte(v256_7_byte);
            {
            let v257_2: Space = singleton(&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
            let v257_3: Space = intersect(&(*CONSTANT_1),&(v257_2));
            let v257_4: Space = if has_head(&(v257_3)) { singleton(&[]) } else { Space::new() };
            drop(v257_3);
            let v257_5: Space = subtract(&(*CONSTANT_0),&(v257_4));
            drop(v257_4);
            let v257_8: Space = if (&(v257_5)).is_empty() { Space::new() } else {
              let v258_6: Path = concat_path(&(v256_6),&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
              let v258_7: Space = routine_28(c, &(v258_6), &v252_20_cursor);
              compose(&(v257_5),&(v258_7))
            };
            drop(v257_5);
            let v257_9: Space = intersect(&(*CONSTANT_1),&(v257_2));
            drop(v257_2);
            let v257_10: Space = if has_head(&(v257_9)) { singleton(&[]) } else { Space::new() };
            drop(v257_9);
            let v257_12: Space = if (&(v257_10)).is_empty() { Space::new() } else {
              let v259_6: Path = concat_path(&(v256_6),&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
              let v259_11: Space = routine_29(c, &(v259_6), &v252_20_cursor);
              drop(v259_6);
              compose(&(v257_10),&(v259_11))
            };
            drop(v257_10);
            let v257_13: Space = unite(&(v257_8),&(v257_12));
            join_wrapped_into(&mut v256_7_write,&((v257_13).read_zipper()),&[]);
            }
            v252_20_cursor.ascend(1);
          }
          drop(v256_7_write);
          compose(&(v255_5),&(v256_7))
        };
        drop(v255_5);
        let v255_9: Space = intersect(&(*CONSTANT_1),&(v255_2));
        drop(v255_2);
        let v255_10: Space = if has_head(&(v255_9)) { singleton(&[]) } else { Space::new() };
        drop(v255_9);
        let v255_12: Space = if (&(v255_10)).is_empty() { Space::new() } else {
          let v260_6: Path = concat_path(&(v254_6),&v252_20_cursor.path()[(v252_20_origin + 1)..(v252_20_origin + 2)]);
          let mut v260_11 = Space::new();
          let mut v260_11_write = v260_11.write_zipper();
          for v260_11_byte in v252_20_cursor.child_mask().iter() {
            v252_20_cursor.descend_to_existing_byte(v260_11_byte);
            {
            let v261_2: Space = singleton(&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
            let v261_3: Space = intersect(&(*CONSTANT_1),&(v261_2));
            let v261_4: Space = if has_head(&(v261_3)) { singleton(&[]) } else { Space::new() };
            drop(v261_3);
            let v261_5: Space = subtract(&(*CONSTANT_0),&(v261_4));
            drop(v261_4);
            let v261_8: Space = if (&(v261_5)).is_empty() { Space::new() } else {
              let v262_6: Path = concat_path(&(v260_6),&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
              let v262_7: Space = routine_28(c, &(v262_6), &v252_20_cursor);
              compose(&(v261_5),&(v262_7))
            };
            drop(v261_5);
            let v261_9: Space = intersect(&(*CONSTANT_1),&(v261_2));
            drop(v261_2);
            let v261_10: Space = if has_head(&(v261_9)) { singleton(&[]) } else { Space::new() };
            drop(v261_9);
            let v261_12: Space = if (&(v261_10)).is_empty() { Space::new() } else {
              let v263_6: Path = concat_path(&(v260_6),&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
              let v263_11: Space = routine_15(c, &(v263_6), &v252_20_cursor);
              drop(v263_6);
              compose(&(v261_10),&(v263_11))
            };
            drop(v261_10);
            let v261_13: Space = unite(&(v261_8),&(v261_12));
            join_wrapped_into(&mut v260_11_write,&((v261_13).read_zipper()),&[]);
            }
            v252_20_cursor.ascend(1);
          }
          drop(v260_11_write);
          drop(v260_6);
          compose(&(v255_10),&(v260_11))
        };
        drop(v255_10);
        let v255_13: Space = unite(&(v255_8),&(v255_12));
        join_wrapped_into(&mut v254_7_write,&((v255_13).read_zipper()),&[]);
        }
        v252_20_cursor.ascend(1);
      }
      drop(v254_7_write);
      compose(&(v253_5),&(v254_7))
    };
    drop(v253_5);
    let v253_9: Space = intersect(&(*CONSTANT_1),&(v253_2));
    drop(v253_2);
    let v253_10: Space = if has_head(&(v253_9)) { singleton(&[]) } else { Space::new() };
    drop(v253_9);
    let v253_12: Space = if (&(v253_10)).is_empty() { Space::new() } else {
      let v264_6: Path = concat_path(&(*p0),&v252_20_cursor.path()[v252_20_origin..(v252_20_origin + 1)]);
      let mut v264_11 = Space::new();
      let mut v264_11_write = v264_11.write_zipper();
      for v264_11_byte in v252_20_cursor.child_mask().iter() {
        v252_20_cursor.descend_to_existing_byte(v264_11_byte);
        {
        let v265_2: Space = singleton(&v252_20_cursor.path()[(v252_20_origin + 1)..(v252_20_origin + 2)]);
        let v265_3: Space = intersect(&(*CONSTANT_1),&(v265_2));
        let v265_4: Space = if has_head(&(v265_3)) { singleton(&[]) } else { Space::new() };
        drop(v265_3);
        let v265_5: Space = subtract(&(*CONSTANT_0),&(v265_4));
        drop(v265_4);
        let v265_8: Space = if (&(v265_5)).is_empty() { Space::new() } else {
          let v266_6: Path = concat_path(&(v264_6),&v252_20_cursor.path()[(v252_20_origin + 1)..(v252_20_origin + 2)]);
          let mut v266_7 = Space::new();
          let mut v266_7_write = v266_7.write_zipper();
          for v266_7_byte in v252_20_cursor.child_mask().iter() {
            v252_20_cursor.descend_to_existing_byte(v266_7_byte);
            {
            let v267_2: Space = singleton(&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
            let v267_3: Space = intersect(&(*CONSTANT_1),&(v267_2));
            let v267_4: Space = if has_head(&(v267_3)) { singleton(&[]) } else { Space::new() };
            drop(v267_3);
            let v267_5: Space = subtract(&(*CONSTANT_0),&(v267_4));
            drop(v267_4);
            let v267_8: Space = if (&(v267_5)).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v266_6),&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
              let v268_7: Space = routine_28(c, &(v268_6), &v252_20_cursor);
              compose(&(v267_5),&(v268_7))
            };
            drop(v267_5);
            let v267_9: Space = intersect(&(*CONSTANT_1),&(v267_2));
            drop(v267_2);
            let v267_10: Space = if has_head(&(v267_9)) { singleton(&[]) } else { Space::new() };
            drop(v267_9);
            let v267_12: Space = if (&(v267_10)).is_empty() { Space::new() } else {
              let v269_6: Path = concat_path(&(v266_6),&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
              let v269_11: Space = routine_29(c, &(v269_6), &v252_20_cursor);
              drop(v269_6);
              compose(&(v267_10),&(v269_11))
            };
            drop(v267_10);
            let v267_13: Space = unite(&(v267_8),&(v267_12));
            join_wrapped_into(&mut v266_7_write,&((v267_13).read_zipper()),&[]);
            }
            v252_20_cursor.ascend(1);
          }
          drop(v266_7_write);
          drop(v266_6);
          compose(&(v265_5),&(v266_7))
        };
        drop(v265_5);
        let v265_9: Space = intersect(&(*CONSTANT_1),&(v265_2));
        drop(v265_2);
        let v265_10: Space = if has_head(&(v265_9)) { singleton(&[]) } else { Space::new() };
        drop(v265_9);
        let v265_11: Space = compose(&(v265_10),&v252_20_cursor);
        drop(v265_10);
        let v265_12: Space = unite(&(v265_8),&(v265_11));
        drop(v265_11);
        join_wrapped_into(&mut v264_11_write,&((v265_12).read_zipper()),&[]);
        }
        v252_20_cursor.ascend(1);
      }
      drop(v264_11_write);
      drop(v264_6);
      compose(&(v253_10),&(v264_11))
    };
    drop(v253_10);
    let v253_13: Space = unite(&(v253_8),&(v253_12));
    join_wrapped_into(&mut v252_20_write,&((v253_13).read_zipper()),&[]);
    }
    v252_20_cursor.ascend(1);
  }
  drop(v252_20_cursor);
  drop(v252_20_write);
  (v252_20).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v270_14 = Space::new();
  let mut v270_14_write = v270_14.write_zipper();
  let mut v270_14_cursor = (*s0).read_zipper();
  let v270_14_origin = v270_14_cursor.path().len();
  for v270_14_byte in v270_14_cursor.child_mask().iter() {
    v270_14_cursor.descend_to_existing_byte(v270_14_byte);
    {
    let v271_2: Space = singleton(&v270_14_cursor.path()[v270_14_origin..(v270_14_origin + 1)]);
    let v271_3: Space = intersect(&(*CONSTANT_1),&(v271_2));
    let v271_4: Space = if has_head(&(v271_3)) { singleton(&[]) } else { Space::new() };
    drop(v271_3);
    let v271_5: Space = subtract(&(*CONSTANT_0),&(v271_4));
    drop(v271_4);
    let v271_8: Space = if (&(v271_5)).is_empty() { Space::new() } else {
      let v272_6: Path = concat_path(&(*p0),&v270_14_cursor.path()[v270_14_origin..(v270_14_origin + 1)]);
      let mut v272_7 = Space::new();
      let mut v272_7_write = v272_7.write_zipper();
      for v272_7_byte in v270_14_cursor.child_mask().iter() {
        v270_14_cursor.descend_to_existing_byte(v272_7_byte);
        {
        let v273_2: Space = singleton(&v270_14_cursor.path()[(v270_14_origin + 1)..(v270_14_origin + 2)]);
        let v273_3: Space = intersect(&(*CONSTANT_1),&(v273_2));
        let v273_4: Space = if has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
        drop(v273_3);
        let v273_5: Space = subtract(&(*CONSTANT_0),&(v273_4));
        drop(v273_4);
        let v273_8: Space = if (&(v273_5)).is_empty() { Space::new() } else {
          let v274_6: Path = concat_path(&(v272_6),&v270_14_cursor.path()[(v270_14_origin + 1)..(v270_14_origin + 2)]);
          let mut v274_7 = Space::new();
          let mut v274_7_write = v274_7.write_zipper();
          for v274_7_byte in v270_14_cursor.child_mask().iter() {
            v270_14_cursor.descend_to_existing_byte(v274_7_byte);
            {
            let v275_2: Space = singleton(&v270_14_cursor.path()[(v270_14_origin + 2)..(v270_14_origin + 3)]);
            let v275_3: Space = intersect(&(*CONSTANT_1),&(v275_2));
            let v275_4: Space = if has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
            drop(v275_3);
            let v275_5: Space = subtract(&(*CONSTANT_0),&(v275_4));
            drop(v275_4);
            let v275_8: Space = if (&(v275_5)).is_empty() { Space::new() } else {
              let v276_6: Path = concat_path(&(v274_6),&v270_14_cursor.path()[(v270_14_origin + 2)..(v270_14_origin + 3)]);
              let v276_7: Space = routine_28(c, &(v276_6), &v270_14_cursor);
              compose(&(v275_5),&(v276_7))
            };
            drop(v275_5);
            let v275_9: Space = intersect(&(*CONSTANT_1),&(v275_2));
            drop(v275_2);
            let v275_10: Space = if has_head(&(v275_9)) { singleton(&[]) } else { Space::new() };
            drop(v275_9);
            let v275_12: Space = if (&(v275_10)).is_empty() { Space::new() } else {
              let v277_6: Path = concat_path(&(v274_6),&v270_14_cursor.path()[(v270_14_origin + 2)..(v270_14_origin + 3)]);
              let v277_11: Space = routine_29(c, &(v277_6), &v270_14_cursor);
              drop(v277_6);
              compose(&(v275_10),&(v277_11))
            };
            drop(v275_10);
            let v275_13: Space = unite(&(v275_8),&(v275_12));
            join_wrapped_into(&mut v274_7_write,&((v275_13).read_zipper()),&[]);
            }
            v270_14_cursor.ascend(1);
          }
          drop(v274_7_write);
          compose(&(v273_5),&(v274_7))
        };
        drop(v273_5);
        let v273_9: Space = intersect(&(*CONSTANT_1),&(v273_2));
        drop(v273_2);
        let v273_10: Space = if has_head(&(v273_9)) { singleton(&[]) } else { Space::new() };
        drop(v273_9);
        let v273_12: Space = if (&(v273_10)).is_empty() { Space::new() } else {
          let v278_6: Path = concat_path(&(v272_6),&v270_14_cursor.path()[(v270_14_origin + 1)..(v270_14_origin + 2)]);
          let mut v278_11 = Space::new();
          let mut v278_11_write = v278_11.write_zipper();
          for v278_11_byte in v270_14_cursor.child_mask().iter() {
            v270_14_cursor.descend_to_existing_byte(v278_11_byte);
            {
            let v279_2: Space = singleton(&v270_14_cursor.path()[(v270_14_origin + 2)..(v270_14_origin + 3)]);
            let v279_3: Space = intersect(&(*CONSTANT_1),&(v279_2));
            let v279_4: Space = if has_head(&(v279_3)) { singleton(&[]) } else { Space::new() };
            drop(v279_3);
            let v279_5: Space = subtract(&(*CONSTANT_0),&(v279_4));
            drop(v279_4);
            let v279_8: Space = if (&(v279_5)).is_empty() { Space::new() } else {
              let v280_6: Path = concat_path(&(v278_6),&v270_14_cursor.path()[(v270_14_origin + 2)..(v270_14_origin + 3)]);
              let v280_7: Space = routine_28(c, &(v280_6), &v270_14_cursor);
              compose(&(v279_5),&(v280_7))
            };
            drop(v279_5);
            let v279_9: Space = intersect(&(*CONSTANT_1),&(v279_2));
            drop(v279_2);
            let v279_10: Space = if has_head(&(v279_9)) { singleton(&[]) } else { Space::new() };
            drop(v279_9);
            let v279_12: Space = if (&(v279_10)).is_empty() { Space::new() } else {
              let v281_6: Path = concat_path(&(v278_6),&v270_14_cursor.path()[(v270_14_origin + 2)..(v270_14_origin + 3)]);
              let v281_11: Space = routine_15(c, &(v281_6), &v270_14_cursor);
              drop(v281_6);
              compose(&(v279_10),&(v281_11))
            };
            drop(v279_10);
            let v279_13: Space = unite(&(v279_8),&(v279_12));
            join_wrapped_into(&mut v278_11_write,&((v279_13).read_zipper()),&[]);
            }
            v270_14_cursor.ascend(1);
          }
          drop(v278_11_write);
          drop(v278_6);
          compose(&(v273_10),&(v278_11))
        };
        drop(v273_10);
        let v273_13: Space = unite(&(v273_8),&(v273_12));
        join_wrapped_into(&mut v272_7_write,&((v273_13).read_zipper()),&[]);
        }
        v270_14_cursor.ascend(1);
      }
      drop(v272_7_write);
      drop(v272_6);
      compose(&(v271_5),&(v272_7))
    };
    drop(v271_5);
    let v271_9: Space = intersect(&(*CONSTANT_1),&(v271_2));
    drop(v271_2);
    let v271_10: Space = if has_head(&(v271_9)) { singleton(&[]) } else { Space::new() };
    drop(v271_9);
    let v271_11: Space = compose(&(v271_10),&v270_14_cursor);
    drop(v271_10);
    let v271_12: Space = unite(&(v271_8),&(v271_11));
    drop(v271_11);
    join_wrapped_into(&mut v270_14_write,&((v271_12).read_zipper()),&[]);
    }
    v270_14_cursor.ascend(1);
  }
  drop(v270_14_cursor);
  drop(v270_14_write);
  (v270_14).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_16(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v283_20 = Space::new();
  let mut v283_20_write = v283_20.write_zipper();
  let mut v283_20_cursor = (*s0).read_zipper();
  let v283_20_origin = v283_20_cursor.path().len();
  for v283_20_byte in v283_20_cursor.child_mask().iter() {
    v283_20_cursor.descend_to_existing_byte(v283_20_byte);
    {
    let v284_2: Space = singleton(&v283_20_cursor.path()[v283_20_origin..(v283_20_origin + 1)]);
    let v284_3: Space = intersect(&(*CONSTANT_1),&(v284_2));
    let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
    drop(v284_3);
    let v284_5: Space = subtract(&(*CONSTANT_0),&(v284_4));
    drop(v284_4);
    let v284_8: Space = if (&(v284_5)).is_empty() { Space::new() } else {
      let v285_6: Path = concat_path(&(*p0),&v283_20_cursor.path()[v283_20_origin..(v283_20_origin + 1)]);
      let mut v285_7 = Space::new();
      let mut v285_7_write = v285_7.write_zipper();
      for v285_7_byte in v283_20_cursor.child_mask().iter() {
        v283_20_cursor.descend_to_existing_byte(v285_7_byte);
        {
        let v286_2: Space = singleton(&v283_20_cursor.path()[(v283_20_origin + 1)..(v283_20_origin + 2)]);
        let v286_3: Space = intersect(&(*CONSTANT_1),&(v286_2));
        let v286_4: Space = if has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
        drop(v286_3);
        let v286_5: Space = subtract(&(*CONSTANT_0),&(v286_4));
        drop(v286_4);
        let v286_8: Space = if (&(v286_5)).is_empty() { Space::new() } else {
          let v287_6: Path = concat_path(&(v285_6),&v283_20_cursor.path()[(v283_20_origin + 1)..(v283_20_origin + 2)]);
          let mut v287_7 = Space::new();
          let mut v287_7_write = v287_7.write_zipper();
          for v287_7_byte in v283_20_cursor.child_mask().iter() {
            v283_20_cursor.descend_to_existing_byte(v287_7_byte);
            {
            let v288_2: Space = singleton(&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
            let v288_3: Space = intersect(&(*CONSTANT_1),&(v288_2));
            let v288_4: Space = if has_head(&(v288_3)) { singleton(&[]) } else { Space::new() };
            drop(v288_3);
            let v288_5: Space = subtract(&(*CONSTANT_0),&(v288_4));
            drop(v288_4);
            let v288_8: Space = if (&(v288_5)).is_empty() { Space::new() } else {
              let v289_6: Path = concat_path(&(v287_6),&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
              let v289_7: Space = routine_30(c, &(v289_6), &v283_20_cursor);
              compose(&(v288_5),&(v289_7))
            };
            drop(v288_5);
            let v288_9: Space = intersect(&(*CONSTANT_1),&(v288_2));
            drop(v288_2);
            let v288_10: Space = if has_head(&(v288_9)) { singleton(&[]) } else { Space::new() };
            drop(v288_9);
            let v288_12: Space = if (&(v288_10)).is_empty() { Space::new() } else {
              let v290_6: Path = concat_path(&(v287_6),&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
              let v290_11: Space = routine_31(c, &(v290_6), &v283_20_cursor);
              drop(v290_6);
              compose(&(v288_10),&(v290_11))
            };
            drop(v288_10);
            let v288_13: Space = unite(&(v288_8),&(v288_12));
            join_wrapped_into(&mut v287_7_write,&((v288_13).read_zipper()),&[]);
            }
            v283_20_cursor.ascend(1);
          }
          drop(v287_7_write);
          compose(&(v286_5),&(v287_7))
        };
        drop(v286_5);
        let v286_9: Space = intersect(&(*CONSTANT_1),&(v286_2));
        drop(v286_2);
        let v286_10: Space = if has_head(&(v286_9)) { singleton(&[]) } else { Space::new() };
        drop(v286_9);
        let v286_12: Space = if (&(v286_10)).is_empty() { Space::new() } else {
          let v291_6: Path = concat_path(&(v285_6),&v283_20_cursor.path()[(v283_20_origin + 1)..(v283_20_origin + 2)]);
          let mut v291_11 = Space::new();
          let mut v291_11_write = v291_11.write_zipper();
          for v291_11_byte in v283_20_cursor.child_mask().iter() {
            v283_20_cursor.descend_to_existing_byte(v291_11_byte);
            {
            let v292_2: Space = singleton(&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
            let v292_3: Space = intersect(&(*CONSTANT_1),&(v292_2));
            let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
            drop(v292_3);
            let v292_5: Space = subtract(&(*CONSTANT_0),&(v292_4));
            drop(v292_4);
            let v292_8: Space = if (&(v292_5)).is_empty() { Space::new() } else {
              let v293_6: Path = concat_path(&(v291_6),&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
              let v293_7: Space = routine_30(c, &(v293_6), &v283_20_cursor);
              compose(&(v292_5),&(v293_7))
            };
            drop(v292_5);
            let v292_9: Space = intersect(&(*CONSTANT_1),&(v292_2));
            drop(v292_2);
            let v292_10: Space = if has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
            drop(v292_9);
            let v292_12: Space = if (&(v292_10)).is_empty() { Space::new() } else {
              let v294_6: Path = concat_path(&(v291_6),&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
              let v294_11: Space = routine_12(c, &(v294_6), &v283_20_cursor);
              drop(v294_6);
              compose(&(v292_10),&(v294_11))
            };
            drop(v292_10);
            let v292_13: Space = unite(&(v292_8),&(v292_12));
            join_wrapped_into(&mut v291_11_write,&((v292_13).read_zipper()),&[]);
            }
            v283_20_cursor.ascend(1);
          }
          drop(v291_11_write);
          drop(v291_6);
          compose(&(v286_10),&(v291_11))
        };
        drop(v286_10);
        let v286_13: Space = unite(&(v286_8),&(v286_12));
        join_wrapped_into(&mut v285_7_write,&((v286_13).read_zipper()),&[]);
        }
        v283_20_cursor.ascend(1);
      }
      drop(v285_7_write);
      compose(&(v284_5),&(v285_7))
    };
    drop(v284_5);
    let v284_9: Space = intersect(&(*CONSTANT_1),&(v284_2));
    drop(v284_2);
    let v284_10: Space = if has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
    drop(v284_9);
    let v284_12: Space = if (&(v284_10)).is_empty() { Space::new() } else {
      let v295_6: Path = concat_path(&(*p0),&v283_20_cursor.path()[v283_20_origin..(v283_20_origin + 1)]);
      let mut v295_11 = Space::new();
      let mut v295_11_write = v295_11.write_zipper();
      for v295_11_byte in v283_20_cursor.child_mask().iter() {
        v283_20_cursor.descend_to_existing_byte(v295_11_byte);
        {
        let v296_2: Space = singleton(&v283_20_cursor.path()[(v283_20_origin + 1)..(v283_20_origin + 2)]);
        let v296_3: Space = intersect(&(*CONSTANT_1),&(v296_2));
        let v296_4: Space = if has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
        drop(v296_3);
        let v296_5: Space = subtract(&(*CONSTANT_0),&(v296_4));
        drop(v296_4);
        let v296_8: Space = if (&(v296_5)).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v295_6),&v283_20_cursor.path()[(v283_20_origin + 1)..(v283_20_origin + 2)]);
          let mut v297_7 = Space::new();
          let mut v297_7_write = v297_7.write_zipper();
          for v297_7_byte in v283_20_cursor.child_mask().iter() {
            v283_20_cursor.descend_to_existing_byte(v297_7_byte);
            {
            let v298_2: Space = singleton(&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
            let v298_3: Space = intersect(&(*CONSTANT_1),&(v298_2));
            let v298_4: Space = if has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = subtract(&(*CONSTANT_0),&(v298_4));
            drop(v298_4);
            let v298_8: Space = if (&(v298_5)).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v297_6),&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
              let v299_7: Space = routine_30(c, &(v299_6), &v283_20_cursor);
              compose(&(v298_5),&(v299_7))
            };
            drop(v298_5);
            let v298_9: Space = intersect(&(*CONSTANT_1),&(v298_2));
            drop(v298_2);
            let v298_10: Space = if has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
            drop(v298_9);
            let v298_12: Space = if (&(v298_10)).is_empty() { Space::new() } else {
              let v300_6: Path = concat_path(&(v297_6),&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
              let v300_11: Space = routine_31(c, &(v300_6), &v283_20_cursor);
              drop(v300_6);
              compose(&(v298_10),&(v300_11))
            };
            drop(v298_10);
            let v298_13: Space = unite(&(v298_8),&(v298_12));
            join_wrapped_into(&mut v297_7_write,&((v298_13).read_zipper()),&[]);
            }
            v283_20_cursor.ascend(1);
          }
          drop(v297_7_write);
          drop(v297_6);
          compose(&(v296_5),&(v297_7))
        };
        drop(v296_5);
        let v296_9: Space = intersect(&(*CONSTANT_1),&(v296_2));
        drop(v296_2);
        let v296_10: Space = if has_head(&(v296_9)) { singleton(&[]) } else { Space::new() };
        drop(v296_9);
        let v296_11: Space = compose(&(v296_10),&v283_20_cursor);
        drop(v296_10);
        let v296_12: Space = unite(&(v296_8),&(v296_11));
        drop(v296_11);
        join_wrapped_into(&mut v295_11_write,&((v296_12).read_zipper()),&[]);
        }
        v283_20_cursor.ascend(1);
      }
      drop(v295_11_write);
      drop(v295_6);
      compose(&(v284_10),&(v295_11))
    };
    drop(v284_10);
    let v284_13: Space = unite(&(v284_8),&(v284_12));
    join_wrapped_into(&mut v283_20_write,&((v284_13).read_zipper()),&[]);
    }
    v283_20_cursor.ascend(1);
  }
  drop(v283_20_cursor);
  drop(v283_20_write);
  (v283_20).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v301_14 = Space::new();
  let mut v301_14_write = v301_14.write_zipper();
  let mut v301_14_cursor = (*s0).read_zipper();
  let v301_14_origin = v301_14_cursor.path().len();
  for v301_14_byte in v301_14_cursor.child_mask().iter() {
    v301_14_cursor.descend_to_existing_byte(v301_14_byte);
    {
    let v302_2: Space = singleton(&v301_14_cursor.path()[v301_14_origin..(v301_14_origin + 1)]);
    let v302_3: Space = intersect(&(*CONSTANT_1),&(v302_2));
    let v302_4: Space = if has_head(&(v302_3)) { singleton(&[]) } else { Space::new() };
    drop(v302_3);
    let v302_5: Space = subtract(&(*CONSTANT_0),&(v302_4));
    drop(v302_4);
    let v302_8: Space = if (&(v302_5)).is_empty() { Space::new() } else {
      let v303_6: Path = concat_path(&(*p0),&v301_14_cursor.path()[v301_14_origin..(v301_14_origin + 1)]);
      let mut v303_7 = Space::new();
      let mut v303_7_write = v303_7.write_zipper();
      for v303_7_byte in v301_14_cursor.child_mask().iter() {
        v301_14_cursor.descend_to_existing_byte(v303_7_byte);
        {
        let v304_2: Space = singleton(&v301_14_cursor.path()[(v301_14_origin + 1)..(v301_14_origin + 2)]);
        let v304_3: Space = intersect(&(*CONSTANT_1),&(v304_2));
        let v304_4: Space = if has_head(&(v304_3)) { singleton(&[]) } else { Space::new() };
        drop(v304_3);
        let v304_5: Space = subtract(&(*CONSTANT_0),&(v304_4));
        drop(v304_4);
        let v304_8: Space = if (&(v304_5)).is_empty() { Space::new() } else {
          let v305_6: Path = concat_path(&(v303_6),&v301_14_cursor.path()[(v301_14_origin + 1)..(v301_14_origin + 2)]);
          let mut v305_7 = Space::new();
          let mut v305_7_write = v305_7.write_zipper();
          for v305_7_byte in v301_14_cursor.child_mask().iter() {
            v301_14_cursor.descend_to_existing_byte(v305_7_byte);
            {
            let v306_2: Space = singleton(&v301_14_cursor.path()[(v301_14_origin + 2)..(v301_14_origin + 3)]);
            let v306_3: Space = intersect(&(*CONSTANT_1),&(v306_2));
            let v306_4: Space = if has_head(&(v306_3)) { singleton(&[]) } else { Space::new() };
            drop(v306_3);
            let v306_5: Space = subtract(&(*CONSTANT_0),&(v306_4));
            drop(v306_4);
            let v306_8: Space = if (&(v306_5)).is_empty() { Space::new() } else {
              let v307_6: Path = concat_path(&(v305_6),&v301_14_cursor.path()[(v301_14_origin + 2)..(v301_14_origin + 3)]);
              let v307_7: Space = routine_30(c, &(v307_6), &v301_14_cursor);
              compose(&(v306_5),&(v307_7))
            };
            drop(v306_5);
            let v306_9: Space = intersect(&(*CONSTANT_1),&(v306_2));
            drop(v306_2);
            let v306_10: Space = if has_head(&(v306_9)) { singleton(&[]) } else { Space::new() };
            drop(v306_9);
            let v306_12: Space = if (&(v306_10)).is_empty() { Space::new() } else {
              let v308_6: Path = concat_path(&(v305_6),&v301_14_cursor.path()[(v301_14_origin + 2)..(v301_14_origin + 3)]);
              let v308_11: Space = routine_31(c, &(v308_6), &v301_14_cursor);
              drop(v308_6);
              compose(&(v306_10),&(v308_11))
            };
            drop(v306_10);
            let v306_13: Space = unite(&(v306_8),&(v306_12));
            join_wrapped_into(&mut v305_7_write,&((v306_13).read_zipper()),&[]);
            }
            v301_14_cursor.ascend(1);
          }
          drop(v305_7_write);
          compose(&(v304_5),&(v305_7))
        };
        drop(v304_5);
        let v304_9: Space = intersect(&(*CONSTANT_1),&(v304_2));
        drop(v304_2);
        let v304_10: Space = if has_head(&(v304_9)) { singleton(&[]) } else { Space::new() };
        drop(v304_9);
        let v304_12: Space = if (&(v304_10)).is_empty() { Space::new() } else {
          let v309_6: Path = concat_path(&(v303_6),&v301_14_cursor.path()[(v301_14_origin + 1)..(v301_14_origin + 2)]);
          let mut v309_11 = Space::new();
          let mut v309_11_write = v309_11.write_zipper();
          for v309_11_byte in v301_14_cursor.child_mask().iter() {
            v301_14_cursor.descend_to_existing_byte(v309_11_byte);
            {
            let v310_2: Space = singleton(&v301_14_cursor.path()[(v301_14_origin + 2)..(v301_14_origin + 3)]);
            let v310_3: Space = intersect(&(*CONSTANT_1),&(v310_2));
            let v310_4: Space = if has_head(&(v310_3)) { singleton(&[]) } else { Space::new() };
            drop(v310_3);
            let v310_5: Space = subtract(&(*CONSTANT_0),&(v310_4));
            drop(v310_4);
            let v310_8: Space = if (&(v310_5)).is_empty() { Space::new() } else {
              let v311_6: Path = concat_path(&(v309_6),&v301_14_cursor.path()[(v301_14_origin + 2)..(v301_14_origin + 3)]);
              let v311_7: Space = routine_30(c, &(v311_6), &v301_14_cursor);
              compose(&(v310_5),&(v311_7))
            };
            drop(v310_5);
            let v310_9: Space = intersect(&(*CONSTANT_1),&(v310_2));
            drop(v310_2);
            let v310_10: Space = if has_head(&(v310_9)) { singleton(&[]) } else { Space::new() };
            drop(v310_9);
            let v310_12: Space = if (&(v310_10)).is_empty() { Space::new() } else {
              let v312_6: Path = concat_path(&(v309_6),&v301_14_cursor.path()[(v301_14_origin + 2)..(v301_14_origin + 3)]);
              let v312_11: Space = routine_12(c, &(v312_6), &v301_14_cursor);
              drop(v312_6);
              compose(&(v310_10),&(v312_11))
            };
            drop(v310_10);
            let v310_13: Space = unite(&(v310_8),&(v310_12));
            join_wrapped_into(&mut v309_11_write,&((v310_13).read_zipper()),&[]);
            }
            v301_14_cursor.ascend(1);
          }
          drop(v309_11_write);
          drop(v309_6);
          compose(&(v304_10),&(v309_11))
        };
        drop(v304_10);
        let v304_13: Space = unite(&(v304_8),&(v304_12));
        join_wrapped_into(&mut v303_7_write,&((v304_13).read_zipper()),&[]);
        }
        v301_14_cursor.ascend(1);
      }
      drop(v303_7_write);
      drop(v303_6);
      compose(&(v302_5),&(v303_7))
    };
    drop(v302_5);
    let v302_9: Space = intersect(&(*CONSTANT_1),&(v302_2));
    drop(v302_2);
    let v302_10: Space = if has_head(&(v302_9)) { singleton(&[]) } else { Space::new() };
    drop(v302_9);
    let v302_11: Space = compose(&(v302_10),&v301_14_cursor);
    drop(v302_10);
    let v302_12: Space = unite(&(v302_8),&(v302_11));
    drop(v302_11);
    join_wrapped_into(&mut v301_14_write,&((v302_12).read_zipper()),&[]);
    }
    v301_14_cursor.ascend(1);
  }
  drop(v301_14_cursor);
  drop(v301_14_write);
  (v301_14).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v313_20 = Space::new();
  let mut v313_20_write = v313_20.write_zipper();
  let mut v313_20_cursor = (*s0).read_zipper();
  let v313_20_origin = v313_20_cursor.path().len();
  for v313_20_byte in v313_20_cursor.child_mask().iter() {
    v313_20_cursor.descend_to_existing_byte(v313_20_byte);
    {
    let v314_2: Space = singleton(&v313_20_cursor.path()[v313_20_origin..(v313_20_origin + 1)]);
    let v314_3: Space = intersect(&(*CONSTANT_1),&(v314_2));
    let v314_4: Space = if has_head(&(v314_3)) { singleton(&[]) } else { Space::new() };
    drop(v314_3);
    let v314_5: Space = subtract(&(*CONSTANT_0),&(v314_4));
    drop(v314_4);
    let v314_8: Space = if (&(v314_5)).is_empty() { Space::new() } else {
      let v315_6: Path = concat_path(&(*p0),&v313_20_cursor.path()[v313_20_origin..(v313_20_origin + 1)]);
      let mut v315_7 = Space::new();
      let mut v315_7_write = v315_7.write_zipper();
      for v315_7_byte in v313_20_cursor.child_mask().iter() {
        v313_20_cursor.descend_to_existing_byte(v315_7_byte);
        {
        let v316_2: Space = singleton(&v313_20_cursor.path()[(v313_20_origin + 1)..(v313_20_origin + 2)]);
        let v316_3: Space = intersect(&(*CONSTANT_1),&(v316_2));
        let v316_4: Space = if has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
        drop(v316_3);
        let v316_5: Space = subtract(&(*CONSTANT_0),&(v316_4));
        drop(v316_4);
        let v316_8: Space = if (&(v316_5)).is_empty() { Space::new() } else {
          let v317_6: Path = concat_path(&(v315_6),&v313_20_cursor.path()[(v313_20_origin + 1)..(v313_20_origin + 2)]);
          let mut v317_7 = Space::new();
          let mut v317_7_write = v317_7.write_zipper();
          for v317_7_byte in v313_20_cursor.child_mask().iter() {
            v313_20_cursor.descend_to_existing_byte(v317_7_byte);
            {
            let v318_2: Space = singleton(&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
            let v318_3: Space = intersect(&(*CONSTANT_1),&(v318_2));
            let v318_4: Space = if has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
            drop(v318_3);
            let v318_5: Space = subtract(&(*CONSTANT_0),&(v318_4));
            drop(v318_4);
            let v318_8: Space = if (&(v318_5)).is_empty() { Space::new() } else {
              let v319_6: Path = concat_path(&(v317_6),&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
              let v319_7: Space = routine_32(c, &(v319_6), &v313_20_cursor);
              compose(&(v318_5),&(v319_7))
            };
            drop(v318_5);
            let v318_9: Space = intersect(&(*CONSTANT_1),&(v318_2));
            drop(v318_2);
            let v318_10: Space = if has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
            drop(v318_9);
            let v318_12: Space = if (&(v318_10)).is_empty() { Space::new() } else {
              let v320_6: Path = concat_path(&(v317_6),&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
              let v320_11: Space = routine_33(c, &(v320_6), &v313_20_cursor);
              drop(v320_6);
              compose(&(v318_10),&(v320_11))
            };
            drop(v318_10);
            let v318_13: Space = unite(&(v318_8),&(v318_12));
            join_wrapped_into(&mut v317_7_write,&((v318_13).read_zipper()),&[]);
            }
            v313_20_cursor.ascend(1);
          }
          drop(v317_7_write);
          compose(&(v316_5),&(v317_7))
        };
        drop(v316_5);
        let v316_9: Space = intersect(&(*CONSTANT_1),&(v316_2));
        drop(v316_2);
        let v316_10: Space = if has_head(&(v316_9)) { singleton(&[]) } else { Space::new() };
        drop(v316_9);
        let v316_12: Space = if (&(v316_10)).is_empty() { Space::new() } else {
          let v321_6: Path = concat_path(&(v315_6),&v313_20_cursor.path()[(v313_20_origin + 1)..(v313_20_origin + 2)]);
          let mut v321_11 = Space::new();
          let mut v321_11_write = v321_11.write_zipper();
          for v321_11_byte in v313_20_cursor.child_mask().iter() {
            v313_20_cursor.descend_to_existing_byte(v321_11_byte);
            {
            let v322_2: Space = singleton(&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
            let v322_3: Space = intersect(&(*CONSTANT_1),&(v322_2));
            let v322_4: Space = if has_head(&(v322_3)) { singleton(&[]) } else { Space::new() };
            drop(v322_3);
            let v322_5: Space = subtract(&(*CONSTANT_0),&(v322_4));
            drop(v322_4);
            let v322_8: Space = if (&(v322_5)).is_empty() { Space::new() } else {
              let v323_6: Path = concat_path(&(v321_6),&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
              let v323_7: Space = routine_32(c, &(v323_6), &v313_20_cursor);
              compose(&(v322_5),&(v323_7))
            };
            drop(v322_5);
            let v322_9: Space = intersect(&(*CONSTANT_1),&(v322_2));
            drop(v322_2);
            let v322_10: Space = if has_head(&(v322_9)) { singleton(&[]) } else { Space::new() };
            drop(v322_9);
            let v322_12: Space = if (&(v322_10)).is_empty() { Space::new() } else {
              let v324_6: Path = concat_path(&(v321_6),&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
              let v324_11: Space = routine_15(c, &(v324_6), &v313_20_cursor);
              drop(v324_6);
              compose(&(v322_10),&(v324_11))
            };
            drop(v322_10);
            let v322_13: Space = unite(&(v322_8),&(v322_12));
            join_wrapped_into(&mut v321_11_write,&((v322_13).read_zipper()),&[]);
            }
            v313_20_cursor.ascend(1);
          }
          drop(v321_11_write);
          drop(v321_6);
          compose(&(v316_10),&(v321_11))
        };
        drop(v316_10);
        let v316_13: Space = unite(&(v316_8),&(v316_12));
        join_wrapped_into(&mut v315_7_write,&((v316_13).read_zipper()),&[]);
        }
        v313_20_cursor.ascend(1);
      }
      drop(v315_7_write);
      compose(&(v314_5),&(v315_7))
    };
    drop(v314_5);
    let v314_9: Space = intersect(&(*CONSTANT_1),&(v314_2));
    drop(v314_2);
    let v314_10: Space = if has_head(&(v314_9)) { singleton(&[]) } else { Space::new() };
    drop(v314_9);
    let v314_12: Space = if (&(v314_10)).is_empty() { Space::new() } else {
      let v325_6: Path = concat_path(&(*p0),&v313_20_cursor.path()[v313_20_origin..(v313_20_origin + 1)]);
      let mut v325_11 = Space::new();
      let mut v325_11_write = v325_11.write_zipper();
      for v325_11_byte in v313_20_cursor.child_mask().iter() {
        v313_20_cursor.descend_to_existing_byte(v325_11_byte);
        {
        let v326_2: Space = singleton(&v313_20_cursor.path()[(v313_20_origin + 1)..(v313_20_origin + 2)]);
        let v326_3: Space = intersect(&(*CONSTANT_1),&(v326_2));
        let v326_4: Space = if has_head(&(v326_3)) { singleton(&[]) } else { Space::new() };
        drop(v326_3);
        let v326_5: Space = subtract(&(*CONSTANT_0),&(v326_4));
        drop(v326_4);
        let v326_8: Space = if (&(v326_5)).is_empty() { Space::new() } else {
          let v327_6: Path = concat_path(&(v325_6),&v313_20_cursor.path()[(v313_20_origin + 1)..(v313_20_origin + 2)]);
          let mut v327_7 = Space::new();
          let mut v327_7_write = v327_7.write_zipper();
          for v327_7_byte in v313_20_cursor.child_mask().iter() {
            v313_20_cursor.descend_to_existing_byte(v327_7_byte);
            {
            let v328_2: Space = singleton(&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
            let v328_3: Space = intersect(&(*CONSTANT_1),&(v328_2));
            let v328_4: Space = if has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
            drop(v328_3);
            let v328_5: Space = subtract(&(*CONSTANT_0),&(v328_4));
            drop(v328_4);
            let v328_8: Space = if (&(v328_5)).is_empty() { Space::new() } else {
              let v329_6: Path = concat_path(&(v327_6),&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
              let v329_7: Space = routine_32(c, &(v329_6), &v313_20_cursor);
              compose(&(v328_5),&(v329_7))
            };
            drop(v328_5);
            let v328_9: Space = intersect(&(*CONSTANT_1),&(v328_2));
            drop(v328_2);
            let v328_10: Space = if has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
            drop(v328_9);
            let v328_12: Space = if (&(v328_10)).is_empty() { Space::new() } else {
              let v330_6: Path = concat_path(&(v327_6),&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
              let v330_11: Space = routine_33(c, &(v330_6), &v313_20_cursor);
              drop(v330_6);
              compose(&(v328_10),&(v330_11))
            };
            drop(v328_10);
            let v328_13: Space = unite(&(v328_8),&(v328_12));
            join_wrapped_into(&mut v327_7_write,&((v328_13).read_zipper()),&[]);
            }
            v313_20_cursor.ascend(1);
          }
          drop(v327_7_write);
          drop(v327_6);
          compose(&(v326_5),&(v327_7))
        };
        drop(v326_5);
        let v326_9: Space = intersect(&(*CONSTANT_1),&(v326_2));
        drop(v326_2);
        let v326_10: Space = if has_head(&(v326_9)) { singleton(&[]) } else { Space::new() };
        drop(v326_9);
        let v326_11: Space = compose(&(v326_10),&v313_20_cursor);
        drop(v326_10);
        let v326_12: Space = unite(&(v326_8),&(v326_11));
        drop(v326_11);
        join_wrapped_into(&mut v325_11_write,&((v326_12).read_zipper()),&[]);
        }
        v313_20_cursor.ascend(1);
      }
      drop(v325_11_write);
      drop(v325_6);
      compose(&(v314_10),&(v325_11))
    };
    drop(v314_10);
    let v314_13: Space = unite(&(v314_8),&(v314_12));
    join_wrapped_into(&mut v313_20_write,&((v314_13).read_zipper()),&[]);
    }
    v313_20_cursor.ascend(1);
  }
  drop(v313_20_cursor);
  drop(v313_20_write);
  (v313_20).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v331_14 = Space::new();
  let mut v331_14_write = v331_14.write_zipper();
  let mut v331_14_cursor = (*s0).read_zipper();
  let v331_14_origin = v331_14_cursor.path().len();
  for v331_14_byte in v331_14_cursor.child_mask().iter() {
    v331_14_cursor.descend_to_existing_byte(v331_14_byte);
    {
    let v332_2: Space = singleton(&v331_14_cursor.path()[v331_14_origin..(v331_14_origin + 1)]);
    let v332_3: Space = intersect(&(*CONSTANT_1),&(v332_2));
    let v332_4: Space = if has_head(&(v332_3)) { singleton(&[]) } else { Space::new() };
    drop(v332_3);
    let v332_5: Space = subtract(&(*CONSTANT_0),&(v332_4));
    drop(v332_4);
    let v332_8: Space = if (&(v332_5)).is_empty() { Space::new() } else {
      let v333_6: Path = concat_path(&(*p0),&v331_14_cursor.path()[v331_14_origin..(v331_14_origin + 1)]);
      let mut v333_7 = Space::new();
      let mut v333_7_write = v333_7.write_zipper();
      for v333_7_byte in v331_14_cursor.child_mask().iter() {
        v331_14_cursor.descend_to_existing_byte(v333_7_byte);
        {
        let v334_2: Space = singleton(&v331_14_cursor.path()[(v331_14_origin + 1)..(v331_14_origin + 2)]);
        let v334_3: Space = intersect(&(*CONSTANT_1),&(v334_2));
        let v334_4: Space = if has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
        drop(v334_3);
        let v334_5: Space = subtract(&(*CONSTANT_0),&(v334_4));
        drop(v334_4);
        let v334_8: Space = if (&(v334_5)).is_empty() { Space::new() } else {
          let v335_6: Path = concat_path(&(v333_6),&v331_14_cursor.path()[(v331_14_origin + 1)..(v331_14_origin + 2)]);
          let mut v335_7 = Space::new();
          let mut v335_7_write = v335_7.write_zipper();
          for v335_7_byte in v331_14_cursor.child_mask().iter() {
            v331_14_cursor.descend_to_existing_byte(v335_7_byte);
            {
            let v336_2: Space = singleton(&v331_14_cursor.path()[(v331_14_origin + 2)..(v331_14_origin + 3)]);
            let v336_3: Space = intersect(&(*CONSTANT_1),&(v336_2));
            let v336_4: Space = if has_head(&(v336_3)) { singleton(&[]) } else { Space::new() };
            drop(v336_3);
            let v336_5: Space = subtract(&(*CONSTANT_0),&(v336_4));
            drop(v336_4);
            let v336_8: Space = if (&(v336_5)).is_empty() { Space::new() } else {
              let v337_6: Path = concat_path(&(v335_6),&v331_14_cursor.path()[(v331_14_origin + 2)..(v331_14_origin + 3)]);
              let v337_7: Space = routine_32(c, &(v337_6), &v331_14_cursor);
              compose(&(v336_5),&(v337_7))
            };
            drop(v336_5);
            let v336_9: Space = intersect(&(*CONSTANT_1),&(v336_2));
            drop(v336_2);
            let v336_10: Space = if has_head(&(v336_9)) { singleton(&[]) } else { Space::new() };
            drop(v336_9);
            let v336_12: Space = if (&(v336_10)).is_empty() { Space::new() } else {
              let v338_6: Path = concat_path(&(v335_6),&v331_14_cursor.path()[(v331_14_origin + 2)..(v331_14_origin + 3)]);
              let v338_11: Space = routine_33(c, &(v338_6), &v331_14_cursor);
              drop(v338_6);
              compose(&(v336_10),&(v338_11))
            };
            drop(v336_10);
            let v336_13: Space = unite(&(v336_8),&(v336_12));
            join_wrapped_into(&mut v335_7_write,&((v336_13).read_zipper()),&[]);
            }
            v331_14_cursor.ascend(1);
          }
          drop(v335_7_write);
          compose(&(v334_5),&(v335_7))
        };
        drop(v334_5);
        let v334_9: Space = intersect(&(*CONSTANT_1),&(v334_2));
        drop(v334_2);
        let v334_10: Space = if has_head(&(v334_9)) { singleton(&[]) } else { Space::new() };
        drop(v334_9);
        let v334_12: Space = if (&(v334_10)).is_empty() { Space::new() } else {
          let v339_6: Path = concat_path(&(v333_6),&v331_14_cursor.path()[(v331_14_origin + 1)..(v331_14_origin + 2)]);
          let mut v339_11 = Space::new();
          let mut v339_11_write = v339_11.write_zipper();
          for v339_11_byte in v331_14_cursor.child_mask().iter() {
            v331_14_cursor.descend_to_existing_byte(v339_11_byte);
            {
            let v340_2: Space = singleton(&v331_14_cursor.path()[(v331_14_origin + 2)..(v331_14_origin + 3)]);
            let v340_3: Space = intersect(&(*CONSTANT_1),&(v340_2));
            let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
            drop(v340_3);
            let v340_5: Space = subtract(&(*CONSTANT_0),&(v340_4));
            drop(v340_4);
            let v340_8: Space = if (&(v340_5)).is_empty() { Space::new() } else {
              let v341_6: Path = concat_path(&(v339_6),&v331_14_cursor.path()[(v331_14_origin + 2)..(v331_14_origin + 3)]);
              let v341_7: Space = routine_32(c, &(v341_6), &v331_14_cursor);
              compose(&(v340_5),&(v341_7))
            };
            drop(v340_5);
            let v340_9: Space = intersect(&(*CONSTANT_1),&(v340_2));
            drop(v340_2);
            let v340_10: Space = if has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
            drop(v340_9);
            let v340_12: Space = if (&(v340_10)).is_empty() { Space::new() } else {
              let v342_6: Path = concat_path(&(v339_6),&v331_14_cursor.path()[(v331_14_origin + 2)..(v331_14_origin + 3)]);
              let v342_11: Space = routine_15(c, &(v342_6), &v331_14_cursor);
              drop(v342_6);
              compose(&(v340_10),&(v342_11))
            };
            drop(v340_10);
            let v340_13: Space = unite(&(v340_8),&(v340_12));
            join_wrapped_into(&mut v339_11_write,&((v340_13).read_zipper()),&[]);
            }
            v331_14_cursor.ascend(1);
          }
          drop(v339_11_write);
          drop(v339_6);
          compose(&(v334_10),&(v339_11))
        };
        drop(v334_10);
        let v334_13: Space = unite(&(v334_8),&(v334_12));
        join_wrapped_into(&mut v333_7_write,&((v334_13).read_zipper()),&[]);
        }
        v331_14_cursor.ascend(1);
      }
      drop(v333_7_write);
      drop(v333_6);
      compose(&(v332_5),&(v333_7))
    };
    drop(v332_5);
    let v332_9: Space = intersect(&(*CONSTANT_1),&(v332_2));
    drop(v332_2);
    let v332_10: Space = if has_head(&(v332_9)) { singleton(&[]) } else { Space::new() };
    drop(v332_9);
    let v332_11: Space = compose(&(v332_10),&v331_14_cursor);
    drop(v332_10);
    let v332_12: Space = unite(&(v332_8),&(v332_11));
    drop(v332_11);
    join_wrapped_into(&mut v331_14_write,&((v332_12).read_zipper()),&[]);
    }
    v331_14_cursor.ascend(1);
  }
  drop(v331_14_cursor);
  drop(v331_14_write);
  (v331_14).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v343_18 = Space::new();
  let mut v343_18_write = v343_18.write_zipper();
  let mut v343_18_cursor = (*s0).read_zipper();
  let v343_18_origin = v343_18_cursor.path().len();
  for v343_18_byte in v343_18_cursor.child_mask().iter() {
    v343_18_cursor.descend_to_existing_byte(v343_18_byte);
    {
    let v344_2: Space = singleton(&v343_18_cursor.path()[v343_18_origin..(v343_18_origin + 1)]);
    let v344_3: Space = intersect(&(*CONSTANT_1),&(v344_2));
    drop(v344_2);
    let v344_4: Space = if has_head(&(v344_3)) { singleton(&[]) } else { Space::new() };
    drop(v344_3);
    let v344_8: Space = if (&(v344_4)).is_empty() { Space::new() } else {
      let v345_6: Path = concat_path(&(*p0),&v343_18_cursor.path()[v343_18_origin..(v343_18_origin + 1)]);
      let mut v345_7 = Space::new();
      let mut v345_7_write = v345_7.write_zipper();
      for v345_7_byte in v343_18_cursor.child_mask().iter() {
        v343_18_cursor.descend_to_existing_byte(v345_7_byte);
        {
        let v346_2: Space = singleton(&v343_18_cursor.path()[(v343_18_origin + 1)..(v343_18_origin + 2)]);
        let v346_3: Space = intersect(&(*CONSTANT_1),&(v346_2));
        drop(v346_2);
        let v346_4: Space = if has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
        drop(v346_3);
        let v346_12: Space = if (&(v346_4)).is_empty() { Space::new() } else {
          let v347_6: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v343_18_cursor.path()[v343_18_origin..(v343_18_origin + 1)]),&v343_18_cursor.path()[(v343_18_origin + 1)..(v343_18_origin + 2)])));
          let mut v347_7 = Space::new();
          let mut v347_7_write = v347_7.write_zipper();
          let mut v347_7_cursor = (v347_6).read_zipper();
          let v347_7_origin = v347_7_cursor.path().len();
          for v347_7_byte in v347_7_cursor.child_mask().iter() {
            v347_7_cursor.descend_to_existing_byte(v347_7_byte);
            {
            let v348_2: Space = singleton(&v347_7_cursor.path()[v347_7_origin..(v347_7_origin + 1)]);
            let v348_3: Space = intersect(&(*CONSTANT_1),&(v348_2));
            let v348_4: Space = if has_head(&(v348_3)) { singleton(&[]) } else { Space::new() };
            drop(v348_3);
            let v348_5: Space = subtract(&(*CONSTANT_0),&(v348_4));
            drop(v348_4);
            let v348_7: Space = if (&(v348_5)).is_empty() { Space::new() } else {
              let v349_6: Space = routine_6(c, &v347_7_cursor.path()[v347_7_origin..(v347_7_origin + 1)], &v347_7_cursor);
              compose(&(v348_5),&(v349_6))
            };
            drop(v348_5);
            let v348_8: Space = intersect(&(*CONSTANT_1),&(v348_2));
            drop(v348_2);
            let v348_9: Space = if has_head(&(v348_8)) { singleton(&[]) } else { Space::new() };
            drop(v348_8);
            let v348_11: Space = if (&(v348_9)).is_empty() { Space::new() } else {
              let v350_10: Space = routine_7(c, &v347_7_cursor.path()[v347_7_origin..(v347_7_origin + 1)], &v347_7_cursor);
              compose(&(v348_9),&(v350_10))
            };
            drop(v348_9);
            let v348_12: Space = unite(&(v348_7),&(v348_11));
            join_wrapped_into(&mut v347_7_write,&((v348_12).read_zipper()),&[]);
            }
            v347_7_cursor.ascend(1);
          }
          drop(v347_7_cursor);
          drop(v347_7_write);
          drop(v347_6);
          let v347_8: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v347_7));
          let mut v347_9 = Space::new();
          let mut v347_9_write = v347_9.write_zipper();
          let mut v347_9_cursor = (v347_8).read_zipper();
          let v347_9_origin = v347_9_cursor.path().len();
          for v347_9_byte in v347_9_cursor.child_mask().iter() {
            v347_9_cursor.descend_to_existing_byte(v347_9_byte);
            {
            let v351_2: Space = singleton(&v347_9_cursor.path()[v347_9_origin..(v347_9_origin + 1)]);
            let v351_3: Space = intersect(&(*CONSTANT_1),&(v351_2));
            let v351_4: Space = if has_head(&(v351_3)) { singleton(&[]) } else { Space::new() };
            drop(v351_3);
            let v351_5: Space = subtract(&(*CONSTANT_0),&(v351_4));
            drop(v351_4);
            let v351_7: Space = if (&(v351_5)).is_empty() { Space::new() } else {
              let v352_6: Space = routine_8(c, &v347_9_cursor.path()[v347_9_origin..(v347_9_origin + 1)], &v347_9_cursor);
              compose(&(v351_5),&(v352_6))
            };
            drop(v351_5);
            let v351_8: Space = intersect(&(*CONSTANT_1),&(v351_2));
            drop(v351_2);
            let v351_9: Space = if has_head(&(v351_8)) { singleton(&[]) } else { Space::new() };
            drop(v351_8);
            let v351_11: Space = if (&(v351_9)).is_empty() { Space::new() } else {
              let v353_10: Space = routine_9(c, &v347_9_cursor.path()[v347_9_origin..(v347_9_origin + 1)], &v347_9_cursor);
              compose(&(v351_9),&(v353_10))
            };
            drop(v351_9);
            let v351_12: Space = unite(&(v351_7),&(v351_11));
            join_wrapped_into(&mut v347_9_write,&((v351_12).read_zipper()),&[]);
            }
            v347_9_cursor.ascend(1);
          }
          drop(v347_9_cursor);
          drop(v347_9_write);
          let v347_10: Space = subtract(&(v347_9),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v343_18_cursor.path()[v343_18_origin..(v343_18_origin + 1)]),&v343_18_cursor.path()[(v343_18_origin + 1)..(v343_18_origin + 2)])));
          let v347_11: Space = intersect(&(v347_10),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
          compose(&(v346_4),&(v347_11))
        };
        drop(v346_4);
        let v346_13: Path = concat_path(&(v345_6),&v343_18_cursor.path()[(v343_18_origin + 1)..(v343_18_origin + 2)]);
        join_wrapped_into(&mut v345_7_write,&((v346_12).read_zipper()),&(v346_13));
        drop(v346_13);
        }
        v343_18_cursor.ascend(1);
      }
      drop(v345_7_write);
      drop(v345_6);
      compose(&(v344_4),&(v345_7))
    };
    drop(v344_4);
    join_wrapped_into(&mut v343_18_write,&((v344_8).read_zipper()),&[]);
    }
    v343_18_cursor.ascend(1);
  }
  drop(v343_18_cursor);
  drop(v343_18_write);
  (v343_18).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v354_29 = Space::new();
  let mut v354_29_write = v354_29.write_zipper();
  let mut v354_29_cursor = (*s0).read_zipper();
  let v354_29_origin = v354_29_cursor.path().len();
  for v354_29_byte in v354_29_cursor.child_mask().iter() {
    v354_29_cursor.descend_to_existing_byte(v354_29_byte);
    {
    let v355_2: Space = singleton(&v354_29_cursor.path()[v354_29_origin..(v354_29_origin + 1)]);
    let v355_3: Space = intersect(&(*CONSTANT_1),&(v355_2));
    drop(v355_2);
    let v355_4: Space = if has_head(&(v355_3)) { singleton(&[]) } else { Space::new() };
    drop(v355_3);
    let v355_12: Space = if (&(v355_4)).is_empty() { Space::new() } else {
      let v356_6: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v354_29_cursor.path()[v354_29_origin..(v354_29_origin + 1)])));
      let mut v356_7 = Space::new();
      let mut v356_7_write = v356_7.write_zipper();
      let mut v356_7_cursor = (v356_6).read_zipper();
      let v356_7_origin = v356_7_cursor.path().len();
      for v356_7_byte in v356_7_cursor.child_mask().iter() {
        v356_7_cursor.descend_to_existing_byte(v356_7_byte);
        {
        let v357_2: Space = singleton(&v356_7_cursor.path()[v356_7_origin..(v356_7_origin + 1)]);
        let v357_3: Space = intersect(&(*CONSTANT_1),&(v357_2));
        let v357_4: Space = if has_head(&(v357_3)) { singleton(&[]) } else { Space::new() };
        drop(v357_3);
        let v357_5: Space = subtract(&(*CONSTANT_0),&(v357_4));
        drop(v357_4);
        let v357_7: Space = if (&(v357_5)).is_empty() { Space::new() } else {
          let mut v358_6 = Space::new();
          let mut v358_6_write = v358_6.write_zipper();
          for v358_6_byte in v356_7_cursor.child_mask().iter() {
            v356_7_cursor.descend_to_existing_byte(v358_6_byte);
            {
            let v359_2: Space = singleton(&v356_7_cursor.path()[(v356_7_origin + 1)..(v356_7_origin + 2)]);
            let v359_3: Space = intersect(&(*CONSTANT_1),&(v359_2));
            let v359_4: Space = if has_head(&(v359_3)) { singleton(&[]) } else { Space::new() };
            drop(v359_3);
            let v359_5: Space = subtract(&(*CONSTANT_0),&(v359_4));
            drop(v359_4);
            let v359_8: Space = if (&(v359_5)).is_empty() { Space::new() } else {
              let v360_7: Space = routine_10(c, &v356_7_cursor.path()[v356_7_origin..(v356_7_origin + 2)], &v356_7_cursor);
              compose(&(v359_5),&(v360_7))
            };
            drop(v359_5);
            let v359_9: Space = intersect(&(*CONSTANT_1),&(v359_2));
            drop(v359_2);
            let v359_10: Space = if has_head(&(v359_9)) { singleton(&[]) } else { Space::new() };
            drop(v359_9);
            let v359_12: Space = if (&(v359_10)).is_empty() { Space::new() } else {
              let v361_11: Space = routine_11(c, &v356_7_cursor.path()[v356_7_origin..(v356_7_origin + 2)], &v356_7_cursor);
              compose(&(v359_10),&(v361_11))
            };
            drop(v359_10);
            let v359_13: Space = unite(&(v359_8),&(v359_12));
            join_wrapped_into(&mut v358_6_write,&((v359_13).read_zipper()),&[]);
            }
            v356_7_cursor.ascend(1);
          }
          drop(v358_6_write);
          compose(&(v357_5),&(v358_6))
        };
        drop(v357_5);
        let v357_8: Space = intersect(&(*CONSTANT_1),&(v357_2));
        drop(v357_2);
        let v357_9: Space = if has_head(&(v357_8)) { singleton(&[]) } else { Space::new() };
        drop(v357_8);
        let v357_11: Space = if (&(v357_9)).is_empty() { Space::new() } else {
          let mut v362_10 = Space::new();
          let mut v362_10_write = v362_10.write_zipper();
          for v362_10_byte in v356_7_cursor.child_mask().iter() {
            v356_7_cursor.descend_to_existing_byte(v362_10_byte);
            {
            let v363_2: Space = singleton(&v356_7_cursor.path()[(v356_7_origin + 1)..(v356_7_origin + 2)]);
            let v363_3: Space = intersect(&(*CONSTANT_1),&(v363_2));
            let v363_4: Space = if has_head(&(v363_3)) { singleton(&[]) } else { Space::new() };
            drop(v363_3);
            let v363_5: Space = subtract(&(*CONSTANT_0),&(v363_4));
            drop(v363_4);
            let v363_8: Space = if (&(v363_5)).is_empty() { Space::new() } else {
              let v364_7: Space = routine_10(c, &v356_7_cursor.path()[v356_7_origin..(v356_7_origin + 2)], &v356_7_cursor);
              compose(&(v363_5),&(v364_7))
            };
            drop(v363_5);
            let v363_9: Space = intersect(&(*CONSTANT_1),&(v363_2));
            drop(v363_2);
            let v363_10: Space = if has_head(&(v363_9)) { singleton(&[]) } else { Space::new() };
            drop(v363_9);
            let v363_12: Space = if (&(v363_10)).is_empty() { Space::new() } else {
              let v365_11: Space = routine_12(c, &v356_7_cursor.path()[v356_7_origin..(v356_7_origin + 2)], &v356_7_cursor);
              compose(&(v363_10),&(v365_11))
            };
            drop(v363_10);
            let v363_13: Space = unite(&(v363_8),&(v363_12));
            join_wrapped_into(&mut v362_10_write,&((v363_13).read_zipper()),&[]);
            }
            v356_7_cursor.ascend(1);
          }
          drop(v362_10_write);
          compose(&(v357_9),&(v362_10))
        };
        drop(v357_9);
        let v357_12: Space = unite(&(v357_7),&(v357_11));
        join_wrapped_into(&mut v356_7_write,&((v357_12).read_zipper()),&[]);
        }
        v356_7_cursor.ascend(1);
      }
      drop(v356_7_cursor);
      drop(v356_7_write);
      drop(v356_6);
      let v356_8: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v356_7));
      let mut v356_9 = Space::new();
      let mut v356_9_write = v356_9.write_zipper();
      let mut v356_9_cursor = (v356_8).read_zipper();
      let v356_9_origin = v356_9_cursor.path().len();
      for v356_9_byte in v356_9_cursor.child_mask().iter() {
        v356_9_cursor.descend_to_existing_byte(v356_9_byte);
        {
        let v366_2: Space = singleton(&v356_9_cursor.path()[v356_9_origin..(v356_9_origin + 1)]);
        let v366_3: Space = intersect(&(*CONSTANT_1),&(v366_2));
        let v366_4: Space = if has_head(&(v366_3)) { singleton(&[]) } else { Space::new() };
        drop(v366_3);
        let v366_5: Space = subtract(&(*CONSTANT_0),&(v366_4));
        drop(v366_4);
        let v366_7: Space = if (&(v366_5)).is_empty() { Space::new() } else {
          let mut v367_6 = Space::new();
          let mut v367_6_write = v367_6.write_zipper();
          for v367_6_byte in v356_9_cursor.child_mask().iter() {
            v356_9_cursor.descend_to_existing_byte(v367_6_byte);
            {
            let v368_2: Space = singleton(&v356_9_cursor.path()[(v356_9_origin + 1)..(v356_9_origin + 2)]);
            let v368_3: Space = intersect(&(*CONSTANT_1),&(v368_2));
            let v368_4: Space = if has_head(&(v368_3)) { singleton(&[]) } else { Space::new() };
            drop(v368_3);
            let v368_5: Space = subtract(&(*CONSTANT_0),&(v368_4));
            drop(v368_4);
            let v368_8: Space = if (&(v368_5)).is_empty() { Space::new() } else {
              let v369_7: Space = routine_13(c, &v356_9_cursor.path()[v356_9_origin..(v356_9_origin + 2)], &v356_9_cursor);
              compose(&(v368_5),&(v369_7))
            };
            drop(v368_5);
            let v368_9: Space = intersect(&(*CONSTANT_1),&(v368_2));
            drop(v368_2);
            let v368_10: Space = if has_head(&(v368_9)) { singleton(&[]) } else { Space::new() };
            drop(v368_9);
            let v368_12: Space = if (&(v368_10)).is_empty() { Space::new() } else {
              let v370_11: Space = routine_14(c, &v356_9_cursor.path()[v356_9_origin..(v356_9_origin + 2)], &v356_9_cursor);
              compose(&(v368_10),&(v370_11))
            };
            drop(v368_10);
            let v368_13: Space = unite(&(v368_8),&(v368_12));
            join_wrapped_into(&mut v367_6_write,&((v368_13).read_zipper()),&[]);
            }
            v356_9_cursor.ascend(1);
          }
          drop(v367_6_write);
          compose(&(v366_5),&(v367_6))
        };
        drop(v366_5);
        let v366_8: Space = intersect(&(*CONSTANT_1),&(v366_2));
        drop(v366_2);
        let v366_9: Space = if has_head(&(v366_8)) { singleton(&[]) } else { Space::new() };
        drop(v366_8);
        let v366_11: Space = if (&(v366_9)).is_empty() { Space::new() } else {
          let mut v371_10 = Space::new();
          let mut v371_10_write = v371_10.write_zipper();
          for v371_10_byte in v356_9_cursor.child_mask().iter() {
            v356_9_cursor.descend_to_existing_byte(v371_10_byte);
            {
            let v372_2: Space = singleton(&v356_9_cursor.path()[(v356_9_origin + 1)..(v356_9_origin + 2)]);
            let v372_3: Space = intersect(&(*CONSTANT_1),&(v372_2));
            let v372_4: Space = if has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
            drop(v372_3);
            let v372_5: Space = subtract(&(*CONSTANT_0),&(v372_4));
            drop(v372_4);
            let v372_8: Space = if (&(v372_5)).is_empty() { Space::new() } else {
              let v373_7: Space = routine_13(c, &v356_9_cursor.path()[v356_9_origin..(v356_9_origin + 2)], &v356_9_cursor);
              compose(&(v372_5),&(v373_7))
            };
            drop(v372_5);
            let v372_9: Space = intersect(&(*CONSTANT_1),&(v372_2));
            drop(v372_2);
            let v372_10: Space = if has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
            drop(v372_9);
            let v372_12: Space = if (&(v372_10)).is_empty() { Space::new() } else {
              let v374_11: Space = routine_15(c, &v356_9_cursor.path()[v356_9_origin..(v356_9_origin + 2)], &v356_9_cursor);
              compose(&(v372_10),&(v374_11))
            };
            drop(v372_10);
            let v372_13: Space = unite(&(v372_8),&(v372_12));
            join_wrapped_into(&mut v371_10_write,&((v372_13).read_zipper()),&[]);
            }
            v356_9_cursor.ascend(1);
          }
          drop(v371_10_write);
          compose(&(v366_9),&(v371_10))
        };
        drop(v366_9);
        let v366_12: Space = unite(&(v366_7),&(v366_11));
        join_wrapped_into(&mut v356_9_write,&((v366_12).read_zipper()),&[]);
        }
        v356_9_cursor.ascend(1);
      }
      drop(v356_9_cursor);
      drop(v356_9_write);
      let v356_10: Space = subtract(&(v356_9),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v354_29_cursor.path()[v354_29_origin..(v354_29_origin + 1)])));
      let v356_11: Space = intersect(&(v356_10),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
      compose(&(v355_4),&(v356_11))
    };
    drop(v355_4);
    let v355_13: Path = concat_path(&(*p0),&v354_29_cursor.path()[v354_29_origin..(v354_29_origin + 1)]);
    join_wrapped_into(&mut v354_29_write,&((v355_12).read_zipper()),&(v355_13));
    drop(v355_13);
    }
    v354_29_cursor.ascend(1);
  }
  drop(v354_29_cursor);
  drop(v354_29_write);
  (v354_29).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v375_20 = Space::new();
  let mut v375_20_write = v375_20.write_zipper();
  let mut v375_20_cursor = (*s0).read_zipper();
  let v375_20_origin = v375_20_cursor.path().len();
  for v375_20_byte in v375_20_cursor.child_mask().iter() {
    v375_20_cursor.descend_to_existing_byte(v375_20_byte);
    {
    let v376_2: Space = singleton(&v375_20_cursor.path()[v375_20_origin..(v375_20_origin + 1)]);
    let v376_3: Space = intersect(&(*CONSTANT_1),&(v376_2));
    let v376_4: Space = if has_head(&(v376_3)) { singleton(&[]) } else { Space::new() };
    drop(v376_3);
    let v376_5: Space = subtract(&(*CONSTANT_0),&(v376_4));
    drop(v376_4);
    let v376_8: Space = if (&(v376_5)).is_empty() { Space::new() } else {
      let v377_6: Path = concat_path(&(*p0),&v375_20_cursor.path()[v375_20_origin..(v375_20_origin + 1)]);
      let mut v377_7 = Space::new();
      let mut v377_7_write = v377_7.write_zipper();
      for v377_7_byte in v375_20_cursor.child_mask().iter() {
        v375_20_cursor.descend_to_existing_byte(v377_7_byte);
        {
        let v378_2: Space = singleton(&v375_20_cursor.path()[(v375_20_origin + 1)..(v375_20_origin + 2)]);
        let v378_3: Space = intersect(&(*CONSTANT_1),&(v378_2));
        let v378_4: Space = if has_head(&(v378_3)) { singleton(&[]) } else { Space::new() };
        drop(v378_3);
        let v378_5: Space = subtract(&(*CONSTANT_0),&(v378_4));
        drop(v378_4);
        let v378_8: Space = if (&(v378_5)).is_empty() { Space::new() } else {
          let v379_6: Path = concat_path(&(v377_6),&v375_20_cursor.path()[(v375_20_origin + 1)..(v375_20_origin + 2)]);
          let mut v379_7 = Space::new();
          let mut v379_7_write = v379_7.write_zipper();
          for v379_7_byte in v375_20_cursor.child_mask().iter() {
            v375_20_cursor.descend_to_existing_byte(v379_7_byte);
            {
            let v380_2: Space = singleton(&v375_20_cursor.path()[(v375_20_origin + 2)..(v375_20_origin + 3)]);
            let v380_3: Space = intersect(&(*CONSTANT_1),&(v380_2));
            let v380_4: Space = if has_head(&(v380_3)) { singleton(&[]) } else { Space::new() };
            drop(v380_3);
            let v380_5: Space = subtract(&(*CONSTANT_0),&(v380_4));
            drop(v380_4);
            let v380_8: Space = if (&(v380_5)).is_empty() { Space::new() } else {
              let v381_6: Path = concat_path(&(v379_6),&v375_20_cursor.path()[(v375_20_origin + 2)..(v375_20_origin + 3)]);
              let v381_7: Space = routine_34(c, &(v381_6), &v375_20_cursor);
              compose(&(v380_5),&(v381_7))
            };
            drop(v380_5);
            let v380_9: Space = intersect(&(*CONSTANT_1),&(v380_2));
            drop(v380_2);
            let v380_10: Space = if has_head(&(v380_9)) { singleton(&[]) } else { Space::new() };
            drop(v380_9);
            let v380_12: Space = if (&(v380_10)).is_empty() { Space::new() } else {
              let v382_6: Path = concat_path(&(v379_6),&v375_20_cursor.path()[(v375_20_origin + 2)..(v375_20_origin + 3)]);
              let v382_11: Space = routine_35(c, &(v382_6), &v375_20_cursor);
              drop(v382_6);
              compose(&(v380_10),&(v382_11))
            };
            drop(v380_10);
            let v380_13: Space = unite(&(v380_8),&(v380_12));
            join_wrapped_into(&mut v379_7_write,&((v380_13).read_zipper()),&[]);
            }
            v375_20_cursor.ascend(1);
          }
          drop(v379_7_write);
          compose(&(v378_5),&(v379_7))
        };
        drop(v378_5);
        let v378_9: Space = intersect(&(*CONSTANT_1),&(v378_2));
        drop(v378_2);
        let v378_10: Space = if has_head(&(v378_9)) { singleton(&[]) } else { Space::new() };
        drop(v378_9);
        let v378_12: Space = if (&(v378_10)).is_empty() { Space::new() } else {
          let v383_6: Path = concat_path(&(v377_6),&v375_20_cursor.path()[(v375_20_origin + 1)..(v375_20_origin + 2)]);
          let mut v383_11 = Space::new();
          let mut v383_11_write = v383_11.write_zipper();
          for v383_11_byte in v375_20_cursor.child_mask().iter() {
            v375_20_cursor.descend_to_existing_byte(v383_11_byte);
            {
            let v384_2: Space = singleton(&v375_20_cursor.path()[(v375_20_origin + 2)..(v375_20_origin + 3)]);
            let v384_3: Space = intersect(&(*CONSTANT_1),&(v384_2));
            let v384_4: Space = if has_head(&(v384_3)) { singleton(&[]) } else { Space::new() };
            drop(v384_3);
            let v384_5: Space = subtract(&(*CONSTANT_0),&(v384_4));
            drop(v384_4);
            let v384_8: Space = if (&(v384_5)).is_empty() { Space::new() } else {
              let v385_6: Path = concat_path(&(v383_6),&v375_20_cursor.path()[(v375_20_origin + 2)..(v375_20_origin + 3)]);
              let v385_7: Space = routine_34(c, &(v385_6), &v375_20_cursor);
              compose(&(v384_5),&(v385_7))
            };
            drop(v384_5);
            let v384_9: Space = intersect(&(*CONSTANT_1),&(v384_2));
            drop(v384_2);
            let v384_10: Space = if has_head(&(v384_9)) { singleton(&[]) } else { Space::new() };
            drop(v384_9);
            let v384_12: Space = if (&(v384_10)).is_empty() { Space::new() } else {
              let v386_6: Path = concat_path(&(v383_6),&v375_20_cursor.path()[(v375_20_origin + 2)..(v375_20_origin + 3)]);
              let v386_11: Space = routine_12(c, &(v386_6), &v375_20_cursor);
              drop(v386_6);
              compose(&(v384_10),&(v386_11))
            };
            drop(v384_10);
            let v384_13: Space = unite(&(v384_8),&(v384_12));
            join_wrapped_into(&mut v383_11_write,&((v384_13).read_zipper()),&[]);
            }
            v375_20_cursor.ascend(1);
          }
          drop(v383_11_write);
          drop(v383_6);
          compose(&(v378_10),&(v383_11))
        };
        drop(v378_10);
        let v378_13: Space = unite(&(v378_8),&(v378_12));
        join_wrapped_into(&mut v377_7_write,&((v378_13).read_zipper()),&[]);
        }
        v375_20_cursor.ascend(1);
      }
      drop(v377_7_write);
      compose(&(v376_5),&(v377_7))
    };
    drop(v376_5);
    let v376_9: Space = intersect(&(*CONSTANT_1),&(v376_2));
    drop(v376_2);
    let v376_10: Space = if has_head(&(v376_9)) { singleton(&[]) } else { Space::new() };
    drop(v376_9);
    let v376_12: Space = if (&(v376_10)).is_empty() { Space::new() } else {
      let v387_6: Path = concat_path(&(*p0),&v375_20_cursor.path()[v375_20_origin..(v375_20_origin + 1)]);
      let mut v387_11 = Space::new();
      let mut v387_11_write = v387_11.write_zipper();
      for v387_11_byte in v375_20_cursor.child_mask().iter() {
        v375_20_cursor.descend_to_existing_byte(v387_11_byte);
        {
        let v388_2: Space = singleton(&v375_20_cursor.path()[(v375_20_origin + 1)..(v375_20_origin + 2)]);
        let v388_3: Space = intersect(&(*CONSTANT_1),&(v388_2));
        let v388_4: Space = if has_head(&(v388_3)) { singleton(&[]) } else { Space::new() };
        drop(v388_3);
        let v388_5: Space = subtract(&(*CONSTANT_0),&(v388_4));
        drop(v388_4);
        let v388_8: Space = if (&(v388_5)).is_empty() { Space::new() } else {
          let v389_6: Path = concat_path(&(v387_6),&v375_20_cursor.path()[(v375_20_origin + 1)..(v375_20_origin + 2)]);
          let mut v389_7 = Space::new();
          let mut v389_7_write = v389_7.write_zipper();
          for v389_7_byte in v375_20_cursor.child_mask().iter() {
            v375_20_cursor.descend_to_existing_byte(v389_7_byte);
            {
            let v390_2: Space = singleton(&v375_20_cursor.path()[(v375_20_origin + 2)..(v375_20_origin + 3)]);
            let v390_3: Space = intersect(&(*CONSTANT_1),&(v390_2));
            let v390_4: Space = if has_head(&(v390_3)) { singleton(&[]) } else { Space::new() };
            drop(v390_3);
            let v390_5: Space = subtract(&(*CONSTANT_0),&(v390_4));
            drop(v390_4);
            let v390_8: Space = if (&(v390_5)).is_empty() { Space::new() } else {
              let v391_6: Path = concat_path(&(v389_6),&v375_20_cursor.path()[(v375_20_origin + 2)..(v375_20_origin + 3)]);
              let v391_7: Space = routine_34(c, &(v391_6), &v375_20_cursor);
              compose(&(v390_5),&(v391_7))
            };
            drop(v390_5);
            let v390_9: Space = intersect(&(*CONSTANT_1),&(v390_2));
            drop(v390_2);
            let v390_10: Space = if has_head(&(v390_9)) { singleton(&[]) } else { Space::new() };
            drop(v390_9);
            let v390_12: Space = if (&(v390_10)).is_empty() { Space::new() } else {
              let v392_6: Path = concat_path(&(v389_6),&v375_20_cursor.path()[(v375_20_origin + 2)..(v375_20_origin + 3)]);
              let v392_11: Space = routine_35(c, &(v392_6), &v375_20_cursor);
              drop(v392_6);
              compose(&(v390_10),&(v392_11))
            };
            drop(v390_10);
            let v390_13: Space = unite(&(v390_8),&(v390_12));
            join_wrapped_into(&mut v389_7_write,&((v390_13).read_zipper()),&[]);
            }
            v375_20_cursor.ascend(1);
          }
          drop(v389_7_write);
          drop(v389_6);
          compose(&(v388_5),&(v389_7))
        };
        drop(v388_5);
        let v388_9: Space = intersect(&(*CONSTANT_1),&(v388_2));
        drop(v388_2);
        let v388_10: Space = if has_head(&(v388_9)) { singleton(&[]) } else { Space::new() };
        drop(v388_9);
        let v388_11: Space = compose(&(v388_10),&v375_20_cursor);
        drop(v388_10);
        let v388_12: Space = unite(&(v388_8),&(v388_11));
        drop(v388_11);
        join_wrapped_into(&mut v387_11_write,&((v388_12).read_zipper()),&[]);
        }
        v375_20_cursor.ascend(1);
      }
      drop(v387_11_write);
      drop(v387_6);
      compose(&(v376_10),&(v387_11))
    };
    drop(v376_10);
    let v376_13: Space = unite(&(v376_8),&(v376_12));
    join_wrapped_into(&mut v375_20_write,&((v376_13).read_zipper()),&[]);
    }
    v375_20_cursor.ascend(1);
  }
  drop(v375_20_cursor);
  drop(v375_20_write);
  (v375_20).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v393_14 = Space::new();
  let mut v393_14_write = v393_14.write_zipper();
  let mut v393_14_cursor = (*s0).read_zipper();
  let v393_14_origin = v393_14_cursor.path().len();
  for v393_14_byte in v393_14_cursor.child_mask().iter() {
    v393_14_cursor.descend_to_existing_byte(v393_14_byte);
    {
    let v394_2: Space = singleton(&v393_14_cursor.path()[v393_14_origin..(v393_14_origin + 1)]);
    let v394_3: Space = intersect(&(*CONSTANT_1),&(v394_2));
    let v394_4: Space = if has_head(&(v394_3)) { singleton(&[]) } else { Space::new() };
    drop(v394_3);
    let v394_5: Space = subtract(&(*CONSTANT_0),&(v394_4));
    drop(v394_4);
    let v394_8: Space = if (&(v394_5)).is_empty() { Space::new() } else {
      let v395_6: Path = concat_path(&(*p0),&v393_14_cursor.path()[v393_14_origin..(v393_14_origin + 1)]);
      let mut v395_7 = Space::new();
      let mut v395_7_write = v395_7.write_zipper();
      for v395_7_byte in v393_14_cursor.child_mask().iter() {
        v393_14_cursor.descend_to_existing_byte(v395_7_byte);
        {
        let v396_2: Space = singleton(&v393_14_cursor.path()[(v393_14_origin + 1)..(v393_14_origin + 2)]);
        let v396_3: Space = intersect(&(*CONSTANT_1),&(v396_2));
        let v396_4: Space = if has_head(&(v396_3)) { singleton(&[]) } else { Space::new() };
        drop(v396_3);
        let v396_5: Space = subtract(&(*CONSTANT_0),&(v396_4));
        drop(v396_4);
        let v396_8: Space = if (&(v396_5)).is_empty() { Space::new() } else {
          let v397_6: Path = concat_path(&(v395_6),&v393_14_cursor.path()[(v393_14_origin + 1)..(v393_14_origin + 2)]);
          let mut v397_7 = Space::new();
          let mut v397_7_write = v397_7.write_zipper();
          for v397_7_byte in v393_14_cursor.child_mask().iter() {
            v393_14_cursor.descend_to_existing_byte(v397_7_byte);
            {
            let v398_2: Space = singleton(&v393_14_cursor.path()[(v393_14_origin + 2)..(v393_14_origin + 3)]);
            let v398_3: Space = intersect(&(*CONSTANT_1),&(v398_2));
            let v398_4: Space = if has_head(&(v398_3)) { singleton(&[]) } else { Space::new() };
            drop(v398_3);
            let v398_5: Space = subtract(&(*CONSTANT_0),&(v398_4));
            drop(v398_4);
            let v398_8: Space = if (&(v398_5)).is_empty() { Space::new() } else {
              let v399_6: Path = concat_path(&(v397_6),&v393_14_cursor.path()[(v393_14_origin + 2)..(v393_14_origin + 3)]);
              let v399_7: Space = routine_34(c, &(v399_6), &v393_14_cursor);
              compose(&(v398_5),&(v399_7))
            };
            drop(v398_5);
            let v398_9: Space = intersect(&(*CONSTANT_1),&(v398_2));
            drop(v398_2);
            let v398_10: Space = if has_head(&(v398_9)) { singleton(&[]) } else { Space::new() };
            drop(v398_9);
            let v398_12: Space = if (&(v398_10)).is_empty() { Space::new() } else {
              let v400_6: Path = concat_path(&(v397_6),&v393_14_cursor.path()[(v393_14_origin + 2)..(v393_14_origin + 3)]);
              let v400_11: Space = routine_35(c, &(v400_6), &v393_14_cursor);
              drop(v400_6);
              compose(&(v398_10),&(v400_11))
            };
            drop(v398_10);
            let v398_13: Space = unite(&(v398_8),&(v398_12));
            join_wrapped_into(&mut v397_7_write,&((v398_13).read_zipper()),&[]);
            }
            v393_14_cursor.ascend(1);
          }
          drop(v397_7_write);
          compose(&(v396_5),&(v397_7))
        };
        drop(v396_5);
        let v396_9: Space = intersect(&(*CONSTANT_1),&(v396_2));
        drop(v396_2);
        let v396_10: Space = if has_head(&(v396_9)) { singleton(&[]) } else { Space::new() };
        drop(v396_9);
        let v396_12: Space = if (&(v396_10)).is_empty() { Space::new() } else {
          let v401_6: Path = concat_path(&(v395_6),&v393_14_cursor.path()[(v393_14_origin + 1)..(v393_14_origin + 2)]);
          let mut v401_11 = Space::new();
          let mut v401_11_write = v401_11.write_zipper();
          for v401_11_byte in v393_14_cursor.child_mask().iter() {
            v393_14_cursor.descend_to_existing_byte(v401_11_byte);
            {
            let v402_2: Space = singleton(&v393_14_cursor.path()[(v393_14_origin + 2)..(v393_14_origin + 3)]);
            let v402_3: Space = intersect(&(*CONSTANT_1),&(v402_2));
            let v402_4: Space = if has_head(&(v402_3)) { singleton(&[]) } else { Space::new() };
            drop(v402_3);
            let v402_5: Space = subtract(&(*CONSTANT_0),&(v402_4));
            drop(v402_4);
            let v402_8: Space = if (&(v402_5)).is_empty() { Space::new() } else {
              let v403_6: Path = concat_path(&(v401_6),&v393_14_cursor.path()[(v393_14_origin + 2)..(v393_14_origin + 3)]);
              let v403_7: Space = routine_34(c, &(v403_6), &v393_14_cursor);
              compose(&(v402_5),&(v403_7))
            };
            drop(v402_5);
            let v402_9: Space = intersect(&(*CONSTANT_1),&(v402_2));
            drop(v402_2);
            let v402_10: Space = if has_head(&(v402_9)) { singleton(&[]) } else { Space::new() };
            drop(v402_9);
            let v402_12: Space = if (&(v402_10)).is_empty() { Space::new() } else {
              let v404_6: Path = concat_path(&(v401_6),&v393_14_cursor.path()[(v393_14_origin + 2)..(v393_14_origin + 3)]);
              let v404_11: Space = routine_12(c, &(v404_6), &v393_14_cursor);
              drop(v404_6);
              compose(&(v402_10),&(v404_11))
            };
            drop(v402_10);
            let v402_13: Space = unite(&(v402_8),&(v402_12));
            join_wrapped_into(&mut v401_11_write,&((v402_13).read_zipper()),&[]);
            }
            v393_14_cursor.ascend(1);
          }
          drop(v401_11_write);
          drop(v401_6);
          compose(&(v396_10),&(v401_11))
        };
        drop(v396_10);
        let v396_13: Space = unite(&(v396_8),&(v396_12));
        join_wrapped_into(&mut v395_7_write,&((v396_13).read_zipper()),&[]);
        }
        v393_14_cursor.ascend(1);
      }
      drop(v395_7_write);
      drop(v395_6);
      compose(&(v394_5),&(v395_7))
    };
    drop(v394_5);
    let v394_9: Space = intersect(&(*CONSTANT_1),&(v394_2));
    drop(v394_2);
    let v394_10: Space = if has_head(&(v394_9)) { singleton(&[]) } else { Space::new() };
    drop(v394_9);
    let v394_11: Space = compose(&(v394_10),&v393_14_cursor);
    drop(v394_10);
    let v394_12: Space = unite(&(v394_8),&(v394_11));
    drop(v394_11);
    join_wrapped_into(&mut v393_14_write,&((v394_12).read_zipper()),&[]);
    }
    v393_14_cursor.ascend(1);
  }
  drop(v393_14_cursor);
  drop(v393_14_write);
  (v393_14).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v405_20 = Space::new();
  let mut v405_20_write = v405_20.write_zipper();
  let mut v405_20_cursor = (*s0).read_zipper();
  let v405_20_origin = v405_20_cursor.path().len();
  for v405_20_byte in v405_20_cursor.child_mask().iter() {
    v405_20_cursor.descend_to_existing_byte(v405_20_byte);
    {
    let v406_2: Space = singleton(&v405_20_cursor.path()[v405_20_origin..(v405_20_origin + 1)]);
    let v406_3: Space = intersect(&(*CONSTANT_1),&(v406_2));
    let v406_4: Space = if has_head(&(v406_3)) { singleton(&[]) } else { Space::new() };
    drop(v406_3);
    let v406_5: Space = subtract(&(*CONSTANT_0),&(v406_4));
    drop(v406_4);
    let v406_8: Space = if (&(v406_5)).is_empty() { Space::new() } else {
      let v407_6: Path = concat_path(&(*p0),&v405_20_cursor.path()[v405_20_origin..(v405_20_origin + 1)]);
      let mut v407_7 = Space::new();
      let mut v407_7_write = v407_7.write_zipper();
      for v407_7_byte in v405_20_cursor.child_mask().iter() {
        v405_20_cursor.descend_to_existing_byte(v407_7_byte);
        {
        let v408_2: Space = singleton(&v405_20_cursor.path()[(v405_20_origin + 1)..(v405_20_origin + 2)]);
        let v408_3: Space = intersect(&(*CONSTANT_1),&(v408_2));
        let v408_4: Space = if has_head(&(v408_3)) { singleton(&[]) } else { Space::new() };
        drop(v408_3);
        let v408_5: Space = subtract(&(*CONSTANT_0),&(v408_4));
        drop(v408_4);
        let v408_8: Space = if (&(v408_5)).is_empty() { Space::new() } else {
          let v409_6: Path = concat_path(&(v407_6),&v405_20_cursor.path()[(v405_20_origin + 1)..(v405_20_origin + 2)]);
          let mut v409_7 = Space::new();
          let mut v409_7_write = v409_7.write_zipper();
          for v409_7_byte in v405_20_cursor.child_mask().iter() {
            v405_20_cursor.descend_to_existing_byte(v409_7_byte);
            {
            let v410_2: Space = singleton(&v405_20_cursor.path()[(v405_20_origin + 2)..(v405_20_origin + 3)]);
            let v410_3: Space = intersect(&(*CONSTANT_1),&(v410_2));
            let v410_4: Space = if has_head(&(v410_3)) { singleton(&[]) } else { Space::new() };
            drop(v410_3);
            let v410_5: Space = subtract(&(*CONSTANT_0),&(v410_4));
            drop(v410_4);
            let v410_8: Space = if (&(v410_5)).is_empty() { Space::new() } else {
              let v411_6: Path = concat_path(&(v409_6),&v405_20_cursor.path()[(v405_20_origin + 2)..(v405_20_origin + 3)]);
              let v411_7: Space = routine_36(c, &(v411_6), &v405_20_cursor);
              compose(&(v410_5),&(v411_7))
            };
            drop(v410_5);
            let v410_9: Space = intersect(&(*CONSTANT_1),&(v410_2));
            drop(v410_2);
            let v410_10: Space = if has_head(&(v410_9)) { singleton(&[]) } else { Space::new() };
            drop(v410_9);
            let v410_12: Space = if (&(v410_10)).is_empty() { Space::new() } else {
              let v412_6: Path = concat_path(&(v409_6),&v405_20_cursor.path()[(v405_20_origin + 2)..(v405_20_origin + 3)]);
              let v412_11: Space = routine_37(c, &(v412_6), &v405_20_cursor);
              drop(v412_6);
              compose(&(v410_10),&(v412_11))
            };
            drop(v410_10);
            let v410_13: Space = unite(&(v410_8),&(v410_12));
            join_wrapped_into(&mut v409_7_write,&((v410_13).read_zipper()),&[]);
            }
            v405_20_cursor.ascend(1);
          }
          drop(v409_7_write);
          compose(&(v408_5),&(v409_7))
        };
        drop(v408_5);
        let v408_9: Space = intersect(&(*CONSTANT_1),&(v408_2));
        drop(v408_2);
        let v408_10: Space = if has_head(&(v408_9)) { singleton(&[]) } else { Space::new() };
        drop(v408_9);
        let v408_12: Space = if (&(v408_10)).is_empty() { Space::new() } else {
          let v413_6: Path = concat_path(&(v407_6),&v405_20_cursor.path()[(v405_20_origin + 1)..(v405_20_origin + 2)]);
          let mut v413_11 = Space::new();
          let mut v413_11_write = v413_11.write_zipper();
          for v413_11_byte in v405_20_cursor.child_mask().iter() {
            v405_20_cursor.descend_to_existing_byte(v413_11_byte);
            {
            let v414_2: Space = singleton(&v405_20_cursor.path()[(v405_20_origin + 2)..(v405_20_origin + 3)]);
            let v414_3: Space = intersect(&(*CONSTANT_1),&(v414_2));
            let v414_4: Space = if has_head(&(v414_3)) { singleton(&[]) } else { Space::new() };
            drop(v414_3);
            let v414_5: Space = subtract(&(*CONSTANT_0),&(v414_4));
            drop(v414_4);
            let v414_8: Space = if (&(v414_5)).is_empty() { Space::new() } else {
              let v415_6: Path = concat_path(&(v413_6),&v405_20_cursor.path()[(v405_20_origin + 2)..(v405_20_origin + 3)]);
              let v415_7: Space = routine_36(c, &(v415_6), &v405_20_cursor);
              compose(&(v414_5),&(v415_7))
            };
            drop(v414_5);
            let v414_9: Space = intersect(&(*CONSTANT_1),&(v414_2));
            drop(v414_2);
            let v414_10: Space = if has_head(&(v414_9)) { singleton(&[]) } else { Space::new() };
            drop(v414_9);
            let v414_12: Space = if (&(v414_10)).is_empty() { Space::new() } else {
              let v416_6: Path = concat_path(&(v413_6),&v405_20_cursor.path()[(v405_20_origin + 2)..(v405_20_origin + 3)]);
              let v416_11: Space = routine_15(c, &(v416_6), &v405_20_cursor);
              drop(v416_6);
              compose(&(v414_10),&(v416_11))
            };
            drop(v414_10);
            let v414_13: Space = unite(&(v414_8),&(v414_12));
            join_wrapped_into(&mut v413_11_write,&((v414_13).read_zipper()),&[]);
            }
            v405_20_cursor.ascend(1);
          }
          drop(v413_11_write);
          drop(v413_6);
          compose(&(v408_10),&(v413_11))
        };
        drop(v408_10);
        let v408_13: Space = unite(&(v408_8),&(v408_12));
        join_wrapped_into(&mut v407_7_write,&((v408_13).read_zipper()),&[]);
        }
        v405_20_cursor.ascend(1);
      }
      drop(v407_7_write);
      compose(&(v406_5),&(v407_7))
    };
    drop(v406_5);
    let v406_9: Space = intersect(&(*CONSTANT_1),&(v406_2));
    drop(v406_2);
    let v406_10: Space = if has_head(&(v406_9)) { singleton(&[]) } else { Space::new() };
    drop(v406_9);
    let v406_12: Space = if (&(v406_10)).is_empty() { Space::new() } else {
      let v417_6: Path = concat_path(&(*p0),&v405_20_cursor.path()[v405_20_origin..(v405_20_origin + 1)]);
      let mut v417_11 = Space::new();
      let mut v417_11_write = v417_11.write_zipper();
      for v417_11_byte in v405_20_cursor.child_mask().iter() {
        v405_20_cursor.descend_to_existing_byte(v417_11_byte);
        {
        let v418_2: Space = singleton(&v405_20_cursor.path()[(v405_20_origin + 1)..(v405_20_origin + 2)]);
        let v418_3: Space = intersect(&(*CONSTANT_1),&(v418_2));
        let v418_4: Space = if has_head(&(v418_3)) { singleton(&[]) } else { Space::new() };
        drop(v418_3);
        let v418_5: Space = subtract(&(*CONSTANT_0),&(v418_4));
        drop(v418_4);
        let v418_8: Space = if (&(v418_5)).is_empty() { Space::new() } else {
          let v419_6: Path = concat_path(&(v417_6),&v405_20_cursor.path()[(v405_20_origin + 1)..(v405_20_origin + 2)]);
          let mut v419_7 = Space::new();
          let mut v419_7_write = v419_7.write_zipper();
          for v419_7_byte in v405_20_cursor.child_mask().iter() {
            v405_20_cursor.descend_to_existing_byte(v419_7_byte);
            {
            let v420_2: Space = singleton(&v405_20_cursor.path()[(v405_20_origin + 2)..(v405_20_origin + 3)]);
            let v420_3: Space = intersect(&(*CONSTANT_1),&(v420_2));
            let v420_4: Space = if has_head(&(v420_3)) { singleton(&[]) } else { Space::new() };
            drop(v420_3);
            let v420_5: Space = subtract(&(*CONSTANT_0),&(v420_4));
            drop(v420_4);
            let v420_8: Space = if (&(v420_5)).is_empty() { Space::new() } else {
              let v421_6: Path = concat_path(&(v419_6),&v405_20_cursor.path()[(v405_20_origin + 2)..(v405_20_origin + 3)]);
              let v421_7: Space = routine_36(c, &(v421_6), &v405_20_cursor);
              compose(&(v420_5),&(v421_7))
            };
            drop(v420_5);
            let v420_9: Space = intersect(&(*CONSTANT_1),&(v420_2));
            drop(v420_2);
            let v420_10: Space = if has_head(&(v420_9)) { singleton(&[]) } else { Space::new() };
            drop(v420_9);
            let v420_12: Space = if (&(v420_10)).is_empty() { Space::new() } else {
              let v422_6: Path = concat_path(&(v419_6),&v405_20_cursor.path()[(v405_20_origin + 2)..(v405_20_origin + 3)]);
              let v422_11: Space = routine_37(c, &(v422_6), &v405_20_cursor);
              drop(v422_6);
              compose(&(v420_10),&(v422_11))
            };
            drop(v420_10);
            let v420_13: Space = unite(&(v420_8),&(v420_12));
            join_wrapped_into(&mut v419_7_write,&((v420_13).read_zipper()),&[]);
            }
            v405_20_cursor.ascend(1);
          }
          drop(v419_7_write);
          drop(v419_6);
          compose(&(v418_5),&(v419_7))
        };
        drop(v418_5);
        let v418_9: Space = intersect(&(*CONSTANT_1),&(v418_2));
        drop(v418_2);
        let v418_10: Space = if has_head(&(v418_9)) { singleton(&[]) } else { Space::new() };
        drop(v418_9);
        let v418_11: Space = compose(&(v418_10),&v405_20_cursor);
        drop(v418_10);
        let v418_12: Space = unite(&(v418_8),&(v418_11));
        drop(v418_11);
        join_wrapped_into(&mut v417_11_write,&((v418_12).read_zipper()),&[]);
        }
        v405_20_cursor.ascend(1);
      }
      drop(v417_11_write);
      drop(v417_6);
      compose(&(v406_10),&(v417_11))
    };
    drop(v406_10);
    let v406_13: Space = unite(&(v406_8),&(v406_12));
    join_wrapped_into(&mut v405_20_write,&((v406_13).read_zipper()),&[]);
    }
    v405_20_cursor.ascend(1);
  }
  drop(v405_20_cursor);
  drop(v405_20_write);
  (v405_20).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v423_14 = Space::new();
  let mut v423_14_write = v423_14.write_zipper();
  let mut v423_14_cursor = (*s0).read_zipper();
  let v423_14_origin = v423_14_cursor.path().len();
  for v423_14_byte in v423_14_cursor.child_mask().iter() {
    v423_14_cursor.descend_to_existing_byte(v423_14_byte);
    {
    let v424_2: Space = singleton(&v423_14_cursor.path()[v423_14_origin..(v423_14_origin + 1)]);
    let v424_3: Space = intersect(&(*CONSTANT_1),&(v424_2));
    let v424_4: Space = if has_head(&(v424_3)) { singleton(&[]) } else { Space::new() };
    drop(v424_3);
    let v424_5: Space = subtract(&(*CONSTANT_0),&(v424_4));
    drop(v424_4);
    let v424_8: Space = if (&(v424_5)).is_empty() { Space::new() } else {
      let v425_6: Path = concat_path(&(*p0),&v423_14_cursor.path()[v423_14_origin..(v423_14_origin + 1)]);
      let mut v425_7 = Space::new();
      let mut v425_7_write = v425_7.write_zipper();
      for v425_7_byte in v423_14_cursor.child_mask().iter() {
        v423_14_cursor.descend_to_existing_byte(v425_7_byte);
        {
        let v426_2: Space = singleton(&v423_14_cursor.path()[(v423_14_origin + 1)..(v423_14_origin + 2)]);
        let v426_3: Space = intersect(&(*CONSTANT_1),&(v426_2));
        let v426_4: Space = if has_head(&(v426_3)) { singleton(&[]) } else { Space::new() };
        drop(v426_3);
        let v426_5: Space = subtract(&(*CONSTANT_0),&(v426_4));
        drop(v426_4);
        let v426_8: Space = if (&(v426_5)).is_empty() { Space::new() } else {
          let v427_6: Path = concat_path(&(v425_6),&v423_14_cursor.path()[(v423_14_origin + 1)..(v423_14_origin + 2)]);
          let mut v427_7 = Space::new();
          let mut v427_7_write = v427_7.write_zipper();
          for v427_7_byte in v423_14_cursor.child_mask().iter() {
            v423_14_cursor.descend_to_existing_byte(v427_7_byte);
            {
            let v428_2: Space = singleton(&v423_14_cursor.path()[(v423_14_origin + 2)..(v423_14_origin + 3)]);
            let v428_3: Space = intersect(&(*CONSTANT_1),&(v428_2));
            let v428_4: Space = if has_head(&(v428_3)) { singleton(&[]) } else { Space::new() };
            drop(v428_3);
            let v428_5: Space = subtract(&(*CONSTANT_0),&(v428_4));
            drop(v428_4);
            let v428_8: Space = if (&(v428_5)).is_empty() { Space::new() } else {
              let v429_6: Path = concat_path(&(v427_6),&v423_14_cursor.path()[(v423_14_origin + 2)..(v423_14_origin + 3)]);
              let v429_7: Space = routine_36(c, &(v429_6), &v423_14_cursor);
              compose(&(v428_5),&(v429_7))
            };
            drop(v428_5);
            let v428_9: Space = intersect(&(*CONSTANT_1),&(v428_2));
            drop(v428_2);
            let v428_10: Space = if has_head(&(v428_9)) { singleton(&[]) } else { Space::new() };
            drop(v428_9);
            let v428_12: Space = if (&(v428_10)).is_empty() { Space::new() } else {
              let v430_6: Path = concat_path(&(v427_6),&v423_14_cursor.path()[(v423_14_origin + 2)..(v423_14_origin + 3)]);
              let v430_11: Space = routine_37(c, &(v430_6), &v423_14_cursor);
              drop(v430_6);
              compose(&(v428_10),&(v430_11))
            };
            drop(v428_10);
            let v428_13: Space = unite(&(v428_8),&(v428_12));
            join_wrapped_into(&mut v427_7_write,&((v428_13).read_zipper()),&[]);
            }
            v423_14_cursor.ascend(1);
          }
          drop(v427_7_write);
          compose(&(v426_5),&(v427_7))
        };
        drop(v426_5);
        let v426_9: Space = intersect(&(*CONSTANT_1),&(v426_2));
        drop(v426_2);
        let v426_10: Space = if has_head(&(v426_9)) { singleton(&[]) } else { Space::new() };
        drop(v426_9);
        let v426_12: Space = if (&(v426_10)).is_empty() { Space::new() } else {
          let v431_6: Path = concat_path(&(v425_6),&v423_14_cursor.path()[(v423_14_origin + 1)..(v423_14_origin + 2)]);
          let mut v431_11 = Space::new();
          let mut v431_11_write = v431_11.write_zipper();
          for v431_11_byte in v423_14_cursor.child_mask().iter() {
            v423_14_cursor.descend_to_existing_byte(v431_11_byte);
            {
            let v432_2: Space = singleton(&v423_14_cursor.path()[(v423_14_origin + 2)..(v423_14_origin + 3)]);
            let v432_3: Space = intersect(&(*CONSTANT_1),&(v432_2));
            let v432_4: Space = if has_head(&(v432_3)) { singleton(&[]) } else { Space::new() };
            drop(v432_3);
            let v432_5: Space = subtract(&(*CONSTANT_0),&(v432_4));
            drop(v432_4);
            let v432_8: Space = if (&(v432_5)).is_empty() { Space::new() } else {
              let v433_6: Path = concat_path(&(v431_6),&v423_14_cursor.path()[(v423_14_origin + 2)..(v423_14_origin + 3)]);
              let v433_7: Space = routine_36(c, &(v433_6), &v423_14_cursor);
              compose(&(v432_5),&(v433_7))
            };
            drop(v432_5);
            let v432_9: Space = intersect(&(*CONSTANT_1),&(v432_2));
            drop(v432_2);
            let v432_10: Space = if has_head(&(v432_9)) { singleton(&[]) } else { Space::new() };
            drop(v432_9);
            let v432_12: Space = if (&(v432_10)).is_empty() { Space::new() } else {
              let v434_6: Path = concat_path(&(v431_6),&v423_14_cursor.path()[(v423_14_origin + 2)..(v423_14_origin + 3)]);
              let v434_11: Space = routine_15(c, &(v434_6), &v423_14_cursor);
              drop(v434_6);
              compose(&(v432_10),&(v434_11))
            };
            drop(v432_10);
            let v432_13: Space = unite(&(v432_8),&(v432_12));
            join_wrapped_into(&mut v431_11_write,&((v432_13).read_zipper()),&[]);
            }
            v423_14_cursor.ascend(1);
          }
          drop(v431_11_write);
          drop(v431_6);
          compose(&(v426_10),&(v431_11))
        };
        drop(v426_10);
        let v426_13: Space = unite(&(v426_8),&(v426_12));
        join_wrapped_into(&mut v425_7_write,&((v426_13).read_zipper()),&[]);
        }
        v423_14_cursor.ascend(1);
      }
      drop(v425_7_write);
      drop(v425_6);
      compose(&(v424_5),&(v425_7))
    };
    drop(v424_5);
    let v424_9: Space = intersect(&(*CONSTANT_1),&(v424_2));
    drop(v424_2);
    let v424_10: Space = if has_head(&(v424_9)) { singleton(&[]) } else { Space::new() };
    drop(v424_9);
    let v424_11: Space = compose(&(v424_10),&v423_14_cursor);
    drop(v424_10);
    let v424_12: Space = unite(&(v424_8),&(v424_11));
    drop(v424_11);
    join_wrapped_into(&mut v423_14_write,&((v424_12).read_zipper()),&[]);
    }
    v423_14_cursor.ascend(1);
  }
  drop(v423_14_cursor);
  drop(v423_14_write);
  (v423_14).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v435_20 = Space::new();
  let mut v435_20_write = v435_20.write_zipper();
  let mut v435_20_cursor = (*s0).read_zipper();
  let v435_20_origin = v435_20_cursor.path().len();
  for v435_20_byte in v435_20_cursor.child_mask().iter() {
    v435_20_cursor.descend_to_existing_byte(v435_20_byte);
    {
    let v436_2: Space = singleton(&v435_20_cursor.path()[v435_20_origin..(v435_20_origin + 1)]);
    let v436_3: Space = intersect(&(*CONSTANT_1),&(v436_2));
    let v436_4: Space = if has_head(&(v436_3)) { singleton(&[]) } else { Space::new() };
    drop(v436_3);
    let v436_5: Space = subtract(&(*CONSTANT_0),&(v436_4));
    drop(v436_4);
    let v436_8: Space = if (&(v436_5)).is_empty() { Space::new() } else {
      let v437_6: Path = concat_path(&(*p0),&v435_20_cursor.path()[v435_20_origin..(v435_20_origin + 1)]);
      let mut v437_7 = Space::new();
      let mut v437_7_write = v437_7.write_zipper();
      for v437_7_byte in v435_20_cursor.child_mask().iter() {
        v435_20_cursor.descend_to_existing_byte(v437_7_byte);
        {
        let v438_2: Space = singleton(&v435_20_cursor.path()[(v435_20_origin + 1)..(v435_20_origin + 2)]);
        let v438_3: Space = intersect(&(*CONSTANT_1),&(v438_2));
        let v438_4: Space = if has_head(&(v438_3)) { singleton(&[]) } else { Space::new() };
        drop(v438_3);
        let v438_5: Space = subtract(&(*CONSTANT_0),&(v438_4));
        drop(v438_4);
        let v438_8: Space = if (&(v438_5)).is_empty() { Space::new() } else {
          let v439_6: Path = concat_path(&(v437_6),&v435_20_cursor.path()[(v435_20_origin + 1)..(v435_20_origin + 2)]);
          let mut v439_7 = Space::new();
          let mut v439_7_write = v439_7.write_zipper();
          for v439_7_byte in v435_20_cursor.child_mask().iter() {
            v435_20_cursor.descend_to_existing_byte(v439_7_byte);
            {
            let v440_2: Space = singleton(&v435_20_cursor.path()[(v435_20_origin + 2)..(v435_20_origin + 3)]);
            let v440_3: Space = intersect(&(*CONSTANT_1),&(v440_2));
            let v440_4: Space = if has_head(&(v440_3)) { singleton(&[]) } else { Space::new() };
            drop(v440_3);
            let v440_5: Space = subtract(&(*CONSTANT_0),&(v440_4));
            drop(v440_4);
            let v440_8: Space = if (&(v440_5)).is_empty() { Space::new() } else {
              let v441_6: Path = concat_path(&(v439_6),&v435_20_cursor.path()[(v435_20_origin + 2)..(v435_20_origin + 3)]);
              let v441_7: Space = routine_38(c, &(v441_6), &v435_20_cursor);
              compose(&(v440_5),&(v441_7))
            };
            drop(v440_5);
            let v440_9: Space = intersect(&(*CONSTANT_1),&(v440_2));
            drop(v440_2);
            let v440_10: Space = if has_head(&(v440_9)) { singleton(&[]) } else { Space::new() };
            drop(v440_9);
            let v440_12: Space = if (&(v440_10)).is_empty() { Space::new() } else {
              let v442_6: Path = concat_path(&(v439_6),&v435_20_cursor.path()[(v435_20_origin + 2)..(v435_20_origin + 3)]);
              let v442_11: Space = routine_39(c, &(v442_6), &v435_20_cursor);
              drop(v442_6);
              compose(&(v440_10),&(v442_11))
            };
            drop(v440_10);
            let v440_13: Space = unite(&(v440_8),&(v440_12));
            join_wrapped_into(&mut v439_7_write,&((v440_13).read_zipper()),&[]);
            }
            v435_20_cursor.ascend(1);
          }
          drop(v439_7_write);
          compose(&(v438_5),&(v439_7))
        };
        drop(v438_5);
        let v438_9: Space = intersect(&(*CONSTANT_1),&(v438_2));
        drop(v438_2);
        let v438_10: Space = if has_head(&(v438_9)) { singleton(&[]) } else { Space::new() };
        drop(v438_9);
        let v438_12: Space = if (&(v438_10)).is_empty() { Space::new() } else {
          let v443_6: Path = concat_path(&(v437_6),&v435_20_cursor.path()[(v435_20_origin + 1)..(v435_20_origin + 2)]);
          let mut v443_11 = Space::new();
          let mut v443_11_write = v443_11.write_zipper();
          for v443_11_byte in v435_20_cursor.child_mask().iter() {
            v435_20_cursor.descend_to_existing_byte(v443_11_byte);
            {
            let v444_2: Space = singleton(&v435_20_cursor.path()[(v435_20_origin + 2)..(v435_20_origin + 3)]);
            let v444_3: Space = intersect(&(*CONSTANT_1),&(v444_2));
            let v444_4: Space = if has_head(&(v444_3)) { singleton(&[]) } else { Space::new() };
            drop(v444_3);
            let v444_5: Space = subtract(&(*CONSTANT_0),&(v444_4));
            drop(v444_4);
            let v444_8: Space = if (&(v444_5)).is_empty() { Space::new() } else {
              let v445_6: Path = concat_path(&(v443_6),&v435_20_cursor.path()[(v435_20_origin + 2)..(v435_20_origin + 3)]);
              let v445_7: Space = routine_38(c, &(v445_6), &v435_20_cursor);
              compose(&(v444_5),&(v445_7))
            };
            drop(v444_5);
            let v444_9: Space = intersect(&(*CONSTANT_1),&(v444_2));
            drop(v444_2);
            let v444_10: Space = if has_head(&(v444_9)) { singleton(&[]) } else { Space::new() };
            drop(v444_9);
            let v444_12: Space = if (&(v444_10)).is_empty() { Space::new() } else {
              let v446_6: Path = concat_path(&(v443_6),&v435_20_cursor.path()[(v435_20_origin + 2)..(v435_20_origin + 3)]);
              let v446_11: Space = routine_12(c, &(v446_6), &v435_20_cursor);
              drop(v446_6);
              compose(&(v444_10),&(v446_11))
            };
            drop(v444_10);
            let v444_13: Space = unite(&(v444_8),&(v444_12));
            join_wrapped_into(&mut v443_11_write,&((v444_13).read_zipper()),&[]);
            }
            v435_20_cursor.ascend(1);
          }
          drop(v443_11_write);
          drop(v443_6);
          compose(&(v438_10),&(v443_11))
        };
        drop(v438_10);
        let v438_13: Space = unite(&(v438_8),&(v438_12));
        join_wrapped_into(&mut v437_7_write,&((v438_13).read_zipper()),&[]);
        }
        v435_20_cursor.ascend(1);
      }
      drop(v437_7_write);
      compose(&(v436_5),&(v437_7))
    };
    drop(v436_5);
    let v436_9: Space = intersect(&(*CONSTANT_1),&(v436_2));
    drop(v436_2);
    let v436_10: Space = if has_head(&(v436_9)) { singleton(&[]) } else { Space::new() };
    drop(v436_9);
    let v436_12: Space = if (&(v436_10)).is_empty() { Space::new() } else {
      let v447_6: Path = concat_path(&(*p0),&v435_20_cursor.path()[v435_20_origin..(v435_20_origin + 1)]);
      let mut v447_11 = Space::new();
      let mut v447_11_write = v447_11.write_zipper();
      for v447_11_byte in v435_20_cursor.child_mask().iter() {
        v435_20_cursor.descend_to_existing_byte(v447_11_byte);
        {
        let v448_2: Space = singleton(&v435_20_cursor.path()[(v435_20_origin + 1)..(v435_20_origin + 2)]);
        let v448_3: Space = intersect(&(*CONSTANT_1),&(v448_2));
        let v448_4: Space = if has_head(&(v448_3)) { singleton(&[]) } else { Space::new() };
        drop(v448_3);
        let v448_5: Space = subtract(&(*CONSTANT_0),&(v448_4));
        drop(v448_4);
        let v448_8: Space = if (&(v448_5)).is_empty() { Space::new() } else {
          let v449_6: Path = concat_path(&(v447_6),&v435_20_cursor.path()[(v435_20_origin + 1)..(v435_20_origin + 2)]);
          let mut v449_7 = Space::new();
          let mut v449_7_write = v449_7.write_zipper();
          for v449_7_byte in v435_20_cursor.child_mask().iter() {
            v435_20_cursor.descend_to_existing_byte(v449_7_byte);
            {
            let v450_2: Space = singleton(&v435_20_cursor.path()[(v435_20_origin + 2)..(v435_20_origin + 3)]);
            let v450_3: Space = intersect(&(*CONSTANT_1),&(v450_2));
            let v450_4: Space = if has_head(&(v450_3)) { singleton(&[]) } else { Space::new() };
            drop(v450_3);
            let v450_5: Space = subtract(&(*CONSTANT_0),&(v450_4));
            drop(v450_4);
            let v450_8: Space = if (&(v450_5)).is_empty() { Space::new() } else {
              let v451_6: Path = concat_path(&(v449_6),&v435_20_cursor.path()[(v435_20_origin + 2)..(v435_20_origin + 3)]);
              let v451_7: Space = routine_38(c, &(v451_6), &v435_20_cursor);
              compose(&(v450_5),&(v451_7))
            };
            drop(v450_5);
            let v450_9: Space = intersect(&(*CONSTANT_1),&(v450_2));
            drop(v450_2);
            let v450_10: Space = if has_head(&(v450_9)) { singleton(&[]) } else { Space::new() };
            drop(v450_9);
            let v450_12: Space = if (&(v450_10)).is_empty() { Space::new() } else {
              let v452_6: Path = concat_path(&(v449_6),&v435_20_cursor.path()[(v435_20_origin + 2)..(v435_20_origin + 3)]);
              let v452_11: Space = routine_39(c, &(v452_6), &v435_20_cursor);
              drop(v452_6);
              compose(&(v450_10),&(v452_11))
            };
            drop(v450_10);
            let v450_13: Space = unite(&(v450_8),&(v450_12));
            join_wrapped_into(&mut v449_7_write,&((v450_13).read_zipper()),&[]);
            }
            v435_20_cursor.ascend(1);
          }
          drop(v449_7_write);
          drop(v449_6);
          compose(&(v448_5),&(v449_7))
        };
        drop(v448_5);
        let v448_9: Space = intersect(&(*CONSTANT_1),&(v448_2));
        drop(v448_2);
        let v448_10: Space = if has_head(&(v448_9)) { singleton(&[]) } else { Space::new() };
        drop(v448_9);
        let v448_11: Space = compose(&(v448_10),&v435_20_cursor);
        drop(v448_10);
        let v448_12: Space = unite(&(v448_8),&(v448_11));
        drop(v448_11);
        join_wrapped_into(&mut v447_11_write,&((v448_12).read_zipper()),&[]);
        }
        v435_20_cursor.ascend(1);
      }
      drop(v447_11_write);
      drop(v447_6);
      compose(&(v436_10),&(v447_11))
    };
    drop(v436_10);
    let v436_13: Space = unite(&(v436_8),&(v436_12));
    join_wrapped_into(&mut v435_20_write,&((v436_13).read_zipper()),&[]);
    }
    v435_20_cursor.ascend(1);
  }
  drop(v435_20_cursor);
  drop(v435_20_write);
  (v435_20).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v453_14 = Space::new();
  let mut v453_14_write = v453_14.write_zipper();
  let mut v453_14_cursor = (*s0).read_zipper();
  let v453_14_origin = v453_14_cursor.path().len();
  for v453_14_byte in v453_14_cursor.child_mask().iter() {
    v453_14_cursor.descend_to_existing_byte(v453_14_byte);
    {
    let v454_2: Space = singleton(&v453_14_cursor.path()[v453_14_origin..(v453_14_origin + 1)]);
    let v454_3: Space = intersect(&(*CONSTANT_1),&(v454_2));
    let v454_4: Space = if has_head(&(v454_3)) { singleton(&[]) } else { Space::new() };
    drop(v454_3);
    let v454_5: Space = subtract(&(*CONSTANT_0),&(v454_4));
    drop(v454_4);
    let v454_8: Space = if (&(v454_5)).is_empty() { Space::new() } else {
      let v455_6: Path = concat_path(&(*p0),&v453_14_cursor.path()[v453_14_origin..(v453_14_origin + 1)]);
      let mut v455_7 = Space::new();
      let mut v455_7_write = v455_7.write_zipper();
      for v455_7_byte in v453_14_cursor.child_mask().iter() {
        v453_14_cursor.descend_to_existing_byte(v455_7_byte);
        {
        let v456_2: Space = singleton(&v453_14_cursor.path()[(v453_14_origin + 1)..(v453_14_origin + 2)]);
        let v456_3: Space = intersect(&(*CONSTANT_1),&(v456_2));
        let v456_4: Space = if has_head(&(v456_3)) { singleton(&[]) } else { Space::new() };
        drop(v456_3);
        let v456_5: Space = subtract(&(*CONSTANT_0),&(v456_4));
        drop(v456_4);
        let v456_8: Space = if (&(v456_5)).is_empty() { Space::new() } else {
          let v457_6: Path = concat_path(&(v455_6),&v453_14_cursor.path()[(v453_14_origin + 1)..(v453_14_origin + 2)]);
          let mut v457_7 = Space::new();
          let mut v457_7_write = v457_7.write_zipper();
          for v457_7_byte in v453_14_cursor.child_mask().iter() {
            v453_14_cursor.descend_to_existing_byte(v457_7_byte);
            {
            let v458_2: Space = singleton(&v453_14_cursor.path()[(v453_14_origin + 2)..(v453_14_origin + 3)]);
            let v458_3: Space = intersect(&(*CONSTANT_1),&(v458_2));
            let v458_4: Space = if has_head(&(v458_3)) { singleton(&[]) } else { Space::new() };
            drop(v458_3);
            let v458_5: Space = subtract(&(*CONSTANT_0),&(v458_4));
            drop(v458_4);
            let v458_8: Space = if (&(v458_5)).is_empty() { Space::new() } else {
              let v459_6: Path = concat_path(&(v457_6),&v453_14_cursor.path()[(v453_14_origin + 2)..(v453_14_origin + 3)]);
              let v459_7: Space = routine_38(c, &(v459_6), &v453_14_cursor);
              compose(&(v458_5),&(v459_7))
            };
            drop(v458_5);
            let v458_9: Space = intersect(&(*CONSTANT_1),&(v458_2));
            drop(v458_2);
            let v458_10: Space = if has_head(&(v458_9)) { singleton(&[]) } else { Space::new() };
            drop(v458_9);
            let v458_12: Space = if (&(v458_10)).is_empty() { Space::new() } else {
              let v460_6: Path = concat_path(&(v457_6),&v453_14_cursor.path()[(v453_14_origin + 2)..(v453_14_origin + 3)]);
              let v460_11: Space = routine_39(c, &(v460_6), &v453_14_cursor);
              drop(v460_6);
              compose(&(v458_10),&(v460_11))
            };
            drop(v458_10);
            let v458_13: Space = unite(&(v458_8),&(v458_12));
            join_wrapped_into(&mut v457_7_write,&((v458_13).read_zipper()),&[]);
            }
            v453_14_cursor.ascend(1);
          }
          drop(v457_7_write);
          compose(&(v456_5),&(v457_7))
        };
        drop(v456_5);
        let v456_9: Space = intersect(&(*CONSTANT_1),&(v456_2));
        drop(v456_2);
        let v456_10: Space = if has_head(&(v456_9)) { singleton(&[]) } else { Space::new() };
        drop(v456_9);
        let v456_12: Space = if (&(v456_10)).is_empty() { Space::new() } else {
          let v461_6: Path = concat_path(&(v455_6),&v453_14_cursor.path()[(v453_14_origin + 1)..(v453_14_origin + 2)]);
          let mut v461_11 = Space::new();
          let mut v461_11_write = v461_11.write_zipper();
          for v461_11_byte in v453_14_cursor.child_mask().iter() {
            v453_14_cursor.descend_to_existing_byte(v461_11_byte);
            {
            let v462_2: Space = singleton(&v453_14_cursor.path()[(v453_14_origin + 2)..(v453_14_origin + 3)]);
            let v462_3: Space = intersect(&(*CONSTANT_1),&(v462_2));
            let v462_4: Space = if has_head(&(v462_3)) { singleton(&[]) } else { Space::new() };
            drop(v462_3);
            let v462_5: Space = subtract(&(*CONSTANT_0),&(v462_4));
            drop(v462_4);
            let v462_8: Space = if (&(v462_5)).is_empty() { Space::new() } else {
              let v463_6: Path = concat_path(&(v461_6),&v453_14_cursor.path()[(v453_14_origin + 2)..(v453_14_origin + 3)]);
              let v463_7: Space = routine_38(c, &(v463_6), &v453_14_cursor);
              compose(&(v462_5),&(v463_7))
            };
            drop(v462_5);
            let v462_9: Space = intersect(&(*CONSTANT_1),&(v462_2));
            drop(v462_2);
            let v462_10: Space = if has_head(&(v462_9)) { singleton(&[]) } else { Space::new() };
            drop(v462_9);
            let v462_12: Space = if (&(v462_10)).is_empty() { Space::new() } else {
              let v464_6: Path = concat_path(&(v461_6),&v453_14_cursor.path()[(v453_14_origin + 2)..(v453_14_origin + 3)]);
              let v464_11: Space = routine_12(c, &(v464_6), &v453_14_cursor);
              drop(v464_6);
              compose(&(v462_10),&(v464_11))
            };
            drop(v462_10);
            let v462_13: Space = unite(&(v462_8),&(v462_12));
            join_wrapped_into(&mut v461_11_write,&((v462_13).read_zipper()),&[]);
            }
            v453_14_cursor.ascend(1);
          }
          drop(v461_11_write);
          drop(v461_6);
          compose(&(v456_10),&(v461_11))
        };
        drop(v456_10);
        let v456_13: Space = unite(&(v456_8),&(v456_12));
        join_wrapped_into(&mut v455_7_write,&((v456_13).read_zipper()),&[]);
        }
        v453_14_cursor.ascend(1);
      }
      drop(v455_7_write);
      drop(v455_6);
      compose(&(v454_5),&(v455_7))
    };
    drop(v454_5);
    let v454_9: Space = intersect(&(*CONSTANT_1),&(v454_2));
    drop(v454_2);
    let v454_10: Space = if has_head(&(v454_9)) { singleton(&[]) } else { Space::new() };
    drop(v454_9);
    let v454_11: Space = compose(&(v454_10),&v453_14_cursor);
    drop(v454_10);
    let v454_12: Space = unite(&(v454_8),&(v454_11));
    drop(v454_11);
    join_wrapped_into(&mut v453_14_write,&((v454_12).read_zipper()),&[]);
    }
    v453_14_cursor.ascend(1);
  }
  drop(v453_14_cursor);
  drop(v453_14_write);
  (v453_14).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v465_20 = Space::new();
  let mut v465_20_write = v465_20.write_zipper();
  let mut v465_20_cursor = (*s0).read_zipper();
  let v465_20_origin = v465_20_cursor.path().len();
  for v465_20_byte in v465_20_cursor.child_mask().iter() {
    v465_20_cursor.descend_to_existing_byte(v465_20_byte);
    {
    let v466_2: Space = singleton(&v465_20_cursor.path()[v465_20_origin..(v465_20_origin + 1)]);
    let v466_3: Space = intersect(&(*CONSTANT_1),&(v466_2));
    let v466_4: Space = if has_head(&(v466_3)) { singleton(&[]) } else { Space::new() };
    drop(v466_3);
    let v466_5: Space = subtract(&(*CONSTANT_0),&(v466_4));
    drop(v466_4);
    let v466_8: Space = if (&(v466_5)).is_empty() { Space::new() } else {
      let v467_6: Path = concat_path(&(*p0),&v465_20_cursor.path()[v465_20_origin..(v465_20_origin + 1)]);
      let mut v467_7 = Space::new();
      let mut v467_7_write = v467_7.write_zipper();
      for v467_7_byte in v465_20_cursor.child_mask().iter() {
        v465_20_cursor.descend_to_existing_byte(v467_7_byte);
        {
        let v468_2: Space = singleton(&v465_20_cursor.path()[(v465_20_origin + 1)..(v465_20_origin + 2)]);
        let v468_3: Space = intersect(&(*CONSTANT_1),&(v468_2));
        let v468_4: Space = if has_head(&(v468_3)) { singleton(&[]) } else { Space::new() };
        drop(v468_3);
        let v468_5: Space = subtract(&(*CONSTANT_0),&(v468_4));
        drop(v468_4);
        let v468_8: Space = if (&(v468_5)).is_empty() { Space::new() } else {
          let v469_6: Path = concat_path(&(v467_6),&v465_20_cursor.path()[(v465_20_origin + 1)..(v465_20_origin + 2)]);
          let mut v469_7 = Space::new();
          let mut v469_7_write = v469_7.write_zipper();
          for v469_7_byte in v465_20_cursor.child_mask().iter() {
            v465_20_cursor.descend_to_existing_byte(v469_7_byte);
            {
            let v470_2: Space = singleton(&v465_20_cursor.path()[(v465_20_origin + 2)..(v465_20_origin + 3)]);
            let v470_3: Space = intersect(&(*CONSTANT_1),&(v470_2));
            let v470_4: Space = if has_head(&(v470_3)) { singleton(&[]) } else { Space::new() };
            drop(v470_3);
            let v470_5: Space = subtract(&(*CONSTANT_0),&(v470_4));
            drop(v470_4);
            let v470_8: Space = if (&(v470_5)).is_empty() { Space::new() } else {
              let v471_6: Path = concat_path(&(v469_6),&v465_20_cursor.path()[(v465_20_origin + 2)..(v465_20_origin + 3)]);
              let v471_7: Space = routine_40(c, &(v471_6), &v465_20_cursor);
              compose(&(v470_5),&(v471_7))
            };
            drop(v470_5);
            let v470_9: Space = intersect(&(*CONSTANT_1),&(v470_2));
            drop(v470_2);
            let v470_10: Space = if has_head(&(v470_9)) { singleton(&[]) } else { Space::new() };
            drop(v470_9);
            let v470_12: Space = if (&(v470_10)).is_empty() { Space::new() } else {
              let v472_6: Path = concat_path(&(v469_6),&v465_20_cursor.path()[(v465_20_origin + 2)..(v465_20_origin + 3)]);
              let v472_11: Space = routine_41(c, &(v472_6), &v465_20_cursor);
              drop(v472_6);
              compose(&(v470_10),&(v472_11))
            };
            drop(v470_10);
            let v470_13: Space = unite(&(v470_8),&(v470_12));
            join_wrapped_into(&mut v469_7_write,&((v470_13).read_zipper()),&[]);
            }
            v465_20_cursor.ascend(1);
          }
          drop(v469_7_write);
          compose(&(v468_5),&(v469_7))
        };
        drop(v468_5);
        let v468_9: Space = intersect(&(*CONSTANT_1),&(v468_2));
        drop(v468_2);
        let v468_10: Space = if has_head(&(v468_9)) { singleton(&[]) } else { Space::new() };
        drop(v468_9);
        let v468_12: Space = if (&(v468_10)).is_empty() { Space::new() } else {
          let v473_6: Path = concat_path(&(v467_6),&v465_20_cursor.path()[(v465_20_origin + 1)..(v465_20_origin + 2)]);
          let mut v473_11 = Space::new();
          let mut v473_11_write = v473_11.write_zipper();
          for v473_11_byte in v465_20_cursor.child_mask().iter() {
            v465_20_cursor.descend_to_existing_byte(v473_11_byte);
            {
            let v474_2: Space = singleton(&v465_20_cursor.path()[(v465_20_origin + 2)..(v465_20_origin + 3)]);
            let v474_3: Space = intersect(&(*CONSTANT_1),&(v474_2));
            let v474_4: Space = if has_head(&(v474_3)) { singleton(&[]) } else { Space::new() };
            drop(v474_3);
            let v474_5: Space = subtract(&(*CONSTANT_0),&(v474_4));
            drop(v474_4);
            let v474_8: Space = if (&(v474_5)).is_empty() { Space::new() } else {
              let v475_6: Path = concat_path(&(v473_6),&v465_20_cursor.path()[(v465_20_origin + 2)..(v465_20_origin + 3)]);
              let v475_7: Space = routine_40(c, &(v475_6), &v465_20_cursor);
              compose(&(v474_5),&(v475_7))
            };
            drop(v474_5);
            let v474_9: Space = intersect(&(*CONSTANT_1),&(v474_2));
            drop(v474_2);
            let v474_10: Space = if has_head(&(v474_9)) { singleton(&[]) } else { Space::new() };
            drop(v474_9);
            let v474_12: Space = if (&(v474_10)).is_empty() { Space::new() } else {
              let v476_6: Path = concat_path(&(v473_6),&v465_20_cursor.path()[(v465_20_origin + 2)..(v465_20_origin + 3)]);
              let v476_11: Space = routine_15(c, &(v476_6), &v465_20_cursor);
              drop(v476_6);
              compose(&(v474_10),&(v476_11))
            };
            drop(v474_10);
            let v474_13: Space = unite(&(v474_8),&(v474_12));
            join_wrapped_into(&mut v473_11_write,&((v474_13).read_zipper()),&[]);
            }
            v465_20_cursor.ascend(1);
          }
          drop(v473_11_write);
          drop(v473_6);
          compose(&(v468_10),&(v473_11))
        };
        drop(v468_10);
        let v468_13: Space = unite(&(v468_8),&(v468_12));
        join_wrapped_into(&mut v467_7_write,&((v468_13).read_zipper()),&[]);
        }
        v465_20_cursor.ascend(1);
      }
      drop(v467_7_write);
      compose(&(v466_5),&(v467_7))
    };
    drop(v466_5);
    let v466_9: Space = intersect(&(*CONSTANT_1),&(v466_2));
    drop(v466_2);
    let v466_10: Space = if has_head(&(v466_9)) { singleton(&[]) } else { Space::new() };
    drop(v466_9);
    let v466_12: Space = if (&(v466_10)).is_empty() { Space::new() } else {
      let v477_6: Path = concat_path(&(*p0),&v465_20_cursor.path()[v465_20_origin..(v465_20_origin + 1)]);
      let mut v477_11 = Space::new();
      let mut v477_11_write = v477_11.write_zipper();
      for v477_11_byte in v465_20_cursor.child_mask().iter() {
        v465_20_cursor.descend_to_existing_byte(v477_11_byte);
        {
        let v478_2: Space = singleton(&v465_20_cursor.path()[(v465_20_origin + 1)..(v465_20_origin + 2)]);
        let v478_3: Space = intersect(&(*CONSTANT_1),&(v478_2));
        let v478_4: Space = if has_head(&(v478_3)) { singleton(&[]) } else { Space::new() };
        drop(v478_3);
        let v478_5: Space = subtract(&(*CONSTANT_0),&(v478_4));
        drop(v478_4);
        let v478_8: Space = if (&(v478_5)).is_empty() { Space::new() } else {
          let v479_6: Path = concat_path(&(v477_6),&v465_20_cursor.path()[(v465_20_origin + 1)..(v465_20_origin + 2)]);
          let mut v479_7 = Space::new();
          let mut v479_7_write = v479_7.write_zipper();
          for v479_7_byte in v465_20_cursor.child_mask().iter() {
            v465_20_cursor.descend_to_existing_byte(v479_7_byte);
            {
            let v480_2: Space = singleton(&v465_20_cursor.path()[(v465_20_origin + 2)..(v465_20_origin + 3)]);
            let v480_3: Space = intersect(&(*CONSTANT_1),&(v480_2));
            let v480_4: Space = if has_head(&(v480_3)) { singleton(&[]) } else { Space::new() };
            drop(v480_3);
            let v480_5: Space = subtract(&(*CONSTANT_0),&(v480_4));
            drop(v480_4);
            let v480_8: Space = if (&(v480_5)).is_empty() { Space::new() } else {
              let v481_6: Path = concat_path(&(v479_6),&v465_20_cursor.path()[(v465_20_origin + 2)..(v465_20_origin + 3)]);
              let v481_7: Space = routine_40(c, &(v481_6), &v465_20_cursor);
              compose(&(v480_5),&(v481_7))
            };
            drop(v480_5);
            let v480_9: Space = intersect(&(*CONSTANT_1),&(v480_2));
            drop(v480_2);
            let v480_10: Space = if has_head(&(v480_9)) { singleton(&[]) } else { Space::new() };
            drop(v480_9);
            let v480_12: Space = if (&(v480_10)).is_empty() { Space::new() } else {
              let v482_6: Path = concat_path(&(v479_6),&v465_20_cursor.path()[(v465_20_origin + 2)..(v465_20_origin + 3)]);
              let v482_11: Space = routine_41(c, &(v482_6), &v465_20_cursor);
              drop(v482_6);
              compose(&(v480_10),&(v482_11))
            };
            drop(v480_10);
            let v480_13: Space = unite(&(v480_8),&(v480_12));
            join_wrapped_into(&mut v479_7_write,&((v480_13).read_zipper()),&[]);
            }
            v465_20_cursor.ascend(1);
          }
          drop(v479_7_write);
          drop(v479_6);
          compose(&(v478_5),&(v479_7))
        };
        drop(v478_5);
        let v478_9: Space = intersect(&(*CONSTANT_1),&(v478_2));
        drop(v478_2);
        let v478_10: Space = if has_head(&(v478_9)) { singleton(&[]) } else { Space::new() };
        drop(v478_9);
        let v478_11: Space = compose(&(v478_10),&v465_20_cursor);
        drop(v478_10);
        let v478_12: Space = unite(&(v478_8),&(v478_11));
        drop(v478_11);
        join_wrapped_into(&mut v477_11_write,&((v478_12).read_zipper()),&[]);
        }
        v465_20_cursor.ascend(1);
      }
      drop(v477_11_write);
      drop(v477_6);
      compose(&(v466_10),&(v477_11))
    };
    drop(v466_10);
    let v466_13: Space = unite(&(v466_8),&(v466_12));
    join_wrapped_into(&mut v465_20_write,&((v466_13).read_zipper()),&[]);
    }
    v465_20_cursor.ascend(1);
  }
  drop(v465_20_cursor);
  drop(v465_20_write);
  (v465_20).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v483_14 = Space::new();
  let mut v483_14_write = v483_14.write_zipper();
  let mut v483_14_cursor = (*s0).read_zipper();
  let v483_14_origin = v483_14_cursor.path().len();
  for v483_14_byte in v483_14_cursor.child_mask().iter() {
    v483_14_cursor.descend_to_existing_byte(v483_14_byte);
    {
    let v484_2: Space = singleton(&v483_14_cursor.path()[v483_14_origin..(v483_14_origin + 1)]);
    let v484_3: Space = intersect(&(*CONSTANT_1),&(v484_2));
    let v484_4: Space = if has_head(&(v484_3)) { singleton(&[]) } else { Space::new() };
    drop(v484_3);
    let v484_5: Space = subtract(&(*CONSTANT_0),&(v484_4));
    drop(v484_4);
    let v484_8: Space = if (&(v484_5)).is_empty() { Space::new() } else {
      let v485_6: Path = concat_path(&(*p0),&v483_14_cursor.path()[v483_14_origin..(v483_14_origin + 1)]);
      let mut v485_7 = Space::new();
      let mut v485_7_write = v485_7.write_zipper();
      for v485_7_byte in v483_14_cursor.child_mask().iter() {
        v483_14_cursor.descend_to_existing_byte(v485_7_byte);
        {
        let v486_2: Space = singleton(&v483_14_cursor.path()[(v483_14_origin + 1)..(v483_14_origin + 2)]);
        let v486_3: Space = intersect(&(*CONSTANT_1),&(v486_2));
        let v486_4: Space = if has_head(&(v486_3)) { singleton(&[]) } else { Space::new() };
        drop(v486_3);
        let v486_5: Space = subtract(&(*CONSTANT_0),&(v486_4));
        drop(v486_4);
        let v486_8: Space = if (&(v486_5)).is_empty() { Space::new() } else {
          let v487_6: Path = concat_path(&(v485_6),&v483_14_cursor.path()[(v483_14_origin + 1)..(v483_14_origin + 2)]);
          let mut v487_7 = Space::new();
          let mut v487_7_write = v487_7.write_zipper();
          for v487_7_byte in v483_14_cursor.child_mask().iter() {
            v483_14_cursor.descend_to_existing_byte(v487_7_byte);
            {
            let v488_2: Space = singleton(&v483_14_cursor.path()[(v483_14_origin + 2)..(v483_14_origin + 3)]);
            let v488_3: Space = intersect(&(*CONSTANT_1),&(v488_2));
            let v488_4: Space = if has_head(&(v488_3)) { singleton(&[]) } else { Space::new() };
            drop(v488_3);
            let v488_5: Space = subtract(&(*CONSTANT_0),&(v488_4));
            drop(v488_4);
            let v488_8: Space = if (&(v488_5)).is_empty() { Space::new() } else {
              let v489_6: Path = concat_path(&(v487_6),&v483_14_cursor.path()[(v483_14_origin + 2)..(v483_14_origin + 3)]);
              let v489_7: Space = routine_40(c, &(v489_6), &v483_14_cursor);
              compose(&(v488_5),&(v489_7))
            };
            drop(v488_5);
            let v488_9: Space = intersect(&(*CONSTANT_1),&(v488_2));
            drop(v488_2);
            let v488_10: Space = if has_head(&(v488_9)) { singleton(&[]) } else { Space::new() };
            drop(v488_9);
            let v488_12: Space = if (&(v488_10)).is_empty() { Space::new() } else {
              let v490_6: Path = concat_path(&(v487_6),&v483_14_cursor.path()[(v483_14_origin + 2)..(v483_14_origin + 3)]);
              let v490_11: Space = routine_41(c, &(v490_6), &v483_14_cursor);
              drop(v490_6);
              compose(&(v488_10),&(v490_11))
            };
            drop(v488_10);
            let v488_13: Space = unite(&(v488_8),&(v488_12));
            join_wrapped_into(&mut v487_7_write,&((v488_13).read_zipper()),&[]);
            }
            v483_14_cursor.ascend(1);
          }
          drop(v487_7_write);
          compose(&(v486_5),&(v487_7))
        };
        drop(v486_5);
        let v486_9: Space = intersect(&(*CONSTANT_1),&(v486_2));
        drop(v486_2);
        let v486_10: Space = if has_head(&(v486_9)) { singleton(&[]) } else { Space::new() };
        drop(v486_9);
        let v486_12: Space = if (&(v486_10)).is_empty() { Space::new() } else {
          let v491_6: Path = concat_path(&(v485_6),&v483_14_cursor.path()[(v483_14_origin + 1)..(v483_14_origin + 2)]);
          let mut v491_11 = Space::new();
          let mut v491_11_write = v491_11.write_zipper();
          for v491_11_byte in v483_14_cursor.child_mask().iter() {
            v483_14_cursor.descend_to_existing_byte(v491_11_byte);
            {
            let v492_2: Space = singleton(&v483_14_cursor.path()[(v483_14_origin + 2)..(v483_14_origin + 3)]);
            let v492_3: Space = intersect(&(*CONSTANT_1),&(v492_2));
            let v492_4: Space = if has_head(&(v492_3)) { singleton(&[]) } else { Space::new() };
            drop(v492_3);
            let v492_5: Space = subtract(&(*CONSTANT_0),&(v492_4));
            drop(v492_4);
            let v492_8: Space = if (&(v492_5)).is_empty() { Space::new() } else {
              let v493_6: Path = concat_path(&(v491_6),&v483_14_cursor.path()[(v483_14_origin + 2)..(v483_14_origin + 3)]);
              let v493_7: Space = routine_40(c, &(v493_6), &v483_14_cursor);
              compose(&(v492_5),&(v493_7))
            };
            drop(v492_5);
            let v492_9: Space = intersect(&(*CONSTANT_1),&(v492_2));
            drop(v492_2);
            let v492_10: Space = if has_head(&(v492_9)) { singleton(&[]) } else { Space::new() };
            drop(v492_9);
            let v492_12: Space = if (&(v492_10)).is_empty() { Space::new() } else {
              let v494_6: Path = concat_path(&(v491_6),&v483_14_cursor.path()[(v483_14_origin + 2)..(v483_14_origin + 3)]);
              let v494_11: Space = routine_15(c, &(v494_6), &v483_14_cursor);
              drop(v494_6);
              compose(&(v492_10),&(v494_11))
            };
            drop(v492_10);
            let v492_13: Space = unite(&(v492_8),&(v492_12));
            join_wrapped_into(&mut v491_11_write,&((v492_13).read_zipper()),&[]);
            }
            v483_14_cursor.ascend(1);
          }
          drop(v491_11_write);
          drop(v491_6);
          compose(&(v486_10),&(v491_11))
        };
        drop(v486_10);
        let v486_13: Space = unite(&(v486_8),&(v486_12));
        join_wrapped_into(&mut v485_7_write,&((v486_13).read_zipper()),&[]);
        }
        v483_14_cursor.ascend(1);
      }
      drop(v485_7_write);
      drop(v485_6);
      compose(&(v484_5),&(v485_7))
    };
    drop(v484_5);
    let v484_9: Space = intersect(&(*CONSTANT_1),&(v484_2));
    drop(v484_2);
    let v484_10: Space = if has_head(&(v484_9)) { singleton(&[]) } else { Space::new() };
    drop(v484_9);
    let v484_11: Space = compose(&(v484_10),&v483_14_cursor);
    drop(v484_10);
    let v484_12: Space = unite(&(v484_8),&(v484_11));
    drop(v484_11);
    join_wrapped_into(&mut v483_14_write,&((v484_12).read_zipper()),&[]);
    }
    v483_14_cursor.ascend(1);
  }
  drop(v483_14_cursor);
  drop(v483_14_write);
  (v483_14).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v495_20 = Space::new();
  let mut v495_20_write = v495_20.write_zipper();
  let mut v495_20_cursor = (*s0).read_zipper();
  let v495_20_origin = v495_20_cursor.path().len();
  for v495_20_byte in v495_20_cursor.child_mask().iter() {
    v495_20_cursor.descend_to_existing_byte(v495_20_byte);
    {
    let v496_2: Space = singleton(&v495_20_cursor.path()[v495_20_origin..(v495_20_origin + 1)]);
    let v496_3: Space = intersect(&(*CONSTANT_1),&(v496_2));
    let v496_4: Space = if has_head(&(v496_3)) { singleton(&[]) } else { Space::new() };
    drop(v496_3);
    let v496_5: Space = subtract(&(*CONSTANT_0),&(v496_4));
    drop(v496_4);
    let v496_8: Space = if (&(v496_5)).is_empty() { Space::new() } else {
      let v497_6: Path = concat_path(&(*p0),&v495_20_cursor.path()[v495_20_origin..(v495_20_origin + 1)]);
      let mut v497_7 = Space::new();
      let mut v497_7_write = v497_7.write_zipper();
      for v497_7_byte in v495_20_cursor.child_mask().iter() {
        v495_20_cursor.descend_to_existing_byte(v497_7_byte);
        {
        let v498_2: Space = singleton(&v495_20_cursor.path()[(v495_20_origin + 1)..(v495_20_origin + 2)]);
        let v498_3: Space = intersect(&(*CONSTANT_1),&(v498_2));
        let v498_4: Space = if has_head(&(v498_3)) { singleton(&[]) } else { Space::new() };
        drop(v498_3);
        let v498_5: Space = subtract(&(*CONSTANT_0),&(v498_4));
        drop(v498_4);
        let v498_8: Space = if (&(v498_5)).is_empty() { Space::new() } else {
          let v499_6: Path = concat_path(&(v497_6),&v495_20_cursor.path()[(v495_20_origin + 1)..(v495_20_origin + 2)]);
          let mut v499_7 = Space::new();
          let mut v499_7_write = v499_7.write_zipper();
          for v499_7_byte in v495_20_cursor.child_mask().iter() {
            v495_20_cursor.descend_to_existing_byte(v499_7_byte);
            {
            let v500_2: Space = singleton(&v495_20_cursor.path()[(v495_20_origin + 2)..(v495_20_origin + 3)]);
            let v500_3: Space = intersect(&(*CONSTANT_1),&(v500_2));
            let v500_4: Space = if has_head(&(v500_3)) { singleton(&[]) } else { Space::new() };
            drop(v500_3);
            let v500_5: Space = subtract(&(*CONSTANT_0),&(v500_4));
            drop(v500_4);
            let v500_8: Space = if (&(v500_5)).is_empty() { Space::new() } else {
              let v501_6: Path = concat_path(&(v499_6),&v495_20_cursor.path()[(v495_20_origin + 2)..(v495_20_origin + 3)]);
              let v501_7: Space = routine_42(c, &(v501_6), &v495_20_cursor);
              compose(&(v500_5),&(v501_7))
            };
            drop(v500_5);
            let v500_9: Space = intersect(&(*CONSTANT_1),&(v500_2));
            drop(v500_2);
            let v500_10: Space = if has_head(&(v500_9)) { singleton(&[]) } else { Space::new() };
            drop(v500_9);
            let v500_12: Space = if (&(v500_10)).is_empty() { Space::new() } else {
              let v502_6: Path = concat_path(&(v499_6),&v495_20_cursor.path()[(v495_20_origin + 2)..(v495_20_origin + 3)]);
              let v502_11: Space = routine_43(c, &(v502_6), &v495_20_cursor);
              drop(v502_6);
              compose(&(v500_10),&(v502_11))
            };
            drop(v500_10);
            let v500_13: Space = unite(&(v500_8),&(v500_12));
            join_wrapped_into(&mut v499_7_write,&((v500_13).read_zipper()),&[]);
            }
            v495_20_cursor.ascend(1);
          }
          drop(v499_7_write);
          compose(&(v498_5),&(v499_7))
        };
        drop(v498_5);
        let v498_9: Space = intersect(&(*CONSTANT_1),&(v498_2));
        drop(v498_2);
        let v498_10: Space = if has_head(&(v498_9)) { singleton(&[]) } else { Space::new() };
        drop(v498_9);
        let v498_12: Space = if (&(v498_10)).is_empty() { Space::new() } else {
          let v503_6: Path = concat_path(&(v497_6),&v495_20_cursor.path()[(v495_20_origin + 1)..(v495_20_origin + 2)]);
          let mut v503_11 = Space::new();
          let mut v503_11_write = v503_11.write_zipper();
          for v503_11_byte in v495_20_cursor.child_mask().iter() {
            v495_20_cursor.descend_to_existing_byte(v503_11_byte);
            {
            let v504_2: Space = singleton(&v495_20_cursor.path()[(v495_20_origin + 2)..(v495_20_origin + 3)]);
            let v504_3: Space = intersect(&(*CONSTANT_1),&(v504_2));
            let v504_4: Space = if has_head(&(v504_3)) { singleton(&[]) } else { Space::new() };
            drop(v504_3);
            let v504_5: Space = subtract(&(*CONSTANT_0),&(v504_4));
            drop(v504_4);
            let v504_8: Space = if (&(v504_5)).is_empty() { Space::new() } else {
              let v505_6: Path = concat_path(&(v503_6),&v495_20_cursor.path()[(v495_20_origin + 2)..(v495_20_origin + 3)]);
              let v505_7: Space = routine_42(c, &(v505_6), &v495_20_cursor);
              compose(&(v504_5),&(v505_7))
            };
            drop(v504_5);
            let v504_9: Space = intersect(&(*CONSTANT_1),&(v504_2));
            drop(v504_2);
            let v504_10: Space = if has_head(&(v504_9)) { singleton(&[]) } else { Space::new() };
            drop(v504_9);
            let v504_12: Space = if (&(v504_10)).is_empty() { Space::new() } else {
              let v506_6: Path = concat_path(&(v503_6),&v495_20_cursor.path()[(v495_20_origin + 2)..(v495_20_origin + 3)]);
              let v506_11: Space = routine_12(c, &(v506_6), &v495_20_cursor);
              drop(v506_6);
              compose(&(v504_10),&(v506_11))
            };
            drop(v504_10);
            let v504_13: Space = unite(&(v504_8),&(v504_12));
            join_wrapped_into(&mut v503_11_write,&((v504_13).read_zipper()),&[]);
            }
            v495_20_cursor.ascend(1);
          }
          drop(v503_11_write);
          drop(v503_6);
          compose(&(v498_10),&(v503_11))
        };
        drop(v498_10);
        let v498_13: Space = unite(&(v498_8),&(v498_12));
        join_wrapped_into(&mut v497_7_write,&((v498_13).read_zipper()),&[]);
        }
        v495_20_cursor.ascend(1);
      }
      drop(v497_7_write);
      compose(&(v496_5),&(v497_7))
    };
    drop(v496_5);
    let v496_9: Space = intersect(&(*CONSTANT_1),&(v496_2));
    drop(v496_2);
    let v496_10: Space = if has_head(&(v496_9)) { singleton(&[]) } else { Space::new() };
    drop(v496_9);
    let v496_12: Space = if (&(v496_10)).is_empty() { Space::new() } else {
      let v507_6: Path = concat_path(&(*p0),&v495_20_cursor.path()[v495_20_origin..(v495_20_origin + 1)]);
      let mut v507_11 = Space::new();
      let mut v507_11_write = v507_11.write_zipper();
      for v507_11_byte in v495_20_cursor.child_mask().iter() {
        v495_20_cursor.descend_to_existing_byte(v507_11_byte);
        {
        let v508_2: Space = singleton(&v495_20_cursor.path()[(v495_20_origin + 1)..(v495_20_origin + 2)]);
        let v508_3: Space = intersect(&(*CONSTANT_1),&(v508_2));
        let v508_4: Space = if has_head(&(v508_3)) { singleton(&[]) } else { Space::new() };
        drop(v508_3);
        let v508_5: Space = subtract(&(*CONSTANT_0),&(v508_4));
        drop(v508_4);
        let v508_8: Space = if (&(v508_5)).is_empty() { Space::new() } else {
          let v509_6: Path = concat_path(&(v507_6),&v495_20_cursor.path()[(v495_20_origin + 1)..(v495_20_origin + 2)]);
          let mut v509_7 = Space::new();
          let mut v509_7_write = v509_7.write_zipper();
          for v509_7_byte in v495_20_cursor.child_mask().iter() {
            v495_20_cursor.descend_to_existing_byte(v509_7_byte);
            {
            let v510_2: Space = singleton(&v495_20_cursor.path()[(v495_20_origin + 2)..(v495_20_origin + 3)]);
            let v510_3: Space = intersect(&(*CONSTANT_1),&(v510_2));
            let v510_4: Space = if has_head(&(v510_3)) { singleton(&[]) } else { Space::new() };
            drop(v510_3);
            let v510_5: Space = subtract(&(*CONSTANT_0),&(v510_4));
            drop(v510_4);
            let v510_8: Space = if (&(v510_5)).is_empty() { Space::new() } else {
              let v511_6: Path = concat_path(&(v509_6),&v495_20_cursor.path()[(v495_20_origin + 2)..(v495_20_origin + 3)]);
              let v511_7: Space = routine_42(c, &(v511_6), &v495_20_cursor);
              compose(&(v510_5),&(v511_7))
            };
            drop(v510_5);
            let v510_9: Space = intersect(&(*CONSTANT_1),&(v510_2));
            drop(v510_2);
            let v510_10: Space = if has_head(&(v510_9)) { singleton(&[]) } else { Space::new() };
            drop(v510_9);
            let v510_12: Space = if (&(v510_10)).is_empty() { Space::new() } else {
              let v512_6: Path = concat_path(&(v509_6),&v495_20_cursor.path()[(v495_20_origin + 2)..(v495_20_origin + 3)]);
              let v512_11: Space = routine_43(c, &(v512_6), &v495_20_cursor);
              drop(v512_6);
              compose(&(v510_10),&(v512_11))
            };
            drop(v510_10);
            let v510_13: Space = unite(&(v510_8),&(v510_12));
            join_wrapped_into(&mut v509_7_write,&((v510_13).read_zipper()),&[]);
            }
            v495_20_cursor.ascend(1);
          }
          drop(v509_7_write);
          drop(v509_6);
          compose(&(v508_5),&(v509_7))
        };
        drop(v508_5);
        let v508_9: Space = intersect(&(*CONSTANT_1),&(v508_2));
        drop(v508_2);
        let v508_10: Space = if has_head(&(v508_9)) { singleton(&[]) } else { Space::new() };
        drop(v508_9);
        let v508_11: Space = compose(&(v508_10),&v495_20_cursor);
        drop(v508_10);
        let v508_12: Space = unite(&(v508_8),&(v508_11));
        drop(v508_11);
        join_wrapped_into(&mut v507_11_write,&((v508_12).read_zipper()),&[]);
        }
        v495_20_cursor.ascend(1);
      }
      drop(v507_11_write);
      drop(v507_6);
      compose(&(v496_10),&(v507_11))
    };
    drop(v496_10);
    let v496_13: Space = unite(&(v496_8),&(v496_12));
    join_wrapped_into(&mut v495_20_write,&((v496_13).read_zipper()),&[]);
    }
    v495_20_cursor.ascend(1);
  }
  drop(v495_20_cursor);
  drop(v495_20_write);
  (v495_20).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v513_14 = Space::new();
  let mut v513_14_write = v513_14.write_zipper();
  let mut v513_14_cursor = (*s0).read_zipper();
  let v513_14_origin = v513_14_cursor.path().len();
  for v513_14_byte in v513_14_cursor.child_mask().iter() {
    v513_14_cursor.descend_to_existing_byte(v513_14_byte);
    {
    let v514_2: Space = singleton(&v513_14_cursor.path()[v513_14_origin..(v513_14_origin + 1)]);
    let v514_3: Space = intersect(&(*CONSTANT_1),&(v514_2));
    let v514_4: Space = if has_head(&(v514_3)) { singleton(&[]) } else { Space::new() };
    drop(v514_3);
    let v514_5: Space = subtract(&(*CONSTANT_0),&(v514_4));
    drop(v514_4);
    let v514_8: Space = if (&(v514_5)).is_empty() { Space::new() } else {
      let v515_6: Path = concat_path(&(*p0),&v513_14_cursor.path()[v513_14_origin..(v513_14_origin + 1)]);
      let mut v515_7 = Space::new();
      let mut v515_7_write = v515_7.write_zipper();
      for v515_7_byte in v513_14_cursor.child_mask().iter() {
        v513_14_cursor.descend_to_existing_byte(v515_7_byte);
        {
        let v516_2: Space = singleton(&v513_14_cursor.path()[(v513_14_origin + 1)..(v513_14_origin + 2)]);
        let v516_3: Space = intersect(&(*CONSTANT_1),&(v516_2));
        let v516_4: Space = if has_head(&(v516_3)) { singleton(&[]) } else { Space::new() };
        drop(v516_3);
        let v516_5: Space = subtract(&(*CONSTANT_0),&(v516_4));
        drop(v516_4);
        let v516_8: Space = if (&(v516_5)).is_empty() { Space::new() } else {
          let v517_6: Path = concat_path(&(v515_6),&v513_14_cursor.path()[(v513_14_origin + 1)..(v513_14_origin + 2)]);
          let mut v517_7 = Space::new();
          let mut v517_7_write = v517_7.write_zipper();
          for v517_7_byte in v513_14_cursor.child_mask().iter() {
            v513_14_cursor.descend_to_existing_byte(v517_7_byte);
            {
            let v518_2: Space = singleton(&v513_14_cursor.path()[(v513_14_origin + 2)..(v513_14_origin + 3)]);
            let v518_3: Space = intersect(&(*CONSTANT_1),&(v518_2));
            let v518_4: Space = if has_head(&(v518_3)) { singleton(&[]) } else { Space::new() };
            drop(v518_3);
            let v518_5: Space = subtract(&(*CONSTANT_0),&(v518_4));
            drop(v518_4);
            let v518_8: Space = if (&(v518_5)).is_empty() { Space::new() } else {
              let v519_6: Path = concat_path(&(v517_6),&v513_14_cursor.path()[(v513_14_origin + 2)..(v513_14_origin + 3)]);
              let v519_7: Space = routine_42(c, &(v519_6), &v513_14_cursor);
              compose(&(v518_5),&(v519_7))
            };
            drop(v518_5);
            let v518_9: Space = intersect(&(*CONSTANT_1),&(v518_2));
            drop(v518_2);
            let v518_10: Space = if has_head(&(v518_9)) { singleton(&[]) } else { Space::new() };
            drop(v518_9);
            let v518_12: Space = if (&(v518_10)).is_empty() { Space::new() } else {
              let v520_6: Path = concat_path(&(v517_6),&v513_14_cursor.path()[(v513_14_origin + 2)..(v513_14_origin + 3)]);
              let v520_11: Space = routine_43(c, &(v520_6), &v513_14_cursor);
              drop(v520_6);
              compose(&(v518_10),&(v520_11))
            };
            drop(v518_10);
            let v518_13: Space = unite(&(v518_8),&(v518_12));
            join_wrapped_into(&mut v517_7_write,&((v518_13).read_zipper()),&[]);
            }
            v513_14_cursor.ascend(1);
          }
          drop(v517_7_write);
          compose(&(v516_5),&(v517_7))
        };
        drop(v516_5);
        let v516_9: Space = intersect(&(*CONSTANT_1),&(v516_2));
        drop(v516_2);
        let v516_10: Space = if has_head(&(v516_9)) { singleton(&[]) } else { Space::new() };
        drop(v516_9);
        let v516_12: Space = if (&(v516_10)).is_empty() { Space::new() } else {
          let v521_6: Path = concat_path(&(v515_6),&v513_14_cursor.path()[(v513_14_origin + 1)..(v513_14_origin + 2)]);
          let mut v521_11 = Space::new();
          let mut v521_11_write = v521_11.write_zipper();
          for v521_11_byte in v513_14_cursor.child_mask().iter() {
            v513_14_cursor.descend_to_existing_byte(v521_11_byte);
            {
            let v522_2: Space = singleton(&v513_14_cursor.path()[(v513_14_origin + 2)..(v513_14_origin + 3)]);
            let v522_3: Space = intersect(&(*CONSTANT_1),&(v522_2));
            let v522_4: Space = if has_head(&(v522_3)) { singleton(&[]) } else { Space::new() };
            drop(v522_3);
            let v522_5: Space = subtract(&(*CONSTANT_0),&(v522_4));
            drop(v522_4);
            let v522_8: Space = if (&(v522_5)).is_empty() { Space::new() } else {
              let v523_6: Path = concat_path(&(v521_6),&v513_14_cursor.path()[(v513_14_origin + 2)..(v513_14_origin + 3)]);
              let v523_7: Space = routine_42(c, &(v523_6), &v513_14_cursor);
              compose(&(v522_5),&(v523_7))
            };
            drop(v522_5);
            let v522_9: Space = intersect(&(*CONSTANT_1),&(v522_2));
            drop(v522_2);
            let v522_10: Space = if has_head(&(v522_9)) { singleton(&[]) } else { Space::new() };
            drop(v522_9);
            let v522_12: Space = if (&(v522_10)).is_empty() { Space::new() } else {
              let v524_6: Path = concat_path(&(v521_6),&v513_14_cursor.path()[(v513_14_origin + 2)..(v513_14_origin + 3)]);
              let v524_11: Space = routine_12(c, &(v524_6), &v513_14_cursor);
              drop(v524_6);
              compose(&(v522_10),&(v524_11))
            };
            drop(v522_10);
            let v522_13: Space = unite(&(v522_8),&(v522_12));
            join_wrapped_into(&mut v521_11_write,&((v522_13).read_zipper()),&[]);
            }
            v513_14_cursor.ascend(1);
          }
          drop(v521_11_write);
          drop(v521_6);
          compose(&(v516_10),&(v521_11))
        };
        drop(v516_10);
        let v516_13: Space = unite(&(v516_8),&(v516_12));
        join_wrapped_into(&mut v515_7_write,&((v516_13).read_zipper()),&[]);
        }
        v513_14_cursor.ascend(1);
      }
      drop(v515_7_write);
      drop(v515_6);
      compose(&(v514_5),&(v515_7))
    };
    drop(v514_5);
    let v514_9: Space = intersect(&(*CONSTANT_1),&(v514_2));
    drop(v514_2);
    let v514_10: Space = if has_head(&(v514_9)) { singleton(&[]) } else { Space::new() };
    drop(v514_9);
    let v514_11: Space = compose(&(v514_10),&v513_14_cursor);
    drop(v514_10);
    let v514_12: Space = unite(&(v514_8),&(v514_11));
    drop(v514_11);
    join_wrapped_into(&mut v513_14_write,&((v514_12).read_zipper()),&[]);
    }
    v513_14_cursor.ascend(1);
  }
  drop(v513_14_cursor);
  drop(v513_14_write);
  (v513_14).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v525_20 = Space::new();
  let mut v525_20_write = v525_20.write_zipper();
  let mut v525_20_cursor = (*s0).read_zipper();
  let v525_20_origin = v525_20_cursor.path().len();
  for v525_20_byte in v525_20_cursor.child_mask().iter() {
    v525_20_cursor.descend_to_existing_byte(v525_20_byte);
    {
    let v526_2: Space = singleton(&v525_20_cursor.path()[v525_20_origin..(v525_20_origin + 1)]);
    let v526_3: Space = intersect(&(*CONSTANT_1),&(v526_2));
    let v526_4: Space = if has_head(&(v526_3)) { singleton(&[]) } else { Space::new() };
    drop(v526_3);
    let v526_5: Space = subtract(&(*CONSTANT_0),&(v526_4));
    drop(v526_4);
    let v526_8: Space = if (&(v526_5)).is_empty() { Space::new() } else {
      let v527_6: Path = concat_path(&(*p0),&v525_20_cursor.path()[v525_20_origin..(v525_20_origin + 1)]);
      let mut v527_7 = Space::new();
      let mut v527_7_write = v527_7.write_zipper();
      for v527_7_byte in v525_20_cursor.child_mask().iter() {
        v525_20_cursor.descend_to_existing_byte(v527_7_byte);
        {
        let v528_2: Space = singleton(&v525_20_cursor.path()[(v525_20_origin + 1)..(v525_20_origin + 2)]);
        let v528_3: Space = intersect(&(*CONSTANT_1),&(v528_2));
        let v528_4: Space = if has_head(&(v528_3)) { singleton(&[]) } else { Space::new() };
        drop(v528_3);
        let v528_5: Space = subtract(&(*CONSTANT_0),&(v528_4));
        drop(v528_4);
        let v528_8: Space = if (&(v528_5)).is_empty() { Space::new() } else {
          let v529_6: Path = concat_path(&(v527_6),&v525_20_cursor.path()[(v525_20_origin + 1)..(v525_20_origin + 2)]);
          let mut v529_7 = Space::new();
          let mut v529_7_write = v529_7.write_zipper();
          for v529_7_byte in v525_20_cursor.child_mask().iter() {
            v525_20_cursor.descend_to_existing_byte(v529_7_byte);
            {
            let v530_2: Space = singleton(&v525_20_cursor.path()[(v525_20_origin + 2)..(v525_20_origin + 3)]);
            let v530_3: Space = intersect(&(*CONSTANT_1),&(v530_2));
            let v530_4: Space = if has_head(&(v530_3)) { singleton(&[]) } else { Space::new() };
            drop(v530_3);
            let v530_5: Space = subtract(&(*CONSTANT_0),&(v530_4));
            drop(v530_4);
            let v530_8: Space = if (&(v530_5)).is_empty() { Space::new() } else {
              let v531_6: Path = concat_path(&(v529_6),&v525_20_cursor.path()[(v525_20_origin + 2)..(v525_20_origin + 3)]);
              let v531_7: Space = routine_44(c, &(v531_6), &v525_20_cursor);
              compose(&(v530_5),&(v531_7))
            };
            drop(v530_5);
            let v530_9: Space = intersect(&(*CONSTANT_1),&(v530_2));
            drop(v530_2);
            let v530_10: Space = if has_head(&(v530_9)) { singleton(&[]) } else { Space::new() };
            drop(v530_9);
            let v530_12: Space = if (&(v530_10)).is_empty() { Space::new() } else {
              let v532_6: Path = concat_path(&(v529_6),&v525_20_cursor.path()[(v525_20_origin + 2)..(v525_20_origin + 3)]);
              let v532_11: Space = routine_45(c, &(v532_6), &v525_20_cursor);
              drop(v532_6);
              compose(&(v530_10),&(v532_11))
            };
            drop(v530_10);
            let v530_13: Space = unite(&(v530_8),&(v530_12));
            join_wrapped_into(&mut v529_7_write,&((v530_13).read_zipper()),&[]);
            }
            v525_20_cursor.ascend(1);
          }
          drop(v529_7_write);
          compose(&(v528_5),&(v529_7))
        };
        drop(v528_5);
        let v528_9: Space = intersect(&(*CONSTANT_1),&(v528_2));
        drop(v528_2);
        let v528_10: Space = if has_head(&(v528_9)) { singleton(&[]) } else { Space::new() };
        drop(v528_9);
        let v528_12: Space = if (&(v528_10)).is_empty() { Space::new() } else {
          let v533_6: Path = concat_path(&(v527_6),&v525_20_cursor.path()[(v525_20_origin + 1)..(v525_20_origin + 2)]);
          let mut v533_11 = Space::new();
          let mut v533_11_write = v533_11.write_zipper();
          for v533_11_byte in v525_20_cursor.child_mask().iter() {
            v525_20_cursor.descend_to_existing_byte(v533_11_byte);
            {
            let v534_2: Space = singleton(&v525_20_cursor.path()[(v525_20_origin + 2)..(v525_20_origin + 3)]);
            let v534_3: Space = intersect(&(*CONSTANT_1),&(v534_2));
            let v534_4: Space = if has_head(&(v534_3)) { singleton(&[]) } else { Space::new() };
            drop(v534_3);
            let v534_5: Space = subtract(&(*CONSTANT_0),&(v534_4));
            drop(v534_4);
            let v534_8: Space = if (&(v534_5)).is_empty() { Space::new() } else {
              let v535_6: Path = concat_path(&(v533_6),&v525_20_cursor.path()[(v525_20_origin + 2)..(v525_20_origin + 3)]);
              let v535_7: Space = routine_44(c, &(v535_6), &v525_20_cursor);
              compose(&(v534_5),&(v535_7))
            };
            drop(v534_5);
            let v534_9: Space = intersect(&(*CONSTANT_1),&(v534_2));
            drop(v534_2);
            let v534_10: Space = if has_head(&(v534_9)) { singleton(&[]) } else { Space::new() };
            drop(v534_9);
            let v534_12: Space = if (&(v534_10)).is_empty() { Space::new() } else {
              let v536_6: Path = concat_path(&(v533_6),&v525_20_cursor.path()[(v525_20_origin + 2)..(v525_20_origin + 3)]);
              let v536_11: Space = routine_15(c, &(v536_6), &v525_20_cursor);
              drop(v536_6);
              compose(&(v534_10),&(v536_11))
            };
            drop(v534_10);
            let v534_13: Space = unite(&(v534_8),&(v534_12));
            join_wrapped_into(&mut v533_11_write,&((v534_13).read_zipper()),&[]);
            }
            v525_20_cursor.ascend(1);
          }
          drop(v533_11_write);
          drop(v533_6);
          compose(&(v528_10),&(v533_11))
        };
        drop(v528_10);
        let v528_13: Space = unite(&(v528_8),&(v528_12));
        join_wrapped_into(&mut v527_7_write,&((v528_13).read_zipper()),&[]);
        }
        v525_20_cursor.ascend(1);
      }
      drop(v527_7_write);
      compose(&(v526_5),&(v527_7))
    };
    drop(v526_5);
    let v526_9: Space = intersect(&(*CONSTANT_1),&(v526_2));
    drop(v526_2);
    let v526_10: Space = if has_head(&(v526_9)) { singleton(&[]) } else { Space::new() };
    drop(v526_9);
    let v526_12: Space = if (&(v526_10)).is_empty() { Space::new() } else {
      let v537_6: Path = concat_path(&(*p0),&v525_20_cursor.path()[v525_20_origin..(v525_20_origin + 1)]);
      let mut v537_11 = Space::new();
      let mut v537_11_write = v537_11.write_zipper();
      for v537_11_byte in v525_20_cursor.child_mask().iter() {
        v525_20_cursor.descend_to_existing_byte(v537_11_byte);
        {
        let v538_2: Space = singleton(&v525_20_cursor.path()[(v525_20_origin + 1)..(v525_20_origin + 2)]);
        let v538_3: Space = intersect(&(*CONSTANT_1),&(v538_2));
        let v538_4: Space = if has_head(&(v538_3)) { singleton(&[]) } else { Space::new() };
        drop(v538_3);
        let v538_5: Space = subtract(&(*CONSTANT_0),&(v538_4));
        drop(v538_4);
        let v538_8: Space = if (&(v538_5)).is_empty() { Space::new() } else {
          let v539_6: Path = concat_path(&(v537_6),&v525_20_cursor.path()[(v525_20_origin + 1)..(v525_20_origin + 2)]);
          let mut v539_7 = Space::new();
          let mut v539_7_write = v539_7.write_zipper();
          for v539_7_byte in v525_20_cursor.child_mask().iter() {
            v525_20_cursor.descend_to_existing_byte(v539_7_byte);
            {
            let v540_2: Space = singleton(&v525_20_cursor.path()[(v525_20_origin + 2)..(v525_20_origin + 3)]);
            let v540_3: Space = intersect(&(*CONSTANT_1),&(v540_2));
            let v540_4: Space = if has_head(&(v540_3)) { singleton(&[]) } else { Space::new() };
            drop(v540_3);
            let v540_5: Space = subtract(&(*CONSTANT_0),&(v540_4));
            drop(v540_4);
            let v540_8: Space = if (&(v540_5)).is_empty() { Space::new() } else {
              let v541_6: Path = concat_path(&(v539_6),&v525_20_cursor.path()[(v525_20_origin + 2)..(v525_20_origin + 3)]);
              let v541_7: Space = routine_44(c, &(v541_6), &v525_20_cursor);
              compose(&(v540_5),&(v541_7))
            };
            drop(v540_5);
            let v540_9: Space = intersect(&(*CONSTANT_1),&(v540_2));
            drop(v540_2);
            let v540_10: Space = if has_head(&(v540_9)) { singleton(&[]) } else { Space::new() };
            drop(v540_9);
            let v540_12: Space = if (&(v540_10)).is_empty() { Space::new() } else {
              let v542_6: Path = concat_path(&(v539_6),&v525_20_cursor.path()[(v525_20_origin + 2)..(v525_20_origin + 3)]);
              let v542_11: Space = routine_45(c, &(v542_6), &v525_20_cursor);
              drop(v542_6);
              compose(&(v540_10),&(v542_11))
            };
            drop(v540_10);
            let v540_13: Space = unite(&(v540_8),&(v540_12));
            join_wrapped_into(&mut v539_7_write,&((v540_13).read_zipper()),&[]);
            }
            v525_20_cursor.ascend(1);
          }
          drop(v539_7_write);
          drop(v539_6);
          compose(&(v538_5),&(v539_7))
        };
        drop(v538_5);
        let v538_9: Space = intersect(&(*CONSTANT_1),&(v538_2));
        drop(v538_2);
        let v538_10: Space = if has_head(&(v538_9)) { singleton(&[]) } else { Space::new() };
        drop(v538_9);
        let v538_11: Space = compose(&(v538_10),&v525_20_cursor);
        drop(v538_10);
        let v538_12: Space = unite(&(v538_8),&(v538_11));
        drop(v538_11);
        join_wrapped_into(&mut v537_11_write,&((v538_12).read_zipper()),&[]);
        }
        v525_20_cursor.ascend(1);
      }
      drop(v537_11_write);
      drop(v537_6);
      compose(&(v526_10),&(v537_11))
    };
    drop(v526_10);
    let v526_13: Space = unite(&(v526_8),&(v526_12));
    join_wrapped_into(&mut v525_20_write,&((v526_13).read_zipper()),&[]);
    }
    v525_20_cursor.ascend(1);
  }
  drop(v525_20_cursor);
  drop(v525_20_write);
  (v525_20).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v543_14 = Space::new();
  let mut v543_14_write = v543_14.write_zipper();
  let mut v543_14_cursor = (*s0).read_zipper();
  let v543_14_origin = v543_14_cursor.path().len();
  for v543_14_byte in v543_14_cursor.child_mask().iter() {
    v543_14_cursor.descend_to_existing_byte(v543_14_byte);
    {
    let v544_2: Space = singleton(&v543_14_cursor.path()[v543_14_origin..(v543_14_origin + 1)]);
    let v544_3: Space = intersect(&(*CONSTANT_1),&(v544_2));
    let v544_4: Space = if has_head(&(v544_3)) { singleton(&[]) } else { Space::new() };
    drop(v544_3);
    let v544_5: Space = subtract(&(*CONSTANT_0),&(v544_4));
    drop(v544_4);
    let v544_8: Space = if (&(v544_5)).is_empty() { Space::new() } else {
      let v545_6: Path = concat_path(&(*p0),&v543_14_cursor.path()[v543_14_origin..(v543_14_origin + 1)]);
      let mut v545_7 = Space::new();
      let mut v545_7_write = v545_7.write_zipper();
      for v545_7_byte in v543_14_cursor.child_mask().iter() {
        v543_14_cursor.descend_to_existing_byte(v545_7_byte);
        {
        let v546_2: Space = singleton(&v543_14_cursor.path()[(v543_14_origin + 1)..(v543_14_origin + 2)]);
        let v546_3: Space = intersect(&(*CONSTANT_1),&(v546_2));
        let v546_4: Space = if has_head(&(v546_3)) { singleton(&[]) } else { Space::new() };
        drop(v546_3);
        let v546_5: Space = subtract(&(*CONSTANT_0),&(v546_4));
        drop(v546_4);
        let v546_8: Space = if (&(v546_5)).is_empty() { Space::new() } else {
          let v547_6: Path = concat_path(&(v545_6),&v543_14_cursor.path()[(v543_14_origin + 1)..(v543_14_origin + 2)]);
          let mut v547_7 = Space::new();
          let mut v547_7_write = v547_7.write_zipper();
          for v547_7_byte in v543_14_cursor.child_mask().iter() {
            v543_14_cursor.descend_to_existing_byte(v547_7_byte);
            {
            let v548_2: Space = singleton(&v543_14_cursor.path()[(v543_14_origin + 2)..(v543_14_origin + 3)]);
            let v548_3: Space = intersect(&(*CONSTANT_1),&(v548_2));
            let v548_4: Space = if has_head(&(v548_3)) { singleton(&[]) } else { Space::new() };
            drop(v548_3);
            let v548_5: Space = subtract(&(*CONSTANT_0),&(v548_4));
            drop(v548_4);
            let v548_8: Space = if (&(v548_5)).is_empty() { Space::new() } else {
              let v549_6: Path = concat_path(&(v547_6),&v543_14_cursor.path()[(v543_14_origin + 2)..(v543_14_origin + 3)]);
              let v549_7: Space = routine_44(c, &(v549_6), &v543_14_cursor);
              compose(&(v548_5),&(v549_7))
            };
            drop(v548_5);
            let v548_9: Space = intersect(&(*CONSTANT_1),&(v548_2));
            drop(v548_2);
            let v548_10: Space = if has_head(&(v548_9)) { singleton(&[]) } else { Space::new() };
            drop(v548_9);
            let v548_12: Space = if (&(v548_10)).is_empty() { Space::new() } else {
              let v550_6: Path = concat_path(&(v547_6),&v543_14_cursor.path()[(v543_14_origin + 2)..(v543_14_origin + 3)]);
              let v550_11: Space = routine_45(c, &(v550_6), &v543_14_cursor);
              drop(v550_6);
              compose(&(v548_10),&(v550_11))
            };
            drop(v548_10);
            let v548_13: Space = unite(&(v548_8),&(v548_12));
            join_wrapped_into(&mut v547_7_write,&((v548_13).read_zipper()),&[]);
            }
            v543_14_cursor.ascend(1);
          }
          drop(v547_7_write);
          compose(&(v546_5),&(v547_7))
        };
        drop(v546_5);
        let v546_9: Space = intersect(&(*CONSTANT_1),&(v546_2));
        drop(v546_2);
        let v546_10: Space = if has_head(&(v546_9)) { singleton(&[]) } else { Space::new() };
        drop(v546_9);
        let v546_12: Space = if (&(v546_10)).is_empty() { Space::new() } else {
          let v551_6: Path = concat_path(&(v545_6),&v543_14_cursor.path()[(v543_14_origin + 1)..(v543_14_origin + 2)]);
          let mut v551_11 = Space::new();
          let mut v551_11_write = v551_11.write_zipper();
          for v551_11_byte in v543_14_cursor.child_mask().iter() {
            v543_14_cursor.descend_to_existing_byte(v551_11_byte);
            {
            let v552_2: Space = singleton(&v543_14_cursor.path()[(v543_14_origin + 2)..(v543_14_origin + 3)]);
            let v552_3: Space = intersect(&(*CONSTANT_1),&(v552_2));
            let v552_4: Space = if has_head(&(v552_3)) { singleton(&[]) } else { Space::new() };
            drop(v552_3);
            let v552_5: Space = subtract(&(*CONSTANT_0),&(v552_4));
            drop(v552_4);
            let v552_8: Space = if (&(v552_5)).is_empty() { Space::new() } else {
              let v553_6: Path = concat_path(&(v551_6),&v543_14_cursor.path()[(v543_14_origin + 2)..(v543_14_origin + 3)]);
              let v553_7: Space = routine_44(c, &(v553_6), &v543_14_cursor);
              compose(&(v552_5),&(v553_7))
            };
            drop(v552_5);
            let v552_9: Space = intersect(&(*CONSTANT_1),&(v552_2));
            drop(v552_2);
            let v552_10: Space = if has_head(&(v552_9)) { singleton(&[]) } else { Space::new() };
            drop(v552_9);
            let v552_12: Space = if (&(v552_10)).is_empty() { Space::new() } else {
              let v554_6: Path = concat_path(&(v551_6),&v543_14_cursor.path()[(v543_14_origin + 2)..(v543_14_origin + 3)]);
              let v554_11: Space = routine_15(c, &(v554_6), &v543_14_cursor);
              drop(v554_6);
              compose(&(v552_10),&(v554_11))
            };
            drop(v552_10);
            let v552_13: Space = unite(&(v552_8),&(v552_12));
            join_wrapped_into(&mut v551_11_write,&((v552_13).read_zipper()),&[]);
            }
            v543_14_cursor.ascend(1);
          }
          drop(v551_11_write);
          drop(v551_6);
          compose(&(v546_10),&(v551_11))
        };
        drop(v546_10);
        let v546_13: Space = unite(&(v546_8),&(v546_12));
        join_wrapped_into(&mut v545_7_write,&((v546_13).read_zipper()),&[]);
        }
        v543_14_cursor.ascend(1);
      }
      drop(v545_7_write);
      drop(v545_6);
      compose(&(v544_5),&(v545_7))
    };
    drop(v544_5);
    let v544_9: Space = intersect(&(*CONSTANT_1),&(v544_2));
    drop(v544_2);
    let v544_10: Space = if has_head(&(v544_9)) { singleton(&[]) } else { Space::new() };
    drop(v544_9);
    let v544_11: Space = compose(&(v544_10),&v543_14_cursor);
    drop(v544_10);
    let v544_12: Space = unite(&(v544_8),&(v544_11));
    drop(v544_11);
    join_wrapped_into(&mut v543_14_write,&((v544_12).read_zipper()),&[]);
    }
    v543_14_cursor.ascend(1);
  }
  drop(v543_14_cursor);
  drop(v543_14_write);
  (v543_14).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v555_8 = Space::new();
  let mut v555_8_write = v555_8.write_zipper();
  let mut v555_8_cursor = (*s0).read_zipper();
  let v555_8_origin = v555_8_cursor.path().len();
  for v555_8_byte in v555_8_cursor.child_mask().iter() {
    v555_8_cursor.descend_to_existing_byte(v555_8_byte);
    {
    let v556_2: Space = singleton(&v555_8_cursor.path()[v555_8_origin..(v555_8_origin + 1)]);
    let v556_3: Space = intersect(&(*CONSTANT_1),&(v556_2));
    let v556_4: Space = if has_head(&(v556_3)) { singleton(&[]) } else { Space::new() };
    drop(v556_3);
    let v556_5: Space = subtract(&(*CONSTANT_0),&(v556_4));
    drop(v556_4);
    let v556_8: Space = if (&(v556_5)).is_empty() { Space::new() } else {
      let v557_6: Path = concat_path(&(*p0),&v555_8_cursor.path()[v555_8_origin..(v555_8_origin + 1)]);
      let mut v557_7 = Space::new();
      let mut v557_7_write = v557_7.write_zipper();
      for v557_7_byte in v555_8_cursor.child_mask().iter() {
        v555_8_cursor.descend_to_existing_byte(v557_7_byte);
        {
        let v558_2: Space = singleton(&v555_8_cursor.path()[(v555_8_origin + 1)..(v555_8_origin + 2)]);
        let v558_3: Space = intersect(&(*CONSTANT_1),&(v558_2));
        drop(v558_2);
        let v558_4: Space = if has_head(&(v558_3)) { singleton(&[]) } else { Space::new() };
        drop(v558_3);
        let v558_7: Space = if (&(v558_4)).is_empty() { Space::new() } else {
          let v559_5: Path = concat_path(&(v557_6),&v555_8_cursor.path()[(v555_8_origin + 1)..(v555_8_origin + 2)]);
          let mut v559_6 = Space::new();
          let mut v559_6_write = v559_6.write_zipper();
          for v559_6_byte in v555_8_cursor.child_mask().iter() {
            v555_8_cursor.descend_to_existing_byte(v559_6_byte);
            {
            let v560_2: Space = singleton(&v555_8_cursor.path()[(v555_8_origin + 2)..(v555_8_origin + 3)]);
            let v560_3: Space = intersect(&(*CONSTANT_1),&(v560_2));
            drop(v560_2);
            let v560_4: Space = if has_head(&(v560_3)) { singleton(&[]) } else { Space::new() };
            drop(v560_3);
            let v560_7: Space = if (&(v560_4)).is_empty() { Space::new() } else {
              let v561_5: Path = concat_path(&(v559_5),&v555_8_cursor.path()[(v555_8_origin + 2)..(v555_8_origin + 3)]);
              let v561_6: Space = routine_12(c, &(v561_5), &v555_8_cursor);
              drop(v561_5);
              compose(&(v560_4),&(v561_6))
            };
            drop(v560_4);
            join_wrapped_into(&mut v559_6_write,&((v560_7).read_zipper()),&[]);
            }
            v555_8_cursor.ascend(1);
          }
          drop(v559_6_write);
          drop(v559_5);
          compose(&(v558_4),&(v559_6))
        };
        drop(v558_4);
        join_wrapped_into(&mut v557_7_write,&((v558_7).read_zipper()),&[]);
        }
        v555_8_cursor.ascend(1);
      }
      drop(v557_7_write);
      drop(v557_6);
      compose(&(v556_5),&(v557_7))
    };
    drop(v556_5);
    let v556_9: Space = intersect(&(*CONSTANT_1),&(v556_2));
    drop(v556_2);
    let v556_10: Space = if has_head(&(v556_9)) { singleton(&[]) } else { Space::new() };
    drop(v556_9);
    let v556_12: Space = if (&(v556_10)).is_empty() { Space::new() } else {
      let mut v562_11 = Space::new();
      let mut v562_11_write = v562_11.write_zipper();
      for v562_11_byte in v555_8_cursor.child_mask().iter() {
        v555_8_cursor.descend_to_existing_byte(v562_11_byte);
        {
        let v563_2: Space = singleton(&v555_8_cursor.path()[(v555_8_origin + 1)..(v555_8_origin + 2)]);
        let v563_3: Space = intersect(&(*CONSTANT_1),&(v563_2));
        drop(v563_2);
        let v563_4: Space = if has_head(&(v563_3)) { singleton(&[]) } else { Space::new() };
        drop(v563_3);
        let v563_5: Space = compose(&(v563_4),&v555_8_cursor);
        drop(v563_4);
        join_wrapped_into(&mut v562_11_write,&((v563_5).read_zipper()),&[]);
        }
        v555_8_cursor.ascend(1);
      }
      drop(v562_11_write);
      compose(&(v556_10),&(v562_11))
    };
    drop(v556_10);
    let v556_13: Space = unite(&(v556_8),&(v556_12));
    drop(v556_12);
    join_wrapped_into(&mut v555_8_write,&((v556_13).read_zipper()),&[]);
    }
    v555_8_cursor.ascend(1);
  }
  drop(v555_8_cursor);
  drop(v555_8_write);
  (v555_8).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v564_7 = Space::new();
  let mut v564_7_write = v564_7.write_zipper();
  let mut v564_7_cursor = (*s0).read_zipper();
  let v564_7_origin = v564_7_cursor.path().len();
  for v564_7_byte in v564_7_cursor.child_mask().iter() {
    v564_7_cursor.descend_to_existing_byte(v564_7_byte);
    {
    let v565_2: Space = singleton(&v564_7_cursor.path()[v564_7_origin..(v564_7_origin + 1)]);
    let v565_3: Space = intersect(&(*CONSTANT_1),&(v565_2));
    let v565_4: Space = if has_head(&(v565_3)) { singleton(&[]) } else { Space::new() };
    drop(v565_3);
    let v565_5: Space = subtract(&(*CONSTANT_0),&(v565_4));
    drop(v565_4);
    let v565_8: Space = if (&(v565_5)).is_empty() { Space::new() } else {
      let v566_6: Path = concat_path(&(*p0),&v564_7_cursor.path()[v564_7_origin..(v564_7_origin + 1)]);
      let mut v566_7 = Space::new();
      let mut v566_7_write = v566_7.write_zipper();
      for v566_7_byte in v564_7_cursor.child_mask().iter() {
        v564_7_cursor.descend_to_existing_byte(v566_7_byte);
        {
        let v567_2: Space = singleton(&v564_7_cursor.path()[(v564_7_origin + 1)..(v564_7_origin + 2)]);
        let v567_3: Space = intersect(&(*CONSTANT_1),&(v567_2));
        drop(v567_2);
        let v567_4: Space = if has_head(&(v567_3)) { singleton(&[]) } else { Space::new() };
        drop(v567_3);
        let v567_7: Space = if (&(v567_4)).is_empty() { Space::new() } else {
          let v568_5: Path = concat_path(&(v566_6),&v564_7_cursor.path()[(v564_7_origin + 1)..(v564_7_origin + 2)]);
          let mut v568_6 = Space::new();
          let mut v568_6_write = v568_6.write_zipper();
          for v568_6_byte in v564_7_cursor.child_mask().iter() {
            v564_7_cursor.descend_to_existing_byte(v568_6_byte);
            {
            let v569_2: Space = singleton(&v564_7_cursor.path()[(v564_7_origin + 2)..(v564_7_origin + 3)]);
            let v569_3: Space = intersect(&(*CONSTANT_1),&(v569_2));
            drop(v569_2);
            let v569_4: Space = if has_head(&(v569_3)) { singleton(&[]) } else { Space::new() };
            drop(v569_3);
            let v569_7: Space = if (&(v569_4)).is_empty() { Space::new() } else {
              let v570_5: Path = concat_path(&(v568_5),&v564_7_cursor.path()[(v564_7_origin + 2)..(v564_7_origin + 3)]);
              let v570_6: Space = routine_12(c, &(v570_5), &v564_7_cursor);
              drop(v570_5);
              compose(&(v569_4),&(v570_6))
            };
            drop(v569_4);
            join_wrapped_into(&mut v568_6_write,&((v569_7).read_zipper()),&[]);
            }
            v564_7_cursor.ascend(1);
          }
          drop(v568_6_write);
          drop(v568_5);
          compose(&(v567_4),&(v568_6))
        };
        drop(v567_4);
        join_wrapped_into(&mut v566_7_write,&((v567_7).read_zipper()),&[]);
        }
        v564_7_cursor.ascend(1);
      }
      drop(v566_7_write);
      drop(v566_6);
      compose(&(v565_5),&(v566_7))
    };
    drop(v565_5);
    let v565_9: Space = intersect(&(*CONSTANT_1),&(v565_2));
    drop(v565_2);
    let v565_10: Space = if has_head(&(v565_9)) { singleton(&[]) } else { Space::new() };
    drop(v565_9);
    let v565_11: Space = compose(&(v565_10),&v564_7_cursor);
    drop(v565_10);
    let v565_12: Space = unite(&(v565_8),&(v565_11));
    drop(v565_11);
    join_wrapped_into(&mut v564_7_write,&((v565_12).read_zipper()),&[]);
    }
    v564_7_cursor.ascend(1);
  }
  drop(v564_7_cursor);
  drop(v564_7_write);
  (v564_7).clone()
}

fn routine_36(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v571_8 = Space::new();
  let mut v571_8_write = v571_8.write_zipper();
  let mut v571_8_cursor = (*s0).read_zipper();
  let v571_8_origin = v571_8_cursor.path().len();
  for v571_8_byte in v571_8_cursor.child_mask().iter() {
    v571_8_cursor.descend_to_existing_byte(v571_8_byte);
    {
    let v572_2: Space = singleton(&v571_8_cursor.path()[v571_8_origin..(v571_8_origin + 1)]);
    let v572_3: Space = intersect(&(*CONSTANT_1),&(v572_2));
    let v572_4: Space = if has_head(&(v572_3)) { singleton(&[]) } else { Space::new() };
    drop(v572_3);
    let v572_5: Space = subtract(&(*CONSTANT_0),&(v572_4));
    drop(v572_4);
    let v572_8: Space = if (&(v572_5)).is_empty() { Space::new() } else {
      let v573_6: Path = concat_path(&(*p0),&v571_8_cursor.path()[v571_8_origin..(v571_8_origin + 1)]);
      let mut v573_7 = Space::new();
      let mut v573_7_write = v573_7.write_zipper();
      for v573_7_byte in v571_8_cursor.child_mask().iter() {
        v571_8_cursor.descend_to_existing_byte(v573_7_byte);
        {
        let v574_2: Space = singleton(&v571_8_cursor.path()[(v571_8_origin + 1)..(v571_8_origin + 2)]);
        let v574_3: Space = intersect(&(*CONSTANT_1),&(v574_2));
        drop(v574_2);
        let v574_4: Space = if has_head(&(v574_3)) { singleton(&[]) } else { Space::new() };
        drop(v574_3);
        let v574_7: Space = if (&(v574_4)).is_empty() { Space::new() } else {
          let v575_5: Path = concat_path(&(v573_6),&v571_8_cursor.path()[(v571_8_origin + 1)..(v571_8_origin + 2)]);
          let mut v575_6 = Space::new();
          let mut v575_6_write = v575_6.write_zipper();
          for v575_6_byte in v571_8_cursor.child_mask().iter() {
            v571_8_cursor.descend_to_existing_byte(v575_6_byte);
            {
            let v576_2: Space = singleton(&v571_8_cursor.path()[(v571_8_origin + 2)..(v571_8_origin + 3)]);
            let v576_3: Space = intersect(&(*CONSTANT_1),&(v576_2));
            drop(v576_2);
            let v576_4: Space = if has_head(&(v576_3)) { singleton(&[]) } else { Space::new() };
            drop(v576_3);
            let v576_7: Space = if (&(v576_4)).is_empty() { Space::new() } else {
              let v577_5: Path = concat_path(&(v575_5),&v571_8_cursor.path()[(v571_8_origin + 2)..(v571_8_origin + 3)]);
              let v577_6: Space = routine_15(c, &(v577_5), &v571_8_cursor);
              drop(v577_5);
              compose(&(v576_4),&(v577_6))
            };
            drop(v576_4);
            join_wrapped_into(&mut v575_6_write,&((v576_7).read_zipper()),&[]);
            }
            v571_8_cursor.ascend(1);
          }
          drop(v575_6_write);
          drop(v575_5);
          compose(&(v574_4),&(v575_6))
        };
        drop(v574_4);
        join_wrapped_into(&mut v573_7_write,&((v574_7).read_zipper()),&[]);
        }
        v571_8_cursor.ascend(1);
      }
      drop(v573_7_write);
      drop(v573_6);
      compose(&(v572_5),&(v573_7))
    };
    drop(v572_5);
    let v572_9: Space = intersect(&(*CONSTANT_1),&(v572_2));
    drop(v572_2);
    let v572_10: Space = if has_head(&(v572_9)) { singleton(&[]) } else { Space::new() };
    drop(v572_9);
    let v572_12: Space = if (&(v572_10)).is_empty() { Space::new() } else {
      let mut v578_11 = Space::new();
      let mut v578_11_write = v578_11.write_zipper();
      for v578_11_byte in v571_8_cursor.child_mask().iter() {
        v571_8_cursor.descend_to_existing_byte(v578_11_byte);
        {
        let v579_2: Space = singleton(&v571_8_cursor.path()[(v571_8_origin + 1)..(v571_8_origin + 2)]);
        let v579_3: Space = intersect(&(*CONSTANT_1),&(v579_2));
        drop(v579_2);
        let v579_4: Space = if has_head(&(v579_3)) { singleton(&[]) } else { Space::new() };
        drop(v579_3);
        let v579_5: Space = compose(&(v579_4),&v571_8_cursor);
        drop(v579_4);
        join_wrapped_into(&mut v578_11_write,&((v579_5).read_zipper()),&[]);
        }
        v571_8_cursor.ascend(1);
      }
      drop(v578_11_write);
      compose(&(v572_10),&(v578_11))
    };
    drop(v572_10);
    let v572_13: Space = unite(&(v572_8),&(v572_12));
    drop(v572_12);
    join_wrapped_into(&mut v571_8_write,&((v572_13).read_zipper()),&[]);
    }
    v571_8_cursor.ascend(1);
  }
  drop(v571_8_cursor);
  drop(v571_8_write);
  (v571_8).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v580_7 = Space::new();
  let mut v580_7_write = v580_7.write_zipper();
  let mut v580_7_cursor = (*s0).read_zipper();
  let v580_7_origin = v580_7_cursor.path().len();
  for v580_7_byte in v580_7_cursor.child_mask().iter() {
    v580_7_cursor.descend_to_existing_byte(v580_7_byte);
    {
    let v581_2: Space = singleton(&v580_7_cursor.path()[v580_7_origin..(v580_7_origin + 1)]);
    let v581_3: Space = intersect(&(*CONSTANT_1),&(v581_2));
    let v581_4: Space = if has_head(&(v581_3)) { singleton(&[]) } else { Space::new() };
    drop(v581_3);
    let v581_5: Space = subtract(&(*CONSTANT_0),&(v581_4));
    drop(v581_4);
    let v581_8: Space = if (&(v581_5)).is_empty() { Space::new() } else {
      let v582_6: Path = concat_path(&(*p0),&v580_7_cursor.path()[v580_7_origin..(v580_7_origin + 1)]);
      let mut v582_7 = Space::new();
      let mut v582_7_write = v582_7.write_zipper();
      for v582_7_byte in v580_7_cursor.child_mask().iter() {
        v580_7_cursor.descend_to_existing_byte(v582_7_byte);
        {
        let v583_2: Space = singleton(&v580_7_cursor.path()[(v580_7_origin + 1)..(v580_7_origin + 2)]);
        let v583_3: Space = intersect(&(*CONSTANT_1),&(v583_2));
        drop(v583_2);
        let v583_4: Space = if has_head(&(v583_3)) { singleton(&[]) } else { Space::new() };
        drop(v583_3);
        let v583_7: Space = if (&(v583_4)).is_empty() { Space::new() } else {
          let v584_5: Path = concat_path(&(v582_6),&v580_7_cursor.path()[(v580_7_origin + 1)..(v580_7_origin + 2)]);
          let mut v584_6 = Space::new();
          let mut v584_6_write = v584_6.write_zipper();
          for v584_6_byte in v580_7_cursor.child_mask().iter() {
            v580_7_cursor.descend_to_existing_byte(v584_6_byte);
            {
            let v585_2: Space = singleton(&v580_7_cursor.path()[(v580_7_origin + 2)..(v580_7_origin + 3)]);
            let v585_3: Space = intersect(&(*CONSTANT_1),&(v585_2));
            drop(v585_2);
            let v585_4: Space = if has_head(&(v585_3)) { singleton(&[]) } else { Space::new() };
            drop(v585_3);
            let v585_7: Space = if (&(v585_4)).is_empty() { Space::new() } else {
              let v586_5: Path = concat_path(&(v584_5),&v580_7_cursor.path()[(v580_7_origin + 2)..(v580_7_origin + 3)]);
              let v586_6: Space = routine_15(c, &(v586_5), &v580_7_cursor);
              drop(v586_5);
              compose(&(v585_4),&(v586_6))
            };
            drop(v585_4);
            join_wrapped_into(&mut v584_6_write,&((v585_7).read_zipper()),&[]);
            }
            v580_7_cursor.ascend(1);
          }
          drop(v584_6_write);
          drop(v584_5);
          compose(&(v583_4),&(v584_6))
        };
        drop(v583_4);
        join_wrapped_into(&mut v582_7_write,&((v583_7).read_zipper()),&[]);
        }
        v580_7_cursor.ascend(1);
      }
      drop(v582_7_write);
      drop(v582_6);
      compose(&(v581_5),&(v582_7))
    };
    drop(v581_5);
    let v581_9: Space = intersect(&(*CONSTANT_1),&(v581_2));
    drop(v581_2);
    let v581_10: Space = if has_head(&(v581_9)) { singleton(&[]) } else { Space::new() };
    drop(v581_9);
    let v581_11: Space = compose(&(v581_10),&v580_7_cursor);
    drop(v581_10);
    let v581_12: Space = unite(&(v581_8),&(v581_11));
    drop(v581_11);
    join_wrapped_into(&mut v580_7_write,&((v581_12).read_zipper()),&[]);
    }
    v580_7_cursor.ascend(1);
  }
  drop(v580_7_cursor);
  drop(v580_7_write);
  (v580_7).clone()
}

fn routine_38(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v587_4 = Space::new();
  let mut v587_4_write = v587_4.write_zipper();
  let mut v587_4_cursor = (*s0).read_zipper();
  let v587_4_origin = v587_4_cursor.path().len();
  for v587_4_byte in v587_4_cursor.child_mask().iter() {
    v587_4_cursor.descend_to_existing_byte(v587_4_byte);
    {
    let v588_2: Space = singleton(&v587_4_cursor.path()[v587_4_origin..(v587_4_origin + 1)]);
    let v588_3: Space = intersect(&(*CONSTANT_1),&(v588_2));
    drop(v588_2);
    let v588_4: Space = if has_head(&(v588_3)) { singleton(&[]) } else { Space::new() };
    drop(v588_3);
    let v588_6: Space = if (&(v588_4)).is_empty() { Space::new() } else {
      let mut v589_5 = Space::new();
      let mut v589_5_write = v589_5.write_zipper();
      for v589_5_byte in v587_4_cursor.child_mask().iter() {
        v587_4_cursor.descend_to_existing_byte(v589_5_byte);
        {
        let v590_2: Space = singleton(&v587_4_cursor.path()[(v587_4_origin + 1)..(v587_4_origin + 2)]);
        let v590_3: Space = intersect(&(*CONSTANT_1),&(v590_2));
        drop(v590_2);
        let v590_4: Space = if has_head(&(v590_3)) { singleton(&[]) } else { Space::new() };
        drop(v590_3);
        let v590_5: Space = compose(&(v590_4),&v587_4_cursor);
        drop(v590_4);
        join_wrapped_into(&mut v589_5_write,&((v590_5).read_zipper()),&[]);
        }
        v587_4_cursor.ascend(1);
      }
      drop(v589_5_write);
      compose(&(v588_4),&(v589_5))
    };
    drop(v588_4);
    join_wrapped_into(&mut v587_4_write,&((v588_6).read_zipper()),&[]);
    }
    v587_4_cursor.ascend(1);
  }
  drop(v587_4_cursor);
  drop(v587_4_write);
  (v587_4).clone()
}

fn routine_39(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v591_3 = Space::new();
  let mut v591_3_write = v591_3.write_zipper();
  let mut v591_3_cursor = (*s0).read_zipper();
  let v591_3_origin = v591_3_cursor.path().len();
  for v591_3_byte in v591_3_cursor.child_mask().iter() {
    v591_3_cursor.descend_to_existing_byte(v591_3_byte);
    {
    let v592_2: Space = singleton(&v591_3_cursor.path()[v591_3_origin..(v591_3_origin + 1)]);
    let v592_3: Space = intersect(&(*CONSTANT_1),&(v592_2));
    drop(v592_2);
    let v592_4: Space = if has_head(&(v592_3)) { singleton(&[]) } else { Space::new() };
    drop(v592_3);
    let v592_5: Space = compose(&(v592_4),&v591_3_cursor);
    drop(v592_4);
    join_wrapped_into(&mut v591_3_write,&((v592_5).read_zipper()),&[]);
    }
    v591_3_cursor.ascend(1);
  }
  drop(v591_3_cursor);
  drop(v591_3_write);
  (v591_3).clone()
}

fn routine_40(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v593_4 = Space::new();
  let mut v593_4_write = v593_4.write_zipper();
  let mut v593_4_cursor = (*s0).read_zipper();
  let v593_4_origin = v593_4_cursor.path().len();
  for v593_4_byte in v593_4_cursor.child_mask().iter() {
    v593_4_cursor.descend_to_existing_byte(v593_4_byte);
    {
    let v594_2: Space = singleton(&v593_4_cursor.path()[v593_4_origin..(v593_4_origin + 1)]);
    let v594_3: Space = intersect(&(*CONSTANT_1),&(v594_2));
    drop(v594_2);
    let v594_4: Space = if has_head(&(v594_3)) { singleton(&[]) } else { Space::new() };
    drop(v594_3);
    let v594_6: Space = if (&(v594_4)).is_empty() { Space::new() } else {
      let mut v595_5 = Space::new();
      let mut v595_5_write = v595_5.write_zipper();
      for v595_5_byte in v593_4_cursor.child_mask().iter() {
        v593_4_cursor.descend_to_existing_byte(v595_5_byte);
        {
        let v596_2: Space = singleton(&v593_4_cursor.path()[(v593_4_origin + 1)..(v593_4_origin + 2)]);
        let v596_3: Space = intersect(&(*CONSTANT_1),&(v596_2));
        drop(v596_2);
        let v596_4: Space = if has_head(&(v596_3)) { singleton(&[]) } else { Space::new() };
        drop(v596_3);
        let v596_5: Space = compose(&(v596_4),&v593_4_cursor);
        drop(v596_4);
        join_wrapped_into(&mut v595_5_write,&((v596_5).read_zipper()),&[]);
        }
        v593_4_cursor.ascend(1);
      }
      drop(v595_5_write);
      compose(&(v594_4),&(v595_5))
    };
    drop(v594_4);
    join_wrapped_into(&mut v593_4_write,&((v594_6).read_zipper()),&[]);
    }
    v593_4_cursor.ascend(1);
  }
  drop(v593_4_cursor);
  drop(v593_4_write);
  (v593_4).clone()
}

fn routine_41(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v597_3 = Space::new();
  let mut v597_3_write = v597_3.write_zipper();
  let mut v597_3_cursor = (*s0).read_zipper();
  let v597_3_origin = v597_3_cursor.path().len();
  for v597_3_byte in v597_3_cursor.child_mask().iter() {
    v597_3_cursor.descend_to_existing_byte(v597_3_byte);
    {
    let v598_2: Space = singleton(&v597_3_cursor.path()[v597_3_origin..(v597_3_origin + 1)]);
    let v598_3: Space = intersect(&(*CONSTANT_1),&(v598_2));
    drop(v598_2);
    let v598_4: Space = if has_head(&(v598_3)) { singleton(&[]) } else { Space::new() };
    drop(v598_3);
    let v598_5: Space = compose(&(v598_4),&v597_3_cursor);
    drop(v598_4);
    join_wrapped_into(&mut v597_3_write,&((v598_5).read_zipper()),&[]);
    }
    v597_3_cursor.ascend(1);
  }
  drop(v597_3_cursor);
  drop(v597_3_write);
  (v597_3).clone()
}

fn routine_42(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v599_2: Space = Space::new();
  (v599_2).clone()
}

fn routine_43(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v600_3 = Space::new();
  let mut v600_3_write = v600_3.write_zipper();
  let mut v600_3_cursor = (*s0).read_zipper();
  let v600_3_origin = v600_3_cursor.path().len();
  for v600_3_byte in v600_3_cursor.child_mask().iter() {
    v600_3_cursor.descend_to_existing_byte(v600_3_byte);
    {
    let v601_2: Space = singleton(&v600_3_cursor.path()[v600_3_origin..(v600_3_origin + 1)]);
    let v601_3: Space = intersect(&(*CONSTANT_1),&(v601_2));
    drop(v601_2);
    let v601_4: Space = if has_head(&(v601_3)) { singleton(&[]) } else { Space::new() };
    drop(v601_3);
    let v601_5: Space = compose(&(v601_4),&v600_3_cursor);
    drop(v601_4);
    join_wrapped_into(&mut v600_3_write,&((v601_5).read_zipper()),&[]);
    }
    v600_3_cursor.ascend(1);
  }
  drop(v600_3_cursor);
  drop(v600_3_write);
  (v600_3).clone()
}

fn routine_44(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v602_2: Space = Space::new();
  (v602_2).clone()
}

fn routine_45(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v603_3 = Space::new();
  let mut v603_3_write = v603_3.write_zipper();
  let mut v603_3_cursor = (*s0).read_zipper();
  let v603_3_origin = v603_3_cursor.path().len();
  for v603_3_byte in v603_3_cursor.child_mask().iter() {
    v603_3_cursor.descend_to_existing_byte(v603_3_byte);
    {
    let v604_2: Space = singleton(&v603_3_cursor.path()[v603_3_origin..(v603_3_origin + 1)]);
    let v604_3: Space = intersect(&(*CONSTANT_1),&(v604_2));
    drop(v604_2);
    let v604_4: Space = if has_head(&(v604_3)) { singleton(&[]) } else { Space::new() };
    drop(v604_3);
    let v604_5: Space = compose(&(v604_4),&v603_3_cursor);
    drop(v604_4);
    join_wrapped_into(&mut v603_3_write,&((v604_5).read_zipper()),&[]);
    }
    v603_3_cursor.ascend(1);
  }
  drop(v603_3_cursor);
  drop(v603_3_write);
  (v603_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0),e.space(1)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
