#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,65]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,63]));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>, s1: Option<&Space>) -> Space {
  let mut v0_2 = Space::new();
  let mut v0_2_write = v0_2.write_zipper();
  let mut v0_2_cursor = (*s1.expect("unbound native input")).read_zipper();
  let v0_2_origin = v0_2_cursor.path().len();
  for v0_2_byte in v0_2_cursor.child_mask().iter() {
    v0_2_cursor.descend_to_existing_byte(v0_2_byte);
    {
    for v1_2_byte in v0_2_cursor.child_mask().iter() {
      v0_2_cursor.descend_to_existing_byte(v1_2_byte);
      {
      for v2_3_byte in v0_2_cursor.child_mask().iter() {
        v0_2_cursor.descend_to_existing_byte(v2_3_byte);
        {
        for v3_3_byte in v0_2_cursor.child_mask().iter() {
          v0_2_cursor.descend_to_existing_byte(v3_3_byte);
          {
          let v4_3: Space = routine_1(c, &v0_2_cursor.path()[v0_2_origin..(v0_2_origin + 4)], &v0_2_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          join_wrapped_into(&mut v0_2_write,&((v4_3).read_zipper()),&[]);
          }
          v0_2_cursor.ascend(1);
        }
        }
        v0_2_cursor.ascend(1);
      }
      }
      v0_2_cursor.ascend(1);
    }
    }
    v0_2_cursor.ascend(1);
  }
  drop(v0_2_cursor);
  drop(v0_2_write);
  let v0_4: Space = wrap(&(v0_2),&(*CONSTANT_0));
  (v0_4).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v5_8: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_2))),&(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_2)),&(*p0))));
  let mut v5_9 = Space::new();
  let mut v5_9_write = v5_9.write_zipper();
  let mut v5_9_cursor = (v5_8).read_zipper();
  let v5_9_origin = v5_9_cursor.path().len();
  for v5_9_byte in v5_9_cursor.child_mask().iter() {
    v5_9_cursor.descend_to_existing_byte(v5_9_byte);
    {
    for v6_2_byte in v5_9_cursor.child_mask().iter() {
      v5_9_cursor.descend_to_existing_byte(v6_2_byte);
      {
      for v7_2_byte in v5_9_cursor.child_mask().iter() {
        v5_9_cursor.descend_to_existing_byte(v7_2_byte);
        {
        join_tails_into(&mut v5_9_write,&mut v5_9_cursor);
        }
        v5_9_cursor.ascend(1);
      }
      }
      v5_9_cursor.ascend(1);
    }
    }
    v5_9_cursor.ascend(1);
  }
  drop(v5_9_cursor);
  drop(v5_9_write);
  drop(v5_8);
  let v5_10: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_1))),&(v5_9));
  drop(v5_9);
  let mut v5_11 = Space::new();
  let mut v5_11_write = v5_11.write_zipper();
  let mut v5_11_cursor = (v5_10).read_zipper();
  let v5_11_origin = v5_11_cursor.path().len();
  for v5_11_byte in v5_11_cursor.child_mask().iter() {
    v5_11_cursor.descend_to_existing_byte(v5_11_byte);
    {
    for v9_2_byte in v5_11_cursor.child_mask().iter() {
      v5_11_cursor.descend_to_existing_byte(v9_2_byte);
      {
      for v10_2_byte in v5_11_cursor.child_mask().iter() {
        v5_11_cursor.descend_to_existing_byte(v10_2_byte);
        {
        join_tails_into(&mut v5_11_write,&mut v5_11_cursor);
        }
        v5_11_cursor.ascend(1);
      }
      }
      v5_11_cursor.ascend(1);
    }
    }
    v5_11_cursor.ascend(1);
  }
  drop(v5_11_cursor);
  drop(v5_11_write);
  drop(v5_10);
  let v5_12: Space = subtract(&(v5_11),&(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_2)),&(*p0))));
  drop(v5_11);
  let v5_15: Space = intersect(&(v5_12),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))));
  drop(v5_12);
  let v5_16: Space = wrap(&(v5_15),&(*p0));
  drop(v5_15);
  (v5_16).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0),e.space(1)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
