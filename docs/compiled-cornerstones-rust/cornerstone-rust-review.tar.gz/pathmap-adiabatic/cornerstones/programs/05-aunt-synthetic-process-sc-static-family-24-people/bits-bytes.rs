#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,1,0,0,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("36 15 0 0 0 0 0 1 1 0 0 1 0 0 0 1 1 14 0 0 0 0 0 1 1 1 0 0 1 0 1 1 13 0 0 0 0 1 1 0 0 0 0 0 1 1 13 0 0 0 0 1 1 1 0 0 0 0 1 1 15 0 0 0 1 0 1 1 0 0 1 0 0 0 1 1 15 0 0 0 1 0 1 1 0 1 0 0 0 0 1 1 11 0 0 0 1 1 0 0 1 0 1 1 11 0 0 0 1 1 0 1 0 0 1 1 15 0 0 1 0 0 1 1 0 0 0 0 0 0 1 1 15 0 0 1 0 0 1 1 1 0 0 0 0 0 1 1 13 0 0 1 0 1 1 0 0 1 0 0 1 1 13 0 0 1 0 1 1 1 0 1 0 0 1 1 10 0 0 1 1 0 0 0 0 1 1 10 0 0 1 1 1 0 0 0 1 1 15 0 1 0 0 0 1 1 0 0 0 0 0 0 1 1 14 0 1 0 0 0 1 1 0 1 0 1 0 1 1 13 0 1 0 0 1 1 0 0 1 0 0 1 1 13 0 1 0 0 1 1 0 1 0 0 0 1 1 12 0 1 0 1 1 0 0 0 0 0 1 1 12 0 1 0 1 1 0 0 0 1 0 1 1 9 0 1 1 0 0 0 0 1 1 8 0 1 1 0 1 0 1 1 14 1 0 0 0 0 1 1 0 1 0 1 0 1 1 14 1 0 0 0 0 1 1 1 0 0 1 0 1 1 13 1 0 0 0 1 1 0 1 0 0 0 1 1 13 1 0 0 0 1 1 1 0 0 0 0 1 1 11 1 0 0 1 1 0 0 1 0 1 1 11 1 0 0 1 1 1 0 1 0 1 1 15 1 0 1 0 0 1 1 0 1 0 0 0 0 1 1 15 1 0 1 0 0 1 1 1 0 0 0 0 0 1 1 13 1 0 1 0 1 1 0 0 0 1 0 1 1 13 1 0 1 0 1 1 1 0 1 0 0 1 1 10 1 0 1 1 0 1 0 0 1 1 10 1 0 1 1 1 0 0 0 1 1 7 1 1 0 1 0 1 1 8 1 1 1 0 1 0 1 1"));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("36 15 0 0 0 0 0 0 1 1 0 0 1 0 0 1 1 15 0 0 0 0 0 0 1 1 0 1 0 0 0 1 1 13 0 0 0 0 0 1 1 0 0 0 0 1 1 12 0 0 0 0 0 1 1 0 1 0 1 1 10 0 0 0 0 1 1 0 0 1 1 9 0 0 0 0 1 1 0 1 1 12 0 0 0 1 0 1 1 0 1 0 1 1 13 0 0 0 1 0 1 1 1 0 1 0 1 1 15 0 0 1 0 0 0 1 1 0 0 0 0 0 1 1 15 0 0 1 0 0 0 1 1 0 0 0 1 0 1 1 13 0 0 1 0 0 1 1 0 0 1 0 1 1 13 0 0 1 0 0 1 1 0 1 0 0 1 1 11 0 0 1 0 1 1 0 0 0 1 1 11 0 0 1 0 1 1 1 0 0 1 1 15 0 1 0 0 0 0 1 1 0 0 0 1 0 1 1 15 0 1 0 0 0 0 1 1 1 0 1 0 0 1 1 13 0 1 0 0 0 1 1 0 1 0 0 1 1 13 0 1 0 0 0 1 1 1 0 0 0 1 1 11 0 1 0 0 1 1 0 0 0 1 1 10 0 1 0 0 1 1 1 0 1 1 14 0 1 0 1 0 1 1 0 1 0 0 0 1 1 14 0 1 0 1 0 1 1 1 0 0 0 0 1 1 8 0 1 0 1 1 0 1 1 7 0 1 0 1 1 1 1 15 1 0 0 0 0 0 1 1 0 0 1 0 0 1 1 15 1 0 0 0 0 0 1 1 1 0 1 0 0 1 1 13 1 0 0 0 0 1 1 0 0 0 0 1 1 13 1 0 0 0 0 1 1 1 0 0 0 1 1 10 1 0 0 0 1 1 0 0 1 1 10 1 0 0 0 1 1 1 0 1 1 14 1 0 0 1 0 1 1 0 0 0 0 0 1 1 14 1 0 0 1 0 1 1 1 0 0 0 0 1 1 13 1 0 1 0 0 1 1 0 0 1 0 1 1 13 1 0 1 0 0 1 1 1 0 1 0 1 1 11 1 0 1 0 1 1 1 0 0 1 1 8 1 0 1 0 1 1 1 1"));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("12 8 0 0 0 0 0 0 1 1 7 0 0 0 0 0 1 1 5 0 0 0 1 1 6 0 0 1 0 1 1 4 0 0 1 1 8 0 1 0 0 0 0 1 1 7 0 1 0 0 0 1 1 5 0 1 0 1 1 6 1 0 0 0 1 1 7 1 0 0 1 0 1 1 7 1 0 1 0 0 1 1 2 1 1"));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_10 = Space::new();
  let mut v0_10_write = v0_10.write_zipper();
  let mut v0_10_cursor = (*s0.expect("unbound native input")).read_zipper();
  let v0_10_origin = v0_10_cursor.path().len();
  for v0_10_byte in v0_10_cursor.child_mask().iter() {
    v0_10_cursor.descend_to_existing_byte(v0_10_byte);
    {
    let v1_2: Space = singleton(&v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 1)]);
    let v1_3: Space = intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (&(v1_5)).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_write = v2_6.write_zipper();
      for v2_6_byte in v0_10_cursor.child_mask().iter() {
        v0_10_cursor.descend_to_existing_byte(v2_6_byte);
        {
        let v3_2: Space = singleton(&v0_10_cursor.path()[(v0_10_origin + 1)..(v0_10_origin + 2)]);
        let v3_3: Space = intersect(&(*CONSTANT_1),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_0),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (&(v3_5)).is_empty() { Space::new() } else {
          let v4_7: Space = routine_1(c, &v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 2)], &v0_10_cursor);
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_1),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (&(v3_10)).is_empty() { Space::new() } else {
          let v5_11: Space = routine_2(c, &v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 2)], &v0_10_cursor);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        join_wrapped_into(&mut v2_6_write,&((v3_13).read_zipper()),&[]);
        }
        v0_10_cursor.ascend(1);
      }
      drop(v2_6_write);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (&(v1_9)).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_write = v6_10.write_zipper();
      for v6_10_byte in v0_10_cursor.child_mask().iter() {
        v0_10_cursor.descend_to_existing_byte(v6_10_byte);
        {
        let v7_2: Space = singleton(&v0_10_cursor.path()[(v0_10_origin + 1)..(v0_10_origin + 2)]);
        let v7_3: Space = intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (&(v7_5)).is_empty() { Space::new() } else {
          let v8_7: Space = routine_1(c, &v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 2)], &v0_10_cursor);
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (&(v7_10)).is_empty() { Space::new() } else {
          let v9_11: Space = routine_3(c, &v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 2)], &v0_10_cursor);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        join_wrapped_into(&mut v6_10_write,&((v7_13).read_zipper()),&[]);
        }
        v0_10_cursor.ascend(1);
      }
      drop(v6_10_write);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    join_wrapped_into(&mut v0_10_write,&((v1_12).read_zipper()),&[]);
    }
    v0_10_cursor.ascend(1);
  }
  drop(v0_10_cursor);
  drop(v0_10_write);
  let v0_12: Space = wrap(&(v0_10),&(*CONSTANT_2));
  (v0_12).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v10_33 = Space::new();
  let mut v10_33_write = v10_33.write_zipper();
  let mut v10_33_cursor = (*s0).read_zipper();
  let v10_33_origin = v10_33_cursor.path().len();
  for v10_33_byte in v10_33_cursor.child_mask().iter() {
    v10_33_cursor.descend_to_existing_byte(v10_33_byte);
    {
    let v11_2: Space = singleton(&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]);
    let v11_3: Space = intersect(&(*CONSTANT_1),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (&(v11_5)).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]);
      let mut v12_7 = Space::new();
      let mut v12_7_write = v12_7.write_zipper();
      for v12_7_byte in v10_33_cursor.child_mask().iter() {
        v10_33_cursor.descend_to_existing_byte(v12_7_byte);
        {
        let v13_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
        let v13_3: Space = intersect(&(*CONSTANT_1),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_0),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (&(v13_5)).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v12_6),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
          let mut v14_7 = Space::new();
          let mut v14_7_write = v14_7.write_zipper();
          for v14_7_byte in v10_33_cursor.child_mask().iter() {
            v10_33_cursor.descend_to_existing_byte(v14_7_byte);
            {
            let v15_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
            let v15_3: Space = intersect(&(*CONSTANT_1),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (&(v15_5)).is_empty() { Space::new() } else {
              let v16_6: Path = concat_path(&(v14_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v16_7: Space = routine_4(c, &(v16_6), &v10_33_cursor);
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_1),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (&(v15_10)).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v14_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v17_11: Space = routine_5(c, &(v17_6), &v10_33_cursor);
              drop(v17_6);
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            join_wrapped_into(&mut v14_7_write,&((v15_13).read_zipper()),&[]);
            }
            v10_33_cursor.ascend(1);
          }
          drop(v14_7_write);
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_1),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (&(v13_10)).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v12_6),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
          let mut v18_11 = Space::new();
          let mut v18_11_write = v18_11.write_zipper();
          for v18_11_byte in v10_33_cursor.child_mask().iter() {
            v10_33_cursor.descend_to_existing_byte(v18_11_byte);
            {
            let v19_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
            let v19_3: Space = intersect(&(*CONSTANT_1),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
            drop(v19_4);
            let v19_8: Space = if (&(v19_5)).is_empty() { Space::new() } else {
              let v20_6: Path = concat_path(&(v18_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v20_7: Space = routine_4(c, &(v20_6), &v10_33_cursor);
              compose(&(v19_5),&(v20_7))
            };
            drop(v19_5);
            let v19_9: Space = intersect(&(*CONSTANT_1),&(v19_2));
            drop(v19_2);
            let v19_10: Space = if has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
            drop(v19_9);
            let v19_12: Space = if (&(v19_10)).is_empty() { Space::new() } else {
              let v21_6: Path = concat_path(&(v18_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v21_11: Space = routine_3(c, &(v21_6), &v10_33_cursor);
              drop(v21_6);
              compose(&(v19_10),&(v21_11))
            };
            drop(v19_10);
            let v19_13: Space = unite(&(v19_8),&(v19_12));
            join_wrapped_into(&mut v18_11_write,&((v19_13).read_zipper()),&[]);
            }
            v10_33_cursor.ascend(1);
          }
          drop(v18_11_write);
          drop(v18_6);
          compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        join_wrapped_into(&mut v12_7_write,&((v13_13).read_zipper()),&[]);
        }
        v10_33_cursor.ascend(1);
      }
      drop(v12_7_write);
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_1),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_14: Space = if (&(v11_10)).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]);
      let mut v22_13 = Space::new();
      let mut v22_13_write = v22_13.write_zipper();
      for v22_13_byte in v10_33_cursor.child_mask().iter() {
        v10_33_cursor.descend_to_existing_byte(v22_13_byte);
        {
        let v23_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
        let v23_3: Space = intersect(&(*CONSTANT_1),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_0),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (&(v23_5)).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v22_6),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
          let mut v24_7 = Space::new();
          let mut v24_7_write = v24_7.write_zipper();
          for v24_7_byte in v10_33_cursor.child_mask().iter() {
            v10_33_cursor.descend_to_existing_byte(v24_7_byte);
            {
            let v25_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
            let v25_3: Space = intersect(&(*CONSTANT_1),&(v25_2));
            let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
            drop(v25_3);
            let v25_5: Space = subtract(&(*CONSTANT_0),&(v25_4));
            drop(v25_4);
            let v25_8: Space = if (&(v25_5)).is_empty() { Space::new() } else {
              let v26_6: Path = concat_path(&(v24_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v26_7: Space = routine_4(c, &(v26_6), &v10_33_cursor);
              compose(&(v25_5),&(v26_7))
            };
            drop(v25_5);
            let v25_9: Space = intersect(&(*CONSTANT_1),&(v25_2));
            drop(v25_2);
            let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
            drop(v25_9);
            let v25_12: Space = if (&(v25_10)).is_empty() { Space::new() } else {
              let v27_6: Path = concat_path(&(v24_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v27_11: Space = routine_5(c, &(v27_6), &v10_33_cursor);
              drop(v27_6);
              compose(&(v25_10),&(v27_11))
            };
            drop(v25_10);
            let v25_13: Space = unite(&(v25_8),&(v25_12));
            join_wrapped_into(&mut v24_7_write,&((v25_13).read_zipper()),&[]);
            }
            v10_33_cursor.ascend(1);
          }
          drop(v24_7_write);
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_1),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_19: Space = if (&(v23_10)).is_empty() { Space::new() } else {
          let v28_12: Space = restrict_to(&(*CONSTANT_4),&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)])));
          let mut v28_13 = Space::new();
          let mut v28_13_write = v28_13.write_zipper();
          let mut v28_13_cursor = (v28_12).read_zipper();
          let v28_13_origin = v28_13_cursor.path().len();
          for v28_13_byte in v28_13_cursor.child_mask().iter() {
            v28_13_cursor.descend_to_existing_byte(v28_13_byte);
            {
            let v29_2: Space = singleton(&v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)]);
            let v29_3: Space = intersect(&(*CONSTANT_1),&(v29_2));
            let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
            drop(v29_3);
            let v29_5: Space = subtract(&(*CONSTANT_0),&(v29_4));
            drop(v29_4);
            let v29_7: Space = if (&(v29_5)).is_empty() { Space::new() } else {
              let v30_6: Space = routine_6(c, &v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)], &v28_13_cursor);
              compose(&(v29_5),&(v30_6))
            };
            drop(v29_5);
            let v29_8: Space = intersect(&(*CONSTANT_1),&(v29_2));
            drop(v29_2);
            let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
            drop(v29_8);
            let v29_11: Space = if (&(v29_9)).is_empty() { Space::new() } else {
              let v31_10: Space = routine_7(c, &v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)], &v28_13_cursor);
              compose(&(v29_9),&(v31_10))
            };
            drop(v29_9);
            let v29_12: Space = unite(&(v29_7),&(v29_11));
            join_wrapped_into(&mut v28_13_write,&((v29_12).read_zipper()),&[]);
            }
            v28_13_cursor.ascend(1);
          }
          drop(v28_13_cursor);
          drop(v28_13_write);
          drop(v28_12);
          let v28_14: Space = restrict_to(&(*CONSTANT_3),&(v28_13));
          let mut v28_15 = Space::new();
          let mut v28_15_write = v28_15.write_zipper();
          let mut v28_15_cursor = (v28_14).read_zipper();
          let v28_15_origin = v28_15_cursor.path().len();
          for v28_15_byte in v28_15_cursor.child_mask().iter() {
            v28_15_cursor.descend_to_existing_byte(v28_15_byte);
            {
            let v32_2: Space = singleton(&v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)]);
            let v32_3: Space = intersect(&(*CONSTANT_1),&(v32_2));
            let v32_4: Space = if has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
            drop(v32_3);
            let v32_5: Space = subtract(&(*CONSTANT_0),&(v32_4));
            drop(v32_4);
            let v32_7: Space = if (&(v32_5)).is_empty() { Space::new() } else {
              let v33_6: Space = routine_8(c, &v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)], &v28_15_cursor);
              compose(&(v32_5),&(v33_6))
            };
            drop(v32_5);
            let v32_8: Space = intersect(&(*CONSTANT_1),&(v32_2));
            drop(v32_2);
            let v32_9: Space = if has_head(&(v32_8)) { singleton(&[]) } else { Space::new() };
            drop(v32_8);
            let v32_11: Space = if (&(v32_9)).is_empty() { Space::new() } else {
              let v34_10: Space = routine_9(c, &v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)], &v28_15_cursor);
              compose(&(v32_9),&(v34_10))
            };
            drop(v32_9);
            let v32_12: Space = unite(&(v32_7),&(v32_11));
            join_wrapped_into(&mut v28_15_write,&((v32_12).read_zipper()),&[]);
            }
            v28_15_cursor.ascend(1);
          }
          drop(v28_15_cursor);
          drop(v28_15_write);
          let v28_17: Space = subtract(&(v28_15),&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)])));
          let v28_18: Space = intersect(&(v28_17),&(*CONSTANT_5));
          compose(&(v23_10),&(v28_18))
        };
        drop(v23_10);
        let v35_6: Path = concat_path(&(v22_6),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
        let v23_20: Space = wrap(&(v23_19),&(v35_6));
        let v23_21: Space = unite(&(v23_8),&(v23_20));
        join_wrapped_into(&mut v22_13_write,&((v23_21).read_zipper()),&[]);
        }
        v10_33_cursor.ascend(1);
      }
      drop(v22_13_write);
      drop(v22_6);
      compose(&(v11_10),&(v22_13))
    };
    drop(v11_10);
    let v11_15: Space = unite(&(v11_8),&(v11_14));
    join_wrapped_into(&mut v10_33_write,&((v11_15).read_zipper()),&[]);
    }
    v10_33_cursor.ascend(1);
  }
  drop(v10_33_cursor);
  drop(v10_33_write);
  (v10_33).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v36_39 = Space::new();
  let mut v36_39_write = v36_39.write_zipper();
  let mut v36_39_cursor = (*s0).read_zipper();
  let v36_39_origin = v36_39_cursor.path().len();
  for v36_39_byte in v36_39_cursor.child_mask().iter() {
    v36_39_cursor.descend_to_existing_byte(v36_39_byte);
    {
    let v37_2: Space = singleton(&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)]);
    let v37_3: Space = intersect(&(*CONSTANT_1),&(v37_2));
    let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
    drop(v37_3);
    let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
    drop(v37_4);
    let v37_8: Space = if (&(v37_5)).is_empty() { Space::new() } else {
      let v38_6: Path = concat_path(&(*p0),&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)]);
      let mut v38_7 = Space::new();
      let mut v38_7_write = v38_7.write_zipper();
      for v38_7_byte in v36_39_cursor.child_mask().iter() {
        v36_39_cursor.descend_to_existing_byte(v38_7_byte);
        {
        let v39_2: Space = singleton(&v36_39_cursor.path()[(v36_39_origin + 1)..(v36_39_origin + 2)]);
        let v39_3: Space = intersect(&(*CONSTANT_1),&(v39_2));
        let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_8: Space = if (&(v39_5)).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v38_6),&v36_39_cursor.path()[(v36_39_origin + 1)..(v36_39_origin + 2)]);
          let mut v40_7 = Space::new();
          let mut v40_7_write = v40_7.write_zipper();
          for v40_7_byte in v36_39_cursor.child_mask().iter() {
            v36_39_cursor.descend_to_existing_byte(v40_7_byte);
            {
            let v41_2: Space = singleton(&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
            let v41_3: Space = intersect(&(*CONSTANT_1),&(v41_2));
            let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
            drop(v41_4);
            let v41_8: Space = if (&(v41_5)).is_empty() { Space::new() } else {
              let v42_6: Path = concat_path(&(v40_6),&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
              let v42_7: Space = routine_4(c, &(v42_6), &v36_39_cursor);
              compose(&(v41_5),&(v42_7))
            };
            drop(v41_5);
            let v41_9: Space = intersect(&(*CONSTANT_1),&(v41_2));
            drop(v41_2);
            let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
            drop(v41_9);
            let v41_12: Space = if (&(v41_10)).is_empty() { Space::new() } else {
              let v43_6: Path = concat_path(&(v40_6),&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
              let v43_11: Space = routine_5(c, &(v43_6), &v36_39_cursor);
              drop(v43_6);
              compose(&(v41_10),&(v43_11))
            };
            drop(v41_10);
            let v41_13: Space = unite(&(v41_8),&(v41_12));
            join_wrapped_into(&mut v40_7_write,&((v41_13).read_zipper()),&[]);
            }
            v36_39_cursor.ascend(1);
          }
          drop(v40_7_write);
          compose(&(v39_5),&(v40_7))
        };
        drop(v39_5);
        let v39_9: Space = intersect(&(*CONSTANT_1),&(v39_2));
        drop(v39_2);
        let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
        drop(v39_9);
        let v39_12: Space = if (&(v39_10)).is_empty() { Space::new() } else {
          let v44_6: Path = concat_path(&(v38_6),&v36_39_cursor.path()[(v36_39_origin + 1)..(v36_39_origin + 2)]);
          let mut v44_11 = Space::new();
          let mut v44_11_write = v44_11.write_zipper();
          for v44_11_byte in v36_39_cursor.child_mask().iter() {
            v36_39_cursor.descend_to_existing_byte(v44_11_byte);
            {
            let v45_2: Space = singleton(&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
            let v45_3: Space = intersect(&(*CONSTANT_1),&(v45_2));
            let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
            drop(v45_3);
            let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
            drop(v45_4);
            let v45_8: Space = if (&(v45_5)).is_empty() { Space::new() } else {
              let v46_6: Path = concat_path(&(v44_6),&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
              let v46_7: Space = routine_4(c, &(v46_6), &v36_39_cursor);
              compose(&(v45_5),&(v46_7))
            };
            drop(v45_5);
            let v45_9: Space = intersect(&(*CONSTANT_1),&(v45_2));
            drop(v45_2);
            let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
            drop(v45_9);
            let v45_12: Space = if (&(v45_10)).is_empty() { Space::new() } else {
              let v47_6: Path = concat_path(&(v44_6),&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
              let v47_11: Space = routine_3(c, &(v47_6), &v36_39_cursor);
              drop(v47_6);
              compose(&(v45_10),&(v47_11))
            };
            drop(v45_10);
            let v45_13: Space = unite(&(v45_8),&(v45_12));
            join_wrapped_into(&mut v44_11_write,&((v45_13).read_zipper()),&[]);
            }
            v36_39_cursor.ascend(1);
          }
          drop(v44_11_write);
          drop(v44_6);
          compose(&(v39_10),&(v44_11))
        };
        drop(v39_10);
        let v39_13: Space = unite(&(v39_8),&(v39_12));
        join_wrapped_into(&mut v38_7_write,&((v39_13).read_zipper()),&[]);
        }
        v36_39_cursor.ascend(1);
      }
      drop(v38_7_write);
      compose(&(v37_5),&(v38_7))
    };
    drop(v37_5);
    let v37_9: Space = intersect(&(*CONSTANT_1),&(v37_2));
    drop(v37_2);
    let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
    drop(v37_9);
    let v37_19: Space = if (&(v37_10)).is_empty() { Space::new() } else {
      let v48_12: Space = restrict_to(&(*CONSTANT_4),&(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)])));
      let mut v48_13 = Space::new();
      let mut v48_13_write = v48_13.write_zipper();
      let mut v48_13_cursor = (v48_12).read_zipper();
      let v48_13_origin = v48_13_cursor.path().len();
      for v48_13_byte in v48_13_cursor.child_mask().iter() {
        v48_13_cursor.descend_to_existing_byte(v48_13_byte);
        {
        let v49_2: Space = singleton(&v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 1)]);
        let v49_3: Space = intersect(&(*CONSTANT_1),&(v49_2));
        let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
        drop(v49_3);
        let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
        drop(v49_4);
        let v49_7: Space = if (&(v49_5)).is_empty() { Space::new() } else {
          let mut v50_6 = Space::new();
          let mut v50_6_write = v50_6.write_zipper();
          for v50_6_byte in v48_13_cursor.child_mask().iter() {
            v48_13_cursor.descend_to_existing_byte(v50_6_byte);
            {
            let v51_2: Space = singleton(&v48_13_cursor.path()[(v48_13_origin + 1)..(v48_13_origin + 2)]);
            let v51_3: Space = intersect(&(*CONSTANT_1),&(v51_2));
            let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
            drop(v51_3);
            let v51_5: Space = subtract(&(*CONSTANT_0),&(v51_4));
            drop(v51_4);
            let v51_8: Space = if (&(v51_5)).is_empty() { Space::new() } else {
              let v52_7: Space = routine_10(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v51_5),&(v52_7))
            };
            drop(v51_5);
            let v51_9: Space = intersect(&(*CONSTANT_1),&(v51_2));
            drop(v51_2);
            let v51_10: Space = if has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
            drop(v51_9);
            let v51_12: Space = if (&(v51_10)).is_empty() { Space::new() } else {
              let v53_11: Space = routine_11(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v51_10),&(v53_11))
            };
            drop(v51_10);
            let v51_13: Space = unite(&(v51_8),&(v51_12));
            join_wrapped_into(&mut v50_6_write,&((v51_13).read_zipper()),&[]);
            }
            v48_13_cursor.ascend(1);
          }
          drop(v50_6_write);
          compose(&(v49_5),&(v50_6))
        };
        drop(v49_5);
        let v49_8: Space = intersect(&(*CONSTANT_1),&(v49_2));
        drop(v49_2);
        let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
        drop(v49_8);
        let v49_11: Space = if (&(v49_9)).is_empty() { Space::new() } else {
          let mut v54_10 = Space::new();
          let mut v54_10_write = v54_10.write_zipper();
          for v54_10_byte in v48_13_cursor.child_mask().iter() {
            v48_13_cursor.descend_to_existing_byte(v54_10_byte);
            {
            let v55_2: Space = singleton(&v48_13_cursor.path()[(v48_13_origin + 1)..(v48_13_origin + 2)]);
            let v55_3: Space = intersect(&(*CONSTANT_1),&(v55_2));
            let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
            drop(v55_3);
            let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
            drop(v55_4);
            let v55_8: Space = if (&(v55_5)).is_empty() { Space::new() } else {
              let v56_7: Space = routine_10(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v55_5),&(v56_7))
            };
            drop(v55_5);
            let v55_9: Space = intersect(&(*CONSTANT_1),&(v55_2));
            drop(v55_2);
            let v55_10: Space = if has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
            drop(v55_9);
            let v55_12: Space = if (&(v55_10)).is_empty() { Space::new() } else {
              let v57_11: Space = routine_12(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v55_10),&(v57_11))
            };
            drop(v55_10);
            let v55_13: Space = unite(&(v55_8),&(v55_12));
            join_wrapped_into(&mut v54_10_write,&((v55_13).read_zipper()),&[]);
            }
            v48_13_cursor.ascend(1);
          }
          drop(v54_10_write);
          compose(&(v49_9),&(v54_10))
        };
        drop(v49_9);
        let v49_12: Space = unite(&(v49_7),&(v49_11));
        join_wrapped_into(&mut v48_13_write,&((v49_12).read_zipper()),&[]);
        }
        v48_13_cursor.ascend(1);
      }
      drop(v48_13_cursor);
      drop(v48_13_write);
      drop(v48_12);
      let v48_14: Space = restrict_to(&(*CONSTANT_3),&(v48_13));
      let mut v48_15 = Space::new();
      let mut v48_15_write = v48_15.write_zipper();
      let mut v48_15_cursor = (v48_14).read_zipper();
      let v48_15_origin = v48_15_cursor.path().len();
      for v48_15_byte in v48_15_cursor.child_mask().iter() {
        v48_15_cursor.descend_to_existing_byte(v48_15_byte);
        {
        let v58_2: Space = singleton(&v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 1)]);
        let v58_3: Space = intersect(&(*CONSTANT_1),&(v58_2));
        let v58_4: Space = if has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
        drop(v58_3);
        let v58_5: Space = subtract(&(*CONSTANT_0),&(v58_4));
        drop(v58_4);
        let v58_7: Space = if (&(v58_5)).is_empty() { Space::new() } else {
          let mut v59_6 = Space::new();
          let mut v59_6_write = v59_6.write_zipper();
          for v59_6_byte in v48_15_cursor.child_mask().iter() {
            v48_15_cursor.descend_to_existing_byte(v59_6_byte);
            {
            let v60_2: Space = singleton(&v48_15_cursor.path()[(v48_15_origin + 1)..(v48_15_origin + 2)]);
            let v60_3: Space = intersect(&(*CONSTANT_1),&(v60_2));
            let v60_4: Space = if has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
            drop(v60_3);
            let v60_5: Space = subtract(&(*CONSTANT_0),&(v60_4));
            drop(v60_4);
            let v60_8: Space = if (&(v60_5)).is_empty() { Space::new() } else {
              let v61_7: Space = routine_13(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v60_5),&(v61_7))
            };
            drop(v60_5);
            let v60_9: Space = intersect(&(*CONSTANT_1),&(v60_2));
            drop(v60_2);
            let v60_10: Space = if has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
            drop(v60_9);
            let v60_12: Space = if (&(v60_10)).is_empty() { Space::new() } else {
              let v62_11: Space = routine_14(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v60_10),&(v62_11))
            };
            drop(v60_10);
            let v60_13: Space = unite(&(v60_8),&(v60_12));
            join_wrapped_into(&mut v59_6_write,&((v60_13).read_zipper()),&[]);
            }
            v48_15_cursor.ascend(1);
          }
          drop(v59_6_write);
          compose(&(v58_5),&(v59_6))
        };
        drop(v58_5);
        let v58_8: Space = intersect(&(*CONSTANT_1),&(v58_2));
        drop(v58_2);
        let v58_9: Space = if has_head(&(v58_8)) { singleton(&[]) } else { Space::new() };
        drop(v58_8);
        let v58_11: Space = if (&(v58_9)).is_empty() { Space::new() } else {
          let mut v63_10 = Space::new();
          let mut v63_10_write = v63_10.write_zipper();
          for v63_10_byte in v48_15_cursor.child_mask().iter() {
            v48_15_cursor.descend_to_existing_byte(v63_10_byte);
            {
            let v64_2: Space = singleton(&v48_15_cursor.path()[(v48_15_origin + 1)..(v48_15_origin + 2)]);
            let v64_3: Space = intersect(&(*CONSTANT_1),&(v64_2));
            let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
            drop(v64_3);
            let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
            drop(v64_4);
            let v64_8: Space = if (&(v64_5)).is_empty() { Space::new() } else {
              let v65_7: Space = routine_13(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v64_5),&(v65_7))
            };
            drop(v64_5);
            let v64_9: Space = intersect(&(*CONSTANT_1),&(v64_2));
            drop(v64_2);
            let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
            drop(v64_9);
            let v64_12: Space = if (&(v64_10)).is_empty() { Space::new() } else {
              let v66_11: Space = routine_15(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v64_10),&(v66_11))
            };
            drop(v64_10);
            let v64_13: Space = unite(&(v64_8),&(v64_12));
            join_wrapped_into(&mut v63_10_write,&((v64_13).read_zipper()),&[]);
            }
            v48_15_cursor.ascend(1);
          }
          drop(v63_10_write);
          compose(&(v58_9),&(v63_10))
        };
        drop(v58_9);
        let v58_12: Space = unite(&(v58_7),&(v58_11));
        join_wrapped_into(&mut v48_15_write,&((v58_12).read_zipper()),&[]);
        }
        v48_15_cursor.ascend(1);
      }
      drop(v48_15_cursor);
      drop(v48_15_write);
      let v48_17: Space = subtract(&(v48_15),&(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)])));
      let v48_18: Space = intersect(&(v48_17),&(*CONSTANT_5));
      compose(&(v37_10),&(v48_18))
    };
    drop(v37_10);
    let v67_6: Path = concat_path(&(*p0),&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)]);
    let v37_20: Space = wrap(&(v37_19),&(v67_6));
    let v37_21: Space = unite(&(v37_8),&(v37_20));
    join_wrapped_into(&mut v36_39_write,&((v37_21).read_zipper()),&[]);
    }
    v36_39_cursor.ascend(1);
  }
  drop(v36_39_cursor);
  drop(v36_39_write);
  (v36_39).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v68_6: Space = restrict_to(&(*CONSTANT_4),&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0))));
  let mut v68_25 = Space::new();
  let mut v68_25_write = v68_25.write_zipper();
  let mut v68_25_cursor = (v68_6).read_zipper();
  let v68_25_origin = v68_25_cursor.path().len();
  for v68_25_byte in v68_25_cursor.child_mask().iter() {
    v68_25_cursor.descend_to_existing_byte(v68_25_byte);
    {
    let v69_2: Space = singleton(&v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 1)]);
    let v69_3: Space = intersect(&(*CONSTANT_1),&(v69_2));
    let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
    drop(v69_3);
    let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
    drop(v69_4);
    let v69_7: Space = if (&(v69_5)).is_empty() { Space::new() } else {
      let mut v70_6 = Space::new();
      let mut v70_6_write = v70_6.write_zipper();
      for v70_6_byte in v68_25_cursor.child_mask().iter() {
        v68_25_cursor.descend_to_existing_byte(v70_6_byte);
        {
        let v71_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 1)..(v68_25_origin + 2)]);
        let v71_3: Space = intersect(&(*CONSTANT_1),&(v71_2));
        let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
        drop(v71_3);
        let v71_5: Space = subtract(&(*CONSTANT_0),&(v71_4));
        drop(v71_4);
        let v71_8: Space = if (&(v71_5)).is_empty() { Space::new() } else {
          let mut v72_7 = Space::new();
          let mut v72_7_write = v72_7.write_zipper();
          for v72_7_byte in v68_25_cursor.child_mask().iter() {
            v68_25_cursor.descend_to_existing_byte(v72_7_byte);
            {
            let v73_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 2)..(v68_25_origin + 3)]);
            let v73_3: Space = intersect(&(*CONSTANT_1),&(v73_2));
            let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
            drop(v73_3);
            let v73_5: Space = subtract(&(*CONSTANT_0),&(v73_4));
            drop(v73_4);
            let v73_8: Space = if (&(v73_5)).is_empty() { Space::new() } else {
              let v74_7: Space = routine_16(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v73_5),&(v74_7))
            };
            drop(v73_5);
            let v73_9: Space = intersect(&(*CONSTANT_1),&(v73_2));
            drop(v73_2);
            let v73_10: Space = if has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
            drop(v73_9);
            let v73_12: Space = if (&(v73_10)).is_empty() { Space::new() } else {
              let v75_11: Space = routine_17(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v73_10),&(v75_11))
            };
            drop(v73_10);
            let v73_13: Space = unite(&(v73_8),&(v73_12));
            join_wrapped_into(&mut v72_7_write,&((v73_13).read_zipper()),&[]);
            }
            v68_25_cursor.ascend(1);
          }
          drop(v72_7_write);
          compose(&(v71_5),&(v72_7))
        };
        drop(v71_5);
        let v71_9: Space = intersect(&(*CONSTANT_1),&(v71_2));
        drop(v71_2);
        let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
        drop(v71_9);
        let v71_12: Space = if (&(v71_10)).is_empty() { Space::new() } else {
          let mut v76_11 = Space::new();
          let mut v76_11_write = v76_11.write_zipper();
          for v76_11_byte in v68_25_cursor.child_mask().iter() {
            v68_25_cursor.descend_to_existing_byte(v76_11_byte);
            {
            let v77_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 2)..(v68_25_origin + 3)]);
            let v77_3: Space = intersect(&(*CONSTANT_1),&(v77_2));
            let v77_4: Space = if has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
            drop(v77_3);
            let v77_5: Space = subtract(&(*CONSTANT_0),&(v77_4));
            drop(v77_4);
            let v77_8: Space = if (&(v77_5)).is_empty() { Space::new() } else {
              let v78_7: Space = routine_16(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v77_5),&(v78_7))
            };
            drop(v77_5);
            let v77_9: Space = intersect(&(*CONSTANT_1),&(v77_2));
            drop(v77_2);
            let v77_10: Space = if has_head(&(v77_9)) { singleton(&[]) } else { Space::new() };
            drop(v77_9);
            let v77_12: Space = if (&(v77_10)).is_empty() { Space::new() } else {
              let v79_11: Space = routine_12(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v77_10),&(v79_11))
            };
            drop(v77_10);
            let v77_13: Space = unite(&(v77_8),&(v77_12));
            join_wrapped_into(&mut v76_11_write,&((v77_13).read_zipper()),&[]);
            }
            v68_25_cursor.ascend(1);
          }
          drop(v76_11_write);
          compose(&(v71_10),&(v76_11))
        };
        drop(v71_10);
        let v71_13: Space = unite(&(v71_8),&(v71_12));
        join_wrapped_into(&mut v70_6_write,&((v71_13).read_zipper()),&[]);
        }
        v68_25_cursor.ascend(1);
      }
      drop(v70_6_write);
      compose(&(v69_5),&(v70_6))
    };
    drop(v69_5);
    let v69_8: Space = intersect(&(*CONSTANT_1),&(v69_2));
    drop(v69_2);
    let v69_9: Space = if has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
    drop(v69_8);
    let v69_11: Space = if (&(v69_9)).is_empty() { Space::new() } else {
      let mut v80_10 = Space::new();
      let mut v80_10_write = v80_10.write_zipper();
      for v80_10_byte in v68_25_cursor.child_mask().iter() {
        v68_25_cursor.descend_to_existing_byte(v80_10_byte);
        {
        let v81_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 1)..(v68_25_origin + 2)]);
        let v81_3: Space = intersect(&(*CONSTANT_1),&(v81_2));
        let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
        drop(v81_3);
        let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
        drop(v81_4);
        let v81_8: Space = if (&(v81_5)).is_empty() { Space::new() } else {
          let mut v82_7 = Space::new();
          let mut v82_7_write = v82_7.write_zipper();
          for v82_7_byte in v68_25_cursor.child_mask().iter() {
            v68_25_cursor.descend_to_existing_byte(v82_7_byte);
            {
            let v83_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 2)..(v68_25_origin + 3)]);
            let v83_3: Space = intersect(&(*CONSTANT_1),&(v83_2));
            let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
            drop(v83_3);
            let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
            drop(v83_4);
            let v83_8: Space = if (&(v83_5)).is_empty() { Space::new() } else {
              let v84_7: Space = routine_16(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v83_5),&(v84_7))
            };
            drop(v83_5);
            let v83_9: Space = intersect(&(*CONSTANT_1),&(v83_2));
            drop(v83_2);
            let v83_10: Space = if has_head(&(v83_9)) { singleton(&[]) } else { Space::new() };
            drop(v83_9);
            let v83_12: Space = if (&(v83_10)).is_empty() { Space::new() } else {
              let v85_11: Space = routine_17(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v83_10),&(v85_11))
            };
            drop(v83_10);
            let v83_13: Space = unite(&(v83_8),&(v83_12));
            join_wrapped_into(&mut v82_7_write,&((v83_13).read_zipper()),&[]);
            }
            v68_25_cursor.ascend(1);
          }
          drop(v82_7_write);
          compose(&(v81_5),&(v82_7))
        };
        drop(v81_5);
        let v81_9: Space = intersect(&(*CONSTANT_1),&(v81_2));
        drop(v81_2);
        let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
        drop(v81_9);
        let v81_11: Space = compose(&(v81_10),&v68_25_cursor);
        drop(v81_10);
        let v81_12: Space = unite(&(v81_8),&(v81_11));
        drop(v81_11);
        join_wrapped_into(&mut v80_10_write,&((v81_12).read_zipper()),&[]);
        }
        v68_25_cursor.ascend(1);
      }
      drop(v80_10_write);
      compose(&(v69_9),&(v80_10))
    };
    drop(v69_9);
    let v69_12: Space = unite(&(v69_7),&(v69_11));
    join_wrapped_into(&mut v68_25_write,&((v69_12).read_zipper()),&[]);
    }
    v68_25_cursor.ascend(1);
  }
  drop(v68_25_cursor);
  drop(v68_25_write);
  drop(v68_6);
  let v68_26: Space = restrict_to(&(*CONSTANT_3),&(v68_25));
  let mut v68_45 = Space::new();
  let mut v68_45_write = v68_45.write_zipper();
  let mut v68_45_cursor = (v68_26).read_zipper();
  let v68_45_origin = v68_45_cursor.path().len();
  for v68_45_byte in v68_45_cursor.child_mask().iter() {
    v68_45_cursor.descend_to_existing_byte(v68_45_byte);
    {
    let v86_2: Space = singleton(&v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 1)]);
    let v86_3: Space = intersect(&(*CONSTANT_1),&(v86_2));
    let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
    drop(v86_3);
    let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
    drop(v86_4);
    let v86_7: Space = if (&(v86_5)).is_empty() { Space::new() } else {
      let mut v87_6 = Space::new();
      let mut v87_6_write = v87_6.write_zipper();
      for v87_6_byte in v68_45_cursor.child_mask().iter() {
        v68_45_cursor.descend_to_existing_byte(v87_6_byte);
        {
        let v88_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 1)..(v68_45_origin + 2)]);
        let v88_3: Space = intersect(&(*CONSTANT_1),&(v88_2));
        let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
        drop(v88_3);
        let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
        drop(v88_4);
        let v88_8: Space = if (&(v88_5)).is_empty() { Space::new() } else {
          let mut v89_7 = Space::new();
          let mut v89_7_write = v89_7.write_zipper();
          for v89_7_byte in v68_45_cursor.child_mask().iter() {
            v68_45_cursor.descend_to_existing_byte(v89_7_byte);
            {
            let v90_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 2)..(v68_45_origin + 3)]);
            let v90_3: Space = intersect(&(*CONSTANT_1),&(v90_2));
            let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
            drop(v90_3);
            let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
            drop(v90_4);
            let v90_8: Space = if (&(v90_5)).is_empty() { Space::new() } else {
              let v91_7: Space = routine_18(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v90_5),&(v91_7))
            };
            drop(v90_5);
            let v90_9: Space = intersect(&(*CONSTANT_1),&(v90_2));
            drop(v90_2);
            let v90_10: Space = if has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
            drop(v90_9);
            let v90_12: Space = if (&(v90_10)).is_empty() { Space::new() } else {
              let v92_11: Space = routine_19(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v90_10),&(v92_11))
            };
            drop(v90_10);
            let v90_13: Space = unite(&(v90_8),&(v90_12));
            join_wrapped_into(&mut v89_7_write,&((v90_13).read_zipper()),&[]);
            }
            v68_45_cursor.ascend(1);
          }
          drop(v89_7_write);
          compose(&(v88_5),&(v89_7))
        };
        drop(v88_5);
        let v88_9: Space = intersect(&(*CONSTANT_1),&(v88_2));
        drop(v88_2);
        let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
        drop(v88_9);
        let v88_12: Space = if (&(v88_10)).is_empty() { Space::new() } else {
          let mut v93_11 = Space::new();
          let mut v93_11_write = v93_11.write_zipper();
          for v93_11_byte in v68_45_cursor.child_mask().iter() {
            v68_45_cursor.descend_to_existing_byte(v93_11_byte);
            {
            let v94_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 2)..(v68_45_origin + 3)]);
            let v94_3: Space = intersect(&(*CONSTANT_1),&(v94_2));
            let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
            drop(v94_3);
            let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
            drop(v94_4);
            let v94_8: Space = if (&(v94_5)).is_empty() { Space::new() } else {
              let v95_7: Space = routine_18(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v94_5),&(v95_7))
            };
            drop(v94_5);
            let v94_9: Space = intersect(&(*CONSTANT_1),&(v94_2));
            drop(v94_2);
            let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
            drop(v94_9);
            let v94_12: Space = if (&(v94_10)).is_empty() { Space::new() } else {
              let v96_11: Space = routine_15(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v94_10),&(v96_11))
            };
            drop(v94_10);
            let v94_13: Space = unite(&(v94_8),&(v94_12));
            join_wrapped_into(&mut v93_11_write,&((v94_13).read_zipper()),&[]);
            }
            v68_45_cursor.ascend(1);
          }
          drop(v93_11_write);
          compose(&(v88_10),&(v93_11))
        };
        drop(v88_10);
        let v88_13: Space = unite(&(v88_8),&(v88_12));
        join_wrapped_into(&mut v87_6_write,&((v88_13).read_zipper()),&[]);
        }
        v68_45_cursor.ascend(1);
      }
      drop(v87_6_write);
      compose(&(v86_5),&(v87_6))
    };
    drop(v86_5);
    let v86_8: Space = intersect(&(*CONSTANT_1),&(v86_2));
    drop(v86_2);
    let v86_9: Space = if has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
    drop(v86_8);
    let v86_11: Space = if (&(v86_9)).is_empty() { Space::new() } else {
      let mut v97_10 = Space::new();
      let mut v97_10_write = v97_10.write_zipper();
      for v97_10_byte in v68_45_cursor.child_mask().iter() {
        v68_45_cursor.descend_to_existing_byte(v97_10_byte);
        {
        let v98_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 1)..(v68_45_origin + 2)]);
        let v98_3: Space = intersect(&(*CONSTANT_1),&(v98_2));
        let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
        drop(v98_3);
        let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
        drop(v98_4);
        let v98_8: Space = if (&(v98_5)).is_empty() { Space::new() } else {
          let mut v99_7 = Space::new();
          let mut v99_7_write = v99_7.write_zipper();
          for v99_7_byte in v68_45_cursor.child_mask().iter() {
            v68_45_cursor.descend_to_existing_byte(v99_7_byte);
            {
            let v100_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 2)..(v68_45_origin + 3)]);
            let v100_3: Space = intersect(&(*CONSTANT_1),&(v100_2));
            let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
            drop(v100_3);
            let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
            drop(v100_4);
            let v100_8: Space = if (&(v100_5)).is_empty() { Space::new() } else {
              let v101_7: Space = routine_18(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v100_5),&(v101_7))
            };
            drop(v100_5);
            let v100_9: Space = intersect(&(*CONSTANT_1),&(v100_2));
            drop(v100_2);
            let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
            drop(v100_9);
            let v100_12: Space = if (&(v100_10)).is_empty() { Space::new() } else {
              let v102_11: Space = routine_19(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v100_10),&(v102_11))
            };
            drop(v100_10);
            let v100_13: Space = unite(&(v100_8),&(v100_12));
            join_wrapped_into(&mut v99_7_write,&((v100_13).read_zipper()),&[]);
            }
            v68_45_cursor.ascend(1);
          }
          drop(v99_7_write);
          compose(&(v98_5),&(v99_7))
        };
        drop(v98_5);
        let v98_9: Space = intersect(&(*CONSTANT_1),&(v98_2));
        drop(v98_2);
        let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
        drop(v98_9);
        let v98_11: Space = compose(&(v98_10),&v68_45_cursor);
        drop(v98_10);
        let v98_12: Space = unite(&(v98_8),&(v98_11));
        drop(v98_11);
        join_wrapped_into(&mut v97_10_write,&((v98_12).read_zipper()),&[]);
        }
        v68_45_cursor.ascend(1);
      }
      drop(v97_10_write);
      compose(&(v86_9),&(v97_10))
    };
    drop(v86_9);
    let v86_12: Space = unite(&(v86_7),&(v86_11));
    join_wrapped_into(&mut v68_45_write,&((v86_12).read_zipper()),&[]);
    }
    v68_45_cursor.ascend(1);
  }
  drop(v68_45_cursor);
  drop(v68_45_write);
  let v68_48: Space = subtract(&(v68_45),&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0))));
  let v68_50: Space = intersect(&(v68_48),&(*CONSTANT_5));
  let v68_51: Space = wrap(&(v68_50),&(*p0));
  (v68_51).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v103_25 = Space::new();
  let mut v103_25_write = v103_25.write_zipper();
  let mut v103_25_cursor = (*s0).read_zipper();
  let v103_25_origin = v103_25_cursor.path().len();
  for v103_25_byte in v103_25_cursor.child_mask().iter() {
    v103_25_cursor.descend_to_existing_byte(v103_25_byte);
    {
    let v104_2: Space = singleton(&v103_25_cursor.path()[v103_25_origin..(v103_25_origin + 1)]);
    let v104_3: Space = intersect(&(*CONSTANT_1),&(v104_2));
    let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
    drop(v104_3);
    let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
    drop(v104_4);
    let v104_8: Space = if (&(v104_5)).is_empty() { Space::new() } else {
      let v105_6: Path = concat_path(&(*p0),&v103_25_cursor.path()[v103_25_origin..(v103_25_origin + 1)]);
      let mut v105_7 = Space::new();
      let mut v105_7_write = v105_7.write_zipper();
      for v105_7_byte in v103_25_cursor.child_mask().iter() {
        v103_25_cursor.descend_to_existing_byte(v105_7_byte);
        {
        let v106_2: Space = singleton(&v103_25_cursor.path()[(v103_25_origin + 1)..(v103_25_origin + 2)]);
        let v106_3: Space = intersect(&(*CONSTANT_1),&(v106_2));
        let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
        drop(v106_3);
        let v106_5: Space = subtract(&(*CONSTANT_0),&(v106_4));
        drop(v106_4);
        let v106_7: Space = if (&(v106_5)).is_empty() { Space::new() } else {
          let mut v107_6 = Space::new();
          let mut v107_6_write = v107_6.write_zipper();
          for v107_6_byte in v103_25_cursor.child_mask().iter() {
            v103_25_cursor.descend_to_existing_byte(v107_6_byte);
            {
            let v108_2: Space = Space::new();
            join_wrapped_into(&mut v107_6_write,&((v108_2).read_zipper()),&[]);
            }
            v103_25_cursor.ascend(1);
          }
          drop(v107_6_write);
          compose(&(v106_5),&(v107_6))
        };
        drop(v106_5);
        let v106_8: Space = intersect(&(*CONSTANT_1),&(v106_2));
        drop(v106_2);
        let v106_9: Space = if has_head(&(v106_8)) { singleton(&[]) } else { Space::new() };
        drop(v106_8);
        let v106_12: Space = if (&(v106_9)).is_empty() { Space::new() } else {
          let v109_10: Path = concat_path(&(v105_6),&v103_25_cursor.path()[(v103_25_origin + 1)..(v103_25_origin + 2)]);
          let mut v109_11 = Space::new();
          let mut v109_11_write = v109_11.write_zipper();
          for v109_11_byte in v103_25_cursor.child_mask().iter() {
            v103_25_cursor.descend_to_existing_byte(v109_11_byte);
            {
            let v110_2: Space = singleton(&v103_25_cursor.path()[(v103_25_origin + 2)..(v103_25_origin + 3)]);
            let v110_3: Space = intersect(&(*CONSTANT_1),&(v110_2));
            drop(v110_2);
            let v110_4: Space = if has_head(&(v110_3)) { singleton(&[]) } else { Space::new() };
            drop(v110_3);
            let v110_7: Space = if (&(v110_4)).is_empty() { Space::new() } else {
              let v111_5: Path = concat_path(&(v109_10),&v103_25_cursor.path()[(v103_25_origin + 2)..(v103_25_origin + 3)]);
              let v111_6: Space = routine_3(c, &(v111_5), &v103_25_cursor);
              drop(v111_5);
              compose(&(v110_4),&(v111_6))
            };
            drop(v110_4);
            join_wrapped_into(&mut v109_11_write,&((v110_7).read_zipper()),&[]);
            }
            v103_25_cursor.ascend(1);
          }
          drop(v109_11_write);
          drop(v109_10);
          compose(&(v106_9),&(v109_11))
        };
        drop(v106_9);
        let v106_13: Space = unite(&(v106_7),&(v106_12));
        drop(v106_7);
        join_wrapped_into(&mut v105_7_write,&((v106_13).read_zipper()),&[]);
        }
        v103_25_cursor.ascend(1);
      }
      drop(v105_7_write);
      compose(&(v104_5),&(v105_7))
    };
    drop(v104_5);
    let v104_9: Space = intersect(&(*CONSTANT_1),&(v104_2));
    drop(v104_2);
    let v104_10: Space = if has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
    drop(v104_9);
    let v104_14: Space = if (&(v104_10)).is_empty() { Space::new() } else {
      let v112_6: Path = concat_path(&(*p0),&v103_25_cursor.path()[v103_25_origin..(v103_25_origin + 1)]);
      let mut v112_13 = Space::new();
      let mut v112_13_write = v112_13.write_zipper();
      for v112_13_byte in v103_25_cursor.child_mask().iter() {
        v103_25_cursor.descend_to_existing_byte(v112_13_byte);
        {
        let v113_2: Space = singleton(&v103_25_cursor.path()[(v103_25_origin + 1)..(v103_25_origin + 2)]);
        let v113_3: Space = intersect(&(*CONSTANT_1),&(v113_2));
        let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
        drop(v113_3);
        let v113_5: Space = subtract(&(*CONSTANT_0),&(v113_4));
        drop(v113_4);
        let v113_7: Space = if (&(v113_5)).is_empty() { Space::new() } else {
          let mut v114_6 = Space::new();
          let mut v114_6_write = v114_6.write_zipper();
          for v114_6_byte in v103_25_cursor.child_mask().iter() {
            v103_25_cursor.descend_to_existing_byte(v114_6_byte);
            {
            let v115_2: Space = Space::new();
            join_wrapped_into(&mut v114_6_write,&((v115_2).read_zipper()),&[]);
            }
            v103_25_cursor.ascend(1);
          }
          drop(v114_6_write);
          compose(&(v113_5),&(v114_6))
        };
        drop(v113_5);
        let v113_8: Space = intersect(&(*CONSTANT_1),&(v113_2));
        drop(v113_2);
        let v113_9: Space = if has_head(&(v113_8)) { singleton(&[]) } else { Space::new() };
        drop(v113_8);
        let v113_18: Space = if (&(v113_9)).is_empty() { Space::new() } else {
          let v116_11: Space = restrict_to(&(*CONSTANT_4),&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v103_25_cursor.path()[v103_25_origin..(v103_25_origin + 1)]),&v103_25_cursor.path()[(v103_25_origin + 1)..(v103_25_origin + 2)])));
          let mut v116_12 = Space::new();
          let mut v116_12_write = v116_12.write_zipper();
          let mut v116_12_cursor = (v116_11).read_zipper();
          let v116_12_origin = v116_12_cursor.path().len();
          for v116_12_byte in v116_12_cursor.child_mask().iter() {
            v116_12_cursor.descend_to_existing_byte(v116_12_byte);
            {
            let v117_2: Space = singleton(&v116_12_cursor.path()[v116_12_origin..(v116_12_origin + 1)]);
            let v117_3: Space = intersect(&(*CONSTANT_1),&(v117_2));
            let v117_4: Space = if has_head(&(v117_3)) { singleton(&[]) } else { Space::new() };
            drop(v117_3);
            let v117_5: Space = subtract(&(*CONSTANT_0),&(v117_4));
            drop(v117_4);
            let v117_7: Space = if (&(v117_5)).is_empty() { Space::new() } else {
              let v118_6: Space = routine_6(c, &v116_12_cursor.path()[v116_12_origin..(v116_12_origin + 1)], &v116_12_cursor);
              compose(&(v117_5),&(v118_6))
            };
            drop(v117_5);
            let v117_8: Space = intersect(&(*CONSTANT_1),&(v117_2));
            drop(v117_2);
            let v117_9: Space = if has_head(&(v117_8)) { singleton(&[]) } else { Space::new() };
            drop(v117_8);
            let v117_11: Space = if (&(v117_9)).is_empty() { Space::new() } else {
              let v119_10: Space = routine_7(c, &v116_12_cursor.path()[v116_12_origin..(v116_12_origin + 1)], &v116_12_cursor);
              compose(&(v117_9),&(v119_10))
            };
            drop(v117_9);
            let v117_12: Space = unite(&(v117_7),&(v117_11));
            join_wrapped_into(&mut v116_12_write,&((v117_12).read_zipper()),&[]);
            }
            v116_12_cursor.ascend(1);
          }
          drop(v116_12_cursor);
          drop(v116_12_write);
          drop(v116_11);
          let v116_13: Space = restrict_to(&(*CONSTANT_3),&(v116_12));
          let mut v116_14 = Space::new();
          let mut v116_14_write = v116_14.write_zipper();
          let mut v116_14_cursor = (v116_13).read_zipper();
          let v116_14_origin = v116_14_cursor.path().len();
          for v116_14_byte in v116_14_cursor.child_mask().iter() {
            v116_14_cursor.descend_to_existing_byte(v116_14_byte);
            {
            let v120_2: Space = singleton(&v116_14_cursor.path()[v116_14_origin..(v116_14_origin + 1)]);
            let v120_3: Space = intersect(&(*CONSTANT_1),&(v120_2));
            let v120_4: Space = if has_head(&(v120_3)) { singleton(&[]) } else { Space::new() };
            drop(v120_3);
            let v120_5: Space = subtract(&(*CONSTANT_0),&(v120_4));
            drop(v120_4);
            let v120_7: Space = if (&(v120_5)).is_empty() { Space::new() } else {
              let v121_6: Space = routine_8(c, &v116_14_cursor.path()[v116_14_origin..(v116_14_origin + 1)], &v116_14_cursor);
              compose(&(v120_5),&(v121_6))
            };
            drop(v120_5);
            let v120_8: Space = intersect(&(*CONSTANT_1),&(v120_2));
            drop(v120_2);
            let v120_9: Space = if has_head(&(v120_8)) { singleton(&[]) } else { Space::new() };
            drop(v120_8);
            let v120_11: Space = if (&(v120_9)).is_empty() { Space::new() } else {
              let v122_10: Space = routine_9(c, &v116_14_cursor.path()[v116_14_origin..(v116_14_origin + 1)], &v116_14_cursor);
              compose(&(v120_9),&(v122_10))
            };
            drop(v120_9);
            let v120_12: Space = unite(&(v120_7),&(v120_11));
            join_wrapped_into(&mut v116_14_write,&((v120_12).read_zipper()),&[]);
            }
            v116_14_cursor.ascend(1);
          }
          drop(v116_14_cursor);
          drop(v116_14_write);
          let v116_16: Space = subtract(&(v116_14),&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v103_25_cursor.path()[v103_25_origin..(v103_25_origin + 1)]),&v103_25_cursor.path()[(v103_25_origin + 1)..(v103_25_origin + 2)])));
          let v116_17: Space = intersect(&(v116_16),&(*CONSTANT_5));
          compose(&(v113_9),&(v116_17))
        };
        drop(v113_9);
        let v113_19: Path = concat_path(&(v112_6),&v103_25_cursor.path()[(v103_25_origin + 1)..(v103_25_origin + 2)]);
        let v113_20: Space = wrap(&(v113_18),&(v113_19));
        drop(v113_19);
        let v113_21: Space = unite(&(v113_7),&(v113_20));
        drop(v113_7);
        join_wrapped_into(&mut v112_13_write,&((v113_21).read_zipper()),&[]);
        }
        v103_25_cursor.ascend(1);
      }
      drop(v112_13_write);
      drop(v112_6);
      compose(&(v104_10),&(v112_13))
    };
    drop(v104_10);
    let v104_15: Space = unite(&(v104_8),&(v104_14));
    join_wrapped_into(&mut v103_25_write,&((v104_15).read_zipper()),&[]);
    }
    v103_25_cursor.ascend(1);
  }
  drop(v103_25_cursor);
  drop(v103_25_write);
  (v103_25).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v123_34 = Space::new();
  let mut v123_34_write = v123_34.write_zipper();
  let mut v123_34_cursor = (*s0).read_zipper();
  let v123_34_origin = v123_34_cursor.path().len();
  for v123_34_byte in v123_34_cursor.child_mask().iter() {
    v123_34_cursor.descend_to_existing_byte(v123_34_byte);
    {
    let v124_2: Space = singleton(&v123_34_cursor.path()[v123_34_origin..(v123_34_origin + 1)]);
    let v124_3: Space = intersect(&(*CONSTANT_1),&(v124_2));
    let v124_4: Space = if has_head(&(v124_3)) { singleton(&[]) } else { Space::new() };
    drop(v124_3);
    let v124_5: Space = subtract(&(*CONSTANT_0),&(v124_4));
    drop(v124_4);
    let v124_8: Space = if (&(v124_5)).is_empty() { Space::new() } else {
      let v125_6: Path = concat_path(&(*p0),&v123_34_cursor.path()[v123_34_origin..(v123_34_origin + 1)]);
      let mut v125_7 = Space::new();
      let mut v125_7_write = v125_7.write_zipper();
      for v125_7_byte in v123_34_cursor.child_mask().iter() {
        v123_34_cursor.descend_to_existing_byte(v125_7_byte);
        {
        let v126_2: Space = singleton(&v123_34_cursor.path()[(v123_34_origin + 1)..(v123_34_origin + 2)]);
        let v126_3: Space = intersect(&(*CONSTANT_1),&(v126_2));
        let v126_4: Space = if has_head(&(v126_3)) { singleton(&[]) } else { Space::new() };
        drop(v126_3);
        let v126_5: Space = subtract(&(*CONSTANT_0),&(v126_4));
        drop(v126_4);
        let v126_7: Space = if (&(v126_5)).is_empty() { Space::new() } else {
          let mut v127_6 = Space::new();
          let mut v127_6_write = v127_6.write_zipper();
          for v127_6_byte in v123_34_cursor.child_mask().iter() {
            v123_34_cursor.descend_to_existing_byte(v127_6_byte);
            {
            let v128_2: Space = Space::new();
            join_wrapped_into(&mut v127_6_write,&((v128_2).read_zipper()),&[]);
            }
            v123_34_cursor.ascend(1);
          }
          drop(v127_6_write);
          compose(&(v126_5),&(v127_6))
        };
        drop(v126_5);
        let v126_8: Space = intersect(&(*CONSTANT_1),&(v126_2));
        drop(v126_2);
        let v126_9: Space = if has_head(&(v126_8)) { singleton(&[]) } else { Space::new() };
        drop(v126_8);
        let v126_12: Space = if (&(v126_9)).is_empty() { Space::new() } else {
          let v129_10: Path = concat_path(&(v125_6),&v123_34_cursor.path()[(v123_34_origin + 1)..(v123_34_origin + 2)]);
          let mut v129_11 = Space::new();
          let mut v129_11_write = v129_11.write_zipper();
          for v129_11_byte in v123_34_cursor.child_mask().iter() {
            v123_34_cursor.descend_to_existing_byte(v129_11_byte);
            {
            let v130_2: Space = singleton(&v123_34_cursor.path()[(v123_34_origin + 2)..(v123_34_origin + 3)]);
            let v130_3: Space = intersect(&(*CONSTANT_1),&(v130_2));
            drop(v130_2);
            let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
            drop(v130_3);
            let v130_7: Space = if (&(v130_4)).is_empty() { Space::new() } else {
              let v131_5: Path = concat_path(&(v129_10),&v123_34_cursor.path()[(v123_34_origin + 2)..(v123_34_origin + 3)]);
              let v131_6: Space = routine_3(c, &(v131_5), &v123_34_cursor);
              drop(v131_5);
              compose(&(v130_4),&(v131_6))
            };
            drop(v130_4);
            join_wrapped_into(&mut v129_11_write,&((v130_7).read_zipper()),&[]);
            }
            v123_34_cursor.ascend(1);
          }
          drop(v129_11_write);
          drop(v129_10);
          compose(&(v126_9),&(v129_11))
        };
        drop(v126_9);
        let v126_13: Space = unite(&(v126_7),&(v126_12));
        drop(v126_7);
        join_wrapped_into(&mut v125_7_write,&((v126_13).read_zipper()),&[]);
        }
        v123_34_cursor.ascend(1);
      }
      drop(v125_7_write);
      compose(&(v124_5),&(v125_7))
    };
    drop(v124_5);
    let v124_9: Space = intersect(&(*CONSTANT_1),&(v124_2));
    drop(v124_2);
    let v124_10: Space = if has_head(&(v124_9)) { singleton(&[]) } else { Space::new() };
    drop(v124_9);
    let v124_19: Space = if (&(v124_10)).is_empty() { Space::new() } else {
      let v132_12: Space = restrict_to(&(*CONSTANT_4),&(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v123_34_cursor.path()[v123_34_origin..(v123_34_origin + 1)])));
      let mut v132_13 = Space::new();
      let mut v132_13_write = v132_13.write_zipper();
      let mut v132_13_cursor = (v132_12).read_zipper();
      let v132_13_origin = v132_13_cursor.path().len();
      for v132_13_byte in v132_13_cursor.child_mask().iter() {
        v132_13_cursor.descend_to_existing_byte(v132_13_byte);
        {
        let v133_2: Space = singleton(&v132_13_cursor.path()[v132_13_origin..(v132_13_origin + 1)]);
        let v133_3: Space = intersect(&(*CONSTANT_1),&(v133_2));
        let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
        drop(v133_3);
        let v133_5: Space = subtract(&(*CONSTANT_0),&(v133_4));
        drop(v133_4);
        let v133_7: Space = if (&(v133_5)).is_empty() { Space::new() } else {
          let mut v134_6 = Space::new();
          let mut v134_6_write = v134_6.write_zipper();
          for v134_6_byte in v132_13_cursor.child_mask().iter() {
            v132_13_cursor.descend_to_existing_byte(v134_6_byte);
            {
            let v135_2: Space = singleton(&v132_13_cursor.path()[(v132_13_origin + 1)..(v132_13_origin + 2)]);
            let v135_3: Space = intersect(&(*CONSTANT_1),&(v135_2));
            let v135_4: Space = if has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
            drop(v135_3);
            let v135_5: Space = subtract(&(*CONSTANT_0),&(v135_4));
            drop(v135_4);
            let v135_8: Space = if (&(v135_5)).is_empty() { Space::new() } else {
              let v136_7: Space = routine_10(c, &v132_13_cursor.path()[v132_13_origin..(v132_13_origin + 2)], &v132_13_cursor);
              compose(&(v135_5),&(v136_7))
            };
            drop(v135_5);
            let v135_9: Space = intersect(&(*CONSTANT_1),&(v135_2));
            drop(v135_2);
            let v135_10: Space = if has_head(&(v135_9)) { singleton(&[]) } else { Space::new() };
            drop(v135_9);
            let v135_12: Space = if (&(v135_10)).is_empty() { Space::new() } else {
              let v137_11: Space = routine_11(c, &v132_13_cursor.path()[v132_13_origin..(v132_13_origin + 2)], &v132_13_cursor);
              compose(&(v135_10),&(v137_11))
            };
            drop(v135_10);
            let v135_13: Space = unite(&(v135_8),&(v135_12));
            join_wrapped_into(&mut v134_6_write,&((v135_13).read_zipper()),&[]);
            }
            v132_13_cursor.ascend(1);
          }
          drop(v134_6_write);
          compose(&(v133_5),&(v134_6))
        };
        drop(v133_5);
        let v133_8: Space = intersect(&(*CONSTANT_1),&(v133_2));
        drop(v133_2);
        let v133_9: Space = if has_head(&(v133_8)) { singleton(&[]) } else { Space::new() };
        drop(v133_8);
        let v133_11: Space = if (&(v133_9)).is_empty() { Space::new() } else {
          let mut v138_10 = Space::new();
          let mut v138_10_write = v138_10.write_zipper();
          for v138_10_byte in v132_13_cursor.child_mask().iter() {
            v132_13_cursor.descend_to_existing_byte(v138_10_byte);
            {
            let v139_2: Space = singleton(&v132_13_cursor.path()[(v132_13_origin + 1)..(v132_13_origin + 2)]);
            let v139_3: Space = intersect(&(*CONSTANT_1),&(v139_2));
            let v139_4: Space = if has_head(&(v139_3)) { singleton(&[]) } else { Space::new() };
            drop(v139_3);
            let v139_5: Space = subtract(&(*CONSTANT_0),&(v139_4));
            drop(v139_4);
            let v139_8: Space = if (&(v139_5)).is_empty() { Space::new() } else {
              let v140_7: Space = routine_10(c, &v132_13_cursor.path()[v132_13_origin..(v132_13_origin + 2)], &v132_13_cursor);
              compose(&(v139_5),&(v140_7))
            };
            drop(v139_5);
            let v139_9: Space = intersect(&(*CONSTANT_1),&(v139_2));
            drop(v139_2);
            let v139_10: Space = if has_head(&(v139_9)) { singleton(&[]) } else { Space::new() };
            drop(v139_9);
            let v139_12: Space = if (&(v139_10)).is_empty() { Space::new() } else {
              let v141_11: Space = routine_12(c, &v132_13_cursor.path()[v132_13_origin..(v132_13_origin + 2)], &v132_13_cursor);
              compose(&(v139_10),&(v141_11))
            };
            drop(v139_10);
            let v139_13: Space = unite(&(v139_8),&(v139_12));
            join_wrapped_into(&mut v138_10_write,&((v139_13).read_zipper()),&[]);
            }
            v132_13_cursor.ascend(1);
          }
          drop(v138_10_write);
          compose(&(v133_9),&(v138_10))
        };
        drop(v133_9);
        let v133_12: Space = unite(&(v133_7),&(v133_11));
        join_wrapped_into(&mut v132_13_write,&((v133_12).read_zipper()),&[]);
        }
        v132_13_cursor.ascend(1);
      }
      drop(v132_13_cursor);
      drop(v132_13_write);
      drop(v132_12);
      let v132_14: Space = restrict_to(&(*CONSTANT_3),&(v132_13));
      let mut v132_15 = Space::new();
      let mut v132_15_write = v132_15.write_zipper();
      let mut v132_15_cursor = (v132_14).read_zipper();
      let v132_15_origin = v132_15_cursor.path().len();
      for v132_15_byte in v132_15_cursor.child_mask().iter() {
        v132_15_cursor.descend_to_existing_byte(v132_15_byte);
        {
        let v142_2: Space = singleton(&v132_15_cursor.path()[v132_15_origin..(v132_15_origin + 1)]);
        let v142_3: Space = intersect(&(*CONSTANT_1),&(v142_2));
        let v142_4: Space = if has_head(&(v142_3)) { singleton(&[]) } else { Space::new() };
        drop(v142_3);
        let v142_5: Space = subtract(&(*CONSTANT_0),&(v142_4));
        drop(v142_4);
        let v142_7: Space = if (&(v142_5)).is_empty() { Space::new() } else {
          let mut v143_6 = Space::new();
          let mut v143_6_write = v143_6.write_zipper();
          for v143_6_byte in v132_15_cursor.child_mask().iter() {
            v132_15_cursor.descend_to_existing_byte(v143_6_byte);
            {
            let v144_2: Space = singleton(&v132_15_cursor.path()[(v132_15_origin + 1)..(v132_15_origin + 2)]);
            let v144_3: Space = intersect(&(*CONSTANT_1),&(v144_2));
            let v144_4: Space = if has_head(&(v144_3)) { singleton(&[]) } else { Space::new() };
            drop(v144_3);
            let v144_5: Space = subtract(&(*CONSTANT_0),&(v144_4));
            drop(v144_4);
            let v144_8: Space = if (&(v144_5)).is_empty() { Space::new() } else {
              let v145_7: Space = routine_13(c, &v132_15_cursor.path()[v132_15_origin..(v132_15_origin + 2)], &v132_15_cursor);
              compose(&(v144_5),&(v145_7))
            };
            drop(v144_5);
            let v144_9: Space = intersect(&(*CONSTANT_1),&(v144_2));
            drop(v144_2);
            let v144_10: Space = if has_head(&(v144_9)) { singleton(&[]) } else { Space::new() };
            drop(v144_9);
            let v144_12: Space = if (&(v144_10)).is_empty() { Space::new() } else {
              let v146_11: Space = routine_14(c, &v132_15_cursor.path()[v132_15_origin..(v132_15_origin + 2)], &v132_15_cursor);
              compose(&(v144_10),&(v146_11))
            };
            drop(v144_10);
            let v144_13: Space = unite(&(v144_8),&(v144_12));
            join_wrapped_into(&mut v143_6_write,&((v144_13).read_zipper()),&[]);
            }
            v132_15_cursor.ascend(1);
          }
          drop(v143_6_write);
          compose(&(v142_5),&(v143_6))
        };
        drop(v142_5);
        let v142_8: Space = intersect(&(*CONSTANT_1),&(v142_2));
        drop(v142_2);
        let v142_9: Space = if has_head(&(v142_8)) { singleton(&[]) } else { Space::new() };
        drop(v142_8);
        let v142_11: Space = if (&(v142_9)).is_empty() { Space::new() } else {
          let mut v147_10 = Space::new();
          let mut v147_10_write = v147_10.write_zipper();
          for v147_10_byte in v132_15_cursor.child_mask().iter() {
            v132_15_cursor.descend_to_existing_byte(v147_10_byte);
            {
            let v148_2: Space = singleton(&v132_15_cursor.path()[(v132_15_origin + 1)..(v132_15_origin + 2)]);
            let v148_3: Space = intersect(&(*CONSTANT_1),&(v148_2));
            let v148_4: Space = if has_head(&(v148_3)) { singleton(&[]) } else { Space::new() };
            drop(v148_3);
            let v148_5: Space = subtract(&(*CONSTANT_0),&(v148_4));
            drop(v148_4);
            let v148_8: Space = if (&(v148_5)).is_empty() { Space::new() } else {
              let v149_7: Space = routine_13(c, &v132_15_cursor.path()[v132_15_origin..(v132_15_origin + 2)], &v132_15_cursor);
              compose(&(v148_5),&(v149_7))
            };
            drop(v148_5);
            let v148_9: Space = intersect(&(*CONSTANT_1),&(v148_2));
            drop(v148_2);
            let v148_10: Space = if has_head(&(v148_9)) { singleton(&[]) } else { Space::new() };
            drop(v148_9);
            let v148_12: Space = if (&(v148_10)).is_empty() { Space::new() } else {
              let v150_11: Space = routine_15(c, &v132_15_cursor.path()[v132_15_origin..(v132_15_origin + 2)], &v132_15_cursor);
              compose(&(v148_10),&(v150_11))
            };
            drop(v148_10);
            let v148_13: Space = unite(&(v148_8),&(v148_12));
            join_wrapped_into(&mut v147_10_write,&((v148_13).read_zipper()),&[]);
            }
            v132_15_cursor.ascend(1);
          }
          drop(v147_10_write);
          compose(&(v142_9),&(v147_10))
        };
        drop(v142_9);
        let v142_12: Space = unite(&(v142_7),&(v142_11));
        join_wrapped_into(&mut v132_15_write,&((v142_12).read_zipper()),&[]);
        }
        v132_15_cursor.ascend(1);
      }
      drop(v132_15_cursor);
      drop(v132_15_write);
      let v132_17: Space = subtract(&(v132_15),&(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v123_34_cursor.path()[v123_34_origin..(v123_34_origin + 1)])));
      let v132_18: Space = intersect(&(v132_17),&(*CONSTANT_5));
      compose(&(v124_10),&(v132_18))
    };
    drop(v124_10);
    let v151_6: Path = concat_path(&(*p0),&v123_34_cursor.path()[v123_34_origin..(v123_34_origin + 1)]);
    let v124_20: Space = wrap(&(v124_19),&(v151_6));
    let v124_21: Space = unite(&(v124_8),&(v124_20));
    join_wrapped_into(&mut v123_34_write,&((v124_21).read_zipper()),&[]);
    }
    v123_34_cursor.ascend(1);
  }
  drop(v123_34_cursor);
  drop(v123_34_write);
  (v123_34).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v152_20 = Space::new();
  let mut v152_20_write = v152_20.write_zipper();
  let mut v152_20_cursor = (*s0).read_zipper();
  let v152_20_origin = v152_20_cursor.path().len();
  for v152_20_byte in v152_20_cursor.child_mask().iter() {
    v152_20_cursor.descend_to_existing_byte(v152_20_byte);
    {
    let v153_2: Space = singleton(&v152_20_cursor.path()[v152_20_origin..(v152_20_origin + 1)]);
    let v153_3: Space = intersect(&(*CONSTANT_1),&(v153_2));
    let v153_4: Space = if has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
    drop(v153_3);
    let v153_5: Space = subtract(&(*CONSTANT_0),&(v153_4));
    drop(v153_4);
    let v153_8: Space = if (&(v153_5)).is_empty() { Space::new() } else {
      let v154_6: Path = concat_path(&(*p0),&v152_20_cursor.path()[v152_20_origin..(v152_20_origin + 1)]);
      let mut v154_7 = Space::new();
      let mut v154_7_write = v154_7.write_zipper();
      for v154_7_byte in v152_20_cursor.child_mask().iter() {
        v152_20_cursor.descend_to_existing_byte(v154_7_byte);
        {
        let v155_2: Space = singleton(&v152_20_cursor.path()[(v152_20_origin + 1)..(v152_20_origin + 2)]);
        let v155_3: Space = intersect(&(*CONSTANT_1),&(v155_2));
        let v155_4: Space = if has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
        drop(v155_3);
        let v155_5: Space = subtract(&(*CONSTANT_0),&(v155_4));
        drop(v155_4);
        let v155_8: Space = if (&(v155_5)).is_empty() { Space::new() } else {
          let v156_6: Path = concat_path(&(v154_6),&v152_20_cursor.path()[(v152_20_origin + 1)..(v152_20_origin + 2)]);
          let mut v156_7 = Space::new();
          let mut v156_7_write = v156_7.write_zipper();
          for v156_7_byte in v152_20_cursor.child_mask().iter() {
            v152_20_cursor.descend_to_existing_byte(v156_7_byte);
            {
            let v157_2: Space = singleton(&v152_20_cursor.path()[(v152_20_origin + 2)..(v152_20_origin + 3)]);
            let v157_3: Space = intersect(&(*CONSTANT_1),&(v157_2));
            let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
            drop(v157_3);
            let v157_5: Space = subtract(&(*CONSTANT_0),&(v157_4));
            drop(v157_4);
            let v157_8: Space = if (&(v157_5)).is_empty() { Space::new() } else {
              let v158_6: Path = concat_path(&(v156_6),&v152_20_cursor.path()[(v152_20_origin + 2)..(v152_20_origin + 3)]);
              let v158_7: Space = routine_20(c, &(v158_6), &v152_20_cursor);
              compose(&(v157_5),&(v158_7))
            };
            drop(v157_5);
            let v157_9: Space = intersect(&(*CONSTANT_1),&(v157_2));
            drop(v157_2);
            let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
            drop(v157_9);
            let v157_12: Space = if (&(v157_10)).is_empty() { Space::new() } else {
              let v159_6: Path = concat_path(&(v156_6),&v152_20_cursor.path()[(v152_20_origin + 2)..(v152_20_origin + 3)]);
              let v159_11: Space = routine_21(c, &(v159_6), &v152_20_cursor);
              drop(v159_6);
              compose(&(v157_10),&(v159_11))
            };
            drop(v157_10);
            let v157_13: Space = unite(&(v157_8),&(v157_12));
            join_wrapped_into(&mut v156_7_write,&((v157_13).read_zipper()),&[]);
            }
            v152_20_cursor.ascend(1);
          }
          drop(v156_7_write);
          compose(&(v155_5),&(v156_7))
        };
        drop(v155_5);
        let v155_9: Space = intersect(&(*CONSTANT_1),&(v155_2));
        drop(v155_2);
        let v155_10: Space = if has_head(&(v155_9)) { singleton(&[]) } else { Space::new() };
        drop(v155_9);
        let v155_12: Space = if (&(v155_10)).is_empty() { Space::new() } else {
          let v160_6: Path = concat_path(&(v154_6),&v152_20_cursor.path()[(v152_20_origin + 1)..(v152_20_origin + 2)]);
          let mut v160_11 = Space::new();
          let mut v160_11_write = v160_11.write_zipper();
          for v160_11_byte in v152_20_cursor.child_mask().iter() {
            v152_20_cursor.descend_to_existing_byte(v160_11_byte);
            {
            let v161_2: Space = singleton(&v152_20_cursor.path()[(v152_20_origin + 2)..(v152_20_origin + 3)]);
            let v161_3: Space = intersect(&(*CONSTANT_1),&(v161_2));
            let v161_4: Space = if has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
            drop(v161_3);
            let v161_5: Space = subtract(&(*CONSTANT_0),&(v161_4));
            drop(v161_4);
            let v161_8: Space = if (&(v161_5)).is_empty() { Space::new() } else {
              let v162_6: Path = concat_path(&(v160_6),&v152_20_cursor.path()[(v152_20_origin + 2)..(v152_20_origin + 3)]);
              let v162_7: Space = routine_20(c, &(v162_6), &v152_20_cursor);
              compose(&(v161_5),&(v162_7))
            };
            drop(v161_5);
            let v161_9: Space = intersect(&(*CONSTANT_1),&(v161_2));
            drop(v161_2);
            let v161_10: Space = if has_head(&(v161_9)) { singleton(&[]) } else { Space::new() };
            drop(v161_9);
            let v161_12: Space = if (&(v161_10)).is_empty() { Space::new() } else {
              let v163_6: Path = concat_path(&(v160_6),&v152_20_cursor.path()[(v152_20_origin + 2)..(v152_20_origin + 3)]);
              let v163_11: Space = routine_12(c, &(v163_6), &v152_20_cursor);
              drop(v163_6);
              compose(&(v161_10),&(v163_11))
            };
            drop(v161_10);
            let v161_13: Space = unite(&(v161_8),&(v161_12));
            join_wrapped_into(&mut v160_11_write,&((v161_13).read_zipper()),&[]);
            }
            v152_20_cursor.ascend(1);
          }
          drop(v160_11_write);
          drop(v160_6);
          compose(&(v155_10),&(v160_11))
        };
        drop(v155_10);
        let v155_13: Space = unite(&(v155_8),&(v155_12));
        join_wrapped_into(&mut v154_7_write,&((v155_13).read_zipper()),&[]);
        }
        v152_20_cursor.ascend(1);
      }
      drop(v154_7_write);
      compose(&(v153_5),&(v154_7))
    };
    drop(v153_5);
    let v153_9: Space = intersect(&(*CONSTANT_1),&(v153_2));
    drop(v153_2);
    let v153_10: Space = if has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
    drop(v153_9);
    let v153_12: Space = if (&(v153_10)).is_empty() { Space::new() } else {
      let v164_6: Path = concat_path(&(*p0),&v152_20_cursor.path()[v152_20_origin..(v152_20_origin + 1)]);
      let mut v164_11 = Space::new();
      let mut v164_11_write = v164_11.write_zipper();
      for v164_11_byte in v152_20_cursor.child_mask().iter() {
        v152_20_cursor.descend_to_existing_byte(v164_11_byte);
        {
        let v165_2: Space = singleton(&v152_20_cursor.path()[(v152_20_origin + 1)..(v152_20_origin + 2)]);
        let v165_3: Space = intersect(&(*CONSTANT_1),&(v165_2));
        let v165_4: Space = if has_head(&(v165_3)) { singleton(&[]) } else { Space::new() };
        drop(v165_3);
        let v165_5: Space = subtract(&(*CONSTANT_0),&(v165_4));
        drop(v165_4);
        let v165_8: Space = if (&(v165_5)).is_empty() { Space::new() } else {
          let v166_6: Path = concat_path(&(v164_6),&v152_20_cursor.path()[(v152_20_origin + 1)..(v152_20_origin + 2)]);
          let mut v166_7 = Space::new();
          let mut v166_7_write = v166_7.write_zipper();
          for v166_7_byte in v152_20_cursor.child_mask().iter() {
            v152_20_cursor.descend_to_existing_byte(v166_7_byte);
            {
            let v167_2: Space = singleton(&v152_20_cursor.path()[(v152_20_origin + 2)..(v152_20_origin + 3)]);
            let v167_3: Space = intersect(&(*CONSTANT_1),&(v167_2));
            let v167_4: Space = if has_head(&(v167_3)) { singleton(&[]) } else { Space::new() };
            drop(v167_3);
            let v167_5: Space = subtract(&(*CONSTANT_0),&(v167_4));
            drop(v167_4);
            let v167_8: Space = if (&(v167_5)).is_empty() { Space::new() } else {
              let v168_6: Path = concat_path(&(v166_6),&v152_20_cursor.path()[(v152_20_origin + 2)..(v152_20_origin + 3)]);
              let v168_7: Space = routine_20(c, &(v168_6), &v152_20_cursor);
              compose(&(v167_5),&(v168_7))
            };
            drop(v167_5);
            let v167_9: Space = intersect(&(*CONSTANT_1),&(v167_2));
            drop(v167_2);
            let v167_10: Space = if has_head(&(v167_9)) { singleton(&[]) } else { Space::new() };
            drop(v167_9);
            let v167_12: Space = if (&(v167_10)).is_empty() { Space::new() } else {
              let v169_6: Path = concat_path(&(v166_6),&v152_20_cursor.path()[(v152_20_origin + 2)..(v152_20_origin + 3)]);
              let v169_11: Space = routine_21(c, &(v169_6), &v152_20_cursor);
              drop(v169_6);
              compose(&(v167_10),&(v169_11))
            };
            drop(v167_10);
            let v167_13: Space = unite(&(v167_8),&(v167_12));
            join_wrapped_into(&mut v166_7_write,&((v167_13).read_zipper()),&[]);
            }
            v152_20_cursor.ascend(1);
          }
          drop(v166_7_write);
          drop(v166_6);
          compose(&(v165_5),&(v166_7))
        };
        drop(v165_5);
        let v165_9: Space = intersect(&(*CONSTANT_1),&(v165_2));
        drop(v165_2);
        let v165_10: Space = if has_head(&(v165_9)) { singleton(&[]) } else { Space::new() };
        drop(v165_9);
        let v165_11: Space = compose(&(v165_10),&v152_20_cursor);
        drop(v165_10);
        let v165_12: Space = unite(&(v165_8),&(v165_11));
        drop(v165_11);
        join_wrapped_into(&mut v164_11_write,&((v165_12).read_zipper()),&[]);
        }
        v152_20_cursor.ascend(1);
      }
      drop(v164_11_write);
      drop(v164_6);
      compose(&(v153_10),&(v164_11))
    };
    drop(v153_10);
    let v153_13: Space = unite(&(v153_8),&(v153_12));
    join_wrapped_into(&mut v152_20_write,&((v153_13).read_zipper()),&[]);
    }
    v152_20_cursor.ascend(1);
  }
  drop(v152_20_cursor);
  drop(v152_20_write);
  (v152_20).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v170_14 = Space::new();
  let mut v170_14_write = v170_14.write_zipper();
  let mut v170_14_cursor = (*s0).read_zipper();
  let v170_14_origin = v170_14_cursor.path().len();
  for v170_14_byte in v170_14_cursor.child_mask().iter() {
    v170_14_cursor.descend_to_existing_byte(v170_14_byte);
    {
    let v171_2: Space = singleton(&v170_14_cursor.path()[v170_14_origin..(v170_14_origin + 1)]);
    let v171_3: Space = intersect(&(*CONSTANT_1),&(v171_2));
    let v171_4: Space = if has_head(&(v171_3)) { singleton(&[]) } else { Space::new() };
    drop(v171_3);
    let v171_5: Space = subtract(&(*CONSTANT_0),&(v171_4));
    drop(v171_4);
    let v171_8: Space = if (&(v171_5)).is_empty() { Space::new() } else {
      let v172_6: Path = concat_path(&(*p0),&v170_14_cursor.path()[v170_14_origin..(v170_14_origin + 1)]);
      let mut v172_7 = Space::new();
      let mut v172_7_write = v172_7.write_zipper();
      for v172_7_byte in v170_14_cursor.child_mask().iter() {
        v170_14_cursor.descend_to_existing_byte(v172_7_byte);
        {
        let v173_2: Space = singleton(&v170_14_cursor.path()[(v170_14_origin + 1)..(v170_14_origin + 2)]);
        let v173_3: Space = intersect(&(*CONSTANT_1),&(v173_2));
        let v173_4: Space = if has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
        drop(v173_3);
        let v173_5: Space = subtract(&(*CONSTANT_0),&(v173_4));
        drop(v173_4);
        let v173_8: Space = if (&(v173_5)).is_empty() { Space::new() } else {
          let v174_6: Path = concat_path(&(v172_6),&v170_14_cursor.path()[(v170_14_origin + 1)..(v170_14_origin + 2)]);
          let mut v174_7 = Space::new();
          let mut v174_7_write = v174_7.write_zipper();
          for v174_7_byte in v170_14_cursor.child_mask().iter() {
            v170_14_cursor.descend_to_existing_byte(v174_7_byte);
            {
            let v175_2: Space = singleton(&v170_14_cursor.path()[(v170_14_origin + 2)..(v170_14_origin + 3)]);
            let v175_3: Space = intersect(&(*CONSTANT_1),&(v175_2));
            let v175_4: Space = if has_head(&(v175_3)) { singleton(&[]) } else { Space::new() };
            drop(v175_3);
            let v175_5: Space = subtract(&(*CONSTANT_0),&(v175_4));
            drop(v175_4);
            let v175_8: Space = if (&(v175_5)).is_empty() { Space::new() } else {
              let v176_6: Path = concat_path(&(v174_6),&v170_14_cursor.path()[(v170_14_origin + 2)..(v170_14_origin + 3)]);
              let v176_7: Space = routine_20(c, &(v176_6), &v170_14_cursor);
              compose(&(v175_5),&(v176_7))
            };
            drop(v175_5);
            let v175_9: Space = intersect(&(*CONSTANT_1),&(v175_2));
            drop(v175_2);
            let v175_10: Space = if has_head(&(v175_9)) { singleton(&[]) } else { Space::new() };
            drop(v175_9);
            let v175_12: Space = if (&(v175_10)).is_empty() { Space::new() } else {
              let v177_6: Path = concat_path(&(v174_6),&v170_14_cursor.path()[(v170_14_origin + 2)..(v170_14_origin + 3)]);
              let v177_11: Space = routine_21(c, &(v177_6), &v170_14_cursor);
              drop(v177_6);
              compose(&(v175_10),&(v177_11))
            };
            drop(v175_10);
            let v175_13: Space = unite(&(v175_8),&(v175_12));
            join_wrapped_into(&mut v174_7_write,&((v175_13).read_zipper()),&[]);
            }
            v170_14_cursor.ascend(1);
          }
          drop(v174_7_write);
          compose(&(v173_5),&(v174_7))
        };
        drop(v173_5);
        let v173_9: Space = intersect(&(*CONSTANT_1),&(v173_2));
        drop(v173_2);
        let v173_10: Space = if has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
        drop(v173_9);
        let v173_12: Space = if (&(v173_10)).is_empty() { Space::new() } else {
          let v178_6: Path = concat_path(&(v172_6),&v170_14_cursor.path()[(v170_14_origin + 1)..(v170_14_origin + 2)]);
          let mut v178_11 = Space::new();
          let mut v178_11_write = v178_11.write_zipper();
          for v178_11_byte in v170_14_cursor.child_mask().iter() {
            v170_14_cursor.descend_to_existing_byte(v178_11_byte);
            {
            let v179_2: Space = singleton(&v170_14_cursor.path()[(v170_14_origin + 2)..(v170_14_origin + 3)]);
            let v179_3: Space = intersect(&(*CONSTANT_1),&(v179_2));
            let v179_4: Space = if has_head(&(v179_3)) { singleton(&[]) } else { Space::new() };
            drop(v179_3);
            let v179_5: Space = subtract(&(*CONSTANT_0),&(v179_4));
            drop(v179_4);
            let v179_8: Space = if (&(v179_5)).is_empty() { Space::new() } else {
              let v180_6: Path = concat_path(&(v178_6),&v170_14_cursor.path()[(v170_14_origin + 2)..(v170_14_origin + 3)]);
              let v180_7: Space = routine_20(c, &(v180_6), &v170_14_cursor);
              compose(&(v179_5),&(v180_7))
            };
            drop(v179_5);
            let v179_9: Space = intersect(&(*CONSTANT_1),&(v179_2));
            drop(v179_2);
            let v179_10: Space = if has_head(&(v179_9)) { singleton(&[]) } else { Space::new() };
            drop(v179_9);
            let v179_12: Space = if (&(v179_10)).is_empty() { Space::new() } else {
              let v181_6: Path = concat_path(&(v178_6),&v170_14_cursor.path()[(v170_14_origin + 2)..(v170_14_origin + 3)]);
              let v181_11: Space = routine_12(c, &(v181_6), &v170_14_cursor);
              drop(v181_6);
              compose(&(v179_10),&(v181_11))
            };
            drop(v179_10);
            let v179_13: Space = unite(&(v179_8),&(v179_12));
            join_wrapped_into(&mut v178_11_write,&((v179_13).read_zipper()),&[]);
            }
            v170_14_cursor.ascend(1);
          }
          drop(v178_11_write);
          drop(v178_6);
          compose(&(v173_10),&(v178_11))
        };
        drop(v173_10);
        let v173_13: Space = unite(&(v173_8),&(v173_12));
        join_wrapped_into(&mut v172_7_write,&((v173_13).read_zipper()),&[]);
        }
        v170_14_cursor.ascend(1);
      }
      drop(v172_7_write);
      drop(v172_6);
      compose(&(v171_5),&(v172_7))
    };
    drop(v171_5);
    let v171_9: Space = intersect(&(*CONSTANT_1),&(v171_2));
    drop(v171_2);
    let v171_10: Space = if has_head(&(v171_9)) { singleton(&[]) } else { Space::new() };
    drop(v171_9);
    let v171_11: Space = compose(&(v171_10),&v170_14_cursor);
    drop(v171_10);
    let v171_12: Space = unite(&(v171_8),&(v171_11));
    drop(v171_11);
    join_wrapped_into(&mut v170_14_write,&((v171_12).read_zipper()),&[]);
    }
    v170_14_cursor.ascend(1);
  }
  drop(v170_14_cursor);
  drop(v170_14_write);
  (v170_14).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v182_20 = Space::new();
  let mut v182_20_write = v182_20.write_zipper();
  let mut v182_20_cursor = (*s0).read_zipper();
  let v182_20_origin = v182_20_cursor.path().len();
  for v182_20_byte in v182_20_cursor.child_mask().iter() {
    v182_20_cursor.descend_to_existing_byte(v182_20_byte);
    {
    let v183_2: Space = singleton(&v182_20_cursor.path()[v182_20_origin..(v182_20_origin + 1)]);
    let v183_3: Space = intersect(&(*CONSTANT_1),&(v183_2));
    let v183_4: Space = if has_head(&(v183_3)) { singleton(&[]) } else { Space::new() };
    drop(v183_3);
    let v183_5: Space = subtract(&(*CONSTANT_0),&(v183_4));
    drop(v183_4);
    let v183_8: Space = if (&(v183_5)).is_empty() { Space::new() } else {
      let v184_6: Path = concat_path(&(*p0),&v182_20_cursor.path()[v182_20_origin..(v182_20_origin + 1)]);
      let mut v184_7 = Space::new();
      let mut v184_7_write = v184_7.write_zipper();
      for v184_7_byte in v182_20_cursor.child_mask().iter() {
        v182_20_cursor.descend_to_existing_byte(v184_7_byte);
        {
        let v185_2: Space = singleton(&v182_20_cursor.path()[(v182_20_origin + 1)..(v182_20_origin + 2)]);
        let v185_3: Space = intersect(&(*CONSTANT_1),&(v185_2));
        let v185_4: Space = if has_head(&(v185_3)) { singleton(&[]) } else { Space::new() };
        drop(v185_3);
        let v185_5: Space = subtract(&(*CONSTANT_0),&(v185_4));
        drop(v185_4);
        let v185_8: Space = if (&(v185_5)).is_empty() { Space::new() } else {
          let v186_6: Path = concat_path(&(v184_6),&v182_20_cursor.path()[(v182_20_origin + 1)..(v182_20_origin + 2)]);
          let mut v186_7 = Space::new();
          let mut v186_7_write = v186_7.write_zipper();
          for v186_7_byte in v182_20_cursor.child_mask().iter() {
            v182_20_cursor.descend_to_existing_byte(v186_7_byte);
            {
            let v187_2: Space = singleton(&v182_20_cursor.path()[(v182_20_origin + 2)..(v182_20_origin + 3)]);
            let v187_3: Space = intersect(&(*CONSTANT_1),&(v187_2));
            let v187_4: Space = if has_head(&(v187_3)) { singleton(&[]) } else { Space::new() };
            drop(v187_3);
            let v187_5: Space = subtract(&(*CONSTANT_0),&(v187_4));
            drop(v187_4);
            let v187_8: Space = if (&(v187_5)).is_empty() { Space::new() } else {
              let v188_6: Path = concat_path(&(v186_6),&v182_20_cursor.path()[(v182_20_origin + 2)..(v182_20_origin + 3)]);
              let v188_7: Space = routine_22(c, &(v188_6), &v182_20_cursor);
              compose(&(v187_5),&(v188_7))
            };
            drop(v187_5);
            let v187_9: Space = intersect(&(*CONSTANT_1),&(v187_2));
            drop(v187_2);
            let v187_10: Space = if has_head(&(v187_9)) { singleton(&[]) } else { Space::new() };
            drop(v187_9);
            let v187_12: Space = if (&(v187_10)).is_empty() { Space::new() } else {
              let v189_6: Path = concat_path(&(v186_6),&v182_20_cursor.path()[(v182_20_origin + 2)..(v182_20_origin + 3)]);
              let v189_11: Space = routine_23(c, &(v189_6), &v182_20_cursor);
              drop(v189_6);
              compose(&(v187_10),&(v189_11))
            };
            drop(v187_10);
            let v187_13: Space = unite(&(v187_8),&(v187_12));
            join_wrapped_into(&mut v186_7_write,&((v187_13).read_zipper()),&[]);
            }
            v182_20_cursor.ascend(1);
          }
          drop(v186_7_write);
          compose(&(v185_5),&(v186_7))
        };
        drop(v185_5);
        let v185_9: Space = intersect(&(*CONSTANT_1),&(v185_2));
        drop(v185_2);
        let v185_10: Space = if has_head(&(v185_9)) { singleton(&[]) } else { Space::new() };
        drop(v185_9);
        let v185_12: Space = if (&(v185_10)).is_empty() { Space::new() } else {
          let v190_6: Path = concat_path(&(v184_6),&v182_20_cursor.path()[(v182_20_origin + 1)..(v182_20_origin + 2)]);
          let mut v190_11 = Space::new();
          let mut v190_11_write = v190_11.write_zipper();
          for v190_11_byte in v182_20_cursor.child_mask().iter() {
            v182_20_cursor.descend_to_existing_byte(v190_11_byte);
            {
            let v191_2: Space = singleton(&v182_20_cursor.path()[(v182_20_origin + 2)..(v182_20_origin + 3)]);
            let v191_3: Space = intersect(&(*CONSTANT_1),&(v191_2));
            let v191_4: Space = if has_head(&(v191_3)) { singleton(&[]) } else { Space::new() };
            drop(v191_3);
            let v191_5: Space = subtract(&(*CONSTANT_0),&(v191_4));
            drop(v191_4);
            let v191_8: Space = if (&(v191_5)).is_empty() { Space::new() } else {
              let v192_6: Path = concat_path(&(v190_6),&v182_20_cursor.path()[(v182_20_origin + 2)..(v182_20_origin + 3)]);
              let v192_7: Space = routine_22(c, &(v192_6), &v182_20_cursor);
              compose(&(v191_5),&(v192_7))
            };
            drop(v191_5);
            let v191_9: Space = intersect(&(*CONSTANT_1),&(v191_2));
            drop(v191_2);
            let v191_10: Space = if has_head(&(v191_9)) { singleton(&[]) } else { Space::new() };
            drop(v191_9);
            let v191_12: Space = if (&(v191_10)).is_empty() { Space::new() } else {
              let v193_6: Path = concat_path(&(v190_6),&v182_20_cursor.path()[(v182_20_origin + 2)..(v182_20_origin + 3)]);
              let v193_11: Space = routine_15(c, &(v193_6), &v182_20_cursor);
              drop(v193_6);
              compose(&(v191_10),&(v193_11))
            };
            drop(v191_10);
            let v191_13: Space = unite(&(v191_8),&(v191_12));
            join_wrapped_into(&mut v190_11_write,&((v191_13).read_zipper()),&[]);
            }
            v182_20_cursor.ascend(1);
          }
          drop(v190_11_write);
          drop(v190_6);
          compose(&(v185_10),&(v190_11))
        };
        drop(v185_10);
        let v185_13: Space = unite(&(v185_8),&(v185_12));
        join_wrapped_into(&mut v184_7_write,&((v185_13).read_zipper()),&[]);
        }
        v182_20_cursor.ascend(1);
      }
      drop(v184_7_write);
      compose(&(v183_5),&(v184_7))
    };
    drop(v183_5);
    let v183_9: Space = intersect(&(*CONSTANT_1),&(v183_2));
    drop(v183_2);
    let v183_10: Space = if has_head(&(v183_9)) { singleton(&[]) } else { Space::new() };
    drop(v183_9);
    let v183_12: Space = if (&(v183_10)).is_empty() { Space::new() } else {
      let v194_6: Path = concat_path(&(*p0),&v182_20_cursor.path()[v182_20_origin..(v182_20_origin + 1)]);
      let mut v194_11 = Space::new();
      let mut v194_11_write = v194_11.write_zipper();
      for v194_11_byte in v182_20_cursor.child_mask().iter() {
        v182_20_cursor.descend_to_existing_byte(v194_11_byte);
        {
        let v195_2: Space = singleton(&v182_20_cursor.path()[(v182_20_origin + 1)..(v182_20_origin + 2)]);
        let v195_3: Space = intersect(&(*CONSTANT_1),&(v195_2));
        let v195_4: Space = if has_head(&(v195_3)) { singleton(&[]) } else { Space::new() };
        drop(v195_3);
        let v195_5: Space = subtract(&(*CONSTANT_0),&(v195_4));
        drop(v195_4);
        let v195_8: Space = if (&(v195_5)).is_empty() { Space::new() } else {
          let v196_6: Path = concat_path(&(v194_6),&v182_20_cursor.path()[(v182_20_origin + 1)..(v182_20_origin + 2)]);
          let mut v196_7 = Space::new();
          let mut v196_7_write = v196_7.write_zipper();
          for v196_7_byte in v182_20_cursor.child_mask().iter() {
            v182_20_cursor.descend_to_existing_byte(v196_7_byte);
            {
            let v197_2: Space = singleton(&v182_20_cursor.path()[(v182_20_origin + 2)..(v182_20_origin + 3)]);
            let v197_3: Space = intersect(&(*CONSTANT_1),&(v197_2));
            let v197_4: Space = if has_head(&(v197_3)) { singleton(&[]) } else { Space::new() };
            drop(v197_3);
            let v197_5: Space = subtract(&(*CONSTANT_0),&(v197_4));
            drop(v197_4);
            let v197_8: Space = if (&(v197_5)).is_empty() { Space::new() } else {
              let v198_6: Path = concat_path(&(v196_6),&v182_20_cursor.path()[(v182_20_origin + 2)..(v182_20_origin + 3)]);
              let v198_7: Space = routine_22(c, &(v198_6), &v182_20_cursor);
              compose(&(v197_5),&(v198_7))
            };
            drop(v197_5);
            let v197_9: Space = intersect(&(*CONSTANT_1),&(v197_2));
            drop(v197_2);
            let v197_10: Space = if has_head(&(v197_9)) { singleton(&[]) } else { Space::new() };
            drop(v197_9);
            let v197_12: Space = if (&(v197_10)).is_empty() { Space::new() } else {
              let v199_6: Path = concat_path(&(v196_6),&v182_20_cursor.path()[(v182_20_origin + 2)..(v182_20_origin + 3)]);
              let v199_11: Space = routine_23(c, &(v199_6), &v182_20_cursor);
              drop(v199_6);
              compose(&(v197_10),&(v199_11))
            };
            drop(v197_10);
            let v197_13: Space = unite(&(v197_8),&(v197_12));
            join_wrapped_into(&mut v196_7_write,&((v197_13).read_zipper()),&[]);
            }
            v182_20_cursor.ascend(1);
          }
          drop(v196_7_write);
          drop(v196_6);
          compose(&(v195_5),&(v196_7))
        };
        drop(v195_5);
        let v195_9: Space = intersect(&(*CONSTANT_1),&(v195_2));
        drop(v195_2);
        let v195_10: Space = if has_head(&(v195_9)) { singleton(&[]) } else { Space::new() };
        drop(v195_9);
        let v195_11: Space = compose(&(v195_10),&v182_20_cursor);
        drop(v195_10);
        let v195_12: Space = unite(&(v195_8),&(v195_11));
        drop(v195_11);
        join_wrapped_into(&mut v194_11_write,&((v195_12).read_zipper()),&[]);
        }
        v182_20_cursor.ascend(1);
      }
      drop(v194_11_write);
      drop(v194_6);
      compose(&(v183_10),&(v194_11))
    };
    drop(v183_10);
    let v183_13: Space = unite(&(v183_8),&(v183_12));
    join_wrapped_into(&mut v182_20_write,&((v183_13).read_zipper()),&[]);
    }
    v182_20_cursor.ascend(1);
  }
  drop(v182_20_cursor);
  drop(v182_20_write);
  (v182_20).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v200_14 = Space::new();
  let mut v200_14_write = v200_14.write_zipper();
  let mut v200_14_cursor = (*s0).read_zipper();
  let v200_14_origin = v200_14_cursor.path().len();
  for v200_14_byte in v200_14_cursor.child_mask().iter() {
    v200_14_cursor.descend_to_existing_byte(v200_14_byte);
    {
    let v201_2: Space = singleton(&v200_14_cursor.path()[v200_14_origin..(v200_14_origin + 1)]);
    let v201_3: Space = intersect(&(*CONSTANT_1),&(v201_2));
    let v201_4: Space = if has_head(&(v201_3)) { singleton(&[]) } else { Space::new() };
    drop(v201_3);
    let v201_5: Space = subtract(&(*CONSTANT_0),&(v201_4));
    drop(v201_4);
    let v201_8: Space = if (&(v201_5)).is_empty() { Space::new() } else {
      let v202_6: Path = concat_path(&(*p0),&v200_14_cursor.path()[v200_14_origin..(v200_14_origin + 1)]);
      let mut v202_7 = Space::new();
      let mut v202_7_write = v202_7.write_zipper();
      for v202_7_byte in v200_14_cursor.child_mask().iter() {
        v200_14_cursor.descend_to_existing_byte(v202_7_byte);
        {
        let v203_2: Space = singleton(&v200_14_cursor.path()[(v200_14_origin + 1)..(v200_14_origin + 2)]);
        let v203_3: Space = intersect(&(*CONSTANT_1),&(v203_2));
        let v203_4: Space = if has_head(&(v203_3)) { singleton(&[]) } else { Space::new() };
        drop(v203_3);
        let v203_5: Space = subtract(&(*CONSTANT_0),&(v203_4));
        drop(v203_4);
        let v203_8: Space = if (&(v203_5)).is_empty() { Space::new() } else {
          let v204_6: Path = concat_path(&(v202_6),&v200_14_cursor.path()[(v200_14_origin + 1)..(v200_14_origin + 2)]);
          let mut v204_7 = Space::new();
          let mut v204_7_write = v204_7.write_zipper();
          for v204_7_byte in v200_14_cursor.child_mask().iter() {
            v200_14_cursor.descend_to_existing_byte(v204_7_byte);
            {
            let v205_2: Space = singleton(&v200_14_cursor.path()[(v200_14_origin + 2)..(v200_14_origin + 3)]);
            let v205_3: Space = intersect(&(*CONSTANT_1),&(v205_2));
            let v205_4: Space = if has_head(&(v205_3)) { singleton(&[]) } else { Space::new() };
            drop(v205_3);
            let v205_5: Space = subtract(&(*CONSTANT_0),&(v205_4));
            drop(v205_4);
            let v205_8: Space = if (&(v205_5)).is_empty() { Space::new() } else {
              let v206_6: Path = concat_path(&(v204_6),&v200_14_cursor.path()[(v200_14_origin + 2)..(v200_14_origin + 3)]);
              let v206_7: Space = routine_22(c, &(v206_6), &v200_14_cursor);
              compose(&(v205_5),&(v206_7))
            };
            drop(v205_5);
            let v205_9: Space = intersect(&(*CONSTANT_1),&(v205_2));
            drop(v205_2);
            let v205_10: Space = if has_head(&(v205_9)) { singleton(&[]) } else { Space::new() };
            drop(v205_9);
            let v205_12: Space = if (&(v205_10)).is_empty() { Space::new() } else {
              let v207_6: Path = concat_path(&(v204_6),&v200_14_cursor.path()[(v200_14_origin + 2)..(v200_14_origin + 3)]);
              let v207_11: Space = routine_23(c, &(v207_6), &v200_14_cursor);
              drop(v207_6);
              compose(&(v205_10),&(v207_11))
            };
            drop(v205_10);
            let v205_13: Space = unite(&(v205_8),&(v205_12));
            join_wrapped_into(&mut v204_7_write,&((v205_13).read_zipper()),&[]);
            }
            v200_14_cursor.ascend(1);
          }
          drop(v204_7_write);
          compose(&(v203_5),&(v204_7))
        };
        drop(v203_5);
        let v203_9: Space = intersect(&(*CONSTANT_1),&(v203_2));
        drop(v203_2);
        let v203_10: Space = if has_head(&(v203_9)) { singleton(&[]) } else { Space::new() };
        drop(v203_9);
        let v203_12: Space = if (&(v203_10)).is_empty() { Space::new() } else {
          let v208_6: Path = concat_path(&(v202_6),&v200_14_cursor.path()[(v200_14_origin + 1)..(v200_14_origin + 2)]);
          let mut v208_11 = Space::new();
          let mut v208_11_write = v208_11.write_zipper();
          for v208_11_byte in v200_14_cursor.child_mask().iter() {
            v200_14_cursor.descend_to_existing_byte(v208_11_byte);
            {
            let v209_2: Space = singleton(&v200_14_cursor.path()[(v200_14_origin + 2)..(v200_14_origin + 3)]);
            let v209_3: Space = intersect(&(*CONSTANT_1),&(v209_2));
            let v209_4: Space = if has_head(&(v209_3)) { singleton(&[]) } else { Space::new() };
            drop(v209_3);
            let v209_5: Space = subtract(&(*CONSTANT_0),&(v209_4));
            drop(v209_4);
            let v209_8: Space = if (&(v209_5)).is_empty() { Space::new() } else {
              let v210_6: Path = concat_path(&(v208_6),&v200_14_cursor.path()[(v200_14_origin + 2)..(v200_14_origin + 3)]);
              let v210_7: Space = routine_22(c, &(v210_6), &v200_14_cursor);
              compose(&(v209_5),&(v210_7))
            };
            drop(v209_5);
            let v209_9: Space = intersect(&(*CONSTANT_1),&(v209_2));
            drop(v209_2);
            let v209_10: Space = if has_head(&(v209_9)) { singleton(&[]) } else { Space::new() };
            drop(v209_9);
            let v209_12: Space = if (&(v209_10)).is_empty() { Space::new() } else {
              let v211_6: Path = concat_path(&(v208_6),&v200_14_cursor.path()[(v200_14_origin + 2)..(v200_14_origin + 3)]);
              let v211_11: Space = routine_15(c, &(v211_6), &v200_14_cursor);
              drop(v211_6);
              compose(&(v209_10),&(v211_11))
            };
            drop(v209_10);
            let v209_13: Space = unite(&(v209_8),&(v209_12));
            join_wrapped_into(&mut v208_11_write,&((v209_13).read_zipper()),&[]);
            }
            v200_14_cursor.ascend(1);
          }
          drop(v208_11_write);
          drop(v208_6);
          compose(&(v203_10),&(v208_11))
        };
        drop(v203_10);
        let v203_13: Space = unite(&(v203_8),&(v203_12));
        join_wrapped_into(&mut v202_7_write,&((v203_13).read_zipper()),&[]);
        }
        v200_14_cursor.ascend(1);
      }
      drop(v202_7_write);
      drop(v202_6);
      compose(&(v201_5),&(v202_7))
    };
    drop(v201_5);
    let v201_9: Space = intersect(&(*CONSTANT_1),&(v201_2));
    drop(v201_2);
    let v201_10: Space = if has_head(&(v201_9)) { singleton(&[]) } else { Space::new() };
    drop(v201_9);
    let v201_11: Space = compose(&(v201_10),&v200_14_cursor);
    drop(v201_10);
    let v201_12: Space = unite(&(v201_8),&(v201_11));
    drop(v201_11);
    join_wrapped_into(&mut v200_14_write,&((v201_12).read_zipper()),&[]);
    }
    v200_14_cursor.ascend(1);
  }
  drop(v200_14_cursor);
  drop(v200_14_write);
  (v200_14).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v212_20 = Space::new();
  let mut v212_20_write = v212_20.write_zipper();
  let mut v212_20_cursor = (*s0).read_zipper();
  let v212_20_origin = v212_20_cursor.path().len();
  for v212_20_byte in v212_20_cursor.child_mask().iter() {
    v212_20_cursor.descend_to_existing_byte(v212_20_byte);
    {
    let v213_2: Space = singleton(&v212_20_cursor.path()[v212_20_origin..(v212_20_origin + 1)]);
    let v213_3: Space = intersect(&(*CONSTANT_1),&(v213_2));
    let v213_4: Space = if has_head(&(v213_3)) { singleton(&[]) } else { Space::new() };
    drop(v213_3);
    let v213_5: Space = subtract(&(*CONSTANT_0),&(v213_4));
    drop(v213_4);
    let v213_8: Space = if (&(v213_5)).is_empty() { Space::new() } else {
      let v214_6: Path = concat_path(&(*p0),&v212_20_cursor.path()[v212_20_origin..(v212_20_origin + 1)]);
      let mut v214_7 = Space::new();
      let mut v214_7_write = v214_7.write_zipper();
      for v214_7_byte in v212_20_cursor.child_mask().iter() {
        v212_20_cursor.descend_to_existing_byte(v214_7_byte);
        {
        let v215_2: Space = singleton(&v212_20_cursor.path()[(v212_20_origin + 1)..(v212_20_origin + 2)]);
        let v215_3: Space = intersect(&(*CONSTANT_1),&(v215_2));
        let v215_4: Space = if has_head(&(v215_3)) { singleton(&[]) } else { Space::new() };
        drop(v215_3);
        let v215_5: Space = subtract(&(*CONSTANT_0),&(v215_4));
        drop(v215_4);
        let v215_8: Space = if (&(v215_5)).is_empty() { Space::new() } else {
          let v216_6: Path = concat_path(&(v214_6),&v212_20_cursor.path()[(v212_20_origin + 1)..(v212_20_origin + 2)]);
          let mut v216_7 = Space::new();
          let mut v216_7_write = v216_7.write_zipper();
          for v216_7_byte in v212_20_cursor.child_mask().iter() {
            v212_20_cursor.descend_to_existing_byte(v216_7_byte);
            {
            let v217_2: Space = singleton(&v212_20_cursor.path()[(v212_20_origin + 2)..(v212_20_origin + 3)]);
            let v217_3: Space = intersect(&(*CONSTANT_1),&(v217_2));
            let v217_4: Space = if has_head(&(v217_3)) { singleton(&[]) } else { Space::new() };
            drop(v217_3);
            let v217_5: Space = subtract(&(*CONSTANT_0),&(v217_4));
            drop(v217_4);
            let v217_8: Space = if (&(v217_5)).is_empty() { Space::new() } else {
              let v218_6: Path = concat_path(&(v216_6),&v212_20_cursor.path()[(v212_20_origin + 2)..(v212_20_origin + 3)]);
              let v218_7: Space = routine_24(c, &(v218_6), &v212_20_cursor);
              compose(&(v217_5),&(v218_7))
            };
            drop(v217_5);
            let v217_9: Space = intersect(&(*CONSTANT_1),&(v217_2));
            drop(v217_2);
            let v217_10: Space = if has_head(&(v217_9)) { singleton(&[]) } else { Space::new() };
            drop(v217_9);
            let v217_12: Space = if (&(v217_10)).is_empty() { Space::new() } else {
              let v219_6: Path = concat_path(&(v216_6),&v212_20_cursor.path()[(v212_20_origin + 2)..(v212_20_origin + 3)]);
              let v219_11: Space = routine_25(c, &(v219_6), &v212_20_cursor);
              drop(v219_6);
              compose(&(v217_10),&(v219_11))
            };
            drop(v217_10);
            let v217_13: Space = unite(&(v217_8),&(v217_12));
            join_wrapped_into(&mut v216_7_write,&((v217_13).read_zipper()),&[]);
            }
            v212_20_cursor.ascend(1);
          }
          drop(v216_7_write);
          compose(&(v215_5),&(v216_7))
        };
        drop(v215_5);
        let v215_9: Space = intersect(&(*CONSTANT_1),&(v215_2));
        drop(v215_2);
        let v215_10: Space = if has_head(&(v215_9)) { singleton(&[]) } else { Space::new() };
        drop(v215_9);
        let v215_12: Space = if (&(v215_10)).is_empty() { Space::new() } else {
          let v220_6: Path = concat_path(&(v214_6),&v212_20_cursor.path()[(v212_20_origin + 1)..(v212_20_origin + 2)]);
          let mut v220_11 = Space::new();
          let mut v220_11_write = v220_11.write_zipper();
          for v220_11_byte in v212_20_cursor.child_mask().iter() {
            v212_20_cursor.descend_to_existing_byte(v220_11_byte);
            {
            let v221_2: Space = singleton(&v212_20_cursor.path()[(v212_20_origin + 2)..(v212_20_origin + 3)]);
            let v221_3: Space = intersect(&(*CONSTANT_1),&(v221_2));
            let v221_4: Space = if has_head(&(v221_3)) { singleton(&[]) } else { Space::new() };
            drop(v221_3);
            let v221_5: Space = subtract(&(*CONSTANT_0),&(v221_4));
            drop(v221_4);
            let v221_8: Space = if (&(v221_5)).is_empty() { Space::new() } else {
              let v222_6: Path = concat_path(&(v220_6),&v212_20_cursor.path()[(v212_20_origin + 2)..(v212_20_origin + 3)]);
              let v222_7: Space = routine_24(c, &(v222_6), &v212_20_cursor);
              compose(&(v221_5),&(v222_7))
            };
            drop(v221_5);
            let v221_9: Space = intersect(&(*CONSTANT_1),&(v221_2));
            drop(v221_2);
            let v221_10: Space = if has_head(&(v221_9)) { singleton(&[]) } else { Space::new() };
            drop(v221_9);
            let v221_12: Space = if (&(v221_10)).is_empty() { Space::new() } else {
              let v223_6: Path = concat_path(&(v220_6),&v212_20_cursor.path()[(v212_20_origin + 2)..(v212_20_origin + 3)]);
              let v223_11: Space = routine_12(c, &(v223_6), &v212_20_cursor);
              drop(v223_6);
              compose(&(v221_10),&(v223_11))
            };
            drop(v221_10);
            let v221_13: Space = unite(&(v221_8),&(v221_12));
            join_wrapped_into(&mut v220_11_write,&((v221_13).read_zipper()),&[]);
            }
            v212_20_cursor.ascend(1);
          }
          drop(v220_11_write);
          drop(v220_6);
          compose(&(v215_10),&(v220_11))
        };
        drop(v215_10);
        let v215_13: Space = unite(&(v215_8),&(v215_12));
        join_wrapped_into(&mut v214_7_write,&((v215_13).read_zipper()),&[]);
        }
        v212_20_cursor.ascend(1);
      }
      drop(v214_7_write);
      compose(&(v213_5),&(v214_7))
    };
    drop(v213_5);
    let v213_9: Space = intersect(&(*CONSTANT_1),&(v213_2));
    drop(v213_2);
    let v213_10: Space = if has_head(&(v213_9)) { singleton(&[]) } else { Space::new() };
    drop(v213_9);
    let v213_12: Space = if (&(v213_10)).is_empty() { Space::new() } else {
      let v224_6: Path = concat_path(&(*p0),&v212_20_cursor.path()[v212_20_origin..(v212_20_origin + 1)]);
      let mut v224_11 = Space::new();
      let mut v224_11_write = v224_11.write_zipper();
      for v224_11_byte in v212_20_cursor.child_mask().iter() {
        v212_20_cursor.descend_to_existing_byte(v224_11_byte);
        {
        let v225_2: Space = singleton(&v212_20_cursor.path()[(v212_20_origin + 1)..(v212_20_origin + 2)]);
        let v225_3: Space = intersect(&(*CONSTANT_1),&(v225_2));
        let v225_4: Space = if has_head(&(v225_3)) { singleton(&[]) } else { Space::new() };
        drop(v225_3);
        let v225_5: Space = subtract(&(*CONSTANT_0),&(v225_4));
        drop(v225_4);
        let v225_8: Space = if (&(v225_5)).is_empty() { Space::new() } else {
          let v226_6: Path = concat_path(&(v224_6),&v212_20_cursor.path()[(v212_20_origin + 1)..(v212_20_origin + 2)]);
          let mut v226_7 = Space::new();
          let mut v226_7_write = v226_7.write_zipper();
          for v226_7_byte in v212_20_cursor.child_mask().iter() {
            v212_20_cursor.descend_to_existing_byte(v226_7_byte);
            {
            let v227_2: Space = singleton(&v212_20_cursor.path()[(v212_20_origin + 2)..(v212_20_origin + 3)]);
            let v227_3: Space = intersect(&(*CONSTANT_1),&(v227_2));
            let v227_4: Space = if has_head(&(v227_3)) { singleton(&[]) } else { Space::new() };
            drop(v227_3);
            let v227_5: Space = subtract(&(*CONSTANT_0),&(v227_4));
            drop(v227_4);
            let v227_8: Space = if (&(v227_5)).is_empty() { Space::new() } else {
              let v228_6: Path = concat_path(&(v226_6),&v212_20_cursor.path()[(v212_20_origin + 2)..(v212_20_origin + 3)]);
              let v228_7: Space = routine_24(c, &(v228_6), &v212_20_cursor);
              compose(&(v227_5),&(v228_7))
            };
            drop(v227_5);
            let v227_9: Space = intersect(&(*CONSTANT_1),&(v227_2));
            drop(v227_2);
            let v227_10: Space = if has_head(&(v227_9)) { singleton(&[]) } else { Space::new() };
            drop(v227_9);
            let v227_12: Space = if (&(v227_10)).is_empty() { Space::new() } else {
              let v229_6: Path = concat_path(&(v226_6),&v212_20_cursor.path()[(v212_20_origin + 2)..(v212_20_origin + 3)]);
              let v229_11: Space = routine_25(c, &(v229_6), &v212_20_cursor);
              drop(v229_6);
              compose(&(v227_10),&(v229_11))
            };
            drop(v227_10);
            let v227_13: Space = unite(&(v227_8),&(v227_12));
            join_wrapped_into(&mut v226_7_write,&((v227_13).read_zipper()),&[]);
            }
            v212_20_cursor.ascend(1);
          }
          drop(v226_7_write);
          drop(v226_6);
          compose(&(v225_5),&(v226_7))
        };
        drop(v225_5);
        let v225_9: Space = intersect(&(*CONSTANT_1),&(v225_2));
        drop(v225_2);
        let v225_10: Space = if has_head(&(v225_9)) { singleton(&[]) } else { Space::new() };
        drop(v225_9);
        let v225_11: Space = compose(&(v225_10),&v212_20_cursor);
        drop(v225_10);
        let v225_12: Space = unite(&(v225_8),&(v225_11));
        drop(v225_11);
        join_wrapped_into(&mut v224_11_write,&((v225_12).read_zipper()),&[]);
        }
        v212_20_cursor.ascend(1);
      }
      drop(v224_11_write);
      drop(v224_6);
      compose(&(v213_10),&(v224_11))
    };
    drop(v213_10);
    let v213_13: Space = unite(&(v213_8),&(v213_12));
    join_wrapped_into(&mut v212_20_write,&((v213_13).read_zipper()),&[]);
    }
    v212_20_cursor.ascend(1);
  }
  drop(v212_20_cursor);
  drop(v212_20_write);
  (v212_20).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v230_14 = Space::new();
  let mut v230_14_write = v230_14.write_zipper();
  let mut v230_14_cursor = (*s0).read_zipper();
  let v230_14_origin = v230_14_cursor.path().len();
  for v230_14_byte in v230_14_cursor.child_mask().iter() {
    v230_14_cursor.descend_to_existing_byte(v230_14_byte);
    {
    let v231_2: Space = singleton(&v230_14_cursor.path()[v230_14_origin..(v230_14_origin + 1)]);
    let v231_3: Space = intersect(&(*CONSTANT_1),&(v231_2));
    let v231_4: Space = if has_head(&(v231_3)) { singleton(&[]) } else { Space::new() };
    drop(v231_3);
    let v231_5: Space = subtract(&(*CONSTANT_0),&(v231_4));
    drop(v231_4);
    let v231_8: Space = if (&(v231_5)).is_empty() { Space::new() } else {
      let v232_6: Path = concat_path(&(*p0),&v230_14_cursor.path()[v230_14_origin..(v230_14_origin + 1)]);
      let mut v232_7 = Space::new();
      let mut v232_7_write = v232_7.write_zipper();
      for v232_7_byte in v230_14_cursor.child_mask().iter() {
        v230_14_cursor.descend_to_existing_byte(v232_7_byte);
        {
        let v233_2: Space = singleton(&v230_14_cursor.path()[(v230_14_origin + 1)..(v230_14_origin + 2)]);
        let v233_3: Space = intersect(&(*CONSTANT_1),&(v233_2));
        let v233_4: Space = if has_head(&(v233_3)) { singleton(&[]) } else { Space::new() };
        drop(v233_3);
        let v233_5: Space = subtract(&(*CONSTANT_0),&(v233_4));
        drop(v233_4);
        let v233_8: Space = if (&(v233_5)).is_empty() { Space::new() } else {
          let v234_6: Path = concat_path(&(v232_6),&v230_14_cursor.path()[(v230_14_origin + 1)..(v230_14_origin + 2)]);
          let mut v234_7 = Space::new();
          let mut v234_7_write = v234_7.write_zipper();
          for v234_7_byte in v230_14_cursor.child_mask().iter() {
            v230_14_cursor.descend_to_existing_byte(v234_7_byte);
            {
            let v235_2: Space = singleton(&v230_14_cursor.path()[(v230_14_origin + 2)..(v230_14_origin + 3)]);
            let v235_3: Space = intersect(&(*CONSTANT_1),&(v235_2));
            let v235_4: Space = if has_head(&(v235_3)) { singleton(&[]) } else { Space::new() };
            drop(v235_3);
            let v235_5: Space = subtract(&(*CONSTANT_0),&(v235_4));
            drop(v235_4);
            let v235_8: Space = if (&(v235_5)).is_empty() { Space::new() } else {
              let v236_6: Path = concat_path(&(v234_6),&v230_14_cursor.path()[(v230_14_origin + 2)..(v230_14_origin + 3)]);
              let v236_7: Space = routine_24(c, &(v236_6), &v230_14_cursor);
              compose(&(v235_5),&(v236_7))
            };
            drop(v235_5);
            let v235_9: Space = intersect(&(*CONSTANT_1),&(v235_2));
            drop(v235_2);
            let v235_10: Space = if has_head(&(v235_9)) { singleton(&[]) } else { Space::new() };
            drop(v235_9);
            let v235_12: Space = if (&(v235_10)).is_empty() { Space::new() } else {
              let v237_6: Path = concat_path(&(v234_6),&v230_14_cursor.path()[(v230_14_origin + 2)..(v230_14_origin + 3)]);
              let v237_11: Space = routine_25(c, &(v237_6), &v230_14_cursor);
              drop(v237_6);
              compose(&(v235_10),&(v237_11))
            };
            drop(v235_10);
            let v235_13: Space = unite(&(v235_8),&(v235_12));
            join_wrapped_into(&mut v234_7_write,&((v235_13).read_zipper()),&[]);
            }
            v230_14_cursor.ascend(1);
          }
          drop(v234_7_write);
          compose(&(v233_5),&(v234_7))
        };
        drop(v233_5);
        let v233_9: Space = intersect(&(*CONSTANT_1),&(v233_2));
        drop(v233_2);
        let v233_10: Space = if has_head(&(v233_9)) { singleton(&[]) } else { Space::new() };
        drop(v233_9);
        let v233_12: Space = if (&(v233_10)).is_empty() { Space::new() } else {
          let v238_6: Path = concat_path(&(v232_6),&v230_14_cursor.path()[(v230_14_origin + 1)..(v230_14_origin + 2)]);
          let mut v238_11 = Space::new();
          let mut v238_11_write = v238_11.write_zipper();
          for v238_11_byte in v230_14_cursor.child_mask().iter() {
            v230_14_cursor.descend_to_existing_byte(v238_11_byte);
            {
            let v239_2: Space = singleton(&v230_14_cursor.path()[(v230_14_origin + 2)..(v230_14_origin + 3)]);
            let v239_3: Space = intersect(&(*CONSTANT_1),&(v239_2));
            let v239_4: Space = if has_head(&(v239_3)) { singleton(&[]) } else { Space::new() };
            drop(v239_3);
            let v239_5: Space = subtract(&(*CONSTANT_0),&(v239_4));
            drop(v239_4);
            let v239_8: Space = if (&(v239_5)).is_empty() { Space::new() } else {
              let v240_6: Path = concat_path(&(v238_6),&v230_14_cursor.path()[(v230_14_origin + 2)..(v230_14_origin + 3)]);
              let v240_7: Space = routine_24(c, &(v240_6), &v230_14_cursor);
              compose(&(v239_5),&(v240_7))
            };
            drop(v239_5);
            let v239_9: Space = intersect(&(*CONSTANT_1),&(v239_2));
            drop(v239_2);
            let v239_10: Space = if has_head(&(v239_9)) { singleton(&[]) } else { Space::new() };
            drop(v239_9);
            let v239_12: Space = if (&(v239_10)).is_empty() { Space::new() } else {
              let v241_6: Path = concat_path(&(v238_6),&v230_14_cursor.path()[(v230_14_origin + 2)..(v230_14_origin + 3)]);
              let v241_11: Space = routine_12(c, &(v241_6), &v230_14_cursor);
              drop(v241_6);
              compose(&(v239_10),&(v241_11))
            };
            drop(v239_10);
            let v239_13: Space = unite(&(v239_8),&(v239_12));
            join_wrapped_into(&mut v238_11_write,&((v239_13).read_zipper()),&[]);
            }
            v230_14_cursor.ascend(1);
          }
          drop(v238_11_write);
          drop(v238_6);
          compose(&(v233_10),&(v238_11))
        };
        drop(v233_10);
        let v233_13: Space = unite(&(v233_8),&(v233_12));
        join_wrapped_into(&mut v232_7_write,&((v233_13).read_zipper()),&[]);
        }
        v230_14_cursor.ascend(1);
      }
      drop(v232_7_write);
      drop(v232_6);
      compose(&(v231_5),&(v232_7))
    };
    drop(v231_5);
    let v231_9: Space = intersect(&(*CONSTANT_1),&(v231_2));
    drop(v231_2);
    let v231_10: Space = if has_head(&(v231_9)) { singleton(&[]) } else { Space::new() };
    drop(v231_9);
    let v231_11: Space = compose(&(v231_10),&v230_14_cursor);
    drop(v231_10);
    let v231_12: Space = unite(&(v231_8),&(v231_11));
    drop(v231_11);
    join_wrapped_into(&mut v230_14_write,&((v231_12).read_zipper()),&[]);
    }
    v230_14_cursor.ascend(1);
  }
  drop(v230_14_cursor);
  drop(v230_14_write);
  (v230_14).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v243_20 = Space::new();
  let mut v243_20_write = v243_20.write_zipper();
  let mut v243_20_cursor = (*s0).read_zipper();
  let v243_20_origin = v243_20_cursor.path().len();
  for v243_20_byte in v243_20_cursor.child_mask().iter() {
    v243_20_cursor.descend_to_existing_byte(v243_20_byte);
    {
    let v244_2: Space = singleton(&v243_20_cursor.path()[v243_20_origin..(v243_20_origin + 1)]);
    let v244_3: Space = intersect(&(*CONSTANT_1),&(v244_2));
    let v244_4: Space = if has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
    drop(v244_3);
    let v244_5: Space = subtract(&(*CONSTANT_0),&(v244_4));
    drop(v244_4);
    let v244_8: Space = if (&(v244_5)).is_empty() { Space::new() } else {
      let v245_6: Path = concat_path(&(*p0),&v243_20_cursor.path()[v243_20_origin..(v243_20_origin + 1)]);
      let mut v245_7 = Space::new();
      let mut v245_7_write = v245_7.write_zipper();
      for v245_7_byte in v243_20_cursor.child_mask().iter() {
        v243_20_cursor.descend_to_existing_byte(v245_7_byte);
        {
        let v246_2: Space = singleton(&v243_20_cursor.path()[(v243_20_origin + 1)..(v243_20_origin + 2)]);
        let v246_3: Space = intersect(&(*CONSTANT_1),&(v246_2));
        let v246_4: Space = if has_head(&(v246_3)) { singleton(&[]) } else { Space::new() };
        drop(v246_3);
        let v246_5: Space = subtract(&(*CONSTANT_0),&(v246_4));
        drop(v246_4);
        let v246_8: Space = if (&(v246_5)).is_empty() { Space::new() } else {
          let v247_6: Path = concat_path(&(v245_6),&v243_20_cursor.path()[(v243_20_origin + 1)..(v243_20_origin + 2)]);
          let mut v247_7 = Space::new();
          let mut v247_7_write = v247_7.write_zipper();
          for v247_7_byte in v243_20_cursor.child_mask().iter() {
            v243_20_cursor.descend_to_existing_byte(v247_7_byte);
            {
            let v248_2: Space = singleton(&v243_20_cursor.path()[(v243_20_origin + 2)..(v243_20_origin + 3)]);
            let v248_3: Space = intersect(&(*CONSTANT_1),&(v248_2));
            let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
            drop(v248_3);
            let v248_5: Space = subtract(&(*CONSTANT_0),&(v248_4));
            drop(v248_4);
            let v248_8: Space = if (&(v248_5)).is_empty() { Space::new() } else {
              let v249_6: Path = concat_path(&(v247_6),&v243_20_cursor.path()[(v243_20_origin + 2)..(v243_20_origin + 3)]);
              let v249_7: Space = routine_26(c, &(v249_6), &v243_20_cursor);
              compose(&(v248_5),&(v249_7))
            };
            drop(v248_5);
            let v248_9: Space = intersect(&(*CONSTANT_1),&(v248_2));
            drop(v248_2);
            let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
            drop(v248_9);
            let v248_12: Space = if (&(v248_10)).is_empty() { Space::new() } else {
              let v250_6: Path = concat_path(&(v247_6),&v243_20_cursor.path()[(v243_20_origin + 2)..(v243_20_origin + 3)]);
              let v250_11: Space = routine_27(c, &(v250_6), &v243_20_cursor);
              drop(v250_6);
              compose(&(v248_10),&(v250_11))
            };
            drop(v248_10);
            let v248_13: Space = unite(&(v248_8),&(v248_12));
            join_wrapped_into(&mut v247_7_write,&((v248_13).read_zipper()),&[]);
            }
            v243_20_cursor.ascend(1);
          }
          drop(v247_7_write);
          compose(&(v246_5),&(v247_7))
        };
        drop(v246_5);
        let v246_9: Space = intersect(&(*CONSTANT_1),&(v246_2));
        drop(v246_2);
        let v246_10: Space = if has_head(&(v246_9)) { singleton(&[]) } else { Space::new() };
        drop(v246_9);
        let v246_12: Space = if (&(v246_10)).is_empty() { Space::new() } else {
          let v251_6: Path = concat_path(&(v245_6),&v243_20_cursor.path()[(v243_20_origin + 1)..(v243_20_origin + 2)]);
          let mut v251_11 = Space::new();
          let mut v251_11_write = v251_11.write_zipper();
          for v251_11_byte in v243_20_cursor.child_mask().iter() {
            v243_20_cursor.descend_to_existing_byte(v251_11_byte);
            {
            let v252_2: Space = singleton(&v243_20_cursor.path()[(v243_20_origin + 2)..(v243_20_origin + 3)]);
            let v252_3: Space = intersect(&(*CONSTANT_1),&(v252_2));
            let v252_4: Space = if has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
            drop(v252_3);
            let v252_5: Space = subtract(&(*CONSTANT_0),&(v252_4));
            drop(v252_4);
            let v252_8: Space = if (&(v252_5)).is_empty() { Space::new() } else {
              let v253_6: Path = concat_path(&(v251_6),&v243_20_cursor.path()[(v243_20_origin + 2)..(v243_20_origin + 3)]);
              let v253_7: Space = routine_26(c, &(v253_6), &v243_20_cursor);
              compose(&(v252_5),&(v253_7))
            };
            drop(v252_5);
            let v252_9: Space = intersect(&(*CONSTANT_1),&(v252_2));
            drop(v252_2);
            let v252_10: Space = if has_head(&(v252_9)) { singleton(&[]) } else { Space::new() };
            drop(v252_9);
            let v252_12: Space = if (&(v252_10)).is_empty() { Space::new() } else {
              let v254_6: Path = concat_path(&(v251_6),&v243_20_cursor.path()[(v243_20_origin + 2)..(v243_20_origin + 3)]);
              let v254_11: Space = routine_15(c, &(v254_6), &v243_20_cursor);
              drop(v254_6);
              compose(&(v252_10),&(v254_11))
            };
            drop(v252_10);
            let v252_13: Space = unite(&(v252_8),&(v252_12));
            join_wrapped_into(&mut v251_11_write,&((v252_13).read_zipper()),&[]);
            }
            v243_20_cursor.ascend(1);
          }
          drop(v251_11_write);
          drop(v251_6);
          compose(&(v246_10),&(v251_11))
        };
        drop(v246_10);
        let v246_13: Space = unite(&(v246_8),&(v246_12));
        join_wrapped_into(&mut v245_7_write,&((v246_13).read_zipper()),&[]);
        }
        v243_20_cursor.ascend(1);
      }
      drop(v245_7_write);
      compose(&(v244_5),&(v245_7))
    };
    drop(v244_5);
    let v244_9: Space = intersect(&(*CONSTANT_1),&(v244_2));
    drop(v244_2);
    let v244_10: Space = if has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
    drop(v244_9);
    let v244_12: Space = if (&(v244_10)).is_empty() { Space::new() } else {
      let v255_6: Path = concat_path(&(*p0),&v243_20_cursor.path()[v243_20_origin..(v243_20_origin + 1)]);
      let mut v255_11 = Space::new();
      let mut v255_11_write = v255_11.write_zipper();
      for v255_11_byte in v243_20_cursor.child_mask().iter() {
        v243_20_cursor.descend_to_existing_byte(v255_11_byte);
        {
        let v256_2: Space = singleton(&v243_20_cursor.path()[(v243_20_origin + 1)..(v243_20_origin + 2)]);
        let v256_3: Space = intersect(&(*CONSTANT_1),&(v256_2));
        let v256_4: Space = if has_head(&(v256_3)) { singleton(&[]) } else { Space::new() };
        drop(v256_3);
        let v256_5: Space = subtract(&(*CONSTANT_0),&(v256_4));
        drop(v256_4);
        let v256_8: Space = if (&(v256_5)).is_empty() { Space::new() } else {
          let v257_6: Path = concat_path(&(v255_6),&v243_20_cursor.path()[(v243_20_origin + 1)..(v243_20_origin + 2)]);
          let mut v257_7 = Space::new();
          let mut v257_7_write = v257_7.write_zipper();
          for v257_7_byte in v243_20_cursor.child_mask().iter() {
            v243_20_cursor.descend_to_existing_byte(v257_7_byte);
            {
            let v258_2: Space = singleton(&v243_20_cursor.path()[(v243_20_origin + 2)..(v243_20_origin + 3)]);
            let v258_3: Space = intersect(&(*CONSTANT_1),&(v258_2));
            let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
            drop(v258_3);
            let v258_5: Space = subtract(&(*CONSTANT_0),&(v258_4));
            drop(v258_4);
            let v258_8: Space = if (&(v258_5)).is_empty() { Space::new() } else {
              let v259_6: Path = concat_path(&(v257_6),&v243_20_cursor.path()[(v243_20_origin + 2)..(v243_20_origin + 3)]);
              let v259_7: Space = routine_26(c, &(v259_6), &v243_20_cursor);
              compose(&(v258_5),&(v259_7))
            };
            drop(v258_5);
            let v258_9: Space = intersect(&(*CONSTANT_1),&(v258_2));
            drop(v258_2);
            let v258_10: Space = if has_head(&(v258_9)) { singleton(&[]) } else { Space::new() };
            drop(v258_9);
            let v258_12: Space = if (&(v258_10)).is_empty() { Space::new() } else {
              let v260_6: Path = concat_path(&(v257_6),&v243_20_cursor.path()[(v243_20_origin + 2)..(v243_20_origin + 3)]);
              let v260_11: Space = routine_27(c, &(v260_6), &v243_20_cursor);
              drop(v260_6);
              compose(&(v258_10),&(v260_11))
            };
            drop(v258_10);
            let v258_13: Space = unite(&(v258_8),&(v258_12));
            join_wrapped_into(&mut v257_7_write,&((v258_13).read_zipper()),&[]);
            }
            v243_20_cursor.ascend(1);
          }
          drop(v257_7_write);
          drop(v257_6);
          compose(&(v256_5),&(v257_7))
        };
        drop(v256_5);
        let v256_9: Space = intersect(&(*CONSTANT_1),&(v256_2));
        drop(v256_2);
        let v256_10: Space = if has_head(&(v256_9)) { singleton(&[]) } else { Space::new() };
        drop(v256_9);
        let v256_11: Space = compose(&(v256_10),&v243_20_cursor);
        drop(v256_10);
        let v256_12: Space = unite(&(v256_8),&(v256_11));
        drop(v256_11);
        join_wrapped_into(&mut v255_11_write,&((v256_12).read_zipper()),&[]);
        }
        v243_20_cursor.ascend(1);
      }
      drop(v255_11_write);
      drop(v255_6);
      compose(&(v244_10),&(v255_11))
    };
    drop(v244_10);
    let v244_13: Space = unite(&(v244_8),&(v244_12));
    join_wrapped_into(&mut v243_20_write,&((v244_13).read_zipper()),&[]);
    }
    v243_20_cursor.ascend(1);
  }
  drop(v243_20_cursor);
  drop(v243_20_write);
  (v243_20).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v261_14 = Space::new();
  let mut v261_14_write = v261_14.write_zipper();
  let mut v261_14_cursor = (*s0).read_zipper();
  let v261_14_origin = v261_14_cursor.path().len();
  for v261_14_byte in v261_14_cursor.child_mask().iter() {
    v261_14_cursor.descend_to_existing_byte(v261_14_byte);
    {
    let v262_2: Space = singleton(&v261_14_cursor.path()[v261_14_origin..(v261_14_origin + 1)]);
    let v262_3: Space = intersect(&(*CONSTANT_1),&(v262_2));
    let v262_4: Space = if has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
    drop(v262_3);
    let v262_5: Space = subtract(&(*CONSTANT_0),&(v262_4));
    drop(v262_4);
    let v262_8: Space = if (&(v262_5)).is_empty() { Space::new() } else {
      let v263_6: Path = concat_path(&(*p0),&v261_14_cursor.path()[v261_14_origin..(v261_14_origin + 1)]);
      let mut v263_7 = Space::new();
      let mut v263_7_write = v263_7.write_zipper();
      for v263_7_byte in v261_14_cursor.child_mask().iter() {
        v261_14_cursor.descend_to_existing_byte(v263_7_byte);
        {
        let v264_2: Space = singleton(&v261_14_cursor.path()[(v261_14_origin + 1)..(v261_14_origin + 2)]);
        let v264_3: Space = intersect(&(*CONSTANT_1),&(v264_2));
        let v264_4: Space = if has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
        drop(v264_3);
        let v264_5: Space = subtract(&(*CONSTANT_0),&(v264_4));
        drop(v264_4);
        let v264_8: Space = if (&(v264_5)).is_empty() { Space::new() } else {
          let v265_6: Path = concat_path(&(v263_6),&v261_14_cursor.path()[(v261_14_origin + 1)..(v261_14_origin + 2)]);
          let mut v265_7 = Space::new();
          let mut v265_7_write = v265_7.write_zipper();
          for v265_7_byte in v261_14_cursor.child_mask().iter() {
            v261_14_cursor.descend_to_existing_byte(v265_7_byte);
            {
            let v266_2: Space = singleton(&v261_14_cursor.path()[(v261_14_origin + 2)..(v261_14_origin + 3)]);
            let v266_3: Space = intersect(&(*CONSTANT_1),&(v266_2));
            let v266_4: Space = if has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
            drop(v266_3);
            let v266_5: Space = subtract(&(*CONSTANT_0),&(v266_4));
            drop(v266_4);
            let v266_8: Space = if (&(v266_5)).is_empty() { Space::new() } else {
              let v267_6: Path = concat_path(&(v265_6),&v261_14_cursor.path()[(v261_14_origin + 2)..(v261_14_origin + 3)]);
              let v267_7: Space = routine_26(c, &(v267_6), &v261_14_cursor);
              compose(&(v266_5),&(v267_7))
            };
            drop(v266_5);
            let v266_9: Space = intersect(&(*CONSTANT_1),&(v266_2));
            drop(v266_2);
            let v266_10: Space = if has_head(&(v266_9)) { singleton(&[]) } else { Space::new() };
            drop(v266_9);
            let v266_12: Space = if (&(v266_10)).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v265_6),&v261_14_cursor.path()[(v261_14_origin + 2)..(v261_14_origin + 3)]);
              let v268_11: Space = routine_27(c, &(v268_6), &v261_14_cursor);
              drop(v268_6);
              compose(&(v266_10),&(v268_11))
            };
            drop(v266_10);
            let v266_13: Space = unite(&(v266_8),&(v266_12));
            join_wrapped_into(&mut v265_7_write,&((v266_13).read_zipper()),&[]);
            }
            v261_14_cursor.ascend(1);
          }
          drop(v265_7_write);
          compose(&(v264_5),&(v265_7))
        };
        drop(v264_5);
        let v264_9: Space = intersect(&(*CONSTANT_1),&(v264_2));
        drop(v264_2);
        let v264_10: Space = if has_head(&(v264_9)) { singleton(&[]) } else { Space::new() };
        drop(v264_9);
        let v264_12: Space = if (&(v264_10)).is_empty() { Space::new() } else {
          let v269_6: Path = concat_path(&(v263_6),&v261_14_cursor.path()[(v261_14_origin + 1)..(v261_14_origin + 2)]);
          let mut v269_11 = Space::new();
          let mut v269_11_write = v269_11.write_zipper();
          for v269_11_byte in v261_14_cursor.child_mask().iter() {
            v261_14_cursor.descend_to_existing_byte(v269_11_byte);
            {
            let v270_2: Space = singleton(&v261_14_cursor.path()[(v261_14_origin + 2)..(v261_14_origin + 3)]);
            let v270_3: Space = intersect(&(*CONSTANT_1),&(v270_2));
            let v270_4: Space = if has_head(&(v270_3)) { singleton(&[]) } else { Space::new() };
            drop(v270_3);
            let v270_5: Space = subtract(&(*CONSTANT_0),&(v270_4));
            drop(v270_4);
            let v270_8: Space = if (&(v270_5)).is_empty() { Space::new() } else {
              let v271_6: Path = concat_path(&(v269_6),&v261_14_cursor.path()[(v261_14_origin + 2)..(v261_14_origin + 3)]);
              let v271_7: Space = routine_26(c, &(v271_6), &v261_14_cursor);
              compose(&(v270_5),&(v271_7))
            };
            drop(v270_5);
            let v270_9: Space = intersect(&(*CONSTANT_1),&(v270_2));
            drop(v270_2);
            let v270_10: Space = if has_head(&(v270_9)) { singleton(&[]) } else { Space::new() };
            drop(v270_9);
            let v270_12: Space = if (&(v270_10)).is_empty() { Space::new() } else {
              let v272_6: Path = concat_path(&(v269_6),&v261_14_cursor.path()[(v261_14_origin + 2)..(v261_14_origin + 3)]);
              let v272_11: Space = routine_15(c, &(v272_6), &v261_14_cursor);
              drop(v272_6);
              compose(&(v270_10),&(v272_11))
            };
            drop(v270_10);
            let v270_13: Space = unite(&(v270_8),&(v270_12));
            join_wrapped_into(&mut v269_11_write,&((v270_13).read_zipper()),&[]);
            }
            v261_14_cursor.ascend(1);
          }
          drop(v269_11_write);
          drop(v269_6);
          compose(&(v264_10),&(v269_11))
        };
        drop(v264_10);
        let v264_13: Space = unite(&(v264_8),&(v264_12));
        join_wrapped_into(&mut v263_7_write,&((v264_13).read_zipper()),&[]);
        }
        v261_14_cursor.ascend(1);
      }
      drop(v263_7_write);
      drop(v263_6);
      compose(&(v262_5),&(v263_7))
    };
    drop(v262_5);
    let v262_9: Space = intersect(&(*CONSTANT_1),&(v262_2));
    drop(v262_2);
    let v262_10: Space = if has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
    drop(v262_9);
    let v262_11: Space = compose(&(v262_10),&v261_14_cursor);
    drop(v262_10);
    let v262_12: Space = unite(&(v262_8),&(v262_11));
    drop(v262_11);
    join_wrapped_into(&mut v261_14_write,&((v262_12).read_zipper()),&[]);
    }
    v261_14_cursor.ascend(1);
  }
  drop(v261_14_cursor);
  drop(v261_14_write);
  (v261_14).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_16(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v274_20 = Space::new();
  let mut v274_20_write = v274_20.write_zipper();
  let mut v274_20_cursor = (*s0).read_zipper();
  let v274_20_origin = v274_20_cursor.path().len();
  for v274_20_byte in v274_20_cursor.child_mask().iter() {
    v274_20_cursor.descend_to_existing_byte(v274_20_byte);
    {
    let v275_2: Space = singleton(&v274_20_cursor.path()[v274_20_origin..(v274_20_origin + 1)]);
    let v275_3: Space = intersect(&(*CONSTANT_1),&(v275_2));
    let v275_4: Space = if has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
    drop(v275_3);
    let v275_5: Space = subtract(&(*CONSTANT_0),&(v275_4));
    drop(v275_4);
    let v275_8: Space = if (&(v275_5)).is_empty() { Space::new() } else {
      let v276_6: Path = concat_path(&(*p0),&v274_20_cursor.path()[v274_20_origin..(v274_20_origin + 1)]);
      let mut v276_7 = Space::new();
      let mut v276_7_write = v276_7.write_zipper();
      for v276_7_byte in v274_20_cursor.child_mask().iter() {
        v274_20_cursor.descend_to_existing_byte(v276_7_byte);
        {
        let v277_2: Space = singleton(&v274_20_cursor.path()[(v274_20_origin + 1)..(v274_20_origin + 2)]);
        let v277_3: Space = intersect(&(*CONSTANT_1),&(v277_2));
        let v277_4: Space = if has_head(&(v277_3)) { singleton(&[]) } else { Space::new() };
        drop(v277_3);
        let v277_5: Space = subtract(&(*CONSTANT_0),&(v277_4));
        drop(v277_4);
        let v277_8: Space = if (&(v277_5)).is_empty() { Space::new() } else {
          let v278_6: Path = concat_path(&(v276_6),&v274_20_cursor.path()[(v274_20_origin + 1)..(v274_20_origin + 2)]);
          let mut v278_7 = Space::new();
          let mut v278_7_write = v278_7.write_zipper();
          for v278_7_byte in v274_20_cursor.child_mask().iter() {
            v274_20_cursor.descend_to_existing_byte(v278_7_byte);
            {
            let v279_2: Space = singleton(&v274_20_cursor.path()[(v274_20_origin + 2)..(v274_20_origin + 3)]);
            let v279_3: Space = intersect(&(*CONSTANT_1),&(v279_2));
            let v279_4: Space = if has_head(&(v279_3)) { singleton(&[]) } else { Space::new() };
            drop(v279_3);
            let v279_5: Space = subtract(&(*CONSTANT_0),&(v279_4));
            drop(v279_4);
            let v279_8: Space = if (&(v279_5)).is_empty() { Space::new() } else {
              let v280_6: Path = concat_path(&(v278_6),&v274_20_cursor.path()[(v274_20_origin + 2)..(v274_20_origin + 3)]);
              let v280_7: Space = routine_28(c, &(v280_6), &v274_20_cursor);
              compose(&(v279_5),&(v280_7))
            };
            drop(v279_5);
            let v279_9: Space = intersect(&(*CONSTANT_1),&(v279_2));
            drop(v279_2);
            let v279_10: Space = if has_head(&(v279_9)) { singleton(&[]) } else { Space::new() };
            drop(v279_9);
            let v279_12: Space = if (&(v279_10)).is_empty() { Space::new() } else {
              let v281_6: Path = concat_path(&(v278_6),&v274_20_cursor.path()[(v274_20_origin + 2)..(v274_20_origin + 3)]);
              let v281_11: Space = routine_29(c, &(v281_6), &v274_20_cursor);
              drop(v281_6);
              compose(&(v279_10),&(v281_11))
            };
            drop(v279_10);
            let v279_13: Space = unite(&(v279_8),&(v279_12));
            join_wrapped_into(&mut v278_7_write,&((v279_13).read_zipper()),&[]);
            }
            v274_20_cursor.ascend(1);
          }
          drop(v278_7_write);
          compose(&(v277_5),&(v278_7))
        };
        drop(v277_5);
        let v277_9: Space = intersect(&(*CONSTANT_1),&(v277_2));
        drop(v277_2);
        let v277_10: Space = if has_head(&(v277_9)) { singleton(&[]) } else { Space::new() };
        drop(v277_9);
        let v277_12: Space = if (&(v277_10)).is_empty() { Space::new() } else {
          let v282_6: Path = concat_path(&(v276_6),&v274_20_cursor.path()[(v274_20_origin + 1)..(v274_20_origin + 2)]);
          let mut v282_11 = Space::new();
          let mut v282_11_write = v282_11.write_zipper();
          for v282_11_byte in v274_20_cursor.child_mask().iter() {
            v274_20_cursor.descend_to_existing_byte(v282_11_byte);
            {
            let v283_2: Space = singleton(&v274_20_cursor.path()[(v274_20_origin + 2)..(v274_20_origin + 3)]);
            let v283_3: Space = intersect(&(*CONSTANT_1),&(v283_2));
            let v283_4: Space = if has_head(&(v283_3)) { singleton(&[]) } else { Space::new() };
            drop(v283_3);
            let v283_5: Space = subtract(&(*CONSTANT_0),&(v283_4));
            drop(v283_4);
            let v283_8: Space = if (&(v283_5)).is_empty() { Space::new() } else {
              let v284_6: Path = concat_path(&(v282_6),&v274_20_cursor.path()[(v274_20_origin + 2)..(v274_20_origin + 3)]);
              let v284_7: Space = routine_28(c, &(v284_6), &v274_20_cursor);
              compose(&(v283_5),&(v284_7))
            };
            drop(v283_5);
            let v283_9: Space = intersect(&(*CONSTANT_1),&(v283_2));
            drop(v283_2);
            let v283_10: Space = if has_head(&(v283_9)) { singleton(&[]) } else { Space::new() };
            drop(v283_9);
            let v283_12: Space = if (&(v283_10)).is_empty() { Space::new() } else {
              let v285_6: Path = concat_path(&(v282_6),&v274_20_cursor.path()[(v274_20_origin + 2)..(v274_20_origin + 3)]);
              let v285_11: Space = routine_12(c, &(v285_6), &v274_20_cursor);
              drop(v285_6);
              compose(&(v283_10),&(v285_11))
            };
            drop(v283_10);
            let v283_13: Space = unite(&(v283_8),&(v283_12));
            join_wrapped_into(&mut v282_11_write,&((v283_13).read_zipper()),&[]);
            }
            v274_20_cursor.ascend(1);
          }
          drop(v282_11_write);
          drop(v282_6);
          compose(&(v277_10),&(v282_11))
        };
        drop(v277_10);
        let v277_13: Space = unite(&(v277_8),&(v277_12));
        join_wrapped_into(&mut v276_7_write,&((v277_13).read_zipper()),&[]);
        }
        v274_20_cursor.ascend(1);
      }
      drop(v276_7_write);
      compose(&(v275_5),&(v276_7))
    };
    drop(v275_5);
    let v275_9: Space = intersect(&(*CONSTANT_1),&(v275_2));
    drop(v275_2);
    let v275_10: Space = if has_head(&(v275_9)) { singleton(&[]) } else { Space::new() };
    drop(v275_9);
    let v275_12: Space = if (&(v275_10)).is_empty() { Space::new() } else {
      let v286_6: Path = concat_path(&(*p0),&v274_20_cursor.path()[v274_20_origin..(v274_20_origin + 1)]);
      let mut v286_11 = Space::new();
      let mut v286_11_write = v286_11.write_zipper();
      for v286_11_byte in v274_20_cursor.child_mask().iter() {
        v274_20_cursor.descend_to_existing_byte(v286_11_byte);
        {
        let v287_2: Space = singleton(&v274_20_cursor.path()[(v274_20_origin + 1)..(v274_20_origin + 2)]);
        let v287_3: Space = intersect(&(*CONSTANT_1),&(v287_2));
        let v287_4: Space = if has_head(&(v287_3)) { singleton(&[]) } else { Space::new() };
        drop(v287_3);
        let v287_5: Space = subtract(&(*CONSTANT_0),&(v287_4));
        drop(v287_4);
        let v287_8: Space = if (&(v287_5)).is_empty() { Space::new() } else {
          let v288_6: Path = concat_path(&(v286_6),&v274_20_cursor.path()[(v274_20_origin + 1)..(v274_20_origin + 2)]);
          let mut v288_7 = Space::new();
          let mut v288_7_write = v288_7.write_zipper();
          for v288_7_byte in v274_20_cursor.child_mask().iter() {
            v274_20_cursor.descend_to_existing_byte(v288_7_byte);
            {
            let v289_2: Space = singleton(&v274_20_cursor.path()[(v274_20_origin + 2)..(v274_20_origin + 3)]);
            let v289_3: Space = intersect(&(*CONSTANT_1),&(v289_2));
            let v289_4: Space = if has_head(&(v289_3)) { singleton(&[]) } else { Space::new() };
            drop(v289_3);
            let v289_5: Space = subtract(&(*CONSTANT_0),&(v289_4));
            drop(v289_4);
            let v289_8: Space = if (&(v289_5)).is_empty() { Space::new() } else {
              let v290_6: Path = concat_path(&(v288_6),&v274_20_cursor.path()[(v274_20_origin + 2)..(v274_20_origin + 3)]);
              let v290_7: Space = routine_28(c, &(v290_6), &v274_20_cursor);
              compose(&(v289_5),&(v290_7))
            };
            drop(v289_5);
            let v289_9: Space = intersect(&(*CONSTANT_1),&(v289_2));
            drop(v289_2);
            let v289_10: Space = if has_head(&(v289_9)) { singleton(&[]) } else { Space::new() };
            drop(v289_9);
            let v289_12: Space = if (&(v289_10)).is_empty() { Space::new() } else {
              let v291_6: Path = concat_path(&(v288_6),&v274_20_cursor.path()[(v274_20_origin + 2)..(v274_20_origin + 3)]);
              let v291_11: Space = routine_29(c, &(v291_6), &v274_20_cursor);
              drop(v291_6);
              compose(&(v289_10),&(v291_11))
            };
            drop(v289_10);
            let v289_13: Space = unite(&(v289_8),&(v289_12));
            join_wrapped_into(&mut v288_7_write,&((v289_13).read_zipper()),&[]);
            }
            v274_20_cursor.ascend(1);
          }
          drop(v288_7_write);
          drop(v288_6);
          compose(&(v287_5),&(v288_7))
        };
        drop(v287_5);
        let v287_9: Space = intersect(&(*CONSTANT_1),&(v287_2));
        drop(v287_2);
        let v287_10: Space = if has_head(&(v287_9)) { singleton(&[]) } else { Space::new() };
        drop(v287_9);
        let v287_11: Space = compose(&(v287_10),&v274_20_cursor);
        drop(v287_10);
        let v287_12: Space = unite(&(v287_8),&(v287_11));
        drop(v287_11);
        join_wrapped_into(&mut v286_11_write,&((v287_12).read_zipper()),&[]);
        }
        v274_20_cursor.ascend(1);
      }
      drop(v286_11_write);
      drop(v286_6);
      compose(&(v275_10),&(v286_11))
    };
    drop(v275_10);
    let v275_13: Space = unite(&(v275_8),&(v275_12));
    join_wrapped_into(&mut v274_20_write,&((v275_13).read_zipper()),&[]);
    }
    v274_20_cursor.ascend(1);
  }
  drop(v274_20_cursor);
  drop(v274_20_write);
  (v274_20).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v292_14 = Space::new();
  let mut v292_14_write = v292_14.write_zipper();
  let mut v292_14_cursor = (*s0).read_zipper();
  let v292_14_origin = v292_14_cursor.path().len();
  for v292_14_byte in v292_14_cursor.child_mask().iter() {
    v292_14_cursor.descend_to_existing_byte(v292_14_byte);
    {
    let v293_2: Space = singleton(&v292_14_cursor.path()[v292_14_origin..(v292_14_origin + 1)]);
    let v293_3: Space = intersect(&(*CONSTANT_1),&(v293_2));
    let v293_4: Space = if has_head(&(v293_3)) { singleton(&[]) } else { Space::new() };
    drop(v293_3);
    let v293_5: Space = subtract(&(*CONSTANT_0),&(v293_4));
    drop(v293_4);
    let v293_8: Space = if (&(v293_5)).is_empty() { Space::new() } else {
      let v294_6: Path = concat_path(&(*p0),&v292_14_cursor.path()[v292_14_origin..(v292_14_origin + 1)]);
      let mut v294_7 = Space::new();
      let mut v294_7_write = v294_7.write_zipper();
      for v294_7_byte in v292_14_cursor.child_mask().iter() {
        v292_14_cursor.descend_to_existing_byte(v294_7_byte);
        {
        let v295_2: Space = singleton(&v292_14_cursor.path()[(v292_14_origin + 1)..(v292_14_origin + 2)]);
        let v295_3: Space = intersect(&(*CONSTANT_1),&(v295_2));
        let v295_4: Space = if has_head(&(v295_3)) { singleton(&[]) } else { Space::new() };
        drop(v295_3);
        let v295_5: Space = subtract(&(*CONSTANT_0),&(v295_4));
        drop(v295_4);
        let v295_8: Space = if (&(v295_5)).is_empty() { Space::new() } else {
          let v296_6: Path = concat_path(&(v294_6),&v292_14_cursor.path()[(v292_14_origin + 1)..(v292_14_origin + 2)]);
          let mut v296_7 = Space::new();
          let mut v296_7_write = v296_7.write_zipper();
          for v296_7_byte in v292_14_cursor.child_mask().iter() {
            v292_14_cursor.descend_to_existing_byte(v296_7_byte);
            {
            let v297_2: Space = singleton(&v292_14_cursor.path()[(v292_14_origin + 2)..(v292_14_origin + 3)]);
            let v297_3: Space = intersect(&(*CONSTANT_1),&(v297_2));
            let v297_4: Space = if has_head(&(v297_3)) { singleton(&[]) } else { Space::new() };
            drop(v297_3);
            let v297_5: Space = subtract(&(*CONSTANT_0),&(v297_4));
            drop(v297_4);
            let v297_8: Space = if (&(v297_5)).is_empty() { Space::new() } else {
              let v298_6: Path = concat_path(&(v296_6),&v292_14_cursor.path()[(v292_14_origin + 2)..(v292_14_origin + 3)]);
              let v298_7: Space = routine_28(c, &(v298_6), &v292_14_cursor);
              compose(&(v297_5),&(v298_7))
            };
            drop(v297_5);
            let v297_9: Space = intersect(&(*CONSTANT_1),&(v297_2));
            drop(v297_2);
            let v297_10: Space = if has_head(&(v297_9)) { singleton(&[]) } else { Space::new() };
            drop(v297_9);
            let v297_12: Space = if (&(v297_10)).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v296_6),&v292_14_cursor.path()[(v292_14_origin + 2)..(v292_14_origin + 3)]);
              let v299_11: Space = routine_29(c, &(v299_6), &v292_14_cursor);
              drop(v299_6);
              compose(&(v297_10),&(v299_11))
            };
            drop(v297_10);
            let v297_13: Space = unite(&(v297_8),&(v297_12));
            join_wrapped_into(&mut v296_7_write,&((v297_13).read_zipper()),&[]);
            }
            v292_14_cursor.ascend(1);
          }
          drop(v296_7_write);
          compose(&(v295_5),&(v296_7))
        };
        drop(v295_5);
        let v295_9: Space = intersect(&(*CONSTANT_1),&(v295_2));
        drop(v295_2);
        let v295_10: Space = if has_head(&(v295_9)) { singleton(&[]) } else { Space::new() };
        drop(v295_9);
        let v295_12: Space = if (&(v295_10)).is_empty() { Space::new() } else {
          let v300_6: Path = concat_path(&(v294_6),&v292_14_cursor.path()[(v292_14_origin + 1)..(v292_14_origin + 2)]);
          let mut v300_11 = Space::new();
          let mut v300_11_write = v300_11.write_zipper();
          for v300_11_byte in v292_14_cursor.child_mask().iter() {
            v292_14_cursor.descend_to_existing_byte(v300_11_byte);
            {
            let v301_2: Space = singleton(&v292_14_cursor.path()[(v292_14_origin + 2)..(v292_14_origin + 3)]);
            let v301_3: Space = intersect(&(*CONSTANT_1),&(v301_2));
            let v301_4: Space = if has_head(&(v301_3)) { singleton(&[]) } else { Space::new() };
            drop(v301_3);
            let v301_5: Space = subtract(&(*CONSTANT_0),&(v301_4));
            drop(v301_4);
            let v301_8: Space = if (&(v301_5)).is_empty() { Space::new() } else {
              let v302_6: Path = concat_path(&(v300_6),&v292_14_cursor.path()[(v292_14_origin + 2)..(v292_14_origin + 3)]);
              let v302_7: Space = routine_28(c, &(v302_6), &v292_14_cursor);
              compose(&(v301_5),&(v302_7))
            };
            drop(v301_5);
            let v301_9: Space = intersect(&(*CONSTANT_1),&(v301_2));
            drop(v301_2);
            let v301_10: Space = if has_head(&(v301_9)) { singleton(&[]) } else { Space::new() };
            drop(v301_9);
            let v301_12: Space = if (&(v301_10)).is_empty() { Space::new() } else {
              let v303_6: Path = concat_path(&(v300_6),&v292_14_cursor.path()[(v292_14_origin + 2)..(v292_14_origin + 3)]);
              let v303_11: Space = routine_12(c, &(v303_6), &v292_14_cursor);
              drop(v303_6);
              compose(&(v301_10),&(v303_11))
            };
            drop(v301_10);
            let v301_13: Space = unite(&(v301_8),&(v301_12));
            join_wrapped_into(&mut v300_11_write,&((v301_13).read_zipper()),&[]);
            }
            v292_14_cursor.ascend(1);
          }
          drop(v300_11_write);
          drop(v300_6);
          compose(&(v295_10),&(v300_11))
        };
        drop(v295_10);
        let v295_13: Space = unite(&(v295_8),&(v295_12));
        join_wrapped_into(&mut v294_7_write,&((v295_13).read_zipper()),&[]);
        }
        v292_14_cursor.ascend(1);
      }
      drop(v294_7_write);
      drop(v294_6);
      compose(&(v293_5),&(v294_7))
    };
    drop(v293_5);
    let v293_9: Space = intersect(&(*CONSTANT_1),&(v293_2));
    drop(v293_2);
    let v293_10: Space = if has_head(&(v293_9)) { singleton(&[]) } else { Space::new() };
    drop(v293_9);
    let v293_11: Space = compose(&(v293_10),&v292_14_cursor);
    drop(v293_10);
    let v293_12: Space = unite(&(v293_8),&(v293_11));
    drop(v293_11);
    join_wrapped_into(&mut v292_14_write,&((v293_12).read_zipper()),&[]);
    }
    v292_14_cursor.ascend(1);
  }
  drop(v292_14_cursor);
  drop(v292_14_write);
  (v292_14).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v304_20 = Space::new();
  let mut v304_20_write = v304_20.write_zipper();
  let mut v304_20_cursor = (*s0).read_zipper();
  let v304_20_origin = v304_20_cursor.path().len();
  for v304_20_byte in v304_20_cursor.child_mask().iter() {
    v304_20_cursor.descend_to_existing_byte(v304_20_byte);
    {
    let v305_2: Space = singleton(&v304_20_cursor.path()[v304_20_origin..(v304_20_origin + 1)]);
    let v305_3: Space = intersect(&(*CONSTANT_1),&(v305_2));
    let v305_4: Space = if has_head(&(v305_3)) { singleton(&[]) } else { Space::new() };
    drop(v305_3);
    let v305_5: Space = subtract(&(*CONSTANT_0),&(v305_4));
    drop(v305_4);
    let v305_8: Space = if (&(v305_5)).is_empty() { Space::new() } else {
      let v306_6: Path = concat_path(&(*p0),&v304_20_cursor.path()[v304_20_origin..(v304_20_origin + 1)]);
      let mut v306_7 = Space::new();
      let mut v306_7_write = v306_7.write_zipper();
      for v306_7_byte in v304_20_cursor.child_mask().iter() {
        v304_20_cursor.descend_to_existing_byte(v306_7_byte);
        {
        let v307_2: Space = singleton(&v304_20_cursor.path()[(v304_20_origin + 1)..(v304_20_origin + 2)]);
        let v307_3: Space = intersect(&(*CONSTANT_1),&(v307_2));
        let v307_4: Space = if has_head(&(v307_3)) { singleton(&[]) } else { Space::new() };
        drop(v307_3);
        let v307_5: Space = subtract(&(*CONSTANT_0),&(v307_4));
        drop(v307_4);
        let v307_8: Space = if (&(v307_5)).is_empty() { Space::new() } else {
          let v308_6: Path = concat_path(&(v306_6),&v304_20_cursor.path()[(v304_20_origin + 1)..(v304_20_origin + 2)]);
          let mut v308_7 = Space::new();
          let mut v308_7_write = v308_7.write_zipper();
          for v308_7_byte in v304_20_cursor.child_mask().iter() {
            v304_20_cursor.descend_to_existing_byte(v308_7_byte);
            {
            let v309_2: Space = singleton(&v304_20_cursor.path()[(v304_20_origin + 2)..(v304_20_origin + 3)]);
            let v309_3: Space = intersect(&(*CONSTANT_1),&(v309_2));
            let v309_4: Space = if has_head(&(v309_3)) { singleton(&[]) } else { Space::new() };
            drop(v309_3);
            let v309_5: Space = subtract(&(*CONSTANT_0),&(v309_4));
            drop(v309_4);
            let v309_8: Space = if (&(v309_5)).is_empty() { Space::new() } else {
              let v310_6: Path = concat_path(&(v308_6),&v304_20_cursor.path()[(v304_20_origin + 2)..(v304_20_origin + 3)]);
              let v310_7: Space = routine_30(c, &(v310_6), &v304_20_cursor);
              compose(&(v309_5),&(v310_7))
            };
            drop(v309_5);
            let v309_9: Space = intersect(&(*CONSTANT_1),&(v309_2));
            drop(v309_2);
            let v309_10: Space = if has_head(&(v309_9)) { singleton(&[]) } else { Space::new() };
            drop(v309_9);
            let v309_12: Space = if (&(v309_10)).is_empty() { Space::new() } else {
              let v311_6: Path = concat_path(&(v308_6),&v304_20_cursor.path()[(v304_20_origin + 2)..(v304_20_origin + 3)]);
              let v311_11: Space = routine_31(c, &(v311_6), &v304_20_cursor);
              drop(v311_6);
              compose(&(v309_10),&(v311_11))
            };
            drop(v309_10);
            let v309_13: Space = unite(&(v309_8),&(v309_12));
            join_wrapped_into(&mut v308_7_write,&((v309_13).read_zipper()),&[]);
            }
            v304_20_cursor.ascend(1);
          }
          drop(v308_7_write);
          compose(&(v307_5),&(v308_7))
        };
        drop(v307_5);
        let v307_9: Space = intersect(&(*CONSTANT_1),&(v307_2));
        drop(v307_2);
        let v307_10: Space = if has_head(&(v307_9)) { singleton(&[]) } else { Space::new() };
        drop(v307_9);
        let v307_12: Space = if (&(v307_10)).is_empty() { Space::new() } else {
          let v312_6: Path = concat_path(&(v306_6),&v304_20_cursor.path()[(v304_20_origin + 1)..(v304_20_origin + 2)]);
          let mut v312_11 = Space::new();
          let mut v312_11_write = v312_11.write_zipper();
          for v312_11_byte in v304_20_cursor.child_mask().iter() {
            v304_20_cursor.descend_to_existing_byte(v312_11_byte);
            {
            let v313_2: Space = singleton(&v304_20_cursor.path()[(v304_20_origin + 2)..(v304_20_origin + 3)]);
            let v313_3: Space = intersect(&(*CONSTANT_1),&(v313_2));
            let v313_4: Space = if has_head(&(v313_3)) { singleton(&[]) } else { Space::new() };
            drop(v313_3);
            let v313_5: Space = subtract(&(*CONSTANT_0),&(v313_4));
            drop(v313_4);
            let v313_8: Space = if (&(v313_5)).is_empty() { Space::new() } else {
              let v314_6: Path = concat_path(&(v312_6),&v304_20_cursor.path()[(v304_20_origin + 2)..(v304_20_origin + 3)]);
              let v314_7: Space = routine_30(c, &(v314_6), &v304_20_cursor);
              compose(&(v313_5),&(v314_7))
            };
            drop(v313_5);
            let v313_9: Space = intersect(&(*CONSTANT_1),&(v313_2));
            drop(v313_2);
            let v313_10: Space = if has_head(&(v313_9)) { singleton(&[]) } else { Space::new() };
            drop(v313_9);
            let v313_12: Space = if (&(v313_10)).is_empty() { Space::new() } else {
              let v315_6: Path = concat_path(&(v312_6),&v304_20_cursor.path()[(v304_20_origin + 2)..(v304_20_origin + 3)]);
              let v315_11: Space = routine_15(c, &(v315_6), &v304_20_cursor);
              drop(v315_6);
              compose(&(v313_10),&(v315_11))
            };
            drop(v313_10);
            let v313_13: Space = unite(&(v313_8),&(v313_12));
            join_wrapped_into(&mut v312_11_write,&((v313_13).read_zipper()),&[]);
            }
            v304_20_cursor.ascend(1);
          }
          drop(v312_11_write);
          drop(v312_6);
          compose(&(v307_10),&(v312_11))
        };
        drop(v307_10);
        let v307_13: Space = unite(&(v307_8),&(v307_12));
        join_wrapped_into(&mut v306_7_write,&((v307_13).read_zipper()),&[]);
        }
        v304_20_cursor.ascend(1);
      }
      drop(v306_7_write);
      compose(&(v305_5),&(v306_7))
    };
    drop(v305_5);
    let v305_9: Space = intersect(&(*CONSTANT_1),&(v305_2));
    drop(v305_2);
    let v305_10: Space = if has_head(&(v305_9)) { singleton(&[]) } else { Space::new() };
    drop(v305_9);
    let v305_12: Space = if (&(v305_10)).is_empty() { Space::new() } else {
      let v316_6: Path = concat_path(&(*p0),&v304_20_cursor.path()[v304_20_origin..(v304_20_origin + 1)]);
      let mut v316_11 = Space::new();
      let mut v316_11_write = v316_11.write_zipper();
      for v316_11_byte in v304_20_cursor.child_mask().iter() {
        v304_20_cursor.descend_to_existing_byte(v316_11_byte);
        {
        let v317_2: Space = singleton(&v304_20_cursor.path()[(v304_20_origin + 1)..(v304_20_origin + 2)]);
        let v317_3: Space = intersect(&(*CONSTANT_1),&(v317_2));
        let v317_4: Space = if has_head(&(v317_3)) { singleton(&[]) } else { Space::new() };
        drop(v317_3);
        let v317_5: Space = subtract(&(*CONSTANT_0),&(v317_4));
        drop(v317_4);
        let v317_8: Space = if (&(v317_5)).is_empty() { Space::new() } else {
          let v318_6: Path = concat_path(&(v316_6),&v304_20_cursor.path()[(v304_20_origin + 1)..(v304_20_origin + 2)]);
          let mut v318_7 = Space::new();
          let mut v318_7_write = v318_7.write_zipper();
          for v318_7_byte in v304_20_cursor.child_mask().iter() {
            v304_20_cursor.descend_to_existing_byte(v318_7_byte);
            {
            let v319_2: Space = singleton(&v304_20_cursor.path()[(v304_20_origin + 2)..(v304_20_origin + 3)]);
            let v319_3: Space = intersect(&(*CONSTANT_1),&(v319_2));
            let v319_4: Space = if has_head(&(v319_3)) { singleton(&[]) } else { Space::new() };
            drop(v319_3);
            let v319_5: Space = subtract(&(*CONSTANT_0),&(v319_4));
            drop(v319_4);
            let v319_8: Space = if (&(v319_5)).is_empty() { Space::new() } else {
              let v320_6: Path = concat_path(&(v318_6),&v304_20_cursor.path()[(v304_20_origin + 2)..(v304_20_origin + 3)]);
              let v320_7: Space = routine_30(c, &(v320_6), &v304_20_cursor);
              compose(&(v319_5),&(v320_7))
            };
            drop(v319_5);
            let v319_9: Space = intersect(&(*CONSTANT_1),&(v319_2));
            drop(v319_2);
            let v319_10: Space = if has_head(&(v319_9)) { singleton(&[]) } else { Space::new() };
            drop(v319_9);
            let v319_12: Space = if (&(v319_10)).is_empty() { Space::new() } else {
              let v321_6: Path = concat_path(&(v318_6),&v304_20_cursor.path()[(v304_20_origin + 2)..(v304_20_origin + 3)]);
              let v321_11: Space = routine_31(c, &(v321_6), &v304_20_cursor);
              drop(v321_6);
              compose(&(v319_10),&(v321_11))
            };
            drop(v319_10);
            let v319_13: Space = unite(&(v319_8),&(v319_12));
            join_wrapped_into(&mut v318_7_write,&((v319_13).read_zipper()),&[]);
            }
            v304_20_cursor.ascend(1);
          }
          drop(v318_7_write);
          drop(v318_6);
          compose(&(v317_5),&(v318_7))
        };
        drop(v317_5);
        let v317_9: Space = intersect(&(*CONSTANT_1),&(v317_2));
        drop(v317_2);
        let v317_10: Space = if has_head(&(v317_9)) { singleton(&[]) } else { Space::new() };
        drop(v317_9);
        let v317_11: Space = compose(&(v317_10),&v304_20_cursor);
        drop(v317_10);
        let v317_12: Space = unite(&(v317_8),&(v317_11));
        drop(v317_11);
        join_wrapped_into(&mut v316_11_write,&((v317_12).read_zipper()),&[]);
        }
        v304_20_cursor.ascend(1);
      }
      drop(v316_11_write);
      drop(v316_6);
      compose(&(v305_10),&(v316_11))
    };
    drop(v305_10);
    let v305_13: Space = unite(&(v305_8),&(v305_12));
    join_wrapped_into(&mut v304_20_write,&((v305_13).read_zipper()),&[]);
    }
    v304_20_cursor.ascend(1);
  }
  drop(v304_20_cursor);
  drop(v304_20_write);
  (v304_20).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v322_14 = Space::new();
  let mut v322_14_write = v322_14.write_zipper();
  let mut v322_14_cursor = (*s0).read_zipper();
  let v322_14_origin = v322_14_cursor.path().len();
  for v322_14_byte in v322_14_cursor.child_mask().iter() {
    v322_14_cursor.descend_to_existing_byte(v322_14_byte);
    {
    let v323_2: Space = singleton(&v322_14_cursor.path()[v322_14_origin..(v322_14_origin + 1)]);
    let v323_3: Space = intersect(&(*CONSTANT_1),&(v323_2));
    let v323_4: Space = if has_head(&(v323_3)) { singleton(&[]) } else { Space::new() };
    drop(v323_3);
    let v323_5: Space = subtract(&(*CONSTANT_0),&(v323_4));
    drop(v323_4);
    let v323_8: Space = if (&(v323_5)).is_empty() { Space::new() } else {
      let v324_6: Path = concat_path(&(*p0),&v322_14_cursor.path()[v322_14_origin..(v322_14_origin + 1)]);
      let mut v324_7 = Space::new();
      let mut v324_7_write = v324_7.write_zipper();
      for v324_7_byte in v322_14_cursor.child_mask().iter() {
        v322_14_cursor.descend_to_existing_byte(v324_7_byte);
        {
        let v325_2: Space = singleton(&v322_14_cursor.path()[(v322_14_origin + 1)..(v322_14_origin + 2)]);
        let v325_3: Space = intersect(&(*CONSTANT_1),&(v325_2));
        let v325_4: Space = if has_head(&(v325_3)) { singleton(&[]) } else { Space::new() };
        drop(v325_3);
        let v325_5: Space = subtract(&(*CONSTANT_0),&(v325_4));
        drop(v325_4);
        let v325_8: Space = if (&(v325_5)).is_empty() { Space::new() } else {
          let v326_6: Path = concat_path(&(v324_6),&v322_14_cursor.path()[(v322_14_origin + 1)..(v322_14_origin + 2)]);
          let mut v326_7 = Space::new();
          let mut v326_7_write = v326_7.write_zipper();
          for v326_7_byte in v322_14_cursor.child_mask().iter() {
            v322_14_cursor.descend_to_existing_byte(v326_7_byte);
            {
            let v327_2: Space = singleton(&v322_14_cursor.path()[(v322_14_origin + 2)..(v322_14_origin + 3)]);
            let v327_3: Space = intersect(&(*CONSTANT_1),&(v327_2));
            let v327_4: Space = if has_head(&(v327_3)) { singleton(&[]) } else { Space::new() };
            drop(v327_3);
            let v327_5: Space = subtract(&(*CONSTANT_0),&(v327_4));
            drop(v327_4);
            let v327_8: Space = if (&(v327_5)).is_empty() { Space::new() } else {
              let v328_6: Path = concat_path(&(v326_6),&v322_14_cursor.path()[(v322_14_origin + 2)..(v322_14_origin + 3)]);
              let v328_7: Space = routine_30(c, &(v328_6), &v322_14_cursor);
              compose(&(v327_5),&(v328_7))
            };
            drop(v327_5);
            let v327_9: Space = intersect(&(*CONSTANT_1),&(v327_2));
            drop(v327_2);
            let v327_10: Space = if has_head(&(v327_9)) { singleton(&[]) } else { Space::new() };
            drop(v327_9);
            let v327_12: Space = if (&(v327_10)).is_empty() { Space::new() } else {
              let v329_6: Path = concat_path(&(v326_6),&v322_14_cursor.path()[(v322_14_origin + 2)..(v322_14_origin + 3)]);
              let v329_11: Space = routine_31(c, &(v329_6), &v322_14_cursor);
              drop(v329_6);
              compose(&(v327_10),&(v329_11))
            };
            drop(v327_10);
            let v327_13: Space = unite(&(v327_8),&(v327_12));
            join_wrapped_into(&mut v326_7_write,&((v327_13).read_zipper()),&[]);
            }
            v322_14_cursor.ascend(1);
          }
          drop(v326_7_write);
          compose(&(v325_5),&(v326_7))
        };
        drop(v325_5);
        let v325_9: Space = intersect(&(*CONSTANT_1),&(v325_2));
        drop(v325_2);
        let v325_10: Space = if has_head(&(v325_9)) { singleton(&[]) } else { Space::new() };
        drop(v325_9);
        let v325_12: Space = if (&(v325_10)).is_empty() { Space::new() } else {
          let v330_6: Path = concat_path(&(v324_6),&v322_14_cursor.path()[(v322_14_origin + 1)..(v322_14_origin + 2)]);
          let mut v330_11 = Space::new();
          let mut v330_11_write = v330_11.write_zipper();
          for v330_11_byte in v322_14_cursor.child_mask().iter() {
            v322_14_cursor.descend_to_existing_byte(v330_11_byte);
            {
            let v331_2: Space = singleton(&v322_14_cursor.path()[(v322_14_origin + 2)..(v322_14_origin + 3)]);
            let v331_3: Space = intersect(&(*CONSTANT_1),&(v331_2));
            let v331_4: Space = if has_head(&(v331_3)) { singleton(&[]) } else { Space::new() };
            drop(v331_3);
            let v331_5: Space = subtract(&(*CONSTANT_0),&(v331_4));
            drop(v331_4);
            let v331_8: Space = if (&(v331_5)).is_empty() { Space::new() } else {
              let v332_6: Path = concat_path(&(v330_6),&v322_14_cursor.path()[(v322_14_origin + 2)..(v322_14_origin + 3)]);
              let v332_7: Space = routine_30(c, &(v332_6), &v322_14_cursor);
              compose(&(v331_5),&(v332_7))
            };
            drop(v331_5);
            let v331_9: Space = intersect(&(*CONSTANT_1),&(v331_2));
            drop(v331_2);
            let v331_10: Space = if has_head(&(v331_9)) { singleton(&[]) } else { Space::new() };
            drop(v331_9);
            let v331_12: Space = if (&(v331_10)).is_empty() { Space::new() } else {
              let v333_6: Path = concat_path(&(v330_6),&v322_14_cursor.path()[(v322_14_origin + 2)..(v322_14_origin + 3)]);
              let v333_11: Space = routine_15(c, &(v333_6), &v322_14_cursor);
              drop(v333_6);
              compose(&(v331_10),&(v333_11))
            };
            drop(v331_10);
            let v331_13: Space = unite(&(v331_8),&(v331_12));
            join_wrapped_into(&mut v330_11_write,&((v331_13).read_zipper()),&[]);
            }
            v322_14_cursor.ascend(1);
          }
          drop(v330_11_write);
          drop(v330_6);
          compose(&(v325_10),&(v330_11))
        };
        drop(v325_10);
        let v325_13: Space = unite(&(v325_8),&(v325_12));
        join_wrapped_into(&mut v324_7_write,&((v325_13).read_zipper()),&[]);
        }
        v322_14_cursor.ascend(1);
      }
      drop(v324_7_write);
      drop(v324_6);
      compose(&(v323_5),&(v324_7))
    };
    drop(v323_5);
    let v323_9: Space = intersect(&(*CONSTANT_1),&(v323_2));
    drop(v323_2);
    let v323_10: Space = if has_head(&(v323_9)) { singleton(&[]) } else { Space::new() };
    drop(v323_9);
    let v323_11: Space = compose(&(v323_10),&v322_14_cursor);
    drop(v323_10);
    let v323_12: Space = unite(&(v323_8),&(v323_11));
    drop(v323_11);
    join_wrapped_into(&mut v322_14_write,&((v323_12).read_zipper()),&[]);
    }
    v322_14_cursor.ascend(1);
  }
  drop(v322_14_cursor);
  drop(v322_14_write);
  (v322_14).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v334_20 = Space::new();
  let mut v334_20_write = v334_20.write_zipper();
  let mut v334_20_cursor = (*s0).read_zipper();
  let v334_20_origin = v334_20_cursor.path().len();
  for v334_20_byte in v334_20_cursor.child_mask().iter() {
    v334_20_cursor.descend_to_existing_byte(v334_20_byte);
    {
    let v335_2: Space = singleton(&v334_20_cursor.path()[v334_20_origin..(v334_20_origin + 1)]);
    let v335_3: Space = intersect(&(*CONSTANT_1),&(v335_2));
    let v335_4: Space = if has_head(&(v335_3)) { singleton(&[]) } else { Space::new() };
    drop(v335_3);
    let v335_5: Space = subtract(&(*CONSTANT_0),&(v335_4));
    drop(v335_4);
    let v335_8: Space = if (&(v335_5)).is_empty() { Space::new() } else {
      let v336_6: Path = concat_path(&(*p0),&v334_20_cursor.path()[v334_20_origin..(v334_20_origin + 1)]);
      let mut v336_7 = Space::new();
      let mut v336_7_write = v336_7.write_zipper();
      for v336_7_byte in v334_20_cursor.child_mask().iter() {
        v334_20_cursor.descend_to_existing_byte(v336_7_byte);
        {
        let v337_2: Space = singleton(&v334_20_cursor.path()[(v334_20_origin + 1)..(v334_20_origin + 2)]);
        let v337_3: Space = intersect(&(*CONSTANT_1),&(v337_2));
        let v337_4: Space = if has_head(&(v337_3)) { singleton(&[]) } else { Space::new() };
        drop(v337_3);
        let v337_5: Space = subtract(&(*CONSTANT_0),&(v337_4));
        drop(v337_4);
        let v337_8: Space = if (&(v337_5)).is_empty() { Space::new() } else {
          let v338_6: Path = concat_path(&(v336_6),&v334_20_cursor.path()[(v334_20_origin + 1)..(v334_20_origin + 2)]);
          let mut v338_7 = Space::new();
          let mut v338_7_write = v338_7.write_zipper();
          for v338_7_byte in v334_20_cursor.child_mask().iter() {
            v334_20_cursor.descend_to_existing_byte(v338_7_byte);
            {
            let v339_2: Space = singleton(&v334_20_cursor.path()[(v334_20_origin + 2)..(v334_20_origin + 3)]);
            let v339_3: Space = intersect(&(*CONSTANT_1),&(v339_2));
            let v339_4: Space = if has_head(&(v339_3)) { singleton(&[]) } else { Space::new() };
            drop(v339_3);
            let v339_5: Space = subtract(&(*CONSTANT_0),&(v339_4));
            drop(v339_4);
            let v339_8: Space = if (&(v339_5)).is_empty() { Space::new() } else {
              let v340_6: Path = concat_path(&(v338_6),&v334_20_cursor.path()[(v334_20_origin + 2)..(v334_20_origin + 3)]);
              let v340_7: Space = routine_32(c, &(v340_6), &v334_20_cursor);
              compose(&(v339_5),&(v340_7))
            };
            drop(v339_5);
            let v339_9: Space = intersect(&(*CONSTANT_1),&(v339_2));
            drop(v339_2);
            let v339_10: Space = if has_head(&(v339_9)) { singleton(&[]) } else { Space::new() };
            drop(v339_9);
            let v339_12: Space = if (&(v339_10)).is_empty() { Space::new() } else {
              let v341_6: Path = concat_path(&(v338_6),&v334_20_cursor.path()[(v334_20_origin + 2)..(v334_20_origin + 3)]);
              let v341_11: Space = routine_33(c, &(v341_6), &v334_20_cursor);
              drop(v341_6);
              compose(&(v339_10),&(v341_11))
            };
            drop(v339_10);
            let v339_13: Space = unite(&(v339_8),&(v339_12));
            join_wrapped_into(&mut v338_7_write,&((v339_13).read_zipper()),&[]);
            }
            v334_20_cursor.ascend(1);
          }
          drop(v338_7_write);
          compose(&(v337_5),&(v338_7))
        };
        drop(v337_5);
        let v337_9: Space = intersect(&(*CONSTANT_1),&(v337_2));
        drop(v337_2);
        let v337_10: Space = if has_head(&(v337_9)) { singleton(&[]) } else { Space::new() };
        drop(v337_9);
        let v337_12: Space = if (&(v337_10)).is_empty() { Space::new() } else {
          let v342_6: Path = concat_path(&(v336_6),&v334_20_cursor.path()[(v334_20_origin + 1)..(v334_20_origin + 2)]);
          let mut v342_11 = Space::new();
          let mut v342_11_write = v342_11.write_zipper();
          for v342_11_byte in v334_20_cursor.child_mask().iter() {
            v334_20_cursor.descend_to_existing_byte(v342_11_byte);
            {
            let v343_2: Space = singleton(&v334_20_cursor.path()[(v334_20_origin + 2)..(v334_20_origin + 3)]);
            let v343_3: Space = intersect(&(*CONSTANT_1),&(v343_2));
            let v343_4: Space = if has_head(&(v343_3)) { singleton(&[]) } else { Space::new() };
            drop(v343_3);
            let v343_5: Space = subtract(&(*CONSTANT_0),&(v343_4));
            drop(v343_4);
            let v343_8: Space = if (&(v343_5)).is_empty() { Space::new() } else {
              let v344_6: Path = concat_path(&(v342_6),&v334_20_cursor.path()[(v334_20_origin + 2)..(v334_20_origin + 3)]);
              let v344_7: Space = routine_32(c, &(v344_6), &v334_20_cursor);
              compose(&(v343_5),&(v344_7))
            };
            drop(v343_5);
            let v343_9: Space = intersect(&(*CONSTANT_1),&(v343_2));
            drop(v343_2);
            let v343_10: Space = if has_head(&(v343_9)) { singleton(&[]) } else { Space::new() };
            drop(v343_9);
            let v343_12: Space = if (&(v343_10)).is_empty() { Space::new() } else {
              let v345_6: Path = concat_path(&(v342_6),&v334_20_cursor.path()[(v334_20_origin + 2)..(v334_20_origin + 3)]);
              let v345_11: Space = routine_12(c, &(v345_6), &v334_20_cursor);
              drop(v345_6);
              compose(&(v343_10),&(v345_11))
            };
            drop(v343_10);
            let v343_13: Space = unite(&(v343_8),&(v343_12));
            join_wrapped_into(&mut v342_11_write,&((v343_13).read_zipper()),&[]);
            }
            v334_20_cursor.ascend(1);
          }
          drop(v342_11_write);
          drop(v342_6);
          compose(&(v337_10),&(v342_11))
        };
        drop(v337_10);
        let v337_13: Space = unite(&(v337_8),&(v337_12));
        join_wrapped_into(&mut v336_7_write,&((v337_13).read_zipper()),&[]);
        }
        v334_20_cursor.ascend(1);
      }
      drop(v336_7_write);
      compose(&(v335_5),&(v336_7))
    };
    drop(v335_5);
    let v335_9: Space = intersect(&(*CONSTANT_1),&(v335_2));
    drop(v335_2);
    let v335_10: Space = if has_head(&(v335_9)) { singleton(&[]) } else { Space::new() };
    drop(v335_9);
    let v335_12: Space = if (&(v335_10)).is_empty() { Space::new() } else {
      let v346_6: Path = concat_path(&(*p0),&v334_20_cursor.path()[v334_20_origin..(v334_20_origin + 1)]);
      let mut v346_11 = Space::new();
      let mut v346_11_write = v346_11.write_zipper();
      for v346_11_byte in v334_20_cursor.child_mask().iter() {
        v334_20_cursor.descend_to_existing_byte(v346_11_byte);
        {
        let v347_2: Space = singleton(&v334_20_cursor.path()[(v334_20_origin + 1)..(v334_20_origin + 2)]);
        let v347_3: Space = intersect(&(*CONSTANT_1),&(v347_2));
        let v347_4: Space = if has_head(&(v347_3)) { singleton(&[]) } else { Space::new() };
        drop(v347_3);
        let v347_5: Space = subtract(&(*CONSTANT_0),&(v347_4));
        drop(v347_4);
        let v347_8: Space = if (&(v347_5)).is_empty() { Space::new() } else {
          let v348_6: Path = concat_path(&(v346_6),&v334_20_cursor.path()[(v334_20_origin + 1)..(v334_20_origin + 2)]);
          let mut v348_7 = Space::new();
          let mut v348_7_write = v348_7.write_zipper();
          for v348_7_byte in v334_20_cursor.child_mask().iter() {
            v334_20_cursor.descend_to_existing_byte(v348_7_byte);
            {
            let v349_2: Space = singleton(&v334_20_cursor.path()[(v334_20_origin + 2)..(v334_20_origin + 3)]);
            let v349_3: Space = intersect(&(*CONSTANT_1),&(v349_2));
            let v349_4: Space = if has_head(&(v349_3)) { singleton(&[]) } else { Space::new() };
            drop(v349_3);
            let v349_5: Space = subtract(&(*CONSTANT_0),&(v349_4));
            drop(v349_4);
            let v349_8: Space = if (&(v349_5)).is_empty() { Space::new() } else {
              let v350_6: Path = concat_path(&(v348_6),&v334_20_cursor.path()[(v334_20_origin + 2)..(v334_20_origin + 3)]);
              let v350_7: Space = routine_32(c, &(v350_6), &v334_20_cursor);
              compose(&(v349_5),&(v350_7))
            };
            drop(v349_5);
            let v349_9: Space = intersect(&(*CONSTANT_1),&(v349_2));
            drop(v349_2);
            let v349_10: Space = if has_head(&(v349_9)) { singleton(&[]) } else { Space::new() };
            drop(v349_9);
            let v349_12: Space = if (&(v349_10)).is_empty() { Space::new() } else {
              let v351_6: Path = concat_path(&(v348_6),&v334_20_cursor.path()[(v334_20_origin + 2)..(v334_20_origin + 3)]);
              let v351_11: Space = routine_33(c, &(v351_6), &v334_20_cursor);
              drop(v351_6);
              compose(&(v349_10),&(v351_11))
            };
            drop(v349_10);
            let v349_13: Space = unite(&(v349_8),&(v349_12));
            join_wrapped_into(&mut v348_7_write,&((v349_13).read_zipper()),&[]);
            }
            v334_20_cursor.ascend(1);
          }
          drop(v348_7_write);
          drop(v348_6);
          compose(&(v347_5),&(v348_7))
        };
        drop(v347_5);
        let v347_9: Space = intersect(&(*CONSTANT_1),&(v347_2));
        drop(v347_2);
        let v347_10: Space = if has_head(&(v347_9)) { singleton(&[]) } else { Space::new() };
        drop(v347_9);
        let v347_11: Space = compose(&(v347_10),&v334_20_cursor);
        drop(v347_10);
        let v347_12: Space = unite(&(v347_8),&(v347_11));
        drop(v347_11);
        join_wrapped_into(&mut v346_11_write,&((v347_12).read_zipper()),&[]);
        }
        v334_20_cursor.ascend(1);
      }
      drop(v346_11_write);
      drop(v346_6);
      compose(&(v335_10),&(v346_11))
    };
    drop(v335_10);
    let v335_13: Space = unite(&(v335_8),&(v335_12));
    join_wrapped_into(&mut v334_20_write,&((v335_13).read_zipper()),&[]);
    }
    v334_20_cursor.ascend(1);
  }
  drop(v334_20_cursor);
  drop(v334_20_write);
  (v334_20).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v352_14 = Space::new();
  let mut v352_14_write = v352_14.write_zipper();
  let mut v352_14_cursor = (*s0).read_zipper();
  let v352_14_origin = v352_14_cursor.path().len();
  for v352_14_byte in v352_14_cursor.child_mask().iter() {
    v352_14_cursor.descend_to_existing_byte(v352_14_byte);
    {
    let v353_2: Space = singleton(&v352_14_cursor.path()[v352_14_origin..(v352_14_origin + 1)]);
    let v353_3: Space = intersect(&(*CONSTANT_1),&(v353_2));
    let v353_4: Space = if has_head(&(v353_3)) { singleton(&[]) } else { Space::new() };
    drop(v353_3);
    let v353_5: Space = subtract(&(*CONSTANT_0),&(v353_4));
    drop(v353_4);
    let v353_8: Space = if (&(v353_5)).is_empty() { Space::new() } else {
      let v354_6: Path = concat_path(&(*p0),&v352_14_cursor.path()[v352_14_origin..(v352_14_origin + 1)]);
      let mut v354_7 = Space::new();
      let mut v354_7_write = v354_7.write_zipper();
      for v354_7_byte in v352_14_cursor.child_mask().iter() {
        v352_14_cursor.descend_to_existing_byte(v354_7_byte);
        {
        let v355_2: Space = singleton(&v352_14_cursor.path()[(v352_14_origin + 1)..(v352_14_origin + 2)]);
        let v355_3: Space = intersect(&(*CONSTANT_1),&(v355_2));
        let v355_4: Space = if has_head(&(v355_3)) { singleton(&[]) } else { Space::new() };
        drop(v355_3);
        let v355_5: Space = subtract(&(*CONSTANT_0),&(v355_4));
        drop(v355_4);
        let v355_8: Space = if (&(v355_5)).is_empty() { Space::new() } else {
          let v356_6: Path = concat_path(&(v354_6),&v352_14_cursor.path()[(v352_14_origin + 1)..(v352_14_origin + 2)]);
          let mut v356_7 = Space::new();
          let mut v356_7_write = v356_7.write_zipper();
          for v356_7_byte in v352_14_cursor.child_mask().iter() {
            v352_14_cursor.descend_to_existing_byte(v356_7_byte);
            {
            let v357_2: Space = singleton(&v352_14_cursor.path()[(v352_14_origin + 2)..(v352_14_origin + 3)]);
            let v357_3: Space = intersect(&(*CONSTANT_1),&(v357_2));
            let v357_4: Space = if has_head(&(v357_3)) { singleton(&[]) } else { Space::new() };
            drop(v357_3);
            let v357_5: Space = subtract(&(*CONSTANT_0),&(v357_4));
            drop(v357_4);
            let v357_8: Space = if (&(v357_5)).is_empty() { Space::new() } else {
              let v358_6: Path = concat_path(&(v356_6),&v352_14_cursor.path()[(v352_14_origin + 2)..(v352_14_origin + 3)]);
              let v358_7: Space = routine_32(c, &(v358_6), &v352_14_cursor);
              compose(&(v357_5),&(v358_7))
            };
            drop(v357_5);
            let v357_9: Space = intersect(&(*CONSTANT_1),&(v357_2));
            drop(v357_2);
            let v357_10: Space = if has_head(&(v357_9)) { singleton(&[]) } else { Space::new() };
            drop(v357_9);
            let v357_12: Space = if (&(v357_10)).is_empty() { Space::new() } else {
              let v359_6: Path = concat_path(&(v356_6),&v352_14_cursor.path()[(v352_14_origin + 2)..(v352_14_origin + 3)]);
              let v359_11: Space = routine_33(c, &(v359_6), &v352_14_cursor);
              drop(v359_6);
              compose(&(v357_10),&(v359_11))
            };
            drop(v357_10);
            let v357_13: Space = unite(&(v357_8),&(v357_12));
            join_wrapped_into(&mut v356_7_write,&((v357_13).read_zipper()),&[]);
            }
            v352_14_cursor.ascend(1);
          }
          drop(v356_7_write);
          compose(&(v355_5),&(v356_7))
        };
        drop(v355_5);
        let v355_9: Space = intersect(&(*CONSTANT_1),&(v355_2));
        drop(v355_2);
        let v355_10: Space = if has_head(&(v355_9)) { singleton(&[]) } else { Space::new() };
        drop(v355_9);
        let v355_12: Space = if (&(v355_10)).is_empty() { Space::new() } else {
          let v360_6: Path = concat_path(&(v354_6),&v352_14_cursor.path()[(v352_14_origin + 1)..(v352_14_origin + 2)]);
          let mut v360_11 = Space::new();
          let mut v360_11_write = v360_11.write_zipper();
          for v360_11_byte in v352_14_cursor.child_mask().iter() {
            v352_14_cursor.descend_to_existing_byte(v360_11_byte);
            {
            let v361_2: Space = singleton(&v352_14_cursor.path()[(v352_14_origin + 2)..(v352_14_origin + 3)]);
            let v361_3: Space = intersect(&(*CONSTANT_1),&(v361_2));
            let v361_4: Space = if has_head(&(v361_3)) { singleton(&[]) } else { Space::new() };
            drop(v361_3);
            let v361_5: Space = subtract(&(*CONSTANT_0),&(v361_4));
            drop(v361_4);
            let v361_8: Space = if (&(v361_5)).is_empty() { Space::new() } else {
              let v362_6: Path = concat_path(&(v360_6),&v352_14_cursor.path()[(v352_14_origin + 2)..(v352_14_origin + 3)]);
              let v362_7: Space = routine_32(c, &(v362_6), &v352_14_cursor);
              compose(&(v361_5),&(v362_7))
            };
            drop(v361_5);
            let v361_9: Space = intersect(&(*CONSTANT_1),&(v361_2));
            drop(v361_2);
            let v361_10: Space = if has_head(&(v361_9)) { singleton(&[]) } else { Space::new() };
            drop(v361_9);
            let v361_12: Space = if (&(v361_10)).is_empty() { Space::new() } else {
              let v363_6: Path = concat_path(&(v360_6),&v352_14_cursor.path()[(v352_14_origin + 2)..(v352_14_origin + 3)]);
              let v363_11: Space = routine_12(c, &(v363_6), &v352_14_cursor);
              drop(v363_6);
              compose(&(v361_10),&(v363_11))
            };
            drop(v361_10);
            let v361_13: Space = unite(&(v361_8),&(v361_12));
            join_wrapped_into(&mut v360_11_write,&((v361_13).read_zipper()),&[]);
            }
            v352_14_cursor.ascend(1);
          }
          drop(v360_11_write);
          drop(v360_6);
          compose(&(v355_10),&(v360_11))
        };
        drop(v355_10);
        let v355_13: Space = unite(&(v355_8),&(v355_12));
        join_wrapped_into(&mut v354_7_write,&((v355_13).read_zipper()),&[]);
        }
        v352_14_cursor.ascend(1);
      }
      drop(v354_7_write);
      drop(v354_6);
      compose(&(v353_5),&(v354_7))
    };
    drop(v353_5);
    let v353_9: Space = intersect(&(*CONSTANT_1),&(v353_2));
    drop(v353_2);
    let v353_10: Space = if has_head(&(v353_9)) { singleton(&[]) } else { Space::new() };
    drop(v353_9);
    let v353_11: Space = compose(&(v353_10),&v352_14_cursor);
    drop(v353_10);
    let v353_12: Space = unite(&(v353_8),&(v353_11));
    drop(v353_11);
    join_wrapped_into(&mut v352_14_write,&((v353_12).read_zipper()),&[]);
    }
    v352_14_cursor.ascend(1);
  }
  drop(v352_14_cursor);
  drop(v352_14_write);
  (v352_14).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v364_20 = Space::new();
  let mut v364_20_write = v364_20.write_zipper();
  let mut v364_20_cursor = (*s0).read_zipper();
  let v364_20_origin = v364_20_cursor.path().len();
  for v364_20_byte in v364_20_cursor.child_mask().iter() {
    v364_20_cursor.descend_to_existing_byte(v364_20_byte);
    {
    let v365_2: Space = singleton(&v364_20_cursor.path()[v364_20_origin..(v364_20_origin + 1)]);
    let v365_3: Space = intersect(&(*CONSTANT_1),&(v365_2));
    let v365_4: Space = if has_head(&(v365_3)) { singleton(&[]) } else { Space::new() };
    drop(v365_3);
    let v365_5: Space = subtract(&(*CONSTANT_0),&(v365_4));
    drop(v365_4);
    let v365_8: Space = if (&(v365_5)).is_empty() { Space::new() } else {
      let v366_6: Path = concat_path(&(*p0),&v364_20_cursor.path()[v364_20_origin..(v364_20_origin + 1)]);
      let mut v366_7 = Space::new();
      let mut v366_7_write = v366_7.write_zipper();
      for v366_7_byte in v364_20_cursor.child_mask().iter() {
        v364_20_cursor.descend_to_existing_byte(v366_7_byte);
        {
        let v367_2: Space = singleton(&v364_20_cursor.path()[(v364_20_origin + 1)..(v364_20_origin + 2)]);
        let v367_3: Space = intersect(&(*CONSTANT_1),&(v367_2));
        let v367_4: Space = if has_head(&(v367_3)) { singleton(&[]) } else { Space::new() };
        drop(v367_3);
        let v367_5: Space = subtract(&(*CONSTANT_0),&(v367_4));
        drop(v367_4);
        let v367_8: Space = if (&(v367_5)).is_empty() { Space::new() } else {
          let v368_6: Path = concat_path(&(v366_6),&v364_20_cursor.path()[(v364_20_origin + 1)..(v364_20_origin + 2)]);
          let mut v368_7 = Space::new();
          let mut v368_7_write = v368_7.write_zipper();
          for v368_7_byte in v364_20_cursor.child_mask().iter() {
            v364_20_cursor.descend_to_existing_byte(v368_7_byte);
            {
            let v369_2: Space = singleton(&v364_20_cursor.path()[(v364_20_origin + 2)..(v364_20_origin + 3)]);
            let v369_3: Space = intersect(&(*CONSTANT_1),&(v369_2));
            let v369_4: Space = if has_head(&(v369_3)) { singleton(&[]) } else { Space::new() };
            drop(v369_3);
            let v369_5: Space = subtract(&(*CONSTANT_0),&(v369_4));
            drop(v369_4);
            let v369_8: Space = if (&(v369_5)).is_empty() { Space::new() } else {
              let v370_6: Path = concat_path(&(v368_6),&v364_20_cursor.path()[(v364_20_origin + 2)..(v364_20_origin + 3)]);
              let v370_7: Space = routine_34(c, &(v370_6), &v364_20_cursor);
              compose(&(v369_5),&(v370_7))
            };
            drop(v369_5);
            let v369_9: Space = intersect(&(*CONSTANT_1),&(v369_2));
            drop(v369_2);
            let v369_10: Space = if has_head(&(v369_9)) { singleton(&[]) } else { Space::new() };
            drop(v369_9);
            let v369_12: Space = if (&(v369_10)).is_empty() { Space::new() } else {
              let v371_6: Path = concat_path(&(v368_6),&v364_20_cursor.path()[(v364_20_origin + 2)..(v364_20_origin + 3)]);
              let v371_11: Space = routine_35(c, &(v371_6), &v364_20_cursor);
              drop(v371_6);
              compose(&(v369_10),&(v371_11))
            };
            drop(v369_10);
            let v369_13: Space = unite(&(v369_8),&(v369_12));
            join_wrapped_into(&mut v368_7_write,&((v369_13).read_zipper()),&[]);
            }
            v364_20_cursor.ascend(1);
          }
          drop(v368_7_write);
          compose(&(v367_5),&(v368_7))
        };
        drop(v367_5);
        let v367_9: Space = intersect(&(*CONSTANT_1),&(v367_2));
        drop(v367_2);
        let v367_10: Space = if has_head(&(v367_9)) { singleton(&[]) } else { Space::new() };
        drop(v367_9);
        let v367_12: Space = if (&(v367_10)).is_empty() { Space::new() } else {
          let v372_6: Path = concat_path(&(v366_6),&v364_20_cursor.path()[(v364_20_origin + 1)..(v364_20_origin + 2)]);
          let mut v372_11 = Space::new();
          let mut v372_11_write = v372_11.write_zipper();
          for v372_11_byte in v364_20_cursor.child_mask().iter() {
            v364_20_cursor.descend_to_existing_byte(v372_11_byte);
            {
            let v373_2: Space = singleton(&v364_20_cursor.path()[(v364_20_origin + 2)..(v364_20_origin + 3)]);
            let v373_3: Space = intersect(&(*CONSTANT_1),&(v373_2));
            let v373_4: Space = if has_head(&(v373_3)) { singleton(&[]) } else { Space::new() };
            drop(v373_3);
            let v373_5: Space = subtract(&(*CONSTANT_0),&(v373_4));
            drop(v373_4);
            let v373_8: Space = if (&(v373_5)).is_empty() { Space::new() } else {
              let v374_6: Path = concat_path(&(v372_6),&v364_20_cursor.path()[(v364_20_origin + 2)..(v364_20_origin + 3)]);
              let v374_7: Space = routine_34(c, &(v374_6), &v364_20_cursor);
              compose(&(v373_5),&(v374_7))
            };
            drop(v373_5);
            let v373_9: Space = intersect(&(*CONSTANT_1),&(v373_2));
            drop(v373_2);
            let v373_10: Space = if has_head(&(v373_9)) { singleton(&[]) } else { Space::new() };
            drop(v373_9);
            let v373_12: Space = if (&(v373_10)).is_empty() { Space::new() } else {
              let v375_6: Path = concat_path(&(v372_6),&v364_20_cursor.path()[(v364_20_origin + 2)..(v364_20_origin + 3)]);
              let v375_11: Space = routine_15(c, &(v375_6), &v364_20_cursor);
              drop(v375_6);
              compose(&(v373_10),&(v375_11))
            };
            drop(v373_10);
            let v373_13: Space = unite(&(v373_8),&(v373_12));
            join_wrapped_into(&mut v372_11_write,&((v373_13).read_zipper()),&[]);
            }
            v364_20_cursor.ascend(1);
          }
          drop(v372_11_write);
          drop(v372_6);
          compose(&(v367_10),&(v372_11))
        };
        drop(v367_10);
        let v367_13: Space = unite(&(v367_8),&(v367_12));
        join_wrapped_into(&mut v366_7_write,&((v367_13).read_zipper()),&[]);
        }
        v364_20_cursor.ascend(1);
      }
      drop(v366_7_write);
      compose(&(v365_5),&(v366_7))
    };
    drop(v365_5);
    let v365_9: Space = intersect(&(*CONSTANT_1),&(v365_2));
    drop(v365_2);
    let v365_10: Space = if has_head(&(v365_9)) { singleton(&[]) } else { Space::new() };
    drop(v365_9);
    let v365_12: Space = if (&(v365_10)).is_empty() { Space::new() } else {
      let v376_6: Path = concat_path(&(*p0),&v364_20_cursor.path()[v364_20_origin..(v364_20_origin + 1)]);
      let mut v376_11 = Space::new();
      let mut v376_11_write = v376_11.write_zipper();
      for v376_11_byte in v364_20_cursor.child_mask().iter() {
        v364_20_cursor.descend_to_existing_byte(v376_11_byte);
        {
        let v377_2: Space = singleton(&v364_20_cursor.path()[(v364_20_origin + 1)..(v364_20_origin + 2)]);
        let v377_3: Space = intersect(&(*CONSTANT_1),&(v377_2));
        let v377_4: Space = if has_head(&(v377_3)) { singleton(&[]) } else { Space::new() };
        drop(v377_3);
        let v377_5: Space = subtract(&(*CONSTANT_0),&(v377_4));
        drop(v377_4);
        let v377_8: Space = if (&(v377_5)).is_empty() { Space::new() } else {
          let v378_6: Path = concat_path(&(v376_6),&v364_20_cursor.path()[(v364_20_origin + 1)..(v364_20_origin + 2)]);
          let mut v378_7 = Space::new();
          let mut v378_7_write = v378_7.write_zipper();
          for v378_7_byte in v364_20_cursor.child_mask().iter() {
            v364_20_cursor.descend_to_existing_byte(v378_7_byte);
            {
            let v379_2: Space = singleton(&v364_20_cursor.path()[(v364_20_origin + 2)..(v364_20_origin + 3)]);
            let v379_3: Space = intersect(&(*CONSTANT_1),&(v379_2));
            let v379_4: Space = if has_head(&(v379_3)) { singleton(&[]) } else { Space::new() };
            drop(v379_3);
            let v379_5: Space = subtract(&(*CONSTANT_0),&(v379_4));
            drop(v379_4);
            let v379_8: Space = if (&(v379_5)).is_empty() { Space::new() } else {
              let v380_6: Path = concat_path(&(v378_6),&v364_20_cursor.path()[(v364_20_origin + 2)..(v364_20_origin + 3)]);
              let v380_7: Space = routine_34(c, &(v380_6), &v364_20_cursor);
              compose(&(v379_5),&(v380_7))
            };
            drop(v379_5);
            let v379_9: Space = intersect(&(*CONSTANT_1),&(v379_2));
            drop(v379_2);
            let v379_10: Space = if has_head(&(v379_9)) { singleton(&[]) } else { Space::new() };
            drop(v379_9);
            let v379_12: Space = if (&(v379_10)).is_empty() { Space::new() } else {
              let v381_6: Path = concat_path(&(v378_6),&v364_20_cursor.path()[(v364_20_origin + 2)..(v364_20_origin + 3)]);
              let v381_11: Space = routine_35(c, &(v381_6), &v364_20_cursor);
              drop(v381_6);
              compose(&(v379_10),&(v381_11))
            };
            drop(v379_10);
            let v379_13: Space = unite(&(v379_8),&(v379_12));
            join_wrapped_into(&mut v378_7_write,&((v379_13).read_zipper()),&[]);
            }
            v364_20_cursor.ascend(1);
          }
          drop(v378_7_write);
          drop(v378_6);
          compose(&(v377_5),&(v378_7))
        };
        drop(v377_5);
        let v377_9: Space = intersect(&(*CONSTANT_1),&(v377_2));
        drop(v377_2);
        let v377_10: Space = if has_head(&(v377_9)) { singleton(&[]) } else { Space::new() };
        drop(v377_9);
        let v377_11: Space = compose(&(v377_10),&v364_20_cursor);
        drop(v377_10);
        let v377_12: Space = unite(&(v377_8),&(v377_11));
        drop(v377_11);
        join_wrapped_into(&mut v376_11_write,&((v377_12).read_zipper()),&[]);
        }
        v364_20_cursor.ascend(1);
      }
      drop(v376_11_write);
      drop(v376_6);
      compose(&(v365_10),&(v376_11))
    };
    drop(v365_10);
    let v365_13: Space = unite(&(v365_8),&(v365_12));
    join_wrapped_into(&mut v364_20_write,&((v365_13).read_zipper()),&[]);
    }
    v364_20_cursor.ascend(1);
  }
  drop(v364_20_cursor);
  drop(v364_20_write);
  (v364_20).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v382_14 = Space::new();
  let mut v382_14_write = v382_14.write_zipper();
  let mut v382_14_cursor = (*s0).read_zipper();
  let v382_14_origin = v382_14_cursor.path().len();
  for v382_14_byte in v382_14_cursor.child_mask().iter() {
    v382_14_cursor.descend_to_existing_byte(v382_14_byte);
    {
    let v383_2: Space = singleton(&v382_14_cursor.path()[v382_14_origin..(v382_14_origin + 1)]);
    let v383_3: Space = intersect(&(*CONSTANT_1),&(v383_2));
    let v383_4: Space = if has_head(&(v383_3)) { singleton(&[]) } else { Space::new() };
    drop(v383_3);
    let v383_5: Space = subtract(&(*CONSTANT_0),&(v383_4));
    drop(v383_4);
    let v383_8: Space = if (&(v383_5)).is_empty() { Space::new() } else {
      let v384_6: Path = concat_path(&(*p0),&v382_14_cursor.path()[v382_14_origin..(v382_14_origin + 1)]);
      let mut v384_7 = Space::new();
      let mut v384_7_write = v384_7.write_zipper();
      for v384_7_byte in v382_14_cursor.child_mask().iter() {
        v382_14_cursor.descend_to_existing_byte(v384_7_byte);
        {
        let v385_2: Space = singleton(&v382_14_cursor.path()[(v382_14_origin + 1)..(v382_14_origin + 2)]);
        let v385_3: Space = intersect(&(*CONSTANT_1),&(v385_2));
        let v385_4: Space = if has_head(&(v385_3)) { singleton(&[]) } else { Space::new() };
        drop(v385_3);
        let v385_5: Space = subtract(&(*CONSTANT_0),&(v385_4));
        drop(v385_4);
        let v385_8: Space = if (&(v385_5)).is_empty() { Space::new() } else {
          let v386_6: Path = concat_path(&(v384_6),&v382_14_cursor.path()[(v382_14_origin + 1)..(v382_14_origin + 2)]);
          let mut v386_7 = Space::new();
          let mut v386_7_write = v386_7.write_zipper();
          for v386_7_byte in v382_14_cursor.child_mask().iter() {
            v382_14_cursor.descend_to_existing_byte(v386_7_byte);
            {
            let v387_2: Space = singleton(&v382_14_cursor.path()[(v382_14_origin + 2)..(v382_14_origin + 3)]);
            let v387_3: Space = intersect(&(*CONSTANT_1),&(v387_2));
            let v387_4: Space = if has_head(&(v387_3)) { singleton(&[]) } else { Space::new() };
            drop(v387_3);
            let v387_5: Space = subtract(&(*CONSTANT_0),&(v387_4));
            drop(v387_4);
            let v387_8: Space = if (&(v387_5)).is_empty() { Space::new() } else {
              let v388_6: Path = concat_path(&(v386_6),&v382_14_cursor.path()[(v382_14_origin + 2)..(v382_14_origin + 3)]);
              let v388_7: Space = routine_34(c, &(v388_6), &v382_14_cursor);
              compose(&(v387_5),&(v388_7))
            };
            drop(v387_5);
            let v387_9: Space = intersect(&(*CONSTANT_1),&(v387_2));
            drop(v387_2);
            let v387_10: Space = if has_head(&(v387_9)) { singleton(&[]) } else { Space::new() };
            drop(v387_9);
            let v387_12: Space = if (&(v387_10)).is_empty() { Space::new() } else {
              let v389_6: Path = concat_path(&(v386_6),&v382_14_cursor.path()[(v382_14_origin + 2)..(v382_14_origin + 3)]);
              let v389_11: Space = routine_35(c, &(v389_6), &v382_14_cursor);
              drop(v389_6);
              compose(&(v387_10),&(v389_11))
            };
            drop(v387_10);
            let v387_13: Space = unite(&(v387_8),&(v387_12));
            join_wrapped_into(&mut v386_7_write,&((v387_13).read_zipper()),&[]);
            }
            v382_14_cursor.ascend(1);
          }
          drop(v386_7_write);
          compose(&(v385_5),&(v386_7))
        };
        drop(v385_5);
        let v385_9: Space = intersect(&(*CONSTANT_1),&(v385_2));
        drop(v385_2);
        let v385_10: Space = if has_head(&(v385_9)) { singleton(&[]) } else { Space::new() };
        drop(v385_9);
        let v385_12: Space = if (&(v385_10)).is_empty() { Space::new() } else {
          let v390_6: Path = concat_path(&(v384_6),&v382_14_cursor.path()[(v382_14_origin + 1)..(v382_14_origin + 2)]);
          let mut v390_11 = Space::new();
          let mut v390_11_write = v390_11.write_zipper();
          for v390_11_byte in v382_14_cursor.child_mask().iter() {
            v382_14_cursor.descend_to_existing_byte(v390_11_byte);
            {
            let v391_2: Space = singleton(&v382_14_cursor.path()[(v382_14_origin + 2)..(v382_14_origin + 3)]);
            let v391_3: Space = intersect(&(*CONSTANT_1),&(v391_2));
            let v391_4: Space = if has_head(&(v391_3)) { singleton(&[]) } else { Space::new() };
            drop(v391_3);
            let v391_5: Space = subtract(&(*CONSTANT_0),&(v391_4));
            drop(v391_4);
            let v391_8: Space = if (&(v391_5)).is_empty() { Space::new() } else {
              let v392_6: Path = concat_path(&(v390_6),&v382_14_cursor.path()[(v382_14_origin + 2)..(v382_14_origin + 3)]);
              let v392_7: Space = routine_34(c, &(v392_6), &v382_14_cursor);
              compose(&(v391_5),&(v392_7))
            };
            drop(v391_5);
            let v391_9: Space = intersect(&(*CONSTANT_1),&(v391_2));
            drop(v391_2);
            let v391_10: Space = if has_head(&(v391_9)) { singleton(&[]) } else { Space::new() };
            drop(v391_9);
            let v391_12: Space = if (&(v391_10)).is_empty() { Space::new() } else {
              let v393_6: Path = concat_path(&(v390_6),&v382_14_cursor.path()[(v382_14_origin + 2)..(v382_14_origin + 3)]);
              let v393_11: Space = routine_15(c, &(v393_6), &v382_14_cursor);
              drop(v393_6);
              compose(&(v391_10),&(v393_11))
            };
            drop(v391_10);
            let v391_13: Space = unite(&(v391_8),&(v391_12));
            join_wrapped_into(&mut v390_11_write,&((v391_13).read_zipper()),&[]);
            }
            v382_14_cursor.ascend(1);
          }
          drop(v390_11_write);
          drop(v390_6);
          compose(&(v385_10),&(v390_11))
        };
        drop(v385_10);
        let v385_13: Space = unite(&(v385_8),&(v385_12));
        join_wrapped_into(&mut v384_7_write,&((v385_13).read_zipper()),&[]);
        }
        v382_14_cursor.ascend(1);
      }
      drop(v384_7_write);
      drop(v384_6);
      compose(&(v383_5),&(v384_7))
    };
    drop(v383_5);
    let v383_9: Space = intersect(&(*CONSTANT_1),&(v383_2));
    drop(v383_2);
    let v383_10: Space = if has_head(&(v383_9)) { singleton(&[]) } else { Space::new() };
    drop(v383_9);
    let v383_11: Space = compose(&(v383_10),&v382_14_cursor);
    drop(v383_10);
    let v383_12: Space = unite(&(v383_8),&(v383_11));
    drop(v383_11);
    join_wrapped_into(&mut v382_14_write,&((v383_12).read_zipper()),&[]);
    }
    v382_14_cursor.ascend(1);
  }
  drop(v382_14_cursor);
  drop(v382_14_write);
  (v382_14).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v394_12 = Space::new();
  let mut v394_12_write = v394_12.write_zipper();
  let mut v394_12_cursor = (*s0).read_zipper();
  let v394_12_origin = v394_12_cursor.path().len();
  for v394_12_byte in v394_12_cursor.child_mask().iter() {
    v394_12_cursor.descend_to_existing_byte(v394_12_byte);
    {
    let v395_2: Space = singleton(&v394_12_cursor.path()[v394_12_origin..(v394_12_origin + 1)]);
    let v395_3: Space = intersect(&(*CONSTANT_1),&(v395_2));
    let v395_4: Space = if has_head(&(v395_3)) { singleton(&[]) } else { Space::new() };
    drop(v395_3);
    let v395_5: Space = subtract(&(*CONSTANT_0),&(v395_4));
    drop(v395_4);
    let v395_8: Space = if (&(v395_5)).is_empty() { Space::new() } else {
      let v396_6: Path = concat_path(&(*p0),&v394_12_cursor.path()[v394_12_origin..(v394_12_origin + 1)]);
      let mut v396_7 = Space::new();
      let mut v396_7_write = v396_7.write_zipper();
      for v396_7_byte in v394_12_cursor.child_mask().iter() {
        v394_12_cursor.descend_to_existing_byte(v396_7_byte);
        {
        let v397_2: Space = singleton(&v394_12_cursor.path()[(v394_12_origin + 1)..(v394_12_origin + 2)]);
        let v397_3: Space = intersect(&(*CONSTANT_1),&(v397_2));
        let v397_4: Space = if has_head(&(v397_3)) { singleton(&[]) } else { Space::new() };
        drop(v397_3);
        let v397_5: Space = subtract(&(*CONSTANT_0),&(v397_4));
        drop(v397_4);
        let v397_7: Space = if (&(v397_5)).is_empty() { Space::new() } else {
          let mut v398_6 = Space::new();
          let mut v398_6_write = v398_6.write_zipper();
          for v398_6_byte in v394_12_cursor.child_mask().iter() {
            v394_12_cursor.descend_to_existing_byte(v398_6_byte);
            {
            let v399_2: Space = Space::new();
            join_wrapped_into(&mut v398_6_write,&((v399_2).read_zipper()),&[]);
            }
            v394_12_cursor.ascend(1);
          }
          drop(v398_6_write);
          compose(&(v397_5),&(v398_6))
        };
        drop(v397_5);
        let v397_8: Space = intersect(&(*CONSTANT_1),&(v397_2));
        drop(v397_2);
        let v397_9: Space = if has_head(&(v397_8)) { singleton(&[]) } else { Space::new() };
        drop(v397_8);
        let v397_12: Space = if (&(v397_9)).is_empty() { Space::new() } else {
          let v400_10: Path = concat_path(&(v396_6),&v394_12_cursor.path()[(v394_12_origin + 1)..(v394_12_origin + 2)]);
          let mut v400_11 = Space::new();
          let mut v400_11_write = v400_11.write_zipper();
          for v400_11_byte in v394_12_cursor.child_mask().iter() {
            v394_12_cursor.descend_to_existing_byte(v400_11_byte);
            {
            let v401_2: Space = singleton(&v394_12_cursor.path()[(v394_12_origin + 2)..(v394_12_origin + 3)]);
            let v401_3: Space = intersect(&(*CONSTANT_1),&(v401_2));
            drop(v401_2);
            let v401_4: Space = if has_head(&(v401_3)) { singleton(&[]) } else { Space::new() };
            drop(v401_3);
            let v401_7: Space = if (&(v401_4)).is_empty() { Space::new() } else {
              let v402_5: Path = concat_path(&(v400_10),&v394_12_cursor.path()[(v394_12_origin + 2)..(v394_12_origin + 3)]);
              let v402_6: Space = routine_12(c, &(v402_5), &v394_12_cursor);
              drop(v402_5);
              compose(&(v401_4),&(v402_6))
            };
            drop(v401_4);
            join_wrapped_into(&mut v400_11_write,&((v401_7).read_zipper()),&[]);
            }
            v394_12_cursor.ascend(1);
          }
          drop(v400_11_write);
          drop(v400_10);
          compose(&(v397_9),&(v400_11))
        };
        drop(v397_9);
        let v397_13: Space = unite(&(v397_7),&(v397_12));
        drop(v397_7);
        join_wrapped_into(&mut v396_7_write,&((v397_13).read_zipper()),&[]);
        }
        v394_12_cursor.ascend(1);
      }
      drop(v396_7_write);
      drop(v396_6);
      compose(&(v395_5),&(v396_7))
    };
    drop(v395_5);
    let v395_9: Space = intersect(&(*CONSTANT_1),&(v395_2));
    drop(v395_2);
    let v395_10: Space = if has_head(&(v395_9)) { singleton(&[]) } else { Space::new() };
    drop(v395_9);
    let v395_12: Space = if (&(v395_10)).is_empty() { Space::new() } else {
      let mut v403_11 = Space::new();
      let mut v403_11_write = v403_11.write_zipper();
      for v403_11_byte in v394_12_cursor.child_mask().iter() {
        v394_12_cursor.descend_to_existing_byte(v403_11_byte);
        {
        let v404_2: Space = singleton(&v394_12_cursor.path()[(v394_12_origin + 1)..(v394_12_origin + 2)]);
        let v404_3: Space = intersect(&(*CONSTANT_1),&(v404_2));
        let v404_4: Space = if has_head(&(v404_3)) { singleton(&[]) } else { Space::new() };
        drop(v404_3);
        let v404_5: Space = subtract(&(*CONSTANT_0),&(v404_4));
        drop(v404_4);
        let v404_7: Space = if (&(v404_5)).is_empty() { Space::new() } else {
          let mut v405_6 = Space::new();
          let mut v405_6_write = v405_6.write_zipper();
          for v405_6_byte in v394_12_cursor.child_mask().iter() {
            v394_12_cursor.descend_to_existing_byte(v405_6_byte);
            {
            let v406_2: Space = Space::new();
            join_wrapped_into(&mut v405_6_write,&((v406_2).read_zipper()),&[]);
            }
            v394_12_cursor.ascend(1);
          }
          drop(v405_6_write);
          compose(&(v404_5),&(v405_6))
        };
        drop(v404_5);
        let v404_8: Space = intersect(&(*CONSTANT_1),&(v404_2));
        drop(v404_2);
        let v404_9: Space = if has_head(&(v404_8)) { singleton(&[]) } else { Space::new() };
        drop(v404_8);
        let v404_10: Space = compose(&(v404_9),&v394_12_cursor);
        drop(v404_9);
        let v404_11: Space = unite(&(v404_7),&(v404_10));
        drop(v404_7);
        drop(v404_10);
        join_wrapped_into(&mut v403_11_write,&((v404_11).read_zipper()),&[]);
        }
        v394_12_cursor.ascend(1);
      }
      drop(v403_11_write);
      compose(&(v395_10),&(v403_11))
    };
    drop(v395_10);
    let v395_13: Space = unite(&(v395_8),&(v395_12));
    drop(v395_12);
    join_wrapped_into(&mut v394_12_write,&((v395_13).read_zipper()),&[]);
    }
    v394_12_cursor.ascend(1);
  }
  drop(v394_12_cursor);
  drop(v394_12_write);
  (v394_12).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v407_9 = Space::new();
  let mut v407_9_write = v407_9.write_zipper();
  let mut v407_9_cursor = (*s0).read_zipper();
  let v407_9_origin = v407_9_cursor.path().len();
  for v407_9_byte in v407_9_cursor.child_mask().iter() {
    v407_9_cursor.descend_to_existing_byte(v407_9_byte);
    {
    let v408_2: Space = singleton(&v407_9_cursor.path()[v407_9_origin..(v407_9_origin + 1)]);
    let v408_3: Space = intersect(&(*CONSTANT_1),&(v408_2));
    let v408_4: Space = if has_head(&(v408_3)) { singleton(&[]) } else { Space::new() };
    drop(v408_3);
    let v408_5: Space = subtract(&(*CONSTANT_0),&(v408_4));
    drop(v408_4);
    let v408_8: Space = if (&(v408_5)).is_empty() { Space::new() } else {
      let v409_6: Path = concat_path(&(*p0),&v407_9_cursor.path()[v407_9_origin..(v407_9_origin + 1)]);
      let mut v409_7 = Space::new();
      let mut v409_7_write = v409_7.write_zipper();
      for v409_7_byte in v407_9_cursor.child_mask().iter() {
        v407_9_cursor.descend_to_existing_byte(v409_7_byte);
        {
        let v410_2: Space = singleton(&v407_9_cursor.path()[(v407_9_origin + 1)..(v407_9_origin + 2)]);
        let v410_3: Space = intersect(&(*CONSTANT_1),&(v410_2));
        let v410_4: Space = if has_head(&(v410_3)) { singleton(&[]) } else { Space::new() };
        drop(v410_3);
        let v410_5: Space = subtract(&(*CONSTANT_0),&(v410_4));
        drop(v410_4);
        let v410_7: Space = if (&(v410_5)).is_empty() { Space::new() } else {
          let mut v411_6 = Space::new();
          let mut v411_6_write = v411_6.write_zipper();
          for v411_6_byte in v407_9_cursor.child_mask().iter() {
            v407_9_cursor.descend_to_existing_byte(v411_6_byte);
            {
            let v412_2: Space = Space::new();
            join_wrapped_into(&mut v411_6_write,&((v412_2).read_zipper()),&[]);
            }
            v407_9_cursor.ascend(1);
          }
          drop(v411_6_write);
          compose(&(v410_5),&(v411_6))
        };
        drop(v410_5);
        let v410_8: Space = intersect(&(*CONSTANT_1),&(v410_2));
        drop(v410_2);
        let v410_9: Space = if has_head(&(v410_8)) { singleton(&[]) } else { Space::new() };
        drop(v410_8);
        let v410_12: Space = if (&(v410_9)).is_empty() { Space::new() } else {
          let v413_10: Path = concat_path(&(v409_6),&v407_9_cursor.path()[(v407_9_origin + 1)..(v407_9_origin + 2)]);
          let mut v413_11 = Space::new();
          let mut v413_11_write = v413_11.write_zipper();
          for v413_11_byte in v407_9_cursor.child_mask().iter() {
            v407_9_cursor.descend_to_existing_byte(v413_11_byte);
            {
            let v414_2: Space = singleton(&v407_9_cursor.path()[(v407_9_origin + 2)..(v407_9_origin + 3)]);
            let v414_3: Space = intersect(&(*CONSTANT_1),&(v414_2));
            drop(v414_2);
            let v414_4: Space = if has_head(&(v414_3)) { singleton(&[]) } else { Space::new() };
            drop(v414_3);
            let v414_7: Space = if (&(v414_4)).is_empty() { Space::new() } else {
              let v415_5: Path = concat_path(&(v413_10),&v407_9_cursor.path()[(v407_9_origin + 2)..(v407_9_origin + 3)]);
              let v415_6: Space = routine_12(c, &(v415_5), &v407_9_cursor);
              drop(v415_5);
              compose(&(v414_4),&(v415_6))
            };
            drop(v414_4);
            join_wrapped_into(&mut v413_11_write,&((v414_7).read_zipper()),&[]);
            }
            v407_9_cursor.ascend(1);
          }
          drop(v413_11_write);
          drop(v413_10);
          compose(&(v410_9),&(v413_11))
        };
        drop(v410_9);
        let v410_13: Space = unite(&(v410_7),&(v410_12));
        drop(v410_7);
        join_wrapped_into(&mut v409_7_write,&((v410_13).read_zipper()),&[]);
        }
        v407_9_cursor.ascend(1);
      }
      drop(v409_7_write);
      drop(v409_6);
      compose(&(v408_5),&(v409_7))
    };
    drop(v408_5);
    let v408_9: Space = intersect(&(*CONSTANT_1),&(v408_2));
    drop(v408_2);
    let v408_10: Space = if has_head(&(v408_9)) { singleton(&[]) } else { Space::new() };
    drop(v408_9);
    let v408_11: Space = compose(&(v408_10),&v407_9_cursor);
    drop(v408_10);
    let v408_12: Space = unite(&(v408_8),&(v408_11));
    drop(v408_11);
    join_wrapped_into(&mut v407_9_write,&((v408_12).read_zipper()),&[]);
    }
    v407_9_cursor.ascend(1);
  }
  drop(v407_9_cursor);
  drop(v407_9_write);
  (v407_9).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v416_12 = Space::new();
  let mut v416_12_write = v416_12.write_zipper();
  let mut v416_12_cursor = (*s0).read_zipper();
  let v416_12_origin = v416_12_cursor.path().len();
  for v416_12_byte in v416_12_cursor.child_mask().iter() {
    v416_12_cursor.descend_to_existing_byte(v416_12_byte);
    {
    let v417_2: Space = singleton(&v416_12_cursor.path()[v416_12_origin..(v416_12_origin + 1)]);
    let v417_3: Space = intersect(&(*CONSTANT_1),&(v417_2));
    let v417_4: Space = if has_head(&(v417_3)) { singleton(&[]) } else { Space::new() };
    drop(v417_3);
    let v417_5: Space = subtract(&(*CONSTANT_0),&(v417_4));
    drop(v417_4);
    let v417_8: Space = if (&(v417_5)).is_empty() { Space::new() } else {
      let v418_6: Path = concat_path(&(*p0),&v416_12_cursor.path()[v416_12_origin..(v416_12_origin + 1)]);
      let mut v418_7 = Space::new();
      let mut v418_7_write = v418_7.write_zipper();
      for v418_7_byte in v416_12_cursor.child_mask().iter() {
        v416_12_cursor.descend_to_existing_byte(v418_7_byte);
        {
        let v419_2: Space = singleton(&v416_12_cursor.path()[(v416_12_origin + 1)..(v416_12_origin + 2)]);
        let v419_3: Space = intersect(&(*CONSTANT_1),&(v419_2));
        let v419_4: Space = if has_head(&(v419_3)) { singleton(&[]) } else { Space::new() };
        drop(v419_3);
        let v419_5: Space = subtract(&(*CONSTANT_0),&(v419_4));
        drop(v419_4);
        let v419_7: Space = if (&(v419_5)).is_empty() { Space::new() } else {
          let mut v420_6 = Space::new();
          let mut v420_6_write = v420_6.write_zipper();
          for v420_6_byte in v416_12_cursor.child_mask().iter() {
            v416_12_cursor.descend_to_existing_byte(v420_6_byte);
            {
            let v421_2: Space = Space::new();
            join_wrapped_into(&mut v420_6_write,&((v421_2).read_zipper()),&[]);
            }
            v416_12_cursor.ascend(1);
          }
          drop(v420_6_write);
          compose(&(v419_5),&(v420_6))
        };
        drop(v419_5);
        let v419_8: Space = intersect(&(*CONSTANT_1),&(v419_2));
        drop(v419_2);
        let v419_9: Space = if has_head(&(v419_8)) { singleton(&[]) } else { Space::new() };
        drop(v419_8);
        let v419_12: Space = if (&(v419_9)).is_empty() { Space::new() } else {
          let v422_10: Path = concat_path(&(v418_6),&v416_12_cursor.path()[(v416_12_origin + 1)..(v416_12_origin + 2)]);
          let mut v422_11 = Space::new();
          let mut v422_11_write = v422_11.write_zipper();
          for v422_11_byte in v416_12_cursor.child_mask().iter() {
            v416_12_cursor.descend_to_existing_byte(v422_11_byte);
            {
            let v423_2: Space = singleton(&v416_12_cursor.path()[(v416_12_origin + 2)..(v416_12_origin + 3)]);
            let v423_3: Space = intersect(&(*CONSTANT_1),&(v423_2));
            drop(v423_2);
            let v423_4: Space = if has_head(&(v423_3)) { singleton(&[]) } else { Space::new() };
            drop(v423_3);
            let v423_7: Space = if (&(v423_4)).is_empty() { Space::new() } else {
              let v424_5: Path = concat_path(&(v422_10),&v416_12_cursor.path()[(v416_12_origin + 2)..(v416_12_origin + 3)]);
              let v424_6: Space = routine_15(c, &(v424_5), &v416_12_cursor);
              drop(v424_5);
              compose(&(v423_4),&(v424_6))
            };
            drop(v423_4);
            join_wrapped_into(&mut v422_11_write,&((v423_7).read_zipper()),&[]);
            }
            v416_12_cursor.ascend(1);
          }
          drop(v422_11_write);
          drop(v422_10);
          compose(&(v419_9),&(v422_11))
        };
        drop(v419_9);
        let v419_13: Space = unite(&(v419_7),&(v419_12));
        drop(v419_7);
        join_wrapped_into(&mut v418_7_write,&((v419_13).read_zipper()),&[]);
        }
        v416_12_cursor.ascend(1);
      }
      drop(v418_7_write);
      drop(v418_6);
      compose(&(v417_5),&(v418_7))
    };
    drop(v417_5);
    let v417_9: Space = intersect(&(*CONSTANT_1),&(v417_2));
    drop(v417_2);
    let v417_10: Space = if has_head(&(v417_9)) { singleton(&[]) } else { Space::new() };
    drop(v417_9);
    let v417_12: Space = if (&(v417_10)).is_empty() { Space::new() } else {
      let mut v425_11 = Space::new();
      let mut v425_11_write = v425_11.write_zipper();
      for v425_11_byte in v416_12_cursor.child_mask().iter() {
        v416_12_cursor.descend_to_existing_byte(v425_11_byte);
        {
        let v426_2: Space = singleton(&v416_12_cursor.path()[(v416_12_origin + 1)..(v416_12_origin + 2)]);
        let v426_3: Space = intersect(&(*CONSTANT_1),&(v426_2));
        let v426_4: Space = if has_head(&(v426_3)) { singleton(&[]) } else { Space::new() };
        drop(v426_3);
        let v426_5: Space = subtract(&(*CONSTANT_0),&(v426_4));
        drop(v426_4);
        let v426_7: Space = if (&(v426_5)).is_empty() { Space::new() } else {
          let mut v427_6 = Space::new();
          let mut v427_6_write = v427_6.write_zipper();
          for v427_6_byte in v416_12_cursor.child_mask().iter() {
            v416_12_cursor.descend_to_existing_byte(v427_6_byte);
            {
            let v428_2: Space = Space::new();
            join_wrapped_into(&mut v427_6_write,&((v428_2).read_zipper()),&[]);
            }
            v416_12_cursor.ascend(1);
          }
          drop(v427_6_write);
          compose(&(v426_5),&(v427_6))
        };
        drop(v426_5);
        let v426_8: Space = intersect(&(*CONSTANT_1),&(v426_2));
        drop(v426_2);
        let v426_9: Space = if has_head(&(v426_8)) { singleton(&[]) } else { Space::new() };
        drop(v426_8);
        let v426_10: Space = compose(&(v426_9),&v416_12_cursor);
        drop(v426_9);
        let v426_11: Space = unite(&(v426_7),&(v426_10));
        drop(v426_7);
        drop(v426_10);
        join_wrapped_into(&mut v425_11_write,&((v426_11).read_zipper()),&[]);
        }
        v416_12_cursor.ascend(1);
      }
      drop(v425_11_write);
      compose(&(v417_10),&(v425_11))
    };
    drop(v417_10);
    let v417_13: Space = unite(&(v417_8),&(v417_12));
    drop(v417_12);
    join_wrapped_into(&mut v416_12_write,&((v417_13).read_zipper()),&[]);
    }
    v416_12_cursor.ascend(1);
  }
  drop(v416_12_cursor);
  drop(v416_12_write);
  (v416_12).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v429_9 = Space::new();
  let mut v429_9_write = v429_9.write_zipper();
  let mut v429_9_cursor = (*s0).read_zipper();
  let v429_9_origin = v429_9_cursor.path().len();
  for v429_9_byte in v429_9_cursor.child_mask().iter() {
    v429_9_cursor.descend_to_existing_byte(v429_9_byte);
    {
    let v430_2: Space = singleton(&v429_9_cursor.path()[v429_9_origin..(v429_9_origin + 1)]);
    let v430_3: Space = intersect(&(*CONSTANT_1),&(v430_2));
    let v430_4: Space = if has_head(&(v430_3)) { singleton(&[]) } else { Space::new() };
    drop(v430_3);
    let v430_5: Space = subtract(&(*CONSTANT_0),&(v430_4));
    drop(v430_4);
    let v430_8: Space = if (&(v430_5)).is_empty() { Space::new() } else {
      let v431_6: Path = concat_path(&(*p0),&v429_9_cursor.path()[v429_9_origin..(v429_9_origin + 1)]);
      let mut v431_7 = Space::new();
      let mut v431_7_write = v431_7.write_zipper();
      for v431_7_byte in v429_9_cursor.child_mask().iter() {
        v429_9_cursor.descend_to_existing_byte(v431_7_byte);
        {
        let v432_2: Space = singleton(&v429_9_cursor.path()[(v429_9_origin + 1)..(v429_9_origin + 2)]);
        let v432_3: Space = intersect(&(*CONSTANT_1),&(v432_2));
        let v432_4: Space = if has_head(&(v432_3)) { singleton(&[]) } else { Space::new() };
        drop(v432_3);
        let v432_5: Space = subtract(&(*CONSTANT_0),&(v432_4));
        drop(v432_4);
        let v432_7: Space = if (&(v432_5)).is_empty() { Space::new() } else {
          let mut v433_6 = Space::new();
          let mut v433_6_write = v433_6.write_zipper();
          for v433_6_byte in v429_9_cursor.child_mask().iter() {
            v429_9_cursor.descend_to_existing_byte(v433_6_byte);
            {
            let v434_2: Space = Space::new();
            join_wrapped_into(&mut v433_6_write,&((v434_2).read_zipper()),&[]);
            }
            v429_9_cursor.ascend(1);
          }
          drop(v433_6_write);
          compose(&(v432_5),&(v433_6))
        };
        drop(v432_5);
        let v432_8: Space = intersect(&(*CONSTANT_1),&(v432_2));
        drop(v432_2);
        let v432_9: Space = if has_head(&(v432_8)) { singleton(&[]) } else { Space::new() };
        drop(v432_8);
        let v432_12: Space = if (&(v432_9)).is_empty() { Space::new() } else {
          let v435_10: Path = concat_path(&(v431_6),&v429_9_cursor.path()[(v429_9_origin + 1)..(v429_9_origin + 2)]);
          let mut v435_11 = Space::new();
          let mut v435_11_write = v435_11.write_zipper();
          for v435_11_byte in v429_9_cursor.child_mask().iter() {
            v429_9_cursor.descend_to_existing_byte(v435_11_byte);
            {
            let v436_2: Space = singleton(&v429_9_cursor.path()[(v429_9_origin + 2)..(v429_9_origin + 3)]);
            let v436_3: Space = intersect(&(*CONSTANT_1),&(v436_2));
            drop(v436_2);
            let v436_4: Space = if has_head(&(v436_3)) { singleton(&[]) } else { Space::new() };
            drop(v436_3);
            let v436_7: Space = if (&(v436_4)).is_empty() { Space::new() } else {
              let v437_5: Path = concat_path(&(v435_10),&v429_9_cursor.path()[(v429_9_origin + 2)..(v429_9_origin + 3)]);
              let v437_6: Space = routine_15(c, &(v437_5), &v429_9_cursor);
              drop(v437_5);
              compose(&(v436_4),&(v437_6))
            };
            drop(v436_4);
            join_wrapped_into(&mut v435_11_write,&((v436_7).read_zipper()),&[]);
            }
            v429_9_cursor.ascend(1);
          }
          drop(v435_11_write);
          drop(v435_10);
          compose(&(v432_9),&(v435_11))
        };
        drop(v432_9);
        let v432_13: Space = unite(&(v432_7),&(v432_12));
        drop(v432_7);
        join_wrapped_into(&mut v431_7_write,&((v432_13).read_zipper()),&[]);
        }
        v429_9_cursor.ascend(1);
      }
      drop(v431_7_write);
      drop(v431_6);
      compose(&(v430_5),&(v431_7))
    };
    drop(v430_5);
    let v430_9: Space = intersect(&(*CONSTANT_1),&(v430_2));
    drop(v430_2);
    let v430_10: Space = if has_head(&(v430_9)) { singleton(&[]) } else { Space::new() };
    drop(v430_9);
    let v430_11: Space = compose(&(v430_10),&v429_9_cursor);
    drop(v430_10);
    let v430_12: Space = unite(&(v430_8),&(v430_11));
    drop(v430_11);
    join_wrapped_into(&mut v429_9_write,&((v430_12).read_zipper()),&[]);
    }
    v429_9_cursor.ascend(1);
  }
  drop(v429_9_cursor);
  drop(v429_9_write);
  (v429_9).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v438_6 = Space::new();
  let mut v438_6_write = v438_6.write_zipper();
  let mut v438_6_cursor = (*s0).read_zipper();
  let v438_6_origin = v438_6_cursor.path().len();
  for v438_6_byte in v438_6_cursor.child_mask().iter() {
    v438_6_cursor.descend_to_existing_byte(v438_6_byte);
    {
    let v439_2: Space = singleton(&v438_6_cursor.path()[v438_6_origin..(v438_6_origin + 1)]);
    let v439_3: Space = intersect(&(*CONSTANT_1),&(v439_2));
    let v439_4: Space = if has_head(&(v439_3)) { singleton(&[]) } else { Space::new() };
    drop(v439_3);
    let v439_5: Space = subtract(&(*CONSTANT_0),&(v439_4));
    drop(v439_4);
    let v439_7: Space = if (&(v439_5)).is_empty() { Space::new() } else {
      let mut v440_6 = Space::new();
      let mut v440_6_write = v440_6.write_zipper();
      for v440_6_byte in v438_6_cursor.child_mask().iter() {
        v438_6_cursor.descend_to_existing_byte(v440_6_byte);
        {
        let v441_2: Space = Space::new();
        join_wrapped_into(&mut v440_6_write,&((v441_2).read_zipper()),&[]);
        }
        v438_6_cursor.ascend(1);
      }
      drop(v440_6_write);
      compose(&(v439_5),&(v440_6))
    };
    drop(v439_5);
    let v439_8: Space = intersect(&(*CONSTANT_1),&(v439_2));
    drop(v439_2);
    let v439_9: Space = if has_head(&(v439_8)) { singleton(&[]) } else { Space::new() };
    drop(v439_8);
    let v439_11: Space = if (&(v439_9)).is_empty() { Space::new() } else {
      let mut v442_10 = Space::new();
      let mut v442_10_write = v442_10.write_zipper();
      for v442_10_byte in v438_6_cursor.child_mask().iter() {
        v438_6_cursor.descend_to_existing_byte(v442_10_byte);
        {
        let v443_2: Space = singleton(&v438_6_cursor.path()[(v438_6_origin + 1)..(v438_6_origin + 2)]);
        let v443_3: Space = intersect(&(*CONSTANT_1),&(v443_2));
        drop(v443_2);
        let v443_4: Space = if has_head(&(v443_3)) { singleton(&[]) } else { Space::new() };
        drop(v443_3);
        let v443_5: Space = compose(&(v443_4),&v438_6_cursor);
        drop(v443_4);
        join_wrapped_into(&mut v442_10_write,&((v443_5).read_zipper()),&[]);
        }
        v438_6_cursor.ascend(1);
      }
      drop(v442_10_write);
      compose(&(v439_9),&(v442_10))
    };
    drop(v439_9);
    let v439_12: Space = unite(&(v439_7),&(v439_11));
    drop(v439_7);
    drop(v439_11);
    join_wrapped_into(&mut v438_6_write,&((v439_12).read_zipper()),&[]);
    }
    v438_6_cursor.ascend(1);
  }
  drop(v438_6_cursor);
  drop(v438_6_write);
  (v438_6).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v444_5 = Space::new();
  let mut v444_5_write = v444_5.write_zipper();
  let mut v444_5_cursor = (*s0).read_zipper();
  let v444_5_origin = v444_5_cursor.path().len();
  for v444_5_byte in v444_5_cursor.child_mask().iter() {
    v444_5_cursor.descend_to_existing_byte(v444_5_byte);
    {
    let v445_2: Space = singleton(&v444_5_cursor.path()[v444_5_origin..(v444_5_origin + 1)]);
    let v445_3: Space = intersect(&(*CONSTANT_1),&(v445_2));
    let v445_4: Space = if has_head(&(v445_3)) { singleton(&[]) } else { Space::new() };
    drop(v445_3);
    let v445_5: Space = subtract(&(*CONSTANT_0),&(v445_4));
    drop(v445_4);
    let v445_7: Space = if (&(v445_5)).is_empty() { Space::new() } else {
      let mut v446_6 = Space::new();
      let mut v446_6_write = v446_6.write_zipper();
      for v446_6_byte in v444_5_cursor.child_mask().iter() {
        v444_5_cursor.descend_to_existing_byte(v446_6_byte);
        {
        let v447_2: Space = Space::new();
        join_wrapped_into(&mut v446_6_write,&((v447_2).read_zipper()),&[]);
        }
        v444_5_cursor.ascend(1);
      }
      drop(v446_6_write);
      compose(&(v445_5),&(v446_6))
    };
    drop(v445_5);
    let v445_8: Space = intersect(&(*CONSTANT_1),&(v445_2));
    drop(v445_2);
    let v445_9: Space = if has_head(&(v445_8)) { singleton(&[]) } else { Space::new() };
    drop(v445_8);
    let v445_10: Space = compose(&(v445_9),&v444_5_cursor);
    drop(v445_9);
    let v445_11: Space = unite(&(v445_7),&(v445_10));
    drop(v445_7);
    drop(v445_10);
    join_wrapped_into(&mut v444_5_write,&((v445_11).read_zipper()),&[]);
    }
    v444_5_cursor.ascend(1);
  }
  drop(v444_5_cursor);
  drop(v444_5_write);
  (v444_5).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v448_6 = Space::new();
  let mut v448_6_write = v448_6.write_zipper();
  let mut v448_6_cursor = (*s0).read_zipper();
  let v448_6_origin = v448_6_cursor.path().len();
  for v448_6_byte in v448_6_cursor.child_mask().iter() {
    v448_6_cursor.descend_to_existing_byte(v448_6_byte);
    {
    let v449_2: Space = singleton(&v448_6_cursor.path()[v448_6_origin..(v448_6_origin + 1)]);
    let v449_3: Space = intersect(&(*CONSTANT_1),&(v449_2));
    let v449_4: Space = if has_head(&(v449_3)) { singleton(&[]) } else { Space::new() };
    drop(v449_3);
    let v449_5: Space = subtract(&(*CONSTANT_0),&(v449_4));
    drop(v449_4);
    let v449_7: Space = if (&(v449_5)).is_empty() { Space::new() } else {
      let mut v450_6 = Space::new();
      let mut v450_6_write = v450_6.write_zipper();
      for v450_6_byte in v448_6_cursor.child_mask().iter() {
        v448_6_cursor.descend_to_existing_byte(v450_6_byte);
        {
        let v451_2: Space = Space::new();
        join_wrapped_into(&mut v450_6_write,&((v451_2).read_zipper()),&[]);
        }
        v448_6_cursor.ascend(1);
      }
      drop(v450_6_write);
      compose(&(v449_5),&(v450_6))
    };
    drop(v449_5);
    let v449_8: Space = intersect(&(*CONSTANT_1),&(v449_2));
    drop(v449_2);
    let v449_9: Space = if has_head(&(v449_8)) { singleton(&[]) } else { Space::new() };
    drop(v449_8);
    let v449_11: Space = if (&(v449_9)).is_empty() { Space::new() } else {
      let mut v452_10 = Space::new();
      let mut v452_10_write = v452_10.write_zipper();
      for v452_10_byte in v448_6_cursor.child_mask().iter() {
        v448_6_cursor.descend_to_existing_byte(v452_10_byte);
        {
        let v453_2: Space = singleton(&v448_6_cursor.path()[(v448_6_origin + 1)..(v448_6_origin + 2)]);
        let v453_3: Space = intersect(&(*CONSTANT_1),&(v453_2));
        drop(v453_2);
        let v453_4: Space = if has_head(&(v453_3)) { singleton(&[]) } else { Space::new() };
        drop(v453_3);
        let v453_5: Space = compose(&(v453_4),&v448_6_cursor);
        drop(v453_4);
        join_wrapped_into(&mut v452_10_write,&((v453_5).read_zipper()),&[]);
        }
        v448_6_cursor.ascend(1);
      }
      drop(v452_10_write);
      compose(&(v449_9),&(v452_10))
    };
    drop(v449_9);
    let v449_12: Space = unite(&(v449_7),&(v449_11));
    drop(v449_7);
    drop(v449_11);
    join_wrapped_into(&mut v448_6_write,&((v449_12).read_zipper()),&[]);
    }
    v448_6_cursor.ascend(1);
  }
  drop(v448_6_cursor);
  drop(v448_6_write);
  (v448_6).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v454_5 = Space::new();
  let mut v454_5_write = v454_5.write_zipper();
  let mut v454_5_cursor = (*s0).read_zipper();
  let v454_5_origin = v454_5_cursor.path().len();
  for v454_5_byte in v454_5_cursor.child_mask().iter() {
    v454_5_cursor.descend_to_existing_byte(v454_5_byte);
    {
    let v455_2: Space = singleton(&v454_5_cursor.path()[v454_5_origin..(v454_5_origin + 1)]);
    let v455_3: Space = intersect(&(*CONSTANT_1),&(v455_2));
    let v455_4: Space = if has_head(&(v455_3)) { singleton(&[]) } else { Space::new() };
    drop(v455_3);
    let v455_5: Space = subtract(&(*CONSTANT_0),&(v455_4));
    drop(v455_4);
    let v455_7: Space = if (&(v455_5)).is_empty() { Space::new() } else {
      let mut v456_6 = Space::new();
      let mut v456_6_write = v456_6.write_zipper();
      for v456_6_byte in v454_5_cursor.child_mask().iter() {
        v454_5_cursor.descend_to_existing_byte(v456_6_byte);
        {
        let v457_2: Space = Space::new();
        join_wrapped_into(&mut v456_6_write,&((v457_2).read_zipper()),&[]);
        }
        v454_5_cursor.ascend(1);
      }
      drop(v456_6_write);
      compose(&(v455_5),&(v456_6))
    };
    drop(v455_5);
    let v455_8: Space = intersect(&(*CONSTANT_1),&(v455_2));
    drop(v455_2);
    let v455_9: Space = if has_head(&(v455_8)) { singleton(&[]) } else { Space::new() };
    drop(v455_8);
    let v455_10: Space = compose(&(v455_9),&v454_5_cursor);
    drop(v455_9);
    let v455_11: Space = unite(&(v455_7),&(v455_10));
    drop(v455_7);
    drop(v455_10);
    join_wrapped_into(&mut v454_5_write,&((v455_11).read_zipper()),&[]);
    }
    v454_5_cursor.ascend(1);
  }
  drop(v454_5_cursor);
  drop(v454_5_write);
  (v454_5).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v458_2 = Space::new();
  let mut v458_2_write = v458_2.write_zipper();
  let mut v458_2_cursor = (*s0).read_zipper();
  let v458_2_origin = v458_2_cursor.path().len();
  for v458_2_byte in v458_2_cursor.child_mask().iter() {
    v458_2_cursor.descend_to_existing_byte(v458_2_byte);
    {
    let v459_2: Space = Space::new();
    join_wrapped_into(&mut v458_2_write,&((v459_2).read_zipper()),&[]);
    }
    v458_2_cursor.ascend(1);
  }
  drop(v458_2_cursor);
  drop(v458_2_write);
  (v458_2).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v460_3 = Space::new();
  let mut v460_3_write = v460_3.write_zipper();
  let mut v460_3_cursor = (*s0).read_zipper();
  let v460_3_origin = v460_3_cursor.path().len();
  for v460_3_byte in v460_3_cursor.child_mask().iter() {
    v460_3_cursor.descend_to_existing_byte(v460_3_byte);
    {
    let v461_2: Space = singleton(&v460_3_cursor.path()[v460_3_origin..(v460_3_origin + 1)]);
    let v461_3: Space = intersect(&(*CONSTANT_1),&(v461_2));
    drop(v461_2);
    let v461_4: Space = if has_head(&(v461_3)) { singleton(&[]) } else { Space::new() };
    drop(v461_3);
    let v461_5: Space = compose(&(v461_4),&v460_3_cursor);
    drop(v461_4);
    join_wrapped_into(&mut v460_3_write,&((v461_5).read_zipper()),&[]);
    }
    v460_3_cursor.ascend(1);
  }
  drop(v460_3_cursor);
  drop(v460_3_write);
  (v460_3).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v462_2 = Space::new();
  let mut v462_2_write = v462_2.write_zipper();
  let mut v462_2_cursor = (*s0).read_zipper();
  let v462_2_origin = v462_2_cursor.path().len();
  for v462_2_byte in v462_2_cursor.child_mask().iter() {
    v462_2_cursor.descend_to_existing_byte(v462_2_byte);
    {
    let v463_2: Space = Space::new();
    join_wrapped_into(&mut v462_2_write,&((v463_2).read_zipper()),&[]);
    }
    v462_2_cursor.ascend(1);
  }
  drop(v462_2_cursor);
  drop(v462_2_write);
  (v462_2).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v464_3 = Space::new();
  let mut v464_3_write = v464_3.write_zipper();
  let mut v464_3_cursor = (*s0).read_zipper();
  let v464_3_origin = v464_3_cursor.path().len();
  for v464_3_byte in v464_3_cursor.child_mask().iter() {
    v464_3_cursor.descend_to_existing_byte(v464_3_byte);
    {
    let v465_2: Space = singleton(&v464_3_cursor.path()[v464_3_origin..(v464_3_origin + 1)]);
    let v465_3: Space = intersect(&(*CONSTANT_1),&(v465_2));
    drop(v465_2);
    let v465_4: Space = if has_head(&(v465_3)) { singleton(&[]) } else { Space::new() };
    drop(v465_3);
    let v465_5: Space = compose(&(v465_4),&v464_3_cursor);
    drop(v465_4);
    join_wrapped_into(&mut v464_3_write,&((v465_5).read_zipper()),&[]);
    }
    v464_3_cursor.ascend(1);
  }
  drop(v464_3_cursor);
  drop(v464_3_write);
  (v464_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
