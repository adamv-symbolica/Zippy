#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,1,0,0,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("36 15 0 0 0 0 0 1 1 0 0 1 0 0 0 1 1 14 0 0 0 0 0 1 1 1 0 0 1 0 1 1 13 0 0 0 0 1 1 0 0 0 0 0 1 1 13 0 0 0 0 1 1 1 0 0 0 0 1 1 15 0 0 0 1 0 1 1 0 0 1 0 0 0 1 1 15 0 0 0 1 0 1 1 0 1 0 0 0 0 1 1 11 0 0 0 1 1 0 0 1 0 1 1 11 0 0 0 1 1 0 1 0 0 1 1 15 0 0 1 0 0 1 1 0 0 0 0 0 0 1 1 15 0 0 1 0 0 1 1 1 0 0 0 0 0 1 1 13 0 0 1 0 1 1 0 0 1 0 0 1 1 13 0 0 1 0 1 1 1 0 1 0 0 1 1 10 0 0 1 1 0 0 0 0 1 1 10 0 0 1 1 1 0 0 0 1 1 15 0 1 0 0 0 1 1 0 0 0 0 0 0 1 1 14 0 1 0 0 0 1 1 0 1 0 1 0 1 1 13 0 1 0 0 1 1 0 0 1 0 0 1 1 13 0 1 0 0 1 1 0 1 0 0 0 1 1 12 0 1 0 1 1 0 0 0 0 0 1 1 12 0 1 0 1 1 0 0 0 1 0 1 1 9 0 1 1 0 0 0 0 1 1 8 0 1 1 0 1 0 1 1 14 1 0 0 0 0 1 1 0 1 0 1 0 1 1 14 1 0 0 0 0 1 1 1 0 0 1 0 1 1 13 1 0 0 0 1 1 0 1 0 0 0 1 1 13 1 0 0 0 1 1 1 0 0 0 0 1 1 11 1 0 0 1 1 0 0 1 0 1 1 11 1 0 0 1 1 1 0 1 0 1 1 15 1 0 1 0 0 1 1 0 1 0 0 0 0 1 1 15 1 0 1 0 0 1 1 1 0 0 0 0 0 1 1 13 1 0 1 0 1 1 0 0 0 1 0 1 1 13 1 0 1 0 1 1 1 0 1 0 0 1 1 10 1 0 1 1 0 1 0 0 1 1 10 1 0 1 1 1 0 0 0 1 1 7 1 1 0 1 0 1 1 8 1 1 1 0 1 0 1 1"));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("36 15 0 0 0 0 0 0 1 1 0 0 1 0 0 1 1 15 0 0 0 0 0 0 1 1 0 1 0 0 0 1 1 13 0 0 0 0 0 1 1 0 0 0 0 1 1 12 0 0 0 0 0 1 1 0 1 0 1 1 10 0 0 0 0 1 1 0 0 1 1 9 0 0 0 0 1 1 0 1 1 12 0 0 0 1 0 1 1 0 1 0 1 1 13 0 0 0 1 0 1 1 1 0 1 0 1 1 15 0 0 1 0 0 0 1 1 0 0 0 0 0 1 1 15 0 0 1 0 0 0 1 1 0 0 0 1 0 1 1 13 0 0 1 0 0 1 1 0 0 1 0 1 1 13 0 0 1 0 0 1 1 0 1 0 0 1 1 11 0 0 1 0 1 1 0 0 0 1 1 11 0 0 1 0 1 1 1 0 0 1 1 15 0 1 0 0 0 0 1 1 0 0 0 1 0 1 1 15 0 1 0 0 0 0 1 1 1 0 1 0 0 1 1 13 0 1 0 0 0 1 1 0 1 0 0 1 1 13 0 1 0 0 0 1 1 1 0 0 0 1 1 11 0 1 0 0 1 1 0 0 0 1 1 10 0 1 0 0 1 1 1 0 1 1 14 0 1 0 1 0 1 1 0 1 0 0 0 1 1 14 0 1 0 1 0 1 1 1 0 0 0 0 1 1 8 0 1 0 1 1 0 1 1 7 0 1 0 1 1 1 1 15 1 0 0 0 0 0 1 1 0 0 1 0 0 1 1 15 1 0 0 0 0 0 1 1 1 0 1 0 0 1 1 13 1 0 0 0 0 1 1 0 0 0 0 1 1 13 1 0 0 0 0 1 1 1 0 0 0 1 1 10 1 0 0 0 1 1 0 0 1 1 10 1 0 0 0 1 1 1 0 1 1 14 1 0 0 1 0 1 1 0 0 0 0 0 1 1 14 1 0 0 1 0 1 1 1 0 0 0 0 1 1 13 1 0 1 0 0 1 1 0 0 1 0 1 1 13 1 0 1 0 0 1 1 1 0 1 0 1 1 11 1 0 1 0 1 1 1 0 0 1 1 8 1 0 1 0 1 1 1 1"));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("12 8 0 0 0 0 0 0 1 1 7 0 0 0 0 0 1 1 5 0 0 0 1 1 6 0 0 1 0 1 1 4 0 0 1 1 8 0 1 0 0 0 0 1 1 7 0 1 0 0 0 1 1 5 0 1 0 1 1 6 1 0 0 0 1 1 7 1 0 0 1 0 1 1 7 1 0 1 0 0 1 1 2 1 1"));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_10 = Space::new();
  let mut v0_10_write = v0_10.write_zipper();
  let mut v0_10_cursor = (*s0.expect("unbound native input")).read_zipper();
  let v0_10_origin = v0_10_cursor.path().len();
  for v0_10_byte in v0_10_cursor.child_mask().iter() {
    v0_10_cursor.descend_to_existing_byte(v0_10_byte);
    {
    let v1_2: Space = singleton(&v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 1)]);
    let v1_3: Space = intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (&(v1_5)).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_write = v2_6.write_zipper();
      for v2_6_byte in v0_10_cursor.child_mask().iter() {
        v0_10_cursor.descend_to_existing_byte(v2_6_byte);
        {
        let v3_2: Space = singleton(&v0_10_cursor.path()[(v0_10_origin + 1)..(v0_10_origin + 2)]);
        let v3_3: Space = intersect(&(*CONSTANT_1),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_0),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (&(v3_5)).is_empty() { Space::new() } else {
          let v4_7: Space = routine_1(c, &v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 2)], &v0_10_cursor);
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_1),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (&(v3_10)).is_empty() { Space::new() } else {
          let v5_11: Space = routine_2(c, &v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 2)], &v0_10_cursor);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        join_wrapped_into(&mut v2_6_write,&((v3_13).read_zipper()),&[]);
        }
        v0_10_cursor.ascend(1);
      }
      drop(v2_6_write);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (&(v1_9)).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_write = v6_10.write_zipper();
      for v6_10_byte in v0_10_cursor.child_mask().iter() {
        v0_10_cursor.descend_to_existing_byte(v6_10_byte);
        {
        let v7_2: Space = singleton(&v0_10_cursor.path()[(v0_10_origin + 1)..(v0_10_origin + 2)]);
        let v7_3: Space = intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (&(v7_5)).is_empty() { Space::new() } else {
          let v8_7: Space = routine_1(c, &v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 2)], &v0_10_cursor);
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (&(v7_10)).is_empty() { Space::new() } else {
          let v9_11: Space = routine_3(c, &v0_10_cursor.path()[v0_10_origin..(v0_10_origin + 2)], &v0_10_cursor);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        join_wrapped_into(&mut v6_10_write,&((v7_13).read_zipper()),&[]);
        }
        v0_10_cursor.ascend(1);
      }
      drop(v6_10_write);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    join_wrapped_into(&mut v0_10_write,&((v1_12).read_zipper()),&[]);
    }
    v0_10_cursor.ascend(1);
  }
  drop(v0_10_cursor);
  drop(v0_10_write);
  let v0_12: Space = wrap(&(v0_10),&(*CONSTANT_2));
  (v0_12).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v10_33 = Space::new();
  let mut v10_33_write = v10_33.write_zipper();
  let mut v10_33_cursor = (*s0).read_zipper();
  let v10_33_origin = v10_33_cursor.path().len();
  for v10_33_byte in v10_33_cursor.child_mask().iter() {
    v10_33_cursor.descend_to_existing_byte(v10_33_byte);
    {
    let v11_2: Space = singleton(&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]);
    let v11_3: Space = intersect(&(*CONSTANT_1),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (&(v11_5)).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]);
      let mut v12_7 = Space::new();
      let mut v12_7_write = v12_7.write_zipper();
      for v12_7_byte in v10_33_cursor.child_mask().iter() {
        v10_33_cursor.descend_to_existing_byte(v12_7_byte);
        {
        let v13_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
        let v13_3: Space = intersect(&(*CONSTANT_1),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_0),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (&(v13_5)).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v12_6),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
          let mut v14_7 = Space::new();
          let mut v14_7_write = v14_7.write_zipper();
          for v14_7_byte in v10_33_cursor.child_mask().iter() {
            v10_33_cursor.descend_to_existing_byte(v14_7_byte);
            {
            let v15_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
            let v15_3: Space = intersect(&(*CONSTANT_1),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (&(v15_5)).is_empty() { Space::new() } else {
              let v16_6: Path = concat_path(&(v14_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v16_7: Space = routine_4(c, &(v16_6), &v10_33_cursor);
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_1),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (&(v15_10)).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v14_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v17_11: Space = routine_5(c, &(v17_6), &v10_33_cursor);
              drop(v17_6);
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            join_wrapped_into(&mut v14_7_write,&((v15_13).read_zipper()),&[]);
            }
            v10_33_cursor.ascend(1);
          }
          drop(v14_7_write);
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_1),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (&(v13_10)).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v12_6),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
          let mut v18_11 = Space::new();
          let mut v18_11_write = v18_11.write_zipper();
          for v18_11_byte in v10_33_cursor.child_mask().iter() {
            v10_33_cursor.descend_to_existing_byte(v18_11_byte);
            {
            let v19_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
            let v19_3: Space = intersect(&(*CONSTANT_1),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
            drop(v19_4);
            let v19_8: Space = if (&(v19_5)).is_empty() { Space::new() } else {
              let v20_6: Path = concat_path(&(v18_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v20_7: Space = routine_4(c, &(v20_6), &v10_33_cursor);
              compose(&(v19_5),&(v20_7))
            };
            drop(v19_5);
            let v19_9: Space = intersect(&(*CONSTANT_1),&(v19_2));
            drop(v19_2);
            let v19_10: Space = if has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
            drop(v19_9);
            let v19_12: Space = if (&(v19_10)).is_empty() { Space::new() } else {
              let v21_6: Path = concat_path(&(v18_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v21_11: Space = routine_3(c, &(v21_6), &v10_33_cursor);
              drop(v21_6);
              compose(&(v19_10),&(v21_11))
            };
            drop(v19_10);
            let v19_13: Space = unite(&(v19_8),&(v19_12));
            join_wrapped_into(&mut v18_11_write,&((v19_13).read_zipper()),&[]);
            }
            v10_33_cursor.ascend(1);
          }
          drop(v18_11_write);
          drop(v18_6);
          compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        join_wrapped_into(&mut v12_7_write,&((v13_13).read_zipper()),&[]);
        }
        v10_33_cursor.ascend(1);
      }
      drop(v12_7_write);
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_1),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_14: Space = if (&(v11_10)).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]);
      let mut v22_13 = Space::new();
      let mut v22_13_write = v22_13.write_zipper();
      for v22_13_byte in v10_33_cursor.child_mask().iter() {
        v10_33_cursor.descend_to_existing_byte(v22_13_byte);
        {
        let v23_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
        let v23_3: Space = intersect(&(*CONSTANT_1),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_0),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (&(v23_5)).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v22_6),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
          let mut v24_7 = Space::new();
          let mut v24_7_write = v24_7.write_zipper();
          for v24_7_byte in v10_33_cursor.child_mask().iter() {
            v10_33_cursor.descend_to_existing_byte(v24_7_byte);
            {
            let v25_2: Space = singleton(&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
            let v25_3: Space = intersect(&(*CONSTANT_1),&(v25_2));
            let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
            drop(v25_3);
            let v25_5: Space = subtract(&(*CONSTANT_0),&(v25_4));
            drop(v25_4);
            let v25_8: Space = if (&(v25_5)).is_empty() { Space::new() } else {
              let v26_6: Path = concat_path(&(v24_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v26_7: Space = routine_4(c, &(v26_6), &v10_33_cursor);
              compose(&(v25_5),&(v26_7))
            };
            drop(v25_5);
            let v25_9: Space = intersect(&(*CONSTANT_1),&(v25_2));
            drop(v25_2);
            let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
            drop(v25_9);
            let v25_12: Space = if (&(v25_10)).is_empty() { Space::new() } else {
              let v27_6: Path = concat_path(&(v24_6),&v10_33_cursor.path()[(v10_33_origin + 2)..(v10_33_origin + 3)]);
              let v27_11: Space = routine_5(c, &(v27_6), &v10_33_cursor);
              drop(v27_6);
              compose(&(v25_10),&(v27_11))
            };
            drop(v25_10);
            let v25_13: Space = unite(&(v25_8),&(v25_12));
            join_wrapped_into(&mut v24_7_write,&((v25_13).read_zipper()),&[]);
            }
            v10_33_cursor.ascend(1);
          }
          drop(v24_7_write);
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_1),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_19: Space = if (&(v23_10)).is_empty() { Space::new() } else {
          let v28_12: Space = restrict_to(&(*CONSTANT_4),&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)])));
          let mut v28_13 = Space::new();
          let mut v28_13_write = v28_13.write_zipper();
          let mut v28_13_cursor = (v28_12).read_zipper();
          let v28_13_origin = v28_13_cursor.path().len();
          for v28_13_byte in v28_13_cursor.child_mask().iter() {
            v28_13_cursor.descend_to_existing_byte(v28_13_byte);
            {
            let v29_2: Space = singleton(&v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)]);
            let v29_3: Space = intersect(&(*CONSTANT_1),&(v29_2));
            let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
            drop(v29_3);
            let v29_5: Space = subtract(&(*CONSTANT_0),&(v29_4));
            drop(v29_4);
            let v29_7: Space = if (&(v29_5)).is_empty() { Space::new() } else {
              let v30_6: Space = routine_6(c, &v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)], &v28_13_cursor);
              compose(&(v29_5),&(v30_6))
            };
            drop(v29_5);
            let v29_8: Space = intersect(&(*CONSTANT_1),&(v29_2));
            drop(v29_2);
            let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
            drop(v29_8);
            let v29_11: Space = if (&(v29_9)).is_empty() { Space::new() } else {
              let v31_10: Space = routine_7(c, &v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)], &v28_13_cursor);
              compose(&(v29_9),&(v31_10))
            };
            drop(v29_9);
            let v29_12: Space = unite(&(v29_7),&(v29_11));
            join_wrapped_into(&mut v28_13_write,&((v29_12).read_zipper()),&[]);
            }
            v28_13_cursor.ascend(1);
          }
          drop(v28_13_cursor);
          drop(v28_13_write);
          drop(v28_12);
          let v28_14: Space = restrict_to(&(*CONSTANT_3),&(v28_13));
          let mut v28_15 = Space::new();
          let mut v28_15_write = v28_15.write_zipper();
          let mut v28_15_cursor = (v28_14).read_zipper();
          let v28_15_origin = v28_15_cursor.path().len();
          for v28_15_byte in v28_15_cursor.child_mask().iter() {
            v28_15_cursor.descend_to_existing_byte(v28_15_byte);
            {
            let v32_2: Space = singleton(&v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)]);
            let v32_3: Space = intersect(&(*CONSTANT_1),&(v32_2));
            let v32_4: Space = if has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
            drop(v32_3);
            let v32_5: Space = subtract(&(*CONSTANT_0),&(v32_4));
            drop(v32_4);
            let v32_7: Space = if (&(v32_5)).is_empty() { Space::new() } else {
              let v33_6: Space = routine_8(c, &v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)], &v28_15_cursor);
              compose(&(v32_5),&(v33_6))
            };
            drop(v32_5);
            let v32_8: Space = intersect(&(*CONSTANT_1),&(v32_2));
            drop(v32_2);
            let v32_9: Space = if has_head(&(v32_8)) { singleton(&[]) } else { Space::new() };
            drop(v32_8);
            let v32_11: Space = if (&(v32_9)).is_empty() { Space::new() } else {
              let v34_10: Space = routine_9(c, &v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)], &v28_15_cursor);
              compose(&(v32_9),&(v34_10))
            };
            drop(v32_9);
            let v32_12: Space = unite(&(v32_7),&(v32_11));
            join_wrapped_into(&mut v28_15_write,&((v32_12).read_zipper()),&[]);
            }
            v28_15_cursor.ascend(1);
          }
          drop(v28_15_cursor);
          drop(v28_15_write);
          let v28_17: Space = subtract(&(v28_15),&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v10_33_cursor.path()[v10_33_origin..(v10_33_origin + 1)]),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)])));
          let v28_18: Space = intersect(&(v28_17),&(*CONSTANT_5));
          compose(&(v23_10),&(v28_18))
        };
        drop(v23_10);
        let v35_6: Path = concat_path(&(v22_6),&v10_33_cursor.path()[(v10_33_origin + 1)..(v10_33_origin + 2)]);
        let v23_20: Space = wrap(&(v23_19),&(v35_6));
        let v23_21: Space = unite(&(v23_8),&(v23_20));
        join_wrapped_into(&mut v22_13_write,&((v23_21).read_zipper()),&[]);
        }
        v10_33_cursor.ascend(1);
      }
      drop(v22_13_write);
      drop(v22_6);
      compose(&(v11_10),&(v22_13))
    };
    drop(v11_10);
    let v11_15: Space = unite(&(v11_8),&(v11_14));
    join_wrapped_into(&mut v10_33_write,&((v11_15).read_zipper()),&[]);
    }
    v10_33_cursor.ascend(1);
  }
  drop(v10_33_cursor);
  drop(v10_33_write);
  (v10_33).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v36_39 = Space::new();
  let mut v36_39_write = v36_39.write_zipper();
  let mut v36_39_cursor = (*s0).read_zipper();
  let v36_39_origin = v36_39_cursor.path().len();
  for v36_39_byte in v36_39_cursor.child_mask().iter() {
    v36_39_cursor.descend_to_existing_byte(v36_39_byte);
    {
    let v37_2: Space = singleton(&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)]);
    let v37_3: Space = intersect(&(*CONSTANT_1),&(v37_2));
    let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
    drop(v37_3);
    let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
    drop(v37_4);
    let v37_8: Space = if (&(v37_5)).is_empty() { Space::new() } else {
      let v38_6: Path = concat_path(&(*p0),&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)]);
      let mut v38_7 = Space::new();
      let mut v38_7_write = v38_7.write_zipper();
      for v38_7_byte in v36_39_cursor.child_mask().iter() {
        v36_39_cursor.descend_to_existing_byte(v38_7_byte);
        {
        let v39_2: Space = singleton(&v36_39_cursor.path()[(v36_39_origin + 1)..(v36_39_origin + 2)]);
        let v39_3: Space = intersect(&(*CONSTANT_1),&(v39_2));
        let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_8: Space = if (&(v39_5)).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v38_6),&v36_39_cursor.path()[(v36_39_origin + 1)..(v36_39_origin + 2)]);
          let mut v40_7 = Space::new();
          let mut v40_7_write = v40_7.write_zipper();
          for v40_7_byte in v36_39_cursor.child_mask().iter() {
            v36_39_cursor.descend_to_existing_byte(v40_7_byte);
            {
            let v41_2: Space = singleton(&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
            let v41_3: Space = intersect(&(*CONSTANT_1),&(v41_2));
            let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
            drop(v41_4);
            let v41_8: Space = if (&(v41_5)).is_empty() { Space::new() } else {
              let v42_6: Path = concat_path(&(v40_6),&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
              let v42_7: Space = routine_4(c, &(v42_6), &v36_39_cursor);
              compose(&(v41_5),&(v42_7))
            };
            drop(v41_5);
            let v41_9: Space = intersect(&(*CONSTANT_1),&(v41_2));
            drop(v41_2);
            let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
            drop(v41_9);
            let v41_12: Space = if (&(v41_10)).is_empty() { Space::new() } else {
              let v43_6: Path = concat_path(&(v40_6),&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
              let v43_11: Space = routine_5(c, &(v43_6), &v36_39_cursor);
              drop(v43_6);
              compose(&(v41_10),&(v43_11))
            };
            drop(v41_10);
            let v41_13: Space = unite(&(v41_8),&(v41_12));
            join_wrapped_into(&mut v40_7_write,&((v41_13).read_zipper()),&[]);
            }
            v36_39_cursor.ascend(1);
          }
          drop(v40_7_write);
          compose(&(v39_5),&(v40_7))
        };
        drop(v39_5);
        let v39_9: Space = intersect(&(*CONSTANT_1),&(v39_2));
        drop(v39_2);
        let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
        drop(v39_9);
        let v39_12: Space = if (&(v39_10)).is_empty() { Space::new() } else {
          let v44_6: Path = concat_path(&(v38_6),&v36_39_cursor.path()[(v36_39_origin + 1)..(v36_39_origin + 2)]);
          let mut v44_11 = Space::new();
          let mut v44_11_write = v44_11.write_zipper();
          for v44_11_byte in v36_39_cursor.child_mask().iter() {
            v36_39_cursor.descend_to_existing_byte(v44_11_byte);
            {
            let v45_2: Space = singleton(&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
            let v45_3: Space = intersect(&(*CONSTANT_1),&(v45_2));
            let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
            drop(v45_3);
            let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
            drop(v45_4);
            let v45_8: Space = if (&(v45_5)).is_empty() { Space::new() } else {
              let v46_6: Path = concat_path(&(v44_6),&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
              let v46_7: Space = routine_4(c, &(v46_6), &v36_39_cursor);
              compose(&(v45_5),&(v46_7))
            };
            drop(v45_5);
            let v45_9: Space = intersect(&(*CONSTANT_1),&(v45_2));
            drop(v45_2);
            let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
            drop(v45_9);
            let v45_12: Space = if (&(v45_10)).is_empty() { Space::new() } else {
              let v47_6: Path = concat_path(&(v44_6),&v36_39_cursor.path()[(v36_39_origin + 2)..(v36_39_origin + 3)]);
              let v47_11: Space = routine_3(c, &(v47_6), &v36_39_cursor);
              drop(v47_6);
              compose(&(v45_10),&(v47_11))
            };
            drop(v45_10);
            let v45_13: Space = unite(&(v45_8),&(v45_12));
            join_wrapped_into(&mut v44_11_write,&((v45_13).read_zipper()),&[]);
            }
            v36_39_cursor.ascend(1);
          }
          drop(v44_11_write);
          drop(v44_6);
          compose(&(v39_10),&(v44_11))
        };
        drop(v39_10);
        let v39_13: Space = unite(&(v39_8),&(v39_12));
        join_wrapped_into(&mut v38_7_write,&((v39_13).read_zipper()),&[]);
        }
        v36_39_cursor.ascend(1);
      }
      drop(v38_7_write);
      compose(&(v37_5),&(v38_7))
    };
    drop(v37_5);
    let v37_9: Space = intersect(&(*CONSTANT_1),&(v37_2));
    drop(v37_2);
    let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
    drop(v37_9);
    let v37_19: Space = if (&(v37_10)).is_empty() { Space::new() } else {
      let v48_12: Space = restrict_to(&(*CONSTANT_4),&(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)])));
      let mut v48_13 = Space::new();
      let mut v48_13_write = v48_13.write_zipper();
      let mut v48_13_cursor = (v48_12).read_zipper();
      let v48_13_origin = v48_13_cursor.path().len();
      for v48_13_byte in v48_13_cursor.child_mask().iter() {
        v48_13_cursor.descend_to_existing_byte(v48_13_byte);
        {
        let v49_2: Space = singleton(&v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 1)]);
        let v49_3: Space = intersect(&(*CONSTANT_1),&(v49_2));
        let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
        drop(v49_3);
        let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
        drop(v49_4);
        let v49_7: Space = if (&(v49_5)).is_empty() { Space::new() } else {
          let mut v50_6 = Space::new();
          let mut v50_6_write = v50_6.write_zipper();
          for v50_6_byte in v48_13_cursor.child_mask().iter() {
            v48_13_cursor.descend_to_existing_byte(v50_6_byte);
            {
            let v51_2: Space = singleton(&v48_13_cursor.path()[(v48_13_origin + 1)..(v48_13_origin + 2)]);
            let v51_3: Space = intersect(&(*CONSTANT_1),&(v51_2));
            let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
            drop(v51_3);
            let v51_5: Space = subtract(&(*CONSTANT_0),&(v51_4));
            drop(v51_4);
            let v51_8: Space = if (&(v51_5)).is_empty() { Space::new() } else {
              let v52_7: Space = routine_10(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v51_5),&(v52_7))
            };
            drop(v51_5);
            let v51_9: Space = intersect(&(*CONSTANT_1),&(v51_2));
            drop(v51_2);
            let v51_10: Space = if has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
            drop(v51_9);
            let v51_12: Space = if (&(v51_10)).is_empty() { Space::new() } else {
              let v53_11: Space = routine_11(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v51_10),&(v53_11))
            };
            drop(v51_10);
            let v51_13: Space = unite(&(v51_8),&(v51_12));
            join_wrapped_into(&mut v50_6_write,&((v51_13).read_zipper()),&[]);
            }
            v48_13_cursor.ascend(1);
          }
          drop(v50_6_write);
          compose(&(v49_5),&(v50_6))
        };
        drop(v49_5);
        let v49_8: Space = intersect(&(*CONSTANT_1),&(v49_2));
        drop(v49_2);
        let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
        drop(v49_8);
        let v49_11: Space = if (&(v49_9)).is_empty() { Space::new() } else {
          let mut v54_10 = Space::new();
          let mut v54_10_write = v54_10.write_zipper();
          for v54_10_byte in v48_13_cursor.child_mask().iter() {
            v48_13_cursor.descend_to_existing_byte(v54_10_byte);
            {
            let v55_2: Space = singleton(&v48_13_cursor.path()[(v48_13_origin + 1)..(v48_13_origin + 2)]);
            let v55_3: Space = intersect(&(*CONSTANT_1),&(v55_2));
            let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
            drop(v55_3);
            let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
            drop(v55_4);
            let v55_8: Space = if (&(v55_5)).is_empty() { Space::new() } else {
              let v56_7: Space = routine_10(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v55_5),&(v56_7))
            };
            drop(v55_5);
            let v55_9: Space = intersect(&(*CONSTANT_1),&(v55_2));
            drop(v55_2);
            let v55_10: Space = if has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
            drop(v55_9);
            let v55_12: Space = if (&(v55_10)).is_empty() { Space::new() } else {
              let v57_11: Space = routine_12(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              compose(&(v55_10),&(v57_11))
            };
            drop(v55_10);
            let v55_13: Space = unite(&(v55_8),&(v55_12));
            join_wrapped_into(&mut v54_10_write,&((v55_13).read_zipper()),&[]);
            }
            v48_13_cursor.ascend(1);
          }
          drop(v54_10_write);
          compose(&(v49_9),&(v54_10))
        };
        drop(v49_9);
        let v49_12: Space = unite(&(v49_7),&(v49_11));
        join_wrapped_into(&mut v48_13_write,&((v49_12).read_zipper()),&[]);
        }
        v48_13_cursor.ascend(1);
      }
      drop(v48_13_cursor);
      drop(v48_13_write);
      drop(v48_12);
      let v48_14: Space = restrict_to(&(*CONSTANT_3),&(v48_13));
      let mut v48_15 = Space::new();
      let mut v48_15_write = v48_15.write_zipper();
      let mut v48_15_cursor = (v48_14).read_zipper();
      let v48_15_origin = v48_15_cursor.path().len();
      for v48_15_byte in v48_15_cursor.child_mask().iter() {
        v48_15_cursor.descend_to_existing_byte(v48_15_byte);
        {
        let v58_2: Space = singleton(&v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 1)]);
        let v58_3: Space = intersect(&(*CONSTANT_1),&(v58_2));
        let v58_4: Space = if has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
        drop(v58_3);
        let v58_5: Space = subtract(&(*CONSTANT_0),&(v58_4));
        drop(v58_4);
        let v58_7: Space = if (&(v58_5)).is_empty() { Space::new() } else {
          let mut v59_6 = Space::new();
          let mut v59_6_write = v59_6.write_zipper();
          for v59_6_byte in v48_15_cursor.child_mask().iter() {
            v48_15_cursor.descend_to_existing_byte(v59_6_byte);
            {
            let v60_2: Space = singleton(&v48_15_cursor.path()[(v48_15_origin + 1)..(v48_15_origin + 2)]);
            let v60_3: Space = intersect(&(*CONSTANT_1),&(v60_2));
            let v60_4: Space = if has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
            drop(v60_3);
            let v60_5: Space = subtract(&(*CONSTANT_0),&(v60_4));
            drop(v60_4);
            let v60_8: Space = if (&(v60_5)).is_empty() { Space::new() } else {
              let v61_7: Space = routine_13(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v60_5),&(v61_7))
            };
            drop(v60_5);
            let v60_9: Space = intersect(&(*CONSTANT_1),&(v60_2));
            drop(v60_2);
            let v60_10: Space = if has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
            drop(v60_9);
            let v60_12: Space = if (&(v60_10)).is_empty() { Space::new() } else {
              let v62_11: Space = routine_14(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v60_10),&(v62_11))
            };
            drop(v60_10);
            let v60_13: Space = unite(&(v60_8),&(v60_12));
            join_wrapped_into(&mut v59_6_write,&((v60_13).read_zipper()),&[]);
            }
            v48_15_cursor.ascend(1);
          }
          drop(v59_6_write);
          compose(&(v58_5),&(v59_6))
        };
        drop(v58_5);
        let v58_8: Space = intersect(&(*CONSTANT_1),&(v58_2));
        drop(v58_2);
        let v58_9: Space = if has_head(&(v58_8)) { singleton(&[]) } else { Space::new() };
        drop(v58_8);
        let v58_11: Space = if (&(v58_9)).is_empty() { Space::new() } else {
          let mut v63_10 = Space::new();
          let mut v63_10_write = v63_10.write_zipper();
          for v63_10_byte in v48_15_cursor.child_mask().iter() {
            v48_15_cursor.descend_to_existing_byte(v63_10_byte);
            {
            let v64_2: Space = singleton(&v48_15_cursor.path()[(v48_15_origin + 1)..(v48_15_origin + 2)]);
            let v64_3: Space = intersect(&(*CONSTANT_1),&(v64_2));
            let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
            drop(v64_3);
            let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
            drop(v64_4);
            let v64_8: Space = if (&(v64_5)).is_empty() { Space::new() } else {
              let v65_7: Space = routine_13(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v64_5),&(v65_7))
            };
            drop(v64_5);
            let v64_9: Space = intersect(&(*CONSTANT_1),&(v64_2));
            drop(v64_2);
            let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
            drop(v64_9);
            let v64_12: Space = if (&(v64_10)).is_empty() { Space::new() } else {
              let v66_11: Space = routine_15(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              compose(&(v64_10),&(v66_11))
            };
            drop(v64_10);
            let v64_13: Space = unite(&(v64_8),&(v64_12));
            join_wrapped_into(&mut v63_10_write,&((v64_13).read_zipper()),&[]);
            }
            v48_15_cursor.ascend(1);
          }
          drop(v63_10_write);
          compose(&(v58_9),&(v63_10))
        };
        drop(v58_9);
        let v58_12: Space = unite(&(v58_7),&(v58_11));
        join_wrapped_into(&mut v48_15_write,&((v58_12).read_zipper()),&[]);
        }
        v48_15_cursor.ascend(1);
      }
      drop(v48_15_cursor);
      drop(v48_15_write);
      let v48_17: Space = subtract(&(v48_15),&(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)])));
      let v48_18: Space = intersect(&(v48_17),&(*CONSTANT_5));
      compose(&(v37_10),&(v48_18))
    };
    drop(v37_10);
    let v67_6: Path = concat_path(&(*p0),&v36_39_cursor.path()[v36_39_origin..(v36_39_origin + 1)]);
    let v37_20: Space = wrap(&(v37_19),&(v67_6));
    let v37_21: Space = unite(&(v37_8),&(v37_20));
    join_wrapped_into(&mut v36_39_write,&((v37_21).read_zipper()),&[]);
    }
    v36_39_cursor.ascend(1);
  }
  drop(v36_39_cursor);
  drop(v36_39_write);
  (v36_39).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v68_6: Space = restrict_to(&(*CONSTANT_4),&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0))));
  let mut v68_25 = Space::new();
  let mut v68_25_write = v68_25.write_zipper();
  let mut v68_25_cursor = (v68_6).read_zipper();
  let v68_25_origin = v68_25_cursor.path().len();
  for v68_25_byte in v68_25_cursor.child_mask().iter() {
    v68_25_cursor.descend_to_existing_byte(v68_25_byte);
    {
    let v69_2: Space = singleton(&v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 1)]);
    let v69_3: Space = intersect(&(*CONSTANT_1),&(v69_2));
    let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
    drop(v69_3);
    let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
    drop(v69_4);
    let v69_7: Space = if (&(v69_5)).is_empty() { Space::new() } else {
      let mut v70_6 = Space::new();
      let mut v70_6_write = v70_6.write_zipper();
      for v70_6_byte in v68_25_cursor.child_mask().iter() {
        v68_25_cursor.descend_to_existing_byte(v70_6_byte);
        {
        let v71_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 1)..(v68_25_origin + 2)]);
        let v71_3: Space = intersect(&(*CONSTANT_1),&(v71_2));
        let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
        drop(v71_3);
        let v71_5: Space = subtract(&(*CONSTANT_0),&(v71_4));
        drop(v71_4);
        let v71_8: Space = if (&(v71_5)).is_empty() { Space::new() } else {
          let mut v72_7 = Space::new();
          let mut v72_7_write = v72_7.write_zipper();
          for v72_7_byte in v68_25_cursor.child_mask().iter() {
            v68_25_cursor.descend_to_existing_byte(v72_7_byte);
            {
            let v73_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 2)..(v68_25_origin + 3)]);
            let v73_3: Space = intersect(&(*CONSTANT_1),&(v73_2));
            let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
            drop(v73_3);
            let v73_5: Space = subtract(&(*CONSTANT_0),&(v73_4));
            drop(v73_4);
            let v73_8: Space = if (&(v73_5)).is_empty() { Space::new() } else {
              let v74_7: Space = routine_16(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v73_5),&(v74_7))
            };
            drop(v73_5);
            let v73_9: Space = intersect(&(*CONSTANT_1),&(v73_2));
            drop(v73_2);
            let v73_10: Space = if has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
            drop(v73_9);
            let v73_12: Space = if (&(v73_10)).is_empty() { Space::new() } else {
              let v75_11: Space = routine_17(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v73_10),&(v75_11))
            };
            drop(v73_10);
            let v73_13: Space = unite(&(v73_8),&(v73_12));
            join_wrapped_into(&mut v72_7_write,&((v73_13).read_zipper()),&[]);
            }
            v68_25_cursor.ascend(1);
          }
          drop(v72_7_write);
          compose(&(v71_5),&(v72_7))
        };
        drop(v71_5);
        let v71_9: Space = intersect(&(*CONSTANT_1),&(v71_2));
        drop(v71_2);
        let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
        drop(v71_9);
        let v71_12: Space = if (&(v71_10)).is_empty() { Space::new() } else {
          let mut v76_11 = Space::new();
          let mut v76_11_write = v76_11.write_zipper();
          for v76_11_byte in v68_25_cursor.child_mask().iter() {
            v68_25_cursor.descend_to_existing_byte(v76_11_byte);
            {
            let v77_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 2)..(v68_25_origin + 3)]);
            let v77_3: Space = intersect(&(*CONSTANT_1),&(v77_2));
            let v77_4: Space = if has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
            drop(v77_3);
            let v77_5: Space = subtract(&(*CONSTANT_0),&(v77_4));
            drop(v77_4);
            let v77_8: Space = if (&(v77_5)).is_empty() { Space::new() } else {
              let v78_7: Space = routine_16(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v77_5),&(v78_7))
            };
            drop(v77_5);
            let v77_9: Space = intersect(&(*CONSTANT_1),&(v77_2));
            drop(v77_2);
            let v77_10: Space = if has_head(&(v77_9)) { singleton(&[]) } else { Space::new() };
            drop(v77_9);
            let v77_12: Space = if (&(v77_10)).is_empty() { Space::new() } else {
              let v79_11: Space = routine_12(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v77_10),&(v79_11))
            };
            drop(v77_10);
            let v77_13: Space = unite(&(v77_8),&(v77_12));
            join_wrapped_into(&mut v76_11_write,&((v77_13).read_zipper()),&[]);
            }
            v68_25_cursor.ascend(1);
          }
          drop(v76_11_write);
          compose(&(v71_10),&(v76_11))
        };
        drop(v71_10);
        let v71_13: Space = unite(&(v71_8),&(v71_12));
        join_wrapped_into(&mut v70_6_write,&((v71_13).read_zipper()),&[]);
        }
        v68_25_cursor.ascend(1);
      }
      drop(v70_6_write);
      compose(&(v69_5),&(v70_6))
    };
    drop(v69_5);
    let v69_8: Space = intersect(&(*CONSTANT_1),&(v69_2));
    drop(v69_2);
    let v69_9: Space = if has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
    drop(v69_8);
    let v69_11: Space = if (&(v69_9)).is_empty() { Space::new() } else {
      let mut v80_10 = Space::new();
      let mut v80_10_write = v80_10.write_zipper();
      for v80_10_byte in v68_25_cursor.child_mask().iter() {
        v68_25_cursor.descend_to_existing_byte(v80_10_byte);
        {
        let v81_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 1)..(v68_25_origin + 2)]);
        let v81_3: Space = intersect(&(*CONSTANT_1),&(v81_2));
        let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
        drop(v81_3);
        let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
        drop(v81_4);
        let v81_8: Space = if (&(v81_5)).is_empty() { Space::new() } else {
          let mut v82_7 = Space::new();
          let mut v82_7_write = v82_7.write_zipper();
          for v82_7_byte in v68_25_cursor.child_mask().iter() {
            v68_25_cursor.descend_to_existing_byte(v82_7_byte);
            {
            let v83_2: Space = singleton(&v68_25_cursor.path()[(v68_25_origin + 2)..(v68_25_origin + 3)]);
            let v83_3: Space = intersect(&(*CONSTANT_1),&(v83_2));
            let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
            drop(v83_3);
            let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
            drop(v83_4);
            let v83_8: Space = if (&(v83_5)).is_empty() { Space::new() } else {
              let v84_7: Space = routine_16(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v83_5),&(v84_7))
            };
            drop(v83_5);
            let v83_9: Space = intersect(&(*CONSTANT_1),&(v83_2));
            drop(v83_2);
            let v83_10: Space = if has_head(&(v83_9)) { singleton(&[]) } else { Space::new() };
            drop(v83_9);
            let v83_12: Space = if (&(v83_10)).is_empty() { Space::new() } else {
              let v85_11: Space = routine_17(c, &v68_25_cursor.path()[v68_25_origin..(v68_25_origin + 3)], &v68_25_cursor);
              compose(&(v83_10),&(v85_11))
            };
            drop(v83_10);
            let v83_13: Space = unite(&(v83_8),&(v83_12));
            join_wrapped_into(&mut v82_7_write,&((v83_13).read_zipper()),&[]);
            }
            v68_25_cursor.ascend(1);
          }
          drop(v82_7_write);
          compose(&(v81_5),&(v82_7))
        };
        drop(v81_5);
        let v81_9: Space = intersect(&(*CONSTANT_1),&(v81_2));
        drop(v81_2);
        let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
        drop(v81_9);
        let v81_11: Space = compose(&(v81_10),&v68_25_cursor);
        drop(v81_10);
        let v81_12: Space = unite(&(v81_8),&(v81_11));
        drop(v81_11);
        join_wrapped_into(&mut v80_10_write,&((v81_12).read_zipper()),&[]);
        }
        v68_25_cursor.ascend(1);
      }
      drop(v80_10_write);
      compose(&(v69_9),&(v80_10))
    };
    drop(v69_9);
    let v69_12: Space = unite(&(v69_7),&(v69_11));
    join_wrapped_into(&mut v68_25_write,&((v69_12).read_zipper()),&[]);
    }
    v68_25_cursor.ascend(1);
  }
  drop(v68_25_cursor);
  drop(v68_25_write);
  drop(v68_6);
  let v68_26: Space = restrict_to(&(*CONSTANT_3),&(v68_25));
  let mut v68_45 = Space::new();
  let mut v68_45_write = v68_45.write_zipper();
  let mut v68_45_cursor = (v68_26).read_zipper();
  let v68_45_origin = v68_45_cursor.path().len();
  for v68_45_byte in v68_45_cursor.child_mask().iter() {
    v68_45_cursor.descend_to_existing_byte(v68_45_byte);
    {
    let v86_2: Space = singleton(&v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 1)]);
    let v86_3: Space = intersect(&(*CONSTANT_1),&(v86_2));
    let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
    drop(v86_3);
    let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
    drop(v86_4);
    let v86_7: Space = if (&(v86_5)).is_empty() { Space::new() } else {
      let mut v87_6 = Space::new();
      let mut v87_6_write = v87_6.write_zipper();
      for v87_6_byte in v68_45_cursor.child_mask().iter() {
        v68_45_cursor.descend_to_existing_byte(v87_6_byte);
        {
        let v88_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 1)..(v68_45_origin + 2)]);
        let v88_3: Space = intersect(&(*CONSTANT_1),&(v88_2));
        let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
        drop(v88_3);
        let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
        drop(v88_4);
        let v88_8: Space = if (&(v88_5)).is_empty() { Space::new() } else {
          let mut v89_7 = Space::new();
          let mut v89_7_write = v89_7.write_zipper();
          for v89_7_byte in v68_45_cursor.child_mask().iter() {
            v68_45_cursor.descend_to_existing_byte(v89_7_byte);
            {
            let v90_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 2)..(v68_45_origin + 3)]);
            let v90_3: Space = intersect(&(*CONSTANT_1),&(v90_2));
            let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
            drop(v90_3);
            let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
            drop(v90_4);
            let v90_8: Space = if (&(v90_5)).is_empty() { Space::new() } else {
              let v91_7: Space = routine_18(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v90_5),&(v91_7))
            };
            drop(v90_5);
            let v90_9: Space = intersect(&(*CONSTANT_1),&(v90_2));
            drop(v90_2);
            let v90_10: Space = if has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
            drop(v90_9);
            let v90_12: Space = if (&(v90_10)).is_empty() { Space::new() } else {
              let v92_11: Space = routine_19(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v90_10),&(v92_11))
            };
            drop(v90_10);
            let v90_13: Space = unite(&(v90_8),&(v90_12));
            join_wrapped_into(&mut v89_7_write,&((v90_13).read_zipper()),&[]);
            }
            v68_45_cursor.ascend(1);
          }
          drop(v89_7_write);
          compose(&(v88_5),&(v89_7))
        };
        drop(v88_5);
        let v88_9: Space = intersect(&(*CONSTANT_1),&(v88_2));
        drop(v88_2);
        let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
        drop(v88_9);
        let v88_12: Space = if (&(v88_10)).is_empty() { Space::new() } else {
          let mut v93_11 = Space::new();
          let mut v93_11_write = v93_11.write_zipper();
          for v93_11_byte in v68_45_cursor.child_mask().iter() {
            v68_45_cursor.descend_to_existing_byte(v93_11_byte);
            {
            let v94_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 2)..(v68_45_origin + 3)]);
            let v94_3: Space = intersect(&(*CONSTANT_1),&(v94_2));
            let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
            drop(v94_3);
            let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
            drop(v94_4);
            let v94_8: Space = if (&(v94_5)).is_empty() { Space::new() } else {
              let v95_7: Space = routine_18(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v94_5),&(v95_7))
            };
            drop(v94_5);
            let v94_9: Space = intersect(&(*CONSTANT_1),&(v94_2));
            drop(v94_2);
            let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
            drop(v94_9);
            let v94_12: Space = if (&(v94_10)).is_empty() { Space::new() } else {
              let v96_11: Space = routine_15(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v94_10),&(v96_11))
            };
            drop(v94_10);
            let v94_13: Space = unite(&(v94_8),&(v94_12));
            join_wrapped_into(&mut v93_11_write,&((v94_13).read_zipper()),&[]);
            }
            v68_45_cursor.ascend(1);
          }
          drop(v93_11_write);
          compose(&(v88_10),&(v93_11))
        };
        drop(v88_10);
        let v88_13: Space = unite(&(v88_8),&(v88_12));
        join_wrapped_into(&mut v87_6_write,&((v88_13).read_zipper()),&[]);
        }
        v68_45_cursor.ascend(1);
      }
      drop(v87_6_write);
      compose(&(v86_5),&(v87_6))
    };
    drop(v86_5);
    let v86_8: Space = intersect(&(*CONSTANT_1),&(v86_2));
    drop(v86_2);
    let v86_9: Space = if has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
    drop(v86_8);
    let v86_11: Space = if (&(v86_9)).is_empty() { Space::new() } else {
      let mut v97_10 = Space::new();
      let mut v97_10_write = v97_10.write_zipper();
      for v97_10_byte in v68_45_cursor.child_mask().iter() {
        v68_45_cursor.descend_to_existing_byte(v97_10_byte);
        {
        let v98_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 1)..(v68_45_origin + 2)]);
        let v98_3: Space = intersect(&(*CONSTANT_1),&(v98_2));
        let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
        drop(v98_3);
        let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
        drop(v98_4);
        let v98_8: Space = if (&(v98_5)).is_empty() { Space::new() } else {
          let mut v99_7 = Space::new();
          let mut v99_7_write = v99_7.write_zipper();
          for v99_7_byte in v68_45_cursor.child_mask().iter() {
            v68_45_cursor.descend_to_existing_byte(v99_7_byte);
            {
            let v100_2: Space = singleton(&v68_45_cursor.path()[(v68_45_origin + 2)..(v68_45_origin + 3)]);
            let v100_3: Space = intersect(&(*CONSTANT_1),&(v100_2));
            let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
            drop(v100_3);
            let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
            drop(v100_4);
            let v100_8: Space = if (&(v100_5)).is_empty() { Space::new() } else {
              let v101_7: Space = routine_18(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v100_5),&(v101_7))
            };
            drop(v100_5);
            let v100_9: Space = intersect(&(*CONSTANT_1),&(v100_2));
            drop(v100_2);
            let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
            drop(v100_9);
            let v100_12: Space = if (&(v100_10)).is_empty() { Space::new() } else {
              let v102_11: Space = routine_19(c, &v68_45_cursor.path()[v68_45_origin..(v68_45_origin + 3)], &v68_45_cursor);
              compose(&(v100_10),&(v102_11))
            };
            drop(v100_10);
            let v100_13: Space = unite(&(v100_8),&(v100_12));
            join_wrapped_into(&mut v99_7_write,&((v100_13).read_zipper()),&[]);
            }
            v68_45_cursor.ascend(1);
          }
          drop(v99_7_write);
          compose(&(v98_5),&(v99_7))
        };
        drop(v98_5);
        let v98_9: Space = intersect(&(*CONSTANT_1),&(v98_2));
        drop(v98_2);
        let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
        drop(v98_9);
        let v98_11: Space = compose(&(v98_10),&v68_45_cursor);
        drop(v98_10);
        let v98_12: Space = unite(&(v98_8),&(v98_11));
        drop(v98_11);
        join_wrapped_into(&mut v97_10_write,&((v98_12).read_zipper()),&[]);
        }
        v68_45_cursor.ascend(1);
      }
      drop(v97_10_write);
      compose(&(v86_9),&(v97_10))
    };
    drop(v86_9);
    let v86_12: Space = unite(&(v86_7),&(v86_11));
    join_wrapped_into(&mut v68_45_write,&((v86_12).read_zipper()),&[]);
    }
    v68_45_cursor.ascend(1);
  }
  drop(v68_45_cursor);
  drop(v68_45_write);
  let v68_48: Space = subtract(&(v68_45),&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0))));
  let v68_50: Space = intersect(&(v68_48),&(*CONSTANT_5));
  let v68_51: Space = wrap(&(v68_50),&(*p0));
  (v68_51).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v103_21 = Space::new();
  let mut v103_21_write = v103_21.write_zipper();
  let mut v103_21_cursor = (*s0).read_zipper();
  let v103_21_origin = v103_21_cursor.path().len();
  for v103_21_byte in v103_21_cursor.child_mask().iter() {
    v103_21_cursor.descend_to_existing_byte(v103_21_byte);
    {
    let v104_2: Space = singleton(&v103_21_cursor.path()[v103_21_origin..(v103_21_origin + 1)]);
    let v104_3: Space = intersect(&(*CONSTANT_1),&(v104_2));
    let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
    drop(v104_3);
    let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
    drop(v104_4);
    let v104_8: Space = if (&(v104_5)).is_empty() { Space::new() } else {
      let v105_6: Path = concat_path(&(*p0),&v103_21_cursor.path()[v103_21_origin..(v103_21_origin + 1)]);
      let mut v105_7 = Space::new();
      let mut v105_7_write = v105_7.write_zipper();
      for v105_7_byte in v103_21_cursor.child_mask().iter() {
        v103_21_cursor.descend_to_existing_byte(v105_7_byte);
        {
        let v106_2: Space = singleton(&v103_21_cursor.path()[(v103_21_origin + 1)..(v103_21_origin + 2)]);
        let v106_3: Space = intersect(&(*CONSTANT_1),&(v106_2));
        drop(v106_2);
        let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
        drop(v106_3);
        let v106_7: Space = if (&(v106_4)).is_empty() { Space::new() } else {
          let v107_5: Path = concat_path(&(v105_6),&v103_21_cursor.path()[(v103_21_origin + 1)..(v103_21_origin + 2)]);
          let mut v107_6 = Space::new();
          let mut v107_6_write = v107_6.write_zipper();
          for v107_6_byte in v103_21_cursor.child_mask().iter() {
            v103_21_cursor.descend_to_existing_byte(v107_6_byte);
            {
            let v108_2: Space = singleton(&v103_21_cursor.path()[(v103_21_origin + 2)..(v103_21_origin + 3)]);
            let v108_3: Space = intersect(&(*CONSTANT_1),&(v108_2));
            drop(v108_2);
            let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
            drop(v108_3);
            let v108_7: Space = if (&(v108_4)).is_empty() { Space::new() } else {
              let v109_5: Path = concat_path(&(v107_5),&v103_21_cursor.path()[(v103_21_origin + 2)..(v103_21_origin + 3)]);
              let v109_6: Space = routine_3(c, &(v109_5), &v103_21_cursor);
              drop(v109_5);
              compose(&(v108_4),&(v109_6))
            };
            drop(v108_4);
            join_wrapped_into(&mut v107_6_write,&((v108_7).read_zipper()),&[]);
            }
            v103_21_cursor.ascend(1);
          }
          drop(v107_6_write);
          drop(v107_5);
          compose(&(v106_4),&(v107_6))
        };
        drop(v106_4);
        join_wrapped_into(&mut v105_7_write,&((v106_7).read_zipper()),&[]);
        }
        v103_21_cursor.ascend(1);
      }
      drop(v105_7_write);
      compose(&(v104_5),&(v105_7))
    };
    drop(v104_5);
    let v104_9: Space = intersect(&(*CONSTANT_1),&(v104_2));
    drop(v104_2);
    let v104_10: Space = if has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
    drop(v104_9);
    let v104_14: Space = if (&(v104_10)).is_empty() { Space::new() } else {
      let v110_6: Path = concat_path(&(*p0),&v103_21_cursor.path()[v103_21_origin..(v103_21_origin + 1)]);
      let mut v110_13 = Space::new();
      let mut v110_13_write = v110_13.write_zipper();
      for v110_13_byte in v103_21_cursor.child_mask().iter() {
        v103_21_cursor.descend_to_existing_byte(v110_13_byte);
        {
        let v111_2: Space = singleton(&v103_21_cursor.path()[(v103_21_origin + 1)..(v103_21_origin + 2)]);
        let v111_3: Space = intersect(&(*CONSTANT_1),&(v111_2));
        drop(v111_2);
        let v111_4: Space = if has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
        drop(v111_3);
        let v111_13: Space = if (&(v111_4)).is_empty() { Space::new() } else {
          let v112_6: Space = restrict_to(&(*CONSTANT_4),&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v103_21_cursor.path()[v103_21_origin..(v103_21_origin + 1)]),&v103_21_cursor.path()[(v103_21_origin + 1)..(v103_21_origin + 2)])));
          let mut v112_7 = Space::new();
          let mut v112_7_write = v112_7.write_zipper();
          let mut v112_7_cursor = (v112_6).read_zipper();
          let v112_7_origin = v112_7_cursor.path().len();
          for v112_7_byte in v112_7_cursor.child_mask().iter() {
            v112_7_cursor.descend_to_existing_byte(v112_7_byte);
            {
            let v113_2: Space = singleton(&v112_7_cursor.path()[v112_7_origin..(v112_7_origin + 1)]);
            let v113_3: Space = intersect(&(*CONSTANT_1),&(v113_2));
            let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
            drop(v113_3);
            let v113_5: Space = subtract(&(*CONSTANT_0),&(v113_4));
            drop(v113_4);
            let v113_7: Space = if (&(v113_5)).is_empty() { Space::new() } else {
              let v114_6: Space = routine_6(c, &v112_7_cursor.path()[v112_7_origin..(v112_7_origin + 1)], &v112_7_cursor);
              compose(&(v113_5),&(v114_6))
            };
            drop(v113_5);
            let v113_8: Space = intersect(&(*CONSTANT_1),&(v113_2));
            drop(v113_2);
            let v113_9: Space = if has_head(&(v113_8)) { singleton(&[]) } else { Space::new() };
            drop(v113_8);
            let v113_11: Space = if (&(v113_9)).is_empty() { Space::new() } else {
              let v115_10: Space = routine_7(c, &v112_7_cursor.path()[v112_7_origin..(v112_7_origin + 1)], &v112_7_cursor);
              compose(&(v113_9),&(v115_10))
            };
            drop(v113_9);
            let v113_12: Space = unite(&(v113_7),&(v113_11));
            join_wrapped_into(&mut v112_7_write,&((v113_12).read_zipper()),&[]);
            }
            v112_7_cursor.ascend(1);
          }
          drop(v112_7_cursor);
          drop(v112_7_write);
          drop(v112_6);
          let v112_8: Space = restrict_to(&(*CONSTANT_3),&(v112_7));
          let mut v112_9 = Space::new();
          let mut v112_9_write = v112_9.write_zipper();
          let mut v112_9_cursor = (v112_8).read_zipper();
          let v112_9_origin = v112_9_cursor.path().len();
          for v112_9_byte in v112_9_cursor.child_mask().iter() {
            v112_9_cursor.descend_to_existing_byte(v112_9_byte);
            {
            let v116_2: Space = singleton(&v112_9_cursor.path()[v112_9_origin..(v112_9_origin + 1)]);
            let v116_3: Space = intersect(&(*CONSTANT_1),&(v116_2));
            let v116_4: Space = if has_head(&(v116_3)) { singleton(&[]) } else { Space::new() };
            drop(v116_3);
            let v116_5: Space = subtract(&(*CONSTANT_0),&(v116_4));
            drop(v116_4);
            let v116_7: Space = if (&(v116_5)).is_empty() { Space::new() } else {
              let v117_6: Space = routine_8(c, &v112_9_cursor.path()[v112_9_origin..(v112_9_origin + 1)], &v112_9_cursor);
              compose(&(v116_5),&(v117_6))
            };
            drop(v116_5);
            let v116_8: Space = intersect(&(*CONSTANT_1),&(v116_2));
            drop(v116_2);
            let v116_9: Space = if has_head(&(v116_8)) { singleton(&[]) } else { Space::new() };
            drop(v116_8);
            let v116_11: Space = if (&(v116_9)).is_empty() { Space::new() } else {
              let v118_10: Space = routine_9(c, &v112_9_cursor.path()[v112_9_origin..(v112_9_origin + 1)], &v112_9_cursor);
              compose(&(v116_9),&(v118_10))
            };
            drop(v116_9);
            let v116_12: Space = unite(&(v116_7),&(v116_11));
            join_wrapped_into(&mut v112_9_write,&((v116_12).read_zipper()),&[]);
            }
            v112_9_cursor.ascend(1);
          }
          drop(v112_9_cursor);
          drop(v112_9_write);
          let v112_11: Space = subtract(&(v112_9),&(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v103_21_cursor.path()[v103_21_origin..(v103_21_origin + 1)]),&v103_21_cursor.path()[(v103_21_origin + 1)..(v103_21_origin + 2)])));
          let v112_12: Space = intersect(&(v112_11),&(*CONSTANT_5));
          compose(&(v111_4),&(v112_12))
        };
        drop(v111_4);
        let v111_14: Path = concat_path(&(v110_6),&v103_21_cursor.path()[(v103_21_origin + 1)..(v103_21_origin + 2)]);
        join_wrapped_into(&mut v110_13_write,&((v111_13).read_zipper()),&(v111_14));
        drop(v111_14);
        }
        v103_21_cursor.ascend(1);
      }
      drop(v110_13_write);
      drop(v110_6);
      compose(&(v104_10),&(v110_13))
    };
    drop(v104_10);
    let v104_15: Space = unite(&(v104_8),&(v104_14));
    join_wrapped_into(&mut v103_21_write,&((v104_15).read_zipper()),&[]);
    }
    v103_21_cursor.ascend(1);
  }
  drop(v103_21_cursor);
  drop(v103_21_write);
  (v103_21).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v119_32 = Space::new();
  let mut v119_32_write = v119_32.write_zipper();
  let mut v119_32_cursor = (*s0).read_zipper();
  let v119_32_origin = v119_32_cursor.path().len();
  for v119_32_byte in v119_32_cursor.child_mask().iter() {
    v119_32_cursor.descend_to_existing_byte(v119_32_byte);
    {
    let v120_2: Space = singleton(&v119_32_cursor.path()[v119_32_origin..(v119_32_origin + 1)]);
    let v120_3: Space = intersect(&(*CONSTANT_1),&(v120_2));
    let v120_4: Space = if has_head(&(v120_3)) { singleton(&[]) } else { Space::new() };
    drop(v120_3);
    let v120_5: Space = subtract(&(*CONSTANT_0),&(v120_4));
    drop(v120_4);
    let v120_8: Space = if (&(v120_5)).is_empty() { Space::new() } else {
      let v121_6: Path = concat_path(&(*p0),&v119_32_cursor.path()[v119_32_origin..(v119_32_origin + 1)]);
      let mut v121_7 = Space::new();
      let mut v121_7_write = v121_7.write_zipper();
      for v121_7_byte in v119_32_cursor.child_mask().iter() {
        v119_32_cursor.descend_to_existing_byte(v121_7_byte);
        {
        let v122_2: Space = singleton(&v119_32_cursor.path()[(v119_32_origin + 1)..(v119_32_origin + 2)]);
        let v122_3: Space = intersect(&(*CONSTANT_1),&(v122_2));
        drop(v122_2);
        let v122_4: Space = if has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
        drop(v122_3);
        let v122_7: Space = if (&(v122_4)).is_empty() { Space::new() } else {
          let v123_5: Path = concat_path(&(v121_6),&v119_32_cursor.path()[(v119_32_origin + 1)..(v119_32_origin + 2)]);
          let mut v123_6 = Space::new();
          let mut v123_6_write = v123_6.write_zipper();
          for v123_6_byte in v119_32_cursor.child_mask().iter() {
            v119_32_cursor.descend_to_existing_byte(v123_6_byte);
            {
            let v124_2: Space = singleton(&v119_32_cursor.path()[(v119_32_origin + 2)..(v119_32_origin + 3)]);
            let v124_3: Space = intersect(&(*CONSTANT_1),&(v124_2));
            drop(v124_2);
            let v124_4: Space = if has_head(&(v124_3)) { singleton(&[]) } else { Space::new() };
            drop(v124_3);
            let v124_7: Space = if (&(v124_4)).is_empty() { Space::new() } else {
              let v125_5: Path = concat_path(&(v123_5),&v119_32_cursor.path()[(v119_32_origin + 2)..(v119_32_origin + 3)]);
              let v125_6: Space = routine_3(c, &(v125_5), &v119_32_cursor);
              drop(v125_5);
              compose(&(v124_4),&(v125_6))
            };
            drop(v124_4);
            join_wrapped_into(&mut v123_6_write,&((v124_7).read_zipper()),&[]);
            }
            v119_32_cursor.ascend(1);
          }
          drop(v123_6_write);
          drop(v123_5);
          compose(&(v122_4),&(v123_6))
        };
        drop(v122_4);
        join_wrapped_into(&mut v121_7_write,&((v122_7).read_zipper()),&[]);
        }
        v119_32_cursor.ascend(1);
      }
      drop(v121_7_write);
      compose(&(v120_5),&(v121_7))
    };
    drop(v120_5);
    let v120_9: Space = intersect(&(*CONSTANT_1),&(v120_2));
    drop(v120_2);
    let v120_10: Space = if has_head(&(v120_9)) { singleton(&[]) } else { Space::new() };
    drop(v120_9);
    let v120_19: Space = if (&(v120_10)).is_empty() { Space::new() } else {
      let v126_12: Space = restrict_to(&(*CONSTANT_4),&(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v119_32_cursor.path()[v119_32_origin..(v119_32_origin + 1)])));
      let mut v126_13 = Space::new();
      let mut v126_13_write = v126_13.write_zipper();
      let mut v126_13_cursor = (v126_12).read_zipper();
      let v126_13_origin = v126_13_cursor.path().len();
      for v126_13_byte in v126_13_cursor.child_mask().iter() {
        v126_13_cursor.descend_to_existing_byte(v126_13_byte);
        {
        let v127_2: Space = singleton(&v126_13_cursor.path()[v126_13_origin..(v126_13_origin + 1)]);
        let v127_3: Space = intersect(&(*CONSTANT_1),&(v127_2));
        let v127_4: Space = if has_head(&(v127_3)) { singleton(&[]) } else { Space::new() };
        drop(v127_3);
        let v127_5: Space = subtract(&(*CONSTANT_0),&(v127_4));
        drop(v127_4);
        let v127_7: Space = if (&(v127_5)).is_empty() { Space::new() } else {
          let mut v128_6 = Space::new();
          let mut v128_6_write = v128_6.write_zipper();
          for v128_6_byte in v126_13_cursor.child_mask().iter() {
            v126_13_cursor.descend_to_existing_byte(v128_6_byte);
            {
            let v129_2: Space = singleton(&v126_13_cursor.path()[(v126_13_origin + 1)..(v126_13_origin + 2)]);
            let v129_3: Space = intersect(&(*CONSTANT_1),&(v129_2));
            let v129_4: Space = if has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
            drop(v129_3);
            let v129_5: Space = subtract(&(*CONSTANT_0),&(v129_4));
            drop(v129_4);
            let v129_8: Space = if (&(v129_5)).is_empty() { Space::new() } else {
              let v130_7: Space = routine_10(c, &v126_13_cursor.path()[v126_13_origin..(v126_13_origin + 2)], &v126_13_cursor);
              compose(&(v129_5),&(v130_7))
            };
            drop(v129_5);
            let v129_9: Space = intersect(&(*CONSTANT_1),&(v129_2));
            drop(v129_2);
            let v129_10: Space = if has_head(&(v129_9)) { singleton(&[]) } else { Space::new() };
            drop(v129_9);
            let v129_12: Space = if (&(v129_10)).is_empty() { Space::new() } else {
              let v131_11: Space = routine_11(c, &v126_13_cursor.path()[v126_13_origin..(v126_13_origin + 2)], &v126_13_cursor);
              compose(&(v129_10),&(v131_11))
            };
            drop(v129_10);
            let v129_13: Space = unite(&(v129_8),&(v129_12));
            join_wrapped_into(&mut v128_6_write,&((v129_13).read_zipper()),&[]);
            }
            v126_13_cursor.ascend(1);
          }
          drop(v128_6_write);
          compose(&(v127_5),&(v128_6))
        };
        drop(v127_5);
        let v127_8: Space = intersect(&(*CONSTANT_1),&(v127_2));
        drop(v127_2);
        let v127_9: Space = if has_head(&(v127_8)) { singleton(&[]) } else { Space::new() };
        drop(v127_8);
        let v127_11: Space = if (&(v127_9)).is_empty() { Space::new() } else {
          let mut v132_10 = Space::new();
          let mut v132_10_write = v132_10.write_zipper();
          for v132_10_byte in v126_13_cursor.child_mask().iter() {
            v126_13_cursor.descend_to_existing_byte(v132_10_byte);
            {
            let v133_2: Space = singleton(&v126_13_cursor.path()[(v126_13_origin + 1)..(v126_13_origin + 2)]);
            let v133_3: Space = intersect(&(*CONSTANT_1),&(v133_2));
            let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
            drop(v133_3);
            let v133_5: Space = subtract(&(*CONSTANT_0),&(v133_4));
            drop(v133_4);
            let v133_8: Space = if (&(v133_5)).is_empty() { Space::new() } else {
              let v134_7: Space = routine_10(c, &v126_13_cursor.path()[v126_13_origin..(v126_13_origin + 2)], &v126_13_cursor);
              compose(&(v133_5),&(v134_7))
            };
            drop(v133_5);
            let v133_9: Space = intersect(&(*CONSTANT_1),&(v133_2));
            drop(v133_2);
            let v133_10: Space = if has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
            drop(v133_9);
            let v133_12: Space = if (&(v133_10)).is_empty() { Space::new() } else {
              let v135_11: Space = routine_12(c, &v126_13_cursor.path()[v126_13_origin..(v126_13_origin + 2)], &v126_13_cursor);
              compose(&(v133_10),&(v135_11))
            };
            drop(v133_10);
            let v133_13: Space = unite(&(v133_8),&(v133_12));
            join_wrapped_into(&mut v132_10_write,&((v133_13).read_zipper()),&[]);
            }
            v126_13_cursor.ascend(1);
          }
          drop(v132_10_write);
          compose(&(v127_9),&(v132_10))
        };
        drop(v127_9);
        let v127_12: Space = unite(&(v127_7),&(v127_11));
        join_wrapped_into(&mut v126_13_write,&((v127_12).read_zipper()),&[]);
        }
        v126_13_cursor.ascend(1);
      }
      drop(v126_13_cursor);
      drop(v126_13_write);
      drop(v126_12);
      let v126_14: Space = restrict_to(&(*CONSTANT_3),&(v126_13));
      let mut v126_15 = Space::new();
      let mut v126_15_write = v126_15.write_zipper();
      let mut v126_15_cursor = (v126_14).read_zipper();
      let v126_15_origin = v126_15_cursor.path().len();
      for v126_15_byte in v126_15_cursor.child_mask().iter() {
        v126_15_cursor.descend_to_existing_byte(v126_15_byte);
        {
        let v136_2: Space = singleton(&v126_15_cursor.path()[v126_15_origin..(v126_15_origin + 1)]);
        let v136_3: Space = intersect(&(*CONSTANT_1),&(v136_2));
        let v136_4: Space = if has_head(&(v136_3)) { singleton(&[]) } else { Space::new() };
        drop(v136_3);
        let v136_5: Space = subtract(&(*CONSTANT_0),&(v136_4));
        drop(v136_4);
        let v136_7: Space = if (&(v136_5)).is_empty() { Space::new() } else {
          let mut v137_6 = Space::new();
          let mut v137_6_write = v137_6.write_zipper();
          for v137_6_byte in v126_15_cursor.child_mask().iter() {
            v126_15_cursor.descend_to_existing_byte(v137_6_byte);
            {
            let v138_2: Space = singleton(&v126_15_cursor.path()[(v126_15_origin + 1)..(v126_15_origin + 2)]);
            let v138_3: Space = intersect(&(*CONSTANT_1),&(v138_2));
            let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
            drop(v138_3);
            let v138_5: Space = subtract(&(*CONSTANT_0),&(v138_4));
            drop(v138_4);
            let v138_8: Space = if (&(v138_5)).is_empty() { Space::new() } else {
              let v139_7: Space = routine_13(c, &v126_15_cursor.path()[v126_15_origin..(v126_15_origin + 2)], &v126_15_cursor);
              compose(&(v138_5),&(v139_7))
            };
            drop(v138_5);
            let v138_9: Space = intersect(&(*CONSTANT_1),&(v138_2));
            drop(v138_2);
            let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
            drop(v138_9);
            let v138_12: Space = if (&(v138_10)).is_empty() { Space::new() } else {
              let v140_11: Space = routine_14(c, &v126_15_cursor.path()[v126_15_origin..(v126_15_origin + 2)], &v126_15_cursor);
              compose(&(v138_10),&(v140_11))
            };
            drop(v138_10);
            let v138_13: Space = unite(&(v138_8),&(v138_12));
            join_wrapped_into(&mut v137_6_write,&((v138_13).read_zipper()),&[]);
            }
            v126_15_cursor.ascend(1);
          }
          drop(v137_6_write);
          compose(&(v136_5),&(v137_6))
        };
        drop(v136_5);
        let v136_8: Space = intersect(&(*CONSTANT_1),&(v136_2));
        drop(v136_2);
        let v136_9: Space = if has_head(&(v136_8)) { singleton(&[]) } else { Space::new() };
        drop(v136_8);
        let v136_11: Space = if (&(v136_9)).is_empty() { Space::new() } else {
          let mut v141_10 = Space::new();
          let mut v141_10_write = v141_10.write_zipper();
          for v141_10_byte in v126_15_cursor.child_mask().iter() {
            v126_15_cursor.descend_to_existing_byte(v141_10_byte);
            {
            let v142_2: Space = singleton(&v126_15_cursor.path()[(v126_15_origin + 1)..(v126_15_origin + 2)]);
            let v142_3: Space = intersect(&(*CONSTANT_1),&(v142_2));
            let v142_4: Space = if has_head(&(v142_3)) { singleton(&[]) } else { Space::new() };
            drop(v142_3);
            let v142_5: Space = subtract(&(*CONSTANT_0),&(v142_4));
            drop(v142_4);
            let v142_8: Space = if (&(v142_5)).is_empty() { Space::new() } else {
              let v143_7: Space = routine_13(c, &v126_15_cursor.path()[v126_15_origin..(v126_15_origin + 2)], &v126_15_cursor);
              compose(&(v142_5),&(v143_7))
            };
            drop(v142_5);
            let v142_9: Space = intersect(&(*CONSTANT_1),&(v142_2));
            drop(v142_2);
            let v142_10: Space = if has_head(&(v142_9)) { singleton(&[]) } else { Space::new() };
            drop(v142_9);
            let v142_12: Space = if (&(v142_10)).is_empty() { Space::new() } else {
              let v144_11: Space = routine_15(c, &v126_15_cursor.path()[v126_15_origin..(v126_15_origin + 2)], &v126_15_cursor);
              compose(&(v142_10),&(v144_11))
            };
            drop(v142_10);
            let v142_13: Space = unite(&(v142_8),&(v142_12));
            join_wrapped_into(&mut v141_10_write,&((v142_13).read_zipper()),&[]);
            }
            v126_15_cursor.ascend(1);
          }
          drop(v141_10_write);
          compose(&(v136_9),&(v141_10))
        };
        drop(v136_9);
        let v136_12: Space = unite(&(v136_7),&(v136_11));
        join_wrapped_into(&mut v126_15_write,&((v136_12).read_zipper()),&[]);
        }
        v126_15_cursor.ascend(1);
      }
      drop(v126_15_cursor);
      drop(v126_15_write);
      let v126_17: Space = subtract(&(v126_15),&(descend_cursor(descend_cursor((*CONSTANT_4).read_zipper(),&(*p0)),&v119_32_cursor.path()[v119_32_origin..(v119_32_origin + 1)])));
      let v126_18: Space = intersect(&(v126_17),&(*CONSTANT_5));
      compose(&(v120_10),&(v126_18))
    };
    drop(v120_10);
    let v145_6: Path = concat_path(&(*p0),&v119_32_cursor.path()[v119_32_origin..(v119_32_origin + 1)]);
    let v120_20: Space = wrap(&(v120_19),&(v145_6));
    let v120_21: Space = unite(&(v120_8),&(v120_20));
    join_wrapped_into(&mut v119_32_write,&((v120_21).read_zipper()),&[]);
    }
    v119_32_cursor.ascend(1);
  }
  drop(v119_32_cursor);
  drop(v119_32_write);
  (v119_32).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v146_20 = Space::new();
  let mut v146_20_write = v146_20.write_zipper();
  let mut v146_20_cursor = (*s0).read_zipper();
  let v146_20_origin = v146_20_cursor.path().len();
  for v146_20_byte in v146_20_cursor.child_mask().iter() {
    v146_20_cursor.descend_to_existing_byte(v146_20_byte);
    {
    let v147_2: Space = singleton(&v146_20_cursor.path()[v146_20_origin..(v146_20_origin + 1)]);
    let v147_3: Space = intersect(&(*CONSTANT_1),&(v147_2));
    let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
    drop(v147_3);
    let v147_5: Space = subtract(&(*CONSTANT_0),&(v147_4));
    drop(v147_4);
    let v147_8: Space = if (&(v147_5)).is_empty() { Space::new() } else {
      let v148_6: Path = concat_path(&(*p0),&v146_20_cursor.path()[v146_20_origin..(v146_20_origin + 1)]);
      let mut v148_7 = Space::new();
      let mut v148_7_write = v148_7.write_zipper();
      for v148_7_byte in v146_20_cursor.child_mask().iter() {
        v146_20_cursor.descend_to_existing_byte(v148_7_byte);
        {
        let v149_2: Space = singleton(&v146_20_cursor.path()[(v146_20_origin + 1)..(v146_20_origin + 2)]);
        let v149_3: Space = intersect(&(*CONSTANT_1),&(v149_2));
        let v149_4: Space = if has_head(&(v149_3)) { singleton(&[]) } else { Space::new() };
        drop(v149_3);
        let v149_5: Space = subtract(&(*CONSTANT_0),&(v149_4));
        drop(v149_4);
        let v149_8: Space = if (&(v149_5)).is_empty() { Space::new() } else {
          let v150_6: Path = concat_path(&(v148_6),&v146_20_cursor.path()[(v146_20_origin + 1)..(v146_20_origin + 2)]);
          let mut v150_7 = Space::new();
          let mut v150_7_write = v150_7.write_zipper();
          for v150_7_byte in v146_20_cursor.child_mask().iter() {
            v146_20_cursor.descend_to_existing_byte(v150_7_byte);
            {
            let v151_2: Space = singleton(&v146_20_cursor.path()[(v146_20_origin + 2)..(v146_20_origin + 3)]);
            let v151_3: Space = intersect(&(*CONSTANT_1),&(v151_2));
            let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
            drop(v151_3);
            let v151_5: Space = subtract(&(*CONSTANT_0),&(v151_4));
            drop(v151_4);
            let v151_8: Space = if (&(v151_5)).is_empty() { Space::new() } else {
              let v152_6: Path = concat_path(&(v150_6),&v146_20_cursor.path()[(v146_20_origin + 2)..(v146_20_origin + 3)]);
              let v152_7: Space = routine_20(c, &(v152_6), &v146_20_cursor);
              compose(&(v151_5),&(v152_7))
            };
            drop(v151_5);
            let v151_9: Space = intersect(&(*CONSTANT_1),&(v151_2));
            drop(v151_2);
            let v151_10: Space = if has_head(&(v151_9)) { singleton(&[]) } else { Space::new() };
            drop(v151_9);
            let v151_12: Space = if (&(v151_10)).is_empty() { Space::new() } else {
              let v153_6: Path = concat_path(&(v150_6),&v146_20_cursor.path()[(v146_20_origin + 2)..(v146_20_origin + 3)]);
              let v153_11: Space = routine_21(c, &(v153_6), &v146_20_cursor);
              drop(v153_6);
              compose(&(v151_10),&(v153_11))
            };
            drop(v151_10);
            let v151_13: Space = unite(&(v151_8),&(v151_12));
            join_wrapped_into(&mut v150_7_write,&((v151_13).read_zipper()),&[]);
            }
            v146_20_cursor.ascend(1);
          }
          drop(v150_7_write);
          compose(&(v149_5),&(v150_7))
        };
        drop(v149_5);
        let v149_9: Space = intersect(&(*CONSTANT_1),&(v149_2));
        drop(v149_2);
        let v149_10: Space = if has_head(&(v149_9)) { singleton(&[]) } else { Space::new() };
        drop(v149_9);
        let v149_12: Space = if (&(v149_10)).is_empty() { Space::new() } else {
          let v154_6: Path = concat_path(&(v148_6),&v146_20_cursor.path()[(v146_20_origin + 1)..(v146_20_origin + 2)]);
          let mut v154_11 = Space::new();
          let mut v154_11_write = v154_11.write_zipper();
          for v154_11_byte in v146_20_cursor.child_mask().iter() {
            v146_20_cursor.descend_to_existing_byte(v154_11_byte);
            {
            let v155_2: Space = singleton(&v146_20_cursor.path()[(v146_20_origin + 2)..(v146_20_origin + 3)]);
            let v155_3: Space = intersect(&(*CONSTANT_1),&(v155_2));
            let v155_4: Space = if has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
            drop(v155_3);
            let v155_5: Space = subtract(&(*CONSTANT_0),&(v155_4));
            drop(v155_4);
            let v155_8: Space = if (&(v155_5)).is_empty() { Space::new() } else {
              let v156_6: Path = concat_path(&(v154_6),&v146_20_cursor.path()[(v146_20_origin + 2)..(v146_20_origin + 3)]);
              let v156_7: Space = routine_20(c, &(v156_6), &v146_20_cursor);
              compose(&(v155_5),&(v156_7))
            };
            drop(v155_5);
            let v155_9: Space = intersect(&(*CONSTANT_1),&(v155_2));
            drop(v155_2);
            let v155_10: Space = if has_head(&(v155_9)) { singleton(&[]) } else { Space::new() };
            drop(v155_9);
            let v155_12: Space = if (&(v155_10)).is_empty() { Space::new() } else {
              let v157_6: Path = concat_path(&(v154_6),&v146_20_cursor.path()[(v146_20_origin + 2)..(v146_20_origin + 3)]);
              let v157_11: Space = routine_12(c, &(v157_6), &v146_20_cursor);
              drop(v157_6);
              compose(&(v155_10),&(v157_11))
            };
            drop(v155_10);
            let v155_13: Space = unite(&(v155_8),&(v155_12));
            join_wrapped_into(&mut v154_11_write,&((v155_13).read_zipper()),&[]);
            }
            v146_20_cursor.ascend(1);
          }
          drop(v154_11_write);
          drop(v154_6);
          compose(&(v149_10),&(v154_11))
        };
        drop(v149_10);
        let v149_13: Space = unite(&(v149_8),&(v149_12));
        join_wrapped_into(&mut v148_7_write,&((v149_13).read_zipper()),&[]);
        }
        v146_20_cursor.ascend(1);
      }
      drop(v148_7_write);
      compose(&(v147_5),&(v148_7))
    };
    drop(v147_5);
    let v147_9: Space = intersect(&(*CONSTANT_1),&(v147_2));
    drop(v147_2);
    let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
    drop(v147_9);
    let v147_12: Space = if (&(v147_10)).is_empty() { Space::new() } else {
      let v158_6: Path = concat_path(&(*p0),&v146_20_cursor.path()[v146_20_origin..(v146_20_origin + 1)]);
      let mut v158_11 = Space::new();
      let mut v158_11_write = v158_11.write_zipper();
      for v158_11_byte in v146_20_cursor.child_mask().iter() {
        v146_20_cursor.descend_to_existing_byte(v158_11_byte);
        {
        let v159_2: Space = singleton(&v146_20_cursor.path()[(v146_20_origin + 1)..(v146_20_origin + 2)]);
        let v159_3: Space = intersect(&(*CONSTANT_1),&(v159_2));
        let v159_4: Space = if has_head(&(v159_3)) { singleton(&[]) } else { Space::new() };
        drop(v159_3);
        let v159_5: Space = subtract(&(*CONSTANT_0),&(v159_4));
        drop(v159_4);
        let v159_8: Space = if (&(v159_5)).is_empty() { Space::new() } else {
          let v160_6: Path = concat_path(&(v158_6),&v146_20_cursor.path()[(v146_20_origin + 1)..(v146_20_origin + 2)]);
          let mut v160_7 = Space::new();
          let mut v160_7_write = v160_7.write_zipper();
          for v160_7_byte in v146_20_cursor.child_mask().iter() {
            v146_20_cursor.descend_to_existing_byte(v160_7_byte);
            {
            let v161_2: Space = singleton(&v146_20_cursor.path()[(v146_20_origin + 2)..(v146_20_origin + 3)]);
            let v161_3: Space = intersect(&(*CONSTANT_1),&(v161_2));
            let v161_4: Space = if has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
            drop(v161_3);
            let v161_5: Space = subtract(&(*CONSTANT_0),&(v161_4));
            drop(v161_4);
            let v161_8: Space = if (&(v161_5)).is_empty() { Space::new() } else {
              let v162_6: Path = concat_path(&(v160_6),&v146_20_cursor.path()[(v146_20_origin + 2)..(v146_20_origin + 3)]);
              let v162_7: Space = routine_20(c, &(v162_6), &v146_20_cursor);
              compose(&(v161_5),&(v162_7))
            };
            drop(v161_5);
            let v161_9: Space = intersect(&(*CONSTANT_1),&(v161_2));
            drop(v161_2);
            let v161_10: Space = if has_head(&(v161_9)) { singleton(&[]) } else { Space::new() };
            drop(v161_9);
            let v161_12: Space = if (&(v161_10)).is_empty() { Space::new() } else {
              let v163_6: Path = concat_path(&(v160_6),&v146_20_cursor.path()[(v146_20_origin + 2)..(v146_20_origin + 3)]);
              let v163_11: Space = routine_21(c, &(v163_6), &v146_20_cursor);
              drop(v163_6);
              compose(&(v161_10),&(v163_11))
            };
            drop(v161_10);
            let v161_13: Space = unite(&(v161_8),&(v161_12));
            join_wrapped_into(&mut v160_7_write,&((v161_13).read_zipper()),&[]);
            }
            v146_20_cursor.ascend(1);
          }
          drop(v160_7_write);
          drop(v160_6);
          compose(&(v159_5),&(v160_7))
        };
        drop(v159_5);
        let v159_9: Space = intersect(&(*CONSTANT_1),&(v159_2));
        drop(v159_2);
        let v159_10: Space = if has_head(&(v159_9)) { singleton(&[]) } else { Space::new() };
        drop(v159_9);
        let v159_11: Space = compose(&(v159_10),&v146_20_cursor);
        drop(v159_10);
        let v159_12: Space = unite(&(v159_8),&(v159_11));
        drop(v159_11);
        join_wrapped_into(&mut v158_11_write,&((v159_12).read_zipper()),&[]);
        }
        v146_20_cursor.ascend(1);
      }
      drop(v158_11_write);
      drop(v158_6);
      compose(&(v147_10),&(v158_11))
    };
    drop(v147_10);
    let v147_13: Space = unite(&(v147_8),&(v147_12));
    join_wrapped_into(&mut v146_20_write,&((v147_13).read_zipper()),&[]);
    }
    v146_20_cursor.ascend(1);
  }
  drop(v146_20_cursor);
  drop(v146_20_write);
  (v146_20).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v164_14 = Space::new();
  let mut v164_14_write = v164_14.write_zipper();
  let mut v164_14_cursor = (*s0).read_zipper();
  let v164_14_origin = v164_14_cursor.path().len();
  for v164_14_byte in v164_14_cursor.child_mask().iter() {
    v164_14_cursor.descend_to_existing_byte(v164_14_byte);
    {
    let v165_2: Space = singleton(&v164_14_cursor.path()[v164_14_origin..(v164_14_origin + 1)]);
    let v165_3: Space = intersect(&(*CONSTANT_1),&(v165_2));
    let v165_4: Space = if has_head(&(v165_3)) { singleton(&[]) } else { Space::new() };
    drop(v165_3);
    let v165_5: Space = subtract(&(*CONSTANT_0),&(v165_4));
    drop(v165_4);
    let v165_8: Space = if (&(v165_5)).is_empty() { Space::new() } else {
      let v166_6: Path = concat_path(&(*p0),&v164_14_cursor.path()[v164_14_origin..(v164_14_origin + 1)]);
      let mut v166_7 = Space::new();
      let mut v166_7_write = v166_7.write_zipper();
      for v166_7_byte in v164_14_cursor.child_mask().iter() {
        v164_14_cursor.descend_to_existing_byte(v166_7_byte);
        {
        let v167_2: Space = singleton(&v164_14_cursor.path()[(v164_14_origin + 1)..(v164_14_origin + 2)]);
        let v167_3: Space = intersect(&(*CONSTANT_1),&(v167_2));
        let v167_4: Space = if has_head(&(v167_3)) { singleton(&[]) } else { Space::new() };
        drop(v167_3);
        let v167_5: Space = subtract(&(*CONSTANT_0),&(v167_4));
        drop(v167_4);
        let v167_8: Space = if (&(v167_5)).is_empty() { Space::new() } else {
          let v168_6: Path = concat_path(&(v166_6),&v164_14_cursor.path()[(v164_14_origin + 1)..(v164_14_origin + 2)]);
          let mut v168_7 = Space::new();
          let mut v168_7_write = v168_7.write_zipper();
          for v168_7_byte in v164_14_cursor.child_mask().iter() {
            v164_14_cursor.descend_to_existing_byte(v168_7_byte);
            {
            let v169_2: Space = singleton(&v164_14_cursor.path()[(v164_14_origin + 2)..(v164_14_origin + 3)]);
            let v169_3: Space = intersect(&(*CONSTANT_1),&(v169_2));
            let v169_4: Space = if has_head(&(v169_3)) { singleton(&[]) } else { Space::new() };
            drop(v169_3);
            let v169_5: Space = subtract(&(*CONSTANT_0),&(v169_4));
            drop(v169_4);
            let v169_8: Space = if (&(v169_5)).is_empty() { Space::new() } else {
              let v170_6: Path = concat_path(&(v168_6),&v164_14_cursor.path()[(v164_14_origin + 2)..(v164_14_origin + 3)]);
              let v170_7: Space = routine_20(c, &(v170_6), &v164_14_cursor);
              compose(&(v169_5),&(v170_7))
            };
            drop(v169_5);
            let v169_9: Space = intersect(&(*CONSTANT_1),&(v169_2));
            drop(v169_2);
            let v169_10: Space = if has_head(&(v169_9)) { singleton(&[]) } else { Space::new() };
            drop(v169_9);
            let v169_12: Space = if (&(v169_10)).is_empty() { Space::new() } else {
              let v171_6: Path = concat_path(&(v168_6),&v164_14_cursor.path()[(v164_14_origin + 2)..(v164_14_origin + 3)]);
              let v171_11: Space = routine_21(c, &(v171_6), &v164_14_cursor);
              drop(v171_6);
              compose(&(v169_10),&(v171_11))
            };
            drop(v169_10);
            let v169_13: Space = unite(&(v169_8),&(v169_12));
            join_wrapped_into(&mut v168_7_write,&((v169_13).read_zipper()),&[]);
            }
            v164_14_cursor.ascend(1);
          }
          drop(v168_7_write);
          compose(&(v167_5),&(v168_7))
        };
        drop(v167_5);
        let v167_9: Space = intersect(&(*CONSTANT_1),&(v167_2));
        drop(v167_2);
        let v167_10: Space = if has_head(&(v167_9)) { singleton(&[]) } else { Space::new() };
        drop(v167_9);
        let v167_12: Space = if (&(v167_10)).is_empty() { Space::new() } else {
          let v172_6: Path = concat_path(&(v166_6),&v164_14_cursor.path()[(v164_14_origin + 1)..(v164_14_origin + 2)]);
          let mut v172_11 = Space::new();
          let mut v172_11_write = v172_11.write_zipper();
          for v172_11_byte in v164_14_cursor.child_mask().iter() {
            v164_14_cursor.descend_to_existing_byte(v172_11_byte);
            {
            let v173_2: Space = singleton(&v164_14_cursor.path()[(v164_14_origin + 2)..(v164_14_origin + 3)]);
            let v173_3: Space = intersect(&(*CONSTANT_1),&(v173_2));
            let v173_4: Space = if has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
            drop(v173_3);
            let v173_5: Space = subtract(&(*CONSTANT_0),&(v173_4));
            drop(v173_4);
            let v173_8: Space = if (&(v173_5)).is_empty() { Space::new() } else {
              let v174_6: Path = concat_path(&(v172_6),&v164_14_cursor.path()[(v164_14_origin + 2)..(v164_14_origin + 3)]);
              let v174_7: Space = routine_20(c, &(v174_6), &v164_14_cursor);
              compose(&(v173_5),&(v174_7))
            };
            drop(v173_5);
            let v173_9: Space = intersect(&(*CONSTANT_1),&(v173_2));
            drop(v173_2);
            let v173_10: Space = if has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
            drop(v173_9);
            let v173_12: Space = if (&(v173_10)).is_empty() { Space::new() } else {
              let v175_6: Path = concat_path(&(v172_6),&v164_14_cursor.path()[(v164_14_origin + 2)..(v164_14_origin + 3)]);
              let v175_11: Space = routine_12(c, &(v175_6), &v164_14_cursor);
              drop(v175_6);
              compose(&(v173_10),&(v175_11))
            };
            drop(v173_10);
            let v173_13: Space = unite(&(v173_8),&(v173_12));
            join_wrapped_into(&mut v172_11_write,&((v173_13).read_zipper()),&[]);
            }
            v164_14_cursor.ascend(1);
          }
          drop(v172_11_write);
          drop(v172_6);
          compose(&(v167_10),&(v172_11))
        };
        drop(v167_10);
        let v167_13: Space = unite(&(v167_8),&(v167_12));
        join_wrapped_into(&mut v166_7_write,&((v167_13).read_zipper()),&[]);
        }
        v164_14_cursor.ascend(1);
      }
      drop(v166_7_write);
      drop(v166_6);
      compose(&(v165_5),&(v166_7))
    };
    drop(v165_5);
    let v165_9: Space = intersect(&(*CONSTANT_1),&(v165_2));
    drop(v165_2);
    let v165_10: Space = if has_head(&(v165_9)) { singleton(&[]) } else { Space::new() };
    drop(v165_9);
    let v165_11: Space = compose(&(v165_10),&v164_14_cursor);
    drop(v165_10);
    let v165_12: Space = unite(&(v165_8),&(v165_11));
    drop(v165_11);
    join_wrapped_into(&mut v164_14_write,&((v165_12).read_zipper()),&[]);
    }
    v164_14_cursor.ascend(1);
  }
  drop(v164_14_cursor);
  drop(v164_14_write);
  (v164_14).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v176_20 = Space::new();
  let mut v176_20_write = v176_20.write_zipper();
  let mut v176_20_cursor = (*s0).read_zipper();
  let v176_20_origin = v176_20_cursor.path().len();
  for v176_20_byte in v176_20_cursor.child_mask().iter() {
    v176_20_cursor.descend_to_existing_byte(v176_20_byte);
    {
    let v177_2: Space = singleton(&v176_20_cursor.path()[v176_20_origin..(v176_20_origin + 1)]);
    let v177_3: Space = intersect(&(*CONSTANT_1),&(v177_2));
    let v177_4: Space = if has_head(&(v177_3)) { singleton(&[]) } else { Space::new() };
    drop(v177_3);
    let v177_5: Space = subtract(&(*CONSTANT_0),&(v177_4));
    drop(v177_4);
    let v177_8: Space = if (&(v177_5)).is_empty() { Space::new() } else {
      let v178_6: Path = concat_path(&(*p0),&v176_20_cursor.path()[v176_20_origin..(v176_20_origin + 1)]);
      let mut v178_7 = Space::new();
      let mut v178_7_write = v178_7.write_zipper();
      for v178_7_byte in v176_20_cursor.child_mask().iter() {
        v176_20_cursor.descend_to_existing_byte(v178_7_byte);
        {
        let v179_2: Space = singleton(&v176_20_cursor.path()[(v176_20_origin + 1)..(v176_20_origin + 2)]);
        let v179_3: Space = intersect(&(*CONSTANT_1),&(v179_2));
        let v179_4: Space = if has_head(&(v179_3)) { singleton(&[]) } else { Space::new() };
        drop(v179_3);
        let v179_5: Space = subtract(&(*CONSTANT_0),&(v179_4));
        drop(v179_4);
        let v179_8: Space = if (&(v179_5)).is_empty() { Space::new() } else {
          let v180_6: Path = concat_path(&(v178_6),&v176_20_cursor.path()[(v176_20_origin + 1)..(v176_20_origin + 2)]);
          let mut v180_7 = Space::new();
          let mut v180_7_write = v180_7.write_zipper();
          for v180_7_byte in v176_20_cursor.child_mask().iter() {
            v176_20_cursor.descend_to_existing_byte(v180_7_byte);
            {
            let v181_2: Space = singleton(&v176_20_cursor.path()[(v176_20_origin + 2)..(v176_20_origin + 3)]);
            let v181_3: Space = intersect(&(*CONSTANT_1),&(v181_2));
            let v181_4: Space = if has_head(&(v181_3)) { singleton(&[]) } else { Space::new() };
            drop(v181_3);
            let v181_5: Space = subtract(&(*CONSTANT_0),&(v181_4));
            drop(v181_4);
            let v181_8: Space = if (&(v181_5)).is_empty() { Space::new() } else {
              let v182_6: Path = concat_path(&(v180_6),&v176_20_cursor.path()[(v176_20_origin + 2)..(v176_20_origin + 3)]);
              let v182_7: Space = routine_22(c, &(v182_6), &v176_20_cursor);
              compose(&(v181_5),&(v182_7))
            };
            drop(v181_5);
            let v181_9: Space = intersect(&(*CONSTANT_1),&(v181_2));
            drop(v181_2);
            let v181_10: Space = if has_head(&(v181_9)) { singleton(&[]) } else { Space::new() };
            drop(v181_9);
            let v181_12: Space = if (&(v181_10)).is_empty() { Space::new() } else {
              let v183_6: Path = concat_path(&(v180_6),&v176_20_cursor.path()[(v176_20_origin + 2)..(v176_20_origin + 3)]);
              let v183_11: Space = routine_23(c, &(v183_6), &v176_20_cursor);
              drop(v183_6);
              compose(&(v181_10),&(v183_11))
            };
            drop(v181_10);
            let v181_13: Space = unite(&(v181_8),&(v181_12));
            join_wrapped_into(&mut v180_7_write,&((v181_13).read_zipper()),&[]);
            }
            v176_20_cursor.ascend(1);
          }
          drop(v180_7_write);
          compose(&(v179_5),&(v180_7))
        };
        drop(v179_5);
        let v179_9: Space = intersect(&(*CONSTANT_1),&(v179_2));
        drop(v179_2);
        let v179_10: Space = if has_head(&(v179_9)) { singleton(&[]) } else { Space::new() };
        drop(v179_9);
        let v179_12: Space = if (&(v179_10)).is_empty() { Space::new() } else {
          let v184_6: Path = concat_path(&(v178_6),&v176_20_cursor.path()[(v176_20_origin + 1)..(v176_20_origin + 2)]);
          let mut v184_11 = Space::new();
          let mut v184_11_write = v184_11.write_zipper();
          for v184_11_byte in v176_20_cursor.child_mask().iter() {
            v176_20_cursor.descend_to_existing_byte(v184_11_byte);
            {
            let v185_2: Space = singleton(&v176_20_cursor.path()[(v176_20_origin + 2)..(v176_20_origin + 3)]);
            let v185_3: Space = intersect(&(*CONSTANT_1),&(v185_2));
            let v185_4: Space = if has_head(&(v185_3)) { singleton(&[]) } else { Space::new() };
            drop(v185_3);
            let v185_5: Space = subtract(&(*CONSTANT_0),&(v185_4));
            drop(v185_4);
            let v185_8: Space = if (&(v185_5)).is_empty() { Space::new() } else {
              let v186_6: Path = concat_path(&(v184_6),&v176_20_cursor.path()[(v176_20_origin + 2)..(v176_20_origin + 3)]);
              let v186_7: Space = routine_22(c, &(v186_6), &v176_20_cursor);
              compose(&(v185_5),&(v186_7))
            };
            drop(v185_5);
            let v185_9: Space = intersect(&(*CONSTANT_1),&(v185_2));
            drop(v185_2);
            let v185_10: Space = if has_head(&(v185_9)) { singleton(&[]) } else { Space::new() };
            drop(v185_9);
            let v185_12: Space = if (&(v185_10)).is_empty() { Space::new() } else {
              let v187_6: Path = concat_path(&(v184_6),&v176_20_cursor.path()[(v176_20_origin + 2)..(v176_20_origin + 3)]);
              let v187_11: Space = routine_15(c, &(v187_6), &v176_20_cursor);
              drop(v187_6);
              compose(&(v185_10),&(v187_11))
            };
            drop(v185_10);
            let v185_13: Space = unite(&(v185_8),&(v185_12));
            join_wrapped_into(&mut v184_11_write,&((v185_13).read_zipper()),&[]);
            }
            v176_20_cursor.ascend(1);
          }
          drop(v184_11_write);
          drop(v184_6);
          compose(&(v179_10),&(v184_11))
        };
        drop(v179_10);
        let v179_13: Space = unite(&(v179_8),&(v179_12));
        join_wrapped_into(&mut v178_7_write,&((v179_13).read_zipper()),&[]);
        }
        v176_20_cursor.ascend(1);
      }
      drop(v178_7_write);
      compose(&(v177_5),&(v178_7))
    };
    drop(v177_5);
    let v177_9: Space = intersect(&(*CONSTANT_1),&(v177_2));
    drop(v177_2);
    let v177_10: Space = if has_head(&(v177_9)) { singleton(&[]) } else { Space::new() };
    drop(v177_9);
    let v177_12: Space = if (&(v177_10)).is_empty() { Space::new() } else {
      let v188_6: Path = concat_path(&(*p0),&v176_20_cursor.path()[v176_20_origin..(v176_20_origin + 1)]);
      let mut v188_11 = Space::new();
      let mut v188_11_write = v188_11.write_zipper();
      for v188_11_byte in v176_20_cursor.child_mask().iter() {
        v176_20_cursor.descend_to_existing_byte(v188_11_byte);
        {
        let v189_2: Space = singleton(&v176_20_cursor.path()[(v176_20_origin + 1)..(v176_20_origin + 2)]);
        let v189_3: Space = intersect(&(*CONSTANT_1),&(v189_2));
        let v189_4: Space = if has_head(&(v189_3)) { singleton(&[]) } else { Space::new() };
        drop(v189_3);
        let v189_5: Space = subtract(&(*CONSTANT_0),&(v189_4));
        drop(v189_4);
        let v189_8: Space = if (&(v189_5)).is_empty() { Space::new() } else {
          let v190_6: Path = concat_path(&(v188_6),&v176_20_cursor.path()[(v176_20_origin + 1)..(v176_20_origin + 2)]);
          let mut v190_7 = Space::new();
          let mut v190_7_write = v190_7.write_zipper();
          for v190_7_byte in v176_20_cursor.child_mask().iter() {
            v176_20_cursor.descend_to_existing_byte(v190_7_byte);
            {
            let v191_2: Space = singleton(&v176_20_cursor.path()[(v176_20_origin + 2)..(v176_20_origin + 3)]);
            let v191_3: Space = intersect(&(*CONSTANT_1),&(v191_2));
            let v191_4: Space = if has_head(&(v191_3)) { singleton(&[]) } else { Space::new() };
            drop(v191_3);
            let v191_5: Space = subtract(&(*CONSTANT_0),&(v191_4));
            drop(v191_4);
            let v191_8: Space = if (&(v191_5)).is_empty() { Space::new() } else {
              let v192_6: Path = concat_path(&(v190_6),&v176_20_cursor.path()[(v176_20_origin + 2)..(v176_20_origin + 3)]);
              let v192_7: Space = routine_22(c, &(v192_6), &v176_20_cursor);
              compose(&(v191_5),&(v192_7))
            };
            drop(v191_5);
            let v191_9: Space = intersect(&(*CONSTANT_1),&(v191_2));
            drop(v191_2);
            let v191_10: Space = if has_head(&(v191_9)) { singleton(&[]) } else { Space::new() };
            drop(v191_9);
            let v191_12: Space = if (&(v191_10)).is_empty() { Space::new() } else {
              let v193_6: Path = concat_path(&(v190_6),&v176_20_cursor.path()[(v176_20_origin + 2)..(v176_20_origin + 3)]);
              let v193_11: Space = routine_23(c, &(v193_6), &v176_20_cursor);
              drop(v193_6);
              compose(&(v191_10),&(v193_11))
            };
            drop(v191_10);
            let v191_13: Space = unite(&(v191_8),&(v191_12));
            join_wrapped_into(&mut v190_7_write,&((v191_13).read_zipper()),&[]);
            }
            v176_20_cursor.ascend(1);
          }
          drop(v190_7_write);
          drop(v190_6);
          compose(&(v189_5),&(v190_7))
        };
        drop(v189_5);
        let v189_9: Space = intersect(&(*CONSTANT_1),&(v189_2));
        drop(v189_2);
        let v189_10: Space = if has_head(&(v189_9)) { singleton(&[]) } else { Space::new() };
        drop(v189_9);
        let v189_11: Space = compose(&(v189_10),&v176_20_cursor);
        drop(v189_10);
        let v189_12: Space = unite(&(v189_8),&(v189_11));
        drop(v189_11);
        join_wrapped_into(&mut v188_11_write,&((v189_12).read_zipper()),&[]);
        }
        v176_20_cursor.ascend(1);
      }
      drop(v188_11_write);
      drop(v188_6);
      compose(&(v177_10),&(v188_11))
    };
    drop(v177_10);
    let v177_13: Space = unite(&(v177_8),&(v177_12));
    join_wrapped_into(&mut v176_20_write,&((v177_13).read_zipper()),&[]);
    }
    v176_20_cursor.ascend(1);
  }
  drop(v176_20_cursor);
  drop(v176_20_write);
  (v176_20).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v194_14 = Space::new();
  let mut v194_14_write = v194_14.write_zipper();
  let mut v194_14_cursor = (*s0).read_zipper();
  let v194_14_origin = v194_14_cursor.path().len();
  for v194_14_byte in v194_14_cursor.child_mask().iter() {
    v194_14_cursor.descend_to_existing_byte(v194_14_byte);
    {
    let v195_2: Space = singleton(&v194_14_cursor.path()[v194_14_origin..(v194_14_origin + 1)]);
    let v195_3: Space = intersect(&(*CONSTANT_1),&(v195_2));
    let v195_4: Space = if has_head(&(v195_3)) { singleton(&[]) } else { Space::new() };
    drop(v195_3);
    let v195_5: Space = subtract(&(*CONSTANT_0),&(v195_4));
    drop(v195_4);
    let v195_8: Space = if (&(v195_5)).is_empty() { Space::new() } else {
      let v196_6: Path = concat_path(&(*p0),&v194_14_cursor.path()[v194_14_origin..(v194_14_origin + 1)]);
      let mut v196_7 = Space::new();
      let mut v196_7_write = v196_7.write_zipper();
      for v196_7_byte in v194_14_cursor.child_mask().iter() {
        v194_14_cursor.descend_to_existing_byte(v196_7_byte);
        {
        let v197_2: Space = singleton(&v194_14_cursor.path()[(v194_14_origin + 1)..(v194_14_origin + 2)]);
        let v197_3: Space = intersect(&(*CONSTANT_1),&(v197_2));
        let v197_4: Space = if has_head(&(v197_3)) { singleton(&[]) } else { Space::new() };
        drop(v197_3);
        let v197_5: Space = subtract(&(*CONSTANT_0),&(v197_4));
        drop(v197_4);
        let v197_8: Space = if (&(v197_5)).is_empty() { Space::new() } else {
          let v198_6: Path = concat_path(&(v196_6),&v194_14_cursor.path()[(v194_14_origin + 1)..(v194_14_origin + 2)]);
          let mut v198_7 = Space::new();
          let mut v198_7_write = v198_7.write_zipper();
          for v198_7_byte in v194_14_cursor.child_mask().iter() {
            v194_14_cursor.descend_to_existing_byte(v198_7_byte);
            {
            let v199_2: Space = singleton(&v194_14_cursor.path()[(v194_14_origin + 2)..(v194_14_origin + 3)]);
            let v199_3: Space = intersect(&(*CONSTANT_1),&(v199_2));
            let v199_4: Space = if has_head(&(v199_3)) { singleton(&[]) } else { Space::new() };
            drop(v199_3);
            let v199_5: Space = subtract(&(*CONSTANT_0),&(v199_4));
            drop(v199_4);
            let v199_8: Space = if (&(v199_5)).is_empty() { Space::new() } else {
              let v200_6: Path = concat_path(&(v198_6),&v194_14_cursor.path()[(v194_14_origin + 2)..(v194_14_origin + 3)]);
              let v200_7: Space = routine_22(c, &(v200_6), &v194_14_cursor);
              compose(&(v199_5),&(v200_7))
            };
            drop(v199_5);
            let v199_9: Space = intersect(&(*CONSTANT_1),&(v199_2));
            drop(v199_2);
            let v199_10: Space = if has_head(&(v199_9)) { singleton(&[]) } else { Space::new() };
            drop(v199_9);
            let v199_12: Space = if (&(v199_10)).is_empty() { Space::new() } else {
              let v201_6: Path = concat_path(&(v198_6),&v194_14_cursor.path()[(v194_14_origin + 2)..(v194_14_origin + 3)]);
              let v201_11: Space = routine_23(c, &(v201_6), &v194_14_cursor);
              drop(v201_6);
              compose(&(v199_10),&(v201_11))
            };
            drop(v199_10);
            let v199_13: Space = unite(&(v199_8),&(v199_12));
            join_wrapped_into(&mut v198_7_write,&((v199_13).read_zipper()),&[]);
            }
            v194_14_cursor.ascend(1);
          }
          drop(v198_7_write);
          compose(&(v197_5),&(v198_7))
        };
        drop(v197_5);
        let v197_9: Space = intersect(&(*CONSTANT_1),&(v197_2));
        drop(v197_2);
        let v197_10: Space = if has_head(&(v197_9)) { singleton(&[]) } else { Space::new() };
        drop(v197_9);
        let v197_12: Space = if (&(v197_10)).is_empty() { Space::new() } else {
          let v202_6: Path = concat_path(&(v196_6),&v194_14_cursor.path()[(v194_14_origin + 1)..(v194_14_origin + 2)]);
          let mut v202_11 = Space::new();
          let mut v202_11_write = v202_11.write_zipper();
          for v202_11_byte in v194_14_cursor.child_mask().iter() {
            v194_14_cursor.descend_to_existing_byte(v202_11_byte);
            {
            let v203_2: Space = singleton(&v194_14_cursor.path()[(v194_14_origin + 2)..(v194_14_origin + 3)]);
            let v203_3: Space = intersect(&(*CONSTANT_1),&(v203_2));
            let v203_4: Space = if has_head(&(v203_3)) { singleton(&[]) } else { Space::new() };
            drop(v203_3);
            let v203_5: Space = subtract(&(*CONSTANT_0),&(v203_4));
            drop(v203_4);
            let v203_8: Space = if (&(v203_5)).is_empty() { Space::new() } else {
              let v204_6: Path = concat_path(&(v202_6),&v194_14_cursor.path()[(v194_14_origin + 2)..(v194_14_origin + 3)]);
              let v204_7: Space = routine_22(c, &(v204_6), &v194_14_cursor);
              compose(&(v203_5),&(v204_7))
            };
            drop(v203_5);
            let v203_9: Space = intersect(&(*CONSTANT_1),&(v203_2));
            drop(v203_2);
            let v203_10: Space = if has_head(&(v203_9)) { singleton(&[]) } else { Space::new() };
            drop(v203_9);
            let v203_12: Space = if (&(v203_10)).is_empty() { Space::new() } else {
              let v205_6: Path = concat_path(&(v202_6),&v194_14_cursor.path()[(v194_14_origin + 2)..(v194_14_origin + 3)]);
              let v205_11: Space = routine_15(c, &(v205_6), &v194_14_cursor);
              drop(v205_6);
              compose(&(v203_10),&(v205_11))
            };
            drop(v203_10);
            let v203_13: Space = unite(&(v203_8),&(v203_12));
            join_wrapped_into(&mut v202_11_write,&((v203_13).read_zipper()),&[]);
            }
            v194_14_cursor.ascend(1);
          }
          drop(v202_11_write);
          drop(v202_6);
          compose(&(v197_10),&(v202_11))
        };
        drop(v197_10);
        let v197_13: Space = unite(&(v197_8),&(v197_12));
        join_wrapped_into(&mut v196_7_write,&((v197_13).read_zipper()),&[]);
        }
        v194_14_cursor.ascend(1);
      }
      drop(v196_7_write);
      drop(v196_6);
      compose(&(v195_5),&(v196_7))
    };
    drop(v195_5);
    let v195_9: Space = intersect(&(*CONSTANT_1),&(v195_2));
    drop(v195_2);
    let v195_10: Space = if has_head(&(v195_9)) { singleton(&[]) } else { Space::new() };
    drop(v195_9);
    let v195_11: Space = compose(&(v195_10),&v194_14_cursor);
    drop(v195_10);
    let v195_12: Space = unite(&(v195_8),&(v195_11));
    drop(v195_11);
    join_wrapped_into(&mut v194_14_write,&((v195_12).read_zipper()),&[]);
    }
    v194_14_cursor.ascend(1);
  }
  drop(v194_14_cursor);
  drop(v194_14_write);
  (v194_14).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v206_20 = Space::new();
  let mut v206_20_write = v206_20.write_zipper();
  let mut v206_20_cursor = (*s0).read_zipper();
  let v206_20_origin = v206_20_cursor.path().len();
  for v206_20_byte in v206_20_cursor.child_mask().iter() {
    v206_20_cursor.descend_to_existing_byte(v206_20_byte);
    {
    let v207_2: Space = singleton(&v206_20_cursor.path()[v206_20_origin..(v206_20_origin + 1)]);
    let v207_3: Space = intersect(&(*CONSTANT_1),&(v207_2));
    let v207_4: Space = if has_head(&(v207_3)) { singleton(&[]) } else { Space::new() };
    drop(v207_3);
    let v207_5: Space = subtract(&(*CONSTANT_0),&(v207_4));
    drop(v207_4);
    let v207_8: Space = if (&(v207_5)).is_empty() { Space::new() } else {
      let v208_6: Path = concat_path(&(*p0),&v206_20_cursor.path()[v206_20_origin..(v206_20_origin + 1)]);
      let mut v208_7 = Space::new();
      let mut v208_7_write = v208_7.write_zipper();
      for v208_7_byte in v206_20_cursor.child_mask().iter() {
        v206_20_cursor.descend_to_existing_byte(v208_7_byte);
        {
        let v209_2: Space = singleton(&v206_20_cursor.path()[(v206_20_origin + 1)..(v206_20_origin + 2)]);
        let v209_3: Space = intersect(&(*CONSTANT_1),&(v209_2));
        let v209_4: Space = if has_head(&(v209_3)) { singleton(&[]) } else { Space::new() };
        drop(v209_3);
        let v209_5: Space = subtract(&(*CONSTANT_0),&(v209_4));
        drop(v209_4);
        let v209_8: Space = if (&(v209_5)).is_empty() { Space::new() } else {
          let v210_6: Path = concat_path(&(v208_6),&v206_20_cursor.path()[(v206_20_origin + 1)..(v206_20_origin + 2)]);
          let mut v210_7 = Space::new();
          let mut v210_7_write = v210_7.write_zipper();
          for v210_7_byte in v206_20_cursor.child_mask().iter() {
            v206_20_cursor.descend_to_existing_byte(v210_7_byte);
            {
            let v211_2: Space = singleton(&v206_20_cursor.path()[(v206_20_origin + 2)..(v206_20_origin + 3)]);
            let v211_3: Space = intersect(&(*CONSTANT_1),&(v211_2));
            let v211_4: Space = if has_head(&(v211_3)) { singleton(&[]) } else { Space::new() };
            drop(v211_3);
            let v211_5: Space = subtract(&(*CONSTANT_0),&(v211_4));
            drop(v211_4);
            let v211_8: Space = if (&(v211_5)).is_empty() { Space::new() } else {
              let v212_6: Path = concat_path(&(v210_6),&v206_20_cursor.path()[(v206_20_origin + 2)..(v206_20_origin + 3)]);
              let v212_7: Space = routine_24(c, &(v212_6), &v206_20_cursor);
              compose(&(v211_5),&(v212_7))
            };
            drop(v211_5);
            let v211_9: Space = intersect(&(*CONSTANT_1),&(v211_2));
            drop(v211_2);
            let v211_10: Space = if has_head(&(v211_9)) { singleton(&[]) } else { Space::new() };
            drop(v211_9);
            let v211_12: Space = if (&(v211_10)).is_empty() { Space::new() } else {
              let v213_6: Path = concat_path(&(v210_6),&v206_20_cursor.path()[(v206_20_origin + 2)..(v206_20_origin + 3)]);
              let v213_11: Space = routine_25(c, &(v213_6), &v206_20_cursor);
              drop(v213_6);
              compose(&(v211_10),&(v213_11))
            };
            drop(v211_10);
            let v211_13: Space = unite(&(v211_8),&(v211_12));
            join_wrapped_into(&mut v210_7_write,&((v211_13).read_zipper()),&[]);
            }
            v206_20_cursor.ascend(1);
          }
          drop(v210_7_write);
          compose(&(v209_5),&(v210_7))
        };
        drop(v209_5);
        let v209_9: Space = intersect(&(*CONSTANT_1),&(v209_2));
        drop(v209_2);
        let v209_10: Space = if has_head(&(v209_9)) { singleton(&[]) } else { Space::new() };
        drop(v209_9);
        let v209_12: Space = if (&(v209_10)).is_empty() { Space::new() } else {
          let v214_6: Path = concat_path(&(v208_6),&v206_20_cursor.path()[(v206_20_origin + 1)..(v206_20_origin + 2)]);
          let mut v214_11 = Space::new();
          let mut v214_11_write = v214_11.write_zipper();
          for v214_11_byte in v206_20_cursor.child_mask().iter() {
            v206_20_cursor.descend_to_existing_byte(v214_11_byte);
            {
            let v215_2: Space = singleton(&v206_20_cursor.path()[(v206_20_origin + 2)..(v206_20_origin + 3)]);
            let v215_3: Space = intersect(&(*CONSTANT_1),&(v215_2));
            let v215_4: Space = if has_head(&(v215_3)) { singleton(&[]) } else { Space::new() };
            drop(v215_3);
            let v215_5: Space = subtract(&(*CONSTANT_0),&(v215_4));
            drop(v215_4);
            let v215_8: Space = if (&(v215_5)).is_empty() { Space::new() } else {
              let v216_6: Path = concat_path(&(v214_6),&v206_20_cursor.path()[(v206_20_origin + 2)..(v206_20_origin + 3)]);
              let v216_7: Space = routine_24(c, &(v216_6), &v206_20_cursor);
              compose(&(v215_5),&(v216_7))
            };
            drop(v215_5);
            let v215_9: Space = intersect(&(*CONSTANT_1),&(v215_2));
            drop(v215_2);
            let v215_10: Space = if has_head(&(v215_9)) { singleton(&[]) } else { Space::new() };
            drop(v215_9);
            let v215_12: Space = if (&(v215_10)).is_empty() { Space::new() } else {
              let v217_6: Path = concat_path(&(v214_6),&v206_20_cursor.path()[(v206_20_origin + 2)..(v206_20_origin + 3)]);
              let v217_11: Space = routine_12(c, &(v217_6), &v206_20_cursor);
              drop(v217_6);
              compose(&(v215_10),&(v217_11))
            };
            drop(v215_10);
            let v215_13: Space = unite(&(v215_8),&(v215_12));
            join_wrapped_into(&mut v214_11_write,&((v215_13).read_zipper()),&[]);
            }
            v206_20_cursor.ascend(1);
          }
          drop(v214_11_write);
          drop(v214_6);
          compose(&(v209_10),&(v214_11))
        };
        drop(v209_10);
        let v209_13: Space = unite(&(v209_8),&(v209_12));
        join_wrapped_into(&mut v208_7_write,&((v209_13).read_zipper()),&[]);
        }
        v206_20_cursor.ascend(1);
      }
      drop(v208_7_write);
      compose(&(v207_5),&(v208_7))
    };
    drop(v207_5);
    let v207_9: Space = intersect(&(*CONSTANT_1),&(v207_2));
    drop(v207_2);
    let v207_10: Space = if has_head(&(v207_9)) { singleton(&[]) } else { Space::new() };
    drop(v207_9);
    let v207_12: Space = if (&(v207_10)).is_empty() { Space::new() } else {
      let v218_6: Path = concat_path(&(*p0),&v206_20_cursor.path()[v206_20_origin..(v206_20_origin + 1)]);
      let mut v218_11 = Space::new();
      let mut v218_11_write = v218_11.write_zipper();
      for v218_11_byte in v206_20_cursor.child_mask().iter() {
        v206_20_cursor.descend_to_existing_byte(v218_11_byte);
        {
        let v219_2: Space = singleton(&v206_20_cursor.path()[(v206_20_origin + 1)..(v206_20_origin + 2)]);
        let v219_3: Space = intersect(&(*CONSTANT_1),&(v219_2));
        let v219_4: Space = if has_head(&(v219_3)) { singleton(&[]) } else { Space::new() };
        drop(v219_3);
        let v219_5: Space = subtract(&(*CONSTANT_0),&(v219_4));
        drop(v219_4);
        let v219_8: Space = if (&(v219_5)).is_empty() { Space::new() } else {
          let v220_6: Path = concat_path(&(v218_6),&v206_20_cursor.path()[(v206_20_origin + 1)..(v206_20_origin + 2)]);
          let mut v220_7 = Space::new();
          let mut v220_7_write = v220_7.write_zipper();
          for v220_7_byte in v206_20_cursor.child_mask().iter() {
            v206_20_cursor.descend_to_existing_byte(v220_7_byte);
            {
            let v221_2: Space = singleton(&v206_20_cursor.path()[(v206_20_origin + 2)..(v206_20_origin + 3)]);
            let v221_3: Space = intersect(&(*CONSTANT_1),&(v221_2));
            let v221_4: Space = if has_head(&(v221_3)) { singleton(&[]) } else { Space::new() };
            drop(v221_3);
            let v221_5: Space = subtract(&(*CONSTANT_0),&(v221_4));
            drop(v221_4);
            let v221_8: Space = if (&(v221_5)).is_empty() { Space::new() } else {
              let v222_6: Path = concat_path(&(v220_6),&v206_20_cursor.path()[(v206_20_origin + 2)..(v206_20_origin + 3)]);
              let v222_7: Space = routine_24(c, &(v222_6), &v206_20_cursor);
              compose(&(v221_5),&(v222_7))
            };
            drop(v221_5);
            let v221_9: Space = intersect(&(*CONSTANT_1),&(v221_2));
            drop(v221_2);
            let v221_10: Space = if has_head(&(v221_9)) { singleton(&[]) } else { Space::new() };
            drop(v221_9);
            let v221_12: Space = if (&(v221_10)).is_empty() { Space::new() } else {
              let v223_6: Path = concat_path(&(v220_6),&v206_20_cursor.path()[(v206_20_origin + 2)..(v206_20_origin + 3)]);
              let v223_11: Space = routine_25(c, &(v223_6), &v206_20_cursor);
              drop(v223_6);
              compose(&(v221_10),&(v223_11))
            };
            drop(v221_10);
            let v221_13: Space = unite(&(v221_8),&(v221_12));
            join_wrapped_into(&mut v220_7_write,&((v221_13).read_zipper()),&[]);
            }
            v206_20_cursor.ascend(1);
          }
          drop(v220_7_write);
          drop(v220_6);
          compose(&(v219_5),&(v220_7))
        };
        drop(v219_5);
        let v219_9: Space = intersect(&(*CONSTANT_1),&(v219_2));
        drop(v219_2);
        let v219_10: Space = if has_head(&(v219_9)) { singleton(&[]) } else { Space::new() };
        drop(v219_9);
        let v219_11: Space = compose(&(v219_10),&v206_20_cursor);
        drop(v219_10);
        let v219_12: Space = unite(&(v219_8),&(v219_11));
        drop(v219_11);
        join_wrapped_into(&mut v218_11_write,&((v219_12).read_zipper()),&[]);
        }
        v206_20_cursor.ascend(1);
      }
      drop(v218_11_write);
      drop(v218_6);
      compose(&(v207_10),&(v218_11))
    };
    drop(v207_10);
    let v207_13: Space = unite(&(v207_8),&(v207_12));
    join_wrapped_into(&mut v206_20_write,&((v207_13).read_zipper()),&[]);
    }
    v206_20_cursor.ascend(1);
  }
  drop(v206_20_cursor);
  drop(v206_20_write);
  (v206_20).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v224_14 = Space::new();
  let mut v224_14_write = v224_14.write_zipper();
  let mut v224_14_cursor = (*s0).read_zipper();
  let v224_14_origin = v224_14_cursor.path().len();
  for v224_14_byte in v224_14_cursor.child_mask().iter() {
    v224_14_cursor.descend_to_existing_byte(v224_14_byte);
    {
    let v225_2: Space = singleton(&v224_14_cursor.path()[v224_14_origin..(v224_14_origin + 1)]);
    let v225_3: Space = intersect(&(*CONSTANT_1),&(v225_2));
    let v225_4: Space = if has_head(&(v225_3)) { singleton(&[]) } else { Space::new() };
    drop(v225_3);
    let v225_5: Space = subtract(&(*CONSTANT_0),&(v225_4));
    drop(v225_4);
    let v225_8: Space = if (&(v225_5)).is_empty() { Space::new() } else {
      let v226_6: Path = concat_path(&(*p0),&v224_14_cursor.path()[v224_14_origin..(v224_14_origin + 1)]);
      let mut v226_7 = Space::new();
      let mut v226_7_write = v226_7.write_zipper();
      for v226_7_byte in v224_14_cursor.child_mask().iter() {
        v224_14_cursor.descend_to_existing_byte(v226_7_byte);
        {
        let v227_2: Space = singleton(&v224_14_cursor.path()[(v224_14_origin + 1)..(v224_14_origin + 2)]);
        let v227_3: Space = intersect(&(*CONSTANT_1),&(v227_2));
        let v227_4: Space = if has_head(&(v227_3)) { singleton(&[]) } else { Space::new() };
        drop(v227_3);
        let v227_5: Space = subtract(&(*CONSTANT_0),&(v227_4));
        drop(v227_4);
        let v227_8: Space = if (&(v227_5)).is_empty() { Space::new() } else {
          let v228_6: Path = concat_path(&(v226_6),&v224_14_cursor.path()[(v224_14_origin + 1)..(v224_14_origin + 2)]);
          let mut v228_7 = Space::new();
          let mut v228_7_write = v228_7.write_zipper();
          for v228_7_byte in v224_14_cursor.child_mask().iter() {
            v224_14_cursor.descend_to_existing_byte(v228_7_byte);
            {
            let v229_2: Space = singleton(&v224_14_cursor.path()[(v224_14_origin + 2)..(v224_14_origin + 3)]);
            let v229_3: Space = intersect(&(*CONSTANT_1),&(v229_2));
            let v229_4: Space = if has_head(&(v229_3)) { singleton(&[]) } else { Space::new() };
            drop(v229_3);
            let v229_5: Space = subtract(&(*CONSTANT_0),&(v229_4));
            drop(v229_4);
            let v229_8: Space = if (&(v229_5)).is_empty() { Space::new() } else {
              let v230_6: Path = concat_path(&(v228_6),&v224_14_cursor.path()[(v224_14_origin + 2)..(v224_14_origin + 3)]);
              let v230_7: Space = routine_24(c, &(v230_6), &v224_14_cursor);
              compose(&(v229_5),&(v230_7))
            };
            drop(v229_5);
            let v229_9: Space = intersect(&(*CONSTANT_1),&(v229_2));
            drop(v229_2);
            let v229_10: Space = if has_head(&(v229_9)) { singleton(&[]) } else { Space::new() };
            drop(v229_9);
            let v229_12: Space = if (&(v229_10)).is_empty() { Space::new() } else {
              let v231_6: Path = concat_path(&(v228_6),&v224_14_cursor.path()[(v224_14_origin + 2)..(v224_14_origin + 3)]);
              let v231_11: Space = routine_25(c, &(v231_6), &v224_14_cursor);
              drop(v231_6);
              compose(&(v229_10),&(v231_11))
            };
            drop(v229_10);
            let v229_13: Space = unite(&(v229_8),&(v229_12));
            join_wrapped_into(&mut v228_7_write,&((v229_13).read_zipper()),&[]);
            }
            v224_14_cursor.ascend(1);
          }
          drop(v228_7_write);
          compose(&(v227_5),&(v228_7))
        };
        drop(v227_5);
        let v227_9: Space = intersect(&(*CONSTANT_1),&(v227_2));
        drop(v227_2);
        let v227_10: Space = if has_head(&(v227_9)) { singleton(&[]) } else { Space::new() };
        drop(v227_9);
        let v227_12: Space = if (&(v227_10)).is_empty() { Space::new() } else {
          let v232_6: Path = concat_path(&(v226_6),&v224_14_cursor.path()[(v224_14_origin + 1)..(v224_14_origin + 2)]);
          let mut v232_11 = Space::new();
          let mut v232_11_write = v232_11.write_zipper();
          for v232_11_byte in v224_14_cursor.child_mask().iter() {
            v224_14_cursor.descend_to_existing_byte(v232_11_byte);
            {
            let v233_2: Space = singleton(&v224_14_cursor.path()[(v224_14_origin + 2)..(v224_14_origin + 3)]);
            let v233_3: Space = intersect(&(*CONSTANT_1),&(v233_2));
            let v233_4: Space = if has_head(&(v233_3)) { singleton(&[]) } else { Space::new() };
            drop(v233_3);
            let v233_5: Space = subtract(&(*CONSTANT_0),&(v233_4));
            drop(v233_4);
            let v233_8: Space = if (&(v233_5)).is_empty() { Space::new() } else {
              let v234_6: Path = concat_path(&(v232_6),&v224_14_cursor.path()[(v224_14_origin + 2)..(v224_14_origin + 3)]);
              let v234_7: Space = routine_24(c, &(v234_6), &v224_14_cursor);
              compose(&(v233_5),&(v234_7))
            };
            drop(v233_5);
            let v233_9: Space = intersect(&(*CONSTANT_1),&(v233_2));
            drop(v233_2);
            let v233_10: Space = if has_head(&(v233_9)) { singleton(&[]) } else { Space::new() };
            drop(v233_9);
            let v233_12: Space = if (&(v233_10)).is_empty() { Space::new() } else {
              let v235_6: Path = concat_path(&(v232_6),&v224_14_cursor.path()[(v224_14_origin + 2)..(v224_14_origin + 3)]);
              let v235_11: Space = routine_12(c, &(v235_6), &v224_14_cursor);
              drop(v235_6);
              compose(&(v233_10),&(v235_11))
            };
            drop(v233_10);
            let v233_13: Space = unite(&(v233_8),&(v233_12));
            join_wrapped_into(&mut v232_11_write,&((v233_13).read_zipper()),&[]);
            }
            v224_14_cursor.ascend(1);
          }
          drop(v232_11_write);
          drop(v232_6);
          compose(&(v227_10),&(v232_11))
        };
        drop(v227_10);
        let v227_13: Space = unite(&(v227_8),&(v227_12));
        join_wrapped_into(&mut v226_7_write,&((v227_13).read_zipper()),&[]);
        }
        v224_14_cursor.ascend(1);
      }
      drop(v226_7_write);
      drop(v226_6);
      compose(&(v225_5),&(v226_7))
    };
    drop(v225_5);
    let v225_9: Space = intersect(&(*CONSTANT_1),&(v225_2));
    drop(v225_2);
    let v225_10: Space = if has_head(&(v225_9)) { singleton(&[]) } else { Space::new() };
    drop(v225_9);
    let v225_11: Space = compose(&(v225_10),&v224_14_cursor);
    drop(v225_10);
    let v225_12: Space = unite(&(v225_8),&(v225_11));
    drop(v225_11);
    join_wrapped_into(&mut v224_14_write,&((v225_12).read_zipper()),&[]);
    }
    v224_14_cursor.ascend(1);
  }
  drop(v224_14_cursor);
  drop(v224_14_write);
  (v224_14).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v237_20 = Space::new();
  let mut v237_20_write = v237_20.write_zipper();
  let mut v237_20_cursor = (*s0).read_zipper();
  let v237_20_origin = v237_20_cursor.path().len();
  for v237_20_byte in v237_20_cursor.child_mask().iter() {
    v237_20_cursor.descend_to_existing_byte(v237_20_byte);
    {
    let v238_2: Space = singleton(&v237_20_cursor.path()[v237_20_origin..(v237_20_origin + 1)]);
    let v238_3: Space = intersect(&(*CONSTANT_1),&(v238_2));
    let v238_4: Space = if has_head(&(v238_3)) { singleton(&[]) } else { Space::new() };
    drop(v238_3);
    let v238_5: Space = subtract(&(*CONSTANT_0),&(v238_4));
    drop(v238_4);
    let v238_8: Space = if (&(v238_5)).is_empty() { Space::new() } else {
      let v239_6: Path = concat_path(&(*p0),&v237_20_cursor.path()[v237_20_origin..(v237_20_origin + 1)]);
      let mut v239_7 = Space::new();
      let mut v239_7_write = v239_7.write_zipper();
      for v239_7_byte in v237_20_cursor.child_mask().iter() {
        v237_20_cursor.descend_to_existing_byte(v239_7_byte);
        {
        let v240_2: Space = singleton(&v237_20_cursor.path()[(v237_20_origin + 1)..(v237_20_origin + 2)]);
        let v240_3: Space = intersect(&(*CONSTANT_1),&(v240_2));
        let v240_4: Space = if has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
        drop(v240_3);
        let v240_5: Space = subtract(&(*CONSTANT_0),&(v240_4));
        drop(v240_4);
        let v240_8: Space = if (&(v240_5)).is_empty() { Space::new() } else {
          let v241_6: Path = concat_path(&(v239_6),&v237_20_cursor.path()[(v237_20_origin + 1)..(v237_20_origin + 2)]);
          let mut v241_7 = Space::new();
          let mut v241_7_write = v241_7.write_zipper();
          for v241_7_byte in v237_20_cursor.child_mask().iter() {
            v237_20_cursor.descend_to_existing_byte(v241_7_byte);
            {
            let v242_2: Space = singleton(&v237_20_cursor.path()[(v237_20_origin + 2)..(v237_20_origin + 3)]);
            let v242_3: Space = intersect(&(*CONSTANT_1),&(v242_2));
            let v242_4: Space = if has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
            drop(v242_3);
            let v242_5: Space = subtract(&(*CONSTANT_0),&(v242_4));
            drop(v242_4);
            let v242_8: Space = if (&(v242_5)).is_empty() { Space::new() } else {
              let v243_6: Path = concat_path(&(v241_6),&v237_20_cursor.path()[(v237_20_origin + 2)..(v237_20_origin + 3)]);
              let v243_7: Space = routine_26(c, &(v243_6), &v237_20_cursor);
              compose(&(v242_5),&(v243_7))
            };
            drop(v242_5);
            let v242_9: Space = intersect(&(*CONSTANT_1),&(v242_2));
            drop(v242_2);
            let v242_10: Space = if has_head(&(v242_9)) { singleton(&[]) } else { Space::new() };
            drop(v242_9);
            let v242_12: Space = if (&(v242_10)).is_empty() { Space::new() } else {
              let v244_6: Path = concat_path(&(v241_6),&v237_20_cursor.path()[(v237_20_origin + 2)..(v237_20_origin + 3)]);
              let v244_11: Space = routine_27(c, &(v244_6), &v237_20_cursor);
              drop(v244_6);
              compose(&(v242_10),&(v244_11))
            };
            drop(v242_10);
            let v242_13: Space = unite(&(v242_8),&(v242_12));
            join_wrapped_into(&mut v241_7_write,&((v242_13).read_zipper()),&[]);
            }
            v237_20_cursor.ascend(1);
          }
          drop(v241_7_write);
          compose(&(v240_5),&(v241_7))
        };
        drop(v240_5);
        let v240_9: Space = intersect(&(*CONSTANT_1),&(v240_2));
        drop(v240_2);
        let v240_10: Space = if has_head(&(v240_9)) { singleton(&[]) } else { Space::new() };
        drop(v240_9);
        let v240_12: Space = if (&(v240_10)).is_empty() { Space::new() } else {
          let v245_6: Path = concat_path(&(v239_6),&v237_20_cursor.path()[(v237_20_origin + 1)..(v237_20_origin + 2)]);
          let mut v245_11 = Space::new();
          let mut v245_11_write = v245_11.write_zipper();
          for v245_11_byte in v237_20_cursor.child_mask().iter() {
            v237_20_cursor.descend_to_existing_byte(v245_11_byte);
            {
            let v246_2: Space = singleton(&v237_20_cursor.path()[(v237_20_origin + 2)..(v237_20_origin + 3)]);
            let v246_3: Space = intersect(&(*CONSTANT_1),&(v246_2));
            let v246_4: Space = if has_head(&(v246_3)) { singleton(&[]) } else { Space::new() };
            drop(v246_3);
            let v246_5: Space = subtract(&(*CONSTANT_0),&(v246_4));
            drop(v246_4);
            let v246_8: Space = if (&(v246_5)).is_empty() { Space::new() } else {
              let v247_6: Path = concat_path(&(v245_6),&v237_20_cursor.path()[(v237_20_origin + 2)..(v237_20_origin + 3)]);
              let v247_7: Space = routine_26(c, &(v247_6), &v237_20_cursor);
              compose(&(v246_5),&(v247_7))
            };
            drop(v246_5);
            let v246_9: Space = intersect(&(*CONSTANT_1),&(v246_2));
            drop(v246_2);
            let v246_10: Space = if has_head(&(v246_9)) { singleton(&[]) } else { Space::new() };
            drop(v246_9);
            let v246_12: Space = if (&(v246_10)).is_empty() { Space::new() } else {
              let v248_6: Path = concat_path(&(v245_6),&v237_20_cursor.path()[(v237_20_origin + 2)..(v237_20_origin + 3)]);
              let v248_11: Space = routine_15(c, &(v248_6), &v237_20_cursor);
              drop(v248_6);
              compose(&(v246_10),&(v248_11))
            };
            drop(v246_10);
            let v246_13: Space = unite(&(v246_8),&(v246_12));
            join_wrapped_into(&mut v245_11_write,&((v246_13).read_zipper()),&[]);
            }
            v237_20_cursor.ascend(1);
          }
          drop(v245_11_write);
          drop(v245_6);
          compose(&(v240_10),&(v245_11))
        };
        drop(v240_10);
        let v240_13: Space = unite(&(v240_8),&(v240_12));
        join_wrapped_into(&mut v239_7_write,&((v240_13).read_zipper()),&[]);
        }
        v237_20_cursor.ascend(1);
      }
      drop(v239_7_write);
      compose(&(v238_5),&(v239_7))
    };
    drop(v238_5);
    let v238_9: Space = intersect(&(*CONSTANT_1),&(v238_2));
    drop(v238_2);
    let v238_10: Space = if has_head(&(v238_9)) { singleton(&[]) } else { Space::new() };
    drop(v238_9);
    let v238_12: Space = if (&(v238_10)).is_empty() { Space::new() } else {
      let v249_6: Path = concat_path(&(*p0),&v237_20_cursor.path()[v237_20_origin..(v237_20_origin + 1)]);
      let mut v249_11 = Space::new();
      let mut v249_11_write = v249_11.write_zipper();
      for v249_11_byte in v237_20_cursor.child_mask().iter() {
        v237_20_cursor.descend_to_existing_byte(v249_11_byte);
        {
        let v250_2: Space = singleton(&v237_20_cursor.path()[(v237_20_origin + 1)..(v237_20_origin + 2)]);
        let v250_3: Space = intersect(&(*CONSTANT_1),&(v250_2));
        let v250_4: Space = if has_head(&(v250_3)) { singleton(&[]) } else { Space::new() };
        drop(v250_3);
        let v250_5: Space = subtract(&(*CONSTANT_0),&(v250_4));
        drop(v250_4);
        let v250_8: Space = if (&(v250_5)).is_empty() { Space::new() } else {
          let v251_6: Path = concat_path(&(v249_6),&v237_20_cursor.path()[(v237_20_origin + 1)..(v237_20_origin + 2)]);
          let mut v251_7 = Space::new();
          let mut v251_7_write = v251_7.write_zipper();
          for v251_7_byte in v237_20_cursor.child_mask().iter() {
            v237_20_cursor.descend_to_existing_byte(v251_7_byte);
            {
            let v252_2: Space = singleton(&v237_20_cursor.path()[(v237_20_origin + 2)..(v237_20_origin + 3)]);
            let v252_3: Space = intersect(&(*CONSTANT_1),&(v252_2));
            let v252_4: Space = if has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
            drop(v252_3);
            let v252_5: Space = subtract(&(*CONSTANT_0),&(v252_4));
            drop(v252_4);
            let v252_8: Space = if (&(v252_5)).is_empty() { Space::new() } else {
              let v253_6: Path = concat_path(&(v251_6),&v237_20_cursor.path()[(v237_20_origin + 2)..(v237_20_origin + 3)]);
              let v253_7: Space = routine_26(c, &(v253_6), &v237_20_cursor);
              compose(&(v252_5),&(v253_7))
            };
            drop(v252_5);
            let v252_9: Space = intersect(&(*CONSTANT_1),&(v252_2));
            drop(v252_2);
            let v252_10: Space = if has_head(&(v252_9)) { singleton(&[]) } else { Space::new() };
            drop(v252_9);
            let v252_12: Space = if (&(v252_10)).is_empty() { Space::new() } else {
              let v254_6: Path = concat_path(&(v251_6),&v237_20_cursor.path()[(v237_20_origin + 2)..(v237_20_origin + 3)]);
              let v254_11: Space = routine_27(c, &(v254_6), &v237_20_cursor);
              drop(v254_6);
              compose(&(v252_10),&(v254_11))
            };
            drop(v252_10);
            let v252_13: Space = unite(&(v252_8),&(v252_12));
            join_wrapped_into(&mut v251_7_write,&((v252_13).read_zipper()),&[]);
            }
            v237_20_cursor.ascend(1);
          }
          drop(v251_7_write);
          drop(v251_6);
          compose(&(v250_5),&(v251_7))
        };
        drop(v250_5);
        let v250_9: Space = intersect(&(*CONSTANT_1),&(v250_2));
        drop(v250_2);
        let v250_10: Space = if has_head(&(v250_9)) { singleton(&[]) } else { Space::new() };
        drop(v250_9);
        let v250_11: Space = compose(&(v250_10),&v237_20_cursor);
        drop(v250_10);
        let v250_12: Space = unite(&(v250_8),&(v250_11));
        drop(v250_11);
        join_wrapped_into(&mut v249_11_write,&((v250_12).read_zipper()),&[]);
        }
        v237_20_cursor.ascend(1);
      }
      drop(v249_11_write);
      drop(v249_6);
      compose(&(v238_10),&(v249_11))
    };
    drop(v238_10);
    let v238_13: Space = unite(&(v238_8),&(v238_12));
    join_wrapped_into(&mut v237_20_write,&((v238_13).read_zipper()),&[]);
    }
    v237_20_cursor.ascend(1);
  }
  drop(v237_20_cursor);
  drop(v237_20_write);
  (v237_20).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v255_14 = Space::new();
  let mut v255_14_write = v255_14.write_zipper();
  let mut v255_14_cursor = (*s0).read_zipper();
  let v255_14_origin = v255_14_cursor.path().len();
  for v255_14_byte in v255_14_cursor.child_mask().iter() {
    v255_14_cursor.descend_to_existing_byte(v255_14_byte);
    {
    let v256_2: Space = singleton(&v255_14_cursor.path()[v255_14_origin..(v255_14_origin + 1)]);
    let v256_3: Space = intersect(&(*CONSTANT_1),&(v256_2));
    let v256_4: Space = if has_head(&(v256_3)) { singleton(&[]) } else { Space::new() };
    drop(v256_3);
    let v256_5: Space = subtract(&(*CONSTANT_0),&(v256_4));
    drop(v256_4);
    let v256_8: Space = if (&(v256_5)).is_empty() { Space::new() } else {
      let v257_6: Path = concat_path(&(*p0),&v255_14_cursor.path()[v255_14_origin..(v255_14_origin + 1)]);
      let mut v257_7 = Space::new();
      let mut v257_7_write = v257_7.write_zipper();
      for v257_7_byte in v255_14_cursor.child_mask().iter() {
        v255_14_cursor.descend_to_existing_byte(v257_7_byte);
        {
        let v258_2: Space = singleton(&v255_14_cursor.path()[(v255_14_origin + 1)..(v255_14_origin + 2)]);
        let v258_3: Space = intersect(&(*CONSTANT_1),&(v258_2));
        let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
        drop(v258_3);
        let v258_5: Space = subtract(&(*CONSTANT_0),&(v258_4));
        drop(v258_4);
        let v258_8: Space = if (&(v258_5)).is_empty() { Space::new() } else {
          let v259_6: Path = concat_path(&(v257_6),&v255_14_cursor.path()[(v255_14_origin + 1)..(v255_14_origin + 2)]);
          let mut v259_7 = Space::new();
          let mut v259_7_write = v259_7.write_zipper();
          for v259_7_byte in v255_14_cursor.child_mask().iter() {
            v255_14_cursor.descend_to_existing_byte(v259_7_byte);
            {
            let v260_2: Space = singleton(&v255_14_cursor.path()[(v255_14_origin + 2)..(v255_14_origin + 3)]);
            let v260_3: Space = intersect(&(*CONSTANT_1),&(v260_2));
            let v260_4: Space = if has_head(&(v260_3)) { singleton(&[]) } else { Space::new() };
            drop(v260_3);
            let v260_5: Space = subtract(&(*CONSTANT_0),&(v260_4));
            drop(v260_4);
            let v260_8: Space = if (&(v260_5)).is_empty() { Space::new() } else {
              let v261_6: Path = concat_path(&(v259_6),&v255_14_cursor.path()[(v255_14_origin + 2)..(v255_14_origin + 3)]);
              let v261_7: Space = routine_26(c, &(v261_6), &v255_14_cursor);
              compose(&(v260_5),&(v261_7))
            };
            drop(v260_5);
            let v260_9: Space = intersect(&(*CONSTANT_1),&(v260_2));
            drop(v260_2);
            let v260_10: Space = if has_head(&(v260_9)) { singleton(&[]) } else { Space::new() };
            drop(v260_9);
            let v260_12: Space = if (&(v260_10)).is_empty() { Space::new() } else {
              let v262_6: Path = concat_path(&(v259_6),&v255_14_cursor.path()[(v255_14_origin + 2)..(v255_14_origin + 3)]);
              let v262_11: Space = routine_27(c, &(v262_6), &v255_14_cursor);
              drop(v262_6);
              compose(&(v260_10),&(v262_11))
            };
            drop(v260_10);
            let v260_13: Space = unite(&(v260_8),&(v260_12));
            join_wrapped_into(&mut v259_7_write,&((v260_13).read_zipper()),&[]);
            }
            v255_14_cursor.ascend(1);
          }
          drop(v259_7_write);
          compose(&(v258_5),&(v259_7))
        };
        drop(v258_5);
        let v258_9: Space = intersect(&(*CONSTANT_1),&(v258_2));
        drop(v258_2);
        let v258_10: Space = if has_head(&(v258_9)) { singleton(&[]) } else { Space::new() };
        drop(v258_9);
        let v258_12: Space = if (&(v258_10)).is_empty() { Space::new() } else {
          let v263_6: Path = concat_path(&(v257_6),&v255_14_cursor.path()[(v255_14_origin + 1)..(v255_14_origin + 2)]);
          let mut v263_11 = Space::new();
          let mut v263_11_write = v263_11.write_zipper();
          for v263_11_byte in v255_14_cursor.child_mask().iter() {
            v255_14_cursor.descend_to_existing_byte(v263_11_byte);
            {
            let v264_2: Space = singleton(&v255_14_cursor.path()[(v255_14_origin + 2)..(v255_14_origin + 3)]);
            let v264_3: Space = intersect(&(*CONSTANT_1),&(v264_2));
            let v264_4: Space = if has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
            drop(v264_3);
            let v264_5: Space = subtract(&(*CONSTANT_0),&(v264_4));
            drop(v264_4);
            let v264_8: Space = if (&(v264_5)).is_empty() { Space::new() } else {
              let v265_6: Path = concat_path(&(v263_6),&v255_14_cursor.path()[(v255_14_origin + 2)..(v255_14_origin + 3)]);
              let v265_7: Space = routine_26(c, &(v265_6), &v255_14_cursor);
              compose(&(v264_5),&(v265_7))
            };
            drop(v264_5);
            let v264_9: Space = intersect(&(*CONSTANT_1),&(v264_2));
            drop(v264_2);
            let v264_10: Space = if has_head(&(v264_9)) { singleton(&[]) } else { Space::new() };
            drop(v264_9);
            let v264_12: Space = if (&(v264_10)).is_empty() { Space::new() } else {
              let v266_6: Path = concat_path(&(v263_6),&v255_14_cursor.path()[(v255_14_origin + 2)..(v255_14_origin + 3)]);
              let v266_11: Space = routine_15(c, &(v266_6), &v255_14_cursor);
              drop(v266_6);
              compose(&(v264_10),&(v266_11))
            };
            drop(v264_10);
            let v264_13: Space = unite(&(v264_8),&(v264_12));
            join_wrapped_into(&mut v263_11_write,&((v264_13).read_zipper()),&[]);
            }
            v255_14_cursor.ascend(1);
          }
          drop(v263_11_write);
          drop(v263_6);
          compose(&(v258_10),&(v263_11))
        };
        drop(v258_10);
        let v258_13: Space = unite(&(v258_8),&(v258_12));
        join_wrapped_into(&mut v257_7_write,&((v258_13).read_zipper()),&[]);
        }
        v255_14_cursor.ascend(1);
      }
      drop(v257_7_write);
      drop(v257_6);
      compose(&(v256_5),&(v257_7))
    };
    drop(v256_5);
    let v256_9: Space = intersect(&(*CONSTANT_1),&(v256_2));
    drop(v256_2);
    let v256_10: Space = if has_head(&(v256_9)) { singleton(&[]) } else { Space::new() };
    drop(v256_9);
    let v256_11: Space = compose(&(v256_10),&v255_14_cursor);
    drop(v256_10);
    let v256_12: Space = unite(&(v256_8),&(v256_11));
    drop(v256_11);
    join_wrapped_into(&mut v255_14_write,&((v256_12).read_zipper()),&[]);
    }
    v255_14_cursor.ascend(1);
  }
  drop(v255_14_cursor);
  drop(v255_14_write);
  (v255_14).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_16(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v268_20 = Space::new();
  let mut v268_20_write = v268_20.write_zipper();
  let mut v268_20_cursor = (*s0).read_zipper();
  let v268_20_origin = v268_20_cursor.path().len();
  for v268_20_byte in v268_20_cursor.child_mask().iter() {
    v268_20_cursor.descend_to_existing_byte(v268_20_byte);
    {
    let v269_2: Space = singleton(&v268_20_cursor.path()[v268_20_origin..(v268_20_origin + 1)]);
    let v269_3: Space = intersect(&(*CONSTANT_1),&(v269_2));
    let v269_4: Space = if has_head(&(v269_3)) { singleton(&[]) } else { Space::new() };
    drop(v269_3);
    let v269_5: Space = subtract(&(*CONSTANT_0),&(v269_4));
    drop(v269_4);
    let v269_8: Space = if (&(v269_5)).is_empty() { Space::new() } else {
      let v270_6: Path = concat_path(&(*p0),&v268_20_cursor.path()[v268_20_origin..(v268_20_origin + 1)]);
      let mut v270_7 = Space::new();
      let mut v270_7_write = v270_7.write_zipper();
      for v270_7_byte in v268_20_cursor.child_mask().iter() {
        v268_20_cursor.descend_to_existing_byte(v270_7_byte);
        {
        let v271_2: Space = singleton(&v268_20_cursor.path()[(v268_20_origin + 1)..(v268_20_origin + 2)]);
        let v271_3: Space = intersect(&(*CONSTANT_1),&(v271_2));
        let v271_4: Space = if has_head(&(v271_3)) { singleton(&[]) } else { Space::new() };
        drop(v271_3);
        let v271_5: Space = subtract(&(*CONSTANT_0),&(v271_4));
        drop(v271_4);
        let v271_8: Space = if (&(v271_5)).is_empty() { Space::new() } else {
          let v272_6: Path = concat_path(&(v270_6),&v268_20_cursor.path()[(v268_20_origin + 1)..(v268_20_origin + 2)]);
          let mut v272_7 = Space::new();
          let mut v272_7_write = v272_7.write_zipper();
          for v272_7_byte in v268_20_cursor.child_mask().iter() {
            v268_20_cursor.descend_to_existing_byte(v272_7_byte);
            {
            let v273_2: Space = singleton(&v268_20_cursor.path()[(v268_20_origin + 2)..(v268_20_origin + 3)]);
            let v273_3: Space = intersect(&(*CONSTANT_1),&(v273_2));
            let v273_4: Space = if has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
            drop(v273_3);
            let v273_5: Space = subtract(&(*CONSTANT_0),&(v273_4));
            drop(v273_4);
            let v273_8: Space = if (&(v273_5)).is_empty() { Space::new() } else {
              let v274_6: Path = concat_path(&(v272_6),&v268_20_cursor.path()[(v268_20_origin + 2)..(v268_20_origin + 3)]);
              let v274_7: Space = routine_28(c, &(v274_6), &v268_20_cursor);
              compose(&(v273_5),&(v274_7))
            };
            drop(v273_5);
            let v273_9: Space = intersect(&(*CONSTANT_1),&(v273_2));
            drop(v273_2);
            let v273_10: Space = if has_head(&(v273_9)) { singleton(&[]) } else { Space::new() };
            drop(v273_9);
            let v273_12: Space = if (&(v273_10)).is_empty() { Space::new() } else {
              let v275_6: Path = concat_path(&(v272_6),&v268_20_cursor.path()[(v268_20_origin + 2)..(v268_20_origin + 3)]);
              let v275_11: Space = routine_29(c, &(v275_6), &v268_20_cursor);
              drop(v275_6);
              compose(&(v273_10),&(v275_11))
            };
            drop(v273_10);
            let v273_13: Space = unite(&(v273_8),&(v273_12));
            join_wrapped_into(&mut v272_7_write,&((v273_13).read_zipper()),&[]);
            }
            v268_20_cursor.ascend(1);
          }
          drop(v272_7_write);
          compose(&(v271_5),&(v272_7))
        };
        drop(v271_5);
        let v271_9: Space = intersect(&(*CONSTANT_1),&(v271_2));
        drop(v271_2);
        let v271_10: Space = if has_head(&(v271_9)) { singleton(&[]) } else { Space::new() };
        drop(v271_9);
        let v271_12: Space = if (&(v271_10)).is_empty() { Space::new() } else {
          let v276_6: Path = concat_path(&(v270_6),&v268_20_cursor.path()[(v268_20_origin + 1)..(v268_20_origin + 2)]);
          let mut v276_11 = Space::new();
          let mut v276_11_write = v276_11.write_zipper();
          for v276_11_byte in v268_20_cursor.child_mask().iter() {
            v268_20_cursor.descend_to_existing_byte(v276_11_byte);
            {
            let v277_2: Space = singleton(&v268_20_cursor.path()[(v268_20_origin + 2)..(v268_20_origin + 3)]);
            let v277_3: Space = intersect(&(*CONSTANT_1),&(v277_2));
            let v277_4: Space = if has_head(&(v277_3)) { singleton(&[]) } else { Space::new() };
            drop(v277_3);
            let v277_5: Space = subtract(&(*CONSTANT_0),&(v277_4));
            drop(v277_4);
            let v277_8: Space = if (&(v277_5)).is_empty() { Space::new() } else {
              let v278_6: Path = concat_path(&(v276_6),&v268_20_cursor.path()[(v268_20_origin + 2)..(v268_20_origin + 3)]);
              let v278_7: Space = routine_28(c, &(v278_6), &v268_20_cursor);
              compose(&(v277_5),&(v278_7))
            };
            drop(v277_5);
            let v277_9: Space = intersect(&(*CONSTANT_1),&(v277_2));
            drop(v277_2);
            let v277_10: Space = if has_head(&(v277_9)) { singleton(&[]) } else { Space::new() };
            drop(v277_9);
            let v277_12: Space = if (&(v277_10)).is_empty() { Space::new() } else {
              let v279_6: Path = concat_path(&(v276_6),&v268_20_cursor.path()[(v268_20_origin + 2)..(v268_20_origin + 3)]);
              let v279_11: Space = routine_12(c, &(v279_6), &v268_20_cursor);
              drop(v279_6);
              compose(&(v277_10),&(v279_11))
            };
            drop(v277_10);
            let v277_13: Space = unite(&(v277_8),&(v277_12));
            join_wrapped_into(&mut v276_11_write,&((v277_13).read_zipper()),&[]);
            }
            v268_20_cursor.ascend(1);
          }
          drop(v276_11_write);
          drop(v276_6);
          compose(&(v271_10),&(v276_11))
        };
        drop(v271_10);
        let v271_13: Space = unite(&(v271_8),&(v271_12));
        join_wrapped_into(&mut v270_7_write,&((v271_13).read_zipper()),&[]);
        }
        v268_20_cursor.ascend(1);
      }
      drop(v270_7_write);
      compose(&(v269_5),&(v270_7))
    };
    drop(v269_5);
    let v269_9: Space = intersect(&(*CONSTANT_1),&(v269_2));
    drop(v269_2);
    let v269_10: Space = if has_head(&(v269_9)) { singleton(&[]) } else { Space::new() };
    drop(v269_9);
    let v269_12: Space = if (&(v269_10)).is_empty() { Space::new() } else {
      let v280_6: Path = concat_path(&(*p0),&v268_20_cursor.path()[v268_20_origin..(v268_20_origin + 1)]);
      let mut v280_11 = Space::new();
      let mut v280_11_write = v280_11.write_zipper();
      for v280_11_byte in v268_20_cursor.child_mask().iter() {
        v268_20_cursor.descend_to_existing_byte(v280_11_byte);
        {
        let v281_2: Space = singleton(&v268_20_cursor.path()[(v268_20_origin + 1)..(v268_20_origin + 2)]);
        let v281_3: Space = intersect(&(*CONSTANT_1),&(v281_2));
        let v281_4: Space = if has_head(&(v281_3)) { singleton(&[]) } else { Space::new() };
        drop(v281_3);
        let v281_5: Space = subtract(&(*CONSTANT_0),&(v281_4));
        drop(v281_4);
        let v281_8: Space = if (&(v281_5)).is_empty() { Space::new() } else {
          let v282_6: Path = concat_path(&(v280_6),&v268_20_cursor.path()[(v268_20_origin + 1)..(v268_20_origin + 2)]);
          let mut v282_7 = Space::new();
          let mut v282_7_write = v282_7.write_zipper();
          for v282_7_byte in v268_20_cursor.child_mask().iter() {
            v268_20_cursor.descend_to_existing_byte(v282_7_byte);
            {
            let v283_2: Space = singleton(&v268_20_cursor.path()[(v268_20_origin + 2)..(v268_20_origin + 3)]);
            let v283_3: Space = intersect(&(*CONSTANT_1),&(v283_2));
            let v283_4: Space = if has_head(&(v283_3)) { singleton(&[]) } else { Space::new() };
            drop(v283_3);
            let v283_5: Space = subtract(&(*CONSTANT_0),&(v283_4));
            drop(v283_4);
            let v283_8: Space = if (&(v283_5)).is_empty() { Space::new() } else {
              let v284_6: Path = concat_path(&(v282_6),&v268_20_cursor.path()[(v268_20_origin + 2)..(v268_20_origin + 3)]);
              let v284_7: Space = routine_28(c, &(v284_6), &v268_20_cursor);
              compose(&(v283_5),&(v284_7))
            };
            drop(v283_5);
            let v283_9: Space = intersect(&(*CONSTANT_1),&(v283_2));
            drop(v283_2);
            let v283_10: Space = if has_head(&(v283_9)) { singleton(&[]) } else { Space::new() };
            drop(v283_9);
            let v283_12: Space = if (&(v283_10)).is_empty() { Space::new() } else {
              let v285_6: Path = concat_path(&(v282_6),&v268_20_cursor.path()[(v268_20_origin + 2)..(v268_20_origin + 3)]);
              let v285_11: Space = routine_29(c, &(v285_6), &v268_20_cursor);
              drop(v285_6);
              compose(&(v283_10),&(v285_11))
            };
            drop(v283_10);
            let v283_13: Space = unite(&(v283_8),&(v283_12));
            join_wrapped_into(&mut v282_7_write,&((v283_13).read_zipper()),&[]);
            }
            v268_20_cursor.ascend(1);
          }
          drop(v282_7_write);
          drop(v282_6);
          compose(&(v281_5),&(v282_7))
        };
        drop(v281_5);
        let v281_9: Space = intersect(&(*CONSTANT_1),&(v281_2));
        drop(v281_2);
        let v281_10: Space = if has_head(&(v281_9)) { singleton(&[]) } else { Space::new() };
        drop(v281_9);
        let v281_11: Space = compose(&(v281_10),&v268_20_cursor);
        drop(v281_10);
        let v281_12: Space = unite(&(v281_8),&(v281_11));
        drop(v281_11);
        join_wrapped_into(&mut v280_11_write,&((v281_12).read_zipper()),&[]);
        }
        v268_20_cursor.ascend(1);
      }
      drop(v280_11_write);
      drop(v280_6);
      compose(&(v269_10),&(v280_11))
    };
    drop(v269_10);
    let v269_13: Space = unite(&(v269_8),&(v269_12));
    join_wrapped_into(&mut v268_20_write,&((v269_13).read_zipper()),&[]);
    }
    v268_20_cursor.ascend(1);
  }
  drop(v268_20_cursor);
  drop(v268_20_write);
  (v268_20).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v286_14 = Space::new();
  let mut v286_14_write = v286_14.write_zipper();
  let mut v286_14_cursor = (*s0).read_zipper();
  let v286_14_origin = v286_14_cursor.path().len();
  for v286_14_byte in v286_14_cursor.child_mask().iter() {
    v286_14_cursor.descend_to_existing_byte(v286_14_byte);
    {
    let v287_2: Space = singleton(&v286_14_cursor.path()[v286_14_origin..(v286_14_origin + 1)]);
    let v287_3: Space = intersect(&(*CONSTANT_1),&(v287_2));
    let v287_4: Space = if has_head(&(v287_3)) { singleton(&[]) } else { Space::new() };
    drop(v287_3);
    let v287_5: Space = subtract(&(*CONSTANT_0),&(v287_4));
    drop(v287_4);
    let v287_8: Space = if (&(v287_5)).is_empty() { Space::new() } else {
      let v288_6: Path = concat_path(&(*p0),&v286_14_cursor.path()[v286_14_origin..(v286_14_origin + 1)]);
      let mut v288_7 = Space::new();
      let mut v288_7_write = v288_7.write_zipper();
      for v288_7_byte in v286_14_cursor.child_mask().iter() {
        v286_14_cursor.descend_to_existing_byte(v288_7_byte);
        {
        let v289_2: Space = singleton(&v286_14_cursor.path()[(v286_14_origin + 1)..(v286_14_origin + 2)]);
        let v289_3: Space = intersect(&(*CONSTANT_1),&(v289_2));
        let v289_4: Space = if has_head(&(v289_3)) { singleton(&[]) } else { Space::new() };
        drop(v289_3);
        let v289_5: Space = subtract(&(*CONSTANT_0),&(v289_4));
        drop(v289_4);
        let v289_8: Space = if (&(v289_5)).is_empty() { Space::new() } else {
          let v290_6: Path = concat_path(&(v288_6),&v286_14_cursor.path()[(v286_14_origin + 1)..(v286_14_origin + 2)]);
          let mut v290_7 = Space::new();
          let mut v290_7_write = v290_7.write_zipper();
          for v290_7_byte in v286_14_cursor.child_mask().iter() {
            v286_14_cursor.descend_to_existing_byte(v290_7_byte);
            {
            let v291_2: Space = singleton(&v286_14_cursor.path()[(v286_14_origin + 2)..(v286_14_origin + 3)]);
            let v291_3: Space = intersect(&(*CONSTANT_1),&(v291_2));
            let v291_4: Space = if has_head(&(v291_3)) { singleton(&[]) } else { Space::new() };
            drop(v291_3);
            let v291_5: Space = subtract(&(*CONSTANT_0),&(v291_4));
            drop(v291_4);
            let v291_8: Space = if (&(v291_5)).is_empty() { Space::new() } else {
              let v292_6: Path = concat_path(&(v290_6),&v286_14_cursor.path()[(v286_14_origin + 2)..(v286_14_origin + 3)]);
              let v292_7: Space = routine_28(c, &(v292_6), &v286_14_cursor);
              compose(&(v291_5),&(v292_7))
            };
            drop(v291_5);
            let v291_9: Space = intersect(&(*CONSTANT_1),&(v291_2));
            drop(v291_2);
            let v291_10: Space = if has_head(&(v291_9)) { singleton(&[]) } else { Space::new() };
            drop(v291_9);
            let v291_12: Space = if (&(v291_10)).is_empty() { Space::new() } else {
              let v293_6: Path = concat_path(&(v290_6),&v286_14_cursor.path()[(v286_14_origin + 2)..(v286_14_origin + 3)]);
              let v293_11: Space = routine_29(c, &(v293_6), &v286_14_cursor);
              drop(v293_6);
              compose(&(v291_10),&(v293_11))
            };
            drop(v291_10);
            let v291_13: Space = unite(&(v291_8),&(v291_12));
            join_wrapped_into(&mut v290_7_write,&((v291_13).read_zipper()),&[]);
            }
            v286_14_cursor.ascend(1);
          }
          drop(v290_7_write);
          compose(&(v289_5),&(v290_7))
        };
        drop(v289_5);
        let v289_9: Space = intersect(&(*CONSTANT_1),&(v289_2));
        drop(v289_2);
        let v289_10: Space = if has_head(&(v289_9)) { singleton(&[]) } else { Space::new() };
        drop(v289_9);
        let v289_12: Space = if (&(v289_10)).is_empty() { Space::new() } else {
          let v294_6: Path = concat_path(&(v288_6),&v286_14_cursor.path()[(v286_14_origin + 1)..(v286_14_origin + 2)]);
          let mut v294_11 = Space::new();
          let mut v294_11_write = v294_11.write_zipper();
          for v294_11_byte in v286_14_cursor.child_mask().iter() {
            v286_14_cursor.descend_to_existing_byte(v294_11_byte);
            {
            let v295_2: Space = singleton(&v286_14_cursor.path()[(v286_14_origin + 2)..(v286_14_origin + 3)]);
            let v295_3: Space = intersect(&(*CONSTANT_1),&(v295_2));
            let v295_4: Space = if has_head(&(v295_3)) { singleton(&[]) } else { Space::new() };
            drop(v295_3);
            let v295_5: Space = subtract(&(*CONSTANT_0),&(v295_4));
            drop(v295_4);
            let v295_8: Space = if (&(v295_5)).is_empty() { Space::new() } else {
              let v296_6: Path = concat_path(&(v294_6),&v286_14_cursor.path()[(v286_14_origin + 2)..(v286_14_origin + 3)]);
              let v296_7: Space = routine_28(c, &(v296_6), &v286_14_cursor);
              compose(&(v295_5),&(v296_7))
            };
            drop(v295_5);
            let v295_9: Space = intersect(&(*CONSTANT_1),&(v295_2));
            drop(v295_2);
            let v295_10: Space = if has_head(&(v295_9)) { singleton(&[]) } else { Space::new() };
            drop(v295_9);
            let v295_12: Space = if (&(v295_10)).is_empty() { Space::new() } else {
              let v297_6: Path = concat_path(&(v294_6),&v286_14_cursor.path()[(v286_14_origin + 2)..(v286_14_origin + 3)]);
              let v297_11: Space = routine_12(c, &(v297_6), &v286_14_cursor);
              drop(v297_6);
              compose(&(v295_10),&(v297_11))
            };
            drop(v295_10);
            let v295_13: Space = unite(&(v295_8),&(v295_12));
            join_wrapped_into(&mut v294_11_write,&((v295_13).read_zipper()),&[]);
            }
            v286_14_cursor.ascend(1);
          }
          drop(v294_11_write);
          drop(v294_6);
          compose(&(v289_10),&(v294_11))
        };
        drop(v289_10);
        let v289_13: Space = unite(&(v289_8),&(v289_12));
        join_wrapped_into(&mut v288_7_write,&((v289_13).read_zipper()),&[]);
        }
        v286_14_cursor.ascend(1);
      }
      drop(v288_7_write);
      drop(v288_6);
      compose(&(v287_5),&(v288_7))
    };
    drop(v287_5);
    let v287_9: Space = intersect(&(*CONSTANT_1),&(v287_2));
    drop(v287_2);
    let v287_10: Space = if has_head(&(v287_9)) { singleton(&[]) } else { Space::new() };
    drop(v287_9);
    let v287_11: Space = compose(&(v287_10),&v286_14_cursor);
    drop(v287_10);
    let v287_12: Space = unite(&(v287_8),&(v287_11));
    drop(v287_11);
    join_wrapped_into(&mut v286_14_write,&((v287_12).read_zipper()),&[]);
    }
    v286_14_cursor.ascend(1);
  }
  drop(v286_14_cursor);
  drop(v286_14_write);
  (v286_14).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v298_20 = Space::new();
  let mut v298_20_write = v298_20.write_zipper();
  let mut v298_20_cursor = (*s0).read_zipper();
  let v298_20_origin = v298_20_cursor.path().len();
  for v298_20_byte in v298_20_cursor.child_mask().iter() {
    v298_20_cursor.descend_to_existing_byte(v298_20_byte);
    {
    let v299_2: Space = singleton(&v298_20_cursor.path()[v298_20_origin..(v298_20_origin + 1)]);
    let v299_3: Space = intersect(&(*CONSTANT_1),&(v299_2));
    let v299_4: Space = if has_head(&(v299_3)) { singleton(&[]) } else { Space::new() };
    drop(v299_3);
    let v299_5: Space = subtract(&(*CONSTANT_0),&(v299_4));
    drop(v299_4);
    let v299_8: Space = if (&(v299_5)).is_empty() { Space::new() } else {
      let v300_6: Path = concat_path(&(*p0),&v298_20_cursor.path()[v298_20_origin..(v298_20_origin + 1)]);
      let mut v300_7 = Space::new();
      let mut v300_7_write = v300_7.write_zipper();
      for v300_7_byte in v298_20_cursor.child_mask().iter() {
        v298_20_cursor.descend_to_existing_byte(v300_7_byte);
        {
        let v301_2: Space = singleton(&v298_20_cursor.path()[(v298_20_origin + 1)..(v298_20_origin + 2)]);
        let v301_3: Space = intersect(&(*CONSTANT_1),&(v301_2));
        let v301_4: Space = if has_head(&(v301_3)) { singleton(&[]) } else { Space::new() };
        drop(v301_3);
        let v301_5: Space = subtract(&(*CONSTANT_0),&(v301_4));
        drop(v301_4);
        let v301_8: Space = if (&(v301_5)).is_empty() { Space::new() } else {
          let v302_6: Path = concat_path(&(v300_6),&v298_20_cursor.path()[(v298_20_origin + 1)..(v298_20_origin + 2)]);
          let mut v302_7 = Space::new();
          let mut v302_7_write = v302_7.write_zipper();
          for v302_7_byte in v298_20_cursor.child_mask().iter() {
            v298_20_cursor.descend_to_existing_byte(v302_7_byte);
            {
            let v303_2: Space = singleton(&v298_20_cursor.path()[(v298_20_origin + 2)..(v298_20_origin + 3)]);
            let v303_3: Space = intersect(&(*CONSTANT_1),&(v303_2));
            let v303_4: Space = if has_head(&(v303_3)) { singleton(&[]) } else { Space::new() };
            drop(v303_3);
            let v303_5: Space = subtract(&(*CONSTANT_0),&(v303_4));
            drop(v303_4);
            let v303_8: Space = if (&(v303_5)).is_empty() { Space::new() } else {
              let v304_6: Path = concat_path(&(v302_6),&v298_20_cursor.path()[(v298_20_origin + 2)..(v298_20_origin + 3)]);
              let v304_7: Space = routine_30(c, &(v304_6), &v298_20_cursor);
              compose(&(v303_5),&(v304_7))
            };
            drop(v303_5);
            let v303_9: Space = intersect(&(*CONSTANT_1),&(v303_2));
            drop(v303_2);
            let v303_10: Space = if has_head(&(v303_9)) { singleton(&[]) } else { Space::new() };
            drop(v303_9);
            let v303_12: Space = if (&(v303_10)).is_empty() { Space::new() } else {
              let v305_6: Path = concat_path(&(v302_6),&v298_20_cursor.path()[(v298_20_origin + 2)..(v298_20_origin + 3)]);
              let v305_11: Space = routine_31(c, &(v305_6), &v298_20_cursor);
              drop(v305_6);
              compose(&(v303_10),&(v305_11))
            };
            drop(v303_10);
            let v303_13: Space = unite(&(v303_8),&(v303_12));
            join_wrapped_into(&mut v302_7_write,&((v303_13).read_zipper()),&[]);
            }
            v298_20_cursor.ascend(1);
          }
          drop(v302_7_write);
          compose(&(v301_5),&(v302_7))
        };
        drop(v301_5);
        let v301_9: Space = intersect(&(*CONSTANT_1),&(v301_2));
        drop(v301_2);
        let v301_10: Space = if has_head(&(v301_9)) { singleton(&[]) } else { Space::new() };
        drop(v301_9);
        let v301_12: Space = if (&(v301_10)).is_empty() { Space::new() } else {
          let v306_6: Path = concat_path(&(v300_6),&v298_20_cursor.path()[(v298_20_origin + 1)..(v298_20_origin + 2)]);
          let mut v306_11 = Space::new();
          let mut v306_11_write = v306_11.write_zipper();
          for v306_11_byte in v298_20_cursor.child_mask().iter() {
            v298_20_cursor.descend_to_existing_byte(v306_11_byte);
            {
            let v307_2: Space = singleton(&v298_20_cursor.path()[(v298_20_origin + 2)..(v298_20_origin + 3)]);
            let v307_3: Space = intersect(&(*CONSTANT_1),&(v307_2));
            let v307_4: Space = if has_head(&(v307_3)) { singleton(&[]) } else { Space::new() };
            drop(v307_3);
            let v307_5: Space = subtract(&(*CONSTANT_0),&(v307_4));
            drop(v307_4);
            let v307_8: Space = if (&(v307_5)).is_empty() { Space::new() } else {
              let v308_6: Path = concat_path(&(v306_6),&v298_20_cursor.path()[(v298_20_origin + 2)..(v298_20_origin + 3)]);
              let v308_7: Space = routine_30(c, &(v308_6), &v298_20_cursor);
              compose(&(v307_5),&(v308_7))
            };
            drop(v307_5);
            let v307_9: Space = intersect(&(*CONSTANT_1),&(v307_2));
            drop(v307_2);
            let v307_10: Space = if has_head(&(v307_9)) { singleton(&[]) } else { Space::new() };
            drop(v307_9);
            let v307_12: Space = if (&(v307_10)).is_empty() { Space::new() } else {
              let v309_6: Path = concat_path(&(v306_6),&v298_20_cursor.path()[(v298_20_origin + 2)..(v298_20_origin + 3)]);
              let v309_11: Space = routine_15(c, &(v309_6), &v298_20_cursor);
              drop(v309_6);
              compose(&(v307_10),&(v309_11))
            };
            drop(v307_10);
            let v307_13: Space = unite(&(v307_8),&(v307_12));
            join_wrapped_into(&mut v306_11_write,&((v307_13).read_zipper()),&[]);
            }
            v298_20_cursor.ascend(1);
          }
          drop(v306_11_write);
          drop(v306_6);
          compose(&(v301_10),&(v306_11))
        };
        drop(v301_10);
        let v301_13: Space = unite(&(v301_8),&(v301_12));
        join_wrapped_into(&mut v300_7_write,&((v301_13).read_zipper()),&[]);
        }
        v298_20_cursor.ascend(1);
      }
      drop(v300_7_write);
      compose(&(v299_5),&(v300_7))
    };
    drop(v299_5);
    let v299_9: Space = intersect(&(*CONSTANT_1),&(v299_2));
    drop(v299_2);
    let v299_10: Space = if has_head(&(v299_9)) { singleton(&[]) } else { Space::new() };
    drop(v299_9);
    let v299_12: Space = if (&(v299_10)).is_empty() { Space::new() } else {
      let v310_6: Path = concat_path(&(*p0),&v298_20_cursor.path()[v298_20_origin..(v298_20_origin + 1)]);
      let mut v310_11 = Space::new();
      let mut v310_11_write = v310_11.write_zipper();
      for v310_11_byte in v298_20_cursor.child_mask().iter() {
        v298_20_cursor.descend_to_existing_byte(v310_11_byte);
        {
        let v311_2: Space = singleton(&v298_20_cursor.path()[(v298_20_origin + 1)..(v298_20_origin + 2)]);
        let v311_3: Space = intersect(&(*CONSTANT_1),&(v311_2));
        let v311_4: Space = if has_head(&(v311_3)) { singleton(&[]) } else { Space::new() };
        drop(v311_3);
        let v311_5: Space = subtract(&(*CONSTANT_0),&(v311_4));
        drop(v311_4);
        let v311_8: Space = if (&(v311_5)).is_empty() { Space::new() } else {
          let v312_6: Path = concat_path(&(v310_6),&v298_20_cursor.path()[(v298_20_origin + 1)..(v298_20_origin + 2)]);
          let mut v312_7 = Space::new();
          let mut v312_7_write = v312_7.write_zipper();
          for v312_7_byte in v298_20_cursor.child_mask().iter() {
            v298_20_cursor.descend_to_existing_byte(v312_7_byte);
            {
            let v313_2: Space = singleton(&v298_20_cursor.path()[(v298_20_origin + 2)..(v298_20_origin + 3)]);
            let v313_3: Space = intersect(&(*CONSTANT_1),&(v313_2));
            let v313_4: Space = if has_head(&(v313_3)) { singleton(&[]) } else { Space::new() };
            drop(v313_3);
            let v313_5: Space = subtract(&(*CONSTANT_0),&(v313_4));
            drop(v313_4);
            let v313_8: Space = if (&(v313_5)).is_empty() { Space::new() } else {
              let v314_6: Path = concat_path(&(v312_6),&v298_20_cursor.path()[(v298_20_origin + 2)..(v298_20_origin + 3)]);
              let v314_7: Space = routine_30(c, &(v314_6), &v298_20_cursor);
              compose(&(v313_5),&(v314_7))
            };
            drop(v313_5);
            let v313_9: Space = intersect(&(*CONSTANT_1),&(v313_2));
            drop(v313_2);
            let v313_10: Space = if has_head(&(v313_9)) { singleton(&[]) } else { Space::new() };
            drop(v313_9);
            let v313_12: Space = if (&(v313_10)).is_empty() { Space::new() } else {
              let v315_6: Path = concat_path(&(v312_6),&v298_20_cursor.path()[(v298_20_origin + 2)..(v298_20_origin + 3)]);
              let v315_11: Space = routine_31(c, &(v315_6), &v298_20_cursor);
              drop(v315_6);
              compose(&(v313_10),&(v315_11))
            };
            drop(v313_10);
            let v313_13: Space = unite(&(v313_8),&(v313_12));
            join_wrapped_into(&mut v312_7_write,&((v313_13).read_zipper()),&[]);
            }
            v298_20_cursor.ascend(1);
          }
          drop(v312_7_write);
          drop(v312_6);
          compose(&(v311_5),&(v312_7))
        };
        drop(v311_5);
        let v311_9: Space = intersect(&(*CONSTANT_1),&(v311_2));
        drop(v311_2);
        let v311_10: Space = if has_head(&(v311_9)) { singleton(&[]) } else { Space::new() };
        drop(v311_9);
        let v311_11: Space = compose(&(v311_10),&v298_20_cursor);
        drop(v311_10);
        let v311_12: Space = unite(&(v311_8),&(v311_11));
        drop(v311_11);
        join_wrapped_into(&mut v310_11_write,&((v311_12).read_zipper()),&[]);
        }
        v298_20_cursor.ascend(1);
      }
      drop(v310_11_write);
      drop(v310_6);
      compose(&(v299_10),&(v310_11))
    };
    drop(v299_10);
    let v299_13: Space = unite(&(v299_8),&(v299_12));
    join_wrapped_into(&mut v298_20_write,&((v299_13).read_zipper()),&[]);
    }
    v298_20_cursor.ascend(1);
  }
  drop(v298_20_cursor);
  drop(v298_20_write);
  (v298_20).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v316_14 = Space::new();
  let mut v316_14_write = v316_14.write_zipper();
  let mut v316_14_cursor = (*s0).read_zipper();
  let v316_14_origin = v316_14_cursor.path().len();
  for v316_14_byte in v316_14_cursor.child_mask().iter() {
    v316_14_cursor.descend_to_existing_byte(v316_14_byte);
    {
    let v317_2: Space = singleton(&v316_14_cursor.path()[v316_14_origin..(v316_14_origin + 1)]);
    let v317_3: Space = intersect(&(*CONSTANT_1),&(v317_2));
    let v317_4: Space = if has_head(&(v317_3)) { singleton(&[]) } else { Space::new() };
    drop(v317_3);
    let v317_5: Space = subtract(&(*CONSTANT_0),&(v317_4));
    drop(v317_4);
    let v317_8: Space = if (&(v317_5)).is_empty() { Space::new() } else {
      let v318_6: Path = concat_path(&(*p0),&v316_14_cursor.path()[v316_14_origin..(v316_14_origin + 1)]);
      let mut v318_7 = Space::new();
      let mut v318_7_write = v318_7.write_zipper();
      for v318_7_byte in v316_14_cursor.child_mask().iter() {
        v316_14_cursor.descend_to_existing_byte(v318_7_byte);
        {
        let v319_2: Space = singleton(&v316_14_cursor.path()[(v316_14_origin + 1)..(v316_14_origin + 2)]);
        let v319_3: Space = intersect(&(*CONSTANT_1),&(v319_2));
        let v319_4: Space = if has_head(&(v319_3)) { singleton(&[]) } else { Space::new() };
        drop(v319_3);
        let v319_5: Space = subtract(&(*CONSTANT_0),&(v319_4));
        drop(v319_4);
        let v319_8: Space = if (&(v319_5)).is_empty() { Space::new() } else {
          let v320_6: Path = concat_path(&(v318_6),&v316_14_cursor.path()[(v316_14_origin + 1)..(v316_14_origin + 2)]);
          let mut v320_7 = Space::new();
          let mut v320_7_write = v320_7.write_zipper();
          for v320_7_byte in v316_14_cursor.child_mask().iter() {
            v316_14_cursor.descend_to_existing_byte(v320_7_byte);
            {
            let v321_2: Space = singleton(&v316_14_cursor.path()[(v316_14_origin + 2)..(v316_14_origin + 3)]);
            let v321_3: Space = intersect(&(*CONSTANT_1),&(v321_2));
            let v321_4: Space = if has_head(&(v321_3)) { singleton(&[]) } else { Space::new() };
            drop(v321_3);
            let v321_5: Space = subtract(&(*CONSTANT_0),&(v321_4));
            drop(v321_4);
            let v321_8: Space = if (&(v321_5)).is_empty() { Space::new() } else {
              let v322_6: Path = concat_path(&(v320_6),&v316_14_cursor.path()[(v316_14_origin + 2)..(v316_14_origin + 3)]);
              let v322_7: Space = routine_30(c, &(v322_6), &v316_14_cursor);
              compose(&(v321_5),&(v322_7))
            };
            drop(v321_5);
            let v321_9: Space = intersect(&(*CONSTANT_1),&(v321_2));
            drop(v321_2);
            let v321_10: Space = if has_head(&(v321_9)) { singleton(&[]) } else { Space::new() };
            drop(v321_9);
            let v321_12: Space = if (&(v321_10)).is_empty() { Space::new() } else {
              let v323_6: Path = concat_path(&(v320_6),&v316_14_cursor.path()[(v316_14_origin + 2)..(v316_14_origin + 3)]);
              let v323_11: Space = routine_31(c, &(v323_6), &v316_14_cursor);
              drop(v323_6);
              compose(&(v321_10),&(v323_11))
            };
            drop(v321_10);
            let v321_13: Space = unite(&(v321_8),&(v321_12));
            join_wrapped_into(&mut v320_7_write,&((v321_13).read_zipper()),&[]);
            }
            v316_14_cursor.ascend(1);
          }
          drop(v320_7_write);
          compose(&(v319_5),&(v320_7))
        };
        drop(v319_5);
        let v319_9: Space = intersect(&(*CONSTANT_1),&(v319_2));
        drop(v319_2);
        let v319_10: Space = if has_head(&(v319_9)) { singleton(&[]) } else { Space::new() };
        drop(v319_9);
        let v319_12: Space = if (&(v319_10)).is_empty() { Space::new() } else {
          let v324_6: Path = concat_path(&(v318_6),&v316_14_cursor.path()[(v316_14_origin + 1)..(v316_14_origin + 2)]);
          let mut v324_11 = Space::new();
          let mut v324_11_write = v324_11.write_zipper();
          for v324_11_byte in v316_14_cursor.child_mask().iter() {
            v316_14_cursor.descend_to_existing_byte(v324_11_byte);
            {
            let v325_2: Space = singleton(&v316_14_cursor.path()[(v316_14_origin + 2)..(v316_14_origin + 3)]);
            let v325_3: Space = intersect(&(*CONSTANT_1),&(v325_2));
            let v325_4: Space = if has_head(&(v325_3)) { singleton(&[]) } else { Space::new() };
            drop(v325_3);
            let v325_5: Space = subtract(&(*CONSTANT_0),&(v325_4));
            drop(v325_4);
            let v325_8: Space = if (&(v325_5)).is_empty() { Space::new() } else {
              let v326_6: Path = concat_path(&(v324_6),&v316_14_cursor.path()[(v316_14_origin + 2)..(v316_14_origin + 3)]);
              let v326_7: Space = routine_30(c, &(v326_6), &v316_14_cursor);
              compose(&(v325_5),&(v326_7))
            };
            drop(v325_5);
            let v325_9: Space = intersect(&(*CONSTANT_1),&(v325_2));
            drop(v325_2);
            let v325_10: Space = if has_head(&(v325_9)) { singleton(&[]) } else { Space::new() };
            drop(v325_9);
            let v325_12: Space = if (&(v325_10)).is_empty() { Space::new() } else {
              let v327_6: Path = concat_path(&(v324_6),&v316_14_cursor.path()[(v316_14_origin + 2)..(v316_14_origin + 3)]);
              let v327_11: Space = routine_15(c, &(v327_6), &v316_14_cursor);
              drop(v327_6);
              compose(&(v325_10),&(v327_11))
            };
            drop(v325_10);
            let v325_13: Space = unite(&(v325_8),&(v325_12));
            join_wrapped_into(&mut v324_11_write,&((v325_13).read_zipper()),&[]);
            }
            v316_14_cursor.ascend(1);
          }
          drop(v324_11_write);
          drop(v324_6);
          compose(&(v319_10),&(v324_11))
        };
        drop(v319_10);
        let v319_13: Space = unite(&(v319_8),&(v319_12));
        join_wrapped_into(&mut v318_7_write,&((v319_13).read_zipper()),&[]);
        }
        v316_14_cursor.ascend(1);
      }
      drop(v318_7_write);
      drop(v318_6);
      compose(&(v317_5),&(v318_7))
    };
    drop(v317_5);
    let v317_9: Space = intersect(&(*CONSTANT_1),&(v317_2));
    drop(v317_2);
    let v317_10: Space = if has_head(&(v317_9)) { singleton(&[]) } else { Space::new() };
    drop(v317_9);
    let v317_11: Space = compose(&(v317_10),&v316_14_cursor);
    drop(v317_10);
    let v317_12: Space = unite(&(v317_8),&(v317_11));
    drop(v317_11);
    join_wrapped_into(&mut v316_14_write,&((v317_12).read_zipper()),&[]);
    }
    v316_14_cursor.ascend(1);
  }
  drop(v316_14_cursor);
  drop(v316_14_write);
  (v316_14).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v328_20 = Space::new();
  let mut v328_20_write = v328_20.write_zipper();
  let mut v328_20_cursor = (*s0).read_zipper();
  let v328_20_origin = v328_20_cursor.path().len();
  for v328_20_byte in v328_20_cursor.child_mask().iter() {
    v328_20_cursor.descend_to_existing_byte(v328_20_byte);
    {
    let v329_2: Space = singleton(&v328_20_cursor.path()[v328_20_origin..(v328_20_origin + 1)]);
    let v329_3: Space = intersect(&(*CONSTANT_1),&(v329_2));
    let v329_4: Space = if has_head(&(v329_3)) { singleton(&[]) } else { Space::new() };
    drop(v329_3);
    let v329_5: Space = subtract(&(*CONSTANT_0),&(v329_4));
    drop(v329_4);
    let v329_8: Space = if (&(v329_5)).is_empty() { Space::new() } else {
      let v330_6: Path = concat_path(&(*p0),&v328_20_cursor.path()[v328_20_origin..(v328_20_origin + 1)]);
      let mut v330_7 = Space::new();
      let mut v330_7_write = v330_7.write_zipper();
      for v330_7_byte in v328_20_cursor.child_mask().iter() {
        v328_20_cursor.descend_to_existing_byte(v330_7_byte);
        {
        let v331_2: Space = singleton(&v328_20_cursor.path()[(v328_20_origin + 1)..(v328_20_origin + 2)]);
        let v331_3: Space = intersect(&(*CONSTANT_1),&(v331_2));
        let v331_4: Space = if has_head(&(v331_3)) { singleton(&[]) } else { Space::new() };
        drop(v331_3);
        let v331_5: Space = subtract(&(*CONSTANT_0),&(v331_4));
        drop(v331_4);
        let v331_8: Space = if (&(v331_5)).is_empty() { Space::new() } else {
          let v332_6: Path = concat_path(&(v330_6),&v328_20_cursor.path()[(v328_20_origin + 1)..(v328_20_origin + 2)]);
          let mut v332_7 = Space::new();
          let mut v332_7_write = v332_7.write_zipper();
          for v332_7_byte in v328_20_cursor.child_mask().iter() {
            v328_20_cursor.descend_to_existing_byte(v332_7_byte);
            {
            let v333_2: Space = singleton(&v328_20_cursor.path()[(v328_20_origin + 2)..(v328_20_origin + 3)]);
            let v333_3: Space = intersect(&(*CONSTANT_1),&(v333_2));
            let v333_4: Space = if has_head(&(v333_3)) { singleton(&[]) } else { Space::new() };
            drop(v333_3);
            let v333_5: Space = subtract(&(*CONSTANT_0),&(v333_4));
            drop(v333_4);
            let v333_8: Space = if (&(v333_5)).is_empty() { Space::new() } else {
              let v334_6: Path = concat_path(&(v332_6),&v328_20_cursor.path()[(v328_20_origin + 2)..(v328_20_origin + 3)]);
              let v334_7: Space = routine_32(c, &(v334_6), &v328_20_cursor);
              compose(&(v333_5),&(v334_7))
            };
            drop(v333_5);
            let v333_9: Space = intersect(&(*CONSTANT_1),&(v333_2));
            drop(v333_2);
            let v333_10: Space = if has_head(&(v333_9)) { singleton(&[]) } else { Space::new() };
            drop(v333_9);
            let v333_12: Space = if (&(v333_10)).is_empty() { Space::new() } else {
              let v335_6: Path = concat_path(&(v332_6),&v328_20_cursor.path()[(v328_20_origin + 2)..(v328_20_origin + 3)]);
              let v335_11: Space = routine_33(c, &(v335_6), &v328_20_cursor);
              drop(v335_6);
              compose(&(v333_10),&(v335_11))
            };
            drop(v333_10);
            let v333_13: Space = unite(&(v333_8),&(v333_12));
            join_wrapped_into(&mut v332_7_write,&((v333_13).read_zipper()),&[]);
            }
            v328_20_cursor.ascend(1);
          }
          drop(v332_7_write);
          compose(&(v331_5),&(v332_7))
        };
        drop(v331_5);
        let v331_9: Space = intersect(&(*CONSTANT_1),&(v331_2));
        drop(v331_2);
        let v331_10: Space = if has_head(&(v331_9)) { singleton(&[]) } else { Space::new() };
        drop(v331_9);
        let v331_12: Space = if (&(v331_10)).is_empty() { Space::new() } else {
          let v336_6: Path = concat_path(&(v330_6),&v328_20_cursor.path()[(v328_20_origin + 1)..(v328_20_origin + 2)]);
          let mut v336_11 = Space::new();
          let mut v336_11_write = v336_11.write_zipper();
          for v336_11_byte in v328_20_cursor.child_mask().iter() {
            v328_20_cursor.descend_to_existing_byte(v336_11_byte);
            {
            let v337_2: Space = singleton(&v328_20_cursor.path()[(v328_20_origin + 2)..(v328_20_origin + 3)]);
            let v337_3: Space = intersect(&(*CONSTANT_1),&(v337_2));
            let v337_4: Space = if has_head(&(v337_3)) { singleton(&[]) } else { Space::new() };
            drop(v337_3);
            let v337_5: Space = subtract(&(*CONSTANT_0),&(v337_4));
            drop(v337_4);
            let v337_8: Space = if (&(v337_5)).is_empty() { Space::new() } else {
              let v338_6: Path = concat_path(&(v336_6),&v328_20_cursor.path()[(v328_20_origin + 2)..(v328_20_origin + 3)]);
              let v338_7: Space = routine_32(c, &(v338_6), &v328_20_cursor);
              compose(&(v337_5),&(v338_7))
            };
            drop(v337_5);
            let v337_9: Space = intersect(&(*CONSTANT_1),&(v337_2));
            drop(v337_2);
            let v337_10: Space = if has_head(&(v337_9)) { singleton(&[]) } else { Space::new() };
            drop(v337_9);
            let v337_12: Space = if (&(v337_10)).is_empty() { Space::new() } else {
              let v339_6: Path = concat_path(&(v336_6),&v328_20_cursor.path()[(v328_20_origin + 2)..(v328_20_origin + 3)]);
              let v339_11: Space = routine_12(c, &(v339_6), &v328_20_cursor);
              drop(v339_6);
              compose(&(v337_10),&(v339_11))
            };
            drop(v337_10);
            let v337_13: Space = unite(&(v337_8),&(v337_12));
            join_wrapped_into(&mut v336_11_write,&((v337_13).read_zipper()),&[]);
            }
            v328_20_cursor.ascend(1);
          }
          drop(v336_11_write);
          drop(v336_6);
          compose(&(v331_10),&(v336_11))
        };
        drop(v331_10);
        let v331_13: Space = unite(&(v331_8),&(v331_12));
        join_wrapped_into(&mut v330_7_write,&((v331_13).read_zipper()),&[]);
        }
        v328_20_cursor.ascend(1);
      }
      drop(v330_7_write);
      compose(&(v329_5),&(v330_7))
    };
    drop(v329_5);
    let v329_9: Space = intersect(&(*CONSTANT_1),&(v329_2));
    drop(v329_2);
    let v329_10: Space = if has_head(&(v329_9)) { singleton(&[]) } else { Space::new() };
    drop(v329_9);
    let v329_12: Space = if (&(v329_10)).is_empty() { Space::new() } else {
      let v340_6: Path = concat_path(&(*p0),&v328_20_cursor.path()[v328_20_origin..(v328_20_origin + 1)]);
      let mut v340_11 = Space::new();
      let mut v340_11_write = v340_11.write_zipper();
      for v340_11_byte in v328_20_cursor.child_mask().iter() {
        v328_20_cursor.descend_to_existing_byte(v340_11_byte);
        {
        let v341_2: Space = singleton(&v328_20_cursor.path()[(v328_20_origin + 1)..(v328_20_origin + 2)]);
        let v341_3: Space = intersect(&(*CONSTANT_1),&(v341_2));
        let v341_4: Space = if has_head(&(v341_3)) { singleton(&[]) } else { Space::new() };
        drop(v341_3);
        let v341_5: Space = subtract(&(*CONSTANT_0),&(v341_4));
        drop(v341_4);
        let v341_8: Space = if (&(v341_5)).is_empty() { Space::new() } else {
          let v342_6: Path = concat_path(&(v340_6),&v328_20_cursor.path()[(v328_20_origin + 1)..(v328_20_origin + 2)]);
          let mut v342_7 = Space::new();
          let mut v342_7_write = v342_7.write_zipper();
          for v342_7_byte in v328_20_cursor.child_mask().iter() {
            v328_20_cursor.descend_to_existing_byte(v342_7_byte);
            {
            let v343_2: Space = singleton(&v328_20_cursor.path()[(v328_20_origin + 2)..(v328_20_origin + 3)]);
            let v343_3: Space = intersect(&(*CONSTANT_1),&(v343_2));
            let v343_4: Space = if has_head(&(v343_3)) { singleton(&[]) } else { Space::new() };
            drop(v343_3);
            let v343_5: Space = subtract(&(*CONSTANT_0),&(v343_4));
            drop(v343_4);
            let v343_8: Space = if (&(v343_5)).is_empty() { Space::new() } else {
              let v344_6: Path = concat_path(&(v342_6),&v328_20_cursor.path()[(v328_20_origin + 2)..(v328_20_origin + 3)]);
              let v344_7: Space = routine_32(c, &(v344_6), &v328_20_cursor);
              compose(&(v343_5),&(v344_7))
            };
            drop(v343_5);
            let v343_9: Space = intersect(&(*CONSTANT_1),&(v343_2));
            drop(v343_2);
            let v343_10: Space = if has_head(&(v343_9)) { singleton(&[]) } else { Space::new() };
            drop(v343_9);
            let v343_12: Space = if (&(v343_10)).is_empty() { Space::new() } else {
              let v345_6: Path = concat_path(&(v342_6),&v328_20_cursor.path()[(v328_20_origin + 2)..(v328_20_origin + 3)]);
              let v345_11: Space = routine_33(c, &(v345_6), &v328_20_cursor);
              drop(v345_6);
              compose(&(v343_10),&(v345_11))
            };
            drop(v343_10);
            let v343_13: Space = unite(&(v343_8),&(v343_12));
            join_wrapped_into(&mut v342_7_write,&((v343_13).read_zipper()),&[]);
            }
            v328_20_cursor.ascend(1);
          }
          drop(v342_7_write);
          drop(v342_6);
          compose(&(v341_5),&(v342_7))
        };
        drop(v341_5);
        let v341_9: Space = intersect(&(*CONSTANT_1),&(v341_2));
        drop(v341_2);
        let v341_10: Space = if has_head(&(v341_9)) { singleton(&[]) } else { Space::new() };
        drop(v341_9);
        let v341_11: Space = compose(&(v341_10),&v328_20_cursor);
        drop(v341_10);
        let v341_12: Space = unite(&(v341_8),&(v341_11));
        drop(v341_11);
        join_wrapped_into(&mut v340_11_write,&((v341_12).read_zipper()),&[]);
        }
        v328_20_cursor.ascend(1);
      }
      drop(v340_11_write);
      drop(v340_6);
      compose(&(v329_10),&(v340_11))
    };
    drop(v329_10);
    let v329_13: Space = unite(&(v329_8),&(v329_12));
    join_wrapped_into(&mut v328_20_write,&((v329_13).read_zipper()),&[]);
    }
    v328_20_cursor.ascend(1);
  }
  drop(v328_20_cursor);
  drop(v328_20_write);
  (v328_20).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v346_14 = Space::new();
  let mut v346_14_write = v346_14.write_zipper();
  let mut v346_14_cursor = (*s0).read_zipper();
  let v346_14_origin = v346_14_cursor.path().len();
  for v346_14_byte in v346_14_cursor.child_mask().iter() {
    v346_14_cursor.descend_to_existing_byte(v346_14_byte);
    {
    let v347_2: Space = singleton(&v346_14_cursor.path()[v346_14_origin..(v346_14_origin + 1)]);
    let v347_3: Space = intersect(&(*CONSTANT_1),&(v347_2));
    let v347_4: Space = if has_head(&(v347_3)) { singleton(&[]) } else { Space::new() };
    drop(v347_3);
    let v347_5: Space = subtract(&(*CONSTANT_0),&(v347_4));
    drop(v347_4);
    let v347_8: Space = if (&(v347_5)).is_empty() { Space::new() } else {
      let v348_6: Path = concat_path(&(*p0),&v346_14_cursor.path()[v346_14_origin..(v346_14_origin + 1)]);
      let mut v348_7 = Space::new();
      let mut v348_7_write = v348_7.write_zipper();
      for v348_7_byte in v346_14_cursor.child_mask().iter() {
        v346_14_cursor.descend_to_existing_byte(v348_7_byte);
        {
        let v349_2: Space = singleton(&v346_14_cursor.path()[(v346_14_origin + 1)..(v346_14_origin + 2)]);
        let v349_3: Space = intersect(&(*CONSTANT_1),&(v349_2));
        let v349_4: Space = if has_head(&(v349_3)) { singleton(&[]) } else { Space::new() };
        drop(v349_3);
        let v349_5: Space = subtract(&(*CONSTANT_0),&(v349_4));
        drop(v349_4);
        let v349_8: Space = if (&(v349_5)).is_empty() { Space::new() } else {
          let v350_6: Path = concat_path(&(v348_6),&v346_14_cursor.path()[(v346_14_origin + 1)..(v346_14_origin + 2)]);
          let mut v350_7 = Space::new();
          let mut v350_7_write = v350_7.write_zipper();
          for v350_7_byte in v346_14_cursor.child_mask().iter() {
            v346_14_cursor.descend_to_existing_byte(v350_7_byte);
            {
            let v351_2: Space = singleton(&v346_14_cursor.path()[(v346_14_origin + 2)..(v346_14_origin + 3)]);
            let v351_3: Space = intersect(&(*CONSTANT_1),&(v351_2));
            let v351_4: Space = if has_head(&(v351_3)) { singleton(&[]) } else { Space::new() };
            drop(v351_3);
            let v351_5: Space = subtract(&(*CONSTANT_0),&(v351_4));
            drop(v351_4);
            let v351_8: Space = if (&(v351_5)).is_empty() { Space::new() } else {
              let v352_6: Path = concat_path(&(v350_6),&v346_14_cursor.path()[(v346_14_origin + 2)..(v346_14_origin + 3)]);
              let v352_7: Space = routine_32(c, &(v352_6), &v346_14_cursor);
              compose(&(v351_5),&(v352_7))
            };
            drop(v351_5);
            let v351_9: Space = intersect(&(*CONSTANT_1),&(v351_2));
            drop(v351_2);
            let v351_10: Space = if has_head(&(v351_9)) { singleton(&[]) } else { Space::new() };
            drop(v351_9);
            let v351_12: Space = if (&(v351_10)).is_empty() { Space::new() } else {
              let v353_6: Path = concat_path(&(v350_6),&v346_14_cursor.path()[(v346_14_origin + 2)..(v346_14_origin + 3)]);
              let v353_11: Space = routine_33(c, &(v353_6), &v346_14_cursor);
              drop(v353_6);
              compose(&(v351_10),&(v353_11))
            };
            drop(v351_10);
            let v351_13: Space = unite(&(v351_8),&(v351_12));
            join_wrapped_into(&mut v350_7_write,&((v351_13).read_zipper()),&[]);
            }
            v346_14_cursor.ascend(1);
          }
          drop(v350_7_write);
          compose(&(v349_5),&(v350_7))
        };
        drop(v349_5);
        let v349_9: Space = intersect(&(*CONSTANT_1),&(v349_2));
        drop(v349_2);
        let v349_10: Space = if has_head(&(v349_9)) { singleton(&[]) } else { Space::new() };
        drop(v349_9);
        let v349_12: Space = if (&(v349_10)).is_empty() { Space::new() } else {
          let v354_6: Path = concat_path(&(v348_6),&v346_14_cursor.path()[(v346_14_origin + 1)..(v346_14_origin + 2)]);
          let mut v354_11 = Space::new();
          let mut v354_11_write = v354_11.write_zipper();
          for v354_11_byte in v346_14_cursor.child_mask().iter() {
            v346_14_cursor.descend_to_existing_byte(v354_11_byte);
            {
            let v355_2: Space = singleton(&v346_14_cursor.path()[(v346_14_origin + 2)..(v346_14_origin + 3)]);
            let v355_3: Space = intersect(&(*CONSTANT_1),&(v355_2));
            let v355_4: Space = if has_head(&(v355_3)) { singleton(&[]) } else { Space::new() };
            drop(v355_3);
            let v355_5: Space = subtract(&(*CONSTANT_0),&(v355_4));
            drop(v355_4);
            let v355_8: Space = if (&(v355_5)).is_empty() { Space::new() } else {
              let v356_6: Path = concat_path(&(v354_6),&v346_14_cursor.path()[(v346_14_origin + 2)..(v346_14_origin + 3)]);
              let v356_7: Space = routine_32(c, &(v356_6), &v346_14_cursor);
              compose(&(v355_5),&(v356_7))
            };
            drop(v355_5);
            let v355_9: Space = intersect(&(*CONSTANT_1),&(v355_2));
            drop(v355_2);
            let v355_10: Space = if has_head(&(v355_9)) { singleton(&[]) } else { Space::new() };
            drop(v355_9);
            let v355_12: Space = if (&(v355_10)).is_empty() { Space::new() } else {
              let v357_6: Path = concat_path(&(v354_6),&v346_14_cursor.path()[(v346_14_origin + 2)..(v346_14_origin + 3)]);
              let v357_11: Space = routine_12(c, &(v357_6), &v346_14_cursor);
              drop(v357_6);
              compose(&(v355_10),&(v357_11))
            };
            drop(v355_10);
            let v355_13: Space = unite(&(v355_8),&(v355_12));
            join_wrapped_into(&mut v354_11_write,&((v355_13).read_zipper()),&[]);
            }
            v346_14_cursor.ascend(1);
          }
          drop(v354_11_write);
          drop(v354_6);
          compose(&(v349_10),&(v354_11))
        };
        drop(v349_10);
        let v349_13: Space = unite(&(v349_8),&(v349_12));
        join_wrapped_into(&mut v348_7_write,&((v349_13).read_zipper()),&[]);
        }
        v346_14_cursor.ascend(1);
      }
      drop(v348_7_write);
      drop(v348_6);
      compose(&(v347_5),&(v348_7))
    };
    drop(v347_5);
    let v347_9: Space = intersect(&(*CONSTANT_1),&(v347_2));
    drop(v347_2);
    let v347_10: Space = if has_head(&(v347_9)) { singleton(&[]) } else { Space::new() };
    drop(v347_9);
    let v347_11: Space = compose(&(v347_10),&v346_14_cursor);
    drop(v347_10);
    let v347_12: Space = unite(&(v347_8),&(v347_11));
    drop(v347_11);
    join_wrapped_into(&mut v346_14_write,&((v347_12).read_zipper()),&[]);
    }
    v346_14_cursor.ascend(1);
  }
  drop(v346_14_cursor);
  drop(v346_14_write);
  (v346_14).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v358_20 = Space::new();
  let mut v358_20_write = v358_20.write_zipper();
  let mut v358_20_cursor = (*s0).read_zipper();
  let v358_20_origin = v358_20_cursor.path().len();
  for v358_20_byte in v358_20_cursor.child_mask().iter() {
    v358_20_cursor.descend_to_existing_byte(v358_20_byte);
    {
    let v359_2: Space = singleton(&v358_20_cursor.path()[v358_20_origin..(v358_20_origin + 1)]);
    let v359_3: Space = intersect(&(*CONSTANT_1),&(v359_2));
    let v359_4: Space = if has_head(&(v359_3)) { singleton(&[]) } else { Space::new() };
    drop(v359_3);
    let v359_5: Space = subtract(&(*CONSTANT_0),&(v359_4));
    drop(v359_4);
    let v359_8: Space = if (&(v359_5)).is_empty() { Space::new() } else {
      let v360_6: Path = concat_path(&(*p0),&v358_20_cursor.path()[v358_20_origin..(v358_20_origin + 1)]);
      let mut v360_7 = Space::new();
      let mut v360_7_write = v360_7.write_zipper();
      for v360_7_byte in v358_20_cursor.child_mask().iter() {
        v358_20_cursor.descend_to_existing_byte(v360_7_byte);
        {
        let v361_2: Space = singleton(&v358_20_cursor.path()[(v358_20_origin + 1)..(v358_20_origin + 2)]);
        let v361_3: Space = intersect(&(*CONSTANT_1),&(v361_2));
        let v361_4: Space = if has_head(&(v361_3)) { singleton(&[]) } else { Space::new() };
        drop(v361_3);
        let v361_5: Space = subtract(&(*CONSTANT_0),&(v361_4));
        drop(v361_4);
        let v361_8: Space = if (&(v361_5)).is_empty() { Space::new() } else {
          let v362_6: Path = concat_path(&(v360_6),&v358_20_cursor.path()[(v358_20_origin + 1)..(v358_20_origin + 2)]);
          let mut v362_7 = Space::new();
          let mut v362_7_write = v362_7.write_zipper();
          for v362_7_byte in v358_20_cursor.child_mask().iter() {
            v358_20_cursor.descend_to_existing_byte(v362_7_byte);
            {
            let v363_2: Space = singleton(&v358_20_cursor.path()[(v358_20_origin + 2)..(v358_20_origin + 3)]);
            let v363_3: Space = intersect(&(*CONSTANT_1),&(v363_2));
            let v363_4: Space = if has_head(&(v363_3)) { singleton(&[]) } else { Space::new() };
            drop(v363_3);
            let v363_5: Space = subtract(&(*CONSTANT_0),&(v363_4));
            drop(v363_4);
            let v363_8: Space = if (&(v363_5)).is_empty() { Space::new() } else {
              let v364_6: Path = concat_path(&(v362_6),&v358_20_cursor.path()[(v358_20_origin + 2)..(v358_20_origin + 3)]);
              let v364_7: Space = routine_34(c, &(v364_6), &v358_20_cursor);
              compose(&(v363_5),&(v364_7))
            };
            drop(v363_5);
            let v363_9: Space = intersect(&(*CONSTANT_1),&(v363_2));
            drop(v363_2);
            let v363_10: Space = if has_head(&(v363_9)) { singleton(&[]) } else { Space::new() };
            drop(v363_9);
            let v363_12: Space = if (&(v363_10)).is_empty() { Space::new() } else {
              let v365_6: Path = concat_path(&(v362_6),&v358_20_cursor.path()[(v358_20_origin + 2)..(v358_20_origin + 3)]);
              let v365_11: Space = routine_35(c, &(v365_6), &v358_20_cursor);
              drop(v365_6);
              compose(&(v363_10),&(v365_11))
            };
            drop(v363_10);
            let v363_13: Space = unite(&(v363_8),&(v363_12));
            join_wrapped_into(&mut v362_7_write,&((v363_13).read_zipper()),&[]);
            }
            v358_20_cursor.ascend(1);
          }
          drop(v362_7_write);
          compose(&(v361_5),&(v362_7))
        };
        drop(v361_5);
        let v361_9: Space = intersect(&(*CONSTANT_1),&(v361_2));
        drop(v361_2);
        let v361_10: Space = if has_head(&(v361_9)) { singleton(&[]) } else { Space::new() };
        drop(v361_9);
        let v361_12: Space = if (&(v361_10)).is_empty() { Space::new() } else {
          let v366_6: Path = concat_path(&(v360_6),&v358_20_cursor.path()[(v358_20_origin + 1)..(v358_20_origin + 2)]);
          let mut v366_11 = Space::new();
          let mut v366_11_write = v366_11.write_zipper();
          for v366_11_byte in v358_20_cursor.child_mask().iter() {
            v358_20_cursor.descend_to_existing_byte(v366_11_byte);
            {
            let v367_2: Space = singleton(&v358_20_cursor.path()[(v358_20_origin + 2)..(v358_20_origin + 3)]);
            let v367_3: Space = intersect(&(*CONSTANT_1),&(v367_2));
            let v367_4: Space = if has_head(&(v367_3)) { singleton(&[]) } else { Space::new() };
            drop(v367_3);
            let v367_5: Space = subtract(&(*CONSTANT_0),&(v367_4));
            drop(v367_4);
            let v367_8: Space = if (&(v367_5)).is_empty() { Space::new() } else {
              let v368_6: Path = concat_path(&(v366_6),&v358_20_cursor.path()[(v358_20_origin + 2)..(v358_20_origin + 3)]);
              let v368_7: Space = routine_34(c, &(v368_6), &v358_20_cursor);
              compose(&(v367_5),&(v368_7))
            };
            drop(v367_5);
            let v367_9: Space = intersect(&(*CONSTANT_1),&(v367_2));
            drop(v367_2);
            let v367_10: Space = if has_head(&(v367_9)) { singleton(&[]) } else { Space::new() };
            drop(v367_9);
            let v367_12: Space = if (&(v367_10)).is_empty() { Space::new() } else {
              let v369_6: Path = concat_path(&(v366_6),&v358_20_cursor.path()[(v358_20_origin + 2)..(v358_20_origin + 3)]);
              let v369_11: Space = routine_15(c, &(v369_6), &v358_20_cursor);
              drop(v369_6);
              compose(&(v367_10),&(v369_11))
            };
            drop(v367_10);
            let v367_13: Space = unite(&(v367_8),&(v367_12));
            join_wrapped_into(&mut v366_11_write,&((v367_13).read_zipper()),&[]);
            }
            v358_20_cursor.ascend(1);
          }
          drop(v366_11_write);
          drop(v366_6);
          compose(&(v361_10),&(v366_11))
        };
        drop(v361_10);
        let v361_13: Space = unite(&(v361_8),&(v361_12));
        join_wrapped_into(&mut v360_7_write,&((v361_13).read_zipper()),&[]);
        }
        v358_20_cursor.ascend(1);
      }
      drop(v360_7_write);
      compose(&(v359_5),&(v360_7))
    };
    drop(v359_5);
    let v359_9: Space = intersect(&(*CONSTANT_1),&(v359_2));
    drop(v359_2);
    let v359_10: Space = if has_head(&(v359_9)) { singleton(&[]) } else { Space::new() };
    drop(v359_9);
    let v359_12: Space = if (&(v359_10)).is_empty() { Space::new() } else {
      let v370_6: Path = concat_path(&(*p0),&v358_20_cursor.path()[v358_20_origin..(v358_20_origin + 1)]);
      let mut v370_11 = Space::new();
      let mut v370_11_write = v370_11.write_zipper();
      for v370_11_byte in v358_20_cursor.child_mask().iter() {
        v358_20_cursor.descend_to_existing_byte(v370_11_byte);
        {
        let v371_2: Space = singleton(&v358_20_cursor.path()[(v358_20_origin + 1)..(v358_20_origin + 2)]);
        let v371_3: Space = intersect(&(*CONSTANT_1),&(v371_2));
        let v371_4: Space = if has_head(&(v371_3)) { singleton(&[]) } else { Space::new() };
        drop(v371_3);
        let v371_5: Space = subtract(&(*CONSTANT_0),&(v371_4));
        drop(v371_4);
        let v371_8: Space = if (&(v371_5)).is_empty() { Space::new() } else {
          let v372_6: Path = concat_path(&(v370_6),&v358_20_cursor.path()[(v358_20_origin + 1)..(v358_20_origin + 2)]);
          let mut v372_7 = Space::new();
          let mut v372_7_write = v372_7.write_zipper();
          for v372_7_byte in v358_20_cursor.child_mask().iter() {
            v358_20_cursor.descend_to_existing_byte(v372_7_byte);
            {
            let v373_2: Space = singleton(&v358_20_cursor.path()[(v358_20_origin + 2)..(v358_20_origin + 3)]);
            let v373_3: Space = intersect(&(*CONSTANT_1),&(v373_2));
            let v373_4: Space = if has_head(&(v373_3)) { singleton(&[]) } else { Space::new() };
            drop(v373_3);
            let v373_5: Space = subtract(&(*CONSTANT_0),&(v373_4));
            drop(v373_4);
            let v373_8: Space = if (&(v373_5)).is_empty() { Space::new() } else {
              let v374_6: Path = concat_path(&(v372_6),&v358_20_cursor.path()[(v358_20_origin + 2)..(v358_20_origin + 3)]);
              let v374_7: Space = routine_34(c, &(v374_6), &v358_20_cursor);
              compose(&(v373_5),&(v374_7))
            };
            drop(v373_5);
            let v373_9: Space = intersect(&(*CONSTANT_1),&(v373_2));
            drop(v373_2);
            let v373_10: Space = if has_head(&(v373_9)) { singleton(&[]) } else { Space::new() };
            drop(v373_9);
            let v373_12: Space = if (&(v373_10)).is_empty() { Space::new() } else {
              let v375_6: Path = concat_path(&(v372_6),&v358_20_cursor.path()[(v358_20_origin + 2)..(v358_20_origin + 3)]);
              let v375_11: Space = routine_35(c, &(v375_6), &v358_20_cursor);
              drop(v375_6);
              compose(&(v373_10),&(v375_11))
            };
            drop(v373_10);
            let v373_13: Space = unite(&(v373_8),&(v373_12));
            join_wrapped_into(&mut v372_7_write,&((v373_13).read_zipper()),&[]);
            }
            v358_20_cursor.ascend(1);
          }
          drop(v372_7_write);
          drop(v372_6);
          compose(&(v371_5),&(v372_7))
        };
        drop(v371_5);
        let v371_9: Space = intersect(&(*CONSTANT_1),&(v371_2));
        drop(v371_2);
        let v371_10: Space = if has_head(&(v371_9)) { singleton(&[]) } else { Space::new() };
        drop(v371_9);
        let v371_11: Space = compose(&(v371_10),&v358_20_cursor);
        drop(v371_10);
        let v371_12: Space = unite(&(v371_8),&(v371_11));
        drop(v371_11);
        join_wrapped_into(&mut v370_11_write,&((v371_12).read_zipper()),&[]);
        }
        v358_20_cursor.ascend(1);
      }
      drop(v370_11_write);
      drop(v370_6);
      compose(&(v359_10),&(v370_11))
    };
    drop(v359_10);
    let v359_13: Space = unite(&(v359_8),&(v359_12));
    join_wrapped_into(&mut v358_20_write,&((v359_13).read_zipper()),&[]);
    }
    v358_20_cursor.ascend(1);
  }
  drop(v358_20_cursor);
  drop(v358_20_write);
  (v358_20).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v376_14 = Space::new();
  let mut v376_14_write = v376_14.write_zipper();
  let mut v376_14_cursor = (*s0).read_zipper();
  let v376_14_origin = v376_14_cursor.path().len();
  for v376_14_byte in v376_14_cursor.child_mask().iter() {
    v376_14_cursor.descend_to_existing_byte(v376_14_byte);
    {
    let v377_2: Space = singleton(&v376_14_cursor.path()[v376_14_origin..(v376_14_origin + 1)]);
    let v377_3: Space = intersect(&(*CONSTANT_1),&(v377_2));
    let v377_4: Space = if has_head(&(v377_3)) { singleton(&[]) } else { Space::new() };
    drop(v377_3);
    let v377_5: Space = subtract(&(*CONSTANT_0),&(v377_4));
    drop(v377_4);
    let v377_8: Space = if (&(v377_5)).is_empty() { Space::new() } else {
      let v378_6: Path = concat_path(&(*p0),&v376_14_cursor.path()[v376_14_origin..(v376_14_origin + 1)]);
      let mut v378_7 = Space::new();
      let mut v378_7_write = v378_7.write_zipper();
      for v378_7_byte in v376_14_cursor.child_mask().iter() {
        v376_14_cursor.descend_to_existing_byte(v378_7_byte);
        {
        let v379_2: Space = singleton(&v376_14_cursor.path()[(v376_14_origin + 1)..(v376_14_origin + 2)]);
        let v379_3: Space = intersect(&(*CONSTANT_1),&(v379_2));
        let v379_4: Space = if has_head(&(v379_3)) { singleton(&[]) } else { Space::new() };
        drop(v379_3);
        let v379_5: Space = subtract(&(*CONSTANT_0),&(v379_4));
        drop(v379_4);
        let v379_8: Space = if (&(v379_5)).is_empty() { Space::new() } else {
          let v380_6: Path = concat_path(&(v378_6),&v376_14_cursor.path()[(v376_14_origin + 1)..(v376_14_origin + 2)]);
          let mut v380_7 = Space::new();
          let mut v380_7_write = v380_7.write_zipper();
          for v380_7_byte in v376_14_cursor.child_mask().iter() {
            v376_14_cursor.descend_to_existing_byte(v380_7_byte);
            {
            let v381_2: Space = singleton(&v376_14_cursor.path()[(v376_14_origin + 2)..(v376_14_origin + 3)]);
            let v381_3: Space = intersect(&(*CONSTANT_1),&(v381_2));
            let v381_4: Space = if has_head(&(v381_3)) { singleton(&[]) } else { Space::new() };
            drop(v381_3);
            let v381_5: Space = subtract(&(*CONSTANT_0),&(v381_4));
            drop(v381_4);
            let v381_8: Space = if (&(v381_5)).is_empty() { Space::new() } else {
              let v382_6: Path = concat_path(&(v380_6),&v376_14_cursor.path()[(v376_14_origin + 2)..(v376_14_origin + 3)]);
              let v382_7: Space = routine_34(c, &(v382_6), &v376_14_cursor);
              compose(&(v381_5),&(v382_7))
            };
            drop(v381_5);
            let v381_9: Space = intersect(&(*CONSTANT_1),&(v381_2));
            drop(v381_2);
            let v381_10: Space = if has_head(&(v381_9)) { singleton(&[]) } else { Space::new() };
            drop(v381_9);
            let v381_12: Space = if (&(v381_10)).is_empty() { Space::new() } else {
              let v383_6: Path = concat_path(&(v380_6),&v376_14_cursor.path()[(v376_14_origin + 2)..(v376_14_origin + 3)]);
              let v383_11: Space = routine_35(c, &(v383_6), &v376_14_cursor);
              drop(v383_6);
              compose(&(v381_10),&(v383_11))
            };
            drop(v381_10);
            let v381_13: Space = unite(&(v381_8),&(v381_12));
            join_wrapped_into(&mut v380_7_write,&((v381_13).read_zipper()),&[]);
            }
            v376_14_cursor.ascend(1);
          }
          drop(v380_7_write);
          compose(&(v379_5),&(v380_7))
        };
        drop(v379_5);
        let v379_9: Space = intersect(&(*CONSTANT_1),&(v379_2));
        drop(v379_2);
        let v379_10: Space = if has_head(&(v379_9)) { singleton(&[]) } else { Space::new() };
        drop(v379_9);
        let v379_12: Space = if (&(v379_10)).is_empty() { Space::new() } else {
          let v384_6: Path = concat_path(&(v378_6),&v376_14_cursor.path()[(v376_14_origin + 1)..(v376_14_origin + 2)]);
          let mut v384_11 = Space::new();
          let mut v384_11_write = v384_11.write_zipper();
          for v384_11_byte in v376_14_cursor.child_mask().iter() {
            v376_14_cursor.descend_to_existing_byte(v384_11_byte);
            {
            let v385_2: Space = singleton(&v376_14_cursor.path()[(v376_14_origin + 2)..(v376_14_origin + 3)]);
            let v385_3: Space = intersect(&(*CONSTANT_1),&(v385_2));
            let v385_4: Space = if has_head(&(v385_3)) { singleton(&[]) } else { Space::new() };
            drop(v385_3);
            let v385_5: Space = subtract(&(*CONSTANT_0),&(v385_4));
            drop(v385_4);
            let v385_8: Space = if (&(v385_5)).is_empty() { Space::new() } else {
              let v386_6: Path = concat_path(&(v384_6),&v376_14_cursor.path()[(v376_14_origin + 2)..(v376_14_origin + 3)]);
              let v386_7: Space = routine_34(c, &(v386_6), &v376_14_cursor);
              compose(&(v385_5),&(v386_7))
            };
            drop(v385_5);
            let v385_9: Space = intersect(&(*CONSTANT_1),&(v385_2));
            drop(v385_2);
            let v385_10: Space = if has_head(&(v385_9)) { singleton(&[]) } else { Space::new() };
            drop(v385_9);
            let v385_12: Space = if (&(v385_10)).is_empty() { Space::new() } else {
              let v387_6: Path = concat_path(&(v384_6),&v376_14_cursor.path()[(v376_14_origin + 2)..(v376_14_origin + 3)]);
              let v387_11: Space = routine_15(c, &(v387_6), &v376_14_cursor);
              drop(v387_6);
              compose(&(v385_10),&(v387_11))
            };
            drop(v385_10);
            let v385_13: Space = unite(&(v385_8),&(v385_12));
            join_wrapped_into(&mut v384_11_write,&((v385_13).read_zipper()),&[]);
            }
            v376_14_cursor.ascend(1);
          }
          drop(v384_11_write);
          drop(v384_6);
          compose(&(v379_10),&(v384_11))
        };
        drop(v379_10);
        let v379_13: Space = unite(&(v379_8),&(v379_12));
        join_wrapped_into(&mut v378_7_write,&((v379_13).read_zipper()),&[]);
        }
        v376_14_cursor.ascend(1);
      }
      drop(v378_7_write);
      drop(v378_6);
      compose(&(v377_5),&(v378_7))
    };
    drop(v377_5);
    let v377_9: Space = intersect(&(*CONSTANT_1),&(v377_2));
    drop(v377_2);
    let v377_10: Space = if has_head(&(v377_9)) { singleton(&[]) } else { Space::new() };
    drop(v377_9);
    let v377_11: Space = compose(&(v377_10),&v376_14_cursor);
    drop(v377_10);
    let v377_12: Space = unite(&(v377_8),&(v377_11));
    drop(v377_11);
    join_wrapped_into(&mut v376_14_write,&((v377_12).read_zipper()),&[]);
    }
    v376_14_cursor.ascend(1);
  }
  drop(v376_14_cursor);
  drop(v376_14_write);
  (v376_14).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v388_8 = Space::new();
  let mut v388_8_write = v388_8.write_zipper();
  let mut v388_8_cursor = (*s0).read_zipper();
  let v388_8_origin = v388_8_cursor.path().len();
  for v388_8_byte in v388_8_cursor.child_mask().iter() {
    v388_8_cursor.descend_to_existing_byte(v388_8_byte);
    {
    let v389_2: Space = singleton(&v388_8_cursor.path()[v388_8_origin..(v388_8_origin + 1)]);
    let v389_3: Space = intersect(&(*CONSTANT_1),&(v389_2));
    let v389_4: Space = if has_head(&(v389_3)) { singleton(&[]) } else { Space::new() };
    drop(v389_3);
    let v389_5: Space = subtract(&(*CONSTANT_0),&(v389_4));
    drop(v389_4);
    let v389_8: Space = if (&(v389_5)).is_empty() { Space::new() } else {
      let v390_6: Path = concat_path(&(*p0),&v388_8_cursor.path()[v388_8_origin..(v388_8_origin + 1)]);
      let mut v390_7 = Space::new();
      let mut v390_7_write = v390_7.write_zipper();
      for v390_7_byte in v388_8_cursor.child_mask().iter() {
        v388_8_cursor.descend_to_existing_byte(v390_7_byte);
        {
        let v391_2: Space = singleton(&v388_8_cursor.path()[(v388_8_origin + 1)..(v388_8_origin + 2)]);
        let v391_3: Space = intersect(&(*CONSTANT_1),&(v391_2));
        drop(v391_2);
        let v391_4: Space = if has_head(&(v391_3)) { singleton(&[]) } else { Space::new() };
        drop(v391_3);
        let v391_7: Space = if (&(v391_4)).is_empty() { Space::new() } else {
          let v392_5: Path = concat_path(&(v390_6),&v388_8_cursor.path()[(v388_8_origin + 1)..(v388_8_origin + 2)]);
          let mut v392_6 = Space::new();
          let mut v392_6_write = v392_6.write_zipper();
          for v392_6_byte in v388_8_cursor.child_mask().iter() {
            v388_8_cursor.descend_to_existing_byte(v392_6_byte);
            {
            let v393_2: Space = singleton(&v388_8_cursor.path()[(v388_8_origin + 2)..(v388_8_origin + 3)]);
            let v393_3: Space = intersect(&(*CONSTANT_1),&(v393_2));
            drop(v393_2);
            let v393_4: Space = if has_head(&(v393_3)) { singleton(&[]) } else { Space::new() };
            drop(v393_3);
            let v393_7: Space = if (&(v393_4)).is_empty() { Space::new() } else {
              let v394_5: Path = concat_path(&(v392_5),&v388_8_cursor.path()[(v388_8_origin + 2)..(v388_8_origin + 3)]);
              let v394_6: Space = routine_12(c, &(v394_5), &v388_8_cursor);
              drop(v394_5);
              compose(&(v393_4),&(v394_6))
            };
            drop(v393_4);
            join_wrapped_into(&mut v392_6_write,&((v393_7).read_zipper()),&[]);
            }
            v388_8_cursor.ascend(1);
          }
          drop(v392_6_write);
          drop(v392_5);
          compose(&(v391_4),&(v392_6))
        };
        drop(v391_4);
        join_wrapped_into(&mut v390_7_write,&((v391_7).read_zipper()),&[]);
        }
        v388_8_cursor.ascend(1);
      }
      drop(v390_7_write);
      drop(v390_6);
      compose(&(v389_5),&(v390_7))
    };
    drop(v389_5);
    let v389_9: Space = intersect(&(*CONSTANT_1),&(v389_2));
    drop(v389_2);
    let v389_10: Space = if has_head(&(v389_9)) { singleton(&[]) } else { Space::new() };
    drop(v389_9);
    let v389_12: Space = if (&(v389_10)).is_empty() { Space::new() } else {
      let mut v395_11 = Space::new();
      let mut v395_11_write = v395_11.write_zipper();
      for v395_11_byte in v388_8_cursor.child_mask().iter() {
        v388_8_cursor.descend_to_existing_byte(v395_11_byte);
        {
        let v396_2: Space = singleton(&v388_8_cursor.path()[(v388_8_origin + 1)..(v388_8_origin + 2)]);
        let v396_3: Space = intersect(&(*CONSTANT_1),&(v396_2));
        drop(v396_2);
        let v396_4: Space = if has_head(&(v396_3)) { singleton(&[]) } else { Space::new() };
        drop(v396_3);
        let v396_5: Space = compose(&(v396_4),&v388_8_cursor);
        drop(v396_4);
        join_wrapped_into(&mut v395_11_write,&((v396_5).read_zipper()),&[]);
        }
        v388_8_cursor.ascend(1);
      }
      drop(v395_11_write);
      compose(&(v389_10),&(v395_11))
    };
    drop(v389_10);
    let v389_13: Space = unite(&(v389_8),&(v389_12));
    drop(v389_12);
    join_wrapped_into(&mut v388_8_write,&((v389_13).read_zipper()),&[]);
    }
    v388_8_cursor.ascend(1);
  }
  drop(v388_8_cursor);
  drop(v388_8_write);
  (v388_8).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v397_7 = Space::new();
  let mut v397_7_write = v397_7.write_zipper();
  let mut v397_7_cursor = (*s0).read_zipper();
  let v397_7_origin = v397_7_cursor.path().len();
  for v397_7_byte in v397_7_cursor.child_mask().iter() {
    v397_7_cursor.descend_to_existing_byte(v397_7_byte);
    {
    let v398_2: Space = singleton(&v397_7_cursor.path()[v397_7_origin..(v397_7_origin + 1)]);
    let v398_3: Space = intersect(&(*CONSTANT_1),&(v398_2));
    let v398_4: Space = if has_head(&(v398_3)) { singleton(&[]) } else { Space::new() };
    drop(v398_3);
    let v398_5: Space = subtract(&(*CONSTANT_0),&(v398_4));
    drop(v398_4);
    let v398_8: Space = if (&(v398_5)).is_empty() { Space::new() } else {
      let v399_6: Path = concat_path(&(*p0),&v397_7_cursor.path()[v397_7_origin..(v397_7_origin + 1)]);
      let mut v399_7 = Space::new();
      let mut v399_7_write = v399_7.write_zipper();
      for v399_7_byte in v397_7_cursor.child_mask().iter() {
        v397_7_cursor.descend_to_existing_byte(v399_7_byte);
        {
        let v400_2: Space = singleton(&v397_7_cursor.path()[(v397_7_origin + 1)..(v397_7_origin + 2)]);
        let v400_3: Space = intersect(&(*CONSTANT_1),&(v400_2));
        drop(v400_2);
        let v400_4: Space = if has_head(&(v400_3)) { singleton(&[]) } else { Space::new() };
        drop(v400_3);
        let v400_7: Space = if (&(v400_4)).is_empty() { Space::new() } else {
          let v401_5: Path = concat_path(&(v399_6),&v397_7_cursor.path()[(v397_7_origin + 1)..(v397_7_origin + 2)]);
          let mut v401_6 = Space::new();
          let mut v401_6_write = v401_6.write_zipper();
          for v401_6_byte in v397_7_cursor.child_mask().iter() {
            v397_7_cursor.descend_to_existing_byte(v401_6_byte);
            {
            let v402_2: Space = singleton(&v397_7_cursor.path()[(v397_7_origin + 2)..(v397_7_origin + 3)]);
            let v402_3: Space = intersect(&(*CONSTANT_1),&(v402_2));
            drop(v402_2);
            let v402_4: Space = if has_head(&(v402_3)) { singleton(&[]) } else { Space::new() };
            drop(v402_3);
            let v402_7: Space = if (&(v402_4)).is_empty() { Space::new() } else {
              let v403_5: Path = concat_path(&(v401_5),&v397_7_cursor.path()[(v397_7_origin + 2)..(v397_7_origin + 3)]);
              let v403_6: Space = routine_12(c, &(v403_5), &v397_7_cursor);
              drop(v403_5);
              compose(&(v402_4),&(v403_6))
            };
            drop(v402_4);
            join_wrapped_into(&mut v401_6_write,&((v402_7).read_zipper()),&[]);
            }
            v397_7_cursor.ascend(1);
          }
          drop(v401_6_write);
          drop(v401_5);
          compose(&(v400_4),&(v401_6))
        };
        drop(v400_4);
        join_wrapped_into(&mut v399_7_write,&((v400_7).read_zipper()),&[]);
        }
        v397_7_cursor.ascend(1);
      }
      drop(v399_7_write);
      drop(v399_6);
      compose(&(v398_5),&(v399_7))
    };
    drop(v398_5);
    let v398_9: Space = intersect(&(*CONSTANT_1),&(v398_2));
    drop(v398_2);
    let v398_10: Space = if has_head(&(v398_9)) { singleton(&[]) } else { Space::new() };
    drop(v398_9);
    let v398_11: Space = compose(&(v398_10),&v397_7_cursor);
    drop(v398_10);
    let v398_12: Space = unite(&(v398_8),&(v398_11));
    drop(v398_11);
    join_wrapped_into(&mut v397_7_write,&((v398_12).read_zipper()),&[]);
    }
    v397_7_cursor.ascend(1);
  }
  drop(v397_7_cursor);
  drop(v397_7_write);
  (v397_7).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v404_8 = Space::new();
  let mut v404_8_write = v404_8.write_zipper();
  let mut v404_8_cursor = (*s0).read_zipper();
  let v404_8_origin = v404_8_cursor.path().len();
  for v404_8_byte in v404_8_cursor.child_mask().iter() {
    v404_8_cursor.descend_to_existing_byte(v404_8_byte);
    {
    let v405_2: Space = singleton(&v404_8_cursor.path()[v404_8_origin..(v404_8_origin + 1)]);
    let v405_3: Space = intersect(&(*CONSTANT_1),&(v405_2));
    let v405_4: Space = if has_head(&(v405_3)) { singleton(&[]) } else { Space::new() };
    drop(v405_3);
    let v405_5: Space = subtract(&(*CONSTANT_0),&(v405_4));
    drop(v405_4);
    let v405_8: Space = if (&(v405_5)).is_empty() { Space::new() } else {
      let v406_6: Path = concat_path(&(*p0),&v404_8_cursor.path()[v404_8_origin..(v404_8_origin + 1)]);
      let mut v406_7 = Space::new();
      let mut v406_7_write = v406_7.write_zipper();
      for v406_7_byte in v404_8_cursor.child_mask().iter() {
        v404_8_cursor.descend_to_existing_byte(v406_7_byte);
        {
        let v407_2: Space = singleton(&v404_8_cursor.path()[(v404_8_origin + 1)..(v404_8_origin + 2)]);
        let v407_3: Space = intersect(&(*CONSTANT_1),&(v407_2));
        drop(v407_2);
        let v407_4: Space = if has_head(&(v407_3)) { singleton(&[]) } else { Space::new() };
        drop(v407_3);
        let v407_7: Space = if (&(v407_4)).is_empty() { Space::new() } else {
          let v408_5: Path = concat_path(&(v406_6),&v404_8_cursor.path()[(v404_8_origin + 1)..(v404_8_origin + 2)]);
          let mut v408_6 = Space::new();
          let mut v408_6_write = v408_6.write_zipper();
          for v408_6_byte in v404_8_cursor.child_mask().iter() {
            v404_8_cursor.descend_to_existing_byte(v408_6_byte);
            {
            let v409_2: Space = singleton(&v404_8_cursor.path()[(v404_8_origin + 2)..(v404_8_origin + 3)]);
            let v409_3: Space = intersect(&(*CONSTANT_1),&(v409_2));
            drop(v409_2);
            let v409_4: Space = if has_head(&(v409_3)) { singleton(&[]) } else { Space::new() };
            drop(v409_3);
            let v409_7: Space = if (&(v409_4)).is_empty() { Space::new() } else {
              let v410_5: Path = concat_path(&(v408_5),&v404_8_cursor.path()[(v404_8_origin + 2)..(v404_8_origin + 3)]);
              let v410_6: Space = routine_15(c, &(v410_5), &v404_8_cursor);
              drop(v410_5);
              compose(&(v409_4),&(v410_6))
            };
            drop(v409_4);
            join_wrapped_into(&mut v408_6_write,&((v409_7).read_zipper()),&[]);
            }
            v404_8_cursor.ascend(1);
          }
          drop(v408_6_write);
          drop(v408_5);
          compose(&(v407_4),&(v408_6))
        };
        drop(v407_4);
        join_wrapped_into(&mut v406_7_write,&((v407_7).read_zipper()),&[]);
        }
        v404_8_cursor.ascend(1);
      }
      drop(v406_7_write);
      drop(v406_6);
      compose(&(v405_5),&(v406_7))
    };
    drop(v405_5);
    let v405_9: Space = intersect(&(*CONSTANT_1),&(v405_2));
    drop(v405_2);
    let v405_10: Space = if has_head(&(v405_9)) { singleton(&[]) } else { Space::new() };
    drop(v405_9);
    let v405_12: Space = if (&(v405_10)).is_empty() { Space::new() } else {
      let mut v411_11 = Space::new();
      let mut v411_11_write = v411_11.write_zipper();
      for v411_11_byte in v404_8_cursor.child_mask().iter() {
        v404_8_cursor.descend_to_existing_byte(v411_11_byte);
        {
        let v412_2: Space = singleton(&v404_8_cursor.path()[(v404_8_origin + 1)..(v404_8_origin + 2)]);
        let v412_3: Space = intersect(&(*CONSTANT_1),&(v412_2));
        drop(v412_2);
        let v412_4: Space = if has_head(&(v412_3)) { singleton(&[]) } else { Space::new() };
        drop(v412_3);
        let v412_5: Space = compose(&(v412_4),&v404_8_cursor);
        drop(v412_4);
        join_wrapped_into(&mut v411_11_write,&((v412_5).read_zipper()),&[]);
        }
        v404_8_cursor.ascend(1);
      }
      drop(v411_11_write);
      compose(&(v405_10),&(v411_11))
    };
    drop(v405_10);
    let v405_13: Space = unite(&(v405_8),&(v405_12));
    drop(v405_12);
    join_wrapped_into(&mut v404_8_write,&((v405_13).read_zipper()),&[]);
    }
    v404_8_cursor.ascend(1);
  }
  drop(v404_8_cursor);
  drop(v404_8_write);
  (v404_8).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v413_7 = Space::new();
  let mut v413_7_write = v413_7.write_zipper();
  let mut v413_7_cursor = (*s0).read_zipper();
  let v413_7_origin = v413_7_cursor.path().len();
  for v413_7_byte in v413_7_cursor.child_mask().iter() {
    v413_7_cursor.descend_to_existing_byte(v413_7_byte);
    {
    let v414_2: Space = singleton(&v413_7_cursor.path()[v413_7_origin..(v413_7_origin + 1)]);
    let v414_3: Space = intersect(&(*CONSTANT_1),&(v414_2));
    let v414_4: Space = if has_head(&(v414_3)) { singleton(&[]) } else { Space::new() };
    drop(v414_3);
    let v414_5: Space = subtract(&(*CONSTANT_0),&(v414_4));
    drop(v414_4);
    let v414_8: Space = if (&(v414_5)).is_empty() { Space::new() } else {
      let v415_6: Path = concat_path(&(*p0),&v413_7_cursor.path()[v413_7_origin..(v413_7_origin + 1)]);
      let mut v415_7 = Space::new();
      let mut v415_7_write = v415_7.write_zipper();
      for v415_7_byte in v413_7_cursor.child_mask().iter() {
        v413_7_cursor.descend_to_existing_byte(v415_7_byte);
        {
        let v416_2: Space = singleton(&v413_7_cursor.path()[(v413_7_origin + 1)..(v413_7_origin + 2)]);
        let v416_3: Space = intersect(&(*CONSTANT_1),&(v416_2));
        drop(v416_2);
        let v416_4: Space = if has_head(&(v416_3)) { singleton(&[]) } else { Space::new() };
        drop(v416_3);
        let v416_7: Space = if (&(v416_4)).is_empty() { Space::new() } else {
          let v417_5: Path = concat_path(&(v415_6),&v413_7_cursor.path()[(v413_7_origin + 1)..(v413_7_origin + 2)]);
          let mut v417_6 = Space::new();
          let mut v417_6_write = v417_6.write_zipper();
          for v417_6_byte in v413_7_cursor.child_mask().iter() {
            v413_7_cursor.descend_to_existing_byte(v417_6_byte);
            {
            let v418_2: Space = singleton(&v413_7_cursor.path()[(v413_7_origin + 2)..(v413_7_origin + 3)]);
            let v418_3: Space = intersect(&(*CONSTANT_1),&(v418_2));
            drop(v418_2);
            let v418_4: Space = if has_head(&(v418_3)) { singleton(&[]) } else { Space::new() };
            drop(v418_3);
            let v418_7: Space = if (&(v418_4)).is_empty() { Space::new() } else {
              let v419_5: Path = concat_path(&(v417_5),&v413_7_cursor.path()[(v413_7_origin + 2)..(v413_7_origin + 3)]);
              let v419_6: Space = routine_15(c, &(v419_5), &v413_7_cursor);
              drop(v419_5);
              compose(&(v418_4),&(v419_6))
            };
            drop(v418_4);
            join_wrapped_into(&mut v417_6_write,&((v418_7).read_zipper()),&[]);
            }
            v413_7_cursor.ascend(1);
          }
          drop(v417_6_write);
          drop(v417_5);
          compose(&(v416_4),&(v417_6))
        };
        drop(v416_4);
        join_wrapped_into(&mut v415_7_write,&((v416_7).read_zipper()),&[]);
        }
        v413_7_cursor.ascend(1);
      }
      drop(v415_7_write);
      drop(v415_6);
      compose(&(v414_5),&(v415_7))
    };
    drop(v414_5);
    let v414_9: Space = intersect(&(*CONSTANT_1),&(v414_2));
    drop(v414_2);
    let v414_10: Space = if has_head(&(v414_9)) { singleton(&[]) } else { Space::new() };
    drop(v414_9);
    let v414_11: Space = compose(&(v414_10),&v413_7_cursor);
    drop(v414_10);
    let v414_12: Space = unite(&(v414_8),&(v414_11));
    drop(v414_11);
    join_wrapped_into(&mut v413_7_write,&((v414_12).read_zipper()),&[]);
    }
    v413_7_cursor.ascend(1);
  }
  drop(v413_7_cursor);
  drop(v413_7_write);
  (v413_7).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v420_4 = Space::new();
  let mut v420_4_write = v420_4.write_zipper();
  let mut v420_4_cursor = (*s0).read_zipper();
  let v420_4_origin = v420_4_cursor.path().len();
  for v420_4_byte in v420_4_cursor.child_mask().iter() {
    v420_4_cursor.descend_to_existing_byte(v420_4_byte);
    {
    let v421_2: Space = singleton(&v420_4_cursor.path()[v420_4_origin..(v420_4_origin + 1)]);
    let v421_3: Space = intersect(&(*CONSTANT_1),&(v421_2));
    drop(v421_2);
    let v421_4: Space = if has_head(&(v421_3)) { singleton(&[]) } else { Space::new() };
    drop(v421_3);
    let v421_6: Space = if (&(v421_4)).is_empty() { Space::new() } else {
      let mut v422_5 = Space::new();
      let mut v422_5_write = v422_5.write_zipper();
      for v422_5_byte in v420_4_cursor.child_mask().iter() {
        v420_4_cursor.descend_to_existing_byte(v422_5_byte);
        {
        let v423_2: Space = singleton(&v420_4_cursor.path()[(v420_4_origin + 1)..(v420_4_origin + 2)]);
        let v423_3: Space = intersect(&(*CONSTANT_1),&(v423_2));
        drop(v423_2);
        let v423_4: Space = if has_head(&(v423_3)) { singleton(&[]) } else { Space::new() };
        drop(v423_3);
        let v423_5: Space = compose(&(v423_4),&v420_4_cursor);
        drop(v423_4);
        join_wrapped_into(&mut v422_5_write,&((v423_5).read_zipper()),&[]);
        }
        v420_4_cursor.ascend(1);
      }
      drop(v422_5_write);
      compose(&(v421_4),&(v422_5))
    };
    drop(v421_4);
    join_wrapped_into(&mut v420_4_write,&((v421_6).read_zipper()),&[]);
    }
    v420_4_cursor.ascend(1);
  }
  drop(v420_4_cursor);
  drop(v420_4_write);
  (v420_4).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v424_3 = Space::new();
  let mut v424_3_write = v424_3.write_zipper();
  let mut v424_3_cursor = (*s0).read_zipper();
  let v424_3_origin = v424_3_cursor.path().len();
  for v424_3_byte in v424_3_cursor.child_mask().iter() {
    v424_3_cursor.descend_to_existing_byte(v424_3_byte);
    {
    let v425_2: Space = singleton(&v424_3_cursor.path()[v424_3_origin..(v424_3_origin + 1)]);
    let v425_3: Space = intersect(&(*CONSTANT_1),&(v425_2));
    drop(v425_2);
    let v425_4: Space = if has_head(&(v425_3)) { singleton(&[]) } else { Space::new() };
    drop(v425_3);
    let v425_5: Space = compose(&(v425_4),&v424_3_cursor);
    drop(v425_4);
    join_wrapped_into(&mut v424_3_write,&((v425_5).read_zipper()),&[]);
    }
    v424_3_cursor.ascend(1);
  }
  drop(v424_3_cursor);
  drop(v424_3_write);
  (v424_3).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v426_4 = Space::new();
  let mut v426_4_write = v426_4.write_zipper();
  let mut v426_4_cursor = (*s0).read_zipper();
  let v426_4_origin = v426_4_cursor.path().len();
  for v426_4_byte in v426_4_cursor.child_mask().iter() {
    v426_4_cursor.descend_to_existing_byte(v426_4_byte);
    {
    let v427_2: Space = singleton(&v426_4_cursor.path()[v426_4_origin..(v426_4_origin + 1)]);
    let v427_3: Space = intersect(&(*CONSTANT_1),&(v427_2));
    drop(v427_2);
    let v427_4: Space = if has_head(&(v427_3)) { singleton(&[]) } else { Space::new() };
    drop(v427_3);
    let v427_6: Space = if (&(v427_4)).is_empty() { Space::new() } else {
      let mut v428_5 = Space::new();
      let mut v428_5_write = v428_5.write_zipper();
      for v428_5_byte in v426_4_cursor.child_mask().iter() {
        v426_4_cursor.descend_to_existing_byte(v428_5_byte);
        {
        let v429_2: Space = singleton(&v426_4_cursor.path()[(v426_4_origin + 1)..(v426_4_origin + 2)]);
        let v429_3: Space = intersect(&(*CONSTANT_1),&(v429_2));
        drop(v429_2);
        let v429_4: Space = if has_head(&(v429_3)) { singleton(&[]) } else { Space::new() };
        drop(v429_3);
        let v429_5: Space = compose(&(v429_4),&v426_4_cursor);
        drop(v429_4);
        join_wrapped_into(&mut v428_5_write,&((v429_5).read_zipper()),&[]);
        }
        v426_4_cursor.ascend(1);
      }
      drop(v428_5_write);
      compose(&(v427_4),&(v428_5))
    };
    drop(v427_4);
    join_wrapped_into(&mut v426_4_write,&((v427_6).read_zipper()),&[]);
    }
    v426_4_cursor.ascend(1);
  }
  drop(v426_4_cursor);
  drop(v426_4_write);
  (v426_4).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v430_3 = Space::new();
  let mut v430_3_write = v430_3.write_zipper();
  let mut v430_3_cursor = (*s0).read_zipper();
  let v430_3_origin = v430_3_cursor.path().len();
  for v430_3_byte in v430_3_cursor.child_mask().iter() {
    v430_3_cursor.descend_to_existing_byte(v430_3_byte);
    {
    let v431_2: Space = singleton(&v430_3_cursor.path()[v430_3_origin..(v430_3_origin + 1)]);
    let v431_3: Space = intersect(&(*CONSTANT_1),&(v431_2));
    drop(v431_2);
    let v431_4: Space = if has_head(&(v431_3)) { singleton(&[]) } else { Space::new() };
    drop(v431_3);
    let v431_5: Space = compose(&(v431_4),&v430_3_cursor);
    drop(v431_4);
    join_wrapped_into(&mut v430_3_write,&((v431_5).read_zipper()),&[]);
    }
    v430_3_cursor.ascend(1);
  }
  drop(v430_3_cursor);
  drop(v430_3_write);
  (v430_3).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v432_2: Space = Space::new();
  (v432_2).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v433_3 = Space::new();
  let mut v433_3_write = v433_3.write_zipper();
  let mut v433_3_cursor = (*s0).read_zipper();
  let v433_3_origin = v433_3_cursor.path().len();
  for v433_3_byte in v433_3_cursor.child_mask().iter() {
    v433_3_cursor.descend_to_existing_byte(v433_3_byte);
    {
    let v434_2: Space = singleton(&v433_3_cursor.path()[v433_3_origin..(v433_3_origin + 1)]);
    let v434_3: Space = intersect(&(*CONSTANT_1),&(v434_2));
    drop(v434_2);
    let v434_4: Space = if has_head(&(v434_3)) { singleton(&[]) } else { Space::new() };
    drop(v434_3);
    let v434_5: Space = compose(&(v434_4),&v433_3_cursor);
    drop(v434_4);
    join_wrapped_into(&mut v433_3_write,&((v434_5).read_zipper()),&[]);
    }
    v433_3_cursor.ascend(1);
  }
  drop(v433_3_cursor);
  drop(v433_3_write);
  (v433_3).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v435_2: Space = Space::new();
  (v435_2).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v436_3 = Space::new();
  let mut v436_3_write = v436_3.write_zipper();
  let mut v436_3_cursor = (*s0).read_zipper();
  let v436_3_origin = v436_3_cursor.path().len();
  for v436_3_byte in v436_3_cursor.child_mask().iter() {
    v436_3_cursor.descend_to_existing_byte(v436_3_byte);
    {
    let v437_2: Space = singleton(&v436_3_cursor.path()[v436_3_origin..(v436_3_origin + 1)]);
    let v437_3: Space = intersect(&(*CONSTANT_1),&(v437_2));
    drop(v437_2);
    let v437_4: Space = if has_head(&(v437_3)) { singleton(&[]) } else { Space::new() };
    drop(v437_3);
    let v437_5: Space = compose(&(v437_4),&v436_3_cursor);
    drop(v437_4);
    join_wrapped_into(&mut v436_3_write,&((v437_5).read_zipper()),&[]);
    }
    v436_3_cursor.ascend(1);
  }
  drop(v436_3_cursor);
  drop(v436_3_write);
  (v436_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
