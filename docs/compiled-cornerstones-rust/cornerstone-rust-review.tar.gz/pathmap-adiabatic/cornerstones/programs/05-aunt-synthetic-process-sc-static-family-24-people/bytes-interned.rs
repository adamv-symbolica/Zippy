#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,24]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("36 8 0 0 0 0 0 0 0 6 8 0 0 0 0 0 0 0 11 8 0 0 0 1 0 0 0 6 8 0 0 0 1 0 0 0 7 8 0 0 0 2 0 0 0 7 8 0 0 0 2 0 0 0 8 8 0 0 0 3 0 0 0 8 8 0 0 0 3 0 0 0 9 8 0 0 0 4 0 0 0 9 8 0 0 0 4 0 0 0 10 8 0 0 0 5 0 0 0 10 8 0 0 0 5 0 0 0 11 8 0 0 0 6 0 0 0 12 8 0 0 0 6 0 0 0 17 8 0 0 0 7 0 0 0 12 8 0 0 0 7 0 0 0 13 8 0 0 0 8 0 0 0 13 8 0 0 0 8 0 0 0 14 8 0 0 0 9 0 0 0 14 8 0 0 0 9 0 0 0 15 8 0 0 0 10 0 0 0 15 8 0 0 0 10 0 0 0 16 8 0 0 0 11 0 0 0 16 8 0 0 0 11 0 0 0 17 8 0 0 0 12 0 0 0 18 8 0 0 0 12 0 0 0 23 8 0 0 0 13 0 0 0 18 8 0 0 0 13 0 0 0 19 8 0 0 0 14 0 0 0 19 8 0 0 0 14 0 0 0 20 8 0 0 0 15 0 0 0 20 8 0 0 0 15 0 0 0 21 8 0 0 0 16 0 0 0 21 8 0 0 0 16 0 0 0 22 8 0 0 0 17 0 0 0 22 8 0 0 0 17 0 0 0 23"));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("36 8 0 0 0 6 0 0 0 0 8 0 0 0 6 0 0 0 1 8 0 0 0 7 0 0 0 1 8 0 0 0 7 0 0 0 2 8 0 0 0 8 0 0 0 2 8 0 0 0 8 0 0 0 3 8 0 0 0 9 0 0 0 3 8 0 0 0 9 0 0 0 4 8 0 0 0 10 0 0 0 4 8 0 0 0 10 0 0 0 5 8 0 0 0 11 0 0 0 0 8 0 0 0 11 0 0 0 5 8 0 0 0 12 0 0 0 6 8 0 0 0 12 0 0 0 7 8 0 0 0 13 0 0 0 7 8 0 0 0 13 0 0 0 8 8 0 0 0 14 0 0 0 8 8 0 0 0 14 0 0 0 9 8 0 0 0 15 0 0 0 9 8 0 0 0 15 0 0 0 10 8 0 0 0 16 0 0 0 10 8 0 0 0 16 0 0 0 11 8 0 0 0 17 0 0 0 6 8 0 0 0 17 0 0 0 11 8 0 0 0 18 0 0 0 12 8 0 0 0 18 0 0 0 13 8 0 0 0 19 0 0 0 13 8 0 0 0 19 0 0 0 14 8 0 0 0 20 0 0 0 14 8 0 0 0 20 0 0 0 15 8 0 0 0 21 0 0 0 15 8 0 0 0 21 0 0 0 16 8 0 0 0 22 0 0 0 16 8 0 0 0 22 0 0 0 17 8 0 0 0 23 0 0 0 12 8 0 0 0 23 0 0 0 17"));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("12 4 0 0 0 0 4 0 0 0 2 4 0 0 0 4 4 0 0 0 6 4 0 0 0 8 4 0 0 0 10 4 0 0 0 12 4 0 0 0 14 4 0 0 0 16 4 0 0 0 18 4 0 0 0 20 4 0 0 0 22"));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_1 = Space::new();
  let mut v0_1_write = v0_1.write_zipper();
  let mut v0_1_cursor = (*s0.expect("unbound native input")).read_zipper();
  let v0_1_origin = v0_1_cursor.path().len();
  for v0_1_byte in v0_1_cursor.child_mask().iter() {
    v0_1_cursor.descend_to_existing_byte(v0_1_byte);
    {
    for v1_2_byte in v0_1_cursor.child_mask().iter() {
      v0_1_cursor.descend_to_existing_byte(v1_2_byte);
      {
      for v2_3_byte in v0_1_cursor.child_mask().iter() {
        v0_1_cursor.descend_to_existing_byte(v2_3_byte);
        {
        for v3_3_byte in v0_1_cursor.child_mask().iter() {
          v0_1_cursor.descend_to_existing_byte(v3_3_byte);
          {
          let v4_3: Space = routine_1(c, &v0_1_cursor.path()[v0_1_origin..(v0_1_origin + 4)], &v0_1_cursor);
          join_wrapped_into(&mut v0_1_write,&((v4_3).read_zipper()),&[]);
          }
          v0_1_cursor.ascend(1);
        }
        }
        v0_1_cursor.ascend(1);
      }
      }
      v0_1_cursor.ascend(1);
    }
    }
    v0_1_cursor.ascend(1);
  }
  drop(v0_1_cursor);
  drop(v0_1_write);
  let v0_3: Space = wrap(&(v0_1),&(*CONSTANT_0));
  (v0_3).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v5_6: Space = restrict_to(&(*CONSTANT_2),&(descend_cursor((*CONSTANT_2).read_zipper(),&(*p0))));
  let mut v5_7 = Space::new();
  let mut v5_7_write = v5_7.write_zipper();
  let mut v5_7_cursor = (v5_6).read_zipper();
  let v5_7_origin = v5_7_cursor.path().len();
  for v5_7_byte in v5_7_cursor.child_mask().iter() {
    v5_7_cursor.descend_to_existing_byte(v5_7_byte);
    {
    for v6_2_byte in v5_7_cursor.child_mask().iter() {
      v5_7_cursor.descend_to_existing_byte(v6_2_byte);
      {
      for v7_2_byte in v5_7_cursor.child_mask().iter() {
        v5_7_cursor.descend_to_existing_byte(v7_2_byte);
        {
        join_tails_into(&mut v5_7_write,&mut v5_7_cursor);
        }
        v5_7_cursor.ascend(1);
      }
      }
      v5_7_cursor.ascend(1);
    }
    }
    v5_7_cursor.ascend(1);
  }
  drop(v5_7_cursor);
  drop(v5_7_write);
  drop(v5_6);
  let v5_8: Space = restrict_to(&(*CONSTANT_1),&(v5_7));
  drop(v5_7);
  let mut v5_9 = Space::new();
  let mut v5_9_write = v5_9.write_zipper();
  let mut v5_9_cursor = (v5_8).read_zipper();
  let v5_9_origin = v5_9_cursor.path().len();
  for v5_9_byte in v5_9_cursor.child_mask().iter() {
    v5_9_cursor.descend_to_existing_byte(v5_9_byte);
    {
    for v9_2_byte in v5_9_cursor.child_mask().iter() {
      v5_9_cursor.descend_to_existing_byte(v9_2_byte);
      {
      for v10_2_byte in v5_9_cursor.child_mask().iter() {
        v5_9_cursor.descend_to_existing_byte(v10_2_byte);
        {
        join_tails_into(&mut v5_9_write,&mut v5_9_cursor);
        }
        v5_9_cursor.ascend(1);
      }
      }
      v5_9_cursor.ascend(1);
    }
    }
    v5_9_cursor.ascend(1);
  }
  drop(v5_9_cursor);
  drop(v5_9_write);
  drop(v5_8);
  let v5_12: Space = subtract(&(v5_9),&(descend_cursor((*CONSTANT_2).read_zipper(),&(*p0))));
  drop(v5_9);
  let v5_14: Space = intersect(&(v5_12),&(*CONSTANT_3));
  drop(v5_12);
  let v5_15: Space = wrap(&(v5_14),&(*p0));
  drop(v5_14);
  (v5_15).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
