#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[48]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 49 48 0 4 0 49 49 0"));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("120 10 67 101 108 108 0 48 0 49 48 0 10 67 101 108 108 0 48 0 49 49 0 10 67 101 108 108 0 49 0 49 51 0 10 67 101 108 108 0 49 0 49 52 0 10 67 101 108 108 0 49 0 50 48 0 11 67 101 108 108 0 49 48 0 49 50 0 11 67 101 108 108 0 49 48 0 49 56 0 11 67 101 108 108 0 49 48 0 50 51 0 10 67 101 108 108 0 49 48 0 54 0 10 67 101 108 108 0 49 48 0 57 0 11 67 101 108 108 0 49 49 0 49 49 0 11 67 101 108 108 0 49 49 0 49 50 0 11 67 101 108 108 0 49 49 0 50 51 0 10 67 101 108 108 0 49 49 0 51 0 10 67 101 108 108 0 49 49 0 53 0 11 67 101 108 108 0 49 50 0 49 54 0 11 67 101 108 108 0 49 50 0 49 57 0 10 67 101 108 108 0 49 50 0 50 0 11 67 101 108 108 0 49 51 0 49 52 0 11 67 101 108 108 0 49 51 0 50 48 0 11 67 101 108 108 0 49 51 0 50 49 0 10 67 101 108 108 0 49 51 0 57 0 10 67 101 108 108 0 49 52 0 48 0 11 67 101 108 108 0 49 52 0 49 56 0 10 67 101 108 108 0 49 52 0 54 0 10 67 101 108 108 0 49 52 0 56 0 10 67 101 108 108 0 49 52 0 57 0 10 67 101 108 108 0 49 53 0 49 0 11 67 101 108 108 0 49 53 0 49 54 0 11 67 101 108 108 0 49 53 0 49 55 0 11 67 101 108 108 0 49 53 0 49 57 0 11 67 101 108 108 0 49 53 0 50 48 0 10 67 101 108 108 0 49 53 0 51 0 10 67 101 108 108 0 49 53 0 53 0 10 67 101 108 108 0 49 53 0 54 0 10 67 101 108 108 0 49 54 0 48 0 11 67 101 108 108 0 49 55 0 49 50 0 11 67 101 108 108 0 49 55 0 49 54 0 11 67 101 108 108 0 49 55 0 49 56 0 10 67 101 108 108 0 49 55 0 50 0 10 67 101 108 108 0 49 55 0 51 0 10 67 101 108 108 0 49 55 0 52 0 10 67 101 108 108 0 49 55 0 54 0 10 67 101 108 108 0 49 55 0 55 0 10 67 101 108 108 0 49 55 0 57 0 11 67 101 108 108 0 49 56 0 49 48 0 11 67 101 108 108 0 49 56 0 49 50 0 11 67 101 108 108 0 49 56 0 49 51 0 11 67 101 108 108 0 49 56 0 49 53 0 11 67 101 108 108 0 49 56 0 49 55 0 11 67 101 108 108 0 49 56 0 50 50 0 10 67 101 108 108 0 49 56 0 53 0 11 67 101 108 108 0 49 57 0 49 56 0 11 67 101 108 108 0 49 57 0 50 49 0 10 67 101 108 108 0 49 57 0 51 0 10 67 101 108 108 0 50 0 49 48 0 10 67 101 108 108 0 50 0 49 51 0 10 67 101 108 108 0 50 0 50 49 0 11 67 101 108 108 0 50 48 0 49 53 0 10 67 101 108 108 0 50 48 0 50 0 10 67 101 108 108 0 50 48 0 53 0 10 67 101 108 108 0 50 48 0 55 0 10 67 101 108 108 0 50 48 0 57 0 11 67 101 108 108 0 50 49 0 49 51 0 11 67 101 108 108 0 50 49 0 49 53 0 10 67 101 108 108 0 50 49 0 52 0 10 67 101 108 108 0 50 49 0 56 0 10 67 101 108 108 0 50 49 0 57 0 11 67 101 108 108 0 50 50 0 49 54 0 10 67 101 108 108 0 50 50 0 50 0 11 67 101 108 108 0 50 50 0 50 50 0 10 67 101 108 108 0 50 51 0 49 0 10 67 101 108 108 0 50 51 0 50 0 10 67 101 108 108 0 50 51 0 53 0 10 67 101 108 108 0 50 51 0 55 0 10 67 101 108 108 0 50 51 0 57 0 9 67 101 108 108 0 51 0 49 0 9 67 101 108 108 0 51 0 50 0 10 67 101 108 108 0 51 0 50 49 0 9 67 101 108 108 0 51 0 53 0 9 67 101 108 108 0 51 0 55 0 10 67 101 108 108 0 52 0 49 49 0 10 67 101 108 108 0 52 0 49 53 0 10 67 101 108 108 0 52 0 49 54 0 10 67 101 108 108 0 52 0 49 57 0 10 67 101 108 108 0 52 0 50 48 0 10 67 101 108 108 0 52 0 50 51 0 9 67 101 108 108 0 52 0 56 0 10 67 101 108 108 0 53 0 49 48 0 10 67 101 108 108 0 53 0 49 50 0 10 67 101 108 108 0 53 0 49 56 0 10 67 101 108 108 0 53 0 49 57 0 9 67 101 108 108 0 53 0 55 0 9 67 101 108 108 0 54 0 49 0 10 67 101 108 108 0 54 0 49 52 0 9 67 101 108 108 0 54 0 50 0 10 67 101 108 108 0 54 0 50 48 0 9 67 101 108 108 0 54 0 52 0 9 67 101 108 108 0 54 0 54 0 9 67 101 108 108 0 55 0 49 0 10 67 101 108 108 0 55 0 49 48 0 10 67 101 108 108 0 55 0 49 52 0 10 67 101 108 108 0 55 0 49 57 0 10 67 101 108 108 0 55 0 50 48 0 9 67 101 108 108 0 55 0 52 0 9 67 101 108 108 0 55 0 53 0 10 67 101 108 108 0 56 0 49 49 0 10 67 101 108 108 0 56 0 49 57 0 10 67 101 108 108 0 56 0 50 49 0 9 67 101 108 108 0 56 0 53 0 9 67 101 108 108 0 56 0 54 0 9 67 101 108 108 0 56 0 57 0 10 67 101 108 108 0 57 0 49 50 0 10 67 101 108 108 0 57 0 49 55 0 10 67 101 108 108 0 57 0 49 57 0 10 67 101 108 108 0 57 0 50 51 0 9 67 101 108 108 0 57 0 51 0 9 67 101 108 108 0 57 0 52 0 9 67 101 108 108 0 57 0 53 0 9 67 101 108 108 0 57 0 55 0"));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[49]));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("53 4 0 49 51 0 4 0 49 52 0 4 0 50 48 0 5 48 0 49 50 0 5 48 0 49 56 0 5 48 0 50 51 0 4 48 0 54 0 4 48 0 57 0 5 49 0 49 49 0 5 49 0 49 50 0 5 49 0 50 51 0 4 49 0 51 0 4 49 0 53 0 5 50 0 49 54 0 5 50 0 49 57 0 4 50 0 50 0 5 51 0 49 52 0 5 51 0 50 48 0 5 51 0 50 49 0 4 51 0 57 0 4 52 0 48 0 5 52 0 49 56 0 4 52 0 54 0 4 52 0 56 0 4 52 0 57 0 4 53 0 49 0 5 53 0 49 54 0 5 53 0 49 55 0 5 53 0 49 57 0 5 53 0 50 48 0 4 53 0 51 0 4 53 0 53 0 4 53 0 54 0 4 54 0 48 0 5 55 0 49 50 0 5 55 0 49 54 0 5 55 0 49 56 0 4 55 0 50 0 4 55 0 51 0 4 55 0 52 0 4 55 0 54 0 4 55 0 55 0 4 55 0 57 0 5 56 0 49 48 0 5 56 0 49 50 0 5 56 0 49 51 0 5 56 0 49 53 0 5 56 0 49 55 0 5 56 0 50 50 0 4 56 0 53 0 5 57 0 49 56 0 5 57 0 50 49 0 4 57 0 51 0"));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[50]));
static CONSTANT_7: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("21 4 0 49 48 0 4 0 49 51 0 4 0 50 49 0 5 48 0 49 53 0 4 48 0 50 0 4 48 0 53 0 4 48 0 55 0 4 48 0 57 0 5 49 0 49 51 0 5 49 0 49 53 0 4 49 0 52 0 4 49 0 56 0 4 49 0 57 0 5 50 0 49 54 0 4 50 0 50 0 5 50 0 50 50 0 4 51 0 49 0 4 51 0 50 0 4 51 0 53 0 4 51 0 55 0 4 51 0 57 0"));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[51]));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 3 0 49 0 3 0 50 0 4 0 50 49 0 3 0 53 0 3 0 55 0"));
static CONSTANT_10: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[52]));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 4 0 49 49 0 4 0 49 53 0 4 0 49 54 0 4 0 49 57 0 4 0 50 48 0 4 0 50 51 0 3 0 56 0"));
static CONSTANT_12: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[53]));
static CONSTANT_13: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 49 48 0 4 0 49 50 0 4 0 49 56 0 4 0 49 57 0 3 0 55 0"));
static CONSTANT_14: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[54]));
static CONSTANT_15: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 3 0 49 0 4 0 49 52 0 3 0 50 0 4 0 50 48 0 3 0 52 0 3 0 54 0"));
static CONSTANT_16: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[55]));
static CONSTANT_17: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 3 0 49 0 4 0 49 48 0 4 0 49 52 0 4 0 49 57 0 4 0 50 48 0 3 0 52 0 3 0 53 0"));
static CONSTANT_18: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[56]));
static CONSTANT_19: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 4 0 49 49 0 4 0 49 57 0 4 0 50 49 0 3 0 53 0 3 0 54 0 3 0 57 0"));
static CONSTANT_20: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[57]));
static CONSTANT_21: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 4 0 49 50 0 4 0 49 55 0 4 0 49 57 0 4 0 50 51 0 3 0 51 0 3 0 52 0 3 0 53 0 3 0 55 0"));
static CONSTANT_22: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_23: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[67,101,108,108,0]));
static CONSTANT_24: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("387 6 45 49 0 45 49 0 6 45 49 0 45 50 0 5 45 49 0 48 0 8 45 49 48 0 45 49 48 0 8 45 49 48 0 45 49 49 0 7 45 49 48 0 45 57 0 8 45 49 49 0 45 49 48 0 8 45 49 49 0 45 49 49 0 8 45 49 49 0 45 49 50 0 8 45 49 50 0 45 49 49 0 8 45 49 50 0 45 49 50 0 8 45 49 50 0 45 49 51 0 8 45 49 51 0 45 49 50 0 8 45 49 51 0 45 49 51 0 8 45 49 51 0 45 49 52 0 8 45 49 52 0 45 49 51 0 8 45 49 52 0 45 49 52 0 8 45 49 52 0 45 49 53 0 8 45 49 53 0 45 49 52 0 8 45 49 53 0 45 49 53 0 8 45 49 53 0 45 49 54 0 8 45 49 54 0 45 49 53 0 8 45 49 54 0 45 49 54 0 8 45 49 54 0 45 49 55 0 8 45 49 55 0 45 49 54 0 8 45 49 55 0 45 49 55 0 8 45 49 55 0 45 49 56 0 8 45 49 56 0 45 49 55 0 8 45 49 56 0 45 49 56 0 8 45 49 56 0 45 49 57 0 8 45 49 57 0 45 49 56 0 8 45 49 57 0 45 49 57 0 8 45 49 57 0 45 50 48 0 6 45 50 0 45 49 0 6 45 50 0 45 50 0 6 45 50 0 45 51 0 8 45 50 48 0 45 49 57 0 8 45 50 48 0 45 50 48 0 8 45 50 48 0 45 50 49 0 8 45 50 49 0 45 50 48 0 8 45 50 49 0 45 50 49 0 8 45 50 49 0 45 50 50 0 8 45 50 50 0 45 50 49 0 8 45 50 50 0 45 50 50 0 8 45 50 50 0 45 50 51 0 8 45 50 51 0 45 50 50 0 8 45 50 51 0 45 50 51 0 8 45 50 51 0 45 50 52 0 8 45 50 52 0 45 50 51 0 8 45 50 52 0 45 50 52 0 8 45 50 52 0 45 50 53 0 8 45 50 53 0 45 50 52 0 8 45 50 53 0 45 50 53 0 8 45 50 53 0 45 50 54 0 8 45 50 54 0 45 50 53 0 8 45 50 54 0 45 50 54 0 8 45 50 54 0 45 50 55 0 8 45 50 55 0 45 50 54 0 8 45 50 55 0 45 50 55 0 8 45 50 55 0 45 50 56 0 8 45 50 56 0 45 50 55 0 8 45 50 56 0 45 50 56 0 8 45 50 56 0 45 50 57 0 8 45 50 57 0 45 50 56 0 8 45 50 57 0 45 50 57 0 8 45 50 57 0 45 51 48 0 6 45 51 0 45 50 0 6 45 51 0 45 51 0 6 45 51 0 45 52 0 8 45 51 48 0 45 50 57 0 8 45 51 48 0 45 51 48 0 8 45 51 48 0 45 51 49 0 8 45 51 49 0 45 51 48 0 8 45 51 49 0 45 51 49 0 8 45 51 49 0 45 51 50 0 8 45 51 50 0 45 51 49 0 8 45 51 50 0 45 51 50 0 8 45 51 50 0 45 51 51 0 8 45 51 51 0 45 51 50 0 8 45 51 51 0 45 51 51 0 8 45 51 51 0 45 51 52 0 8 45 51 52 0 45 51 51 0 8 45 51 52 0 45 51 52 0 8 45 51 52 0 45 51 53 0 8 45 51 53 0 45 51 52 0 8 45 51 53 0 45 51 53 0 8 45 51 53 0 45 51 54 0 8 45 51 54 0 45 51 53 0 8 45 51 54 0 45 51 54 0 8 45 51 54 0 45 51 55 0 8 45 51 55 0 45 51 54 0 8 45 51 55 0 45 51 55 0 8 45 51 55 0 45 51 56 0 8 45 51 56 0 45 51 55 0 8 45 51 56 0 45 51 56 0 8 45 51 56 0 45 51 57 0 8 45 51 57 0 45 51 56 0 8 45 51 57 0 45 51 57 0 8 45 51 57 0 45 52 48 0 6 45 52 0 45 51 0 6 45 52 0 45 52 0 6 45 52 0 45 53 0 8 45 52 48 0 45 51 57 0 8 45 52 48 0 45 52 48 0 8 45 52 48 0 45 52 49 0 8 45 52 49 0 45 52 48 0 8 45 52 49 0 45 52 49 0 8 45 52 49 0 45 52 50 0 8 45 52 50 0 45 52 49 0 8 45 52 50 0 45 52 50 0 8 45 52 50 0 45 52 51 0 8 45 52 51 0 45 52 50 0 8 45 52 51 0 45 52 51 0 8 45 52 51 0 45 52 52 0 8 45 52 52 0 45 52 51 0 8 45 52 52 0 45 52 52 0 8 45 52 52 0 45 52 53 0 8 45 52 53 0 45 52 52 0 8 45 52 53 0 45 52 53 0 8 45 52 53 0 45 52 54 0 8 45 52 54 0 45 52 53 0 8 45 52 54 0 45 52 54 0 8 45 52 54 0 45 52 55 0 8 45 52 55 0 45 52 54 0 8 45 52 55 0 45 52 55 0 8 45 52 55 0 45 52 56 0 8 45 52 56 0 45 52 55 0 8 45 52 56 0 45 52 56 0 8 45 52 56 0 45 52 57 0 8 45 52 57 0 45 52 56 0 8 45 52 57 0 45 52 57 0 8 45 52 57 0 45 53 48 0 6 45 53 0 45 52 0 6 45 53 0 45 53 0 6 45 53 0 45 54 0 8 45 53 48 0 45 52 57 0 8 45 53 48 0 45 53 48 0 8 45 53 48 0 45 53 49 0 8 45 53 49 0 45 53 48 0 8 45 53 49 0 45 53 49 0 8 45 53 49 0 45 53 50 0 8 45 53 50 0 45 53 49 0 8 45 53 50 0 45 53 50 0 8 45 53 50 0 45 53 51 0 8 45 53 51 0 45 53 50 0 8 45 53 51 0 45 53 51 0 8 45 53 51 0 45 53 52 0 8 45 53 52 0 45 53 51 0 8 45 53 52 0 45 53 52 0 8 45 53 52 0 45 53 53 0 8 45 53 53 0 45 53 52 0 8 45 53 53 0 45 53 53 0 8 45 53 53 0 45 53 54 0 8 45 53 54 0 45 53 53 0 8 45 53 54 0 45 53 54 0 8 45 53 54 0 45 53 55 0 8 45 53 55 0 45 53 54 0 8 45 53 55 0 45 53 55 0 8 45 53 55 0 45 53 56 0 8 45 53 56 0 45 53 55 0 8 45 53 56 0 45 53 56 0 8 45 53 56 0 45 53 57 0 8 45 53 57 0 45 53 56 0 8 45 53 57 0 45 53 57 0 8 45 53 57 0 45 54 48 0 6 45 54 0 45 53 0 6 45 54 0 45 54 0 6 45 54 0 45 55 0 8 45 54 48 0 45 53 57 0 8 45 54 48 0 45 54 48 0 8 45 54 48 0 45 54 49 0 8 45 54 49 0 45 54 48 0 8 45 54 49 0 45 54 49 0 8 45 54 49 0 45 54 50 0 8 45 54 50 0 45 54 49 0 8 45 54 50 0 45 54 50 0 8 45 54 50 0 45 54 51 0 8 45 54 51 0 45 54 50 0 8 45 54 51 0 45 54 51 0 8 45 54 51 0 45 54 52 0 8 45 54 52 0 45 54 51 0 8 45 54 52 0 45 54 52 0 8 45 54 52 0 45 54 53 0 6 45 55 0 45 54 0 6 45 55 0 45 55 0 6 45 55 0 45 56 0 6 45 56 0 45 55 0 6 45 56 0 45 56 0 6 45 56 0 45 57 0 7 45 57 0 45 49 48 0 6 45 57 0 45 56 0 6 45 57 0 45 57 0 5 48 0 45 49 0 4 48 0 48 0 4 48 0 49 0 4 49 0 48 0 4 49 0 49 0 4 49 0 50 0 6 49 48 0 49 48 0 6 49 48 0 49 49 0 5 49 48 0 57 0 6 49 49 0 49 48 0 6 49 49 0 49 49 0 6 49 49 0 49 50 0 6 49 50 0 49 49 0 6 49 50 0 49 50 0 6 49 50 0 49 51 0 6 49 51 0 49 50 0 6 49 51 0 49 51 0 6 49 51 0 49 52 0 6 49 52 0 49 51 0 6 49 52 0 49 52 0 6 49 52 0 49 53 0 6 49 53 0 49 52 0 6 49 53 0 49 53 0 6 49 53 0 49 54 0 6 49 54 0 49 53 0 6 49 54 0 49 54 0 6 49 54 0 49 55 0 6 49 55 0 49 54 0 6 49 55 0 49 55 0 6 49 55 0 49 56 0 6 49 56 0 49 55 0 6 49 56 0 49 56 0 6 49 56 0 49 57 0 6 49 57 0 49 56 0 6 49 57 0 49 57 0 6 49 57 0 50 48 0 4 50 0 49 0 4 50 0 50 0 4 50 0 51 0 6 50 48 0 49 57 0 6 50 48 0 50 48 0 6 50 48 0 50 49 0 6 50 49 0 50 48 0 6 50 49 0 50 49 0 6 50 49 0 50 50 0 6 50 50 0 50 49 0 6 50 50 0 50 50 0 6 50 50 0 50 51 0 6 50 51 0 50 50 0 6 50 51 0 50 51 0 6 50 51 0 50 52 0 6 50 52 0 50 51 0 6 50 52 0 50 52 0 6 50 52 0 50 53 0 6 50 53 0 50 52 0 6 50 53 0 50 53 0 6 50 53 0 50 54 0 6 50 54 0 50 53 0 6 50 54 0 50 54 0 6 50 54 0 50 55 0 6 50 55 0 50 54 0 6 50 55 0 50 55 0 6 50 55 0 50 56 0 6 50 56 0 50 55 0 6 50 56 0 50 56 0 6 50 56 0 50 57 0 6 50 57 0 50 56 0 6 50 57 0 50 57 0 6 50 57 0 51 48 0 4 51 0 50 0 4 51 0 51 0 4 51 0 52 0 6 51 48 0 50 57 0 6 51 48 0 51 48 0 6 51 48 0 51 49 0 6 51 49 0 51 48 0 6 51 49 0 51 49 0 6 51 49 0 51 50 0 6 51 50 0 51 49 0 6 51 50 0 51 50 0 6 51 50 0 51 51 0 6 51 51 0 51 50 0 6 51 51 0 51 51 0 6 51 51 0 51 52 0 6 51 52 0 51 51 0 6 51 52 0 51 52 0 6 51 52 0 51 53 0 6 51 53 0 51 52 0 6 51 53 0 51 53 0 6 51 53 0 51 54 0 6 51 54 0 51 53 0 6 51 54 0 51 54 0 6 51 54 0 51 55 0 6 51 55 0 51 54 0 6 51 55 0 51 55 0 6 51 55 0 51 56 0 6 51 56 0 51 55 0 6 51 56 0 51 56 0 6 51 56 0 51 57 0 6 51 57 0 51 56 0 6 51 57 0 51 57 0 6 51 57 0 52 48 0 4 52 0 51 0 4 52 0 52 0 4 52 0 53 0 6 52 48 0 51 57 0 6 52 48 0 52 48 0 6 52 48 0 52 49 0 6 52 49 0 52 48 0 6 52 49 0 52 49 0 6 52 49 0 52 50 0 6 52 50 0 52 49 0 6 52 50 0 52 50 0 6 52 50 0 52 51 0 6 52 51 0 52 50 0 6 52 51 0 52 51 0 6 52 51 0 52 52 0 6 52 52 0 52 51 0 6 52 52 0 52 52 0 6 52 52 0 52 53 0 6 52 53 0 52 52 0 6 52 53 0 52 53 0 6 52 53 0 52 54 0 6 52 54 0 52 53 0 6 52 54 0 52 54 0 6 52 54 0 52 55 0 6 52 55 0 52 54 0 6 52 55 0 52 55 0 6 52 55 0 52 56 0 6 52 56 0 52 55 0 6 52 56 0 52 56 0 6 52 56 0 52 57 0 6 52 57 0 52 56 0 6 52 57 0 52 57 0 6 52 57 0 53 48 0 4 53 0 52 0 4 53 0 53 0 4 53 0 54 0 6 53 48 0 52 57 0 6 53 48 0 53 48 0 6 53 48 0 53 49 0 6 53 49 0 53 48 0 6 53 49 0 53 49 0 6 53 49 0 53 50 0 6 53 50 0 53 49 0 6 53 50 0 53 50 0 6 53 50 0 53 51 0 6 53 51 0 53 50 0 6 53 51 0 53 51 0 6 53 51 0 53 52 0 6 53 52 0 53 51 0 6 53 52 0 53 52 0 6 53 52 0 53 53 0 6 53 53 0 53 52 0 6 53 53 0 53 53 0 6 53 53 0 53 54 0 6 53 54 0 53 53 0 6 53 54 0 53 54 0 6 53 54 0 53 55 0 6 53 55 0 53 54 0 6 53 55 0 53 55 0 6 53 55 0 53 56 0 6 53 56 0 53 55 0 6 53 56 0 53 56 0 6 53 56 0 53 57 0 6 53 57 0 53 56 0 6 53 57 0 53 57 0 6 53 57 0 54 48 0 4 54 0 53 0 4 54 0 54 0 4 54 0 55 0 6 54 48 0 53 57 0 6 54 48 0 54 48 0 6 54 48 0 54 49 0 6 54 49 0 54 48 0 6 54 49 0 54 49 0 6 54 49 0 54 50 0 6 54 50 0 54 49 0 6 54 50 0 54 50 0 6 54 50 0 54 51 0 6 54 51 0 54 50 0 6 54 51 0 54 51 0 6 54 51 0 54 52 0 6 54 52 0 54 51 0 6 54 52 0 54 52 0 6 54 52 0 54 53 0 4 55 0 54 0 4 55 0 55 0 4 55 0 56 0 4 56 0 55 0 4 56 0 56 0 4 56 0 57 0 5 57 0 49 48 0 4 57 0 56 0 4 57 0 57 0"));
static CONSTANT_25: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 104 105 116 0"));
fn routine_0(c: &mut Context) -> Space {
  let v0_50: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v1_4: Space = routine_1(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()), &((*CONSTANT_3).read_zipper()));
    let v1_8: Space = routine_1(c, &(*CONSTANT_4), &((*CONSTANT_5).read_zipper()), &((*CONSTANT_3).read_zipper()));
    let v1_9: Space = unite(&(v1_4),&(v1_8));
    let v1_13: Space = routine_1(c, &(*CONSTANT_6), &((*CONSTANT_7).read_zipper()), &((*CONSTANT_3).read_zipper()));
    let v1_14: Space = unite(&(v1_9),&(v1_13));
    let v1_18: Space = routine_1(c, &(*CONSTANT_8), &((*CONSTANT_9).read_zipper()), &((*CONSTANT_3).read_zipper()));
    let v1_19: Space = unite(&(v1_14),&(v1_18));
    let v1_23: Space = routine_1(c, &(*CONSTANT_10), &((*CONSTANT_11).read_zipper()), &((*CONSTANT_3).read_zipper()));
    let v1_24: Space = unite(&(v1_19),&(v1_23));
    let v1_28: Space = routine_1(c, &(*CONSTANT_12), &((*CONSTANT_13).read_zipper()), &((*CONSTANT_3).read_zipper()));
    let v1_29: Space = unite(&(v1_24),&(v1_28));
    let v1_33: Space = routine_1(c, &(*CONSTANT_14), &((*CONSTANT_15).read_zipper()), &((*CONSTANT_3).read_zipper()));
    let v1_34: Space = unite(&(v1_29),&(v1_33));
    let v1_38: Space = routine_1(c, &(*CONSTANT_16), &((*CONSTANT_17).read_zipper()), &((*CONSTANT_3).read_zipper()));
    let v1_39: Space = unite(&(v1_34),&(v1_38));
    let v1_43: Space = routine_1(c, &(*CONSTANT_18), &((*CONSTANT_19).read_zipper()), &((*CONSTANT_3).read_zipper()));
    let v1_44: Space = unite(&(v1_39),&(v1_43));
    let v1_48: Space = routine_1(c, &(*CONSTANT_20), &((*CONSTANT_21).read_zipper()), &((*CONSTANT_3).read_zipper()));
    let v1_49: Space = unite(&(v1_44),&(v1_48));
    compose(&(*CONSTANT_0),&(v1_49))
  };
  let v0_81: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v2_53: Space = routine_2(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
    let v2_55: Space = routine_2(c, &(*CONSTANT_4), &((*CONSTANT_5).read_zipper()));
    let v2_56: Space = unite(&(v2_53),&(v2_55));
    let v2_58: Space = routine_2(c, &(*CONSTANT_6), &((*CONSTANT_7).read_zipper()));
    let v2_59: Space = unite(&(v2_56),&(v2_58));
    let v2_61: Space = routine_2(c, &(*CONSTANT_8), &((*CONSTANT_9).read_zipper()));
    let v2_62: Space = unite(&(v2_59),&(v2_61));
    let v2_64: Space = routine_2(c, &(*CONSTANT_10), &((*CONSTANT_11).read_zipper()));
    let v2_65: Space = unite(&(v2_62),&(v2_64));
    let v2_67: Space = routine_2(c, &(*CONSTANT_12), &((*CONSTANT_13).read_zipper()));
    let v2_68: Space = unite(&(v2_65),&(v2_67));
    let v2_70: Space = routine_2(c, &(*CONSTANT_14), &((*CONSTANT_15).read_zipper()));
    let v2_71: Space = unite(&(v2_68),&(v2_70));
    let v2_73: Space = routine_2(c, &(*CONSTANT_16), &((*CONSTANT_17).read_zipper()));
    let v2_74: Space = unite(&(v2_71),&(v2_73));
    let v2_76: Space = routine_2(c, &(*CONSTANT_18), &((*CONSTANT_19).read_zipper()));
    let v2_77: Space = unite(&(v2_74),&(v2_76));
    let v2_79: Space = routine_2(c, &(*CONSTANT_20), &((*CONSTANT_21).read_zipper()));
    let v2_80: Space = unite(&(v2_77),&(v2_79));
    compose(&(*CONSTANT_0),&(v2_80))
  };
  let mut v0_87 = Space::new();
  let mut v0_87_write = v0_87.write_zipper();
  let mut v0_87_cursor = (v0_81).read_zipper();
  let v0_87_origin = v0_87_cursor.path().len();
  for v0_87_byte in v0_87_cursor.child_mask().iter() {
    v0_87_cursor.descend_to_existing_byte(v0_87_byte);
    {
    let v3_2: Space = singleton(&v0_87_cursor.path()[v0_87_origin..(v0_87_origin + 1)]);
    let v3_3: Space = intersect(&(*CONSTANT_22),&(v3_2));
    let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
    drop(v3_3);
    let v3_5: Space = subtract(&(*CONSTANT_0),&(v3_4));
    drop(v3_4);
    let v3_7: Space = if (&(v3_5)).is_empty() { Space::new() } else {
      let v4_6: Space = routine_3(c, &v0_87_cursor.path()[v0_87_origin..(v0_87_origin + 1)], &v0_87_cursor, &((*CONSTANT_3).read_zipper()));
      compose(&(v3_5),&(v4_6))
    };
    drop(v3_5);
    let v3_8: Space = intersect(&(*CONSTANT_22),&(v3_2));
    drop(v3_2);
    let v3_9: Space = if has_head(&(v3_8)) { singleton(&[]) } else { Space::new() };
    drop(v3_8);
    let v3_11: Space = if (&(v3_9)).is_empty() { Space::new() } else {
      let v5_10: Space = routine_4(c, &v0_87_cursor.path()[v0_87_origin..(v0_87_origin + 1)], &v0_87_cursor, &((*CONSTANT_3).read_zipper()));
      compose(&(v3_9),&(v5_10))
    };
    drop(v3_9);
    let v3_12: Space = unite(&(v3_7),&(v3_11));
    join_wrapped_into(&mut v0_87_write,&((v3_12).read_zipper()),&[]);
    }
    v0_87_cursor.ascend(1);
  }
  drop(v0_87_cursor);
  drop(v0_87_write);
  let v0_88: Space = unite(&(v0_50),&(v0_87));
  let v0_90: Space = wrap(&(v0_88),&(*CONSTANT_23));
  (v0_90).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v6_9 = Space::new();
  let mut v6_9_write = v6_9.write_zipper();
  let mut v6_9_cursor = (*s0).read_zipper();
  let v6_9_origin = v6_9_cursor.path().len();
  for v6_9_byte in v6_9_cursor.child_mask().iter() {
    v6_9_cursor.descend_to_existing_byte(v6_9_byte);
    {
    let v7_2: Space = singleton(&v6_9_cursor.path()[v6_9_origin..(v6_9_origin + 1)]);
    let v7_3: Space = intersect(&(*CONSTANT_22),&(v7_2));
    let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
    drop(v7_3);
    let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
    drop(v7_4);
    let v7_8: Space = if (&(v7_5)).is_empty() { Space::new() } else {
      let v8_6: Path = concat_path(&(*p0),&v6_9_cursor.path()[v6_9_origin..(v6_9_origin + 1)]);
      let v8_7: Space = routine_1(c, &(v8_6), &v6_9_cursor, &(*s1));
      compose(&(v7_5),&(v8_7))
    };
    drop(v7_5);
    let v7_9: Space = intersect(&(*CONSTANT_22),&(v7_2));
    drop(v7_2);
    let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
    drop(v7_9);
    let v7_12: Space = if (&(v7_10)).is_empty() { Space::new() } else {
      let v9_6: Path = concat_path(&(*p0),&v6_9_cursor.path()[v6_9_origin..(v6_9_origin + 1)]);
      let mut v9_11 = Space::new();
      let mut v9_11_write = v9_11.write_zipper();
      for v9_11_byte in v6_9_cursor.child_mask().iter() {
        v6_9_cursor.descend_to_existing_byte(v9_11_byte);
        {
        let v10_2: Space = singleton(&v6_9_cursor.path()[(v6_9_origin + 1)..(v6_9_origin + 2)]);
        let v10_3: Space = intersect(&(*CONSTANT_22),&(v10_2));
        let v10_4: Space = if has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
        drop(v10_3);
        let v10_5: Space = subtract(&(*CONSTANT_0),&(v10_4));
        drop(v10_4);
        let v10_7: Space = if (&(v10_5)).is_empty() { Space::new() } else {
          let v11_6: Space = routine_5(c, &v6_9_cursor.path()[(v6_9_origin + 1)..(v6_9_origin + 2)], &(v9_6), &v6_9_cursor, &(*s1));
          compose(&(v10_5),&(v11_6))
        };
        drop(v10_5);
        let v10_8: Space = intersect(&(*CONSTANT_22),&(v10_2));
        drop(v10_2);
        let v10_9: Space = if has_head(&(v10_8)) { singleton(&[]) } else { Space::new() };
        drop(v10_8);
        let v10_11: Space = if (&(v10_9)).is_empty() { Space::new() } else {
          let v12_10: Space = routine_6(c, &v6_9_cursor.path()[(v6_9_origin + 1)..(v6_9_origin + 2)], &(v9_6), &v6_9_cursor, &(*s1));
          compose(&(v10_9),&(v12_10))
        };
        drop(v10_9);
        let v10_12: Space = unite(&(v10_7),&(v10_11));
        join_wrapped_into(&mut v9_11_write,&((v10_12).read_zipper()),&[]);
        }
        v6_9_cursor.ascend(1);
      }
      drop(v9_11_write);
      drop(v9_6);
      compose(&(v7_10),&(v9_11))
    };
    drop(v7_10);
    let v7_13: Space = unite(&(v7_8),&(v7_12));
    join_wrapped_into(&mut v6_9_write,&((v7_13).read_zipper()),&[]);
    }
    v6_9_cursor.ascend(1);
  }
  drop(v6_9_cursor);
  drop(v6_9_write);
  (v6_9).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v13_11 = Space::new();
  let mut v13_11_write = v13_11.write_zipper();
  let mut v13_11_cursor = (*s0).read_zipper();
  let v13_11_origin = v13_11_cursor.path().len();
  for v13_11_byte in v13_11_cursor.child_mask().iter() {
    v13_11_cursor.descend_to_existing_byte(v13_11_byte);
    {
    let v14_2: Space = singleton(&v13_11_cursor.path()[v13_11_origin..(v13_11_origin + 1)]);
    let v14_3: Space = intersect(&(*CONSTANT_22),&(v14_2));
    let v14_4: Space = if has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
    drop(v14_3);
    let v14_5: Space = subtract(&(*CONSTANT_0),&(v14_4));
    drop(v14_4);
    let v14_8: Space = if (&(v14_5)).is_empty() { Space::new() } else {
      let v15_6: Path = concat_path(&(*p0),&v13_11_cursor.path()[v13_11_origin..(v13_11_origin + 1)]);
      let v15_7: Space = routine_2(c, &(v15_6), &v13_11_cursor);
      compose(&(v14_5),&(v15_7))
    };
    drop(v14_5);
    let v14_9: Space = intersect(&(*CONSTANT_22),&(v14_2));
    drop(v14_2);
    let v14_10: Space = if has_head(&(v14_9)) { singleton(&[]) } else { Space::new() };
    drop(v14_9);
    let v14_13: Space = if (&(v14_10)).is_empty() { Space::new() } else {
      let v16_6: Path = concat_path(&(*p0),&v13_11_cursor.path()[v13_11_origin..(v13_11_origin + 1)]);
      let mut v16_12 = Space::new();
      let mut v16_12_write = v16_12.write_zipper();
      for v16_12_byte in v13_11_cursor.child_mask().iter() {
        v13_11_cursor.descend_to_existing_byte(v16_12_byte);
        {
        let v17_2: Space = singleton(&v13_11_cursor.path()[(v13_11_origin + 1)..(v13_11_origin + 2)]);
        let v17_3: Space = intersect(&(*CONSTANT_22),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_0),&(v17_4));
        drop(v17_4);
        let v17_7: Space = if (&(v17_5)).is_empty() { Space::new() } else {
          let v18_6: Space = routine_7(c, &v13_11_cursor.path()[(v13_11_origin + 1)..(v13_11_origin + 2)], &(v16_6), &v13_11_cursor);
          compose(&(v17_5),&(v18_6))
        };
        drop(v17_5);
        let v17_8: Space = intersect(&(*CONSTANT_22),&(v17_2));
        drop(v17_2);
        let v17_9: Space = if has_head(&(v17_8)) { singleton(&[]) } else { Space::new() };
        drop(v17_8);
        let v17_15: Space = if (&(v17_9)).is_empty() { Space::new() } else {
          let v19_11: Space = if (&(descend_cursor(descend_cursor((*CONSTANT_24).read_zipper(),&(*p0)),&v13_11_cursor.path()[v13_11_origin..(v13_11_origin + 1)]))).is_empty() { Space::new() } else {
            compose(&(descend_cursor(descend_cursor((*CONSTANT_24).read_zipper(),&(*p0)),&v13_11_cursor.path()[v13_11_origin..(v13_11_origin + 1)])),&(descend_cursor((*CONSTANT_24).read_zipper(),&v13_11_cursor.path()[(v13_11_origin + 1)..(v13_11_origin + 2)])))
          };
          let v19_12: Path = concat_path(&(v16_6),&v13_11_cursor.path()[(v13_11_origin + 1)..(v13_11_origin + 2)]);
          let v19_13: Space = singleton(&(v19_12));
          drop(v19_12);
          let v19_14: Space = subtract(&(v19_11),&(v19_13));
          drop(v19_11);
          drop(v19_13);
          compose(&(v17_9),&(v19_14))
        };
        drop(v17_9);
        let v17_16: Space = unite(&(v17_7),&(v17_15));
        drop(v17_15);
        join_wrapped_into(&mut v16_12_write,&((v17_16).read_zipper()),&[]);
        }
        v13_11_cursor.ascend(1);
      }
      drop(v16_12_write);
      drop(v16_6);
      compose(&(v14_10),&(v16_12))
    };
    drop(v14_10);
    let v14_14: Space = unite(&(v14_8),&(v14_13));
    join_wrapped_into(&mut v13_11_write,&((v14_14).read_zipper()),&[]);
    }
    v13_11_cursor.ascend(1);
  }
  drop(v13_11_cursor);
  drop(v13_11_write);
  (v13_11).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v21_9 = Space::new();
  let mut v21_9_write = v21_9.write_zipper();
  let mut v21_9_cursor = (*s0).read_zipper();
  let v21_9_origin = v21_9_cursor.path().len();
  for v21_9_byte in v21_9_cursor.child_mask().iter() {
    v21_9_cursor.descend_to_existing_byte(v21_9_byte);
    {
    let v22_2: Space = singleton(&v21_9_cursor.path()[v21_9_origin..(v21_9_origin + 1)]);
    let v22_3: Space = intersect(&(*CONSTANT_22),&(v22_2));
    let v22_4: Space = if has_head(&(v22_3)) { singleton(&[]) } else { Space::new() };
    drop(v22_3);
    let v22_5: Space = subtract(&(*CONSTANT_0),&(v22_4));
    drop(v22_4);
    let v22_8: Space = if (&(v22_5)).is_empty() { Space::new() } else {
      let v23_6: Path = concat_path(&(*p0),&v21_9_cursor.path()[v21_9_origin..(v21_9_origin + 1)]);
      let v23_7: Space = routine_3(c, &(v23_6), &v21_9_cursor, &(*s1));
      compose(&(v22_5),&(v23_7))
    };
    drop(v22_5);
    let v22_9: Space = intersect(&(*CONSTANT_22),&(v22_2));
    drop(v22_2);
    let v22_10: Space = if has_head(&(v22_9)) { singleton(&[]) } else { Space::new() };
    drop(v22_9);
    let v22_12: Space = if (&(v22_10)).is_empty() { Space::new() } else {
      let v24_6: Path = concat_path(&(*p0),&v21_9_cursor.path()[v21_9_origin..(v21_9_origin + 1)]);
      let mut v24_11 = Space::new();
      let mut v24_11_write = v24_11.write_zipper();
      for v24_11_byte in v21_9_cursor.child_mask().iter() {
        v21_9_cursor.descend_to_existing_byte(v24_11_byte);
        {
        let v25_2: Space = singleton(&v21_9_cursor.path()[(v21_9_origin + 1)..(v21_9_origin + 2)]);
        let v25_3: Space = intersect(&(*CONSTANT_22),&(v25_2));
        let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
        drop(v25_3);
        let v25_5: Space = subtract(&(*CONSTANT_0),&(v25_4));
        drop(v25_4);
        let v25_7: Space = if (&(v25_5)).is_empty() { Space::new() } else {
          let v26_6: Space = routine_8(c, &v21_9_cursor.path()[(v21_9_origin + 1)..(v21_9_origin + 2)], &(v24_6), &v21_9_cursor, &(*s1));
          compose(&(v25_5),&(v26_6))
        };
        drop(v25_5);
        let v25_8: Space = intersect(&(*CONSTANT_22),&(v25_2));
        drop(v25_2);
        let v25_9: Space = if has_head(&(v25_8)) { singleton(&[]) } else { Space::new() };
        drop(v25_8);
        let v25_11: Space = if (&(v25_9)).is_empty() { Space::new() } else {
          let v27_10: Space = routine_9(c, &v21_9_cursor.path()[(v21_9_origin + 1)..(v21_9_origin + 2)], &(v24_6), &v21_9_cursor, &(*s1));
          compose(&(v25_9),&(v27_10))
        };
        drop(v25_9);
        let v25_12: Space = unite(&(v25_7),&(v25_11));
        join_wrapped_into(&mut v24_11_write,&((v25_12).read_zipper()),&[]);
        }
        v21_9_cursor.ascend(1);
      }
      drop(v24_11_write);
      drop(v24_6);
      compose(&(v22_10),&(v24_11))
    };
    drop(v22_10);
    let v22_13: Space = unite(&(v22_8),&(v22_12));
    join_wrapped_into(&mut v21_9_write,&((v22_13).read_zipper()),&[]);
    }
    v21_9_cursor.ascend(1);
  }
  drop(v21_9_cursor);
  drop(v21_9_write);
  (v21_9).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v28_28 = Space::new();
  let mut v28_28_write = v28_28.write_zipper();
  let mut v28_28_cursor = (*s0).read_zipper();
  let v28_28_origin = v28_28_cursor.path().len();
  for v28_28_byte in v28_28_cursor.child_mask().iter() {
    v28_28_cursor.descend_to_existing_byte(v28_28_byte);
    {
    let v29_2: Space = singleton(&v28_28_cursor.path()[v28_28_origin..(v28_28_origin + 1)]);
    let v29_3: Space = intersect(&(*CONSTANT_22),&(v29_2));
    let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
    drop(v29_3);
    let v29_5: Space = subtract(&(*CONSTANT_0),&(v29_4));
    drop(v29_4);
    let v29_7: Space = if (&(v29_5)).is_empty() { Space::new() } else {
      let mut v30_6 = Space::new();
      let mut v30_6_write = v30_6.write_zipper();
      for v30_6_byte in v28_28_cursor.child_mask().iter() {
        v28_28_cursor.descend_to_existing_byte(v30_6_byte);
        {
        let v31_2: Space = singleton(&v28_28_cursor.path()[(v28_28_origin + 1)..(v28_28_origin + 2)]);
        let v31_3: Space = intersect(&(*CONSTANT_22),&(v31_2));
        let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
        drop(v31_3);
        let v31_5: Space = subtract(&(*CONSTANT_0),&(v31_4));
        drop(v31_4);
        let v31_8: Space = if (&(v31_5)).is_empty() { Space::new() } else {
          let v32_7: Space = routine_8(c, &v28_28_cursor.path()[v28_28_origin..(v28_28_origin + 2)], &(*p0), &v28_28_cursor, &(*s1));
          compose(&(v31_5),&(v32_7))
        };
        drop(v31_5);
        let v31_9: Space = intersect(&(*CONSTANT_22),&(v31_2));
        drop(v31_2);
        let v31_10: Space = if has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
        drop(v31_9);
        let v31_12: Space = if (&(v31_10)).is_empty() { Space::new() } else {
          let v33_11: Space = routine_9(c, &v28_28_cursor.path()[v28_28_origin..(v28_28_origin + 2)], &(*p0), &v28_28_cursor, &(*s1));
          compose(&(v31_10),&(v33_11))
        };
        drop(v31_10);
        let v31_13: Space = unite(&(v31_8),&(v31_12));
        join_wrapped_into(&mut v30_6_write,&((v31_13).read_zipper()),&[]);
        }
        v28_28_cursor.ascend(1);
      }
      drop(v30_6_write);
      compose(&(v29_5),&(v30_6))
    };
    drop(v29_5);
    let v29_8: Space = intersect(&(*CONSTANT_22),&(v29_2));
    drop(v29_2);
    let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
    drop(v29_8);
    let v29_27: Space = if (&(v29_9)).is_empty() { Space::new() } else {
      let v34_11: Space = if (&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p0)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p0))),&(descend_cursor((*CONSTANT_24).read_zipper(),&v28_28_cursor.path()[v28_28_origin..(v28_28_origin + 1)])))
      };
      let v34_12: Path = concat_path(&(*p0),&v28_28_cursor.path()[v28_28_origin..(v28_28_origin + 1)]);
      let v34_13: Space = singleton(&(v34_12));
      drop(v34_12);
      let v34_14: Space = subtract(&(v34_11),&(v34_13));
      drop(v34_11);
      let v34_15: Space = intersect(&(v34_14),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))));
      drop(v34_14);
      let v34_16: Space = range_const::<{3},{4}>(&(v34_15));
      drop(v34_15);
      let mut v34_17 = Space::new();
      let mut v34_17_write = v34_17.write_zipper();
      let mut v34_17_cursor = (v34_16).read_zipper();
      let v34_17_origin = v34_17_cursor.path().len();
      for v34_17_byte in v34_17_cursor.child_mask().iter() {
        v34_17_cursor.descend_to_existing_byte(v34_17_byte);
        {
        let v36_2: Space = singleton(&v34_17_cursor.path()[v34_17_origin..(v34_17_origin + 1)]);
        let v36_3: Space = intersect(&(*CONSTANT_22),&(v36_2));
        let v36_4: Space = if has_head(&(v36_3)) { singleton(&[]) } else { Space::new() };
        drop(v36_3);
        let v36_5: Space = subtract(&(*CONSTANT_0),&(v36_4));
        drop(v36_4);
        let v36_7: Space = if (&(v36_5)).is_empty() { Space::new() } else {
          let v37_6: Space = routine_10(c, &v34_17_cursor.path()[v34_17_origin..(v34_17_origin + 1)], &v34_17_cursor);
          compose(&(v36_5),&(v37_6))
        };
        drop(v36_5);
        let v36_8: Space = intersect(&(*CONSTANT_22),&(v36_2));
        drop(v36_2);
        let v36_9: Space = if has_head(&(v36_8)) { singleton(&[]) } else { Space::new() };
        drop(v36_8);
        let v36_10: Space = compose(&(v36_9),&(*CONSTANT_25));
        drop(v36_9);
        let v36_11: Space = unite(&(v36_7),&(v36_10));
        drop(v36_10);
        join_wrapped_into(&mut v34_17_write,&((v36_11).read_zipper()),&[]);
        }
        v34_17_cursor.ascend(1);
      }
      drop(v34_17_cursor);
      drop(v34_17_write);
      drop(v34_16);
      let v34_19: Space = if (&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p0)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p0))),&(descend_cursor((*CONSTANT_24).read_zipper(),&v28_28_cursor.path()[v28_28_origin..(v28_28_origin + 1)])))
      };
      let v34_20: Space = subtract(&(v34_19),&(v34_13));
      drop(v34_19);
      let v34_21: Space = intersect(&(v34_20),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))));
      drop(v34_20);
      let v34_22: Space = range_const::<{4},{5}>(&(v34_21));
      drop(v34_21);
      let mut v34_23 = Space::new();
      let mut v34_23_write = v34_23.write_zipper();
      let mut v34_23_cursor = (v34_22).read_zipper();
      let v34_23_origin = v34_23_cursor.path().len();
      for v34_23_byte in v34_23_cursor.child_mask().iter() {
        v34_23_cursor.descend_to_existing_byte(v34_23_byte);
        {
        let v39_2: Space = singleton(&v34_23_cursor.path()[v34_23_origin..(v34_23_origin + 1)]);
        let v39_3: Space = intersect(&(*CONSTANT_22),&(v39_2));
        let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_7: Space = if (&(v39_5)).is_empty() { Space::new() } else {
          let v40_6: Space = routine_11(c, &v34_23_cursor.path()[v34_23_origin..(v34_23_origin + 1)], &v34_23_cursor);
          compose(&(v39_5),&(v40_6))
        };
        drop(v39_5);
        let v39_8: Space = intersect(&(*CONSTANT_22),&(v39_2));
        drop(v39_2);
        let v39_9: Space = if has_head(&(v39_8)) { singleton(&[]) } else { Space::new() };
        drop(v39_8);
        let v39_10: Space = compose(&(v39_9),&(*CONSTANT_25));
        drop(v39_9);
        let v39_11: Space = unite(&(v39_7),&(v39_10));
        drop(v39_10);
        join_wrapped_into(&mut v34_23_write,&((v39_11).read_zipper()),&[]);
        }
        v34_23_cursor.ascend(1);
      }
      drop(v34_23_cursor);
      drop(v34_23_write);
      drop(v34_22);
      let v34_24: Space = subtract(&(v34_17),&(v34_23));
      let v34_25: Space = if (&(v34_24)).is_empty() { Space::new() } else {
        compose(&(v34_24),&(v34_13))
      };
      drop(v34_13);
      let mut v34_26 = Space::new();
      let mut v34_26_write = v34_26.write_zipper();
      let mut v34_26_cursor = (v34_25).read_zipper();
      let v34_26_origin = v34_26_cursor.path().len();
      for v34_26_byte in v34_26_cursor.child_mask().iter() {
        v34_26_cursor.descend_to_existing_byte(v34_26_byte);
        {
        let v42_2: Space = singleton(&v34_26_cursor.path()[v34_26_origin..(v34_26_origin + 1)]);
        let v42_3: Space = intersect(&(*CONSTANT_22),&(v42_2));
        let v42_4: Space = if has_head(&(v42_3)) { singleton(&[]) } else { Space::new() };
        drop(v42_3);
        let v42_5: Space = subtract(&(*CONSTANT_0),&(v42_4));
        drop(v42_4);
        let v42_7: Space = if (&(v42_5)).is_empty() { Space::new() } else {
          let v43_6: Space = routine_12(c, &v34_26_cursor.path()[v34_26_origin..(v34_26_origin + 1)], &v34_26_cursor);
          compose(&(v42_5),&(v43_6))
        };
        drop(v42_5);
        let v42_8: Space = intersect(&(*CONSTANT_22),&(v42_2));
        drop(v42_2);
        let v42_9: Space = if has_head(&(v42_8)) { singleton(&[]) } else { Space::new() };
        drop(v42_8);
        let v42_10: Space = compose(&(v42_9),&v34_26_cursor);
        drop(v42_9);
        let v42_11: Space = unite(&(v42_7),&(v42_10));
        drop(v42_10);
        join_wrapped_into(&mut v34_26_write,&((v42_11).read_zipper()),&[]);
        }
        v34_26_cursor.ascend(1);
      }
      drop(v34_26_cursor);
      drop(v34_26_write);
      compose(&(v29_9),&(v34_26))
    };
    drop(v29_9);
    let v29_28: Space = unite(&(v29_7),&(v29_27));
    join_wrapped_into(&mut v28_28_write,&((v29_28).read_zipper()),&[]);
    }
    v28_28_cursor.ascend(1);
  }
  drop(v28_28_cursor);
  drop(v28_28_write);
  (v28_28).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v44_28 = Space::new();
  let mut v44_28_write = v44_28.write_zipper();
  let mut v44_28_cursor = (*s0).read_zipper();
  let v44_28_origin = v44_28_cursor.path().len();
  for v44_28_byte in v44_28_cursor.child_mask().iter() {
    v44_28_cursor.descend_to_existing_byte(v44_28_byte);
    {
    let v45_2: Space = singleton(&v44_28_cursor.path()[v44_28_origin..(v44_28_origin + 1)]);
    let v45_3: Space = intersect(&(*CONSTANT_22),&(v45_2));
    let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
    drop(v45_3);
    let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
    drop(v45_4);
    let v45_8: Space = if (&(v45_5)).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&v44_28_cursor.path()[v44_28_origin..(v44_28_origin + 1)]);
      let v46_7: Space = routine_5(c, &(v46_6), &(*p1), &v44_28_cursor, &(*s1));
      compose(&(v45_5),&(v46_7))
    };
    drop(v45_5);
    let v45_9: Space = intersect(&(*CONSTANT_22),&(v45_2));
    drop(v45_2);
    let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
    drop(v45_9);
    let v45_28: Space = if (&(v45_10)).is_empty() { Space::new() } else {
      let v47_6: Path = concat_path(&(*p0),&v44_28_cursor.path()[v44_28_origin..(v44_28_origin + 1)]);
      let v47_12: Space = if (&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p1))),&(descend_cursor(descend_cursor((*CONSTANT_24).read_zipper(),&(*p0)),&v44_28_cursor.path()[v44_28_origin..(v44_28_origin + 1)])))
      };
      let v47_13: Path = concat_path(&(*p1),&(v47_6));
      drop(v47_6);
      let v47_14: Space = singleton(&(v47_13));
      drop(v47_13);
      let v47_15: Space = subtract(&(v47_12),&(v47_14));
      drop(v47_12);
      let v47_16: Space = intersect(&(v47_15),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))));
      drop(v47_15);
      let v47_17: Space = range_const::<{2},{3}>(&(v47_16));
      drop(v47_16);
      let mut v47_18 = Space::new();
      let mut v47_18_write = v47_18.write_zipper();
      let mut v47_18_cursor = (v47_17).read_zipper();
      let v47_18_origin = v47_18_cursor.path().len();
      for v47_18_byte in v47_18_cursor.child_mask().iter() {
        v47_18_cursor.descend_to_existing_byte(v47_18_byte);
        {
        let v49_2: Space = singleton(&v47_18_cursor.path()[v47_18_origin..(v47_18_origin + 1)]);
        let v49_3: Space = intersect(&(*CONSTANT_22),&(v49_2));
        let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
        drop(v49_3);
        let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
        drop(v49_4);
        let v49_7: Space = if (&(v49_5)).is_empty() { Space::new() } else {
          let v50_6: Space = routine_13(c, &v47_18_cursor.path()[v47_18_origin..(v47_18_origin + 1)], &v47_18_cursor);
          compose(&(v49_5),&(v50_6))
        };
        drop(v49_5);
        let v49_8: Space = intersect(&(*CONSTANT_22),&(v49_2));
        drop(v49_2);
        let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
        drop(v49_8);
        let v49_10: Space = compose(&(v49_9),&(*CONSTANT_25));
        drop(v49_9);
        let v49_11: Space = unite(&(v49_7),&(v49_10));
        drop(v49_10);
        join_wrapped_into(&mut v47_18_write,&((v49_11).read_zipper()),&[]);
        }
        v47_18_cursor.ascend(1);
      }
      drop(v47_18_cursor);
      drop(v47_18_write);
      drop(v47_17);
      let v47_20: Space = if (&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p1))),&(descend_cursor(descend_cursor((*CONSTANT_24).read_zipper(),&(*p0)),&v44_28_cursor.path()[v44_28_origin..(v44_28_origin + 1)])))
      };
      let v47_21: Space = subtract(&(v47_20),&(v47_14));
      drop(v47_20);
      let v47_22: Space = intersect(&(v47_21),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))));
      drop(v47_21);
      let v47_23: Space = range_const::<{3},{4}>(&(v47_22));
      drop(v47_22);
      let mut v47_24 = Space::new();
      let mut v47_24_write = v47_24.write_zipper();
      let mut v47_24_cursor = (v47_23).read_zipper();
      let v47_24_origin = v47_24_cursor.path().len();
      for v47_24_byte in v47_24_cursor.child_mask().iter() {
        v47_24_cursor.descend_to_existing_byte(v47_24_byte);
        {
        let v52_2: Space = singleton(&v47_24_cursor.path()[v47_24_origin..(v47_24_origin + 1)]);
        let v52_3: Space = intersect(&(*CONSTANT_22),&(v52_2));
        let v52_4: Space = if has_head(&(v52_3)) { singleton(&[]) } else { Space::new() };
        drop(v52_3);
        let v52_5: Space = subtract(&(*CONSTANT_0),&(v52_4));
        drop(v52_4);
        let v52_7: Space = if (&(v52_5)).is_empty() { Space::new() } else {
          let v53_6: Space = routine_14(c, &v47_24_cursor.path()[v47_24_origin..(v47_24_origin + 1)], &v47_24_cursor);
          compose(&(v52_5),&(v53_6))
        };
        drop(v52_5);
        let v52_8: Space = intersect(&(*CONSTANT_22),&(v52_2));
        drop(v52_2);
        let v52_9: Space = if has_head(&(v52_8)) { singleton(&[]) } else { Space::new() };
        drop(v52_8);
        let v52_10: Space = compose(&(v52_9),&(*CONSTANT_25));
        drop(v52_9);
        let v52_11: Space = unite(&(v52_7),&(v52_10));
        drop(v52_10);
        join_wrapped_into(&mut v47_24_write,&((v52_11).read_zipper()),&[]);
        }
        v47_24_cursor.ascend(1);
      }
      drop(v47_24_cursor);
      drop(v47_24_write);
      drop(v47_23);
      let v47_25: Space = subtract(&(v47_18),&(v47_24));
      let v47_26: Space = if (&(v47_25)).is_empty() { Space::new() } else {
        compose(&(v47_25),&(v47_14))
      };
      drop(v47_14);
      let mut v47_27 = Space::new();
      let mut v47_27_write = v47_27.write_zipper();
      let mut v47_27_cursor = (v47_26).read_zipper();
      let v47_27_origin = v47_27_cursor.path().len();
      for v47_27_byte in v47_27_cursor.child_mask().iter() {
        v47_27_cursor.descend_to_existing_byte(v47_27_byte);
        {
        let v55_2: Space = singleton(&v47_27_cursor.path()[v47_27_origin..(v47_27_origin + 1)]);
        let v55_3: Space = intersect(&(*CONSTANT_22),&(v55_2));
        let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
        drop(v55_3);
        let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
        drop(v55_4);
        let v55_7: Space = if (&(v55_5)).is_empty() { Space::new() } else {
          let v56_6: Space = routine_15(c, &v47_27_cursor.path()[v47_27_origin..(v47_27_origin + 1)], &v47_27_cursor);
          compose(&(v55_5),&(v56_6))
        };
        drop(v55_5);
        let v55_8: Space = intersect(&(*CONSTANT_22),&(v55_2));
        drop(v55_2);
        let v55_9: Space = if has_head(&(v55_8)) { singleton(&[]) } else { Space::new() };
        drop(v55_8);
        let v55_10: Space = compose(&(v55_9),&v47_27_cursor);
        drop(v55_9);
        let v55_11: Space = unite(&(v55_7),&(v55_10));
        drop(v55_10);
        join_wrapped_into(&mut v47_27_write,&((v55_11).read_zipper()),&[]);
        }
        v47_27_cursor.ascend(1);
      }
      drop(v47_27_cursor);
      drop(v47_27_write);
      compose(&(v45_10),&(v47_27))
    };
    drop(v45_10);
    let v45_29: Space = unite(&(v45_8),&(v45_28));
    join_wrapped_into(&mut v44_28_write,&((v45_29).read_zipper()),&[]);
    }
    v44_28_cursor.ascend(1);
  }
  drop(v44_28_cursor);
  drop(v44_28_write);
  (v44_28).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v57_8: Space = if (&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p1))),&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p0))))
  };
  let v57_9: Path = concat_path(&(*p1),&(*p0));
  let v57_10: Space = singleton(&(v57_9));
  drop(v57_9);
  let v57_11: Space = subtract(&(v57_8),&(v57_10));
  drop(v57_8);
  let v57_14: Space = intersect(&(v57_11),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))));
  drop(v57_11);
  let v57_15: Space = range_const::<{2},{3}>(&(v57_14));
  drop(v57_14);
  let mut v57_24 = Space::new();
  let mut v57_24_write = v57_24.write_zipper();
  let mut v57_24_cursor = (v57_15).read_zipper();
  let v57_24_origin = v57_24_cursor.path().len();
  for v57_24_byte in v57_24_cursor.child_mask().iter() {
    v57_24_cursor.descend_to_existing_byte(v57_24_byte);
    {
    let v59_2: Space = singleton(&v57_24_cursor.path()[v57_24_origin..(v57_24_origin + 1)]);
    let v59_3: Space = intersect(&(*CONSTANT_22),&(v59_2));
    let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
    drop(v59_3);
    let v59_5: Space = subtract(&(*CONSTANT_0),&(v59_4));
    drop(v59_4);
    let v59_7: Space = if (&(v59_5)).is_empty() { Space::new() } else {
      let mut v60_6 = Space::new();
      let mut v60_6_write = v60_6.write_zipper();
      for v60_6_byte in v57_24_cursor.child_mask().iter() {
        v57_24_cursor.descend_to_existing_byte(v60_6_byte);
        {
        let v61_2: Space = singleton(&v57_24_cursor.path()[(v57_24_origin + 1)..(v57_24_origin + 2)]);
        let v61_3: Space = intersect(&(*CONSTANT_22),&(v61_2));
        let v61_4: Space = if has_head(&(v61_3)) { singleton(&[]) } else { Space::new() };
        drop(v61_3);
        let v61_5: Space = subtract(&(*CONSTANT_0),&(v61_4));
        drop(v61_4);
        let v61_8: Space = if (&(v61_5)).is_empty() { Space::new() } else {
          let v62_7: Space = routine_13(c, &v57_24_cursor.path()[v57_24_origin..(v57_24_origin + 2)], &v57_24_cursor);
          compose(&(v61_5),&(v62_7))
        };
        drop(v61_5);
        let v61_9: Space = intersect(&(*CONSTANT_22),&(v61_2));
        drop(v61_2);
        let v61_10: Space = if has_head(&(v61_9)) { singleton(&[]) } else { Space::new() };
        drop(v61_9);
        let v61_11: Space = compose(&(v61_10),&(*CONSTANT_25));
        drop(v61_10);
        let v61_12: Space = unite(&(v61_8),&(v61_11));
        drop(v61_11);
        join_wrapped_into(&mut v60_6_write,&((v61_12).read_zipper()),&[]);
        }
        v57_24_cursor.ascend(1);
      }
      drop(v60_6_write);
      compose(&(v59_5),&(v60_6))
    };
    drop(v59_5);
    let v59_8: Space = intersect(&(*CONSTANT_22),&(v59_2));
    drop(v59_2);
    let v59_9: Space = if has_head(&(v59_8)) { singleton(&[]) } else { Space::new() };
    drop(v59_8);
    let v59_10: Space = compose(&(v59_9),&(*CONSTANT_25));
    drop(v59_9);
    let v59_11: Space = unite(&(v59_7),&(v59_10));
    drop(v59_10);
    join_wrapped_into(&mut v57_24_write,&((v59_11).read_zipper()),&[]);
    }
    v57_24_cursor.ascend(1);
  }
  drop(v57_24_cursor);
  drop(v57_24_write);
  drop(v57_15);
  let v57_29: Space = if (&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p1))),&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p0))))
  };
  let v57_30: Space = subtract(&(v57_29),&(v57_10));
  drop(v57_29);
  let v57_31: Space = intersect(&(v57_30),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))));
  drop(v57_30);
  let v57_32: Space = range_const::<{3},{4}>(&(v57_31));
  drop(v57_31);
  let mut v57_41 = Space::new();
  let mut v57_41_write = v57_41.write_zipper();
  let mut v57_41_cursor = (v57_32).read_zipper();
  let v57_41_origin = v57_41_cursor.path().len();
  for v57_41_byte in v57_41_cursor.child_mask().iter() {
    v57_41_cursor.descend_to_existing_byte(v57_41_byte);
    {
    let v64_2: Space = singleton(&v57_41_cursor.path()[v57_41_origin..(v57_41_origin + 1)]);
    let v64_3: Space = intersect(&(*CONSTANT_22),&(v64_2));
    let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
    drop(v64_3);
    let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
    drop(v64_4);
    let v64_7: Space = if (&(v64_5)).is_empty() { Space::new() } else {
      let mut v65_6 = Space::new();
      let mut v65_6_write = v65_6.write_zipper();
      for v65_6_byte in v57_41_cursor.child_mask().iter() {
        v57_41_cursor.descend_to_existing_byte(v65_6_byte);
        {
        let v66_2: Space = singleton(&v57_41_cursor.path()[(v57_41_origin + 1)..(v57_41_origin + 2)]);
        let v66_3: Space = intersect(&(*CONSTANT_22),&(v66_2));
        let v66_4: Space = if has_head(&(v66_3)) { singleton(&[]) } else { Space::new() };
        drop(v66_3);
        let v66_5: Space = subtract(&(*CONSTANT_0),&(v66_4));
        drop(v66_4);
        let v66_8: Space = if (&(v66_5)).is_empty() { Space::new() } else {
          let v67_7: Space = routine_14(c, &v57_41_cursor.path()[v57_41_origin..(v57_41_origin + 2)], &v57_41_cursor);
          compose(&(v66_5),&(v67_7))
        };
        drop(v66_5);
        let v66_9: Space = intersect(&(*CONSTANT_22),&(v66_2));
        drop(v66_2);
        let v66_10: Space = if has_head(&(v66_9)) { singleton(&[]) } else { Space::new() };
        drop(v66_9);
        let v66_11: Space = compose(&(v66_10),&(*CONSTANT_25));
        drop(v66_10);
        let v66_12: Space = unite(&(v66_8),&(v66_11));
        drop(v66_11);
        join_wrapped_into(&mut v65_6_write,&((v66_12).read_zipper()),&[]);
        }
        v57_41_cursor.ascend(1);
      }
      drop(v65_6_write);
      compose(&(v64_5),&(v65_6))
    };
    drop(v64_5);
    let v64_8: Space = intersect(&(*CONSTANT_22),&(v64_2));
    drop(v64_2);
    let v64_9: Space = if has_head(&(v64_8)) { singleton(&[]) } else { Space::new() };
    drop(v64_8);
    let v64_10: Space = compose(&(v64_9),&(*CONSTANT_25));
    drop(v64_9);
    let v64_11: Space = unite(&(v64_7),&(v64_10));
    drop(v64_10);
    join_wrapped_into(&mut v57_41_write,&((v64_11).read_zipper()),&[]);
    }
    v57_41_cursor.ascend(1);
  }
  drop(v57_41_cursor);
  drop(v57_41_write);
  drop(v57_32);
  let v57_42: Space = subtract(&(v57_24),&(v57_41));
  let v57_43: Space = if (&(v57_42)).is_empty() { Space::new() } else {
    compose(&(v57_42),&(v57_10))
  };
  drop(v57_10);
  let mut v57_50 = Space::new();
  let mut v57_50_write = v57_50.write_zipper();
  let mut v57_50_cursor = (v57_43).read_zipper();
  let v57_50_origin = v57_50_cursor.path().len();
  for v57_50_byte in v57_50_cursor.child_mask().iter() {
    v57_50_cursor.descend_to_existing_byte(v57_50_byte);
    {
    let v69_2: Space = singleton(&v57_50_cursor.path()[v57_50_origin..(v57_50_origin + 1)]);
    let v69_3: Space = intersect(&(*CONSTANT_22),&(v69_2));
    let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
    drop(v69_3);
    let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
    drop(v69_4);
    let v69_7: Space = if (&(v69_5)).is_empty() { Space::new() } else {
      let mut v70_6 = Space::new();
      let mut v70_6_write = v70_6.write_zipper();
      for v70_6_byte in v57_50_cursor.child_mask().iter() {
        v57_50_cursor.descend_to_existing_byte(v70_6_byte);
        {
        let v71_2: Space = singleton(&v57_50_cursor.path()[(v57_50_origin + 1)..(v57_50_origin + 2)]);
        let v71_3: Space = intersect(&(*CONSTANT_22),&(v71_2));
        let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
        drop(v71_3);
        let v71_5: Space = subtract(&(*CONSTANT_0),&(v71_4));
        drop(v71_4);
        let v71_8: Space = if (&(v71_5)).is_empty() { Space::new() } else {
          let v72_7: Space = routine_15(c, &v57_50_cursor.path()[v57_50_origin..(v57_50_origin + 2)], &v57_50_cursor);
          compose(&(v71_5),&(v72_7))
        };
        drop(v71_5);
        let v71_9: Space = intersect(&(*CONSTANT_22),&(v71_2));
        drop(v71_2);
        let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
        drop(v71_9);
        let v71_11: Space = compose(&(v71_10),&v57_50_cursor);
        drop(v71_10);
        let v71_12: Space = unite(&(v71_8),&(v71_11));
        drop(v71_11);
        join_wrapped_into(&mut v70_6_write,&((v71_12).read_zipper()),&[]);
        }
        v57_50_cursor.ascend(1);
      }
      drop(v70_6_write);
      compose(&(v69_5),&(v70_6))
    };
    drop(v69_5);
    let v69_8: Space = intersect(&(*CONSTANT_22),&(v69_2));
    drop(v69_2);
    let v69_9: Space = if has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
    drop(v69_8);
    let v69_10: Space = compose(&(v69_9),&v57_50_cursor);
    drop(v69_9);
    let v69_11: Space = unite(&(v69_7),&(v69_10));
    drop(v69_10);
    join_wrapped_into(&mut v57_50_write,&((v69_11).read_zipper()),&[]);
    }
    v57_50_cursor.ascend(1);
  }
  drop(v57_50_cursor);
  drop(v57_50_write);
  (v57_50).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v73_10 = Space::new();
  let mut v73_10_write = v73_10.write_zipper();
  let mut v73_10_cursor = (*s0).read_zipper();
  let v73_10_origin = v73_10_cursor.path().len();
  for v73_10_byte in v73_10_cursor.child_mask().iter() {
    v73_10_cursor.descend_to_existing_byte(v73_10_byte);
    {
    let v74_2: Space = singleton(&v73_10_cursor.path()[v73_10_origin..(v73_10_origin + 1)]);
    let v74_3: Space = intersect(&(*CONSTANT_22),&(v74_2));
    let v74_4: Space = if has_head(&(v74_3)) { singleton(&[]) } else { Space::new() };
    drop(v74_3);
    let v74_5: Space = subtract(&(*CONSTANT_0),&(v74_4));
    drop(v74_4);
    let v74_8: Space = if (&(v74_5)).is_empty() { Space::new() } else {
      let v75_6: Path = concat_path(&(*p0),&v73_10_cursor.path()[v73_10_origin..(v73_10_origin + 1)]);
      let v75_7: Space = routine_7(c, &(v75_6), &(*p1), &v73_10_cursor);
      compose(&(v74_5),&(v75_7))
    };
    drop(v74_5);
    let v74_9: Space = intersect(&(*CONSTANT_22),&(v74_2));
    drop(v74_2);
    let v74_10: Space = if has_head(&(v74_9)) { singleton(&[]) } else { Space::new() };
    drop(v74_9);
    let v74_16: Space = if (&(v74_10)).is_empty() { Space::new() } else {
      let v76_6: Path = concat_path(&(*p0),&v73_10_cursor.path()[v73_10_origin..(v73_10_origin + 1)]);
      let v76_12: Space = if (&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p1))),&(descend_cursor(descend_cursor((*CONSTANT_24).read_zipper(),&(*p0)),&v73_10_cursor.path()[v73_10_origin..(v73_10_origin + 1)])))
      };
      let v76_13: Path = concat_path(&(*p1),&(v76_6));
      drop(v76_6);
      let v76_14: Space = singleton(&(v76_13));
      drop(v76_13);
      let v76_15: Space = subtract(&(v76_12),&(v76_14));
      drop(v76_12);
      drop(v76_14);
      compose(&(v74_10),&(v76_15))
    };
    drop(v74_10);
    let v74_17: Space = unite(&(v74_8),&(v74_16));
    drop(v74_16);
    join_wrapped_into(&mut v73_10_write,&((v74_17).read_zipper()),&[]);
    }
    v73_10_cursor.ascend(1);
  }
  drop(v73_10_cursor);
  drop(v73_10_write);
  (v73_10).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v78_28 = Space::new();
  let mut v78_28_write = v78_28.write_zipper();
  let mut v78_28_cursor = (*s0).read_zipper();
  let v78_28_origin = v78_28_cursor.path().len();
  for v78_28_byte in v78_28_cursor.child_mask().iter() {
    v78_28_cursor.descend_to_existing_byte(v78_28_byte);
    {
    let v79_2: Space = singleton(&v78_28_cursor.path()[v78_28_origin..(v78_28_origin + 1)]);
    let v79_3: Space = intersect(&(*CONSTANT_22),&(v79_2));
    let v79_4: Space = if has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
    drop(v79_3);
    let v79_5: Space = subtract(&(*CONSTANT_0),&(v79_4));
    drop(v79_4);
    let v79_8: Space = if (&(v79_5)).is_empty() { Space::new() } else {
      let v80_6: Path = concat_path(&(*p0),&v78_28_cursor.path()[v78_28_origin..(v78_28_origin + 1)]);
      let v80_7: Space = routine_8(c, &(v80_6), &(*p1), &v78_28_cursor, &(*s1));
      compose(&(v79_5),&(v80_7))
    };
    drop(v79_5);
    let v79_9: Space = intersect(&(*CONSTANT_22),&(v79_2));
    drop(v79_2);
    let v79_10: Space = if has_head(&(v79_9)) { singleton(&[]) } else { Space::new() };
    drop(v79_9);
    let v79_28: Space = if (&(v79_10)).is_empty() { Space::new() } else {
      let v81_6: Path = concat_path(&(*p0),&v78_28_cursor.path()[v78_28_origin..(v78_28_origin + 1)]);
      let v81_12: Space = if (&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p1))),&(descend_cursor(descend_cursor((*CONSTANT_24).read_zipper(),&(*p0)),&v78_28_cursor.path()[v78_28_origin..(v78_28_origin + 1)])))
      };
      let v81_13: Path = concat_path(&(*p1),&(v81_6));
      drop(v81_6);
      let v81_14: Space = singleton(&(v81_13));
      drop(v81_13);
      let v81_15: Space = subtract(&(v81_12),&(v81_14));
      drop(v81_12);
      let v81_16: Space = intersect(&(v81_15),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))));
      drop(v81_15);
      let v81_17: Space = range_const::<{3},{4}>(&(v81_16));
      drop(v81_16);
      let mut v81_18 = Space::new();
      let mut v81_18_write = v81_18.write_zipper();
      let mut v81_18_cursor = (v81_17).read_zipper();
      let v81_18_origin = v81_18_cursor.path().len();
      for v81_18_byte in v81_18_cursor.child_mask().iter() {
        v81_18_cursor.descend_to_existing_byte(v81_18_byte);
        {
        let v83_2: Space = singleton(&v81_18_cursor.path()[v81_18_origin..(v81_18_origin + 1)]);
        let v83_3: Space = intersect(&(*CONSTANT_22),&(v83_2));
        let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
        drop(v83_3);
        let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
        drop(v83_4);
        let v83_7: Space = if (&(v83_5)).is_empty() { Space::new() } else {
          let v84_6: Space = routine_10(c, &v81_18_cursor.path()[v81_18_origin..(v81_18_origin + 1)], &v81_18_cursor);
          compose(&(v83_5),&(v84_6))
        };
        drop(v83_5);
        let v83_8: Space = intersect(&(*CONSTANT_22),&(v83_2));
        drop(v83_2);
        let v83_9: Space = if has_head(&(v83_8)) { singleton(&[]) } else { Space::new() };
        drop(v83_8);
        let v83_10: Space = compose(&(v83_9),&(*CONSTANT_25));
        drop(v83_9);
        let v83_11: Space = unite(&(v83_7),&(v83_10));
        drop(v83_10);
        join_wrapped_into(&mut v81_18_write,&((v83_11).read_zipper()),&[]);
        }
        v81_18_cursor.ascend(1);
      }
      drop(v81_18_cursor);
      drop(v81_18_write);
      drop(v81_17);
      let v81_20: Space = if (&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p1))),&(descend_cursor(descend_cursor((*CONSTANT_24).read_zipper(),&(*p0)),&v78_28_cursor.path()[v78_28_origin..(v78_28_origin + 1)])))
      };
      let v81_21: Space = subtract(&(v81_20),&(v81_14));
      drop(v81_20);
      let v81_22: Space = intersect(&(v81_21),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))));
      drop(v81_21);
      let v81_23: Space = range_const::<{4},{5}>(&(v81_22));
      drop(v81_22);
      let mut v81_24 = Space::new();
      let mut v81_24_write = v81_24.write_zipper();
      let mut v81_24_cursor = (v81_23).read_zipper();
      let v81_24_origin = v81_24_cursor.path().len();
      for v81_24_byte in v81_24_cursor.child_mask().iter() {
        v81_24_cursor.descend_to_existing_byte(v81_24_byte);
        {
        let v86_2: Space = singleton(&v81_24_cursor.path()[v81_24_origin..(v81_24_origin + 1)]);
        let v86_3: Space = intersect(&(*CONSTANT_22),&(v86_2));
        let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
        drop(v86_3);
        let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
        drop(v86_4);
        let v86_7: Space = if (&(v86_5)).is_empty() { Space::new() } else {
          let v87_6: Space = routine_11(c, &v81_24_cursor.path()[v81_24_origin..(v81_24_origin + 1)], &v81_24_cursor);
          compose(&(v86_5),&(v87_6))
        };
        drop(v86_5);
        let v86_8: Space = intersect(&(*CONSTANT_22),&(v86_2));
        drop(v86_2);
        let v86_9: Space = if has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
        drop(v86_8);
        let v86_10: Space = compose(&(v86_9),&(*CONSTANT_25));
        drop(v86_9);
        let v86_11: Space = unite(&(v86_7),&(v86_10));
        drop(v86_10);
        join_wrapped_into(&mut v81_24_write,&((v86_11).read_zipper()),&[]);
        }
        v81_24_cursor.ascend(1);
      }
      drop(v81_24_cursor);
      drop(v81_24_write);
      drop(v81_23);
      let v81_25: Space = subtract(&(v81_18),&(v81_24));
      let v81_26: Space = if (&(v81_25)).is_empty() { Space::new() } else {
        compose(&(v81_25),&(v81_14))
      };
      drop(v81_14);
      let mut v81_27 = Space::new();
      let mut v81_27_write = v81_27.write_zipper();
      let mut v81_27_cursor = (v81_26).read_zipper();
      let v81_27_origin = v81_27_cursor.path().len();
      for v81_27_byte in v81_27_cursor.child_mask().iter() {
        v81_27_cursor.descend_to_existing_byte(v81_27_byte);
        {
        let v89_2: Space = singleton(&v81_27_cursor.path()[v81_27_origin..(v81_27_origin + 1)]);
        let v89_3: Space = intersect(&(*CONSTANT_22),&(v89_2));
        let v89_4: Space = if has_head(&(v89_3)) { singleton(&[]) } else { Space::new() };
        drop(v89_3);
        let v89_5: Space = subtract(&(*CONSTANT_0),&(v89_4));
        drop(v89_4);
        let v89_7: Space = if (&(v89_5)).is_empty() { Space::new() } else {
          let v90_6: Space = routine_12(c, &v81_27_cursor.path()[v81_27_origin..(v81_27_origin + 1)], &v81_27_cursor);
          compose(&(v89_5),&(v90_6))
        };
        drop(v89_5);
        let v89_8: Space = intersect(&(*CONSTANT_22),&(v89_2));
        drop(v89_2);
        let v89_9: Space = if has_head(&(v89_8)) { singleton(&[]) } else { Space::new() };
        drop(v89_8);
        let v89_10: Space = compose(&(v89_9),&v81_27_cursor);
        drop(v89_9);
        let v89_11: Space = unite(&(v89_7),&(v89_10));
        drop(v89_10);
        join_wrapped_into(&mut v81_27_write,&((v89_11).read_zipper()),&[]);
        }
        v81_27_cursor.ascend(1);
      }
      drop(v81_27_cursor);
      drop(v81_27_write);
      compose(&(v79_10),&(v81_27))
    };
    drop(v79_10);
    let v79_29: Space = unite(&(v79_8),&(v79_28));
    join_wrapped_into(&mut v78_28_write,&((v79_29).read_zipper()),&[]);
    }
    v78_28_cursor.ascend(1);
  }
  drop(v78_28_cursor);
  drop(v78_28_write);
  (v78_28).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v91_8: Space = if (&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p1))),&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p0))))
  };
  let v91_9: Path = concat_path(&(*p1),&(*p0));
  let v91_10: Space = singleton(&(v91_9));
  drop(v91_9);
  let v91_11: Space = subtract(&(v91_8),&(v91_10));
  drop(v91_8);
  let v91_14: Space = intersect(&(v91_11),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))));
  drop(v91_11);
  let v91_15: Space = range_const::<{3},{4}>(&(v91_14));
  drop(v91_14);
  let mut v91_24 = Space::new();
  let mut v91_24_write = v91_24.write_zipper();
  let mut v91_24_cursor = (v91_15).read_zipper();
  let v91_24_origin = v91_24_cursor.path().len();
  for v91_24_byte in v91_24_cursor.child_mask().iter() {
    v91_24_cursor.descend_to_existing_byte(v91_24_byte);
    {
    let v93_2: Space = singleton(&v91_24_cursor.path()[v91_24_origin..(v91_24_origin + 1)]);
    let v93_3: Space = intersect(&(*CONSTANT_22),&(v93_2));
    let v93_4: Space = if has_head(&(v93_3)) { singleton(&[]) } else { Space::new() };
    drop(v93_3);
    let v93_5: Space = subtract(&(*CONSTANT_0),&(v93_4));
    drop(v93_4);
    let v93_7: Space = if (&(v93_5)).is_empty() { Space::new() } else {
      let mut v94_6 = Space::new();
      let mut v94_6_write = v94_6.write_zipper();
      for v94_6_byte in v91_24_cursor.child_mask().iter() {
        v91_24_cursor.descend_to_existing_byte(v94_6_byte);
        {
        let v95_2: Space = singleton(&v91_24_cursor.path()[(v91_24_origin + 1)..(v91_24_origin + 2)]);
        let v95_3: Space = intersect(&(*CONSTANT_22),&(v95_2));
        let v95_4: Space = if has_head(&(v95_3)) { singleton(&[]) } else { Space::new() };
        drop(v95_3);
        let v95_5: Space = subtract(&(*CONSTANT_0),&(v95_4));
        drop(v95_4);
        let v95_8: Space = if (&(v95_5)).is_empty() { Space::new() } else {
          let v96_7: Space = routine_10(c, &v91_24_cursor.path()[v91_24_origin..(v91_24_origin + 2)], &v91_24_cursor);
          compose(&(v95_5),&(v96_7))
        };
        drop(v95_5);
        let v95_9: Space = intersect(&(*CONSTANT_22),&(v95_2));
        drop(v95_2);
        let v95_10: Space = if has_head(&(v95_9)) { singleton(&[]) } else { Space::new() };
        drop(v95_9);
        let v95_11: Space = compose(&(v95_10),&(*CONSTANT_25));
        drop(v95_10);
        let v95_12: Space = unite(&(v95_8),&(v95_11));
        drop(v95_11);
        join_wrapped_into(&mut v94_6_write,&((v95_12).read_zipper()),&[]);
        }
        v91_24_cursor.ascend(1);
      }
      drop(v94_6_write);
      compose(&(v93_5),&(v94_6))
    };
    drop(v93_5);
    let v93_8: Space = intersect(&(*CONSTANT_22),&(v93_2));
    drop(v93_2);
    let v93_9: Space = if has_head(&(v93_8)) { singleton(&[]) } else { Space::new() };
    drop(v93_8);
    let v93_10: Space = compose(&(v93_9),&(*CONSTANT_25));
    drop(v93_9);
    let v93_11: Space = unite(&(v93_7),&(v93_10));
    drop(v93_10);
    join_wrapped_into(&mut v91_24_write,&((v93_11).read_zipper()),&[]);
    }
    v91_24_cursor.ascend(1);
  }
  drop(v91_24_cursor);
  drop(v91_24_write);
  drop(v91_15);
  let v91_29: Space = if (&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p1))),&(descend_cursor((*CONSTANT_24).read_zipper(),&(*p0))))
  };
  let v91_30: Space = subtract(&(v91_29),&(v91_10));
  drop(v91_29);
  let v91_31: Space = intersect(&(v91_30),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_23))));
  drop(v91_30);
  let v91_32: Space = range_const::<{4},{5}>(&(v91_31));
  drop(v91_31);
  let mut v91_41 = Space::new();
  let mut v91_41_write = v91_41.write_zipper();
  let mut v91_41_cursor = (v91_32).read_zipper();
  let v91_41_origin = v91_41_cursor.path().len();
  for v91_41_byte in v91_41_cursor.child_mask().iter() {
    v91_41_cursor.descend_to_existing_byte(v91_41_byte);
    {
    let v98_2: Space = singleton(&v91_41_cursor.path()[v91_41_origin..(v91_41_origin + 1)]);
    let v98_3: Space = intersect(&(*CONSTANT_22),&(v98_2));
    let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
    drop(v98_3);
    let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
    drop(v98_4);
    let v98_7: Space = if (&(v98_5)).is_empty() { Space::new() } else {
      let mut v99_6 = Space::new();
      let mut v99_6_write = v99_6.write_zipper();
      for v99_6_byte in v91_41_cursor.child_mask().iter() {
        v91_41_cursor.descend_to_existing_byte(v99_6_byte);
        {
        let v100_2: Space = singleton(&v91_41_cursor.path()[(v91_41_origin + 1)..(v91_41_origin + 2)]);
        let v100_3: Space = intersect(&(*CONSTANT_22),&(v100_2));
        let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
        drop(v100_3);
        let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
        drop(v100_4);
        let v100_8: Space = if (&(v100_5)).is_empty() { Space::new() } else {
          let v101_7: Space = routine_11(c, &v91_41_cursor.path()[v91_41_origin..(v91_41_origin + 2)], &v91_41_cursor);
          compose(&(v100_5),&(v101_7))
        };
        drop(v100_5);
        let v100_9: Space = intersect(&(*CONSTANT_22),&(v100_2));
        drop(v100_2);
        let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
        drop(v100_9);
        let v100_11: Space = compose(&(v100_10),&(*CONSTANT_25));
        drop(v100_10);
        let v100_12: Space = unite(&(v100_8),&(v100_11));
        drop(v100_11);
        join_wrapped_into(&mut v99_6_write,&((v100_12).read_zipper()),&[]);
        }
        v91_41_cursor.ascend(1);
      }
      drop(v99_6_write);
      compose(&(v98_5),&(v99_6))
    };
    drop(v98_5);
    let v98_8: Space = intersect(&(*CONSTANT_22),&(v98_2));
    drop(v98_2);
    let v98_9: Space = if has_head(&(v98_8)) { singleton(&[]) } else { Space::new() };
    drop(v98_8);
    let v98_10: Space = compose(&(v98_9),&(*CONSTANT_25));
    drop(v98_9);
    let v98_11: Space = unite(&(v98_7),&(v98_10));
    drop(v98_10);
    join_wrapped_into(&mut v91_41_write,&((v98_11).read_zipper()),&[]);
    }
    v91_41_cursor.ascend(1);
  }
  drop(v91_41_cursor);
  drop(v91_41_write);
  drop(v91_32);
  let v91_42: Space = subtract(&(v91_24),&(v91_41));
  let v91_43: Space = if (&(v91_42)).is_empty() { Space::new() } else {
    compose(&(v91_42),&(v91_10))
  };
  drop(v91_10);
  let mut v91_50 = Space::new();
  let mut v91_50_write = v91_50.write_zipper();
  let mut v91_50_cursor = (v91_43).read_zipper();
  let v91_50_origin = v91_50_cursor.path().len();
  for v91_50_byte in v91_50_cursor.child_mask().iter() {
    v91_50_cursor.descend_to_existing_byte(v91_50_byte);
    {
    let v103_2: Space = singleton(&v91_50_cursor.path()[v91_50_origin..(v91_50_origin + 1)]);
    let v103_3: Space = intersect(&(*CONSTANT_22),&(v103_2));
    let v103_4: Space = if has_head(&(v103_3)) { singleton(&[]) } else { Space::new() };
    drop(v103_3);
    let v103_5: Space = subtract(&(*CONSTANT_0),&(v103_4));
    drop(v103_4);
    let v103_7: Space = if (&(v103_5)).is_empty() { Space::new() } else {
      let mut v104_6 = Space::new();
      let mut v104_6_write = v104_6.write_zipper();
      for v104_6_byte in v91_50_cursor.child_mask().iter() {
        v91_50_cursor.descend_to_existing_byte(v104_6_byte);
        {
        let v105_2: Space = singleton(&v91_50_cursor.path()[(v91_50_origin + 1)..(v91_50_origin + 2)]);
        let v105_3: Space = intersect(&(*CONSTANT_22),&(v105_2));
        let v105_4: Space = if has_head(&(v105_3)) { singleton(&[]) } else { Space::new() };
        drop(v105_3);
        let v105_5: Space = subtract(&(*CONSTANT_0),&(v105_4));
        drop(v105_4);
        let v105_8: Space = if (&(v105_5)).is_empty() { Space::new() } else {
          let v106_7: Space = routine_12(c, &v91_50_cursor.path()[v91_50_origin..(v91_50_origin + 2)], &v91_50_cursor);
          compose(&(v105_5),&(v106_7))
        };
        drop(v105_5);
        let v105_9: Space = intersect(&(*CONSTANT_22),&(v105_2));
        drop(v105_2);
        let v105_10: Space = if has_head(&(v105_9)) { singleton(&[]) } else { Space::new() };
        drop(v105_9);
        let v105_11: Space = compose(&(v105_10),&v91_50_cursor);
        drop(v105_10);
        let v105_12: Space = unite(&(v105_8),&(v105_11));
        drop(v105_11);
        join_wrapped_into(&mut v104_6_write,&((v105_12).read_zipper()),&[]);
        }
        v91_50_cursor.ascend(1);
      }
      drop(v104_6_write);
      compose(&(v103_5),&(v104_6))
    };
    drop(v103_5);
    let v103_8: Space = intersect(&(*CONSTANT_22),&(v103_2));
    drop(v103_2);
    let v103_9: Space = if has_head(&(v103_8)) { singleton(&[]) } else { Space::new() };
    drop(v103_8);
    let v103_10: Space = compose(&(v103_9),&v91_50_cursor);
    drop(v103_9);
    let v103_11: Space = unite(&(v103_7),&(v103_10));
    drop(v103_10);
    join_wrapped_into(&mut v91_50_write,&((v103_11).read_zipper()),&[]);
    }
    v91_50_cursor.ascend(1);
  }
  drop(v91_50_cursor);
  drop(v91_50_write);
  (v91_50).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v107_6 = Space::new();
  let mut v107_6_write = v107_6.write_zipper();
  let mut v107_6_cursor = (*s0).read_zipper();
  let v107_6_origin = v107_6_cursor.path().len();
  for v107_6_byte in v107_6_cursor.child_mask().iter() {
    v107_6_cursor.descend_to_existing_byte(v107_6_byte);
    {
    let v108_2: Space = singleton(&v107_6_cursor.path()[v107_6_origin..(v107_6_origin + 1)]);
    let v108_3: Space = intersect(&(*CONSTANT_22),&(v108_2));
    let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
    drop(v108_3);
    let v108_5: Space = subtract(&(*CONSTANT_0),&(v108_4));
    drop(v108_4);
    let v108_8: Space = if (&(v108_5)).is_empty() { Space::new() } else {
      let v109_6: Path = concat_path(&(*p0),&v107_6_cursor.path()[v107_6_origin..(v107_6_origin + 1)]);
      let v109_7: Space = routine_10(c, &(v109_6), &v107_6_cursor);
      drop(v109_6);
      compose(&(v108_5),&(v109_7))
    };
    drop(v108_5);
    let v108_9: Space = intersect(&(*CONSTANT_22),&(v108_2));
    drop(v108_2);
    let v108_10: Space = if has_head(&(v108_9)) { singleton(&[]) } else { Space::new() };
    drop(v108_9);
    let v108_11: Space = compose(&(v108_10),&(*CONSTANT_25));
    drop(v108_10);
    let v108_12: Space = unite(&(v108_8),&(v108_11));
    drop(v108_11);
    join_wrapped_into(&mut v107_6_write,&((v108_12).read_zipper()),&[]);
    }
    v107_6_cursor.ascend(1);
  }
  drop(v107_6_cursor);
  drop(v107_6_write);
  (v107_6).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v110_6 = Space::new();
  let mut v110_6_write = v110_6.write_zipper();
  let mut v110_6_cursor = (*s0).read_zipper();
  let v110_6_origin = v110_6_cursor.path().len();
  for v110_6_byte in v110_6_cursor.child_mask().iter() {
    v110_6_cursor.descend_to_existing_byte(v110_6_byte);
    {
    let v111_2: Space = singleton(&v110_6_cursor.path()[v110_6_origin..(v110_6_origin + 1)]);
    let v111_3: Space = intersect(&(*CONSTANT_22),&(v111_2));
    let v111_4: Space = if has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
    drop(v111_3);
    let v111_5: Space = subtract(&(*CONSTANT_0),&(v111_4));
    drop(v111_4);
    let v111_8: Space = if (&(v111_5)).is_empty() { Space::new() } else {
      let v112_6: Path = concat_path(&(*p0),&v110_6_cursor.path()[v110_6_origin..(v110_6_origin + 1)]);
      let v112_7: Space = routine_11(c, &(v112_6), &v110_6_cursor);
      drop(v112_6);
      compose(&(v111_5),&(v112_7))
    };
    drop(v111_5);
    let v111_9: Space = intersect(&(*CONSTANT_22),&(v111_2));
    drop(v111_2);
    let v111_10: Space = if has_head(&(v111_9)) { singleton(&[]) } else { Space::new() };
    drop(v111_9);
    let v111_11: Space = compose(&(v111_10),&(*CONSTANT_25));
    drop(v111_10);
    let v111_12: Space = unite(&(v111_8),&(v111_11));
    drop(v111_11);
    join_wrapped_into(&mut v110_6_write,&((v111_12).read_zipper()),&[]);
    }
    v110_6_cursor.ascend(1);
  }
  drop(v110_6_cursor);
  drop(v110_6_write);
  (v110_6).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v113_5 = Space::new();
  let mut v113_5_write = v113_5.write_zipper();
  let mut v113_5_cursor = (*s0).read_zipper();
  let v113_5_origin = v113_5_cursor.path().len();
  for v113_5_byte in v113_5_cursor.child_mask().iter() {
    v113_5_cursor.descend_to_existing_byte(v113_5_byte);
    {
    let v114_2: Space = singleton(&v113_5_cursor.path()[v113_5_origin..(v113_5_origin + 1)]);
    let v114_3: Space = intersect(&(*CONSTANT_22),&(v114_2));
    let v114_4: Space = if has_head(&(v114_3)) { singleton(&[]) } else { Space::new() };
    drop(v114_3);
    let v114_5: Space = subtract(&(*CONSTANT_0),&(v114_4));
    drop(v114_4);
    let v114_8: Space = if (&(v114_5)).is_empty() { Space::new() } else {
      let v115_6: Path = concat_path(&(*p0),&v113_5_cursor.path()[v113_5_origin..(v113_5_origin + 1)]);
      let v115_7: Space = routine_12(c, &(v115_6), &v113_5_cursor);
      drop(v115_6);
      compose(&(v114_5),&(v115_7))
    };
    drop(v114_5);
    let v114_9: Space = intersect(&(*CONSTANT_22),&(v114_2));
    drop(v114_2);
    let v114_10: Space = if has_head(&(v114_9)) { singleton(&[]) } else { Space::new() };
    drop(v114_9);
    let v114_11: Space = compose(&(v114_10),&v113_5_cursor);
    drop(v114_10);
    let v114_12: Space = unite(&(v114_8),&(v114_11));
    drop(v114_11);
    join_wrapped_into(&mut v113_5_write,&((v114_12).read_zipper()),&[]);
    }
    v113_5_cursor.ascend(1);
  }
  drop(v113_5_cursor);
  drop(v113_5_write);
  (v113_5).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v116_6 = Space::new();
  let mut v116_6_write = v116_6.write_zipper();
  let mut v116_6_cursor = (*s0).read_zipper();
  let v116_6_origin = v116_6_cursor.path().len();
  for v116_6_byte in v116_6_cursor.child_mask().iter() {
    v116_6_cursor.descend_to_existing_byte(v116_6_byte);
    {
    let v117_2: Space = singleton(&v116_6_cursor.path()[v116_6_origin..(v116_6_origin + 1)]);
    let v117_3: Space = intersect(&(*CONSTANT_22),&(v117_2));
    let v117_4: Space = if has_head(&(v117_3)) { singleton(&[]) } else { Space::new() };
    drop(v117_3);
    let v117_5: Space = subtract(&(*CONSTANT_0),&(v117_4));
    drop(v117_4);
    let v117_8: Space = if (&(v117_5)).is_empty() { Space::new() } else {
      let v118_6: Path = concat_path(&(*p0),&v116_6_cursor.path()[v116_6_origin..(v116_6_origin + 1)]);
      let v118_7: Space = routine_13(c, &(v118_6), &v116_6_cursor);
      drop(v118_6);
      compose(&(v117_5),&(v118_7))
    };
    drop(v117_5);
    let v117_9: Space = intersect(&(*CONSTANT_22),&(v117_2));
    drop(v117_2);
    let v117_10: Space = if has_head(&(v117_9)) { singleton(&[]) } else { Space::new() };
    drop(v117_9);
    let v117_11: Space = compose(&(v117_10),&(*CONSTANT_25));
    drop(v117_10);
    let v117_12: Space = unite(&(v117_8),&(v117_11));
    drop(v117_11);
    join_wrapped_into(&mut v116_6_write,&((v117_12).read_zipper()),&[]);
    }
    v116_6_cursor.ascend(1);
  }
  drop(v116_6_cursor);
  drop(v116_6_write);
  (v116_6).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v119_6 = Space::new();
  let mut v119_6_write = v119_6.write_zipper();
  let mut v119_6_cursor = (*s0).read_zipper();
  let v119_6_origin = v119_6_cursor.path().len();
  for v119_6_byte in v119_6_cursor.child_mask().iter() {
    v119_6_cursor.descend_to_existing_byte(v119_6_byte);
    {
    let v120_2: Space = singleton(&v119_6_cursor.path()[v119_6_origin..(v119_6_origin + 1)]);
    let v120_3: Space = intersect(&(*CONSTANT_22),&(v120_2));
    let v120_4: Space = if has_head(&(v120_3)) { singleton(&[]) } else { Space::new() };
    drop(v120_3);
    let v120_5: Space = subtract(&(*CONSTANT_0),&(v120_4));
    drop(v120_4);
    let v120_8: Space = if (&(v120_5)).is_empty() { Space::new() } else {
      let v121_6: Path = concat_path(&(*p0),&v119_6_cursor.path()[v119_6_origin..(v119_6_origin + 1)]);
      let v121_7: Space = routine_14(c, &(v121_6), &v119_6_cursor);
      drop(v121_6);
      compose(&(v120_5),&(v121_7))
    };
    drop(v120_5);
    let v120_9: Space = intersect(&(*CONSTANT_22),&(v120_2));
    drop(v120_2);
    let v120_10: Space = if has_head(&(v120_9)) { singleton(&[]) } else { Space::new() };
    drop(v120_9);
    let v120_11: Space = compose(&(v120_10),&(*CONSTANT_25));
    drop(v120_10);
    let v120_12: Space = unite(&(v120_8),&(v120_11));
    drop(v120_11);
    join_wrapped_into(&mut v119_6_write,&((v120_12).read_zipper()),&[]);
    }
    v119_6_cursor.ascend(1);
  }
  drop(v119_6_cursor);
  drop(v119_6_write);
  (v119_6).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v122_5 = Space::new();
  let mut v122_5_write = v122_5.write_zipper();
  let mut v122_5_cursor = (*s0).read_zipper();
  let v122_5_origin = v122_5_cursor.path().len();
  for v122_5_byte in v122_5_cursor.child_mask().iter() {
    v122_5_cursor.descend_to_existing_byte(v122_5_byte);
    {
    let v123_2: Space = singleton(&v122_5_cursor.path()[v122_5_origin..(v122_5_origin + 1)]);
    let v123_3: Space = intersect(&(*CONSTANT_22),&(v123_2));
    let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
    drop(v123_3);
    let v123_5: Space = subtract(&(*CONSTANT_0),&(v123_4));
    drop(v123_4);
    let v123_8: Space = if (&(v123_5)).is_empty() { Space::new() } else {
      let v124_6: Path = concat_path(&(*p0),&v122_5_cursor.path()[v122_5_origin..(v122_5_origin + 1)]);
      let v124_7: Space = routine_15(c, &(v124_6), &v122_5_cursor);
      drop(v124_6);
      compose(&(v123_5),&(v124_7))
    };
    drop(v123_5);
    let v123_9: Space = intersect(&(*CONSTANT_22),&(v123_2));
    drop(v123_2);
    let v123_10: Space = if has_head(&(v123_9)) { singleton(&[]) } else { Space::new() };
    drop(v123_9);
    let v123_11: Space = compose(&(v123_10),&v122_5_cursor);
    drop(v123_10);
    let v123_12: Space = unite(&(v123_8),&(v123_11));
    drop(v123_11);
    join_wrapped_into(&mut v122_5_write,&((v123_12).read_zipper()),&[]);
    }
    v122_5_cursor.ascend(1);
  }
  drop(v122_5_cursor);
  drop(v122_5_write);
  (v122_5).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
