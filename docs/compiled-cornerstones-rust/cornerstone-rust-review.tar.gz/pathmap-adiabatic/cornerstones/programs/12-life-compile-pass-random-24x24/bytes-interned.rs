#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 0 0 2 4 0 0 0 3"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,2]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 8 4 0 0 0 9 4 0 0 0 10 4 0 0 0 11 4 0 0 0 12"));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,3]));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 3 4 0 0 0 8 4 0 0 0 10 4 0 0 0 13 4 0 0 0 14"));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,4]));
static CONSTANT_7: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 4 0 0 0 5 4 0 0 0 6 4 0 0 0 7"));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,5]));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 4 0 0 0 6 4 0 0 0 7 4 0 0 0 12 4 0 0 0 18"));
static CONSTANT_10: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,6]));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 1 4 0 0 0 9 4 0 0 0 11 4 0 0 0 12 4 0 0 0 19"));
static CONSTANT_12: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,7]));
static CONSTANT_13: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 12 4 0 0 0 14 4 0 0 0 17 4 0 0 0 20 4 0 0 0 23"));
static CONSTANT_14: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,8]));
static CONSTANT_15: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 4 0 0 0 15 4 0 0 0 16 4 0 0 0 17"));
static CONSTANT_16: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,9]));
static CONSTANT_17: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 4 0 0 0 2 4 0 0 0 5 4 0 0 0 8 4 0 0 0 14 4 0 0 0 20 4 0 0 0 21 4 0 0 0 24"));
static CONSTANT_18: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,10]));
static CONSTANT_19: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 4 4 0 0 0 12 4 0 0 0 14 4 0 0 0 17 4 0 0 0 23"));
static CONSTANT_20: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,11]));
static CONSTANT_21: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 4 0 0 0 4 4 0 0 0 6 4 0 0 0 7 4 0 0 0 11 4 0 0 0 17 4 0 0 0 22"));
static CONSTANT_22: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,12]));
static CONSTANT_23: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 4 0 0 0 8 4 0 0 0 10 4 0 0 0 13 4 0 0 0 14 4 0 0 0 16 4 0 0 0 21 4 0 0 0 22 4 0 0 0 23"));
static CONSTANT_24: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,13]));
static CONSTANT_25: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 4 4 0 0 0 14 4 0 0 0 17 4 0 0 0 18 4 0 0 0 23"));
static CONSTANT_26: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,14]));
static CONSTANT_27: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 2 4 0 0 0 8 4 0 0 0 9 4 0 0 0 16 4 0 0 0 23"));
static CONSTANT_28: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,15]));
static CONSTANT_29: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 1"));
static CONSTANT_30: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,16]));
static CONSTANT_31: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 4 0 0 0 9 4 0 0 0 13 4 0 0 0 18"));
static CONSTANT_32: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,17]));
static CONSTANT_33: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 4 0 0 0 2 4 0 0 0 5 4 0 0 0 18"));
static CONSTANT_34: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,18]));
static CONSTANT_35: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 5 4 0 0 0 12 4 0 0 0 19 4 0 0 0 20 4 0 0 0 22"));
static CONSTANT_36: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,19]));
static CONSTANT_37: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 4 0 0 0 3 4 0 0 0 11 4 0 0 0 12 4 0 0 0 14 4 0 0 0 16 4 0 0 0 18"));
static CONSTANT_38: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,20]));
static CONSTANT_39: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 4 0 0 0 4 4 0 0 0 7 4 0 0 0 11 4 0 0 0 13 4 0 0 0 14 4 0 0 0 15 4 0 0 0 16 4 0 0 0 21"));
static CONSTANT_40: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,21]));
static CONSTANT_41: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("9 4 0 0 0 8 4 0 0 0 9 4 0 0 0 11 4 0 0 0 12 4 0 0 0 13 4 0 0 0 15 4 0 0 0 17 4 0 0 0 22 4 0 0 0 23"));
static CONSTANT_42: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,22]));
static CONSTANT_43: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 4 0 0 0 3 4 0 0 0 7 4 0 0 0 10 4 0 0 0 15 4 0 0 0 16 4 0 0 0 19 4 0 0 0 20"));
static CONSTANT_44: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,23]));
static CONSTANT_45: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 4 0 0 0 2 4 0 0 0 4 4 0 0 0 6 4 0 0 0 7 4 0 0 0 14 4 0 0 0 16 4 0 0 0 22"));
static CONSTANT_46: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,24]));
static CONSTANT_47: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 4 0 0 0 15 4 0 0 0 17 4 0 0 0 24"));
static CONSTANT_48: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("120 12 0 0 0 0 0 0 0 1 0 0 0 2 12 0 0 0 0 0 0 0 1 0 0 0 3 12 0 0 0 0 0 0 0 2 0 0 0 8 12 0 0 0 0 0 0 0 2 0 0 0 9 12 0 0 0 0 0 0 0 2 0 0 0 10 12 0 0 0 0 0 0 0 2 0 0 0 11 12 0 0 0 0 0 0 0 2 0 0 0 12 12 0 0 0 0 0 0 0 3 0 0 0 3 12 0 0 0 0 0 0 0 3 0 0 0 8 12 0 0 0 0 0 0 0 3 0 0 0 10 12 0 0 0 0 0 0 0 3 0 0 0 13 12 0 0 0 0 0 0 0 3 0 0 0 14 12 0 0 0 0 0 0 0 4 0 0 0 5 12 0 0 0 0 0 0 0 4 0 0 0 6 12 0 0 0 0 0 0 0 4 0 0 0 7 12 0 0 0 0 0 0 0 5 0 0 0 6 12 0 0 0 0 0 0 0 5 0 0 0 7 12 0 0 0 0 0 0 0 5 0 0 0 12 12 0 0 0 0 0 0 0 5 0 0 0 18 12 0 0 0 0 0 0 0 6 0 0 0 1 12 0 0 0 0 0 0 0 6 0 0 0 9 12 0 0 0 0 0 0 0 6 0 0 0 11 12 0 0 0 0 0 0 0 6 0 0 0 12 12 0 0 0 0 0 0 0 6 0 0 0 19 12 0 0 0 0 0 0 0 7 0 0 0 12 12 0 0 0 0 0 0 0 7 0 0 0 14 12 0 0 0 0 0 0 0 7 0 0 0 17 12 0 0 0 0 0 0 0 7 0 0 0 20 12 0 0 0 0 0 0 0 7 0 0 0 23 12 0 0 0 0 0 0 0 8 0 0 0 15 12 0 0 0 0 0 0 0 8 0 0 0 16 12 0 0 0 0 0 0 0 8 0 0 0 17 12 0 0 0 0 0 0 0 9 0 0 0 2 12 0 0 0 0 0 0 0 9 0 0 0 5 12 0 0 0 0 0 0 0 9 0 0 0 8 12 0 0 0 0 0 0 0 9 0 0 0 14 12 0 0 0 0 0 0 0 9 0 0 0 20 12 0 0 0 0 0 0 0 9 0 0 0 21 12 0 0 0 0 0 0 0 9 0 0 0 24 12 0 0 0 0 0 0 0 10 0 0 0 4 12 0 0 0 0 0 0 0 10 0 0 0 12 12 0 0 0 0 0 0 0 10 0 0 0 14 12 0 0 0 0 0 0 0 10 0 0 0 17 12 0 0 0 0 0 0 0 10 0 0 0 23 12 0 0 0 0 0 0 0 11 0 0 0 4 12 0 0 0 0 0 0 0 11 0 0 0 6 12 0 0 0 0 0 0 0 11 0 0 0 7 12 0 0 0 0 0 0 0 11 0 0 0 11 12 0 0 0 0 0 0 0 11 0 0 0 17 12 0 0 0 0 0 0 0 11 0 0 0 22 12 0 0 0 0 0 0 0 12 0 0 0 8 12 0 0 0 0 0 0 0 12 0 0 0 10 12 0 0 0 0 0 0 0 12 0 0 0 13 12 0 0 0 0 0 0 0 12 0 0 0 14 12 0 0 0 0 0 0 0 12 0 0 0 16 12 0 0 0 0 0 0 0 12 0 0 0 21 12 0 0 0 0 0 0 0 12 0 0 0 22 12 0 0 0 0 0 0 0 12 0 0 0 23 12 0 0 0 0 0 0 0 13 0 0 0 4 12 0 0 0 0 0 0 0 13 0 0 0 14 12 0 0 0 0 0 0 0 13 0 0 0 17 12 0 0 0 0 0 0 0 13 0 0 0 18 12 0 0 0 0 0 0 0 13 0 0 0 23 12 0 0 0 0 0 0 0 14 0 0 0 2 12 0 0 0 0 0 0 0 14 0 0 0 8 12 0 0 0 0 0 0 0 14 0 0 0 9 12 0 0 0 0 0 0 0 14 0 0 0 16 12 0 0 0 0 0 0 0 14 0 0 0 23 12 0 0 0 0 0 0 0 15 0 0 0 1 12 0 0 0 0 0 0 0 16 0 0 0 9 12 0 0 0 0 0 0 0 16 0 0 0 13 12 0 0 0 0 0 0 0 16 0 0 0 18 12 0 0 0 0 0 0 0 17 0 0 0 2 12 0 0 0 0 0 0 0 17 0 0 0 5 12 0 0 0 0 0 0 0 17 0 0 0 18 12 0 0 0 0 0 0 0 18 0 0 0 5 12 0 0 0 0 0 0 0 18 0 0 0 12 12 0 0 0 0 0 0 0 18 0 0 0 19 12 0 0 0 0 0 0 0 18 0 0 0 20 12 0 0 0 0 0 0 0 18 0 0 0 22 12 0 0 0 0 0 0 0 19 0 0 0 3 12 0 0 0 0 0 0 0 19 0 0 0 11 12 0 0 0 0 0 0 0 19 0 0 0 12 12 0 0 0 0 0 0 0 19 0 0 0 14 12 0 0 0 0 0 0 0 19 0 0 0 16 12 0 0 0 0 0 0 0 19 0 0 0 18 12 0 0 0 0 0 0 0 20 0 0 0 4 12 0 0 0 0 0 0 0 20 0 0 0 7 12 0 0 0 0 0 0 0 20 0 0 0 11 12 0 0 0 0 0 0 0 20 0 0 0 13 12 0 0 0 0 0 0 0 20 0 0 0 14 12 0 0 0 0 0 0 0 20 0 0 0 15 12 0 0 0 0 0 0 0 20 0 0 0 16 12 0 0 0 0 0 0 0 20 0 0 0 21 12 0 0 0 0 0 0 0 21 0 0 0 8 12 0 0 0 0 0 0 0 21 0 0 0 9 12 0 0 0 0 0 0 0 21 0 0 0 11 12 0 0 0 0 0 0 0 21 0 0 0 12 12 0 0 0 0 0 0 0 21 0 0 0 13 12 0 0 0 0 0 0 0 21 0 0 0 15 12 0 0 0 0 0 0 0 21 0 0 0 17 12 0 0 0 0 0 0 0 21 0 0 0 22 12 0 0 0 0 0 0 0 21 0 0 0 23 12 0 0 0 0 0 0 0 22 0 0 0 3 12 0 0 0 0 0 0 0 22 0 0 0 7 12 0 0 0 0 0 0 0 22 0 0 0 10 12 0 0 0 0 0 0 0 22 0 0 0 15 12 0 0 0 0 0 0 0 22 0 0 0 16 12 0 0 0 0 0 0 0 22 0 0 0 19 12 0 0 0 0 0 0 0 22 0 0 0 20 12 0 0 0 0 0 0 0 23 0 0 0 2 12 0 0 0 0 0 0 0 23 0 0 0 4 12 0 0 0 0 0 0 0 23 0 0 0 6 12 0 0 0 0 0 0 0 23 0 0 0 7 12 0 0 0 0 0 0 0 23 0 0 0 14 12 0 0 0 0 0 0 0 23 0 0 0 16 12 0 0 0 0 0 0 0 23 0 0 0 22 12 0 0 0 0 0 0 0 24 0 0 0 15 12 0 0 0 0 0 0 0 24 0 0 0 17 12 0 0 0 0 0 0 0 24 0 0 0 24"));
static CONSTANT_49: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_50: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("387 8 0 0 0 1 0 0 0 1 8 0 0 0 1 0 0 0 4 8 0 0 0 1 0 0 0 25 8 0 0 0 2 0 0 0 2 8 0 0 0 2 0 0 0 3 8 0 0 0 2 0 0 0 12 8 0 0 0 3 0 0 0 2 8 0 0 0 3 0 0 0 3 8 0 0 0 3 0 0 0 8 8 0 0 0 4 0 0 0 1 8 0 0 0 4 0 0 0 4 8 0 0 0 4 0 0 0 17 8 0 0 0 5 0 0 0 5 8 0 0 0 5 0 0 0 6 8 0 0 0 5 0 0 0 8 8 0 0 0 6 0 0 0 5 8 0 0 0 6 0 0 0 6 8 0 0 0 6 0 0 0 20 8 0 0 0 7 0 0 0 7 8 0 0 0 7 0 0 0 16 8 0 0 0 7 0 0 0 18 8 0 0 0 8 0 0 0 3 8 0 0 0 8 0 0 0 5 8 0 0 0 8 0 0 0 8 8 0 0 0 9 0 0 0 9 8 0 0 0 9 0 0 0 16 8 0 0 0 9 0 0 0 21 8 0 0 0 10 0 0 0 10 8 0 0 0 10 0 0 0 24 8 0 0 0 10 0 0 0 90 8 0 0 0 11 0 0 0 11 8 0 0 0 11 0 0 0 14 8 0 0 0 11 0 0 0 23 8 0 0 0 12 0 0 0 2 8 0 0 0 12 0 0 0 12 8 0 0 0 12 0 0 0 19 8 0 0 0 13 0 0 0 13 8 0 0 0 13 0 0 0 17 8 0 0 0 13 0 0 0 22 8 0 0 0 14 0 0 0 11 8 0 0 0 14 0 0 0 14 8 0 0 0 14 0 0 0 22 8 0 0 0 15 0 0 0 15 8 0 0 0 15 0 0 0 20 8 0 0 0 15 0 0 0 21 8 0 0 0 16 0 0 0 7 8 0 0 0 16 0 0 0 9 8 0 0 0 16 0 0 0 16 8 0 0 0 17 0 0 0 4 8 0 0 0 17 0 0 0 13 8 0 0 0 17 0 0 0 17 8 0 0 0 18 0 0 0 7 8 0 0 0 18 0 0 0 18 8 0 0 0 18 0 0 0 24 8 0 0 0 19 0 0 0 12 8 0 0 0 19 0 0 0 19 8 0 0 0 19 0 0 0 23 8 0 0 0 20 0 0 0 6 8 0 0 0 20 0 0 0 15 8 0 0 0 20 0 0 0 20 8 0 0 0 21 0 0 0 9 8 0 0 0 21 0 0 0 15 8 0 0 0 21 0 0 0 21 8 0 0 0 22 0 0 0 13 8 0 0 0 22 0 0 0 14 8 0 0 0 22 0 0 0 22 8 0 0 0 23 0 0 0 11 8 0 0 0 23 0 0 0 19 8 0 0 0 23 0 0 0 23 8 0 0 0 24 0 0 0 10 8 0 0 0 24 0 0 0 18 8 0 0 0 24 0 0 0 24 8 0 0 0 25 0 0 0 1 8 0 0 0 25 0 0 0 25 8 0 0 0 25 0 0 0 26 8 0 0 0 26 0 0 0 25 8 0 0 0 26 0 0 0 26 8 0 0 0 26 0 0 0 39 8 0 0 0 27 0 0 0 27 8 0 0 0 27 0 0 0 28 8 0 0 0 27 0 0 0 29 8 0 0 0 28 0 0 0 27 8 0 0 0 28 0 0 0 28 8 0 0 0 28 0 0 0 30 8 0 0 0 29 0 0 0 27 8 0 0 0 29 0 0 0 29 8 0 0 0 29 0 0 0 89 8 0 0 0 30 0 0 0 28 8 0 0 0 30 0 0 0 30 8 0 0 0 30 0 0 0 31 8 0 0 0 31 0 0 0 30 8 0 0 0 31 0 0 0 31 8 0 0 0 31 0 0 0 32 8 0 0 0 32 0 0 0 31 8 0 0 0 32 0 0 0 32 8 0 0 0 32 0 0 0 33 8 0 0 0 33 0 0 0 32 8 0 0 0 33 0 0 0 33 8 0 0 0 33 0 0 0 34 8 0 0 0 34 0 0 0 33 8 0 0 0 34 0 0 0 34 8 0 0 0 34 0 0 0 35 8 0 0 0 35 0 0 0 34 8 0 0 0 35 0 0 0 35 8 0 0 0 35 0 0 0 36 8 0 0 0 36 0 0 0 35 8 0 0 0 36 0 0 0 36 8 0 0 0 36 0 0 0 37 8 0 0 0 37 0 0 0 36 8 0 0 0 37 0 0 0 37 8 0 0 0 37 0 0 0 38 8 0 0 0 38 0 0 0 37 8 0 0 0 38 0 0 0 38 8 0 0 0 38 0 0 0 40 8 0 0 0 39 0 0 0 26 8 0 0 0 39 0 0 0 39 8 0 0 0 39 0 0 0 50 8 0 0 0 40 0 0 0 38 8 0 0 0 40 0 0 0 40 8 0 0 0 40 0 0 0 41 8 0 0 0 41 0 0 0 40 8 0 0 0 41 0 0 0 41 8 0 0 0 41 0 0 0 42 8 0 0 0 42 0 0 0 41 8 0 0 0 42 0 0 0 42 8 0 0 0 42 0 0 0 43 8 0 0 0 43 0 0 0 42 8 0 0 0 43 0 0 0 43 8 0 0 0 43 0 0 0 44 8 0 0 0 44 0 0 0 43 8 0 0 0 44 0 0 0 44 8 0 0 0 44 0 0 0 45 8 0 0 0 45 0 0 0 44 8 0 0 0 45 0 0 0 45 8 0 0 0 45 0 0 0 46 8 0 0 0 46 0 0 0 45 8 0 0 0 46 0 0 0 46 8 0 0 0 46 0 0 0 47 8 0 0 0 47 0 0 0 46 8 0 0 0 47 0 0 0 47 8 0 0 0 47 0 0 0 48 8 0 0 0 48 0 0 0 47 8 0 0 0 48 0 0 0 48 8 0 0 0 48 0 0 0 49 8 0 0 0 49 0 0 0 48 8 0 0 0 49 0 0 0 49 8 0 0 0 49 0 0 0 51 8 0 0 0 50 0 0 0 39 8 0 0 0 50 0 0 0 50 8 0 0 0 50 0 0 0 61 8 0 0 0 51 0 0 0 49 8 0 0 0 51 0 0 0 51 8 0 0 0 51 0 0 0 52 8 0 0 0 52 0 0 0 51 8 0 0 0 52 0 0 0 52 8 0 0 0 52 0 0 0 53 8 0 0 0 53 0 0 0 52 8 0 0 0 53 0 0 0 53 8 0 0 0 53 0 0 0 54 8 0 0 0 54 0 0 0 53 8 0 0 0 54 0 0 0 54 8 0 0 0 54 0 0 0 55 8 0 0 0 55 0 0 0 54 8 0 0 0 55 0 0 0 55 8 0 0 0 55 0 0 0 56 8 0 0 0 56 0 0 0 55 8 0 0 0 56 0 0 0 56 8 0 0 0 56 0 0 0 57 8 0 0 0 57 0 0 0 56 8 0 0 0 57 0 0 0 57 8 0 0 0 57 0 0 0 58 8 0 0 0 58 0 0 0 57 8 0 0 0 58 0 0 0 58 8 0 0 0 58 0 0 0 59 8 0 0 0 59 0 0 0 58 8 0 0 0 59 0 0 0 59 8 0 0 0 59 0 0 0 60 8 0 0 0 60 0 0 0 59 8 0 0 0 60 0 0 0 60 8 0 0 0 60 0 0 0 62 8 0 0 0 61 0 0 0 50 8 0 0 0 61 0 0 0 61 8 0 0 0 61 0 0 0 72 8 0 0 0 62 0 0 0 60 8 0 0 0 62 0 0 0 62 8 0 0 0 62 0 0 0 63 8 0 0 0 63 0 0 0 62 8 0 0 0 63 0 0 0 63 8 0 0 0 63 0 0 0 64 8 0 0 0 64 0 0 0 63 8 0 0 0 64 0 0 0 64 8 0 0 0 64 0 0 0 65 8 0 0 0 65 0 0 0 64 8 0 0 0 65 0 0 0 65 8 0 0 0 65 0 0 0 66 8 0 0 0 66 0 0 0 65 8 0 0 0 66 0 0 0 66 8 0 0 0 66 0 0 0 67 8 0 0 0 67 0 0 0 66 8 0 0 0 67 0 0 0 67 8 0 0 0 67 0 0 0 68 8 0 0 0 68 0 0 0 67 8 0 0 0 68 0 0 0 68 8 0 0 0 68 0 0 0 69 8 0 0 0 69 0 0 0 68 8 0 0 0 69 0 0 0 69 8 0 0 0 69 0 0 0 70 8 0 0 0 70 0 0 0 69 8 0 0 0 70 0 0 0 70 8 0 0 0 70 0 0 0 71 8 0 0 0 71 0 0 0 70 8 0 0 0 71 0 0 0 71 8 0 0 0 71 0 0 0 73 8 0 0 0 72 0 0 0 61 8 0 0 0 72 0 0 0 72 8 0 0 0 72 0 0 0 83 8 0 0 0 73 0 0 0 71 8 0 0 0 73 0 0 0 73 8 0 0 0 73 0 0 0 74 8 0 0 0 74 0 0 0 73 8 0 0 0 74 0 0 0 74 8 0 0 0 74 0 0 0 75 8 0 0 0 75 0 0 0 74 8 0 0 0 75 0 0 0 75 8 0 0 0 75 0 0 0 76 8 0 0 0 76 0 0 0 75 8 0 0 0 76 0 0 0 76 8 0 0 0 76 0 0 0 77 8 0 0 0 77 0 0 0 76 8 0 0 0 77 0 0 0 77 8 0 0 0 77 0 0 0 78 8 0 0 0 78 0 0 0 77 8 0 0 0 78 0 0 0 78 8 0 0 0 78 0 0 0 79 8 0 0 0 79 0 0 0 78 8 0 0 0 79 0 0 0 79 8 0 0 0 79 0 0 0 80 8 0 0 0 80 0 0 0 79 8 0 0 0 80 0 0 0 80 8 0 0 0 80 0 0 0 81 8 0 0 0 81 0 0 0 80 8 0 0 0 81 0 0 0 81 8 0 0 0 81 0 0 0 82 8 0 0 0 82 0 0 0 81 8 0 0 0 82 0 0 0 82 8 0 0 0 82 0 0 0 84 8 0 0 0 83 0 0 0 72 8 0 0 0 83 0 0 0 83 8 0 0 0 83 0 0 0 89 8 0 0 0 84 0 0 0 82 8 0 0 0 84 0 0 0 84 8 0 0 0 84 0 0 0 85 8 0 0 0 85 0 0 0 84 8 0 0 0 85 0 0 0 85 8 0 0 0 85 0 0 0 86 8 0 0 0 86 0 0 0 85 8 0 0 0 86 0 0 0 86 8 0 0 0 86 0 0 0 87 8 0 0 0 87 0 0 0 86 8 0 0 0 87 0 0 0 87 8 0 0 0 87 0 0 0 88 8 0 0 0 89 0 0 0 29 8 0 0 0 89 0 0 0 83 8 0 0 0 89 0 0 0 89 8 0 0 0 90 0 0 0 10 8 0 0 0 90 0 0 0 90 8 0 0 0 90 0 0 0 91 8 0 0 0 91 0 0 0 90 8 0 0 0 91 0 0 0 91 8 0 0 0 91 0 0 0 92 8 0 0 0 92 0 0 0 91 8 0 0 0 92 0 0 0 92 8 0 0 0 92 0 0 0 93 8 0 0 0 93 0 0 0 92 8 0 0 0 93 0 0 0 93 8 0 0 0 93 0 0 0 94 8 0 0 0 94 0 0 0 93 8 0 0 0 94 0 0 0 94 8 0 0 0 94 0 0 0 95 8 0 0 0 95 0 0 0 94 8 0 0 0 95 0 0 0 95 8 0 0 0 95 0 0 0 96 8 0 0 0 96 0 0 0 95 8 0 0 0 96 0 0 0 96 8 0 0 0 96 0 0 0 97 8 0 0 0 97 0 0 0 96 8 0 0 0 97 0 0 0 97 8 0 0 0 97 0 0 0 98 8 0 0 0 98 0 0 0 97 8 0 0 0 98 0 0 0 98 8 0 0 0 98 0 0 0 99 8 0 0 0 99 0 0 0 98 8 0 0 0 99 0 0 0 99 8 0 0 0 99 0 0 0 100 8 0 0 0 100 0 0 0 99 8 0 0 0 100 0 0 0 100 8 0 0 0 100 0 0 0 101 8 0 0 0 101 0 0 0 100 8 0 0 0 101 0 0 0 101 8 0 0 0 101 0 0 0 102 8 0 0 0 102 0 0 0 101 8 0 0 0 102 0 0 0 102 8 0 0 0 102 0 0 0 103 8 0 0 0 103 0 0 0 102 8 0 0 0 103 0 0 0 103 8 0 0 0 103 0 0 0 104 8 0 0 0 104 0 0 0 103 8 0 0 0 104 0 0 0 104 8 0 0 0 104 0 0 0 105 8 0 0 0 105 0 0 0 104 8 0 0 0 105 0 0 0 105 8 0 0 0 105 0 0 0 106 8 0 0 0 106 0 0 0 105 8 0 0 0 106 0 0 0 106 8 0 0 0 106 0 0 0 107 8 0 0 0 107 0 0 0 106 8 0 0 0 107 0 0 0 107 8 0 0 0 107 0 0 0 108 8 0 0 0 108 0 0 0 107 8 0 0 0 108 0 0 0 108 8 0 0 0 108 0 0 0 109 8 0 0 0 109 0 0 0 108 8 0 0 0 109 0 0 0 109 8 0 0 0 109 0 0 0 110 8 0 0 0 110 0 0 0 109 8 0 0 0 110 0 0 0 110 8 0 0 0 110 0 0 0 111 8 0 0 0 111 0 0 0 110 8 0 0 0 111 0 0 0 111 8 0 0 0 111 0 0 0 112 8 0 0 0 112 0 0 0 111 8 0 0 0 112 0 0 0 112 8 0 0 0 112 0 0 0 113 8 0 0 0 113 0 0 0 112 8 0 0 0 113 0 0 0 113 8 0 0 0 113 0 0 0 114 8 0 0 0 114 0 0 0 113 8 0 0 0 114 0 0 0 114 8 0 0 0 114 0 0 0 115 8 0 0 0 115 0 0 0 114 8 0 0 0 115 0 0 0 115 8 0 0 0 115 0 0 0 116 8 0 0 0 116 0 0 0 115 8 0 0 0 116 0 0 0 116 8 0 0 0 116 0 0 0 117 8 0 0 0 117 0 0 0 116 8 0 0 0 117 0 0 0 117 8 0 0 0 117 0 0 0 118 8 0 0 0 118 0 0 0 117 8 0 0 0 118 0 0 0 118 8 0 0 0 118 0 0 0 119 8 0 0 0 119 0 0 0 118 8 0 0 0 119 0 0 0 119 8 0 0 0 119 0 0 0 120 8 0 0 0 120 0 0 0 119 8 0 0 0 120 0 0 0 120 8 0 0 0 120 0 0 0 121 8 0 0 0 121 0 0 0 120 8 0 0 0 121 0 0 0 121 8 0 0 0 121 0 0 0 122 8 0 0 0 122 0 0 0 121 8 0 0 0 122 0 0 0 122 8 0 0 0 122 0 0 0 123 8 0 0 0 123 0 0 0 122 8 0 0 0 123 0 0 0 123 8 0 0 0 123 0 0 0 124 8 0 0 0 124 0 0 0 123 8 0 0 0 124 0 0 0 124 8 0 0 0 124 0 0 0 125 8 0 0 0 125 0 0 0 124 8 0 0 0 125 0 0 0 125 8 0 0 0 125 0 0 0 126 8 0 0 0 126 0 0 0 125 8 0 0 0 126 0 0 0 126 8 0 0 0 126 0 0 0 127 8 0 0 0 127 0 0 0 126 8 0 0 0 127 0 0 0 127 8 0 0 0 127 0 0 0 128 8 0 0 0 128 0 0 0 127 8 0 0 0 128 0 0 0 128 8 0 0 0 128 0 0 0 129 8 0 0 0 129 0 0 0 128 8 0 0 0 129 0 0 0 129 8 0 0 0 129 0 0 0 130 8 0 0 0 130 0 0 0 129 8 0 0 0 130 0 0 0 130 8 0 0 0 130 0 0 0 131"));
static CONSTANT_51: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_52: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 132"));
static CONSTANT_53: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
static CONSTANT_54: std::sync::LazyLock<&'static [&'static [u8]]> = std::sync::LazyLock::new(|| &[&[0,0,0,25],&[0,0,0,27],&[0,0,0,28],&[0,0,0,30],&[0,0,0,31],&[0,0,0,32],&[0,0,0,33],&[0,0,0,34],&[0,0,0,35],&[0,0,0,36],&[0,0,0,37],&[0,0,0,26],&[0,0,0,38],&[0,0,0,40],&[0,0,0,41],&[0,0,0,42],&[0,0,0,43],&[0,0,0,44],&[0,0,0,45],&[0,0,0,46],&[0,0,0,47],&[0,0,0,48],&[0,0,0,39],&[0,0,0,49],&[0,0,0,51],&[0,0,0,52],&[0,0,0,53],&[0,0,0,54],&[0,0,0,55],&[0,0,0,56],&[0,0,0,57],&[0,0,0,58],&[0,0,0,59],&[0,0,0,50],&[0,0,0,60],&[0,0,0,62],&[0,0,0,63],&[0,0,0,64],&[0,0,0,65],&[0,0,0,66],&[0,0,0,67],&[0,0,0,68],&[0,0,0,69],&[0,0,0,70],&[0,0,0,61],&[0,0,0,71],&[0,0,0,73],&[0,0,0,74],&[0,0,0,75],&[0,0,0,76],&[0,0,0,77],&[0,0,0,78],&[0,0,0,79],&[0,0,0,80],&[0,0,0,81],&[0,0,0,72],&[0,0,0,82],&[0,0,0,84],&[0,0,0,85],&[0,0,0,86],&[0,0,0,87],&[0,0,0,88],&[0,0,0,83],&[0,0,0,89],&[0,0,0,29],&[0,0,0,1],&[0,0,0,4],&[0,0,0,2],&[0,0,0,3],&[0,0,0,8],&[0,0,0,5],&[0,0,0,6],&[0,0,0,20],&[0,0,0,15],&[0,0,0,21],&[0,0,0,9],&[0,0,0,16],&[0,0,0,17],&[0,0,0,7],&[0,0,0,18],&[0,0,0,24],&[0,0,0,10],&[0,0,0,90],&[0,0,0,91],&[0,0,0,92],&[0,0,0,93],&[0,0,0,94],&[0,0,0,95],&[0,0,0,13],&[0,0,0,96],&[0,0,0,97],&[0,0,0,98],&[0,0,0,99],&[0,0,0,100],&[0,0,0,101],&[0,0,0,102],&[0,0,0,103],&[0,0,0,104],&[0,0,0,105],&[0,0,0,22],&[0,0,0,106],&[0,0,0,107],&[0,0,0,108],&[0,0,0,109],&[0,0,0,110],&[0,0,0,111],&[0,0,0,112],&[0,0,0,113],&[0,0,0,114],&[0,0,0,115],&[0,0,0,14],&[0,0,0,116],&[0,0,0,117],&[0,0,0,118],&[0,0,0,119],&[0,0,0,120],&[0,0,0,121],&[0,0,0,122],&[0,0,0,123],&[0,0,0,124],&[0,0,0,125],&[0,0,0,11],&[0,0,0,126],&[0,0,0,127],&[0,0,0,128],&[0,0,0,129],&[0,0,0,130],&[0,0,0,131],&[0,0,0,23],&[0,0,0,19],&[0,0,0,12],&[0,0,0,0],&[0,0,0,132]]);
fn routine_0(c: &mut Context) -> Space {
  let v0_2: Space = routine_1(c, &(*CONSTANT_0), &((*CONSTANT_1).read_zipper()));
  let v0_5: Space = routine_1(c, &(*CONSTANT_2), &((*CONSTANT_3).read_zipper()));
  let v0_6: Space = unite(&(v0_2),&(v0_5));
  let v0_9: Space = routine_1(c, &(*CONSTANT_4), &((*CONSTANT_5).read_zipper()));
  let v0_10: Space = unite(&(v0_6),&(v0_9));
  let v0_13: Space = routine_1(c, &(*CONSTANT_6), &((*CONSTANT_7).read_zipper()));
  let v0_14: Space = unite(&(v0_10),&(v0_13));
  let v0_17: Space = routine_1(c, &(*CONSTANT_8), &((*CONSTANT_9).read_zipper()));
  let v0_18: Space = unite(&(v0_14),&(v0_17));
  let v0_21: Space = routine_1(c, &(*CONSTANT_10), &((*CONSTANT_11).read_zipper()));
  let v0_22: Space = unite(&(v0_18),&(v0_21));
  let v0_25: Space = routine_1(c, &(*CONSTANT_12), &((*CONSTANT_13).read_zipper()));
  let v0_26: Space = unite(&(v0_22),&(v0_25));
  let v0_29: Space = routine_1(c, &(*CONSTANT_14), &((*CONSTANT_15).read_zipper()));
  let v0_30: Space = unite(&(v0_26),&(v0_29));
  let v0_33: Space = routine_1(c, &(*CONSTANT_16), &((*CONSTANT_17).read_zipper()));
  let v0_34: Space = unite(&(v0_30),&(v0_33));
  let v0_37: Space = routine_1(c, &(*CONSTANT_18), &((*CONSTANT_19).read_zipper()));
  let v0_38: Space = unite(&(v0_34),&(v0_37));
  let v0_41: Space = routine_1(c, &(*CONSTANT_20), &((*CONSTANT_21).read_zipper()));
  let v0_42: Space = unite(&(v0_38),&(v0_41));
  let v0_45: Space = routine_1(c, &(*CONSTANT_22), &((*CONSTANT_23).read_zipper()));
  let v0_46: Space = unite(&(v0_42),&(v0_45));
  let v0_49: Space = routine_1(c, &(*CONSTANT_24), &((*CONSTANT_25).read_zipper()));
  let v0_50: Space = unite(&(v0_46),&(v0_49));
  let v0_53: Space = routine_1(c, &(*CONSTANT_26), &((*CONSTANT_27).read_zipper()));
  let v0_54: Space = unite(&(v0_50),&(v0_53));
  let v0_57: Space = routine_1(c, &(*CONSTANT_28), &((*CONSTANT_29).read_zipper()));
  let v0_58: Space = unite(&(v0_54),&(v0_57));
  let v0_61: Space = routine_1(c, &(*CONSTANT_30), &((*CONSTANT_31).read_zipper()));
  let v0_62: Space = unite(&(v0_58),&(v0_61));
  let v0_65: Space = routine_1(c, &(*CONSTANT_32), &((*CONSTANT_33).read_zipper()));
  let v0_66: Space = unite(&(v0_62),&(v0_65));
  let v0_69: Space = routine_1(c, &(*CONSTANT_34), &((*CONSTANT_35).read_zipper()));
  let v0_70: Space = unite(&(v0_66),&(v0_69));
  let v0_73: Space = routine_1(c, &(*CONSTANT_36), &((*CONSTANT_37).read_zipper()));
  let v0_74: Space = unite(&(v0_70),&(v0_73));
  let v0_77: Space = routine_1(c, &(*CONSTANT_38), &((*CONSTANT_39).read_zipper()));
  let v0_78: Space = unite(&(v0_74),&(v0_77));
  let v0_81: Space = routine_1(c, &(*CONSTANT_40), &((*CONSTANT_41).read_zipper()));
  let v0_82: Space = unite(&(v0_78),&(v0_81));
  let v0_85: Space = routine_1(c, &(*CONSTANT_42), &((*CONSTANT_43).read_zipper()));
  let v0_86: Space = unite(&(v0_82),&(v0_85));
  let v0_89: Space = routine_1(c, &(*CONSTANT_44), &((*CONSTANT_45).read_zipper()));
  let v0_90: Space = unite(&(v0_86),&(v0_89));
  let v0_93: Space = routine_1(c, &(*CONSTANT_46), &((*CONSTANT_47).read_zipper()));
  let v0_94: Space = unite(&(v0_90),&(v0_93));
  let mut v0_96 = Space::new();
  let mut v0_96_write = v0_96.write_zipper();
  let mut v0_96_cursor = (v0_94).read_zipper();
  let v0_96_origin = v0_96_cursor.path().len();
  for v0_96_byte in v0_96_cursor.child_mask().iter() {
    v0_96_cursor.descend_to_existing_byte(v0_96_byte);
    {
    for v1_2_byte in v0_96_cursor.child_mask().iter() {
      v0_96_cursor.descend_to_existing_byte(v1_2_byte);
      {
      for v2_3_byte in v0_96_cursor.child_mask().iter() {
        v0_96_cursor.descend_to_existing_byte(v2_3_byte);
        {
        for v3_3_byte in v0_96_cursor.child_mask().iter() {
          v0_96_cursor.descend_to_existing_byte(v3_3_byte);
          {
          let v4_3: Space = routine_2(c, &v0_96_cursor.path()[v0_96_origin..(v0_96_origin + 4)], &v0_96_cursor, &((*CONSTANT_48).read_zipper()));
          join_wrapped_into(&mut v0_96_write,&((v4_3).read_zipper()),&[]);
          }
          v0_96_cursor.ascend(1);
        }
        }
        v0_96_cursor.ascend(1);
      }
      }
      v0_96_cursor.ascend(1);
    }
    }
    v0_96_cursor.ascend(1);
  }
  drop(v0_96_cursor);
  drop(v0_96_write);
  let v0_99: Space = routine_3(c, &(*CONSTANT_0), &((*CONSTANT_1).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_100: Space = unite(&(v0_96),&(v0_99));
  let v0_103: Space = routine_3(c, &(*CONSTANT_2), &((*CONSTANT_3).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_104: Space = unite(&(v0_100),&(v0_103));
  let v0_107: Space = routine_3(c, &(*CONSTANT_4), &((*CONSTANT_5).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_108: Space = unite(&(v0_104),&(v0_107));
  let v0_111: Space = routine_3(c, &(*CONSTANT_6), &((*CONSTANT_7).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_112: Space = unite(&(v0_108),&(v0_111));
  let v0_115: Space = routine_3(c, &(*CONSTANT_8), &((*CONSTANT_9).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_116: Space = unite(&(v0_112),&(v0_115));
  let v0_119: Space = routine_3(c, &(*CONSTANT_10), &((*CONSTANT_11).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_120: Space = unite(&(v0_116),&(v0_119));
  let v0_123: Space = routine_3(c, &(*CONSTANT_12), &((*CONSTANT_13).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_124: Space = unite(&(v0_120),&(v0_123));
  let v0_127: Space = routine_3(c, &(*CONSTANT_14), &((*CONSTANT_15).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_128: Space = unite(&(v0_124),&(v0_127));
  let v0_131: Space = routine_3(c, &(*CONSTANT_16), &((*CONSTANT_17).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_132: Space = unite(&(v0_128),&(v0_131));
  let v0_135: Space = routine_3(c, &(*CONSTANT_18), &((*CONSTANT_19).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_136: Space = unite(&(v0_132),&(v0_135));
  let v0_139: Space = routine_3(c, &(*CONSTANT_20), &((*CONSTANT_21).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_140: Space = unite(&(v0_136),&(v0_139));
  let v0_143: Space = routine_3(c, &(*CONSTANT_22), &((*CONSTANT_23).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_144: Space = unite(&(v0_140),&(v0_143));
  let v0_147: Space = routine_3(c, &(*CONSTANT_24), &((*CONSTANT_25).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_148: Space = unite(&(v0_144),&(v0_147));
  let v0_151: Space = routine_3(c, &(*CONSTANT_26), &((*CONSTANT_27).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_152: Space = unite(&(v0_148),&(v0_151));
  let v0_155: Space = routine_3(c, &(*CONSTANT_28), &((*CONSTANT_29).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_156: Space = unite(&(v0_152),&(v0_155));
  let v0_159: Space = routine_3(c, &(*CONSTANT_30), &((*CONSTANT_31).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_160: Space = unite(&(v0_156),&(v0_159));
  let v0_163: Space = routine_3(c, &(*CONSTANT_32), &((*CONSTANT_33).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_164: Space = unite(&(v0_160),&(v0_163));
  let v0_167: Space = routine_3(c, &(*CONSTANT_34), &((*CONSTANT_35).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_168: Space = unite(&(v0_164),&(v0_167));
  let v0_171: Space = routine_3(c, &(*CONSTANT_36), &((*CONSTANT_37).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_172: Space = unite(&(v0_168),&(v0_171));
  let v0_175: Space = routine_3(c, &(*CONSTANT_38), &((*CONSTANT_39).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_176: Space = unite(&(v0_172),&(v0_175));
  let v0_179: Space = routine_3(c, &(*CONSTANT_40), &((*CONSTANT_41).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_180: Space = unite(&(v0_176),&(v0_179));
  let v0_183: Space = routine_3(c, &(*CONSTANT_42), &((*CONSTANT_43).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_184: Space = unite(&(v0_180),&(v0_183));
  let v0_187: Space = routine_3(c, &(*CONSTANT_44), &((*CONSTANT_45).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_188: Space = unite(&(v0_184),&(v0_187));
  let v0_191: Space = routine_3(c, &(*CONSTANT_46), &((*CONSTANT_47).read_zipper()), &((*CONSTANT_48).read_zipper()));
  let v0_192: Space = unite(&(v0_188),&(v0_191));
  let v0_194: Space = wrap(&(v0_192),&(*CONSTANT_49));
  (v0_194).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v5_5 = Space::new();
  let mut v5_5_write = v5_5.write_zipper();
  let mut v5_5_cursor = (*s0).read_zipper();
  let v5_5_origin = v5_5_cursor.path().len();
  for v5_5_byte in v5_5_cursor.child_mask().iter() {
    v5_5_cursor.descend_to_existing_byte(v5_5_byte);
    {
    for v6_3_byte in v5_5_cursor.child_mask().iter() {
      v5_5_cursor.descend_to_existing_byte(v6_3_byte);
      {
      for v7_4_byte in v5_5_cursor.child_mask().iter() {
        v5_5_cursor.descend_to_existing_byte(v7_4_byte);
        {
        for v8_4_byte in v5_5_cursor.child_mask().iter() {
          v5_5_cursor.descend_to_existing_byte(v8_4_byte);
          {
          let v9_3: Space = if (&(descend_cursor((*CONSTANT_50).read_zipper(),&(*p0)))).is_empty() { Space::new() } else {
            compose(&(descend_cursor((*CONSTANT_50).read_zipper(),&(*p0))),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_50).read_zipper(),&v5_5_cursor.path()[v5_5_origin..(v5_5_origin + 1)]),&v5_5_cursor.path()[(v5_5_origin + 1)..(v5_5_origin + 2)]),&v5_5_cursor.path()[(v5_5_origin + 2)..(v5_5_origin + 3)]),&v5_5_cursor.path()[(v5_5_origin + 3)..(v5_5_origin + 4)])))
          };
          let v9_5: Path = concat_path(&(*p0),&v5_5_cursor.path()[v5_5_origin..(v5_5_origin + 4)]);
          let v9_6: Space = singleton(&(v9_5));
          drop(v9_5);
          let v9_7: Space = subtract(&(v9_3),&(v9_6));
          drop(v9_3);
          drop(v9_6);
          join_wrapped_into(&mut v5_5_write,&((v9_7).read_zipper()),&[]);
          }
          v5_5_cursor.ascend(1);
        }
        }
        v5_5_cursor.ascend(1);
      }
      }
      v5_5_cursor.ascend(1);
    }
    }
    v5_5_cursor.ascend(1);
  }
  drop(v5_5_cursor);
  drop(v5_5_write);
  (v5_5).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v11_11 = Space::new();
  let mut v11_11_write = v11_11.write_zipper();
  let mut v11_11_cursor = (*s0).read_zipper();
  let v11_11_origin = v11_11_cursor.path().len();
  for v11_11_byte in v11_11_cursor.child_mask().iter() {
    v11_11_cursor.descend_to_existing_byte(v11_11_byte);
    {
    for v12_4_byte in v11_11_cursor.child_mask().iter() {
      v11_11_cursor.descend_to_existing_byte(v12_4_byte);
      {
      for v13_5_byte in v11_11_cursor.child_mask().iter() {
        v11_11_cursor.descend_to_existing_byte(v13_5_byte);
        {
        for v14_5_byte in v11_11_cursor.child_mask().iter() {
          v11_11_cursor.descend_to_existing_byte(v14_5_byte);
          {
          let v15_3: Space = if (&(descend_cursor((*CONSTANT_50).read_zipper(),&(*p0)))).is_empty() { Space::new() } else {
            compose(&(descend_cursor((*CONSTANT_50).read_zipper(),&(*p0))),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_50).read_zipper(),&v11_11_cursor.path()[v11_11_origin..(v11_11_origin + 1)]),&v11_11_cursor.path()[(v11_11_origin + 1)..(v11_11_origin + 2)]),&v11_11_cursor.path()[(v11_11_origin + 2)..(v11_11_origin + 3)]),&v11_11_cursor.path()[(v11_11_origin + 3)..(v11_11_origin + 4)])))
          };
          let v15_5: Path = concat_path(&(*p0),&v11_11_cursor.path()[v11_11_origin..(v11_11_origin + 4)]);
          let v15_6: Space = singleton(&(v15_5));
          drop(v15_5);
          let v15_7: Space = subtract(&(v15_3),&(v15_6));
          drop(v15_3);
          let v15_8: Space = intersect(&(v15_7),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_49))));
          drop(v15_7);
          let v15_9: Space = routine_4(c, &((v15_8).read_zipper()));
          drop(v15_8);
          let mut v15_10 = Space::new();
          let mut v15_10_write = v15_10.write_zipper();
          let mut v15_10_cursor = (v15_9).read_zipper();
          let v15_10_origin = v15_10_cursor.path().len();
          for v15_10_byte in v15_10_cursor.child_mask().iter() {
            v15_10_cursor.descend_to_existing_byte(v15_10_byte);
            {
            for v17_2_byte in v15_10_cursor.child_mask().iter() {
              v15_10_cursor.descend_to_existing_byte(v17_2_byte);
              {
              for v18_3_byte in v15_10_cursor.child_mask().iter() {
                v15_10_cursor.descend_to_existing_byte(v18_3_byte);
                {
                for v19_3_byte in v15_10_cursor.child_mask().iter() {
                  v15_10_cursor.descend_to_existing_byte(v19_3_byte);
                  {
                  let v20_3: Space = routine_5(c, &v15_10_cursor.path()[v15_10_origin..(v15_10_origin + 4)], &v15_10_cursor);
                  join_wrapped_into(&mut v15_10_write,&((v20_3).read_zipper()),&[]);
                  }
                  v15_10_cursor.ascend(1);
                }
                }
                v15_10_cursor.ascend(1);
              }
              }
              v15_10_cursor.ascend(1);
            }
            }
            v15_10_cursor.ascend(1);
          }
          drop(v15_10_cursor);
          drop(v15_10_write);
          let v15_12: Space = if (&(descend_cursor((*CONSTANT_50).read_zipper(),&(*p0)))).is_empty() { Space::new() } else {
            compose(&(descend_cursor((*CONSTANT_50).read_zipper(),&(*p0))),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_50).read_zipper(),&v11_11_cursor.path()[v11_11_origin..(v11_11_origin + 1)]),&v11_11_cursor.path()[(v11_11_origin + 1)..(v11_11_origin + 2)]),&v11_11_cursor.path()[(v11_11_origin + 2)..(v11_11_origin + 3)]),&v11_11_cursor.path()[(v11_11_origin + 3)..(v11_11_origin + 4)])))
          };
          let v15_13: Space = subtract(&(v15_12),&(v15_6));
          drop(v15_12);
          let v15_14: Space = intersect(&(v15_13),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_49))));
          drop(v15_13);
          let v15_15: Space = routine_6(c, &((v15_14).read_zipper()));
          drop(v15_14);
          let mut v15_16 = Space::new();
          let mut v15_16_write = v15_16.write_zipper();
          let mut v15_16_cursor = (v15_15).read_zipper();
          let v15_16_origin = v15_16_cursor.path().len();
          for v15_16_byte in v15_16_cursor.child_mask().iter() {
            v15_16_cursor.descend_to_existing_byte(v15_16_byte);
            {
            for v22_2_byte in v15_16_cursor.child_mask().iter() {
              v15_16_cursor.descend_to_existing_byte(v22_2_byte);
              {
              for v23_3_byte in v15_16_cursor.child_mask().iter() {
                v15_16_cursor.descend_to_existing_byte(v23_3_byte);
                {
                for v24_3_byte in v15_16_cursor.child_mask().iter() {
                  v15_16_cursor.descend_to_existing_byte(v24_3_byte);
                  {
                  let v25_3: Space = routine_7(c, &v15_16_cursor.path()[v15_16_origin..(v15_16_origin + 4)], &v15_16_cursor);
                  join_wrapped_into(&mut v15_16_write,&((v25_3).read_zipper()),&[]);
                  }
                  v15_16_cursor.ascend(1);
                }
                }
                v15_16_cursor.ascend(1);
              }
              }
              v15_16_cursor.ascend(1);
            }
            }
            v15_16_cursor.ascend(1);
          }
          drop(v15_16_cursor);
          drop(v15_16_write);
          let v15_17: Space = subtract(&(v15_10),&(v15_16));
          let v15_18: Space = if (&(v15_17)).is_empty() { Space::new() } else {
            compose(&(v15_17),&(v15_6))
          };
          drop(v15_6);
          let mut v15_19_cursor = (v15_18).read_zipper();
          let v15_19_origin = v15_19_cursor.path().len();
          for v15_19_byte in v15_19_cursor.child_mask().iter() {
            v15_19_cursor.descend_to_existing_byte(v15_19_byte);
            {
            for v27_2_byte in v15_19_cursor.child_mask().iter() {
              v15_19_cursor.descend_to_existing_byte(v27_2_byte);
              {
              for v28_3_byte in v15_19_cursor.child_mask().iter() {
                v15_19_cursor.descend_to_existing_byte(v28_3_byte);
                {
                for v29_3_byte in v15_19_cursor.child_mask().iter() {
                  v15_19_cursor.descend_to_existing_byte(v29_3_byte);
                  {
                  let v30_3: Space = routine_8(c, &v15_19_cursor.path()[v15_19_origin..(v15_19_origin + 4)], &v15_19_cursor);
                  join_wrapped_into(&mut v11_11_write,&((v30_3).read_zipper()),&[]);
                  }
                  v15_19_cursor.ascend(1);
                }
                }
                v15_19_cursor.ascend(1);
              }
              }
              v15_19_cursor.ascend(1);
            }
            }
            v15_19_cursor.ascend(1);
          }
          drop(v15_19_cursor);
          }
          v11_11_cursor.ascend(1);
        }
        }
        v11_11_cursor.ascend(1);
      }
      }
      v11_11_cursor.ascend(1);
    }
    }
    v11_11_cursor.ascend(1);
  }
  drop(v11_11_cursor);
  drop(v11_11_write);
  (v11_11).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v31_11 = Space::new();
  let mut v31_11_write = v31_11.write_zipper();
  let mut v31_11_cursor = (*s0).read_zipper();
  let v31_11_origin = v31_11_cursor.path().len();
  for v31_11_byte in v31_11_cursor.child_mask().iter() {
    v31_11_cursor.descend_to_existing_byte(v31_11_byte);
    {
    for v32_4_byte in v31_11_cursor.child_mask().iter() {
      v31_11_cursor.descend_to_existing_byte(v32_4_byte);
      {
      for v33_5_byte in v31_11_cursor.child_mask().iter() {
        v31_11_cursor.descend_to_existing_byte(v33_5_byte);
        {
        for v34_5_byte in v31_11_cursor.child_mask().iter() {
          v31_11_cursor.descend_to_existing_byte(v34_5_byte);
          {
          let v35_3: Space = if (&(descend_cursor((*CONSTANT_50).read_zipper(),&(*p0)))).is_empty() { Space::new() } else {
            compose(&(descend_cursor((*CONSTANT_50).read_zipper(),&(*p0))),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_50).read_zipper(),&v31_11_cursor.path()[v31_11_origin..(v31_11_origin + 1)]),&v31_11_cursor.path()[(v31_11_origin + 1)..(v31_11_origin + 2)]),&v31_11_cursor.path()[(v31_11_origin + 2)..(v31_11_origin + 3)]),&v31_11_cursor.path()[(v31_11_origin + 3)..(v31_11_origin + 4)])))
          };
          let v35_5: Path = concat_path(&(*p0),&v31_11_cursor.path()[v31_11_origin..(v31_11_origin + 4)]);
          let v35_6: Space = singleton(&(v35_5));
          drop(v35_5);
          let v35_7: Space = subtract(&(v35_3),&(v35_6));
          drop(v35_3);
          let v35_8: Space = intersect(&(v35_7),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_49))));
          drop(v35_7);
          let v35_9: Space = routine_9(c, &((v35_8).read_zipper()));
          drop(v35_8);
          let mut v35_10 = Space::new();
          let mut v35_10_write = v35_10.write_zipper();
          let mut v35_10_cursor = (v35_9).read_zipper();
          let v35_10_origin = v35_10_cursor.path().len();
          for v35_10_byte in v35_10_cursor.child_mask().iter() {
            v35_10_cursor.descend_to_existing_byte(v35_10_byte);
            {
            for v37_2_byte in v35_10_cursor.child_mask().iter() {
              v35_10_cursor.descend_to_existing_byte(v37_2_byte);
              {
              for v38_3_byte in v35_10_cursor.child_mask().iter() {
                v35_10_cursor.descend_to_existing_byte(v38_3_byte);
                {
                for v39_3_byte in v35_10_cursor.child_mask().iter() {
                  v35_10_cursor.descend_to_existing_byte(v39_3_byte);
                  {
                  let v40_3: Space = routine_10(c, &v35_10_cursor.path()[v35_10_origin..(v35_10_origin + 4)], &v35_10_cursor);
                  join_wrapped_into(&mut v35_10_write,&((v40_3).read_zipper()),&[]);
                  }
                  v35_10_cursor.ascend(1);
                }
                }
                v35_10_cursor.ascend(1);
              }
              }
              v35_10_cursor.ascend(1);
            }
            }
            v35_10_cursor.ascend(1);
          }
          drop(v35_10_cursor);
          drop(v35_10_write);
          let v35_12: Space = if (&(descend_cursor((*CONSTANT_50).read_zipper(),&(*p0)))).is_empty() { Space::new() } else {
            compose(&(descend_cursor((*CONSTANT_50).read_zipper(),&(*p0))),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*CONSTANT_50).read_zipper(),&v31_11_cursor.path()[v31_11_origin..(v31_11_origin + 1)]),&v31_11_cursor.path()[(v31_11_origin + 1)..(v31_11_origin + 2)]),&v31_11_cursor.path()[(v31_11_origin + 2)..(v31_11_origin + 3)]),&v31_11_cursor.path()[(v31_11_origin + 3)..(v31_11_origin + 4)])))
          };
          let v35_13: Space = subtract(&(v35_12),&(v35_6));
          drop(v35_12);
          let v35_14: Space = intersect(&(v35_13),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_49))));
          drop(v35_13);
          let v35_15: Space = routine_4(c, &((v35_14).read_zipper()));
          drop(v35_14);
          let mut v35_16 = Space::new();
          let mut v35_16_write = v35_16.write_zipper();
          let mut v35_16_cursor = (v35_15).read_zipper();
          let v35_16_origin = v35_16_cursor.path().len();
          for v35_16_byte in v35_16_cursor.child_mask().iter() {
            v35_16_cursor.descend_to_existing_byte(v35_16_byte);
            {
            for v42_2_byte in v35_16_cursor.child_mask().iter() {
              v35_16_cursor.descend_to_existing_byte(v42_2_byte);
              {
              for v43_3_byte in v35_16_cursor.child_mask().iter() {
                v35_16_cursor.descend_to_existing_byte(v43_3_byte);
                {
                for v44_3_byte in v35_16_cursor.child_mask().iter() {
                  v35_16_cursor.descend_to_existing_byte(v44_3_byte);
                  {
                  let v45_3: Space = routine_11(c, &v35_16_cursor.path()[v35_16_origin..(v35_16_origin + 4)], &v35_16_cursor);
                  join_wrapped_into(&mut v35_16_write,&((v45_3).read_zipper()),&[]);
                  }
                  v35_16_cursor.ascend(1);
                }
                }
                v35_16_cursor.ascend(1);
              }
              }
              v35_16_cursor.ascend(1);
            }
            }
            v35_16_cursor.ascend(1);
          }
          drop(v35_16_cursor);
          drop(v35_16_write);
          let v35_17: Space = subtract(&(v35_10),&(v35_16));
          let v35_18: Space = if (&(v35_17)).is_empty() { Space::new() } else {
            compose(&(v35_17),&(v35_6))
          };
          drop(v35_6);
          let mut v35_19_cursor = (v35_18).read_zipper();
          let v35_19_origin = v35_19_cursor.path().len();
          for v35_19_byte in v35_19_cursor.child_mask().iter() {
            v35_19_cursor.descend_to_existing_byte(v35_19_byte);
            {
            for v47_2_byte in v35_19_cursor.child_mask().iter() {
              v35_19_cursor.descend_to_existing_byte(v47_2_byte);
              {
              for v48_3_byte in v35_19_cursor.child_mask().iter() {
                v35_19_cursor.descend_to_existing_byte(v48_3_byte);
                {
                for v49_3_byte in v35_19_cursor.child_mask().iter() {
                  v35_19_cursor.descend_to_existing_byte(v49_3_byte);
                  {
                  let v50_3: Space = routine_12(c, &v35_19_cursor.path()[v35_19_origin..(v35_19_origin + 4)], &v35_19_cursor);
                  join_wrapped_into(&mut v31_11_write,&((v50_3).read_zipper()),&[]);
                  }
                  v35_19_cursor.ascend(1);
                }
                }
                v35_19_cursor.ascend(1);
              }
              }
              v35_19_cursor.ascend(1);
            }
            }
            v35_19_cursor.ascend(1);
          }
          drop(v35_19_cursor);
          }
          v31_11_cursor.ascend(1);
        }
        }
        v31_11_cursor.ascend(1);
      }
      }
      v31_11_cursor.ascend(1);
    }
    }
    v31_11_cursor.ascend(1);
  }
  drop(v31_11_cursor);
  drop(v31_11_write);
  (v31_11).clone()
}

fn routine_4(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v51_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v51_2: Space = first_matching(&(*s0),&(*CONSTANT_51),false);
  let v51_3: Space = unite(&(v51_1),&(v51_2));
  drop(v51_1);
  drop(v51_2);
  let v51_8: Space = if (&(v51_3)).is_empty() { Space::new() } else {
    let v52_6: Space = if (&(v51_3)).is_empty() { Space::new() } else {
      let v53_4: Space = routine_13(c, &(*s0));
      let v53_5: Space = subtract(&(*s0),&(v53_4));
      compose(&(v51_3),&(v53_5))
    };
    let v52_7: Space = routine_14(c, &((v52_6).read_zipper()));
    compose(&(v51_3),&(v52_7))
  };
  drop(v51_3);
  let v54_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v54_2: Space = first_matching(&(*s0),&(*CONSTANT_51),false);
  let v54_3: Space = unite(&(v54_1),&(v54_2));
  drop(v54_1);
  drop(v54_2);
  let v54_6: Space = if (&(v54_3)).is_empty() { Space::new() } else {
    let v55_4: Space = routine_13(c, &(*s0));
    let v55_5: Space = subtract(&(*s0),&(v55_4));
    compose(&(v54_3),&(v55_5))
  };
  let v51_9: Space = if has_head(&(v54_6)) { singleton(&[]) } else { Space::new() };
  let v51_10: Space = first_matching(&(v54_6),&(*CONSTANT_51),false);
  let v51_11: Space = unite(&(v51_9),&(v51_10));
  let v51_13: Space = if (&(v51_11)).is_empty() { Space::new() } else {
    let v56_7: Space = routine_14(c, &((v54_6).read_zipper()));
    let v56_12: Space = routine_14(c, &((v56_7).read_zipper()));
    compose(&(v51_11),&(v56_12))
  };
  let v51_14: Space = subtract(&(*s0),&(v51_13));
  let v51_15: Space = intersect(&(v51_8),&(v51_14));
  (v51_15).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (*CONSTANT_52).clone()
}

fn routine_6(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v58_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v58_2: Space = first_matching(&(*s0),&(*CONSTANT_51),false);
  let v58_3: Space = unite(&(v58_1),&(v58_2));
  drop(v58_1);
  drop(v58_2);
  let v58_6: Space = if (&(v58_3)).is_empty() { Space::new() } else {
    let v59_4: Space = routine_13(c, &(*s0));
    let v59_5: Space = subtract(&(*s0),&(v59_4));
    compose(&(v58_3),&(v59_5))
  };
  let v58_7: Space = if has_head(&(v58_6)) { singleton(&[]) } else { Space::new() };
  let v58_8: Space = first_matching(&(v58_6),&(*CONSTANT_51),false);
  let v58_9: Space = unite(&(v58_7),&(v58_8));
  let v58_12: Space = if (&(v58_9)).is_empty() { Space::new() } else {
    let v60_10: Space = routine_14(c, &((v58_6).read_zipper()));
    let v60_11: Space = routine_14(c, &((v60_10).read_zipper()));
    compose(&(v58_9),&(v60_11))
  };
  let v58_17: Space = if (&(v58_3)).is_empty() { Space::new() } else {
    let v61_15: Space = if (&(v58_3)).is_empty() { Space::new() } else {
      let v62_13: Space = routine_14(c, &(*s0));
      let v62_14: Space = routine_14(c, &((v62_13).read_zipper()));
      compose(&(v58_3),&(v62_14))
    };
    let v61_16: Space = routine_15(c, &((v61_15).read_zipper()));
    compose(&(v58_3),&(v61_16))
  };
  drop(v58_3);
  let v58_18: Space = subtract(&(*s0),&(v58_17));
  let v58_19: Space = intersect(&(v58_12),&(v58_18));
  (v58_19).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (*CONSTANT_52).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_9(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v65_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v65_2: Space = first_matching(&(*s0),&(*CONSTANT_51),false);
  let v65_3: Space = unite(&(v65_1),&(v65_2));
  drop(v65_1);
  drop(v65_2);
  let v65_8: Space = if (&(v65_3)).is_empty() { Space::new() } else {
    let v66_6: Space = if (&(v65_3)).is_empty() { Space::new() } else {
      let v67_4: Space = routine_13(c, &(*s0));
      let v67_5: Space = subtract(&(*s0),&(v67_4));
      compose(&(v65_3),&(v67_5))
    };
    let v66_7: Space = routine_14(c, &((v66_6).read_zipper()));
    compose(&(v65_3),&(v66_7))
  };
  drop(v65_3);
  let v65_9: Space = subtract(&(*s0),&(v65_8));
  let v68_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v68_2: Space = first_matching(&(*s0),&(*CONSTANT_51),false);
  let v68_3: Space = unite(&(v68_1),&(v68_2));
  drop(v68_1);
  drop(v68_2);
  let v68_6: Space = if (&(v68_3)).is_empty() { Space::new() } else {
    let v69_4: Space = routine_13(c, &(*s0));
    let v69_5: Space = subtract(&(*s0),&(v69_4));
    compose(&(v68_3),&(v69_5))
  };
  let v65_10: Space = intersect(&(v68_6),&(v65_9));
  (v65_10).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (*CONSTANT_52).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (*CONSTANT_52).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_13(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v73_2: Space = first_matching(&(*s0),&(*CONSTANT_51),false);
  let v73_3: Space = intersect(&(*CONSTANT_51),&(v73_2));
  let v73_4: Space = if has_head(&(v73_2)) { singleton(&[]) } else { Space::new() };
  let v73_5: Space = unite(&(v73_3),&(v73_4));
  drop(v73_3);
  let v73_7: Space = compose(&(v73_5),&(*CONSTANT_51));
  drop(v73_5);
  let v73_9: Space = subtract(&(*CONSTANT_51),&(v73_2));
  drop(v73_2);
  let v73_10: Space = subtract(&(v73_9),&(v73_4));
  drop(v73_4);
  drop(v73_9);
  let v73_18: Space = if (&(v73_10)).is_empty() { Space::new() } else {
    let v74_11: Space = first_listed(&(*s0),&(*CONSTANT_54),true);
    let v74_12: Space = first_matching(&(v74_11),&(*CONSTANT_51),false);
    let v74_15: Space = if (&(v74_12)).is_empty() { Space::new() } else {
      let v75_14: Space = routine_16(c, &(*CONSTANT_53), &(*s0));
      compose(&(v74_12),&(v75_14))
    };
    drop(v74_12);
    let mut v74_16 = Space::new();
    let mut v74_16_write = v74_16.write_zipper();
    let mut v74_16_cursor = (v74_11).read_zipper();
    let v74_16_origin = v74_16_cursor.path().len();
    for v74_16_byte in v74_16_cursor.child_mask().iter() {
      v74_16_cursor.descend_to_existing_byte(v74_16_byte);
      {
      let v76_2_arg_0: &[u8] = &v74_16_cursor.path()[v74_16_origin..(v74_16_origin + 1)];
      let v76_2_arg_2: &Space = &(&(*s0)).make_map();
      let mut v76_2_more = v74_16_cursor.is_val() || next_value_within(&mut v74_16_cursor,(v74_16_origin + 1));
      while v76_2_more {
        {
        let v76_2_depth = v74_16_cursor.path().len();
        let v77_4: Space = routine_13(c, &(descend_cursor((*v76_2_arg_2).read_zipper(),&v74_16_cursor.path()[v74_16_origin..v76_2_depth])));
        join_wrapped_into(&mut v74_16_write,&((v77_4).read_zipper()),&v74_16_cursor.path()[v74_16_origin..v76_2_depth]);
        }
        v76_2_more = next_value_within(&mut v74_16_cursor,(v74_16_origin + 1));
      }
      }
      v74_16_cursor.ascend(1);
    }
    drop(v74_16_cursor);
    drop(v74_16_write);
    drop(v74_11);
    let v74_17: Space = unite(&(v74_15),&(v74_16));
    compose(&(v73_10),&(v74_17))
  };
  drop(v73_10);
  let v73_19: Space = unite(&(v73_7),&(v73_18));
  drop(v73_7);
  (v73_19).clone()
}

fn routine_14(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v78_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v78_2: Space = first_matching(&(*s0),&(*CONSTANT_51),false);
  let v78_3: Space = unite(&(v78_1),&(v78_2));
  drop(v78_1);
  let v78_19: Space = if (&(v78_3)).is_empty() { Space::new() } else {
    let v79_5: Space = intersect(&(*CONSTANT_51),&(v78_2));
    let v79_6: Space = if has_head(&(v78_2)) { singleton(&[]) } else { Space::new() };
    let v79_7: Space = unite(&(v79_5),&(v79_6));
    drop(v79_5);
    let v79_9: Space = compose(&(v79_7),&(*CONSTANT_51));
    drop(v79_7);
    let v79_10: Space = subtract(&(*s0),&(v79_9));
    drop(v79_9);
    let v79_12: Space = subtract(&(*CONSTANT_51),&(v78_2));
    let v79_13: Space = subtract(&(v79_12),&(v79_6));
    drop(v79_6);
    drop(v79_12);
    let v79_17: Space = if (&(v79_13)).is_empty() { Space::new() } else {
      let v80_15: Space = first_listed(&(*s0),&(*CONSTANT_54),true);
      let mut v80_16 = Space::new();
      let mut v80_16_write = v80_16.write_zipper();
      let v80_16_arg_0: &[u8] = &(*CONSTANT_53);
      let v80_16_arg_2: &Space = &(&(*s0)).make_map();
      let mut v80_16_cursor = (v80_15).read_zipper();
      let v80_16_origin = v80_16_cursor.path().len();
      let mut v80_16_more = v80_16_cursor.is_val() || next_value_within(&mut v80_16_cursor,v80_16_origin);
      while v80_16_more {
        {
        let v80_16_depth = v80_16_cursor.path().len();
        let v81_4: Space = routine_13(c, &(descend_cursor((*v80_16_arg_2).read_zipper(),&v80_16_cursor.path()[v80_16_origin..v80_16_depth])));
        join_wrapped_into(&mut v80_16_write,&((v81_4).read_zipper()),&v80_16_cursor.path()[v80_16_origin..v80_16_depth]);
        }
        v80_16_more = next_value_within(&mut v80_16_cursor,v80_16_origin);
      }
      drop(v80_16_cursor);
      drop(v80_16_write);
      drop(v80_15);
      compose(&(v79_13),&(v80_16))
    };
    drop(v79_13);
    let v79_18: Space = subtract(&(v79_10),&(v79_17));
    drop(v79_10);
    compose(&(v78_3),&(v79_18))
  };
  drop(v78_3);
  (v78_19).clone()
}

fn routine_15(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v82_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v82_2: Space = first_matching(&(*s0),&(*CONSTANT_51),false);
  let v82_3: Space = unite(&(v82_1),&(v82_2));
  drop(v82_1);
  drop(v82_2);
  let v82_13: Space = if (&(v82_3)).is_empty() { Space::new() } else {
    let v83_6: Space = if (&(v82_3)).is_empty() { Space::new() } else {
      let v84_4: Space = routine_13(c, &(*s0));
      let v84_5: Space = subtract(&(*s0),&(v84_4));
      compose(&(v82_3),&(v84_5))
    };
    let v83_7: Space = if has_head(&(v83_6)) { singleton(&[]) } else { Space::new() };
    let v83_8: Space = first_matching(&(v83_6),&(*CONSTANT_51),false);
    let v83_9: Space = unite(&(v83_7),&(v83_8));
    let v83_12: Space = if (&(v83_9)).is_empty() { Space::new() } else {
      let v85_10: Space = routine_13(c, &((v83_6).read_zipper()));
      let v85_11: Space = subtract(&(v83_6),&(v85_10));
      compose(&(v83_9),&(v85_11))
    };
    compose(&(v82_3),&(v83_12))
  };
  drop(v82_3);
  (v82_13).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v86_4: Space = first_matching(&(descend_cursor((*s0).read_zipper(),&(*p0))),&(*CONSTANT_51),false);
  let v86_5: Space = intersect(&(*CONSTANT_51),&(v86_4));
  let v86_6: Space = if has_head(&(v86_4)) { singleton(&[]) } else { Space::new() };
  let v86_7: Space = unite(&(v86_5),&(v86_6));
  drop(v86_5);
  let v86_9: Space = compose(&(v86_7),&(*CONSTANT_51));
  drop(v86_7);
  let v86_11: Space = subtract(&(*CONSTANT_51),&(v86_4));
  drop(v86_4);
  let v86_12: Space = subtract(&(v86_11),&(v86_6));
  drop(v86_6);
  drop(v86_11);
  let v86_16: Space = if (&(v86_12)).is_empty() { Space::new() } else {
    let v87_14: Space = first_listed(&(descend_cursor((*s0).read_zipper(),&(*p0))),&(*CONSTANT_54),true);
    let mut v87_15 = Space::new();
    let mut v87_15_write = v87_15.write_zipper();
    let v87_15_arg_0: &[u8] = &(*CONSTANT_53);
    let v87_15_arg_2: &Space = &(&(descend_cursor((*s0).read_zipper(),&(*p0)))).make_map();
    let mut v87_15_cursor = (v87_14).read_zipper();
    let v87_15_origin = v87_15_cursor.path().len();
    let mut v87_15_more = v87_15_cursor.is_val() || next_value_within(&mut v87_15_cursor,v87_15_origin);
    while v87_15_more {
      {
      let v87_15_depth = v87_15_cursor.path().len();
      let v88_3: Space = routine_16(c, &v87_15_cursor.path()[v87_15_origin..v87_15_depth], &((*v87_15_arg_2).read_zipper()));
      join_wrapped_into(&mut v87_15_write,&((v88_3).read_zipper()),&[]);
      }
      v87_15_more = next_value_within(&mut v87_15_cursor,v87_15_origin);
    }
    drop(v87_15_cursor);
    drop(v87_15_write);
    drop(v87_14);
    compose(&(v86_12),&(v87_15))
  };
  drop(v86_12);
  let v86_17: Space = unite(&(v86_9),&(v86_16));
  drop(v86_9);
  let v86_18: Space = wrap(&(v86_17),&(*p0));
  (v86_18).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
