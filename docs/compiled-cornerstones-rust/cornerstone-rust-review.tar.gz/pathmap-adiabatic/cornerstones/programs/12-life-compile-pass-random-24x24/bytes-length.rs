#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("52 4 48 2 49 48 4 48 2 49 49 4 49 2 49 51 4 49 2 49 52 4 49 2 50 48 4 50 2 49 48 4 50 2 49 51 4 50 2 50 49 3 51 1 49 3 51 1 50 3 51 1 53 3 51 1 55 4 51 2 50 49 3 52 1 56 4 52 2 49 49 4 52 2 49 53 4 52 2 49 54 4 52 2 49 57 4 52 2 50 48 4 52 2 50 51 3 53 1 55 4 53 2 49 48 4 53 2 49 50 4 53 2 49 56 4 53 2 49 57 3 54 1 49 3 54 1 50 3 54 1 52 3 54 1 54 4 54 2 49 52 4 54 2 50 48 3 55 1 49 3 55 1 52 3 55 1 53 4 55 2 49 48 4 55 2 49 52 4 55 2 49 57 4 55 2 50 48 3 56 1 53 3 56 1 54 3 56 1 57 4 56 2 49 49 4 56 2 49 57 4 56 2 50 49 3 57 1 51 3 57 1 52 3 57 1 53 3 57 1 55 4 57 2 49 50 4 57 2 49 55 4 57 2 49 57 4 57 2 50 51"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[2]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("68 4 49 48 1 54 4 49 48 1 57 5 49 48 2 49 50 5 49 48 2 49 56 5 49 48 2 50 51 4 49 49 1 51 4 49 49 1 53 5 49 49 2 49 49 5 49 49 2 49 50 5 49 49 2 50 51 4 49 50 1 50 5 49 50 2 49 54 5 49 50 2 49 57 4 49 51 1 57 5 49 51 2 49 52 5 49 51 2 50 48 5 49 51 2 50 49 4 49 52 1 48 4 49 52 1 54 4 49 52 1 56 4 49 52 1 57 5 49 52 2 49 56 4 49 53 1 49 4 49 53 1 51 4 49 53 1 53 4 49 53 1 54 5 49 53 2 49 54 5 49 53 2 49 55 5 49 53 2 49 57 5 49 53 2 50 48 4 49 54 1 48 4 49 55 1 50 4 49 55 1 51 4 49 55 1 52 4 49 55 1 54 4 49 55 1 55 4 49 55 1 57 5 49 55 2 49 50 5 49 55 2 49 54 5 49 55 2 49 56 4 49 56 1 53 5 49 56 2 49 48 5 49 56 2 49 50 5 49 56 2 49 51 5 49 56 2 49 53 5 49 56 2 49 55 5 49 56 2 50 50 4 49 57 1 51 5 49 57 2 49 56 5 49 57 2 50 49 4 50 48 1 50 4 50 48 1 53 4 50 48 1 55 4 50 48 1 57 5 50 48 2 49 53 4 50 49 1 52 4 50 49 1 56 4 50 49 1 57 5 50 49 2 49 51 5 50 49 2 49 53 4 50 50 1 50 5 50 50 2 49 54 5 50 50 2 50 50 4 50 51 1 49 4 50 51 1 50 4 50 51 1 53 4 50 51 1 55 4 50 51 1 57"));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("120 10 4 67 101 108 108 1 48 2 49 48 10 4 67 101 108 108 1 48 2 49 49 10 4 67 101 108 108 1 49 2 49 51 10 4 67 101 108 108 1 49 2 49 52 10 4 67 101 108 108 1 49 2 50 48 10 4 67 101 108 108 1 50 2 49 48 10 4 67 101 108 108 1 50 2 49 51 10 4 67 101 108 108 1 50 2 50 49 9 4 67 101 108 108 1 51 1 49 9 4 67 101 108 108 1 51 1 50 9 4 67 101 108 108 1 51 1 53 9 4 67 101 108 108 1 51 1 55 10 4 67 101 108 108 1 51 2 50 49 9 4 67 101 108 108 1 52 1 56 10 4 67 101 108 108 1 52 2 49 49 10 4 67 101 108 108 1 52 2 49 53 10 4 67 101 108 108 1 52 2 49 54 10 4 67 101 108 108 1 52 2 49 57 10 4 67 101 108 108 1 52 2 50 48 10 4 67 101 108 108 1 52 2 50 51 9 4 67 101 108 108 1 53 1 55 10 4 67 101 108 108 1 53 2 49 48 10 4 67 101 108 108 1 53 2 49 50 10 4 67 101 108 108 1 53 2 49 56 10 4 67 101 108 108 1 53 2 49 57 9 4 67 101 108 108 1 54 1 49 9 4 67 101 108 108 1 54 1 50 9 4 67 101 108 108 1 54 1 52 9 4 67 101 108 108 1 54 1 54 10 4 67 101 108 108 1 54 2 49 52 10 4 67 101 108 108 1 54 2 50 48 9 4 67 101 108 108 1 55 1 49 9 4 67 101 108 108 1 55 1 52 9 4 67 101 108 108 1 55 1 53 10 4 67 101 108 108 1 55 2 49 48 10 4 67 101 108 108 1 55 2 49 52 10 4 67 101 108 108 1 55 2 49 57 10 4 67 101 108 108 1 55 2 50 48 9 4 67 101 108 108 1 56 1 53 9 4 67 101 108 108 1 56 1 54 9 4 67 101 108 108 1 56 1 57 10 4 67 101 108 108 1 56 2 49 49 10 4 67 101 108 108 1 56 2 49 57 10 4 67 101 108 108 1 56 2 50 49 9 4 67 101 108 108 1 57 1 51 9 4 67 101 108 108 1 57 1 52 9 4 67 101 108 108 1 57 1 53 9 4 67 101 108 108 1 57 1 55 10 4 67 101 108 108 1 57 2 49 50 10 4 67 101 108 108 1 57 2 49 55 10 4 67 101 108 108 1 57 2 49 57 10 4 67 101 108 108 1 57 2 50 51 10 4 67 101 108 108 2 49 48 1 54 10 4 67 101 108 108 2 49 48 1 57 11 4 67 101 108 108 2 49 48 2 49 50 11 4 67 101 108 108 2 49 48 2 49 56 11 4 67 101 108 108 2 49 48 2 50 51 10 4 67 101 108 108 2 49 49 1 51 10 4 67 101 108 108 2 49 49 1 53 11 4 67 101 108 108 2 49 49 2 49 49 11 4 67 101 108 108 2 49 49 2 49 50 11 4 67 101 108 108 2 49 49 2 50 51 10 4 67 101 108 108 2 49 50 1 50 11 4 67 101 108 108 2 49 50 2 49 54 11 4 67 101 108 108 2 49 50 2 49 57 10 4 67 101 108 108 2 49 51 1 57 11 4 67 101 108 108 2 49 51 2 49 52 11 4 67 101 108 108 2 49 51 2 50 48 11 4 67 101 108 108 2 49 51 2 50 49 10 4 67 101 108 108 2 49 52 1 48 10 4 67 101 108 108 2 49 52 1 54 10 4 67 101 108 108 2 49 52 1 56 10 4 67 101 108 108 2 49 52 1 57 11 4 67 101 108 108 2 49 52 2 49 56 10 4 67 101 108 108 2 49 53 1 49 10 4 67 101 108 108 2 49 53 1 51 10 4 67 101 108 108 2 49 53 1 53 10 4 67 101 108 108 2 49 53 1 54 11 4 67 101 108 108 2 49 53 2 49 54 11 4 67 101 108 108 2 49 53 2 49 55 11 4 67 101 108 108 2 49 53 2 49 57 11 4 67 101 108 108 2 49 53 2 50 48 10 4 67 101 108 108 2 49 54 1 48 10 4 67 101 108 108 2 49 55 1 50 10 4 67 101 108 108 2 49 55 1 51 10 4 67 101 108 108 2 49 55 1 52 10 4 67 101 108 108 2 49 55 1 54 10 4 67 101 108 108 2 49 55 1 55 10 4 67 101 108 108 2 49 55 1 57 11 4 67 101 108 108 2 49 55 2 49 50 11 4 67 101 108 108 2 49 55 2 49 54 11 4 67 101 108 108 2 49 55 2 49 56 10 4 67 101 108 108 2 49 56 1 53 11 4 67 101 108 108 2 49 56 2 49 48 11 4 67 101 108 108 2 49 56 2 49 50 11 4 67 101 108 108 2 49 56 2 49 51 11 4 67 101 108 108 2 49 56 2 49 53 11 4 67 101 108 108 2 49 56 2 49 55 11 4 67 101 108 108 2 49 56 2 50 50 10 4 67 101 108 108 2 49 57 1 51 11 4 67 101 108 108 2 49 57 2 49 56 11 4 67 101 108 108 2 49 57 2 50 49 10 4 67 101 108 108 2 50 48 1 50 10 4 67 101 108 108 2 50 48 1 53 10 4 67 101 108 108 2 50 48 1 55 10 4 67 101 108 108 2 50 48 1 57 11 4 67 101 108 108 2 50 48 2 49 53 10 4 67 101 108 108 2 50 49 1 52 10 4 67 101 108 108 2 50 49 1 56 10 4 67 101 108 108 2 50 49 1 57 11 4 67 101 108 108 2 50 49 2 49 51 11 4 67 101 108 108 2 50 49 2 49 53 10 4 67 101 108 108 2 50 50 1 50 11 4 67 101 108 108 2 50 50 2 49 54 11 4 67 101 108 108 2 50 50 2 50 50 10 4 67 101 108 108 2 50 51 1 49 10 4 67 101 108 108 2 50 51 1 50 10 4 67 101 108 108 2 50 51 1 53 10 4 67 101 108 108 2 50 51 1 55 10 4 67 101 108 108 2 50 51 1 57"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4,67,101,108,108]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_7: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("255 2 1 0 2 2 1 2 3 2 2 4 3 2 5 4 2 6 5 2 7 6 2 8 7 2 9 8 2 10 9 2 11 10 2 12 11 2 13 12 2 14 13 2 15 14 2 16 15 2 17 16 2 18 17 2 19 18 2 20 19 2 21 20 2 22 21 2 23 22 2 24 23 2 25 24 2 26 25 2 27 26 2 28 27 2 29 28 2 30 29 2 31 30 2 32 31 2 33 32 2 34 33 2 35 34 2 36 35 2 37 36 2 38 37 2 39 38 2 40 39 2 41 40 2 42 41 2 43 42 2 44 43 2 45 44 2 46 45 2 47 46 2 48 47 2 49 48 2 50 49 2 51 50 2 52 51 2 53 52 2 54 53 2 55 54 2 56 55 2 57 56 2 58 57 2 59 58 2 60 59 2 61 60 2 62 61 2 63 62 2 64 63 2 65 64 2 66 65 2 67 66 2 68 67 2 69 68 2 70 69 2 71 70 2 72 71 2 73 72 2 74 73 2 75 74 2 76 75 2 77 76 2 78 77 2 79 78 2 80 79 2 81 80 2 82 81 2 83 82 2 84 83 2 85 84 2 86 85 2 87 86 2 88 87 2 89 88 2 90 89 2 91 90 2 92 91 2 93 92 2 94 93 2 95 94 2 96 95 2 97 96 2 98 97 2 99 98 2 100 99 2 101 100 2 102 101 2 103 102 2 104 103 2 105 104 2 106 105 2 107 106 2 108 107 2 109 108 2 110 109 2 111 110 2 112 111 2 113 112 2 114 113 2 115 114 2 116 115 2 117 116 2 118 117 2 119 118 2 120 119 2 121 120 2 122 121 2 123 122 2 124 123 2 125 124 2 126 125 2 127 126 2 128 127 2 129 128 2 130 129 2 131 130 2 132 131 2 133 132 2 134 133 2 135 134 2 136 135 2 137 136 2 138 137 2 139 138 2 140 139 2 141 140 2 142 141 2 143 142 2 144 143 2 145 144 2 146 145 2 147 146 2 148 147 2 149 148 2 150 149 2 151 150 2 152 151 2 153 152 2 154 153 2 155 154 2 156 155 2 157 156 2 158 157 2 159 158 2 160 159 2 161 160 2 162 161 2 163 162 2 164 163 2 165 164 2 166 165 2 167 166 2 168 167 2 169 168 2 170 169 2 171 170 2 172 171 2 173 172 2 174 173 2 175 174 2 176 175 2 177 176 2 178 177 2 179 178 2 180 179 2 181 180 2 182 181 2 183 182 2 184 183 2 185 184 2 186 185 2 187 186 2 188 187 2 189 188 2 190 189 2 191 190 2 192 191 2 193 192 2 194 193 2 195 194 2 196 195 2 197 196 2 198 197 2 199 198 2 200 199 2 201 200 2 202 201 2 203 202 2 204 203 2 205 204 2 206 205 2 207 206 2 208 207 2 209 208 2 210 209 2 211 210 2 212 211 2 213 212 2 214 213 2 215 214 2 216 215 2 217 216 2 218 217 2 219 218 2 220 219 2 221 220 2 222 221 2 223 222 2 224 223 2 225 224 2 226 225 2 227 226 2 228 227 2 229 228 2 230 229 2 231 230 2 232 231 2 233 232 2 234 233 2 235 234 2 236 235 2 237 236 2 238 237 2 239 238 2 240 239 2 241 240 2 242 241 2 243 242 2 244 243 2 245 244 2 246 245 2 247 246 2 248 247 2 249 248 2 250 249 2 251 250 2 252 251 2 253 252 2 254 253 2 255 254"));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("387 4 1 48 1 48 4 1 48 1 49 5 1 48 2 45 49 4 1 49 1 48 4 1 49 1 49 4 1 49 1 50 4 1 50 1 49 4 1 50 1 50 4 1 50 1 51 4 1 51 1 50 4 1 51 1 51 4 1 51 1 52 4 1 52 1 51 4 1 52 1 52 4 1 52 1 53 4 1 53 1 52 4 1 53 1 53 4 1 53 1 54 4 1 54 1 53 4 1 54 1 54 4 1 54 1 55 4 1 55 1 54 4 1 55 1 55 4 1 55 1 56 4 1 56 1 55 4 1 56 1 56 4 1 56 1 57 4 1 57 1 56 4 1 57 1 57 5 1 57 2 49 48 5 2 45 49 1 48 6 2 45 49 2 45 49 6 2 45 49 2 45 50 6 2 45 50 2 45 49 6 2 45 50 2 45 50 6 2 45 50 2 45 51 6 2 45 51 2 45 50 6 2 45 51 2 45 51 6 2 45 51 2 45 52 6 2 45 52 2 45 51 6 2 45 52 2 45 52 6 2 45 52 2 45 53 6 2 45 53 2 45 52 6 2 45 53 2 45 53 6 2 45 53 2 45 54 6 2 45 54 2 45 53 6 2 45 54 2 45 54 6 2 45 54 2 45 55 6 2 45 55 2 45 54 6 2 45 55 2 45 55 6 2 45 55 2 45 56 6 2 45 56 2 45 55 6 2 45 56 2 45 56 6 2 45 56 2 45 57 6 2 45 57 2 45 56 6 2 45 57 2 45 57 7 2 45 57 3 45 49 48 5 2 49 48 1 57 6 2 49 48 2 49 48 6 2 49 48 2 49 49 6 2 49 49 2 49 48 6 2 49 49 2 49 49 6 2 49 49 2 49 50 6 2 49 50 2 49 49 6 2 49 50 2 49 50 6 2 49 50 2 49 51 6 2 49 51 2 49 50 6 2 49 51 2 49 51 6 2 49 51 2 49 52 6 2 49 52 2 49 51 6 2 49 52 2 49 52 6 2 49 52 2 49 53 6 2 49 53 2 49 52 6 2 49 53 2 49 53 6 2 49 53 2 49 54 6 2 49 54 2 49 53 6 2 49 54 2 49 54 6 2 49 54 2 49 55 6 2 49 55 2 49 54 6 2 49 55 2 49 55 6 2 49 55 2 49 56 6 2 49 56 2 49 55 6 2 49 56 2 49 56 6 2 49 56 2 49 57 6 2 49 57 2 49 56 6 2 49 57 2 49 57 6 2 49 57 2 50 48 6 2 50 48 2 49 57 6 2 50 48 2 50 48 6 2 50 48 2 50 49 6 2 50 49 2 50 48 6 2 50 49 2 50 49 6 2 50 49 2 50 50 6 2 50 50 2 50 49 6 2 50 50 2 50 50 6 2 50 50 2 50 51 6 2 50 51 2 50 50 6 2 50 51 2 50 51 6 2 50 51 2 50 52 6 2 50 52 2 50 51 6 2 50 52 2 50 52 6 2 50 52 2 50 53 6 2 50 53 2 50 52 6 2 50 53 2 50 53 6 2 50 53 2 50 54 6 2 50 54 2 50 53 6 2 50 54 2 50 54 6 2 50 54 2 50 55 6 2 50 55 2 50 54 6 2 50 55 2 50 55 6 2 50 55 2 50 56 6 2 50 56 2 50 55 6 2 50 56 2 50 56 6 2 50 56 2 50 57 6 2 50 57 2 50 56 6 2 50 57 2 50 57 6 2 50 57 2 51 48 6 2 51 48 2 50 57 6 2 51 48 2 51 48 6 2 51 48 2 51 49 6 2 51 49 2 51 48 6 2 51 49 2 51 49 6 2 51 49 2 51 50 6 2 51 50 2 51 49 6 2 51 50 2 51 50 6 2 51 50 2 51 51 6 2 51 51 2 51 50 6 2 51 51 2 51 51 6 2 51 51 2 51 52 6 2 51 52 2 51 51 6 2 51 52 2 51 52 6 2 51 52 2 51 53 6 2 51 53 2 51 52 6 2 51 53 2 51 53 6 2 51 53 2 51 54 6 2 51 54 2 51 53 6 2 51 54 2 51 54 6 2 51 54 2 51 55 6 2 51 55 2 51 54 6 2 51 55 2 51 55 6 2 51 55 2 51 56 6 2 51 56 2 51 55 6 2 51 56 2 51 56 6 2 51 56 2 51 57 6 2 51 57 2 51 56 6 2 51 57 2 51 57 6 2 51 57 2 52 48 6 2 52 48 2 51 57 6 2 52 48 2 52 48 6 2 52 48 2 52 49 6 2 52 49 2 52 48 6 2 52 49 2 52 49 6 2 52 49 2 52 50 6 2 52 50 2 52 49 6 2 52 50 2 52 50 6 2 52 50 2 52 51 6 2 52 51 2 52 50 6 2 52 51 2 52 51 6 2 52 51 2 52 52 6 2 52 52 2 52 51 6 2 52 52 2 52 52 6 2 52 52 2 52 53 6 2 52 53 2 52 52 6 2 52 53 2 52 53 6 2 52 53 2 52 54 6 2 52 54 2 52 53 6 2 52 54 2 52 54 6 2 52 54 2 52 55 6 2 52 55 2 52 54 6 2 52 55 2 52 55 6 2 52 55 2 52 56 6 2 52 56 2 52 55 6 2 52 56 2 52 56 6 2 52 56 2 52 57 6 2 52 57 2 52 56 6 2 52 57 2 52 57 6 2 52 57 2 53 48 6 2 53 48 2 52 57 6 2 53 48 2 53 48 6 2 53 48 2 53 49 6 2 53 49 2 53 48 6 2 53 49 2 53 49 6 2 53 49 2 53 50 6 2 53 50 2 53 49 6 2 53 50 2 53 50 6 2 53 50 2 53 51 6 2 53 51 2 53 50 6 2 53 51 2 53 51 6 2 53 51 2 53 52 6 2 53 52 2 53 51 6 2 53 52 2 53 52 6 2 53 52 2 53 53 6 2 53 53 2 53 52 6 2 53 53 2 53 53 6 2 53 53 2 53 54 6 2 53 54 2 53 53 6 2 53 54 2 53 54 6 2 53 54 2 53 55 6 2 53 55 2 53 54 6 2 53 55 2 53 55 6 2 53 55 2 53 56 6 2 53 56 2 53 55 6 2 53 56 2 53 56 6 2 53 56 2 53 57 6 2 53 57 2 53 56 6 2 53 57 2 53 57 6 2 53 57 2 54 48 6 2 54 48 2 53 57 6 2 54 48 2 54 48 6 2 54 48 2 54 49 6 2 54 49 2 54 48 6 2 54 49 2 54 49 6 2 54 49 2 54 50 6 2 54 50 2 54 49 6 2 54 50 2 54 50 6 2 54 50 2 54 51 6 2 54 51 2 54 50 6 2 54 51 2 54 51 6 2 54 51 2 54 52 6 2 54 52 2 54 51 6 2 54 52 2 54 52 6 2 54 52 2 54 53 7 3 45 49 48 2 45 57 8 3 45 49 48 3 45 49 48 8 3 45 49 48 3 45 49 49 8 3 45 49 49 3 45 49 48 8 3 45 49 49 3 45 49 49 8 3 45 49 49 3 45 49 50 8 3 45 49 50 3 45 49 49 8 3 45 49 50 3 45 49 50 8 3 45 49 50 3 45 49 51 8 3 45 49 51 3 45 49 50 8 3 45 49 51 3 45 49 51 8 3 45 49 51 3 45 49 52 8 3 45 49 52 3 45 49 51 8 3 45 49 52 3 45 49 52 8 3 45 49 52 3 45 49 53 8 3 45 49 53 3 45 49 52 8 3 45 49 53 3 45 49 53 8 3 45 49 53 3 45 49 54 8 3 45 49 54 3 45 49 53 8 3 45 49 54 3 45 49 54 8 3 45 49 54 3 45 49 55 8 3 45 49 55 3 45 49 54 8 3 45 49 55 3 45 49 55 8 3 45 49 55 3 45 49 56 8 3 45 49 56 3 45 49 55 8 3 45 49 56 3 45 49 56 8 3 45 49 56 3 45 49 57 8 3 45 49 57 3 45 49 56 8 3 45 49 57 3 45 49 57 8 3 45 49 57 3 45 50 48 8 3 45 50 48 3 45 49 57 8 3 45 50 48 3 45 50 48 8 3 45 50 48 3 45 50 49 8 3 45 50 49 3 45 50 48 8 3 45 50 49 3 45 50 49 8 3 45 50 49 3 45 50 50 8 3 45 50 50 3 45 50 49 8 3 45 50 50 3 45 50 50 8 3 45 50 50 3 45 50 51 8 3 45 50 51 3 45 50 50 8 3 45 50 51 3 45 50 51 8 3 45 50 51 3 45 50 52 8 3 45 50 52 3 45 50 51 8 3 45 50 52 3 45 50 52 8 3 45 50 52 3 45 50 53 8 3 45 50 53 3 45 50 52 8 3 45 50 53 3 45 50 53 8 3 45 50 53 3 45 50 54 8 3 45 50 54 3 45 50 53 8 3 45 50 54 3 45 50 54 8 3 45 50 54 3 45 50 55 8 3 45 50 55 3 45 50 54 8 3 45 50 55 3 45 50 55 8 3 45 50 55 3 45 50 56 8 3 45 50 56 3 45 50 55 8 3 45 50 56 3 45 50 56 8 3 45 50 56 3 45 50 57 8 3 45 50 57 3 45 50 56 8 3 45 50 57 3 45 50 57 8 3 45 50 57 3 45 51 48 8 3 45 51 48 3 45 50 57 8 3 45 51 48 3 45 51 48 8 3 45 51 48 3 45 51 49 8 3 45 51 49 3 45 51 48 8 3 45 51 49 3 45 51 49 8 3 45 51 49 3 45 51 50 8 3 45 51 50 3 45 51 49 8 3 45 51 50 3 45 51 50 8 3 45 51 50 3 45 51 51 8 3 45 51 51 3 45 51 50 8 3 45 51 51 3 45 51 51 8 3 45 51 51 3 45 51 52 8 3 45 51 52 3 45 51 51 8 3 45 51 52 3 45 51 52 8 3 45 51 52 3 45 51 53 8 3 45 51 53 3 45 51 52 8 3 45 51 53 3 45 51 53 8 3 45 51 53 3 45 51 54 8 3 45 51 54 3 45 51 53 8 3 45 51 54 3 45 51 54 8 3 45 51 54 3 45 51 55 8 3 45 51 55 3 45 51 54 8 3 45 51 55 3 45 51 55 8 3 45 51 55 3 45 51 56 8 3 45 51 56 3 45 51 55 8 3 45 51 56 3 45 51 56 8 3 45 51 56 3 45 51 57 8 3 45 51 57 3 45 51 56 8 3 45 51 57 3 45 51 57 8 3 45 51 57 3 45 52 48 8 3 45 52 48 3 45 51 57 8 3 45 52 48 3 45 52 48 8 3 45 52 48 3 45 52 49 8 3 45 52 49 3 45 52 48 8 3 45 52 49 3 45 52 49 8 3 45 52 49 3 45 52 50 8 3 45 52 50 3 45 52 49 8 3 45 52 50 3 45 52 50 8 3 45 52 50 3 45 52 51 8 3 45 52 51 3 45 52 50 8 3 45 52 51 3 45 52 51 8 3 45 52 51 3 45 52 52 8 3 45 52 52 3 45 52 51 8 3 45 52 52 3 45 52 52 8 3 45 52 52 3 45 52 53 8 3 45 52 53 3 45 52 52 8 3 45 52 53 3 45 52 53 8 3 45 52 53 3 45 52 54 8 3 45 52 54 3 45 52 53 8 3 45 52 54 3 45 52 54 8 3 45 52 54 3 45 52 55 8 3 45 52 55 3 45 52 54 8 3 45 52 55 3 45 52 55 8 3 45 52 55 3 45 52 56 8 3 45 52 56 3 45 52 55 8 3 45 52 56 3 45 52 56 8 3 45 52 56 3 45 52 57 8 3 45 52 57 3 45 52 56 8 3 45 52 57 3 45 52 57 8 3 45 52 57 3 45 53 48 8 3 45 53 48 3 45 52 57 8 3 45 53 48 3 45 53 48 8 3 45 53 48 3 45 53 49 8 3 45 53 49 3 45 53 48 8 3 45 53 49 3 45 53 49 8 3 45 53 49 3 45 53 50 8 3 45 53 50 3 45 53 49 8 3 45 53 50 3 45 53 50 8 3 45 53 50 3 45 53 51 8 3 45 53 51 3 45 53 50 8 3 45 53 51 3 45 53 51 8 3 45 53 51 3 45 53 52 8 3 45 53 52 3 45 53 51 8 3 45 53 52 3 45 53 52 8 3 45 53 52 3 45 53 53 8 3 45 53 53 3 45 53 52 8 3 45 53 53 3 45 53 53 8 3 45 53 53 3 45 53 54 8 3 45 53 54 3 45 53 53 8 3 45 53 54 3 45 53 54 8 3 45 53 54 3 45 53 55 8 3 45 53 55 3 45 53 54 8 3 45 53 55 3 45 53 55 8 3 45 53 55 3 45 53 56 8 3 45 53 56 3 45 53 55 8 3 45 53 56 3 45 53 56 8 3 45 53 56 3 45 53 57 8 3 45 53 57 3 45 53 56 8 3 45 53 57 3 45 53 57 8 3 45 53 57 3 45 54 48 8 3 45 54 48 3 45 53 57 8 3 45 54 48 3 45 54 48 8 3 45 54 48 3 45 54 49 8 3 45 54 49 3 45 54 48 8 3 45 54 49 3 45 54 49 8 3 45 54 49 3 45 54 50 8 3 45 54 50 3 45 54 49 8 3 45 54 50 3 45 54 50 8 3 45 54 50 3 45 54 51 8 3 45 54 51 3 45 54 50 8 3 45 54 51 3 45 54 51 8 3 45 54 51 3 45 54 52 8 3 45 54 52 3 45 54 51 8 3 45 54 52 3 45 54 52 8 3 45 54 52 3 45 54 53"));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 3 104 105 116"));
fn routine_0(c: &mut Context) -> Space {
  let v0_2: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_0), &((*CONSTANT_1).read_zipper()));
  let v0_5: Space = routine_1(c, &(*CONSTANT_2), &(*CONSTANT_2), &((*CONSTANT_3).read_zipper()));
  let v0_6: Space = unite(&(v0_2),&(v0_5));
  let mut v0_8 = Space::new();
  let mut v0_8_write = v0_8.write_zipper();
  let mut v0_8_cursor = (v0_6).read_zipper();
  let v0_8_origin = v0_8_cursor.path().len();
  for v0_8_byte in v0_8_cursor.child_mask().iter() {
    v0_8_cursor.descend_to_existing_byte(v0_8_byte);
    {
    let v1_2: Space = routine_2(c, &v0_8_cursor.path()[v0_8_origin..(v0_8_origin + 1)], &v0_8_cursor.path()[v0_8_origin..(v0_8_origin + 1)], &v0_8_cursor, &((*CONSTANT_4).read_zipper()));
    join_wrapped_into(&mut v0_8_write,&((v1_2).read_zipper()),&[]);
    }
    v0_8_cursor.ascend(1);
  }
  drop(v0_8_cursor);
  drop(v0_8_write);
  let v0_11: Space = routine_3(c, &(*CONSTANT_0), &(*CONSTANT_0), &((*CONSTANT_1).read_zipper()), &((*CONSTANT_4).read_zipper()));
  let v0_12: Space = unite(&(v0_8),&(v0_11));
  let v0_15: Space = routine_3(c, &(*CONSTANT_2), &(*CONSTANT_2), &((*CONSTANT_3).read_zipper()), &((*CONSTANT_4).read_zipper()));
  let v0_16: Space = unite(&(v0_12),&(v0_15));
  let v0_18: Space = wrap(&(v0_16),&(*CONSTANT_5));
  (v0_18).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v2_5: Space = singleton(&(*p1));
  let v2_6: Space = intersect(&(*CONSTANT_7),&(v2_5));
  let v2_7: Space = if has_head(&(v2_6)) { singleton(&[]) } else { Space::new() };
  drop(v2_6);
  let v2_8: Space = subtract(&(*CONSTANT_6),&(v2_7));
  drop(v2_7);
  let v2_19: Space = if (&(v2_8)).is_empty() { Space::new() } else {
    let v3_11: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v3_14: Space = if (&(v3_11)).is_empty() { Space::new() } else {
      let v4_13: Space = routine_4(c, &(*CONSTANT_9), &(*p0), &(*s0));
      compose(&(v3_11),&(v4_13))
    };
    drop(v3_11);
    let mut v3_17 = Space::new();
    let mut v3_17_write = v3_17.write_zipper();
    let mut v3_17_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v3_17_origin = v3_17_cursor.path().len();
    for v3_17_byte in v3_17_cursor.child_mask().iter() {
      v3_17_cursor.descend_to_existing_byte(v3_17_byte);
      {
      let v5_2_arg_0: &[u8] = &v3_17_cursor.path()[v3_17_origin..(v3_17_origin + 1)];
      let v5_2_arg_1: &[u8] = &(*p0);
      let v5_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v5_2_more = v3_17_cursor.is_val() || next_value_within(&mut v3_17_cursor,(v3_17_origin + 1));
      while v5_2_more {
        {
        let v5_2_depth = v3_17_cursor.path().len();
        let mut v6_4_cursor = (*v5_2_arg_3).read_zipper();
        let v6_4_origin = v6_4_cursor.path().len();
        for v6_4_byte in v6_4_cursor.child_mask().iter() {
          v6_4_cursor.descend_to_existing_byte(v6_4_byte);
          {
          let v7_2: Path = concat_path(&(*v5_2_arg_1),&v6_4_cursor.path()[v6_4_origin..(v6_4_origin + 1)]);
          let v7_3: Space = routine_1(c, &(v7_2), &v3_17_cursor.path()[v3_17_origin..v5_2_depth], &v6_4_cursor);
          drop(v7_2);
          join_wrapped_into(&mut v3_17_write,&((v7_3).read_zipper()),&[]);
          }
          v6_4_cursor.ascend(1);
        }
        drop(v6_4_cursor);
        }
        v5_2_more = next_value_within(&mut v3_17_cursor,(v3_17_origin + 1));
      }
      }
      v3_17_cursor.ascend(1);
    }
    drop(v3_17_cursor);
    drop(v3_17_write);
    let v3_18: Space = unite(&(v3_14),&(v3_17));
    compose(&(v2_8),&(v3_18))
  };
  drop(v2_8);
  let v2_21: Space = intersect(&(*CONSTANT_7),&(v2_5));
  drop(v2_5);
  let v2_22: Space = if has_head(&(v2_21)) { singleton(&[]) } else { Space::new() };
  drop(v2_21);
  let v2_24: Space = if (&(v2_22)).is_empty() { Space::new() } else {
    let mut v8_23 = Space::new();
    let mut v8_23_write = v8_23.write_zipper();
    let mut v8_23_cursor = (*s0).read_zipper();
    let v8_23_origin = v8_23_cursor.path().len();
    for v8_23_byte in v8_23_cursor.child_mask().iter() {
      v8_23_cursor.descend_to_existing_byte(v8_23_byte);
      {
      let v9_2: Space = routine_5(c, &v8_23_cursor.path()[v8_23_origin..(v8_23_origin + 1)], &v8_23_cursor.path()[v8_23_origin..(v8_23_origin + 1)], &(*p0), &v8_23_cursor);
      join_wrapped_into(&mut v8_23_write,&((v9_2).read_zipper()),&[]);
      }
      v8_23_cursor.ascend(1);
    }
    drop(v8_23_cursor);
    drop(v8_23_write);
    compose(&(v2_22),&(v8_23))
  };
  drop(v2_22);
  let v2_25: Space = unite(&(v2_19),&(v2_24));
  (v2_25).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v10_6: Space = singleton(&(*p1));
  let v10_7: Space = intersect(&(*CONSTANT_7),&(v10_6));
  let v10_8: Space = if has_head(&(v10_7)) { singleton(&[]) } else { Space::new() };
  drop(v10_7);
  let v10_9: Space = subtract(&(*CONSTANT_6),&(v10_8));
  drop(v10_8);
  let v10_20: Space = if (&(v10_9)).is_empty() { Space::new() } else {
    let v11_12: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v11_15: Space = if (&(v11_12)).is_empty() { Space::new() } else {
      let v12_14: Space = routine_6(c, &(*CONSTANT_9), &(*p0), &(*s0), &(*s1));
      compose(&(v11_12),&(v12_14))
    };
    drop(v11_12);
    let mut v11_18 = Space::new();
    let mut v11_18_write = v11_18.write_zipper();
    let mut v11_18_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v11_18_origin = v11_18_cursor.path().len();
    for v11_18_byte in v11_18_cursor.child_mask().iter() {
      v11_18_cursor.descend_to_existing_byte(v11_18_byte);
      {
      let v13_2_arg_0: &[u8] = &v11_18_cursor.path()[v11_18_origin..(v11_18_origin + 1)];
      let v13_2_arg_1: &[u8] = &(*p0);
      let v13_2_arg_3: &Space = &(&(*s0)).make_map();
      let v13_2_arg_4: &Space = &(&(*s1)).make_map();
      let mut v13_2_more = v11_18_cursor.is_val() || next_value_within(&mut v11_18_cursor,(v11_18_origin + 1));
      while v13_2_more {
        {
        let v13_2_depth = v11_18_cursor.path().len();
        let mut v14_5_cursor = (*v13_2_arg_3).read_zipper();
        let v14_5_origin = v14_5_cursor.path().len();
        for v14_5_byte in v14_5_cursor.child_mask().iter() {
          v14_5_cursor.descend_to_existing_byte(v14_5_byte);
          {
          let v15_2: Path = concat_path(&(*v13_2_arg_1),&v14_5_cursor.path()[v14_5_origin..(v14_5_origin + 1)]);
          let v15_3: Space = routine_2(c, &(v15_2), &v11_18_cursor.path()[v11_18_origin..v13_2_depth], &v14_5_cursor, &((*v13_2_arg_4).read_zipper()));
          drop(v15_2);
          join_wrapped_into(&mut v11_18_write,&((v15_3).read_zipper()),&[]);
          }
          v14_5_cursor.ascend(1);
        }
        drop(v14_5_cursor);
        }
        v13_2_more = next_value_within(&mut v11_18_cursor,(v11_18_origin + 1));
      }
      }
      v11_18_cursor.ascend(1);
    }
    drop(v11_18_cursor);
    drop(v11_18_write);
    let v11_19: Space = unite(&(v11_15),&(v11_18));
    compose(&(v10_9),&(v11_19))
  };
  drop(v10_9);
  let v10_22: Space = intersect(&(*CONSTANT_7),&(v10_6));
  drop(v10_6);
  let v10_23: Space = if has_head(&(v10_22)) { singleton(&[]) } else { Space::new() };
  drop(v10_22);
  let v10_25: Space = if (&(v10_23)).is_empty() { Space::new() } else {
    let mut v16_24 = Space::new();
    let mut v16_24_write = v16_24.write_zipper();
    let mut v16_24_cursor = (*s0).read_zipper();
    let v16_24_origin = v16_24_cursor.path().len();
    for v16_24_byte in v16_24_cursor.child_mask().iter() {
      v16_24_cursor.descend_to_existing_byte(v16_24_byte);
      {
      let v17_2: Space = routine_7(c, &v16_24_cursor.path()[v16_24_origin..(v16_24_origin + 1)], &v16_24_cursor.path()[v16_24_origin..(v16_24_origin + 1)], &(*p0), &v16_24_cursor, &(*s1));
      join_wrapped_into(&mut v16_24_write,&((v17_2).read_zipper()),&[]);
      }
      v16_24_cursor.ascend(1);
    }
    drop(v16_24_cursor);
    drop(v16_24_write);
    compose(&(v10_23),&(v16_24))
  };
  drop(v10_23);
  let v10_26: Space = unite(&(v10_20),&(v10_25));
  (v10_26).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v18_6: Space = singleton(&(*p1));
  let v18_7: Space = intersect(&(*CONSTANT_7),&(v18_6));
  let v18_8: Space = if has_head(&(v18_7)) { singleton(&[]) } else { Space::new() };
  drop(v18_7);
  let v18_9: Space = subtract(&(*CONSTANT_6),&(v18_8));
  drop(v18_8);
  let v18_20: Space = if (&(v18_9)).is_empty() { Space::new() } else {
    let v19_12: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v19_15: Space = if (&(v19_12)).is_empty() { Space::new() } else {
      let v20_14: Space = routine_8(c, &(*CONSTANT_9), &(*p0), &(*s0), &(*s1));
      compose(&(v19_12),&(v20_14))
    };
    drop(v19_12);
    let mut v19_18 = Space::new();
    let mut v19_18_write = v19_18.write_zipper();
    let mut v19_18_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v19_18_origin = v19_18_cursor.path().len();
    for v19_18_byte in v19_18_cursor.child_mask().iter() {
      v19_18_cursor.descend_to_existing_byte(v19_18_byte);
      {
      let v21_2_arg_0: &[u8] = &v19_18_cursor.path()[v19_18_origin..(v19_18_origin + 1)];
      let v21_2_arg_1: &[u8] = &(*p0);
      let v21_2_arg_3: &Space = &(&(*s0)).make_map();
      let v21_2_arg_4: &Space = &(&(*s1)).make_map();
      let mut v21_2_more = v19_18_cursor.is_val() || next_value_within(&mut v19_18_cursor,(v19_18_origin + 1));
      while v21_2_more {
        {
        let v21_2_depth = v19_18_cursor.path().len();
        let mut v22_5_cursor = (*v21_2_arg_3).read_zipper();
        let v22_5_origin = v22_5_cursor.path().len();
        for v22_5_byte in v22_5_cursor.child_mask().iter() {
          v22_5_cursor.descend_to_existing_byte(v22_5_byte);
          {
          let v23_2: Path = concat_path(&(*v21_2_arg_1),&v22_5_cursor.path()[v22_5_origin..(v22_5_origin + 1)]);
          let v23_3: Space = routine_3(c, &(v23_2), &v19_18_cursor.path()[v19_18_origin..v21_2_depth], &v22_5_cursor, &((*v21_2_arg_4).read_zipper()));
          drop(v23_2);
          join_wrapped_into(&mut v19_18_write,&((v23_3).read_zipper()),&[]);
          }
          v22_5_cursor.ascend(1);
        }
        drop(v22_5_cursor);
        }
        v21_2_more = next_value_within(&mut v19_18_cursor,(v19_18_origin + 1));
      }
      }
      v19_18_cursor.ascend(1);
    }
    drop(v19_18_cursor);
    drop(v19_18_write);
    let v19_19: Space = unite(&(v19_15),&(v19_18));
    compose(&(v18_9),&(v19_19))
  };
  drop(v18_9);
  let v18_22: Space = intersect(&(*CONSTANT_7),&(v18_6));
  drop(v18_6);
  let v18_23: Space = if has_head(&(v18_22)) { singleton(&[]) } else { Space::new() };
  drop(v18_22);
  let v18_25: Space = if (&(v18_23)).is_empty() { Space::new() } else {
    let mut v24_24 = Space::new();
    let mut v24_24_write = v24_24.write_zipper();
    let mut v24_24_cursor = (*s0).read_zipper();
    let v24_24_origin = v24_24_cursor.path().len();
    for v24_24_byte in v24_24_cursor.child_mask().iter() {
      v24_24_cursor.descend_to_existing_byte(v24_24_byte);
      {
      let v25_2: Space = routine_9(c, &v24_24_cursor.path()[v24_24_origin..(v24_24_origin + 1)], &v24_24_cursor.path()[v24_24_origin..(v24_24_origin + 1)], &(*p0), &v24_24_cursor, &(*s1));
      join_wrapped_into(&mut v24_24_write,&((v25_2).read_zipper()),&[]);
      }
      v24_24_cursor.ascend(1);
    }
    drop(v24_24_cursor);
    drop(v24_24_write);
    compose(&(v18_23),&(v24_24))
  };
  drop(v18_23);
  let v18_26: Space = unite(&(v18_20),&(v18_25));
  (v18_26).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v26_5: Space = singleton(&(*p0));
  let v26_6: Space = intersect(&(*CONSTANT_7),&(v26_5));
  let v26_7: Space = if has_head(&(v26_6)) { singleton(&[]) } else { Space::new() };
  drop(v26_6);
  let v26_8: Space = subtract(&(*CONSTANT_6),&(v26_7));
  drop(v26_7);
  let v26_13: Space = intersect(&(*CONSTANT_7),&(v26_5));
  drop(v26_5);
  let v26_14: Space = if has_head(&(v26_13)) { singleton(&[]) } else { Space::new() };
  drop(v26_13);
  let mut v26_15 = Space::new();
  let mut v26_15_write = v26_15.write_zipper();
  let mut v26_15_cursor = (*s0).read_zipper();
  let v26_15_origin = v26_15_cursor.path().len();
  for v26_15_byte in v26_15_cursor.child_mask().iter() {
    v26_15_cursor.descend_to_existing_byte(v26_15_byte);
    {
    let v27_4: Space = if (&(v26_8)).is_empty() { Space::new() } else {
      let v28_2: Path = concat_path(&(*p1),&v26_15_cursor.path()[v26_15_origin..(v26_15_origin + 1)]);
      let mut v28_3 = Space::new();
      let mut v28_3_write = v28_3.write_zipper();
      let v28_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v28_3_arg_1: &[u8] = &(v28_2);
      let v28_3_arg_3: &Space = &(&v26_15_cursor).make_map();
      let mut v28_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v28_3_origin = v28_3_cursor.path().len();
      let mut v28_3_more = v28_3_cursor.is_val() || next_value_within(&mut v28_3_cursor,v28_3_origin);
      while v28_3_more {
        {
        let v28_3_depth = v28_3_cursor.path().len();
        let v29_4: Space = routine_4(c, &v28_3_cursor.path()[v28_3_origin..v28_3_depth], &(*v28_3_arg_1), &((*v28_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v28_3_write,&((v29_4).read_zipper()),&[]);
        }
        v28_3_more = next_value_within(&mut v28_3_cursor,v28_3_origin);
      }
      drop(v28_3_cursor);
      drop(v28_3_write);
      compose(&(v26_8),&(v28_3))
    };
    let v27_6: Space = if (&(v26_14)).is_empty() { Space::new() } else {
      let v30_2: Path = concat_path(&(*p1),&v26_15_cursor.path()[v26_15_origin..(v26_15_origin + 1)]);
      let mut v30_5 = Space::new();
      let mut v30_5_write = v30_5.write_zipper();
      for v30_5_byte in v26_15_cursor.child_mask().iter() {
        v26_15_cursor.descend_to_existing_byte(v30_5_byte);
        {
        let v31_2: Space = routine_5(c, &v26_15_cursor.path()[(v26_15_origin + 1)..(v26_15_origin + 2)], &v26_15_cursor.path()[(v26_15_origin + 1)..(v26_15_origin + 2)], &(v30_2), &v26_15_cursor);
        join_wrapped_into(&mut v30_5_write,&((v31_2).read_zipper()),&[]);
        }
        v26_15_cursor.ascend(1);
      }
      drop(v30_5_write);
      drop(v30_2);
      compose(&(v26_14),&(v30_5))
    };
    let v27_7: Space = unite(&(v27_4),&(v27_6));
    join_wrapped_into(&mut v26_15_write,&((v27_7).read_zipper()),&[]);
    }
    v26_15_cursor.ascend(1);
  }
  drop(v26_15_cursor);
  drop(v26_15_write);
  drop(v26_8);
  drop(v26_14);
  (v26_15).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v32_6: Space = singleton(&(*p1));
  let v32_7: Space = intersect(&(*CONSTANT_7),&(v32_6));
  let v32_8: Space = if has_head(&(v32_7)) { singleton(&[]) } else { Space::new() };
  drop(v32_7);
  let v32_9: Space = subtract(&(*CONSTANT_6),&(v32_8));
  drop(v32_8);
  let v32_20: Space = if (&(v32_9)).is_empty() { Space::new() } else {
    let v33_12: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v33_15: Space = if (&(v33_12)).is_empty() { Space::new() } else {
      let v34_14: Space = routine_10(c, &(*CONSTANT_9), &(*p0), &(*p2), &(*s0));
      compose(&(v33_12),&(v34_14))
    };
    drop(v33_12);
    let mut v33_18 = Space::new();
    let mut v33_18_write = v33_18.write_zipper();
    let mut v33_18_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v33_18_origin = v33_18_cursor.path().len();
    for v33_18_byte in v33_18_cursor.child_mask().iter() {
      v33_18_cursor.descend_to_existing_byte(v33_18_byte);
      {
      let v35_2_arg_0: &[u8] = &v33_18_cursor.path()[v33_18_origin..(v33_18_origin + 1)];
      let v35_2_arg_1: &[u8] = &(*p0);
      let v35_2_arg_2: &[u8] = &(*p2);
      let v35_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v35_2_more = v33_18_cursor.is_val() || next_value_within(&mut v33_18_cursor,(v33_18_origin + 1));
      while v35_2_more {
        {
        let v35_2_depth = v33_18_cursor.path().len();
        let mut v36_5_cursor = (*v35_2_arg_4).read_zipper();
        let v36_5_origin = v36_5_cursor.path().len();
        for v36_5_byte in v36_5_cursor.child_mask().iter() {
          v36_5_cursor.descend_to_existing_byte(v36_5_byte);
          {
          let v37_2: Path = concat_path(&(*v35_2_arg_1),&v36_5_cursor.path()[v36_5_origin..(v36_5_origin + 1)]);
          let v37_3: Space = routine_5(c, &(v37_2), &v33_18_cursor.path()[v33_18_origin..v35_2_depth], &(*v35_2_arg_2), &v36_5_cursor);
          drop(v37_2);
          join_wrapped_into(&mut v33_18_write,&((v37_3).read_zipper()),&[]);
          }
          v36_5_cursor.ascend(1);
        }
        drop(v36_5_cursor);
        }
        v35_2_more = next_value_within(&mut v33_18_cursor,(v33_18_origin + 1));
      }
      }
      v33_18_cursor.ascend(1);
    }
    drop(v33_18_cursor);
    drop(v33_18_write);
    let v33_19: Space = unite(&(v33_15),&(v33_18));
    compose(&(v32_9),&(v33_19))
  };
  drop(v32_9);
  let v32_22: Space = intersect(&(*CONSTANT_7),&(v32_6));
  drop(v32_6);
  let v32_23: Space = if has_head(&(v32_22)) { singleton(&[]) } else { Space::new() };
  drop(v32_22);
  let v32_32: Space = if (&(v32_23)).is_empty() { Space::new() } else {
    let v38_28: Space = if (&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p2)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p2))),&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p0))))
    };
    let v38_29: Path = concat_path(&(*p2),&(*p0));
    let v38_30: Space = singleton(&(v38_29));
    drop(v38_29);
    let v38_31: Space = subtract(&(v38_28),&(v38_30));
    drop(v38_28);
    drop(v38_30);
    compose(&(v32_23),&(v38_31))
  };
  drop(v32_23);
  let v32_33: Space = unite(&(v32_20),&(v32_32));
  drop(v32_32);
  (v32_33).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v40_6: Space = singleton(&(*p0));
  let v40_7: Space = intersect(&(*CONSTANT_7),&(v40_6));
  let v40_8: Space = if has_head(&(v40_7)) { singleton(&[]) } else { Space::new() };
  drop(v40_7);
  let v40_9: Space = subtract(&(*CONSTANT_6),&(v40_8));
  drop(v40_8);
  let v40_14: Space = intersect(&(*CONSTANT_7),&(v40_6));
  drop(v40_6);
  let v40_15: Space = if has_head(&(v40_14)) { singleton(&[]) } else { Space::new() };
  drop(v40_14);
  let mut v40_16 = Space::new();
  let mut v40_16_write = v40_16.write_zipper();
  let mut v40_16_cursor = (*s0).read_zipper();
  let v40_16_origin = v40_16_cursor.path().len();
  for v40_16_byte in v40_16_cursor.child_mask().iter() {
    v40_16_cursor.descend_to_existing_byte(v40_16_byte);
    {
    let v41_4: Space = if (&(v40_9)).is_empty() { Space::new() } else {
      let v42_2: Path = concat_path(&(*p1),&v40_16_cursor.path()[v40_16_origin..(v40_16_origin + 1)]);
      let mut v42_3 = Space::new();
      let mut v42_3_write = v42_3.write_zipper();
      let v42_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v42_3_arg_1: &[u8] = &(v42_2);
      let v42_3_arg_3: &Space = &(&v40_16_cursor).make_map();
      let v42_3_arg_4: &Space = &(&(*s1)).make_map();
      let mut v42_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v42_3_origin = v42_3_cursor.path().len();
      let mut v42_3_more = v42_3_cursor.is_val() || next_value_within(&mut v42_3_cursor,v42_3_origin);
      while v42_3_more {
        {
        let v42_3_depth = v42_3_cursor.path().len();
        let v43_5: Space = routine_6(c, &v42_3_cursor.path()[v42_3_origin..v42_3_depth], &(*v42_3_arg_1), &((*v42_3_arg_3).read_zipper()), &((*v42_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v42_3_write,&((v43_5).read_zipper()),&[]);
        }
        v42_3_more = next_value_within(&mut v42_3_cursor,v42_3_origin);
      }
      drop(v42_3_cursor);
      drop(v42_3_write);
      compose(&(v40_9),&(v42_3))
    };
    let v41_6: Space = if (&(v40_15)).is_empty() { Space::new() } else {
      let v44_2: Path = concat_path(&(*p1),&v40_16_cursor.path()[v40_16_origin..(v40_16_origin + 1)]);
      let mut v44_5 = Space::new();
      let mut v44_5_write = v44_5.write_zipper();
      for v44_5_byte in v40_16_cursor.child_mask().iter() {
        v40_16_cursor.descend_to_existing_byte(v44_5_byte);
        {
        let v45_2: Space = routine_7(c, &v40_16_cursor.path()[(v40_16_origin + 1)..(v40_16_origin + 2)], &v40_16_cursor.path()[(v40_16_origin + 1)..(v40_16_origin + 2)], &(v44_2), &v40_16_cursor, &(*s1));
        join_wrapped_into(&mut v44_5_write,&((v45_2).read_zipper()),&[]);
        }
        v40_16_cursor.ascend(1);
      }
      drop(v44_5_write);
      drop(v44_2);
      compose(&(v40_15),&(v44_5))
    };
    let v41_7: Space = unite(&(v41_4),&(v41_6));
    join_wrapped_into(&mut v40_16_write,&((v41_7).read_zipper()),&[]);
    }
    v40_16_cursor.ascend(1);
  }
  drop(v40_16_cursor);
  drop(v40_16_write);
  drop(v40_9);
  drop(v40_15);
  (v40_16).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v46_7: Space = singleton(&(*p1));
  let v46_8: Space = intersect(&(*CONSTANT_7),&(v46_7));
  let v46_9: Space = if has_head(&(v46_8)) { singleton(&[]) } else { Space::new() };
  drop(v46_8);
  let v46_10: Space = subtract(&(*CONSTANT_6),&(v46_9));
  drop(v46_9);
  let v46_21: Space = if (&(v46_10)).is_empty() { Space::new() } else {
    let v47_13: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v47_16: Space = if (&(v47_13)).is_empty() { Space::new() } else {
      let v48_15: Space = routine_11(c, &(*CONSTANT_9), &(*p0), &(*p2), &(*s0), &(*s1));
      compose(&(v47_13),&(v48_15))
    };
    drop(v47_13);
    let mut v47_19 = Space::new();
    let mut v47_19_write = v47_19.write_zipper();
    let mut v47_19_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v47_19_origin = v47_19_cursor.path().len();
    for v47_19_byte in v47_19_cursor.child_mask().iter() {
      v47_19_cursor.descend_to_existing_byte(v47_19_byte);
      {
      let v49_2_arg_0: &[u8] = &v47_19_cursor.path()[v47_19_origin..(v47_19_origin + 1)];
      let v49_2_arg_1: &[u8] = &(*p0);
      let v49_2_arg_2: &[u8] = &(*p2);
      let v49_2_arg_4: &Space = &(&(*s0)).make_map();
      let v49_2_arg_5: &Space = &(&(*s1)).make_map();
      let mut v49_2_more = v47_19_cursor.is_val() || next_value_within(&mut v47_19_cursor,(v47_19_origin + 1));
      while v49_2_more {
        {
        let v49_2_depth = v47_19_cursor.path().len();
        let mut v50_6_cursor = (*v49_2_arg_4).read_zipper();
        let v50_6_origin = v50_6_cursor.path().len();
        for v50_6_byte in v50_6_cursor.child_mask().iter() {
          v50_6_cursor.descend_to_existing_byte(v50_6_byte);
          {
          let v51_2: Path = concat_path(&(*v49_2_arg_1),&v50_6_cursor.path()[v50_6_origin..(v50_6_origin + 1)]);
          let v51_3: Space = routine_7(c, &(v51_2), &v47_19_cursor.path()[v47_19_origin..v49_2_depth], &(*v49_2_arg_2), &v50_6_cursor, &((*v49_2_arg_5).read_zipper()));
          drop(v51_2);
          join_wrapped_into(&mut v47_19_write,&((v51_3).read_zipper()),&[]);
          }
          v50_6_cursor.ascend(1);
        }
        drop(v50_6_cursor);
        }
        v49_2_more = next_value_within(&mut v47_19_cursor,(v47_19_origin + 1));
      }
      }
      v47_19_cursor.ascend(1);
    }
    drop(v47_19_cursor);
    drop(v47_19_write);
    let v47_20: Space = unite(&(v47_16),&(v47_19));
    compose(&(v46_10),&(v47_20))
  };
  drop(v46_10);
  let v46_23: Space = intersect(&(*CONSTANT_7),&(v46_7));
  drop(v46_7);
  let v46_24: Space = if has_head(&(v46_23)) { singleton(&[]) } else { Space::new() };
  drop(v46_23);
  let v46_815: Space = if (&(v46_24)).is_empty() { Space::new() } else {
    let v52_29: Space = if (&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p2)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p2))),&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p0))))
    };
    let v52_30: Path = concat_path(&(*p2),&(*p0));
    let v52_31: Space = singleton(&(v52_30));
    drop(v52_30);
    let v52_32: Space = subtract(&(v52_29),&(v52_31));
    drop(v52_29);
    let v52_35: Space = intersect(&(v52_32),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
    drop(v52_32);
    let v52_36: Space = routine_12(c, &((v52_35).read_zipper()));
    drop(v52_35);
    let mut v52_37 = Space::new();
    let mut v52_37_write = v52_37.write_zipper();
    let mut v52_37_cursor = (v52_36).read_zipper();
    let v52_37_origin = v52_37_cursor.path().len();
    for v52_37_byte in v52_37_cursor.child_mask().iter() {
      v52_37_cursor.descend_to_existing_byte(v52_37_byte);
      {
      let v54_2: Space = routine_13(c, &v52_37_cursor.path()[v52_37_origin..(v52_37_origin + 1)], &v52_37_cursor.path()[v52_37_origin..(v52_37_origin + 1)], &v52_37_cursor);
      join_wrapped_into(&mut v52_37_write,&((v54_2).read_zipper()),&[]);
      }
      v52_37_cursor.ascend(1);
    }
    drop(v52_37_cursor);
    drop(v52_37_write);
    let v52_42: Space = if (&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p2)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p2))),&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p0))))
    };
    let v52_43: Space = subtract(&(v52_42),&(v52_31));
    drop(v52_42);
    let v52_44: Space = intersect(&(v52_43),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
    drop(v52_43);
    let v52_45: Space = routine_14(c, &((v52_44).read_zipper()));
    drop(v52_44);
    let mut v52_46 = Space::new();
    let mut v52_46_write = v52_46.write_zipper();
    let mut v52_46_cursor = (v52_45).read_zipper();
    let v52_46_origin = v52_46_cursor.path().len();
    for v52_46_byte in v52_46_cursor.child_mask().iter() {
      v52_46_cursor.descend_to_existing_byte(v52_46_byte);
      {
      let v56_2: Space = routine_15(c, &v52_46_cursor.path()[v52_46_origin..(v52_46_origin + 1)], &v52_46_cursor.path()[v52_46_origin..(v52_46_origin + 1)], &v52_46_cursor);
      join_wrapped_into(&mut v52_46_write,&((v56_2).read_zipper()),&[]);
      }
      v52_46_cursor.ascend(1);
    }
    drop(v52_46_cursor);
    drop(v52_46_write);
    let v52_47: Space = subtract(&(v52_37),&(v52_46));
    let v52_48: Space = if (&(v52_47)).is_empty() { Space::new() } else {
      compose(&(v52_47),&(v52_31))
    };
    drop(v52_31);
    let v52_814: Space = drop_length_prefixes(&(v52_48));
    compose(&(v46_24),&(v52_814))
  };
  drop(v46_24);
  let v46_816: Space = unite(&(v46_21),&(v46_815));
  (v46_816).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v58_6: Space = singleton(&(*p0));
  let v58_7: Space = intersect(&(*CONSTANT_7),&(v58_6));
  let v58_8: Space = if has_head(&(v58_7)) { singleton(&[]) } else { Space::new() };
  drop(v58_7);
  let v58_9: Space = subtract(&(*CONSTANT_6),&(v58_8));
  drop(v58_8);
  let v58_14: Space = intersect(&(*CONSTANT_7),&(v58_6));
  drop(v58_6);
  let v58_15: Space = if has_head(&(v58_14)) { singleton(&[]) } else { Space::new() };
  drop(v58_14);
  let mut v58_16 = Space::new();
  let mut v58_16_write = v58_16.write_zipper();
  let mut v58_16_cursor = (*s0).read_zipper();
  let v58_16_origin = v58_16_cursor.path().len();
  for v58_16_byte in v58_16_cursor.child_mask().iter() {
    v58_16_cursor.descend_to_existing_byte(v58_16_byte);
    {
    let v59_4: Space = if (&(v58_9)).is_empty() { Space::new() } else {
      let v60_2: Path = concat_path(&(*p1),&v58_16_cursor.path()[v58_16_origin..(v58_16_origin + 1)]);
      let mut v60_3 = Space::new();
      let mut v60_3_write = v60_3.write_zipper();
      let v60_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v60_3_arg_1: &[u8] = &(v60_2);
      let v60_3_arg_3: &Space = &(&v58_16_cursor).make_map();
      let v60_3_arg_4: &Space = &(&(*s1)).make_map();
      let mut v60_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v60_3_origin = v60_3_cursor.path().len();
      let mut v60_3_more = v60_3_cursor.is_val() || next_value_within(&mut v60_3_cursor,v60_3_origin);
      while v60_3_more {
        {
        let v60_3_depth = v60_3_cursor.path().len();
        let v61_5: Space = routine_8(c, &v60_3_cursor.path()[v60_3_origin..v60_3_depth], &(*v60_3_arg_1), &((*v60_3_arg_3).read_zipper()), &((*v60_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v60_3_write,&((v61_5).read_zipper()),&[]);
        }
        v60_3_more = next_value_within(&mut v60_3_cursor,v60_3_origin);
      }
      drop(v60_3_cursor);
      drop(v60_3_write);
      compose(&(v58_9),&(v60_3))
    };
    let v59_6: Space = if (&(v58_15)).is_empty() { Space::new() } else {
      let v62_2: Path = concat_path(&(*p1),&v58_16_cursor.path()[v58_16_origin..(v58_16_origin + 1)]);
      let mut v62_5 = Space::new();
      let mut v62_5_write = v62_5.write_zipper();
      for v62_5_byte in v58_16_cursor.child_mask().iter() {
        v58_16_cursor.descend_to_existing_byte(v62_5_byte);
        {
        let v63_2: Space = routine_9(c, &v58_16_cursor.path()[(v58_16_origin + 1)..(v58_16_origin + 2)], &v58_16_cursor.path()[(v58_16_origin + 1)..(v58_16_origin + 2)], &(v62_2), &v58_16_cursor, &(*s1));
        join_wrapped_into(&mut v62_5_write,&((v63_2).read_zipper()),&[]);
        }
        v58_16_cursor.ascend(1);
      }
      drop(v62_5_write);
      drop(v62_2);
      compose(&(v58_15),&(v62_5))
    };
    let v59_7: Space = unite(&(v59_4),&(v59_6));
    join_wrapped_into(&mut v58_16_write,&((v59_7).read_zipper()),&[]);
    }
    v58_16_cursor.ascend(1);
  }
  drop(v58_16_cursor);
  drop(v58_16_write);
  drop(v58_9);
  drop(v58_15);
  (v58_16).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v64_7: Space = singleton(&(*p1));
  let v64_8: Space = intersect(&(*CONSTANT_7),&(v64_7));
  let v64_9: Space = if has_head(&(v64_8)) { singleton(&[]) } else { Space::new() };
  drop(v64_8);
  let v64_10: Space = subtract(&(*CONSTANT_6),&(v64_9));
  drop(v64_9);
  let v64_21: Space = if (&(v64_10)).is_empty() { Space::new() } else {
    let v65_13: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v65_16: Space = if (&(v65_13)).is_empty() { Space::new() } else {
      let v66_15: Space = routine_16(c, &(*CONSTANT_9), &(*p0), &(*p2), &(*s0), &(*s1));
      compose(&(v65_13),&(v66_15))
    };
    drop(v65_13);
    let mut v65_19 = Space::new();
    let mut v65_19_write = v65_19.write_zipper();
    let mut v65_19_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v65_19_origin = v65_19_cursor.path().len();
    for v65_19_byte in v65_19_cursor.child_mask().iter() {
      v65_19_cursor.descend_to_existing_byte(v65_19_byte);
      {
      let v67_2_arg_0: &[u8] = &v65_19_cursor.path()[v65_19_origin..(v65_19_origin + 1)];
      let v67_2_arg_1: &[u8] = &(*p0);
      let v67_2_arg_2: &[u8] = &(*p2);
      let v67_2_arg_4: &Space = &(&(*s0)).make_map();
      let v67_2_arg_5: &Space = &(&(*s1)).make_map();
      let mut v67_2_more = v65_19_cursor.is_val() || next_value_within(&mut v65_19_cursor,(v65_19_origin + 1));
      while v67_2_more {
        {
        let v67_2_depth = v65_19_cursor.path().len();
        let mut v68_6_cursor = (*v67_2_arg_4).read_zipper();
        let v68_6_origin = v68_6_cursor.path().len();
        for v68_6_byte in v68_6_cursor.child_mask().iter() {
          v68_6_cursor.descend_to_existing_byte(v68_6_byte);
          {
          let v69_2: Path = concat_path(&(*v67_2_arg_1),&v68_6_cursor.path()[v68_6_origin..(v68_6_origin + 1)]);
          let v69_3: Space = routine_9(c, &(v69_2), &v65_19_cursor.path()[v65_19_origin..v67_2_depth], &(*v67_2_arg_2), &v68_6_cursor, &((*v67_2_arg_5).read_zipper()));
          drop(v69_2);
          join_wrapped_into(&mut v65_19_write,&((v69_3).read_zipper()),&[]);
          }
          v68_6_cursor.ascend(1);
        }
        drop(v68_6_cursor);
        }
        v67_2_more = next_value_within(&mut v65_19_cursor,(v65_19_origin + 1));
      }
      }
      v65_19_cursor.ascend(1);
    }
    drop(v65_19_cursor);
    drop(v65_19_write);
    let v65_20: Space = unite(&(v65_16),&(v65_19));
    compose(&(v64_10),&(v65_20))
  };
  drop(v64_10);
  let v64_23: Space = intersect(&(*CONSTANT_7),&(v64_7));
  drop(v64_7);
  let v64_24: Space = if has_head(&(v64_23)) { singleton(&[]) } else { Space::new() };
  drop(v64_23);
  let v64_815: Space = if (&(v64_24)).is_empty() { Space::new() } else {
    let v70_29: Space = if (&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p2)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p2))),&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p0))))
    };
    let v70_30: Path = concat_path(&(*p2),&(*p0));
    let v70_31: Space = singleton(&(v70_30));
    drop(v70_30);
    let v70_32: Space = subtract(&(v70_29),&(v70_31));
    drop(v70_29);
    let v70_35: Space = intersect(&(v70_32),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
    drop(v70_32);
    let v70_36: Space = routine_17(c, &((v70_35).read_zipper()));
    drop(v70_35);
    let mut v70_37 = Space::new();
    let mut v70_37_write = v70_37.write_zipper();
    let mut v70_37_cursor = (v70_36).read_zipper();
    let v70_37_origin = v70_37_cursor.path().len();
    for v70_37_byte in v70_37_cursor.child_mask().iter() {
      v70_37_cursor.descend_to_existing_byte(v70_37_byte);
      {
      let v72_2: Space = routine_18(c, &v70_37_cursor.path()[v70_37_origin..(v70_37_origin + 1)], &v70_37_cursor.path()[v70_37_origin..(v70_37_origin + 1)], &v70_37_cursor);
      join_wrapped_into(&mut v70_37_write,&((v72_2).read_zipper()),&[]);
      }
      v70_37_cursor.ascend(1);
    }
    drop(v70_37_cursor);
    drop(v70_37_write);
    let v70_42: Space = if (&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p2)))).is_empty() { Space::new() } else {
      compose(&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p2))),&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p0))))
    };
    let v70_43: Space = subtract(&(v70_42),&(v70_31));
    drop(v70_42);
    let v70_44: Space = intersect(&(v70_43),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
    drop(v70_43);
    let v70_45: Space = routine_12(c, &((v70_44).read_zipper()));
    drop(v70_44);
    let mut v70_46 = Space::new();
    let mut v70_46_write = v70_46.write_zipper();
    let mut v70_46_cursor = (v70_45).read_zipper();
    let v70_46_origin = v70_46_cursor.path().len();
    for v70_46_byte in v70_46_cursor.child_mask().iter() {
      v70_46_cursor.descend_to_existing_byte(v70_46_byte);
      {
      let v74_2: Space = routine_19(c, &v70_46_cursor.path()[v70_46_origin..(v70_46_origin + 1)], &v70_46_cursor.path()[v70_46_origin..(v70_46_origin + 1)], &v70_46_cursor);
      join_wrapped_into(&mut v70_46_write,&((v74_2).read_zipper()),&[]);
      }
      v70_46_cursor.ascend(1);
    }
    drop(v70_46_cursor);
    drop(v70_46_write);
    let v70_47: Space = subtract(&(v70_37),&(v70_46));
    let v70_48: Space = if (&(v70_47)).is_empty() { Space::new() } else {
      compose(&(v70_47),&(v70_31))
    };
    drop(v70_31);
    let v70_814: Space = drop_length_prefixes(&(v70_48));
    compose(&(v64_24),&(v70_814))
  };
  drop(v64_24);
  let v64_816: Space = unite(&(v64_21),&(v64_815));
  (v64_816).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v76_6: Space = singleton(&(*p0));
  let v76_7: Space = intersect(&(*CONSTANT_7),&(v76_6));
  let v76_8: Space = if has_head(&(v76_7)) { singleton(&[]) } else { Space::new() };
  drop(v76_7);
  let v76_9: Space = subtract(&(*CONSTANT_6),&(v76_8));
  drop(v76_8);
  let v76_14: Space = intersect(&(*CONSTANT_7),&(v76_6));
  drop(v76_6);
  let v76_15: Space = if has_head(&(v76_14)) { singleton(&[]) } else { Space::new() };
  drop(v76_14);
  let mut v76_20 = Space::new();
  let mut v76_20_write = v76_20.write_zipper();
  let mut v76_20_cursor = (*s0).read_zipper();
  let v76_20_origin = v76_20_cursor.path().len();
  for v76_20_byte in v76_20_cursor.child_mask().iter() {
    v76_20_cursor.descend_to_existing_byte(v76_20_byte);
    {
    let v77_4: Space = if (&(v76_9)).is_empty() { Space::new() } else {
      let v78_2: Path = concat_path(&(*p1),&v76_20_cursor.path()[v76_20_origin..(v76_20_origin + 1)]);
      let mut v78_3 = Space::new();
      let mut v78_3_write = v78_3.write_zipper();
      let v78_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v78_3_arg_1: &[u8] = &(v78_2);
      let v78_3_arg_2: &[u8] = &(*p2);
      let v78_3_arg_4: &Space = &(&v76_20_cursor).make_map();
      let mut v78_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v78_3_origin = v78_3_cursor.path().len();
      let mut v78_3_more = v78_3_cursor.is_val() || next_value_within(&mut v78_3_cursor,v78_3_origin);
      while v78_3_more {
        {
        let v78_3_depth = v78_3_cursor.path().len();
        let v79_5: Space = routine_10(c, &v78_3_cursor.path()[v78_3_origin..v78_3_depth], &(*v78_3_arg_1), &(*v78_3_arg_2), &((*v78_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v78_3_write,&((v79_5).read_zipper()),&[]);
        }
        v78_3_more = next_value_within(&mut v78_3_cursor,v78_3_origin);
      }
      drop(v78_3_cursor);
      drop(v78_3_write);
      compose(&(v76_9),&(v78_3))
    };
    let v77_10: Space = if (&(v76_15)).is_empty() { Space::new() } else {
      let v80_2: Path = concat_path(&(*p1),&v76_20_cursor.path()[v76_20_origin..(v76_20_origin + 1)]);
      let v80_6: Space = if (&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p2)))).is_empty() { Space::new() } else {
        compose(&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p2))),&(descend_cursor(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1)),&v76_20_cursor.path()[v76_20_origin..(v76_20_origin + 1)])))
      };
      let v80_7: Path = concat_path(&(*p2),&(v80_2));
      drop(v80_2);
      let v80_8: Space = singleton(&(v80_7));
      drop(v80_7);
      let v80_9: Space = subtract(&(v80_6),&(v80_8));
      drop(v80_6);
      drop(v80_8);
      compose(&(v76_15),&(v80_9))
    };
    let v77_11: Space = unite(&(v77_4),&(v77_10));
    drop(v77_10);
    join_wrapped_into(&mut v76_20_write,&((v77_11).read_zipper()),&[]);
    }
    v76_20_cursor.ascend(1);
  }
  drop(v76_20_cursor);
  drop(v76_20_write);
  drop(v76_9);
  drop(v76_15);
  (v76_20).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v82_7: Space = singleton(&(*p0));
  let v82_8: Space = intersect(&(*CONSTANT_7),&(v82_7));
  let v82_9: Space = if has_head(&(v82_8)) { singleton(&[]) } else { Space::new() };
  drop(v82_8);
  let v82_10: Space = subtract(&(*CONSTANT_6),&(v82_9));
  drop(v82_9);
  let v82_15: Space = intersect(&(*CONSTANT_7),&(v82_7));
  drop(v82_7);
  let v82_16: Space = if has_head(&(v82_15)) { singleton(&[]) } else { Space::new() };
  drop(v82_15);
  let mut v82_17 = Space::new();
  let mut v82_17_write = v82_17.write_zipper();
  let mut v82_17_cursor = (*s0).read_zipper();
  let v82_17_origin = v82_17_cursor.path().len();
  for v82_17_byte in v82_17_cursor.child_mask().iter() {
    v82_17_cursor.descend_to_existing_byte(v82_17_byte);
    {
    let v83_4: Space = if (&(v82_10)).is_empty() { Space::new() } else {
      let v84_2: Path = concat_path(&(*p1),&v82_17_cursor.path()[v82_17_origin..(v82_17_origin + 1)]);
      let mut v84_3 = Space::new();
      let mut v84_3_write = v84_3.write_zipper();
      let v84_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v84_3_arg_1: &[u8] = &(v84_2);
      let v84_3_arg_2: &[u8] = &(*p2);
      let v84_3_arg_4: &Space = &(&v82_17_cursor).make_map();
      let v84_3_arg_5: &Space = &(&(*s1)).make_map();
      let mut v84_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v84_3_origin = v84_3_cursor.path().len();
      let mut v84_3_more = v84_3_cursor.is_val() || next_value_within(&mut v84_3_cursor,v84_3_origin);
      while v84_3_more {
        {
        let v84_3_depth = v84_3_cursor.path().len();
        let v85_6: Space = routine_11(c, &v84_3_cursor.path()[v84_3_origin..v84_3_depth], &(*v84_3_arg_1), &(*v84_3_arg_2), &((*v84_3_arg_4).read_zipper()), &((*v84_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v84_3_write,&((v85_6).read_zipper()),&[]);
        }
        v84_3_more = next_value_within(&mut v84_3_cursor,v84_3_origin);
      }
      drop(v84_3_cursor);
      drop(v84_3_write);
      compose(&(v82_10),&(v84_3))
    };
    let v83_6: Space = if (&(v82_16)).is_empty() { Space::new() } else {
      let v86_2: Path = concat_path(&(*p1),&v82_17_cursor.path()[v82_17_origin..(v82_17_origin + 1)]);
      let v86_5: Space = routine_20(c, &(v86_2), &(*p2), &v82_17_cursor, &(*s1));
      drop(v86_2);
      compose(&(v82_16),&(v86_5))
    };
    let v83_7: Space = unite(&(v83_4),&(v83_6));
    join_wrapped_into(&mut v82_17_write,&((v83_7).read_zipper()),&[]);
    }
    v82_17_cursor.ascend(1);
  }
  drop(v82_17_cursor);
  drop(v82_17_write);
  drop(v82_10);
  drop(v82_16);
  (v82_17).clone()
}

fn routine_12(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v87_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v87_2: Space = first_matching(&(*s0),&(*CONSTANT_6),false);
  let v87_3: Space = unite(&(v87_1),&(v87_2));
  drop(v87_1);
  drop(v87_2);
  let v87_8: Space = if (&(v87_3)).is_empty() { Space::new() } else {
    let v88_6: Space = if (&(v87_3)).is_empty() { Space::new() } else {
      let v89_4: Space = routine_21(c, &(*s0));
      let v89_5: Space = subtract(&(*s0),&(v89_4));
      compose(&(v87_3),&(v89_5))
    };
    let v88_7: Space = routine_22(c, &((v88_6).read_zipper()));
    compose(&(v87_3),&(v88_7))
  };
  drop(v87_3);
  let v90_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v90_2: Space = first_matching(&(*s0),&(*CONSTANT_6),false);
  let v90_3: Space = unite(&(v90_1),&(v90_2));
  drop(v90_1);
  drop(v90_2);
  let v90_6: Space = if (&(v90_3)).is_empty() { Space::new() } else {
    let v91_4: Space = routine_21(c, &(*s0));
    let v91_5: Space = subtract(&(*s0),&(v91_4));
    compose(&(v90_3),&(v91_5))
  };
  let v87_9: Space = if has_head(&(v90_6)) { singleton(&[]) } else { Space::new() };
  let v87_10: Space = first_matching(&(v90_6),&(*CONSTANT_6),false);
  let v87_11: Space = unite(&(v87_9),&(v87_10));
  let v87_13: Space = if (&(v87_11)).is_empty() { Space::new() } else {
    let v92_7: Space = routine_22(c, &((v90_6).read_zipper()));
    let v92_12: Space = routine_22(c, &((v92_7).read_zipper()));
    compose(&(v87_11),&(v92_12))
  };
  let v87_14: Space = subtract(&(*s0),&(v87_13));
  let v87_15: Space = intersect(&(v87_8),&(v87_14));
  (v87_15).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v93_5: Space = singleton(&(*p1));
  let v93_6: Space = intersect(&(*CONSTANT_7),&(v93_5));
  let v93_7: Space = if has_head(&(v93_6)) { singleton(&[]) } else { Space::new() };
  drop(v93_6);
  let v93_8: Space = subtract(&(*CONSTANT_6),&(v93_7));
  drop(v93_7);
  let v93_19: Space = if (&(v93_8)).is_empty() { Space::new() } else {
    let v94_11: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v94_14: Space = if (&(v94_11)).is_empty() { Space::new() } else {
      let v95_13: Space = routine_23(c, &(*CONSTANT_9), &(*p0), &(*s0));
      compose(&(v94_11),&(v95_13))
    };
    drop(v94_11);
    let mut v94_17 = Space::new();
    let mut v94_17_write = v94_17.write_zipper();
    let mut v94_17_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v94_17_origin = v94_17_cursor.path().len();
    for v94_17_byte in v94_17_cursor.child_mask().iter() {
      v94_17_cursor.descend_to_existing_byte(v94_17_byte);
      {
      let v96_2_arg_0: &[u8] = &v94_17_cursor.path()[v94_17_origin..(v94_17_origin + 1)];
      let v96_2_arg_1: &[u8] = &(*p0);
      let v96_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v96_2_more = v94_17_cursor.is_val() || next_value_within(&mut v94_17_cursor,(v94_17_origin + 1));
      while v96_2_more {
        {
        let v96_2_depth = v94_17_cursor.path().len();
        let mut v97_4_cursor = (*v96_2_arg_3).read_zipper();
        let v97_4_origin = v97_4_cursor.path().len();
        for v97_4_byte in v97_4_cursor.child_mask().iter() {
          v97_4_cursor.descend_to_existing_byte(v97_4_byte);
          {
          let v98_2: Path = concat_path(&(*v96_2_arg_1),&v97_4_cursor.path()[v97_4_origin..(v97_4_origin + 1)]);
          let v98_3: Space = routine_13(c, &(v98_2), &v94_17_cursor.path()[v94_17_origin..v96_2_depth], &v97_4_cursor);
          drop(v98_2);
          join_wrapped_into(&mut v94_17_write,&((v98_3).read_zipper()),&[]);
          }
          v97_4_cursor.ascend(1);
        }
        drop(v97_4_cursor);
        }
        v96_2_more = next_value_within(&mut v94_17_cursor,(v94_17_origin + 1));
      }
      }
      v94_17_cursor.ascend(1);
    }
    drop(v94_17_cursor);
    drop(v94_17_write);
    let v94_18: Space = unite(&(v94_14),&(v94_17));
    compose(&(v93_8),&(v94_18))
  };
  drop(v93_8);
  let v93_21: Space = intersect(&(*CONSTANT_7),&(v93_5));
  drop(v93_5);
  let v93_22: Space = if has_head(&(v93_21)) { singleton(&[]) } else { Space::new() };
  drop(v93_21);
  let v93_24: Space = compose(&(v93_22),&(*CONSTANT_11));
  drop(v93_22);
  let v93_25: Space = unite(&(v93_19),&(v93_24));
  drop(v93_24);
  (v93_25).clone()
}

fn routine_14(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v99_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v99_2: Space = first_matching(&(*s0),&(*CONSTANT_6),false);
  let v99_3: Space = unite(&(v99_1),&(v99_2));
  drop(v99_1);
  drop(v99_2);
  let v99_6: Space = if (&(v99_3)).is_empty() { Space::new() } else {
    let v100_4: Space = routine_21(c, &(*s0));
    let v100_5: Space = subtract(&(*s0),&(v100_4));
    compose(&(v99_3),&(v100_5))
  };
  let v99_7: Space = if has_head(&(v99_6)) { singleton(&[]) } else { Space::new() };
  let v99_8: Space = first_matching(&(v99_6),&(*CONSTANT_6),false);
  let v99_9: Space = unite(&(v99_7),&(v99_8));
  let v99_12: Space = if (&(v99_9)).is_empty() { Space::new() } else {
    let v101_10: Space = routine_22(c, &((v99_6).read_zipper()));
    let v101_11: Space = routine_22(c, &((v101_10).read_zipper()));
    compose(&(v99_9),&(v101_11))
  };
  let v99_17: Space = if (&(v99_3)).is_empty() { Space::new() } else {
    let v102_15: Space = if (&(v99_3)).is_empty() { Space::new() } else {
      let v103_13: Space = routine_22(c, &(*s0));
      let v103_14: Space = routine_22(c, &((v103_13).read_zipper()));
      compose(&(v99_3),&(v103_14))
    };
    let v102_16: Space = routine_24(c, &((v102_15).read_zipper()));
    compose(&(v99_3),&(v102_16))
  };
  drop(v99_3);
  let v99_18: Space = subtract(&(*s0),&(v99_17));
  let v99_19: Space = intersect(&(v99_12),&(v99_18));
  (v99_19).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v104_5: Space = singleton(&(*p1));
  let v104_6: Space = intersect(&(*CONSTANT_7),&(v104_5));
  let v104_7: Space = if has_head(&(v104_6)) { singleton(&[]) } else { Space::new() };
  drop(v104_6);
  let v104_8: Space = subtract(&(*CONSTANT_6),&(v104_7));
  drop(v104_7);
  let v104_19: Space = if (&(v104_8)).is_empty() { Space::new() } else {
    let v105_11: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v105_14: Space = if (&(v105_11)).is_empty() { Space::new() } else {
      let v106_13: Space = routine_25(c, &(*CONSTANT_9), &(*p0), &(*s0));
      compose(&(v105_11),&(v106_13))
    };
    drop(v105_11);
    let mut v105_17 = Space::new();
    let mut v105_17_write = v105_17.write_zipper();
    let mut v105_17_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v105_17_origin = v105_17_cursor.path().len();
    for v105_17_byte in v105_17_cursor.child_mask().iter() {
      v105_17_cursor.descend_to_existing_byte(v105_17_byte);
      {
      let v107_2_arg_0: &[u8] = &v105_17_cursor.path()[v105_17_origin..(v105_17_origin + 1)];
      let v107_2_arg_1: &[u8] = &(*p0);
      let v107_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v107_2_more = v105_17_cursor.is_val() || next_value_within(&mut v105_17_cursor,(v105_17_origin + 1));
      while v107_2_more {
        {
        let v107_2_depth = v105_17_cursor.path().len();
        let mut v108_4_cursor = (*v107_2_arg_3).read_zipper();
        let v108_4_origin = v108_4_cursor.path().len();
        for v108_4_byte in v108_4_cursor.child_mask().iter() {
          v108_4_cursor.descend_to_existing_byte(v108_4_byte);
          {
          let v109_2: Path = concat_path(&(*v107_2_arg_1),&v108_4_cursor.path()[v108_4_origin..(v108_4_origin + 1)]);
          let v109_3: Space = routine_15(c, &(v109_2), &v105_17_cursor.path()[v105_17_origin..v107_2_depth], &v108_4_cursor);
          drop(v109_2);
          join_wrapped_into(&mut v105_17_write,&((v109_3).read_zipper()),&[]);
          }
          v108_4_cursor.ascend(1);
        }
        drop(v108_4_cursor);
        }
        v107_2_more = next_value_within(&mut v105_17_cursor,(v105_17_origin + 1));
      }
      }
      v105_17_cursor.ascend(1);
    }
    drop(v105_17_cursor);
    drop(v105_17_write);
    let v105_18: Space = unite(&(v105_14),&(v105_17));
    compose(&(v104_8),&(v105_18))
  };
  drop(v104_8);
  let v104_21: Space = intersect(&(*CONSTANT_7),&(v104_5));
  drop(v104_5);
  let v104_22: Space = if has_head(&(v104_21)) { singleton(&[]) } else { Space::new() };
  drop(v104_21);
  let v104_24: Space = compose(&(v104_22),&(*CONSTANT_11));
  drop(v104_22);
  let v104_25: Space = unite(&(v104_19),&(v104_24));
  drop(v104_24);
  (v104_25).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v110_7: Space = singleton(&(*p0));
  let v110_8: Space = intersect(&(*CONSTANT_7),&(v110_7));
  let v110_9: Space = if has_head(&(v110_8)) { singleton(&[]) } else { Space::new() };
  drop(v110_8);
  let v110_10: Space = subtract(&(*CONSTANT_6),&(v110_9));
  drop(v110_9);
  let v110_15: Space = intersect(&(*CONSTANT_7),&(v110_7));
  drop(v110_7);
  let v110_16: Space = if has_head(&(v110_15)) { singleton(&[]) } else { Space::new() };
  drop(v110_15);
  let mut v110_17 = Space::new();
  let mut v110_17_write = v110_17.write_zipper();
  let mut v110_17_cursor = (*s0).read_zipper();
  let v110_17_origin = v110_17_cursor.path().len();
  for v110_17_byte in v110_17_cursor.child_mask().iter() {
    v110_17_cursor.descend_to_existing_byte(v110_17_byte);
    {
    let v111_4: Space = if (&(v110_10)).is_empty() { Space::new() } else {
      let v112_2: Path = concat_path(&(*p1),&v110_17_cursor.path()[v110_17_origin..(v110_17_origin + 1)]);
      let mut v112_3 = Space::new();
      let mut v112_3_write = v112_3.write_zipper();
      let v112_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v112_3_arg_1: &[u8] = &(v112_2);
      let v112_3_arg_2: &[u8] = &(*p2);
      let v112_3_arg_4: &Space = &(&v110_17_cursor).make_map();
      let v112_3_arg_5: &Space = &(&(*s1)).make_map();
      let mut v112_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v112_3_origin = v112_3_cursor.path().len();
      let mut v112_3_more = v112_3_cursor.is_val() || next_value_within(&mut v112_3_cursor,v112_3_origin);
      while v112_3_more {
        {
        let v112_3_depth = v112_3_cursor.path().len();
        let v113_6: Space = routine_16(c, &v112_3_cursor.path()[v112_3_origin..v112_3_depth], &(*v112_3_arg_1), &(*v112_3_arg_2), &((*v112_3_arg_4).read_zipper()), &((*v112_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v112_3_write,&((v113_6).read_zipper()),&[]);
        }
        v112_3_more = next_value_within(&mut v112_3_cursor,v112_3_origin);
      }
      drop(v112_3_cursor);
      drop(v112_3_write);
      compose(&(v110_10),&(v112_3))
    };
    let v111_6: Space = if (&(v110_16)).is_empty() { Space::new() } else {
      let v114_2: Path = concat_path(&(*p1),&v110_17_cursor.path()[v110_17_origin..(v110_17_origin + 1)]);
      let v114_5: Space = routine_26(c, &(v114_2), &(*p2), &v110_17_cursor, &(*s1));
      drop(v114_2);
      compose(&(v110_16),&(v114_5))
    };
    let v111_7: Space = unite(&(v111_4),&(v111_6));
    join_wrapped_into(&mut v110_17_write,&((v111_7).read_zipper()),&[]);
    }
    v110_17_cursor.ascend(1);
  }
  drop(v110_17_cursor);
  drop(v110_17_write);
  drop(v110_10);
  drop(v110_16);
  (v110_17).clone()
}

fn routine_17(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v115_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v115_2: Space = first_matching(&(*s0),&(*CONSTANT_6),false);
  let v115_3: Space = unite(&(v115_1),&(v115_2));
  drop(v115_1);
  drop(v115_2);
  let v115_8: Space = if (&(v115_3)).is_empty() { Space::new() } else {
    let v116_6: Space = if (&(v115_3)).is_empty() { Space::new() } else {
      let v117_4: Space = routine_21(c, &(*s0));
      let v117_5: Space = subtract(&(*s0),&(v117_4));
      compose(&(v115_3),&(v117_5))
    };
    let v116_7: Space = routine_22(c, &((v116_6).read_zipper()));
    compose(&(v115_3),&(v116_7))
  };
  drop(v115_3);
  let v115_9: Space = subtract(&(*s0),&(v115_8));
  let v118_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v118_2: Space = first_matching(&(*s0),&(*CONSTANT_6),false);
  let v118_3: Space = unite(&(v118_1),&(v118_2));
  drop(v118_1);
  drop(v118_2);
  let v118_6: Space = if (&(v118_3)).is_empty() { Space::new() } else {
    let v119_4: Space = routine_21(c, &(*s0));
    let v119_5: Space = subtract(&(*s0),&(v119_4));
    compose(&(v118_3),&(v119_5))
  };
  let v115_10: Space = intersect(&(v118_6),&(v115_9));
  (v115_10).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v120_5: Space = singleton(&(*p1));
  let v120_6: Space = intersect(&(*CONSTANT_7),&(v120_5));
  let v120_7: Space = if has_head(&(v120_6)) { singleton(&[]) } else { Space::new() };
  drop(v120_6);
  let v120_8: Space = subtract(&(*CONSTANT_6),&(v120_7));
  drop(v120_7);
  let v120_19: Space = if (&(v120_8)).is_empty() { Space::new() } else {
    let v121_11: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v121_14: Space = if (&(v121_11)).is_empty() { Space::new() } else {
      let v122_13: Space = routine_27(c, &(*CONSTANT_9), &(*p0), &(*s0));
      compose(&(v121_11),&(v122_13))
    };
    drop(v121_11);
    let mut v121_17 = Space::new();
    let mut v121_17_write = v121_17.write_zipper();
    let mut v121_17_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v121_17_origin = v121_17_cursor.path().len();
    for v121_17_byte in v121_17_cursor.child_mask().iter() {
      v121_17_cursor.descend_to_existing_byte(v121_17_byte);
      {
      let v123_2_arg_0: &[u8] = &v121_17_cursor.path()[v121_17_origin..(v121_17_origin + 1)];
      let v123_2_arg_1: &[u8] = &(*p0);
      let v123_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v123_2_more = v121_17_cursor.is_val() || next_value_within(&mut v121_17_cursor,(v121_17_origin + 1));
      while v123_2_more {
        {
        let v123_2_depth = v121_17_cursor.path().len();
        let mut v124_4_cursor = (*v123_2_arg_3).read_zipper();
        let v124_4_origin = v124_4_cursor.path().len();
        for v124_4_byte in v124_4_cursor.child_mask().iter() {
          v124_4_cursor.descend_to_existing_byte(v124_4_byte);
          {
          let v125_2: Path = concat_path(&(*v123_2_arg_1),&v124_4_cursor.path()[v124_4_origin..(v124_4_origin + 1)]);
          let v125_3: Space = routine_18(c, &(v125_2), &v121_17_cursor.path()[v121_17_origin..v123_2_depth], &v124_4_cursor);
          drop(v125_2);
          join_wrapped_into(&mut v121_17_write,&((v125_3).read_zipper()),&[]);
          }
          v124_4_cursor.ascend(1);
        }
        drop(v124_4_cursor);
        }
        v123_2_more = next_value_within(&mut v121_17_cursor,(v121_17_origin + 1));
      }
      }
      v121_17_cursor.ascend(1);
    }
    drop(v121_17_cursor);
    drop(v121_17_write);
    let v121_18: Space = unite(&(v121_14),&(v121_17));
    compose(&(v120_8),&(v121_18))
  };
  drop(v120_8);
  let v120_21: Space = intersect(&(*CONSTANT_7),&(v120_5));
  drop(v120_5);
  let v120_22: Space = if has_head(&(v120_21)) { singleton(&[]) } else { Space::new() };
  drop(v120_21);
  let v120_24: Space = compose(&(v120_22),&(*CONSTANT_11));
  drop(v120_22);
  let v120_25: Space = unite(&(v120_19),&(v120_24));
  drop(v120_24);
  (v120_25).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v126_5: Space = singleton(&(*p1));
  let v126_6: Space = intersect(&(*CONSTANT_7),&(v126_5));
  let v126_7: Space = if has_head(&(v126_6)) { singleton(&[]) } else { Space::new() };
  drop(v126_6);
  let v126_8: Space = subtract(&(*CONSTANT_6),&(v126_7));
  drop(v126_7);
  let v126_19: Space = if (&(v126_8)).is_empty() { Space::new() } else {
    let v127_11: Space = first_matching(&(descend_cursor((*CONSTANT_8).read_zipper(),&(*p1))),&(*CONSTANT_6),false);
    let v127_14: Space = if (&(v127_11)).is_empty() { Space::new() } else {
      let v128_13: Space = routine_28(c, &(*CONSTANT_9), &(*p0), &(*s0));
      compose(&(v127_11),&(v128_13))
    };
    drop(v127_11);
    let mut v127_17 = Space::new();
    let mut v127_17_write = v127_17.write_zipper();
    let mut v127_17_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p1));
    let v127_17_origin = v127_17_cursor.path().len();
    for v127_17_byte in v127_17_cursor.child_mask().iter() {
      v127_17_cursor.descend_to_existing_byte(v127_17_byte);
      {
      let v129_2_arg_0: &[u8] = &v127_17_cursor.path()[v127_17_origin..(v127_17_origin + 1)];
      let v129_2_arg_1: &[u8] = &(*p0);
      let v129_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v129_2_more = v127_17_cursor.is_val() || next_value_within(&mut v127_17_cursor,(v127_17_origin + 1));
      while v129_2_more {
        {
        let v129_2_depth = v127_17_cursor.path().len();
        let mut v130_4_cursor = (*v129_2_arg_3).read_zipper();
        let v130_4_origin = v130_4_cursor.path().len();
        for v130_4_byte in v130_4_cursor.child_mask().iter() {
          v130_4_cursor.descend_to_existing_byte(v130_4_byte);
          {
          let v131_2: Path = concat_path(&(*v129_2_arg_1),&v130_4_cursor.path()[v130_4_origin..(v130_4_origin + 1)]);
          let v131_3: Space = routine_19(c, &(v131_2), &v127_17_cursor.path()[v127_17_origin..v129_2_depth], &v130_4_cursor);
          drop(v131_2);
          join_wrapped_into(&mut v127_17_write,&((v131_3).read_zipper()),&[]);
          }
          v130_4_cursor.ascend(1);
        }
        drop(v130_4_cursor);
        }
        v129_2_more = next_value_within(&mut v127_17_cursor,(v127_17_origin + 1));
      }
      }
      v127_17_cursor.ascend(1);
    }
    drop(v127_17_cursor);
    drop(v127_17_write);
    let v127_18: Space = unite(&(v127_14),&(v127_17));
    compose(&(v126_8),&(v127_18))
  };
  drop(v126_8);
  let v126_21: Space = intersect(&(*CONSTANT_7),&(v126_5));
  drop(v126_5);
  let v126_22: Space = if has_head(&(v126_21)) { singleton(&[]) } else { Space::new() };
  drop(v126_21);
  let v126_24: Space = compose(&(v126_22),&(*CONSTANT_11));
  drop(v126_22);
  let v126_25: Space = unite(&(v126_19),&(v126_24));
  drop(v126_24);
  (v126_25).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v132_8: Space = if (&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1))),&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p0))))
  };
  let v132_9: Path = concat_path(&(*p1),&(*p0));
  let v132_10: Space = singleton(&(v132_9));
  drop(v132_9);
  let v132_11: Space = subtract(&(v132_8),&(v132_10));
  drop(v132_8);
  let v132_14: Space = intersect(&(v132_11),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
  drop(v132_11);
  let v132_19: Space = if (&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1))),&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p0))))
  };
  let v132_20: Space = subtract(&(v132_19),&(v132_10));
  drop(v132_19);
  let v132_21: Space = intersect(&(v132_20),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
  drop(v132_20);
  let v132_22: Space = routine_22(c, &((v132_21).read_zipper()));
  drop(v132_21);
  let v132_23: Space = routine_24(c, &((v132_22).read_zipper()));
  let v132_24: Space = subtract(&(v132_14),&(v132_23));
  drop(v132_14);
  let v132_29: Space = if (&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1))),&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p0))))
  };
  let v132_30: Space = subtract(&(v132_29),&(v132_10));
  drop(v132_29);
  let v132_31: Space = intersect(&(v132_30),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
  drop(v132_30);
  let v132_32: Space = routine_24(c, &((v132_31).read_zipper()));
  drop(v132_31);
  let v132_33: Space = intersect(&(v132_24),&(v132_32));
  let mut v132_39 = Space::new();
  let mut v132_39_write = v132_39.write_zipper();
  let mut v132_39_cursor = (v132_33).read_zipper();
  let v132_39_origin = v132_39_cursor.path().len();
  for v132_39_byte in v132_39_cursor.child_mask().iter() {
    v132_39_cursor.descend_to_existing_byte(v132_39_byte);
    {
    let v136_2: Space = singleton(&v132_39_cursor.path()[v132_39_origin..(v132_39_origin + 1)]);
    let v136_3: Space = intersect(&(*CONSTANT_7),&(v136_2));
    let v136_4: Space = if has_head(&(v136_3)) { singleton(&[]) } else { Space::new() };
    drop(v136_3);
    let v136_5: Space = subtract(&(*CONSTANT_6),&(v136_4));
    drop(v136_4);
    let v136_8: Space = if (&(v136_5)).is_empty() { Space::new() } else {
      let mut v137_7 = Space::new();
      let mut v137_7_write = v137_7.write_zipper();
      let v137_7_arg_0: &[u8] = &(*CONSTANT_9);
      let v137_7_arg_1: &[u8] = &v132_39_cursor.path()[v132_39_origin..(v132_39_origin + 1)];
      let v137_7_arg_3: &Space = &(&v132_39_cursor).make_map();
      let mut v137_7_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&v132_39_cursor.path()[v132_39_origin..(v132_39_origin + 1)]);
      let v137_7_origin = v137_7_cursor.path().len();
      let mut v137_7_more = v137_7_cursor.is_val() || next_value_within(&mut v137_7_cursor,v137_7_origin);
      while v137_7_more {
        {
        let v137_7_depth = v137_7_cursor.path().len();
        let mut v138_4_cursor = (*v137_7_arg_3).read_zipper();
        let v138_4_origin = v138_4_cursor.path().len();
        for v138_4_byte in v138_4_cursor.child_mask().iter() {
          v138_4_cursor.descend_to_existing_byte(v138_4_byte);
          {
          let v139_2: Path = concat_path(&(*v137_7_arg_1),&v138_4_cursor.path()[v138_4_origin..(v138_4_origin + 1)]);
          let v139_3: Space = routine_13(c, &(v139_2), &v137_7_cursor.path()[v137_7_origin..v137_7_depth], &v138_4_cursor);
          drop(v139_2);
          join_wrapped_into(&mut v137_7_write,&((v139_3).read_zipper()),&[]);
          }
          v138_4_cursor.ascend(1);
        }
        drop(v138_4_cursor);
        }
        v137_7_more = next_value_within(&mut v137_7_cursor,v137_7_origin);
      }
      drop(v137_7_cursor);
      drop(v137_7_write);
      compose(&(v136_5),&(v137_7))
    };
    drop(v136_5);
    let v136_9: Space = intersect(&(*CONSTANT_7),&(v136_2));
    drop(v136_2);
    let v136_10: Space = if has_head(&(v136_9)) { singleton(&[]) } else { Space::new() };
    drop(v136_9);
    let v136_12: Space = if (&(v136_10)).is_empty() { Space::new() } else {
      let v140_11: Space = routine_29(c, &v132_39_cursor.path()[v132_39_origin..(v132_39_origin + 1)], &v132_39_cursor);
      compose(&(v136_10),&(v140_11))
    };
    drop(v136_10);
    let v136_13: Space = unite(&(v136_8),&(v136_12));
    join_wrapped_into(&mut v132_39_write,&((v136_13).read_zipper()),&[]);
    }
    v132_39_cursor.ascend(1);
  }
  drop(v132_39_cursor);
  drop(v132_39_write);
  let v132_44: Space = if (&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1))),&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p0))))
  };
  let v132_45: Space = subtract(&(v132_44),&(v132_10));
  drop(v132_44);
  let v132_46: Space = intersect(&(v132_45),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
  drop(v132_45);
  let v132_51: Space = if (&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1))),&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p0))))
  };
  let v132_52: Space = subtract(&(v132_51),&(v132_10));
  drop(v132_51);
  let v132_53: Space = intersect(&(v132_52),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
  drop(v132_52);
  let v132_54: Space = routine_30(c, &((v132_53).read_zipper()));
  drop(v132_53);
  let v132_55: Space = subtract(&(v132_46),&(v132_54));
  drop(v132_46);
  let v132_60: Space = if (&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1))),&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p0))))
  };
  let v132_61: Space = subtract(&(v132_60),&(v132_10));
  drop(v132_60);
  let v132_62: Space = intersect(&(v132_61),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
  drop(v132_61);
  let v132_63: Space = routine_22(c, &((v132_62).read_zipper()));
  drop(v132_62);
  let v132_64: Space = routine_24(c, &((v132_63).read_zipper()));
  let v132_65: Space = intersect(&(v132_55),&(v132_64));
  let mut v132_70 = Space::new();
  let mut v132_70_write = v132_70.write_zipper();
  let mut v132_70_cursor = (v132_65).read_zipper();
  let v132_70_origin = v132_70_cursor.path().len();
  for v132_70_byte in v132_70_cursor.child_mask().iter() {
    v132_70_cursor.descend_to_existing_byte(v132_70_byte);
    {
    let v144_2: Space = singleton(&v132_70_cursor.path()[v132_70_origin..(v132_70_origin + 1)]);
    let v144_3: Space = intersect(&(*CONSTANT_7),&(v144_2));
    let v144_4: Space = if has_head(&(v144_3)) { singleton(&[]) } else { Space::new() };
    drop(v144_3);
    let v144_5: Space = subtract(&(*CONSTANT_6),&(v144_4));
    drop(v144_4);
    let v144_8: Space = if (&(v144_5)).is_empty() { Space::new() } else {
      let mut v145_7 = Space::new();
      let mut v145_7_write = v145_7.write_zipper();
      let v145_7_arg_0: &[u8] = &(*CONSTANT_9);
      let v145_7_arg_1: &[u8] = &v132_70_cursor.path()[v132_70_origin..(v132_70_origin + 1)];
      let v145_7_arg_3: &Space = &(&v132_70_cursor).make_map();
      let mut v145_7_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&v132_70_cursor.path()[v132_70_origin..(v132_70_origin + 1)]);
      let v145_7_origin = v145_7_cursor.path().len();
      let mut v145_7_more = v145_7_cursor.is_val() || next_value_within(&mut v145_7_cursor,v145_7_origin);
      while v145_7_more {
        {
        let v145_7_depth = v145_7_cursor.path().len();
        let mut v146_4_cursor = (*v145_7_arg_3).read_zipper();
        let v146_4_origin = v146_4_cursor.path().len();
        for v146_4_byte in v146_4_cursor.child_mask().iter() {
          v146_4_cursor.descend_to_existing_byte(v146_4_byte);
          {
          let v147_2: Path = concat_path(&(*v145_7_arg_1),&v146_4_cursor.path()[v146_4_origin..(v146_4_origin + 1)]);
          let v147_3: Space = routine_15(c, &(v147_2), &v145_7_cursor.path()[v145_7_origin..v145_7_depth], &v146_4_cursor);
          drop(v147_2);
          join_wrapped_into(&mut v145_7_write,&((v147_3).read_zipper()),&[]);
          }
          v146_4_cursor.ascend(1);
        }
        drop(v146_4_cursor);
        }
        v145_7_more = next_value_within(&mut v145_7_cursor,v145_7_origin);
      }
      drop(v145_7_cursor);
      drop(v145_7_write);
      compose(&(v144_5),&(v145_7))
    };
    drop(v144_5);
    let v144_9: Space = intersect(&(*CONSTANT_7),&(v144_2));
    drop(v144_2);
    let v144_10: Space = if has_head(&(v144_9)) { singleton(&[]) } else { Space::new() };
    drop(v144_9);
    let v144_12: Space = if (&(v144_10)).is_empty() { Space::new() } else {
      let v148_11: Space = routine_31(c, &v132_70_cursor.path()[v132_70_origin..(v132_70_origin + 1)], &v132_70_cursor);
      compose(&(v144_10),&(v148_11))
    };
    drop(v144_10);
    let v144_13: Space = unite(&(v144_8),&(v144_12));
    join_wrapped_into(&mut v132_70_write,&((v144_13).read_zipper()),&[]);
    }
    v132_70_cursor.ascend(1);
  }
  drop(v132_70_cursor);
  drop(v132_70_write);
  let v132_71: Space = subtract(&(v132_39),&(v132_70));
  let v132_72: Space = if (&(v132_71)).is_empty() { Space::new() } else {
    compose(&(v132_71),&(v132_10))
  };
  drop(v132_10);
  let v132_838: Space = drop_length_prefixes(&(v132_72));
  (v132_838).clone()
}

fn routine_21(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v150_2: Space = first_matching(&(*s0),&(*CONSTANT_6),false);
  let v150_3: Space = intersect(&(*CONSTANT_6),&(v150_2));
  let v150_4: Space = if has_head(&(v150_2)) { singleton(&[]) } else { Space::new() };
  let v150_5: Space = unite(&(v150_3),&(v150_4));
  drop(v150_3);
  let v150_7: Space = compose(&(v150_5),&(*CONSTANT_6));
  drop(v150_5);
  let v150_9: Space = subtract(&(*CONSTANT_6),&(v150_2));
  drop(v150_2);
  let v150_10: Space = subtract(&(v150_9),&(v150_4));
  drop(v150_4);
  drop(v150_9);
  let v150_18: Space = if (&(v150_10)).is_empty() { Space::new() } else {
    let v151_11: Space = first_length_prefixed(&(*s0));
    let v151_12: Space = first_matching(&(v151_11),&(*CONSTANT_6),false);
    let v151_15: Space = if (&(v151_12)).is_empty() { Space::new() } else {
      let v152_14: Space = routine_32(c, &(*CONSTANT_9), &(*s0));
      compose(&(v151_12),&(v152_14))
    };
    drop(v151_12);
    let mut v151_16 = Space::new();
    let mut v151_16_write = v151_16.write_zipper();
    let mut v151_16_cursor = (v151_11).read_zipper();
    let v151_16_origin = v151_16_cursor.path().len();
    for v151_16_byte in v151_16_cursor.child_mask().iter() {
      v151_16_cursor.descend_to_existing_byte(v151_16_byte);
      {
      let v153_2_arg_0: &[u8] = &v151_16_cursor.path()[v151_16_origin..(v151_16_origin + 1)];
      let v153_2_arg_2: &Space = &(&(*s0)).make_map();
      let mut v153_2_more = v151_16_cursor.is_val() || next_value_within(&mut v151_16_cursor,(v151_16_origin + 1));
      while v153_2_more {
        {
        let v153_2_depth = v151_16_cursor.path().len();
        let v154_4: Space = routine_21(c, &(descend_cursor((*v153_2_arg_2).read_zipper(),&v151_16_cursor.path()[v151_16_origin..v153_2_depth])));
        join_wrapped_into(&mut v151_16_write,&((v154_4).read_zipper()),&v151_16_cursor.path()[v151_16_origin..v153_2_depth]);
        }
        v153_2_more = next_value_within(&mut v151_16_cursor,(v151_16_origin + 1));
      }
      }
      v151_16_cursor.ascend(1);
    }
    drop(v151_16_cursor);
    drop(v151_16_write);
    drop(v151_11);
    let v151_17: Space = unite(&(v151_15),&(v151_16));
    compose(&(v150_10),&(v151_17))
  };
  drop(v150_10);
  let v150_19: Space = unite(&(v150_7),&(v150_18));
  drop(v150_7);
  (v150_19).clone()
}

fn routine_22(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v155_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v155_2: Space = first_matching(&(*s0),&(*CONSTANT_6),false);
  let v155_3: Space = unite(&(v155_1),&(v155_2));
  drop(v155_1);
  let v155_19: Space = if (&(v155_3)).is_empty() { Space::new() } else {
    let v156_5: Space = intersect(&(*CONSTANT_6),&(v155_2));
    let v156_6: Space = if has_head(&(v155_2)) { singleton(&[]) } else { Space::new() };
    let v156_7: Space = unite(&(v156_5),&(v156_6));
    drop(v156_5);
    let v156_9: Space = compose(&(v156_7),&(*CONSTANT_6));
    drop(v156_7);
    let v156_10: Space = subtract(&(*s0),&(v156_9));
    drop(v156_9);
    let v156_12: Space = subtract(&(*CONSTANT_6),&(v155_2));
    let v156_13: Space = subtract(&(v156_12),&(v156_6));
    drop(v156_6);
    drop(v156_12);
    let v156_17: Space = if (&(v156_13)).is_empty() { Space::new() } else {
      let v157_15: Space = first_length_prefixed(&(*s0));
      let mut v157_16 = Space::new();
      let mut v157_16_write = v157_16.write_zipper();
      let v157_16_arg_0: &[u8] = &(*CONSTANT_9);
      let v157_16_arg_2: &Space = &(&(*s0)).make_map();
      let mut v157_16_cursor = (v157_15).read_zipper();
      let v157_16_origin = v157_16_cursor.path().len();
      let mut v157_16_more = v157_16_cursor.is_val() || next_value_within(&mut v157_16_cursor,v157_16_origin);
      while v157_16_more {
        {
        let v157_16_depth = v157_16_cursor.path().len();
        let v158_4: Space = routine_21(c, &(descend_cursor((*v157_16_arg_2).read_zipper(),&v157_16_cursor.path()[v157_16_origin..v157_16_depth])));
        join_wrapped_into(&mut v157_16_write,&((v158_4).read_zipper()),&v157_16_cursor.path()[v157_16_origin..v157_16_depth]);
        }
        v157_16_more = next_value_within(&mut v157_16_cursor,v157_16_origin);
      }
      drop(v157_16_cursor);
      drop(v157_16_write);
      drop(v157_15);
      compose(&(v156_13),&(v157_16))
    };
    drop(v156_13);
    let v156_18: Space = subtract(&(v156_10),&(v156_17));
    drop(v156_10);
    compose(&(v155_3),&(v156_18))
  };
  drop(v155_3);
  (v155_19).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v159_5: Space = singleton(&(*p0));
  let v159_6: Space = intersect(&(*CONSTANT_7),&(v159_5));
  let v159_7: Space = if has_head(&(v159_6)) { singleton(&[]) } else { Space::new() };
  drop(v159_6);
  let v159_8: Space = subtract(&(*CONSTANT_6),&(v159_7));
  drop(v159_7);
  let v159_13: Space = intersect(&(*CONSTANT_7),&(v159_5));
  drop(v159_5);
  let v159_14: Space = if has_head(&(v159_13)) { singleton(&[]) } else { Space::new() };
  drop(v159_13);
  let v159_16: Space = compose(&(v159_14),&(*CONSTANT_11));
  drop(v159_14);
  let mut v159_17 = Space::new();
  let mut v159_17_write = v159_17.write_zipper();
  let mut v159_17_cursor = (*s0).read_zipper();
  let v159_17_origin = v159_17_cursor.path().len();
  for v159_17_byte in v159_17_cursor.child_mask().iter() {
    v159_17_cursor.descend_to_existing_byte(v159_17_byte);
    {
    let v160_4: Space = if (&(v159_8)).is_empty() { Space::new() } else {
      let v161_2: Path = concat_path(&(*p1),&v159_17_cursor.path()[v159_17_origin..(v159_17_origin + 1)]);
      let mut v161_3 = Space::new();
      let mut v161_3_write = v161_3.write_zipper();
      let v161_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v161_3_arg_1: &[u8] = &(v161_2);
      let v161_3_arg_3: &Space = &(&v159_17_cursor).make_map();
      let mut v161_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v161_3_origin = v161_3_cursor.path().len();
      let mut v161_3_more = v161_3_cursor.is_val() || next_value_within(&mut v161_3_cursor,v161_3_origin);
      while v161_3_more {
        {
        let v161_3_depth = v161_3_cursor.path().len();
        let v162_4: Space = routine_23(c, &v161_3_cursor.path()[v161_3_origin..v161_3_depth], &(*v161_3_arg_1), &((*v161_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v161_3_write,&((v162_4).read_zipper()),&[]);
        }
        v161_3_more = next_value_within(&mut v161_3_cursor,v161_3_origin);
      }
      drop(v161_3_cursor);
      drop(v161_3_write);
      drop(v161_2);
      compose(&(v159_8),&(v161_3))
    };
    let v160_5: Space = unite(&(v160_4),&(v159_16));
    join_wrapped_into(&mut v159_17_write,&((v160_5).read_zipper()),&[]);
    }
    v159_17_cursor.ascend(1);
  }
  drop(v159_17_cursor);
  drop(v159_17_write);
  drop(v159_8);
  drop(v159_16);
  (v159_17).clone()
}

fn routine_24(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v163_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v163_2: Space = first_matching(&(*s0),&(*CONSTANT_6),false);
  let v163_3: Space = unite(&(v163_1),&(v163_2));
  drop(v163_1);
  drop(v163_2);
  let v163_13: Space = if (&(v163_3)).is_empty() { Space::new() } else {
    let v164_6: Space = if (&(v163_3)).is_empty() { Space::new() } else {
      let v165_4: Space = routine_21(c, &(*s0));
      let v165_5: Space = subtract(&(*s0),&(v165_4));
      compose(&(v163_3),&(v165_5))
    };
    let v164_7: Space = if has_head(&(v164_6)) { singleton(&[]) } else { Space::new() };
    let v164_8: Space = first_matching(&(v164_6),&(*CONSTANT_6),false);
    let v164_9: Space = unite(&(v164_7),&(v164_8));
    let v164_12: Space = if (&(v164_9)).is_empty() { Space::new() } else {
      let v166_10: Space = routine_21(c, &((v164_6).read_zipper()));
      let v166_11: Space = subtract(&(v164_6),&(v166_10));
      compose(&(v164_9),&(v166_11))
    };
    compose(&(v163_3),&(v164_12))
  };
  drop(v163_3);
  (v163_13).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v167_5: Space = singleton(&(*p0));
  let v167_6: Space = intersect(&(*CONSTANT_7),&(v167_5));
  let v167_7: Space = if has_head(&(v167_6)) { singleton(&[]) } else { Space::new() };
  drop(v167_6);
  let v167_8: Space = subtract(&(*CONSTANT_6),&(v167_7));
  drop(v167_7);
  let v167_13: Space = intersect(&(*CONSTANT_7),&(v167_5));
  drop(v167_5);
  let v167_14: Space = if has_head(&(v167_13)) { singleton(&[]) } else { Space::new() };
  drop(v167_13);
  let v167_16: Space = compose(&(v167_14),&(*CONSTANT_11));
  drop(v167_14);
  let mut v167_17 = Space::new();
  let mut v167_17_write = v167_17.write_zipper();
  let mut v167_17_cursor = (*s0).read_zipper();
  let v167_17_origin = v167_17_cursor.path().len();
  for v167_17_byte in v167_17_cursor.child_mask().iter() {
    v167_17_cursor.descend_to_existing_byte(v167_17_byte);
    {
    let v168_4: Space = if (&(v167_8)).is_empty() { Space::new() } else {
      let v169_2: Path = concat_path(&(*p1),&v167_17_cursor.path()[v167_17_origin..(v167_17_origin + 1)]);
      let mut v169_3 = Space::new();
      let mut v169_3_write = v169_3.write_zipper();
      let v169_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v169_3_arg_1: &[u8] = &(v169_2);
      let v169_3_arg_3: &Space = &(&v167_17_cursor).make_map();
      let mut v169_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v169_3_origin = v169_3_cursor.path().len();
      let mut v169_3_more = v169_3_cursor.is_val() || next_value_within(&mut v169_3_cursor,v169_3_origin);
      while v169_3_more {
        {
        let v169_3_depth = v169_3_cursor.path().len();
        let v170_4: Space = routine_25(c, &v169_3_cursor.path()[v169_3_origin..v169_3_depth], &(*v169_3_arg_1), &((*v169_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v169_3_write,&((v170_4).read_zipper()),&[]);
        }
        v169_3_more = next_value_within(&mut v169_3_cursor,v169_3_origin);
      }
      drop(v169_3_cursor);
      drop(v169_3_write);
      drop(v169_2);
      compose(&(v167_8),&(v169_3))
    };
    let v168_5: Space = unite(&(v168_4),&(v167_16));
    join_wrapped_into(&mut v167_17_write,&((v168_5).read_zipper()),&[]);
    }
    v167_17_cursor.ascend(1);
  }
  drop(v167_17_cursor);
  drop(v167_17_write);
  drop(v167_8);
  drop(v167_16);
  (v167_17).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v171_8: Space = if (&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1))),&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p0))))
  };
  let v171_9: Path = concat_path(&(*p1),&(*p0));
  let v171_10: Space = singleton(&(v171_9));
  drop(v171_9);
  let v171_11: Space = subtract(&(v171_8),&(v171_10));
  drop(v171_8);
  let v171_14: Space = intersect(&(v171_11),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
  drop(v171_11);
  let v171_19: Space = if (&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1))),&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p0))))
  };
  let v171_20: Space = subtract(&(v171_19),&(v171_10));
  drop(v171_19);
  let v171_21: Space = intersect(&(v171_20),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
  drop(v171_20);
  let v171_22: Space = routine_24(c, &((v171_21).read_zipper()));
  drop(v171_21);
  let v171_23: Space = subtract(&(v171_14),&(v171_22));
  drop(v171_14);
  let v171_28: Space = if (&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1))),&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p0))))
  };
  let v171_29: Space = subtract(&(v171_28),&(v171_10));
  drop(v171_28);
  let v171_30: Space = intersect(&(v171_29),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
  drop(v171_29);
  let v171_31: Space = routine_22(c, &((v171_30).read_zipper()));
  drop(v171_30);
  let v171_32: Space = intersect(&(v171_23),&(v171_31));
  let mut v171_38 = Space::new();
  let mut v171_38_write = v171_38.write_zipper();
  let mut v171_38_cursor = (v171_32).read_zipper();
  let v171_38_origin = v171_38_cursor.path().len();
  for v171_38_byte in v171_38_cursor.child_mask().iter() {
    v171_38_cursor.descend_to_existing_byte(v171_38_byte);
    {
    let v175_2: Space = singleton(&v171_38_cursor.path()[v171_38_origin..(v171_38_origin + 1)]);
    let v175_3: Space = intersect(&(*CONSTANT_7),&(v175_2));
    let v175_4: Space = if has_head(&(v175_3)) { singleton(&[]) } else { Space::new() };
    drop(v175_3);
    let v175_5: Space = subtract(&(*CONSTANT_6),&(v175_4));
    drop(v175_4);
    let v175_8: Space = if (&(v175_5)).is_empty() { Space::new() } else {
      let mut v176_7 = Space::new();
      let mut v176_7_write = v176_7.write_zipper();
      let v176_7_arg_0: &[u8] = &(*CONSTANT_9);
      let v176_7_arg_1: &[u8] = &v171_38_cursor.path()[v171_38_origin..(v171_38_origin + 1)];
      let v176_7_arg_3: &Space = &(&v171_38_cursor).make_map();
      let mut v176_7_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&v171_38_cursor.path()[v171_38_origin..(v171_38_origin + 1)]);
      let v176_7_origin = v176_7_cursor.path().len();
      let mut v176_7_more = v176_7_cursor.is_val() || next_value_within(&mut v176_7_cursor,v176_7_origin);
      while v176_7_more {
        {
        let v176_7_depth = v176_7_cursor.path().len();
        let mut v177_4_cursor = (*v176_7_arg_3).read_zipper();
        let v177_4_origin = v177_4_cursor.path().len();
        for v177_4_byte in v177_4_cursor.child_mask().iter() {
          v177_4_cursor.descend_to_existing_byte(v177_4_byte);
          {
          let v178_2: Path = concat_path(&(*v176_7_arg_1),&v177_4_cursor.path()[v177_4_origin..(v177_4_origin + 1)]);
          let v178_3: Space = routine_18(c, &(v178_2), &v176_7_cursor.path()[v176_7_origin..v176_7_depth], &v177_4_cursor);
          drop(v178_2);
          join_wrapped_into(&mut v176_7_write,&((v178_3).read_zipper()),&[]);
          }
          v177_4_cursor.ascend(1);
        }
        drop(v177_4_cursor);
        }
        v176_7_more = next_value_within(&mut v176_7_cursor,v176_7_origin);
      }
      drop(v176_7_cursor);
      drop(v176_7_write);
      compose(&(v175_5),&(v176_7))
    };
    drop(v175_5);
    let v175_9: Space = intersect(&(*CONSTANT_7),&(v175_2));
    drop(v175_2);
    let v175_10: Space = if has_head(&(v175_9)) { singleton(&[]) } else { Space::new() };
    drop(v175_9);
    let v175_12: Space = if (&(v175_10)).is_empty() { Space::new() } else {
      let v179_11: Space = routine_33(c, &v171_38_cursor.path()[v171_38_origin..(v171_38_origin + 1)], &v171_38_cursor);
      compose(&(v175_10),&(v179_11))
    };
    drop(v175_10);
    let v175_13: Space = unite(&(v175_8),&(v175_12));
    join_wrapped_into(&mut v171_38_write,&((v175_13).read_zipper()),&[]);
    }
    v171_38_cursor.ascend(1);
  }
  drop(v171_38_cursor);
  drop(v171_38_write);
  let v171_43: Space = if (&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1))),&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p0))))
  };
  let v171_44: Space = subtract(&(v171_43),&(v171_10));
  drop(v171_43);
  let v171_45: Space = intersect(&(v171_44),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
  drop(v171_44);
  let v171_50: Space = if (&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1))),&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p0))))
  };
  let v171_51: Space = subtract(&(v171_50),&(v171_10));
  drop(v171_50);
  let v171_52: Space = intersect(&(v171_51),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
  drop(v171_51);
  let v171_53: Space = routine_22(c, &((v171_52).read_zipper()));
  drop(v171_52);
  let v171_54: Space = routine_24(c, &((v171_53).read_zipper()));
  let v171_55: Space = subtract(&(v171_45),&(v171_54));
  drop(v171_45);
  let v171_60: Space = if (&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1)))).is_empty() { Space::new() } else {
    compose(&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p1))),&(descend_cursor((*CONSTANT_10).read_zipper(),&(*p0))))
  };
  let v171_61: Space = subtract(&(v171_60),&(v171_10));
  drop(v171_60);
  let v171_62: Space = intersect(&(v171_61),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
  drop(v171_61);
  let v171_63: Space = routine_24(c, &((v171_62).read_zipper()));
  drop(v171_62);
  let v171_64: Space = intersect(&(v171_55),&(v171_63));
  let mut v171_69 = Space::new();
  let mut v171_69_write = v171_69.write_zipper();
  let mut v171_69_cursor = (v171_64).read_zipper();
  let v171_69_origin = v171_69_cursor.path().len();
  for v171_69_byte in v171_69_cursor.child_mask().iter() {
    v171_69_cursor.descend_to_existing_byte(v171_69_byte);
    {
    let v183_2: Space = singleton(&v171_69_cursor.path()[v171_69_origin..(v171_69_origin + 1)]);
    let v183_3: Space = intersect(&(*CONSTANT_7),&(v183_2));
    let v183_4: Space = if has_head(&(v183_3)) { singleton(&[]) } else { Space::new() };
    drop(v183_3);
    let v183_5: Space = subtract(&(*CONSTANT_6),&(v183_4));
    drop(v183_4);
    let v183_8: Space = if (&(v183_5)).is_empty() { Space::new() } else {
      let mut v184_7 = Space::new();
      let mut v184_7_write = v184_7.write_zipper();
      let v184_7_arg_0: &[u8] = &(*CONSTANT_9);
      let v184_7_arg_1: &[u8] = &v171_69_cursor.path()[v171_69_origin..(v171_69_origin + 1)];
      let v184_7_arg_3: &Space = &(&v171_69_cursor).make_map();
      let mut v184_7_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&v171_69_cursor.path()[v171_69_origin..(v171_69_origin + 1)]);
      let v184_7_origin = v184_7_cursor.path().len();
      let mut v184_7_more = v184_7_cursor.is_val() || next_value_within(&mut v184_7_cursor,v184_7_origin);
      while v184_7_more {
        {
        let v184_7_depth = v184_7_cursor.path().len();
        let mut v185_4_cursor = (*v184_7_arg_3).read_zipper();
        let v185_4_origin = v185_4_cursor.path().len();
        for v185_4_byte in v185_4_cursor.child_mask().iter() {
          v185_4_cursor.descend_to_existing_byte(v185_4_byte);
          {
          let v186_2: Path = concat_path(&(*v184_7_arg_1),&v185_4_cursor.path()[v185_4_origin..(v185_4_origin + 1)]);
          let v186_3: Space = routine_19(c, &(v186_2), &v184_7_cursor.path()[v184_7_origin..v184_7_depth], &v185_4_cursor);
          drop(v186_2);
          join_wrapped_into(&mut v184_7_write,&((v186_3).read_zipper()),&[]);
          }
          v185_4_cursor.ascend(1);
        }
        drop(v185_4_cursor);
        }
        v184_7_more = next_value_within(&mut v184_7_cursor,v184_7_origin);
      }
      drop(v184_7_cursor);
      drop(v184_7_write);
      compose(&(v183_5),&(v184_7))
    };
    drop(v183_5);
    let v183_9: Space = intersect(&(*CONSTANT_7),&(v183_2));
    drop(v183_2);
    let v183_10: Space = if has_head(&(v183_9)) { singleton(&[]) } else { Space::new() };
    drop(v183_9);
    let v183_12: Space = if (&(v183_10)).is_empty() { Space::new() } else {
      let v187_11: Space = routine_34(c, &v171_69_cursor.path()[v171_69_origin..(v171_69_origin + 1)], &v171_69_cursor);
      compose(&(v183_10),&(v187_11))
    };
    drop(v183_10);
    let v183_13: Space = unite(&(v183_8),&(v183_12));
    join_wrapped_into(&mut v171_69_write,&((v183_13).read_zipper()),&[]);
    }
    v171_69_cursor.ascend(1);
  }
  drop(v171_69_cursor);
  drop(v171_69_write);
  let v171_70: Space = subtract(&(v171_38),&(v171_69));
  let v171_71: Space = if (&(v171_70)).is_empty() { Space::new() } else {
    compose(&(v171_70),&(v171_10))
  };
  drop(v171_10);
  let v171_837: Space = drop_length_prefixes(&(v171_71));
  (v171_837).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v189_5: Space = singleton(&(*p0));
  let v189_6: Space = intersect(&(*CONSTANT_7),&(v189_5));
  let v189_7: Space = if has_head(&(v189_6)) { singleton(&[]) } else { Space::new() };
  drop(v189_6);
  let v189_8: Space = subtract(&(*CONSTANT_6),&(v189_7));
  drop(v189_7);
  let v189_13: Space = intersect(&(*CONSTANT_7),&(v189_5));
  drop(v189_5);
  let v189_14: Space = if has_head(&(v189_13)) { singleton(&[]) } else { Space::new() };
  drop(v189_13);
  let v189_16: Space = compose(&(v189_14),&(*CONSTANT_11));
  drop(v189_14);
  let mut v189_17 = Space::new();
  let mut v189_17_write = v189_17.write_zipper();
  let mut v189_17_cursor = (*s0).read_zipper();
  let v189_17_origin = v189_17_cursor.path().len();
  for v189_17_byte in v189_17_cursor.child_mask().iter() {
    v189_17_cursor.descend_to_existing_byte(v189_17_byte);
    {
    let v190_4: Space = if (&(v189_8)).is_empty() { Space::new() } else {
      let v191_2: Path = concat_path(&(*p1),&v189_17_cursor.path()[v189_17_origin..(v189_17_origin + 1)]);
      let mut v191_3 = Space::new();
      let mut v191_3_write = v191_3.write_zipper();
      let v191_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v191_3_arg_1: &[u8] = &(v191_2);
      let v191_3_arg_3: &Space = &(&v189_17_cursor).make_map();
      let mut v191_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v191_3_origin = v191_3_cursor.path().len();
      let mut v191_3_more = v191_3_cursor.is_val() || next_value_within(&mut v191_3_cursor,v191_3_origin);
      while v191_3_more {
        {
        let v191_3_depth = v191_3_cursor.path().len();
        let v192_4: Space = routine_27(c, &v191_3_cursor.path()[v191_3_origin..v191_3_depth], &(*v191_3_arg_1), &((*v191_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v191_3_write,&((v192_4).read_zipper()),&[]);
        }
        v191_3_more = next_value_within(&mut v191_3_cursor,v191_3_origin);
      }
      drop(v191_3_cursor);
      drop(v191_3_write);
      drop(v191_2);
      compose(&(v189_8),&(v191_3))
    };
    let v190_5: Space = unite(&(v190_4),&(v189_16));
    join_wrapped_into(&mut v189_17_write,&((v190_5).read_zipper()),&[]);
    }
    v189_17_cursor.ascend(1);
  }
  drop(v189_17_cursor);
  drop(v189_17_write);
  drop(v189_8);
  drop(v189_16);
  (v189_17).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v193_5: Space = singleton(&(*p0));
  let v193_6: Space = intersect(&(*CONSTANT_7),&(v193_5));
  let v193_7: Space = if has_head(&(v193_6)) { singleton(&[]) } else { Space::new() };
  drop(v193_6);
  let v193_8: Space = subtract(&(*CONSTANT_6),&(v193_7));
  drop(v193_7);
  let v193_13: Space = intersect(&(*CONSTANT_7),&(v193_5));
  drop(v193_5);
  let v193_14: Space = if has_head(&(v193_13)) { singleton(&[]) } else { Space::new() };
  drop(v193_13);
  let v193_16: Space = compose(&(v193_14),&(*CONSTANT_11));
  drop(v193_14);
  let mut v193_17 = Space::new();
  let mut v193_17_write = v193_17.write_zipper();
  let mut v193_17_cursor = (*s0).read_zipper();
  let v193_17_origin = v193_17_cursor.path().len();
  for v193_17_byte in v193_17_cursor.child_mask().iter() {
    v193_17_cursor.descend_to_existing_byte(v193_17_byte);
    {
    let v194_4: Space = if (&(v193_8)).is_empty() { Space::new() } else {
      let v195_2: Path = concat_path(&(*p1),&v193_17_cursor.path()[v193_17_origin..(v193_17_origin + 1)]);
      let mut v195_3 = Space::new();
      let mut v195_3_write = v195_3.write_zipper();
      let v195_3_arg_0: &[u8] = &(*CONSTANT_9);
      let v195_3_arg_1: &[u8] = &(v195_2);
      let v195_3_arg_3: &Space = &(&v193_17_cursor).make_map();
      let mut v195_3_cursor = descend_cursor((*CONSTANT_8).read_zipper(),&(*p0));
      let v195_3_origin = v195_3_cursor.path().len();
      let mut v195_3_more = v195_3_cursor.is_val() || next_value_within(&mut v195_3_cursor,v195_3_origin);
      while v195_3_more {
        {
        let v195_3_depth = v195_3_cursor.path().len();
        let v196_4: Space = routine_28(c, &v195_3_cursor.path()[v195_3_origin..v195_3_depth], &(*v195_3_arg_1), &((*v195_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v195_3_write,&((v196_4).read_zipper()),&[]);
        }
        v195_3_more = next_value_within(&mut v195_3_cursor,v195_3_origin);
      }
      drop(v195_3_cursor);
      drop(v195_3_write);
      drop(v195_2);
      compose(&(v193_8),&(v195_3))
    };
    let v194_5: Space = unite(&(v194_4),&(v193_16));
    join_wrapped_into(&mut v193_17_write,&((v194_5).read_zipper()),&[]);
    }
    v193_17_cursor.ascend(1);
  }
  drop(v193_17_cursor);
  drop(v193_17_write);
  drop(v193_8);
  drop(v193_16);
  (v193_17).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (*CONSTANT_11).clone()
}

fn routine_30(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v198_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v198_2: Space = first_matching(&(*s0),&(*CONSTANT_6),false);
  let v198_3: Space = unite(&(v198_1),&(v198_2));
  drop(v198_1);
  drop(v198_2);
  let v198_15: Space = if (&(v198_3)).is_empty() { Space::new() } else {
    let v199_8: Space = if (&(v198_3)).is_empty() { Space::new() } else {
      let v200_6: Space = if (&(v198_3)).is_empty() { Space::new() } else {
        let v201_4: Space = routine_21(c, &(*s0));
        let v201_5: Space = subtract(&(*s0),&(v201_4));
        compose(&(v198_3),&(v201_5))
      };
      let v200_7: Space = routine_22(c, &((v200_6).read_zipper()));
      compose(&(v198_3),&(v200_7))
    };
    let v199_9: Space = if has_head(&(v199_8)) { singleton(&[]) } else { Space::new() };
    let v199_10: Space = first_matching(&(v199_8),&(*CONSTANT_6),false);
    let v199_11: Space = unite(&(v199_9),&(v199_10));
    let v199_14: Space = if (&(v199_11)).is_empty() { Space::new() } else {
      let v202_12: Space = routine_22(c, &((v199_8).read_zipper()));
      let v202_13: Space = routine_22(c, &((v202_12).read_zipper()));
      compose(&(v199_11),&(v202_13))
    };
    compose(&(v198_3),&(v199_14))
  };
  drop(v198_3);
  (v198_15).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (*CONSTANT_11).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v204_4: Space = first_matching(&(descend_cursor((*s0).read_zipper(),&(*p0))),&(*CONSTANT_6),false);
  let v204_5: Space = intersect(&(*CONSTANT_6),&(v204_4));
  let v204_6: Space = if has_head(&(v204_4)) { singleton(&[]) } else { Space::new() };
  let v204_7: Space = unite(&(v204_5),&(v204_6));
  drop(v204_5);
  let v204_9: Space = compose(&(v204_7),&(*CONSTANT_6));
  drop(v204_7);
  let v204_11: Space = subtract(&(*CONSTANT_6),&(v204_4));
  drop(v204_4);
  let v204_12: Space = subtract(&(v204_11),&(v204_6));
  drop(v204_6);
  drop(v204_11);
  let v204_16: Space = if (&(v204_12)).is_empty() { Space::new() } else {
    let v205_14: Space = first_length_prefixed(&(descend_cursor((*s0).read_zipper(),&(*p0))));
    let mut v205_15 = Space::new();
    let mut v205_15_write = v205_15.write_zipper();
    let v205_15_arg_0: &[u8] = &(*CONSTANT_9);
    let v205_15_arg_2: &Space = &(&(descend_cursor((*s0).read_zipper(),&(*p0)))).make_map();
    let mut v205_15_cursor = (v205_14).read_zipper();
    let v205_15_origin = v205_15_cursor.path().len();
    let mut v205_15_more = v205_15_cursor.is_val() || next_value_within(&mut v205_15_cursor,v205_15_origin);
    while v205_15_more {
      {
      let v205_15_depth = v205_15_cursor.path().len();
      let v206_3: Space = routine_32(c, &v205_15_cursor.path()[v205_15_origin..v205_15_depth], &((*v205_15_arg_2).read_zipper()));
      join_wrapped_into(&mut v205_15_write,&((v206_3).read_zipper()),&[]);
      }
      v205_15_more = next_value_within(&mut v205_15_cursor,v205_15_origin);
    }
    drop(v205_15_cursor);
    drop(v205_15_write);
    drop(v205_14);
    compose(&(v204_12),&(v205_15))
  };
  drop(v204_12);
  let v204_17: Space = unite(&(v204_9),&(v204_16));
  drop(v204_9);
  let v204_18: Space = wrap(&(v204_17),&(*p0));
  (v204_18).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (*CONSTANT_11).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (*CONSTANT_11).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
