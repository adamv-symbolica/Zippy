#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,2,210]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_3 = Space::new();
  let mut v0_3_write = v0_3.write_zipper();
  let mut v0_3_cursor = descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0));
  let v0_3_origin = v0_3_cursor.path().len();
  for v0_3_byte in v0_3_cursor.child_mask().iter() {
    v0_3_cursor.descend_to_existing_byte(v0_3_byte);
    {
    for v1_2_byte in v0_3_cursor.child_mask().iter() {
      v0_3_cursor.descend_to_existing_byte(v1_2_byte);
      {
      for v2_3_byte in v0_3_cursor.child_mask().iter() {
        v0_3_cursor.descend_to_existing_byte(v2_3_byte);
        {
        for v3_3_byte in v0_3_cursor.child_mask().iter() {
          v0_3_cursor.descend_to_existing_byte(v3_3_byte);
          {
          for v4_3_byte in v0_3_cursor.child_mask().iter() {
            v0_3_cursor.descend_to_existing_byte(v4_3_byte);
            {
            for v5_2_byte in v0_3_cursor.child_mask().iter() {
              v0_3_cursor.descend_to_existing_byte(v5_2_byte);
              {
              for v6_3_byte in v0_3_cursor.child_mask().iter() {
                v0_3_cursor.descend_to_existing_byte(v6_3_byte);
                {
                for v7_3_byte in v0_3_cursor.child_mask().iter() {
                  v0_3_cursor.descend_to_existing_byte(v7_3_byte);
                  {
                  let v8_3: Space = routine_1(c, &v0_3_cursor.path()[(v0_3_origin + 4)..(v0_3_origin + 8)], &v0_3_cursor.path()[v0_3_origin..(v0_3_origin + 4)], &v0_3_cursor, &((*s0.expect("unbound native input")).read_zipper()));
                  join_wrapped_into(&mut v0_3_write,&((v8_3).read_zipper()),&[]);
                  }
                  v0_3_cursor.ascend(1);
                }
                }
                v0_3_cursor.ascend(1);
              }
              }
              v0_3_cursor.ascend(1);
            }
            }
            v0_3_cursor.ascend(1);
          }
          }
          v0_3_cursor.ascend(1);
        }
        }
        v0_3_cursor.ascend(1);
      }
      }
      v0_3_cursor.ascend(1);
    }
    }
    v0_3_cursor.ascend(1);
  }
  drop(v0_3_cursor);
  drop(v0_3_write);
  let v0_5: Space = wrap(&(v0_3),&(*CONSTANT_1));
  (v0_5).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v9_8 = Space::new();
  let mut v9_8_write = v9_8.write_zipper();
  let mut v9_8_cursor = descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0));
  let v9_8_origin = v9_8_cursor.path().len();
  for v9_8_byte in v9_8_cursor.child_mask().iter() {
    v9_8_cursor.descend_to_existing_byte(v9_8_byte);
    {
    for v10_2_byte in v9_8_cursor.child_mask().iter() {
      v9_8_cursor.descend_to_existing_byte(v10_2_byte);
      {
      for v11_3_byte in v9_8_cursor.child_mask().iter() {
        v9_8_cursor.descend_to_existing_byte(v11_3_byte);
        {
        v9_8_write.descend_to(&v9_8_cursor.path()[v9_8_origin..(v9_8_origin + 3)]);
        join_branches(&mut v9_8_write,&mut v9_8_cursor);
        v9_8_write.ascend((&v9_8_cursor.path()[v9_8_origin..(v9_8_origin + 3)]).len());
        }
        v9_8_cursor.ascend(1);
      }
      }
      v9_8_cursor.ascend(1);
    }
    }
    v9_8_cursor.ascend(1);
  }
  drop(v9_8_cursor);
  drop(v9_8_write);
  let v9_9: Space = wrap(&(v9_8),&(*p1));
  drop(v9_8);
  (v9_9).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
