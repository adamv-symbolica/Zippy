#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1,0,0,0,1,0,0,1,0,0,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_24 = Space::new();
  let mut v0_24_write = v0_24.write_zipper();
  let mut v0_24_cursor = descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0));
  let v0_24_origin = v0_24_cursor.path().len();
  for v0_24_byte in v0_24_cursor.child_mask().iter() {
    v0_24_cursor.descend_to_existing_byte(v0_24_byte);
    {
    let v1_2: Space = singleton(&v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 1)]);
    let v1_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if map_kernels::has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (&(v1_5)).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_write = v2_6.write_zipper();
      for v2_6_byte in v0_24_cursor.child_mask().iter() {
        v0_24_cursor.descend_to_existing_byte(v2_6_byte);
        {
        let v3_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 1)..(v0_24_origin + 2)]);
        let v3_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v3_2));
        let v3_4: Space = if map_kernels::has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (&(v3_5)).is_empty() { Space::new() } else {
          let mut v4_7 = Space::new();
          let mut v4_7_write = v4_7.write_zipper();
          for v4_7_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v4_7_byte);
            {
            let v5_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v5_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v5_2));
            let v5_4: Space = if map_kernels::has_head(&(v5_3)) { singleton(&[]) } else { Space::new() };
            drop(v5_3);
            let v5_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v5_4));
            drop(v5_4);
            let v5_8: Space = if (&(v5_5)).is_empty() { Space::new() } else {
              let v6_7: Space = routine_1(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              map_map_kernels::compose(&(v5_5),&(v6_7))
            };
            drop(v5_5);
            let v5_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v5_2));
            drop(v5_2);
            let v5_10: Space = if map_kernels::has_head(&(v5_9)) { singleton(&[]) } else { Space::new() };
            drop(v5_9);
            let v5_12: Space = if (&(v5_10)).is_empty() { Space::new() } else {
              let v7_11: Space = routine_2(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              map_map_kernels::compose(&(v5_10),&(v7_11))
            };
            drop(v5_10);
            let v5_13: Space = map_map_kernels::unite(&(v5_8),&(v5_12));
            join_wrapped_into(&mut v4_7_write,&((v5_13).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v4_7_write);
          map_map_kernels::compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if map_kernels::has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (&(v3_10)).is_empty() { Space::new() } else {
          let mut v8_11 = Space::new();
          let mut v8_11_write = v8_11.write_zipper();
          for v8_11_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v8_11_byte);
            {
            let v9_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v9_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v9_2));
            let v9_4: Space = if map_kernels::has_head(&(v9_3)) { singleton(&[]) } else { Space::new() };
            drop(v9_3);
            let v9_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v9_4));
            drop(v9_4);
            let v9_8: Space = if (&(v9_5)).is_empty() { Space::new() } else {
              let v10_7: Space = routine_1(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              map_map_kernels::compose(&(v9_5),&(v10_7))
            };
            drop(v9_5);
            let v9_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v9_2));
            drop(v9_2);
            let v9_10: Space = if map_kernels::has_head(&(v9_9)) { singleton(&[]) } else { Space::new() };
            drop(v9_9);
            let v9_12: Space = if (&(v9_10)).is_empty() { Space::new() } else {
              let v11_11: Space = routine_3(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              map_map_kernels::compose(&(v9_10),&(v11_11))
            };
            drop(v9_10);
            let v9_13: Space = map_map_kernels::unite(&(v9_8),&(v9_12));
            join_wrapped_into(&mut v8_11_write,&((v9_13).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v8_11_write);
          map_map_kernels::compose(&(v3_10),&(v8_11))
        };
        drop(v3_10);
        let v3_13: Space = map_map_kernels::unite(&(v3_8),&(v3_12));
        join_wrapped_into(&mut v2_6_write,&((v3_13).read_zipper()),&[]);
        }
        v0_24_cursor.ascend(1);
      }
      drop(v2_6_write);
      map_map_kernels::compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if map_kernels::has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (&(v1_9)).is_empty() { Space::new() } else {
      let mut v12_10 = Space::new();
      let mut v12_10_write = v12_10.write_zipper();
      for v12_10_byte in v0_24_cursor.child_mask().iter() {
        v0_24_cursor.descend_to_existing_byte(v12_10_byte);
        {
        let v13_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 1)..(v0_24_origin + 2)]);
        let v13_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v13_2));
        let v13_4: Space = if map_kernels::has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (&(v13_5)).is_empty() { Space::new() } else {
          let mut v14_7 = Space::new();
          let mut v14_7_write = v14_7.write_zipper();
          for v14_7_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v14_7_byte);
            {
            let v15_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v15_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v15_2));
            let v15_4: Space = if map_kernels::has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (&(v15_5)).is_empty() { Space::new() } else {
              let v16_7: Space = routine_1(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              map_map_kernels::compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if map_kernels::has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (&(v15_10)).is_empty() { Space::new() } else {
              let v17_11: Space = routine_2(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              map_map_kernels::compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = map_map_kernels::unite(&(v15_8),&(v15_12));
            join_wrapped_into(&mut v14_7_write,&((v15_13).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v14_7_write);
          map_map_kernels::compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if map_kernels::has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (&(v13_10)).is_empty() { Space::new() } else {
          let mut v18_11 = Space::new();
          let mut v18_11_write = v18_11.write_zipper();
          for v18_11_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v18_11_byte);
            {
            let v19_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v19_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v19_2));
            let v19_4: Space = if map_kernels::has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v19_4));
            drop(v19_4);
            let v19_7: Space = if (&(v19_5)).is_empty() { Space::new() } else {
              let v20_6: Space = routine_4(c, &v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)], &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 2)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              map_map_kernels::compose(&(v19_5),&(v20_6))
            };
            drop(v19_5);
            let v19_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v19_2));
            drop(v19_2);
            let v19_9: Space = if map_kernels::has_head(&(v19_8)) { singleton(&[]) } else { Space::new() };
            drop(v19_8);
            let v19_11: Space = if (&(v19_9)).is_empty() { Space::new() } else {
              let v21_10: Space = routine_5(c, &v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)], &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 2)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              map_map_kernels::compose(&(v19_9),&(v21_10))
            };
            drop(v19_9);
            let v19_12: Space = map_map_kernels::unite(&(v19_7),&(v19_11));
            join_wrapped_into(&mut v18_11_write,&((v19_12).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v18_11_write);
          map_map_kernels::compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = map_map_kernels::unite(&(v13_8),&(v13_12));
        join_wrapped_into(&mut v12_10_write,&((v13_13).read_zipper()),&[]);
        }
        v0_24_cursor.ascend(1);
      }
      drop(v12_10_write);
      map_map_kernels::compose(&(v1_9),&(v12_10))
    };
    drop(v1_9);
    let v1_12: Space = map_map_kernels::unite(&(v1_7),&(v1_11));
    join_wrapped_into(&mut v0_24_write,&((v1_12).read_zipper()),&[]);
    }
    v0_24_cursor.ascend(1);
  }
  drop(v0_24_cursor);
  drop(v0_24_write);
  let v0_26: Space = map_kernels::wrap(&(v0_24),&(*CONSTANT_3));
  (v0_26).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v22_24 = Space::new();
  let mut v22_24_write = v22_24.write_zipper();
  let mut v22_24_cursor = (*s0).read_zipper();
  let v22_24_origin = v22_24_cursor.path().len();
  for v22_24_byte in v22_24_cursor.child_mask().iter() {
    v22_24_cursor.descend_to_existing_byte(v22_24_byte);
    {
    let v23_2: Space = singleton(&v22_24_cursor.path()[v22_24_origin..(v22_24_origin + 1)]);
    let v23_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v23_2));
    let v23_4: Space = if map_kernels::has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
    drop(v23_3);
    let v23_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v23_4));
    drop(v23_4);
    let v23_8: Space = if (&(v23_5)).is_empty() { Space::new() } else {
      let v24_6: Path = concat_path(&(*p0),&v22_24_cursor.path()[v22_24_origin..(v22_24_origin + 1)]);
      let mut v24_7 = Space::new();
      let mut v24_7_write = v24_7.write_zipper();
      for v24_7_byte in v22_24_cursor.child_mask().iter() {
        v22_24_cursor.descend_to_existing_byte(v24_7_byte);
        {
        let v25_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
        let v25_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v25_2));
        let v25_4: Space = if map_kernels::has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
        drop(v25_3);
        let v25_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v25_4));
        drop(v25_4);
        let v25_8: Space = if (&(v25_5)).is_empty() { Space::new() } else {
          let v26_6: Path = concat_path(&(v24_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v26_7 = Space::new();
          let mut v26_7_write = v26_7.write_zipper();
          for v26_7_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v26_7_byte);
            {
            let v27_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v27_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v27_2));
            let v27_4: Space = if map_kernels::has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
            drop(v27_3);
            let v27_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v27_4));
            drop(v27_4);
            let v27_8: Space = if (&(v27_5)).is_empty() { Space::new() } else {
              let v28_6: Path = concat_path(&(v26_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v28_7: Space = routine_6(c, &(v28_6), &v22_24_cursor, &(*s1));
              map_map_kernels::compose(&(v27_5),&(v28_7))
            };
            drop(v27_5);
            let v27_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v27_2));
            drop(v27_2);
            let v27_10: Space = if map_kernels::has_head(&(v27_9)) { singleton(&[]) } else { Space::new() };
            drop(v27_9);
            let v27_12: Space = if (&(v27_10)).is_empty() { Space::new() } else {
              let v29_6: Path = concat_path(&(v26_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v29_11: Space = routine_7(c, &(v29_6), &v22_24_cursor, &(*s1));
              drop(v29_6);
              map_map_kernels::compose(&(v27_10),&(v29_11))
            };
            drop(v27_10);
            let v27_13: Space = map_map_kernels::unite(&(v27_8),&(v27_12));
            join_wrapped_into(&mut v26_7_write,&((v27_13).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v26_7_write);
          map_map_kernels::compose(&(v25_5),&(v26_7))
        };
        drop(v25_5);
        let v25_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v25_2));
        drop(v25_2);
        let v25_10: Space = if map_kernels::has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
        drop(v25_9);
        let v25_12: Space = if (&(v25_10)).is_empty() { Space::new() } else {
          let v30_6: Path = concat_path(&(v24_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v30_11 = Space::new();
          let mut v30_11_write = v30_11.write_zipper();
          for v30_11_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v30_11_byte);
            {
            let v31_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v31_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v31_2));
            let v31_4: Space = if map_kernels::has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
            drop(v31_3);
            let v31_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v31_4));
            drop(v31_4);
            let v31_8: Space = if (&(v31_5)).is_empty() { Space::new() } else {
              let v32_6: Path = concat_path(&(v30_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v32_7: Space = routine_6(c, &(v32_6), &v22_24_cursor, &(*s1));
              map_map_kernels::compose(&(v31_5),&(v32_7))
            };
            drop(v31_5);
            let v31_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v31_2));
            drop(v31_2);
            let v31_10: Space = if map_kernels::has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
            drop(v31_9);
            let v31_12: Space = if (&(v31_10)).is_empty() { Space::new() } else {
              let v33_6: Path = concat_path(&(v30_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v33_11: Space = routine_3(c, &(v33_6), &v22_24_cursor, &(*s1));
              drop(v33_6);
              map_map_kernels::compose(&(v31_10),&(v33_11))
            };
            drop(v31_10);
            let v31_13: Space = map_map_kernels::unite(&(v31_8),&(v31_12));
            join_wrapped_into(&mut v30_11_write,&((v31_13).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v30_11_write);
          drop(v30_6);
          map_map_kernels::compose(&(v25_10),&(v30_11))
        };
        drop(v25_10);
        let v25_13: Space = map_map_kernels::unite(&(v25_8),&(v25_12));
        join_wrapped_into(&mut v24_7_write,&((v25_13).read_zipper()),&[]);
        }
        v22_24_cursor.ascend(1);
      }
      drop(v24_7_write);
      map_map_kernels::compose(&(v23_5),&(v24_7))
    };
    drop(v23_5);
    let v23_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v23_2));
    drop(v23_2);
    let v23_10: Space = if map_kernels::has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
    drop(v23_9);
    let v23_12: Space = if (&(v23_10)).is_empty() { Space::new() } else {
      let v34_6: Path = concat_path(&(*p0),&v22_24_cursor.path()[v22_24_origin..(v22_24_origin + 1)]);
      let mut v34_11 = Space::new();
      let mut v34_11_write = v34_11.write_zipper();
      for v34_11_byte in v22_24_cursor.child_mask().iter() {
        v22_24_cursor.descend_to_existing_byte(v34_11_byte);
        {
        let v35_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
        let v35_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v35_2));
        let v35_4: Space = if map_kernels::has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
        drop(v35_3);
        let v35_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v35_4));
        drop(v35_4);
        let v35_8: Space = if (&(v35_5)).is_empty() { Space::new() } else {
          let v36_6: Path = concat_path(&(v34_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v36_7 = Space::new();
          let mut v36_7_write = v36_7.write_zipper();
          for v36_7_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v36_7_byte);
            {
            let v37_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v37_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v37_2));
            let v37_4: Space = if map_kernels::has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
            drop(v37_3);
            let v37_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v37_4));
            drop(v37_4);
            let v37_8: Space = if (&(v37_5)).is_empty() { Space::new() } else {
              let v38_6: Path = concat_path(&(v36_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v38_7: Space = routine_6(c, &(v38_6), &v22_24_cursor, &(*s1));
              map_map_kernels::compose(&(v37_5),&(v38_7))
            };
            drop(v37_5);
            let v37_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v37_2));
            drop(v37_2);
            let v37_10: Space = if map_kernels::has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
            drop(v37_9);
            let v37_12: Space = if (&(v37_10)).is_empty() { Space::new() } else {
              let v39_6: Path = concat_path(&(v36_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v39_11: Space = routine_7(c, &(v39_6), &v22_24_cursor, &(*s1));
              drop(v39_6);
              map_map_kernels::compose(&(v37_10),&(v39_11))
            };
            drop(v37_10);
            let v37_13: Space = map_map_kernels::unite(&(v37_8),&(v37_12));
            join_wrapped_into(&mut v36_7_write,&((v37_13).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v36_7_write);
          map_map_kernels::compose(&(v35_5),&(v36_7))
        };
        drop(v35_5);
        let v35_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v35_2));
        drop(v35_2);
        let v35_10: Space = if map_kernels::has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
        drop(v35_9);
        let v35_12: Space = if (&(v35_10)).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v34_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v40_11 = Space::new();
          let mut v40_11_write = v40_11.write_zipper();
          for v40_11_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v40_11_byte);
            {
            let v41_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v41_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v41_2));
            let v41_4: Space = if map_kernels::has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v41_4));
            drop(v41_4);
            let v41_7: Space = if (&(v41_5)).is_empty() { Space::new() } else {
              let v42_6: Space = routine_4(c, &v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)], &(v40_6), &v22_24_cursor, &(*s1));
              map_map_kernels::compose(&(v41_5),&(v42_6))
            };
            drop(v41_5);
            let v41_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v41_2));
            drop(v41_2);
            let v41_9: Space = if map_kernels::has_head(&(v41_8)) { singleton(&[]) } else { Space::new() };
            drop(v41_8);
            let v41_11: Space = if (&(v41_9)).is_empty() { Space::new() } else {
              let v43_10: Space = routine_5(c, &v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)], &(v40_6), &v22_24_cursor, &(*s1));
              map_map_kernels::compose(&(v41_9),&(v43_10))
            };
            drop(v41_9);
            let v41_12: Space = map_map_kernels::unite(&(v41_7),&(v41_11));
            join_wrapped_into(&mut v40_11_write,&((v41_12).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v40_11_write);
          drop(v40_6);
          map_map_kernels::compose(&(v35_10),&(v40_11))
        };
        drop(v35_10);
        let v35_13: Space = map_map_kernels::unite(&(v35_8),&(v35_12));
        join_wrapped_into(&mut v34_11_write,&((v35_13).read_zipper()),&[]);
        }
        v22_24_cursor.ascend(1);
      }
      drop(v34_11_write);
      drop(v34_6);
      map_map_kernels::compose(&(v23_10),&(v34_11))
    };
    drop(v23_10);
    let v23_13: Space = map_map_kernels::unite(&(v23_8),&(v23_12));
    join_wrapped_into(&mut v22_24_write,&((v23_13).read_zipper()),&[]);
    }
    v22_24_cursor.ascend(1);
  }
  drop(v22_24_cursor);
  drop(v22_24_write);
  (v22_24).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v44_24 = Space::new();
  let mut v44_24_write = v44_24.write_zipper();
  let mut v44_24_cursor = (*s0).read_zipper();
  let v44_24_origin = v44_24_cursor.path().len();
  for v44_24_byte in v44_24_cursor.child_mask().iter() {
    v44_24_cursor.descend_to_existing_byte(v44_24_byte);
    {
    let v45_2: Space = singleton(&v44_24_cursor.path()[v44_24_origin..(v44_24_origin + 1)]);
    let v45_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v45_2));
    let v45_4: Space = if map_kernels::has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
    drop(v45_3);
    let v45_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v45_4));
    drop(v45_4);
    let v45_8: Space = if (&(v45_5)).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&v44_24_cursor.path()[v44_24_origin..(v44_24_origin + 1)]);
      let mut v46_7 = Space::new();
      let mut v46_7_write = v46_7.write_zipper();
      for v46_7_byte in v44_24_cursor.child_mask().iter() {
        v44_24_cursor.descend_to_existing_byte(v46_7_byte);
        {
        let v47_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
        let v47_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v47_2));
        let v47_4: Space = if map_kernels::has_head(&(v47_3)) { singleton(&[]) } else { Space::new() };
        drop(v47_3);
        let v47_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v47_4));
        drop(v47_4);
        let v47_8: Space = if (&(v47_5)).is_empty() { Space::new() } else {
          let v48_6: Path = concat_path(&(v46_6),&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
          let mut v48_7 = Space::new();
          let mut v48_7_write = v48_7.write_zipper();
          for v48_7_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v48_7_byte);
            {
            let v49_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v49_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v49_2));
            let v49_4: Space = if map_kernels::has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
            drop(v49_3);
            let v49_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v49_4));
            drop(v49_4);
            let v49_8: Space = if (&(v49_5)).is_empty() { Space::new() } else {
              let v50_6: Path = concat_path(&(v48_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v50_7: Space = routine_6(c, &(v50_6), &v44_24_cursor, &(*s1));
              map_map_kernels::compose(&(v49_5),&(v50_7))
            };
            drop(v49_5);
            let v49_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v49_2));
            drop(v49_2);
            let v49_10: Space = if map_kernels::has_head(&(v49_9)) { singleton(&[]) } else { Space::new() };
            drop(v49_9);
            let v49_12: Space = if (&(v49_10)).is_empty() { Space::new() } else {
              let v51_6: Path = concat_path(&(v48_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v51_11: Space = routine_7(c, &(v51_6), &v44_24_cursor, &(*s1));
              drop(v51_6);
              map_map_kernels::compose(&(v49_10),&(v51_11))
            };
            drop(v49_10);
            let v49_13: Space = map_map_kernels::unite(&(v49_8),&(v49_12));
            join_wrapped_into(&mut v48_7_write,&((v49_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v48_7_write);
          map_map_kernels::compose(&(v47_5),&(v48_7))
        };
        drop(v47_5);
        let v47_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v47_2));
        drop(v47_2);
        let v47_10: Space = if map_kernels::has_head(&(v47_9)) { singleton(&[]) } else { Space::new() };
        drop(v47_9);
        let v47_12: Space = if (&(v47_10)).is_empty() { Space::new() } else {
          let v52_6: Path = concat_path(&(v46_6),&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
          let mut v52_11 = Space::new();
          let mut v52_11_write = v52_11.write_zipper();
          for v52_11_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v52_11_byte);
            {
            let v53_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v53_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v53_2));
            let v53_4: Space = if map_kernels::has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
            drop(v53_3);
            let v53_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v53_4));
            drop(v53_4);
            let v53_8: Space = if (&(v53_5)).is_empty() { Space::new() } else {
              let v54_6: Path = concat_path(&(v52_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v54_7: Space = routine_6(c, &(v54_6), &v44_24_cursor, &(*s1));
              map_map_kernels::compose(&(v53_5),&(v54_7))
            };
            drop(v53_5);
            let v53_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v53_2));
            drop(v53_2);
            let v53_10: Space = if map_kernels::has_head(&(v53_9)) { singleton(&[]) } else { Space::new() };
            drop(v53_9);
            let v53_12: Space = if (&(v53_10)).is_empty() { Space::new() } else {
              let v55_6: Path = concat_path(&(v52_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v55_11: Space = routine_3(c, &(v55_6), &v44_24_cursor, &(*s1));
              drop(v55_6);
              map_map_kernels::compose(&(v53_10),&(v55_11))
            };
            drop(v53_10);
            let v53_13: Space = map_map_kernels::unite(&(v53_8),&(v53_12));
            join_wrapped_into(&mut v52_11_write,&((v53_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v52_11_write);
          drop(v52_6);
          map_map_kernels::compose(&(v47_10),&(v52_11))
        };
        drop(v47_10);
        let v47_13: Space = map_map_kernels::unite(&(v47_8),&(v47_12));
        join_wrapped_into(&mut v46_7_write,&((v47_13).read_zipper()),&[]);
        }
        v44_24_cursor.ascend(1);
      }
      drop(v46_7_write);
      map_map_kernels::compose(&(v45_5),&(v46_7))
    };
    drop(v45_5);
    let v45_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v45_2));
    drop(v45_2);
    let v45_10: Space = if map_kernels::has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
    drop(v45_9);
    let v45_12: Space = if (&(v45_10)).is_empty() { Space::new() } else {
      let v56_6: Path = concat_path(&(*p0),&v44_24_cursor.path()[v44_24_origin..(v44_24_origin + 1)]);
      let mut v56_11 = Space::new();
      let mut v56_11_write = v56_11.write_zipper();
      for v56_11_byte in v44_24_cursor.child_mask().iter() {
        v44_24_cursor.descend_to_existing_byte(v56_11_byte);
        {
        let v57_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
        let v57_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v57_2));
        let v57_4: Space = if map_kernels::has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v57_4));
        drop(v57_4);
        let v57_7: Space = if (&(v57_5)).is_empty() { Space::new() } else {
          let mut v58_6 = Space::new();
          let mut v58_6_write = v58_6.write_zipper();
          for v58_6_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v58_6_byte);
            {
            let v59_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v59_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v59_2));
            let v59_4: Space = if map_kernels::has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
            drop(v59_3);
            let v59_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v59_4));
            drop(v59_4);
            let v59_8: Space = if (&(v59_5)).is_empty() { Space::new() } else {
              let v60_7: Space = routine_8(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              map_map_kernels::compose(&(v59_5),&(v60_7))
            };
            drop(v59_5);
            let v59_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v59_2));
            drop(v59_2);
            let v59_10: Space = if map_kernels::has_head(&(v59_9)) { singleton(&[]) } else { Space::new() };
            drop(v59_9);
            let v59_12: Space = if (&(v59_10)).is_empty() { Space::new() } else {
              let v61_11: Space = routine_9(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              map_map_kernels::compose(&(v59_10),&(v61_11))
            };
            drop(v59_10);
            let v59_13: Space = map_map_kernels::unite(&(v59_8),&(v59_12));
            join_wrapped_into(&mut v58_6_write,&((v59_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v58_6_write);
          map_map_kernels::compose(&(v57_5),&(v58_6))
        };
        drop(v57_5);
        let v57_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v57_2));
        drop(v57_2);
        let v57_9: Space = if map_kernels::has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
        drop(v57_8);
        let v57_11: Space = if (&(v57_9)).is_empty() { Space::new() } else {
          let mut v62_10 = Space::new();
          let mut v62_10_write = v62_10.write_zipper();
          for v62_10_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v62_10_byte);
            {
            let v63_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v63_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v63_2));
            let v63_4: Space = if map_kernels::has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
            drop(v63_3);
            let v63_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v63_4));
            drop(v63_4);
            let v63_8: Space = if (&(v63_5)).is_empty() { Space::new() } else {
              let v64_7: Space = routine_8(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              map_map_kernels::compose(&(v63_5),&(v64_7))
            };
            drop(v63_5);
            let v63_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v63_2));
            drop(v63_2);
            let v63_10: Space = if map_kernels::has_head(&(v63_9)) { singleton(&[]) } else { Space::new() };
            drop(v63_9);
            let v63_12: Space = if (&(v63_10)).is_empty() { Space::new() } else {
              let v65_11: Space = routine_10(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              map_map_kernels::compose(&(v63_10),&(v65_11))
            };
            drop(v63_10);
            let v63_13: Space = map_map_kernels::unite(&(v63_8),&(v63_12));
            join_wrapped_into(&mut v62_10_write,&((v63_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v62_10_write);
          map_map_kernels::compose(&(v57_9),&(v62_10))
        };
        drop(v57_9);
        let v57_12: Space = map_map_kernels::unite(&(v57_7),&(v57_11));
        join_wrapped_into(&mut v56_11_write,&((v57_12).read_zipper()),&[]);
        }
        v44_24_cursor.ascend(1);
      }
      drop(v56_11_write);
      drop(v56_6);
      map_map_kernels::compose(&(v45_10),&(v56_11))
    };
    drop(v45_10);
    let v45_13: Space = map_map_kernels::unite(&(v45_8),&(v45_12));
    join_wrapped_into(&mut v44_24_write,&((v45_13).read_zipper()),&[]);
    }
    v44_24_cursor.ascend(1);
  }
  drop(v44_24_cursor);
  drop(v44_24_write);
  (v44_24).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v66_26 = Space::new();
  let mut v66_26_write = v66_26.write_zipper();
  let mut v66_26_cursor = (*s0).read_zipper();
  let v66_26_origin = v66_26_cursor.path().len();
  for v66_26_byte in v66_26_cursor.child_mask().iter() {
    v66_26_cursor.descend_to_existing_byte(v66_26_byte);
    {
    let v67_2: Space = singleton(&v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 1)]);
    let v67_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v67_2));
    let v67_4: Space = if map_kernels::has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
    drop(v67_3);
    let v67_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v67_4));
    drop(v67_4);
    let v67_7: Space = if (&(v67_5)).is_empty() { Space::new() } else {
      let mut v68_6 = Space::new();
      let mut v68_6_write = v68_6.write_zipper();
      for v68_6_byte in v66_26_cursor.child_mask().iter() {
        v66_26_cursor.descend_to_existing_byte(v68_6_byte);
        {
        let v69_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 1)..(v66_26_origin + 2)]);
        let v69_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v69_2));
        let v69_4: Space = if map_kernels::has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
        drop(v69_3);
        let v69_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v69_4));
        drop(v69_4);
        let v69_8: Space = if (&(v69_5)).is_empty() { Space::new() } else {
          let mut v70_7 = Space::new();
          let mut v70_7_write = v70_7.write_zipper();
          for v70_7_byte in v66_26_cursor.child_mask().iter() {
            v66_26_cursor.descend_to_existing_byte(v70_7_byte);
            {
            let v71_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 2)..(v66_26_origin + 3)]);
            let v71_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v71_2));
            let v71_4: Space = if map_kernels::has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
            drop(v71_3);
            let v71_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v71_4));
            drop(v71_4);
            let v71_8: Space = if (&(v71_5)).is_empty() { Space::new() } else {
              let v72_7: Space = routine_11(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              map_map_kernels::compose(&(v71_5),&(v72_7))
            };
            drop(v71_5);
            let v71_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v71_2));
            drop(v71_2);
            let v71_10: Space = if map_kernels::has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
            drop(v71_9);
            let v71_12: Space = if (&(v71_10)).is_empty() { Space::new() } else {
              let v73_11: Space = routine_12(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              map_map_kernels::compose(&(v71_10),&(v73_11))
            };
            drop(v71_10);
            let v71_13: Space = map_map_kernels::unite(&(v71_8),&(v71_12));
            join_wrapped_into(&mut v70_7_write,&((v71_13).read_zipper()),&[]);
            }
            v66_26_cursor.ascend(1);
          }
          drop(v70_7_write);
          map_map_kernels::compose(&(v69_5),&(v70_7))
        };
        drop(v69_5);
        let v69_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v69_2));
        drop(v69_2);
        let v69_10: Space = if map_kernels::has_head(&(v69_9)) { singleton(&[]) } else { Space::new() };
        drop(v69_9);
        let v69_12: Space = if (&(v69_10)).is_empty() { Space::new() } else {
          let mut v74_11 = Space::new();
          let mut v74_11_write = v74_11.write_zipper();
          for v74_11_byte in v66_26_cursor.child_mask().iter() {
            v66_26_cursor.descend_to_existing_byte(v74_11_byte);
            {
            let v75_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 2)..(v66_26_origin + 3)]);
            let v75_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v75_2));
            let v75_4: Space = if map_kernels::has_head(&(v75_3)) { singleton(&[]) } else { Space::new() };
            drop(v75_3);
            let v75_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v75_4));
            drop(v75_4);
            let v75_8: Space = if (&(v75_5)).is_empty() { Space::new() } else {
              let v76_7: Space = routine_11(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              map_map_kernels::compose(&(v75_5),&(v76_7))
            };
            drop(v75_5);
            let v75_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v75_2));
            drop(v75_2);
            let v75_10: Space = if map_kernels::has_head(&(v75_9)) { singleton(&[]) } else { Space::new() };
            drop(v75_9);
            let v75_12: Space = if (&(v75_10)).is_empty() { Space::new() } else {
              let v77_11: Space = routine_10(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              map_map_kernels::compose(&(v75_10),&(v77_11))
            };
            drop(v75_10);
            let v75_13: Space = map_map_kernels::unite(&(v75_8),&(v75_12));
            join_wrapped_into(&mut v74_11_write,&((v75_13).read_zipper()),&[]);
            }
            v66_26_cursor.ascend(1);
          }
          drop(v74_11_write);
          map_map_kernels::compose(&(v69_10),&(v74_11))
        };
        drop(v69_10);
        let v69_13: Space = map_map_kernels::unite(&(v69_8),&(v69_12));
        join_wrapped_into(&mut v68_6_write,&((v69_13).read_zipper()),&[]);
        }
        v66_26_cursor.ascend(1);
      }
      drop(v68_6_write);
      map_map_kernels::compose(&(v67_5),&(v68_6))
    };
    drop(v67_5);
    let v67_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v67_2));
    drop(v67_2);
    let v67_9: Space = if map_kernels::has_head(&(v67_8)) { singleton(&[]) } else { Space::new() };
    drop(v67_8);
    let v67_12: Space = if (&(v67_9)).is_empty() { Space::new() } else {
      let mut v78_11 = Space::new();
      let mut v78_11_write = v78_11.write_zipper();
      for v78_11_byte in v66_26_cursor.child_mask().iter() {
        v66_26_cursor.descend_to_existing_byte(v78_11_byte);
        {
        let v79_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 1)..(v66_26_origin + 2)]);
        let v79_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v79_2));
        let v79_4: Space = if map_kernels::has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
        drop(v79_3);
        let v79_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v79_4));
        drop(v79_4);
        let v79_8: Space = if (&(v79_5)).is_empty() { Space::new() } else {
          let mut v80_7 = Space::new();
          let mut v80_7_write = v80_7.write_zipper();
          for v80_7_byte in v66_26_cursor.child_mask().iter() {
            v66_26_cursor.descend_to_existing_byte(v80_7_byte);
            {
            let v81_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 2)..(v66_26_origin + 3)]);
            let v81_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v81_2));
            let v81_4: Space = if map_kernels::has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
            drop(v81_3);
            let v81_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v81_4));
            drop(v81_4);
            let v81_8: Space = if (&(v81_5)).is_empty() { Space::new() } else {
              let v82_7: Space = routine_11(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              map_map_kernels::compose(&(v81_5),&(v82_7))
            };
            drop(v81_5);
            let v81_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v81_2));
            drop(v81_2);
            let v81_10: Space = if map_kernels::has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
            drop(v81_9);
            let v81_12: Space = if (&(v81_10)).is_empty() { Space::new() } else {
              let v83_11: Space = routine_12(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              map_map_kernels::compose(&(v81_10),&(v83_11))
            };
            drop(v81_10);
            let v81_13: Space = map_map_kernels::unite(&(v81_8),&(v81_12));
            join_wrapped_into(&mut v80_7_write,&((v81_13).read_zipper()),&[]);
            }
            v66_26_cursor.ascend(1);
          }
          drop(v80_7_write);
          map_map_kernels::compose(&(v79_5),&(v80_7))
        };
        drop(v79_5);
        let v79_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v79_2));
        drop(v79_2);
        let v79_10: Space = if map_kernels::has_head(&(v79_9)) { singleton(&[]) } else { Space::new() };
        drop(v79_9);
        let v79_13: Space = if (&(v79_10)).is_empty() { Space::new() } else {
          let mut v84_12 = Space::new();
          let mut v84_12_write = v84_12.write_zipper();
          let mut v84_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 1)]),&v66_26_cursor.path()[(v66_26_origin + 1)..(v66_26_origin + 2)]);
          let v84_12_origin = v84_12_cursor.path().len();
          for v84_12_byte in v84_12_cursor.child_mask().iter() {
            v84_12_cursor.descend_to_existing_byte(v84_12_byte);
            {
            let v85_2: Space = singleton(&v84_12_cursor.path()[v84_12_origin..(v84_12_origin + 1)]);
            let v85_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v85_2));
            let v85_4: Space = if map_kernels::has_head(&(v85_3)) { singleton(&[]) } else { Space::new() };
            drop(v85_3);
            let v85_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v85_4));
            drop(v85_4);
            let v85_7: Space = if (&(v85_5)).is_empty() { Space::new() } else {
              let v86_6: Space = routine_13(c, &v84_12_cursor.path()[v84_12_origin..(v84_12_origin + 1)], &(*p0), &v84_12_cursor);
              map_map_kernels::compose(&(v85_5),&(v86_6))
            };
            drop(v85_5);
            let v85_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v85_2));
            drop(v85_2);
            let v85_9: Space = if map_kernels::has_head(&(v85_8)) { singleton(&[]) } else { Space::new() };
            drop(v85_8);
            let v85_11: Space = if (&(v85_9)).is_empty() { Space::new() } else {
              let v87_10: Space = routine_14(c, &v84_12_cursor.path()[v84_12_origin..(v84_12_origin + 1)], &(*p0), &v84_12_cursor);
              map_map_kernels::compose(&(v85_9),&(v87_10))
            };
            drop(v85_9);
            let v85_12: Space = map_map_kernels::unite(&(v85_7),&(v85_11));
            join_wrapped_into(&mut v84_12_write,&((v85_12).read_zipper()),&[]);
            }
            v84_12_cursor.ascend(1);
          }
          drop(v84_12_cursor);
          drop(v84_12_write);
          map_map_kernels::compose(&(v79_10),&(v84_12))
        };
        drop(v79_10);
        let v79_14: Space = map_map_kernels::unite(&(v79_8),&(v79_13));
        join_wrapped_into(&mut v78_11_write,&((v79_14).read_zipper()),&[]);
        }
        v66_26_cursor.ascend(1);
      }
      drop(v78_11_write);
      map_map_kernels::compose(&(v67_9),&(v78_11))
    };
    drop(v67_9);
    let v67_13: Space = map_map_kernels::unite(&(v67_7),&(v67_12));
    join_wrapped_into(&mut v66_26_write,&((v67_13).read_zipper()),&[]);
    }
    v66_26_cursor.ascend(1);
  }
  drop(v66_26_cursor);
  drop(v66_26_write);
  (v66_26).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v88_28 = Space::new();
  let mut v88_28_write = v88_28.write_zipper();
  let mut v88_28_cursor = (*s0).read_zipper();
  let v88_28_origin = v88_28_cursor.path().len();
  for v88_28_byte in v88_28_cursor.child_mask().iter() {
    v88_28_cursor.descend_to_existing_byte(v88_28_byte);
    {
    let v89_2: Space = singleton(&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]);
    let v89_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v89_2));
    let v89_4: Space = if map_kernels::has_head(&(v89_3)) { singleton(&[]) } else { Space::new() };
    drop(v89_3);
    let v89_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v89_4));
    drop(v89_4);
    let v89_8: Space = if (&(v89_5)).is_empty() { Space::new() } else {
      let v90_6: Path = concat_path(&(*p0),&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]);
      let mut v90_7 = Space::new();
      let mut v90_7_write = v90_7.write_zipper();
      for v90_7_byte in v88_28_cursor.child_mask().iter() {
        v88_28_cursor.descend_to_existing_byte(v90_7_byte);
        {
        let v91_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
        let v91_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v91_2));
        let v91_4: Space = if map_kernels::has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
        drop(v91_3);
        let v91_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v91_4));
        drop(v91_4);
        let v91_8: Space = if (&(v91_5)).is_empty() { Space::new() } else {
          let v92_6: Path = concat_path(&(v90_6),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let mut v92_7 = Space::new();
          let mut v92_7_write = v92_7.write_zipper();
          for v92_7_byte in v88_28_cursor.child_mask().iter() {
            v88_28_cursor.descend_to_existing_byte(v92_7_byte);
            {
            let v93_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
            let v93_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v93_2));
            let v93_4: Space = if map_kernels::has_head(&(v93_3)) { singleton(&[]) } else { Space::new() };
            drop(v93_3);
            let v93_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v93_4));
            drop(v93_4);
            let v93_8: Space = if (&(v93_5)).is_empty() { Space::new() } else {
              let v94_6: Path = concat_path(&(v92_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v94_7: Space = routine_15(c, &(v94_6), &(*p1), &v88_28_cursor, &(*s1));
              map_map_kernels::compose(&(v93_5),&(v94_7))
            };
            drop(v93_5);
            let v93_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v93_2));
            drop(v93_2);
            let v93_10: Space = if map_kernels::has_head(&(v93_9)) { singleton(&[]) } else { Space::new() };
            drop(v93_9);
            let v93_12: Space = if (&(v93_10)).is_empty() { Space::new() } else {
              let v95_6: Path = concat_path(&(v92_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v95_11: Space = routine_16(c, &(v95_6), &(*p1), &v88_28_cursor, &(*s1));
              drop(v95_6);
              map_map_kernels::compose(&(v93_10),&(v95_11))
            };
            drop(v93_10);
            let v93_13: Space = map_map_kernels::unite(&(v93_8),&(v93_12));
            join_wrapped_into(&mut v92_7_write,&((v93_13).read_zipper()),&[]);
            }
            v88_28_cursor.ascend(1);
          }
          drop(v92_7_write);
          map_map_kernels::compose(&(v91_5),&(v92_7))
        };
        drop(v91_5);
        let v91_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v91_2));
        drop(v91_2);
        let v91_10: Space = if map_kernels::has_head(&(v91_9)) { singleton(&[]) } else { Space::new() };
        drop(v91_9);
        let v91_12: Space = if (&(v91_10)).is_empty() { Space::new() } else {
          let v96_6: Path = concat_path(&(v90_6),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let mut v96_11 = Space::new();
          let mut v96_11_write = v96_11.write_zipper();
          for v96_11_byte in v88_28_cursor.child_mask().iter() {
            v88_28_cursor.descend_to_existing_byte(v96_11_byte);
            {
            let v97_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
            let v97_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v97_2));
            let v97_4: Space = if map_kernels::has_head(&(v97_3)) { singleton(&[]) } else { Space::new() };
            drop(v97_3);
            let v97_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v97_4));
            drop(v97_4);
            let v97_8: Space = if (&(v97_5)).is_empty() { Space::new() } else {
              let v98_6: Path = concat_path(&(v96_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v98_7: Space = routine_15(c, &(v98_6), &(*p1), &v88_28_cursor, &(*s1));
              map_map_kernels::compose(&(v97_5),&(v98_7))
            };
            drop(v97_5);
            let v97_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v97_2));
            drop(v97_2);
            let v97_10: Space = if map_kernels::has_head(&(v97_9)) { singleton(&[]) } else { Space::new() };
            drop(v97_9);
            let v97_12: Space = if (&(v97_10)).is_empty() { Space::new() } else {
              let v99_6: Path = concat_path(&(v96_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v99_11: Space = routine_10(c, &(v99_6), &(*p1), &v88_28_cursor, &(*s1));
              drop(v99_6);
              map_map_kernels::compose(&(v97_10),&(v99_11))
            };
            drop(v97_10);
            let v97_13: Space = map_map_kernels::unite(&(v97_8),&(v97_12));
            join_wrapped_into(&mut v96_11_write,&((v97_13).read_zipper()),&[]);
            }
            v88_28_cursor.ascend(1);
          }
          drop(v96_11_write);
          drop(v96_6);
          map_map_kernels::compose(&(v91_10),&(v96_11))
        };
        drop(v91_10);
        let v91_13: Space = map_map_kernels::unite(&(v91_8),&(v91_12));
        join_wrapped_into(&mut v90_7_write,&((v91_13).read_zipper()),&[]);
        }
        v88_28_cursor.ascend(1);
      }
      drop(v90_7_write);
      map_map_kernels::compose(&(v89_5),&(v90_7))
    };
    drop(v89_5);
    let v89_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v89_2));
    drop(v89_2);
    let v89_10: Space = if map_kernels::has_head(&(v89_9)) { singleton(&[]) } else { Space::new() };
    drop(v89_9);
    let v89_13: Space = if (&(v89_10)).is_empty() { Space::new() } else {
      let v100_6: Path = concat_path(&(*p0),&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]);
      let mut v100_12 = Space::new();
      let mut v100_12_write = v100_12.write_zipper();
      for v100_12_byte in v88_28_cursor.child_mask().iter() {
        v88_28_cursor.descend_to_existing_byte(v100_12_byte);
        {
        let v101_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
        let v101_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v101_2));
        let v101_4: Space = if map_kernels::has_head(&(v101_3)) { singleton(&[]) } else { Space::new() };
        drop(v101_3);
        let v101_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v101_4));
        drop(v101_4);
        let v101_8: Space = if (&(v101_5)).is_empty() { Space::new() } else {
          let v102_6: Path = concat_path(&(v100_6),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let mut v102_7 = Space::new();
          let mut v102_7_write = v102_7.write_zipper();
          for v102_7_byte in v88_28_cursor.child_mask().iter() {
            v88_28_cursor.descend_to_existing_byte(v102_7_byte);
            {
            let v103_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
            let v103_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v103_2));
            let v103_4: Space = if map_kernels::has_head(&(v103_3)) { singleton(&[]) } else { Space::new() };
            drop(v103_3);
            let v103_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v103_4));
            drop(v103_4);
            let v103_8: Space = if (&(v103_5)).is_empty() { Space::new() } else {
              let v104_6: Path = concat_path(&(v102_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v104_7: Space = routine_15(c, &(v104_6), &(*p1), &v88_28_cursor, &(*s1));
              map_map_kernels::compose(&(v103_5),&(v104_7))
            };
            drop(v103_5);
            let v103_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v103_2));
            drop(v103_2);
            let v103_10: Space = if map_kernels::has_head(&(v103_9)) { singleton(&[]) } else { Space::new() };
            drop(v103_9);
            let v103_12: Space = if (&(v103_10)).is_empty() { Space::new() } else {
              let v105_6: Path = concat_path(&(v102_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v105_11: Space = routine_16(c, &(v105_6), &(*p1), &v88_28_cursor, &(*s1));
              drop(v105_6);
              map_map_kernels::compose(&(v103_10),&(v105_11))
            };
            drop(v103_10);
            let v103_13: Space = map_map_kernels::unite(&(v103_8),&(v103_12));
            join_wrapped_into(&mut v102_7_write,&((v103_13).read_zipper()),&[]);
            }
            v88_28_cursor.ascend(1);
          }
          drop(v102_7_write);
          drop(v102_6);
          map_map_kernels::compose(&(v101_5),&(v102_7))
        };
        drop(v101_5);
        let v101_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v101_2));
        drop(v101_2);
        let v101_10: Space = if map_kernels::has_head(&(v101_9)) { singleton(&[]) } else { Space::new() };
        drop(v101_9);
        let v101_13: Space = if (&(v101_10)).is_empty() { Space::new() } else {
          let mut v106_12 = Space::new();
          let mut v106_12_write = v106_12.write_zipper();
          let mut v106_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let v106_12_origin = v106_12_cursor.path().len();
          for v106_12_byte in v106_12_cursor.child_mask().iter() {
            v106_12_cursor.descend_to_existing_byte(v106_12_byte);
            {
            let v107_2: Space = singleton(&v106_12_cursor.path()[v106_12_origin..(v106_12_origin + 1)]);
            let v107_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v107_2));
            let v107_4: Space = if map_kernels::has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
            drop(v107_3);
            let v107_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v107_4));
            drop(v107_4);
            let v107_7: Space = if (&(v107_5)).is_empty() { Space::new() } else {
              let v108_6: Space = routine_13(c, &v106_12_cursor.path()[v106_12_origin..(v106_12_origin + 1)], &(*p1), &v106_12_cursor);
              map_map_kernels::compose(&(v107_5),&(v108_6))
            };
            drop(v107_5);
            let v107_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v107_2));
            drop(v107_2);
            let v107_9: Space = if map_kernels::has_head(&(v107_8)) { singleton(&[]) } else { Space::new() };
            drop(v107_8);
            let v107_11: Space = if (&(v107_9)).is_empty() { Space::new() } else {
              let v109_10: Space = routine_14(c, &v106_12_cursor.path()[v106_12_origin..(v106_12_origin + 1)], &(*p1), &v106_12_cursor);
              map_map_kernels::compose(&(v107_9),&(v109_10))
            };
            drop(v107_9);
            let v107_12: Space = map_map_kernels::unite(&(v107_7),&(v107_11));
            join_wrapped_into(&mut v106_12_write,&((v107_12).read_zipper()),&[]);
            }
            v106_12_cursor.ascend(1);
          }
          drop(v106_12_cursor);
          drop(v106_12_write);
          map_map_kernels::compose(&(v101_10),&(v106_12))
        };
        drop(v101_10);
        let v101_14: Space = map_map_kernels::unite(&(v101_8),&(v101_13));
        join_wrapped_into(&mut v100_12_write,&((v101_14).read_zipper()),&[]);
        }
        v88_28_cursor.ascend(1);
      }
      drop(v100_12_write);
      drop(v100_6);
      map_map_kernels::compose(&(v89_10),&(v100_12))
    };
    drop(v89_10);
    let v89_14: Space = map_map_kernels::unite(&(v89_8),&(v89_13));
    join_wrapped_into(&mut v88_28_write,&((v89_14).read_zipper()),&[]);
    }
    v88_28_cursor.ascend(1);
  }
  drop(v88_28_cursor);
  drop(v88_28_write);
  (v88_28).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v110_28 = Space::new();
  let mut v110_28_write = v110_28.write_zipper();
  let mut v110_28_cursor = (*s0).read_zipper();
  let v110_28_origin = v110_28_cursor.path().len();
  for v110_28_byte in v110_28_cursor.child_mask().iter() {
    v110_28_cursor.descend_to_existing_byte(v110_28_byte);
    {
    let v111_2: Space = singleton(&v110_28_cursor.path()[v110_28_origin..(v110_28_origin + 1)]);
    let v111_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v111_2));
    let v111_4: Space = if map_kernels::has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
    drop(v111_3);
    let v111_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v111_4));
    drop(v111_4);
    let v111_8: Space = if (&(v111_5)).is_empty() { Space::new() } else {
      let v112_6: Path = concat_path(&(*p0),&v110_28_cursor.path()[v110_28_origin..(v110_28_origin + 1)]);
      let mut v112_7 = Space::new();
      let mut v112_7_write = v112_7.write_zipper();
      for v112_7_byte in v110_28_cursor.child_mask().iter() {
        v110_28_cursor.descend_to_existing_byte(v112_7_byte);
        {
        let v113_2: Space = singleton(&v110_28_cursor.path()[(v110_28_origin + 1)..(v110_28_origin + 2)]);
        let v113_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v113_2));
        let v113_4: Space = if map_kernels::has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
        drop(v113_3);
        let v113_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v113_4));
        drop(v113_4);
        let v113_8: Space = if (&(v113_5)).is_empty() { Space::new() } else {
          let v114_6: Path = concat_path(&(v112_6),&v110_28_cursor.path()[(v110_28_origin + 1)..(v110_28_origin + 2)]);
          let mut v114_7 = Space::new();
          let mut v114_7_write = v114_7.write_zipper();
          for v114_7_byte in v110_28_cursor.child_mask().iter() {
            v110_28_cursor.descend_to_existing_byte(v114_7_byte);
            {
            let v115_2: Space = singleton(&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
            let v115_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v115_2));
            let v115_4: Space = if map_kernels::has_head(&(v115_3)) { singleton(&[]) } else { Space::new() };
            drop(v115_3);
            let v115_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v115_4));
            drop(v115_4);
            let v115_8: Space = if (&(v115_5)).is_empty() { Space::new() } else {
              let v116_6: Path = concat_path(&(v114_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v116_7: Space = routine_15(c, &(v116_6), &(*p1), &v110_28_cursor, &(*s1));
              map_map_kernels::compose(&(v115_5),&(v116_7))
            };
            drop(v115_5);
            let v115_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v115_2));
            drop(v115_2);
            let v115_10: Space = if map_kernels::has_head(&(v115_9)) { singleton(&[]) } else { Space::new() };
            drop(v115_9);
            let v115_12: Space = if (&(v115_10)).is_empty() { Space::new() } else {
              let v117_6: Path = concat_path(&(v114_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v117_11: Space = routine_16(c, &(v117_6), &(*p1), &v110_28_cursor, &(*s1));
              drop(v117_6);
              map_map_kernels::compose(&(v115_10),&(v117_11))
            };
            drop(v115_10);
            let v115_13: Space = map_map_kernels::unite(&(v115_8),&(v115_12));
            join_wrapped_into(&mut v114_7_write,&((v115_13).read_zipper()),&[]);
            }
            v110_28_cursor.ascend(1);
          }
          drop(v114_7_write);
          map_map_kernels::compose(&(v113_5),&(v114_7))
        };
        drop(v113_5);
        let v113_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v113_2));
        drop(v113_2);
        let v113_10: Space = if map_kernels::has_head(&(v113_9)) { singleton(&[]) } else { Space::new() };
        drop(v113_9);
        let v113_12: Space = if (&(v113_10)).is_empty() { Space::new() } else {
          let v118_6: Path = concat_path(&(v112_6),&v110_28_cursor.path()[(v110_28_origin + 1)..(v110_28_origin + 2)]);
          let mut v118_11 = Space::new();
          let mut v118_11_write = v118_11.write_zipper();
          for v118_11_byte in v110_28_cursor.child_mask().iter() {
            v110_28_cursor.descend_to_existing_byte(v118_11_byte);
            {
            let v119_2: Space = singleton(&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
            let v119_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v119_2));
            let v119_4: Space = if map_kernels::has_head(&(v119_3)) { singleton(&[]) } else { Space::new() };
            drop(v119_3);
            let v119_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v119_4));
            drop(v119_4);
            let v119_8: Space = if (&(v119_5)).is_empty() { Space::new() } else {
              let v120_6: Path = concat_path(&(v118_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v120_7: Space = routine_15(c, &(v120_6), &(*p1), &v110_28_cursor, &(*s1));
              map_map_kernels::compose(&(v119_5),&(v120_7))
            };
            drop(v119_5);
            let v119_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v119_2));
            drop(v119_2);
            let v119_10: Space = if map_kernels::has_head(&(v119_9)) { singleton(&[]) } else { Space::new() };
            drop(v119_9);
            let v119_12: Space = if (&(v119_10)).is_empty() { Space::new() } else {
              let v121_6: Path = concat_path(&(v118_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v121_11: Space = routine_10(c, &(v121_6), &(*p1), &v110_28_cursor, &(*s1));
              drop(v121_6);
              map_map_kernels::compose(&(v119_10),&(v121_11))
            };
            drop(v119_10);
            let v119_13: Space = map_map_kernels::unite(&(v119_8),&(v119_12));
            join_wrapped_into(&mut v118_11_write,&((v119_13).read_zipper()),&[]);
            }
            v110_28_cursor.ascend(1);
          }
          drop(v118_11_write);
          drop(v118_6);
          map_map_kernels::compose(&(v113_10),&(v118_11))
        };
        drop(v113_10);
        let v113_13: Space = map_map_kernels::unite(&(v113_8),&(v113_12));
        join_wrapped_into(&mut v112_7_write,&((v113_13).read_zipper()),&[]);
        }
        v110_28_cursor.ascend(1);
      }
      drop(v112_7_write);
      drop(v112_6);
      map_map_kernels::compose(&(v111_5),&(v112_7))
    };
    drop(v111_5);
    let v111_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v111_2));
    drop(v111_2);
    let v111_10: Space = if map_kernels::has_head(&(v111_9)) { singleton(&[]) } else { Space::new() };
    drop(v111_9);
    let v111_13: Space = if (&(v111_10)).is_empty() { Space::new() } else {
      let mut v122_12 = Space::new();
      let mut v122_12_write = v122_12.write_zipper();
      let mut v122_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v110_28_cursor.path()[v110_28_origin..(v110_28_origin + 1)]);
      let v122_12_origin = v122_12_cursor.path().len();
      for v122_12_byte in v122_12_cursor.child_mask().iter() {
        v122_12_cursor.descend_to_existing_byte(v122_12_byte);
        {
        let v123_2: Space = singleton(&v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 1)]);
        let v123_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v123_2));
        let v123_4: Space = if map_kernels::has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v123_4));
        drop(v123_4);
        let v123_7: Space = if (&(v123_5)).is_empty() { Space::new() } else {
          let mut v124_6 = Space::new();
          let mut v124_6_write = v124_6.write_zipper();
          for v124_6_byte in v122_12_cursor.child_mask().iter() {
            v122_12_cursor.descend_to_existing_byte(v124_6_byte);
            {
            let v125_2: Space = singleton(&v122_12_cursor.path()[(v122_12_origin + 1)..(v122_12_origin + 2)]);
            let v125_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v125_2));
            let v125_4: Space = if map_kernels::has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
            drop(v125_3);
            let v125_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v125_4));
            drop(v125_4);
            let v125_8: Space = if (&(v125_5)).is_empty() { Space::new() } else {
              let v126_7: Space = routine_17(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              map_map_kernels::compose(&(v125_5),&(v126_7))
            };
            drop(v125_5);
            let v125_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v125_2));
            drop(v125_2);
            let v125_10: Space = if map_kernels::has_head(&(v125_9)) { singleton(&[]) } else { Space::new() };
            drop(v125_9);
            let v125_12: Space = if (&(v125_10)).is_empty() { Space::new() } else {
              let v127_11: Space = routine_18(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              map_map_kernels::compose(&(v125_10),&(v127_11))
            };
            drop(v125_10);
            let v125_13: Space = map_map_kernels::unite(&(v125_8),&(v125_12));
            join_wrapped_into(&mut v124_6_write,&((v125_13).read_zipper()),&[]);
            }
            v122_12_cursor.ascend(1);
          }
          drop(v124_6_write);
          map_map_kernels::compose(&(v123_5),&(v124_6))
        };
        drop(v123_5);
        let v123_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v123_2));
        drop(v123_2);
        let v123_9: Space = if map_kernels::has_head(&(v123_8)) { singleton(&[]) } else { Space::new() };
        drop(v123_8);
        let v123_11: Space = if (&(v123_9)).is_empty() { Space::new() } else {
          let mut v128_10 = Space::new();
          let mut v128_10_write = v128_10.write_zipper();
          for v128_10_byte in v122_12_cursor.child_mask().iter() {
            v122_12_cursor.descend_to_existing_byte(v128_10_byte);
            {
            let v129_2: Space = singleton(&v122_12_cursor.path()[(v122_12_origin + 1)..(v122_12_origin + 2)]);
            let v129_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v129_2));
            let v129_4: Space = if map_kernels::has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
            drop(v129_3);
            let v129_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v129_4));
            drop(v129_4);
            let v129_8: Space = if (&(v129_5)).is_empty() { Space::new() } else {
              let v130_7: Space = routine_17(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              map_map_kernels::compose(&(v129_5),&(v130_7))
            };
            drop(v129_5);
            let v129_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v129_2));
            drop(v129_2);
            let v129_10: Space = if map_kernels::has_head(&(v129_9)) { singleton(&[]) } else { Space::new() };
            drop(v129_9);
            let v129_12: Space = if (&(v129_10)).is_empty() { Space::new() } else {
              let v131_11: Space = routine_19(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              map_map_kernels::compose(&(v129_10),&(v131_11))
            };
            drop(v129_10);
            let v129_13: Space = map_map_kernels::unite(&(v129_8),&(v129_12));
            join_wrapped_into(&mut v128_10_write,&((v129_13).read_zipper()),&[]);
            }
            v122_12_cursor.ascend(1);
          }
          drop(v128_10_write);
          map_map_kernels::compose(&(v123_9),&(v128_10))
        };
        drop(v123_9);
        let v123_12: Space = map_map_kernels::unite(&(v123_7),&(v123_11));
        join_wrapped_into(&mut v122_12_write,&((v123_12).read_zipper()),&[]);
        }
        v122_12_cursor.ascend(1);
      }
      drop(v122_12_cursor);
      drop(v122_12_write);
      map_map_kernels::compose(&(v111_10),&(v122_12))
    };
    drop(v111_10);
    let v111_14: Space = map_map_kernels::unite(&(v111_8),&(v111_13));
    join_wrapped_into(&mut v110_28_write,&((v111_14).read_zipper()),&[]);
    }
    v110_28_cursor.ascend(1);
  }
  drop(v110_28_cursor);
  drop(v110_28_write);
  (v110_28).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v132_24 = Space::new();
  let mut v132_24_write = v132_24.write_zipper();
  let mut v132_24_cursor = (*s0).read_zipper();
  let v132_24_origin = v132_24_cursor.path().len();
  for v132_24_byte in v132_24_cursor.child_mask().iter() {
    v132_24_cursor.descend_to_existing_byte(v132_24_byte);
    {
    let v133_2: Space = singleton(&v132_24_cursor.path()[v132_24_origin..(v132_24_origin + 1)]);
    let v133_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v133_2));
    let v133_4: Space = if map_kernels::has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
    drop(v133_3);
    let v133_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v133_4));
    drop(v133_4);
    let v133_8: Space = if (&(v133_5)).is_empty() { Space::new() } else {
      let v134_6: Path = concat_path(&(*p0),&v132_24_cursor.path()[v132_24_origin..(v132_24_origin + 1)]);
      let mut v134_7 = Space::new();
      let mut v134_7_write = v134_7.write_zipper();
      for v134_7_byte in v132_24_cursor.child_mask().iter() {
        v132_24_cursor.descend_to_existing_byte(v134_7_byte);
        {
        let v135_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
        let v135_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v135_2));
        let v135_4: Space = if map_kernels::has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
        drop(v135_3);
        let v135_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v135_4));
        drop(v135_4);
        let v135_8: Space = if (&(v135_5)).is_empty() { Space::new() } else {
          let v136_6: Path = concat_path(&(v134_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v136_7 = Space::new();
          let mut v136_7_write = v136_7.write_zipper();
          for v136_7_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v136_7_byte);
            {
            let v137_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v137_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v137_2));
            let v137_4: Space = if map_kernels::has_head(&(v137_3)) { singleton(&[]) } else { Space::new() };
            drop(v137_3);
            let v137_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v137_4));
            drop(v137_4);
            let v137_8: Space = if (&(v137_5)).is_empty() { Space::new() } else {
              let v138_6: Path = concat_path(&(v136_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v138_7: Space = routine_20(c, &(v138_6), &v132_24_cursor, &(*s1));
              map_map_kernels::compose(&(v137_5),&(v138_7))
            };
            drop(v137_5);
            let v137_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v137_2));
            drop(v137_2);
            let v137_10: Space = if map_kernels::has_head(&(v137_9)) { singleton(&[]) } else { Space::new() };
            drop(v137_9);
            let v137_12: Space = if (&(v137_10)).is_empty() { Space::new() } else {
              let v139_6: Path = concat_path(&(v136_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v139_11: Space = routine_21(c, &(v139_6), &v132_24_cursor, &(*s1));
              drop(v139_6);
              map_map_kernels::compose(&(v137_10),&(v139_11))
            };
            drop(v137_10);
            let v137_13: Space = map_map_kernels::unite(&(v137_8),&(v137_12));
            join_wrapped_into(&mut v136_7_write,&((v137_13).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v136_7_write);
          map_map_kernels::compose(&(v135_5),&(v136_7))
        };
        drop(v135_5);
        let v135_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v135_2));
        drop(v135_2);
        let v135_10: Space = if map_kernels::has_head(&(v135_9)) { singleton(&[]) } else { Space::new() };
        drop(v135_9);
        let v135_12: Space = if (&(v135_10)).is_empty() { Space::new() } else {
          let v140_6: Path = concat_path(&(v134_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v140_11 = Space::new();
          let mut v140_11_write = v140_11.write_zipper();
          for v140_11_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v140_11_byte);
            {
            let v141_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v141_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v141_2));
            let v141_4: Space = if map_kernels::has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
            drop(v141_3);
            let v141_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v141_4));
            drop(v141_4);
            let v141_8: Space = if (&(v141_5)).is_empty() { Space::new() } else {
              let v142_6: Path = concat_path(&(v140_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v142_7: Space = routine_20(c, &(v142_6), &v132_24_cursor, &(*s1));
              map_map_kernels::compose(&(v141_5),&(v142_7))
            };
            drop(v141_5);
            let v141_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v141_2));
            drop(v141_2);
            let v141_10: Space = if map_kernels::has_head(&(v141_9)) { singleton(&[]) } else { Space::new() };
            drop(v141_9);
            let v141_12: Space = if (&(v141_10)).is_empty() { Space::new() } else {
              let v143_6: Path = concat_path(&(v140_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v143_11: Space = routine_3(c, &(v143_6), &v132_24_cursor, &(*s1));
              drop(v143_6);
              map_map_kernels::compose(&(v141_10),&(v143_11))
            };
            drop(v141_10);
            let v141_13: Space = map_map_kernels::unite(&(v141_8),&(v141_12));
            join_wrapped_into(&mut v140_11_write,&((v141_13).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v140_11_write);
          drop(v140_6);
          map_map_kernels::compose(&(v135_10),&(v140_11))
        };
        drop(v135_10);
        let v135_13: Space = map_map_kernels::unite(&(v135_8),&(v135_12));
        join_wrapped_into(&mut v134_7_write,&((v135_13).read_zipper()),&[]);
        }
        v132_24_cursor.ascend(1);
      }
      drop(v134_7_write);
      map_map_kernels::compose(&(v133_5),&(v134_7))
    };
    drop(v133_5);
    let v133_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v133_2));
    drop(v133_2);
    let v133_10: Space = if map_kernels::has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
    drop(v133_9);
    let v133_12: Space = if (&(v133_10)).is_empty() { Space::new() } else {
      let v144_6: Path = concat_path(&(*p0),&v132_24_cursor.path()[v132_24_origin..(v132_24_origin + 1)]);
      let mut v144_11 = Space::new();
      let mut v144_11_write = v144_11.write_zipper();
      for v144_11_byte in v132_24_cursor.child_mask().iter() {
        v132_24_cursor.descend_to_existing_byte(v144_11_byte);
        {
        let v145_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
        let v145_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v145_2));
        let v145_4: Space = if map_kernels::has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
        drop(v145_3);
        let v145_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v145_4));
        drop(v145_4);
        let v145_8: Space = if (&(v145_5)).is_empty() { Space::new() } else {
          let v146_6: Path = concat_path(&(v144_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v146_7 = Space::new();
          let mut v146_7_write = v146_7.write_zipper();
          for v146_7_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v146_7_byte);
            {
            let v147_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v147_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v147_2));
            let v147_4: Space = if map_kernels::has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
            drop(v147_3);
            let v147_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v147_4));
            drop(v147_4);
            let v147_8: Space = if (&(v147_5)).is_empty() { Space::new() } else {
              let v148_6: Path = concat_path(&(v146_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v148_7: Space = routine_20(c, &(v148_6), &v132_24_cursor, &(*s1));
              map_map_kernels::compose(&(v147_5),&(v148_7))
            };
            drop(v147_5);
            let v147_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v147_2));
            drop(v147_2);
            let v147_10: Space = if map_kernels::has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
            drop(v147_9);
            let v147_12: Space = if (&(v147_10)).is_empty() { Space::new() } else {
              let v149_6: Path = concat_path(&(v146_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v149_11: Space = routine_21(c, &(v149_6), &v132_24_cursor, &(*s1));
              drop(v149_6);
              map_map_kernels::compose(&(v147_10),&(v149_11))
            };
            drop(v147_10);
            let v147_13: Space = map_map_kernels::unite(&(v147_8),&(v147_12));
            join_wrapped_into(&mut v146_7_write,&((v147_13).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v146_7_write);
          map_map_kernels::compose(&(v145_5),&(v146_7))
        };
        drop(v145_5);
        let v145_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v145_2));
        drop(v145_2);
        let v145_10: Space = if map_kernels::has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
        drop(v145_9);
        let v145_12: Space = if (&(v145_10)).is_empty() { Space::new() } else {
          let v150_6: Path = concat_path(&(v144_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v150_11 = Space::new();
          let mut v150_11_write = v150_11.write_zipper();
          for v150_11_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v150_11_byte);
            {
            let v151_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v151_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v151_2));
            let v151_4: Space = if map_kernels::has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
            drop(v151_3);
            let v151_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v151_4));
            drop(v151_4);
            let v151_7: Space = if (&(v151_5)).is_empty() { Space::new() } else {
              let v152_6: Space = routine_4(c, &v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)], &(v150_6), &v132_24_cursor, &(*s1));
              map_map_kernels::compose(&(v151_5),&(v152_6))
            };
            drop(v151_5);
            let v151_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v151_2));
            drop(v151_2);
            let v151_9: Space = if map_kernels::has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
            drop(v151_8);
            let v151_11: Space = if (&(v151_9)).is_empty() { Space::new() } else {
              let v153_10: Space = routine_5(c, &v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)], &(v150_6), &v132_24_cursor, &(*s1));
              map_map_kernels::compose(&(v151_9),&(v153_10))
            };
            drop(v151_9);
            let v151_12: Space = map_map_kernels::unite(&(v151_7),&(v151_11));
            join_wrapped_into(&mut v150_11_write,&((v151_12).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v150_11_write);
          drop(v150_6);
          map_map_kernels::compose(&(v145_10),&(v150_11))
        };
        drop(v145_10);
        let v145_13: Space = map_map_kernels::unite(&(v145_8),&(v145_12));
        join_wrapped_into(&mut v144_11_write,&((v145_13).read_zipper()),&[]);
        }
        v132_24_cursor.ascend(1);
      }
      drop(v144_11_write);
      drop(v144_6);
      map_map_kernels::compose(&(v133_10),&(v144_11))
    };
    drop(v133_10);
    let v133_13: Space = map_map_kernels::unite(&(v133_8),&(v133_12));
    join_wrapped_into(&mut v132_24_write,&((v133_13).read_zipper()),&[]);
    }
    v132_24_cursor.ascend(1);
  }
  drop(v132_24_cursor);
  drop(v132_24_write);
  (v132_24).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v154_24 = Space::new();
  let mut v154_24_write = v154_24.write_zipper();
  let mut v154_24_cursor = (*s0).read_zipper();
  let v154_24_origin = v154_24_cursor.path().len();
  for v154_24_byte in v154_24_cursor.child_mask().iter() {
    v154_24_cursor.descend_to_existing_byte(v154_24_byte);
    {
    let v155_2: Space = singleton(&v154_24_cursor.path()[v154_24_origin..(v154_24_origin + 1)]);
    let v155_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v155_2));
    let v155_4: Space = if map_kernels::has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
    drop(v155_3);
    let v155_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v155_4));
    drop(v155_4);
    let v155_8: Space = if (&(v155_5)).is_empty() { Space::new() } else {
      let v156_6: Path = concat_path(&(*p0),&v154_24_cursor.path()[v154_24_origin..(v154_24_origin + 1)]);
      let mut v156_7 = Space::new();
      let mut v156_7_write = v156_7.write_zipper();
      for v156_7_byte in v154_24_cursor.child_mask().iter() {
        v154_24_cursor.descend_to_existing_byte(v156_7_byte);
        {
        let v157_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
        let v157_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v157_2));
        let v157_4: Space = if map_kernels::has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
        drop(v157_3);
        let v157_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v157_4));
        drop(v157_4);
        let v157_8: Space = if (&(v157_5)).is_empty() { Space::new() } else {
          let v158_6: Path = concat_path(&(v156_6),&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
          let mut v158_7 = Space::new();
          let mut v158_7_write = v158_7.write_zipper();
          for v158_7_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v158_7_byte);
            {
            let v159_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v159_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v159_2));
            let v159_4: Space = if map_kernels::has_head(&(v159_3)) { singleton(&[]) } else { Space::new() };
            drop(v159_3);
            let v159_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v159_4));
            drop(v159_4);
            let v159_8: Space = if (&(v159_5)).is_empty() { Space::new() } else {
              let v160_6: Path = concat_path(&(v158_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v160_7: Space = routine_20(c, &(v160_6), &v154_24_cursor, &(*s1));
              map_map_kernels::compose(&(v159_5),&(v160_7))
            };
            drop(v159_5);
            let v159_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v159_2));
            drop(v159_2);
            let v159_10: Space = if map_kernels::has_head(&(v159_9)) { singleton(&[]) } else { Space::new() };
            drop(v159_9);
            let v159_12: Space = if (&(v159_10)).is_empty() { Space::new() } else {
              let v161_6: Path = concat_path(&(v158_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v161_11: Space = routine_21(c, &(v161_6), &v154_24_cursor, &(*s1));
              drop(v161_6);
              map_map_kernels::compose(&(v159_10),&(v161_11))
            };
            drop(v159_10);
            let v159_13: Space = map_map_kernels::unite(&(v159_8),&(v159_12));
            join_wrapped_into(&mut v158_7_write,&((v159_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v158_7_write);
          map_map_kernels::compose(&(v157_5),&(v158_7))
        };
        drop(v157_5);
        let v157_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v157_2));
        drop(v157_2);
        let v157_10: Space = if map_kernels::has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
        drop(v157_9);
        let v157_12: Space = if (&(v157_10)).is_empty() { Space::new() } else {
          let v162_6: Path = concat_path(&(v156_6),&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
          let mut v162_11 = Space::new();
          let mut v162_11_write = v162_11.write_zipper();
          for v162_11_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v162_11_byte);
            {
            let v163_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v163_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v163_2));
            let v163_4: Space = if map_kernels::has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
            drop(v163_3);
            let v163_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v163_4));
            drop(v163_4);
            let v163_8: Space = if (&(v163_5)).is_empty() { Space::new() } else {
              let v164_6: Path = concat_path(&(v162_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v164_7: Space = routine_20(c, &(v164_6), &v154_24_cursor, &(*s1));
              map_map_kernels::compose(&(v163_5),&(v164_7))
            };
            drop(v163_5);
            let v163_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v163_2));
            drop(v163_2);
            let v163_10: Space = if map_kernels::has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
            drop(v163_9);
            let v163_12: Space = if (&(v163_10)).is_empty() { Space::new() } else {
              let v165_6: Path = concat_path(&(v162_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v165_11: Space = routine_3(c, &(v165_6), &v154_24_cursor, &(*s1));
              drop(v165_6);
              map_map_kernels::compose(&(v163_10),&(v165_11))
            };
            drop(v163_10);
            let v163_13: Space = map_map_kernels::unite(&(v163_8),&(v163_12));
            join_wrapped_into(&mut v162_11_write,&((v163_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v162_11_write);
          drop(v162_6);
          map_map_kernels::compose(&(v157_10),&(v162_11))
        };
        drop(v157_10);
        let v157_13: Space = map_map_kernels::unite(&(v157_8),&(v157_12));
        join_wrapped_into(&mut v156_7_write,&((v157_13).read_zipper()),&[]);
        }
        v154_24_cursor.ascend(1);
      }
      drop(v156_7_write);
      map_map_kernels::compose(&(v155_5),&(v156_7))
    };
    drop(v155_5);
    let v155_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v155_2));
    drop(v155_2);
    let v155_10: Space = if map_kernels::has_head(&(v155_9)) { singleton(&[]) } else { Space::new() };
    drop(v155_9);
    let v155_12: Space = if (&(v155_10)).is_empty() { Space::new() } else {
      let v166_6: Path = concat_path(&(*p0),&v154_24_cursor.path()[v154_24_origin..(v154_24_origin + 1)]);
      let mut v166_11 = Space::new();
      let mut v166_11_write = v166_11.write_zipper();
      for v166_11_byte in v154_24_cursor.child_mask().iter() {
        v154_24_cursor.descend_to_existing_byte(v166_11_byte);
        {
        let v167_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
        let v167_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v167_2));
        let v167_4: Space = if map_kernels::has_head(&(v167_3)) { singleton(&[]) } else { Space::new() };
        drop(v167_3);
        let v167_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v167_4));
        drop(v167_4);
        let v167_7: Space = if (&(v167_5)).is_empty() { Space::new() } else {
          let mut v168_6 = Space::new();
          let mut v168_6_write = v168_6.write_zipper();
          for v168_6_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v168_6_byte);
            {
            let v169_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v169_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v169_2));
            let v169_4: Space = if map_kernels::has_head(&(v169_3)) { singleton(&[]) } else { Space::new() };
            drop(v169_3);
            let v169_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v169_4));
            drop(v169_4);
            let v169_8: Space = if (&(v169_5)).is_empty() { Space::new() } else {
              let v170_7: Space = routine_8(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              map_map_kernels::compose(&(v169_5),&(v170_7))
            };
            drop(v169_5);
            let v169_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v169_2));
            drop(v169_2);
            let v169_10: Space = if map_kernels::has_head(&(v169_9)) { singleton(&[]) } else { Space::new() };
            drop(v169_9);
            let v169_12: Space = if (&(v169_10)).is_empty() { Space::new() } else {
              let v171_11: Space = routine_9(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              map_map_kernels::compose(&(v169_10),&(v171_11))
            };
            drop(v169_10);
            let v169_13: Space = map_map_kernels::unite(&(v169_8),&(v169_12));
            join_wrapped_into(&mut v168_6_write,&((v169_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v168_6_write);
          map_map_kernels::compose(&(v167_5),&(v168_6))
        };
        drop(v167_5);
        let v167_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v167_2));
        drop(v167_2);
        let v167_9: Space = if map_kernels::has_head(&(v167_8)) { singleton(&[]) } else { Space::new() };
        drop(v167_8);
        let v167_11: Space = if (&(v167_9)).is_empty() { Space::new() } else {
          let mut v172_10 = Space::new();
          let mut v172_10_write = v172_10.write_zipper();
          for v172_10_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v172_10_byte);
            {
            let v173_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v173_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v173_2));
            let v173_4: Space = if map_kernels::has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
            drop(v173_3);
            let v173_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v173_4));
            drop(v173_4);
            let v173_8: Space = if (&(v173_5)).is_empty() { Space::new() } else {
              let v174_7: Space = routine_8(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              map_map_kernels::compose(&(v173_5),&(v174_7))
            };
            drop(v173_5);
            let v173_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v173_2));
            drop(v173_2);
            let v173_10: Space = if map_kernels::has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
            drop(v173_9);
            let v173_12: Space = if (&(v173_10)).is_empty() { Space::new() } else {
              let v175_11: Space = routine_10(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              map_map_kernels::compose(&(v173_10),&(v175_11))
            };
            drop(v173_10);
            let v173_13: Space = map_map_kernels::unite(&(v173_8),&(v173_12));
            join_wrapped_into(&mut v172_10_write,&((v173_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v172_10_write);
          map_map_kernels::compose(&(v167_9),&(v172_10))
        };
        drop(v167_9);
        let v167_12: Space = map_map_kernels::unite(&(v167_7),&(v167_11));
        join_wrapped_into(&mut v166_11_write,&((v167_12).read_zipper()),&[]);
        }
        v154_24_cursor.ascend(1);
      }
      drop(v166_11_write);
      drop(v166_6);
      map_map_kernels::compose(&(v155_10),&(v166_11))
    };
    drop(v155_10);
    let v155_13: Space = map_map_kernels::unite(&(v155_8),&(v155_12));
    join_wrapped_into(&mut v154_24_write,&((v155_13).read_zipper()),&[]);
    }
    v154_24_cursor.ascend(1);
  }
  drop(v154_24_cursor);
  drop(v154_24_write);
  (v154_24).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v176_28 = Space::new();
  let mut v176_28_write = v176_28.write_zipper();
  let mut v176_28_cursor = (*s0).read_zipper();
  let v176_28_origin = v176_28_cursor.path().len();
  for v176_28_byte in v176_28_cursor.child_mask().iter() {
    v176_28_cursor.descend_to_existing_byte(v176_28_byte);
    {
    let v177_2: Space = singleton(&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]);
    let v177_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v177_2));
    let v177_4: Space = if map_kernels::has_head(&(v177_3)) { singleton(&[]) } else { Space::new() };
    drop(v177_3);
    let v177_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v177_4));
    drop(v177_4);
    let v177_8: Space = if (&(v177_5)).is_empty() { Space::new() } else {
      let v178_6: Path = concat_path(&(*p0),&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]);
      let mut v178_7 = Space::new();
      let mut v178_7_write = v178_7.write_zipper();
      for v178_7_byte in v176_28_cursor.child_mask().iter() {
        v176_28_cursor.descend_to_existing_byte(v178_7_byte);
        {
        let v179_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
        let v179_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v179_2));
        let v179_4: Space = if map_kernels::has_head(&(v179_3)) { singleton(&[]) } else { Space::new() };
        drop(v179_3);
        let v179_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v179_4));
        drop(v179_4);
        let v179_8: Space = if (&(v179_5)).is_empty() { Space::new() } else {
          let v180_6: Path = concat_path(&(v178_6),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let mut v180_7 = Space::new();
          let mut v180_7_write = v180_7.write_zipper();
          for v180_7_byte in v176_28_cursor.child_mask().iter() {
            v176_28_cursor.descend_to_existing_byte(v180_7_byte);
            {
            let v181_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
            let v181_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v181_2));
            let v181_4: Space = if map_kernels::has_head(&(v181_3)) { singleton(&[]) } else { Space::new() };
            drop(v181_3);
            let v181_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v181_4));
            drop(v181_4);
            let v181_8: Space = if (&(v181_5)).is_empty() { Space::new() } else {
              let v182_6: Path = concat_path(&(v180_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v182_7: Space = routine_22(c, &(v182_6), &(*p1), &v176_28_cursor, &(*s1));
              map_map_kernels::compose(&(v181_5),&(v182_7))
            };
            drop(v181_5);
            let v181_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v181_2));
            drop(v181_2);
            let v181_10: Space = if map_kernels::has_head(&(v181_9)) { singleton(&[]) } else { Space::new() };
            drop(v181_9);
            let v181_12: Space = if (&(v181_10)).is_empty() { Space::new() } else {
              let v183_6: Path = concat_path(&(v180_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v183_11: Space = routine_23(c, &(v183_6), &(*p1), &v176_28_cursor, &(*s1));
              drop(v183_6);
              map_map_kernels::compose(&(v181_10),&(v183_11))
            };
            drop(v181_10);
            let v181_13: Space = map_map_kernels::unite(&(v181_8),&(v181_12));
            join_wrapped_into(&mut v180_7_write,&((v181_13).read_zipper()),&[]);
            }
            v176_28_cursor.ascend(1);
          }
          drop(v180_7_write);
          map_map_kernels::compose(&(v179_5),&(v180_7))
        };
        drop(v179_5);
        let v179_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v179_2));
        drop(v179_2);
        let v179_10: Space = if map_kernels::has_head(&(v179_9)) { singleton(&[]) } else { Space::new() };
        drop(v179_9);
        let v179_12: Space = if (&(v179_10)).is_empty() { Space::new() } else {
          let v184_6: Path = concat_path(&(v178_6),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let mut v184_11 = Space::new();
          let mut v184_11_write = v184_11.write_zipper();
          for v184_11_byte in v176_28_cursor.child_mask().iter() {
            v176_28_cursor.descend_to_existing_byte(v184_11_byte);
            {
            let v185_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
            let v185_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v185_2));
            let v185_4: Space = if map_kernels::has_head(&(v185_3)) { singleton(&[]) } else { Space::new() };
            drop(v185_3);
            let v185_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v185_4));
            drop(v185_4);
            let v185_8: Space = if (&(v185_5)).is_empty() { Space::new() } else {
              let v186_6: Path = concat_path(&(v184_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v186_7: Space = routine_22(c, &(v186_6), &(*p1), &v176_28_cursor, &(*s1));
              map_map_kernels::compose(&(v185_5),&(v186_7))
            };
            drop(v185_5);
            let v185_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v185_2));
            drop(v185_2);
            let v185_10: Space = if map_kernels::has_head(&(v185_9)) { singleton(&[]) } else { Space::new() };
            drop(v185_9);
            let v185_12: Space = if (&(v185_10)).is_empty() { Space::new() } else {
              let v187_6: Path = concat_path(&(v184_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v187_11: Space = routine_10(c, &(v187_6), &(*p1), &v176_28_cursor, &(*s1));
              drop(v187_6);
              map_map_kernels::compose(&(v185_10),&(v187_11))
            };
            drop(v185_10);
            let v185_13: Space = map_map_kernels::unite(&(v185_8),&(v185_12));
            join_wrapped_into(&mut v184_11_write,&((v185_13).read_zipper()),&[]);
            }
            v176_28_cursor.ascend(1);
          }
          drop(v184_11_write);
          drop(v184_6);
          map_map_kernels::compose(&(v179_10),&(v184_11))
        };
        drop(v179_10);
        let v179_13: Space = map_map_kernels::unite(&(v179_8),&(v179_12));
        join_wrapped_into(&mut v178_7_write,&((v179_13).read_zipper()),&[]);
        }
        v176_28_cursor.ascend(1);
      }
      drop(v178_7_write);
      map_map_kernels::compose(&(v177_5),&(v178_7))
    };
    drop(v177_5);
    let v177_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v177_2));
    drop(v177_2);
    let v177_10: Space = if map_kernels::has_head(&(v177_9)) { singleton(&[]) } else { Space::new() };
    drop(v177_9);
    let v177_13: Space = if (&(v177_10)).is_empty() { Space::new() } else {
      let v188_6: Path = concat_path(&(*p0),&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]);
      let mut v188_12 = Space::new();
      let mut v188_12_write = v188_12.write_zipper();
      for v188_12_byte in v176_28_cursor.child_mask().iter() {
        v176_28_cursor.descend_to_existing_byte(v188_12_byte);
        {
        let v189_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
        let v189_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v189_2));
        let v189_4: Space = if map_kernels::has_head(&(v189_3)) { singleton(&[]) } else { Space::new() };
        drop(v189_3);
        let v189_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v189_4));
        drop(v189_4);
        let v189_8: Space = if (&(v189_5)).is_empty() { Space::new() } else {
          let v190_6: Path = concat_path(&(v188_6),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let mut v190_7 = Space::new();
          let mut v190_7_write = v190_7.write_zipper();
          for v190_7_byte in v176_28_cursor.child_mask().iter() {
            v176_28_cursor.descend_to_existing_byte(v190_7_byte);
            {
            let v191_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
            let v191_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v191_2));
            let v191_4: Space = if map_kernels::has_head(&(v191_3)) { singleton(&[]) } else { Space::new() };
            drop(v191_3);
            let v191_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v191_4));
            drop(v191_4);
            let v191_8: Space = if (&(v191_5)).is_empty() { Space::new() } else {
              let v192_6: Path = concat_path(&(v190_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v192_7: Space = routine_22(c, &(v192_6), &(*p1), &v176_28_cursor, &(*s1));
              map_map_kernels::compose(&(v191_5),&(v192_7))
            };
            drop(v191_5);
            let v191_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v191_2));
            drop(v191_2);
            let v191_10: Space = if map_kernels::has_head(&(v191_9)) { singleton(&[]) } else { Space::new() };
            drop(v191_9);
            let v191_12: Space = if (&(v191_10)).is_empty() { Space::new() } else {
              let v193_6: Path = concat_path(&(v190_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v193_11: Space = routine_23(c, &(v193_6), &(*p1), &v176_28_cursor, &(*s1));
              drop(v193_6);
              map_map_kernels::compose(&(v191_10),&(v193_11))
            };
            drop(v191_10);
            let v191_13: Space = map_map_kernels::unite(&(v191_8),&(v191_12));
            join_wrapped_into(&mut v190_7_write,&((v191_13).read_zipper()),&[]);
            }
            v176_28_cursor.ascend(1);
          }
          drop(v190_7_write);
          drop(v190_6);
          map_map_kernels::compose(&(v189_5),&(v190_7))
        };
        drop(v189_5);
        let v189_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v189_2));
        drop(v189_2);
        let v189_10: Space = if map_kernels::has_head(&(v189_9)) { singleton(&[]) } else { Space::new() };
        drop(v189_9);
        let v189_13: Space = if (&(v189_10)).is_empty() { Space::new() } else {
          let mut v194_12 = Space::new();
          let mut v194_12_write = v194_12.write_zipper();
          let mut v194_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let v194_12_origin = v194_12_cursor.path().len();
          for v194_12_byte in v194_12_cursor.child_mask().iter() {
            v194_12_cursor.descend_to_existing_byte(v194_12_byte);
            {
            let v195_2: Space = singleton(&v194_12_cursor.path()[v194_12_origin..(v194_12_origin + 1)]);
            let v195_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v195_2));
            let v195_4: Space = if map_kernels::has_head(&(v195_3)) { singleton(&[]) } else { Space::new() };
            drop(v195_3);
            let v195_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v195_4));
            drop(v195_4);
            let v195_7: Space = if (&(v195_5)).is_empty() { Space::new() } else {
              let v196_6: Space = routine_13(c, &v194_12_cursor.path()[v194_12_origin..(v194_12_origin + 1)], &(*p1), &v194_12_cursor);
              map_map_kernels::compose(&(v195_5),&(v196_6))
            };
            drop(v195_5);
            let v195_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v195_2));
            drop(v195_2);
            let v195_9: Space = if map_kernels::has_head(&(v195_8)) { singleton(&[]) } else { Space::new() };
            drop(v195_8);
            let v195_11: Space = if (&(v195_9)).is_empty() { Space::new() } else {
              let v197_10: Space = routine_14(c, &v194_12_cursor.path()[v194_12_origin..(v194_12_origin + 1)], &(*p1), &v194_12_cursor);
              map_map_kernels::compose(&(v195_9),&(v197_10))
            };
            drop(v195_9);
            let v195_12: Space = map_map_kernels::unite(&(v195_7),&(v195_11));
            join_wrapped_into(&mut v194_12_write,&((v195_12).read_zipper()),&[]);
            }
            v194_12_cursor.ascend(1);
          }
          drop(v194_12_cursor);
          drop(v194_12_write);
          map_map_kernels::compose(&(v189_10),&(v194_12))
        };
        drop(v189_10);
        let v189_14: Space = map_map_kernels::unite(&(v189_8),&(v189_13));
        join_wrapped_into(&mut v188_12_write,&((v189_14).read_zipper()),&[]);
        }
        v176_28_cursor.ascend(1);
      }
      drop(v188_12_write);
      drop(v188_6);
      map_map_kernels::compose(&(v177_10),&(v188_12))
    };
    drop(v177_10);
    let v177_14: Space = map_map_kernels::unite(&(v177_8),&(v177_13));
    join_wrapped_into(&mut v176_28_write,&((v177_14).read_zipper()),&[]);
    }
    v176_28_cursor.ascend(1);
  }
  drop(v176_28_cursor);
  drop(v176_28_write);
  (v176_28).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v198_28 = Space::new();
  let mut v198_28_write = v198_28.write_zipper();
  let mut v198_28_cursor = (*s0).read_zipper();
  let v198_28_origin = v198_28_cursor.path().len();
  for v198_28_byte in v198_28_cursor.child_mask().iter() {
    v198_28_cursor.descend_to_existing_byte(v198_28_byte);
    {
    let v199_2: Space = singleton(&v198_28_cursor.path()[v198_28_origin..(v198_28_origin + 1)]);
    let v199_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v199_2));
    let v199_4: Space = if map_kernels::has_head(&(v199_3)) { singleton(&[]) } else { Space::new() };
    drop(v199_3);
    let v199_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v199_4));
    drop(v199_4);
    let v199_8: Space = if (&(v199_5)).is_empty() { Space::new() } else {
      let v200_6: Path = concat_path(&(*p0),&v198_28_cursor.path()[v198_28_origin..(v198_28_origin + 1)]);
      let mut v200_7 = Space::new();
      let mut v200_7_write = v200_7.write_zipper();
      for v200_7_byte in v198_28_cursor.child_mask().iter() {
        v198_28_cursor.descend_to_existing_byte(v200_7_byte);
        {
        let v201_2: Space = singleton(&v198_28_cursor.path()[(v198_28_origin + 1)..(v198_28_origin + 2)]);
        let v201_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v201_2));
        let v201_4: Space = if map_kernels::has_head(&(v201_3)) { singleton(&[]) } else { Space::new() };
        drop(v201_3);
        let v201_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v201_4));
        drop(v201_4);
        let v201_8: Space = if (&(v201_5)).is_empty() { Space::new() } else {
          let v202_6: Path = concat_path(&(v200_6),&v198_28_cursor.path()[(v198_28_origin + 1)..(v198_28_origin + 2)]);
          let mut v202_7 = Space::new();
          let mut v202_7_write = v202_7.write_zipper();
          for v202_7_byte in v198_28_cursor.child_mask().iter() {
            v198_28_cursor.descend_to_existing_byte(v202_7_byte);
            {
            let v203_2: Space = singleton(&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
            let v203_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v203_2));
            let v203_4: Space = if map_kernels::has_head(&(v203_3)) { singleton(&[]) } else { Space::new() };
            drop(v203_3);
            let v203_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v203_4));
            drop(v203_4);
            let v203_8: Space = if (&(v203_5)).is_empty() { Space::new() } else {
              let v204_6: Path = concat_path(&(v202_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v204_7: Space = routine_22(c, &(v204_6), &(*p1), &v198_28_cursor, &(*s1));
              map_map_kernels::compose(&(v203_5),&(v204_7))
            };
            drop(v203_5);
            let v203_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v203_2));
            drop(v203_2);
            let v203_10: Space = if map_kernels::has_head(&(v203_9)) { singleton(&[]) } else { Space::new() };
            drop(v203_9);
            let v203_12: Space = if (&(v203_10)).is_empty() { Space::new() } else {
              let v205_6: Path = concat_path(&(v202_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v205_11: Space = routine_23(c, &(v205_6), &(*p1), &v198_28_cursor, &(*s1));
              drop(v205_6);
              map_map_kernels::compose(&(v203_10),&(v205_11))
            };
            drop(v203_10);
            let v203_13: Space = map_map_kernels::unite(&(v203_8),&(v203_12));
            join_wrapped_into(&mut v202_7_write,&((v203_13).read_zipper()),&[]);
            }
            v198_28_cursor.ascend(1);
          }
          drop(v202_7_write);
          map_map_kernels::compose(&(v201_5),&(v202_7))
        };
        drop(v201_5);
        let v201_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v201_2));
        drop(v201_2);
        let v201_10: Space = if map_kernels::has_head(&(v201_9)) { singleton(&[]) } else { Space::new() };
        drop(v201_9);
        let v201_12: Space = if (&(v201_10)).is_empty() { Space::new() } else {
          let v206_6: Path = concat_path(&(v200_6),&v198_28_cursor.path()[(v198_28_origin + 1)..(v198_28_origin + 2)]);
          let mut v206_11 = Space::new();
          let mut v206_11_write = v206_11.write_zipper();
          for v206_11_byte in v198_28_cursor.child_mask().iter() {
            v198_28_cursor.descend_to_existing_byte(v206_11_byte);
            {
            let v207_2: Space = singleton(&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
            let v207_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v207_2));
            let v207_4: Space = if map_kernels::has_head(&(v207_3)) { singleton(&[]) } else { Space::new() };
            drop(v207_3);
            let v207_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v207_4));
            drop(v207_4);
            let v207_8: Space = if (&(v207_5)).is_empty() { Space::new() } else {
              let v208_6: Path = concat_path(&(v206_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v208_7: Space = routine_22(c, &(v208_6), &(*p1), &v198_28_cursor, &(*s1));
              map_map_kernels::compose(&(v207_5),&(v208_7))
            };
            drop(v207_5);
            let v207_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v207_2));
            drop(v207_2);
            let v207_10: Space = if map_kernels::has_head(&(v207_9)) { singleton(&[]) } else { Space::new() };
            drop(v207_9);
            let v207_12: Space = if (&(v207_10)).is_empty() { Space::new() } else {
              let v209_6: Path = concat_path(&(v206_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v209_11: Space = routine_10(c, &(v209_6), &(*p1), &v198_28_cursor, &(*s1));
              drop(v209_6);
              map_map_kernels::compose(&(v207_10),&(v209_11))
            };
            drop(v207_10);
            let v207_13: Space = map_map_kernels::unite(&(v207_8),&(v207_12));
            join_wrapped_into(&mut v206_11_write,&((v207_13).read_zipper()),&[]);
            }
            v198_28_cursor.ascend(1);
          }
          drop(v206_11_write);
          drop(v206_6);
          map_map_kernels::compose(&(v201_10),&(v206_11))
        };
        drop(v201_10);
        let v201_13: Space = map_map_kernels::unite(&(v201_8),&(v201_12));
        join_wrapped_into(&mut v200_7_write,&((v201_13).read_zipper()),&[]);
        }
        v198_28_cursor.ascend(1);
      }
      drop(v200_7_write);
      drop(v200_6);
      map_map_kernels::compose(&(v199_5),&(v200_7))
    };
    drop(v199_5);
    let v199_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v199_2));
    drop(v199_2);
    let v199_10: Space = if map_kernels::has_head(&(v199_9)) { singleton(&[]) } else { Space::new() };
    drop(v199_9);
    let v199_13: Space = if (&(v199_10)).is_empty() { Space::new() } else {
      let mut v210_12 = Space::new();
      let mut v210_12_write = v210_12.write_zipper();
      let mut v210_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v198_28_cursor.path()[v198_28_origin..(v198_28_origin + 1)]);
      let v210_12_origin = v210_12_cursor.path().len();
      for v210_12_byte in v210_12_cursor.child_mask().iter() {
        v210_12_cursor.descend_to_existing_byte(v210_12_byte);
        {
        let v211_2: Space = singleton(&v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 1)]);
        let v211_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v211_2));
        let v211_4: Space = if map_kernels::has_head(&(v211_3)) { singleton(&[]) } else { Space::new() };
        drop(v211_3);
        let v211_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v211_4));
        drop(v211_4);
        let v211_7: Space = if (&(v211_5)).is_empty() { Space::new() } else {
          let mut v212_6 = Space::new();
          let mut v212_6_write = v212_6.write_zipper();
          for v212_6_byte in v210_12_cursor.child_mask().iter() {
            v210_12_cursor.descend_to_existing_byte(v212_6_byte);
            {
            let v213_2: Space = singleton(&v210_12_cursor.path()[(v210_12_origin + 1)..(v210_12_origin + 2)]);
            let v213_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v213_2));
            let v213_4: Space = if map_kernels::has_head(&(v213_3)) { singleton(&[]) } else { Space::new() };
            drop(v213_3);
            let v213_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v213_4));
            drop(v213_4);
            let v213_8: Space = if (&(v213_5)).is_empty() { Space::new() } else {
              let v214_7: Space = routine_17(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              map_map_kernels::compose(&(v213_5),&(v214_7))
            };
            drop(v213_5);
            let v213_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v213_2));
            drop(v213_2);
            let v213_10: Space = if map_kernels::has_head(&(v213_9)) { singleton(&[]) } else { Space::new() };
            drop(v213_9);
            let v213_12: Space = if (&(v213_10)).is_empty() { Space::new() } else {
              let v215_11: Space = routine_18(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              map_map_kernels::compose(&(v213_10),&(v215_11))
            };
            drop(v213_10);
            let v213_13: Space = map_map_kernels::unite(&(v213_8),&(v213_12));
            join_wrapped_into(&mut v212_6_write,&((v213_13).read_zipper()),&[]);
            }
            v210_12_cursor.ascend(1);
          }
          drop(v212_6_write);
          map_map_kernels::compose(&(v211_5),&(v212_6))
        };
        drop(v211_5);
        let v211_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v211_2));
        drop(v211_2);
        let v211_9: Space = if map_kernels::has_head(&(v211_8)) { singleton(&[]) } else { Space::new() };
        drop(v211_8);
        let v211_11: Space = if (&(v211_9)).is_empty() { Space::new() } else {
          let mut v216_10 = Space::new();
          let mut v216_10_write = v216_10.write_zipper();
          for v216_10_byte in v210_12_cursor.child_mask().iter() {
            v210_12_cursor.descend_to_existing_byte(v216_10_byte);
            {
            let v217_2: Space = singleton(&v210_12_cursor.path()[(v210_12_origin + 1)..(v210_12_origin + 2)]);
            let v217_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v217_2));
            let v217_4: Space = if map_kernels::has_head(&(v217_3)) { singleton(&[]) } else { Space::new() };
            drop(v217_3);
            let v217_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v217_4));
            drop(v217_4);
            let v217_8: Space = if (&(v217_5)).is_empty() { Space::new() } else {
              let v218_7: Space = routine_17(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              map_map_kernels::compose(&(v217_5),&(v218_7))
            };
            drop(v217_5);
            let v217_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v217_2));
            drop(v217_2);
            let v217_10: Space = if map_kernels::has_head(&(v217_9)) { singleton(&[]) } else { Space::new() };
            drop(v217_9);
            let v217_12: Space = if (&(v217_10)).is_empty() { Space::new() } else {
              let v219_11: Space = routine_19(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              map_map_kernels::compose(&(v217_10),&(v219_11))
            };
            drop(v217_10);
            let v217_13: Space = map_map_kernels::unite(&(v217_8),&(v217_12));
            join_wrapped_into(&mut v216_10_write,&((v217_13).read_zipper()),&[]);
            }
            v210_12_cursor.ascend(1);
          }
          drop(v216_10_write);
          map_map_kernels::compose(&(v211_9),&(v216_10))
        };
        drop(v211_9);
        let v211_12: Space = map_map_kernels::unite(&(v211_7),&(v211_11));
        join_wrapped_into(&mut v210_12_write,&((v211_12).read_zipper()),&[]);
        }
        v210_12_cursor.ascend(1);
      }
      drop(v210_12_cursor);
      drop(v210_12_write);
      map_map_kernels::compose(&(v199_10),&(v210_12))
    };
    drop(v199_10);
    let v199_14: Space = map_map_kernels::unite(&(v199_8),&(v199_13));
    join_wrapped_into(&mut v198_28_write,&((v199_14).read_zipper()),&[]);
    }
    v198_28_cursor.ascend(1);
  }
  drop(v198_28_cursor);
  drop(v198_28_write);
  (v198_28).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v220_25 = Space::new();
  let mut v220_25_write = v220_25.write_zipper();
  let mut v220_25_cursor = descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0));
  let v220_25_origin = v220_25_cursor.path().len();
  for v220_25_byte in v220_25_cursor.child_mask().iter() {
    v220_25_cursor.descend_to_existing_byte(v220_25_byte);
    {
    let v221_2: Space = singleton(&v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 1)]);
    let v221_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v221_2));
    let v221_4: Space = if map_kernels::has_head(&(v221_3)) { singleton(&[]) } else { Space::new() };
    drop(v221_3);
    let v221_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v221_4));
    drop(v221_4);
    let v221_7: Space = if (&(v221_5)).is_empty() { Space::new() } else {
      let mut v222_6 = Space::new();
      let mut v222_6_write = v222_6.write_zipper();
      for v222_6_byte in v220_25_cursor.child_mask().iter() {
        v220_25_cursor.descend_to_existing_byte(v222_6_byte);
        {
        let v223_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 1)..(v220_25_origin + 2)]);
        let v223_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v223_2));
        let v223_4: Space = if map_kernels::has_head(&(v223_3)) { singleton(&[]) } else { Space::new() };
        drop(v223_3);
        let v223_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v223_4));
        drop(v223_4);
        let v223_8: Space = if (&(v223_5)).is_empty() { Space::new() } else {
          let mut v224_7 = Space::new();
          let mut v224_7_write = v224_7.write_zipper();
          for v224_7_byte in v220_25_cursor.child_mask().iter() {
            v220_25_cursor.descend_to_existing_byte(v224_7_byte);
            {
            let v225_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 2)..(v220_25_origin + 3)]);
            let v225_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v225_2));
            let v225_4: Space = if map_kernels::has_head(&(v225_3)) { singleton(&[]) } else { Space::new() };
            drop(v225_3);
            let v225_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v225_4));
            drop(v225_4);
            let v225_8: Space = if (&(v225_5)).is_empty() { Space::new() } else {
              let v226_7: Space = routine_24(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              map_map_kernels::compose(&(v225_5),&(v226_7))
            };
            drop(v225_5);
            let v225_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v225_2));
            drop(v225_2);
            let v225_10: Space = if map_kernels::has_head(&(v225_9)) { singleton(&[]) } else { Space::new() };
            drop(v225_9);
            let v225_12: Space = if (&(v225_10)).is_empty() { Space::new() } else {
              let v227_11: Space = routine_25(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              map_map_kernels::compose(&(v225_10),&(v227_11))
            };
            drop(v225_10);
            let v225_13: Space = map_map_kernels::unite(&(v225_8),&(v225_12));
            join_wrapped_into(&mut v224_7_write,&((v225_13).read_zipper()),&[]);
            }
            v220_25_cursor.ascend(1);
          }
          drop(v224_7_write);
          map_map_kernels::compose(&(v223_5),&(v224_7))
        };
        drop(v223_5);
        let v223_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v223_2));
        drop(v223_2);
        let v223_10: Space = if map_kernels::has_head(&(v223_9)) { singleton(&[]) } else { Space::new() };
        drop(v223_9);
        let v223_12: Space = if (&(v223_10)).is_empty() { Space::new() } else {
          let mut v228_11 = Space::new();
          let mut v228_11_write = v228_11.write_zipper();
          for v228_11_byte in v220_25_cursor.child_mask().iter() {
            v220_25_cursor.descend_to_existing_byte(v228_11_byte);
            {
            let v229_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 2)..(v220_25_origin + 3)]);
            let v229_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v229_2));
            let v229_4: Space = if map_kernels::has_head(&(v229_3)) { singleton(&[]) } else { Space::new() };
            drop(v229_3);
            let v229_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v229_4));
            drop(v229_4);
            let v229_8: Space = if (&(v229_5)).is_empty() { Space::new() } else {
              let v230_7: Space = routine_24(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              map_map_kernels::compose(&(v229_5),&(v230_7))
            };
            drop(v229_5);
            let v229_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v229_2));
            drop(v229_2);
            let v229_10: Space = if map_kernels::has_head(&(v229_9)) { singleton(&[]) } else { Space::new() };
            drop(v229_9);
            let v229_12: Space = if (&(v229_10)).is_empty() { Space::new() } else {
              let v231_11: Space = routine_19(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              map_map_kernels::compose(&(v229_10),&(v231_11))
            };
            drop(v229_10);
            let v229_13: Space = map_map_kernels::unite(&(v229_8),&(v229_12));
            join_wrapped_into(&mut v228_11_write,&((v229_13).read_zipper()),&[]);
            }
            v220_25_cursor.ascend(1);
          }
          drop(v228_11_write);
          map_map_kernels::compose(&(v223_10),&(v228_11))
        };
        drop(v223_10);
        let v223_13: Space = map_map_kernels::unite(&(v223_8),&(v223_12));
        join_wrapped_into(&mut v222_6_write,&((v223_13).read_zipper()),&[]);
        }
        v220_25_cursor.ascend(1);
      }
      drop(v222_6_write);
      map_map_kernels::compose(&(v221_5),&(v222_6))
    };
    drop(v221_5);
    let v221_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v221_2));
    drop(v221_2);
    let v221_9: Space = if map_kernels::has_head(&(v221_8)) { singleton(&[]) } else { Space::new() };
    drop(v221_8);
    let v221_11: Space = if (&(v221_9)).is_empty() { Space::new() } else {
      let mut v232_10 = Space::new();
      let mut v232_10_write = v232_10.write_zipper();
      for v232_10_byte in v220_25_cursor.child_mask().iter() {
        v220_25_cursor.descend_to_existing_byte(v232_10_byte);
        {
        let v233_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 1)..(v220_25_origin + 2)]);
        let v233_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v233_2));
        let v233_4: Space = if map_kernels::has_head(&(v233_3)) { singleton(&[]) } else { Space::new() };
        drop(v233_3);
        let v233_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v233_4));
        drop(v233_4);
        let v233_8: Space = if (&(v233_5)).is_empty() { Space::new() } else {
          let mut v234_7 = Space::new();
          let mut v234_7_write = v234_7.write_zipper();
          for v234_7_byte in v220_25_cursor.child_mask().iter() {
            v220_25_cursor.descend_to_existing_byte(v234_7_byte);
            {
            let v235_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 2)..(v220_25_origin + 3)]);
            let v235_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v235_2));
            let v235_4: Space = if map_kernels::has_head(&(v235_3)) { singleton(&[]) } else { Space::new() };
            drop(v235_3);
            let v235_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v235_4));
            drop(v235_4);
            let v235_8: Space = if (&(v235_5)).is_empty() { Space::new() } else {
              let v236_7: Space = routine_24(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              map_map_kernels::compose(&(v235_5),&(v236_7))
            };
            drop(v235_5);
            let v235_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v235_2));
            drop(v235_2);
            let v235_10: Space = if map_kernels::has_head(&(v235_9)) { singleton(&[]) } else { Space::new() };
            drop(v235_9);
            let v235_12: Space = if (&(v235_10)).is_empty() { Space::new() } else {
              let v237_11: Space = routine_25(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              map_map_kernels::compose(&(v235_10),&(v237_11))
            };
            drop(v235_10);
            let v235_13: Space = map_map_kernels::unite(&(v235_8),&(v235_12));
            join_wrapped_into(&mut v234_7_write,&((v235_13).read_zipper()),&[]);
            }
            v220_25_cursor.ascend(1);
          }
          drop(v234_7_write);
          map_map_kernels::compose(&(v233_5),&(v234_7))
        };
        drop(v233_5);
        let v233_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v233_2));
        drop(v233_2);
        let v233_10: Space = if map_kernels::has_head(&(v233_9)) { singleton(&[]) } else { Space::new() };
        drop(v233_9);
        let v233_11: Space = map_view_kernels::compose(&(v233_10),&v220_25_cursor);
        drop(v233_10);
        let v233_12: Space = map_kernels::wrap(&(v233_11),&v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 2)]);
        drop(v233_11);
        let v233_13: Space = map_kernels::wrap(&(v233_12),&(*p1));
        drop(v233_12);
        let v233_14: Space = map_map_kernels::unite(&(v233_8),&(v233_13));
        drop(v233_13);
        join_wrapped_into(&mut v232_10_write,&((v233_14).read_zipper()),&[]);
        }
        v220_25_cursor.ascend(1);
      }
      drop(v232_10_write);
      map_map_kernels::compose(&(v221_9),&(v232_10))
    };
    drop(v221_9);
    let v221_12: Space = map_map_kernels::unite(&(v221_7),&(v221_11));
    join_wrapped_into(&mut v220_25_write,&((v221_12).read_zipper()),&[]);
    }
    v220_25_cursor.ascend(1);
  }
  drop(v220_25_cursor);
  drop(v220_25_write);
  (v220_25).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v239_28 = Space::new();
  let mut v239_28_write = v239_28.write_zipper();
  let mut v239_28_cursor = (*s0).read_zipper();
  let v239_28_origin = v239_28_cursor.path().len();
  for v239_28_byte in v239_28_cursor.child_mask().iter() {
    v239_28_cursor.descend_to_existing_byte(v239_28_byte);
    {
    let v240_2: Space = singleton(&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]);
    let v240_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v240_2));
    let v240_4: Space = if map_kernels::has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
    drop(v240_3);
    let v240_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v240_4));
    drop(v240_4);
    let v240_8: Space = if (&(v240_5)).is_empty() { Space::new() } else {
      let v241_6: Path = concat_path(&(*p0),&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]);
      let mut v241_7 = Space::new();
      let mut v241_7_write = v241_7.write_zipper();
      for v241_7_byte in v239_28_cursor.child_mask().iter() {
        v239_28_cursor.descend_to_existing_byte(v241_7_byte);
        {
        let v242_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
        let v242_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v242_2));
        let v242_4: Space = if map_kernels::has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
        drop(v242_3);
        let v242_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v242_4));
        drop(v242_4);
        let v242_8: Space = if (&(v242_5)).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v241_6),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let mut v243_7 = Space::new();
          let mut v243_7_write = v243_7.write_zipper();
          for v243_7_byte in v239_28_cursor.child_mask().iter() {
            v239_28_cursor.descend_to_existing_byte(v243_7_byte);
            {
            let v244_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
            let v244_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v244_2));
            let v244_4: Space = if map_kernels::has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
            drop(v244_3);
            let v244_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v244_4));
            drop(v244_4);
            let v244_8: Space = if (&(v244_5)).is_empty() { Space::new() } else {
              let v245_6: Path = concat_path(&(v243_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v245_7: Space = routine_26(c, &(v245_6), &(*p1), &v239_28_cursor, &(*s1));
              map_map_kernels::compose(&(v244_5),&(v245_7))
            };
            drop(v244_5);
            let v244_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v244_2));
            drop(v244_2);
            let v244_10: Space = if map_kernels::has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
            drop(v244_9);
            let v244_12: Space = if (&(v244_10)).is_empty() { Space::new() } else {
              let v246_6: Path = concat_path(&(v243_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v246_11: Space = routine_27(c, &(v246_6), &(*p1), &v239_28_cursor, &(*s1));
              drop(v246_6);
              map_map_kernels::compose(&(v244_10),&(v246_11))
            };
            drop(v244_10);
            let v244_13: Space = map_map_kernels::unite(&(v244_8),&(v244_12));
            join_wrapped_into(&mut v243_7_write,&((v244_13).read_zipper()),&[]);
            }
            v239_28_cursor.ascend(1);
          }
          drop(v243_7_write);
          map_map_kernels::compose(&(v242_5),&(v243_7))
        };
        drop(v242_5);
        let v242_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v242_2));
        drop(v242_2);
        let v242_10: Space = if map_kernels::has_head(&(v242_9)) { singleton(&[]) } else { Space::new() };
        drop(v242_9);
        let v242_12: Space = if (&(v242_10)).is_empty() { Space::new() } else {
          let v247_6: Path = concat_path(&(v241_6),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let mut v247_11 = Space::new();
          let mut v247_11_write = v247_11.write_zipper();
          for v247_11_byte in v239_28_cursor.child_mask().iter() {
            v239_28_cursor.descend_to_existing_byte(v247_11_byte);
            {
            let v248_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
            let v248_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v248_2));
            let v248_4: Space = if map_kernels::has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
            drop(v248_3);
            let v248_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v248_4));
            drop(v248_4);
            let v248_8: Space = if (&(v248_5)).is_empty() { Space::new() } else {
              let v249_6: Path = concat_path(&(v247_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v249_7: Space = routine_26(c, &(v249_6), &(*p1), &v239_28_cursor, &(*s1));
              map_map_kernels::compose(&(v248_5),&(v249_7))
            };
            drop(v248_5);
            let v248_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v248_2));
            drop(v248_2);
            let v248_10: Space = if map_kernels::has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
            drop(v248_9);
            let v248_12: Space = if (&(v248_10)).is_empty() { Space::new() } else {
              let v250_6: Path = concat_path(&(v247_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v250_11: Space = routine_10(c, &(v250_6), &(*p1), &v239_28_cursor, &(*s1));
              drop(v250_6);
              map_map_kernels::compose(&(v248_10),&(v250_11))
            };
            drop(v248_10);
            let v248_13: Space = map_map_kernels::unite(&(v248_8),&(v248_12));
            join_wrapped_into(&mut v247_11_write,&((v248_13).read_zipper()),&[]);
            }
            v239_28_cursor.ascend(1);
          }
          drop(v247_11_write);
          drop(v247_6);
          map_map_kernels::compose(&(v242_10),&(v247_11))
        };
        drop(v242_10);
        let v242_13: Space = map_map_kernels::unite(&(v242_8),&(v242_12));
        join_wrapped_into(&mut v241_7_write,&((v242_13).read_zipper()),&[]);
        }
        v239_28_cursor.ascend(1);
      }
      drop(v241_7_write);
      map_map_kernels::compose(&(v240_5),&(v241_7))
    };
    drop(v240_5);
    let v240_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v240_2));
    drop(v240_2);
    let v240_10: Space = if map_kernels::has_head(&(v240_9)) { singleton(&[]) } else { Space::new() };
    drop(v240_9);
    let v240_13: Space = if (&(v240_10)).is_empty() { Space::new() } else {
      let v251_6: Path = concat_path(&(*p0),&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]);
      let mut v251_12 = Space::new();
      let mut v251_12_write = v251_12.write_zipper();
      for v251_12_byte in v239_28_cursor.child_mask().iter() {
        v239_28_cursor.descend_to_existing_byte(v251_12_byte);
        {
        let v252_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
        let v252_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v252_2));
        let v252_4: Space = if map_kernels::has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
        drop(v252_3);
        let v252_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v252_4));
        drop(v252_4);
        let v252_8: Space = if (&(v252_5)).is_empty() { Space::new() } else {
          let v253_6: Path = concat_path(&(v251_6),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let mut v253_7 = Space::new();
          let mut v253_7_write = v253_7.write_zipper();
          for v253_7_byte in v239_28_cursor.child_mask().iter() {
            v239_28_cursor.descend_to_existing_byte(v253_7_byte);
            {
            let v254_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
            let v254_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v254_2));
            let v254_4: Space = if map_kernels::has_head(&(v254_3)) { singleton(&[]) } else { Space::new() };
            drop(v254_3);
            let v254_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v254_4));
            drop(v254_4);
            let v254_8: Space = if (&(v254_5)).is_empty() { Space::new() } else {
              let v255_6: Path = concat_path(&(v253_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v255_7: Space = routine_26(c, &(v255_6), &(*p1), &v239_28_cursor, &(*s1));
              map_map_kernels::compose(&(v254_5),&(v255_7))
            };
            drop(v254_5);
            let v254_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v254_2));
            drop(v254_2);
            let v254_10: Space = if map_kernels::has_head(&(v254_9)) { singleton(&[]) } else { Space::new() };
            drop(v254_9);
            let v254_12: Space = if (&(v254_10)).is_empty() { Space::new() } else {
              let v256_6: Path = concat_path(&(v253_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v256_11: Space = routine_27(c, &(v256_6), &(*p1), &v239_28_cursor, &(*s1));
              drop(v256_6);
              map_map_kernels::compose(&(v254_10),&(v256_11))
            };
            drop(v254_10);
            let v254_13: Space = map_map_kernels::unite(&(v254_8),&(v254_12));
            join_wrapped_into(&mut v253_7_write,&((v254_13).read_zipper()),&[]);
            }
            v239_28_cursor.ascend(1);
          }
          drop(v253_7_write);
          drop(v253_6);
          map_map_kernels::compose(&(v252_5),&(v253_7))
        };
        drop(v252_5);
        let v252_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v252_2));
        drop(v252_2);
        let v252_10: Space = if map_kernels::has_head(&(v252_9)) { singleton(&[]) } else { Space::new() };
        drop(v252_9);
        let v252_13: Space = if (&(v252_10)).is_empty() { Space::new() } else {
          let mut v257_12 = Space::new();
          let mut v257_12_write = v257_12.write_zipper();
          let mut v257_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let v257_12_origin = v257_12_cursor.path().len();
          for v257_12_byte in v257_12_cursor.child_mask().iter() {
            v257_12_cursor.descend_to_existing_byte(v257_12_byte);
            {
            let v258_2: Space = singleton(&v257_12_cursor.path()[v257_12_origin..(v257_12_origin + 1)]);
            let v258_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v258_2));
            let v258_4: Space = if map_kernels::has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
            drop(v258_3);
            let v258_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v258_4));
            drop(v258_4);
            let v258_7: Space = if (&(v258_5)).is_empty() { Space::new() } else {
              let v259_6: Space = routine_13(c, &v257_12_cursor.path()[v257_12_origin..(v257_12_origin + 1)], &(*p1), &v257_12_cursor);
              map_map_kernels::compose(&(v258_5),&(v259_6))
            };
            drop(v258_5);
            let v258_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v258_2));
            drop(v258_2);
            let v258_9: Space = if map_kernels::has_head(&(v258_8)) { singleton(&[]) } else { Space::new() };
            drop(v258_8);
            let v258_11: Space = if (&(v258_9)).is_empty() { Space::new() } else {
              let v260_10: Space = routine_14(c, &v257_12_cursor.path()[v257_12_origin..(v257_12_origin + 1)], &(*p1), &v257_12_cursor);
              map_map_kernels::compose(&(v258_9),&(v260_10))
            };
            drop(v258_9);
            let v258_12: Space = map_map_kernels::unite(&(v258_7),&(v258_11));
            join_wrapped_into(&mut v257_12_write,&((v258_12).read_zipper()),&[]);
            }
            v257_12_cursor.ascend(1);
          }
          drop(v257_12_cursor);
          drop(v257_12_write);
          map_map_kernels::compose(&(v252_10),&(v257_12))
        };
        drop(v252_10);
        let v252_14: Space = map_map_kernels::unite(&(v252_8),&(v252_13));
        join_wrapped_into(&mut v251_12_write,&((v252_14).read_zipper()),&[]);
        }
        v239_28_cursor.ascend(1);
      }
      drop(v251_12_write);
      drop(v251_6);
      map_map_kernels::compose(&(v240_10),&(v251_12))
    };
    drop(v240_10);
    let v240_14: Space = map_map_kernels::unite(&(v240_8),&(v240_13));
    join_wrapped_into(&mut v239_28_write,&((v240_14).read_zipper()),&[]);
    }
    v239_28_cursor.ascend(1);
  }
  drop(v239_28_cursor);
  drop(v239_28_write);
  (v239_28).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v261_28 = Space::new();
  let mut v261_28_write = v261_28.write_zipper();
  let mut v261_28_cursor = (*s0).read_zipper();
  let v261_28_origin = v261_28_cursor.path().len();
  for v261_28_byte in v261_28_cursor.child_mask().iter() {
    v261_28_cursor.descend_to_existing_byte(v261_28_byte);
    {
    let v262_2: Space = singleton(&v261_28_cursor.path()[v261_28_origin..(v261_28_origin + 1)]);
    let v262_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v262_2));
    let v262_4: Space = if map_kernels::has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
    drop(v262_3);
    let v262_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v262_4));
    drop(v262_4);
    let v262_8: Space = if (&(v262_5)).is_empty() { Space::new() } else {
      let v263_6: Path = concat_path(&(*p0),&v261_28_cursor.path()[v261_28_origin..(v261_28_origin + 1)]);
      let mut v263_7 = Space::new();
      let mut v263_7_write = v263_7.write_zipper();
      for v263_7_byte in v261_28_cursor.child_mask().iter() {
        v261_28_cursor.descend_to_existing_byte(v263_7_byte);
        {
        let v264_2: Space = singleton(&v261_28_cursor.path()[(v261_28_origin + 1)..(v261_28_origin + 2)]);
        let v264_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v264_2));
        let v264_4: Space = if map_kernels::has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
        drop(v264_3);
        let v264_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v264_4));
        drop(v264_4);
        let v264_8: Space = if (&(v264_5)).is_empty() { Space::new() } else {
          let v265_6: Path = concat_path(&(v263_6),&v261_28_cursor.path()[(v261_28_origin + 1)..(v261_28_origin + 2)]);
          let mut v265_7 = Space::new();
          let mut v265_7_write = v265_7.write_zipper();
          for v265_7_byte in v261_28_cursor.child_mask().iter() {
            v261_28_cursor.descend_to_existing_byte(v265_7_byte);
            {
            let v266_2: Space = singleton(&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
            let v266_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v266_2));
            let v266_4: Space = if map_kernels::has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
            drop(v266_3);
            let v266_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v266_4));
            drop(v266_4);
            let v266_8: Space = if (&(v266_5)).is_empty() { Space::new() } else {
              let v267_6: Path = concat_path(&(v265_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v267_7: Space = routine_26(c, &(v267_6), &(*p1), &v261_28_cursor, &(*s1));
              map_map_kernels::compose(&(v266_5),&(v267_7))
            };
            drop(v266_5);
            let v266_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v266_2));
            drop(v266_2);
            let v266_10: Space = if map_kernels::has_head(&(v266_9)) { singleton(&[]) } else { Space::new() };
            drop(v266_9);
            let v266_12: Space = if (&(v266_10)).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v265_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v268_11: Space = routine_27(c, &(v268_6), &(*p1), &v261_28_cursor, &(*s1));
              drop(v268_6);
              map_map_kernels::compose(&(v266_10),&(v268_11))
            };
            drop(v266_10);
            let v266_13: Space = map_map_kernels::unite(&(v266_8),&(v266_12));
            join_wrapped_into(&mut v265_7_write,&((v266_13).read_zipper()),&[]);
            }
            v261_28_cursor.ascend(1);
          }
          drop(v265_7_write);
          map_map_kernels::compose(&(v264_5),&(v265_7))
        };
        drop(v264_5);
        let v264_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v264_2));
        drop(v264_2);
        let v264_10: Space = if map_kernels::has_head(&(v264_9)) { singleton(&[]) } else { Space::new() };
        drop(v264_9);
        let v264_12: Space = if (&(v264_10)).is_empty() { Space::new() } else {
          let v269_6: Path = concat_path(&(v263_6),&v261_28_cursor.path()[(v261_28_origin + 1)..(v261_28_origin + 2)]);
          let mut v269_11 = Space::new();
          let mut v269_11_write = v269_11.write_zipper();
          for v269_11_byte in v261_28_cursor.child_mask().iter() {
            v261_28_cursor.descend_to_existing_byte(v269_11_byte);
            {
            let v270_2: Space = singleton(&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
            let v270_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v270_2));
            let v270_4: Space = if map_kernels::has_head(&(v270_3)) { singleton(&[]) } else { Space::new() };
            drop(v270_3);
            let v270_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v270_4));
            drop(v270_4);
            let v270_8: Space = if (&(v270_5)).is_empty() { Space::new() } else {
              let v271_6: Path = concat_path(&(v269_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v271_7: Space = routine_26(c, &(v271_6), &(*p1), &v261_28_cursor, &(*s1));
              map_map_kernels::compose(&(v270_5),&(v271_7))
            };
            drop(v270_5);
            let v270_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v270_2));
            drop(v270_2);
            let v270_10: Space = if map_kernels::has_head(&(v270_9)) { singleton(&[]) } else { Space::new() };
            drop(v270_9);
            let v270_12: Space = if (&(v270_10)).is_empty() { Space::new() } else {
              let v272_6: Path = concat_path(&(v269_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v272_11: Space = routine_10(c, &(v272_6), &(*p1), &v261_28_cursor, &(*s1));
              drop(v272_6);
              map_map_kernels::compose(&(v270_10),&(v272_11))
            };
            drop(v270_10);
            let v270_13: Space = map_map_kernels::unite(&(v270_8),&(v270_12));
            join_wrapped_into(&mut v269_11_write,&((v270_13).read_zipper()),&[]);
            }
            v261_28_cursor.ascend(1);
          }
          drop(v269_11_write);
          drop(v269_6);
          map_map_kernels::compose(&(v264_10),&(v269_11))
        };
        drop(v264_10);
        let v264_13: Space = map_map_kernels::unite(&(v264_8),&(v264_12));
        join_wrapped_into(&mut v263_7_write,&((v264_13).read_zipper()),&[]);
        }
        v261_28_cursor.ascend(1);
      }
      drop(v263_7_write);
      drop(v263_6);
      map_map_kernels::compose(&(v262_5),&(v263_7))
    };
    drop(v262_5);
    let v262_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v262_2));
    drop(v262_2);
    let v262_10: Space = if map_kernels::has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
    drop(v262_9);
    let v262_13: Space = if (&(v262_10)).is_empty() { Space::new() } else {
      let mut v273_12 = Space::new();
      let mut v273_12_write = v273_12.write_zipper();
      let mut v273_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v261_28_cursor.path()[v261_28_origin..(v261_28_origin + 1)]);
      let v273_12_origin = v273_12_cursor.path().len();
      for v273_12_byte in v273_12_cursor.child_mask().iter() {
        v273_12_cursor.descend_to_existing_byte(v273_12_byte);
        {
        let v274_2: Space = singleton(&v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 1)]);
        let v274_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v274_2));
        let v274_4: Space = if map_kernels::has_head(&(v274_3)) { singleton(&[]) } else { Space::new() };
        drop(v274_3);
        let v274_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v274_4));
        drop(v274_4);
        let v274_7: Space = if (&(v274_5)).is_empty() { Space::new() } else {
          let mut v275_6 = Space::new();
          let mut v275_6_write = v275_6.write_zipper();
          for v275_6_byte in v273_12_cursor.child_mask().iter() {
            v273_12_cursor.descend_to_existing_byte(v275_6_byte);
            {
            let v276_2: Space = singleton(&v273_12_cursor.path()[(v273_12_origin + 1)..(v273_12_origin + 2)]);
            let v276_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v276_2));
            let v276_4: Space = if map_kernels::has_head(&(v276_3)) { singleton(&[]) } else { Space::new() };
            drop(v276_3);
            let v276_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v276_4));
            drop(v276_4);
            let v276_8: Space = if (&(v276_5)).is_empty() { Space::new() } else {
              let v277_7: Space = routine_17(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              map_map_kernels::compose(&(v276_5),&(v277_7))
            };
            drop(v276_5);
            let v276_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v276_2));
            drop(v276_2);
            let v276_10: Space = if map_kernels::has_head(&(v276_9)) { singleton(&[]) } else { Space::new() };
            drop(v276_9);
            let v276_12: Space = if (&(v276_10)).is_empty() { Space::new() } else {
              let v278_11: Space = routine_18(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              map_map_kernels::compose(&(v276_10),&(v278_11))
            };
            drop(v276_10);
            let v276_13: Space = map_map_kernels::unite(&(v276_8),&(v276_12));
            join_wrapped_into(&mut v275_6_write,&((v276_13).read_zipper()),&[]);
            }
            v273_12_cursor.ascend(1);
          }
          drop(v275_6_write);
          map_map_kernels::compose(&(v274_5),&(v275_6))
        };
        drop(v274_5);
        let v274_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v274_2));
        drop(v274_2);
        let v274_9: Space = if map_kernels::has_head(&(v274_8)) { singleton(&[]) } else { Space::new() };
        drop(v274_8);
        let v274_11: Space = if (&(v274_9)).is_empty() { Space::new() } else {
          let mut v279_10 = Space::new();
          let mut v279_10_write = v279_10.write_zipper();
          for v279_10_byte in v273_12_cursor.child_mask().iter() {
            v273_12_cursor.descend_to_existing_byte(v279_10_byte);
            {
            let v280_2: Space = singleton(&v273_12_cursor.path()[(v273_12_origin + 1)..(v273_12_origin + 2)]);
            let v280_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v280_2));
            let v280_4: Space = if map_kernels::has_head(&(v280_3)) { singleton(&[]) } else { Space::new() };
            drop(v280_3);
            let v280_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v280_4));
            drop(v280_4);
            let v280_8: Space = if (&(v280_5)).is_empty() { Space::new() } else {
              let v281_7: Space = routine_17(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              map_map_kernels::compose(&(v280_5),&(v281_7))
            };
            drop(v280_5);
            let v280_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v280_2));
            drop(v280_2);
            let v280_10: Space = if map_kernels::has_head(&(v280_9)) { singleton(&[]) } else { Space::new() };
            drop(v280_9);
            let v280_12: Space = if (&(v280_10)).is_empty() { Space::new() } else {
              let v282_11: Space = routine_19(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              map_map_kernels::compose(&(v280_10),&(v282_11))
            };
            drop(v280_10);
            let v280_13: Space = map_map_kernels::unite(&(v280_8),&(v280_12));
            join_wrapped_into(&mut v279_10_write,&((v280_13).read_zipper()),&[]);
            }
            v273_12_cursor.ascend(1);
          }
          drop(v279_10_write);
          map_map_kernels::compose(&(v274_9),&(v279_10))
        };
        drop(v274_9);
        let v274_12: Space = map_map_kernels::unite(&(v274_7),&(v274_11));
        join_wrapped_into(&mut v273_12_write,&((v274_12).read_zipper()),&[]);
        }
        v273_12_cursor.ascend(1);
      }
      drop(v273_12_cursor);
      drop(v273_12_write);
      map_map_kernels::compose(&(v262_10),&(v273_12))
    };
    drop(v262_10);
    let v262_14: Space = map_map_kernels::unite(&(v262_8),&(v262_13));
    join_wrapped_into(&mut v261_28_write,&((v262_14).read_zipper()),&[]);
    }
    v261_28_cursor.ascend(1);
  }
  drop(v261_28_cursor);
  drop(v261_28_write);
  (v261_28).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v283_21 = Space::new();
  let mut v283_21_write = v283_21.write_zipper();
  let mut v283_21_cursor = (*s0).read_zipper();
  let v283_21_origin = v283_21_cursor.path().len();
  for v283_21_byte in v283_21_cursor.child_mask().iter() {
    v283_21_cursor.descend_to_existing_byte(v283_21_byte);
    {
    let v284_2: Space = singleton(&v283_21_cursor.path()[v283_21_origin..(v283_21_origin + 1)]);
    let v284_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v284_2));
    let v284_4: Space = if map_kernels::has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
    drop(v284_3);
    let v284_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v284_4));
    drop(v284_4);
    let v284_8: Space = if (&(v284_5)).is_empty() { Space::new() } else {
      let v285_6: Path = concat_path(&(*p0),&v283_21_cursor.path()[v283_21_origin..(v283_21_origin + 1)]);
      let mut v285_7 = Space::new();
      let mut v285_7_write = v285_7.write_zipper();
      for v285_7_byte in v283_21_cursor.child_mask().iter() {
        v283_21_cursor.descend_to_existing_byte(v285_7_byte);
        {
        let v286_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
        let v286_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v286_2));
        let v286_4: Space = if map_kernels::has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
        drop(v286_3);
        let v286_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v286_4));
        drop(v286_4);
        let v286_8: Space = if (&(v286_5)).is_empty() { Space::new() } else {
          let v287_6: Path = concat_path(&(v285_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
          let mut v287_7 = Space::new();
          let mut v287_7_write = v287_7.write_zipper();
          for v287_7_byte in v283_21_cursor.child_mask().iter() {
            v283_21_cursor.descend_to_existing_byte(v287_7_byte);
            {
            let v288_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
            let v288_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v288_2));
            let v288_4: Space = if map_kernels::has_head(&(v288_3)) { singleton(&[]) } else { Space::new() };
            drop(v288_3);
            let v288_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v288_4));
            drop(v288_4);
            let v288_8: Space = if (&(v288_5)).is_empty() { Space::new() } else {
              let v289_6: Path = concat_path(&(v287_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v289_7: Space = routine_28(c, &(v289_6), &(*p1), &v283_21_cursor);
              map_map_kernels::compose(&(v288_5),&(v289_7))
            };
            drop(v288_5);
            let v288_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v288_2));
            drop(v288_2);
            let v288_10: Space = if map_kernels::has_head(&(v288_9)) { singleton(&[]) } else { Space::new() };
            drop(v288_9);
            let v288_12: Space = if (&(v288_10)).is_empty() { Space::new() } else {
              let v290_6: Path = concat_path(&(v287_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v290_11: Space = routine_29(c, &(v290_6), &(*p1), &v283_21_cursor);
              drop(v290_6);
              map_map_kernels::compose(&(v288_10),&(v290_11))
            };
            drop(v288_10);
            let v288_13: Space = map_map_kernels::unite(&(v288_8),&(v288_12));
            join_wrapped_into(&mut v287_7_write,&((v288_13).read_zipper()),&[]);
            }
            v283_21_cursor.ascend(1);
          }
          drop(v287_7_write);
          map_map_kernels::compose(&(v286_5),&(v287_7))
        };
        drop(v286_5);
        let v286_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v286_2));
        drop(v286_2);
        let v286_10: Space = if map_kernels::has_head(&(v286_9)) { singleton(&[]) } else { Space::new() };
        drop(v286_9);
        let v286_12: Space = if (&(v286_10)).is_empty() { Space::new() } else {
          let v291_6: Path = concat_path(&(v285_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
          let mut v291_11 = Space::new();
          let mut v291_11_write = v291_11.write_zipper();
          for v291_11_byte in v283_21_cursor.child_mask().iter() {
            v283_21_cursor.descend_to_existing_byte(v291_11_byte);
            {
            let v292_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
            let v292_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v292_2));
            let v292_4: Space = if map_kernels::has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
            drop(v292_3);
            let v292_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v292_4));
            drop(v292_4);
            let v292_8: Space = if (&(v292_5)).is_empty() { Space::new() } else {
              let v293_6: Path = concat_path(&(v291_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v293_7: Space = routine_28(c, &(v293_6), &(*p1), &v283_21_cursor);
              map_map_kernels::compose(&(v292_5),&(v293_7))
            };
            drop(v292_5);
            let v292_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v292_2));
            drop(v292_2);
            let v292_10: Space = if map_kernels::has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
            drop(v292_9);
            let v292_12: Space = if (&(v292_10)).is_empty() { Space::new() } else {
              let v294_6: Path = concat_path(&(v291_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v294_11: Space = routine_19(c, &(v294_6), &(*p1), &v283_21_cursor);
              drop(v294_6);
              map_map_kernels::compose(&(v292_10),&(v294_11))
            };
            drop(v292_10);
            let v292_13: Space = map_map_kernels::unite(&(v292_8),&(v292_12));
            join_wrapped_into(&mut v291_11_write,&((v292_13).read_zipper()),&[]);
            }
            v283_21_cursor.ascend(1);
          }
          drop(v291_11_write);
          drop(v291_6);
          map_map_kernels::compose(&(v286_10),&(v291_11))
        };
        drop(v286_10);
        let v286_13: Space = map_map_kernels::unite(&(v286_8),&(v286_12));
        join_wrapped_into(&mut v285_7_write,&((v286_13).read_zipper()),&[]);
        }
        v283_21_cursor.ascend(1);
      }
      drop(v285_7_write);
      map_map_kernels::compose(&(v284_5),&(v285_7))
    };
    drop(v284_5);
    let v284_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v284_2));
    drop(v284_2);
    let v284_10: Space = if map_kernels::has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
    drop(v284_9);
    let v284_12: Space = if (&(v284_10)).is_empty() { Space::new() } else {
      let v295_6: Path = concat_path(&(*p0),&v283_21_cursor.path()[v283_21_origin..(v283_21_origin + 1)]);
      let mut v295_11 = Space::new();
      let mut v295_11_write = v295_11.write_zipper();
      for v295_11_byte in v283_21_cursor.child_mask().iter() {
        v283_21_cursor.descend_to_existing_byte(v295_11_byte);
        {
        let v296_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
        let v296_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v296_2));
        let v296_4: Space = if map_kernels::has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
        drop(v296_3);
        let v296_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v296_4));
        drop(v296_4);
        let v296_8: Space = if (&(v296_5)).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v295_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
          let mut v297_7 = Space::new();
          let mut v297_7_write = v297_7.write_zipper();
          for v297_7_byte in v283_21_cursor.child_mask().iter() {
            v283_21_cursor.descend_to_existing_byte(v297_7_byte);
            {
            let v298_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
            let v298_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v298_2));
            let v298_4: Space = if map_kernels::has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v298_4));
            drop(v298_4);
            let v298_8: Space = if (&(v298_5)).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v297_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v299_7: Space = routine_28(c, &(v299_6), &(*p1), &v283_21_cursor);
              map_map_kernels::compose(&(v298_5),&(v299_7))
            };
            drop(v298_5);
            let v298_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v298_2));
            drop(v298_2);
            let v298_10: Space = if map_kernels::has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
            drop(v298_9);
            let v298_12: Space = if (&(v298_10)).is_empty() { Space::new() } else {
              let v300_6: Path = concat_path(&(v297_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v300_11: Space = routine_29(c, &(v300_6), &(*p1), &v283_21_cursor);
              drop(v300_6);
              map_map_kernels::compose(&(v298_10),&(v300_11))
            };
            drop(v298_10);
            let v298_13: Space = map_map_kernels::unite(&(v298_8),&(v298_12));
            join_wrapped_into(&mut v297_7_write,&((v298_13).read_zipper()),&[]);
            }
            v283_21_cursor.ascend(1);
          }
          drop(v297_7_write);
          map_map_kernels::compose(&(v296_5),&(v297_7))
        };
        drop(v296_5);
        let v296_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v296_2));
        drop(v296_2);
        let v296_10: Space = if map_kernels::has_head(&(v296_9)) { singleton(&[]) } else { Space::new() };
        drop(v296_9);
        let v296_11: Space = map_view_kernels::compose(&(v296_10),&v283_21_cursor);
        drop(v296_10);
        let v301_6: Path = concat_path(&(v295_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
        let v296_12: Space = map_kernels::wrap(&(v296_11),&(v301_6));
        drop(v296_11);
        let v296_13: Space = map_kernels::wrap(&(v296_12),&(*p1));
        drop(v296_12);
        let v296_14: Space = map_map_kernels::unite(&(v296_8),&(v296_13));
        drop(v296_13);
        join_wrapped_into(&mut v295_11_write,&((v296_14).read_zipper()),&[]);
        }
        v283_21_cursor.ascend(1);
      }
      drop(v295_11_write);
      drop(v295_6);
      map_map_kernels::compose(&(v284_10),&(v295_11))
    };
    drop(v284_10);
    let v284_13: Space = map_map_kernels::unite(&(v284_8),&(v284_12));
    join_wrapped_into(&mut v283_21_write,&((v284_13).read_zipper()),&[]);
    }
    v283_21_cursor.ascend(1);
  }
  drop(v283_21_cursor);
  drop(v283_21_write);
  (v283_21).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v302_15 = Space::new();
  let mut v302_15_write = v302_15.write_zipper();
  let mut v302_15_cursor = (*s0).read_zipper();
  let v302_15_origin = v302_15_cursor.path().len();
  for v302_15_byte in v302_15_cursor.child_mask().iter() {
    v302_15_cursor.descend_to_existing_byte(v302_15_byte);
    {
    let v303_2: Space = singleton(&v302_15_cursor.path()[v302_15_origin..(v302_15_origin + 1)]);
    let v303_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v303_2));
    let v303_4: Space = if map_kernels::has_head(&(v303_3)) { singleton(&[]) } else { Space::new() };
    drop(v303_3);
    let v303_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v303_4));
    drop(v303_4);
    let v303_8: Space = if (&(v303_5)).is_empty() { Space::new() } else {
      let v304_6: Path = concat_path(&(*p0),&v302_15_cursor.path()[v302_15_origin..(v302_15_origin + 1)]);
      let mut v304_7 = Space::new();
      let mut v304_7_write = v304_7.write_zipper();
      for v304_7_byte in v302_15_cursor.child_mask().iter() {
        v302_15_cursor.descend_to_existing_byte(v304_7_byte);
        {
        let v305_2: Space = singleton(&v302_15_cursor.path()[(v302_15_origin + 1)..(v302_15_origin + 2)]);
        let v305_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v305_2));
        let v305_4: Space = if map_kernels::has_head(&(v305_3)) { singleton(&[]) } else { Space::new() };
        drop(v305_3);
        let v305_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v305_4));
        drop(v305_4);
        let v305_8: Space = if (&(v305_5)).is_empty() { Space::new() } else {
          let v306_6: Path = concat_path(&(v304_6),&v302_15_cursor.path()[(v302_15_origin + 1)..(v302_15_origin + 2)]);
          let mut v306_7 = Space::new();
          let mut v306_7_write = v306_7.write_zipper();
          for v306_7_byte in v302_15_cursor.child_mask().iter() {
            v302_15_cursor.descend_to_existing_byte(v306_7_byte);
            {
            let v307_2: Space = singleton(&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
            let v307_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v307_2));
            let v307_4: Space = if map_kernels::has_head(&(v307_3)) { singleton(&[]) } else { Space::new() };
            drop(v307_3);
            let v307_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v307_4));
            drop(v307_4);
            let v307_8: Space = if (&(v307_5)).is_empty() { Space::new() } else {
              let v308_6: Path = concat_path(&(v306_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v308_7: Space = routine_28(c, &(v308_6), &(*p1), &v302_15_cursor);
              map_map_kernels::compose(&(v307_5),&(v308_7))
            };
            drop(v307_5);
            let v307_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v307_2));
            drop(v307_2);
            let v307_10: Space = if map_kernels::has_head(&(v307_9)) { singleton(&[]) } else { Space::new() };
            drop(v307_9);
            let v307_12: Space = if (&(v307_10)).is_empty() { Space::new() } else {
              let v309_6: Path = concat_path(&(v306_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v309_11: Space = routine_29(c, &(v309_6), &(*p1), &v302_15_cursor);
              drop(v309_6);
              map_map_kernels::compose(&(v307_10),&(v309_11))
            };
            drop(v307_10);
            let v307_13: Space = map_map_kernels::unite(&(v307_8),&(v307_12));
            join_wrapped_into(&mut v306_7_write,&((v307_13).read_zipper()),&[]);
            }
            v302_15_cursor.ascend(1);
          }
          drop(v306_7_write);
          map_map_kernels::compose(&(v305_5),&(v306_7))
        };
        drop(v305_5);
        let v305_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v305_2));
        drop(v305_2);
        let v305_10: Space = if map_kernels::has_head(&(v305_9)) { singleton(&[]) } else { Space::new() };
        drop(v305_9);
        let v305_12: Space = if (&(v305_10)).is_empty() { Space::new() } else {
          let v310_6: Path = concat_path(&(v304_6),&v302_15_cursor.path()[(v302_15_origin + 1)..(v302_15_origin + 2)]);
          let mut v310_11 = Space::new();
          let mut v310_11_write = v310_11.write_zipper();
          for v310_11_byte in v302_15_cursor.child_mask().iter() {
            v302_15_cursor.descend_to_existing_byte(v310_11_byte);
            {
            let v311_2: Space = singleton(&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
            let v311_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v311_2));
            let v311_4: Space = if map_kernels::has_head(&(v311_3)) { singleton(&[]) } else { Space::new() };
            drop(v311_3);
            let v311_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v311_4));
            drop(v311_4);
            let v311_8: Space = if (&(v311_5)).is_empty() { Space::new() } else {
              let v312_6: Path = concat_path(&(v310_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v312_7: Space = routine_28(c, &(v312_6), &(*p1), &v302_15_cursor);
              map_map_kernels::compose(&(v311_5),&(v312_7))
            };
            drop(v311_5);
            let v311_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v311_2));
            drop(v311_2);
            let v311_10: Space = if map_kernels::has_head(&(v311_9)) { singleton(&[]) } else { Space::new() };
            drop(v311_9);
            let v311_12: Space = if (&(v311_10)).is_empty() { Space::new() } else {
              let v313_6: Path = concat_path(&(v310_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v313_11: Space = routine_19(c, &(v313_6), &(*p1), &v302_15_cursor);
              drop(v313_6);
              map_map_kernels::compose(&(v311_10),&(v313_11))
            };
            drop(v311_10);
            let v311_13: Space = map_map_kernels::unite(&(v311_8),&(v311_12));
            join_wrapped_into(&mut v310_11_write,&((v311_13).read_zipper()),&[]);
            }
            v302_15_cursor.ascend(1);
          }
          drop(v310_11_write);
          drop(v310_6);
          map_map_kernels::compose(&(v305_10),&(v310_11))
        };
        drop(v305_10);
        let v305_13: Space = map_map_kernels::unite(&(v305_8),&(v305_12));
        join_wrapped_into(&mut v304_7_write,&((v305_13).read_zipper()),&[]);
        }
        v302_15_cursor.ascend(1);
      }
      drop(v304_7_write);
      map_map_kernels::compose(&(v303_5),&(v304_7))
    };
    drop(v303_5);
    let v303_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v303_2));
    drop(v303_2);
    let v303_10: Space = if map_kernels::has_head(&(v303_9)) { singleton(&[]) } else { Space::new() };
    drop(v303_9);
    let v303_11: Space = map_view_kernels::compose(&(v303_10),&v302_15_cursor);
    drop(v303_10);
    let v314_6: Path = concat_path(&(*p0),&v302_15_cursor.path()[v302_15_origin..(v302_15_origin + 1)]);
    let v303_12: Space = map_kernels::wrap(&(v303_11),&(v314_6));
    drop(v303_11);
    let v303_13: Space = map_kernels::wrap(&(v303_12),&(*p1));
    drop(v303_12);
    let v303_14: Space = map_map_kernels::unite(&(v303_8),&(v303_13));
    drop(v303_13);
    join_wrapped_into(&mut v302_15_write,&((v303_14).read_zipper()),&[]);
    }
    v302_15_cursor.ascend(1);
  }
  drop(v302_15_cursor);
  drop(v302_15_write);
  (v302_15).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v315_28 = Space::new();
  let mut v315_28_write = v315_28.write_zipper();
  let mut v315_28_cursor = (*s0).read_zipper();
  let v315_28_origin = v315_28_cursor.path().len();
  for v315_28_byte in v315_28_cursor.child_mask().iter() {
    v315_28_cursor.descend_to_existing_byte(v315_28_byte);
    {
    let v316_2: Space = singleton(&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]);
    let v316_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v316_2));
    let v316_4: Space = if map_kernels::has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
    drop(v316_3);
    let v316_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v316_4));
    drop(v316_4);
    let v316_8: Space = if (&(v316_5)).is_empty() { Space::new() } else {
      let v317_6: Path = concat_path(&(*p0),&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]);
      let mut v317_7 = Space::new();
      let mut v317_7_write = v317_7.write_zipper();
      for v317_7_byte in v315_28_cursor.child_mask().iter() {
        v315_28_cursor.descend_to_existing_byte(v317_7_byte);
        {
        let v318_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
        let v318_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v318_2));
        let v318_4: Space = if map_kernels::has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
        drop(v318_3);
        let v318_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v318_4));
        drop(v318_4);
        let v318_8: Space = if (&(v318_5)).is_empty() { Space::new() } else {
          let v319_6: Path = concat_path(&(v317_6),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let mut v319_7 = Space::new();
          let mut v319_7_write = v319_7.write_zipper();
          for v319_7_byte in v315_28_cursor.child_mask().iter() {
            v315_28_cursor.descend_to_existing_byte(v319_7_byte);
            {
            let v320_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
            let v320_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v320_2));
            let v320_4: Space = if map_kernels::has_head(&(v320_3)) { singleton(&[]) } else { Space::new() };
            drop(v320_3);
            let v320_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v320_4));
            drop(v320_4);
            let v320_8: Space = if (&(v320_5)).is_empty() { Space::new() } else {
              let v321_6: Path = concat_path(&(v319_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v321_7: Space = routine_30(c, &(v321_6), &(*p1), &v315_28_cursor, &(*s1));
              map_map_kernels::compose(&(v320_5),&(v321_7))
            };
            drop(v320_5);
            let v320_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v320_2));
            drop(v320_2);
            let v320_10: Space = if map_kernels::has_head(&(v320_9)) { singleton(&[]) } else { Space::new() };
            drop(v320_9);
            let v320_12: Space = if (&(v320_10)).is_empty() { Space::new() } else {
              let v322_6: Path = concat_path(&(v319_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v322_11: Space = routine_31(c, &(v322_6), &(*p1), &v315_28_cursor, &(*s1));
              drop(v322_6);
              map_map_kernels::compose(&(v320_10),&(v322_11))
            };
            drop(v320_10);
            let v320_13: Space = map_map_kernels::unite(&(v320_8),&(v320_12));
            join_wrapped_into(&mut v319_7_write,&((v320_13).read_zipper()),&[]);
            }
            v315_28_cursor.ascend(1);
          }
          drop(v319_7_write);
          map_map_kernels::compose(&(v318_5),&(v319_7))
        };
        drop(v318_5);
        let v318_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v318_2));
        drop(v318_2);
        let v318_10: Space = if map_kernels::has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
        drop(v318_9);
        let v318_12: Space = if (&(v318_10)).is_empty() { Space::new() } else {
          let v323_6: Path = concat_path(&(v317_6),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let mut v323_11 = Space::new();
          let mut v323_11_write = v323_11.write_zipper();
          for v323_11_byte in v315_28_cursor.child_mask().iter() {
            v315_28_cursor.descend_to_existing_byte(v323_11_byte);
            {
            let v324_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
            let v324_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v324_2));
            let v324_4: Space = if map_kernels::has_head(&(v324_3)) { singleton(&[]) } else { Space::new() };
            drop(v324_3);
            let v324_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v324_4));
            drop(v324_4);
            let v324_8: Space = if (&(v324_5)).is_empty() { Space::new() } else {
              let v325_6: Path = concat_path(&(v323_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v325_7: Space = routine_30(c, &(v325_6), &(*p1), &v315_28_cursor, &(*s1));
              map_map_kernels::compose(&(v324_5),&(v325_7))
            };
            drop(v324_5);
            let v324_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v324_2));
            drop(v324_2);
            let v324_10: Space = if map_kernels::has_head(&(v324_9)) { singleton(&[]) } else { Space::new() };
            drop(v324_9);
            let v324_12: Space = if (&(v324_10)).is_empty() { Space::new() } else {
              let v326_6: Path = concat_path(&(v323_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v326_11: Space = routine_10(c, &(v326_6), &(*p1), &v315_28_cursor, &(*s1));
              drop(v326_6);
              map_map_kernels::compose(&(v324_10),&(v326_11))
            };
            drop(v324_10);
            let v324_13: Space = map_map_kernels::unite(&(v324_8),&(v324_12));
            join_wrapped_into(&mut v323_11_write,&((v324_13).read_zipper()),&[]);
            }
            v315_28_cursor.ascend(1);
          }
          drop(v323_11_write);
          drop(v323_6);
          map_map_kernels::compose(&(v318_10),&(v323_11))
        };
        drop(v318_10);
        let v318_13: Space = map_map_kernels::unite(&(v318_8),&(v318_12));
        join_wrapped_into(&mut v317_7_write,&((v318_13).read_zipper()),&[]);
        }
        v315_28_cursor.ascend(1);
      }
      drop(v317_7_write);
      map_map_kernels::compose(&(v316_5),&(v317_7))
    };
    drop(v316_5);
    let v316_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v316_2));
    drop(v316_2);
    let v316_10: Space = if map_kernels::has_head(&(v316_9)) { singleton(&[]) } else { Space::new() };
    drop(v316_9);
    let v316_13: Space = if (&(v316_10)).is_empty() { Space::new() } else {
      let v327_6: Path = concat_path(&(*p0),&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]);
      let mut v327_12 = Space::new();
      let mut v327_12_write = v327_12.write_zipper();
      for v327_12_byte in v315_28_cursor.child_mask().iter() {
        v315_28_cursor.descend_to_existing_byte(v327_12_byte);
        {
        let v328_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
        let v328_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v328_2));
        let v328_4: Space = if map_kernels::has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
        drop(v328_3);
        let v328_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v328_4));
        drop(v328_4);
        let v328_8: Space = if (&(v328_5)).is_empty() { Space::new() } else {
          let v329_6: Path = concat_path(&(v327_6),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let mut v329_7 = Space::new();
          let mut v329_7_write = v329_7.write_zipper();
          for v329_7_byte in v315_28_cursor.child_mask().iter() {
            v315_28_cursor.descend_to_existing_byte(v329_7_byte);
            {
            let v330_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
            let v330_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v330_2));
            let v330_4: Space = if map_kernels::has_head(&(v330_3)) { singleton(&[]) } else { Space::new() };
            drop(v330_3);
            let v330_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v330_4));
            drop(v330_4);
            let v330_8: Space = if (&(v330_5)).is_empty() { Space::new() } else {
              let v331_6: Path = concat_path(&(v329_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v331_7: Space = routine_30(c, &(v331_6), &(*p1), &v315_28_cursor, &(*s1));
              map_map_kernels::compose(&(v330_5),&(v331_7))
            };
            drop(v330_5);
            let v330_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v330_2));
            drop(v330_2);
            let v330_10: Space = if map_kernels::has_head(&(v330_9)) { singleton(&[]) } else { Space::new() };
            drop(v330_9);
            let v330_12: Space = if (&(v330_10)).is_empty() { Space::new() } else {
              let v332_6: Path = concat_path(&(v329_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v332_11: Space = routine_31(c, &(v332_6), &(*p1), &v315_28_cursor, &(*s1));
              drop(v332_6);
              map_map_kernels::compose(&(v330_10),&(v332_11))
            };
            drop(v330_10);
            let v330_13: Space = map_map_kernels::unite(&(v330_8),&(v330_12));
            join_wrapped_into(&mut v329_7_write,&((v330_13).read_zipper()),&[]);
            }
            v315_28_cursor.ascend(1);
          }
          drop(v329_7_write);
          drop(v329_6);
          map_map_kernels::compose(&(v328_5),&(v329_7))
        };
        drop(v328_5);
        let v328_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v328_2));
        drop(v328_2);
        let v328_10: Space = if map_kernels::has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
        drop(v328_9);
        let v328_13: Space = if (&(v328_10)).is_empty() { Space::new() } else {
          let mut v333_12 = Space::new();
          let mut v333_12_write = v333_12.write_zipper();
          let mut v333_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let v333_12_origin = v333_12_cursor.path().len();
          for v333_12_byte in v333_12_cursor.child_mask().iter() {
            v333_12_cursor.descend_to_existing_byte(v333_12_byte);
            {
            let v334_2: Space = singleton(&v333_12_cursor.path()[v333_12_origin..(v333_12_origin + 1)]);
            let v334_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v334_2));
            let v334_4: Space = if map_kernels::has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
            drop(v334_3);
            let v334_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v334_4));
            drop(v334_4);
            let v334_7: Space = if (&(v334_5)).is_empty() { Space::new() } else {
              let v335_6: Space = routine_13(c, &v333_12_cursor.path()[v333_12_origin..(v333_12_origin + 1)], &(*p1), &v333_12_cursor);
              map_map_kernels::compose(&(v334_5),&(v335_6))
            };
            drop(v334_5);
            let v334_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v334_2));
            drop(v334_2);
            let v334_9: Space = if map_kernels::has_head(&(v334_8)) { singleton(&[]) } else { Space::new() };
            drop(v334_8);
            let v334_11: Space = if (&(v334_9)).is_empty() { Space::new() } else {
              let v336_10: Space = routine_14(c, &v333_12_cursor.path()[v333_12_origin..(v333_12_origin + 1)], &(*p1), &v333_12_cursor);
              map_map_kernels::compose(&(v334_9),&(v336_10))
            };
            drop(v334_9);
            let v334_12: Space = map_map_kernels::unite(&(v334_7),&(v334_11));
            join_wrapped_into(&mut v333_12_write,&((v334_12).read_zipper()),&[]);
            }
            v333_12_cursor.ascend(1);
          }
          drop(v333_12_cursor);
          drop(v333_12_write);
          map_map_kernels::compose(&(v328_10),&(v333_12))
        };
        drop(v328_10);
        let v328_14: Space = map_map_kernels::unite(&(v328_8),&(v328_13));
        join_wrapped_into(&mut v327_12_write,&((v328_14).read_zipper()),&[]);
        }
        v315_28_cursor.ascend(1);
      }
      drop(v327_12_write);
      drop(v327_6);
      map_map_kernels::compose(&(v316_10),&(v327_12))
    };
    drop(v316_10);
    let v316_14: Space = map_map_kernels::unite(&(v316_8),&(v316_13));
    join_wrapped_into(&mut v315_28_write,&((v316_14).read_zipper()),&[]);
    }
    v315_28_cursor.ascend(1);
  }
  drop(v315_28_cursor);
  drop(v315_28_write);
  (v315_28).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v337_28 = Space::new();
  let mut v337_28_write = v337_28.write_zipper();
  let mut v337_28_cursor = (*s0).read_zipper();
  let v337_28_origin = v337_28_cursor.path().len();
  for v337_28_byte in v337_28_cursor.child_mask().iter() {
    v337_28_cursor.descend_to_existing_byte(v337_28_byte);
    {
    let v338_2: Space = singleton(&v337_28_cursor.path()[v337_28_origin..(v337_28_origin + 1)]);
    let v338_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v338_2));
    let v338_4: Space = if map_kernels::has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
    drop(v338_3);
    let v338_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v338_4));
    drop(v338_4);
    let v338_8: Space = if (&(v338_5)).is_empty() { Space::new() } else {
      let v339_6: Path = concat_path(&(*p0),&v337_28_cursor.path()[v337_28_origin..(v337_28_origin + 1)]);
      let mut v339_7 = Space::new();
      let mut v339_7_write = v339_7.write_zipper();
      for v339_7_byte in v337_28_cursor.child_mask().iter() {
        v337_28_cursor.descend_to_existing_byte(v339_7_byte);
        {
        let v340_2: Space = singleton(&v337_28_cursor.path()[(v337_28_origin + 1)..(v337_28_origin + 2)]);
        let v340_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v340_2));
        let v340_4: Space = if map_kernels::has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
        drop(v340_3);
        let v340_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v340_4));
        drop(v340_4);
        let v340_8: Space = if (&(v340_5)).is_empty() { Space::new() } else {
          let v341_6: Path = concat_path(&(v339_6),&v337_28_cursor.path()[(v337_28_origin + 1)..(v337_28_origin + 2)]);
          let mut v341_7 = Space::new();
          let mut v341_7_write = v341_7.write_zipper();
          for v341_7_byte in v337_28_cursor.child_mask().iter() {
            v337_28_cursor.descend_to_existing_byte(v341_7_byte);
            {
            let v342_2: Space = singleton(&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
            let v342_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v342_2));
            let v342_4: Space = if map_kernels::has_head(&(v342_3)) { singleton(&[]) } else { Space::new() };
            drop(v342_3);
            let v342_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v342_4));
            drop(v342_4);
            let v342_8: Space = if (&(v342_5)).is_empty() { Space::new() } else {
              let v343_6: Path = concat_path(&(v341_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v343_7: Space = routine_30(c, &(v343_6), &(*p1), &v337_28_cursor, &(*s1));
              map_map_kernels::compose(&(v342_5),&(v343_7))
            };
            drop(v342_5);
            let v342_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v342_2));
            drop(v342_2);
            let v342_10: Space = if map_kernels::has_head(&(v342_9)) { singleton(&[]) } else { Space::new() };
            drop(v342_9);
            let v342_12: Space = if (&(v342_10)).is_empty() { Space::new() } else {
              let v344_6: Path = concat_path(&(v341_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v344_11: Space = routine_31(c, &(v344_6), &(*p1), &v337_28_cursor, &(*s1));
              drop(v344_6);
              map_map_kernels::compose(&(v342_10),&(v344_11))
            };
            drop(v342_10);
            let v342_13: Space = map_map_kernels::unite(&(v342_8),&(v342_12));
            join_wrapped_into(&mut v341_7_write,&((v342_13).read_zipper()),&[]);
            }
            v337_28_cursor.ascend(1);
          }
          drop(v341_7_write);
          map_map_kernels::compose(&(v340_5),&(v341_7))
        };
        drop(v340_5);
        let v340_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v340_2));
        drop(v340_2);
        let v340_10: Space = if map_kernels::has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
        drop(v340_9);
        let v340_12: Space = if (&(v340_10)).is_empty() { Space::new() } else {
          let v345_6: Path = concat_path(&(v339_6),&v337_28_cursor.path()[(v337_28_origin + 1)..(v337_28_origin + 2)]);
          let mut v345_11 = Space::new();
          let mut v345_11_write = v345_11.write_zipper();
          for v345_11_byte in v337_28_cursor.child_mask().iter() {
            v337_28_cursor.descend_to_existing_byte(v345_11_byte);
            {
            let v346_2: Space = singleton(&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
            let v346_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v346_2));
            let v346_4: Space = if map_kernels::has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
            drop(v346_3);
            let v346_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v346_4));
            drop(v346_4);
            let v346_8: Space = if (&(v346_5)).is_empty() { Space::new() } else {
              let v347_6: Path = concat_path(&(v345_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v347_7: Space = routine_30(c, &(v347_6), &(*p1), &v337_28_cursor, &(*s1));
              map_map_kernels::compose(&(v346_5),&(v347_7))
            };
            drop(v346_5);
            let v346_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v346_2));
            drop(v346_2);
            let v346_10: Space = if map_kernels::has_head(&(v346_9)) { singleton(&[]) } else { Space::new() };
            drop(v346_9);
            let v346_12: Space = if (&(v346_10)).is_empty() { Space::new() } else {
              let v348_6: Path = concat_path(&(v345_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v348_11: Space = routine_10(c, &(v348_6), &(*p1), &v337_28_cursor, &(*s1));
              drop(v348_6);
              map_map_kernels::compose(&(v346_10),&(v348_11))
            };
            drop(v346_10);
            let v346_13: Space = map_map_kernels::unite(&(v346_8),&(v346_12));
            join_wrapped_into(&mut v345_11_write,&((v346_13).read_zipper()),&[]);
            }
            v337_28_cursor.ascend(1);
          }
          drop(v345_11_write);
          drop(v345_6);
          map_map_kernels::compose(&(v340_10),&(v345_11))
        };
        drop(v340_10);
        let v340_13: Space = map_map_kernels::unite(&(v340_8),&(v340_12));
        join_wrapped_into(&mut v339_7_write,&((v340_13).read_zipper()),&[]);
        }
        v337_28_cursor.ascend(1);
      }
      drop(v339_7_write);
      drop(v339_6);
      map_map_kernels::compose(&(v338_5),&(v339_7))
    };
    drop(v338_5);
    let v338_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v338_2));
    drop(v338_2);
    let v338_10: Space = if map_kernels::has_head(&(v338_9)) { singleton(&[]) } else { Space::new() };
    drop(v338_9);
    let v338_13: Space = if (&(v338_10)).is_empty() { Space::new() } else {
      let mut v349_12 = Space::new();
      let mut v349_12_write = v349_12.write_zipper();
      let mut v349_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v337_28_cursor.path()[v337_28_origin..(v337_28_origin + 1)]);
      let v349_12_origin = v349_12_cursor.path().len();
      for v349_12_byte in v349_12_cursor.child_mask().iter() {
        v349_12_cursor.descend_to_existing_byte(v349_12_byte);
        {
        let v350_2: Space = singleton(&v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 1)]);
        let v350_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v350_2));
        let v350_4: Space = if map_kernels::has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
        drop(v350_3);
        let v350_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v350_4));
        drop(v350_4);
        let v350_7: Space = if (&(v350_5)).is_empty() { Space::new() } else {
          let mut v351_6 = Space::new();
          let mut v351_6_write = v351_6.write_zipper();
          for v351_6_byte in v349_12_cursor.child_mask().iter() {
            v349_12_cursor.descend_to_existing_byte(v351_6_byte);
            {
            let v352_2: Space = singleton(&v349_12_cursor.path()[(v349_12_origin + 1)..(v349_12_origin + 2)]);
            let v352_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v352_2));
            let v352_4: Space = if map_kernels::has_head(&(v352_3)) { singleton(&[]) } else { Space::new() };
            drop(v352_3);
            let v352_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v352_4));
            drop(v352_4);
            let v352_8: Space = if (&(v352_5)).is_empty() { Space::new() } else {
              let v353_7: Space = routine_17(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              map_map_kernels::compose(&(v352_5),&(v353_7))
            };
            drop(v352_5);
            let v352_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v352_2));
            drop(v352_2);
            let v352_10: Space = if map_kernels::has_head(&(v352_9)) { singleton(&[]) } else { Space::new() };
            drop(v352_9);
            let v352_12: Space = if (&(v352_10)).is_empty() { Space::new() } else {
              let v354_11: Space = routine_18(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              map_map_kernels::compose(&(v352_10),&(v354_11))
            };
            drop(v352_10);
            let v352_13: Space = map_map_kernels::unite(&(v352_8),&(v352_12));
            join_wrapped_into(&mut v351_6_write,&((v352_13).read_zipper()),&[]);
            }
            v349_12_cursor.ascend(1);
          }
          drop(v351_6_write);
          map_map_kernels::compose(&(v350_5),&(v351_6))
        };
        drop(v350_5);
        let v350_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v350_2));
        drop(v350_2);
        let v350_9: Space = if map_kernels::has_head(&(v350_8)) { singleton(&[]) } else { Space::new() };
        drop(v350_8);
        let v350_11: Space = if (&(v350_9)).is_empty() { Space::new() } else {
          let mut v355_10 = Space::new();
          let mut v355_10_write = v355_10.write_zipper();
          for v355_10_byte in v349_12_cursor.child_mask().iter() {
            v349_12_cursor.descend_to_existing_byte(v355_10_byte);
            {
            let v356_2: Space = singleton(&v349_12_cursor.path()[(v349_12_origin + 1)..(v349_12_origin + 2)]);
            let v356_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v356_2));
            let v356_4: Space = if map_kernels::has_head(&(v356_3)) { singleton(&[]) } else { Space::new() };
            drop(v356_3);
            let v356_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v356_4));
            drop(v356_4);
            let v356_8: Space = if (&(v356_5)).is_empty() { Space::new() } else {
              let v357_7: Space = routine_17(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              map_map_kernels::compose(&(v356_5),&(v357_7))
            };
            drop(v356_5);
            let v356_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v356_2));
            drop(v356_2);
            let v356_10: Space = if map_kernels::has_head(&(v356_9)) { singleton(&[]) } else { Space::new() };
            drop(v356_9);
            let v356_12: Space = if (&(v356_10)).is_empty() { Space::new() } else {
              let v358_11: Space = routine_19(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              map_map_kernels::compose(&(v356_10),&(v358_11))
            };
            drop(v356_10);
            let v356_13: Space = map_map_kernels::unite(&(v356_8),&(v356_12));
            join_wrapped_into(&mut v355_10_write,&((v356_13).read_zipper()),&[]);
            }
            v349_12_cursor.ascend(1);
          }
          drop(v355_10_write);
          map_map_kernels::compose(&(v350_9),&(v355_10))
        };
        drop(v350_9);
        let v350_12: Space = map_map_kernels::unite(&(v350_7),&(v350_11));
        join_wrapped_into(&mut v349_12_write,&((v350_12).read_zipper()),&[]);
        }
        v349_12_cursor.ascend(1);
      }
      drop(v349_12_cursor);
      drop(v349_12_write);
      map_map_kernels::compose(&(v338_10),&(v349_12))
    };
    drop(v338_10);
    let v338_14: Space = map_map_kernels::unite(&(v338_8),&(v338_13));
    join_wrapped_into(&mut v337_28_write,&((v338_14).read_zipper()),&[]);
    }
    v337_28_cursor.ascend(1);
  }
  drop(v337_28_cursor);
  drop(v337_28_write);
  (v337_28).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v359_21 = Space::new();
  let mut v359_21_write = v359_21.write_zipper();
  let mut v359_21_cursor = (*s0).read_zipper();
  let v359_21_origin = v359_21_cursor.path().len();
  for v359_21_byte in v359_21_cursor.child_mask().iter() {
    v359_21_cursor.descend_to_existing_byte(v359_21_byte);
    {
    let v360_2: Space = singleton(&v359_21_cursor.path()[v359_21_origin..(v359_21_origin + 1)]);
    let v360_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v360_2));
    let v360_4: Space = if map_kernels::has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
    drop(v360_3);
    let v360_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v360_4));
    drop(v360_4);
    let v360_8: Space = if (&(v360_5)).is_empty() { Space::new() } else {
      let v361_6: Path = concat_path(&(*p0),&v359_21_cursor.path()[v359_21_origin..(v359_21_origin + 1)]);
      let mut v361_7 = Space::new();
      let mut v361_7_write = v361_7.write_zipper();
      for v361_7_byte in v359_21_cursor.child_mask().iter() {
        v359_21_cursor.descend_to_existing_byte(v361_7_byte);
        {
        let v362_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
        let v362_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v362_2));
        let v362_4: Space = if map_kernels::has_head(&(v362_3)) { singleton(&[]) } else { Space::new() };
        drop(v362_3);
        let v362_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v362_4));
        drop(v362_4);
        let v362_8: Space = if (&(v362_5)).is_empty() { Space::new() } else {
          let v363_6: Path = concat_path(&(v361_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
          let mut v363_7 = Space::new();
          let mut v363_7_write = v363_7.write_zipper();
          for v363_7_byte in v359_21_cursor.child_mask().iter() {
            v359_21_cursor.descend_to_existing_byte(v363_7_byte);
            {
            let v364_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
            let v364_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v364_2));
            let v364_4: Space = if map_kernels::has_head(&(v364_3)) { singleton(&[]) } else { Space::new() };
            drop(v364_3);
            let v364_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v364_4));
            drop(v364_4);
            let v364_8: Space = if (&(v364_5)).is_empty() { Space::new() } else {
              let v365_6: Path = concat_path(&(v363_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v365_7: Space = routine_32(c, &(v365_6), &(*p1), &v359_21_cursor);
              map_map_kernels::compose(&(v364_5),&(v365_7))
            };
            drop(v364_5);
            let v364_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v364_2));
            drop(v364_2);
            let v364_10: Space = if map_kernels::has_head(&(v364_9)) { singleton(&[]) } else { Space::new() };
            drop(v364_9);
            let v364_12: Space = if (&(v364_10)).is_empty() { Space::new() } else {
              let v366_6: Path = concat_path(&(v363_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v366_11: Space = routine_33(c, &(v366_6), &(*p1), &v359_21_cursor);
              drop(v366_6);
              map_map_kernels::compose(&(v364_10),&(v366_11))
            };
            drop(v364_10);
            let v364_13: Space = map_map_kernels::unite(&(v364_8),&(v364_12));
            join_wrapped_into(&mut v363_7_write,&((v364_13).read_zipper()),&[]);
            }
            v359_21_cursor.ascend(1);
          }
          drop(v363_7_write);
          map_map_kernels::compose(&(v362_5),&(v363_7))
        };
        drop(v362_5);
        let v362_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v362_2));
        drop(v362_2);
        let v362_10: Space = if map_kernels::has_head(&(v362_9)) { singleton(&[]) } else { Space::new() };
        drop(v362_9);
        let v362_12: Space = if (&(v362_10)).is_empty() { Space::new() } else {
          let v367_6: Path = concat_path(&(v361_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
          let mut v367_11 = Space::new();
          let mut v367_11_write = v367_11.write_zipper();
          for v367_11_byte in v359_21_cursor.child_mask().iter() {
            v359_21_cursor.descend_to_existing_byte(v367_11_byte);
            {
            let v368_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
            let v368_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v368_2));
            let v368_4: Space = if map_kernels::has_head(&(v368_3)) { singleton(&[]) } else { Space::new() };
            drop(v368_3);
            let v368_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v368_4));
            drop(v368_4);
            let v368_8: Space = if (&(v368_5)).is_empty() { Space::new() } else {
              let v369_6: Path = concat_path(&(v367_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v369_7: Space = routine_32(c, &(v369_6), &(*p1), &v359_21_cursor);
              map_map_kernels::compose(&(v368_5),&(v369_7))
            };
            drop(v368_5);
            let v368_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v368_2));
            drop(v368_2);
            let v368_10: Space = if map_kernels::has_head(&(v368_9)) { singleton(&[]) } else { Space::new() };
            drop(v368_9);
            let v368_12: Space = if (&(v368_10)).is_empty() { Space::new() } else {
              let v370_6: Path = concat_path(&(v367_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v370_11: Space = routine_19(c, &(v370_6), &(*p1), &v359_21_cursor);
              drop(v370_6);
              map_map_kernels::compose(&(v368_10),&(v370_11))
            };
            drop(v368_10);
            let v368_13: Space = map_map_kernels::unite(&(v368_8),&(v368_12));
            join_wrapped_into(&mut v367_11_write,&((v368_13).read_zipper()),&[]);
            }
            v359_21_cursor.ascend(1);
          }
          drop(v367_11_write);
          drop(v367_6);
          map_map_kernels::compose(&(v362_10),&(v367_11))
        };
        drop(v362_10);
        let v362_13: Space = map_map_kernels::unite(&(v362_8),&(v362_12));
        join_wrapped_into(&mut v361_7_write,&((v362_13).read_zipper()),&[]);
        }
        v359_21_cursor.ascend(1);
      }
      drop(v361_7_write);
      map_map_kernels::compose(&(v360_5),&(v361_7))
    };
    drop(v360_5);
    let v360_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v360_2));
    drop(v360_2);
    let v360_10: Space = if map_kernels::has_head(&(v360_9)) { singleton(&[]) } else { Space::new() };
    drop(v360_9);
    let v360_12: Space = if (&(v360_10)).is_empty() { Space::new() } else {
      let v371_6: Path = concat_path(&(*p0),&v359_21_cursor.path()[v359_21_origin..(v359_21_origin + 1)]);
      let mut v371_11 = Space::new();
      let mut v371_11_write = v371_11.write_zipper();
      for v371_11_byte in v359_21_cursor.child_mask().iter() {
        v359_21_cursor.descend_to_existing_byte(v371_11_byte);
        {
        let v372_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
        let v372_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v372_2));
        let v372_4: Space = if map_kernels::has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
        drop(v372_3);
        let v372_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v372_4));
        drop(v372_4);
        let v372_8: Space = if (&(v372_5)).is_empty() { Space::new() } else {
          let v373_6: Path = concat_path(&(v371_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
          let mut v373_7 = Space::new();
          let mut v373_7_write = v373_7.write_zipper();
          for v373_7_byte in v359_21_cursor.child_mask().iter() {
            v359_21_cursor.descend_to_existing_byte(v373_7_byte);
            {
            let v374_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
            let v374_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v374_2));
            let v374_4: Space = if map_kernels::has_head(&(v374_3)) { singleton(&[]) } else { Space::new() };
            drop(v374_3);
            let v374_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v374_4));
            drop(v374_4);
            let v374_8: Space = if (&(v374_5)).is_empty() { Space::new() } else {
              let v375_6: Path = concat_path(&(v373_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v375_7: Space = routine_32(c, &(v375_6), &(*p1), &v359_21_cursor);
              map_map_kernels::compose(&(v374_5),&(v375_7))
            };
            drop(v374_5);
            let v374_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v374_2));
            drop(v374_2);
            let v374_10: Space = if map_kernels::has_head(&(v374_9)) { singleton(&[]) } else { Space::new() };
            drop(v374_9);
            let v374_12: Space = if (&(v374_10)).is_empty() { Space::new() } else {
              let v376_6: Path = concat_path(&(v373_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v376_11: Space = routine_33(c, &(v376_6), &(*p1), &v359_21_cursor);
              drop(v376_6);
              map_map_kernels::compose(&(v374_10),&(v376_11))
            };
            drop(v374_10);
            let v374_13: Space = map_map_kernels::unite(&(v374_8),&(v374_12));
            join_wrapped_into(&mut v373_7_write,&((v374_13).read_zipper()),&[]);
            }
            v359_21_cursor.ascend(1);
          }
          drop(v373_7_write);
          map_map_kernels::compose(&(v372_5),&(v373_7))
        };
        drop(v372_5);
        let v372_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v372_2));
        drop(v372_2);
        let v372_10: Space = if map_kernels::has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
        drop(v372_9);
        let v372_11: Space = map_view_kernels::compose(&(v372_10),&v359_21_cursor);
        drop(v372_10);
        let v377_6: Path = concat_path(&(v371_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
        let v372_12: Space = map_kernels::wrap(&(v372_11),&(v377_6));
        drop(v372_11);
        let v372_13: Space = map_kernels::wrap(&(v372_12),&(*p1));
        drop(v372_12);
        let v372_14: Space = map_map_kernels::unite(&(v372_8),&(v372_13));
        drop(v372_13);
        join_wrapped_into(&mut v371_11_write,&((v372_14).read_zipper()),&[]);
        }
        v359_21_cursor.ascend(1);
      }
      drop(v371_11_write);
      drop(v371_6);
      map_map_kernels::compose(&(v360_10),&(v371_11))
    };
    drop(v360_10);
    let v360_13: Space = map_map_kernels::unite(&(v360_8),&(v360_12));
    join_wrapped_into(&mut v359_21_write,&((v360_13).read_zipper()),&[]);
    }
    v359_21_cursor.ascend(1);
  }
  drop(v359_21_cursor);
  drop(v359_21_write);
  (v359_21).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v378_15 = Space::new();
  let mut v378_15_write = v378_15.write_zipper();
  let mut v378_15_cursor = (*s0).read_zipper();
  let v378_15_origin = v378_15_cursor.path().len();
  for v378_15_byte in v378_15_cursor.child_mask().iter() {
    v378_15_cursor.descend_to_existing_byte(v378_15_byte);
    {
    let v379_2: Space = singleton(&v378_15_cursor.path()[v378_15_origin..(v378_15_origin + 1)]);
    let v379_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v379_2));
    let v379_4: Space = if map_kernels::has_head(&(v379_3)) { singleton(&[]) } else { Space::new() };
    drop(v379_3);
    let v379_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v379_4));
    drop(v379_4);
    let v379_8: Space = if (&(v379_5)).is_empty() { Space::new() } else {
      let v380_6: Path = concat_path(&(*p0),&v378_15_cursor.path()[v378_15_origin..(v378_15_origin + 1)]);
      let mut v380_7 = Space::new();
      let mut v380_7_write = v380_7.write_zipper();
      for v380_7_byte in v378_15_cursor.child_mask().iter() {
        v378_15_cursor.descend_to_existing_byte(v380_7_byte);
        {
        let v381_2: Space = singleton(&v378_15_cursor.path()[(v378_15_origin + 1)..(v378_15_origin + 2)]);
        let v381_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v381_2));
        let v381_4: Space = if map_kernels::has_head(&(v381_3)) { singleton(&[]) } else { Space::new() };
        drop(v381_3);
        let v381_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v381_4));
        drop(v381_4);
        let v381_8: Space = if (&(v381_5)).is_empty() { Space::new() } else {
          let v382_6: Path = concat_path(&(v380_6),&v378_15_cursor.path()[(v378_15_origin + 1)..(v378_15_origin + 2)]);
          let mut v382_7 = Space::new();
          let mut v382_7_write = v382_7.write_zipper();
          for v382_7_byte in v378_15_cursor.child_mask().iter() {
            v378_15_cursor.descend_to_existing_byte(v382_7_byte);
            {
            let v383_2: Space = singleton(&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
            let v383_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v383_2));
            let v383_4: Space = if map_kernels::has_head(&(v383_3)) { singleton(&[]) } else { Space::new() };
            drop(v383_3);
            let v383_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v383_4));
            drop(v383_4);
            let v383_8: Space = if (&(v383_5)).is_empty() { Space::new() } else {
              let v384_6: Path = concat_path(&(v382_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v384_7: Space = routine_32(c, &(v384_6), &(*p1), &v378_15_cursor);
              map_map_kernels::compose(&(v383_5),&(v384_7))
            };
            drop(v383_5);
            let v383_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v383_2));
            drop(v383_2);
            let v383_10: Space = if map_kernels::has_head(&(v383_9)) { singleton(&[]) } else { Space::new() };
            drop(v383_9);
            let v383_12: Space = if (&(v383_10)).is_empty() { Space::new() } else {
              let v385_6: Path = concat_path(&(v382_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v385_11: Space = routine_33(c, &(v385_6), &(*p1), &v378_15_cursor);
              drop(v385_6);
              map_map_kernels::compose(&(v383_10),&(v385_11))
            };
            drop(v383_10);
            let v383_13: Space = map_map_kernels::unite(&(v383_8),&(v383_12));
            join_wrapped_into(&mut v382_7_write,&((v383_13).read_zipper()),&[]);
            }
            v378_15_cursor.ascend(1);
          }
          drop(v382_7_write);
          map_map_kernels::compose(&(v381_5),&(v382_7))
        };
        drop(v381_5);
        let v381_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v381_2));
        drop(v381_2);
        let v381_10: Space = if map_kernels::has_head(&(v381_9)) { singleton(&[]) } else { Space::new() };
        drop(v381_9);
        let v381_12: Space = if (&(v381_10)).is_empty() { Space::new() } else {
          let v386_6: Path = concat_path(&(v380_6),&v378_15_cursor.path()[(v378_15_origin + 1)..(v378_15_origin + 2)]);
          let mut v386_11 = Space::new();
          let mut v386_11_write = v386_11.write_zipper();
          for v386_11_byte in v378_15_cursor.child_mask().iter() {
            v378_15_cursor.descend_to_existing_byte(v386_11_byte);
            {
            let v387_2: Space = singleton(&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
            let v387_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v387_2));
            let v387_4: Space = if map_kernels::has_head(&(v387_3)) { singleton(&[]) } else { Space::new() };
            drop(v387_3);
            let v387_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v387_4));
            drop(v387_4);
            let v387_8: Space = if (&(v387_5)).is_empty() { Space::new() } else {
              let v388_6: Path = concat_path(&(v386_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v388_7: Space = routine_32(c, &(v388_6), &(*p1), &v378_15_cursor);
              map_map_kernels::compose(&(v387_5),&(v388_7))
            };
            drop(v387_5);
            let v387_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v387_2));
            drop(v387_2);
            let v387_10: Space = if map_kernels::has_head(&(v387_9)) { singleton(&[]) } else { Space::new() };
            drop(v387_9);
            let v387_12: Space = if (&(v387_10)).is_empty() { Space::new() } else {
              let v389_6: Path = concat_path(&(v386_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v389_11: Space = routine_19(c, &(v389_6), &(*p1), &v378_15_cursor);
              drop(v389_6);
              map_map_kernels::compose(&(v387_10),&(v389_11))
            };
            drop(v387_10);
            let v387_13: Space = map_map_kernels::unite(&(v387_8),&(v387_12));
            join_wrapped_into(&mut v386_11_write,&((v387_13).read_zipper()),&[]);
            }
            v378_15_cursor.ascend(1);
          }
          drop(v386_11_write);
          drop(v386_6);
          map_map_kernels::compose(&(v381_10),&(v386_11))
        };
        drop(v381_10);
        let v381_13: Space = map_map_kernels::unite(&(v381_8),&(v381_12));
        join_wrapped_into(&mut v380_7_write,&((v381_13).read_zipper()),&[]);
        }
        v378_15_cursor.ascend(1);
      }
      drop(v380_7_write);
      map_map_kernels::compose(&(v379_5),&(v380_7))
    };
    drop(v379_5);
    let v379_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v379_2));
    drop(v379_2);
    let v379_10: Space = if map_kernels::has_head(&(v379_9)) { singleton(&[]) } else { Space::new() };
    drop(v379_9);
    let v379_11: Space = map_view_kernels::compose(&(v379_10),&v378_15_cursor);
    drop(v379_10);
    let v390_6: Path = concat_path(&(*p0),&v378_15_cursor.path()[v378_15_origin..(v378_15_origin + 1)]);
    let v379_12: Space = map_kernels::wrap(&(v379_11),&(v390_6));
    drop(v379_11);
    let v379_13: Space = map_kernels::wrap(&(v379_12),&(*p1));
    drop(v379_12);
    let v379_14: Space = map_map_kernels::unite(&(v379_8),&(v379_13));
    drop(v379_13);
    join_wrapped_into(&mut v378_15_write,&((v379_14).read_zipper()),&[]);
    }
    v378_15_cursor.ascend(1);
  }
  drop(v378_15_cursor);
  drop(v378_15_write);
  (v378_15).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v391_3: Space = view_kernels::wrap(&(*s0),&(*p0));
  let v391_4: Space = map_kernels::wrap(&(v391_3),&(*p1));
  drop(v391_3);
  (v391_4).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v392_24 = Space::new();
  let mut v392_24_write = v392_24.write_zipper();
  let mut v392_24_cursor = (*s0).read_zipper();
  let v392_24_origin = v392_24_cursor.path().len();
  for v392_24_byte in v392_24_cursor.child_mask().iter() {
    v392_24_cursor.descend_to_existing_byte(v392_24_byte);
    {
    let v393_2: Space = singleton(&v392_24_cursor.path()[v392_24_origin..(v392_24_origin + 1)]);
    let v393_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v393_2));
    let v393_4: Space = if map_kernels::has_head(&(v393_3)) { singleton(&[]) } else { Space::new() };
    drop(v393_3);
    let v393_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v393_4));
    drop(v393_4);
    let v393_8: Space = if (&(v393_5)).is_empty() { Space::new() } else {
      let v394_6: Path = concat_path(&(*p0),&v392_24_cursor.path()[v392_24_origin..(v392_24_origin + 1)]);
      let mut v394_7 = Space::new();
      let mut v394_7_write = v394_7.write_zipper();
      for v394_7_byte in v392_24_cursor.child_mask().iter() {
        v392_24_cursor.descend_to_existing_byte(v394_7_byte);
        {
        let v395_2: Space = singleton(&v392_24_cursor.path()[(v392_24_origin + 1)..(v392_24_origin + 2)]);
        let v395_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v395_2));
        let v395_4: Space = if map_kernels::has_head(&(v395_3)) { singleton(&[]) } else { Space::new() };
        drop(v395_3);
        let v395_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v395_4));
        drop(v395_4);
        let v395_8: Space = if (&(v395_5)).is_empty() { Space::new() } else {
          let v396_6: Path = concat_path(&(v394_6),&v392_24_cursor.path()[(v392_24_origin + 1)..(v392_24_origin + 2)]);
          let mut v396_7 = Space::new();
          let mut v396_7_write = v396_7.write_zipper();
          for v396_7_byte in v392_24_cursor.child_mask().iter() {
            v392_24_cursor.descend_to_existing_byte(v396_7_byte);
            {
            let v397_2: Space = singleton(&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
            let v397_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v397_2));
            let v397_4: Space = if map_kernels::has_head(&(v397_3)) { singleton(&[]) } else { Space::new() };
            drop(v397_3);
            let v397_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v397_4));
            drop(v397_4);
            let v397_8: Space = if (&(v397_5)).is_empty() { Space::new() } else {
              let v398_6: Path = concat_path(&(v396_6),&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
              let v398_7: Space = routine_34(c, &(v398_6), &v392_24_cursor, &(*s1));
              map_map_kernels::compose(&(v397_5),&(v398_7))
            };
            drop(v397_5);
            let v397_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v397_2));
            drop(v397_2);
            let v397_10: Space = if map_kernels::has_head(&(v397_9)) { singleton(&[]) } else { Space::new() };
            drop(v397_9);
            let v397_12: Space = if (&(v397_10)).is_empty() { Space::new() } else {
              let v399_6: Path = concat_path(&(v396_6),&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
              let v399_11: Space = routine_35(c, &(v399_6), &v392_24_cursor, &(*s1));
              drop(v399_6);
              map_map_kernels::compose(&(v397_10),&(v399_11))
            };
            drop(v397_10);
            let v397_13: Space = map_map_kernels::unite(&(v397_8),&(v397_12));
            join_wrapped_into(&mut v396_7_write,&((v397_13).read_zipper()),&[]);
            }
            v392_24_cursor.ascend(1);
          }
          drop(v396_7_write);
          map_map_kernels::compose(&(v395_5),&(v396_7))
        };
        drop(v395_5);
        let v395_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v395_2));
        drop(v395_2);
        let v395_10: Space = if map_kernels::has_head(&(v395_9)) { singleton(&[]) } else { Space::new() };
        drop(v395_9);
        let v395_12: Space = if (&(v395_10)).is_empty() { Space::new() } else {
          let v400_6: Path = concat_path(&(v394_6),&v392_24_cursor.path()[(v392_24_origin + 1)..(v392_24_origin + 2)]);
          let mut v400_11 = Space::new();
          let mut v400_11_write = v400_11.write_zipper();
          for v400_11_byte in v392_24_cursor.child_mask().iter() {
            v392_24_cursor.descend_to_existing_byte(v400_11_byte);
            {
            let v401_2: Space = singleton(&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
            let v401_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v401_2));
            let v401_4: Space = if map_kernels::has_head(&(v401_3)) { singleton(&[]) } else { Space::new() };
            drop(v401_3);
            let v401_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v401_4));
            drop(v401_4);
            let v401_8: Space = if (&(v401_5)).is_empty() { Space::new() } else {
              let v402_6: Path = concat_path(&(v400_6),&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
              let v402_7: Space = routine_34(c, &(v402_6), &v392_24_cursor, &(*s1));
              map_map_kernels::compose(&(v401_5),&(v402_7))
            };
            drop(v401_5);
            let v401_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v401_2));
            drop(v401_2);
            let v401_10: Space = if map_kernels::has_head(&(v401_9)) { singleton(&[]) } else { Space::new() };
            drop(v401_9);
            let v401_12: Space = if (&(v401_10)).is_empty() { Space::new() } else {
              let v403_6: Path = concat_path(&(v400_6),&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
              let v403_11: Space = routine_3(c, &(v403_6), &v392_24_cursor, &(*s1));
              drop(v403_6);
              map_map_kernels::compose(&(v401_10),&(v403_11))
            };
            drop(v401_10);
            let v401_13: Space = map_map_kernels::unite(&(v401_8),&(v401_12));
            join_wrapped_into(&mut v400_11_write,&((v401_13).read_zipper()),&[]);
            }
            v392_24_cursor.ascend(1);
          }
          drop(v400_11_write);
          drop(v400_6);
          map_map_kernels::compose(&(v395_10),&(v400_11))
        };
        drop(v395_10);
        let v395_13: Space = map_map_kernels::unite(&(v395_8),&(v395_12));
        join_wrapped_into(&mut v394_7_write,&((v395_13).read_zipper()),&[]);
        }
        v392_24_cursor.ascend(1);
      }
      drop(v394_7_write);
      map_map_kernels::compose(&(v393_5),&(v394_7))
    };
    drop(v393_5);
    let v393_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v393_2));
    drop(v393_2);
    let v393_10: Space = if map_kernels::has_head(&(v393_9)) { singleton(&[]) } else { Space::new() };
    drop(v393_9);
    let v393_12: Space = if (&(v393_10)).is_empty() { Space::new() } else {
      let v404_6: Path = concat_path(&(*p0),&v392_24_cursor.path()[v392_24_origin..(v392_24_origin + 1)]);
      let mut v404_11 = Space::new();
      let mut v404_11_write = v404_11.write_zipper();
      for v404_11_byte in v392_24_cursor.child_mask().iter() {
        v392_24_cursor.descend_to_existing_byte(v404_11_byte);
        {
        let v405_2: Space = singleton(&v392_24_cursor.path()[(v392_24_origin + 1)..(v392_24_origin + 2)]);
        let v405_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v405_2));
        let v405_4: Space = if map_kernels::has_head(&(v405_3)) { singleton(&[]) } else { Space::new() };
        drop(v405_3);
        let v405_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v405_4));
        drop(v405_4);
        let v405_8: Space = if (&(v405_5)).is_empty() { Space::new() } else {
          let v406_6: Path = concat_path(&(v404_6),&v392_24_cursor.path()[(v392_24_origin + 1)..(v392_24_origin + 2)]);
          let mut v406_7 = Space::new();
          let mut v406_7_write = v406_7.write_zipper();
          for v406_7_byte in v392_24_cursor.child_mask().iter() {
            v392_24_cursor.descend_to_existing_byte(v406_7_byte);
            {
            let v407_2: Space = singleton(&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
            let v407_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v407_2));
            let v407_4: Space = if map_kernels::has_head(&(v407_3)) { singleton(&[]) } else { Space::new() };
            drop(v407_3);
            let v407_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v407_4));
            drop(v407_4);
            let v407_8: Space = if (&(v407_5)).is_empty() { Space::new() } else {
              let v408_6: Path = concat_path(&(v406_6),&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
              let v408_7: Space = routine_34(c, &(v408_6), &v392_24_cursor, &(*s1));
              map_map_kernels::compose(&(v407_5),&(v408_7))
            };
            drop(v407_5);
            let v407_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v407_2));
            drop(v407_2);
            let v407_10: Space = if map_kernels::has_head(&(v407_9)) { singleton(&[]) } else { Space::new() };
            drop(v407_9);
            let v407_12: Space = if (&(v407_10)).is_empty() { Space::new() } else {
              let v409_6: Path = concat_path(&(v406_6),&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
              let v409_11: Space = routine_35(c, &(v409_6), &v392_24_cursor, &(*s1));
              drop(v409_6);
              map_map_kernels::compose(&(v407_10),&(v409_11))
            };
            drop(v407_10);
            let v407_13: Space = map_map_kernels::unite(&(v407_8),&(v407_12));
            join_wrapped_into(&mut v406_7_write,&((v407_13).read_zipper()),&[]);
            }
            v392_24_cursor.ascend(1);
          }
          drop(v406_7_write);
          map_map_kernels::compose(&(v405_5),&(v406_7))
        };
        drop(v405_5);
        let v405_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v405_2));
        drop(v405_2);
        let v405_10: Space = if map_kernels::has_head(&(v405_9)) { singleton(&[]) } else { Space::new() };
        drop(v405_9);
        let v405_12: Space = if (&(v405_10)).is_empty() { Space::new() } else {
          let v410_6: Path = concat_path(&(v404_6),&v392_24_cursor.path()[(v392_24_origin + 1)..(v392_24_origin + 2)]);
          let mut v410_11 = Space::new();
          let mut v410_11_write = v410_11.write_zipper();
          for v410_11_byte in v392_24_cursor.child_mask().iter() {
            v392_24_cursor.descend_to_existing_byte(v410_11_byte);
            {
            let v411_2: Space = singleton(&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
            let v411_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v411_2));
            let v411_4: Space = if map_kernels::has_head(&(v411_3)) { singleton(&[]) } else { Space::new() };
            drop(v411_3);
            let v411_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v411_4));
            drop(v411_4);
            let v411_7: Space = if (&(v411_5)).is_empty() { Space::new() } else {
              let v412_6: Space = routine_4(c, &v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)], &(v410_6), &v392_24_cursor, &(*s1));
              map_map_kernels::compose(&(v411_5),&(v412_6))
            };
            drop(v411_5);
            let v411_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v411_2));
            drop(v411_2);
            let v411_9: Space = if map_kernels::has_head(&(v411_8)) { singleton(&[]) } else { Space::new() };
            drop(v411_8);
            let v411_11: Space = if (&(v411_9)).is_empty() { Space::new() } else {
              let v413_10: Space = routine_5(c, &v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)], &(v410_6), &v392_24_cursor, &(*s1));
              map_map_kernels::compose(&(v411_9),&(v413_10))
            };
            drop(v411_9);
            let v411_12: Space = map_map_kernels::unite(&(v411_7),&(v411_11));
            join_wrapped_into(&mut v410_11_write,&((v411_12).read_zipper()),&[]);
            }
            v392_24_cursor.ascend(1);
          }
          drop(v410_11_write);
          drop(v410_6);
          map_map_kernels::compose(&(v405_10),&(v410_11))
        };
        drop(v405_10);
        let v405_13: Space = map_map_kernels::unite(&(v405_8),&(v405_12));
        join_wrapped_into(&mut v404_11_write,&((v405_13).read_zipper()),&[]);
        }
        v392_24_cursor.ascend(1);
      }
      drop(v404_11_write);
      drop(v404_6);
      map_map_kernels::compose(&(v393_10),&(v404_11))
    };
    drop(v393_10);
    let v393_13: Space = map_map_kernels::unite(&(v393_8),&(v393_12));
    join_wrapped_into(&mut v392_24_write,&((v393_13).read_zipper()),&[]);
    }
    v392_24_cursor.ascend(1);
  }
  drop(v392_24_cursor);
  drop(v392_24_write);
  (v392_24).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v414_24 = Space::new();
  let mut v414_24_write = v414_24.write_zipper();
  let mut v414_24_cursor = (*s0).read_zipper();
  let v414_24_origin = v414_24_cursor.path().len();
  for v414_24_byte in v414_24_cursor.child_mask().iter() {
    v414_24_cursor.descend_to_existing_byte(v414_24_byte);
    {
    let v415_2: Space = singleton(&v414_24_cursor.path()[v414_24_origin..(v414_24_origin + 1)]);
    let v415_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v415_2));
    let v415_4: Space = if map_kernels::has_head(&(v415_3)) { singleton(&[]) } else { Space::new() };
    drop(v415_3);
    let v415_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v415_4));
    drop(v415_4);
    let v415_8: Space = if (&(v415_5)).is_empty() { Space::new() } else {
      let v416_6: Path = concat_path(&(*p0),&v414_24_cursor.path()[v414_24_origin..(v414_24_origin + 1)]);
      let mut v416_7 = Space::new();
      let mut v416_7_write = v416_7.write_zipper();
      for v416_7_byte in v414_24_cursor.child_mask().iter() {
        v414_24_cursor.descend_to_existing_byte(v416_7_byte);
        {
        let v417_2: Space = singleton(&v414_24_cursor.path()[(v414_24_origin + 1)..(v414_24_origin + 2)]);
        let v417_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v417_2));
        let v417_4: Space = if map_kernels::has_head(&(v417_3)) { singleton(&[]) } else { Space::new() };
        drop(v417_3);
        let v417_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v417_4));
        drop(v417_4);
        let v417_8: Space = if (&(v417_5)).is_empty() { Space::new() } else {
          let v418_6: Path = concat_path(&(v416_6),&v414_24_cursor.path()[(v414_24_origin + 1)..(v414_24_origin + 2)]);
          let mut v418_7 = Space::new();
          let mut v418_7_write = v418_7.write_zipper();
          for v418_7_byte in v414_24_cursor.child_mask().iter() {
            v414_24_cursor.descend_to_existing_byte(v418_7_byte);
            {
            let v419_2: Space = singleton(&v414_24_cursor.path()[(v414_24_origin + 2)..(v414_24_origin + 3)]);
            let v419_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v419_2));
            let v419_4: Space = if map_kernels::has_head(&(v419_3)) { singleton(&[]) } else { Space::new() };
            drop(v419_3);
            let v419_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v419_4));
            drop(v419_4);
            let v419_8: Space = if (&(v419_5)).is_empty() { Space::new() } else {
              let v420_6: Path = concat_path(&(v418_6),&v414_24_cursor.path()[(v414_24_origin + 2)..(v414_24_origin + 3)]);
              let v420_7: Space = routine_34(c, &(v420_6), &v414_24_cursor, &(*s1));
              map_map_kernels::compose(&(v419_5),&(v420_7))
            };
            drop(v419_5);
            let v419_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v419_2));
            drop(v419_2);
            let v419_10: Space = if map_kernels::has_head(&(v419_9)) { singleton(&[]) } else { Space::new() };
            drop(v419_9);
            let v419_12: Space = if (&(v419_10)).is_empty() { Space::new() } else {
              let v421_6: Path = concat_path(&(v418_6),&v414_24_cursor.path()[(v414_24_origin + 2)..(v414_24_origin + 3)]);
              let v421_11: Space = routine_35(c, &(v421_6), &v414_24_cursor, &(*s1));
              drop(v421_6);
              map_map_kernels::compose(&(v419_10),&(v421_11))
            };
            drop(v419_10);
            let v419_13: Space = map_map_kernels::unite(&(v419_8),&(v419_12));
            join_wrapped_into(&mut v418_7_write,&((v419_13).read_zipper()),&[]);
            }
            v414_24_cursor.ascend(1);
          }
          drop(v418_7_write);
          map_map_kernels::compose(&(v417_5),&(v418_7))
        };
        drop(v417_5);
        let v417_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v417_2));
        drop(v417_2);
        let v417_10: Space = if map_kernels::has_head(&(v417_9)) { singleton(&[]) } else { Space::new() };
        drop(v417_9);
        let v417_12: Space = if (&(v417_10)).is_empty() { Space::new() } else {
          let v422_6: Path = concat_path(&(v416_6),&v414_24_cursor.path()[(v414_24_origin + 1)..(v414_24_origin + 2)]);
          let mut v422_11 = Space::new();
          let mut v422_11_write = v422_11.write_zipper();
          for v422_11_byte in v414_24_cursor.child_mask().iter() {
            v414_24_cursor.descend_to_existing_byte(v422_11_byte);
            {
            let v423_2: Space = singleton(&v414_24_cursor.path()[(v414_24_origin + 2)..(v414_24_origin + 3)]);
            let v423_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v423_2));
            let v423_4: Space = if map_kernels::has_head(&(v423_3)) { singleton(&[]) } else { Space::new() };
            drop(v423_3);
            let v423_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v423_4));
            drop(v423_4);
            let v423_8: Space = if (&(v423_5)).is_empty() { Space::new() } else {
              let v424_6: Path = concat_path(&(v422_6),&v414_24_cursor.path()[(v414_24_origin + 2)..(v414_24_origin + 3)]);
              let v424_7: Space = routine_34(c, &(v424_6), &v414_24_cursor, &(*s1));
              map_map_kernels::compose(&(v423_5),&(v424_7))
            };
            drop(v423_5);
            let v423_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v423_2));
            drop(v423_2);
            let v423_10: Space = if map_kernels::has_head(&(v423_9)) { singleton(&[]) } else { Space::new() };
            drop(v423_9);
            let v423_12: Space = if (&(v423_10)).is_empty() { Space::new() } else {
              let v425_6: Path = concat_path(&(v422_6),&v414_24_cursor.path()[(v414_24_origin + 2)..(v414_24_origin + 3)]);
              let v425_11: Space = routine_3(c, &(v425_6), &v414_24_cursor, &(*s1));
              drop(v425_6);
              map_map_kernels::compose(&(v423_10),&(v425_11))
            };
            drop(v423_10);
            let v423_13: Space = map_map_kernels::unite(&(v423_8),&(v423_12));
            join_wrapped_into(&mut v422_11_write,&((v423_13).read_zipper()),&[]);
            }
            v414_24_cursor.ascend(1);
          }
          drop(v422_11_write);
          drop(v422_6);
          map_map_kernels::compose(&(v417_10),&(v422_11))
        };
        drop(v417_10);
        let v417_13: Space = map_map_kernels::unite(&(v417_8),&(v417_12));
        join_wrapped_into(&mut v416_7_write,&((v417_13).read_zipper()),&[]);
        }
        v414_24_cursor.ascend(1);
      }
      drop(v416_7_write);
      map_map_kernels::compose(&(v415_5),&(v416_7))
    };
    drop(v415_5);
    let v415_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v415_2));
    drop(v415_2);
    let v415_10: Space = if map_kernels::has_head(&(v415_9)) { singleton(&[]) } else { Space::new() };
    drop(v415_9);
    let v415_12: Space = if (&(v415_10)).is_empty() { Space::new() } else {
      let v426_6: Path = concat_path(&(*p0),&v414_24_cursor.path()[v414_24_origin..(v414_24_origin + 1)]);
      let mut v426_11 = Space::new();
      let mut v426_11_write = v426_11.write_zipper();
      for v426_11_byte in v414_24_cursor.child_mask().iter() {
        v414_24_cursor.descend_to_existing_byte(v426_11_byte);
        {
        let v427_2: Space = singleton(&v414_24_cursor.path()[(v414_24_origin + 1)..(v414_24_origin + 2)]);
        let v427_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v427_2));
        let v427_4: Space = if map_kernels::has_head(&(v427_3)) { singleton(&[]) } else { Space::new() };
        drop(v427_3);
        let v427_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v427_4));
        drop(v427_4);
        let v427_7: Space = if (&(v427_5)).is_empty() { Space::new() } else {
          let mut v428_6 = Space::new();
          let mut v428_6_write = v428_6.write_zipper();
          for v428_6_byte in v414_24_cursor.child_mask().iter() {
            v414_24_cursor.descend_to_existing_byte(v428_6_byte);
            {
            let v429_2: Space = singleton(&v414_24_cursor.path()[(v414_24_origin + 2)..(v414_24_origin + 3)]);
            let v429_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v429_2));
            let v429_4: Space = if map_kernels::has_head(&(v429_3)) { singleton(&[]) } else { Space::new() };
            drop(v429_3);
            let v429_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v429_4));
            drop(v429_4);
            let v429_8: Space = if (&(v429_5)).is_empty() { Space::new() } else {
              let v430_7: Space = routine_8(c, &v414_24_cursor.path()[(v414_24_origin + 1)..(v414_24_origin + 3)], &(v426_6), &v414_24_cursor, &(*s1));
              map_map_kernels::compose(&(v429_5),&(v430_7))
            };
            drop(v429_5);
            let v429_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v429_2));
            drop(v429_2);
            let v429_10: Space = if map_kernels::has_head(&(v429_9)) { singleton(&[]) } else { Space::new() };
            drop(v429_9);
            let v429_12: Space = if (&(v429_10)).is_empty() { Space::new() } else {
              let v431_11: Space = routine_9(c, &v414_24_cursor.path()[(v414_24_origin + 1)..(v414_24_origin + 3)], &(v426_6), &v414_24_cursor, &(*s1));
              map_map_kernels::compose(&(v429_10),&(v431_11))
            };
            drop(v429_10);
            let v429_13: Space = map_map_kernels::unite(&(v429_8),&(v429_12));
            join_wrapped_into(&mut v428_6_write,&((v429_13).read_zipper()),&[]);
            }
            v414_24_cursor.ascend(1);
          }
          drop(v428_6_write);
          map_map_kernels::compose(&(v427_5),&(v428_6))
        };
        drop(v427_5);
        let v427_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v427_2));
        drop(v427_2);
        let v427_9: Space = if map_kernels::has_head(&(v427_8)) { singleton(&[]) } else { Space::new() };
        drop(v427_8);
        let v427_11: Space = if (&(v427_9)).is_empty() { Space::new() } else {
          let mut v432_10 = Space::new();
          let mut v432_10_write = v432_10.write_zipper();
          for v432_10_byte in v414_24_cursor.child_mask().iter() {
            v414_24_cursor.descend_to_existing_byte(v432_10_byte);
            {
            let v433_2: Space = singleton(&v414_24_cursor.path()[(v414_24_origin + 2)..(v414_24_origin + 3)]);
            let v433_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v433_2));
            let v433_4: Space = if map_kernels::has_head(&(v433_3)) { singleton(&[]) } else { Space::new() };
            drop(v433_3);
            let v433_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v433_4));
            drop(v433_4);
            let v433_8: Space = if (&(v433_5)).is_empty() { Space::new() } else {
              let v434_7: Space = routine_8(c, &v414_24_cursor.path()[(v414_24_origin + 1)..(v414_24_origin + 3)], &(v426_6), &v414_24_cursor, &(*s1));
              map_map_kernels::compose(&(v433_5),&(v434_7))
            };
            drop(v433_5);
            let v433_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v433_2));
            drop(v433_2);
            let v433_10: Space = if map_kernels::has_head(&(v433_9)) { singleton(&[]) } else { Space::new() };
            drop(v433_9);
            let v433_12: Space = if (&(v433_10)).is_empty() { Space::new() } else {
              let v435_11: Space = routine_10(c, &v414_24_cursor.path()[(v414_24_origin + 1)..(v414_24_origin + 3)], &(v426_6), &v414_24_cursor, &(*s1));
              map_map_kernels::compose(&(v433_10),&(v435_11))
            };
            drop(v433_10);
            let v433_13: Space = map_map_kernels::unite(&(v433_8),&(v433_12));
            join_wrapped_into(&mut v432_10_write,&((v433_13).read_zipper()),&[]);
            }
            v414_24_cursor.ascend(1);
          }
          drop(v432_10_write);
          map_map_kernels::compose(&(v427_9),&(v432_10))
        };
        drop(v427_9);
        let v427_12: Space = map_map_kernels::unite(&(v427_7),&(v427_11));
        join_wrapped_into(&mut v426_11_write,&((v427_12).read_zipper()),&[]);
        }
        v414_24_cursor.ascend(1);
      }
      drop(v426_11_write);
      drop(v426_6);
      map_map_kernels::compose(&(v415_10),&(v426_11))
    };
    drop(v415_10);
    let v415_13: Space = map_map_kernels::unite(&(v415_8),&(v415_12));
    join_wrapped_into(&mut v414_24_write,&((v415_13).read_zipper()),&[]);
    }
    v414_24_cursor.ascend(1);
  }
  drop(v414_24_cursor);
  drop(v414_24_write);
  (v414_24).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v436_28 = Space::new();
  let mut v436_28_write = v436_28.write_zipper();
  let mut v436_28_cursor = (*s0).read_zipper();
  let v436_28_origin = v436_28_cursor.path().len();
  for v436_28_byte in v436_28_cursor.child_mask().iter() {
    v436_28_cursor.descend_to_existing_byte(v436_28_byte);
    {
    let v437_2: Space = singleton(&v436_28_cursor.path()[v436_28_origin..(v436_28_origin + 1)]);
    let v437_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v437_2));
    let v437_4: Space = if map_kernels::has_head(&(v437_3)) { singleton(&[]) } else { Space::new() };
    drop(v437_3);
    let v437_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v437_4));
    drop(v437_4);
    let v437_8: Space = if (&(v437_5)).is_empty() { Space::new() } else {
      let v438_6: Path = concat_path(&(*p0),&v436_28_cursor.path()[v436_28_origin..(v436_28_origin + 1)]);
      let mut v438_7 = Space::new();
      let mut v438_7_write = v438_7.write_zipper();
      for v438_7_byte in v436_28_cursor.child_mask().iter() {
        v436_28_cursor.descend_to_existing_byte(v438_7_byte);
        {
        let v439_2: Space = singleton(&v436_28_cursor.path()[(v436_28_origin + 1)..(v436_28_origin + 2)]);
        let v439_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v439_2));
        let v439_4: Space = if map_kernels::has_head(&(v439_3)) { singleton(&[]) } else { Space::new() };
        drop(v439_3);
        let v439_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v439_4));
        drop(v439_4);
        let v439_8: Space = if (&(v439_5)).is_empty() { Space::new() } else {
          let v440_6: Path = concat_path(&(v438_6),&v436_28_cursor.path()[(v436_28_origin + 1)..(v436_28_origin + 2)]);
          let mut v440_7 = Space::new();
          let mut v440_7_write = v440_7.write_zipper();
          for v440_7_byte in v436_28_cursor.child_mask().iter() {
            v436_28_cursor.descend_to_existing_byte(v440_7_byte);
            {
            let v441_2: Space = singleton(&v436_28_cursor.path()[(v436_28_origin + 2)..(v436_28_origin + 3)]);
            let v441_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v441_2));
            let v441_4: Space = if map_kernels::has_head(&(v441_3)) { singleton(&[]) } else { Space::new() };
            drop(v441_3);
            let v441_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v441_4));
            drop(v441_4);
            let v441_8: Space = if (&(v441_5)).is_empty() { Space::new() } else {
              let v442_6: Path = concat_path(&(v440_6),&v436_28_cursor.path()[(v436_28_origin + 2)..(v436_28_origin + 3)]);
              let v442_7: Space = routine_36(c, &(v442_6), &(*p1), &v436_28_cursor, &(*s1));
              map_map_kernels::compose(&(v441_5),&(v442_7))
            };
            drop(v441_5);
            let v441_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v441_2));
            drop(v441_2);
            let v441_10: Space = if map_kernels::has_head(&(v441_9)) { singleton(&[]) } else { Space::new() };
            drop(v441_9);
            let v441_12: Space = if (&(v441_10)).is_empty() { Space::new() } else {
              let v443_6: Path = concat_path(&(v440_6),&v436_28_cursor.path()[(v436_28_origin + 2)..(v436_28_origin + 3)]);
              let v443_11: Space = routine_37(c, &(v443_6), &(*p1), &v436_28_cursor, &(*s1));
              drop(v443_6);
              map_map_kernels::compose(&(v441_10),&(v443_11))
            };
            drop(v441_10);
            let v441_13: Space = map_map_kernels::unite(&(v441_8),&(v441_12));
            join_wrapped_into(&mut v440_7_write,&((v441_13).read_zipper()),&[]);
            }
            v436_28_cursor.ascend(1);
          }
          drop(v440_7_write);
          map_map_kernels::compose(&(v439_5),&(v440_7))
        };
        drop(v439_5);
        let v439_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v439_2));
        drop(v439_2);
        let v439_10: Space = if map_kernels::has_head(&(v439_9)) { singleton(&[]) } else { Space::new() };
        drop(v439_9);
        let v439_12: Space = if (&(v439_10)).is_empty() { Space::new() } else {
          let v444_6: Path = concat_path(&(v438_6),&v436_28_cursor.path()[(v436_28_origin + 1)..(v436_28_origin + 2)]);
          let mut v444_11 = Space::new();
          let mut v444_11_write = v444_11.write_zipper();
          for v444_11_byte in v436_28_cursor.child_mask().iter() {
            v436_28_cursor.descend_to_existing_byte(v444_11_byte);
            {
            let v445_2: Space = singleton(&v436_28_cursor.path()[(v436_28_origin + 2)..(v436_28_origin + 3)]);
            let v445_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v445_2));
            let v445_4: Space = if map_kernels::has_head(&(v445_3)) { singleton(&[]) } else { Space::new() };
            drop(v445_3);
            let v445_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v445_4));
            drop(v445_4);
            let v445_8: Space = if (&(v445_5)).is_empty() { Space::new() } else {
              let v446_6: Path = concat_path(&(v444_6),&v436_28_cursor.path()[(v436_28_origin + 2)..(v436_28_origin + 3)]);
              let v446_7: Space = routine_36(c, &(v446_6), &(*p1), &v436_28_cursor, &(*s1));
              map_map_kernels::compose(&(v445_5),&(v446_7))
            };
            drop(v445_5);
            let v445_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v445_2));
            drop(v445_2);
            let v445_10: Space = if map_kernels::has_head(&(v445_9)) { singleton(&[]) } else { Space::new() };
            drop(v445_9);
            let v445_12: Space = if (&(v445_10)).is_empty() { Space::new() } else {
              let v447_6: Path = concat_path(&(v444_6),&v436_28_cursor.path()[(v436_28_origin + 2)..(v436_28_origin + 3)]);
              let v447_11: Space = routine_10(c, &(v447_6), &(*p1), &v436_28_cursor, &(*s1));
              drop(v447_6);
              map_map_kernels::compose(&(v445_10),&(v447_11))
            };
            drop(v445_10);
            let v445_13: Space = map_map_kernels::unite(&(v445_8),&(v445_12));
            join_wrapped_into(&mut v444_11_write,&((v445_13).read_zipper()),&[]);
            }
            v436_28_cursor.ascend(1);
          }
          drop(v444_11_write);
          drop(v444_6);
          map_map_kernels::compose(&(v439_10),&(v444_11))
        };
        drop(v439_10);
        let v439_13: Space = map_map_kernels::unite(&(v439_8),&(v439_12));
        join_wrapped_into(&mut v438_7_write,&((v439_13).read_zipper()),&[]);
        }
        v436_28_cursor.ascend(1);
      }
      drop(v438_7_write);
      map_map_kernels::compose(&(v437_5),&(v438_7))
    };
    drop(v437_5);
    let v437_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v437_2));
    drop(v437_2);
    let v437_10: Space = if map_kernels::has_head(&(v437_9)) { singleton(&[]) } else { Space::new() };
    drop(v437_9);
    let v437_13: Space = if (&(v437_10)).is_empty() { Space::new() } else {
      let v448_6: Path = concat_path(&(*p0),&v436_28_cursor.path()[v436_28_origin..(v436_28_origin + 1)]);
      let mut v448_12 = Space::new();
      let mut v448_12_write = v448_12.write_zipper();
      for v448_12_byte in v436_28_cursor.child_mask().iter() {
        v436_28_cursor.descend_to_existing_byte(v448_12_byte);
        {
        let v449_2: Space = singleton(&v436_28_cursor.path()[(v436_28_origin + 1)..(v436_28_origin + 2)]);
        let v449_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v449_2));
        let v449_4: Space = if map_kernels::has_head(&(v449_3)) { singleton(&[]) } else { Space::new() };
        drop(v449_3);
        let v449_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v449_4));
        drop(v449_4);
        let v449_8: Space = if (&(v449_5)).is_empty() { Space::new() } else {
          let v450_6: Path = concat_path(&(v448_6),&v436_28_cursor.path()[(v436_28_origin + 1)..(v436_28_origin + 2)]);
          let mut v450_7 = Space::new();
          let mut v450_7_write = v450_7.write_zipper();
          for v450_7_byte in v436_28_cursor.child_mask().iter() {
            v436_28_cursor.descend_to_existing_byte(v450_7_byte);
            {
            let v451_2: Space = singleton(&v436_28_cursor.path()[(v436_28_origin + 2)..(v436_28_origin + 3)]);
            let v451_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v451_2));
            let v451_4: Space = if map_kernels::has_head(&(v451_3)) { singleton(&[]) } else { Space::new() };
            drop(v451_3);
            let v451_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v451_4));
            drop(v451_4);
            let v451_8: Space = if (&(v451_5)).is_empty() { Space::new() } else {
              let v452_6: Path = concat_path(&(v450_6),&v436_28_cursor.path()[(v436_28_origin + 2)..(v436_28_origin + 3)]);
              let v452_7: Space = routine_36(c, &(v452_6), &(*p1), &v436_28_cursor, &(*s1));
              map_map_kernels::compose(&(v451_5),&(v452_7))
            };
            drop(v451_5);
            let v451_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v451_2));
            drop(v451_2);
            let v451_10: Space = if map_kernels::has_head(&(v451_9)) { singleton(&[]) } else { Space::new() };
            drop(v451_9);
            let v451_12: Space = if (&(v451_10)).is_empty() { Space::new() } else {
              let v453_6: Path = concat_path(&(v450_6),&v436_28_cursor.path()[(v436_28_origin + 2)..(v436_28_origin + 3)]);
              let v453_11: Space = routine_37(c, &(v453_6), &(*p1), &v436_28_cursor, &(*s1));
              drop(v453_6);
              map_map_kernels::compose(&(v451_10),&(v453_11))
            };
            drop(v451_10);
            let v451_13: Space = map_map_kernels::unite(&(v451_8),&(v451_12));
            join_wrapped_into(&mut v450_7_write,&((v451_13).read_zipper()),&[]);
            }
            v436_28_cursor.ascend(1);
          }
          drop(v450_7_write);
          drop(v450_6);
          map_map_kernels::compose(&(v449_5),&(v450_7))
        };
        drop(v449_5);
        let v449_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v449_2));
        drop(v449_2);
        let v449_10: Space = if map_kernels::has_head(&(v449_9)) { singleton(&[]) } else { Space::new() };
        drop(v449_9);
        let v449_13: Space = if (&(v449_10)).is_empty() { Space::new() } else {
          let mut v454_12 = Space::new();
          let mut v454_12_write = v454_12.write_zipper();
          let mut v454_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v436_28_cursor.path()[v436_28_origin..(v436_28_origin + 1)]),&v436_28_cursor.path()[(v436_28_origin + 1)..(v436_28_origin + 2)]);
          let v454_12_origin = v454_12_cursor.path().len();
          for v454_12_byte in v454_12_cursor.child_mask().iter() {
            v454_12_cursor.descend_to_existing_byte(v454_12_byte);
            {
            let v455_2: Space = singleton(&v454_12_cursor.path()[v454_12_origin..(v454_12_origin + 1)]);
            let v455_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v455_2));
            let v455_4: Space = if map_kernels::has_head(&(v455_3)) { singleton(&[]) } else { Space::new() };
            drop(v455_3);
            let v455_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v455_4));
            drop(v455_4);
            let v455_7: Space = if (&(v455_5)).is_empty() { Space::new() } else {
              let v456_6: Space = routine_13(c, &v454_12_cursor.path()[v454_12_origin..(v454_12_origin + 1)], &(*p1), &v454_12_cursor);
              map_map_kernels::compose(&(v455_5),&(v456_6))
            };
            drop(v455_5);
            let v455_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v455_2));
            drop(v455_2);
            let v455_9: Space = if map_kernels::has_head(&(v455_8)) { singleton(&[]) } else { Space::new() };
            drop(v455_8);
            let v455_11: Space = if (&(v455_9)).is_empty() { Space::new() } else {
              let v457_10: Space = routine_14(c, &v454_12_cursor.path()[v454_12_origin..(v454_12_origin + 1)], &(*p1), &v454_12_cursor);
              map_map_kernels::compose(&(v455_9),&(v457_10))
            };
            drop(v455_9);
            let v455_12: Space = map_map_kernels::unite(&(v455_7),&(v455_11));
            join_wrapped_into(&mut v454_12_write,&((v455_12).read_zipper()),&[]);
            }
            v454_12_cursor.ascend(1);
          }
          drop(v454_12_cursor);
          drop(v454_12_write);
          map_map_kernels::compose(&(v449_10),&(v454_12))
        };
        drop(v449_10);
        let v449_14: Space = map_map_kernels::unite(&(v449_8),&(v449_13));
        join_wrapped_into(&mut v448_12_write,&((v449_14).read_zipper()),&[]);
        }
        v436_28_cursor.ascend(1);
      }
      drop(v448_12_write);
      drop(v448_6);
      map_map_kernels::compose(&(v437_10),&(v448_12))
    };
    drop(v437_10);
    let v437_14: Space = map_map_kernels::unite(&(v437_8),&(v437_13));
    join_wrapped_into(&mut v436_28_write,&((v437_14).read_zipper()),&[]);
    }
    v436_28_cursor.ascend(1);
  }
  drop(v436_28_cursor);
  drop(v436_28_write);
  (v436_28).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v458_28 = Space::new();
  let mut v458_28_write = v458_28.write_zipper();
  let mut v458_28_cursor = (*s0).read_zipper();
  let v458_28_origin = v458_28_cursor.path().len();
  for v458_28_byte in v458_28_cursor.child_mask().iter() {
    v458_28_cursor.descend_to_existing_byte(v458_28_byte);
    {
    let v459_2: Space = singleton(&v458_28_cursor.path()[v458_28_origin..(v458_28_origin + 1)]);
    let v459_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v459_2));
    let v459_4: Space = if map_kernels::has_head(&(v459_3)) { singleton(&[]) } else { Space::new() };
    drop(v459_3);
    let v459_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v459_4));
    drop(v459_4);
    let v459_8: Space = if (&(v459_5)).is_empty() { Space::new() } else {
      let v460_6: Path = concat_path(&(*p0),&v458_28_cursor.path()[v458_28_origin..(v458_28_origin + 1)]);
      let mut v460_7 = Space::new();
      let mut v460_7_write = v460_7.write_zipper();
      for v460_7_byte in v458_28_cursor.child_mask().iter() {
        v458_28_cursor.descend_to_existing_byte(v460_7_byte);
        {
        let v461_2: Space = singleton(&v458_28_cursor.path()[(v458_28_origin + 1)..(v458_28_origin + 2)]);
        let v461_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v461_2));
        let v461_4: Space = if map_kernels::has_head(&(v461_3)) { singleton(&[]) } else { Space::new() };
        drop(v461_3);
        let v461_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v461_4));
        drop(v461_4);
        let v461_8: Space = if (&(v461_5)).is_empty() { Space::new() } else {
          let v462_6: Path = concat_path(&(v460_6),&v458_28_cursor.path()[(v458_28_origin + 1)..(v458_28_origin + 2)]);
          let mut v462_7 = Space::new();
          let mut v462_7_write = v462_7.write_zipper();
          for v462_7_byte in v458_28_cursor.child_mask().iter() {
            v458_28_cursor.descend_to_existing_byte(v462_7_byte);
            {
            let v463_2: Space = singleton(&v458_28_cursor.path()[(v458_28_origin + 2)..(v458_28_origin + 3)]);
            let v463_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v463_2));
            let v463_4: Space = if map_kernels::has_head(&(v463_3)) { singleton(&[]) } else { Space::new() };
            drop(v463_3);
            let v463_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v463_4));
            drop(v463_4);
            let v463_8: Space = if (&(v463_5)).is_empty() { Space::new() } else {
              let v464_6: Path = concat_path(&(v462_6),&v458_28_cursor.path()[(v458_28_origin + 2)..(v458_28_origin + 3)]);
              let v464_7: Space = routine_36(c, &(v464_6), &(*p1), &v458_28_cursor, &(*s1));
              map_map_kernels::compose(&(v463_5),&(v464_7))
            };
            drop(v463_5);
            let v463_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v463_2));
            drop(v463_2);
            let v463_10: Space = if map_kernels::has_head(&(v463_9)) { singleton(&[]) } else { Space::new() };
            drop(v463_9);
            let v463_12: Space = if (&(v463_10)).is_empty() { Space::new() } else {
              let v465_6: Path = concat_path(&(v462_6),&v458_28_cursor.path()[(v458_28_origin + 2)..(v458_28_origin + 3)]);
              let v465_11: Space = routine_37(c, &(v465_6), &(*p1), &v458_28_cursor, &(*s1));
              drop(v465_6);
              map_map_kernels::compose(&(v463_10),&(v465_11))
            };
            drop(v463_10);
            let v463_13: Space = map_map_kernels::unite(&(v463_8),&(v463_12));
            join_wrapped_into(&mut v462_7_write,&((v463_13).read_zipper()),&[]);
            }
            v458_28_cursor.ascend(1);
          }
          drop(v462_7_write);
          map_map_kernels::compose(&(v461_5),&(v462_7))
        };
        drop(v461_5);
        let v461_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v461_2));
        drop(v461_2);
        let v461_10: Space = if map_kernels::has_head(&(v461_9)) { singleton(&[]) } else { Space::new() };
        drop(v461_9);
        let v461_12: Space = if (&(v461_10)).is_empty() { Space::new() } else {
          let v466_6: Path = concat_path(&(v460_6),&v458_28_cursor.path()[(v458_28_origin + 1)..(v458_28_origin + 2)]);
          let mut v466_11 = Space::new();
          let mut v466_11_write = v466_11.write_zipper();
          for v466_11_byte in v458_28_cursor.child_mask().iter() {
            v458_28_cursor.descend_to_existing_byte(v466_11_byte);
            {
            let v467_2: Space = singleton(&v458_28_cursor.path()[(v458_28_origin + 2)..(v458_28_origin + 3)]);
            let v467_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v467_2));
            let v467_4: Space = if map_kernels::has_head(&(v467_3)) { singleton(&[]) } else { Space::new() };
            drop(v467_3);
            let v467_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v467_4));
            drop(v467_4);
            let v467_8: Space = if (&(v467_5)).is_empty() { Space::new() } else {
              let v468_6: Path = concat_path(&(v466_6),&v458_28_cursor.path()[(v458_28_origin + 2)..(v458_28_origin + 3)]);
              let v468_7: Space = routine_36(c, &(v468_6), &(*p1), &v458_28_cursor, &(*s1));
              map_map_kernels::compose(&(v467_5),&(v468_7))
            };
            drop(v467_5);
            let v467_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v467_2));
            drop(v467_2);
            let v467_10: Space = if map_kernels::has_head(&(v467_9)) { singleton(&[]) } else { Space::new() };
            drop(v467_9);
            let v467_12: Space = if (&(v467_10)).is_empty() { Space::new() } else {
              let v469_6: Path = concat_path(&(v466_6),&v458_28_cursor.path()[(v458_28_origin + 2)..(v458_28_origin + 3)]);
              let v469_11: Space = routine_10(c, &(v469_6), &(*p1), &v458_28_cursor, &(*s1));
              drop(v469_6);
              map_map_kernels::compose(&(v467_10),&(v469_11))
            };
            drop(v467_10);
            let v467_13: Space = map_map_kernels::unite(&(v467_8),&(v467_12));
            join_wrapped_into(&mut v466_11_write,&((v467_13).read_zipper()),&[]);
            }
            v458_28_cursor.ascend(1);
          }
          drop(v466_11_write);
          drop(v466_6);
          map_map_kernels::compose(&(v461_10),&(v466_11))
        };
        drop(v461_10);
        let v461_13: Space = map_map_kernels::unite(&(v461_8),&(v461_12));
        join_wrapped_into(&mut v460_7_write,&((v461_13).read_zipper()),&[]);
        }
        v458_28_cursor.ascend(1);
      }
      drop(v460_7_write);
      drop(v460_6);
      map_map_kernels::compose(&(v459_5),&(v460_7))
    };
    drop(v459_5);
    let v459_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v459_2));
    drop(v459_2);
    let v459_10: Space = if map_kernels::has_head(&(v459_9)) { singleton(&[]) } else { Space::new() };
    drop(v459_9);
    let v459_13: Space = if (&(v459_10)).is_empty() { Space::new() } else {
      let mut v470_12 = Space::new();
      let mut v470_12_write = v470_12.write_zipper();
      let mut v470_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v458_28_cursor.path()[v458_28_origin..(v458_28_origin + 1)]);
      let v470_12_origin = v470_12_cursor.path().len();
      for v470_12_byte in v470_12_cursor.child_mask().iter() {
        v470_12_cursor.descend_to_existing_byte(v470_12_byte);
        {
        let v471_2: Space = singleton(&v470_12_cursor.path()[v470_12_origin..(v470_12_origin + 1)]);
        let v471_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v471_2));
        let v471_4: Space = if map_kernels::has_head(&(v471_3)) { singleton(&[]) } else { Space::new() };
        drop(v471_3);
        let v471_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v471_4));
        drop(v471_4);
        let v471_7: Space = if (&(v471_5)).is_empty() { Space::new() } else {
          let mut v472_6 = Space::new();
          let mut v472_6_write = v472_6.write_zipper();
          for v472_6_byte in v470_12_cursor.child_mask().iter() {
            v470_12_cursor.descend_to_existing_byte(v472_6_byte);
            {
            let v473_2: Space = singleton(&v470_12_cursor.path()[(v470_12_origin + 1)..(v470_12_origin + 2)]);
            let v473_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v473_2));
            let v473_4: Space = if map_kernels::has_head(&(v473_3)) { singleton(&[]) } else { Space::new() };
            drop(v473_3);
            let v473_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v473_4));
            drop(v473_4);
            let v473_8: Space = if (&(v473_5)).is_empty() { Space::new() } else {
              let v474_7: Space = routine_17(c, &v470_12_cursor.path()[v470_12_origin..(v470_12_origin + 2)], &(*p1), &v470_12_cursor);
              map_map_kernels::compose(&(v473_5),&(v474_7))
            };
            drop(v473_5);
            let v473_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v473_2));
            drop(v473_2);
            let v473_10: Space = if map_kernels::has_head(&(v473_9)) { singleton(&[]) } else { Space::new() };
            drop(v473_9);
            let v473_12: Space = if (&(v473_10)).is_empty() { Space::new() } else {
              let v475_11: Space = routine_18(c, &v470_12_cursor.path()[v470_12_origin..(v470_12_origin + 2)], &(*p1), &v470_12_cursor);
              map_map_kernels::compose(&(v473_10),&(v475_11))
            };
            drop(v473_10);
            let v473_13: Space = map_map_kernels::unite(&(v473_8),&(v473_12));
            join_wrapped_into(&mut v472_6_write,&((v473_13).read_zipper()),&[]);
            }
            v470_12_cursor.ascend(1);
          }
          drop(v472_6_write);
          map_map_kernels::compose(&(v471_5),&(v472_6))
        };
        drop(v471_5);
        let v471_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v471_2));
        drop(v471_2);
        let v471_9: Space = if map_kernels::has_head(&(v471_8)) { singleton(&[]) } else { Space::new() };
        drop(v471_8);
        let v471_11: Space = if (&(v471_9)).is_empty() { Space::new() } else {
          let mut v476_10 = Space::new();
          let mut v476_10_write = v476_10.write_zipper();
          for v476_10_byte in v470_12_cursor.child_mask().iter() {
            v470_12_cursor.descend_to_existing_byte(v476_10_byte);
            {
            let v477_2: Space = singleton(&v470_12_cursor.path()[(v470_12_origin + 1)..(v470_12_origin + 2)]);
            let v477_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v477_2));
            let v477_4: Space = if map_kernels::has_head(&(v477_3)) { singleton(&[]) } else { Space::new() };
            drop(v477_3);
            let v477_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v477_4));
            drop(v477_4);
            let v477_8: Space = if (&(v477_5)).is_empty() { Space::new() } else {
              let v478_7: Space = routine_17(c, &v470_12_cursor.path()[v470_12_origin..(v470_12_origin + 2)], &(*p1), &v470_12_cursor);
              map_map_kernels::compose(&(v477_5),&(v478_7))
            };
            drop(v477_5);
            let v477_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v477_2));
            drop(v477_2);
            let v477_10: Space = if map_kernels::has_head(&(v477_9)) { singleton(&[]) } else { Space::new() };
            drop(v477_9);
            let v477_12: Space = if (&(v477_10)).is_empty() { Space::new() } else {
              let v479_11: Space = routine_19(c, &v470_12_cursor.path()[v470_12_origin..(v470_12_origin + 2)], &(*p1), &v470_12_cursor);
              map_map_kernels::compose(&(v477_10),&(v479_11))
            };
            drop(v477_10);
            let v477_13: Space = map_map_kernels::unite(&(v477_8),&(v477_12));
            join_wrapped_into(&mut v476_10_write,&((v477_13).read_zipper()),&[]);
            }
            v470_12_cursor.ascend(1);
          }
          drop(v476_10_write);
          map_map_kernels::compose(&(v471_9),&(v476_10))
        };
        drop(v471_9);
        let v471_12: Space = map_map_kernels::unite(&(v471_7),&(v471_11));
        join_wrapped_into(&mut v470_12_write,&((v471_12).read_zipper()),&[]);
        }
        v470_12_cursor.ascend(1);
      }
      drop(v470_12_cursor);
      drop(v470_12_write);
      map_map_kernels::compose(&(v459_10),&(v470_12))
    };
    drop(v459_10);
    let v459_14: Space = map_map_kernels::unite(&(v459_8),&(v459_13));
    join_wrapped_into(&mut v458_28_write,&((v459_14).read_zipper()),&[]);
    }
    v458_28_cursor.ascend(1);
  }
  drop(v458_28_cursor);
  drop(v458_28_write);
  (v458_28).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v480_21 = Space::new();
  let mut v480_21_write = v480_21.write_zipper();
  let mut v480_21_cursor = (*s0).read_zipper();
  let v480_21_origin = v480_21_cursor.path().len();
  for v480_21_byte in v480_21_cursor.child_mask().iter() {
    v480_21_cursor.descend_to_existing_byte(v480_21_byte);
    {
    let v481_2: Space = singleton(&v480_21_cursor.path()[v480_21_origin..(v480_21_origin + 1)]);
    let v481_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v481_2));
    let v481_4: Space = if map_kernels::has_head(&(v481_3)) { singleton(&[]) } else { Space::new() };
    drop(v481_3);
    let v481_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v481_4));
    drop(v481_4);
    let v481_8: Space = if (&(v481_5)).is_empty() { Space::new() } else {
      let v482_6: Path = concat_path(&(*p0),&v480_21_cursor.path()[v480_21_origin..(v480_21_origin + 1)]);
      let mut v482_7 = Space::new();
      let mut v482_7_write = v482_7.write_zipper();
      for v482_7_byte in v480_21_cursor.child_mask().iter() {
        v480_21_cursor.descend_to_existing_byte(v482_7_byte);
        {
        let v483_2: Space = singleton(&v480_21_cursor.path()[(v480_21_origin + 1)..(v480_21_origin + 2)]);
        let v483_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v483_2));
        let v483_4: Space = if map_kernels::has_head(&(v483_3)) { singleton(&[]) } else { Space::new() };
        drop(v483_3);
        let v483_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v483_4));
        drop(v483_4);
        let v483_8: Space = if (&(v483_5)).is_empty() { Space::new() } else {
          let v484_6: Path = concat_path(&(v482_6),&v480_21_cursor.path()[(v480_21_origin + 1)..(v480_21_origin + 2)]);
          let mut v484_7 = Space::new();
          let mut v484_7_write = v484_7.write_zipper();
          for v484_7_byte in v480_21_cursor.child_mask().iter() {
            v480_21_cursor.descend_to_existing_byte(v484_7_byte);
            {
            let v485_2: Space = singleton(&v480_21_cursor.path()[(v480_21_origin + 2)..(v480_21_origin + 3)]);
            let v485_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v485_2));
            let v485_4: Space = if map_kernels::has_head(&(v485_3)) { singleton(&[]) } else { Space::new() };
            drop(v485_3);
            let v485_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v485_4));
            drop(v485_4);
            let v485_8: Space = if (&(v485_5)).is_empty() { Space::new() } else {
              let v486_6: Path = concat_path(&(v484_6),&v480_21_cursor.path()[(v480_21_origin + 2)..(v480_21_origin + 3)]);
              let v486_7: Space = routine_38(c, &(v486_6), &(*p1), &v480_21_cursor);
              map_map_kernels::compose(&(v485_5),&(v486_7))
            };
            drop(v485_5);
            let v485_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v485_2));
            drop(v485_2);
            let v485_10: Space = if map_kernels::has_head(&(v485_9)) { singleton(&[]) } else { Space::new() };
            drop(v485_9);
            let v485_12: Space = if (&(v485_10)).is_empty() { Space::new() } else {
              let v487_6: Path = concat_path(&(v484_6),&v480_21_cursor.path()[(v480_21_origin + 2)..(v480_21_origin + 3)]);
              let v487_11: Space = routine_39(c, &(v487_6), &(*p1), &v480_21_cursor);
              drop(v487_6);
              map_map_kernels::compose(&(v485_10),&(v487_11))
            };
            drop(v485_10);
            let v485_13: Space = map_map_kernels::unite(&(v485_8),&(v485_12));
            join_wrapped_into(&mut v484_7_write,&((v485_13).read_zipper()),&[]);
            }
            v480_21_cursor.ascend(1);
          }
          drop(v484_7_write);
          map_map_kernels::compose(&(v483_5),&(v484_7))
        };
        drop(v483_5);
        let v483_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v483_2));
        drop(v483_2);
        let v483_10: Space = if map_kernels::has_head(&(v483_9)) { singleton(&[]) } else { Space::new() };
        drop(v483_9);
        let v483_12: Space = if (&(v483_10)).is_empty() { Space::new() } else {
          let v488_6: Path = concat_path(&(v482_6),&v480_21_cursor.path()[(v480_21_origin + 1)..(v480_21_origin + 2)]);
          let mut v488_11 = Space::new();
          let mut v488_11_write = v488_11.write_zipper();
          for v488_11_byte in v480_21_cursor.child_mask().iter() {
            v480_21_cursor.descend_to_existing_byte(v488_11_byte);
            {
            let v489_2: Space = singleton(&v480_21_cursor.path()[(v480_21_origin + 2)..(v480_21_origin + 3)]);
            let v489_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v489_2));
            let v489_4: Space = if map_kernels::has_head(&(v489_3)) { singleton(&[]) } else { Space::new() };
            drop(v489_3);
            let v489_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v489_4));
            drop(v489_4);
            let v489_8: Space = if (&(v489_5)).is_empty() { Space::new() } else {
              let v490_6: Path = concat_path(&(v488_6),&v480_21_cursor.path()[(v480_21_origin + 2)..(v480_21_origin + 3)]);
              let v490_7: Space = routine_38(c, &(v490_6), &(*p1), &v480_21_cursor);
              map_map_kernels::compose(&(v489_5),&(v490_7))
            };
            drop(v489_5);
            let v489_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v489_2));
            drop(v489_2);
            let v489_10: Space = if map_kernels::has_head(&(v489_9)) { singleton(&[]) } else { Space::new() };
            drop(v489_9);
            let v489_12: Space = if (&(v489_10)).is_empty() { Space::new() } else {
              let v491_6: Path = concat_path(&(v488_6),&v480_21_cursor.path()[(v480_21_origin + 2)..(v480_21_origin + 3)]);
              let v491_11: Space = routine_19(c, &(v491_6), &(*p1), &v480_21_cursor);
              drop(v491_6);
              map_map_kernels::compose(&(v489_10),&(v491_11))
            };
            drop(v489_10);
            let v489_13: Space = map_map_kernels::unite(&(v489_8),&(v489_12));
            join_wrapped_into(&mut v488_11_write,&((v489_13).read_zipper()),&[]);
            }
            v480_21_cursor.ascend(1);
          }
          drop(v488_11_write);
          drop(v488_6);
          map_map_kernels::compose(&(v483_10),&(v488_11))
        };
        drop(v483_10);
        let v483_13: Space = map_map_kernels::unite(&(v483_8),&(v483_12));
        join_wrapped_into(&mut v482_7_write,&((v483_13).read_zipper()),&[]);
        }
        v480_21_cursor.ascend(1);
      }
      drop(v482_7_write);
      map_map_kernels::compose(&(v481_5),&(v482_7))
    };
    drop(v481_5);
    let v481_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v481_2));
    drop(v481_2);
    let v481_10: Space = if map_kernels::has_head(&(v481_9)) { singleton(&[]) } else { Space::new() };
    drop(v481_9);
    let v481_12: Space = if (&(v481_10)).is_empty() { Space::new() } else {
      let v492_6: Path = concat_path(&(*p0),&v480_21_cursor.path()[v480_21_origin..(v480_21_origin + 1)]);
      let mut v492_11 = Space::new();
      let mut v492_11_write = v492_11.write_zipper();
      for v492_11_byte in v480_21_cursor.child_mask().iter() {
        v480_21_cursor.descend_to_existing_byte(v492_11_byte);
        {
        let v493_2: Space = singleton(&v480_21_cursor.path()[(v480_21_origin + 1)..(v480_21_origin + 2)]);
        let v493_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v493_2));
        let v493_4: Space = if map_kernels::has_head(&(v493_3)) { singleton(&[]) } else { Space::new() };
        drop(v493_3);
        let v493_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v493_4));
        drop(v493_4);
        let v493_8: Space = if (&(v493_5)).is_empty() { Space::new() } else {
          let v494_6: Path = concat_path(&(v492_6),&v480_21_cursor.path()[(v480_21_origin + 1)..(v480_21_origin + 2)]);
          let mut v494_7 = Space::new();
          let mut v494_7_write = v494_7.write_zipper();
          for v494_7_byte in v480_21_cursor.child_mask().iter() {
            v480_21_cursor.descend_to_existing_byte(v494_7_byte);
            {
            let v495_2: Space = singleton(&v480_21_cursor.path()[(v480_21_origin + 2)..(v480_21_origin + 3)]);
            let v495_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v495_2));
            let v495_4: Space = if map_kernels::has_head(&(v495_3)) { singleton(&[]) } else { Space::new() };
            drop(v495_3);
            let v495_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v495_4));
            drop(v495_4);
            let v495_8: Space = if (&(v495_5)).is_empty() { Space::new() } else {
              let v496_6: Path = concat_path(&(v494_6),&v480_21_cursor.path()[(v480_21_origin + 2)..(v480_21_origin + 3)]);
              let v496_7: Space = routine_38(c, &(v496_6), &(*p1), &v480_21_cursor);
              map_map_kernels::compose(&(v495_5),&(v496_7))
            };
            drop(v495_5);
            let v495_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v495_2));
            drop(v495_2);
            let v495_10: Space = if map_kernels::has_head(&(v495_9)) { singleton(&[]) } else { Space::new() };
            drop(v495_9);
            let v495_12: Space = if (&(v495_10)).is_empty() { Space::new() } else {
              let v497_6: Path = concat_path(&(v494_6),&v480_21_cursor.path()[(v480_21_origin + 2)..(v480_21_origin + 3)]);
              let v497_11: Space = routine_39(c, &(v497_6), &(*p1), &v480_21_cursor);
              drop(v497_6);
              map_map_kernels::compose(&(v495_10),&(v497_11))
            };
            drop(v495_10);
            let v495_13: Space = map_map_kernels::unite(&(v495_8),&(v495_12));
            join_wrapped_into(&mut v494_7_write,&((v495_13).read_zipper()),&[]);
            }
            v480_21_cursor.ascend(1);
          }
          drop(v494_7_write);
          map_map_kernels::compose(&(v493_5),&(v494_7))
        };
        drop(v493_5);
        let v493_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v493_2));
        drop(v493_2);
        let v493_10: Space = if map_kernels::has_head(&(v493_9)) { singleton(&[]) } else { Space::new() };
        drop(v493_9);
        let v493_11: Space = map_view_kernels::compose(&(v493_10),&v480_21_cursor);
        drop(v493_10);
        let v498_6: Path = concat_path(&(v492_6),&v480_21_cursor.path()[(v480_21_origin + 1)..(v480_21_origin + 2)]);
        let v493_12: Space = map_kernels::wrap(&(v493_11),&(v498_6));
        drop(v493_11);
        let v493_13: Space = map_kernels::wrap(&(v493_12),&(*p1));
        drop(v493_12);
        let v493_14: Space = map_map_kernels::unite(&(v493_8),&(v493_13));
        drop(v493_13);
        join_wrapped_into(&mut v492_11_write,&((v493_14).read_zipper()),&[]);
        }
        v480_21_cursor.ascend(1);
      }
      drop(v492_11_write);
      drop(v492_6);
      map_map_kernels::compose(&(v481_10),&(v492_11))
    };
    drop(v481_10);
    let v481_13: Space = map_map_kernels::unite(&(v481_8),&(v481_12));
    join_wrapped_into(&mut v480_21_write,&((v481_13).read_zipper()),&[]);
    }
    v480_21_cursor.ascend(1);
  }
  drop(v480_21_cursor);
  drop(v480_21_write);
  (v480_21).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v499_15 = Space::new();
  let mut v499_15_write = v499_15.write_zipper();
  let mut v499_15_cursor = (*s0).read_zipper();
  let v499_15_origin = v499_15_cursor.path().len();
  for v499_15_byte in v499_15_cursor.child_mask().iter() {
    v499_15_cursor.descend_to_existing_byte(v499_15_byte);
    {
    let v500_2: Space = singleton(&v499_15_cursor.path()[v499_15_origin..(v499_15_origin + 1)]);
    let v500_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v500_2));
    let v500_4: Space = if map_kernels::has_head(&(v500_3)) { singleton(&[]) } else { Space::new() };
    drop(v500_3);
    let v500_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v500_4));
    drop(v500_4);
    let v500_8: Space = if (&(v500_5)).is_empty() { Space::new() } else {
      let v501_6: Path = concat_path(&(*p0),&v499_15_cursor.path()[v499_15_origin..(v499_15_origin + 1)]);
      let mut v501_7 = Space::new();
      let mut v501_7_write = v501_7.write_zipper();
      for v501_7_byte in v499_15_cursor.child_mask().iter() {
        v499_15_cursor.descend_to_existing_byte(v501_7_byte);
        {
        let v502_2: Space = singleton(&v499_15_cursor.path()[(v499_15_origin + 1)..(v499_15_origin + 2)]);
        let v502_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v502_2));
        let v502_4: Space = if map_kernels::has_head(&(v502_3)) { singleton(&[]) } else { Space::new() };
        drop(v502_3);
        let v502_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v502_4));
        drop(v502_4);
        let v502_8: Space = if (&(v502_5)).is_empty() { Space::new() } else {
          let v503_6: Path = concat_path(&(v501_6),&v499_15_cursor.path()[(v499_15_origin + 1)..(v499_15_origin + 2)]);
          let mut v503_7 = Space::new();
          let mut v503_7_write = v503_7.write_zipper();
          for v503_7_byte in v499_15_cursor.child_mask().iter() {
            v499_15_cursor.descend_to_existing_byte(v503_7_byte);
            {
            let v504_2: Space = singleton(&v499_15_cursor.path()[(v499_15_origin + 2)..(v499_15_origin + 3)]);
            let v504_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v504_2));
            let v504_4: Space = if map_kernels::has_head(&(v504_3)) { singleton(&[]) } else { Space::new() };
            drop(v504_3);
            let v504_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v504_4));
            drop(v504_4);
            let v504_8: Space = if (&(v504_5)).is_empty() { Space::new() } else {
              let v505_6: Path = concat_path(&(v503_6),&v499_15_cursor.path()[(v499_15_origin + 2)..(v499_15_origin + 3)]);
              let v505_7: Space = routine_38(c, &(v505_6), &(*p1), &v499_15_cursor);
              map_map_kernels::compose(&(v504_5),&(v505_7))
            };
            drop(v504_5);
            let v504_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v504_2));
            drop(v504_2);
            let v504_10: Space = if map_kernels::has_head(&(v504_9)) { singleton(&[]) } else { Space::new() };
            drop(v504_9);
            let v504_12: Space = if (&(v504_10)).is_empty() { Space::new() } else {
              let v506_6: Path = concat_path(&(v503_6),&v499_15_cursor.path()[(v499_15_origin + 2)..(v499_15_origin + 3)]);
              let v506_11: Space = routine_39(c, &(v506_6), &(*p1), &v499_15_cursor);
              drop(v506_6);
              map_map_kernels::compose(&(v504_10),&(v506_11))
            };
            drop(v504_10);
            let v504_13: Space = map_map_kernels::unite(&(v504_8),&(v504_12));
            join_wrapped_into(&mut v503_7_write,&((v504_13).read_zipper()),&[]);
            }
            v499_15_cursor.ascend(1);
          }
          drop(v503_7_write);
          map_map_kernels::compose(&(v502_5),&(v503_7))
        };
        drop(v502_5);
        let v502_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v502_2));
        drop(v502_2);
        let v502_10: Space = if map_kernels::has_head(&(v502_9)) { singleton(&[]) } else { Space::new() };
        drop(v502_9);
        let v502_12: Space = if (&(v502_10)).is_empty() { Space::new() } else {
          let v507_6: Path = concat_path(&(v501_6),&v499_15_cursor.path()[(v499_15_origin + 1)..(v499_15_origin + 2)]);
          let mut v507_11 = Space::new();
          let mut v507_11_write = v507_11.write_zipper();
          for v507_11_byte in v499_15_cursor.child_mask().iter() {
            v499_15_cursor.descend_to_existing_byte(v507_11_byte);
            {
            let v508_2: Space = singleton(&v499_15_cursor.path()[(v499_15_origin + 2)..(v499_15_origin + 3)]);
            let v508_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v508_2));
            let v508_4: Space = if map_kernels::has_head(&(v508_3)) { singleton(&[]) } else { Space::new() };
            drop(v508_3);
            let v508_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v508_4));
            drop(v508_4);
            let v508_8: Space = if (&(v508_5)).is_empty() { Space::new() } else {
              let v509_6: Path = concat_path(&(v507_6),&v499_15_cursor.path()[(v499_15_origin + 2)..(v499_15_origin + 3)]);
              let v509_7: Space = routine_38(c, &(v509_6), &(*p1), &v499_15_cursor);
              map_map_kernels::compose(&(v508_5),&(v509_7))
            };
            drop(v508_5);
            let v508_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v508_2));
            drop(v508_2);
            let v508_10: Space = if map_kernels::has_head(&(v508_9)) { singleton(&[]) } else { Space::new() };
            drop(v508_9);
            let v508_12: Space = if (&(v508_10)).is_empty() { Space::new() } else {
              let v510_6: Path = concat_path(&(v507_6),&v499_15_cursor.path()[(v499_15_origin + 2)..(v499_15_origin + 3)]);
              let v510_11: Space = routine_19(c, &(v510_6), &(*p1), &v499_15_cursor);
              drop(v510_6);
              map_map_kernels::compose(&(v508_10),&(v510_11))
            };
            drop(v508_10);
            let v508_13: Space = map_map_kernels::unite(&(v508_8),&(v508_12));
            join_wrapped_into(&mut v507_11_write,&((v508_13).read_zipper()),&[]);
            }
            v499_15_cursor.ascend(1);
          }
          drop(v507_11_write);
          drop(v507_6);
          map_map_kernels::compose(&(v502_10),&(v507_11))
        };
        drop(v502_10);
        let v502_13: Space = map_map_kernels::unite(&(v502_8),&(v502_12));
        join_wrapped_into(&mut v501_7_write,&((v502_13).read_zipper()),&[]);
        }
        v499_15_cursor.ascend(1);
      }
      drop(v501_7_write);
      map_map_kernels::compose(&(v500_5),&(v501_7))
    };
    drop(v500_5);
    let v500_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v500_2));
    drop(v500_2);
    let v500_10: Space = if map_kernels::has_head(&(v500_9)) { singleton(&[]) } else { Space::new() };
    drop(v500_9);
    let v500_11: Space = map_view_kernels::compose(&(v500_10),&v499_15_cursor);
    drop(v500_10);
    let v511_6: Path = concat_path(&(*p0),&v499_15_cursor.path()[v499_15_origin..(v499_15_origin + 1)]);
    let v500_12: Space = map_kernels::wrap(&(v500_11),&(v511_6));
    drop(v500_11);
    let v500_13: Space = map_kernels::wrap(&(v500_12),&(*p1));
    drop(v500_12);
    let v500_14: Space = map_map_kernels::unite(&(v500_8),&(v500_13));
    drop(v500_13);
    join_wrapped_into(&mut v499_15_write,&((v500_14).read_zipper()),&[]);
    }
    v499_15_cursor.ascend(1);
  }
  drop(v499_15_cursor);
  drop(v499_15_write);
  (v499_15).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v512_28 = Space::new();
  let mut v512_28_write = v512_28.write_zipper();
  let mut v512_28_cursor = (*s0).read_zipper();
  let v512_28_origin = v512_28_cursor.path().len();
  for v512_28_byte in v512_28_cursor.child_mask().iter() {
    v512_28_cursor.descend_to_existing_byte(v512_28_byte);
    {
    let v513_2: Space = singleton(&v512_28_cursor.path()[v512_28_origin..(v512_28_origin + 1)]);
    let v513_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v513_2));
    let v513_4: Space = if map_kernels::has_head(&(v513_3)) { singleton(&[]) } else { Space::new() };
    drop(v513_3);
    let v513_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v513_4));
    drop(v513_4);
    let v513_8: Space = if (&(v513_5)).is_empty() { Space::new() } else {
      let v514_6: Path = concat_path(&(*p0),&v512_28_cursor.path()[v512_28_origin..(v512_28_origin + 1)]);
      let mut v514_7 = Space::new();
      let mut v514_7_write = v514_7.write_zipper();
      for v514_7_byte in v512_28_cursor.child_mask().iter() {
        v512_28_cursor.descend_to_existing_byte(v514_7_byte);
        {
        let v515_2: Space = singleton(&v512_28_cursor.path()[(v512_28_origin + 1)..(v512_28_origin + 2)]);
        let v515_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v515_2));
        let v515_4: Space = if map_kernels::has_head(&(v515_3)) { singleton(&[]) } else { Space::new() };
        drop(v515_3);
        let v515_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v515_4));
        drop(v515_4);
        let v515_8: Space = if (&(v515_5)).is_empty() { Space::new() } else {
          let v516_6: Path = concat_path(&(v514_6),&v512_28_cursor.path()[(v512_28_origin + 1)..(v512_28_origin + 2)]);
          let mut v516_7 = Space::new();
          let mut v516_7_write = v516_7.write_zipper();
          for v516_7_byte in v512_28_cursor.child_mask().iter() {
            v512_28_cursor.descend_to_existing_byte(v516_7_byte);
            {
            let v517_2: Space = singleton(&v512_28_cursor.path()[(v512_28_origin + 2)..(v512_28_origin + 3)]);
            let v517_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v517_2));
            let v517_4: Space = if map_kernels::has_head(&(v517_3)) { singleton(&[]) } else { Space::new() };
            drop(v517_3);
            let v517_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v517_4));
            drop(v517_4);
            let v517_8: Space = if (&(v517_5)).is_empty() { Space::new() } else {
              let v518_6: Path = concat_path(&(v516_6),&v512_28_cursor.path()[(v512_28_origin + 2)..(v512_28_origin + 3)]);
              let v518_7: Space = routine_40(c, &(v518_6), &(*p1), &v512_28_cursor, &(*s1));
              map_map_kernels::compose(&(v517_5),&(v518_7))
            };
            drop(v517_5);
            let v517_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v517_2));
            drop(v517_2);
            let v517_10: Space = if map_kernels::has_head(&(v517_9)) { singleton(&[]) } else { Space::new() };
            drop(v517_9);
            let v517_12: Space = if (&(v517_10)).is_empty() { Space::new() } else {
              let v519_6: Path = concat_path(&(v516_6),&v512_28_cursor.path()[(v512_28_origin + 2)..(v512_28_origin + 3)]);
              let v519_11: Space = routine_41(c, &(v519_6), &(*p1), &v512_28_cursor, &(*s1));
              drop(v519_6);
              map_map_kernels::compose(&(v517_10),&(v519_11))
            };
            drop(v517_10);
            let v517_13: Space = map_map_kernels::unite(&(v517_8),&(v517_12));
            join_wrapped_into(&mut v516_7_write,&((v517_13).read_zipper()),&[]);
            }
            v512_28_cursor.ascend(1);
          }
          drop(v516_7_write);
          map_map_kernels::compose(&(v515_5),&(v516_7))
        };
        drop(v515_5);
        let v515_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v515_2));
        drop(v515_2);
        let v515_10: Space = if map_kernels::has_head(&(v515_9)) { singleton(&[]) } else { Space::new() };
        drop(v515_9);
        let v515_12: Space = if (&(v515_10)).is_empty() { Space::new() } else {
          let v520_6: Path = concat_path(&(v514_6),&v512_28_cursor.path()[(v512_28_origin + 1)..(v512_28_origin + 2)]);
          let mut v520_11 = Space::new();
          let mut v520_11_write = v520_11.write_zipper();
          for v520_11_byte in v512_28_cursor.child_mask().iter() {
            v512_28_cursor.descend_to_existing_byte(v520_11_byte);
            {
            let v521_2: Space = singleton(&v512_28_cursor.path()[(v512_28_origin + 2)..(v512_28_origin + 3)]);
            let v521_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v521_2));
            let v521_4: Space = if map_kernels::has_head(&(v521_3)) { singleton(&[]) } else { Space::new() };
            drop(v521_3);
            let v521_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v521_4));
            drop(v521_4);
            let v521_8: Space = if (&(v521_5)).is_empty() { Space::new() } else {
              let v522_6: Path = concat_path(&(v520_6),&v512_28_cursor.path()[(v512_28_origin + 2)..(v512_28_origin + 3)]);
              let v522_7: Space = routine_40(c, &(v522_6), &(*p1), &v512_28_cursor, &(*s1));
              map_map_kernels::compose(&(v521_5),&(v522_7))
            };
            drop(v521_5);
            let v521_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v521_2));
            drop(v521_2);
            let v521_10: Space = if map_kernels::has_head(&(v521_9)) { singleton(&[]) } else { Space::new() };
            drop(v521_9);
            let v521_12: Space = if (&(v521_10)).is_empty() { Space::new() } else {
              let v523_6: Path = concat_path(&(v520_6),&v512_28_cursor.path()[(v512_28_origin + 2)..(v512_28_origin + 3)]);
              let v523_11: Space = routine_10(c, &(v523_6), &(*p1), &v512_28_cursor, &(*s1));
              drop(v523_6);
              map_map_kernels::compose(&(v521_10),&(v523_11))
            };
            drop(v521_10);
            let v521_13: Space = map_map_kernels::unite(&(v521_8),&(v521_12));
            join_wrapped_into(&mut v520_11_write,&((v521_13).read_zipper()),&[]);
            }
            v512_28_cursor.ascend(1);
          }
          drop(v520_11_write);
          drop(v520_6);
          map_map_kernels::compose(&(v515_10),&(v520_11))
        };
        drop(v515_10);
        let v515_13: Space = map_map_kernels::unite(&(v515_8),&(v515_12));
        join_wrapped_into(&mut v514_7_write,&((v515_13).read_zipper()),&[]);
        }
        v512_28_cursor.ascend(1);
      }
      drop(v514_7_write);
      map_map_kernels::compose(&(v513_5),&(v514_7))
    };
    drop(v513_5);
    let v513_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v513_2));
    drop(v513_2);
    let v513_10: Space = if map_kernels::has_head(&(v513_9)) { singleton(&[]) } else { Space::new() };
    drop(v513_9);
    let v513_13: Space = if (&(v513_10)).is_empty() { Space::new() } else {
      let v524_6: Path = concat_path(&(*p0),&v512_28_cursor.path()[v512_28_origin..(v512_28_origin + 1)]);
      let mut v524_12 = Space::new();
      let mut v524_12_write = v524_12.write_zipper();
      for v524_12_byte in v512_28_cursor.child_mask().iter() {
        v512_28_cursor.descend_to_existing_byte(v524_12_byte);
        {
        let v525_2: Space = singleton(&v512_28_cursor.path()[(v512_28_origin + 1)..(v512_28_origin + 2)]);
        let v525_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v525_2));
        let v525_4: Space = if map_kernels::has_head(&(v525_3)) { singleton(&[]) } else { Space::new() };
        drop(v525_3);
        let v525_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v525_4));
        drop(v525_4);
        let v525_8: Space = if (&(v525_5)).is_empty() { Space::new() } else {
          let v526_6: Path = concat_path(&(v524_6),&v512_28_cursor.path()[(v512_28_origin + 1)..(v512_28_origin + 2)]);
          let mut v526_7 = Space::new();
          let mut v526_7_write = v526_7.write_zipper();
          for v526_7_byte in v512_28_cursor.child_mask().iter() {
            v512_28_cursor.descend_to_existing_byte(v526_7_byte);
            {
            let v527_2: Space = singleton(&v512_28_cursor.path()[(v512_28_origin + 2)..(v512_28_origin + 3)]);
            let v527_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v527_2));
            let v527_4: Space = if map_kernels::has_head(&(v527_3)) { singleton(&[]) } else { Space::new() };
            drop(v527_3);
            let v527_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v527_4));
            drop(v527_4);
            let v527_8: Space = if (&(v527_5)).is_empty() { Space::new() } else {
              let v528_6: Path = concat_path(&(v526_6),&v512_28_cursor.path()[(v512_28_origin + 2)..(v512_28_origin + 3)]);
              let v528_7: Space = routine_40(c, &(v528_6), &(*p1), &v512_28_cursor, &(*s1));
              map_map_kernels::compose(&(v527_5),&(v528_7))
            };
            drop(v527_5);
            let v527_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v527_2));
            drop(v527_2);
            let v527_10: Space = if map_kernels::has_head(&(v527_9)) { singleton(&[]) } else { Space::new() };
            drop(v527_9);
            let v527_12: Space = if (&(v527_10)).is_empty() { Space::new() } else {
              let v529_6: Path = concat_path(&(v526_6),&v512_28_cursor.path()[(v512_28_origin + 2)..(v512_28_origin + 3)]);
              let v529_11: Space = routine_41(c, &(v529_6), &(*p1), &v512_28_cursor, &(*s1));
              drop(v529_6);
              map_map_kernels::compose(&(v527_10),&(v529_11))
            };
            drop(v527_10);
            let v527_13: Space = map_map_kernels::unite(&(v527_8),&(v527_12));
            join_wrapped_into(&mut v526_7_write,&((v527_13).read_zipper()),&[]);
            }
            v512_28_cursor.ascend(1);
          }
          drop(v526_7_write);
          drop(v526_6);
          map_map_kernels::compose(&(v525_5),&(v526_7))
        };
        drop(v525_5);
        let v525_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v525_2));
        drop(v525_2);
        let v525_10: Space = if map_kernels::has_head(&(v525_9)) { singleton(&[]) } else { Space::new() };
        drop(v525_9);
        let v525_13: Space = if (&(v525_10)).is_empty() { Space::new() } else {
          let mut v530_12 = Space::new();
          let mut v530_12_write = v530_12.write_zipper();
          let mut v530_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v512_28_cursor.path()[v512_28_origin..(v512_28_origin + 1)]),&v512_28_cursor.path()[(v512_28_origin + 1)..(v512_28_origin + 2)]);
          let v530_12_origin = v530_12_cursor.path().len();
          for v530_12_byte in v530_12_cursor.child_mask().iter() {
            v530_12_cursor.descend_to_existing_byte(v530_12_byte);
            {
            let v531_2: Space = singleton(&v530_12_cursor.path()[v530_12_origin..(v530_12_origin + 1)]);
            let v531_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v531_2));
            let v531_4: Space = if map_kernels::has_head(&(v531_3)) { singleton(&[]) } else { Space::new() };
            drop(v531_3);
            let v531_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v531_4));
            drop(v531_4);
            let v531_7: Space = if (&(v531_5)).is_empty() { Space::new() } else {
              let v532_6: Space = routine_13(c, &v530_12_cursor.path()[v530_12_origin..(v530_12_origin + 1)], &(*p1), &v530_12_cursor);
              map_map_kernels::compose(&(v531_5),&(v532_6))
            };
            drop(v531_5);
            let v531_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v531_2));
            drop(v531_2);
            let v531_9: Space = if map_kernels::has_head(&(v531_8)) { singleton(&[]) } else { Space::new() };
            drop(v531_8);
            let v531_11: Space = if (&(v531_9)).is_empty() { Space::new() } else {
              let v533_10: Space = routine_14(c, &v530_12_cursor.path()[v530_12_origin..(v530_12_origin + 1)], &(*p1), &v530_12_cursor);
              map_map_kernels::compose(&(v531_9),&(v533_10))
            };
            drop(v531_9);
            let v531_12: Space = map_map_kernels::unite(&(v531_7),&(v531_11));
            join_wrapped_into(&mut v530_12_write,&((v531_12).read_zipper()),&[]);
            }
            v530_12_cursor.ascend(1);
          }
          drop(v530_12_cursor);
          drop(v530_12_write);
          map_map_kernels::compose(&(v525_10),&(v530_12))
        };
        drop(v525_10);
        let v525_14: Space = map_map_kernels::unite(&(v525_8),&(v525_13));
        join_wrapped_into(&mut v524_12_write,&((v525_14).read_zipper()),&[]);
        }
        v512_28_cursor.ascend(1);
      }
      drop(v524_12_write);
      drop(v524_6);
      map_map_kernels::compose(&(v513_10),&(v524_12))
    };
    drop(v513_10);
    let v513_14: Space = map_map_kernels::unite(&(v513_8),&(v513_13));
    join_wrapped_into(&mut v512_28_write,&((v513_14).read_zipper()),&[]);
    }
    v512_28_cursor.ascend(1);
  }
  drop(v512_28_cursor);
  drop(v512_28_write);
  (v512_28).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v534_28 = Space::new();
  let mut v534_28_write = v534_28.write_zipper();
  let mut v534_28_cursor = (*s0).read_zipper();
  let v534_28_origin = v534_28_cursor.path().len();
  for v534_28_byte in v534_28_cursor.child_mask().iter() {
    v534_28_cursor.descend_to_existing_byte(v534_28_byte);
    {
    let v535_2: Space = singleton(&v534_28_cursor.path()[v534_28_origin..(v534_28_origin + 1)]);
    let v535_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v535_2));
    let v535_4: Space = if map_kernels::has_head(&(v535_3)) { singleton(&[]) } else { Space::new() };
    drop(v535_3);
    let v535_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v535_4));
    drop(v535_4);
    let v535_8: Space = if (&(v535_5)).is_empty() { Space::new() } else {
      let v536_6: Path = concat_path(&(*p0),&v534_28_cursor.path()[v534_28_origin..(v534_28_origin + 1)]);
      let mut v536_7 = Space::new();
      let mut v536_7_write = v536_7.write_zipper();
      for v536_7_byte in v534_28_cursor.child_mask().iter() {
        v534_28_cursor.descend_to_existing_byte(v536_7_byte);
        {
        let v537_2: Space = singleton(&v534_28_cursor.path()[(v534_28_origin + 1)..(v534_28_origin + 2)]);
        let v537_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v537_2));
        let v537_4: Space = if map_kernels::has_head(&(v537_3)) { singleton(&[]) } else { Space::new() };
        drop(v537_3);
        let v537_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v537_4));
        drop(v537_4);
        let v537_8: Space = if (&(v537_5)).is_empty() { Space::new() } else {
          let v538_6: Path = concat_path(&(v536_6),&v534_28_cursor.path()[(v534_28_origin + 1)..(v534_28_origin + 2)]);
          let mut v538_7 = Space::new();
          let mut v538_7_write = v538_7.write_zipper();
          for v538_7_byte in v534_28_cursor.child_mask().iter() {
            v534_28_cursor.descend_to_existing_byte(v538_7_byte);
            {
            let v539_2: Space = singleton(&v534_28_cursor.path()[(v534_28_origin + 2)..(v534_28_origin + 3)]);
            let v539_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v539_2));
            let v539_4: Space = if map_kernels::has_head(&(v539_3)) { singleton(&[]) } else { Space::new() };
            drop(v539_3);
            let v539_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v539_4));
            drop(v539_4);
            let v539_8: Space = if (&(v539_5)).is_empty() { Space::new() } else {
              let v540_6: Path = concat_path(&(v538_6),&v534_28_cursor.path()[(v534_28_origin + 2)..(v534_28_origin + 3)]);
              let v540_7: Space = routine_40(c, &(v540_6), &(*p1), &v534_28_cursor, &(*s1));
              map_map_kernels::compose(&(v539_5),&(v540_7))
            };
            drop(v539_5);
            let v539_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v539_2));
            drop(v539_2);
            let v539_10: Space = if map_kernels::has_head(&(v539_9)) { singleton(&[]) } else { Space::new() };
            drop(v539_9);
            let v539_12: Space = if (&(v539_10)).is_empty() { Space::new() } else {
              let v541_6: Path = concat_path(&(v538_6),&v534_28_cursor.path()[(v534_28_origin + 2)..(v534_28_origin + 3)]);
              let v541_11: Space = routine_41(c, &(v541_6), &(*p1), &v534_28_cursor, &(*s1));
              drop(v541_6);
              map_map_kernels::compose(&(v539_10),&(v541_11))
            };
            drop(v539_10);
            let v539_13: Space = map_map_kernels::unite(&(v539_8),&(v539_12));
            join_wrapped_into(&mut v538_7_write,&((v539_13).read_zipper()),&[]);
            }
            v534_28_cursor.ascend(1);
          }
          drop(v538_7_write);
          map_map_kernels::compose(&(v537_5),&(v538_7))
        };
        drop(v537_5);
        let v537_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v537_2));
        drop(v537_2);
        let v537_10: Space = if map_kernels::has_head(&(v537_9)) { singleton(&[]) } else { Space::new() };
        drop(v537_9);
        let v537_12: Space = if (&(v537_10)).is_empty() { Space::new() } else {
          let v542_6: Path = concat_path(&(v536_6),&v534_28_cursor.path()[(v534_28_origin + 1)..(v534_28_origin + 2)]);
          let mut v542_11 = Space::new();
          let mut v542_11_write = v542_11.write_zipper();
          for v542_11_byte in v534_28_cursor.child_mask().iter() {
            v534_28_cursor.descend_to_existing_byte(v542_11_byte);
            {
            let v543_2: Space = singleton(&v534_28_cursor.path()[(v534_28_origin + 2)..(v534_28_origin + 3)]);
            let v543_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v543_2));
            let v543_4: Space = if map_kernels::has_head(&(v543_3)) { singleton(&[]) } else { Space::new() };
            drop(v543_3);
            let v543_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v543_4));
            drop(v543_4);
            let v543_8: Space = if (&(v543_5)).is_empty() { Space::new() } else {
              let v544_6: Path = concat_path(&(v542_6),&v534_28_cursor.path()[(v534_28_origin + 2)..(v534_28_origin + 3)]);
              let v544_7: Space = routine_40(c, &(v544_6), &(*p1), &v534_28_cursor, &(*s1));
              map_map_kernels::compose(&(v543_5),&(v544_7))
            };
            drop(v543_5);
            let v543_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v543_2));
            drop(v543_2);
            let v543_10: Space = if map_kernels::has_head(&(v543_9)) { singleton(&[]) } else { Space::new() };
            drop(v543_9);
            let v543_12: Space = if (&(v543_10)).is_empty() { Space::new() } else {
              let v545_6: Path = concat_path(&(v542_6),&v534_28_cursor.path()[(v534_28_origin + 2)..(v534_28_origin + 3)]);
              let v545_11: Space = routine_10(c, &(v545_6), &(*p1), &v534_28_cursor, &(*s1));
              drop(v545_6);
              map_map_kernels::compose(&(v543_10),&(v545_11))
            };
            drop(v543_10);
            let v543_13: Space = map_map_kernels::unite(&(v543_8),&(v543_12));
            join_wrapped_into(&mut v542_11_write,&((v543_13).read_zipper()),&[]);
            }
            v534_28_cursor.ascend(1);
          }
          drop(v542_11_write);
          drop(v542_6);
          map_map_kernels::compose(&(v537_10),&(v542_11))
        };
        drop(v537_10);
        let v537_13: Space = map_map_kernels::unite(&(v537_8),&(v537_12));
        join_wrapped_into(&mut v536_7_write,&((v537_13).read_zipper()),&[]);
        }
        v534_28_cursor.ascend(1);
      }
      drop(v536_7_write);
      drop(v536_6);
      map_map_kernels::compose(&(v535_5),&(v536_7))
    };
    drop(v535_5);
    let v535_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v535_2));
    drop(v535_2);
    let v535_10: Space = if map_kernels::has_head(&(v535_9)) { singleton(&[]) } else { Space::new() };
    drop(v535_9);
    let v535_13: Space = if (&(v535_10)).is_empty() { Space::new() } else {
      let mut v546_12 = Space::new();
      let mut v546_12_write = v546_12.write_zipper();
      let mut v546_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v534_28_cursor.path()[v534_28_origin..(v534_28_origin + 1)]);
      let v546_12_origin = v546_12_cursor.path().len();
      for v546_12_byte in v546_12_cursor.child_mask().iter() {
        v546_12_cursor.descend_to_existing_byte(v546_12_byte);
        {
        let v547_2: Space = singleton(&v546_12_cursor.path()[v546_12_origin..(v546_12_origin + 1)]);
        let v547_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v547_2));
        let v547_4: Space = if map_kernels::has_head(&(v547_3)) { singleton(&[]) } else { Space::new() };
        drop(v547_3);
        let v547_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v547_4));
        drop(v547_4);
        let v547_7: Space = if (&(v547_5)).is_empty() { Space::new() } else {
          let mut v548_6 = Space::new();
          let mut v548_6_write = v548_6.write_zipper();
          for v548_6_byte in v546_12_cursor.child_mask().iter() {
            v546_12_cursor.descend_to_existing_byte(v548_6_byte);
            {
            let v549_2: Space = singleton(&v546_12_cursor.path()[(v546_12_origin + 1)..(v546_12_origin + 2)]);
            let v549_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v549_2));
            let v549_4: Space = if map_kernels::has_head(&(v549_3)) { singleton(&[]) } else { Space::new() };
            drop(v549_3);
            let v549_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v549_4));
            drop(v549_4);
            let v549_8: Space = if (&(v549_5)).is_empty() { Space::new() } else {
              let v550_7: Space = routine_17(c, &v546_12_cursor.path()[v546_12_origin..(v546_12_origin + 2)], &(*p1), &v546_12_cursor);
              map_map_kernels::compose(&(v549_5),&(v550_7))
            };
            drop(v549_5);
            let v549_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v549_2));
            drop(v549_2);
            let v549_10: Space = if map_kernels::has_head(&(v549_9)) { singleton(&[]) } else { Space::new() };
            drop(v549_9);
            let v549_12: Space = if (&(v549_10)).is_empty() { Space::new() } else {
              let v551_11: Space = routine_18(c, &v546_12_cursor.path()[v546_12_origin..(v546_12_origin + 2)], &(*p1), &v546_12_cursor);
              map_map_kernels::compose(&(v549_10),&(v551_11))
            };
            drop(v549_10);
            let v549_13: Space = map_map_kernels::unite(&(v549_8),&(v549_12));
            join_wrapped_into(&mut v548_6_write,&((v549_13).read_zipper()),&[]);
            }
            v546_12_cursor.ascend(1);
          }
          drop(v548_6_write);
          map_map_kernels::compose(&(v547_5),&(v548_6))
        };
        drop(v547_5);
        let v547_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v547_2));
        drop(v547_2);
        let v547_9: Space = if map_kernels::has_head(&(v547_8)) { singleton(&[]) } else { Space::new() };
        drop(v547_8);
        let v547_11: Space = if (&(v547_9)).is_empty() { Space::new() } else {
          let mut v552_10 = Space::new();
          let mut v552_10_write = v552_10.write_zipper();
          for v552_10_byte in v546_12_cursor.child_mask().iter() {
            v546_12_cursor.descend_to_existing_byte(v552_10_byte);
            {
            let v553_2: Space = singleton(&v546_12_cursor.path()[(v546_12_origin + 1)..(v546_12_origin + 2)]);
            let v553_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v553_2));
            let v553_4: Space = if map_kernels::has_head(&(v553_3)) { singleton(&[]) } else { Space::new() };
            drop(v553_3);
            let v553_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v553_4));
            drop(v553_4);
            let v553_8: Space = if (&(v553_5)).is_empty() { Space::new() } else {
              let v554_7: Space = routine_17(c, &v546_12_cursor.path()[v546_12_origin..(v546_12_origin + 2)], &(*p1), &v546_12_cursor);
              map_map_kernels::compose(&(v553_5),&(v554_7))
            };
            drop(v553_5);
            let v553_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v553_2));
            drop(v553_2);
            let v553_10: Space = if map_kernels::has_head(&(v553_9)) { singleton(&[]) } else { Space::new() };
            drop(v553_9);
            let v553_12: Space = if (&(v553_10)).is_empty() { Space::new() } else {
              let v555_11: Space = routine_19(c, &v546_12_cursor.path()[v546_12_origin..(v546_12_origin + 2)], &(*p1), &v546_12_cursor);
              map_map_kernels::compose(&(v553_10),&(v555_11))
            };
            drop(v553_10);
            let v553_13: Space = map_map_kernels::unite(&(v553_8),&(v553_12));
            join_wrapped_into(&mut v552_10_write,&((v553_13).read_zipper()),&[]);
            }
            v546_12_cursor.ascend(1);
          }
          drop(v552_10_write);
          map_map_kernels::compose(&(v547_9),&(v552_10))
        };
        drop(v547_9);
        let v547_12: Space = map_map_kernels::unite(&(v547_7),&(v547_11));
        join_wrapped_into(&mut v546_12_write,&((v547_12).read_zipper()),&[]);
        }
        v546_12_cursor.ascend(1);
      }
      drop(v546_12_cursor);
      drop(v546_12_write);
      map_map_kernels::compose(&(v535_10),&(v546_12))
    };
    drop(v535_10);
    let v535_14: Space = map_map_kernels::unite(&(v535_8),&(v535_13));
    join_wrapped_into(&mut v534_28_write,&((v535_14).read_zipper()),&[]);
    }
    v534_28_cursor.ascend(1);
  }
  drop(v534_28_cursor);
  drop(v534_28_write);
  (v534_28).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v556_21 = Space::new();
  let mut v556_21_write = v556_21.write_zipper();
  let mut v556_21_cursor = (*s0).read_zipper();
  let v556_21_origin = v556_21_cursor.path().len();
  for v556_21_byte in v556_21_cursor.child_mask().iter() {
    v556_21_cursor.descend_to_existing_byte(v556_21_byte);
    {
    let v557_2: Space = singleton(&v556_21_cursor.path()[v556_21_origin..(v556_21_origin + 1)]);
    let v557_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v557_2));
    let v557_4: Space = if map_kernels::has_head(&(v557_3)) { singleton(&[]) } else { Space::new() };
    drop(v557_3);
    let v557_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v557_4));
    drop(v557_4);
    let v557_8: Space = if (&(v557_5)).is_empty() { Space::new() } else {
      let v558_6: Path = concat_path(&(*p0),&v556_21_cursor.path()[v556_21_origin..(v556_21_origin + 1)]);
      let mut v558_7 = Space::new();
      let mut v558_7_write = v558_7.write_zipper();
      for v558_7_byte in v556_21_cursor.child_mask().iter() {
        v556_21_cursor.descend_to_existing_byte(v558_7_byte);
        {
        let v559_2: Space = singleton(&v556_21_cursor.path()[(v556_21_origin + 1)..(v556_21_origin + 2)]);
        let v559_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v559_2));
        let v559_4: Space = if map_kernels::has_head(&(v559_3)) { singleton(&[]) } else { Space::new() };
        drop(v559_3);
        let v559_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v559_4));
        drop(v559_4);
        let v559_8: Space = if (&(v559_5)).is_empty() { Space::new() } else {
          let v560_6: Path = concat_path(&(v558_6),&v556_21_cursor.path()[(v556_21_origin + 1)..(v556_21_origin + 2)]);
          let mut v560_7 = Space::new();
          let mut v560_7_write = v560_7.write_zipper();
          for v560_7_byte in v556_21_cursor.child_mask().iter() {
            v556_21_cursor.descend_to_existing_byte(v560_7_byte);
            {
            let v561_2: Space = singleton(&v556_21_cursor.path()[(v556_21_origin + 2)..(v556_21_origin + 3)]);
            let v561_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v561_2));
            let v561_4: Space = if map_kernels::has_head(&(v561_3)) { singleton(&[]) } else { Space::new() };
            drop(v561_3);
            let v561_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v561_4));
            drop(v561_4);
            let v561_8: Space = if (&(v561_5)).is_empty() { Space::new() } else {
              let v562_6: Path = concat_path(&(v560_6),&v556_21_cursor.path()[(v556_21_origin + 2)..(v556_21_origin + 3)]);
              let v562_7: Space = routine_42(c, &(v562_6), &(*p1), &v556_21_cursor);
              map_map_kernels::compose(&(v561_5),&(v562_7))
            };
            drop(v561_5);
            let v561_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v561_2));
            drop(v561_2);
            let v561_10: Space = if map_kernels::has_head(&(v561_9)) { singleton(&[]) } else { Space::new() };
            drop(v561_9);
            let v561_12: Space = if (&(v561_10)).is_empty() { Space::new() } else {
              let v563_6: Path = concat_path(&(v560_6),&v556_21_cursor.path()[(v556_21_origin + 2)..(v556_21_origin + 3)]);
              let v563_11: Space = routine_43(c, &(v563_6), &(*p1), &v556_21_cursor);
              drop(v563_6);
              map_map_kernels::compose(&(v561_10),&(v563_11))
            };
            drop(v561_10);
            let v561_13: Space = map_map_kernels::unite(&(v561_8),&(v561_12));
            join_wrapped_into(&mut v560_7_write,&((v561_13).read_zipper()),&[]);
            }
            v556_21_cursor.ascend(1);
          }
          drop(v560_7_write);
          map_map_kernels::compose(&(v559_5),&(v560_7))
        };
        drop(v559_5);
        let v559_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v559_2));
        drop(v559_2);
        let v559_10: Space = if map_kernels::has_head(&(v559_9)) { singleton(&[]) } else { Space::new() };
        drop(v559_9);
        let v559_12: Space = if (&(v559_10)).is_empty() { Space::new() } else {
          let v564_6: Path = concat_path(&(v558_6),&v556_21_cursor.path()[(v556_21_origin + 1)..(v556_21_origin + 2)]);
          let mut v564_11 = Space::new();
          let mut v564_11_write = v564_11.write_zipper();
          for v564_11_byte in v556_21_cursor.child_mask().iter() {
            v556_21_cursor.descend_to_existing_byte(v564_11_byte);
            {
            let v565_2: Space = singleton(&v556_21_cursor.path()[(v556_21_origin + 2)..(v556_21_origin + 3)]);
            let v565_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v565_2));
            let v565_4: Space = if map_kernels::has_head(&(v565_3)) { singleton(&[]) } else { Space::new() };
            drop(v565_3);
            let v565_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v565_4));
            drop(v565_4);
            let v565_8: Space = if (&(v565_5)).is_empty() { Space::new() } else {
              let v566_6: Path = concat_path(&(v564_6),&v556_21_cursor.path()[(v556_21_origin + 2)..(v556_21_origin + 3)]);
              let v566_7: Space = routine_42(c, &(v566_6), &(*p1), &v556_21_cursor);
              map_map_kernels::compose(&(v565_5),&(v566_7))
            };
            drop(v565_5);
            let v565_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v565_2));
            drop(v565_2);
            let v565_10: Space = if map_kernels::has_head(&(v565_9)) { singleton(&[]) } else { Space::new() };
            drop(v565_9);
            let v565_12: Space = if (&(v565_10)).is_empty() { Space::new() } else {
              let v567_6: Path = concat_path(&(v564_6),&v556_21_cursor.path()[(v556_21_origin + 2)..(v556_21_origin + 3)]);
              let v567_11: Space = routine_19(c, &(v567_6), &(*p1), &v556_21_cursor);
              drop(v567_6);
              map_map_kernels::compose(&(v565_10),&(v567_11))
            };
            drop(v565_10);
            let v565_13: Space = map_map_kernels::unite(&(v565_8),&(v565_12));
            join_wrapped_into(&mut v564_11_write,&((v565_13).read_zipper()),&[]);
            }
            v556_21_cursor.ascend(1);
          }
          drop(v564_11_write);
          drop(v564_6);
          map_map_kernels::compose(&(v559_10),&(v564_11))
        };
        drop(v559_10);
        let v559_13: Space = map_map_kernels::unite(&(v559_8),&(v559_12));
        join_wrapped_into(&mut v558_7_write,&((v559_13).read_zipper()),&[]);
        }
        v556_21_cursor.ascend(1);
      }
      drop(v558_7_write);
      map_map_kernels::compose(&(v557_5),&(v558_7))
    };
    drop(v557_5);
    let v557_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v557_2));
    drop(v557_2);
    let v557_10: Space = if map_kernels::has_head(&(v557_9)) { singleton(&[]) } else { Space::new() };
    drop(v557_9);
    let v557_12: Space = if (&(v557_10)).is_empty() { Space::new() } else {
      let v568_6: Path = concat_path(&(*p0),&v556_21_cursor.path()[v556_21_origin..(v556_21_origin + 1)]);
      let mut v568_11 = Space::new();
      let mut v568_11_write = v568_11.write_zipper();
      for v568_11_byte in v556_21_cursor.child_mask().iter() {
        v556_21_cursor.descend_to_existing_byte(v568_11_byte);
        {
        let v569_2: Space = singleton(&v556_21_cursor.path()[(v556_21_origin + 1)..(v556_21_origin + 2)]);
        let v569_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v569_2));
        let v569_4: Space = if map_kernels::has_head(&(v569_3)) { singleton(&[]) } else { Space::new() };
        drop(v569_3);
        let v569_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v569_4));
        drop(v569_4);
        let v569_8: Space = if (&(v569_5)).is_empty() { Space::new() } else {
          let v570_6: Path = concat_path(&(v568_6),&v556_21_cursor.path()[(v556_21_origin + 1)..(v556_21_origin + 2)]);
          let mut v570_7 = Space::new();
          let mut v570_7_write = v570_7.write_zipper();
          for v570_7_byte in v556_21_cursor.child_mask().iter() {
            v556_21_cursor.descend_to_existing_byte(v570_7_byte);
            {
            let v571_2: Space = singleton(&v556_21_cursor.path()[(v556_21_origin + 2)..(v556_21_origin + 3)]);
            let v571_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v571_2));
            let v571_4: Space = if map_kernels::has_head(&(v571_3)) { singleton(&[]) } else { Space::new() };
            drop(v571_3);
            let v571_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v571_4));
            drop(v571_4);
            let v571_8: Space = if (&(v571_5)).is_empty() { Space::new() } else {
              let v572_6: Path = concat_path(&(v570_6),&v556_21_cursor.path()[(v556_21_origin + 2)..(v556_21_origin + 3)]);
              let v572_7: Space = routine_42(c, &(v572_6), &(*p1), &v556_21_cursor);
              map_map_kernels::compose(&(v571_5),&(v572_7))
            };
            drop(v571_5);
            let v571_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v571_2));
            drop(v571_2);
            let v571_10: Space = if map_kernels::has_head(&(v571_9)) { singleton(&[]) } else { Space::new() };
            drop(v571_9);
            let v571_12: Space = if (&(v571_10)).is_empty() { Space::new() } else {
              let v573_6: Path = concat_path(&(v570_6),&v556_21_cursor.path()[(v556_21_origin + 2)..(v556_21_origin + 3)]);
              let v573_11: Space = routine_43(c, &(v573_6), &(*p1), &v556_21_cursor);
              drop(v573_6);
              map_map_kernels::compose(&(v571_10),&(v573_11))
            };
            drop(v571_10);
            let v571_13: Space = map_map_kernels::unite(&(v571_8),&(v571_12));
            join_wrapped_into(&mut v570_7_write,&((v571_13).read_zipper()),&[]);
            }
            v556_21_cursor.ascend(1);
          }
          drop(v570_7_write);
          map_map_kernels::compose(&(v569_5),&(v570_7))
        };
        drop(v569_5);
        let v569_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v569_2));
        drop(v569_2);
        let v569_10: Space = if map_kernels::has_head(&(v569_9)) { singleton(&[]) } else { Space::new() };
        drop(v569_9);
        let v569_11: Space = map_view_kernels::compose(&(v569_10),&v556_21_cursor);
        drop(v569_10);
        let v574_6: Path = concat_path(&(v568_6),&v556_21_cursor.path()[(v556_21_origin + 1)..(v556_21_origin + 2)]);
        let v569_12: Space = map_kernels::wrap(&(v569_11),&(v574_6));
        drop(v569_11);
        let v569_13: Space = map_kernels::wrap(&(v569_12),&(*p1));
        drop(v569_12);
        let v569_14: Space = map_map_kernels::unite(&(v569_8),&(v569_13));
        drop(v569_13);
        join_wrapped_into(&mut v568_11_write,&((v569_14).read_zipper()),&[]);
        }
        v556_21_cursor.ascend(1);
      }
      drop(v568_11_write);
      drop(v568_6);
      map_map_kernels::compose(&(v557_10),&(v568_11))
    };
    drop(v557_10);
    let v557_13: Space = map_map_kernels::unite(&(v557_8),&(v557_12));
    join_wrapped_into(&mut v556_21_write,&((v557_13).read_zipper()),&[]);
    }
    v556_21_cursor.ascend(1);
  }
  drop(v556_21_cursor);
  drop(v556_21_write);
  (v556_21).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v575_15 = Space::new();
  let mut v575_15_write = v575_15.write_zipper();
  let mut v575_15_cursor = (*s0).read_zipper();
  let v575_15_origin = v575_15_cursor.path().len();
  for v575_15_byte in v575_15_cursor.child_mask().iter() {
    v575_15_cursor.descend_to_existing_byte(v575_15_byte);
    {
    let v576_2: Space = singleton(&v575_15_cursor.path()[v575_15_origin..(v575_15_origin + 1)]);
    let v576_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v576_2));
    let v576_4: Space = if map_kernels::has_head(&(v576_3)) { singleton(&[]) } else { Space::new() };
    drop(v576_3);
    let v576_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v576_4));
    drop(v576_4);
    let v576_8: Space = if (&(v576_5)).is_empty() { Space::new() } else {
      let v577_6: Path = concat_path(&(*p0),&v575_15_cursor.path()[v575_15_origin..(v575_15_origin + 1)]);
      let mut v577_7 = Space::new();
      let mut v577_7_write = v577_7.write_zipper();
      for v577_7_byte in v575_15_cursor.child_mask().iter() {
        v575_15_cursor.descend_to_existing_byte(v577_7_byte);
        {
        let v578_2: Space = singleton(&v575_15_cursor.path()[(v575_15_origin + 1)..(v575_15_origin + 2)]);
        let v578_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v578_2));
        let v578_4: Space = if map_kernels::has_head(&(v578_3)) { singleton(&[]) } else { Space::new() };
        drop(v578_3);
        let v578_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v578_4));
        drop(v578_4);
        let v578_8: Space = if (&(v578_5)).is_empty() { Space::new() } else {
          let v579_6: Path = concat_path(&(v577_6),&v575_15_cursor.path()[(v575_15_origin + 1)..(v575_15_origin + 2)]);
          let mut v579_7 = Space::new();
          let mut v579_7_write = v579_7.write_zipper();
          for v579_7_byte in v575_15_cursor.child_mask().iter() {
            v575_15_cursor.descend_to_existing_byte(v579_7_byte);
            {
            let v580_2: Space = singleton(&v575_15_cursor.path()[(v575_15_origin + 2)..(v575_15_origin + 3)]);
            let v580_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v580_2));
            let v580_4: Space = if map_kernels::has_head(&(v580_3)) { singleton(&[]) } else { Space::new() };
            drop(v580_3);
            let v580_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v580_4));
            drop(v580_4);
            let v580_8: Space = if (&(v580_5)).is_empty() { Space::new() } else {
              let v581_6: Path = concat_path(&(v579_6),&v575_15_cursor.path()[(v575_15_origin + 2)..(v575_15_origin + 3)]);
              let v581_7: Space = routine_42(c, &(v581_6), &(*p1), &v575_15_cursor);
              map_map_kernels::compose(&(v580_5),&(v581_7))
            };
            drop(v580_5);
            let v580_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v580_2));
            drop(v580_2);
            let v580_10: Space = if map_kernels::has_head(&(v580_9)) { singleton(&[]) } else { Space::new() };
            drop(v580_9);
            let v580_12: Space = if (&(v580_10)).is_empty() { Space::new() } else {
              let v582_6: Path = concat_path(&(v579_6),&v575_15_cursor.path()[(v575_15_origin + 2)..(v575_15_origin + 3)]);
              let v582_11: Space = routine_43(c, &(v582_6), &(*p1), &v575_15_cursor);
              drop(v582_6);
              map_map_kernels::compose(&(v580_10),&(v582_11))
            };
            drop(v580_10);
            let v580_13: Space = map_map_kernels::unite(&(v580_8),&(v580_12));
            join_wrapped_into(&mut v579_7_write,&((v580_13).read_zipper()),&[]);
            }
            v575_15_cursor.ascend(1);
          }
          drop(v579_7_write);
          map_map_kernels::compose(&(v578_5),&(v579_7))
        };
        drop(v578_5);
        let v578_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v578_2));
        drop(v578_2);
        let v578_10: Space = if map_kernels::has_head(&(v578_9)) { singleton(&[]) } else { Space::new() };
        drop(v578_9);
        let v578_12: Space = if (&(v578_10)).is_empty() { Space::new() } else {
          let v583_6: Path = concat_path(&(v577_6),&v575_15_cursor.path()[(v575_15_origin + 1)..(v575_15_origin + 2)]);
          let mut v583_11 = Space::new();
          let mut v583_11_write = v583_11.write_zipper();
          for v583_11_byte in v575_15_cursor.child_mask().iter() {
            v575_15_cursor.descend_to_existing_byte(v583_11_byte);
            {
            let v584_2: Space = singleton(&v575_15_cursor.path()[(v575_15_origin + 2)..(v575_15_origin + 3)]);
            let v584_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v584_2));
            let v584_4: Space = if map_kernels::has_head(&(v584_3)) { singleton(&[]) } else { Space::new() };
            drop(v584_3);
            let v584_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v584_4));
            drop(v584_4);
            let v584_8: Space = if (&(v584_5)).is_empty() { Space::new() } else {
              let v585_6: Path = concat_path(&(v583_6),&v575_15_cursor.path()[(v575_15_origin + 2)..(v575_15_origin + 3)]);
              let v585_7: Space = routine_42(c, &(v585_6), &(*p1), &v575_15_cursor);
              map_map_kernels::compose(&(v584_5),&(v585_7))
            };
            drop(v584_5);
            let v584_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v584_2));
            drop(v584_2);
            let v584_10: Space = if map_kernels::has_head(&(v584_9)) { singleton(&[]) } else { Space::new() };
            drop(v584_9);
            let v584_12: Space = if (&(v584_10)).is_empty() { Space::new() } else {
              let v586_6: Path = concat_path(&(v583_6),&v575_15_cursor.path()[(v575_15_origin + 2)..(v575_15_origin + 3)]);
              let v586_11: Space = routine_19(c, &(v586_6), &(*p1), &v575_15_cursor);
              drop(v586_6);
              map_map_kernels::compose(&(v584_10),&(v586_11))
            };
            drop(v584_10);
            let v584_13: Space = map_map_kernels::unite(&(v584_8),&(v584_12));
            join_wrapped_into(&mut v583_11_write,&((v584_13).read_zipper()),&[]);
            }
            v575_15_cursor.ascend(1);
          }
          drop(v583_11_write);
          drop(v583_6);
          map_map_kernels::compose(&(v578_10),&(v583_11))
        };
        drop(v578_10);
        let v578_13: Space = map_map_kernels::unite(&(v578_8),&(v578_12));
        join_wrapped_into(&mut v577_7_write,&((v578_13).read_zipper()),&[]);
        }
        v575_15_cursor.ascend(1);
      }
      drop(v577_7_write);
      map_map_kernels::compose(&(v576_5),&(v577_7))
    };
    drop(v576_5);
    let v576_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v576_2));
    drop(v576_2);
    let v576_10: Space = if map_kernels::has_head(&(v576_9)) { singleton(&[]) } else { Space::new() };
    drop(v576_9);
    let v576_11: Space = map_view_kernels::compose(&(v576_10),&v575_15_cursor);
    drop(v576_10);
    let v587_6: Path = concat_path(&(*p0),&v575_15_cursor.path()[v575_15_origin..(v575_15_origin + 1)]);
    let v576_12: Space = map_kernels::wrap(&(v576_11),&(v587_6));
    drop(v576_11);
    let v576_13: Space = map_kernels::wrap(&(v576_12),&(*p1));
    drop(v576_12);
    let v576_14: Space = map_map_kernels::unite(&(v576_8),&(v576_13));
    drop(v576_13);
    join_wrapped_into(&mut v575_15_write,&((v576_14).read_zipper()),&[]);
    }
    v575_15_cursor.ascend(1);
  }
  drop(v575_15_cursor);
  drop(v575_15_write);
  (v575_15).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v588_28 = Space::new();
  let mut v588_28_write = v588_28.write_zipper();
  let mut v588_28_cursor = (*s0).read_zipper();
  let v588_28_origin = v588_28_cursor.path().len();
  for v588_28_byte in v588_28_cursor.child_mask().iter() {
    v588_28_cursor.descend_to_existing_byte(v588_28_byte);
    {
    let v589_2: Space = singleton(&v588_28_cursor.path()[v588_28_origin..(v588_28_origin + 1)]);
    let v589_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v589_2));
    let v589_4: Space = if map_kernels::has_head(&(v589_3)) { singleton(&[]) } else { Space::new() };
    drop(v589_3);
    let v589_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v589_4));
    drop(v589_4);
    let v589_8: Space = if (&(v589_5)).is_empty() { Space::new() } else {
      let v590_6: Path = concat_path(&(*p0),&v588_28_cursor.path()[v588_28_origin..(v588_28_origin + 1)]);
      let mut v590_7 = Space::new();
      let mut v590_7_write = v590_7.write_zipper();
      for v590_7_byte in v588_28_cursor.child_mask().iter() {
        v588_28_cursor.descend_to_existing_byte(v590_7_byte);
        {
        let v591_2: Space = singleton(&v588_28_cursor.path()[(v588_28_origin + 1)..(v588_28_origin + 2)]);
        let v591_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v591_2));
        let v591_4: Space = if map_kernels::has_head(&(v591_3)) { singleton(&[]) } else { Space::new() };
        drop(v591_3);
        let v591_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v591_4));
        drop(v591_4);
        let v591_8: Space = if (&(v591_5)).is_empty() { Space::new() } else {
          let v592_6: Path = concat_path(&(v590_6),&v588_28_cursor.path()[(v588_28_origin + 1)..(v588_28_origin + 2)]);
          let mut v592_7 = Space::new();
          let mut v592_7_write = v592_7.write_zipper();
          for v592_7_byte in v588_28_cursor.child_mask().iter() {
            v588_28_cursor.descend_to_existing_byte(v592_7_byte);
            {
            let v593_2: Space = singleton(&v588_28_cursor.path()[(v588_28_origin + 2)..(v588_28_origin + 3)]);
            let v593_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v593_2));
            let v593_4: Space = if map_kernels::has_head(&(v593_3)) { singleton(&[]) } else { Space::new() };
            drop(v593_3);
            let v593_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v593_4));
            drop(v593_4);
            let v593_8: Space = if (&(v593_5)).is_empty() { Space::new() } else {
              let v594_6: Path = concat_path(&(v592_6),&v588_28_cursor.path()[(v588_28_origin + 2)..(v588_28_origin + 3)]);
              let v594_7: Space = routine_44(c, &(v594_6), &(*p1), &v588_28_cursor, &(*s1));
              map_map_kernels::compose(&(v593_5),&(v594_7))
            };
            drop(v593_5);
            let v593_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v593_2));
            drop(v593_2);
            let v593_10: Space = if map_kernels::has_head(&(v593_9)) { singleton(&[]) } else { Space::new() };
            drop(v593_9);
            let v593_12: Space = if (&(v593_10)).is_empty() { Space::new() } else {
              let v595_6: Path = concat_path(&(v592_6),&v588_28_cursor.path()[(v588_28_origin + 2)..(v588_28_origin + 3)]);
              let v595_11: Space = routine_45(c, &(v595_6), &(*p1), &v588_28_cursor, &(*s1));
              drop(v595_6);
              map_map_kernels::compose(&(v593_10),&(v595_11))
            };
            drop(v593_10);
            let v593_13: Space = map_map_kernels::unite(&(v593_8),&(v593_12));
            join_wrapped_into(&mut v592_7_write,&((v593_13).read_zipper()),&[]);
            }
            v588_28_cursor.ascend(1);
          }
          drop(v592_7_write);
          map_map_kernels::compose(&(v591_5),&(v592_7))
        };
        drop(v591_5);
        let v591_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v591_2));
        drop(v591_2);
        let v591_10: Space = if map_kernels::has_head(&(v591_9)) { singleton(&[]) } else { Space::new() };
        drop(v591_9);
        let v591_12: Space = if (&(v591_10)).is_empty() { Space::new() } else {
          let v596_6: Path = concat_path(&(v590_6),&v588_28_cursor.path()[(v588_28_origin + 1)..(v588_28_origin + 2)]);
          let mut v596_11 = Space::new();
          let mut v596_11_write = v596_11.write_zipper();
          for v596_11_byte in v588_28_cursor.child_mask().iter() {
            v588_28_cursor.descend_to_existing_byte(v596_11_byte);
            {
            let v597_2: Space = singleton(&v588_28_cursor.path()[(v588_28_origin + 2)..(v588_28_origin + 3)]);
            let v597_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v597_2));
            let v597_4: Space = if map_kernels::has_head(&(v597_3)) { singleton(&[]) } else { Space::new() };
            drop(v597_3);
            let v597_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v597_4));
            drop(v597_4);
            let v597_8: Space = if (&(v597_5)).is_empty() { Space::new() } else {
              let v598_6: Path = concat_path(&(v596_6),&v588_28_cursor.path()[(v588_28_origin + 2)..(v588_28_origin + 3)]);
              let v598_7: Space = routine_44(c, &(v598_6), &(*p1), &v588_28_cursor, &(*s1));
              map_map_kernels::compose(&(v597_5),&(v598_7))
            };
            drop(v597_5);
            let v597_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v597_2));
            drop(v597_2);
            let v597_10: Space = if map_kernels::has_head(&(v597_9)) { singleton(&[]) } else { Space::new() };
            drop(v597_9);
            let v597_12: Space = if (&(v597_10)).is_empty() { Space::new() } else {
              let v599_6: Path = concat_path(&(v596_6),&v588_28_cursor.path()[(v588_28_origin + 2)..(v588_28_origin + 3)]);
              let v599_11: Space = routine_10(c, &(v599_6), &(*p1), &v588_28_cursor, &(*s1));
              drop(v599_6);
              map_map_kernels::compose(&(v597_10),&(v599_11))
            };
            drop(v597_10);
            let v597_13: Space = map_map_kernels::unite(&(v597_8),&(v597_12));
            join_wrapped_into(&mut v596_11_write,&((v597_13).read_zipper()),&[]);
            }
            v588_28_cursor.ascend(1);
          }
          drop(v596_11_write);
          drop(v596_6);
          map_map_kernels::compose(&(v591_10),&(v596_11))
        };
        drop(v591_10);
        let v591_13: Space = map_map_kernels::unite(&(v591_8),&(v591_12));
        join_wrapped_into(&mut v590_7_write,&((v591_13).read_zipper()),&[]);
        }
        v588_28_cursor.ascend(1);
      }
      drop(v590_7_write);
      map_map_kernels::compose(&(v589_5),&(v590_7))
    };
    drop(v589_5);
    let v589_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v589_2));
    drop(v589_2);
    let v589_10: Space = if map_kernels::has_head(&(v589_9)) { singleton(&[]) } else { Space::new() };
    drop(v589_9);
    let v589_13: Space = if (&(v589_10)).is_empty() { Space::new() } else {
      let v600_6: Path = concat_path(&(*p0),&v588_28_cursor.path()[v588_28_origin..(v588_28_origin + 1)]);
      let mut v600_12 = Space::new();
      let mut v600_12_write = v600_12.write_zipper();
      for v600_12_byte in v588_28_cursor.child_mask().iter() {
        v588_28_cursor.descend_to_existing_byte(v600_12_byte);
        {
        let v601_2: Space = singleton(&v588_28_cursor.path()[(v588_28_origin + 1)..(v588_28_origin + 2)]);
        let v601_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v601_2));
        let v601_4: Space = if map_kernels::has_head(&(v601_3)) { singleton(&[]) } else { Space::new() };
        drop(v601_3);
        let v601_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v601_4));
        drop(v601_4);
        let v601_8: Space = if (&(v601_5)).is_empty() { Space::new() } else {
          let v602_6: Path = concat_path(&(v600_6),&v588_28_cursor.path()[(v588_28_origin + 1)..(v588_28_origin + 2)]);
          let mut v602_7 = Space::new();
          let mut v602_7_write = v602_7.write_zipper();
          for v602_7_byte in v588_28_cursor.child_mask().iter() {
            v588_28_cursor.descend_to_existing_byte(v602_7_byte);
            {
            let v603_2: Space = singleton(&v588_28_cursor.path()[(v588_28_origin + 2)..(v588_28_origin + 3)]);
            let v603_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v603_2));
            let v603_4: Space = if map_kernels::has_head(&(v603_3)) { singleton(&[]) } else { Space::new() };
            drop(v603_3);
            let v603_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v603_4));
            drop(v603_4);
            let v603_8: Space = if (&(v603_5)).is_empty() { Space::new() } else {
              let v604_6: Path = concat_path(&(v602_6),&v588_28_cursor.path()[(v588_28_origin + 2)..(v588_28_origin + 3)]);
              let v604_7: Space = routine_44(c, &(v604_6), &(*p1), &v588_28_cursor, &(*s1));
              map_map_kernels::compose(&(v603_5),&(v604_7))
            };
            drop(v603_5);
            let v603_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v603_2));
            drop(v603_2);
            let v603_10: Space = if map_kernels::has_head(&(v603_9)) { singleton(&[]) } else { Space::new() };
            drop(v603_9);
            let v603_12: Space = if (&(v603_10)).is_empty() { Space::new() } else {
              let v605_6: Path = concat_path(&(v602_6),&v588_28_cursor.path()[(v588_28_origin + 2)..(v588_28_origin + 3)]);
              let v605_11: Space = routine_45(c, &(v605_6), &(*p1), &v588_28_cursor, &(*s1));
              drop(v605_6);
              map_map_kernels::compose(&(v603_10),&(v605_11))
            };
            drop(v603_10);
            let v603_13: Space = map_map_kernels::unite(&(v603_8),&(v603_12));
            join_wrapped_into(&mut v602_7_write,&((v603_13).read_zipper()),&[]);
            }
            v588_28_cursor.ascend(1);
          }
          drop(v602_7_write);
          drop(v602_6);
          map_map_kernels::compose(&(v601_5),&(v602_7))
        };
        drop(v601_5);
        let v601_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v601_2));
        drop(v601_2);
        let v601_10: Space = if map_kernels::has_head(&(v601_9)) { singleton(&[]) } else { Space::new() };
        drop(v601_9);
        let v601_13: Space = if (&(v601_10)).is_empty() { Space::new() } else {
          let mut v606_12 = Space::new();
          let mut v606_12_write = v606_12.write_zipper();
          let mut v606_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v588_28_cursor.path()[v588_28_origin..(v588_28_origin + 1)]),&v588_28_cursor.path()[(v588_28_origin + 1)..(v588_28_origin + 2)]);
          let v606_12_origin = v606_12_cursor.path().len();
          for v606_12_byte in v606_12_cursor.child_mask().iter() {
            v606_12_cursor.descend_to_existing_byte(v606_12_byte);
            {
            let v607_2: Space = singleton(&v606_12_cursor.path()[v606_12_origin..(v606_12_origin + 1)]);
            let v607_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v607_2));
            let v607_4: Space = if map_kernels::has_head(&(v607_3)) { singleton(&[]) } else { Space::new() };
            drop(v607_3);
            let v607_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v607_4));
            drop(v607_4);
            let v607_7: Space = if (&(v607_5)).is_empty() { Space::new() } else {
              let v608_6: Space = routine_13(c, &v606_12_cursor.path()[v606_12_origin..(v606_12_origin + 1)], &(*p1), &v606_12_cursor);
              map_map_kernels::compose(&(v607_5),&(v608_6))
            };
            drop(v607_5);
            let v607_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v607_2));
            drop(v607_2);
            let v607_9: Space = if map_kernels::has_head(&(v607_8)) { singleton(&[]) } else { Space::new() };
            drop(v607_8);
            let v607_11: Space = if (&(v607_9)).is_empty() { Space::new() } else {
              let v609_10: Space = routine_14(c, &v606_12_cursor.path()[v606_12_origin..(v606_12_origin + 1)], &(*p1), &v606_12_cursor);
              map_map_kernels::compose(&(v607_9),&(v609_10))
            };
            drop(v607_9);
            let v607_12: Space = map_map_kernels::unite(&(v607_7),&(v607_11));
            join_wrapped_into(&mut v606_12_write,&((v607_12).read_zipper()),&[]);
            }
            v606_12_cursor.ascend(1);
          }
          drop(v606_12_cursor);
          drop(v606_12_write);
          map_map_kernels::compose(&(v601_10),&(v606_12))
        };
        drop(v601_10);
        let v601_14: Space = map_map_kernels::unite(&(v601_8),&(v601_13));
        join_wrapped_into(&mut v600_12_write,&((v601_14).read_zipper()),&[]);
        }
        v588_28_cursor.ascend(1);
      }
      drop(v600_12_write);
      drop(v600_6);
      map_map_kernels::compose(&(v589_10),&(v600_12))
    };
    drop(v589_10);
    let v589_14: Space = map_map_kernels::unite(&(v589_8),&(v589_13));
    join_wrapped_into(&mut v588_28_write,&((v589_14).read_zipper()),&[]);
    }
    v588_28_cursor.ascend(1);
  }
  drop(v588_28_cursor);
  drop(v588_28_write);
  (v588_28).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v610_28 = Space::new();
  let mut v610_28_write = v610_28.write_zipper();
  let mut v610_28_cursor = (*s0).read_zipper();
  let v610_28_origin = v610_28_cursor.path().len();
  for v610_28_byte in v610_28_cursor.child_mask().iter() {
    v610_28_cursor.descend_to_existing_byte(v610_28_byte);
    {
    let v611_2: Space = singleton(&v610_28_cursor.path()[v610_28_origin..(v610_28_origin + 1)]);
    let v611_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v611_2));
    let v611_4: Space = if map_kernels::has_head(&(v611_3)) { singleton(&[]) } else { Space::new() };
    drop(v611_3);
    let v611_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v611_4));
    drop(v611_4);
    let v611_8: Space = if (&(v611_5)).is_empty() { Space::new() } else {
      let v612_6: Path = concat_path(&(*p0),&v610_28_cursor.path()[v610_28_origin..(v610_28_origin + 1)]);
      let mut v612_7 = Space::new();
      let mut v612_7_write = v612_7.write_zipper();
      for v612_7_byte in v610_28_cursor.child_mask().iter() {
        v610_28_cursor.descend_to_existing_byte(v612_7_byte);
        {
        let v613_2: Space = singleton(&v610_28_cursor.path()[(v610_28_origin + 1)..(v610_28_origin + 2)]);
        let v613_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v613_2));
        let v613_4: Space = if map_kernels::has_head(&(v613_3)) { singleton(&[]) } else { Space::new() };
        drop(v613_3);
        let v613_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v613_4));
        drop(v613_4);
        let v613_8: Space = if (&(v613_5)).is_empty() { Space::new() } else {
          let v614_6: Path = concat_path(&(v612_6),&v610_28_cursor.path()[(v610_28_origin + 1)..(v610_28_origin + 2)]);
          let mut v614_7 = Space::new();
          let mut v614_7_write = v614_7.write_zipper();
          for v614_7_byte in v610_28_cursor.child_mask().iter() {
            v610_28_cursor.descend_to_existing_byte(v614_7_byte);
            {
            let v615_2: Space = singleton(&v610_28_cursor.path()[(v610_28_origin + 2)..(v610_28_origin + 3)]);
            let v615_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v615_2));
            let v615_4: Space = if map_kernels::has_head(&(v615_3)) { singleton(&[]) } else { Space::new() };
            drop(v615_3);
            let v615_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v615_4));
            drop(v615_4);
            let v615_8: Space = if (&(v615_5)).is_empty() { Space::new() } else {
              let v616_6: Path = concat_path(&(v614_6),&v610_28_cursor.path()[(v610_28_origin + 2)..(v610_28_origin + 3)]);
              let v616_7: Space = routine_44(c, &(v616_6), &(*p1), &v610_28_cursor, &(*s1));
              map_map_kernels::compose(&(v615_5),&(v616_7))
            };
            drop(v615_5);
            let v615_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v615_2));
            drop(v615_2);
            let v615_10: Space = if map_kernels::has_head(&(v615_9)) { singleton(&[]) } else { Space::new() };
            drop(v615_9);
            let v615_12: Space = if (&(v615_10)).is_empty() { Space::new() } else {
              let v617_6: Path = concat_path(&(v614_6),&v610_28_cursor.path()[(v610_28_origin + 2)..(v610_28_origin + 3)]);
              let v617_11: Space = routine_45(c, &(v617_6), &(*p1), &v610_28_cursor, &(*s1));
              drop(v617_6);
              map_map_kernels::compose(&(v615_10),&(v617_11))
            };
            drop(v615_10);
            let v615_13: Space = map_map_kernels::unite(&(v615_8),&(v615_12));
            join_wrapped_into(&mut v614_7_write,&((v615_13).read_zipper()),&[]);
            }
            v610_28_cursor.ascend(1);
          }
          drop(v614_7_write);
          map_map_kernels::compose(&(v613_5),&(v614_7))
        };
        drop(v613_5);
        let v613_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v613_2));
        drop(v613_2);
        let v613_10: Space = if map_kernels::has_head(&(v613_9)) { singleton(&[]) } else { Space::new() };
        drop(v613_9);
        let v613_12: Space = if (&(v613_10)).is_empty() { Space::new() } else {
          let v618_6: Path = concat_path(&(v612_6),&v610_28_cursor.path()[(v610_28_origin + 1)..(v610_28_origin + 2)]);
          let mut v618_11 = Space::new();
          let mut v618_11_write = v618_11.write_zipper();
          for v618_11_byte in v610_28_cursor.child_mask().iter() {
            v610_28_cursor.descend_to_existing_byte(v618_11_byte);
            {
            let v619_2: Space = singleton(&v610_28_cursor.path()[(v610_28_origin + 2)..(v610_28_origin + 3)]);
            let v619_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v619_2));
            let v619_4: Space = if map_kernels::has_head(&(v619_3)) { singleton(&[]) } else { Space::new() };
            drop(v619_3);
            let v619_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v619_4));
            drop(v619_4);
            let v619_8: Space = if (&(v619_5)).is_empty() { Space::new() } else {
              let v620_6: Path = concat_path(&(v618_6),&v610_28_cursor.path()[(v610_28_origin + 2)..(v610_28_origin + 3)]);
              let v620_7: Space = routine_44(c, &(v620_6), &(*p1), &v610_28_cursor, &(*s1));
              map_map_kernels::compose(&(v619_5),&(v620_7))
            };
            drop(v619_5);
            let v619_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v619_2));
            drop(v619_2);
            let v619_10: Space = if map_kernels::has_head(&(v619_9)) { singleton(&[]) } else { Space::new() };
            drop(v619_9);
            let v619_12: Space = if (&(v619_10)).is_empty() { Space::new() } else {
              let v621_6: Path = concat_path(&(v618_6),&v610_28_cursor.path()[(v610_28_origin + 2)..(v610_28_origin + 3)]);
              let v621_11: Space = routine_10(c, &(v621_6), &(*p1), &v610_28_cursor, &(*s1));
              drop(v621_6);
              map_map_kernels::compose(&(v619_10),&(v621_11))
            };
            drop(v619_10);
            let v619_13: Space = map_map_kernels::unite(&(v619_8),&(v619_12));
            join_wrapped_into(&mut v618_11_write,&((v619_13).read_zipper()),&[]);
            }
            v610_28_cursor.ascend(1);
          }
          drop(v618_11_write);
          drop(v618_6);
          map_map_kernels::compose(&(v613_10),&(v618_11))
        };
        drop(v613_10);
        let v613_13: Space = map_map_kernels::unite(&(v613_8),&(v613_12));
        join_wrapped_into(&mut v612_7_write,&((v613_13).read_zipper()),&[]);
        }
        v610_28_cursor.ascend(1);
      }
      drop(v612_7_write);
      drop(v612_6);
      map_map_kernels::compose(&(v611_5),&(v612_7))
    };
    drop(v611_5);
    let v611_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v611_2));
    drop(v611_2);
    let v611_10: Space = if map_kernels::has_head(&(v611_9)) { singleton(&[]) } else { Space::new() };
    drop(v611_9);
    let v611_13: Space = if (&(v611_10)).is_empty() { Space::new() } else {
      let mut v622_12 = Space::new();
      let mut v622_12_write = v622_12.write_zipper();
      let mut v622_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v610_28_cursor.path()[v610_28_origin..(v610_28_origin + 1)]);
      let v622_12_origin = v622_12_cursor.path().len();
      for v622_12_byte in v622_12_cursor.child_mask().iter() {
        v622_12_cursor.descend_to_existing_byte(v622_12_byte);
        {
        let v623_2: Space = singleton(&v622_12_cursor.path()[v622_12_origin..(v622_12_origin + 1)]);
        let v623_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v623_2));
        let v623_4: Space = if map_kernels::has_head(&(v623_3)) { singleton(&[]) } else { Space::new() };
        drop(v623_3);
        let v623_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v623_4));
        drop(v623_4);
        let v623_7: Space = if (&(v623_5)).is_empty() { Space::new() } else {
          let mut v624_6 = Space::new();
          let mut v624_6_write = v624_6.write_zipper();
          for v624_6_byte in v622_12_cursor.child_mask().iter() {
            v622_12_cursor.descend_to_existing_byte(v624_6_byte);
            {
            let v625_2: Space = singleton(&v622_12_cursor.path()[(v622_12_origin + 1)..(v622_12_origin + 2)]);
            let v625_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v625_2));
            let v625_4: Space = if map_kernels::has_head(&(v625_3)) { singleton(&[]) } else { Space::new() };
            drop(v625_3);
            let v625_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v625_4));
            drop(v625_4);
            let v625_8: Space = if (&(v625_5)).is_empty() { Space::new() } else {
              let v626_7: Space = routine_17(c, &v622_12_cursor.path()[v622_12_origin..(v622_12_origin + 2)], &(*p1), &v622_12_cursor);
              map_map_kernels::compose(&(v625_5),&(v626_7))
            };
            drop(v625_5);
            let v625_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v625_2));
            drop(v625_2);
            let v625_10: Space = if map_kernels::has_head(&(v625_9)) { singleton(&[]) } else { Space::new() };
            drop(v625_9);
            let v625_12: Space = if (&(v625_10)).is_empty() { Space::new() } else {
              let v627_11: Space = routine_18(c, &v622_12_cursor.path()[v622_12_origin..(v622_12_origin + 2)], &(*p1), &v622_12_cursor);
              map_map_kernels::compose(&(v625_10),&(v627_11))
            };
            drop(v625_10);
            let v625_13: Space = map_map_kernels::unite(&(v625_8),&(v625_12));
            join_wrapped_into(&mut v624_6_write,&((v625_13).read_zipper()),&[]);
            }
            v622_12_cursor.ascend(1);
          }
          drop(v624_6_write);
          map_map_kernels::compose(&(v623_5),&(v624_6))
        };
        drop(v623_5);
        let v623_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v623_2));
        drop(v623_2);
        let v623_9: Space = if map_kernels::has_head(&(v623_8)) { singleton(&[]) } else { Space::new() };
        drop(v623_8);
        let v623_11: Space = if (&(v623_9)).is_empty() { Space::new() } else {
          let mut v628_10 = Space::new();
          let mut v628_10_write = v628_10.write_zipper();
          for v628_10_byte in v622_12_cursor.child_mask().iter() {
            v622_12_cursor.descend_to_existing_byte(v628_10_byte);
            {
            let v629_2: Space = singleton(&v622_12_cursor.path()[(v622_12_origin + 1)..(v622_12_origin + 2)]);
            let v629_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v629_2));
            let v629_4: Space = if map_kernels::has_head(&(v629_3)) { singleton(&[]) } else { Space::new() };
            drop(v629_3);
            let v629_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v629_4));
            drop(v629_4);
            let v629_8: Space = if (&(v629_5)).is_empty() { Space::new() } else {
              let v630_7: Space = routine_17(c, &v622_12_cursor.path()[v622_12_origin..(v622_12_origin + 2)], &(*p1), &v622_12_cursor);
              map_map_kernels::compose(&(v629_5),&(v630_7))
            };
            drop(v629_5);
            let v629_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v629_2));
            drop(v629_2);
            let v629_10: Space = if map_kernels::has_head(&(v629_9)) { singleton(&[]) } else { Space::new() };
            drop(v629_9);
            let v629_12: Space = if (&(v629_10)).is_empty() { Space::new() } else {
              let v631_11: Space = routine_19(c, &v622_12_cursor.path()[v622_12_origin..(v622_12_origin + 2)], &(*p1), &v622_12_cursor);
              map_map_kernels::compose(&(v629_10),&(v631_11))
            };
            drop(v629_10);
            let v629_13: Space = map_map_kernels::unite(&(v629_8),&(v629_12));
            join_wrapped_into(&mut v628_10_write,&((v629_13).read_zipper()),&[]);
            }
            v622_12_cursor.ascend(1);
          }
          drop(v628_10_write);
          map_map_kernels::compose(&(v623_9),&(v628_10))
        };
        drop(v623_9);
        let v623_12: Space = map_map_kernels::unite(&(v623_7),&(v623_11));
        join_wrapped_into(&mut v622_12_write,&((v623_12).read_zipper()),&[]);
        }
        v622_12_cursor.ascend(1);
      }
      drop(v622_12_cursor);
      drop(v622_12_write);
      map_map_kernels::compose(&(v611_10),&(v622_12))
    };
    drop(v611_10);
    let v611_14: Space = map_map_kernels::unite(&(v611_8),&(v611_13));
    join_wrapped_into(&mut v610_28_write,&((v611_14).read_zipper()),&[]);
    }
    v610_28_cursor.ascend(1);
  }
  drop(v610_28_cursor);
  drop(v610_28_write);
  (v610_28).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v632_21 = Space::new();
  let mut v632_21_write = v632_21.write_zipper();
  let mut v632_21_cursor = (*s0).read_zipper();
  let v632_21_origin = v632_21_cursor.path().len();
  for v632_21_byte in v632_21_cursor.child_mask().iter() {
    v632_21_cursor.descend_to_existing_byte(v632_21_byte);
    {
    let v633_2: Space = singleton(&v632_21_cursor.path()[v632_21_origin..(v632_21_origin + 1)]);
    let v633_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v633_2));
    let v633_4: Space = if map_kernels::has_head(&(v633_3)) { singleton(&[]) } else { Space::new() };
    drop(v633_3);
    let v633_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v633_4));
    drop(v633_4);
    let v633_8: Space = if (&(v633_5)).is_empty() { Space::new() } else {
      let v634_6: Path = concat_path(&(*p0),&v632_21_cursor.path()[v632_21_origin..(v632_21_origin + 1)]);
      let mut v634_7 = Space::new();
      let mut v634_7_write = v634_7.write_zipper();
      for v634_7_byte in v632_21_cursor.child_mask().iter() {
        v632_21_cursor.descend_to_existing_byte(v634_7_byte);
        {
        let v635_2: Space = singleton(&v632_21_cursor.path()[(v632_21_origin + 1)..(v632_21_origin + 2)]);
        let v635_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v635_2));
        let v635_4: Space = if map_kernels::has_head(&(v635_3)) { singleton(&[]) } else { Space::new() };
        drop(v635_3);
        let v635_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v635_4));
        drop(v635_4);
        let v635_8: Space = if (&(v635_5)).is_empty() { Space::new() } else {
          let v636_6: Path = concat_path(&(v634_6),&v632_21_cursor.path()[(v632_21_origin + 1)..(v632_21_origin + 2)]);
          let mut v636_7 = Space::new();
          let mut v636_7_write = v636_7.write_zipper();
          for v636_7_byte in v632_21_cursor.child_mask().iter() {
            v632_21_cursor.descend_to_existing_byte(v636_7_byte);
            {
            let v637_2: Space = singleton(&v632_21_cursor.path()[(v632_21_origin + 2)..(v632_21_origin + 3)]);
            let v637_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v637_2));
            let v637_4: Space = if map_kernels::has_head(&(v637_3)) { singleton(&[]) } else { Space::new() };
            drop(v637_3);
            let v637_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v637_4));
            drop(v637_4);
            let v637_8: Space = if (&(v637_5)).is_empty() { Space::new() } else {
              let v638_6: Path = concat_path(&(v636_6),&v632_21_cursor.path()[(v632_21_origin + 2)..(v632_21_origin + 3)]);
              let v638_7: Space = routine_46(c, &(v638_6), &(*p1), &v632_21_cursor);
              map_map_kernels::compose(&(v637_5),&(v638_7))
            };
            drop(v637_5);
            let v637_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v637_2));
            drop(v637_2);
            let v637_10: Space = if map_kernels::has_head(&(v637_9)) { singleton(&[]) } else { Space::new() };
            drop(v637_9);
            let v637_12: Space = if (&(v637_10)).is_empty() { Space::new() } else {
              let v639_6: Path = concat_path(&(v636_6),&v632_21_cursor.path()[(v632_21_origin + 2)..(v632_21_origin + 3)]);
              let v639_11: Space = routine_47(c, &(v639_6), &(*p1), &v632_21_cursor);
              drop(v639_6);
              map_map_kernels::compose(&(v637_10),&(v639_11))
            };
            drop(v637_10);
            let v637_13: Space = map_map_kernels::unite(&(v637_8),&(v637_12));
            join_wrapped_into(&mut v636_7_write,&((v637_13).read_zipper()),&[]);
            }
            v632_21_cursor.ascend(1);
          }
          drop(v636_7_write);
          map_map_kernels::compose(&(v635_5),&(v636_7))
        };
        drop(v635_5);
        let v635_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v635_2));
        drop(v635_2);
        let v635_10: Space = if map_kernels::has_head(&(v635_9)) { singleton(&[]) } else { Space::new() };
        drop(v635_9);
        let v635_12: Space = if (&(v635_10)).is_empty() { Space::new() } else {
          let v640_6: Path = concat_path(&(v634_6),&v632_21_cursor.path()[(v632_21_origin + 1)..(v632_21_origin + 2)]);
          let mut v640_11 = Space::new();
          let mut v640_11_write = v640_11.write_zipper();
          for v640_11_byte in v632_21_cursor.child_mask().iter() {
            v632_21_cursor.descend_to_existing_byte(v640_11_byte);
            {
            let v641_2: Space = singleton(&v632_21_cursor.path()[(v632_21_origin + 2)..(v632_21_origin + 3)]);
            let v641_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v641_2));
            let v641_4: Space = if map_kernels::has_head(&(v641_3)) { singleton(&[]) } else { Space::new() };
            drop(v641_3);
            let v641_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v641_4));
            drop(v641_4);
            let v641_8: Space = if (&(v641_5)).is_empty() { Space::new() } else {
              let v642_6: Path = concat_path(&(v640_6),&v632_21_cursor.path()[(v632_21_origin + 2)..(v632_21_origin + 3)]);
              let v642_7: Space = routine_46(c, &(v642_6), &(*p1), &v632_21_cursor);
              map_map_kernels::compose(&(v641_5),&(v642_7))
            };
            drop(v641_5);
            let v641_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v641_2));
            drop(v641_2);
            let v641_10: Space = if map_kernels::has_head(&(v641_9)) { singleton(&[]) } else { Space::new() };
            drop(v641_9);
            let v641_12: Space = if (&(v641_10)).is_empty() { Space::new() } else {
              let v643_6: Path = concat_path(&(v640_6),&v632_21_cursor.path()[(v632_21_origin + 2)..(v632_21_origin + 3)]);
              let v643_11: Space = routine_19(c, &(v643_6), &(*p1), &v632_21_cursor);
              drop(v643_6);
              map_map_kernels::compose(&(v641_10),&(v643_11))
            };
            drop(v641_10);
            let v641_13: Space = map_map_kernels::unite(&(v641_8),&(v641_12));
            join_wrapped_into(&mut v640_11_write,&((v641_13).read_zipper()),&[]);
            }
            v632_21_cursor.ascend(1);
          }
          drop(v640_11_write);
          drop(v640_6);
          map_map_kernels::compose(&(v635_10),&(v640_11))
        };
        drop(v635_10);
        let v635_13: Space = map_map_kernels::unite(&(v635_8),&(v635_12));
        join_wrapped_into(&mut v634_7_write,&((v635_13).read_zipper()),&[]);
        }
        v632_21_cursor.ascend(1);
      }
      drop(v634_7_write);
      map_map_kernels::compose(&(v633_5),&(v634_7))
    };
    drop(v633_5);
    let v633_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v633_2));
    drop(v633_2);
    let v633_10: Space = if map_kernels::has_head(&(v633_9)) { singleton(&[]) } else { Space::new() };
    drop(v633_9);
    let v633_12: Space = if (&(v633_10)).is_empty() { Space::new() } else {
      let v644_6: Path = concat_path(&(*p0),&v632_21_cursor.path()[v632_21_origin..(v632_21_origin + 1)]);
      let mut v644_11 = Space::new();
      let mut v644_11_write = v644_11.write_zipper();
      for v644_11_byte in v632_21_cursor.child_mask().iter() {
        v632_21_cursor.descend_to_existing_byte(v644_11_byte);
        {
        let v645_2: Space = singleton(&v632_21_cursor.path()[(v632_21_origin + 1)..(v632_21_origin + 2)]);
        let v645_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v645_2));
        let v645_4: Space = if map_kernels::has_head(&(v645_3)) { singleton(&[]) } else { Space::new() };
        drop(v645_3);
        let v645_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v645_4));
        drop(v645_4);
        let v645_8: Space = if (&(v645_5)).is_empty() { Space::new() } else {
          let v646_6: Path = concat_path(&(v644_6),&v632_21_cursor.path()[(v632_21_origin + 1)..(v632_21_origin + 2)]);
          let mut v646_7 = Space::new();
          let mut v646_7_write = v646_7.write_zipper();
          for v646_7_byte in v632_21_cursor.child_mask().iter() {
            v632_21_cursor.descend_to_existing_byte(v646_7_byte);
            {
            let v647_2: Space = singleton(&v632_21_cursor.path()[(v632_21_origin + 2)..(v632_21_origin + 3)]);
            let v647_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v647_2));
            let v647_4: Space = if map_kernels::has_head(&(v647_3)) { singleton(&[]) } else { Space::new() };
            drop(v647_3);
            let v647_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v647_4));
            drop(v647_4);
            let v647_8: Space = if (&(v647_5)).is_empty() { Space::new() } else {
              let v648_6: Path = concat_path(&(v646_6),&v632_21_cursor.path()[(v632_21_origin + 2)..(v632_21_origin + 3)]);
              let v648_7: Space = routine_46(c, &(v648_6), &(*p1), &v632_21_cursor);
              map_map_kernels::compose(&(v647_5),&(v648_7))
            };
            drop(v647_5);
            let v647_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v647_2));
            drop(v647_2);
            let v647_10: Space = if map_kernels::has_head(&(v647_9)) { singleton(&[]) } else { Space::new() };
            drop(v647_9);
            let v647_12: Space = if (&(v647_10)).is_empty() { Space::new() } else {
              let v649_6: Path = concat_path(&(v646_6),&v632_21_cursor.path()[(v632_21_origin + 2)..(v632_21_origin + 3)]);
              let v649_11: Space = routine_47(c, &(v649_6), &(*p1), &v632_21_cursor);
              drop(v649_6);
              map_map_kernels::compose(&(v647_10),&(v649_11))
            };
            drop(v647_10);
            let v647_13: Space = map_map_kernels::unite(&(v647_8),&(v647_12));
            join_wrapped_into(&mut v646_7_write,&((v647_13).read_zipper()),&[]);
            }
            v632_21_cursor.ascend(1);
          }
          drop(v646_7_write);
          map_map_kernels::compose(&(v645_5),&(v646_7))
        };
        drop(v645_5);
        let v645_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v645_2));
        drop(v645_2);
        let v645_10: Space = if map_kernels::has_head(&(v645_9)) { singleton(&[]) } else { Space::new() };
        drop(v645_9);
        let v645_11: Space = map_view_kernels::compose(&(v645_10),&v632_21_cursor);
        drop(v645_10);
        let v650_6: Path = concat_path(&(v644_6),&v632_21_cursor.path()[(v632_21_origin + 1)..(v632_21_origin + 2)]);
        let v645_12: Space = map_kernels::wrap(&(v645_11),&(v650_6));
        drop(v645_11);
        let v645_13: Space = map_kernels::wrap(&(v645_12),&(*p1));
        drop(v645_12);
        let v645_14: Space = map_map_kernels::unite(&(v645_8),&(v645_13));
        drop(v645_13);
        join_wrapped_into(&mut v644_11_write,&((v645_14).read_zipper()),&[]);
        }
        v632_21_cursor.ascend(1);
      }
      drop(v644_11_write);
      drop(v644_6);
      map_map_kernels::compose(&(v633_10),&(v644_11))
    };
    drop(v633_10);
    let v633_13: Space = map_map_kernels::unite(&(v633_8),&(v633_12));
    join_wrapped_into(&mut v632_21_write,&((v633_13).read_zipper()),&[]);
    }
    v632_21_cursor.ascend(1);
  }
  drop(v632_21_cursor);
  drop(v632_21_write);
  (v632_21).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v651_15 = Space::new();
  let mut v651_15_write = v651_15.write_zipper();
  let mut v651_15_cursor = (*s0).read_zipper();
  let v651_15_origin = v651_15_cursor.path().len();
  for v651_15_byte in v651_15_cursor.child_mask().iter() {
    v651_15_cursor.descend_to_existing_byte(v651_15_byte);
    {
    let v652_2: Space = singleton(&v651_15_cursor.path()[v651_15_origin..(v651_15_origin + 1)]);
    let v652_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v652_2));
    let v652_4: Space = if map_kernels::has_head(&(v652_3)) { singleton(&[]) } else { Space::new() };
    drop(v652_3);
    let v652_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v652_4));
    drop(v652_4);
    let v652_8: Space = if (&(v652_5)).is_empty() { Space::new() } else {
      let v653_6: Path = concat_path(&(*p0),&v651_15_cursor.path()[v651_15_origin..(v651_15_origin + 1)]);
      let mut v653_7 = Space::new();
      let mut v653_7_write = v653_7.write_zipper();
      for v653_7_byte in v651_15_cursor.child_mask().iter() {
        v651_15_cursor.descend_to_existing_byte(v653_7_byte);
        {
        let v654_2: Space = singleton(&v651_15_cursor.path()[(v651_15_origin + 1)..(v651_15_origin + 2)]);
        let v654_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v654_2));
        let v654_4: Space = if map_kernels::has_head(&(v654_3)) { singleton(&[]) } else { Space::new() };
        drop(v654_3);
        let v654_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v654_4));
        drop(v654_4);
        let v654_8: Space = if (&(v654_5)).is_empty() { Space::new() } else {
          let v655_6: Path = concat_path(&(v653_6),&v651_15_cursor.path()[(v651_15_origin + 1)..(v651_15_origin + 2)]);
          let mut v655_7 = Space::new();
          let mut v655_7_write = v655_7.write_zipper();
          for v655_7_byte in v651_15_cursor.child_mask().iter() {
            v651_15_cursor.descend_to_existing_byte(v655_7_byte);
            {
            let v656_2: Space = singleton(&v651_15_cursor.path()[(v651_15_origin + 2)..(v651_15_origin + 3)]);
            let v656_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v656_2));
            let v656_4: Space = if map_kernels::has_head(&(v656_3)) { singleton(&[]) } else { Space::new() };
            drop(v656_3);
            let v656_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v656_4));
            drop(v656_4);
            let v656_8: Space = if (&(v656_5)).is_empty() { Space::new() } else {
              let v657_6: Path = concat_path(&(v655_6),&v651_15_cursor.path()[(v651_15_origin + 2)..(v651_15_origin + 3)]);
              let v657_7: Space = routine_46(c, &(v657_6), &(*p1), &v651_15_cursor);
              map_map_kernels::compose(&(v656_5),&(v657_7))
            };
            drop(v656_5);
            let v656_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v656_2));
            drop(v656_2);
            let v656_10: Space = if map_kernels::has_head(&(v656_9)) { singleton(&[]) } else { Space::new() };
            drop(v656_9);
            let v656_12: Space = if (&(v656_10)).is_empty() { Space::new() } else {
              let v658_6: Path = concat_path(&(v655_6),&v651_15_cursor.path()[(v651_15_origin + 2)..(v651_15_origin + 3)]);
              let v658_11: Space = routine_47(c, &(v658_6), &(*p1), &v651_15_cursor);
              drop(v658_6);
              map_map_kernels::compose(&(v656_10),&(v658_11))
            };
            drop(v656_10);
            let v656_13: Space = map_map_kernels::unite(&(v656_8),&(v656_12));
            join_wrapped_into(&mut v655_7_write,&((v656_13).read_zipper()),&[]);
            }
            v651_15_cursor.ascend(1);
          }
          drop(v655_7_write);
          map_map_kernels::compose(&(v654_5),&(v655_7))
        };
        drop(v654_5);
        let v654_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v654_2));
        drop(v654_2);
        let v654_10: Space = if map_kernels::has_head(&(v654_9)) { singleton(&[]) } else { Space::new() };
        drop(v654_9);
        let v654_12: Space = if (&(v654_10)).is_empty() { Space::new() } else {
          let v659_6: Path = concat_path(&(v653_6),&v651_15_cursor.path()[(v651_15_origin + 1)..(v651_15_origin + 2)]);
          let mut v659_11 = Space::new();
          let mut v659_11_write = v659_11.write_zipper();
          for v659_11_byte in v651_15_cursor.child_mask().iter() {
            v651_15_cursor.descend_to_existing_byte(v659_11_byte);
            {
            let v660_2: Space = singleton(&v651_15_cursor.path()[(v651_15_origin + 2)..(v651_15_origin + 3)]);
            let v660_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v660_2));
            let v660_4: Space = if map_kernels::has_head(&(v660_3)) { singleton(&[]) } else { Space::new() };
            drop(v660_3);
            let v660_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v660_4));
            drop(v660_4);
            let v660_8: Space = if (&(v660_5)).is_empty() { Space::new() } else {
              let v661_6: Path = concat_path(&(v659_6),&v651_15_cursor.path()[(v651_15_origin + 2)..(v651_15_origin + 3)]);
              let v661_7: Space = routine_46(c, &(v661_6), &(*p1), &v651_15_cursor);
              map_map_kernels::compose(&(v660_5),&(v661_7))
            };
            drop(v660_5);
            let v660_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v660_2));
            drop(v660_2);
            let v660_10: Space = if map_kernels::has_head(&(v660_9)) { singleton(&[]) } else { Space::new() };
            drop(v660_9);
            let v660_12: Space = if (&(v660_10)).is_empty() { Space::new() } else {
              let v662_6: Path = concat_path(&(v659_6),&v651_15_cursor.path()[(v651_15_origin + 2)..(v651_15_origin + 3)]);
              let v662_11: Space = routine_19(c, &(v662_6), &(*p1), &v651_15_cursor);
              drop(v662_6);
              map_map_kernels::compose(&(v660_10),&(v662_11))
            };
            drop(v660_10);
            let v660_13: Space = map_map_kernels::unite(&(v660_8),&(v660_12));
            join_wrapped_into(&mut v659_11_write,&((v660_13).read_zipper()),&[]);
            }
            v651_15_cursor.ascend(1);
          }
          drop(v659_11_write);
          drop(v659_6);
          map_map_kernels::compose(&(v654_10),&(v659_11))
        };
        drop(v654_10);
        let v654_13: Space = map_map_kernels::unite(&(v654_8),&(v654_12));
        join_wrapped_into(&mut v653_7_write,&((v654_13).read_zipper()),&[]);
        }
        v651_15_cursor.ascend(1);
      }
      drop(v653_7_write);
      map_map_kernels::compose(&(v652_5),&(v653_7))
    };
    drop(v652_5);
    let v652_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v652_2));
    drop(v652_2);
    let v652_10: Space = if map_kernels::has_head(&(v652_9)) { singleton(&[]) } else { Space::new() };
    drop(v652_9);
    let v652_11: Space = map_view_kernels::compose(&(v652_10),&v651_15_cursor);
    drop(v652_10);
    let v663_6: Path = concat_path(&(*p0),&v651_15_cursor.path()[v651_15_origin..(v651_15_origin + 1)]);
    let v652_12: Space = map_kernels::wrap(&(v652_11),&(v663_6));
    drop(v652_11);
    let v652_13: Space = map_kernels::wrap(&(v652_12),&(*p1));
    drop(v652_12);
    let v652_14: Space = map_map_kernels::unite(&(v652_8),&(v652_13));
    drop(v652_13);
    join_wrapped_into(&mut v651_15_write,&((v652_14).read_zipper()),&[]);
    }
    v651_15_cursor.ascend(1);
  }
  drop(v651_15_cursor);
  drop(v651_15_write);
  (v651_15).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v664_16 = Space::new();
  let mut v664_16_write = v664_16.write_zipper();
  let mut v664_16_cursor = (*s0).read_zipper();
  let v664_16_origin = v664_16_cursor.path().len();
  for v664_16_byte in v664_16_cursor.child_mask().iter() {
    v664_16_cursor.descend_to_existing_byte(v664_16_byte);
    {
    let v665_2: Space = singleton(&v664_16_cursor.path()[v664_16_origin..(v664_16_origin + 1)]);
    let v665_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v665_2));
    let v665_4: Space = if map_kernels::has_head(&(v665_3)) { singleton(&[]) } else { Space::new() };
    drop(v665_3);
    let v665_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v665_4));
    drop(v665_4);
    let v665_8: Space = if (&(v665_5)).is_empty() { Space::new() } else {
      let v666_6: Path = concat_path(&(*p0),&v664_16_cursor.path()[v664_16_origin..(v664_16_origin + 1)]);
      let mut v666_7 = Space::new();
      let mut v666_7_write = v666_7.write_zipper();
      for v666_7_byte in v664_16_cursor.child_mask().iter() {
        v664_16_cursor.descend_to_existing_byte(v666_7_byte);
        {
        let v667_2: Space = singleton(&v664_16_cursor.path()[(v664_16_origin + 1)..(v664_16_origin + 2)]);
        let v667_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v667_2));
        let v667_4: Space = if map_kernels::has_head(&(v667_3)) { singleton(&[]) } else { Space::new() };
        drop(v667_3);
        let v667_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v667_4));
        drop(v667_4);
        let v667_7: Space = if (&(v667_5)).is_empty() { Space::new() } else {
          let mut v668_6 = Space::new();
          let mut v668_6_write = v668_6.write_zipper();
          for v668_6_byte in v664_16_cursor.child_mask().iter() {
            v664_16_cursor.descend_to_existing_byte(v668_6_byte);
            {
            let v669_2: Space = Space::new();
            join_wrapped_into(&mut v668_6_write,&((v669_2).read_zipper()),&[]);
            }
            v664_16_cursor.ascend(1);
          }
          drop(v668_6_write);
          map_map_kernels::compose(&(v667_5),&(v668_6))
        };
        drop(v667_5);
        let v667_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v667_2));
        drop(v667_2);
        let v667_9: Space = if map_kernels::has_head(&(v667_8)) { singleton(&[]) } else { Space::new() };
        drop(v667_8);
        let v667_12: Space = if (&(v667_9)).is_empty() { Space::new() } else {
          let v670_10: Path = concat_path(&(v666_6),&v664_16_cursor.path()[(v664_16_origin + 1)..(v664_16_origin + 2)]);
          let mut v670_11 = Space::new();
          let mut v670_11_write = v670_11.write_zipper();
          for v670_11_byte in v664_16_cursor.child_mask().iter() {
            v664_16_cursor.descend_to_existing_byte(v670_11_byte);
            {
            let v671_2: Space = singleton(&v664_16_cursor.path()[(v664_16_origin + 2)..(v664_16_origin + 3)]);
            let v671_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v671_2));
            drop(v671_2);
            let v671_4: Space = if map_kernels::has_head(&(v671_3)) { singleton(&[]) } else { Space::new() };
            drop(v671_3);
            let v671_7: Space = if (&(v671_4)).is_empty() { Space::new() } else {
              let v672_5: Path = concat_path(&(v670_10),&v664_16_cursor.path()[(v664_16_origin + 2)..(v664_16_origin + 3)]);
              let v672_6: Space = routine_3(c, &(v672_5), &v664_16_cursor, &(*s1));
              drop(v672_5);
              map_map_kernels::compose(&(v671_4),&(v672_6))
            };
            drop(v671_4);
            join_wrapped_into(&mut v670_11_write,&((v671_7).read_zipper()),&[]);
            }
            v664_16_cursor.ascend(1);
          }
          drop(v670_11_write);
          drop(v670_10);
          map_map_kernels::compose(&(v667_9),&(v670_11))
        };
        drop(v667_9);
        let v667_13: Space = map_map_kernels::unite(&(v667_7),&(v667_12));
        drop(v667_7);
        join_wrapped_into(&mut v666_7_write,&((v667_13).read_zipper()),&[]);
        }
        v664_16_cursor.ascend(1);
      }
      drop(v666_7_write);
      map_map_kernels::compose(&(v665_5),&(v666_7))
    };
    drop(v665_5);
    let v665_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v665_2));
    drop(v665_2);
    let v665_10: Space = if map_kernels::has_head(&(v665_9)) { singleton(&[]) } else { Space::new() };
    drop(v665_9);
    let v665_12: Space = if (&(v665_10)).is_empty() { Space::new() } else {
      let v673_6: Path = concat_path(&(*p0),&v664_16_cursor.path()[v664_16_origin..(v664_16_origin + 1)]);
      let mut v673_11 = Space::new();
      let mut v673_11_write = v673_11.write_zipper();
      for v673_11_byte in v664_16_cursor.child_mask().iter() {
        v664_16_cursor.descend_to_existing_byte(v673_11_byte);
        {
        let v674_2: Space = singleton(&v664_16_cursor.path()[(v664_16_origin + 1)..(v664_16_origin + 2)]);
        let v674_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v674_2));
        let v674_4: Space = if map_kernels::has_head(&(v674_3)) { singleton(&[]) } else { Space::new() };
        drop(v674_3);
        let v674_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v674_4));
        drop(v674_4);
        let v674_7: Space = if (&(v674_5)).is_empty() { Space::new() } else {
          let mut v675_6 = Space::new();
          let mut v675_6_write = v675_6.write_zipper();
          for v675_6_byte in v664_16_cursor.child_mask().iter() {
            v664_16_cursor.descend_to_existing_byte(v675_6_byte);
            {
            let v676_2: Space = Space::new();
            join_wrapped_into(&mut v675_6_write,&((v676_2).read_zipper()),&[]);
            }
            v664_16_cursor.ascend(1);
          }
          drop(v675_6_write);
          map_map_kernels::compose(&(v674_5),&(v675_6))
        };
        drop(v674_5);
        let v674_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v674_2));
        drop(v674_2);
        let v674_9: Space = if map_kernels::has_head(&(v674_8)) { singleton(&[]) } else { Space::new() };
        drop(v674_8);
        let v674_12: Space = if (&(v674_9)).is_empty() { Space::new() } else {
          let v677_10: Path = concat_path(&(v673_6),&v664_16_cursor.path()[(v664_16_origin + 1)..(v664_16_origin + 2)]);
          let mut v677_11 = Space::new();
          let mut v677_11_write = v677_11.write_zipper();
          for v677_11_byte in v664_16_cursor.child_mask().iter() {
            v664_16_cursor.descend_to_existing_byte(v677_11_byte);
            {
            let v678_2: Space = singleton(&v664_16_cursor.path()[(v664_16_origin + 2)..(v664_16_origin + 3)]);
            let v678_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v678_2));
            let v678_4: Space = if map_kernels::has_head(&(v678_3)) { singleton(&[]) } else { Space::new() };
            drop(v678_3);
            let v678_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v678_4));
            drop(v678_4);
            let v678_7: Space = if (&(v678_5)).is_empty() { Space::new() } else {
              let v679_6: Space = routine_4(c, &v664_16_cursor.path()[(v664_16_origin + 2)..(v664_16_origin + 3)], &(v677_10), &v664_16_cursor, &(*s1));
              map_map_kernels::compose(&(v678_5),&(v679_6))
            };
            drop(v678_5);
            let v678_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v678_2));
            drop(v678_2);
            let v678_9: Space = if map_kernels::has_head(&(v678_8)) { singleton(&[]) } else { Space::new() };
            drop(v678_8);
            let v678_11: Space = if (&(v678_9)).is_empty() { Space::new() } else {
              let v680_10: Space = routine_5(c, &v664_16_cursor.path()[(v664_16_origin + 2)..(v664_16_origin + 3)], &(v677_10), &v664_16_cursor, &(*s1));
              map_map_kernels::compose(&(v678_9),&(v680_10))
            };
            drop(v678_9);
            let v678_12: Space = map_map_kernels::unite(&(v678_7),&(v678_11));
            join_wrapped_into(&mut v677_11_write,&((v678_12).read_zipper()),&[]);
            }
            v664_16_cursor.ascend(1);
          }
          drop(v677_11_write);
          drop(v677_10);
          map_map_kernels::compose(&(v674_9),&(v677_11))
        };
        drop(v674_9);
        let v674_13: Space = map_map_kernels::unite(&(v674_7),&(v674_12));
        drop(v674_7);
        join_wrapped_into(&mut v673_11_write,&((v674_13).read_zipper()),&[]);
        }
        v664_16_cursor.ascend(1);
      }
      drop(v673_11_write);
      drop(v673_6);
      map_map_kernels::compose(&(v665_10),&(v673_11))
    };
    drop(v665_10);
    let v665_13: Space = map_map_kernels::unite(&(v665_8),&(v665_12));
    join_wrapped_into(&mut v664_16_write,&((v665_13).read_zipper()),&[]);
    }
    v664_16_cursor.ascend(1);
  }
  drop(v664_16_cursor);
  drop(v664_16_write);
  (v664_16).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v681_19 = Space::new();
  let mut v681_19_write = v681_19.write_zipper();
  let mut v681_19_cursor = (*s0).read_zipper();
  let v681_19_origin = v681_19_cursor.path().len();
  for v681_19_byte in v681_19_cursor.child_mask().iter() {
    v681_19_cursor.descend_to_existing_byte(v681_19_byte);
    {
    let v682_2: Space = singleton(&v681_19_cursor.path()[v681_19_origin..(v681_19_origin + 1)]);
    let v682_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v682_2));
    let v682_4: Space = if map_kernels::has_head(&(v682_3)) { singleton(&[]) } else { Space::new() };
    drop(v682_3);
    let v682_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v682_4));
    drop(v682_4);
    let v682_8: Space = if (&(v682_5)).is_empty() { Space::new() } else {
      let v683_6: Path = concat_path(&(*p0),&v681_19_cursor.path()[v681_19_origin..(v681_19_origin + 1)]);
      let mut v683_7 = Space::new();
      let mut v683_7_write = v683_7.write_zipper();
      for v683_7_byte in v681_19_cursor.child_mask().iter() {
        v681_19_cursor.descend_to_existing_byte(v683_7_byte);
        {
        let v684_2: Space = singleton(&v681_19_cursor.path()[(v681_19_origin + 1)..(v681_19_origin + 2)]);
        let v684_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v684_2));
        let v684_4: Space = if map_kernels::has_head(&(v684_3)) { singleton(&[]) } else { Space::new() };
        drop(v684_3);
        let v684_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v684_4));
        drop(v684_4);
        let v684_7: Space = if (&(v684_5)).is_empty() { Space::new() } else {
          let mut v685_6 = Space::new();
          let mut v685_6_write = v685_6.write_zipper();
          for v685_6_byte in v681_19_cursor.child_mask().iter() {
            v681_19_cursor.descend_to_existing_byte(v685_6_byte);
            {
            let v686_2: Space = Space::new();
            join_wrapped_into(&mut v685_6_write,&((v686_2).read_zipper()),&[]);
            }
            v681_19_cursor.ascend(1);
          }
          drop(v685_6_write);
          map_map_kernels::compose(&(v684_5),&(v685_6))
        };
        drop(v684_5);
        let v684_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v684_2));
        drop(v684_2);
        let v684_9: Space = if map_kernels::has_head(&(v684_8)) { singleton(&[]) } else { Space::new() };
        drop(v684_8);
        let v684_12: Space = if (&(v684_9)).is_empty() { Space::new() } else {
          let v687_10: Path = concat_path(&(v683_6),&v681_19_cursor.path()[(v681_19_origin + 1)..(v681_19_origin + 2)]);
          let mut v687_11 = Space::new();
          let mut v687_11_write = v687_11.write_zipper();
          for v687_11_byte in v681_19_cursor.child_mask().iter() {
            v681_19_cursor.descend_to_existing_byte(v687_11_byte);
            {
            let v688_2: Space = singleton(&v681_19_cursor.path()[(v681_19_origin + 2)..(v681_19_origin + 3)]);
            let v688_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v688_2));
            drop(v688_2);
            let v688_4: Space = if map_kernels::has_head(&(v688_3)) { singleton(&[]) } else { Space::new() };
            drop(v688_3);
            let v688_7: Space = if (&(v688_4)).is_empty() { Space::new() } else {
              let v689_5: Path = concat_path(&(v687_10),&v681_19_cursor.path()[(v681_19_origin + 2)..(v681_19_origin + 3)]);
              let v689_6: Space = routine_3(c, &(v689_5), &v681_19_cursor, &(*s1));
              drop(v689_5);
              map_map_kernels::compose(&(v688_4),&(v689_6))
            };
            drop(v688_4);
            join_wrapped_into(&mut v687_11_write,&((v688_7).read_zipper()),&[]);
            }
            v681_19_cursor.ascend(1);
          }
          drop(v687_11_write);
          drop(v687_10);
          map_map_kernels::compose(&(v684_9),&(v687_11))
        };
        drop(v684_9);
        let v684_13: Space = map_map_kernels::unite(&(v684_7),&(v684_12));
        drop(v684_7);
        join_wrapped_into(&mut v683_7_write,&((v684_13).read_zipper()),&[]);
        }
        v681_19_cursor.ascend(1);
      }
      drop(v683_7_write);
      map_map_kernels::compose(&(v682_5),&(v683_7))
    };
    drop(v682_5);
    let v682_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v682_2));
    drop(v682_2);
    let v682_10: Space = if map_kernels::has_head(&(v682_9)) { singleton(&[]) } else { Space::new() };
    drop(v682_9);
    let v682_12: Space = if (&(v682_10)).is_empty() { Space::new() } else {
      let v690_6: Path = concat_path(&(*p0),&v681_19_cursor.path()[v681_19_origin..(v681_19_origin + 1)]);
      let mut v690_11 = Space::new();
      let mut v690_11_write = v690_11.write_zipper();
      for v690_11_byte in v681_19_cursor.child_mask().iter() {
        v681_19_cursor.descend_to_existing_byte(v690_11_byte);
        {
        let v691_2: Space = singleton(&v681_19_cursor.path()[(v681_19_origin + 1)..(v681_19_origin + 2)]);
        let v691_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v691_2));
        let v691_4: Space = if map_kernels::has_head(&(v691_3)) { singleton(&[]) } else { Space::new() };
        drop(v691_3);
        let v691_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v691_4));
        drop(v691_4);
        let v691_7: Space = if (&(v691_5)).is_empty() { Space::new() } else {
          let mut v692_6 = Space::new();
          let mut v692_6_write = v692_6.write_zipper();
          for v692_6_byte in v681_19_cursor.child_mask().iter() {
            v681_19_cursor.descend_to_existing_byte(v692_6_byte);
            {
            let v693_2: Space = singleton(&v681_19_cursor.path()[(v681_19_origin + 2)..(v681_19_origin + 3)]);
            let v693_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v693_2));
            let v693_4: Space = if map_kernels::has_head(&(v693_3)) { singleton(&[]) } else { Space::new() };
            drop(v693_3);
            let v693_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v693_4));
            drop(v693_4);
            let v693_8: Space = if (&(v693_5)).is_empty() { Space::new() } else {
              let v694_7: Space = routine_8(c, &v681_19_cursor.path()[(v681_19_origin + 1)..(v681_19_origin + 3)], &(v690_6), &v681_19_cursor, &(*s1));
              map_map_kernels::compose(&(v693_5),&(v694_7))
            };
            drop(v693_5);
            let v693_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v693_2));
            drop(v693_2);
            let v693_10: Space = if map_kernels::has_head(&(v693_9)) { singleton(&[]) } else { Space::new() };
            drop(v693_9);
            let v693_12: Space = if (&(v693_10)).is_empty() { Space::new() } else {
              let v695_11: Space = routine_9(c, &v681_19_cursor.path()[(v681_19_origin + 1)..(v681_19_origin + 3)], &(v690_6), &v681_19_cursor, &(*s1));
              map_map_kernels::compose(&(v693_10),&(v695_11))
            };
            drop(v693_10);
            let v693_13: Space = map_map_kernels::unite(&(v693_8),&(v693_12));
            join_wrapped_into(&mut v692_6_write,&((v693_13).read_zipper()),&[]);
            }
            v681_19_cursor.ascend(1);
          }
          drop(v692_6_write);
          map_map_kernels::compose(&(v691_5),&(v692_6))
        };
        drop(v691_5);
        let v691_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v691_2));
        drop(v691_2);
        let v691_9: Space = if map_kernels::has_head(&(v691_8)) { singleton(&[]) } else { Space::new() };
        drop(v691_8);
        let v691_11: Space = if (&(v691_9)).is_empty() { Space::new() } else {
          let mut v696_10 = Space::new();
          let mut v696_10_write = v696_10.write_zipper();
          for v696_10_byte in v681_19_cursor.child_mask().iter() {
            v681_19_cursor.descend_to_existing_byte(v696_10_byte);
            {
            let v697_2: Space = singleton(&v681_19_cursor.path()[(v681_19_origin + 2)..(v681_19_origin + 3)]);
            let v697_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v697_2));
            let v697_4: Space = if map_kernels::has_head(&(v697_3)) { singleton(&[]) } else { Space::new() };
            drop(v697_3);
            let v697_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v697_4));
            drop(v697_4);
            let v697_8: Space = if (&(v697_5)).is_empty() { Space::new() } else {
              let v698_7: Space = routine_8(c, &v681_19_cursor.path()[(v681_19_origin + 1)..(v681_19_origin + 3)], &(v690_6), &v681_19_cursor, &(*s1));
              map_map_kernels::compose(&(v697_5),&(v698_7))
            };
            drop(v697_5);
            let v697_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v697_2));
            drop(v697_2);
            let v697_10: Space = if map_kernels::has_head(&(v697_9)) { singleton(&[]) } else { Space::new() };
            drop(v697_9);
            let v697_12: Space = if (&(v697_10)).is_empty() { Space::new() } else {
              let v699_11: Space = routine_10(c, &v681_19_cursor.path()[(v681_19_origin + 1)..(v681_19_origin + 3)], &(v690_6), &v681_19_cursor, &(*s1));
              map_map_kernels::compose(&(v697_10),&(v699_11))
            };
            drop(v697_10);
            let v697_13: Space = map_map_kernels::unite(&(v697_8),&(v697_12));
            join_wrapped_into(&mut v696_10_write,&((v697_13).read_zipper()),&[]);
            }
            v681_19_cursor.ascend(1);
          }
          drop(v696_10_write);
          map_map_kernels::compose(&(v691_9),&(v696_10))
        };
        drop(v691_9);
        let v691_12: Space = map_map_kernels::unite(&(v691_7),&(v691_11));
        join_wrapped_into(&mut v690_11_write,&((v691_12).read_zipper()),&[]);
        }
        v681_19_cursor.ascend(1);
      }
      drop(v690_11_write);
      drop(v690_6);
      map_map_kernels::compose(&(v682_10),&(v690_11))
    };
    drop(v682_10);
    let v682_13: Space = map_map_kernels::unite(&(v682_8),&(v682_12));
    join_wrapped_into(&mut v681_19_write,&((v682_13).read_zipper()),&[]);
    }
    v681_19_cursor.ascend(1);
  }
  drop(v681_19_cursor);
  drop(v681_19_write);
  (v681_19).clone()
}

fn routine_36(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v700_28 = Space::new();
  let mut v700_28_write = v700_28.write_zipper();
  let mut v700_28_cursor = (*s0).read_zipper();
  let v700_28_origin = v700_28_cursor.path().len();
  for v700_28_byte in v700_28_cursor.child_mask().iter() {
    v700_28_cursor.descend_to_existing_byte(v700_28_byte);
    {
    let v701_2: Space = singleton(&v700_28_cursor.path()[v700_28_origin..(v700_28_origin + 1)]);
    let v701_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v701_2));
    let v701_4: Space = if map_kernels::has_head(&(v701_3)) { singleton(&[]) } else { Space::new() };
    drop(v701_3);
    let v701_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v701_4));
    drop(v701_4);
    let v701_8: Space = if (&(v701_5)).is_empty() { Space::new() } else {
      let v702_6: Path = concat_path(&(*p0),&v700_28_cursor.path()[v700_28_origin..(v700_28_origin + 1)]);
      let mut v702_7 = Space::new();
      let mut v702_7_write = v702_7.write_zipper();
      for v702_7_byte in v700_28_cursor.child_mask().iter() {
        v700_28_cursor.descend_to_existing_byte(v702_7_byte);
        {
        let v703_2: Space = singleton(&v700_28_cursor.path()[(v700_28_origin + 1)..(v700_28_origin + 2)]);
        let v703_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v703_2));
        let v703_4: Space = if map_kernels::has_head(&(v703_3)) { singleton(&[]) } else { Space::new() };
        drop(v703_3);
        let v703_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v703_4));
        drop(v703_4);
        let v703_8: Space = if (&(v703_5)).is_empty() { Space::new() } else {
          let v704_6: Path = concat_path(&(v702_6),&v700_28_cursor.path()[(v700_28_origin + 1)..(v700_28_origin + 2)]);
          let mut v704_7 = Space::new();
          let mut v704_7_write = v704_7.write_zipper();
          for v704_7_byte in v700_28_cursor.child_mask().iter() {
            v700_28_cursor.descend_to_existing_byte(v704_7_byte);
            {
            let v705_2: Space = singleton(&v700_28_cursor.path()[(v700_28_origin + 2)..(v700_28_origin + 3)]);
            let v705_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v705_2));
            let v705_4: Space = if map_kernels::has_head(&(v705_3)) { singleton(&[]) } else { Space::new() };
            drop(v705_3);
            let v705_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v705_4));
            drop(v705_4);
            let v705_8: Space = if (&(v705_5)).is_empty() { Space::new() } else {
              let v706_6: Path = concat_path(&(v704_6),&v700_28_cursor.path()[(v700_28_origin + 2)..(v700_28_origin + 3)]);
              let v706_7: Space = routine_48(c, &(v706_6), &(*p1), &v700_28_cursor, &(*s1));
              map_map_kernels::compose(&(v705_5),&(v706_7))
            };
            drop(v705_5);
            let v705_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v705_2));
            drop(v705_2);
            let v705_10: Space = if map_kernels::has_head(&(v705_9)) { singleton(&[]) } else { Space::new() };
            drop(v705_9);
            let v705_12: Space = if (&(v705_10)).is_empty() { Space::new() } else {
              let v707_6: Path = concat_path(&(v704_6),&v700_28_cursor.path()[(v700_28_origin + 2)..(v700_28_origin + 3)]);
              let v707_11: Space = routine_49(c, &(v707_6), &(*p1), &v700_28_cursor, &(*s1));
              drop(v707_6);
              map_map_kernels::compose(&(v705_10),&(v707_11))
            };
            drop(v705_10);
            let v705_13: Space = map_map_kernels::unite(&(v705_8),&(v705_12));
            join_wrapped_into(&mut v704_7_write,&((v705_13).read_zipper()),&[]);
            }
            v700_28_cursor.ascend(1);
          }
          drop(v704_7_write);
          map_map_kernels::compose(&(v703_5),&(v704_7))
        };
        drop(v703_5);
        let v703_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v703_2));
        drop(v703_2);
        let v703_10: Space = if map_kernels::has_head(&(v703_9)) { singleton(&[]) } else { Space::new() };
        drop(v703_9);
        let v703_12: Space = if (&(v703_10)).is_empty() { Space::new() } else {
          let v708_6: Path = concat_path(&(v702_6),&v700_28_cursor.path()[(v700_28_origin + 1)..(v700_28_origin + 2)]);
          let mut v708_11 = Space::new();
          let mut v708_11_write = v708_11.write_zipper();
          for v708_11_byte in v700_28_cursor.child_mask().iter() {
            v700_28_cursor.descend_to_existing_byte(v708_11_byte);
            {
            let v709_2: Space = singleton(&v700_28_cursor.path()[(v700_28_origin + 2)..(v700_28_origin + 3)]);
            let v709_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v709_2));
            let v709_4: Space = if map_kernels::has_head(&(v709_3)) { singleton(&[]) } else { Space::new() };
            drop(v709_3);
            let v709_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v709_4));
            drop(v709_4);
            let v709_8: Space = if (&(v709_5)).is_empty() { Space::new() } else {
              let v710_6: Path = concat_path(&(v708_6),&v700_28_cursor.path()[(v700_28_origin + 2)..(v700_28_origin + 3)]);
              let v710_7: Space = routine_48(c, &(v710_6), &(*p1), &v700_28_cursor, &(*s1));
              map_map_kernels::compose(&(v709_5),&(v710_7))
            };
            drop(v709_5);
            let v709_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v709_2));
            drop(v709_2);
            let v709_10: Space = if map_kernels::has_head(&(v709_9)) { singleton(&[]) } else { Space::new() };
            drop(v709_9);
            let v709_12: Space = if (&(v709_10)).is_empty() { Space::new() } else {
              let v711_6: Path = concat_path(&(v708_6),&v700_28_cursor.path()[(v700_28_origin + 2)..(v700_28_origin + 3)]);
              let v711_11: Space = routine_10(c, &(v711_6), &(*p1), &v700_28_cursor, &(*s1));
              drop(v711_6);
              map_map_kernels::compose(&(v709_10),&(v711_11))
            };
            drop(v709_10);
            let v709_13: Space = map_map_kernels::unite(&(v709_8),&(v709_12));
            join_wrapped_into(&mut v708_11_write,&((v709_13).read_zipper()),&[]);
            }
            v700_28_cursor.ascend(1);
          }
          drop(v708_11_write);
          drop(v708_6);
          map_map_kernels::compose(&(v703_10),&(v708_11))
        };
        drop(v703_10);
        let v703_13: Space = map_map_kernels::unite(&(v703_8),&(v703_12));
        join_wrapped_into(&mut v702_7_write,&((v703_13).read_zipper()),&[]);
        }
        v700_28_cursor.ascend(1);
      }
      drop(v702_7_write);
      map_map_kernels::compose(&(v701_5),&(v702_7))
    };
    drop(v701_5);
    let v701_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v701_2));
    drop(v701_2);
    let v701_10: Space = if map_kernels::has_head(&(v701_9)) { singleton(&[]) } else { Space::new() };
    drop(v701_9);
    let v701_13: Space = if (&(v701_10)).is_empty() { Space::new() } else {
      let v712_6: Path = concat_path(&(*p0),&v700_28_cursor.path()[v700_28_origin..(v700_28_origin + 1)]);
      let mut v712_12 = Space::new();
      let mut v712_12_write = v712_12.write_zipper();
      for v712_12_byte in v700_28_cursor.child_mask().iter() {
        v700_28_cursor.descend_to_existing_byte(v712_12_byte);
        {
        let v713_2: Space = singleton(&v700_28_cursor.path()[(v700_28_origin + 1)..(v700_28_origin + 2)]);
        let v713_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v713_2));
        let v713_4: Space = if map_kernels::has_head(&(v713_3)) { singleton(&[]) } else { Space::new() };
        drop(v713_3);
        let v713_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v713_4));
        drop(v713_4);
        let v713_8: Space = if (&(v713_5)).is_empty() { Space::new() } else {
          let v714_6: Path = concat_path(&(v712_6),&v700_28_cursor.path()[(v700_28_origin + 1)..(v700_28_origin + 2)]);
          let mut v714_7 = Space::new();
          let mut v714_7_write = v714_7.write_zipper();
          for v714_7_byte in v700_28_cursor.child_mask().iter() {
            v700_28_cursor.descend_to_existing_byte(v714_7_byte);
            {
            let v715_2: Space = singleton(&v700_28_cursor.path()[(v700_28_origin + 2)..(v700_28_origin + 3)]);
            let v715_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v715_2));
            let v715_4: Space = if map_kernels::has_head(&(v715_3)) { singleton(&[]) } else { Space::new() };
            drop(v715_3);
            let v715_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v715_4));
            drop(v715_4);
            let v715_8: Space = if (&(v715_5)).is_empty() { Space::new() } else {
              let v716_6: Path = concat_path(&(v714_6),&v700_28_cursor.path()[(v700_28_origin + 2)..(v700_28_origin + 3)]);
              let v716_7: Space = routine_48(c, &(v716_6), &(*p1), &v700_28_cursor, &(*s1));
              map_map_kernels::compose(&(v715_5),&(v716_7))
            };
            drop(v715_5);
            let v715_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v715_2));
            drop(v715_2);
            let v715_10: Space = if map_kernels::has_head(&(v715_9)) { singleton(&[]) } else { Space::new() };
            drop(v715_9);
            let v715_12: Space = if (&(v715_10)).is_empty() { Space::new() } else {
              let v717_6: Path = concat_path(&(v714_6),&v700_28_cursor.path()[(v700_28_origin + 2)..(v700_28_origin + 3)]);
              let v717_11: Space = routine_49(c, &(v717_6), &(*p1), &v700_28_cursor, &(*s1));
              drop(v717_6);
              map_map_kernels::compose(&(v715_10),&(v717_11))
            };
            drop(v715_10);
            let v715_13: Space = map_map_kernels::unite(&(v715_8),&(v715_12));
            join_wrapped_into(&mut v714_7_write,&((v715_13).read_zipper()),&[]);
            }
            v700_28_cursor.ascend(1);
          }
          drop(v714_7_write);
          drop(v714_6);
          map_map_kernels::compose(&(v713_5),&(v714_7))
        };
        drop(v713_5);
        let v713_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v713_2));
        drop(v713_2);
        let v713_10: Space = if map_kernels::has_head(&(v713_9)) { singleton(&[]) } else { Space::new() };
        drop(v713_9);
        let v713_13: Space = if (&(v713_10)).is_empty() { Space::new() } else {
          let mut v718_12 = Space::new();
          let mut v718_12_write = v718_12.write_zipper();
          let mut v718_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v700_28_cursor.path()[v700_28_origin..(v700_28_origin + 1)]),&v700_28_cursor.path()[(v700_28_origin + 1)..(v700_28_origin + 2)]);
          let v718_12_origin = v718_12_cursor.path().len();
          for v718_12_byte in v718_12_cursor.child_mask().iter() {
            v718_12_cursor.descend_to_existing_byte(v718_12_byte);
            {
            let v719_2: Space = singleton(&v718_12_cursor.path()[v718_12_origin..(v718_12_origin + 1)]);
            let v719_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v719_2));
            let v719_4: Space = if map_kernels::has_head(&(v719_3)) { singleton(&[]) } else { Space::new() };
            drop(v719_3);
            let v719_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v719_4));
            drop(v719_4);
            let v719_7: Space = if (&(v719_5)).is_empty() { Space::new() } else {
              let v720_6: Space = routine_13(c, &v718_12_cursor.path()[v718_12_origin..(v718_12_origin + 1)], &(*p1), &v718_12_cursor);
              map_map_kernels::compose(&(v719_5),&(v720_6))
            };
            drop(v719_5);
            let v719_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v719_2));
            drop(v719_2);
            let v719_9: Space = if map_kernels::has_head(&(v719_8)) { singleton(&[]) } else { Space::new() };
            drop(v719_8);
            let v719_11: Space = if (&(v719_9)).is_empty() { Space::new() } else {
              let v721_10: Space = routine_14(c, &v718_12_cursor.path()[v718_12_origin..(v718_12_origin + 1)], &(*p1), &v718_12_cursor);
              map_map_kernels::compose(&(v719_9),&(v721_10))
            };
            drop(v719_9);
            let v719_12: Space = map_map_kernels::unite(&(v719_7),&(v719_11));
            join_wrapped_into(&mut v718_12_write,&((v719_12).read_zipper()),&[]);
            }
            v718_12_cursor.ascend(1);
          }
          drop(v718_12_cursor);
          drop(v718_12_write);
          map_map_kernels::compose(&(v713_10),&(v718_12))
        };
        drop(v713_10);
        let v713_14: Space = map_map_kernels::unite(&(v713_8),&(v713_13));
        join_wrapped_into(&mut v712_12_write,&((v713_14).read_zipper()),&[]);
        }
        v700_28_cursor.ascend(1);
      }
      drop(v712_12_write);
      drop(v712_6);
      map_map_kernels::compose(&(v701_10),&(v712_12))
    };
    drop(v701_10);
    let v701_14: Space = map_map_kernels::unite(&(v701_8),&(v701_13));
    join_wrapped_into(&mut v700_28_write,&((v701_14).read_zipper()),&[]);
    }
    v700_28_cursor.ascend(1);
  }
  drop(v700_28_cursor);
  drop(v700_28_write);
  (v700_28).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v722_28 = Space::new();
  let mut v722_28_write = v722_28.write_zipper();
  let mut v722_28_cursor = (*s0).read_zipper();
  let v722_28_origin = v722_28_cursor.path().len();
  for v722_28_byte in v722_28_cursor.child_mask().iter() {
    v722_28_cursor.descend_to_existing_byte(v722_28_byte);
    {
    let v723_2: Space = singleton(&v722_28_cursor.path()[v722_28_origin..(v722_28_origin + 1)]);
    let v723_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v723_2));
    let v723_4: Space = if map_kernels::has_head(&(v723_3)) { singleton(&[]) } else { Space::new() };
    drop(v723_3);
    let v723_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v723_4));
    drop(v723_4);
    let v723_8: Space = if (&(v723_5)).is_empty() { Space::new() } else {
      let v724_6: Path = concat_path(&(*p0),&v722_28_cursor.path()[v722_28_origin..(v722_28_origin + 1)]);
      let mut v724_7 = Space::new();
      let mut v724_7_write = v724_7.write_zipper();
      for v724_7_byte in v722_28_cursor.child_mask().iter() {
        v722_28_cursor.descend_to_existing_byte(v724_7_byte);
        {
        let v725_2: Space = singleton(&v722_28_cursor.path()[(v722_28_origin + 1)..(v722_28_origin + 2)]);
        let v725_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v725_2));
        let v725_4: Space = if map_kernels::has_head(&(v725_3)) { singleton(&[]) } else { Space::new() };
        drop(v725_3);
        let v725_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v725_4));
        drop(v725_4);
        let v725_8: Space = if (&(v725_5)).is_empty() { Space::new() } else {
          let v726_6: Path = concat_path(&(v724_6),&v722_28_cursor.path()[(v722_28_origin + 1)..(v722_28_origin + 2)]);
          let mut v726_7 = Space::new();
          let mut v726_7_write = v726_7.write_zipper();
          for v726_7_byte in v722_28_cursor.child_mask().iter() {
            v722_28_cursor.descend_to_existing_byte(v726_7_byte);
            {
            let v727_2: Space = singleton(&v722_28_cursor.path()[(v722_28_origin + 2)..(v722_28_origin + 3)]);
            let v727_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v727_2));
            let v727_4: Space = if map_kernels::has_head(&(v727_3)) { singleton(&[]) } else { Space::new() };
            drop(v727_3);
            let v727_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v727_4));
            drop(v727_4);
            let v727_8: Space = if (&(v727_5)).is_empty() { Space::new() } else {
              let v728_6: Path = concat_path(&(v726_6),&v722_28_cursor.path()[(v722_28_origin + 2)..(v722_28_origin + 3)]);
              let v728_7: Space = routine_48(c, &(v728_6), &(*p1), &v722_28_cursor, &(*s1));
              map_map_kernels::compose(&(v727_5),&(v728_7))
            };
            drop(v727_5);
            let v727_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v727_2));
            drop(v727_2);
            let v727_10: Space = if map_kernels::has_head(&(v727_9)) { singleton(&[]) } else { Space::new() };
            drop(v727_9);
            let v727_12: Space = if (&(v727_10)).is_empty() { Space::new() } else {
              let v729_6: Path = concat_path(&(v726_6),&v722_28_cursor.path()[(v722_28_origin + 2)..(v722_28_origin + 3)]);
              let v729_11: Space = routine_49(c, &(v729_6), &(*p1), &v722_28_cursor, &(*s1));
              drop(v729_6);
              map_map_kernels::compose(&(v727_10),&(v729_11))
            };
            drop(v727_10);
            let v727_13: Space = map_map_kernels::unite(&(v727_8),&(v727_12));
            join_wrapped_into(&mut v726_7_write,&((v727_13).read_zipper()),&[]);
            }
            v722_28_cursor.ascend(1);
          }
          drop(v726_7_write);
          map_map_kernels::compose(&(v725_5),&(v726_7))
        };
        drop(v725_5);
        let v725_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v725_2));
        drop(v725_2);
        let v725_10: Space = if map_kernels::has_head(&(v725_9)) { singleton(&[]) } else { Space::new() };
        drop(v725_9);
        let v725_12: Space = if (&(v725_10)).is_empty() { Space::new() } else {
          let v730_6: Path = concat_path(&(v724_6),&v722_28_cursor.path()[(v722_28_origin + 1)..(v722_28_origin + 2)]);
          let mut v730_11 = Space::new();
          let mut v730_11_write = v730_11.write_zipper();
          for v730_11_byte in v722_28_cursor.child_mask().iter() {
            v722_28_cursor.descend_to_existing_byte(v730_11_byte);
            {
            let v731_2: Space = singleton(&v722_28_cursor.path()[(v722_28_origin + 2)..(v722_28_origin + 3)]);
            let v731_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v731_2));
            let v731_4: Space = if map_kernels::has_head(&(v731_3)) { singleton(&[]) } else { Space::new() };
            drop(v731_3);
            let v731_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v731_4));
            drop(v731_4);
            let v731_8: Space = if (&(v731_5)).is_empty() { Space::new() } else {
              let v732_6: Path = concat_path(&(v730_6),&v722_28_cursor.path()[(v722_28_origin + 2)..(v722_28_origin + 3)]);
              let v732_7: Space = routine_48(c, &(v732_6), &(*p1), &v722_28_cursor, &(*s1));
              map_map_kernels::compose(&(v731_5),&(v732_7))
            };
            drop(v731_5);
            let v731_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v731_2));
            drop(v731_2);
            let v731_10: Space = if map_kernels::has_head(&(v731_9)) { singleton(&[]) } else { Space::new() };
            drop(v731_9);
            let v731_12: Space = if (&(v731_10)).is_empty() { Space::new() } else {
              let v733_6: Path = concat_path(&(v730_6),&v722_28_cursor.path()[(v722_28_origin + 2)..(v722_28_origin + 3)]);
              let v733_11: Space = routine_10(c, &(v733_6), &(*p1), &v722_28_cursor, &(*s1));
              drop(v733_6);
              map_map_kernels::compose(&(v731_10),&(v733_11))
            };
            drop(v731_10);
            let v731_13: Space = map_map_kernels::unite(&(v731_8),&(v731_12));
            join_wrapped_into(&mut v730_11_write,&((v731_13).read_zipper()),&[]);
            }
            v722_28_cursor.ascend(1);
          }
          drop(v730_11_write);
          drop(v730_6);
          map_map_kernels::compose(&(v725_10),&(v730_11))
        };
        drop(v725_10);
        let v725_13: Space = map_map_kernels::unite(&(v725_8),&(v725_12));
        join_wrapped_into(&mut v724_7_write,&((v725_13).read_zipper()),&[]);
        }
        v722_28_cursor.ascend(1);
      }
      drop(v724_7_write);
      drop(v724_6);
      map_map_kernels::compose(&(v723_5),&(v724_7))
    };
    drop(v723_5);
    let v723_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v723_2));
    drop(v723_2);
    let v723_10: Space = if map_kernels::has_head(&(v723_9)) { singleton(&[]) } else { Space::new() };
    drop(v723_9);
    let v723_13: Space = if (&(v723_10)).is_empty() { Space::new() } else {
      let mut v734_12 = Space::new();
      let mut v734_12_write = v734_12.write_zipper();
      let mut v734_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v722_28_cursor.path()[v722_28_origin..(v722_28_origin + 1)]);
      let v734_12_origin = v734_12_cursor.path().len();
      for v734_12_byte in v734_12_cursor.child_mask().iter() {
        v734_12_cursor.descend_to_existing_byte(v734_12_byte);
        {
        let v735_2: Space = singleton(&v734_12_cursor.path()[v734_12_origin..(v734_12_origin + 1)]);
        let v735_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v735_2));
        let v735_4: Space = if map_kernels::has_head(&(v735_3)) { singleton(&[]) } else { Space::new() };
        drop(v735_3);
        let v735_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v735_4));
        drop(v735_4);
        let v735_7: Space = if (&(v735_5)).is_empty() { Space::new() } else {
          let mut v736_6 = Space::new();
          let mut v736_6_write = v736_6.write_zipper();
          for v736_6_byte in v734_12_cursor.child_mask().iter() {
            v734_12_cursor.descend_to_existing_byte(v736_6_byte);
            {
            let v737_2: Space = singleton(&v734_12_cursor.path()[(v734_12_origin + 1)..(v734_12_origin + 2)]);
            let v737_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v737_2));
            let v737_4: Space = if map_kernels::has_head(&(v737_3)) { singleton(&[]) } else { Space::new() };
            drop(v737_3);
            let v737_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v737_4));
            drop(v737_4);
            let v737_8: Space = if (&(v737_5)).is_empty() { Space::new() } else {
              let v738_7: Space = routine_17(c, &v734_12_cursor.path()[v734_12_origin..(v734_12_origin + 2)], &(*p1), &v734_12_cursor);
              map_map_kernels::compose(&(v737_5),&(v738_7))
            };
            drop(v737_5);
            let v737_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v737_2));
            drop(v737_2);
            let v737_10: Space = if map_kernels::has_head(&(v737_9)) { singleton(&[]) } else { Space::new() };
            drop(v737_9);
            let v737_12: Space = if (&(v737_10)).is_empty() { Space::new() } else {
              let v739_11: Space = routine_18(c, &v734_12_cursor.path()[v734_12_origin..(v734_12_origin + 2)], &(*p1), &v734_12_cursor);
              map_map_kernels::compose(&(v737_10),&(v739_11))
            };
            drop(v737_10);
            let v737_13: Space = map_map_kernels::unite(&(v737_8),&(v737_12));
            join_wrapped_into(&mut v736_6_write,&((v737_13).read_zipper()),&[]);
            }
            v734_12_cursor.ascend(1);
          }
          drop(v736_6_write);
          map_map_kernels::compose(&(v735_5),&(v736_6))
        };
        drop(v735_5);
        let v735_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v735_2));
        drop(v735_2);
        let v735_9: Space = if map_kernels::has_head(&(v735_8)) { singleton(&[]) } else { Space::new() };
        drop(v735_8);
        let v735_11: Space = if (&(v735_9)).is_empty() { Space::new() } else {
          let mut v740_10 = Space::new();
          let mut v740_10_write = v740_10.write_zipper();
          for v740_10_byte in v734_12_cursor.child_mask().iter() {
            v734_12_cursor.descend_to_existing_byte(v740_10_byte);
            {
            let v741_2: Space = singleton(&v734_12_cursor.path()[(v734_12_origin + 1)..(v734_12_origin + 2)]);
            let v741_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v741_2));
            let v741_4: Space = if map_kernels::has_head(&(v741_3)) { singleton(&[]) } else { Space::new() };
            drop(v741_3);
            let v741_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v741_4));
            drop(v741_4);
            let v741_8: Space = if (&(v741_5)).is_empty() { Space::new() } else {
              let v742_7: Space = routine_17(c, &v734_12_cursor.path()[v734_12_origin..(v734_12_origin + 2)], &(*p1), &v734_12_cursor);
              map_map_kernels::compose(&(v741_5),&(v742_7))
            };
            drop(v741_5);
            let v741_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v741_2));
            drop(v741_2);
            let v741_10: Space = if map_kernels::has_head(&(v741_9)) { singleton(&[]) } else { Space::new() };
            drop(v741_9);
            let v741_12: Space = if (&(v741_10)).is_empty() { Space::new() } else {
              let v743_11: Space = routine_19(c, &v734_12_cursor.path()[v734_12_origin..(v734_12_origin + 2)], &(*p1), &v734_12_cursor);
              map_map_kernels::compose(&(v741_10),&(v743_11))
            };
            drop(v741_10);
            let v741_13: Space = map_map_kernels::unite(&(v741_8),&(v741_12));
            join_wrapped_into(&mut v740_10_write,&((v741_13).read_zipper()),&[]);
            }
            v734_12_cursor.ascend(1);
          }
          drop(v740_10_write);
          map_map_kernels::compose(&(v735_9),&(v740_10))
        };
        drop(v735_9);
        let v735_12: Space = map_map_kernels::unite(&(v735_7),&(v735_11));
        join_wrapped_into(&mut v734_12_write,&((v735_12).read_zipper()),&[]);
        }
        v734_12_cursor.ascend(1);
      }
      drop(v734_12_cursor);
      drop(v734_12_write);
      map_map_kernels::compose(&(v723_10),&(v734_12))
    };
    drop(v723_10);
    let v723_14: Space = map_map_kernels::unite(&(v723_8),&(v723_13));
    join_wrapped_into(&mut v722_28_write,&((v723_14).read_zipper()),&[]);
    }
    v722_28_cursor.ascend(1);
  }
  drop(v722_28_cursor);
  drop(v722_28_write);
  (v722_28).clone()
}

fn routine_38(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v744_21 = Space::new();
  let mut v744_21_write = v744_21.write_zipper();
  let mut v744_21_cursor = (*s0).read_zipper();
  let v744_21_origin = v744_21_cursor.path().len();
  for v744_21_byte in v744_21_cursor.child_mask().iter() {
    v744_21_cursor.descend_to_existing_byte(v744_21_byte);
    {
    let v745_2: Space = singleton(&v744_21_cursor.path()[v744_21_origin..(v744_21_origin + 1)]);
    let v745_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v745_2));
    let v745_4: Space = if map_kernels::has_head(&(v745_3)) { singleton(&[]) } else { Space::new() };
    drop(v745_3);
    let v745_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v745_4));
    drop(v745_4);
    let v745_8: Space = if (&(v745_5)).is_empty() { Space::new() } else {
      let v746_6: Path = concat_path(&(*p0),&v744_21_cursor.path()[v744_21_origin..(v744_21_origin + 1)]);
      let mut v746_7 = Space::new();
      let mut v746_7_write = v746_7.write_zipper();
      for v746_7_byte in v744_21_cursor.child_mask().iter() {
        v744_21_cursor.descend_to_existing_byte(v746_7_byte);
        {
        let v747_2: Space = singleton(&v744_21_cursor.path()[(v744_21_origin + 1)..(v744_21_origin + 2)]);
        let v747_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v747_2));
        let v747_4: Space = if map_kernels::has_head(&(v747_3)) { singleton(&[]) } else { Space::new() };
        drop(v747_3);
        let v747_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v747_4));
        drop(v747_4);
        let v747_8: Space = if (&(v747_5)).is_empty() { Space::new() } else {
          let v748_6: Path = concat_path(&(v746_6),&v744_21_cursor.path()[(v744_21_origin + 1)..(v744_21_origin + 2)]);
          let mut v748_7 = Space::new();
          let mut v748_7_write = v748_7.write_zipper();
          for v748_7_byte in v744_21_cursor.child_mask().iter() {
            v744_21_cursor.descend_to_existing_byte(v748_7_byte);
            {
            let v749_2: Space = singleton(&v744_21_cursor.path()[(v744_21_origin + 2)..(v744_21_origin + 3)]);
            let v749_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v749_2));
            let v749_4: Space = if map_kernels::has_head(&(v749_3)) { singleton(&[]) } else { Space::new() };
            drop(v749_3);
            let v749_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v749_4));
            drop(v749_4);
            let v749_8: Space = if (&(v749_5)).is_empty() { Space::new() } else {
              let v750_6: Path = concat_path(&(v748_6),&v744_21_cursor.path()[(v744_21_origin + 2)..(v744_21_origin + 3)]);
              let v750_7: Space = routine_50(c, &(v750_6), &(*p1), &v744_21_cursor);
              map_map_kernels::compose(&(v749_5),&(v750_7))
            };
            drop(v749_5);
            let v749_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v749_2));
            drop(v749_2);
            let v749_10: Space = if map_kernels::has_head(&(v749_9)) { singleton(&[]) } else { Space::new() };
            drop(v749_9);
            let v749_12: Space = if (&(v749_10)).is_empty() { Space::new() } else {
              let v751_6: Path = concat_path(&(v748_6),&v744_21_cursor.path()[(v744_21_origin + 2)..(v744_21_origin + 3)]);
              let v751_11: Space = routine_51(c, &(v751_6), &(*p1), &v744_21_cursor);
              drop(v751_6);
              map_map_kernels::compose(&(v749_10),&(v751_11))
            };
            drop(v749_10);
            let v749_13: Space = map_map_kernels::unite(&(v749_8),&(v749_12));
            join_wrapped_into(&mut v748_7_write,&((v749_13).read_zipper()),&[]);
            }
            v744_21_cursor.ascend(1);
          }
          drop(v748_7_write);
          map_map_kernels::compose(&(v747_5),&(v748_7))
        };
        drop(v747_5);
        let v747_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v747_2));
        drop(v747_2);
        let v747_10: Space = if map_kernels::has_head(&(v747_9)) { singleton(&[]) } else { Space::new() };
        drop(v747_9);
        let v747_12: Space = if (&(v747_10)).is_empty() { Space::new() } else {
          let v752_6: Path = concat_path(&(v746_6),&v744_21_cursor.path()[(v744_21_origin + 1)..(v744_21_origin + 2)]);
          let mut v752_11 = Space::new();
          let mut v752_11_write = v752_11.write_zipper();
          for v752_11_byte in v744_21_cursor.child_mask().iter() {
            v744_21_cursor.descend_to_existing_byte(v752_11_byte);
            {
            let v753_2: Space = singleton(&v744_21_cursor.path()[(v744_21_origin + 2)..(v744_21_origin + 3)]);
            let v753_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v753_2));
            let v753_4: Space = if map_kernels::has_head(&(v753_3)) { singleton(&[]) } else { Space::new() };
            drop(v753_3);
            let v753_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v753_4));
            drop(v753_4);
            let v753_8: Space = if (&(v753_5)).is_empty() { Space::new() } else {
              let v754_6: Path = concat_path(&(v752_6),&v744_21_cursor.path()[(v744_21_origin + 2)..(v744_21_origin + 3)]);
              let v754_7: Space = routine_50(c, &(v754_6), &(*p1), &v744_21_cursor);
              map_map_kernels::compose(&(v753_5),&(v754_7))
            };
            drop(v753_5);
            let v753_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v753_2));
            drop(v753_2);
            let v753_10: Space = if map_kernels::has_head(&(v753_9)) { singleton(&[]) } else { Space::new() };
            drop(v753_9);
            let v753_12: Space = if (&(v753_10)).is_empty() { Space::new() } else {
              let v755_6: Path = concat_path(&(v752_6),&v744_21_cursor.path()[(v744_21_origin + 2)..(v744_21_origin + 3)]);
              let v755_11: Space = routine_19(c, &(v755_6), &(*p1), &v744_21_cursor);
              drop(v755_6);
              map_map_kernels::compose(&(v753_10),&(v755_11))
            };
            drop(v753_10);
            let v753_13: Space = map_map_kernels::unite(&(v753_8),&(v753_12));
            join_wrapped_into(&mut v752_11_write,&((v753_13).read_zipper()),&[]);
            }
            v744_21_cursor.ascend(1);
          }
          drop(v752_11_write);
          drop(v752_6);
          map_map_kernels::compose(&(v747_10),&(v752_11))
        };
        drop(v747_10);
        let v747_13: Space = map_map_kernels::unite(&(v747_8),&(v747_12));
        join_wrapped_into(&mut v746_7_write,&((v747_13).read_zipper()),&[]);
        }
        v744_21_cursor.ascend(1);
      }
      drop(v746_7_write);
      map_map_kernels::compose(&(v745_5),&(v746_7))
    };
    drop(v745_5);
    let v745_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v745_2));
    drop(v745_2);
    let v745_10: Space = if map_kernels::has_head(&(v745_9)) { singleton(&[]) } else { Space::new() };
    drop(v745_9);
    let v745_12: Space = if (&(v745_10)).is_empty() { Space::new() } else {
      let v756_6: Path = concat_path(&(*p0),&v744_21_cursor.path()[v744_21_origin..(v744_21_origin + 1)]);
      let mut v756_11 = Space::new();
      let mut v756_11_write = v756_11.write_zipper();
      for v756_11_byte in v744_21_cursor.child_mask().iter() {
        v744_21_cursor.descend_to_existing_byte(v756_11_byte);
        {
        let v757_2: Space = singleton(&v744_21_cursor.path()[(v744_21_origin + 1)..(v744_21_origin + 2)]);
        let v757_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v757_2));
        let v757_4: Space = if map_kernels::has_head(&(v757_3)) { singleton(&[]) } else { Space::new() };
        drop(v757_3);
        let v757_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v757_4));
        drop(v757_4);
        let v757_8: Space = if (&(v757_5)).is_empty() { Space::new() } else {
          let v758_6: Path = concat_path(&(v756_6),&v744_21_cursor.path()[(v744_21_origin + 1)..(v744_21_origin + 2)]);
          let mut v758_7 = Space::new();
          let mut v758_7_write = v758_7.write_zipper();
          for v758_7_byte in v744_21_cursor.child_mask().iter() {
            v744_21_cursor.descend_to_existing_byte(v758_7_byte);
            {
            let v759_2: Space = singleton(&v744_21_cursor.path()[(v744_21_origin + 2)..(v744_21_origin + 3)]);
            let v759_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v759_2));
            let v759_4: Space = if map_kernels::has_head(&(v759_3)) { singleton(&[]) } else { Space::new() };
            drop(v759_3);
            let v759_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v759_4));
            drop(v759_4);
            let v759_8: Space = if (&(v759_5)).is_empty() { Space::new() } else {
              let v760_6: Path = concat_path(&(v758_6),&v744_21_cursor.path()[(v744_21_origin + 2)..(v744_21_origin + 3)]);
              let v760_7: Space = routine_50(c, &(v760_6), &(*p1), &v744_21_cursor);
              map_map_kernels::compose(&(v759_5),&(v760_7))
            };
            drop(v759_5);
            let v759_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v759_2));
            drop(v759_2);
            let v759_10: Space = if map_kernels::has_head(&(v759_9)) { singleton(&[]) } else { Space::new() };
            drop(v759_9);
            let v759_12: Space = if (&(v759_10)).is_empty() { Space::new() } else {
              let v761_6: Path = concat_path(&(v758_6),&v744_21_cursor.path()[(v744_21_origin + 2)..(v744_21_origin + 3)]);
              let v761_11: Space = routine_51(c, &(v761_6), &(*p1), &v744_21_cursor);
              drop(v761_6);
              map_map_kernels::compose(&(v759_10),&(v761_11))
            };
            drop(v759_10);
            let v759_13: Space = map_map_kernels::unite(&(v759_8),&(v759_12));
            join_wrapped_into(&mut v758_7_write,&((v759_13).read_zipper()),&[]);
            }
            v744_21_cursor.ascend(1);
          }
          drop(v758_7_write);
          map_map_kernels::compose(&(v757_5),&(v758_7))
        };
        drop(v757_5);
        let v757_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v757_2));
        drop(v757_2);
        let v757_10: Space = if map_kernels::has_head(&(v757_9)) { singleton(&[]) } else { Space::new() };
        drop(v757_9);
        let v757_11: Space = map_view_kernels::compose(&(v757_10),&v744_21_cursor);
        drop(v757_10);
        let v762_6: Path = concat_path(&(v756_6),&v744_21_cursor.path()[(v744_21_origin + 1)..(v744_21_origin + 2)]);
        let v757_12: Space = map_kernels::wrap(&(v757_11),&(v762_6));
        drop(v757_11);
        let v757_13: Space = map_kernels::wrap(&(v757_12),&(*p1));
        drop(v757_12);
        let v757_14: Space = map_map_kernels::unite(&(v757_8),&(v757_13));
        drop(v757_13);
        join_wrapped_into(&mut v756_11_write,&((v757_14).read_zipper()),&[]);
        }
        v744_21_cursor.ascend(1);
      }
      drop(v756_11_write);
      drop(v756_6);
      map_map_kernels::compose(&(v745_10),&(v756_11))
    };
    drop(v745_10);
    let v745_13: Space = map_map_kernels::unite(&(v745_8),&(v745_12));
    join_wrapped_into(&mut v744_21_write,&((v745_13).read_zipper()),&[]);
    }
    v744_21_cursor.ascend(1);
  }
  drop(v744_21_cursor);
  drop(v744_21_write);
  (v744_21).clone()
}

fn routine_39(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v763_15 = Space::new();
  let mut v763_15_write = v763_15.write_zipper();
  let mut v763_15_cursor = (*s0).read_zipper();
  let v763_15_origin = v763_15_cursor.path().len();
  for v763_15_byte in v763_15_cursor.child_mask().iter() {
    v763_15_cursor.descend_to_existing_byte(v763_15_byte);
    {
    let v764_2: Space = singleton(&v763_15_cursor.path()[v763_15_origin..(v763_15_origin + 1)]);
    let v764_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v764_2));
    let v764_4: Space = if map_kernels::has_head(&(v764_3)) { singleton(&[]) } else { Space::new() };
    drop(v764_3);
    let v764_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v764_4));
    drop(v764_4);
    let v764_8: Space = if (&(v764_5)).is_empty() { Space::new() } else {
      let v765_6: Path = concat_path(&(*p0),&v763_15_cursor.path()[v763_15_origin..(v763_15_origin + 1)]);
      let mut v765_7 = Space::new();
      let mut v765_7_write = v765_7.write_zipper();
      for v765_7_byte in v763_15_cursor.child_mask().iter() {
        v763_15_cursor.descend_to_existing_byte(v765_7_byte);
        {
        let v766_2: Space = singleton(&v763_15_cursor.path()[(v763_15_origin + 1)..(v763_15_origin + 2)]);
        let v766_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v766_2));
        let v766_4: Space = if map_kernels::has_head(&(v766_3)) { singleton(&[]) } else { Space::new() };
        drop(v766_3);
        let v766_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v766_4));
        drop(v766_4);
        let v766_8: Space = if (&(v766_5)).is_empty() { Space::new() } else {
          let v767_6: Path = concat_path(&(v765_6),&v763_15_cursor.path()[(v763_15_origin + 1)..(v763_15_origin + 2)]);
          let mut v767_7 = Space::new();
          let mut v767_7_write = v767_7.write_zipper();
          for v767_7_byte in v763_15_cursor.child_mask().iter() {
            v763_15_cursor.descend_to_existing_byte(v767_7_byte);
            {
            let v768_2: Space = singleton(&v763_15_cursor.path()[(v763_15_origin + 2)..(v763_15_origin + 3)]);
            let v768_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v768_2));
            let v768_4: Space = if map_kernels::has_head(&(v768_3)) { singleton(&[]) } else { Space::new() };
            drop(v768_3);
            let v768_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v768_4));
            drop(v768_4);
            let v768_8: Space = if (&(v768_5)).is_empty() { Space::new() } else {
              let v769_6: Path = concat_path(&(v767_6),&v763_15_cursor.path()[(v763_15_origin + 2)..(v763_15_origin + 3)]);
              let v769_7: Space = routine_50(c, &(v769_6), &(*p1), &v763_15_cursor);
              map_map_kernels::compose(&(v768_5),&(v769_7))
            };
            drop(v768_5);
            let v768_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v768_2));
            drop(v768_2);
            let v768_10: Space = if map_kernels::has_head(&(v768_9)) { singleton(&[]) } else { Space::new() };
            drop(v768_9);
            let v768_12: Space = if (&(v768_10)).is_empty() { Space::new() } else {
              let v770_6: Path = concat_path(&(v767_6),&v763_15_cursor.path()[(v763_15_origin + 2)..(v763_15_origin + 3)]);
              let v770_11: Space = routine_51(c, &(v770_6), &(*p1), &v763_15_cursor);
              drop(v770_6);
              map_map_kernels::compose(&(v768_10),&(v770_11))
            };
            drop(v768_10);
            let v768_13: Space = map_map_kernels::unite(&(v768_8),&(v768_12));
            join_wrapped_into(&mut v767_7_write,&((v768_13).read_zipper()),&[]);
            }
            v763_15_cursor.ascend(1);
          }
          drop(v767_7_write);
          map_map_kernels::compose(&(v766_5),&(v767_7))
        };
        drop(v766_5);
        let v766_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v766_2));
        drop(v766_2);
        let v766_10: Space = if map_kernels::has_head(&(v766_9)) { singleton(&[]) } else { Space::new() };
        drop(v766_9);
        let v766_12: Space = if (&(v766_10)).is_empty() { Space::new() } else {
          let v771_6: Path = concat_path(&(v765_6),&v763_15_cursor.path()[(v763_15_origin + 1)..(v763_15_origin + 2)]);
          let mut v771_11 = Space::new();
          let mut v771_11_write = v771_11.write_zipper();
          for v771_11_byte in v763_15_cursor.child_mask().iter() {
            v763_15_cursor.descend_to_existing_byte(v771_11_byte);
            {
            let v772_2: Space = singleton(&v763_15_cursor.path()[(v763_15_origin + 2)..(v763_15_origin + 3)]);
            let v772_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v772_2));
            let v772_4: Space = if map_kernels::has_head(&(v772_3)) { singleton(&[]) } else { Space::new() };
            drop(v772_3);
            let v772_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v772_4));
            drop(v772_4);
            let v772_8: Space = if (&(v772_5)).is_empty() { Space::new() } else {
              let v773_6: Path = concat_path(&(v771_6),&v763_15_cursor.path()[(v763_15_origin + 2)..(v763_15_origin + 3)]);
              let v773_7: Space = routine_50(c, &(v773_6), &(*p1), &v763_15_cursor);
              map_map_kernels::compose(&(v772_5),&(v773_7))
            };
            drop(v772_5);
            let v772_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v772_2));
            drop(v772_2);
            let v772_10: Space = if map_kernels::has_head(&(v772_9)) { singleton(&[]) } else { Space::new() };
            drop(v772_9);
            let v772_12: Space = if (&(v772_10)).is_empty() { Space::new() } else {
              let v774_6: Path = concat_path(&(v771_6),&v763_15_cursor.path()[(v763_15_origin + 2)..(v763_15_origin + 3)]);
              let v774_11: Space = routine_19(c, &(v774_6), &(*p1), &v763_15_cursor);
              drop(v774_6);
              map_map_kernels::compose(&(v772_10),&(v774_11))
            };
            drop(v772_10);
            let v772_13: Space = map_map_kernels::unite(&(v772_8),&(v772_12));
            join_wrapped_into(&mut v771_11_write,&((v772_13).read_zipper()),&[]);
            }
            v763_15_cursor.ascend(1);
          }
          drop(v771_11_write);
          drop(v771_6);
          map_map_kernels::compose(&(v766_10),&(v771_11))
        };
        drop(v766_10);
        let v766_13: Space = map_map_kernels::unite(&(v766_8),&(v766_12));
        join_wrapped_into(&mut v765_7_write,&((v766_13).read_zipper()),&[]);
        }
        v763_15_cursor.ascend(1);
      }
      drop(v765_7_write);
      map_map_kernels::compose(&(v764_5),&(v765_7))
    };
    drop(v764_5);
    let v764_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v764_2));
    drop(v764_2);
    let v764_10: Space = if map_kernels::has_head(&(v764_9)) { singleton(&[]) } else { Space::new() };
    drop(v764_9);
    let v764_11: Space = map_view_kernels::compose(&(v764_10),&v763_15_cursor);
    drop(v764_10);
    let v775_6: Path = concat_path(&(*p0),&v763_15_cursor.path()[v763_15_origin..(v763_15_origin + 1)]);
    let v764_12: Space = map_kernels::wrap(&(v764_11),&(v775_6));
    drop(v764_11);
    let v764_13: Space = map_kernels::wrap(&(v764_12),&(*p1));
    drop(v764_12);
    let v764_14: Space = map_map_kernels::unite(&(v764_8),&(v764_13));
    drop(v764_13);
    join_wrapped_into(&mut v763_15_write,&((v764_14).read_zipper()),&[]);
    }
    v763_15_cursor.ascend(1);
  }
  drop(v763_15_cursor);
  drop(v763_15_write);
  (v763_15).clone()
}

fn routine_40(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v776_28 = Space::new();
  let mut v776_28_write = v776_28.write_zipper();
  let mut v776_28_cursor = (*s0).read_zipper();
  let v776_28_origin = v776_28_cursor.path().len();
  for v776_28_byte in v776_28_cursor.child_mask().iter() {
    v776_28_cursor.descend_to_existing_byte(v776_28_byte);
    {
    let v777_2: Space = singleton(&v776_28_cursor.path()[v776_28_origin..(v776_28_origin + 1)]);
    let v777_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v777_2));
    let v777_4: Space = if map_kernels::has_head(&(v777_3)) { singleton(&[]) } else { Space::new() };
    drop(v777_3);
    let v777_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v777_4));
    drop(v777_4);
    let v777_8: Space = if (&(v777_5)).is_empty() { Space::new() } else {
      let v778_6: Path = concat_path(&(*p0),&v776_28_cursor.path()[v776_28_origin..(v776_28_origin + 1)]);
      let mut v778_7 = Space::new();
      let mut v778_7_write = v778_7.write_zipper();
      for v778_7_byte in v776_28_cursor.child_mask().iter() {
        v776_28_cursor.descend_to_existing_byte(v778_7_byte);
        {
        let v779_2: Space = singleton(&v776_28_cursor.path()[(v776_28_origin + 1)..(v776_28_origin + 2)]);
        let v779_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v779_2));
        let v779_4: Space = if map_kernels::has_head(&(v779_3)) { singleton(&[]) } else { Space::new() };
        drop(v779_3);
        let v779_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v779_4));
        drop(v779_4);
        let v779_8: Space = if (&(v779_5)).is_empty() { Space::new() } else {
          let v780_6: Path = concat_path(&(v778_6),&v776_28_cursor.path()[(v776_28_origin + 1)..(v776_28_origin + 2)]);
          let mut v780_7 = Space::new();
          let mut v780_7_write = v780_7.write_zipper();
          for v780_7_byte in v776_28_cursor.child_mask().iter() {
            v776_28_cursor.descend_to_existing_byte(v780_7_byte);
            {
            let v781_2: Space = singleton(&v776_28_cursor.path()[(v776_28_origin + 2)..(v776_28_origin + 3)]);
            let v781_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v781_2));
            let v781_4: Space = if map_kernels::has_head(&(v781_3)) { singleton(&[]) } else { Space::new() };
            drop(v781_3);
            let v781_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v781_4));
            drop(v781_4);
            let v781_8: Space = if (&(v781_5)).is_empty() { Space::new() } else {
              let v782_6: Path = concat_path(&(v780_6),&v776_28_cursor.path()[(v776_28_origin + 2)..(v776_28_origin + 3)]);
              let v782_7: Space = routine_52(c, &(v782_6), &(*p1), &v776_28_cursor, &(*s1));
              map_map_kernels::compose(&(v781_5),&(v782_7))
            };
            drop(v781_5);
            let v781_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v781_2));
            drop(v781_2);
            let v781_10: Space = if map_kernels::has_head(&(v781_9)) { singleton(&[]) } else { Space::new() };
            drop(v781_9);
            let v781_12: Space = if (&(v781_10)).is_empty() { Space::new() } else {
              let v783_6: Path = concat_path(&(v780_6),&v776_28_cursor.path()[(v776_28_origin + 2)..(v776_28_origin + 3)]);
              let v783_11: Space = routine_53(c, &(v783_6), &(*p1), &v776_28_cursor, &(*s1));
              drop(v783_6);
              map_map_kernels::compose(&(v781_10),&(v783_11))
            };
            drop(v781_10);
            let v781_13: Space = map_map_kernels::unite(&(v781_8),&(v781_12));
            join_wrapped_into(&mut v780_7_write,&((v781_13).read_zipper()),&[]);
            }
            v776_28_cursor.ascend(1);
          }
          drop(v780_7_write);
          map_map_kernels::compose(&(v779_5),&(v780_7))
        };
        drop(v779_5);
        let v779_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v779_2));
        drop(v779_2);
        let v779_10: Space = if map_kernels::has_head(&(v779_9)) { singleton(&[]) } else { Space::new() };
        drop(v779_9);
        let v779_12: Space = if (&(v779_10)).is_empty() { Space::new() } else {
          let v784_6: Path = concat_path(&(v778_6),&v776_28_cursor.path()[(v776_28_origin + 1)..(v776_28_origin + 2)]);
          let mut v784_11 = Space::new();
          let mut v784_11_write = v784_11.write_zipper();
          for v784_11_byte in v776_28_cursor.child_mask().iter() {
            v776_28_cursor.descend_to_existing_byte(v784_11_byte);
            {
            let v785_2: Space = singleton(&v776_28_cursor.path()[(v776_28_origin + 2)..(v776_28_origin + 3)]);
            let v785_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v785_2));
            let v785_4: Space = if map_kernels::has_head(&(v785_3)) { singleton(&[]) } else { Space::new() };
            drop(v785_3);
            let v785_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v785_4));
            drop(v785_4);
            let v785_8: Space = if (&(v785_5)).is_empty() { Space::new() } else {
              let v786_6: Path = concat_path(&(v784_6),&v776_28_cursor.path()[(v776_28_origin + 2)..(v776_28_origin + 3)]);
              let v786_7: Space = routine_52(c, &(v786_6), &(*p1), &v776_28_cursor, &(*s1));
              map_map_kernels::compose(&(v785_5),&(v786_7))
            };
            drop(v785_5);
            let v785_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v785_2));
            drop(v785_2);
            let v785_10: Space = if map_kernels::has_head(&(v785_9)) { singleton(&[]) } else { Space::new() };
            drop(v785_9);
            let v785_12: Space = if (&(v785_10)).is_empty() { Space::new() } else {
              let v787_6: Path = concat_path(&(v784_6),&v776_28_cursor.path()[(v776_28_origin + 2)..(v776_28_origin + 3)]);
              let v787_11: Space = routine_10(c, &(v787_6), &(*p1), &v776_28_cursor, &(*s1));
              drop(v787_6);
              map_map_kernels::compose(&(v785_10),&(v787_11))
            };
            drop(v785_10);
            let v785_13: Space = map_map_kernels::unite(&(v785_8),&(v785_12));
            join_wrapped_into(&mut v784_11_write,&((v785_13).read_zipper()),&[]);
            }
            v776_28_cursor.ascend(1);
          }
          drop(v784_11_write);
          drop(v784_6);
          map_map_kernels::compose(&(v779_10),&(v784_11))
        };
        drop(v779_10);
        let v779_13: Space = map_map_kernels::unite(&(v779_8),&(v779_12));
        join_wrapped_into(&mut v778_7_write,&((v779_13).read_zipper()),&[]);
        }
        v776_28_cursor.ascend(1);
      }
      drop(v778_7_write);
      map_map_kernels::compose(&(v777_5),&(v778_7))
    };
    drop(v777_5);
    let v777_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v777_2));
    drop(v777_2);
    let v777_10: Space = if map_kernels::has_head(&(v777_9)) { singleton(&[]) } else { Space::new() };
    drop(v777_9);
    let v777_13: Space = if (&(v777_10)).is_empty() { Space::new() } else {
      let v788_6: Path = concat_path(&(*p0),&v776_28_cursor.path()[v776_28_origin..(v776_28_origin + 1)]);
      let mut v788_12 = Space::new();
      let mut v788_12_write = v788_12.write_zipper();
      for v788_12_byte in v776_28_cursor.child_mask().iter() {
        v776_28_cursor.descend_to_existing_byte(v788_12_byte);
        {
        let v789_2: Space = singleton(&v776_28_cursor.path()[(v776_28_origin + 1)..(v776_28_origin + 2)]);
        let v789_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v789_2));
        let v789_4: Space = if map_kernels::has_head(&(v789_3)) { singleton(&[]) } else { Space::new() };
        drop(v789_3);
        let v789_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v789_4));
        drop(v789_4);
        let v789_8: Space = if (&(v789_5)).is_empty() { Space::new() } else {
          let v790_6: Path = concat_path(&(v788_6),&v776_28_cursor.path()[(v776_28_origin + 1)..(v776_28_origin + 2)]);
          let mut v790_7 = Space::new();
          let mut v790_7_write = v790_7.write_zipper();
          for v790_7_byte in v776_28_cursor.child_mask().iter() {
            v776_28_cursor.descend_to_existing_byte(v790_7_byte);
            {
            let v791_2: Space = singleton(&v776_28_cursor.path()[(v776_28_origin + 2)..(v776_28_origin + 3)]);
            let v791_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v791_2));
            let v791_4: Space = if map_kernels::has_head(&(v791_3)) { singleton(&[]) } else { Space::new() };
            drop(v791_3);
            let v791_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v791_4));
            drop(v791_4);
            let v791_8: Space = if (&(v791_5)).is_empty() { Space::new() } else {
              let v792_6: Path = concat_path(&(v790_6),&v776_28_cursor.path()[(v776_28_origin + 2)..(v776_28_origin + 3)]);
              let v792_7: Space = routine_52(c, &(v792_6), &(*p1), &v776_28_cursor, &(*s1));
              map_map_kernels::compose(&(v791_5),&(v792_7))
            };
            drop(v791_5);
            let v791_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v791_2));
            drop(v791_2);
            let v791_10: Space = if map_kernels::has_head(&(v791_9)) { singleton(&[]) } else { Space::new() };
            drop(v791_9);
            let v791_12: Space = if (&(v791_10)).is_empty() { Space::new() } else {
              let v793_6: Path = concat_path(&(v790_6),&v776_28_cursor.path()[(v776_28_origin + 2)..(v776_28_origin + 3)]);
              let v793_11: Space = routine_53(c, &(v793_6), &(*p1), &v776_28_cursor, &(*s1));
              drop(v793_6);
              map_map_kernels::compose(&(v791_10),&(v793_11))
            };
            drop(v791_10);
            let v791_13: Space = map_map_kernels::unite(&(v791_8),&(v791_12));
            join_wrapped_into(&mut v790_7_write,&((v791_13).read_zipper()),&[]);
            }
            v776_28_cursor.ascend(1);
          }
          drop(v790_7_write);
          drop(v790_6);
          map_map_kernels::compose(&(v789_5),&(v790_7))
        };
        drop(v789_5);
        let v789_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v789_2));
        drop(v789_2);
        let v789_10: Space = if map_kernels::has_head(&(v789_9)) { singleton(&[]) } else { Space::new() };
        drop(v789_9);
        let v789_13: Space = if (&(v789_10)).is_empty() { Space::new() } else {
          let mut v794_12 = Space::new();
          let mut v794_12_write = v794_12.write_zipper();
          let mut v794_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v776_28_cursor.path()[v776_28_origin..(v776_28_origin + 1)]),&v776_28_cursor.path()[(v776_28_origin + 1)..(v776_28_origin + 2)]);
          let v794_12_origin = v794_12_cursor.path().len();
          for v794_12_byte in v794_12_cursor.child_mask().iter() {
            v794_12_cursor.descend_to_existing_byte(v794_12_byte);
            {
            let v795_2: Space = singleton(&v794_12_cursor.path()[v794_12_origin..(v794_12_origin + 1)]);
            let v795_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v795_2));
            let v795_4: Space = if map_kernels::has_head(&(v795_3)) { singleton(&[]) } else { Space::new() };
            drop(v795_3);
            let v795_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v795_4));
            drop(v795_4);
            let v795_7: Space = if (&(v795_5)).is_empty() { Space::new() } else {
              let v796_6: Space = routine_13(c, &v794_12_cursor.path()[v794_12_origin..(v794_12_origin + 1)], &(*p1), &v794_12_cursor);
              map_map_kernels::compose(&(v795_5),&(v796_6))
            };
            drop(v795_5);
            let v795_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v795_2));
            drop(v795_2);
            let v795_9: Space = if map_kernels::has_head(&(v795_8)) { singleton(&[]) } else { Space::new() };
            drop(v795_8);
            let v795_11: Space = if (&(v795_9)).is_empty() { Space::new() } else {
              let v797_10: Space = routine_14(c, &v794_12_cursor.path()[v794_12_origin..(v794_12_origin + 1)], &(*p1), &v794_12_cursor);
              map_map_kernels::compose(&(v795_9),&(v797_10))
            };
            drop(v795_9);
            let v795_12: Space = map_map_kernels::unite(&(v795_7),&(v795_11));
            join_wrapped_into(&mut v794_12_write,&((v795_12).read_zipper()),&[]);
            }
            v794_12_cursor.ascend(1);
          }
          drop(v794_12_cursor);
          drop(v794_12_write);
          map_map_kernels::compose(&(v789_10),&(v794_12))
        };
        drop(v789_10);
        let v789_14: Space = map_map_kernels::unite(&(v789_8),&(v789_13));
        join_wrapped_into(&mut v788_12_write,&((v789_14).read_zipper()),&[]);
        }
        v776_28_cursor.ascend(1);
      }
      drop(v788_12_write);
      drop(v788_6);
      map_map_kernels::compose(&(v777_10),&(v788_12))
    };
    drop(v777_10);
    let v777_14: Space = map_map_kernels::unite(&(v777_8),&(v777_13));
    join_wrapped_into(&mut v776_28_write,&((v777_14).read_zipper()),&[]);
    }
    v776_28_cursor.ascend(1);
  }
  drop(v776_28_cursor);
  drop(v776_28_write);
  (v776_28).clone()
}

fn routine_41(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v798_28 = Space::new();
  let mut v798_28_write = v798_28.write_zipper();
  let mut v798_28_cursor = (*s0).read_zipper();
  let v798_28_origin = v798_28_cursor.path().len();
  for v798_28_byte in v798_28_cursor.child_mask().iter() {
    v798_28_cursor.descend_to_existing_byte(v798_28_byte);
    {
    let v799_2: Space = singleton(&v798_28_cursor.path()[v798_28_origin..(v798_28_origin + 1)]);
    let v799_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v799_2));
    let v799_4: Space = if map_kernels::has_head(&(v799_3)) { singleton(&[]) } else { Space::new() };
    drop(v799_3);
    let v799_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v799_4));
    drop(v799_4);
    let v799_8: Space = if (&(v799_5)).is_empty() { Space::new() } else {
      let v800_6: Path = concat_path(&(*p0),&v798_28_cursor.path()[v798_28_origin..(v798_28_origin + 1)]);
      let mut v800_7 = Space::new();
      let mut v800_7_write = v800_7.write_zipper();
      for v800_7_byte in v798_28_cursor.child_mask().iter() {
        v798_28_cursor.descend_to_existing_byte(v800_7_byte);
        {
        let v801_2: Space = singleton(&v798_28_cursor.path()[(v798_28_origin + 1)..(v798_28_origin + 2)]);
        let v801_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v801_2));
        let v801_4: Space = if map_kernels::has_head(&(v801_3)) { singleton(&[]) } else { Space::new() };
        drop(v801_3);
        let v801_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v801_4));
        drop(v801_4);
        let v801_8: Space = if (&(v801_5)).is_empty() { Space::new() } else {
          let v802_6: Path = concat_path(&(v800_6),&v798_28_cursor.path()[(v798_28_origin + 1)..(v798_28_origin + 2)]);
          let mut v802_7 = Space::new();
          let mut v802_7_write = v802_7.write_zipper();
          for v802_7_byte in v798_28_cursor.child_mask().iter() {
            v798_28_cursor.descend_to_existing_byte(v802_7_byte);
            {
            let v803_2: Space = singleton(&v798_28_cursor.path()[(v798_28_origin + 2)..(v798_28_origin + 3)]);
            let v803_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v803_2));
            let v803_4: Space = if map_kernels::has_head(&(v803_3)) { singleton(&[]) } else { Space::new() };
            drop(v803_3);
            let v803_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v803_4));
            drop(v803_4);
            let v803_8: Space = if (&(v803_5)).is_empty() { Space::new() } else {
              let v804_6: Path = concat_path(&(v802_6),&v798_28_cursor.path()[(v798_28_origin + 2)..(v798_28_origin + 3)]);
              let v804_7: Space = routine_52(c, &(v804_6), &(*p1), &v798_28_cursor, &(*s1));
              map_map_kernels::compose(&(v803_5),&(v804_7))
            };
            drop(v803_5);
            let v803_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v803_2));
            drop(v803_2);
            let v803_10: Space = if map_kernels::has_head(&(v803_9)) { singleton(&[]) } else { Space::new() };
            drop(v803_9);
            let v803_12: Space = if (&(v803_10)).is_empty() { Space::new() } else {
              let v805_6: Path = concat_path(&(v802_6),&v798_28_cursor.path()[(v798_28_origin + 2)..(v798_28_origin + 3)]);
              let v805_11: Space = routine_53(c, &(v805_6), &(*p1), &v798_28_cursor, &(*s1));
              drop(v805_6);
              map_map_kernels::compose(&(v803_10),&(v805_11))
            };
            drop(v803_10);
            let v803_13: Space = map_map_kernels::unite(&(v803_8),&(v803_12));
            join_wrapped_into(&mut v802_7_write,&((v803_13).read_zipper()),&[]);
            }
            v798_28_cursor.ascend(1);
          }
          drop(v802_7_write);
          map_map_kernels::compose(&(v801_5),&(v802_7))
        };
        drop(v801_5);
        let v801_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v801_2));
        drop(v801_2);
        let v801_10: Space = if map_kernels::has_head(&(v801_9)) { singleton(&[]) } else { Space::new() };
        drop(v801_9);
        let v801_12: Space = if (&(v801_10)).is_empty() { Space::new() } else {
          let v806_6: Path = concat_path(&(v800_6),&v798_28_cursor.path()[(v798_28_origin + 1)..(v798_28_origin + 2)]);
          let mut v806_11 = Space::new();
          let mut v806_11_write = v806_11.write_zipper();
          for v806_11_byte in v798_28_cursor.child_mask().iter() {
            v798_28_cursor.descend_to_existing_byte(v806_11_byte);
            {
            let v807_2: Space = singleton(&v798_28_cursor.path()[(v798_28_origin + 2)..(v798_28_origin + 3)]);
            let v807_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v807_2));
            let v807_4: Space = if map_kernels::has_head(&(v807_3)) { singleton(&[]) } else { Space::new() };
            drop(v807_3);
            let v807_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v807_4));
            drop(v807_4);
            let v807_8: Space = if (&(v807_5)).is_empty() { Space::new() } else {
              let v808_6: Path = concat_path(&(v806_6),&v798_28_cursor.path()[(v798_28_origin + 2)..(v798_28_origin + 3)]);
              let v808_7: Space = routine_52(c, &(v808_6), &(*p1), &v798_28_cursor, &(*s1));
              map_map_kernels::compose(&(v807_5),&(v808_7))
            };
            drop(v807_5);
            let v807_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v807_2));
            drop(v807_2);
            let v807_10: Space = if map_kernels::has_head(&(v807_9)) { singleton(&[]) } else { Space::new() };
            drop(v807_9);
            let v807_12: Space = if (&(v807_10)).is_empty() { Space::new() } else {
              let v809_6: Path = concat_path(&(v806_6),&v798_28_cursor.path()[(v798_28_origin + 2)..(v798_28_origin + 3)]);
              let v809_11: Space = routine_10(c, &(v809_6), &(*p1), &v798_28_cursor, &(*s1));
              drop(v809_6);
              map_map_kernels::compose(&(v807_10),&(v809_11))
            };
            drop(v807_10);
            let v807_13: Space = map_map_kernels::unite(&(v807_8),&(v807_12));
            join_wrapped_into(&mut v806_11_write,&((v807_13).read_zipper()),&[]);
            }
            v798_28_cursor.ascend(1);
          }
          drop(v806_11_write);
          drop(v806_6);
          map_map_kernels::compose(&(v801_10),&(v806_11))
        };
        drop(v801_10);
        let v801_13: Space = map_map_kernels::unite(&(v801_8),&(v801_12));
        join_wrapped_into(&mut v800_7_write,&((v801_13).read_zipper()),&[]);
        }
        v798_28_cursor.ascend(1);
      }
      drop(v800_7_write);
      drop(v800_6);
      map_map_kernels::compose(&(v799_5),&(v800_7))
    };
    drop(v799_5);
    let v799_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v799_2));
    drop(v799_2);
    let v799_10: Space = if map_kernels::has_head(&(v799_9)) { singleton(&[]) } else { Space::new() };
    drop(v799_9);
    let v799_13: Space = if (&(v799_10)).is_empty() { Space::new() } else {
      let mut v810_12 = Space::new();
      let mut v810_12_write = v810_12.write_zipper();
      let mut v810_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v798_28_cursor.path()[v798_28_origin..(v798_28_origin + 1)]);
      let v810_12_origin = v810_12_cursor.path().len();
      for v810_12_byte in v810_12_cursor.child_mask().iter() {
        v810_12_cursor.descend_to_existing_byte(v810_12_byte);
        {
        let v811_2: Space = singleton(&v810_12_cursor.path()[v810_12_origin..(v810_12_origin + 1)]);
        let v811_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v811_2));
        let v811_4: Space = if map_kernels::has_head(&(v811_3)) { singleton(&[]) } else { Space::new() };
        drop(v811_3);
        let v811_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v811_4));
        drop(v811_4);
        let v811_7: Space = if (&(v811_5)).is_empty() { Space::new() } else {
          let mut v812_6 = Space::new();
          let mut v812_6_write = v812_6.write_zipper();
          for v812_6_byte in v810_12_cursor.child_mask().iter() {
            v810_12_cursor.descend_to_existing_byte(v812_6_byte);
            {
            let v813_2: Space = singleton(&v810_12_cursor.path()[(v810_12_origin + 1)..(v810_12_origin + 2)]);
            let v813_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v813_2));
            let v813_4: Space = if map_kernels::has_head(&(v813_3)) { singleton(&[]) } else { Space::new() };
            drop(v813_3);
            let v813_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v813_4));
            drop(v813_4);
            let v813_8: Space = if (&(v813_5)).is_empty() { Space::new() } else {
              let v814_7: Space = routine_17(c, &v810_12_cursor.path()[v810_12_origin..(v810_12_origin + 2)], &(*p1), &v810_12_cursor);
              map_map_kernels::compose(&(v813_5),&(v814_7))
            };
            drop(v813_5);
            let v813_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v813_2));
            drop(v813_2);
            let v813_10: Space = if map_kernels::has_head(&(v813_9)) { singleton(&[]) } else { Space::new() };
            drop(v813_9);
            let v813_12: Space = if (&(v813_10)).is_empty() { Space::new() } else {
              let v815_11: Space = routine_18(c, &v810_12_cursor.path()[v810_12_origin..(v810_12_origin + 2)], &(*p1), &v810_12_cursor);
              map_map_kernels::compose(&(v813_10),&(v815_11))
            };
            drop(v813_10);
            let v813_13: Space = map_map_kernels::unite(&(v813_8),&(v813_12));
            join_wrapped_into(&mut v812_6_write,&((v813_13).read_zipper()),&[]);
            }
            v810_12_cursor.ascend(1);
          }
          drop(v812_6_write);
          map_map_kernels::compose(&(v811_5),&(v812_6))
        };
        drop(v811_5);
        let v811_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v811_2));
        drop(v811_2);
        let v811_9: Space = if map_kernels::has_head(&(v811_8)) { singleton(&[]) } else { Space::new() };
        drop(v811_8);
        let v811_11: Space = if (&(v811_9)).is_empty() { Space::new() } else {
          let mut v816_10 = Space::new();
          let mut v816_10_write = v816_10.write_zipper();
          for v816_10_byte in v810_12_cursor.child_mask().iter() {
            v810_12_cursor.descend_to_existing_byte(v816_10_byte);
            {
            let v817_2: Space = singleton(&v810_12_cursor.path()[(v810_12_origin + 1)..(v810_12_origin + 2)]);
            let v817_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v817_2));
            let v817_4: Space = if map_kernels::has_head(&(v817_3)) { singleton(&[]) } else { Space::new() };
            drop(v817_3);
            let v817_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v817_4));
            drop(v817_4);
            let v817_8: Space = if (&(v817_5)).is_empty() { Space::new() } else {
              let v818_7: Space = routine_17(c, &v810_12_cursor.path()[v810_12_origin..(v810_12_origin + 2)], &(*p1), &v810_12_cursor);
              map_map_kernels::compose(&(v817_5),&(v818_7))
            };
            drop(v817_5);
            let v817_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v817_2));
            drop(v817_2);
            let v817_10: Space = if map_kernels::has_head(&(v817_9)) { singleton(&[]) } else { Space::new() };
            drop(v817_9);
            let v817_12: Space = if (&(v817_10)).is_empty() { Space::new() } else {
              let v819_11: Space = routine_19(c, &v810_12_cursor.path()[v810_12_origin..(v810_12_origin + 2)], &(*p1), &v810_12_cursor);
              map_map_kernels::compose(&(v817_10),&(v819_11))
            };
            drop(v817_10);
            let v817_13: Space = map_map_kernels::unite(&(v817_8),&(v817_12));
            join_wrapped_into(&mut v816_10_write,&((v817_13).read_zipper()),&[]);
            }
            v810_12_cursor.ascend(1);
          }
          drop(v816_10_write);
          map_map_kernels::compose(&(v811_9),&(v816_10))
        };
        drop(v811_9);
        let v811_12: Space = map_map_kernels::unite(&(v811_7),&(v811_11));
        join_wrapped_into(&mut v810_12_write,&((v811_12).read_zipper()),&[]);
        }
        v810_12_cursor.ascend(1);
      }
      drop(v810_12_cursor);
      drop(v810_12_write);
      map_map_kernels::compose(&(v799_10),&(v810_12))
    };
    drop(v799_10);
    let v799_14: Space = map_map_kernels::unite(&(v799_8),&(v799_13));
    join_wrapped_into(&mut v798_28_write,&((v799_14).read_zipper()),&[]);
    }
    v798_28_cursor.ascend(1);
  }
  drop(v798_28_cursor);
  drop(v798_28_write);
  (v798_28).clone()
}

fn routine_42(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v820_21 = Space::new();
  let mut v820_21_write = v820_21.write_zipper();
  let mut v820_21_cursor = (*s0).read_zipper();
  let v820_21_origin = v820_21_cursor.path().len();
  for v820_21_byte in v820_21_cursor.child_mask().iter() {
    v820_21_cursor.descend_to_existing_byte(v820_21_byte);
    {
    let v821_2: Space = singleton(&v820_21_cursor.path()[v820_21_origin..(v820_21_origin + 1)]);
    let v821_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v821_2));
    let v821_4: Space = if map_kernels::has_head(&(v821_3)) { singleton(&[]) } else { Space::new() };
    drop(v821_3);
    let v821_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v821_4));
    drop(v821_4);
    let v821_8: Space = if (&(v821_5)).is_empty() { Space::new() } else {
      let v822_6: Path = concat_path(&(*p0),&v820_21_cursor.path()[v820_21_origin..(v820_21_origin + 1)]);
      let mut v822_7 = Space::new();
      let mut v822_7_write = v822_7.write_zipper();
      for v822_7_byte in v820_21_cursor.child_mask().iter() {
        v820_21_cursor.descend_to_existing_byte(v822_7_byte);
        {
        let v823_2: Space = singleton(&v820_21_cursor.path()[(v820_21_origin + 1)..(v820_21_origin + 2)]);
        let v823_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v823_2));
        let v823_4: Space = if map_kernels::has_head(&(v823_3)) { singleton(&[]) } else { Space::new() };
        drop(v823_3);
        let v823_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v823_4));
        drop(v823_4);
        let v823_8: Space = if (&(v823_5)).is_empty() { Space::new() } else {
          let v824_6: Path = concat_path(&(v822_6),&v820_21_cursor.path()[(v820_21_origin + 1)..(v820_21_origin + 2)]);
          let mut v824_7 = Space::new();
          let mut v824_7_write = v824_7.write_zipper();
          for v824_7_byte in v820_21_cursor.child_mask().iter() {
            v820_21_cursor.descend_to_existing_byte(v824_7_byte);
            {
            let v825_2: Space = singleton(&v820_21_cursor.path()[(v820_21_origin + 2)..(v820_21_origin + 3)]);
            let v825_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v825_2));
            let v825_4: Space = if map_kernels::has_head(&(v825_3)) { singleton(&[]) } else { Space::new() };
            drop(v825_3);
            let v825_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v825_4));
            drop(v825_4);
            let v825_8: Space = if (&(v825_5)).is_empty() { Space::new() } else {
              let v826_6: Path = concat_path(&(v824_6),&v820_21_cursor.path()[(v820_21_origin + 2)..(v820_21_origin + 3)]);
              let v826_7: Space = routine_54(c, &(v826_6), &(*p1), &v820_21_cursor);
              map_map_kernels::compose(&(v825_5),&(v826_7))
            };
            drop(v825_5);
            let v825_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v825_2));
            drop(v825_2);
            let v825_10: Space = if map_kernels::has_head(&(v825_9)) { singleton(&[]) } else { Space::new() };
            drop(v825_9);
            let v825_12: Space = if (&(v825_10)).is_empty() { Space::new() } else {
              let v827_6: Path = concat_path(&(v824_6),&v820_21_cursor.path()[(v820_21_origin + 2)..(v820_21_origin + 3)]);
              let v827_11: Space = routine_55(c, &(v827_6), &(*p1), &v820_21_cursor);
              drop(v827_6);
              map_map_kernels::compose(&(v825_10),&(v827_11))
            };
            drop(v825_10);
            let v825_13: Space = map_map_kernels::unite(&(v825_8),&(v825_12));
            join_wrapped_into(&mut v824_7_write,&((v825_13).read_zipper()),&[]);
            }
            v820_21_cursor.ascend(1);
          }
          drop(v824_7_write);
          map_map_kernels::compose(&(v823_5),&(v824_7))
        };
        drop(v823_5);
        let v823_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v823_2));
        drop(v823_2);
        let v823_10: Space = if map_kernels::has_head(&(v823_9)) { singleton(&[]) } else { Space::new() };
        drop(v823_9);
        let v823_12: Space = if (&(v823_10)).is_empty() { Space::new() } else {
          let v828_6: Path = concat_path(&(v822_6),&v820_21_cursor.path()[(v820_21_origin + 1)..(v820_21_origin + 2)]);
          let mut v828_11 = Space::new();
          let mut v828_11_write = v828_11.write_zipper();
          for v828_11_byte in v820_21_cursor.child_mask().iter() {
            v820_21_cursor.descend_to_existing_byte(v828_11_byte);
            {
            let v829_2: Space = singleton(&v820_21_cursor.path()[(v820_21_origin + 2)..(v820_21_origin + 3)]);
            let v829_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v829_2));
            let v829_4: Space = if map_kernels::has_head(&(v829_3)) { singleton(&[]) } else { Space::new() };
            drop(v829_3);
            let v829_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v829_4));
            drop(v829_4);
            let v829_8: Space = if (&(v829_5)).is_empty() { Space::new() } else {
              let v830_6: Path = concat_path(&(v828_6),&v820_21_cursor.path()[(v820_21_origin + 2)..(v820_21_origin + 3)]);
              let v830_7: Space = routine_54(c, &(v830_6), &(*p1), &v820_21_cursor);
              map_map_kernels::compose(&(v829_5),&(v830_7))
            };
            drop(v829_5);
            let v829_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v829_2));
            drop(v829_2);
            let v829_10: Space = if map_kernels::has_head(&(v829_9)) { singleton(&[]) } else { Space::new() };
            drop(v829_9);
            let v829_12: Space = if (&(v829_10)).is_empty() { Space::new() } else {
              let v831_6: Path = concat_path(&(v828_6),&v820_21_cursor.path()[(v820_21_origin + 2)..(v820_21_origin + 3)]);
              let v831_11: Space = routine_19(c, &(v831_6), &(*p1), &v820_21_cursor);
              drop(v831_6);
              map_map_kernels::compose(&(v829_10),&(v831_11))
            };
            drop(v829_10);
            let v829_13: Space = map_map_kernels::unite(&(v829_8),&(v829_12));
            join_wrapped_into(&mut v828_11_write,&((v829_13).read_zipper()),&[]);
            }
            v820_21_cursor.ascend(1);
          }
          drop(v828_11_write);
          drop(v828_6);
          map_map_kernels::compose(&(v823_10),&(v828_11))
        };
        drop(v823_10);
        let v823_13: Space = map_map_kernels::unite(&(v823_8),&(v823_12));
        join_wrapped_into(&mut v822_7_write,&((v823_13).read_zipper()),&[]);
        }
        v820_21_cursor.ascend(1);
      }
      drop(v822_7_write);
      map_map_kernels::compose(&(v821_5),&(v822_7))
    };
    drop(v821_5);
    let v821_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v821_2));
    drop(v821_2);
    let v821_10: Space = if map_kernels::has_head(&(v821_9)) { singleton(&[]) } else { Space::new() };
    drop(v821_9);
    let v821_12: Space = if (&(v821_10)).is_empty() { Space::new() } else {
      let v832_6: Path = concat_path(&(*p0),&v820_21_cursor.path()[v820_21_origin..(v820_21_origin + 1)]);
      let mut v832_11 = Space::new();
      let mut v832_11_write = v832_11.write_zipper();
      for v832_11_byte in v820_21_cursor.child_mask().iter() {
        v820_21_cursor.descend_to_existing_byte(v832_11_byte);
        {
        let v833_2: Space = singleton(&v820_21_cursor.path()[(v820_21_origin + 1)..(v820_21_origin + 2)]);
        let v833_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v833_2));
        let v833_4: Space = if map_kernels::has_head(&(v833_3)) { singleton(&[]) } else { Space::new() };
        drop(v833_3);
        let v833_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v833_4));
        drop(v833_4);
        let v833_8: Space = if (&(v833_5)).is_empty() { Space::new() } else {
          let v834_6: Path = concat_path(&(v832_6),&v820_21_cursor.path()[(v820_21_origin + 1)..(v820_21_origin + 2)]);
          let mut v834_7 = Space::new();
          let mut v834_7_write = v834_7.write_zipper();
          for v834_7_byte in v820_21_cursor.child_mask().iter() {
            v820_21_cursor.descend_to_existing_byte(v834_7_byte);
            {
            let v835_2: Space = singleton(&v820_21_cursor.path()[(v820_21_origin + 2)..(v820_21_origin + 3)]);
            let v835_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v835_2));
            let v835_4: Space = if map_kernels::has_head(&(v835_3)) { singleton(&[]) } else { Space::new() };
            drop(v835_3);
            let v835_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v835_4));
            drop(v835_4);
            let v835_8: Space = if (&(v835_5)).is_empty() { Space::new() } else {
              let v836_6: Path = concat_path(&(v834_6),&v820_21_cursor.path()[(v820_21_origin + 2)..(v820_21_origin + 3)]);
              let v836_7: Space = routine_54(c, &(v836_6), &(*p1), &v820_21_cursor);
              map_map_kernels::compose(&(v835_5),&(v836_7))
            };
            drop(v835_5);
            let v835_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v835_2));
            drop(v835_2);
            let v835_10: Space = if map_kernels::has_head(&(v835_9)) { singleton(&[]) } else { Space::new() };
            drop(v835_9);
            let v835_12: Space = if (&(v835_10)).is_empty() { Space::new() } else {
              let v837_6: Path = concat_path(&(v834_6),&v820_21_cursor.path()[(v820_21_origin + 2)..(v820_21_origin + 3)]);
              let v837_11: Space = routine_55(c, &(v837_6), &(*p1), &v820_21_cursor);
              drop(v837_6);
              map_map_kernels::compose(&(v835_10),&(v837_11))
            };
            drop(v835_10);
            let v835_13: Space = map_map_kernels::unite(&(v835_8),&(v835_12));
            join_wrapped_into(&mut v834_7_write,&((v835_13).read_zipper()),&[]);
            }
            v820_21_cursor.ascend(1);
          }
          drop(v834_7_write);
          map_map_kernels::compose(&(v833_5),&(v834_7))
        };
        drop(v833_5);
        let v833_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v833_2));
        drop(v833_2);
        let v833_10: Space = if map_kernels::has_head(&(v833_9)) { singleton(&[]) } else { Space::new() };
        drop(v833_9);
        let v833_11: Space = map_view_kernels::compose(&(v833_10),&v820_21_cursor);
        drop(v833_10);
        let v838_6: Path = concat_path(&(v832_6),&v820_21_cursor.path()[(v820_21_origin + 1)..(v820_21_origin + 2)]);
        let v833_12: Space = map_kernels::wrap(&(v833_11),&(v838_6));
        drop(v833_11);
        let v833_13: Space = map_kernels::wrap(&(v833_12),&(*p1));
        drop(v833_12);
        let v833_14: Space = map_map_kernels::unite(&(v833_8),&(v833_13));
        drop(v833_13);
        join_wrapped_into(&mut v832_11_write,&((v833_14).read_zipper()),&[]);
        }
        v820_21_cursor.ascend(1);
      }
      drop(v832_11_write);
      drop(v832_6);
      map_map_kernels::compose(&(v821_10),&(v832_11))
    };
    drop(v821_10);
    let v821_13: Space = map_map_kernels::unite(&(v821_8),&(v821_12));
    join_wrapped_into(&mut v820_21_write,&((v821_13).read_zipper()),&[]);
    }
    v820_21_cursor.ascend(1);
  }
  drop(v820_21_cursor);
  drop(v820_21_write);
  (v820_21).clone()
}

fn routine_43(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v839_15 = Space::new();
  let mut v839_15_write = v839_15.write_zipper();
  let mut v839_15_cursor = (*s0).read_zipper();
  let v839_15_origin = v839_15_cursor.path().len();
  for v839_15_byte in v839_15_cursor.child_mask().iter() {
    v839_15_cursor.descend_to_existing_byte(v839_15_byte);
    {
    let v840_2: Space = singleton(&v839_15_cursor.path()[v839_15_origin..(v839_15_origin + 1)]);
    let v840_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v840_2));
    let v840_4: Space = if map_kernels::has_head(&(v840_3)) { singleton(&[]) } else { Space::new() };
    drop(v840_3);
    let v840_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v840_4));
    drop(v840_4);
    let v840_8: Space = if (&(v840_5)).is_empty() { Space::new() } else {
      let v841_6: Path = concat_path(&(*p0),&v839_15_cursor.path()[v839_15_origin..(v839_15_origin + 1)]);
      let mut v841_7 = Space::new();
      let mut v841_7_write = v841_7.write_zipper();
      for v841_7_byte in v839_15_cursor.child_mask().iter() {
        v839_15_cursor.descend_to_existing_byte(v841_7_byte);
        {
        let v842_2: Space = singleton(&v839_15_cursor.path()[(v839_15_origin + 1)..(v839_15_origin + 2)]);
        let v842_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v842_2));
        let v842_4: Space = if map_kernels::has_head(&(v842_3)) { singleton(&[]) } else { Space::new() };
        drop(v842_3);
        let v842_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v842_4));
        drop(v842_4);
        let v842_8: Space = if (&(v842_5)).is_empty() { Space::new() } else {
          let v843_6: Path = concat_path(&(v841_6),&v839_15_cursor.path()[(v839_15_origin + 1)..(v839_15_origin + 2)]);
          let mut v843_7 = Space::new();
          let mut v843_7_write = v843_7.write_zipper();
          for v843_7_byte in v839_15_cursor.child_mask().iter() {
            v839_15_cursor.descend_to_existing_byte(v843_7_byte);
            {
            let v844_2: Space = singleton(&v839_15_cursor.path()[(v839_15_origin + 2)..(v839_15_origin + 3)]);
            let v844_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v844_2));
            let v844_4: Space = if map_kernels::has_head(&(v844_3)) { singleton(&[]) } else { Space::new() };
            drop(v844_3);
            let v844_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v844_4));
            drop(v844_4);
            let v844_8: Space = if (&(v844_5)).is_empty() { Space::new() } else {
              let v845_6: Path = concat_path(&(v843_6),&v839_15_cursor.path()[(v839_15_origin + 2)..(v839_15_origin + 3)]);
              let v845_7: Space = routine_54(c, &(v845_6), &(*p1), &v839_15_cursor);
              map_map_kernels::compose(&(v844_5),&(v845_7))
            };
            drop(v844_5);
            let v844_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v844_2));
            drop(v844_2);
            let v844_10: Space = if map_kernels::has_head(&(v844_9)) { singleton(&[]) } else { Space::new() };
            drop(v844_9);
            let v844_12: Space = if (&(v844_10)).is_empty() { Space::new() } else {
              let v846_6: Path = concat_path(&(v843_6),&v839_15_cursor.path()[(v839_15_origin + 2)..(v839_15_origin + 3)]);
              let v846_11: Space = routine_55(c, &(v846_6), &(*p1), &v839_15_cursor);
              drop(v846_6);
              map_map_kernels::compose(&(v844_10),&(v846_11))
            };
            drop(v844_10);
            let v844_13: Space = map_map_kernels::unite(&(v844_8),&(v844_12));
            join_wrapped_into(&mut v843_7_write,&((v844_13).read_zipper()),&[]);
            }
            v839_15_cursor.ascend(1);
          }
          drop(v843_7_write);
          map_map_kernels::compose(&(v842_5),&(v843_7))
        };
        drop(v842_5);
        let v842_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v842_2));
        drop(v842_2);
        let v842_10: Space = if map_kernels::has_head(&(v842_9)) { singleton(&[]) } else { Space::new() };
        drop(v842_9);
        let v842_12: Space = if (&(v842_10)).is_empty() { Space::new() } else {
          let v847_6: Path = concat_path(&(v841_6),&v839_15_cursor.path()[(v839_15_origin + 1)..(v839_15_origin + 2)]);
          let mut v847_11 = Space::new();
          let mut v847_11_write = v847_11.write_zipper();
          for v847_11_byte in v839_15_cursor.child_mask().iter() {
            v839_15_cursor.descend_to_existing_byte(v847_11_byte);
            {
            let v848_2: Space = singleton(&v839_15_cursor.path()[(v839_15_origin + 2)..(v839_15_origin + 3)]);
            let v848_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v848_2));
            let v848_4: Space = if map_kernels::has_head(&(v848_3)) { singleton(&[]) } else { Space::new() };
            drop(v848_3);
            let v848_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v848_4));
            drop(v848_4);
            let v848_8: Space = if (&(v848_5)).is_empty() { Space::new() } else {
              let v849_6: Path = concat_path(&(v847_6),&v839_15_cursor.path()[(v839_15_origin + 2)..(v839_15_origin + 3)]);
              let v849_7: Space = routine_54(c, &(v849_6), &(*p1), &v839_15_cursor);
              map_map_kernels::compose(&(v848_5),&(v849_7))
            };
            drop(v848_5);
            let v848_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v848_2));
            drop(v848_2);
            let v848_10: Space = if map_kernels::has_head(&(v848_9)) { singleton(&[]) } else { Space::new() };
            drop(v848_9);
            let v848_12: Space = if (&(v848_10)).is_empty() { Space::new() } else {
              let v850_6: Path = concat_path(&(v847_6),&v839_15_cursor.path()[(v839_15_origin + 2)..(v839_15_origin + 3)]);
              let v850_11: Space = routine_19(c, &(v850_6), &(*p1), &v839_15_cursor);
              drop(v850_6);
              map_map_kernels::compose(&(v848_10),&(v850_11))
            };
            drop(v848_10);
            let v848_13: Space = map_map_kernels::unite(&(v848_8),&(v848_12));
            join_wrapped_into(&mut v847_11_write,&((v848_13).read_zipper()),&[]);
            }
            v839_15_cursor.ascend(1);
          }
          drop(v847_11_write);
          drop(v847_6);
          map_map_kernels::compose(&(v842_10),&(v847_11))
        };
        drop(v842_10);
        let v842_13: Space = map_map_kernels::unite(&(v842_8),&(v842_12));
        join_wrapped_into(&mut v841_7_write,&((v842_13).read_zipper()),&[]);
        }
        v839_15_cursor.ascend(1);
      }
      drop(v841_7_write);
      map_map_kernels::compose(&(v840_5),&(v841_7))
    };
    drop(v840_5);
    let v840_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v840_2));
    drop(v840_2);
    let v840_10: Space = if map_kernels::has_head(&(v840_9)) { singleton(&[]) } else { Space::new() };
    drop(v840_9);
    let v840_11: Space = map_view_kernels::compose(&(v840_10),&v839_15_cursor);
    drop(v840_10);
    let v851_6: Path = concat_path(&(*p0),&v839_15_cursor.path()[v839_15_origin..(v839_15_origin + 1)]);
    let v840_12: Space = map_kernels::wrap(&(v840_11),&(v851_6));
    drop(v840_11);
    let v840_13: Space = map_kernels::wrap(&(v840_12),&(*p1));
    drop(v840_12);
    let v840_14: Space = map_map_kernels::unite(&(v840_8),&(v840_13));
    drop(v840_13);
    join_wrapped_into(&mut v839_15_write,&((v840_14).read_zipper()),&[]);
    }
    v839_15_cursor.ascend(1);
  }
  drop(v839_15_cursor);
  drop(v839_15_write);
  (v839_15).clone()
}

fn routine_44(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v852_28 = Space::new();
  let mut v852_28_write = v852_28.write_zipper();
  let mut v852_28_cursor = (*s0).read_zipper();
  let v852_28_origin = v852_28_cursor.path().len();
  for v852_28_byte in v852_28_cursor.child_mask().iter() {
    v852_28_cursor.descend_to_existing_byte(v852_28_byte);
    {
    let v853_2: Space = singleton(&v852_28_cursor.path()[v852_28_origin..(v852_28_origin + 1)]);
    let v853_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v853_2));
    let v853_4: Space = if map_kernels::has_head(&(v853_3)) { singleton(&[]) } else { Space::new() };
    drop(v853_3);
    let v853_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v853_4));
    drop(v853_4);
    let v853_8: Space = if (&(v853_5)).is_empty() { Space::new() } else {
      let v854_6: Path = concat_path(&(*p0),&v852_28_cursor.path()[v852_28_origin..(v852_28_origin + 1)]);
      let mut v854_7 = Space::new();
      let mut v854_7_write = v854_7.write_zipper();
      for v854_7_byte in v852_28_cursor.child_mask().iter() {
        v852_28_cursor.descend_to_existing_byte(v854_7_byte);
        {
        let v855_2: Space = singleton(&v852_28_cursor.path()[(v852_28_origin + 1)..(v852_28_origin + 2)]);
        let v855_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v855_2));
        let v855_4: Space = if map_kernels::has_head(&(v855_3)) { singleton(&[]) } else { Space::new() };
        drop(v855_3);
        let v855_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v855_4));
        drop(v855_4);
        let v855_8: Space = if (&(v855_5)).is_empty() { Space::new() } else {
          let v856_6: Path = concat_path(&(v854_6),&v852_28_cursor.path()[(v852_28_origin + 1)..(v852_28_origin + 2)]);
          let mut v856_7 = Space::new();
          let mut v856_7_write = v856_7.write_zipper();
          for v856_7_byte in v852_28_cursor.child_mask().iter() {
            v852_28_cursor.descend_to_existing_byte(v856_7_byte);
            {
            let v857_2: Space = singleton(&v852_28_cursor.path()[(v852_28_origin + 2)..(v852_28_origin + 3)]);
            let v857_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v857_2));
            let v857_4: Space = if map_kernels::has_head(&(v857_3)) { singleton(&[]) } else { Space::new() };
            drop(v857_3);
            let v857_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v857_4));
            drop(v857_4);
            let v857_8: Space = if (&(v857_5)).is_empty() { Space::new() } else {
              let v858_6: Path = concat_path(&(v856_6),&v852_28_cursor.path()[(v852_28_origin + 2)..(v852_28_origin + 3)]);
              let v858_7: Space = routine_56(c, &(v858_6), &(*p1), &v852_28_cursor, &(*s1));
              map_map_kernels::compose(&(v857_5),&(v858_7))
            };
            drop(v857_5);
            let v857_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v857_2));
            drop(v857_2);
            let v857_10: Space = if map_kernels::has_head(&(v857_9)) { singleton(&[]) } else { Space::new() };
            drop(v857_9);
            let v857_12: Space = if (&(v857_10)).is_empty() { Space::new() } else {
              let v859_6: Path = concat_path(&(v856_6),&v852_28_cursor.path()[(v852_28_origin + 2)..(v852_28_origin + 3)]);
              let v859_11: Space = routine_57(c, &(v859_6), &(*p1), &v852_28_cursor, &(*s1));
              drop(v859_6);
              map_map_kernels::compose(&(v857_10),&(v859_11))
            };
            drop(v857_10);
            let v857_13: Space = map_map_kernels::unite(&(v857_8),&(v857_12));
            join_wrapped_into(&mut v856_7_write,&((v857_13).read_zipper()),&[]);
            }
            v852_28_cursor.ascend(1);
          }
          drop(v856_7_write);
          map_map_kernels::compose(&(v855_5),&(v856_7))
        };
        drop(v855_5);
        let v855_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v855_2));
        drop(v855_2);
        let v855_10: Space = if map_kernels::has_head(&(v855_9)) { singleton(&[]) } else { Space::new() };
        drop(v855_9);
        let v855_12: Space = if (&(v855_10)).is_empty() { Space::new() } else {
          let v860_6: Path = concat_path(&(v854_6),&v852_28_cursor.path()[(v852_28_origin + 1)..(v852_28_origin + 2)]);
          let mut v860_11 = Space::new();
          let mut v860_11_write = v860_11.write_zipper();
          for v860_11_byte in v852_28_cursor.child_mask().iter() {
            v852_28_cursor.descend_to_existing_byte(v860_11_byte);
            {
            let v861_2: Space = singleton(&v852_28_cursor.path()[(v852_28_origin + 2)..(v852_28_origin + 3)]);
            let v861_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v861_2));
            let v861_4: Space = if map_kernels::has_head(&(v861_3)) { singleton(&[]) } else { Space::new() };
            drop(v861_3);
            let v861_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v861_4));
            drop(v861_4);
            let v861_8: Space = if (&(v861_5)).is_empty() { Space::new() } else {
              let v862_6: Path = concat_path(&(v860_6),&v852_28_cursor.path()[(v852_28_origin + 2)..(v852_28_origin + 3)]);
              let v862_7: Space = routine_56(c, &(v862_6), &(*p1), &v852_28_cursor, &(*s1));
              map_map_kernels::compose(&(v861_5),&(v862_7))
            };
            drop(v861_5);
            let v861_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v861_2));
            drop(v861_2);
            let v861_10: Space = if map_kernels::has_head(&(v861_9)) { singleton(&[]) } else { Space::new() };
            drop(v861_9);
            let v861_12: Space = if (&(v861_10)).is_empty() { Space::new() } else {
              let v863_6: Path = concat_path(&(v860_6),&v852_28_cursor.path()[(v852_28_origin + 2)..(v852_28_origin + 3)]);
              let v863_11: Space = routine_10(c, &(v863_6), &(*p1), &v852_28_cursor, &(*s1));
              drop(v863_6);
              map_map_kernels::compose(&(v861_10),&(v863_11))
            };
            drop(v861_10);
            let v861_13: Space = map_map_kernels::unite(&(v861_8),&(v861_12));
            join_wrapped_into(&mut v860_11_write,&((v861_13).read_zipper()),&[]);
            }
            v852_28_cursor.ascend(1);
          }
          drop(v860_11_write);
          drop(v860_6);
          map_map_kernels::compose(&(v855_10),&(v860_11))
        };
        drop(v855_10);
        let v855_13: Space = map_map_kernels::unite(&(v855_8),&(v855_12));
        join_wrapped_into(&mut v854_7_write,&((v855_13).read_zipper()),&[]);
        }
        v852_28_cursor.ascend(1);
      }
      drop(v854_7_write);
      map_map_kernels::compose(&(v853_5),&(v854_7))
    };
    drop(v853_5);
    let v853_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v853_2));
    drop(v853_2);
    let v853_10: Space = if map_kernels::has_head(&(v853_9)) { singleton(&[]) } else { Space::new() };
    drop(v853_9);
    let v853_13: Space = if (&(v853_10)).is_empty() { Space::new() } else {
      let v864_6: Path = concat_path(&(*p0),&v852_28_cursor.path()[v852_28_origin..(v852_28_origin + 1)]);
      let mut v864_12 = Space::new();
      let mut v864_12_write = v864_12.write_zipper();
      for v864_12_byte in v852_28_cursor.child_mask().iter() {
        v852_28_cursor.descend_to_existing_byte(v864_12_byte);
        {
        let v865_2: Space = singleton(&v852_28_cursor.path()[(v852_28_origin + 1)..(v852_28_origin + 2)]);
        let v865_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v865_2));
        let v865_4: Space = if map_kernels::has_head(&(v865_3)) { singleton(&[]) } else { Space::new() };
        drop(v865_3);
        let v865_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v865_4));
        drop(v865_4);
        let v865_8: Space = if (&(v865_5)).is_empty() { Space::new() } else {
          let v866_6: Path = concat_path(&(v864_6),&v852_28_cursor.path()[(v852_28_origin + 1)..(v852_28_origin + 2)]);
          let mut v866_7 = Space::new();
          let mut v866_7_write = v866_7.write_zipper();
          for v866_7_byte in v852_28_cursor.child_mask().iter() {
            v852_28_cursor.descend_to_existing_byte(v866_7_byte);
            {
            let v867_2: Space = singleton(&v852_28_cursor.path()[(v852_28_origin + 2)..(v852_28_origin + 3)]);
            let v867_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v867_2));
            let v867_4: Space = if map_kernels::has_head(&(v867_3)) { singleton(&[]) } else { Space::new() };
            drop(v867_3);
            let v867_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v867_4));
            drop(v867_4);
            let v867_8: Space = if (&(v867_5)).is_empty() { Space::new() } else {
              let v868_6: Path = concat_path(&(v866_6),&v852_28_cursor.path()[(v852_28_origin + 2)..(v852_28_origin + 3)]);
              let v868_7: Space = routine_56(c, &(v868_6), &(*p1), &v852_28_cursor, &(*s1));
              map_map_kernels::compose(&(v867_5),&(v868_7))
            };
            drop(v867_5);
            let v867_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v867_2));
            drop(v867_2);
            let v867_10: Space = if map_kernels::has_head(&(v867_9)) { singleton(&[]) } else { Space::new() };
            drop(v867_9);
            let v867_12: Space = if (&(v867_10)).is_empty() { Space::new() } else {
              let v869_6: Path = concat_path(&(v866_6),&v852_28_cursor.path()[(v852_28_origin + 2)..(v852_28_origin + 3)]);
              let v869_11: Space = routine_57(c, &(v869_6), &(*p1), &v852_28_cursor, &(*s1));
              drop(v869_6);
              map_map_kernels::compose(&(v867_10),&(v869_11))
            };
            drop(v867_10);
            let v867_13: Space = map_map_kernels::unite(&(v867_8),&(v867_12));
            join_wrapped_into(&mut v866_7_write,&((v867_13).read_zipper()),&[]);
            }
            v852_28_cursor.ascend(1);
          }
          drop(v866_7_write);
          drop(v866_6);
          map_map_kernels::compose(&(v865_5),&(v866_7))
        };
        drop(v865_5);
        let v865_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v865_2));
        drop(v865_2);
        let v865_10: Space = if map_kernels::has_head(&(v865_9)) { singleton(&[]) } else { Space::new() };
        drop(v865_9);
        let v865_13: Space = if (&(v865_10)).is_empty() { Space::new() } else {
          let mut v870_12 = Space::new();
          let mut v870_12_write = v870_12.write_zipper();
          let mut v870_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v852_28_cursor.path()[v852_28_origin..(v852_28_origin + 1)]),&v852_28_cursor.path()[(v852_28_origin + 1)..(v852_28_origin + 2)]);
          let v870_12_origin = v870_12_cursor.path().len();
          for v870_12_byte in v870_12_cursor.child_mask().iter() {
            v870_12_cursor.descend_to_existing_byte(v870_12_byte);
            {
            let v871_2: Space = singleton(&v870_12_cursor.path()[v870_12_origin..(v870_12_origin + 1)]);
            let v871_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v871_2));
            let v871_4: Space = if map_kernels::has_head(&(v871_3)) { singleton(&[]) } else { Space::new() };
            drop(v871_3);
            let v871_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v871_4));
            drop(v871_4);
            let v871_7: Space = if (&(v871_5)).is_empty() { Space::new() } else {
              let v872_6: Space = routine_13(c, &v870_12_cursor.path()[v870_12_origin..(v870_12_origin + 1)], &(*p1), &v870_12_cursor);
              map_map_kernels::compose(&(v871_5),&(v872_6))
            };
            drop(v871_5);
            let v871_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v871_2));
            drop(v871_2);
            let v871_9: Space = if map_kernels::has_head(&(v871_8)) { singleton(&[]) } else { Space::new() };
            drop(v871_8);
            let v871_11: Space = if (&(v871_9)).is_empty() { Space::new() } else {
              let v873_10: Space = routine_14(c, &v870_12_cursor.path()[v870_12_origin..(v870_12_origin + 1)], &(*p1), &v870_12_cursor);
              map_map_kernels::compose(&(v871_9),&(v873_10))
            };
            drop(v871_9);
            let v871_12: Space = map_map_kernels::unite(&(v871_7),&(v871_11));
            join_wrapped_into(&mut v870_12_write,&((v871_12).read_zipper()),&[]);
            }
            v870_12_cursor.ascend(1);
          }
          drop(v870_12_cursor);
          drop(v870_12_write);
          map_map_kernels::compose(&(v865_10),&(v870_12))
        };
        drop(v865_10);
        let v865_14: Space = map_map_kernels::unite(&(v865_8),&(v865_13));
        join_wrapped_into(&mut v864_12_write,&((v865_14).read_zipper()),&[]);
        }
        v852_28_cursor.ascend(1);
      }
      drop(v864_12_write);
      drop(v864_6);
      map_map_kernels::compose(&(v853_10),&(v864_12))
    };
    drop(v853_10);
    let v853_14: Space = map_map_kernels::unite(&(v853_8),&(v853_13));
    join_wrapped_into(&mut v852_28_write,&((v853_14).read_zipper()),&[]);
    }
    v852_28_cursor.ascend(1);
  }
  drop(v852_28_cursor);
  drop(v852_28_write);
  (v852_28).clone()
}

fn routine_45(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v874_28 = Space::new();
  let mut v874_28_write = v874_28.write_zipper();
  let mut v874_28_cursor = (*s0).read_zipper();
  let v874_28_origin = v874_28_cursor.path().len();
  for v874_28_byte in v874_28_cursor.child_mask().iter() {
    v874_28_cursor.descend_to_existing_byte(v874_28_byte);
    {
    let v875_2: Space = singleton(&v874_28_cursor.path()[v874_28_origin..(v874_28_origin + 1)]);
    let v875_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v875_2));
    let v875_4: Space = if map_kernels::has_head(&(v875_3)) { singleton(&[]) } else { Space::new() };
    drop(v875_3);
    let v875_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v875_4));
    drop(v875_4);
    let v875_8: Space = if (&(v875_5)).is_empty() { Space::new() } else {
      let v876_6: Path = concat_path(&(*p0),&v874_28_cursor.path()[v874_28_origin..(v874_28_origin + 1)]);
      let mut v876_7 = Space::new();
      let mut v876_7_write = v876_7.write_zipper();
      for v876_7_byte in v874_28_cursor.child_mask().iter() {
        v874_28_cursor.descend_to_existing_byte(v876_7_byte);
        {
        let v877_2: Space = singleton(&v874_28_cursor.path()[(v874_28_origin + 1)..(v874_28_origin + 2)]);
        let v877_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v877_2));
        let v877_4: Space = if map_kernels::has_head(&(v877_3)) { singleton(&[]) } else { Space::new() };
        drop(v877_3);
        let v877_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v877_4));
        drop(v877_4);
        let v877_8: Space = if (&(v877_5)).is_empty() { Space::new() } else {
          let v878_6: Path = concat_path(&(v876_6),&v874_28_cursor.path()[(v874_28_origin + 1)..(v874_28_origin + 2)]);
          let mut v878_7 = Space::new();
          let mut v878_7_write = v878_7.write_zipper();
          for v878_7_byte in v874_28_cursor.child_mask().iter() {
            v874_28_cursor.descend_to_existing_byte(v878_7_byte);
            {
            let v879_2: Space = singleton(&v874_28_cursor.path()[(v874_28_origin + 2)..(v874_28_origin + 3)]);
            let v879_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v879_2));
            let v879_4: Space = if map_kernels::has_head(&(v879_3)) { singleton(&[]) } else { Space::new() };
            drop(v879_3);
            let v879_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v879_4));
            drop(v879_4);
            let v879_8: Space = if (&(v879_5)).is_empty() { Space::new() } else {
              let v880_6: Path = concat_path(&(v878_6),&v874_28_cursor.path()[(v874_28_origin + 2)..(v874_28_origin + 3)]);
              let v880_7: Space = routine_56(c, &(v880_6), &(*p1), &v874_28_cursor, &(*s1));
              map_map_kernels::compose(&(v879_5),&(v880_7))
            };
            drop(v879_5);
            let v879_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v879_2));
            drop(v879_2);
            let v879_10: Space = if map_kernels::has_head(&(v879_9)) { singleton(&[]) } else { Space::new() };
            drop(v879_9);
            let v879_12: Space = if (&(v879_10)).is_empty() { Space::new() } else {
              let v881_6: Path = concat_path(&(v878_6),&v874_28_cursor.path()[(v874_28_origin + 2)..(v874_28_origin + 3)]);
              let v881_11: Space = routine_57(c, &(v881_6), &(*p1), &v874_28_cursor, &(*s1));
              drop(v881_6);
              map_map_kernels::compose(&(v879_10),&(v881_11))
            };
            drop(v879_10);
            let v879_13: Space = map_map_kernels::unite(&(v879_8),&(v879_12));
            join_wrapped_into(&mut v878_7_write,&((v879_13).read_zipper()),&[]);
            }
            v874_28_cursor.ascend(1);
          }
          drop(v878_7_write);
          map_map_kernels::compose(&(v877_5),&(v878_7))
        };
        drop(v877_5);
        let v877_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v877_2));
        drop(v877_2);
        let v877_10: Space = if map_kernels::has_head(&(v877_9)) { singleton(&[]) } else { Space::new() };
        drop(v877_9);
        let v877_12: Space = if (&(v877_10)).is_empty() { Space::new() } else {
          let v882_6: Path = concat_path(&(v876_6),&v874_28_cursor.path()[(v874_28_origin + 1)..(v874_28_origin + 2)]);
          let mut v882_11 = Space::new();
          let mut v882_11_write = v882_11.write_zipper();
          for v882_11_byte in v874_28_cursor.child_mask().iter() {
            v874_28_cursor.descend_to_existing_byte(v882_11_byte);
            {
            let v883_2: Space = singleton(&v874_28_cursor.path()[(v874_28_origin + 2)..(v874_28_origin + 3)]);
            let v883_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v883_2));
            let v883_4: Space = if map_kernels::has_head(&(v883_3)) { singleton(&[]) } else { Space::new() };
            drop(v883_3);
            let v883_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v883_4));
            drop(v883_4);
            let v883_8: Space = if (&(v883_5)).is_empty() { Space::new() } else {
              let v884_6: Path = concat_path(&(v882_6),&v874_28_cursor.path()[(v874_28_origin + 2)..(v874_28_origin + 3)]);
              let v884_7: Space = routine_56(c, &(v884_6), &(*p1), &v874_28_cursor, &(*s1));
              map_map_kernels::compose(&(v883_5),&(v884_7))
            };
            drop(v883_5);
            let v883_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v883_2));
            drop(v883_2);
            let v883_10: Space = if map_kernels::has_head(&(v883_9)) { singleton(&[]) } else { Space::new() };
            drop(v883_9);
            let v883_12: Space = if (&(v883_10)).is_empty() { Space::new() } else {
              let v885_6: Path = concat_path(&(v882_6),&v874_28_cursor.path()[(v874_28_origin + 2)..(v874_28_origin + 3)]);
              let v885_11: Space = routine_10(c, &(v885_6), &(*p1), &v874_28_cursor, &(*s1));
              drop(v885_6);
              map_map_kernels::compose(&(v883_10),&(v885_11))
            };
            drop(v883_10);
            let v883_13: Space = map_map_kernels::unite(&(v883_8),&(v883_12));
            join_wrapped_into(&mut v882_11_write,&((v883_13).read_zipper()),&[]);
            }
            v874_28_cursor.ascend(1);
          }
          drop(v882_11_write);
          drop(v882_6);
          map_map_kernels::compose(&(v877_10),&(v882_11))
        };
        drop(v877_10);
        let v877_13: Space = map_map_kernels::unite(&(v877_8),&(v877_12));
        join_wrapped_into(&mut v876_7_write,&((v877_13).read_zipper()),&[]);
        }
        v874_28_cursor.ascend(1);
      }
      drop(v876_7_write);
      drop(v876_6);
      map_map_kernels::compose(&(v875_5),&(v876_7))
    };
    drop(v875_5);
    let v875_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v875_2));
    drop(v875_2);
    let v875_10: Space = if map_kernels::has_head(&(v875_9)) { singleton(&[]) } else { Space::new() };
    drop(v875_9);
    let v875_13: Space = if (&(v875_10)).is_empty() { Space::new() } else {
      let mut v886_12 = Space::new();
      let mut v886_12_write = v886_12.write_zipper();
      let mut v886_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v874_28_cursor.path()[v874_28_origin..(v874_28_origin + 1)]);
      let v886_12_origin = v886_12_cursor.path().len();
      for v886_12_byte in v886_12_cursor.child_mask().iter() {
        v886_12_cursor.descend_to_existing_byte(v886_12_byte);
        {
        let v887_2: Space = singleton(&v886_12_cursor.path()[v886_12_origin..(v886_12_origin + 1)]);
        let v887_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v887_2));
        let v887_4: Space = if map_kernels::has_head(&(v887_3)) { singleton(&[]) } else { Space::new() };
        drop(v887_3);
        let v887_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v887_4));
        drop(v887_4);
        let v887_7: Space = if (&(v887_5)).is_empty() { Space::new() } else {
          let mut v888_6 = Space::new();
          let mut v888_6_write = v888_6.write_zipper();
          for v888_6_byte in v886_12_cursor.child_mask().iter() {
            v886_12_cursor.descend_to_existing_byte(v888_6_byte);
            {
            let v889_2: Space = singleton(&v886_12_cursor.path()[(v886_12_origin + 1)..(v886_12_origin + 2)]);
            let v889_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v889_2));
            let v889_4: Space = if map_kernels::has_head(&(v889_3)) { singleton(&[]) } else { Space::new() };
            drop(v889_3);
            let v889_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v889_4));
            drop(v889_4);
            let v889_8: Space = if (&(v889_5)).is_empty() { Space::new() } else {
              let v890_7: Space = routine_17(c, &v886_12_cursor.path()[v886_12_origin..(v886_12_origin + 2)], &(*p1), &v886_12_cursor);
              map_map_kernels::compose(&(v889_5),&(v890_7))
            };
            drop(v889_5);
            let v889_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v889_2));
            drop(v889_2);
            let v889_10: Space = if map_kernels::has_head(&(v889_9)) { singleton(&[]) } else { Space::new() };
            drop(v889_9);
            let v889_12: Space = if (&(v889_10)).is_empty() { Space::new() } else {
              let v891_11: Space = routine_18(c, &v886_12_cursor.path()[v886_12_origin..(v886_12_origin + 2)], &(*p1), &v886_12_cursor);
              map_map_kernels::compose(&(v889_10),&(v891_11))
            };
            drop(v889_10);
            let v889_13: Space = map_map_kernels::unite(&(v889_8),&(v889_12));
            join_wrapped_into(&mut v888_6_write,&((v889_13).read_zipper()),&[]);
            }
            v886_12_cursor.ascend(1);
          }
          drop(v888_6_write);
          map_map_kernels::compose(&(v887_5),&(v888_6))
        };
        drop(v887_5);
        let v887_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v887_2));
        drop(v887_2);
        let v887_9: Space = if map_kernels::has_head(&(v887_8)) { singleton(&[]) } else { Space::new() };
        drop(v887_8);
        let v887_11: Space = if (&(v887_9)).is_empty() { Space::new() } else {
          let mut v892_10 = Space::new();
          let mut v892_10_write = v892_10.write_zipper();
          for v892_10_byte in v886_12_cursor.child_mask().iter() {
            v886_12_cursor.descend_to_existing_byte(v892_10_byte);
            {
            let v893_2: Space = singleton(&v886_12_cursor.path()[(v886_12_origin + 1)..(v886_12_origin + 2)]);
            let v893_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v893_2));
            let v893_4: Space = if map_kernels::has_head(&(v893_3)) { singleton(&[]) } else { Space::new() };
            drop(v893_3);
            let v893_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v893_4));
            drop(v893_4);
            let v893_8: Space = if (&(v893_5)).is_empty() { Space::new() } else {
              let v894_7: Space = routine_17(c, &v886_12_cursor.path()[v886_12_origin..(v886_12_origin + 2)], &(*p1), &v886_12_cursor);
              map_map_kernels::compose(&(v893_5),&(v894_7))
            };
            drop(v893_5);
            let v893_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v893_2));
            drop(v893_2);
            let v893_10: Space = if map_kernels::has_head(&(v893_9)) { singleton(&[]) } else { Space::new() };
            drop(v893_9);
            let v893_12: Space = if (&(v893_10)).is_empty() { Space::new() } else {
              let v895_11: Space = routine_19(c, &v886_12_cursor.path()[v886_12_origin..(v886_12_origin + 2)], &(*p1), &v886_12_cursor);
              map_map_kernels::compose(&(v893_10),&(v895_11))
            };
            drop(v893_10);
            let v893_13: Space = map_map_kernels::unite(&(v893_8),&(v893_12));
            join_wrapped_into(&mut v892_10_write,&((v893_13).read_zipper()),&[]);
            }
            v886_12_cursor.ascend(1);
          }
          drop(v892_10_write);
          map_map_kernels::compose(&(v887_9),&(v892_10))
        };
        drop(v887_9);
        let v887_12: Space = map_map_kernels::unite(&(v887_7),&(v887_11));
        join_wrapped_into(&mut v886_12_write,&((v887_12).read_zipper()),&[]);
        }
        v886_12_cursor.ascend(1);
      }
      drop(v886_12_cursor);
      drop(v886_12_write);
      map_map_kernels::compose(&(v875_10),&(v886_12))
    };
    drop(v875_10);
    let v875_14: Space = map_map_kernels::unite(&(v875_8),&(v875_13));
    join_wrapped_into(&mut v874_28_write,&((v875_14).read_zipper()),&[]);
    }
    v874_28_cursor.ascend(1);
  }
  drop(v874_28_cursor);
  drop(v874_28_write);
  (v874_28).clone()
}

fn routine_46(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v896_21 = Space::new();
  let mut v896_21_write = v896_21.write_zipper();
  let mut v896_21_cursor = (*s0).read_zipper();
  let v896_21_origin = v896_21_cursor.path().len();
  for v896_21_byte in v896_21_cursor.child_mask().iter() {
    v896_21_cursor.descend_to_existing_byte(v896_21_byte);
    {
    let v897_2: Space = singleton(&v896_21_cursor.path()[v896_21_origin..(v896_21_origin + 1)]);
    let v897_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v897_2));
    let v897_4: Space = if map_kernels::has_head(&(v897_3)) { singleton(&[]) } else { Space::new() };
    drop(v897_3);
    let v897_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v897_4));
    drop(v897_4);
    let v897_8: Space = if (&(v897_5)).is_empty() { Space::new() } else {
      let v898_6: Path = concat_path(&(*p0),&v896_21_cursor.path()[v896_21_origin..(v896_21_origin + 1)]);
      let mut v898_7 = Space::new();
      let mut v898_7_write = v898_7.write_zipper();
      for v898_7_byte in v896_21_cursor.child_mask().iter() {
        v896_21_cursor.descend_to_existing_byte(v898_7_byte);
        {
        let v899_2: Space = singleton(&v896_21_cursor.path()[(v896_21_origin + 1)..(v896_21_origin + 2)]);
        let v899_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v899_2));
        let v899_4: Space = if map_kernels::has_head(&(v899_3)) { singleton(&[]) } else { Space::new() };
        drop(v899_3);
        let v899_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v899_4));
        drop(v899_4);
        let v899_8: Space = if (&(v899_5)).is_empty() { Space::new() } else {
          let v900_6: Path = concat_path(&(v898_6),&v896_21_cursor.path()[(v896_21_origin + 1)..(v896_21_origin + 2)]);
          let mut v900_7 = Space::new();
          let mut v900_7_write = v900_7.write_zipper();
          for v900_7_byte in v896_21_cursor.child_mask().iter() {
            v896_21_cursor.descend_to_existing_byte(v900_7_byte);
            {
            let v901_2: Space = singleton(&v896_21_cursor.path()[(v896_21_origin + 2)..(v896_21_origin + 3)]);
            let v901_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v901_2));
            let v901_4: Space = if map_kernels::has_head(&(v901_3)) { singleton(&[]) } else { Space::new() };
            drop(v901_3);
            let v901_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v901_4));
            drop(v901_4);
            let v901_8: Space = if (&(v901_5)).is_empty() { Space::new() } else {
              let v902_6: Path = concat_path(&(v900_6),&v896_21_cursor.path()[(v896_21_origin + 2)..(v896_21_origin + 3)]);
              let v902_7: Space = routine_58(c, &(v902_6), &(*p1), &v896_21_cursor);
              map_map_kernels::compose(&(v901_5),&(v902_7))
            };
            drop(v901_5);
            let v901_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v901_2));
            drop(v901_2);
            let v901_10: Space = if map_kernels::has_head(&(v901_9)) { singleton(&[]) } else { Space::new() };
            drop(v901_9);
            let v901_12: Space = if (&(v901_10)).is_empty() { Space::new() } else {
              let v903_6: Path = concat_path(&(v900_6),&v896_21_cursor.path()[(v896_21_origin + 2)..(v896_21_origin + 3)]);
              let v903_11: Space = routine_59(c, &(v903_6), &(*p1), &v896_21_cursor);
              drop(v903_6);
              map_map_kernels::compose(&(v901_10),&(v903_11))
            };
            drop(v901_10);
            let v901_13: Space = map_map_kernels::unite(&(v901_8),&(v901_12));
            join_wrapped_into(&mut v900_7_write,&((v901_13).read_zipper()),&[]);
            }
            v896_21_cursor.ascend(1);
          }
          drop(v900_7_write);
          map_map_kernels::compose(&(v899_5),&(v900_7))
        };
        drop(v899_5);
        let v899_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v899_2));
        drop(v899_2);
        let v899_10: Space = if map_kernels::has_head(&(v899_9)) { singleton(&[]) } else { Space::new() };
        drop(v899_9);
        let v899_12: Space = if (&(v899_10)).is_empty() { Space::new() } else {
          let v904_6: Path = concat_path(&(v898_6),&v896_21_cursor.path()[(v896_21_origin + 1)..(v896_21_origin + 2)]);
          let mut v904_11 = Space::new();
          let mut v904_11_write = v904_11.write_zipper();
          for v904_11_byte in v896_21_cursor.child_mask().iter() {
            v896_21_cursor.descend_to_existing_byte(v904_11_byte);
            {
            let v905_2: Space = singleton(&v896_21_cursor.path()[(v896_21_origin + 2)..(v896_21_origin + 3)]);
            let v905_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v905_2));
            let v905_4: Space = if map_kernels::has_head(&(v905_3)) { singleton(&[]) } else { Space::new() };
            drop(v905_3);
            let v905_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v905_4));
            drop(v905_4);
            let v905_8: Space = if (&(v905_5)).is_empty() { Space::new() } else {
              let v906_6: Path = concat_path(&(v904_6),&v896_21_cursor.path()[(v896_21_origin + 2)..(v896_21_origin + 3)]);
              let v906_7: Space = routine_58(c, &(v906_6), &(*p1), &v896_21_cursor);
              map_map_kernels::compose(&(v905_5),&(v906_7))
            };
            drop(v905_5);
            let v905_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v905_2));
            drop(v905_2);
            let v905_10: Space = if map_kernels::has_head(&(v905_9)) { singleton(&[]) } else { Space::new() };
            drop(v905_9);
            let v905_12: Space = if (&(v905_10)).is_empty() { Space::new() } else {
              let v907_6: Path = concat_path(&(v904_6),&v896_21_cursor.path()[(v896_21_origin + 2)..(v896_21_origin + 3)]);
              let v907_11: Space = routine_19(c, &(v907_6), &(*p1), &v896_21_cursor);
              drop(v907_6);
              map_map_kernels::compose(&(v905_10),&(v907_11))
            };
            drop(v905_10);
            let v905_13: Space = map_map_kernels::unite(&(v905_8),&(v905_12));
            join_wrapped_into(&mut v904_11_write,&((v905_13).read_zipper()),&[]);
            }
            v896_21_cursor.ascend(1);
          }
          drop(v904_11_write);
          drop(v904_6);
          map_map_kernels::compose(&(v899_10),&(v904_11))
        };
        drop(v899_10);
        let v899_13: Space = map_map_kernels::unite(&(v899_8),&(v899_12));
        join_wrapped_into(&mut v898_7_write,&((v899_13).read_zipper()),&[]);
        }
        v896_21_cursor.ascend(1);
      }
      drop(v898_7_write);
      map_map_kernels::compose(&(v897_5),&(v898_7))
    };
    drop(v897_5);
    let v897_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v897_2));
    drop(v897_2);
    let v897_10: Space = if map_kernels::has_head(&(v897_9)) { singleton(&[]) } else { Space::new() };
    drop(v897_9);
    let v897_12: Space = if (&(v897_10)).is_empty() { Space::new() } else {
      let v908_6: Path = concat_path(&(*p0),&v896_21_cursor.path()[v896_21_origin..(v896_21_origin + 1)]);
      let mut v908_11 = Space::new();
      let mut v908_11_write = v908_11.write_zipper();
      for v908_11_byte in v896_21_cursor.child_mask().iter() {
        v896_21_cursor.descend_to_existing_byte(v908_11_byte);
        {
        let v909_2: Space = singleton(&v896_21_cursor.path()[(v896_21_origin + 1)..(v896_21_origin + 2)]);
        let v909_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v909_2));
        let v909_4: Space = if map_kernels::has_head(&(v909_3)) { singleton(&[]) } else { Space::new() };
        drop(v909_3);
        let v909_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v909_4));
        drop(v909_4);
        let v909_8: Space = if (&(v909_5)).is_empty() { Space::new() } else {
          let v910_6: Path = concat_path(&(v908_6),&v896_21_cursor.path()[(v896_21_origin + 1)..(v896_21_origin + 2)]);
          let mut v910_7 = Space::new();
          let mut v910_7_write = v910_7.write_zipper();
          for v910_7_byte in v896_21_cursor.child_mask().iter() {
            v896_21_cursor.descend_to_existing_byte(v910_7_byte);
            {
            let v911_2: Space = singleton(&v896_21_cursor.path()[(v896_21_origin + 2)..(v896_21_origin + 3)]);
            let v911_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v911_2));
            let v911_4: Space = if map_kernels::has_head(&(v911_3)) { singleton(&[]) } else { Space::new() };
            drop(v911_3);
            let v911_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v911_4));
            drop(v911_4);
            let v911_8: Space = if (&(v911_5)).is_empty() { Space::new() } else {
              let v912_6: Path = concat_path(&(v910_6),&v896_21_cursor.path()[(v896_21_origin + 2)..(v896_21_origin + 3)]);
              let v912_7: Space = routine_58(c, &(v912_6), &(*p1), &v896_21_cursor);
              map_map_kernels::compose(&(v911_5),&(v912_7))
            };
            drop(v911_5);
            let v911_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v911_2));
            drop(v911_2);
            let v911_10: Space = if map_kernels::has_head(&(v911_9)) { singleton(&[]) } else { Space::new() };
            drop(v911_9);
            let v911_12: Space = if (&(v911_10)).is_empty() { Space::new() } else {
              let v913_6: Path = concat_path(&(v910_6),&v896_21_cursor.path()[(v896_21_origin + 2)..(v896_21_origin + 3)]);
              let v913_11: Space = routine_59(c, &(v913_6), &(*p1), &v896_21_cursor);
              drop(v913_6);
              map_map_kernels::compose(&(v911_10),&(v913_11))
            };
            drop(v911_10);
            let v911_13: Space = map_map_kernels::unite(&(v911_8),&(v911_12));
            join_wrapped_into(&mut v910_7_write,&((v911_13).read_zipper()),&[]);
            }
            v896_21_cursor.ascend(1);
          }
          drop(v910_7_write);
          map_map_kernels::compose(&(v909_5),&(v910_7))
        };
        drop(v909_5);
        let v909_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v909_2));
        drop(v909_2);
        let v909_10: Space = if map_kernels::has_head(&(v909_9)) { singleton(&[]) } else { Space::new() };
        drop(v909_9);
        let v909_11: Space = map_view_kernels::compose(&(v909_10),&v896_21_cursor);
        drop(v909_10);
        let v914_6: Path = concat_path(&(v908_6),&v896_21_cursor.path()[(v896_21_origin + 1)..(v896_21_origin + 2)]);
        let v909_12: Space = map_kernels::wrap(&(v909_11),&(v914_6));
        drop(v909_11);
        let v909_13: Space = map_kernels::wrap(&(v909_12),&(*p1));
        drop(v909_12);
        let v909_14: Space = map_map_kernels::unite(&(v909_8),&(v909_13));
        drop(v909_13);
        join_wrapped_into(&mut v908_11_write,&((v909_14).read_zipper()),&[]);
        }
        v896_21_cursor.ascend(1);
      }
      drop(v908_11_write);
      drop(v908_6);
      map_map_kernels::compose(&(v897_10),&(v908_11))
    };
    drop(v897_10);
    let v897_13: Space = map_map_kernels::unite(&(v897_8),&(v897_12));
    join_wrapped_into(&mut v896_21_write,&((v897_13).read_zipper()),&[]);
    }
    v896_21_cursor.ascend(1);
  }
  drop(v896_21_cursor);
  drop(v896_21_write);
  (v896_21).clone()
}

fn routine_47(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v915_15 = Space::new();
  let mut v915_15_write = v915_15.write_zipper();
  let mut v915_15_cursor = (*s0).read_zipper();
  let v915_15_origin = v915_15_cursor.path().len();
  for v915_15_byte in v915_15_cursor.child_mask().iter() {
    v915_15_cursor.descend_to_existing_byte(v915_15_byte);
    {
    let v916_2: Space = singleton(&v915_15_cursor.path()[v915_15_origin..(v915_15_origin + 1)]);
    let v916_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v916_2));
    let v916_4: Space = if map_kernels::has_head(&(v916_3)) { singleton(&[]) } else { Space::new() };
    drop(v916_3);
    let v916_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v916_4));
    drop(v916_4);
    let v916_8: Space = if (&(v916_5)).is_empty() { Space::new() } else {
      let v917_6: Path = concat_path(&(*p0),&v915_15_cursor.path()[v915_15_origin..(v915_15_origin + 1)]);
      let mut v917_7 = Space::new();
      let mut v917_7_write = v917_7.write_zipper();
      for v917_7_byte in v915_15_cursor.child_mask().iter() {
        v915_15_cursor.descend_to_existing_byte(v917_7_byte);
        {
        let v918_2: Space = singleton(&v915_15_cursor.path()[(v915_15_origin + 1)..(v915_15_origin + 2)]);
        let v918_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v918_2));
        let v918_4: Space = if map_kernels::has_head(&(v918_3)) { singleton(&[]) } else { Space::new() };
        drop(v918_3);
        let v918_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v918_4));
        drop(v918_4);
        let v918_8: Space = if (&(v918_5)).is_empty() { Space::new() } else {
          let v919_6: Path = concat_path(&(v917_6),&v915_15_cursor.path()[(v915_15_origin + 1)..(v915_15_origin + 2)]);
          let mut v919_7 = Space::new();
          let mut v919_7_write = v919_7.write_zipper();
          for v919_7_byte in v915_15_cursor.child_mask().iter() {
            v915_15_cursor.descend_to_existing_byte(v919_7_byte);
            {
            let v920_2: Space = singleton(&v915_15_cursor.path()[(v915_15_origin + 2)..(v915_15_origin + 3)]);
            let v920_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v920_2));
            let v920_4: Space = if map_kernels::has_head(&(v920_3)) { singleton(&[]) } else { Space::new() };
            drop(v920_3);
            let v920_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v920_4));
            drop(v920_4);
            let v920_8: Space = if (&(v920_5)).is_empty() { Space::new() } else {
              let v921_6: Path = concat_path(&(v919_6),&v915_15_cursor.path()[(v915_15_origin + 2)..(v915_15_origin + 3)]);
              let v921_7: Space = routine_58(c, &(v921_6), &(*p1), &v915_15_cursor);
              map_map_kernels::compose(&(v920_5),&(v921_7))
            };
            drop(v920_5);
            let v920_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v920_2));
            drop(v920_2);
            let v920_10: Space = if map_kernels::has_head(&(v920_9)) { singleton(&[]) } else { Space::new() };
            drop(v920_9);
            let v920_12: Space = if (&(v920_10)).is_empty() { Space::new() } else {
              let v922_6: Path = concat_path(&(v919_6),&v915_15_cursor.path()[(v915_15_origin + 2)..(v915_15_origin + 3)]);
              let v922_11: Space = routine_59(c, &(v922_6), &(*p1), &v915_15_cursor);
              drop(v922_6);
              map_map_kernels::compose(&(v920_10),&(v922_11))
            };
            drop(v920_10);
            let v920_13: Space = map_map_kernels::unite(&(v920_8),&(v920_12));
            join_wrapped_into(&mut v919_7_write,&((v920_13).read_zipper()),&[]);
            }
            v915_15_cursor.ascend(1);
          }
          drop(v919_7_write);
          map_map_kernels::compose(&(v918_5),&(v919_7))
        };
        drop(v918_5);
        let v918_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v918_2));
        drop(v918_2);
        let v918_10: Space = if map_kernels::has_head(&(v918_9)) { singleton(&[]) } else { Space::new() };
        drop(v918_9);
        let v918_12: Space = if (&(v918_10)).is_empty() { Space::new() } else {
          let v923_6: Path = concat_path(&(v917_6),&v915_15_cursor.path()[(v915_15_origin + 1)..(v915_15_origin + 2)]);
          let mut v923_11 = Space::new();
          let mut v923_11_write = v923_11.write_zipper();
          for v923_11_byte in v915_15_cursor.child_mask().iter() {
            v915_15_cursor.descend_to_existing_byte(v923_11_byte);
            {
            let v924_2: Space = singleton(&v915_15_cursor.path()[(v915_15_origin + 2)..(v915_15_origin + 3)]);
            let v924_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v924_2));
            let v924_4: Space = if map_kernels::has_head(&(v924_3)) { singleton(&[]) } else { Space::new() };
            drop(v924_3);
            let v924_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v924_4));
            drop(v924_4);
            let v924_8: Space = if (&(v924_5)).is_empty() { Space::new() } else {
              let v925_6: Path = concat_path(&(v923_6),&v915_15_cursor.path()[(v915_15_origin + 2)..(v915_15_origin + 3)]);
              let v925_7: Space = routine_58(c, &(v925_6), &(*p1), &v915_15_cursor);
              map_map_kernels::compose(&(v924_5),&(v925_7))
            };
            drop(v924_5);
            let v924_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v924_2));
            drop(v924_2);
            let v924_10: Space = if map_kernels::has_head(&(v924_9)) { singleton(&[]) } else { Space::new() };
            drop(v924_9);
            let v924_12: Space = if (&(v924_10)).is_empty() { Space::new() } else {
              let v926_6: Path = concat_path(&(v923_6),&v915_15_cursor.path()[(v915_15_origin + 2)..(v915_15_origin + 3)]);
              let v926_11: Space = routine_19(c, &(v926_6), &(*p1), &v915_15_cursor);
              drop(v926_6);
              map_map_kernels::compose(&(v924_10),&(v926_11))
            };
            drop(v924_10);
            let v924_13: Space = map_map_kernels::unite(&(v924_8),&(v924_12));
            join_wrapped_into(&mut v923_11_write,&((v924_13).read_zipper()),&[]);
            }
            v915_15_cursor.ascend(1);
          }
          drop(v923_11_write);
          drop(v923_6);
          map_map_kernels::compose(&(v918_10),&(v923_11))
        };
        drop(v918_10);
        let v918_13: Space = map_map_kernels::unite(&(v918_8),&(v918_12));
        join_wrapped_into(&mut v917_7_write,&((v918_13).read_zipper()),&[]);
        }
        v915_15_cursor.ascend(1);
      }
      drop(v917_7_write);
      map_map_kernels::compose(&(v916_5),&(v917_7))
    };
    drop(v916_5);
    let v916_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v916_2));
    drop(v916_2);
    let v916_10: Space = if map_kernels::has_head(&(v916_9)) { singleton(&[]) } else { Space::new() };
    drop(v916_9);
    let v916_11: Space = map_view_kernels::compose(&(v916_10),&v915_15_cursor);
    drop(v916_10);
    let v927_6: Path = concat_path(&(*p0),&v915_15_cursor.path()[v915_15_origin..(v915_15_origin + 1)]);
    let v916_12: Space = map_kernels::wrap(&(v916_11),&(v927_6));
    drop(v916_11);
    let v916_13: Space = map_kernels::wrap(&(v916_12),&(*p1));
    drop(v916_12);
    let v916_14: Space = map_map_kernels::unite(&(v916_8),&(v916_13));
    drop(v916_13);
    join_wrapped_into(&mut v915_15_write,&((v916_14).read_zipper()),&[]);
    }
    v915_15_cursor.ascend(1);
  }
  drop(v915_15_cursor);
  drop(v915_15_write);
  (v915_15).clone()
}

fn routine_48(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v928_28 = Space::new();
  let mut v928_28_write = v928_28.write_zipper();
  let mut v928_28_cursor = (*s0).read_zipper();
  let v928_28_origin = v928_28_cursor.path().len();
  for v928_28_byte in v928_28_cursor.child_mask().iter() {
    v928_28_cursor.descend_to_existing_byte(v928_28_byte);
    {
    let v929_2: Space = singleton(&v928_28_cursor.path()[v928_28_origin..(v928_28_origin + 1)]);
    let v929_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v929_2));
    let v929_4: Space = if map_kernels::has_head(&(v929_3)) { singleton(&[]) } else { Space::new() };
    drop(v929_3);
    let v929_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v929_4));
    drop(v929_4);
    let v929_8: Space = if (&(v929_5)).is_empty() { Space::new() } else {
      let v930_6: Path = concat_path(&(*p0),&v928_28_cursor.path()[v928_28_origin..(v928_28_origin + 1)]);
      let mut v930_7 = Space::new();
      let mut v930_7_write = v930_7.write_zipper();
      for v930_7_byte in v928_28_cursor.child_mask().iter() {
        v928_28_cursor.descend_to_existing_byte(v930_7_byte);
        {
        let v931_2: Space = singleton(&v928_28_cursor.path()[(v928_28_origin + 1)..(v928_28_origin + 2)]);
        let v931_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v931_2));
        let v931_4: Space = if map_kernels::has_head(&(v931_3)) { singleton(&[]) } else { Space::new() };
        drop(v931_3);
        let v931_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v931_4));
        drop(v931_4);
        let v931_8: Space = if (&(v931_5)).is_empty() { Space::new() } else {
          let v932_6: Path = concat_path(&(v930_6),&v928_28_cursor.path()[(v928_28_origin + 1)..(v928_28_origin + 2)]);
          let mut v932_7 = Space::new();
          let mut v932_7_write = v932_7.write_zipper();
          for v932_7_byte in v928_28_cursor.child_mask().iter() {
            v928_28_cursor.descend_to_existing_byte(v932_7_byte);
            {
            let v933_2: Space = singleton(&v928_28_cursor.path()[(v928_28_origin + 2)..(v928_28_origin + 3)]);
            let v933_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v933_2));
            let v933_4: Space = if map_kernels::has_head(&(v933_3)) { singleton(&[]) } else { Space::new() };
            drop(v933_3);
            let v933_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v933_4));
            drop(v933_4);
            let v933_8: Space = if (&(v933_5)).is_empty() { Space::new() } else {
              let v934_6: Path = concat_path(&(v932_6),&v928_28_cursor.path()[(v928_28_origin + 2)..(v928_28_origin + 3)]);
              let v934_7: Space = routine_60(c, &(v934_6), &(*p1), &v928_28_cursor, &(*s1));
              map_map_kernels::compose(&(v933_5),&(v934_7))
            };
            drop(v933_5);
            let v933_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v933_2));
            drop(v933_2);
            let v933_10: Space = if map_kernels::has_head(&(v933_9)) { singleton(&[]) } else { Space::new() };
            drop(v933_9);
            let v933_12: Space = if (&(v933_10)).is_empty() { Space::new() } else {
              let v935_6: Path = concat_path(&(v932_6),&v928_28_cursor.path()[(v928_28_origin + 2)..(v928_28_origin + 3)]);
              let v935_11: Space = routine_61(c, &(v935_6), &(*p1), &v928_28_cursor, &(*s1));
              drop(v935_6);
              map_map_kernels::compose(&(v933_10),&(v935_11))
            };
            drop(v933_10);
            let v933_13: Space = map_map_kernels::unite(&(v933_8),&(v933_12));
            join_wrapped_into(&mut v932_7_write,&((v933_13).read_zipper()),&[]);
            }
            v928_28_cursor.ascend(1);
          }
          drop(v932_7_write);
          map_map_kernels::compose(&(v931_5),&(v932_7))
        };
        drop(v931_5);
        let v931_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v931_2));
        drop(v931_2);
        let v931_10: Space = if map_kernels::has_head(&(v931_9)) { singleton(&[]) } else { Space::new() };
        drop(v931_9);
        let v931_12: Space = if (&(v931_10)).is_empty() { Space::new() } else {
          let v936_6: Path = concat_path(&(v930_6),&v928_28_cursor.path()[(v928_28_origin + 1)..(v928_28_origin + 2)]);
          let mut v936_11 = Space::new();
          let mut v936_11_write = v936_11.write_zipper();
          for v936_11_byte in v928_28_cursor.child_mask().iter() {
            v928_28_cursor.descend_to_existing_byte(v936_11_byte);
            {
            let v937_2: Space = singleton(&v928_28_cursor.path()[(v928_28_origin + 2)..(v928_28_origin + 3)]);
            let v937_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v937_2));
            let v937_4: Space = if map_kernels::has_head(&(v937_3)) { singleton(&[]) } else { Space::new() };
            drop(v937_3);
            let v937_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v937_4));
            drop(v937_4);
            let v937_8: Space = if (&(v937_5)).is_empty() { Space::new() } else {
              let v938_6: Path = concat_path(&(v936_6),&v928_28_cursor.path()[(v928_28_origin + 2)..(v928_28_origin + 3)]);
              let v938_7: Space = routine_60(c, &(v938_6), &(*p1), &v928_28_cursor, &(*s1));
              map_map_kernels::compose(&(v937_5),&(v938_7))
            };
            drop(v937_5);
            let v937_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v937_2));
            drop(v937_2);
            let v937_10: Space = if map_kernels::has_head(&(v937_9)) { singleton(&[]) } else { Space::new() };
            drop(v937_9);
            let v937_12: Space = if (&(v937_10)).is_empty() { Space::new() } else {
              let v939_6: Path = concat_path(&(v936_6),&v928_28_cursor.path()[(v928_28_origin + 2)..(v928_28_origin + 3)]);
              let v939_11: Space = routine_10(c, &(v939_6), &(*p1), &v928_28_cursor, &(*s1));
              drop(v939_6);
              map_map_kernels::compose(&(v937_10),&(v939_11))
            };
            drop(v937_10);
            let v937_13: Space = map_map_kernels::unite(&(v937_8),&(v937_12));
            join_wrapped_into(&mut v936_11_write,&((v937_13).read_zipper()),&[]);
            }
            v928_28_cursor.ascend(1);
          }
          drop(v936_11_write);
          drop(v936_6);
          map_map_kernels::compose(&(v931_10),&(v936_11))
        };
        drop(v931_10);
        let v931_13: Space = map_map_kernels::unite(&(v931_8),&(v931_12));
        join_wrapped_into(&mut v930_7_write,&((v931_13).read_zipper()),&[]);
        }
        v928_28_cursor.ascend(1);
      }
      drop(v930_7_write);
      map_map_kernels::compose(&(v929_5),&(v930_7))
    };
    drop(v929_5);
    let v929_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v929_2));
    drop(v929_2);
    let v929_10: Space = if map_kernels::has_head(&(v929_9)) { singleton(&[]) } else { Space::new() };
    drop(v929_9);
    let v929_13: Space = if (&(v929_10)).is_empty() { Space::new() } else {
      let v940_6: Path = concat_path(&(*p0),&v928_28_cursor.path()[v928_28_origin..(v928_28_origin + 1)]);
      let mut v940_12 = Space::new();
      let mut v940_12_write = v940_12.write_zipper();
      for v940_12_byte in v928_28_cursor.child_mask().iter() {
        v928_28_cursor.descend_to_existing_byte(v940_12_byte);
        {
        let v941_2: Space = singleton(&v928_28_cursor.path()[(v928_28_origin + 1)..(v928_28_origin + 2)]);
        let v941_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v941_2));
        let v941_4: Space = if map_kernels::has_head(&(v941_3)) { singleton(&[]) } else { Space::new() };
        drop(v941_3);
        let v941_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v941_4));
        drop(v941_4);
        let v941_8: Space = if (&(v941_5)).is_empty() { Space::new() } else {
          let v942_6: Path = concat_path(&(v940_6),&v928_28_cursor.path()[(v928_28_origin + 1)..(v928_28_origin + 2)]);
          let mut v942_7 = Space::new();
          let mut v942_7_write = v942_7.write_zipper();
          for v942_7_byte in v928_28_cursor.child_mask().iter() {
            v928_28_cursor.descend_to_existing_byte(v942_7_byte);
            {
            let v943_2: Space = singleton(&v928_28_cursor.path()[(v928_28_origin + 2)..(v928_28_origin + 3)]);
            let v943_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v943_2));
            let v943_4: Space = if map_kernels::has_head(&(v943_3)) { singleton(&[]) } else { Space::new() };
            drop(v943_3);
            let v943_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v943_4));
            drop(v943_4);
            let v943_8: Space = if (&(v943_5)).is_empty() { Space::new() } else {
              let v944_6: Path = concat_path(&(v942_6),&v928_28_cursor.path()[(v928_28_origin + 2)..(v928_28_origin + 3)]);
              let v944_7: Space = routine_60(c, &(v944_6), &(*p1), &v928_28_cursor, &(*s1));
              map_map_kernels::compose(&(v943_5),&(v944_7))
            };
            drop(v943_5);
            let v943_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v943_2));
            drop(v943_2);
            let v943_10: Space = if map_kernels::has_head(&(v943_9)) { singleton(&[]) } else { Space::new() };
            drop(v943_9);
            let v943_12: Space = if (&(v943_10)).is_empty() { Space::new() } else {
              let v945_6: Path = concat_path(&(v942_6),&v928_28_cursor.path()[(v928_28_origin + 2)..(v928_28_origin + 3)]);
              let v945_11: Space = routine_61(c, &(v945_6), &(*p1), &v928_28_cursor, &(*s1));
              drop(v945_6);
              map_map_kernels::compose(&(v943_10),&(v945_11))
            };
            drop(v943_10);
            let v943_13: Space = map_map_kernels::unite(&(v943_8),&(v943_12));
            join_wrapped_into(&mut v942_7_write,&((v943_13).read_zipper()),&[]);
            }
            v928_28_cursor.ascend(1);
          }
          drop(v942_7_write);
          drop(v942_6);
          map_map_kernels::compose(&(v941_5),&(v942_7))
        };
        drop(v941_5);
        let v941_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v941_2));
        drop(v941_2);
        let v941_10: Space = if map_kernels::has_head(&(v941_9)) { singleton(&[]) } else { Space::new() };
        drop(v941_9);
        let v941_13: Space = if (&(v941_10)).is_empty() { Space::new() } else {
          let mut v946_12 = Space::new();
          let mut v946_12_write = v946_12.write_zipper();
          let mut v946_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v928_28_cursor.path()[v928_28_origin..(v928_28_origin + 1)]),&v928_28_cursor.path()[(v928_28_origin + 1)..(v928_28_origin + 2)]);
          let v946_12_origin = v946_12_cursor.path().len();
          for v946_12_byte in v946_12_cursor.child_mask().iter() {
            v946_12_cursor.descend_to_existing_byte(v946_12_byte);
            {
            let v947_2: Space = singleton(&v946_12_cursor.path()[v946_12_origin..(v946_12_origin + 1)]);
            let v947_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v947_2));
            let v947_4: Space = if map_kernels::has_head(&(v947_3)) { singleton(&[]) } else { Space::new() };
            drop(v947_3);
            let v947_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v947_4));
            drop(v947_4);
            let v947_7: Space = if (&(v947_5)).is_empty() { Space::new() } else {
              let v948_6: Space = routine_13(c, &v946_12_cursor.path()[v946_12_origin..(v946_12_origin + 1)], &(*p1), &v946_12_cursor);
              map_map_kernels::compose(&(v947_5),&(v948_6))
            };
            drop(v947_5);
            let v947_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v947_2));
            drop(v947_2);
            let v947_9: Space = if map_kernels::has_head(&(v947_8)) { singleton(&[]) } else { Space::new() };
            drop(v947_8);
            let v947_11: Space = if (&(v947_9)).is_empty() { Space::new() } else {
              let v949_10: Space = routine_14(c, &v946_12_cursor.path()[v946_12_origin..(v946_12_origin + 1)], &(*p1), &v946_12_cursor);
              map_map_kernels::compose(&(v947_9),&(v949_10))
            };
            drop(v947_9);
            let v947_12: Space = map_map_kernels::unite(&(v947_7),&(v947_11));
            join_wrapped_into(&mut v946_12_write,&((v947_12).read_zipper()),&[]);
            }
            v946_12_cursor.ascend(1);
          }
          drop(v946_12_cursor);
          drop(v946_12_write);
          map_map_kernels::compose(&(v941_10),&(v946_12))
        };
        drop(v941_10);
        let v941_14: Space = map_map_kernels::unite(&(v941_8),&(v941_13));
        join_wrapped_into(&mut v940_12_write,&((v941_14).read_zipper()),&[]);
        }
        v928_28_cursor.ascend(1);
      }
      drop(v940_12_write);
      drop(v940_6);
      map_map_kernels::compose(&(v929_10),&(v940_12))
    };
    drop(v929_10);
    let v929_14: Space = map_map_kernels::unite(&(v929_8),&(v929_13));
    join_wrapped_into(&mut v928_28_write,&((v929_14).read_zipper()),&[]);
    }
    v928_28_cursor.ascend(1);
  }
  drop(v928_28_cursor);
  drop(v928_28_write);
  (v928_28).clone()
}

fn routine_49(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v950_28 = Space::new();
  let mut v950_28_write = v950_28.write_zipper();
  let mut v950_28_cursor = (*s0).read_zipper();
  let v950_28_origin = v950_28_cursor.path().len();
  for v950_28_byte in v950_28_cursor.child_mask().iter() {
    v950_28_cursor.descend_to_existing_byte(v950_28_byte);
    {
    let v951_2: Space = singleton(&v950_28_cursor.path()[v950_28_origin..(v950_28_origin + 1)]);
    let v951_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v951_2));
    let v951_4: Space = if map_kernels::has_head(&(v951_3)) { singleton(&[]) } else { Space::new() };
    drop(v951_3);
    let v951_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v951_4));
    drop(v951_4);
    let v951_8: Space = if (&(v951_5)).is_empty() { Space::new() } else {
      let v952_6: Path = concat_path(&(*p0),&v950_28_cursor.path()[v950_28_origin..(v950_28_origin + 1)]);
      let mut v952_7 = Space::new();
      let mut v952_7_write = v952_7.write_zipper();
      for v952_7_byte in v950_28_cursor.child_mask().iter() {
        v950_28_cursor.descend_to_existing_byte(v952_7_byte);
        {
        let v953_2: Space = singleton(&v950_28_cursor.path()[(v950_28_origin + 1)..(v950_28_origin + 2)]);
        let v953_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v953_2));
        let v953_4: Space = if map_kernels::has_head(&(v953_3)) { singleton(&[]) } else { Space::new() };
        drop(v953_3);
        let v953_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v953_4));
        drop(v953_4);
        let v953_8: Space = if (&(v953_5)).is_empty() { Space::new() } else {
          let v954_6: Path = concat_path(&(v952_6),&v950_28_cursor.path()[(v950_28_origin + 1)..(v950_28_origin + 2)]);
          let mut v954_7 = Space::new();
          let mut v954_7_write = v954_7.write_zipper();
          for v954_7_byte in v950_28_cursor.child_mask().iter() {
            v950_28_cursor.descend_to_existing_byte(v954_7_byte);
            {
            let v955_2: Space = singleton(&v950_28_cursor.path()[(v950_28_origin + 2)..(v950_28_origin + 3)]);
            let v955_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v955_2));
            let v955_4: Space = if map_kernels::has_head(&(v955_3)) { singleton(&[]) } else { Space::new() };
            drop(v955_3);
            let v955_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v955_4));
            drop(v955_4);
            let v955_8: Space = if (&(v955_5)).is_empty() { Space::new() } else {
              let v956_6: Path = concat_path(&(v954_6),&v950_28_cursor.path()[(v950_28_origin + 2)..(v950_28_origin + 3)]);
              let v956_7: Space = routine_60(c, &(v956_6), &(*p1), &v950_28_cursor, &(*s1));
              map_map_kernels::compose(&(v955_5),&(v956_7))
            };
            drop(v955_5);
            let v955_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v955_2));
            drop(v955_2);
            let v955_10: Space = if map_kernels::has_head(&(v955_9)) { singleton(&[]) } else { Space::new() };
            drop(v955_9);
            let v955_12: Space = if (&(v955_10)).is_empty() { Space::new() } else {
              let v957_6: Path = concat_path(&(v954_6),&v950_28_cursor.path()[(v950_28_origin + 2)..(v950_28_origin + 3)]);
              let v957_11: Space = routine_61(c, &(v957_6), &(*p1), &v950_28_cursor, &(*s1));
              drop(v957_6);
              map_map_kernels::compose(&(v955_10),&(v957_11))
            };
            drop(v955_10);
            let v955_13: Space = map_map_kernels::unite(&(v955_8),&(v955_12));
            join_wrapped_into(&mut v954_7_write,&((v955_13).read_zipper()),&[]);
            }
            v950_28_cursor.ascend(1);
          }
          drop(v954_7_write);
          map_map_kernels::compose(&(v953_5),&(v954_7))
        };
        drop(v953_5);
        let v953_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v953_2));
        drop(v953_2);
        let v953_10: Space = if map_kernels::has_head(&(v953_9)) { singleton(&[]) } else { Space::new() };
        drop(v953_9);
        let v953_12: Space = if (&(v953_10)).is_empty() { Space::new() } else {
          let v958_6: Path = concat_path(&(v952_6),&v950_28_cursor.path()[(v950_28_origin + 1)..(v950_28_origin + 2)]);
          let mut v958_11 = Space::new();
          let mut v958_11_write = v958_11.write_zipper();
          for v958_11_byte in v950_28_cursor.child_mask().iter() {
            v950_28_cursor.descend_to_existing_byte(v958_11_byte);
            {
            let v959_2: Space = singleton(&v950_28_cursor.path()[(v950_28_origin + 2)..(v950_28_origin + 3)]);
            let v959_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v959_2));
            let v959_4: Space = if map_kernels::has_head(&(v959_3)) { singleton(&[]) } else { Space::new() };
            drop(v959_3);
            let v959_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v959_4));
            drop(v959_4);
            let v959_8: Space = if (&(v959_5)).is_empty() { Space::new() } else {
              let v960_6: Path = concat_path(&(v958_6),&v950_28_cursor.path()[(v950_28_origin + 2)..(v950_28_origin + 3)]);
              let v960_7: Space = routine_60(c, &(v960_6), &(*p1), &v950_28_cursor, &(*s1));
              map_map_kernels::compose(&(v959_5),&(v960_7))
            };
            drop(v959_5);
            let v959_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v959_2));
            drop(v959_2);
            let v959_10: Space = if map_kernels::has_head(&(v959_9)) { singleton(&[]) } else { Space::new() };
            drop(v959_9);
            let v959_12: Space = if (&(v959_10)).is_empty() { Space::new() } else {
              let v961_6: Path = concat_path(&(v958_6),&v950_28_cursor.path()[(v950_28_origin + 2)..(v950_28_origin + 3)]);
              let v961_11: Space = routine_10(c, &(v961_6), &(*p1), &v950_28_cursor, &(*s1));
              drop(v961_6);
              map_map_kernels::compose(&(v959_10),&(v961_11))
            };
            drop(v959_10);
            let v959_13: Space = map_map_kernels::unite(&(v959_8),&(v959_12));
            join_wrapped_into(&mut v958_11_write,&((v959_13).read_zipper()),&[]);
            }
            v950_28_cursor.ascend(1);
          }
          drop(v958_11_write);
          drop(v958_6);
          map_map_kernels::compose(&(v953_10),&(v958_11))
        };
        drop(v953_10);
        let v953_13: Space = map_map_kernels::unite(&(v953_8),&(v953_12));
        join_wrapped_into(&mut v952_7_write,&((v953_13).read_zipper()),&[]);
        }
        v950_28_cursor.ascend(1);
      }
      drop(v952_7_write);
      drop(v952_6);
      map_map_kernels::compose(&(v951_5),&(v952_7))
    };
    drop(v951_5);
    let v951_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v951_2));
    drop(v951_2);
    let v951_10: Space = if map_kernels::has_head(&(v951_9)) { singleton(&[]) } else { Space::new() };
    drop(v951_9);
    let v951_13: Space = if (&(v951_10)).is_empty() { Space::new() } else {
      let mut v962_12 = Space::new();
      let mut v962_12_write = v962_12.write_zipper();
      let mut v962_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v950_28_cursor.path()[v950_28_origin..(v950_28_origin + 1)]);
      let v962_12_origin = v962_12_cursor.path().len();
      for v962_12_byte in v962_12_cursor.child_mask().iter() {
        v962_12_cursor.descend_to_existing_byte(v962_12_byte);
        {
        let v963_2: Space = singleton(&v962_12_cursor.path()[v962_12_origin..(v962_12_origin + 1)]);
        let v963_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v963_2));
        let v963_4: Space = if map_kernels::has_head(&(v963_3)) { singleton(&[]) } else { Space::new() };
        drop(v963_3);
        let v963_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v963_4));
        drop(v963_4);
        let v963_7: Space = if (&(v963_5)).is_empty() { Space::new() } else {
          let mut v964_6 = Space::new();
          let mut v964_6_write = v964_6.write_zipper();
          for v964_6_byte in v962_12_cursor.child_mask().iter() {
            v962_12_cursor.descend_to_existing_byte(v964_6_byte);
            {
            let v965_2: Space = singleton(&v962_12_cursor.path()[(v962_12_origin + 1)..(v962_12_origin + 2)]);
            let v965_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v965_2));
            let v965_4: Space = if map_kernels::has_head(&(v965_3)) { singleton(&[]) } else { Space::new() };
            drop(v965_3);
            let v965_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v965_4));
            drop(v965_4);
            let v965_8: Space = if (&(v965_5)).is_empty() { Space::new() } else {
              let v966_7: Space = routine_17(c, &v962_12_cursor.path()[v962_12_origin..(v962_12_origin + 2)], &(*p1), &v962_12_cursor);
              map_map_kernels::compose(&(v965_5),&(v966_7))
            };
            drop(v965_5);
            let v965_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v965_2));
            drop(v965_2);
            let v965_10: Space = if map_kernels::has_head(&(v965_9)) { singleton(&[]) } else { Space::new() };
            drop(v965_9);
            let v965_12: Space = if (&(v965_10)).is_empty() { Space::new() } else {
              let v967_11: Space = routine_18(c, &v962_12_cursor.path()[v962_12_origin..(v962_12_origin + 2)], &(*p1), &v962_12_cursor);
              map_map_kernels::compose(&(v965_10),&(v967_11))
            };
            drop(v965_10);
            let v965_13: Space = map_map_kernels::unite(&(v965_8),&(v965_12));
            join_wrapped_into(&mut v964_6_write,&((v965_13).read_zipper()),&[]);
            }
            v962_12_cursor.ascend(1);
          }
          drop(v964_6_write);
          map_map_kernels::compose(&(v963_5),&(v964_6))
        };
        drop(v963_5);
        let v963_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v963_2));
        drop(v963_2);
        let v963_9: Space = if map_kernels::has_head(&(v963_8)) { singleton(&[]) } else { Space::new() };
        drop(v963_8);
        let v963_11: Space = if (&(v963_9)).is_empty() { Space::new() } else {
          let mut v968_10 = Space::new();
          let mut v968_10_write = v968_10.write_zipper();
          for v968_10_byte in v962_12_cursor.child_mask().iter() {
            v962_12_cursor.descend_to_existing_byte(v968_10_byte);
            {
            let v969_2: Space = singleton(&v962_12_cursor.path()[(v962_12_origin + 1)..(v962_12_origin + 2)]);
            let v969_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v969_2));
            let v969_4: Space = if map_kernels::has_head(&(v969_3)) { singleton(&[]) } else { Space::new() };
            drop(v969_3);
            let v969_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v969_4));
            drop(v969_4);
            let v969_8: Space = if (&(v969_5)).is_empty() { Space::new() } else {
              let v970_7: Space = routine_17(c, &v962_12_cursor.path()[v962_12_origin..(v962_12_origin + 2)], &(*p1), &v962_12_cursor);
              map_map_kernels::compose(&(v969_5),&(v970_7))
            };
            drop(v969_5);
            let v969_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v969_2));
            drop(v969_2);
            let v969_10: Space = if map_kernels::has_head(&(v969_9)) { singleton(&[]) } else { Space::new() };
            drop(v969_9);
            let v969_12: Space = if (&(v969_10)).is_empty() { Space::new() } else {
              let v971_11: Space = routine_19(c, &v962_12_cursor.path()[v962_12_origin..(v962_12_origin + 2)], &(*p1), &v962_12_cursor);
              map_map_kernels::compose(&(v969_10),&(v971_11))
            };
            drop(v969_10);
            let v969_13: Space = map_map_kernels::unite(&(v969_8),&(v969_12));
            join_wrapped_into(&mut v968_10_write,&((v969_13).read_zipper()),&[]);
            }
            v962_12_cursor.ascend(1);
          }
          drop(v968_10_write);
          map_map_kernels::compose(&(v963_9),&(v968_10))
        };
        drop(v963_9);
        let v963_12: Space = map_map_kernels::unite(&(v963_7),&(v963_11));
        join_wrapped_into(&mut v962_12_write,&((v963_12).read_zipper()),&[]);
        }
        v962_12_cursor.ascend(1);
      }
      drop(v962_12_cursor);
      drop(v962_12_write);
      map_map_kernels::compose(&(v951_10),&(v962_12))
    };
    drop(v951_10);
    let v951_14: Space = map_map_kernels::unite(&(v951_8),&(v951_13));
    join_wrapped_into(&mut v950_28_write,&((v951_14).read_zipper()),&[]);
    }
    v950_28_cursor.ascend(1);
  }
  drop(v950_28_cursor);
  drop(v950_28_write);
  (v950_28).clone()
}

fn routine_50(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v972_21 = Space::new();
  let mut v972_21_write = v972_21.write_zipper();
  let mut v972_21_cursor = (*s0).read_zipper();
  let v972_21_origin = v972_21_cursor.path().len();
  for v972_21_byte in v972_21_cursor.child_mask().iter() {
    v972_21_cursor.descend_to_existing_byte(v972_21_byte);
    {
    let v973_2: Space = singleton(&v972_21_cursor.path()[v972_21_origin..(v972_21_origin + 1)]);
    let v973_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v973_2));
    let v973_4: Space = if map_kernels::has_head(&(v973_3)) { singleton(&[]) } else { Space::new() };
    drop(v973_3);
    let v973_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v973_4));
    drop(v973_4);
    let v973_8: Space = if (&(v973_5)).is_empty() { Space::new() } else {
      let v974_6: Path = concat_path(&(*p0),&v972_21_cursor.path()[v972_21_origin..(v972_21_origin + 1)]);
      let mut v974_7 = Space::new();
      let mut v974_7_write = v974_7.write_zipper();
      for v974_7_byte in v972_21_cursor.child_mask().iter() {
        v972_21_cursor.descend_to_existing_byte(v974_7_byte);
        {
        let v975_2: Space = singleton(&v972_21_cursor.path()[(v972_21_origin + 1)..(v972_21_origin + 2)]);
        let v975_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v975_2));
        let v975_4: Space = if map_kernels::has_head(&(v975_3)) { singleton(&[]) } else { Space::new() };
        drop(v975_3);
        let v975_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v975_4));
        drop(v975_4);
        let v975_8: Space = if (&(v975_5)).is_empty() { Space::new() } else {
          let v976_6: Path = concat_path(&(v974_6),&v972_21_cursor.path()[(v972_21_origin + 1)..(v972_21_origin + 2)]);
          let mut v976_7 = Space::new();
          let mut v976_7_write = v976_7.write_zipper();
          for v976_7_byte in v972_21_cursor.child_mask().iter() {
            v972_21_cursor.descend_to_existing_byte(v976_7_byte);
            {
            let v977_2: Space = singleton(&v972_21_cursor.path()[(v972_21_origin + 2)..(v972_21_origin + 3)]);
            let v977_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v977_2));
            let v977_4: Space = if map_kernels::has_head(&(v977_3)) { singleton(&[]) } else { Space::new() };
            drop(v977_3);
            let v977_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v977_4));
            drop(v977_4);
            let v977_8: Space = if (&(v977_5)).is_empty() { Space::new() } else {
              let v978_6: Path = concat_path(&(v976_6),&v972_21_cursor.path()[(v972_21_origin + 2)..(v972_21_origin + 3)]);
              let v978_7: Space = routine_62(c, &(v978_6), &(*p1), &v972_21_cursor);
              map_map_kernels::compose(&(v977_5),&(v978_7))
            };
            drop(v977_5);
            let v977_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v977_2));
            drop(v977_2);
            let v977_10: Space = if map_kernels::has_head(&(v977_9)) { singleton(&[]) } else { Space::new() };
            drop(v977_9);
            let v977_12: Space = if (&(v977_10)).is_empty() { Space::new() } else {
              let v979_6: Path = concat_path(&(v976_6),&v972_21_cursor.path()[(v972_21_origin + 2)..(v972_21_origin + 3)]);
              let v979_11: Space = routine_63(c, &(v979_6), &(*p1), &v972_21_cursor);
              drop(v979_6);
              map_map_kernels::compose(&(v977_10),&(v979_11))
            };
            drop(v977_10);
            let v977_13: Space = map_map_kernels::unite(&(v977_8),&(v977_12));
            join_wrapped_into(&mut v976_7_write,&((v977_13).read_zipper()),&[]);
            }
            v972_21_cursor.ascend(1);
          }
          drop(v976_7_write);
          map_map_kernels::compose(&(v975_5),&(v976_7))
        };
        drop(v975_5);
        let v975_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v975_2));
        drop(v975_2);
        let v975_10: Space = if map_kernels::has_head(&(v975_9)) { singleton(&[]) } else { Space::new() };
        drop(v975_9);
        let v975_12: Space = if (&(v975_10)).is_empty() { Space::new() } else {
          let v980_6: Path = concat_path(&(v974_6),&v972_21_cursor.path()[(v972_21_origin + 1)..(v972_21_origin + 2)]);
          let mut v980_11 = Space::new();
          let mut v980_11_write = v980_11.write_zipper();
          for v980_11_byte in v972_21_cursor.child_mask().iter() {
            v972_21_cursor.descend_to_existing_byte(v980_11_byte);
            {
            let v981_2: Space = singleton(&v972_21_cursor.path()[(v972_21_origin + 2)..(v972_21_origin + 3)]);
            let v981_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v981_2));
            let v981_4: Space = if map_kernels::has_head(&(v981_3)) { singleton(&[]) } else { Space::new() };
            drop(v981_3);
            let v981_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v981_4));
            drop(v981_4);
            let v981_8: Space = if (&(v981_5)).is_empty() { Space::new() } else {
              let v982_6: Path = concat_path(&(v980_6),&v972_21_cursor.path()[(v972_21_origin + 2)..(v972_21_origin + 3)]);
              let v982_7: Space = routine_62(c, &(v982_6), &(*p1), &v972_21_cursor);
              map_map_kernels::compose(&(v981_5),&(v982_7))
            };
            drop(v981_5);
            let v981_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v981_2));
            drop(v981_2);
            let v981_10: Space = if map_kernels::has_head(&(v981_9)) { singleton(&[]) } else { Space::new() };
            drop(v981_9);
            let v981_12: Space = if (&(v981_10)).is_empty() { Space::new() } else {
              let v983_6: Path = concat_path(&(v980_6),&v972_21_cursor.path()[(v972_21_origin + 2)..(v972_21_origin + 3)]);
              let v983_11: Space = routine_19(c, &(v983_6), &(*p1), &v972_21_cursor);
              drop(v983_6);
              map_map_kernels::compose(&(v981_10),&(v983_11))
            };
            drop(v981_10);
            let v981_13: Space = map_map_kernels::unite(&(v981_8),&(v981_12));
            join_wrapped_into(&mut v980_11_write,&((v981_13).read_zipper()),&[]);
            }
            v972_21_cursor.ascend(1);
          }
          drop(v980_11_write);
          drop(v980_6);
          map_map_kernels::compose(&(v975_10),&(v980_11))
        };
        drop(v975_10);
        let v975_13: Space = map_map_kernels::unite(&(v975_8),&(v975_12));
        join_wrapped_into(&mut v974_7_write,&((v975_13).read_zipper()),&[]);
        }
        v972_21_cursor.ascend(1);
      }
      drop(v974_7_write);
      map_map_kernels::compose(&(v973_5),&(v974_7))
    };
    drop(v973_5);
    let v973_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v973_2));
    drop(v973_2);
    let v973_10: Space = if map_kernels::has_head(&(v973_9)) { singleton(&[]) } else { Space::new() };
    drop(v973_9);
    let v973_12: Space = if (&(v973_10)).is_empty() { Space::new() } else {
      let v984_6: Path = concat_path(&(*p0),&v972_21_cursor.path()[v972_21_origin..(v972_21_origin + 1)]);
      let mut v984_11 = Space::new();
      let mut v984_11_write = v984_11.write_zipper();
      for v984_11_byte in v972_21_cursor.child_mask().iter() {
        v972_21_cursor.descend_to_existing_byte(v984_11_byte);
        {
        let v985_2: Space = singleton(&v972_21_cursor.path()[(v972_21_origin + 1)..(v972_21_origin + 2)]);
        let v985_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v985_2));
        let v985_4: Space = if map_kernels::has_head(&(v985_3)) { singleton(&[]) } else { Space::new() };
        drop(v985_3);
        let v985_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v985_4));
        drop(v985_4);
        let v985_8: Space = if (&(v985_5)).is_empty() { Space::new() } else {
          let v986_6: Path = concat_path(&(v984_6),&v972_21_cursor.path()[(v972_21_origin + 1)..(v972_21_origin + 2)]);
          let mut v986_7 = Space::new();
          let mut v986_7_write = v986_7.write_zipper();
          for v986_7_byte in v972_21_cursor.child_mask().iter() {
            v972_21_cursor.descend_to_existing_byte(v986_7_byte);
            {
            let v987_2: Space = singleton(&v972_21_cursor.path()[(v972_21_origin + 2)..(v972_21_origin + 3)]);
            let v987_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v987_2));
            let v987_4: Space = if map_kernels::has_head(&(v987_3)) { singleton(&[]) } else { Space::new() };
            drop(v987_3);
            let v987_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v987_4));
            drop(v987_4);
            let v987_8: Space = if (&(v987_5)).is_empty() { Space::new() } else {
              let v988_6: Path = concat_path(&(v986_6),&v972_21_cursor.path()[(v972_21_origin + 2)..(v972_21_origin + 3)]);
              let v988_7: Space = routine_62(c, &(v988_6), &(*p1), &v972_21_cursor);
              map_map_kernels::compose(&(v987_5),&(v988_7))
            };
            drop(v987_5);
            let v987_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v987_2));
            drop(v987_2);
            let v987_10: Space = if map_kernels::has_head(&(v987_9)) { singleton(&[]) } else { Space::new() };
            drop(v987_9);
            let v987_12: Space = if (&(v987_10)).is_empty() { Space::new() } else {
              let v989_6: Path = concat_path(&(v986_6),&v972_21_cursor.path()[(v972_21_origin + 2)..(v972_21_origin + 3)]);
              let v989_11: Space = routine_63(c, &(v989_6), &(*p1), &v972_21_cursor);
              drop(v989_6);
              map_map_kernels::compose(&(v987_10),&(v989_11))
            };
            drop(v987_10);
            let v987_13: Space = map_map_kernels::unite(&(v987_8),&(v987_12));
            join_wrapped_into(&mut v986_7_write,&((v987_13).read_zipper()),&[]);
            }
            v972_21_cursor.ascend(1);
          }
          drop(v986_7_write);
          map_map_kernels::compose(&(v985_5),&(v986_7))
        };
        drop(v985_5);
        let v985_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v985_2));
        drop(v985_2);
        let v985_10: Space = if map_kernels::has_head(&(v985_9)) { singleton(&[]) } else { Space::new() };
        drop(v985_9);
        let v985_11: Space = map_view_kernels::compose(&(v985_10),&v972_21_cursor);
        drop(v985_10);
        let v990_6: Path = concat_path(&(v984_6),&v972_21_cursor.path()[(v972_21_origin + 1)..(v972_21_origin + 2)]);
        let v985_12: Space = map_kernels::wrap(&(v985_11),&(v990_6));
        drop(v985_11);
        let v985_13: Space = map_kernels::wrap(&(v985_12),&(*p1));
        drop(v985_12);
        let v985_14: Space = map_map_kernels::unite(&(v985_8),&(v985_13));
        drop(v985_13);
        join_wrapped_into(&mut v984_11_write,&((v985_14).read_zipper()),&[]);
        }
        v972_21_cursor.ascend(1);
      }
      drop(v984_11_write);
      drop(v984_6);
      map_map_kernels::compose(&(v973_10),&(v984_11))
    };
    drop(v973_10);
    let v973_13: Space = map_map_kernels::unite(&(v973_8),&(v973_12));
    join_wrapped_into(&mut v972_21_write,&((v973_13).read_zipper()),&[]);
    }
    v972_21_cursor.ascend(1);
  }
  drop(v972_21_cursor);
  drop(v972_21_write);
  (v972_21).clone()
}

fn routine_51(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v991_15 = Space::new();
  let mut v991_15_write = v991_15.write_zipper();
  let mut v991_15_cursor = (*s0).read_zipper();
  let v991_15_origin = v991_15_cursor.path().len();
  for v991_15_byte in v991_15_cursor.child_mask().iter() {
    v991_15_cursor.descend_to_existing_byte(v991_15_byte);
    {
    let v992_2: Space = singleton(&v991_15_cursor.path()[v991_15_origin..(v991_15_origin + 1)]);
    let v992_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v992_2));
    let v992_4: Space = if map_kernels::has_head(&(v992_3)) { singleton(&[]) } else { Space::new() };
    drop(v992_3);
    let v992_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v992_4));
    drop(v992_4);
    let v992_8: Space = if (&(v992_5)).is_empty() { Space::new() } else {
      let v993_6: Path = concat_path(&(*p0),&v991_15_cursor.path()[v991_15_origin..(v991_15_origin + 1)]);
      let mut v993_7 = Space::new();
      let mut v993_7_write = v993_7.write_zipper();
      for v993_7_byte in v991_15_cursor.child_mask().iter() {
        v991_15_cursor.descend_to_existing_byte(v993_7_byte);
        {
        let v994_2: Space = singleton(&v991_15_cursor.path()[(v991_15_origin + 1)..(v991_15_origin + 2)]);
        let v994_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v994_2));
        let v994_4: Space = if map_kernels::has_head(&(v994_3)) { singleton(&[]) } else { Space::new() };
        drop(v994_3);
        let v994_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v994_4));
        drop(v994_4);
        let v994_8: Space = if (&(v994_5)).is_empty() { Space::new() } else {
          let v995_6: Path = concat_path(&(v993_6),&v991_15_cursor.path()[(v991_15_origin + 1)..(v991_15_origin + 2)]);
          let mut v995_7 = Space::new();
          let mut v995_7_write = v995_7.write_zipper();
          for v995_7_byte in v991_15_cursor.child_mask().iter() {
            v991_15_cursor.descend_to_existing_byte(v995_7_byte);
            {
            let v996_2: Space = singleton(&v991_15_cursor.path()[(v991_15_origin + 2)..(v991_15_origin + 3)]);
            let v996_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v996_2));
            let v996_4: Space = if map_kernels::has_head(&(v996_3)) { singleton(&[]) } else { Space::new() };
            drop(v996_3);
            let v996_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v996_4));
            drop(v996_4);
            let v996_8: Space = if (&(v996_5)).is_empty() { Space::new() } else {
              let v997_6: Path = concat_path(&(v995_6),&v991_15_cursor.path()[(v991_15_origin + 2)..(v991_15_origin + 3)]);
              let v997_7: Space = routine_62(c, &(v997_6), &(*p1), &v991_15_cursor);
              map_map_kernels::compose(&(v996_5),&(v997_7))
            };
            drop(v996_5);
            let v996_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v996_2));
            drop(v996_2);
            let v996_10: Space = if map_kernels::has_head(&(v996_9)) { singleton(&[]) } else { Space::new() };
            drop(v996_9);
            let v996_12: Space = if (&(v996_10)).is_empty() { Space::new() } else {
              let v998_6: Path = concat_path(&(v995_6),&v991_15_cursor.path()[(v991_15_origin + 2)..(v991_15_origin + 3)]);
              let v998_11: Space = routine_63(c, &(v998_6), &(*p1), &v991_15_cursor);
              drop(v998_6);
              map_map_kernels::compose(&(v996_10),&(v998_11))
            };
            drop(v996_10);
            let v996_13: Space = map_map_kernels::unite(&(v996_8),&(v996_12));
            join_wrapped_into(&mut v995_7_write,&((v996_13).read_zipper()),&[]);
            }
            v991_15_cursor.ascend(1);
          }
          drop(v995_7_write);
          map_map_kernels::compose(&(v994_5),&(v995_7))
        };
        drop(v994_5);
        let v994_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v994_2));
        drop(v994_2);
        let v994_10: Space = if map_kernels::has_head(&(v994_9)) { singleton(&[]) } else { Space::new() };
        drop(v994_9);
        let v994_12: Space = if (&(v994_10)).is_empty() { Space::new() } else {
          let v999_6: Path = concat_path(&(v993_6),&v991_15_cursor.path()[(v991_15_origin + 1)..(v991_15_origin + 2)]);
          let mut v999_11 = Space::new();
          let mut v999_11_write = v999_11.write_zipper();
          for v999_11_byte in v991_15_cursor.child_mask().iter() {
            v991_15_cursor.descend_to_existing_byte(v999_11_byte);
            {
            let v1000_2: Space = singleton(&v991_15_cursor.path()[(v991_15_origin + 2)..(v991_15_origin + 3)]);
            let v1000_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1000_2));
            let v1000_4: Space = if map_kernels::has_head(&(v1000_3)) { singleton(&[]) } else { Space::new() };
            drop(v1000_3);
            let v1000_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1000_4));
            drop(v1000_4);
            let v1000_8: Space = if (&(v1000_5)).is_empty() { Space::new() } else {
              let v1001_6: Path = concat_path(&(v999_6),&v991_15_cursor.path()[(v991_15_origin + 2)..(v991_15_origin + 3)]);
              let v1001_7: Space = routine_62(c, &(v1001_6), &(*p1), &v991_15_cursor);
              map_map_kernels::compose(&(v1000_5),&(v1001_7))
            };
            drop(v1000_5);
            let v1000_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1000_2));
            drop(v1000_2);
            let v1000_10: Space = if map_kernels::has_head(&(v1000_9)) { singleton(&[]) } else { Space::new() };
            drop(v1000_9);
            let v1000_12: Space = if (&(v1000_10)).is_empty() { Space::new() } else {
              let v1002_6: Path = concat_path(&(v999_6),&v991_15_cursor.path()[(v991_15_origin + 2)..(v991_15_origin + 3)]);
              let v1002_11: Space = routine_19(c, &(v1002_6), &(*p1), &v991_15_cursor);
              drop(v1002_6);
              map_map_kernels::compose(&(v1000_10),&(v1002_11))
            };
            drop(v1000_10);
            let v1000_13: Space = map_map_kernels::unite(&(v1000_8),&(v1000_12));
            join_wrapped_into(&mut v999_11_write,&((v1000_13).read_zipper()),&[]);
            }
            v991_15_cursor.ascend(1);
          }
          drop(v999_11_write);
          drop(v999_6);
          map_map_kernels::compose(&(v994_10),&(v999_11))
        };
        drop(v994_10);
        let v994_13: Space = map_map_kernels::unite(&(v994_8),&(v994_12));
        join_wrapped_into(&mut v993_7_write,&((v994_13).read_zipper()),&[]);
        }
        v991_15_cursor.ascend(1);
      }
      drop(v993_7_write);
      map_map_kernels::compose(&(v992_5),&(v993_7))
    };
    drop(v992_5);
    let v992_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v992_2));
    drop(v992_2);
    let v992_10: Space = if map_kernels::has_head(&(v992_9)) { singleton(&[]) } else { Space::new() };
    drop(v992_9);
    let v992_11: Space = map_view_kernels::compose(&(v992_10),&v991_15_cursor);
    drop(v992_10);
    let v1003_6: Path = concat_path(&(*p0),&v991_15_cursor.path()[v991_15_origin..(v991_15_origin + 1)]);
    let v992_12: Space = map_kernels::wrap(&(v992_11),&(v1003_6));
    drop(v992_11);
    let v992_13: Space = map_kernels::wrap(&(v992_12),&(*p1));
    drop(v992_12);
    let v992_14: Space = map_map_kernels::unite(&(v992_8),&(v992_13));
    drop(v992_13);
    join_wrapped_into(&mut v991_15_write,&((v992_14).read_zipper()),&[]);
    }
    v991_15_cursor.ascend(1);
  }
  drop(v991_15_cursor);
  drop(v991_15_write);
  (v991_15).clone()
}

fn routine_52(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v1004_20 = Space::new();
  let mut v1004_20_write = v1004_20.write_zipper();
  let mut v1004_20_cursor = (*s0).read_zipper();
  let v1004_20_origin = v1004_20_cursor.path().len();
  for v1004_20_byte in v1004_20_cursor.child_mask().iter() {
    v1004_20_cursor.descend_to_existing_byte(v1004_20_byte);
    {
    let v1005_2: Space = singleton(&v1004_20_cursor.path()[v1004_20_origin..(v1004_20_origin + 1)]);
    let v1005_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1005_2));
    let v1005_4: Space = if map_kernels::has_head(&(v1005_3)) { singleton(&[]) } else { Space::new() };
    drop(v1005_3);
    let v1005_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1005_4));
    drop(v1005_4);
    let v1005_8: Space = if (&(v1005_5)).is_empty() { Space::new() } else {
      let v1006_6: Path = concat_path(&(*p0),&v1004_20_cursor.path()[v1004_20_origin..(v1004_20_origin + 1)]);
      let mut v1006_7 = Space::new();
      let mut v1006_7_write = v1006_7.write_zipper();
      for v1006_7_byte in v1004_20_cursor.child_mask().iter() {
        v1004_20_cursor.descend_to_existing_byte(v1006_7_byte);
        {
        let v1007_2: Space = singleton(&v1004_20_cursor.path()[(v1004_20_origin + 1)..(v1004_20_origin + 2)]);
        let v1007_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1007_2));
        let v1007_4: Space = if map_kernels::has_head(&(v1007_3)) { singleton(&[]) } else { Space::new() };
        drop(v1007_3);
        let v1007_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1007_4));
        drop(v1007_4);
        let v1007_7: Space = if (&(v1007_5)).is_empty() { Space::new() } else {
          let mut v1008_6 = Space::new();
          let mut v1008_6_write = v1008_6.write_zipper();
          for v1008_6_byte in v1004_20_cursor.child_mask().iter() {
            v1004_20_cursor.descend_to_existing_byte(v1008_6_byte);
            {
            let v1009_2: Space = Space::new();
            join_wrapped_into(&mut v1008_6_write,&((v1009_2).read_zipper()),&[]);
            }
            v1004_20_cursor.ascend(1);
          }
          drop(v1008_6_write);
          map_map_kernels::compose(&(v1007_5),&(v1008_6))
        };
        drop(v1007_5);
        let v1007_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1007_2));
        drop(v1007_2);
        let v1007_9: Space = if map_kernels::has_head(&(v1007_8)) { singleton(&[]) } else { Space::new() };
        drop(v1007_8);
        let v1007_12: Space = if (&(v1007_9)).is_empty() { Space::new() } else {
          let v1010_10: Path = concat_path(&(v1006_6),&v1004_20_cursor.path()[(v1004_20_origin + 1)..(v1004_20_origin + 2)]);
          let mut v1010_11 = Space::new();
          let mut v1010_11_write = v1010_11.write_zipper();
          for v1010_11_byte in v1004_20_cursor.child_mask().iter() {
            v1004_20_cursor.descend_to_existing_byte(v1010_11_byte);
            {
            let v1011_2: Space = singleton(&v1004_20_cursor.path()[(v1004_20_origin + 2)..(v1004_20_origin + 3)]);
            let v1011_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1011_2));
            drop(v1011_2);
            let v1011_4: Space = if map_kernels::has_head(&(v1011_3)) { singleton(&[]) } else { Space::new() };
            drop(v1011_3);
            let v1011_7: Space = if (&(v1011_4)).is_empty() { Space::new() } else {
              let v1012_5: Path = concat_path(&(v1010_10),&v1004_20_cursor.path()[(v1004_20_origin + 2)..(v1004_20_origin + 3)]);
              let v1012_6: Space = routine_10(c, &(v1012_5), &(*p1), &v1004_20_cursor, &(*s1));
              drop(v1012_5);
              map_map_kernels::compose(&(v1011_4),&(v1012_6))
            };
            drop(v1011_4);
            join_wrapped_into(&mut v1010_11_write,&((v1011_7).read_zipper()),&[]);
            }
            v1004_20_cursor.ascend(1);
          }
          drop(v1010_11_write);
          drop(v1010_10);
          map_map_kernels::compose(&(v1007_9),&(v1010_11))
        };
        drop(v1007_9);
        let v1007_13: Space = map_map_kernels::unite(&(v1007_7),&(v1007_12));
        drop(v1007_7);
        join_wrapped_into(&mut v1006_7_write,&((v1007_13).read_zipper()),&[]);
        }
        v1004_20_cursor.ascend(1);
      }
      drop(v1006_7_write);
      drop(v1006_6);
      map_map_kernels::compose(&(v1005_5),&(v1006_7))
    };
    drop(v1005_5);
    let v1005_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1005_2));
    drop(v1005_2);
    let v1005_10: Space = if map_kernels::has_head(&(v1005_9)) { singleton(&[]) } else { Space::new() };
    drop(v1005_9);
    let v1005_13: Space = if (&(v1005_10)).is_empty() { Space::new() } else {
      let mut v1013_12 = Space::new();
      let mut v1013_12_write = v1013_12.write_zipper();
      for v1013_12_byte in v1004_20_cursor.child_mask().iter() {
        v1004_20_cursor.descend_to_existing_byte(v1013_12_byte);
        {
        let v1014_2: Space = singleton(&v1004_20_cursor.path()[(v1004_20_origin + 1)..(v1004_20_origin + 2)]);
        let v1014_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1014_2));
        let v1014_4: Space = if map_kernels::has_head(&(v1014_3)) { singleton(&[]) } else { Space::new() };
        drop(v1014_3);
        let v1014_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1014_4));
        drop(v1014_4);
        let v1014_7: Space = if (&(v1014_5)).is_empty() { Space::new() } else {
          let mut v1015_6 = Space::new();
          let mut v1015_6_write = v1015_6.write_zipper();
          for v1015_6_byte in v1004_20_cursor.child_mask().iter() {
            v1004_20_cursor.descend_to_existing_byte(v1015_6_byte);
            {
            let v1016_2: Space = Space::new();
            join_wrapped_into(&mut v1015_6_write,&((v1016_2).read_zipper()),&[]);
            }
            v1004_20_cursor.ascend(1);
          }
          drop(v1015_6_write);
          map_map_kernels::compose(&(v1014_5),&(v1015_6))
        };
        drop(v1014_5);
        let v1014_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1014_2));
        drop(v1014_2);
        let v1014_9: Space = if map_kernels::has_head(&(v1014_8)) { singleton(&[]) } else { Space::new() };
        drop(v1014_8);
        let v1014_12: Space = if (&(v1014_9)).is_empty() { Space::new() } else {
          let mut v1017_11 = Space::new();
          let mut v1017_11_write = v1017_11.write_zipper();
          let mut v1017_11_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v1004_20_cursor.path()[v1004_20_origin..(v1004_20_origin + 1)]),&v1004_20_cursor.path()[(v1004_20_origin + 1)..(v1004_20_origin + 2)]);
          let v1017_11_origin = v1017_11_cursor.path().len();
          for v1017_11_byte in v1017_11_cursor.child_mask().iter() {
            v1017_11_cursor.descend_to_existing_byte(v1017_11_byte);
            {
            let v1018_2: Space = singleton(&v1017_11_cursor.path()[v1017_11_origin..(v1017_11_origin + 1)]);
            let v1018_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1018_2));
            let v1018_4: Space = if map_kernels::has_head(&(v1018_3)) { singleton(&[]) } else { Space::new() };
            drop(v1018_3);
            let v1018_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1018_4));
            drop(v1018_4);
            let v1018_7: Space = if (&(v1018_5)).is_empty() { Space::new() } else {
              let v1019_6: Space = routine_13(c, &v1017_11_cursor.path()[v1017_11_origin..(v1017_11_origin + 1)], &(*p1), &v1017_11_cursor);
              map_map_kernels::compose(&(v1018_5),&(v1019_6))
            };
            drop(v1018_5);
            let v1018_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1018_2));
            drop(v1018_2);
            let v1018_9: Space = if map_kernels::has_head(&(v1018_8)) { singleton(&[]) } else { Space::new() };
            drop(v1018_8);
            let v1018_11: Space = if (&(v1018_9)).is_empty() { Space::new() } else {
              let v1020_10: Space = routine_14(c, &v1017_11_cursor.path()[v1017_11_origin..(v1017_11_origin + 1)], &(*p1), &v1017_11_cursor);
              map_map_kernels::compose(&(v1018_9),&(v1020_10))
            };
            drop(v1018_9);
            let v1018_12: Space = map_map_kernels::unite(&(v1018_7),&(v1018_11));
            join_wrapped_into(&mut v1017_11_write,&((v1018_12).read_zipper()),&[]);
            }
            v1017_11_cursor.ascend(1);
          }
          drop(v1017_11_cursor);
          drop(v1017_11_write);
          map_map_kernels::compose(&(v1014_9),&(v1017_11))
        };
        drop(v1014_9);
        let v1014_13: Space = map_map_kernels::unite(&(v1014_7),&(v1014_12));
        drop(v1014_7);
        join_wrapped_into(&mut v1013_12_write,&((v1014_13).read_zipper()),&[]);
        }
        v1004_20_cursor.ascend(1);
      }
      drop(v1013_12_write);
      map_map_kernels::compose(&(v1005_10),&(v1013_12))
    };
    drop(v1005_10);
    let v1005_14: Space = map_map_kernels::unite(&(v1005_8),&(v1005_13));
    join_wrapped_into(&mut v1004_20_write,&((v1005_14).read_zipper()),&[]);
    }
    v1004_20_cursor.ascend(1);
  }
  drop(v1004_20_cursor);
  drop(v1004_20_write);
  (v1004_20).clone()
}

fn routine_53(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v1021_23 = Space::new();
  let mut v1021_23_write = v1021_23.write_zipper();
  let mut v1021_23_cursor = (*s0).read_zipper();
  let v1021_23_origin = v1021_23_cursor.path().len();
  for v1021_23_byte in v1021_23_cursor.child_mask().iter() {
    v1021_23_cursor.descend_to_existing_byte(v1021_23_byte);
    {
    let v1022_2: Space = singleton(&v1021_23_cursor.path()[v1021_23_origin..(v1021_23_origin + 1)]);
    let v1022_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1022_2));
    let v1022_4: Space = if map_kernels::has_head(&(v1022_3)) { singleton(&[]) } else { Space::new() };
    drop(v1022_3);
    let v1022_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1022_4));
    drop(v1022_4);
    let v1022_8: Space = if (&(v1022_5)).is_empty() { Space::new() } else {
      let v1023_6: Path = concat_path(&(*p0),&v1021_23_cursor.path()[v1021_23_origin..(v1021_23_origin + 1)]);
      let mut v1023_7 = Space::new();
      let mut v1023_7_write = v1023_7.write_zipper();
      for v1023_7_byte in v1021_23_cursor.child_mask().iter() {
        v1021_23_cursor.descend_to_existing_byte(v1023_7_byte);
        {
        let v1024_2: Space = singleton(&v1021_23_cursor.path()[(v1021_23_origin + 1)..(v1021_23_origin + 2)]);
        let v1024_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1024_2));
        let v1024_4: Space = if map_kernels::has_head(&(v1024_3)) { singleton(&[]) } else { Space::new() };
        drop(v1024_3);
        let v1024_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1024_4));
        drop(v1024_4);
        let v1024_7: Space = if (&(v1024_5)).is_empty() { Space::new() } else {
          let mut v1025_6 = Space::new();
          let mut v1025_6_write = v1025_6.write_zipper();
          for v1025_6_byte in v1021_23_cursor.child_mask().iter() {
            v1021_23_cursor.descend_to_existing_byte(v1025_6_byte);
            {
            let v1026_2: Space = Space::new();
            join_wrapped_into(&mut v1025_6_write,&((v1026_2).read_zipper()),&[]);
            }
            v1021_23_cursor.ascend(1);
          }
          drop(v1025_6_write);
          map_map_kernels::compose(&(v1024_5),&(v1025_6))
        };
        drop(v1024_5);
        let v1024_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1024_2));
        drop(v1024_2);
        let v1024_9: Space = if map_kernels::has_head(&(v1024_8)) { singleton(&[]) } else { Space::new() };
        drop(v1024_8);
        let v1024_12: Space = if (&(v1024_9)).is_empty() { Space::new() } else {
          let v1027_10: Path = concat_path(&(v1023_6),&v1021_23_cursor.path()[(v1021_23_origin + 1)..(v1021_23_origin + 2)]);
          let mut v1027_11 = Space::new();
          let mut v1027_11_write = v1027_11.write_zipper();
          for v1027_11_byte in v1021_23_cursor.child_mask().iter() {
            v1021_23_cursor.descend_to_existing_byte(v1027_11_byte);
            {
            let v1028_2: Space = singleton(&v1021_23_cursor.path()[(v1021_23_origin + 2)..(v1021_23_origin + 3)]);
            let v1028_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1028_2));
            drop(v1028_2);
            let v1028_4: Space = if map_kernels::has_head(&(v1028_3)) { singleton(&[]) } else { Space::new() };
            drop(v1028_3);
            let v1028_7: Space = if (&(v1028_4)).is_empty() { Space::new() } else {
              let v1029_5: Path = concat_path(&(v1027_10),&v1021_23_cursor.path()[(v1021_23_origin + 2)..(v1021_23_origin + 3)]);
              let v1029_6: Space = routine_10(c, &(v1029_5), &(*p1), &v1021_23_cursor, &(*s1));
              drop(v1029_5);
              map_map_kernels::compose(&(v1028_4),&(v1029_6))
            };
            drop(v1028_4);
            join_wrapped_into(&mut v1027_11_write,&((v1028_7).read_zipper()),&[]);
            }
            v1021_23_cursor.ascend(1);
          }
          drop(v1027_11_write);
          drop(v1027_10);
          map_map_kernels::compose(&(v1024_9),&(v1027_11))
        };
        drop(v1024_9);
        let v1024_13: Space = map_map_kernels::unite(&(v1024_7),&(v1024_12));
        drop(v1024_7);
        join_wrapped_into(&mut v1023_7_write,&((v1024_13).read_zipper()),&[]);
        }
        v1021_23_cursor.ascend(1);
      }
      drop(v1023_7_write);
      drop(v1023_6);
      map_map_kernels::compose(&(v1022_5),&(v1023_7))
    };
    drop(v1022_5);
    let v1022_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1022_2));
    drop(v1022_2);
    let v1022_10: Space = if map_kernels::has_head(&(v1022_9)) { singleton(&[]) } else { Space::new() };
    drop(v1022_9);
    let v1022_13: Space = if (&(v1022_10)).is_empty() { Space::new() } else {
      let mut v1030_12 = Space::new();
      let mut v1030_12_write = v1030_12.write_zipper();
      let mut v1030_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v1021_23_cursor.path()[v1021_23_origin..(v1021_23_origin + 1)]);
      let v1030_12_origin = v1030_12_cursor.path().len();
      for v1030_12_byte in v1030_12_cursor.child_mask().iter() {
        v1030_12_cursor.descend_to_existing_byte(v1030_12_byte);
        {
        let v1031_2: Space = singleton(&v1030_12_cursor.path()[v1030_12_origin..(v1030_12_origin + 1)]);
        let v1031_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1031_2));
        let v1031_4: Space = if map_kernels::has_head(&(v1031_3)) { singleton(&[]) } else { Space::new() };
        drop(v1031_3);
        let v1031_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1031_4));
        drop(v1031_4);
        let v1031_7: Space = if (&(v1031_5)).is_empty() { Space::new() } else {
          let mut v1032_6 = Space::new();
          let mut v1032_6_write = v1032_6.write_zipper();
          for v1032_6_byte in v1030_12_cursor.child_mask().iter() {
            v1030_12_cursor.descend_to_existing_byte(v1032_6_byte);
            {
            let v1033_2: Space = singleton(&v1030_12_cursor.path()[(v1030_12_origin + 1)..(v1030_12_origin + 2)]);
            let v1033_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1033_2));
            let v1033_4: Space = if map_kernels::has_head(&(v1033_3)) { singleton(&[]) } else { Space::new() };
            drop(v1033_3);
            let v1033_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1033_4));
            drop(v1033_4);
            let v1033_8: Space = if (&(v1033_5)).is_empty() { Space::new() } else {
              let v1034_7: Space = routine_17(c, &v1030_12_cursor.path()[v1030_12_origin..(v1030_12_origin + 2)], &(*p1), &v1030_12_cursor);
              map_map_kernels::compose(&(v1033_5),&(v1034_7))
            };
            drop(v1033_5);
            let v1033_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1033_2));
            drop(v1033_2);
            let v1033_10: Space = if map_kernels::has_head(&(v1033_9)) { singleton(&[]) } else { Space::new() };
            drop(v1033_9);
            let v1033_12: Space = if (&(v1033_10)).is_empty() { Space::new() } else {
              let v1035_11: Space = routine_18(c, &v1030_12_cursor.path()[v1030_12_origin..(v1030_12_origin + 2)], &(*p1), &v1030_12_cursor);
              map_map_kernels::compose(&(v1033_10),&(v1035_11))
            };
            drop(v1033_10);
            let v1033_13: Space = map_map_kernels::unite(&(v1033_8),&(v1033_12));
            join_wrapped_into(&mut v1032_6_write,&((v1033_13).read_zipper()),&[]);
            }
            v1030_12_cursor.ascend(1);
          }
          drop(v1032_6_write);
          map_map_kernels::compose(&(v1031_5),&(v1032_6))
        };
        drop(v1031_5);
        let v1031_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1031_2));
        drop(v1031_2);
        let v1031_9: Space = if map_kernels::has_head(&(v1031_8)) { singleton(&[]) } else { Space::new() };
        drop(v1031_8);
        let v1031_11: Space = if (&(v1031_9)).is_empty() { Space::new() } else {
          let mut v1036_10 = Space::new();
          let mut v1036_10_write = v1036_10.write_zipper();
          for v1036_10_byte in v1030_12_cursor.child_mask().iter() {
            v1030_12_cursor.descend_to_existing_byte(v1036_10_byte);
            {
            let v1037_2: Space = singleton(&v1030_12_cursor.path()[(v1030_12_origin + 1)..(v1030_12_origin + 2)]);
            let v1037_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1037_2));
            let v1037_4: Space = if map_kernels::has_head(&(v1037_3)) { singleton(&[]) } else { Space::new() };
            drop(v1037_3);
            let v1037_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1037_4));
            drop(v1037_4);
            let v1037_8: Space = if (&(v1037_5)).is_empty() { Space::new() } else {
              let v1038_7: Space = routine_17(c, &v1030_12_cursor.path()[v1030_12_origin..(v1030_12_origin + 2)], &(*p1), &v1030_12_cursor);
              map_map_kernels::compose(&(v1037_5),&(v1038_7))
            };
            drop(v1037_5);
            let v1037_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1037_2));
            drop(v1037_2);
            let v1037_10: Space = if map_kernels::has_head(&(v1037_9)) { singleton(&[]) } else { Space::new() };
            drop(v1037_9);
            let v1037_12: Space = if (&(v1037_10)).is_empty() { Space::new() } else {
              let v1039_11: Space = routine_19(c, &v1030_12_cursor.path()[v1030_12_origin..(v1030_12_origin + 2)], &(*p1), &v1030_12_cursor);
              map_map_kernels::compose(&(v1037_10),&(v1039_11))
            };
            drop(v1037_10);
            let v1037_13: Space = map_map_kernels::unite(&(v1037_8),&(v1037_12));
            join_wrapped_into(&mut v1036_10_write,&((v1037_13).read_zipper()),&[]);
            }
            v1030_12_cursor.ascend(1);
          }
          drop(v1036_10_write);
          map_map_kernels::compose(&(v1031_9),&(v1036_10))
        };
        drop(v1031_9);
        let v1031_12: Space = map_map_kernels::unite(&(v1031_7),&(v1031_11));
        join_wrapped_into(&mut v1030_12_write,&((v1031_12).read_zipper()),&[]);
        }
        v1030_12_cursor.ascend(1);
      }
      drop(v1030_12_cursor);
      drop(v1030_12_write);
      map_map_kernels::compose(&(v1022_10),&(v1030_12))
    };
    drop(v1022_10);
    let v1022_14: Space = map_map_kernels::unite(&(v1022_8),&(v1022_13));
    join_wrapped_into(&mut v1021_23_write,&((v1022_14).read_zipper()),&[]);
    }
    v1021_23_cursor.ascend(1);
  }
  drop(v1021_23_cursor);
  drop(v1021_23_write);
  (v1021_23).clone()
}

fn routine_54(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1040_21 = Space::new();
  let mut v1040_21_write = v1040_21.write_zipper();
  let mut v1040_21_cursor = (*s0).read_zipper();
  let v1040_21_origin = v1040_21_cursor.path().len();
  for v1040_21_byte in v1040_21_cursor.child_mask().iter() {
    v1040_21_cursor.descend_to_existing_byte(v1040_21_byte);
    {
    let v1041_2: Space = singleton(&v1040_21_cursor.path()[v1040_21_origin..(v1040_21_origin + 1)]);
    let v1041_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1041_2));
    let v1041_4: Space = if map_kernels::has_head(&(v1041_3)) { singleton(&[]) } else { Space::new() };
    drop(v1041_3);
    let v1041_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1041_4));
    drop(v1041_4);
    let v1041_8: Space = if (&(v1041_5)).is_empty() { Space::new() } else {
      let v1042_6: Path = concat_path(&(*p0),&v1040_21_cursor.path()[v1040_21_origin..(v1040_21_origin + 1)]);
      let mut v1042_7 = Space::new();
      let mut v1042_7_write = v1042_7.write_zipper();
      for v1042_7_byte in v1040_21_cursor.child_mask().iter() {
        v1040_21_cursor.descend_to_existing_byte(v1042_7_byte);
        {
        let v1043_2: Space = singleton(&v1040_21_cursor.path()[(v1040_21_origin + 1)..(v1040_21_origin + 2)]);
        let v1043_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1043_2));
        let v1043_4: Space = if map_kernels::has_head(&(v1043_3)) { singleton(&[]) } else { Space::new() };
        drop(v1043_3);
        let v1043_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1043_4));
        drop(v1043_4);
        let v1043_8: Space = if (&(v1043_5)).is_empty() { Space::new() } else {
          let v1044_6: Path = concat_path(&(v1042_6),&v1040_21_cursor.path()[(v1040_21_origin + 1)..(v1040_21_origin + 2)]);
          let mut v1044_7 = Space::new();
          let mut v1044_7_write = v1044_7.write_zipper();
          for v1044_7_byte in v1040_21_cursor.child_mask().iter() {
            v1040_21_cursor.descend_to_existing_byte(v1044_7_byte);
            {
            let v1045_2: Space = singleton(&v1040_21_cursor.path()[(v1040_21_origin + 2)..(v1040_21_origin + 3)]);
            let v1045_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1045_2));
            let v1045_4: Space = if map_kernels::has_head(&(v1045_3)) { singleton(&[]) } else { Space::new() };
            drop(v1045_3);
            let v1045_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1045_4));
            drop(v1045_4);
            let v1045_8: Space = if (&(v1045_5)).is_empty() { Space::new() } else {
              let v1046_6: Path = concat_path(&(v1044_6),&v1040_21_cursor.path()[(v1040_21_origin + 2)..(v1040_21_origin + 3)]);
              let v1046_7: Space = routine_64(c, &(v1046_6), &(*p1), &v1040_21_cursor);
              map_map_kernels::compose(&(v1045_5),&(v1046_7))
            };
            drop(v1045_5);
            let v1045_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1045_2));
            drop(v1045_2);
            let v1045_10: Space = if map_kernels::has_head(&(v1045_9)) { singleton(&[]) } else { Space::new() };
            drop(v1045_9);
            let v1045_12: Space = if (&(v1045_10)).is_empty() { Space::new() } else {
              let v1047_6: Path = concat_path(&(v1044_6),&v1040_21_cursor.path()[(v1040_21_origin + 2)..(v1040_21_origin + 3)]);
              let v1047_11: Space = routine_65(c, &(v1047_6), &(*p1), &v1040_21_cursor);
              drop(v1047_6);
              map_map_kernels::compose(&(v1045_10),&(v1047_11))
            };
            drop(v1045_10);
            let v1045_13: Space = map_map_kernels::unite(&(v1045_8),&(v1045_12));
            join_wrapped_into(&mut v1044_7_write,&((v1045_13).read_zipper()),&[]);
            }
            v1040_21_cursor.ascend(1);
          }
          drop(v1044_7_write);
          map_map_kernels::compose(&(v1043_5),&(v1044_7))
        };
        drop(v1043_5);
        let v1043_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1043_2));
        drop(v1043_2);
        let v1043_10: Space = if map_kernels::has_head(&(v1043_9)) { singleton(&[]) } else { Space::new() };
        drop(v1043_9);
        let v1043_12: Space = if (&(v1043_10)).is_empty() { Space::new() } else {
          let v1048_6: Path = concat_path(&(v1042_6),&v1040_21_cursor.path()[(v1040_21_origin + 1)..(v1040_21_origin + 2)]);
          let mut v1048_11 = Space::new();
          let mut v1048_11_write = v1048_11.write_zipper();
          for v1048_11_byte in v1040_21_cursor.child_mask().iter() {
            v1040_21_cursor.descend_to_existing_byte(v1048_11_byte);
            {
            let v1049_2: Space = singleton(&v1040_21_cursor.path()[(v1040_21_origin + 2)..(v1040_21_origin + 3)]);
            let v1049_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1049_2));
            let v1049_4: Space = if map_kernels::has_head(&(v1049_3)) { singleton(&[]) } else { Space::new() };
            drop(v1049_3);
            let v1049_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1049_4));
            drop(v1049_4);
            let v1049_8: Space = if (&(v1049_5)).is_empty() { Space::new() } else {
              let v1050_6: Path = concat_path(&(v1048_6),&v1040_21_cursor.path()[(v1040_21_origin + 2)..(v1040_21_origin + 3)]);
              let v1050_7: Space = routine_64(c, &(v1050_6), &(*p1), &v1040_21_cursor);
              map_map_kernels::compose(&(v1049_5),&(v1050_7))
            };
            drop(v1049_5);
            let v1049_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1049_2));
            drop(v1049_2);
            let v1049_10: Space = if map_kernels::has_head(&(v1049_9)) { singleton(&[]) } else { Space::new() };
            drop(v1049_9);
            let v1049_12: Space = if (&(v1049_10)).is_empty() { Space::new() } else {
              let v1051_6: Path = concat_path(&(v1048_6),&v1040_21_cursor.path()[(v1040_21_origin + 2)..(v1040_21_origin + 3)]);
              let v1051_11: Space = routine_19(c, &(v1051_6), &(*p1), &v1040_21_cursor);
              drop(v1051_6);
              map_map_kernels::compose(&(v1049_10),&(v1051_11))
            };
            drop(v1049_10);
            let v1049_13: Space = map_map_kernels::unite(&(v1049_8),&(v1049_12));
            join_wrapped_into(&mut v1048_11_write,&((v1049_13).read_zipper()),&[]);
            }
            v1040_21_cursor.ascend(1);
          }
          drop(v1048_11_write);
          drop(v1048_6);
          map_map_kernels::compose(&(v1043_10),&(v1048_11))
        };
        drop(v1043_10);
        let v1043_13: Space = map_map_kernels::unite(&(v1043_8),&(v1043_12));
        join_wrapped_into(&mut v1042_7_write,&((v1043_13).read_zipper()),&[]);
        }
        v1040_21_cursor.ascend(1);
      }
      drop(v1042_7_write);
      map_map_kernels::compose(&(v1041_5),&(v1042_7))
    };
    drop(v1041_5);
    let v1041_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1041_2));
    drop(v1041_2);
    let v1041_10: Space = if map_kernels::has_head(&(v1041_9)) { singleton(&[]) } else { Space::new() };
    drop(v1041_9);
    let v1041_12: Space = if (&(v1041_10)).is_empty() { Space::new() } else {
      let v1052_6: Path = concat_path(&(*p0),&v1040_21_cursor.path()[v1040_21_origin..(v1040_21_origin + 1)]);
      let mut v1052_11 = Space::new();
      let mut v1052_11_write = v1052_11.write_zipper();
      for v1052_11_byte in v1040_21_cursor.child_mask().iter() {
        v1040_21_cursor.descend_to_existing_byte(v1052_11_byte);
        {
        let v1053_2: Space = singleton(&v1040_21_cursor.path()[(v1040_21_origin + 1)..(v1040_21_origin + 2)]);
        let v1053_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1053_2));
        let v1053_4: Space = if map_kernels::has_head(&(v1053_3)) { singleton(&[]) } else { Space::new() };
        drop(v1053_3);
        let v1053_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1053_4));
        drop(v1053_4);
        let v1053_8: Space = if (&(v1053_5)).is_empty() { Space::new() } else {
          let v1054_6: Path = concat_path(&(v1052_6),&v1040_21_cursor.path()[(v1040_21_origin + 1)..(v1040_21_origin + 2)]);
          let mut v1054_7 = Space::new();
          let mut v1054_7_write = v1054_7.write_zipper();
          for v1054_7_byte in v1040_21_cursor.child_mask().iter() {
            v1040_21_cursor.descend_to_existing_byte(v1054_7_byte);
            {
            let v1055_2: Space = singleton(&v1040_21_cursor.path()[(v1040_21_origin + 2)..(v1040_21_origin + 3)]);
            let v1055_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1055_2));
            let v1055_4: Space = if map_kernels::has_head(&(v1055_3)) { singleton(&[]) } else { Space::new() };
            drop(v1055_3);
            let v1055_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1055_4));
            drop(v1055_4);
            let v1055_8: Space = if (&(v1055_5)).is_empty() { Space::new() } else {
              let v1056_6: Path = concat_path(&(v1054_6),&v1040_21_cursor.path()[(v1040_21_origin + 2)..(v1040_21_origin + 3)]);
              let v1056_7: Space = routine_64(c, &(v1056_6), &(*p1), &v1040_21_cursor);
              map_map_kernels::compose(&(v1055_5),&(v1056_7))
            };
            drop(v1055_5);
            let v1055_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1055_2));
            drop(v1055_2);
            let v1055_10: Space = if map_kernels::has_head(&(v1055_9)) { singleton(&[]) } else { Space::new() };
            drop(v1055_9);
            let v1055_12: Space = if (&(v1055_10)).is_empty() { Space::new() } else {
              let v1057_6: Path = concat_path(&(v1054_6),&v1040_21_cursor.path()[(v1040_21_origin + 2)..(v1040_21_origin + 3)]);
              let v1057_11: Space = routine_65(c, &(v1057_6), &(*p1), &v1040_21_cursor);
              drop(v1057_6);
              map_map_kernels::compose(&(v1055_10),&(v1057_11))
            };
            drop(v1055_10);
            let v1055_13: Space = map_map_kernels::unite(&(v1055_8),&(v1055_12));
            join_wrapped_into(&mut v1054_7_write,&((v1055_13).read_zipper()),&[]);
            }
            v1040_21_cursor.ascend(1);
          }
          drop(v1054_7_write);
          map_map_kernels::compose(&(v1053_5),&(v1054_7))
        };
        drop(v1053_5);
        let v1053_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1053_2));
        drop(v1053_2);
        let v1053_10: Space = if map_kernels::has_head(&(v1053_9)) { singleton(&[]) } else { Space::new() };
        drop(v1053_9);
        let v1053_11: Space = map_view_kernels::compose(&(v1053_10),&v1040_21_cursor);
        drop(v1053_10);
        let v1058_6: Path = concat_path(&(v1052_6),&v1040_21_cursor.path()[(v1040_21_origin + 1)..(v1040_21_origin + 2)]);
        let v1053_12: Space = map_kernels::wrap(&(v1053_11),&(v1058_6));
        drop(v1053_11);
        let v1053_13: Space = map_kernels::wrap(&(v1053_12),&(*p1));
        drop(v1053_12);
        let v1053_14: Space = map_map_kernels::unite(&(v1053_8),&(v1053_13));
        drop(v1053_13);
        join_wrapped_into(&mut v1052_11_write,&((v1053_14).read_zipper()),&[]);
        }
        v1040_21_cursor.ascend(1);
      }
      drop(v1052_11_write);
      drop(v1052_6);
      map_map_kernels::compose(&(v1041_10),&(v1052_11))
    };
    drop(v1041_10);
    let v1041_13: Space = map_map_kernels::unite(&(v1041_8),&(v1041_12));
    join_wrapped_into(&mut v1040_21_write,&((v1041_13).read_zipper()),&[]);
    }
    v1040_21_cursor.ascend(1);
  }
  drop(v1040_21_cursor);
  drop(v1040_21_write);
  (v1040_21).clone()
}

fn routine_55(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1059_15 = Space::new();
  let mut v1059_15_write = v1059_15.write_zipper();
  let mut v1059_15_cursor = (*s0).read_zipper();
  let v1059_15_origin = v1059_15_cursor.path().len();
  for v1059_15_byte in v1059_15_cursor.child_mask().iter() {
    v1059_15_cursor.descend_to_existing_byte(v1059_15_byte);
    {
    let v1060_2: Space = singleton(&v1059_15_cursor.path()[v1059_15_origin..(v1059_15_origin + 1)]);
    let v1060_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1060_2));
    let v1060_4: Space = if map_kernels::has_head(&(v1060_3)) { singleton(&[]) } else { Space::new() };
    drop(v1060_3);
    let v1060_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1060_4));
    drop(v1060_4);
    let v1060_8: Space = if (&(v1060_5)).is_empty() { Space::new() } else {
      let v1061_6: Path = concat_path(&(*p0),&v1059_15_cursor.path()[v1059_15_origin..(v1059_15_origin + 1)]);
      let mut v1061_7 = Space::new();
      let mut v1061_7_write = v1061_7.write_zipper();
      for v1061_7_byte in v1059_15_cursor.child_mask().iter() {
        v1059_15_cursor.descend_to_existing_byte(v1061_7_byte);
        {
        let v1062_2: Space = singleton(&v1059_15_cursor.path()[(v1059_15_origin + 1)..(v1059_15_origin + 2)]);
        let v1062_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1062_2));
        let v1062_4: Space = if map_kernels::has_head(&(v1062_3)) { singleton(&[]) } else { Space::new() };
        drop(v1062_3);
        let v1062_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1062_4));
        drop(v1062_4);
        let v1062_8: Space = if (&(v1062_5)).is_empty() { Space::new() } else {
          let v1063_6: Path = concat_path(&(v1061_6),&v1059_15_cursor.path()[(v1059_15_origin + 1)..(v1059_15_origin + 2)]);
          let mut v1063_7 = Space::new();
          let mut v1063_7_write = v1063_7.write_zipper();
          for v1063_7_byte in v1059_15_cursor.child_mask().iter() {
            v1059_15_cursor.descend_to_existing_byte(v1063_7_byte);
            {
            let v1064_2: Space = singleton(&v1059_15_cursor.path()[(v1059_15_origin + 2)..(v1059_15_origin + 3)]);
            let v1064_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1064_2));
            let v1064_4: Space = if map_kernels::has_head(&(v1064_3)) { singleton(&[]) } else { Space::new() };
            drop(v1064_3);
            let v1064_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1064_4));
            drop(v1064_4);
            let v1064_8: Space = if (&(v1064_5)).is_empty() { Space::new() } else {
              let v1065_6: Path = concat_path(&(v1063_6),&v1059_15_cursor.path()[(v1059_15_origin + 2)..(v1059_15_origin + 3)]);
              let v1065_7: Space = routine_64(c, &(v1065_6), &(*p1), &v1059_15_cursor);
              map_map_kernels::compose(&(v1064_5),&(v1065_7))
            };
            drop(v1064_5);
            let v1064_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1064_2));
            drop(v1064_2);
            let v1064_10: Space = if map_kernels::has_head(&(v1064_9)) { singleton(&[]) } else { Space::new() };
            drop(v1064_9);
            let v1064_12: Space = if (&(v1064_10)).is_empty() { Space::new() } else {
              let v1066_6: Path = concat_path(&(v1063_6),&v1059_15_cursor.path()[(v1059_15_origin + 2)..(v1059_15_origin + 3)]);
              let v1066_11: Space = routine_65(c, &(v1066_6), &(*p1), &v1059_15_cursor);
              drop(v1066_6);
              map_map_kernels::compose(&(v1064_10),&(v1066_11))
            };
            drop(v1064_10);
            let v1064_13: Space = map_map_kernels::unite(&(v1064_8),&(v1064_12));
            join_wrapped_into(&mut v1063_7_write,&((v1064_13).read_zipper()),&[]);
            }
            v1059_15_cursor.ascend(1);
          }
          drop(v1063_7_write);
          map_map_kernels::compose(&(v1062_5),&(v1063_7))
        };
        drop(v1062_5);
        let v1062_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1062_2));
        drop(v1062_2);
        let v1062_10: Space = if map_kernels::has_head(&(v1062_9)) { singleton(&[]) } else { Space::new() };
        drop(v1062_9);
        let v1062_12: Space = if (&(v1062_10)).is_empty() { Space::new() } else {
          let v1067_6: Path = concat_path(&(v1061_6),&v1059_15_cursor.path()[(v1059_15_origin + 1)..(v1059_15_origin + 2)]);
          let mut v1067_11 = Space::new();
          let mut v1067_11_write = v1067_11.write_zipper();
          for v1067_11_byte in v1059_15_cursor.child_mask().iter() {
            v1059_15_cursor.descend_to_existing_byte(v1067_11_byte);
            {
            let v1068_2: Space = singleton(&v1059_15_cursor.path()[(v1059_15_origin + 2)..(v1059_15_origin + 3)]);
            let v1068_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1068_2));
            let v1068_4: Space = if map_kernels::has_head(&(v1068_3)) { singleton(&[]) } else { Space::new() };
            drop(v1068_3);
            let v1068_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1068_4));
            drop(v1068_4);
            let v1068_8: Space = if (&(v1068_5)).is_empty() { Space::new() } else {
              let v1069_6: Path = concat_path(&(v1067_6),&v1059_15_cursor.path()[(v1059_15_origin + 2)..(v1059_15_origin + 3)]);
              let v1069_7: Space = routine_64(c, &(v1069_6), &(*p1), &v1059_15_cursor);
              map_map_kernels::compose(&(v1068_5),&(v1069_7))
            };
            drop(v1068_5);
            let v1068_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1068_2));
            drop(v1068_2);
            let v1068_10: Space = if map_kernels::has_head(&(v1068_9)) { singleton(&[]) } else { Space::new() };
            drop(v1068_9);
            let v1068_12: Space = if (&(v1068_10)).is_empty() { Space::new() } else {
              let v1070_6: Path = concat_path(&(v1067_6),&v1059_15_cursor.path()[(v1059_15_origin + 2)..(v1059_15_origin + 3)]);
              let v1070_11: Space = routine_19(c, &(v1070_6), &(*p1), &v1059_15_cursor);
              drop(v1070_6);
              map_map_kernels::compose(&(v1068_10),&(v1070_11))
            };
            drop(v1068_10);
            let v1068_13: Space = map_map_kernels::unite(&(v1068_8),&(v1068_12));
            join_wrapped_into(&mut v1067_11_write,&((v1068_13).read_zipper()),&[]);
            }
            v1059_15_cursor.ascend(1);
          }
          drop(v1067_11_write);
          drop(v1067_6);
          map_map_kernels::compose(&(v1062_10),&(v1067_11))
        };
        drop(v1062_10);
        let v1062_13: Space = map_map_kernels::unite(&(v1062_8),&(v1062_12));
        join_wrapped_into(&mut v1061_7_write,&((v1062_13).read_zipper()),&[]);
        }
        v1059_15_cursor.ascend(1);
      }
      drop(v1061_7_write);
      map_map_kernels::compose(&(v1060_5),&(v1061_7))
    };
    drop(v1060_5);
    let v1060_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1060_2));
    drop(v1060_2);
    let v1060_10: Space = if map_kernels::has_head(&(v1060_9)) { singleton(&[]) } else { Space::new() };
    drop(v1060_9);
    let v1060_11: Space = map_view_kernels::compose(&(v1060_10),&v1059_15_cursor);
    drop(v1060_10);
    let v1071_6: Path = concat_path(&(*p0),&v1059_15_cursor.path()[v1059_15_origin..(v1059_15_origin + 1)]);
    let v1060_12: Space = map_kernels::wrap(&(v1060_11),&(v1071_6));
    drop(v1060_11);
    let v1060_13: Space = map_kernels::wrap(&(v1060_12),&(*p1));
    drop(v1060_12);
    let v1060_14: Space = map_map_kernels::unite(&(v1060_8),&(v1060_13));
    drop(v1060_13);
    join_wrapped_into(&mut v1059_15_write,&((v1060_14).read_zipper()),&[]);
    }
    v1059_15_cursor.ascend(1);
  }
  drop(v1059_15_cursor);
  drop(v1059_15_write);
  (v1059_15).clone()
}

fn routine_56(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v1072_14 = Space::new();
  let mut v1072_14_write = v1072_14.write_zipper();
  let mut v1072_14_cursor = (*s0).read_zipper();
  let v1072_14_origin = v1072_14_cursor.path().len();
  for v1072_14_byte in v1072_14_cursor.child_mask().iter() {
    v1072_14_cursor.descend_to_existing_byte(v1072_14_byte);
    {
    let v1073_2: Space = singleton(&v1072_14_cursor.path()[v1072_14_origin..(v1072_14_origin + 1)]);
    let v1073_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1073_2));
    let v1073_4: Space = if map_kernels::has_head(&(v1073_3)) { singleton(&[]) } else { Space::new() };
    drop(v1073_3);
    let v1073_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1073_4));
    drop(v1073_4);
    let v1073_7: Space = if (&(v1073_5)).is_empty() { Space::new() } else {
      let mut v1074_6 = Space::new();
      let mut v1074_6_write = v1074_6.write_zipper();
      for v1074_6_byte in v1072_14_cursor.child_mask().iter() {
        v1072_14_cursor.descend_to_existing_byte(v1074_6_byte);
        {
        let v1075_2: Space = Space::new();
        join_wrapped_into(&mut v1074_6_write,&((v1075_2).read_zipper()),&[]);
        }
        v1072_14_cursor.ascend(1);
      }
      drop(v1074_6_write);
      map_map_kernels::compose(&(v1073_5),&(v1074_6))
    };
    drop(v1073_5);
    let v1073_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1073_2));
    drop(v1073_2);
    let v1073_9: Space = if map_kernels::has_head(&(v1073_8)) { singleton(&[]) } else { Space::new() };
    drop(v1073_8);
    let v1073_12: Space = if (&(v1073_9)).is_empty() { Space::new() } else {
      let mut v1076_11 = Space::new();
      let mut v1076_11_write = v1076_11.write_zipper();
      for v1076_11_byte in v1072_14_cursor.child_mask().iter() {
        v1072_14_cursor.descend_to_existing_byte(v1076_11_byte);
        {
        let v1077_2: Space = singleton(&v1072_14_cursor.path()[(v1072_14_origin + 1)..(v1072_14_origin + 2)]);
        let v1077_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1077_2));
        drop(v1077_2);
        let v1077_4: Space = if map_kernels::has_head(&(v1077_3)) { singleton(&[]) } else { Space::new() };
        drop(v1077_3);
        let v1077_7: Space = if (&(v1077_4)).is_empty() { Space::new() } else {
          let mut v1078_6 = Space::new();
          let mut v1078_6_write = v1078_6.write_zipper();
          let mut v1078_6_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v1072_14_cursor.path()[v1072_14_origin..(v1072_14_origin + 1)]),&v1072_14_cursor.path()[(v1072_14_origin + 1)..(v1072_14_origin + 2)]);
          let v1078_6_origin = v1078_6_cursor.path().len();
          for v1078_6_byte in v1078_6_cursor.child_mask().iter() {
            v1078_6_cursor.descend_to_existing_byte(v1078_6_byte);
            {
            let v1079_2: Space = singleton(&v1078_6_cursor.path()[v1078_6_origin..(v1078_6_origin + 1)]);
            let v1079_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1079_2));
            let v1079_4: Space = if map_kernels::has_head(&(v1079_3)) { singleton(&[]) } else { Space::new() };
            drop(v1079_3);
            let v1079_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1079_4));
            drop(v1079_4);
            let v1079_7: Space = if (&(v1079_5)).is_empty() { Space::new() } else {
              let v1080_6: Space = routine_13(c, &v1078_6_cursor.path()[v1078_6_origin..(v1078_6_origin + 1)], &(*p1), &v1078_6_cursor);
              map_map_kernels::compose(&(v1079_5),&(v1080_6))
            };
            drop(v1079_5);
            let v1079_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1079_2));
            drop(v1079_2);
            let v1079_9: Space = if map_kernels::has_head(&(v1079_8)) { singleton(&[]) } else { Space::new() };
            drop(v1079_8);
            let v1079_11: Space = if (&(v1079_9)).is_empty() { Space::new() } else {
              let v1081_10: Space = routine_14(c, &v1078_6_cursor.path()[v1078_6_origin..(v1078_6_origin + 1)], &(*p1), &v1078_6_cursor);
              map_map_kernels::compose(&(v1079_9),&(v1081_10))
            };
            drop(v1079_9);
            let v1079_12: Space = map_map_kernels::unite(&(v1079_7),&(v1079_11));
            join_wrapped_into(&mut v1078_6_write,&((v1079_12).read_zipper()),&[]);
            }
            v1078_6_cursor.ascend(1);
          }
          drop(v1078_6_cursor);
          drop(v1078_6_write);
          map_map_kernels::compose(&(v1077_4),&(v1078_6))
        };
        drop(v1077_4);
        join_wrapped_into(&mut v1076_11_write,&((v1077_7).read_zipper()),&[]);
        }
        v1072_14_cursor.ascend(1);
      }
      drop(v1076_11_write);
      map_map_kernels::compose(&(v1073_9),&(v1076_11))
    };
    drop(v1073_9);
    let v1073_13: Space = map_map_kernels::unite(&(v1073_7),&(v1073_12));
    drop(v1073_7);
    join_wrapped_into(&mut v1072_14_write,&((v1073_13).read_zipper()),&[]);
    }
    v1072_14_cursor.ascend(1);
  }
  drop(v1072_14_cursor);
  drop(v1072_14_write);
  (v1072_14).clone()
}

fn routine_57(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v1082_19 = Space::new();
  let mut v1082_19_write = v1082_19.write_zipper();
  let mut v1082_19_cursor = (*s0).read_zipper();
  let v1082_19_origin = v1082_19_cursor.path().len();
  for v1082_19_byte in v1082_19_cursor.child_mask().iter() {
    v1082_19_cursor.descend_to_existing_byte(v1082_19_byte);
    {
    let v1083_2: Space = singleton(&v1082_19_cursor.path()[v1082_19_origin..(v1082_19_origin + 1)]);
    let v1083_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1083_2));
    let v1083_4: Space = if map_kernels::has_head(&(v1083_3)) { singleton(&[]) } else { Space::new() };
    drop(v1083_3);
    let v1083_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1083_4));
    drop(v1083_4);
    let v1083_7: Space = if (&(v1083_5)).is_empty() { Space::new() } else {
      let mut v1084_6 = Space::new();
      let mut v1084_6_write = v1084_6.write_zipper();
      for v1084_6_byte in v1082_19_cursor.child_mask().iter() {
        v1082_19_cursor.descend_to_existing_byte(v1084_6_byte);
        {
        let v1085_2: Space = Space::new();
        join_wrapped_into(&mut v1084_6_write,&((v1085_2).read_zipper()),&[]);
        }
        v1082_19_cursor.ascend(1);
      }
      drop(v1084_6_write);
      map_map_kernels::compose(&(v1083_5),&(v1084_6))
    };
    drop(v1083_5);
    let v1083_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1083_2));
    drop(v1083_2);
    let v1083_9: Space = if map_kernels::has_head(&(v1083_8)) { singleton(&[]) } else { Space::new() };
    drop(v1083_8);
    let v1083_12: Space = if (&(v1083_9)).is_empty() { Space::new() } else {
      let mut v1086_11 = Space::new();
      let mut v1086_11_write = v1086_11.write_zipper();
      let mut v1086_11_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v1082_19_cursor.path()[v1082_19_origin..(v1082_19_origin + 1)]);
      let v1086_11_origin = v1086_11_cursor.path().len();
      for v1086_11_byte in v1086_11_cursor.child_mask().iter() {
        v1086_11_cursor.descend_to_existing_byte(v1086_11_byte);
        {
        let v1087_2: Space = singleton(&v1086_11_cursor.path()[v1086_11_origin..(v1086_11_origin + 1)]);
        let v1087_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1087_2));
        let v1087_4: Space = if map_kernels::has_head(&(v1087_3)) { singleton(&[]) } else { Space::new() };
        drop(v1087_3);
        let v1087_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1087_4));
        drop(v1087_4);
        let v1087_7: Space = if (&(v1087_5)).is_empty() { Space::new() } else {
          let mut v1088_6 = Space::new();
          let mut v1088_6_write = v1088_6.write_zipper();
          for v1088_6_byte in v1086_11_cursor.child_mask().iter() {
            v1086_11_cursor.descend_to_existing_byte(v1088_6_byte);
            {
            let v1089_2: Space = singleton(&v1086_11_cursor.path()[(v1086_11_origin + 1)..(v1086_11_origin + 2)]);
            let v1089_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1089_2));
            let v1089_4: Space = if map_kernels::has_head(&(v1089_3)) { singleton(&[]) } else { Space::new() };
            drop(v1089_3);
            let v1089_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1089_4));
            drop(v1089_4);
            let v1089_8: Space = if (&(v1089_5)).is_empty() { Space::new() } else {
              let v1090_7: Space = routine_17(c, &v1086_11_cursor.path()[v1086_11_origin..(v1086_11_origin + 2)], &(*p1), &v1086_11_cursor);
              map_map_kernels::compose(&(v1089_5),&(v1090_7))
            };
            drop(v1089_5);
            let v1089_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1089_2));
            drop(v1089_2);
            let v1089_10: Space = if map_kernels::has_head(&(v1089_9)) { singleton(&[]) } else { Space::new() };
            drop(v1089_9);
            let v1089_12: Space = if (&(v1089_10)).is_empty() { Space::new() } else {
              let v1091_11: Space = routine_18(c, &v1086_11_cursor.path()[v1086_11_origin..(v1086_11_origin + 2)], &(*p1), &v1086_11_cursor);
              map_map_kernels::compose(&(v1089_10),&(v1091_11))
            };
            drop(v1089_10);
            let v1089_13: Space = map_map_kernels::unite(&(v1089_8),&(v1089_12));
            join_wrapped_into(&mut v1088_6_write,&((v1089_13).read_zipper()),&[]);
            }
            v1086_11_cursor.ascend(1);
          }
          drop(v1088_6_write);
          map_map_kernels::compose(&(v1087_5),&(v1088_6))
        };
        drop(v1087_5);
        let v1087_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1087_2));
        drop(v1087_2);
        let v1087_9: Space = if map_kernels::has_head(&(v1087_8)) { singleton(&[]) } else { Space::new() };
        drop(v1087_8);
        let v1087_11: Space = if (&(v1087_9)).is_empty() { Space::new() } else {
          let mut v1092_10 = Space::new();
          let mut v1092_10_write = v1092_10.write_zipper();
          for v1092_10_byte in v1086_11_cursor.child_mask().iter() {
            v1086_11_cursor.descend_to_existing_byte(v1092_10_byte);
            {
            let v1093_2: Space = singleton(&v1086_11_cursor.path()[(v1086_11_origin + 1)..(v1086_11_origin + 2)]);
            let v1093_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1093_2));
            let v1093_4: Space = if map_kernels::has_head(&(v1093_3)) { singleton(&[]) } else { Space::new() };
            drop(v1093_3);
            let v1093_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1093_4));
            drop(v1093_4);
            let v1093_8: Space = if (&(v1093_5)).is_empty() { Space::new() } else {
              let v1094_7: Space = routine_17(c, &v1086_11_cursor.path()[v1086_11_origin..(v1086_11_origin + 2)], &(*p1), &v1086_11_cursor);
              map_map_kernels::compose(&(v1093_5),&(v1094_7))
            };
            drop(v1093_5);
            let v1093_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1093_2));
            drop(v1093_2);
            let v1093_10: Space = if map_kernels::has_head(&(v1093_9)) { singleton(&[]) } else { Space::new() };
            drop(v1093_9);
            let v1093_12: Space = if (&(v1093_10)).is_empty() { Space::new() } else {
              let v1095_11: Space = routine_19(c, &v1086_11_cursor.path()[v1086_11_origin..(v1086_11_origin + 2)], &(*p1), &v1086_11_cursor);
              map_map_kernels::compose(&(v1093_10),&(v1095_11))
            };
            drop(v1093_10);
            let v1093_13: Space = map_map_kernels::unite(&(v1093_8),&(v1093_12));
            join_wrapped_into(&mut v1092_10_write,&((v1093_13).read_zipper()),&[]);
            }
            v1086_11_cursor.ascend(1);
          }
          drop(v1092_10_write);
          map_map_kernels::compose(&(v1087_9),&(v1092_10))
        };
        drop(v1087_9);
        let v1087_12: Space = map_map_kernels::unite(&(v1087_7),&(v1087_11));
        join_wrapped_into(&mut v1086_11_write,&((v1087_12).read_zipper()),&[]);
        }
        v1086_11_cursor.ascend(1);
      }
      drop(v1086_11_cursor);
      drop(v1086_11_write);
      map_map_kernels::compose(&(v1083_9),&(v1086_11))
    };
    drop(v1083_9);
    let v1083_13: Space = map_map_kernels::unite(&(v1083_7),&(v1083_12));
    drop(v1083_7);
    join_wrapped_into(&mut v1082_19_write,&((v1083_13).read_zipper()),&[]);
    }
    v1082_19_cursor.ascend(1);
  }
  drop(v1082_19_cursor);
  drop(v1082_19_write);
  (v1082_19).clone()
}

fn routine_58(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1096_21 = Space::new();
  let mut v1096_21_write = v1096_21.write_zipper();
  let mut v1096_21_cursor = (*s0).read_zipper();
  let v1096_21_origin = v1096_21_cursor.path().len();
  for v1096_21_byte in v1096_21_cursor.child_mask().iter() {
    v1096_21_cursor.descend_to_existing_byte(v1096_21_byte);
    {
    let v1097_2: Space = singleton(&v1096_21_cursor.path()[v1096_21_origin..(v1096_21_origin + 1)]);
    let v1097_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1097_2));
    let v1097_4: Space = if map_kernels::has_head(&(v1097_3)) { singleton(&[]) } else { Space::new() };
    drop(v1097_3);
    let v1097_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1097_4));
    drop(v1097_4);
    let v1097_8: Space = if (&(v1097_5)).is_empty() { Space::new() } else {
      let v1098_6: Path = concat_path(&(*p0),&v1096_21_cursor.path()[v1096_21_origin..(v1096_21_origin + 1)]);
      let mut v1098_7 = Space::new();
      let mut v1098_7_write = v1098_7.write_zipper();
      for v1098_7_byte in v1096_21_cursor.child_mask().iter() {
        v1096_21_cursor.descend_to_existing_byte(v1098_7_byte);
        {
        let v1099_2: Space = singleton(&v1096_21_cursor.path()[(v1096_21_origin + 1)..(v1096_21_origin + 2)]);
        let v1099_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1099_2));
        let v1099_4: Space = if map_kernels::has_head(&(v1099_3)) { singleton(&[]) } else { Space::new() };
        drop(v1099_3);
        let v1099_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1099_4));
        drop(v1099_4);
        let v1099_8: Space = if (&(v1099_5)).is_empty() { Space::new() } else {
          let v1100_6: Path = concat_path(&(v1098_6),&v1096_21_cursor.path()[(v1096_21_origin + 1)..(v1096_21_origin + 2)]);
          let mut v1100_7 = Space::new();
          let mut v1100_7_write = v1100_7.write_zipper();
          for v1100_7_byte in v1096_21_cursor.child_mask().iter() {
            v1096_21_cursor.descend_to_existing_byte(v1100_7_byte);
            {
            let v1101_2: Space = singleton(&v1096_21_cursor.path()[(v1096_21_origin + 2)..(v1096_21_origin + 3)]);
            let v1101_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1101_2));
            let v1101_4: Space = if map_kernels::has_head(&(v1101_3)) { singleton(&[]) } else { Space::new() };
            drop(v1101_3);
            let v1101_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1101_4));
            drop(v1101_4);
            let v1101_8: Space = if (&(v1101_5)).is_empty() { Space::new() } else {
              let v1102_6: Path = concat_path(&(v1100_6),&v1096_21_cursor.path()[(v1096_21_origin + 2)..(v1096_21_origin + 3)]);
              let v1102_7: Space = routine_66(c, &(v1102_6), &(*p1), &v1096_21_cursor);
              map_map_kernels::compose(&(v1101_5),&(v1102_7))
            };
            drop(v1101_5);
            let v1101_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1101_2));
            drop(v1101_2);
            let v1101_10: Space = if map_kernels::has_head(&(v1101_9)) { singleton(&[]) } else { Space::new() };
            drop(v1101_9);
            let v1101_12: Space = if (&(v1101_10)).is_empty() { Space::new() } else {
              let v1103_6: Path = concat_path(&(v1100_6),&v1096_21_cursor.path()[(v1096_21_origin + 2)..(v1096_21_origin + 3)]);
              let v1103_11: Space = routine_67(c, &(v1103_6), &(*p1), &v1096_21_cursor);
              drop(v1103_6);
              map_map_kernels::compose(&(v1101_10),&(v1103_11))
            };
            drop(v1101_10);
            let v1101_13: Space = map_map_kernels::unite(&(v1101_8),&(v1101_12));
            join_wrapped_into(&mut v1100_7_write,&((v1101_13).read_zipper()),&[]);
            }
            v1096_21_cursor.ascend(1);
          }
          drop(v1100_7_write);
          map_map_kernels::compose(&(v1099_5),&(v1100_7))
        };
        drop(v1099_5);
        let v1099_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1099_2));
        drop(v1099_2);
        let v1099_10: Space = if map_kernels::has_head(&(v1099_9)) { singleton(&[]) } else { Space::new() };
        drop(v1099_9);
        let v1099_12: Space = if (&(v1099_10)).is_empty() { Space::new() } else {
          let v1104_6: Path = concat_path(&(v1098_6),&v1096_21_cursor.path()[(v1096_21_origin + 1)..(v1096_21_origin + 2)]);
          let mut v1104_11 = Space::new();
          let mut v1104_11_write = v1104_11.write_zipper();
          for v1104_11_byte in v1096_21_cursor.child_mask().iter() {
            v1096_21_cursor.descend_to_existing_byte(v1104_11_byte);
            {
            let v1105_2: Space = singleton(&v1096_21_cursor.path()[(v1096_21_origin + 2)..(v1096_21_origin + 3)]);
            let v1105_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1105_2));
            let v1105_4: Space = if map_kernels::has_head(&(v1105_3)) { singleton(&[]) } else { Space::new() };
            drop(v1105_3);
            let v1105_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1105_4));
            drop(v1105_4);
            let v1105_8: Space = if (&(v1105_5)).is_empty() { Space::new() } else {
              let v1106_6: Path = concat_path(&(v1104_6),&v1096_21_cursor.path()[(v1096_21_origin + 2)..(v1096_21_origin + 3)]);
              let v1106_7: Space = routine_66(c, &(v1106_6), &(*p1), &v1096_21_cursor);
              map_map_kernels::compose(&(v1105_5),&(v1106_7))
            };
            drop(v1105_5);
            let v1105_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1105_2));
            drop(v1105_2);
            let v1105_10: Space = if map_kernels::has_head(&(v1105_9)) { singleton(&[]) } else { Space::new() };
            drop(v1105_9);
            let v1105_12: Space = if (&(v1105_10)).is_empty() { Space::new() } else {
              let v1107_6: Path = concat_path(&(v1104_6),&v1096_21_cursor.path()[(v1096_21_origin + 2)..(v1096_21_origin + 3)]);
              let v1107_11: Space = routine_19(c, &(v1107_6), &(*p1), &v1096_21_cursor);
              drop(v1107_6);
              map_map_kernels::compose(&(v1105_10),&(v1107_11))
            };
            drop(v1105_10);
            let v1105_13: Space = map_map_kernels::unite(&(v1105_8),&(v1105_12));
            join_wrapped_into(&mut v1104_11_write,&((v1105_13).read_zipper()),&[]);
            }
            v1096_21_cursor.ascend(1);
          }
          drop(v1104_11_write);
          drop(v1104_6);
          map_map_kernels::compose(&(v1099_10),&(v1104_11))
        };
        drop(v1099_10);
        let v1099_13: Space = map_map_kernels::unite(&(v1099_8),&(v1099_12));
        join_wrapped_into(&mut v1098_7_write,&((v1099_13).read_zipper()),&[]);
        }
        v1096_21_cursor.ascend(1);
      }
      drop(v1098_7_write);
      map_map_kernels::compose(&(v1097_5),&(v1098_7))
    };
    drop(v1097_5);
    let v1097_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1097_2));
    drop(v1097_2);
    let v1097_10: Space = if map_kernels::has_head(&(v1097_9)) { singleton(&[]) } else { Space::new() };
    drop(v1097_9);
    let v1097_12: Space = if (&(v1097_10)).is_empty() { Space::new() } else {
      let v1108_6: Path = concat_path(&(*p0),&v1096_21_cursor.path()[v1096_21_origin..(v1096_21_origin + 1)]);
      let mut v1108_11 = Space::new();
      let mut v1108_11_write = v1108_11.write_zipper();
      for v1108_11_byte in v1096_21_cursor.child_mask().iter() {
        v1096_21_cursor.descend_to_existing_byte(v1108_11_byte);
        {
        let v1109_2: Space = singleton(&v1096_21_cursor.path()[(v1096_21_origin + 1)..(v1096_21_origin + 2)]);
        let v1109_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1109_2));
        let v1109_4: Space = if map_kernels::has_head(&(v1109_3)) { singleton(&[]) } else { Space::new() };
        drop(v1109_3);
        let v1109_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1109_4));
        drop(v1109_4);
        let v1109_8: Space = if (&(v1109_5)).is_empty() { Space::new() } else {
          let v1110_6: Path = concat_path(&(v1108_6),&v1096_21_cursor.path()[(v1096_21_origin + 1)..(v1096_21_origin + 2)]);
          let mut v1110_7 = Space::new();
          let mut v1110_7_write = v1110_7.write_zipper();
          for v1110_7_byte in v1096_21_cursor.child_mask().iter() {
            v1096_21_cursor.descend_to_existing_byte(v1110_7_byte);
            {
            let v1111_2: Space = singleton(&v1096_21_cursor.path()[(v1096_21_origin + 2)..(v1096_21_origin + 3)]);
            let v1111_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1111_2));
            let v1111_4: Space = if map_kernels::has_head(&(v1111_3)) { singleton(&[]) } else { Space::new() };
            drop(v1111_3);
            let v1111_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1111_4));
            drop(v1111_4);
            let v1111_8: Space = if (&(v1111_5)).is_empty() { Space::new() } else {
              let v1112_6: Path = concat_path(&(v1110_6),&v1096_21_cursor.path()[(v1096_21_origin + 2)..(v1096_21_origin + 3)]);
              let v1112_7: Space = routine_66(c, &(v1112_6), &(*p1), &v1096_21_cursor);
              map_map_kernels::compose(&(v1111_5),&(v1112_7))
            };
            drop(v1111_5);
            let v1111_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1111_2));
            drop(v1111_2);
            let v1111_10: Space = if map_kernels::has_head(&(v1111_9)) { singleton(&[]) } else { Space::new() };
            drop(v1111_9);
            let v1111_12: Space = if (&(v1111_10)).is_empty() { Space::new() } else {
              let v1113_6: Path = concat_path(&(v1110_6),&v1096_21_cursor.path()[(v1096_21_origin + 2)..(v1096_21_origin + 3)]);
              let v1113_11: Space = routine_67(c, &(v1113_6), &(*p1), &v1096_21_cursor);
              drop(v1113_6);
              map_map_kernels::compose(&(v1111_10),&(v1113_11))
            };
            drop(v1111_10);
            let v1111_13: Space = map_map_kernels::unite(&(v1111_8),&(v1111_12));
            join_wrapped_into(&mut v1110_7_write,&((v1111_13).read_zipper()),&[]);
            }
            v1096_21_cursor.ascend(1);
          }
          drop(v1110_7_write);
          map_map_kernels::compose(&(v1109_5),&(v1110_7))
        };
        drop(v1109_5);
        let v1109_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1109_2));
        drop(v1109_2);
        let v1109_10: Space = if map_kernels::has_head(&(v1109_9)) { singleton(&[]) } else { Space::new() };
        drop(v1109_9);
        let v1109_11: Space = map_view_kernels::compose(&(v1109_10),&v1096_21_cursor);
        drop(v1109_10);
        let v1114_6: Path = concat_path(&(v1108_6),&v1096_21_cursor.path()[(v1096_21_origin + 1)..(v1096_21_origin + 2)]);
        let v1109_12: Space = map_kernels::wrap(&(v1109_11),&(v1114_6));
        drop(v1109_11);
        let v1109_13: Space = map_kernels::wrap(&(v1109_12),&(*p1));
        drop(v1109_12);
        let v1109_14: Space = map_map_kernels::unite(&(v1109_8),&(v1109_13));
        drop(v1109_13);
        join_wrapped_into(&mut v1108_11_write,&((v1109_14).read_zipper()),&[]);
        }
        v1096_21_cursor.ascend(1);
      }
      drop(v1108_11_write);
      drop(v1108_6);
      map_map_kernels::compose(&(v1097_10),&(v1108_11))
    };
    drop(v1097_10);
    let v1097_13: Space = map_map_kernels::unite(&(v1097_8),&(v1097_12));
    join_wrapped_into(&mut v1096_21_write,&((v1097_13).read_zipper()),&[]);
    }
    v1096_21_cursor.ascend(1);
  }
  drop(v1096_21_cursor);
  drop(v1096_21_write);
  (v1096_21).clone()
}

fn routine_59(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1115_15 = Space::new();
  let mut v1115_15_write = v1115_15.write_zipper();
  let mut v1115_15_cursor = (*s0).read_zipper();
  let v1115_15_origin = v1115_15_cursor.path().len();
  for v1115_15_byte in v1115_15_cursor.child_mask().iter() {
    v1115_15_cursor.descend_to_existing_byte(v1115_15_byte);
    {
    let v1116_2: Space = singleton(&v1115_15_cursor.path()[v1115_15_origin..(v1115_15_origin + 1)]);
    let v1116_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1116_2));
    let v1116_4: Space = if map_kernels::has_head(&(v1116_3)) { singleton(&[]) } else { Space::new() };
    drop(v1116_3);
    let v1116_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1116_4));
    drop(v1116_4);
    let v1116_8: Space = if (&(v1116_5)).is_empty() { Space::new() } else {
      let v1117_6: Path = concat_path(&(*p0),&v1115_15_cursor.path()[v1115_15_origin..(v1115_15_origin + 1)]);
      let mut v1117_7 = Space::new();
      let mut v1117_7_write = v1117_7.write_zipper();
      for v1117_7_byte in v1115_15_cursor.child_mask().iter() {
        v1115_15_cursor.descend_to_existing_byte(v1117_7_byte);
        {
        let v1118_2: Space = singleton(&v1115_15_cursor.path()[(v1115_15_origin + 1)..(v1115_15_origin + 2)]);
        let v1118_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1118_2));
        let v1118_4: Space = if map_kernels::has_head(&(v1118_3)) { singleton(&[]) } else { Space::new() };
        drop(v1118_3);
        let v1118_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1118_4));
        drop(v1118_4);
        let v1118_8: Space = if (&(v1118_5)).is_empty() { Space::new() } else {
          let v1119_6: Path = concat_path(&(v1117_6),&v1115_15_cursor.path()[(v1115_15_origin + 1)..(v1115_15_origin + 2)]);
          let mut v1119_7 = Space::new();
          let mut v1119_7_write = v1119_7.write_zipper();
          for v1119_7_byte in v1115_15_cursor.child_mask().iter() {
            v1115_15_cursor.descend_to_existing_byte(v1119_7_byte);
            {
            let v1120_2: Space = singleton(&v1115_15_cursor.path()[(v1115_15_origin + 2)..(v1115_15_origin + 3)]);
            let v1120_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1120_2));
            let v1120_4: Space = if map_kernels::has_head(&(v1120_3)) { singleton(&[]) } else { Space::new() };
            drop(v1120_3);
            let v1120_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1120_4));
            drop(v1120_4);
            let v1120_8: Space = if (&(v1120_5)).is_empty() { Space::new() } else {
              let v1121_6: Path = concat_path(&(v1119_6),&v1115_15_cursor.path()[(v1115_15_origin + 2)..(v1115_15_origin + 3)]);
              let v1121_7: Space = routine_66(c, &(v1121_6), &(*p1), &v1115_15_cursor);
              map_map_kernels::compose(&(v1120_5),&(v1121_7))
            };
            drop(v1120_5);
            let v1120_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1120_2));
            drop(v1120_2);
            let v1120_10: Space = if map_kernels::has_head(&(v1120_9)) { singleton(&[]) } else { Space::new() };
            drop(v1120_9);
            let v1120_12: Space = if (&(v1120_10)).is_empty() { Space::new() } else {
              let v1122_6: Path = concat_path(&(v1119_6),&v1115_15_cursor.path()[(v1115_15_origin + 2)..(v1115_15_origin + 3)]);
              let v1122_11: Space = routine_67(c, &(v1122_6), &(*p1), &v1115_15_cursor);
              drop(v1122_6);
              map_map_kernels::compose(&(v1120_10),&(v1122_11))
            };
            drop(v1120_10);
            let v1120_13: Space = map_map_kernels::unite(&(v1120_8),&(v1120_12));
            join_wrapped_into(&mut v1119_7_write,&((v1120_13).read_zipper()),&[]);
            }
            v1115_15_cursor.ascend(1);
          }
          drop(v1119_7_write);
          map_map_kernels::compose(&(v1118_5),&(v1119_7))
        };
        drop(v1118_5);
        let v1118_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1118_2));
        drop(v1118_2);
        let v1118_10: Space = if map_kernels::has_head(&(v1118_9)) { singleton(&[]) } else { Space::new() };
        drop(v1118_9);
        let v1118_12: Space = if (&(v1118_10)).is_empty() { Space::new() } else {
          let v1123_6: Path = concat_path(&(v1117_6),&v1115_15_cursor.path()[(v1115_15_origin + 1)..(v1115_15_origin + 2)]);
          let mut v1123_11 = Space::new();
          let mut v1123_11_write = v1123_11.write_zipper();
          for v1123_11_byte in v1115_15_cursor.child_mask().iter() {
            v1115_15_cursor.descend_to_existing_byte(v1123_11_byte);
            {
            let v1124_2: Space = singleton(&v1115_15_cursor.path()[(v1115_15_origin + 2)..(v1115_15_origin + 3)]);
            let v1124_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1124_2));
            let v1124_4: Space = if map_kernels::has_head(&(v1124_3)) { singleton(&[]) } else { Space::new() };
            drop(v1124_3);
            let v1124_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1124_4));
            drop(v1124_4);
            let v1124_8: Space = if (&(v1124_5)).is_empty() { Space::new() } else {
              let v1125_6: Path = concat_path(&(v1123_6),&v1115_15_cursor.path()[(v1115_15_origin + 2)..(v1115_15_origin + 3)]);
              let v1125_7: Space = routine_66(c, &(v1125_6), &(*p1), &v1115_15_cursor);
              map_map_kernels::compose(&(v1124_5),&(v1125_7))
            };
            drop(v1124_5);
            let v1124_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1124_2));
            drop(v1124_2);
            let v1124_10: Space = if map_kernels::has_head(&(v1124_9)) { singleton(&[]) } else { Space::new() };
            drop(v1124_9);
            let v1124_12: Space = if (&(v1124_10)).is_empty() { Space::new() } else {
              let v1126_6: Path = concat_path(&(v1123_6),&v1115_15_cursor.path()[(v1115_15_origin + 2)..(v1115_15_origin + 3)]);
              let v1126_11: Space = routine_19(c, &(v1126_6), &(*p1), &v1115_15_cursor);
              drop(v1126_6);
              map_map_kernels::compose(&(v1124_10),&(v1126_11))
            };
            drop(v1124_10);
            let v1124_13: Space = map_map_kernels::unite(&(v1124_8),&(v1124_12));
            join_wrapped_into(&mut v1123_11_write,&((v1124_13).read_zipper()),&[]);
            }
            v1115_15_cursor.ascend(1);
          }
          drop(v1123_11_write);
          drop(v1123_6);
          map_map_kernels::compose(&(v1118_10),&(v1123_11))
        };
        drop(v1118_10);
        let v1118_13: Space = map_map_kernels::unite(&(v1118_8),&(v1118_12));
        join_wrapped_into(&mut v1117_7_write,&((v1118_13).read_zipper()),&[]);
        }
        v1115_15_cursor.ascend(1);
      }
      drop(v1117_7_write);
      map_map_kernels::compose(&(v1116_5),&(v1117_7))
    };
    drop(v1116_5);
    let v1116_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1116_2));
    drop(v1116_2);
    let v1116_10: Space = if map_kernels::has_head(&(v1116_9)) { singleton(&[]) } else { Space::new() };
    drop(v1116_9);
    let v1116_11: Space = map_view_kernels::compose(&(v1116_10),&v1115_15_cursor);
    drop(v1116_10);
    let v1127_6: Path = concat_path(&(*p0),&v1115_15_cursor.path()[v1115_15_origin..(v1115_15_origin + 1)]);
    let v1116_12: Space = map_kernels::wrap(&(v1116_11),&(v1127_6));
    drop(v1116_11);
    let v1116_13: Space = map_kernels::wrap(&(v1116_12),&(*p1));
    drop(v1116_12);
    let v1116_14: Space = map_map_kernels::unite(&(v1116_8),&(v1116_13));
    drop(v1116_13);
    join_wrapped_into(&mut v1115_15_write,&((v1116_14).read_zipper()),&[]);
    }
    v1115_15_cursor.ascend(1);
  }
  drop(v1115_15_cursor);
  drop(v1115_15_write);
  (v1115_15).clone()
}

fn routine_60(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v1128_4 = Space::new();
  let mut v1128_4_write = v1128_4.write_zipper();
  let mut v1128_4_cursor = (*s0).read_zipper();
  let v1128_4_origin = v1128_4_cursor.path().len();
  for v1128_4_byte in v1128_4_cursor.child_mask().iter() {
    v1128_4_cursor.descend_to_existing_byte(v1128_4_byte);
    {
    let v1129_2: Space = Space::new();
    join_wrapped_into(&mut v1128_4_write,&((v1129_2).read_zipper()),&[]);
    }
    v1128_4_cursor.ascend(1);
  }
  drop(v1128_4_cursor);
  drop(v1128_4_write);
  (v1128_4).clone()
}

fn routine_61(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v1130_17 = Space::new();
  let mut v1130_17_write = v1130_17.write_zipper();
  let mut v1130_17_cursor = (*s0).read_zipper();
  let v1130_17_origin = v1130_17_cursor.path().len();
  for v1130_17_byte in v1130_17_cursor.child_mask().iter() {
    v1130_17_cursor.descend_to_existing_byte(v1130_17_byte);
    {
    let v1131_2: Space = singleton(&v1130_17_cursor.path()[v1130_17_origin..(v1130_17_origin + 1)]);
    let v1131_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1131_2));
    drop(v1131_2);
    let v1131_4: Space = if map_kernels::has_head(&(v1131_3)) { singleton(&[]) } else { Space::new() };
    drop(v1131_3);
    let v1131_7: Space = if (&(v1131_4)).is_empty() { Space::new() } else {
      let mut v1132_6 = Space::new();
      let mut v1132_6_write = v1132_6.write_zipper();
      let mut v1132_6_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v1130_17_cursor.path()[v1130_17_origin..(v1130_17_origin + 1)]);
      let v1132_6_origin = v1132_6_cursor.path().len();
      for v1132_6_byte in v1132_6_cursor.child_mask().iter() {
        v1132_6_cursor.descend_to_existing_byte(v1132_6_byte);
        {
        let v1133_2: Space = singleton(&v1132_6_cursor.path()[v1132_6_origin..(v1132_6_origin + 1)]);
        let v1133_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1133_2));
        let v1133_4: Space = if map_kernels::has_head(&(v1133_3)) { singleton(&[]) } else { Space::new() };
        drop(v1133_3);
        let v1133_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1133_4));
        drop(v1133_4);
        let v1133_7: Space = if (&(v1133_5)).is_empty() { Space::new() } else {
          let mut v1134_6 = Space::new();
          let mut v1134_6_write = v1134_6.write_zipper();
          for v1134_6_byte in v1132_6_cursor.child_mask().iter() {
            v1132_6_cursor.descend_to_existing_byte(v1134_6_byte);
            {
            let v1135_2: Space = singleton(&v1132_6_cursor.path()[(v1132_6_origin + 1)..(v1132_6_origin + 2)]);
            let v1135_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1135_2));
            let v1135_4: Space = if map_kernels::has_head(&(v1135_3)) { singleton(&[]) } else { Space::new() };
            drop(v1135_3);
            let v1135_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1135_4));
            drop(v1135_4);
            let v1135_8: Space = if (&(v1135_5)).is_empty() { Space::new() } else {
              let v1136_7: Space = routine_17(c, &v1132_6_cursor.path()[v1132_6_origin..(v1132_6_origin + 2)], &(*p1), &v1132_6_cursor);
              map_map_kernels::compose(&(v1135_5),&(v1136_7))
            };
            drop(v1135_5);
            let v1135_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1135_2));
            drop(v1135_2);
            let v1135_10: Space = if map_kernels::has_head(&(v1135_9)) { singleton(&[]) } else { Space::new() };
            drop(v1135_9);
            let v1135_12: Space = if (&(v1135_10)).is_empty() { Space::new() } else {
              let v1137_11: Space = routine_18(c, &v1132_6_cursor.path()[v1132_6_origin..(v1132_6_origin + 2)], &(*p1), &v1132_6_cursor);
              map_map_kernels::compose(&(v1135_10),&(v1137_11))
            };
            drop(v1135_10);
            let v1135_13: Space = map_map_kernels::unite(&(v1135_8),&(v1135_12));
            join_wrapped_into(&mut v1134_6_write,&((v1135_13).read_zipper()),&[]);
            }
            v1132_6_cursor.ascend(1);
          }
          drop(v1134_6_write);
          map_map_kernels::compose(&(v1133_5),&(v1134_6))
        };
        drop(v1133_5);
        let v1133_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1133_2));
        drop(v1133_2);
        let v1133_9: Space = if map_kernels::has_head(&(v1133_8)) { singleton(&[]) } else { Space::new() };
        drop(v1133_8);
        let v1133_11: Space = if (&(v1133_9)).is_empty() { Space::new() } else {
          let mut v1138_10 = Space::new();
          let mut v1138_10_write = v1138_10.write_zipper();
          for v1138_10_byte in v1132_6_cursor.child_mask().iter() {
            v1132_6_cursor.descend_to_existing_byte(v1138_10_byte);
            {
            let v1139_2: Space = singleton(&v1132_6_cursor.path()[(v1132_6_origin + 1)..(v1132_6_origin + 2)]);
            let v1139_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1139_2));
            let v1139_4: Space = if map_kernels::has_head(&(v1139_3)) { singleton(&[]) } else { Space::new() };
            drop(v1139_3);
            let v1139_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1139_4));
            drop(v1139_4);
            let v1139_8: Space = if (&(v1139_5)).is_empty() { Space::new() } else {
              let v1140_7: Space = routine_17(c, &v1132_6_cursor.path()[v1132_6_origin..(v1132_6_origin + 2)], &(*p1), &v1132_6_cursor);
              map_map_kernels::compose(&(v1139_5),&(v1140_7))
            };
            drop(v1139_5);
            let v1139_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1139_2));
            drop(v1139_2);
            let v1139_10: Space = if map_kernels::has_head(&(v1139_9)) { singleton(&[]) } else { Space::new() };
            drop(v1139_9);
            let v1139_12: Space = if (&(v1139_10)).is_empty() { Space::new() } else {
              let v1141_11: Space = routine_19(c, &v1132_6_cursor.path()[v1132_6_origin..(v1132_6_origin + 2)], &(*p1), &v1132_6_cursor);
              map_map_kernels::compose(&(v1139_10),&(v1141_11))
            };
            drop(v1139_10);
            let v1139_13: Space = map_map_kernels::unite(&(v1139_8),&(v1139_12));
            join_wrapped_into(&mut v1138_10_write,&((v1139_13).read_zipper()),&[]);
            }
            v1132_6_cursor.ascend(1);
          }
          drop(v1138_10_write);
          map_map_kernels::compose(&(v1133_9),&(v1138_10))
        };
        drop(v1133_9);
        let v1133_12: Space = map_map_kernels::unite(&(v1133_7),&(v1133_11));
        join_wrapped_into(&mut v1132_6_write,&((v1133_12).read_zipper()),&[]);
        }
        v1132_6_cursor.ascend(1);
      }
      drop(v1132_6_cursor);
      drop(v1132_6_write);
      map_map_kernels::compose(&(v1131_4),&(v1132_6))
    };
    drop(v1131_4);
    join_wrapped_into(&mut v1130_17_write,&((v1131_7).read_zipper()),&[]);
    }
    v1130_17_cursor.ascend(1);
  }
  drop(v1130_17_cursor);
  drop(v1130_17_write);
  (v1130_17).clone()
}

fn routine_62(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1142_13 = Space::new();
  let mut v1142_13_write = v1142_13.write_zipper();
  let mut v1142_13_cursor = (*s0).read_zipper();
  let v1142_13_origin = v1142_13_cursor.path().len();
  for v1142_13_byte in v1142_13_cursor.child_mask().iter() {
    v1142_13_cursor.descend_to_existing_byte(v1142_13_byte);
    {
    let v1143_2: Space = singleton(&v1142_13_cursor.path()[v1142_13_origin..(v1142_13_origin + 1)]);
    let v1143_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1143_2));
    let v1143_4: Space = if map_kernels::has_head(&(v1143_3)) { singleton(&[]) } else { Space::new() };
    drop(v1143_3);
    let v1143_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1143_4));
    drop(v1143_4);
    let v1143_8: Space = if (&(v1143_5)).is_empty() { Space::new() } else {
      let v1144_6: Path = concat_path(&(*p0),&v1142_13_cursor.path()[v1142_13_origin..(v1142_13_origin + 1)]);
      let mut v1144_7 = Space::new();
      let mut v1144_7_write = v1144_7.write_zipper();
      for v1144_7_byte in v1142_13_cursor.child_mask().iter() {
        v1142_13_cursor.descend_to_existing_byte(v1144_7_byte);
        {
        let v1145_2: Space = singleton(&v1142_13_cursor.path()[(v1142_13_origin + 1)..(v1142_13_origin + 2)]);
        let v1145_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1145_2));
        let v1145_4: Space = if map_kernels::has_head(&(v1145_3)) { singleton(&[]) } else { Space::new() };
        drop(v1145_3);
        let v1145_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1145_4));
        drop(v1145_4);
        let v1145_7: Space = if (&(v1145_5)).is_empty() { Space::new() } else {
          let mut v1146_6 = Space::new();
          let mut v1146_6_write = v1146_6.write_zipper();
          for v1146_6_byte in v1142_13_cursor.child_mask().iter() {
            v1142_13_cursor.descend_to_existing_byte(v1146_6_byte);
            {
            let v1147_2: Space = Space::new();
            join_wrapped_into(&mut v1146_6_write,&((v1147_2).read_zipper()),&[]);
            }
            v1142_13_cursor.ascend(1);
          }
          drop(v1146_6_write);
          map_map_kernels::compose(&(v1145_5),&(v1146_6))
        };
        drop(v1145_5);
        let v1145_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1145_2));
        drop(v1145_2);
        let v1145_9: Space = if map_kernels::has_head(&(v1145_8)) { singleton(&[]) } else { Space::new() };
        drop(v1145_8);
        let v1145_12: Space = if (&(v1145_9)).is_empty() { Space::new() } else {
          let v1148_10: Path = concat_path(&(v1144_6),&v1142_13_cursor.path()[(v1142_13_origin + 1)..(v1142_13_origin + 2)]);
          let mut v1148_11 = Space::new();
          let mut v1148_11_write = v1148_11.write_zipper();
          for v1148_11_byte in v1142_13_cursor.child_mask().iter() {
            v1142_13_cursor.descend_to_existing_byte(v1148_11_byte);
            {
            let v1149_2: Space = singleton(&v1142_13_cursor.path()[(v1142_13_origin + 2)..(v1142_13_origin + 3)]);
            let v1149_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1149_2));
            drop(v1149_2);
            let v1149_4: Space = if map_kernels::has_head(&(v1149_3)) { singleton(&[]) } else { Space::new() };
            drop(v1149_3);
            let v1149_7: Space = if (&(v1149_4)).is_empty() { Space::new() } else {
              let v1150_5: Path = concat_path(&(v1148_10),&v1142_13_cursor.path()[(v1142_13_origin + 2)..(v1142_13_origin + 3)]);
              let v1150_6: Space = routine_19(c, &(v1150_5), &(*p1), &v1142_13_cursor);
              drop(v1150_5);
              map_map_kernels::compose(&(v1149_4),&(v1150_6))
            };
            drop(v1149_4);
            join_wrapped_into(&mut v1148_11_write,&((v1149_7).read_zipper()),&[]);
            }
            v1142_13_cursor.ascend(1);
          }
          drop(v1148_11_write);
          drop(v1148_10);
          map_map_kernels::compose(&(v1145_9),&(v1148_11))
        };
        drop(v1145_9);
        let v1145_13: Space = map_map_kernels::unite(&(v1145_7),&(v1145_12));
        drop(v1145_7);
        join_wrapped_into(&mut v1144_7_write,&((v1145_13).read_zipper()),&[]);
        }
        v1142_13_cursor.ascend(1);
      }
      drop(v1144_7_write);
      map_map_kernels::compose(&(v1143_5),&(v1144_7))
    };
    drop(v1143_5);
    let v1143_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1143_2));
    drop(v1143_2);
    let v1143_10: Space = if map_kernels::has_head(&(v1143_9)) { singleton(&[]) } else { Space::new() };
    drop(v1143_9);
    let v1143_12: Space = if (&(v1143_10)).is_empty() { Space::new() } else {
      let v1151_6: Path = concat_path(&(*p0),&v1142_13_cursor.path()[v1142_13_origin..(v1142_13_origin + 1)]);
      let mut v1151_11 = Space::new();
      let mut v1151_11_write = v1151_11.write_zipper();
      for v1151_11_byte in v1142_13_cursor.child_mask().iter() {
        v1142_13_cursor.descend_to_existing_byte(v1151_11_byte);
        {
        let v1152_2: Space = singleton(&v1142_13_cursor.path()[(v1142_13_origin + 1)..(v1142_13_origin + 2)]);
        let v1152_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1152_2));
        let v1152_4: Space = if map_kernels::has_head(&(v1152_3)) { singleton(&[]) } else { Space::new() };
        drop(v1152_3);
        let v1152_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1152_4));
        drop(v1152_4);
        let v1152_7: Space = if (&(v1152_5)).is_empty() { Space::new() } else {
          let mut v1153_6 = Space::new();
          let mut v1153_6_write = v1153_6.write_zipper();
          for v1153_6_byte in v1142_13_cursor.child_mask().iter() {
            v1142_13_cursor.descend_to_existing_byte(v1153_6_byte);
            {
            let v1154_2: Space = Space::new();
            join_wrapped_into(&mut v1153_6_write,&((v1154_2).read_zipper()),&[]);
            }
            v1142_13_cursor.ascend(1);
          }
          drop(v1153_6_write);
          map_map_kernels::compose(&(v1152_5),&(v1153_6))
        };
        drop(v1152_5);
        let v1152_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1152_2));
        drop(v1152_2);
        let v1152_9: Space = if map_kernels::has_head(&(v1152_8)) { singleton(&[]) } else { Space::new() };
        drop(v1152_8);
        let v1152_10: Space = map_view_kernels::compose(&(v1152_9),&v1142_13_cursor);
        drop(v1152_9);
        let v1152_11: Path = concat_path(&(v1151_6),&v1142_13_cursor.path()[(v1142_13_origin + 1)..(v1142_13_origin + 2)]);
        let v1152_12: Space = map_kernels::wrap(&(v1152_10),&(v1152_11));
        drop(v1152_10);
        drop(v1152_11);
        let v1152_13: Space = map_kernels::wrap(&(v1152_12),&(*p1));
        drop(v1152_12);
        let v1152_14: Space = map_map_kernels::unite(&(v1152_7),&(v1152_13));
        drop(v1152_7);
        drop(v1152_13);
        join_wrapped_into(&mut v1151_11_write,&((v1152_14).read_zipper()),&[]);
        }
        v1142_13_cursor.ascend(1);
      }
      drop(v1151_11_write);
      drop(v1151_6);
      map_map_kernels::compose(&(v1143_10),&(v1151_11))
    };
    drop(v1143_10);
    let v1143_13: Space = map_map_kernels::unite(&(v1143_8),&(v1143_12));
    drop(v1143_12);
    join_wrapped_into(&mut v1142_13_write,&((v1143_13).read_zipper()),&[]);
    }
    v1142_13_cursor.ascend(1);
  }
  drop(v1142_13_cursor);
  drop(v1142_13_write);
  (v1142_13).clone()
}

fn routine_63(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1155_10 = Space::new();
  let mut v1155_10_write = v1155_10.write_zipper();
  let mut v1155_10_cursor = (*s0).read_zipper();
  let v1155_10_origin = v1155_10_cursor.path().len();
  for v1155_10_byte in v1155_10_cursor.child_mask().iter() {
    v1155_10_cursor.descend_to_existing_byte(v1155_10_byte);
    {
    let v1156_2: Space = singleton(&v1155_10_cursor.path()[v1155_10_origin..(v1155_10_origin + 1)]);
    let v1156_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1156_2));
    let v1156_4: Space = if map_kernels::has_head(&(v1156_3)) { singleton(&[]) } else { Space::new() };
    drop(v1156_3);
    let v1156_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1156_4));
    drop(v1156_4);
    let v1156_8: Space = if (&(v1156_5)).is_empty() { Space::new() } else {
      let v1157_6: Path = concat_path(&(*p0),&v1155_10_cursor.path()[v1155_10_origin..(v1155_10_origin + 1)]);
      let mut v1157_7 = Space::new();
      let mut v1157_7_write = v1157_7.write_zipper();
      for v1157_7_byte in v1155_10_cursor.child_mask().iter() {
        v1155_10_cursor.descend_to_existing_byte(v1157_7_byte);
        {
        let v1158_2: Space = singleton(&v1155_10_cursor.path()[(v1155_10_origin + 1)..(v1155_10_origin + 2)]);
        let v1158_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1158_2));
        let v1158_4: Space = if map_kernels::has_head(&(v1158_3)) { singleton(&[]) } else { Space::new() };
        drop(v1158_3);
        let v1158_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1158_4));
        drop(v1158_4);
        let v1158_7: Space = if (&(v1158_5)).is_empty() { Space::new() } else {
          let mut v1159_6 = Space::new();
          let mut v1159_6_write = v1159_6.write_zipper();
          for v1159_6_byte in v1155_10_cursor.child_mask().iter() {
            v1155_10_cursor.descend_to_existing_byte(v1159_6_byte);
            {
            let v1160_2: Space = Space::new();
            join_wrapped_into(&mut v1159_6_write,&((v1160_2).read_zipper()),&[]);
            }
            v1155_10_cursor.ascend(1);
          }
          drop(v1159_6_write);
          map_map_kernels::compose(&(v1158_5),&(v1159_6))
        };
        drop(v1158_5);
        let v1158_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1158_2));
        drop(v1158_2);
        let v1158_9: Space = if map_kernels::has_head(&(v1158_8)) { singleton(&[]) } else { Space::new() };
        drop(v1158_8);
        let v1158_12: Space = if (&(v1158_9)).is_empty() { Space::new() } else {
          let v1161_10: Path = concat_path(&(v1157_6),&v1155_10_cursor.path()[(v1155_10_origin + 1)..(v1155_10_origin + 2)]);
          let mut v1161_11 = Space::new();
          let mut v1161_11_write = v1161_11.write_zipper();
          for v1161_11_byte in v1155_10_cursor.child_mask().iter() {
            v1155_10_cursor.descend_to_existing_byte(v1161_11_byte);
            {
            let v1162_2: Space = singleton(&v1155_10_cursor.path()[(v1155_10_origin + 2)..(v1155_10_origin + 3)]);
            let v1162_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1162_2));
            drop(v1162_2);
            let v1162_4: Space = if map_kernels::has_head(&(v1162_3)) { singleton(&[]) } else { Space::new() };
            drop(v1162_3);
            let v1162_7: Space = if (&(v1162_4)).is_empty() { Space::new() } else {
              let v1163_5: Path = concat_path(&(v1161_10),&v1155_10_cursor.path()[(v1155_10_origin + 2)..(v1155_10_origin + 3)]);
              let v1163_6: Space = routine_19(c, &(v1163_5), &(*p1), &v1155_10_cursor);
              drop(v1163_5);
              map_map_kernels::compose(&(v1162_4),&(v1163_6))
            };
            drop(v1162_4);
            join_wrapped_into(&mut v1161_11_write,&((v1162_7).read_zipper()),&[]);
            }
            v1155_10_cursor.ascend(1);
          }
          drop(v1161_11_write);
          drop(v1161_10);
          map_map_kernels::compose(&(v1158_9),&(v1161_11))
        };
        drop(v1158_9);
        let v1158_13: Space = map_map_kernels::unite(&(v1158_7),&(v1158_12));
        drop(v1158_7);
        join_wrapped_into(&mut v1157_7_write,&((v1158_13).read_zipper()),&[]);
        }
        v1155_10_cursor.ascend(1);
      }
      drop(v1157_7_write);
      map_map_kernels::compose(&(v1156_5),&(v1157_7))
    };
    drop(v1156_5);
    let v1156_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1156_2));
    drop(v1156_2);
    let v1156_10: Space = if map_kernels::has_head(&(v1156_9)) { singleton(&[]) } else { Space::new() };
    drop(v1156_9);
    let v1156_11: Space = map_view_kernels::compose(&(v1156_10),&v1155_10_cursor);
    drop(v1156_10);
    let v1164_6: Path = concat_path(&(*p0),&v1155_10_cursor.path()[v1155_10_origin..(v1155_10_origin + 1)]);
    let v1156_12: Space = map_kernels::wrap(&(v1156_11),&(v1164_6));
    drop(v1156_11);
    let v1156_13: Space = map_kernels::wrap(&(v1156_12),&(*p1));
    drop(v1156_12);
    let v1156_14: Space = map_map_kernels::unite(&(v1156_8),&(v1156_13));
    drop(v1156_13);
    join_wrapped_into(&mut v1155_10_write,&((v1156_14).read_zipper()),&[]);
    }
    v1155_10_cursor.ascend(1);
  }
  drop(v1155_10_cursor);
  drop(v1155_10_write);
  (v1155_10).clone()
}

fn routine_64(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1165_7 = Space::new();
  let mut v1165_7_write = v1165_7.write_zipper();
  let mut v1165_7_cursor = (*s0).read_zipper();
  let v1165_7_origin = v1165_7_cursor.path().len();
  for v1165_7_byte in v1165_7_cursor.child_mask().iter() {
    v1165_7_cursor.descend_to_existing_byte(v1165_7_byte);
    {
    let v1166_2: Space = singleton(&v1165_7_cursor.path()[v1165_7_origin..(v1165_7_origin + 1)]);
    let v1166_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1166_2));
    let v1166_4: Space = if map_kernels::has_head(&(v1166_3)) { singleton(&[]) } else { Space::new() };
    drop(v1166_3);
    let v1166_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1166_4));
    drop(v1166_4);
    let v1166_7: Space = if (&(v1166_5)).is_empty() { Space::new() } else {
      let mut v1167_6 = Space::new();
      let mut v1167_6_write = v1167_6.write_zipper();
      for v1167_6_byte in v1165_7_cursor.child_mask().iter() {
        v1165_7_cursor.descend_to_existing_byte(v1167_6_byte);
        {
        let v1168_2: Space = Space::new();
        join_wrapped_into(&mut v1167_6_write,&((v1168_2).read_zipper()),&[]);
        }
        v1165_7_cursor.ascend(1);
      }
      drop(v1167_6_write);
      map_map_kernels::compose(&(v1166_5),&(v1167_6))
    };
    drop(v1166_5);
    let v1166_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1166_2));
    drop(v1166_2);
    let v1166_9: Space = if map_kernels::has_head(&(v1166_8)) { singleton(&[]) } else { Space::new() };
    drop(v1166_8);
    let v1166_12: Space = if (&(v1166_9)).is_empty() { Space::new() } else {
      let v1169_10: Path = concat_path(&(*p0),&v1165_7_cursor.path()[v1165_7_origin..(v1165_7_origin + 1)]);
      let mut v1169_11 = Space::new();
      let mut v1169_11_write = v1169_11.write_zipper();
      for v1169_11_byte in v1165_7_cursor.child_mask().iter() {
        v1165_7_cursor.descend_to_existing_byte(v1169_11_byte);
        {
        let v1170_2: Space = singleton(&v1165_7_cursor.path()[(v1165_7_origin + 1)..(v1165_7_origin + 2)]);
        let v1170_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1170_2));
        drop(v1170_2);
        let v1170_4: Space = if map_kernels::has_head(&(v1170_3)) { singleton(&[]) } else { Space::new() };
        drop(v1170_3);
        let v1170_5: Space = map_view_kernels::compose(&(v1170_4),&v1165_7_cursor);
        drop(v1170_4);
        let v1170_6: Path = concat_path(&(v1169_10),&v1165_7_cursor.path()[(v1165_7_origin + 1)..(v1165_7_origin + 2)]);
        join_wrapped_into(&mut v1169_11_write,&((v1170_5).read_zipper()),&(v1170_6));
        drop(v1170_5);
        drop(v1170_6);
        }
        v1165_7_cursor.ascend(1);
      }
      drop(v1169_11_write);
      drop(v1169_10);
      map_map_kernels::compose(&(v1166_9),&(v1169_11))
    };
    drop(v1166_9);
    let v1166_13: Space = map_kernels::wrap(&(v1166_12),&(*p1));
    drop(v1166_12);
    let v1166_14: Space = map_map_kernels::unite(&(v1166_7),&(v1166_13));
    drop(v1166_7);
    drop(v1166_13);
    join_wrapped_into(&mut v1165_7_write,&((v1166_14).read_zipper()),&[]);
    }
    v1165_7_cursor.ascend(1);
  }
  drop(v1165_7_cursor);
  drop(v1165_7_write);
  (v1165_7).clone()
}

fn routine_65(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1171_6 = Space::new();
  let mut v1171_6_write = v1171_6.write_zipper();
  let mut v1171_6_cursor = (*s0).read_zipper();
  let v1171_6_origin = v1171_6_cursor.path().len();
  for v1171_6_byte in v1171_6_cursor.child_mask().iter() {
    v1171_6_cursor.descend_to_existing_byte(v1171_6_byte);
    {
    let v1172_2: Space = singleton(&v1171_6_cursor.path()[v1171_6_origin..(v1171_6_origin + 1)]);
    let v1172_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1172_2));
    let v1172_4: Space = if map_kernels::has_head(&(v1172_3)) { singleton(&[]) } else { Space::new() };
    drop(v1172_3);
    let v1172_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1172_4));
    drop(v1172_4);
    let v1172_7: Space = if (&(v1172_5)).is_empty() { Space::new() } else {
      let mut v1173_6 = Space::new();
      let mut v1173_6_write = v1173_6.write_zipper();
      for v1173_6_byte in v1171_6_cursor.child_mask().iter() {
        v1171_6_cursor.descend_to_existing_byte(v1173_6_byte);
        {
        let v1174_2: Space = Space::new();
        join_wrapped_into(&mut v1173_6_write,&((v1174_2).read_zipper()),&[]);
        }
        v1171_6_cursor.ascend(1);
      }
      drop(v1173_6_write);
      map_map_kernels::compose(&(v1172_5),&(v1173_6))
    };
    drop(v1172_5);
    let v1172_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1172_2));
    drop(v1172_2);
    let v1172_9: Space = if map_kernels::has_head(&(v1172_8)) { singleton(&[]) } else { Space::new() };
    drop(v1172_8);
    let v1172_10: Space = map_view_kernels::compose(&(v1172_9),&v1171_6_cursor);
    drop(v1172_9);
    let v1172_11: Path = concat_path(&(*p0),&v1171_6_cursor.path()[v1171_6_origin..(v1171_6_origin + 1)]);
    let v1172_12: Space = map_kernels::wrap(&(v1172_10),&(v1172_11));
    drop(v1172_10);
    drop(v1172_11);
    let v1172_13: Space = map_kernels::wrap(&(v1172_12),&(*p1));
    drop(v1172_12);
    let v1172_14: Space = map_map_kernels::unite(&(v1172_7),&(v1172_13));
    drop(v1172_7);
    drop(v1172_13);
    join_wrapped_into(&mut v1171_6_write,&((v1172_14).read_zipper()),&[]);
    }
    v1171_6_cursor.ascend(1);
  }
  drop(v1171_6_cursor);
  drop(v1171_6_write);
  (v1171_6).clone()
}

fn routine_66(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1175_3 = Space::new();
  let mut v1175_3_write = v1175_3.write_zipper();
  let mut v1175_3_cursor = (*s0).read_zipper();
  let v1175_3_origin = v1175_3_cursor.path().len();
  for v1175_3_byte in v1175_3_cursor.child_mask().iter() {
    v1175_3_cursor.descend_to_existing_byte(v1175_3_byte);
    {
    let v1176_2: Space = Space::new();
    join_wrapped_into(&mut v1175_3_write,&((v1176_2).read_zipper()),&[]);
    }
    v1175_3_cursor.ascend(1);
  }
  drop(v1175_3_cursor);
  drop(v1175_3_write);
  (v1175_3).clone()
}

fn routine_67(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1177_4 = Space::new();
  let mut v1177_4_write = v1177_4.write_zipper();
  let mut v1177_4_cursor = (*s0).read_zipper();
  let v1177_4_origin = v1177_4_cursor.path().len();
  for v1177_4_byte in v1177_4_cursor.child_mask().iter() {
    v1177_4_cursor.descend_to_existing_byte(v1177_4_byte);
    {
    let v1178_2: Space = singleton(&v1177_4_cursor.path()[v1177_4_origin..(v1177_4_origin + 1)]);
    let v1178_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1178_2));
    drop(v1178_2);
    let v1178_4: Space = if map_kernels::has_head(&(v1178_3)) { singleton(&[]) } else { Space::new() };
    drop(v1178_3);
    let v1178_5: Space = map_view_kernels::compose(&(v1178_4),&v1177_4_cursor);
    drop(v1178_4);
    let v1178_6: Path = concat_path(&(*p0),&v1177_4_cursor.path()[v1177_4_origin..(v1177_4_origin + 1)]);
    join_wrapped_into(&mut v1177_4_write,&((v1178_5).read_zipper()),&(v1178_6));
    drop(v1178_5);
    drop(v1178_6);
    }
    v1177_4_cursor.ascend(1);
  }
  drop(v1177_4_cursor);
  drop(v1177_4_write);
  let v1177_5: Space = map_kernels::wrap(&(v1177_4),&(*p1));
  drop(v1177_4);
  (v1177_5).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
