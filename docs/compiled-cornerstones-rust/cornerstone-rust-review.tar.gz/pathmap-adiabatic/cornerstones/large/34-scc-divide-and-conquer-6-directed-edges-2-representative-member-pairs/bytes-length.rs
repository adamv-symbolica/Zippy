#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 3 97 1 98 3 98 1 97 3 98 1 99 3 99 1 100 3 100 1 99 3 101 1 102"));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("255 2 1 0 2 2 1 2 3 2 2 4 3 2 5 4 2 6 5 2 7 6 2 8 7 2 9 8 2 10 9 2 11 10 2 12 11 2 13 12 2 14 13 2 15 14 2 16 15 2 17 16 2 18 17 2 19 18 2 20 19 2 21 20 2 22 21 2 23 22 2 24 23 2 25 24 2 26 25 2 27 26 2 28 27 2 29 28 2 30 29 2 31 30 2 32 31 2 33 32 2 34 33 2 35 34 2 36 35 2 37 36 2 38 37 2 39 38 2 40 39 2 41 40 2 42 41 2 43 42 2 44 43 2 45 44 2 46 45 2 47 46 2 48 47 2 49 48 2 50 49 2 51 50 2 52 51 2 53 52 2 54 53 2 55 54 2 56 55 2 57 56 2 58 57 2 59 58 2 60 59 2 61 60 2 62 61 2 63 62 2 64 63 2 65 64 2 66 65 2 67 66 2 68 67 2 69 68 2 70 69 2 71 70 2 72 71 2 73 72 2 74 73 2 75 74 2 76 75 2 77 76 2 78 77 2 79 78 2 80 79 2 81 80 2 82 81 2 83 82 2 84 83 2 85 84 2 86 85 2 87 86 2 88 87 2 89 88 2 90 89 2 91 90 2 92 91 2 93 92 2 94 93 2 95 94 2 96 95 2 97 96 2 98 97 2 99 98 2 100 99 2 101 100 2 102 101 2 103 102 2 104 103 2 105 104 2 106 105 2 107 106 2 108 107 2 109 108 2 110 109 2 111 110 2 112 111 2 113 112 2 114 113 2 115 114 2 116 115 2 117 116 2 118 117 2 119 118 2 120 119 2 121 120 2 122 121 2 123 122 2 124 123 2 125 124 2 126 125 2 127 126 2 128 127 2 129 128 2 130 129 2 131 130 2 132 131 2 133 132 2 134 133 2 135 134 2 136 135 2 137 136 2 138 137 2 139 138 2 140 139 2 141 140 2 142 141 2 143 142 2 144 143 2 145 144 2 146 145 2 147 146 2 148 147 2 149 148 2 150 149 2 151 150 2 152 151 2 153 152 2 154 153 2 155 154 2 156 155 2 157 156 2 158 157 2 159 158 2 160 159 2 161 160 2 162 161 2 163 162 2 164 163 2 165 164 2 166 165 2 167 166 2 168 167 2 169 168 2 170 169 2 171 170 2 172 171 2 173 172 2 174 173 2 175 174 2 176 175 2 177 176 2 178 177 2 179 178 2 180 179 2 181 180 2 182 181 2 183 182 2 184 183 2 185 184 2 186 185 2 187 186 2 188 187 2 189 188 2 190 189 2 191 190 2 192 191 2 193 192 2 194 193 2 195 194 2 196 195 2 197 196 2 198 197 2 199 198 2 200 199 2 201 200 2 202 201 2 203 202 2 204 203 2 205 204 2 206 205 2 207 206 2 208 207 2 209 208 2 210 209 2 211 210 2 212 211 2 213 212 2 214 213 2 215 214 2 216 215 2 217 216 2 218 217 2 219 218 2 220 219 2 221 220 2 222 221 2 223 222 2 224 223 2 225 224 2 226 225 2 227 226 2 228 227 2 229 228 2 230 229 2 231 230 2 232 231 2 233 232 2 234 233 2 235 234 2 236 235 2 237 236 2 238 237 2 239 238 2 240 239 2 241 240 2 242 241 2 243 242 2 244 243 2 245 244 2 246 245 2 247 246 2 248 247 2 249 248 2 250 249 2 251 250 2 252 251 2 253 252 2 254 253 2 255 254"));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 4 1 97 1 98 4 1 98 1 97 4 1 98 1 99 4 1 99 1 100 4 1 100 1 99 4 1 101 1 102"));
fn routine_0(c: &mut Context) -> Space {
  let v0_6: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let mut v1_5 = Space::new();
    let mut v1_5_write = v1_5.write_zipper();
    let v1_5_arg_0: &[u8] = &(*CONSTANT_1);
    let v1_5_arg_1: &[u8] = &(*CONSTANT_2);
    let v1_5_arg_3: &Space = &(*CONSTANT_4);
    let mut v1_5_cursor = (*CONSTANT_3).read_zipper();
    let v1_5_origin = v1_5_cursor.path().len();
    let mut v1_5_more = v1_5_cursor.is_val() || next_value_within(&mut v1_5_cursor,v1_5_origin);
    while v1_5_more {
      {
      let v1_5_depth = v1_5_cursor.path().len();
      let mut v2_4_cursor = (*v1_5_arg_3).read_zipper();
      let v2_4_origin = v2_4_cursor.path().len();
      for v2_4_byte in v2_4_cursor.child_mask().iter() {
        v2_4_cursor.descend_to_existing_byte(v2_4_byte);
        {
        let v3_2: Path = concat_path(&(*v1_5_arg_1),&v2_4_cursor.path()[v2_4_origin..(v2_4_origin + 1)]);
        let v3_3: Space = routine_1(c, &(v3_2), &v1_5_cursor.path()[v1_5_origin..v1_5_depth], &v2_4_cursor);
        drop(v3_2);
        join_wrapped_into(&mut v1_5_write,&((v3_3).read_zipper()),&[]);
        }
        v2_4_cursor.ascend(1);
      }
      drop(v2_4_cursor);
      }
      v1_5_more = next_value_within(&mut v1_5_cursor,v1_5_origin);
    }
    drop(v1_5_cursor);
    drop(v1_5_write);
    compose(&(*CONSTANT_0),&(v1_5))
  };
  let v0_11: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let mut v4_10 = Space::new();
    let mut v4_10_write = v4_10.write_zipper();
    let v4_10_arg_0: &[u8] = &(*CONSTANT_1);
    let v4_10_arg_1: &[u8] = &(*CONSTANT_2);
    let v4_10_arg_3: &Space = &(*CONSTANT_4);
    let mut v4_10_cursor = (*CONSTANT_3).read_zipper();
    let v4_10_origin = v4_10_cursor.path().len();
    let mut v4_10_more = v4_10_cursor.is_val() || next_value_within(&mut v4_10_cursor,v4_10_origin);
    while v4_10_more {
      {
      let v4_10_depth = v4_10_cursor.path().len();
      let mut v5_4_cursor = (*v4_10_arg_3).read_zipper();
      let v5_4_origin = v5_4_cursor.path().len();
      for v5_4_byte in v5_4_cursor.child_mask().iter() {
        v5_4_cursor.descend_to_existing_byte(v5_4_byte);
        {
        let v6_2: Path = concat_path(&(*v4_10_arg_1),&v5_4_cursor.path()[v5_4_origin..(v5_4_origin + 1)]);
        let v6_3: Space = routine_2(c, &(v6_2), &v4_10_cursor.path()[v4_10_origin..v4_10_depth], &v5_4_cursor);
        drop(v6_2);
        join_wrapped_into(&mut v4_10_write,&((v6_3).read_zipper()),&[]);
        }
        v5_4_cursor.ascend(1);
      }
      drop(v5_4_cursor);
      }
      v4_10_more = next_value_within(&mut v4_10_cursor,v4_10_origin);
    }
    drop(v4_10_cursor);
    drop(v4_10_write);
    compose(&(*CONSTANT_0),&(v4_10))
  };
  let mut v0_16 = Space::new();
  let mut v0_16_write = v0_16.write_zipper();
  let mut v0_16_cursor = (v0_11).read_zipper();
  let v0_16_origin = v0_16_cursor.path().len();
  for v0_16_byte in v0_16_cursor.child_mask().iter() {
    v0_16_cursor.descend_to_existing_byte(v0_16_byte);
    {
    let v7_2: Space = singleton(&v0_16_cursor.path()[v0_16_origin..(v0_16_origin + 1)]);
    let v7_3: Space = intersect(&(*CONSTANT_3),&(v7_2));
    let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
    drop(v7_3);
    let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
    drop(v7_4);
    let v7_8: Space = if (&(v7_5)).is_empty() { Space::new() } else {
      let mut v8_7 = Space::new();
      let mut v8_7_write = v8_7.write_zipper();
      let v8_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v8_7_arg_1: &[u8] = &v0_16_cursor.path()[v0_16_origin..(v0_16_origin + 1)];
      let v8_7_arg_3: &Space = &(&v0_16_cursor).make_map();
      let mut v8_7_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&v0_16_cursor.path()[v0_16_origin..(v0_16_origin + 1)]);
      let v8_7_origin = v8_7_cursor.path().len();
      let mut v8_7_more = v8_7_cursor.is_val() || next_value_within(&mut v8_7_cursor,v8_7_origin);
      while v8_7_more {
        {
        let v8_7_depth = v8_7_cursor.path().len();
        let mut v9_4_cursor = (*v8_7_arg_3).read_zipper();
        let v9_4_origin = v9_4_cursor.path().len();
        for v9_4_byte in v9_4_cursor.child_mask().iter() {
          v9_4_cursor.descend_to_existing_byte(v9_4_byte);
          {
          let v10_2: Path = concat_path(&(*v8_7_arg_1),&v9_4_cursor.path()[v9_4_origin..(v9_4_origin + 1)]);
          let v10_3: Space = routine_3(c, &(v10_2), &v8_7_cursor.path()[v8_7_origin..v8_7_depth], &v9_4_cursor);
          drop(v10_2);
          join_wrapped_into(&mut v8_7_write,&((v10_3).read_zipper()),&[]);
          }
          v9_4_cursor.ascend(1);
        }
        drop(v9_4_cursor);
        }
        v8_7_more = next_value_within(&mut v8_7_cursor,v8_7_origin);
      }
      drop(v8_7_cursor);
      drop(v8_7_write);
      compose(&(v7_5),&(v8_7))
    };
    drop(v7_5);
    let v7_9: Space = intersect(&(*CONSTANT_3),&(v7_2));
    let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
    drop(v7_9);
    let v7_11: Space = compose(&(v7_10),&(v7_2));
    drop(v7_2);
    drop(v7_10);
    let v7_12: Space = unite(&(v7_8),&(v7_11));
    drop(v7_11);
    join_wrapped_into(&mut v0_16_write,&((v7_12).read_zipper()),&[]);
    }
    v0_16_cursor.ascend(1);
  }
  drop(v0_16_cursor);
  drop(v0_16_write);
  let v0_17: Space = unite(&(v0_6),&(v0_16));
  let v0_18: Space = routine_4(c, &((v0_17).read_zipper()));
  let mut v0_33 = Space::new();
  let mut v0_33_write = v0_33.write_zipper();
  let mut v0_33_cursor = (v0_18).read_zipper();
  let v0_33_origin = v0_33_cursor.path().len();
  for v0_33_byte in v0_33_cursor.child_mask().iter() {
    v0_33_cursor.descend_to_existing_byte(v0_33_byte);
    {
    let v11_3: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
      let mut v12_2 = Space::new();
      let mut v12_2_write = v12_2.write_zipper();
      let v12_2_arg_0: &[u8] = &(*CONSTANT_1);
      let v12_2_arg_1: &[u8] = &(*CONSTANT_2);
      let v12_2_arg_3: &Space = &(*CONSTANT_4);
      let mut v12_2_cursor = (*CONSTANT_3).read_zipper();
      let v12_2_origin = v12_2_cursor.path().len();
      let mut v12_2_more = v12_2_cursor.is_val() || next_value_within(&mut v12_2_cursor,v12_2_origin);
      while v12_2_more {
        {
        let v12_2_depth = v12_2_cursor.path().len();
        let mut v13_4_cursor = (*v12_2_arg_3).read_zipper();
        let v13_4_origin = v13_4_cursor.path().len();
        for v13_4_byte in v13_4_cursor.child_mask().iter() {
          v13_4_cursor.descend_to_existing_byte(v13_4_byte);
          {
          let v14_2: Path = concat_path(&(*v12_2_arg_1),&v13_4_cursor.path()[v13_4_origin..(v13_4_origin + 1)]);
          let v14_3: Space = routine_5(c, &(v14_2), &v12_2_cursor.path()[v12_2_origin..v12_2_depth], &v13_4_cursor);
          drop(v14_2);
          join_wrapped_into(&mut v12_2_write,&((v14_3).read_zipper()),&[]);
          }
          v13_4_cursor.ascend(1);
        }
        drop(v13_4_cursor);
        }
        v12_2_more = next_value_within(&mut v12_2_cursor,v12_2_origin);
      }
      drop(v12_2_cursor);
      drop(v12_2_write);
      compose(&(*CONSTANT_0),&(v12_2))
    };
    let v11_5: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
      let mut v15_4 = Space::new();
      let mut v15_4_write = v15_4.write_zipper();
      let v15_4_arg_0: &[u8] = &(*CONSTANT_1);
      let v15_4_arg_1: &[u8] = &(*CONSTANT_2);
      let v15_4_arg_3: &Space = &(*CONSTANT_4);
      let mut v15_4_cursor = (*CONSTANT_3).read_zipper();
      let v15_4_origin = v15_4_cursor.path().len();
      let mut v15_4_more = v15_4_cursor.is_val() || next_value_within(&mut v15_4_cursor,v15_4_origin);
      while v15_4_more {
        {
        let v15_4_depth = v15_4_cursor.path().len();
        let mut v16_4_cursor = (*v15_4_arg_3).read_zipper();
        let v16_4_origin = v16_4_cursor.path().len();
        for v16_4_byte in v16_4_cursor.child_mask().iter() {
          v16_4_cursor.descend_to_existing_byte(v16_4_byte);
          {
          let v17_2: Path = concat_path(&(*v15_4_arg_1),&v16_4_cursor.path()[v16_4_origin..(v16_4_origin + 1)]);
          let v17_3: Space = routine_1(c, &(v17_2), &v15_4_cursor.path()[v15_4_origin..v15_4_depth], &v16_4_cursor);
          drop(v17_2);
          join_wrapped_into(&mut v15_4_write,&((v17_3).read_zipper()),&[]);
          }
          v16_4_cursor.ascend(1);
        }
        drop(v16_4_cursor);
        }
        v15_4_more = next_value_within(&mut v15_4_cursor,v15_4_origin);
      }
      drop(v15_4_cursor);
      drop(v15_4_write);
      compose(&(*CONSTANT_0),&(v15_4))
    };
    let v11_7: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
      let mut v18_6 = Space::new();
      let mut v18_6_write = v18_6.write_zipper();
      let v18_6_arg_0: &[u8] = &(*CONSTANT_1);
      let v18_6_arg_1: &[u8] = &(*CONSTANT_2);
      let v18_6_arg_3: &Space = &(*CONSTANT_4);
      let mut v18_6_cursor = (*CONSTANT_3).read_zipper();
      let v18_6_origin = v18_6_cursor.path().len();
      let mut v18_6_more = v18_6_cursor.is_val() || next_value_within(&mut v18_6_cursor,v18_6_origin);
      while v18_6_more {
        {
        let v18_6_depth = v18_6_cursor.path().len();
        let mut v19_4_cursor = (*v18_6_arg_3).read_zipper();
        let v19_4_origin = v19_4_cursor.path().len();
        for v19_4_byte in v19_4_cursor.child_mask().iter() {
          v19_4_cursor.descend_to_existing_byte(v19_4_byte);
          {
          let v20_2: Path = concat_path(&(*v18_6_arg_1),&v19_4_cursor.path()[v19_4_origin..(v19_4_origin + 1)]);
          let v20_3: Space = routine_2(c, &(v20_2), &v18_6_cursor.path()[v18_6_origin..v18_6_depth], &v19_4_cursor);
          drop(v20_2);
          join_wrapped_into(&mut v18_6_write,&((v20_3).read_zipper()),&[]);
          }
          v19_4_cursor.ascend(1);
        }
        drop(v19_4_cursor);
        }
        v18_6_more = next_value_within(&mut v18_6_cursor,v18_6_origin);
      }
      drop(v18_6_cursor);
      drop(v18_6_write);
      compose(&(*CONSTANT_0),&(v18_6))
    };
    let mut v11_8 = Space::new();
    let mut v11_8_write = v11_8.write_zipper();
    let mut v11_8_cursor = (v11_7).read_zipper();
    let v11_8_origin = v11_8_cursor.path().len();
    for v11_8_byte in v11_8_cursor.child_mask().iter() {
      v11_8_cursor.descend_to_existing_byte(v11_8_byte);
      {
      let v21_2: Space = singleton(&v11_8_cursor.path()[v11_8_origin..(v11_8_origin + 1)]);
      let v21_3: Space = intersect(&(*CONSTANT_3),&(v21_2));
      let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
      drop(v21_3);
      let v21_5: Space = subtract(&(*CONSTANT_0),&(v21_4));
      drop(v21_4);
      let v21_8: Space = if (&(v21_5)).is_empty() { Space::new() } else {
        let mut v22_7 = Space::new();
        let mut v22_7_write = v22_7.write_zipper();
        let v22_7_arg_0: &[u8] = &(*CONSTANT_1);
        let v22_7_arg_1: &[u8] = &v11_8_cursor.path()[v11_8_origin..(v11_8_origin + 1)];
        let v22_7_arg_3: &Space = &(&v11_8_cursor).make_map();
        let mut v22_7_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&v11_8_cursor.path()[v11_8_origin..(v11_8_origin + 1)]);
        let v22_7_origin = v22_7_cursor.path().len();
        let mut v22_7_more = v22_7_cursor.is_val() || next_value_within(&mut v22_7_cursor,v22_7_origin);
        while v22_7_more {
          {
          let v22_7_depth = v22_7_cursor.path().len();
          let mut v23_4_cursor = (*v22_7_arg_3).read_zipper();
          let v23_4_origin = v23_4_cursor.path().len();
          for v23_4_byte in v23_4_cursor.child_mask().iter() {
            v23_4_cursor.descend_to_existing_byte(v23_4_byte);
            {
            let v24_2: Path = concat_path(&(*v22_7_arg_1),&v23_4_cursor.path()[v23_4_origin..(v23_4_origin + 1)]);
            let v24_3: Space = routine_3(c, &(v24_2), &v22_7_cursor.path()[v22_7_origin..v22_7_depth], &v23_4_cursor);
            drop(v24_2);
            join_wrapped_into(&mut v22_7_write,&((v24_3).read_zipper()),&[]);
            }
            v23_4_cursor.ascend(1);
          }
          drop(v23_4_cursor);
          }
          v22_7_more = next_value_within(&mut v22_7_cursor,v22_7_origin);
        }
        drop(v22_7_cursor);
        drop(v22_7_write);
        compose(&(v21_5),&(v22_7))
      };
      drop(v21_5);
      let v21_9: Space = intersect(&(*CONSTANT_3),&(v21_2));
      let v21_10: Space = if has_head(&(v21_9)) { singleton(&[]) } else { Space::new() };
      drop(v21_9);
      let v21_11: Space = compose(&(v21_10),&(v21_2));
      drop(v21_2);
      drop(v21_10);
      let v21_12: Space = unite(&(v21_8),&(v21_11));
      drop(v21_11);
      join_wrapped_into(&mut v11_8_write,&((v21_12).read_zipper()),&[]);
      }
      v11_8_cursor.ascend(1);
    }
    drop(v11_8_cursor);
    drop(v11_8_write);
    let v11_9: Space = unite(&(v11_5),&(v11_8));
    let v11_10: Space = routine_6(c, &v0_33_cursor.path()[v0_33_origin..(v0_33_origin + 1)], &v0_33_cursor.path()[v0_33_origin..(v0_33_origin + 1)], &v0_33_cursor, &((v11_3).read_zipper()), &((*CONSTANT_6).read_zipper()), &((v11_9).read_zipper()));
    join_wrapped_into(&mut v0_33_write,&((v11_10).read_zipper()),&[]);
    }
    v0_33_cursor.ascend(1);
  }
  drop(v0_33_cursor);
  drop(v0_33_write);
  (v0_33).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v25_5: Space = singleton(&(*p1));
  let v25_6: Space = intersect(&(*CONSTANT_3),&(v25_5));
  let v25_7: Space = if has_head(&(v25_6)) { singleton(&[]) } else { Space::new() };
  drop(v25_6);
  let v25_8: Space = subtract(&(*CONSTANT_0),&(v25_7));
  drop(v25_7);
  let v25_19: Space = if (&(v25_8)).is_empty() { Space::new() } else {
    let v26_11: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v26_14: Space = if (&(v26_11)).is_empty() { Space::new() } else {
      let v27_13: Space = routine_7(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v26_11),&(v27_13))
    };
    drop(v26_11);
    let mut v26_17 = Space::new();
    let mut v26_17_write = v26_17.write_zipper();
    let mut v26_17_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v26_17_origin = v26_17_cursor.path().len();
    for v26_17_byte in v26_17_cursor.child_mask().iter() {
      v26_17_cursor.descend_to_existing_byte(v26_17_byte);
      {
      let v28_2_arg_0: &[u8] = &v26_17_cursor.path()[v26_17_origin..(v26_17_origin + 1)];
      let v28_2_arg_1: &[u8] = &(*p0);
      let v28_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v28_2_more = v26_17_cursor.is_val() || next_value_within(&mut v26_17_cursor,(v26_17_origin + 1));
      while v28_2_more {
        {
        let v28_2_depth = v26_17_cursor.path().len();
        let mut v29_4_cursor = (*v28_2_arg_3).read_zipper();
        let v29_4_origin = v29_4_cursor.path().len();
        for v29_4_byte in v29_4_cursor.child_mask().iter() {
          v29_4_cursor.descend_to_existing_byte(v29_4_byte);
          {
          let v30_2: Path = concat_path(&(*v28_2_arg_1),&v29_4_cursor.path()[v29_4_origin..(v29_4_origin + 1)]);
          let v30_3: Space = routine_1(c, &(v30_2), &v26_17_cursor.path()[v26_17_origin..v28_2_depth], &v29_4_cursor);
          drop(v30_2);
          join_wrapped_into(&mut v26_17_write,&((v30_3).read_zipper()),&[]);
          }
          v29_4_cursor.ascend(1);
        }
        drop(v29_4_cursor);
        }
        v28_2_more = next_value_within(&mut v26_17_cursor,(v26_17_origin + 1));
      }
      }
      v26_17_cursor.ascend(1);
    }
    drop(v26_17_cursor);
    drop(v26_17_write);
    let v26_18: Space = unite(&(v26_14),&(v26_17));
    compose(&(v25_8),&(v26_18))
  };
  drop(v25_8);
  let v25_21: Space = intersect(&(*CONSTANT_3),&(v25_5));
  drop(v25_5);
  let v25_22: Space = if has_head(&(v25_21)) { singleton(&[]) } else { Space::new() };
  drop(v25_21);
  let v25_24: Space = if (&(v25_22)).is_empty() { Space::new() } else {
    let v31_23: Space = singleton(&(*p0));
    compose(&(v25_22),&(v31_23))
  };
  drop(v25_22);
  let v25_25: Space = unite(&(v25_19),&(v25_24));
  drop(v25_24);
  (v25_25).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v32_5: Space = singleton(&(*p1));
  let v32_6: Space = intersect(&(*CONSTANT_3),&(v32_5));
  let v32_7: Space = if has_head(&(v32_6)) { singleton(&[]) } else { Space::new() };
  drop(v32_6);
  let v32_8: Space = subtract(&(*CONSTANT_0),&(v32_7));
  drop(v32_7);
  let v32_19: Space = if (&(v32_8)).is_empty() { Space::new() } else {
    let v33_11: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v33_14: Space = if (&(v33_11)).is_empty() { Space::new() } else {
      let v34_13: Space = routine_8(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v33_11),&(v34_13))
    };
    drop(v33_11);
    let mut v33_17 = Space::new();
    let mut v33_17_write = v33_17.write_zipper();
    let mut v33_17_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v33_17_origin = v33_17_cursor.path().len();
    for v33_17_byte in v33_17_cursor.child_mask().iter() {
      v33_17_cursor.descend_to_existing_byte(v33_17_byte);
      {
      let v35_2_arg_0: &[u8] = &v33_17_cursor.path()[v33_17_origin..(v33_17_origin + 1)];
      let v35_2_arg_1: &[u8] = &(*p0);
      let v35_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v35_2_more = v33_17_cursor.is_val() || next_value_within(&mut v33_17_cursor,(v33_17_origin + 1));
      while v35_2_more {
        {
        let v35_2_depth = v33_17_cursor.path().len();
        let mut v36_4_cursor = (*v35_2_arg_3).read_zipper();
        let v36_4_origin = v36_4_cursor.path().len();
        for v36_4_byte in v36_4_cursor.child_mask().iter() {
          v36_4_cursor.descend_to_existing_byte(v36_4_byte);
          {
          let v37_2: Path = concat_path(&(*v35_2_arg_1),&v36_4_cursor.path()[v36_4_origin..(v36_4_origin + 1)]);
          let v37_3: Space = routine_2(c, &(v37_2), &v33_17_cursor.path()[v33_17_origin..v35_2_depth], &v36_4_cursor);
          drop(v37_2);
          join_wrapped_into(&mut v33_17_write,&((v37_3).read_zipper()),&[]);
          }
          v36_4_cursor.ascend(1);
        }
        drop(v36_4_cursor);
        }
        v35_2_more = next_value_within(&mut v33_17_cursor,(v33_17_origin + 1));
      }
      }
      v33_17_cursor.ascend(1);
    }
    drop(v33_17_cursor);
    drop(v33_17_write);
    let v33_18: Space = unite(&(v33_14),&(v33_17));
    compose(&(v32_8),&(v33_18))
  };
  drop(v32_8);
  let v32_21: Space = intersect(&(*CONSTANT_3),&(v32_5));
  drop(v32_5);
  let v32_22: Space = if has_head(&(v32_21)) { singleton(&[]) } else { Space::new() };
  drop(v32_21);
  let v32_24: Space = if (&(v32_22)).is_empty() { Space::new() } else {
    let mut v38_23 = Space::new();
    let mut v38_23_write = v38_23.write_zipper();
    let mut v38_23_cursor = (*s0).read_zipper();
    let v38_23_origin = v38_23_cursor.path().len();
    for v38_23_byte in v38_23_cursor.child_mask().iter() {
      v38_23_cursor.descend_to_existing_byte(v38_23_byte);
      {
      let v39_2: Space = routine_9(c, &v38_23_cursor.path()[v38_23_origin..(v38_23_origin + 1)], &v38_23_cursor.path()[v38_23_origin..(v38_23_origin + 1)], &(*p0), &v38_23_cursor);
      join_wrapped_into(&mut v38_23_write,&((v39_2).read_zipper()),&[]);
      }
      v38_23_cursor.ascend(1);
    }
    drop(v38_23_cursor);
    drop(v38_23_write);
    compose(&(v32_22),&(v38_23))
  };
  drop(v32_22);
  let v32_25: Space = unite(&(v32_19),&(v32_24));
  (v32_25).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v40_5: Space = singleton(&(*p1));
  let v40_6: Space = intersect(&(*CONSTANT_3),&(v40_5));
  let v40_7: Space = if has_head(&(v40_6)) { singleton(&[]) } else { Space::new() };
  drop(v40_6);
  let v40_8: Space = subtract(&(*CONSTANT_0),&(v40_7));
  drop(v40_7);
  let v40_19: Space = if (&(v40_8)).is_empty() { Space::new() } else {
    let v41_11: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v41_14: Space = if (&(v41_11)).is_empty() { Space::new() } else {
      let v42_13: Space = routine_10(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v41_11),&(v42_13))
    };
    drop(v41_11);
    let mut v41_17 = Space::new();
    let mut v41_17_write = v41_17.write_zipper();
    let mut v41_17_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v41_17_origin = v41_17_cursor.path().len();
    for v41_17_byte in v41_17_cursor.child_mask().iter() {
      v41_17_cursor.descend_to_existing_byte(v41_17_byte);
      {
      let v43_2_arg_0: &[u8] = &v41_17_cursor.path()[v41_17_origin..(v41_17_origin + 1)];
      let v43_2_arg_1: &[u8] = &(*p0);
      let v43_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v43_2_more = v41_17_cursor.is_val() || next_value_within(&mut v41_17_cursor,(v41_17_origin + 1));
      while v43_2_more {
        {
        let v43_2_depth = v41_17_cursor.path().len();
        let mut v44_4_cursor = (*v43_2_arg_3).read_zipper();
        let v44_4_origin = v44_4_cursor.path().len();
        for v44_4_byte in v44_4_cursor.child_mask().iter() {
          v44_4_cursor.descend_to_existing_byte(v44_4_byte);
          {
          let v45_2: Path = concat_path(&(*v43_2_arg_1),&v44_4_cursor.path()[v44_4_origin..(v44_4_origin + 1)]);
          let v45_3: Space = routine_3(c, &(v45_2), &v41_17_cursor.path()[v41_17_origin..v43_2_depth], &v44_4_cursor);
          drop(v45_2);
          join_wrapped_into(&mut v41_17_write,&((v45_3).read_zipper()),&[]);
          }
          v44_4_cursor.ascend(1);
        }
        drop(v44_4_cursor);
        }
        v43_2_more = next_value_within(&mut v41_17_cursor,(v41_17_origin + 1));
      }
      }
      v41_17_cursor.ascend(1);
    }
    drop(v41_17_cursor);
    drop(v41_17_write);
    let v41_18: Space = unite(&(v41_14),&(v41_17));
    compose(&(v40_8),&(v41_18))
  };
  drop(v40_8);
  let v40_21: Space = intersect(&(*CONSTANT_3),&(v40_5));
  drop(v40_5);
  let v40_22: Space = if has_head(&(v40_21)) { singleton(&[]) } else { Space::new() };
  drop(v40_21);
  let v40_24: Space = if (&(v40_22)).is_empty() { Space::new() } else {
    let v46_23: Space = singleton(&(*p0));
    compose(&(v40_22),&(v46_23))
  };
  drop(v40_22);
  let v40_25: Space = unite(&(v40_19),&(v40_24));
  drop(v40_24);
  (v40_25).clone()
}

fn routine_4(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v47_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v47_2: Space = first_matching(&(*s0),&(*CONSTANT_0),false);
  let v47_3: Space = unite(&(v47_1),&(v47_2));
  drop(v47_1);
  drop(v47_2);
  let v47_6: Space = if (&(v47_3)).is_empty() { Space::new() } else {
    let v48_4: Space = routine_11(c, &(*s0));
    let v48_5: Space = subtract(&(*s0),&(v48_4));
    compose(&(v47_3),&(v48_5))
  };
  drop(v47_3);
  let v47_7: Space = subtract(&(*s0),&(v47_6));
  (v47_7).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v49_5: Space = singleton(&(*p1));
  let v49_6: Space = intersect(&(*CONSTANT_3),&(v49_5));
  let v49_7: Space = if has_head(&(v49_6)) { singleton(&[]) } else { Space::new() };
  drop(v49_6);
  let v49_8: Space = subtract(&(*CONSTANT_0),&(v49_7));
  drop(v49_7);
  let v49_19: Space = if (&(v49_8)).is_empty() { Space::new() } else {
    let v50_11: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v50_14: Space = if (&(v50_11)).is_empty() { Space::new() } else {
      let v51_13: Space = routine_12(c, &(*CONSTANT_1), &(*p0), &(*s0));
      compose(&(v50_11),&(v51_13))
    };
    drop(v50_11);
    let mut v50_17 = Space::new();
    let mut v50_17_write = v50_17.write_zipper();
    let mut v50_17_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v50_17_origin = v50_17_cursor.path().len();
    for v50_17_byte in v50_17_cursor.child_mask().iter() {
      v50_17_cursor.descend_to_existing_byte(v50_17_byte);
      {
      let v52_2_arg_0: &[u8] = &v50_17_cursor.path()[v50_17_origin..(v50_17_origin + 1)];
      let v52_2_arg_1: &[u8] = &(*p0);
      let v52_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v52_2_more = v50_17_cursor.is_val() || next_value_within(&mut v50_17_cursor,(v50_17_origin + 1));
      while v52_2_more {
        {
        let v52_2_depth = v50_17_cursor.path().len();
        let mut v53_4_cursor = (*v52_2_arg_3).read_zipper();
        let v53_4_origin = v53_4_cursor.path().len();
        for v53_4_byte in v53_4_cursor.child_mask().iter() {
          v53_4_cursor.descend_to_existing_byte(v53_4_byte);
          {
          let v54_2: Path = concat_path(&(*v52_2_arg_1),&v53_4_cursor.path()[v53_4_origin..(v53_4_origin + 1)]);
          let v54_3: Space = routine_5(c, &(v54_2), &v50_17_cursor.path()[v50_17_origin..v52_2_depth], &v53_4_cursor);
          drop(v54_2);
          join_wrapped_into(&mut v50_17_write,&((v54_3).read_zipper()),&[]);
          }
          v53_4_cursor.ascend(1);
        }
        drop(v53_4_cursor);
        }
        v52_2_more = next_value_within(&mut v50_17_cursor,(v50_17_origin + 1));
      }
      }
      v50_17_cursor.ascend(1);
    }
    drop(v50_17_cursor);
    drop(v50_17_write);
    let v50_18: Space = unite(&(v50_14),&(v50_17));
    compose(&(v49_8),&(v50_18))
  };
  drop(v49_8);
  let v49_21: Space = intersect(&(*CONSTANT_3),&(v49_5));
  drop(v49_5);
  let v49_22: Space = if has_head(&(v49_21)) { singleton(&[]) } else { Space::new() };
  drop(v49_21);
  let v49_24: Space = if (&(v49_22)).is_empty() { Space::new() } else {
    let mut v55_23 = Space::new();
    let mut v55_23_write = v55_23.write_zipper();
    let mut v55_23_cursor = (*s0).read_zipper();
    let v55_23_origin = v55_23_cursor.path().len();
    for v55_23_byte in v55_23_cursor.child_mask().iter() {
      v55_23_cursor.descend_to_existing_byte(v55_23_byte);
      {
      let v56_2: Space = routine_13(c, &v55_23_cursor.path()[v55_23_origin..(v55_23_origin + 1)], &v55_23_cursor.path()[v55_23_origin..(v55_23_origin + 1)], &(*p0), &v55_23_cursor);
      join_wrapped_into(&mut v55_23_write,&((v56_2).read_zipper()),&[]);
      }
      v55_23_cursor.ascend(1);
    }
    drop(v55_23_cursor);
    drop(v55_23_write);
    compose(&(v49_22),&(v55_23))
  };
  drop(v49_22);
  let v49_25: Space = unite(&(v49_19),&(v49_24));
  (v49_25).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let v57_8: Space = singleton(&(*p1));
  let v57_9: Space = intersect(&(*CONSTANT_3),&(v57_8));
  let v57_10: Space = if has_head(&(v57_9)) { singleton(&[]) } else { Space::new() };
  drop(v57_9);
  let v57_11: Space = subtract(&(*CONSTANT_0),&(v57_10));
  drop(v57_10);
  let v57_22: Space = if (&(v57_11)).is_empty() { Space::new() } else {
    let v58_14: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v58_17: Space = if (&(v58_14)).is_empty() { Space::new() } else {
      let v59_16: Space = routine_14(c, &(*CONSTANT_1), &(*p0), &(*s0), &(*s1), &(*s2), &(*s3));
      compose(&(v58_14),&(v59_16))
    };
    drop(v58_14);
    let mut v58_20 = Space::new();
    let mut v58_20_write = v58_20.write_zipper();
    let mut v58_20_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v58_20_origin = v58_20_cursor.path().len();
    for v58_20_byte in v58_20_cursor.child_mask().iter() {
      v58_20_cursor.descend_to_existing_byte(v58_20_byte);
      {
      let v60_2_arg_0: &[u8] = &v58_20_cursor.path()[v58_20_origin..(v58_20_origin + 1)];
      let v60_2_arg_1: &[u8] = &(*p0);
      let v60_2_arg_3: &Space = &(&(*s0)).make_map();
      let v60_2_arg_4: &Space = &(&(*s1)).make_map();
      let v60_2_arg_5: &Space = &(&(*s2)).make_map();
      let v60_2_arg_6: &Space = &(&(*s3)).make_map();
      let mut v60_2_more = v58_20_cursor.is_val() || next_value_within(&mut v58_20_cursor,(v58_20_origin + 1));
      while v60_2_more {
        {
        let v60_2_depth = v58_20_cursor.path().len();
        let mut v61_7_cursor = (*v60_2_arg_3).read_zipper();
        let v61_7_origin = v61_7_cursor.path().len();
        for v61_7_byte in v61_7_cursor.child_mask().iter() {
          v61_7_cursor.descend_to_existing_byte(v61_7_byte);
          {
          let v62_2: Path = concat_path(&(*v60_2_arg_1),&v61_7_cursor.path()[v61_7_origin..(v61_7_origin + 1)]);
          let v62_3: Space = routine_6(c, &(v62_2), &v58_20_cursor.path()[v58_20_origin..v60_2_depth], &v61_7_cursor, &((*v60_2_arg_4).read_zipper()), &((*v60_2_arg_5).read_zipper()), &((*v60_2_arg_6).read_zipper()));
          drop(v62_2);
          join_wrapped_into(&mut v58_20_write,&((v62_3).read_zipper()),&[]);
          }
          v61_7_cursor.ascend(1);
        }
        drop(v61_7_cursor);
        }
        v60_2_more = next_value_within(&mut v58_20_cursor,(v58_20_origin + 1));
      }
      }
      v58_20_cursor.ascend(1);
    }
    drop(v58_20_cursor);
    drop(v58_20_write);
    let v58_21: Space = unite(&(v58_17),&(v58_20));
    compose(&(v57_11),&(v58_21))
  };
  drop(v57_11);
  let v57_24: Space = intersect(&(*CONSTANT_3),&(v57_8));
  drop(v57_8);
  let v57_25: Space = if has_head(&(v57_24)) { singleton(&[]) } else { Space::new() };
  drop(v57_24);
  let v57_42: Space = if (&(v57_25)).is_empty() { Space::new() } else {
    let v63_26: Space = singleton(&(*p0));
    let v63_27: Space = routine_15(c, &(*s1), &(*s3), &((v63_26).read_zipper()));
    let v63_28: Space = routine_15(c, &(*s2), &(*s3), &((v63_26).read_zipper()));
    let v63_29: Space = intersect(&(v63_27),&(v63_28));
    let v63_30: Space = subtract(&(v63_29),&(v63_26));
    drop(v63_26);
    let v63_31: Space = wrap(&(v63_30),&(*p0));
    let v63_32: Space = subtract(&(*s3),&(v63_28));
    let v63_33: Space = subtract(&(v63_32),&(v63_27));
    let v63_34: Space = routine_16(c, &(*s2), &(*s1), &((v63_33).read_zipper()));
    let v63_35: Space = unite(&(v63_31),&(v63_34));
    let v63_36: Space = subtract(&(v63_27),&(v63_28));
    let v63_37: Space = routine_16(c, &(*s2), &(*s1), &((v63_36).read_zipper()));
    let v63_38: Space = unite(&(v63_35),&(v63_37));
    let v63_39: Space = subtract(&(v63_28),&(v63_27));
    let v63_40: Space = routine_16(c, &(*s2), &(*s1), &((v63_39).read_zipper()));
    let v63_41: Space = unite(&(v63_38),&(v63_40));
    compose(&(v57_25),&(v63_41))
  };
  drop(v57_25);
  let v57_43: Space = unite(&(v57_22),&(v57_42));
  (v57_43).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v64_5: Space = singleton(&(*p0));
  let v64_6: Space = intersect(&(*CONSTANT_3),&(v64_5));
  let v64_7: Space = if has_head(&(v64_6)) { singleton(&[]) } else { Space::new() };
  drop(v64_6);
  let v64_8: Space = subtract(&(*CONSTANT_0),&(v64_7));
  drop(v64_7);
  let v64_13: Space = intersect(&(*CONSTANT_3),&(v64_5));
  drop(v64_5);
  let v64_14: Space = if has_head(&(v64_13)) { singleton(&[]) } else { Space::new() };
  drop(v64_13);
  let mut v64_15 = Space::new();
  let mut v64_15_write = v64_15.write_zipper();
  let mut v64_15_cursor = (*s0).read_zipper();
  let v64_15_origin = v64_15_cursor.path().len();
  for v64_15_byte in v64_15_cursor.child_mask().iter() {
    v64_15_cursor.descend_to_existing_byte(v64_15_byte);
    {
    let v65_4: Space = if (&(v64_8)).is_empty() { Space::new() } else {
      let v66_2: Path = concat_path(&(*p1),&v64_15_cursor.path()[v64_15_origin..(v64_15_origin + 1)]);
      let mut v66_3 = Space::new();
      let mut v66_3_write = v66_3.write_zipper();
      let v66_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v66_3_arg_1: &[u8] = &(v66_2);
      let v66_3_arg_3: &Space = &(&v64_15_cursor).make_map();
      let mut v66_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v66_3_origin = v66_3_cursor.path().len();
      let mut v66_3_more = v66_3_cursor.is_val() || next_value_within(&mut v66_3_cursor,v66_3_origin);
      while v66_3_more {
        {
        let v66_3_depth = v66_3_cursor.path().len();
        let v67_4: Space = routine_7(c, &v66_3_cursor.path()[v66_3_origin..v66_3_depth], &(*v66_3_arg_1), &((*v66_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v66_3_write,&((v67_4).read_zipper()),&[]);
        }
        v66_3_more = next_value_within(&mut v66_3_cursor,v66_3_origin);
      }
      drop(v66_3_cursor);
      drop(v66_3_write);
      compose(&(v64_8),&(v66_3))
    };
    let v65_6: Space = if (&(v64_14)).is_empty() { Space::new() } else {
      let v68_2: Path = concat_path(&(*p1),&v64_15_cursor.path()[v64_15_origin..(v64_15_origin + 1)]);
      let v68_5: Space = singleton(&(v68_2));
      drop(v68_2);
      compose(&(v64_14),&(v68_5))
    };
    let v65_7: Space = unite(&(v65_4),&(v65_6));
    drop(v65_6);
    join_wrapped_into(&mut v64_15_write,&((v65_7).read_zipper()),&[]);
    }
    v64_15_cursor.ascend(1);
  }
  drop(v64_15_cursor);
  drop(v64_15_write);
  drop(v64_8);
  drop(v64_14);
  (v64_15).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v69_5: Space = singleton(&(*p0));
  let v69_6: Space = intersect(&(*CONSTANT_3),&(v69_5));
  let v69_7: Space = if has_head(&(v69_6)) { singleton(&[]) } else { Space::new() };
  drop(v69_6);
  let v69_8: Space = subtract(&(*CONSTANT_0),&(v69_7));
  drop(v69_7);
  let v69_13: Space = intersect(&(*CONSTANT_3),&(v69_5));
  drop(v69_5);
  let v69_14: Space = if has_head(&(v69_13)) { singleton(&[]) } else { Space::new() };
  drop(v69_13);
  let mut v69_15 = Space::new();
  let mut v69_15_write = v69_15.write_zipper();
  let mut v69_15_cursor = (*s0).read_zipper();
  let v69_15_origin = v69_15_cursor.path().len();
  for v69_15_byte in v69_15_cursor.child_mask().iter() {
    v69_15_cursor.descend_to_existing_byte(v69_15_byte);
    {
    let v70_4: Space = if (&(v69_8)).is_empty() { Space::new() } else {
      let v71_2: Path = concat_path(&(*p1),&v69_15_cursor.path()[v69_15_origin..(v69_15_origin + 1)]);
      let mut v71_3 = Space::new();
      let mut v71_3_write = v71_3.write_zipper();
      let v71_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v71_3_arg_1: &[u8] = &(v71_2);
      let v71_3_arg_3: &Space = &(&v69_15_cursor).make_map();
      let mut v71_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v71_3_origin = v71_3_cursor.path().len();
      let mut v71_3_more = v71_3_cursor.is_val() || next_value_within(&mut v71_3_cursor,v71_3_origin);
      while v71_3_more {
        {
        let v71_3_depth = v71_3_cursor.path().len();
        let v72_4: Space = routine_8(c, &v71_3_cursor.path()[v71_3_origin..v71_3_depth], &(*v71_3_arg_1), &((*v71_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v71_3_write,&((v72_4).read_zipper()),&[]);
        }
        v71_3_more = next_value_within(&mut v71_3_cursor,v71_3_origin);
      }
      drop(v71_3_cursor);
      drop(v71_3_write);
      compose(&(v69_8),&(v71_3))
    };
    let v70_6: Space = if (&(v69_14)).is_empty() { Space::new() } else {
      let v73_2: Path = concat_path(&(*p1),&v69_15_cursor.path()[v69_15_origin..(v69_15_origin + 1)]);
      let mut v73_5 = Space::new();
      let mut v73_5_write = v73_5.write_zipper();
      for v73_5_byte in v69_15_cursor.child_mask().iter() {
        v69_15_cursor.descend_to_existing_byte(v73_5_byte);
        {
        let v74_2: Space = routine_9(c, &v69_15_cursor.path()[(v69_15_origin + 1)..(v69_15_origin + 2)], &v69_15_cursor.path()[(v69_15_origin + 1)..(v69_15_origin + 2)], &(v73_2), &v69_15_cursor);
        join_wrapped_into(&mut v73_5_write,&((v74_2).read_zipper()),&[]);
        }
        v69_15_cursor.ascend(1);
      }
      drop(v73_5_write);
      drop(v73_2);
      compose(&(v69_14),&(v73_5))
    };
    let v70_7: Space = unite(&(v70_4),&(v70_6));
    join_wrapped_into(&mut v69_15_write,&((v70_7).read_zipper()),&[]);
    }
    v69_15_cursor.ascend(1);
  }
  drop(v69_15_cursor);
  drop(v69_15_write);
  drop(v69_8);
  drop(v69_14);
  (v69_15).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v75_6: Space = singleton(&(*p1));
  let v75_7: Space = intersect(&(*CONSTANT_3),&(v75_6));
  let v75_8: Space = if has_head(&(v75_7)) { singleton(&[]) } else { Space::new() };
  drop(v75_7);
  let v75_9: Space = subtract(&(*CONSTANT_0),&(v75_8));
  drop(v75_8);
  let v75_20: Space = if (&(v75_9)).is_empty() { Space::new() } else {
    let v76_12: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v76_15: Space = if (&(v76_12)).is_empty() { Space::new() } else {
      let v77_14: Space = routine_17(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v76_12),&(v77_14))
    };
    drop(v76_12);
    let mut v76_18 = Space::new();
    let mut v76_18_write = v76_18.write_zipper();
    let mut v76_18_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v76_18_origin = v76_18_cursor.path().len();
    for v76_18_byte in v76_18_cursor.child_mask().iter() {
      v76_18_cursor.descend_to_existing_byte(v76_18_byte);
      {
      let v78_2_arg_0: &[u8] = &v76_18_cursor.path()[v76_18_origin..(v76_18_origin + 1)];
      let v78_2_arg_1: &[u8] = &(*p0);
      let v78_2_arg_2: &[u8] = &(*p2);
      let v78_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v78_2_more = v76_18_cursor.is_val() || next_value_within(&mut v76_18_cursor,(v76_18_origin + 1));
      while v78_2_more {
        {
        let v78_2_depth = v76_18_cursor.path().len();
        let mut v79_5_cursor = (*v78_2_arg_4).read_zipper();
        let v79_5_origin = v79_5_cursor.path().len();
        for v79_5_byte in v79_5_cursor.child_mask().iter() {
          v79_5_cursor.descend_to_existing_byte(v79_5_byte);
          {
          let v80_2: Path = concat_path(&(*v78_2_arg_1),&v79_5_cursor.path()[v79_5_origin..(v79_5_origin + 1)]);
          let v80_3: Space = routine_9(c, &(v80_2), &v76_18_cursor.path()[v76_18_origin..v78_2_depth], &(*v78_2_arg_2), &v79_5_cursor);
          drop(v80_2);
          join_wrapped_into(&mut v76_18_write,&((v80_3).read_zipper()),&[]);
          }
          v79_5_cursor.ascend(1);
        }
        drop(v79_5_cursor);
        }
        v78_2_more = next_value_within(&mut v76_18_cursor,(v76_18_origin + 1));
      }
      }
      v76_18_cursor.ascend(1);
    }
    drop(v76_18_cursor);
    drop(v76_18_write);
    let v76_19: Space = unite(&(v76_15),&(v76_18));
    compose(&(v75_9),&(v76_19))
  };
  drop(v75_9);
  let v75_22: Space = intersect(&(*CONSTANT_3),&(v75_6));
  drop(v75_6);
  let v75_23: Space = if has_head(&(v75_22)) { singleton(&[]) } else { Space::new() };
  drop(v75_22);
  let v75_26: Space = if (&(v75_23)).is_empty() { Space::new() } else {
    let v81_24: Path = concat_path(&(*p0),&(*p2));
    let v81_25: Space = singleton(&(v81_24));
    drop(v81_24);
    compose(&(v75_23),&(v81_25))
  };
  drop(v75_23);
  let v75_27: Space = unite(&(v75_20),&(v75_26));
  drop(v75_26);
  (v75_27).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v82_5: Space = singleton(&(*p0));
  let v82_6: Space = intersect(&(*CONSTANT_3),&(v82_5));
  let v82_7: Space = if has_head(&(v82_6)) { singleton(&[]) } else { Space::new() };
  drop(v82_6);
  let v82_8: Space = subtract(&(*CONSTANT_0),&(v82_7));
  drop(v82_7);
  let v82_13: Space = intersect(&(*CONSTANT_3),&(v82_5));
  drop(v82_5);
  let v82_14: Space = if has_head(&(v82_13)) { singleton(&[]) } else { Space::new() };
  drop(v82_13);
  let mut v82_15 = Space::new();
  let mut v82_15_write = v82_15.write_zipper();
  let mut v82_15_cursor = (*s0).read_zipper();
  let v82_15_origin = v82_15_cursor.path().len();
  for v82_15_byte in v82_15_cursor.child_mask().iter() {
    v82_15_cursor.descend_to_existing_byte(v82_15_byte);
    {
    let v83_4: Space = if (&(v82_8)).is_empty() { Space::new() } else {
      let v84_2: Path = concat_path(&(*p1),&v82_15_cursor.path()[v82_15_origin..(v82_15_origin + 1)]);
      let mut v84_3 = Space::new();
      let mut v84_3_write = v84_3.write_zipper();
      let v84_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v84_3_arg_1: &[u8] = &(v84_2);
      let v84_3_arg_3: &Space = &(&v82_15_cursor).make_map();
      let mut v84_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v84_3_origin = v84_3_cursor.path().len();
      let mut v84_3_more = v84_3_cursor.is_val() || next_value_within(&mut v84_3_cursor,v84_3_origin);
      while v84_3_more {
        {
        let v84_3_depth = v84_3_cursor.path().len();
        let v85_4: Space = routine_10(c, &v84_3_cursor.path()[v84_3_origin..v84_3_depth], &(*v84_3_arg_1), &((*v84_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v84_3_write,&((v85_4).read_zipper()),&[]);
        }
        v84_3_more = next_value_within(&mut v84_3_cursor,v84_3_origin);
      }
      drop(v84_3_cursor);
      drop(v84_3_write);
      compose(&(v82_8),&(v84_3))
    };
    let v83_6: Space = if (&(v82_14)).is_empty() { Space::new() } else {
      let v86_2: Path = concat_path(&(*p1),&v82_15_cursor.path()[v82_15_origin..(v82_15_origin + 1)]);
      let v86_5: Space = singleton(&(v86_2));
      drop(v86_2);
      compose(&(v82_14),&(v86_5))
    };
    let v83_7: Space = unite(&(v83_4),&(v83_6));
    drop(v83_6);
    join_wrapped_into(&mut v82_15_write,&((v83_7).read_zipper()),&[]);
    }
    v82_15_cursor.ascend(1);
  }
  drop(v82_15_cursor);
  drop(v82_15_write);
  drop(v82_8);
  drop(v82_14);
  (v82_15).clone()
}

fn routine_11(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v87_2: Space = first_matching(&(*s0),&(*CONSTANT_0),false);
  let v87_3: Space = intersect(&(*CONSTANT_0),&(v87_2));
  let v87_4: Space = if has_head(&(v87_2)) { singleton(&[]) } else { Space::new() };
  let v87_5: Space = unite(&(v87_3),&(v87_4));
  drop(v87_3);
  let v87_7: Space = compose(&(v87_5),&(*CONSTANT_0));
  drop(v87_5);
  let v87_9: Space = subtract(&(*CONSTANT_0),&(v87_2));
  drop(v87_2);
  let v87_10: Space = subtract(&(v87_9),&(v87_4));
  drop(v87_4);
  drop(v87_9);
  let v87_18: Space = if (&(v87_10)).is_empty() { Space::new() } else {
    let v88_11: Space = first_length_prefixed(&(*s0));
    let v88_12: Space = first_matching(&(v88_11),&(*CONSTANT_0),false);
    let v88_15: Space = if (&(v88_12)).is_empty() { Space::new() } else {
      let v89_14: Space = routine_18(c, &(*CONSTANT_1), &(*s0));
      compose(&(v88_12),&(v89_14))
    };
    drop(v88_12);
    let mut v88_16 = Space::new();
    let mut v88_16_write = v88_16.write_zipper();
    let mut v88_16_cursor = (v88_11).read_zipper();
    let v88_16_origin = v88_16_cursor.path().len();
    for v88_16_byte in v88_16_cursor.child_mask().iter() {
      v88_16_cursor.descend_to_existing_byte(v88_16_byte);
      {
      let v90_2_arg_0: &[u8] = &v88_16_cursor.path()[v88_16_origin..(v88_16_origin + 1)];
      let v90_2_arg_2: &Space = &(&(*s0)).make_map();
      let mut v90_2_more = v88_16_cursor.is_val() || next_value_within(&mut v88_16_cursor,(v88_16_origin + 1));
      while v90_2_more {
        {
        let v90_2_depth = v88_16_cursor.path().len();
        let v91_4: Space = routine_11(c, &(descend_cursor((*v90_2_arg_2).read_zipper(),&v88_16_cursor.path()[v88_16_origin..v90_2_depth])));
        join_wrapped_into(&mut v88_16_write,&((v91_4).read_zipper()),&v88_16_cursor.path()[v88_16_origin..v90_2_depth]);
        }
        v90_2_more = next_value_within(&mut v88_16_cursor,(v88_16_origin + 1));
      }
      }
      v88_16_cursor.ascend(1);
    }
    drop(v88_16_cursor);
    drop(v88_16_write);
    drop(v88_11);
    let v88_17: Space = unite(&(v88_15),&(v88_16));
    compose(&(v87_10),&(v88_17))
  };
  drop(v87_10);
  let v87_19: Space = unite(&(v87_7),&(v87_18));
  drop(v87_7);
  (v87_19).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v92_5: Space = singleton(&(*p0));
  let v92_6: Space = intersect(&(*CONSTANT_3),&(v92_5));
  let v92_7: Space = if has_head(&(v92_6)) { singleton(&[]) } else { Space::new() };
  drop(v92_6);
  let v92_8: Space = subtract(&(*CONSTANT_0),&(v92_7));
  drop(v92_7);
  let v92_13: Space = intersect(&(*CONSTANT_3),&(v92_5));
  drop(v92_5);
  let v92_14: Space = if has_head(&(v92_13)) { singleton(&[]) } else { Space::new() };
  drop(v92_13);
  let mut v92_15 = Space::new();
  let mut v92_15_write = v92_15.write_zipper();
  let mut v92_15_cursor = (*s0).read_zipper();
  let v92_15_origin = v92_15_cursor.path().len();
  for v92_15_byte in v92_15_cursor.child_mask().iter() {
    v92_15_cursor.descend_to_existing_byte(v92_15_byte);
    {
    let v93_4: Space = if (&(v92_8)).is_empty() { Space::new() } else {
      let v94_2: Path = concat_path(&(*p1),&v92_15_cursor.path()[v92_15_origin..(v92_15_origin + 1)]);
      let mut v94_3 = Space::new();
      let mut v94_3_write = v94_3.write_zipper();
      let v94_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v94_3_arg_1: &[u8] = &(v94_2);
      let v94_3_arg_3: &Space = &(&v92_15_cursor).make_map();
      let mut v94_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v94_3_origin = v94_3_cursor.path().len();
      let mut v94_3_more = v94_3_cursor.is_val() || next_value_within(&mut v94_3_cursor,v94_3_origin);
      while v94_3_more {
        {
        let v94_3_depth = v94_3_cursor.path().len();
        let v95_4: Space = routine_12(c, &v94_3_cursor.path()[v94_3_origin..v94_3_depth], &(*v94_3_arg_1), &((*v94_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v94_3_write,&((v95_4).read_zipper()),&[]);
        }
        v94_3_more = next_value_within(&mut v94_3_cursor,v94_3_origin);
      }
      drop(v94_3_cursor);
      drop(v94_3_write);
      compose(&(v92_8),&(v94_3))
    };
    let v93_6: Space = if (&(v92_14)).is_empty() { Space::new() } else {
      let v96_2: Path = concat_path(&(*p1),&v92_15_cursor.path()[v92_15_origin..(v92_15_origin + 1)]);
      let mut v96_5 = Space::new();
      let mut v96_5_write = v96_5.write_zipper();
      for v96_5_byte in v92_15_cursor.child_mask().iter() {
        v92_15_cursor.descend_to_existing_byte(v96_5_byte);
        {
        let v97_2: Space = routine_13(c, &v92_15_cursor.path()[(v92_15_origin + 1)..(v92_15_origin + 2)], &v92_15_cursor.path()[(v92_15_origin + 1)..(v92_15_origin + 2)], &(v96_2), &v92_15_cursor);
        join_wrapped_into(&mut v96_5_write,&((v97_2).read_zipper()),&[]);
        }
        v92_15_cursor.ascend(1);
      }
      drop(v96_5_write);
      drop(v96_2);
      compose(&(v92_14),&(v96_5))
    };
    let v93_7: Space = unite(&(v93_4),&(v93_6));
    join_wrapped_into(&mut v92_15_write,&((v93_7).read_zipper()),&[]);
    }
    v92_15_cursor.ascend(1);
  }
  drop(v92_15_cursor);
  drop(v92_15_write);
  drop(v92_8);
  drop(v92_14);
  (v92_15).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v98_6: Space = singleton(&(*p1));
  let v98_7: Space = intersect(&(*CONSTANT_3),&(v98_6));
  let v98_8: Space = if has_head(&(v98_7)) { singleton(&[]) } else { Space::new() };
  drop(v98_7);
  let v98_9: Space = subtract(&(*CONSTANT_0),&(v98_8));
  drop(v98_8);
  let v98_20: Space = if (&(v98_9)).is_empty() { Space::new() } else {
    let v99_12: Space = first_matching(&(descend_cursor((*CONSTANT_5).read_zipper(),&(*p1))),&(*CONSTANT_0),false);
    let v99_15: Space = if (&(v99_12)).is_empty() { Space::new() } else {
      let v100_14: Space = routine_19(c, &(*CONSTANT_1), &(*p0), &(*p2), &(*s0));
      compose(&(v99_12),&(v100_14))
    };
    drop(v99_12);
    let mut v99_18 = Space::new();
    let mut v99_18_write = v99_18.write_zipper();
    let mut v99_18_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p1));
    let v99_18_origin = v99_18_cursor.path().len();
    for v99_18_byte in v99_18_cursor.child_mask().iter() {
      v99_18_cursor.descend_to_existing_byte(v99_18_byte);
      {
      let v101_2_arg_0: &[u8] = &v99_18_cursor.path()[v99_18_origin..(v99_18_origin + 1)];
      let v101_2_arg_1: &[u8] = &(*p0);
      let v101_2_arg_2: &[u8] = &(*p2);
      let v101_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v101_2_more = v99_18_cursor.is_val() || next_value_within(&mut v99_18_cursor,(v99_18_origin + 1));
      while v101_2_more {
        {
        let v101_2_depth = v99_18_cursor.path().len();
        let mut v102_5_cursor = (*v101_2_arg_4).read_zipper();
        let v102_5_origin = v102_5_cursor.path().len();
        for v102_5_byte in v102_5_cursor.child_mask().iter() {
          v102_5_cursor.descend_to_existing_byte(v102_5_byte);
          {
          let v103_2: Path = concat_path(&(*v101_2_arg_1),&v102_5_cursor.path()[v102_5_origin..(v102_5_origin + 1)]);
          let v103_3: Space = routine_13(c, &(v103_2), &v99_18_cursor.path()[v99_18_origin..v101_2_depth], &(*v101_2_arg_2), &v102_5_cursor);
          drop(v103_2);
          join_wrapped_into(&mut v99_18_write,&((v103_3).read_zipper()),&[]);
          }
          v102_5_cursor.ascend(1);
        }
        drop(v102_5_cursor);
        }
        v101_2_more = next_value_within(&mut v99_18_cursor,(v99_18_origin + 1));
      }
      }
      v99_18_cursor.ascend(1);
    }
    drop(v99_18_cursor);
    drop(v99_18_write);
    let v99_19: Space = unite(&(v99_15),&(v99_18));
    compose(&(v98_9),&(v99_19))
  };
  drop(v98_9);
  let v98_22: Space = intersect(&(*CONSTANT_3),&(v98_6));
  drop(v98_6);
  let v98_23: Space = if has_head(&(v98_22)) { singleton(&[]) } else { Space::new() };
  drop(v98_22);
  let v98_26: Space = if (&(v98_23)).is_empty() { Space::new() } else {
    let v104_24: Path = concat_path(&(*p0),&(*p2));
    let v104_25: Space = singleton(&(v104_24));
    drop(v104_24);
    compose(&(v98_23),&(v104_25))
  };
  drop(v98_23);
  let v98_27: Space = unite(&(v98_20),&(v98_26));
  drop(v98_26);
  (v98_27).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let v105_8: Space = singleton(&(*p0));
  let v105_9: Space = intersect(&(*CONSTANT_3),&(v105_8));
  let v105_10: Space = if has_head(&(v105_9)) { singleton(&[]) } else { Space::new() };
  drop(v105_9);
  let v105_11: Space = subtract(&(*CONSTANT_0),&(v105_10));
  drop(v105_10);
  let v105_16: Space = intersect(&(*CONSTANT_3),&(v105_8));
  drop(v105_8);
  let v105_17: Space = if has_head(&(v105_16)) { singleton(&[]) } else { Space::new() };
  drop(v105_16);
  let mut v105_18 = Space::new();
  let mut v105_18_write = v105_18.write_zipper();
  let mut v105_18_cursor = (*s0).read_zipper();
  let v105_18_origin = v105_18_cursor.path().len();
  for v105_18_byte in v105_18_cursor.child_mask().iter() {
    v105_18_cursor.descend_to_existing_byte(v105_18_byte);
    {
    let v106_4: Space = if (&(v105_11)).is_empty() { Space::new() } else {
      let v107_2: Path = concat_path(&(*p1),&v105_18_cursor.path()[v105_18_origin..(v105_18_origin + 1)]);
      let mut v107_3 = Space::new();
      let mut v107_3_write = v107_3.write_zipper();
      let v107_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v107_3_arg_1: &[u8] = &(v107_2);
      let v107_3_arg_3: &Space = &(&v105_18_cursor).make_map();
      let v107_3_arg_4: &Space = &(&(*s1)).make_map();
      let v107_3_arg_5: &Space = &(&(*s2)).make_map();
      let v107_3_arg_6: &Space = &(&(*s3)).make_map();
      let mut v107_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v107_3_origin = v107_3_cursor.path().len();
      let mut v107_3_more = v107_3_cursor.is_val() || next_value_within(&mut v107_3_cursor,v107_3_origin);
      while v107_3_more {
        {
        let v107_3_depth = v107_3_cursor.path().len();
        let v108_7: Space = routine_14(c, &v107_3_cursor.path()[v107_3_origin..v107_3_depth], &(*v107_3_arg_1), &((*v107_3_arg_3).read_zipper()), &((*v107_3_arg_4).read_zipper()), &((*v107_3_arg_5).read_zipper()), &((*v107_3_arg_6).read_zipper()));
        join_wrapped_into(&mut v107_3_write,&((v108_7).read_zipper()),&[]);
        }
        v107_3_more = next_value_within(&mut v107_3_cursor,v107_3_origin);
      }
      drop(v107_3_cursor);
      drop(v107_3_write);
      compose(&(v105_11),&(v107_3))
    };
    let v106_6: Space = if (&(v105_17)).is_empty() { Space::new() } else {
      let v109_2: Path = concat_path(&(*p1),&v105_18_cursor.path()[v105_18_origin..(v105_18_origin + 1)]);
      let v109_5: Space = routine_20(c, &(v109_2), &v105_18_cursor, &(*s1), &(*s2), &(*s3));
      drop(v109_2);
      compose(&(v105_17),&(v109_5))
    };
    let v106_7: Space = unite(&(v106_4),&(v106_6));
    join_wrapped_into(&mut v105_18_write,&((v106_7).read_zipper()),&[]);
    }
    v105_18_cursor.ascend(1);
  }
  drop(v105_18_cursor);
  drop(v105_18_write);
  drop(v105_11);
  drop(v105_17);
  (v105_18).clone()
}

fn routine_15(c: &mut Context, s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>) -> Space {
  let v110_3: Space = intersect(&(*s1),&(*s2));
  let v110_4: Space = restrict_to(&(*s0),&(v110_3));
  drop(v110_3);
  let v110_770: Space = drop_length_prefixes(&(v110_4));
  drop(v110_4);
  let v110_771: Space = unite(&(v110_770),&(*s2));
  drop(v110_770);
  let v110_772: Space = intersect(&(v110_771),&(*s1));
  drop(v110_771);
  let mut v110_1538: Space = (v110_772).clone();
  loop {
    let v111_1: Space = intersect(&(v110_1538),&(*s1));
    let v111_2: Space = restrict_to(&(*s0),&(v111_1));
    drop(v111_1);
    let v111_3: Space = drop_length_prefixes(&(v111_2));
    drop(v111_2);
    let v111_4: Space = unite(&(v111_3),&(v110_1538));
    drop(v111_3);
    let v111_5: Space = intersect(&(v111_4),&(*s1));
    drop(v111_4);
    if !v110_1538.join_into((v111_5).clone()).is_element() { break; }
  }
  drop(v110_772);
  let v110_1539: Space = unite(&(*s2),&(v110_1538));
  drop(v110_1538);
  (v110_1539).clone()
}

fn routine_16(c: &mut Context, s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>) -> Space {
  let v112_3: Space = if has_head(&(*s2)) { singleton(&[]) } else { Space::new() };
  let v112_4: Space = first_matching(&(*s2),&(*CONSTANT_0),false);
  let v112_5: Space = unite(&(v112_3),&(v112_4));
  drop(v112_3);
  drop(v112_4);
  let v112_8: Space = if (&(v112_5)).is_empty() { Space::new() } else {
    let v113_6: Space = routine_11(c, &(*s2));
    let v113_7: Space = subtract(&(*s2),&(v113_6));
    compose(&(v112_5),&(v113_7))
  };
  drop(v112_5);
  let v112_9: Space = subtract(&(*s2),&(v112_8));
  let mut v112_15 = Space::new();
  let mut v112_15_write = v112_15.write_zipper();
  let mut v112_15_cursor = (v112_9).read_zipper();
  let v112_15_origin = v112_15_cursor.path().len();
  for v112_15_byte in v112_15_cursor.child_mask().iter() {
    v112_15_cursor.descend_to_existing_byte(v112_15_byte);
    {
    let v114_2: Space = singleton(&v112_15_cursor.path()[v112_15_origin..(v112_15_origin + 1)]);
    let v114_3: Space = intersect(&(*CONSTANT_3),&(v114_2));
    let v114_4: Space = if has_head(&(v114_3)) { singleton(&[]) } else { Space::new() };
    drop(v114_3);
    let v114_5: Space = subtract(&(*CONSTANT_0),&(v114_4));
    drop(v114_4);
    let v114_8: Space = if (&(v114_5)).is_empty() { Space::new() } else {
      let mut v115_7 = Space::new();
      let mut v115_7_write = v115_7.write_zipper();
      let v115_7_arg_0: &[u8] = &(*CONSTANT_1);
      let v115_7_arg_1: &[u8] = &v112_15_cursor.path()[v112_15_origin..(v112_15_origin + 1)];
      let v115_7_arg_3: &Space = &(&v112_15_cursor).make_map();
      let v115_7_arg_4: &Space = &(&(*s1)).make_map();
      let v115_7_arg_5: &Space = &(&(*s0)).make_map();
      let v115_7_arg_6: &Space = &(&(*s2)).make_map();
      let mut v115_7_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&v112_15_cursor.path()[v112_15_origin..(v112_15_origin + 1)]);
      let v115_7_origin = v115_7_cursor.path().len();
      let mut v115_7_more = v115_7_cursor.is_val() || next_value_within(&mut v115_7_cursor,v115_7_origin);
      while v115_7_more {
        {
        let v115_7_depth = v115_7_cursor.path().len();
        let mut v116_7_cursor = (*v115_7_arg_3).read_zipper();
        let v116_7_origin = v116_7_cursor.path().len();
        for v116_7_byte in v116_7_cursor.child_mask().iter() {
          v116_7_cursor.descend_to_existing_byte(v116_7_byte);
          {
          let v117_2: Path = concat_path(&(*v115_7_arg_1),&v116_7_cursor.path()[v116_7_origin..(v116_7_origin + 1)]);
          let v117_3: Space = routine_6(c, &(v117_2), &v115_7_cursor.path()[v115_7_origin..v115_7_depth], &v116_7_cursor, &((*v115_7_arg_4).read_zipper()), &((*v115_7_arg_5).read_zipper()), &((*v115_7_arg_6).read_zipper()));
          drop(v117_2);
          join_wrapped_into(&mut v115_7_write,&((v117_3).read_zipper()),&[]);
          }
          v116_7_cursor.ascend(1);
        }
        drop(v116_7_cursor);
        }
        v115_7_more = next_value_within(&mut v115_7_cursor,v115_7_origin);
      }
      drop(v115_7_cursor);
      drop(v115_7_write);
      compose(&(v114_5),&(v115_7))
    };
    drop(v114_5);
    let v114_9: Space = intersect(&(*CONSTANT_3),&(v114_2));
    drop(v114_2);
    let v114_10: Space = if has_head(&(v114_9)) { singleton(&[]) } else { Space::new() };
    drop(v114_9);
    let v114_12: Space = if (&(v114_10)).is_empty() { Space::new() } else {
      let v118_11: Space = routine_20(c, &v112_15_cursor.path()[v112_15_origin..(v112_15_origin + 1)], &v112_15_cursor, &(*s1), &(*s0), &(*s2));
      compose(&(v114_10),&(v118_11))
    };
    drop(v114_10);
    let v114_13: Space = unite(&(v114_8),&(v114_12));
    join_wrapped_into(&mut v112_15_write,&((v114_13).read_zipper()),&[]);
    }
    v112_15_cursor.ascend(1);
  }
  drop(v112_15_cursor);
  drop(v112_15_write);
  (v112_15).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v119_6: Space = singleton(&(*p0));
  let v119_7: Space = intersect(&(*CONSTANT_3),&(v119_6));
  let v119_8: Space = if has_head(&(v119_7)) { singleton(&[]) } else { Space::new() };
  drop(v119_7);
  let v119_9: Space = subtract(&(*CONSTANT_0),&(v119_8));
  drop(v119_8);
  let v119_14: Space = intersect(&(*CONSTANT_3),&(v119_6));
  drop(v119_6);
  let v119_15: Space = if has_head(&(v119_14)) { singleton(&[]) } else { Space::new() };
  drop(v119_14);
  let mut v119_16 = Space::new();
  let mut v119_16_write = v119_16.write_zipper();
  let mut v119_16_cursor = (*s0).read_zipper();
  let v119_16_origin = v119_16_cursor.path().len();
  for v119_16_byte in v119_16_cursor.child_mask().iter() {
    v119_16_cursor.descend_to_existing_byte(v119_16_byte);
    {
    let v120_4: Space = if (&(v119_9)).is_empty() { Space::new() } else {
      let v121_2: Path = concat_path(&(*p1),&v119_16_cursor.path()[v119_16_origin..(v119_16_origin + 1)]);
      let mut v121_3 = Space::new();
      let mut v121_3_write = v121_3.write_zipper();
      let v121_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v121_3_arg_1: &[u8] = &(v121_2);
      let v121_3_arg_2: &[u8] = &(*p2);
      let v121_3_arg_4: &Space = &(&v119_16_cursor).make_map();
      let mut v121_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v121_3_origin = v121_3_cursor.path().len();
      let mut v121_3_more = v121_3_cursor.is_val() || next_value_within(&mut v121_3_cursor,v121_3_origin);
      while v121_3_more {
        {
        let v121_3_depth = v121_3_cursor.path().len();
        let v122_5: Space = routine_17(c, &v121_3_cursor.path()[v121_3_origin..v121_3_depth], &(*v121_3_arg_1), &(*v121_3_arg_2), &((*v121_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v121_3_write,&((v122_5).read_zipper()),&[]);
        }
        v121_3_more = next_value_within(&mut v121_3_cursor,v121_3_origin);
      }
      drop(v121_3_cursor);
      drop(v121_3_write);
      compose(&(v119_9),&(v121_3))
    };
    let v120_7: Space = if (&(v119_15)).is_empty() { Space::new() } else {
      let v123_2: Path = concat_path(&(*p1),&v119_16_cursor.path()[v119_16_origin..(v119_16_origin + 1)]);
      let v123_5: Path = concat_path(&(v123_2),&(*p2));
      drop(v123_2);
      let v123_6: Space = singleton(&(v123_5));
      drop(v123_5);
      compose(&(v119_15),&(v123_6))
    };
    let v120_8: Space = unite(&(v120_4),&(v120_7));
    drop(v120_7);
    join_wrapped_into(&mut v119_16_write,&((v120_8).read_zipper()),&[]);
    }
    v119_16_cursor.ascend(1);
  }
  drop(v119_16_cursor);
  drop(v119_16_write);
  drop(v119_9);
  drop(v119_15);
  (v119_16).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v124_4: Space = first_matching(&(descend_cursor((*s0).read_zipper(),&(*p0))),&(*CONSTANT_0),false);
  let v124_5: Space = intersect(&(*CONSTANT_0),&(v124_4));
  let v124_6: Space = if has_head(&(v124_4)) { singleton(&[]) } else { Space::new() };
  let v124_7: Space = unite(&(v124_5),&(v124_6));
  drop(v124_5);
  let v124_9: Space = compose(&(v124_7),&(*CONSTANT_0));
  drop(v124_7);
  let v124_11: Space = subtract(&(*CONSTANT_0),&(v124_4));
  drop(v124_4);
  let v124_12: Space = subtract(&(v124_11),&(v124_6));
  drop(v124_6);
  drop(v124_11);
  let v124_16: Space = if (&(v124_12)).is_empty() { Space::new() } else {
    let v125_14: Space = first_length_prefixed(&(descend_cursor((*s0).read_zipper(),&(*p0))));
    let mut v125_15 = Space::new();
    let mut v125_15_write = v125_15.write_zipper();
    let v125_15_arg_0: &[u8] = &(*CONSTANT_1);
    let v125_15_arg_2: &Space = &(&(descend_cursor((*s0).read_zipper(),&(*p0)))).make_map();
    let mut v125_15_cursor = (v125_14).read_zipper();
    let v125_15_origin = v125_15_cursor.path().len();
    let mut v125_15_more = v125_15_cursor.is_val() || next_value_within(&mut v125_15_cursor,v125_15_origin);
    while v125_15_more {
      {
      let v125_15_depth = v125_15_cursor.path().len();
      let v126_3: Space = routine_18(c, &v125_15_cursor.path()[v125_15_origin..v125_15_depth], &((*v125_15_arg_2).read_zipper()));
      join_wrapped_into(&mut v125_15_write,&((v126_3).read_zipper()),&[]);
      }
      v125_15_more = next_value_within(&mut v125_15_cursor,v125_15_origin);
    }
    drop(v125_15_cursor);
    drop(v125_15_write);
    drop(v125_14);
    compose(&(v124_12),&(v125_15))
  };
  drop(v124_12);
  let v124_17: Space = unite(&(v124_9),&(v124_16));
  drop(v124_9);
  let v124_18: Space = wrap(&(v124_17),&(*p0));
  (v124_18).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v127_6: Space = singleton(&(*p0));
  let v127_7: Space = intersect(&(*CONSTANT_3),&(v127_6));
  let v127_8: Space = if has_head(&(v127_7)) { singleton(&[]) } else { Space::new() };
  drop(v127_7);
  let v127_9: Space = subtract(&(*CONSTANT_0),&(v127_8));
  drop(v127_8);
  let v127_14: Space = intersect(&(*CONSTANT_3),&(v127_6));
  drop(v127_6);
  let v127_15: Space = if has_head(&(v127_14)) { singleton(&[]) } else { Space::new() };
  drop(v127_14);
  let mut v127_16 = Space::new();
  let mut v127_16_write = v127_16.write_zipper();
  let mut v127_16_cursor = (*s0).read_zipper();
  let v127_16_origin = v127_16_cursor.path().len();
  for v127_16_byte in v127_16_cursor.child_mask().iter() {
    v127_16_cursor.descend_to_existing_byte(v127_16_byte);
    {
    let v128_4: Space = if (&(v127_9)).is_empty() { Space::new() } else {
      let v129_2: Path = concat_path(&(*p1),&v127_16_cursor.path()[v127_16_origin..(v127_16_origin + 1)]);
      let mut v129_3 = Space::new();
      let mut v129_3_write = v129_3.write_zipper();
      let v129_3_arg_0: &[u8] = &(*CONSTANT_1);
      let v129_3_arg_1: &[u8] = &(v129_2);
      let v129_3_arg_2: &[u8] = &(*p2);
      let v129_3_arg_4: &Space = &(&v127_16_cursor).make_map();
      let mut v129_3_cursor = descend_cursor((*CONSTANT_5).read_zipper(),&(*p0));
      let v129_3_origin = v129_3_cursor.path().len();
      let mut v129_3_more = v129_3_cursor.is_val() || next_value_within(&mut v129_3_cursor,v129_3_origin);
      while v129_3_more {
        {
        let v129_3_depth = v129_3_cursor.path().len();
        let v130_5: Space = routine_19(c, &v129_3_cursor.path()[v129_3_origin..v129_3_depth], &(*v129_3_arg_1), &(*v129_3_arg_2), &((*v129_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v129_3_write,&((v130_5).read_zipper()),&[]);
        }
        v129_3_more = next_value_within(&mut v129_3_cursor,v129_3_origin);
      }
      drop(v129_3_cursor);
      drop(v129_3_write);
      compose(&(v127_9),&(v129_3))
    };
    let v128_7: Space = if (&(v127_15)).is_empty() { Space::new() } else {
      let v131_2: Path = concat_path(&(*p1),&v127_16_cursor.path()[v127_16_origin..(v127_16_origin + 1)]);
      let v131_5: Path = concat_path(&(v131_2),&(*p2));
      drop(v131_2);
      let v131_6: Space = singleton(&(v131_5));
      drop(v131_5);
      compose(&(v127_15),&(v131_6))
    };
    let v128_8: Space = unite(&(v128_4),&(v128_7));
    drop(v128_7);
    join_wrapped_into(&mut v127_16_write,&((v128_8).read_zipper()),&[]);
    }
    v127_16_cursor.ascend(1);
  }
  drop(v127_16_cursor);
  drop(v127_16_write);
  drop(v127_9);
  drop(v127_15);
  (v127_16).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let v132_5: Space = singleton(&(*p0));
  let mut v132_771: Space = (v132_5).clone();
  loop {
    let v133_1: Space = intersect(&(v132_771),&(*s3));
    let v133_2: Space = restrict_to(&(*s1),&(v133_1));
    drop(v133_1);
    let v133_3: Space = drop_length_prefixes(&(v133_2));
    drop(v133_2);
    let v133_4: Space = unite(&(v133_3),&(v132_771));
    drop(v133_3);
    let v133_5: Space = intersect(&(v133_4),&(*s3));
    drop(v133_4);
    if !v132_771.join_into((v133_5).clone()).is_element() { break; }
  }
  let mut v132_1537: Space = (v132_5).clone();
  loop {
    let v134_1: Space = intersect(&(v132_1537),&(*s3));
    let v134_2: Space = restrict_to(&(*s2),&(v134_1));
    drop(v134_1);
    let v134_3: Space = drop_length_prefixes(&(v134_2));
    drop(v134_2);
    let v134_4: Space = unite(&(v134_3),&(v132_1537));
    drop(v134_3);
    let v134_5: Space = intersect(&(v134_4),&(*s3));
    drop(v134_4);
    if !v132_1537.join_into((v134_5).clone()).is_element() { break; }
  }
  let v132_1538: Space = intersect(&(v132_771),&(v132_1537));
  drop(v132_771);
  drop(v132_1537);
  let v132_1539: Space = subtract(&(v132_1538),&(v132_5));
  drop(v132_1538);
  let v132_1540: Space = wrap(&(v132_1539),&(*p0));
  drop(v132_1539);
  let mut v132_2306: Space = (v132_5).clone();
  loop {
    let v135_1: Space = intersect(&(v132_2306),&(*s3));
    let v135_2: Space = restrict_to(&(*s2),&(v135_1));
    drop(v135_1);
    let v135_3: Space = drop_length_prefixes(&(v135_2));
    drop(v135_2);
    let v135_4: Space = unite(&(v135_3),&(v132_2306));
    drop(v135_3);
    let v135_5: Space = intersect(&(v135_4),&(*s3));
    drop(v135_4);
    if !v132_2306.join_into((v135_5).clone()).is_element() { break; }
  }
  let v132_2307: Space = subtract(&(*s3),&(v132_2306));
  drop(v132_2306);
  let mut v132_3073: Space = (v132_5).clone();
  loop {
    let v136_1: Space = intersect(&(v132_3073),&(*s3));
    let v136_2: Space = restrict_to(&(*s1),&(v136_1));
    drop(v136_1);
    let v136_3: Space = drop_length_prefixes(&(v136_2));
    drop(v136_2);
    let v136_4: Space = unite(&(v136_3),&(v132_3073));
    drop(v136_3);
    let v136_5: Space = intersect(&(v136_4),&(*s3));
    drop(v136_4);
    if !v132_3073.join_into((v136_5).clone()).is_element() { break; }
  }
  let v132_3074: Space = subtract(&(v132_2307),&(v132_3073));
  drop(v132_2307);
  drop(v132_3073);
  let v132_3075: Space = routine_4(c, &((v132_3074).read_zipper()));
  drop(v132_3074);
  let mut v132_4606 = Space::new();
  let mut v132_4606_write = v132_4606.write_zipper();
  let mut v132_4606_cursor = (v132_3075).read_zipper();
  let v132_4606_origin = v132_4606_cursor.path().len();
  for v132_4606_byte in v132_4606_cursor.child_mask().iter() {
    v132_4606_cursor.descend_to_existing_byte(v132_4606_byte);
    {
    let mut v137_2: Space = (v132_5).clone();
    loop {
      let v138_1: Space = intersect(&(v137_2),&(*s3));
      let v138_2: Space = restrict_to(&(*s2),&(v138_1));
      drop(v138_1);
      let v138_3: Space = drop_length_prefixes(&(v138_2));
      drop(v138_2);
      let v138_4: Space = unite(&(v138_3),&(v137_2));
      drop(v138_3);
      let v138_5: Space = intersect(&(v138_4),&(*s3));
      drop(v138_4);
      if !v137_2.join_into((v138_5).clone()).is_element() { break; }
    }
    let v137_3: Space = subtract(&(*s3),&(v137_2));
    drop(v137_2);
    let mut v137_4: Space = (v132_5).clone();
    loop {
      let v139_1: Space = intersect(&(v137_4),&(*s3));
      let v139_2: Space = restrict_to(&(*s1),&(v139_1));
      drop(v139_1);
      let v139_3: Space = drop_length_prefixes(&(v139_2));
      drop(v139_2);
      let v139_4: Space = unite(&(v139_3),&(v137_4));
      drop(v139_3);
      let v139_5: Space = intersect(&(v139_4),&(*s3));
      drop(v139_4);
      if !v137_4.join_into((v139_5).clone()).is_element() { break; }
    }
    let v137_5: Space = subtract(&(v137_3),&(v137_4));
    drop(v137_3);
    drop(v137_4);
    let v137_6: Space = routine_6(c, &v132_4606_cursor.path()[v132_4606_origin..(v132_4606_origin + 1)], &v132_4606_cursor.path()[v132_4606_origin..(v132_4606_origin + 1)], &v132_4606_cursor, &(*s1), &(*s2), &((v137_5).read_zipper()));
    drop(v137_5);
    join_wrapped_into(&mut v132_4606_write,&((v137_6).read_zipper()),&[]);
    }
    v132_4606_cursor.ascend(1);
  }
  drop(v132_4606_cursor);
  drop(v132_4606_write);
  let v132_4607: Space = unite(&(v132_1540),&(v132_4606));
  drop(v132_1540);
  let mut v132_5373: Space = (v132_5).clone();
  loop {
    let v140_1: Space = intersect(&(v132_5373),&(*s3));
    let v140_2: Space = restrict_to(&(*s2),&(v140_1));
    drop(v140_1);
    let v140_3: Space = drop_length_prefixes(&(v140_2));
    drop(v140_2);
    let v140_4: Space = unite(&(v140_3),&(v132_5373));
    drop(v140_3);
    let v140_5: Space = intersect(&(v140_4),&(*s3));
    drop(v140_4);
    if !v132_5373.join_into((v140_5).clone()).is_element() { break; }
  }
  let mut v132_6139: Space = (v132_5).clone();
  loop {
    let v141_1: Space = intersect(&(v132_6139),&(*s3));
    let v141_2: Space = restrict_to(&(*s1),&(v141_1));
    drop(v141_1);
    let v141_3: Space = drop_length_prefixes(&(v141_2));
    drop(v141_2);
    let v141_4: Space = unite(&(v141_3),&(v132_6139));
    drop(v141_3);
    let v141_5: Space = intersect(&(v141_4),&(*s3));
    drop(v141_4);
    if !v132_6139.join_into((v141_5).clone()).is_element() { break; }
  }
  let v132_6140: Space = subtract(&(v132_5373),&(v132_6139));
  drop(v132_5373);
  drop(v132_6139);
  let v132_6141: Space = routine_4(c, &((v132_6140).read_zipper()));
  drop(v132_6140);
  let mut v132_7672 = Space::new();
  let mut v132_7672_write = v132_7672.write_zipper();
  let mut v132_7672_cursor = (v132_6141).read_zipper();
  let v132_7672_origin = v132_7672_cursor.path().len();
  for v132_7672_byte in v132_7672_cursor.child_mask().iter() {
    v132_7672_cursor.descend_to_existing_byte(v132_7672_byte);
    {
    let mut v142_2: Space = (v132_5).clone();
    loop {
      let v143_1: Space = intersect(&(v142_2),&(*s3));
      let v143_2: Space = restrict_to(&(*s2),&(v143_1));
      drop(v143_1);
      let v143_3: Space = drop_length_prefixes(&(v143_2));
      drop(v143_2);
      let v143_4: Space = unite(&(v143_3),&(v142_2));
      drop(v143_3);
      let v143_5: Space = intersect(&(v143_4),&(*s3));
      drop(v143_4);
      if !v142_2.join_into((v143_5).clone()).is_element() { break; }
    }
    let mut v142_3: Space = (v132_5).clone();
    loop {
      let v144_1: Space = intersect(&(v142_3),&(*s3));
      let v144_2: Space = restrict_to(&(*s1),&(v144_1));
      drop(v144_1);
      let v144_3: Space = drop_length_prefixes(&(v144_2));
      drop(v144_2);
      let v144_4: Space = unite(&(v144_3),&(v142_3));
      drop(v144_3);
      let v144_5: Space = intersect(&(v144_4),&(*s3));
      drop(v144_4);
      if !v142_3.join_into((v144_5).clone()).is_element() { break; }
    }
    let v142_4: Space = subtract(&(v142_2),&(v142_3));
    drop(v142_2);
    drop(v142_3);
    let v142_5: Space = routine_6(c, &v132_7672_cursor.path()[v132_7672_origin..(v132_7672_origin + 1)], &v132_7672_cursor.path()[v132_7672_origin..(v132_7672_origin + 1)], &v132_7672_cursor, &(*s1), &(*s2), &((v142_4).read_zipper()));
    drop(v142_4);
    join_wrapped_into(&mut v132_7672_write,&((v142_5).read_zipper()),&[]);
    }
    v132_7672_cursor.ascend(1);
  }
  drop(v132_7672_cursor);
  drop(v132_7672_write);
  let v132_7673: Space = unite(&(v132_4607),&(v132_7672));
  let mut v132_8439: Space = (v132_5).clone();
  loop {
    let v145_1: Space = intersect(&(v132_8439),&(*s3));
    let v145_2: Space = restrict_to(&(*s1),&(v145_1));
    drop(v145_1);
    let v145_3: Space = drop_length_prefixes(&(v145_2));
    drop(v145_2);
    let v145_4: Space = unite(&(v145_3),&(v132_8439));
    drop(v145_3);
    let v145_5: Space = intersect(&(v145_4),&(*s3));
    drop(v145_4);
    if !v132_8439.join_into((v145_5).clone()).is_element() { break; }
  }
  let mut v132_9205: Space = (v132_5).clone();
  loop {
    let v146_1: Space = intersect(&(v132_9205),&(*s3));
    let v146_2: Space = restrict_to(&(*s2),&(v146_1));
    drop(v146_1);
    let v146_3: Space = drop_length_prefixes(&(v146_2));
    drop(v146_2);
    let v146_4: Space = unite(&(v146_3),&(v132_9205));
    drop(v146_3);
    let v146_5: Space = intersect(&(v146_4),&(*s3));
    drop(v146_4);
    if !v132_9205.join_into((v146_5).clone()).is_element() { break; }
  }
  let v132_9206: Space = subtract(&(v132_8439),&(v132_9205));
  drop(v132_8439);
  drop(v132_9205);
  let v132_9207: Space = routine_4(c, &((v132_9206).read_zipper()));
  drop(v132_9206);
  let mut v132_10738 = Space::new();
  let mut v132_10738_write = v132_10738.write_zipper();
  let mut v132_10738_cursor = (v132_9207).read_zipper();
  let v132_10738_origin = v132_10738_cursor.path().len();
  for v132_10738_byte in v132_10738_cursor.child_mask().iter() {
    v132_10738_cursor.descend_to_existing_byte(v132_10738_byte);
    {
    let mut v147_2: Space = (v132_5).clone();
    loop {
      let v148_1: Space = intersect(&(v147_2),&(*s3));
      let v148_2: Space = restrict_to(&(*s1),&(v148_1));
      drop(v148_1);
      let v148_3: Space = drop_length_prefixes(&(v148_2));
      drop(v148_2);
      let v148_4: Space = unite(&(v148_3),&(v147_2));
      drop(v148_3);
      let v148_5: Space = intersect(&(v148_4),&(*s3));
      drop(v148_4);
      if !v147_2.join_into((v148_5).clone()).is_element() { break; }
    }
    let mut v147_3: Space = (v132_5).clone();
    loop {
      let v149_1: Space = intersect(&(v147_3),&(*s3));
      let v149_2: Space = restrict_to(&(*s2),&(v149_1));
      drop(v149_1);
      let v149_3: Space = drop_length_prefixes(&(v149_2));
      drop(v149_2);
      let v149_4: Space = unite(&(v149_3),&(v147_3));
      drop(v149_3);
      let v149_5: Space = intersect(&(v149_4),&(*s3));
      drop(v149_4);
      if !v147_3.join_into((v149_5).clone()).is_element() { break; }
    }
    let v147_4: Space = subtract(&(v147_2),&(v147_3));
    drop(v147_2);
    drop(v147_3);
    let v147_5: Space = routine_6(c, &v132_10738_cursor.path()[v132_10738_origin..(v132_10738_origin + 1)], &v132_10738_cursor.path()[v132_10738_origin..(v132_10738_origin + 1)], &v132_10738_cursor, &(*s1), &(*s2), &((v147_4).read_zipper()));
    drop(v147_4);
    join_wrapped_into(&mut v132_10738_write,&((v147_5).read_zipper()),&[]);
    }
    v132_10738_cursor.ascend(1);
  }
  drop(v132_10738_cursor);
  drop(v132_10738_write);
  drop(v132_5);
  let v132_10739: Space = unite(&(v132_7673),&(v132_10738));
  (v132_10739).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
