#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 1 1 1 0 0 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1]));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 1 1 0 1 1"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,1]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 1 0 0 1 1"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1,1]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 0 1 1 2 1 1"));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 2 1 1"));
static CONSTANT_10: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0]));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_13: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 10 0 0 0 1 1 1 0 0 1 1 8 0 0 1 1 1 0 1 1 7 0 1 1 0 0 1 1 5 0 1 1 1 1 8 1 0 1 1 0 0 1 1 5 1 1 0 1 1"));
static CONSTANT_14: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
#[inline(never)]
fn native_block_0(c: &mut Context) -> (Space,Space,Space,Space,Space,Space,) {
  let v0_22: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v1_19: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
      let v2_18: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v3_5: Space = routine_1(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
        let v3_8: Space = routine_2(c, &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
        let v3_9: Space = unite(&(v3_5),&(v3_8));
        let v3_12: Space = routine_2(c, &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
        let v3_13: Space = unite(&(v3_9),&(v3_12));
        let v3_16: Space = routine_3(c, &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
        let v3_17: Space = unite(&(v3_13),&(v3_16));
        compose(&(*CONSTANT_0),&(v3_17))
      };
      compose(&(*CONSTANT_0),&(v2_18))
    };
    let v1_21: Space = unite(&(v1_19),&(*CONSTANT_9));
    compose(&(*CONSTANT_0),&(v1_21))
  };
  let v0_44: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v4_43: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
      let v5_42: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v6_29: Space = routine_4(c, &(*CONSTANT_10), &(*CONSTANT_11), &((*CONSTANT_9).read_zipper()));
        let v6_31: Space = routine_5(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
        let v6_32: Space = unite(&(v6_29),&(v6_31));
        let v6_34: Space = routine_6(c, &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
        let v6_35: Space = unite(&(v6_32),&(v6_34));
        let v6_37: Space = routine_6(c, &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
        let v6_38: Space = unite(&(v6_35),&(v6_37));
        let v6_40: Space = routine_7(c, &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
        let v6_41: Space = unite(&(v6_38),&(v6_40));
        compose(&(*CONSTANT_0),&(v6_41))
      };
      compose(&(*CONSTANT_0),&(v5_42))
    };
    compose(&(*CONSTANT_0),&(v4_43))
  };
  let mut v0_63 = Space::new();
  let mut v0_63_write = v0_63.write_zipper();
  let mut v0_63_cursor = (v0_44).read_zipper();
  let v0_63_origin = v0_63_cursor.path().len();
  for v0_63_byte in v0_63_cursor.child_mask().iter() {
    v0_63_cursor.descend_to_existing_byte(v0_63_byte);
    {
    let v7_2: Space = singleton(&v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 1)]);
    let v7_3: Space = intersect(&(*CONSTANT_12),&(v7_2));
    let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
    drop(v7_3);
    let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
    drop(v7_4);
    let v7_7: Space = if (&(v7_5)).is_empty() { Space::new() } else {
      let mut v8_6 = Space::new();
      let mut v8_6_write = v8_6.write_zipper();
      for v8_6_byte in v0_63_cursor.child_mask().iter() {
        v0_63_cursor.descend_to_existing_byte(v8_6_byte);
        {
        let v9_2: Space = singleton(&v0_63_cursor.path()[(v0_63_origin + 1)..(v0_63_origin + 2)]);
        let v9_3: Space = intersect(&(*CONSTANT_12),&(v9_2));
        let v9_4: Space = if has_head(&(v9_3)) { singleton(&[]) } else { Space::new() };
        drop(v9_3);
        let v9_5: Space = subtract(&(*CONSTANT_0),&(v9_4));
        drop(v9_4);
        let v9_8: Space = if (&(v9_5)).is_empty() { Space::new() } else {
          let mut v10_7 = Space::new();
          let mut v10_7_write = v10_7.write_zipper();
          for v10_7_byte in v0_63_cursor.child_mask().iter() {
            v0_63_cursor.descend_to_existing_byte(v10_7_byte);
            {
            let v11_2: Space = singleton(&v0_63_cursor.path()[(v0_63_origin + 2)..(v0_63_origin + 3)]);
            let v11_3: Space = intersect(&(*CONSTANT_12),&(v11_2));
            let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
            drop(v11_3);
            let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
            drop(v11_4);
            let v11_8: Space = if (&(v11_5)).is_empty() { Space::new() } else {
              let v12_7: Space = routine_8(c, &v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 3)], &v0_63_cursor);
              compose(&(v11_5),&(v12_7))
            };
            drop(v11_5);
            let v11_9: Space = intersect(&(*CONSTANT_12),&(v11_2));
            drop(v11_2);
            let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
            drop(v11_9);
            let v11_12: Space = if (&(v11_10)).is_empty() { Space::new() } else {
              let v13_11: Space = routine_9(c, &v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 3)], &v0_63_cursor);
              compose(&(v11_10),&(v13_11))
            };
            drop(v11_10);
            let v11_13: Space = unite(&(v11_8),&(v11_12));
            join_wrapped_into(&mut v10_7_write,&((v11_13).read_zipper()),&[]);
            }
            v0_63_cursor.ascend(1);
          }
          drop(v10_7_write);
          compose(&(v9_5),&(v10_7))
        };
        drop(v9_5);
        let v9_9: Space = intersect(&(*CONSTANT_12),&(v9_2));
        drop(v9_2);
        let v9_10: Space = if has_head(&(v9_9)) { singleton(&[]) } else { Space::new() };
        drop(v9_9);
        let v9_12: Space = if (&(v9_10)).is_empty() { Space::new() } else {
          let mut v14_11 = Space::new();
          let mut v14_11_write = v14_11.write_zipper();
          for v14_11_byte in v0_63_cursor.child_mask().iter() {
            v0_63_cursor.descend_to_existing_byte(v14_11_byte);
            {
            let v15_2: Space = singleton(&v0_63_cursor.path()[(v0_63_origin + 2)..(v0_63_origin + 3)]);
            let v15_3: Space = intersect(&(*CONSTANT_12),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (&(v15_5)).is_empty() { Space::new() } else {
              let v16_7: Space = routine_8(c, &v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 3)], &v0_63_cursor);
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_12),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (&(v15_10)).is_empty() { Space::new() } else {
              let v17_11: Space = routine_10(c, &v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 3)], &v0_63_cursor);
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            join_wrapped_into(&mut v14_11_write,&((v15_13).read_zipper()),&[]);
            }
            v0_63_cursor.ascend(1);
          }
          drop(v14_11_write);
          compose(&(v9_10),&(v14_11))
        };
        drop(v9_10);
        let v9_13: Space = unite(&(v9_8),&(v9_12));
        join_wrapped_into(&mut v8_6_write,&((v9_13).read_zipper()),&[]);
        }
        v0_63_cursor.ascend(1);
      }
      drop(v8_6_write);
      compose(&(v7_5),&(v8_6))
    };
    drop(v7_5);
    let v7_8: Space = intersect(&(*CONSTANT_12),&(v7_2));
    drop(v7_2);
    let v7_9: Space = if has_head(&(v7_8)) { singleton(&[]) } else { Space::new() };
    drop(v7_8);
    let v7_11: Space = if (&(v7_9)).is_empty() { Space::new() } else {
      let mut v18_10 = Space::new();
      let mut v18_10_write = v18_10.write_zipper();
      for v18_10_byte in v0_63_cursor.child_mask().iter() {
        v0_63_cursor.descend_to_existing_byte(v18_10_byte);
        {
        let v19_2: Space = singleton(&v0_63_cursor.path()[(v0_63_origin + 1)..(v0_63_origin + 2)]);
        let v19_3: Space = intersect(&(*CONSTANT_12),&(v19_2));
        let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
        drop(v19_3);
        let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
        drop(v19_4);
        let v19_8: Space = if (&(v19_5)).is_empty() { Space::new() } else {
          let mut v20_7 = Space::new();
          let mut v20_7_write = v20_7.write_zipper();
          for v20_7_byte in v0_63_cursor.child_mask().iter() {
            v0_63_cursor.descend_to_existing_byte(v20_7_byte);
            {
            let v21_2: Space = singleton(&v0_63_cursor.path()[(v0_63_origin + 2)..(v0_63_origin + 3)]);
            let v21_3: Space = intersect(&(*CONSTANT_12),&(v21_2));
            let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
            drop(v21_3);
            let v21_5: Space = subtract(&(*CONSTANT_0),&(v21_4));
            drop(v21_4);
            let v21_8: Space = if (&(v21_5)).is_empty() { Space::new() } else {
              let v22_7: Space = routine_8(c, &v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 3)], &v0_63_cursor);
              compose(&(v21_5),&(v22_7))
            };
            drop(v21_5);
            let v21_9: Space = intersect(&(*CONSTANT_12),&(v21_2));
            drop(v21_2);
            let v21_10: Space = if has_head(&(v21_9)) { singleton(&[]) } else { Space::new() };
            drop(v21_9);
            let v21_12: Space = if (&(v21_10)).is_empty() { Space::new() } else {
              let v23_11: Space = routine_9(c, &v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 3)], &v0_63_cursor);
              compose(&(v21_10),&(v23_11))
            };
            drop(v21_10);
            let v21_13: Space = unite(&(v21_8),&(v21_12));
            join_wrapped_into(&mut v20_7_write,&((v21_13).read_zipper()),&[]);
            }
            v0_63_cursor.ascend(1);
          }
          drop(v20_7_write);
          compose(&(v19_5),&(v20_7))
        };
        drop(v19_5);
        let v19_9: Space = intersect(&(*CONSTANT_12),&(v19_2));
        drop(v19_2);
        let v19_10: Space = if has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
        drop(v19_9);
        let v19_12: Space = if (&(v19_10)).is_empty() { Space::new() } else {
          let v24_11: Space = singleton(&v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 2)]);
          compose(&(v19_10),&(v24_11))
        };
        drop(v19_10);
        let v19_13: Space = unite(&(v19_8),&(v19_12));
        drop(v19_12);
        join_wrapped_into(&mut v18_10_write,&((v19_13).read_zipper()),&[]);
        }
        v0_63_cursor.ascend(1);
      }
      drop(v18_10_write);
      compose(&(v7_9),&(v18_10))
    };
    drop(v7_9);
    let v7_12: Space = unite(&(v7_7),&(v7_11));
    join_wrapped_into(&mut v0_63_write,&((v7_12).read_zipper()),&[]);
    }
    v0_63_cursor.ascend(1);
  }
  drop(v0_63_cursor);
  drop(v0_63_write);
  let v0_64: Space = unite(&(v0_22),&(v0_63));
  let v0_65: Space = routine_11(c, &((v0_64).read_zipper()));
  let mut v0_155 = Space::new();
  let mut v0_155_write = v0_155.write_zipper();
  let mut v0_155_cursor = (v0_65).read_zipper();
  let v0_155_origin = v0_155_cursor.path().len();
  for v0_155_byte in v0_155_cursor.child_mask().iter() {
    v0_155_cursor.descend_to_existing_byte(v0_155_byte);
    {
    let v25_2: Space = singleton(&v0_155_cursor.path()[v0_155_origin..(v0_155_origin + 1)]);
    let v25_3: Space = intersect(&(*CONSTANT_12),&(v25_2));
    let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
    drop(v25_3);
    let v25_5: Space = subtract(&(*CONSTANT_0),&(v25_4));
    drop(v25_4);
    let v25_44: Space = if (&(v25_5)).is_empty() { Space::new() } else {
      let v26_17: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v27_16: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
          let v28_15: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
            let v29_6: Space = routine_12(c, &(*CONSTANT_10), &(*CONSTANT_11), &((*CONSTANT_9).read_zipper()));
            let v29_7: Space = routine_13(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
            let v29_8: Space = unite(&(v29_6),&(v29_7));
            let v29_9: Space = routine_14(c, &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
            let v29_10: Space = unite(&(v29_8),&(v29_9));
            let v29_11: Space = routine_14(c, &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
            let v29_12: Space = unite(&(v29_10),&(v29_11));
            let v29_13: Space = routine_15(c, &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
            let v29_14: Space = unite(&(v29_12),&(v29_13));
            compose(&(*CONSTANT_0),&(v29_14))
          };
          compose(&(*CONSTANT_0),&(v28_15))
        };
        compose(&(*CONSTANT_0),&(v27_16))
      };
      let v26_28: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v30_26: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
          let v31_25: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
            let v32_18: Space = routine_1(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
            let v32_19: Space = routine_2(c, &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
            let v32_20: Space = unite(&(v32_18),&(v32_19));
            let v32_21: Space = routine_2(c, &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
            let v32_22: Space = unite(&(v32_20),&(v32_21));
            let v32_23: Space = routine_3(c, &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
            let v32_24: Space = unite(&(v32_22),&(v32_23));
            compose(&(*CONSTANT_0),&(v32_24))
          };
          compose(&(*CONSTANT_0),&(v31_25))
        };
        let v30_27: Space = unite(&(v30_26),&(*CONSTANT_9));
        compose(&(*CONSTANT_0),&(v30_27))
      };
      let v26_40: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v33_39: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
          let v34_38: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
            let v35_29: Space = routine_4(c, &(*CONSTANT_10), &(*CONSTANT_11), &((*CONSTANT_9).read_zipper()));
            let v35_30: Space = routine_5(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
            let v35_31: Space = unite(&(v35_29),&(v35_30));
            let v35_32: Space = routine_6(c, &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
            let v35_33: Space = unite(&(v35_31),&(v35_32));
            let v35_34: Space = routine_6(c, &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
            let v35_35: Space = unite(&(v35_33),&(v35_34));
            let v35_36: Space = routine_7(c, &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
            let v35_37: Space = unite(&(v35_35),&(v35_36));
            compose(&(*CONSTANT_0),&(v35_37))
          };
          compose(&(*CONSTANT_0),&(v34_38))
        };
        compose(&(*CONSTANT_0),&(v33_39))
      };
      let mut v26_41 = Space::new();
      let mut v26_41_write = v26_41.write_zipper();
      let mut v26_41_cursor = (v26_40).read_zipper();
      let v26_41_origin = v26_41_cursor.path().len();
      for v26_41_byte in v26_41_cursor.child_mask().iter() {
        v26_41_cursor.descend_to_existing_byte(v26_41_byte);
        {
        let v36_2: Space = singleton(&v26_41_cursor.path()[v26_41_origin..(v26_41_origin + 1)]);
        let v36_3: Space = intersect(&(*CONSTANT_12),&(v36_2));
        let v36_4: Space = if has_head(&(v36_3)) { singleton(&[]) } else { Space::new() };
        drop(v36_3);
        let v36_5: Space = subtract(&(*CONSTANT_0),&(v36_4));
        drop(v36_4);
        let v36_7: Space = if (&(v36_5)).is_empty() { Space::new() } else {
          let mut v37_6 = Space::new();
          let mut v37_6_write = v37_6.write_zipper();
          for v37_6_byte in v26_41_cursor.child_mask().iter() {
            v26_41_cursor.descend_to_existing_byte(v37_6_byte);
            {
            let v38_2: Space = singleton(&v26_41_cursor.path()[(v26_41_origin + 1)..(v26_41_origin + 2)]);
            let v38_3: Space = intersect(&(*CONSTANT_12),&(v38_2));
            let v38_4: Space = if has_head(&(v38_3)) { singleton(&[]) } else { Space::new() };
            drop(v38_3);
            let v38_5: Space = subtract(&(*CONSTANT_0),&(v38_4));
            drop(v38_4);
            let v38_8: Space = if (&(v38_5)).is_empty() { Space::new() } else {
              let mut v39_7 = Space::new();
              let mut v39_7_write = v39_7.write_zipper();
              for v39_7_byte in v26_41_cursor.child_mask().iter() {
                v26_41_cursor.descend_to_existing_byte(v39_7_byte);
                {
                let v40_2: Space = singleton(&v26_41_cursor.path()[(v26_41_origin + 2)..(v26_41_origin + 3)]);
                let v40_3: Space = intersect(&(*CONSTANT_12),&(v40_2));
                let v40_4: Space = if has_head(&(v40_3)) { singleton(&[]) } else { Space::new() };
                drop(v40_3);
                let v40_5: Space = subtract(&(*CONSTANT_0),&(v40_4));
                drop(v40_4);
                let v40_8: Space = if (&(v40_5)).is_empty() { Space::new() } else {
                  let v41_7: Space = routine_8(c, &v26_41_cursor.path()[v26_41_origin..(v26_41_origin + 3)], &v26_41_cursor);
                  compose(&(v40_5),&(v41_7))
                };
                drop(v40_5);
                let v40_9: Space = intersect(&(*CONSTANT_12),&(v40_2));
                drop(v40_2);
                let v40_10: Space = if has_head(&(v40_9)) { singleton(&[]) } else { Space::new() };
                drop(v40_9);
                let v40_12: Space = if (&(v40_10)).is_empty() { Space::new() } else {
                  let v42_11: Space = routine_9(c, &v26_41_cursor.path()[v26_41_origin..(v26_41_origin + 3)], &v26_41_cursor);
                  compose(&(v40_10),&(v42_11))
                };
                drop(v40_10);
                let v40_13: Space = unite(&(v40_8),&(v40_12));
                join_wrapped_into(&mut v39_7_write,&((v40_13).read_zipper()),&[]);
                }
                v26_41_cursor.ascend(1);
              }
              drop(v39_7_write);
              compose(&(v38_5),&(v39_7))
            };
            drop(v38_5);
            let v38_9: Space = intersect(&(*CONSTANT_12),&(v38_2));
            drop(v38_2);
            let v38_10: Space = if has_head(&(v38_9)) { singleton(&[]) } else { Space::new() };
            drop(v38_9);
            let v38_12: Space = if (&(v38_10)).is_empty() { Space::new() } else {
              let mut v43_11 = Space::new();
              let mut v43_11_write = v43_11.write_zipper();
              for v43_11_byte in v26_41_cursor.child_mask().iter() {
                v26_41_cursor.descend_to_existing_byte(v43_11_byte);
                {
                let v44_2: Space = singleton(&v26_41_cursor.path()[(v26_41_origin + 2)..(v26_41_origin + 3)]);
                let v44_3: Space = intersect(&(*CONSTANT_12),&(v44_2));
                let v44_4: Space = if has_head(&(v44_3)) { singleton(&[]) } else { Space::new() };
                drop(v44_3);
                let v44_5: Space = subtract(&(*CONSTANT_0),&(v44_4));
                drop(v44_4);
                let v44_8: Space = if (&(v44_5)).is_empty() { Space::new() } else {
                  let v45_7: Space = routine_8(c, &v26_41_cursor.path()[v26_41_origin..(v26_41_origin + 3)], &v26_41_cursor);
                  compose(&(v44_5),&(v45_7))
                };
                drop(v44_5);
                let v44_9: Space = intersect(&(*CONSTANT_12),&(v44_2));
                drop(v44_2);
                let v44_10: Space = if has_head(&(v44_9)) { singleton(&[]) } else { Space::new() };
                drop(v44_9);
                let v44_12: Space = if (&(v44_10)).is_empty() { Space::new() } else {
                  let v46_11: Space = routine_10(c, &v26_41_cursor.path()[v26_41_origin..(v26_41_origin + 3)], &v26_41_cursor);
                  compose(&(v44_10),&(v46_11))
                };
                drop(v44_10);
                let v44_13: Space = unite(&(v44_8),&(v44_12));
                join_wrapped_into(&mut v43_11_write,&((v44_13).read_zipper()),&[]);
                }
                v26_41_cursor.ascend(1);
              }
              drop(v43_11_write);
              compose(&(v38_10),&(v43_11))
            };
            drop(v38_10);
            let v38_13: Space = unite(&(v38_8),&(v38_12));
            join_wrapped_into(&mut v37_6_write,&((v38_13).read_zipper()),&[]);
            }
            v26_41_cursor.ascend(1);
          }
          drop(v37_6_write);
          compose(&(v36_5),&(v37_6))
        };
        drop(v36_5);
        let v36_8: Space = intersect(&(*CONSTANT_12),&(v36_2));
        drop(v36_2);
        let v36_9: Space = if has_head(&(v36_8)) { singleton(&[]) } else { Space::new() };
        drop(v36_8);
        let v36_11: Space = if (&(v36_9)).is_empty() { Space::new() } else {
          let mut v47_10 = Space::new();
          let mut v47_10_write = v47_10.write_zipper();
          for v47_10_byte in v26_41_cursor.child_mask().iter() {
            v26_41_cursor.descend_to_existing_byte(v47_10_byte);
            {
            let v48_2: Space = singleton(&v26_41_cursor.path()[(v26_41_origin + 1)..(v26_41_origin + 2)]);
            let v48_3: Space = intersect(&(*CONSTANT_12),&(v48_2));
            let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
            drop(v48_3);
            let v48_5: Space = subtract(&(*CONSTANT_0),&(v48_4));
            drop(v48_4);
            let v48_8: Space = if (&(v48_5)).is_empty() { Space::new() } else {
              let mut v49_7 = Space::new();
              let mut v49_7_write = v49_7.write_zipper();
              for v49_7_byte in v26_41_cursor.child_mask().iter() {
                v26_41_cursor.descend_to_existing_byte(v49_7_byte);
                {
                let v50_2: Space = singleton(&v26_41_cursor.path()[(v26_41_origin + 2)..(v26_41_origin + 3)]);
                let v50_3: Space = intersect(&(*CONSTANT_12),&(v50_2));
                let v50_4: Space = if has_head(&(v50_3)) { singleton(&[]) } else { Space::new() };
                drop(v50_3);
                let v50_5: Space = subtract(&(*CONSTANT_0),&(v50_4));
                drop(v50_4);
                let v50_8: Space = if (&(v50_5)).is_empty() { Space::new() } else {
                  let v51_7: Space = routine_8(c, &v26_41_cursor.path()[v26_41_origin..(v26_41_origin + 3)], &v26_41_cursor);
                  compose(&(v50_5),&(v51_7))
                };
                drop(v50_5);
                let v50_9: Space = intersect(&(*CONSTANT_12),&(v50_2));
                drop(v50_2);
                let v50_10: Space = if has_head(&(v50_9)) { singleton(&[]) } else { Space::new() };
                drop(v50_9);
                let v50_12: Space = if (&(v50_10)).is_empty() { Space::new() } else {
                  let v52_11: Space = routine_9(c, &v26_41_cursor.path()[v26_41_origin..(v26_41_origin + 3)], &v26_41_cursor);
                  compose(&(v50_10),&(v52_11))
                };
                drop(v50_10);
                let v50_13: Space = unite(&(v50_8),&(v50_12));
                join_wrapped_into(&mut v49_7_write,&((v50_13).read_zipper()),&[]);
                }
                v26_41_cursor.ascend(1);
              }
              drop(v49_7_write);
              compose(&(v48_5),&(v49_7))
            };
            drop(v48_5);
            let v48_9: Space = intersect(&(*CONSTANT_12),&(v48_2));
            drop(v48_2);
            let v48_10: Space = if has_head(&(v48_9)) { singleton(&[]) } else { Space::new() };
            drop(v48_9);
            let v48_12: Space = if (&(v48_10)).is_empty() { Space::new() } else {
              let v53_11: Space = singleton(&v26_41_cursor.path()[v26_41_origin..(v26_41_origin + 2)]);
              compose(&(v48_10),&(v53_11))
            };
            drop(v48_10);
            let v48_13: Space = unite(&(v48_8),&(v48_12));
            drop(v48_12);
            join_wrapped_into(&mut v47_10_write,&((v48_13).read_zipper()),&[]);
            }
            v26_41_cursor.ascend(1);
          }
          drop(v47_10_write);
          compose(&(v36_9),&(v47_10))
        };
        drop(v36_9);
        let v36_12: Space = unite(&(v36_7),&(v36_11));
        join_wrapped_into(&mut v26_41_write,&((v36_12).read_zipper()),&[]);
        }
        v26_41_cursor.ascend(1);
      }
      drop(v26_41_cursor);
      drop(v26_41_write);
      let v26_42: Space = unite(&(v26_28),&(v26_41));
      let v26_43: Space = routine_16(c, &v0_155_cursor.path()[v0_155_origin..(v0_155_origin + 1)], &v0_155_cursor, &((v26_17).read_zipper()), &((*CONSTANT_13).read_zipper()), &((v26_42).read_zipper()));
      compose(&(v25_5),&(v26_43))
    };
    drop(v25_5);
    let v25_45: Space = intersect(&(*CONSTANT_12),&(v25_2));
    drop(v25_2);
    let v25_46: Space = if has_head(&(v25_45)) { singleton(&[]) } else { Space::new() };
    drop(v25_45);
    let v25_85: Space = if (&(v25_46)).is_empty() { Space::new() } else {
      let v54_58: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v55_57: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
          let v56_56: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
            let v57_47: Space = routine_12(c, &(*CONSTANT_10), &(*CONSTANT_11), &((*CONSTANT_9).read_zipper()));
            let v57_48: Space = routine_13(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
            let v57_49: Space = unite(&(v57_47),&(v57_48));
            let v57_50: Space = routine_14(c, &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
            let v57_51: Space = unite(&(v57_49),&(v57_50));
            let v57_52: Space = routine_14(c, &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
            let v57_53: Space = unite(&(v57_51),&(v57_52));
            let v57_54: Space = routine_15(c, &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
            let v57_55: Space = unite(&(v57_53),&(v57_54));
            compose(&(*CONSTANT_0),&(v57_55))
          };
          compose(&(*CONSTANT_0),&(v56_56))
        };
        compose(&(*CONSTANT_0),&(v55_57))
      };
      let v54_69: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v58_67: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
          let v59_66: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
            let v60_59: Space = routine_1(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
            let v60_60: Space = routine_2(c, &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
            let v60_61: Space = unite(&(v60_59),&(v60_60));
            let v60_62: Space = routine_2(c, &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
            let v60_63: Space = unite(&(v60_61),&(v60_62));
            let v60_64: Space = routine_3(c, &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
            let v60_65: Space = unite(&(v60_63),&(v60_64));
            compose(&(*CONSTANT_0),&(v60_65))
          };
          compose(&(*CONSTANT_0),&(v59_66))
        };
        let v58_68: Space = unite(&(v58_67),&(*CONSTANT_9));
        compose(&(*CONSTANT_0),&(v58_68))
      };
      let v54_81: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v61_80: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
          let v62_79: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
            let v63_70: Space = routine_4(c, &(*CONSTANT_10), &(*CONSTANT_11), &((*CONSTANT_9).read_zipper()));
            let v63_71: Space = routine_5(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
            let v63_72: Space = unite(&(v63_70),&(v63_71));
            let v63_73: Space = routine_6(c, &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
            let v63_74: Space = unite(&(v63_72),&(v63_73));
            let v63_75: Space = routine_6(c, &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
            let v63_76: Space = unite(&(v63_74),&(v63_75));
            let v63_77: Space = routine_7(c, &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
            let v63_78: Space = unite(&(v63_76),&(v63_77));
            compose(&(*CONSTANT_0),&(v63_78))
          };
          compose(&(*CONSTANT_0),&(v62_79))
        };
        compose(&(*CONSTANT_0),&(v61_80))
      };
      let mut v54_82 = Space::new();
      let mut v54_82_write = v54_82.write_zipper();
      let mut v54_82_cursor = (v54_81).read_zipper();
      let v54_82_origin = v54_82_cursor.path().len();
      for v54_82_byte in v54_82_cursor.child_mask().iter() {
        v54_82_cursor.descend_to_existing_byte(v54_82_byte);
        {
        let v64_2: Space = singleton(&v54_82_cursor.path()[v54_82_origin..(v54_82_origin + 1)]);
        let v64_3: Space = intersect(&(*CONSTANT_12),&(v64_2));
        let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
        drop(v64_3);
        let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
        drop(v64_4);
        let v64_7: Space = if (&(v64_5)).is_empty() { Space::new() } else {
          let mut v65_6 = Space::new();
          let mut v65_6_write = v65_6.write_zipper();
          for v65_6_byte in v54_82_cursor.child_mask().iter() {
            v54_82_cursor.descend_to_existing_byte(v65_6_byte);
            {
            let v66_2: Space = singleton(&v54_82_cursor.path()[(v54_82_origin + 1)..(v54_82_origin + 2)]);
            let v66_3: Space = intersect(&(*CONSTANT_12),&(v66_2));
            let v66_4: Space = if has_head(&(v66_3)) { singleton(&[]) } else { Space::new() };
            drop(v66_3);
            let v66_5: Space = subtract(&(*CONSTANT_0),&(v66_4));
            drop(v66_4);
            let v66_8: Space = if (&(v66_5)).is_empty() { Space::new() } else {
              let mut v67_7 = Space::new();
              let mut v67_7_write = v67_7.write_zipper();
              for v67_7_byte in v54_82_cursor.child_mask().iter() {
                v54_82_cursor.descend_to_existing_byte(v67_7_byte);
                {
                let v68_2: Space = singleton(&v54_82_cursor.path()[(v54_82_origin + 2)..(v54_82_origin + 3)]);
                let v68_3: Space = intersect(&(*CONSTANT_12),&(v68_2));
                let v68_4: Space = if has_head(&(v68_3)) { singleton(&[]) } else { Space::new() };
                drop(v68_3);
                let v68_5: Space = subtract(&(*CONSTANT_0),&(v68_4));
                drop(v68_4);
                let v68_8: Space = if (&(v68_5)).is_empty() { Space::new() } else {
                  let v69_7: Space = routine_8(c, &v54_82_cursor.path()[v54_82_origin..(v54_82_origin + 3)], &v54_82_cursor);
                  compose(&(v68_5),&(v69_7))
                };
                drop(v68_5);
                let v68_9: Space = intersect(&(*CONSTANT_12),&(v68_2));
                drop(v68_2);
                let v68_10: Space = if has_head(&(v68_9)) { singleton(&[]) } else { Space::new() };
                drop(v68_9);
                let v68_12: Space = if (&(v68_10)).is_empty() { Space::new() } else {
                  let v70_11: Space = routine_9(c, &v54_82_cursor.path()[v54_82_origin..(v54_82_origin + 3)], &v54_82_cursor);
                  compose(&(v68_10),&(v70_11))
                };
                drop(v68_10);
                let v68_13: Space = unite(&(v68_8),&(v68_12));
                join_wrapped_into(&mut v67_7_write,&((v68_13).read_zipper()),&[]);
                }
                v54_82_cursor.ascend(1);
              }
              drop(v67_7_write);
              compose(&(v66_5),&(v67_7))
            };
            drop(v66_5);
            let v66_9: Space = intersect(&(*CONSTANT_12),&(v66_2));
            drop(v66_2);
            let v66_10: Space = if has_head(&(v66_9)) { singleton(&[]) } else { Space::new() };
            drop(v66_9);
            let v66_12: Space = if (&(v66_10)).is_empty() { Space::new() } else {
              let mut v71_11 = Space::new();
              let mut v71_11_write = v71_11.write_zipper();
              for v71_11_byte in v54_82_cursor.child_mask().iter() {
                v54_82_cursor.descend_to_existing_byte(v71_11_byte);
                {
                let v72_2: Space = singleton(&v54_82_cursor.path()[(v54_82_origin + 2)..(v54_82_origin + 3)]);
                let v72_3: Space = intersect(&(*CONSTANT_12),&(v72_2));
                let v72_4: Space = if has_head(&(v72_3)) { singleton(&[]) } else { Space::new() };
                drop(v72_3);
                let v72_5: Space = subtract(&(*CONSTANT_0),&(v72_4));
                drop(v72_4);
                let v72_8: Space = if (&(v72_5)).is_empty() { Space::new() } else {
                  let v73_7: Space = routine_8(c, &v54_82_cursor.path()[v54_82_origin..(v54_82_origin + 3)], &v54_82_cursor);
                  compose(&(v72_5),&(v73_7))
                };
                drop(v72_5);
                let v72_9: Space = intersect(&(*CONSTANT_12),&(v72_2));
                drop(v72_2);
                let v72_10: Space = if has_head(&(v72_9)) { singleton(&[]) } else { Space::new() };
                drop(v72_9);
                let v72_12: Space = if (&(v72_10)).is_empty() { Space::new() } else {
                  let v74_11: Space = routine_10(c, &v54_82_cursor.path()[v54_82_origin..(v54_82_origin + 3)], &v54_82_cursor);
                  compose(&(v72_10),&(v74_11))
                };
                drop(v72_10);
                let v72_13: Space = unite(&(v72_8),&(v72_12));
                join_wrapped_into(&mut v71_11_write,&((v72_13).read_zipper()),&[]);
                }
                v54_82_cursor.ascend(1);
              }
              drop(v71_11_write);
              compose(&(v66_10),&(v71_11))
            };
            drop(v66_10);
            let v66_13: Space = unite(&(v66_8),&(v66_12));
            join_wrapped_into(&mut v65_6_write,&((v66_13).read_zipper()),&[]);
            }
            v54_82_cursor.ascend(1);
          }
          drop(v65_6_write);
          compose(&(v64_5),&(v65_6))
        };
        drop(v64_5);
        let v64_8: Space = intersect(&(*CONSTANT_12),&(v64_2));
        drop(v64_2);
        let v64_9: Space = if has_head(&(v64_8)) { singleton(&[]) } else { Space::new() };
        drop(v64_8);
        let v64_11: Space = if (&(v64_9)).is_empty() { Space::new() } else {
          let mut v75_10 = Space::new();
          let mut v75_10_write = v75_10.write_zipper();
          for v75_10_byte in v54_82_cursor.child_mask().iter() {
            v54_82_cursor.descend_to_existing_byte(v75_10_byte);
            {
            let v76_2: Space = singleton(&v54_82_cursor.path()[(v54_82_origin + 1)..(v54_82_origin + 2)]);
            let v76_3: Space = intersect(&(*CONSTANT_12),&(v76_2));
            let v76_4: Space = if has_head(&(v76_3)) { singleton(&[]) } else { Space::new() };
            drop(v76_3);
            let v76_5: Space = subtract(&(*CONSTANT_0),&(v76_4));
            drop(v76_4);
            let v76_8: Space = if (&(v76_5)).is_empty() { Space::new() } else {
              let mut v77_7 = Space::new();
              let mut v77_7_write = v77_7.write_zipper();
              for v77_7_byte in v54_82_cursor.child_mask().iter() {
                v54_82_cursor.descend_to_existing_byte(v77_7_byte);
                {
                let v78_2: Space = singleton(&v54_82_cursor.path()[(v54_82_origin + 2)..(v54_82_origin + 3)]);
                let v78_3: Space = intersect(&(*CONSTANT_12),&(v78_2));
                let v78_4: Space = if has_head(&(v78_3)) { singleton(&[]) } else { Space::new() };
                drop(v78_3);
                let v78_5: Space = subtract(&(*CONSTANT_0),&(v78_4));
                drop(v78_4);
                let v78_8: Space = if (&(v78_5)).is_empty() { Space::new() } else {
                  let v79_7: Space = routine_8(c, &v54_82_cursor.path()[v54_82_origin..(v54_82_origin + 3)], &v54_82_cursor);
                  compose(&(v78_5),&(v79_7))
                };
                drop(v78_5);
                let v78_9: Space = intersect(&(*CONSTANT_12),&(v78_2));
                drop(v78_2);
                let v78_10: Space = if has_head(&(v78_9)) { singleton(&[]) } else { Space::new() };
                drop(v78_9);
                let v78_12: Space = if (&(v78_10)).is_empty() { Space::new() } else {
                  let v80_11: Space = routine_9(c, &v54_82_cursor.path()[v54_82_origin..(v54_82_origin + 3)], &v54_82_cursor);
                  compose(&(v78_10),&(v80_11))
                };
                drop(v78_10);
                let v78_13: Space = unite(&(v78_8),&(v78_12));
                join_wrapped_into(&mut v77_7_write,&((v78_13).read_zipper()),&[]);
                }
                v54_82_cursor.ascend(1);
              }
              drop(v77_7_write);
              compose(&(v76_5),&(v77_7))
            };
            drop(v76_5);
            let v76_9: Space = intersect(&(*CONSTANT_12),&(v76_2));
            drop(v76_2);
            let v76_10: Space = if has_head(&(v76_9)) { singleton(&[]) } else { Space::new() };
            drop(v76_9);
            let v76_12: Space = if (&(v76_10)).is_empty() { Space::new() } else {
              let v81_11: Space = singleton(&v54_82_cursor.path()[v54_82_origin..(v54_82_origin + 2)]);
              compose(&(v76_10),&(v81_11))
            };
            drop(v76_10);
            let v76_13: Space = unite(&(v76_8),&(v76_12));
            drop(v76_12);
            join_wrapped_into(&mut v75_10_write,&((v76_13).read_zipper()),&[]);
            }
            v54_82_cursor.ascend(1);
          }
          drop(v75_10_write);
          compose(&(v64_9),&(v75_10))
        };
        drop(v64_9);
        let v64_12: Space = unite(&(v64_7),&(v64_11));
        join_wrapped_into(&mut v54_82_write,&((v64_12).read_zipper()),&[]);
        }
        v54_82_cursor.ascend(1);
      }
      drop(v54_82_cursor);
      drop(v54_82_write);
      let v54_83: Space = unite(&(v54_69),&(v54_82));
      let v54_84: Space = routine_17(c, &v0_155_cursor.path()[v0_155_origin..(v0_155_origin + 1)], &v0_155_cursor, &((v54_58).read_zipper()), &((*CONSTANT_13).read_zipper()), &((v54_83).read_zipper()));
      compose(&(v25_46),&(v54_84))
    };
    drop(v25_46);
    let v25_86: Space = unite(&(v25_44),&(v25_85));
    join_wrapped_into(&mut v0_155_write,&((v25_86).read_zipper()),&[]);
    }
    v0_155_cursor.ascend(1);
  }
  drop(v0_155_cursor);
  drop(v0_155_write);

((v0_155).clone(),(v0_22).clone(),(v0_44).clone(),(v0_63).clone(),(v0_64).clone(),(v0_65).clone(),)
}

#[inline(never)]
fn native_block_1(c: &mut Context,capture_0: &[u8],capture_1: &View<'_, '_>,capture_2: &View<'_, '_>,capture_3: &View<'_, '_>) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v378_5: Space = singleton(&(*capture_0));
  let mut v378_24: Space = (v378_5).clone();
  loop {
    let v379_1: Space = intersect(&(v378_24),&(*capture_3));
    let v379_2: Space = restrict_to(&(*capture_1),&(v379_1));
    drop(v379_1);
    let mut v379_3 = Space::new();
    let mut v379_3_write = v379_3.write_zipper();
    let mut v379_3_cursor = (v379_2).read_zipper();
    let v379_3_origin = v379_3_cursor.path().len();
    for v379_3_byte in v379_3_cursor.child_mask().iter() {
      v379_3_cursor.descend_to_existing_byte(v379_3_byte);
      {
      let v380_2: Space = singleton(&v379_3_cursor.path()[v379_3_origin..(v379_3_origin + 1)]);
      let v380_3: Space = intersect(&(*CONSTANT_12),&(v380_2));
      let v380_4: Space = if has_head(&(v380_3)) { singleton(&[]) } else { Space::new() };
      drop(v380_3);
      let v380_5: Space = subtract(&(*CONSTANT_0),&(v380_4));
      drop(v380_4);
      let v380_7: Space = if (&(v380_5)).is_empty() { Space::new() } else {
        let mut v381_6 = Space::new();
        let mut v381_6_write = v381_6.write_zipper();
        for v381_6_byte in v379_3_cursor.child_mask().iter() {
          v379_3_cursor.descend_to_existing_byte(v381_6_byte);
          {
          let v382_2: Space = singleton(&v379_3_cursor.path()[(v379_3_origin + 1)..(v379_3_origin + 2)]);
          let v382_3: Space = intersect(&(*CONSTANT_12),&(v382_2));
          let v382_4: Space = if has_head(&(v382_3)) { singleton(&[]) } else { Space::new() };
          drop(v382_3);
          let v382_5: Space = subtract(&(*CONSTANT_0),&(v382_4));
          drop(v382_4);
          let v382_8: Space = if (&(v382_5)).is_empty() { Space::new() } else {
            let mut v383_7 = Space::new();
            let mut v383_7_write = v383_7.write_zipper();
            for v383_7_byte in v379_3_cursor.child_mask().iter() {
              v379_3_cursor.descend_to_existing_byte(v383_7_byte);
              {
              let v384_2: Space = singleton(&v379_3_cursor.path()[(v379_3_origin + 2)..(v379_3_origin + 3)]);
              let v384_3: Space = intersect(&(*CONSTANT_12),&(v384_2));
              let v384_4: Space = if has_head(&(v384_3)) { singleton(&[]) } else { Space::new() };
              drop(v384_3);
              let v384_5: Space = subtract(&(*CONSTANT_0),&(v384_4));
              drop(v384_4);
              let v384_8: Space = if (&(v384_5)).is_empty() { Space::new() } else {
                let v385_7: Space = routine_41(c, &v379_3_cursor.path()[v379_3_origin..(v379_3_origin + 3)], &v379_3_cursor);
                compose(&(v384_5),&(v385_7))
              };
              drop(v384_5);
              let v384_9: Space = intersect(&(*CONSTANT_12),&(v384_2));
              drop(v384_2);
              let v384_10: Space = if has_head(&(v384_9)) { singleton(&[]) } else { Space::new() };
              drop(v384_9);
              let v384_12: Space = if (&(v384_10)).is_empty() { Space::new() } else {
                let v386_11: Space = routine_42(c, &v379_3_cursor.path()[v379_3_origin..(v379_3_origin + 3)], &v379_3_cursor);
                compose(&(v384_10),&(v386_11))
              };
              drop(v384_10);
              let v384_13: Space = unite(&(v384_8),&(v384_12));
              join_wrapped_into(&mut v383_7_write,&((v384_13).read_zipper()),&[]);
              }
              v379_3_cursor.ascend(1);
            }
            drop(v383_7_write);
            compose(&(v382_5),&(v383_7))
          };
          drop(v382_5);
          let v382_9: Space = intersect(&(*CONSTANT_12),&(v382_2));
          drop(v382_2);
          let v382_10: Space = if has_head(&(v382_9)) { singleton(&[]) } else { Space::new() };
          drop(v382_9);
          let v382_12: Space = if (&(v382_10)).is_empty() { Space::new() } else {
            let mut v387_11 = Space::new();
            let mut v387_11_write = v387_11.write_zipper();
            for v387_11_byte in v379_3_cursor.child_mask().iter() {
              v379_3_cursor.descend_to_existing_byte(v387_11_byte);
              {
              let v388_2: Space = singleton(&v379_3_cursor.path()[(v379_3_origin + 2)..(v379_3_origin + 3)]);
              let v388_3: Space = intersect(&(*CONSTANT_12),&(v388_2));
              let v388_4: Space = if has_head(&(v388_3)) { singleton(&[]) } else { Space::new() };
              drop(v388_3);
              let v388_5: Space = subtract(&(*CONSTANT_0),&(v388_4));
              drop(v388_4);
              let v388_8: Space = if (&(v388_5)).is_empty() { Space::new() } else {
                let v389_7: Space = routine_41(c, &v379_3_cursor.path()[v379_3_origin..(v379_3_origin + 3)], &v379_3_cursor);
                compose(&(v388_5),&(v389_7))
              };
              drop(v388_5);
              let v388_9: Space = intersect(&(*CONSTANT_12),&(v388_2));
              drop(v388_2);
              let v388_10: Space = if has_head(&(v388_9)) { singleton(&[]) } else { Space::new() };
              drop(v388_9);
              let v388_12: Space = if (&(v388_10)).is_empty() { Space::new() } else {
                let v390_11: Space = routine_43(c, &v379_3_cursor.path()[v379_3_origin..(v379_3_origin + 3)], &v379_3_cursor);
                compose(&(v388_10),&(v390_11))
              };
              drop(v388_10);
              let v388_13: Space = unite(&(v388_8),&(v388_12));
              join_wrapped_into(&mut v387_11_write,&((v388_13).read_zipper()),&[]);
              }
              v379_3_cursor.ascend(1);
            }
            drop(v387_11_write);
            compose(&(v382_10),&(v387_11))
          };
          drop(v382_10);
          let v382_13: Space = unite(&(v382_8),&(v382_12));
          join_wrapped_into(&mut v381_6_write,&((v382_13).read_zipper()),&[]);
          }
          v379_3_cursor.ascend(1);
        }
        drop(v381_6_write);
        compose(&(v380_5),&(v381_6))
      };
      drop(v380_5);
      let v380_8: Space = intersect(&(*CONSTANT_12),&(v380_2));
      drop(v380_2);
      let v380_9: Space = if has_head(&(v380_8)) { singleton(&[]) } else { Space::new() };
      drop(v380_8);
      let v380_11: Space = if (&(v380_9)).is_empty() { Space::new() } else {
        let mut v391_10 = Space::new();
        let mut v391_10_write = v391_10.write_zipper();
        for v391_10_byte in v379_3_cursor.child_mask().iter() {
          v379_3_cursor.descend_to_existing_byte(v391_10_byte);
          {
          let v392_2: Space = singleton(&v379_3_cursor.path()[(v379_3_origin + 1)..(v379_3_origin + 2)]);
          let v392_3: Space = intersect(&(*CONSTANT_12),&(v392_2));
          let v392_4: Space = if has_head(&(v392_3)) { singleton(&[]) } else { Space::new() };
          drop(v392_3);
          let v392_5: Space = subtract(&(*CONSTANT_0),&(v392_4));
          drop(v392_4);
          let v392_8: Space = if (&(v392_5)).is_empty() { Space::new() } else {
            let mut v393_7 = Space::new();
            let mut v393_7_write = v393_7.write_zipper();
            for v393_7_byte in v379_3_cursor.child_mask().iter() {
              v379_3_cursor.descend_to_existing_byte(v393_7_byte);
              {
              let v394_2: Space = singleton(&v379_3_cursor.path()[(v379_3_origin + 2)..(v379_3_origin + 3)]);
              let v394_3: Space = intersect(&(*CONSTANT_12),&(v394_2));
              let v394_4: Space = if has_head(&(v394_3)) { singleton(&[]) } else { Space::new() };
              drop(v394_3);
              let v394_5: Space = subtract(&(*CONSTANT_0),&(v394_4));
              drop(v394_4);
              let v394_8: Space = if (&(v394_5)).is_empty() { Space::new() } else {
                let v395_7: Space = routine_41(c, &v379_3_cursor.path()[v379_3_origin..(v379_3_origin + 3)], &v379_3_cursor);
                compose(&(v394_5),&(v395_7))
              };
              drop(v394_5);
              let v394_9: Space = intersect(&(*CONSTANT_12),&(v394_2));
              drop(v394_2);
              let v394_10: Space = if has_head(&(v394_9)) { singleton(&[]) } else { Space::new() };
              drop(v394_9);
              let v394_12: Space = if (&(v394_10)).is_empty() { Space::new() } else {
                let v396_11: Space = routine_42(c, &v379_3_cursor.path()[v379_3_origin..(v379_3_origin + 3)], &v379_3_cursor);
                compose(&(v394_10),&(v396_11))
              };
              drop(v394_10);
              let v394_13: Space = unite(&(v394_8),&(v394_12));
              join_wrapped_into(&mut v393_7_write,&((v394_13).read_zipper()),&[]);
              }
              v379_3_cursor.ascend(1);
            }
            drop(v393_7_write);
            compose(&(v392_5),&(v393_7))
          };
          drop(v392_5);
          let v392_9: Space = intersect(&(*CONSTANT_12),&(v392_2));
          drop(v392_2);
          let v392_10: Space = if has_head(&(v392_9)) { singleton(&[]) } else { Space::new() };
          drop(v392_9);
          let v392_11: Space = compose(&(v392_10),&v379_3_cursor);
          drop(v392_10);
          let v392_12: Space = unite(&(v392_8),&(v392_11));
          drop(v392_11);
          join_wrapped_into(&mut v391_10_write,&((v392_12).read_zipper()),&[]);
          }
          v379_3_cursor.ascend(1);
        }
        drop(v391_10_write);
        compose(&(v380_9),&(v391_10))
      };
      drop(v380_9);
      let v380_12: Space = unite(&(v380_7),&(v380_11));
      join_wrapped_into(&mut v379_3_write,&((v380_12).read_zipper()),&[]);
      }
      v379_3_cursor.ascend(1);
    }
    drop(v379_3_cursor);
    drop(v379_3_write);
    drop(v379_2);
    let v379_4: Space = unite(&(v379_3),&(v378_24));
    let v379_5: Space = intersect(&(v379_4),&(*capture_3));
    if !v378_24.join_into((v379_5).clone()).is_element() { break; }
  }
  let mut v378_43: Space = (v378_5).clone();
  loop {
    let v397_1: Space = intersect(&(v378_43),&(*capture_3));
    let v397_2: Space = restrict_to(&(*capture_2),&(v397_1));
    drop(v397_1);
    let mut v397_3 = Space::new();
    let mut v397_3_write = v397_3.write_zipper();
    let mut v397_3_cursor = (v397_2).read_zipper();
    let v397_3_origin = v397_3_cursor.path().len();
    for v397_3_byte in v397_3_cursor.child_mask().iter() {
      v397_3_cursor.descend_to_existing_byte(v397_3_byte);
      {
      let v398_2: Space = singleton(&v397_3_cursor.path()[v397_3_origin..(v397_3_origin + 1)]);
      let v398_3: Space = intersect(&(*CONSTANT_12),&(v398_2));
      let v398_4: Space = if has_head(&(v398_3)) { singleton(&[]) } else { Space::new() };
      drop(v398_3);
      let v398_5: Space = subtract(&(*CONSTANT_0),&(v398_4));
      drop(v398_4);
      let v398_7: Space = if (&(v398_5)).is_empty() { Space::new() } else {
        let mut v399_6 = Space::new();
        let mut v399_6_write = v399_6.write_zipper();
        for v399_6_byte in v397_3_cursor.child_mask().iter() {
          v397_3_cursor.descend_to_existing_byte(v399_6_byte);
          {
          let v400_2: Space = singleton(&v397_3_cursor.path()[(v397_3_origin + 1)..(v397_3_origin + 2)]);
          let v400_3: Space = intersect(&(*CONSTANT_12),&(v400_2));
          let v400_4: Space = if has_head(&(v400_3)) { singleton(&[]) } else { Space::new() };
          drop(v400_3);
          let v400_5: Space = subtract(&(*CONSTANT_0),&(v400_4));
          drop(v400_4);
          let v400_8: Space = if (&(v400_5)).is_empty() { Space::new() } else {
            let mut v401_7 = Space::new();
            let mut v401_7_write = v401_7.write_zipper();
            for v401_7_byte in v397_3_cursor.child_mask().iter() {
              v397_3_cursor.descend_to_existing_byte(v401_7_byte);
              {
              let v402_2: Space = singleton(&v397_3_cursor.path()[(v397_3_origin + 2)..(v397_3_origin + 3)]);
              let v402_3: Space = intersect(&(*CONSTANT_12),&(v402_2));
              let v402_4: Space = if has_head(&(v402_3)) { singleton(&[]) } else { Space::new() };
              drop(v402_3);
              let v402_5: Space = subtract(&(*CONSTANT_0),&(v402_4));
              drop(v402_4);
              let v402_8: Space = if (&(v402_5)).is_empty() { Space::new() } else {
                let v403_7: Space = routine_41(c, &v397_3_cursor.path()[v397_3_origin..(v397_3_origin + 3)], &v397_3_cursor);
                compose(&(v402_5),&(v403_7))
              };
              drop(v402_5);
              let v402_9: Space = intersect(&(*CONSTANT_12),&(v402_2));
              drop(v402_2);
              let v402_10: Space = if has_head(&(v402_9)) { singleton(&[]) } else { Space::new() };
              drop(v402_9);
              let v402_12: Space = if (&(v402_10)).is_empty() { Space::new() } else {
                let v404_11: Space = routine_42(c, &v397_3_cursor.path()[v397_3_origin..(v397_3_origin + 3)], &v397_3_cursor);
                compose(&(v402_10),&(v404_11))
              };
              drop(v402_10);
              let v402_13: Space = unite(&(v402_8),&(v402_12));
              join_wrapped_into(&mut v401_7_write,&((v402_13).read_zipper()),&[]);
              }
              v397_3_cursor.ascend(1);
            }
            drop(v401_7_write);
            compose(&(v400_5),&(v401_7))
          };
          drop(v400_5);
          let v400_9: Space = intersect(&(*CONSTANT_12),&(v400_2));
          drop(v400_2);
          let v400_10: Space = if has_head(&(v400_9)) { singleton(&[]) } else { Space::new() };
          drop(v400_9);
          let v400_12: Space = if (&(v400_10)).is_empty() { Space::new() } else {
            let mut v405_11 = Space::new();
            let mut v405_11_write = v405_11.write_zipper();
            for v405_11_byte in v397_3_cursor.child_mask().iter() {
              v397_3_cursor.descend_to_existing_byte(v405_11_byte);
              {
              let v406_2: Space = singleton(&v397_3_cursor.path()[(v397_3_origin + 2)..(v397_3_origin + 3)]);
              let v406_3: Space = intersect(&(*CONSTANT_12),&(v406_2));
              let v406_4: Space = if has_head(&(v406_3)) { singleton(&[]) } else { Space::new() };
              drop(v406_3);
              let v406_5: Space = subtract(&(*CONSTANT_0),&(v406_4));
              drop(v406_4);
              let v406_8: Space = if (&(v406_5)).is_empty() { Space::new() } else {
                let v407_7: Space = routine_41(c, &v397_3_cursor.path()[v397_3_origin..(v397_3_origin + 3)], &v397_3_cursor);
                compose(&(v406_5),&(v407_7))
              };
              drop(v406_5);
              let v406_9: Space = intersect(&(*CONSTANT_12),&(v406_2));
              drop(v406_2);
              let v406_10: Space = if has_head(&(v406_9)) { singleton(&[]) } else { Space::new() };
              drop(v406_9);
              let v406_12: Space = if (&(v406_10)).is_empty() { Space::new() } else {
                let v408_11: Space = routine_43(c, &v397_3_cursor.path()[v397_3_origin..(v397_3_origin + 3)], &v397_3_cursor);
                compose(&(v406_10),&(v408_11))
              };
              drop(v406_10);
              let v406_13: Space = unite(&(v406_8),&(v406_12));
              join_wrapped_into(&mut v405_11_write,&((v406_13).read_zipper()),&[]);
              }
              v397_3_cursor.ascend(1);
            }
            drop(v405_11_write);
            compose(&(v400_10),&(v405_11))
          };
          drop(v400_10);
          let v400_13: Space = unite(&(v400_8),&(v400_12));
          join_wrapped_into(&mut v399_6_write,&((v400_13).read_zipper()),&[]);
          }
          v397_3_cursor.ascend(1);
        }
        drop(v399_6_write);
        compose(&(v398_5),&(v399_6))
      };
      drop(v398_5);
      let v398_8: Space = intersect(&(*CONSTANT_12),&(v398_2));
      drop(v398_2);
      let v398_9: Space = if has_head(&(v398_8)) { singleton(&[]) } else { Space::new() };
      drop(v398_8);
      let v398_11: Space = if (&(v398_9)).is_empty() { Space::new() } else {
        let mut v409_10 = Space::new();
        let mut v409_10_write = v409_10.write_zipper();
        for v409_10_byte in v397_3_cursor.child_mask().iter() {
          v397_3_cursor.descend_to_existing_byte(v409_10_byte);
          {
          let v410_2: Space = singleton(&v397_3_cursor.path()[(v397_3_origin + 1)..(v397_3_origin + 2)]);
          let v410_3: Space = intersect(&(*CONSTANT_12),&(v410_2));
          let v410_4: Space = if has_head(&(v410_3)) { singleton(&[]) } else { Space::new() };
          drop(v410_3);
          let v410_5: Space = subtract(&(*CONSTANT_0),&(v410_4));
          drop(v410_4);
          let v410_8: Space = if (&(v410_5)).is_empty() { Space::new() } else {
            let mut v411_7 = Space::new();
            let mut v411_7_write = v411_7.write_zipper();
            for v411_7_byte in v397_3_cursor.child_mask().iter() {
              v397_3_cursor.descend_to_existing_byte(v411_7_byte);
              {
              let v412_2: Space = singleton(&v397_3_cursor.path()[(v397_3_origin + 2)..(v397_3_origin + 3)]);
              let v412_3: Space = intersect(&(*CONSTANT_12),&(v412_2));
              let v412_4: Space = if has_head(&(v412_3)) { singleton(&[]) } else { Space::new() };
              drop(v412_3);
              let v412_5: Space = subtract(&(*CONSTANT_0),&(v412_4));
              drop(v412_4);
              let v412_8: Space = if (&(v412_5)).is_empty() { Space::new() } else {
                let v413_7: Space = routine_41(c, &v397_3_cursor.path()[v397_3_origin..(v397_3_origin + 3)], &v397_3_cursor);
                compose(&(v412_5),&(v413_7))
              };
              drop(v412_5);
              let v412_9: Space = intersect(&(*CONSTANT_12),&(v412_2));
              drop(v412_2);
              let v412_10: Space = if has_head(&(v412_9)) { singleton(&[]) } else { Space::new() };
              drop(v412_9);
              let v412_12: Space = if (&(v412_10)).is_empty() { Space::new() } else {
                let v414_11: Space = routine_42(c, &v397_3_cursor.path()[v397_3_origin..(v397_3_origin + 3)], &v397_3_cursor);
                compose(&(v412_10),&(v414_11))
              };
              drop(v412_10);
              let v412_13: Space = unite(&(v412_8),&(v412_12));
              join_wrapped_into(&mut v411_7_write,&((v412_13).read_zipper()),&[]);
              }
              v397_3_cursor.ascend(1);
            }
            drop(v411_7_write);
            compose(&(v410_5),&(v411_7))
          };
          drop(v410_5);
          let v410_9: Space = intersect(&(*CONSTANT_12),&(v410_2));
          drop(v410_2);
          let v410_10: Space = if has_head(&(v410_9)) { singleton(&[]) } else { Space::new() };
          drop(v410_9);
          let v410_11: Space = compose(&(v410_10),&v397_3_cursor);
          drop(v410_10);
          let v410_12: Space = unite(&(v410_8),&(v410_11));
          drop(v410_11);
          join_wrapped_into(&mut v409_10_write,&((v410_12).read_zipper()),&[]);
          }
          v397_3_cursor.ascend(1);
        }
        drop(v409_10_write);
        compose(&(v398_9),&(v409_10))
      };
      drop(v398_9);
      let v398_12: Space = unite(&(v398_7),&(v398_11));
      join_wrapped_into(&mut v397_3_write,&((v398_12).read_zipper()),&[]);
      }
      v397_3_cursor.ascend(1);
    }
    drop(v397_3_cursor);
    drop(v397_3_write);
    drop(v397_2);
    let v397_4: Space = unite(&(v397_3),&(v378_43));
    let v397_5: Space = intersect(&(v397_4),&(*capture_3));
    if !v378_43.join_into((v397_5).clone()).is_element() { break; }
  }
  let v378_44: Space = intersect(&(v378_24),&(v378_43));
  let v378_45: Space = subtract(&(v378_44),&(v378_5));
  let v378_46: Space = wrap(&(v378_45),&(*capture_0));
  let mut v378_65: Space = (v378_5).clone();
  loop {
    let v415_1: Space = intersect(&(v378_65),&(*capture_3));
    let v415_2: Space = restrict_to(&(*capture_2),&(v415_1));
    drop(v415_1);
    let mut v415_3 = Space::new();
    let mut v415_3_write = v415_3.write_zipper();
    let mut v415_3_cursor = (v415_2).read_zipper();
    let v415_3_origin = v415_3_cursor.path().len();
    for v415_3_byte in v415_3_cursor.child_mask().iter() {
      v415_3_cursor.descend_to_existing_byte(v415_3_byte);
      {
      let v416_2: Space = singleton(&v415_3_cursor.path()[v415_3_origin..(v415_3_origin + 1)]);
      let v416_3: Space = intersect(&(*CONSTANT_12),&(v416_2));
      let v416_4: Space = if has_head(&(v416_3)) { singleton(&[]) } else { Space::new() };
      drop(v416_3);
      let v416_5: Space = subtract(&(*CONSTANT_0),&(v416_4));
      drop(v416_4);
      let v416_7: Space = if (&(v416_5)).is_empty() { Space::new() } else {
        let mut v417_6 = Space::new();
        let mut v417_6_write = v417_6.write_zipper();
        for v417_6_byte in v415_3_cursor.child_mask().iter() {
          v415_3_cursor.descend_to_existing_byte(v417_6_byte);
          {
          let v418_2: Space = singleton(&v415_3_cursor.path()[(v415_3_origin + 1)..(v415_3_origin + 2)]);
          let v418_3: Space = intersect(&(*CONSTANT_12),&(v418_2));
          let v418_4: Space = if has_head(&(v418_3)) { singleton(&[]) } else { Space::new() };
          drop(v418_3);
          let v418_5: Space = subtract(&(*CONSTANT_0),&(v418_4));
          drop(v418_4);
          let v418_8: Space = if (&(v418_5)).is_empty() { Space::new() } else {
            let mut v419_7 = Space::new();
            let mut v419_7_write = v419_7.write_zipper();
            for v419_7_byte in v415_3_cursor.child_mask().iter() {
              v415_3_cursor.descend_to_existing_byte(v419_7_byte);
              {
              let v420_2: Space = singleton(&v415_3_cursor.path()[(v415_3_origin + 2)..(v415_3_origin + 3)]);
              let v420_3: Space = intersect(&(*CONSTANT_12),&(v420_2));
              let v420_4: Space = if has_head(&(v420_3)) { singleton(&[]) } else { Space::new() };
              drop(v420_3);
              let v420_5: Space = subtract(&(*CONSTANT_0),&(v420_4));
              drop(v420_4);
              let v420_8: Space = if (&(v420_5)).is_empty() { Space::new() } else {
                let v421_7: Space = routine_41(c, &v415_3_cursor.path()[v415_3_origin..(v415_3_origin + 3)], &v415_3_cursor);
                compose(&(v420_5),&(v421_7))
              };
              drop(v420_5);
              let v420_9: Space = intersect(&(*CONSTANT_12),&(v420_2));
              drop(v420_2);
              let v420_10: Space = if has_head(&(v420_9)) { singleton(&[]) } else { Space::new() };
              drop(v420_9);
              let v420_12: Space = if (&(v420_10)).is_empty() { Space::new() } else {
                let v422_11: Space = routine_42(c, &v415_3_cursor.path()[v415_3_origin..(v415_3_origin + 3)], &v415_3_cursor);
                compose(&(v420_10),&(v422_11))
              };
              drop(v420_10);
              let v420_13: Space = unite(&(v420_8),&(v420_12));
              join_wrapped_into(&mut v419_7_write,&((v420_13).read_zipper()),&[]);
              }
              v415_3_cursor.ascend(1);
            }
            drop(v419_7_write);
            compose(&(v418_5),&(v419_7))
          };
          drop(v418_5);
          let v418_9: Space = intersect(&(*CONSTANT_12),&(v418_2));
          drop(v418_2);
          let v418_10: Space = if has_head(&(v418_9)) { singleton(&[]) } else { Space::new() };
          drop(v418_9);
          let v418_12: Space = if (&(v418_10)).is_empty() { Space::new() } else {
            let mut v423_11 = Space::new();
            let mut v423_11_write = v423_11.write_zipper();
            for v423_11_byte in v415_3_cursor.child_mask().iter() {
              v415_3_cursor.descend_to_existing_byte(v423_11_byte);
              {
              let v424_2: Space = singleton(&v415_3_cursor.path()[(v415_3_origin + 2)..(v415_3_origin + 3)]);
              let v424_3: Space = intersect(&(*CONSTANT_12),&(v424_2));
              let v424_4: Space = if has_head(&(v424_3)) { singleton(&[]) } else { Space::new() };
              drop(v424_3);
              let v424_5: Space = subtract(&(*CONSTANT_0),&(v424_4));
              drop(v424_4);
              let v424_8: Space = if (&(v424_5)).is_empty() { Space::new() } else {
                let v425_7: Space = routine_41(c, &v415_3_cursor.path()[v415_3_origin..(v415_3_origin + 3)], &v415_3_cursor);
                compose(&(v424_5),&(v425_7))
              };
              drop(v424_5);
              let v424_9: Space = intersect(&(*CONSTANT_12),&(v424_2));
              drop(v424_2);
              let v424_10: Space = if has_head(&(v424_9)) { singleton(&[]) } else { Space::new() };
              drop(v424_9);
              let v424_12: Space = if (&(v424_10)).is_empty() { Space::new() } else {
                let v426_11: Space = routine_43(c, &v415_3_cursor.path()[v415_3_origin..(v415_3_origin + 3)], &v415_3_cursor);
                compose(&(v424_10),&(v426_11))
              };
              drop(v424_10);
              let v424_13: Space = unite(&(v424_8),&(v424_12));
              join_wrapped_into(&mut v423_11_write,&((v424_13).read_zipper()),&[]);
              }
              v415_3_cursor.ascend(1);
            }
            drop(v423_11_write);
            compose(&(v418_10),&(v423_11))
          };
          drop(v418_10);
          let v418_13: Space = unite(&(v418_8),&(v418_12));
          join_wrapped_into(&mut v417_6_write,&((v418_13).read_zipper()),&[]);
          }
          v415_3_cursor.ascend(1);
        }
        drop(v417_6_write);
        compose(&(v416_5),&(v417_6))
      };
      drop(v416_5);
      let v416_8: Space = intersect(&(*CONSTANT_12),&(v416_2));
      drop(v416_2);
      let v416_9: Space = if has_head(&(v416_8)) { singleton(&[]) } else { Space::new() };
      drop(v416_8);
      let v416_11: Space = if (&(v416_9)).is_empty() { Space::new() } else {
        let mut v427_10 = Space::new();
        let mut v427_10_write = v427_10.write_zipper();
        for v427_10_byte in v415_3_cursor.child_mask().iter() {
          v415_3_cursor.descend_to_existing_byte(v427_10_byte);
          {
          let v428_2: Space = singleton(&v415_3_cursor.path()[(v415_3_origin + 1)..(v415_3_origin + 2)]);
          let v428_3: Space = intersect(&(*CONSTANT_12),&(v428_2));
          let v428_4: Space = if has_head(&(v428_3)) { singleton(&[]) } else { Space::new() };
          drop(v428_3);
          let v428_5: Space = subtract(&(*CONSTANT_0),&(v428_4));
          drop(v428_4);
          let v428_8: Space = if (&(v428_5)).is_empty() { Space::new() } else {
            let mut v429_7 = Space::new();
            let mut v429_7_write = v429_7.write_zipper();
            for v429_7_byte in v415_3_cursor.child_mask().iter() {
              v415_3_cursor.descend_to_existing_byte(v429_7_byte);
              {
              let v430_2: Space = singleton(&v415_3_cursor.path()[(v415_3_origin + 2)..(v415_3_origin + 3)]);
              let v430_3: Space = intersect(&(*CONSTANT_12),&(v430_2));
              let v430_4: Space = if has_head(&(v430_3)) { singleton(&[]) } else { Space::new() };
              drop(v430_3);
              let v430_5: Space = subtract(&(*CONSTANT_0),&(v430_4));
              drop(v430_4);
              let v430_8: Space = if (&(v430_5)).is_empty() { Space::new() } else {
                let v431_7: Space = routine_41(c, &v415_3_cursor.path()[v415_3_origin..(v415_3_origin + 3)], &v415_3_cursor);
                compose(&(v430_5),&(v431_7))
              };
              drop(v430_5);
              let v430_9: Space = intersect(&(*CONSTANT_12),&(v430_2));
              drop(v430_2);
              let v430_10: Space = if has_head(&(v430_9)) { singleton(&[]) } else { Space::new() };
              drop(v430_9);
              let v430_12: Space = if (&(v430_10)).is_empty() { Space::new() } else {
                let v432_11: Space = routine_42(c, &v415_3_cursor.path()[v415_3_origin..(v415_3_origin + 3)], &v415_3_cursor);
                compose(&(v430_10),&(v432_11))
              };
              drop(v430_10);
              let v430_13: Space = unite(&(v430_8),&(v430_12));
              join_wrapped_into(&mut v429_7_write,&((v430_13).read_zipper()),&[]);
              }
              v415_3_cursor.ascend(1);
            }
            drop(v429_7_write);
            compose(&(v428_5),&(v429_7))
          };
          drop(v428_5);
          let v428_9: Space = intersect(&(*CONSTANT_12),&(v428_2));
          drop(v428_2);
          let v428_10: Space = if has_head(&(v428_9)) { singleton(&[]) } else { Space::new() };
          drop(v428_9);
          let v428_11: Space = compose(&(v428_10),&v415_3_cursor);
          drop(v428_10);
          let v428_12: Space = unite(&(v428_8),&(v428_11));
          drop(v428_11);
          join_wrapped_into(&mut v427_10_write,&((v428_12).read_zipper()),&[]);
          }
          v415_3_cursor.ascend(1);
        }
        drop(v427_10_write);
        compose(&(v416_9),&(v427_10))
      };
      drop(v416_9);
      let v416_12: Space = unite(&(v416_7),&(v416_11));
      join_wrapped_into(&mut v415_3_write,&((v416_12).read_zipper()),&[]);
      }
      v415_3_cursor.ascend(1);
    }
    drop(v415_3_cursor);
    drop(v415_3_write);
    drop(v415_2);
    let v415_4: Space = unite(&(v415_3),&(v378_65));
    let v415_5: Space = intersect(&(v415_4),&(*capture_3));
    if !v378_65.join_into((v415_5).clone()).is_element() { break; }
  }
  let v378_66: Space = subtract(&(*capture_3),&(v378_65));
  let mut v378_85: Space = (v378_5).clone();
  loop {
    let v433_1: Space = intersect(&(v378_85),&(*capture_3));
    let v433_2: Space = restrict_to(&(*capture_1),&(v433_1));
    drop(v433_1);
    let mut v433_3 = Space::new();
    let mut v433_3_write = v433_3.write_zipper();
    let mut v433_3_cursor = (v433_2).read_zipper();
    let v433_3_origin = v433_3_cursor.path().len();
    for v433_3_byte in v433_3_cursor.child_mask().iter() {
      v433_3_cursor.descend_to_existing_byte(v433_3_byte);
      {
      let v434_2: Space = singleton(&v433_3_cursor.path()[v433_3_origin..(v433_3_origin + 1)]);
      let v434_3: Space = intersect(&(*CONSTANT_12),&(v434_2));
      let v434_4: Space = if has_head(&(v434_3)) { singleton(&[]) } else { Space::new() };
      drop(v434_3);
      let v434_5: Space = subtract(&(*CONSTANT_0),&(v434_4));
      drop(v434_4);
      let v434_7: Space = if (&(v434_5)).is_empty() { Space::new() } else {
        let mut v435_6 = Space::new();
        let mut v435_6_write = v435_6.write_zipper();
        for v435_6_byte in v433_3_cursor.child_mask().iter() {
          v433_3_cursor.descend_to_existing_byte(v435_6_byte);
          {
          let v436_2: Space = singleton(&v433_3_cursor.path()[(v433_3_origin + 1)..(v433_3_origin + 2)]);
          let v436_3: Space = intersect(&(*CONSTANT_12),&(v436_2));
          let v436_4: Space = if has_head(&(v436_3)) { singleton(&[]) } else { Space::new() };
          drop(v436_3);
          let v436_5: Space = subtract(&(*CONSTANT_0),&(v436_4));
          drop(v436_4);
          let v436_8: Space = if (&(v436_5)).is_empty() { Space::new() } else {
            let mut v437_7 = Space::new();
            let mut v437_7_write = v437_7.write_zipper();
            for v437_7_byte in v433_3_cursor.child_mask().iter() {
              v433_3_cursor.descend_to_existing_byte(v437_7_byte);
              {
              let v438_2: Space = singleton(&v433_3_cursor.path()[(v433_3_origin + 2)..(v433_3_origin + 3)]);
              let v438_3: Space = intersect(&(*CONSTANT_12),&(v438_2));
              let v438_4: Space = if has_head(&(v438_3)) { singleton(&[]) } else { Space::new() };
              drop(v438_3);
              let v438_5: Space = subtract(&(*CONSTANT_0),&(v438_4));
              drop(v438_4);
              let v438_8: Space = if (&(v438_5)).is_empty() { Space::new() } else {
                let v439_7: Space = routine_41(c, &v433_3_cursor.path()[v433_3_origin..(v433_3_origin + 3)], &v433_3_cursor);
                compose(&(v438_5),&(v439_7))
              };
              drop(v438_5);
              let v438_9: Space = intersect(&(*CONSTANT_12),&(v438_2));
              drop(v438_2);
              let v438_10: Space = if has_head(&(v438_9)) { singleton(&[]) } else { Space::new() };
              drop(v438_9);
              let v438_12: Space = if (&(v438_10)).is_empty() { Space::new() } else {
                let v440_11: Space = routine_42(c, &v433_3_cursor.path()[v433_3_origin..(v433_3_origin + 3)], &v433_3_cursor);
                compose(&(v438_10),&(v440_11))
              };
              drop(v438_10);
              let v438_13: Space = unite(&(v438_8),&(v438_12));
              join_wrapped_into(&mut v437_7_write,&((v438_13).read_zipper()),&[]);
              }
              v433_3_cursor.ascend(1);
            }
            drop(v437_7_write);
            compose(&(v436_5),&(v437_7))
          };
          drop(v436_5);
          let v436_9: Space = intersect(&(*CONSTANT_12),&(v436_2));
          drop(v436_2);
          let v436_10: Space = if has_head(&(v436_9)) { singleton(&[]) } else { Space::new() };
          drop(v436_9);
          let v436_12: Space = if (&(v436_10)).is_empty() { Space::new() } else {
            let mut v441_11 = Space::new();
            let mut v441_11_write = v441_11.write_zipper();
            for v441_11_byte in v433_3_cursor.child_mask().iter() {
              v433_3_cursor.descend_to_existing_byte(v441_11_byte);
              {
              let v442_2: Space = singleton(&v433_3_cursor.path()[(v433_3_origin + 2)..(v433_3_origin + 3)]);
              let v442_3: Space = intersect(&(*CONSTANT_12),&(v442_2));
              let v442_4: Space = if has_head(&(v442_3)) { singleton(&[]) } else { Space::new() };
              drop(v442_3);
              let v442_5: Space = subtract(&(*CONSTANT_0),&(v442_4));
              drop(v442_4);
              let v442_8: Space = if (&(v442_5)).is_empty() { Space::new() } else {
                let v443_7: Space = routine_41(c, &v433_3_cursor.path()[v433_3_origin..(v433_3_origin + 3)], &v433_3_cursor);
                compose(&(v442_5),&(v443_7))
              };
              drop(v442_5);
              let v442_9: Space = intersect(&(*CONSTANT_12),&(v442_2));
              drop(v442_2);
              let v442_10: Space = if has_head(&(v442_9)) { singleton(&[]) } else { Space::new() };
              drop(v442_9);
              let v442_12: Space = if (&(v442_10)).is_empty() { Space::new() } else {
                let v444_11: Space = routine_43(c, &v433_3_cursor.path()[v433_3_origin..(v433_3_origin + 3)], &v433_3_cursor);
                compose(&(v442_10),&(v444_11))
              };
              drop(v442_10);
              let v442_13: Space = unite(&(v442_8),&(v442_12));
              join_wrapped_into(&mut v441_11_write,&((v442_13).read_zipper()),&[]);
              }
              v433_3_cursor.ascend(1);
            }
            drop(v441_11_write);
            compose(&(v436_10),&(v441_11))
          };
          drop(v436_10);
          let v436_13: Space = unite(&(v436_8),&(v436_12));
          join_wrapped_into(&mut v435_6_write,&((v436_13).read_zipper()),&[]);
          }
          v433_3_cursor.ascend(1);
        }
        drop(v435_6_write);
        compose(&(v434_5),&(v435_6))
      };
      drop(v434_5);
      let v434_8: Space = intersect(&(*CONSTANT_12),&(v434_2));
      drop(v434_2);
      let v434_9: Space = if has_head(&(v434_8)) { singleton(&[]) } else { Space::new() };
      drop(v434_8);
      let v434_11: Space = if (&(v434_9)).is_empty() { Space::new() } else {
        let mut v445_10 = Space::new();
        let mut v445_10_write = v445_10.write_zipper();
        for v445_10_byte in v433_3_cursor.child_mask().iter() {
          v433_3_cursor.descend_to_existing_byte(v445_10_byte);
          {
          let v446_2: Space = singleton(&v433_3_cursor.path()[(v433_3_origin + 1)..(v433_3_origin + 2)]);
          let v446_3: Space = intersect(&(*CONSTANT_12),&(v446_2));
          let v446_4: Space = if has_head(&(v446_3)) { singleton(&[]) } else { Space::new() };
          drop(v446_3);
          let v446_5: Space = subtract(&(*CONSTANT_0),&(v446_4));
          drop(v446_4);
          let v446_8: Space = if (&(v446_5)).is_empty() { Space::new() } else {
            let mut v447_7 = Space::new();
            let mut v447_7_write = v447_7.write_zipper();
            for v447_7_byte in v433_3_cursor.child_mask().iter() {
              v433_3_cursor.descend_to_existing_byte(v447_7_byte);
              {
              let v448_2: Space = singleton(&v433_3_cursor.path()[(v433_3_origin + 2)..(v433_3_origin + 3)]);
              let v448_3: Space = intersect(&(*CONSTANT_12),&(v448_2));
              let v448_4: Space = if has_head(&(v448_3)) { singleton(&[]) } else { Space::new() };
              drop(v448_3);
              let v448_5: Space = subtract(&(*CONSTANT_0),&(v448_4));
              drop(v448_4);
              let v448_8: Space = if (&(v448_5)).is_empty() { Space::new() } else {
                let v449_7: Space = routine_41(c, &v433_3_cursor.path()[v433_3_origin..(v433_3_origin + 3)], &v433_3_cursor);
                compose(&(v448_5),&(v449_7))
              };
              drop(v448_5);
              let v448_9: Space = intersect(&(*CONSTANT_12),&(v448_2));
              drop(v448_2);
              let v448_10: Space = if has_head(&(v448_9)) { singleton(&[]) } else { Space::new() };
              drop(v448_9);
              let v448_12: Space = if (&(v448_10)).is_empty() { Space::new() } else {
                let v450_11: Space = routine_42(c, &v433_3_cursor.path()[v433_3_origin..(v433_3_origin + 3)], &v433_3_cursor);
                compose(&(v448_10),&(v450_11))
              };
              drop(v448_10);
              let v448_13: Space = unite(&(v448_8),&(v448_12));
              join_wrapped_into(&mut v447_7_write,&((v448_13).read_zipper()),&[]);
              }
              v433_3_cursor.ascend(1);
            }
            drop(v447_7_write);
            compose(&(v446_5),&(v447_7))
          };
          drop(v446_5);
          let v446_9: Space = intersect(&(*CONSTANT_12),&(v446_2));
          drop(v446_2);
          let v446_10: Space = if has_head(&(v446_9)) { singleton(&[]) } else { Space::new() };
          drop(v446_9);
          let v446_11: Space = compose(&(v446_10),&v433_3_cursor);
          drop(v446_10);
          let v446_12: Space = unite(&(v446_8),&(v446_11));
          drop(v446_11);
          join_wrapped_into(&mut v445_10_write,&((v446_12).read_zipper()),&[]);
          }
          v433_3_cursor.ascend(1);
        }
        drop(v445_10_write);
        compose(&(v434_9),&(v445_10))
      };
      drop(v434_9);
      let v434_12: Space = unite(&(v434_7),&(v434_11));
      join_wrapped_into(&mut v433_3_write,&((v434_12).read_zipper()),&[]);
      }
      v433_3_cursor.ascend(1);
    }
    drop(v433_3_cursor);
    drop(v433_3_write);
    drop(v433_2);
    let v433_4: Space = unite(&(v433_3),&(v378_85));
    let v433_5: Space = intersect(&(v433_4),&(*capture_3));
    if !v378_85.join_into((v433_5).clone()).is_element() { break; }
  }

((v378_24).clone(),(v378_43).clone(),(v378_44).clone(),(v378_45).clone(),(v378_46).clone(),(v378_5).clone(),(v378_65).clone(),(v378_66).clone(),(v378_85).clone(),)
}

#[inline(never)]
fn native_block_2(c: &mut Context,capture_0: &View<'_, '_>,capture_1: &View<'_, '_>,capture_2: &View<'_, '_>,capture_3: &View<'_, '_>,capture_4: usize,capture_5: &Space) -> (Space,Space,) {
    let v451_2: Space = singleton(&(*capture_3).path()[capture_4..(capture_4 + 1)]);
    let v451_3: Space = intersect(&(*CONSTANT_12),&(v451_2));
    let v451_4: Space = if has_head(&(v451_3)) { singleton(&[]) } else { Space::new() };
    drop(v451_3);
    let v451_5: Space = subtract(&(*CONSTANT_0),&(v451_4));
    drop(v451_4);
    let v451_11: Space = if (&(v451_5)).is_empty() { Space::new() } else {
      let mut v452_6: Space = ((*capture_5)).clone();
      loop {
        let v453_1: Space = intersect(&(v452_6),&(*capture_2));
        let v453_2: Space = restrict_to(&(*capture_1),&(v453_1));
        drop(v453_1);
        let mut v453_3 = Space::new();
        let mut v453_3_write = v453_3.write_zipper();
        let mut v453_3_cursor = (v453_2).read_zipper();
        let v453_3_origin = v453_3_cursor.path().len();
        for v453_3_byte in v453_3_cursor.child_mask().iter() {
          v453_3_cursor.descend_to_existing_byte(v453_3_byte);
          {
          let v454_2: Space = singleton(&v453_3_cursor.path()[v453_3_origin..(v453_3_origin + 1)]);
          let v454_3: Space = intersect(&(*CONSTANT_12),&(v454_2));
          let v454_4: Space = if has_head(&(v454_3)) { singleton(&[]) } else { Space::new() };
          drop(v454_3);
          let v454_5: Space = subtract(&(*CONSTANT_0),&(v454_4));
          drop(v454_4);
          let v454_7: Space = if (&(v454_5)).is_empty() { Space::new() } else {
            let mut v455_6 = Space::new();
            let mut v455_6_write = v455_6.write_zipper();
            for v455_6_byte in v453_3_cursor.child_mask().iter() {
              v453_3_cursor.descend_to_existing_byte(v455_6_byte);
              {
              let v456_2: Space = singleton(&v453_3_cursor.path()[(v453_3_origin + 1)..(v453_3_origin + 2)]);
              let v456_3: Space = intersect(&(*CONSTANT_12),&(v456_2));
              let v456_4: Space = if has_head(&(v456_3)) { singleton(&[]) } else { Space::new() };
              drop(v456_3);
              let v456_5: Space = subtract(&(*CONSTANT_0),&(v456_4));
              drop(v456_4);
              let v456_8: Space = if (&(v456_5)).is_empty() { Space::new() } else {
                let mut v457_7 = Space::new();
                let mut v457_7_write = v457_7.write_zipper();
                for v457_7_byte in v453_3_cursor.child_mask().iter() {
                  v453_3_cursor.descend_to_existing_byte(v457_7_byte);
                  {
                  let v458_2: Space = singleton(&v453_3_cursor.path()[(v453_3_origin + 2)..(v453_3_origin + 3)]);
                  let v458_3: Space = intersect(&(*CONSTANT_12),&(v458_2));
                  let v458_4: Space = if has_head(&(v458_3)) { singleton(&[]) } else { Space::new() };
                  drop(v458_3);
                  let v458_5: Space = subtract(&(*CONSTANT_0),&(v458_4));
                  drop(v458_4);
                  let v458_8: Space = if (&(v458_5)).is_empty() { Space::new() } else {
                    let v459_7: Space = routine_41(c, &v453_3_cursor.path()[v453_3_origin..(v453_3_origin + 3)], &v453_3_cursor);
                    compose(&(v458_5),&(v459_7))
                  };
                  drop(v458_5);
                  let v458_9: Space = intersect(&(*CONSTANT_12),&(v458_2));
                  drop(v458_2);
                  let v458_10: Space = if has_head(&(v458_9)) { singleton(&[]) } else { Space::new() };
                  drop(v458_9);
                  let v458_12: Space = if (&(v458_10)).is_empty() { Space::new() } else {
                    let v460_11: Space = routine_42(c, &v453_3_cursor.path()[v453_3_origin..(v453_3_origin + 3)], &v453_3_cursor);
                    compose(&(v458_10),&(v460_11))
                  };
                  drop(v458_10);
                  let v458_13: Space = unite(&(v458_8),&(v458_12));
                  join_wrapped_into(&mut v457_7_write,&((v458_13).read_zipper()),&[]);
                  }
                  v453_3_cursor.ascend(1);
                }
                drop(v457_7_write);
                compose(&(v456_5),&(v457_7))
              };
              drop(v456_5);
              let v456_9: Space = intersect(&(*CONSTANT_12),&(v456_2));
              drop(v456_2);
              let v456_10: Space = if has_head(&(v456_9)) { singleton(&[]) } else { Space::new() };
              drop(v456_9);
              let v456_12: Space = if (&(v456_10)).is_empty() { Space::new() } else {
                let mut v461_11 = Space::new();
                let mut v461_11_write = v461_11.write_zipper();
                for v461_11_byte in v453_3_cursor.child_mask().iter() {
                  v453_3_cursor.descend_to_existing_byte(v461_11_byte);
                  {
                  let v462_2: Space = singleton(&v453_3_cursor.path()[(v453_3_origin + 2)..(v453_3_origin + 3)]);
                  let v462_3: Space = intersect(&(*CONSTANT_12),&(v462_2));
                  let v462_4: Space = if has_head(&(v462_3)) { singleton(&[]) } else { Space::new() };
                  drop(v462_3);
                  let v462_5: Space = subtract(&(*CONSTANT_0),&(v462_4));
                  drop(v462_4);
                  let v462_8: Space = if (&(v462_5)).is_empty() { Space::new() } else {
                    let v463_7: Space = routine_41(c, &v453_3_cursor.path()[v453_3_origin..(v453_3_origin + 3)], &v453_3_cursor);
                    compose(&(v462_5),&(v463_7))
                  };
                  drop(v462_5);
                  let v462_9: Space = intersect(&(*CONSTANT_12),&(v462_2));
                  drop(v462_2);
                  let v462_10: Space = if has_head(&(v462_9)) { singleton(&[]) } else { Space::new() };
                  drop(v462_9);
                  let v462_12: Space = if (&(v462_10)).is_empty() { Space::new() } else {
                    let v464_11: Space = routine_43(c, &v453_3_cursor.path()[v453_3_origin..(v453_3_origin + 3)], &v453_3_cursor);
                    compose(&(v462_10),&(v464_11))
                  };
                  drop(v462_10);
                  let v462_13: Space = unite(&(v462_8),&(v462_12));
                  join_wrapped_into(&mut v461_11_write,&((v462_13).read_zipper()),&[]);
                  }
                  v453_3_cursor.ascend(1);
                }
                drop(v461_11_write);
                compose(&(v456_10),&(v461_11))
              };
              drop(v456_10);
              let v456_13: Space = unite(&(v456_8),&(v456_12));
              join_wrapped_into(&mut v455_6_write,&((v456_13).read_zipper()),&[]);
              }
              v453_3_cursor.ascend(1);
            }
            drop(v455_6_write);
            compose(&(v454_5),&(v455_6))
          };
          drop(v454_5);
          let v454_8: Space = intersect(&(*CONSTANT_12),&(v454_2));
          drop(v454_2);
          let v454_9: Space = if has_head(&(v454_8)) { singleton(&[]) } else { Space::new() };
          drop(v454_8);
          let v454_11: Space = if (&(v454_9)).is_empty() { Space::new() } else {
            let mut v465_10 = Space::new();
            let mut v465_10_write = v465_10.write_zipper();
            for v465_10_byte in v453_3_cursor.child_mask().iter() {
              v453_3_cursor.descend_to_existing_byte(v465_10_byte);
              {
              let v466_2: Space = singleton(&v453_3_cursor.path()[(v453_3_origin + 1)..(v453_3_origin + 2)]);
              let v466_3: Space = intersect(&(*CONSTANT_12),&(v466_2));
              let v466_4: Space = if has_head(&(v466_3)) { singleton(&[]) } else { Space::new() };
              drop(v466_3);
              let v466_5: Space = subtract(&(*CONSTANT_0),&(v466_4));
              drop(v466_4);
              let v466_8: Space = if (&(v466_5)).is_empty() { Space::new() } else {
                let mut v467_7 = Space::new();
                let mut v467_7_write = v467_7.write_zipper();
                for v467_7_byte in v453_3_cursor.child_mask().iter() {
                  v453_3_cursor.descend_to_existing_byte(v467_7_byte);
                  {
                  let v468_2: Space = singleton(&v453_3_cursor.path()[(v453_3_origin + 2)..(v453_3_origin + 3)]);
                  let v468_3: Space = intersect(&(*CONSTANT_12),&(v468_2));
                  let v468_4: Space = if has_head(&(v468_3)) { singleton(&[]) } else { Space::new() };
                  drop(v468_3);
                  let v468_5: Space = subtract(&(*CONSTANT_0),&(v468_4));
                  drop(v468_4);
                  let v468_8: Space = if (&(v468_5)).is_empty() { Space::new() } else {
                    let v469_7: Space = routine_41(c, &v453_3_cursor.path()[v453_3_origin..(v453_3_origin + 3)], &v453_3_cursor);
                    compose(&(v468_5),&(v469_7))
                  };
                  drop(v468_5);
                  let v468_9: Space = intersect(&(*CONSTANT_12),&(v468_2));
                  drop(v468_2);
                  let v468_10: Space = if has_head(&(v468_9)) { singleton(&[]) } else { Space::new() };
                  drop(v468_9);
                  let v468_12: Space = if (&(v468_10)).is_empty() { Space::new() } else {
                    let v470_11: Space = routine_42(c, &v453_3_cursor.path()[v453_3_origin..(v453_3_origin + 3)], &v453_3_cursor);
                    compose(&(v468_10),&(v470_11))
                  };
                  drop(v468_10);
                  let v468_13: Space = unite(&(v468_8),&(v468_12));
                  join_wrapped_into(&mut v467_7_write,&((v468_13).read_zipper()),&[]);
                  }
                  v453_3_cursor.ascend(1);
                }
                drop(v467_7_write);
                compose(&(v466_5),&(v467_7))
              };
              drop(v466_5);
              let v466_9: Space = intersect(&(*CONSTANT_12),&(v466_2));
              drop(v466_2);
              let v466_10: Space = if has_head(&(v466_9)) { singleton(&[]) } else { Space::new() };
              drop(v466_9);
              let v466_11: Space = compose(&(v466_10),&v453_3_cursor);
              drop(v466_10);
              let v466_12: Space = unite(&(v466_8),&(v466_11));
              drop(v466_11);
              join_wrapped_into(&mut v465_10_write,&((v466_12).read_zipper()),&[]);
              }
              v453_3_cursor.ascend(1);
            }
            drop(v465_10_write);
            compose(&(v454_9),&(v465_10))
          };
          drop(v454_9);
          let v454_12: Space = unite(&(v454_7),&(v454_11));
          join_wrapped_into(&mut v453_3_write,&((v454_12).read_zipper()),&[]);
          }
          v453_3_cursor.ascend(1);
        }
        drop(v453_3_cursor);
        drop(v453_3_write);
        drop(v453_2);
        let v453_4: Space = unite(&(v453_3),&(v452_6));
        let v453_5: Space = intersect(&(v453_4),&(*capture_2));
        if !v452_6.join_into((v453_5).clone()).is_element() { break; }
      }
      let v452_7: Space = subtract(&(*capture_2),&(v452_6));
      let mut v452_8: Space = ((*capture_5)).clone();
      loop {
        let v471_1: Space = intersect(&(v452_8),&(*capture_2));
        let v471_2: Space = restrict_to(&(*capture_0),&(v471_1));
        drop(v471_1);
        let mut v471_3 = Space::new();
        let mut v471_3_write = v471_3.write_zipper();
        let mut v471_3_cursor = (v471_2).read_zipper();
        let v471_3_origin = v471_3_cursor.path().len();
        for v471_3_byte in v471_3_cursor.child_mask().iter() {
          v471_3_cursor.descend_to_existing_byte(v471_3_byte);
          {
          let v472_2: Space = singleton(&v471_3_cursor.path()[v471_3_origin..(v471_3_origin + 1)]);
          let v472_3: Space = intersect(&(*CONSTANT_12),&(v472_2));
          let v472_4: Space = if has_head(&(v472_3)) { singleton(&[]) } else { Space::new() };
          drop(v472_3);
          let v472_5: Space = subtract(&(*CONSTANT_0),&(v472_4));
          drop(v472_4);
          let v472_7: Space = if (&(v472_5)).is_empty() { Space::new() } else {
            let mut v473_6 = Space::new();
            let mut v473_6_write = v473_6.write_zipper();
            for v473_6_byte in v471_3_cursor.child_mask().iter() {
              v471_3_cursor.descend_to_existing_byte(v473_6_byte);
              {
              let v474_2: Space = singleton(&v471_3_cursor.path()[(v471_3_origin + 1)..(v471_3_origin + 2)]);
              let v474_3: Space = intersect(&(*CONSTANT_12),&(v474_2));
              let v474_4: Space = if has_head(&(v474_3)) { singleton(&[]) } else { Space::new() };
              drop(v474_3);
              let v474_5: Space = subtract(&(*CONSTANT_0),&(v474_4));
              drop(v474_4);
              let v474_8: Space = if (&(v474_5)).is_empty() { Space::new() } else {
                let mut v475_7 = Space::new();
                let mut v475_7_write = v475_7.write_zipper();
                for v475_7_byte in v471_3_cursor.child_mask().iter() {
                  v471_3_cursor.descend_to_existing_byte(v475_7_byte);
                  {
                  let v476_2: Space = singleton(&v471_3_cursor.path()[(v471_3_origin + 2)..(v471_3_origin + 3)]);
                  let v476_3: Space = intersect(&(*CONSTANT_12),&(v476_2));
                  let v476_4: Space = if has_head(&(v476_3)) { singleton(&[]) } else { Space::new() };
                  drop(v476_3);
                  let v476_5: Space = subtract(&(*CONSTANT_0),&(v476_4));
                  drop(v476_4);
                  let v476_8: Space = if (&(v476_5)).is_empty() { Space::new() } else {
                    let v477_7: Space = routine_41(c, &v471_3_cursor.path()[v471_3_origin..(v471_3_origin + 3)], &v471_3_cursor);
                    compose(&(v476_5),&(v477_7))
                  };
                  drop(v476_5);
                  let v476_9: Space = intersect(&(*CONSTANT_12),&(v476_2));
                  drop(v476_2);
                  let v476_10: Space = if has_head(&(v476_9)) { singleton(&[]) } else { Space::new() };
                  drop(v476_9);
                  let v476_12: Space = if (&(v476_10)).is_empty() { Space::new() } else {
                    let v478_11: Space = routine_42(c, &v471_3_cursor.path()[v471_3_origin..(v471_3_origin + 3)], &v471_3_cursor);
                    compose(&(v476_10),&(v478_11))
                  };
                  drop(v476_10);
                  let v476_13: Space = unite(&(v476_8),&(v476_12));
                  join_wrapped_into(&mut v475_7_write,&((v476_13).read_zipper()),&[]);
                  }
                  v471_3_cursor.ascend(1);
                }
                drop(v475_7_write);
                compose(&(v474_5),&(v475_7))
              };
              drop(v474_5);
              let v474_9: Space = intersect(&(*CONSTANT_12),&(v474_2));
              drop(v474_2);
              let v474_10: Space = if has_head(&(v474_9)) { singleton(&[]) } else { Space::new() };
              drop(v474_9);
              let v474_12: Space = if (&(v474_10)).is_empty() { Space::new() } else {
                let mut v479_11 = Space::new();
                let mut v479_11_write = v479_11.write_zipper();
                for v479_11_byte in v471_3_cursor.child_mask().iter() {
                  v471_3_cursor.descend_to_existing_byte(v479_11_byte);
                  {
                  let v480_2: Space = singleton(&v471_3_cursor.path()[(v471_3_origin + 2)..(v471_3_origin + 3)]);
                  let v480_3: Space = intersect(&(*CONSTANT_12),&(v480_2));
                  let v480_4: Space = if has_head(&(v480_3)) { singleton(&[]) } else { Space::new() };
                  drop(v480_3);
                  let v480_5: Space = subtract(&(*CONSTANT_0),&(v480_4));
                  drop(v480_4);
                  let v480_8: Space = if (&(v480_5)).is_empty() { Space::new() } else {
                    let v481_7: Space = routine_41(c, &v471_3_cursor.path()[v471_3_origin..(v471_3_origin + 3)], &v471_3_cursor);
                    compose(&(v480_5),&(v481_7))
                  };
                  drop(v480_5);
                  let v480_9: Space = intersect(&(*CONSTANT_12),&(v480_2));
                  drop(v480_2);
                  let v480_10: Space = if has_head(&(v480_9)) { singleton(&[]) } else { Space::new() };
                  drop(v480_9);
                  let v480_12: Space = if (&(v480_10)).is_empty() { Space::new() } else {
                    let v482_11: Space = routine_43(c, &v471_3_cursor.path()[v471_3_origin..(v471_3_origin + 3)], &v471_3_cursor);
                    compose(&(v480_10),&(v482_11))
                  };
                  drop(v480_10);
                  let v480_13: Space = unite(&(v480_8),&(v480_12));
                  join_wrapped_into(&mut v479_11_write,&((v480_13).read_zipper()),&[]);
                  }
                  v471_3_cursor.ascend(1);
                }
                drop(v479_11_write);
                compose(&(v474_10),&(v479_11))
              };
              drop(v474_10);
              let v474_13: Space = unite(&(v474_8),&(v474_12));
              join_wrapped_into(&mut v473_6_write,&((v474_13).read_zipper()),&[]);
              }
              v471_3_cursor.ascend(1);
            }
            drop(v473_6_write);
            compose(&(v472_5),&(v473_6))
          };
          drop(v472_5);
          let v472_8: Space = intersect(&(*CONSTANT_12),&(v472_2));
          drop(v472_2);
          let v472_9: Space = if has_head(&(v472_8)) { singleton(&[]) } else { Space::new() };
          drop(v472_8);
          let v472_11: Space = if (&(v472_9)).is_empty() { Space::new() } else {
            let mut v483_10 = Space::new();
            let mut v483_10_write = v483_10.write_zipper();
            for v483_10_byte in v471_3_cursor.child_mask().iter() {
              v471_3_cursor.descend_to_existing_byte(v483_10_byte);
              {
              let v484_2: Space = singleton(&v471_3_cursor.path()[(v471_3_origin + 1)..(v471_3_origin + 2)]);
              let v484_3: Space = intersect(&(*CONSTANT_12),&(v484_2));
              let v484_4: Space = if has_head(&(v484_3)) { singleton(&[]) } else { Space::new() };
              drop(v484_3);
              let v484_5: Space = subtract(&(*CONSTANT_0),&(v484_4));
              drop(v484_4);
              let v484_8: Space = if (&(v484_5)).is_empty() { Space::new() } else {
                let mut v485_7 = Space::new();
                let mut v485_7_write = v485_7.write_zipper();
                for v485_7_byte in v471_3_cursor.child_mask().iter() {
                  v471_3_cursor.descend_to_existing_byte(v485_7_byte);
                  {
                  let v486_2: Space = singleton(&v471_3_cursor.path()[(v471_3_origin + 2)..(v471_3_origin + 3)]);
                  let v486_3: Space = intersect(&(*CONSTANT_12),&(v486_2));
                  let v486_4: Space = if has_head(&(v486_3)) { singleton(&[]) } else { Space::new() };
                  drop(v486_3);
                  let v486_5: Space = subtract(&(*CONSTANT_0),&(v486_4));
                  drop(v486_4);
                  let v486_8: Space = if (&(v486_5)).is_empty() { Space::new() } else {
                    let v487_7: Space = routine_41(c, &v471_3_cursor.path()[v471_3_origin..(v471_3_origin + 3)], &v471_3_cursor);
                    compose(&(v486_5),&(v487_7))
                  };
                  drop(v486_5);
                  let v486_9: Space = intersect(&(*CONSTANT_12),&(v486_2));
                  drop(v486_2);
                  let v486_10: Space = if has_head(&(v486_9)) { singleton(&[]) } else { Space::new() };
                  drop(v486_9);
                  let v486_12: Space = if (&(v486_10)).is_empty() { Space::new() } else {
                    let v488_11: Space = routine_42(c, &v471_3_cursor.path()[v471_3_origin..(v471_3_origin + 3)], &v471_3_cursor);
                    compose(&(v486_10),&(v488_11))
                  };
                  drop(v486_10);
                  let v486_13: Space = unite(&(v486_8),&(v486_12));
                  join_wrapped_into(&mut v485_7_write,&((v486_13).read_zipper()),&[]);
                  }
                  v471_3_cursor.ascend(1);
                }
                drop(v485_7_write);
                compose(&(v484_5),&(v485_7))
              };
              drop(v484_5);
              let v484_9: Space = intersect(&(*CONSTANT_12),&(v484_2));
              drop(v484_2);
              let v484_10: Space = if has_head(&(v484_9)) { singleton(&[]) } else { Space::new() };
              drop(v484_9);
              let v484_11: Space = compose(&(v484_10),&v471_3_cursor);
              drop(v484_10);
              let v484_12: Space = unite(&(v484_8),&(v484_11));
              drop(v484_11);
              join_wrapped_into(&mut v483_10_write,&((v484_12).read_zipper()),&[]);
              }
              v471_3_cursor.ascend(1);
            }
            drop(v483_10_write);
            compose(&(v472_9),&(v483_10))
          };
          drop(v472_9);
          let v472_12: Space = unite(&(v472_7),&(v472_11));
          join_wrapped_into(&mut v471_3_write,&((v472_12).read_zipper()),&[]);
          }
          v471_3_cursor.ascend(1);
        }
        drop(v471_3_cursor);
        drop(v471_3_write);
        drop(v471_2);
        let v471_4: Space = unite(&(v471_3),&(v452_8));
        let v471_5: Space = intersect(&(v471_4),&(*capture_2));
        if !v452_8.join_into((v471_5).clone()).is_element() { break; }
      }
      let v452_9: Space = subtract(&(v452_7),&(v452_8));
      let v452_10: Space = routine_16(c, &(*capture_3).path()[capture_4..(capture_4 + 1)], &(*capture_3), &(*capture_0), &(*capture_1), &((v452_9).read_zipper()));
      compose(&(v451_5),&(v452_10))
    };
    drop(v451_5);
    let v451_12: Space = intersect(&(*CONSTANT_12),&(v451_2));
    drop(v451_2);
    let v451_13: Space = if has_head(&(v451_12)) { singleton(&[]) } else { Space::new() };
    drop(v451_12);
    let v451_19: Space = if (&(v451_13)).is_empty() { Space::new() } else {
      let mut v489_14: Space = ((*capture_5)).clone();
      loop {
        let v490_1: Space = intersect(&(v489_14),&(*capture_2));
        let v490_2: Space = restrict_to(&(*capture_1),&(v490_1));
        drop(v490_1);
        let mut v490_3 = Space::new();
        let mut v490_3_write = v490_3.write_zipper();
        let mut v490_3_cursor = (v490_2).read_zipper();
        let v490_3_origin = v490_3_cursor.path().len();
        for v490_3_byte in v490_3_cursor.child_mask().iter() {
          v490_3_cursor.descend_to_existing_byte(v490_3_byte);
          {
          let v491_2: Space = singleton(&v490_3_cursor.path()[v490_3_origin..(v490_3_origin + 1)]);
          let v491_3: Space = intersect(&(*CONSTANT_12),&(v491_2));
          let v491_4: Space = if has_head(&(v491_3)) { singleton(&[]) } else { Space::new() };
          drop(v491_3);
          let v491_5: Space = subtract(&(*CONSTANT_0),&(v491_4));
          drop(v491_4);
          let v491_7: Space = if (&(v491_5)).is_empty() { Space::new() } else {
            let mut v492_6 = Space::new();
            let mut v492_6_write = v492_6.write_zipper();
            for v492_6_byte in v490_3_cursor.child_mask().iter() {
              v490_3_cursor.descend_to_existing_byte(v492_6_byte);
              {
              let v493_2: Space = singleton(&v490_3_cursor.path()[(v490_3_origin + 1)..(v490_3_origin + 2)]);
              let v493_3: Space = intersect(&(*CONSTANT_12),&(v493_2));
              let v493_4: Space = if has_head(&(v493_3)) { singleton(&[]) } else { Space::new() };
              drop(v493_3);
              let v493_5: Space = subtract(&(*CONSTANT_0),&(v493_4));
              drop(v493_4);
              let v493_8: Space = if (&(v493_5)).is_empty() { Space::new() } else {
                let mut v494_7 = Space::new();
                let mut v494_7_write = v494_7.write_zipper();
                for v494_7_byte in v490_3_cursor.child_mask().iter() {
                  v490_3_cursor.descend_to_existing_byte(v494_7_byte);
                  {
                  let v495_2: Space = singleton(&v490_3_cursor.path()[(v490_3_origin + 2)..(v490_3_origin + 3)]);
                  let v495_3: Space = intersect(&(*CONSTANT_12),&(v495_2));
                  let v495_4: Space = if has_head(&(v495_3)) { singleton(&[]) } else { Space::new() };
                  drop(v495_3);
                  let v495_5: Space = subtract(&(*CONSTANT_0),&(v495_4));
                  drop(v495_4);
                  let v495_8: Space = if (&(v495_5)).is_empty() { Space::new() } else {
                    let v496_7: Space = routine_41(c, &v490_3_cursor.path()[v490_3_origin..(v490_3_origin + 3)], &v490_3_cursor);
                    compose(&(v495_5),&(v496_7))
                  };
                  drop(v495_5);
                  let v495_9: Space = intersect(&(*CONSTANT_12),&(v495_2));
                  drop(v495_2);
                  let v495_10: Space = if has_head(&(v495_9)) { singleton(&[]) } else { Space::new() };
                  drop(v495_9);
                  let v495_12: Space = if (&(v495_10)).is_empty() { Space::new() } else {
                    let v497_11: Space = routine_42(c, &v490_3_cursor.path()[v490_3_origin..(v490_3_origin + 3)], &v490_3_cursor);
                    compose(&(v495_10),&(v497_11))
                  };
                  drop(v495_10);
                  let v495_13: Space = unite(&(v495_8),&(v495_12));
                  join_wrapped_into(&mut v494_7_write,&((v495_13).read_zipper()),&[]);
                  }
                  v490_3_cursor.ascend(1);
                }
                drop(v494_7_write);
                compose(&(v493_5),&(v494_7))
              };
              drop(v493_5);
              let v493_9: Space = intersect(&(*CONSTANT_12),&(v493_2));
              drop(v493_2);
              let v493_10: Space = if has_head(&(v493_9)) { singleton(&[]) } else { Space::new() };
              drop(v493_9);
              let v493_12: Space = if (&(v493_10)).is_empty() { Space::new() } else {
                let mut v498_11 = Space::new();
                let mut v498_11_write = v498_11.write_zipper();
                for v498_11_byte in v490_3_cursor.child_mask().iter() {
                  v490_3_cursor.descend_to_existing_byte(v498_11_byte);
                  {
                  let v499_2: Space = singleton(&v490_3_cursor.path()[(v490_3_origin + 2)..(v490_3_origin + 3)]);
                  let v499_3: Space = intersect(&(*CONSTANT_12),&(v499_2));
                  let v499_4: Space = if has_head(&(v499_3)) { singleton(&[]) } else { Space::new() };
                  drop(v499_3);
                  let v499_5: Space = subtract(&(*CONSTANT_0),&(v499_4));
                  drop(v499_4);
                  let v499_8: Space = if (&(v499_5)).is_empty() { Space::new() } else {
                    let v500_7: Space = routine_41(c, &v490_3_cursor.path()[v490_3_origin..(v490_3_origin + 3)], &v490_3_cursor);
                    compose(&(v499_5),&(v500_7))
                  };
                  drop(v499_5);
                  let v499_9: Space = intersect(&(*CONSTANT_12),&(v499_2));
                  drop(v499_2);
                  let v499_10: Space = if has_head(&(v499_9)) { singleton(&[]) } else { Space::new() };
                  drop(v499_9);
                  let v499_12: Space = if (&(v499_10)).is_empty() { Space::new() } else {
                    let v501_11: Space = routine_43(c, &v490_3_cursor.path()[v490_3_origin..(v490_3_origin + 3)], &v490_3_cursor);
                    compose(&(v499_10),&(v501_11))
                  };
                  drop(v499_10);
                  let v499_13: Space = unite(&(v499_8),&(v499_12));
                  join_wrapped_into(&mut v498_11_write,&((v499_13).read_zipper()),&[]);
                  }
                  v490_3_cursor.ascend(1);
                }
                drop(v498_11_write);
                compose(&(v493_10),&(v498_11))
              };
              drop(v493_10);
              let v493_13: Space = unite(&(v493_8),&(v493_12));
              join_wrapped_into(&mut v492_6_write,&((v493_13).read_zipper()),&[]);
              }
              v490_3_cursor.ascend(1);
            }
            drop(v492_6_write);
            compose(&(v491_5),&(v492_6))
          };
          drop(v491_5);
          let v491_8: Space = intersect(&(*CONSTANT_12),&(v491_2));
          drop(v491_2);
          let v491_9: Space = if has_head(&(v491_8)) { singleton(&[]) } else { Space::new() };
          drop(v491_8);
          let v491_11: Space = if (&(v491_9)).is_empty() { Space::new() } else {
            let mut v502_10 = Space::new();
            let mut v502_10_write = v502_10.write_zipper();
            for v502_10_byte in v490_3_cursor.child_mask().iter() {
              v490_3_cursor.descend_to_existing_byte(v502_10_byte);
              {
              let v503_2: Space = singleton(&v490_3_cursor.path()[(v490_3_origin + 1)..(v490_3_origin + 2)]);
              let v503_3: Space = intersect(&(*CONSTANT_12),&(v503_2));
              let v503_4: Space = if has_head(&(v503_3)) { singleton(&[]) } else { Space::new() };
              drop(v503_3);
              let v503_5: Space = subtract(&(*CONSTANT_0),&(v503_4));
              drop(v503_4);
              let v503_8: Space = if (&(v503_5)).is_empty() { Space::new() } else {
                let mut v504_7 = Space::new();
                let mut v504_7_write = v504_7.write_zipper();
                for v504_7_byte in v490_3_cursor.child_mask().iter() {
                  v490_3_cursor.descend_to_existing_byte(v504_7_byte);
                  {
                  let v505_2: Space = singleton(&v490_3_cursor.path()[(v490_3_origin + 2)..(v490_3_origin + 3)]);
                  let v505_3: Space = intersect(&(*CONSTANT_12),&(v505_2));
                  let v505_4: Space = if has_head(&(v505_3)) { singleton(&[]) } else { Space::new() };
                  drop(v505_3);
                  let v505_5: Space = subtract(&(*CONSTANT_0),&(v505_4));
                  drop(v505_4);
                  let v505_8: Space = if (&(v505_5)).is_empty() { Space::new() } else {
                    let v506_7: Space = routine_41(c, &v490_3_cursor.path()[v490_3_origin..(v490_3_origin + 3)], &v490_3_cursor);
                    compose(&(v505_5),&(v506_7))
                  };
                  drop(v505_5);
                  let v505_9: Space = intersect(&(*CONSTANT_12),&(v505_2));
                  drop(v505_2);
                  let v505_10: Space = if has_head(&(v505_9)) { singleton(&[]) } else { Space::new() };
                  drop(v505_9);
                  let v505_12: Space = if (&(v505_10)).is_empty() { Space::new() } else {
                    let v507_11: Space = routine_42(c, &v490_3_cursor.path()[v490_3_origin..(v490_3_origin + 3)], &v490_3_cursor);
                    compose(&(v505_10),&(v507_11))
                  };
                  drop(v505_10);
                  let v505_13: Space = unite(&(v505_8),&(v505_12));
                  join_wrapped_into(&mut v504_7_write,&((v505_13).read_zipper()),&[]);
                  }
                  v490_3_cursor.ascend(1);
                }
                drop(v504_7_write);
                compose(&(v503_5),&(v504_7))
              };
              drop(v503_5);
              let v503_9: Space = intersect(&(*CONSTANT_12),&(v503_2));
              drop(v503_2);
              let v503_10: Space = if has_head(&(v503_9)) { singleton(&[]) } else { Space::new() };
              drop(v503_9);
              let v503_11: Space = compose(&(v503_10),&v490_3_cursor);
              drop(v503_10);
              let v503_12: Space = unite(&(v503_8),&(v503_11));
              drop(v503_11);
              join_wrapped_into(&mut v502_10_write,&((v503_12).read_zipper()),&[]);
              }
              v490_3_cursor.ascend(1);
            }
            drop(v502_10_write);
            compose(&(v491_9),&(v502_10))
          };
          drop(v491_9);
          let v491_12: Space = unite(&(v491_7),&(v491_11));
          join_wrapped_into(&mut v490_3_write,&((v491_12).read_zipper()),&[]);
          }
          v490_3_cursor.ascend(1);
        }
        drop(v490_3_cursor);
        drop(v490_3_write);
        drop(v490_2);
        let v490_4: Space = unite(&(v490_3),&(v489_14));
        let v490_5: Space = intersect(&(v490_4),&(*capture_2));
        if !v489_14.join_into((v490_5).clone()).is_element() { break; }
      }
      let v489_15: Space = subtract(&(*capture_2),&(v489_14));
      let mut v489_16: Space = ((*capture_5)).clone();
      loop {
        let v508_1: Space = intersect(&(v489_16),&(*capture_2));
        let v508_2: Space = restrict_to(&(*capture_0),&(v508_1));
        drop(v508_1);
        let mut v508_3 = Space::new();
        let mut v508_3_write = v508_3.write_zipper();
        let mut v508_3_cursor = (v508_2).read_zipper();
        let v508_3_origin = v508_3_cursor.path().len();
        for v508_3_byte in v508_3_cursor.child_mask().iter() {
          v508_3_cursor.descend_to_existing_byte(v508_3_byte);
          {
          let v509_2: Space = singleton(&v508_3_cursor.path()[v508_3_origin..(v508_3_origin + 1)]);
          let v509_3: Space = intersect(&(*CONSTANT_12),&(v509_2));
          let v509_4: Space = if has_head(&(v509_3)) { singleton(&[]) } else { Space::new() };
          drop(v509_3);
          let v509_5: Space = subtract(&(*CONSTANT_0),&(v509_4));
          drop(v509_4);
          let v509_7: Space = if (&(v509_5)).is_empty() { Space::new() } else {
            let mut v510_6 = Space::new();
            let mut v510_6_write = v510_6.write_zipper();
            for v510_6_byte in v508_3_cursor.child_mask().iter() {
              v508_3_cursor.descend_to_existing_byte(v510_6_byte);
              {
              let v511_2: Space = singleton(&v508_3_cursor.path()[(v508_3_origin + 1)..(v508_3_origin + 2)]);
              let v511_3: Space = intersect(&(*CONSTANT_12),&(v511_2));
              let v511_4: Space = if has_head(&(v511_3)) { singleton(&[]) } else { Space::new() };
              drop(v511_3);
              let v511_5: Space = subtract(&(*CONSTANT_0),&(v511_4));
              drop(v511_4);
              let v511_8: Space = if (&(v511_5)).is_empty() { Space::new() } else {
                let mut v512_7 = Space::new();
                let mut v512_7_write = v512_7.write_zipper();
                for v512_7_byte in v508_3_cursor.child_mask().iter() {
                  v508_3_cursor.descend_to_existing_byte(v512_7_byte);
                  {
                  let v513_2: Space = singleton(&v508_3_cursor.path()[(v508_3_origin + 2)..(v508_3_origin + 3)]);
                  let v513_3: Space = intersect(&(*CONSTANT_12),&(v513_2));
                  let v513_4: Space = if has_head(&(v513_3)) { singleton(&[]) } else { Space::new() };
                  drop(v513_3);
                  let v513_5: Space = subtract(&(*CONSTANT_0),&(v513_4));
                  drop(v513_4);
                  let v513_8: Space = if (&(v513_5)).is_empty() { Space::new() } else {
                    let v514_7: Space = routine_41(c, &v508_3_cursor.path()[v508_3_origin..(v508_3_origin + 3)], &v508_3_cursor);
                    compose(&(v513_5),&(v514_7))
                  };
                  drop(v513_5);
                  let v513_9: Space = intersect(&(*CONSTANT_12),&(v513_2));
                  drop(v513_2);
                  let v513_10: Space = if has_head(&(v513_9)) { singleton(&[]) } else { Space::new() };
                  drop(v513_9);
                  let v513_12: Space = if (&(v513_10)).is_empty() { Space::new() } else {
                    let v515_11: Space = routine_42(c, &v508_3_cursor.path()[v508_3_origin..(v508_3_origin + 3)], &v508_3_cursor);
                    compose(&(v513_10),&(v515_11))
                  };
                  drop(v513_10);
                  let v513_13: Space = unite(&(v513_8),&(v513_12));
                  join_wrapped_into(&mut v512_7_write,&((v513_13).read_zipper()),&[]);
                  }
                  v508_3_cursor.ascend(1);
                }
                drop(v512_7_write);
                compose(&(v511_5),&(v512_7))
              };
              drop(v511_5);
              let v511_9: Space = intersect(&(*CONSTANT_12),&(v511_2));
              drop(v511_2);
              let v511_10: Space = if has_head(&(v511_9)) { singleton(&[]) } else { Space::new() };
              drop(v511_9);
              let v511_12: Space = if (&(v511_10)).is_empty() { Space::new() } else {
                let mut v516_11 = Space::new();
                let mut v516_11_write = v516_11.write_zipper();
                for v516_11_byte in v508_3_cursor.child_mask().iter() {
                  v508_3_cursor.descend_to_existing_byte(v516_11_byte);
                  {
                  let v517_2: Space = singleton(&v508_3_cursor.path()[(v508_3_origin + 2)..(v508_3_origin + 3)]);
                  let v517_3: Space = intersect(&(*CONSTANT_12),&(v517_2));
                  let v517_4: Space = if has_head(&(v517_3)) { singleton(&[]) } else { Space::new() };
                  drop(v517_3);
                  let v517_5: Space = subtract(&(*CONSTANT_0),&(v517_4));
                  drop(v517_4);
                  let v517_8: Space = if (&(v517_5)).is_empty() { Space::new() } else {
                    let v518_7: Space = routine_41(c, &v508_3_cursor.path()[v508_3_origin..(v508_3_origin + 3)], &v508_3_cursor);
                    compose(&(v517_5),&(v518_7))
                  };
                  drop(v517_5);
                  let v517_9: Space = intersect(&(*CONSTANT_12),&(v517_2));
                  drop(v517_2);
                  let v517_10: Space = if has_head(&(v517_9)) { singleton(&[]) } else { Space::new() };
                  drop(v517_9);
                  let v517_12: Space = if (&(v517_10)).is_empty() { Space::new() } else {
                    let v519_11: Space = routine_43(c, &v508_3_cursor.path()[v508_3_origin..(v508_3_origin + 3)], &v508_3_cursor);
                    compose(&(v517_10),&(v519_11))
                  };
                  drop(v517_10);
                  let v517_13: Space = unite(&(v517_8),&(v517_12));
                  join_wrapped_into(&mut v516_11_write,&((v517_13).read_zipper()),&[]);
                  }
                  v508_3_cursor.ascend(1);
                }
                drop(v516_11_write);
                compose(&(v511_10),&(v516_11))
              };
              drop(v511_10);
              let v511_13: Space = unite(&(v511_8),&(v511_12));
              join_wrapped_into(&mut v510_6_write,&((v511_13).read_zipper()),&[]);
              }
              v508_3_cursor.ascend(1);
            }
            drop(v510_6_write);
            compose(&(v509_5),&(v510_6))
          };
          drop(v509_5);
          let v509_8: Space = intersect(&(*CONSTANT_12),&(v509_2));
          drop(v509_2);
          let v509_9: Space = if has_head(&(v509_8)) { singleton(&[]) } else { Space::new() };
          drop(v509_8);
          let v509_11: Space = if (&(v509_9)).is_empty() { Space::new() } else {
            let mut v520_10 = Space::new();
            let mut v520_10_write = v520_10.write_zipper();
            for v520_10_byte in v508_3_cursor.child_mask().iter() {
              v508_3_cursor.descend_to_existing_byte(v520_10_byte);
              {
              let v521_2: Space = singleton(&v508_3_cursor.path()[(v508_3_origin + 1)..(v508_3_origin + 2)]);
              let v521_3: Space = intersect(&(*CONSTANT_12),&(v521_2));
              let v521_4: Space = if has_head(&(v521_3)) { singleton(&[]) } else { Space::new() };
              drop(v521_3);
              let v521_5: Space = subtract(&(*CONSTANT_0),&(v521_4));
              drop(v521_4);
              let v521_8: Space = if (&(v521_5)).is_empty() { Space::new() } else {
                let mut v522_7 = Space::new();
                let mut v522_7_write = v522_7.write_zipper();
                for v522_7_byte in v508_3_cursor.child_mask().iter() {
                  v508_3_cursor.descend_to_existing_byte(v522_7_byte);
                  {
                  let v523_2: Space = singleton(&v508_3_cursor.path()[(v508_3_origin + 2)..(v508_3_origin + 3)]);
                  let v523_3: Space = intersect(&(*CONSTANT_12),&(v523_2));
                  let v523_4: Space = if has_head(&(v523_3)) { singleton(&[]) } else { Space::new() };
                  drop(v523_3);
                  let v523_5: Space = subtract(&(*CONSTANT_0),&(v523_4));
                  drop(v523_4);
                  let v523_8: Space = if (&(v523_5)).is_empty() { Space::new() } else {
                    let v524_7: Space = routine_41(c, &v508_3_cursor.path()[v508_3_origin..(v508_3_origin + 3)], &v508_3_cursor);
                    compose(&(v523_5),&(v524_7))
                  };
                  drop(v523_5);
                  let v523_9: Space = intersect(&(*CONSTANT_12),&(v523_2));
                  drop(v523_2);
                  let v523_10: Space = if has_head(&(v523_9)) { singleton(&[]) } else { Space::new() };
                  drop(v523_9);
                  let v523_12: Space = if (&(v523_10)).is_empty() { Space::new() } else {
                    let v525_11: Space = routine_42(c, &v508_3_cursor.path()[v508_3_origin..(v508_3_origin + 3)], &v508_3_cursor);
                    compose(&(v523_10),&(v525_11))
                  };
                  drop(v523_10);
                  let v523_13: Space = unite(&(v523_8),&(v523_12));
                  join_wrapped_into(&mut v522_7_write,&((v523_13).read_zipper()),&[]);
                  }
                  v508_3_cursor.ascend(1);
                }
                drop(v522_7_write);
                compose(&(v521_5),&(v522_7))
              };
              drop(v521_5);
              let v521_9: Space = intersect(&(*CONSTANT_12),&(v521_2));
              drop(v521_2);
              let v521_10: Space = if has_head(&(v521_9)) { singleton(&[]) } else { Space::new() };
              drop(v521_9);
              let v521_11: Space = compose(&(v521_10),&v508_3_cursor);
              drop(v521_10);
              let v521_12: Space = unite(&(v521_8),&(v521_11));
              drop(v521_11);
              join_wrapped_into(&mut v520_10_write,&((v521_12).read_zipper()),&[]);
              }
              v508_3_cursor.ascend(1);
            }
            drop(v520_10_write);
            compose(&(v509_9),&(v520_10))
          };
          drop(v509_9);
          let v509_12: Space = unite(&(v509_7),&(v509_11));
          join_wrapped_into(&mut v508_3_write,&((v509_12).read_zipper()),&[]);
          }
          v508_3_cursor.ascend(1);
        }
        drop(v508_3_cursor);
        drop(v508_3_write);
        drop(v508_2);
        let v508_4: Space = unite(&(v508_3),&(v489_16));
        let v508_5: Space = intersect(&(v508_4),&(*capture_2));
        if !v489_16.join_into((v508_5).clone()).is_element() { break; }
      }
      let v489_17: Space = subtract(&(v489_15),&(v489_16));
      let v489_18: Space = routine_17(c, &(*capture_3).path()[capture_4..(capture_4 + 1)], &(*capture_3), &(*capture_0), &(*capture_1), &((v489_17).read_zipper()));
      compose(&(v451_13),&(v489_18))
    };
    drop(v451_13);

((v451_11).clone(),(v451_19).clone(),)
}

#[inline(never)]
fn native_block_3(c: &mut Context,capture_0: &View<'_, '_>,capture_1: &View<'_, '_>,capture_2: &View<'_, '_>,capture_3: &View<'_, '_>,capture_4: usize,capture_5: &Space) -> (Space,Space,) {
    let v562_2: Space = singleton(&(*capture_3).path()[capture_4..(capture_4 + 1)]);
    let v562_3: Space = intersect(&(*CONSTANT_12),&(v562_2));
    let v562_4: Space = if has_head(&(v562_3)) { singleton(&[]) } else { Space::new() };
    drop(v562_3);
    let v562_5: Space = subtract(&(*CONSTANT_0),&(v562_4));
    drop(v562_4);
    let v562_10: Space = if (&(v562_5)).is_empty() { Space::new() } else {
      let mut v563_6: Space = ((*capture_5)).clone();
      loop {
        let v564_1: Space = intersect(&(v563_6),&(*capture_2));
        let v564_2: Space = restrict_to(&(*capture_0),&(v564_1));
        drop(v564_1);
        let mut v564_3 = Space::new();
        let mut v564_3_write = v564_3.write_zipper();
        let mut v564_3_cursor = (v564_2).read_zipper();
        let v564_3_origin = v564_3_cursor.path().len();
        for v564_3_byte in v564_3_cursor.child_mask().iter() {
          v564_3_cursor.descend_to_existing_byte(v564_3_byte);
          {
          let v565_2: Space = singleton(&v564_3_cursor.path()[v564_3_origin..(v564_3_origin + 1)]);
          let v565_3: Space = intersect(&(*CONSTANT_12),&(v565_2));
          let v565_4: Space = if has_head(&(v565_3)) { singleton(&[]) } else { Space::new() };
          drop(v565_3);
          let v565_5: Space = subtract(&(*CONSTANT_0),&(v565_4));
          drop(v565_4);
          let v565_7: Space = if (&(v565_5)).is_empty() { Space::new() } else {
            let mut v566_6 = Space::new();
            let mut v566_6_write = v566_6.write_zipper();
            for v566_6_byte in v564_3_cursor.child_mask().iter() {
              v564_3_cursor.descend_to_existing_byte(v566_6_byte);
              {
              let v567_2: Space = singleton(&v564_3_cursor.path()[(v564_3_origin + 1)..(v564_3_origin + 2)]);
              let v567_3: Space = intersect(&(*CONSTANT_12),&(v567_2));
              let v567_4: Space = if has_head(&(v567_3)) { singleton(&[]) } else { Space::new() };
              drop(v567_3);
              let v567_5: Space = subtract(&(*CONSTANT_0),&(v567_4));
              drop(v567_4);
              let v567_8: Space = if (&(v567_5)).is_empty() { Space::new() } else {
                let mut v568_7 = Space::new();
                let mut v568_7_write = v568_7.write_zipper();
                for v568_7_byte in v564_3_cursor.child_mask().iter() {
                  v564_3_cursor.descend_to_existing_byte(v568_7_byte);
                  {
                  let v569_2: Space = singleton(&v564_3_cursor.path()[(v564_3_origin + 2)..(v564_3_origin + 3)]);
                  let v569_3: Space = intersect(&(*CONSTANT_12),&(v569_2));
                  let v569_4: Space = if has_head(&(v569_3)) { singleton(&[]) } else { Space::new() };
                  drop(v569_3);
                  let v569_5: Space = subtract(&(*CONSTANT_0),&(v569_4));
                  drop(v569_4);
                  let v569_8: Space = if (&(v569_5)).is_empty() { Space::new() } else {
                    let v570_7: Space = routine_41(c, &v564_3_cursor.path()[v564_3_origin..(v564_3_origin + 3)], &v564_3_cursor);
                    compose(&(v569_5),&(v570_7))
                  };
                  drop(v569_5);
                  let v569_9: Space = intersect(&(*CONSTANT_12),&(v569_2));
                  drop(v569_2);
                  let v569_10: Space = if has_head(&(v569_9)) { singleton(&[]) } else { Space::new() };
                  drop(v569_9);
                  let v569_12: Space = if (&(v569_10)).is_empty() { Space::new() } else {
                    let v571_11: Space = routine_42(c, &v564_3_cursor.path()[v564_3_origin..(v564_3_origin + 3)], &v564_3_cursor);
                    compose(&(v569_10),&(v571_11))
                  };
                  drop(v569_10);
                  let v569_13: Space = unite(&(v569_8),&(v569_12));
                  join_wrapped_into(&mut v568_7_write,&((v569_13).read_zipper()),&[]);
                  }
                  v564_3_cursor.ascend(1);
                }
                drop(v568_7_write);
                compose(&(v567_5),&(v568_7))
              };
              drop(v567_5);
              let v567_9: Space = intersect(&(*CONSTANT_12),&(v567_2));
              drop(v567_2);
              let v567_10: Space = if has_head(&(v567_9)) { singleton(&[]) } else { Space::new() };
              drop(v567_9);
              let v567_12: Space = if (&(v567_10)).is_empty() { Space::new() } else {
                let mut v572_11 = Space::new();
                let mut v572_11_write = v572_11.write_zipper();
                for v572_11_byte in v564_3_cursor.child_mask().iter() {
                  v564_3_cursor.descend_to_existing_byte(v572_11_byte);
                  {
                  let v573_2: Space = singleton(&v564_3_cursor.path()[(v564_3_origin + 2)..(v564_3_origin + 3)]);
                  let v573_3: Space = intersect(&(*CONSTANT_12),&(v573_2));
                  let v573_4: Space = if has_head(&(v573_3)) { singleton(&[]) } else { Space::new() };
                  drop(v573_3);
                  let v573_5: Space = subtract(&(*CONSTANT_0),&(v573_4));
                  drop(v573_4);
                  let v573_8: Space = if (&(v573_5)).is_empty() { Space::new() } else {
                    let v574_7: Space = routine_41(c, &v564_3_cursor.path()[v564_3_origin..(v564_3_origin + 3)], &v564_3_cursor);
                    compose(&(v573_5),&(v574_7))
                  };
                  drop(v573_5);
                  let v573_9: Space = intersect(&(*CONSTANT_12),&(v573_2));
                  drop(v573_2);
                  let v573_10: Space = if has_head(&(v573_9)) { singleton(&[]) } else { Space::new() };
                  drop(v573_9);
                  let v573_12: Space = if (&(v573_10)).is_empty() { Space::new() } else {
                    let v575_11: Space = routine_43(c, &v564_3_cursor.path()[v564_3_origin..(v564_3_origin + 3)], &v564_3_cursor);
                    compose(&(v573_10),&(v575_11))
                  };
                  drop(v573_10);
                  let v573_13: Space = unite(&(v573_8),&(v573_12));
                  join_wrapped_into(&mut v572_11_write,&((v573_13).read_zipper()),&[]);
                  }
                  v564_3_cursor.ascend(1);
                }
                drop(v572_11_write);
                compose(&(v567_10),&(v572_11))
              };
              drop(v567_10);
              let v567_13: Space = unite(&(v567_8),&(v567_12));
              join_wrapped_into(&mut v566_6_write,&((v567_13).read_zipper()),&[]);
              }
              v564_3_cursor.ascend(1);
            }
            drop(v566_6_write);
            compose(&(v565_5),&(v566_6))
          };
          drop(v565_5);
          let v565_8: Space = intersect(&(*CONSTANT_12),&(v565_2));
          drop(v565_2);
          let v565_9: Space = if has_head(&(v565_8)) { singleton(&[]) } else { Space::new() };
          drop(v565_8);
          let v565_11: Space = if (&(v565_9)).is_empty() { Space::new() } else {
            let mut v576_10 = Space::new();
            let mut v576_10_write = v576_10.write_zipper();
            for v576_10_byte in v564_3_cursor.child_mask().iter() {
              v564_3_cursor.descend_to_existing_byte(v576_10_byte);
              {
              let v577_2: Space = singleton(&v564_3_cursor.path()[(v564_3_origin + 1)..(v564_3_origin + 2)]);
              let v577_3: Space = intersect(&(*CONSTANT_12),&(v577_2));
              let v577_4: Space = if has_head(&(v577_3)) { singleton(&[]) } else { Space::new() };
              drop(v577_3);
              let v577_5: Space = subtract(&(*CONSTANT_0),&(v577_4));
              drop(v577_4);
              let v577_8: Space = if (&(v577_5)).is_empty() { Space::new() } else {
                let mut v578_7 = Space::new();
                let mut v578_7_write = v578_7.write_zipper();
                for v578_7_byte in v564_3_cursor.child_mask().iter() {
                  v564_3_cursor.descend_to_existing_byte(v578_7_byte);
                  {
                  let v579_2: Space = singleton(&v564_3_cursor.path()[(v564_3_origin + 2)..(v564_3_origin + 3)]);
                  let v579_3: Space = intersect(&(*CONSTANT_12),&(v579_2));
                  let v579_4: Space = if has_head(&(v579_3)) { singleton(&[]) } else { Space::new() };
                  drop(v579_3);
                  let v579_5: Space = subtract(&(*CONSTANT_0),&(v579_4));
                  drop(v579_4);
                  let v579_8: Space = if (&(v579_5)).is_empty() { Space::new() } else {
                    let v580_7: Space = routine_41(c, &v564_3_cursor.path()[v564_3_origin..(v564_3_origin + 3)], &v564_3_cursor);
                    compose(&(v579_5),&(v580_7))
                  };
                  drop(v579_5);
                  let v579_9: Space = intersect(&(*CONSTANT_12),&(v579_2));
                  drop(v579_2);
                  let v579_10: Space = if has_head(&(v579_9)) { singleton(&[]) } else { Space::new() };
                  drop(v579_9);
                  let v579_12: Space = if (&(v579_10)).is_empty() { Space::new() } else {
                    let v581_11: Space = routine_42(c, &v564_3_cursor.path()[v564_3_origin..(v564_3_origin + 3)], &v564_3_cursor);
                    compose(&(v579_10),&(v581_11))
                  };
                  drop(v579_10);
                  let v579_13: Space = unite(&(v579_8),&(v579_12));
                  join_wrapped_into(&mut v578_7_write,&((v579_13).read_zipper()),&[]);
                  }
                  v564_3_cursor.ascend(1);
                }
                drop(v578_7_write);
                compose(&(v577_5),&(v578_7))
              };
              drop(v577_5);
              let v577_9: Space = intersect(&(*CONSTANT_12),&(v577_2));
              drop(v577_2);
              let v577_10: Space = if has_head(&(v577_9)) { singleton(&[]) } else { Space::new() };
              drop(v577_9);
              let v577_11: Space = compose(&(v577_10),&v564_3_cursor);
              drop(v577_10);
              let v577_12: Space = unite(&(v577_8),&(v577_11));
              drop(v577_11);
              join_wrapped_into(&mut v576_10_write,&((v577_12).read_zipper()),&[]);
              }
              v564_3_cursor.ascend(1);
            }
            drop(v576_10_write);
            compose(&(v565_9),&(v576_10))
          };
          drop(v565_9);
          let v565_12: Space = unite(&(v565_7),&(v565_11));
          join_wrapped_into(&mut v564_3_write,&((v565_12).read_zipper()),&[]);
          }
          v564_3_cursor.ascend(1);
        }
        drop(v564_3_cursor);
        drop(v564_3_write);
        drop(v564_2);
        let v564_4: Space = unite(&(v564_3),&(v563_6));
        let v564_5: Space = intersect(&(v564_4),&(*capture_2));
        if !v563_6.join_into((v564_5).clone()).is_element() { break; }
      }
      let mut v563_7: Space = ((*capture_5)).clone();
      loop {
        let v582_1: Space = intersect(&(v563_7),&(*capture_2));
        let v582_2: Space = restrict_to(&(*capture_1),&(v582_1));
        drop(v582_1);
        let mut v582_3 = Space::new();
        let mut v582_3_write = v582_3.write_zipper();
        let mut v582_3_cursor = (v582_2).read_zipper();
        let v582_3_origin = v582_3_cursor.path().len();
        for v582_3_byte in v582_3_cursor.child_mask().iter() {
          v582_3_cursor.descend_to_existing_byte(v582_3_byte);
          {
          let v583_2: Space = singleton(&v582_3_cursor.path()[v582_3_origin..(v582_3_origin + 1)]);
          let v583_3: Space = intersect(&(*CONSTANT_12),&(v583_2));
          let v583_4: Space = if has_head(&(v583_3)) { singleton(&[]) } else { Space::new() };
          drop(v583_3);
          let v583_5: Space = subtract(&(*CONSTANT_0),&(v583_4));
          drop(v583_4);
          let v583_7: Space = if (&(v583_5)).is_empty() { Space::new() } else {
            let mut v584_6 = Space::new();
            let mut v584_6_write = v584_6.write_zipper();
            for v584_6_byte in v582_3_cursor.child_mask().iter() {
              v582_3_cursor.descend_to_existing_byte(v584_6_byte);
              {
              let v585_2: Space = singleton(&v582_3_cursor.path()[(v582_3_origin + 1)..(v582_3_origin + 2)]);
              let v585_3: Space = intersect(&(*CONSTANT_12),&(v585_2));
              let v585_4: Space = if has_head(&(v585_3)) { singleton(&[]) } else { Space::new() };
              drop(v585_3);
              let v585_5: Space = subtract(&(*CONSTANT_0),&(v585_4));
              drop(v585_4);
              let v585_8: Space = if (&(v585_5)).is_empty() { Space::new() } else {
                let mut v586_7 = Space::new();
                let mut v586_7_write = v586_7.write_zipper();
                for v586_7_byte in v582_3_cursor.child_mask().iter() {
                  v582_3_cursor.descend_to_existing_byte(v586_7_byte);
                  {
                  let v587_2: Space = singleton(&v582_3_cursor.path()[(v582_3_origin + 2)..(v582_3_origin + 3)]);
                  let v587_3: Space = intersect(&(*CONSTANT_12),&(v587_2));
                  let v587_4: Space = if has_head(&(v587_3)) { singleton(&[]) } else { Space::new() };
                  drop(v587_3);
                  let v587_5: Space = subtract(&(*CONSTANT_0),&(v587_4));
                  drop(v587_4);
                  let v587_8: Space = if (&(v587_5)).is_empty() { Space::new() } else {
                    let v588_7: Space = routine_41(c, &v582_3_cursor.path()[v582_3_origin..(v582_3_origin + 3)], &v582_3_cursor);
                    compose(&(v587_5),&(v588_7))
                  };
                  drop(v587_5);
                  let v587_9: Space = intersect(&(*CONSTANT_12),&(v587_2));
                  drop(v587_2);
                  let v587_10: Space = if has_head(&(v587_9)) { singleton(&[]) } else { Space::new() };
                  drop(v587_9);
                  let v587_12: Space = if (&(v587_10)).is_empty() { Space::new() } else {
                    let v589_11: Space = routine_42(c, &v582_3_cursor.path()[v582_3_origin..(v582_3_origin + 3)], &v582_3_cursor);
                    compose(&(v587_10),&(v589_11))
                  };
                  drop(v587_10);
                  let v587_13: Space = unite(&(v587_8),&(v587_12));
                  join_wrapped_into(&mut v586_7_write,&((v587_13).read_zipper()),&[]);
                  }
                  v582_3_cursor.ascend(1);
                }
                drop(v586_7_write);
                compose(&(v585_5),&(v586_7))
              };
              drop(v585_5);
              let v585_9: Space = intersect(&(*CONSTANT_12),&(v585_2));
              drop(v585_2);
              let v585_10: Space = if has_head(&(v585_9)) { singleton(&[]) } else { Space::new() };
              drop(v585_9);
              let v585_12: Space = if (&(v585_10)).is_empty() { Space::new() } else {
                let mut v590_11 = Space::new();
                let mut v590_11_write = v590_11.write_zipper();
                for v590_11_byte in v582_3_cursor.child_mask().iter() {
                  v582_3_cursor.descend_to_existing_byte(v590_11_byte);
                  {
                  let v591_2: Space = singleton(&v582_3_cursor.path()[(v582_3_origin + 2)..(v582_3_origin + 3)]);
                  let v591_3: Space = intersect(&(*CONSTANT_12),&(v591_2));
                  let v591_4: Space = if has_head(&(v591_3)) { singleton(&[]) } else { Space::new() };
                  drop(v591_3);
                  let v591_5: Space = subtract(&(*CONSTANT_0),&(v591_4));
                  drop(v591_4);
                  let v591_8: Space = if (&(v591_5)).is_empty() { Space::new() } else {
                    let v592_7: Space = routine_41(c, &v582_3_cursor.path()[v582_3_origin..(v582_3_origin + 3)], &v582_3_cursor);
                    compose(&(v591_5),&(v592_7))
                  };
                  drop(v591_5);
                  let v591_9: Space = intersect(&(*CONSTANT_12),&(v591_2));
                  drop(v591_2);
                  let v591_10: Space = if has_head(&(v591_9)) { singleton(&[]) } else { Space::new() };
                  drop(v591_9);
                  let v591_12: Space = if (&(v591_10)).is_empty() { Space::new() } else {
                    let v593_11: Space = routine_43(c, &v582_3_cursor.path()[v582_3_origin..(v582_3_origin + 3)], &v582_3_cursor);
                    compose(&(v591_10),&(v593_11))
                  };
                  drop(v591_10);
                  let v591_13: Space = unite(&(v591_8),&(v591_12));
                  join_wrapped_into(&mut v590_11_write,&((v591_13).read_zipper()),&[]);
                  }
                  v582_3_cursor.ascend(1);
                }
                drop(v590_11_write);
                compose(&(v585_10),&(v590_11))
              };
              drop(v585_10);
              let v585_13: Space = unite(&(v585_8),&(v585_12));
              join_wrapped_into(&mut v584_6_write,&((v585_13).read_zipper()),&[]);
              }
              v582_3_cursor.ascend(1);
            }
            drop(v584_6_write);
            compose(&(v583_5),&(v584_6))
          };
          drop(v583_5);
          let v583_8: Space = intersect(&(*CONSTANT_12),&(v583_2));
          drop(v583_2);
          let v583_9: Space = if has_head(&(v583_8)) { singleton(&[]) } else { Space::new() };
          drop(v583_8);
          let v583_11: Space = if (&(v583_9)).is_empty() { Space::new() } else {
            let mut v594_10 = Space::new();
            let mut v594_10_write = v594_10.write_zipper();
            for v594_10_byte in v582_3_cursor.child_mask().iter() {
              v582_3_cursor.descend_to_existing_byte(v594_10_byte);
              {
              let v595_2: Space = singleton(&v582_3_cursor.path()[(v582_3_origin + 1)..(v582_3_origin + 2)]);
              let v595_3: Space = intersect(&(*CONSTANT_12),&(v595_2));
              let v595_4: Space = if has_head(&(v595_3)) { singleton(&[]) } else { Space::new() };
              drop(v595_3);
              let v595_5: Space = subtract(&(*CONSTANT_0),&(v595_4));
              drop(v595_4);
              let v595_8: Space = if (&(v595_5)).is_empty() { Space::new() } else {
                let mut v596_7 = Space::new();
                let mut v596_7_write = v596_7.write_zipper();
                for v596_7_byte in v582_3_cursor.child_mask().iter() {
                  v582_3_cursor.descend_to_existing_byte(v596_7_byte);
                  {
                  let v597_2: Space = singleton(&v582_3_cursor.path()[(v582_3_origin + 2)..(v582_3_origin + 3)]);
                  let v597_3: Space = intersect(&(*CONSTANT_12),&(v597_2));
                  let v597_4: Space = if has_head(&(v597_3)) { singleton(&[]) } else { Space::new() };
                  drop(v597_3);
                  let v597_5: Space = subtract(&(*CONSTANT_0),&(v597_4));
                  drop(v597_4);
                  let v597_8: Space = if (&(v597_5)).is_empty() { Space::new() } else {
                    let v598_7: Space = routine_41(c, &v582_3_cursor.path()[v582_3_origin..(v582_3_origin + 3)], &v582_3_cursor);
                    compose(&(v597_5),&(v598_7))
                  };
                  drop(v597_5);
                  let v597_9: Space = intersect(&(*CONSTANT_12),&(v597_2));
                  drop(v597_2);
                  let v597_10: Space = if has_head(&(v597_9)) { singleton(&[]) } else { Space::new() };
                  drop(v597_9);
                  let v597_12: Space = if (&(v597_10)).is_empty() { Space::new() } else {
                    let v599_11: Space = routine_42(c, &v582_3_cursor.path()[v582_3_origin..(v582_3_origin + 3)], &v582_3_cursor);
                    compose(&(v597_10),&(v599_11))
                  };
                  drop(v597_10);
                  let v597_13: Space = unite(&(v597_8),&(v597_12));
                  join_wrapped_into(&mut v596_7_write,&((v597_13).read_zipper()),&[]);
                  }
                  v582_3_cursor.ascend(1);
                }
                drop(v596_7_write);
                compose(&(v595_5),&(v596_7))
              };
              drop(v595_5);
              let v595_9: Space = intersect(&(*CONSTANT_12),&(v595_2));
              drop(v595_2);
              let v595_10: Space = if has_head(&(v595_9)) { singleton(&[]) } else { Space::new() };
              drop(v595_9);
              let v595_11: Space = compose(&(v595_10),&v582_3_cursor);
              drop(v595_10);
              let v595_12: Space = unite(&(v595_8),&(v595_11));
              drop(v595_11);
              join_wrapped_into(&mut v594_10_write,&((v595_12).read_zipper()),&[]);
              }
              v582_3_cursor.ascend(1);
            }
            drop(v594_10_write);
            compose(&(v583_9),&(v594_10))
          };
          drop(v583_9);
          let v583_12: Space = unite(&(v583_7),&(v583_11));
          join_wrapped_into(&mut v582_3_write,&((v583_12).read_zipper()),&[]);
          }
          v582_3_cursor.ascend(1);
        }
        drop(v582_3_cursor);
        drop(v582_3_write);
        drop(v582_2);
        let v582_4: Space = unite(&(v582_3),&(v563_7));
        let v582_5: Space = intersect(&(v582_4),&(*capture_2));
        if !v563_7.join_into((v582_5).clone()).is_element() { break; }
      }
      let v563_8: Space = subtract(&(v563_6),&(v563_7));
      let v563_9: Space = routine_16(c, &(*capture_3).path()[capture_4..(capture_4 + 1)], &(*capture_3), &(*capture_0), &(*capture_1), &((v563_8).read_zipper()));
      compose(&(v562_5),&(v563_9))
    };
    drop(v562_5);
    let v562_11: Space = intersect(&(*CONSTANT_12),&(v562_2));
    drop(v562_2);
    let v562_12: Space = if has_head(&(v562_11)) { singleton(&[]) } else { Space::new() };
    drop(v562_11);
    let v562_17: Space = if (&(v562_12)).is_empty() { Space::new() } else {
      let mut v600_13: Space = ((*capture_5)).clone();
      loop {
        let v601_1: Space = intersect(&(v600_13),&(*capture_2));
        let v601_2: Space = restrict_to(&(*capture_0),&(v601_1));
        drop(v601_1);
        let mut v601_3 = Space::new();
        let mut v601_3_write = v601_3.write_zipper();
        let mut v601_3_cursor = (v601_2).read_zipper();
        let v601_3_origin = v601_3_cursor.path().len();
        for v601_3_byte in v601_3_cursor.child_mask().iter() {
          v601_3_cursor.descend_to_existing_byte(v601_3_byte);
          {
          let v602_2: Space = singleton(&v601_3_cursor.path()[v601_3_origin..(v601_3_origin + 1)]);
          let v602_3: Space = intersect(&(*CONSTANT_12),&(v602_2));
          let v602_4: Space = if has_head(&(v602_3)) { singleton(&[]) } else { Space::new() };
          drop(v602_3);
          let v602_5: Space = subtract(&(*CONSTANT_0),&(v602_4));
          drop(v602_4);
          let v602_7: Space = if (&(v602_5)).is_empty() { Space::new() } else {
            let mut v603_6 = Space::new();
            let mut v603_6_write = v603_6.write_zipper();
            for v603_6_byte in v601_3_cursor.child_mask().iter() {
              v601_3_cursor.descend_to_existing_byte(v603_6_byte);
              {
              let v604_2: Space = singleton(&v601_3_cursor.path()[(v601_3_origin + 1)..(v601_3_origin + 2)]);
              let v604_3: Space = intersect(&(*CONSTANT_12),&(v604_2));
              let v604_4: Space = if has_head(&(v604_3)) { singleton(&[]) } else { Space::new() };
              drop(v604_3);
              let v604_5: Space = subtract(&(*CONSTANT_0),&(v604_4));
              drop(v604_4);
              let v604_8: Space = if (&(v604_5)).is_empty() { Space::new() } else {
                let mut v605_7 = Space::new();
                let mut v605_7_write = v605_7.write_zipper();
                for v605_7_byte in v601_3_cursor.child_mask().iter() {
                  v601_3_cursor.descend_to_existing_byte(v605_7_byte);
                  {
                  let v606_2: Space = singleton(&v601_3_cursor.path()[(v601_3_origin + 2)..(v601_3_origin + 3)]);
                  let v606_3: Space = intersect(&(*CONSTANT_12),&(v606_2));
                  let v606_4: Space = if has_head(&(v606_3)) { singleton(&[]) } else { Space::new() };
                  drop(v606_3);
                  let v606_5: Space = subtract(&(*CONSTANT_0),&(v606_4));
                  drop(v606_4);
                  let v606_8: Space = if (&(v606_5)).is_empty() { Space::new() } else {
                    let v607_7: Space = routine_41(c, &v601_3_cursor.path()[v601_3_origin..(v601_3_origin + 3)], &v601_3_cursor);
                    compose(&(v606_5),&(v607_7))
                  };
                  drop(v606_5);
                  let v606_9: Space = intersect(&(*CONSTANT_12),&(v606_2));
                  drop(v606_2);
                  let v606_10: Space = if has_head(&(v606_9)) { singleton(&[]) } else { Space::new() };
                  drop(v606_9);
                  let v606_12: Space = if (&(v606_10)).is_empty() { Space::new() } else {
                    let v608_11: Space = routine_42(c, &v601_3_cursor.path()[v601_3_origin..(v601_3_origin + 3)], &v601_3_cursor);
                    compose(&(v606_10),&(v608_11))
                  };
                  drop(v606_10);
                  let v606_13: Space = unite(&(v606_8),&(v606_12));
                  join_wrapped_into(&mut v605_7_write,&((v606_13).read_zipper()),&[]);
                  }
                  v601_3_cursor.ascend(1);
                }
                drop(v605_7_write);
                compose(&(v604_5),&(v605_7))
              };
              drop(v604_5);
              let v604_9: Space = intersect(&(*CONSTANT_12),&(v604_2));
              drop(v604_2);
              let v604_10: Space = if has_head(&(v604_9)) { singleton(&[]) } else { Space::new() };
              drop(v604_9);
              let v604_12: Space = if (&(v604_10)).is_empty() { Space::new() } else {
                let mut v609_11 = Space::new();
                let mut v609_11_write = v609_11.write_zipper();
                for v609_11_byte in v601_3_cursor.child_mask().iter() {
                  v601_3_cursor.descend_to_existing_byte(v609_11_byte);
                  {
                  let v610_2: Space = singleton(&v601_3_cursor.path()[(v601_3_origin + 2)..(v601_3_origin + 3)]);
                  let v610_3: Space = intersect(&(*CONSTANT_12),&(v610_2));
                  let v610_4: Space = if has_head(&(v610_3)) { singleton(&[]) } else { Space::new() };
                  drop(v610_3);
                  let v610_5: Space = subtract(&(*CONSTANT_0),&(v610_4));
                  drop(v610_4);
                  let v610_8: Space = if (&(v610_5)).is_empty() { Space::new() } else {
                    let v611_7: Space = routine_41(c, &v601_3_cursor.path()[v601_3_origin..(v601_3_origin + 3)], &v601_3_cursor);
                    compose(&(v610_5),&(v611_7))
                  };
                  drop(v610_5);
                  let v610_9: Space = intersect(&(*CONSTANT_12),&(v610_2));
                  drop(v610_2);
                  let v610_10: Space = if has_head(&(v610_9)) { singleton(&[]) } else { Space::new() };
                  drop(v610_9);
                  let v610_12: Space = if (&(v610_10)).is_empty() { Space::new() } else {
                    let v612_11: Space = routine_43(c, &v601_3_cursor.path()[v601_3_origin..(v601_3_origin + 3)], &v601_3_cursor);
                    compose(&(v610_10),&(v612_11))
                  };
                  drop(v610_10);
                  let v610_13: Space = unite(&(v610_8),&(v610_12));
                  join_wrapped_into(&mut v609_11_write,&((v610_13).read_zipper()),&[]);
                  }
                  v601_3_cursor.ascend(1);
                }
                drop(v609_11_write);
                compose(&(v604_10),&(v609_11))
              };
              drop(v604_10);
              let v604_13: Space = unite(&(v604_8),&(v604_12));
              join_wrapped_into(&mut v603_6_write,&((v604_13).read_zipper()),&[]);
              }
              v601_3_cursor.ascend(1);
            }
            drop(v603_6_write);
            compose(&(v602_5),&(v603_6))
          };
          drop(v602_5);
          let v602_8: Space = intersect(&(*CONSTANT_12),&(v602_2));
          drop(v602_2);
          let v602_9: Space = if has_head(&(v602_8)) { singleton(&[]) } else { Space::new() };
          drop(v602_8);
          let v602_11: Space = if (&(v602_9)).is_empty() { Space::new() } else {
            let mut v613_10 = Space::new();
            let mut v613_10_write = v613_10.write_zipper();
            for v613_10_byte in v601_3_cursor.child_mask().iter() {
              v601_3_cursor.descend_to_existing_byte(v613_10_byte);
              {
              let v614_2: Space = singleton(&v601_3_cursor.path()[(v601_3_origin + 1)..(v601_3_origin + 2)]);
              let v614_3: Space = intersect(&(*CONSTANT_12),&(v614_2));
              let v614_4: Space = if has_head(&(v614_3)) { singleton(&[]) } else { Space::new() };
              drop(v614_3);
              let v614_5: Space = subtract(&(*CONSTANT_0),&(v614_4));
              drop(v614_4);
              let v614_8: Space = if (&(v614_5)).is_empty() { Space::new() } else {
                let mut v615_7 = Space::new();
                let mut v615_7_write = v615_7.write_zipper();
                for v615_7_byte in v601_3_cursor.child_mask().iter() {
                  v601_3_cursor.descend_to_existing_byte(v615_7_byte);
                  {
                  let v616_2: Space = singleton(&v601_3_cursor.path()[(v601_3_origin + 2)..(v601_3_origin + 3)]);
                  let v616_3: Space = intersect(&(*CONSTANT_12),&(v616_2));
                  let v616_4: Space = if has_head(&(v616_3)) { singleton(&[]) } else { Space::new() };
                  drop(v616_3);
                  let v616_5: Space = subtract(&(*CONSTANT_0),&(v616_4));
                  drop(v616_4);
                  let v616_8: Space = if (&(v616_5)).is_empty() { Space::new() } else {
                    let v617_7: Space = routine_41(c, &v601_3_cursor.path()[v601_3_origin..(v601_3_origin + 3)], &v601_3_cursor);
                    compose(&(v616_5),&(v617_7))
                  };
                  drop(v616_5);
                  let v616_9: Space = intersect(&(*CONSTANT_12),&(v616_2));
                  drop(v616_2);
                  let v616_10: Space = if has_head(&(v616_9)) { singleton(&[]) } else { Space::new() };
                  drop(v616_9);
                  let v616_12: Space = if (&(v616_10)).is_empty() { Space::new() } else {
                    let v618_11: Space = routine_42(c, &v601_3_cursor.path()[v601_3_origin..(v601_3_origin + 3)], &v601_3_cursor);
                    compose(&(v616_10),&(v618_11))
                  };
                  drop(v616_10);
                  let v616_13: Space = unite(&(v616_8),&(v616_12));
                  join_wrapped_into(&mut v615_7_write,&((v616_13).read_zipper()),&[]);
                  }
                  v601_3_cursor.ascend(1);
                }
                drop(v615_7_write);
                compose(&(v614_5),&(v615_7))
              };
              drop(v614_5);
              let v614_9: Space = intersect(&(*CONSTANT_12),&(v614_2));
              drop(v614_2);
              let v614_10: Space = if has_head(&(v614_9)) { singleton(&[]) } else { Space::new() };
              drop(v614_9);
              let v614_11: Space = compose(&(v614_10),&v601_3_cursor);
              drop(v614_10);
              let v614_12: Space = unite(&(v614_8),&(v614_11));
              drop(v614_11);
              join_wrapped_into(&mut v613_10_write,&((v614_12).read_zipper()),&[]);
              }
              v601_3_cursor.ascend(1);
            }
            drop(v613_10_write);
            compose(&(v602_9),&(v613_10))
          };
          drop(v602_9);
          let v602_12: Space = unite(&(v602_7),&(v602_11));
          join_wrapped_into(&mut v601_3_write,&((v602_12).read_zipper()),&[]);
          }
          v601_3_cursor.ascend(1);
        }
        drop(v601_3_cursor);
        drop(v601_3_write);
        drop(v601_2);
        let v601_4: Space = unite(&(v601_3),&(v600_13));
        let v601_5: Space = intersect(&(v601_4),&(*capture_2));
        if !v600_13.join_into((v601_5).clone()).is_element() { break; }
      }
      let mut v600_14: Space = ((*capture_5)).clone();
      loop {
        let v619_1: Space = intersect(&(v600_14),&(*capture_2));
        let v619_2: Space = restrict_to(&(*capture_1),&(v619_1));
        drop(v619_1);
        let mut v619_3 = Space::new();
        let mut v619_3_write = v619_3.write_zipper();
        let mut v619_3_cursor = (v619_2).read_zipper();
        let v619_3_origin = v619_3_cursor.path().len();
        for v619_3_byte in v619_3_cursor.child_mask().iter() {
          v619_3_cursor.descend_to_existing_byte(v619_3_byte);
          {
          let v620_2: Space = singleton(&v619_3_cursor.path()[v619_3_origin..(v619_3_origin + 1)]);
          let v620_3: Space = intersect(&(*CONSTANT_12),&(v620_2));
          let v620_4: Space = if has_head(&(v620_3)) { singleton(&[]) } else { Space::new() };
          drop(v620_3);
          let v620_5: Space = subtract(&(*CONSTANT_0),&(v620_4));
          drop(v620_4);
          let v620_7: Space = if (&(v620_5)).is_empty() { Space::new() } else {
            let mut v621_6 = Space::new();
            let mut v621_6_write = v621_6.write_zipper();
            for v621_6_byte in v619_3_cursor.child_mask().iter() {
              v619_3_cursor.descend_to_existing_byte(v621_6_byte);
              {
              let v622_2: Space = singleton(&v619_3_cursor.path()[(v619_3_origin + 1)..(v619_3_origin + 2)]);
              let v622_3: Space = intersect(&(*CONSTANT_12),&(v622_2));
              let v622_4: Space = if has_head(&(v622_3)) { singleton(&[]) } else { Space::new() };
              drop(v622_3);
              let v622_5: Space = subtract(&(*CONSTANT_0),&(v622_4));
              drop(v622_4);
              let v622_8: Space = if (&(v622_5)).is_empty() { Space::new() } else {
                let mut v623_7 = Space::new();
                let mut v623_7_write = v623_7.write_zipper();
                for v623_7_byte in v619_3_cursor.child_mask().iter() {
                  v619_3_cursor.descend_to_existing_byte(v623_7_byte);
                  {
                  let v624_2: Space = singleton(&v619_3_cursor.path()[(v619_3_origin + 2)..(v619_3_origin + 3)]);
                  let v624_3: Space = intersect(&(*CONSTANT_12),&(v624_2));
                  let v624_4: Space = if has_head(&(v624_3)) { singleton(&[]) } else { Space::new() };
                  drop(v624_3);
                  let v624_5: Space = subtract(&(*CONSTANT_0),&(v624_4));
                  drop(v624_4);
                  let v624_8: Space = if (&(v624_5)).is_empty() { Space::new() } else {
                    let v625_7: Space = routine_41(c, &v619_3_cursor.path()[v619_3_origin..(v619_3_origin + 3)], &v619_3_cursor);
                    compose(&(v624_5),&(v625_7))
                  };
                  drop(v624_5);
                  let v624_9: Space = intersect(&(*CONSTANT_12),&(v624_2));
                  drop(v624_2);
                  let v624_10: Space = if has_head(&(v624_9)) { singleton(&[]) } else { Space::new() };
                  drop(v624_9);
                  let v624_12: Space = if (&(v624_10)).is_empty() { Space::new() } else {
                    let v626_11: Space = routine_42(c, &v619_3_cursor.path()[v619_3_origin..(v619_3_origin + 3)], &v619_3_cursor);
                    compose(&(v624_10),&(v626_11))
                  };
                  drop(v624_10);
                  let v624_13: Space = unite(&(v624_8),&(v624_12));
                  join_wrapped_into(&mut v623_7_write,&((v624_13).read_zipper()),&[]);
                  }
                  v619_3_cursor.ascend(1);
                }
                drop(v623_7_write);
                compose(&(v622_5),&(v623_7))
              };
              drop(v622_5);
              let v622_9: Space = intersect(&(*CONSTANT_12),&(v622_2));
              drop(v622_2);
              let v622_10: Space = if has_head(&(v622_9)) { singleton(&[]) } else { Space::new() };
              drop(v622_9);
              let v622_12: Space = if (&(v622_10)).is_empty() { Space::new() } else {
                let mut v627_11 = Space::new();
                let mut v627_11_write = v627_11.write_zipper();
                for v627_11_byte in v619_3_cursor.child_mask().iter() {
                  v619_3_cursor.descend_to_existing_byte(v627_11_byte);
                  {
                  let v628_2: Space = singleton(&v619_3_cursor.path()[(v619_3_origin + 2)..(v619_3_origin + 3)]);
                  let v628_3: Space = intersect(&(*CONSTANT_12),&(v628_2));
                  let v628_4: Space = if has_head(&(v628_3)) { singleton(&[]) } else { Space::new() };
                  drop(v628_3);
                  let v628_5: Space = subtract(&(*CONSTANT_0),&(v628_4));
                  drop(v628_4);
                  let v628_8: Space = if (&(v628_5)).is_empty() { Space::new() } else {
                    let v629_7: Space = routine_41(c, &v619_3_cursor.path()[v619_3_origin..(v619_3_origin + 3)], &v619_3_cursor);
                    compose(&(v628_5),&(v629_7))
                  };
                  drop(v628_5);
                  let v628_9: Space = intersect(&(*CONSTANT_12),&(v628_2));
                  drop(v628_2);
                  let v628_10: Space = if has_head(&(v628_9)) { singleton(&[]) } else { Space::new() };
                  drop(v628_9);
                  let v628_12: Space = if (&(v628_10)).is_empty() { Space::new() } else {
                    let v630_11: Space = routine_43(c, &v619_3_cursor.path()[v619_3_origin..(v619_3_origin + 3)], &v619_3_cursor);
                    compose(&(v628_10),&(v630_11))
                  };
                  drop(v628_10);
                  let v628_13: Space = unite(&(v628_8),&(v628_12));
                  join_wrapped_into(&mut v627_11_write,&((v628_13).read_zipper()),&[]);
                  }
                  v619_3_cursor.ascend(1);
                }
                drop(v627_11_write);
                compose(&(v622_10),&(v627_11))
              };
              drop(v622_10);
              let v622_13: Space = unite(&(v622_8),&(v622_12));
              join_wrapped_into(&mut v621_6_write,&((v622_13).read_zipper()),&[]);
              }
              v619_3_cursor.ascend(1);
            }
            drop(v621_6_write);
            compose(&(v620_5),&(v621_6))
          };
          drop(v620_5);
          let v620_8: Space = intersect(&(*CONSTANT_12),&(v620_2));
          drop(v620_2);
          let v620_9: Space = if has_head(&(v620_8)) { singleton(&[]) } else { Space::new() };
          drop(v620_8);
          let v620_11: Space = if (&(v620_9)).is_empty() { Space::new() } else {
            let mut v631_10 = Space::new();
            let mut v631_10_write = v631_10.write_zipper();
            for v631_10_byte in v619_3_cursor.child_mask().iter() {
              v619_3_cursor.descend_to_existing_byte(v631_10_byte);
              {
              let v632_2: Space = singleton(&v619_3_cursor.path()[(v619_3_origin + 1)..(v619_3_origin + 2)]);
              let v632_3: Space = intersect(&(*CONSTANT_12),&(v632_2));
              let v632_4: Space = if has_head(&(v632_3)) { singleton(&[]) } else { Space::new() };
              drop(v632_3);
              let v632_5: Space = subtract(&(*CONSTANT_0),&(v632_4));
              drop(v632_4);
              let v632_8: Space = if (&(v632_5)).is_empty() { Space::new() } else {
                let mut v633_7 = Space::new();
                let mut v633_7_write = v633_7.write_zipper();
                for v633_7_byte in v619_3_cursor.child_mask().iter() {
                  v619_3_cursor.descend_to_existing_byte(v633_7_byte);
                  {
                  let v634_2: Space = singleton(&v619_3_cursor.path()[(v619_3_origin + 2)..(v619_3_origin + 3)]);
                  let v634_3: Space = intersect(&(*CONSTANT_12),&(v634_2));
                  let v634_4: Space = if has_head(&(v634_3)) { singleton(&[]) } else { Space::new() };
                  drop(v634_3);
                  let v634_5: Space = subtract(&(*CONSTANT_0),&(v634_4));
                  drop(v634_4);
                  let v634_8: Space = if (&(v634_5)).is_empty() { Space::new() } else {
                    let v635_7: Space = routine_41(c, &v619_3_cursor.path()[v619_3_origin..(v619_3_origin + 3)], &v619_3_cursor);
                    compose(&(v634_5),&(v635_7))
                  };
                  drop(v634_5);
                  let v634_9: Space = intersect(&(*CONSTANT_12),&(v634_2));
                  drop(v634_2);
                  let v634_10: Space = if has_head(&(v634_9)) { singleton(&[]) } else { Space::new() };
                  drop(v634_9);
                  let v634_12: Space = if (&(v634_10)).is_empty() { Space::new() } else {
                    let v636_11: Space = routine_42(c, &v619_3_cursor.path()[v619_3_origin..(v619_3_origin + 3)], &v619_3_cursor);
                    compose(&(v634_10),&(v636_11))
                  };
                  drop(v634_10);
                  let v634_13: Space = unite(&(v634_8),&(v634_12));
                  join_wrapped_into(&mut v633_7_write,&((v634_13).read_zipper()),&[]);
                  }
                  v619_3_cursor.ascend(1);
                }
                drop(v633_7_write);
                compose(&(v632_5),&(v633_7))
              };
              drop(v632_5);
              let v632_9: Space = intersect(&(*CONSTANT_12),&(v632_2));
              drop(v632_2);
              let v632_10: Space = if has_head(&(v632_9)) { singleton(&[]) } else { Space::new() };
              drop(v632_9);
              let v632_11: Space = compose(&(v632_10),&v619_3_cursor);
              drop(v632_10);
              let v632_12: Space = unite(&(v632_8),&(v632_11));
              drop(v632_11);
              join_wrapped_into(&mut v631_10_write,&((v632_12).read_zipper()),&[]);
              }
              v619_3_cursor.ascend(1);
            }
            drop(v631_10_write);
            compose(&(v620_9),&(v631_10))
          };
          drop(v620_9);
          let v620_12: Space = unite(&(v620_7),&(v620_11));
          join_wrapped_into(&mut v619_3_write,&((v620_12).read_zipper()),&[]);
          }
          v619_3_cursor.ascend(1);
        }
        drop(v619_3_cursor);
        drop(v619_3_write);
        drop(v619_2);
        let v619_4: Space = unite(&(v619_3),&(v600_14));
        let v619_5: Space = intersect(&(v619_4),&(*capture_2));
        if !v600_14.join_into((v619_5).clone()).is_element() { break; }
      }
      let v600_15: Space = subtract(&(v600_13),&(v600_14));
      let v600_16: Space = routine_17(c, &(*capture_3).path()[capture_4..(capture_4 + 1)], &(*capture_3), &(*capture_0), &(*capture_1), &((v600_15).read_zipper()));
      compose(&(v562_12),&(v600_16))
    };
    drop(v562_12);

((v562_10).clone(),(v562_17).clone(),)
}

#[inline(never)]
fn native_block_4(c: &mut Context,capture_0: &View<'_, '_>,capture_1: &View<'_, '_>,capture_2: &View<'_, '_>,capture_3: &Space,capture_4: &Space,capture_5: &Space,capture_6: &Space) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v378_86: Space = subtract(&((*capture_5)),&((*capture_6)));
  let v378_87: Space = routine_11(c, &((v378_86).read_zipper()));
  let mut v378_163 = Space::new();
  let mut v378_163_write = v378_163.write_zipper();
  let mut v378_163_cursor = (v378_87).read_zipper();
  let v378_163_origin = v378_163_cursor.path().len();
  for v378_163_byte in v378_163_cursor.child_mask().iter() {
    v378_163_cursor.descend_to_existing_byte(v378_163_byte);
    {
    let (mut v451_11,mut v451_19,) = native_block_2(c, capture_0, capture_1, capture_2, &v378_163_cursor, v378_163_origin, &(*capture_4));
    let v451_20: Space = unite(&(v451_11),&(v451_19));
    join_wrapped_into(&mut v378_163_write,&((v451_20).read_zipper()),&[]);
    }
    v378_163_cursor.ascend(1);
  }
  drop(v378_163_cursor);
  drop(v378_163_write);
  let v378_164: Space = unite(&((*capture_3)),&(v378_163));
  let mut v378_183: Space = ((*capture_4)).clone();
  loop {
    let v526_1: Space = intersect(&(v378_183),&(*capture_2));
    let v526_2: Space = restrict_to(&(*capture_0),&(v526_1));
    drop(v526_1);
    let mut v526_3 = Space::new();
    let mut v526_3_write = v526_3.write_zipper();
    let mut v526_3_cursor = (v526_2).read_zipper();
    let v526_3_origin = v526_3_cursor.path().len();
    for v526_3_byte in v526_3_cursor.child_mask().iter() {
      v526_3_cursor.descend_to_existing_byte(v526_3_byte);
      {
      let v527_2: Space = singleton(&v526_3_cursor.path()[v526_3_origin..(v526_3_origin + 1)]);
      let v527_3: Space = intersect(&(*CONSTANT_12),&(v527_2));
      let v527_4: Space = if has_head(&(v527_3)) { singleton(&[]) } else { Space::new() };
      drop(v527_3);
      let v527_5: Space = subtract(&(*CONSTANT_0),&(v527_4));
      drop(v527_4);
      let v527_7: Space = if (&(v527_5)).is_empty() { Space::new() } else {
        let mut v528_6 = Space::new();
        let mut v528_6_write = v528_6.write_zipper();
        for v528_6_byte in v526_3_cursor.child_mask().iter() {
          v526_3_cursor.descend_to_existing_byte(v528_6_byte);
          {
          let v529_2: Space = singleton(&v526_3_cursor.path()[(v526_3_origin + 1)..(v526_3_origin + 2)]);
          let v529_3: Space = intersect(&(*CONSTANT_12),&(v529_2));
          let v529_4: Space = if has_head(&(v529_3)) { singleton(&[]) } else { Space::new() };
          drop(v529_3);
          let v529_5: Space = subtract(&(*CONSTANT_0),&(v529_4));
          drop(v529_4);
          let v529_8: Space = if (&(v529_5)).is_empty() { Space::new() } else {
            let mut v530_7 = Space::new();
            let mut v530_7_write = v530_7.write_zipper();
            for v530_7_byte in v526_3_cursor.child_mask().iter() {
              v526_3_cursor.descend_to_existing_byte(v530_7_byte);
              {
              let v531_2: Space = singleton(&v526_3_cursor.path()[(v526_3_origin + 2)..(v526_3_origin + 3)]);
              let v531_3: Space = intersect(&(*CONSTANT_12),&(v531_2));
              let v531_4: Space = if has_head(&(v531_3)) { singleton(&[]) } else { Space::new() };
              drop(v531_3);
              let v531_5: Space = subtract(&(*CONSTANT_0),&(v531_4));
              drop(v531_4);
              let v531_8: Space = if (&(v531_5)).is_empty() { Space::new() } else {
                let v532_7: Space = routine_41(c, &v526_3_cursor.path()[v526_3_origin..(v526_3_origin + 3)], &v526_3_cursor);
                compose(&(v531_5),&(v532_7))
              };
              drop(v531_5);
              let v531_9: Space = intersect(&(*CONSTANT_12),&(v531_2));
              drop(v531_2);
              let v531_10: Space = if has_head(&(v531_9)) { singleton(&[]) } else { Space::new() };
              drop(v531_9);
              let v531_12: Space = if (&(v531_10)).is_empty() { Space::new() } else {
                let v533_11: Space = routine_42(c, &v526_3_cursor.path()[v526_3_origin..(v526_3_origin + 3)], &v526_3_cursor);
                compose(&(v531_10),&(v533_11))
              };
              drop(v531_10);
              let v531_13: Space = unite(&(v531_8),&(v531_12));
              join_wrapped_into(&mut v530_7_write,&((v531_13).read_zipper()),&[]);
              }
              v526_3_cursor.ascend(1);
            }
            drop(v530_7_write);
            compose(&(v529_5),&(v530_7))
          };
          drop(v529_5);
          let v529_9: Space = intersect(&(*CONSTANT_12),&(v529_2));
          drop(v529_2);
          let v529_10: Space = if has_head(&(v529_9)) { singleton(&[]) } else { Space::new() };
          drop(v529_9);
          let v529_12: Space = if (&(v529_10)).is_empty() { Space::new() } else {
            let mut v534_11 = Space::new();
            let mut v534_11_write = v534_11.write_zipper();
            for v534_11_byte in v526_3_cursor.child_mask().iter() {
              v526_3_cursor.descend_to_existing_byte(v534_11_byte);
              {
              let v535_2: Space = singleton(&v526_3_cursor.path()[(v526_3_origin + 2)..(v526_3_origin + 3)]);
              let v535_3: Space = intersect(&(*CONSTANT_12),&(v535_2));
              let v535_4: Space = if has_head(&(v535_3)) { singleton(&[]) } else { Space::new() };
              drop(v535_3);
              let v535_5: Space = subtract(&(*CONSTANT_0),&(v535_4));
              drop(v535_4);
              let v535_8: Space = if (&(v535_5)).is_empty() { Space::new() } else {
                let v536_7: Space = routine_41(c, &v526_3_cursor.path()[v526_3_origin..(v526_3_origin + 3)], &v526_3_cursor);
                compose(&(v535_5),&(v536_7))
              };
              drop(v535_5);
              let v535_9: Space = intersect(&(*CONSTANT_12),&(v535_2));
              drop(v535_2);
              let v535_10: Space = if has_head(&(v535_9)) { singleton(&[]) } else { Space::new() };
              drop(v535_9);
              let v535_12: Space = if (&(v535_10)).is_empty() { Space::new() } else {
                let v537_11: Space = routine_43(c, &v526_3_cursor.path()[v526_3_origin..(v526_3_origin + 3)], &v526_3_cursor);
                compose(&(v535_10),&(v537_11))
              };
              drop(v535_10);
              let v535_13: Space = unite(&(v535_8),&(v535_12));
              join_wrapped_into(&mut v534_11_write,&((v535_13).read_zipper()),&[]);
              }
              v526_3_cursor.ascend(1);
            }
            drop(v534_11_write);
            compose(&(v529_10),&(v534_11))
          };
          drop(v529_10);
          let v529_13: Space = unite(&(v529_8),&(v529_12));
          join_wrapped_into(&mut v528_6_write,&((v529_13).read_zipper()),&[]);
          }
          v526_3_cursor.ascend(1);
        }
        drop(v528_6_write);
        compose(&(v527_5),&(v528_6))
      };
      drop(v527_5);
      let v527_8: Space = intersect(&(*CONSTANT_12),&(v527_2));
      drop(v527_2);
      let v527_9: Space = if has_head(&(v527_8)) { singleton(&[]) } else { Space::new() };
      drop(v527_8);
      let v527_11: Space = if (&(v527_9)).is_empty() { Space::new() } else {
        let mut v538_10 = Space::new();
        let mut v538_10_write = v538_10.write_zipper();
        for v538_10_byte in v526_3_cursor.child_mask().iter() {
          v526_3_cursor.descend_to_existing_byte(v538_10_byte);
          {
          let v539_2: Space = singleton(&v526_3_cursor.path()[(v526_3_origin + 1)..(v526_3_origin + 2)]);
          let v539_3: Space = intersect(&(*CONSTANT_12),&(v539_2));
          let v539_4: Space = if has_head(&(v539_3)) { singleton(&[]) } else { Space::new() };
          drop(v539_3);
          let v539_5: Space = subtract(&(*CONSTANT_0),&(v539_4));
          drop(v539_4);
          let v539_8: Space = if (&(v539_5)).is_empty() { Space::new() } else {
            let mut v540_7 = Space::new();
            let mut v540_7_write = v540_7.write_zipper();
            for v540_7_byte in v526_3_cursor.child_mask().iter() {
              v526_3_cursor.descend_to_existing_byte(v540_7_byte);
              {
              let v541_2: Space = singleton(&v526_3_cursor.path()[(v526_3_origin + 2)..(v526_3_origin + 3)]);
              let v541_3: Space = intersect(&(*CONSTANT_12),&(v541_2));
              let v541_4: Space = if has_head(&(v541_3)) { singleton(&[]) } else { Space::new() };
              drop(v541_3);
              let v541_5: Space = subtract(&(*CONSTANT_0),&(v541_4));
              drop(v541_4);
              let v541_8: Space = if (&(v541_5)).is_empty() { Space::new() } else {
                let v542_7: Space = routine_41(c, &v526_3_cursor.path()[v526_3_origin..(v526_3_origin + 3)], &v526_3_cursor);
                compose(&(v541_5),&(v542_7))
              };
              drop(v541_5);
              let v541_9: Space = intersect(&(*CONSTANT_12),&(v541_2));
              drop(v541_2);
              let v541_10: Space = if has_head(&(v541_9)) { singleton(&[]) } else { Space::new() };
              drop(v541_9);
              let v541_12: Space = if (&(v541_10)).is_empty() { Space::new() } else {
                let v543_11: Space = routine_42(c, &v526_3_cursor.path()[v526_3_origin..(v526_3_origin + 3)], &v526_3_cursor);
                compose(&(v541_10),&(v543_11))
              };
              drop(v541_10);
              let v541_13: Space = unite(&(v541_8),&(v541_12));
              join_wrapped_into(&mut v540_7_write,&((v541_13).read_zipper()),&[]);
              }
              v526_3_cursor.ascend(1);
            }
            drop(v540_7_write);
            compose(&(v539_5),&(v540_7))
          };
          drop(v539_5);
          let v539_9: Space = intersect(&(*CONSTANT_12),&(v539_2));
          drop(v539_2);
          let v539_10: Space = if has_head(&(v539_9)) { singleton(&[]) } else { Space::new() };
          drop(v539_9);
          let v539_11: Space = compose(&(v539_10),&v526_3_cursor);
          drop(v539_10);
          let v539_12: Space = unite(&(v539_8),&(v539_11));
          drop(v539_11);
          join_wrapped_into(&mut v538_10_write,&((v539_12).read_zipper()),&[]);
          }
          v526_3_cursor.ascend(1);
        }
        drop(v538_10_write);
        compose(&(v527_9),&(v538_10))
      };
      drop(v527_9);
      let v527_12: Space = unite(&(v527_7),&(v527_11));
      join_wrapped_into(&mut v526_3_write,&((v527_12).read_zipper()),&[]);
      }
      v526_3_cursor.ascend(1);
    }
    drop(v526_3_cursor);
    drop(v526_3_write);
    drop(v526_2);
    let v526_4: Space = unite(&(v526_3),&(v378_183));
    let v526_5: Space = intersect(&(v526_4),&(*capture_2));
    if !v378_183.join_into((v526_5).clone()).is_element() { break; }
  }
  let mut v378_202: Space = ((*capture_4)).clone();
  loop {
    let v544_1: Space = intersect(&(v378_202),&(*capture_2));
    let v544_2: Space = restrict_to(&(*capture_1),&(v544_1));
    drop(v544_1);
    let mut v544_3 = Space::new();
    let mut v544_3_write = v544_3.write_zipper();
    let mut v544_3_cursor = (v544_2).read_zipper();
    let v544_3_origin = v544_3_cursor.path().len();
    for v544_3_byte in v544_3_cursor.child_mask().iter() {
      v544_3_cursor.descend_to_existing_byte(v544_3_byte);
      {
      let v545_2: Space = singleton(&v544_3_cursor.path()[v544_3_origin..(v544_3_origin + 1)]);
      let v545_3: Space = intersect(&(*CONSTANT_12),&(v545_2));
      let v545_4: Space = if has_head(&(v545_3)) { singleton(&[]) } else { Space::new() };
      drop(v545_3);
      let v545_5: Space = subtract(&(*CONSTANT_0),&(v545_4));
      drop(v545_4);
      let v545_7: Space = if (&(v545_5)).is_empty() { Space::new() } else {
        let mut v546_6 = Space::new();
        let mut v546_6_write = v546_6.write_zipper();
        for v546_6_byte in v544_3_cursor.child_mask().iter() {
          v544_3_cursor.descend_to_existing_byte(v546_6_byte);
          {
          let v547_2: Space = singleton(&v544_3_cursor.path()[(v544_3_origin + 1)..(v544_3_origin + 2)]);
          let v547_3: Space = intersect(&(*CONSTANT_12),&(v547_2));
          let v547_4: Space = if has_head(&(v547_3)) { singleton(&[]) } else { Space::new() };
          drop(v547_3);
          let v547_5: Space = subtract(&(*CONSTANT_0),&(v547_4));
          drop(v547_4);
          let v547_8: Space = if (&(v547_5)).is_empty() { Space::new() } else {
            let mut v548_7 = Space::new();
            let mut v548_7_write = v548_7.write_zipper();
            for v548_7_byte in v544_3_cursor.child_mask().iter() {
              v544_3_cursor.descend_to_existing_byte(v548_7_byte);
              {
              let v549_2: Space = singleton(&v544_3_cursor.path()[(v544_3_origin + 2)..(v544_3_origin + 3)]);
              let v549_3: Space = intersect(&(*CONSTANT_12),&(v549_2));
              let v549_4: Space = if has_head(&(v549_3)) { singleton(&[]) } else { Space::new() };
              drop(v549_3);
              let v549_5: Space = subtract(&(*CONSTANT_0),&(v549_4));
              drop(v549_4);
              let v549_8: Space = if (&(v549_5)).is_empty() { Space::new() } else {
                let v550_7: Space = routine_41(c, &v544_3_cursor.path()[v544_3_origin..(v544_3_origin + 3)], &v544_3_cursor);
                compose(&(v549_5),&(v550_7))
              };
              drop(v549_5);
              let v549_9: Space = intersect(&(*CONSTANT_12),&(v549_2));
              drop(v549_2);
              let v549_10: Space = if has_head(&(v549_9)) { singleton(&[]) } else { Space::new() };
              drop(v549_9);
              let v549_12: Space = if (&(v549_10)).is_empty() { Space::new() } else {
                let v551_11: Space = routine_42(c, &v544_3_cursor.path()[v544_3_origin..(v544_3_origin + 3)], &v544_3_cursor);
                compose(&(v549_10),&(v551_11))
              };
              drop(v549_10);
              let v549_13: Space = unite(&(v549_8),&(v549_12));
              join_wrapped_into(&mut v548_7_write,&((v549_13).read_zipper()),&[]);
              }
              v544_3_cursor.ascend(1);
            }
            drop(v548_7_write);
            compose(&(v547_5),&(v548_7))
          };
          drop(v547_5);
          let v547_9: Space = intersect(&(*CONSTANT_12),&(v547_2));
          drop(v547_2);
          let v547_10: Space = if has_head(&(v547_9)) { singleton(&[]) } else { Space::new() };
          drop(v547_9);
          let v547_12: Space = if (&(v547_10)).is_empty() { Space::new() } else {
            let mut v552_11 = Space::new();
            let mut v552_11_write = v552_11.write_zipper();
            for v552_11_byte in v544_3_cursor.child_mask().iter() {
              v544_3_cursor.descend_to_existing_byte(v552_11_byte);
              {
              let v553_2: Space = singleton(&v544_3_cursor.path()[(v544_3_origin + 2)..(v544_3_origin + 3)]);
              let v553_3: Space = intersect(&(*CONSTANT_12),&(v553_2));
              let v553_4: Space = if has_head(&(v553_3)) { singleton(&[]) } else { Space::new() };
              drop(v553_3);
              let v553_5: Space = subtract(&(*CONSTANT_0),&(v553_4));
              drop(v553_4);
              let v553_8: Space = if (&(v553_5)).is_empty() { Space::new() } else {
                let v554_7: Space = routine_41(c, &v544_3_cursor.path()[v544_3_origin..(v544_3_origin + 3)], &v544_3_cursor);
                compose(&(v553_5),&(v554_7))
              };
              drop(v553_5);
              let v553_9: Space = intersect(&(*CONSTANT_12),&(v553_2));
              drop(v553_2);
              let v553_10: Space = if has_head(&(v553_9)) { singleton(&[]) } else { Space::new() };
              drop(v553_9);
              let v553_12: Space = if (&(v553_10)).is_empty() { Space::new() } else {
                let v555_11: Space = routine_43(c, &v544_3_cursor.path()[v544_3_origin..(v544_3_origin + 3)], &v544_3_cursor);
                compose(&(v553_10),&(v555_11))
              };
              drop(v553_10);
              let v553_13: Space = unite(&(v553_8),&(v553_12));
              join_wrapped_into(&mut v552_11_write,&((v553_13).read_zipper()),&[]);
              }
              v544_3_cursor.ascend(1);
            }
            drop(v552_11_write);
            compose(&(v547_10),&(v552_11))
          };
          drop(v547_10);
          let v547_13: Space = unite(&(v547_8),&(v547_12));
          join_wrapped_into(&mut v546_6_write,&((v547_13).read_zipper()),&[]);
          }
          v544_3_cursor.ascend(1);
        }
        drop(v546_6_write);
        compose(&(v545_5),&(v546_6))
      };
      drop(v545_5);
      let v545_8: Space = intersect(&(*CONSTANT_12),&(v545_2));
      drop(v545_2);
      let v545_9: Space = if has_head(&(v545_8)) { singleton(&[]) } else { Space::new() };
      drop(v545_8);
      let v545_11: Space = if (&(v545_9)).is_empty() { Space::new() } else {
        let mut v556_10 = Space::new();
        let mut v556_10_write = v556_10.write_zipper();
        for v556_10_byte in v544_3_cursor.child_mask().iter() {
          v544_3_cursor.descend_to_existing_byte(v556_10_byte);
          {
          let v557_2: Space = singleton(&v544_3_cursor.path()[(v544_3_origin + 1)..(v544_3_origin + 2)]);
          let v557_3: Space = intersect(&(*CONSTANT_12),&(v557_2));
          let v557_4: Space = if has_head(&(v557_3)) { singleton(&[]) } else { Space::new() };
          drop(v557_3);
          let v557_5: Space = subtract(&(*CONSTANT_0),&(v557_4));
          drop(v557_4);
          let v557_8: Space = if (&(v557_5)).is_empty() { Space::new() } else {
            let mut v558_7 = Space::new();
            let mut v558_7_write = v558_7.write_zipper();
            for v558_7_byte in v544_3_cursor.child_mask().iter() {
              v544_3_cursor.descend_to_existing_byte(v558_7_byte);
              {
              let v559_2: Space = singleton(&v544_3_cursor.path()[(v544_3_origin + 2)..(v544_3_origin + 3)]);
              let v559_3: Space = intersect(&(*CONSTANT_12),&(v559_2));
              let v559_4: Space = if has_head(&(v559_3)) { singleton(&[]) } else { Space::new() };
              drop(v559_3);
              let v559_5: Space = subtract(&(*CONSTANT_0),&(v559_4));
              drop(v559_4);
              let v559_8: Space = if (&(v559_5)).is_empty() { Space::new() } else {
                let v560_7: Space = routine_41(c, &v544_3_cursor.path()[v544_3_origin..(v544_3_origin + 3)], &v544_3_cursor);
                compose(&(v559_5),&(v560_7))
              };
              drop(v559_5);
              let v559_9: Space = intersect(&(*CONSTANT_12),&(v559_2));
              drop(v559_2);
              let v559_10: Space = if has_head(&(v559_9)) { singleton(&[]) } else { Space::new() };
              drop(v559_9);
              let v559_12: Space = if (&(v559_10)).is_empty() { Space::new() } else {
                let v561_11: Space = routine_42(c, &v544_3_cursor.path()[v544_3_origin..(v544_3_origin + 3)], &v544_3_cursor);
                compose(&(v559_10),&(v561_11))
              };
              drop(v559_10);
              let v559_13: Space = unite(&(v559_8),&(v559_12));
              join_wrapped_into(&mut v558_7_write,&((v559_13).read_zipper()),&[]);
              }
              v544_3_cursor.ascend(1);
            }
            drop(v558_7_write);
            compose(&(v557_5),&(v558_7))
          };
          drop(v557_5);
          let v557_9: Space = intersect(&(*CONSTANT_12),&(v557_2));
          drop(v557_2);
          let v557_10: Space = if has_head(&(v557_9)) { singleton(&[]) } else { Space::new() };
          drop(v557_9);
          let v557_11: Space = compose(&(v557_10),&v544_3_cursor);
          drop(v557_10);
          let v557_12: Space = unite(&(v557_8),&(v557_11));
          drop(v557_11);
          join_wrapped_into(&mut v556_10_write,&((v557_12).read_zipper()),&[]);
          }
          v544_3_cursor.ascend(1);
        }
        drop(v556_10_write);
        compose(&(v545_9),&(v556_10))
      };
      drop(v545_9);
      let v545_12: Space = unite(&(v545_7),&(v545_11));
      join_wrapped_into(&mut v544_3_write,&((v545_12).read_zipper()),&[]);
      }
      v544_3_cursor.ascend(1);
    }
    drop(v544_3_cursor);
    drop(v544_3_write);
    drop(v544_2);
    let v544_4: Space = unite(&(v544_3),&(v378_202));
    let v544_5: Space = intersect(&(v544_4),&(*capture_2));
    if !v378_202.join_into((v544_5).clone()).is_element() { break; }
  }
  let v378_203: Space = subtract(&(v378_183),&(v378_202));
  let v378_204: Space = routine_11(c, &((v378_203).read_zipper()));
  let mut v378_280 = Space::new();
  let mut v378_280_write = v378_280.write_zipper();
  let mut v378_280_cursor = (v378_204).read_zipper();
  let v378_280_origin = v378_280_cursor.path().len();
  for v378_280_byte in v378_280_cursor.child_mask().iter() {
    v378_280_cursor.descend_to_existing_byte(v378_280_byte);
    {
    let (mut v562_10,mut v562_17,) = native_block_3(c, capture_0, capture_1, capture_2, &v378_280_cursor, v378_280_origin, &(*capture_4));
    let v562_18: Space = unite(&(v562_10),&(v562_17));
    join_wrapped_into(&mut v378_280_write,&((v562_18).read_zipper()),&[]);
    }
    v378_280_cursor.ascend(1);
  }
  drop(v378_280_cursor);
  drop(v378_280_write);
  let v378_281: Space = unite(&(v378_164),&(v378_280));
  let mut v378_300: Space = ((*capture_4)).clone();
  loop {
    let v637_1: Space = intersect(&(v378_300),&(*capture_2));
    let v637_2: Space = restrict_to(&(*capture_1),&(v637_1));
    drop(v637_1);
    let mut v637_3 = Space::new();
    let mut v637_3_write = v637_3.write_zipper();
    let mut v637_3_cursor = (v637_2).read_zipper();
    let v637_3_origin = v637_3_cursor.path().len();
    for v637_3_byte in v637_3_cursor.child_mask().iter() {
      v637_3_cursor.descend_to_existing_byte(v637_3_byte);
      {
      let v638_2: Space = singleton(&v637_3_cursor.path()[v637_3_origin..(v637_3_origin + 1)]);
      let v638_3: Space = intersect(&(*CONSTANT_12),&(v638_2));
      let v638_4: Space = if has_head(&(v638_3)) { singleton(&[]) } else { Space::new() };
      drop(v638_3);
      let v638_5: Space = subtract(&(*CONSTANT_0),&(v638_4));
      drop(v638_4);
      let v638_7: Space = if (&(v638_5)).is_empty() { Space::new() } else {
        let mut v639_6 = Space::new();
        let mut v639_6_write = v639_6.write_zipper();
        for v639_6_byte in v637_3_cursor.child_mask().iter() {
          v637_3_cursor.descend_to_existing_byte(v639_6_byte);
          {
          let v640_2: Space = singleton(&v637_3_cursor.path()[(v637_3_origin + 1)..(v637_3_origin + 2)]);
          let v640_3: Space = intersect(&(*CONSTANT_12),&(v640_2));
          let v640_4: Space = if has_head(&(v640_3)) { singleton(&[]) } else { Space::new() };
          drop(v640_3);
          let v640_5: Space = subtract(&(*CONSTANT_0),&(v640_4));
          drop(v640_4);
          let v640_8: Space = if (&(v640_5)).is_empty() { Space::new() } else {
            let mut v641_7 = Space::new();
            let mut v641_7_write = v641_7.write_zipper();
            for v641_7_byte in v637_3_cursor.child_mask().iter() {
              v637_3_cursor.descend_to_existing_byte(v641_7_byte);
              {
              let v642_2: Space = singleton(&v637_3_cursor.path()[(v637_3_origin + 2)..(v637_3_origin + 3)]);
              let v642_3: Space = intersect(&(*CONSTANT_12),&(v642_2));
              let v642_4: Space = if has_head(&(v642_3)) { singleton(&[]) } else { Space::new() };
              drop(v642_3);
              let v642_5: Space = subtract(&(*CONSTANT_0),&(v642_4));
              drop(v642_4);
              let v642_8: Space = if (&(v642_5)).is_empty() { Space::new() } else {
                let v643_7: Space = routine_41(c, &v637_3_cursor.path()[v637_3_origin..(v637_3_origin + 3)], &v637_3_cursor);
                compose(&(v642_5),&(v643_7))
              };
              drop(v642_5);
              let v642_9: Space = intersect(&(*CONSTANT_12),&(v642_2));
              drop(v642_2);
              let v642_10: Space = if has_head(&(v642_9)) { singleton(&[]) } else { Space::new() };
              drop(v642_9);
              let v642_12: Space = if (&(v642_10)).is_empty() { Space::new() } else {
                let v644_11: Space = routine_42(c, &v637_3_cursor.path()[v637_3_origin..(v637_3_origin + 3)], &v637_3_cursor);
                compose(&(v642_10),&(v644_11))
              };
              drop(v642_10);
              let v642_13: Space = unite(&(v642_8),&(v642_12));
              join_wrapped_into(&mut v641_7_write,&((v642_13).read_zipper()),&[]);
              }
              v637_3_cursor.ascend(1);
            }
            drop(v641_7_write);
            compose(&(v640_5),&(v641_7))
          };
          drop(v640_5);
          let v640_9: Space = intersect(&(*CONSTANT_12),&(v640_2));
          drop(v640_2);
          let v640_10: Space = if has_head(&(v640_9)) { singleton(&[]) } else { Space::new() };
          drop(v640_9);
          let v640_12: Space = if (&(v640_10)).is_empty() { Space::new() } else {
            let mut v645_11 = Space::new();
            let mut v645_11_write = v645_11.write_zipper();
            for v645_11_byte in v637_3_cursor.child_mask().iter() {
              v637_3_cursor.descend_to_existing_byte(v645_11_byte);
              {
              let v646_2: Space = singleton(&v637_3_cursor.path()[(v637_3_origin + 2)..(v637_3_origin + 3)]);
              let v646_3: Space = intersect(&(*CONSTANT_12),&(v646_2));
              let v646_4: Space = if has_head(&(v646_3)) { singleton(&[]) } else { Space::new() };
              drop(v646_3);
              let v646_5: Space = subtract(&(*CONSTANT_0),&(v646_4));
              drop(v646_4);
              let v646_8: Space = if (&(v646_5)).is_empty() { Space::new() } else {
                let v647_7: Space = routine_41(c, &v637_3_cursor.path()[v637_3_origin..(v637_3_origin + 3)], &v637_3_cursor);
                compose(&(v646_5),&(v647_7))
              };
              drop(v646_5);
              let v646_9: Space = intersect(&(*CONSTANT_12),&(v646_2));
              drop(v646_2);
              let v646_10: Space = if has_head(&(v646_9)) { singleton(&[]) } else { Space::new() };
              drop(v646_9);
              let v646_12: Space = if (&(v646_10)).is_empty() { Space::new() } else {
                let v648_11: Space = routine_43(c, &v637_3_cursor.path()[v637_3_origin..(v637_3_origin + 3)], &v637_3_cursor);
                compose(&(v646_10),&(v648_11))
              };
              drop(v646_10);
              let v646_13: Space = unite(&(v646_8),&(v646_12));
              join_wrapped_into(&mut v645_11_write,&((v646_13).read_zipper()),&[]);
              }
              v637_3_cursor.ascend(1);
            }
            drop(v645_11_write);
            compose(&(v640_10),&(v645_11))
          };
          drop(v640_10);
          let v640_13: Space = unite(&(v640_8),&(v640_12));
          join_wrapped_into(&mut v639_6_write,&((v640_13).read_zipper()),&[]);
          }
          v637_3_cursor.ascend(1);
        }
        drop(v639_6_write);
        compose(&(v638_5),&(v639_6))
      };
      drop(v638_5);
      let v638_8: Space = intersect(&(*CONSTANT_12),&(v638_2));
      drop(v638_2);
      let v638_9: Space = if has_head(&(v638_8)) { singleton(&[]) } else { Space::new() };
      drop(v638_8);
      let v638_11: Space = if (&(v638_9)).is_empty() { Space::new() } else {
        let mut v649_10 = Space::new();
        let mut v649_10_write = v649_10.write_zipper();
        for v649_10_byte in v637_3_cursor.child_mask().iter() {
          v637_3_cursor.descend_to_existing_byte(v649_10_byte);
          {
          let v650_2: Space = singleton(&v637_3_cursor.path()[(v637_3_origin + 1)..(v637_3_origin + 2)]);
          let v650_3: Space = intersect(&(*CONSTANT_12),&(v650_2));
          let v650_4: Space = if has_head(&(v650_3)) { singleton(&[]) } else { Space::new() };
          drop(v650_3);
          let v650_5: Space = subtract(&(*CONSTANT_0),&(v650_4));
          drop(v650_4);
          let v650_8: Space = if (&(v650_5)).is_empty() { Space::new() } else {
            let mut v651_7 = Space::new();
            let mut v651_7_write = v651_7.write_zipper();
            for v651_7_byte in v637_3_cursor.child_mask().iter() {
              v637_3_cursor.descend_to_existing_byte(v651_7_byte);
              {
              let v652_2: Space = singleton(&v637_3_cursor.path()[(v637_3_origin + 2)..(v637_3_origin + 3)]);
              let v652_3: Space = intersect(&(*CONSTANT_12),&(v652_2));
              let v652_4: Space = if has_head(&(v652_3)) { singleton(&[]) } else { Space::new() };
              drop(v652_3);
              let v652_5: Space = subtract(&(*CONSTANT_0),&(v652_4));
              drop(v652_4);
              let v652_8: Space = if (&(v652_5)).is_empty() { Space::new() } else {
                let v653_7: Space = routine_41(c, &v637_3_cursor.path()[v637_3_origin..(v637_3_origin + 3)], &v637_3_cursor);
                compose(&(v652_5),&(v653_7))
              };
              drop(v652_5);
              let v652_9: Space = intersect(&(*CONSTANT_12),&(v652_2));
              drop(v652_2);
              let v652_10: Space = if has_head(&(v652_9)) { singleton(&[]) } else { Space::new() };
              drop(v652_9);
              let v652_12: Space = if (&(v652_10)).is_empty() { Space::new() } else {
                let v654_11: Space = routine_42(c, &v637_3_cursor.path()[v637_3_origin..(v637_3_origin + 3)], &v637_3_cursor);
                compose(&(v652_10),&(v654_11))
              };
              drop(v652_10);
              let v652_13: Space = unite(&(v652_8),&(v652_12));
              join_wrapped_into(&mut v651_7_write,&((v652_13).read_zipper()),&[]);
              }
              v637_3_cursor.ascend(1);
            }
            drop(v651_7_write);
            compose(&(v650_5),&(v651_7))
          };
          drop(v650_5);
          let v650_9: Space = intersect(&(*CONSTANT_12),&(v650_2));
          drop(v650_2);
          let v650_10: Space = if has_head(&(v650_9)) { singleton(&[]) } else { Space::new() };
          drop(v650_9);
          let v650_11: Space = compose(&(v650_10),&v637_3_cursor);
          drop(v650_10);
          let v650_12: Space = unite(&(v650_8),&(v650_11));
          drop(v650_11);
          join_wrapped_into(&mut v649_10_write,&((v650_12).read_zipper()),&[]);
          }
          v637_3_cursor.ascend(1);
        }
        drop(v649_10_write);
        compose(&(v638_9),&(v649_10))
      };
      drop(v638_9);
      let v638_12: Space = unite(&(v638_7),&(v638_11));
      join_wrapped_into(&mut v637_3_write,&((v638_12).read_zipper()),&[]);
      }
      v637_3_cursor.ascend(1);
    }
    drop(v637_3_cursor);
    drop(v637_3_write);
    drop(v637_2);
    let v637_4: Space = unite(&(v637_3),&(v378_300));
    let v637_5: Space = intersect(&(v637_4),&(*capture_2));
    if !v378_300.join_into((v637_5).clone()).is_element() { break; }
  }

((v378_163).clone(),(v378_164).clone(),(v378_183).clone(),(v378_202).clone(),(v378_203).clone(),(v378_204).clone(),(v378_280).clone(),(v378_281).clone(),(v378_300).clone(),(v378_86).clone(),(v378_87).clone(),)
}

#[inline(never)]
fn native_block_5(c: &mut Context,capture_0: &View<'_, '_>,capture_1: &View<'_, '_>,capture_2: &View<'_, '_>,capture_3: &View<'_, '_>,capture_4: usize,capture_5: &Space) -> (Space,Space,) {
    let v673_2: Space = singleton(&(*capture_3).path()[capture_4..(capture_4 + 1)]);
    let v673_3: Space = intersect(&(*CONSTANT_12),&(v673_2));
    let v673_4: Space = if has_head(&(v673_3)) { singleton(&[]) } else { Space::new() };
    drop(v673_3);
    let v673_5: Space = subtract(&(*CONSTANT_0),&(v673_4));
    drop(v673_4);
    let v673_10: Space = if (&(v673_5)).is_empty() { Space::new() } else {
      let mut v674_6: Space = ((*capture_5)).clone();
      loop {
        let v675_1: Space = intersect(&(v674_6),&(*capture_2));
        let v675_2: Space = restrict_to(&(*capture_1),&(v675_1));
        drop(v675_1);
        let mut v675_3 = Space::new();
        let mut v675_3_write = v675_3.write_zipper();
        let mut v675_3_cursor = (v675_2).read_zipper();
        let v675_3_origin = v675_3_cursor.path().len();
        for v675_3_byte in v675_3_cursor.child_mask().iter() {
          v675_3_cursor.descend_to_existing_byte(v675_3_byte);
          {
          let v676_2: Space = singleton(&v675_3_cursor.path()[v675_3_origin..(v675_3_origin + 1)]);
          let v676_3: Space = intersect(&(*CONSTANT_12),&(v676_2));
          let v676_4: Space = if has_head(&(v676_3)) { singleton(&[]) } else { Space::new() };
          drop(v676_3);
          let v676_5: Space = subtract(&(*CONSTANT_0),&(v676_4));
          drop(v676_4);
          let v676_7: Space = if (&(v676_5)).is_empty() { Space::new() } else {
            let mut v677_6 = Space::new();
            let mut v677_6_write = v677_6.write_zipper();
            for v677_6_byte in v675_3_cursor.child_mask().iter() {
              v675_3_cursor.descend_to_existing_byte(v677_6_byte);
              {
              let v678_2: Space = singleton(&v675_3_cursor.path()[(v675_3_origin + 1)..(v675_3_origin + 2)]);
              let v678_3: Space = intersect(&(*CONSTANT_12),&(v678_2));
              let v678_4: Space = if has_head(&(v678_3)) { singleton(&[]) } else { Space::new() };
              drop(v678_3);
              let v678_5: Space = subtract(&(*CONSTANT_0),&(v678_4));
              drop(v678_4);
              let v678_8: Space = if (&(v678_5)).is_empty() { Space::new() } else {
                let mut v679_7 = Space::new();
                let mut v679_7_write = v679_7.write_zipper();
                for v679_7_byte in v675_3_cursor.child_mask().iter() {
                  v675_3_cursor.descend_to_existing_byte(v679_7_byte);
                  {
                  let v680_2: Space = singleton(&v675_3_cursor.path()[(v675_3_origin + 2)..(v675_3_origin + 3)]);
                  let v680_3: Space = intersect(&(*CONSTANT_12),&(v680_2));
                  let v680_4: Space = if has_head(&(v680_3)) { singleton(&[]) } else { Space::new() };
                  drop(v680_3);
                  let v680_5: Space = subtract(&(*CONSTANT_0),&(v680_4));
                  drop(v680_4);
                  let v680_8: Space = if (&(v680_5)).is_empty() { Space::new() } else {
                    let v681_7: Space = routine_41(c, &v675_3_cursor.path()[v675_3_origin..(v675_3_origin + 3)], &v675_3_cursor);
                    compose(&(v680_5),&(v681_7))
                  };
                  drop(v680_5);
                  let v680_9: Space = intersect(&(*CONSTANT_12),&(v680_2));
                  drop(v680_2);
                  let v680_10: Space = if has_head(&(v680_9)) { singleton(&[]) } else { Space::new() };
                  drop(v680_9);
                  let v680_12: Space = if (&(v680_10)).is_empty() { Space::new() } else {
                    let v682_11: Space = routine_42(c, &v675_3_cursor.path()[v675_3_origin..(v675_3_origin + 3)], &v675_3_cursor);
                    compose(&(v680_10),&(v682_11))
                  };
                  drop(v680_10);
                  let v680_13: Space = unite(&(v680_8),&(v680_12));
                  join_wrapped_into(&mut v679_7_write,&((v680_13).read_zipper()),&[]);
                  }
                  v675_3_cursor.ascend(1);
                }
                drop(v679_7_write);
                compose(&(v678_5),&(v679_7))
              };
              drop(v678_5);
              let v678_9: Space = intersect(&(*CONSTANT_12),&(v678_2));
              drop(v678_2);
              let v678_10: Space = if has_head(&(v678_9)) { singleton(&[]) } else { Space::new() };
              drop(v678_9);
              let v678_12: Space = if (&(v678_10)).is_empty() { Space::new() } else {
                let mut v683_11 = Space::new();
                let mut v683_11_write = v683_11.write_zipper();
                for v683_11_byte in v675_3_cursor.child_mask().iter() {
                  v675_3_cursor.descend_to_existing_byte(v683_11_byte);
                  {
                  let v684_2: Space = singleton(&v675_3_cursor.path()[(v675_3_origin + 2)..(v675_3_origin + 3)]);
                  let v684_3: Space = intersect(&(*CONSTANT_12),&(v684_2));
                  let v684_4: Space = if has_head(&(v684_3)) { singleton(&[]) } else { Space::new() };
                  drop(v684_3);
                  let v684_5: Space = subtract(&(*CONSTANT_0),&(v684_4));
                  drop(v684_4);
                  let v684_8: Space = if (&(v684_5)).is_empty() { Space::new() } else {
                    let v685_7: Space = routine_41(c, &v675_3_cursor.path()[v675_3_origin..(v675_3_origin + 3)], &v675_3_cursor);
                    compose(&(v684_5),&(v685_7))
                  };
                  drop(v684_5);
                  let v684_9: Space = intersect(&(*CONSTANT_12),&(v684_2));
                  drop(v684_2);
                  let v684_10: Space = if has_head(&(v684_9)) { singleton(&[]) } else { Space::new() };
                  drop(v684_9);
                  let v684_12: Space = if (&(v684_10)).is_empty() { Space::new() } else {
                    let v686_11: Space = routine_43(c, &v675_3_cursor.path()[v675_3_origin..(v675_3_origin + 3)], &v675_3_cursor);
                    compose(&(v684_10),&(v686_11))
                  };
                  drop(v684_10);
                  let v684_13: Space = unite(&(v684_8),&(v684_12));
                  join_wrapped_into(&mut v683_11_write,&((v684_13).read_zipper()),&[]);
                  }
                  v675_3_cursor.ascend(1);
                }
                drop(v683_11_write);
                compose(&(v678_10),&(v683_11))
              };
              drop(v678_10);
              let v678_13: Space = unite(&(v678_8),&(v678_12));
              join_wrapped_into(&mut v677_6_write,&((v678_13).read_zipper()),&[]);
              }
              v675_3_cursor.ascend(1);
            }
            drop(v677_6_write);
            compose(&(v676_5),&(v677_6))
          };
          drop(v676_5);
          let v676_8: Space = intersect(&(*CONSTANT_12),&(v676_2));
          drop(v676_2);
          let v676_9: Space = if has_head(&(v676_8)) { singleton(&[]) } else { Space::new() };
          drop(v676_8);
          let v676_11: Space = if (&(v676_9)).is_empty() { Space::new() } else {
            let mut v687_10 = Space::new();
            let mut v687_10_write = v687_10.write_zipper();
            for v687_10_byte in v675_3_cursor.child_mask().iter() {
              v675_3_cursor.descend_to_existing_byte(v687_10_byte);
              {
              let v688_2: Space = singleton(&v675_3_cursor.path()[(v675_3_origin + 1)..(v675_3_origin + 2)]);
              let v688_3: Space = intersect(&(*CONSTANT_12),&(v688_2));
              let v688_4: Space = if has_head(&(v688_3)) { singleton(&[]) } else { Space::new() };
              drop(v688_3);
              let v688_5: Space = subtract(&(*CONSTANT_0),&(v688_4));
              drop(v688_4);
              let v688_8: Space = if (&(v688_5)).is_empty() { Space::new() } else {
                let mut v689_7 = Space::new();
                let mut v689_7_write = v689_7.write_zipper();
                for v689_7_byte in v675_3_cursor.child_mask().iter() {
                  v675_3_cursor.descend_to_existing_byte(v689_7_byte);
                  {
                  let v690_2: Space = singleton(&v675_3_cursor.path()[(v675_3_origin + 2)..(v675_3_origin + 3)]);
                  let v690_3: Space = intersect(&(*CONSTANT_12),&(v690_2));
                  let v690_4: Space = if has_head(&(v690_3)) { singleton(&[]) } else { Space::new() };
                  drop(v690_3);
                  let v690_5: Space = subtract(&(*CONSTANT_0),&(v690_4));
                  drop(v690_4);
                  let v690_8: Space = if (&(v690_5)).is_empty() { Space::new() } else {
                    let v691_7: Space = routine_41(c, &v675_3_cursor.path()[v675_3_origin..(v675_3_origin + 3)], &v675_3_cursor);
                    compose(&(v690_5),&(v691_7))
                  };
                  drop(v690_5);
                  let v690_9: Space = intersect(&(*CONSTANT_12),&(v690_2));
                  drop(v690_2);
                  let v690_10: Space = if has_head(&(v690_9)) { singleton(&[]) } else { Space::new() };
                  drop(v690_9);
                  let v690_12: Space = if (&(v690_10)).is_empty() { Space::new() } else {
                    let v692_11: Space = routine_42(c, &v675_3_cursor.path()[v675_3_origin..(v675_3_origin + 3)], &v675_3_cursor);
                    compose(&(v690_10),&(v692_11))
                  };
                  drop(v690_10);
                  let v690_13: Space = unite(&(v690_8),&(v690_12));
                  join_wrapped_into(&mut v689_7_write,&((v690_13).read_zipper()),&[]);
                  }
                  v675_3_cursor.ascend(1);
                }
                drop(v689_7_write);
                compose(&(v688_5),&(v689_7))
              };
              drop(v688_5);
              let v688_9: Space = intersect(&(*CONSTANT_12),&(v688_2));
              drop(v688_2);
              let v688_10: Space = if has_head(&(v688_9)) { singleton(&[]) } else { Space::new() };
              drop(v688_9);
              let v688_11: Space = compose(&(v688_10),&v675_3_cursor);
              drop(v688_10);
              let v688_12: Space = unite(&(v688_8),&(v688_11));
              drop(v688_11);
              join_wrapped_into(&mut v687_10_write,&((v688_12).read_zipper()),&[]);
              }
              v675_3_cursor.ascend(1);
            }
            drop(v687_10_write);
            compose(&(v676_9),&(v687_10))
          };
          drop(v676_9);
          let v676_12: Space = unite(&(v676_7),&(v676_11));
          join_wrapped_into(&mut v675_3_write,&((v676_12).read_zipper()),&[]);
          }
          v675_3_cursor.ascend(1);
        }
        drop(v675_3_cursor);
        drop(v675_3_write);
        drop(v675_2);
        let v675_4: Space = unite(&(v675_3),&(v674_6));
        let v675_5: Space = intersect(&(v675_4),&(*capture_2));
        if !v674_6.join_into((v675_5).clone()).is_element() { break; }
      }
      let mut v674_7: Space = ((*capture_5)).clone();
      loop {
        let v693_1: Space = intersect(&(v674_7),&(*capture_2));
        let v693_2: Space = restrict_to(&(*capture_0),&(v693_1));
        drop(v693_1);
        let mut v693_3 = Space::new();
        let mut v693_3_write = v693_3.write_zipper();
        let mut v693_3_cursor = (v693_2).read_zipper();
        let v693_3_origin = v693_3_cursor.path().len();
        for v693_3_byte in v693_3_cursor.child_mask().iter() {
          v693_3_cursor.descend_to_existing_byte(v693_3_byte);
          {
          let v694_2: Space = singleton(&v693_3_cursor.path()[v693_3_origin..(v693_3_origin + 1)]);
          let v694_3: Space = intersect(&(*CONSTANT_12),&(v694_2));
          let v694_4: Space = if has_head(&(v694_3)) { singleton(&[]) } else { Space::new() };
          drop(v694_3);
          let v694_5: Space = subtract(&(*CONSTANT_0),&(v694_4));
          drop(v694_4);
          let v694_7: Space = if (&(v694_5)).is_empty() { Space::new() } else {
            let mut v695_6 = Space::new();
            let mut v695_6_write = v695_6.write_zipper();
            for v695_6_byte in v693_3_cursor.child_mask().iter() {
              v693_3_cursor.descend_to_existing_byte(v695_6_byte);
              {
              let v696_2: Space = singleton(&v693_3_cursor.path()[(v693_3_origin + 1)..(v693_3_origin + 2)]);
              let v696_3: Space = intersect(&(*CONSTANT_12),&(v696_2));
              let v696_4: Space = if has_head(&(v696_3)) { singleton(&[]) } else { Space::new() };
              drop(v696_3);
              let v696_5: Space = subtract(&(*CONSTANT_0),&(v696_4));
              drop(v696_4);
              let v696_8: Space = if (&(v696_5)).is_empty() { Space::new() } else {
                let mut v697_7 = Space::new();
                let mut v697_7_write = v697_7.write_zipper();
                for v697_7_byte in v693_3_cursor.child_mask().iter() {
                  v693_3_cursor.descend_to_existing_byte(v697_7_byte);
                  {
                  let v698_2: Space = singleton(&v693_3_cursor.path()[(v693_3_origin + 2)..(v693_3_origin + 3)]);
                  let v698_3: Space = intersect(&(*CONSTANT_12),&(v698_2));
                  let v698_4: Space = if has_head(&(v698_3)) { singleton(&[]) } else { Space::new() };
                  drop(v698_3);
                  let v698_5: Space = subtract(&(*CONSTANT_0),&(v698_4));
                  drop(v698_4);
                  let v698_8: Space = if (&(v698_5)).is_empty() { Space::new() } else {
                    let v699_7: Space = routine_41(c, &v693_3_cursor.path()[v693_3_origin..(v693_3_origin + 3)], &v693_3_cursor);
                    compose(&(v698_5),&(v699_7))
                  };
                  drop(v698_5);
                  let v698_9: Space = intersect(&(*CONSTANT_12),&(v698_2));
                  drop(v698_2);
                  let v698_10: Space = if has_head(&(v698_9)) { singleton(&[]) } else { Space::new() };
                  drop(v698_9);
                  let v698_12: Space = if (&(v698_10)).is_empty() { Space::new() } else {
                    let v700_11: Space = routine_42(c, &v693_3_cursor.path()[v693_3_origin..(v693_3_origin + 3)], &v693_3_cursor);
                    compose(&(v698_10),&(v700_11))
                  };
                  drop(v698_10);
                  let v698_13: Space = unite(&(v698_8),&(v698_12));
                  join_wrapped_into(&mut v697_7_write,&((v698_13).read_zipper()),&[]);
                  }
                  v693_3_cursor.ascend(1);
                }
                drop(v697_7_write);
                compose(&(v696_5),&(v697_7))
              };
              drop(v696_5);
              let v696_9: Space = intersect(&(*CONSTANT_12),&(v696_2));
              drop(v696_2);
              let v696_10: Space = if has_head(&(v696_9)) { singleton(&[]) } else { Space::new() };
              drop(v696_9);
              let v696_12: Space = if (&(v696_10)).is_empty() { Space::new() } else {
                let mut v701_11 = Space::new();
                let mut v701_11_write = v701_11.write_zipper();
                for v701_11_byte in v693_3_cursor.child_mask().iter() {
                  v693_3_cursor.descend_to_existing_byte(v701_11_byte);
                  {
                  let v702_2: Space = singleton(&v693_3_cursor.path()[(v693_3_origin + 2)..(v693_3_origin + 3)]);
                  let v702_3: Space = intersect(&(*CONSTANT_12),&(v702_2));
                  let v702_4: Space = if has_head(&(v702_3)) { singleton(&[]) } else { Space::new() };
                  drop(v702_3);
                  let v702_5: Space = subtract(&(*CONSTANT_0),&(v702_4));
                  drop(v702_4);
                  let v702_8: Space = if (&(v702_5)).is_empty() { Space::new() } else {
                    let v703_7: Space = routine_41(c, &v693_3_cursor.path()[v693_3_origin..(v693_3_origin + 3)], &v693_3_cursor);
                    compose(&(v702_5),&(v703_7))
                  };
                  drop(v702_5);
                  let v702_9: Space = intersect(&(*CONSTANT_12),&(v702_2));
                  drop(v702_2);
                  let v702_10: Space = if has_head(&(v702_9)) { singleton(&[]) } else { Space::new() };
                  drop(v702_9);
                  let v702_12: Space = if (&(v702_10)).is_empty() { Space::new() } else {
                    let v704_11: Space = routine_43(c, &v693_3_cursor.path()[v693_3_origin..(v693_3_origin + 3)], &v693_3_cursor);
                    compose(&(v702_10),&(v704_11))
                  };
                  drop(v702_10);
                  let v702_13: Space = unite(&(v702_8),&(v702_12));
                  join_wrapped_into(&mut v701_11_write,&((v702_13).read_zipper()),&[]);
                  }
                  v693_3_cursor.ascend(1);
                }
                drop(v701_11_write);
                compose(&(v696_10),&(v701_11))
              };
              drop(v696_10);
              let v696_13: Space = unite(&(v696_8),&(v696_12));
              join_wrapped_into(&mut v695_6_write,&((v696_13).read_zipper()),&[]);
              }
              v693_3_cursor.ascend(1);
            }
            drop(v695_6_write);
            compose(&(v694_5),&(v695_6))
          };
          drop(v694_5);
          let v694_8: Space = intersect(&(*CONSTANT_12),&(v694_2));
          drop(v694_2);
          let v694_9: Space = if has_head(&(v694_8)) { singleton(&[]) } else { Space::new() };
          drop(v694_8);
          let v694_11: Space = if (&(v694_9)).is_empty() { Space::new() } else {
            let mut v705_10 = Space::new();
            let mut v705_10_write = v705_10.write_zipper();
            for v705_10_byte in v693_3_cursor.child_mask().iter() {
              v693_3_cursor.descend_to_existing_byte(v705_10_byte);
              {
              let v706_2: Space = singleton(&v693_3_cursor.path()[(v693_3_origin + 1)..(v693_3_origin + 2)]);
              let v706_3: Space = intersect(&(*CONSTANT_12),&(v706_2));
              let v706_4: Space = if has_head(&(v706_3)) { singleton(&[]) } else { Space::new() };
              drop(v706_3);
              let v706_5: Space = subtract(&(*CONSTANT_0),&(v706_4));
              drop(v706_4);
              let v706_8: Space = if (&(v706_5)).is_empty() { Space::new() } else {
                let mut v707_7 = Space::new();
                let mut v707_7_write = v707_7.write_zipper();
                for v707_7_byte in v693_3_cursor.child_mask().iter() {
                  v693_3_cursor.descend_to_existing_byte(v707_7_byte);
                  {
                  let v708_2: Space = singleton(&v693_3_cursor.path()[(v693_3_origin + 2)..(v693_3_origin + 3)]);
                  let v708_3: Space = intersect(&(*CONSTANT_12),&(v708_2));
                  let v708_4: Space = if has_head(&(v708_3)) { singleton(&[]) } else { Space::new() };
                  drop(v708_3);
                  let v708_5: Space = subtract(&(*CONSTANT_0),&(v708_4));
                  drop(v708_4);
                  let v708_8: Space = if (&(v708_5)).is_empty() { Space::new() } else {
                    let v709_7: Space = routine_41(c, &v693_3_cursor.path()[v693_3_origin..(v693_3_origin + 3)], &v693_3_cursor);
                    compose(&(v708_5),&(v709_7))
                  };
                  drop(v708_5);
                  let v708_9: Space = intersect(&(*CONSTANT_12),&(v708_2));
                  drop(v708_2);
                  let v708_10: Space = if has_head(&(v708_9)) { singleton(&[]) } else { Space::new() };
                  drop(v708_9);
                  let v708_12: Space = if (&(v708_10)).is_empty() { Space::new() } else {
                    let v710_11: Space = routine_42(c, &v693_3_cursor.path()[v693_3_origin..(v693_3_origin + 3)], &v693_3_cursor);
                    compose(&(v708_10),&(v710_11))
                  };
                  drop(v708_10);
                  let v708_13: Space = unite(&(v708_8),&(v708_12));
                  join_wrapped_into(&mut v707_7_write,&((v708_13).read_zipper()),&[]);
                  }
                  v693_3_cursor.ascend(1);
                }
                drop(v707_7_write);
                compose(&(v706_5),&(v707_7))
              };
              drop(v706_5);
              let v706_9: Space = intersect(&(*CONSTANT_12),&(v706_2));
              drop(v706_2);
              let v706_10: Space = if has_head(&(v706_9)) { singleton(&[]) } else { Space::new() };
              drop(v706_9);
              let v706_11: Space = compose(&(v706_10),&v693_3_cursor);
              drop(v706_10);
              let v706_12: Space = unite(&(v706_8),&(v706_11));
              drop(v706_11);
              join_wrapped_into(&mut v705_10_write,&((v706_12).read_zipper()),&[]);
              }
              v693_3_cursor.ascend(1);
            }
            drop(v705_10_write);
            compose(&(v694_9),&(v705_10))
          };
          drop(v694_9);
          let v694_12: Space = unite(&(v694_7),&(v694_11));
          join_wrapped_into(&mut v693_3_write,&((v694_12).read_zipper()),&[]);
          }
          v693_3_cursor.ascend(1);
        }
        drop(v693_3_cursor);
        drop(v693_3_write);
        drop(v693_2);
        let v693_4: Space = unite(&(v693_3),&(v674_7));
        let v693_5: Space = intersect(&(v693_4),&(*capture_2));
        if !v674_7.join_into((v693_5).clone()).is_element() { break; }
      }
      let v674_8: Space = subtract(&(v674_6),&(v674_7));
      let v674_9: Space = routine_16(c, &(*capture_3).path()[capture_4..(capture_4 + 1)], &(*capture_3), &(*capture_0), &(*capture_1), &((v674_8).read_zipper()));
      compose(&(v673_5),&(v674_9))
    };
    drop(v673_5);
    let v673_11: Space = intersect(&(*CONSTANT_12),&(v673_2));
    drop(v673_2);
    let v673_12: Space = if has_head(&(v673_11)) { singleton(&[]) } else { Space::new() };
    drop(v673_11);
    let v673_17: Space = if (&(v673_12)).is_empty() { Space::new() } else {
      let mut v711_13: Space = ((*capture_5)).clone();
      loop {
        let v712_1: Space = intersect(&(v711_13),&(*capture_2));
        let v712_2: Space = restrict_to(&(*capture_1),&(v712_1));
        drop(v712_1);
        let mut v712_3 = Space::new();
        let mut v712_3_write = v712_3.write_zipper();
        let mut v712_3_cursor = (v712_2).read_zipper();
        let v712_3_origin = v712_3_cursor.path().len();
        for v712_3_byte in v712_3_cursor.child_mask().iter() {
          v712_3_cursor.descend_to_existing_byte(v712_3_byte);
          {
          let v713_2: Space = singleton(&v712_3_cursor.path()[v712_3_origin..(v712_3_origin + 1)]);
          let v713_3: Space = intersect(&(*CONSTANT_12),&(v713_2));
          let v713_4: Space = if has_head(&(v713_3)) { singleton(&[]) } else { Space::new() };
          drop(v713_3);
          let v713_5: Space = subtract(&(*CONSTANT_0),&(v713_4));
          drop(v713_4);
          let v713_7: Space = if (&(v713_5)).is_empty() { Space::new() } else {
            let mut v714_6 = Space::new();
            let mut v714_6_write = v714_6.write_zipper();
            for v714_6_byte in v712_3_cursor.child_mask().iter() {
              v712_3_cursor.descend_to_existing_byte(v714_6_byte);
              {
              let v715_2: Space = singleton(&v712_3_cursor.path()[(v712_3_origin + 1)..(v712_3_origin + 2)]);
              let v715_3: Space = intersect(&(*CONSTANT_12),&(v715_2));
              let v715_4: Space = if has_head(&(v715_3)) { singleton(&[]) } else { Space::new() };
              drop(v715_3);
              let v715_5: Space = subtract(&(*CONSTANT_0),&(v715_4));
              drop(v715_4);
              let v715_8: Space = if (&(v715_5)).is_empty() { Space::new() } else {
                let mut v716_7 = Space::new();
                let mut v716_7_write = v716_7.write_zipper();
                for v716_7_byte in v712_3_cursor.child_mask().iter() {
                  v712_3_cursor.descend_to_existing_byte(v716_7_byte);
                  {
                  let v717_2: Space = singleton(&v712_3_cursor.path()[(v712_3_origin + 2)..(v712_3_origin + 3)]);
                  let v717_3: Space = intersect(&(*CONSTANT_12),&(v717_2));
                  let v717_4: Space = if has_head(&(v717_3)) { singleton(&[]) } else { Space::new() };
                  drop(v717_3);
                  let v717_5: Space = subtract(&(*CONSTANT_0),&(v717_4));
                  drop(v717_4);
                  let v717_8: Space = if (&(v717_5)).is_empty() { Space::new() } else {
                    let v718_7: Space = routine_41(c, &v712_3_cursor.path()[v712_3_origin..(v712_3_origin + 3)], &v712_3_cursor);
                    compose(&(v717_5),&(v718_7))
                  };
                  drop(v717_5);
                  let v717_9: Space = intersect(&(*CONSTANT_12),&(v717_2));
                  drop(v717_2);
                  let v717_10: Space = if has_head(&(v717_9)) { singleton(&[]) } else { Space::new() };
                  drop(v717_9);
                  let v717_12: Space = if (&(v717_10)).is_empty() { Space::new() } else {
                    let v719_11: Space = routine_42(c, &v712_3_cursor.path()[v712_3_origin..(v712_3_origin + 3)], &v712_3_cursor);
                    compose(&(v717_10),&(v719_11))
                  };
                  drop(v717_10);
                  let v717_13: Space = unite(&(v717_8),&(v717_12));
                  join_wrapped_into(&mut v716_7_write,&((v717_13).read_zipper()),&[]);
                  }
                  v712_3_cursor.ascend(1);
                }
                drop(v716_7_write);
                compose(&(v715_5),&(v716_7))
              };
              drop(v715_5);
              let v715_9: Space = intersect(&(*CONSTANT_12),&(v715_2));
              drop(v715_2);
              let v715_10: Space = if has_head(&(v715_9)) { singleton(&[]) } else { Space::new() };
              drop(v715_9);
              let v715_12: Space = if (&(v715_10)).is_empty() { Space::new() } else {
                let mut v720_11 = Space::new();
                let mut v720_11_write = v720_11.write_zipper();
                for v720_11_byte in v712_3_cursor.child_mask().iter() {
                  v712_3_cursor.descend_to_existing_byte(v720_11_byte);
                  {
                  let v721_2: Space = singleton(&v712_3_cursor.path()[(v712_3_origin + 2)..(v712_3_origin + 3)]);
                  let v721_3: Space = intersect(&(*CONSTANT_12),&(v721_2));
                  let v721_4: Space = if has_head(&(v721_3)) { singleton(&[]) } else { Space::new() };
                  drop(v721_3);
                  let v721_5: Space = subtract(&(*CONSTANT_0),&(v721_4));
                  drop(v721_4);
                  let v721_8: Space = if (&(v721_5)).is_empty() { Space::new() } else {
                    let v722_7: Space = routine_41(c, &v712_3_cursor.path()[v712_3_origin..(v712_3_origin + 3)], &v712_3_cursor);
                    compose(&(v721_5),&(v722_7))
                  };
                  drop(v721_5);
                  let v721_9: Space = intersect(&(*CONSTANT_12),&(v721_2));
                  drop(v721_2);
                  let v721_10: Space = if has_head(&(v721_9)) { singleton(&[]) } else { Space::new() };
                  drop(v721_9);
                  let v721_12: Space = if (&(v721_10)).is_empty() { Space::new() } else {
                    let v723_11: Space = routine_43(c, &v712_3_cursor.path()[v712_3_origin..(v712_3_origin + 3)], &v712_3_cursor);
                    compose(&(v721_10),&(v723_11))
                  };
                  drop(v721_10);
                  let v721_13: Space = unite(&(v721_8),&(v721_12));
                  join_wrapped_into(&mut v720_11_write,&((v721_13).read_zipper()),&[]);
                  }
                  v712_3_cursor.ascend(1);
                }
                drop(v720_11_write);
                compose(&(v715_10),&(v720_11))
              };
              drop(v715_10);
              let v715_13: Space = unite(&(v715_8),&(v715_12));
              join_wrapped_into(&mut v714_6_write,&((v715_13).read_zipper()),&[]);
              }
              v712_3_cursor.ascend(1);
            }
            drop(v714_6_write);
            compose(&(v713_5),&(v714_6))
          };
          drop(v713_5);
          let v713_8: Space = intersect(&(*CONSTANT_12),&(v713_2));
          drop(v713_2);
          let v713_9: Space = if has_head(&(v713_8)) { singleton(&[]) } else { Space::new() };
          drop(v713_8);
          let v713_11: Space = if (&(v713_9)).is_empty() { Space::new() } else {
            let mut v724_10 = Space::new();
            let mut v724_10_write = v724_10.write_zipper();
            for v724_10_byte in v712_3_cursor.child_mask().iter() {
              v712_3_cursor.descend_to_existing_byte(v724_10_byte);
              {
              let v725_2: Space = singleton(&v712_3_cursor.path()[(v712_3_origin + 1)..(v712_3_origin + 2)]);
              let v725_3: Space = intersect(&(*CONSTANT_12),&(v725_2));
              let v725_4: Space = if has_head(&(v725_3)) { singleton(&[]) } else { Space::new() };
              drop(v725_3);
              let v725_5: Space = subtract(&(*CONSTANT_0),&(v725_4));
              drop(v725_4);
              let v725_8: Space = if (&(v725_5)).is_empty() { Space::new() } else {
                let mut v726_7 = Space::new();
                let mut v726_7_write = v726_7.write_zipper();
                for v726_7_byte in v712_3_cursor.child_mask().iter() {
                  v712_3_cursor.descend_to_existing_byte(v726_7_byte);
                  {
                  let v727_2: Space = singleton(&v712_3_cursor.path()[(v712_3_origin + 2)..(v712_3_origin + 3)]);
                  let v727_3: Space = intersect(&(*CONSTANT_12),&(v727_2));
                  let v727_4: Space = if has_head(&(v727_3)) { singleton(&[]) } else { Space::new() };
                  drop(v727_3);
                  let v727_5: Space = subtract(&(*CONSTANT_0),&(v727_4));
                  drop(v727_4);
                  let v727_8: Space = if (&(v727_5)).is_empty() { Space::new() } else {
                    let v728_7: Space = routine_41(c, &v712_3_cursor.path()[v712_3_origin..(v712_3_origin + 3)], &v712_3_cursor);
                    compose(&(v727_5),&(v728_7))
                  };
                  drop(v727_5);
                  let v727_9: Space = intersect(&(*CONSTANT_12),&(v727_2));
                  drop(v727_2);
                  let v727_10: Space = if has_head(&(v727_9)) { singleton(&[]) } else { Space::new() };
                  drop(v727_9);
                  let v727_12: Space = if (&(v727_10)).is_empty() { Space::new() } else {
                    let v729_11: Space = routine_42(c, &v712_3_cursor.path()[v712_3_origin..(v712_3_origin + 3)], &v712_3_cursor);
                    compose(&(v727_10),&(v729_11))
                  };
                  drop(v727_10);
                  let v727_13: Space = unite(&(v727_8),&(v727_12));
                  join_wrapped_into(&mut v726_7_write,&((v727_13).read_zipper()),&[]);
                  }
                  v712_3_cursor.ascend(1);
                }
                drop(v726_7_write);
                compose(&(v725_5),&(v726_7))
              };
              drop(v725_5);
              let v725_9: Space = intersect(&(*CONSTANT_12),&(v725_2));
              drop(v725_2);
              let v725_10: Space = if has_head(&(v725_9)) { singleton(&[]) } else { Space::new() };
              drop(v725_9);
              let v725_11: Space = compose(&(v725_10),&v712_3_cursor);
              drop(v725_10);
              let v725_12: Space = unite(&(v725_8),&(v725_11));
              drop(v725_11);
              join_wrapped_into(&mut v724_10_write,&((v725_12).read_zipper()),&[]);
              }
              v712_3_cursor.ascend(1);
            }
            drop(v724_10_write);
            compose(&(v713_9),&(v724_10))
          };
          drop(v713_9);
          let v713_12: Space = unite(&(v713_7),&(v713_11));
          join_wrapped_into(&mut v712_3_write,&((v713_12).read_zipper()),&[]);
          }
          v712_3_cursor.ascend(1);
        }
        drop(v712_3_cursor);
        drop(v712_3_write);
        drop(v712_2);
        let v712_4: Space = unite(&(v712_3),&(v711_13));
        let v712_5: Space = intersect(&(v712_4),&(*capture_2));
        if !v711_13.join_into((v712_5).clone()).is_element() { break; }
      }
      let mut v711_14: Space = ((*capture_5)).clone();
      loop {
        let v730_1: Space = intersect(&(v711_14),&(*capture_2));
        let v730_2: Space = restrict_to(&(*capture_0),&(v730_1));
        drop(v730_1);
        let mut v730_3 = Space::new();
        let mut v730_3_write = v730_3.write_zipper();
        let mut v730_3_cursor = (v730_2).read_zipper();
        let v730_3_origin = v730_3_cursor.path().len();
        for v730_3_byte in v730_3_cursor.child_mask().iter() {
          v730_3_cursor.descend_to_existing_byte(v730_3_byte);
          {
          let v731_2: Space = singleton(&v730_3_cursor.path()[v730_3_origin..(v730_3_origin + 1)]);
          let v731_3: Space = intersect(&(*CONSTANT_12),&(v731_2));
          let v731_4: Space = if has_head(&(v731_3)) { singleton(&[]) } else { Space::new() };
          drop(v731_3);
          let v731_5: Space = subtract(&(*CONSTANT_0),&(v731_4));
          drop(v731_4);
          let v731_7: Space = if (&(v731_5)).is_empty() { Space::new() } else {
            let mut v732_6 = Space::new();
            let mut v732_6_write = v732_6.write_zipper();
            for v732_6_byte in v730_3_cursor.child_mask().iter() {
              v730_3_cursor.descend_to_existing_byte(v732_6_byte);
              {
              let v733_2: Space = singleton(&v730_3_cursor.path()[(v730_3_origin + 1)..(v730_3_origin + 2)]);
              let v733_3: Space = intersect(&(*CONSTANT_12),&(v733_2));
              let v733_4: Space = if has_head(&(v733_3)) { singleton(&[]) } else { Space::new() };
              drop(v733_3);
              let v733_5: Space = subtract(&(*CONSTANT_0),&(v733_4));
              drop(v733_4);
              let v733_8: Space = if (&(v733_5)).is_empty() { Space::new() } else {
                let mut v734_7 = Space::new();
                let mut v734_7_write = v734_7.write_zipper();
                for v734_7_byte in v730_3_cursor.child_mask().iter() {
                  v730_3_cursor.descend_to_existing_byte(v734_7_byte);
                  {
                  let v735_2: Space = singleton(&v730_3_cursor.path()[(v730_3_origin + 2)..(v730_3_origin + 3)]);
                  let v735_3: Space = intersect(&(*CONSTANT_12),&(v735_2));
                  let v735_4: Space = if has_head(&(v735_3)) { singleton(&[]) } else { Space::new() };
                  drop(v735_3);
                  let v735_5: Space = subtract(&(*CONSTANT_0),&(v735_4));
                  drop(v735_4);
                  let v735_8: Space = if (&(v735_5)).is_empty() { Space::new() } else {
                    let v736_7: Space = routine_41(c, &v730_3_cursor.path()[v730_3_origin..(v730_3_origin + 3)], &v730_3_cursor);
                    compose(&(v735_5),&(v736_7))
                  };
                  drop(v735_5);
                  let v735_9: Space = intersect(&(*CONSTANT_12),&(v735_2));
                  drop(v735_2);
                  let v735_10: Space = if has_head(&(v735_9)) { singleton(&[]) } else { Space::new() };
                  drop(v735_9);
                  let v735_12: Space = if (&(v735_10)).is_empty() { Space::new() } else {
                    let v737_11: Space = routine_42(c, &v730_3_cursor.path()[v730_3_origin..(v730_3_origin + 3)], &v730_3_cursor);
                    compose(&(v735_10),&(v737_11))
                  };
                  drop(v735_10);
                  let v735_13: Space = unite(&(v735_8),&(v735_12));
                  join_wrapped_into(&mut v734_7_write,&((v735_13).read_zipper()),&[]);
                  }
                  v730_3_cursor.ascend(1);
                }
                drop(v734_7_write);
                compose(&(v733_5),&(v734_7))
              };
              drop(v733_5);
              let v733_9: Space = intersect(&(*CONSTANT_12),&(v733_2));
              drop(v733_2);
              let v733_10: Space = if has_head(&(v733_9)) { singleton(&[]) } else { Space::new() };
              drop(v733_9);
              let v733_12: Space = if (&(v733_10)).is_empty() { Space::new() } else {
                let mut v738_11 = Space::new();
                let mut v738_11_write = v738_11.write_zipper();
                for v738_11_byte in v730_3_cursor.child_mask().iter() {
                  v730_3_cursor.descend_to_existing_byte(v738_11_byte);
                  {
                  let v739_2: Space = singleton(&v730_3_cursor.path()[(v730_3_origin + 2)..(v730_3_origin + 3)]);
                  let v739_3: Space = intersect(&(*CONSTANT_12),&(v739_2));
                  let v739_4: Space = if has_head(&(v739_3)) { singleton(&[]) } else { Space::new() };
                  drop(v739_3);
                  let v739_5: Space = subtract(&(*CONSTANT_0),&(v739_4));
                  drop(v739_4);
                  let v739_8: Space = if (&(v739_5)).is_empty() { Space::new() } else {
                    let v740_7: Space = routine_41(c, &v730_3_cursor.path()[v730_3_origin..(v730_3_origin + 3)], &v730_3_cursor);
                    compose(&(v739_5),&(v740_7))
                  };
                  drop(v739_5);
                  let v739_9: Space = intersect(&(*CONSTANT_12),&(v739_2));
                  drop(v739_2);
                  let v739_10: Space = if has_head(&(v739_9)) { singleton(&[]) } else { Space::new() };
                  drop(v739_9);
                  let v739_12: Space = if (&(v739_10)).is_empty() { Space::new() } else {
                    let v741_11: Space = routine_43(c, &v730_3_cursor.path()[v730_3_origin..(v730_3_origin + 3)], &v730_3_cursor);
                    compose(&(v739_10),&(v741_11))
                  };
                  drop(v739_10);
                  let v739_13: Space = unite(&(v739_8),&(v739_12));
                  join_wrapped_into(&mut v738_11_write,&((v739_13).read_zipper()),&[]);
                  }
                  v730_3_cursor.ascend(1);
                }
                drop(v738_11_write);
                compose(&(v733_10),&(v738_11))
              };
              drop(v733_10);
              let v733_13: Space = unite(&(v733_8),&(v733_12));
              join_wrapped_into(&mut v732_6_write,&((v733_13).read_zipper()),&[]);
              }
              v730_3_cursor.ascend(1);
            }
            drop(v732_6_write);
            compose(&(v731_5),&(v732_6))
          };
          drop(v731_5);
          let v731_8: Space = intersect(&(*CONSTANT_12),&(v731_2));
          drop(v731_2);
          let v731_9: Space = if has_head(&(v731_8)) { singleton(&[]) } else { Space::new() };
          drop(v731_8);
          let v731_11: Space = if (&(v731_9)).is_empty() { Space::new() } else {
            let mut v742_10 = Space::new();
            let mut v742_10_write = v742_10.write_zipper();
            for v742_10_byte in v730_3_cursor.child_mask().iter() {
              v730_3_cursor.descend_to_existing_byte(v742_10_byte);
              {
              let v743_2: Space = singleton(&v730_3_cursor.path()[(v730_3_origin + 1)..(v730_3_origin + 2)]);
              let v743_3: Space = intersect(&(*CONSTANT_12),&(v743_2));
              let v743_4: Space = if has_head(&(v743_3)) { singleton(&[]) } else { Space::new() };
              drop(v743_3);
              let v743_5: Space = subtract(&(*CONSTANT_0),&(v743_4));
              drop(v743_4);
              let v743_8: Space = if (&(v743_5)).is_empty() { Space::new() } else {
                let mut v744_7 = Space::new();
                let mut v744_7_write = v744_7.write_zipper();
                for v744_7_byte in v730_3_cursor.child_mask().iter() {
                  v730_3_cursor.descend_to_existing_byte(v744_7_byte);
                  {
                  let v745_2: Space = singleton(&v730_3_cursor.path()[(v730_3_origin + 2)..(v730_3_origin + 3)]);
                  let v745_3: Space = intersect(&(*CONSTANT_12),&(v745_2));
                  let v745_4: Space = if has_head(&(v745_3)) { singleton(&[]) } else { Space::new() };
                  drop(v745_3);
                  let v745_5: Space = subtract(&(*CONSTANT_0),&(v745_4));
                  drop(v745_4);
                  let v745_8: Space = if (&(v745_5)).is_empty() { Space::new() } else {
                    let v746_7: Space = routine_41(c, &v730_3_cursor.path()[v730_3_origin..(v730_3_origin + 3)], &v730_3_cursor);
                    compose(&(v745_5),&(v746_7))
                  };
                  drop(v745_5);
                  let v745_9: Space = intersect(&(*CONSTANT_12),&(v745_2));
                  drop(v745_2);
                  let v745_10: Space = if has_head(&(v745_9)) { singleton(&[]) } else { Space::new() };
                  drop(v745_9);
                  let v745_12: Space = if (&(v745_10)).is_empty() { Space::new() } else {
                    let v747_11: Space = routine_42(c, &v730_3_cursor.path()[v730_3_origin..(v730_3_origin + 3)], &v730_3_cursor);
                    compose(&(v745_10),&(v747_11))
                  };
                  drop(v745_10);
                  let v745_13: Space = unite(&(v745_8),&(v745_12));
                  join_wrapped_into(&mut v744_7_write,&((v745_13).read_zipper()),&[]);
                  }
                  v730_3_cursor.ascend(1);
                }
                drop(v744_7_write);
                compose(&(v743_5),&(v744_7))
              };
              drop(v743_5);
              let v743_9: Space = intersect(&(*CONSTANT_12),&(v743_2));
              drop(v743_2);
              let v743_10: Space = if has_head(&(v743_9)) { singleton(&[]) } else { Space::new() };
              drop(v743_9);
              let v743_11: Space = compose(&(v743_10),&v730_3_cursor);
              drop(v743_10);
              let v743_12: Space = unite(&(v743_8),&(v743_11));
              drop(v743_11);
              join_wrapped_into(&mut v742_10_write,&((v743_12).read_zipper()),&[]);
              }
              v730_3_cursor.ascend(1);
            }
            drop(v742_10_write);
            compose(&(v731_9),&(v742_10))
          };
          drop(v731_9);
          let v731_12: Space = unite(&(v731_7),&(v731_11));
          join_wrapped_into(&mut v730_3_write,&((v731_12).read_zipper()),&[]);
          }
          v730_3_cursor.ascend(1);
        }
        drop(v730_3_cursor);
        drop(v730_3_write);
        drop(v730_2);
        let v730_4: Space = unite(&(v730_3),&(v711_14));
        let v730_5: Space = intersect(&(v730_4),&(*capture_2));
        if !v711_14.join_into((v730_5).clone()).is_element() { break; }
      }
      let v711_15: Space = subtract(&(v711_13),&(v711_14));
      let v711_16: Space = routine_17(c, &(*capture_3).path()[capture_4..(capture_4 + 1)], &(*capture_3), &(*capture_0), &(*capture_1), &((v711_15).read_zipper()));
      compose(&(v673_12),&(v711_16))
    };
    drop(v673_12);

((v673_10).clone(),(v673_17).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let (mut v0_155,mut v0_22,mut v0_44,mut v0_63,mut v0_64,mut v0_65,) = native_block_0(c);
  (v0_155).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v82_6 = Space::new();
  let mut v82_6_write = v82_6.write_zipper();
  let mut v82_6_cursor = (*s0).read_zipper();
  let v82_6_origin = v82_6_cursor.path().len();
  for v82_6_byte in v82_6_cursor.child_mask().iter() {
    v82_6_cursor.descend_to_existing_byte(v82_6_byte);
    {
    let v83_2: Space = singleton(&v82_6_cursor.path()[v82_6_origin..(v82_6_origin + 1)]);
    let v83_3: Space = intersect(&(*CONSTANT_12),&(v83_2));
    let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
    drop(v83_3);
    let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
    drop(v83_4);
    let v83_7: Space = if (&(v83_5)).is_empty() { Space::new() } else {
      let mut v84_6 = Space::new();
      let mut v84_6_write = v84_6.write_zipper();
      for v84_6_byte in v82_6_cursor.child_mask().iter() {
        v82_6_cursor.descend_to_existing_byte(v84_6_byte);
        {
        let v85_2: Space = Space::new();
        join_wrapped_into(&mut v84_6_write,&((v85_2).read_zipper()),&[]);
        }
        v82_6_cursor.ascend(1);
      }
      drop(v84_6_write);
      compose(&(v83_5),&(v84_6))
    };
    drop(v83_5);
    let v83_8: Space = intersect(&(*CONSTANT_12),&(v83_2));
    drop(v83_2);
    let v83_9: Space = if has_head(&(v83_8)) { singleton(&[]) } else { Space::new() };
    drop(v83_8);
    let v83_12: Space = if (&(v83_9)).is_empty() { Space::new() } else {
      let v86_10: Path = concat_path(&(*p0),&v82_6_cursor.path()[v82_6_origin..(v82_6_origin + 1)]);
      let mut v86_11 = Space::new();
      let mut v86_11_write = v86_11.write_zipper();
      for v86_11_byte in v82_6_cursor.child_mask().iter() {
        v82_6_cursor.descend_to_existing_byte(v86_11_byte);
        {
        let v87_2: Space = singleton(&v82_6_cursor.path()[(v82_6_origin + 1)..(v82_6_origin + 2)]);
        let v87_3: Space = intersect(&(*CONSTANT_12),&(v87_2));
        drop(v87_2);
        let v87_4: Space = if has_head(&(v87_3)) { singleton(&[]) } else { Space::new() };
        drop(v87_3);
        let v87_7: Space = if (&(v87_4)).is_empty() { Space::new() } else {
          let v88_5: Path = concat_path(&(v86_10),&v82_6_cursor.path()[(v82_6_origin + 1)..(v82_6_origin + 2)]);
          let v88_6: Space = singleton(&(v88_5));
          drop(v88_5);
          compose(&(v87_4),&(v88_6))
        };
        drop(v87_4);
        join_wrapped_into(&mut v86_11_write,&((v87_7).read_zipper()),&[]);
        }
        v82_6_cursor.ascend(1);
      }
      drop(v86_11_write);
      drop(v86_10);
      compose(&(v83_9),&(v86_11))
    };
    drop(v83_9);
    let v83_13: Space = unite(&(v83_7),&(v83_12));
    drop(v83_7);
    drop(v83_12);
    join_wrapped_into(&mut v82_6_write,&((v83_13).read_zipper()),&[]);
    }
    v82_6_cursor.ascend(1);
  }
  drop(v82_6_cursor);
  drop(v82_6_write);
  (v82_6).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v89_5 = Space::new();
  let mut v89_5_write = v89_5.write_zipper();
  let mut v89_5_cursor = (*s0).read_zipper();
  let v89_5_origin = v89_5_cursor.path().len();
  for v89_5_byte in v89_5_cursor.child_mask().iter() {
    v89_5_cursor.descend_to_existing_byte(v89_5_byte);
    {
    let v90_2: Space = singleton(&v89_5_cursor.path()[v89_5_origin..(v89_5_origin + 1)]);
    let v90_3: Space = intersect(&(*CONSTANT_12),&(v90_2));
    let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
    drop(v90_3);
    let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
    drop(v90_4);
    let v90_7: Space = if (&(v90_5)).is_empty() { Space::new() } else {
      let mut v91_6 = Space::new();
      let mut v91_6_write = v91_6.write_zipper();
      for v91_6_byte in v89_5_cursor.child_mask().iter() {
        v89_5_cursor.descend_to_existing_byte(v91_6_byte);
        {
        let v92_2: Space = Space::new();
        join_wrapped_into(&mut v91_6_write,&((v92_2).read_zipper()),&[]);
        }
        v89_5_cursor.ascend(1);
      }
      drop(v91_6_write);
      compose(&(v90_5),&(v91_6))
    };
    drop(v90_5);
    let v90_8: Space = intersect(&(*CONSTANT_12),&(v90_2));
    drop(v90_2);
    let v90_9: Space = if has_head(&(v90_8)) { singleton(&[]) } else { Space::new() };
    drop(v90_8);
    let v90_12: Space = if (&(v90_9)).is_empty() { Space::new() } else {
      let v93_10: Path = concat_path(&(*p0),&v89_5_cursor.path()[v89_5_origin..(v89_5_origin + 1)]);
      let v93_11: Space = singleton(&(v93_10));
      drop(v93_10);
      compose(&(v90_9),&(v93_11))
    };
    drop(v90_9);
    let v90_13: Space = unite(&(v90_7),&(v90_12));
    drop(v90_7);
    drop(v90_12);
    join_wrapped_into(&mut v89_5_write,&((v90_13).read_zipper()),&[]);
    }
    v89_5_cursor.ascend(1);
  }
  drop(v89_5_cursor);
  drop(v89_5_write);
  (v89_5).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v94_2: Space = singleton(&(*p0));
  (v94_2).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v95_21 = Space::new();
  let mut v95_21_write = v95_21.write_zipper();
  let mut v95_21_cursor = (*s0).read_zipper();
  let v95_21_origin = v95_21_cursor.path().len();
  for v95_21_byte in v95_21_cursor.child_mask().iter() {
    v95_21_cursor.descend_to_existing_byte(v95_21_byte);
    {
    let v96_2: Space = singleton(&v95_21_cursor.path()[v95_21_origin..(v95_21_origin + 1)]);
    let v96_3: Space = intersect(&(*CONSTANT_12),&(v96_2));
    let v96_4: Space = if has_head(&(v96_3)) { singleton(&[]) } else { Space::new() };
    drop(v96_3);
    let v96_5: Space = subtract(&(*CONSTANT_0),&(v96_4));
    drop(v96_4);
    let v96_8: Space = if (&(v96_5)).is_empty() { Space::new() } else {
      let v97_6: Path = concat_path(&(*p0),&v95_21_cursor.path()[v95_21_origin..(v95_21_origin + 1)]);
      let mut v97_7 = Space::new();
      let mut v97_7_write = v97_7.write_zipper();
      for v97_7_byte in v95_21_cursor.child_mask().iter() {
        v95_21_cursor.descend_to_existing_byte(v97_7_byte);
        {
        let v98_2: Space = singleton(&v95_21_cursor.path()[(v95_21_origin + 1)..(v95_21_origin + 2)]);
        let v98_3: Space = intersect(&(*CONSTANT_12),&(v98_2));
        let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
        drop(v98_3);
        let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
        drop(v98_4);
        let v98_8: Space = if (&(v98_5)).is_empty() { Space::new() } else {
          let v99_6: Path = concat_path(&(v97_6),&v95_21_cursor.path()[(v95_21_origin + 1)..(v95_21_origin + 2)]);
          let mut v99_7 = Space::new();
          let mut v99_7_write = v99_7.write_zipper();
          for v99_7_byte in v95_21_cursor.child_mask().iter() {
            v95_21_cursor.descend_to_existing_byte(v99_7_byte);
            {
            let v100_2: Space = singleton(&v95_21_cursor.path()[(v95_21_origin + 2)..(v95_21_origin + 3)]);
            let v100_3: Space = intersect(&(*CONSTANT_12),&(v100_2));
            let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
            drop(v100_3);
            let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
            drop(v100_4);
            let v100_8: Space = if (&(v100_5)).is_empty() { Space::new() } else {
              let v101_6: Path = concat_path(&(v99_6),&v95_21_cursor.path()[(v95_21_origin + 2)..(v95_21_origin + 3)]);
              let v101_7: Space = routine_18(c, &(v101_6), &(*p1), &v95_21_cursor);
              compose(&(v100_5),&(v101_7))
            };
            drop(v100_5);
            let v100_9: Space = intersect(&(*CONSTANT_12),&(v100_2));
            drop(v100_2);
            let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
            drop(v100_9);
            let v100_12: Space = if (&(v100_10)).is_empty() { Space::new() } else {
              let v102_6: Path = concat_path(&(v99_6),&v95_21_cursor.path()[(v95_21_origin + 2)..(v95_21_origin + 3)]);
              let v102_11: Space = routine_19(c, &(v102_6), &(*p1), &v95_21_cursor);
              drop(v102_6);
              compose(&(v100_10),&(v102_11))
            };
            drop(v100_10);
            let v100_13: Space = unite(&(v100_8),&(v100_12));
            join_wrapped_into(&mut v99_7_write,&((v100_13).read_zipper()),&[]);
            }
            v95_21_cursor.ascend(1);
          }
          drop(v99_7_write);
          compose(&(v98_5),&(v99_7))
        };
        drop(v98_5);
        let v98_9: Space = intersect(&(*CONSTANT_12),&(v98_2));
        drop(v98_2);
        let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
        drop(v98_9);
        let v98_12: Space = if (&(v98_10)).is_empty() { Space::new() } else {
          let v103_6: Path = concat_path(&(v97_6),&v95_21_cursor.path()[(v95_21_origin + 1)..(v95_21_origin + 2)]);
          let mut v103_11 = Space::new();
          let mut v103_11_write = v103_11.write_zipper();
          for v103_11_byte in v95_21_cursor.child_mask().iter() {
            v95_21_cursor.descend_to_existing_byte(v103_11_byte);
            {
            let v104_2: Space = singleton(&v95_21_cursor.path()[(v95_21_origin + 2)..(v95_21_origin + 3)]);
            let v104_3: Space = intersect(&(*CONSTANT_12),&(v104_2));
            let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
            drop(v104_3);
            let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
            drop(v104_4);
            let v104_8: Space = if (&(v104_5)).is_empty() { Space::new() } else {
              let v105_6: Path = concat_path(&(v103_6),&v95_21_cursor.path()[(v95_21_origin + 2)..(v95_21_origin + 3)]);
              let v105_7: Space = routine_18(c, &(v105_6), &(*p1), &v95_21_cursor);
              compose(&(v104_5),&(v105_7))
            };
            drop(v104_5);
            let v104_9: Space = intersect(&(*CONSTANT_12),&(v104_2));
            drop(v104_2);
            let v104_10: Space = if has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
            drop(v104_9);
            let v104_12: Space = if (&(v104_10)).is_empty() { Space::new() } else {
              let v106_6: Path = concat_path(&(v103_6),&v95_21_cursor.path()[(v95_21_origin + 2)..(v95_21_origin + 3)]);
              let v106_11: Space = routine_20(c, &(v106_6), &(*p1), &v95_21_cursor);
              drop(v106_6);
              compose(&(v104_10),&(v106_11))
            };
            drop(v104_10);
            let v104_13: Space = unite(&(v104_8),&(v104_12));
            join_wrapped_into(&mut v103_11_write,&((v104_13).read_zipper()),&[]);
            }
            v95_21_cursor.ascend(1);
          }
          drop(v103_11_write);
          drop(v103_6);
          compose(&(v98_10),&(v103_11))
        };
        drop(v98_10);
        let v98_13: Space = unite(&(v98_8),&(v98_12));
        join_wrapped_into(&mut v97_7_write,&((v98_13).read_zipper()),&[]);
        }
        v95_21_cursor.ascend(1);
      }
      drop(v97_7_write);
      compose(&(v96_5),&(v97_7))
    };
    drop(v96_5);
    let v96_9: Space = intersect(&(*CONSTANT_12),&(v96_2));
    drop(v96_2);
    let v96_10: Space = if has_head(&(v96_9)) { singleton(&[]) } else { Space::new() };
    drop(v96_9);
    let v96_12: Space = if (&(v96_10)).is_empty() { Space::new() } else {
      let v107_6: Path = concat_path(&(*p0),&v95_21_cursor.path()[v95_21_origin..(v95_21_origin + 1)]);
      let mut v107_11 = Space::new();
      let mut v107_11_write = v107_11.write_zipper();
      for v107_11_byte in v95_21_cursor.child_mask().iter() {
        v95_21_cursor.descend_to_existing_byte(v107_11_byte);
        {
        let v108_2: Space = singleton(&v95_21_cursor.path()[(v95_21_origin + 1)..(v95_21_origin + 2)]);
        let v108_3: Space = intersect(&(*CONSTANT_12),&(v108_2));
        let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
        drop(v108_3);
        let v108_5: Space = subtract(&(*CONSTANT_0),&(v108_4));
        drop(v108_4);
        let v108_8: Space = if (&(v108_5)).is_empty() { Space::new() } else {
          let v109_6: Path = concat_path(&(v107_6),&v95_21_cursor.path()[(v95_21_origin + 1)..(v95_21_origin + 2)]);
          let mut v109_7 = Space::new();
          let mut v109_7_write = v109_7.write_zipper();
          for v109_7_byte in v95_21_cursor.child_mask().iter() {
            v95_21_cursor.descend_to_existing_byte(v109_7_byte);
            {
            let v110_2: Space = singleton(&v95_21_cursor.path()[(v95_21_origin + 2)..(v95_21_origin + 3)]);
            let v110_3: Space = intersect(&(*CONSTANT_12),&(v110_2));
            let v110_4: Space = if has_head(&(v110_3)) { singleton(&[]) } else { Space::new() };
            drop(v110_3);
            let v110_5: Space = subtract(&(*CONSTANT_0),&(v110_4));
            drop(v110_4);
            let v110_8: Space = if (&(v110_5)).is_empty() { Space::new() } else {
              let v111_6: Path = concat_path(&(v109_6),&v95_21_cursor.path()[(v95_21_origin + 2)..(v95_21_origin + 3)]);
              let v111_7: Space = routine_18(c, &(v111_6), &(*p1), &v95_21_cursor);
              compose(&(v110_5),&(v111_7))
            };
            drop(v110_5);
            let v110_9: Space = intersect(&(*CONSTANT_12),&(v110_2));
            drop(v110_2);
            let v110_10: Space = if has_head(&(v110_9)) { singleton(&[]) } else { Space::new() };
            drop(v110_9);
            let v110_12: Space = if (&(v110_10)).is_empty() { Space::new() } else {
              let v112_6: Path = concat_path(&(v109_6),&v95_21_cursor.path()[(v95_21_origin + 2)..(v95_21_origin + 3)]);
              let v112_11: Space = routine_19(c, &(v112_6), &(*p1), &v95_21_cursor);
              drop(v112_6);
              compose(&(v110_10),&(v112_11))
            };
            drop(v110_10);
            let v110_13: Space = unite(&(v110_8),&(v110_12));
            join_wrapped_into(&mut v109_7_write,&((v110_13).read_zipper()),&[]);
            }
            v95_21_cursor.ascend(1);
          }
          drop(v109_7_write);
          compose(&(v108_5),&(v109_7))
        };
        drop(v108_5);
        let v108_9: Space = intersect(&(*CONSTANT_12),&(v108_2));
        drop(v108_2);
        let v108_10: Space = if has_head(&(v108_9)) { singleton(&[]) } else { Space::new() };
        drop(v108_9);
        let v108_13: Space = if (&(v108_10)).is_empty() { Space::new() } else {
          let v113_6: Path = concat_path(&(v107_6),&v95_21_cursor.path()[(v95_21_origin + 1)..(v95_21_origin + 2)]);
          let v113_11: Path = concat_path(&(v113_6),&(*p1));
          drop(v113_6);
          let v113_12: Space = singleton(&(v113_11));
          drop(v113_11);
          compose(&(v108_10),&(v113_12))
        };
        drop(v108_10);
        let v108_14: Space = unite(&(v108_8),&(v108_13));
        drop(v108_13);
        join_wrapped_into(&mut v107_11_write,&((v108_14).read_zipper()),&[]);
        }
        v95_21_cursor.ascend(1);
      }
      drop(v107_11_write);
      drop(v107_6);
      compose(&(v96_10),&(v107_11))
    };
    drop(v96_10);
    let v96_13: Space = unite(&(v96_8),&(v96_12));
    join_wrapped_into(&mut v95_21_write,&((v96_13).read_zipper()),&[]);
    }
    v95_21_cursor.ascend(1);
  }
  drop(v95_21_cursor);
  drop(v95_21_write);
  (v95_21).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v114_9 = Space::new();
  let mut v114_9_write = v114_9.write_zipper();
  let mut v114_9_cursor = (*s0).read_zipper();
  let v114_9_origin = v114_9_cursor.path().len();
  for v114_9_byte in v114_9_cursor.child_mask().iter() {
    v114_9_cursor.descend_to_existing_byte(v114_9_byte);
    {
    let v115_2: Space = singleton(&v114_9_cursor.path()[v114_9_origin..(v114_9_origin + 1)]);
    let v115_3: Space = intersect(&(*CONSTANT_12),&(v115_2));
    let v115_4: Space = if has_head(&(v115_3)) { singleton(&[]) } else { Space::new() };
    drop(v115_3);
    let v115_5: Space = subtract(&(*CONSTANT_0),&(v115_4));
    drop(v115_4);
    let v115_7: Space = if (&(v115_5)).is_empty() { Space::new() } else {
      let mut v116_6 = Space::new();
      let mut v116_6_write = v116_6.write_zipper();
      for v116_6_byte in v114_9_cursor.child_mask().iter() {
        v114_9_cursor.descend_to_existing_byte(v116_6_byte);
        {
        let v117_2: Space = Space::new();
        join_wrapped_into(&mut v116_6_write,&((v117_2).read_zipper()),&[]);
        }
        v114_9_cursor.ascend(1);
      }
      drop(v116_6_write);
      compose(&(v115_5),&(v116_6))
    };
    drop(v115_5);
    let v115_8: Space = intersect(&(*CONSTANT_12),&(v115_2));
    drop(v115_2);
    let v115_9: Space = if has_head(&(v115_8)) { singleton(&[]) } else { Space::new() };
    drop(v115_8);
    let v115_12: Space = if (&(v115_9)).is_empty() { Space::new() } else {
      let v118_10: Path = concat_path(&(*p0),&v114_9_cursor.path()[v114_9_origin..(v114_9_origin + 1)]);
      let mut v118_11 = Space::new();
      let mut v118_11_write = v118_11.write_zipper();
      for v118_11_byte in v114_9_cursor.child_mask().iter() {
        v114_9_cursor.descend_to_existing_byte(v118_11_byte);
        {
        let v119_2: Space = singleton(&v114_9_cursor.path()[(v114_9_origin + 1)..(v114_9_origin + 2)]);
        let v119_3: Space = intersect(&(*CONSTANT_12),&(v119_2));
        drop(v119_2);
        let v119_4: Space = if has_head(&(v119_3)) { singleton(&[]) } else { Space::new() };
        drop(v119_3);
        let v119_7: Space = if (&(v119_4)).is_empty() { Space::new() } else {
          let v120_5: Path = concat_path(&(v118_10),&v114_9_cursor.path()[(v114_9_origin + 1)..(v114_9_origin + 2)]);
          let mut v120_6 = Space::new();
          let mut v120_6_write = v120_6.write_zipper();
          for v120_6_byte in v114_9_cursor.child_mask().iter() {
            v114_9_cursor.descend_to_existing_byte(v120_6_byte);
            {
            let v121_2: Space = singleton(&v114_9_cursor.path()[(v114_9_origin + 2)..(v114_9_origin + 3)]);
            let v121_3: Space = intersect(&(*CONSTANT_12),&(v121_2));
            let v121_4: Space = if has_head(&(v121_3)) { singleton(&[]) } else { Space::new() };
            drop(v121_3);
            let v121_5: Space = subtract(&(*CONSTANT_0),&(v121_4));
            drop(v121_4);
            let v121_7: Space = if (&(v121_5)).is_empty() { Space::new() } else {
              let v122_6: Space = routine_4(c, &v114_9_cursor.path()[(v114_9_origin + 2)..(v114_9_origin + 3)], &(v120_5), &v114_9_cursor);
              compose(&(v121_5),&(v122_6))
            };
            drop(v121_5);
            let v121_8: Space = intersect(&(*CONSTANT_12),&(v121_2));
            drop(v121_2);
            let v121_9: Space = if has_head(&(v121_8)) { singleton(&[]) } else { Space::new() };
            drop(v121_8);
            let v121_11: Space = if (&(v121_9)).is_empty() { Space::new() } else {
              let v123_10: Space = routine_21(c, &v114_9_cursor.path()[(v114_9_origin + 2)..(v114_9_origin + 3)], &(v120_5), &v114_9_cursor);
              compose(&(v121_9),&(v123_10))
            };
            drop(v121_9);
            let v121_12: Space = unite(&(v121_7),&(v121_11));
            join_wrapped_into(&mut v120_6_write,&((v121_12).read_zipper()),&[]);
            }
            v114_9_cursor.ascend(1);
          }
          drop(v120_6_write);
          drop(v120_5);
          compose(&(v119_4),&(v120_6))
        };
        drop(v119_4);
        join_wrapped_into(&mut v118_11_write,&((v119_7).read_zipper()),&[]);
        }
        v114_9_cursor.ascend(1);
      }
      drop(v118_11_write);
      drop(v118_10);
      compose(&(v115_9),&(v118_11))
    };
    drop(v115_9);
    let v115_13: Space = unite(&(v115_7),&(v115_12));
    drop(v115_7);
    join_wrapped_into(&mut v114_9_write,&((v115_13).read_zipper()),&[]);
    }
    v114_9_cursor.ascend(1);
  }
  drop(v114_9_cursor);
  drop(v114_9_write);
  (v114_9).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v124_14 = Space::new();
  let mut v124_14_write = v124_14.write_zipper();
  let mut v124_14_cursor = (*s0).read_zipper();
  let v124_14_origin = v124_14_cursor.path().len();
  for v124_14_byte in v124_14_cursor.child_mask().iter() {
    v124_14_cursor.descend_to_existing_byte(v124_14_byte);
    {
    let v125_2: Space = singleton(&v124_14_cursor.path()[v124_14_origin..(v124_14_origin + 1)]);
    let v125_3: Space = intersect(&(*CONSTANT_12),&(v125_2));
    let v125_4: Space = if has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
    drop(v125_3);
    let v125_5: Space = subtract(&(*CONSTANT_0),&(v125_4));
    drop(v125_4);
    let v125_7: Space = if (&(v125_5)).is_empty() { Space::new() } else {
      let mut v126_6 = Space::new();
      let mut v126_6_write = v126_6.write_zipper();
      for v126_6_byte in v124_14_cursor.child_mask().iter() {
        v124_14_cursor.descend_to_existing_byte(v126_6_byte);
        {
        let v127_2: Space = Space::new();
        join_wrapped_into(&mut v126_6_write,&((v127_2).read_zipper()),&[]);
        }
        v124_14_cursor.ascend(1);
      }
      drop(v126_6_write);
      compose(&(v125_5),&(v126_6))
    };
    drop(v125_5);
    let v125_8: Space = intersect(&(*CONSTANT_12),&(v125_2));
    drop(v125_2);
    let v125_9: Space = if has_head(&(v125_8)) { singleton(&[]) } else { Space::new() };
    drop(v125_8);
    let v125_12: Space = if (&(v125_9)).is_empty() { Space::new() } else {
      let v128_10: Path = concat_path(&(*p0),&v124_14_cursor.path()[v124_14_origin..(v124_14_origin + 1)]);
      let mut v128_11 = Space::new();
      let mut v128_11_write = v128_11.write_zipper();
      for v128_11_byte in v124_14_cursor.child_mask().iter() {
        v124_14_cursor.descend_to_existing_byte(v128_11_byte);
        {
        let v129_2: Space = singleton(&v124_14_cursor.path()[(v124_14_origin + 1)..(v124_14_origin + 2)]);
        let v129_3: Space = intersect(&(*CONSTANT_12),&(v129_2));
        let v129_4: Space = if has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
        drop(v129_3);
        let v129_5: Space = subtract(&(*CONSTANT_0),&(v129_4));
        drop(v129_4);
        let v129_7: Space = if (&(v129_5)).is_empty() { Space::new() } else {
          let mut v130_6 = Space::new();
          let mut v130_6_write = v130_6.write_zipper();
          for v130_6_byte in v124_14_cursor.child_mask().iter() {
            v124_14_cursor.descend_to_existing_byte(v130_6_byte);
            {
            let v131_2: Space = singleton(&v124_14_cursor.path()[(v124_14_origin + 2)..(v124_14_origin + 3)]);
            let v131_3: Space = intersect(&(*CONSTANT_12),&(v131_2));
            let v131_4: Space = if has_head(&(v131_3)) { singleton(&[]) } else { Space::new() };
            drop(v131_3);
            let v131_5: Space = subtract(&(*CONSTANT_0),&(v131_4));
            drop(v131_4);
            let v131_8: Space = if (&(v131_5)).is_empty() { Space::new() } else {
              let v132_7: Space = routine_22(c, &v124_14_cursor.path()[(v124_14_origin + 1)..(v124_14_origin + 3)], &(v128_10), &v124_14_cursor);
              compose(&(v131_5),&(v132_7))
            };
            drop(v131_5);
            let v131_9: Space = intersect(&(*CONSTANT_12),&(v131_2));
            drop(v131_2);
            let v131_10: Space = if has_head(&(v131_9)) { singleton(&[]) } else { Space::new() };
            drop(v131_9);
            let v131_12: Space = if (&(v131_10)).is_empty() { Space::new() } else {
              let v133_11: Space = routine_23(c, &v124_14_cursor.path()[(v124_14_origin + 1)..(v124_14_origin + 3)], &(v128_10), &v124_14_cursor);
              compose(&(v131_10),&(v133_11))
            };
            drop(v131_10);
            let v131_13: Space = unite(&(v131_8),&(v131_12));
            join_wrapped_into(&mut v130_6_write,&((v131_13).read_zipper()),&[]);
            }
            v124_14_cursor.ascend(1);
          }
          drop(v130_6_write);
          compose(&(v129_5),&(v130_6))
        };
        drop(v129_5);
        let v129_8: Space = intersect(&(*CONSTANT_12),&(v129_2));
        drop(v129_2);
        let v129_9: Space = if has_head(&(v129_8)) { singleton(&[]) } else { Space::new() };
        drop(v129_8);
        let v129_11: Space = if (&(v129_9)).is_empty() { Space::new() } else {
          let mut v134_10 = Space::new();
          let mut v134_10_write = v134_10.write_zipper();
          for v134_10_byte in v124_14_cursor.child_mask().iter() {
            v124_14_cursor.descend_to_existing_byte(v134_10_byte);
            {
            let v135_2: Space = singleton(&v124_14_cursor.path()[(v124_14_origin + 2)..(v124_14_origin + 3)]);
            let v135_3: Space = intersect(&(*CONSTANT_12),&(v135_2));
            let v135_4: Space = if has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
            drop(v135_3);
            let v135_5: Space = subtract(&(*CONSTANT_0),&(v135_4));
            drop(v135_4);
            let v135_8: Space = if (&(v135_5)).is_empty() { Space::new() } else {
              let v136_7: Space = routine_22(c, &v124_14_cursor.path()[(v124_14_origin + 1)..(v124_14_origin + 3)], &(v128_10), &v124_14_cursor);
              compose(&(v135_5),&(v136_7))
            };
            drop(v135_5);
            let v135_9: Space = intersect(&(*CONSTANT_12),&(v135_2));
            drop(v135_2);
            let v135_10: Space = if has_head(&(v135_9)) { singleton(&[]) } else { Space::new() };
            drop(v135_9);
            let v135_12: Space = if (&(v135_10)).is_empty() { Space::new() } else {
              let v137_11: Space = routine_20(c, &v124_14_cursor.path()[(v124_14_origin + 1)..(v124_14_origin + 3)], &(v128_10), &v124_14_cursor);
              compose(&(v135_10),&(v137_11))
            };
            drop(v135_10);
            let v135_13: Space = unite(&(v135_8),&(v135_12));
            join_wrapped_into(&mut v134_10_write,&((v135_13).read_zipper()),&[]);
            }
            v124_14_cursor.ascend(1);
          }
          drop(v134_10_write);
          compose(&(v129_9),&(v134_10))
        };
        drop(v129_9);
        let v129_12: Space = unite(&(v129_7),&(v129_11));
        join_wrapped_into(&mut v128_11_write,&((v129_12).read_zipper()),&[]);
        }
        v124_14_cursor.ascend(1);
      }
      drop(v128_11_write);
      drop(v128_10);
      compose(&(v125_9),&(v128_11))
    };
    drop(v125_9);
    let v125_13: Space = unite(&(v125_7),&(v125_12));
    drop(v125_7);
    join_wrapped_into(&mut v124_14_write,&((v125_13).read_zipper()),&[]);
    }
    v124_14_cursor.ascend(1);
  }
  drop(v124_14_cursor);
  drop(v124_14_write);
  (v124_14).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v138_20 = Space::new();
  let mut v138_20_write = v138_20.write_zipper();
  let mut v138_20_cursor = (*s0).read_zipper();
  let v138_20_origin = v138_20_cursor.path().len();
  for v138_20_byte in v138_20_cursor.child_mask().iter() {
    v138_20_cursor.descend_to_existing_byte(v138_20_byte);
    {
    let v139_2: Space = singleton(&v138_20_cursor.path()[v138_20_origin..(v138_20_origin + 1)]);
    let v139_3: Space = intersect(&(*CONSTANT_12),&(v139_2));
    let v139_4: Space = if has_head(&(v139_3)) { singleton(&[]) } else { Space::new() };
    drop(v139_3);
    let v139_5: Space = subtract(&(*CONSTANT_0),&(v139_4));
    drop(v139_4);
    let v139_7: Space = if (&(v139_5)).is_empty() { Space::new() } else {
      let mut v140_6 = Space::new();
      let mut v140_6_write = v140_6.write_zipper();
      for v140_6_byte in v138_20_cursor.child_mask().iter() {
        v138_20_cursor.descend_to_existing_byte(v140_6_byte);
        {
        let v141_2: Space = singleton(&v138_20_cursor.path()[(v138_20_origin + 1)..(v138_20_origin + 2)]);
        let v141_3: Space = intersect(&(*CONSTANT_12),&(v141_2));
        let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
        drop(v141_3);
        let v141_5: Space = subtract(&(*CONSTANT_0),&(v141_4));
        drop(v141_4);
        let v141_8: Space = if (&(v141_5)).is_empty() { Space::new() } else {
          let mut v142_7 = Space::new();
          let mut v142_7_write = v142_7.write_zipper();
          for v142_7_byte in v138_20_cursor.child_mask().iter() {
            v138_20_cursor.descend_to_existing_byte(v142_7_byte);
            {
            let v143_2: Space = singleton(&v138_20_cursor.path()[(v138_20_origin + 2)..(v138_20_origin + 3)]);
            let v143_3: Space = intersect(&(*CONSTANT_12),&(v143_2));
            let v143_4: Space = if has_head(&(v143_3)) { singleton(&[]) } else { Space::new() };
            drop(v143_3);
            let v143_5: Space = subtract(&(*CONSTANT_0),&(v143_4));
            drop(v143_4);
            let v143_8: Space = if (&(v143_5)).is_empty() { Space::new() } else {
              let v144_7: Space = routine_24(c, &v138_20_cursor.path()[v138_20_origin..(v138_20_origin + 3)], &(*p0), &v138_20_cursor);
              compose(&(v143_5),&(v144_7))
            };
            drop(v143_5);
            let v143_9: Space = intersect(&(*CONSTANT_12),&(v143_2));
            drop(v143_2);
            let v143_10: Space = if has_head(&(v143_9)) { singleton(&[]) } else { Space::new() };
            drop(v143_9);
            let v143_12: Space = if (&(v143_10)).is_empty() { Space::new() } else {
              let v145_11: Space = routine_25(c, &v138_20_cursor.path()[v138_20_origin..(v138_20_origin + 3)], &(*p0), &v138_20_cursor);
              compose(&(v143_10),&(v145_11))
            };
            drop(v143_10);
            let v143_13: Space = unite(&(v143_8),&(v143_12));
            join_wrapped_into(&mut v142_7_write,&((v143_13).read_zipper()),&[]);
            }
            v138_20_cursor.ascend(1);
          }
          drop(v142_7_write);
          compose(&(v141_5),&(v142_7))
        };
        drop(v141_5);
        let v141_9: Space = intersect(&(*CONSTANT_12),&(v141_2));
        drop(v141_2);
        let v141_10: Space = if has_head(&(v141_9)) { singleton(&[]) } else { Space::new() };
        drop(v141_9);
        let v141_12: Space = if (&(v141_10)).is_empty() { Space::new() } else {
          let mut v146_11 = Space::new();
          let mut v146_11_write = v146_11.write_zipper();
          for v146_11_byte in v138_20_cursor.child_mask().iter() {
            v138_20_cursor.descend_to_existing_byte(v146_11_byte);
            {
            let v147_2: Space = singleton(&v138_20_cursor.path()[(v138_20_origin + 2)..(v138_20_origin + 3)]);
            let v147_3: Space = intersect(&(*CONSTANT_12),&(v147_2));
            let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
            drop(v147_3);
            let v147_5: Space = subtract(&(*CONSTANT_0),&(v147_4));
            drop(v147_4);
            let v147_8: Space = if (&(v147_5)).is_empty() { Space::new() } else {
              let v148_7: Space = routine_24(c, &v138_20_cursor.path()[v138_20_origin..(v138_20_origin + 3)], &(*p0), &v138_20_cursor);
              compose(&(v147_5),&(v148_7))
            };
            drop(v147_5);
            let v147_9: Space = intersect(&(*CONSTANT_12),&(v147_2));
            drop(v147_2);
            let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
            drop(v147_9);
            let v147_12: Space = if (&(v147_10)).is_empty() { Space::new() } else {
              let v149_11: Space = routine_20(c, &v138_20_cursor.path()[v138_20_origin..(v138_20_origin + 3)], &(*p0), &v138_20_cursor);
              compose(&(v147_10),&(v149_11))
            };
            drop(v147_10);
            let v147_13: Space = unite(&(v147_8),&(v147_12));
            join_wrapped_into(&mut v146_11_write,&((v147_13).read_zipper()),&[]);
            }
            v138_20_cursor.ascend(1);
          }
          drop(v146_11_write);
          compose(&(v141_10),&(v146_11))
        };
        drop(v141_10);
        let v141_13: Space = unite(&(v141_8),&(v141_12));
        join_wrapped_into(&mut v140_6_write,&((v141_13).read_zipper()),&[]);
        }
        v138_20_cursor.ascend(1);
      }
      drop(v140_6_write);
      compose(&(v139_5),&(v140_6))
    };
    drop(v139_5);
    let v139_8: Space = intersect(&(*CONSTANT_12),&(v139_2));
    drop(v139_2);
    let v139_9: Space = if has_head(&(v139_8)) { singleton(&[]) } else { Space::new() };
    drop(v139_8);
    let v139_11: Space = if (&(v139_9)).is_empty() { Space::new() } else {
      let mut v150_10 = Space::new();
      let mut v150_10_write = v150_10.write_zipper();
      for v150_10_byte in v138_20_cursor.child_mask().iter() {
        v138_20_cursor.descend_to_existing_byte(v150_10_byte);
        {
        let v151_2: Space = singleton(&v138_20_cursor.path()[(v138_20_origin + 1)..(v138_20_origin + 2)]);
        let v151_3: Space = intersect(&(*CONSTANT_12),&(v151_2));
        let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
        drop(v151_3);
        let v151_5: Space = subtract(&(*CONSTANT_0),&(v151_4));
        drop(v151_4);
        let v151_8: Space = if (&(v151_5)).is_empty() { Space::new() } else {
          let mut v152_7 = Space::new();
          let mut v152_7_write = v152_7.write_zipper();
          for v152_7_byte in v138_20_cursor.child_mask().iter() {
            v138_20_cursor.descend_to_existing_byte(v152_7_byte);
            {
            let v153_2: Space = singleton(&v138_20_cursor.path()[(v138_20_origin + 2)..(v138_20_origin + 3)]);
            let v153_3: Space = intersect(&(*CONSTANT_12),&(v153_2));
            let v153_4: Space = if has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
            drop(v153_3);
            let v153_5: Space = subtract(&(*CONSTANT_0),&(v153_4));
            drop(v153_4);
            let v153_8: Space = if (&(v153_5)).is_empty() { Space::new() } else {
              let v154_7: Space = routine_24(c, &v138_20_cursor.path()[v138_20_origin..(v138_20_origin + 3)], &(*p0), &v138_20_cursor);
              compose(&(v153_5),&(v154_7))
            };
            drop(v153_5);
            let v153_9: Space = intersect(&(*CONSTANT_12),&(v153_2));
            drop(v153_2);
            let v153_10: Space = if has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
            drop(v153_9);
            let v153_12: Space = if (&(v153_10)).is_empty() { Space::new() } else {
              let v155_11: Space = routine_25(c, &v138_20_cursor.path()[v138_20_origin..(v138_20_origin + 3)], &(*p0), &v138_20_cursor);
              compose(&(v153_10),&(v155_11))
            };
            drop(v153_10);
            let v153_13: Space = unite(&(v153_8),&(v153_12));
            join_wrapped_into(&mut v152_7_write,&((v153_13).read_zipper()),&[]);
            }
            v138_20_cursor.ascend(1);
          }
          drop(v152_7_write);
          compose(&(v151_5),&(v152_7))
        };
        drop(v151_5);
        let v151_9: Space = intersect(&(*CONSTANT_12),&(v151_2));
        drop(v151_2);
        let v151_10: Space = if has_head(&(v151_9)) { singleton(&[]) } else { Space::new() };
        drop(v151_9);
        let v151_13: Space = if (&(v151_10)).is_empty() { Space::new() } else {
          let v156_11: Path = concat_path(&v138_20_cursor.path()[v138_20_origin..(v138_20_origin + 2)],&(*p0));
          let v156_12: Space = singleton(&(v156_11));
          drop(v156_11);
          compose(&(v151_10),&(v156_12))
        };
        drop(v151_10);
        let v151_14: Space = unite(&(v151_8),&(v151_13));
        drop(v151_13);
        join_wrapped_into(&mut v150_10_write,&((v151_14).read_zipper()),&[]);
        }
        v138_20_cursor.ascend(1);
      }
      drop(v150_10_write);
      compose(&(v139_9),&(v150_10))
    };
    drop(v139_9);
    let v139_12: Space = unite(&(v139_7),&(v139_11));
    join_wrapped_into(&mut v138_20_write,&((v139_12).read_zipper()),&[]);
    }
    v138_20_cursor.ascend(1);
  }
  drop(v138_20_cursor);
  drop(v138_20_write);
  (v138_20).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v157_6 = Space::new();
  let mut v157_6_write = v157_6.write_zipper();
  let mut v157_6_cursor = (*s0).read_zipper();
  let v157_6_origin = v157_6_cursor.path().len();
  for v157_6_byte in v157_6_cursor.child_mask().iter() {
    v157_6_cursor.descend_to_existing_byte(v157_6_byte);
    {
    let v158_2: Space = singleton(&v157_6_cursor.path()[v157_6_origin..(v157_6_origin + 1)]);
    let v158_3: Space = intersect(&(*CONSTANT_12),&(v158_2));
    let v158_4: Space = if has_head(&(v158_3)) { singleton(&[]) } else { Space::new() };
    drop(v158_3);
    let v158_5: Space = subtract(&(*CONSTANT_0),&(v158_4));
    drop(v158_4);
    let v158_7: Space = if (&(v158_5)).is_empty() { Space::new() } else {
      let mut v159_6 = Space::new();
      let mut v159_6_write = v159_6.write_zipper();
      for v159_6_byte in v157_6_cursor.child_mask().iter() {
        v157_6_cursor.descend_to_existing_byte(v159_6_byte);
        {
        let v160_2: Space = Space::new();
        join_wrapped_into(&mut v159_6_write,&((v160_2).read_zipper()),&[]);
        }
        v157_6_cursor.ascend(1);
      }
      drop(v159_6_write);
      compose(&(v158_5),&(v159_6))
    };
    drop(v158_5);
    let v158_8: Space = intersect(&(*CONSTANT_12),&(v158_2));
    drop(v158_2);
    let v158_9: Space = if has_head(&(v158_8)) { singleton(&[]) } else { Space::new() };
    drop(v158_8);
    let v158_12: Space = if (&(v158_9)).is_empty() { Space::new() } else {
      let v161_10: Path = concat_path(&(*p0),&v157_6_cursor.path()[v157_6_origin..(v157_6_origin + 1)]);
      let mut v161_11 = Space::new();
      let mut v161_11_write = v161_11.write_zipper();
      for v161_11_byte in v157_6_cursor.child_mask().iter() {
        v157_6_cursor.descend_to_existing_byte(v161_11_byte);
        {
        let v162_2: Space = singleton(&v157_6_cursor.path()[(v157_6_origin + 1)..(v157_6_origin + 2)]);
        let v162_3: Space = intersect(&(*CONSTANT_12),&(v162_2));
        drop(v162_2);
        let v162_4: Space = if has_head(&(v162_3)) { singleton(&[]) } else { Space::new() };
        drop(v162_3);
        let v162_7: Space = if (&(v162_4)).is_empty() { Space::new() } else {
          let v163_5: Path = concat_path(&(v161_10),&v157_6_cursor.path()[(v157_6_origin + 1)..(v157_6_origin + 2)]);
          let v163_6: Space = singleton(&(v163_5));
          drop(v163_5);
          compose(&(v162_4),&(v163_6))
        };
        drop(v162_4);
        join_wrapped_into(&mut v161_11_write,&((v162_7).read_zipper()),&[]);
        }
        v157_6_cursor.ascend(1);
      }
      drop(v161_11_write);
      drop(v161_10);
      compose(&(v158_9),&(v161_11))
    };
    drop(v158_9);
    let v158_13: Space = unite(&(v158_7),&(v158_12));
    drop(v158_7);
    drop(v158_12);
    join_wrapped_into(&mut v157_6_write,&((v158_13).read_zipper()),&[]);
    }
    v157_6_cursor.ascend(1);
  }
  drop(v157_6_cursor);
  drop(v157_6_write);
  (v157_6).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v164_5 = Space::new();
  let mut v164_5_write = v164_5.write_zipper();
  let mut v164_5_cursor = (*s0).read_zipper();
  let v164_5_origin = v164_5_cursor.path().len();
  for v164_5_byte in v164_5_cursor.child_mask().iter() {
    v164_5_cursor.descend_to_existing_byte(v164_5_byte);
    {
    let v165_2: Space = singleton(&v164_5_cursor.path()[v164_5_origin..(v164_5_origin + 1)]);
    let v165_3: Space = intersect(&(*CONSTANT_12),&(v165_2));
    let v165_4: Space = if has_head(&(v165_3)) { singleton(&[]) } else { Space::new() };
    drop(v165_3);
    let v165_5: Space = subtract(&(*CONSTANT_0),&(v165_4));
    drop(v165_4);
    let v165_7: Space = if (&(v165_5)).is_empty() { Space::new() } else {
      let mut v166_6 = Space::new();
      let mut v166_6_write = v166_6.write_zipper();
      for v166_6_byte in v164_5_cursor.child_mask().iter() {
        v164_5_cursor.descend_to_existing_byte(v166_6_byte);
        {
        let v167_2: Space = Space::new();
        join_wrapped_into(&mut v166_6_write,&((v167_2).read_zipper()),&[]);
        }
        v164_5_cursor.ascend(1);
      }
      drop(v166_6_write);
      compose(&(v165_5),&(v166_6))
    };
    drop(v165_5);
    let v165_8: Space = intersect(&(*CONSTANT_12),&(v165_2));
    drop(v165_2);
    let v165_9: Space = if has_head(&(v165_8)) { singleton(&[]) } else { Space::new() };
    drop(v165_8);
    let v165_12: Space = if (&(v165_9)).is_empty() { Space::new() } else {
      let v168_10: Path = concat_path(&(*p0),&v164_5_cursor.path()[v164_5_origin..(v164_5_origin + 1)]);
      let v168_11: Space = singleton(&(v168_10));
      drop(v168_10);
      compose(&(v165_9),&(v168_11))
    };
    drop(v165_9);
    let v165_13: Space = unite(&(v165_7),&(v165_12));
    drop(v165_7);
    drop(v165_12);
    join_wrapped_into(&mut v164_5_write,&((v165_13).read_zipper()),&[]);
    }
    v164_5_cursor.ascend(1);
  }
  drop(v164_5_cursor);
  drop(v164_5_write);
  (v164_5).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v169_2: Space = singleton(&(*p0));
  (v169_2).clone()
}

fn routine_11(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v170_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v170_2: Space = first_matching(&(*s0),&(*CONSTANT_0),false);
  let v170_3: Space = unite(&(v170_1),&(v170_2));
  drop(v170_1);
  drop(v170_2);
  let v170_6: Space = if (&(v170_3)).is_empty() { Space::new() } else {
    let v171_4: Space = routine_26(c, &(*s0));
    let v171_5: Space = subtract(&(*s0),&(v171_4));
    compose(&(v170_3),&(v171_5))
  };
  drop(v170_3);
  let v170_7: Space = subtract(&(*s0),&(v170_6));
  (v170_7).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v172_21 = Space::new();
  let mut v172_21_write = v172_21.write_zipper();
  let mut v172_21_cursor = (*s0).read_zipper();
  let v172_21_origin = v172_21_cursor.path().len();
  for v172_21_byte in v172_21_cursor.child_mask().iter() {
    v172_21_cursor.descend_to_existing_byte(v172_21_byte);
    {
    let v173_2: Space = singleton(&v172_21_cursor.path()[v172_21_origin..(v172_21_origin + 1)]);
    let v173_3: Space = intersect(&(*CONSTANT_12),&(v173_2));
    let v173_4: Space = if has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
    drop(v173_3);
    let v173_5: Space = subtract(&(*CONSTANT_0),&(v173_4));
    drop(v173_4);
    let v173_8: Space = if (&(v173_5)).is_empty() { Space::new() } else {
      let v174_6: Path = concat_path(&(*p0),&v172_21_cursor.path()[v172_21_origin..(v172_21_origin + 1)]);
      let mut v174_7 = Space::new();
      let mut v174_7_write = v174_7.write_zipper();
      for v174_7_byte in v172_21_cursor.child_mask().iter() {
        v172_21_cursor.descend_to_existing_byte(v174_7_byte);
        {
        let v175_2: Space = singleton(&v172_21_cursor.path()[(v172_21_origin + 1)..(v172_21_origin + 2)]);
        let v175_3: Space = intersect(&(*CONSTANT_12),&(v175_2));
        let v175_4: Space = if has_head(&(v175_3)) { singleton(&[]) } else { Space::new() };
        drop(v175_3);
        let v175_5: Space = subtract(&(*CONSTANT_0),&(v175_4));
        drop(v175_4);
        let v175_8: Space = if (&(v175_5)).is_empty() { Space::new() } else {
          let v176_6: Path = concat_path(&(v174_6),&v172_21_cursor.path()[(v172_21_origin + 1)..(v172_21_origin + 2)]);
          let mut v176_7 = Space::new();
          let mut v176_7_write = v176_7.write_zipper();
          for v176_7_byte in v172_21_cursor.child_mask().iter() {
            v172_21_cursor.descend_to_existing_byte(v176_7_byte);
            {
            let v177_2: Space = singleton(&v172_21_cursor.path()[(v172_21_origin + 2)..(v172_21_origin + 3)]);
            let v177_3: Space = intersect(&(*CONSTANT_12),&(v177_2));
            let v177_4: Space = if has_head(&(v177_3)) { singleton(&[]) } else { Space::new() };
            drop(v177_3);
            let v177_5: Space = subtract(&(*CONSTANT_0),&(v177_4));
            drop(v177_4);
            let v177_8: Space = if (&(v177_5)).is_empty() { Space::new() } else {
              let v178_6: Path = concat_path(&(v176_6),&v172_21_cursor.path()[(v172_21_origin + 2)..(v172_21_origin + 3)]);
              let v178_7: Space = routine_27(c, &(v178_6), &(*p1), &v172_21_cursor);
              compose(&(v177_5),&(v178_7))
            };
            drop(v177_5);
            let v177_9: Space = intersect(&(*CONSTANT_12),&(v177_2));
            drop(v177_2);
            let v177_10: Space = if has_head(&(v177_9)) { singleton(&[]) } else { Space::new() };
            drop(v177_9);
            let v177_12: Space = if (&(v177_10)).is_empty() { Space::new() } else {
              let v179_6: Path = concat_path(&(v176_6),&v172_21_cursor.path()[(v172_21_origin + 2)..(v172_21_origin + 3)]);
              let v179_11: Space = routine_28(c, &(v179_6), &(*p1), &v172_21_cursor);
              drop(v179_6);
              compose(&(v177_10),&(v179_11))
            };
            drop(v177_10);
            let v177_13: Space = unite(&(v177_8),&(v177_12));
            join_wrapped_into(&mut v176_7_write,&((v177_13).read_zipper()),&[]);
            }
            v172_21_cursor.ascend(1);
          }
          drop(v176_7_write);
          compose(&(v175_5),&(v176_7))
        };
        drop(v175_5);
        let v175_9: Space = intersect(&(*CONSTANT_12),&(v175_2));
        drop(v175_2);
        let v175_10: Space = if has_head(&(v175_9)) { singleton(&[]) } else { Space::new() };
        drop(v175_9);
        let v175_12: Space = if (&(v175_10)).is_empty() { Space::new() } else {
          let v180_6: Path = concat_path(&(v174_6),&v172_21_cursor.path()[(v172_21_origin + 1)..(v172_21_origin + 2)]);
          let mut v180_11 = Space::new();
          let mut v180_11_write = v180_11.write_zipper();
          for v180_11_byte in v172_21_cursor.child_mask().iter() {
            v172_21_cursor.descend_to_existing_byte(v180_11_byte);
            {
            let v181_2: Space = singleton(&v172_21_cursor.path()[(v172_21_origin + 2)..(v172_21_origin + 3)]);
            let v181_3: Space = intersect(&(*CONSTANT_12),&(v181_2));
            let v181_4: Space = if has_head(&(v181_3)) { singleton(&[]) } else { Space::new() };
            drop(v181_3);
            let v181_5: Space = subtract(&(*CONSTANT_0),&(v181_4));
            drop(v181_4);
            let v181_8: Space = if (&(v181_5)).is_empty() { Space::new() } else {
              let v182_6: Path = concat_path(&(v180_6),&v172_21_cursor.path()[(v172_21_origin + 2)..(v172_21_origin + 3)]);
              let v182_7: Space = routine_27(c, &(v182_6), &(*p1), &v172_21_cursor);
              compose(&(v181_5),&(v182_7))
            };
            drop(v181_5);
            let v181_9: Space = intersect(&(*CONSTANT_12),&(v181_2));
            drop(v181_2);
            let v181_10: Space = if has_head(&(v181_9)) { singleton(&[]) } else { Space::new() };
            drop(v181_9);
            let v181_12: Space = if (&(v181_10)).is_empty() { Space::new() } else {
              let v183_6: Path = concat_path(&(v180_6),&v172_21_cursor.path()[(v172_21_origin + 2)..(v172_21_origin + 3)]);
              let v183_11: Space = routine_29(c, &(v183_6), &(*p1), &v172_21_cursor);
              drop(v183_6);
              compose(&(v181_10),&(v183_11))
            };
            drop(v181_10);
            let v181_13: Space = unite(&(v181_8),&(v181_12));
            join_wrapped_into(&mut v180_11_write,&((v181_13).read_zipper()),&[]);
            }
            v172_21_cursor.ascend(1);
          }
          drop(v180_11_write);
          drop(v180_6);
          compose(&(v175_10),&(v180_11))
        };
        drop(v175_10);
        let v175_13: Space = unite(&(v175_8),&(v175_12));
        join_wrapped_into(&mut v174_7_write,&((v175_13).read_zipper()),&[]);
        }
        v172_21_cursor.ascend(1);
      }
      drop(v174_7_write);
      compose(&(v173_5),&(v174_7))
    };
    drop(v173_5);
    let v173_9: Space = intersect(&(*CONSTANT_12),&(v173_2));
    drop(v173_2);
    let v173_10: Space = if has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
    drop(v173_9);
    let v173_12: Space = if (&(v173_10)).is_empty() { Space::new() } else {
      let v184_6: Path = concat_path(&(*p0),&v172_21_cursor.path()[v172_21_origin..(v172_21_origin + 1)]);
      let mut v184_11 = Space::new();
      let mut v184_11_write = v184_11.write_zipper();
      for v184_11_byte in v172_21_cursor.child_mask().iter() {
        v172_21_cursor.descend_to_existing_byte(v184_11_byte);
        {
        let v185_2: Space = singleton(&v172_21_cursor.path()[(v172_21_origin + 1)..(v172_21_origin + 2)]);
        let v185_3: Space = intersect(&(*CONSTANT_12),&(v185_2));
        let v185_4: Space = if has_head(&(v185_3)) { singleton(&[]) } else { Space::new() };
        drop(v185_3);
        let v185_5: Space = subtract(&(*CONSTANT_0),&(v185_4));
        drop(v185_4);
        let v185_8: Space = if (&(v185_5)).is_empty() { Space::new() } else {
          let v186_6: Path = concat_path(&(v184_6),&v172_21_cursor.path()[(v172_21_origin + 1)..(v172_21_origin + 2)]);
          let mut v186_7 = Space::new();
          let mut v186_7_write = v186_7.write_zipper();
          for v186_7_byte in v172_21_cursor.child_mask().iter() {
            v172_21_cursor.descend_to_existing_byte(v186_7_byte);
            {
            let v187_2: Space = singleton(&v172_21_cursor.path()[(v172_21_origin + 2)..(v172_21_origin + 3)]);
            let v187_3: Space = intersect(&(*CONSTANT_12),&(v187_2));
            let v187_4: Space = if has_head(&(v187_3)) { singleton(&[]) } else { Space::new() };
            drop(v187_3);
            let v187_5: Space = subtract(&(*CONSTANT_0),&(v187_4));
            drop(v187_4);
            let v187_8: Space = if (&(v187_5)).is_empty() { Space::new() } else {
              let v188_6: Path = concat_path(&(v186_6),&v172_21_cursor.path()[(v172_21_origin + 2)..(v172_21_origin + 3)]);
              let v188_7: Space = routine_27(c, &(v188_6), &(*p1), &v172_21_cursor);
              compose(&(v187_5),&(v188_7))
            };
            drop(v187_5);
            let v187_9: Space = intersect(&(*CONSTANT_12),&(v187_2));
            drop(v187_2);
            let v187_10: Space = if has_head(&(v187_9)) { singleton(&[]) } else { Space::new() };
            drop(v187_9);
            let v187_12: Space = if (&(v187_10)).is_empty() { Space::new() } else {
              let v189_6: Path = concat_path(&(v186_6),&v172_21_cursor.path()[(v172_21_origin + 2)..(v172_21_origin + 3)]);
              let v189_11: Space = routine_28(c, &(v189_6), &(*p1), &v172_21_cursor);
              drop(v189_6);
              compose(&(v187_10),&(v189_11))
            };
            drop(v187_10);
            let v187_13: Space = unite(&(v187_8),&(v187_12));
            join_wrapped_into(&mut v186_7_write,&((v187_13).read_zipper()),&[]);
            }
            v172_21_cursor.ascend(1);
          }
          drop(v186_7_write);
          compose(&(v185_5),&(v186_7))
        };
        drop(v185_5);
        let v185_9: Space = intersect(&(*CONSTANT_12),&(v185_2));
        drop(v185_2);
        let v185_10: Space = if has_head(&(v185_9)) { singleton(&[]) } else { Space::new() };
        drop(v185_9);
        let v185_13: Space = if (&(v185_10)).is_empty() { Space::new() } else {
          let v190_6: Path = concat_path(&(v184_6),&v172_21_cursor.path()[(v172_21_origin + 1)..(v172_21_origin + 2)]);
          let v190_11: Path = concat_path(&(v190_6),&(*p1));
          drop(v190_6);
          let v190_12: Space = singleton(&(v190_11));
          drop(v190_11);
          compose(&(v185_10),&(v190_12))
        };
        drop(v185_10);
        let v185_14: Space = unite(&(v185_8),&(v185_13));
        drop(v185_13);
        join_wrapped_into(&mut v184_11_write,&((v185_14).read_zipper()),&[]);
        }
        v172_21_cursor.ascend(1);
      }
      drop(v184_11_write);
      drop(v184_6);
      compose(&(v173_10),&(v184_11))
    };
    drop(v173_10);
    let v173_13: Space = unite(&(v173_8),&(v173_12));
    join_wrapped_into(&mut v172_21_write,&((v173_13).read_zipper()),&[]);
    }
    v172_21_cursor.ascend(1);
  }
  drop(v172_21_cursor);
  drop(v172_21_write);
  (v172_21).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v191_9 = Space::new();
  let mut v191_9_write = v191_9.write_zipper();
  let mut v191_9_cursor = (*s0).read_zipper();
  let v191_9_origin = v191_9_cursor.path().len();
  for v191_9_byte in v191_9_cursor.child_mask().iter() {
    v191_9_cursor.descend_to_existing_byte(v191_9_byte);
    {
    let v192_2: Space = singleton(&v191_9_cursor.path()[v191_9_origin..(v191_9_origin + 1)]);
    let v192_3: Space = intersect(&(*CONSTANT_12),&(v192_2));
    let v192_4: Space = if has_head(&(v192_3)) { singleton(&[]) } else { Space::new() };
    drop(v192_3);
    let v192_5: Space = subtract(&(*CONSTANT_0),&(v192_4));
    drop(v192_4);
    let v192_7: Space = if (&(v192_5)).is_empty() { Space::new() } else {
      let mut v193_6 = Space::new();
      let mut v193_6_write = v193_6.write_zipper();
      for v193_6_byte in v191_9_cursor.child_mask().iter() {
        v191_9_cursor.descend_to_existing_byte(v193_6_byte);
        {
        let v194_2: Space = Space::new();
        join_wrapped_into(&mut v193_6_write,&((v194_2).read_zipper()),&[]);
        }
        v191_9_cursor.ascend(1);
      }
      drop(v193_6_write);
      compose(&(v192_5),&(v193_6))
    };
    drop(v192_5);
    let v192_8: Space = intersect(&(*CONSTANT_12),&(v192_2));
    drop(v192_2);
    let v192_9: Space = if has_head(&(v192_8)) { singleton(&[]) } else { Space::new() };
    drop(v192_8);
    let v192_12: Space = if (&(v192_9)).is_empty() { Space::new() } else {
      let v195_10: Path = concat_path(&(*p0),&v191_9_cursor.path()[v191_9_origin..(v191_9_origin + 1)]);
      let mut v195_11 = Space::new();
      let mut v195_11_write = v195_11.write_zipper();
      for v195_11_byte in v191_9_cursor.child_mask().iter() {
        v191_9_cursor.descend_to_existing_byte(v195_11_byte);
        {
        let v196_2: Space = singleton(&v191_9_cursor.path()[(v191_9_origin + 1)..(v191_9_origin + 2)]);
        let v196_3: Space = intersect(&(*CONSTANT_12),&(v196_2));
        drop(v196_2);
        let v196_4: Space = if has_head(&(v196_3)) { singleton(&[]) } else { Space::new() };
        drop(v196_3);
        let v196_7: Space = if (&(v196_4)).is_empty() { Space::new() } else {
          let v197_5: Path = concat_path(&(v195_10),&v191_9_cursor.path()[(v191_9_origin + 1)..(v191_9_origin + 2)]);
          let mut v197_6 = Space::new();
          let mut v197_6_write = v197_6.write_zipper();
          for v197_6_byte in v191_9_cursor.child_mask().iter() {
            v191_9_cursor.descend_to_existing_byte(v197_6_byte);
            {
            let v198_2: Space = singleton(&v191_9_cursor.path()[(v191_9_origin + 2)..(v191_9_origin + 3)]);
            let v198_3: Space = intersect(&(*CONSTANT_12),&(v198_2));
            let v198_4: Space = if has_head(&(v198_3)) { singleton(&[]) } else { Space::new() };
            drop(v198_3);
            let v198_5: Space = subtract(&(*CONSTANT_0),&(v198_4));
            drop(v198_4);
            let v198_7: Space = if (&(v198_5)).is_empty() { Space::new() } else {
              let v199_6: Space = routine_12(c, &v191_9_cursor.path()[(v191_9_origin + 2)..(v191_9_origin + 3)], &(v197_5), &v191_9_cursor);
              compose(&(v198_5),&(v199_6))
            };
            drop(v198_5);
            let v198_8: Space = intersect(&(*CONSTANT_12),&(v198_2));
            drop(v198_2);
            let v198_9: Space = if has_head(&(v198_8)) { singleton(&[]) } else { Space::new() };
            drop(v198_8);
            let v198_11: Space = if (&(v198_9)).is_empty() { Space::new() } else {
              let v200_10: Space = routine_30(c, &v191_9_cursor.path()[(v191_9_origin + 2)..(v191_9_origin + 3)], &(v197_5), &v191_9_cursor);
              compose(&(v198_9),&(v200_10))
            };
            drop(v198_9);
            let v198_12: Space = unite(&(v198_7),&(v198_11));
            join_wrapped_into(&mut v197_6_write,&((v198_12).read_zipper()),&[]);
            }
            v191_9_cursor.ascend(1);
          }
          drop(v197_6_write);
          drop(v197_5);
          compose(&(v196_4),&(v197_6))
        };
        drop(v196_4);
        join_wrapped_into(&mut v195_11_write,&((v196_7).read_zipper()),&[]);
        }
        v191_9_cursor.ascend(1);
      }
      drop(v195_11_write);
      drop(v195_10);
      compose(&(v192_9),&(v195_11))
    };
    drop(v192_9);
    let v192_13: Space = unite(&(v192_7),&(v192_12));
    drop(v192_7);
    join_wrapped_into(&mut v191_9_write,&((v192_13).read_zipper()),&[]);
    }
    v191_9_cursor.ascend(1);
  }
  drop(v191_9_cursor);
  drop(v191_9_write);
  (v191_9).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v201_14 = Space::new();
  let mut v201_14_write = v201_14.write_zipper();
  let mut v201_14_cursor = (*s0).read_zipper();
  let v201_14_origin = v201_14_cursor.path().len();
  for v201_14_byte in v201_14_cursor.child_mask().iter() {
    v201_14_cursor.descend_to_existing_byte(v201_14_byte);
    {
    let v202_2: Space = singleton(&v201_14_cursor.path()[v201_14_origin..(v201_14_origin + 1)]);
    let v202_3: Space = intersect(&(*CONSTANT_12),&(v202_2));
    let v202_4: Space = if has_head(&(v202_3)) { singleton(&[]) } else { Space::new() };
    drop(v202_3);
    let v202_5: Space = subtract(&(*CONSTANT_0),&(v202_4));
    drop(v202_4);
    let v202_7: Space = if (&(v202_5)).is_empty() { Space::new() } else {
      let mut v203_6 = Space::new();
      let mut v203_6_write = v203_6.write_zipper();
      for v203_6_byte in v201_14_cursor.child_mask().iter() {
        v201_14_cursor.descend_to_existing_byte(v203_6_byte);
        {
        let v204_2: Space = Space::new();
        join_wrapped_into(&mut v203_6_write,&((v204_2).read_zipper()),&[]);
        }
        v201_14_cursor.ascend(1);
      }
      drop(v203_6_write);
      compose(&(v202_5),&(v203_6))
    };
    drop(v202_5);
    let v202_8: Space = intersect(&(*CONSTANT_12),&(v202_2));
    drop(v202_2);
    let v202_9: Space = if has_head(&(v202_8)) { singleton(&[]) } else { Space::new() };
    drop(v202_8);
    let v202_12: Space = if (&(v202_9)).is_empty() { Space::new() } else {
      let v205_10: Path = concat_path(&(*p0),&v201_14_cursor.path()[v201_14_origin..(v201_14_origin + 1)]);
      let mut v205_11 = Space::new();
      let mut v205_11_write = v205_11.write_zipper();
      for v205_11_byte in v201_14_cursor.child_mask().iter() {
        v201_14_cursor.descend_to_existing_byte(v205_11_byte);
        {
        let v206_2: Space = singleton(&v201_14_cursor.path()[(v201_14_origin + 1)..(v201_14_origin + 2)]);
        let v206_3: Space = intersect(&(*CONSTANT_12),&(v206_2));
        let v206_4: Space = if has_head(&(v206_3)) { singleton(&[]) } else { Space::new() };
        drop(v206_3);
        let v206_5: Space = subtract(&(*CONSTANT_0),&(v206_4));
        drop(v206_4);
        let v206_7: Space = if (&(v206_5)).is_empty() { Space::new() } else {
          let mut v207_6 = Space::new();
          let mut v207_6_write = v207_6.write_zipper();
          for v207_6_byte in v201_14_cursor.child_mask().iter() {
            v201_14_cursor.descend_to_existing_byte(v207_6_byte);
            {
            let v208_2: Space = singleton(&v201_14_cursor.path()[(v201_14_origin + 2)..(v201_14_origin + 3)]);
            let v208_3: Space = intersect(&(*CONSTANT_12),&(v208_2));
            let v208_4: Space = if has_head(&(v208_3)) { singleton(&[]) } else { Space::new() };
            drop(v208_3);
            let v208_5: Space = subtract(&(*CONSTANT_0),&(v208_4));
            drop(v208_4);
            let v208_8: Space = if (&(v208_5)).is_empty() { Space::new() } else {
              let v209_7: Space = routine_31(c, &v201_14_cursor.path()[(v201_14_origin + 1)..(v201_14_origin + 3)], &(v205_10), &v201_14_cursor);
              compose(&(v208_5),&(v209_7))
            };
            drop(v208_5);
            let v208_9: Space = intersect(&(*CONSTANT_12),&(v208_2));
            drop(v208_2);
            let v208_10: Space = if has_head(&(v208_9)) { singleton(&[]) } else { Space::new() };
            drop(v208_9);
            let v208_12: Space = if (&(v208_10)).is_empty() { Space::new() } else {
              let v210_11: Space = routine_32(c, &v201_14_cursor.path()[(v201_14_origin + 1)..(v201_14_origin + 3)], &(v205_10), &v201_14_cursor);
              compose(&(v208_10),&(v210_11))
            };
            drop(v208_10);
            let v208_13: Space = unite(&(v208_8),&(v208_12));
            join_wrapped_into(&mut v207_6_write,&((v208_13).read_zipper()),&[]);
            }
            v201_14_cursor.ascend(1);
          }
          drop(v207_6_write);
          compose(&(v206_5),&(v207_6))
        };
        drop(v206_5);
        let v206_8: Space = intersect(&(*CONSTANT_12),&(v206_2));
        drop(v206_2);
        let v206_9: Space = if has_head(&(v206_8)) { singleton(&[]) } else { Space::new() };
        drop(v206_8);
        let v206_11: Space = if (&(v206_9)).is_empty() { Space::new() } else {
          let mut v211_10 = Space::new();
          let mut v211_10_write = v211_10.write_zipper();
          for v211_10_byte in v201_14_cursor.child_mask().iter() {
            v201_14_cursor.descend_to_existing_byte(v211_10_byte);
            {
            let v212_2: Space = singleton(&v201_14_cursor.path()[(v201_14_origin + 2)..(v201_14_origin + 3)]);
            let v212_3: Space = intersect(&(*CONSTANT_12),&(v212_2));
            let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
            drop(v212_3);
            let v212_5: Space = subtract(&(*CONSTANT_0),&(v212_4));
            drop(v212_4);
            let v212_8: Space = if (&(v212_5)).is_empty() { Space::new() } else {
              let v213_7: Space = routine_31(c, &v201_14_cursor.path()[(v201_14_origin + 1)..(v201_14_origin + 3)], &(v205_10), &v201_14_cursor);
              compose(&(v212_5),&(v213_7))
            };
            drop(v212_5);
            let v212_9: Space = intersect(&(*CONSTANT_12),&(v212_2));
            drop(v212_2);
            let v212_10: Space = if has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
            drop(v212_9);
            let v212_12: Space = if (&(v212_10)).is_empty() { Space::new() } else {
              let v214_11: Space = routine_29(c, &v201_14_cursor.path()[(v201_14_origin + 1)..(v201_14_origin + 3)], &(v205_10), &v201_14_cursor);
              compose(&(v212_10),&(v214_11))
            };
            drop(v212_10);
            let v212_13: Space = unite(&(v212_8),&(v212_12));
            join_wrapped_into(&mut v211_10_write,&((v212_13).read_zipper()),&[]);
            }
            v201_14_cursor.ascend(1);
          }
          drop(v211_10_write);
          compose(&(v206_9),&(v211_10))
        };
        drop(v206_9);
        let v206_12: Space = unite(&(v206_7),&(v206_11));
        join_wrapped_into(&mut v205_11_write,&((v206_12).read_zipper()),&[]);
        }
        v201_14_cursor.ascend(1);
      }
      drop(v205_11_write);
      drop(v205_10);
      compose(&(v202_9),&(v205_11))
    };
    drop(v202_9);
    let v202_13: Space = unite(&(v202_7),&(v202_12));
    drop(v202_7);
    join_wrapped_into(&mut v201_14_write,&((v202_13).read_zipper()),&[]);
    }
    v201_14_cursor.ascend(1);
  }
  drop(v201_14_cursor);
  drop(v201_14_write);
  (v201_14).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v215_20 = Space::new();
  let mut v215_20_write = v215_20.write_zipper();
  let mut v215_20_cursor = (*s0).read_zipper();
  let v215_20_origin = v215_20_cursor.path().len();
  for v215_20_byte in v215_20_cursor.child_mask().iter() {
    v215_20_cursor.descend_to_existing_byte(v215_20_byte);
    {
    let v216_2: Space = singleton(&v215_20_cursor.path()[v215_20_origin..(v215_20_origin + 1)]);
    let v216_3: Space = intersect(&(*CONSTANT_12),&(v216_2));
    let v216_4: Space = if has_head(&(v216_3)) { singleton(&[]) } else { Space::new() };
    drop(v216_3);
    let v216_5: Space = subtract(&(*CONSTANT_0),&(v216_4));
    drop(v216_4);
    let v216_7: Space = if (&(v216_5)).is_empty() { Space::new() } else {
      let mut v217_6 = Space::new();
      let mut v217_6_write = v217_6.write_zipper();
      for v217_6_byte in v215_20_cursor.child_mask().iter() {
        v215_20_cursor.descend_to_existing_byte(v217_6_byte);
        {
        let v218_2: Space = singleton(&v215_20_cursor.path()[(v215_20_origin + 1)..(v215_20_origin + 2)]);
        let v218_3: Space = intersect(&(*CONSTANT_12),&(v218_2));
        let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
        drop(v218_3);
        let v218_5: Space = subtract(&(*CONSTANT_0),&(v218_4));
        drop(v218_4);
        let v218_8: Space = if (&(v218_5)).is_empty() { Space::new() } else {
          let mut v219_7 = Space::new();
          let mut v219_7_write = v219_7.write_zipper();
          for v219_7_byte in v215_20_cursor.child_mask().iter() {
            v215_20_cursor.descend_to_existing_byte(v219_7_byte);
            {
            let v220_2: Space = singleton(&v215_20_cursor.path()[(v215_20_origin + 2)..(v215_20_origin + 3)]);
            let v220_3: Space = intersect(&(*CONSTANT_12),&(v220_2));
            let v220_4: Space = if has_head(&(v220_3)) { singleton(&[]) } else { Space::new() };
            drop(v220_3);
            let v220_5: Space = subtract(&(*CONSTANT_0),&(v220_4));
            drop(v220_4);
            let v220_8: Space = if (&(v220_5)).is_empty() { Space::new() } else {
              let v221_7: Space = routine_33(c, &v215_20_cursor.path()[v215_20_origin..(v215_20_origin + 3)], &(*p0), &v215_20_cursor);
              compose(&(v220_5),&(v221_7))
            };
            drop(v220_5);
            let v220_9: Space = intersect(&(*CONSTANT_12),&(v220_2));
            drop(v220_2);
            let v220_10: Space = if has_head(&(v220_9)) { singleton(&[]) } else { Space::new() };
            drop(v220_9);
            let v220_12: Space = if (&(v220_10)).is_empty() { Space::new() } else {
              let v222_11: Space = routine_34(c, &v215_20_cursor.path()[v215_20_origin..(v215_20_origin + 3)], &(*p0), &v215_20_cursor);
              compose(&(v220_10),&(v222_11))
            };
            drop(v220_10);
            let v220_13: Space = unite(&(v220_8),&(v220_12));
            join_wrapped_into(&mut v219_7_write,&((v220_13).read_zipper()),&[]);
            }
            v215_20_cursor.ascend(1);
          }
          drop(v219_7_write);
          compose(&(v218_5),&(v219_7))
        };
        drop(v218_5);
        let v218_9: Space = intersect(&(*CONSTANT_12),&(v218_2));
        drop(v218_2);
        let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
        drop(v218_9);
        let v218_12: Space = if (&(v218_10)).is_empty() { Space::new() } else {
          let mut v223_11 = Space::new();
          let mut v223_11_write = v223_11.write_zipper();
          for v223_11_byte in v215_20_cursor.child_mask().iter() {
            v215_20_cursor.descend_to_existing_byte(v223_11_byte);
            {
            let v224_2: Space = singleton(&v215_20_cursor.path()[(v215_20_origin + 2)..(v215_20_origin + 3)]);
            let v224_3: Space = intersect(&(*CONSTANT_12),&(v224_2));
            let v224_4: Space = if has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
            drop(v224_3);
            let v224_5: Space = subtract(&(*CONSTANT_0),&(v224_4));
            drop(v224_4);
            let v224_8: Space = if (&(v224_5)).is_empty() { Space::new() } else {
              let v225_7: Space = routine_33(c, &v215_20_cursor.path()[v215_20_origin..(v215_20_origin + 3)], &(*p0), &v215_20_cursor);
              compose(&(v224_5),&(v225_7))
            };
            drop(v224_5);
            let v224_9: Space = intersect(&(*CONSTANT_12),&(v224_2));
            drop(v224_2);
            let v224_10: Space = if has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
            drop(v224_9);
            let v224_12: Space = if (&(v224_10)).is_empty() { Space::new() } else {
              let v226_11: Space = routine_29(c, &v215_20_cursor.path()[v215_20_origin..(v215_20_origin + 3)], &(*p0), &v215_20_cursor);
              compose(&(v224_10),&(v226_11))
            };
            drop(v224_10);
            let v224_13: Space = unite(&(v224_8),&(v224_12));
            join_wrapped_into(&mut v223_11_write,&((v224_13).read_zipper()),&[]);
            }
            v215_20_cursor.ascend(1);
          }
          drop(v223_11_write);
          compose(&(v218_10),&(v223_11))
        };
        drop(v218_10);
        let v218_13: Space = unite(&(v218_8),&(v218_12));
        join_wrapped_into(&mut v217_6_write,&((v218_13).read_zipper()),&[]);
        }
        v215_20_cursor.ascend(1);
      }
      drop(v217_6_write);
      compose(&(v216_5),&(v217_6))
    };
    drop(v216_5);
    let v216_8: Space = intersect(&(*CONSTANT_12),&(v216_2));
    drop(v216_2);
    let v216_9: Space = if has_head(&(v216_8)) { singleton(&[]) } else { Space::new() };
    drop(v216_8);
    let v216_11: Space = if (&(v216_9)).is_empty() { Space::new() } else {
      let mut v227_10 = Space::new();
      let mut v227_10_write = v227_10.write_zipper();
      for v227_10_byte in v215_20_cursor.child_mask().iter() {
        v215_20_cursor.descend_to_existing_byte(v227_10_byte);
        {
        let v228_2: Space = singleton(&v215_20_cursor.path()[(v215_20_origin + 1)..(v215_20_origin + 2)]);
        let v228_3: Space = intersect(&(*CONSTANT_12),&(v228_2));
        let v228_4: Space = if has_head(&(v228_3)) { singleton(&[]) } else { Space::new() };
        drop(v228_3);
        let v228_5: Space = subtract(&(*CONSTANT_0),&(v228_4));
        drop(v228_4);
        let v228_8: Space = if (&(v228_5)).is_empty() { Space::new() } else {
          let mut v229_7 = Space::new();
          let mut v229_7_write = v229_7.write_zipper();
          for v229_7_byte in v215_20_cursor.child_mask().iter() {
            v215_20_cursor.descend_to_existing_byte(v229_7_byte);
            {
            let v230_2: Space = singleton(&v215_20_cursor.path()[(v215_20_origin + 2)..(v215_20_origin + 3)]);
            let v230_3: Space = intersect(&(*CONSTANT_12),&(v230_2));
            let v230_4: Space = if has_head(&(v230_3)) { singleton(&[]) } else { Space::new() };
            drop(v230_3);
            let v230_5: Space = subtract(&(*CONSTANT_0),&(v230_4));
            drop(v230_4);
            let v230_8: Space = if (&(v230_5)).is_empty() { Space::new() } else {
              let v231_7: Space = routine_33(c, &v215_20_cursor.path()[v215_20_origin..(v215_20_origin + 3)], &(*p0), &v215_20_cursor);
              compose(&(v230_5),&(v231_7))
            };
            drop(v230_5);
            let v230_9: Space = intersect(&(*CONSTANT_12),&(v230_2));
            drop(v230_2);
            let v230_10: Space = if has_head(&(v230_9)) { singleton(&[]) } else { Space::new() };
            drop(v230_9);
            let v230_12: Space = if (&(v230_10)).is_empty() { Space::new() } else {
              let v232_11: Space = routine_34(c, &v215_20_cursor.path()[v215_20_origin..(v215_20_origin + 3)], &(*p0), &v215_20_cursor);
              compose(&(v230_10),&(v232_11))
            };
            drop(v230_10);
            let v230_13: Space = unite(&(v230_8),&(v230_12));
            join_wrapped_into(&mut v229_7_write,&((v230_13).read_zipper()),&[]);
            }
            v215_20_cursor.ascend(1);
          }
          drop(v229_7_write);
          compose(&(v228_5),&(v229_7))
        };
        drop(v228_5);
        let v228_9: Space = intersect(&(*CONSTANT_12),&(v228_2));
        drop(v228_2);
        let v228_10: Space = if has_head(&(v228_9)) { singleton(&[]) } else { Space::new() };
        drop(v228_9);
        let v228_13: Space = if (&(v228_10)).is_empty() { Space::new() } else {
          let v233_11: Path = concat_path(&v215_20_cursor.path()[v215_20_origin..(v215_20_origin + 2)],&(*p0));
          let v233_12: Space = singleton(&(v233_11));
          drop(v233_11);
          compose(&(v228_10),&(v233_12))
        };
        drop(v228_10);
        let v228_14: Space = unite(&(v228_8),&(v228_13));
        drop(v228_13);
        join_wrapped_into(&mut v227_10_write,&((v228_14).read_zipper()),&[]);
        }
        v215_20_cursor.ascend(1);
      }
      drop(v227_10_write);
      compose(&(v216_9),&(v227_10))
    };
    drop(v216_9);
    let v216_12: Space = unite(&(v216_7),&(v216_11));
    join_wrapped_into(&mut v215_20_write,&((v216_12).read_zipper()),&[]);
    }
    v215_20_cursor.ascend(1);
  }
  drop(v215_20_cursor);
  drop(v215_20_write);
  (v215_20).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let mut v234_14 = Space::new();
  let mut v234_14_write = v234_14.write_zipper();
  let mut v234_14_cursor = (*s0).read_zipper();
  let v234_14_origin = v234_14_cursor.path().len();
  for v234_14_byte in v234_14_cursor.child_mask().iter() {
    v234_14_cursor.descend_to_existing_byte(v234_14_byte);
    {
    let v235_2: Space = singleton(&v234_14_cursor.path()[v234_14_origin..(v234_14_origin + 1)]);
    let v235_3: Space = intersect(&(*CONSTANT_12),&(v235_2));
    let v235_4: Space = if has_head(&(v235_3)) { singleton(&[]) } else { Space::new() };
    drop(v235_3);
    let v235_5: Space = subtract(&(*CONSTANT_0),&(v235_4));
    drop(v235_4);
    let v235_8: Space = if (&(v235_5)).is_empty() { Space::new() } else {
      let v236_6: Path = concat_path(&(*p0),&v234_14_cursor.path()[v234_14_origin..(v234_14_origin + 1)]);
      let mut v236_7 = Space::new();
      let mut v236_7_write = v236_7.write_zipper();
      for v236_7_byte in v234_14_cursor.child_mask().iter() {
        v234_14_cursor.descend_to_existing_byte(v236_7_byte);
        {
        let v237_2: Space = singleton(&v234_14_cursor.path()[(v234_14_origin + 1)..(v234_14_origin + 2)]);
        let v237_3: Space = intersect(&(*CONSTANT_12),&(v237_2));
        let v237_4: Space = if has_head(&(v237_3)) { singleton(&[]) } else { Space::new() };
        drop(v237_3);
        let v237_5: Space = subtract(&(*CONSTANT_0),&(v237_4));
        drop(v237_4);
        let v237_8: Space = if (&(v237_5)).is_empty() { Space::new() } else {
          let v238_6: Path = concat_path(&(v236_6),&v234_14_cursor.path()[(v234_14_origin + 1)..(v234_14_origin + 2)]);
          let v238_7: Space = routine_35(c, &(v238_6), &v234_14_cursor, &(*s1), &(*s2), &(*s3));
          compose(&(v237_5),&(v238_7))
        };
        drop(v237_5);
        let v237_9: Space = intersect(&(*CONSTANT_12),&(v237_2));
        drop(v237_2);
        let v237_10: Space = if has_head(&(v237_9)) { singleton(&[]) } else { Space::new() };
        drop(v237_9);
        let v237_12: Space = if (&(v237_10)).is_empty() { Space::new() } else {
          let v239_6: Path = concat_path(&(v236_6),&v234_14_cursor.path()[(v234_14_origin + 1)..(v234_14_origin + 2)]);
          let v239_11: Space = routine_36(c, &(v239_6), &v234_14_cursor, &(*s1), &(*s2), &(*s3));
          drop(v239_6);
          compose(&(v237_10),&(v239_11))
        };
        drop(v237_10);
        let v237_13: Space = unite(&(v237_8),&(v237_12));
        join_wrapped_into(&mut v236_7_write,&((v237_13).read_zipper()),&[]);
        }
        v234_14_cursor.ascend(1);
      }
      drop(v236_7_write);
      compose(&(v235_5),&(v236_7))
    };
    drop(v235_5);
    let v235_9: Space = intersect(&(*CONSTANT_12),&(v235_2));
    drop(v235_2);
    let v235_10: Space = if has_head(&(v235_9)) { singleton(&[]) } else { Space::new() };
    drop(v235_9);
    let v235_12: Space = if (&(v235_10)).is_empty() { Space::new() } else {
      let v240_6: Path = concat_path(&(*p0),&v234_14_cursor.path()[v234_14_origin..(v234_14_origin + 1)]);
      let mut v240_11 = Space::new();
      let mut v240_11_write = v240_11.write_zipper();
      for v240_11_byte in v234_14_cursor.child_mask().iter() {
        v234_14_cursor.descend_to_existing_byte(v240_11_byte);
        {
        let v241_2: Space = singleton(&v234_14_cursor.path()[(v234_14_origin + 1)..(v234_14_origin + 2)]);
        let v241_3: Space = intersect(&(*CONSTANT_12),&(v241_2));
        let v241_4: Space = if has_head(&(v241_3)) { singleton(&[]) } else { Space::new() };
        drop(v241_3);
        let v241_5: Space = subtract(&(*CONSTANT_0),&(v241_4));
        drop(v241_4);
        let v241_8: Space = if (&(v241_5)).is_empty() { Space::new() } else {
          let v242_6: Path = concat_path(&(v240_6),&v234_14_cursor.path()[(v234_14_origin + 1)..(v234_14_origin + 2)]);
          let v242_7: Space = routine_35(c, &(v242_6), &v234_14_cursor, &(*s1), &(*s2), &(*s3));
          compose(&(v241_5),&(v242_7))
        };
        drop(v241_5);
        let v241_9: Space = intersect(&(*CONSTANT_12),&(v241_2));
        drop(v241_2);
        let v241_10: Space = if has_head(&(v241_9)) { singleton(&[]) } else { Space::new() };
        drop(v241_9);
        let v241_12: Space = if (&(v241_10)).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v240_6),&v234_14_cursor.path()[(v234_14_origin + 1)..(v234_14_origin + 2)]);
          let v243_11: Space = routine_37(c, &(v243_6), &v234_14_cursor, &(*s1), &(*s2), &(*s3));
          drop(v243_6);
          compose(&(v241_10),&(v243_11))
        };
        drop(v241_10);
        let v241_13: Space = unite(&(v241_8),&(v241_12));
        join_wrapped_into(&mut v240_11_write,&((v241_13).read_zipper()),&[]);
        }
        v234_14_cursor.ascend(1);
      }
      drop(v240_11_write);
      drop(v240_6);
      compose(&(v235_10),&(v240_11))
    };
    drop(v235_10);
    let v235_13: Space = unite(&(v235_8),&(v235_12));
    join_wrapped_into(&mut v234_14_write,&((v235_13).read_zipper()),&[]);
    }
    v234_14_cursor.ascend(1);
  }
  drop(v234_14_cursor);
  drop(v234_14_write);
  (v234_14).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let mut v244_11 = Space::new();
  let mut v244_11_write = v244_11.write_zipper();
  let mut v244_11_cursor = (*s0).read_zipper();
  let v244_11_origin = v244_11_cursor.path().len();
  for v244_11_byte in v244_11_cursor.child_mask().iter() {
    v244_11_cursor.descend_to_existing_byte(v244_11_byte);
    {
    let v245_2: Space = singleton(&v244_11_cursor.path()[v244_11_origin..(v244_11_origin + 1)]);
    let v245_3: Space = intersect(&(*CONSTANT_12),&(v245_2));
    let v245_4: Space = if has_head(&(v245_3)) { singleton(&[]) } else { Space::new() };
    drop(v245_3);
    let v245_5: Space = subtract(&(*CONSTANT_0),&(v245_4));
    drop(v245_4);
    let v245_8: Space = if (&(v245_5)).is_empty() { Space::new() } else {
      let v246_6: Path = concat_path(&(*p0),&v244_11_cursor.path()[v244_11_origin..(v244_11_origin + 1)]);
      let mut v246_7 = Space::new();
      let mut v246_7_write = v246_7.write_zipper();
      for v246_7_byte in v244_11_cursor.child_mask().iter() {
        v244_11_cursor.descend_to_existing_byte(v246_7_byte);
        {
        let v247_2: Space = singleton(&v244_11_cursor.path()[(v244_11_origin + 1)..(v244_11_origin + 2)]);
        let v247_3: Space = intersect(&(*CONSTANT_12),&(v247_2));
        let v247_4: Space = if has_head(&(v247_3)) { singleton(&[]) } else { Space::new() };
        drop(v247_3);
        let v247_5: Space = subtract(&(*CONSTANT_0),&(v247_4));
        drop(v247_4);
        let v247_8: Space = if (&(v247_5)).is_empty() { Space::new() } else {
          let v248_6: Path = concat_path(&(v246_6),&v244_11_cursor.path()[(v244_11_origin + 1)..(v244_11_origin + 2)]);
          let v248_7: Space = routine_35(c, &(v248_6), &v244_11_cursor, &(*s1), &(*s2), &(*s3));
          compose(&(v247_5),&(v248_7))
        };
        drop(v247_5);
        let v247_9: Space = intersect(&(*CONSTANT_12),&(v247_2));
        drop(v247_2);
        let v247_10: Space = if has_head(&(v247_9)) { singleton(&[]) } else { Space::new() };
        drop(v247_9);
        let v247_12: Space = if (&(v247_10)).is_empty() { Space::new() } else {
          let v249_6: Path = concat_path(&(v246_6),&v244_11_cursor.path()[(v244_11_origin + 1)..(v244_11_origin + 2)]);
          let v249_11: Space = routine_36(c, &(v249_6), &v244_11_cursor, &(*s1), &(*s2), &(*s3));
          drop(v249_6);
          compose(&(v247_10),&(v249_11))
        };
        drop(v247_10);
        let v247_13: Space = unite(&(v247_8),&(v247_12));
        join_wrapped_into(&mut v246_7_write,&((v247_13).read_zipper()),&[]);
        }
        v244_11_cursor.ascend(1);
      }
      drop(v246_7_write);
      compose(&(v245_5),&(v246_7))
    };
    drop(v245_5);
    let v245_9: Space = intersect(&(*CONSTANT_12),&(v245_2));
    drop(v245_2);
    let v245_10: Space = if has_head(&(v245_9)) { singleton(&[]) } else { Space::new() };
    drop(v245_9);
    let v245_27: Space = if (&(v245_10)).is_empty() { Space::new() } else {
      let v250_6: Path = concat_path(&(*p0),&v244_11_cursor.path()[v244_11_origin..(v244_11_origin + 1)]);
      let v250_11: Space = singleton(&(v250_6));
      let v250_12: Space = routine_38(c, &(*s1), &(*s3), &((v250_11).read_zipper()));
      let v250_13: Space = routine_38(c, &(*s2), &(*s3), &((v250_11).read_zipper()));
      let v250_14: Space = intersect(&(v250_12),&(v250_13));
      let v250_15: Space = subtract(&(v250_14),&(v250_11));
      drop(v250_11);
      let v250_16: Space = wrap(&(v250_15),&(v250_6));
      drop(v250_6);
      let v250_17: Space = subtract(&(*s3),&(v250_13));
      let v250_18: Space = subtract(&(v250_17),&(v250_12));
      let v250_19: Space = routine_39(c, &(*s2), &(*s1), &((v250_18).read_zipper()));
      let v250_20: Space = unite(&(v250_16),&(v250_19));
      let v250_21: Space = subtract(&(v250_12),&(v250_13));
      let v250_22: Space = routine_39(c, &(*s2), &(*s1), &((v250_21).read_zipper()));
      let v250_23: Space = unite(&(v250_20),&(v250_22));
      let v250_24: Space = subtract(&(v250_13),&(v250_12));
      let v250_25: Space = routine_39(c, &(*s2), &(*s1), &((v250_24).read_zipper()));
      let v250_26: Space = unite(&(v250_23),&(v250_25));
      compose(&(v245_10),&(v250_26))
    };
    drop(v245_10);
    let v245_28: Space = unite(&(v245_8),&(v245_27));
    join_wrapped_into(&mut v244_11_write,&((v245_28).read_zipper()),&[]);
    }
    v244_11_cursor.ascend(1);
  }
  drop(v244_11_cursor);
  drop(v244_11_write);
  (v244_11).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v251_3 = Space::new();
  let mut v251_3_write = v251_3.write_zipper();
  let mut v251_3_cursor = (*s0).read_zipper();
  let v251_3_origin = v251_3_cursor.path().len();
  for v251_3_byte in v251_3_cursor.child_mask().iter() {
    v251_3_cursor.descend_to_existing_byte(v251_3_byte);
    {
    let v252_2: Space = Space::new();
    join_wrapped_into(&mut v251_3_write,&((v252_2).read_zipper()),&[]);
    }
    v251_3_cursor.ascend(1);
  }
  drop(v251_3_cursor);
  drop(v251_3_write);
  (v251_3).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v253_4 = Space::new();
  let mut v253_4_write = v253_4.write_zipper();
  let mut v253_4_cursor = (*s0).read_zipper();
  let v253_4_origin = v253_4_cursor.path().len();
  for v253_4_byte in v253_4_cursor.child_mask().iter() {
    v253_4_cursor.descend_to_existing_byte(v253_4_byte);
    {
    let v254_2: Space = singleton(&v253_4_cursor.path()[v253_4_origin..(v253_4_origin + 1)]);
    let v254_3: Space = intersect(&(*CONSTANT_12),&(v254_2));
    drop(v254_2);
    let v254_4: Space = if has_head(&(v254_3)) { singleton(&[]) } else { Space::new() };
    drop(v254_3);
    let v254_8: Space = if (&(v254_4)).is_empty() { Space::new() } else {
      let v255_5: Path = concat_path(&(*p0),&v253_4_cursor.path()[v253_4_origin..(v253_4_origin + 1)]);
      let v255_6: Path = concat_path(&(v255_5),&(*p1));
      drop(v255_5);
      let v255_7: Space = singleton(&(v255_6));
      drop(v255_6);
      compose(&(v254_4),&(v255_7))
    };
    drop(v254_4);
    join_wrapped_into(&mut v253_4_write,&((v254_8).read_zipper()),&[]);
    }
    v253_4_cursor.ascend(1);
  }
  drop(v253_4_cursor);
  drop(v253_4_write);
  (v253_4).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v256_3: Path = concat_path(&(*p0),&(*p1));
  let v256_4: Space = singleton(&(v256_3));
  drop(v256_3);
  (v256_4).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v257_15 = Space::new();
  let mut v257_15_write = v257_15.write_zipper();
  let mut v257_15_cursor = (*s0).read_zipper();
  let v257_15_origin = v257_15_cursor.path().len();
  for v257_15_byte in v257_15_cursor.child_mask().iter() {
    v257_15_cursor.descend_to_existing_byte(v257_15_byte);
    {
    let v258_2: Space = singleton(&v257_15_cursor.path()[v257_15_origin..(v257_15_origin + 1)]);
    let v258_3: Space = intersect(&(*CONSTANT_12),&(v258_2));
    let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
    drop(v258_3);
    let v258_5: Space = subtract(&(*CONSTANT_0),&(v258_4));
    drop(v258_4);
    let v258_8: Space = if (&(v258_5)).is_empty() { Space::new() } else {
      let v259_6: Path = concat_path(&(*p0),&v257_15_cursor.path()[v257_15_origin..(v257_15_origin + 1)]);
      let mut v259_7 = Space::new();
      let mut v259_7_write = v259_7.write_zipper();
      for v259_7_byte in v257_15_cursor.child_mask().iter() {
        v257_15_cursor.descend_to_existing_byte(v259_7_byte);
        {
        let v260_2: Space = singleton(&v257_15_cursor.path()[(v257_15_origin + 1)..(v257_15_origin + 2)]);
        let v260_3: Space = intersect(&(*CONSTANT_12),&(v260_2));
        let v260_4: Space = if has_head(&(v260_3)) { singleton(&[]) } else { Space::new() };
        drop(v260_3);
        let v260_5: Space = subtract(&(*CONSTANT_0),&(v260_4));
        drop(v260_4);
        let v260_8: Space = if (&(v260_5)).is_empty() { Space::new() } else {
          let v261_6: Path = concat_path(&(v259_6),&v257_15_cursor.path()[(v257_15_origin + 1)..(v257_15_origin + 2)]);
          let mut v261_7 = Space::new();
          let mut v261_7_write = v261_7.write_zipper();
          for v261_7_byte in v257_15_cursor.child_mask().iter() {
            v257_15_cursor.descend_to_existing_byte(v261_7_byte);
            {
            let v262_2: Space = singleton(&v257_15_cursor.path()[(v257_15_origin + 2)..(v257_15_origin + 3)]);
            let v262_3: Space = intersect(&(*CONSTANT_12),&(v262_2));
            let v262_4: Space = if has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
            drop(v262_3);
            let v262_5: Space = subtract(&(*CONSTANT_0),&(v262_4));
            drop(v262_4);
            let v262_8: Space = if (&(v262_5)).is_empty() { Space::new() } else {
              let v263_6: Path = concat_path(&(v261_6),&v257_15_cursor.path()[(v257_15_origin + 2)..(v257_15_origin + 3)]);
              let v263_7: Space = routine_18(c, &(v263_6), &(*p1), &v257_15_cursor);
              compose(&(v262_5),&(v263_7))
            };
            drop(v262_5);
            let v262_9: Space = intersect(&(*CONSTANT_12),&(v262_2));
            drop(v262_2);
            let v262_10: Space = if has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
            drop(v262_9);
            let v262_12: Space = if (&(v262_10)).is_empty() { Space::new() } else {
              let v264_6: Path = concat_path(&(v261_6),&v257_15_cursor.path()[(v257_15_origin + 2)..(v257_15_origin + 3)]);
              let v264_11: Space = routine_19(c, &(v264_6), &(*p1), &v257_15_cursor);
              drop(v264_6);
              compose(&(v262_10),&(v264_11))
            };
            drop(v262_10);
            let v262_13: Space = unite(&(v262_8),&(v262_12));
            join_wrapped_into(&mut v261_7_write,&((v262_13).read_zipper()),&[]);
            }
            v257_15_cursor.ascend(1);
          }
          drop(v261_7_write);
          compose(&(v260_5),&(v261_7))
        };
        drop(v260_5);
        let v260_9: Space = intersect(&(*CONSTANT_12),&(v260_2));
        drop(v260_2);
        let v260_10: Space = if has_head(&(v260_9)) { singleton(&[]) } else { Space::new() };
        drop(v260_9);
        let v260_12: Space = if (&(v260_10)).is_empty() { Space::new() } else {
          let v265_6: Path = concat_path(&(v259_6),&v257_15_cursor.path()[(v257_15_origin + 1)..(v257_15_origin + 2)]);
          let mut v265_11 = Space::new();
          let mut v265_11_write = v265_11.write_zipper();
          for v265_11_byte in v257_15_cursor.child_mask().iter() {
            v257_15_cursor.descend_to_existing_byte(v265_11_byte);
            {
            let v266_2: Space = singleton(&v257_15_cursor.path()[(v257_15_origin + 2)..(v257_15_origin + 3)]);
            let v266_3: Space = intersect(&(*CONSTANT_12),&(v266_2));
            let v266_4: Space = if has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
            drop(v266_3);
            let v266_5: Space = subtract(&(*CONSTANT_0),&(v266_4));
            drop(v266_4);
            let v266_8: Space = if (&(v266_5)).is_empty() { Space::new() } else {
              let v267_6: Path = concat_path(&(v265_6),&v257_15_cursor.path()[(v257_15_origin + 2)..(v257_15_origin + 3)]);
              let v267_7: Space = routine_18(c, &(v267_6), &(*p1), &v257_15_cursor);
              compose(&(v266_5),&(v267_7))
            };
            drop(v266_5);
            let v266_9: Space = intersect(&(*CONSTANT_12),&(v266_2));
            drop(v266_2);
            let v266_10: Space = if has_head(&(v266_9)) { singleton(&[]) } else { Space::new() };
            drop(v266_9);
            let v266_12: Space = if (&(v266_10)).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v265_6),&v257_15_cursor.path()[(v257_15_origin + 2)..(v257_15_origin + 3)]);
              let v268_11: Space = routine_20(c, &(v268_6), &(*p1), &v257_15_cursor);
              drop(v268_6);
              compose(&(v266_10),&(v268_11))
            };
            drop(v266_10);
            let v266_13: Space = unite(&(v266_8),&(v266_12));
            join_wrapped_into(&mut v265_11_write,&((v266_13).read_zipper()),&[]);
            }
            v257_15_cursor.ascend(1);
          }
          drop(v265_11_write);
          drop(v265_6);
          compose(&(v260_10),&(v265_11))
        };
        drop(v260_10);
        let v260_13: Space = unite(&(v260_8),&(v260_12));
        join_wrapped_into(&mut v259_7_write,&((v260_13).read_zipper()),&[]);
        }
        v257_15_cursor.ascend(1);
      }
      drop(v259_7_write);
      compose(&(v258_5),&(v259_7))
    };
    drop(v258_5);
    let v258_9: Space = intersect(&(*CONSTANT_12),&(v258_2));
    drop(v258_2);
    let v258_10: Space = if has_head(&(v258_9)) { singleton(&[]) } else { Space::new() };
    drop(v258_9);
    let v258_13: Space = if (&(v258_10)).is_empty() { Space::new() } else {
      let v269_6: Path = concat_path(&(*p0),&v257_15_cursor.path()[v257_15_origin..(v257_15_origin + 1)]);
      let v269_11: Path = concat_path(&(v269_6),&(*p1));
      drop(v269_6);
      let v269_12: Space = singleton(&(v269_11));
      drop(v269_11);
      compose(&(v258_10),&(v269_12))
    };
    drop(v258_10);
    let v258_14: Space = unite(&(v258_8),&(v258_13));
    drop(v258_13);
    join_wrapped_into(&mut v257_15_write,&((v258_14).read_zipper()),&[]);
    }
    v257_15_cursor.ascend(1);
  }
  drop(v257_15_cursor);
  drop(v257_15_write);
  (v257_15).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v270_13 = Space::new();
  let mut v270_13_write = v270_13.write_zipper();
  let mut v270_13_cursor = (*s0).read_zipper();
  let v270_13_origin = v270_13_cursor.path().len();
  for v270_13_byte in v270_13_cursor.child_mask().iter() {
    v270_13_cursor.descend_to_existing_byte(v270_13_byte);
    {
    let v271_2: Space = singleton(&v270_13_cursor.path()[v270_13_origin..(v270_13_origin + 1)]);
    let v271_3: Space = intersect(&(*CONSTANT_12),&(v271_2));
    let v271_4: Space = if has_head(&(v271_3)) { singleton(&[]) } else { Space::new() };
    drop(v271_3);
    let v271_5: Space = subtract(&(*CONSTANT_0),&(v271_4));
    drop(v271_4);
    let v271_8: Space = if (&(v271_5)).is_empty() { Space::new() } else {
      let v272_6: Path = concat_path(&(*p0),&v270_13_cursor.path()[v270_13_origin..(v270_13_origin + 1)]);
      let mut v272_7 = Space::new();
      let mut v272_7_write = v272_7.write_zipper();
      for v272_7_byte in v270_13_cursor.child_mask().iter() {
        v270_13_cursor.descend_to_existing_byte(v272_7_byte);
        {
        let v273_2: Space = singleton(&v270_13_cursor.path()[(v270_13_origin + 1)..(v270_13_origin + 2)]);
        let v273_3: Space = intersect(&(*CONSTANT_12),&(v273_2));
        let v273_4: Space = if has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
        drop(v273_3);
        let v273_5: Space = subtract(&(*CONSTANT_0),&(v273_4));
        drop(v273_4);
        let v273_7: Space = if (&(v273_5)).is_empty() { Space::new() } else {
          let mut v274_6 = Space::new();
          let mut v274_6_write = v274_6.write_zipper();
          for v274_6_byte in v270_13_cursor.child_mask().iter() {
            v270_13_cursor.descend_to_existing_byte(v274_6_byte);
            {
            let v275_2: Space = Space::new();
            join_wrapped_into(&mut v274_6_write,&((v275_2).read_zipper()),&[]);
            }
            v270_13_cursor.ascend(1);
          }
          drop(v274_6_write);
          compose(&(v273_5),&(v274_6))
        };
        drop(v273_5);
        let v273_8: Space = intersect(&(*CONSTANT_12),&(v273_2));
        drop(v273_2);
        let v273_9: Space = if has_head(&(v273_8)) { singleton(&[]) } else { Space::new() };
        drop(v273_8);
        let v273_12: Space = if (&(v273_9)).is_empty() { Space::new() } else {
          let v276_10: Path = concat_path(&(v272_6),&v270_13_cursor.path()[(v270_13_origin + 1)..(v270_13_origin + 2)]);
          let mut v276_11 = Space::new();
          let mut v276_11_write = v276_11.write_zipper();
          for v276_11_byte in v270_13_cursor.child_mask().iter() {
            v270_13_cursor.descend_to_existing_byte(v276_11_byte);
            {
            let v277_2: Space = singleton(&v270_13_cursor.path()[(v270_13_origin + 2)..(v270_13_origin + 3)]);
            let v277_3: Space = intersect(&(*CONSTANT_12),&(v277_2));
            drop(v277_2);
            let v277_4: Space = if has_head(&(v277_3)) { singleton(&[]) } else { Space::new() };
            drop(v277_3);
            let v277_7: Space = if (&(v277_4)).is_empty() { Space::new() } else {
              let v278_5: Path = concat_path(&(v276_10),&v270_13_cursor.path()[(v270_13_origin + 2)..(v270_13_origin + 3)]);
              let v278_6: Space = routine_20(c, &(v278_5), &(*p1), &v270_13_cursor);
              drop(v278_5);
              compose(&(v277_4),&(v278_6))
            };
            drop(v277_4);
            join_wrapped_into(&mut v276_11_write,&((v277_7).read_zipper()),&[]);
            }
            v270_13_cursor.ascend(1);
          }
          drop(v276_11_write);
          drop(v276_10);
          compose(&(v273_9),&(v276_11))
        };
        drop(v273_9);
        let v273_13: Space = unite(&(v273_7),&(v273_12));
        drop(v273_7);
        join_wrapped_into(&mut v272_7_write,&((v273_13).read_zipper()),&[]);
        }
        v270_13_cursor.ascend(1);
      }
      drop(v272_7_write);
      compose(&(v271_5),&(v272_7))
    };
    drop(v271_5);
    let v271_9: Space = intersect(&(*CONSTANT_12),&(v271_2));
    drop(v271_2);
    let v271_10: Space = if has_head(&(v271_9)) { singleton(&[]) } else { Space::new() };
    drop(v271_9);
    let v271_12: Space = if (&(v271_10)).is_empty() { Space::new() } else {
      let v279_6: Path = concat_path(&(*p0),&v270_13_cursor.path()[v270_13_origin..(v270_13_origin + 1)]);
      let mut v279_11 = Space::new();
      let mut v279_11_write = v279_11.write_zipper();
      for v279_11_byte in v270_13_cursor.child_mask().iter() {
        v270_13_cursor.descend_to_existing_byte(v279_11_byte);
        {
        let v280_2: Space = singleton(&v270_13_cursor.path()[(v270_13_origin + 1)..(v270_13_origin + 2)]);
        let v280_3: Space = intersect(&(*CONSTANT_12),&(v280_2));
        let v280_4: Space = if has_head(&(v280_3)) { singleton(&[]) } else { Space::new() };
        drop(v280_3);
        let v280_5: Space = subtract(&(*CONSTANT_0),&(v280_4));
        drop(v280_4);
        let v280_7: Space = if (&(v280_5)).is_empty() { Space::new() } else {
          let mut v281_6 = Space::new();
          let mut v281_6_write = v281_6.write_zipper();
          for v281_6_byte in v270_13_cursor.child_mask().iter() {
            v270_13_cursor.descend_to_existing_byte(v281_6_byte);
            {
            let v282_2: Space = Space::new();
            join_wrapped_into(&mut v281_6_write,&((v282_2).read_zipper()),&[]);
            }
            v270_13_cursor.ascend(1);
          }
          drop(v281_6_write);
          compose(&(v280_5),&(v281_6))
        };
        drop(v280_5);
        let v280_8: Space = intersect(&(*CONSTANT_12),&(v280_2));
        drop(v280_2);
        let v280_9: Space = if has_head(&(v280_8)) { singleton(&[]) } else { Space::new() };
        drop(v280_8);
        let v280_13: Space = if (&(v280_9)).is_empty() { Space::new() } else {
          let v283_10: Path = concat_path(&(v279_6),&v270_13_cursor.path()[(v270_13_origin + 1)..(v270_13_origin + 2)]);
          let v283_11: Path = concat_path(&(v283_10),&(*p1));
          drop(v283_10);
          let v283_12: Space = singleton(&(v283_11));
          drop(v283_11);
          compose(&(v280_9),&(v283_12))
        };
        drop(v280_9);
        let v280_14: Space = unite(&(v280_7),&(v280_13));
        drop(v280_7);
        drop(v280_13);
        join_wrapped_into(&mut v279_11_write,&((v280_14).read_zipper()),&[]);
        }
        v270_13_cursor.ascend(1);
      }
      drop(v279_11_write);
      drop(v279_6);
      compose(&(v271_10),&(v279_11))
    };
    drop(v271_10);
    let v271_13: Space = unite(&(v271_8),&(v271_12));
    drop(v271_12);
    join_wrapped_into(&mut v270_13_write,&((v271_13).read_zipper()),&[]);
    }
    v270_13_cursor.ascend(1);
  }
  drop(v270_13_cursor);
  drop(v270_13_write);
  (v270_13).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v284_10 = Space::new();
  let mut v284_10_write = v284_10.write_zipper();
  let mut v284_10_cursor = (*s0).read_zipper();
  let v284_10_origin = v284_10_cursor.path().len();
  for v284_10_byte in v284_10_cursor.child_mask().iter() {
    v284_10_cursor.descend_to_existing_byte(v284_10_byte);
    {
    let v285_2: Space = singleton(&v284_10_cursor.path()[v284_10_origin..(v284_10_origin + 1)]);
    let v285_3: Space = intersect(&(*CONSTANT_12),&(v285_2));
    let v285_4: Space = if has_head(&(v285_3)) { singleton(&[]) } else { Space::new() };
    drop(v285_3);
    let v285_5: Space = subtract(&(*CONSTANT_0),&(v285_4));
    drop(v285_4);
    let v285_8: Space = if (&(v285_5)).is_empty() { Space::new() } else {
      let v286_6: Path = concat_path(&(*p0),&v284_10_cursor.path()[v284_10_origin..(v284_10_origin + 1)]);
      let mut v286_7 = Space::new();
      let mut v286_7_write = v286_7.write_zipper();
      for v286_7_byte in v284_10_cursor.child_mask().iter() {
        v284_10_cursor.descend_to_existing_byte(v286_7_byte);
        {
        let v287_2: Space = singleton(&v284_10_cursor.path()[(v284_10_origin + 1)..(v284_10_origin + 2)]);
        let v287_3: Space = intersect(&(*CONSTANT_12),&(v287_2));
        let v287_4: Space = if has_head(&(v287_3)) { singleton(&[]) } else { Space::new() };
        drop(v287_3);
        let v287_5: Space = subtract(&(*CONSTANT_0),&(v287_4));
        drop(v287_4);
        let v287_7: Space = if (&(v287_5)).is_empty() { Space::new() } else {
          let mut v288_6 = Space::new();
          let mut v288_6_write = v288_6.write_zipper();
          for v288_6_byte in v284_10_cursor.child_mask().iter() {
            v284_10_cursor.descend_to_existing_byte(v288_6_byte);
            {
            let v289_2: Space = Space::new();
            join_wrapped_into(&mut v288_6_write,&((v289_2).read_zipper()),&[]);
            }
            v284_10_cursor.ascend(1);
          }
          drop(v288_6_write);
          compose(&(v287_5),&(v288_6))
        };
        drop(v287_5);
        let v287_8: Space = intersect(&(*CONSTANT_12),&(v287_2));
        drop(v287_2);
        let v287_9: Space = if has_head(&(v287_8)) { singleton(&[]) } else { Space::new() };
        drop(v287_8);
        let v287_12: Space = if (&(v287_9)).is_empty() { Space::new() } else {
          let v290_10: Path = concat_path(&(v286_6),&v284_10_cursor.path()[(v284_10_origin + 1)..(v284_10_origin + 2)]);
          let mut v290_11 = Space::new();
          let mut v290_11_write = v290_11.write_zipper();
          for v290_11_byte in v284_10_cursor.child_mask().iter() {
            v284_10_cursor.descend_to_existing_byte(v290_11_byte);
            {
            let v291_2: Space = singleton(&v284_10_cursor.path()[(v284_10_origin + 2)..(v284_10_origin + 3)]);
            let v291_3: Space = intersect(&(*CONSTANT_12),&(v291_2));
            drop(v291_2);
            let v291_4: Space = if has_head(&(v291_3)) { singleton(&[]) } else { Space::new() };
            drop(v291_3);
            let v291_7: Space = if (&(v291_4)).is_empty() { Space::new() } else {
              let v292_5: Path = concat_path(&(v290_10),&v284_10_cursor.path()[(v284_10_origin + 2)..(v284_10_origin + 3)]);
              let v292_6: Space = routine_20(c, &(v292_5), &(*p1), &v284_10_cursor);
              drop(v292_5);
              compose(&(v291_4),&(v292_6))
            };
            drop(v291_4);
            join_wrapped_into(&mut v290_11_write,&((v291_7).read_zipper()),&[]);
            }
            v284_10_cursor.ascend(1);
          }
          drop(v290_11_write);
          drop(v290_10);
          compose(&(v287_9),&(v290_11))
        };
        drop(v287_9);
        let v287_13: Space = unite(&(v287_7),&(v287_12));
        drop(v287_7);
        join_wrapped_into(&mut v286_7_write,&((v287_13).read_zipper()),&[]);
        }
        v284_10_cursor.ascend(1);
      }
      drop(v286_7_write);
      compose(&(v285_5),&(v286_7))
    };
    drop(v285_5);
    let v285_9: Space = intersect(&(*CONSTANT_12),&(v285_2));
    drop(v285_2);
    let v285_10: Space = if has_head(&(v285_9)) { singleton(&[]) } else { Space::new() };
    drop(v285_9);
    let v285_13: Space = if (&(v285_10)).is_empty() { Space::new() } else {
      let v293_6: Path = concat_path(&(*p0),&v284_10_cursor.path()[v284_10_origin..(v284_10_origin + 1)]);
      let v293_11: Path = concat_path(&(v293_6),&(*p1));
      drop(v293_6);
      let v293_12: Space = singleton(&(v293_11));
      drop(v293_11);
      compose(&(v285_10),&(v293_12))
    };
    drop(v285_10);
    let v285_14: Space = unite(&(v285_8),&(v285_13));
    drop(v285_13);
    join_wrapped_into(&mut v284_10_write,&((v285_14).read_zipper()),&[]);
    }
    v284_10_cursor.ascend(1);
  }
  drop(v284_10_cursor);
  drop(v284_10_write);
  (v284_10).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v294_7 = Space::new();
  let mut v294_7_write = v294_7.write_zipper();
  let mut v294_7_cursor = (*s0).read_zipper();
  let v294_7_origin = v294_7_cursor.path().len();
  for v294_7_byte in v294_7_cursor.child_mask().iter() {
    v294_7_cursor.descend_to_existing_byte(v294_7_byte);
    {
    let v295_2: Space = singleton(&v294_7_cursor.path()[v294_7_origin..(v294_7_origin + 1)]);
    let v295_3: Space = intersect(&(*CONSTANT_12),&(v295_2));
    let v295_4: Space = if has_head(&(v295_3)) { singleton(&[]) } else { Space::new() };
    drop(v295_3);
    let v295_5: Space = subtract(&(*CONSTANT_0),&(v295_4));
    drop(v295_4);
    let v295_7: Space = if (&(v295_5)).is_empty() { Space::new() } else {
      let mut v296_6 = Space::new();
      let mut v296_6_write = v296_6.write_zipper();
      for v296_6_byte in v294_7_cursor.child_mask().iter() {
        v294_7_cursor.descend_to_existing_byte(v296_6_byte);
        {
        let v297_2: Space = Space::new();
        join_wrapped_into(&mut v296_6_write,&((v297_2).read_zipper()),&[]);
        }
        v294_7_cursor.ascend(1);
      }
      drop(v296_6_write);
      compose(&(v295_5),&(v296_6))
    };
    drop(v295_5);
    let v295_8: Space = intersect(&(*CONSTANT_12),&(v295_2));
    drop(v295_2);
    let v295_9: Space = if has_head(&(v295_8)) { singleton(&[]) } else { Space::new() };
    drop(v295_8);
    let v295_12: Space = if (&(v295_9)).is_empty() { Space::new() } else {
      let v298_10: Path = concat_path(&(*p0),&v294_7_cursor.path()[v294_7_origin..(v294_7_origin + 1)]);
      let mut v298_11 = Space::new();
      let mut v298_11_write = v298_11.write_zipper();
      for v298_11_byte in v294_7_cursor.child_mask().iter() {
        v294_7_cursor.descend_to_existing_byte(v298_11_byte);
        {
        let v299_2: Space = singleton(&v294_7_cursor.path()[(v294_7_origin + 1)..(v294_7_origin + 2)]);
        let v299_3: Space = intersect(&(*CONSTANT_12),&(v299_2));
        drop(v299_2);
        let v299_4: Space = if has_head(&(v299_3)) { singleton(&[]) } else { Space::new() };
        drop(v299_3);
        let v299_8: Space = if (&(v299_4)).is_empty() { Space::new() } else {
          let v300_5: Path = concat_path(&(v298_10),&v294_7_cursor.path()[(v294_7_origin + 1)..(v294_7_origin + 2)]);
          let v300_6: Path = concat_path(&(v300_5),&(*p1));
          drop(v300_5);
          let v300_7: Space = singleton(&(v300_6));
          drop(v300_6);
          compose(&(v299_4),&(v300_7))
        };
        drop(v299_4);
        join_wrapped_into(&mut v298_11_write,&((v299_8).read_zipper()),&[]);
        }
        v294_7_cursor.ascend(1);
      }
      drop(v298_11_write);
      drop(v298_10);
      compose(&(v295_9),&(v298_11))
    };
    drop(v295_9);
    let v295_13: Space = unite(&(v295_7),&(v295_12));
    drop(v295_7);
    drop(v295_12);
    join_wrapped_into(&mut v294_7_write,&((v295_13).read_zipper()),&[]);
    }
    v294_7_cursor.ascend(1);
  }
  drop(v294_7_cursor);
  drop(v294_7_write);
  (v294_7).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v301_6 = Space::new();
  let mut v301_6_write = v301_6.write_zipper();
  let mut v301_6_cursor = (*s0).read_zipper();
  let v301_6_origin = v301_6_cursor.path().len();
  for v301_6_byte in v301_6_cursor.child_mask().iter() {
    v301_6_cursor.descend_to_existing_byte(v301_6_byte);
    {
    let v302_2: Space = singleton(&v301_6_cursor.path()[v301_6_origin..(v301_6_origin + 1)]);
    let v302_3: Space = intersect(&(*CONSTANT_12),&(v302_2));
    let v302_4: Space = if has_head(&(v302_3)) { singleton(&[]) } else { Space::new() };
    drop(v302_3);
    let v302_5: Space = subtract(&(*CONSTANT_0),&(v302_4));
    drop(v302_4);
    let v302_7: Space = if (&(v302_5)).is_empty() { Space::new() } else {
      let mut v303_6 = Space::new();
      let mut v303_6_write = v303_6.write_zipper();
      for v303_6_byte in v301_6_cursor.child_mask().iter() {
        v301_6_cursor.descend_to_existing_byte(v303_6_byte);
        {
        let v304_2: Space = Space::new();
        join_wrapped_into(&mut v303_6_write,&((v304_2).read_zipper()),&[]);
        }
        v301_6_cursor.ascend(1);
      }
      drop(v303_6_write);
      compose(&(v302_5),&(v303_6))
    };
    drop(v302_5);
    let v302_8: Space = intersect(&(*CONSTANT_12),&(v302_2));
    drop(v302_2);
    let v302_9: Space = if has_head(&(v302_8)) { singleton(&[]) } else { Space::new() };
    drop(v302_8);
    let v302_13: Space = if (&(v302_9)).is_empty() { Space::new() } else {
      let v305_10: Path = concat_path(&(*p0),&v301_6_cursor.path()[v301_6_origin..(v301_6_origin + 1)]);
      let v305_11: Path = concat_path(&(v305_10),&(*p1));
      drop(v305_10);
      let v305_12: Space = singleton(&(v305_11));
      drop(v305_11);
      compose(&(v302_9),&(v305_12))
    };
    drop(v302_9);
    let v302_14: Space = unite(&(v302_7),&(v302_13));
    drop(v302_7);
    drop(v302_13);
    join_wrapped_into(&mut v301_6_write,&((v302_14).read_zipper()),&[]);
    }
    v301_6_cursor.ascend(1);
  }
  drop(v301_6_cursor);
  drop(v301_6_write);
  (v301_6).clone()
}

fn routine_26(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v306_2: Space = first_matching(&(*s0),&(*CONSTANT_0),false);
  let v306_3: Space = intersect(&(*CONSTANT_0),&(v306_2));
  let v306_4: Space = if has_head(&(v306_2)) { singleton(&[]) } else { Space::new() };
  let v306_5: Space = unite(&(v306_3),&(v306_4));
  drop(v306_3);
  let v306_7: Space = compose(&(v306_5),&(*CONSTANT_0));
  drop(v306_5);
  let v306_9: Space = subtract(&(*CONSTANT_0),&(v306_2));
  drop(v306_2);
  let v306_10: Space = subtract(&(v306_9),&(v306_4));
  drop(v306_4);
  drop(v306_9);
  let v306_18: Space = if (&(v306_10)).is_empty() { Space::new() } else {
    let v307_11: Space = first_fibonacci(&(*s0),6,5,true);
    let v307_12: Space = first_matching(&(v307_11),&(*CONSTANT_0),false);
    let v307_15: Space = if (&(v307_12)).is_empty() { Space::new() } else {
      let v308_14: Space = routine_40(c, &(*CONSTANT_14), &(*s0));
      compose(&(v307_12),&(v308_14))
    };
    drop(v307_12);
    let mut v307_16 = Space::new();
    let mut v307_16_write = v307_16.write_zipper();
    let mut v307_16_cursor = (v307_11).read_zipper();
    let v307_16_origin = v307_16_cursor.path().len();
    for v307_16_byte in v307_16_cursor.child_mask().iter() {
      v307_16_cursor.descend_to_existing_byte(v307_16_byte);
      {
      let v309_2_arg_0: &[u8] = &v307_16_cursor.path()[v307_16_origin..(v307_16_origin + 1)];
      let v309_2_arg_2: &Space = &(&(*s0)).make_map();
      let mut v309_2_more = v307_16_cursor.is_val() || next_value_within(&mut v307_16_cursor,(v307_16_origin + 1));
      while v309_2_more {
        {
        let v309_2_depth = v307_16_cursor.path().len();
        let v310_4: Space = routine_26(c, &(descend_cursor((*v309_2_arg_2).read_zipper(),&v307_16_cursor.path()[v307_16_origin..v309_2_depth])));
        join_wrapped_into(&mut v307_16_write,&((v310_4).read_zipper()),&v307_16_cursor.path()[v307_16_origin..v309_2_depth]);
        }
        v309_2_more = next_value_within(&mut v307_16_cursor,(v307_16_origin + 1));
      }
      }
      v307_16_cursor.ascend(1);
    }
    drop(v307_16_cursor);
    drop(v307_16_write);
    drop(v307_11);
    let v307_17: Space = unite(&(v307_15),&(v307_16));
    compose(&(v306_10),&(v307_17))
  };
  drop(v306_10);
  let v306_19: Space = unite(&(v306_7),&(v306_18));
  drop(v306_7);
  (v306_19).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v311_3 = Space::new();
  let mut v311_3_write = v311_3.write_zipper();
  let mut v311_3_cursor = (*s0).read_zipper();
  let v311_3_origin = v311_3_cursor.path().len();
  for v311_3_byte in v311_3_cursor.child_mask().iter() {
    v311_3_cursor.descend_to_existing_byte(v311_3_byte);
    {
    let v312_2: Space = Space::new();
    join_wrapped_into(&mut v311_3_write,&((v312_2).read_zipper()),&[]);
    }
    v311_3_cursor.ascend(1);
  }
  drop(v311_3_cursor);
  drop(v311_3_write);
  (v311_3).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v313_4 = Space::new();
  let mut v313_4_write = v313_4.write_zipper();
  let mut v313_4_cursor = (*s0).read_zipper();
  let v313_4_origin = v313_4_cursor.path().len();
  for v313_4_byte in v313_4_cursor.child_mask().iter() {
    v313_4_cursor.descend_to_existing_byte(v313_4_byte);
    {
    let v314_2: Space = singleton(&v313_4_cursor.path()[v313_4_origin..(v313_4_origin + 1)]);
    let v314_3: Space = intersect(&(*CONSTANT_12),&(v314_2));
    drop(v314_2);
    let v314_4: Space = if has_head(&(v314_3)) { singleton(&[]) } else { Space::new() };
    drop(v314_3);
    let v314_8: Space = if (&(v314_4)).is_empty() { Space::new() } else {
      let v315_5: Path = concat_path(&(*p0),&v313_4_cursor.path()[v313_4_origin..(v313_4_origin + 1)]);
      let v315_6: Path = concat_path(&(v315_5),&(*p1));
      drop(v315_5);
      let v315_7: Space = singleton(&(v315_6));
      drop(v315_6);
      compose(&(v314_4),&(v315_7))
    };
    drop(v314_4);
    join_wrapped_into(&mut v313_4_write,&((v314_8).read_zipper()),&[]);
    }
    v313_4_cursor.ascend(1);
  }
  drop(v313_4_cursor);
  drop(v313_4_write);
  (v313_4).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v316_3: Path = concat_path(&(*p0),&(*p1));
  let v316_4: Space = singleton(&(v316_3));
  drop(v316_3);
  (v316_4).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v317_15 = Space::new();
  let mut v317_15_write = v317_15.write_zipper();
  let mut v317_15_cursor = (*s0).read_zipper();
  let v317_15_origin = v317_15_cursor.path().len();
  for v317_15_byte in v317_15_cursor.child_mask().iter() {
    v317_15_cursor.descend_to_existing_byte(v317_15_byte);
    {
    let v318_2: Space = singleton(&v317_15_cursor.path()[v317_15_origin..(v317_15_origin + 1)]);
    let v318_3: Space = intersect(&(*CONSTANT_12),&(v318_2));
    let v318_4: Space = if has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
    drop(v318_3);
    let v318_5: Space = subtract(&(*CONSTANT_0),&(v318_4));
    drop(v318_4);
    let v318_8: Space = if (&(v318_5)).is_empty() { Space::new() } else {
      let v319_6: Path = concat_path(&(*p0),&v317_15_cursor.path()[v317_15_origin..(v317_15_origin + 1)]);
      let mut v319_7 = Space::new();
      let mut v319_7_write = v319_7.write_zipper();
      for v319_7_byte in v317_15_cursor.child_mask().iter() {
        v317_15_cursor.descend_to_existing_byte(v319_7_byte);
        {
        let v320_2: Space = singleton(&v317_15_cursor.path()[(v317_15_origin + 1)..(v317_15_origin + 2)]);
        let v320_3: Space = intersect(&(*CONSTANT_12),&(v320_2));
        let v320_4: Space = if has_head(&(v320_3)) { singleton(&[]) } else { Space::new() };
        drop(v320_3);
        let v320_5: Space = subtract(&(*CONSTANT_0),&(v320_4));
        drop(v320_4);
        let v320_8: Space = if (&(v320_5)).is_empty() { Space::new() } else {
          let v321_6: Path = concat_path(&(v319_6),&v317_15_cursor.path()[(v317_15_origin + 1)..(v317_15_origin + 2)]);
          let mut v321_7 = Space::new();
          let mut v321_7_write = v321_7.write_zipper();
          for v321_7_byte in v317_15_cursor.child_mask().iter() {
            v317_15_cursor.descend_to_existing_byte(v321_7_byte);
            {
            let v322_2: Space = singleton(&v317_15_cursor.path()[(v317_15_origin + 2)..(v317_15_origin + 3)]);
            let v322_3: Space = intersect(&(*CONSTANT_12),&(v322_2));
            let v322_4: Space = if has_head(&(v322_3)) { singleton(&[]) } else { Space::new() };
            drop(v322_3);
            let v322_5: Space = subtract(&(*CONSTANT_0),&(v322_4));
            drop(v322_4);
            let v322_8: Space = if (&(v322_5)).is_empty() { Space::new() } else {
              let v323_6: Path = concat_path(&(v321_6),&v317_15_cursor.path()[(v317_15_origin + 2)..(v317_15_origin + 3)]);
              let v323_7: Space = routine_27(c, &(v323_6), &(*p1), &v317_15_cursor);
              compose(&(v322_5),&(v323_7))
            };
            drop(v322_5);
            let v322_9: Space = intersect(&(*CONSTANT_12),&(v322_2));
            drop(v322_2);
            let v322_10: Space = if has_head(&(v322_9)) { singleton(&[]) } else { Space::new() };
            drop(v322_9);
            let v322_12: Space = if (&(v322_10)).is_empty() { Space::new() } else {
              let v324_6: Path = concat_path(&(v321_6),&v317_15_cursor.path()[(v317_15_origin + 2)..(v317_15_origin + 3)]);
              let v324_11: Space = routine_28(c, &(v324_6), &(*p1), &v317_15_cursor);
              drop(v324_6);
              compose(&(v322_10),&(v324_11))
            };
            drop(v322_10);
            let v322_13: Space = unite(&(v322_8),&(v322_12));
            join_wrapped_into(&mut v321_7_write,&((v322_13).read_zipper()),&[]);
            }
            v317_15_cursor.ascend(1);
          }
          drop(v321_7_write);
          compose(&(v320_5),&(v321_7))
        };
        drop(v320_5);
        let v320_9: Space = intersect(&(*CONSTANT_12),&(v320_2));
        drop(v320_2);
        let v320_10: Space = if has_head(&(v320_9)) { singleton(&[]) } else { Space::new() };
        drop(v320_9);
        let v320_12: Space = if (&(v320_10)).is_empty() { Space::new() } else {
          let v325_6: Path = concat_path(&(v319_6),&v317_15_cursor.path()[(v317_15_origin + 1)..(v317_15_origin + 2)]);
          let mut v325_11 = Space::new();
          let mut v325_11_write = v325_11.write_zipper();
          for v325_11_byte in v317_15_cursor.child_mask().iter() {
            v317_15_cursor.descend_to_existing_byte(v325_11_byte);
            {
            let v326_2: Space = singleton(&v317_15_cursor.path()[(v317_15_origin + 2)..(v317_15_origin + 3)]);
            let v326_3: Space = intersect(&(*CONSTANT_12),&(v326_2));
            let v326_4: Space = if has_head(&(v326_3)) { singleton(&[]) } else { Space::new() };
            drop(v326_3);
            let v326_5: Space = subtract(&(*CONSTANT_0),&(v326_4));
            drop(v326_4);
            let v326_8: Space = if (&(v326_5)).is_empty() { Space::new() } else {
              let v327_6: Path = concat_path(&(v325_6),&v317_15_cursor.path()[(v317_15_origin + 2)..(v317_15_origin + 3)]);
              let v327_7: Space = routine_27(c, &(v327_6), &(*p1), &v317_15_cursor);
              compose(&(v326_5),&(v327_7))
            };
            drop(v326_5);
            let v326_9: Space = intersect(&(*CONSTANT_12),&(v326_2));
            drop(v326_2);
            let v326_10: Space = if has_head(&(v326_9)) { singleton(&[]) } else { Space::new() };
            drop(v326_9);
            let v326_12: Space = if (&(v326_10)).is_empty() { Space::new() } else {
              let v328_6: Path = concat_path(&(v325_6),&v317_15_cursor.path()[(v317_15_origin + 2)..(v317_15_origin + 3)]);
              let v328_11: Space = routine_29(c, &(v328_6), &(*p1), &v317_15_cursor);
              drop(v328_6);
              compose(&(v326_10),&(v328_11))
            };
            drop(v326_10);
            let v326_13: Space = unite(&(v326_8),&(v326_12));
            join_wrapped_into(&mut v325_11_write,&((v326_13).read_zipper()),&[]);
            }
            v317_15_cursor.ascend(1);
          }
          drop(v325_11_write);
          drop(v325_6);
          compose(&(v320_10),&(v325_11))
        };
        drop(v320_10);
        let v320_13: Space = unite(&(v320_8),&(v320_12));
        join_wrapped_into(&mut v319_7_write,&((v320_13).read_zipper()),&[]);
        }
        v317_15_cursor.ascend(1);
      }
      drop(v319_7_write);
      compose(&(v318_5),&(v319_7))
    };
    drop(v318_5);
    let v318_9: Space = intersect(&(*CONSTANT_12),&(v318_2));
    drop(v318_2);
    let v318_10: Space = if has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
    drop(v318_9);
    let v318_13: Space = if (&(v318_10)).is_empty() { Space::new() } else {
      let v329_6: Path = concat_path(&(*p0),&v317_15_cursor.path()[v317_15_origin..(v317_15_origin + 1)]);
      let v329_11: Path = concat_path(&(v329_6),&(*p1));
      drop(v329_6);
      let v329_12: Space = singleton(&(v329_11));
      drop(v329_11);
      compose(&(v318_10),&(v329_12))
    };
    drop(v318_10);
    let v318_14: Space = unite(&(v318_8),&(v318_13));
    drop(v318_13);
    join_wrapped_into(&mut v317_15_write,&((v318_14).read_zipper()),&[]);
    }
    v317_15_cursor.ascend(1);
  }
  drop(v317_15_cursor);
  drop(v317_15_write);
  (v317_15).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v330_13 = Space::new();
  let mut v330_13_write = v330_13.write_zipper();
  let mut v330_13_cursor = (*s0).read_zipper();
  let v330_13_origin = v330_13_cursor.path().len();
  for v330_13_byte in v330_13_cursor.child_mask().iter() {
    v330_13_cursor.descend_to_existing_byte(v330_13_byte);
    {
    let v331_2: Space = singleton(&v330_13_cursor.path()[v330_13_origin..(v330_13_origin + 1)]);
    let v331_3: Space = intersect(&(*CONSTANT_12),&(v331_2));
    let v331_4: Space = if has_head(&(v331_3)) { singleton(&[]) } else { Space::new() };
    drop(v331_3);
    let v331_5: Space = subtract(&(*CONSTANT_0),&(v331_4));
    drop(v331_4);
    let v331_8: Space = if (&(v331_5)).is_empty() { Space::new() } else {
      let v332_6: Path = concat_path(&(*p0),&v330_13_cursor.path()[v330_13_origin..(v330_13_origin + 1)]);
      let mut v332_7 = Space::new();
      let mut v332_7_write = v332_7.write_zipper();
      for v332_7_byte in v330_13_cursor.child_mask().iter() {
        v330_13_cursor.descend_to_existing_byte(v332_7_byte);
        {
        let v333_2: Space = singleton(&v330_13_cursor.path()[(v330_13_origin + 1)..(v330_13_origin + 2)]);
        let v333_3: Space = intersect(&(*CONSTANT_12),&(v333_2));
        let v333_4: Space = if has_head(&(v333_3)) { singleton(&[]) } else { Space::new() };
        drop(v333_3);
        let v333_5: Space = subtract(&(*CONSTANT_0),&(v333_4));
        drop(v333_4);
        let v333_7: Space = if (&(v333_5)).is_empty() { Space::new() } else {
          let mut v334_6 = Space::new();
          let mut v334_6_write = v334_6.write_zipper();
          for v334_6_byte in v330_13_cursor.child_mask().iter() {
            v330_13_cursor.descend_to_existing_byte(v334_6_byte);
            {
            let v335_2: Space = Space::new();
            join_wrapped_into(&mut v334_6_write,&((v335_2).read_zipper()),&[]);
            }
            v330_13_cursor.ascend(1);
          }
          drop(v334_6_write);
          compose(&(v333_5),&(v334_6))
        };
        drop(v333_5);
        let v333_8: Space = intersect(&(*CONSTANT_12),&(v333_2));
        drop(v333_2);
        let v333_9: Space = if has_head(&(v333_8)) { singleton(&[]) } else { Space::new() };
        drop(v333_8);
        let v333_12: Space = if (&(v333_9)).is_empty() { Space::new() } else {
          let v336_10: Path = concat_path(&(v332_6),&v330_13_cursor.path()[(v330_13_origin + 1)..(v330_13_origin + 2)]);
          let mut v336_11 = Space::new();
          let mut v336_11_write = v336_11.write_zipper();
          for v336_11_byte in v330_13_cursor.child_mask().iter() {
            v330_13_cursor.descend_to_existing_byte(v336_11_byte);
            {
            let v337_2: Space = singleton(&v330_13_cursor.path()[(v330_13_origin + 2)..(v330_13_origin + 3)]);
            let v337_3: Space = intersect(&(*CONSTANT_12),&(v337_2));
            drop(v337_2);
            let v337_4: Space = if has_head(&(v337_3)) { singleton(&[]) } else { Space::new() };
            drop(v337_3);
            let v337_7: Space = if (&(v337_4)).is_empty() { Space::new() } else {
              let v338_5: Path = concat_path(&(v336_10),&v330_13_cursor.path()[(v330_13_origin + 2)..(v330_13_origin + 3)]);
              let v338_6: Space = routine_29(c, &(v338_5), &(*p1), &v330_13_cursor);
              drop(v338_5);
              compose(&(v337_4),&(v338_6))
            };
            drop(v337_4);
            join_wrapped_into(&mut v336_11_write,&((v337_7).read_zipper()),&[]);
            }
            v330_13_cursor.ascend(1);
          }
          drop(v336_11_write);
          drop(v336_10);
          compose(&(v333_9),&(v336_11))
        };
        drop(v333_9);
        let v333_13: Space = unite(&(v333_7),&(v333_12));
        drop(v333_7);
        join_wrapped_into(&mut v332_7_write,&((v333_13).read_zipper()),&[]);
        }
        v330_13_cursor.ascend(1);
      }
      drop(v332_7_write);
      compose(&(v331_5),&(v332_7))
    };
    drop(v331_5);
    let v331_9: Space = intersect(&(*CONSTANT_12),&(v331_2));
    drop(v331_2);
    let v331_10: Space = if has_head(&(v331_9)) { singleton(&[]) } else { Space::new() };
    drop(v331_9);
    let v331_12: Space = if (&(v331_10)).is_empty() { Space::new() } else {
      let v339_6: Path = concat_path(&(*p0),&v330_13_cursor.path()[v330_13_origin..(v330_13_origin + 1)]);
      let mut v339_11 = Space::new();
      let mut v339_11_write = v339_11.write_zipper();
      for v339_11_byte in v330_13_cursor.child_mask().iter() {
        v330_13_cursor.descend_to_existing_byte(v339_11_byte);
        {
        let v340_2: Space = singleton(&v330_13_cursor.path()[(v330_13_origin + 1)..(v330_13_origin + 2)]);
        let v340_3: Space = intersect(&(*CONSTANT_12),&(v340_2));
        let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
        drop(v340_3);
        let v340_5: Space = subtract(&(*CONSTANT_0),&(v340_4));
        drop(v340_4);
        let v340_7: Space = if (&(v340_5)).is_empty() { Space::new() } else {
          let mut v341_6 = Space::new();
          let mut v341_6_write = v341_6.write_zipper();
          for v341_6_byte in v330_13_cursor.child_mask().iter() {
            v330_13_cursor.descend_to_existing_byte(v341_6_byte);
            {
            let v342_2: Space = Space::new();
            join_wrapped_into(&mut v341_6_write,&((v342_2).read_zipper()),&[]);
            }
            v330_13_cursor.ascend(1);
          }
          drop(v341_6_write);
          compose(&(v340_5),&(v341_6))
        };
        drop(v340_5);
        let v340_8: Space = intersect(&(*CONSTANT_12),&(v340_2));
        drop(v340_2);
        let v340_9: Space = if has_head(&(v340_8)) { singleton(&[]) } else { Space::new() };
        drop(v340_8);
        let v340_13: Space = if (&(v340_9)).is_empty() { Space::new() } else {
          let v343_10: Path = concat_path(&(v339_6),&v330_13_cursor.path()[(v330_13_origin + 1)..(v330_13_origin + 2)]);
          let v343_11: Path = concat_path(&(v343_10),&(*p1));
          drop(v343_10);
          let v343_12: Space = singleton(&(v343_11));
          drop(v343_11);
          compose(&(v340_9),&(v343_12))
        };
        drop(v340_9);
        let v340_14: Space = unite(&(v340_7),&(v340_13));
        drop(v340_7);
        drop(v340_13);
        join_wrapped_into(&mut v339_11_write,&((v340_14).read_zipper()),&[]);
        }
        v330_13_cursor.ascend(1);
      }
      drop(v339_11_write);
      drop(v339_6);
      compose(&(v331_10),&(v339_11))
    };
    drop(v331_10);
    let v331_13: Space = unite(&(v331_8),&(v331_12));
    drop(v331_12);
    join_wrapped_into(&mut v330_13_write,&((v331_13).read_zipper()),&[]);
    }
    v330_13_cursor.ascend(1);
  }
  drop(v330_13_cursor);
  drop(v330_13_write);
  (v330_13).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v344_10 = Space::new();
  let mut v344_10_write = v344_10.write_zipper();
  let mut v344_10_cursor = (*s0).read_zipper();
  let v344_10_origin = v344_10_cursor.path().len();
  for v344_10_byte in v344_10_cursor.child_mask().iter() {
    v344_10_cursor.descend_to_existing_byte(v344_10_byte);
    {
    let v345_2: Space = singleton(&v344_10_cursor.path()[v344_10_origin..(v344_10_origin + 1)]);
    let v345_3: Space = intersect(&(*CONSTANT_12),&(v345_2));
    let v345_4: Space = if has_head(&(v345_3)) { singleton(&[]) } else { Space::new() };
    drop(v345_3);
    let v345_5: Space = subtract(&(*CONSTANT_0),&(v345_4));
    drop(v345_4);
    let v345_8: Space = if (&(v345_5)).is_empty() { Space::new() } else {
      let v346_6: Path = concat_path(&(*p0),&v344_10_cursor.path()[v344_10_origin..(v344_10_origin + 1)]);
      let mut v346_7 = Space::new();
      let mut v346_7_write = v346_7.write_zipper();
      for v346_7_byte in v344_10_cursor.child_mask().iter() {
        v344_10_cursor.descend_to_existing_byte(v346_7_byte);
        {
        let v347_2: Space = singleton(&v344_10_cursor.path()[(v344_10_origin + 1)..(v344_10_origin + 2)]);
        let v347_3: Space = intersect(&(*CONSTANT_12),&(v347_2));
        let v347_4: Space = if has_head(&(v347_3)) { singleton(&[]) } else { Space::new() };
        drop(v347_3);
        let v347_5: Space = subtract(&(*CONSTANT_0),&(v347_4));
        drop(v347_4);
        let v347_7: Space = if (&(v347_5)).is_empty() { Space::new() } else {
          let mut v348_6 = Space::new();
          let mut v348_6_write = v348_6.write_zipper();
          for v348_6_byte in v344_10_cursor.child_mask().iter() {
            v344_10_cursor.descend_to_existing_byte(v348_6_byte);
            {
            let v349_2: Space = Space::new();
            join_wrapped_into(&mut v348_6_write,&((v349_2).read_zipper()),&[]);
            }
            v344_10_cursor.ascend(1);
          }
          drop(v348_6_write);
          compose(&(v347_5),&(v348_6))
        };
        drop(v347_5);
        let v347_8: Space = intersect(&(*CONSTANT_12),&(v347_2));
        drop(v347_2);
        let v347_9: Space = if has_head(&(v347_8)) { singleton(&[]) } else { Space::new() };
        drop(v347_8);
        let v347_12: Space = if (&(v347_9)).is_empty() { Space::new() } else {
          let v350_10: Path = concat_path(&(v346_6),&v344_10_cursor.path()[(v344_10_origin + 1)..(v344_10_origin + 2)]);
          let mut v350_11 = Space::new();
          let mut v350_11_write = v350_11.write_zipper();
          for v350_11_byte in v344_10_cursor.child_mask().iter() {
            v344_10_cursor.descend_to_existing_byte(v350_11_byte);
            {
            let v351_2: Space = singleton(&v344_10_cursor.path()[(v344_10_origin + 2)..(v344_10_origin + 3)]);
            let v351_3: Space = intersect(&(*CONSTANT_12),&(v351_2));
            drop(v351_2);
            let v351_4: Space = if has_head(&(v351_3)) { singleton(&[]) } else { Space::new() };
            drop(v351_3);
            let v351_7: Space = if (&(v351_4)).is_empty() { Space::new() } else {
              let v352_5: Path = concat_path(&(v350_10),&v344_10_cursor.path()[(v344_10_origin + 2)..(v344_10_origin + 3)]);
              let v352_6: Space = routine_29(c, &(v352_5), &(*p1), &v344_10_cursor);
              drop(v352_5);
              compose(&(v351_4),&(v352_6))
            };
            drop(v351_4);
            join_wrapped_into(&mut v350_11_write,&((v351_7).read_zipper()),&[]);
            }
            v344_10_cursor.ascend(1);
          }
          drop(v350_11_write);
          drop(v350_10);
          compose(&(v347_9),&(v350_11))
        };
        drop(v347_9);
        let v347_13: Space = unite(&(v347_7),&(v347_12));
        drop(v347_7);
        join_wrapped_into(&mut v346_7_write,&((v347_13).read_zipper()),&[]);
        }
        v344_10_cursor.ascend(1);
      }
      drop(v346_7_write);
      compose(&(v345_5),&(v346_7))
    };
    drop(v345_5);
    let v345_9: Space = intersect(&(*CONSTANT_12),&(v345_2));
    drop(v345_2);
    let v345_10: Space = if has_head(&(v345_9)) { singleton(&[]) } else { Space::new() };
    drop(v345_9);
    let v345_13: Space = if (&(v345_10)).is_empty() { Space::new() } else {
      let v353_6: Path = concat_path(&(*p0),&v344_10_cursor.path()[v344_10_origin..(v344_10_origin + 1)]);
      let v353_11: Path = concat_path(&(v353_6),&(*p1));
      drop(v353_6);
      let v353_12: Space = singleton(&(v353_11));
      drop(v353_11);
      compose(&(v345_10),&(v353_12))
    };
    drop(v345_10);
    let v345_14: Space = unite(&(v345_8),&(v345_13));
    drop(v345_13);
    join_wrapped_into(&mut v344_10_write,&((v345_14).read_zipper()),&[]);
    }
    v344_10_cursor.ascend(1);
  }
  drop(v344_10_cursor);
  drop(v344_10_write);
  (v344_10).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v354_7 = Space::new();
  let mut v354_7_write = v354_7.write_zipper();
  let mut v354_7_cursor = (*s0).read_zipper();
  let v354_7_origin = v354_7_cursor.path().len();
  for v354_7_byte in v354_7_cursor.child_mask().iter() {
    v354_7_cursor.descend_to_existing_byte(v354_7_byte);
    {
    let v355_2: Space = singleton(&v354_7_cursor.path()[v354_7_origin..(v354_7_origin + 1)]);
    let v355_3: Space = intersect(&(*CONSTANT_12),&(v355_2));
    let v355_4: Space = if has_head(&(v355_3)) { singleton(&[]) } else { Space::new() };
    drop(v355_3);
    let v355_5: Space = subtract(&(*CONSTANT_0),&(v355_4));
    drop(v355_4);
    let v355_7: Space = if (&(v355_5)).is_empty() { Space::new() } else {
      let mut v356_6 = Space::new();
      let mut v356_6_write = v356_6.write_zipper();
      for v356_6_byte in v354_7_cursor.child_mask().iter() {
        v354_7_cursor.descend_to_existing_byte(v356_6_byte);
        {
        let v357_2: Space = Space::new();
        join_wrapped_into(&mut v356_6_write,&((v357_2).read_zipper()),&[]);
        }
        v354_7_cursor.ascend(1);
      }
      drop(v356_6_write);
      compose(&(v355_5),&(v356_6))
    };
    drop(v355_5);
    let v355_8: Space = intersect(&(*CONSTANT_12),&(v355_2));
    drop(v355_2);
    let v355_9: Space = if has_head(&(v355_8)) { singleton(&[]) } else { Space::new() };
    drop(v355_8);
    let v355_12: Space = if (&(v355_9)).is_empty() { Space::new() } else {
      let v358_10: Path = concat_path(&(*p0),&v354_7_cursor.path()[v354_7_origin..(v354_7_origin + 1)]);
      let mut v358_11 = Space::new();
      let mut v358_11_write = v358_11.write_zipper();
      for v358_11_byte in v354_7_cursor.child_mask().iter() {
        v354_7_cursor.descend_to_existing_byte(v358_11_byte);
        {
        let v359_2: Space = singleton(&v354_7_cursor.path()[(v354_7_origin + 1)..(v354_7_origin + 2)]);
        let v359_3: Space = intersect(&(*CONSTANT_12),&(v359_2));
        drop(v359_2);
        let v359_4: Space = if has_head(&(v359_3)) { singleton(&[]) } else { Space::new() };
        drop(v359_3);
        let v359_8: Space = if (&(v359_4)).is_empty() { Space::new() } else {
          let v360_5: Path = concat_path(&(v358_10),&v354_7_cursor.path()[(v354_7_origin + 1)..(v354_7_origin + 2)]);
          let v360_6: Path = concat_path(&(v360_5),&(*p1));
          drop(v360_5);
          let v360_7: Space = singleton(&(v360_6));
          drop(v360_6);
          compose(&(v359_4),&(v360_7))
        };
        drop(v359_4);
        join_wrapped_into(&mut v358_11_write,&((v359_8).read_zipper()),&[]);
        }
        v354_7_cursor.ascend(1);
      }
      drop(v358_11_write);
      drop(v358_10);
      compose(&(v355_9),&(v358_11))
    };
    drop(v355_9);
    let v355_13: Space = unite(&(v355_7),&(v355_12));
    drop(v355_7);
    drop(v355_12);
    join_wrapped_into(&mut v354_7_write,&((v355_13).read_zipper()),&[]);
    }
    v354_7_cursor.ascend(1);
  }
  drop(v354_7_cursor);
  drop(v354_7_write);
  (v354_7).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v361_6 = Space::new();
  let mut v361_6_write = v361_6.write_zipper();
  let mut v361_6_cursor = (*s0).read_zipper();
  let v361_6_origin = v361_6_cursor.path().len();
  for v361_6_byte in v361_6_cursor.child_mask().iter() {
    v361_6_cursor.descend_to_existing_byte(v361_6_byte);
    {
    let v362_2: Space = singleton(&v361_6_cursor.path()[v361_6_origin..(v361_6_origin + 1)]);
    let v362_3: Space = intersect(&(*CONSTANT_12),&(v362_2));
    let v362_4: Space = if has_head(&(v362_3)) { singleton(&[]) } else { Space::new() };
    drop(v362_3);
    let v362_5: Space = subtract(&(*CONSTANT_0),&(v362_4));
    drop(v362_4);
    let v362_7: Space = if (&(v362_5)).is_empty() { Space::new() } else {
      let mut v363_6 = Space::new();
      let mut v363_6_write = v363_6.write_zipper();
      for v363_6_byte in v361_6_cursor.child_mask().iter() {
        v361_6_cursor.descend_to_existing_byte(v363_6_byte);
        {
        let v364_2: Space = Space::new();
        join_wrapped_into(&mut v363_6_write,&((v364_2).read_zipper()),&[]);
        }
        v361_6_cursor.ascend(1);
      }
      drop(v363_6_write);
      compose(&(v362_5),&(v363_6))
    };
    drop(v362_5);
    let v362_8: Space = intersect(&(*CONSTANT_12),&(v362_2));
    drop(v362_2);
    let v362_9: Space = if has_head(&(v362_8)) { singleton(&[]) } else { Space::new() };
    drop(v362_8);
    let v362_13: Space = if (&(v362_9)).is_empty() { Space::new() } else {
      let v365_10: Path = concat_path(&(*p0),&v361_6_cursor.path()[v361_6_origin..(v361_6_origin + 1)]);
      let v365_11: Path = concat_path(&(v365_10),&(*p1));
      drop(v365_10);
      let v365_12: Space = singleton(&(v365_11));
      drop(v365_11);
      compose(&(v362_9),&(v365_12))
    };
    drop(v362_9);
    let v362_14: Space = unite(&(v362_7),&(v362_13));
    drop(v362_7);
    drop(v362_13);
    join_wrapped_into(&mut v361_6_write,&((v362_14).read_zipper()),&[]);
    }
    v361_6_cursor.ascend(1);
  }
  drop(v361_6_cursor);
  drop(v361_6_write);
  (v361_6).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let mut v366_9 = Space::new();
  let mut v366_9_write = v366_9.write_zipper();
  let mut v366_9_cursor = (*s0).read_zipper();
  let v366_9_origin = v366_9_cursor.path().len();
  for v366_9_byte in v366_9_cursor.child_mask().iter() {
    v366_9_cursor.descend_to_existing_byte(v366_9_byte);
    {
    let v367_2: Space = singleton(&v366_9_cursor.path()[v366_9_origin..(v366_9_origin + 1)]);
    let v367_3: Space = intersect(&(*CONSTANT_12),&(v367_2));
    let v367_4: Space = if has_head(&(v367_3)) { singleton(&[]) } else { Space::new() };
    drop(v367_3);
    let v367_5: Space = subtract(&(*CONSTANT_0),&(v367_4));
    drop(v367_4);
    let v367_7: Space = if (&(v367_5)).is_empty() { Space::new() } else {
      let mut v368_6 = Space::new();
      let mut v368_6_write = v368_6.write_zipper();
      for v368_6_byte in v366_9_cursor.child_mask().iter() {
        v366_9_cursor.descend_to_existing_byte(v368_6_byte);
        {
        let v369_2: Space = Space::new();
        join_wrapped_into(&mut v368_6_write,&((v369_2).read_zipper()),&[]);
        }
        v366_9_cursor.ascend(1);
      }
      drop(v368_6_write);
      compose(&(v367_5),&(v368_6))
    };
    drop(v367_5);
    let v367_8: Space = intersect(&(*CONSTANT_12),&(v367_2));
    drop(v367_2);
    let v367_9: Space = if has_head(&(v367_8)) { singleton(&[]) } else { Space::new() };
    drop(v367_8);
    let v367_12: Space = if (&(v367_9)).is_empty() { Space::new() } else {
      let v370_10: Path = concat_path(&(*p0),&v366_9_cursor.path()[v366_9_origin..(v366_9_origin + 1)]);
      let mut v370_11 = Space::new();
      let mut v370_11_write = v370_11.write_zipper();
      for v370_11_byte in v366_9_cursor.child_mask().iter() {
        v366_9_cursor.descend_to_existing_byte(v370_11_byte);
        {
        let v371_2: Space = singleton(&v366_9_cursor.path()[(v366_9_origin + 1)..(v366_9_origin + 2)]);
        let v371_3: Space = intersect(&(*CONSTANT_12),&(v371_2));
        drop(v371_2);
        let v371_4: Space = if has_head(&(v371_3)) { singleton(&[]) } else { Space::new() };
        drop(v371_3);
        let v371_7: Space = if (&(v371_4)).is_empty() { Space::new() } else {
          let v372_5: Path = concat_path(&(v370_10),&v366_9_cursor.path()[(v366_9_origin + 1)..(v366_9_origin + 2)]);
          let v372_6: Space = routine_37(c, &(v372_5), &v366_9_cursor, &(*s1), &(*s2), &(*s3));
          drop(v372_5);
          compose(&(v371_4),&(v372_6))
        };
        drop(v371_4);
        join_wrapped_into(&mut v370_11_write,&((v371_7).read_zipper()),&[]);
        }
        v366_9_cursor.ascend(1);
      }
      drop(v370_11_write);
      drop(v370_10);
      compose(&(v367_9),&(v370_11))
    };
    drop(v367_9);
    let v367_13: Space = unite(&(v367_7),&(v367_12));
    drop(v367_7);
    join_wrapped_into(&mut v366_9_write,&((v367_13).read_zipper()),&[]);
    }
    v366_9_cursor.ascend(1);
  }
  drop(v366_9_cursor);
  drop(v366_9_write);
  (v366_9).clone()
}

fn routine_36(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let mut v373_8 = Space::new();
  let mut v373_8_write = v373_8.write_zipper();
  let mut v373_8_cursor = (*s0).read_zipper();
  let v373_8_origin = v373_8_cursor.path().len();
  for v373_8_byte in v373_8_cursor.child_mask().iter() {
    v373_8_cursor.descend_to_existing_byte(v373_8_byte);
    {
    let v374_2: Space = singleton(&v373_8_cursor.path()[v373_8_origin..(v373_8_origin + 1)]);
    let v374_3: Space = intersect(&(*CONSTANT_12),&(v374_2));
    let v374_4: Space = if has_head(&(v374_3)) { singleton(&[]) } else { Space::new() };
    drop(v374_3);
    let v374_5: Space = subtract(&(*CONSTANT_0),&(v374_4));
    drop(v374_4);
    let v374_7: Space = if (&(v374_5)).is_empty() { Space::new() } else {
      let mut v375_6 = Space::new();
      let mut v375_6_write = v375_6.write_zipper();
      for v375_6_byte in v373_8_cursor.child_mask().iter() {
        v373_8_cursor.descend_to_existing_byte(v375_6_byte);
        {
        let v376_2: Space = Space::new();
        join_wrapped_into(&mut v375_6_write,&((v376_2).read_zipper()),&[]);
        }
        v373_8_cursor.ascend(1);
      }
      drop(v375_6_write);
      compose(&(v374_5),&(v375_6))
    };
    drop(v374_5);
    let v374_8: Space = intersect(&(*CONSTANT_12),&(v374_2));
    drop(v374_2);
    let v374_9: Space = if has_head(&(v374_8)) { singleton(&[]) } else { Space::new() };
    drop(v374_8);
    let v374_27: Space = if (&(v374_9)).is_empty() { Space::new() } else {
      let v377_10: Path = concat_path(&(*p0),&v373_8_cursor.path()[v373_8_origin..(v373_8_origin + 1)]);
      let v377_11: Space = singleton(&(v377_10));
      let v377_12: Space = routine_38(c, &(*s1), &(*s3), &((v377_11).read_zipper()));
      let v377_13: Space = routine_38(c, &(*s2), &(*s3), &((v377_11).read_zipper()));
      let v377_14: Space = intersect(&(v377_12),&(v377_13));
      let v377_15: Space = subtract(&(v377_14),&(v377_11));
      drop(v377_11);
      let v377_16: Space = wrap(&(v377_15),&(v377_10));
      drop(v377_10);
      let v377_17: Space = subtract(&(*s3),&(v377_13));
      let v377_18: Space = subtract(&(v377_17),&(v377_12));
      let v377_19: Space = routine_39(c, &(*s2), &(*s1), &((v377_18).read_zipper()));
      let v377_20: Space = unite(&(v377_16),&(v377_19));
      let v377_21: Space = subtract(&(v377_12),&(v377_13));
      let v377_22: Space = routine_39(c, &(*s2), &(*s1), &((v377_21).read_zipper()));
      let v377_23: Space = unite(&(v377_20),&(v377_22));
      let v377_24: Space = subtract(&(v377_13),&(v377_12));
      let v377_25: Space = routine_39(c, &(*s2), &(*s1), &((v377_24).read_zipper()));
      let v377_26: Space = unite(&(v377_23),&(v377_25));
      compose(&(v374_9),&(v377_26))
    };
    drop(v374_9);
    let v374_28: Space = unite(&(v374_7),&(v374_27));
    drop(v374_7);
    join_wrapped_into(&mut v373_8_write,&((v374_28).read_zipper()),&[]);
    }
    v373_8_cursor.ascend(1);
  }
  drop(v373_8_cursor);
  drop(v373_8_write);
  (v373_8).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let (mut v378_24,mut v378_43,mut v378_44,mut v378_45,mut v378_46,mut v378_5,mut v378_65,mut v378_66,mut v378_85,) = native_block_1(c, p0, s1, s2, s3);
  let (mut v378_163,mut v378_164,mut v378_183,mut v378_202,mut v378_203,mut v378_204,mut v378_280,mut v378_281,mut v378_300,mut v378_86,mut v378_87,) = native_block_4(c, s1, s2, s3, &v378_46, &v378_5, &v378_66, &v378_85);
  let mut v378_319: Space = (v378_5).clone();
  loop {
    let v655_1: Space = intersect(&(v378_319),&(*s3));
    let v655_2: Space = restrict_to(&(*s1),&(v655_1));
    drop(v655_1);
    let mut v655_3 = Space::new();
    let mut v655_3_write = v655_3.write_zipper();
    let mut v655_3_cursor = (v655_2).read_zipper();
    let v655_3_origin = v655_3_cursor.path().len();
    for v655_3_byte in v655_3_cursor.child_mask().iter() {
      v655_3_cursor.descend_to_existing_byte(v655_3_byte);
      {
      let v656_2: Space = singleton(&v655_3_cursor.path()[v655_3_origin..(v655_3_origin + 1)]);
      let v656_3: Space = intersect(&(*CONSTANT_12),&(v656_2));
      let v656_4: Space = if has_head(&(v656_3)) { singleton(&[]) } else { Space::new() };
      drop(v656_3);
      let v656_5: Space = subtract(&(*CONSTANT_0),&(v656_4));
      drop(v656_4);
      let v656_7: Space = if (&(v656_5)).is_empty() { Space::new() } else {
        let mut v657_6 = Space::new();
        let mut v657_6_write = v657_6.write_zipper();
        for v657_6_byte in v655_3_cursor.child_mask().iter() {
          v655_3_cursor.descend_to_existing_byte(v657_6_byte);
          {
          let v658_2: Space = singleton(&v655_3_cursor.path()[(v655_3_origin + 1)..(v655_3_origin + 2)]);
          let v658_3: Space = intersect(&(*CONSTANT_12),&(v658_2));
          let v658_4: Space = if has_head(&(v658_3)) { singleton(&[]) } else { Space::new() };
          drop(v658_3);
          let v658_5: Space = subtract(&(*CONSTANT_0),&(v658_4));
          drop(v658_4);
          let v658_8: Space = if (&(v658_5)).is_empty() { Space::new() } else {
            let mut v659_7 = Space::new();
            let mut v659_7_write = v659_7.write_zipper();
            for v659_7_byte in v655_3_cursor.child_mask().iter() {
              v655_3_cursor.descend_to_existing_byte(v659_7_byte);
              {
              let v660_2: Space = singleton(&v655_3_cursor.path()[(v655_3_origin + 2)..(v655_3_origin + 3)]);
              let v660_3: Space = intersect(&(*CONSTANT_12),&(v660_2));
              let v660_4: Space = if has_head(&(v660_3)) { singleton(&[]) } else { Space::new() };
              drop(v660_3);
              let v660_5: Space = subtract(&(*CONSTANT_0),&(v660_4));
              drop(v660_4);
              let v660_8: Space = if (&(v660_5)).is_empty() { Space::new() } else {
                let v661_7: Space = routine_41(c, &v655_3_cursor.path()[v655_3_origin..(v655_3_origin + 3)], &v655_3_cursor);
                compose(&(v660_5),&(v661_7))
              };
              drop(v660_5);
              let v660_9: Space = intersect(&(*CONSTANT_12),&(v660_2));
              drop(v660_2);
              let v660_10: Space = if has_head(&(v660_9)) { singleton(&[]) } else { Space::new() };
              drop(v660_9);
              let v660_12: Space = if (&(v660_10)).is_empty() { Space::new() } else {
                let v662_11: Space = routine_42(c, &v655_3_cursor.path()[v655_3_origin..(v655_3_origin + 3)], &v655_3_cursor);
                compose(&(v660_10),&(v662_11))
              };
              drop(v660_10);
              let v660_13: Space = unite(&(v660_8),&(v660_12));
              join_wrapped_into(&mut v659_7_write,&((v660_13).read_zipper()),&[]);
              }
              v655_3_cursor.ascend(1);
            }
            drop(v659_7_write);
            compose(&(v658_5),&(v659_7))
          };
          drop(v658_5);
          let v658_9: Space = intersect(&(*CONSTANT_12),&(v658_2));
          drop(v658_2);
          let v658_10: Space = if has_head(&(v658_9)) { singleton(&[]) } else { Space::new() };
          drop(v658_9);
          let v658_12: Space = if (&(v658_10)).is_empty() { Space::new() } else {
            let mut v663_11 = Space::new();
            let mut v663_11_write = v663_11.write_zipper();
            for v663_11_byte in v655_3_cursor.child_mask().iter() {
              v655_3_cursor.descend_to_existing_byte(v663_11_byte);
              {
              let v664_2: Space = singleton(&v655_3_cursor.path()[(v655_3_origin + 2)..(v655_3_origin + 3)]);
              let v664_3: Space = intersect(&(*CONSTANT_12),&(v664_2));
              let v664_4: Space = if has_head(&(v664_3)) { singleton(&[]) } else { Space::new() };
              drop(v664_3);
              let v664_5: Space = subtract(&(*CONSTANT_0),&(v664_4));
              drop(v664_4);
              let v664_8: Space = if (&(v664_5)).is_empty() { Space::new() } else {
                let v665_7: Space = routine_41(c, &v655_3_cursor.path()[v655_3_origin..(v655_3_origin + 3)], &v655_3_cursor);
                compose(&(v664_5),&(v665_7))
              };
              drop(v664_5);
              let v664_9: Space = intersect(&(*CONSTANT_12),&(v664_2));
              drop(v664_2);
              let v664_10: Space = if has_head(&(v664_9)) { singleton(&[]) } else { Space::new() };
              drop(v664_9);
              let v664_12: Space = if (&(v664_10)).is_empty() { Space::new() } else {
                let v666_11: Space = routine_43(c, &v655_3_cursor.path()[v655_3_origin..(v655_3_origin + 3)], &v655_3_cursor);
                compose(&(v664_10),&(v666_11))
              };
              drop(v664_10);
              let v664_13: Space = unite(&(v664_8),&(v664_12));
              join_wrapped_into(&mut v663_11_write,&((v664_13).read_zipper()),&[]);
              }
              v655_3_cursor.ascend(1);
            }
            drop(v663_11_write);
            compose(&(v658_10),&(v663_11))
          };
          drop(v658_10);
          let v658_13: Space = unite(&(v658_8),&(v658_12));
          join_wrapped_into(&mut v657_6_write,&((v658_13).read_zipper()),&[]);
          }
          v655_3_cursor.ascend(1);
        }
        drop(v657_6_write);
        compose(&(v656_5),&(v657_6))
      };
      drop(v656_5);
      let v656_8: Space = intersect(&(*CONSTANT_12),&(v656_2));
      drop(v656_2);
      let v656_9: Space = if has_head(&(v656_8)) { singleton(&[]) } else { Space::new() };
      drop(v656_8);
      let v656_11: Space = if (&(v656_9)).is_empty() { Space::new() } else {
        let mut v667_10 = Space::new();
        let mut v667_10_write = v667_10.write_zipper();
        for v667_10_byte in v655_3_cursor.child_mask().iter() {
          v655_3_cursor.descend_to_existing_byte(v667_10_byte);
          {
          let v668_2: Space = singleton(&v655_3_cursor.path()[(v655_3_origin + 1)..(v655_3_origin + 2)]);
          let v668_3: Space = intersect(&(*CONSTANT_12),&(v668_2));
          let v668_4: Space = if has_head(&(v668_3)) { singleton(&[]) } else { Space::new() };
          drop(v668_3);
          let v668_5: Space = subtract(&(*CONSTANT_0),&(v668_4));
          drop(v668_4);
          let v668_8: Space = if (&(v668_5)).is_empty() { Space::new() } else {
            let mut v669_7 = Space::new();
            let mut v669_7_write = v669_7.write_zipper();
            for v669_7_byte in v655_3_cursor.child_mask().iter() {
              v655_3_cursor.descend_to_existing_byte(v669_7_byte);
              {
              let v670_2: Space = singleton(&v655_3_cursor.path()[(v655_3_origin + 2)..(v655_3_origin + 3)]);
              let v670_3: Space = intersect(&(*CONSTANT_12),&(v670_2));
              let v670_4: Space = if has_head(&(v670_3)) { singleton(&[]) } else { Space::new() };
              drop(v670_3);
              let v670_5: Space = subtract(&(*CONSTANT_0),&(v670_4));
              drop(v670_4);
              let v670_8: Space = if (&(v670_5)).is_empty() { Space::new() } else {
                let v671_7: Space = routine_41(c, &v655_3_cursor.path()[v655_3_origin..(v655_3_origin + 3)], &v655_3_cursor);
                compose(&(v670_5),&(v671_7))
              };
              drop(v670_5);
              let v670_9: Space = intersect(&(*CONSTANT_12),&(v670_2));
              drop(v670_2);
              let v670_10: Space = if has_head(&(v670_9)) { singleton(&[]) } else { Space::new() };
              drop(v670_9);
              let v670_12: Space = if (&(v670_10)).is_empty() { Space::new() } else {
                let v672_11: Space = routine_42(c, &v655_3_cursor.path()[v655_3_origin..(v655_3_origin + 3)], &v655_3_cursor);
                compose(&(v670_10),&(v672_11))
              };
              drop(v670_10);
              let v670_13: Space = unite(&(v670_8),&(v670_12));
              join_wrapped_into(&mut v669_7_write,&((v670_13).read_zipper()),&[]);
              }
              v655_3_cursor.ascend(1);
            }
            drop(v669_7_write);
            compose(&(v668_5),&(v669_7))
          };
          drop(v668_5);
          let v668_9: Space = intersect(&(*CONSTANT_12),&(v668_2));
          drop(v668_2);
          let v668_10: Space = if has_head(&(v668_9)) { singleton(&[]) } else { Space::new() };
          drop(v668_9);
          let v668_11: Space = compose(&(v668_10),&v655_3_cursor);
          drop(v668_10);
          let v668_12: Space = unite(&(v668_8),&(v668_11));
          drop(v668_11);
          join_wrapped_into(&mut v667_10_write,&((v668_12).read_zipper()),&[]);
          }
          v655_3_cursor.ascend(1);
        }
        drop(v667_10_write);
        compose(&(v656_9),&(v667_10))
      };
      drop(v656_9);
      let v656_12: Space = unite(&(v656_7),&(v656_11));
      join_wrapped_into(&mut v655_3_write,&((v656_12).read_zipper()),&[]);
      }
      v655_3_cursor.ascend(1);
    }
    drop(v655_3_cursor);
    drop(v655_3_write);
    drop(v655_2);
    let v655_4: Space = unite(&(v655_3),&(v378_319));
    let v655_5: Space = intersect(&(v655_4),&(*s3));
    if !v378_319.join_into((v655_5).clone()).is_element() { break; }
  }
  let v378_320: Space = subtract(&(v378_300),&(v378_319));
  let v378_321: Space = routine_11(c, &((v378_320).read_zipper()));
  let mut v378_397 = Space::new();
  let mut v378_397_write = v378_397.write_zipper();
  let mut v378_397_cursor = (v378_321).read_zipper();
  let v378_397_origin = v378_397_cursor.path().len();
  for v378_397_byte in v378_397_cursor.child_mask().iter() {
    v378_397_cursor.descend_to_existing_byte(v378_397_byte);
    {
    let (mut v673_10,mut v673_17,) = native_block_5(c, s1, s2, s3, &v378_397_cursor, v378_397_origin, &v378_5);
    let v673_18: Space = unite(&(v673_10),&(v673_17));
    join_wrapped_into(&mut v378_397_write,&((v673_18).read_zipper()),&[]);
    }
    v378_397_cursor.ascend(1);
  }
  drop(v378_397_cursor);
  drop(v378_397_write);
  drop(v378_5);
  let v378_398: Space = unite(&(v378_281),&(v378_397));
  (v378_398).clone()
}

fn routine_38(c: &mut Context, s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>) -> Space {
  let v748_3: Space = intersect(&(*s1),&(*s2));
  let v748_4: Space = restrict_to(&(*s0),&(v748_3));
  drop(v748_3);
  let mut v748_23 = Space::new();
  let mut v748_23_write = v748_23.write_zipper();
  let mut v748_23_cursor = (v748_4).read_zipper();
  let v748_23_origin = v748_23_cursor.path().len();
  for v748_23_byte in v748_23_cursor.child_mask().iter() {
    v748_23_cursor.descend_to_existing_byte(v748_23_byte);
    {
    let v749_2: Space = singleton(&v748_23_cursor.path()[v748_23_origin..(v748_23_origin + 1)]);
    let v749_3: Space = intersect(&(*CONSTANT_12),&(v749_2));
    let v749_4: Space = if has_head(&(v749_3)) { singleton(&[]) } else { Space::new() };
    drop(v749_3);
    let v749_5: Space = subtract(&(*CONSTANT_0),&(v749_4));
    drop(v749_4);
    let v749_7: Space = if (&(v749_5)).is_empty() { Space::new() } else {
      let mut v750_6 = Space::new();
      let mut v750_6_write = v750_6.write_zipper();
      for v750_6_byte in v748_23_cursor.child_mask().iter() {
        v748_23_cursor.descend_to_existing_byte(v750_6_byte);
        {
        let v751_2: Space = singleton(&v748_23_cursor.path()[(v748_23_origin + 1)..(v748_23_origin + 2)]);
        let v751_3: Space = intersect(&(*CONSTANT_12),&(v751_2));
        let v751_4: Space = if has_head(&(v751_3)) { singleton(&[]) } else { Space::new() };
        drop(v751_3);
        let v751_5: Space = subtract(&(*CONSTANT_0),&(v751_4));
        drop(v751_4);
        let v751_8: Space = if (&(v751_5)).is_empty() { Space::new() } else {
          let mut v752_7 = Space::new();
          let mut v752_7_write = v752_7.write_zipper();
          for v752_7_byte in v748_23_cursor.child_mask().iter() {
            v748_23_cursor.descend_to_existing_byte(v752_7_byte);
            {
            let v753_2: Space = singleton(&v748_23_cursor.path()[(v748_23_origin + 2)..(v748_23_origin + 3)]);
            let v753_3: Space = intersect(&(*CONSTANT_12),&(v753_2));
            let v753_4: Space = if has_head(&(v753_3)) { singleton(&[]) } else { Space::new() };
            drop(v753_3);
            let v753_5: Space = subtract(&(*CONSTANT_0),&(v753_4));
            drop(v753_4);
            let v753_8: Space = if (&(v753_5)).is_empty() { Space::new() } else {
              let v754_7: Space = routine_41(c, &v748_23_cursor.path()[v748_23_origin..(v748_23_origin + 3)], &v748_23_cursor);
              compose(&(v753_5),&(v754_7))
            };
            drop(v753_5);
            let v753_9: Space = intersect(&(*CONSTANT_12),&(v753_2));
            drop(v753_2);
            let v753_10: Space = if has_head(&(v753_9)) { singleton(&[]) } else { Space::new() };
            drop(v753_9);
            let v753_12: Space = if (&(v753_10)).is_empty() { Space::new() } else {
              let v755_11: Space = routine_42(c, &v748_23_cursor.path()[v748_23_origin..(v748_23_origin + 3)], &v748_23_cursor);
              compose(&(v753_10),&(v755_11))
            };
            drop(v753_10);
            let v753_13: Space = unite(&(v753_8),&(v753_12));
            join_wrapped_into(&mut v752_7_write,&((v753_13).read_zipper()),&[]);
            }
            v748_23_cursor.ascend(1);
          }
          drop(v752_7_write);
          compose(&(v751_5),&(v752_7))
        };
        drop(v751_5);
        let v751_9: Space = intersect(&(*CONSTANT_12),&(v751_2));
        drop(v751_2);
        let v751_10: Space = if has_head(&(v751_9)) { singleton(&[]) } else { Space::new() };
        drop(v751_9);
        let v751_12: Space = if (&(v751_10)).is_empty() { Space::new() } else {
          let mut v756_11 = Space::new();
          let mut v756_11_write = v756_11.write_zipper();
          for v756_11_byte in v748_23_cursor.child_mask().iter() {
            v748_23_cursor.descend_to_existing_byte(v756_11_byte);
            {
            let v757_2: Space = singleton(&v748_23_cursor.path()[(v748_23_origin + 2)..(v748_23_origin + 3)]);
            let v757_3: Space = intersect(&(*CONSTANT_12),&(v757_2));
            let v757_4: Space = if has_head(&(v757_3)) { singleton(&[]) } else { Space::new() };
            drop(v757_3);
            let v757_5: Space = subtract(&(*CONSTANT_0),&(v757_4));
            drop(v757_4);
            let v757_8: Space = if (&(v757_5)).is_empty() { Space::new() } else {
              let v758_7: Space = routine_41(c, &v748_23_cursor.path()[v748_23_origin..(v748_23_origin + 3)], &v748_23_cursor);
              compose(&(v757_5),&(v758_7))
            };
            drop(v757_5);
            let v757_9: Space = intersect(&(*CONSTANT_12),&(v757_2));
            drop(v757_2);
            let v757_10: Space = if has_head(&(v757_9)) { singleton(&[]) } else { Space::new() };
            drop(v757_9);
            let v757_12: Space = if (&(v757_10)).is_empty() { Space::new() } else {
              let v759_11: Space = routine_43(c, &v748_23_cursor.path()[v748_23_origin..(v748_23_origin + 3)], &v748_23_cursor);
              compose(&(v757_10),&(v759_11))
            };
            drop(v757_10);
            let v757_13: Space = unite(&(v757_8),&(v757_12));
            join_wrapped_into(&mut v756_11_write,&((v757_13).read_zipper()),&[]);
            }
            v748_23_cursor.ascend(1);
          }
          drop(v756_11_write);
          compose(&(v751_10),&(v756_11))
        };
        drop(v751_10);
        let v751_13: Space = unite(&(v751_8),&(v751_12));
        join_wrapped_into(&mut v750_6_write,&((v751_13).read_zipper()),&[]);
        }
        v748_23_cursor.ascend(1);
      }
      drop(v750_6_write);
      compose(&(v749_5),&(v750_6))
    };
    drop(v749_5);
    let v749_8: Space = intersect(&(*CONSTANT_12),&(v749_2));
    drop(v749_2);
    let v749_9: Space = if has_head(&(v749_8)) { singleton(&[]) } else { Space::new() };
    drop(v749_8);
    let v749_11: Space = if (&(v749_9)).is_empty() { Space::new() } else {
      let mut v760_10 = Space::new();
      let mut v760_10_write = v760_10.write_zipper();
      for v760_10_byte in v748_23_cursor.child_mask().iter() {
        v748_23_cursor.descend_to_existing_byte(v760_10_byte);
        {
        let v761_2: Space = singleton(&v748_23_cursor.path()[(v748_23_origin + 1)..(v748_23_origin + 2)]);
        let v761_3: Space = intersect(&(*CONSTANT_12),&(v761_2));
        let v761_4: Space = if has_head(&(v761_3)) { singleton(&[]) } else { Space::new() };
        drop(v761_3);
        let v761_5: Space = subtract(&(*CONSTANT_0),&(v761_4));
        drop(v761_4);
        let v761_8: Space = if (&(v761_5)).is_empty() { Space::new() } else {
          let mut v762_7 = Space::new();
          let mut v762_7_write = v762_7.write_zipper();
          for v762_7_byte in v748_23_cursor.child_mask().iter() {
            v748_23_cursor.descend_to_existing_byte(v762_7_byte);
            {
            let v763_2: Space = singleton(&v748_23_cursor.path()[(v748_23_origin + 2)..(v748_23_origin + 3)]);
            let v763_3: Space = intersect(&(*CONSTANT_12),&(v763_2));
            let v763_4: Space = if has_head(&(v763_3)) { singleton(&[]) } else { Space::new() };
            drop(v763_3);
            let v763_5: Space = subtract(&(*CONSTANT_0),&(v763_4));
            drop(v763_4);
            let v763_8: Space = if (&(v763_5)).is_empty() { Space::new() } else {
              let v764_7: Space = routine_41(c, &v748_23_cursor.path()[v748_23_origin..(v748_23_origin + 3)], &v748_23_cursor);
              compose(&(v763_5),&(v764_7))
            };
            drop(v763_5);
            let v763_9: Space = intersect(&(*CONSTANT_12),&(v763_2));
            drop(v763_2);
            let v763_10: Space = if has_head(&(v763_9)) { singleton(&[]) } else { Space::new() };
            drop(v763_9);
            let v763_12: Space = if (&(v763_10)).is_empty() { Space::new() } else {
              let v765_11: Space = routine_42(c, &v748_23_cursor.path()[v748_23_origin..(v748_23_origin + 3)], &v748_23_cursor);
              compose(&(v763_10),&(v765_11))
            };
            drop(v763_10);
            let v763_13: Space = unite(&(v763_8),&(v763_12));
            join_wrapped_into(&mut v762_7_write,&((v763_13).read_zipper()),&[]);
            }
            v748_23_cursor.ascend(1);
          }
          drop(v762_7_write);
          compose(&(v761_5),&(v762_7))
        };
        drop(v761_5);
        let v761_9: Space = intersect(&(*CONSTANT_12),&(v761_2));
        drop(v761_2);
        let v761_10: Space = if has_head(&(v761_9)) { singleton(&[]) } else { Space::new() };
        drop(v761_9);
        let v761_11: Space = compose(&(v761_10),&v748_23_cursor);
        drop(v761_10);
        let v761_12: Space = unite(&(v761_8),&(v761_11));
        drop(v761_11);
        join_wrapped_into(&mut v760_10_write,&((v761_12).read_zipper()),&[]);
        }
        v748_23_cursor.ascend(1);
      }
      drop(v760_10_write);
      compose(&(v749_9),&(v760_10))
    };
    drop(v749_9);
    let v749_12: Space = unite(&(v749_7),&(v749_11));
    join_wrapped_into(&mut v748_23_write,&((v749_12).read_zipper()),&[]);
    }
    v748_23_cursor.ascend(1);
  }
  drop(v748_23_cursor);
  drop(v748_23_write);
  drop(v748_4);
  let v748_24: Space = unite(&(v748_23),&(*s2));
  let v748_25: Space = intersect(&(v748_24),&(*s1));
  let mut v748_44: Space = (v748_25).clone();
  loop {
    let v766_1: Space = intersect(&(v748_44),&(*s1));
    let v766_2: Space = restrict_to(&(*s0),&(v766_1));
    drop(v766_1);
    let mut v766_3 = Space::new();
    let mut v766_3_write = v766_3.write_zipper();
    let mut v766_3_cursor = (v766_2).read_zipper();
    let v766_3_origin = v766_3_cursor.path().len();
    for v766_3_byte in v766_3_cursor.child_mask().iter() {
      v766_3_cursor.descend_to_existing_byte(v766_3_byte);
      {
      let v767_2: Space = singleton(&v766_3_cursor.path()[v766_3_origin..(v766_3_origin + 1)]);
      let v767_3: Space = intersect(&(*CONSTANT_12),&(v767_2));
      let v767_4: Space = if has_head(&(v767_3)) { singleton(&[]) } else { Space::new() };
      drop(v767_3);
      let v767_5: Space = subtract(&(*CONSTANT_0),&(v767_4));
      drop(v767_4);
      let v767_7: Space = if (&(v767_5)).is_empty() { Space::new() } else {
        let mut v768_6 = Space::new();
        let mut v768_6_write = v768_6.write_zipper();
        for v768_6_byte in v766_3_cursor.child_mask().iter() {
          v766_3_cursor.descend_to_existing_byte(v768_6_byte);
          {
          let v769_2: Space = singleton(&v766_3_cursor.path()[(v766_3_origin + 1)..(v766_3_origin + 2)]);
          let v769_3: Space = intersect(&(*CONSTANT_12),&(v769_2));
          let v769_4: Space = if has_head(&(v769_3)) { singleton(&[]) } else { Space::new() };
          drop(v769_3);
          let v769_5: Space = subtract(&(*CONSTANT_0),&(v769_4));
          drop(v769_4);
          let v769_8: Space = if (&(v769_5)).is_empty() { Space::new() } else {
            let mut v770_7 = Space::new();
            let mut v770_7_write = v770_7.write_zipper();
            for v770_7_byte in v766_3_cursor.child_mask().iter() {
              v766_3_cursor.descend_to_existing_byte(v770_7_byte);
              {
              let v771_2: Space = singleton(&v766_3_cursor.path()[(v766_3_origin + 2)..(v766_3_origin + 3)]);
              let v771_3: Space = intersect(&(*CONSTANT_12),&(v771_2));
              let v771_4: Space = if has_head(&(v771_3)) { singleton(&[]) } else { Space::new() };
              drop(v771_3);
              let v771_5: Space = subtract(&(*CONSTANT_0),&(v771_4));
              drop(v771_4);
              let v771_8: Space = if (&(v771_5)).is_empty() { Space::new() } else {
                let v772_7: Space = routine_41(c, &v766_3_cursor.path()[v766_3_origin..(v766_3_origin + 3)], &v766_3_cursor);
                compose(&(v771_5),&(v772_7))
              };
              drop(v771_5);
              let v771_9: Space = intersect(&(*CONSTANT_12),&(v771_2));
              drop(v771_2);
              let v771_10: Space = if has_head(&(v771_9)) { singleton(&[]) } else { Space::new() };
              drop(v771_9);
              let v771_12: Space = if (&(v771_10)).is_empty() { Space::new() } else {
                let v773_11: Space = routine_42(c, &v766_3_cursor.path()[v766_3_origin..(v766_3_origin + 3)], &v766_3_cursor);
                compose(&(v771_10),&(v773_11))
              };
              drop(v771_10);
              let v771_13: Space = unite(&(v771_8),&(v771_12));
              join_wrapped_into(&mut v770_7_write,&((v771_13).read_zipper()),&[]);
              }
              v766_3_cursor.ascend(1);
            }
            drop(v770_7_write);
            compose(&(v769_5),&(v770_7))
          };
          drop(v769_5);
          let v769_9: Space = intersect(&(*CONSTANT_12),&(v769_2));
          drop(v769_2);
          let v769_10: Space = if has_head(&(v769_9)) { singleton(&[]) } else { Space::new() };
          drop(v769_9);
          let v769_12: Space = if (&(v769_10)).is_empty() { Space::new() } else {
            let mut v774_11 = Space::new();
            let mut v774_11_write = v774_11.write_zipper();
            for v774_11_byte in v766_3_cursor.child_mask().iter() {
              v766_3_cursor.descend_to_existing_byte(v774_11_byte);
              {
              let v775_2: Space = singleton(&v766_3_cursor.path()[(v766_3_origin + 2)..(v766_3_origin + 3)]);
              let v775_3: Space = intersect(&(*CONSTANT_12),&(v775_2));
              let v775_4: Space = if has_head(&(v775_3)) { singleton(&[]) } else { Space::new() };
              drop(v775_3);
              let v775_5: Space = subtract(&(*CONSTANT_0),&(v775_4));
              drop(v775_4);
              let v775_8: Space = if (&(v775_5)).is_empty() { Space::new() } else {
                let v776_7: Space = routine_41(c, &v766_3_cursor.path()[v766_3_origin..(v766_3_origin + 3)], &v766_3_cursor);
                compose(&(v775_5),&(v776_7))
              };
              drop(v775_5);
              let v775_9: Space = intersect(&(*CONSTANT_12),&(v775_2));
              drop(v775_2);
              let v775_10: Space = if has_head(&(v775_9)) { singleton(&[]) } else { Space::new() };
              drop(v775_9);
              let v775_12: Space = if (&(v775_10)).is_empty() { Space::new() } else {
                let v777_11: Space = routine_43(c, &v766_3_cursor.path()[v766_3_origin..(v766_3_origin + 3)], &v766_3_cursor);
                compose(&(v775_10),&(v777_11))
              };
              drop(v775_10);
              let v775_13: Space = unite(&(v775_8),&(v775_12));
              join_wrapped_into(&mut v774_11_write,&((v775_13).read_zipper()),&[]);
              }
              v766_3_cursor.ascend(1);
            }
            drop(v774_11_write);
            compose(&(v769_10),&(v774_11))
          };
          drop(v769_10);
          let v769_13: Space = unite(&(v769_8),&(v769_12));
          join_wrapped_into(&mut v768_6_write,&((v769_13).read_zipper()),&[]);
          }
          v766_3_cursor.ascend(1);
        }
        drop(v768_6_write);
        compose(&(v767_5),&(v768_6))
      };
      drop(v767_5);
      let v767_8: Space = intersect(&(*CONSTANT_12),&(v767_2));
      drop(v767_2);
      let v767_9: Space = if has_head(&(v767_8)) { singleton(&[]) } else { Space::new() };
      drop(v767_8);
      let v767_11: Space = if (&(v767_9)).is_empty() { Space::new() } else {
        let mut v778_10 = Space::new();
        let mut v778_10_write = v778_10.write_zipper();
        for v778_10_byte in v766_3_cursor.child_mask().iter() {
          v766_3_cursor.descend_to_existing_byte(v778_10_byte);
          {
          let v779_2: Space = singleton(&v766_3_cursor.path()[(v766_3_origin + 1)..(v766_3_origin + 2)]);
          let v779_3: Space = intersect(&(*CONSTANT_12),&(v779_2));
          let v779_4: Space = if has_head(&(v779_3)) { singleton(&[]) } else { Space::new() };
          drop(v779_3);
          let v779_5: Space = subtract(&(*CONSTANT_0),&(v779_4));
          drop(v779_4);
          let v779_8: Space = if (&(v779_5)).is_empty() { Space::new() } else {
            let mut v780_7 = Space::new();
            let mut v780_7_write = v780_7.write_zipper();
            for v780_7_byte in v766_3_cursor.child_mask().iter() {
              v766_3_cursor.descend_to_existing_byte(v780_7_byte);
              {
              let v781_2: Space = singleton(&v766_3_cursor.path()[(v766_3_origin + 2)..(v766_3_origin + 3)]);
              let v781_3: Space = intersect(&(*CONSTANT_12),&(v781_2));
              let v781_4: Space = if has_head(&(v781_3)) { singleton(&[]) } else { Space::new() };
              drop(v781_3);
              let v781_5: Space = subtract(&(*CONSTANT_0),&(v781_4));
              drop(v781_4);
              let v781_8: Space = if (&(v781_5)).is_empty() { Space::new() } else {
                let v782_7: Space = routine_41(c, &v766_3_cursor.path()[v766_3_origin..(v766_3_origin + 3)], &v766_3_cursor);
                compose(&(v781_5),&(v782_7))
              };
              drop(v781_5);
              let v781_9: Space = intersect(&(*CONSTANT_12),&(v781_2));
              drop(v781_2);
              let v781_10: Space = if has_head(&(v781_9)) { singleton(&[]) } else { Space::new() };
              drop(v781_9);
              let v781_12: Space = if (&(v781_10)).is_empty() { Space::new() } else {
                let v783_11: Space = routine_42(c, &v766_3_cursor.path()[v766_3_origin..(v766_3_origin + 3)], &v766_3_cursor);
                compose(&(v781_10),&(v783_11))
              };
              drop(v781_10);
              let v781_13: Space = unite(&(v781_8),&(v781_12));
              join_wrapped_into(&mut v780_7_write,&((v781_13).read_zipper()),&[]);
              }
              v766_3_cursor.ascend(1);
            }
            drop(v780_7_write);
            compose(&(v779_5),&(v780_7))
          };
          drop(v779_5);
          let v779_9: Space = intersect(&(*CONSTANT_12),&(v779_2));
          drop(v779_2);
          let v779_10: Space = if has_head(&(v779_9)) { singleton(&[]) } else { Space::new() };
          drop(v779_9);
          let v779_11: Space = compose(&(v779_10),&v766_3_cursor);
          drop(v779_10);
          let v779_12: Space = unite(&(v779_8),&(v779_11));
          drop(v779_11);
          join_wrapped_into(&mut v778_10_write,&((v779_12).read_zipper()),&[]);
          }
          v766_3_cursor.ascend(1);
        }
        drop(v778_10_write);
        compose(&(v767_9),&(v778_10))
      };
      drop(v767_9);
      let v767_12: Space = unite(&(v767_7),&(v767_11));
      join_wrapped_into(&mut v766_3_write,&((v767_12).read_zipper()),&[]);
      }
      v766_3_cursor.ascend(1);
    }
    drop(v766_3_cursor);
    drop(v766_3_write);
    drop(v766_2);
    let v766_4: Space = unite(&(v766_3),&(v748_44));
    let v766_5: Space = intersect(&(v766_4),&(*s1));
    if !v748_44.join_into((v766_5).clone()).is_element() { break; }
  }
  let v748_45: Space = unite(&(*s2),&(v748_44));
  (v748_45).clone()
}

fn routine_39(c: &mut Context, s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>) -> Space {
  let v784_3: Space = if has_head(&(*s2)) { singleton(&[]) } else { Space::new() };
  let v784_4: Space = first_matching(&(*s2),&(*CONSTANT_0),false);
  let v784_5: Space = unite(&(v784_3),&(v784_4));
  drop(v784_3);
  drop(v784_4);
  let v784_8: Space = if (&(v784_5)).is_empty() { Space::new() } else {
    let v785_6: Space = routine_26(c, &(*s2));
    let v785_7: Space = subtract(&(*s2),&(v785_6));
    compose(&(v784_5),&(v785_7))
  };
  drop(v784_5);
  let v784_9: Space = subtract(&(*s2),&(v784_8));
  let mut v784_19 = Space::new();
  let mut v784_19_write = v784_19.write_zipper();
  let mut v784_19_cursor = (v784_9).read_zipper();
  let v784_19_origin = v784_19_cursor.path().len();
  for v784_19_byte in v784_19_cursor.child_mask().iter() {
    v784_19_cursor.descend_to_existing_byte(v784_19_byte);
    {
    let v786_2: Space = singleton(&v784_19_cursor.path()[v784_19_origin..(v784_19_origin + 1)]);
    let v786_3: Space = intersect(&(*CONSTANT_12),&(v786_2));
    let v786_4: Space = if has_head(&(v786_3)) { singleton(&[]) } else { Space::new() };
    drop(v786_3);
    let v786_5: Space = subtract(&(*CONSTANT_0),&(v786_4));
    drop(v786_4);
    let v786_7: Space = if (&(v786_5)).is_empty() { Space::new() } else {
      let mut v787_6 = Space::new();
      let mut v787_6_write = v787_6.write_zipper();
      for v787_6_byte in v784_19_cursor.child_mask().iter() {
        v784_19_cursor.descend_to_existing_byte(v787_6_byte);
        {
        let v788_2: Space = singleton(&v784_19_cursor.path()[(v784_19_origin + 1)..(v784_19_origin + 2)]);
        let v788_3: Space = intersect(&(*CONSTANT_12),&(v788_2));
        let v788_4: Space = if has_head(&(v788_3)) { singleton(&[]) } else { Space::new() };
        drop(v788_3);
        let v788_5: Space = subtract(&(*CONSTANT_0),&(v788_4));
        drop(v788_4);
        let v788_8: Space = if (&(v788_5)).is_empty() { Space::new() } else {
          let v789_7: Space = routine_44(c, &v784_19_cursor.path()[v784_19_origin..(v784_19_origin + 2)], &v784_19_cursor, &(*s1), &(*s0), &(*s2));
          compose(&(v788_5),&(v789_7))
        };
        drop(v788_5);
        let v788_9: Space = intersect(&(*CONSTANT_12),&(v788_2));
        drop(v788_2);
        let v788_10: Space = if has_head(&(v788_9)) { singleton(&[]) } else { Space::new() };
        drop(v788_9);
        let v788_12: Space = if (&(v788_10)).is_empty() { Space::new() } else {
          let v790_11: Space = routine_45(c, &v784_19_cursor.path()[v784_19_origin..(v784_19_origin + 2)], &v784_19_cursor, &(*s1), &(*s0), &(*s2));
          compose(&(v788_10),&(v790_11))
        };
        drop(v788_10);
        let v788_13: Space = unite(&(v788_8),&(v788_12));
        join_wrapped_into(&mut v787_6_write,&((v788_13).read_zipper()),&[]);
        }
        v784_19_cursor.ascend(1);
      }
      drop(v787_6_write);
      compose(&(v786_5),&(v787_6))
    };
    drop(v786_5);
    let v786_8: Space = intersect(&(*CONSTANT_12),&(v786_2));
    drop(v786_2);
    let v786_9: Space = if has_head(&(v786_8)) { singleton(&[]) } else { Space::new() };
    drop(v786_8);
    let v786_11: Space = if (&(v786_9)).is_empty() { Space::new() } else {
      let mut v791_10 = Space::new();
      let mut v791_10_write = v791_10.write_zipper();
      for v791_10_byte in v784_19_cursor.child_mask().iter() {
        v784_19_cursor.descend_to_existing_byte(v791_10_byte);
        {
        let v792_2: Space = singleton(&v784_19_cursor.path()[(v784_19_origin + 1)..(v784_19_origin + 2)]);
        let v792_3: Space = intersect(&(*CONSTANT_12),&(v792_2));
        let v792_4: Space = if has_head(&(v792_3)) { singleton(&[]) } else { Space::new() };
        drop(v792_3);
        let v792_5: Space = subtract(&(*CONSTANT_0),&(v792_4));
        drop(v792_4);
        let v792_8: Space = if (&(v792_5)).is_empty() { Space::new() } else {
          let v793_7: Space = routine_44(c, &v784_19_cursor.path()[v784_19_origin..(v784_19_origin + 2)], &v784_19_cursor, &(*s1), &(*s0), &(*s2));
          compose(&(v792_5),&(v793_7))
        };
        drop(v792_5);
        let v792_9: Space = intersect(&(*CONSTANT_12),&(v792_2));
        drop(v792_2);
        let v792_10: Space = if has_head(&(v792_9)) { singleton(&[]) } else { Space::new() };
        drop(v792_9);
        let v792_12: Space = if (&(v792_10)).is_empty() { Space::new() } else {
          let v794_11: Space = routine_37(c, &v784_19_cursor.path()[v784_19_origin..(v784_19_origin + 2)], &v784_19_cursor, &(*s1), &(*s0), &(*s2));
          compose(&(v792_10),&(v794_11))
        };
        drop(v792_10);
        let v792_13: Space = unite(&(v792_8),&(v792_12));
        join_wrapped_into(&mut v791_10_write,&((v792_13).read_zipper()),&[]);
        }
        v784_19_cursor.ascend(1);
      }
      drop(v791_10_write);
      compose(&(v786_9),&(v791_10))
    };
    drop(v786_9);
    let v786_12: Space = unite(&(v786_7),&(v786_11));
    join_wrapped_into(&mut v784_19_write,&((v786_12).read_zipper()),&[]);
    }
    v784_19_cursor.ascend(1);
  }
  drop(v784_19_cursor);
  drop(v784_19_write);
  (v784_19).clone()
}

fn routine_40(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v795_4: Space = first_matching(&(descend_cursor((*s0).read_zipper(),&(*p0))),&(*CONSTANT_0),false);
  let v795_5: Space = intersect(&(*CONSTANT_0),&(v795_4));
  let v795_6: Space = if has_head(&(v795_4)) { singleton(&[]) } else { Space::new() };
  let v795_7: Space = unite(&(v795_5),&(v795_6));
  drop(v795_5);
  let v795_9: Space = compose(&(v795_7),&(*CONSTANT_0));
  drop(v795_7);
  let v795_11: Space = subtract(&(*CONSTANT_0),&(v795_4));
  drop(v795_4);
  let v795_12: Space = subtract(&(v795_11),&(v795_6));
  drop(v795_6);
  drop(v795_11);
  let v795_16: Space = if (&(v795_12)).is_empty() { Space::new() } else {
    let v796_14: Space = first_fibonacci(&(descend_cursor((*s0).read_zipper(),&(*p0))),6,5,true);
    let mut v796_15 = Space::new();
    let mut v796_15_write = v796_15.write_zipper();
    let v796_15_arg_0: &[u8] = &(*CONSTANT_14);
    let v796_15_arg_2: &Space = &(&(descend_cursor((*s0).read_zipper(),&(*p0)))).make_map();
    let mut v796_15_cursor = (v796_14).read_zipper();
    let v796_15_origin = v796_15_cursor.path().len();
    let mut v796_15_more = v796_15_cursor.is_val() || next_value_within(&mut v796_15_cursor,v796_15_origin);
    while v796_15_more {
      {
      let v796_15_depth = v796_15_cursor.path().len();
      let v797_3: Space = routine_40(c, &v796_15_cursor.path()[v796_15_origin..v796_15_depth], &((*v796_15_arg_2).read_zipper()));
      join_wrapped_into(&mut v796_15_write,&((v797_3).read_zipper()),&[]);
      }
      v796_15_more = next_value_within(&mut v796_15_cursor,v796_15_origin);
    }
    drop(v796_15_cursor);
    drop(v796_15_write);
    drop(v796_14);
    compose(&(v795_12),&(v796_15))
  };
  drop(v795_12);
  let v795_17: Space = unite(&(v795_9),&(v795_16));
  drop(v795_9);
  let v795_18: Space = wrap(&(v795_17),&(*p0));
  (v795_18).clone()
}

fn routine_41(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v798_6 = Space::new();
  let mut v798_6_write = v798_6.write_zipper();
  let mut v798_6_cursor = (*s0).read_zipper();
  let v798_6_origin = v798_6_cursor.path().len();
  for v798_6_byte in v798_6_cursor.child_mask().iter() {
    v798_6_cursor.descend_to_existing_byte(v798_6_byte);
    {
    let v799_2: Space = singleton(&v798_6_cursor.path()[v798_6_origin..(v798_6_origin + 1)]);
    let v799_3: Space = intersect(&(*CONSTANT_12),&(v799_2));
    let v799_4: Space = if has_head(&(v799_3)) { singleton(&[]) } else { Space::new() };
    drop(v799_3);
    let v799_5: Space = subtract(&(*CONSTANT_0),&(v799_4));
    drop(v799_4);
    let v799_7: Space = if (&(v799_5)).is_empty() { Space::new() } else {
      let mut v800_6 = Space::new();
      let mut v800_6_write = v800_6.write_zipper();
      for v800_6_byte in v798_6_cursor.child_mask().iter() {
        v798_6_cursor.descend_to_existing_byte(v800_6_byte);
        {
        let v801_2: Space = Space::new();
        join_wrapped_into(&mut v800_6_write,&((v801_2).read_zipper()),&[]);
        }
        v798_6_cursor.ascend(1);
      }
      drop(v800_6_write);
      compose(&(v799_5),&(v800_6))
    };
    drop(v799_5);
    let v799_8: Space = intersect(&(*CONSTANT_12),&(v799_2));
    drop(v799_2);
    let v799_9: Space = if has_head(&(v799_8)) { singleton(&[]) } else { Space::new() };
    drop(v799_8);
    let v799_11: Space = if (&(v799_9)).is_empty() { Space::new() } else {
      let mut v802_10 = Space::new();
      let mut v802_10_write = v802_10.write_zipper();
      for v802_10_byte in v798_6_cursor.child_mask().iter() {
        v798_6_cursor.descend_to_existing_byte(v802_10_byte);
        {
        let v803_2: Space = singleton(&v798_6_cursor.path()[(v798_6_origin + 1)..(v798_6_origin + 2)]);
        let v803_3: Space = intersect(&(*CONSTANT_12),&(v803_2));
        drop(v803_2);
        let v803_4: Space = if has_head(&(v803_3)) { singleton(&[]) } else { Space::new() };
        drop(v803_3);
        let v803_5: Space = compose(&(v803_4),&v798_6_cursor);
        drop(v803_4);
        join_wrapped_into(&mut v802_10_write,&((v803_5).read_zipper()),&[]);
        }
        v798_6_cursor.ascend(1);
      }
      drop(v802_10_write);
      compose(&(v799_9),&(v802_10))
    };
    drop(v799_9);
    let v799_12: Space = unite(&(v799_7),&(v799_11));
    drop(v799_7);
    drop(v799_11);
    join_wrapped_into(&mut v798_6_write,&((v799_12).read_zipper()),&[]);
    }
    v798_6_cursor.ascend(1);
  }
  drop(v798_6_cursor);
  drop(v798_6_write);
  (v798_6).clone()
}

fn routine_42(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v804_5 = Space::new();
  let mut v804_5_write = v804_5.write_zipper();
  let mut v804_5_cursor = (*s0).read_zipper();
  let v804_5_origin = v804_5_cursor.path().len();
  for v804_5_byte in v804_5_cursor.child_mask().iter() {
    v804_5_cursor.descend_to_existing_byte(v804_5_byte);
    {
    let v805_2: Space = singleton(&v804_5_cursor.path()[v804_5_origin..(v804_5_origin + 1)]);
    let v805_3: Space = intersect(&(*CONSTANT_12),&(v805_2));
    let v805_4: Space = if has_head(&(v805_3)) { singleton(&[]) } else { Space::new() };
    drop(v805_3);
    let v805_5: Space = subtract(&(*CONSTANT_0),&(v805_4));
    drop(v805_4);
    let v805_7: Space = if (&(v805_5)).is_empty() { Space::new() } else {
      let mut v806_6 = Space::new();
      let mut v806_6_write = v806_6.write_zipper();
      for v806_6_byte in v804_5_cursor.child_mask().iter() {
        v804_5_cursor.descend_to_existing_byte(v806_6_byte);
        {
        let v807_2: Space = Space::new();
        join_wrapped_into(&mut v806_6_write,&((v807_2).read_zipper()),&[]);
        }
        v804_5_cursor.ascend(1);
      }
      drop(v806_6_write);
      compose(&(v805_5),&(v806_6))
    };
    drop(v805_5);
    let v805_8: Space = intersect(&(*CONSTANT_12),&(v805_2));
    drop(v805_2);
    let v805_9: Space = if has_head(&(v805_8)) { singleton(&[]) } else { Space::new() };
    drop(v805_8);
    let v805_10: Space = compose(&(v805_9),&v804_5_cursor);
    drop(v805_9);
    let v805_11: Space = unite(&(v805_7),&(v805_10));
    drop(v805_7);
    drop(v805_10);
    join_wrapped_into(&mut v804_5_write,&((v805_11).read_zipper()),&[]);
    }
    v804_5_cursor.ascend(1);
  }
  drop(v804_5_cursor);
  drop(v804_5_write);
  (v804_5).clone()
}

fn routine_43(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_44(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let mut v809_14 = Space::new();
  let mut v809_14_write = v809_14.write_zipper();
  let mut v809_14_cursor = (*s0).read_zipper();
  let v809_14_origin = v809_14_cursor.path().len();
  for v809_14_byte in v809_14_cursor.child_mask().iter() {
    v809_14_cursor.descend_to_existing_byte(v809_14_byte);
    {
    let v810_2: Space = singleton(&v809_14_cursor.path()[v809_14_origin..(v809_14_origin + 1)]);
    let v810_3: Space = intersect(&(*CONSTANT_12),&(v810_2));
    let v810_4: Space = if has_head(&(v810_3)) { singleton(&[]) } else { Space::new() };
    drop(v810_3);
    let v810_5: Space = subtract(&(*CONSTANT_0),&(v810_4));
    drop(v810_4);
    let v810_8: Space = if (&(v810_5)).is_empty() { Space::new() } else {
      let v811_6: Path = concat_path(&(*p0),&v809_14_cursor.path()[v809_14_origin..(v809_14_origin + 1)]);
      let mut v811_7 = Space::new();
      let mut v811_7_write = v811_7.write_zipper();
      for v811_7_byte in v809_14_cursor.child_mask().iter() {
        v809_14_cursor.descend_to_existing_byte(v811_7_byte);
        {
        let v812_2: Space = singleton(&v809_14_cursor.path()[(v809_14_origin + 1)..(v809_14_origin + 2)]);
        let v812_3: Space = intersect(&(*CONSTANT_12),&(v812_2));
        let v812_4: Space = if has_head(&(v812_3)) { singleton(&[]) } else { Space::new() };
        drop(v812_3);
        let v812_5: Space = subtract(&(*CONSTANT_0),&(v812_4));
        drop(v812_4);
        let v812_7: Space = if (&(v812_5)).is_empty() { Space::new() } else {
          let mut v813_6 = Space::new();
          let mut v813_6_write = v813_6.write_zipper();
          for v813_6_byte in v809_14_cursor.child_mask().iter() {
            v809_14_cursor.descend_to_existing_byte(v813_6_byte);
            {
            let v814_2: Space = Space::new();
            join_wrapped_into(&mut v813_6_write,&((v814_2).read_zipper()),&[]);
            }
            v809_14_cursor.ascend(1);
          }
          drop(v813_6_write);
          compose(&(v812_5),&(v813_6))
        };
        drop(v812_5);
        let v812_8: Space = intersect(&(*CONSTANT_12),&(v812_2));
        drop(v812_2);
        let v812_9: Space = if has_head(&(v812_8)) { singleton(&[]) } else { Space::new() };
        drop(v812_8);
        let v812_12: Space = if (&(v812_9)).is_empty() { Space::new() } else {
          let v815_10: Path = concat_path(&(v811_6),&v809_14_cursor.path()[(v809_14_origin + 1)..(v809_14_origin + 2)]);
          let v815_11: Space = routine_46(c, &(v815_10), &v809_14_cursor, &(*s1), &(*s2), &(*s3));
          drop(v815_10);
          compose(&(v812_9),&(v815_11))
        };
        drop(v812_9);
        let v812_13: Space = unite(&(v812_7),&(v812_12));
        drop(v812_7);
        join_wrapped_into(&mut v811_7_write,&((v812_13).read_zipper()),&[]);
        }
        v809_14_cursor.ascend(1);
      }
      drop(v811_7_write);
      compose(&(v810_5),&(v811_7))
    };
    drop(v810_5);
    let v810_9: Space = intersect(&(*CONSTANT_12),&(v810_2));
    drop(v810_2);
    let v810_10: Space = if has_head(&(v810_9)) { singleton(&[]) } else { Space::new() };
    drop(v810_9);
    let v810_12: Space = if (&(v810_10)).is_empty() { Space::new() } else {
      let v816_6: Path = concat_path(&(*p0),&v809_14_cursor.path()[v809_14_origin..(v809_14_origin + 1)]);
      let mut v816_11 = Space::new();
      let mut v816_11_write = v816_11.write_zipper();
      for v816_11_byte in v809_14_cursor.child_mask().iter() {
        v809_14_cursor.descend_to_existing_byte(v816_11_byte);
        {
        let v817_2: Space = singleton(&v809_14_cursor.path()[(v809_14_origin + 1)..(v809_14_origin + 2)]);
        let v817_3: Space = intersect(&(*CONSTANT_12),&(v817_2));
        let v817_4: Space = if has_head(&(v817_3)) { singleton(&[]) } else { Space::new() };
        drop(v817_3);
        let v817_5: Space = subtract(&(*CONSTANT_0),&(v817_4));
        drop(v817_4);
        let v817_7: Space = if (&(v817_5)).is_empty() { Space::new() } else {
          let mut v818_6 = Space::new();
          let mut v818_6_write = v818_6.write_zipper();
          for v818_6_byte in v809_14_cursor.child_mask().iter() {
            v809_14_cursor.descend_to_existing_byte(v818_6_byte);
            {
            let v819_2: Space = Space::new();
            join_wrapped_into(&mut v818_6_write,&((v819_2).read_zipper()),&[]);
            }
            v809_14_cursor.ascend(1);
          }
          drop(v818_6_write);
          compose(&(v817_5),&(v818_6))
        };
        drop(v817_5);
        let v817_8: Space = intersect(&(*CONSTANT_12),&(v817_2));
        drop(v817_2);
        let v817_9: Space = if has_head(&(v817_8)) { singleton(&[]) } else { Space::new() };
        drop(v817_8);
        let v817_12: Space = if (&(v817_9)).is_empty() { Space::new() } else {
          let v820_10: Path = concat_path(&(v816_6),&v809_14_cursor.path()[(v809_14_origin + 1)..(v809_14_origin + 2)]);
          let v820_11: Space = routine_37(c, &(v820_10), &v809_14_cursor, &(*s1), &(*s2), &(*s3));
          drop(v820_10);
          compose(&(v817_9),&(v820_11))
        };
        drop(v817_9);
        let v817_13: Space = unite(&(v817_7),&(v817_12));
        drop(v817_7);
        join_wrapped_into(&mut v816_11_write,&((v817_13).read_zipper()),&[]);
        }
        v809_14_cursor.ascend(1);
      }
      drop(v816_11_write);
      drop(v816_6);
      compose(&(v810_10),&(v816_11))
    };
    drop(v810_10);
    let v810_13: Space = unite(&(v810_8),&(v810_12));
    join_wrapped_into(&mut v809_14_write,&((v810_13).read_zipper()),&[]);
    }
    v809_14_cursor.ascend(1);
  }
  drop(v809_14_cursor);
  drop(v809_14_write);
  (v809_14).clone()
}

fn routine_45(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let mut v821_11 = Space::new();
  let mut v821_11_write = v821_11.write_zipper();
  let mut v821_11_cursor = (*s0).read_zipper();
  let v821_11_origin = v821_11_cursor.path().len();
  for v821_11_byte in v821_11_cursor.child_mask().iter() {
    v821_11_cursor.descend_to_existing_byte(v821_11_byte);
    {
    let v822_2: Space = singleton(&v821_11_cursor.path()[v821_11_origin..(v821_11_origin + 1)]);
    let v822_3: Space = intersect(&(*CONSTANT_12),&(v822_2));
    let v822_4: Space = if has_head(&(v822_3)) { singleton(&[]) } else { Space::new() };
    drop(v822_3);
    let v822_5: Space = subtract(&(*CONSTANT_0),&(v822_4));
    drop(v822_4);
    let v822_8: Space = if (&(v822_5)).is_empty() { Space::new() } else {
      let v823_6: Path = concat_path(&(*p0),&v821_11_cursor.path()[v821_11_origin..(v821_11_origin + 1)]);
      let mut v823_7 = Space::new();
      let mut v823_7_write = v823_7.write_zipper();
      for v823_7_byte in v821_11_cursor.child_mask().iter() {
        v821_11_cursor.descend_to_existing_byte(v823_7_byte);
        {
        let v824_2: Space = singleton(&v821_11_cursor.path()[(v821_11_origin + 1)..(v821_11_origin + 2)]);
        let v824_3: Space = intersect(&(*CONSTANT_12),&(v824_2));
        let v824_4: Space = if has_head(&(v824_3)) { singleton(&[]) } else { Space::new() };
        drop(v824_3);
        let v824_5: Space = subtract(&(*CONSTANT_0),&(v824_4));
        drop(v824_4);
        let v824_7: Space = if (&(v824_5)).is_empty() { Space::new() } else {
          let mut v825_6 = Space::new();
          let mut v825_6_write = v825_6.write_zipper();
          for v825_6_byte in v821_11_cursor.child_mask().iter() {
            v821_11_cursor.descend_to_existing_byte(v825_6_byte);
            {
            let v826_2: Space = Space::new();
            join_wrapped_into(&mut v825_6_write,&((v826_2).read_zipper()),&[]);
            }
            v821_11_cursor.ascend(1);
          }
          drop(v825_6_write);
          compose(&(v824_5),&(v825_6))
        };
        drop(v824_5);
        let v824_8: Space = intersect(&(*CONSTANT_12),&(v824_2));
        drop(v824_2);
        let v824_9: Space = if has_head(&(v824_8)) { singleton(&[]) } else { Space::new() };
        drop(v824_8);
        let v824_12: Space = if (&(v824_9)).is_empty() { Space::new() } else {
          let v827_10: Path = concat_path(&(v823_6),&v821_11_cursor.path()[(v821_11_origin + 1)..(v821_11_origin + 2)]);
          let v827_11: Space = routine_46(c, &(v827_10), &v821_11_cursor, &(*s1), &(*s2), &(*s3));
          drop(v827_10);
          compose(&(v824_9),&(v827_11))
        };
        drop(v824_9);
        let v824_13: Space = unite(&(v824_7),&(v824_12));
        drop(v824_7);
        join_wrapped_into(&mut v823_7_write,&((v824_13).read_zipper()),&[]);
        }
        v821_11_cursor.ascend(1);
      }
      drop(v823_7_write);
      compose(&(v822_5),&(v823_7))
    };
    drop(v822_5);
    let v822_9: Space = intersect(&(*CONSTANT_12),&(v822_2));
    drop(v822_2);
    let v822_10: Space = if has_head(&(v822_9)) { singleton(&[]) } else { Space::new() };
    drop(v822_9);
    let v822_27: Space = if (&(v822_10)).is_empty() { Space::new() } else {
      let v828_6: Path = concat_path(&(*p0),&v821_11_cursor.path()[v821_11_origin..(v821_11_origin + 1)]);
      let v828_11: Space = singleton(&(v828_6));
      let v828_12: Space = routine_38(c, &(*s1), &(*s3), &((v828_11).read_zipper()));
      let v828_13: Space = routine_38(c, &(*s2), &(*s3), &((v828_11).read_zipper()));
      let v828_14: Space = intersect(&(v828_12),&(v828_13));
      let v828_15: Space = subtract(&(v828_14),&(v828_11));
      drop(v828_11);
      let v828_16: Space = wrap(&(v828_15),&(v828_6));
      drop(v828_6);
      let v828_17: Space = subtract(&(*s3),&(v828_13));
      let v828_18: Space = subtract(&(v828_17),&(v828_12));
      let v828_19: Space = routine_39(c, &(*s2), &(*s1), &((v828_18).read_zipper()));
      let v828_20: Space = unite(&(v828_16),&(v828_19));
      let v828_21: Space = subtract(&(v828_12),&(v828_13));
      let v828_22: Space = routine_39(c, &(*s2), &(*s1), &((v828_21).read_zipper()));
      let v828_23: Space = unite(&(v828_20),&(v828_22));
      let v828_24: Space = subtract(&(v828_13),&(v828_12));
      let v828_25: Space = routine_39(c, &(*s2), &(*s1), &((v828_24).read_zipper()));
      let v828_26: Space = unite(&(v828_23),&(v828_25));
      compose(&(v822_10),&(v828_26))
    };
    drop(v822_10);
    let v822_28: Space = unite(&(v822_8),&(v822_27));
    join_wrapped_into(&mut v821_11_write,&((v822_28).read_zipper()),&[]);
    }
    v821_11_cursor.ascend(1);
  }
  drop(v821_11_cursor);
  drop(v821_11_write);
  (v821_11).clone()
}

fn routine_46(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let mut v829_6 = Space::new();
  let mut v829_6_write = v829_6.write_zipper();
  let mut v829_6_cursor = (*s0).read_zipper();
  let v829_6_origin = v829_6_cursor.path().len();
  for v829_6_byte in v829_6_cursor.child_mask().iter() {
    v829_6_cursor.descend_to_existing_byte(v829_6_byte);
    {
    let v830_2: Space = singleton(&v829_6_cursor.path()[v829_6_origin..(v829_6_origin + 1)]);
    let v830_3: Space = intersect(&(*CONSTANT_12),&(v830_2));
    drop(v830_2);
    let v830_4: Space = if has_head(&(v830_3)) { singleton(&[]) } else { Space::new() };
    drop(v830_3);
    let v830_22: Space = if (&(v830_4)).is_empty() { Space::new() } else {
      let v831_5: Path = concat_path(&(*p0),&v829_6_cursor.path()[v829_6_origin..(v829_6_origin + 1)]);
      let v831_6: Space = singleton(&(v831_5));
      let v831_7: Space = routine_38(c, &(*s1), &(*s3), &((v831_6).read_zipper()));
      let v831_8: Space = routine_38(c, &(*s2), &(*s3), &((v831_6).read_zipper()));
      let v831_9: Space = intersect(&(v831_7),&(v831_8));
      let v831_10: Space = subtract(&(v831_9),&(v831_6));
      drop(v831_6);
      let v831_11: Space = wrap(&(v831_10),&(v831_5));
      drop(v831_5);
      let v831_12: Space = subtract(&(*s3),&(v831_8));
      let v831_13: Space = subtract(&(v831_12),&(v831_7));
      let v831_14: Space = routine_39(c, &(*s2), &(*s1), &((v831_13).read_zipper()));
      let v831_15: Space = unite(&(v831_11),&(v831_14));
      let v831_16: Space = subtract(&(v831_7),&(v831_8));
      let v831_17: Space = routine_39(c, &(*s2), &(*s1), &((v831_16).read_zipper()));
      let v831_18: Space = unite(&(v831_15),&(v831_17));
      let v831_19: Space = subtract(&(v831_8),&(v831_7));
      let v831_20: Space = routine_39(c, &(*s2), &(*s1), &((v831_19).read_zipper()));
      let v831_21: Space = unite(&(v831_18),&(v831_20));
      compose(&(v830_4),&(v831_21))
    };
    drop(v830_4);
    join_wrapped_into(&mut v829_6_write,&((v830_22).read_zipper()),&[]);
    }
    v829_6_cursor.ascend(1);
  }
  drop(v829_6_cursor);
  drop(v829_6_write);
  (v829_6).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
