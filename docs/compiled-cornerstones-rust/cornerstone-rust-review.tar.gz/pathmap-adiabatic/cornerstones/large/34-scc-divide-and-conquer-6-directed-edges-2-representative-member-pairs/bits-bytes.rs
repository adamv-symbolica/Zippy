#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 1 1 1 0 0 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1]));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 1 1 0 1 1"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,1]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 1 0 0 1 1"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1,1]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 0 1 1 2 1 1"));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 2 1 1"));
static CONSTANT_10: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0]));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_13: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 10 0 0 0 1 1 1 0 0 1 1 8 0 0 1 1 1 0 1 1 7 0 1 1 0 0 1 1 5 0 1 1 1 1 8 1 0 1 1 0 0 1 1 5 1 1 0 1 1"));
static CONSTANT_14: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
#[inline(never)]
fn native_block_0(c: &mut Context) -> (Space,Space,Space,Space,Space,Space,) {
  let v0_22: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v1_19: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
      let v2_18: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v3_5: Space = routine_1(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
        let v3_8: Space = routine_2(c, &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
        let v3_9: Space = unite(&(v3_5),&(v3_8));
        let v3_12: Space = routine_2(c, &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
        let v3_13: Space = unite(&(v3_9),&(v3_12));
        let v3_16: Space = routine_3(c, &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
        let v3_17: Space = unite(&(v3_13),&(v3_16));
        compose(&(*CONSTANT_0),&(v3_17))
      };
      compose(&(*CONSTANT_0),&(v2_18))
    };
    let v1_21: Space = unite(&(v1_19),&(*CONSTANT_9));
    compose(&(*CONSTANT_0),&(v1_21))
  };
  let v0_44: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
    let v4_43: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
      let v5_42: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v6_29: Space = routine_4(c, &(*CONSTANT_10), &(*CONSTANT_11), &((*CONSTANT_9).read_zipper()));
        let v6_31: Space = routine_5(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
        let v6_32: Space = unite(&(v6_29),&(v6_31));
        let v6_34: Space = routine_6(c, &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
        let v6_35: Space = unite(&(v6_32),&(v6_34));
        let v6_37: Space = routine_6(c, &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
        let v6_38: Space = unite(&(v6_35),&(v6_37));
        let v6_40: Space = routine_7(c, &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
        let v6_41: Space = unite(&(v6_38),&(v6_40));
        compose(&(*CONSTANT_0),&(v6_41))
      };
      compose(&(*CONSTANT_0),&(v5_42))
    };
    compose(&(*CONSTANT_0),&(v4_43))
  };
  let mut v0_63 = Space::new();
  let mut v0_63_write = v0_63.write_zipper();
  let mut v0_63_cursor = (v0_44).read_zipper();
  let v0_63_origin = v0_63_cursor.path().len();
  for v0_63_byte in v0_63_cursor.child_mask().iter() {
    v0_63_cursor.descend_to_existing_byte(v0_63_byte);
    {
    let v7_2: Space = singleton(&v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 1)]);
    let v7_3: Space = intersect(&(*CONSTANT_12),&(v7_2));
    let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
    drop(v7_3);
    let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
    drop(v7_4);
    let v7_7: Space = if (&(v7_5)).is_empty() { Space::new() } else {
      let mut v8_6 = Space::new();
      let mut v8_6_write = v8_6.write_zipper();
      for v8_6_byte in v0_63_cursor.child_mask().iter() {
        v0_63_cursor.descend_to_existing_byte(v8_6_byte);
        {
        let v9_2: Space = singleton(&v0_63_cursor.path()[(v0_63_origin + 1)..(v0_63_origin + 2)]);
        let v9_3: Space = intersect(&(*CONSTANT_12),&(v9_2));
        let v9_4: Space = if has_head(&(v9_3)) { singleton(&[]) } else { Space::new() };
        drop(v9_3);
        let v9_5: Space = subtract(&(*CONSTANT_0),&(v9_4));
        drop(v9_4);
        let v9_8: Space = if (&(v9_5)).is_empty() { Space::new() } else {
          let mut v10_7 = Space::new();
          let mut v10_7_write = v10_7.write_zipper();
          for v10_7_byte in v0_63_cursor.child_mask().iter() {
            v0_63_cursor.descend_to_existing_byte(v10_7_byte);
            {
            let v11_2: Space = singleton(&v0_63_cursor.path()[(v0_63_origin + 2)..(v0_63_origin + 3)]);
            let v11_3: Space = intersect(&(*CONSTANT_12),&(v11_2));
            let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
            drop(v11_3);
            let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
            drop(v11_4);
            let v11_8: Space = if (&(v11_5)).is_empty() { Space::new() } else {
              let v12_7: Space = routine_8(c, &v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 3)], &v0_63_cursor);
              compose(&(v11_5),&(v12_7))
            };
            drop(v11_5);
            let v11_9: Space = intersect(&(*CONSTANT_12),&(v11_2));
            drop(v11_2);
            let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
            drop(v11_9);
            let v11_12: Space = if (&(v11_10)).is_empty() { Space::new() } else {
              let v13_11: Space = routine_9(c, &v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 3)], &v0_63_cursor);
              compose(&(v11_10),&(v13_11))
            };
            drop(v11_10);
            let v11_13: Space = unite(&(v11_8),&(v11_12));
            join_wrapped_into(&mut v10_7_write,&((v11_13).read_zipper()),&[]);
            }
            v0_63_cursor.ascend(1);
          }
          drop(v10_7_write);
          compose(&(v9_5),&(v10_7))
        };
        drop(v9_5);
        let v9_9: Space = intersect(&(*CONSTANT_12),&(v9_2));
        drop(v9_2);
        let v9_10: Space = if has_head(&(v9_9)) { singleton(&[]) } else { Space::new() };
        drop(v9_9);
        let v9_12: Space = if (&(v9_10)).is_empty() { Space::new() } else {
          let mut v14_11 = Space::new();
          let mut v14_11_write = v14_11.write_zipper();
          for v14_11_byte in v0_63_cursor.child_mask().iter() {
            v0_63_cursor.descend_to_existing_byte(v14_11_byte);
            {
            let v15_2: Space = singleton(&v0_63_cursor.path()[(v0_63_origin + 2)..(v0_63_origin + 3)]);
            let v15_3: Space = intersect(&(*CONSTANT_12),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (&(v15_5)).is_empty() { Space::new() } else {
              let v16_7: Space = routine_8(c, &v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 3)], &v0_63_cursor);
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_12),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (&(v15_10)).is_empty() { Space::new() } else {
              let v17_11: Space = routine_10(c, &v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 3)], &v0_63_cursor);
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            join_wrapped_into(&mut v14_11_write,&((v15_13).read_zipper()),&[]);
            }
            v0_63_cursor.ascend(1);
          }
          drop(v14_11_write);
          compose(&(v9_10),&(v14_11))
        };
        drop(v9_10);
        let v9_13: Space = unite(&(v9_8),&(v9_12));
        join_wrapped_into(&mut v8_6_write,&((v9_13).read_zipper()),&[]);
        }
        v0_63_cursor.ascend(1);
      }
      drop(v8_6_write);
      compose(&(v7_5),&(v8_6))
    };
    drop(v7_5);
    let v7_8: Space = intersect(&(*CONSTANT_12),&(v7_2));
    drop(v7_2);
    let v7_9: Space = if has_head(&(v7_8)) { singleton(&[]) } else { Space::new() };
    drop(v7_8);
    let v7_11: Space = if (&(v7_9)).is_empty() { Space::new() } else {
      let mut v18_10 = Space::new();
      let mut v18_10_write = v18_10.write_zipper();
      for v18_10_byte in v0_63_cursor.child_mask().iter() {
        v0_63_cursor.descend_to_existing_byte(v18_10_byte);
        {
        let v19_2: Space = singleton(&v0_63_cursor.path()[(v0_63_origin + 1)..(v0_63_origin + 2)]);
        let v19_3: Space = intersect(&(*CONSTANT_12),&(v19_2));
        let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
        drop(v19_3);
        let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
        drop(v19_4);
        let v19_8: Space = if (&(v19_5)).is_empty() { Space::new() } else {
          let mut v20_7 = Space::new();
          let mut v20_7_write = v20_7.write_zipper();
          for v20_7_byte in v0_63_cursor.child_mask().iter() {
            v0_63_cursor.descend_to_existing_byte(v20_7_byte);
            {
            let v21_2: Space = singleton(&v0_63_cursor.path()[(v0_63_origin + 2)..(v0_63_origin + 3)]);
            let v21_3: Space = intersect(&(*CONSTANT_12),&(v21_2));
            let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
            drop(v21_3);
            let v21_5: Space = subtract(&(*CONSTANT_0),&(v21_4));
            drop(v21_4);
            let v21_8: Space = if (&(v21_5)).is_empty() { Space::new() } else {
              let v22_7: Space = routine_8(c, &v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 3)], &v0_63_cursor);
              compose(&(v21_5),&(v22_7))
            };
            drop(v21_5);
            let v21_9: Space = intersect(&(*CONSTANT_12),&(v21_2));
            drop(v21_2);
            let v21_10: Space = if has_head(&(v21_9)) { singleton(&[]) } else { Space::new() };
            drop(v21_9);
            let v21_12: Space = if (&(v21_10)).is_empty() { Space::new() } else {
              let v23_11: Space = routine_9(c, &v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 3)], &v0_63_cursor);
              compose(&(v21_10),&(v23_11))
            };
            drop(v21_10);
            let v21_13: Space = unite(&(v21_8),&(v21_12));
            join_wrapped_into(&mut v20_7_write,&((v21_13).read_zipper()),&[]);
            }
            v0_63_cursor.ascend(1);
          }
          drop(v20_7_write);
          compose(&(v19_5),&(v20_7))
        };
        drop(v19_5);
        let v19_9: Space = intersect(&(*CONSTANT_12),&(v19_2));
        drop(v19_2);
        let v19_10: Space = if has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
        drop(v19_9);
        let v19_12: Space = if (&(v19_10)).is_empty() { Space::new() } else {
          let v24_11: Space = singleton(&v0_63_cursor.path()[v0_63_origin..(v0_63_origin + 2)]);
          compose(&(v19_10),&(v24_11))
        };
        drop(v19_10);
        let v19_13: Space = unite(&(v19_8),&(v19_12));
        drop(v19_12);
        join_wrapped_into(&mut v18_10_write,&((v19_13).read_zipper()),&[]);
        }
        v0_63_cursor.ascend(1);
      }
      drop(v18_10_write);
      compose(&(v7_9),&(v18_10))
    };
    drop(v7_9);
    let v7_12: Space = unite(&(v7_7),&(v7_11));
    join_wrapped_into(&mut v0_63_write,&((v7_12).read_zipper()),&[]);
    }
    v0_63_cursor.ascend(1);
  }
  drop(v0_63_cursor);
  drop(v0_63_write);
  let v0_64: Space = unite(&(v0_22),&(v0_63));
  let v0_65: Space = routine_11(c, &((v0_64).read_zipper()));
  let mut v0_155 = Space::new();
  let mut v0_155_write = v0_155.write_zipper();
  let mut v0_155_cursor = (v0_65).read_zipper();
  let v0_155_origin = v0_155_cursor.path().len();
  for v0_155_byte in v0_155_cursor.child_mask().iter() {
    v0_155_cursor.descend_to_existing_byte(v0_155_byte);
    {
    let v25_2: Space = singleton(&v0_155_cursor.path()[v0_155_origin..(v0_155_origin + 1)]);
    let v25_3: Space = intersect(&(*CONSTANT_12),&(v25_2));
    let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
    drop(v25_3);
    let v25_5: Space = subtract(&(*CONSTANT_0),&(v25_4));
    drop(v25_4);
    let v25_44: Space = if (&(v25_5)).is_empty() { Space::new() } else {
      let v26_17: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v27_16: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
          let v28_15: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
            let v29_6: Space = routine_12(c, &(*CONSTANT_10), &(*CONSTANT_11), &((*CONSTANT_9).read_zipper()));
            let v29_7: Space = routine_13(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
            let v29_8: Space = unite(&(v29_6),&(v29_7));
            let v29_9: Space = routine_14(c, &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
            let v29_10: Space = unite(&(v29_8),&(v29_9));
            let v29_11: Space = routine_14(c, &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
            let v29_12: Space = unite(&(v29_10),&(v29_11));
            let v29_13: Space = routine_15(c, &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
            let v29_14: Space = unite(&(v29_12),&(v29_13));
            compose(&(*CONSTANT_0),&(v29_14))
          };
          compose(&(*CONSTANT_0),&(v28_15))
        };
        compose(&(*CONSTANT_0),&(v27_16))
      };
      let v26_28: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v30_26: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
          let v31_25: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
            let v32_18: Space = routine_1(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
            let v32_19: Space = routine_2(c, &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
            let v32_20: Space = unite(&(v32_18),&(v32_19));
            let v32_21: Space = routine_2(c, &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
            let v32_22: Space = unite(&(v32_20),&(v32_21));
            let v32_23: Space = routine_3(c, &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
            let v32_24: Space = unite(&(v32_22),&(v32_23));
            compose(&(*CONSTANT_0),&(v32_24))
          };
          compose(&(*CONSTANT_0),&(v31_25))
        };
        let v30_27: Space = unite(&(v30_26),&(*CONSTANT_9));
        compose(&(*CONSTANT_0),&(v30_27))
      };
      let v26_40: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v33_39: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
          let v34_38: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
            let v35_29: Space = routine_4(c, &(*CONSTANT_10), &(*CONSTANT_11), &((*CONSTANT_9).read_zipper()));
            let v35_30: Space = routine_5(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
            let v35_31: Space = unite(&(v35_29),&(v35_30));
            let v35_32: Space = routine_6(c, &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
            let v35_33: Space = unite(&(v35_31),&(v35_32));
            let v35_34: Space = routine_6(c, &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
            let v35_35: Space = unite(&(v35_33),&(v35_34));
            let v35_36: Space = routine_7(c, &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
            let v35_37: Space = unite(&(v35_35),&(v35_36));
            compose(&(*CONSTANT_0),&(v35_37))
          };
          compose(&(*CONSTANT_0),&(v34_38))
        };
        compose(&(*CONSTANT_0),&(v33_39))
      };
      let mut v26_41 = Space::new();
      let mut v26_41_write = v26_41.write_zipper();
      let mut v26_41_cursor = (v26_40).read_zipper();
      let v26_41_origin = v26_41_cursor.path().len();
      for v26_41_byte in v26_41_cursor.child_mask().iter() {
        v26_41_cursor.descend_to_existing_byte(v26_41_byte);
        {
        let v36_2: Space = singleton(&v26_41_cursor.path()[v26_41_origin..(v26_41_origin + 1)]);
        let v36_3: Space = intersect(&(*CONSTANT_12),&(v36_2));
        let v36_4: Space = if has_head(&(v36_3)) { singleton(&[]) } else { Space::new() };
        drop(v36_3);
        let v36_5: Space = subtract(&(*CONSTANT_0),&(v36_4));
        drop(v36_4);
        let v36_7: Space = if (&(v36_5)).is_empty() { Space::new() } else {
          let mut v37_6 = Space::new();
          let mut v37_6_write = v37_6.write_zipper();
          for v37_6_byte in v26_41_cursor.child_mask().iter() {
            v26_41_cursor.descend_to_existing_byte(v37_6_byte);
            {
            let v38_2: Space = singleton(&v26_41_cursor.path()[(v26_41_origin + 1)..(v26_41_origin + 2)]);
            let v38_3: Space = intersect(&(*CONSTANT_12),&(v38_2));
            let v38_4: Space = if has_head(&(v38_3)) { singleton(&[]) } else { Space::new() };
            drop(v38_3);
            let v38_5: Space = subtract(&(*CONSTANT_0),&(v38_4));
            drop(v38_4);
            let v38_8: Space = if (&(v38_5)).is_empty() { Space::new() } else {
              let mut v39_7 = Space::new();
              let mut v39_7_write = v39_7.write_zipper();
              for v39_7_byte in v26_41_cursor.child_mask().iter() {
                v26_41_cursor.descend_to_existing_byte(v39_7_byte);
                {
                let v40_2: Space = singleton(&v26_41_cursor.path()[(v26_41_origin + 2)..(v26_41_origin + 3)]);
                let v40_3: Space = intersect(&(*CONSTANT_12),&(v40_2));
                let v40_4: Space = if has_head(&(v40_3)) { singleton(&[]) } else { Space::new() };
                drop(v40_3);
                let v40_5: Space = subtract(&(*CONSTANT_0),&(v40_4));
                drop(v40_4);
                let v40_8: Space = if (&(v40_5)).is_empty() { Space::new() } else {
                  let v41_7: Space = routine_8(c, &v26_41_cursor.path()[v26_41_origin..(v26_41_origin + 3)], &v26_41_cursor);
                  compose(&(v40_5),&(v41_7))
                };
                drop(v40_5);
                let v40_9: Space = intersect(&(*CONSTANT_12),&(v40_2));
                drop(v40_2);
                let v40_10: Space = if has_head(&(v40_9)) { singleton(&[]) } else { Space::new() };
                drop(v40_9);
                let v40_12: Space = if (&(v40_10)).is_empty() { Space::new() } else {
                  let v42_11: Space = routine_9(c, &v26_41_cursor.path()[v26_41_origin..(v26_41_origin + 3)], &v26_41_cursor);
                  compose(&(v40_10),&(v42_11))
                };
                drop(v40_10);
                let v40_13: Space = unite(&(v40_8),&(v40_12));
                join_wrapped_into(&mut v39_7_write,&((v40_13).read_zipper()),&[]);
                }
                v26_41_cursor.ascend(1);
              }
              drop(v39_7_write);
              compose(&(v38_5),&(v39_7))
            };
            drop(v38_5);
            let v38_9: Space = intersect(&(*CONSTANT_12),&(v38_2));
            drop(v38_2);
            let v38_10: Space = if has_head(&(v38_9)) { singleton(&[]) } else { Space::new() };
            drop(v38_9);
            let v38_12: Space = if (&(v38_10)).is_empty() { Space::new() } else {
              let mut v43_11 = Space::new();
              let mut v43_11_write = v43_11.write_zipper();
              for v43_11_byte in v26_41_cursor.child_mask().iter() {
                v26_41_cursor.descend_to_existing_byte(v43_11_byte);
                {
                let v44_2: Space = singleton(&v26_41_cursor.path()[(v26_41_origin + 2)..(v26_41_origin + 3)]);
                let v44_3: Space = intersect(&(*CONSTANT_12),&(v44_2));
                let v44_4: Space = if has_head(&(v44_3)) { singleton(&[]) } else { Space::new() };
                drop(v44_3);
                let v44_5: Space = subtract(&(*CONSTANT_0),&(v44_4));
                drop(v44_4);
                let v44_8: Space = if (&(v44_5)).is_empty() { Space::new() } else {
                  let v45_7: Space = routine_8(c, &v26_41_cursor.path()[v26_41_origin..(v26_41_origin + 3)], &v26_41_cursor);
                  compose(&(v44_5),&(v45_7))
                };
                drop(v44_5);
                let v44_9: Space = intersect(&(*CONSTANT_12),&(v44_2));
                drop(v44_2);
                let v44_10: Space = if has_head(&(v44_9)) { singleton(&[]) } else { Space::new() };
                drop(v44_9);
                let v44_12: Space = if (&(v44_10)).is_empty() { Space::new() } else {
                  let v46_11: Space = routine_10(c, &v26_41_cursor.path()[v26_41_origin..(v26_41_origin + 3)], &v26_41_cursor);
                  compose(&(v44_10),&(v46_11))
                };
                drop(v44_10);
                let v44_13: Space = unite(&(v44_8),&(v44_12));
                join_wrapped_into(&mut v43_11_write,&((v44_13).read_zipper()),&[]);
                }
                v26_41_cursor.ascend(1);
              }
              drop(v43_11_write);
              compose(&(v38_10),&(v43_11))
            };
            drop(v38_10);
            let v38_13: Space = unite(&(v38_8),&(v38_12));
            join_wrapped_into(&mut v37_6_write,&((v38_13).read_zipper()),&[]);
            }
            v26_41_cursor.ascend(1);
          }
          drop(v37_6_write);
          compose(&(v36_5),&(v37_6))
        };
        drop(v36_5);
        let v36_8: Space = intersect(&(*CONSTANT_12),&(v36_2));
        drop(v36_2);
        let v36_9: Space = if has_head(&(v36_8)) { singleton(&[]) } else { Space::new() };
        drop(v36_8);
        let v36_11: Space = if (&(v36_9)).is_empty() { Space::new() } else {
          let mut v47_10 = Space::new();
          let mut v47_10_write = v47_10.write_zipper();
          for v47_10_byte in v26_41_cursor.child_mask().iter() {
            v26_41_cursor.descend_to_existing_byte(v47_10_byte);
            {
            let v48_2: Space = singleton(&v26_41_cursor.path()[(v26_41_origin + 1)..(v26_41_origin + 2)]);
            let v48_3: Space = intersect(&(*CONSTANT_12),&(v48_2));
            let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
            drop(v48_3);
            let v48_5: Space = subtract(&(*CONSTANT_0),&(v48_4));
            drop(v48_4);
            let v48_8: Space = if (&(v48_5)).is_empty() { Space::new() } else {
              let mut v49_7 = Space::new();
              let mut v49_7_write = v49_7.write_zipper();
              for v49_7_byte in v26_41_cursor.child_mask().iter() {
                v26_41_cursor.descend_to_existing_byte(v49_7_byte);
                {
                let v50_2: Space = singleton(&v26_41_cursor.path()[(v26_41_origin + 2)..(v26_41_origin + 3)]);
                let v50_3: Space = intersect(&(*CONSTANT_12),&(v50_2));
                let v50_4: Space = if has_head(&(v50_3)) { singleton(&[]) } else { Space::new() };
                drop(v50_3);
                let v50_5: Space = subtract(&(*CONSTANT_0),&(v50_4));
                drop(v50_4);
                let v50_8: Space = if (&(v50_5)).is_empty() { Space::new() } else {
                  let v51_7: Space = routine_8(c, &v26_41_cursor.path()[v26_41_origin..(v26_41_origin + 3)], &v26_41_cursor);
                  compose(&(v50_5),&(v51_7))
                };
                drop(v50_5);
                let v50_9: Space = intersect(&(*CONSTANT_12),&(v50_2));
                drop(v50_2);
                let v50_10: Space = if has_head(&(v50_9)) { singleton(&[]) } else { Space::new() };
                drop(v50_9);
                let v50_12: Space = if (&(v50_10)).is_empty() { Space::new() } else {
                  let v52_11: Space = routine_9(c, &v26_41_cursor.path()[v26_41_origin..(v26_41_origin + 3)], &v26_41_cursor);
                  compose(&(v50_10),&(v52_11))
                };
                drop(v50_10);
                let v50_13: Space = unite(&(v50_8),&(v50_12));
                join_wrapped_into(&mut v49_7_write,&((v50_13).read_zipper()),&[]);
                }
                v26_41_cursor.ascend(1);
              }
              drop(v49_7_write);
              compose(&(v48_5),&(v49_7))
            };
            drop(v48_5);
            let v48_9: Space = intersect(&(*CONSTANT_12),&(v48_2));
            drop(v48_2);
            let v48_10: Space = if has_head(&(v48_9)) { singleton(&[]) } else { Space::new() };
            drop(v48_9);
            let v48_12: Space = if (&(v48_10)).is_empty() { Space::new() } else {
              let v53_11: Space = singleton(&v26_41_cursor.path()[v26_41_origin..(v26_41_origin + 2)]);
              compose(&(v48_10),&(v53_11))
            };
            drop(v48_10);
            let v48_13: Space = unite(&(v48_8),&(v48_12));
            drop(v48_12);
            join_wrapped_into(&mut v47_10_write,&((v48_13).read_zipper()),&[]);
            }
            v26_41_cursor.ascend(1);
          }
          drop(v47_10_write);
          compose(&(v36_9),&(v47_10))
        };
        drop(v36_9);
        let v36_12: Space = unite(&(v36_7),&(v36_11));
        join_wrapped_into(&mut v26_41_write,&((v36_12).read_zipper()),&[]);
        }
        v26_41_cursor.ascend(1);
      }
      drop(v26_41_cursor);
      drop(v26_41_write);
      let v26_42: Space = unite(&(v26_28),&(v26_41));
      let v26_43: Space = routine_16(c, &v0_155_cursor.path()[v0_155_origin..(v0_155_origin + 1)], &v0_155_cursor, &((v26_17).read_zipper()), &((*CONSTANT_13).read_zipper()), &((v26_42).read_zipper()));
      compose(&(v25_5),&(v26_43))
    };
    drop(v25_5);
    let v25_45: Space = intersect(&(*CONSTANT_12),&(v25_2));
    drop(v25_2);
    let v25_46: Space = if has_head(&(v25_45)) { singleton(&[]) } else { Space::new() };
    drop(v25_45);
    let v25_85: Space = if (&(v25_46)).is_empty() { Space::new() } else {
      let v54_58: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v55_57: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
          let v56_56: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
            let v57_47: Space = routine_12(c, &(*CONSTANT_10), &(*CONSTANT_11), &((*CONSTANT_9).read_zipper()));
            let v57_48: Space = routine_13(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
            let v57_49: Space = unite(&(v57_47),&(v57_48));
            let v57_50: Space = routine_14(c, &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
            let v57_51: Space = unite(&(v57_49),&(v57_50));
            let v57_52: Space = routine_14(c, &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
            let v57_53: Space = unite(&(v57_51),&(v57_52));
            let v57_54: Space = routine_15(c, &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
            let v57_55: Space = unite(&(v57_53),&(v57_54));
            compose(&(*CONSTANT_0),&(v57_55))
          };
          compose(&(*CONSTANT_0),&(v56_56))
        };
        compose(&(*CONSTANT_0),&(v55_57))
      };
      let v54_69: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v58_67: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
          let v59_66: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
            let v60_59: Space = routine_1(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
            let v60_60: Space = routine_2(c, &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
            let v60_61: Space = unite(&(v60_59),&(v60_60));
            let v60_62: Space = routine_2(c, &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
            let v60_63: Space = unite(&(v60_61),&(v60_62));
            let v60_64: Space = routine_3(c, &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
            let v60_65: Space = unite(&(v60_63),&(v60_64));
            compose(&(*CONSTANT_0),&(v60_65))
          };
          compose(&(*CONSTANT_0),&(v59_66))
        };
        let v58_68: Space = unite(&(v58_67),&(*CONSTANT_9));
        compose(&(*CONSTANT_0),&(v58_68))
      };
      let v54_81: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
        let v61_80: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
          let v62_79: Space = if (&(*CONSTANT_0)).is_empty() { Space::new() } else {
            let v63_70: Space = routine_4(c, &(*CONSTANT_10), &(*CONSTANT_11), &((*CONSTANT_9).read_zipper()));
            let v63_71: Space = routine_5(c, &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
            let v63_72: Space = unite(&(v63_70),&(v63_71));
            let v63_73: Space = routine_6(c, &(*CONSTANT_3), &((*CONSTANT_4).read_zipper()));
            let v63_74: Space = unite(&(v63_72),&(v63_73));
            let v63_75: Space = routine_6(c, &(*CONSTANT_5), &((*CONSTANT_6).read_zipper()));
            let v63_76: Space = unite(&(v63_74),&(v63_75));
            let v63_77: Space = routine_7(c, &(*CONSTANT_7), &((*CONSTANT_8).read_zipper()));
            let v63_78: Space = unite(&(v63_76),&(v63_77));
            compose(&(*CONSTANT_0),&(v63_78))
          };
          compose(&(*CONSTANT_0),&(v62_79))
        };
        compose(&(*CONSTANT_0),&(v61_80))
      };
      let mut v54_82 = Space::new();
      let mut v54_82_write = v54_82.write_zipper();
      let mut v54_82_cursor = (v54_81).read_zipper();
      let v54_82_origin = v54_82_cursor.path().len();
      for v54_82_byte in v54_82_cursor.child_mask().iter() {
        v54_82_cursor.descend_to_existing_byte(v54_82_byte);
        {
        let v64_2: Space = singleton(&v54_82_cursor.path()[v54_82_origin..(v54_82_origin + 1)]);
        let v64_3: Space = intersect(&(*CONSTANT_12),&(v64_2));
        let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
        drop(v64_3);
        let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
        drop(v64_4);
        let v64_7: Space = if (&(v64_5)).is_empty() { Space::new() } else {
          let mut v65_6 = Space::new();
          let mut v65_6_write = v65_6.write_zipper();
          for v65_6_byte in v54_82_cursor.child_mask().iter() {
            v54_82_cursor.descend_to_existing_byte(v65_6_byte);
            {
            let v66_2: Space = singleton(&v54_82_cursor.path()[(v54_82_origin + 1)..(v54_82_origin + 2)]);
            let v66_3: Space = intersect(&(*CONSTANT_12),&(v66_2));
            let v66_4: Space = if has_head(&(v66_3)) { singleton(&[]) } else { Space::new() };
            drop(v66_3);
            let v66_5: Space = subtract(&(*CONSTANT_0),&(v66_4));
            drop(v66_4);
            let v66_8: Space = if (&(v66_5)).is_empty() { Space::new() } else {
              let mut v67_7 = Space::new();
              let mut v67_7_write = v67_7.write_zipper();
              for v67_7_byte in v54_82_cursor.child_mask().iter() {
                v54_82_cursor.descend_to_existing_byte(v67_7_byte);
                {
                let v68_2: Space = singleton(&v54_82_cursor.path()[(v54_82_origin + 2)..(v54_82_origin + 3)]);
                let v68_3: Space = intersect(&(*CONSTANT_12),&(v68_2));
                let v68_4: Space = if has_head(&(v68_3)) { singleton(&[]) } else { Space::new() };
                drop(v68_3);
                let v68_5: Space = subtract(&(*CONSTANT_0),&(v68_4));
                drop(v68_4);
                let v68_8: Space = if (&(v68_5)).is_empty() { Space::new() } else {
                  let v69_7: Space = routine_8(c, &v54_82_cursor.path()[v54_82_origin..(v54_82_origin + 3)], &v54_82_cursor);
                  compose(&(v68_5),&(v69_7))
                };
                drop(v68_5);
                let v68_9: Space = intersect(&(*CONSTANT_12),&(v68_2));
                drop(v68_2);
                let v68_10: Space = if has_head(&(v68_9)) { singleton(&[]) } else { Space::new() };
                drop(v68_9);
                let v68_12: Space = if (&(v68_10)).is_empty() { Space::new() } else {
                  let v70_11: Space = routine_9(c, &v54_82_cursor.path()[v54_82_origin..(v54_82_origin + 3)], &v54_82_cursor);
                  compose(&(v68_10),&(v70_11))
                };
                drop(v68_10);
                let v68_13: Space = unite(&(v68_8),&(v68_12));
                join_wrapped_into(&mut v67_7_write,&((v68_13).read_zipper()),&[]);
                }
                v54_82_cursor.ascend(1);
              }
              drop(v67_7_write);
              compose(&(v66_5),&(v67_7))
            };
            drop(v66_5);
            let v66_9: Space = intersect(&(*CONSTANT_12),&(v66_2));
            drop(v66_2);
            let v66_10: Space = if has_head(&(v66_9)) { singleton(&[]) } else { Space::new() };
            drop(v66_9);
            let v66_12: Space = if (&(v66_10)).is_empty() { Space::new() } else {
              let mut v71_11 = Space::new();
              let mut v71_11_write = v71_11.write_zipper();
              for v71_11_byte in v54_82_cursor.child_mask().iter() {
                v54_82_cursor.descend_to_existing_byte(v71_11_byte);
                {
                let v72_2: Space = singleton(&v54_82_cursor.path()[(v54_82_origin + 2)..(v54_82_origin + 3)]);
                let v72_3: Space = intersect(&(*CONSTANT_12),&(v72_2));
                let v72_4: Space = if has_head(&(v72_3)) { singleton(&[]) } else { Space::new() };
                drop(v72_3);
                let v72_5: Space = subtract(&(*CONSTANT_0),&(v72_4));
                drop(v72_4);
                let v72_8: Space = if (&(v72_5)).is_empty() { Space::new() } else {
                  let v73_7: Space = routine_8(c, &v54_82_cursor.path()[v54_82_origin..(v54_82_origin + 3)], &v54_82_cursor);
                  compose(&(v72_5),&(v73_7))
                };
                drop(v72_5);
                let v72_9: Space = intersect(&(*CONSTANT_12),&(v72_2));
                drop(v72_2);
                let v72_10: Space = if has_head(&(v72_9)) { singleton(&[]) } else { Space::new() };
                drop(v72_9);
                let v72_12: Space = if (&(v72_10)).is_empty() { Space::new() } else {
                  let v74_11: Space = routine_10(c, &v54_82_cursor.path()[v54_82_origin..(v54_82_origin + 3)], &v54_82_cursor);
                  compose(&(v72_10),&(v74_11))
                };
                drop(v72_10);
                let v72_13: Space = unite(&(v72_8),&(v72_12));
                join_wrapped_into(&mut v71_11_write,&((v72_13).read_zipper()),&[]);
                }
                v54_82_cursor.ascend(1);
              }
              drop(v71_11_write);
              compose(&(v66_10),&(v71_11))
            };
            drop(v66_10);
            let v66_13: Space = unite(&(v66_8),&(v66_12));
            join_wrapped_into(&mut v65_6_write,&((v66_13).read_zipper()),&[]);
            }
            v54_82_cursor.ascend(1);
          }
          drop(v65_6_write);
          compose(&(v64_5),&(v65_6))
        };
        drop(v64_5);
        let v64_8: Space = intersect(&(*CONSTANT_12),&(v64_2));
        drop(v64_2);
        let v64_9: Space = if has_head(&(v64_8)) { singleton(&[]) } else { Space::new() };
        drop(v64_8);
        let v64_11: Space = if (&(v64_9)).is_empty() { Space::new() } else {
          let mut v75_10 = Space::new();
          let mut v75_10_write = v75_10.write_zipper();
          for v75_10_byte in v54_82_cursor.child_mask().iter() {
            v54_82_cursor.descend_to_existing_byte(v75_10_byte);
            {
            let v76_2: Space = singleton(&v54_82_cursor.path()[(v54_82_origin + 1)..(v54_82_origin + 2)]);
            let v76_3: Space = intersect(&(*CONSTANT_12),&(v76_2));
            let v76_4: Space = if has_head(&(v76_3)) { singleton(&[]) } else { Space::new() };
            drop(v76_3);
            let v76_5: Space = subtract(&(*CONSTANT_0),&(v76_4));
            drop(v76_4);
            let v76_8: Space = if (&(v76_5)).is_empty() { Space::new() } else {
              let mut v77_7 = Space::new();
              let mut v77_7_write = v77_7.write_zipper();
              for v77_7_byte in v54_82_cursor.child_mask().iter() {
                v54_82_cursor.descend_to_existing_byte(v77_7_byte);
                {
                let v78_2: Space = singleton(&v54_82_cursor.path()[(v54_82_origin + 2)..(v54_82_origin + 3)]);
                let v78_3: Space = intersect(&(*CONSTANT_12),&(v78_2));
                let v78_4: Space = if has_head(&(v78_3)) { singleton(&[]) } else { Space::new() };
                drop(v78_3);
                let v78_5: Space = subtract(&(*CONSTANT_0),&(v78_4));
                drop(v78_4);
                let v78_8: Space = if (&(v78_5)).is_empty() { Space::new() } else {
                  let v79_7: Space = routine_8(c, &v54_82_cursor.path()[v54_82_origin..(v54_82_origin + 3)], &v54_82_cursor);
                  compose(&(v78_5),&(v79_7))
                };
                drop(v78_5);
                let v78_9: Space = intersect(&(*CONSTANT_12),&(v78_2));
                drop(v78_2);
                let v78_10: Space = if has_head(&(v78_9)) { singleton(&[]) } else { Space::new() };
                drop(v78_9);
                let v78_12: Space = if (&(v78_10)).is_empty() { Space::new() } else {
                  let v80_11: Space = routine_9(c, &v54_82_cursor.path()[v54_82_origin..(v54_82_origin + 3)], &v54_82_cursor);
                  compose(&(v78_10),&(v80_11))
                };
                drop(v78_10);
                let v78_13: Space = unite(&(v78_8),&(v78_12));
                join_wrapped_into(&mut v77_7_write,&((v78_13).read_zipper()),&[]);
                }
                v54_82_cursor.ascend(1);
              }
              drop(v77_7_write);
              compose(&(v76_5),&(v77_7))
            };
            drop(v76_5);
            let v76_9: Space = intersect(&(*CONSTANT_12),&(v76_2));
            drop(v76_2);
            let v76_10: Space = if has_head(&(v76_9)) { singleton(&[]) } else { Space::new() };
            drop(v76_9);
            let v76_12: Space = if (&(v76_10)).is_empty() { Space::new() } else {
              let v81_11: Space = singleton(&v54_82_cursor.path()[v54_82_origin..(v54_82_origin + 2)]);
              compose(&(v76_10),&(v81_11))
            };
            drop(v76_10);
            let v76_13: Space = unite(&(v76_8),&(v76_12));
            drop(v76_12);
            join_wrapped_into(&mut v75_10_write,&((v76_13).read_zipper()),&[]);
            }
            v54_82_cursor.ascend(1);
          }
          drop(v75_10_write);
          compose(&(v64_9),&(v75_10))
        };
        drop(v64_9);
        let v64_12: Space = unite(&(v64_7),&(v64_11));
        join_wrapped_into(&mut v54_82_write,&((v64_12).read_zipper()),&[]);
        }
        v54_82_cursor.ascend(1);
      }
      drop(v54_82_cursor);
      drop(v54_82_write);
      let v54_83: Space = unite(&(v54_69),&(v54_82));
      let v54_84: Space = routine_17(c, &v0_155_cursor.path()[v0_155_origin..(v0_155_origin + 1)], &v0_155_cursor, &((v54_58).read_zipper()), &((*CONSTANT_13).read_zipper()), &((v54_83).read_zipper()));
      compose(&(v25_46),&(v54_84))
    };
    drop(v25_46);
    let v25_86: Space = unite(&(v25_44),&(v25_85));
    join_wrapped_into(&mut v0_155_write,&((v25_86).read_zipper()),&[]);
    }
    v0_155_cursor.ascend(1);
  }
  drop(v0_155_cursor);
  drop(v0_155_write);

((v0_155).clone(),(v0_22).clone(),(v0_44).clone(),(v0_63).clone(),(v0_64).clone(),(v0_65).clone(),)
}

#[inline(never)]
fn native_block_1(c: &mut Context,capture_0: &[u8],capture_1: &View<'_, '_>,capture_2: &View<'_, '_>,capture_3: &View<'_, '_>) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v336_5: Space = singleton(&(*capture_0));
  let mut v336_24: Space = (v336_5).clone();
  loop {
    let v337_1: Space = intersect(&(v336_24),&(*capture_3));
    let v337_2: Space = restrict_to(&(*capture_1),&(v337_1));
    drop(v337_1);
    let mut v337_3 = Space::new();
    let mut v337_3_write = v337_3.write_zipper();
    let mut v337_3_cursor = (v337_2).read_zipper();
    let v337_3_origin = v337_3_cursor.path().len();
    for v337_3_byte in v337_3_cursor.child_mask().iter() {
      v337_3_cursor.descend_to_existing_byte(v337_3_byte);
      {
      let v338_2: Space = singleton(&v337_3_cursor.path()[v337_3_origin..(v337_3_origin + 1)]);
      let v338_3: Space = intersect(&(*CONSTANT_12),&(v338_2));
      let v338_4: Space = if has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
      drop(v338_3);
      let v338_5: Space = subtract(&(*CONSTANT_0),&(v338_4));
      drop(v338_4);
      let v338_7: Space = if (&(v338_5)).is_empty() { Space::new() } else {
        let mut v339_6 = Space::new();
        let mut v339_6_write = v339_6.write_zipper();
        for v339_6_byte in v337_3_cursor.child_mask().iter() {
          v337_3_cursor.descend_to_existing_byte(v339_6_byte);
          {
          let v340_2: Space = singleton(&v337_3_cursor.path()[(v337_3_origin + 1)..(v337_3_origin + 2)]);
          let v340_3: Space = intersect(&(*CONSTANT_12),&(v340_2));
          let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
          drop(v340_3);
          let v340_5: Space = subtract(&(*CONSTANT_0),&(v340_4));
          drop(v340_4);
          let v340_8: Space = if (&(v340_5)).is_empty() { Space::new() } else {
            let mut v341_7 = Space::new();
            let mut v341_7_write = v341_7.write_zipper();
            for v341_7_byte in v337_3_cursor.child_mask().iter() {
              v337_3_cursor.descend_to_existing_byte(v341_7_byte);
              {
              let v342_2: Space = singleton(&v337_3_cursor.path()[(v337_3_origin + 2)..(v337_3_origin + 3)]);
              let v342_3: Space = intersect(&(*CONSTANT_12),&(v342_2));
              let v342_4: Space = if has_head(&(v342_3)) { singleton(&[]) } else { Space::new() };
              drop(v342_3);
              let v342_5: Space = subtract(&(*CONSTANT_0),&(v342_4));
              drop(v342_4);
              let v342_8: Space = if (&(v342_5)).is_empty() { Space::new() } else {
                let v343_7: Space = routine_41(c, &v337_3_cursor.path()[v337_3_origin..(v337_3_origin + 3)], &v337_3_cursor);
                compose(&(v342_5),&(v343_7))
              };
              drop(v342_5);
              let v342_9: Space = intersect(&(*CONSTANT_12),&(v342_2));
              drop(v342_2);
              let v342_10: Space = if has_head(&(v342_9)) { singleton(&[]) } else { Space::new() };
              drop(v342_9);
              let v342_12: Space = if (&(v342_10)).is_empty() { Space::new() } else {
                let v344_11: Space = routine_42(c, &v337_3_cursor.path()[v337_3_origin..(v337_3_origin + 3)], &v337_3_cursor);
                compose(&(v342_10),&(v344_11))
              };
              drop(v342_10);
              let v342_13: Space = unite(&(v342_8),&(v342_12));
              join_wrapped_into(&mut v341_7_write,&((v342_13).read_zipper()),&[]);
              }
              v337_3_cursor.ascend(1);
            }
            drop(v341_7_write);
            compose(&(v340_5),&(v341_7))
          };
          drop(v340_5);
          let v340_9: Space = intersect(&(*CONSTANT_12),&(v340_2));
          drop(v340_2);
          let v340_10: Space = if has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
          drop(v340_9);
          let v340_12: Space = if (&(v340_10)).is_empty() { Space::new() } else {
            let mut v345_11 = Space::new();
            let mut v345_11_write = v345_11.write_zipper();
            for v345_11_byte in v337_3_cursor.child_mask().iter() {
              v337_3_cursor.descend_to_existing_byte(v345_11_byte);
              {
              let v346_2: Space = singleton(&v337_3_cursor.path()[(v337_3_origin + 2)..(v337_3_origin + 3)]);
              let v346_3: Space = intersect(&(*CONSTANT_12),&(v346_2));
              let v346_4: Space = if has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
              drop(v346_3);
              let v346_5: Space = subtract(&(*CONSTANT_0),&(v346_4));
              drop(v346_4);
              let v346_8: Space = if (&(v346_5)).is_empty() { Space::new() } else {
                let v347_7: Space = routine_41(c, &v337_3_cursor.path()[v337_3_origin..(v337_3_origin + 3)], &v337_3_cursor);
                compose(&(v346_5),&(v347_7))
              };
              drop(v346_5);
              let v346_9: Space = intersect(&(*CONSTANT_12),&(v346_2));
              drop(v346_2);
              let v346_10: Space = if has_head(&(v346_9)) { singleton(&[]) } else { Space::new() };
              drop(v346_9);
              let v346_12: Space = if (&(v346_10)).is_empty() { Space::new() } else {
                let v348_11: Space = routine_43(c, &v337_3_cursor.path()[v337_3_origin..(v337_3_origin + 3)], &v337_3_cursor);
                compose(&(v346_10),&(v348_11))
              };
              drop(v346_10);
              let v346_13: Space = unite(&(v346_8),&(v346_12));
              join_wrapped_into(&mut v345_11_write,&((v346_13).read_zipper()),&[]);
              }
              v337_3_cursor.ascend(1);
            }
            drop(v345_11_write);
            compose(&(v340_10),&(v345_11))
          };
          drop(v340_10);
          let v340_13: Space = unite(&(v340_8),&(v340_12));
          join_wrapped_into(&mut v339_6_write,&((v340_13).read_zipper()),&[]);
          }
          v337_3_cursor.ascend(1);
        }
        drop(v339_6_write);
        compose(&(v338_5),&(v339_6))
      };
      drop(v338_5);
      let v338_8: Space = intersect(&(*CONSTANT_12),&(v338_2));
      drop(v338_2);
      let v338_9: Space = if has_head(&(v338_8)) { singleton(&[]) } else { Space::new() };
      drop(v338_8);
      let v338_11: Space = if (&(v338_9)).is_empty() { Space::new() } else {
        let mut v349_10 = Space::new();
        let mut v349_10_write = v349_10.write_zipper();
        for v349_10_byte in v337_3_cursor.child_mask().iter() {
          v337_3_cursor.descend_to_existing_byte(v349_10_byte);
          {
          let v350_2: Space = singleton(&v337_3_cursor.path()[(v337_3_origin + 1)..(v337_3_origin + 2)]);
          let v350_3: Space = intersect(&(*CONSTANT_12),&(v350_2));
          let v350_4: Space = if has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
          drop(v350_3);
          let v350_5: Space = subtract(&(*CONSTANT_0),&(v350_4));
          drop(v350_4);
          let v350_8: Space = if (&(v350_5)).is_empty() { Space::new() } else {
            let mut v351_7 = Space::new();
            let mut v351_7_write = v351_7.write_zipper();
            for v351_7_byte in v337_3_cursor.child_mask().iter() {
              v337_3_cursor.descend_to_existing_byte(v351_7_byte);
              {
              let v352_2: Space = singleton(&v337_3_cursor.path()[(v337_3_origin + 2)..(v337_3_origin + 3)]);
              let v352_3: Space = intersect(&(*CONSTANT_12),&(v352_2));
              let v352_4: Space = if has_head(&(v352_3)) { singleton(&[]) } else { Space::new() };
              drop(v352_3);
              let v352_5: Space = subtract(&(*CONSTANT_0),&(v352_4));
              drop(v352_4);
              let v352_8: Space = if (&(v352_5)).is_empty() { Space::new() } else {
                let v353_7: Space = routine_41(c, &v337_3_cursor.path()[v337_3_origin..(v337_3_origin + 3)], &v337_3_cursor);
                compose(&(v352_5),&(v353_7))
              };
              drop(v352_5);
              let v352_9: Space = intersect(&(*CONSTANT_12),&(v352_2));
              drop(v352_2);
              let v352_10: Space = if has_head(&(v352_9)) { singleton(&[]) } else { Space::new() };
              drop(v352_9);
              let v352_12: Space = if (&(v352_10)).is_empty() { Space::new() } else {
                let v354_11: Space = routine_42(c, &v337_3_cursor.path()[v337_3_origin..(v337_3_origin + 3)], &v337_3_cursor);
                compose(&(v352_10),&(v354_11))
              };
              drop(v352_10);
              let v352_13: Space = unite(&(v352_8),&(v352_12));
              join_wrapped_into(&mut v351_7_write,&((v352_13).read_zipper()),&[]);
              }
              v337_3_cursor.ascend(1);
            }
            drop(v351_7_write);
            compose(&(v350_5),&(v351_7))
          };
          drop(v350_5);
          let v350_9: Space = intersect(&(*CONSTANT_12),&(v350_2));
          drop(v350_2);
          let v350_10: Space = if has_head(&(v350_9)) { singleton(&[]) } else { Space::new() };
          drop(v350_9);
          let v350_11: Space = compose(&(v350_10),&v337_3_cursor);
          drop(v350_10);
          let v350_12: Space = unite(&(v350_8),&(v350_11));
          drop(v350_11);
          join_wrapped_into(&mut v349_10_write,&((v350_12).read_zipper()),&[]);
          }
          v337_3_cursor.ascend(1);
        }
        drop(v349_10_write);
        compose(&(v338_9),&(v349_10))
      };
      drop(v338_9);
      let v338_12: Space = unite(&(v338_7),&(v338_11));
      join_wrapped_into(&mut v337_3_write,&((v338_12).read_zipper()),&[]);
      }
      v337_3_cursor.ascend(1);
    }
    drop(v337_3_cursor);
    drop(v337_3_write);
    drop(v337_2);
    let v337_4: Space = unite(&(v337_3),&(v336_24));
    let v337_5: Space = intersect(&(v337_4),&(*capture_3));
    if !v336_24.join_into((v337_5).clone()).is_element() { break; }
  }
  let mut v336_43: Space = (v336_5).clone();
  loop {
    let v355_1: Space = intersect(&(v336_43),&(*capture_3));
    let v355_2: Space = restrict_to(&(*capture_2),&(v355_1));
    drop(v355_1);
    let mut v355_3 = Space::new();
    let mut v355_3_write = v355_3.write_zipper();
    let mut v355_3_cursor = (v355_2).read_zipper();
    let v355_3_origin = v355_3_cursor.path().len();
    for v355_3_byte in v355_3_cursor.child_mask().iter() {
      v355_3_cursor.descend_to_existing_byte(v355_3_byte);
      {
      let v356_2: Space = singleton(&v355_3_cursor.path()[v355_3_origin..(v355_3_origin + 1)]);
      let v356_3: Space = intersect(&(*CONSTANT_12),&(v356_2));
      let v356_4: Space = if has_head(&(v356_3)) { singleton(&[]) } else { Space::new() };
      drop(v356_3);
      let v356_5: Space = subtract(&(*CONSTANT_0),&(v356_4));
      drop(v356_4);
      let v356_7: Space = if (&(v356_5)).is_empty() { Space::new() } else {
        let mut v357_6 = Space::new();
        let mut v357_6_write = v357_6.write_zipper();
        for v357_6_byte in v355_3_cursor.child_mask().iter() {
          v355_3_cursor.descend_to_existing_byte(v357_6_byte);
          {
          let v358_2: Space = singleton(&v355_3_cursor.path()[(v355_3_origin + 1)..(v355_3_origin + 2)]);
          let v358_3: Space = intersect(&(*CONSTANT_12),&(v358_2));
          let v358_4: Space = if has_head(&(v358_3)) { singleton(&[]) } else { Space::new() };
          drop(v358_3);
          let v358_5: Space = subtract(&(*CONSTANT_0),&(v358_4));
          drop(v358_4);
          let v358_8: Space = if (&(v358_5)).is_empty() { Space::new() } else {
            let mut v359_7 = Space::new();
            let mut v359_7_write = v359_7.write_zipper();
            for v359_7_byte in v355_3_cursor.child_mask().iter() {
              v355_3_cursor.descend_to_existing_byte(v359_7_byte);
              {
              let v360_2: Space = singleton(&v355_3_cursor.path()[(v355_3_origin + 2)..(v355_3_origin + 3)]);
              let v360_3: Space = intersect(&(*CONSTANT_12),&(v360_2));
              let v360_4: Space = if has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
              drop(v360_3);
              let v360_5: Space = subtract(&(*CONSTANT_0),&(v360_4));
              drop(v360_4);
              let v360_8: Space = if (&(v360_5)).is_empty() { Space::new() } else {
                let v361_7: Space = routine_41(c, &v355_3_cursor.path()[v355_3_origin..(v355_3_origin + 3)], &v355_3_cursor);
                compose(&(v360_5),&(v361_7))
              };
              drop(v360_5);
              let v360_9: Space = intersect(&(*CONSTANT_12),&(v360_2));
              drop(v360_2);
              let v360_10: Space = if has_head(&(v360_9)) { singleton(&[]) } else { Space::new() };
              drop(v360_9);
              let v360_12: Space = if (&(v360_10)).is_empty() { Space::new() } else {
                let v362_11: Space = routine_42(c, &v355_3_cursor.path()[v355_3_origin..(v355_3_origin + 3)], &v355_3_cursor);
                compose(&(v360_10),&(v362_11))
              };
              drop(v360_10);
              let v360_13: Space = unite(&(v360_8),&(v360_12));
              join_wrapped_into(&mut v359_7_write,&((v360_13).read_zipper()),&[]);
              }
              v355_3_cursor.ascend(1);
            }
            drop(v359_7_write);
            compose(&(v358_5),&(v359_7))
          };
          drop(v358_5);
          let v358_9: Space = intersect(&(*CONSTANT_12),&(v358_2));
          drop(v358_2);
          let v358_10: Space = if has_head(&(v358_9)) { singleton(&[]) } else { Space::new() };
          drop(v358_9);
          let v358_12: Space = if (&(v358_10)).is_empty() { Space::new() } else {
            let mut v363_11 = Space::new();
            let mut v363_11_write = v363_11.write_zipper();
            for v363_11_byte in v355_3_cursor.child_mask().iter() {
              v355_3_cursor.descend_to_existing_byte(v363_11_byte);
              {
              let v364_2: Space = singleton(&v355_3_cursor.path()[(v355_3_origin + 2)..(v355_3_origin + 3)]);
              let v364_3: Space = intersect(&(*CONSTANT_12),&(v364_2));
              let v364_4: Space = if has_head(&(v364_3)) { singleton(&[]) } else { Space::new() };
              drop(v364_3);
              let v364_5: Space = subtract(&(*CONSTANT_0),&(v364_4));
              drop(v364_4);
              let v364_8: Space = if (&(v364_5)).is_empty() { Space::new() } else {
                let v365_7: Space = routine_41(c, &v355_3_cursor.path()[v355_3_origin..(v355_3_origin + 3)], &v355_3_cursor);
                compose(&(v364_5),&(v365_7))
              };
              drop(v364_5);
              let v364_9: Space = intersect(&(*CONSTANT_12),&(v364_2));
              drop(v364_2);
              let v364_10: Space = if has_head(&(v364_9)) { singleton(&[]) } else { Space::new() };
              drop(v364_9);
              let v364_12: Space = if (&(v364_10)).is_empty() { Space::new() } else {
                let v366_11: Space = routine_43(c, &v355_3_cursor.path()[v355_3_origin..(v355_3_origin + 3)], &v355_3_cursor);
                compose(&(v364_10),&(v366_11))
              };
              drop(v364_10);
              let v364_13: Space = unite(&(v364_8),&(v364_12));
              join_wrapped_into(&mut v363_11_write,&((v364_13).read_zipper()),&[]);
              }
              v355_3_cursor.ascend(1);
            }
            drop(v363_11_write);
            compose(&(v358_10),&(v363_11))
          };
          drop(v358_10);
          let v358_13: Space = unite(&(v358_8),&(v358_12));
          join_wrapped_into(&mut v357_6_write,&((v358_13).read_zipper()),&[]);
          }
          v355_3_cursor.ascend(1);
        }
        drop(v357_6_write);
        compose(&(v356_5),&(v357_6))
      };
      drop(v356_5);
      let v356_8: Space = intersect(&(*CONSTANT_12),&(v356_2));
      drop(v356_2);
      let v356_9: Space = if has_head(&(v356_8)) { singleton(&[]) } else { Space::new() };
      drop(v356_8);
      let v356_11: Space = if (&(v356_9)).is_empty() { Space::new() } else {
        let mut v367_10 = Space::new();
        let mut v367_10_write = v367_10.write_zipper();
        for v367_10_byte in v355_3_cursor.child_mask().iter() {
          v355_3_cursor.descend_to_existing_byte(v367_10_byte);
          {
          let v368_2: Space = singleton(&v355_3_cursor.path()[(v355_3_origin + 1)..(v355_3_origin + 2)]);
          let v368_3: Space = intersect(&(*CONSTANT_12),&(v368_2));
          let v368_4: Space = if has_head(&(v368_3)) { singleton(&[]) } else { Space::new() };
          drop(v368_3);
          let v368_5: Space = subtract(&(*CONSTANT_0),&(v368_4));
          drop(v368_4);
          let v368_8: Space = if (&(v368_5)).is_empty() { Space::new() } else {
            let mut v369_7 = Space::new();
            let mut v369_7_write = v369_7.write_zipper();
            for v369_7_byte in v355_3_cursor.child_mask().iter() {
              v355_3_cursor.descend_to_existing_byte(v369_7_byte);
              {
              let v370_2: Space = singleton(&v355_3_cursor.path()[(v355_3_origin + 2)..(v355_3_origin + 3)]);
              let v370_3: Space = intersect(&(*CONSTANT_12),&(v370_2));
              let v370_4: Space = if has_head(&(v370_3)) { singleton(&[]) } else { Space::new() };
              drop(v370_3);
              let v370_5: Space = subtract(&(*CONSTANT_0),&(v370_4));
              drop(v370_4);
              let v370_8: Space = if (&(v370_5)).is_empty() { Space::new() } else {
                let v371_7: Space = routine_41(c, &v355_3_cursor.path()[v355_3_origin..(v355_3_origin + 3)], &v355_3_cursor);
                compose(&(v370_5),&(v371_7))
              };
              drop(v370_5);
              let v370_9: Space = intersect(&(*CONSTANT_12),&(v370_2));
              drop(v370_2);
              let v370_10: Space = if has_head(&(v370_9)) { singleton(&[]) } else { Space::new() };
              drop(v370_9);
              let v370_12: Space = if (&(v370_10)).is_empty() { Space::new() } else {
                let v372_11: Space = routine_42(c, &v355_3_cursor.path()[v355_3_origin..(v355_3_origin + 3)], &v355_3_cursor);
                compose(&(v370_10),&(v372_11))
              };
              drop(v370_10);
              let v370_13: Space = unite(&(v370_8),&(v370_12));
              join_wrapped_into(&mut v369_7_write,&((v370_13).read_zipper()),&[]);
              }
              v355_3_cursor.ascend(1);
            }
            drop(v369_7_write);
            compose(&(v368_5),&(v369_7))
          };
          drop(v368_5);
          let v368_9: Space = intersect(&(*CONSTANT_12),&(v368_2));
          drop(v368_2);
          let v368_10: Space = if has_head(&(v368_9)) { singleton(&[]) } else { Space::new() };
          drop(v368_9);
          let v368_11: Space = compose(&(v368_10),&v355_3_cursor);
          drop(v368_10);
          let v368_12: Space = unite(&(v368_8),&(v368_11));
          drop(v368_11);
          join_wrapped_into(&mut v367_10_write,&((v368_12).read_zipper()),&[]);
          }
          v355_3_cursor.ascend(1);
        }
        drop(v367_10_write);
        compose(&(v356_9),&(v367_10))
      };
      drop(v356_9);
      let v356_12: Space = unite(&(v356_7),&(v356_11));
      join_wrapped_into(&mut v355_3_write,&((v356_12).read_zipper()),&[]);
      }
      v355_3_cursor.ascend(1);
    }
    drop(v355_3_cursor);
    drop(v355_3_write);
    drop(v355_2);
    let v355_4: Space = unite(&(v355_3),&(v336_43));
    let v355_5: Space = intersect(&(v355_4),&(*capture_3));
    if !v336_43.join_into((v355_5).clone()).is_element() { break; }
  }
  let v336_44: Space = intersect(&(v336_24),&(v336_43));
  let v336_45: Space = subtract(&(v336_44),&(v336_5));
  let v336_46: Space = wrap(&(v336_45),&(*capture_0));
  let mut v336_65: Space = (v336_5).clone();
  loop {
    let v373_1: Space = intersect(&(v336_65),&(*capture_3));
    let v373_2: Space = restrict_to(&(*capture_2),&(v373_1));
    drop(v373_1);
    let mut v373_3 = Space::new();
    let mut v373_3_write = v373_3.write_zipper();
    let mut v373_3_cursor = (v373_2).read_zipper();
    let v373_3_origin = v373_3_cursor.path().len();
    for v373_3_byte in v373_3_cursor.child_mask().iter() {
      v373_3_cursor.descend_to_existing_byte(v373_3_byte);
      {
      let v374_2: Space = singleton(&v373_3_cursor.path()[v373_3_origin..(v373_3_origin + 1)]);
      let v374_3: Space = intersect(&(*CONSTANT_12),&(v374_2));
      let v374_4: Space = if has_head(&(v374_3)) { singleton(&[]) } else { Space::new() };
      drop(v374_3);
      let v374_5: Space = subtract(&(*CONSTANT_0),&(v374_4));
      drop(v374_4);
      let v374_7: Space = if (&(v374_5)).is_empty() { Space::new() } else {
        let mut v375_6 = Space::new();
        let mut v375_6_write = v375_6.write_zipper();
        for v375_6_byte in v373_3_cursor.child_mask().iter() {
          v373_3_cursor.descend_to_existing_byte(v375_6_byte);
          {
          let v376_2: Space = singleton(&v373_3_cursor.path()[(v373_3_origin + 1)..(v373_3_origin + 2)]);
          let v376_3: Space = intersect(&(*CONSTANT_12),&(v376_2));
          let v376_4: Space = if has_head(&(v376_3)) { singleton(&[]) } else { Space::new() };
          drop(v376_3);
          let v376_5: Space = subtract(&(*CONSTANT_0),&(v376_4));
          drop(v376_4);
          let v376_8: Space = if (&(v376_5)).is_empty() { Space::new() } else {
            let mut v377_7 = Space::new();
            let mut v377_7_write = v377_7.write_zipper();
            for v377_7_byte in v373_3_cursor.child_mask().iter() {
              v373_3_cursor.descend_to_existing_byte(v377_7_byte);
              {
              let v378_2: Space = singleton(&v373_3_cursor.path()[(v373_3_origin + 2)..(v373_3_origin + 3)]);
              let v378_3: Space = intersect(&(*CONSTANT_12),&(v378_2));
              let v378_4: Space = if has_head(&(v378_3)) { singleton(&[]) } else { Space::new() };
              drop(v378_3);
              let v378_5: Space = subtract(&(*CONSTANT_0),&(v378_4));
              drop(v378_4);
              let v378_8: Space = if (&(v378_5)).is_empty() { Space::new() } else {
                let v379_7: Space = routine_41(c, &v373_3_cursor.path()[v373_3_origin..(v373_3_origin + 3)], &v373_3_cursor);
                compose(&(v378_5),&(v379_7))
              };
              drop(v378_5);
              let v378_9: Space = intersect(&(*CONSTANT_12),&(v378_2));
              drop(v378_2);
              let v378_10: Space = if has_head(&(v378_9)) { singleton(&[]) } else { Space::new() };
              drop(v378_9);
              let v378_12: Space = if (&(v378_10)).is_empty() { Space::new() } else {
                let v380_11: Space = routine_42(c, &v373_3_cursor.path()[v373_3_origin..(v373_3_origin + 3)], &v373_3_cursor);
                compose(&(v378_10),&(v380_11))
              };
              drop(v378_10);
              let v378_13: Space = unite(&(v378_8),&(v378_12));
              join_wrapped_into(&mut v377_7_write,&((v378_13).read_zipper()),&[]);
              }
              v373_3_cursor.ascend(1);
            }
            drop(v377_7_write);
            compose(&(v376_5),&(v377_7))
          };
          drop(v376_5);
          let v376_9: Space = intersect(&(*CONSTANT_12),&(v376_2));
          drop(v376_2);
          let v376_10: Space = if has_head(&(v376_9)) { singleton(&[]) } else { Space::new() };
          drop(v376_9);
          let v376_12: Space = if (&(v376_10)).is_empty() { Space::new() } else {
            let mut v381_11 = Space::new();
            let mut v381_11_write = v381_11.write_zipper();
            for v381_11_byte in v373_3_cursor.child_mask().iter() {
              v373_3_cursor.descend_to_existing_byte(v381_11_byte);
              {
              let v382_2: Space = singleton(&v373_3_cursor.path()[(v373_3_origin + 2)..(v373_3_origin + 3)]);
              let v382_3: Space = intersect(&(*CONSTANT_12),&(v382_2));
              let v382_4: Space = if has_head(&(v382_3)) { singleton(&[]) } else { Space::new() };
              drop(v382_3);
              let v382_5: Space = subtract(&(*CONSTANT_0),&(v382_4));
              drop(v382_4);
              let v382_8: Space = if (&(v382_5)).is_empty() { Space::new() } else {
                let v383_7: Space = routine_41(c, &v373_3_cursor.path()[v373_3_origin..(v373_3_origin + 3)], &v373_3_cursor);
                compose(&(v382_5),&(v383_7))
              };
              drop(v382_5);
              let v382_9: Space = intersect(&(*CONSTANT_12),&(v382_2));
              drop(v382_2);
              let v382_10: Space = if has_head(&(v382_9)) { singleton(&[]) } else { Space::new() };
              drop(v382_9);
              let v382_12: Space = if (&(v382_10)).is_empty() { Space::new() } else {
                let v384_11: Space = routine_43(c, &v373_3_cursor.path()[v373_3_origin..(v373_3_origin + 3)], &v373_3_cursor);
                compose(&(v382_10),&(v384_11))
              };
              drop(v382_10);
              let v382_13: Space = unite(&(v382_8),&(v382_12));
              join_wrapped_into(&mut v381_11_write,&((v382_13).read_zipper()),&[]);
              }
              v373_3_cursor.ascend(1);
            }
            drop(v381_11_write);
            compose(&(v376_10),&(v381_11))
          };
          drop(v376_10);
          let v376_13: Space = unite(&(v376_8),&(v376_12));
          join_wrapped_into(&mut v375_6_write,&((v376_13).read_zipper()),&[]);
          }
          v373_3_cursor.ascend(1);
        }
        drop(v375_6_write);
        compose(&(v374_5),&(v375_6))
      };
      drop(v374_5);
      let v374_8: Space = intersect(&(*CONSTANT_12),&(v374_2));
      drop(v374_2);
      let v374_9: Space = if has_head(&(v374_8)) { singleton(&[]) } else { Space::new() };
      drop(v374_8);
      let v374_11: Space = if (&(v374_9)).is_empty() { Space::new() } else {
        let mut v385_10 = Space::new();
        let mut v385_10_write = v385_10.write_zipper();
        for v385_10_byte in v373_3_cursor.child_mask().iter() {
          v373_3_cursor.descend_to_existing_byte(v385_10_byte);
          {
          let v386_2: Space = singleton(&v373_3_cursor.path()[(v373_3_origin + 1)..(v373_3_origin + 2)]);
          let v386_3: Space = intersect(&(*CONSTANT_12),&(v386_2));
          let v386_4: Space = if has_head(&(v386_3)) { singleton(&[]) } else { Space::new() };
          drop(v386_3);
          let v386_5: Space = subtract(&(*CONSTANT_0),&(v386_4));
          drop(v386_4);
          let v386_8: Space = if (&(v386_5)).is_empty() { Space::new() } else {
            let mut v387_7 = Space::new();
            let mut v387_7_write = v387_7.write_zipper();
            for v387_7_byte in v373_3_cursor.child_mask().iter() {
              v373_3_cursor.descend_to_existing_byte(v387_7_byte);
              {
              let v388_2: Space = singleton(&v373_3_cursor.path()[(v373_3_origin + 2)..(v373_3_origin + 3)]);
              let v388_3: Space = intersect(&(*CONSTANT_12),&(v388_2));
              let v388_4: Space = if has_head(&(v388_3)) { singleton(&[]) } else { Space::new() };
              drop(v388_3);
              let v388_5: Space = subtract(&(*CONSTANT_0),&(v388_4));
              drop(v388_4);
              let v388_8: Space = if (&(v388_5)).is_empty() { Space::new() } else {
                let v389_7: Space = routine_41(c, &v373_3_cursor.path()[v373_3_origin..(v373_3_origin + 3)], &v373_3_cursor);
                compose(&(v388_5),&(v389_7))
              };
              drop(v388_5);
              let v388_9: Space = intersect(&(*CONSTANT_12),&(v388_2));
              drop(v388_2);
              let v388_10: Space = if has_head(&(v388_9)) { singleton(&[]) } else { Space::new() };
              drop(v388_9);
              let v388_12: Space = if (&(v388_10)).is_empty() { Space::new() } else {
                let v390_11: Space = routine_42(c, &v373_3_cursor.path()[v373_3_origin..(v373_3_origin + 3)], &v373_3_cursor);
                compose(&(v388_10),&(v390_11))
              };
              drop(v388_10);
              let v388_13: Space = unite(&(v388_8),&(v388_12));
              join_wrapped_into(&mut v387_7_write,&((v388_13).read_zipper()),&[]);
              }
              v373_3_cursor.ascend(1);
            }
            drop(v387_7_write);
            compose(&(v386_5),&(v387_7))
          };
          drop(v386_5);
          let v386_9: Space = intersect(&(*CONSTANT_12),&(v386_2));
          drop(v386_2);
          let v386_10: Space = if has_head(&(v386_9)) { singleton(&[]) } else { Space::new() };
          drop(v386_9);
          let v386_11: Space = compose(&(v386_10),&v373_3_cursor);
          drop(v386_10);
          let v386_12: Space = unite(&(v386_8),&(v386_11));
          drop(v386_11);
          join_wrapped_into(&mut v385_10_write,&((v386_12).read_zipper()),&[]);
          }
          v373_3_cursor.ascend(1);
        }
        drop(v385_10_write);
        compose(&(v374_9),&(v385_10))
      };
      drop(v374_9);
      let v374_12: Space = unite(&(v374_7),&(v374_11));
      join_wrapped_into(&mut v373_3_write,&((v374_12).read_zipper()),&[]);
      }
      v373_3_cursor.ascend(1);
    }
    drop(v373_3_cursor);
    drop(v373_3_write);
    drop(v373_2);
    let v373_4: Space = unite(&(v373_3),&(v336_65));
    let v373_5: Space = intersect(&(v373_4),&(*capture_3));
    if !v336_65.join_into((v373_5).clone()).is_element() { break; }
  }
  let v336_66: Space = subtract(&(*capture_3),&(v336_65));
  let mut v336_85: Space = (v336_5).clone();
  loop {
    let v391_1: Space = intersect(&(v336_85),&(*capture_3));
    let v391_2: Space = restrict_to(&(*capture_1),&(v391_1));
    drop(v391_1);
    let mut v391_3 = Space::new();
    let mut v391_3_write = v391_3.write_zipper();
    let mut v391_3_cursor = (v391_2).read_zipper();
    let v391_3_origin = v391_3_cursor.path().len();
    for v391_3_byte in v391_3_cursor.child_mask().iter() {
      v391_3_cursor.descend_to_existing_byte(v391_3_byte);
      {
      let v392_2: Space = singleton(&v391_3_cursor.path()[v391_3_origin..(v391_3_origin + 1)]);
      let v392_3: Space = intersect(&(*CONSTANT_12),&(v392_2));
      let v392_4: Space = if has_head(&(v392_3)) { singleton(&[]) } else { Space::new() };
      drop(v392_3);
      let v392_5: Space = subtract(&(*CONSTANT_0),&(v392_4));
      drop(v392_4);
      let v392_7: Space = if (&(v392_5)).is_empty() { Space::new() } else {
        let mut v393_6 = Space::new();
        let mut v393_6_write = v393_6.write_zipper();
        for v393_6_byte in v391_3_cursor.child_mask().iter() {
          v391_3_cursor.descend_to_existing_byte(v393_6_byte);
          {
          let v394_2: Space = singleton(&v391_3_cursor.path()[(v391_3_origin + 1)..(v391_3_origin + 2)]);
          let v394_3: Space = intersect(&(*CONSTANT_12),&(v394_2));
          let v394_4: Space = if has_head(&(v394_3)) { singleton(&[]) } else { Space::new() };
          drop(v394_3);
          let v394_5: Space = subtract(&(*CONSTANT_0),&(v394_4));
          drop(v394_4);
          let v394_8: Space = if (&(v394_5)).is_empty() { Space::new() } else {
            let mut v395_7 = Space::new();
            let mut v395_7_write = v395_7.write_zipper();
            for v395_7_byte in v391_3_cursor.child_mask().iter() {
              v391_3_cursor.descend_to_existing_byte(v395_7_byte);
              {
              let v396_2: Space = singleton(&v391_3_cursor.path()[(v391_3_origin + 2)..(v391_3_origin + 3)]);
              let v396_3: Space = intersect(&(*CONSTANT_12),&(v396_2));
              let v396_4: Space = if has_head(&(v396_3)) { singleton(&[]) } else { Space::new() };
              drop(v396_3);
              let v396_5: Space = subtract(&(*CONSTANT_0),&(v396_4));
              drop(v396_4);
              let v396_8: Space = if (&(v396_5)).is_empty() { Space::new() } else {
                let v397_7: Space = routine_41(c, &v391_3_cursor.path()[v391_3_origin..(v391_3_origin + 3)], &v391_3_cursor);
                compose(&(v396_5),&(v397_7))
              };
              drop(v396_5);
              let v396_9: Space = intersect(&(*CONSTANT_12),&(v396_2));
              drop(v396_2);
              let v396_10: Space = if has_head(&(v396_9)) { singleton(&[]) } else { Space::new() };
              drop(v396_9);
              let v396_12: Space = if (&(v396_10)).is_empty() { Space::new() } else {
                let v398_11: Space = routine_42(c, &v391_3_cursor.path()[v391_3_origin..(v391_3_origin + 3)], &v391_3_cursor);
                compose(&(v396_10),&(v398_11))
              };
              drop(v396_10);
              let v396_13: Space = unite(&(v396_8),&(v396_12));
              join_wrapped_into(&mut v395_7_write,&((v396_13).read_zipper()),&[]);
              }
              v391_3_cursor.ascend(1);
            }
            drop(v395_7_write);
            compose(&(v394_5),&(v395_7))
          };
          drop(v394_5);
          let v394_9: Space = intersect(&(*CONSTANT_12),&(v394_2));
          drop(v394_2);
          let v394_10: Space = if has_head(&(v394_9)) { singleton(&[]) } else { Space::new() };
          drop(v394_9);
          let v394_12: Space = if (&(v394_10)).is_empty() { Space::new() } else {
            let mut v399_11 = Space::new();
            let mut v399_11_write = v399_11.write_zipper();
            for v399_11_byte in v391_3_cursor.child_mask().iter() {
              v391_3_cursor.descend_to_existing_byte(v399_11_byte);
              {
              let v400_2: Space = singleton(&v391_3_cursor.path()[(v391_3_origin + 2)..(v391_3_origin + 3)]);
              let v400_3: Space = intersect(&(*CONSTANT_12),&(v400_2));
              let v400_4: Space = if has_head(&(v400_3)) { singleton(&[]) } else { Space::new() };
              drop(v400_3);
              let v400_5: Space = subtract(&(*CONSTANT_0),&(v400_4));
              drop(v400_4);
              let v400_8: Space = if (&(v400_5)).is_empty() { Space::new() } else {
                let v401_7: Space = routine_41(c, &v391_3_cursor.path()[v391_3_origin..(v391_3_origin + 3)], &v391_3_cursor);
                compose(&(v400_5),&(v401_7))
              };
              drop(v400_5);
              let v400_9: Space = intersect(&(*CONSTANT_12),&(v400_2));
              drop(v400_2);
              let v400_10: Space = if has_head(&(v400_9)) { singleton(&[]) } else { Space::new() };
              drop(v400_9);
              let v400_12: Space = if (&(v400_10)).is_empty() { Space::new() } else {
                let v402_11: Space = routine_43(c, &v391_3_cursor.path()[v391_3_origin..(v391_3_origin + 3)], &v391_3_cursor);
                compose(&(v400_10),&(v402_11))
              };
              drop(v400_10);
              let v400_13: Space = unite(&(v400_8),&(v400_12));
              join_wrapped_into(&mut v399_11_write,&((v400_13).read_zipper()),&[]);
              }
              v391_3_cursor.ascend(1);
            }
            drop(v399_11_write);
            compose(&(v394_10),&(v399_11))
          };
          drop(v394_10);
          let v394_13: Space = unite(&(v394_8),&(v394_12));
          join_wrapped_into(&mut v393_6_write,&((v394_13).read_zipper()),&[]);
          }
          v391_3_cursor.ascend(1);
        }
        drop(v393_6_write);
        compose(&(v392_5),&(v393_6))
      };
      drop(v392_5);
      let v392_8: Space = intersect(&(*CONSTANT_12),&(v392_2));
      drop(v392_2);
      let v392_9: Space = if has_head(&(v392_8)) { singleton(&[]) } else { Space::new() };
      drop(v392_8);
      let v392_11: Space = if (&(v392_9)).is_empty() { Space::new() } else {
        let mut v403_10 = Space::new();
        let mut v403_10_write = v403_10.write_zipper();
        for v403_10_byte in v391_3_cursor.child_mask().iter() {
          v391_3_cursor.descend_to_existing_byte(v403_10_byte);
          {
          let v404_2: Space = singleton(&v391_3_cursor.path()[(v391_3_origin + 1)..(v391_3_origin + 2)]);
          let v404_3: Space = intersect(&(*CONSTANT_12),&(v404_2));
          let v404_4: Space = if has_head(&(v404_3)) { singleton(&[]) } else { Space::new() };
          drop(v404_3);
          let v404_5: Space = subtract(&(*CONSTANT_0),&(v404_4));
          drop(v404_4);
          let v404_8: Space = if (&(v404_5)).is_empty() { Space::new() } else {
            let mut v405_7 = Space::new();
            let mut v405_7_write = v405_7.write_zipper();
            for v405_7_byte in v391_3_cursor.child_mask().iter() {
              v391_3_cursor.descend_to_existing_byte(v405_7_byte);
              {
              let v406_2: Space = singleton(&v391_3_cursor.path()[(v391_3_origin + 2)..(v391_3_origin + 3)]);
              let v406_3: Space = intersect(&(*CONSTANT_12),&(v406_2));
              let v406_4: Space = if has_head(&(v406_3)) { singleton(&[]) } else { Space::new() };
              drop(v406_3);
              let v406_5: Space = subtract(&(*CONSTANT_0),&(v406_4));
              drop(v406_4);
              let v406_8: Space = if (&(v406_5)).is_empty() { Space::new() } else {
                let v407_7: Space = routine_41(c, &v391_3_cursor.path()[v391_3_origin..(v391_3_origin + 3)], &v391_3_cursor);
                compose(&(v406_5),&(v407_7))
              };
              drop(v406_5);
              let v406_9: Space = intersect(&(*CONSTANT_12),&(v406_2));
              drop(v406_2);
              let v406_10: Space = if has_head(&(v406_9)) { singleton(&[]) } else { Space::new() };
              drop(v406_9);
              let v406_12: Space = if (&(v406_10)).is_empty() { Space::new() } else {
                let v408_11: Space = routine_42(c, &v391_3_cursor.path()[v391_3_origin..(v391_3_origin + 3)], &v391_3_cursor);
                compose(&(v406_10),&(v408_11))
              };
              drop(v406_10);
              let v406_13: Space = unite(&(v406_8),&(v406_12));
              join_wrapped_into(&mut v405_7_write,&((v406_13).read_zipper()),&[]);
              }
              v391_3_cursor.ascend(1);
            }
            drop(v405_7_write);
            compose(&(v404_5),&(v405_7))
          };
          drop(v404_5);
          let v404_9: Space = intersect(&(*CONSTANT_12),&(v404_2));
          drop(v404_2);
          let v404_10: Space = if has_head(&(v404_9)) { singleton(&[]) } else { Space::new() };
          drop(v404_9);
          let v404_11: Space = compose(&(v404_10),&v391_3_cursor);
          drop(v404_10);
          let v404_12: Space = unite(&(v404_8),&(v404_11));
          drop(v404_11);
          join_wrapped_into(&mut v403_10_write,&((v404_12).read_zipper()),&[]);
          }
          v391_3_cursor.ascend(1);
        }
        drop(v403_10_write);
        compose(&(v392_9),&(v403_10))
      };
      drop(v392_9);
      let v392_12: Space = unite(&(v392_7),&(v392_11));
      join_wrapped_into(&mut v391_3_write,&((v392_12).read_zipper()),&[]);
      }
      v391_3_cursor.ascend(1);
    }
    drop(v391_3_cursor);
    drop(v391_3_write);
    drop(v391_2);
    let v391_4: Space = unite(&(v391_3),&(v336_85));
    let v391_5: Space = intersect(&(v391_4),&(*capture_3));
    if !v336_85.join_into((v391_5).clone()).is_element() { break; }
  }

((v336_24).clone(),(v336_43).clone(),(v336_44).clone(),(v336_45).clone(),(v336_46).clone(),(v336_5).clone(),(v336_65).clone(),(v336_66).clone(),(v336_85).clone(),)
}

#[inline(never)]
fn native_block_2(c: &mut Context,capture_0: &View<'_, '_>,capture_1: &View<'_, '_>,capture_2: &View<'_, '_>,capture_3: &View<'_, '_>,capture_4: usize,capture_5: &Space) -> (Space,Space,) {
    let v409_2: Space = singleton(&(*capture_3).path()[capture_4..(capture_4 + 1)]);
    let v409_3: Space = intersect(&(*CONSTANT_12),&(v409_2));
    let v409_4: Space = if has_head(&(v409_3)) { singleton(&[]) } else { Space::new() };
    drop(v409_3);
    let v409_5: Space = subtract(&(*CONSTANT_0),&(v409_4));
    drop(v409_4);
    let v409_11: Space = if (&(v409_5)).is_empty() { Space::new() } else {
      let mut v410_6: Space = ((*capture_5)).clone();
      loop {
        let v411_1: Space = intersect(&(v410_6),&(*capture_2));
        let v411_2: Space = restrict_to(&(*capture_1),&(v411_1));
        drop(v411_1);
        let mut v411_3 = Space::new();
        let mut v411_3_write = v411_3.write_zipper();
        let mut v411_3_cursor = (v411_2).read_zipper();
        let v411_3_origin = v411_3_cursor.path().len();
        for v411_3_byte in v411_3_cursor.child_mask().iter() {
          v411_3_cursor.descend_to_existing_byte(v411_3_byte);
          {
          let v412_2: Space = singleton(&v411_3_cursor.path()[v411_3_origin..(v411_3_origin + 1)]);
          let v412_3: Space = intersect(&(*CONSTANT_12),&(v412_2));
          let v412_4: Space = if has_head(&(v412_3)) { singleton(&[]) } else { Space::new() };
          drop(v412_3);
          let v412_5: Space = subtract(&(*CONSTANT_0),&(v412_4));
          drop(v412_4);
          let v412_7: Space = if (&(v412_5)).is_empty() { Space::new() } else {
            let mut v413_6 = Space::new();
            let mut v413_6_write = v413_6.write_zipper();
            for v413_6_byte in v411_3_cursor.child_mask().iter() {
              v411_3_cursor.descend_to_existing_byte(v413_6_byte);
              {
              let v414_2: Space = singleton(&v411_3_cursor.path()[(v411_3_origin + 1)..(v411_3_origin + 2)]);
              let v414_3: Space = intersect(&(*CONSTANT_12),&(v414_2));
              let v414_4: Space = if has_head(&(v414_3)) { singleton(&[]) } else { Space::new() };
              drop(v414_3);
              let v414_5: Space = subtract(&(*CONSTANT_0),&(v414_4));
              drop(v414_4);
              let v414_8: Space = if (&(v414_5)).is_empty() { Space::new() } else {
                let mut v415_7 = Space::new();
                let mut v415_7_write = v415_7.write_zipper();
                for v415_7_byte in v411_3_cursor.child_mask().iter() {
                  v411_3_cursor.descend_to_existing_byte(v415_7_byte);
                  {
                  let v416_2: Space = singleton(&v411_3_cursor.path()[(v411_3_origin + 2)..(v411_3_origin + 3)]);
                  let v416_3: Space = intersect(&(*CONSTANT_12),&(v416_2));
                  let v416_4: Space = if has_head(&(v416_3)) { singleton(&[]) } else { Space::new() };
                  drop(v416_3);
                  let v416_5: Space = subtract(&(*CONSTANT_0),&(v416_4));
                  drop(v416_4);
                  let v416_8: Space = if (&(v416_5)).is_empty() { Space::new() } else {
                    let v417_7: Space = routine_41(c, &v411_3_cursor.path()[v411_3_origin..(v411_3_origin + 3)], &v411_3_cursor);
                    compose(&(v416_5),&(v417_7))
                  };
                  drop(v416_5);
                  let v416_9: Space = intersect(&(*CONSTANT_12),&(v416_2));
                  drop(v416_2);
                  let v416_10: Space = if has_head(&(v416_9)) { singleton(&[]) } else { Space::new() };
                  drop(v416_9);
                  let v416_12: Space = if (&(v416_10)).is_empty() { Space::new() } else {
                    let v418_11: Space = routine_42(c, &v411_3_cursor.path()[v411_3_origin..(v411_3_origin + 3)], &v411_3_cursor);
                    compose(&(v416_10),&(v418_11))
                  };
                  drop(v416_10);
                  let v416_13: Space = unite(&(v416_8),&(v416_12));
                  join_wrapped_into(&mut v415_7_write,&((v416_13).read_zipper()),&[]);
                  }
                  v411_3_cursor.ascend(1);
                }
                drop(v415_7_write);
                compose(&(v414_5),&(v415_7))
              };
              drop(v414_5);
              let v414_9: Space = intersect(&(*CONSTANT_12),&(v414_2));
              drop(v414_2);
              let v414_10: Space = if has_head(&(v414_9)) { singleton(&[]) } else { Space::new() };
              drop(v414_9);
              let v414_12: Space = if (&(v414_10)).is_empty() { Space::new() } else {
                let mut v419_11 = Space::new();
                let mut v419_11_write = v419_11.write_zipper();
                for v419_11_byte in v411_3_cursor.child_mask().iter() {
                  v411_3_cursor.descend_to_existing_byte(v419_11_byte);
                  {
                  let v420_2: Space = singleton(&v411_3_cursor.path()[(v411_3_origin + 2)..(v411_3_origin + 3)]);
                  let v420_3: Space = intersect(&(*CONSTANT_12),&(v420_2));
                  let v420_4: Space = if has_head(&(v420_3)) { singleton(&[]) } else { Space::new() };
                  drop(v420_3);
                  let v420_5: Space = subtract(&(*CONSTANT_0),&(v420_4));
                  drop(v420_4);
                  let v420_8: Space = if (&(v420_5)).is_empty() { Space::new() } else {
                    let v421_7: Space = routine_41(c, &v411_3_cursor.path()[v411_3_origin..(v411_3_origin + 3)], &v411_3_cursor);
                    compose(&(v420_5),&(v421_7))
                  };
                  drop(v420_5);
                  let v420_9: Space = intersect(&(*CONSTANT_12),&(v420_2));
                  drop(v420_2);
                  let v420_10: Space = if has_head(&(v420_9)) { singleton(&[]) } else { Space::new() };
                  drop(v420_9);
                  let v420_12: Space = if (&(v420_10)).is_empty() { Space::new() } else {
                    let v422_11: Space = routine_43(c, &v411_3_cursor.path()[v411_3_origin..(v411_3_origin + 3)], &v411_3_cursor);
                    compose(&(v420_10),&(v422_11))
                  };
                  drop(v420_10);
                  let v420_13: Space = unite(&(v420_8),&(v420_12));
                  join_wrapped_into(&mut v419_11_write,&((v420_13).read_zipper()),&[]);
                  }
                  v411_3_cursor.ascend(1);
                }
                drop(v419_11_write);
                compose(&(v414_10),&(v419_11))
              };
              drop(v414_10);
              let v414_13: Space = unite(&(v414_8),&(v414_12));
              join_wrapped_into(&mut v413_6_write,&((v414_13).read_zipper()),&[]);
              }
              v411_3_cursor.ascend(1);
            }
            drop(v413_6_write);
            compose(&(v412_5),&(v413_6))
          };
          drop(v412_5);
          let v412_8: Space = intersect(&(*CONSTANT_12),&(v412_2));
          drop(v412_2);
          let v412_9: Space = if has_head(&(v412_8)) { singleton(&[]) } else { Space::new() };
          drop(v412_8);
          let v412_11: Space = if (&(v412_9)).is_empty() { Space::new() } else {
            let mut v423_10 = Space::new();
            let mut v423_10_write = v423_10.write_zipper();
            for v423_10_byte in v411_3_cursor.child_mask().iter() {
              v411_3_cursor.descend_to_existing_byte(v423_10_byte);
              {
              let v424_2: Space = singleton(&v411_3_cursor.path()[(v411_3_origin + 1)..(v411_3_origin + 2)]);
              let v424_3: Space = intersect(&(*CONSTANT_12),&(v424_2));
              let v424_4: Space = if has_head(&(v424_3)) { singleton(&[]) } else { Space::new() };
              drop(v424_3);
              let v424_5: Space = subtract(&(*CONSTANT_0),&(v424_4));
              drop(v424_4);
              let v424_8: Space = if (&(v424_5)).is_empty() { Space::new() } else {
                let mut v425_7 = Space::new();
                let mut v425_7_write = v425_7.write_zipper();
                for v425_7_byte in v411_3_cursor.child_mask().iter() {
                  v411_3_cursor.descend_to_existing_byte(v425_7_byte);
                  {
                  let v426_2: Space = singleton(&v411_3_cursor.path()[(v411_3_origin + 2)..(v411_3_origin + 3)]);
                  let v426_3: Space = intersect(&(*CONSTANT_12),&(v426_2));
                  let v426_4: Space = if has_head(&(v426_3)) { singleton(&[]) } else { Space::new() };
                  drop(v426_3);
                  let v426_5: Space = subtract(&(*CONSTANT_0),&(v426_4));
                  drop(v426_4);
                  let v426_8: Space = if (&(v426_5)).is_empty() { Space::new() } else {
                    let v427_7: Space = routine_41(c, &v411_3_cursor.path()[v411_3_origin..(v411_3_origin + 3)], &v411_3_cursor);
                    compose(&(v426_5),&(v427_7))
                  };
                  drop(v426_5);
                  let v426_9: Space = intersect(&(*CONSTANT_12),&(v426_2));
                  drop(v426_2);
                  let v426_10: Space = if has_head(&(v426_9)) { singleton(&[]) } else { Space::new() };
                  drop(v426_9);
                  let v426_12: Space = if (&(v426_10)).is_empty() { Space::new() } else {
                    let v428_11: Space = routine_42(c, &v411_3_cursor.path()[v411_3_origin..(v411_3_origin + 3)], &v411_3_cursor);
                    compose(&(v426_10),&(v428_11))
                  };
                  drop(v426_10);
                  let v426_13: Space = unite(&(v426_8),&(v426_12));
                  join_wrapped_into(&mut v425_7_write,&((v426_13).read_zipper()),&[]);
                  }
                  v411_3_cursor.ascend(1);
                }
                drop(v425_7_write);
                compose(&(v424_5),&(v425_7))
              };
              drop(v424_5);
              let v424_9: Space = intersect(&(*CONSTANT_12),&(v424_2));
              drop(v424_2);
              let v424_10: Space = if has_head(&(v424_9)) { singleton(&[]) } else { Space::new() };
              drop(v424_9);
              let v424_11: Space = compose(&(v424_10),&v411_3_cursor);
              drop(v424_10);
              let v424_12: Space = unite(&(v424_8),&(v424_11));
              drop(v424_11);
              join_wrapped_into(&mut v423_10_write,&((v424_12).read_zipper()),&[]);
              }
              v411_3_cursor.ascend(1);
            }
            drop(v423_10_write);
            compose(&(v412_9),&(v423_10))
          };
          drop(v412_9);
          let v412_12: Space = unite(&(v412_7),&(v412_11));
          join_wrapped_into(&mut v411_3_write,&((v412_12).read_zipper()),&[]);
          }
          v411_3_cursor.ascend(1);
        }
        drop(v411_3_cursor);
        drop(v411_3_write);
        drop(v411_2);
        let v411_4: Space = unite(&(v411_3),&(v410_6));
        let v411_5: Space = intersect(&(v411_4),&(*capture_2));
        if !v410_6.join_into((v411_5).clone()).is_element() { break; }
      }
      let v410_7: Space = subtract(&(*capture_2),&(v410_6));
      let mut v410_8: Space = ((*capture_5)).clone();
      loop {
        let v429_1: Space = intersect(&(v410_8),&(*capture_2));
        let v429_2: Space = restrict_to(&(*capture_0),&(v429_1));
        drop(v429_1);
        let mut v429_3 = Space::new();
        let mut v429_3_write = v429_3.write_zipper();
        let mut v429_3_cursor = (v429_2).read_zipper();
        let v429_3_origin = v429_3_cursor.path().len();
        for v429_3_byte in v429_3_cursor.child_mask().iter() {
          v429_3_cursor.descend_to_existing_byte(v429_3_byte);
          {
          let v430_2: Space = singleton(&v429_3_cursor.path()[v429_3_origin..(v429_3_origin + 1)]);
          let v430_3: Space = intersect(&(*CONSTANT_12),&(v430_2));
          let v430_4: Space = if has_head(&(v430_3)) { singleton(&[]) } else { Space::new() };
          drop(v430_3);
          let v430_5: Space = subtract(&(*CONSTANT_0),&(v430_4));
          drop(v430_4);
          let v430_7: Space = if (&(v430_5)).is_empty() { Space::new() } else {
            let mut v431_6 = Space::new();
            let mut v431_6_write = v431_6.write_zipper();
            for v431_6_byte in v429_3_cursor.child_mask().iter() {
              v429_3_cursor.descend_to_existing_byte(v431_6_byte);
              {
              let v432_2: Space = singleton(&v429_3_cursor.path()[(v429_3_origin + 1)..(v429_3_origin + 2)]);
              let v432_3: Space = intersect(&(*CONSTANT_12),&(v432_2));
              let v432_4: Space = if has_head(&(v432_3)) { singleton(&[]) } else { Space::new() };
              drop(v432_3);
              let v432_5: Space = subtract(&(*CONSTANT_0),&(v432_4));
              drop(v432_4);
              let v432_8: Space = if (&(v432_5)).is_empty() { Space::new() } else {
                let mut v433_7 = Space::new();
                let mut v433_7_write = v433_7.write_zipper();
                for v433_7_byte in v429_3_cursor.child_mask().iter() {
                  v429_3_cursor.descend_to_existing_byte(v433_7_byte);
                  {
                  let v434_2: Space = singleton(&v429_3_cursor.path()[(v429_3_origin + 2)..(v429_3_origin + 3)]);
                  let v434_3: Space = intersect(&(*CONSTANT_12),&(v434_2));
                  let v434_4: Space = if has_head(&(v434_3)) { singleton(&[]) } else { Space::new() };
                  drop(v434_3);
                  let v434_5: Space = subtract(&(*CONSTANT_0),&(v434_4));
                  drop(v434_4);
                  let v434_8: Space = if (&(v434_5)).is_empty() { Space::new() } else {
                    let v435_7: Space = routine_41(c, &v429_3_cursor.path()[v429_3_origin..(v429_3_origin + 3)], &v429_3_cursor);
                    compose(&(v434_5),&(v435_7))
                  };
                  drop(v434_5);
                  let v434_9: Space = intersect(&(*CONSTANT_12),&(v434_2));
                  drop(v434_2);
                  let v434_10: Space = if has_head(&(v434_9)) { singleton(&[]) } else { Space::new() };
                  drop(v434_9);
                  let v434_12: Space = if (&(v434_10)).is_empty() { Space::new() } else {
                    let v436_11: Space = routine_42(c, &v429_3_cursor.path()[v429_3_origin..(v429_3_origin + 3)], &v429_3_cursor);
                    compose(&(v434_10),&(v436_11))
                  };
                  drop(v434_10);
                  let v434_13: Space = unite(&(v434_8),&(v434_12));
                  join_wrapped_into(&mut v433_7_write,&((v434_13).read_zipper()),&[]);
                  }
                  v429_3_cursor.ascend(1);
                }
                drop(v433_7_write);
                compose(&(v432_5),&(v433_7))
              };
              drop(v432_5);
              let v432_9: Space = intersect(&(*CONSTANT_12),&(v432_2));
              drop(v432_2);
              let v432_10: Space = if has_head(&(v432_9)) { singleton(&[]) } else { Space::new() };
              drop(v432_9);
              let v432_12: Space = if (&(v432_10)).is_empty() { Space::new() } else {
                let mut v437_11 = Space::new();
                let mut v437_11_write = v437_11.write_zipper();
                for v437_11_byte in v429_3_cursor.child_mask().iter() {
                  v429_3_cursor.descend_to_existing_byte(v437_11_byte);
                  {
                  let v438_2: Space = singleton(&v429_3_cursor.path()[(v429_3_origin + 2)..(v429_3_origin + 3)]);
                  let v438_3: Space = intersect(&(*CONSTANT_12),&(v438_2));
                  let v438_4: Space = if has_head(&(v438_3)) { singleton(&[]) } else { Space::new() };
                  drop(v438_3);
                  let v438_5: Space = subtract(&(*CONSTANT_0),&(v438_4));
                  drop(v438_4);
                  let v438_8: Space = if (&(v438_5)).is_empty() { Space::new() } else {
                    let v439_7: Space = routine_41(c, &v429_3_cursor.path()[v429_3_origin..(v429_3_origin + 3)], &v429_3_cursor);
                    compose(&(v438_5),&(v439_7))
                  };
                  drop(v438_5);
                  let v438_9: Space = intersect(&(*CONSTANT_12),&(v438_2));
                  drop(v438_2);
                  let v438_10: Space = if has_head(&(v438_9)) { singleton(&[]) } else { Space::new() };
                  drop(v438_9);
                  let v438_12: Space = if (&(v438_10)).is_empty() { Space::new() } else {
                    let v440_11: Space = routine_43(c, &v429_3_cursor.path()[v429_3_origin..(v429_3_origin + 3)], &v429_3_cursor);
                    compose(&(v438_10),&(v440_11))
                  };
                  drop(v438_10);
                  let v438_13: Space = unite(&(v438_8),&(v438_12));
                  join_wrapped_into(&mut v437_11_write,&((v438_13).read_zipper()),&[]);
                  }
                  v429_3_cursor.ascend(1);
                }
                drop(v437_11_write);
                compose(&(v432_10),&(v437_11))
              };
              drop(v432_10);
              let v432_13: Space = unite(&(v432_8),&(v432_12));
              join_wrapped_into(&mut v431_6_write,&((v432_13).read_zipper()),&[]);
              }
              v429_3_cursor.ascend(1);
            }
            drop(v431_6_write);
            compose(&(v430_5),&(v431_6))
          };
          drop(v430_5);
          let v430_8: Space = intersect(&(*CONSTANT_12),&(v430_2));
          drop(v430_2);
          let v430_9: Space = if has_head(&(v430_8)) { singleton(&[]) } else { Space::new() };
          drop(v430_8);
          let v430_11: Space = if (&(v430_9)).is_empty() { Space::new() } else {
            let mut v441_10 = Space::new();
            let mut v441_10_write = v441_10.write_zipper();
            for v441_10_byte in v429_3_cursor.child_mask().iter() {
              v429_3_cursor.descend_to_existing_byte(v441_10_byte);
              {
              let v442_2: Space = singleton(&v429_3_cursor.path()[(v429_3_origin + 1)..(v429_3_origin + 2)]);
              let v442_3: Space = intersect(&(*CONSTANT_12),&(v442_2));
              let v442_4: Space = if has_head(&(v442_3)) { singleton(&[]) } else { Space::new() };
              drop(v442_3);
              let v442_5: Space = subtract(&(*CONSTANT_0),&(v442_4));
              drop(v442_4);
              let v442_8: Space = if (&(v442_5)).is_empty() { Space::new() } else {
                let mut v443_7 = Space::new();
                let mut v443_7_write = v443_7.write_zipper();
                for v443_7_byte in v429_3_cursor.child_mask().iter() {
                  v429_3_cursor.descend_to_existing_byte(v443_7_byte);
                  {
                  let v444_2: Space = singleton(&v429_3_cursor.path()[(v429_3_origin + 2)..(v429_3_origin + 3)]);
                  let v444_3: Space = intersect(&(*CONSTANT_12),&(v444_2));
                  let v444_4: Space = if has_head(&(v444_3)) { singleton(&[]) } else { Space::new() };
                  drop(v444_3);
                  let v444_5: Space = subtract(&(*CONSTANT_0),&(v444_4));
                  drop(v444_4);
                  let v444_8: Space = if (&(v444_5)).is_empty() { Space::new() } else {
                    let v445_7: Space = routine_41(c, &v429_3_cursor.path()[v429_3_origin..(v429_3_origin + 3)], &v429_3_cursor);
                    compose(&(v444_5),&(v445_7))
                  };
                  drop(v444_5);
                  let v444_9: Space = intersect(&(*CONSTANT_12),&(v444_2));
                  drop(v444_2);
                  let v444_10: Space = if has_head(&(v444_9)) { singleton(&[]) } else { Space::new() };
                  drop(v444_9);
                  let v444_12: Space = if (&(v444_10)).is_empty() { Space::new() } else {
                    let v446_11: Space = routine_42(c, &v429_3_cursor.path()[v429_3_origin..(v429_3_origin + 3)], &v429_3_cursor);
                    compose(&(v444_10),&(v446_11))
                  };
                  drop(v444_10);
                  let v444_13: Space = unite(&(v444_8),&(v444_12));
                  join_wrapped_into(&mut v443_7_write,&((v444_13).read_zipper()),&[]);
                  }
                  v429_3_cursor.ascend(1);
                }
                drop(v443_7_write);
                compose(&(v442_5),&(v443_7))
              };
              drop(v442_5);
              let v442_9: Space = intersect(&(*CONSTANT_12),&(v442_2));
              drop(v442_2);
              let v442_10: Space = if has_head(&(v442_9)) { singleton(&[]) } else { Space::new() };
              drop(v442_9);
              let v442_11: Space = compose(&(v442_10),&v429_3_cursor);
              drop(v442_10);
              let v442_12: Space = unite(&(v442_8),&(v442_11));
              drop(v442_11);
              join_wrapped_into(&mut v441_10_write,&((v442_12).read_zipper()),&[]);
              }
              v429_3_cursor.ascend(1);
            }
            drop(v441_10_write);
            compose(&(v430_9),&(v441_10))
          };
          drop(v430_9);
          let v430_12: Space = unite(&(v430_7),&(v430_11));
          join_wrapped_into(&mut v429_3_write,&((v430_12).read_zipper()),&[]);
          }
          v429_3_cursor.ascend(1);
        }
        drop(v429_3_cursor);
        drop(v429_3_write);
        drop(v429_2);
        let v429_4: Space = unite(&(v429_3),&(v410_8));
        let v429_5: Space = intersect(&(v429_4),&(*capture_2));
        if !v410_8.join_into((v429_5).clone()).is_element() { break; }
      }
      let v410_9: Space = subtract(&(v410_7),&(v410_8));
      let v410_10: Space = routine_16(c, &(*capture_3).path()[capture_4..(capture_4 + 1)], &(*capture_3), &(*capture_0), &(*capture_1), &((v410_9).read_zipper()));
      compose(&(v409_5),&(v410_10))
    };
    drop(v409_5);
    let v409_12: Space = intersect(&(*CONSTANT_12),&(v409_2));
    drop(v409_2);
    let v409_13: Space = if has_head(&(v409_12)) { singleton(&[]) } else { Space::new() };
    drop(v409_12);
    let v409_19: Space = if (&(v409_13)).is_empty() { Space::new() } else {
      let mut v447_14: Space = ((*capture_5)).clone();
      loop {
        let v448_1: Space = intersect(&(v447_14),&(*capture_2));
        let v448_2: Space = restrict_to(&(*capture_1),&(v448_1));
        drop(v448_1);
        let mut v448_3 = Space::new();
        let mut v448_3_write = v448_3.write_zipper();
        let mut v448_3_cursor = (v448_2).read_zipper();
        let v448_3_origin = v448_3_cursor.path().len();
        for v448_3_byte in v448_3_cursor.child_mask().iter() {
          v448_3_cursor.descend_to_existing_byte(v448_3_byte);
          {
          let v449_2: Space = singleton(&v448_3_cursor.path()[v448_3_origin..(v448_3_origin + 1)]);
          let v449_3: Space = intersect(&(*CONSTANT_12),&(v449_2));
          let v449_4: Space = if has_head(&(v449_3)) { singleton(&[]) } else { Space::new() };
          drop(v449_3);
          let v449_5: Space = subtract(&(*CONSTANT_0),&(v449_4));
          drop(v449_4);
          let v449_7: Space = if (&(v449_5)).is_empty() { Space::new() } else {
            let mut v450_6 = Space::new();
            let mut v450_6_write = v450_6.write_zipper();
            for v450_6_byte in v448_3_cursor.child_mask().iter() {
              v448_3_cursor.descend_to_existing_byte(v450_6_byte);
              {
              let v451_2: Space = singleton(&v448_3_cursor.path()[(v448_3_origin + 1)..(v448_3_origin + 2)]);
              let v451_3: Space = intersect(&(*CONSTANT_12),&(v451_2));
              let v451_4: Space = if has_head(&(v451_3)) { singleton(&[]) } else { Space::new() };
              drop(v451_3);
              let v451_5: Space = subtract(&(*CONSTANT_0),&(v451_4));
              drop(v451_4);
              let v451_8: Space = if (&(v451_5)).is_empty() { Space::new() } else {
                let mut v452_7 = Space::new();
                let mut v452_7_write = v452_7.write_zipper();
                for v452_7_byte in v448_3_cursor.child_mask().iter() {
                  v448_3_cursor.descend_to_existing_byte(v452_7_byte);
                  {
                  let v453_2: Space = singleton(&v448_3_cursor.path()[(v448_3_origin + 2)..(v448_3_origin + 3)]);
                  let v453_3: Space = intersect(&(*CONSTANT_12),&(v453_2));
                  let v453_4: Space = if has_head(&(v453_3)) { singleton(&[]) } else { Space::new() };
                  drop(v453_3);
                  let v453_5: Space = subtract(&(*CONSTANT_0),&(v453_4));
                  drop(v453_4);
                  let v453_8: Space = if (&(v453_5)).is_empty() { Space::new() } else {
                    let v454_7: Space = routine_41(c, &v448_3_cursor.path()[v448_3_origin..(v448_3_origin + 3)], &v448_3_cursor);
                    compose(&(v453_5),&(v454_7))
                  };
                  drop(v453_5);
                  let v453_9: Space = intersect(&(*CONSTANT_12),&(v453_2));
                  drop(v453_2);
                  let v453_10: Space = if has_head(&(v453_9)) { singleton(&[]) } else { Space::new() };
                  drop(v453_9);
                  let v453_12: Space = if (&(v453_10)).is_empty() { Space::new() } else {
                    let v455_11: Space = routine_42(c, &v448_3_cursor.path()[v448_3_origin..(v448_3_origin + 3)], &v448_3_cursor);
                    compose(&(v453_10),&(v455_11))
                  };
                  drop(v453_10);
                  let v453_13: Space = unite(&(v453_8),&(v453_12));
                  join_wrapped_into(&mut v452_7_write,&((v453_13).read_zipper()),&[]);
                  }
                  v448_3_cursor.ascend(1);
                }
                drop(v452_7_write);
                compose(&(v451_5),&(v452_7))
              };
              drop(v451_5);
              let v451_9: Space = intersect(&(*CONSTANT_12),&(v451_2));
              drop(v451_2);
              let v451_10: Space = if has_head(&(v451_9)) { singleton(&[]) } else { Space::new() };
              drop(v451_9);
              let v451_12: Space = if (&(v451_10)).is_empty() { Space::new() } else {
                let mut v456_11 = Space::new();
                let mut v456_11_write = v456_11.write_zipper();
                for v456_11_byte in v448_3_cursor.child_mask().iter() {
                  v448_3_cursor.descend_to_existing_byte(v456_11_byte);
                  {
                  let v457_2: Space = singleton(&v448_3_cursor.path()[(v448_3_origin + 2)..(v448_3_origin + 3)]);
                  let v457_3: Space = intersect(&(*CONSTANT_12),&(v457_2));
                  let v457_4: Space = if has_head(&(v457_3)) { singleton(&[]) } else { Space::new() };
                  drop(v457_3);
                  let v457_5: Space = subtract(&(*CONSTANT_0),&(v457_4));
                  drop(v457_4);
                  let v457_8: Space = if (&(v457_5)).is_empty() { Space::new() } else {
                    let v458_7: Space = routine_41(c, &v448_3_cursor.path()[v448_3_origin..(v448_3_origin + 3)], &v448_3_cursor);
                    compose(&(v457_5),&(v458_7))
                  };
                  drop(v457_5);
                  let v457_9: Space = intersect(&(*CONSTANT_12),&(v457_2));
                  drop(v457_2);
                  let v457_10: Space = if has_head(&(v457_9)) { singleton(&[]) } else { Space::new() };
                  drop(v457_9);
                  let v457_12: Space = if (&(v457_10)).is_empty() { Space::new() } else {
                    let v459_11: Space = routine_43(c, &v448_3_cursor.path()[v448_3_origin..(v448_3_origin + 3)], &v448_3_cursor);
                    compose(&(v457_10),&(v459_11))
                  };
                  drop(v457_10);
                  let v457_13: Space = unite(&(v457_8),&(v457_12));
                  join_wrapped_into(&mut v456_11_write,&((v457_13).read_zipper()),&[]);
                  }
                  v448_3_cursor.ascend(1);
                }
                drop(v456_11_write);
                compose(&(v451_10),&(v456_11))
              };
              drop(v451_10);
              let v451_13: Space = unite(&(v451_8),&(v451_12));
              join_wrapped_into(&mut v450_6_write,&((v451_13).read_zipper()),&[]);
              }
              v448_3_cursor.ascend(1);
            }
            drop(v450_6_write);
            compose(&(v449_5),&(v450_6))
          };
          drop(v449_5);
          let v449_8: Space = intersect(&(*CONSTANT_12),&(v449_2));
          drop(v449_2);
          let v449_9: Space = if has_head(&(v449_8)) { singleton(&[]) } else { Space::new() };
          drop(v449_8);
          let v449_11: Space = if (&(v449_9)).is_empty() { Space::new() } else {
            let mut v460_10 = Space::new();
            let mut v460_10_write = v460_10.write_zipper();
            for v460_10_byte in v448_3_cursor.child_mask().iter() {
              v448_3_cursor.descend_to_existing_byte(v460_10_byte);
              {
              let v461_2: Space = singleton(&v448_3_cursor.path()[(v448_3_origin + 1)..(v448_3_origin + 2)]);
              let v461_3: Space = intersect(&(*CONSTANT_12),&(v461_2));
              let v461_4: Space = if has_head(&(v461_3)) { singleton(&[]) } else { Space::new() };
              drop(v461_3);
              let v461_5: Space = subtract(&(*CONSTANT_0),&(v461_4));
              drop(v461_4);
              let v461_8: Space = if (&(v461_5)).is_empty() { Space::new() } else {
                let mut v462_7 = Space::new();
                let mut v462_7_write = v462_7.write_zipper();
                for v462_7_byte in v448_3_cursor.child_mask().iter() {
                  v448_3_cursor.descend_to_existing_byte(v462_7_byte);
                  {
                  let v463_2: Space = singleton(&v448_3_cursor.path()[(v448_3_origin + 2)..(v448_3_origin + 3)]);
                  let v463_3: Space = intersect(&(*CONSTANT_12),&(v463_2));
                  let v463_4: Space = if has_head(&(v463_3)) { singleton(&[]) } else { Space::new() };
                  drop(v463_3);
                  let v463_5: Space = subtract(&(*CONSTANT_0),&(v463_4));
                  drop(v463_4);
                  let v463_8: Space = if (&(v463_5)).is_empty() { Space::new() } else {
                    let v464_7: Space = routine_41(c, &v448_3_cursor.path()[v448_3_origin..(v448_3_origin + 3)], &v448_3_cursor);
                    compose(&(v463_5),&(v464_7))
                  };
                  drop(v463_5);
                  let v463_9: Space = intersect(&(*CONSTANT_12),&(v463_2));
                  drop(v463_2);
                  let v463_10: Space = if has_head(&(v463_9)) { singleton(&[]) } else { Space::new() };
                  drop(v463_9);
                  let v463_12: Space = if (&(v463_10)).is_empty() { Space::new() } else {
                    let v465_11: Space = routine_42(c, &v448_3_cursor.path()[v448_3_origin..(v448_3_origin + 3)], &v448_3_cursor);
                    compose(&(v463_10),&(v465_11))
                  };
                  drop(v463_10);
                  let v463_13: Space = unite(&(v463_8),&(v463_12));
                  join_wrapped_into(&mut v462_7_write,&((v463_13).read_zipper()),&[]);
                  }
                  v448_3_cursor.ascend(1);
                }
                drop(v462_7_write);
                compose(&(v461_5),&(v462_7))
              };
              drop(v461_5);
              let v461_9: Space = intersect(&(*CONSTANT_12),&(v461_2));
              drop(v461_2);
              let v461_10: Space = if has_head(&(v461_9)) { singleton(&[]) } else { Space::new() };
              drop(v461_9);
              let v461_11: Space = compose(&(v461_10),&v448_3_cursor);
              drop(v461_10);
              let v461_12: Space = unite(&(v461_8),&(v461_11));
              drop(v461_11);
              join_wrapped_into(&mut v460_10_write,&((v461_12).read_zipper()),&[]);
              }
              v448_3_cursor.ascend(1);
            }
            drop(v460_10_write);
            compose(&(v449_9),&(v460_10))
          };
          drop(v449_9);
          let v449_12: Space = unite(&(v449_7),&(v449_11));
          join_wrapped_into(&mut v448_3_write,&((v449_12).read_zipper()),&[]);
          }
          v448_3_cursor.ascend(1);
        }
        drop(v448_3_cursor);
        drop(v448_3_write);
        drop(v448_2);
        let v448_4: Space = unite(&(v448_3),&(v447_14));
        let v448_5: Space = intersect(&(v448_4),&(*capture_2));
        if !v447_14.join_into((v448_5).clone()).is_element() { break; }
      }
      let v447_15: Space = subtract(&(*capture_2),&(v447_14));
      let mut v447_16: Space = ((*capture_5)).clone();
      loop {
        let v466_1: Space = intersect(&(v447_16),&(*capture_2));
        let v466_2: Space = restrict_to(&(*capture_0),&(v466_1));
        drop(v466_1);
        let mut v466_3 = Space::new();
        let mut v466_3_write = v466_3.write_zipper();
        let mut v466_3_cursor = (v466_2).read_zipper();
        let v466_3_origin = v466_3_cursor.path().len();
        for v466_3_byte in v466_3_cursor.child_mask().iter() {
          v466_3_cursor.descend_to_existing_byte(v466_3_byte);
          {
          let v467_2: Space = singleton(&v466_3_cursor.path()[v466_3_origin..(v466_3_origin + 1)]);
          let v467_3: Space = intersect(&(*CONSTANT_12),&(v467_2));
          let v467_4: Space = if has_head(&(v467_3)) { singleton(&[]) } else { Space::new() };
          drop(v467_3);
          let v467_5: Space = subtract(&(*CONSTANT_0),&(v467_4));
          drop(v467_4);
          let v467_7: Space = if (&(v467_5)).is_empty() { Space::new() } else {
            let mut v468_6 = Space::new();
            let mut v468_6_write = v468_6.write_zipper();
            for v468_6_byte in v466_3_cursor.child_mask().iter() {
              v466_3_cursor.descend_to_existing_byte(v468_6_byte);
              {
              let v469_2: Space = singleton(&v466_3_cursor.path()[(v466_3_origin + 1)..(v466_3_origin + 2)]);
              let v469_3: Space = intersect(&(*CONSTANT_12),&(v469_2));
              let v469_4: Space = if has_head(&(v469_3)) { singleton(&[]) } else { Space::new() };
              drop(v469_3);
              let v469_5: Space = subtract(&(*CONSTANT_0),&(v469_4));
              drop(v469_4);
              let v469_8: Space = if (&(v469_5)).is_empty() { Space::new() } else {
                let mut v470_7 = Space::new();
                let mut v470_7_write = v470_7.write_zipper();
                for v470_7_byte in v466_3_cursor.child_mask().iter() {
                  v466_3_cursor.descend_to_existing_byte(v470_7_byte);
                  {
                  let v471_2: Space = singleton(&v466_3_cursor.path()[(v466_3_origin + 2)..(v466_3_origin + 3)]);
                  let v471_3: Space = intersect(&(*CONSTANT_12),&(v471_2));
                  let v471_4: Space = if has_head(&(v471_3)) { singleton(&[]) } else { Space::new() };
                  drop(v471_3);
                  let v471_5: Space = subtract(&(*CONSTANT_0),&(v471_4));
                  drop(v471_4);
                  let v471_8: Space = if (&(v471_5)).is_empty() { Space::new() } else {
                    let v472_7: Space = routine_41(c, &v466_3_cursor.path()[v466_3_origin..(v466_3_origin + 3)], &v466_3_cursor);
                    compose(&(v471_5),&(v472_7))
                  };
                  drop(v471_5);
                  let v471_9: Space = intersect(&(*CONSTANT_12),&(v471_2));
                  drop(v471_2);
                  let v471_10: Space = if has_head(&(v471_9)) { singleton(&[]) } else { Space::new() };
                  drop(v471_9);
                  let v471_12: Space = if (&(v471_10)).is_empty() { Space::new() } else {
                    let v473_11: Space = routine_42(c, &v466_3_cursor.path()[v466_3_origin..(v466_3_origin + 3)], &v466_3_cursor);
                    compose(&(v471_10),&(v473_11))
                  };
                  drop(v471_10);
                  let v471_13: Space = unite(&(v471_8),&(v471_12));
                  join_wrapped_into(&mut v470_7_write,&((v471_13).read_zipper()),&[]);
                  }
                  v466_3_cursor.ascend(1);
                }
                drop(v470_7_write);
                compose(&(v469_5),&(v470_7))
              };
              drop(v469_5);
              let v469_9: Space = intersect(&(*CONSTANT_12),&(v469_2));
              drop(v469_2);
              let v469_10: Space = if has_head(&(v469_9)) { singleton(&[]) } else { Space::new() };
              drop(v469_9);
              let v469_12: Space = if (&(v469_10)).is_empty() { Space::new() } else {
                let mut v474_11 = Space::new();
                let mut v474_11_write = v474_11.write_zipper();
                for v474_11_byte in v466_3_cursor.child_mask().iter() {
                  v466_3_cursor.descend_to_existing_byte(v474_11_byte);
                  {
                  let v475_2: Space = singleton(&v466_3_cursor.path()[(v466_3_origin + 2)..(v466_3_origin + 3)]);
                  let v475_3: Space = intersect(&(*CONSTANT_12),&(v475_2));
                  let v475_4: Space = if has_head(&(v475_3)) { singleton(&[]) } else { Space::new() };
                  drop(v475_3);
                  let v475_5: Space = subtract(&(*CONSTANT_0),&(v475_4));
                  drop(v475_4);
                  let v475_8: Space = if (&(v475_5)).is_empty() { Space::new() } else {
                    let v476_7: Space = routine_41(c, &v466_3_cursor.path()[v466_3_origin..(v466_3_origin + 3)], &v466_3_cursor);
                    compose(&(v475_5),&(v476_7))
                  };
                  drop(v475_5);
                  let v475_9: Space = intersect(&(*CONSTANT_12),&(v475_2));
                  drop(v475_2);
                  let v475_10: Space = if has_head(&(v475_9)) { singleton(&[]) } else { Space::new() };
                  drop(v475_9);
                  let v475_12: Space = if (&(v475_10)).is_empty() { Space::new() } else {
                    let v477_11: Space = routine_43(c, &v466_3_cursor.path()[v466_3_origin..(v466_3_origin + 3)], &v466_3_cursor);
                    compose(&(v475_10),&(v477_11))
                  };
                  drop(v475_10);
                  let v475_13: Space = unite(&(v475_8),&(v475_12));
                  join_wrapped_into(&mut v474_11_write,&((v475_13).read_zipper()),&[]);
                  }
                  v466_3_cursor.ascend(1);
                }
                drop(v474_11_write);
                compose(&(v469_10),&(v474_11))
              };
              drop(v469_10);
              let v469_13: Space = unite(&(v469_8),&(v469_12));
              join_wrapped_into(&mut v468_6_write,&((v469_13).read_zipper()),&[]);
              }
              v466_3_cursor.ascend(1);
            }
            drop(v468_6_write);
            compose(&(v467_5),&(v468_6))
          };
          drop(v467_5);
          let v467_8: Space = intersect(&(*CONSTANT_12),&(v467_2));
          drop(v467_2);
          let v467_9: Space = if has_head(&(v467_8)) { singleton(&[]) } else { Space::new() };
          drop(v467_8);
          let v467_11: Space = if (&(v467_9)).is_empty() { Space::new() } else {
            let mut v478_10 = Space::new();
            let mut v478_10_write = v478_10.write_zipper();
            for v478_10_byte in v466_3_cursor.child_mask().iter() {
              v466_3_cursor.descend_to_existing_byte(v478_10_byte);
              {
              let v479_2: Space = singleton(&v466_3_cursor.path()[(v466_3_origin + 1)..(v466_3_origin + 2)]);
              let v479_3: Space = intersect(&(*CONSTANT_12),&(v479_2));
              let v479_4: Space = if has_head(&(v479_3)) { singleton(&[]) } else { Space::new() };
              drop(v479_3);
              let v479_5: Space = subtract(&(*CONSTANT_0),&(v479_4));
              drop(v479_4);
              let v479_8: Space = if (&(v479_5)).is_empty() { Space::new() } else {
                let mut v480_7 = Space::new();
                let mut v480_7_write = v480_7.write_zipper();
                for v480_7_byte in v466_3_cursor.child_mask().iter() {
                  v466_3_cursor.descend_to_existing_byte(v480_7_byte);
                  {
                  let v481_2: Space = singleton(&v466_3_cursor.path()[(v466_3_origin + 2)..(v466_3_origin + 3)]);
                  let v481_3: Space = intersect(&(*CONSTANT_12),&(v481_2));
                  let v481_4: Space = if has_head(&(v481_3)) { singleton(&[]) } else { Space::new() };
                  drop(v481_3);
                  let v481_5: Space = subtract(&(*CONSTANT_0),&(v481_4));
                  drop(v481_4);
                  let v481_8: Space = if (&(v481_5)).is_empty() { Space::new() } else {
                    let v482_7: Space = routine_41(c, &v466_3_cursor.path()[v466_3_origin..(v466_3_origin + 3)], &v466_3_cursor);
                    compose(&(v481_5),&(v482_7))
                  };
                  drop(v481_5);
                  let v481_9: Space = intersect(&(*CONSTANT_12),&(v481_2));
                  drop(v481_2);
                  let v481_10: Space = if has_head(&(v481_9)) { singleton(&[]) } else { Space::new() };
                  drop(v481_9);
                  let v481_12: Space = if (&(v481_10)).is_empty() { Space::new() } else {
                    let v483_11: Space = routine_42(c, &v466_3_cursor.path()[v466_3_origin..(v466_3_origin + 3)], &v466_3_cursor);
                    compose(&(v481_10),&(v483_11))
                  };
                  drop(v481_10);
                  let v481_13: Space = unite(&(v481_8),&(v481_12));
                  join_wrapped_into(&mut v480_7_write,&((v481_13).read_zipper()),&[]);
                  }
                  v466_3_cursor.ascend(1);
                }
                drop(v480_7_write);
                compose(&(v479_5),&(v480_7))
              };
              drop(v479_5);
              let v479_9: Space = intersect(&(*CONSTANT_12),&(v479_2));
              drop(v479_2);
              let v479_10: Space = if has_head(&(v479_9)) { singleton(&[]) } else { Space::new() };
              drop(v479_9);
              let v479_11: Space = compose(&(v479_10),&v466_3_cursor);
              drop(v479_10);
              let v479_12: Space = unite(&(v479_8),&(v479_11));
              drop(v479_11);
              join_wrapped_into(&mut v478_10_write,&((v479_12).read_zipper()),&[]);
              }
              v466_3_cursor.ascend(1);
            }
            drop(v478_10_write);
            compose(&(v467_9),&(v478_10))
          };
          drop(v467_9);
          let v467_12: Space = unite(&(v467_7),&(v467_11));
          join_wrapped_into(&mut v466_3_write,&((v467_12).read_zipper()),&[]);
          }
          v466_3_cursor.ascend(1);
        }
        drop(v466_3_cursor);
        drop(v466_3_write);
        drop(v466_2);
        let v466_4: Space = unite(&(v466_3),&(v447_16));
        let v466_5: Space = intersect(&(v466_4),&(*capture_2));
        if !v447_16.join_into((v466_5).clone()).is_element() { break; }
      }
      let v447_17: Space = subtract(&(v447_15),&(v447_16));
      let v447_18: Space = routine_17(c, &(*capture_3).path()[capture_4..(capture_4 + 1)], &(*capture_3), &(*capture_0), &(*capture_1), &((v447_17).read_zipper()));
      compose(&(v409_13),&(v447_18))
    };
    drop(v409_13);

((v409_11).clone(),(v409_19).clone(),)
}

#[inline(never)]
fn native_block_3(c: &mut Context,capture_0: &View<'_, '_>,capture_1: &View<'_, '_>,capture_2: &View<'_, '_>,capture_3: &View<'_, '_>,capture_4: usize,capture_5: &Space) -> (Space,Space,) {
    let v520_2: Space = singleton(&(*capture_3).path()[capture_4..(capture_4 + 1)]);
    let v520_3: Space = intersect(&(*CONSTANT_12),&(v520_2));
    let v520_4: Space = if has_head(&(v520_3)) { singleton(&[]) } else { Space::new() };
    drop(v520_3);
    let v520_5: Space = subtract(&(*CONSTANT_0),&(v520_4));
    drop(v520_4);
    let v520_10: Space = if (&(v520_5)).is_empty() { Space::new() } else {
      let mut v521_6: Space = ((*capture_5)).clone();
      loop {
        let v522_1: Space = intersect(&(v521_6),&(*capture_2));
        let v522_2: Space = restrict_to(&(*capture_0),&(v522_1));
        drop(v522_1);
        let mut v522_3 = Space::new();
        let mut v522_3_write = v522_3.write_zipper();
        let mut v522_3_cursor = (v522_2).read_zipper();
        let v522_3_origin = v522_3_cursor.path().len();
        for v522_3_byte in v522_3_cursor.child_mask().iter() {
          v522_3_cursor.descend_to_existing_byte(v522_3_byte);
          {
          let v523_2: Space = singleton(&v522_3_cursor.path()[v522_3_origin..(v522_3_origin + 1)]);
          let v523_3: Space = intersect(&(*CONSTANT_12),&(v523_2));
          let v523_4: Space = if has_head(&(v523_3)) { singleton(&[]) } else { Space::new() };
          drop(v523_3);
          let v523_5: Space = subtract(&(*CONSTANT_0),&(v523_4));
          drop(v523_4);
          let v523_7: Space = if (&(v523_5)).is_empty() { Space::new() } else {
            let mut v524_6 = Space::new();
            let mut v524_6_write = v524_6.write_zipper();
            for v524_6_byte in v522_3_cursor.child_mask().iter() {
              v522_3_cursor.descend_to_existing_byte(v524_6_byte);
              {
              let v525_2: Space = singleton(&v522_3_cursor.path()[(v522_3_origin + 1)..(v522_3_origin + 2)]);
              let v525_3: Space = intersect(&(*CONSTANT_12),&(v525_2));
              let v525_4: Space = if has_head(&(v525_3)) { singleton(&[]) } else { Space::new() };
              drop(v525_3);
              let v525_5: Space = subtract(&(*CONSTANT_0),&(v525_4));
              drop(v525_4);
              let v525_8: Space = if (&(v525_5)).is_empty() { Space::new() } else {
                let mut v526_7 = Space::new();
                let mut v526_7_write = v526_7.write_zipper();
                for v526_7_byte in v522_3_cursor.child_mask().iter() {
                  v522_3_cursor.descend_to_existing_byte(v526_7_byte);
                  {
                  let v527_2: Space = singleton(&v522_3_cursor.path()[(v522_3_origin + 2)..(v522_3_origin + 3)]);
                  let v527_3: Space = intersect(&(*CONSTANT_12),&(v527_2));
                  let v527_4: Space = if has_head(&(v527_3)) { singleton(&[]) } else { Space::new() };
                  drop(v527_3);
                  let v527_5: Space = subtract(&(*CONSTANT_0),&(v527_4));
                  drop(v527_4);
                  let v527_8: Space = if (&(v527_5)).is_empty() { Space::new() } else {
                    let v528_7: Space = routine_41(c, &v522_3_cursor.path()[v522_3_origin..(v522_3_origin + 3)], &v522_3_cursor);
                    compose(&(v527_5),&(v528_7))
                  };
                  drop(v527_5);
                  let v527_9: Space = intersect(&(*CONSTANT_12),&(v527_2));
                  drop(v527_2);
                  let v527_10: Space = if has_head(&(v527_9)) { singleton(&[]) } else { Space::new() };
                  drop(v527_9);
                  let v527_12: Space = if (&(v527_10)).is_empty() { Space::new() } else {
                    let v529_11: Space = routine_42(c, &v522_3_cursor.path()[v522_3_origin..(v522_3_origin + 3)], &v522_3_cursor);
                    compose(&(v527_10),&(v529_11))
                  };
                  drop(v527_10);
                  let v527_13: Space = unite(&(v527_8),&(v527_12));
                  join_wrapped_into(&mut v526_7_write,&((v527_13).read_zipper()),&[]);
                  }
                  v522_3_cursor.ascend(1);
                }
                drop(v526_7_write);
                compose(&(v525_5),&(v526_7))
              };
              drop(v525_5);
              let v525_9: Space = intersect(&(*CONSTANT_12),&(v525_2));
              drop(v525_2);
              let v525_10: Space = if has_head(&(v525_9)) { singleton(&[]) } else { Space::new() };
              drop(v525_9);
              let v525_12: Space = if (&(v525_10)).is_empty() { Space::new() } else {
                let mut v530_11 = Space::new();
                let mut v530_11_write = v530_11.write_zipper();
                for v530_11_byte in v522_3_cursor.child_mask().iter() {
                  v522_3_cursor.descend_to_existing_byte(v530_11_byte);
                  {
                  let v531_2: Space = singleton(&v522_3_cursor.path()[(v522_3_origin + 2)..(v522_3_origin + 3)]);
                  let v531_3: Space = intersect(&(*CONSTANT_12),&(v531_2));
                  let v531_4: Space = if has_head(&(v531_3)) { singleton(&[]) } else { Space::new() };
                  drop(v531_3);
                  let v531_5: Space = subtract(&(*CONSTANT_0),&(v531_4));
                  drop(v531_4);
                  let v531_8: Space = if (&(v531_5)).is_empty() { Space::new() } else {
                    let v532_7: Space = routine_41(c, &v522_3_cursor.path()[v522_3_origin..(v522_3_origin + 3)], &v522_3_cursor);
                    compose(&(v531_5),&(v532_7))
                  };
                  drop(v531_5);
                  let v531_9: Space = intersect(&(*CONSTANT_12),&(v531_2));
                  drop(v531_2);
                  let v531_10: Space = if has_head(&(v531_9)) { singleton(&[]) } else { Space::new() };
                  drop(v531_9);
                  let v531_12: Space = if (&(v531_10)).is_empty() { Space::new() } else {
                    let v533_11: Space = routine_43(c, &v522_3_cursor.path()[v522_3_origin..(v522_3_origin + 3)], &v522_3_cursor);
                    compose(&(v531_10),&(v533_11))
                  };
                  drop(v531_10);
                  let v531_13: Space = unite(&(v531_8),&(v531_12));
                  join_wrapped_into(&mut v530_11_write,&((v531_13).read_zipper()),&[]);
                  }
                  v522_3_cursor.ascend(1);
                }
                drop(v530_11_write);
                compose(&(v525_10),&(v530_11))
              };
              drop(v525_10);
              let v525_13: Space = unite(&(v525_8),&(v525_12));
              join_wrapped_into(&mut v524_6_write,&((v525_13).read_zipper()),&[]);
              }
              v522_3_cursor.ascend(1);
            }
            drop(v524_6_write);
            compose(&(v523_5),&(v524_6))
          };
          drop(v523_5);
          let v523_8: Space = intersect(&(*CONSTANT_12),&(v523_2));
          drop(v523_2);
          let v523_9: Space = if has_head(&(v523_8)) { singleton(&[]) } else { Space::new() };
          drop(v523_8);
          let v523_11: Space = if (&(v523_9)).is_empty() { Space::new() } else {
            let mut v534_10 = Space::new();
            let mut v534_10_write = v534_10.write_zipper();
            for v534_10_byte in v522_3_cursor.child_mask().iter() {
              v522_3_cursor.descend_to_existing_byte(v534_10_byte);
              {
              let v535_2: Space = singleton(&v522_3_cursor.path()[(v522_3_origin + 1)..(v522_3_origin + 2)]);
              let v535_3: Space = intersect(&(*CONSTANT_12),&(v535_2));
              let v535_4: Space = if has_head(&(v535_3)) { singleton(&[]) } else { Space::new() };
              drop(v535_3);
              let v535_5: Space = subtract(&(*CONSTANT_0),&(v535_4));
              drop(v535_4);
              let v535_8: Space = if (&(v535_5)).is_empty() { Space::new() } else {
                let mut v536_7 = Space::new();
                let mut v536_7_write = v536_7.write_zipper();
                for v536_7_byte in v522_3_cursor.child_mask().iter() {
                  v522_3_cursor.descend_to_existing_byte(v536_7_byte);
                  {
                  let v537_2: Space = singleton(&v522_3_cursor.path()[(v522_3_origin + 2)..(v522_3_origin + 3)]);
                  let v537_3: Space = intersect(&(*CONSTANT_12),&(v537_2));
                  let v537_4: Space = if has_head(&(v537_3)) { singleton(&[]) } else { Space::new() };
                  drop(v537_3);
                  let v537_5: Space = subtract(&(*CONSTANT_0),&(v537_4));
                  drop(v537_4);
                  let v537_8: Space = if (&(v537_5)).is_empty() { Space::new() } else {
                    let v538_7: Space = routine_41(c, &v522_3_cursor.path()[v522_3_origin..(v522_3_origin + 3)], &v522_3_cursor);
                    compose(&(v537_5),&(v538_7))
                  };
                  drop(v537_5);
                  let v537_9: Space = intersect(&(*CONSTANT_12),&(v537_2));
                  drop(v537_2);
                  let v537_10: Space = if has_head(&(v537_9)) { singleton(&[]) } else { Space::new() };
                  drop(v537_9);
                  let v537_12: Space = if (&(v537_10)).is_empty() { Space::new() } else {
                    let v539_11: Space = routine_42(c, &v522_3_cursor.path()[v522_3_origin..(v522_3_origin + 3)], &v522_3_cursor);
                    compose(&(v537_10),&(v539_11))
                  };
                  drop(v537_10);
                  let v537_13: Space = unite(&(v537_8),&(v537_12));
                  join_wrapped_into(&mut v536_7_write,&((v537_13).read_zipper()),&[]);
                  }
                  v522_3_cursor.ascend(1);
                }
                drop(v536_7_write);
                compose(&(v535_5),&(v536_7))
              };
              drop(v535_5);
              let v535_9: Space = intersect(&(*CONSTANT_12),&(v535_2));
              drop(v535_2);
              let v535_10: Space = if has_head(&(v535_9)) { singleton(&[]) } else { Space::new() };
              drop(v535_9);
              let v535_11: Space = compose(&(v535_10),&v522_3_cursor);
              drop(v535_10);
              let v535_12: Space = unite(&(v535_8),&(v535_11));
              drop(v535_11);
              join_wrapped_into(&mut v534_10_write,&((v535_12).read_zipper()),&[]);
              }
              v522_3_cursor.ascend(1);
            }
            drop(v534_10_write);
            compose(&(v523_9),&(v534_10))
          };
          drop(v523_9);
          let v523_12: Space = unite(&(v523_7),&(v523_11));
          join_wrapped_into(&mut v522_3_write,&((v523_12).read_zipper()),&[]);
          }
          v522_3_cursor.ascend(1);
        }
        drop(v522_3_cursor);
        drop(v522_3_write);
        drop(v522_2);
        let v522_4: Space = unite(&(v522_3),&(v521_6));
        let v522_5: Space = intersect(&(v522_4),&(*capture_2));
        if !v521_6.join_into((v522_5).clone()).is_element() { break; }
      }
      let mut v521_7: Space = ((*capture_5)).clone();
      loop {
        let v540_1: Space = intersect(&(v521_7),&(*capture_2));
        let v540_2: Space = restrict_to(&(*capture_1),&(v540_1));
        drop(v540_1);
        let mut v540_3 = Space::new();
        let mut v540_3_write = v540_3.write_zipper();
        let mut v540_3_cursor = (v540_2).read_zipper();
        let v540_3_origin = v540_3_cursor.path().len();
        for v540_3_byte in v540_3_cursor.child_mask().iter() {
          v540_3_cursor.descend_to_existing_byte(v540_3_byte);
          {
          let v541_2: Space = singleton(&v540_3_cursor.path()[v540_3_origin..(v540_3_origin + 1)]);
          let v541_3: Space = intersect(&(*CONSTANT_12),&(v541_2));
          let v541_4: Space = if has_head(&(v541_3)) { singleton(&[]) } else { Space::new() };
          drop(v541_3);
          let v541_5: Space = subtract(&(*CONSTANT_0),&(v541_4));
          drop(v541_4);
          let v541_7: Space = if (&(v541_5)).is_empty() { Space::new() } else {
            let mut v542_6 = Space::new();
            let mut v542_6_write = v542_6.write_zipper();
            for v542_6_byte in v540_3_cursor.child_mask().iter() {
              v540_3_cursor.descend_to_existing_byte(v542_6_byte);
              {
              let v543_2: Space = singleton(&v540_3_cursor.path()[(v540_3_origin + 1)..(v540_3_origin + 2)]);
              let v543_3: Space = intersect(&(*CONSTANT_12),&(v543_2));
              let v543_4: Space = if has_head(&(v543_3)) { singleton(&[]) } else { Space::new() };
              drop(v543_3);
              let v543_5: Space = subtract(&(*CONSTANT_0),&(v543_4));
              drop(v543_4);
              let v543_8: Space = if (&(v543_5)).is_empty() { Space::new() } else {
                let mut v544_7 = Space::new();
                let mut v544_7_write = v544_7.write_zipper();
                for v544_7_byte in v540_3_cursor.child_mask().iter() {
                  v540_3_cursor.descend_to_existing_byte(v544_7_byte);
                  {
                  let v545_2: Space = singleton(&v540_3_cursor.path()[(v540_3_origin + 2)..(v540_3_origin + 3)]);
                  let v545_3: Space = intersect(&(*CONSTANT_12),&(v545_2));
                  let v545_4: Space = if has_head(&(v545_3)) { singleton(&[]) } else { Space::new() };
                  drop(v545_3);
                  let v545_5: Space = subtract(&(*CONSTANT_0),&(v545_4));
                  drop(v545_4);
                  let v545_8: Space = if (&(v545_5)).is_empty() { Space::new() } else {
                    let v546_7: Space = routine_41(c, &v540_3_cursor.path()[v540_3_origin..(v540_3_origin + 3)], &v540_3_cursor);
                    compose(&(v545_5),&(v546_7))
                  };
                  drop(v545_5);
                  let v545_9: Space = intersect(&(*CONSTANT_12),&(v545_2));
                  drop(v545_2);
                  let v545_10: Space = if has_head(&(v545_9)) { singleton(&[]) } else { Space::new() };
                  drop(v545_9);
                  let v545_12: Space = if (&(v545_10)).is_empty() { Space::new() } else {
                    let v547_11: Space = routine_42(c, &v540_3_cursor.path()[v540_3_origin..(v540_3_origin + 3)], &v540_3_cursor);
                    compose(&(v545_10),&(v547_11))
                  };
                  drop(v545_10);
                  let v545_13: Space = unite(&(v545_8),&(v545_12));
                  join_wrapped_into(&mut v544_7_write,&((v545_13).read_zipper()),&[]);
                  }
                  v540_3_cursor.ascend(1);
                }
                drop(v544_7_write);
                compose(&(v543_5),&(v544_7))
              };
              drop(v543_5);
              let v543_9: Space = intersect(&(*CONSTANT_12),&(v543_2));
              drop(v543_2);
              let v543_10: Space = if has_head(&(v543_9)) { singleton(&[]) } else { Space::new() };
              drop(v543_9);
              let v543_12: Space = if (&(v543_10)).is_empty() { Space::new() } else {
                let mut v548_11 = Space::new();
                let mut v548_11_write = v548_11.write_zipper();
                for v548_11_byte in v540_3_cursor.child_mask().iter() {
                  v540_3_cursor.descend_to_existing_byte(v548_11_byte);
                  {
                  let v549_2: Space = singleton(&v540_3_cursor.path()[(v540_3_origin + 2)..(v540_3_origin + 3)]);
                  let v549_3: Space = intersect(&(*CONSTANT_12),&(v549_2));
                  let v549_4: Space = if has_head(&(v549_3)) { singleton(&[]) } else { Space::new() };
                  drop(v549_3);
                  let v549_5: Space = subtract(&(*CONSTANT_0),&(v549_4));
                  drop(v549_4);
                  let v549_8: Space = if (&(v549_5)).is_empty() { Space::new() } else {
                    let v550_7: Space = routine_41(c, &v540_3_cursor.path()[v540_3_origin..(v540_3_origin + 3)], &v540_3_cursor);
                    compose(&(v549_5),&(v550_7))
                  };
                  drop(v549_5);
                  let v549_9: Space = intersect(&(*CONSTANT_12),&(v549_2));
                  drop(v549_2);
                  let v549_10: Space = if has_head(&(v549_9)) { singleton(&[]) } else { Space::new() };
                  drop(v549_9);
                  let v549_12: Space = if (&(v549_10)).is_empty() { Space::new() } else {
                    let v551_11: Space = routine_43(c, &v540_3_cursor.path()[v540_3_origin..(v540_3_origin + 3)], &v540_3_cursor);
                    compose(&(v549_10),&(v551_11))
                  };
                  drop(v549_10);
                  let v549_13: Space = unite(&(v549_8),&(v549_12));
                  join_wrapped_into(&mut v548_11_write,&((v549_13).read_zipper()),&[]);
                  }
                  v540_3_cursor.ascend(1);
                }
                drop(v548_11_write);
                compose(&(v543_10),&(v548_11))
              };
              drop(v543_10);
              let v543_13: Space = unite(&(v543_8),&(v543_12));
              join_wrapped_into(&mut v542_6_write,&((v543_13).read_zipper()),&[]);
              }
              v540_3_cursor.ascend(1);
            }
            drop(v542_6_write);
            compose(&(v541_5),&(v542_6))
          };
          drop(v541_5);
          let v541_8: Space = intersect(&(*CONSTANT_12),&(v541_2));
          drop(v541_2);
          let v541_9: Space = if has_head(&(v541_8)) { singleton(&[]) } else { Space::new() };
          drop(v541_8);
          let v541_11: Space = if (&(v541_9)).is_empty() { Space::new() } else {
            let mut v552_10 = Space::new();
            let mut v552_10_write = v552_10.write_zipper();
            for v552_10_byte in v540_3_cursor.child_mask().iter() {
              v540_3_cursor.descend_to_existing_byte(v552_10_byte);
              {
              let v553_2: Space = singleton(&v540_3_cursor.path()[(v540_3_origin + 1)..(v540_3_origin + 2)]);
              let v553_3: Space = intersect(&(*CONSTANT_12),&(v553_2));
              let v553_4: Space = if has_head(&(v553_3)) { singleton(&[]) } else { Space::new() };
              drop(v553_3);
              let v553_5: Space = subtract(&(*CONSTANT_0),&(v553_4));
              drop(v553_4);
              let v553_8: Space = if (&(v553_5)).is_empty() { Space::new() } else {
                let mut v554_7 = Space::new();
                let mut v554_7_write = v554_7.write_zipper();
                for v554_7_byte in v540_3_cursor.child_mask().iter() {
                  v540_3_cursor.descend_to_existing_byte(v554_7_byte);
                  {
                  let v555_2: Space = singleton(&v540_3_cursor.path()[(v540_3_origin + 2)..(v540_3_origin + 3)]);
                  let v555_3: Space = intersect(&(*CONSTANT_12),&(v555_2));
                  let v555_4: Space = if has_head(&(v555_3)) { singleton(&[]) } else { Space::new() };
                  drop(v555_3);
                  let v555_5: Space = subtract(&(*CONSTANT_0),&(v555_4));
                  drop(v555_4);
                  let v555_8: Space = if (&(v555_5)).is_empty() { Space::new() } else {
                    let v556_7: Space = routine_41(c, &v540_3_cursor.path()[v540_3_origin..(v540_3_origin + 3)], &v540_3_cursor);
                    compose(&(v555_5),&(v556_7))
                  };
                  drop(v555_5);
                  let v555_9: Space = intersect(&(*CONSTANT_12),&(v555_2));
                  drop(v555_2);
                  let v555_10: Space = if has_head(&(v555_9)) { singleton(&[]) } else { Space::new() };
                  drop(v555_9);
                  let v555_12: Space = if (&(v555_10)).is_empty() { Space::new() } else {
                    let v557_11: Space = routine_42(c, &v540_3_cursor.path()[v540_3_origin..(v540_3_origin + 3)], &v540_3_cursor);
                    compose(&(v555_10),&(v557_11))
                  };
                  drop(v555_10);
                  let v555_13: Space = unite(&(v555_8),&(v555_12));
                  join_wrapped_into(&mut v554_7_write,&((v555_13).read_zipper()),&[]);
                  }
                  v540_3_cursor.ascend(1);
                }
                drop(v554_7_write);
                compose(&(v553_5),&(v554_7))
              };
              drop(v553_5);
              let v553_9: Space = intersect(&(*CONSTANT_12),&(v553_2));
              drop(v553_2);
              let v553_10: Space = if has_head(&(v553_9)) { singleton(&[]) } else { Space::new() };
              drop(v553_9);
              let v553_11: Space = compose(&(v553_10),&v540_3_cursor);
              drop(v553_10);
              let v553_12: Space = unite(&(v553_8),&(v553_11));
              drop(v553_11);
              join_wrapped_into(&mut v552_10_write,&((v553_12).read_zipper()),&[]);
              }
              v540_3_cursor.ascend(1);
            }
            drop(v552_10_write);
            compose(&(v541_9),&(v552_10))
          };
          drop(v541_9);
          let v541_12: Space = unite(&(v541_7),&(v541_11));
          join_wrapped_into(&mut v540_3_write,&((v541_12).read_zipper()),&[]);
          }
          v540_3_cursor.ascend(1);
        }
        drop(v540_3_cursor);
        drop(v540_3_write);
        drop(v540_2);
        let v540_4: Space = unite(&(v540_3),&(v521_7));
        let v540_5: Space = intersect(&(v540_4),&(*capture_2));
        if !v521_7.join_into((v540_5).clone()).is_element() { break; }
      }
      let v521_8: Space = subtract(&(v521_6),&(v521_7));
      let v521_9: Space = routine_16(c, &(*capture_3).path()[capture_4..(capture_4 + 1)], &(*capture_3), &(*capture_0), &(*capture_1), &((v521_8).read_zipper()));
      compose(&(v520_5),&(v521_9))
    };
    drop(v520_5);
    let v520_11: Space = intersect(&(*CONSTANT_12),&(v520_2));
    drop(v520_2);
    let v520_12: Space = if has_head(&(v520_11)) { singleton(&[]) } else { Space::new() };
    drop(v520_11);
    let v520_17: Space = if (&(v520_12)).is_empty() { Space::new() } else {
      let mut v558_13: Space = ((*capture_5)).clone();
      loop {
        let v559_1: Space = intersect(&(v558_13),&(*capture_2));
        let v559_2: Space = restrict_to(&(*capture_0),&(v559_1));
        drop(v559_1);
        let mut v559_3 = Space::new();
        let mut v559_3_write = v559_3.write_zipper();
        let mut v559_3_cursor = (v559_2).read_zipper();
        let v559_3_origin = v559_3_cursor.path().len();
        for v559_3_byte in v559_3_cursor.child_mask().iter() {
          v559_3_cursor.descend_to_existing_byte(v559_3_byte);
          {
          let v560_2: Space = singleton(&v559_3_cursor.path()[v559_3_origin..(v559_3_origin + 1)]);
          let v560_3: Space = intersect(&(*CONSTANT_12),&(v560_2));
          let v560_4: Space = if has_head(&(v560_3)) { singleton(&[]) } else { Space::new() };
          drop(v560_3);
          let v560_5: Space = subtract(&(*CONSTANT_0),&(v560_4));
          drop(v560_4);
          let v560_7: Space = if (&(v560_5)).is_empty() { Space::new() } else {
            let mut v561_6 = Space::new();
            let mut v561_6_write = v561_6.write_zipper();
            for v561_6_byte in v559_3_cursor.child_mask().iter() {
              v559_3_cursor.descend_to_existing_byte(v561_6_byte);
              {
              let v562_2: Space = singleton(&v559_3_cursor.path()[(v559_3_origin + 1)..(v559_3_origin + 2)]);
              let v562_3: Space = intersect(&(*CONSTANT_12),&(v562_2));
              let v562_4: Space = if has_head(&(v562_3)) { singleton(&[]) } else { Space::new() };
              drop(v562_3);
              let v562_5: Space = subtract(&(*CONSTANT_0),&(v562_4));
              drop(v562_4);
              let v562_8: Space = if (&(v562_5)).is_empty() { Space::new() } else {
                let mut v563_7 = Space::new();
                let mut v563_7_write = v563_7.write_zipper();
                for v563_7_byte in v559_3_cursor.child_mask().iter() {
                  v559_3_cursor.descend_to_existing_byte(v563_7_byte);
                  {
                  let v564_2: Space = singleton(&v559_3_cursor.path()[(v559_3_origin + 2)..(v559_3_origin + 3)]);
                  let v564_3: Space = intersect(&(*CONSTANT_12),&(v564_2));
                  let v564_4: Space = if has_head(&(v564_3)) { singleton(&[]) } else { Space::new() };
                  drop(v564_3);
                  let v564_5: Space = subtract(&(*CONSTANT_0),&(v564_4));
                  drop(v564_4);
                  let v564_8: Space = if (&(v564_5)).is_empty() { Space::new() } else {
                    let v565_7: Space = routine_41(c, &v559_3_cursor.path()[v559_3_origin..(v559_3_origin + 3)], &v559_3_cursor);
                    compose(&(v564_5),&(v565_7))
                  };
                  drop(v564_5);
                  let v564_9: Space = intersect(&(*CONSTANT_12),&(v564_2));
                  drop(v564_2);
                  let v564_10: Space = if has_head(&(v564_9)) { singleton(&[]) } else { Space::new() };
                  drop(v564_9);
                  let v564_12: Space = if (&(v564_10)).is_empty() { Space::new() } else {
                    let v566_11: Space = routine_42(c, &v559_3_cursor.path()[v559_3_origin..(v559_3_origin + 3)], &v559_3_cursor);
                    compose(&(v564_10),&(v566_11))
                  };
                  drop(v564_10);
                  let v564_13: Space = unite(&(v564_8),&(v564_12));
                  join_wrapped_into(&mut v563_7_write,&((v564_13).read_zipper()),&[]);
                  }
                  v559_3_cursor.ascend(1);
                }
                drop(v563_7_write);
                compose(&(v562_5),&(v563_7))
              };
              drop(v562_5);
              let v562_9: Space = intersect(&(*CONSTANT_12),&(v562_2));
              drop(v562_2);
              let v562_10: Space = if has_head(&(v562_9)) { singleton(&[]) } else { Space::new() };
              drop(v562_9);
              let v562_12: Space = if (&(v562_10)).is_empty() { Space::new() } else {
                let mut v567_11 = Space::new();
                let mut v567_11_write = v567_11.write_zipper();
                for v567_11_byte in v559_3_cursor.child_mask().iter() {
                  v559_3_cursor.descend_to_existing_byte(v567_11_byte);
                  {
                  let v568_2: Space = singleton(&v559_3_cursor.path()[(v559_3_origin + 2)..(v559_3_origin + 3)]);
                  let v568_3: Space = intersect(&(*CONSTANT_12),&(v568_2));
                  let v568_4: Space = if has_head(&(v568_3)) { singleton(&[]) } else { Space::new() };
                  drop(v568_3);
                  let v568_5: Space = subtract(&(*CONSTANT_0),&(v568_4));
                  drop(v568_4);
                  let v568_8: Space = if (&(v568_5)).is_empty() { Space::new() } else {
                    let v569_7: Space = routine_41(c, &v559_3_cursor.path()[v559_3_origin..(v559_3_origin + 3)], &v559_3_cursor);
                    compose(&(v568_5),&(v569_7))
                  };
                  drop(v568_5);
                  let v568_9: Space = intersect(&(*CONSTANT_12),&(v568_2));
                  drop(v568_2);
                  let v568_10: Space = if has_head(&(v568_9)) { singleton(&[]) } else { Space::new() };
                  drop(v568_9);
                  let v568_12: Space = if (&(v568_10)).is_empty() { Space::new() } else {
                    let v570_11: Space = routine_43(c, &v559_3_cursor.path()[v559_3_origin..(v559_3_origin + 3)], &v559_3_cursor);
                    compose(&(v568_10),&(v570_11))
                  };
                  drop(v568_10);
                  let v568_13: Space = unite(&(v568_8),&(v568_12));
                  join_wrapped_into(&mut v567_11_write,&((v568_13).read_zipper()),&[]);
                  }
                  v559_3_cursor.ascend(1);
                }
                drop(v567_11_write);
                compose(&(v562_10),&(v567_11))
              };
              drop(v562_10);
              let v562_13: Space = unite(&(v562_8),&(v562_12));
              join_wrapped_into(&mut v561_6_write,&((v562_13).read_zipper()),&[]);
              }
              v559_3_cursor.ascend(1);
            }
            drop(v561_6_write);
            compose(&(v560_5),&(v561_6))
          };
          drop(v560_5);
          let v560_8: Space = intersect(&(*CONSTANT_12),&(v560_2));
          drop(v560_2);
          let v560_9: Space = if has_head(&(v560_8)) { singleton(&[]) } else { Space::new() };
          drop(v560_8);
          let v560_11: Space = if (&(v560_9)).is_empty() { Space::new() } else {
            let mut v571_10 = Space::new();
            let mut v571_10_write = v571_10.write_zipper();
            for v571_10_byte in v559_3_cursor.child_mask().iter() {
              v559_3_cursor.descend_to_existing_byte(v571_10_byte);
              {
              let v572_2: Space = singleton(&v559_3_cursor.path()[(v559_3_origin + 1)..(v559_3_origin + 2)]);
              let v572_3: Space = intersect(&(*CONSTANT_12),&(v572_2));
              let v572_4: Space = if has_head(&(v572_3)) { singleton(&[]) } else { Space::new() };
              drop(v572_3);
              let v572_5: Space = subtract(&(*CONSTANT_0),&(v572_4));
              drop(v572_4);
              let v572_8: Space = if (&(v572_5)).is_empty() { Space::new() } else {
                let mut v573_7 = Space::new();
                let mut v573_7_write = v573_7.write_zipper();
                for v573_7_byte in v559_3_cursor.child_mask().iter() {
                  v559_3_cursor.descend_to_existing_byte(v573_7_byte);
                  {
                  let v574_2: Space = singleton(&v559_3_cursor.path()[(v559_3_origin + 2)..(v559_3_origin + 3)]);
                  let v574_3: Space = intersect(&(*CONSTANT_12),&(v574_2));
                  let v574_4: Space = if has_head(&(v574_3)) { singleton(&[]) } else { Space::new() };
                  drop(v574_3);
                  let v574_5: Space = subtract(&(*CONSTANT_0),&(v574_4));
                  drop(v574_4);
                  let v574_8: Space = if (&(v574_5)).is_empty() { Space::new() } else {
                    let v575_7: Space = routine_41(c, &v559_3_cursor.path()[v559_3_origin..(v559_3_origin + 3)], &v559_3_cursor);
                    compose(&(v574_5),&(v575_7))
                  };
                  drop(v574_5);
                  let v574_9: Space = intersect(&(*CONSTANT_12),&(v574_2));
                  drop(v574_2);
                  let v574_10: Space = if has_head(&(v574_9)) { singleton(&[]) } else { Space::new() };
                  drop(v574_9);
                  let v574_12: Space = if (&(v574_10)).is_empty() { Space::new() } else {
                    let v576_11: Space = routine_42(c, &v559_3_cursor.path()[v559_3_origin..(v559_3_origin + 3)], &v559_3_cursor);
                    compose(&(v574_10),&(v576_11))
                  };
                  drop(v574_10);
                  let v574_13: Space = unite(&(v574_8),&(v574_12));
                  join_wrapped_into(&mut v573_7_write,&((v574_13).read_zipper()),&[]);
                  }
                  v559_3_cursor.ascend(1);
                }
                drop(v573_7_write);
                compose(&(v572_5),&(v573_7))
              };
              drop(v572_5);
              let v572_9: Space = intersect(&(*CONSTANT_12),&(v572_2));
              drop(v572_2);
              let v572_10: Space = if has_head(&(v572_9)) { singleton(&[]) } else { Space::new() };
              drop(v572_9);
              let v572_11: Space = compose(&(v572_10),&v559_3_cursor);
              drop(v572_10);
              let v572_12: Space = unite(&(v572_8),&(v572_11));
              drop(v572_11);
              join_wrapped_into(&mut v571_10_write,&((v572_12).read_zipper()),&[]);
              }
              v559_3_cursor.ascend(1);
            }
            drop(v571_10_write);
            compose(&(v560_9),&(v571_10))
          };
          drop(v560_9);
          let v560_12: Space = unite(&(v560_7),&(v560_11));
          join_wrapped_into(&mut v559_3_write,&((v560_12).read_zipper()),&[]);
          }
          v559_3_cursor.ascend(1);
        }
        drop(v559_3_cursor);
        drop(v559_3_write);
        drop(v559_2);
        let v559_4: Space = unite(&(v559_3),&(v558_13));
        let v559_5: Space = intersect(&(v559_4),&(*capture_2));
        if !v558_13.join_into((v559_5).clone()).is_element() { break; }
      }
      let mut v558_14: Space = ((*capture_5)).clone();
      loop {
        let v577_1: Space = intersect(&(v558_14),&(*capture_2));
        let v577_2: Space = restrict_to(&(*capture_1),&(v577_1));
        drop(v577_1);
        let mut v577_3 = Space::new();
        let mut v577_3_write = v577_3.write_zipper();
        let mut v577_3_cursor = (v577_2).read_zipper();
        let v577_3_origin = v577_3_cursor.path().len();
        for v577_3_byte in v577_3_cursor.child_mask().iter() {
          v577_3_cursor.descend_to_existing_byte(v577_3_byte);
          {
          let v578_2: Space = singleton(&v577_3_cursor.path()[v577_3_origin..(v577_3_origin + 1)]);
          let v578_3: Space = intersect(&(*CONSTANT_12),&(v578_2));
          let v578_4: Space = if has_head(&(v578_3)) { singleton(&[]) } else { Space::new() };
          drop(v578_3);
          let v578_5: Space = subtract(&(*CONSTANT_0),&(v578_4));
          drop(v578_4);
          let v578_7: Space = if (&(v578_5)).is_empty() { Space::new() } else {
            let mut v579_6 = Space::new();
            let mut v579_6_write = v579_6.write_zipper();
            for v579_6_byte in v577_3_cursor.child_mask().iter() {
              v577_3_cursor.descend_to_existing_byte(v579_6_byte);
              {
              let v580_2: Space = singleton(&v577_3_cursor.path()[(v577_3_origin + 1)..(v577_3_origin + 2)]);
              let v580_3: Space = intersect(&(*CONSTANT_12),&(v580_2));
              let v580_4: Space = if has_head(&(v580_3)) { singleton(&[]) } else { Space::new() };
              drop(v580_3);
              let v580_5: Space = subtract(&(*CONSTANT_0),&(v580_4));
              drop(v580_4);
              let v580_8: Space = if (&(v580_5)).is_empty() { Space::new() } else {
                let mut v581_7 = Space::new();
                let mut v581_7_write = v581_7.write_zipper();
                for v581_7_byte in v577_3_cursor.child_mask().iter() {
                  v577_3_cursor.descend_to_existing_byte(v581_7_byte);
                  {
                  let v582_2: Space = singleton(&v577_3_cursor.path()[(v577_3_origin + 2)..(v577_3_origin + 3)]);
                  let v582_3: Space = intersect(&(*CONSTANT_12),&(v582_2));
                  let v582_4: Space = if has_head(&(v582_3)) { singleton(&[]) } else { Space::new() };
                  drop(v582_3);
                  let v582_5: Space = subtract(&(*CONSTANT_0),&(v582_4));
                  drop(v582_4);
                  let v582_8: Space = if (&(v582_5)).is_empty() { Space::new() } else {
                    let v583_7: Space = routine_41(c, &v577_3_cursor.path()[v577_3_origin..(v577_3_origin + 3)], &v577_3_cursor);
                    compose(&(v582_5),&(v583_7))
                  };
                  drop(v582_5);
                  let v582_9: Space = intersect(&(*CONSTANT_12),&(v582_2));
                  drop(v582_2);
                  let v582_10: Space = if has_head(&(v582_9)) { singleton(&[]) } else { Space::new() };
                  drop(v582_9);
                  let v582_12: Space = if (&(v582_10)).is_empty() { Space::new() } else {
                    let v584_11: Space = routine_42(c, &v577_3_cursor.path()[v577_3_origin..(v577_3_origin + 3)], &v577_3_cursor);
                    compose(&(v582_10),&(v584_11))
                  };
                  drop(v582_10);
                  let v582_13: Space = unite(&(v582_8),&(v582_12));
                  join_wrapped_into(&mut v581_7_write,&((v582_13).read_zipper()),&[]);
                  }
                  v577_3_cursor.ascend(1);
                }
                drop(v581_7_write);
                compose(&(v580_5),&(v581_7))
              };
              drop(v580_5);
              let v580_9: Space = intersect(&(*CONSTANT_12),&(v580_2));
              drop(v580_2);
              let v580_10: Space = if has_head(&(v580_9)) { singleton(&[]) } else { Space::new() };
              drop(v580_9);
              let v580_12: Space = if (&(v580_10)).is_empty() { Space::new() } else {
                let mut v585_11 = Space::new();
                let mut v585_11_write = v585_11.write_zipper();
                for v585_11_byte in v577_3_cursor.child_mask().iter() {
                  v577_3_cursor.descend_to_existing_byte(v585_11_byte);
                  {
                  let v586_2: Space = singleton(&v577_3_cursor.path()[(v577_3_origin + 2)..(v577_3_origin + 3)]);
                  let v586_3: Space = intersect(&(*CONSTANT_12),&(v586_2));
                  let v586_4: Space = if has_head(&(v586_3)) { singleton(&[]) } else { Space::new() };
                  drop(v586_3);
                  let v586_5: Space = subtract(&(*CONSTANT_0),&(v586_4));
                  drop(v586_4);
                  let v586_8: Space = if (&(v586_5)).is_empty() { Space::new() } else {
                    let v587_7: Space = routine_41(c, &v577_3_cursor.path()[v577_3_origin..(v577_3_origin + 3)], &v577_3_cursor);
                    compose(&(v586_5),&(v587_7))
                  };
                  drop(v586_5);
                  let v586_9: Space = intersect(&(*CONSTANT_12),&(v586_2));
                  drop(v586_2);
                  let v586_10: Space = if has_head(&(v586_9)) { singleton(&[]) } else { Space::new() };
                  drop(v586_9);
                  let v586_12: Space = if (&(v586_10)).is_empty() { Space::new() } else {
                    let v588_11: Space = routine_43(c, &v577_3_cursor.path()[v577_3_origin..(v577_3_origin + 3)], &v577_3_cursor);
                    compose(&(v586_10),&(v588_11))
                  };
                  drop(v586_10);
                  let v586_13: Space = unite(&(v586_8),&(v586_12));
                  join_wrapped_into(&mut v585_11_write,&((v586_13).read_zipper()),&[]);
                  }
                  v577_3_cursor.ascend(1);
                }
                drop(v585_11_write);
                compose(&(v580_10),&(v585_11))
              };
              drop(v580_10);
              let v580_13: Space = unite(&(v580_8),&(v580_12));
              join_wrapped_into(&mut v579_6_write,&((v580_13).read_zipper()),&[]);
              }
              v577_3_cursor.ascend(1);
            }
            drop(v579_6_write);
            compose(&(v578_5),&(v579_6))
          };
          drop(v578_5);
          let v578_8: Space = intersect(&(*CONSTANT_12),&(v578_2));
          drop(v578_2);
          let v578_9: Space = if has_head(&(v578_8)) { singleton(&[]) } else { Space::new() };
          drop(v578_8);
          let v578_11: Space = if (&(v578_9)).is_empty() { Space::new() } else {
            let mut v589_10 = Space::new();
            let mut v589_10_write = v589_10.write_zipper();
            for v589_10_byte in v577_3_cursor.child_mask().iter() {
              v577_3_cursor.descend_to_existing_byte(v589_10_byte);
              {
              let v590_2: Space = singleton(&v577_3_cursor.path()[(v577_3_origin + 1)..(v577_3_origin + 2)]);
              let v590_3: Space = intersect(&(*CONSTANT_12),&(v590_2));
              let v590_4: Space = if has_head(&(v590_3)) { singleton(&[]) } else { Space::new() };
              drop(v590_3);
              let v590_5: Space = subtract(&(*CONSTANT_0),&(v590_4));
              drop(v590_4);
              let v590_8: Space = if (&(v590_5)).is_empty() { Space::new() } else {
                let mut v591_7 = Space::new();
                let mut v591_7_write = v591_7.write_zipper();
                for v591_7_byte in v577_3_cursor.child_mask().iter() {
                  v577_3_cursor.descend_to_existing_byte(v591_7_byte);
                  {
                  let v592_2: Space = singleton(&v577_3_cursor.path()[(v577_3_origin + 2)..(v577_3_origin + 3)]);
                  let v592_3: Space = intersect(&(*CONSTANT_12),&(v592_2));
                  let v592_4: Space = if has_head(&(v592_3)) { singleton(&[]) } else { Space::new() };
                  drop(v592_3);
                  let v592_5: Space = subtract(&(*CONSTANT_0),&(v592_4));
                  drop(v592_4);
                  let v592_8: Space = if (&(v592_5)).is_empty() { Space::new() } else {
                    let v593_7: Space = routine_41(c, &v577_3_cursor.path()[v577_3_origin..(v577_3_origin + 3)], &v577_3_cursor);
                    compose(&(v592_5),&(v593_7))
                  };
                  drop(v592_5);
                  let v592_9: Space = intersect(&(*CONSTANT_12),&(v592_2));
                  drop(v592_2);
                  let v592_10: Space = if has_head(&(v592_9)) { singleton(&[]) } else { Space::new() };
                  drop(v592_9);
                  let v592_12: Space = if (&(v592_10)).is_empty() { Space::new() } else {
                    let v594_11: Space = routine_42(c, &v577_3_cursor.path()[v577_3_origin..(v577_3_origin + 3)], &v577_3_cursor);
                    compose(&(v592_10),&(v594_11))
                  };
                  drop(v592_10);
                  let v592_13: Space = unite(&(v592_8),&(v592_12));
                  join_wrapped_into(&mut v591_7_write,&((v592_13).read_zipper()),&[]);
                  }
                  v577_3_cursor.ascend(1);
                }
                drop(v591_7_write);
                compose(&(v590_5),&(v591_7))
              };
              drop(v590_5);
              let v590_9: Space = intersect(&(*CONSTANT_12),&(v590_2));
              drop(v590_2);
              let v590_10: Space = if has_head(&(v590_9)) { singleton(&[]) } else { Space::new() };
              drop(v590_9);
              let v590_11: Space = compose(&(v590_10),&v577_3_cursor);
              drop(v590_10);
              let v590_12: Space = unite(&(v590_8),&(v590_11));
              drop(v590_11);
              join_wrapped_into(&mut v589_10_write,&((v590_12).read_zipper()),&[]);
              }
              v577_3_cursor.ascend(1);
            }
            drop(v589_10_write);
            compose(&(v578_9),&(v589_10))
          };
          drop(v578_9);
          let v578_12: Space = unite(&(v578_7),&(v578_11));
          join_wrapped_into(&mut v577_3_write,&((v578_12).read_zipper()),&[]);
          }
          v577_3_cursor.ascend(1);
        }
        drop(v577_3_cursor);
        drop(v577_3_write);
        drop(v577_2);
        let v577_4: Space = unite(&(v577_3),&(v558_14));
        let v577_5: Space = intersect(&(v577_4),&(*capture_2));
        if !v558_14.join_into((v577_5).clone()).is_element() { break; }
      }
      let v558_15: Space = subtract(&(v558_13),&(v558_14));
      let v558_16: Space = routine_17(c, &(*capture_3).path()[capture_4..(capture_4 + 1)], &(*capture_3), &(*capture_0), &(*capture_1), &((v558_15).read_zipper()));
      compose(&(v520_12),&(v558_16))
    };
    drop(v520_12);

((v520_10).clone(),(v520_17).clone(),)
}

#[inline(never)]
fn native_block_4(c: &mut Context,capture_0: &View<'_, '_>,capture_1: &View<'_, '_>,capture_2: &View<'_, '_>,capture_3: &Space,capture_4: &Space,capture_5: &Space,capture_6: &Space) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v336_86: Space = subtract(&((*capture_5)),&((*capture_6)));
  let v336_87: Space = routine_11(c, &((v336_86).read_zipper()));
  let mut v336_163 = Space::new();
  let mut v336_163_write = v336_163.write_zipper();
  let mut v336_163_cursor = (v336_87).read_zipper();
  let v336_163_origin = v336_163_cursor.path().len();
  for v336_163_byte in v336_163_cursor.child_mask().iter() {
    v336_163_cursor.descend_to_existing_byte(v336_163_byte);
    {
    let (mut v409_11,mut v409_19,) = native_block_2(c, capture_0, capture_1, capture_2, &v336_163_cursor, v336_163_origin, &(*capture_4));
    let v409_20: Space = unite(&(v409_11),&(v409_19));
    join_wrapped_into(&mut v336_163_write,&((v409_20).read_zipper()),&[]);
    }
    v336_163_cursor.ascend(1);
  }
  drop(v336_163_cursor);
  drop(v336_163_write);
  let v336_164: Space = unite(&((*capture_3)),&(v336_163));
  let mut v336_183: Space = ((*capture_4)).clone();
  loop {
    let v484_1: Space = intersect(&(v336_183),&(*capture_2));
    let v484_2: Space = restrict_to(&(*capture_0),&(v484_1));
    drop(v484_1);
    let mut v484_3 = Space::new();
    let mut v484_3_write = v484_3.write_zipper();
    let mut v484_3_cursor = (v484_2).read_zipper();
    let v484_3_origin = v484_3_cursor.path().len();
    for v484_3_byte in v484_3_cursor.child_mask().iter() {
      v484_3_cursor.descend_to_existing_byte(v484_3_byte);
      {
      let v485_2: Space = singleton(&v484_3_cursor.path()[v484_3_origin..(v484_3_origin + 1)]);
      let v485_3: Space = intersect(&(*CONSTANT_12),&(v485_2));
      let v485_4: Space = if has_head(&(v485_3)) { singleton(&[]) } else { Space::new() };
      drop(v485_3);
      let v485_5: Space = subtract(&(*CONSTANT_0),&(v485_4));
      drop(v485_4);
      let v485_7: Space = if (&(v485_5)).is_empty() { Space::new() } else {
        let mut v486_6 = Space::new();
        let mut v486_6_write = v486_6.write_zipper();
        for v486_6_byte in v484_3_cursor.child_mask().iter() {
          v484_3_cursor.descend_to_existing_byte(v486_6_byte);
          {
          let v487_2: Space = singleton(&v484_3_cursor.path()[(v484_3_origin + 1)..(v484_3_origin + 2)]);
          let v487_3: Space = intersect(&(*CONSTANT_12),&(v487_2));
          let v487_4: Space = if has_head(&(v487_3)) { singleton(&[]) } else { Space::new() };
          drop(v487_3);
          let v487_5: Space = subtract(&(*CONSTANT_0),&(v487_4));
          drop(v487_4);
          let v487_8: Space = if (&(v487_5)).is_empty() { Space::new() } else {
            let mut v488_7 = Space::new();
            let mut v488_7_write = v488_7.write_zipper();
            for v488_7_byte in v484_3_cursor.child_mask().iter() {
              v484_3_cursor.descend_to_existing_byte(v488_7_byte);
              {
              let v489_2: Space = singleton(&v484_3_cursor.path()[(v484_3_origin + 2)..(v484_3_origin + 3)]);
              let v489_3: Space = intersect(&(*CONSTANT_12),&(v489_2));
              let v489_4: Space = if has_head(&(v489_3)) { singleton(&[]) } else { Space::new() };
              drop(v489_3);
              let v489_5: Space = subtract(&(*CONSTANT_0),&(v489_4));
              drop(v489_4);
              let v489_8: Space = if (&(v489_5)).is_empty() { Space::new() } else {
                let v490_7: Space = routine_41(c, &v484_3_cursor.path()[v484_3_origin..(v484_3_origin + 3)], &v484_3_cursor);
                compose(&(v489_5),&(v490_7))
              };
              drop(v489_5);
              let v489_9: Space = intersect(&(*CONSTANT_12),&(v489_2));
              drop(v489_2);
              let v489_10: Space = if has_head(&(v489_9)) { singleton(&[]) } else { Space::new() };
              drop(v489_9);
              let v489_12: Space = if (&(v489_10)).is_empty() { Space::new() } else {
                let v491_11: Space = routine_42(c, &v484_3_cursor.path()[v484_3_origin..(v484_3_origin + 3)], &v484_3_cursor);
                compose(&(v489_10),&(v491_11))
              };
              drop(v489_10);
              let v489_13: Space = unite(&(v489_8),&(v489_12));
              join_wrapped_into(&mut v488_7_write,&((v489_13).read_zipper()),&[]);
              }
              v484_3_cursor.ascend(1);
            }
            drop(v488_7_write);
            compose(&(v487_5),&(v488_7))
          };
          drop(v487_5);
          let v487_9: Space = intersect(&(*CONSTANT_12),&(v487_2));
          drop(v487_2);
          let v487_10: Space = if has_head(&(v487_9)) { singleton(&[]) } else { Space::new() };
          drop(v487_9);
          let v487_12: Space = if (&(v487_10)).is_empty() { Space::new() } else {
            let mut v492_11 = Space::new();
            let mut v492_11_write = v492_11.write_zipper();
            for v492_11_byte in v484_3_cursor.child_mask().iter() {
              v484_3_cursor.descend_to_existing_byte(v492_11_byte);
              {
              let v493_2: Space = singleton(&v484_3_cursor.path()[(v484_3_origin + 2)..(v484_3_origin + 3)]);
              let v493_3: Space = intersect(&(*CONSTANT_12),&(v493_2));
              let v493_4: Space = if has_head(&(v493_3)) { singleton(&[]) } else { Space::new() };
              drop(v493_3);
              let v493_5: Space = subtract(&(*CONSTANT_0),&(v493_4));
              drop(v493_4);
              let v493_8: Space = if (&(v493_5)).is_empty() { Space::new() } else {
                let v494_7: Space = routine_41(c, &v484_3_cursor.path()[v484_3_origin..(v484_3_origin + 3)], &v484_3_cursor);
                compose(&(v493_5),&(v494_7))
              };
              drop(v493_5);
              let v493_9: Space = intersect(&(*CONSTANT_12),&(v493_2));
              drop(v493_2);
              let v493_10: Space = if has_head(&(v493_9)) { singleton(&[]) } else { Space::new() };
              drop(v493_9);
              let v493_12: Space = if (&(v493_10)).is_empty() { Space::new() } else {
                let v495_11: Space = routine_43(c, &v484_3_cursor.path()[v484_3_origin..(v484_3_origin + 3)], &v484_3_cursor);
                compose(&(v493_10),&(v495_11))
              };
              drop(v493_10);
              let v493_13: Space = unite(&(v493_8),&(v493_12));
              join_wrapped_into(&mut v492_11_write,&((v493_13).read_zipper()),&[]);
              }
              v484_3_cursor.ascend(1);
            }
            drop(v492_11_write);
            compose(&(v487_10),&(v492_11))
          };
          drop(v487_10);
          let v487_13: Space = unite(&(v487_8),&(v487_12));
          join_wrapped_into(&mut v486_6_write,&((v487_13).read_zipper()),&[]);
          }
          v484_3_cursor.ascend(1);
        }
        drop(v486_6_write);
        compose(&(v485_5),&(v486_6))
      };
      drop(v485_5);
      let v485_8: Space = intersect(&(*CONSTANT_12),&(v485_2));
      drop(v485_2);
      let v485_9: Space = if has_head(&(v485_8)) { singleton(&[]) } else { Space::new() };
      drop(v485_8);
      let v485_11: Space = if (&(v485_9)).is_empty() { Space::new() } else {
        let mut v496_10 = Space::new();
        let mut v496_10_write = v496_10.write_zipper();
        for v496_10_byte in v484_3_cursor.child_mask().iter() {
          v484_3_cursor.descend_to_existing_byte(v496_10_byte);
          {
          let v497_2: Space = singleton(&v484_3_cursor.path()[(v484_3_origin + 1)..(v484_3_origin + 2)]);
          let v497_3: Space = intersect(&(*CONSTANT_12),&(v497_2));
          let v497_4: Space = if has_head(&(v497_3)) { singleton(&[]) } else { Space::new() };
          drop(v497_3);
          let v497_5: Space = subtract(&(*CONSTANT_0),&(v497_4));
          drop(v497_4);
          let v497_8: Space = if (&(v497_5)).is_empty() { Space::new() } else {
            let mut v498_7 = Space::new();
            let mut v498_7_write = v498_7.write_zipper();
            for v498_7_byte in v484_3_cursor.child_mask().iter() {
              v484_3_cursor.descend_to_existing_byte(v498_7_byte);
              {
              let v499_2: Space = singleton(&v484_3_cursor.path()[(v484_3_origin + 2)..(v484_3_origin + 3)]);
              let v499_3: Space = intersect(&(*CONSTANT_12),&(v499_2));
              let v499_4: Space = if has_head(&(v499_3)) { singleton(&[]) } else { Space::new() };
              drop(v499_3);
              let v499_5: Space = subtract(&(*CONSTANT_0),&(v499_4));
              drop(v499_4);
              let v499_8: Space = if (&(v499_5)).is_empty() { Space::new() } else {
                let v500_7: Space = routine_41(c, &v484_3_cursor.path()[v484_3_origin..(v484_3_origin + 3)], &v484_3_cursor);
                compose(&(v499_5),&(v500_7))
              };
              drop(v499_5);
              let v499_9: Space = intersect(&(*CONSTANT_12),&(v499_2));
              drop(v499_2);
              let v499_10: Space = if has_head(&(v499_9)) { singleton(&[]) } else { Space::new() };
              drop(v499_9);
              let v499_12: Space = if (&(v499_10)).is_empty() { Space::new() } else {
                let v501_11: Space = routine_42(c, &v484_3_cursor.path()[v484_3_origin..(v484_3_origin + 3)], &v484_3_cursor);
                compose(&(v499_10),&(v501_11))
              };
              drop(v499_10);
              let v499_13: Space = unite(&(v499_8),&(v499_12));
              join_wrapped_into(&mut v498_7_write,&((v499_13).read_zipper()),&[]);
              }
              v484_3_cursor.ascend(1);
            }
            drop(v498_7_write);
            compose(&(v497_5),&(v498_7))
          };
          drop(v497_5);
          let v497_9: Space = intersect(&(*CONSTANT_12),&(v497_2));
          drop(v497_2);
          let v497_10: Space = if has_head(&(v497_9)) { singleton(&[]) } else { Space::new() };
          drop(v497_9);
          let v497_11: Space = compose(&(v497_10),&v484_3_cursor);
          drop(v497_10);
          let v497_12: Space = unite(&(v497_8),&(v497_11));
          drop(v497_11);
          join_wrapped_into(&mut v496_10_write,&((v497_12).read_zipper()),&[]);
          }
          v484_3_cursor.ascend(1);
        }
        drop(v496_10_write);
        compose(&(v485_9),&(v496_10))
      };
      drop(v485_9);
      let v485_12: Space = unite(&(v485_7),&(v485_11));
      join_wrapped_into(&mut v484_3_write,&((v485_12).read_zipper()),&[]);
      }
      v484_3_cursor.ascend(1);
    }
    drop(v484_3_cursor);
    drop(v484_3_write);
    drop(v484_2);
    let v484_4: Space = unite(&(v484_3),&(v336_183));
    let v484_5: Space = intersect(&(v484_4),&(*capture_2));
    if !v336_183.join_into((v484_5).clone()).is_element() { break; }
  }
  let mut v336_202: Space = ((*capture_4)).clone();
  loop {
    let v502_1: Space = intersect(&(v336_202),&(*capture_2));
    let v502_2: Space = restrict_to(&(*capture_1),&(v502_1));
    drop(v502_1);
    let mut v502_3 = Space::new();
    let mut v502_3_write = v502_3.write_zipper();
    let mut v502_3_cursor = (v502_2).read_zipper();
    let v502_3_origin = v502_3_cursor.path().len();
    for v502_3_byte in v502_3_cursor.child_mask().iter() {
      v502_3_cursor.descend_to_existing_byte(v502_3_byte);
      {
      let v503_2: Space = singleton(&v502_3_cursor.path()[v502_3_origin..(v502_3_origin + 1)]);
      let v503_3: Space = intersect(&(*CONSTANT_12),&(v503_2));
      let v503_4: Space = if has_head(&(v503_3)) { singleton(&[]) } else { Space::new() };
      drop(v503_3);
      let v503_5: Space = subtract(&(*CONSTANT_0),&(v503_4));
      drop(v503_4);
      let v503_7: Space = if (&(v503_5)).is_empty() { Space::new() } else {
        let mut v504_6 = Space::new();
        let mut v504_6_write = v504_6.write_zipper();
        for v504_6_byte in v502_3_cursor.child_mask().iter() {
          v502_3_cursor.descend_to_existing_byte(v504_6_byte);
          {
          let v505_2: Space = singleton(&v502_3_cursor.path()[(v502_3_origin + 1)..(v502_3_origin + 2)]);
          let v505_3: Space = intersect(&(*CONSTANT_12),&(v505_2));
          let v505_4: Space = if has_head(&(v505_3)) { singleton(&[]) } else { Space::new() };
          drop(v505_3);
          let v505_5: Space = subtract(&(*CONSTANT_0),&(v505_4));
          drop(v505_4);
          let v505_8: Space = if (&(v505_5)).is_empty() { Space::new() } else {
            let mut v506_7 = Space::new();
            let mut v506_7_write = v506_7.write_zipper();
            for v506_7_byte in v502_3_cursor.child_mask().iter() {
              v502_3_cursor.descend_to_existing_byte(v506_7_byte);
              {
              let v507_2: Space = singleton(&v502_3_cursor.path()[(v502_3_origin + 2)..(v502_3_origin + 3)]);
              let v507_3: Space = intersect(&(*CONSTANT_12),&(v507_2));
              let v507_4: Space = if has_head(&(v507_3)) { singleton(&[]) } else { Space::new() };
              drop(v507_3);
              let v507_5: Space = subtract(&(*CONSTANT_0),&(v507_4));
              drop(v507_4);
              let v507_8: Space = if (&(v507_5)).is_empty() { Space::new() } else {
                let v508_7: Space = routine_41(c, &v502_3_cursor.path()[v502_3_origin..(v502_3_origin + 3)], &v502_3_cursor);
                compose(&(v507_5),&(v508_7))
              };
              drop(v507_5);
              let v507_9: Space = intersect(&(*CONSTANT_12),&(v507_2));
              drop(v507_2);
              let v507_10: Space = if has_head(&(v507_9)) { singleton(&[]) } else { Space::new() };
              drop(v507_9);
              let v507_12: Space = if (&(v507_10)).is_empty() { Space::new() } else {
                let v509_11: Space = routine_42(c, &v502_3_cursor.path()[v502_3_origin..(v502_3_origin + 3)], &v502_3_cursor);
                compose(&(v507_10),&(v509_11))
              };
              drop(v507_10);
              let v507_13: Space = unite(&(v507_8),&(v507_12));
              join_wrapped_into(&mut v506_7_write,&((v507_13).read_zipper()),&[]);
              }
              v502_3_cursor.ascend(1);
            }
            drop(v506_7_write);
            compose(&(v505_5),&(v506_7))
          };
          drop(v505_5);
          let v505_9: Space = intersect(&(*CONSTANT_12),&(v505_2));
          drop(v505_2);
          let v505_10: Space = if has_head(&(v505_9)) { singleton(&[]) } else { Space::new() };
          drop(v505_9);
          let v505_12: Space = if (&(v505_10)).is_empty() { Space::new() } else {
            let mut v510_11 = Space::new();
            let mut v510_11_write = v510_11.write_zipper();
            for v510_11_byte in v502_3_cursor.child_mask().iter() {
              v502_3_cursor.descend_to_existing_byte(v510_11_byte);
              {
              let v511_2: Space = singleton(&v502_3_cursor.path()[(v502_3_origin + 2)..(v502_3_origin + 3)]);
              let v511_3: Space = intersect(&(*CONSTANT_12),&(v511_2));
              let v511_4: Space = if has_head(&(v511_3)) { singleton(&[]) } else { Space::new() };
              drop(v511_3);
              let v511_5: Space = subtract(&(*CONSTANT_0),&(v511_4));
              drop(v511_4);
              let v511_8: Space = if (&(v511_5)).is_empty() { Space::new() } else {
                let v512_7: Space = routine_41(c, &v502_3_cursor.path()[v502_3_origin..(v502_3_origin + 3)], &v502_3_cursor);
                compose(&(v511_5),&(v512_7))
              };
              drop(v511_5);
              let v511_9: Space = intersect(&(*CONSTANT_12),&(v511_2));
              drop(v511_2);
              let v511_10: Space = if has_head(&(v511_9)) { singleton(&[]) } else { Space::new() };
              drop(v511_9);
              let v511_12: Space = if (&(v511_10)).is_empty() { Space::new() } else {
                let v513_11: Space = routine_43(c, &v502_3_cursor.path()[v502_3_origin..(v502_3_origin + 3)], &v502_3_cursor);
                compose(&(v511_10),&(v513_11))
              };
              drop(v511_10);
              let v511_13: Space = unite(&(v511_8),&(v511_12));
              join_wrapped_into(&mut v510_11_write,&((v511_13).read_zipper()),&[]);
              }
              v502_3_cursor.ascend(1);
            }
            drop(v510_11_write);
            compose(&(v505_10),&(v510_11))
          };
          drop(v505_10);
          let v505_13: Space = unite(&(v505_8),&(v505_12));
          join_wrapped_into(&mut v504_6_write,&((v505_13).read_zipper()),&[]);
          }
          v502_3_cursor.ascend(1);
        }
        drop(v504_6_write);
        compose(&(v503_5),&(v504_6))
      };
      drop(v503_5);
      let v503_8: Space = intersect(&(*CONSTANT_12),&(v503_2));
      drop(v503_2);
      let v503_9: Space = if has_head(&(v503_8)) { singleton(&[]) } else { Space::new() };
      drop(v503_8);
      let v503_11: Space = if (&(v503_9)).is_empty() { Space::new() } else {
        let mut v514_10 = Space::new();
        let mut v514_10_write = v514_10.write_zipper();
        for v514_10_byte in v502_3_cursor.child_mask().iter() {
          v502_3_cursor.descend_to_existing_byte(v514_10_byte);
          {
          let v515_2: Space = singleton(&v502_3_cursor.path()[(v502_3_origin + 1)..(v502_3_origin + 2)]);
          let v515_3: Space = intersect(&(*CONSTANT_12),&(v515_2));
          let v515_4: Space = if has_head(&(v515_3)) { singleton(&[]) } else { Space::new() };
          drop(v515_3);
          let v515_5: Space = subtract(&(*CONSTANT_0),&(v515_4));
          drop(v515_4);
          let v515_8: Space = if (&(v515_5)).is_empty() { Space::new() } else {
            let mut v516_7 = Space::new();
            let mut v516_7_write = v516_7.write_zipper();
            for v516_7_byte in v502_3_cursor.child_mask().iter() {
              v502_3_cursor.descend_to_existing_byte(v516_7_byte);
              {
              let v517_2: Space = singleton(&v502_3_cursor.path()[(v502_3_origin + 2)..(v502_3_origin + 3)]);
              let v517_3: Space = intersect(&(*CONSTANT_12),&(v517_2));
              let v517_4: Space = if has_head(&(v517_3)) { singleton(&[]) } else { Space::new() };
              drop(v517_3);
              let v517_5: Space = subtract(&(*CONSTANT_0),&(v517_4));
              drop(v517_4);
              let v517_8: Space = if (&(v517_5)).is_empty() { Space::new() } else {
                let v518_7: Space = routine_41(c, &v502_3_cursor.path()[v502_3_origin..(v502_3_origin + 3)], &v502_3_cursor);
                compose(&(v517_5),&(v518_7))
              };
              drop(v517_5);
              let v517_9: Space = intersect(&(*CONSTANT_12),&(v517_2));
              drop(v517_2);
              let v517_10: Space = if has_head(&(v517_9)) { singleton(&[]) } else { Space::new() };
              drop(v517_9);
              let v517_12: Space = if (&(v517_10)).is_empty() { Space::new() } else {
                let v519_11: Space = routine_42(c, &v502_3_cursor.path()[v502_3_origin..(v502_3_origin + 3)], &v502_3_cursor);
                compose(&(v517_10),&(v519_11))
              };
              drop(v517_10);
              let v517_13: Space = unite(&(v517_8),&(v517_12));
              join_wrapped_into(&mut v516_7_write,&((v517_13).read_zipper()),&[]);
              }
              v502_3_cursor.ascend(1);
            }
            drop(v516_7_write);
            compose(&(v515_5),&(v516_7))
          };
          drop(v515_5);
          let v515_9: Space = intersect(&(*CONSTANT_12),&(v515_2));
          drop(v515_2);
          let v515_10: Space = if has_head(&(v515_9)) { singleton(&[]) } else { Space::new() };
          drop(v515_9);
          let v515_11: Space = compose(&(v515_10),&v502_3_cursor);
          drop(v515_10);
          let v515_12: Space = unite(&(v515_8),&(v515_11));
          drop(v515_11);
          join_wrapped_into(&mut v514_10_write,&((v515_12).read_zipper()),&[]);
          }
          v502_3_cursor.ascend(1);
        }
        drop(v514_10_write);
        compose(&(v503_9),&(v514_10))
      };
      drop(v503_9);
      let v503_12: Space = unite(&(v503_7),&(v503_11));
      join_wrapped_into(&mut v502_3_write,&((v503_12).read_zipper()),&[]);
      }
      v502_3_cursor.ascend(1);
    }
    drop(v502_3_cursor);
    drop(v502_3_write);
    drop(v502_2);
    let v502_4: Space = unite(&(v502_3),&(v336_202));
    let v502_5: Space = intersect(&(v502_4),&(*capture_2));
    if !v336_202.join_into((v502_5).clone()).is_element() { break; }
  }
  let v336_203: Space = subtract(&(v336_183),&(v336_202));
  let v336_204: Space = routine_11(c, &((v336_203).read_zipper()));
  let mut v336_280 = Space::new();
  let mut v336_280_write = v336_280.write_zipper();
  let mut v336_280_cursor = (v336_204).read_zipper();
  let v336_280_origin = v336_280_cursor.path().len();
  for v336_280_byte in v336_280_cursor.child_mask().iter() {
    v336_280_cursor.descend_to_existing_byte(v336_280_byte);
    {
    let (mut v520_10,mut v520_17,) = native_block_3(c, capture_0, capture_1, capture_2, &v336_280_cursor, v336_280_origin, &(*capture_4));
    let v520_18: Space = unite(&(v520_10),&(v520_17));
    join_wrapped_into(&mut v336_280_write,&((v520_18).read_zipper()),&[]);
    }
    v336_280_cursor.ascend(1);
  }
  drop(v336_280_cursor);
  drop(v336_280_write);
  let v336_281: Space = unite(&(v336_164),&(v336_280));
  let mut v336_300: Space = ((*capture_4)).clone();
  loop {
    let v595_1: Space = intersect(&(v336_300),&(*capture_2));
    let v595_2: Space = restrict_to(&(*capture_1),&(v595_1));
    drop(v595_1);
    let mut v595_3 = Space::new();
    let mut v595_3_write = v595_3.write_zipper();
    let mut v595_3_cursor = (v595_2).read_zipper();
    let v595_3_origin = v595_3_cursor.path().len();
    for v595_3_byte in v595_3_cursor.child_mask().iter() {
      v595_3_cursor.descend_to_existing_byte(v595_3_byte);
      {
      let v596_2: Space = singleton(&v595_3_cursor.path()[v595_3_origin..(v595_3_origin + 1)]);
      let v596_3: Space = intersect(&(*CONSTANT_12),&(v596_2));
      let v596_4: Space = if has_head(&(v596_3)) { singleton(&[]) } else { Space::new() };
      drop(v596_3);
      let v596_5: Space = subtract(&(*CONSTANT_0),&(v596_4));
      drop(v596_4);
      let v596_7: Space = if (&(v596_5)).is_empty() { Space::new() } else {
        let mut v597_6 = Space::new();
        let mut v597_6_write = v597_6.write_zipper();
        for v597_6_byte in v595_3_cursor.child_mask().iter() {
          v595_3_cursor.descend_to_existing_byte(v597_6_byte);
          {
          let v598_2: Space = singleton(&v595_3_cursor.path()[(v595_3_origin + 1)..(v595_3_origin + 2)]);
          let v598_3: Space = intersect(&(*CONSTANT_12),&(v598_2));
          let v598_4: Space = if has_head(&(v598_3)) { singleton(&[]) } else { Space::new() };
          drop(v598_3);
          let v598_5: Space = subtract(&(*CONSTANT_0),&(v598_4));
          drop(v598_4);
          let v598_8: Space = if (&(v598_5)).is_empty() { Space::new() } else {
            let mut v599_7 = Space::new();
            let mut v599_7_write = v599_7.write_zipper();
            for v599_7_byte in v595_3_cursor.child_mask().iter() {
              v595_3_cursor.descend_to_existing_byte(v599_7_byte);
              {
              let v600_2: Space = singleton(&v595_3_cursor.path()[(v595_3_origin + 2)..(v595_3_origin + 3)]);
              let v600_3: Space = intersect(&(*CONSTANT_12),&(v600_2));
              let v600_4: Space = if has_head(&(v600_3)) { singleton(&[]) } else { Space::new() };
              drop(v600_3);
              let v600_5: Space = subtract(&(*CONSTANT_0),&(v600_4));
              drop(v600_4);
              let v600_8: Space = if (&(v600_5)).is_empty() { Space::new() } else {
                let v601_7: Space = routine_41(c, &v595_3_cursor.path()[v595_3_origin..(v595_3_origin + 3)], &v595_3_cursor);
                compose(&(v600_5),&(v601_7))
              };
              drop(v600_5);
              let v600_9: Space = intersect(&(*CONSTANT_12),&(v600_2));
              drop(v600_2);
              let v600_10: Space = if has_head(&(v600_9)) { singleton(&[]) } else { Space::new() };
              drop(v600_9);
              let v600_12: Space = if (&(v600_10)).is_empty() { Space::new() } else {
                let v602_11: Space = routine_42(c, &v595_3_cursor.path()[v595_3_origin..(v595_3_origin + 3)], &v595_3_cursor);
                compose(&(v600_10),&(v602_11))
              };
              drop(v600_10);
              let v600_13: Space = unite(&(v600_8),&(v600_12));
              join_wrapped_into(&mut v599_7_write,&((v600_13).read_zipper()),&[]);
              }
              v595_3_cursor.ascend(1);
            }
            drop(v599_7_write);
            compose(&(v598_5),&(v599_7))
          };
          drop(v598_5);
          let v598_9: Space = intersect(&(*CONSTANT_12),&(v598_2));
          drop(v598_2);
          let v598_10: Space = if has_head(&(v598_9)) { singleton(&[]) } else { Space::new() };
          drop(v598_9);
          let v598_12: Space = if (&(v598_10)).is_empty() { Space::new() } else {
            let mut v603_11 = Space::new();
            let mut v603_11_write = v603_11.write_zipper();
            for v603_11_byte in v595_3_cursor.child_mask().iter() {
              v595_3_cursor.descend_to_existing_byte(v603_11_byte);
              {
              let v604_2: Space = singleton(&v595_3_cursor.path()[(v595_3_origin + 2)..(v595_3_origin + 3)]);
              let v604_3: Space = intersect(&(*CONSTANT_12),&(v604_2));
              let v604_4: Space = if has_head(&(v604_3)) { singleton(&[]) } else { Space::new() };
              drop(v604_3);
              let v604_5: Space = subtract(&(*CONSTANT_0),&(v604_4));
              drop(v604_4);
              let v604_8: Space = if (&(v604_5)).is_empty() { Space::new() } else {
                let v605_7: Space = routine_41(c, &v595_3_cursor.path()[v595_3_origin..(v595_3_origin + 3)], &v595_3_cursor);
                compose(&(v604_5),&(v605_7))
              };
              drop(v604_5);
              let v604_9: Space = intersect(&(*CONSTANT_12),&(v604_2));
              drop(v604_2);
              let v604_10: Space = if has_head(&(v604_9)) { singleton(&[]) } else { Space::new() };
              drop(v604_9);
              let v604_12: Space = if (&(v604_10)).is_empty() { Space::new() } else {
                let v606_11: Space = routine_43(c, &v595_3_cursor.path()[v595_3_origin..(v595_3_origin + 3)], &v595_3_cursor);
                compose(&(v604_10),&(v606_11))
              };
              drop(v604_10);
              let v604_13: Space = unite(&(v604_8),&(v604_12));
              join_wrapped_into(&mut v603_11_write,&((v604_13).read_zipper()),&[]);
              }
              v595_3_cursor.ascend(1);
            }
            drop(v603_11_write);
            compose(&(v598_10),&(v603_11))
          };
          drop(v598_10);
          let v598_13: Space = unite(&(v598_8),&(v598_12));
          join_wrapped_into(&mut v597_6_write,&((v598_13).read_zipper()),&[]);
          }
          v595_3_cursor.ascend(1);
        }
        drop(v597_6_write);
        compose(&(v596_5),&(v597_6))
      };
      drop(v596_5);
      let v596_8: Space = intersect(&(*CONSTANT_12),&(v596_2));
      drop(v596_2);
      let v596_9: Space = if has_head(&(v596_8)) { singleton(&[]) } else { Space::new() };
      drop(v596_8);
      let v596_11: Space = if (&(v596_9)).is_empty() { Space::new() } else {
        let mut v607_10 = Space::new();
        let mut v607_10_write = v607_10.write_zipper();
        for v607_10_byte in v595_3_cursor.child_mask().iter() {
          v595_3_cursor.descend_to_existing_byte(v607_10_byte);
          {
          let v608_2: Space = singleton(&v595_3_cursor.path()[(v595_3_origin + 1)..(v595_3_origin + 2)]);
          let v608_3: Space = intersect(&(*CONSTANT_12),&(v608_2));
          let v608_4: Space = if has_head(&(v608_3)) { singleton(&[]) } else { Space::new() };
          drop(v608_3);
          let v608_5: Space = subtract(&(*CONSTANT_0),&(v608_4));
          drop(v608_4);
          let v608_8: Space = if (&(v608_5)).is_empty() { Space::new() } else {
            let mut v609_7 = Space::new();
            let mut v609_7_write = v609_7.write_zipper();
            for v609_7_byte in v595_3_cursor.child_mask().iter() {
              v595_3_cursor.descend_to_existing_byte(v609_7_byte);
              {
              let v610_2: Space = singleton(&v595_3_cursor.path()[(v595_3_origin + 2)..(v595_3_origin + 3)]);
              let v610_3: Space = intersect(&(*CONSTANT_12),&(v610_2));
              let v610_4: Space = if has_head(&(v610_3)) { singleton(&[]) } else { Space::new() };
              drop(v610_3);
              let v610_5: Space = subtract(&(*CONSTANT_0),&(v610_4));
              drop(v610_4);
              let v610_8: Space = if (&(v610_5)).is_empty() { Space::new() } else {
                let v611_7: Space = routine_41(c, &v595_3_cursor.path()[v595_3_origin..(v595_3_origin + 3)], &v595_3_cursor);
                compose(&(v610_5),&(v611_7))
              };
              drop(v610_5);
              let v610_9: Space = intersect(&(*CONSTANT_12),&(v610_2));
              drop(v610_2);
              let v610_10: Space = if has_head(&(v610_9)) { singleton(&[]) } else { Space::new() };
              drop(v610_9);
              let v610_12: Space = if (&(v610_10)).is_empty() { Space::new() } else {
                let v612_11: Space = routine_42(c, &v595_3_cursor.path()[v595_3_origin..(v595_3_origin + 3)], &v595_3_cursor);
                compose(&(v610_10),&(v612_11))
              };
              drop(v610_10);
              let v610_13: Space = unite(&(v610_8),&(v610_12));
              join_wrapped_into(&mut v609_7_write,&((v610_13).read_zipper()),&[]);
              }
              v595_3_cursor.ascend(1);
            }
            drop(v609_7_write);
            compose(&(v608_5),&(v609_7))
          };
          drop(v608_5);
          let v608_9: Space = intersect(&(*CONSTANT_12),&(v608_2));
          drop(v608_2);
          let v608_10: Space = if has_head(&(v608_9)) { singleton(&[]) } else { Space::new() };
          drop(v608_9);
          let v608_11: Space = compose(&(v608_10),&v595_3_cursor);
          drop(v608_10);
          let v608_12: Space = unite(&(v608_8),&(v608_11));
          drop(v608_11);
          join_wrapped_into(&mut v607_10_write,&((v608_12).read_zipper()),&[]);
          }
          v595_3_cursor.ascend(1);
        }
        drop(v607_10_write);
        compose(&(v596_9),&(v607_10))
      };
      drop(v596_9);
      let v596_12: Space = unite(&(v596_7),&(v596_11));
      join_wrapped_into(&mut v595_3_write,&((v596_12).read_zipper()),&[]);
      }
      v595_3_cursor.ascend(1);
    }
    drop(v595_3_cursor);
    drop(v595_3_write);
    drop(v595_2);
    let v595_4: Space = unite(&(v595_3),&(v336_300));
    let v595_5: Space = intersect(&(v595_4),&(*capture_2));
    if !v336_300.join_into((v595_5).clone()).is_element() { break; }
  }

((v336_163).clone(),(v336_164).clone(),(v336_183).clone(),(v336_202).clone(),(v336_203).clone(),(v336_204).clone(),(v336_280).clone(),(v336_281).clone(),(v336_300).clone(),(v336_86).clone(),(v336_87).clone(),)
}

#[inline(never)]
fn native_block_5(c: &mut Context,capture_0: &View<'_, '_>,capture_1: &View<'_, '_>,capture_2: &View<'_, '_>,capture_3: &View<'_, '_>,capture_4: usize,capture_5: &Space) -> (Space,Space,) {
    let v631_2: Space = singleton(&(*capture_3).path()[capture_4..(capture_4 + 1)]);
    let v631_3: Space = intersect(&(*CONSTANT_12),&(v631_2));
    let v631_4: Space = if has_head(&(v631_3)) { singleton(&[]) } else { Space::new() };
    drop(v631_3);
    let v631_5: Space = subtract(&(*CONSTANT_0),&(v631_4));
    drop(v631_4);
    let v631_10: Space = if (&(v631_5)).is_empty() { Space::new() } else {
      let mut v632_6: Space = ((*capture_5)).clone();
      loop {
        let v633_1: Space = intersect(&(v632_6),&(*capture_2));
        let v633_2: Space = restrict_to(&(*capture_1),&(v633_1));
        drop(v633_1);
        let mut v633_3 = Space::new();
        let mut v633_3_write = v633_3.write_zipper();
        let mut v633_3_cursor = (v633_2).read_zipper();
        let v633_3_origin = v633_3_cursor.path().len();
        for v633_3_byte in v633_3_cursor.child_mask().iter() {
          v633_3_cursor.descend_to_existing_byte(v633_3_byte);
          {
          let v634_2: Space = singleton(&v633_3_cursor.path()[v633_3_origin..(v633_3_origin + 1)]);
          let v634_3: Space = intersect(&(*CONSTANT_12),&(v634_2));
          let v634_4: Space = if has_head(&(v634_3)) { singleton(&[]) } else { Space::new() };
          drop(v634_3);
          let v634_5: Space = subtract(&(*CONSTANT_0),&(v634_4));
          drop(v634_4);
          let v634_7: Space = if (&(v634_5)).is_empty() { Space::new() } else {
            let mut v635_6 = Space::new();
            let mut v635_6_write = v635_6.write_zipper();
            for v635_6_byte in v633_3_cursor.child_mask().iter() {
              v633_3_cursor.descend_to_existing_byte(v635_6_byte);
              {
              let v636_2: Space = singleton(&v633_3_cursor.path()[(v633_3_origin + 1)..(v633_3_origin + 2)]);
              let v636_3: Space = intersect(&(*CONSTANT_12),&(v636_2));
              let v636_4: Space = if has_head(&(v636_3)) { singleton(&[]) } else { Space::new() };
              drop(v636_3);
              let v636_5: Space = subtract(&(*CONSTANT_0),&(v636_4));
              drop(v636_4);
              let v636_8: Space = if (&(v636_5)).is_empty() { Space::new() } else {
                let mut v637_7 = Space::new();
                let mut v637_7_write = v637_7.write_zipper();
                for v637_7_byte in v633_3_cursor.child_mask().iter() {
                  v633_3_cursor.descend_to_existing_byte(v637_7_byte);
                  {
                  let v638_2: Space = singleton(&v633_3_cursor.path()[(v633_3_origin + 2)..(v633_3_origin + 3)]);
                  let v638_3: Space = intersect(&(*CONSTANT_12),&(v638_2));
                  let v638_4: Space = if has_head(&(v638_3)) { singleton(&[]) } else { Space::new() };
                  drop(v638_3);
                  let v638_5: Space = subtract(&(*CONSTANT_0),&(v638_4));
                  drop(v638_4);
                  let v638_8: Space = if (&(v638_5)).is_empty() { Space::new() } else {
                    let v639_7: Space = routine_41(c, &v633_3_cursor.path()[v633_3_origin..(v633_3_origin + 3)], &v633_3_cursor);
                    compose(&(v638_5),&(v639_7))
                  };
                  drop(v638_5);
                  let v638_9: Space = intersect(&(*CONSTANT_12),&(v638_2));
                  drop(v638_2);
                  let v638_10: Space = if has_head(&(v638_9)) { singleton(&[]) } else { Space::new() };
                  drop(v638_9);
                  let v638_12: Space = if (&(v638_10)).is_empty() { Space::new() } else {
                    let v640_11: Space = routine_42(c, &v633_3_cursor.path()[v633_3_origin..(v633_3_origin + 3)], &v633_3_cursor);
                    compose(&(v638_10),&(v640_11))
                  };
                  drop(v638_10);
                  let v638_13: Space = unite(&(v638_8),&(v638_12));
                  join_wrapped_into(&mut v637_7_write,&((v638_13).read_zipper()),&[]);
                  }
                  v633_3_cursor.ascend(1);
                }
                drop(v637_7_write);
                compose(&(v636_5),&(v637_7))
              };
              drop(v636_5);
              let v636_9: Space = intersect(&(*CONSTANT_12),&(v636_2));
              drop(v636_2);
              let v636_10: Space = if has_head(&(v636_9)) { singleton(&[]) } else { Space::new() };
              drop(v636_9);
              let v636_12: Space = if (&(v636_10)).is_empty() { Space::new() } else {
                let mut v641_11 = Space::new();
                let mut v641_11_write = v641_11.write_zipper();
                for v641_11_byte in v633_3_cursor.child_mask().iter() {
                  v633_3_cursor.descend_to_existing_byte(v641_11_byte);
                  {
                  let v642_2: Space = singleton(&v633_3_cursor.path()[(v633_3_origin + 2)..(v633_3_origin + 3)]);
                  let v642_3: Space = intersect(&(*CONSTANT_12),&(v642_2));
                  let v642_4: Space = if has_head(&(v642_3)) { singleton(&[]) } else { Space::new() };
                  drop(v642_3);
                  let v642_5: Space = subtract(&(*CONSTANT_0),&(v642_4));
                  drop(v642_4);
                  let v642_8: Space = if (&(v642_5)).is_empty() { Space::new() } else {
                    let v643_7: Space = routine_41(c, &v633_3_cursor.path()[v633_3_origin..(v633_3_origin + 3)], &v633_3_cursor);
                    compose(&(v642_5),&(v643_7))
                  };
                  drop(v642_5);
                  let v642_9: Space = intersect(&(*CONSTANT_12),&(v642_2));
                  drop(v642_2);
                  let v642_10: Space = if has_head(&(v642_9)) { singleton(&[]) } else { Space::new() };
                  drop(v642_9);
                  let v642_12: Space = if (&(v642_10)).is_empty() { Space::new() } else {
                    let v644_11: Space = routine_43(c, &v633_3_cursor.path()[v633_3_origin..(v633_3_origin + 3)], &v633_3_cursor);
                    compose(&(v642_10),&(v644_11))
                  };
                  drop(v642_10);
                  let v642_13: Space = unite(&(v642_8),&(v642_12));
                  join_wrapped_into(&mut v641_11_write,&((v642_13).read_zipper()),&[]);
                  }
                  v633_3_cursor.ascend(1);
                }
                drop(v641_11_write);
                compose(&(v636_10),&(v641_11))
              };
              drop(v636_10);
              let v636_13: Space = unite(&(v636_8),&(v636_12));
              join_wrapped_into(&mut v635_6_write,&((v636_13).read_zipper()),&[]);
              }
              v633_3_cursor.ascend(1);
            }
            drop(v635_6_write);
            compose(&(v634_5),&(v635_6))
          };
          drop(v634_5);
          let v634_8: Space = intersect(&(*CONSTANT_12),&(v634_2));
          drop(v634_2);
          let v634_9: Space = if has_head(&(v634_8)) { singleton(&[]) } else { Space::new() };
          drop(v634_8);
          let v634_11: Space = if (&(v634_9)).is_empty() { Space::new() } else {
            let mut v645_10 = Space::new();
            let mut v645_10_write = v645_10.write_zipper();
            for v645_10_byte in v633_3_cursor.child_mask().iter() {
              v633_3_cursor.descend_to_existing_byte(v645_10_byte);
              {
              let v646_2: Space = singleton(&v633_3_cursor.path()[(v633_3_origin + 1)..(v633_3_origin + 2)]);
              let v646_3: Space = intersect(&(*CONSTANT_12),&(v646_2));
              let v646_4: Space = if has_head(&(v646_3)) { singleton(&[]) } else { Space::new() };
              drop(v646_3);
              let v646_5: Space = subtract(&(*CONSTANT_0),&(v646_4));
              drop(v646_4);
              let v646_8: Space = if (&(v646_5)).is_empty() { Space::new() } else {
                let mut v647_7 = Space::new();
                let mut v647_7_write = v647_7.write_zipper();
                for v647_7_byte in v633_3_cursor.child_mask().iter() {
                  v633_3_cursor.descend_to_existing_byte(v647_7_byte);
                  {
                  let v648_2: Space = singleton(&v633_3_cursor.path()[(v633_3_origin + 2)..(v633_3_origin + 3)]);
                  let v648_3: Space = intersect(&(*CONSTANT_12),&(v648_2));
                  let v648_4: Space = if has_head(&(v648_3)) { singleton(&[]) } else { Space::new() };
                  drop(v648_3);
                  let v648_5: Space = subtract(&(*CONSTANT_0),&(v648_4));
                  drop(v648_4);
                  let v648_8: Space = if (&(v648_5)).is_empty() { Space::new() } else {
                    let v649_7: Space = routine_41(c, &v633_3_cursor.path()[v633_3_origin..(v633_3_origin + 3)], &v633_3_cursor);
                    compose(&(v648_5),&(v649_7))
                  };
                  drop(v648_5);
                  let v648_9: Space = intersect(&(*CONSTANT_12),&(v648_2));
                  drop(v648_2);
                  let v648_10: Space = if has_head(&(v648_9)) { singleton(&[]) } else { Space::new() };
                  drop(v648_9);
                  let v648_12: Space = if (&(v648_10)).is_empty() { Space::new() } else {
                    let v650_11: Space = routine_42(c, &v633_3_cursor.path()[v633_3_origin..(v633_3_origin + 3)], &v633_3_cursor);
                    compose(&(v648_10),&(v650_11))
                  };
                  drop(v648_10);
                  let v648_13: Space = unite(&(v648_8),&(v648_12));
                  join_wrapped_into(&mut v647_7_write,&((v648_13).read_zipper()),&[]);
                  }
                  v633_3_cursor.ascend(1);
                }
                drop(v647_7_write);
                compose(&(v646_5),&(v647_7))
              };
              drop(v646_5);
              let v646_9: Space = intersect(&(*CONSTANT_12),&(v646_2));
              drop(v646_2);
              let v646_10: Space = if has_head(&(v646_9)) { singleton(&[]) } else { Space::new() };
              drop(v646_9);
              let v646_11: Space = compose(&(v646_10),&v633_3_cursor);
              drop(v646_10);
              let v646_12: Space = unite(&(v646_8),&(v646_11));
              drop(v646_11);
              join_wrapped_into(&mut v645_10_write,&((v646_12).read_zipper()),&[]);
              }
              v633_3_cursor.ascend(1);
            }
            drop(v645_10_write);
            compose(&(v634_9),&(v645_10))
          };
          drop(v634_9);
          let v634_12: Space = unite(&(v634_7),&(v634_11));
          join_wrapped_into(&mut v633_3_write,&((v634_12).read_zipper()),&[]);
          }
          v633_3_cursor.ascend(1);
        }
        drop(v633_3_cursor);
        drop(v633_3_write);
        drop(v633_2);
        let v633_4: Space = unite(&(v633_3),&(v632_6));
        let v633_5: Space = intersect(&(v633_4),&(*capture_2));
        if !v632_6.join_into((v633_5).clone()).is_element() { break; }
      }
      let mut v632_7: Space = ((*capture_5)).clone();
      loop {
        let v651_1: Space = intersect(&(v632_7),&(*capture_2));
        let v651_2: Space = restrict_to(&(*capture_0),&(v651_1));
        drop(v651_1);
        let mut v651_3 = Space::new();
        let mut v651_3_write = v651_3.write_zipper();
        let mut v651_3_cursor = (v651_2).read_zipper();
        let v651_3_origin = v651_3_cursor.path().len();
        for v651_3_byte in v651_3_cursor.child_mask().iter() {
          v651_3_cursor.descend_to_existing_byte(v651_3_byte);
          {
          let v652_2: Space = singleton(&v651_3_cursor.path()[v651_3_origin..(v651_3_origin + 1)]);
          let v652_3: Space = intersect(&(*CONSTANT_12),&(v652_2));
          let v652_4: Space = if has_head(&(v652_3)) { singleton(&[]) } else { Space::new() };
          drop(v652_3);
          let v652_5: Space = subtract(&(*CONSTANT_0),&(v652_4));
          drop(v652_4);
          let v652_7: Space = if (&(v652_5)).is_empty() { Space::new() } else {
            let mut v653_6 = Space::new();
            let mut v653_6_write = v653_6.write_zipper();
            for v653_6_byte in v651_3_cursor.child_mask().iter() {
              v651_3_cursor.descend_to_existing_byte(v653_6_byte);
              {
              let v654_2: Space = singleton(&v651_3_cursor.path()[(v651_3_origin + 1)..(v651_3_origin + 2)]);
              let v654_3: Space = intersect(&(*CONSTANT_12),&(v654_2));
              let v654_4: Space = if has_head(&(v654_3)) { singleton(&[]) } else { Space::new() };
              drop(v654_3);
              let v654_5: Space = subtract(&(*CONSTANT_0),&(v654_4));
              drop(v654_4);
              let v654_8: Space = if (&(v654_5)).is_empty() { Space::new() } else {
                let mut v655_7 = Space::new();
                let mut v655_7_write = v655_7.write_zipper();
                for v655_7_byte in v651_3_cursor.child_mask().iter() {
                  v651_3_cursor.descend_to_existing_byte(v655_7_byte);
                  {
                  let v656_2: Space = singleton(&v651_3_cursor.path()[(v651_3_origin + 2)..(v651_3_origin + 3)]);
                  let v656_3: Space = intersect(&(*CONSTANT_12),&(v656_2));
                  let v656_4: Space = if has_head(&(v656_3)) { singleton(&[]) } else { Space::new() };
                  drop(v656_3);
                  let v656_5: Space = subtract(&(*CONSTANT_0),&(v656_4));
                  drop(v656_4);
                  let v656_8: Space = if (&(v656_5)).is_empty() { Space::new() } else {
                    let v657_7: Space = routine_41(c, &v651_3_cursor.path()[v651_3_origin..(v651_3_origin + 3)], &v651_3_cursor);
                    compose(&(v656_5),&(v657_7))
                  };
                  drop(v656_5);
                  let v656_9: Space = intersect(&(*CONSTANT_12),&(v656_2));
                  drop(v656_2);
                  let v656_10: Space = if has_head(&(v656_9)) { singleton(&[]) } else { Space::new() };
                  drop(v656_9);
                  let v656_12: Space = if (&(v656_10)).is_empty() { Space::new() } else {
                    let v658_11: Space = routine_42(c, &v651_3_cursor.path()[v651_3_origin..(v651_3_origin + 3)], &v651_3_cursor);
                    compose(&(v656_10),&(v658_11))
                  };
                  drop(v656_10);
                  let v656_13: Space = unite(&(v656_8),&(v656_12));
                  join_wrapped_into(&mut v655_7_write,&((v656_13).read_zipper()),&[]);
                  }
                  v651_3_cursor.ascend(1);
                }
                drop(v655_7_write);
                compose(&(v654_5),&(v655_7))
              };
              drop(v654_5);
              let v654_9: Space = intersect(&(*CONSTANT_12),&(v654_2));
              drop(v654_2);
              let v654_10: Space = if has_head(&(v654_9)) { singleton(&[]) } else { Space::new() };
              drop(v654_9);
              let v654_12: Space = if (&(v654_10)).is_empty() { Space::new() } else {
                let mut v659_11 = Space::new();
                let mut v659_11_write = v659_11.write_zipper();
                for v659_11_byte in v651_3_cursor.child_mask().iter() {
                  v651_3_cursor.descend_to_existing_byte(v659_11_byte);
                  {
                  let v660_2: Space = singleton(&v651_3_cursor.path()[(v651_3_origin + 2)..(v651_3_origin + 3)]);
                  let v660_3: Space = intersect(&(*CONSTANT_12),&(v660_2));
                  let v660_4: Space = if has_head(&(v660_3)) { singleton(&[]) } else { Space::new() };
                  drop(v660_3);
                  let v660_5: Space = subtract(&(*CONSTANT_0),&(v660_4));
                  drop(v660_4);
                  let v660_8: Space = if (&(v660_5)).is_empty() { Space::new() } else {
                    let v661_7: Space = routine_41(c, &v651_3_cursor.path()[v651_3_origin..(v651_3_origin + 3)], &v651_3_cursor);
                    compose(&(v660_5),&(v661_7))
                  };
                  drop(v660_5);
                  let v660_9: Space = intersect(&(*CONSTANT_12),&(v660_2));
                  drop(v660_2);
                  let v660_10: Space = if has_head(&(v660_9)) { singleton(&[]) } else { Space::new() };
                  drop(v660_9);
                  let v660_12: Space = if (&(v660_10)).is_empty() { Space::new() } else {
                    let v662_11: Space = routine_43(c, &v651_3_cursor.path()[v651_3_origin..(v651_3_origin + 3)], &v651_3_cursor);
                    compose(&(v660_10),&(v662_11))
                  };
                  drop(v660_10);
                  let v660_13: Space = unite(&(v660_8),&(v660_12));
                  join_wrapped_into(&mut v659_11_write,&((v660_13).read_zipper()),&[]);
                  }
                  v651_3_cursor.ascend(1);
                }
                drop(v659_11_write);
                compose(&(v654_10),&(v659_11))
              };
              drop(v654_10);
              let v654_13: Space = unite(&(v654_8),&(v654_12));
              join_wrapped_into(&mut v653_6_write,&((v654_13).read_zipper()),&[]);
              }
              v651_3_cursor.ascend(1);
            }
            drop(v653_6_write);
            compose(&(v652_5),&(v653_6))
          };
          drop(v652_5);
          let v652_8: Space = intersect(&(*CONSTANT_12),&(v652_2));
          drop(v652_2);
          let v652_9: Space = if has_head(&(v652_8)) { singleton(&[]) } else { Space::new() };
          drop(v652_8);
          let v652_11: Space = if (&(v652_9)).is_empty() { Space::new() } else {
            let mut v663_10 = Space::new();
            let mut v663_10_write = v663_10.write_zipper();
            for v663_10_byte in v651_3_cursor.child_mask().iter() {
              v651_3_cursor.descend_to_existing_byte(v663_10_byte);
              {
              let v664_2: Space = singleton(&v651_3_cursor.path()[(v651_3_origin + 1)..(v651_3_origin + 2)]);
              let v664_3: Space = intersect(&(*CONSTANT_12),&(v664_2));
              let v664_4: Space = if has_head(&(v664_3)) { singleton(&[]) } else { Space::new() };
              drop(v664_3);
              let v664_5: Space = subtract(&(*CONSTANT_0),&(v664_4));
              drop(v664_4);
              let v664_8: Space = if (&(v664_5)).is_empty() { Space::new() } else {
                let mut v665_7 = Space::new();
                let mut v665_7_write = v665_7.write_zipper();
                for v665_7_byte in v651_3_cursor.child_mask().iter() {
                  v651_3_cursor.descend_to_existing_byte(v665_7_byte);
                  {
                  let v666_2: Space = singleton(&v651_3_cursor.path()[(v651_3_origin + 2)..(v651_3_origin + 3)]);
                  let v666_3: Space = intersect(&(*CONSTANT_12),&(v666_2));
                  let v666_4: Space = if has_head(&(v666_3)) { singleton(&[]) } else { Space::new() };
                  drop(v666_3);
                  let v666_5: Space = subtract(&(*CONSTANT_0),&(v666_4));
                  drop(v666_4);
                  let v666_8: Space = if (&(v666_5)).is_empty() { Space::new() } else {
                    let v667_7: Space = routine_41(c, &v651_3_cursor.path()[v651_3_origin..(v651_3_origin + 3)], &v651_3_cursor);
                    compose(&(v666_5),&(v667_7))
                  };
                  drop(v666_5);
                  let v666_9: Space = intersect(&(*CONSTANT_12),&(v666_2));
                  drop(v666_2);
                  let v666_10: Space = if has_head(&(v666_9)) { singleton(&[]) } else { Space::new() };
                  drop(v666_9);
                  let v666_12: Space = if (&(v666_10)).is_empty() { Space::new() } else {
                    let v668_11: Space = routine_42(c, &v651_3_cursor.path()[v651_3_origin..(v651_3_origin + 3)], &v651_3_cursor);
                    compose(&(v666_10),&(v668_11))
                  };
                  drop(v666_10);
                  let v666_13: Space = unite(&(v666_8),&(v666_12));
                  join_wrapped_into(&mut v665_7_write,&((v666_13).read_zipper()),&[]);
                  }
                  v651_3_cursor.ascend(1);
                }
                drop(v665_7_write);
                compose(&(v664_5),&(v665_7))
              };
              drop(v664_5);
              let v664_9: Space = intersect(&(*CONSTANT_12),&(v664_2));
              drop(v664_2);
              let v664_10: Space = if has_head(&(v664_9)) { singleton(&[]) } else { Space::new() };
              drop(v664_9);
              let v664_11: Space = compose(&(v664_10),&v651_3_cursor);
              drop(v664_10);
              let v664_12: Space = unite(&(v664_8),&(v664_11));
              drop(v664_11);
              join_wrapped_into(&mut v663_10_write,&((v664_12).read_zipper()),&[]);
              }
              v651_3_cursor.ascend(1);
            }
            drop(v663_10_write);
            compose(&(v652_9),&(v663_10))
          };
          drop(v652_9);
          let v652_12: Space = unite(&(v652_7),&(v652_11));
          join_wrapped_into(&mut v651_3_write,&((v652_12).read_zipper()),&[]);
          }
          v651_3_cursor.ascend(1);
        }
        drop(v651_3_cursor);
        drop(v651_3_write);
        drop(v651_2);
        let v651_4: Space = unite(&(v651_3),&(v632_7));
        let v651_5: Space = intersect(&(v651_4),&(*capture_2));
        if !v632_7.join_into((v651_5).clone()).is_element() { break; }
      }
      let v632_8: Space = subtract(&(v632_6),&(v632_7));
      let v632_9: Space = routine_16(c, &(*capture_3).path()[capture_4..(capture_4 + 1)], &(*capture_3), &(*capture_0), &(*capture_1), &((v632_8).read_zipper()));
      compose(&(v631_5),&(v632_9))
    };
    drop(v631_5);
    let v631_11: Space = intersect(&(*CONSTANT_12),&(v631_2));
    drop(v631_2);
    let v631_12: Space = if has_head(&(v631_11)) { singleton(&[]) } else { Space::new() };
    drop(v631_11);
    let v631_17: Space = if (&(v631_12)).is_empty() { Space::new() } else {
      let mut v669_13: Space = ((*capture_5)).clone();
      loop {
        let v670_1: Space = intersect(&(v669_13),&(*capture_2));
        let v670_2: Space = restrict_to(&(*capture_1),&(v670_1));
        drop(v670_1);
        let mut v670_3 = Space::new();
        let mut v670_3_write = v670_3.write_zipper();
        let mut v670_3_cursor = (v670_2).read_zipper();
        let v670_3_origin = v670_3_cursor.path().len();
        for v670_3_byte in v670_3_cursor.child_mask().iter() {
          v670_3_cursor.descend_to_existing_byte(v670_3_byte);
          {
          let v671_2: Space = singleton(&v670_3_cursor.path()[v670_3_origin..(v670_3_origin + 1)]);
          let v671_3: Space = intersect(&(*CONSTANT_12),&(v671_2));
          let v671_4: Space = if has_head(&(v671_3)) { singleton(&[]) } else { Space::new() };
          drop(v671_3);
          let v671_5: Space = subtract(&(*CONSTANT_0),&(v671_4));
          drop(v671_4);
          let v671_7: Space = if (&(v671_5)).is_empty() { Space::new() } else {
            let mut v672_6 = Space::new();
            let mut v672_6_write = v672_6.write_zipper();
            for v672_6_byte in v670_3_cursor.child_mask().iter() {
              v670_3_cursor.descend_to_existing_byte(v672_6_byte);
              {
              let v673_2: Space = singleton(&v670_3_cursor.path()[(v670_3_origin + 1)..(v670_3_origin + 2)]);
              let v673_3: Space = intersect(&(*CONSTANT_12),&(v673_2));
              let v673_4: Space = if has_head(&(v673_3)) { singleton(&[]) } else { Space::new() };
              drop(v673_3);
              let v673_5: Space = subtract(&(*CONSTANT_0),&(v673_4));
              drop(v673_4);
              let v673_8: Space = if (&(v673_5)).is_empty() { Space::new() } else {
                let mut v674_7 = Space::new();
                let mut v674_7_write = v674_7.write_zipper();
                for v674_7_byte in v670_3_cursor.child_mask().iter() {
                  v670_3_cursor.descend_to_existing_byte(v674_7_byte);
                  {
                  let v675_2: Space = singleton(&v670_3_cursor.path()[(v670_3_origin + 2)..(v670_3_origin + 3)]);
                  let v675_3: Space = intersect(&(*CONSTANT_12),&(v675_2));
                  let v675_4: Space = if has_head(&(v675_3)) { singleton(&[]) } else { Space::new() };
                  drop(v675_3);
                  let v675_5: Space = subtract(&(*CONSTANT_0),&(v675_4));
                  drop(v675_4);
                  let v675_8: Space = if (&(v675_5)).is_empty() { Space::new() } else {
                    let v676_7: Space = routine_41(c, &v670_3_cursor.path()[v670_3_origin..(v670_3_origin + 3)], &v670_3_cursor);
                    compose(&(v675_5),&(v676_7))
                  };
                  drop(v675_5);
                  let v675_9: Space = intersect(&(*CONSTANT_12),&(v675_2));
                  drop(v675_2);
                  let v675_10: Space = if has_head(&(v675_9)) { singleton(&[]) } else { Space::new() };
                  drop(v675_9);
                  let v675_12: Space = if (&(v675_10)).is_empty() { Space::new() } else {
                    let v677_11: Space = routine_42(c, &v670_3_cursor.path()[v670_3_origin..(v670_3_origin + 3)], &v670_3_cursor);
                    compose(&(v675_10),&(v677_11))
                  };
                  drop(v675_10);
                  let v675_13: Space = unite(&(v675_8),&(v675_12));
                  join_wrapped_into(&mut v674_7_write,&((v675_13).read_zipper()),&[]);
                  }
                  v670_3_cursor.ascend(1);
                }
                drop(v674_7_write);
                compose(&(v673_5),&(v674_7))
              };
              drop(v673_5);
              let v673_9: Space = intersect(&(*CONSTANT_12),&(v673_2));
              drop(v673_2);
              let v673_10: Space = if has_head(&(v673_9)) { singleton(&[]) } else { Space::new() };
              drop(v673_9);
              let v673_12: Space = if (&(v673_10)).is_empty() { Space::new() } else {
                let mut v678_11 = Space::new();
                let mut v678_11_write = v678_11.write_zipper();
                for v678_11_byte in v670_3_cursor.child_mask().iter() {
                  v670_3_cursor.descend_to_existing_byte(v678_11_byte);
                  {
                  let v679_2: Space = singleton(&v670_3_cursor.path()[(v670_3_origin + 2)..(v670_3_origin + 3)]);
                  let v679_3: Space = intersect(&(*CONSTANT_12),&(v679_2));
                  let v679_4: Space = if has_head(&(v679_3)) { singleton(&[]) } else { Space::new() };
                  drop(v679_3);
                  let v679_5: Space = subtract(&(*CONSTANT_0),&(v679_4));
                  drop(v679_4);
                  let v679_8: Space = if (&(v679_5)).is_empty() { Space::new() } else {
                    let v680_7: Space = routine_41(c, &v670_3_cursor.path()[v670_3_origin..(v670_3_origin + 3)], &v670_3_cursor);
                    compose(&(v679_5),&(v680_7))
                  };
                  drop(v679_5);
                  let v679_9: Space = intersect(&(*CONSTANT_12),&(v679_2));
                  drop(v679_2);
                  let v679_10: Space = if has_head(&(v679_9)) { singleton(&[]) } else { Space::new() };
                  drop(v679_9);
                  let v679_12: Space = if (&(v679_10)).is_empty() { Space::new() } else {
                    let v681_11: Space = routine_43(c, &v670_3_cursor.path()[v670_3_origin..(v670_3_origin + 3)], &v670_3_cursor);
                    compose(&(v679_10),&(v681_11))
                  };
                  drop(v679_10);
                  let v679_13: Space = unite(&(v679_8),&(v679_12));
                  join_wrapped_into(&mut v678_11_write,&((v679_13).read_zipper()),&[]);
                  }
                  v670_3_cursor.ascend(1);
                }
                drop(v678_11_write);
                compose(&(v673_10),&(v678_11))
              };
              drop(v673_10);
              let v673_13: Space = unite(&(v673_8),&(v673_12));
              join_wrapped_into(&mut v672_6_write,&((v673_13).read_zipper()),&[]);
              }
              v670_3_cursor.ascend(1);
            }
            drop(v672_6_write);
            compose(&(v671_5),&(v672_6))
          };
          drop(v671_5);
          let v671_8: Space = intersect(&(*CONSTANT_12),&(v671_2));
          drop(v671_2);
          let v671_9: Space = if has_head(&(v671_8)) { singleton(&[]) } else { Space::new() };
          drop(v671_8);
          let v671_11: Space = if (&(v671_9)).is_empty() { Space::new() } else {
            let mut v682_10 = Space::new();
            let mut v682_10_write = v682_10.write_zipper();
            for v682_10_byte in v670_3_cursor.child_mask().iter() {
              v670_3_cursor.descend_to_existing_byte(v682_10_byte);
              {
              let v683_2: Space = singleton(&v670_3_cursor.path()[(v670_3_origin + 1)..(v670_3_origin + 2)]);
              let v683_3: Space = intersect(&(*CONSTANT_12),&(v683_2));
              let v683_4: Space = if has_head(&(v683_3)) { singleton(&[]) } else { Space::new() };
              drop(v683_3);
              let v683_5: Space = subtract(&(*CONSTANT_0),&(v683_4));
              drop(v683_4);
              let v683_8: Space = if (&(v683_5)).is_empty() { Space::new() } else {
                let mut v684_7 = Space::new();
                let mut v684_7_write = v684_7.write_zipper();
                for v684_7_byte in v670_3_cursor.child_mask().iter() {
                  v670_3_cursor.descend_to_existing_byte(v684_7_byte);
                  {
                  let v685_2: Space = singleton(&v670_3_cursor.path()[(v670_3_origin + 2)..(v670_3_origin + 3)]);
                  let v685_3: Space = intersect(&(*CONSTANT_12),&(v685_2));
                  let v685_4: Space = if has_head(&(v685_3)) { singleton(&[]) } else { Space::new() };
                  drop(v685_3);
                  let v685_5: Space = subtract(&(*CONSTANT_0),&(v685_4));
                  drop(v685_4);
                  let v685_8: Space = if (&(v685_5)).is_empty() { Space::new() } else {
                    let v686_7: Space = routine_41(c, &v670_3_cursor.path()[v670_3_origin..(v670_3_origin + 3)], &v670_3_cursor);
                    compose(&(v685_5),&(v686_7))
                  };
                  drop(v685_5);
                  let v685_9: Space = intersect(&(*CONSTANT_12),&(v685_2));
                  drop(v685_2);
                  let v685_10: Space = if has_head(&(v685_9)) { singleton(&[]) } else { Space::new() };
                  drop(v685_9);
                  let v685_12: Space = if (&(v685_10)).is_empty() { Space::new() } else {
                    let v687_11: Space = routine_42(c, &v670_3_cursor.path()[v670_3_origin..(v670_3_origin + 3)], &v670_3_cursor);
                    compose(&(v685_10),&(v687_11))
                  };
                  drop(v685_10);
                  let v685_13: Space = unite(&(v685_8),&(v685_12));
                  join_wrapped_into(&mut v684_7_write,&((v685_13).read_zipper()),&[]);
                  }
                  v670_3_cursor.ascend(1);
                }
                drop(v684_7_write);
                compose(&(v683_5),&(v684_7))
              };
              drop(v683_5);
              let v683_9: Space = intersect(&(*CONSTANT_12),&(v683_2));
              drop(v683_2);
              let v683_10: Space = if has_head(&(v683_9)) { singleton(&[]) } else { Space::new() };
              drop(v683_9);
              let v683_11: Space = compose(&(v683_10),&v670_3_cursor);
              drop(v683_10);
              let v683_12: Space = unite(&(v683_8),&(v683_11));
              drop(v683_11);
              join_wrapped_into(&mut v682_10_write,&((v683_12).read_zipper()),&[]);
              }
              v670_3_cursor.ascend(1);
            }
            drop(v682_10_write);
            compose(&(v671_9),&(v682_10))
          };
          drop(v671_9);
          let v671_12: Space = unite(&(v671_7),&(v671_11));
          join_wrapped_into(&mut v670_3_write,&((v671_12).read_zipper()),&[]);
          }
          v670_3_cursor.ascend(1);
        }
        drop(v670_3_cursor);
        drop(v670_3_write);
        drop(v670_2);
        let v670_4: Space = unite(&(v670_3),&(v669_13));
        let v670_5: Space = intersect(&(v670_4),&(*capture_2));
        if !v669_13.join_into((v670_5).clone()).is_element() { break; }
      }
      let mut v669_14: Space = ((*capture_5)).clone();
      loop {
        let v688_1: Space = intersect(&(v669_14),&(*capture_2));
        let v688_2: Space = restrict_to(&(*capture_0),&(v688_1));
        drop(v688_1);
        let mut v688_3 = Space::new();
        let mut v688_3_write = v688_3.write_zipper();
        let mut v688_3_cursor = (v688_2).read_zipper();
        let v688_3_origin = v688_3_cursor.path().len();
        for v688_3_byte in v688_3_cursor.child_mask().iter() {
          v688_3_cursor.descend_to_existing_byte(v688_3_byte);
          {
          let v689_2: Space = singleton(&v688_3_cursor.path()[v688_3_origin..(v688_3_origin + 1)]);
          let v689_3: Space = intersect(&(*CONSTANT_12),&(v689_2));
          let v689_4: Space = if has_head(&(v689_3)) { singleton(&[]) } else { Space::new() };
          drop(v689_3);
          let v689_5: Space = subtract(&(*CONSTANT_0),&(v689_4));
          drop(v689_4);
          let v689_7: Space = if (&(v689_5)).is_empty() { Space::new() } else {
            let mut v690_6 = Space::new();
            let mut v690_6_write = v690_6.write_zipper();
            for v690_6_byte in v688_3_cursor.child_mask().iter() {
              v688_3_cursor.descend_to_existing_byte(v690_6_byte);
              {
              let v691_2: Space = singleton(&v688_3_cursor.path()[(v688_3_origin + 1)..(v688_3_origin + 2)]);
              let v691_3: Space = intersect(&(*CONSTANT_12),&(v691_2));
              let v691_4: Space = if has_head(&(v691_3)) { singleton(&[]) } else { Space::new() };
              drop(v691_3);
              let v691_5: Space = subtract(&(*CONSTANT_0),&(v691_4));
              drop(v691_4);
              let v691_8: Space = if (&(v691_5)).is_empty() { Space::new() } else {
                let mut v692_7 = Space::new();
                let mut v692_7_write = v692_7.write_zipper();
                for v692_7_byte in v688_3_cursor.child_mask().iter() {
                  v688_3_cursor.descend_to_existing_byte(v692_7_byte);
                  {
                  let v693_2: Space = singleton(&v688_3_cursor.path()[(v688_3_origin + 2)..(v688_3_origin + 3)]);
                  let v693_3: Space = intersect(&(*CONSTANT_12),&(v693_2));
                  let v693_4: Space = if has_head(&(v693_3)) { singleton(&[]) } else { Space::new() };
                  drop(v693_3);
                  let v693_5: Space = subtract(&(*CONSTANT_0),&(v693_4));
                  drop(v693_4);
                  let v693_8: Space = if (&(v693_5)).is_empty() { Space::new() } else {
                    let v694_7: Space = routine_41(c, &v688_3_cursor.path()[v688_3_origin..(v688_3_origin + 3)], &v688_3_cursor);
                    compose(&(v693_5),&(v694_7))
                  };
                  drop(v693_5);
                  let v693_9: Space = intersect(&(*CONSTANT_12),&(v693_2));
                  drop(v693_2);
                  let v693_10: Space = if has_head(&(v693_9)) { singleton(&[]) } else { Space::new() };
                  drop(v693_9);
                  let v693_12: Space = if (&(v693_10)).is_empty() { Space::new() } else {
                    let v695_11: Space = routine_42(c, &v688_3_cursor.path()[v688_3_origin..(v688_3_origin + 3)], &v688_3_cursor);
                    compose(&(v693_10),&(v695_11))
                  };
                  drop(v693_10);
                  let v693_13: Space = unite(&(v693_8),&(v693_12));
                  join_wrapped_into(&mut v692_7_write,&((v693_13).read_zipper()),&[]);
                  }
                  v688_3_cursor.ascend(1);
                }
                drop(v692_7_write);
                compose(&(v691_5),&(v692_7))
              };
              drop(v691_5);
              let v691_9: Space = intersect(&(*CONSTANT_12),&(v691_2));
              drop(v691_2);
              let v691_10: Space = if has_head(&(v691_9)) { singleton(&[]) } else { Space::new() };
              drop(v691_9);
              let v691_12: Space = if (&(v691_10)).is_empty() { Space::new() } else {
                let mut v696_11 = Space::new();
                let mut v696_11_write = v696_11.write_zipper();
                for v696_11_byte in v688_3_cursor.child_mask().iter() {
                  v688_3_cursor.descend_to_existing_byte(v696_11_byte);
                  {
                  let v697_2: Space = singleton(&v688_3_cursor.path()[(v688_3_origin + 2)..(v688_3_origin + 3)]);
                  let v697_3: Space = intersect(&(*CONSTANT_12),&(v697_2));
                  let v697_4: Space = if has_head(&(v697_3)) { singleton(&[]) } else { Space::new() };
                  drop(v697_3);
                  let v697_5: Space = subtract(&(*CONSTANT_0),&(v697_4));
                  drop(v697_4);
                  let v697_8: Space = if (&(v697_5)).is_empty() { Space::new() } else {
                    let v698_7: Space = routine_41(c, &v688_3_cursor.path()[v688_3_origin..(v688_3_origin + 3)], &v688_3_cursor);
                    compose(&(v697_5),&(v698_7))
                  };
                  drop(v697_5);
                  let v697_9: Space = intersect(&(*CONSTANT_12),&(v697_2));
                  drop(v697_2);
                  let v697_10: Space = if has_head(&(v697_9)) { singleton(&[]) } else { Space::new() };
                  drop(v697_9);
                  let v697_12: Space = if (&(v697_10)).is_empty() { Space::new() } else {
                    let v699_11: Space = routine_43(c, &v688_3_cursor.path()[v688_3_origin..(v688_3_origin + 3)], &v688_3_cursor);
                    compose(&(v697_10),&(v699_11))
                  };
                  drop(v697_10);
                  let v697_13: Space = unite(&(v697_8),&(v697_12));
                  join_wrapped_into(&mut v696_11_write,&((v697_13).read_zipper()),&[]);
                  }
                  v688_3_cursor.ascend(1);
                }
                drop(v696_11_write);
                compose(&(v691_10),&(v696_11))
              };
              drop(v691_10);
              let v691_13: Space = unite(&(v691_8),&(v691_12));
              join_wrapped_into(&mut v690_6_write,&((v691_13).read_zipper()),&[]);
              }
              v688_3_cursor.ascend(1);
            }
            drop(v690_6_write);
            compose(&(v689_5),&(v690_6))
          };
          drop(v689_5);
          let v689_8: Space = intersect(&(*CONSTANT_12),&(v689_2));
          drop(v689_2);
          let v689_9: Space = if has_head(&(v689_8)) { singleton(&[]) } else { Space::new() };
          drop(v689_8);
          let v689_11: Space = if (&(v689_9)).is_empty() { Space::new() } else {
            let mut v700_10 = Space::new();
            let mut v700_10_write = v700_10.write_zipper();
            for v700_10_byte in v688_3_cursor.child_mask().iter() {
              v688_3_cursor.descend_to_existing_byte(v700_10_byte);
              {
              let v701_2: Space = singleton(&v688_3_cursor.path()[(v688_3_origin + 1)..(v688_3_origin + 2)]);
              let v701_3: Space = intersect(&(*CONSTANT_12),&(v701_2));
              let v701_4: Space = if has_head(&(v701_3)) { singleton(&[]) } else { Space::new() };
              drop(v701_3);
              let v701_5: Space = subtract(&(*CONSTANT_0),&(v701_4));
              drop(v701_4);
              let v701_8: Space = if (&(v701_5)).is_empty() { Space::new() } else {
                let mut v702_7 = Space::new();
                let mut v702_7_write = v702_7.write_zipper();
                for v702_7_byte in v688_3_cursor.child_mask().iter() {
                  v688_3_cursor.descend_to_existing_byte(v702_7_byte);
                  {
                  let v703_2: Space = singleton(&v688_3_cursor.path()[(v688_3_origin + 2)..(v688_3_origin + 3)]);
                  let v703_3: Space = intersect(&(*CONSTANT_12),&(v703_2));
                  let v703_4: Space = if has_head(&(v703_3)) { singleton(&[]) } else { Space::new() };
                  drop(v703_3);
                  let v703_5: Space = subtract(&(*CONSTANT_0),&(v703_4));
                  drop(v703_4);
                  let v703_8: Space = if (&(v703_5)).is_empty() { Space::new() } else {
                    let v704_7: Space = routine_41(c, &v688_3_cursor.path()[v688_3_origin..(v688_3_origin + 3)], &v688_3_cursor);
                    compose(&(v703_5),&(v704_7))
                  };
                  drop(v703_5);
                  let v703_9: Space = intersect(&(*CONSTANT_12),&(v703_2));
                  drop(v703_2);
                  let v703_10: Space = if has_head(&(v703_9)) { singleton(&[]) } else { Space::new() };
                  drop(v703_9);
                  let v703_12: Space = if (&(v703_10)).is_empty() { Space::new() } else {
                    let v705_11: Space = routine_42(c, &v688_3_cursor.path()[v688_3_origin..(v688_3_origin + 3)], &v688_3_cursor);
                    compose(&(v703_10),&(v705_11))
                  };
                  drop(v703_10);
                  let v703_13: Space = unite(&(v703_8),&(v703_12));
                  join_wrapped_into(&mut v702_7_write,&((v703_13).read_zipper()),&[]);
                  }
                  v688_3_cursor.ascend(1);
                }
                drop(v702_7_write);
                compose(&(v701_5),&(v702_7))
              };
              drop(v701_5);
              let v701_9: Space = intersect(&(*CONSTANT_12),&(v701_2));
              drop(v701_2);
              let v701_10: Space = if has_head(&(v701_9)) { singleton(&[]) } else { Space::new() };
              drop(v701_9);
              let v701_11: Space = compose(&(v701_10),&v688_3_cursor);
              drop(v701_10);
              let v701_12: Space = unite(&(v701_8),&(v701_11));
              drop(v701_11);
              join_wrapped_into(&mut v700_10_write,&((v701_12).read_zipper()),&[]);
              }
              v688_3_cursor.ascend(1);
            }
            drop(v700_10_write);
            compose(&(v689_9),&(v700_10))
          };
          drop(v689_9);
          let v689_12: Space = unite(&(v689_7),&(v689_11));
          join_wrapped_into(&mut v688_3_write,&((v689_12).read_zipper()),&[]);
          }
          v688_3_cursor.ascend(1);
        }
        drop(v688_3_cursor);
        drop(v688_3_write);
        drop(v688_2);
        let v688_4: Space = unite(&(v688_3),&(v669_14));
        let v688_5: Space = intersect(&(v688_4),&(*capture_2));
        if !v669_14.join_into((v688_5).clone()).is_element() { break; }
      }
      let v669_15: Space = subtract(&(v669_13),&(v669_14));
      let v669_16: Space = routine_17(c, &(*capture_3).path()[capture_4..(capture_4 + 1)], &(*capture_3), &(*capture_0), &(*capture_1), &((v669_15).read_zipper()));
      compose(&(v631_12),&(v669_16))
    };
    drop(v631_12);

((v631_10).clone(),(v631_17).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let (mut v0_155,mut v0_22,mut v0_44,mut v0_63,mut v0_64,mut v0_65,) = native_block_0(c);
  (v0_155).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v82_4 = Space::new();
  let mut v82_4_write = v82_4.write_zipper();
  let mut v82_4_cursor = (*s0).read_zipper();
  let v82_4_origin = v82_4_cursor.path().len();
  for v82_4_byte in v82_4_cursor.child_mask().iter() {
    v82_4_cursor.descend_to_existing_byte(v82_4_byte);
    {
    let v83_2: Space = singleton(&v82_4_cursor.path()[v82_4_origin..(v82_4_origin + 1)]);
    let v83_3: Space = intersect(&(*CONSTANT_12),&(v83_2));
    drop(v83_2);
    let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
    drop(v83_3);
    let v83_7: Space = if (&(v83_4)).is_empty() { Space::new() } else {
      let v84_5: Path = concat_path(&(*p0),&v82_4_cursor.path()[v82_4_origin..(v82_4_origin + 1)]);
      let mut v84_6 = Space::new();
      let mut v84_6_write = v84_6.write_zipper();
      for v84_6_byte in v82_4_cursor.child_mask().iter() {
        v82_4_cursor.descend_to_existing_byte(v84_6_byte);
        {
        let v85_2: Space = singleton(&v82_4_cursor.path()[(v82_4_origin + 1)..(v82_4_origin + 2)]);
        let v85_3: Space = intersect(&(*CONSTANT_12),&(v85_2));
        drop(v85_2);
        let v85_4: Space = if has_head(&(v85_3)) { singleton(&[]) } else { Space::new() };
        drop(v85_3);
        let v85_7: Space = if (&(v85_4)).is_empty() { Space::new() } else {
          let v86_5: Path = concat_path(&(v84_5),&v82_4_cursor.path()[(v82_4_origin + 1)..(v82_4_origin + 2)]);
          let v86_6: Space = singleton(&(v86_5));
          drop(v86_5);
          compose(&(v85_4),&(v86_6))
        };
        drop(v85_4);
        join_wrapped_into(&mut v84_6_write,&((v85_7).read_zipper()),&[]);
        }
        v82_4_cursor.ascend(1);
      }
      drop(v84_6_write);
      drop(v84_5);
      compose(&(v83_4),&(v84_6))
    };
    drop(v83_4);
    join_wrapped_into(&mut v82_4_write,&((v83_7).read_zipper()),&[]);
    }
    v82_4_cursor.ascend(1);
  }
  drop(v82_4_cursor);
  drop(v82_4_write);
  (v82_4).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v87_3 = Space::new();
  let mut v87_3_write = v87_3.write_zipper();
  let mut v87_3_cursor = (*s0).read_zipper();
  let v87_3_origin = v87_3_cursor.path().len();
  for v87_3_byte in v87_3_cursor.child_mask().iter() {
    v87_3_cursor.descend_to_existing_byte(v87_3_byte);
    {
    let v88_2: Space = singleton(&v87_3_cursor.path()[v87_3_origin..(v87_3_origin + 1)]);
    let v88_3: Space = intersect(&(*CONSTANT_12),&(v88_2));
    drop(v88_2);
    let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
    drop(v88_3);
    let v88_7: Space = if (&(v88_4)).is_empty() { Space::new() } else {
      let v89_5: Path = concat_path(&(*p0),&v87_3_cursor.path()[v87_3_origin..(v87_3_origin + 1)]);
      let v89_6: Space = singleton(&(v89_5));
      drop(v89_5);
      compose(&(v88_4),&(v89_6))
    };
    drop(v88_4);
    join_wrapped_into(&mut v87_3_write,&((v88_7).read_zipper()),&[]);
    }
    v87_3_cursor.ascend(1);
  }
  drop(v87_3_cursor);
  drop(v87_3_write);
  (v87_3).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v90_2: Space = singleton(&(*p0));
  (v90_2).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v91_21 = Space::new();
  let mut v91_21_write = v91_21.write_zipper();
  let mut v91_21_cursor = (*s0).read_zipper();
  let v91_21_origin = v91_21_cursor.path().len();
  for v91_21_byte in v91_21_cursor.child_mask().iter() {
    v91_21_cursor.descend_to_existing_byte(v91_21_byte);
    {
    let v92_2: Space = singleton(&v91_21_cursor.path()[v91_21_origin..(v91_21_origin + 1)]);
    let v92_3: Space = intersect(&(*CONSTANT_12),&(v92_2));
    let v92_4: Space = if has_head(&(v92_3)) { singleton(&[]) } else { Space::new() };
    drop(v92_3);
    let v92_5: Space = subtract(&(*CONSTANT_0),&(v92_4));
    drop(v92_4);
    let v92_8: Space = if (&(v92_5)).is_empty() { Space::new() } else {
      let v93_6: Path = concat_path(&(*p0),&v91_21_cursor.path()[v91_21_origin..(v91_21_origin + 1)]);
      let mut v93_7 = Space::new();
      let mut v93_7_write = v93_7.write_zipper();
      for v93_7_byte in v91_21_cursor.child_mask().iter() {
        v91_21_cursor.descend_to_existing_byte(v93_7_byte);
        {
        let v94_2: Space = singleton(&v91_21_cursor.path()[(v91_21_origin + 1)..(v91_21_origin + 2)]);
        let v94_3: Space = intersect(&(*CONSTANT_12),&(v94_2));
        let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
        drop(v94_3);
        let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
        drop(v94_4);
        let v94_8: Space = if (&(v94_5)).is_empty() { Space::new() } else {
          let v95_6: Path = concat_path(&(v93_6),&v91_21_cursor.path()[(v91_21_origin + 1)..(v91_21_origin + 2)]);
          let mut v95_7 = Space::new();
          let mut v95_7_write = v95_7.write_zipper();
          for v95_7_byte in v91_21_cursor.child_mask().iter() {
            v91_21_cursor.descend_to_existing_byte(v95_7_byte);
            {
            let v96_2: Space = singleton(&v91_21_cursor.path()[(v91_21_origin + 2)..(v91_21_origin + 3)]);
            let v96_3: Space = intersect(&(*CONSTANT_12),&(v96_2));
            let v96_4: Space = if has_head(&(v96_3)) { singleton(&[]) } else { Space::new() };
            drop(v96_3);
            let v96_5: Space = subtract(&(*CONSTANT_0),&(v96_4));
            drop(v96_4);
            let v96_8: Space = if (&(v96_5)).is_empty() { Space::new() } else {
              let v97_6: Path = concat_path(&(v95_6),&v91_21_cursor.path()[(v91_21_origin + 2)..(v91_21_origin + 3)]);
              let v97_7: Space = routine_18(c, &(v97_6), &(*p1), &v91_21_cursor);
              compose(&(v96_5),&(v97_7))
            };
            drop(v96_5);
            let v96_9: Space = intersect(&(*CONSTANT_12),&(v96_2));
            drop(v96_2);
            let v96_10: Space = if has_head(&(v96_9)) { singleton(&[]) } else { Space::new() };
            drop(v96_9);
            let v96_12: Space = if (&(v96_10)).is_empty() { Space::new() } else {
              let v98_6: Path = concat_path(&(v95_6),&v91_21_cursor.path()[(v91_21_origin + 2)..(v91_21_origin + 3)]);
              let v98_11: Space = routine_19(c, &(v98_6), &(*p1), &v91_21_cursor);
              drop(v98_6);
              compose(&(v96_10),&(v98_11))
            };
            drop(v96_10);
            let v96_13: Space = unite(&(v96_8),&(v96_12));
            join_wrapped_into(&mut v95_7_write,&((v96_13).read_zipper()),&[]);
            }
            v91_21_cursor.ascend(1);
          }
          drop(v95_7_write);
          compose(&(v94_5),&(v95_7))
        };
        drop(v94_5);
        let v94_9: Space = intersect(&(*CONSTANT_12),&(v94_2));
        drop(v94_2);
        let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
        drop(v94_9);
        let v94_12: Space = if (&(v94_10)).is_empty() { Space::new() } else {
          let v99_6: Path = concat_path(&(v93_6),&v91_21_cursor.path()[(v91_21_origin + 1)..(v91_21_origin + 2)]);
          let mut v99_11 = Space::new();
          let mut v99_11_write = v99_11.write_zipper();
          for v99_11_byte in v91_21_cursor.child_mask().iter() {
            v91_21_cursor.descend_to_existing_byte(v99_11_byte);
            {
            let v100_2: Space = singleton(&v91_21_cursor.path()[(v91_21_origin + 2)..(v91_21_origin + 3)]);
            let v100_3: Space = intersect(&(*CONSTANT_12),&(v100_2));
            let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
            drop(v100_3);
            let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
            drop(v100_4);
            let v100_8: Space = if (&(v100_5)).is_empty() { Space::new() } else {
              let v101_6: Path = concat_path(&(v99_6),&v91_21_cursor.path()[(v91_21_origin + 2)..(v91_21_origin + 3)]);
              let v101_7: Space = routine_18(c, &(v101_6), &(*p1), &v91_21_cursor);
              compose(&(v100_5),&(v101_7))
            };
            drop(v100_5);
            let v100_9: Space = intersect(&(*CONSTANT_12),&(v100_2));
            drop(v100_2);
            let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
            drop(v100_9);
            let v100_12: Space = if (&(v100_10)).is_empty() { Space::new() } else {
              let v102_6: Path = concat_path(&(v99_6),&v91_21_cursor.path()[(v91_21_origin + 2)..(v91_21_origin + 3)]);
              let v102_11: Space = routine_20(c, &(v102_6), &(*p1), &v91_21_cursor);
              drop(v102_6);
              compose(&(v100_10),&(v102_11))
            };
            drop(v100_10);
            let v100_13: Space = unite(&(v100_8),&(v100_12));
            join_wrapped_into(&mut v99_11_write,&((v100_13).read_zipper()),&[]);
            }
            v91_21_cursor.ascend(1);
          }
          drop(v99_11_write);
          drop(v99_6);
          compose(&(v94_10),&(v99_11))
        };
        drop(v94_10);
        let v94_13: Space = unite(&(v94_8),&(v94_12));
        join_wrapped_into(&mut v93_7_write,&((v94_13).read_zipper()),&[]);
        }
        v91_21_cursor.ascend(1);
      }
      drop(v93_7_write);
      compose(&(v92_5),&(v93_7))
    };
    drop(v92_5);
    let v92_9: Space = intersect(&(*CONSTANT_12),&(v92_2));
    drop(v92_2);
    let v92_10: Space = if has_head(&(v92_9)) { singleton(&[]) } else { Space::new() };
    drop(v92_9);
    let v92_12: Space = if (&(v92_10)).is_empty() { Space::new() } else {
      let v103_6: Path = concat_path(&(*p0),&v91_21_cursor.path()[v91_21_origin..(v91_21_origin + 1)]);
      let mut v103_11 = Space::new();
      let mut v103_11_write = v103_11.write_zipper();
      for v103_11_byte in v91_21_cursor.child_mask().iter() {
        v91_21_cursor.descend_to_existing_byte(v103_11_byte);
        {
        let v104_2: Space = singleton(&v91_21_cursor.path()[(v91_21_origin + 1)..(v91_21_origin + 2)]);
        let v104_3: Space = intersect(&(*CONSTANT_12),&(v104_2));
        let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
        drop(v104_3);
        let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
        drop(v104_4);
        let v104_8: Space = if (&(v104_5)).is_empty() { Space::new() } else {
          let v105_6: Path = concat_path(&(v103_6),&v91_21_cursor.path()[(v91_21_origin + 1)..(v91_21_origin + 2)]);
          let mut v105_7 = Space::new();
          let mut v105_7_write = v105_7.write_zipper();
          for v105_7_byte in v91_21_cursor.child_mask().iter() {
            v91_21_cursor.descend_to_existing_byte(v105_7_byte);
            {
            let v106_2: Space = singleton(&v91_21_cursor.path()[(v91_21_origin + 2)..(v91_21_origin + 3)]);
            let v106_3: Space = intersect(&(*CONSTANT_12),&(v106_2));
            let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
            drop(v106_3);
            let v106_5: Space = subtract(&(*CONSTANT_0),&(v106_4));
            drop(v106_4);
            let v106_8: Space = if (&(v106_5)).is_empty() { Space::new() } else {
              let v107_6: Path = concat_path(&(v105_6),&v91_21_cursor.path()[(v91_21_origin + 2)..(v91_21_origin + 3)]);
              let v107_7: Space = routine_18(c, &(v107_6), &(*p1), &v91_21_cursor);
              compose(&(v106_5),&(v107_7))
            };
            drop(v106_5);
            let v106_9: Space = intersect(&(*CONSTANT_12),&(v106_2));
            drop(v106_2);
            let v106_10: Space = if has_head(&(v106_9)) { singleton(&[]) } else { Space::new() };
            drop(v106_9);
            let v106_12: Space = if (&(v106_10)).is_empty() { Space::new() } else {
              let v108_6: Path = concat_path(&(v105_6),&v91_21_cursor.path()[(v91_21_origin + 2)..(v91_21_origin + 3)]);
              let v108_11: Space = routine_19(c, &(v108_6), &(*p1), &v91_21_cursor);
              drop(v108_6);
              compose(&(v106_10),&(v108_11))
            };
            drop(v106_10);
            let v106_13: Space = unite(&(v106_8),&(v106_12));
            join_wrapped_into(&mut v105_7_write,&((v106_13).read_zipper()),&[]);
            }
            v91_21_cursor.ascend(1);
          }
          drop(v105_7_write);
          compose(&(v104_5),&(v105_7))
        };
        drop(v104_5);
        let v104_9: Space = intersect(&(*CONSTANT_12),&(v104_2));
        drop(v104_2);
        let v104_10: Space = if has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
        drop(v104_9);
        let v104_13: Space = if (&(v104_10)).is_empty() { Space::new() } else {
          let v109_6: Path = concat_path(&(v103_6),&v91_21_cursor.path()[(v91_21_origin + 1)..(v91_21_origin + 2)]);
          let v109_11: Path = concat_path(&(v109_6),&(*p1));
          drop(v109_6);
          let v109_12: Space = singleton(&(v109_11));
          drop(v109_11);
          compose(&(v104_10),&(v109_12))
        };
        drop(v104_10);
        let v104_14: Space = unite(&(v104_8),&(v104_13));
        drop(v104_13);
        join_wrapped_into(&mut v103_11_write,&((v104_14).read_zipper()),&[]);
        }
        v91_21_cursor.ascend(1);
      }
      drop(v103_11_write);
      drop(v103_6);
      compose(&(v92_10),&(v103_11))
    };
    drop(v92_10);
    let v92_13: Space = unite(&(v92_8),&(v92_12));
    join_wrapped_into(&mut v91_21_write,&((v92_13).read_zipper()),&[]);
    }
    v91_21_cursor.ascend(1);
  }
  drop(v91_21_cursor);
  drop(v91_21_write);
  (v91_21).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v110_7 = Space::new();
  let mut v110_7_write = v110_7.write_zipper();
  let mut v110_7_cursor = (*s0).read_zipper();
  let v110_7_origin = v110_7_cursor.path().len();
  for v110_7_byte in v110_7_cursor.child_mask().iter() {
    v110_7_cursor.descend_to_existing_byte(v110_7_byte);
    {
    let v111_2: Space = singleton(&v110_7_cursor.path()[v110_7_origin..(v110_7_origin + 1)]);
    let v111_3: Space = intersect(&(*CONSTANT_12),&(v111_2));
    drop(v111_2);
    let v111_4: Space = if has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
    drop(v111_3);
    let v111_7: Space = if (&(v111_4)).is_empty() { Space::new() } else {
      let v112_5: Path = concat_path(&(*p0),&v110_7_cursor.path()[v110_7_origin..(v110_7_origin + 1)]);
      let mut v112_6 = Space::new();
      let mut v112_6_write = v112_6.write_zipper();
      for v112_6_byte in v110_7_cursor.child_mask().iter() {
        v110_7_cursor.descend_to_existing_byte(v112_6_byte);
        {
        let v113_2: Space = singleton(&v110_7_cursor.path()[(v110_7_origin + 1)..(v110_7_origin + 2)]);
        let v113_3: Space = intersect(&(*CONSTANT_12),&(v113_2));
        drop(v113_2);
        let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
        drop(v113_3);
        let v113_7: Space = if (&(v113_4)).is_empty() { Space::new() } else {
          let v114_5: Path = concat_path(&(v112_5),&v110_7_cursor.path()[(v110_7_origin + 1)..(v110_7_origin + 2)]);
          let mut v114_6 = Space::new();
          let mut v114_6_write = v114_6.write_zipper();
          for v114_6_byte in v110_7_cursor.child_mask().iter() {
            v110_7_cursor.descend_to_existing_byte(v114_6_byte);
            {
            let v115_2: Space = singleton(&v110_7_cursor.path()[(v110_7_origin + 2)..(v110_7_origin + 3)]);
            let v115_3: Space = intersect(&(*CONSTANT_12),&(v115_2));
            let v115_4: Space = if has_head(&(v115_3)) { singleton(&[]) } else { Space::new() };
            drop(v115_3);
            let v115_5: Space = subtract(&(*CONSTANT_0),&(v115_4));
            drop(v115_4);
            let v115_7: Space = if (&(v115_5)).is_empty() { Space::new() } else {
              let v116_6: Space = routine_4(c, &v110_7_cursor.path()[(v110_7_origin + 2)..(v110_7_origin + 3)], &(v114_5), &v110_7_cursor);
              compose(&(v115_5),&(v116_6))
            };
            drop(v115_5);
            let v115_8: Space = intersect(&(*CONSTANT_12),&(v115_2));
            drop(v115_2);
            let v115_9: Space = if has_head(&(v115_8)) { singleton(&[]) } else { Space::new() };
            drop(v115_8);
            let v115_11: Space = if (&(v115_9)).is_empty() { Space::new() } else {
              let v117_10: Space = routine_21(c, &v110_7_cursor.path()[(v110_7_origin + 2)..(v110_7_origin + 3)], &(v114_5), &v110_7_cursor);
              compose(&(v115_9),&(v117_10))
            };
            drop(v115_9);
            let v115_12: Space = unite(&(v115_7),&(v115_11));
            join_wrapped_into(&mut v114_6_write,&((v115_12).read_zipper()),&[]);
            }
            v110_7_cursor.ascend(1);
          }
          drop(v114_6_write);
          drop(v114_5);
          compose(&(v113_4),&(v114_6))
        };
        drop(v113_4);
        join_wrapped_into(&mut v112_6_write,&((v113_7).read_zipper()),&[]);
        }
        v110_7_cursor.ascend(1);
      }
      drop(v112_6_write);
      drop(v112_5);
      compose(&(v111_4),&(v112_6))
    };
    drop(v111_4);
    join_wrapped_into(&mut v110_7_write,&((v111_7).read_zipper()),&[]);
    }
    v110_7_cursor.ascend(1);
  }
  drop(v110_7_cursor);
  drop(v110_7_write);
  (v110_7).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v118_12 = Space::new();
  let mut v118_12_write = v118_12.write_zipper();
  let mut v118_12_cursor = (*s0).read_zipper();
  let v118_12_origin = v118_12_cursor.path().len();
  for v118_12_byte in v118_12_cursor.child_mask().iter() {
    v118_12_cursor.descend_to_existing_byte(v118_12_byte);
    {
    let v119_2: Space = singleton(&v118_12_cursor.path()[v118_12_origin..(v118_12_origin + 1)]);
    let v119_3: Space = intersect(&(*CONSTANT_12),&(v119_2));
    drop(v119_2);
    let v119_4: Space = if has_head(&(v119_3)) { singleton(&[]) } else { Space::new() };
    drop(v119_3);
    let v119_7: Space = if (&(v119_4)).is_empty() { Space::new() } else {
      let v120_5: Path = concat_path(&(*p0),&v118_12_cursor.path()[v118_12_origin..(v118_12_origin + 1)]);
      let mut v120_6 = Space::new();
      let mut v120_6_write = v120_6.write_zipper();
      for v120_6_byte in v118_12_cursor.child_mask().iter() {
        v118_12_cursor.descend_to_existing_byte(v120_6_byte);
        {
        let v121_2: Space = singleton(&v118_12_cursor.path()[(v118_12_origin + 1)..(v118_12_origin + 2)]);
        let v121_3: Space = intersect(&(*CONSTANT_12),&(v121_2));
        let v121_4: Space = if has_head(&(v121_3)) { singleton(&[]) } else { Space::new() };
        drop(v121_3);
        let v121_5: Space = subtract(&(*CONSTANT_0),&(v121_4));
        drop(v121_4);
        let v121_7: Space = if (&(v121_5)).is_empty() { Space::new() } else {
          let mut v122_6 = Space::new();
          let mut v122_6_write = v122_6.write_zipper();
          for v122_6_byte in v118_12_cursor.child_mask().iter() {
            v118_12_cursor.descend_to_existing_byte(v122_6_byte);
            {
            let v123_2: Space = singleton(&v118_12_cursor.path()[(v118_12_origin + 2)..(v118_12_origin + 3)]);
            let v123_3: Space = intersect(&(*CONSTANT_12),&(v123_2));
            let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
            drop(v123_3);
            let v123_5: Space = subtract(&(*CONSTANT_0),&(v123_4));
            drop(v123_4);
            let v123_8: Space = if (&(v123_5)).is_empty() { Space::new() } else {
              let v124_7: Space = routine_22(c, &v118_12_cursor.path()[(v118_12_origin + 1)..(v118_12_origin + 3)], &(v120_5), &v118_12_cursor);
              compose(&(v123_5),&(v124_7))
            };
            drop(v123_5);
            let v123_9: Space = intersect(&(*CONSTANT_12),&(v123_2));
            drop(v123_2);
            let v123_10: Space = if has_head(&(v123_9)) { singleton(&[]) } else { Space::new() };
            drop(v123_9);
            let v123_12: Space = if (&(v123_10)).is_empty() { Space::new() } else {
              let v125_11: Space = routine_23(c, &v118_12_cursor.path()[(v118_12_origin + 1)..(v118_12_origin + 3)], &(v120_5), &v118_12_cursor);
              compose(&(v123_10),&(v125_11))
            };
            drop(v123_10);
            let v123_13: Space = unite(&(v123_8),&(v123_12));
            join_wrapped_into(&mut v122_6_write,&((v123_13).read_zipper()),&[]);
            }
            v118_12_cursor.ascend(1);
          }
          drop(v122_6_write);
          compose(&(v121_5),&(v122_6))
        };
        drop(v121_5);
        let v121_8: Space = intersect(&(*CONSTANT_12),&(v121_2));
        drop(v121_2);
        let v121_9: Space = if has_head(&(v121_8)) { singleton(&[]) } else { Space::new() };
        drop(v121_8);
        let v121_11: Space = if (&(v121_9)).is_empty() { Space::new() } else {
          let mut v126_10 = Space::new();
          let mut v126_10_write = v126_10.write_zipper();
          for v126_10_byte in v118_12_cursor.child_mask().iter() {
            v118_12_cursor.descend_to_existing_byte(v126_10_byte);
            {
            let v127_2: Space = singleton(&v118_12_cursor.path()[(v118_12_origin + 2)..(v118_12_origin + 3)]);
            let v127_3: Space = intersect(&(*CONSTANT_12),&(v127_2));
            let v127_4: Space = if has_head(&(v127_3)) { singleton(&[]) } else { Space::new() };
            drop(v127_3);
            let v127_5: Space = subtract(&(*CONSTANT_0),&(v127_4));
            drop(v127_4);
            let v127_8: Space = if (&(v127_5)).is_empty() { Space::new() } else {
              let v128_7: Space = routine_22(c, &v118_12_cursor.path()[(v118_12_origin + 1)..(v118_12_origin + 3)], &(v120_5), &v118_12_cursor);
              compose(&(v127_5),&(v128_7))
            };
            drop(v127_5);
            let v127_9: Space = intersect(&(*CONSTANT_12),&(v127_2));
            drop(v127_2);
            let v127_10: Space = if has_head(&(v127_9)) { singleton(&[]) } else { Space::new() };
            drop(v127_9);
            let v127_12: Space = if (&(v127_10)).is_empty() { Space::new() } else {
              let v129_11: Space = routine_20(c, &v118_12_cursor.path()[(v118_12_origin + 1)..(v118_12_origin + 3)], &(v120_5), &v118_12_cursor);
              compose(&(v127_10),&(v129_11))
            };
            drop(v127_10);
            let v127_13: Space = unite(&(v127_8),&(v127_12));
            join_wrapped_into(&mut v126_10_write,&((v127_13).read_zipper()),&[]);
            }
            v118_12_cursor.ascend(1);
          }
          drop(v126_10_write);
          compose(&(v121_9),&(v126_10))
        };
        drop(v121_9);
        let v121_12: Space = unite(&(v121_7),&(v121_11));
        join_wrapped_into(&mut v120_6_write,&((v121_12).read_zipper()),&[]);
        }
        v118_12_cursor.ascend(1);
      }
      drop(v120_6_write);
      drop(v120_5);
      compose(&(v119_4),&(v120_6))
    };
    drop(v119_4);
    join_wrapped_into(&mut v118_12_write,&((v119_7).read_zipper()),&[]);
    }
    v118_12_cursor.ascend(1);
  }
  drop(v118_12_cursor);
  drop(v118_12_write);
  (v118_12).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v130_20 = Space::new();
  let mut v130_20_write = v130_20.write_zipper();
  let mut v130_20_cursor = (*s0).read_zipper();
  let v130_20_origin = v130_20_cursor.path().len();
  for v130_20_byte in v130_20_cursor.child_mask().iter() {
    v130_20_cursor.descend_to_existing_byte(v130_20_byte);
    {
    let v131_2: Space = singleton(&v130_20_cursor.path()[v130_20_origin..(v130_20_origin + 1)]);
    let v131_3: Space = intersect(&(*CONSTANT_12),&(v131_2));
    let v131_4: Space = if has_head(&(v131_3)) { singleton(&[]) } else { Space::new() };
    drop(v131_3);
    let v131_5: Space = subtract(&(*CONSTANT_0),&(v131_4));
    drop(v131_4);
    let v131_7: Space = if (&(v131_5)).is_empty() { Space::new() } else {
      let mut v132_6 = Space::new();
      let mut v132_6_write = v132_6.write_zipper();
      for v132_6_byte in v130_20_cursor.child_mask().iter() {
        v130_20_cursor.descend_to_existing_byte(v132_6_byte);
        {
        let v133_2: Space = singleton(&v130_20_cursor.path()[(v130_20_origin + 1)..(v130_20_origin + 2)]);
        let v133_3: Space = intersect(&(*CONSTANT_12),&(v133_2));
        let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
        drop(v133_3);
        let v133_5: Space = subtract(&(*CONSTANT_0),&(v133_4));
        drop(v133_4);
        let v133_8: Space = if (&(v133_5)).is_empty() { Space::new() } else {
          let mut v134_7 = Space::new();
          let mut v134_7_write = v134_7.write_zipper();
          for v134_7_byte in v130_20_cursor.child_mask().iter() {
            v130_20_cursor.descend_to_existing_byte(v134_7_byte);
            {
            let v135_2: Space = singleton(&v130_20_cursor.path()[(v130_20_origin + 2)..(v130_20_origin + 3)]);
            let v135_3: Space = intersect(&(*CONSTANT_12),&(v135_2));
            let v135_4: Space = if has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
            drop(v135_3);
            let v135_5: Space = subtract(&(*CONSTANT_0),&(v135_4));
            drop(v135_4);
            let v135_8: Space = if (&(v135_5)).is_empty() { Space::new() } else {
              let v136_7: Space = routine_24(c, &v130_20_cursor.path()[v130_20_origin..(v130_20_origin + 3)], &(*p0), &v130_20_cursor);
              compose(&(v135_5),&(v136_7))
            };
            drop(v135_5);
            let v135_9: Space = intersect(&(*CONSTANT_12),&(v135_2));
            drop(v135_2);
            let v135_10: Space = if has_head(&(v135_9)) { singleton(&[]) } else { Space::new() };
            drop(v135_9);
            let v135_12: Space = if (&(v135_10)).is_empty() { Space::new() } else {
              let v137_11: Space = routine_25(c, &v130_20_cursor.path()[v130_20_origin..(v130_20_origin + 3)], &(*p0), &v130_20_cursor);
              compose(&(v135_10),&(v137_11))
            };
            drop(v135_10);
            let v135_13: Space = unite(&(v135_8),&(v135_12));
            join_wrapped_into(&mut v134_7_write,&((v135_13).read_zipper()),&[]);
            }
            v130_20_cursor.ascend(1);
          }
          drop(v134_7_write);
          compose(&(v133_5),&(v134_7))
        };
        drop(v133_5);
        let v133_9: Space = intersect(&(*CONSTANT_12),&(v133_2));
        drop(v133_2);
        let v133_10: Space = if has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
        drop(v133_9);
        let v133_12: Space = if (&(v133_10)).is_empty() { Space::new() } else {
          let mut v138_11 = Space::new();
          let mut v138_11_write = v138_11.write_zipper();
          for v138_11_byte in v130_20_cursor.child_mask().iter() {
            v130_20_cursor.descend_to_existing_byte(v138_11_byte);
            {
            let v139_2: Space = singleton(&v130_20_cursor.path()[(v130_20_origin + 2)..(v130_20_origin + 3)]);
            let v139_3: Space = intersect(&(*CONSTANT_12),&(v139_2));
            let v139_4: Space = if has_head(&(v139_3)) { singleton(&[]) } else { Space::new() };
            drop(v139_3);
            let v139_5: Space = subtract(&(*CONSTANT_0),&(v139_4));
            drop(v139_4);
            let v139_8: Space = if (&(v139_5)).is_empty() { Space::new() } else {
              let v140_7: Space = routine_24(c, &v130_20_cursor.path()[v130_20_origin..(v130_20_origin + 3)], &(*p0), &v130_20_cursor);
              compose(&(v139_5),&(v140_7))
            };
            drop(v139_5);
            let v139_9: Space = intersect(&(*CONSTANT_12),&(v139_2));
            drop(v139_2);
            let v139_10: Space = if has_head(&(v139_9)) { singleton(&[]) } else { Space::new() };
            drop(v139_9);
            let v139_12: Space = if (&(v139_10)).is_empty() { Space::new() } else {
              let v141_11: Space = routine_20(c, &v130_20_cursor.path()[v130_20_origin..(v130_20_origin + 3)], &(*p0), &v130_20_cursor);
              compose(&(v139_10),&(v141_11))
            };
            drop(v139_10);
            let v139_13: Space = unite(&(v139_8),&(v139_12));
            join_wrapped_into(&mut v138_11_write,&((v139_13).read_zipper()),&[]);
            }
            v130_20_cursor.ascend(1);
          }
          drop(v138_11_write);
          compose(&(v133_10),&(v138_11))
        };
        drop(v133_10);
        let v133_13: Space = unite(&(v133_8),&(v133_12));
        join_wrapped_into(&mut v132_6_write,&((v133_13).read_zipper()),&[]);
        }
        v130_20_cursor.ascend(1);
      }
      drop(v132_6_write);
      compose(&(v131_5),&(v132_6))
    };
    drop(v131_5);
    let v131_8: Space = intersect(&(*CONSTANT_12),&(v131_2));
    drop(v131_2);
    let v131_9: Space = if has_head(&(v131_8)) { singleton(&[]) } else { Space::new() };
    drop(v131_8);
    let v131_11: Space = if (&(v131_9)).is_empty() { Space::new() } else {
      let mut v142_10 = Space::new();
      let mut v142_10_write = v142_10.write_zipper();
      for v142_10_byte in v130_20_cursor.child_mask().iter() {
        v130_20_cursor.descend_to_existing_byte(v142_10_byte);
        {
        let v143_2: Space = singleton(&v130_20_cursor.path()[(v130_20_origin + 1)..(v130_20_origin + 2)]);
        let v143_3: Space = intersect(&(*CONSTANT_12),&(v143_2));
        let v143_4: Space = if has_head(&(v143_3)) { singleton(&[]) } else { Space::new() };
        drop(v143_3);
        let v143_5: Space = subtract(&(*CONSTANT_0),&(v143_4));
        drop(v143_4);
        let v143_8: Space = if (&(v143_5)).is_empty() { Space::new() } else {
          let mut v144_7 = Space::new();
          let mut v144_7_write = v144_7.write_zipper();
          for v144_7_byte in v130_20_cursor.child_mask().iter() {
            v130_20_cursor.descend_to_existing_byte(v144_7_byte);
            {
            let v145_2: Space = singleton(&v130_20_cursor.path()[(v130_20_origin + 2)..(v130_20_origin + 3)]);
            let v145_3: Space = intersect(&(*CONSTANT_12),&(v145_2));
            let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
            drop(v145_3);
            let v145_5: Space = subtract(&(*CONSTANT_0),&(v145_4));
            drop(v145_4);
            let v145_8: Space = if (&(v145_5)).is_empty() { Space::new() } else {
              let v146_7: Space = routine_24(c, &v130_20_cursor.path()[v130_20_origin..(v130_20_origin + 3)], &(*p0), &v130_20_cursor);
              compose(&(v145_5),&(v146_7))
            };
            drop(v145_5);
            let v145_9: Space = intersect(&(*CONSTANT_12),&(v145_2));
            drop(v145_2);
            let v145_10: Space = if has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
            drop(v145_9);
            let v145_12: Space = if (&(v145_10)).is_empty() { Space::new() } else {
              let v147_11: Space = routine_25(c, &v130_20_cursor.path()[v130_20_origin..(v130_20_origin + 3)], &(*p0), &v130_20_cursor);
              compose(&(v145_10),&(v147_11))
            };
            drop(v145_10);
            let v145_13: Space = unite(&(v145_8),&(v145_12));
            join_wrapped_into(&mut v144_7_write,&((v145_13).read_zipper()),&[]);
            }
            v130_20_cursor.ascend(1);
          }
          drop(v144_7_write);
          compose(&(v143_5),&(v144_7))
        };
        drop(v143_5);
        let v143_9: Space = intersect(&(*CONSTANT_12),&(v143_2));
        drop(v143_2);
        let v143_10: Space = if has_head(&(v143_9)) { singleton(&[]) } else { Space::new() };
        drop(v143_9);
        let v143_13: Space = if (&(v143_10)).is_empty() { Space::new() } else {
          let v148_11: Path = concat_path(&v130_20_cursor.path()[v130_20_origin..(v130_20_origin + 2)],&(*p0));
          let v148_12: Space = singleton(&(v148_11));
          drop(v148_11);
          compose(&(v143_10),&(v148_12))
        };
        drop(v143_10);
        let v143_14: Space = unite(&(v143_8),&(v143_13));
        drop(v143_13);
        join_wrapped_into(&mut v142_10_write,&((v143_14).read_zipper()),&[]);
        }
        v130_20_cursor.ascend(1);
      }
      drop(v142_10_write);
      compose(&(v131_9),&(v142_10))
    };
    drop(v131_9);
    let v131_12: Space = unite(&(v131_7),&(v131_11));
    join_wrapped_into(&mut v130_20_write,&((v131_12).read_zipper()),&[]);
    }
    v130_20_cursor.ascend(1);
  }
  drop(v130_20_cursor);
  drop(v130_20_write);
  (v130_20).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v149_4 = Space::new();
  let mut v149_4_write = v149_4.write_zipper();
  let mut v149_4_cursor = (*s0).read_zipper();
  let v149_4_origin = v149_4_cursor.path().len();
  for v149_4_byte in v149_4_cursor.child_mask().iter() {
    v149_4_cursor.descend_to_existing_byte(v149_4_byte);
    {
    let v150_2: Space = singleton(&v149_4_cursor.path()[v149_4_origin..(v149_4_origin + 1)]);
    let v150_3: Space = intersect(&(*CONSTANT_12),&(v150_2));
    drop(v150_2);
    let v150_4: Space = if has_head(&(v150_3)) { singleton(&[]) } else { Space::new() };
    drop(v150_3);
    let v150_7: Space = if (&(v150_4)).is_empty() { Space::new() } else {
      let v151_5: Path = concat_path(&(*p0),&v149_4_cursor.path()[v149_4_origin..(v149_4_origin + 1)]);
      let mut v151_6 = Space::new();
      let mut v151_6_write = v151_6.write_zipper();
      for v151_6_byte in v149_4_cursor.child_mask().iter() {
        v149_4_cursor.descend_to_existing_byte(v151_6_byte);
        {
        let v152_2: Space = singleton(&v149_4_cursor.path()[(v149_4_origin + 1)..(v149_4_origin + 2)]);
        let v152_3: Space = intersect(&(*CONSTANT_12),&(v152_2));
        drop(v152_2);
        let v152_4: Space = if has_head(&(v152_3)) { singleton(&[]) } else { Space::new() };
        drop(v152_3);
        let v152_7: Space = if (&(v152_4)).is_empty() { Space::new() } else {
          let v153_5: Path = concat_path(&(v151_5),&v149_4_cursor.path()[(v149_4_origin + 1)..(v149_4_origin + 2)]);
          let v153_6: Space = singleton(&(v153_5));
          drop(v153_5);
          compose(&(v152_4),&(v153_6))
        };
        drop(v152_4);
        join_wrapped_into(&mut v151_6_write,&((v152_7).read_zipper()),&[]);
        }
        v149_4_cursor.ascend(1);
      }
      drop(v151_6_write);
      drop(v151_5);
      compose(&(v150_4),&(v151_6))
    };
    drop(v150_4);
    join_wrapped_into(&mut v149_4_write,&((v150_7).read_zipper()),&[]);
    }
    v149_4_cursor.ascend(1);
  }
  drop(v149_4_cursor);
  drop(v149_4_write);
  (v149_4).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v154_3 = Space::new();
  let mut v154_3_write = v154_3.write_zipper();
  let mut v154_3_cursor = (*s0).read_zipper();
  let v154_3_origin = v154_3_cursor.path().len();
  for v154_3_byte in v154_3_cursor.child_mask().iter() {
    v154_3_cursor.descend_to_existing_byte(v154_3_byte);
    {
    let v155_2: Space = singleton(&v154_3_cursor.path()[v154_3_origin..(v154_3_origin + 1)]);
    let v155_3: Space = intersect(&(*CONSTANT_12),&(v155_2));
    drop(v155_2);
    let v155_4: Space = if has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
    drop(v155_3);
    let v155_7: Space = if (&(v155_4)).is_empty() { Space::new() } else {
      let v156_5: Path = concat_path(&(*p0),&v154_3_cursor.path()[v154_3_origin..(v154_3_origin + 1)]);
      let v156_6: Space = singleton(&(v156_5));
      drop(v156_5);
      compose(&(v155_4),&(v156_6))
    };
    drop(v155_4);
    join_wrapped_into(&mut v154_3_write,&((v155_7).read_zipper()),&[]);
    }
    v154_3_cursor.ascend(1);
  }
  drop(v154_3_cursor);
  drop(v154_3_write);
  (v154_3).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v157_2: Space = singleton(&(*p0));
  (v157_2).clone()
}

fn routine_11(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v158_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v158_2: Space = first_matching(&(*s0),&(*CONSTANT_0),false);
  let v158_3: Space = unite(&(v158_1),&(v158_2));
  drop(v158_1);
  drop(v158_2);
  let v158_6: Space = if (&(v158_3)).is_empty() { Space::new() } else {
    let v159_4: Space = routine_26(c, &(*s0));
    let v159_5: Space = subtract(&(*s0),&(v159_4));
    compose(&(v158_3),&(v159_5))
  };
  drop(v158_3);
  let v158_7: Space = subtract(&(*s0),&(v158_6));
  (v158_7).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v160_21 = Space::new();
  let mut v160_21_write = v160_21.write_zipper();
  let mut v160_21_cursor = (*s0).read_zipper();
  let v160_21_origin = v160_21_cursor.path().len();
  for v160_21_byte in v160_21_cursor.child_mask().iter() {
    v160_21_cursor.descend_to_existing_byte(v160_21_byte);
    {
    let v161_2: Space = singleton(&v160_21_cursor.path()[v160_21_origin..(v160_21_origin + 1)]);
    let v161_3: Space = intersect(&(*CONSTANT_12),&(v161_2));
    let v161_4: Space = if has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
    drop(v161_3);
    let v161_5: Space = subtract(&(*CONSTANT_0),&(v161_4));
    drop(v161_4);
    let v161_8: Space = if (&(v161_5)).is_empty() { Space::new() } else {
      let v162_6: Path = concat_path(&(*p0),&v160_21_cursor.path()[v160_21_origin..(v160_21_origin + 1)]);
      let mut v162_7 = Space::new();
      let mut v162_7_write = v162_7.write_zipper();
      for v162_7_byte in v160_21_cursor.child_mask().iter() {
        v160_21_cursor.descend_to_existing_byte(v162_7_byte);
        {
        let v163_2: Space = singleton(&v160_21_cursor.path()[(v160_21_origin + 1)..(v160_21_origin + 2)]);
        let v163_3: Space = intersect(&(*CONSTANT_12),&(v163_2));
        let v163_4: Space = if has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
        drop(v163_3);
        let v163_5: Space = subtract(&(*CONSTANT_0),&(v163_4));
        drop(v163_4);
        let v163_8: Space = if (&(v163_5)).is_empty() { Space::new() } else {
          let v164_6: Path = concat_path(&(v162_6),&v160_21_cursor.path()[(v160_21_origin + 1)..(v160_21_origin + 2)]);
          let mut v164_7 = Space::new();
          let mut v164_7_write = v164_7.write_zipper();
          for v164_7_byte in v160_21_cursor.child_mask().iter() {
            v160_21_cursor.descend_to_existing_byte(v164_7_byte);
            {
            let v165_2: Space = singleton(&v160_21_cursor.path()[(v160_21_origin + 2)..(v160_21_origin + 3)]);
            let v165_3: Space = intersect(&(*CONSTANT_12),&(v165_2));
            let v165_4: Space = if has_head(&(v165_3)) { singleton(&[]) } else { Space::new() };
            drop(v165_3);
            let v165_5: Space = subtract(&(*CONSTANT_0),&(v165_4));
            drop(v165_4);
            let v165_8: Space = if (&(v165_5)).is_empty() { Space::new() } else {
              let v166_6: Path = concat_path(&(v164_6),&v160_21_cursor.path()[(v160_21_origin + 2)..(v160_21_origin + 3)]);
              let v166_7: Space = routine_27(c, &(v166_6), &(*p1), &v160_21_cursor);
              compose(&(v165_5),&(v166_7))
            };
            drop(v165_5);
            let v165_9: Space = intersect(&(*CONSTANT_12),&(v165_2));
            drop(v165_2);
            let v165_10: Space = if has_head(&(v165_9)) { singleton(&[]) } else { Space::new() };
            drop(v165_9);
            let v165_12: Space = if (&(v165_10)).is_empty() { Space::new() } else {
              let v167_6: Path = concat_path(&(v164_6),&v160_21_cursor.path()[(v160_21_origin + 2)..(v160_21_origin + 3)]);
              let v167_11: Space = routine_28(c, &(v167_6), &(*p1), &v160_21_cursor);
              drop(v167_6);
              compose(&(v165_10),&(v167_11))
            };
            drop(v165_10);
            let v165_13: Space = unite(&(v165_8),&(v165_12));
            join_wrapped_into(&mut v164_7_write,&((v165_13).read_zipper()),&[]);
            }
            v160_21_cursor.ascend(1);
          }
          drop(v164_7_write);
          compose(&(v163_5),&(v164_7))
        };
        drop(v163_5);
        let v163_9: Space = intersect(&(*CONSTANT_12),&(v163_2));
        drop(v163_2);
        let v163_10: Space = if has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
        drop(v163_9);
        let v163_12: Space = if (&(v163_10)).is_empty() { Space::new() } else {
          let v168_6: Path = concat_path(&(v162_6),&v160_21_cursor.path()[(v160_21_origin + 1)..(v160_21_origin + 2)]);
          let mut v168_11 = Space::new();
          let mut v168_11_write = v168_11.write_zipper();
          for v168_11_byte in v160_21_cursor.child_mask().iter() {
            v160_21_cursor.descend_to_existing_byte(v168_11_byte);
            {
            let v169_2: Space = singleton(&v160_21_cursor.path()[(v160_21_origin + 2)..(v160_21_origin + 3)]);
            let v169_3: Space = intersect(&(*CONSTANT_12),&(v169_2));
            let v169_4: Space = if has_head(&(v169_3)) { singleton(&[]) } else { Space::new() };
            drop(v169_3);
            let v169_5: Space = subtract(&(*CONSTANT_0),&(v169_4));
            drop(v169_4);
            let v169_8: Space = if (&(v169_5)).is_empty() { Space::new() } else {
              let v170_6: Path = concat_path(&(v168_6),&v160_21_cursor.path()[(v160_21_origin + 2)..(v160_21_origin + 3)]);
              let v170_7: Space = routine_27(c, &(v170_6), &(*p1), &v160_21_cursor);
              compose(&(v169_5),&(v170_7))
            };
            drop(v169_5);
            let v169_9: Space = intersect(&(*CONSTANT_12),&(v169_2));
            drop(v169_2);
            let v169_10: Space = if has_head(&(v169_9)) { singleton(&[]) } else { Space::new() };
            drop(v169_9);
            let v169_12: Space = if (&(v169_10)).is_empty() { Space::new() } else {
              let v171_6: Path = concat_path(&(v168_6),&v160_21_cursor.path()[(v160_21_origin + 2)..(v160_21_origin + 3)]);
              let v171_11: Space = routine_29(c, &(v171_6), &(*p1), &v160_21_cursor);
              drop(v171_6);
              compose(&(v169_10),&(v171_11))
            };
            drop(v169_10);
            let v169_13: Space = unite(&(v169_8),&(v169_12));
            join_wrapped_into(&mut v168_11_write,&((v169_13).read_zipper()),&[]);
            }
            v160_21_cursor.ascend(1);
          }
          drop(v168_11_write);
          drop(v168_6);
          compose(&(v163_10),&(v168_11))
        };
        drop(v163_10);
        let v163_13: Space = unite(&(v163_8),&(v163_12));
        join_wrapped_into(&mut v162_7_write,&((v163_13).read_zipper()),&[]);
        }
        v160_21_cursor.ascend(1);
      }
      drop(v162_7_write);
      compose(&(v161_5),&(v162_7))
    };
    drop(v161_5);
    let v161_9: Space = intersect(&(*CONSTANT_12),&(v161_2));
    drop(v161_2);
    let v161_10: Space = if has_head(&(v161_9)) { singleton(&[]) } else { Space::new() };
    drop(v161_9);
    let v161_12: Space = if (&(v161_10)).is_empty() { Space::new() } else {
      let v172_6: Path = concat_path(&(*p0),&v160_21_cursor.path()[v160_21_origin..(v160_21_origin + 1)]);
      let mut v172_11 = Space::new();
      let mut v172_11_write = v172_11.write_zipper();
      for v172_11_byte in v160_21_cursor.child_mask().iter() {
        v160_21_cursor.descend_to_existing_byte(v172_11_byte);
        {
        let v173_2: Space = singleton(&v160_21_cursor.path()[(v160_21_origin + 1)..(v160_21_origin + 2)]);
        let v173_3: Space = intersect(&(*CONSTANT_12),&(v173_2));
        let v173_4: Space = if has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
        drop(v173_3);
        let v173_5: Space = subtract(&(*CONSTANT_0),&(v173_4));
        drop(v173_4);
        let v173_8: Space = if (&(v173_5)).is_empty() { Space::new() } else {
          let v174_6: Path = concat_path(&(v172_6),&v160_21_cursor.path()[(v160_21_origin + 1)..(v160_21_origin + 2)]);
          let mut v174_7 = Space::new();
          let mut v174_7_write = v174_7.write_zipper();
          for v174_7_byte in v160_21_cursor.child_mask().iter() {
            v160_21_cursor.descend_to_existing_byte(v174_7_byte);
            {
            let v175_2: Space = singleton(&v160_21_cursor.path()[(v160_21_origin + 2)..(v160_21_origin + 3)]);
            let v175_3: Space = intersect(&(*CONSTANT_12),&(v175_2));
            let v175_4: Space = if has_head(&(v175_3)) { singleton(&[]) } else { Space::new() };
            drop(v175_3);
            let v175_5: Space = subtract(&(*CONSTANT_0),&(v175_4));
            drop(v175_4);
            let v175_8: Space = if (&(v175_5)).is_empty() { Space::new() } else {
              let v176_6: Path = concat_path(&(v174_6),&v160_21_cursor.path()[(v160_21_origin + 2)..(v160_21_origin + 3)]);
              let v176_7: Space = routine_27(c, &(v176_6), &(*p1), &v160_21_cursor);
              compose(&(v175_5),&(v176_7))
            };
            drop(v175_5);
            let v175_9: Space = intersect(&(*CONSTANT_12),&(v175_2));
            drop(v175_2);
            let v175_10: Space = if has_head(&(v175_9)) { singleton(&[]) } else { Space::new() };
            drop(v175_9);
            let v175_12: Space = if (&(v175_10)).is_empty() { Space::new() } else {
              let v177_6: Path = concat_path(&(v174_6),&v160_21_cursor.path()[(v160_21_origin + 2)..(v160_21_origin + 3)]);
              let v177_11: Space = routine_28(c, &(v177_6), &(*p1), &v160_21_cursor);
              drop(v177_6);
              compose(&(v175_10),&(v177_11))
            };
            drop(v175_10);
            let v175_13: Space = unite(&(v175_8),&(v175_12));
            join_wrapped_into(&mut v174_7_write,&((v175_13).read_zipper()),&[]);
            }
            v160_21_cursor.ascend(1);
          }
          drop(v174_7_write);
          compose(&(v173_5),&(v174_7))
        };
        drop(v173_5);
        let v173_9: Space = intersect(&(*CONSTANT_12),&(v173_2));
        drop(v173_2);
        let v173_10: Space = if has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
        drop(v173_9);
        let v173_13: Space = if (&(v173_10)).is_empty() { Space::new() } else {
          let v178_6: Path = concat_path(&(v172_6),&v160_21_cursor.path()[(v160_21_origin + 1)..(v160_21_origin + 2)]);
          let v178_11: Path = concat_path(&(v178_6),&(*p1));
          drop(v178_6);
          let v178_12: Space = singleton(&(v178_11));
          drop(v178_11);
          compose(&(v173_10),&(v178_12))
        };
        drop(v173_10);
        let v173_14: Space = unite(&(v173_8),&(v173_13));
        drop(v173_13);
        join_wrapped_into(&mut v172_11_write,&((v173_14).read_zipper()),&[]);
        }
        v160_21_cursor.ascend(1);
      }
      drop(v172_11_write);
      drop(v172_6);
      compose(&(v161_10),&(v172_11))
    };
    drop(v161_10);
    let v161_13: Space = unite(&(v161_8),&(v161_12));
    join_wrapped_into(&mut v160_21_write,&((v161_13).read_zipper()),&[]);
    }
    v160_21_cursor.ascend(1);
  }
  drop(v160_21_cursor);
  drop(v160_21_write);
  (v160_21).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v179_7 = Space::new();
  let mut v179_7_write = v179_7.write_zipper();
  let mut v179_7_cursor = (*s0).read_zipper();
  let v179_7_origin = v179_7_cursor.path().len();
  for v179_7_byte in v179_7_cursor.child_mask().iter() {
    v179_7_cursor.descend_to_existing_byte(v179_7_byte);
    {
    let v180_2: Space = singleton(&v179_7_cursor.path()[v179_7_origin..(v179_7_origin + 1)]);
    let v180_3: Space = intersect(&(*CONSTANT_12),&(v180_2));
    drop(v180_2);
    let v180_4: Space = if has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
    drop(v180_3);
    let v180_7: Space = if (&(v180_4)).is_empty() { Space::new() } else {
      let v181_5: Path = concat_path(&(*p0),&v179_7_cursor.path()[v179_7_origin..(v179_7_origin + 1)]);
      let mut v181_6 = Space::new();
      let mut v181_6_write = v181_6.write_zipper();
      for v181_6_byte in v179_7_cursor.child_mask().iter() {
        v179_7_cursor.descend_to_existing_byte(v181_6_byte);
        {
        let v182_2: Space = singleton(&v179_7_cursor.path()[(v179_7_origin + 1)..(v179_7_origin + 2)]);
        let v182_3: Space = intersect(&(*CONSTANT_12),&(v182_2));
        drop(v182_2);
        let v182_4: Space = if has_head(&(v182_3)) { singleton(&[]) } else { Space::new() };
        drop(v182_3);
        let v182_7: Space = if (&(v182_4)).is_empty() { Space::new() } else {
          let v183_5: Path = concat_path(&(v181_5),&v179_7_cursor.path()[(v179_7_origin + 1)..(v179_7_origin + 2)]);
          let mut v183_6 = Space::new();
          let mut v183_6_write = v183_6.write_zipper();
          for v183_6_byte in v179_7_cursor.child_mask().iter() {
            v179_7_cursor.descend_to_existing_byte(v183_6_byte);
            {
            let v184_2: Space = singleton(&v179_7_cursor.path()[(v179_7_origin + 2)..(v179_7_origin + 3)]);
            let v184_3: Space = intersect(&(*CONSTANT_12),&(v184_2));
            let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
            drop(v184_3);
            let v184_5: Space = subtract(&(*CONSTANT_0),&(v184_4));
            drop(v184_4);
            let v184_7: Space = if (&(v184_5)).is_empty() { Space::new() } else {
              let v185_6: Space = routine_12(c, &v179_7_cursor.path()[(v179_7_origin + 2)..(v179_7_origin + 3)], &(v183_5), &v179_7_cursor);
              compose(&(v184_5),&(v185_6))
            };
            drop(v184_5);
            let v184_8: Space = intersect(&(*CONSTANT_12),&(v184_2));
            drop(v184_2);
            let v184_9: Space = if has_head(&(v184_8)) { singleton(&[]) } else { Space::new() };
            drop(v184_8);
            let v184_11: Space = if (&(v184_9)).is_empty() { Space::new() } else {
              let v186_10: Space = routine_30(c, &v179_7_cursor.path()[(v179_7_origin + 2)..(v179_7_origin + 3)], &(v183_5), &v179_7_cursor);
              compose(&(v184_9),&(v186_10))
            };
            drop(v184_9);
            let v184_12: Space = unite(&(v184_7),&(v184_11));
            join_wrapped_into(&mut v183_6_write,&((v184_12).read_zipper()),&[]);
            }
            v179_7_cursor.ascend(1);
          }
          drop(v183_6_write);
          drop(v183_5);
          compose(&(v182_4),&(v183_6))
        };
        drop(v182_4);
        join_wrapped_into(&mut v181_6_write,&((v182_7).read_zipper()),&[]);
        }
        v179_7_cursor.ascend(1);
      }
      drop(v181_6_write);
      drop(v181_5);
      compose(&(v180_4),&(v181_6))
    };
    drop(v180_4);
    join_wrapped_into(&mut v179_7_write,&((v180_7).read_zipper()),&[]);
    }
    v179_7_cursor.ascend(1);
  }
  drop(v179_7_cursor);
  drop(v179_7_write);
  (v179_7).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v187_12 = Space::new();
  let mut v187_12_write = v187_12.write_zipper();
  let mut v187_12_cursor = (*s0).read_zipper();
  let v187_12_origin = v187_12_cursor.path().len();
  for v187_12_byte in v187_12_cursor.child_mask().iter() {
    v187_12_cursor.descend_to_existing_byte(v187_12_byte);
    {
    let v188_2: Space = singleton(&v187_12_cursor.path()[v187_12_origin..(v187_12_origin + 1)]);
    let v188_3: Space = intersect(&(*CONSTANT_12),&(v188_2));
    drop(v188_2);
    let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
    drop(v188_3);
    let v188_7: Space = if (&(v188_4)).is_empty() { Space::new() } else {
      let v189_5: Path = concat_path(&(*p0),&v187_12_cursor.path()[v187_12_origin..(v187_12_origin + 1)]);
      let mut v189_6 = Space::new();
      let mut v189_6_write = v189_6.write_zipper();
      for v189_6_byte in v187_12_cursor.child_mask().iter() {
        v187_12_cursor.descend_to_existing_byte(v189_6_byte);
        {
        let v190_2: Space = singleton(&v187_12_cursor.path()[(v187_12_origin + 1)..(v187_12_origin + 2)]);
        let v190_3: Space = intersect(&(*CONSTANT_12),&(v190_2));
        let v190_4: Space = if has_head(&(v190_3)) { singleton(&[]) } else { Space::new() };
        drop(v190_3);
        let v190_5: Space = subtract(&(*CONSTANT_0),&(v190_4));
        drop(v190_4);
        let v190_7: Space = if (&(v190_5)).is_empty() { Space::new() } else {
          let mut v191_6 = Space::new();
          let mut v191_6_write = v191_6.write_zipper();
          for v191_6_byte in v187_12_cursor.child_mask().iter() {
            v187_12_cursor.descend_to_existing_byte(v191_6_byte);
            {
            let v192_2: Space = singleton(&v187_12_cursor.path()[(v187_12_origin + 2)..(v187_12_origin + 3)]);
            let v192_3: Space = intersect(&(*CONSTANT_12),&(v192_2));
            let v192_4: Space = if has_head(&(v192_3)) { singleton(&[]) } else { Space::new() };
            drop(v192_3);
            let v192_5: Space = subtract(&(*CONSTANT_0),&(v192_4));
            drop(v192_4);
            let v192_8: Space = if (&(v192_5)).is_empty() { Space::new() } else {
              let v193_7: Space = routine_31(c, &v187_12_cursor.path()[(v187_12_origin + 1)..(v187_12_origin + 3)], &(v189_5), &v187_12_cursor);
              compose(&(v192_5),&(v193_7))
            };
            drop(v192_5);
            let v192_9: Space = intersect(&(*CONSTANT_12),&(v192_2));
            drop(v192_2);
            let v192_10: Space = if has_head(&(v192_9)) { singleton(&[]) } else { Space::new() };
            drop(v192_9);
            let v192_12: Space = if (&(v192_10)).is_empty() { Space::new() } else {
              let v194_11: Space = routine_32(c, &v187_12_cursor.path()[(v187_12_origin + 1)..(v187_12_origin + 3)], &(v189_5), &v187_12_cursor);
              compose(&(v192_10),&(v194_11))
            };
            drop(v192_10);
            let v192_13: Space = unite(&(v192_8),&(v192_12));
            join_wrapped_into(&mut v191_6_write,&((v192_13).read_zipper()),&[]);
            }
            v187_12_cursor.ascend(1);
          }
          drop(v191_6_write);
          compose(&(v190_5),&(v191_6))
        };
        drop(v190_5);
        let v190_8: Space = intersect(&(*CONSTANT_12),&(v190_2));
        drop(v190_2);
        let v190_9: Space = if has_head(&(v190_8)) { singleton(&[]) } else { Space::new() };
        drop(v190_8);
        let v190_11: Space = if (&(v190_9)).is_empty() { Space::new() } else {
          let mut v195_10 = Space::new();
          let mut v195_10_write = v195_10.write_zipper();
          for v195_10_byte in v187_12_cursor.child_mask().iter() {
            v187_12_cursor.descend_to_existing_byte(v195_10_byte);
            {
            let v196_2: Space = singleton(&v187_12_cursor.path()[(v187_12_origin + 2)..(v187_12_origin + 3)]);
            let v196_3: Space = intersect(&(*CONSTANT_12),&(v196_2));
            let v196_4: Space = if has_head(&(v196_3)) { singleton(&[]) } else { Space::new() };
            drop(v196_3);
            let v196_5: Space = subtract(&(*CONSTANT_0),&(v196_4));
            drop(v196_4);
            let v196_8: Space = if (&(v196_5)).is_empty() { Space::new() } else {
              let v197_7: Space = routine_31(c, &v187_12_cursor.path()[(v187_12_origin + 1)..(v187_12_origin + 3)], &(v189_5), &v187_12_cursor);
              compose(&(v196_5),&(v197_7))
            };
            drop(v196_5);
            let v196_9: Space = intersect(&(*CONSTANT_12),&(v196_2));
            drop(v196_2);
            let v196_10: Space = if has_head(&(v196_9)) { singleton(&[]) } else { Space::new() };
            drop(v196_9);
            let v196_12: Space = if (&(v196_10)).is_empty() { Space::new() } else {
              let v198_11: Space = routine_29(c, &v187_12_cursor.path()[(v187_12_origin + 1)..(v187_12_origin + 3)], &(v189_5), &v187_12_cursor);
              compose(&(v196_10),&(v198_11))
            };
            drop(v196_10);
            let v196_13: Space = unite(&(v196_8),&(v196_12));
            join_wrapped_into(&mut v195_10_write,&((v196_13).read_zipper()),&[]);
            }
            v187_12_cursor.ascend(1);
          }
          drop(v195_10_write);
          compose(&(v190_9),&(v195_10))
        };
        drop(v190_9);
        let v190_12: Space = unite(&(v190_7),&(v190_11));
        join_wrapped_into(&mut v189_6_write,&((v190_12).read_zipper()),&[]);
        }
        v187_12_cursor.ascend(1);
      }
      drop(v189_6_write);
      drop(v189_5);
      compose(&(v188_4),&(v189_6))
    };
    drop(v188_4);
    join_wrapped_into(&mut v187_12_write,&((v188_7).read_zipper()),&[]);
    }
    v187_12_cursor.ascend(1);
  }
  drop(v187_12_cursor);
  drop(v187_12_write);
  (v187_12).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v199_20 = Space::new();
  let mut v199_20_write = v199_20.write_zipper();
  let mut v199_20_cursor = (*s0).read_zipper();
  let v199_20_origin = v199_20_cursor.path().len();
  for v199_20_byte in v199_20_cursor.child_mask().iter() {
    v199_20_cursor.descend_to_existing_byte(v199_20_byte);
    {
    let v200_2: Space = singleton(&v199_20_cursor.path()[v199_20_origin..(v199_20_origin + 1)]);
    let v200_3: Space = intersect(&(*CONSTANT_12),&(v200_2));
    let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
    drop(v200_3);
    let v200_5: Space = subtract(&(*CONSTANT_0),&(v200_4));
    drop(v200_4);
    let v200_7: Space = if (&(v200_5)).is_empty() { Space::new() } else {
      let mut v201_6 = Space::new();
      let mut v201_6_write = v201_6.write_zipper();
      for v201_6_byte in v199_20_cursor.child_mask().iter() {
        v199_20_cursor.descend_to_existing_byte(v201_6_byte);
        {
        let v202_2: Space = singleton(&v199_20_cursor.path()[(v199_20_origin + 1)..(v199_20_origin + 2)]);
        let v202_3: Space = intersect(&(*CONSTANT_12),&(v202_2));
        let v202_4: Space = if has_head(&(v202_3)) { singleton(&[]) } else { Space::new() };
        drop(v202_3);
        let v202_5: Space = subtract(&(*CONSTANT_0),&(v202_4));
        drop(v202_4);
        let v202_8: Space = if (&(v202_5)).is_empty() { Space::new() } else {
          let mut v203_7 = Space::new();
          let mut v203_7_write = v203_7.write_zipper();
          for v203_7_byte in v199_20_cursor.child_mask().iter() {
            v199_20_cursor.descend_to_existing_byte(v203_7_byte);
            {
            let v204_2: Space = singleton(&v199_20_cursor.path()[(v199_20_origin + 2)..(v199_20_origin + 3)]);
            let v204_3: Space = intersect(&(*CONSTANT_12),&(v204_2));
            let v204_4: Space = if has_head(&(v204_3)) { singleton(&[]) } else { Space::new() };
            drop(v204_3);
            let v204_5: Space = subtract(&(*CONSTANT_0),&(v204_4));
            drop(v204_4);
            let v204_8: Space = if (&(v204_5)).is_empty() { Space::new() } else {
              let v205_7: Space = routine_33(c, &v199_20_cursor.path()[v199_20_origin..(v199_20_origin + 3)], &(*p0), &v199_20_cursor);
              compose(&(v204_5),&(v205_7))
            };
            drop(v204_5);
            let v204_9: Space = intersect(&(*CONSTANT_12),&(v204_2));
            drop(v204_2);
            let v204_10: Space = if has_head(&(v204_9)) { singleton(&[]) } else { Space::new() };
            drop(v204_9);
            let v204_12: Space = if (&(v204_10)).is_empty() { Space::new() } else {
              let v206_11: Space = routine_34(c, &v199_20_cursor.path()[v199_20_origin..(v199_20_origin + 3)], &(*p0), &v199_20_cursor);
              compose(&(v204_10),&(v206_11))
            };
            drop(v204_10);
            let v204_13: Space = unite(&(v204_8),&(v204_12));
            join_wrapped_into(&mut v203_7_write,&((v204_13).read_zipper()),&[]);
            }
            v199_20_cursor.ascend(1);
          }
          drop(v203_7_write);
          compose(&(v202_5),&(v203_7))
        };
        drop(v202_5);
        let v202_9: Space = intersect(&(*CONSTANT_12),&(v202_2));
        drop(v202_2);
        let v202_10: Space = if has_head(&(v202_9)) { singleton(&[]) } else { Space::new() };
        drop(v202_9);
        let v202_12: Space = if (&(v202_10)).is_empty() { Space::new() } else {
          let mut v207_11 = Space::new();
          let mut v207_11_write = v207_11.write_zipper();
          for v207_11_byte in v199_20_cursor.child_mask().iter() {
            v199_20_cursor.descend_to_existing_byte(v207_11_byte);
            {
            let v208_2: Space = singleton(&v199_20_cursor.path()[(v199_20_origin + 2)..(v199_20_origin + 3)]);
            let v208_3: Space = intersect(&(*CONSTANT_12),&(v208_2));
            let v208_4: Space = if has_head(&(v208_3)) { singleton(&[]) } else { Space::new() };
            drop(v208_3);
            let v208_5: Space = subtract(&(*CONSTANT_0),&(v208_4));
            drop(v208_4);
            let v208_8: Space = if (&(v208_5)).is_empty() { Space::new() } else {
              let v209_7: Space = routine_33(c, &v199_20_cursor.path()[v199_20_origin..(v199_20_origin + 3)], &(*p0), &v199_20_cursor);
              compose(&(v208_5),&(v209_7))
            };
            drop(v208_5);
            let v208_9: Space = intersect(&(*CONSTANT_12),&(v208_2));
            drop(v208_2);
            let v208_10: Space = if has_head(&(v208_9)) { singleton(&[]) } else { Space::new() };
            drop(v208_9);
            let v208_12: Space = if (&(v208_10)).is_empty() { Space::new() } else {
              let v210_11: Space = routine_29(c, &v199_20_cursor.path()[v199_20_origin..(v199_20_origin + 3)], &(*p0), &v199_20_cursor);
              compose(&(v208_10),&(v210_11))
            };
            drop(v208_10);
            let v208_13: Space = unite(&(v208_8),&(v208_12));
            join_wrapped_into(&mut v207_11_write,&((v208_13).read_zipper()),&[]);
            }
            v199_20_cursor.ascend(1);
          }
          drop(v207_11_write);
          compose(&(v202_10),&(v207_11))
        };
        drop(v202_10);
        let v202_13: Space = unite(&(v202_8),&(v202_12));
        join_wrapped_into(&mut v201_6_write,&((v202_13).read_zipper()),&[]);
        }
        v199_20_cursor.ascend(1);
      }
      drop(v201_6_write);
      compose(&(v200_5),&(v201_6))
    };
    drop(v200_5);
    let v200_8: Space = intersect(&(*CONSTANT_12),&(v200_2));
    drop(v200_2);
    let v200_9: Space = if has_head(&(v200_8)) { singleton(&[]) } else { Space::new() };
    drop(v200_8);
    let v200_11: Space = if (&(v200_9)).is_empty() { Space::new() } else {
      let mut v211_10 = Space::new();
      let mut v211_10_write = v211_10.write_zipper();
      for v211_10_byte in v199_20_cursor.child_mask().iter() {
        v199_20_cursor.descend_to_existing_byte(v211_10_byte);
        {
        let v212_2: Space = singleton(&v199_20_cursor.path()[(v199_20_origin + 1)..(v199_20_origin + 2)]);
        let v212_3: Space = intersect(&(*CONSTANT_12),&(v212_2));
        let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
        drop(v212_3);
        let v212_5: Space = subtract(&(*CONSTANT_0),&(v212_4));
        drop(v212_4);
        let v212_8: Space = if (&(v212_5)).is_empty() { Space::new() } else {
          let mut v213_7 = Space::new();
          let mut v213_7_write = v213_7.write_zipper();
          for v213_7_byte in v199_20_cursor.child_mask().iter() {
            v199_20_cursor.descend_to_existing_byte(v213_7_byte);
            {
            let v214_2: Space = singleton(&v199_20_cursor.path()[(v199_20_origin + 2)..(v199_20_origin + 3)]);
            let v214_3: Space = intersect(&(*CONSTANT_12),&(v214_2));
            let v214_4: Space = if has_head(&(v214_3)) { singleton(&[]) } else { Space::new() };
            drop(v214_3);
            let v214_5: Space = subtract(&(*CONSTANT_0),&(v214_4));
            drop(v214_4);
            let v214_8: Space = if (&(v214_5)).is_empty() { Space::new() } else {
              let v215_7: Space = routine_33(c, &v199_20_cursor.path()[v199_20_origin..(v199_20_origin + 3)], &(*p0), &v199_20_cursor);
              compose(&(v214_5),&(v215_7))
            };
            drop(v214_5);
            let v214_9: Space = intersect(&(*CONSTANT_12),&(v214_2));
            drop(v214_2);
            let v214_10: Space = if has_head(&(v214_9)) { singleton(&[]) } else { Space::new() };
            drop(v214_9);
            let v214_12: Space = if (&(v214_10)).is_empty() { Space::new() } else {
              let v216_11: Space = routine_34(c, &v199_20_cursor.path()[v199_20_origin..(v199_20_origin + 3)], &(*p0), &v199_20_cursor);
              compose(&(v214_10),&(v216_11))
            };
            drop(v214_10);
            let v214_13: Space = unite(&(v214_8),&(v214_12));
            join_wrapped_into(&mut v213_7_write,&((v214_13).read_zipper()),&[]);
            }
            v199_20_cursor.ascend(1);
          }
          drop(v213_7_write);
          compose(&(v212_5),&(v213_7))
        };
        drop(v212_5);
        let v212_9: Space = intersect(&(*CONSTANT_12),&(v212_2));
        drop(v212_2);
        let v212_10: Space = if has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
        drop(v212_9);
        let v212_13: Space = if (&(v212_10)).is_empty() { Space::new() } else {
          let v217_11: Path = concat_path(&v199_20_cursor.path()[v199_20_origin..(v199_20_origin + 2)],&(*p0));
          let v217_12: Space = singleton(&(v217_11));
          drop(v217_11);
          compose(&(v212_10),&(v217_12))
        };
        drop(v212_10);
        let v212_14: Space = unite(&(v212_8),&(v212_13));
        drop(v212_13);
        join_wrapped_into(&mut v211_10_write,&((v212_14).read_zipper()),&[]);
        }
        v199_20_cursor.ascend(1);
      }
      drop(v211_10_write);
      compose(&(v200_9),&(v211_10))
    };
    drop(v200_9);
    let v200_12: Space = unite(&(v200_7),&(v200_11));
    join_wrapped_into(&mut v199_20_write,&((v200_12).read_zipper()),&[]);
    }
    v199_20_cursor.ascend(1);
  }
  drop(v199_20_cursor);
  drop(v199_20_write);
  (v199_20).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let mut v218_14 = Space::new();
  let mut v218_14_write = v218_14.write_zipper();
  let mut v218_14_cursor = (*s0).read_zipper();
  let v218_14_origin = v218_14_cursor.path().len();
  for v218_14_byte in v218_14_cursor.child_mask().iter() {
    v218_14_cursor.descend_to_existing_byte(v218_14_byte);
    {
    let v219_2: Space = singleton(&v218_14_cursor.path()[v218_14_origin..(v218_14_origin + 1)]);
    let v219_3: Space = intersect(&(*CONSTANT_12),&(v219_2));
    let v219_4: Space = if has_head(&(v219_3)) { singleton(&[]) } else { Space::new() };
    drop(v219_3);
    let v219_5: Space = subtract(&(*CONSTANT_0),&(v219_4));
    drop(v219_4);
    let v219_8: Space = if (&(v219_5)).is_empty() { Space::new() } else {
      let v220_6: Path = concat_path(&(*p0),&v218_14_cursor.path()[v218_14_origin..(v218_14_origin + 1)]);
      let mut v220_7 = Space::new();
      let mut v220_7_write = v220_7.write_zipper();
      for v220_7_byte in v218_14_cursor.child_mask().iter() {
        v218_14_cursor.descend_to_existing_byte(v220_7_byte);
        {
        let v221_2: Space = singleton(&v218_14_cursor.path()[(v218_14_origin + 1)..(v218_14_origin + 2)]);
        let v221_3: Space = intersect(&(*CONSTANT_12),&(v221_2));
        let v221_4: Space = if has_head(&(v221_3)) { singleton(&[]) } else { Space::new() };
        drop(v221_3);
        let v221_5: Space = subtract(&(*CONSTANT_0),&(v221_4));
        drop(v221_4);
        let v221_8: Space = if (&(v221_5)).is_empty() { Space::new() } else {
          let v222_6: Path = concat_path(&(v220_6),&v218_14_cursor.path()[(v218_14_origin + 1)..(v218_14_origin + 2)]);
          let v222_7: Space = routine_35(c, &(v222_6), &v218_14_cursor, &(*s1), &(*s2), &(*s3));
          compose(&(v221_5),&(v222_7))
        };
        drop(v221_5);
        let v221_9: Space = intersect(&(*CONSTANT_12),&(v221_2));
        drop(v221_2);
        let v221_10: Space = if has_head(&(v221_9)) { singleton(&[]) } else { Space::new() };
        drop(v221_9);
        let v221_12: Space = if (&(v221_10)).is_empty() { Space::new() } else {
          let v223_6: Path = concat_path(&(v220_6),&v218_14_cursor.path()[(v218_14_origin + 1)..(v218_14_origin + 2)]);
          let v223_11: Space = routine_36(c, &(v223_6), &v218_14_cursor, &(*s1), &(*s2), &(*s3));
          drop(v223_6);
          compose(&(v221_10),&(v223_11))
        };
        drop(v221_10);
        let v221_13: Space = unite(&(v221_8),&(v221_12));
        join_wrapped_into(&mut v220_7_write,&((v221_13).read_zipper()),&[]);
        }
        v218_14_cursor.ascend(1);
      }
      drop(v220_7_write);
      compose(&(v219_5),&(v220_7))
    };
    drop(v219_5);
    let v219_9: Space = intersect(&(*CONSTANT_12),&(v219_2));
    drop(v219_2);
    let v219_10: Space = if has_head(&(v219_9)) { singleton(&[]) } else { Space::new() };
    drop(v219_9);
    let v219_12: Space = if (&(v219_10)).is_empty() { Space::new() } else {
      let v224_6: Path = concat_path(&(*p0),&v218_14_cursor.path()[v218_14_origin..(v218_14_origin + 1)]);
      let mut v224_11 = Space::new();
      let mut v224_11_write = v224_11.write_zipper();
      for v224_11_byte in v218_14_cursor.child_mask().iter() {
        v218_14_cursor.descend_to_existing_byte(v224_11_byte);
        {
        let v225_2: Space = singleton(&v218_14_cursor.path()[(v218_14_origin + 1)..(v218_14_origin + 2)]);
        let v225_3: Space = intersect(&(*CONSTANT_12),&(v225_2));
        let v225_4: Space = if has_head(&(v225_3)) { singleton(&[]) } else { Space::new() };
        drop(v225_3);
        let v225_5: Space = subtract(&(*CONSTANT_0),&(v225_4));
        drop(v225_4);
        let v225_8: Space = if (&(v225_5)).is_empty() { Space::new() } else {
          let v226_6: Path = concat_path(&(v224_6),&v218_14_cursor.path()[(v218_14_origin + 1)..(v218_14_origin + 2)]);
          let v226_7: Space = routine_35(c, &(v226_6), &v218_14_cursor, &(*s1), &(*s2), &(*s3));
          compose(&(v225_5),&(v226_7))
        };
        drop(v225_5);
        let v225_9: Space = intersect(&(*CONSTANT_12),&(v225_2));
        drop(v225_2);
        let v225_10: Space = if has_head(&(v225_9)) { singleton(&[]) } else { Space::new() };
        drop(v225_9);
        let v225_12: Space = if (&(v225_10)).is_empty() { Space::new() } else {
          let v227_6: Path = concat_path(&(v224_6),&v218_14_cursor.path()[(v218_14_origin + 1)..(v218_14_origin + 2)]);
          let v227_11: Space = routine_37(c, &(v227_6), &v218_14_cursor, &(*s1), &(*s2), &(*s3));
          drop(v227_6);
          compose(&(v225_10),&(v227_11))
        };
        drop(v225_10);
        let v225_13: Space = unite(&(v225_8),&(v225_12));
        join_wrapped_into(&mut v224_11_write,&((v225_13).read_zipper()),&[]);
        }
        v218_14_cursor.ascend(1);
      }
      drop(v224_11_write);
      drop(v224_6);
      compose(&(v219_10),&(v224_11))
    };
    drop(v219_10);
    let v219_13: Space = unite(&(v219_8),&(v219_12));
    join_wrapped_into(&mut v218_14_write,&((v219_13).read_zipper()),&[]);
    }
    v218_14_cursor.ascend(1);
  }
  drop(v218_14_cursor);
  drop(v218_14_write);
  (v218_14).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let mut v228_11 = Space::new();
  let mut v228_11_write = v228_11.write_zipper();
  let mut v228_11_cursor = (*s0).read_zipper();
  let v228_11_origin = v228_11_cursor.path().len();
  for v228_11_byte in v228_11_cursor.child_mask().iter() {
    v228_11_cursor.descend_to_existing_byte(v228_11_byte);
    {
    let v229_2: Space = singleton(&v228_11_cursor.path()[v228_11_origin..(v228_11_origin + 1)]);
    let v229_3: Space = intersect(&(*CONSTANT_12),&(v229_2));
    let v229_4: Space = if has_head(&(v229_3)) { singleton(&[]) } else { Space::new() };
    drop(v229_3);
    let v229_5: Space = subtract(&(*CONSTANT_0),&(v229_4));
    drop(v229_4);
    let v229_8: Space = if (&(v229_5)).is_empty() { Space::new() } else {
      let v230_6: Path = concat_path(&(*p0),&v228_11_cursor.path()[v228_11_origin..(v228_11_origin + 1)]);
      let mut v230_7 = Space::new();
      let mut v230_7_write = v230_7.write_zipper();
      for v230_7_byte in v228_11_cursor.child_mask().iter() {
        v228_11_cursor.descend_to_existing_byte(v230_7_byte);
        {
        let v231_2: Space = singleton(&v228_11_cursor.path()[(v228_11_origin + 1)..(v228_11_origin + 2)]);
        let v231_3: Space = intersect(&(*CONSTANT_12),&(v231_2));
        let v231_4: Space = if has_head(&(v231_3)) { singleton(&[]) } else { Space::new() };
        drop(v231_3);
        let v231_5: Space = subtract(&(*CONSTANT_0),&(v231_4));
        drop(v231_4);
        let v231_8: Space = if (&(v231_5)).is_empty() { Space::new() } else {
          let v232_6: Path = concat_path(&(v230_6),&v228_11_cursor.path()[(v228_11_origin + 1)..(v228_11_origin + 2)]);
          let v232_7: Space = routine_35(c, &(v232_6), &v228_11_cursor, &(*s1), &(*s2), &(*s3));
          compose(&(v231_5),&(v232_7))
        };
        drop(v231_5);
        let v231_9: Space = intersect(&(*CONSTANT_12),&(v231_2));
        drop(v231_2);
        let v231_10: Space = if has_head(&(v231_9)) { singleton(&[]) } else { Space::new() };
        drop(v231_9);
        let v231_12: Space = if (&(v231_10)).is_empty() { Space::new() } else {
          let v233_6: Path = concat_path(&(v230_6),&v228_11_cursor.path()[(v228_11_origin + 1)..(v228_11_origin + 2)]);
          let v233_11: Space = routine_36(c, &(v233_6), &v228_11_cursor, &(*s1), &(*s2), &(*s3));
          drop(v233_6);
          compose(&(v231_10),&(v233_11))
        };
        drop(v231_10);
        let v231_13: Space = unite(&(v231_8),&(v231_12));
        join_wrapped_into(&mut v230_7_write,&((v231_13).read_zipper()),&[]);
        }
        v228_11_cursor.ascend(1);
      }
      drop(v230_7_write);
      compose(&(v229_5),&(v230_7))
    };
    drop(v229_5);
    let v229_9: Space = intersect(&(*CONSTANT_12),&(v229_2));
    drop(v229_2);
    let v229_10: Space = if has_head(&(v229_9)) { singleton(&[]) } else { Space::new() };
    drop(v229_9);
    let v229_27: Space = if (&(v229_10)).is_empty() { Space::new() } else {
      let v234_6: Path = concat_path(&(*p0),&v228_11_cursor.path()[v228_11_origin..(v228_11_origin + 1)]);
      let v234_11: Space = singleton(&(v234_6));
      let v234_12: Space = routine_38(c, &(*s1), &(*s3), &((v234_11).read_zipper()));
      let v234_13: Space = routine_38(c, &(*s2), &(*s3), &((v234_11).read_zipper()));
      let v234_14: Space = intersect(&(v234_12),&(v234_13));
      let v234_15: Space = subtract(&(v234_14),&(v234_11));
      drop(v234_11);
      let v234_16: Space = wrap(&(v234_15),&(v234_6));
      drop(v234_6);
      let v234_17: Space = subtract(&(*s3),&(v234_13));
      let v234_18: Space = subtract(&(v234_17),&(v234_12));
      let v234_19: Space = routine_39(c, &(*s2), &(*s1), &((v234_18).read_zipper()));
      let v234_20: Space = unite(&(v234_16),&(v234_19));
      let v234_21: Space = subtract(&(v234_12),&(v234_13));
      let v234_22: Space = routine_39(c, &(*s2), &(*s1), &((v234_21).read_zipper()));
      let v234_23: Space = unite(&(v234_20),&(v234_22));
      let v234_24: Space = subtract(&(v234_13),&(v234_12));
      let v234_25: Space = routine_39(c, &(*s2), &(*s1), &((v234_24).read_zipper()));
      let v234_26: Space = unite(&(v234_23),&(v234_25));
      compose(&(v229_10),&(v234_26))
    };
    drop(v229_10);
    let v229_28: Space = unite(&(v229_8),&(v229_27));
    join_wrapped_into(&mut v228_11_write,&((v229_28).read_zipper()),&[]);
    }
    v228_11_cursor.ascend(1);
  }
  drop(v228_11_cursor);
  drop(v228_11_write);
  (v228_11).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v235_3: Space = Space::new();
  (v235_3).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v236_4 = Space::new();
  let mut v236_4_write = v236_4.write_zipper();
  let mut v236_4_cursor = (*s0).read_zipper();
  let v236_4_origin = v236_4_cursor.path().len();
  for v236_4_byte in v236_4_cursor.child_mask().iter() {
    v236_4_cursor.descend_to_existing_byte(v236_4_byte);
    {
    let v237_2: Space = singleton(&v236_4_cursor.path()[v236_4_origin..(v236_4_origin + 1)]);
    let v237_3: Space = intersect(&(*CONSTANT_12),&(v237_2));
    drop(v237_2);
    let v237_4: Space = if has_head(&(v237_3)) { singleton(&[]) } else { Space::new() };
    drop(v237_3);
    let v237_8: Space = if (&(v237_4)).is_empty() { Space::new() } else {
      let v238_5: Path = concat_path(&(*p0),&v236_4_cursor.path()[v236_4_origin..(v236_4_origin + 1)]);
      let v238_6: Path = concat_path(&(v238_5),&(*p1));
      drop(v238_5);
      let v238_7: Space = singleton(&(v238_6));
      drop(v238_6);
      compose(&(v237_4),&(v238_7))
    };
    drop(v237_4);
    join_wrapped_into(&mut v236_4_write,&((v237_8).read_zipper()),&[]);
    }
    v236_4_cursor.ascend(1);
  }
  drop(v236_4_cursor);
  drop(v236_4_write);
  (v236_4).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v239_3: Path = concat_path(&(*p0),&(*p1));
  let v239_4: Space = singleton(&(v239_3));
  drop(v239_3);
  (v239_4).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v240_15 = Space::new();
  let mut v240_15_write = v240_15.write_zipper();
  let mut v240_15_cursor = (*s0).read_zipper();
  let v240_15_origin = v240_15_cursor.path().len();
  for v240_15_byte in v240_15_cursor.child_mask().iter() {
    v240_15_cursor.descend_to_existing_byte(v240_15_byte);
    {
    let v241_2: Space = singleton(&v240_15_cursor.path()[v240_15_origin..(v240_15_origin + 1)]);
    let v241_3: Space = intersect(&(*CONSTANT_12),&(v241_2));
    let v241_4: Space = if has_head(&(v241_3)) { singleton(&[]) } else { Space::new() };
    drop(v241_3);
    let v241_5: Space = subtract(&(*CONSTANT_0),&(v241_4));
    drop(v241_4);
    let v241_8: Space = if (&(v241_5)).is_empty() { Space::new() } else {
      let v242_6: Path = concat_path(&(*p0),&v240_15_cursor.path()[v240_15_origin..(v240_15_origin + 1)]);
      let mut v242_7 = Space::new();
      let mut v242_7_write = v242_7.write_zipper();
      for v242_7_byte in v240_15_cursor.child_mask().iter() {
        v240_15_cursor.descend_to_existing_byte(v242_7_byte);
        {
        let v243_2: Space = singleton(&v240_15_cursor.path()[(v240_15_origin + 1)..(v240_15_origin + 2)]);
        let v243_3: Space = intersect(&(*CONSTANT_12),&(v243_2));
        let v243_4: Space = if has_head(&(v243_3)) { singleton(&[]) } else { Space::new() };
        drop(v243_3);
        let v243_5: Space = subtract(&(*CONSTANT_0),&(v243_4));
        drop(v243_4);
        let v243_8: Space = if (&(v243_5)).is_empty() { Space::new() } else {
          let v244_6: Path = concat_path(&(v242_6),&v240_15_cursor.path()[(v240_15_origin + 1)..(v240_15_origin + 2)]);
          let mut v244_7 = Space::new();
          let mut v244_7_write = v244_7.write_zipper();
          for v244_7_byte in v240_15_cursor.child_mask().iter() {
            v240_15_cursor.descend_to_existing_byte(v244_7_byte);
            {
            let v245_2: Space = singleton(&v240_15_cursor.path()[(v240_15_origin + 2)..(v240_15_origin + 3)]);
            let v245_3: Space = intersect(&(*CONSTANT_12),&(v245_2));
            let v245_4: Space = if has_head(&(v245_3)) { singleton(&[]) } else { Space::new() };
            drop(v245_3);
            let v245_5: Space = subtract(&(*CONSTANT_0),&(v245_4));
            drop(v245_4);
            let v245_8: Space = if (&(v245_5)).is_empty() { Space::new() } else {
              let v246_6: Path = concat_path(&(v244_6),&v240_15_cursor.path()[(v240_15_origin + 2)..(v240_15_origin + 3)]);
              let v246_7: Space = routine_18(c, &(v246_6), &(*p1), &v240_15_cursor);
              compose(&(v245_5),&(v246_7))
            };
            drop(v245_5);
            let v245_9: Space = intersect(&(*CONSTANT_12),&(v245_2));
            drop(v245_2);
            let v245_10: Space = if has_head(&(v245_9)) { singleton(&[]) } else { Space::new() };
            drop(v245_9);
            let v245_12: Space = if (&(v245_10)).is_empty() { Space::new() } else {
              let v247_6: Path = concat_path(&(v244_6),&v240_15_cursor.path()[(v240_15_origin + 2)..(v240_15_origin + 3)]);
              let v247_11: Space = routine_19(c, &(v247_6), &(*p1), &v240_15_cursor);
              drop(v247_6);
              compose(&(v245_10),&(v247_11))
            };
            drop(v245_10);
            let v245_13: Space = unite(&(v245_8),&(v245_12));
            join_wrapped_into(&mut v244_7_write,&((v245_13).read_zipper()),&[]);
            }
            v240_15_cursor.ascend(1);
          }
          drop(v244_7_write);
          compose(&(v243_5),&(v244_7))
        };
        drop(v243_5);
        let v243_9: Space = intersect(&(*CONSTANT_12),&(v243_2));
        drop(v243_2);
        let v243_10: Space = if has_head(&(v243_9)) { singleton(&[]) } else { Space::new() };
        drop(v243_9);
        let v243_12: Space = if (&(v243_10)).is_empty() { Space::new() } else {
          let v248_6: Path = concat_path(&(v242_6),&v240_15_cursor.path()[(v240_15_origin + 1)..(v240_15_origin + 2)]);
          let mut v248_11 = Space::new();
          let mut v248_11_write = v248_11.write_zipper();
          for v248_11_byte in v240_15_cursor.child_mask().iter() {
            v240_15_cursor.descend_to_existing_byte(v248_11_byte);
            {
            let v249_2: Space = singleton(&v240_15_cursor.path()[(v240_15_origin + 2)..(v240_15_origin + 3)]);
            let v249_3: Space = intersect(&(*CONSTANT_12),&(v249_2));
            let v249_4: Space = if has_head(&(v249_3)) { singleton(&[]) } else { Space::new() };
            drop(v249_3);
            let v249_5: Space = subtract(&(*CONSTANT_0),&(v249_4));
            drop(v249_4);
            let v249_8: Space = if (&(v249_5)).is_empty() { Space::new() } else {
              let v250_6: Path = concat_path(&(v248_6),&v240_15_cursor.path()[(v240_15_origin + 2)..(v240_15_origin + 3)]);
              let v250_7: Space = routine_18(c, &(v250_6), &(*p1), &v240_15_cursor);
              compose(&(v249_5),&(v250_7))
            };
            drop(v249_5);
            let v249_9: Space = intersect(&(*CONSTANT_12),&(v249_2));
            drop(v249_2);
            let v249_10: Space = if has_head(&(v249_9)) { singleton(&[]) } else { Space::new() };
            drop(v249_9);
            let v249_12: Space = if (&(v249_10)).is_empty() { Space::new() } else {
              let v251_6: Path = concat_path(&(v248_6),&v240_15_cursor.path()[(v240_15_origin + 2)..(v240_15_origin + 3)]);
              let v251_11: Space = routine_20(c, &(v251_6), &(*p1), &v240_15_cursor);
              drop(v251_6);
              compose(&(v249_10),&(v251_11))
            };
            drop(v249_10);
            let v249_13: Space = unite(&(v249_8),&(v249_12));
            join_wrapped_into(&mut v248_11_write,&((v249_13).read_zipper()),&[]);
            }
            v240_15_cursor.ascend(1);
          }
          drop(v248_11_write);
          drop(v248_6);
          compose(&(v243_10),&(v248_11))
        };
        drop(v243_10);
        let v243_13: Space = unite(&(v243_8),&(v243_12));
        join_wrapped_into(&mut v242_7_write,&((v243_13).read_zipper()),&[]);
        }
        v240_15_cursor.ascend(1);
      }
      drop(v242_7_write);
      compose(&(v241_5),&(v242_7))
    };
    drop(v241_5);
    let v241_9: Space = intersect(&(*CONSTANT_12),&(v241_2));
    drop(v241_2);
    let v241_10: Space = if has_head(&(v241_9)) { singleton(&[]) } else { Space::new() };
    drop(v241_9);
    let v241_13: Space = if (&(v241_10)).is_empty() { Space::new() } else {
      let v252_6: Path = concat_path(&(*p0),&v240_15_cursor.path()[v240_15_origin..(v240_15_origin + 1)]);
      let v252_11: Path = concat_path(&(v252_6),&(*p1));
      drop(v252_6);
      let v252_12: Space = singleton(&(v252_11));
      drop(v252_11);
      compose(&(v241_10),&(v252_12))
    };
    drop(v241_10);
    let v241_14: Space = unite(&(v241_8),&(v241_13));
    drop(v241_13);
    join_wrapped_into(&mut v240_15_write,&((v241_14).read_zipper()),&[]);
    }
    v240_15_cursor.ascend(1);
  }
  drop(v240_15_cursor);
  drop(v240_15_write);
  (v240_15).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v253_9 = Space::new();
  let mut v253_9_write = v253_9.write_zipper();
  let mut v253_9_cursor = (*s0).read_zipper();
  let v253_9_origin = v253_9_cursor.path().len();
  for v253_9_byte in v253_9_cursor.child_mask().iter() {
    v253_9_cursor.descend_to_existing_byte(v253_9_byte);
    {
    let v254_2: Space = singleton(&v253_9_cursor.path()[v253_9_origin..(v253_9_origin + 1)]);
    let v254_3: Space = intersect(&(*CONSTANT_12),&(v254_2));
    let v254_4: Space = if has_head(&(v254_3)) { singleton(&[]) } else { Space::new() };
    drop(v254_3);
    let v254_5: Space = subtract(&(*CONSTANT_0),&(v254_4));
    drop(v254_4);
    let v254_8: Space = if (&(v254_5)).is_empty() { Space::new() } else {
      let v255_6: Path = concat_path(&(*p0),&v253_9_cursor.path()[v253_9_origin..(v253_9_origin + 1)]);
      let mut v255_7 = Space::new();
      let mut v255_7_write = v255_7.write_zipper();
      for v255_7_byte in v253_9_cursor.child_mask().iter() {
        v253_9_cursor.descend_to_existing_byte(v255_7_byte);
        {
        let v256_2: Space = singleton(&v253_9_cursor.path()[(v253_9_origin + 1)..(v253_9_origin + 2)]);
        let v256_3: Space = intersect(&(*CONSTANT_12),&(v256_2));
        drop(v256_2);
        let v256_4: Space = if has_head(&(v256_3)) { singleton(&[]) } else { Space::new() };
        drop(v256_3);
        let v256_7: Space = if (&(v256_4)).is_empty() { Space::new() } else {
          let v257_5: Path = concat_path(&(v255_6),&v253_9_cursor.path()[(v253_9_origin + 1)..(v253_9_origin + 2)]);
          let mut v257_6 = Space::new();
          let mut v257_6_write = v257_6.write_zipper();
          for v257_6_byte in v253_9_cursor.child_mask().iter() {
            v253_9_cursor.descend_to_existing_byte(v257_6_byte);
            {
            let v258_2: Space = singleton(&v253_9_cursor.path()[(v253_9_origin + 2)..(v253_9_origin + 3)]);
            let v258_3: Space = intersect(&(*CONSTANT_12),&(v258_2));
            drop(v258_2);
            let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
            drop(v258_3);
            let v258_7: Space = if (&(v258_4)).is_empty() { Space::new() } else {
              let v259_5: Path = concat_path(&(v257_5),&v253_9_cursor.path()[(v253_9_origin + 2)..(v253_9_origin + 3)]);
              let v259_6: Space = routine_20(c, &(v259_5), &(*p1), &v253_9_cursor);
              drop(v259_5);
              compose(&(v258_4),&(v259_6))
            };
            drop(v258_4);
            join_wrapped_into(&mut v257_6_write,&((v258_7).read_zipper()),&[]);
            }
            v253_9_cursor.ascend(1);
          }
          drop(v257_6_write);
          drop(v257_5);
          compose(&(v256_4),&(v257_6))
        };
        drop(v256_4);
        join_wrapped_into(&mut v255_7_write,&((v256_7).read_zipper()),&[]);
        }
        v253_9_cursor.ascend(1);
      }
      drop(v255_7_write);
      compose(&(v254_5),&(v255_7))
    };
    drop(v254_5);
    let v254_9: Space = intersect(&(*CONSTANT_12),&(v254_2));
    drop(v254_2);
    let v254_10: Space = if has_head(&(v254_9)) { singleton(&[]) } else { Space::new() };
    drop(v254_9);
    let v254_12: Space = if (&(v254_10)).is_empty() { Space::new() } else {
      let v260_6: Path = concat_path(&(*p0),&v253_9_cursor.path()[v253_9_origin..(v253_9_origin + 1)]);
      let mut v260_11 = Space::new();
      let mut v260_11_write = v260_11.write_zipper();
      for v260_11_byte in v253_9_cursor.child_mask().iter() {
        v253_9_cursor.descend_to_existing_byte(v260_11_byte);
        {
        let v261_2: Space = singleton(&v253_9_cursor.path()[(v253_9_origin + 1)..(v253_9_origin + 2)]);
        let v261_3: Space = intersect(&(*CONSTANT_12),&(v261_2));
        drop(v261_2);
        let v261_4: Space = if has_head(&(v261_3)) { singleton(&[]) } else { Space::new() };
        drop(v261_3);
        let v261_8: Space = if (&(v261_4)).is_empty() { Space::new() } else {
          let v262_5: Path = concat_path(&(v260_6),&v253_9_cursor.path()[(v253_9_origin + 1)..(v253_9_origin + 2)]);
          let v262_6: Path = concat_path(&(v262_5),&(*p1));
          drop(v262_5);
          let v262_7: Space = singleton(&(v262_6));
          drop(v262_6);
          compose(&(v261_4),&(v262_7))
        };
        drop(v261_4);
        join_wrapped_into(&mut v260_11_write,&((v261_8).read_zipper()),&[]);
        }
        v253_9_cursor.ascend(1);
      }
      drop(v260_11_write);
      drop(v260_6);
      compose(&(v254_10),&(v260_11))
    };
    drop(v254_10);
    let v254_13: Space = unite(&(v254_8),&(v254_12));
    drop(v254_12);
    join_wrapped_into(&mut v253_9_write,&((v254_13).read_zipper()),&[]);
    }
    v253_9_cursor.ascend(1);
  }
  drop(v253_9_cursor);
  drop(v253_9_write);
  (v253_9).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v263_8 = Space::new();
  let mut v263_8_write = v263_8.write_zipper();
  let mut v263_8_cursor = (*s0).read_zipper();
  let v263_8_origin = v263_8_cursor.path().len();
  for v263_8_byte in v263_8_cursor.child_mask().iter() {
    v263_8_cursor.descend_to_existing_byte(v263_8_byte);
    {
    let v264_2: Space = singleton(&v263_8_cursor.path()[v263_8_origin..(v263_8_origin + 1)]);
    let v264_3: Space = intersect(&(*CONSTANT_12),&(v264_2));
    let v264_4: Space = if has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
    drop(v264_3);
    let v264_5: Space = subtract(&(*CONSTANT_0),&(v264_4));
    drop(v264_4);
    let v264_8: Space = if (&(v264_5)).is_empty() { Space::new() } else {
      let v265_6: Path = concat_path(&(*p0),&v263_8_cursor.path()[v263_8_origin..(v263_8_origin + 1)]);
      let mut v265_7 = Space::new();
      let mut v265_7_write = v265_7.write_zipper();
      for v265_7_byte in v263_8_cursor.child_mask().iter() {
        v263_8_cursor.descend_to_existing_byte(v265_7_byte);
        {
        let v266_2: Space = singleton(&v263_8_cursor.path()[(v263_8_origin + 1)..(v263_8_origin + 2)]);
        let v266_3: Space = intersect(&(*CONSTANT_12),&(v266_2));
        drop(v266_2);
        let v266_4: Space = if has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
        drop(v266_3);
        let v266_7: Space = if (&(v266_4)).is_empty() { Space::new() } else {
          let v267_5: Path = concat_path(&(v265_6),&v263_8_cursor.path()[(v263_8_origin + 1)..(v263_8_origin + 2)]);
          let mut v267_6 = Space::new();
          let mut v267_6_write = v267_6.write_zipper();
          for v267_6_byte in v263_8_cursor.child_mask().iter() {
            v263_8_cursor.descend_to_existing_byte(v267_6_byte);
            {
            let v268_2: Space = singleton(&v263_8_cursor.path()[(v263_8_origin + 2)..(v263_8_origin + 3)]);
            let v268_3: Space = intersect(&(*CONSTANT_12),&(v268_2));
            drop(v268_2);
            let v268_4: Space = if has_head(&(v268_3)) { singleton(&[]) } else { Space::new() };
            drop(v268_3);
            let v268_7: Space = if (&(v268_4)).is_empty() { Space::new() } else {
              let v269_5: Path = concat_path(&(v267_5),&v263_8_cursor.path()[(v263_8_origin + 2)..(v263_8_origin + 3)]);
              let v269_6: Space = routine_20(c, &(v269_5), &(*p1), &v263_8_cursor);
              drop(v269_5);
              compose(&(v268_4),&(v269_6))
            };
            drop(v268_4);
            join_wrapped_into(&mut v267_6_write,&((v268_7).read_zipper()),&[]);
            }
            v263_8_cursor.ascend(1);
          }
          drop(v267_6_write);
          drop(v267_5);
          compose(&(v266_4),&(v267_6))
        };
        drop(v266_4);
        join_wrapped_into(&mut v265_7_write,&((v266_7).read_zipper()),&[]);
        }
        v263_8_cursor.ascend(1);
      }
      drop(v265_7_write);
      compose(&(v264_5),&(v265_7))
    };
    drop(v264_5);
    let v264_9: Space = intersect(&(*CONSTANT_12),&(v264_2));
    drop(v264_2);
    let v264_10: Space = if has_head(&(v264_9)) { singleton(&[]) } else { Space::new() };
    drop(v264_9);
    let v264_13: Space = if (&(v264_10)).is_empty() { Space::new() } else {
      let v270_6: Path = concat_path(&(*p0),&v263_8_cursor.path()[v263_8_origin..(v263_8_origin + 1)]);
      let v270_11: Path = concat_path(&(v270_6),&(*p1));
      drop(v270_6);
      let v270_12: Space = singleton(&(v270_11));
      drop(v270_11);
      compose(&(v264_10),&(v270_12))
    };
    drop(v264_10);
    let v264_14: Space = unite(&(v264_8),&(v264_13));
    drop(v264_13);
    join_wrapped_into(&mut v263_8_write,&((v264_14).read_zipper()),&[]);
    }
    v263_8_cursor.ascend(1);
  }
  drop(v263_8_cursor);
  drop(v263_8_write);
  (v263_8).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v271_5 = Space::new();
  let mut v271_5_write = v271_5.write_zipper();
  let mut v271_5_cursor = (*s0).read_zipper();
  let v271_5_origin = v271_5_cursor.path().len();
  for v271_5_byte in v271_5_cursor.child_mask().iter() {
    v271_5_cursor.descend_to_existing_byte(v271_5_byte);
    {
    let v272_2: Space = singleton(&v271_5_cursor.path()[v271_5_origin..(v271_5_origin + 1)]);
    let v272_3: Space = intersect(&(*CONSTANT_12),&(v272_2));
    drop(v272_2);
    let v272_4: Space = if has_head(&(v272_3)) { singleton(&[]) } else { Space::new() };
    drop(v272_3);
    let v272_7: Space = if (&(v272_4)).is_empty() { Space::new() } else {
      let v273_5: Path = concat_path(&(*p0),&v271_5_cursor.path()[v271_5_origin..(v271_5_origin + 1)]);
      let mut v273_6 = Space::new();
      let mut v273_6_write = v273_6.write_zipper();
      for v273_6_byte in v271_5_cursor.child_mask().iter() {
        v271_5_cursor.descend_to_existing_byte(v273_6_byte);
        {
        let v274_2: Space = singleton(&v271_5_cursor.path()[(v271_5_origin + 1)..(v271_5_origin + 2)]);
        let v274_3: Space = intersect(&(*CONSTANT_12),&(v274_2));
        drop(v274_2);
        let v274_4: Space = if has_head(&(v274_3)) { singleton(&[]) } else { Space::new() };
        drop(v274_3);
        let v274_8: Space = if (&(v274_4)).is_empty() { Space::new() } else {
          let v275_5: Path = concat_path(&(v273_5),&v271_5_cursor.path()[(v271_5_origin + 1)..(v271_5_origin + 2)]);
          let v275_6: Path = concat_path(&(v275_5),&(*p1));
          drop(v275_5);
          let v275_7: Space = singleton(&(v275_6));
          drop(v275_6);
          compose(&(v274_4),&(v275_7))
        };
        drop(v274_4);
        join_wrapped_into(&mut v273_6_write,&((v274_8).read_zipper()),&[]);
        }
        v271_5_cursor.ascend(1);
      }
      drop(v273_6_write);
      drop(v273_5);
      compose(&(v272_4),&(v273_6))
    };
    drop(v272_4);
    join_wrapped_into(&mut v271_5_write,&((v272_7).read_zipper()),&[]);
    }
    v271_5_cursor.ascend(1);
  }
  drop(v271_5_cursor);
  drop(v271_5_write);
  (v271_5).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v276_4 = Space::new();
  let mut v276_4_write = v276_4.write_zipper();
  let mut v276_4_cursor = (*s0).read_zipper();
  let v276_4_origin = v276_4_cursor.path().len();
  for v276_4_byte in v276_4_cursor.child_mask().iter() {
    v276_4_cursor.descend_to_existing_byte(v276_4_byte);
    {
    let v277_2: Space = singleton(&v276_4_cursor.path()[v276_4_origin..(v276_4_origin + 1)]);
    let v277_3: Space = intersect(&(*CONSTANT_12),&(v277_2));
    drop(v277_2);
    let v277_4: Space = if has_head(&(v277_3)) { singleton(&[]) } else { Space::new() };
    drop(v277_3);
    let v277_8: Space = if (&(v277_4)).is_empty() { Space::new() } else {
      let v278_5: Path = concat_path(&(*p0),&v276_4_cursor.path()[v276_4_origin..(v276_4_origin + 1)]);
      let v278_6: Path = concat_path(&(v278_5),&(*p1));
      drop(v278_5);
      let v278_7: Space = singleton(&(v278_6));
      drop(v278_6);
      compose(&(v277_4),&(v278_7))
    };
    drop(v277_4);
    join_wrapped_into(&mut v276_4_write,&((v277_8).read_zipper()),&[]);
    }
    v276_4_cursor.ascend(1);
  }
  drop(v276_4_cursor);
  drop(v276_4_write);
  (v276_4).clone()
}

fn routine_26(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v279_2: Space = first_matching(&(*s0),&(*CONSTANT_0),false);
  let v279_3: Space = intersect(&(*CONSTANT_0),&(v279_2));
  let v279_4: Space = if has_head(&(v279_2)) { singleton(&[]) } else { Space::new() };
  let v279_5: Space = unite(&(v279_3),&(v279_4));
  drop(v279_3);
  let v279_7: Space = compose(&(v279_5),&(*CONSTANT_0));
  drop(v279_5);
  let v279_9: Space = subtract(&(*CONSTANT_0),&(v279_2));
  drop(v279_2);
  let v279_10: Space = subtract(&(v279_9),&(v279_4));
  drop(v279_4);
  drop(v279_9);
  let v279_18: Space = if (&(v279_10)).is_empty() { Space::new() } else {
    let v280_11: Space = first_fibonacci(&(*s0),6,5,true);
    let v280_12: Space = first_matching(&(v280_11),&(*CONSTANT_0),false);
    let v280_15: Space = if (&(v280_12)).is_empty() { Space::new() } else {
      let v281_14: Space = routine_40(c, &(*CONSTANT_14), &(*s0));
      compose(&(v280_12),&(v281_14))
    };
    drop(v280_12);
    let mut v280_16 = Space::new();
    let mut v280_16_write = v280_16.write_zipper();
    let mut v280_16_cursor = (v280_11).read_zipper();
    let v280_16_origin = v280_16_cursor.path().len();
    for v280_16_byte in v280_16_cursor.child_mask().iter() {
      v280_16_cursor.descend_to_existing_byte(v280_16_byte);
      {
      let v282_2_arg_0: &[u8] = &v280_16_cursor.path()[v280_16_origin..(v280_16_origin + 1)];
      let v282_2_arg_2: &Space = &(&(*s0)).make_map();
      let mut v282_2_more = v280_16_cursor.is_val() || next_value_within(&mut v280_16_cursor,(v280_16_origin + 1));
      while v282_2_more {
        {
        let v282_2_depth = v280_16_cursor.path().len();
        let v283_4: Space = routine_26(c, &(descend_cursor((*v282_2_arg_2).read_zipper(),&v280_16_cursor.path()[v280_16_origin..v282_2_depth])));
        join_wrapped_into(&mut v280_16_write,&((v283_4).read_zipper()),&v280_16_cursor.path()[v280_16_origin..v282_2_depth]);
        }
        v282_2_more = next_value_within(&mut v280_16_cursor,(v280_16_origin + 1));
      }
      }
      v280_16_cursor.ascend(1);
    }
    drop(v280_16_cursor);
    drop(v280_16_write);
    drop(v280_11);
    let v280_17: Space = unite(&(v280_15),&(v280_16));
    compose(&(v279_10),&(v280_17))
  };
  drop(v279_10);
  let v279_19: Space = unite(&(v279_7),&(v279_18));
  drop(v279_7);
  (v279_19).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v284_3: Space = Space::new();
  (v284_3).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v285_4 = Space::new();
  let mut v285_4_write = v285_4.write_zipper();
  let mut v285_4_cursor = (*s0).read_zipper();
  let v285_4_origin = v285_4_cursor.path().len();
  for v285_4_byte in v285_4_cursor.child_mask().iter() {
    v285_4_cursor.descend_to_existing_byte(v285_4_byte);
    {
    let v286_2: Space = singleton(&v285_4_cursor.path()[v285_4_origin..(v285_4_origin + 1)]);
    let v286_3: Space = intersect(&(*CONSTANT_12),&(v286_2));
    drop(v286_2);
    let v286_4: Space = if has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
    drop(v286_3);
    let v286_8: Space = if (&(v286_4)).is_empty() { Space::new() } else {
      let v287_5: Path = concat_path(&(*p0),&v285_4_cursor.path()[v285_4_origin..(v285_4_origin + 1)]);
      let v287_6: Path = concat_path(&(v287_5),&(*p1));
      drop(v287_5);
      let v287_7: Space = singleton(&(v287_6));
      drop(v287_6);
      compose(&(v286_4),&(v287_7))
    };
    drop(v286_4);
    join_wrapped_into(&mut v285_4_write,&((v286_8).read_zipper()),&[]);
    }
    v285_4_cursor.ascend(1);
  }
  drop(v285_4_cursor);
  drop(v285_4_write);
  (v285_4).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v288_3: Path = concat_path(&(*p0),&(*p1));
  let v288_4: Space = singleton(&(v288_3));
  drop(v288_3);
  (v288_4).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v289_15 = Space::new();
  let mut v289_15_write = v289_15.write_zipper();
  let mut v289_15_cursor = (*s0).read_zipper();
  let v289_15_origin = v289_15_cursor.path().len();
  for v289_15_byte in v289_15_cursor.child_mask().iter() {
    v289_15_cursor.descend_to_existing_byte(v289_15_byte);
    {
    let v290_2: Space = singleton(&v289_15_cursor.path()[v289_15_origin..(v289_15_origin + 1)]);
    let v290_3: Space = intersect(&(*CONSTANT_12),&(v290_2));
    let v290_4: Space = if has_head(&(v290_3)) { singleton(&[]) } else { Space::new() };
    drop(v290_3);
    let v290_5: Space = subtract(&(*CONSTANT_0),&(v290_4));
    drop(v290_4);
    let v290_8: Space = if (&(v290_5)).is_empty() { Space::new() } else {
      let v291_6: Path = concat_path(&(*p0),&v289_15_cursor.path()[v289_15_origin..(v289_15_origin + 1)]);
      let mut v291_7 = Space::new();
      let mut v291_7_write = v291_7.write_zipper();
      for v291_7_byte in v289_15_cursor.child_mask().iter() {
        v289_15_cursor.descend_to_existing_byte(v291_7_byte);
        {
        let v292_2: Space = singleton(&v289_15_cursor.path()[(v289_15_origin + 1)..(v289_15_origin + 2)]);
        let v292_3: Space = intersect(&(*CONSTANT_12),&(v292_2));
        let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
        drop(v292_3);
        let v292_5: Space = subtract(&(*CONSTANT_0),&(v292_4));
        drop(v292_4);
        let v292_8: Space = if (&(v292_5)).is_empty() { Space::new() } else {
          let v293_6: Path = concat_path(&(v291_6),&v289_15_cursor.path()[(v289_15_origin + 1)..(v289_15_origin + 2)]);
          let mut v293_7 = Space::new();
          let mut v293_7_write = v293_7.write_zipper();
          for v293_7_byte in v289_15_cursor.child_mask().iter() {
            v289_15_cursor.descend_to_existing_byte(v293_7_byte);
            {
            let v294_2: Space = singleton(&v289_15_cursor.path()[(v289_15_origin + 2)..(v289_15_origin + 3)]);
            let v294_3: Space = intersect(&(*CONSTANT_12),&(v294_2));
            let v294_4: Space = if has_head(&(v294_3)) { singleton(&[]) } else { Space::new() };
            drop(v294_3);
            let v294_5: Space = subtract(&(*CONSTANT_0),&(v294_4));
            drop(v294_4);
            let v294_8: Space = if (&(v294_5)).is_empty() { Space::new() } else {
              let v295_6: Path = concat_path(&(v293_6),&v289_15_cursor.path()[(v289_15_origin + 2)..(v289_15_origin + 3)]);
              let v295_7: Space = routine_27(c, &(v295_6), &(*p1), &v289_15_cursor);
              compose(&(v294_5),&(v295_7))
            };
            drop(v294_5);
            let v294_9: Space = intersect(&(*CONSTANT_12),&(v294_2));
            drop(v294_2);
            let v294_10: Space = if has_head(&(v294_9)) { singleton(&[]) } else { Space::new() };
            drop(v294_9);
            let v294_12: Space = if (&(v294_10)).is_empty() { Space::new() } else {
              let v296_6: Path = concat_path(&(v293_6),&v289_15_cursor.path()[(v289_15_origin + 2)..(v289_15_origin + 3)]);
              let v296_11: Space = routine_28(c, &(v296_6), &(*p1), &v289_15_cursor);
              drop(v296_6);
              compose(&(v294_10),&(v296_11))
            };
            drop(v294_10);
            let v294_13: Space = unite(&(v294_8),&(v294_12));
            join_wrapped_into(&mut v293_7_write,&((v294_13).read_zipper()),&[]);
            }
            v289_15_cursor.ascend(1);
          }
          drop(v293_7_write);
          compose(&(v292_5),&(v293_7))
        };
        drop(v292_5);
        let v292_9: Space = intersect(&(*CONSTANT_12),&(v292_2));
        drop(v292_2);
        let v292_10: Space = if has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
        drop(v292_9);
        let v292_12: Space = if (&(v292_10)).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v291_6),&v289_15_cursor.path()[(v289_15_origin + 1)..(v289_15_origin + 2)]);
          let mut v297_11 = Space::new();
          let mut v297_11_write = v297_11.write_zipper();
          for v297_11_byte in v289_15_cursor.child_mask().iter() {
            v289_15_cursor.descend_to_existing_byte(v297_11_byte);
            {
            let v298_2: Space = singleton(&v289_15_cursor.path()[(v289_15_origin + 2)..(v289_15_origin + 3)]);
            let v298_3: Space = intersect(&(*CONSTANT_12),&(v298_2));
            let v298_4: Space = if has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = subtract(&(*CONSTANT_0),&(v298_4));
            drop(v298_4);
            let v298_8: Space = if (&(v298_5)).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v297_6),&v289_15_cursor.path()[(v289_15_origin + 2)..(v289_15_origin + 3)]);
              let v299_7: Space = routine_27(c, &(v299_6), &(*p1), &v289_15_cursor);
              compose(&(v298_5),&(v299_7))
            };
            drop(v298_5);
            let v298_9: Space = intersect(&(*CONSTANT_12),&(v298_2));
            drop(v298_2);
            let v298_10: Space = if has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
            drop(v298_9);
            let v298_12: Space = if (&(v298_10)).is_empty() { Space::new() } else {
              let v300_6: Path = concat_path(&(v297_6),&v289_15_cursor.path()[(v289_15_origin + 2)..(v289_15_origin + 3)]);
              let v300_11: Space = routine_29(c, &(v300_6), &(*p1), &v289_15_cursor);
              drop(v300_6);
              compose(&(v298_10),&(v300_11))
            };
            drop(v298_10);
            let v298_13: Space = unite(&(v298_8),&(v298_12));
            join_wrapped_into(&mut v297_11_write,&((v298_13).read_zipper()),&[]);
            }
            v289_15_cursor.ascend(1);
          }
          drop(v297_11_write);
          drop(v297_6);
          compose(&(v292_10),&(v297_11))
        };
        drop(v292_10);
        let v292_13: Space = unite(&(v292_8),&(v292_12));
        join_wrapped_into(&mut v291_7_write,&((v292_13).read_zipper()),&[]);
        }
        v289_15_cursor.ascend(1);
      }
      drop(v291_7_write);
      compose(&(v290_5),&(v291_7))
    };
    drop(v290_5);
    let v290_9: Space = intersect(&(*CONSTANT_12),&(v290_2));
    drop(v290_2);
    let v290_10: Space = if has_head(&(v290_9)) { singleton(&[]) } else { Space::new() };
    drop(v290_9);
    let v290_13: Space = if (&(v290_10)).is_empty() { Space::new() } else {
      let v301_6: Path = concat_path(&(*p0),&v289_15_cursor.path()[v289_15_origin..(v289_15_origin + 1)]);
      let v301_11: Path = concat_path(&(v301_6),&(*p1));
      drop(v301_6);
      let v301_12: Space = singleton(&(v301_11));
      drop(v301_11);
      compose(&(v290_10),&(v301_12))
    };
    drop(v290_10);
    let v290_14: Space = unite(&(v290_8),&(v290_13));
    drop(v290_13);
    join_wrapped_into(&mut v289_15_write,&((v290_14).read_zipper()),&[]);
    }
    v289_15_cursor.ascend(1);
  }
  drop(v289_15_cursor);
  drop(v289_15_write);
  (v289_15).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v302_9 = Space::new();
  let mut v302_9_write = v302_9.write_zipper();
  let mut v302_9_cursor = (*s0).read_zipper();
  let v302_9_origin = v302_9_cursor.path().len();
  for v302_9_byte in v302_9_cursor.child_mask().iter() {
    v302_9_cursor.descend_to_existing_byte(v302_9_byte);
    {
    let v303_2: Space = singleton(&v302_9_cursor.path()[v302_9_origin..(v302_9_origin + 1)]);
    let v303_3: Space = intersect(&(*CONSTANT_12),&(v303_2));
    let v303_4: Space = if has_head(&(v303_3)) { singleton(&[]) } else { Space::new() };
    drop(v303_3);
    let v303_5: Space = subtract(&(*CONSTANT_0),&(v303_4));
    drop(v303_4);
    let v303_8: Space = if (&(v303_5)).is_empty() { Space::new() } else {
      let v304_6: Path = concat_path(&(*p0),&v302_9_cursor.path()[v302_9_origin..(v302_9_origin + 1)]);
      let mut v304_7 = Space::new();
      let mut v304_7_write = v304_7.write_zipper();
      for v304_7_byte in v302_9_cursor.child_mask().iter() {
        v302_9_cursor.descend_to_existing_byte(v304_7_byte);
        {
        let v305_2: Space = singleton(&v302_9_cursor.path()[(v302_9_origin + 1)..(v302_9_origin + 2)]);
        let v305_3: Space = intersect(&(*CONSTANT_12),&(v305_2));
        drop(v305_2);
        let v305_4: Space = if has_head(&(v305_3)) { singleton(&[]) } else { Space::new() };
        drop(v305_3);
        let v305_7: Space = if (&(v305_4)).is_empty() { Space::new() } else {
          let v306_5: Path = concat_path(&(v304_6),&v302_9_cursor.path()[(v302_9_origin + 1)..(v302_9_origin + 2)]);
          let mut v306_6 = Space::new();
          let mut v306_6_write = v306_6.write_zipper();
          for v306_6_byte in v302_9_cursor.child_mask().iter() {
            v302_9_cursor.descend_to_existing_byte(v306_6_byte);
            {
            let v307_2: Space = singleton(&v302_9_cursor.path()[(v302_9_origin + 2)..(v302_9_origin + 3)]);
            let v307_3: Space = intersect(&(*CONSTANT_12),&(v307_2));
            drop(v307_2);
            let v307_4: Space = if has_head(&(v307_3)) { singleton(&[]) } else { Space::new() };
            drop(v307_3);
            let v307_7: Space = if (&(v307_4)).is_empty() { Space::new() } else {
              let v308_5: Path = concat_path(&(v306_5),&v302_9_cursor.path()[(v302_9_origin + 2)..(v302_9_origin + 3)]);
              let v308_6: Space = routine_29(c, &(v308_5), &(*p1), &v302_9_cursor);
              drop(v308_5);
              compose(&(v307_4),&(v308_6))
            };
            drop(v307_4);
            join_wrapped_into(&mut v306_6_write,&((v307_7).read_zipper()),&[]);
            }
            v302_9_cursor.ascend(1);
          }
          drop(v306_6_write);
          drop(v306_5);
          compose(&(v305_4),&(v306_6))
        };
        drop(v305_4);
        join_wrapped_into(&mut v304_7_write,&((v305_7).read_zipper()),&[]);
        }
        v302_9_cursor.ascend(1);
      }
      drop(v304_7_write);
      compose(&(v303_5),&(v304_7))
    };
    drop(v303_5);
    let v303_9: Space = intersect(&(*CONSTANT_12),&(v303_2));
    drop(v303_2);
    let v303_10: Space = if has_head(&(v303_9)) { singleton(&[]) } else { Space::new() };
    drop(v303_9);
    let v303_12: Space = if (&(v303_10)).is_empty() { Space::new() } else {
      let v309_6: Path = concat_path(&(*p0),&v302_9_cursor.path()[v302_9_origin..(v302_9_origin + 1)]);
      let mut v309_11 = Space::new();
      let mut v309_11_write = v309_11.write_zipper();
      for v309_11_byte in v302_9_cursor.child_mask().iter() {
        v302_9_cursor.descend_to_existing_byte(v309_11_byte);
        {
        let v310_2: Space = singleton(&v302_9_cursor.path()[(v302_9_origin + 1)..(v302_9_origin + 2)]);
        let v310_3: Space = intersect(&(*CONSTANT_12),&(v310_2));
        drop(v310_2);
        let v310_4: Space = if has_head(&(v310_3)) { singleton(&[]) } else { Space::new() };
        drop(v310_3);
        let v310_8: Space = if (&(v310_4)).is_empty() { Space::new() } else {
          let v311_5: Path = concat_path(&(v309_6),&v302_9_cursor.path()[(v302_9_origin + 1)..(v302_9_origin + 2)]);
          let v311_6: Path = concat_path(&(v311_5),&(*p1));
          drop(v311_5);
          let v311_7: Space = singleton(&(v311_6));
          drop(v311_6);
          compose(&(v310_4),&(v311_7))
        };
        drop(v310_4);
        join_wrapped_into(&mut v309_11_write,&((v310_8).read_zipper()),&[]);
        }
        v302_9_cursor.ascend(1);
      }
      drop(v309_11_write);
      drop(v309_6);
      compose(&(v303_10),&(v309_11))
    };
    drop(v303_10);
    let v303_13: Space = unite(&(v303_8),&(v303_12));
    drop(v303_12);
    join_wrapped_into(&mut v302_9_write,&((v303_13).read_zipper()),&[]);
    }
    v302_9_cursor.ascend(1);
  }
  drop(v302_9_cursor);
  drop(v302_9_write);
  (v302_9).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v312_8 = Space::new();
  let mut v312_8_write = v312_8.write_zipper();
  let mut v312_8_cursor = (*s0).read_zipper();
  let v312_8_origin = v312_8_cursor.path().len();
  for v312_8_byte in v312_8_cursor.child_mask().iter() {
    v312_8_cursor.descend_to_existing_byte(v312_8_byte);
    {
    let v313_2: Space = singleton(&v312_8_cursor.path()[v312_8_origin..(v312_8_origin + 1)]);
    let v313_3: Space = intersect(&(*CONSTANT_12),&(v313_2));
    let v313_4: Space = if has_head(&(v313_3)) { singleton(&[]) } else { Space::new() };
    drop(v313_3);
    let v313_5: Space = subtract(&(*CONSTANT_0),&(v313_4));
    drop(v313_4);
    let v313_8: Space = if (&(v313_5)).is_empty() { Space::new() } else {
      let v314_6: Path = concat_path(&(*p0),&v312_8_cursor.path()[v312_8_origin..(v312_8_origin + 1)]);
      let mut v314_7 = Space::new();
      let mut v314_7_write = v314_7.write_zipper();
      for v314_7_byte in v312_8_cursor.child_mask().iter() {
        v312_8_cursor.descend_to_existing_byte(v314_7_byte);
        {
        let v315_2: Space = singleton(&v312_8_cursor.path()[(v312_8_origin + 1)..(v312_8_origin + 2)]);
        let v315_3: Space = intersect(&(*CONSTANT_12),&(v315_2));
        drop(v315_2);
        let v315_4: Space = if has_head(&(v315_3)) { singleton(&[]) } else { Space::new() };
        drop(v315_3);
        let v315_7: Space = if (&(v315_4)).is_empty() { Space::new() } else {
          let v316_5: Path = concat_path(&(v314_6),&v312_8_cursor.path()[(v312_8_origin + 1)..(v312_8_origin + 2)]);
          let mut v316_6 = Space::new();
          let mut v316_6_write = v316_6.write_zipper();
          for v316_6_byte in v312_8_cursor.child_mask().iter() {
            v312_8_cursor.descend_to_existing_byte(v316_6_byte);
            {
            let v317_2: Space = singleton(&v312_8_cursor.path()[(v312_8_origin + 2)..(v312_8_origin + 3)]);
            let v317_3: Space = intersect(&(*CONSTANT_12),&(v317_2));
            drop(v317_2);
            let v317_4: Space = if has_head(&(v317_3)) { singleton(&[]) } else { Space::new() };
            drop(v317_3);
            let v317_7: Space = if (&(v317_4)).is_empty() { Space::new() } else {
              let v318_5: Path = concat_path(&(v316_5),&v312_8_cursor.path()[(v312_8_origin + 2)..(v312_8_origin + 3)]);
              let v318_6: Space = routine_29(c, &(v318_5), &(*p1), &v312_8_cursor);
              drop(v318_5);
              compose(&(v317_4),&(v318_6))
            };
            drop(v317_4);
            join_wrapped_into(&mut v316_6_write,&((v317_7).read_zipper()),&[]);
            }
            v312_8_cursor.ascend(1);
          }
          drop(v316_6_write);
          drop(v316_5);
          compose(&(v315_4),&(v316_6))
        };
        drop(v315_4);
        join_wrapped_into(&mut v314_7_write,&((v315_7).read_zipper()),&[]);
        }
        v312_8_cursor.ascend(1);
      }
      drop(v314_7_write);
      compose(&(v313_5),&(v314_7))
    };
    drop(v313_5);
    let v313_9: Space = intersect(&(*CONSTANT_12),&(v313_2));
    drop(v313_2);
    let v313_10: Space = if has_head(&(v313_9)) { singleton(&[]) } else { Space::new() };
    drop(v313_9);
    let v313_13: Space = if (&(v313_10)).is_empty() { Space::new() } else {
      let v319_6: Path = concat_path(&(*p0),&v312_8_cursor.path()[v312_8_origin..(v312_8_origin + 1)]);
      let v319_11: Path = concat_path(&(v319_6),&(*p1));
      drop(v319_6);
      let v319_12: Space = singleton(&(v319_11));
      drop(v319_11);
      compose(&(v313_10),&(v319_12))
    };
    drop(v313_10);
    let v313_14: Space = unite(&(v313_8),&(v313_13));
    drop(v313_13);
    join_wrapped_into(&mut v312_8_write,&((v313_14).read_zipper()),&[]);
    }
    v312_8_cursor.ascend(1);
  }
  drop(v312_8_cursor);
  drop(v312_8_write);
  (v312_8).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v320_5 = Space::new();
  let mut v320_5_write = v320_5.write_zipper();
  let mut v320_5_cursor = (*s0).read_zipper();
  let v320_5_origin = v320_5_cursor.path().len();
  for v320_5_byte in v320_5_cursor.child_mask().iter() {
    v320_5_cursor.descend_to_existing_byte(v320_5_byte);
    {
    let v321_2: Space = singleton(&v320_5_cursor.path()[v320_5_origin..(v320_5_origin + 1)]);
    let v321_3: Space = intersect(&(*CONSTANT_12),&(v321_2));
    drop(v321_2);
    let v321_4: Space = if has_head(&(v321_3)) { singleton(&[]) } else { Space::new() };
    drop(v321_3);
    let v321_7: Space = if (&(v321_4)).is_empty() { Space::new() } else {
      let v322_5: Path = concat_path(&(*p0),&v320_5_cursor.path()[v320_5_origin..(v320_5_origin + 1)]);
      let mut v322_6 = Space::new();
      let mut v322_6_write = v322_6.write_zipper();
      for v322_6_byte in v320_5_cursor.child_mask().iter() {
        v320_5_cursor.descend_to_existing_byte(v322_6_byte);
        {
        let v323_2: Space = singleton(&v320_5_cursor.path()[(v320_5_origin + 1)..(v320_5_origin + 2)]);
        let v323_3: Space = intersect(&(*CONSTANT_12),&(v323_2));
        drop(v323_2);
        let v323_4: Space = if has_head(&(v323_3)) { singleton(&[]) } else { Space::new() };
        drop(v323_3);
        let v323_8: Space = if (&(v323_4)).is_empty() { Space::new() } else {
          let v324_5: Path = concat_path(&(v322_5),&v320_5_cursor.path()[(v320_5_origin + 1)..(v320_5_origin + 2)]);
          let v324_6: Path = concat_path(&(v324_5),&(*p1));
          drop(v324_5);
          let v324_7: Space = singleton(&(v324_6));
          drop(v324_6);
          compose(&(v323_4),&(v324_7))
        };
        drop(v323_4);
        join_wrapped_into(&mut v322_6_write,&((v323_8).read_zipper()),&[]);
        }
        v320_5_cursor.ascend(1);
      }
      drop(v322_6_write);
      drop(v322_5);
      compose(&(v321_4),&(v322_6))
    };
    drop(v321_4);
    join_wrapped_into(&mut v320_5_write,&((v321_7).read_zipper()),&[]);
    }
    v320_5_cursor.ascend(1);
  }
  drop(v320_5_cursor);
  drop(v320_5_write);
  (v320_5).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v325_4 = Space::new();
  let mut v325_4_write = v325_4.write_zipper();
  let mut v325_4_cursor = (*s0).read_zipper();
  let v325_4_origin = v325_4_cursor.path().len();
  for v325_4_byte in v325_4_cursor.child_mask().iter() {
    v325_4_cursor.descend_to_existing_byte(v325_4_byte);
    {
    let v326_2: Space = singleton(&v325_4_cursor.path()[v325_4_origin..(v325_4_origin + 1)]);
    let v326_3: Space = intersect(&(*CONSTANT_12),&(v326_2));
    drop(v326_2);
    let v326_4: Space = if has_head(&(v326_3)) { singleton(&[]) } else { Space::new() };
    drop(v326_3);
    let v326_8: Space = if (&(v326_4)).is_empty() { Space::new() } else {
      let v327_5: Path = concat_path(&(*p0),&v325_4_cursor.path()[v325_4_origin..(v325_4_origin + 1)]);
      let v327_6: Path = concat_path(&(v327_5),&(*p1));
      drop(v327_5);
      let v327_7: Space = singleton(&(v327_6));
      drop(v327_6);
      compose(&(v326_4),&(v327_7))
    };
    drop(v326_4);
    join_wrapped_into(&mut v325_4_write,&((v326_8).read_zipper()),&[]);
    }
    v325_4_cursor.ascend(1);
  }
  drop(v325_4_cursor);
  drop(v325_4_write);
  (v325_4).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let mut v328_7 = Space::new();
  let mut v328_7_write = v328_7.write_zipper();
  let mut v328_7_cursor = (*s0).read_zipper();
  let v328_7_origin = v328_7_cursor.path().len();
  for v328_7_byte in v328_7_cursor.child_mask().iter() {
    v328_7_cursor.descend_to_existing_byte(v328_7_byte);
    {
    let v329_2: Space = singleton(&v328_7_cursor.path()[v328_7_origin..(v328_7_origin + 1)]);
    let v329_3: Space = intersect(&(*CONSTANT_12),&(v329_2));
    drop(v329_2);
    let v329_4: Space = if has_head(&(v329_3)) { singleton(&[]) } else { Space::new() };
    drop(v329_3);
    let v329_7: Space = if (&(v329_4)).is_empty() { Space::new() } else {
      let v330_5: Path = concat_path(&(*p0),&v328_7_cursor.path()[v328_7_origin..(v328_7_origin + 1)]);
      let mut v330_6 = Space::new();
      let mut v330_6_write = v330_6.write_zipper();
      for v330_6_byte in v328_7_cursor.child_mask().iter() {
        v328_7_cursor.descend_to_existing_byte(v330_6_byte);
        {
        let v331_2: Space = singleton(&v328_7_cursor.path()[(v328_7_origin + 1)..(v328_7_origin + 2)]);
        let v331_3: Space = intersect(&(*CONSTANT_12),&(v331_2));
        drop(v331_2);
        let v331_4: Space = if has_head(&(v331_3)) { singleton(&[]) } else { Space::new() };
        drop(v331_3);
        let v331_7: Space = if (&(v331_4)).is_empty() { Space::new() } else {
          let v332_5: Path = concat_path(&(v330_5),&v328_7_cursor.path()[(v328_7_origin + 1)..(v328_7_origin + 2)]);
          let v332_6: Space = routine_37(c, &(v332_5), &v328_7_cursor, &(*s1), &(*s2), &(*s3));
          drop(v332_5);
          compose(&(v331_4),&(v332_6))
        };
        drop(v331_4);
        join_wrapped_into(&mut v330_6_write,&((v331_7).read_zipper()),&[]);
        }
        v328_7_cursor.ascend(1);
      }
      drop(v330_6_write);
      drop(v330_5);
      compose(&(v329_4),&(v330_6))
    };
    drop(v329_4);
    join_wrapped_into(&mut v328_7_write,&((v329_7).read_zipper()),&[]);
    }
    v328_7_cursor.ascend(1);
  }
  drop(v328_7_cursor);
  drop(v328_7_write);
  (v328_7).clone()
}

fn routine_36(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let mut v333_6 = Space::new();
  let mut v333_6_write = v333_6.write_zipper();
  let mut v333_6_cursor = (*s0).read_zipper();
  let v333_6_origin = v333_6_cursor.path().len();
  for v333_6_byte in v333_6_cursor.child_mask().iter() {
    v333_6_cursor.descend_to_existing_byte(v333_6_byte);
    {
    let v334_2: Space = singleton(&v333_6_cursor.path()[v333_6_origin..(v333_6_origin + 1)]);
    let v334_3: Space = intersect(&(*CONSTANT_12),&(v334_2));
    drop(v334_2);
    let v334_4: Space = if has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
    drop(v334_3);
    let v334_22: Space = if (&(v334_4)).is_empty() { Space::new() } else {
      let v335_5: Path = concat_path(&(*p0),&v333_6_cursor.path()[v333_6_origin..(v333_6_origin + 1)]);
      let v335_6: Space = singleton(&(v335_5));
      let v335_7: Space = routine_38(c, &(*s1), &(*s3), &((v335_6).read_zipper()));
      let v335_8: Space = routine_38(c, &(*s2), &(*s3), &((v335_6).read_zipper()));
      let v335_9: Space = intersect(&(v335_7),&(v335_8));
      let v335_10: Space = subtract(&(v335_9),&(v335_6));
      drop(v335_6);
      let v335_11: Space = wrap(&(v335_10),&(v335_5));
      drop(v335_5);
      let v335_12: Space = subtract(&(*s3),&(v335_8));
      let v335_13: Space = subtract(&(v335_12),&(v335_7));
      let v335_14: Space = routine_39(c, &(*s2), &(*s1), &((v335_13).read_zipper()));
      let v335_15: Space = unite(&(v335_11),&(v335_14));
      let v335_16: Space = subtract(&(v335_7),&(v335_8));
      let v335_17: Space = routine_39(c, &(*s2), &(*s1), &((v335_16).read_zipper()));
      let v335_18: Space = unite(&(v335_15),&(v335_17));
      let v335_19: Space = subtract(&(v335_8),&(v335_7));
      let v335_20: Space = routine_39(c, &(*s2), &(*s1), &((v335_19).read_zipper()));
      let v335_21: Space = unite(&(v335_18),&(v335_20));
      compose(&(v334_4),&(v335_21))
    };
    drop(v334_4);
    join_wrapped_into(&mut v333_6_write,&((v334_22).read_zipper()),&[]);
    }
    v333_6_cursor.ascend(1);
  }
  drop(v333_6_cursor);
  drop(v333_6_write);
  (v333_6).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let (mut v336_24,mut v336_43,mut v336_44,mut v336_45,mut v336_46,mut v336_5,mut v336_65,mut v336_66,mut v336_85,) = native_block_1(c, p0, s1, s2, s3);
  let (mut v336_163,mut v336_164,mut v336_183,mut v336_202,mut v336_203,mut v336_204,mut v336_280,mut v336_281,mut v336_300,mut v336_86,mut v336_87,) = native_block_4(c, s1, s2, s3, &v336_46, &v336_5, &v336_66, &v336_85);
  let mut v336_319: Space = (v336_5).clone();
  loop {
    let v613_1: Space = intersect(&(v336_319),&(*s3));
    let v613_2: Space = restrict_to(&(*s1),&(v613_1));
    drop(v613_1);
    let mut v613_3 = Space::new();
    let mut v613_3_write = v613_3.write_zipper();
    let mut v613_3_cursor = (v613_2).read_zipper();
    let v613_3_origin = v613_3_cursor.path().len();
    for v613_3_byte in v613_3_cursor.child_mask().iter() {
      v613_3_cursor.descend_to_existing_byte(v613_3_byte);
      {
      let v614_2: Space = singleton(&v613_3_cursor.path()[v613_3_origin..(v613_3_origin + 1)]);
      let v614_3: Space = intersect(&(*CONSTANT_12),&(v614_2));
      let v614_4: Space = if has_head(&(v614_3)) { singleton(&[]) } else { Space::new() };
      drop(v614_3);
      let v614_5: Space = subtract(&(*CONSTANT_0),&(v614_4));
      drop(v614_4);
      let v614_7: Space = if (&(v614_5)).is_empty() { Space::new() } else {
        let mut v615_6 = Space::new();
        let mut v615_6_write = v615_6.write_zipper();
        for v615_6_byte in v613_3_cursor.child_mask().iter() {
          v613_3_cursor.descend_to_existing_byte(v615_6_byte);
          {
          let v616_2: Space = singleton(&v613_3_cursor.path()[(v613_3_origin + 1)..(v613_3_origin + 2)]);
          let v616_3: Space = intersect(&(*CONSTANT_12),&(v616_2));
          let v616_4: Space = if has_head(&(v616_3)) { singleton(&[]) } else { Space::new() };
          drop(v616_3);
          let v616_5: Space = subtract(&(*CONSTANT_0),&(v616_4));
          drop(v616_4);
          let v616_8: Space = if (&(v616_5)).is_empty() { Space::new() } else {
            let mut v617_7 = Space::new();
            let mut v617_7_write = v617_7.write_zipper();
            for v617_7_byte in v613_3_cursor.child_mask().iter() {
              v613_3_cursor.descend_to_existing_byte(v617_7_byte);
              {
              let v618_2: Space = singleton(&v613_3_cursor.path()[(v613_3_origin + 2)..(v613_3_origin + 3)]);
              let v618_3: Space = intersect(&(*CONSTANT_12),&(v618_2));
              let v618_4: Space = if has_head(&(v618_3)) { singleton(&[]) } else { Space::new() };
              drop(v618_3);
              let v618_5: Space = subtract(&(*CONSTANT_0),&(v618_4));
              drop(v618_4);
              let v618_8: Space = if (&(v618_5)).is_empty() { Space::new() } else {
                let v619_7: Space = routine_41(c, &v613_3_cursor.path()[v613_3_origin..(v613_3_origin + 3)], &v613_3_cursor);
                compose(&(v618_5),&(v619_7))
              };
              drop(v618_5);
              let v618_9: Space = intersect(&(*CONSTANT_12),&(v618_2));
              drop(v618_2);
              let v618_10: Space = if has_head(&(v618_9)) { singleton(&[]) } else { Space::new() };
              drop(v618_9);
              let v618_12: Space = if (&(v618_10)).is_empty() { Space::new() } else {
                let v620_11: Space = routine_42(c, &v613_3_cursor.path()[v613_3_origin..(v613_3_origin + 3)], &v613_3_cursor);
                compose(&(v618_10),&(v620_11))
              };
              drop(v618_10);
              let v618_13: Space = unite(&(v618_8),&(v618_12));
              join_wrapped_into(&mut v617_7_write,&((v618_13).read_zipper()),&[]);
              }
              v613_3_cursor.ascend(1);
            }
            drop(v617_7_write);
            compose(&(v616_5),&(v617_7))
          };
          drop(v616_5);
          let v616_9: Space = intersect(&(*CONSTANT_12),&(v616_2));
          drop(v616_2);
          let v616_10: Space = if has_head(&(v616_9)) { singleton(&[]) } else { Space::new() };
          drop(v616_9);
          let v616_12: Space = if (&(v616_10)).is_empty() { Space::new() } else {
            let mut v621_11 = Space::new();
            let mut v621_11_write = v621_11.write_zipper();
            for v621_11_byte in v613_3_cursor.child_mask().iter() {
              v613_3_cursor.descend_to_existing_byte(v621_11_byte);
              {
              let v622_2: Space = singleton(&v613_3_cursor.path()[(v613_3_origin + 2)..(v613_3_origin + 3)]);
              let v622_3: Space = intersect(&(*CONSTANT_12),&(v622_2));
              let v622_4: Space = if has_head(&(v622_3)) { singleton(&[]) } else { Space::new() };
              drop(v622_3);
              let v622_5: Space = subtract(&(*CONSTANT_0),&(v622_4));
              drop(v622_4);
              let v622_8: Space = if (&(v622_5)).is_empty() { Space::new() } else {
                let v623_7: Space = routine_41(c, &v613_3_cursor.path()[v613_3_origin..(v613_3_origin + 3)], &v613_3_cursor);
                compose(&(v622_5),&(v623_7))
              };
              drop(v622_5);
              let v622_9: Space = intersect(&(*CONSTANT_12),&(v622_2));
              drop(v622_2);
              let v622_10: Space = if has_head(&(v622_9)) { singleton(&[]) } else { Space::new() };
              drop(v622_9);
              let v622_12: Space = if (&(v622_10)).is_empty() { Space::new() } else {
                let v624_11: Space = routine_43(c, &v613_3_cursor.path()[v613_3_origin..(v613_3_origin + 3)], &v613_3_cursor);
                compose(&(v622_10),&(v624_11))
              };
              drop(v622_10);
              let v622_13: Space = unite(&(v622_8),&(v622_12));
              join_wrapped_into(&mut v621_11_write,&((v622_13).read_zipper()),&[]);
              }
              v613_3_cursor.ascend(1);
            }
            drop(v621_11_write);
            compose(&(v616_10),&(v621_11))
          };
          drop(v616_10);
          let v616_13: Space = unite(&(v616_8),&(v616_12));
          join_wrapped_into(&mut v615_6_write,&((v616_13).read_zipper()),&[]);
          }
          v613_3_cursor.ascend(1);
        }
        drop(v615_6_write);
        compose(&(v614_5),&(v615_6))
      };
      drop(v614_5);
      let v614_8: Space = intersect(&(*CONSTANT_12),&(v614_2));
      drop(v614_2);
      let v614_9: Space = if has_head(&(v614_8)) { singleton(&[]) } else { Space::new() };
      drop(v614_8);
      let v614_11: Space = if (&(v614_9)).is_empty() { Space::new() } else {
        let mut v625_10 = Space::new();
        let mut v625_10_write = v625_10.write_zipper();
        for v625_10_byte in v613_3_cursor.child_mask().iter() {
          v613_3_cursor.descend_to_existing_byte(v625_10_byte);
          {
          let v626_2: Space = singleton(&v613_3_cursor.path()[(v613_3_origin + 1)..(v613_3_origin + 2)]);
          let v626_3: Space = intersect(&(*CONSTANT_12),&(v626_2));
          let v626_4: Space = if has_head(&(v626_3)) { singleton(&[]) } else { Space::new() };
          drop(v626_3);
          let v626_5: Space = subtract(&(*CONSTANT_0),&(v626_4));
          drop(v626_4);
          let v626_8: Space = if (&(v626_5)).is_empty() { Space::new() } else {
            let mut v627_7 = Space::new();
            let mut v627_7_write = v627_7.write_zipper();
            for v627_7_byte in v613_3_cursor.child_mask().iter() {
              v613_3_cursor.descend_to_existing_byte(v627_7_byte);
              {
              let v628_2: Space = singleton(&v613_3_cursor.path()[(v613_3_origin + 2)..(v613_3_origin + 3)]);
              let v628_3: Space = intersect(&(*CONSTANT_12),&(v628_2));
              let v628_4: Space = if has_head(&(v628_3)) { singleton(&[]) } else { Space::new() };
              drop(v628_3);
              let v628_5: Space = subtract(&(*CONSTANT_0),&(v628_4));
              drop(v628_4);
              let v628_8: Space = if (&(v628_5)).is_empty() { Space::new() } else {
                let v629_7: Space = routine_41(c, &v613_3_cursor.path()[v613_3_origin..(v613_3_origin + 3)], &v613_3_cursor);
                compose(&(v628_5),&(v629_7))
              };
              drop(v628_5);
              let v628_9: Space = intersect(&(*CONSTANT_12),&(v628_2));
              drop(v628_2);
              let v628_10: Space = if has_head(&(v628_9)) { singleton(&[]) } else { Space::new() };
              drop(v628_9);
              let v628_12: Space = if (&(v628_10)).is_empty() { Space::new() } else {
                let v630_11: Space = routine_42(c, &v613_3_cursor.path()[v613_3_origin..(v613_3_origin + 3)], &v613_3_cursor);
                compose(&(v628_10),&(v630_11))
              };
              drop(v628_10);
              let v628_13: Space = unite(&(v628_8),&(v628_12));
              join_wrapped_into(&mut v627_7_write,&((v628_13).read_zipper()),&[]);
              }
              v613_3_cursor.ascend(1);
            }
            drop(v627_7_write);
            compose(&(v626_5),&(v627_7))
          };
          drop(v626_5);
          let v626_9: Space = intersect(&(*CONSTANT_12),&(v626_2));
          drop(v626_2);
          let v626_10: Space = if has_head(&(v626_9)) { singleton(&[]) } else { Space::new() };
          drop(v626_9);
          let v626_11: Space = compose(&(v626_10),&v613_3_cursor);
          drop(v626_10);
          let v626_12: Space = unite(&(v626_8),&(v626_11));
          drop(v626_11);
          join_wrapped_into(&mut v625_10_write,&((v626_12).read_zipper()),&[]);
          }
          v613_3_cursor.ascend(1);
        }
        drop(v625_10_write);
        compose(&(v614_9),&(v625_10))
      };
      drop(v614_9);
      let v614_12: Space = unite(&(v614_7),&(v614_11));
      join_wrapped_into(&mut v613_3_write,&((v614_12).read_zipper()),&[]);
      }
      v613_3_cursor.ascend(1);
    }
    drop(v613_3_cursor);
    drop(v613_3_write);
    drop(v613_2);
    let v613_4: Space = unite(&(v613_3),&(v336_319));
    let v613_5: Space = intersect(&(v613_4),&(*s3));
    if !v336_319.join_into((v613_5).clone()).is_element() { break; }
  }
  let v336_320: Space = subtract(&(v336_300),&(v336_319));
  let v336_321: Space = routine_11(c, &((v336_320).read_zipper()));
  let mut v336_397 = Space::new();
  let mut v336_397_write = v336_397.write_zipper();
  let mut v336_397_cursor = (v336_321).read_zipper();
  let v336_397_origin = v336_397_cursor.path().len();
  for v336_397_byte in v336_397_cursor.child_mask().iter() {
    v336_397_cursor.descend_to_existing_byte(v336_397_byte);
    {
    let (mut v631_10,mut v631_17,) = native_block_5(c, s1, s2, s3, &v336_397_cursor, v336_397_origin, &v336_5);
    let v631_18: Space = unite(&(v631_10),&(v631_17));
    join_wrapped_into(&mut v336_397_write,&((v631_18).read_zipper()),&[]);
    }
    v336_397_cursor.ascend(1);
  }
  drop(v336_397_cursor);
  drop(v336_397_write);
  drop(v336_5);
  let v336_398: Space = unite(&(v336_281),&(v336_397));
  (v336_398).clone()
}

fn routine_38(c: &mut Context, s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>) -> Space {
  let v706_3: Space = intersect(&(*s1),&(*s2));
  let v706_4: Space = restrict_to(&(*s0),&(v706_3));
  drop(v706_3);
  let mut v706_23 = Space::new();
  let mut v706_23_write = v706_23.write_zipper();
  let mut v706_23_cursor = (v706_4).read_zipper();
  let v706_23_origin = v706_23_cursor.path().len();
  for v706_23_byte in v706_23_cursor.child_mask().iter() {
    v706_23_cursor.descend_to_existing_byte(v706_23_byte);
    {
    let v707_2: Space = singleton(&v706_23_cursor.path()[v706_23_origin..(v706_23_origin + 1)]);
    let v707_3: Space = intersect(&(*CONSTANT_12),&(v707_2));
    let v707_4: Space = if has_head(&(v707_3)) { singleton(&[]) } else { Space::new() };
    drop(v707_3);
    let v707_5: Space = subtract(&(*CONSTANT_0),&(v707_4));
    drop(v707_4);
    let v707_7: Space = if (&(v707_5)).is_empty() { Space::new() } else {
      let mut v708_6 = Space::new();
      let mut v708_6_write = v708_6.write_zipper();
      for v708_6_byte in v706_23_cursor.child_mask().iter() {
        v706_23_cursor.descend_to_existing_byte(v708_6_byte);
        {
        let v709_2: Space = singleton(&v706_23_cursor.path()[(v706_23_origin + 1)..(v706_23_origin + 2)]);
        let v709_3: Space = intersect(&(*CONSTANT_12),&(v709_2));
        let v709_4: Space = if has_head(&(v709_3)) { singleton(&[]) } else { Space::new() };
        drop(v709_3);
        let v709_5: Space = subtract(&(*CONSTANT_0),&(v709_4));
        drop(v709_4);
        let v709_8: Space = if (&(v709_5)).is_empty() { Space::new() } else {
          let mut v710_7 = Space::new();
          let mut v710_7_write = v710_7.write_zipper();
          for v710_7_byte in v706_23_cursor.child_mask().iter() {
            v706_23_cursor.descend_to_existing_byte(v710_7_byte);
            {
            let v711_2: Space = singleton(&v706_23_cursor.path()[(v706_23_origin + 2)..(v706_23_origin + 3)]);
            let v711_3: Space = intersect(&(*CONSTANT_12),&(v711_2));
            let v711_4: Space = if has_head(&(v711_3)) { singleton(&[]) } else { Space::new() };
            drop(v711_3);
            let v711_5: Space = subtract(&(*CONSTANT_0),&(v711_4));
            drop(v711_4);
            let v711_8: Space = if (&(v711_5)).is_empty() { Space::new() } else {
              let v712_7: Space = routine_41(c, &v706_23_cursor.path()[v706_23_origin..(v706_23_origin + 3)], &v706_23_cursor);
              compose(&(v711_5),&(v712_7))
            };
            drop(v711_5);
            let v711_9: Space = intersect(&(*CONSTANT_12),&(v711_2));
            drop(v711_2);
            let v711_10: Space = if has_head(&(v711_9)) { singleton(&[]) } else { Space::new() };
            drop(v711_9);
            let v711_12: Space = if (&(v711_10)).is_empty() { Space::new() } else {
              let v713_11: Space = routine_42(c, &v706_23_cursor.path()[v706_23_origin..(v706_23_origin + 3)], &v706_23_cursor);
              compose(&(v711_10),&(v713_11))
            };
            drop(v711_10);
            let v711_13: Space = unite(&(v711_8),&(v711_12));
            join_wrapped_into(&mut v710_7_write,&((v711_13).read_zipper()),&[]);
            }
            v706_23_cursor.ascend(1);
          }
          drop(v710_7_write);
          compose(&(v709_5),&(v710_7))
        };
        drop(v709_5);
        let v709_9: Space = intersect(&(*CONSTANT_12),&(v709_2));
        drop(v709_2);
        let v709_10: Space = if has_head(&(v709_9)) { singleton(&[]) } else { Space::new() };
        drop(v709_9);
        let v709_12: Space = if (&(v709_10)).is_empty() { Space::new() } else {
          let mut v714_11 = Space::new();
          let mut v714_11_write = v714_11.write_zipper();
          for v714_11_byte in v706_23_cursor.child_mask().iter() {
            v706_23_cursor.descend_to_existing_byte(v714_11_byte);
            {
            let v715_2: Space = singleton(&v706_23_cursor.path()[(v706_23_origin + 2)..(v706_23_origin + 3)]);
            let v715_3: Space = intersect(&(*CONSTANT_12),&(v715_2));
            let v715_4: Space = if has_head(&(v715_3)) { singleton(&[]) } else { Space::new() };
            drop(v715_3);
            let v715_5: Space = subtract(&(*CONSTANT_0),&(v715_4));
            drop(v715_4);
            let v715_8: Space = if (&(v715_5)).is_empty() { Space::new() } else {
              let v716_7: Space = routine_41(c, &v706_23_cursor.path()[v706_23_origin..(v706_23_origin + 3)], &v706_23_cursor);
              compose(&(v715_5),&(v716_7))
            };
            drop(v715_5);
            let v715_9: Space = intersect(&(*CONSTANT_12),&(v715_2));
            drop(v715_2);
            let v715_10: Space = if has_head(&(v715_9)) { singleton(&[]) } else { Space::new() };
            drop(v715_9);
            let v715_12: Space = if (&(v715_10)).is_empty() { Space::new() } else {
              let v717_11: Space = routine_43(c, &v706_23_cursor.path()[v706_23_origin..(v706_23_origin + 3)], &v706_23_cursor);
              compose(&(v715_10),&(v717_11))
            };
            drop(v715_10);
            let v715_13: Space = unite(&(v715_8),&(v715_12));
            join_wrapped_into(&mut v714_11_write,&((v715_13).read_zipper()),&[]);
            }
            v706_23_cursor.ascend(1);
          }
          drop(v714_11_write);
          compose(&(v709_10),&(v714_11))
        };
        drop(v709_10);
        let v709_13: Space = unite(&(v709_8),&(v709_12));
        join_wrapped_into(&mut v708_6_write,&((v709_13).read_zipper()),&[]);
        }
        v706_23_cursor.ascend(1);
      }
      drop(v708_6_write);
      compose(&(v707_5),&(v708_6))
    };
    drop(v707_5);
    let v707_8: Space = intersect(&(*CONSTANT_12),&(v707_2));
    drop(v707_2);
    let v707_9: Space = if has_head(&(v707_8)) { singleton(&[]) } else { Space::new() };
    drop(v707_8);
    let v707_11: Space = if (&(v707_9)).is_empty() { Space::new() } else {
      let mut v718_10 = Space::new();
      let mut v718_10_write = v718_10.write_zipper();
      for v718_10_byte in v706_23_cursor.child_mask().iter() {
        v706_23_cursor.descend_to_existing_byte(v718_10_byte);
        {
        let v719_2: Space = singleton(&v706_23_cursor.path()[(v706_23_origin + 1)..(v706_23_origin + 2)]);
        let v719_3: Space = intersect(&(*CONSTANT_12),&(v719_2));
        let v719_4: Space = if has_head(&(v719_3)) { singleton(&[]) } else { Space::new() };
        drop(v719_3);
        let v719_5: Space = subtract(&(*CONSTANT_0),&(v719_4));
        drop(v719_4);
        let v719_8: Space = if (&(v719_5)).is_empty() { Space::new() } else {
          let mut v720_7 = Space::new();
          let mut v720_7_write = v720_7.write_zipper();
          for v720_7_byte in v706_23_cursor.child_mask().iter() {
            v706_23_cursor.descend_to_existing_byte(v720_7_byte);
            {
            let v721_2: Space = singleton(&v706_23_cursor.path()[(v706_23_origin + 2)..(v706_23_origin + 3)]);
            let v721_3: Space = intersect(&(*CONSTANT_12),&(v721_2));
            let v721_4: Space = if has_head(&(v721_3)) { singleton(&[]) } else { Space::new() };
            drop(v721_3);
            let v721_5: Space = subtract(&(*CONSTANT_0),&(v721_4));
            drop(v721_4);
            let v721_8: Space = if (&(v721_5)).is_empty() { Space::new() } else {
              let v722_7: Space = routine_41(c, &v706_23_cursor.path()[v706_23_origin..(v706_23_origin + 3)], &v706_23_cursor);
              compose(&(v721_5),&(v722_7))
            };
            drop(v721_5);
            let v721_9: Space = intersect(&(*CONSTANT_12),&(v721_2));
            drop(v721_2);
            let v721_10: Space = if has_head(&(v721_9)) { singleton(&[]) } else { Space::new() };
            drop(v721_9);
            let v721_12: Space = if (&(v721_10)).is_empty() { Space::new() } else {
              let v723_11: Space = routine_42(c, &v706_23_cursor.path()[v706_23_origin..(v706_23_origin + 3)], &v706_23_cursor);
              compose(&(v721_10),&(v723_11))
            };
            drop(v721_10);
            let v721_13: Space = unite(&(v721_8),&(v721_12));
            join_wrapped_into(&mut v720_7_write,&((v721_13).read_zipper()),&[]);
            }
            v706_23_cursor.ascend(1);
          }
          drop(v720_7_write);
          compose(&(v719_5),&(v720_7))
        };
        drop(v719_5);
        let v719_9: Space = intersect(&(*CONSTANT_12),&(v719_2));
        drop(v719_2);
        let v719_10: Space = if has_head(&(v719_9)) { singleton(&[]) } else { Space::new() };
        drop(v719_9);
        let v719_11: Space = compose(&(v719_10),&v706_23_cursor);
        drop(v719_10);
        let v719_12: Space = unite(&(v719_8),&(v719_11));
        drop(v719_11);
        join_wrapped_into(&mut v718_10_write,&((v719_12).read_zipper()),&[]);
        }
        v706_23_cursor.ascend(1);
      }
      drop(v718_10_write);
      compose(&(v707_9),&(v718_10))
    };
    drop(v707_9);
    let v707_12: Space = unite(&(v707_7),&(v707_11));
    join_wrapped_into(&mut v706_23_write,&((v707_12).read_zipper()),&[]);
    }
    v706_23_cursor.ascend(1);
  }
  drop(v706_23_cursor);
  drop(v706_23_write);
  drop(v706_4);
  let v706_24: Space = unite(&(v706_23),&(*s2));
  let v706_25: Space = intersect(&(v706_24),&(*s1));
  let mut v706_44: Space = (v706_25).clone();
  loop {
    let v724_1: Space = intersect(&(v706_44),&(*s1));
    let v724_2: Space = restrict_to(&(*s0),&(v724_1));
    drop(v724_1);
    let mut v724_3 = Space::new();
    let mut v724_3_write = v724_3.write_zipper();
    let mut v724_3_cursor = (v724_2).read_zipper();
    let v724_3_origin = v724_3_cursor.path().len();
    for v724_3_byte in v724_3_cursor.child_mask().iter() {
      v724_3_cursor.descend_to_existing_byte(v724_3_byte);
      {
      let v725_2: Space = singleton(&v724_3_cursor.path()[v724_3_origin..(v724_3_origin + 1)]);
      let v725_3: Space = intersect(&(*CONSTANT_12),&(v725_2));
      let v725_4: Space = if has_head(&(v725_3)) { singleton(&[]) } else { Space::new() };
      drop(v725_3);
      let v725_5: Space = subtract(&(*CONSTANT_0),&(v725_4));
      drop(v725_4);
      let v725_7: Space = if (&(v725_5)).is_empty() { Space::new() } else {
        let mut v726_6 = Space::new();
        let mut v726_6_write = v726_6.write_zipper();
        for v726_6_byte in v724_3_cursor.child_mask().iter() {
          v724_3_cursor.descend_to_existing_byte(v726_6_byte);
          {
          let v727_2: Space = singleton(&v724_3_cursor.path()[(v724_3_origin + 1)..(v724_3_origin + 2)]);
          let v727_3: Space = intersect(&(*CONSTANT_12),&(v727_2));
          let v727_4: Space = if has_head(&(v727_3)) { singleton(&[]) } else { Space::new() };
          drop(v727_3);
          let v727_5: Space = subtract(&(*CONSTANT_0),&(v727_4));
          drop(v727_4);
          let v727_8: Space = if (&(v727_5)).is_empty() { Space::new() } else {
            let mut v728_7 = Space::new();
            let mut v728_7_write = v728_7.write_zipper();
            for v728_7_byte in v724_3_cursor.child_mask().iter() {
              v724_3_cursor.descend_to_existing_byte(v728_7_byte);
              {
              let v729_2: Space = singleton(&v724_3_cursor.path()[(v724_3_origin + 2)..(v724_3_origin + 3)]);
              let v729_3: Space = intersect(&(*CONSTANT_12),&(v729_2));
              let v729_4: Space = if has_head(&(v729_3)) { singleton(&[]) } else { Space::new() };
              drop(v729_3);
              let v729_5: Space = subtract(&(*CONSTANT_0),&(v729_4));
              drop(v729_4);
              let v729_8: Space = if (&(v729_5)).is_empty() { Space::new() } else {
                let v730_7: Space = routine_41(c, &v724_3_cursor.path()[v724_3_origin..(v724_3_origin + 3)], &v724_3_cursor);
                compose(&(v729_5),&(v730_7))
              };
              drop(v729_5);
              let v729_9: Space = intersect(&(*CONSTANT_12),&(v729_2));
              drop(v729_2);
              let v729_10: Space = if has_head(&(v729_9)) { singleton(&[]) } else { Space::new() };
              drop(v729_9);
              let v729_12: Space = if (&(v729_10)).is_empty() { Space::new() } else {
                let v731_11: Space = routine_42(c, &v724_3_cursor.path()[v724_3_origin..(v724_3_origin + 3)], &v724_3_cursor);
                compose(&(v729_10),&(v731_11))
              };
              drop(v729_10);
              let v729_13: Space = unite(&(v729_8),&(v729_12));
              join_wrapped_into(&mut v728_7_write,&((v729_13).read_zipper()),&[]);
              }
              v724_3_cursor.ascend(1);
            }
            drop(v728_7_write);
            compose(&(v727_5),&(v728_7))
          };
          drop(v727_5);
          let v727_9: Space = intersect(&(*CONSTANT_12),&(v727_2));
          drop(v727_2);
          let v727_10: Space = if has_head(&(v727_9)) { singleton(&[]) } else { Space::new() };
          drop(v727_9);
          let v727_12: Space = if (&(v727_10)).is_empty() { Space::new() } else {
            let mut v732_11 = Space::new();
            let mut v732_11_write = v732_11.write_zipper();
            for v732_11_byte in v724_3_cursor.child_mask().iter() {
              v724_3_cursor.descend_to_existing_byte(v732_11_byte);
              {
              let v733_2: Space = singleton(&v724_3_cursor.path()[(v724_3_origin + 2)..(v724_3_origin + 3)]);
              let v733_3: Space = intersect(&(*CONSTANT_12),&(v733_2));
              let v733_4: Space = if has_head(&(v733_3)) { singleton(&[]) } else { Space::new() };
              drop(v733_3);
              let v733_5: Space = subtract(&(*CONSTANT_0),&(v733_4));
              drop(v733_4);
              let v733_8: Space = if (&(v733_5)).is_empty() { Space::new() } else {
                let v734_7: Space = routine_41(c, &v724_3_cursor.path()[v724_3_origin..(v724_3_origin + 3)], &v724_3_cursor);
                compose(&(v733_5),&(v734_7))
              };
              drop(v733_5);
              let v733_9: Space = intersect(&(*CONSTANT_12),&(v733_2));
              drop(v733_2);
              let v733_10: Space = if has_head(&(v733_9)) { singleton(&[]) } else { Space::new() };
              drop(v733_9);
              let v733_12: Space = if (&(v733_10)).is_empty() { Space::new() } else {
                let v735_11: Space = routine_43(c, &v724_3_cursor.path()[v724_3_origin..(v724_3_origin + 3)], &v724_3_cursor);
                compose(&(v733_10),&(v735_11))
              };
              drop(v733_10);
              let v733_13: Space = unite(&(v733_8),&(v733_12));
              join_wrapped_into(&mut v732_11_write,&((v733_13).read_zipper()),&[]);
              }
              v724_3_cursor.ascend(1);
            }
            drop(v732_11_write);
            compose(&(v727_10),&(v732_11))
          };
          drop(v727_10);
          let v727_13: Space = unite(&(v727_8),&(v727_12));
          join_wrapped_into(&mut v726_6_write,&((v727_13).read_zipper()),&[]);
          }
          v724_3_cursor.ascend(1);
        }
        drop(v726_6_write);
        compose(&(v725_5),&(v726_6))
      };
      drop(v725_5);
      let v725_8: Space = intersect(&(*CONSTANT_12),&(v725_2));
      drop(v725_2);
      let v725_9: Space = if has_head(&(v725_8)) { singleton(&[]) } else { Space::new() };
      drop(v725_8);
      let v725_11: Space = if (&(v725_9)).is_empty() { Space::new() } else {
        let mut v736_10 = Space::new();
        let mut v736_10_write = v736_10.write_zipper();
        for v736_10_byte in v724_3_cursor.child_mask().iter() {
          v724_3_cursor.descend_to_existing_byte(v736_10_byte);
          {
          let v737_2: Space = singleton(&v724_3_cursor.path()[(v724_3_origin + 1)..(v724_3_origin + 2)]);
          let v737_3: Space = intersect(&(*CONSTANT_12),&(v737_2));
          let v737_4: Space = if has_head(&(v737_3)) { singleton(&[]) } else { Space::new() };
          drop(v737_3);
          let v737_5: Space = subtract(&(*CONSTANT_0),&(v737_4));
          drop(v737_4);
          let v737_8: Space = if (&(v737_5)).is_empty() { Space::new() } else {
            let mut v738_7 = Space::new();
            let mut v738_7_write = v738_7.write_zipper();
            for v738_7_byte in v724_3_cursor.child_mask().iter() {
              v724_3_cursor.descend_to_existing_byte(v738_7_byte);
              {
              let v739_2: Space = singleton(&v724_3_cursor.path()[(v724_3_origin + 2)..(v724_3_origin + 3)]);
              let v739_3: Space = intersect(&(*CONSTANT_12),&(v739_2));
              let v739_4: Space = if has_head(&(v739_3)) { singleton(&[]) } else { Space::new() };
              drop(v739_3);
              let v739_5: Space = subtract(&(*CONSTANT_0),&(v739_4));
              drop(v739_4);
              let v739_8: Space = if (&(v739_5)).is_empty() { Space::new() } else {
                let v740_7: Space = routine_41(c, &v724_3_cursor.path()[v724_3_origin..(v724_3_origin + 3)], &v724_3_cursor);
                compose(&(v739_5),&(v740_7))
              };
              drop(v739_5);
              let v739_9: Space = intersect(&(*CONSTANT_12),&(v739_2));
              drop(v739_2);
              let v739_10: Space = if has_head(&(v739_9)) { singleton(&[]) } else { Space::new() };
              drop(v739_9);
              let v739_12: Space = if (&(v739_10)).is_empty() { Space::new() } else {
                let v741_11: Space = routine_42(c, &v724_3_cursor.path()[v724_3_origin..(v724_3_origin + 3)], &v724_3_cursor);
                compose(&(v739_10),&(v741_11))
              };
              drop(v739_10);
              let v739_13: Space = unite(&(v739_8),&(v739_12));
              join_wrapped_into(&mut v738_7_write,&((v739_13).read_zipper()),&[]);
              }
              v724_3_cursor.ascend(1);
            }
            drop(v738_7_write);
            compose(&(v737_5),&(v738_7))
          };
          drop(v737_5);
          let v737_9: Space = intersect(&(*CONSTANT_12),&(v737_2));
          drop(v737_2);
          let v737_10: Space = if has_head(&(v737_9)) { singleton(&[]) } else { Space::new() };
          drop(v737_9);
          let v737_11: Space = compose(&(v737_10),&v724_3_cursor);
          drop(v737_10);
          let v737_12: Space = unite(&(v737_8),&(v737_11));
          drop(v737_11);
          join_wrapped_into(&mut v736_10_write,&((v737_12).read_zipper()),&[]);
          }
          v724_3_cursor.ascend(1);
        }
        drop(v736_10_write);
        compose(&(v725_9),&(v736_10))
      };
      drop(v725_9);
      let v725_12: Space = unite(&(v725_7),&(v725_11));
      join_wrapped_into(&mut v724_3_write,&((v725_12).read_zipper()),&[]);
      }
      v724_3_cursor.ascend(1);
    }
    drop(v724_3_cursor);
    drop(v724_3_write);
    drop(v724_2);
    let v724_4: Space = unite(&(v724_3),&(v706_44));
    let v724_5: Space = intersect(&(v724_4),&(*s1));
    if !v706_44.join_into((v724_5).clone()).is_element() { break; }
  }
  let v706_45: Space = unite(&(*s2),&(v706_44));
  (v706_45).clone()
}

fn routine_39(c: &mut Context, s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>) -> Space {
  let v742_3: Space = if has_head(&(*s2)) { singleton(&[]) } else { Space::new() };
  let v742_4: Space = first_matching(&(*s2),&(*CONSTANT_0),false);
  let v742_5: Space = unite(&(v742_3),&(v742_4));
  drop(v742_3);
  drop(v742_4);
  let v742_8: Space = if (&(v742_5)).is_empty() { Space::new() } else {
    let v743_6: Space = routine_26(c, &(*s2));
    let v743_7: Space = subtract(&(*s2),&(v743_6));
    compose(&(v742_5),&(v743_7))
  };
  drop(v742_5);
  let v742_9: Space = subtract(&(*s2),&(v742_8));
  let mut v742_19 = Space::new();
  let mut v742_19_write = v742_19.write_zipper();
  let mut v742_19_cursor = (v742_9).read_zipper();
  let v742_19_origin = v742_19_cursor.path().len();
  for v742_19_byte in v742_19_cursor.child_mask().iter() {
    v742_19_cursor.descend_to_existing_byte(v742_19_byte);
    {
    let v744_2: Space = singleton(&v742_19_cursor.path()[v742_19_origin..(v742_19_origin + 1)]);
    let v744_3: Space = intersect(&(*CONSTANT_12),&(v744_2));
    let v744_4: Space = if has_head(&(v744_3)) { singleton(&[]) } else { Space::new() };
    drop(v744_3);
    let v744_5: Space = subtract(&(*CONSTANT_0),&(v744_4));
    drop(v744_4);
    let v744_7: Space = if (&(v744_5)).is_empty() { Space::new() } else {
      let mut v745_6 = Space::new();
      let mut v745_6_write = v745_6.write_zipper();
      for v745_6_byte in v742_19_cursor.child_mask().iter() {
        v742_19_cursor.descend_to_existing_byte(v745_6_byte);
        {
        let v746_2: Space = singleton(&v742_19_cursor.path()[(v742_19_origin + 1)..(v742_19_origin + 2)]);
        let v746_3: Space = intersect(&(*CONSTANT_12),&(v746_2));
        let v746_4: Space = if has_head(&(v746_3)) { singleton(&[]) } else { Space::new() };
        drop(v746_3);
        let v746_5: Space = subtract(&(*CONSTANT_0),&(v746_4));
        drop(v746_4);
        let v746_8: Space = if (&(v746_5)).is_empty() { Space::new() } else {
          let v747_7: Space = routine_44(c, &v742_19_cursor.path()[v742_19_origin..(v742_19_origin + 2)], &v742_19_cursor, &(*s1), &(*s0), &(*s2));
          compose(&(v746_5),&(v747_7))
        };
        drop(v746_5);
        let v746_9: Space = intersect(&(*CONSTANT_12),&(v746_2));
        drop(v746_2);
        let v746_10: Space = if has_head(&(v746_9)) { singleton(&[]) } else { Space::new() };
        drop(v746_9);
        let v746_12: Space = if (&(v746_10)).is_empty() { Space::new() } else {
          let v748_11: Space = routine_45(c, &v742_19_cursor.path()[v742_19_origin..(v742_19_origin + 2)], &v742_19_cursor, &(*s1), &(*s0), &(*s2));
          compose(&(v746_10),&(v748_11))
        };
        drop(v746_10);
        let v746_13: Space = unite(&(v746_8),&(v746_12));
        join_wrapped_into(&mut v745_6_write,&((v746_13).read_zipper()),&[]);
        }
        v742_19_cursor.ascend(1);
      }
      drop(v745_6_write);
      compose(&(v744_5),&(v745_6))
    };
    drop(v744_5);
    let v744_8: Space = intersect(&(*CONSTANT_12),&(v744_2));
    drop(v744_2);
    let v744_9: Space = if has_head(&(v744_8)) { singleton(&[]) } else { Space::new() };
    drop(v744_8);
    let v744_11: Space = if (&(v744_9)).is_empty() { Space::new() } else {
      let mut v749_10 = Space::new();
      let mut v749_10_write = v749_10.write_zipper();
      for v749_10_byte in v742_19_cursor.child_mask().iter() {
        v742_19_cursor.descend_to_existing_byte(v749_10_byte);
        {
        let v750_2: Space = singleton(&v742_19_cursor.path()[(v742_19_origin + 1)..(v742_19_origin + 2)]);
        let v750_3: Space = intersect(&(*CONSTANT_12),&(v750_2));
        let v750_4: Space = if has_head(&(v750_3)) { singleton(&[]) } else { Space::new() };
        drop(v750_3);
        let v750_5: Space = subtract(&(*CONSTANT_0),&(v750_4));
        drop(v750_4);
        let v750_8: Space = if (&(v750_5)).is_empty() { Space::new() } else {
          let v751_7: Space = routine_44(c, &v742_19_cursor.path()[v742_19_origin..(v742_19_origin + 2)], &v742_19_cursor, &(*s1), &(*s0), &(*s2));
          compose(&(v750_5),&(v751_7))
        };
        drop(v750_5);
        let v750_9: Space = intersect(&(*CONSTANT_12),&(v750_2));
        drop(v750_2);
        let v750_10: Space = if has_head(&(v750_9)) { singleton(&[]) } else { Space::new() };
        drop(v750_9);
        let v750_12: Space = if (&(v750_10)).is_empty() { Space::new() } else {
          let v752_11: Space = routine_37(c, &v742_19_cursor.path()[v742_19_origin..(v742_19_origin + 2)], &v742_19_cursor, &(*s1), &(*s0), &(*s2));
          compose(&(v750_10),&(v752_11))
        };
        drop(v750_10);
        let v750_13: Space = unite(&(v750_8),&(v750_12));
        join_wrapped_into(&mut v749_10_write,&((v750_13).read_zipper()),&[]);
        }
        v742_19_cursor.ascend(1);
      }
      drop(v749_10_write);
      compose(&(v744_9),&(v749_10))
    };
    drop(v744_9);
    let v744_12: Space = unite(&(v744_7),&(v744_11));
    join_wrapped_into(&mut v742_19_write,&((v744_12).read_zipper()),&[]);
    }
    v742_19_cursor.ascend(1);
  }
  drop(v742_19_cursor);
  drop(v742_19_write);
  (v742_19).clone()
}

fn routine_40(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v753_4: Space = first_matching(&(descend_cursor((*s0).read_zipper(),&(*p0))),&(*CONSTANT_0),false);
  let v753_5: Space = intersect(&(*CONSTANT_0),&(v753_4));
  let v753_6: Space = if has_head(&(v753_4)) { singleton(&[]) } else { Space::new() };
  let v753_7: Space = unite(&(v753_5),&(v753_6));
  drop(v753_5);
  let v753_9: Space = compose(&(v753_7),&(*CONSTANT_0));
  drop(v753_7);
  let v753_11: Space = subtract(&(*CONSTANT_0),&(v753_4));
  drop(v753_4);
  let v753_12: Space = subtract(&(v753_11),&(v753_6));
  drop(v753_6);
  drop(v753_11);
  let v753_16: Space = if (&(v753_12)).is_empty() { Space::new() } else {
    let v754_14: Space = first_fibonacci(&(descend_cursor((*s0).read_zipper(),&(*p0))),6,5,true);
    let mut v754_15 = Space::new();
    let mut v754_15_write = v754_15.write_zipper();
    let v754_15_arg_0: &[u8] = &(*CONSTANT_14);
    let v754_15_arg_2: &Space = &(&(descend_cursor((*s0).read_zipper(),&(*p0)))).make_map();
    let mut v754_15_cursor = (v754_14).read_zipper();
    let v754_15_origin = v754_15_cursor.path().len();
    let mut v754_15_more = v754_15_cursor.is_val() || next_value_within(&mut v754_15_cursor,v754_15_origin);
    while v754_15_more {
      {
      let v754_15_depth = v754_15_cursor.path().len();
      let v755_3: Space = routine_40(c, &v754_15_cursor.path()[v754_15_origin..v754_15_depth], &((*v754_15_arg_2).read_zipper()));
      join_wrapped_into(&mut v754_15_write,&((v755_3).read_zipper()),&[]);
      }
      v754_15_more = next_value_within(&mut v754_15_cursor,v754_15_origin);
    }
    drop(v754_15_cursor);
    drop(v754_15_write);
    drop(v754_14);
    compose(&(v753_12),&(v754_15))
  };
  drop(v753_12);
  let v753_17: Space = unite(&(v753_9),&(v753_16));
  drop(v753_9);
  let v753_18: Space = wrap(&(v753_17),&(*p0));
  (v753_18).clone()
}

fn routine_41(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v756_4 = Space::new();
  let mut v756_4_write = v756_4.write_zipper();
  let mut v756_4_cursor = (*s0).read_zipper();
  let v756_4_origin = v756_4_cursor.path().len();
  for v756_4_byte in v756_4_cursor.child_mask().iter() {
    v756_4_cursor.descend_to_existing_byte(v756_4_byte);
    {
    let v757_2: Space = singleton(&v756_4_cursor.path()[v756_4_origin..(v756_4_origin + 1)]);
    let v757_3: Space = intersect(&(*CONSTANT_12),&(v757_2));
    drop(v757_2);
    let v757_4: Space = if has_head(&(v757_3)) { singleton(&[]) } else { Space::new() };
    drop(v757_3);
    let v757_6: Space = if (&(v757_4)).is_empty() { Space::new() } else {
      let mut v758_5 = Space::new();
      let mut v758_5_write = v758_5.write_zipper();
      for v758_5_byte in v756_4_cursor.child_mask().iter() {
        v756_4_cursor.descend_to_existing_byte(v758_5_byte);
        {
        let v759_2: Space = singleton(&v756_4_cursor.path()[(v756_4_origin + 1)..(v756_4_origin + 2)]);
        let v759_3: Space = intersect(&(*CONSTANT_12),&(v759_2));
        drop(v759_2);
        let v759_4: Space = if has_head(&(v759_3)) { singleton(&[]) } else { Space::new() };
        drop(v759_3);
        let v759_5: Space = compose(&(v759_4),&v756_4_cursor);
        drop(v759_4);
        join_wrapped_into(&mut v758_5_write,&((v759_5).read_zipper()),&[]);
        }
        v756_4_cursor.ascend(1);
      }
      drop(v758_5_write);
      compose(&(v757_4),&(v758_5))
    };
    drop(v757_4);
    join_wrapped_into(&mut v756_4_write,&((v757_6).read_zipper()),&[]);
    }
    v756_4_cursor.ascend(1);
  }
  drop(v756_4_cursor);
  drop(v756_4_write);
  (v756_4).clone()
}

fn routine_42(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v760_3 = Space::new();
  let mut v760_3_write = v760_3.write_zipper();
  let mut v760_3_cursor = (*s0).read_zipper();
  let v760_3_origin = v760_3_cursor.path().len();
  for v760_3_byte in v760_3_cursor.child_mask().iter() {
    v760_3_cursor.descend_to_existing_byte(v760_3_byte);
    {
    let v761_2: Space = singleton(&v760_3_cursor.path()[v760_3_origin..(v760_3_origin + 1)]);
    let v761_3: Space = intersect(&(*CONSTANT_12),&(v761_2));
    drop(v761_2);
    let v761_4: Space = if has_head(&(v761_3)) { singleton(&[]) } else { Space::new() };
    drop(v761_3);
    let v761_5: Space = compose(&(v761_4),&v760_3_cursor);
    drop(v761_4);
    join_wrapped_into(&mut v760_3_write,&((v761_5).read_zipper()),&[]);
    }
    v760_3_cursor.ascend(1);
  }
  drop(v760_3_cursor);
  drop(v760_3_write);
  (v760_3).clone()
}

fn routine_43(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_44(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let mut v763_10 = Space::new();
  let mut v763_10_write = v763_10.write_zipper();
  let mut v763_10_cursor = (*s0).read_zipper();
  let v763_10_origin = v763_10_cursor.path().len();
  for v763_10_byte in v763_10_cursor.child_mask().iter() {
    v763_10_cursor.descend_to_existing_byte(v763_10_byte);
    {
    let v764_2: Space = singleton(&v763_10_cursor.path()[v763_10_origin..(v763_10_origin + 1)]);
    let v764_3: Space = intersect(&(*CONSTANT_12),&(v764_2));
    let v764_4: Space = if has_head(&(v764_3)) { singleton(&[]) } else { Space::new() };
    drop(v764_3);
    let v764_5: Space = subtract(&(*CONSTANT_0),&(v764_4));
    drop(v764_4);
    let v764_8: Space = if (&(v764_5)).is_empty() { Space::new() } else {
      let v765_6: Path = concat_path(&(*p0),&v763_10_cursor.path()[v763_10_origin..(v763_10_origin + 1)]);
      let mut v765_7 = Space::new();
      let mut v765_7_write = v765_7.write_zipper();
      for v765_7_byte in v763_10_cursor.child_mask().iter() {
        v763_10_cursor.descend_to_existing_byte(v765_7_byte);
        {
        let v766_2: Space = singleton(&v763_10_cursor.path()[(v763_10_origin + 1)..(v763_10_origin + 2)]);
        let v766_3: Space = intersect(&(*CONSTANT_12),&(v766_2));
        drop(v766_2);
        let v766_4: Space = if has_head(&(v766_3)) { singleton(&[]) } else { Space::new() };
        drop(v766_3);
        let v766_7: Space = if (&(v766_4)).is_empty() { Space::new() } else {
          let v767_5: Path = concat_path(&(v765_6),&v763_10_cursor.path()[(v763_10_origin + 1)..(v763_10_origin + 2)]);
          let v767_6: Space = routine_46(c, &(v767_5), &v763_10_cursor, &(*s1), &(*s2), &(*s3));
          drop(v767_5);
          compose(&(v766_4),&(v767_6))
        };
        drop(v766_4);
        join_wrapped_into(&mut v765_7_write,&((v766_7).read_zipper()),&[]);
        }
        v763_10_cursor.ascend(1);
      }
      drop(v765_7_write);
      compose(&(v764_5),&(v765_7))
    };
    drop(v764_5);
    let v764_9: Space = intersect(&(*CONSTANT_12),&(v764_2));
    drop(v764_2);
    let v764_10: Space = if has_head(&(v764_9)) { singleton(&[]) } else { Space::new() };
    drop(v764_9);
    let v764_12: Space = if (&(v764_10)).is_empty() { Space::new() } else {
      let v768_6: Path = concat_path(&(*p0),&v763_10_cursor.path()[v763_10_origin..(v763_10_origin + 1)]);
      let mut v768_11 = Space::new();
      let mut v768_11_write = v768_11.write_zipper();
      for v768_11_byte in v763_10_cursor.child_mask().iter() {
        v763_10_cursor.descend_to_existing_byte(v768_11_byte);
        {
        let v769_2: Space = singleton(&v763_10_cursor.path()[(v763_10_origin + 1)..(v763_10_origin + 2)]);
        let v769_3: Space = intersect(&(*CONSTANT_12),&(v769_2));
        drop(v769_2);
        let v769_4: Space = if has_head(&(v769_3)) { singleton(&[]) } else { Space::new() };
        drop(v769_3);
        let v769_7: Space = if (&(v769_4)).is_empty() { Space::new() } else {
          let v770_5: Path = concat_path(&(v768_6),&v763_10_cursor.path()[(v763_10_origin + 1)..(v763_10_origin + 2)]);
          let v770_6: Space = routine_37(c, &(v770_5), &v763_10_cursor, &(*s1), &(*s2), &(*s3));
          drop(v770_5);
          compose(&(v769_4),&(v770_6))
        };
        drop(v769_4);
        join_wrapped_into(&mut v768_11_write,&((v769_7).read_zipper()),&[]);
        }
        v763_10_cursor.ascend(1);
      }
      drop(v768_11_write);
      drop(v768_6);
      compose(&(v764_10),&(v768_11))
    };
    drop(v764_10);
    let v764_13: Space = unite(&(v764_8),&(v764_12));
    join_wrapped_into(&mut v763_10_write,&((v764_13).read_zipper()),&[]);
    }
    v763_10_cursor.ascend(1);
  }
  drop(v763_10_cursor);
  drop(v763_10_write);
  (v763_10).clone()
}

fn routine_45(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let mut v771_9 = Space::new();
  let mut v771_9_write = v771_9.write_zipper();
  let mut v771_9_cursor = (*s0).read_zipper();
  let v771_9_origin = v771_9_cursor.path().len();
  for v771_9_byte in v771_9_cursor.child_mask().iter() {
    v771_9_cursor.descend_to_existing_byte(v771_9_byte);
    {
    let v772_2: Space = singleton(&v771_9_cursor.path()[v771_9_origin..(v771_9_origin + 1)]);
    let v772_3: Space = intersect(&(*CONSTANT_12),&(v772_2));
    let v772_4: Space = if has_head(&(v772_3)) { singleton(&[]) } else { Space::new() };
    drop(v772_3);
    let v772_5: Space = subtract(&(*CONSTANT_0),&(v772_4));
    drop(v772_4);
    let v772_8: Space = if (&(v772_5)).is_empty() { Space::new() } else {
      let v773_6: Path = concat_path(&(*p0),&v771_9_cursor.path()[v771_9_origin..(v771_9_origin + 1)]);
      let mut v773_7 = Space::new();
      let mut v773_7_write = v773_7.write_zipper();
      for v773_7_byte in v771_9_cursor.child_mask().iter() {
        v771_9_cursor.descend_to_existing_byte(v773_7_byte);
        {
        let v774_2: Space = singleton(&v771_9_cursor.path()[(v771_9_origin + 1)..(v771_9_origin + 2)]);
        let v774_3: Space = intersect(&(*CONSTANT_12),&(v774_2));
        drop(v774_2);
        let v774_4: Space = if has_head(&(v774_3)) { singleton(&[]) } else { Space::new() };
        drop(v774_3);
        let v774_7: Space = if (&(v774_4)).is_empty() { Space::new() } else {
          let v775_5: Path = concat_path(&(v773_6),&v771_9_cursor.path()[(v771_9_origin + 1)..(v771_9_origin + 2)]);
          let v775_6: Space = routine_46(c, &(v775_5), &v771_9_cursor, &(*s1), &(*s2), &(*s3));
          drop(v775_5);
          compose(&(v774_4),&(v775_6))
        };
        drop(v774_4);
        join_wrapped_into(&mut v773_7_write,&((v774_7).read_zipper()),&[]);
        }
        v771_9_cursor.ascend(1);
      }
      drop(v773_7_write);
      compose(&(v772_5),&(v773_7))
    };
    drop(v772_5);
    let v772_9: Space = intersect(&(*CONSTANT_12),&(v772_2));
    drop(v772_2);
    let v772_10: Space = if has_head(&(v772_9)) { singleton(&[]) } else { Space::new() };
    drop(v772_9);
    let v772_27: Space = if (&(v772_10)).is_empty() { Space::new() } else {
      let v776_6: Path = concat_path(&(*p0),&v771_9_cursor.path()[v771_9_origin..(v771_9_origin + 1)]);
      let v776_11: Space = singleton(&(v776_6));
      let v776_12: Space = routine_38(c, &(*s1), &(*s3), &((v776_11).read_zipper()));
      let v776_13: Space = routine_38(c, &(*s2), &(*s3), &((v776_11).read_zipper()));
      let v776_14: Space = intersect(&(v776_12),&(v776_13));
      let v776_15: Space = subtract(&(v776_14),&(v776_11));
      drop(v776_11);
      let v776_16: Space = wrap(&(v776_15),&(v776_6));
      drop(v776_6);
      let v776_17: Space = subtract(&(*s3),&(v776_13));
      let v776_18: Space = subtract(&(v776_17),&(v776_12));
      let v776_19: Space = routine_39(c, &(*s2), &(*s1), &((v776_18).read_zipper()));
      let v776_20: Space = unite(&(v776_16),&(v776_19));
      let v776_21: Space = subtract(&(v776_12),&(v776_13));
      let v776_22: Space = routine_39(c, &(*s2), &(*s1), &((v776_21).read_zipper()));
      let v776_23: Space = unite(&(v776_20),&(v776_22));
      let v776_24: Space = subtract(&(v776_13),&(v776_12));
      let v776_25: Space = routine_39(c, &(*s2), &(*s1), &((v776_24).read_zipper()));
      let v776_26: Space = unite(&(v776_23),&(v776_25));
      compose(&(v772_10),&(v776_26))
    };
    drop(v772_10);
    let v772_28: Space = unite(&(v772_8),&(v772_27));
    join_wrapped_into(&mut v771_9_write,&((v772_28).read_zipper()),&[]);
    }
    v771_9_cursor.ascend(1);
  }
  drop(v771_9_cursor);
  drop(v771_9_write);
  (v771_9).clone()
}

fn routine_46(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let mut v777_6 = Space::new();
  let mut v777_6_write = v777_6.write_zipper();
  let mut v777_6_cursor = (*s0).read_zipper();
  let v777_6_origin = v777_6_cursor.path().len();
  for v777_6_byte in v777_6_cursor.child_mask().iter() {
    v777_6_cursor.descend_to_existing_byte(v777_6_byte);
    {
    let v778_2: Space = singleton(&v777_6_cursor.path()[v777_6_origin..(v777_6_origin + 1)]);
    let v778_3: Space = intersect(&(*CONSTANT_12),&(v778_2));
    drop(v778_2);
    let v778_4: Space = if has_head(&(v778_3)) { singleton(&[]) } else { Space::new() };
    drop(v778_3);
    let v778_22: Space = if (&(v778_4)).is_empty() { Space::new() } else {
      let v779_5: Path = concat_path(&(*p0),&v777_6_cursor.path()[v777_6_origin..(v777_6_origin + 1)]);
      let v779_6: Space = singleton(&(v779_5));
      let v779_7: Space = routine_38(c, &(*s1), &(*s3), &((v779_6).read_zipper()));
      let v779_8: Space = routine_38(c, &(*s2), &(*s3), &((v779_6).read_zipper()));
      let v779_9: Space = intersect(&(v779_7),&(v779_8));
      let v779_10: Space = subtract(&(v779_9),&(v779_6));
      drop(v779_6);
      let v779_11: Space = wrap(&(v779_10),&(v779_5));
      drop(v779_5);
      let v779_12: Space = subtract(&(*s3),&(v779_8));
      let v779_13: Space = subtract(&(v779_12),&(v779_7));
      let v779_14: Space = routine_39(c, &(*s2), &(*s1), &((v779_13).read_zipper()));
      let v779_15: Space = unite(&(v779_11),&(v779_14));
      let v779_16: Space = subtract(&(v779_7),&(v779_8));
      let v779_17: Space = routine_39(c, &(*s2), &(*s1), &((v779_16).read_zipper()));
      let v779_18: Space = unite(&(v779_15),&(v779_17));
      let v779_19: Space = subtract(&(v779_8),&(v779_7));
      let v779_20: Space = routine_39(c, &(*s2), &(*s1), &((v779_19).read_zipper()));
      let v779_21: Space = unite(&(v779_18),&(v779_20));
      compose(&(v778_4),&(v779_21))
    };
    drop(v778_4);
    join_wrapped_into(&mut v777_6_write,&((v778_22).read_zipper()),&[]);
    }
    v777_6_cursor.ascend(1);
  }
  drop(v777_6_cursor);
  drop(v777_6_write);
  (v777_6).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
