#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,2]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,3]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,5]));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,4]));
static CONSTANT_7: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 0 4 0 0 0 1 4 0 0 0 2 4 0 0 0 3 4 0 0 0 4"));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 8 0 0 0 0 0 0 0 1 8 0 0 0 1 0 0 0 0 8 0 0 0 1 0 0 0 2 8 0 0 0 2 0 0 0 3 8 0 0 0 3 0 0 0 2 8 0 0 0 4 0 0 0 5"));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 4 0 0 0 0 4 0 0 0 1 4 0 0 0 2 4 0 0 0 3 4 0 0 0 4 4 0 0 0 5"));
fn routine_0(c: &mut Context) -> Space {
  let v0_3: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
  let v0_5: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_0), &((*CONSTANT_2).read_zipper()));
  let v0_6: Space = unite(&(v0_3),&(v0_5));
  let v0_9: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
  let v0_10: Space = unite(&(v0_6),&(v0_9));
  let v0_13: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_4), &((*CONSTANT_2).read_zipper()));
  let v0_14: Space = unite(&(v0_10),&(v0_13));
  let v0_16: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_3), &((*CONSTANT_2).read_zipper()));
  let v0_17: Space = unite(&(v0_14),&(v0_16));
  let v0_21: Space = routine_1(c, &(*CONSTANT_5), &(*CONSTANT_6), &((*CONSTANT_2).read_zipper()));
  let v0_22: Space = unite(&(v0_17),&(v0_21));
  let mut v0_23 = Space::new();
  let mut v0_23_write = v0_23.write_zipper();
  let mut v0_23_cursor = (v0_22).read_zipper();
  let v0_23_origin = v0_23_cursor.path().len();
  for v0_23_byte in v0_23_cursor.child_mask().iter() {
    v0_23_cursor.descend_to_existing_byte(v0_23_byte);
    {
    for v1_2_byte in v0_23_cursor.child_mask().iter() {
      v0_23_cursor.descend_to_existing_byte(v1_2_byte);
      {
      for v2_3_byte in v0_23_cursor.child_mask().iter() {
        v0_23_cursor.descend_to_existing_byte(v2_3_byte);
        {
        write_heads_mask(&mut v0_23_write,(&v0_23_cursor).head_mask(),&v0_23_cursor.path()[v0_23_origin..(v0_23_origin + 3)]);
        }
        v0_23_cursor.ascend(1);
      }
      }
      v0_23_cursor.ascend(1);
    }
    }
    v0_23_cursor.ascend(1);
  }
  drop(v0_23_cursor);
  drop(v0_23_write);
  let v0_25: Space = unite(&(v0_23),&(*CONSTANT_7));
  let v0_26: Space = routine_2(c, &((v0_25).read_zipper()));
  let mut v0_41 = Space::new();
  let mut v0_41_write = v0_41.write_zipper();
  let mut v0_41_cursor = (v0_26).read_zipper();
  let v0_41_origin = v0_41_cursor.path().len();
  for v0_41_byte in v0_41_cursor.child_mask().iter() {
    v0_41_cursor.descend_to_existing_byte(v0_41_byte);
    {
    for v4_2_byte in v0_41_cursor.child_mask().iter() {
      v0_41_cursor.descend_to_existing_byte(v4_2_byte);
      {
      for v5_3_byte in v0_41_cursor.child_mask().iter() {
        v0_41_cursor.descend_to_existing_byte(v5_3_byte);
        {
        for v6_3_byte in v0_41_cursor.child_mask().iter() {
          v0_41_cursor.descend_to_existing_byte(v6_3_byte);
          {
          let v7_3: Space = routine_3(c, &(*CONSTANT_0), &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
          let v7_4: Space = routine_3(c, &(*CONSTANT_1), &(*CONSTANT_0), &((*CONSTANT_2).read_zipper()));
          let v7_5: Space = unite(&(v7_3),&(v7_4));
          let v7_6: Space = routine_3(c, &(*CONSTANT_3), &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
          let v7_7: Space = unite(&(v7_5),&(v7_6));
          let v7_8: Space = routine_3(c, &(*CONSTANT_3), &(*CONSTANT_4), &((*CONSTANT_2).read_zipper()));
          let v7_9: Space = unite(&(v7_7),&(v7_8));
          let v7_10: Space = routine_3(c, &(*CONSTANT_4), &(*CONSTANT_3), &((*CONSTANT_2).read_zipper()));
          let v7_11: Space = unite(&(v7_9),&(v7_10));
          let v7_12: Space = routine_3(c, &(*CONSTANT_5), &(*CONSTANT_6), &((*CONSTANT_2).read_zipper()));
          let v7_13: Space = unite(&(v7_11),&(v7_12));
          let v7_14: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
          let v7_15: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_0), &((*CONSTANT_2).read_zipper()));
          let v7_16: Space = unite(&(v7_14),&(v7_15));
          let v7_17: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_1), &((*CONSTANT_2).read_zipper()));
          let v7_18: Space = unite(&(v7_16),&(v7_17));
          let v7_19: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_4), &((*CONSTANT_2).read_zipper()));
          let v7_20: Space = unite(&(v7_18),&(v7_19));
          let v7_21: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_3), &((*CONSTANT_2).read_zipper()));
          let v7_22: Space = unite(&(v7_20),&(v7_21));
          let v7_23: Space = routine_1(c, &(*CONSTANT_5), &(*CONSTANT_6), &((*CONSTANT_2).read_zipper()));
          let v7_24: Space = unite(&(v7_22),&(v7_23));
          let mut v7_25 = Space::new();
          let mut v7_25_write = v7_25.write_zipper();
          let mut v7_25_cursor = (v7_24).read_zipper();
          let v7_25_origin = v7_25_cursor.path().len();
          for v7_25_byte in v7_25_cursor.child_mask().iter() {
            v7_25_cursor.descend_to_existing_byte(v7_25_byte);
            {
            for v8_2_byte in v7_25_cursor.child_mask().iter() {
              v7_25_cursor.descend_to_existing_byte(v8_2_byte);
              {
              for v9_3_byte in v7_25_cursor.child_mask().iter() {
                v7_25_cursor.descend_to_existing_byte(v9_3_byte);
                {
                write_heads_mask(&mut v7_25_write,(&v7_25_cursor).head_mask(),&v7_25_cursor.path()[v7_25_origin..(v7_25_origin + 3)]);
                }
                v7_25_cursor.ascend(1);
              }
              }
              v7_25_cursor.ascend(1);
            }
            }
            v7_25_cursor.ascend(1);
          }
          drop(v7_25_cursor);
          drop(v7_25_write);
          let v7_26: Space = unite(&(v7_25),&(*CONSTANT_7));
          let v7_27: Space = routine_4(c, &v0_41_cursor.path()[v0_41_origin..(v0_41_origin + 4)], &v0_41_cursor, &((v7_13).read_zipper()), &((*CONSTANT_8).read_zipper()), &((v7_26).read_zipper()));
          join_wrapped_into(&mut v0_41_write,&((v7_27).read_zipper()),&[]);
          }
          v0_41_cursor.ascend(1);
        }
        }
        v0_41_cursor.ascend(1);
      }
      }
      v0_41_cursor.ascend(1);
    }
    }
    v0_41_cursor.ascend(1);
  }
  drop(v0_41_cursor);
  drop(v0_41_write);
  (v0_41).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v11_3: Path = concat_path(&(*p0),&(*p1));
  let v11_4: Space = singleton(&(v11_3));
  drop(v11_3);
  (v11_4).clone()
}

fn routine_2(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v12_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v12_2: Space = first_matching(&(*s0),&(*CONSTANT_2),false);
  let v12_3: Space = unite(&(v12_1),&(v12_2));
  drop(v12_1);
  drop(v12_2);
  let v12_6: Space = if (&(v12_3)).is_empty() { Space::new() } else {
    let v13_4: Space = routine_5(c, &(*s0));
    let v13_5: Space = subtract(&(*s0),&(v13_4));
    compose(&(v12_3),&(v13_5))
  };
  drop(v12_3);
  let v12_7: Space = subtract(&(*s0),&(v12_6));
  (v12_7).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v14_3: Path = concat_path(&(*p0),&(*p1));
  let v14_4: Space = singleton(&(v14_3));
  drop(v14_3);
  (v14_4).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>, s2: &View<'_, '_>, s3: &View<'_, '_>) -> Space {
  let v15_5: Space = singleton(&(*p0));
  let mut v15_6: Space = (v15_5).clone();
  loop {
    let v16_1: Space = intersect(&(v15_6),&(*s3));
    let v16_2: Space = restrict_to(&(*s2),&(v16_1));
    drop(v16_1);
    let mut v16_3 = Space::new();
    let mut v16_3_write = v16_3.write_zipper();
    let mut v16_3_cursor = (v16_2).read_zipper();
    let v16_3_origin = v16_3_cursor.path().len();
    for v16_3_byte in v16_3_cursor.child_mask().iter() {
      v16_3_cursor.descend_to_existing_byte(v16_3_byte);
      {
      for v17_2_byte in v16_3_cursor.child_mask().iter() {
        v16_3_cursor.descend_to_existing_byte(v17_2_byte);
        {
        for v18_2_byte in v16_3_cursor.child_mask().iter() {
          v16_3_cursor.descend_to_existing_byte(v18_2_byte);
          {
          join_tails_into(&mut v16_3_write,&mut v16_3_cursor);
          }
          v16_3_cursor.ascend(1);
        }
        }
        v16_3_cursor.ascend(1);
      }
      }
      v16_3_cursor.ascend(1);
    }
    drop(v16_3_cursor);
    drop(v16_3_write);
    drop(v16_2);
    let v16_4: Space = unite(&(v16_3),&(v15_6));
    drop(v16_3);
    let v16_5: Space = intersect(&(v16_4),&(*s3));
    drop(v16_4);
    if !v15_6.join_into((v16_5).clone()).is_element() { break; }
  }
  let mut v15_7: Space = (v15_5).clone();
  loop {
    let v20_1: Space = intersect(&(v15_7),&(*s3));
    let v20_2: Space = restrict_to(&(*s1),&(v20_1));
    drop(v20_1);
    let mut v20_3 = Space::new();
    let mut v20_3_write = v20_3.write_zipper();
    let mut v20_3_cursor = (v20_2).read_zipper();
    let v20_3_origin = v20_3_cursor.path().len();
    for v20_3_byte in v20_3_cursor.child_mask().iter() {
      v20_3_cursor.descend_to_existing_byte(v20_3_byte);
      {
      for v21_2_byte in v20_3_cursor.child_mask().iter() {
        v20_3_cursor.descend_to_existing_byte(v21_2_byte);
        {
        for v22_2_byte in v20_3_cursor.child_mask().iter() {
          v20_3_cursor.descend_to_existing_byte(v22_2_byte);
          {
          join_tails_into(&mut v20_3_write,&mut v20_3_cursor);
          }
          v20_3_cursor.ascend(1);
        }
        }
        v20_3_cursor.ascend(1);
      }
      }
      v20_3_cursor.ascend(1);
    }
    drop(v20_3_cursor);
    drop(v20_3_write);
    drop(v20_2);
    let v20_4: Space = unite(&(v20_3),&(v15_7));
    drop(v20_3);
    let v20_5: Space = intersect(&(v20_4),&(*s3));
    drop(v20_4);
    if !v15_7.join_into((v20_5).clone()).is_element() { break; }
  }
  let v15_8: Space = intersect(&(v15_6),&(v15_7));
  let v15_9: Space = subtract(&(v15_8),&(v15_5));
  drop(v15_8);
  let v15_10: Space = wrap(&(v15_9),&(*p0));
  drop(v15_9);
  let v15_11: Space = subtract(&(*s3),&(v15_6));
  let v15_12: Space = subtract(&(v15_11),&(v15_7));
  drop(v15_11);
  let v15_13: Space = routine_2(c, &((v15_12).read_zipper()));
  drop(v15_12);
  let mut v15_14 = Space::new();
  let mut v15_14_write = v15_14.write_zipper();
  let mut v15_14_cursor = (v15_13).read_zipper();
  let v15_14_origin = v15_14_cursor.path().len();
  for v15_14_byte in v15_14_cursor.child_mask().iter() {
    v15_14_cursor.descend_to_existing_byte(v15_14_byte);
    {
    for v24_2_byte in v15_14_cursor.child_mask().iter() {
      v15_14_cursor.descend_to_existing_byte(v24_2_byte);
      {
      for v25_3_byte in v15_14_cursor.child_mask().iter() {
        v15_14_cursor.descend_to_existing_byte(v25_3_byte);
        {
        for v26_3_byte in v15_14_cursor.child_mask().iter() {
          v15_14_cursor.descend_to_existing_byte(v26_3_byte);
          {
          let mut v27_3: Space = (v15_5).clone();
          loop {
            let v28_1: Space = intersect(&(v27_3),&(*s3));
            let v28_2: Space = restrict_to(&(*s2),&(v28_1));
            drop(v28_1);
            let mut v28_3 = Space::new();
            let mut v28_3_write = v28_3.write_zipper();
            let mut v28_3_cursor = (v28_2).read_zipper();
            let v28_3_origin = v28_3_cursor.path().len();
            for v28_3_byte in v28_3_cursor.child_mask().iter() {
              v28_3_cursor.descend_to_existing_byte(v28_3_byte);
              {
              for v29_2_byte in v28_3_cursor.child_mask().iter() {
                v28_3_cursor.descend_to_existing_byte(v29_2_byte);
                {
                for v30_2_byte in v28_3_cursor.child_mask().iter() {
                  v28_3_cursor.descend_to_existing_byte(v30_2_byte);
                  {
                  join_tails_into(&mut v28_3_write,&mut v28_3_cursor);
                  }
                  v28_3_cursor.ascend(1);
                }
                }
                v28_3_cursor.ascend(1);
              }
              }
              v28_3_cursor.ascend(1);
            }
            drop(v28_3_cursor);
            drop(v28_3_write);
            drop(v28_2);
            let v28_4: Space = unite(&(v28_3),&(v27_3));
            drop(v28_3);
            let v28_5: Space = intersect(&(v28_4),&(*s3));
            drop(v28_4);
            if !v27_3.join_into((v28_5).clone()).is_element() { break; }
          }
          let v27_4: Space = subtract(&(*s3),&(v27_3));
          drop(v27_3);
          let mut v27_5: Space = (v15_5).clone();
          loop {
            let v32_1: Space = intersect(&(v27_5),&(*s3));
            let v32_2: Space = restrict_to(&(*s1),&(v32_1));
            drop(v32_1);
            let mut v32_3 = Space::new();
            let mut v32_3_write = v32_3.write_zipper();
            let mut v32_3_cursor = (v32_2).read_zipper();
            let v32_3_origin = v32_3_cursor.path().len();
            for v32_3_byte in v32_3_cursor.child_mask().iter() {
              v32_3_cursor.descend_to_existing_byte(v32_3_byte);
              {
              for v33_2_byte in v32_3_cursor.child_mask().iter() {
                v32_3_cursor.descend_to_existing_byte(v33_2_byte);
                {
                for v34_2_byte in v32_3_cursor.child_mask().iter() {
                  v32_3_cursor.descend_to_existing_byte(v34_2_byte);
                  {
                  join_tails_into(&mut v32_3_write,&mut v32_3_cursor);
                  }
                  v32_3_cursor.ascend(1);
                }
                }
                v32_3_cursor.ascend(1);
              }
              }
              v32_3_cursor.ascend(1);
            }
            drop(v32_3_cursor);
            drop(v32_3_write);
            drop(v32_2);
            let v32_4: Space = unite(&(v32_3),&(v27_5));
            drop(v32_3);
            let v32_5: Space = intersect(&(v32_4),&(*s3));
            drop(v32_4);
            if !v27_5.join_into((v32_5).clone()).is_element() { break; }
          }
          let v27_6: Space = subtract(&(v27_4),&(v27_5));
          drop(v27_4);
          drop(v27_5);
          let v27_7: Space = routine_4(c, &v15_14_cursor.path()[v15_14_origin..(v15_14_origin + 4)], &v15_14_cursor, &(*s1), &(*s2), &((v27_6).read_zipper()));
          drop(v27_6);
          join_wrapped_into(&mut v15_14_write,&((v27_7).read_zipper()),&[]);
          }
          v15_14_cursor.ascend(1);
        }
        }
        v15_14_cursor.ascend(1);
      }
      }
      v15_14_cursor.ascend(1);
    }
    }
    v15_14_cursor.ascend(1);
  }
  drop(v15_14_cursor);
  drop(v15_14_write);
  let v15_15: Space = unite(&(v15_10),&(v15_14));
  drop(v15_10);
  let v15_16: Space = subtract(&(v15_6),&(v15_7));
  let v15_17: Space = routine_2(c, &((v15_16).read_zipper()));
  drop(v15_16);
  let mut v15_18 = Space::new();
  let mut v15_18_write = v15_18.write_zipper();
  let mut v15_18_cursor = (v15_17).read_zipper();
  let v15_18_origin = v15_18_cursor.path().len();
  for v15_18_byte in v15_18_cursor.child_mask().iter() {
    v15_18_cursor.descend_to_existing_byte(v15_18_byte);
    {
    for v36_2_byte in v15_18_cursor.child_mask().iter() {
      v15_18_cursor.descend_to_existing_byte(v36_2_byte);
      {
      for v37_3_byte in v15_18_cursor.child_mask().iter() {
        v15_18_cursor.descend_to_existing_byte(v37_3_byte);
        {
        for v38_3_byte in v15_18_cursor.child_mask().iter() {
          v15_18_cursor.descend_to_existing_byte(v38_3_byte);
          {
          let mut v39_3: Space = (v15_5).clone();
          loop {
            let v40_1: Space = intersect(&(v39_3),&(*s3));
            let v40_2: Space = restrict_to(&(*s2),&(v40_1));
            drop(v40_1);
            let mut v40_3 = Space::new();
            let mut v40_3_write = v40_3.write_zipper();
            let mut v40_3_cursor = (v40_2).read_zipper();
            let v40_3_origin = v40_3_cursor.path().len();
            for v40_3_byte in v40_3_cursor.child_mask().iter() {
              v40_3_cursor.descend_to_existing_byte(v40_3_byte);
              {
              for v41_2_byte in v40_3_cursor.child_mask().iter() {
                v40_3_cursor.descend_to_existing_byte(v41_2_byte);
                {
                for v42_2_byte in v40_3_cursor.child_mask().iter() {
                  v40_3_cursor.descend_to_existing_byte(v42_2_byte);
                  {
                  join_tails_into(&mut v40_3_write,&mut v40_3_cursor);
                  }
                  v40_3_cursor.ascend(1);
                }
                }
                v40_3_cursor.ascend(1);
              }
              }
              v40_3_cursor.ascend(1);
            }
            drop(v40_3_cursor);
            drop(v40_3_write);
            drop(v40_2);
            let v40_4: Space = unite(&(v40_3),&(v39_3));
            drop(v40_3);
            let v40_5: Space = intersect(&(v40_4),&(*s3));
            drop(v40_4);
            if !v39_3.join_into((v40_5).clone()).is_element() { break; }
          }
          let mut v39_4: Space = (v15_5).clone();
          loop {
            let v44_1: Space = intersect(&(v39_4),&(*s3));
            let v44_2: Space = restrict_to(&(*s1),&(v44_1));
            drop(v44_1);
            let mut v44_3 = Space::new();
            let mut v44_3_write = v44_3.write_zipper();
            let mut v44_3_cursor = (v44_2).read_zipper();
            let v44_3_origin = v44_3_cursor.path().len();
            for v44_3_byte in v44_3_cursor.child_mask().iter() {
              v44_3_cursor.descend_to_existing_byte(v44_3_byte);
              {
              for v45_2_byte in v44_3_cursor.child_mask().iter() {
                v44_3_cursor.descend_to_existing_byte(v45_2_byte);
                {
                for v46_2_byte in v44_3_cursor.child_mask().iter() {
                  v44_3_cursor.descend_to_existing_byte(v46_2_byte);
                  {
                  join_tails_into(&mut v44_3_write,&mut v44_3_cursor);
                  }
                  v44_3_cursor.ascend(1);
                }
                }
                v44_3_cursor.ascend(1);
              }
              }
              v44_3_cursor.ascend(1);
            }
            drop(v44_3_cursor);
            drop(v44_3_write);
            drop(v44_2);
            let v44_4: Space = unite(&(v44_3),&(v39_4));
            drop(v44_3);
            let v44_5: Space = intersect(&(v44_4),&(*s3));
            drop(v44_4);
            if !v39_4.join_into((v44_5).clone()).is_element() { break; }
          }
          let v39_5: Space = subtract(&(v39_3),&(v39_4));
          drop(v39_3);
          drop(v39_4);
          let v39_6: Space = routine_4(c, &v15_18_cursor.path()[v15_18_origin..(v15_18_origin + 4)], &v15_18_cursor, &(*s1), &(*s2), &((v39_5).read_zipper()));
          drop(v39_5);
          join_wrapped_into(&mut v15_18_write,&((v39_6).read_zipper()),&[]);
          }
          v15_18_cursor.ascend(1);
        }
        }
        v15_18_cursor.ascend(1);
      }
      }
      v15_18_cursor.ascend(1);
    }
    }
    v15_18_cursor.ascend(1);
  }
  drop(v15_18_cursor);
  drop(v15_18_write);
  let v15_19: Space = unite(&(v15_15),&(v15_18));
  let v15_20: Space = subtract(&(v15_7),&(v15_6));
  drop(v15_6);
  drop(v15_7);
  let v15_21: Space = routine_2(c, &((v15_20).read_zipper()));
  drop(v15_20);
  let mut v15_22 = Space::new();
  let mut v15_22_write = v15_22.write_zipper();
  let mut v15_22_cursor = (v15_21).read_zipper();
  let v15_22_origin = v15_22_cursor.path().len();
  for v15_22_byte in v15_22_cursor.child_mask().iter() {
    v15_22_cursor.descend_to_existing_byte(v15_22_byte);
    {
    for v48_2_byte in v15_22_cursor.child_mask().iter() {
      v15_22_cursor.descend_to_existing_byte(v48_2_byte);
      {
      for v49_3_byte in v15_22_cursor.child_mask().iter() {
        v15_22_cursor.descend_to_existing_byte(v49_3_byte);
        {
        for v50_3_byte in v15_22_cursor.child_mask().iter() {
          v15_22_cursor.descend_to_existing_byte(v50_3_byte);
          {
          let mut v51_3: Space = (v15_5).clone();
          loop {
            let v52_1: Space = intersect(&(v51_3),&(*s3));
            let v52_2: Space = restrict_to(&(*s1),&(v52_1));
            drop(v52_1);
            let mut v52_3 = Space::new();
            let mut v52_3_write = v52_3.write_zipper();
            let mut v52_3_cursor = (v52_2).read_zipper();
            let v52_3_origin = v52_3_cursor.path().len();
            for v52_3_byte in v52_3_cursor.child_mask().iter() {
              v52_3_cursor.descend_to_existing_byte(v52_3_byte);
              {
              for v53_2_byte in v52_3_cursor.child_mask().iter() {
                v52_3_cursor.descend_to_existing_byte(v53_2_byte);
                {
                for v54_2_byte in v52_3_cursor.child_mask().iter() {
                  v52_3_cursor.descend_to_existing_byte(v54_2_byte);
                  {
                  join_tails_into(&mut v52_3_write,&mut v52_3_cursor);
                  }
                  v52_3_cursor.ascend(1);
                }
                }
                v52_3_cursor.ascend(1);
              }
              }
              v52_3_cursor.ascend(1);
            }
            drop(v52_3_cursor);
            drop(v52_3_write);
            drop(v52_2);
            let v52_4: Space = unite(&(v52_3),&(v51_3));
            drop(v52_3);
            let v52_5: Space = intersect(&(v52_4),&(*s3));
            drop(v52_4);
            if !v51_3.join_into((v52_5).clone()).is_element() { break; }
          }
          let mut v51_4: Space = (v15_5).clone();
          loop {
            let v56_1: Space = intersect(&(v51_4),&(*s3));
            let v56_2: Space = restrict_to(&(*s2),&(v56_1));
            drop(v56_1);
            let mut v56_3 = Space::new();
            let mut v56_3_write = v56_3.write_zipper();
            let mut v56_3_cursor = (v56_2).read_zipper();
            let v56_3_origin = v56_3_cursor.path().len();
            for v56_3_byte in v56_3_cursor.child_mask().iter() {
              v56_3_cursor.descend_to_existing_byte(v56_3_byte);
              {
              for v57_2_byte in v56_3_cursor.child_mask().iter() {
                v56_3_cursor.descend_to_existing_byte(v57_2_byte);
                {
                for v58_2_byte in v56_3_cursor.child_mask().iter() {
                  v56_3_cursor.descend_to_existing_byte(v58_2_byte);
                  {
                  join_tails_into(&mut v56_3_write,&mut v56_3_cursor);
                  }
                  v56_3_cursor.ascend(1);
                }
                }
                v56_3_cursor.ascend(1);
              }
              }
              v56_3_cursor.ascend(1);
            }
            drop(v56_3_cursor);
            drop(v56_3_write);
            drop(v56_2);
            let v56_4: Space = unite(&(v56_3),&(v51_4));
            drop(v56_3);
            let v56_5: Space = intersect(&(v56_4),&(*s3));
            drop(v56_4);
            if !v51_4.join_into((v56_5).clone()).is_element() { break; }
          }
          let v51_5: Space = subtract(&(v51_3),&(v51_4));
          drop(v51_3);
          drop(v51_4);
          let v51_6: Space = routine_4(c, &v15_22_cursor.path()[v15_22_origin..(v15_22_origin + 4)], &v15_22_cursor, &(*s1), &(*s2), &((v51_5).read_zipper()));
          drop(v51_5);
          join_wrapped_into(&mut v15_22_write,&((v51_6).read_zipper()),&[]);
          }
          v15_22_cursor.ascend(1);
        }
        }
        v15_22_cursor.ascend(1);
      }
      }
      v15_22_cursor.ascend(1);
    }
    }
    v15_22_cursor.ascend(1);
  }
  drop(v15_22_cursor);
  drop(v15_22_write);
  drop(v15_5);
  let v15_23: Space = unite(&(v15_19),&(v15_22));
  (v15_23).clone()
}

fn routine_5(c: &mut Context, s0: &View<'_, '_>) -> Space {
  let v60_2: Space = first_matching(&(*s0),&(*CONSTANT_2),false);
  let v60_3: Space = intersect(&(*CONSTANT_2),&(v60_2));
  let v60_4: Space = if has_head(&(v60_2)) { singleton(&[]) } else { Space::new() };
  let v60_5: Space = unite(&(v60_3),&(v60_4));
  drop(v60_3);
  let v60_7: Space = compose(&(v60_5),&(*CONSTANT_2));
  drop(v60_5);
  let v60_9: Space = subtract(&(*CONSTANT_2),&(v60_2));
  drop(v60_2);
  let v60_10: Space = subtract(&(v60_9),&(v60_4));
  drop(v60_4);
  drop(v60_9);
  let v60_18: Space = if (&(v60_10)).is_empty() { Space::new() } else {
    let v61_11: Space = first_matching(&(*s0),&(*CONSTANT_10),true);
    let v61_12: Space = first_matching(&(v61_11),&(*CONSTANT_2),false);
    let v61_15: Space = if (&(v61_12)).is_empty() { Space::new() } else {
      let v62_14: Space = routine_6(c, &(*CONSTANT_9), &(*s0));
      compose(&(v61_12),&(v62_14))
    };
    drop(v61_12);
    let mut v61_16 = Space::new();
    let mut v61_16_write = v61_16.write_zipper();
    let mut v61_16_cursor = (v61_11).read_zipper();
    let v61_16_origin = v61_16_cursor.path().len();
    for v61_16_byte in v61_16_cursor.child_mask().iter() {
      v61_16_cursor.descend_to_existing_byte(v61_16_byte);
      {
      let v63_2_arg_0: &[u8] = &v61_16_cursor.path()[v61_16_origin..(v61_16_origin + 1)];
      let v63_2_arg_2: &Space = &(&(*s0)).make_map();
      let mut v63_2_more = v61_16_cursor.is_val() || next_value_within(&mut v61_16_cursor,(v61_16_origin + 1));
      while v63_2_more {
        {
        let v63_2_depth = v61_16_cursor.path().len();
        let v64_4: Space = routine_5(c, &(descend_cursor((*v63_2_arg_2).read_zipper(),&v61_16_cursor.path()[v61_16_origin..v63_2_depth])));
        join_wrapped_into(&mut v61_16_write,&((v64_4).read_zipper()),&v61_16_cursor.path()[v61_16_origin..v63_2_depth]);
        }
        v63_2_more = next_value_within(&mut v61_16_cursor,(v61_16_origin + 1));
      }
      }
      v61_16_cursor.ascend(1);
    }
    drop(v61_16_cursor);
    drop(v61_16_write);
    drop(v61_11);
    let v61_17: Space = unite(&(v61_15),&(v61_16));
    compose(&(v60_10),&(v61_17))
  };
  drop(v60_10);
  let v60_19: Space = unite(&(v60_7),&(v60_18));
  drop(v60_7);
  (v60_19).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let v65_4: Space = first_matching(&(descend_cursor((*s0).read_zipper(),&(*p0))),&(*CONSTANT_2),false);
  let v65_5: Space = intersect(&(*CONSTANT_2),&(v65_4));
  let v65_6: Space = if has_head(&(v65_4)) { singleton(&[]) } else { Space::new() };
  let v65_7: Space = unite(&(v65_5),&(v65_6));
  drop(v65_5);
  let v65_9: Space = compose(&(v65_7),&(*CONSTANT_2));
  drop(v65_7);
  let v65_11: Space = subtract(&(*CONSTANT_2),&(v65_4));
  drop(v65_4);
  let v65_12: Space = subtract(&(v65_11),&(v65_6));
  drop(v65_6);
  drop(v65_11);
  let v65_16: Space = if (&(v65_12)).is_empty() { Space::new() } else {
    let v66_14: Space = first_matching(&(descend_cursor((*s0).read_zipper(),&(*p0))),&(*CONSTANT_10),true);
    let mut v66_15 = Space::new();
    let mut v66_15_write = v66_15.write_zipper();
    let v66_15_arg_0: &[u8] = &(*CONSTANT_9);
    let v66_15_arg_2: &Space = &(&(descend_cursor((*s0).read_zipper(),&(*p0)))).make_map();
    let mut v66_15_cursor = (v66_14).read_zipper();
    let v66_15_origin = v66_15_cursor.path().len();
    let mut v66_15_more = v66_15_cursor.is_val() || next_value_within(&mut v66_15_cursor,v66_15_origin);
    while v66_15_more {
      {
      let v66_15_depth = v66_15_cursor.path().len();
      let v67_3: Space = routine_6(c, &v66_15_cursor.path()[v66_15_origin..v66_15_depth], &((*v66_15_arg_2).read_zipper()));
      join_wrapped_into(&mut v66_15_write,&((v67_3).read_zipper()),&[]);
      }
      v66_15_more = next_value_within(&mut v66_15_cursor,v66_15_origin);
    }
    drop(v66_15_cursor);
    drop(v66_15_write);
    drop(v66_14);
    compose(&(v65_12),&(v66_15))
  };
  drop(v65_12);
  let v65_17: Space = unite(&(v65_9),&(v65_16));
  drop(v65_9);
  let v65_18: Space = wrap(&(v65_17),&(*p0));
  (v65_18).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
