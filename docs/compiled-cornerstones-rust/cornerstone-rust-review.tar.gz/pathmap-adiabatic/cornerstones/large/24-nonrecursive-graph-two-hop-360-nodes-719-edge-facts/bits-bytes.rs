#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1,0,1,0,0,0,1,0,1,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_24 = Space::new();
  let mut v0_24_write = v0_24.write_zipper();
  let mut v0_24_cursor = descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0));
  let v0_24_origin = v0_24_cursor.path().len();
  for v0_24_byte in v0_24_cursor.child_mask().iter() {
    v0_24_cursor.descend_to_existing_byte(v0_24_byte);
    {
    let v1_2: Space = singleton(&v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 1)]);
    let v1_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if map_kernels::has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (&(v1_5)).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_write = v2_6.write_zipper();
      for v2_6_byte in v0_24_cursor.child_mask().iter() {
        v0_24_cursor.descend_to_existing_byte(v2_6_byte);
        {
        let v3_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 1)..(v0_24_origin + 2)]);
        let v3_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v3_2));
        let v3_4: Space = if map_kernels::has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (&(v3_5)).is_empty() { Space::new() } else {
          let mut v4_7 = Space::new();
          let mut v4_7_write = v4_7.write_zipper();
          for v4_7_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v4_7_byte);
            {
            let v5_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v5_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v5_2));
            let v5_4: Space = if map_kernels::has_head(&(v5_3)) { singleton(&[]) } else { Space::new() };
            drop(v5_3);
            let v5_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v5_4));
            drop(v5_4);
            let v5_8: Space = if (&(v5_5)).is_empty() { Space::new() } else {
              let v6_7: Space = routine_1(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              map_map_kernels::compose(&(v5_5),&(v6_7))
            };
            drop(v5_5);
            let v5_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v5_2));
            drop(v5_2);
            let v5_10: Space = if map_kernels::has_head(&(v5_9)) { singleton(&[]) } else { Space::new() };
            drop(v5_9);
            let v5_12: Space = if (&(v5_10)).is_empty() { Space::new() } else {
              let v7_11: Space = routine_2(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              map_map_kernels::compose(&(v5_10),&(v7_11))
            };
            drop(v5_10);
            let v5_13: Space = map_map_kernels::unite(&(v5_8),&(v5_12));
            join_wrapped_into(&mut v4_7_write,&((v5_13).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v4_7_write);
          map_map_kernels::compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if map_kernels::has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (&(v3_10)).is_empty() { Space::new() } else {
          let mut v8_11 = Space::new();
          let mut v8_11_write = v8_11.write_zipper();
          for v8_11_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v8_11_byte);
            {
            let v9_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v9_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v9_2));
            let v9_4: Space = if map_kernels::has_head(&(v9_3)) { singleton(&[]) } else { Space::new() };
            drop(v9_3);
            let v9_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v9_4));
            drop(v9_4);
            let v9_8: Space = if (&(v9_5)).is_empty() { Space::new() } else {
              let v10_7: Space = routine_1(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              map_map_kernels::compose(&(v9_5),&(v10_7))
            };
            drop(v9_5);
            let v9_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v9_2));
            drop(v9_2);
            let v9_10: Space = if map_kernels::has_head(&(v9_9)) { singleton(&[]) } else { Space::new() };
            drop(v9_9);
            let v9_12: Space = if (&(v9_10)).is_empty() { Space::new() } else {
              let v11_11: Space = routine_3(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              map_map_kernels::compose(&(v9_10),&(v11_11))
            };
            drop(v9_10);
            let v9_13: Space = map_map_kernels::unite(&(v9_8),&(v9_12));
            join_wrapped_into(&mut v8_11_write,&((v9_13).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v8_11_write);
          map_map_kernels::compose(&(v3_10),&(v8_11))
        };
        drop(v3_10);
        let v3_13: Space = map_map_kernels::unite(&(v3_8),&(v3_12));
        join_wrapped_into(&mut v2_6_write,&((v3_13).read_zipper()),&[]);
        }
        v0_24_cursor.ascend(1);
      }
      drop(v2_6_write);
      map_map_kernels::compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if map_kernels::has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (&(v1_9)).is_empty() { Space::new() } else {
      let mut v12_10 = Space::new();
      let mut v12_10_write = v12_10.write_zipper();
      for v12_10_byte in v0_24_cursor.child_mask().iter() {
        v0_24_cursor.descend_to_existing_byte(v12_10_byte);
        {
        let v13_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 1)..(v0_24_origin + 2)]);
        let v13_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v13_2));
        let v13_4: Space = if map_kernels::has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (&(v13_5)).is_empty() { Space::new() } else {
          let mut v14_7 = Space::new();
          let mut v14_7_write = v14_7.write_zipper();
          for v14_7_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v14_7_byte);
            {
            let v15_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v15_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v15_2));
            let v15_4: Space = if map_kernels::has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (&(v15_5)).is_empty() { Space::new() } else {
              let v16_7: Space = routine_1(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              map_map_kernels::compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if map_kernels::has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (&(v15_10)).is_empty() { Space::new() } else {
              let v17_11: Space = routine_2(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              map_map_kernels::compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = map_map_kernels::unite(&(v15_8),&(v15_12));
            join_wrapped_into(&mut v14_7_write,&((v15_13).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v14_7_write);
          map_map_kernels::compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if map_kernels::has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (&(v13_10)).is_empty() { Space::new() } else {
          let mut v18_11 = Space::new();
          let mut v18_11_write = v18_11.write_zipper();
          for v18_11_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v18_11_byte);
            {
            let v19_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v19_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v19_2));
            let v19_4: Space = if map_kernels::has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v19_4));
            drop(v19_4);
            let v19_7: Space = if (&(v19_5)).is_empty() { Space::new() } else {
              let v20_6: Space = routine_4(c, &v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)], &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 2)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              map_map_kernels::compose(&(v19_5),&(v20_6))
            };
            drop(v19_5);
            let v19_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v19_2));
            drop(v19_2);
            let v19_9: Space = if map_kernels::has_head(&(v19_8)) { singleton(&[]) } else { Space::new() };
            drop(v19_8);
            let v19_11: Space = if (&(v19_9)).is_empty() { Space::new() } else {
              let v21_10: Space = routine_5(c, &v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)], &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 2)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              map_map_kernels::compose(&(v19_9),&(v21_10))
            };
            drop(v19_9);
            let v19_12: Space = map_map_kernels::unite(&(v19_7),&(v19_11));
            join_wrapped_into(&mut v18_11_write,&((v19_12).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v18_11_write);
          map_map_kernels::compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = map_map_kernels::unite(&(v13_8),&(v13_12));
        join_wrapped_into(&mut v12_10_write,&((v13_13).read_zipper()),&[]);
        }
        v0_24_cursor.ascend(1);
      }
      drop(v12_10_write);
      map_map_kernels::compose(&(v1_9),&(v12_10))
    };
    drop(v1_9);
    let v1_12: Space = map_map_kernels::unite(&(v1_7),&(v1_11));
    join_wrapped_into(&mut v0_24_write,&((v1_12).read_zipper()),&[]);
    }
    v0_24_cursor.ascend(1);
  }
  drop(v0_24_cursor);
  drop(v0_24_write);
  let v0_26: Space = map_kernels::wrap(&(v0_24),&(*CONSTANT_3));
  (v0_26).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v22_24 = Space::new();
  let mut v22_24_write = v22_24.write_zipper();
  let mut v22_24_cursor = (*s0).read_zipper();
  let v22_24_origin = v22_24_cursor.path().len();
  for v22_24_byte in v22_24_cursor.child_mask().iter() {
    v22_24_cursor.descend_to_existing_byte(v22_24_byte);
    {
    let v23_2: Space = singleton(&v22_24_cursor.path()[v22_24_origin..(v22_24_origin + 1)]);
    let v23_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v23_2));
    let v23_4: Space = if map_kernels::has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
    drop(v23_3);
    let v23_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v23_4));
    drop(v23_4);
    let v23_8: Space = if (&(v23_5)).is_empty() { Space::new() } else {
      let v24_6: Path = concat_path(&(*p0),&v22_24_cursor.path()[v22_24_origin..(v22_24_origin + 1)]);
      let mut v24_7 = Space::new();
      let mut v24_7_write = v24_7.write_zipper();
      for v24_7_byte in v22_24_cursor.child_mask().iter() {
        v22_24_cursor.descend_to_existing_byte(v24_7_byte);
        {
        let v25_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
        let v25_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v25_2));
        let v25_4: Space = if map_kernels::has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
        drop(v25_3);
        let v25_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v25_4));
        drop(v25_4);
        let v25_8: Space = if (&(v25_5)).is_empty() { Space::new() } else {
          let v26_6: Path = concat_path(&(v24_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v26_7 = Space::new();
          let mut v26_7_write = v26_7.write_zipper();
          for v26_7_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v26_7_byte);
            {
            let v27_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v27_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v27_2));
            let v27_4: Space = if map_kernels::has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
            drop(v27_3);
            let v27_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v27_4));
            drop(v27_4);
            let v27_8: Space = if (&(v27_5)).is_empty() { Space::new() } else {
              let v28_6: Path = concat_path(&(v26_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v28_7: Space = routine_6(c, &(v28_6), &v22_24_cursor, &(*s1));
              map_map_kernels::compose(&(v27_5),&(v28_7))
            };
            drop(v27_5);
            let v27_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v27_2));
            drop(v27_2);
            let v27_10: Space = if map_kernels::has_head(&(v27_9)) { singleton(&[]) } else { Space::new() };
            drop(v27_9);
            let v27_12: Space = if (&(v27_10)).is_empty() { Space::new() } else {
              let v29_6: Path = concat_path(&(v26_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v29_11: Space = routine_7(c, &(v29_6), &v22_24_cursor, &(*s1));
              drop(v29_6);
              map_map_kernels::compose(&(v27_10),&(v29_11))
            };
            drop(v27_10);
            let v27_13: Space = map_map_kernels::unite(&(v27_8),&(v27_12));
            join_wrapped_into(&mut v26_7_write,&((v27_13).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v26_7_write);
          map_map_kernels::compose(&(v25_5),&(v26_7))
        };
        drop(v25_5);
        let v25_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v25_2));
        drop(v25_2);
        let v25_10: Space = if map_kernels::has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
        drop(v25_9);
        let v25_12: Space = if (&(v25_10)).is_empty() { Space::new() } else {
          let v30_6: Path = concat_path(&(v24_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v30_11 = Space::new();
          let mut v30_11_write = v30_11.write_zipper();
          for v30_11_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v30_11_byte);
            {
            let v31_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v31_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v31_2));
            let v31_4: Space = if map_kernels::has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
            drop(v31_3);
            let v31_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v31_4));
            drop(v31_4);
            let v31_8: Space = if (&(v31_5)).is_empty() { Space::new() } else {
              let v32_6: Path = concat_path(&(v30_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v32_7: Space = routine_6(c, &(v32_6), &v22_24_cursor, &(*s1));
              map_map_kernels::compose(&(v31_5),&(v32_7))
            };
            drop(v31_5);
            let v31_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v31_2));
            drop(v31_2);
            let v31_10: Space = if map_kernels::has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
            drop(v31_9);
            let v31_12: Space = if (&(v31_10)).is_empty() { Space::new() } else {
              let v33_6: Path = concat_path(&(v30_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v33_11: Space = routine_3(c, &(v33_6), &v22_24_cursor, &(*s1));
              drop(v33_6);
              map_map_kernels::compose(&(v31_10),&(v33_11))
            };
            drop(v31_10);
            let v31_13: Space = map_map_kernels::unite(&(v31_8),&(v31_12));
            join_wrapped_into(&mut v30_11_write,&((v31_13).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v30_11_write);
          drop(v30_6);
          map_map_kernels::compose(&(v25_10),&(v30_11))
        };
        drop(v25_10);
        let v25_13: Space = map_map_kernels::unite(&(v25_8),&(v25_12));
        join_wrapped_into(&mut v24_7_write,&((v25_13).read_zipper()),&[]);
        }
        v22_24_cursor.ascend(1);
      }
      drop(v24_7_write);
      map_map_kernels::compose(&(v23_5),&(v24_7))
    };
    drop(v23_5);
    let v23_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v23_2));
    drop(v23_2);
    let v23_10: Space = if map_kernels::has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
    drop(v23_9);
    let v23_12: Space = if (&(v23_10)).is_empty() { Space::new() } else {
      let v34_6: Path = concat_path(&(*p0),&v22_24_cursor.path()[v22_24_origin..(v22_24_origin + 1)]);
      let mut v34_11 = Space::new();
      let mut v34_11_write = v34_11.write_zipper();
      for v34_11_byte in v22_24_cursor.child_mask().iter() {
        v22_24_cursor.descend_to_existing_byte(v34_11_byte);
        {
        let v35_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
        let v35_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v35_2));
        let v35_4: Space = if map_kernels::has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
        drop(v35_3);
        let v35_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v35_4));
        drop(v35_4);
        let v35_8: Space = if (&(v35_5)).is_empty() { Space::new() } else {
          let v36_6: Path = concat_path(&(v34_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v36_7 = Space::new();
          let mut v36_7_write = v36_7.write_zipper();
          for v36_7_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v36_7_byte);
            {
            let v37_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v37_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v37_2));
            let v37_4: Space = if map_kernels::has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
            drop(v37_3);
            let v37_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v37_4));
            drop(v37_4);
            let v37_8: Space = if (&(v37_5)).is_empty() { Space::new() } else {
              let v38_6: Path = concat_path(&(v36_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v38_7: Space = routine_6(c, &(v38_6), &v22_24_cursor, &(*s1));
              map_map_kernels::compose(&(v37_5),&(v38_7))
            };
            drop(v37_5);
            let v37_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v37_2));
            drop(v37_2);
            let v37_10: Space = if map_kernels::has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
            drop(v37_9);
            let v37_12: Space = if (&(v37_10)).is_empty() { Space::new() } else {
              let v39_6: Path = concat_path(&(v36_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v39_11: Space = routine_7(c, &(v39_6), &v22_24_cursor, &(*s1));
              drop(v39_6);
              map_map_kernels::compose(&(v37_10),&(v39_11))
            };
            drop(v37_10);
            let v37_13: Space = map_map_kernels::unite(&(v37_8),&(v37_12));
            join_wrapped_into(&mut v36_7_write,&((v37_13).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v36_7_write);
          map_map_kernels::compose(&(v35_5),&(v36_7))
        };
        drop(v35_5);
        let v35_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v35_2));
        drop(v35_2);
        let v35_10: Space = if map_kernels::has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
        drop(v35_9);
        let v35_12: Space = if (&(v35_10)).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v34_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v40_11 = Space::new();
          let mut v40_11_write = v40_11.write_zipper();
          for v40_11_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v40_11_byte);
            {
            let v41_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v41_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v41_2));
            let v41_4: Space = if map_kernels::has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v41_4));
            drop(v41_4);
            let v41_7: Space = if (&(v41_5)).is_empty() { Space::new() } else {
              let v42_6: Space = routine_4(c, &v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)], &(v40_6), &v22_24_cursor, &(*s1));
              map_map_kernels::compose(&(v41_5),&(v42_6))
            };
            drop(v41_5);
            let v41_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v41_2));
            drop(v41_2);
            let v41_9: Space = if map_kernels::has_head(&(v41_8)) { singleton(&[]) } else { Space::new() };
            drop(v41_8);
            let v41_11: Space = if (&(v41_9)).is_empty() { Space::new() } else {
              let v43_10: Space = routine_5(c, &v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)], &(v40_6), &v22_24_cursor, &(*s1));
              map_map_kernels::compose(&(v41_9),&(v43_10))
            };
            drop(v41_9);
            let v41_12: Space = map_map_kernels::unite(&(v41_7),&(v41_11));
            join_wrapped_into(&mut v40_11_write,&((v41_12).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v40_11_write);
          drop(v40_6);
          map_map_kernels::compose(&(v35_10),&(v40_11))
        };
        drop(v35_10);
        let v35_13: Space = map_map_kernels::unite(&(v35_8),&(v35_12));
        join_wrapped_into(&mut v34_11_write,&((v35_13).read_zipper()),&[]);
        }
        v22_24_cursor.ascend(1);
      }
      drop(v34_11_write);
      drop(v34_6);
      map_map_kernels::compose(&(v23_10),&(v34_11))
    };
    drop(v23_10);
    let v23_13: Space = map_map_kernels::unite(&(v23_8),&(v23_12));
    join_wrapped_into(&mut v22_24_write,&((v23_13).read_zipper()),&[]);
    }
    v22_24_cursor.ascend(1);
  }
  drop(v22_24_cursor);
  drop(v22_24_write);
  (v22_24).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v44_24 = Space::new();
  let mut v44_24_write = v44_24.write_zipper();
  let mut v44_24_cursor = (*s0).read_zipper();
  let v44_24_origin = v44_24_cursor.path().len();
  for v44_24_byte in v44_24_cursor.child_mask().iter() {
    v44_24_cursor.descend_to_existing_byte(v44_24_byte);
    {
    let v45_2: Space = singleton(&v44_24_cursor.path()[v44_24_origin..(v44_24_origin + 1)]);
    let v45_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v45_2));
    let v45_4: Space = if map_kernels::has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
    drop(v45_3);
    let v45_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v45_4));
    drop(v45_4);
    let v45_8: Space = if (&(v45_5)).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&v44_24_cursor.path()[v44_24_origin..(v44_24_origin + 1)]);
      let mut v46_7 = Space::new();
      let mut v46_7_write = v46_7.write_zipper();
      for v46_7_byte in v44_24_cursor.child_mask().iter() {
        v44_24_cursor.descend_to_existing_byte(v46_7_byte);
        {
        let v47_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
        let v47_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v47_2));
        let v47_4: Space = if map_kernels::has_head(&(v47_3)) { singleton(&[]) } else { Space::new() };
        drop(v47_3);
        let v47_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v47_4));
        drop(v47_4);
        let v47_8: Space = if (&(v47_5)).is_empty() { Space::new() } else {
          let v48_6: Path = concat_path(&(v46_6),&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
          let mut v48_7 = Space::new();
          let mut v48_7_write = v48_7.write_zipper();
          for v48_7_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v48_7_byte);
            {
            let v49_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v49_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v49_2));
            let v49_4: Space = if map_kernels::has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
            drop(v49_3);
            let v49_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v49_4));
            drop(v49_4);
            let v49_8: Space = if (&(v49_5)).is_empty() { Space::new() } else {
              let v50_6: Path = concat_path(&(v48_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v50_7: Space = routine_6(c, &(v50_6), &v44_24_cursor, &(*s1));
              map_map_kernels::compose(&(v49_5),&(v50_7))
            };
            drop(v49_5);
            let v49_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v49_2));
            drop(v49_2);
            let v49_10: Space = if map_kernels::has_head(&(v49_9)) { singleton(&[]) } else { Space::new() };
            drop(v49_9);
            let v49_12: Space = if (&(v49_10)).is_empty() { Space::new() } else {
              let v51_6: Path = concat_path(&(v48_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v51_11: Space = routine_7(c, &(v51_6), &v44_24_cursor, &(*s1));
              drop(v51_6);
              map_map_kernels::compose(&(v49_10),&(v51_11))
            };
            drop(v49_10);
            let v49_13: Space = map_map_kernels::unite(&(v49_8),&(v49_12));
            join_wrapped_into(&mut v48_7_write,&((v49_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v48_7_write);
          map_map_kernels::compose(&(v47_5),&(v48_7))
        };
        drop(v47_5);
        let v47_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v47_2));
        drop(v47_2);
        let v47_10: Space = if map_kernels::has_head(&(v47_9)) { singleton(&[]) } else { Space::new() };
        drop(v47_9);
        let v47_12: Space = if (&(v47_10)).is_empty() { Space::new() } else {
          let v52_6: Path = concat_path(&(v46_6),&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
          let mut v52_11 = Space::new();
          let mut v52_11_write = v52_11.write_zipper();
          for v52_11_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v52_11_byte);
            {
            let v53_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v53_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v53_2));
            let v53_4: Space = if map_kernels::has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
            drop(v53_3);
            let v53_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v53_4));
            drop(v53_4);
            let v53_8: Space = if (&(v53_5)).is_empty() { Space::new() } else {
              let v54_6: Path = concat_path(&(v52_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v54_7: Space = routine_6(c, &(v54_6), &v44_24_cursor, &(*s1));
              map_map_kernels::compose(&(v53_5),&(v54_7))
            };
            drop(v53_5);
            let v53_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v53_2));
            drop(v53_2);
            let v53_10: Space = if map_kernels::has_head(&(v53_9)) { singleton(&[]) } else { Space::new() };
            drop(v53_9);
            let v53_12: Space = if (&(v53_10)).is_empty() { Space::new() } else {
              let v55_6: Path = concat_path(&(v52_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v55_11: Space = routine_3(c, &(v55_6), &v44_24_cursor, &(*s1));
              drop(v55_6);
              map_map_kernels::compose(&(v53_10),&(v55_11))
            };
            drop(v53_10);
            let v53_13: Space = map_map_kernels::unite(&(v53_8),&(v53_12));
            join_wrapped_into(&mut v52_11_write,&((v53_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v52_11_write);
          drop(v52_6);
          map_map_kernels::compose(&(v47_10),&(v52_11))
        };
        drop(v47_10);
        let v47_13: Space = map_map_kernels::unite(&(v47_8),&(v47_12));
        join_wrapped_into(&mut v46_7_write,&((v47_13).read_zipper()),&[]);
        }
        v44_24_cursor.ascend(1);
      }
      drop(v46_7_write);
      map_map_kernels::compose(&(v45_5),&(v46_7))
    };
    drop(v45_5);
    let v45_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v45_2));
    drop(v45_2);
    let v45_10: Space = if map_kernels::has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
    drop(v45_9);
    let v45_12: Space = if (&(v45_10)).is_empty() { Space::new() } else {
      let v56_6: Path = concat_path(&(*p0),&v44_24_cursor.path()[v44_24_origin..(v44_24_origin + 1)]);
      let mut v56_11 = Space::new();
      let mut v56_11_write = v56_11.write_zipper();
      for v56_11_byte in v44_24_cursor.child_mask().iter() {
        v44_24_cursor.descend_to_existing_byte(v56_11_byte);
        {
        let v57_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
        let v57_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v57_2));
        let v57_4: Space = if map_kernels::has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v57_4));
        drop(v57_4);
        let v57_7: Space = if (&(v57_5)).is_empty() { Space::new() } else {
          let mut v58_6 = Space::new();
          let mut v58_6_write = v58_6.write_zipper();
          for v58_6_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v58_6_byte);
            {
            let v59_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v59_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v59_2));
            let v59_4: Space = if map_kernels::has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
            drop(v59_3);
            let v59_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v59_4));
            drop(v59_4);
            let v59_8: Space = if (&(v59_5)).is_empty() { Space::new() } else {
              let v60_7: Space = routine_8(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              map_map_kernels::compose(&(v59_5),&(v60_7))
            };
            drop(v59_5);
            let v59_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v59_2));
            drop(v59_2);
            let v59_10: Space = if map_kernels::has_head(&(v59_9)) { singleton(&[]) } else { Space::new() };
            drop(v59_9);
            let v59_12: Space = if (&(v59_10)).is_empty() { Space::new() } else {
              let v61_11: Space = routine_9(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              map_map_kernels::compose(&(v59_10),&(v61_11))
            };
            drop(v59_10);
            let v59_13: Space = map_map_kernels::unite(&(v59_8),&(v59_12));
            join_wrapped_into(&mut v58_6_write,&((v59_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v58_6_write);
          map_map_kernels::compose(&(v57_5),&(v58_6))
        };
        drop(v57_5);
        let v57_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v57_2));
        drop(v57_2);
        let v57_9: Space = if map_kernels::has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
        drop(v57_8);
        let v57_11: Space = if (&(v57_9)).is_empty() { Space::new() } else {
          let mut v62_10 = Space::new();
          let mut v62_10_write = v62_10.write_zipper();
          for v62_10_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v62_10_byte);
            {
            let v63_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v63_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v63_2));
            let v63_4: Space = if map_kernels::has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
            drop(v63_3);
            let v63_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v63_4));
            drop(v63_4);
            let v63_8: Space = if (&(v63_5)).is_empty() { Space::new() } else {
              let v64_7: Space = routine_8(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              map_map_kernels::compose(&(v63_5),&(v64_7))
            };
            drop(v63_5);
            let v63_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v63_2));
            drop(v63_2);
            let v63_10: Space = if map_kernels::has_head(&(v63_9)) { singleton(&[]) } else { Space::new() };
            drop(v63_9);
            let v63_12: Space = if (&(v63_10)).is_empty() { Space::new() } else {
              let v65_11: Space = routine_10(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              map_map_kernels::compose(&(v63_10),&(v65_11))
            };
            drop(v63_10);
            let v63_13: Space = map_map_kernels::unite(&(v63_8),&(v63_12));
            join_wrapped_into(&mut v62_10_write,&((v63_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v62_10_write);
          map_map_kernels::compose(&(v57_9),&(v62_10))
        };
        drop(v57_9);
        let v57_12: Space = map_map_kernels::unite(&(v57_7),&(v57_11));
        join_wrapped_into(&mut v56_11_write,&((v57_12).read_zipper()),&[]);
        }
        v44_24_cursor.ascend(1);
      }
      drop(v56_11_write);
      drop(v56_6);
      map_map_kernels::compose(&(v45_10),&(v56_11))
    };
    drop(v45_10);
    let v45_13: Space = map_map_kernels::unite(&(v45_8),&(v45_12));
    join_wrapped_into(&mut v44_24_write,&((v45_13).read_zipper()),&[]);
    }
    v44_24_cursor.ascend(1);
  }
  drop(v44_24_cursor);
  drop(v44_24_write);
  (v44_24).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v66_26 = Space::new();
  let mut v66_26_write = v66_26.write_zipper();
  let mut v66_26_cursor = (*s0).read_zipper();
  let v66_26_origin = v66_26_cursor.path().len();
  for v66_26_byte in v66_26_cursor.child_mask().iter() {
    v66_26_cursor.descend_to_existing_byte(v66_26_byte);
    {
    let v67_2: Space = singleton(&v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 1)]);
    let v67_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v67_2));
    let v67_4: Space = if map_kernels::has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
    drop(v67_3);
    let v67_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v67_4));
    drop(v67_4);
    let v67_7: Space = if (&(v67_5)).is_empty() { Space::new() } else {
      let mut v68_6 = Space::new();
      let mut v68_6_write = v68_6.write_zipper();
      for v68_6_byte in v66_26_cursor.child_mask().iter() {
        v66_26_cursor.descend_to_existing_byte(v68_6_byte);
        {
        let v69_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 1)..(v66_26_origin + 2)]);
        let v69_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v69_2));
        let v69_4: Space = if map_kernels::has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
        drop(v69_3);
        let v69_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v69_4));
        drop(v69_4);
        let v69_8: Space = if (&(v69_5)).is_empty() { Space::new() } else {
          let mut v70_7 = Space::new();
          let mut v70_7_write = v70_7.write_zipper();
          for v70_7_byte in v66_26_cursor.child_mask().iter() {
            v66_26_cursor.descend_to_existing_byte(v70_7_byte);
            {
            let v71_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 2)..(v66_26_origin + 3)]);
            let v71_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v71_2));
            let v71_4: Space = if map_kernels::has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
            drop(v71_3);
            let v71_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v71_4));
            drop(v71_4);
            let v71_8: Space = if (&(v71_5)).is_empty() { Space::new() } else {
              let v72_7: Space = routine_11(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              map_map_kernels::compose(&(v71_5),&(v72_7))
            };
            drop(v71_5);
            let v71_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v71_2));
            drop(v71_2);
            let v71_10: Space = if map_kernels::has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
            drop(v71_9);
            let v71_12: Space = if (&(v71_10)).is_empty() { Space::new() } else {
              let v73_11: Space = routine_12(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              map_map_kernels::compose(&(v71_10),&(v73_11))
            };
            drop(v71_10);
            let v71_13: Space = map_map_kernels::unite(&(v71_8),&(v71_12));
            join_wrapped_into(&mut v70_7_write,&((v71_13).read_zipper()),&[]);
            }
            v66_26_cursor.ascend(1);
          }
          drop(v70_7_write);
          map_map_kernels::compose(&(v69_5),&(v70_7))
        };
        drop(v69_5);
        let v69_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v69_2));
        drop(v69_2);
        let v69_10: Space = if map_kernels::has_head(&(v69_9)) { singleton(&[]) } else { Space::new() };
        drop(v69_9);
        let v69_12: Space = if (&(v69_10)).is_empty() { Space::new() } else {
          let mut v74_11 = Space::new();
          let mut v74_11_write = v74_11.write_zipper();
          for v74_11_byte in v66_26_cursor.child_mask().iter() {
            v66_26_cursor.descend_to_existing_byte(v74_11_byte);
            {
            let v75_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 2)..(v66_26_origin + 3)]);
            let v75_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v75_2));
            let v75_4: Space = if map_kernels::has_head(&(v75_3)) { singleton(&[]) } else { Space::new() };
            drop(v75_3);
            let v75_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v75_4));
            drop(v75_4);
            let v75_8: Space = if (&(v75_5)).is_empty() { Space::new() } else {
              let v76_7: Space = routine_11(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              map_map_kernels::compose(&(v75_5),&(v76_7))
            };
            drop(v75_5);
            let v75_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v75_2));
            drop(v75_2);
            let v75_10: Space = if map_kernels::has_head(&(v75_9)) { singleton(&[]) } else { Space::new() };
            drop(v75_9);
            let v75_12: Space = if (&(v75_10)).is_empty() { Space::new() } else {
              let v77_11: Space = routine_10(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              map_map_kernels::compose(&(v75_10),&(v77_11))
            };
            drop(v75_10);
            let v75_13: Space = map_map_kernels::unite(&(v75_8),&(v75_12));
            join_wrapped_into(&mut v74_11_write,&((v75_13).read_zipper()),&[]);
            }
            v66_26_cursor.ascend(1);
          }
          drop(v74_11_write);
          map_map_kernels::compose(&(v69_10),&(v74_11))
        };
        drop(v69_10);
        let v69_13: Space = map_map_kernels::unite(&(v69_8),&(v69_12));
        join_wrapped_into(&mut v68_6_write,&((v69_13).read_zipper()),&[]);
        }
        v66_26_cursor.ascend(1);
      }
      drop(v68_6_write);
      map_map_kernels::compose(&(v67_5),&(v68_6))
    };
    drop(v67_5);
    let v67_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v67_2));
    drop(v67_2);
    let v67_9: Space = if map_kernels::has_head(&(v67_8)) { singleton(&[]) } else { Space::new() };
    drop(v67_8);
    let v67_12: Space = if (&(v67_9)).is_empty() { Space::new() } else {
      let mut v78_11 = Space::new();
      let mut v78_11_write = v78_11.write_zipper();
      for v78_11_byte in v66_26_cursor.child_mask().iter() {
        v66_26_cursor.descend_to_existing_byte(v78_11_byte);
        {
        let v79_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 1)..(v66_26_origin + 2)]);
        let v79_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v79_2));
        let v79_4: Space = if map_kernels::has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
        drop(v79_3);
        let v79_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v79_4));
        drop(v79_4);
        let v79_8: Space = if (&(v79_5)).is_empty() { Space::new() } else {
          let mut v80_7 = Space::new();
          let mut v80_7_write = v80_7.write_zipper();
          for v80_7_byte in v66_26_cursor.child_mask().iter() {
            v66_26_cursor.descend_to_existing_byte(v80_7_byte);
            {
            let v81_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 2)..(v66_26_origin + 3)]);
            let v81_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v81_2));
            let v81_4: Space = if map_kernels::has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
            drop(v81_3);
            let v81_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v81_4));
            drop(v81_4);
            let v81_8: Space = if (&(v81_5)).is_empty() { Space::new() } else {
              let v82_7: Space = routine_11(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              map_map_kernels::compose(&(v81_5),&(v82_7))
            };
            drop(v81_5);
            let v81_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v81_2));
            drop(v81_2);
            let v81_10: Space = if map_kernels::has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
            drop(v81_9);
            let v81_12: Space = if (&(v81_10)).is_empty() { Space::new() } else {
              let v83_11: Space = routine_12(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              map_map_kernels::compose(&(v81_10),&(v83_11))
            };
            drop(v81_10);
            let v81_13: Space = map_map_kernels::unite(&(v81_8),&(v81_12));
            join_wrapped_into(&mut v80_7_write,&((v81_13).read_zipper()),&[]);
            }
            v66_26_cursor.ascend(1);
          }
          drop(v80_7_write);
          map_map_kernels::compose(&(v79_5),&(v80_7))
        };
        drop(v79_5);
        let v79_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v79_2));
        drop(v79_2);
        let v79_10: Space = if map_kernels::has_head(&(v79_9)) { singleton(&[]) } else { Space::new() };
        drop(v79_9);
        let v79_13: Space = if (&(v79_10)).is_empty() { Space::new() } else {
          let mut v84_12 = Space::new();
          let mut v84_12_write = v84_12.write_zipper();
          let mut v84_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 1)]),&v66_26_cursor.path()[(v66_26_origin + 1)..(v66_26_origin + 2)]);
          let v84_12_origin = v84_12_cursor.path().len();
          for v84_12_byte in v84_12_cursor.child_mask().iter() {
            v84_12_cursor.descend_to_existing_byte(v84_12_byte);
            {
            let v85_2: Space = singleton(&v84_12_cursor.path()[v84_12_origin..(v84_12_origin + 1)]);
            let v85_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v85_2));
            let v85_4: Space = if map_kernels::has_head(&(v85_3)) { singleton(&[]) } else { Space::new() };
            drop(v85_3);
            let v85_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v85_4));
            drop(v85_4);
            let v85_7: Space = if (&(v85_5)).is_empty() { Space::new() } else {
              let v86_6: Space = routine_13(c, &v84_12_cursor.path()[v84_12_origin..(v84_12_origin + 1)], &(*p0), &v84_12_cursor);
              map_map_kernels::compose(&(v85_5),&(v86_6))
            };
            drop(v85_5);
            let v85_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v85_2));
            drop(v85_2);
            let v85_9: Space = if map_kernels::has_head(&(v85_8)) { singleton(&[]) } else { Space::new() };
            drop(v85_8);
            let v85_11: Space = if (&(v85_9)).is_empty() { Space::new() } else {
              let v87_10: Space = routine_14(c, &v84_12_cursor.path()[v84_12_origin..(v84_12_origin + 1)], &(*p0), &v84_12_cursor);
              map_map_kernels::compose(&(v85_9),&(v87_10))
            };
            drop(v85_9);
            let v85_12: Space = map_map_kernels::unite(&(v85_7),&(v85_11));
            join_wrapped_into(&mut v84_12_write,&((v85_12).read_zipper()),&[]);
            }
            v84_12_cursor.ascend(1);
          }
          drop(v84_12_cursor);
          drop(v84_12_write);
          map_map_kernels::compose(&(v79_10),&(v84_12))
        };
        drop(v79_10);
        let v79_14: Space = map_map_kernels::unite(&(v79_8),&(v79_13));
        join_wrapped_into(&mut v78_11_write,&((v79_14).read_zipper()),&[]);
        }
        v66_26_cursor.ascend(1);
      }
      drop(v78_11_write);
      map_map_kernels::compose(&(v67_9),&(v78_11))
    };
    drop(v67_9);
    let v67_13: Space = map_map_kernels::unite(&(v67_7),&(v67_12));
    join_wrapped_into(&mut v66_26_write,&((v67_13).read_zipper()),&[]);
    }
    v66_26_cursor.ascend(1);
  }
  drop(v66_26_cursor);
  drop(v66_26_write);
  (v66_26).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v88_28 = Space::new();
  let mut v88_28_write = v88_28.write_zipper();
  let mut v88_28_cursor = (*s0).read_zipper();
  let v88_28_origin = v88_28_cursor.path().len();
  for v88_28_byte in v88_28_cursor.child_mask().iter() {
    v88_28_cursor.descend_to_existing_byte(v88_28_byte);
    {
    let v89_2: Space = singleton(&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]);
    let v89_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v89_2));
    let v89_4: Space = if map_kernels::has_head(&(v89_3)) { singleton(&[]) } else { Space::new() };
    drop(v89_3);
    let v89_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v89_4));
    drop(v89_4);
    let v89_8: Space = if (&(v89_5)).is_empty() { Space::new() } else {
      let v90_6: Path = concat_path(&(*p0),&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]);
      let mut v90_7 = Space::new();
      let mut v90_7_write = v90_7.write_zipper();
      for v90_7_byte in v88_28_cursor.child_mask().iter() {
        v88_28_cursor.descend_to_existing_byte(v90_7_byte);
        {
        let v91_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
        let v91_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v91_2));
        let v91_4: Space = if map_kernels::has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
        drop(v91_3);
        let v91_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v91_4));
        drop(v91_4);
        let v91_8: Space = if (&(v91_5)).is_empty() { Space::new() } else {
          let v92_6: Path = concat_path(&(v90_6),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let mut v92_7 = Space::new();
          let mut v92_7_write = v92_7.write_zipper();
          for v92_7_byte in v88_28_cursor.child_mask().iter() {
            v88_28_cursor.descend_to_existing_byte(v92_7_byte);
            {
            let v93_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
            let v93_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v93_2));
            let v93_4: Space = if map_kernels::has_head(&(v93_3)) { singleton(&[]) } else { Space::new() };
            drop(v93_3);
            let v93_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v93_4));
            drop(v93_4);
            let v93_8: Space = if (&(v93_5)).is_empty() { Space::new() } else {
              let v94_6: Path = concat_path(&(v92_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v94_7: Space = routine_15(c, &(v94_6), &(*p1), &v88_28_cursor, &(*s1));
              map_map_kernels::compose(&(v93_5),&(v94_7))
            };
            drop(v93_5);
            let v93_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v93_2));
            drop(v93_2);
            let v93_10: Space = if map_kernels::has_head(&(v93_9)) { singleton(&[]) } else { Space::new() };
            drop(v93_9);
            let v93_12: Space = if (&(v93_10)).is_empty() { Space::new() } else {
              let v95_6: Path = concat_path(&(v92_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v95_11: Space = routine_16(c, &(v95_6), &(*p1), &v88_28_cursor, &(*s1));
              drop(v95_6);
              map_map_kernels::compose(&(v93_10),&(v95_11))
            };
            drop(v93_10);
            let v93_13: Space = map_map_kernels::unite(&(v93_8),&(v93_12));
            join_wrapped_into(&mut v92_7_write,&((v93_13).read_zipper()),&[]);
            }
            v88_28_cursor.ascend(1);
          }
          drop(v92_7_write);
          map_map_kernels::compose(&(v91_5),&(v92_7))
        };
        drop(v91_5);
        let v91_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v91_2));
        drop(v91_2);
        let v91_10: Space = if map_kernels::has_head(&(v91_9)) { singleton(&[]) } else { Space::new() };
        drop(v91_9);
        let v91_12: Space = if (&(v91_10)).is_empty() { Space::new() } else {
          let v96_6: Path = concat_path(&(v90_6),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let mut v96_11 = Space::new();
          let mut v96_11_write = v96_11.write_zipper();
          for v96_11_byte in v88_28_cursor.child_mask().iter() {
            v88_28_cursor.descend_to_existing_byte(v96_11_byte);
            {
            let v97_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
            let v97_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v97_2));
            let v97_4: Space = if map_kernels::has_head(&(v97_3)) { singleton(&[]) } else { Space::new() };
            drop(v97_3);
            let v97_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v97_4));
            drop(v97_4);
            let v97_8: Space = if (&(v97_5)).is_empty() { Space::new() } else {
              let v98_6: Path = concat_path(&(v96_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v98_7: Space = routine_15(c, &(v98_6), &(*p1), &v88_28_cursor, &(*s1));
              map_map_kernels::compose(&(v97_5),&(v98_7))
            };
            drop(v97_5);
            let v97_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v97_2));
            drop(v97_2);
            let v97_10: Space = if map_kernels::has_head(&(v97_9)) { singleton(&[]) } else { Space::new() };
            drop(v97_9);
            let v97_12: Space = if (&(v97_10)).is_empty() { Space::new() } else {
              let v99_6: Path = concat_path(&(v96_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v99_11: Space = routine_10(c, &(v99_6), &(*p1), &v88_28_cursor, &(*s1));
              drop(v99_6);
              map_map_kernels::compose(&(v97_10),&(v99_11))
            };
            drop(v97_10);
            let v97_13: Space = map_map_kernels::unite(&(v97_8),&(v97_12));
            join_wrapped_into(&mut v96_11_write,&((v97_13).read_zipper()),&[]);
            }
            v88_28_cursor.ascend(1);
          }
          drop(v96_11_write);
          drop(v96_6);
          map_map_kernels::compose(&(v91_10),&(v96_11))
        };
        drop(v91_10);
        let v91_13: Space = map_map_kernels::unite(&(v91_8),&(v91_12));
        join_wrapped_into(&mut v90_7_write,&((v91_13).read_zipper()),&[]);
        }
        v88_28_cursor.ascend(1);
      }
      drop(v90_7_write);
      map_map_kernels::compose(&(v89_5),&(v90_7))
    };
    drop(v89_5);
    let v89_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v89_2));
    drop(v89_2);
    let v89_10: Space = if map_kernels::has_head(&(v89_9)) { singleton(&[]) } else { Space::new() };
    drop(v89_9);
    let v89_13: Space = if (&(v89_10)).is_empty() { Space::new() } else {
      let v100_6: Path = concat_path(&(*p0),&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]);
      let mut v100_12 = Space::new();
      let mut v100_12_write = v100_12.write_zipper();
      for v100_12_byte in v88_28_cursor.child_mask().iter() {
        v88_28_cursor.descend_to_existing_byte(v100_12_byte);
        {
        let v101_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
        let v101_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v101_2));
        let v101_4: Space = if map_kernels::has_head(&(v101_3)) { singleton(&[]) } else { Space::new() };
        drop(v101_3);
        let v101_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v101_4));
        drop(v101_4);
        let v101_8: Space = if (&(v101_5)).is_empty() { Space::new() } else {
          let v102_6: Path = concat_path(&(v100_6),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let mut v102_7 = Space::new();
          let mut v102_7_write = v102_7.write_zipper();
          for v102_7_byte in v88_28_cursor.child_mask().iter() {
            v88_28_cursor.descend_to_existing_byte(v102_7_byte);
            {
            let v103_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
            let v103_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v103_2));
            let v103_4: Space = if map_kernels::has_head(&(v103_3)) { singleton(&[]) } else { Space::new() };
            drop(v103_3);
            let v103_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v103_4));
            drop(v103_4);
            let v103_8: Space = if (&(v103_5)).is_empty() { Space::new() } else {
              let v104_6: Path = concat_path(&(v102_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v104_7: Space = routine_15(c, &(v104_6), &(*p1), &v88_28_cursor, &(*s1));
              map_map_kernels::compose(&(v103_5),&(v104_7))
            };
            drop(v103_5);
            let v103_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v103_2));
            drop(v103_2);
            let v103_10: Space = if map_kernels::has_head(&(v103_9)) { singleton(&[]) } else { Space::new() };
            drop(v103_9);
            let v103_12: Space = if (&(v103_10)).is_empty() { Space::new() } else {
              let v105_6: Path = concat_path(&(v102_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v105_11: Space = routine_16(c, &(v105_6), &(*p1), &v88_28_cursor, &(*s1));
              drop(v105_6);
              map_map_kernels::compose(&(v103_10),&(v105_11))
            };
            drop(v103_10);
            let v103_13: Space = map_map_kernels::unite(&(v103_8),&(v103_12));
            join_wrapped_into(&mut v102_7_write,&((v103_13).read_zipper()),&[]);
            }
            v88_28_cursor.ascend(1);
          }
          drop(v102_7_write);
          drop(v102_6);
          map_map_kernels::compose(&(v101_5),&(v102_7))
        };
        drop(v101_5);
        let v101_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v101_2));
        drop(v101_2);
        let v101_10: Space = if map_kernels::has_head(&(v101_9)) { singleton(&[]) } else { Space::new() };
        drop(v101_9);
        let v101_13: Space = if (&(v101_10)).is_empty() { Space::new() } else {
          let mut v106_12 = Space::new();
          let mut v106_12_write = v106_12.write_zipper();
          let mut v106_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let v106_12_origin = v106_12_cursor.path().len();
          for v106_12_byte in v106_12_cursor.child_mask().iter() {
            v106_12_cursor.descend_to_existing_byte(v106_12_byte);
            {
            let v107_2: Space = singleton(&v106_12_cursor.path()[v106_12_origin..(v106_12_origin + 1)]);
            let v107_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v107_2));
            let v107_4: Space = if map_kernels::has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
            drop(v107_3);
            let v107_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v107_4));
            drop(v107_4);
            let v107_7: Space = if (&(v107_5)).is_empty() { Space::new() } else {
              let v108_6: Space = routine_13(c, &v106_12_cursor.path()[v106_12_origin..(v106_12_origin + 1)], &(*p1), &v106_12_cursor);
              map_map_kernels::compose(&(v107_5),&(v108_6))
            };
            drop(v107_5);
            let v107_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v107_2));
            drop(v107_2);
            let v107_9: Space = if map_kernels::has_head(&(v107_8)) { singleton(&[]) } else { Space::new() };
            drop(v107_8);
            let v107_11: Space = if (&(v107_9)).is_empty() { Space::new() } else {
              let v109_10: Space = routine_14(c, &v106_12_cursor.path()[v106_12_origin..(v106_12_origin + 1)], &(*p1), &v106_12_cursor);
              map_map_kernels::compose(&(v107_9),&(v109_10))
            };
            drop(v107_9);
            let v107_12: Space = map_map_kernels::unite(&(v107_7),&(v107_11));
            join_wrapped_into(&mut v106_12_write,&((v107_12).read_zipper()),&[]);
            }
            v106_12_cursor.ascend(1);
          }
          drop(v106_12_cursor);
          drop(v106_12_write);
          map_map_kernels::compose(&(v101_10),&(v106_12))
        };
        drop(v101_10);
        let v101_14: Space = map_map_kernels::unite(&(v101_8),&(v101_13));
        join_wrapped_into(&mut v100_12_write,&((v101_14).read_zipper()),&[]);
        }
        v88_28_cursor.ascend(1);
      }
      drop(v100_12_write);
      drop(v100_6);
      map_map_kernels::compose(&(v89_10),&(v100_12))
    };
    drop(v89_10);
    let v89_14: Space = map_map_kernels::unite(&(v89_8),&(v89_13));
    join_wrapped_into(&mut v88_28_write,&((v89_14).read_zipper()),&[]);
    }
    v88_28_cursor.ascend(1);
  }
  drop(v88_28_cursor);
  drop(v88_28_write);
  (v88_28).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v110_28 = Space::new();
  let mut v110_28_write = v110_28.write_zipper();
  let mut v110_28_cursor = (*s0).read_zipper();
  let v110_28_origin = v110_28_cursor.path().len();
  for v110_28_byte in v110_28_cursor.child_mask().iter() {
    v110_28_cursor.descend_to_existing_byte(v110_28_byte);
    {
    let v111_2: Space = singleton(&v110_28_cursor.path()[v110_28_origin..(v110_28_origin + 1)]);
    let v111_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v111_2));
    let v111_4: Space = if map_kernels::has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
    drop(v111_3);
    let v111_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v111_4));
    drop(v111_4);
    let v111_8: Space = if (&(v111_5)).is_empty() { Space::new() } else {
      let v112_6: Path = concat_path(&(*p0),&v110_28_cursor.path()[v110_28_origin..(v110_28_origin + 1)]);
      let mut v112_7 = Space::new();
      let mut v112_7_write = v112_7.write_zipper();
      for v112_7_byte in v110_28_cursor.child_mask().iter() {
        v110_28_cursor.descend_to_existing_byte(v112_7_byte);
        {
        let v113_2: Space = singleton(&v110_28_cursor.path()[(v110_28_origin + 1)..(v110_28_origin + 2)]);
        let v113_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v113_2));
        let v113_4: Space = if map_kernels::has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
        drop(v113_3);
        let v113_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v113_4));
        drop(v113_4);
        let v113_8: Space = if (&(v113_5)).is_empty() { Space::new() } else {
          let v114_6: Path = concat_path(&(v112_6),&v110_28_cursor.path()[(v110_28_origin + 1)..(v110_28_origin + 2)]);
          let mut v114_7 = Space::new();
          let mut v114_7_write = v114_7.write_zipper();
          for v114_7_byte in v110_28_cursor.child_mask().iter() {
            v110_28_cursor.descend_to_existing_byte(v114_7_byte);
            {
            let v115_2: Space = singleton(&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
            let v115_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v115_2));
            let v115_4: Space = if map_kernels::has_head(&(v115_3)) { singleton(&[]) } else { Space::new() };
            drop(v115_3);
            let v115_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v115_4));
            drop(v115_4);
            let v115_8: Space = if (&(v115_5)).is_empty() { Space::new() } else {
              let v116_6: Path = concat_path(&(v114_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v116_7: Space = routine_15(c, &(v116_6), &(*p1), &v110_28_cursor, &(*s1));
              map_map_kernels::compose(&(v115_5),&(v116_7))
            };
            drop(v115_5);
            let v115_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v115_2));
            drop(v115_2);
            let v115_10: Space = if map_kernels::has_head(&(v115_9)) { singleton(&[]) } else { Space::new() };
            drop(v115_9);
            let v115_12: Space = if (&(v115_10)).is_empty() { Space::new() } else {
              let v117_6: Path = concat_path(&(v114_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v117_11: Space = routine_16(c, &(v117_6), &(*p1), &v110_28_cursor, &(*s1));
              drop(v117_6);
              map_map_kernels::compose(&(v115_10),&(v117_11))
            };
            drop(v115_10);
            let v115_13: Space = map_map_kernels::unite(&(v115_8),&(v115_12));
            join_wrapped_into(&mut v114_7_write,&((v115_13).read_zipper()),&[]);
            }
            v110_28_cursor.ascend(1);
          }
          drop(v114_7_write);
          map_map_kernels::compose(&(v113_5),&(v114_7))
        };
        drop(v113_5);
        let v113_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v113_2));
        drop(v113_2);
        let v113_10: Space = if map_kernels::has_head(&(v113_9)) { singleton(&[]) } else { Space::new() };
        drop(v113_9);
        let v113_12: Space = if (&(v113_10)).is_empty() { Space::new() } else {
          let v118_6: Path = concat_path(&(v112_6),&v110_28_cursor.path()[(v110_28_origin + 1)..(v110_28_origin + 2)]);
          let mut v118_11 = Space::new();
          let mut v118_11_write = v118_11.write_zipper();
          for v118_11_byte in v110_28_cursor.child_mask().iter() {
            v110_28_cursor.descend_to_existing_byte(v118_11_byte);
            {
            let v119_2: Space = singleton(&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
            let v119_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v119_2));
            let v119_4: Space = if map_kernels::has_head(&(v119_3)) { singleton(&[]) } else { Space::new() };
            drop(v119_3);
            let v119_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v119_4));
            drop(v119_4);
            let v119_8: Space = if (&(v119_5)).is_empty() { Space::new() } else {
              let v120_6: Path = concat_path(&(v118_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v120_7: Space = routine_15(c, &(v120_6), &(*p1), &v110_28_cursor, &(*s1));
              map_map_kernels::compose(&(v119_5),&(v120_7))
            };
            drop(v119_5);
            let v119_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v119_2));
            drop(v119_2);
            let v119_10: Space = if map_kernels::has_head(&(v119_9)) { singleton(&[]) } else { Space::new() };
            drop(v119_9);
            let v119_12: Space = if (&(v119_10)).is_empty() { Space::new() } else {
              let v121_6: Path = concat_path(&(v118_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v121_11: Space = routine_10(c, &(v121_6), &(*p1), &v110_28_cursor, &(*s1));
              drop(v121_6);
              map_map_kernels::compose(&(v119_10),&(v121_11))
            };
            drop(v119_10);
            let v119_13: Space = map_map_kernels::unite(&(v119_8),&(v119_12));
            join_wrapped_into(&mut v118_11_write,&((v119_13).read_zipper()),&[]);
            }
            v110_28_cursor.ascend(1);
          }
          drop(v118_11_write);
          drop(v118_6);
          map_map_kernels::compose(&(v113_10),&(v118_11))
        };
        drop(v113_10);
        let v113_13: Space = map_map_kernels::unite(&(v113_8),&(v113_12));
        join_wrapped_into(&mut v112_7_write,&((v113_13).read_zipper()),&[]);
        }
        v110_28_cursor.ascend(1);
      }
      drop(v112_7_write);
      drop(v112_6);
      map_map_kernels::compose(&(v111_5),&(v112_7))
    };
    drop(v111_5);
    let v111_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v111_2));
    drop(v111_2);
    let v111_10: Space = if map_kernels::has_head(&(v111_9)) { singleton(&[]) } else { Space::new() };
    drop(v111_9);
    let v111_13: Space = if (&(v111_10)).is_empty() { Space::new() } else {
      let mut v122_12 = Space::new();
      let mut v122_12_write = v122_12.write_zipper();
      let mut v122_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v110_28_cursor.path()[v110_28_origin..(v110_28_origin + 1)]);
      let v122_12_origin = v122_12_cursor.path().len();
      for v122_12_byte in v122_12_cursor.child_mask().iter() {
        v122_12_cursor.descend_to_existing_byte(v122_12_byte);
        {
        let v123_2: Space = singleton(&v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 1)]);
        let v123_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v123_2));
        let v123_4: Space = if map_kernels::has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v123_4));
        drop(v123_4);
        let v123_7: Space = if (&(v123_5)).is_empty() { Space::new() } else {
          let mut v124_6 = Space::new();
          let mut v124_6_write = v124_6.write_zipper();
          for v124_6_byte in v122_12_cursor.child_mask().iter() {
            v122_12_cursor.descend_to_existing_byte(v124_6_byte);
            {
            let v125_2: Space = singleton(&v122_12_cursor.path()[(v122_12_origin + 1)..(v122_12_origin + 2)]);
            let v125_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v125_2));
            let v125_4: Space = if map_kernels::has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
            drop(v125_3);
            let v125_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v125_4));
            drop(v125_4);
            let v125_8: Space = if (&(v125_5)).is_empty() { Space::new() } else {
              let v126_7: Space = routine_17(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              map_map_kernels::compose(&(v125_5),&(v126_7))
            };
            drop(v125_5);
            let v125_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v125_2));
            drop(v125_2);
            let v125_10: Space = if map_kernels::has_head(&(v125_9)) { singleton(&[]) } else { Space::new() };
            drop(v125_9);
            let v125_12: Space = if (&(v125_10)).is_empty() { Space::new() } else {
              let v127_11: Space = routine_18(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              map_map_kernels::compose(&(v125_10),&(v127_11))
            };
            drop(v125_10);
            let v125_13: Space = map_map_kernels::unite(&(v125_8),&(v125_12));
            join_wrapped_into(&mut v124_6_write,&((v125_13).read_zipper()),&[]);
            }
            v122_12_cursor.ascend(1);
          }
          drop(v124_6_write);
          map_map_kernels::compose(&(v123_5),&(v124_6))
        };
        drop(v123_5);
        let v123_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v123_2));
        drop(v123_2);
        let v123_9: Space = if map_kernels::has_head(&(v123_8)) { singleton(&[]) } else { Space::new() };
        drop(v123_8);
        let v123_11: Space = if (&(v123_9)).is_empty() { Space::new() } else {
          let mut v128_10 = Space::new();
          let mut v128_10_write = v128_10.write_zipper();
          for v128_10_byte in v122_12_cursor.child_mask().iter() {
            v122_12_cursor.descend_to_existing_byte(v128_10_byte);
            {
            let v129_2: Space = singleton(&v122_12_cursor.path()[(v122_12_origin + 1)..(v122_12_origin + 2)]);
            let v129_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v129_2));
            let v129_4: Space = if map_kernels::has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
            drop(v129_3);
            let v129_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v129_4));
            drop(v129_4);
            let v129_8: Space = if (&(v129_5)).is_empty() { Space::new() } else {
              let v130_7: Space = routine_17(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              map_map_kernels::compose(&(v129_5),&(v130_7))
            };
            drop(v129_5);
            let v129_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v129_2));
            drop(v129_2);
            let v129_10: Space = if map_kernels::has_head(&(v129_9)) { singleton(&[]) } else { Space::new() };
            drop(v129_9);
            let v129_12: Space = if (&(v129_10)).is_empty() { Space::new() } else {
              let v131_11: Space = routine_19(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              map_map_kernels::compose(&(v129_10),&(v131_11))
            };
            drop(v129_10);
            let v129_13: Space = map_map_kernels::unite(&(v129_8),&(v129_12));
            join_wrapped_into(&mut v128_10_write,&((v129_13).read_zipper()),&[]);
            }
            v122_12_cursor.ascend(1);
          }
          drop(v128_10_write);
          map_map_kernels::compose(&(v123_9),&(v128_10))
        };
        drop(v123_9);
        let v123_12: Space = map_map_kernels::unite(&(v123_7),&(v123_11));
        join_wrapped_into(&mut v122_12_write,&((v123_12).read_zipper()),&[]);
        }
        v122_12_cursor.ascend(1);
      }
      drop(v122_12_cursor);
      drop(v122_12_write);
      map_map_kernels::compose(&(v111_10),&(v122_12))
    };
    drop(v111_10);
    let v111_14: Space = map_map_kernels::unite(&(v111_8),&(v111_13));
    join_wrapped_into(&mut v110_28_write,&((v111_14).read_zipper()),&[]);
    }
    v110_28_cursor.ascend(1);
  }
  drop(v110_28_cursor);
  drop(v110_28_write);
  (v110_28).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v132_24 = Space::new();
  let mut v132_24_write = v132_24.write_zipper();
  let mut v132_24_cursor = (*s0).read_zipper();
  let v132_24_origin = v132_24_cursor.path().len();
  for v132_24_byte in v132_24_cursor.child_mask().iter() {
    v132_24_cursor.descend_to_existing_byte(v132_24_byte);
    {
    let v133_2: Space = singleton(&v132_24_cursor.path()[v132_24_origin..(v132_24_origin + 1)]);
    let v133_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v133_2));
    let v133_4: Space = if map_kernels::has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
    drop(v133_3);
    let v133_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v133_4));
    drop(v133_4);
    let v133_8: Space = if (&(v133_5)).is_empty() { Space::new() } else {
      let v134_6: Path = concat_path(&(*p0),&v132_24_cursor.path()[v132_24_origin..(v132_24_origin + 1)]);
      let mut v134_7 = Space::new();
      let mut v134_7_write = v134_7.write_zipper();
      for v134_7_byte in v132_24_cursor.child_mask().iter() {
        v132_24_cursor.descend_to_existing_byte(v134_7_byte);
        {
        let v135_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
        let v135_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v135_2));
        let v135_4: Space = if map_kernels::has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
        drop(v135_3);
        let v135_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v135_4));
        drop(v135_4);
        let v135_8: Space = if (&(v135_5)).is_empty() { Space::new() } else {
          let v136_6: Path = concat_path(&(v134_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v136_7 = Space::new();
          let mut v136_7_write = v136_7.write_zipper();
          for v136_7_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v136_7_byte);
            {
            let v137_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v137_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v137_2));
            let v137_4: Space = if map_kernels::has_head(&(v137_3)) { singleton(&[]) } else { Space::new() };
            drop(v137_3);
            let v137_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v137_4));
            drop(v137_4);
            let v137_8: Space = if (&(v137_5)).is_empty() { Space::new() } else {
              let v138_6: Path = concat_path(&(v136_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v138_7: Space = routine_20(c, &(v138_6), &v132_24_cursor, &(*s1));
              map_map_kernels::compose(&(v137_5),&(v138_7))
            };
            drop(v137_5);
            let v137_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v137_2));
            drop(v137_2);
            let v137_10: Space = if map_kernels::has_head(&(v137_9)) { singleton(&[]) } else { Space::new() };
            drop(v137_9);
            let v137_12: Space = if (&(v137_10)).is_empty() { Space::new() } else {
              let v139_6: Path = concat_path(&(v136_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v139_11: Space = routine_21(c, &(v139_6), &v132_24_cursor, &(*s1));
              drop(v139_6);
              map_map_kernels::compose(&(v137_10),&(v139_11))
            };
            drop(v137_10);
            let v137_13: Space = map_map_kernels::unite(&(v137_8),&(v137_12));
            join_wrapped_into(&mut v136_7_write,&((v137_13).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v136_7_write);
          map_map_kernels::compose(&(v135_5),&(v136_7))
        };
        drop(v135_5);
        let v135_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v135_2));
        drop(v135_2);
        let v135_10: Space = if map_kernels::has_head(&(v135_9)) { singleton(&[]) } else { Space::new() };
        drop(v135_9);
        let v135_12: Space = if (&(v135_10)).is_empty() { Space::new() } else {
          let v140_6: Path = concat_path(&(v134_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v140_11 = Space::new();
          let mut v140_11_write = v140_11.write_zipper();
          for v140_11_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v140_11_byte);
            {
            let v141_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v141_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v141_2));
            let v141_4: Space = if map_kernels::has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
            drop(v141_3);
            let v141_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v141_4));
            drop(v141_4);
            let v141_8: Space = if (&(v141_5)).is_empty() { Space::new() } else {
              let v142_6: Path = concat_path(&(v140_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v142_7: Space = routine_20(c, &(v142_6), &v132_24_cursor, &(*s1));
              map_map_kernels::compose(&(v141_5),&(v142_7))
            };
            drop(v141_5);
            let v141_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v141_2));
            drop(v141_2);
            let v141_10: Space = if map_kernels::has_head(&(v141_9)) { singleton(&[]) } else { Space::new() };
            drop(v141_9);
            let v141_12: Space = if (&(v141_10)).is_empty() { Space::new() } else {
              let v143_6: Path = concat_path(&(v140_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v143_11: Space = routine_3(c, &(v143_6), &v132_24_cursor, &(*s1));
              drop(v143_6);
              map_map_kernels::compose(&(v141_10),&(v143_11))
            };
            drop(v141_10);
            let v141_13: Space = map_map_kernels::unite(&(v141_8),&(v141_12));
            join_wrapped_into(&mut v140_11_write,&((v141_13).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v140_11_write);
          drop(v140_6);
          map_map_kernels::compose(&(v135_10),&(v140_11))
        };
        drop(v135_10);
        let v135_13: Space = map_map_kernels::unite(&(v135_8),&(v135_12));
        join_wrapped_into(&mut v134_7_write,&((v135_13).read_zipper()),&[]);
        }
        v132_24_cursor.ascend(1);
      }
      drop(v134_7_write);
      map_map_kernels::compose(&(v133_5),&(v134_7))
    };
    drop(v133_5);
    let v133_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v133_2));
    drop(v133_2);
    let v133_10: Space = if map_kernels::has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
    drop(v133_9);
    let v133_12: Space = if (&(v133_10)).is_empty() { Space::new() } else {
      let v144_6: Path = concat_path(&(*p0),&v132_24_cursor.path()[v132_24_origin..(v132_24_origin + 1)]);
      let mut v144_11 = Space::new();
      let mut v144_11_write = v144_11.write_zipper();
      for v144_11_byte in v132_24_cursor.child_mask().iter() {
        v132_24_cursor.descend_to_existing_byte(v144_11_byte);
        {
        let v145_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
        let v145_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v145_2));
        let v145_4: Space = if map_kernels::has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
        drop(v145_3);
        let v145_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v145_4));
        drop(v145_4);
        let v145_8: Space = if (&(v145_5)).is_empty() { Space::new() } else {
          let v146_6: Path = concat_path(&(v144_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v146_7 = Space::new();
          let mut v146_7_write = v146_7.write_zipper();
          for v146_7_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v146_7_byte);
            {
            let v147_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v147_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v147_2));
            let v147_4: Space = if map_kernels::has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
            drop(v147_3);
            let v147_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v147_4));
            drop(v147_4);
            let v147_8: Space = if (&(v147_5)).is_empty() { Space::new() } else {
              let v148_6: Path = concat_path(&(v146_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v148_7: Space = routine_20(c, &(v148_6), &v132_24_cursor, &(*s1));
              map_map_kernels::compose(&(v147_5),&(v148_7))
            };
            drop(v147_5);
            let v147_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v147_2));
            drop(v147_2);
            let v147_10: Space = if map_kernels::has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
            drop(v147_9);
            let v147_12: Space = if (&(v147_10)).is_empty() { Space::new() } else {
              let v149_6: Path = concat_path(&(v146_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v149_11: Space = routine_21(c, &(v149_6), &v132_24_cursor, &(*s1));
              drop(v149_6);
              map_map_kernels::compose(&(v147_10),&(v149_11))
            };
            drop(v147_10);
            let v147_13: Space = map_map_kernels::unite(&(v147_8),&(v147_12));
            join_wrapped_into(&mut v146_7_write,&((v147_13).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v146_7_write);
          map_map_kernels::compose(&(v145_5),&(v146_7))
        };
        drop(v145_5);
        let v145_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v145_2));
        drop(v145_2);
        let v145_10: Space = if map_kernels::has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
        drop(v145_9);
        let v145_12: Space = if (&(v145_10)).is_empty() { Space::new() } else {
          let v150_6: Path = concat_path(&(v144_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v150_11 = Space::new();
          let mut v150_11_write = v150_11.write_zipper();
          for v150_11_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v150_11_byte);
            {
            let v151_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v151_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v151_2));
            let v151_4: Space = if map_kernels::has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
            drop(v151_3);
            let v151_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v151_4));
            drop(v151_4);
            let v151_7: Space = if (&(v151_5)).is_empty() { Space::new() } else {
              let v152_6: Space = routine_4(c, &v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)], &(v150_6), &v132_24_cursor, &(*s1));
              map_map_kernels::compose(&(v151_5),&(v152_6))
            };
            drop(v151_5);
            let v151_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v151_2));
            drop(v151_2);
            let v151_9: Space = if map_kernels::has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
            drop(v151_8);
            let v151_11: Space = if (&(v151_9)).is_empty() { Space::new() } else {
              let v153_10: Space = routine_5(c, &v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)], &(v150_6), &v132_24_cursor, &(*s1));
              map_map_kernels::compose(&(v151_9),&(v153_10))
            };
            drop(v151_9);
            let v151_12: Space = map_map_kernels::unite(&(v151_7),&(v151_11));
            join_wrapped_into(&mut v150_11_write,&((v151_12).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v150_11_write);
          drop(v150_6);
          map_map_kernels::compose(&(v145_10),&(v150_11))
        };
        drop(v145_10);
        let v145_13: Space = map_map_kernels::unite(&(v145_8),&(v145_12));
        join_wrapped_into(&mut v144_11_write,&((v145_13).read_zipper()),&[]);
        }
        v132_24_cursor.ascend(1);
      }
      drop(v144_11_write);
      drop(v144_6);
      map_map_kernels::compose(&(v133_10),&(v144_11))
    };
    drop(v133_10);
    let v133_13: Space = map_map_kernels::unite(&(v133_8),&(v133_12));
    join_wrapped_into(&mut v132_24_write,&((v133_13).read_zipper()),&[]);
    }
    v132_24_cursor.ascend(1);
  }
  drop(v132_24_cursor);
  drop(v132_24_write);
  (v132_24).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v154_24 = Space::new();
  let mut v154_24_write = v154_24.write_zipper();
  let mut v154_24_cursor = (*s0).read_zipper();
  let v154_24_origin = v154_24_cursor.path().len();
  for v154_24_byte in v154_24_cursor.child_mask().iter() {
    v154_24_cursor.descend_to_existing_byte(v154_24_byte);
    {
    let v155_2: Space = singleton(&v154_24_cursor.path()[v154_24_origin..(v154_24_origin + 1)]);
    let v155_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v155_2));
    let v155_4: Space = if map_kernels::has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
    drop(v155_3);
    let v155_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v155_4));
    drop(v155_4);
    let v155_8: Space = if (&(v155_5)).is_empty() { Space::new() } else {
      let v156_6: Path = concat_path(&(*p0),&v154_24_cursor.path()[v154_24_origin..(v154_24_origin + 1)]);
      let mut v156_7 = Space::new();
      let mut v156_7_write = v156_7.write_zipper();
      for v156_7_byte in v154_24_cursor.child_mask().iter() {
        v154_24_cursor.descend_to_existing_byte(v156_7_byte);
        {
        let v157_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
        let v157_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v157_2));
        let v157_4: Space = if map_kernels::has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
        drop(v157_3);
        let v157_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v157_4));
        drop(v157_4);
        let v157_8: Space = if (&(v157_5)).is_empty() { Space::new() } else {
          let v158_6: Path = concat_path(&(v156_6),&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
          let mut v158_7 = Space::new();
          let mut v158_7_write = v158_7.write_zipper();
          for v158_7_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v158_7_byte);
            {
            let v159_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v159_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v159_2));
            let v159_4: Space = if map_kernels::has_head(&(v159_3)) { singleton(&[]) } else { Space::new() };
            drop(v159_3);
            let v159_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v159_4));
            drop(v159_4);
            let v159_8: Space = if (&(v159_5)).is_empty() { Space::new() } else {
              let v160_6: Path = concat_path(&(v158_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v160_7: Space = routine_20(c, &(v160_6), &v154_24_cursor, &(*s1));
              map_map_kernels::compose(&(v159_5),&(v160_7))
            };
            drop(v159_5);
            let v159_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v159_2));
            drop(v159_2);
            let v159_10: Space = if map_kernels::has_head(&(v159_9)) { singleton(&[]) } else { Space::new() };
            drop(v159_9);
            let v159_12: Space = if (&(v159_10)).is_empty() { Space::new() } else {
              let v161_6: Path = concat_path(&(v158_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v161_11: Space = routine_21(c, &(v161_6), &v154_24_cursor, &(*s1));
              drop(v161_6);
              map_map_kernels::compose(&(v159_10),&(v161_11))
            };
            drop(v159_10);
            let v159_13: Space = map_map_kernels::unite(&(v159_8),&(v159_12));
            join_wrapped_into(&mut v158_7_write,&((v159_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v158_7_write);
          map_map_kernels::compose(&(v157_5),&(v158_7))
        };
        drop(v157_5);
        let v157_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v157_2));
        drop(v157_2);
        let v157_10: Space = if map_kernels::has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
        drop(v157_9);
        let v157_12: Space = if (&(v157_10)).is_empty() { Space::new() } else {
          let v162_6: Path = concat_path(&(v156_6),&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
          let mut v162_11 = Space::new();
          let mut v162_11_write = v162_11.write_zipper();
          for v162_11_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v162_11_byte);
            {
            let v163_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v163_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v163_2));
            let v163_4: Space = if map_kernels::has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
            drop(v163_3);
            let v163_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v163_4));
            drop(v163_4);
            let v163_8: Space = if (&(v163_5)).is_empty() { Space::new() } else {
              let v164_6: Path = concat_path(&(v162_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v164_7: Space = routine_20(c, &(v164_6), &v154_24_cursor, &(*s1));
              map_map_kernels::compose(&(v163_5),&(v164_7))
            };
            drop(v163_5);
            let v163_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v163_2));
            drop(v163_2);
            let v163_10: Space = if map_kernels::has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
            drop(v163_9);
            let v163_12: Space = if (&(v163_10)).is_empty() { Space::new() } else {
              let v165_6: Path = concat_path(&(v162_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v165_11: Space = routine_3(c, &(v165_6), &v154_24_cursor, &(*s1));
              drop(v165_6);
              map_map_kernels::compose(&(v163_10),&(v165_11))
            };
            drop(v163_10);
            let v163_13: Space = map_map_kernels::unite(&(v163_8),&(v163_12));
            join_wrapped_into(&mut v162_11_write,&((v163_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v162_11_write);
          drop(v162_6);
          map_map_kernels::compose(&(v157_10),&(v162_11))
        };
        drop(v157_10);
        let v157_13: Space = map_map_kernels::unite(&(v157_8),&(v157_12));
        join_wrapped_into(&mut v156_7_write,&((v157_13).read_zipper()),&[]);
        }
        v154_24_cursor.ascend(1);
      }
      drop(v156_7_write);
      map_map_kernels::compose(&(v155_5),&(v156_7))
    };
    drop(v155_5);
    let v155_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v155_2));
    drop(v155_2);
    let v155_10: Space = if map_kernels::has_head(&(v155_9)) { singleton(&[]) } else { Space::new() };
    drop(v155_9);
    let v155_12: Space = if (&(v155_10)).is_empty() { Space::new() } else {
      let v166_6: Path = concat_path(&(*p0),&v154_24_cursor.path()[v154_24_origin..(v154_24_origin + 1)]);
      let mut v166_11 = Space::new();
      let mut v166_11_write = v166_11.write_zipper();
      for v166_11_byte in v154_24_cursor.child_mask().iter() {
        v154_24_cursor.descend_to_existing_byte(v166_11_byte);
        {
        let v167_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
        let v167_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v167_2));
        let v167_4: Space = if map_kernels::has_head(&(v167_3)) { singleton(&[]) } else { Space::new() };
        drop(v167_3);
        let v167_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v167_4));
        drop(v167_4);
        let v167_7: Space = if (&(v167_5)).is_empty() { Space::new() } else {
          let mut v168_6 = Space::new();
          let mut v168_6_write = v168_6.write_zipper();
          for v168_6_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v168_6_byte);
            {
            let v169_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v169_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v169_2));
            let v169_4: Space = if map_kernels::has_head(&(v169_3)) { singleton(&[]) } else { Space::new() };
            drop(v169_3);
            let v169_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v169_4));
            drop(v169_4);
            let v169_8: Space = if (&(v169_5)).is_empty() { Space::new() } else {
              let v170_7: Space = routine_8(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              map_map_kernels::compose(&(v169_5),&(v170_7))
            };
            drop(v169_5);
            let v169_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v169_2));
            drop(v169_2);
            let v169_10: Space = if map_kernels::has_head(&(v169_9)) { singleton(&[]) } else { Space::new() };
            drop(v169_9);
            let v169_12: Space = if (&(v169_10)).is_empty() { Space::new() } else {
              let v171_11: Space = routine_9(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              map_map_kernels::compose(&(v169_10),&(v171_11))
            };
            drop(v169_10);
            let v169_13: Space = map_map_kernels::unite(&(v169_8),&(v169_12));
            join_wrapped_into(&mut v168_6_write,&((v169_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v168_6_write);
          map_map_kernels::compose(&(v167_5),&(v168_6))
        };
        drop(v167_5);
        let v167_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v167_2));
        drop(v167_2);
        let v167_9: Space = if map_kernels::has_head(&(v167_8)) { singleton(&[]) } else { Space::new() };
        drop(v167_8);
        let v167_11: Space = if (&(v167_9)).is_empty() { Space::new() } else {
          let mut v172_10 = Space::new();
          let mut v172_10_write = v172_10.write_zipper();
          for v172_10_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v172_10_byte);
            {
            let v173_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v173_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v173_2));
            let v173_4: Space = if map_kernels::has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
            drop(v173_3);
            let v173_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v173_4));
            drop(v173_4);
            let v173_8: Space = if (&(v173_5)).is_empty() { Space::new() } else {
              let v174_7: Space = routine_8(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              map_map_kernels::compose(&(v173_5),&(v174_7))
            };
            drop(v173_5);
            let v173_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v173_2));
            drop(v173_2);
            let v173_10: Space = if map_kernels::has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
            drop(v173_9);
            let v173_12: Space = if (&(v173_10)).is_empty() { Space::new() } else {
              let v175_11: Space = routine_10(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              map_map_kernels::compose(&(v173_10),&(v175_11))
            };
            drop(v173_10);
            let v173_13: Space = map_map_kernels::unite(&(v173_8),&(v173_12));
            join_wrapped_into(&mut v172_10_write,&((v173_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v172_10_write);
          map_map_kernels::compose(&(v167_9),&(v172_10))
        };
        drop(v167_9);
        let v167_12: Space = map_map_kernels::unite(&(v167_7),&(v167_11));
        join_wrapped_into(&mut v166_11_write,&((v167_12).read_zipper()),&[]);
        }
        v154_24_cursor.ascend(1);
      }
      drop(v166_11_write);
      drop(v166_6);
      map_map_kernels::compose(&(v155_10),&(v166_11))
    };
    drop(v155_10);
    let v155_13: Space = map_map_kernels::unite(&(v155_8),&(v155_12));
    join_wrapped_into(&mut v154_24_write,&((v155_13).read_zipper()),&[]);
    }
    v154_24_cursor.ascend(1);
  }
  drop(v154_24_cursor);
  drop(v154_24_write);
  (v154_24).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v176_28 = Space::new();
  let mut v176_28_write = v176_28.write_zipper();
  let mut v176_28_cursor = (*s0).read_zipper();
  let v176_28_origin = v176_28_cursor.path().len();
  for v176_28_byte in v176_28_cursor.child_mask().iter() {
    v176_28_cursor.descend_to_existing_byte(v176_28_byte);
    {
    let v177_2: Space = singleton(&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]);
    let v177_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v177_2));
    let v177_4: Space = if map_kernels::has_head(&(v177_3)) { singleton(&[]) } else { Space::new() };
    drop(v177_3);
    let v177_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v177_4));
    drop(v177_4);
    let v177_8: Space = if (&(v177_5)).is_empty() { Space::new() } else {
      let v178_6: Path = concat_path(&(*p0),&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]);
      let mut v178_7 = Space::new();
      let mut v178_7_write = v178_7.write_zipper();
      for v178_7_byte in v176_28_cursor.child_mask().iter() {
        v176_28_cursor.descend_to_existing_byte(v178_7_byte);
        {
        let v179_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
        let v179_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v179_2));
        let v179_4: Space = if map_kernels::has_head(&(v179_3)) { singleton(&[]) } else { Space::new() };
        drop(v179_3);
        let v179_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v179_4));
        drop(v179_4);
        let v179_8: Space = if (&(v179_5)).is_empty() { Space::new() } else {
          let v180_6: Path = concat_path(&(v178_6),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let mut v180_7 = Space::new();
          let mut v180_7_write = v180_7.write_zipper();
          for v180_7_byte in v176_28_cursor.child_mask().iter() {
            v176_28_cursor.descend_to_existing_byte(v180_7_byte);
            {
            let v181_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
            let v181_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v181_2));
            let v181_4: Space = if map_kernels::has_head(&(v181_3)) { singleton(&[]) } else { Space::new() };
            drop(v181_3);
            let v181_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v181_4));
            drop(v181_4);
            let v181_8: Space = if (&(v181_5)).is_empty() { Space::new() } else {
              let v182_6: Path = concat_path(&(v180_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v182_7: Space = routine_22(c, &(v182_6), &(*p1), &v176_28_cursor, &(*s1));
              map_map_kernels::compose(&(v181_5),&(v182_7))
            };
            drop(v181_5);
            let v181_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v181_2));
            drop(v181_2);
            let v181_10: Space = if map_kernels::has_head(&(v181_9)) { singleton(&[]) } else { Space::new() };
            drop(v181_9);
            let v181_12: Space = if (&(v181_10)).is_empty() { Space::new() } else {
              let v183_6: Path = concat_path(&(v180_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v183_11: Space = routine_23(c, &(v183_6), &(*p1), &v176_28_cursor, &(*s1));
              drop(v183_6);
              map_map_kernels::compose(&(v181_10),&(v183_11))
            };
            drop(v181_10);
            let v181_13: Space = map_map_kernels::unite(&(v181_8),&(v181_12));
            join_wrapped_into(&mut v180_7_write,&((v181_13).read_zipper()),&[]);
            }
            v176_28_cursor.ascend(1);
          }
          drop(v180_7_write);
          map_map_kernels::compose(&(v179_5),&(v180_7))
        };
        drop(v179_5);
        let v179_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v179_2));
        drop(v179_2);
        let v179_10: Space = if map_kernels::has_head(&(v179_9)) { singleton(&[]) } else { Space::new() };
        drop(v179_9);
        let v179_12: Space = if (&(v179_10)).is_empty() { Space::new() } else {
          let v184_6: Path = concat_path(&(v178_6),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let mut v184_11 = Space::new();
          let mut v184_11_write = v184_11.write_zipper();
          for v184_11_byte in v176_28_cursor.child_mask().iter() {
            v176_28_cursor.descend_to_existing_byte(v184_11_byte);
            {
            let v185_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
            let v185_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v185_2));
            let v185_4: Space = if map_kernels::has_head(&(v185_3)) { singleton(&[]) } else { Space::new() };
            drop(v185_3);
            let v185_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v185_4));
            drop(v185_4);
            let v185_8: Space = if (&(v185_5)).is_empty() { Space::new() } else {
              let v186_6: Path = concat_path(&(v184_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v186_7: Space = routine_22(c, &(v186_6), &(*p1), &v176_28_cursor, &(*s1));
              map_map_kernels::compose(&(v185_5),&(v186_7))
            };
            drop(v185_5);
            let v185_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v185_2));
            drop(v185_2);
            let v185_10: Space = if map_kernels::has_head(&(v185_9)) { singleton(&[]) } else { Space::new() };
            drop(v185_9);
            let v185_12: Space = if (&(v185_10)).is_empty() { Space::new() } else {
              let v187_6: Path = concat_path(&(v184_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v187_11: Space = routine_10(c, &(v187_6), &(*p1), &v176_28_cursor, &(*s1));
              drop(v187_6);
              map_map_kernels::compose(&(v185_10),&(v187_11))
            };
            drop(v185_10);
            let v185_13: Space = map_map_kernels::unite(&(v185_8),&(v185_12));
            join_wrapped_into(&mut v184_11_write,&((v185_13).read_zipper()),&[]);
            }
            v176_28_cursor.ascend(1);
          }
          drop(v184_11_write);
          drop(v184_6);
          map_map_kernels::compose(&(v179_10),&(v184_11))
        };
        drop(v179_10);
        let v179_13: Space = map_map_kernels::unite(&(v179_8),&(v179_12));
        join_wrapped_into(&mut v178_7_write,&((v179_13).read_zipper()),&[]);
        }
        v176_28_cursor.ascend(1);
      }
      drop(v178_7_write);
      map_map_kernels::compose(&(v177_5),&(v178_7))
    };
    drop(v177_5);
    let v177_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v177_2));
    drop(v177_2);
    let v177_10: Space = if map_kernels::has_head(&(v177_9)) { singleton(&[]) } else { Space::new() };
    drop(v177_9);
    let v177_13: Space = if (&(v177_10)).is_empty() { Space::new() } else {
      let v188_6: Path = concat_path(&(*p0),&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]);
      let mut v188_12 = Space::new();
      let mut v188_12_write = v188_12.write_zipper();
      for v188_12_byte in v176_28_cursor.child_mask().iter() {
        v176_28_cursor.descend_to_existing_byte(v188_12_byte);
        {
        let v189_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
        let v189_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v189_2));
        let v189_4: Space = if map_kernels::has_head(&(v189_3)) { singleton(&[]) } else { Space::new() };
        drop(v189_3);
        let v189_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v189_4));
        drop(v189_4);
        let v189_8: Space = if (&(v189_5)).is_empty() { Space::new() } else {
          let v190_6: Path = concat_path(&(v188_6),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let mut v190_7 = Space::new();
          let mut v190_7_write = v190_7.write_zipper();
          for v190_7_byte in v176_28_cursor.child_mask().iter() {
            v176_28_cursor.descend_to_existing_byte(v190_7_byte);
            {
            let v191_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
            let v191_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v191_2));
            let v191_4: Space = if map_kernels::has_head(&(v191_3)) { singleton(&[]) } else { Space::new() };
            drop(v191_3);
            let v191_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v191_4));
            drop(v191_4);
            let v191_8: Space = if (&(v191_5)).is_empty() { Space::new() } else {
              let v192_6: Path = concat_path(&(v190_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v192_7: Space = routine_22(c, &(v192_6), &(*p1), &v176_28_cursor, &(*s1));
              map_map_kernels::compose(&(v191_5),&(v192_7))
            };
            drop(v191_5);
            let v191_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v191_2));
            drop(v191_2);
            let v191_10: Space = if map_kernels::has_head(&(v191_9)) { singleton(&[]) } else { Space::new() };
            drop(v191_9);
            let v191_12: Space = if (&(v191_10)).is_empty() { Space::new() } else {
              let v193_6: Path = concat_path(&(v190_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v193_11: Space = routine_23(c, &(v193_6), &(*p1), &v176_28_cursor, &(*s1));
              drop(v193_6);
              map_map_kernels::compose(&(v191_10),&(v193_11))
            };
            drop(v191_10);
            let v191_13: Space = map_map_kernels::unite(&(v191_8),&(v191_12));
            join_wrapped_into(&mut v190_7_write,&((v191_13).read_zipper()),&[]);
            }
            v176_28_cursor.ascend(1);
          }
          drop(v190_7_write);
          drop(v190_6);
          map_map_kernels::compose(&(v189_5),&(v190_7))
        };
        drop(v189_5);
        let v189_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v189_2));
        drop(v189_2);
        let v189_10: Space = if map_kernels::has_head(&(v189_9)) { singleton(&[]) } else { Space::new() };
        drop(v189_9);
        let v189_13: Space = if (&(v189_10)).is_empty() { Space::new() } else {
          let mut v194_12 = Space::new();
          let mut v194_12_write = v194_12.write_zipper();
          let mut v194_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let v194_12_origin = v194_12_cursor.path().len();
          for v194_12_byte in v194_12_cursor.child_mask().iter() {
            v194_12_cursor.descend_to_existing_byte(v194_12_byte);
            {
            let v195_2: Space = singleton(&v194_12_cursor.path()[v194_12_origin..(v194_12_origin + 1)]);
            let v195_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v195_2));
            let v195_4: Space = if map_kernels::has_head(&(v195_3)) { singleton(&[]) } else { Space::new() };
            drop(v195_3);
            let v195_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v195_4));
            drop(v195_4);
            let v195_7: Space = if (&(v195_5)).is_empty() { Space::new() } else {
              let v196_6: Space = routine_13(c, &v194_12_cursor.path()[v194_12_origin..(v194_12_origin + 1)], &(*p1), &v194_12_cursor);
              map_map_kernels::compose(&(v195_5),&(v196_6))
            };
            drop(v195_5);
            let v195_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v195_2));
            drop(v195_2);
            let v195_9: Space = if map_kernels::has_head(&(v195_8)) { singleton(&[]) } else { Space::new() };
            drop(v195_8);
            let v195_11: Space = if (&(v195_9)).is_empty() { Space::new() } else {
              let v197_10: Space = routine_14(c, &v194_12_cursor.path()[v194_12_origin..(v194_12_origin + 1)], &(*p1), &v194_12_cursor);
              map_map_kernels::compose(&(v195_9),&(v197_10))
            };
            drop(v195_9);
            let v195_12: Space = map_map_kernels::unite(&(v195_7),&(v195_11));
            join_wrapped_into(&mut v194_12_write,&((v195_12).read_zipper()),&[]);
            }
            v194_12_cursor.ascend(1);
          }
          drop(v194_12_cursor);
          drop(v194_12_write);
          map_map_kernels::compose(&(v189_10),&(v194_12))
        };
        drop(v189_10);
        let v189_14: Space = map_map_kernels::unite(&(v189_8),&(v189_13));
        join_wrapped_into(&mut v188_12_write,&((v189_14).read_zipper()),&[]);
        }
        v176_28_cursor.ascend(1);
      }
      drop(v188_12_write);
      drop(v188_6);
      map_map_kernels::compose(&(v177_10),&(v188_12))
    };
    drop(v177_10);
    let v177_14: Space = map_map_kernels::unite(&(v177_8),&(v177_13));
    join_wrapped_into(&mut v176_28_write,&((v177_14).read_zipper()),&[]);
    }
    v176_28_cursor.ascend(1);
  }
  drop(v176_28_cursor);
  drop(v176_28_write);
  (v176_28).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v198_28 = Space::new();
  let mut v198_28_write = v198_28.write_zipper();
  let mut v198_28_cursor = (*s0).read_zipper();
  let v198_28_origin = v198_28_cursor.path().len();
  for v198_28_byte in v198_28_cursor.child_mask().iter() {
    v198_28_cursor.descend_to_existing_byte(v198_28_byte);
    {
    let v199_2: Space = singleton(&v198_28_cursor.path()[v198_28_origin..(v198_28_origin + 1)]);
    let v199_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v199_2));
    let v199_4: Space = if map_kernels::has_head(&(v199_3)) { singleton(&[]) } else { Space::new() };
    drop(v199_3);
    let v199_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v199_4));
    drop(v199_4);
    let v199_8: Space = if (&(v199_5)).is_empty() { Space::new() } else {
      let v200_6: Path = concat_path(&(*p0),&v198_28_cursor.path()[v198_28_origin..(v198_28_origin + 1)]);
      let mut v200_7 = Space::new();
      let mut v200_7_write = v200_7.write_zipper();
      for v200_7_byte in v198_28_cursor.child_mask().iter() {
        v198_28_cursor.descend_to_existing_byte(v200_7_byte);
        {
        let v201_2: Space = singleton(&v198_28_cursor.path()[(v198_28_origin + 1)..(v198_28_origin + 2)]);
        let v201_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v201_2));
        let v201_4: Space = if map_kernels::has_head(&(v201_3)) { singleton(&[]) } else { Space::new() };
        drop(v201_3);
        let v201_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v201_4));
        drop(v201_4);
        let v201_8: Space = if (&(v201_5)).is_empty() { Space::new() } else {
          let v202_6: Path = concat_path(&(v200_6),&v198_28_cursor.path()[(v198_28_origin + 1)..(v198_28_origin + 2)]);
          let mut v202_7 = Space::new();
          let mut v202_7_write = v202_7.write_zipper();
          for v202_7_byte in v198_28_cursor.child_mask().iter() {
            v198_28_cursor.descend_to_existing_byte(v202_7_byte);
            {
            let v203_2: Space = singleton(&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
            let v203_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v203_2));
            let v203_4: Space = if map_kernels::has_head(&(v203_3)) { singleton(&[]) } else { Space::new() };
            drop(v203_3);
            let v203_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v203_4));
            drop(v203_4);
            let v203_8: Space = if (&(v203_5)).is_empty() { Space::new() } else {
              let v204_6: Path = concat_path(&(v202_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v204_7: Space = routine_22(c, &(v204_6), &(*p1), &v198_28_cursor, &(*s1));
              map_map_kernels::compose(&(v203_5),&(v204_7))
            };
            drop(v203_5);
            let v203_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v203_2));
            drop(v203_2);
            let v203_10: Space = if map_kernels::has_head(&(v203_9)) { singleton(&[]) } else { Space::new() };
            drop(v203_9);
            let v203_12: Space = if (&(v203_10)).is_empty() { Space::new() } else {
              let v205_6: Path = concat_path(&(v202_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v205_11: Space = routine_23(c, &(v205_6), &(*p1), &v198_28_cursor, &(*s1));
              drop(v205_6);
              map_map_kernels::compose(&(v203_10),&(v205_11))
            };
            drop(v203_10);
            let v203_13: Space = map_map_kernels::unite(&(v203_8),&(v203_12));
            join_wrapped_into(&mut v202_7_write,&((v203_13).read_zipper()),&[]);
            }
            v198_28_cursor.ascend(1);
          }
          drop(v202_7_write);
          map_map_kernels::compose(&(v201_5),&(v202_7))
        };
        drop(v201_5);
        let v201_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v201_2));
        drop(v201_2);
        let v201_10: Space = if map_kernels::has_head(&(v201_9)) { singleton(&[]) } else { Space::new() };
        drop(v201_9);
        let v201_12: Space = if (&(v201_10)).is_empty() { Space::new() } else {
          let v206_6: Path = concat_path(&(v200_6),&v198_28_cursor.path()[(v198_28_origin + 1)..(v198_28_origin + 2)]);
          let mut v206_11 = Space::new();
          let mut v206_11_write = v206_11.write_zipper();
          for v206_11_byte in v198_28_cursor.child_mask().iter() {
            v198_28_cursor.descend_to_existing_byte(v206_11_byte);
            {
            let v207_2: Space = singleton(&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
            let v207_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v207_2));
            let v207_4: Space = if map_kernels::has_head(&(v207_3)) { singleton(&[]) } else { Space::new() };
            drop(v207_3);
            let v207_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v207_4));
            drop(v207_4);
            let v207_8: Space = if (&(v207_5)).is_empty() { Space::new() } else {
              let v208_6: Path = concat_path(&(v206_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v208_7: Space = routine_22(c, &(v208_6), &(*p1), &v198_28_cursor, &(*s1));
              map_map_kernels::compose(&(v207_5),&(v208_7))
            };
            drop(v207_5);
            let v207_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v207_2));
            drop(v207_2);
            let v207_10: Space = if map_kernels::has_head(&(v207_9)) { singleton(&[]) } else { Space::new() };
            drop(v207_9);
            let v207_12: Space = if (&(v207_10)).is_empty() { Space::new() } else {
              let v209_6: Path = concat_path(&(v206_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v209_11: Space = routine_10(c, &(v209_6), &(*p1), &v198_28_cursor, &(*s1));
              drop(v209_6);
              map_map_kernels::compose(&(v207_10),&(v209_11))
            };
            drop(v207_10);
            let v207_13: Space = map_map_kernels::unite(&(v207_8),&(v207_12));
            join_wrapped_into(&mut v206_11_write,&((v207_13).read_zipper()),&[]);
            }
            v198_28_cursor.ascend(1);
          }
          drop(v206_11_write);
          drop(v206_6);
          map_map_kernels::compose(&(v201_10),&(v206_11))
        };
        drop(v201_10);
        let v201_13: Space = map_map_kernels::unite(&(v201_8),&(v201_12));
        join_wrapped_into(&mut v200_7_write,&((v201_13).read_zipper()),&[]);
        }
        v198_28_cursor.ascend(1);
      }
      drop(v200_7_write);
      drop(v200_6);
      map_map_kernels::compose(&(v199_5),&(v200_7))
    };
    drop(v199_5);
    let v199_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v199_2));
    drop(v199_2);
    let v199_10: Space = if map_kernels::has_head(&(v199_9)) { singleton(&[]) } else { Space::new() };
    drop(v199_9);
    let v199_13: Space = if (&(v199_10)).is_empty() { Space::new() } else {
      let mut v210_12 = Space::new();
      let mut v210_12_write = v210_12.write_zipper();
      let mut v210_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v198_28_cursor.path()[v198_28_origin..(v198_28_origin + 1)]);
      let v210_12_origin = v210_12_cursor.path().len();
      for v210_12_byte in v210_12_cursor.child_mask().iter() {
        v210_12_cursor.descend_to_existing_byte(v210_12_byte);
        {
        let v211_2: Space = singleton(&v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 1)]);
        let v211_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v211_2));
        let v211_4: Space = if map_kernels::has_head(&(v211_3)) { singleton(&[]) } else { Space::new() };
        drop(v211_3);
        let v211_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v211_4));
        drop(v211_4);
        let v211_7: Space = if (&(v211_5)).is_empty() { Space::new() } else {
          let mut v212_6 = Space::new();
          let mut v212_6_write = v212_6.write_zipper();
          for v212_6_byte in v210_12_cursor.child_mask().iter() {
            v210_12_cursor.descend_to_existing_byte(v212_6_byte);
            {
            let v213_2: Space = singleton(&v210_12_cursor.path()[(v210_12_origin + 1)..(v210_12_origin + 2)]);
            let v213_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v213_2));
            let v213_4: Space = if map_kernels::has_head(&(v213_3)) { singleton(&[]) } else { Space::new() };
            drop(v213_3);
            let v213_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v213_4));
            drop(v213_4);
            let v213_8: Space = if (&(v213_5)).is_empty() { Space::new() } else {
              let v214_7: Space = routine_17(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              map_map_kernels::compose(&(v213_5),&(v214_7))
            };
            drop(v213_5);
            let v213_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v213_2));
            drop(v213_2);
            let v213_10: Space = if map_kernels::has_head(&(v213_9)) { singleton(&[]) } else { Space::new() };
            drop(v213_9);
            let v213_12: Space = if (&(v213_10)).is_empty() { Space::new() } else {
              let v215_11: Space = routine_18(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              map_map_kernels::compose(&(v213_10),&(v215_11))
            };
            drop(v213_10);
            let v213_13: Space = map_map_kernels::unite(&(v213_8),&(v213_12));
            join_wrapped_into(&mut v212_6_write,&((v213_13).read_zipper()),&[]);
            }
            v210_12_cursor.ascend(1);
          }
          drop(v212_6_write);
          map_map_kernels::compose(&(v211_5),&(v212_6))
        };
        drop(v211_5);
        let v211_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v211_2));
        drop(v211_2);
        let v211_9: Space = if map_kernels::has_head(&(v211_8)) { singleton(&[]) } else { Space::new() };
        drop(v211_8);
        let v211_11: Space = if (&(v211_9)).is_empty() { Space::new() } else {
          let mut v216_10 = Space::new();
          let mut v216_10_write = v216_10.write_zipper();
          for v216_10_byte in v210_12_cursor.child_mask().iter() {
            v210_12_cursor.descend_to_existing_byte(v216_10_byte);
            {
            let v217_2: Space = singleton(&v210_12_cursor.path()[(v210_12_origin + 1)..(v210_12_origin + 2)]);
            let v217_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v217_2));
            let v217_4: Space = if map_kernels::has_head(&(v217_3)) { singleton(&[]) } else { Space::new() };
            drop(v217_3);
            let v217_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v217_4));
            drop(v217_4);
            let v217_8: Space = if (&(v217_5)).is_empty() { Space::new() } else {
              let v218_7: Space = routine_17(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              map_map_kernels::compose(&(v217_5),&(v218_7))
            };
            drop(v217_5);
            let v217_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v217_2));
            drop(v217_2);
            let v217_10: Space = if map_kernels::has_head(&(v217_9)) { singleton(&[]) } else { Space::new() };
            drop(v217_9);
            let v217_12: Space = if (&(v217_10)).is_empty() { Space::new() } else {
              let v219_11: Space = routine_19(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              map_map_kernels::compose(&(v217_10),&(v219_11))
            };
            drop(v217_10);
            let v217_13: Space = map_map_kernels::unite(&(v217_8),&(v217_12));
            join_wrapped_into(&mut v216_10_write,&((v217_13).read_zipper()),&[]);
            }
            v210_12_cursor.ascend(1);
          }
          drop(v216_10_write);
          map_map_kernels::compose(&(v211_9),&(v216_10))
        };
        drop(v211_9);
        let v211_12: Space = map_map_kernels::unite(&(v211_7),&(v211_11));
        join_wrapped_into(&mut v210_12_write,&((v211_12).read_zipper()),&[]);
        }
        v210_12_cursor.ascend(1);
      }
      drop(v210_12_cursor);
      drop(v210_12_write);
      map_map_kernels::compose(&(v199_10),&(v210_12))
    };
    drop(v199_10);
    let v199_14: Space = map_map_kernels::unite(&(v199_8),&(v199_13));
    join_wrapped_into(&mut v198_28_write,&((v199_14).read_zipper()),&[]);
    }
    v198_28_cursor.ascend(1);
  }
  drop(v198_28_cursor);
  drop(v198_28_write);
  (v198_28).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v220_25 = Space::new();
  let mut v220_25_write = v220_25.write_zipper();
  let mut v220_25_cursor = descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0));
  let v220_25_origin = v220_25_cursor.path().len();
  for v220_25_byte in v220_25_cursor.child_mask().iter() {
    v220_25_cursor.descend_to_existing_byte(v220_25_byte);
    {
    let v221_2: Space = singleton(&v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 1)]);
    let v221_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v221_2));
    let v221_4: Space = if map_kernels::has_head(&(v221_3)) { singleton(&[]) } else { Space::new() };
    drop(v221_3);
    let v221_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v221_4));
    drop(v221_4);
    let v221_7: Space = if (&(v221_5)).is_empty() { Space::new() } else {
      let mut v222_6 = Space::new();
      let mut v222_6_write = v222_6.write_zipper();
      for v222_6_byte in v220_25_cursor.child_mask().iter() {
        v220_25_cursor.descend_to_existing_byte(v222_6_byte);
        {
        let v223_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 1)..(v220_25_origin + 2)]);
        let v223_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v223_2));
        let v223_4: Space = if map_kernels::has_head(&(v223_3)) { singleton(&[]) } else { Space::new() };
        drop(v223_3);
        let v223_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v223_4));
        drop(v223_4);
        let v223_8: Space = if (&(v223_5)).is_empty() { Space::new() } else {
          let mut v224_7 = Space::new();
          let mut v224_7_write = v224_7.write_zipper();
          for v224_7_byte in v220_25_cursor.child_mask().iter() {
            v220_25_cursor.descend_to_existing_byte(v224_7_byte);
            {
            let v225_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 2)..(v220_25_origin + 3)]);
            let v225_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v225_2));
            let v225_4: Space = if map_kernels::has_head(&(v225_3)) { singleton(&[]) } else { Space::new() };
            drop(v225_3);
            let v225_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v225_4));
            drop(v225_4);
            let v225_8: Space = if (&(v225_5)).is_empty() { Space::new() } else {
              let v226_7: Space = routine_24(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              map_map_kernels::compose(&(v225_5),&(v226_7))
            };
            drop(v225_5);
            let v225_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v225_2));
            drop(v225_2);
            let v225_10: Space = if map_kernels::has_head(&(v225_9)) { singleton(&[]) } else { Space::new() };
            drop(v225_9);
            let v225_12: Space = if (&(v225_10)).is_empty() { Space::new() } else {
              let v227_11: Space = routine_25(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              map_map_kernels::compose(&(v225_10),&(v227_11))
            };
            drop(v225_10);
            let v225_13: Space = map_map_kernels::unite(&(v225_8),&(v225_12));
            join_wrapped_into(&mut v224_7_write,&((v225_13).read_zipper()),&[]);
            }
            v220_25_cursor.ascend(1);
          }
          drop(v224_7_write);
          map_map_kernels::compose(&(v223_5),&(v224_7))
        };
        drop(v223_5);
        let v223_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v223_2));
        drop(v223_2);
        let v223_10: Space = if map_kernels::has_head(&(v223_9)) { singleton(&[]) } else { Space::new() };
        drop(v223_9);
        let v223_12: Space = if (&(v223_10)).is_empty() { Space::new() } else {
          let mut v228_11 = Space::new();
          let mut v228_11_write = v228_11.write_zipper();
          for v228_11_byte in v220_25_cursor.child_mask().iter() {
            v220_25_cursor.descend_to_existing_byte(v228_11_byte);
            {
            let v229_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 2)..(v220_25_origin + 3)]);
            let v229_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v229_2));
            let v229_4: Space = if map_kernels::has_head(&(v229_3)) { singleton(&[]) } else { Space::new() };
            drop(v229_3);
            let v229_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v229_4));
            drop(v229_4);
            let v229_8: Space = if (&(v229_5)).is_empty() { Space::new() } else {
              let v230_7: Space = routine_24(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              map_map_kernels::compose(&(v229_5),&(v230_7))
            };
            drop(v229_5);
            let v229_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v229_2));
            drop(v229_2);
            let v229_10: Space = if map_kernels::has_head(&(v229_9)) { singleton(&[]) } else { Space::new() };
            drop(v229_9);
            let v229_12: Space = if (&(v229_10)).is_empty() { Space::new() } else {
              let v231_11: Space = routine_19(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              map_map_kernels::compose(&(v229_10),&(v231_11))
            };
            drop(v229_10);
            let v229_13: Space = map_map_kernels::unite(&(v229_8),&(v229_12));
            join_wrapped_into(&mut v228_11_write,&((v229_13).read_zipper()),&[]);
            }
            v220_25_cursor.ascend(1);
          }
          drop(v228_11_write);
          map_map_kernels::compose(&(v223_10),&(v228_11))
        };
        drop(v223_10);
        let v223_13: Space = map_map_kernels::unite(&(v223_8),&(v223_12));
        join_wrapped_into(&mut v222_6_write,&((v223_13).read_zipper()),&[]);
        }
        v220_25_cursor.ascend(1);
      }
      drop(v222_6_write);
      map_map_kernels::compose(&(v221_5),&(v222_6))
    };
    drop(v221_5);
    let v221_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v221_2));
    drop(v221_2);
    let v221_9: Space = if map_kernels::has_head(&(v221_8)) { singleton(&[]) } else { Space::new() };
    drop(v221_8);
    let v221_11: Space = if (&(v221_9)).is_empty() { Space::new() } else {
      let mut v232_10 = Space::new();
      let mut v232_10_write = v232_10.write_zipper();
      for v232_10_byte in v220_25_cursor.child_mask().iter() {
        v220_25_cursor.descend_to_existing_byte(v232_10_byte);
        {
        let v233_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 1)..(v220_25_origin + 2)]);
        let v233_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v233_2));
        let v233_4: Space = if map_kernels::has_head(&(v233_3)) { singleton(&[]) } else { Space::new() };
        drop(v233_3);
        let v233_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v233_4));
        drop(v233_4);
        let v233_8: Space = if (&(v233_5)).is_empty() { Space::new() } else {
          let mut v234_7 = Space::new();
          let mut v234_7_write = v234_7.write_zipper();
          for v234_7_byte in v220_25_cursor.child_mask().iter() {
            v220_25_cursor.descend_to_existing_byte(v234_7_byte);
            {
            let v235_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 2)..(v220_25_origin + 3)]);
            let v235_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v235_2));
            let v235_4: Space = if map_kernels::has_head(&(v235_3)) { singleton(&[]) } else { Space::new() };
            drop(v235_3);
            let v235_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v235_4));
            drop(v235_4);
            let v235_8: Space = if (&(v235_5)).is_empty() { Space::new() } else {
              let v236_7: Space = routine_24(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              map_map_kernels::compose(&(v235_5),&(v236_7))
            };
            drop(v235_5);
            let v235_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v235_2));
            drop(v235_2);
            let v235_10: Space = if map_kernels::has_head(&(v235_9)) { singleton(&[]) } else { Space::new() };
            drop(v235_9);
            let v235_12: Space = if (&(v235_10)).is_empty() { Space::new() } else {
              let v237_11: Space = routine_25(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              map_map_kernels::compose(&(v235_10),&(v237_11))
            };
            drop(v235_10);
            let v235_13: Space = map_map_kernels::unite(&(v235_8),&(v235_12));
            join_wrapped_into(&mut v234_7_write,&((v235_13).read_zipper()),&[]);
            }
            v220_25_cursor.ascend(1);
          }
          drop(v234_7_write);
          map_map_kernels::compose(&(v233_5),&(v234_7))
        };
        drop(v233_5);
        let v233_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v233_2));
        drop(v233_2);
        let v233_10: Space = if map_kernels::has_head(&(v233_9)) { singleton(&[]) } else { Space::new() };
        drop(v233_9);
        let v233_11: Space = map_view_kernels::compose(&(v233_10),&v220_25_cursor);
        drop(v233_10);
        let v233_12: Space = map_kernels::wrap(&(v233_11),&v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 2)]);
        drop(v233_11);
        let v233_13: Space = map_kernels::wrap(&(v233_12),&(*p1));
        drop(v233_12);
        let v233_14: Space = map_map_kernels::unite(&(v233_8),&(v233_13));
        drop(v233_13);
        join_wrapped_into(&mut v232_10_write,&((v233_14).read_zipper()),&[]);
        }
        v220_25_cursor.ascend(1);
      }
      drop(v232_10_write);
      map_map_kernels::compose(&(v221_9),&(v232_10))
    };
    drop(v221_9);
    let v221_12: Space = map_map_kernels::unite(&(v221_7),&(v221_11));
    join_wrapped_into(&mut v220_25_write,&((v221_12).read_zipper()),&[]);
    }
    v220_25_cursor.ascend(1);
  }
  drop(v220_25_cursor);
  drop(v220_25_write);
  (v220_25).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v239_28 = Space::new();
  let mut v239_28_write = v239_28.write_zipper();
  let mut v239_28_cursor = (*s0).read_zipper();
  let v239_28_origin = v239_28_cursor.path().len();
  for v239_28_byte in v239_28_cursor.child_mask().iter() {
    v239_28_cursor.descend_to_existing_byte(v239_28_byte);
    {
    let v240_2: Space = singleton(&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]);
    let v240_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v240_2));
    let v240_4: Space = if map_kernels::has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
    drop(v240_3);
    let v240_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v240_4));
    drop(v240_4);
    let v240_8: Space = if (&(v240_5)).is_empty() { Space::new() } else {
      let v241_6: Path = concat_path(&(*p0),&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]);
      let mut v241_7 = Space::new();
      let mut v241_7_write = v241_7.write_zipper();
      for v241_7_byte in v239_28_cursor.child_mask().iter() {
        v239_28_cursor.descend_to_existing_byte(v241_7_byte);
        {
        let v242_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
        let v242_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v242_2));
        let v242_4: Space = if map_kernels::has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
        drop(v242_3);
        let v242_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v242_4));
        drop(v242_4);
        let v242_8: Space = if (&(v242_5)).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v241_6),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let mut v243_7 = Space::new();
          let mut v243_7_write = v243_7.write_zipper();
          for v243_7_byte in v239_28_cursor.child_mask().iter() {
            v239_28_cursor.descend_to_existing_byte(v243_7_byte);
            {
            let v244_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
            let v244_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v244_2));
            let v244_4: Space = if map_kernels::has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
            drop(v244_3);
            let v244_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v244_4));
            drop(v244_4);
            let v244_8: Space = if (&(v244_5)).is_empty() { Space::new() } else {
              let v245_6: Path = concat_path(&(v243_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v245_7: Space = routine_26(c, &(v245_6), &(*p1), &v239_28_cursor, &(*s1));
              map_map_kernels::compose(&(v244_5),&(v245_7))
            };
            drop(v244_5);
            let v244_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v244_2));
            drop(v244_2);
            let v244_10: Space = if map_kernels::has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
            drop(v244_9);
            let v244_12: Space = if (&(v244_10)).is_empty() { Space::new() } else {
              let v246_6: Path = concat_path(&(v243_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v246_11: Space = routine_27(c, &(v246_6), &(*p1), &v239_28_cursor, &(*s1));
              drop(v246_6);
              map_map_kernels::compose(&(v244_10),&(v246_11))
            };
            drop(v244_10);
            let v244_13: Space = map_map_kernels::unite(&(v244_8),&(v244_12));
            join_wrapped_into(&mut v243_7_write,&((v244_13).read_zipper()),&[]);
            }
            v239_28_cursor.ascend(1);
          }
          drop(v243_7_write);
          map_map_kernels::compose(&(v242_5),&(v243_7))
        };
        drop(v242_5);
        let v242_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v242_2));
        drop(v242_2);
        let v242_10: Space = if map_kernels::has_head(&(v242_9)) { singleton(&[]) } else { Space::new() };
        drop(v242_9);
        let v242_12: Space = if (&(v242_10)).is_empty() { Space::new() } else {
          let v247_6: Path = concat_path(&(v241_6),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let mut v247_11 = Space::new();
          let mut v247_11_write = v247_11.write_zipper();
          for v247_11_byte in v239_28_cursor.child_mask().iter() {
            v239_28_cursor.descend_to_existing_byte(v247_11_byte);
            {
            let v248_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
            let v248_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v248_2));
            let v248_4: Space = if map_kernels::has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
            drop(v248_3);
            let v248_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v248_4));
            drop(v248_4);
            let v248_8: Space = if (&(v248_5)).is_empty() { Space::new() } else {
              let v249_6: Path = concat_path(&(v247_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v249_7: Space = routine_26(c, &(v249_6), &(*p1), &v239_28_cursor, &(*s1));
              map_map_kernels::compose(&(v248_5),&(v249_7))
            };
            drop(v248_5);
            let v248_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v248_2));
            drop(v248_2);
            let v248_10: Space = if map_kernels::has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
            drop(v248_9);
            let v248_12: Space = if (&(v248_10)).is_empty() { Space::new() } else {
              let v250_6: Path = concat_path(&(v247_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v250_11: Space = routine_10(c, &(v250_6), &(*p1), &v239_28_cursor, &(*s1));
              drop(v250_6);
              map_map_kernels::compose(&(v248_10),&(v250_11))
            };
            drop(v248_10);
            let v248_13: Space = map_map_kernels::unite(&(v248_8),&(v248_12));
            join_wrapped_into(&mut v247_11_write,&((v248_13).read_zipper()),&[]);
            }
            v239_28_cursor.ascend(1);
          }
          drop(v247_11_write);
          drop(v247_6);
          map_map_kernels::compose(&(v242_10),&(v247_11))
        };
        drop(v242_10);
        let v242_13: Space = map_map_kernels::unite(&(v242_8),&(v242_12));
        join_wrapped_into(&mut v241_7_write,&((v242_13).read_zipper()),&[]);
        }
        v239_28_cursor.ascend(1);
      }
      drop(v241_7_write);
      map_map_kernels::compose(&(v240_5),&(v241_7))
    };
    drop(v240_5);
    let v240_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v240_2));
    drop(v240_2);
    let v240_10: Space = if map_kernels::has_head(&(v240_9)) { singleton(&[]) } else { Space::new() };
    drop(v240_9);
    let v240_13: Space = if (&(v240_10)).is_empty() { Space::new() } else {
      let v251_6: Path = concat_path(&(*p0),&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]);
      let mut v251_12 = Space::new();
      let mut v251_12_write = v251_12.write_zipper();
      for v251_12_byte in v239_28_cursor.child_mask().iter() {
        v239_28_cursor.descend_to_existing_byte(v251_12_byte);
        {
        let v252_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
        let v252_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v252_2));
        let v252_4: Space = if map_kernels::has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
        drop(v252_3);
        let v252_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v252_4));
        drop(v252_4);
        let v252_8: Space = if (&(v252_5)).is_empty() { Space::new() } else {
          let v253_6: Path = concat_path(&(v251_6),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let mut v253_7 = Space::new();
          let mut v253_7_write = v253_7.write_zipper();
          for v253_7_byte in v239_28_cursor.child_mask().iter() {
            v239_28_cursor.descend_to_existing_byte(v253_7_byte);
            {
            let v254_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
            let v254_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v254_2));
            let v254_4: Space = if map_kernels::has_head(&(v254_3)) { singleton(&[]) } else { Space::new() };
            drop(v254_3);
            let v254_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v254_4));
            drop(v254_4);
            let v254_8: Space = if (&(v254_5)).is_empty() { Space::new() } else {
              let v255_6: Path = concat_path(&(v253_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v255_7: Space = routine_26(c, &(v255_6), &(*p1), &v239_28_cursor, &(*s1));
              map_map_kernels::compose(&(v254_5),&(v255_7))
            };
            drop(v254_5);
            let v254_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v254_2));
            drop(v254_2);
            let v254_10: Space = if map_kernels::has_head(&(v254_9)) { singleton(&[]) } else { Space::new() };
            drop(v254_9);
            let v254_12: Space = if (&(v254_10)).is_empty() { Space::new() } else {
              let v256_6: Path = concat_path(&(v253_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v256_11: Space = routine_27(c, &(v256_6), &(*p1), &v239_28_cursor, &(*s1));
              drop(v256_6);
              map_map_kernels::compose(&(v254_10),&(v256_11))
            };
            drop(v254_10);
            let v254_13: Space = map_map_kernels::unite(&(v254_8),&(v254_12));
            join_wrapped_into(&mut v253_7_write,&((v254_13).read_zipper()),&[]);
            }
            v239_28_cursor.ascend(1);
          }
          drop(v253_7_write);
          drop(v253_6);
          map_map_kernels::compose(&(v252_5),&(v253_7))
        };
        drop(v252_5);
        let v252_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v252_2));
        drop(v252_2);
        let v252_10: Space = if map_kernels::has_head(&(v252_9)) { singleton(&[]) } else { Space::new() };
        drop(v252_9);
        let v252_13: Space = if (&(v252_10)).is_empty() { Space::new() } else {
          let mut v257_12 = Space::new();
          let mut v257_12_write = v257_12.write_zipper();
          let mut v257_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let v257_12_origin = v257_12_cursor.path().len();
          for v257_12_byte in v257_12_cursor.child_mask().iter() {
            v257_12_cursor.descend_to_existing_byte(v257_12_byte);
            {
            let v258_2: Space = singleton(&v257_12_cursor.path()[v257_12_origin..(v257_12_origin + 1)]);
            let v258_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v258_2));
            let v258_4: Space = if map_kernels::has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
            drop(v258_3);
            let v258_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v258_4));
            drop(v258_4);
            let v258_7: Space = if (&(v258_5)).is_empty() { Space::new() } else {
              let v259_6: Space = routine_13(c, &v257_12_cursor.path()[v257_12_origin..(v257_12_origin + 1)], &(*p1), &v257_12_cursor);
              map_map_kernels::compose(&(v258_5),&(v259_6))
            };
            drop(v258_5);
            let v258_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v258_2));
            drop(v258_2);
            let v258_9: Space = if map_kernels::has_head(&(v258_8)) { singleton(&[]) } else { Space::new() };
            drop(v258_8);
            let v258_11: Space = if (&(v258_9)).is_empty() { Space::new() } else {
              let v260_10: Space = routine_14(c, &v257_12_cursor.path()[v257_12_origin..(v257_12_origin + 1)], &(*p1), &v257_12_cursor);
              map_map_kernels::compose(&(v258_9),&(v260_10))
            };
            drop(v258_9);
            let v258_12: Space = map_map_kernels::unite(&(v258_7),&(v258_11));
            join_wrapped_into(&mut v257_12_write,&((v258_12).read_zipper()),&[]);
            }
            v257_12_cursor.ascend(1);
          }
          drop(v257_12_cursor);
          drop(v257_12_write);
          map_map_kernels::compose(&(v252_10),&(v257_12))
        };
        drop(v252_10);
        let v252_14: Space = map_map_kernels::unite(&(v252_8),&(v252_13));
        join_wrapped_into(&mut v251_12_write,&((v252_14).read_zipper()),&[]);
        }
        v239_28_cursor.ascend(1);
      }
      drop(v251_12_write);
      drop(v251_6);
      map_map_kernels::compose(&(v240_10),&(v251_12))
    };
    drop(v240_10);
    let v240_14: Space = map_map_kernels::unite(&(v240_8),&(v240_13));
    join_wrapped_into(&mut v239_28_write,&((v240_14).read_zipper()),&[]);
    }
    v239_28_cursor.ascend(1);
  }
  drop(v239_28_cursor);
  drop(v239_28_write);
  (v239_28).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v261_28 = Space::new();
  let mut v261_28_write = v261_28.write_zipper();
  let mut v261_28_cursor = (*s0).read_zipper();
  let v261_28_origin = v261_28_cursor.path().len();
  for v261_28_byte in v261_28_cursor.child_mask().iter() {
    v261_28_cursor.descend_to_existing_byte(v261_28_byte);
    {
    let v262_2: Space = singleton(&v261_28_cursor.path()[v261_28_origin..(v261_28_origin + 1)]);
    let v262_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v262_2));
    let v262_4: Space = if map_kernels::has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
    drop(v262_3);
    let v262_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v262_4));
    drop(v262_4);
    let v262_8: Space = if (&(v262_5)).is_empty() { Space::new() } else {
      let v263_6: Path = concat_path(&(*p0),&v261_28_cursor.path()[v261_28_origin..(v261_28_origin + 1)]);
      let mut v263_7 = Space::new();
      let mut v263_7_write = v263_7.write_zipper();
      for v263_7_byte in v261_28_cursor.child_mask().iter() {
        v261_28_cursor.descend_to_existing_byte(v263_7_byte);
        {
        let v264_2: Space = singleton(&v261_28_cursor.path()[(v261_28_origin + 1)..(v261_28_origin + 2)]);
        let v264_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v264_2));
        let v264_4: Space = if map_kernels::has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
        drop(v264_3);
        let v264_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v264_4));
        drop(v264_4);
        let v264_8: Space = if (&(v264_5)).is_empty() { Space::new() } else {
          let v265_6: Path = concat_path(&(v263_6),&v261_28_cursor.path()[(v261_28_origin + 1)..(v261_28_origin + 2)]);
          let mut v265_7 = Space::new();
          let mut v265_7_write = v265_7.write_zipper();
          for v265_7_byte in v261_28_cursor.child_mask().iter() {
            v261_28_cursor.descend_to_existing_byte(v265_7_byte);
            {
            let v266_2: Space = singleton(&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
            let v266_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v266_2));
            let v266_4: Space = if map_kernels::has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
            drop(v266_3);
            let v266_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v266_4));
            drop(v266_4);
            let v266_8: Space = if (&(v266_5)).is_empty() { Space::new() } else {
              let v267_6: Path = concat_path(&(v265_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v267_7: Space = routine_26(c, &(v267_6), &(*p1), &v261_28_cursor, &(*s1));
              map_map_kernels::compose(&(v266_5),&(v267_7))
            };
            drop(v266_5);
            let v266_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v266_2));
            drop(v266_2);
            let v266_10: Space = if map_kernels::has_head(&(v266_9)) { singleton(&[]) } else { Space::new() };
            drop(v266_9);
            let v266_12: Space = if (&(v266_10)).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v265_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v268_11: Space = routine_27(c, &(v268_6), &(*p1), &v261_28_cursor, &(*s1));
              drop(v268_6);
              map_map_kernels::compose(&(v266_10),&(v268_11))
            };
            drop(v266_10);
            let v266_13: Space = map_map_kernels::unite(&(v266_8),&(v266_12));
            join_wrapped_into(&mut v265_7_write,&((v266_13).read_zipper()),&[]);
            }
            v261_28_cursor.ascend(1);
          }
          drop(v265_7_write);
          map_map_kernels::compose(&(v264_5),&(v265_7))
        };
        drop(v264_5);
        let v264_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v264_2));
        drop(v264_2);
        let v264_10: Space = if map_kernels::has_head(&(v264_9)) { singleton(&[]) } else { Space::new() };
        drop(v264_9);
        let v264_12: Space = if (&(v264_10)).is_empty() { Space::new() } else {
          let v269_6: Path = concat_path(&(v263_6),&v261_28_cursor.path()[(v261_28_origin + 1)..(v261_28_origin + 2)]);
          let mut v269_11 = Space::new();
          let mut v269_11_write = v269_11.write_zipper();
          for v269_11_byte in v261_28_cursor.child_mask().iter() {
            v261_28_cursor.descend_to_existing_byte(v269_11_byte);
            {
            let v270_2: Space = singleton(&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
            let v270_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v270_2));
            let v270_4: Space = if map_kernels::has_head(&(v270_3)) { singleton(&[]) } else { Space::new() };
            drop(v270_3);
            let v270_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v270_4));
            drop(v270_4);
            let v270_8: Space = if (&(v270_5)).is_empty() { Space::new() } else {
              let v271_6: Path = concat_path(&(v269_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v271_7: Space = routine_26(c, &(v271_6), &(*p1), &v261_28_cursor, &(*s1));
              map_map_kernels::compose(&(v270_5),&(v271_7))
            };
            drop(v270_5);
            let v270_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v270_2));
            drop(v270_2);
            let v270_10: Space = if map_kernels::has_head(&(v270_9)) { singleton(&[]) } else { Space::new() };
            drop(v270_9);
            let v270_12: Space = if (&(v270_10)).is_empty() { Space::new() } else {
              let v272_6: Path = concat_path(&(v269_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v272_11: Space = routine_10(c, &(v272_6), &(*p1), &v261_28_cursor, &(*s1));
              drop(v272_6);
              map_map_kernels::compose(&(v270_10),&(v272_11))
            };
            drop(v270_10);
            let v270_13: Space = map_map_kernels::unite(&(v270_8),&(v270_12));
            join_wrapped_into(&mut v269_11_write,&((v270_13).read_zipper()),&[]);
            }
            v261_28_cursor.ascend(1);
          }
          drop(v269_11_write);
          drop(v269_6);
          map_map_kernels::compose(&(v264_10),&(v269_11))
        };
        drop(v264_10);
        let v264_13: Space = map_map_kernels::unite(&(v264_8),&(v264_12));
        join_wrapped_into(&mut v263_7_write,&((v264_13).read_zipper()),&[]);
        }
        v261_28_cursor.ascend(1);
      }
      drop(v263_7_write);
      drop(v263_6);
      map_map_kernels::compose(&(v262_5),&(v263_7))
    };
    drop(v262_5);
    let v262_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v262_2));
    drop(v262_2);
    let v262_10: Space = if map_kernels::has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
    drop(v262_9);
    let v262_13: Space = if (&(v262_10)).is_empty() { Space::new() } else {
      let mut v273_12 = Space::new();
      let mut v273_12_write = v273_12.write_zipper();
      let mut v273_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v261_28_cursor.path()[v261_28_origin..(v261_28_origin + 1)]);
      let v273_12_origin = v273_12_cursor.path().len();
      for v273_12_byte in v273_12_cursor.child_mask().iter() {
        v273_12_cursor.descend_to_existing_byte(v273_12_byte);
        {
        let v274_2: Space = singleton(&v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 1)]);
        let v274_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v274_2));
        let v274_4: Space = if map_kernels::has_head(&(v274_3)) { singleton(&[]) } else { Space::new() };
        drop(v274_3);
        let v274_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v274_4));
        drop(v274_4);
        let v274_7: Space = if (&(v274_5)).is_empty() { Space::new() } else {
          let mut v275_6 = Space::new();
          let mut v275_6_write = v275_6.write_zipper();
          for v275_6_byte in v273_12_cursor.child_mask().iter() {
            v273_12_cursor.descend_to_existing_byte(v275_6_byte);
            {
            let v276_2: Space = singleton(&v273_12_cursor.path()[(v273_12_origin + 1)..(v273_12_origin + 2)]);
            let v276_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v276_2));
            let v276_4: Space = if map_kernels::has_head(&(v276_3)) { singleton(&[]) } else { Space::new() };
            drop(v276_3);
            let v276_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v276_4));
            drop(v276_4);
            let v276_8: Space = if (&(v276_5)).is_empty() { Space::new() } else {
              let v277_7: Space = routine_17(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              map_map_kernels::compose(&(v276_5),&(v277_7))
            };
            drop(v276_5);
            let v276_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v276_2));
            drop(v276_2);
            let v276_10: Space = if map_kernels::has_head(&(v276_9)) { singleton(&[]) } else { Space::new() };
            drop(v276_9);
            let v276_12: Space = if (&(v276_10)).is_empty() { Space::new() } else {
              let v278_11: Space = routine_18(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              map_map_kernels::compose(&(v276_10),&(v278_11))
            };
            drop(v276_10);
            let v276_13: Space = map_map_kernels::unite(&(v276_8),&(v276_12));
            join_wrapped_into(&mut v275_6_write,&((v276_13).read_zipper()),&[]);
            }
            v273_12_cursor.ascend(1);
          }
          drop(v275_6_write);
          map_map_kernels::compose(&(v274_5),&(v275_6))
        };
        drop(v274_5);
        let v274_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v274_2));
        drop(v274_2);
        let v274_9: Space = if map_kernels::has_head(&(v274_8)) { singleton(&[]) } else { Space::new() };
        drop(v274_8);
        let v274_11: Space = if (&(v274_9)).is_empty() { Space::new() } else {
          let mut v279_10 = Space::new();
          let mut v279_10_write = v279_10.write_zipper();
          for v279_10_byte in v273_12_cursor.child_mask().iter() {
            v273_12_cursor.descend_to_existing_byte(v279_10_byte);
            {
            let v280_2: Space = singleton(&v273_12_cursor.path()[(v273_12_origin + 1)..(v273_12_origin + 2)]);
            let v280_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v280_2));
            let v280_4: Space = if map_kernels::has_head(&(v280_3)) { singleton(&[]) } else { Space::new() };
            drop(v280_3);
            let v280_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v280_4));
            drop(v280_4);
            let v280_8: Space = if (&(v280_5)).is_empty() { Space::new() } else {
              let v281_7: Space = routine_17(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              map_map_kernels::compose(&(v280_5),&(v281_7))
            };
            drop(v280_5);
            let v280_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v280_2));
            drop(v280_2);
            let v280_10: Space = if map_kernels::has_head(&(v280_9)) { singleton(&[]) } else { Space::new() };
            drop(v280_9);
            let v280_12: Space = if (&(v280_10)).is_empty() { Space::new() } else {
              let v282_11: Space = routine_19(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              map_map_kernels::compose(&(v280_10),&(v282_11))
            };
            drop(v280_10);
            let v280_13: Space = map_map_kernels::unite(&(v280_8),&(v280_12));
            join_wrapped_into(&mut v279_10_write,&((v280_13).read_zipper()),&[]);
            }
            v273_12_cursor.ascend(1);
          }
          drop(v279_10_write);
          map_map_kernels::compose(&(v274_9),&(v279_10))
        };
        drop(v274_9);
        let v274_12: Space = map_map_kernels::unite(&(v274_7),&(v274_11));
        join_wrapped_into(&mut v273_12_write,&((v274_12).read_zipper()),&[]);
        }
        v273_12_cursor.ascend(1);
      }
      drop(v273_12_cursor);
      drop(v273_12_write);
      map_map_kernels::compose(&(v262_10),&(v273_12))
    };
    drop(v262_10);
    let v262_14: Space = map_map_kernels::unite(&(v262_8),&(v262_13));
    join_wrapped_into(&mut v261_28_write,&((v262_14).read_zipper()),&[]);
    }
    v261_28_cursor.ascend(1);
  }
  drop(v261_28_cursor);
  drop(v261_28_write);
  (v261_28).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v283_21 = Space::new();
  let mut v283_21_write = v283_21.write_zipper();
  let mut v283_21_cursor = (*s0).read_zipper();
  let v283_21_origin = v283_21_cursor.path().len();
  for v283_21_byte in v283_21_cursor.child_mask().iter() {
    v283_21_cursor.descend_to_existing_byte(v283_21_byte);
    {
    let v284_2: Space = singleton(&v283_21_cursor.path()[v283_21_origin..(v283_21_origin + 1)]);
    let v284_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v284_2));
    let v284_4: Space = if map_kernels::has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
    drop(v284_3);
    let v284_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v284_4));
    drop(v284_4);
    let v284_8: Space = if (&(v284_5)).is_empty() { Space::new() } else {
      let v285_6: Path = concat_path(&(*p0),&v283_21_cursor.path()[v283_21_origin..(v283_21_origin + 1)]);
      let mut v285_7 = Space::new();
      let mut v285_7_write = v285_7.write_zipper();
      for v285_7_byte in v283_21_cursor.child_mask().iter() {
        v283_21_cursor.descend_to_existing_byte(v285_7_byte);
        {
        let v286_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
        let v286_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v286_2));
        let v286_4: Space = if map_kernels::has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
        drop(v286_3);
        let v286_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v286_4));
        drop(v286_4);
        let v286_8: Space = if (&(v286_5)).is_empty() { Space::new() } else {
          let v287_6: Path = concat_path(&(v285_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
          let mut v287_7 = Space::new();
          let mut v287_7_write = v287_7.write_zipper();
          for v287_7_byte in v283_21_cursor.child_mask().iter() {
            v283_21_cursor.descend_to_existing_byte(v287_7_byte);
            {
            let v288_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
            let v288_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v288_2));
            let v288_4: Space = if map_kernels::has_head(&(v288_3)) { singleton(&[]) } else { Space::new() };
            drop(v288_3);
            let v288_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v288_4));
            drop(v288_4);
            let v288_8: Space = if (&(v288_5)).is_empty() { Space::new() } else {
              let v289_6: Path = concat_path(&(v287_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v289_7: Space = routine_28(c, &(v289_6), &(*p1), &v283_21_cursor);
              map_map_kernels::compose(&(v288_5),&(v289_7))
            };
            drop(v288_5);
            let v288_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v288_2));
            drop(v288_2);
            let v288_10: Space = if map_kernels::has_head(&(v288_9)) { singleton(&[]) } else { Space::new() };
            drop(v288_9);
            let v288_12: Space = if (&(v288_10)).is_empty() { Space::new() } else {
              let v290_6: Path = concat_path(&(v287_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v290_11: Space = routine_29(c, &(v290_6), &(*p1), &v283_21_cursor);
              drop(v290_6);
              map_map_kernels::compose(&(v288_10),&(v290_11))
            };
            drop(v288_10);
            let v288_13: Space = map_map_kernels::unite(&(v288_8),&(v288_12));
            join_wrapped_into(&mut v287_7_write,&((v288_13).read_zipper()),&[]);
            }
            v283_21_cursor.ascend(1);
          }
          drop(v287_7_write);
          map_map_kernels::compose(&(v286_5),&(v287_7))
        };
        drop(v286_5);
        let v286_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v286_2));
        drop(v286_2);
        let v286_10: Space = if map_kernels::has_head(&(v286_9)) { singleton(&[]) } else { Space::new() };
        drop(v286_9);
        let v286_12: Space = if (&(v286_10)).is_empty() { Space::new() } else {
          let v291_6: Path = concat_path(&(v285_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
          let mut v291_11 = Space::new();
          let mut v291_11_write = v291_11.write_zipper();
          for v291_11_byte in v283_21_cursor.child_mask().iter() {
            v283_21_cursor.descend_to_existing_byte(v291_11_byte);
            {
            let v292_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
            let v292_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v292_2));
            let v292_4: Space = if map_kernels::has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
            drop(v292_3);
            let v292_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v292_4));
            drop(v292_4);
            let v292_8: Space = if (&(v292_5)).is_empty() { Space::new() } else {
              let v293_6: Path = concat_path(&(v291_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v293_7: Space = routine_28(c, &(v293_6), &(*p1), &v283_21_cursor);
              map_map_kernels::compose(&(v292_5),&(v293_7))
            };
            drop(v292_5);
            let v292_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v292_2));
            drop(v292_2);
            let v292_10: Space = if map_kernels::has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
            drop(v292_9);
            let v292_12: Space = if (&(v292_10)).is_empty() { Space::new() } else {
              let v294_6: Path = concat_path(&(v291_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v294_11: Space = routine_19(c, &(v294_6), &(*p1), &v283_21_cursor);
              drop(v294_6);
              map_map_kernels::compose(&(v292_10),&(v294_11))
            };
            drop(v292_10);
            let v292_13: Space = map_map_kernels::unite(&(v292_8),&(v292_12));
            join_wrapped_into(&mut v291_11_write,&((v292_13).read_zipper()),&[]);
            }
            v283_21_cursor.ascend(1);
          }
          drop(v291_11_write);
          drop(v291_6);
          map_map_kernels::compose(&(v286_10),&(v291_11))
        };
        drop(v286_10);
        let v286_13: Space = map_map_kernels::unite(&(v286_8),&(v286_12));
        join_wrapped_into(&mut v285_7_write,&((v286_13).read_zipper()),&[]);
        }
        v283_21_cursor.ascend(1);
      }
      drop(v285_7_write);
      map_map_kernels::compose(&(v284_5),&(v285_7))
    };
    drop(v284_5);
    let v284_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v284_2));
    drop(v284_2);
    let v284_10: Space = if map_kernels::has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
    drop(v284_9);
    let v284_12: Space = if (&(v284_10)).is_empty() { Space::new() } else {
      let v295_6: Path = concat_path(&(*p0),&v283_21_cursor.path()[v283_21_origin..(v283_21_origin + 1)]);
      let mut v295_11 = Space::new();
      let mut v295_11_write = v295_11.write_zipper();
      for v295_11_byte in v283_21_cursor.child_mask().iter() {
        v283_21_cursor.descend_to_existing_byte(v295_11_byte);
        {
        let v296_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
        let v296_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v296_2));
        let v296_4: Space = if map_kernels::has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
        drop(v296_3);
        let v296_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v296_4));
        drop(v296_4);
        let v296_8: Space = if (&(v296_5)).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v295_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
          let mut v297_7 = Space::new();
          let mut v297_7_write = v297_7.write_zipper();
          for v297_7_byte in v283_21_cursor.child_mask().iter() {
            v283_21_cursor.descend_to_existing_byte(v297_7_byte);
            {
            let v298_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
            let v298_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v298_2));
            let v298_4: Space = if map_kernels::has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v298_4));
            drop(v298_4);
            let v298_8: Space = if (&(v298_5)).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v297_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v299_7: Space = routine_28(c, &(v299_6), &(*p1), &v283_21_cursor);
              map_map_kernels::compose(&(v298_5),&(v299_7))
            };
            drop(v298_5);
            let v298_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v298_2));
            drop(v298_2);
            let v298_10: Space = if map_kernels::has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
            drop(v298_9);
            let v298_12: Space = if (&(v298_10)).is_empty() { Space::new() } else {
              let v300_6: Path = concat_path(&(v297_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v300_11: Space = routine_29(c, &(v300_6), &(*p1), &v283_21_cursor);
              drop(v300_6);
              map_map_kernels::compose(&(v298_10),&(v300_11))
            };
            drop(v298_10);
            let v298_13: Space = map_map_kernels::unite(&(v298_8),&(v298_12));
            join_wrapped_into(&mut v297_7_write,&((v298_13).read_zipper()),&[]);
            }
            v283_21_cursor.ascend(1);
          }
          drop(v297_7_write);
          map_map_kernels::compose(&(v296_5),&(v297_7))
        };
        drop(v296_5);
        let v296_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v296_2));
        drop(v296_2);
        let v296_10: Space = if map_kernels::has_head(&(v296_9)) { singleton(&[]) } else { Space::new() };
        drop(v296_9);
        let v296_11: Space = map_view_kernels::compose(&(v296_10),&v283_21_cursor);
        drop(v296_10);
        let v301_6: Path = concat_path(&(v295_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
        let v296_12: Space = map_kernels::wrap(&(v296_11),&(v301_6));
        drop(v296_11);
        let v296_13: Space = map_kernels::wrap(&(v296_12),&(*p1));
        drop(v296_12);
        let v296_14: Space = map_map_kernels::unite(&(v296_8),&(v296_13));
        drop(v296_13);
        join_wrapped_into(&mut v295_11_write,&((v296_14).read_zipper()),&[]);
        }
        v283_21_cursor.ascend(1);
      }
      drop(v295_11_write);
      drop(v295_6);
      map_map_kernels::compose(&(v284_10),&(v295_11))
    };
    drop(v284_10);
    let v284_13: Space = map_map_kernels::unite(&(v284_8),&(v284_12));
    join_wrapped_into(&mut v283_21_write,&((v284_13).read_zipper()),&[]);
    }
    v283_21_cursor.ascend(1);
  }
  drop(v283_21_cursor);
  drop(v283_21_write);
  (v283_21).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v302_15 = Space::new();
  let mut v302_15_write = v302_15.write_zipper();
  let mut v302_15_cursor = (*s0).read_zipper();
  let v302_15_origin = v302_15_cursor.path().len();
  for v302_15_byte in v302_15_cursor.child_mask().iter() {
    v302_15_cursor.descend_to_existing_byte(v302_15_byte);
    {
    let v303_2: Space = singleton(&v302_15_cursor.path()[v302_15_origin..(v302_15_origin + 1)]);
    let v303_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v303_2));
    let v303_4: Space = if map_kernels::has_head(&(v303_3)) { singleton(&[]) } else { Space::new() };
    drop(v303_3);
    let v303_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v303_4));
    drop(v303_4);
    let v303_8: Space = if (&(v303_5)).is_empty() { Space::new() } else {
      let v304_6: Path = concat_path(&(*p0),&v302_15_cursor.path()[v302_15_origin..(v302_15_origin + 1)]);
      let mut v304_7 = Space::new();
      let mut v304_7_write = v304_7.write_zipper();
      for v304_7_byte in v302_15_cursor.child_mask().iter() {
        v302_15_cursor.descend_to_existing_byte(v304_7_byte);
        {
        let v305_2: Space = singleton(&v302_15_cursor.path()[(v302_15_origin + 1)..(v302_15_origin + 2)]);
        let v305_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v305_2));
        let v305_4: Space = if map_kernels::has_head(&(v305_3)) { singleton(&[]) } else { Space::new() };
        drop(v305_3);
        let v305_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v305_4));
        drop(v305_4);
        let v305_8: Space = if (&(v305_5)).is_empty() { Space::new() } else {
          let v306_6: Path = concat_path(&(v304_6),&v302_15_cursor.path()[(v302_15_origin + 1)..(v302_15_origin + 2)]);
          let mut v306_7 = Space::new();
          let mut v306_7_write = v306_7.write_zipper();
          for v306_7_byte in v302_15_cursor.child_mask().iter() {
            v302_15_cursor.descend_to_existing_byte(v306_7_byte);
            {
            let v307_2: Space = singleton(&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
            let v307_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v307_2));
            let v307_4: Space = if map_kernels::has_head(&(v307_3)) { singleton(&[]) } else { Space::new() };
            drop(v307_3);
            let v307_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v307_4));
            drop(v307_4);
            let v307_8: Space = if (&(v307_5)).is_empty() { Space::new() } else {
              let v308_6: Path = concat_path(&(v306_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v308_7: Space = routine_28(c, &(v308_6), &(*p1), &v302_15_cursor);
              map_map_kernels::compose(&(v307_5),&(v308_7))
            };
            drop(v307_5);
            let v307_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v307_2));
            drop(v307_2);
            let v307_10: Space = if map_kernels::has_head(&(v307_9)) { singleton(&[]) } else { Space::new() };
            drop(v307_9);
            let v307_12: Space = if (&(v307_10)).is_empty() { Space::new() } else {
              let v309_6: Path = concat_path(&(v306_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v309_11: Space = routine_29(c, &(v309_6), &(*p1), &v302_15_cursor);
              drop(v309_6);
              map_map_kernels::compose(&(v307_10),&(v309_11))
            };
            drop(v307_10);
            let v307_13: Space = map_map_kernels::unite(&(v307_8),&(v307_12));
            join_wrapped_into(&mut v306_7_write,&((v307_13).read_zipper()),&[]);
            }
            v302_15_cursor.ascend(1);
          }
          drop(v306_7_write);
          map_map_kernels::compose(&(v305_5),&(v306_7))
        };
        drop(v305_5);
        let v305_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v305_2));
        drop(v305_2);
        let v305_10: Space = if map_kernels::has_head(&(v305_9)) { singleton(&[]) } else { Space::new() };
        drop(v305_9);
        let v305_12: Space = if (&(v305_10)).is_empty() { Space::new() } else {
          let v310_6: Path = concat_path(&(v304_6),&v302_15_cursor.path()[(v302_15_origin + 1)..(v302_15_origin + 2)]);
          let mut v310_11 = Space::new();
          let mut v310_11_write = v310_11.write_zipper();
          for v310_11_byte in v302_15_cursor.child_mask().iter() {
            v302_15_cursor.descend_to_existing_byte(v310_11_byte);
            {
            let v311_2: Space = singleton(&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
            let v311_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v311_2));
            let v311_4: Space = if map_kernels::has_head(&(v311_3)) { singleton(&[]) } else { Space::new() };
            drop(v311_3);
            let v311_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v311_4));
            drop(v311_4);
            let v311_8: Space = if (&(v311_5)).is_empty() { Space::new() } else {
              let v312_6: Path = concat_path(&(v310_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v312_7: Space = routine_28(c, &(v312_6), &(*p1), &v302_15_cursor);
              map_map_kernels::compose(&(v311_5),&(v312_7))
            };
            drop(v311_5);
            let v311_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v311_2));
            drop(v311_2);
            let v311_10: Space = if map_kernels::has_head(&(v311_9)) { singleton(&[]) } else { Space::new() };
            drop(v311_9);
            let v311_12: Space = if (&(v311_10)).is_empty() { Space::new() } else {
              let v313_6: Path = concat_path(&(v310_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v313_11: Space = routine_19(c, &(v313_6), &(*p1), &v302_15_cursor);
              drop(v313_6);
              map_map_kernels::compose(&(v311_10),&(v313_11))
            };
            drop(v311_10);
            let v311_13: Space = map_map_kernels::unite(&(v311_8),&(v311_12));
            join_wrapped_into(&mut v310_11_write,&((v311_13).read_zipper()),&[]);
            }
            v302_15_cursor.ascend(1);
          }
          drop(v310_11_write);
          drop(v310_6);
          map_map_kernels::compose(&(v305_10),&(v310_11))
        };
        drop(v305_10);
        let v305_13: Space = map_map_kernels::unite(&(v305_8),&(v305_12));
        join_wrapped_into(&mut v304_7_write,&((v305_13).read_zipper()),&[]);
        }
        v302_15_cursor.ascend(1);
      }
      drop(v304_7_write);
      map_map_kernels::compose(&(v303_5),&(v304_7))
    };
    drop(v303_5);
    let v303_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v303_2));
    drop(v303_2);
    let v303_10: Space = if map_kernels::has_head(&(v303_9)) { singleton(&[]) } else { Space::new() };
    drop(v303_9);
    let v303_11: Space = map_view_kernels::compose(&(v303_10),&v302_15_cursor);
    drop(v303_10);
    let v314_6: Path = concat_path(&(*p0),&v302_15_cursor.path()[v302_15_origin..(v302_15_origin + 1)]);
    let v303_12: Space = map_kernels::wrap(&(v303_11),&(v314_6));
    drop(v303_11);
    let v303_13: Space = map_kernels::wrap(&(v303_12),&(*p1));
    drop(v303_12);
    let v303_14: Space = map_map_kernels::unite(&(v303_8),&(v303_13));
    drop(v303_13);
    join_wrapped_into(&mut v302_15_write,&((v303_14).read_zipper()),&[]);
    }
    v302_15_cursor.ascend(1);
  }
  drop(v302_15_cursor);
  drop(v302_15_write);
  (v302_15).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v315_28 = Space::new();
  let mut v315_28_write = v315_28.write_zipper();
  let mut v315_28_cursor = (*s0).read_zipper();
  let v315_28_origin = v315_28_cursor.path().len();
  for v315_28_byte in v315_28_cursor.child_mask().iter() {
    v315_28_cursor.descend_to_existing_byte(v315_28_byte);
    {
    let v316_2: Space = singleton(&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]);
    let v316_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v316_2));
    let v316_4: Space = if map_kernels::has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
    drop(v316_3);
    let v316_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v316_4));
    drop(v316_4);
    let v316_8: Space = if (&(v316_5)).is_empty() { Space::new() } else {
      let v317_6: Path = concat_path(&(*p0),&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]);
      let mut v317_7 = Space::new();
      let mut v317_7_write = v317_7.write_zipper();
      for v317_7_byte in v315_28_cursor.child_mask().iter() {
        v315_28_cursor.descend_to_existing_byte(v317_7_byte);
        {
        let v318_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
        let v318_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v318_2));
        let v318_4: Space = if map_kernels::has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
        drop(v318_3);
        let v318_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v318_4));
        drop(v318_4);
        let v318_8: Space = if (&(v318_5)).is_empty() { Space::new() } else {
          let v319_6: Path = concat_path(&(v317_6),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let mut v319_7 = Space::new();
          let mut v319_7_write = v319_7.write_zipper();
          for v319_7_byte in v315_28_cursor.child_mask().iter() {
            v315_28_cursor.descend_to_existing_byte(v319_7_byte);
            {
            let v320_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
            let v320_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v320_2));
            let v320_4: Space = if map_kernels::has_head(&(v320_3)) { singleton(&[]) } else { Space::new() };
            drop(v320_3);
            let v320_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v320_4));
            drop(v320_4);
            let v320_8: Space = if (&(v320_5)).is_empty() { Space::new() } else {
              let v321_6: Path = concat_path(&(v319_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v321_7: Space = routine_30(c, &(v321_6), &(*p1), &v315_28_cursor, &(*s1));
              map_map_kernels::compose(&(v320_5),&(v321_7))
            };
            drop(v320_5);
            let v320_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v320_2));
            drop(v320_2);
            let v320_10: Space = if map_kernels::has_head(&(v320_9)) { singleton(&[]) } else { Space::new() };
            drop(v320_9);
            let v320_12: Space = if (&(v320_10)).is_empty() { Space::new() } else {
              let v322_6: Path = concat_path(&(v319_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v322_11: Space = routine_31(c, &(v322_6), &(*p1), &v315_28_cursor, &(*s1));
              drop(v322_6);
              map_map_kernels::compose(&(v320_10),&(v322_11))
            };
            drop(v320_10);
            let v320_13: Space = map_map_kernels::unite(&(v320_8),&(v320_12));
            join_wrapped_into(&mut v319_7_write,&((v320_13).read_zipper()),&[]);
            }
            v315_28_cursor.ascend(1);
          }
          drop(v319_7_write);
          map_map_kernels::compose(&(v318_5),&(v319_7))
        };
        drop(v318_5);
        let v318_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v318_2));
        drop(v318_2);
        let v318_10: Space = if map_kernels::has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
        drop(v318_9);
        let v318_12: Space = if (&(v318_10)).is_empty() { Space::new() } else {
          let v323_6: Path = concat_path(&(v317_6),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let mut v323_11 = Space::new();
          let mut v323_11_write = v323_11.write_zipper();
          for v323_11_byte in v315_28_cursor.child_mask().iter() {
            v315_28_cursor.descend_to_existing_byte(v323_11_byte);
            {
            let v324_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
            let v324_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v324_2));
            let v324_4: Space = if map_kernels::has_head(&(v324_3)) { singleton(&[]) } else { Space::new() };
            drop(v324_3);
            let v324_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v324_4));
            drop(v324_4);
            let v324_8: Space = if (&(v324_5)).is_empty() { Space::new() } else {
              let v325_6: Path = concat_path(&(v323_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v325_7: Space = routine_30(c, &(v325_6), &(*p1), &v315_28_cursor, &(*s1));
              map_map_kernels::compose(&(v324_5),&(v325_7))
            };
            drop(v324_5);
            let v324_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v324_2));
            drop(v324_2);
            let v324_10: Space = if map_kernels::has_head(&(v324_9)) { singleton(&[]) } else { Space::new() };
            drop(v324_9);
            let v324_12: Space = if (&(v324_10)).is_empty() { Space::new() } else {
              let v326_6: Path = concat_path(&(v323_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v326_11: Space = routine_10(c, &(v326_6), &(*p1), &v315_28_cursor, &(*s1));
              drop(v326_6);
              map_map_kernels::compose(&(v324_10),&(v326_11))
            };
            drop(v324_10);
            let v324_13: Space = map_map_kernels::unite(&(v324_8),&(v324_12));
            join_wrapped_into(&mut v323_11_write,&((v324_13).read_zipper()),&[]);
            }
            v315_28_cursor.ascend(1);
          }
          drop(v323_11_write);
          drop(v323_6);
          map_map_kernels::compose(&(v318_10),&(v323_11))
        };
        drop(v318_10);
        let v318_13: Space = map_map_kernels::unite(&(v318_8),&(v318_12));
        join_wrapped_into(&mut v317_7_write,&((v318_13).read_zipper()),&[]);
        }
        v315_28_cursor.ascend(1);
      }
      drop(v317_7_write);
      map_map_kernels::compose(&(v316_5),&(v317_7))
    };
    drop(v316_5);
    let v316_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v316_2));
    drop(v316_2);
    let v316_10: Space = if map_kernels::has_head(&(v316_9)) { singleton(&[]) } else { Space::new() };
    drop(v316_9);
    let v316_13: Space = if (&(v316_10)).is_empty() { Space::new() } else {
      let v327_6: Path = concat_path(&(*p0),&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]);
      let mut v327_12 = Space::new();
      let mut v327_12_write = v327_12.write_zipper();
      for v327_12_byte in v315_28_cursor.child_mask().iter() {
        v315_28_cursor.descend_to_existing_byte(v327_12_byte);
        {
        let v328_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
        let v328_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v328_2));
        let v328_4: Space = if map_kernels::has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
        drop(v328_3);
        let v328_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v328_4));
        drop(v328_4);
        let v328_8: Space = if (&(v328_5)).is_empty() { Space::new() } else {
          let v329_6: Path = concat_path(&(v327_6),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let mut v329_7 = Space::new();
          let mut v329_7_write = v329_7.write_zipper();
          for v329_7_byte in v315_28_cursor.child_mask().iter() {
            v315_28_cursor.descend_to_existing_byte(v329_7_byte);
            {
            let v330_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
            let v330_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v330_2));
            let v330_4: Space = if map_kernels::has_head(&(v330_3)) { singleton(&[]) } else { Space::new() };
            drop(v330_3);
            let v330_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v330_4));
            drop(v330_4);
            let v330_8: Space = if (&(v330_5)).is_empty() { Space::new() } else {
              let v331_6: Path = concat_path(&(v329_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v331_7: Space = routine_30(c, &(v331_6), &(*p1), &v315_28_cursor, &(*s1));
              map_map_kernels::compose(&(v330_5),&(v331_7))
            };
            drop(v330_5);
            let v330_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v330_2));
            drop(v330_2);
            let v330_10: Space = if map_kernels::has_head(&(v330_9)) { singleton(&[]) } else { Space::new() };
            drop(v330_9);
            let v330_12: Space = if (&(v330_10)).is_empty() { Space::new() } else {
              let v332_6: Path = concat_path(&(v329_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v332_11: Space = routine_31(c, &(v332_6), &(*p1), &v315_28_cursor, &(*s1));
              drop(v332_6);
              map_map_kernels::compose(&(v330_10),&(v332_11))
            };
            drop(v330_10);
            let v330_13: Space = map_map_kernels::unite(&(v330_8),&(v330_12));
            join_wrapped_into(&mut v329_7_write,&((v330_13).read_zipper()),&[]);
            }
            v315_28_cursor.ascend(1);
          }
          drop(v329_7_write);
          drop(v329_6);
          map_map_kernels::compose(&(v328_5),&(v329_7))
        };
        drop(v328_5);
        let v328_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v328_2));
        drop(v328_2);
        let v328_10: Space = if map_kernels::has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
        drop(v328_9);
        let v328_13: Space = if (&(v328_10)).is_empty() { Space::new() } else {
          let mut v333_12 = Space::new();
          let mut v333_12_write = v333_12.write_zipper();
          let mut v333_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let v333_12_origin = v333_12_cursor.path().len();
          for v333_12_byte in v333_12_cursor.child_mask().iter() {
            v333_12_cursor.descend_to_existing_byte(v333_12_byte);
            {
            let v334_2: Space = singleton(&v333_12_cursor.path()[v333_12_origin..(v333_12_origin + 1)]);
            let v334_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v334_2));
            let v334_4: Space = if map_kernels::has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
            drop(v334_3);
            let v334_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v334_4));
            drop(v334_4);
            let v334_7: Space = if (&(v334_5)).is_empty() { Space::new() } else {
              let v335_6: Space = routine_13(c, &v333_12_cursor.path()[v333_12_origin..(v333_12_origin + 1)], &(*p1), &v333_12_cursor);
              map_map_kernels::compose(&(v334_5),&(v335_6))
            };
            drop(v334_5);
            let v334_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v334_2));
            drop(v334_2);
            let v334_9: Space = if map_kernels::has_head(&(v334_8)) { singleton(&[]) } else { Space::new() };
            drop(v334_8);
            let v334_11: Space = if (&(v334_9)).is_empty() { Space::new() } else {
              let v336_10: Space = routine_14(c, &v333_12_cursor.path()[v333_12_origin..(v333_12_origin + 1)], &(*p1), &v333_12_cursor);
              map_map_kernels::compose(&(v334_9),&(v336_10))
            };
            drop(v334_9);
            let v334_12: Space = map_map_kernels::unite(&(v334_7),&(v334_11));
            join_wrapped_into(&mut v333_12_write,&((v334_12).read_zipper()),&[]);
            }
            v333_12_cursor.ascend(1);
          }
          drop(v333_12_cursor);
          drop(v333_12_write);
          map_map_kernels::compose(&(v328_10),&(v333_12))
        };
        drop(v328_10);
        let v328_14: Space = map_map_kernels::unite(&(v328_8),&(v328_13));
        join_wrapped_into(&mut v327_12_write,&((v328_14).read_zipper()),&[]);
        }
        v315_28_cursor.ascend(1);
      }
      drop(v327_12_write);
      drop(v327_6);
      map_map_kernels::compose(&(v316_10),&(v327_12))
    };
    drop(v316_10);
    let v316_14: Space = map_map_kernels::unite(&(v316_8),&(v316_13));
    join_wrapped_into(&mut v315_28_write,&((v316_14).read_zipper()),&[]);
    }
    v315_28_cursor.ascend(1);
  }
  drop(v315_28_cursor);
  drop(v315_28_write);
  (v315_28).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v337_28 = Space::new();
  let mut v337_28_write = v337_28.write_zipper();
  let mut v337_28_cursor = (*s0).read_zipper();
  let v337_28_origin = v337_28_cursor.path().len();
  for v337_28_byte in v337_28_cursor.child_mask().iter() {
    v337_28_cursor.descend_to_existing_byte(v337_28_byte);
    {
    let v338_2: Space = singleton(&v337_28_cursor.path()[v337_28_origin..(v337_28_origin + 1)]);
    let v338_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v338_2));
    let v338_4: Space = if map_kernels::has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
    drop(v338_3);
    let v338_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v338_4));
    drop(v338_4);
    let v338_8: Space = if (&(v338_5)).is_empty() { Space::new() } else {
      let v339_6: Path = concat_path(&(*p0),&v337_28_cursor.path()[v337_28_origin..(v337_28_origin + 1)]);
      let mut v339_7 = Space::new();
      let mut v339_7_write = v339_7.write_zipper();
      for v339_7_byte in v337_28_cursor.child_mask().iter() {
        v337_28_cursor.descend_to_existing_byte(v339_7_byte);
        {
        let v340_2: Space = singleton(&v337_28_cursor.path()[(v337_28_origin + 1)..(v337_28_origin + 2)]);
        let v340_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v340_2));
        let v340_4: Space = if map_kernels::has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
        drop(v340_3);
        let v340_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v340_4));
        drop(v340_4);
        let v340_8: Space = if (&(v340_5)).is_empty() { Space::new() } else {
          let v341_6: Path = concat_path(&(v339_6),&v337_28_cursor.path()[(v337_28_origin + 1)..(v337_28_origin + 2)]);
          let mut v341_7 = Space::new();
          let mut v341_7_write = v341_7.write_zipper();
          for v341_7_byte in v337_28_cursor.child_mask().iter() {
            v337_28_cursor.descend_to_existing_byte(v341_7_byte);
            {
            let v342_2: Space = singleton(&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
            let v342_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v342_2));
            let v342_4: Space = if map_kernels::has_head(&(v342_3)) { singleton(&[]) } else { Space::new() };
            drop(v342_3);
            let v342_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v342_4));
            drop(v342_4);
            let v342_8: Space = if (&(v342_5)).is_empty() { Space::new() } else {
              let v343_6: Path = concat_path(&(v341_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v343_7: Space = routine_30(c, &(v343_6), &(*p1), &v337_28_cursor, &(*s1));
              map_map_kernels::compose(&(v342_5),&(v343_7))
            };
            drop(v342_5);
            let v342_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v342_2));
            drop(v342_2);
            let v342_10: Space = if map_kernels::has_head(&(v342_9)) { singleton(&[]) } else { Space::new() };
            drop(v342_9);
            let v342_12: Space = if (&(v342_10)).is_empty() { Space::new() } else {
              let v344_6: Path = concat_path(&(v341_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v344_11: Space = routine_31(c, &(v344_6), &(*p1), &v337_28_cursor, &(*s1));
              drop(v344_6);
              map_map_kernels::compose(&(v342_10),&(v344_11))
            };
            drop(v342_10);
            let v342_13: Space = map_map_kernels::unite(&(v342_8),&(v342_12));
            join_wrapped_into(&mut v341_7_write,&((v342_13).read_zipper()),&[]);
            }
            v337_28_cursor.ascend(1);
          }
          drop(v341_7_write);
          map_map_kernels::compose(&(v340_5),&(v341_7))
        };
        drop(v340_5);
        let v340_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v340_2));
        drop(v340_2);
        let v340_10: Space = if map_kernels::has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
        drop(v340_9);
        let v340_12: Space = if (&(v340_10)).is_empty() { Space::new() } else {
          let v345_6: Path = concat_path(&(v339_6),&v337_28_cursor.path()[(v337_28_origin + 1)..(v337_28_origin + 2)]);
          let mut v345_11 = Space::new();
          let mut v345_11_write = v345_11.write_zipper();
          for v345_11_byte in v337_28_cursor.child_mask().iter() {
            v337_28_cursor.descend_to_existing_byte(v345_11_byte);
            {
            let v346_2: Space = singleton(&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
            let v346_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v346_2));
            let v346_4: Space = if map_kernels::has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
            drop(v346_3);
            let v346_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v346_4));
            drop(v346_4);
            let v346_8: Space = if (&(v346_5)).is_empty() { Space::new() } else {
              let v347_6: Path = concat_path(&(v345_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v347_7: Space = routine_30(c, &(v347_6), &(*p1), &v337_28_cursor, &(*s1));
              map_map_kernels::compose(&(v346_5),&(v347_7))
            };
            drop(v346_5);
            let v346_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v346_2));
            drop(v346_2);
            let v346_10: Space = if map_kernels::has_head(&(v346_9)) { singleton(&[]) } else { Space::new() };
            drop(v346_9);
            let v346_12: Space = if (&(v346_10)).is_empty() { Space::new() } else {
              let v348_6: Path = concat_path(&(v345_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v348_11: Space = routine_10(c, &(v348_6), &(*p1), &v337_28_cursor, &(*s1));
              drop(v348_6);
              map_map_kernels::compose(&(v346_10),&(v348_11))
            };
            drop(v346_10);
            let v346_13: Space = map_map_kernels::unite(&(v346_8),&(v346_12));
            join_wrapped_into(&mut v345_11_write,&((v346_13).read_zipper()),&[]);
            }
            v337_28_cursor.ascend(1);
          }
          drop(v345_11_write);
          drop(v345_6);
          map_map_kernels::compose(&(v340_10),&(v345_11))
        };
        drop(v340_10);
        let v340_13: Space = map_map_kernels::unite(&(v340_8),&(v340_12));
        join_wrapped_into(&mut v339_7_write,&((v340_13).read_zipper()),&[]);
        }
        v337_28_cursor.ascend(1);
      }
      drop(v339_7_write);
      drop(v339_6);
      map_map_kernels::compose(&(v338_5),&(v339_7))
    };
    drop(v338_5);
    let v338_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v338_2));
    drop(v338_2);
    let v338_10: Space = if map_kernels::has_head(&(v338_9)) { singleton(&[]) } else { Space::new() };
    drop(v338_9);
    let v338_13: Space = if (&(v338_10)).is_empty() { Space::new() } else {
      let mut v349_12 = Space::new();
      let mut v349_12_write = v349_12.write_zipper();
      let mut v349_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v337_28_cursor.path()[v337_28_origin..(v337_28_origin + 1)]);
      let v349_12_origin = v349_12_cursor.path().len();
      for v349_12_byte in v349_12_cursor.child_mask().iter() {
        v349_12_cursor.descend_to_existing_byte(v349_12_byte);
        {
        let v350_2: Space = singleton(&v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 1)]);
        let v350_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v350_2));
        let v350_4: Space = if map_kernels::has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
        drop(v350_3);
        let v350_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v350_4));
        drop(v350_4);
        let v350_7: Space = if (&(v350_5)).is_empty() { Space::new() } else {
          let mut v351_6 = Space::new();
          let mut v351_6_write = v351_6.write_zipper();
          for v351_6_byte in v349_12_cursor.child_mask().iter() {
            v349_12_cursor.descend_to_existing_byte(v351_6_byte);
            {
            let v352_2: Space = singleton(&v349_12_cursor.path()[(v349_12_origin + 1)..(v349_12_origin + 2)]);
            let v352_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v352_2));
            let v352_4: Space = if map_kernels::has_head(&(v352_3)) { singleton(&[]) } else { Space::new() };
            drop(v352_3);
            let v352_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v352_4));
            drop(v352_4);
            let v352_8: Space = if (&(v352_5)).is_empty() { Space::new() } else {
              let v353_7: Space = routine_17(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              map_map_kernels::compose(&(v352_5),&(v353_7))
            };
            drop(v352_5);
            let v352_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v352_2));
            drop(v352_2);
            let v352_10: Space = if map_kernels::has_head(&(v352_9)) { singleton(&[]) } else { Space::new() };
            drop(v352_9);
            let v352_12: Space = if (&(v352_10)).is_empty() { Space::new() } else {
              let v354_11: Space = routine_18(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              map_map_kernels::compose(&(v352_10),&(v354_11))
            };
            drop(v352_10);
            let v352_13: Space = map_map_kernels::unite(&(v352_8),&(v352_12));
            join_wrapped_into(&mut v351_6_write,&((v352_13).read_zipper()),&[]);
            }
            v349_12_cursor.ascend(1);
          }
          drop(v351_6_write);
          map_map_kernels::compose(&(v350_5),&(v351_6))
        };
        drop(v350_5);
        let v350_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v350_2));
        drop(v350_2);
        let v350_9: Space = if map_kernels::has_head(&(v350_8)) { singleton(&[]) } else { Space::new() };
        drop(v350_8);
        let v350_11: Space = if (&(v350_9)).is_empty() { Space::new() } else {
          let mut v355_10 = Space::new();
          let mut v355_10_write = v355_10.write_zipper();
          for v355_10_byte in v349_12_cursor.child_mask().iter() {
            v349_12_cursor.descend_to_existing_byte(v355_10_byte);
            {
            let v356_2: Space = singleton(&v349_12_cursor.path()[(v349_12_origin + 1)..(v349_12_origin + 2)]);
            let v356_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v356_2));
            let v356_4: Space = if map_kernels::has_head(&(v356_3)) { singleton(&[]) } else { Space::new() };
            drop(v356_3);
            let v356_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v356_4));
            drop(v356_4);
            let v356_8: Space = if (&(v356_5)).is_empty() { Space::new() } else {
              let v357_7: Space = routine_17(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              map_map_kernels::compose(&(v356_5),&(v357_7))
            };
            drop(v356_5);
            let v356_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v356_2));
            drop(v356_2);
            let v356_10: Space = if map_kernels::has_head(&(v356_9)) { singleton(&[]) } else { Space::new() };
            drop(v356_9);
            let v356_12: Space = if (&(v356_10)).is_empty() { Space::new() } else {
              let v358_11: Space = routine_19(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              map_map_kernels::compose(&(v356_10),&(v358_11))
            };
            drop(v356_10);
            let v356_13: Space = map_map_kernels::unite(&(v356_8),&(v356_12));
            join_wrapped_into(&mut v355_10_write,&((v356_13).read_zipper()),&[]);
            }
            v349_12_cursor.ascend(1);
          }
          drop(v355_10_write);
          map_map_kernels::compose(&(v350_9),&(v355_10))
        };
        drop(v350_9);
        let v350_12: Space = map_map_kernels::unite(&(v350_7),&(v350_11));
        join_wrapped_into(&mut v349_12_write,&((v350_12).read_zipper()),&[]);
        }
        v349_12_cursor.ascend(1);
      }
      drop(v349_12_cursor);
      drop(v349_12_write);
      map_map_kernels::compose(&(v338_10),&(v349_12))
    };
    drop(v338_10);
    let v338_14: Space = map_map_kernels::unite(&(v338_8),&(v338_13));
    join_wrapped_into(&mut v337_28_write,&((v338_14).read_zipper()),&[]);
    }
    v337_28_cursor.ascend(1);
  }
  drop(v337_28_cursor);
  drop(v337_28_write);
  (v337_28).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v359_21 = Space::new();
  let mut v359_21_write = v359_21.write_zipper();
  let mut v359_21_cursor = (*s0).read_zipper();
  let v359_21_origin = v359_21_cursor.path().len();
  for v359_21_byte in v359_21_cursor.child_mask().iter() {
    v359_21_cursor.descend_to_existing_byte(v359_21_byte);
    {
    let v360_2: Space = singleton(&v359_21_cursor.path()[v359_21_origin..(v359_21_origin + 1)]);
    let v360_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v360_2));
    let v360_4: Space = if map_kernels::has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
    drop(v360_3);
    let v360_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v360_4));
    drop(v360_4);
    let v360_8: Space = if (&(v360_5)).is_empty() { Space::new() } else {
      let v361_6: Path = concat_path(&(*p0),&v359_21_cursor.path()[v359_21_origin..(v359_21_origin + 1)]);
      let mut v361_7 = Space::new();
      let mut v361_7_write = v361_7.write_zipper();
      for v361_7_byte in v359_21_cursor.child_mask().iter() {
        v359_21_cursor.descend_to_existing_byte(v361_7_byte);
        {
        let v362_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
        let v362_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v362_2));
        let v362_4: Space = if map_kernels::has_head(&(v362_3)) { singleton(&[]) } else { Space::new() };
        drop(v362_3);
        let v362_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v362_4));
        drop(v362_4);
        let v362_8: Space = if (&(v362_5)).is_empty() { Space::new() } else {
          let v363_6: Path = concat_path(&(v361_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
          let mut v363_7 = Space::new();
          let mut v363_7_write = v363_7.write_zipper();
          for v363_7_byte in v359_21_cursor.child_mask().iter() {
            v359_21_cursor.descend_to_existing_byte(v363_7_byte);
            {
            let v364_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
            let v364_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v364_2));
            let v364_4: Space = if map_kernels::has_head(&(v364_3)) { singleton(&[]) } else { Space::new() };
            drop(v364_3);
            let v364_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v364_4));
            drop(v364_4);
            let v364_8: Space = if (&(v364_5)).is_empty() { Space::new() } else {
              let v365_6: Path = concat_path(&(v363_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v365_7: Space = routine_32(c, &(v365_6), &(*p1), &v359_21_cursor);
              map_map_kernels::compose(&(v364_5),&(v365_7))
            };
            drop(v364_5);
            let v364_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v364_2));
            drop(v364_2);
            let v364_10: Space = if map_kernels::has_head(&(v364_9)) { singleton(&[]) } else { Space::new() };
            drop(v364_9);
            let v364_12: Space = if (&(v364_10)).is_empty() { Space::new() } else {
              let v366_6: Path = concat_path(&(v363_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v366_11: Space = routine_33(c, &(v366_6), &(*p1), &v359_21_cursor);
              drop(v366_6);
              map_map_kernels::compose(&(v364_10),&(v366_11))
            };
            drop(v364_10);
            let v364_13: Space = map_map_kernels::unite(&(v364_8),&(v364_12));
            join_wrapped_into(&mut v363_7_write,&((v364_13).read_zipper()),&[]);
            }
            v359_21_cursor.ascend(1);
          }
          drop(v363_7_write);
          map_map_kernels::compose(&(v362_5),&(v363_7))
        };
        drop(v362_5);
        let v362_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v362_2));
        drop(v362_2);
        let v362_10: Space = if map_kernels::has_head(&(v362_9)) { singleton(&[]) } else { Space::new() };
        drop(v362_9);
        let v362_12: Space = if (&(v362_10)).is_empty() { Space::new() } else {
          let v367_6: Path = concat_path(&(v361_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
          let mut v367_11 = Space::new();
          let mut v367_11_write = v367_11.write_zipper();
          for v367_11_byte in v359_21_cursor.child_mask().iter() {
            v359_21_cursor.descend_to_existing_byte(v367_11_byte);
            {
            let v368_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
            let v368_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v368_2));
            let v368_4: Space = if map_kernels::has_head(&(v368_3)) { singleton(&[]) } else { Space::new() };
            drop(v368_3);
            let v368_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v368_4));
            drop(v368_4);
            let v368_8: Space = if (&(v368_5)).is_empty() { Space::new() } else {
              let v369_6: Path = concat_path(&(v367_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v369_7: Space = routine_32(c, &(v369_6), &(*p1), &v359_21_cursor);
              map_map_kernels::compose(&(v368_5),&(v369_7))
            };
            drop(v368_5);
            let v368_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v368_2));
            drop(v368_2);
            let v368_10: Space = if map_kernels::has_head(&(v368_9)) { singleton(&[]) } else { Space::new() };
            drop(v368_9);
            let v368_12: Space = if (&(v368_10)).is_empty() { Space::new() } else {
              let v370_6: Path = concat_path(&(v367_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v370_11: Space = routine_19(c, &(v370_6), &(*p1), &v359_21_cursor);
              drop(v370_6);
              map_map_kernels::compose(&(v368_10),&(v370_11))
            };
            drop(v368_10);
            let v368_13: Space = map_map_kernels::unite(&(v368_8),&(v368_12));
            join_wrapped_into(&mut v367_11_write,&((v368_13).read_zipper()),&[]);
            }
            v359_21_cursor.ascend(1);
          }
          drop(v367_11_write);
          drop(v367_6);
          map_map_kernels::compose(&(v362_10),&(v367_11))
        };
        drop(v362_10);
        let v362_13: Space = map_map_kernels::unite(&(v362_8),&(v362_12));
        join_wrapped_into(&mut v361_7_write,&((v362_13).read_zipper()),&[]);
        }
        v359_21_cursor.ascend(1);
      }
      drop(v361_7_write);
      map_map_kernels::compose(&(v360_5),&(v361_7))
    };
    drop(v360_5);
    let v360_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v360_2));
    drop(v360_2);
    let v360_10: Space = if map_kernels::has_head(&(v360_9)) { singleton(&[]) } else { Space::new() };
    drop(v360_9);
    let v360_12: Space = if (&(v360_10)).is_empty() { Space::new() } else {
      let v371_6: Path = concat_path(&(*p0),&v359_21_cursor.path()[v359_21_origin..(v359_21_origin + 1)]);
      let mut v371_11 = Space::new();
      let mut v371_11_write = v371_11.write_zipper();
      for v371_11_byte in v359_21_cursor.child_mask().iter() {
        v359_21_cursor.descend_to_existing_byte(v371_11_byte);
        {
        let v372_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
        let v372_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v372_2));
        let v372_4: Space = if map_kernels::has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
        drop(v372_3);
        let v372_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v372_4));
        drop(v372_4);
        let v372_8: Space = if (&(v372_5)).is_empty() { Space::new() } else {
          let v373_6: Path = concat_path(&(v371_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
          let mut v373_7 = Space::new();
          let mut v373_7_write = v373_7.write_zipper();
          for v373_7_byte in v359_21_cursor.child_mask().iter() {
            v359_21_cursor.descend_to_existing_byte(v373_7_byte);
            {
            let v374_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
            let v374_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v374_2));
            let v374_4: Space = if map_kernels::has_head(&(v374_3)) { singleton(&[]) } else { Space::new() };
            drop(v374_3);
            let v374_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v374_4));
            drop(v374_4);
            let v374_8: Space = if (&(v374_5)).is_empty() { Space::new() } else {
              let v375_6: Path = concat_path(&(v373_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v375_7: Space = routine_32(c, &(v375_6), &(*p1), &v359_21_cursor);
              map_map_kernels::compose(&(v374_5),&(v375_7))
            };
            drop(v374_5);
            let v374_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v374_2));
            drop(v374_2);
            let v374_10: Space = if map_kernels::has_head(&(v374_9)) { singleton(&[]) } else { Space::new() };
            drop(v374_9);
            let v374_12: Space = if (&(v374_10)).is_empty() { Space::new() } else {
              let v376_6: Path = concat_path(&(v373_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v376_11: Space = routine_33(c, &(v376_6), &(*p1), &v359_21_cursor);
              drop(v376_6);
              map_map_kernels::compose(&(v374_10),&(v376_11))
            };
            drop(v374_10);
            let v374_13: Space = map_map_kernels::unite(&(v374_8),&(v374_12));
            join_wrapped_into(&mut v373_7_write,&((v374_13).read_zipper()),&[]);
            }
            v359_21_cursor.ascend(1);
          }
          drop(v373_7_write);
          map_map_kernels::compose(&(v372_5),&(v373_7))
        };
        drop(v372_5);
        let v372_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v372_2));
        drop(v372_2);
        let v372_10: Space = if map_kernels::has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
        drop(v372_9);
        let v372_11: Space = map_view_kernels::compose(&(v372_10),&v359_21_cursor);
        drop(v372_10);
        let v377_6: Path = concat_path(&(v371_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
        let v372_12: Space = map_kernels::wrap(&(v372_11),&(v377_6));
        drop(v372_11);
        let v372_13: Space = map_kernels::wrap(&(v372_12),&(*p1));
        drop(v372_12);
        let v372_14: Space = map_map_kernels::unite(&(v372_8),&(v372_13));
        drop(v372_13);
        join_wrapped_into(&mut v371_11_write,&((v372_14).read_zipper()),&[]);
        }
        v359_21_cursor.ascend(1);
      }
      drop(v371_11_write);
      drop(v371_6);
      map_map_kernels::compose(&(v360_10),&(v371_11))
    };
    drop(v360_10);
    let v360_13: Space = map_map_kernels::unite(&(v360_8),&(v360_12));
    join_wrapped_into(&mut v359_21_write,&((v360_13).read_zipper()),&[]);
    }
    v359_21_cursor.ascend(1);
  }
  drop(v359_21_cursor);
  drop(v359_21_write);
  (v359_21).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v378_15 = Space::new();
  let mut v378_15_write = v378_15.write_zipper();
  let mut v378_15_cursor = (*s0).read_zipper();
  let v378_15_origin = v378_15_cursor.path().len();
  for v378_15_byte in v378_15_cursor.child_mask().iter() {
    v378_15_cursor.descend_to_existing_byte(v378_15_byte);
    {
    let v379_2: Space = singleton(&v378_15_cursor.path()[v378_15_origin..(v378_15_origin + 1)]);
    let v379_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v379_2));
    let v379_4: Space = if map_kernels::has_head(&(v379_3)) { singleton(&[]) } else { Space::new() };
    drop(v379_3);
    let v379_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v379_4));
    drop(v379_4);
    let v379_8: Space = if (&(v379_5)).is_empty() { Space::new() } else {
      let v380_6: Path = concat_path(&(*p0),&v378_15_cursor.path()[v378_15_origin..(v378_15_origin + 1)]);
      let mut v380_7 = Space::new();
      let mut v380_7_write = v380_7.write_zipper();
      for v380_7_byte in v378_15_cursor.child_mask().iter() {
        v378_15_cursor.descend_to_existing_byte(v380_7_byte);
        {
        let v381_2: Space = singleton(&v378_15_cursor.path()[(v378_15_origin + 1)..(v378_15_origin + 2)]);
        let v381_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v381_2));
        let v381_4: Space = if map_kernels::has_head(&(v381_3)) { singleton(&[]) } else { Space::new() };
        drop(v381_3);
        let v381_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v381_4));
        drop(v381_4);
        let v381_8: Space = if (&(v381_5)).is_empty() { Space::new() } else {
          let v382_6: Path = concat_path(&(v380_6),&v378_15_cursor.path()[(v378_15_origin + 1)..(v378_15_origin + 2)]);
          let mut v382_7 = Space::new();
          let mut v382_7_write = v382_7.write_zipper();
          for v382_7_byte in v378_15_cursor.child_mask().iter() {
            v378_15_cursor.descend_to_existing_byte(v382_7_byte);
            {
            let v383_2: Space = singleton(&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
            let v383_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v383_2));
            let v383_4: Space = if map_kernels::has_head(&(v383_3)) { singleton(&[]) } else { Space::new() };
            drop(v383_3);
            let v383_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v383_4));
            drop(v383_4);
            let v383_8: Space = if (&(v383_5)).is_empty() { Space::new() } else {
              let v384_6: Path = concat_path(&(v382_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v384_7: Space = routine_32(c, &(v384_6), &(*p1), &v378_15_cursor);
              map_map_kernels::compose(&(v383_5),&(v384_7))
            };
            drop(v383_5);
            let v383_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v383_2));
            drop(v383_2);
            let v383_10: Space = if map_kernels::has_head(&(v383_9)) { singleton(&[]) } else { Space::new() };
            drop(v383_9);
            let v383_12: Space = if (&(v383_10)).is_empty() { Space::new() } else {
              let v385_6: Path = concat_path(&(v382_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v385_11: Space = routine_33(c, &(v385_6), &(*p1), &v378_15_cursor);
              drop(v385_6);
              map_map_kernels::compose(&(v383_10),&(v385_11))
            };
            drop(v383_10);
            let v383_13: Space = map_map_kernels::unite(&(v383_8),&(v383_12));
            join_wrapped_into(&mut v382_7_write,&((v383_13).read_zipper()),&[]);
            }
            v378_15_cursor.ascend(1);
          }
          drop(v382_7_write);
          map_map_kernels::compose(&(v381_5),&(v382_7))
        };
        drop(v381_5);
        let v381_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v381_2));
        drop(v381_2);
        let v381_10: Space = if map_kernels::has_head(&(v381_9)) { singleton(&[]) } else { Space::new() };
        drop(v381_9);
        let v381_12: Space = if (&(v381_10)).is_empty() { Space::new() } else {
          let v386_6: Path = concat_path(&(v380_6),&v378_15_cursor.path()[(v378_15_origin + 1)..(v378_15_origin + 2)]);
          let mut v386_11 = Space::new();
          let mut v386_11_write = v386_11.write_zipper();
          for v386_11_byte in v378_15_cursor.child_mask().iter() {
            v378_15_cursor.descend_to_existing_byte(v386_11_byte);
            {
            let v387_2: Space = singleton(&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
            let v387_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v387_2));
            let v387_4: Space = if map_kernels::has_head(&(v387_3)) { singleton(&[]) } else { Space::new() };
            drop(v387_3);
            let v387_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v387_4));
            drop(v387_4);
            let v387_8: Space = if (&(v387_5)).is_empty() { Space::new() } else {
              let v388_6: Path = concat_path(&(v386_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v388_7: Space = routine_32(c, &(v388_6), &(*p1), &v378_15_cursor);
              map_map_kernels::compose(&(v387_5),&(v388_7))
            };
            drop(v387_5);
            let v387_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v387_2));
            drop(v387_2);
            let v387_10: Space = if map_kernels::has_head(&(v387_9)) { singleton(&[]) } else { Space::new() };
            drop(v387_9);
            let v387_12: Space = if (&(v387_10)).is_empty() { Space::new() } else {
              let v389_6: Path = concat_path(&(v386_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v389_11: Space = routine_19(c, &(v389_6), &(*p1), &v378_15_cursor);
              drop(v389_6);
              map_map_kernels::compose(&(v387_10),&(v389_11))
            };
            drop(v387_10);
            let v387_13: Space = map_map_kernels::unite(&(v387_8),&(v387_12));
            join_wrapped_into(&mut v386_11_write,&((v387_13).read_zipper()),&[]);
            }
            v378_15_cursor.ascend(1);
          }
          drop(v386_11_write);
          drop(v386_6);
          map_map_kernels::compose(&(v381_10),&(v386_11))
        };
        drop(v381_10);
        let v381_13: Space = map_map_kernels::unite(&(v381_8),&(v381_12));
        join_wrapped_into(&mut v380_7_write,&((v381_13).read_zipper()),&[]);
        }
        v378_15_cursor.ascend(1);
      }
      drop(v380_7_write);
      map_map_kernels::compose(&(v379_5),&(v380_7))
    };
    drop(v379_5);
    let v379_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v379_2));
    drop(v379_2);
    let v379_10: Space = if map_kernels::has_head(&(v379_9)) { singleton(&[]) } else { Space::new() };
    drop(v379_9);
    let v379_11: Space = map_view_kernels::compose(&(v379_10),&v378_15_cursor);
    drop(v379_10);
    let v390_6: Path = concat_path(&(*p0),&v378_15_cursor.path()[v378_15_origin..(v378_15_origin + 1)]);
    let v379_12: Space = map_kernels::wrap(&(v379_11),&(v390_6));
    drop(v379_11);
    let v379_13: Space = map_kernels::wrap(&(v379_12),&(*p1));
    drop(v379_12);
    let v379_14: Space = map_map_kernels::unite(&(v379_8),&(v379_13));
    drop(v379_13);
    join_wrapped_into(&mut v378_15_write,&((v379_14).read_zipper()),&[]);
    }
    v378_15_cursor.ascend(1);
  }
  drop(v378_15_cursor);
  drop(v378_15_write);
  (v378_15).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v391_3: Space = view_kernels::wrap(&(*s0),&(*p0));
  let v391_4: Space = map_kernels::wrap(&(v391_3),&(*p1));
  drop(v391_3);
  (v391_4).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v392_24 = Space::new();
  let mut v392_24_write = v392_24.write_zipper();
  let mut v392_24_cursor = (*s0).read_zipper();
  let v392_24_origin = v392_24_cursor.path().len();
  for v392_24_byte in v392_24_cursor.child_mask().iter() {
    v392_24_cursor.descend_to_existing_byte(v392_24_byte);
    {
    let v393_2: Space = singleton(&v392_24_cursor.path()[v392_24_origin..(v392_24_origin + 1)]);
    let v393_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v393_2));
    let v393_4: Space = if map_kernels::has_head(&(v393_3)) { singleton(&[]) } else { Space::new() };
    drop(v393_3);
    let v393_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v393_4));
    drop(v393_4);
    let v393_8: Space = if (&(v393_5)).is_empty() { Space::new() } else {
      let v394_6: Path = concat_path(&(*p0),&v392_24_cursor.path()[v392_24_origin..(v392_24_origin + 1)]);
      let mut v394_7 = Space::new();
      let mut v394_7_write = v394_7.write_zipper();
      for v394_7_byte in v392_24_cursor.child_mask().iter() {
        v392_24_cursor.descend_to_existing_byte(v394_7_byte);
        {
        let v395_2: Space = singleton(&v392_24_cursor.path()[(v392_24_origin + 1)..(v392_24_origin + 2)]);
        let v395_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v395_2));
        let v395_4: Space = if map_kernels::has_head(&(v395_3)) { singleton(&[]) } else { Space::new() };
        drop(v395_3);
        let v395_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v395_4));
        drop(v395_4);
        let v395_8: Space = if (&(v395_5)).is_empty() { Space::new() } else {
          let v396_6: Path = concat_path(&(v394_6),&v392_24_cursor.path()[(v392_24_origin + 1)..(v392_24_origin + 2)]);
          let mut v396_7 = Space::new();
          let mut v396_7_write = v396_7.write_zipper();
          for v396_7_byte in v392_24_cursor.child_mask().iter() {
            v392_24_cursor.descend_to_existing_byte(v396_7_byte);
            {
            let v397_2: Space = singleton(&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
            let v397_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v397_2));
            let v397_4: Space = if map_kernels::has_head(&(v397_3)) { singleton(&[]) } else { Space::new() };
            drop(v397_3);
            let v397_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v397_4));
            drop(v397_4);
            let v397_8: Space = if (&(v397_5)).is_empty() { Space::new() } else {
              let v398_6: Path = concat_path(&(v396_6),&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
              let v398_7: Space = routine_34(c, &(v398_6), &v392_24_cursor, &(*s1));
              map_map_kernels::compose(&(v397_5),&(v398_7))
            };
            drop(v397_5);
            let v397_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v397_2));
            drop(v397_2);
            let v397_10: Space = if map_kernels::has_head(&(v397_9)) { singleton(&[]) } else { Space::new() };
            drop(v397_9);
            let v397_12: Space = if (&(v397_10)).is_empty() { Space::new() } else {
              let v399_6: Path = concat_path(&(v396_6),&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
              let v399_11: Space = routine_35(c, &(v399_6), &v392_24_cursor, &(*s1));
              drop(v399_6);
              map_map_kernels::compose(&(v397_10),&(v399_11))
            };
            drop(v397_10);
            let v397_13: Space = map_map_kernels::unite(&(v397_8),&(v397_12));
            join_wrapped_into(&mut v396_7_write,&((v397_13).read_zipper()),&[]);
            }
            v392_24_cursor.ascend(1);
          }
          drop(v396_7_write);
          map_map_kernels::compose(&(v395_5),&(v396_7))
        };
        drop(v395_5);
        let v395_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v395_2));
        drop(v395_2);
        let v395_10: Space = if map_kernels::has_head(&(v395_9)) { singleton(&[]) } else { Space::new() };
        drop(v395_9);
        let v395_12: Space = if (&(v395_10)).is_empty() { Space::new() } else {
          let v400_6: Path = concat_path(&(v394_6),&v392_24_cursor.path()[(v392_24_origin + 1)..(v392_24_origin + 2)]);
          let mut v400_11 = Space::new();
          let mut v400_11_write = v400_11.write_zipper();
          for v400_11_byte in v392_24_cursor.child_mask().iter() {
            v392_24_cursor.descend_to_existing_byte(v400_11_byte);
            {
            let v401_2: Space = singleton(&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
            let v401_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v401_2));
            let v401_4: Space = if map_kernels::has_head(&(v401_3)) { singleton(&[]) } else { Space::new() };
            drop(v401_3);
            let v401_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v401_4));
            drop(v401_4);
            let v401_8: Space = if (&(v401_5)).is_empty() { Space::new() } else {
              let v402_6: Path = concat_path(&(v400_6),&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
              let v402_7: Space = routine_34(c, &(v402_6), &v392_24_cursor, &(*s1));
              map_map_kernels::compose(&(v401_5),&(v402_7))
            };
            drop(v401_5);
            let v401_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v401_2));
            drop(v401_2);
            let v401_10: Space = if map_kernels::has_head(&(v401_9)) { singleton(&[]) } else { Space::new() };
            drop(v401_9);
            let v401_12: Space = if (&(v401_10)).is_empty() { Space::new() } else {
              let v403_6: Path = concat_path(&(v400_6),&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
              let v403_11: Space = routine_3(c, &(v403_6), &v392_24_cursor, &(*s1));
              drop(v403_6);
              map_map_kernels::compose(&(v401_10),&(v403_11))
            };
            drop(v401_10);
            let v401_13: Space = map_map_kernels::unite(&(v401_8),&(v401_12));
            join_wrapped_into(&mut v400_11_write,&((v401_13).read_zipper()),&[]);
            }
            v392_24_cursor.ascend(1);
          }
          drop(v400_11_write);
          drop(v400_6);
          map_map_kernels::compose(&(v395_10),&(v400_11))
        };
        drop(v395_10);
        let v395_13: Space = map_map_kernels::unite(&(v395_8),&(v395_12));
        join_wrapped_into(&mut v394_7_write,&((v395_13).read_zipper()),&[]);
        }
        v392_24_cursor.ascend(1);
      }
      drop(v394_7_write);
      map_map_kernels::compose(&(v393_5),&(v394_7))
    };
    drop(v393_5);
    let v393_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v393_2));
    drop(v393_2);
    let v393_10: Space = if map_kernels::has_head(&(v393_9)) { singleton(&[]) } else { Space::new() };
    drop(v393_9);
    let v393_12: Space = if (&(v393_10)).is_empty() { Space::new() } else {
      let v404_6: Path = concat_path(&(*p0),&v392_24_cursor.path()[v392_24_origin..(v392_24_origin + 1)]);
      let mut v404_11 = Space::new();
      let mut v404_11_write = v404_11.write_zipper();
      for v404_11_byte in v392_24_cursor.child_mask().iter() {
        v392_24_cursor.descend_to_existing_byte(v404_11_byte);
        {
        let v405_2: Space = singleton(&v392_24_cursor.path()[(v392_24_origin + 1)..(v392_24_origin + 2)]);
        let v405_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v405_2));
        let v405_4: Space = if map_kernels::has_head(&(v405_3)) { singleton(&[]) } else { Space::new() };
        drop(v405_3);
        let v405_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v405_4));
        drop(v405_4);
        let v405_8: Space = if (&(v405_5)).is_empty() { Space::new() } else {
          let v406_6: Path = concat_path(&(v404_6),&v392_24_cursor.path()[(v392_24_origin + 1)..(v392_24_origin + 2)]);
          let mut v406_7 = Space::new();
          let mut v406_7_write = v406_7.write_zipper();
          for v406_7_byte in v392_24_cursor.child_mask().iter() {
            v392_24_cursor.descend_to_existing_byte(v406_7_byte);
            {
            let v407_2: Space = singleton(&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
            let v407_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v407_2));
            let v407_4: Space = if map_kernels::has_head(&(v407_3)) { singleton(&[]) } else { Space::new() };
            drop(v407_3);
            let v407_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v407_4));
            drop(v407_4);
            let v407_8: Space = if (&(v407_5)).is_empty() { Space::new() } else {
              let v408_6: Path = concat_path(&(v406_6),&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
              let v408_7: Space = routine_34(c, &(v408_6), &v392_24_cursor, &(*s1));
              map_map_kernels::compose(&(v407_5),&(v408_7))
            };
            drop(v407_5);
            let v407_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v407_2));
            drop(v407_2);
            let v407_10: Space = if map_kernels::has_head(&(v407_9)) { singleton(&[]) } else { Space::new() };
            drop(v407_9);
            let v407_12: Space = if (&(v407_10)).is_empty() { Space::new() } else {
              let v409_6: Path = concat_path(&(v406_6),&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
              let v409_11: Space = routine_35(c, &(v409_6), &v392_24_cursor, &(*s1));
              drop(v409_6);
              map_map_kernels::compose(&(v407_10),&(v409_11))
            };
            drop(v407_10);
            let v407_13: Space = map_map_kernels::unite(&(v407_8),&(v407_12));
            join_wrapped_into(&mut v406_7_write,&((v407_13).read_zipper()),&[]);
            }
            v392_24_cursor.ascend(1);
          }
          drop(v406_7_write);
          map_map_kernels::compose(&(v405_5),&(v406_7))
        };
        drop(v405_5);
        let v405_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v405_2));
        drop(v405_2);
        let v405_10: Space = if map_kernels::has_head(&(v405_9)) { singleton(&[]) } else { Space::new() };
        drop(v405_9);
        let v405_12: Space = if (&(v405_10)).is_empty() { Space::new() } else {
          let v410_6: Path = concat_path(&(v404_6),&v392_24_cursor.path()[(v392_24_origin + 1)..(v392_24_origin + 2)]);
          let mut v410_11 = Space::new();
          let mut v410_11_write = v410_11.write_zipper();
          for v410_11_byte in v392_24_cursor.child_mask().iter() {
            v392_24_cursor.descend_to_existing_byte(v410_11_byte);
            {
            let v411_2: Space = singleton(&v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)]);
            let v411_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v411_2));
            let v411_4: Space = if map_kernels::has_head(&(v411_3)) { singleton(&[]) } else { Space::new() };
            drop(v411_3);
            let v411_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v411_4));
            drop(v411_4);
            let v411_7: Space = if (&(v411_5)).is_empty() { Space::new() } else {
              let v412_6: Space = routine_4(c, &v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)], &(v410_6), &v392_24_cursor, &(*s1));
              map_map_kernels::compose(&(v411_5),&(v412_6))
            };
            drop(v411_5);
            let v411_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v411_2));
            drop(v411_2);
            let v411_9: Space = if map_kernels::has_head(&(v411_8)) { singleton(&[]) } else { Space::new() };
            drop(v411_8);
            let v411_11: Space = if (&(v411_9)).is_empty() { Space::new() } else {
              let v413_10: Space = routine_5(c, &v392_24_cursor.path()[(v392_24_origin + 2)..(v392_24_origin + 3)], &(v410_6), &v392_24_cursor, &(*s1));
              map_map_kernels::compose(&(v411_9),&(v413_10))
            };
            drop(v411_9);
            let v411_12: Space = map_map_kernels::unite(&(v411_7),&(v411_11));
            join_wrapped_into(&mut v410_11_write,&((v411_12).read_zipper()),&[]);
            }
            v392_24_cursor.ascend(1);
          }
          drop(v410_11_write);
          drop(v410_6);
          map_map_kernels::compose(&(v405_10),&(v410_11))
        };
        drop(v405_10);
        let v405_13: Space = map_map_kernels::unite(&(v405_8),&(v405_12));
        join_wrapped_into(&mut v404_11_write,&((v405_13).read_zipper()),&[]);
        }
        v392_24_cursor.ascend(1);
      }
      drop(v404_11_write);
      drop(v404_6);
      map_map_kernels::compose(&(v393_10),&(v404_11))
    };
    drop(v393_10);
    let v393_13: Space = map_map_kernels::unite(&(v393_8),&(v393_12));
    join_wrapped_into(&mut v392_24_write,&((v393_13).read_zipper()),&[]);
    }
    v392_24_cursor.ascend(1);
  }
  drop(v392_24_cursor);
  drop(v392_24_write);
  (v392_24).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v414_24 = Space::new();
  let mut v414_24_write = v414_24.write_zipper();
  let mut v414_24_cursor = (*s0).read_zipper();
  let v414_24_origin = v414_24_cursor.path().len();
  for v414_24_byte in v414_24_cursor.child_mask().iter() {
    v414_24_cursor.descend_to_existing_byte(v414_24_byte);
    {
    let v415_2: Space = singleton(&v414_24_cursor.path()[v414_24_origin..(v414_24_origin + 1)]);
    let v415_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v415_2));
    let v415_4: Space = if map_kernels::has_head(&(v415_3)) { singleton(&[]) } else { Space::new() };
    drop(v415_3);
    let v415_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v415_4));
    drop(v415_4);
    let v415_8: Space = if (&(v415_5)).is_empty() { Space::new() } else {
      let v416_6: Path = concat_path(&(*p0),&v414_24_cursor.path()[v414_24_origin..(v414_24_origin + 1)]);
      let mut v416_7 = Space::new();
      let mut v416_7_write = v416_7.write_zipper();
      for v416_7_byte in v414_24_cursor.child_mask().iter() {
        v414_24_cursor.descend_to_existing_byte(v416_7_byte);
        {
        let v417_2: Space = singleton(&v414_24_cursor.path()[(v414_24_origin + 1)..(v414_24_origin + 2)]);
        let v417_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v417_2));
        let v417_4: Space = if map_kernels::has_head(&(v417_3)) { singleton(&[]) } else { Space::new() };
        drop(v417_3);
        let v417_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v417_4));
        drop(v417_4);
        let v417_8: Space = if (&(v417_5)).is_empty() { Space::new() } else {
          let v418_6: Path = concat_path(&(v416_6),&v414_24_cursor.path()[(v414_24_origin + 1)..(v414_24_origin + 2)]);
          let mut v418_7 = Space::new();
          let mut v418_7_write = v418_7.write_zipper();
          for v418_7_byte in v414_24_cursor.child_mask().iter() {
            v414_24_cursor.descend_to_existing_byte(v418_7_byte);
            {
            let v419_2: Space = singleton(&v414_24_cursor.path()[(v414_24_origin + 2)..(v414_24_origin + 3)]);
            let v419_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v419_2));
            let v419_4: Space = if map_kernels::has_head(&(v419_3)) { singleton(&[]) } else { Space::new() };
            drop(v419_3);
            let v419_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v419_4));
            drop(v419_4);
            let v419_8: Space = if (&(v419_5)).is_empty() { Space::new() } else {
              let v420_6: Path = concat_path(&(v418_6),&v414_24_cursor.path()[(v414_24_origin + 2)..(v414_24_origin + 3)]);
              let v420_7: Space = routine_34(c, &(v420_6), &v414_24_cursor, &(*s1));
              map_map_kernels::compose(&(v419_5),&(v420_7))
            };
            drop(v419_5);
            let v419_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v419_2));
            drop(v419_2);
            let v419_10: Space = if map_kernels::has_head(&(v419_9)) { singleton(&[]) } else { Space::new() };
            drop(v419_9);
            let v419_12: Space = if (&(v419_10)).is_empty() { Space::new() } else {
              let v421_6: Path = concat_path(&(v418_6),&v414_24_cursor.path()[(v414_24_origin + 2)..(v414_24_origin + 3)]);
              let v421_11: Space = routine_35(c, &(v421_6), &v414_24_cursor, &(*s1));
              drop(v421_6);
              map_map_kernels::compose(&(v419_10),&(v421_11))
            };
            drop(v419_10);
            let v419_13: Space = map_map_kernels::unite(&(v419_8),&(v419_12));
            join_wrapped_into(&mut v418_7_write,&((v419_13).read_zipper()),&[]);
            }
            v414_24_cursor.ascend(1);
          }
          drop(v418_7_write);
          map_map_kernels::compose(&(v417_5),&(v418_7))
        };
        drop(v417_5);
        let v417_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v417_2));
        drop(v417_2);
        let v417_10: Space = if map_kernels::has_head(&(v417_9)) { singleton(&[]) } else { Space::new() };
        drop(v417_9);
        let v417_12: Space = if (&(v417_10)).is_empty() { Space::new() } else {
          let v422_6: Path = concat_path(&(v416_6),&v414_24_cursor.path()[(v414_24_origin + 1)..(v414_24_origin + 2)]);
          let mut v422_11 = Space::new();
          let mut v422_11_write = v422_11.write_zipper();
          for v422_11_byte in v414_24_cursor.child_mask().iter() {
            v414_24_cursor.descend_to_existing_byte(v422_11_byte);
            {
            let v423_2: Space = singleton(&v414_24_cursor.path()[(v414_24_origin + 2)..(v414_24_origin + 3)]);
            let v423_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v423_2));
            let v423_4: Space = if map_kernels::has_head(&(v423_3)) { singleton(&[]) } else { Space::new() };
            drop(v423_3);
            let v423_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v423_4));
            drop(v423_4);
            let v423_8: Space = if (&(v423_5)).is_empty() { Space::new() } else {
              let v424_6: Path = concat_path(&(v422_6),&v414_24_cursor.path()[(v414_24_origin + 2)..(v414_24_origin + 3)]);
              let v424_7: Space = routine_34(c, &(v424_6), &v414_24_cursor, &(*s1));
              map_map_kernels::compose(&(v423_5),&(v424_7))
            };
            drop(v423_5);
            let v423_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v423_2));
            drop(v423_2);
            let v423_10: Space = if map_kernels::has_head(&(v423_9)) { singleton(&[]) } else { Space::new() };
            drop(v423_9);
            let v423_12: Space = if (&(v423_10)).is_empty() { Space::new() } else {
              let v425_6: Path = concat_path(&(v422_6),&v414_24_cursor.path()[(v414_24_origin + 2)..(v414_24_origin + 3)]);
              let v425_11: Space = routine_3(c, &(v425_6), &v414_24_cursor, &(*s1));
              drop(v425_6);
              map_map_kernels::compose(&(v423_10),&(v425_11))
            };
            drop(v423_10);
            let v423_13: Space = map_map_kernels::unite(&(v423_8),&(v423_12));
            join_wrapped_into(&mut v422_11_write,&((v423_13).read_zipper()),&[]);
            }
            v414_24_cursor.ascend(1);
          }
          drop(v422_11_write);
          drop(v422_6);
          map_map_kernels::compose(&(v417_10),&(v422_11))
        };
        drop(v417_10);
        let v417_13: Space = map_map_kernels::unite(&(v417_8),&(v417_12));
        join_wrapped_into(&mut v416_7_write,&((v417_13).read_zipper()),&[]);
        }
        v414_24_cursor.ascend(1);
      }
      drop(v416_7_write);
      map_map_kernels::compose(&(v415_5),&(v416_7))
    };
    drop(v415_5);
    let v415_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v415_2));
    drop(v415_2);
    let v415_10: Space = if map_kernels::has_head(&(v415_9)) { singleton(&[]) } else { Space::new() };
    drop(v415_9);
    let v415_12: Space = if (&(v415_10)).is_empty() { Space::new() } else {
      let v426_6: Path = concat_path(&(*p0),&v414_24_cursor.path()[v414_24_origin..(v414_24_origin + 1)]);
      let mut v426_11 = Space::new();
      let mut v426_11_write = v426_11.write_zipper();
      for v426_11_byte in v414_24_cursor.child_mask().iter() {
        v414_24_cursor.descend_to_existing_byte(v426_11_byte);
        {
        let v427_2: Space = singleton(&v414_24_cursor.path()[(v414_24_origin + 1)..(v414_24_origin + 2)]);
        let v427_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v427_2));
        let v427_4: Space = if map_kernels::has_head(&(v427_3)) { singleton(&[]) } else { Space::new() };
        drop(v427_3);
        let v427_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v427_4));
        drop(v427_4);
        let v427_7: Space = if (&(v427_5)).is_empty() { Space::new() } else {
          let mut v428_6 = Space::new();
          let mut v428_6_write = v428_6.write_zipper();
          for v428_6_byte in v414_24_cursor.child_mask().iter() {
            v414_24_cursor.descend_to_existing_byte(v428_6_byte);
            {
            let v429_2: Space = singleton(&v414_24_cursor.path()[(v414_24_origin + 2)..(v414_24_origin + 3)]);
            let v429_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v429_2));
            let v429_4: Space = if map_kernels::has_head(&(v429_3)) { singleton(&[]) } else { Space::new() };
            drop(v429_3);
            let v429_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v429_4));
            drop(v429_4);
            let v429_8: Space = if (&(v429_5)).is_empty() { Space::new() } else {
              let v430_7: Space = routine_8(c, &v414_24_cursor.path()[(v414_24_origin + 1)..(v414_24_origin + 3)], &(v426_6), &v414_24_cursor, &(*s1));
              map_map_kernels::compose(&(v429_5),&(v430_7))
            };
            drop(v429_5);
            let v429_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v429_2));
            drop(v429_2);
            let v429_10: Space = if map_kernels::has_head(&(v429_9)) { singleton(&[]) } else { Space::new() };
            drop(v429_9);
            let v429_12: Space = if (&(v429_10)).is_empty() { Space::new() } else {
              let v431_11: Space = routine_9(c, &v414_24_cursor.path()[(v414_24_origin + 1)..(v414_24_origin + 3)], &(v426_6), &v414_24_cursor, &(*s1));
              map_map_kernels::compose(&(v429_10),&(v431_11))
            };
            drop(v429_10);
            let v429_13: Space = map_map_kernels::unite(&(v429_8),&(v429_12));
            join_wrapped_into(&mut v428_6_write,&((v429_13).read_zipper()),&[]);
            }
            v414_24_cursor.ascend(1);
          }
          drop(v428_6_write);
          map_map_kernels::compose(&(v427_5),&(v428_6))
        };
        drop(v427_5);
        let v427_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v427_2));
        drop(v427_2);
        let v427_9: Space = if map_kernels::has_head(&(v427_8)) { singleton(&[]) } else { Space::new() };
        drop(v427_8);
        let v427_11: Space = if (&(v427_9)).is_empty() { Space::new() } else {
          let mut v432_10 = Space::new();
          let mut v432_10_write = v432_10.write_zipper();
          for v432_10_byte in v414_24_cursor.child_mask().iter() {
            v414_24_cursor.descend_to_existing_byte(v432_10_byte);
            {
            let v433_2: Space = singleton(&v414_24_cursor.path()[(v414_24_origin + 2)..(v414_24_origin + 3)]);
            let v433_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v433_2));
            let v433_4: Space = if map_kernels::has_head(&(v433_3)) { singleton(&[]) } else { Space::new() };
            drop(v433_3);
            let v433_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v433_4));
            drop(v433_4);
            let v433_8: Space = if (&(v433_5)).is_empty() { Space::new() } else {
              let v434_7: Space = routine_8(c, &v414_24_cursor.path()[(v414_24_origin + 1)..(v414_24_origin + 3)], &(v426_6), &v414_24_cursor, &(*s1));
              map_map_kernels::compose(&(v433_5),&(v434_7))
            };
            drop(v433_5);
            let v433_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v433_2));
            drop(v433_2);
            let v433_10: Space = if map_kernels::has_head(&(v433_9)) { singleton(&[]) } else { Space::new() };
            drop(v433_9);
            let v433_12: Space = if (&(v433_10)).is_empty() { Space::new() } else {
              let v435_11: Space = routine_10(c, &v414_24_cursor.path()[(v414_24_origin + 1)..(v414_24_origin + 3)], &(v426_6), &v414_24_cursor, &(*s1));
              map_map_kernels::compose(&(v433_10),&(v435_11))
            };
            drop(v433_10);
            let v433_13: Space = map_map_kernels::unite(&(v433_8),&(v433_12));
            join_wrapped_into(&mut v432_10_write,&((v433_13).read_zipper()),&[]);
            }
            v414_24_cursor.ascend(1);
          }
          drop(v432_10_write);
          map_map_kernels::compose(&(v427_9),&(v432_10))
        };
        drop(v427_9);
        let v427_12: Space = map_map_kernels::unite(&(v427_7),&(v427_11));
        join_wrapped_into(&mut v426_11_write,&((v427_12).read_zipper()),&[]);
        }
        v414_24_cursor.ascend(1);
      }
      drop(v426_11_write);
      drop(v426_6);
      map_map_kernels::compose(&(v415_10),&(v426_11))
    };
    drop(v415_10);
    let v415_13: Space = map_map_kernels::unite(&(v415_8),&(v415_12));
    join_wrapped_into(&mut v414_24_write,&((v415_13).read_zipper()),&[]);
    }
    v414_24_cursor.ascend(1);
  }
  drop(v414_24_cursor);
  drop(v414_24_write);
  (v414_24).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v436_28 = Space::new();
  let mut v436_28_write = v436_28.write_zipper();
  let mut v436_28_cursor = (*s0).read_zipper();
  let v436_28_origin = v436_28_cursor.path().len();
  for v436_28_byte in v436_28_cursor.child_mask().iter() {
    v436_28_cursor.descend_to_existing_byte(v436_28_byte);
    {
    let v437_2: Space = singleton(&v436_28_cursor.path()[v436_28_origin..(v436_28_origin + 1)]);
    let v437_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v437_2));
    let v437_4: Space = if map_kernels::has_head(&(v437_3)) { singleton(&[]) } else { Space::new() };
    drop(v437_3);
    let v437_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v437_4));
    drop(v437_4);
    let v437_8: Space = if (&(v437_5)).is_empty() { Space::new() } else {
      let v438_6: Path = concat_path(&(*p0),&v436_28_cursor.path()[v436_28_origin..(v436_28_origin + 1)]);
      let mut v438_7 = Space::new();
      let mut v438_7_write = v438_7.write_zipper();
      for v438_7_byte in v436_28_cursor.child_mask().iter() {
        v436_28_cursor.descend_to_existing_byte(v438_7_byte);
        {
        let v439_2: Space = singleton(&v436_28_cursor.path()[(v436_28_origin + 1)..(v436_28_origin + 2)]);
        let v439_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v439_2));
        let v439_4: Space = if map_kernels::has_head(&(v439_3)) { singleton(&[]) } else { Space::new() };
        drop(v439_3);
        let v439_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v439_4));
        drop(v439_4);
        let v439_8: Space = if (&(v439_5)).is_empty() { Space::new() } else {
          let v440_6: Path = concat_path(&(v438_6),&v436_28_cursor.path()[(v436_28_origin + 1)..(v436_28_origin + 2)]);
          let mut v440_7 = Space::new();
          let mut v440_7_write = v440_7.write_zipper();
          for v440_7_byte in v436_28_cursor.child_mask().iter() {
            v436_28_cursor.descend_to_existing_byte(v440_7_byte);
            {
            let v441_2: Space = singleton(&v436_28_cursor.path()[(v436_28_origin + 2)..(v436_28_origin + 3)]);
            let v441_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v441_2));
            let v441_4: Space = if map_kernels::has_head(&(v441_3)) { singleton(&[]) } else { Space::new() };
            drop(v441_3);
            let v441_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v441_4));
            drop(v441_4);
            let v441_8: Space = if (&(v441_5)).is_empty() { Space::new() } else {
              let v442_6: Path = concat_path(&(v440_6),&v436_28_cursor.path()[(v436_28_origin + 2)..(v436_28_origin + 3)]);
              let v442_7: Space = routine_36(c, &(v442_6), &(*p1), &v436_28_cursor, &(*s1));
              map_map_kernels::compose(&(v441_5),&(v442_7))
            };
            drop(v441_5);
            let v441_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v441_2));
            drop(v441_2);
            let v441_10: Space = if map_kernels::has_head(&(v441_9)) { singleton(&[]) } else { Space::new() };
            drop(v441_9);
            let v441_12: Space = if (&(v441_10)).is_empty() { Space::new() } else {
              let v443_6: Path = concat_path(&(v440_6),&v436_28_cursor.path()[(v436_28_origin + 2)..(v436_28_origin + 3)]);
              let v443_11: Space = routine_37(c, &(v443_6), &(*p1), &v436_28_cursor, &(*s1));
              drop(v443_6);
              map_map_kernels::compose(&(v441_10),&(v443_11))
            };
            drop(v441_10);
            let v441_13: Space = map_map_kernels::unite(&(v441_8),&(v441_12));
            join_wrapped_into(&mut v440_7_write,&((v441_13).read_zipper()),&[]);
            }
            v436_28_cursor.ascend(1);
          }
          drop(v440_7_write);
          map_map_kernels::compose(&(v439_5),&(v440_7))
        };
        drop(v439_5);
        let v439_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v439_2));
        drop(v439_2);
        let v439_10: Space = if map_kernels::has_head(&(v439_9)) { singleton(&[]) } else { Space::new() };
        drop(v439_9);
        let v439_12: Space = if (&(v439_10)).is_empty() { Space::new() } else {
          let v444_6: Path = concat_path(&(v438_6),&v436_28_cursor.path()[(v436_28_origin + 1)..(v436_28_origin + 2)]);
          let mut v444_11 = Space::new();
          let mut v444_11_write = v444_11.write_zipper();
          for v444_11_byte in v436_28_cursor.child_mask().iter() {
            v436_28_cursor.descend_to_existing_byte(v444_11_byte);
            {
            let v445_2: Space = singleton(&v436_28_cursor.path()[(v436_28_origin + 2)..(v436_28_origin + 3)]);
            let v445_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v445_2));
            let v445_4: Space = if map_kernels::has_head(&(v445_3)) { singleton(&[]) } else { Space::new() };
            drop(v445_3);
            let v445_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v445_4));
            drop(v445_4);
            let v445_8: Space = if (&(v445_5)).is_empty() { Space::new() } else {
              let v446_6: Path = concat_path(&(v444_6),&v436_28_cursor.path()[(v436_28_origin + 2)..(v436_28_origin + 3)]);
              let v446_7: Space = routine_36(c, &(v446_6), &(*p1), &v436_28_cursor, &(*s1));
              map_map_kernels::compose(&(v445_5),&(v446_7))
            };
            drop(v445_5);
            let v445_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v445_2));
            drop(v445_2);
            let v445_10: Space = if map_kernels::has_head(&(v445_9)) { singleton(&[]) } else { Space::new() };
            drop(v445_9);
            let v445_12: Space = if (&(v445_10)).is_empty() { Space::new() } else {
              let v447_6: Path = concat_path(&(v444_6),&v436_28_cursor.path()[(v436_28_origin + 2)..(v436_28_origin + 3)]);
              let v447_11: Space = routine_10(c, &(v447_6), &(*p1), &v436_28_cursor, &(*s1));
              drop(v447_6);
              map_map_kernels::compose(&(v445_10),&(v447_11))
            };
            drop(v445_10);
            let v445_13: Space = map_map_kernels::unite(&(v445_8),&(v445_12));
            join_wrapped_into(&mut v444_11_write,&((v445_13).read_zipper()),&[]);
            }
            v436_28_cursor.ascend(1);
          }
          drop(v444_11_write);
          drop(v444_6);
          map_map_kernels::compose(&(v439_10),&(v444_11))
        };
        drop(v439_10);
        let v439_13: Space = map_map_kernels::unite(&(v439_8),&(v439_12));
        join_wrapped_into(&mut v438_7_write,&((v439_13).read_zipper()),&[]);
        }
        v436_28_cursor.ascend(1);
      }
      drop(v438_7_write);
      map_map_kernels::compose(&(v437_5),&(v438_7))
    };
    drop(v437_5);
    let v437_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v437_2));
    drop(v437_2);
    let v437_10: Space = if map_kernels::has_head(&(v437_9)) { singleton(&[]) } else { Space::new() };
    drop(v437_9);
    let v437_13: Space = if (&(v437_10)).is_empty() { Space::new() } else {
      let v448_6: Path = concat_path(&(*p0),&v436_28_cursor.path()[v436_28_origin..(v436_28_origin + 1)]);
      let mut v448_12 = Space::new();
      let mut v448_12_write = v448_12.write_zipper();
      for v448_12_byte in v436_28_cursor.child_mask().iter() {
        v436_28_cursor.descend_to_existing_byte(v448_12_byte);
        {
        let v449_2: Space = singleton(&v436_28_cursor.path()[(v436_28_origin + 1)..(v436_28_origin + 2)]);
        let v449_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v449_2));
        let v449_4: Space = if map_kernels::has_head(&(v449_3)) { singleton(&[]) } else { Space::new() };
        drop(v449_3);
        let v449_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v449_4));
        drop(v449_4);
        let v449_8: Space = if (&(v449_5)).is_empty() { Space::new() } else {
          let v450_6: Path = concat_path(&(v448_6),&v436_28_cursor.path()[(v436_28_origin + 1)..(v436_28_origin + 2)]);
          let mut v450_7 = Space::new();
          let mut v450_7_write = v450_7.write_zipper();
          for v450_7_byte in v436_28_cursor.child_mask().iter() {
            v436_28_cursor.descend_to_existing_byte(v450_7_byte);
            {
            let v451_2: Space = singleton(&v436_28_cursor.path()[(v436_28_origin + 2)..(v436_28_origin + 3)]);
            let v451_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v451_2));
            let v451_4: Space = if map_kernels::has_head(&(v451_3)) { singleton(&[]) } else { Space::new() };
            drop(v451_3);
            let v451_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v451_4));
            drop(v451_4);
            let v451_8: Space = if (&(v451_5)).is_empty() { Space::new() } else {
              let v452_6: Path = concat_path(&(v450_6),&v436_28_cursor.path()[(v436_28_origin + 2)..(v436_28_origin + 3)]);
              let v452_7: Space = routine_36(c, &(v452_6), &(*p1), &v436_28_cursor, &(*s1));
              map_map_kernels::compose(&(v451_5),&(v452_7))
            };
            drop(v451_5);
            let v451_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v451_2));
            drop(v451_2);
            let v451_10: Space = if map_kernels::has_head(&(v451_9)) { singleton(&[]) } else { Space::new() };
            drop(v451_9);
            let v451_12: Space = if (&(v451_10)).is_empty() { Space::new() } else {
              let v453_6: Path = concat_path(&(v450_6),&v436_28_cursor.path()[(v436_28_origin + 2)..(v436_28_origin + 3)]);
              let v453_11: Space = routine_37(c, &(v453_6), &(*p1), &v436_28_cursor, &(*s1));
              drop(v453_6);
              map_map_kernels::compose(&(v451_10),&(v453_11))
            };
            drop(v451_10);
            let v451_13: Space = map_map_kernels::unite(&(v451_8),&(v451_12));
            join_wrapped_into(&mut v450_7_write,&((v451_13).read_zipper()),&[]);
            }
            v436_28_cursor.ascend(1);
          }
          drop(v450_7_write);
          drop(v450_6);
          map_map_kernels::compose(&(v449_5),&(v450_7))
        };
        drop(v449_5);
        let v449_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v449_2));
        drop(v449_2);
        let v449_10: Space = if map_kernels::has_head(&(v449_9)) { singleton(&[]) } else { Space::new() };
        drop(v449_9);
        let v449_13: Space = if (&(v449_10)).is_empty() { Space::new() } else {
          let mut v454_12 = Space::new();
          let mut v454_12_write = v454_12.write_zipper();
          let mut v454_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v436_28_cursor.path()[v436_28_origin..(v436_28_origin + 1)]),&v436_28_cursor.path()[(v436_28_origin + 1)..(v436_28_origin + 2)]);
          let v454_12_origin = v454_12_cursor.path().len();
          for v454_12_byte in v454_12_cursor.child_mask().iter() {
            v454_12_cursor.descend_to_existing_byte(v454_12_byte);
            {
            let v455_2: Space = singleton(&v454_12_cursor.path()[v454_12_origin..(v454_12_origin + 1)]);
            let v455_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v455_2));
            let v455_4: Space = if map_kernels::has_head(&(v455_3)) { singleton(&[]) } else { Space::new() };
            drop(v455_3);
            let v455_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v455_4));
            drop(v455_4);
            let v455_7: Space = if (&(v455_5)).is_empty() { Space::new() } else {
              let v456_6: Space = routine_13(c, &v454_12_cursor.path()[v454_12_origin..(v454_12_origin + 1)], &(*p1), &v454_12_cursor);
              map_map_kernels::compose(&(v455_5),&(v456_6))
            };
            drop(v455_5);
            let v455_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v455_2));
            drop(v455_2);
            let v455_9: Space = if map_kernels::has_head(&(v455_8)) { singleton(&[]) } else { Space::new() };
            drop(v455_8);
            let v455_11: Space = if (&(v455_9)).is_empty() { Space::new() } else {
              let v457_10: Space = routine_14(c, &v454_12_cursor.path()[v454_12_origin..(v454_12_origin + 1)], &(*p1), &v454_12_cursor);
              map_map_kernels::compose(&(v455_9),&(v457_10))
            };
            drop(v455_9);
            let v455_12: Space = map_map_kernels::unite(&(v455_7),&(v455_11));
            join_wrapped_into(&mut v454_12_write,&((v455_12).read_zipper()),&[]);
            }
            v454_12_cursor.ascend(1);
          }
          drop(v454_12_cursor);
          drop(v454_12_write);
          map_map_kernels::compose(&(v449_10),&(v454_12))
        };
        drop(v449_10);
        let v449_14: Space = map_map_kernels::unite(&(v449_8),&(v449_13));
        join_wrapped_into(&mut v448_12_write,&((v449_14).read_zipper()),&[]);
        }
        v436_28_cursor.ascend(1);
      }
      drop(v448_12_write);
      drop(v448_6);
      map_map_kernels::compose(&(v437_10),&(v448_12))
    };
    drop(v437_10);
    let v437_14: Space = map_map_kernels::unite(&(v437_8),&(v437_13));
    join_wrapped_into(&mut v436_28_write,&((v437_14).read_zipper()),&[]);
    }
    v436_28_cursor.ascend(1);
  }
  drop(v436_28_cursor);
  drop(v436_28_write);
  (v436_28).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v458_28 = Space::new();
  let mut v458_28_write = v458_28.write_zipper();
  let mut v458_28_cursor = (*s0).read_zipper();
  let v458_28_origin = v458_28_cursor.path().len();
  for v458_28_byte in v458_28_cursor.child_mask().iter() {
    v458_28_cursor.descend_to_existing_byte(v458_28_byte);
    {
    let v459_2: Space = singleton(&v458_28_cursor.path()[v458_28_origin..(v458_28_origin + 1)]);
    let v459_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v459_2));
    let v459_4: Space = if map_kernels::has_head(&(v459_3)) { singleton(&[]) } else { Space::new() };
    drop(v459_3);
    let v459_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v459_4));
    drop(v459_4);
    let v459_8: Space = if (&(v459_5)).is_empty() { Space::new() } else {
      let v460_6: Path = concat_path(&(*p0),&v458_28_cursor.path()[v458_28_origin..(v458_28_origin + 1)]);
      let mut v460_7 = Space::new();
      let mut v460_7_write = v460_7.write_zipper();
      for v460_7_byte in v458_28_cursor.child_mask().iter() {
        v458_28_cursor.descend_to_existing_byte(v460_7_byte);
        {
        let v461_2: Space = singleton(&v458_28_cursor.path()[(v458_28_origin + 1)..(v458_28_origin + 2)]);
        let v461_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v461_2));
        let v461_4: Space = if map_kernels::has_head(&(v461_3)) { singleton(&[]) } else { Space::new() };
        drop(v461_3);
        let v461_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v461_4));
        drop(v461_4);
        let v461_8: Space = if (&(v461_5)).is_empty() { Space::new() } else {
          let v462_6: Path = concat_path(&(v460_6),&v458_28_cursor.path()[(v458_28_origin + 1)..(v458_28_origin + 2)]);
          let mut v462_7 = Space::new();
          let mut v462_7_write = v462_7.write_zipper();
          for v462_7_byte in v458_28_cursor.child_mask().iter() {
            v458_28_cursor.descend_to_existing_byte(v462_7_byte);
            {
            let v463_2: Space = singleton(&v458_28_cursor.path()[(v458_28_origin + 2)..(v458_28_origin + 3)]);
            let v463_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v463_2));
            let v463_4: Space = if map_kernels::has_head(&(v463_3)) { singleton(&[]) } else { Space::new() };
            drop(v463_3);
            let v463_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v463_4));
            drop(v463_4);
            let v463_8: Space = if (&(v463_5)).is_empty() { Space::new() } else {
              let v464_6: Path = concat_path(&(v462_6),&v458_28_cursor.path()[(v458_28_origin + 2)..(v458_28_origin + 3)]);
              let v464_7: Space = routine_36(c, &(v464_6), &(*p1), &v458_28_cursor, &(*s1));
              map_map_kernels::compose(&(v463_5),&(v464_7))
            };
            drop(v463_5);
            let v463_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v463_2));
            drop(v463_2);
            let v463_10: Space = if map_kernels::has_head(&(v463_9)) { singleton(&[]) } else { Space::new() };
            drop(v463_9);
            let v463_12: Space = if (&(v463_10)).is_empty() { Space::new() } else {
              let v465_6: Path = concat_path(&(v462_6),&v458_28_cursor.path()[(v458_28_origin + 2)..(v458_28_origin + 3)]);
              let v465_11: Space = routine_37(c, &(v465_6), &(*p1), &v458_28_cursor, &(*s1));
              drop(v465_6);
              map_map_kernels::compose(&(v463_10),&(v465_11))
            };
            drop(v463_10);
            let v463_13: Space = map_map_kernels::unite(&(v463_8),&(v463_12));
            join_wrapped_into(&mut v462_7_write,&((v463_13).read_zipper()),&[]);
            }
            v458_28_cursor.ascend(1);
          }
          drop(v462_7_write);
          map_map_kernels::compose(&(v461_5),&(v462_7))
        };
        drop(v461_5);
        let v461_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v461_2));
        drop(v461_2);
        let v461_10: Space = if map_kernels::has_head(&(v461_9)) { singleton(&[]) } else { Space::new() };
        drop(v461_9);
        let v461_12: Space = if (&(v461_10)).is_empty() { Space::new() } else {
          let v466_6: Path = concat_path(&(v460_6),&v458_28_cursor.path()[(v458_28_origin + 1)..(v458_28_origin + 2)]);
          let mut v466_11 = Space::new();
          let mut v466_11_write = v466_11.write_zipper();
          for v466_11_byte in v458_28_cursor.child_mask().iter() {
            v458_28_cursor.descend_to_existing_byte(v466_11_byte);
            {
            let v467_2: Space = singleton(&v458_28_cursor.path()[(v458_28_origin + 2)..(v458_28_origin + 3)]);
            let v467_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v467_2));
            let v467_4: Space = if map_kernels::has_head(&(v467_3)) { singleton(&[]) } else { Space::new() };
            drop(v467_3);
            let v467_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v467_4));
            drop(v467_4);
            let v467_8: Space = if (&(v467_5)).is_empty() { Space::new() } else {
              let v468_6: Path = concat_path(&(v466_6),&v458_28_cursor.path()[(v458_28_origin + 2)..(v458_28_origin + 3)]);
              let v468_7: Space = routine_36(c, &(v468_6), &(*p1), &v458_28_cursor, &(*s1));
              map_map_kernels::compose(&(v467_5),&(v468_7))
            };
            drop(v467_5);
            let v467_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v467_2));
            drop(v467_2);
            let v467_10: Space = if map_kernels::has_head(&(v467_9)) { singleton(&[]) } else { Space::new() };
            drop(v467_9);
            let v467_12: Space = if (&(v467_10)).is_empty() { Space::new() } else {
              let v469_6: Path = concat_path(&(v466_6),&v458_28_cursor.path()[(v458_28_origin + 2)..(v458_28_origin + 3)]);
              let v469_11: Space = routine_10(c, &(v469_6), &(*p1), &v458_28_cursor, &(*s1));
              drop(v469_6);
              map_map_kernels::compose(&(v467_10),&(v469_11))
            };
            drop(v467_10);
            let v467_13: Space = map_map_kernels::unite(&(v467_8),&(v467_12));
            join_wrapped_into(&mut v466_11_write,&((v467_13).read_zipper()),&[]);
            }
            v458_28_cursor.ascend(1);
          }
          drop(v466_11_write);
          drop(v466_6);
          map_map_kernels::compose(&(v461_10),&(v466_11))
        };
        drop(v461_10);
        let v461_13: Space = map_map_kernels::unite(&(v461_8),&(v461_12));
        join_wrapped_into(&mut v460_7_write,&((v461_13).read_zipper()),&[]);
        }
        v458_28_cursor.ascend(1);
      }
      drop(v460_7_write);
      drop(v460_6);
      map_map_kernels::compose(&(v459_5),&(v460_7))
    };
    drop(v459_5);
    let v459_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v459_2));
    drop(v459_2);
    let v459_10: Space = if map_kernels::has_head(&(v459_9)) { singleton(&[]) } else { Space::new() };
    drop(v459_9);
    let v459_13: Space = if (&(v459_10)).is_empty() { Space::new() } else {
      let mut v470_12 = Space::new();
      let mut v470_12_write = v470_12.write_zipper();
      let mut v470_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v458_28_cursor.path()[v458_28_origin..(v458_28_origin + 1)]);
      let v470_12_origin = v470_12_cursor.path().len();
      for v470_12_byte in v470_12_cursor.child_mask().iter() {
        v470_12_cursor.descend_to_existing_byte(v470_12_byte);
        {
        let v471_2: Space = singleton(&v470_12_cursor.path()[v470_12_origin..(v470_12_origin + 1)]);
        let v471_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v471_2));
        let v471_4: Space = if map_kernels::has_head(&(v471_3)) { singleton(&[]) } else { Space::new() };
        drop(v471_3);
        let v471_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v471_4));
        drop(v471_4);
        let v471_7: Space = if (&(v471_5)).is_empty() { Space::new() } else {
          let mut v472_6 = Space::new();
          let mut v472_6_write = v472_6.write_zipper();
          for v472_6_byte in v470_12_cursor.child_mask().iter() {
            v470_12_cursor.descend_to_existing_byte(v472_6_byte);
            {
            let v473_2: Space = singleton(&v470_12_cursor.path()[(v470_12_origin + 1)..(v470_12_origin + 2)]);
            let v473_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v473_2));
            let v473_4: Space = if map_kernels::has_head(&(v473_3)) { singleton(&[]) } else { Space::new() };
            drop(v473_3);
            let v473_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v473_4));
            drop(v473_4);
            let v473_8: Space = if (&(v473_5)).is_empty() { Space::new() } else {
              let v474_7: Space = routine_17(c, &v470_12_cursor.path()[v470_12_origin..(v470_12_origin + 2)], &(*p1), &v470_12_cursor);
              map_map_kernels::compose(&(v473_5),&(v474_7))
            };
            drop(v473_5);
            let v473_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v473_2));
            drop(v473_2);
            let v473_10: Space = if map_kernels::has_head(&(v473_9)) { singleton(&[]) } else { Space::new() };
            drop(v473_9);
            let v473_12: Space = if (&(v473_10)).is_empty() { Space::new() } else {
              let v475_11: Space = routine_18(c, &v470_12_cursor.path()[v470_12_origin..(v470_12_origin + 2)], &(*p1), &v470_12_cursor);
              map_map_kernels::compose(&(v473_10),&(v475_11))
            };
            drop(v473_10);
            let v473_13: Space = map_map_kernels::unite(&(v473_8),&(v473_12));
            join_wrapped_into(&mut v472_6_write,&((v473_13).read_zipper()),&[]);
            }
            v470_12_cursor.ascend(1);
          }
          drop(v472_6_write);
          map_map_kernels::compose(&(v471_5),&(v472_6))
        };
        drop(v471_5);
        let v471_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v471_2));
        drop(v471_2);
        let v471_9: Space = if map_kernels::has_head(&(v471_8)) { singleton(&[]) } else { Space::new() };
        drop(v471_8);
        let v471_11: Space = if (&(v471_9)).is_empty() { Space::new() } else {
          let mut v476_10 = Space::new();
          let mut v476_10_write = v476_10.write_zipper();
          for v476_10_byte in v470_12_cursor.child_mask().iter() {
            v470_12_cursor.descend_to_existing_byte(v476_10_byte);
            {
            let v477_2: Space = singleton(&v470_12_cursor.path()[(v470_12_origin + 1)..(v470_12_origin + 2)]);
            let v477_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v477_2));
            let v477_4: Space = if map_kernels::has_head(&(v477_3)) { singleton(&[]) } else { Space::new() };
            drop(v477_3);
            let v477_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v477_4));
            drop(v477_4);
            let v477_8: Space = if (&(v477_5)).is_empty() { Space::new() } else {
              let v478_7: Space = routine_17(c, &v470_12_cursor.path()[v470_12_origin..(v470_12_origin + 2)], &(*p1), &v470_12_cursor);
              map_map_kernels::compose(&(v477_5),&(v478_7))
            };
            drop(v477_5);
            let v477_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v477_2));
            drop(v477_2);
            let v477_10: Space = if map_kernels::has_head(&(v477_9)) { singleton(&[]) } else { Space::new() };
            drop(v477_9);
            let v477_12: Space = if (&(v477_10)).is_empty() { Space::new() } else {
              let v479_11: Space = routine_19(c, &v470_12_cursor.path()[v470_12_origin..(v470_12_origin + 2)], &(*p1), &v470_12_cursor);
              map_map_kernels::compose(&(v477_10),&(v479_11))
            };
            drop(v477_10);
            let v477_13: Space = map_map_kernels::unite(&(v477_8),&(v477_12));
            join_wrapped_into(&mut v476_10_write,&((v477_13).read_zipper()),&[]);
            }
            v470_12_cursor.ascend(1);
          }
          drop(v476_10_write);
          map_map_kernels::compose(&(v471_9),&(v476_10))
        };
        drop(v471_9);
        let v471_12: Space = map_map_kernels::unite(&(v471_7),&(v471_11));
        join_wrapped_into(&mut v470_12_write,&((v471_12).read_zipper()),&[]);
        }
        v470_12_cursor.ascend(1);
      }
      drop(v470_12_cursor);
      drop(v470_12_write);
      map_map_kernels::compose(&(v459_10),&(v470_12))
    };
    drop(v459_10);
    let v459_14: Space = map_map_kernels::unite(&(v459_8),&(v459_13));
    join_wrapped_into(&mut v458_28_write,&((v459_14).read_zipper()),&[]);
    }
    v458_28_cursor.ascend(1);
  }
  drop(v458_28_cursor);
  drop(v458_28_write);
  (v458_28).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v480_21 = Space::new();
  let mut v480_21_write = v480_21.write_zipper();
  let mut v480_21_cursor = (*s0).read_zipper();
  let v480_21_origin = v480_21_cursor.path().len();
  for v480_21_byte in v480_21_cursor.child_mask().iter() {
    v480_21_cursor.descend_to_existing_byte(v480_21_byte);
    {
    let v481_2: Space = singleton(&v480_21_cursor.path()[v480_21_origin..(v480_21_origin + 1)]);
    let v481_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v481_2));
    let v481_4: Space = if map_kernels::has_head(&(v481_3)) { singleton(&[]) } else { Space::new() };
    drop(v481_3);
    let v481_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v481_4));
    drop(v481_4);
    let v481_8: Space = if (&(v481_5)).is_empty() { Space::new() } else {
      let v482_6: Path = concat_path(&(*p0),&v480_21_cursor.path()[v480_21_origin..(v480_21_origin + 1)]);
      let mut v482_7 = Space::new();
      let mut v482_7_write = v482_7.write_zipper();
      for v482_7_byte in v480_21_cursor.child_mask().iter() {
        v480_21_cursor.descend_to_existing_byte(v482_7_byte);
        {
        let v483_2: Space = singleton(&v480_21_cursor.path()[(v480_21_origin + 1)..(v480_21_origin + 2)]);
        let v483_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v483_2));
        let v483_4: Space = if map_kernels::has_head(&(v483_3)) { singleton(&[]) } else { Space::new() };
        drop(v483_3);
        let v483_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v483_4));
        drop(v483_4);
        let v483_8: Space = if (&(v483_5)).is_empty() { Space::new() } else {
          let v484_6: Path = concat_path(&(v482_6),&v480_21_cursor.path()[(v480_21_origin + 1)..(v480_21_origin + 2)]);
          let mut v484_7 = Space::new();
          let mut v484_7_write = v484_7.write_zipper();
          for v484_7_byte in v480_21_cursor.child_mask().iter() {
            v480_21_cursor.descend_to_existing_byte(v484_7_byte);
            {
            let v485_2: Space = singleton(&v480_21_cursor.path()[(v480_21_origin + 2)..(v480_21_origin + 3)]);
            let v485_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v485_2));
            let v485_4: Space = if map_kernels::has_head(&(v485_3)) { singleton(&[]) } else { Space::new() };
            drop(v485_3);
            let v485_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v485_4));
            drop(v485_4);
            let v485_8: Space = if (&(v485_5)).is_empty() { Space::new() } else {
              let v486_6: Path = concat_path(&(v484_6),&v480_21_cursor.path()[(v480_21_origin + 2)..(v480_21_origin + 3)]);
              let v486_7: Space = routine_38(c, &(v486_6), &(*p1), &v480_21_cursor);
              map_map_kernels::compose(&(v485_5),&(v486_7))
            };
            drop(v485_5);
            let v485_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v485_2));
            drop(v485_2);
            let v485_10: Space = if map_kernels::has_head(&(v485_9)) { singleton(&[]) } else { Space::new() };
            drop(v485_9);
            let v485_12: Space = if (&(v485_10)).is_empty() { Space::new() } else {
              let v487_6: Path = concat_path(&(v484_6),&v480_21_cursor.path()[(v480_21_origin + 2)..(v480_21_origin + 3)]);
              let v487_11: Space = routine_39(c, &(v487_6), &(*p1), &v480_21_cursor);
              drop(v487_6);
              map_map_kernels::compose(&(v485_10),&(v487_11))
            };
            drop(v485_10);
            let v485_13: Space = map_map_kernels::unite(&(v485_8),&(v485_12));
            join_wrapped_into(&mut v484_7_write,&((v485_13).read_zipper()),&[]);
            }
            v480_21_cursor.ascend(1);
          }
          drop(v484_7_write);
          map_map_kernels::compose(&(v483_5),&(v484_7))
        };
        drop(v483_5);
        let v483_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v483_2));
        drop(v483_2);
        let v483_10: Space = if map_kernels::has_head(&(v483_9)) { singleton(&[]) } else { Space::new() };
        drop(v483_9);
        let v483_12: Space = if (&(v483_10)).is_empty() { Space::new() } else {
          let v488_6: Path = concat_path(&(v482_6),&v480_21_cursor.path()[(v480_21_origin + 1)..(v480_21_origin + 2)]);
          let mut v488_11 = Space::new();
          let mut v488_11_write = v488_11.write_zipper();
          for v488_11_byte in v480_21_cursor.child_mask().iter() {
            v480_21_cursor.descend_to_existing_byte(v488_11_byte);
            {
            let v489_2: Space = singleton(&v480_21_cursor.path()[(v480_21_origin + 2)..(v480_21_origin + 3)]);
            let v489_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v489_2));
            let v489_4: Space = if map_kernels::has_head(&(v489_3)) { singleton(&[]) } else { Space::new() };
            drop(v489_3);
            let v489_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v489_4));
            drop(v489_4);
            let v489_8: Space = if (&(v489_5)).is_empty() { Space::new() } else {
              let v490_6: Path = concat_path(&(v488_6),&v480_21_cursor.path()[(v480_21_origin + 2)..(v480_21_origin + 3)]);
              let v490_7: Space = routine_38(c, &(v490_6), &(*p1), &v480_21_cursor);
              map_map_kernels::compose(&(v489_5),&(v490_7))
            };
            drop(v489_5);
            let v489_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v489_2));
            drop(v489_2);
            let v489_10: Space = if map_kernels::has_head(&(v489_9)) { singleton(&[]) } else { Space::new() };
            drop(v489_9);
            let v489_12: Space = if (&(v489_10)).is_empty() { Space::new() } else {
              let v491_6: Path = concat_path(&(v488_6),&v480_21_cursor.path()[(v480_21_origin + 2)..(v480_21_origin + 3)]);
              let v491_11: Space = routine_19(c, &(v491_6), &(*p1), &v480_21_cursor);
              drop(v491_6);
              map_map_kernels::compose(&(v489_10),&(v491_11))
            };
            drop(v489_10);
            let v489_13: Space = map_map_kernels::unite(&(v489_8),&(v489_12));
            join_wrapped_into(&mut v488_11_write,&((v489_13).read_zipper()),&[]);
            }
            v480_21_cursor.ascend(1);
          }
          drop(v488_11_write);
          drop(v488_6);
          map_map_kernels::compose(&(v483_10),&(v488_11))
        };
        drop(v483_10);
        let v483_13: Space = map_map_kernels::unite(&(v483_8),&(v483_12));
        join_wrapped_into(&mut v482_7_write,&((v483_13).read_zipper()),&[]);
        }
        v480_21_cursor.ascend(1);
      }
      drop(v482_7_write);
      map_map_kernels::compose(&(v481_5),&(v482_7))
    };
    drop(v481_5);
    let v481_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v481_2));
    drop(v481_2);
    let v481_10: Space = if map_kernels::has_head(&(v481_9)) { singleton(&[]) } else { Space::new() };
    drop(v481_9);
    let v481_12: Space = if (&(v481_10)).is_empty() { Space::new() } else {
      let v492_6: Path = concat_path(&(*p0),&v480_21_cursor.path()[v480_21_origin..(v480_21_origin + 1)]);
      let mut v492_11 = Space::new();
      let mut v492_11_write = v492_11.write_zipper();
      for v492_11_byte in v480_21_cursor.child_mask().iter() {
        v480_21_cursor.descend_to_existing_byte(v492_11_byte);
        {
        let v493_2: Space = singleton(&v480_21_cursor.path()[(v480_21_origin + 1)..(v480_21_origin + 2)]);
        let v493_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v493_2));
        let v493_4: Space = if map_kernels::has_head(&(v493_3)) { singleton(&[]) } else { Space::new() };
        drop(v493_3);
        let v493_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v493_4));
        drop(v493_4);
        let v493_8: Space = if (&(v493_5)).is_empty() { Space::new() } else {
          let v494_6: Path = concat_path(&(v492_6),&v480_21_cursor.path()[(v480_21_origin + 1)..(v480_21_origin + 2)]);
          let mut v494_7 = Space::new();
          let mut v494_7_write = v494_7.write_zipper();
          for v494_7_byte in v480_21_cursor.child_mask().iter() {
            v480_21_cursor.descend_to_existing_byte(v494_7_byte);
            {
            let v495_2: Space = singleton(&v480_21_cursor.path()[(v480_21_origin + 2)..(v480_21_origin + 3)]);
            let v495_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v495_2));
            let v495_4: Space = if map_kernels::has_head(&(v495_3)) { singleton(&[]) } else { Space::new() };
            drop(v495_3);
            let v495_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v495_4));
            drop(v495_4);
            let v495_8: Space = if (&(v495_5)).is_empty() { Space::new() } else {
              let v496_6: Path = concat_path(&(v494_6),&v480_21_cursor.path()[(v480_21_origin + 2)..(v480_21_origin + 3)]);
              let v496_7: Space = routine_38(c, &(v496_6), &(*p1), &v480_21_cursor);
              map_map_kernels::compose(&(v495_5),&(v496_7))
            };
            drop(v495_5);
            let v495_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v495_2));
            drop(v495_2);
            let v495_10: Space = if map_kernels::has_head(&(v495_9)) { singleton(&[]) } else { Space::new() };
            drop(v495_9);
            let v495_12: Space = if (&(v495_10)).is_empty() { Space::new() } else {
              let v497_6: Path = concat_path(&(v494_6),&v480_21_cursor.path()[(v480_21_origin + 2)..(v480_21_origin + 3)]);
              let v497_11: Space = routine_39(c, &(v497_6), &(*p1), &v480_21_cursor);
              drop(v497_6);
              map_map_kernels::compose(&(v495_10),&(v497_11))
            };
            drop(v495_10);
            let v495_13: Space = map_map_kernels::unite(&(v495_8),&(v495_12));
            join_wrapped_into(&mut v494_7_write,&((v495_13).read_zipper()),&[]);
            }
            v480_21_cursor.ascend(1);
          }
          drop(v494_7_write);
          map_map_kernels::compose(&(v493_5),&(v494_7))
        };
        drop(v493_5);
        let v493_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v493_2));
        drop(v493_2);
        let v493_10: Space = if map_kernels::has_head(&(v493_9)) { singleton(&[]) } else { Space::new() };
        drop(v493_9);
        let v493_11: Space = map_view_kernels::compose(&(v493_10),&v480_21_cursor);
        drop(v493_10);
        let v498_6: Path = concat_path(&(v492_6),&v480_21_cursor.path()[(v480_21_origin + 1)..(v480_21_origin + 2)]);
        let v493_12: Space = map_kernels::wrap(&(v493_11),&(v498_6));
        drop(v493_11);
        let v493_13: Space = map_kernels::wrap(&(v493_12),&(*p1));
        drop(v493_12);
        let v493_14: Space = map_map_kernels::unite(&(v493_8),&(v493_13));
        drop(v493_13);
        join_wrapped_into(&mut v492_11_write,&((v493_14).read_zipper()),&[]);
        }
        v480_21_cursor.ascend(1);
      }
      drop(v492_11_write);
      drop(v492_6);
      map_map_kernels::compose(&(v481_10),&(v492_11))
    };
    drop(v481_10);
    let v481_13: Space = map_map_kernels::unite(&(v481_8),&(v481_12));
    join_wrapped_into(&mut v480_21_write,&((v481_13).read_zipper()),&[]);
    }
    v480_21_cursor.ascend(1);
  }
  drop(v480_21_cursor);
  drop(v480_21_write);
  (v480_21).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v499_15 = Space::new();
  let mut v499_15_write = v499_15.write_zipper();
  let mut v499_15_cursor = (*s0).read_zipper();
  let v499_15_origin = v499_15_cursor.path().len();
  for v499_15_byte in v499_15_cursor.child_mask().iter() {
    v499_15_cursor.descend_to_existing_byte(v499_15_byte);
    {
    let v500_2: Space = singleton(&v499_15_cursor.path()[v499_15_origin..(v499_15_origin + 1)]);
    let v500_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v500_2));
    let v500_4: Space = if map_kernels::has_head(&(v500_3)) { singleton(&[]) } else { Space::new() };
    drop(v500_3);
    let v500_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v500_4));
    drop(v500_4);
    let v500_8: Space = if (&(v500_5)).is_empty() { Space::new() } else {
      let v501_6: Path = concat_path(&(*p0),&v499_15_cursor.path()[v499_15_origin..(v499_15_origin + 1)]);
      let mut v501_7 = Space::new();
      let mut v501_7_write = v501_7.write_zipper();
      for v501_7_byte in v499_15_cursor.child_mask().iter() {
        v499_15_cursor.descend_to_existing_byte(v501_7_byte);
        {
        let v502_2: Space = singleton(&v499_15_cursor.path()[(v499_15_origin + 1)..(v499_15_origin + 2)]);
        let v502_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v502_2));
        let v502_4: Space = if map_kernels::has_head(&(v502_3)) { singleton(&[]) } else { Space::new() };
        drop(v502_3);
        let v502_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v502_4));
        drop(v502_4);
        let v502_8: Space = if (&(v502_5)).is_empty() { Space::new() } else {
          let v503_6: Path = concat_path(&(v501_6),&v499_15_cursor.path()[(v499_15_origin + 1)..(v499_15_origin + 2)]);
          let mut v503_7 = Space::new();
          let mut v503_7_write = v503_7.write_zipper();
          for v503_7_byte in v499_15_cursor.child_mask().iter() {
            v499_15_cursor.descend_to_existing_byte(v503_7_byte);
            {
            let v504_2: Space = singleton(&v499_15_cursor.path()[(v499_15_origin + 2)..(v499_15_origin + 3)]);
            let v504_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v504_2));
            let v504_4: Space = if map_kernels::has_head(&(v504_3)) { singleton(&[]) } else { Space::new() };
            drop(v504_3);
            let v504_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v504_4));
            drop(v504_4);
            let v504_8: Space = if (&(v504_5)).is_empty() { Space::new() } else {
              let v505_6: Path = concat_path(&(v503_6),&v499_15_cursor.path()[(v499_15_origin + 2)..(v499_15_origin + 3)]);
              let v505_7: Space = routine_38(c, &(v505_6), &(*p1), &v499_15_cursor);
              map_map_kernels::compose(&(v504_5),&(v505_7))
            };
            drop(v504_5);
            let v504_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v504_2));
            drop(v504_2);
            let v504_10: Space = if map_kernels::has_head(&(v504_9)) { singleton(&[]) } else { Space::new() };
            drop(v504_9);
            let v504_12: Space = if (&(v504_10)).is_empty() { Space::new() } else {
              let v506_6: Path = concat_path(&(v503_6),&v499_15_cursor.path()[(v499_15_origin + 2)..(v499_15_origin + 3)]);
              let v506_11: Space = routine_39(c, &(v506_6), &(*p1), &v499_15_cursor);
              drop(v506_6);
              map_map_kernels::compose(&(v504_10),&(v506_11))
            };
            drop(v504_10);
            let v504_13: Space = map_map_kernels::unite(&(v504_8),&(v504_12));
            join_wrapped_into(&mut v503_7_write,&((v504_13).read_zipper()),&[]);
            }
            v499_15_cursor.ascend(1);
          }
          drop(v503_7_write);
          map_map_kernels::compose(&(v502_5),&(v503_7))
        };
        drop(v502_5);
        let v502_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v502_2));
        drop(v502_2);
        let v502_10: Space = if map_kernels::has_head(&(v502_9)) { singleton(&[]) } else { Space::new() };
        drop(v502_9);
        let v502_12: Space = if (&(v502_10)).is_empty() { Space::new() } else {
          let v507_6: Path = concat_path(&(v501_6),&v499_15_cursor.path()[(v499_15_origin + 1)..(v499_15_origin + 2)]);
          let mut v507_11 = Space::new();
          let mut v507_11_write = v507_11.write_zipper();
          for v507_11_byte in v499_15_cursor.child_mask().iter() {
            v499_15_cursor.descend_to_existing_byte(v507_11_byte);
            {
            let v508_2: Space = singleton(&v499_15_cursor.path()[(v499_15_origin + 2)..(v499_15_origin + 3)]);
            let v508_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v508_2));
            let v508_4: Space = if map_kernels::has_head(&(v508_3)) { singleton(&[]) } else { Space::new() };
            drop(v508_3);
            let v508_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v508_4));
            drop(v508_4);
            let v508_8: Space = if (&(v508_5)).is_empty() { Space::new() } else {
              let v509_6: Path = concat_path(&(v507_6),&v499_15_cursor.path()[(v499_15_origin + 2)..(v499_15_origin + 3)]);
              let v509_7: Space = routine_38(c, &(v509_6), &(*p1), &v499_15_cursor);
              map_map_kernels::compose(&(v508_5),&(v509_7))
            };
            drop(v508_5);
            let v508_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v508_2));
            drop(v508_2);
            let v508_10: Space = if map_kernels::has_head(&(v508_9)) { singleton(&[]) } else { Space::new() };
            drop(v508_9);
            let v508_12: Space = if (&(v508_10)).is_empty() { Space::new() } else {
              let v510_6: Path = concat_path(&(v507_6),&v499_15_cursor.path()[(v499_15_origin + 2)..(v499_15_origin + 3)]);
              let v510_11: Space = routine_19(c, &(v510_6), &(*p1), &v499_15_cursor);
              drop(v510_6);
              map_map_kernels::compose(&(v508_10),&(v510_11))
            };
            drop(v508_10);
            let v508_13: Space = map_map_kernels::unite(&(v508_8),&(v508_12));
            join_wrapped_into(&mut v507_11_write,&((v508_13).read_zipper()),&[]);
            }
            v499_15_cursor.ascend(1);
          }
          drop(v507_11_write);
          drop(v507_6);
          map_map_kernels::compose(&(v502_10),&(v507_11))
        };
        drop(v502_10);
        let v502_13: Space = map_map_kernels::unite(&(v502_8),&(v502_12));
        join_wrapped_into(&mut v501_7_write,&((v502_13).read_zipper()),&[]);
        }
        v499_15_cursor.ascend(1);
      }
      drop(v501_7_write);
      map_map_kernels::compose(&(v500_5),&(v501_7))
    };
    drop(v500_5);
    let v500_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v500_2));
    drop(v500_2);
    let v500_10: Space = if map_kernels::has_head(&(v500_9)) { singleton(&[]) } else { Space::new() };
    drop(v500_9);
    let v500_11: Space = map_view_kernels::compose(&(v500_10),&v499_15_cursor);
    drop(v500_10);
    let v511_6: Path = concat_path(&(*p0),&v499_15_cursor.path()[v499_15_origin..(v499_15_origin + 1)]);
    let v500_12: Space = map_kernels::wrap(&(v500_11),&(v511_6));
    drop(v500_11);
    let v500_13: Space = map_kernels::wrap(&(v500_12),&(*p1));
    drop(v500_12);
    let v500_14: Space = map_map_kernels::unite(&(v500_8),&(v500_13));
    drop(v500_13);
    join_wrapped_into(&mut v499_15_write,&((v500_14).read_zipper()),&[]);
    }
    v499_15_cursor.ascend(1);
  }
  drop(v499_15_cursor);
  drop(v499_15_write);
  (v499_15).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v512_28 = Space::new();
  let mut v512_28_write = v512_28.write_zipper();
  let mut v512_28_cursor = (*s0).read_zipper();
  let v512_28_origin = v512_28_cursor.path().len();
  for v512_28_byte in v512_28_cursor.child_mask().iter() {
    v512_28_cursor.descend_to_existing_byte(v512_28_byte);
    {
    let v513_2: Space = singleton(&v512_28_cursor.path()[v512_28_origin..(v512_28_origin + 1)]);
    let v513_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v513_2));
    let v513_4: Space = if map_kernels::has_head(&(v513_3)) { singleton(&[]) } else { Space::new() };
    drop(v513_3);
    let v513_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v513_4));
    drop(v513_4);
    let v513_8: Space = if (&(v513_5)).is_empty() { Space::new() } else {
      let v514_6: Path = concat_path(&(*p0),&v512_28_cursor.path()[v512_28_origin..(v512_28_origin + 1)]);
      let mut v514_7 = Space::new();
      let mut v514_7_write = v514_7.write_zipper();
      for v514_7_byte in v512_28_cursor.child_mask().iter() {
        v512_28_cursor.descend_to_existing_byte(v514_7_byte);
        {
        let v515_2: Space = singleton(&v512_28_cursor.path()[(v512_28_origin + 1)..(v512_28_origin + 2)]);
        let v515_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v515_2));
        let v515_4: Space = if map_kernels::has_head(&(v515_3)) { singleton(&[]) } else { Space::new() };
        drop(v515_3);
        let v515_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v515_4));
        drop(v515_4);
        let v515_8: Space = if (&(v515_5)).is_empty() { Space::new() } else {
          let v516_6: Path = concat_path(&(v514_6),&v512_28_cursor.path()[(v512_28_origin + 1)..(v512_28_origin + 2)]);
          let mut v516_7 = Space::new();
          let mut v516_7_write = v516_7.write_zipper();
          for v516_7_byte in v512_28_cursor.child_mask().iter() {
            v512_28_cursor.descend_to_existing_byte(v516_7_byte);
            {
            let v517_2: Space = singleton(&v512_28_cursor.path()[(v512_28_origin + 2)..(v512_28_origin + 3)]);
            let v517_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v517_2));
            let v517_4: Space = if map_kernels::has_head(&(v517_3)) { singleton(&[]) } else { Space::new() };
            drop(v517_3);
            let v517_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v517_4));
            drop(v517_4);
            let v517_8: Space = if (&(v517_5)).is_empty() { Space::new() } else {
              let v518_6: Path = concat_path(&(v516_6),&v512_28_cursor.path()[(v512_28_origin + 2)..(v512_28_origin + 3)]);
              let v518_7: Space = routine_40(c, &(v518_6), &(*p1), &v512_28_cursor, &(*s1));
              map_map_kernels::compose(&(v517_5),&(v518_7))
            };
            drop(v517_5);
            let v517_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v517_2));
            drop(v517_2);
            let v517_10: Space = if map_kernels::has_head(&(v517_9)) { singleton(&[]) } else { Space::new() };
            drop(v517_9);
            let v517_12: Space = if (&(v517_10)).is_empty() { Space::new() } else {
              let v519_6: Path = concat_path(&(v516_6),&v512_28_cursor.path()[(v512_28_origin + 2)..(v512_28_origin + 3)]);
              let v519_11: Space = routine_41(c, &(v519_6), &(*p1), &v512_28_cursor, &(*s1));
              drop(v519_6);
              map_map_kernels::compose(&(v517_10),&(v519_11))
            };
            drop(v517_10);
            let v517_13: Space = map_map_kernels::unite(&(v517_8),&(v517_12));
            join_wrapped_into(&mut v516_7_write,&((v517_13).read_zipper()),&[]);
            }
            v512_28_cursor.ascend(1);
          }
          drop(v516_7_write);
          map_map_kernels::compose(&(v515_5),&(v516_7))
        };
        drop(v515_5);
        let v515_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v515_2));
        drop(v515_2);
        let v515_10: Space = if map_kernels::has_head(&(v515_9)) { singleton(&[]) } else { Space::new() };
        drop(v515_9);
        let v515_12: Space = if (&(v515_10)).is_empty() { Space::new() } else {
          let v520_6: Path = concat_path(&(v514_6),&v512_28_cursor.path()[(v512_28_origin + 1)..(v512_28_origin + 2)]);
          let mut v520_11 = Space::new();
          let mut v520_11_write = v520_11.write_zipper();
          for v520_11_byte in v512_28_cursor.child_mask().iter() {
            v512_28_cursor.descend_to_existing_byte(v520_11_byte);
            {
            let v521_2: Space = singleton(&v512_28_cursor.path()[(v512_28_origin + 2)..(v512_28_origin + 3)]);
            let v521_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v521_2));
            let v521_4: Space = if map_kernels::has_head(&(v521_3)) { singleton(&[]) } else { Space::new() };
            drop(v521_3);
            let v521_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v521_4));
            drop(v521_4);
            let v521_8: Space = if (&(v521_5)).is_empty() { Space::new() } else {
              let v522_6: Path = concat_path(&(v520_6),&v512_28_cursor.path()[(v512_28_origin + 2)..(v512_28_origin + 3)]);
              let v522_7: Space = routine_40(c, &(v522_6), &(*p1), &v512_28_cursor, &(*s1));
              map_map_kernels::compose(&(v521_5),&(v522_7))
            };
            drop(v521_5);
            let v521_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v521_2));
            drop(v521_2);
            let v521_10: Space = if map_kernels::has_head(&(v521_9)) { singleton(&[]) } else { Space::new() };
            drop(v521_9);
            let v521_12: Space = if (&(v521_10)).is_empty() { Space::new() } else {
              let v523_6: Path = concat_path(&(v520_6),&v512_28_cursor.path()[(v512_28_origin + 2)..(v512_28_origin + 3)]);
              let v523_11: Space = routine_10(c, &(v523_6), &(*p1), &v512_28_cursor, &(*s1));
              drop(v523_6);
              map_map_kernels::compose(&(v521_10),&(v523_11))
            };
            drop(v521_10);
            let v521_13: Space = map_map_kernels::unite(&(v521_8),&(v521_12));
            join_wrapped_into(&mut v520_11_write,&((v521_13).read_zipper()),&[]);
            }
            v512_28_cursor.ascend(1);
          }
          drop(v520_11_write);
          drop(v520_6);
          map_map_kernels::compose(&(v515_10),&(v520_11))
        };
        drop(v515_10);
        let v515_13: Space = map_map_kernels::unite(&(v515_8),&(v515_12));
        join_wrapped_into(&mut v514_7_write,&((v515_13).read_zipper()),&[]);
        }
        v512_28_cursor.ascend(1);
      }
      drop(v514_7_write);
      map_map_kernels::compose(&(v513_5),&(v514_7))
    };
    drop(v513_5);
    let v513_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v513_2));
    drop(v513_2);
    let v513_10: Space = if map_kernels::has_head(&(v513_9)) { singleton(&[]) } else { Space::new() };
    drop(v513_9);
    let v513_13: Space = if (&(v513_10)).is_empty() { Space::new() } else {
      let v524_6: Path = concat_path(&(*p0),&v512_28_cursor.path()[v512_28_origin..(v512_28_origin + 1)]);
      let mut v524_12 = Space::new();
      let mut v524_12_write = v524_12.write_zipper();
      for v524_12_byte in v512_28_cursor.child_mask().iter() {
        v512_28_cursor.descend_to_existing_byte(v524_12_byte);
        {
        let v525_2: Space = singleton(&v512_28_cursor.path()[(v512_28_origin + 1)..(v512_28_origin + 2)]);
        let v525_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v525_2));
        let v525_4: Space = if map_kernels::has_head(&(v525_3)) { singleton(&[]) } else { Space::new() };
        drop(v525_3);
        let v525_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v525_4));
        drop(v525_4);
        let v525_8: Space = if (&(v525_5)).is_empty() { Space::new() } else {
          let v526_6: Path = concat_path(&(v524_6),&v512_28_cursor.path()[(v512_28_origin + 1)..(v512_28_origin + 2)]);
          let mut v526_7 = Space::new();
          let mut v526_7_write = v526_7.write_zipper();
          for v526_7_byte in v512_28_cursor.child_mask().iter() {
            v512_28_cursor.descend_to_existing_byte(v526_7_byte);
            {
            let v527_2: Space = singleton(&v512_28_cursor.path()[(v512_28_origin + 2)..(v512_28_origin + 3)]);
            let v527_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v527_2));
            let v527_4: Space = if map_kernels::has_head(&(v527_3)) { singleton(&[]) } else { Space::new() };
            drop(v527_3);
            let v527_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v527_4));
            drop(v527_4);
            let v527_8: Space = if (&(v527_5)).is_empty() { Space::new() } else {
              let v528_6: Path = concat_path(&(v526_6),&v512_28_cursor.path()[(v512_28_origin + 2)..(v512_28_origin + 3)]);
              let v528_7: Space = routine_40(c, &(v528_6), &(*p1), &v512_28_cursor, &(*s1));
              map_map_kernels::compose(&(v527_5),&(v528_7))
            };
            drop(v527_5);
            let v527_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v527_2));
            drop(v527_2);
            let v527_10: Space = if map_kernels::has_head(&(v527_9)) { singleton(&[]) } else { Space::new() };
            drop(v527_9);
            let v527_12: Space = if (&(v527_10)).is_empty() { Space::new() } else {
              let v529_6: Path = concat_path(&(v526_6),&v512_28_cursor.path()[(v512_28_origin + 2)..(v512_28_origin + 3)]);
              let v529_11: Space = routine_41(c, &(v529_6), &(*p1), &v512_28_cursor, &(*s1));
              drop(v529_6);
              map_map_kernels::compose(&(v527_10),&(v529_11))
            };
            drop(v527_10);
            let v527_13: Space = map_map_kernels::unite(&(v527_8),&(v527_12));
            join_wrapped_into(&mut v526_7_write,&((v527_13).read_zipper()),&[]);
            }
            v512_28_cursor.ascend(1);
          }
          drop(v526_7_write);
          drop(v526_6);
          map_map_kernels::compose(&(v525_5),&(v526_7))
        };
        drop(v525_5);
        let v525_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v525_2));
        drop(v525_2);
        let v525_10: Space = if map_kernels::has_head(&(v525_9)) { singleton(&[]) } else { Space::new() };
        drop(v525_9);
        let v525_13: Space = if (&(v525_10)).is_empty() { Space::new() } else {
          let mut v530_12 = Space::new();
          let mut v530_12_write = v530_12.write_zipper();
          let mut v530_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v512_28_cursor.path()[v512_28_origin..(v512_28_origin + 1)]),&v512_28_cursor.path()[(v512_28_origin + 1)..(v512_28_origin + 2)]);
          let v530_12_origin = v530_12_cursor.path().len();
          for v530_12_byte in v530_12_cursor.child_mask().iter() {
            v530_12_cursor.descend_to_existing_byte(v530_12_byte);
            {
            let v531_2: Space = singleton(&v530_12_cursor.path()[v530_12_origin..(v530_12_origin + 1)]);
            let v531_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v531_2));
            let v531_4: Space = if map_kernels::has_head(&(v531_3)) { singleton(&[]) } else { Space::new() };
            drop(v531_3);
            let v531_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v531_4));
            drop(v531_4);
            let v531_7: Space = if (&(v531_5)).is_empty() { Space::new() } else {
              let v532_6: Space = routine_13(c, &v530_12_cursor.path()[v530_12_origin..(v530_12_origin + 1)], &(*p1), &v530_12_cursor);
              map_map_kernels::compose(&(v531_5),&(v532_6))
            };
            drop(v531_5);
            let v531_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v531_2));
            drop(v531_2);
            let v531_9: Space = if map_kernels::has_head(&(v531_8)) { singleton(&[]) } else { Space::new() };
            drop(v531_8);
            let v531_11: Space = if (&(v531_9)).is_empty() { Space::new() } else {
              let v533_10: Space = routine_14(c, &v530_12_cursor.path()[v530_12_origin..(v530_12_origin + 1)], &(*p1), &v530_12_cursor);
              map_map_kernels::compose(&(v531_9),&(v533_10))
            };
            drop(v531_9);
            let v531_12: Space = map_map_kernels::unite(&(v531_7),&(v531_11));
            join_wrapped_into(&mut v530_12_write,&((v531_12).read_zipper()),&[]);
            }
            v530_12_cursor.ascend(1);
          }
          drop(v530_12_cursor);
          drop(v530_12_write);
          map_map_kernels::compose(&(v525_10),&(v530_12))
        };
        drop(v525_10);
        let v525_14: Space = map_map_kernels::unite(&(v525_8),&(v525_13));
        join_wrapped_into(&mut v524_12_write,&((v525_14).read_zipper()),&[]);
        }
        v512_28_cursor.ascend(1);
      }
      drop(v524_12_write);
      drop(v524_6);
      map_map_kernels::compose(&(v513_10),&(v524_12))
    };
    drop(v513_10);
    let v513_14: Space = map_map_kernels::unite(&(v513_8),&(v513_13));
    join_wrapped_into(&mut v512_28_write,&((v513_14).read_zipper()),&[]);
    }
    v512_28_cursor.ascend(1);
  }
  drop(v512_28_cursor);
  drop(v512_28_write);
  (v512_28).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v534_28 = Space::new();
  let mut v534_28_write = v534_28.write_zipper();
  let mut v534_28_cursor = (*s0).read_zipper();
  let v534_28_origin = v534_28_cursor.path().len();
  for v534_28_byte in v534_28_cursor.child_mask().iter() {
    v534_28_cursor.descend_to_existing_byte(v534_28_byte);
    {
    let v535_2: Space = singleton(&v534_28_cursor.path()[v534_28_origin..(v534_28_origin + 1)]);
    let v535_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v535_2));
    let v535_4: Space = if map_kernels::has_head(&(v535_3)) { singleton(&[]) } else { Space::new() };
    drop(v535_3);
    let v535_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v535_4));
    drop(v535_4);
    let v535_8: Space = if (&(v535_5)).is_empty() { Space::new() } else {
      let v536_6: Path = concat_path(&(*p0),&v534_28_cursor.path()[v534_28_origin..(v534_28_origin + 1)]);
      let mut v536_7 = Space::new();
      let mut v536_7_write = v536_7.write_zipper();
      for v536_7_byte in v534_28_cursor.child_mask().iter() {
        v534_28_cursor.descend_to_existing_byte(v536_7_byte);
        {
        let v537_2: Space = singleton(&v534_28_cursor.path()[(v534_28_origin + 1)..(v534_28_origin + 2)]);
        let v537_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v537_2));
        let v537_4: Space = if map_kernels::has_head(&(v537_3)) { singleton(&[]) } else { Space::new() };
        drop(v537_3);
        let v537_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v537_4));
        drop(v537_4);
        let v537_8: Space = if (&(v537_5)).is_empty() { Space::new() } else {
          let v538_6: Path = concat_path(&(v536_6),&v534_28_cursor.path()[(v534_28_origin + 1)..(v534_28_origin + 2)]);
          let mut v538_7 = Space::new();
          let mut v538_7_write = v538_7.write_zipper();
          for v538_7_byte in v534_28_cursor.child_mask().iter() {
            v534_28_cursor.descend_to_existing_byte(v538_7_byte);
            {
            let v539_2: Space = singleton(&v534_28_cursor.path()[(v534_28_origin + 2)..(v534_28_origin + 3)]);
            let v539_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v539_2));
            let v539_4: Space = if map_kernels::has_head(&(v539_3)) { singleton(&[]) } else { Space::new() };
            drop(v539_3);
            let v539_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v539_4));
            drop(v539_4);
            let v539_8: Space = if (&(v539_5)).is_empty() { Space::new() } else {
              let v540_6: Path = concat_path(&(v538_6),&v534_28_cursor.path()[(v534_28_origin + 2)..(v534_28_origin + 3)]);
              let v540_7: Space = routine_40(c, &(v540_6), &(*p1), &v534_28_cursor, &(*s1));
              map_map_kernels::compose(&(v539_5),&(v540_7))
            };
            drop(v539_5);
            let v539_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v539_2));
            drop(v539_2);
            let v539_10: Space = if map_kernels::has_head(&(v539_9)) { singleton(&[]) } else { Space::new() };
            drop(v539_9);
            let v539_12: Space = if (&(v539_10)).is_empty() { Space::new() } else {
              let v541_6: Path = concat_path(&(v538_6),&v534_28_cursor.path()[(v534_28_origin + 2)..(v534_28_origin + 3)]);
              let v541_11: Space = routine_41(c, &(v541_6), &(*p1), &v534_28_cursor, &(*s1));
              drop(v541_6);
              map_map_kernels::compose(&(v539_10),&(v541_11))
            };
            drop(v539_10);
            let v539_13: Space = map_map_kernels::unite(&(v539_8),&(v539_12));
            join_wrapped_into(&mut v538_7_write,&((v539_13).read_zipper()),&[]);
            }
            v534_28_cursor.ascend(1);
          }
          drop(v538_7_write);
          map_map_kernels::compose(&(v537_5),&(v538_7))
        };
        drop(v537_5);
        let v537_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v537_2));
        drop(v537_2);
        let v537_10: Space = if map_kernels::has_head(&(v537_9)) { singleton(&[]) } else { Space::new() };
        drop(v537_9);
        let v537_12: Space = if (&(v537_10)).is_empty() { Space::new() } else {
          let v542_6: Path = concat_path(&(v536_6),&v534_28_cursor.path()[(v534_28_origin + 1)..(v534_28_origin + 2)]);
          let mut v542_11 = Space::new();
          let mut v542_11_write = v542_11.write_zipper();
          for v542_11_byte in v534_28_cursor.child_mask().iter() {
            v534_28_cursor.descend_to_existing_byte(v542_11_byte);
            {
            let v543_2: Space = singleton(&v534_28_cursor.path()[(v534_28_origin + 2)..(v534_28_origin + 3)]);
            let v543_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v543_2));
            let v543_4: Space = if map_kernels::has_head(&(v543_3)) { singleton(&[]) } else { Space::new() };
            drop(v543_3);
            let v543_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v543_4));
            drop(v543_4);
            let v543_8: Space = if (&(v543_5)).is_empty() { Space::new() } else {
              let v544_6: Path = concat_path(&(v542_6),&v534_28_cursor.path()[(v534_28_origin + 2)..(v534_28_origin + 3)]);
              let v544_7: Space = routine_40(c, &(v544_6), &(*p1), &v534_28_cursor, &(*s1));
              map_map_kernels::compose(&(v543_5),&(v544_7))
            };
            drop(v543_5);
            let v543_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v543_2));
            drop(v543_2);
            let v543_10: Space = if map_kernels::has_head(&(v543_9)) { singleton(&[]) } else { Space::new() };
            drop(v543_9);
            let v543_12: Space = if (&(v543_10)).is_empty() { Space::new() } else {
              let v545_6: Path = concat_path(&(v542_6),&v534_28_cursor.path()[(v534_28_origin + 2)..(v534_28_origin + 3)]);
              let v545_11: Space = routine_10(c, &(v545_6), &(*p1), &v534_28_cursor, &(*s1));
              drop(v545_6);
              map_map_kernels::compose(&(v543_10),&(v545_11))
            };
            drop(v543_10);
            let v543_13: Space = map_map_kernels::unite(&(v543_8),&(v543_12));
            join_wrapped_into(&mut v542_11_write,&((v543_13).read_zipper()),&[]);
            }
            v534_28_cursor.ascend(1);
          }
          drop(v542_11_write);
          drop(v542_6);
          map_map_kernels::compose(&(v537_10),&(v542_11))
        };
        drop(v537_10);
        let v537_13: Space = map_map_kernels::unite(&(v537_8),&(v537_12));
        join_wrapped_into(&mut v536_7_write,&((v537_13).read_zipper()),&[]);
        }
        v534_28_cursor.ascend(1);
      }
      drop(v536_7_write);
      drop(v536_6);
      map_map_kernels::compose(&(v535_5),&(v536_7))
    };
    drop(v535_5);
    let v535_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v535_2));
    drop(v535_2);
    let v535_10: Space = if map_kernels::has_head(&(v535_9)) { singleton(&[]) } else { Space::new() };
    drop(v535_9);
    let v535_13: Space = if (&(v535_10)).is_empty() { Space::new() } else {
      let mut v546_12 = Space::new();
      let mut v546_12_write = v546_12.write_zipper();
      let mut v546_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v534_28_cursor.path()[v534_28_origin..(v534_28_origin + 1)]);
      let v546_12_origin = v546_12_cursor.path().len();
      for v546_12_byte in v546_12_cursor.child_mask().iter() {
        v546_12_cursor.descend_to_existing_byte(v546_12_byte);
        {
        let v547_2: Space = singleton(&v546_12_cursor.path()[v546_12_origin..(v546_12_origin + 1)]);
        let v547_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v547_2));
        let v547_4: Space = if map_kernels::has_head(&(v547_3)) { singleton(&[]) } else { Space::new() };
        drop(v547_3);
        let v547_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v547_4));
        drop(v547_4);
        let v547_7: Space = if (&(v547_5)).is_empty() { Space::new() } else {
          let mut v548_6 = Space::new();
          let mut v548_6_write = v548_6.write_zipper();
          for v548_6_byte in v546_12_cursor.child_mask().iter() {
            v546_12_cursor.descend_to_existing_byte(v548_6_byte);
            {
            let v549_2: Space = singleton(&v546_12_cursor.path()[(v546_12_origin + 1)..(v546_12_origin + 2)]);
            let v549_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v549_2));
            let v549_4: Space = if map_kernels::has_head(&(v549_3)) { singleton(&[]) } else { Space::new() };
            drop(v549_3);
            let v549_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v549_4));
            drop(v549_4);
            let v549_8: Space = if (&(v549_5)).is_empty() { Space::new() } else {
              let v550_7: Space = routine_17(c, &v546_12_cursor.path()[v546_12_origin..(v546_12_origin + 2)], &(*p1), &v546_12_cursor);
              map_map_kernels::compose(&(v549_5),&(v550_7))
            };
            drop(v549_5);
            let v549_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v549_2));
            drop(v549_2);
            let v549_10: Space = if map_kernels::has_head(&(v549_9)) { singleton(&[]) } else { Space::new() };
            drop(v549_9);
            let v549_12: Space = if (&(v549_10)).is_empty() { Space::new() } else {
              let v551_11: Space = routine_18(c, &v546_12_cursor.path()[v546_12_origin..(v546_12_origin + 2)], &(*p1), &v546_12_cursor);
              map_map_kernels::compose(&(v549_10),&(v551_11))
            };
            drop(v549_10);
            let v549_13: Space = map_map_kernels::unite(&(v549_8),&(v549_12));
            join_wrapped_into(&mut v548_6_write,&((v549_13).read_zipper()),&[]);
            }
            v546_12_cursor.ascend(1);
          }
          drop(v548_6_write);
          map_map_kernels::compose(&(v547_5),&(v548_6))
        };
        drop(v547_5);
        let v547_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v547_2));
        drop(v547_2);
        let v547_9: Space = if map_kernels::has_head(&(v547_8)) { singleton(&[]) } else { Space::new() };
        drop(v547_8);
        let v547_11: Space = if (&(v547_9)).is_empty() { Space::new() } else {
          let mut v552_10 = Space::new();
          let mut v552_10_write = v552_10.write_zipper();
          for v552_10_byte in v546_12_cursor.child_mask().iter() {
            v546_12_cursor.descend_to_existing_byte(v552_10_byte);
            {
            let v553_2: Space = singleton(&v546_12_cursor.path()[(v546_12_origin + 1)..(v546_12_origin + 2)]);
            let v553_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v553_2));
            let v553_4: Space = if map_kernels::has_head(&(v553_3)) { singleton(&[]) } else { Space::new() };
            drop(v553_3);
            let v553_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v553_4));
            drop(v553_4);
            let v553_8: Space = if (&(v553_5)).is_empty() { Space::new() } else {
              let v554_7: Space = routine_17(c, &v546_12_cursor.path()[v546_12_origin..(v546_12_origin + 2)], &(*p1), &v546_12_cursor);
              map_map_kernels::compose(&(v553_5),&(v554_7))
            };
            drop(v553_5);
            let v553_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v553_2));
            drop(v553_2);
            let v553_10: Space = if map_kernels::has_head(&(v553_9)) { singleton(&[]) } else { Space::new() };
            drop(v553_9);
            let v553_12: Space = if (&(v553_10)).is_empty() { Space::new() } else {
              let v555_11: Space = routine_19(c, &v546_12_cursor.path()[v546_12_origin..(v546_12_origin + 2)], &(*p1), &v546_12_cursor);
              map_map_kernels::compose(&(v553_10),&(v555_11))
            };
            drop(v553_10);
            let v553_13: Space = map_map_kernels::unite(&(v553_8),&(v553_12));
            join_wrapped_into(&mut v552_10_write,&((v553_13).read_zipper()),&[]);
            }
            v546_12_cursor.ascend(1);
          }
          drop(v552_10_write);
          map_map_kernels::compose(&(v547_9),&(v552_10))
        };
        drop(v547_9);
        let v547_12: Space = map_map_kernels::unite(&(v547_7),&(v547_11));
        join_wrapped_into(&mut v546_12_write,&((v547_12).read_zipper()),&[]);
        }
        v546_12_cursor.ascend(1);
      }
      drop(v546_12_cursor);
      drop(v546_12_write);
      map_map_kernels::compose(&(v535_10),&(v546_12))
    };
    drop(v535_10);
    let v535_14: Space = map_map_kernels::unite(&(v535_8),&(v535_13));
    join_wrapped_into(&mut v534_28_write,&((v535_14).read_zipper()),&[]);
    }
    v534_28_cursor.ascend(1);
  }
  drop(v534_28_cursor);
  drop(v534_28_write);
  (v534_28).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v556_21 = Space::new();
  let mut v556_21_write = v556_21.write_zipper();
  let mut v556_21_cursor = (*s0).read_zipper();
  let v556_21_origin = v556_21_cursor.path().len();
  for v556_21_byte in v556_21_cursor.child_mask().iter() {
    v556_21_cursor.descend_to_existing_byte(v556_21_byte);
    {
    let v557_2: Space = singleton(&v556_21_cursor.path()[v556_21_origin..(v556_21_origin + 1)]);
    let v557_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v557_2));
    let v557_4: Space = if map_kernels::has_head(&(v557_3)) { singleton(&[]) } else { Space::new() };
    drop(v557_3);
    let v557_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v557_4));
    drop(v557_4);
    let v557_8: Space = if (&(v557_5)).is_empty() { Space::new() } else {
      let v558_6: Path = concat_path(&(*p0),&v556_21_cursor.path()[v556_21_origin..(v556_21_origin + 1)]);
      let mut v558_7 = Space::new();
      let mut v558_7_write = v558_7.write_zipper();
      for v558_7_byte in v556_21_cursor.child_mask().iter() {
        v556_21_cursor.descend_to_existing_byte(v558_7_byte);
        {
        let v559_2: Space = singleton(&v556_21_cursor.path()[(v556_21_origin + 1)..(v556_21_origin + 2)]);
        let v559_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v559_2));
        let v559_4: Space = if map_kernels::has_head(&(v559_3)) { singleton(&[]) } else { Space::new() };
        drop(v559_3);
        let v559_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v559_4));
        drop(v559_4);
        let v559_8: Space = if (&(v559_5)).is_empty() { Space::new() } else {
          let v560_6: Path = concat_path(&(v558_6),&v556_21_cursor.path()[(v556_21_origin + 1)..(v556_21_origin + 2)]);
          let mut v560_7 = Space::new();
          let mut v560_7_write = v560_7.write_zipper();
          for v560_7_byte in v556_21_cursor.child_mask().iter() {
            v556_21_cursor.descend_to_existing_byte(v560_7_byte);
            {
            let v561_2: Space = singleton(&v556_21_cursor.path()[(v556_21_origin + 2)..(v556_21_origin + 3)]);
            let v561_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v561_2));
            let v561_4: Space = if map_kernels::has_head(&(v561_3)) { singleton(&[]) } else { Space::new() };
            drop(v561_3);
            let v561_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v561_4));
            drop(v561_4);
            let v561_8: Space = if (&(v561_5)).is_empty() { Space::new() } else {
              let v562_6: Path = concat_path(&(v560_6),&v556_21_cursor.path()[(v556_21_origin + 2)..(v556_21_origin + 3)]);
              let v562_7: Space = routine_42(c, &(v562_6), &(*p1), &v556_21_cursor);
              map_map_kernels::compose(&(v561_5),&(v562_7))
            };
            drop(v561_5);
            let v561_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v561_2));
            drop(v561_2);
            let v561_10: Space = if map_kernels::has_head(&(v561_9)) { singleton(&[]) } else { Space::new() };
            drop(v561_9);
            let v561_12: Space = if (&(v561_10)).is_empty() { Space::new() } else {
              let v563_6: Path = concat_path(&(v560_6),&v556_21_cursor.path()[(v556_21_origin + 2)..(v556_21_origin + 3)]);
              let v563_11: Space = routine_43(c, &(v563_6), &(*p1), &v556_21_cursor);
              drop(v563_6);
              map_map_kernels::compose(&(v561_10),&(v563_11))
            };
            drop(v561_10);
            let v561_13: Space = map_map_kernels::unite(&(v561_8),&(v561_12));
            join_wrapped_into(&mut v560_7_write,&((v561_13).read_zipper()),&[]);
            }
            v556_21_cursor.ascend(1);
          }
          drop(v560_7_write);
          map_map_kernels::compose(&(v559_5),&(v560_7))
        };
        drop(v559_5);
        let v559_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v559_2));
        drop(v559_2);
        let v559_10: Space = if map_kernels::has_head(&(v559_9)) { singleton(&[]) } else { Space::new() };
        drop(v559_9);
        let v559_12: Space = if (&(v559_10)).is_empty() { Space::new() } else {
          let v564_6: Path = concat_path(&(v558_6),&v556_21_cursor.path()[(v556_21_origin + 1)..(v556_21_origin + 2)]);
          let mut v564_11 = Space::new();
          let mut v564_11_write = v564_11.write_zipper();
          for v564_11_byte in v556_21_cursor.child_mask().iter() {
            v556_21_cursor.descend_to_existing_byte(v564_11_byte);
            {
            let v565_2: Space = singleton(&v556_21_cursor.path()[(v556_21_origin + 2)..(v556_21_origin + 3)]);
            let v565_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v565_2));
            let v565_4: Space = if map_kernels::has_head(&(v565_3)) { singleton(&[]) } else { Space::new() };
            drop(v565_3);
            let v565_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v565_4));
            drop(v565_4);
            let v565_8: Space = if (&(v565_5)).is_empty() { Space::new() } else {
              let v566_6: Path = concat_path(&(v564_6),&v556_21_cursor.path()[(v556_21_origin + 2)..(v556_21_origin + 3)]);
              let v566_7: Space = routine_42(c, &(v566_6), &(*p1), &v556_21_cursor);
              map_map_kernels::compose(&(v565_5),&(v566_7))
            };
            drop(v565_5);
            let v565_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v565_2));
            drop(v565_2);
            let v565_10: Space = if map_kernels::has_head(&(v565_9)) { singleton(&[]) } else { Space::new() };
            drop(v565_9);
            let v565_12: Space = if (&(v565_10)).is_empty() { Space::new() } else {
              let v567_6: Path = concat_path(&(v564_6),&v556_21_cursor.path()[(v556_21_origin + 2)..(v556_21_origin + 3)]);
              let v567_11: Space = routine_19(c, &(v567_6), &(*p1), &v556_21_cursor);
              drop(v567_6);
              map_map_kernels::compose(&(v565_10),&(v567_11))
            };
            drop(v565_10);
            let v565_13: Space = map_map_kernels::unite(&(v565_8),&(v565_12));
            join_wrapped_into(&mut v564_11_write,&((v565_13).read_zipper()),&[]);
            }
            v556_21_cursor.ascend(1);
          }
          drop(v564_11_write);
          drop(v564_6);
          map_map_kernels::compose(&(v559_10),&(v564_11))
        };
        drop(v559_10);
        let v559_13: Space = map_map_kernels::unite(&(v559_8),&(v559_12));
        join_wrapped_into(&mut v558_7_write,&((v559_13).read_zipper()),&[]);
        }
        v556_21_cursor.ascend(1);
      }
      drop(v558_7_write);
      map_map_kernels::compose(&(v557_5),&(v558_7))
    };
    drop(v557_5);
    let v557_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v557_2));
    drop(v557_2);
    let v557_10: Space = if map_kernels::has_head(&(v557_9)) { singleton(&[]) } else { Space::new() };
    drop(v557_9);
    let v557_12: Space = if (&(v557_10)).is_empty() { Space::new() } else {
      let v568_6: Path = concat_path(&(*p0),&v556_21_cursor.path()[v556_21_origin..(v556_21_origin + 1)]);
      let mut v568_11 = Space::new();
      let mut v568_11_write = v568_11.write_zipper();
      for v568_11_byte in v556_21_cursor.child_mask().iter() {
        v556_21_cursor.descend_to_existing_byte(v568_11_byte);
        {
        let v569_2: Space = singleton(&v556_21_cursor.path()[(v556_21_origin + 1)..(v556_21_origin + 2)]);
        let v569_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v569_2));
        let v569_4: Space = if map_kernels::has_head(&(v569_3)) { singleton(&[]) } else { Space::new() };
        drop(v569_3);
        let v569_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v569_4));
        drop(v569_4);
        let v569_8: Space = if (&(v569_5)).is_empty() { Space::new() } else {
          let v570_6: Path = concat_path(&(v568_6),&v556_21_cursor.path()[(v556_21_origin + 1)..(v556_21_origin + 2)]);
          let mut v570_7 = Space::new();
          let mut v570_7_write = v570_7.write_zipper();
          for v570_7_byte in v556_21_cursor.child_mask().iter() {
            v556_21_cursor.descend_to_existing_byte(v570_7_byte);
            {
            let v571_2: Space = singleton(&v556_21_cursor.path()[(v556_21_origin + 2)..(v556_21_origin + 3)]);
            let v571_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v571_2));
            let v571_4: Space = if map_kernels::has_head(&(v571_3)) { singleton(&[]) } else { Space::new() };
            drop(v571_3);
            let v571_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v571_4));
            drop(v571_4);
            let v571_8: Space = if (&(v571_5)).is_empty() { Space::new() } else {
              let v572_6: Path = concat_path(&(v570_6),&v556_21_cursor.path()[(v556_21_origin + 2)..(v556_21_origin + 3)]);
              let v572_7: Space = routine_42(c, &(v572_6), &(*p1), &v556_21_cursor);
              map_map_kernels::compose(&(v571_5),&(v572_7))
            };
            drop(v571_5);
            let v571_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v571_2));
            drop(v571_2);
            let v571_10: Space = if map_kernels::has_head(&(v571_9)) { singleton(&[]) } else { Space::new() };
            drop(v571_9);
            let v571_12: Space = if (&(v571_10)).is_empty() { Space::new() } else {
              let v573_6: Path = concat_path(&(v570_6),&v556_21_cursor.path()[(v556_21_origin + 2)..(v556_21_origin + 3)]);
              let v573_11: Space = routine_43(c, &(v573_6), &(*p1), &v556_21_cursor);
              drop(v573_6);
              map_map_kernels::compose(&(v571_10),&(v573_11))
            };
            drop(v571_10);
            let v571_13: Space = map_map_kernels::unite(&(v571_8),&(v571_12));
            join_wrapped_into(&mut v570_7_write,&((v571_13).read_zipper()),&[]);
            }
            v556_21_cursor.ascend(1);
          }
          drop(v570_7_write);
          map_map_kernels::compose(&(v569_5),&(v570_7))
        };
        drop(v569_5);
        let v569_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v569_2));
        drop(v569_2);
        let v569_10: Space = if map_kernels::has_head(&(v569_9)) { singleton(&[]) } else { Space::new() };
        drop(v569_9);
        let v569_11: Space = map_view_kernels::compose(&(v569_10),&v556_21_cursor);
        drop(v569_10);
        let v574_6: Path = concat_path(&(v568_6),&v556_21_cursor.path()[(v556_21_origin + 1)..(v556_21_origin + 2)]);
        let v569_12: Space = map_kernels::wrap(&(v569_11),&(v574_6));
        drop(v569_11);
        let v569_13: Space = map_kernels::wrap(&(v569_12),&(*p1));
        drop(v569_12);
        let v569_14: Space = map_map_kernels::unite(&(v569_8),&(v569_13));
        drop(v569_13);
        join_wrapped_into(&mut v568_11_write,&((v569_14).read_zipper()),&[]);
        }
        v556_21_cursor.ascend(1);
      }
      drop(v568_11_write);
      drop(v568_6);
      map_map_kernels::compose(&(v557_10),&(v568_11))
    };
    drop(v557_10);
    let v557_13: Space = map_map_kernels::unite(&(v557_8),&(v557_12));
    join_wrapped_into(&mut v556_21_write,&((v557_13).read_zipper()),&[]);
    }
    v556_21_cursor.ascend(1);
  }
  drop(v556_21_cursor);
  drop(v556_21_write);
  (v556_21).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v575_15 = Space::new();
  let mut v575_15_write = v575_15.write_zipper();
  let mut v575_15_cursor = (*s0).read_zipper();
  let v575_15_origin = v575_15_cursor.path().len();
  for v575_15_byte in v575_15_cursor.child_mask().iter() {
    v575_15_cursor.descend_to_existing_byte(v575_15_byte);
    {
    let v576_2: Space = singleton(&v575_15_cursor.path()[v575_15_origin..(v575_15_origin + 1)]);
    let v576_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v576_2));
    let v576_4: Space = if map_kernels::has_head(&(v576_3)) { singleton(&[]) } else { Space::new() };
    drop(v576_3);
    let v576_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v576_4));
    drop(v576_4);
    let v576_8: Space = if (&(v576_5)).is_empty() { Space::new() } else {
      let v577_6: Path = concat_path(&(*p0),&v575_15_cursor.path()[v575_15_origin..(v575_15_origin + 1)]);
      let mut v577_7 = Space::new();
      let mut v577_7_write = v577_7.write_zipper();
      for v577_7_byte in v575_15_cursor.child_mask().iter() {
        v575_15_cursor.descend_to_existing_byte(v577_7_byte);
        {
        let v578_2: Space = singleton(&v575_15_cursor.path()[(v575_15_origin + 1)..(v575_15_origin + 2)]);
        let v578_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v578_2));
        let v578_4: Space = if map_kernels::has_head(&(v578_3)) { singleton(&[]) } else { Space::new() };
        drop(v578_3);
        let v578_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v578_4));
        drop(v578_4);
        let v578_8: Space = if (&(v578_5)).is_empty() { Space::new() } else {
          let v579_6: Path = concat_path(&(v577_6),&v575_15_cursor.path()[(v575_15_origin + 1)..(v575_15_origin + 2)]);
          let mut v579_7 = Space::new();
          let mut v579_7_write = v579_7.write_zipper();
          for v579_7_byte in v575_15_cursor.child_mask().iter() {
            v575_15_cursor.descend_to_existing_byte(v579_7_byte);
            {
            let v580_2: Space = singleton(&v575_15_cursor.path()[(v575_15_origin + 2)..(v575_15_origin + 3)]);
            let v580_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v580_2));
            let v580_4: Space = if map_kernels::has_head(&(v580_3)) { singleton(&[]) } else { Space::new() };
            drop(v580_3);
            let v580_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v580_4));
            drop(v580_4);
            let v580_8: Space = if (&(v580_5)).is_empty() { Space::new() } else {
              let v581_6: Path = concat_path(&(v579_6),&v575_15_cursor.path()[(v575_15_origin + 2)..(v575_15_origin + 3)]);
              let v581_7: Space = routine_42(c, &(v581_6), &(*p1), &v575_15_cursor);
              map_map_kernels::compose(&(v580_5),&(v581_7))
            };
            drop(v580_5);
            let v580_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v580_2));
            drop(v580_2);
            let v580_10: Space = if map_kernels::has_head(&(v580_9)) { singleton(&[]) } else { Space::new() };
            drop(v580_9);
            let v580_12: Space = if (&(v580_10)).is_empty() { Space::new() } else {
              let v582_6: Path = concat_path(&(v579_6),&v575_15_cursor.path()[(v575_15_origin + 2)..(v575_15_origin + 3)]);
              let v582_11: Space = routine_43(c, &(v582_6), &(*p1), &v575_15_cursor);
              drop(v582_6);
              map_map_kernels::compose(&(v580_10),&(v582_11))
            };
            drop(v580_10);
            let v580_13: Space = map_map_kernels::unite(&(v580_8),&(v580_12));
            join_wrapped_into(&mut v579_7_write,&((v580_13).read_zipper()),&[]);
            }
            v575_15_cursor.ascend(1);
          }
          drop(v579_7_write);
          map_map_kernels::compose(&(v578_5),&(v579_7))
        };
        drop(v578_5);
        let v578_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v578_2));
        drop(v578_2);
        let v578_10: Space = if map_kernels::has_head(&(v578_9)) { singleton(&[]) } else { Space::new() };
        drop(v578_9);
        let v578_12: Space = if (&(v578_10)).is_empty() { Space::new() } else {
          let v583_6: Path = concat_path(&(v577_6),&v575_15_cursor.path()[(v575_15_origin + 1)..(v575_15_origin + 2)]);
          let mut v583_11 = Space::new();
          let mut v583_11_write = v583_11.write_zipper();
          for v583_11_byte in v575_15_cursor.child_mask().iter() {
            v575_15_cursor.descend_to_existing_byte(v583_11_byte);
            {
            let v584_2: Space = singleton(&v575_15_cursor.path()[(v575_15_origin + 2)..(v575_15_origin + 3)]);
            let v584_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v584_2));
            let v584_4: Space = if map_kernels::has_head(&(v584_3)) { singleton(&[]) } else { Space::new() };
            drop(v584_3);
            let v584_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v584_4));
            drop(v584_4);
            let v584_8: Space = if (&(v584_5)).is_empty() { Space::new() } else {
              let v585_6: Path = concat_path(&(v583_6),&v575_15_cursor.path()[(v575_15_origin + 2)..(v575_15_origin + 3)]);
              let v585_7: Space = routine_42(c, &(v585_6), &(*p1), &v575_15_cursor);
              map_map_kernels::compose(&(v584_5),&(v585_7))
            };
            drop(v584_5);
            let v584_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v584_2));
            drop(v584_2);
            let v584_10: Space = if map_kernels::has_head(&(v584_9)) { singleton(&[]) } else { Space::new() };
            drop(v584_9);
            let v584_12: Space = if (&(v584_10)).is_empty() { Space::new() } else {
              let v586_6: Path = concat_path(&(v583_6),&v575_15_cursor.path()[(v575_15_origin + 2)..(v575_15_origin + 3)]);
              let v586_11: Space = routine_19(c, &(v586_6), &(*p1), &v575_15_cursor);
              drop(v586_6);
              map_map_kernels::compose(&(v584_10),&(v586_11))
            };
            drop(v584_10);
            let v584_13: Space = map_map_kernels::unite(&(v584_8),&(v584_12));
            join_wrapped_into(&mut v583_11_write,&((v584_13).read_zipper()),&[]);
            }
            v575_15_cursor.ascend(1);
          }
          drop(v583_11_write);
          drop(v583_6);
          map_map_kernels::compose(&(v578_10),&(v583_11))
        };
        drop(v578_10);
        let v578_13: Space = map_map_kernels::unite(&(v578_8),&(v578_12));
        join_wrapped_into(&mut v577_7_write,&((v578_13).read_zipper()),&[]);
        }
        v575_15_cursor.ascend(1);
      }
      drop(v577_7_write);
      map_map_kernels::compose(&(v576_5),&(v577_7))
    };
    drop(v576_5);
    let v576_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v576_2));
    drop(v576_2);
    let v576_10: Space = if map_kernels::has_head(&(v576_9)) { singleton(&[]) } else { Space::new() };
    drop(v576_9);
    let v576_11: Space = map_view_kernels::compose(&(v576_10),&v575_15_cursor);
    drop(v576_10);
    let v587_6: Path = concat_path(&(*p0),&v575_15_cursor.path()[v575_15_origin..(v575_15_origin + 1)]);
    let v576_12: Space = map_kernels::wrap(&(v576_11),&(v587_6));
    drop(v576_11);
    let v576_13: Space = map_kernels::wrap(&(v576_12),&(*p1));
    drop(v576_12);
    let v576_14: Space = map_map_kernels::unite(&(v576_8),&(v576_13));
    drop(v576_13);
    join_wrapped_into(&mut v575_15_write,&((v576_14).read_zipper()),&[]);
    }
    v575_15_cursor.ascend(1);
  }
  drop(v575_15_cursor);
  drop(v575_15_write);
  (v575_15).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v588_28 = Space::new();
  let mut v588_28_write = v588_28.write_zipper();
  let mut v588_28_cursor = (*s0).read_zipper();
  let v588_28_origin = v588_28_cursor.path().len();
  for v588_28_byte in v588_28_cursor.child_mask().iter() {
    v588_28_cursor.descend_to_existing_byte(v588_28_byte);
    {
    let v589_2: Space = singleton(&v588_28_cursor.path()[v588_28_origin..(v588_28_origin + 1)]);
    let v589_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v589_2));
    let v589_4: Space = if map_kernels::has_head(&(v589_3)) { singleton(&[]) } else { Space::new() };
    drop(v589_3);
    let v589_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v589_4));
    drop(v589_4);
    let v589_8: Space = if (&(v589_5)).is_empty() { Space::new() } else {
      let v590_6: Path = concat_path(&(*p0),&v588_28_cursor.path()[v588_28_origin..(v588_28_origin + 1)]);
      let mut v590_7 = Space::new();
      let mut v590_7_write = v590_7.write_zipper();
      for v590_7_byte in v588_28_cursor.child_mask().iter() {
        v588_28_cursor.descend_to_existing_byte(v590_7_byte);
        {
        let v591_2: Space = singleton(&v588_28_cursor.path()[(v588_28_origin + 1)..(v588_28_origin + 2)]);
        let v591_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v591_2));
        let v591_4: Space = if map_kernels::has_head(&(v591_3)) { singleton(&[]) } else { Space::new() };
        drop(v591_3);
        let v591_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v591_4));
        drop(v591_4);
        let v591_8: Space = if (&(v591_5)).is_empty() { Space::new() } else {
          let v592_6: Path = concat_path(&(v590_6),&v588_28_cursor.path()[(v588_28_origin + 1)..(v588_28_origin + 2)]);
          let mut v592_7 = Space::new();
          let mut v592_7_write = v592_7.write_zipper();
          for v592_7_byte in v588_28_cursor.child_mask().iter() {
            v588_28_cursor.descend_to_existing_byte(v592_7_byte);
            {
            let v593_2: Space = singleton(&v588_28_cursor.path()[(v588_28_origin + 2)..(v588_28_origin + 3)]);
            let v593_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v593_2));
            let v593_4: Space = if map_kernels::has_head(&(v593_3)) { singleton(&[]) } else { Space::new() };
            drop(v593_3);
            let v593_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v593_4));
            drop(v593_4);
            let v593_8: Space = if (&(v593_5)).is_empty() { Space::new() } else {
              let v594_6: Path = concat_path(&(v592_6),&v588_28_cursor.path()[(v588_28_origin + 2)..(v588_28_origin + 3)]);
              let v594_7: Space = routine_44(c, &(v594_6), &(*p1), &v588_28_cursor, &(*s1));
              map_map_kernels::compose(&(v593_5),&(v594_7))
            };
            drop(v593_5);
            let v593_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v593_2));
            drop(v593_2);
            let v593_10: Space = if map_kernels::has_head(&(v593_9)) { singleton(&[]) } else { Space::new() };
            drop(v593_9);
            let v593_12: Space = if (&(v593_10)).is_empty() { Space::new() } else {
              let v595_6: Path = concat_path(&(v592_6),&v588_28_cursor.path()[(v588_28_origin + 2)..(v588_28_origin + 3)]);
              let v595_11: Space = routine_45(c, &(v595_6), &(*p1), &v588_28_cursor, &(*s1));
              drop(v595_6);
              map_map_kernels::compose(&(v593_10),&(v595_11))
            };
            drop(v593_10);
            let v593_13: Space = map_map_kernels::unite(&(v593_8),&(v593_12));
            join_wrapped_into(&mut v592_7_write,&((v593_13).read_zipper()),&[]);
            }
            v588_28_cursor.ascend(1);
          }
          drop(v592_7_write);
          map_map_kernels::compose(&(v591_5),&(v592_7))
        };
        drop(v591_5);
        let v591_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v591_2));
        drop(v591_2);
        let v591_10: Space = if map_kernels::has_head(&(v591_9)) { singleton(&[]) } else { Space::new() };
        drop(v591_9);
        let v591_12: Space = if (&(v591_10)).is_empty() { Space::new() } else {
          let v596_6: Path = concat_path(&(v590_6),&v588_28_cursor.path()[(v588_28_origin + 1)..(v588_28_origin + 2)]);
          let mut v596_11 = Space::new();
          let mut v596_11_write = v596_11.write_zipper();
          for v596_11_byte in v588_28_cursor.child_mask().iter() {
            v588_28_cursor.descend_to_existing_byte(v596_11_byte);
            {
            let v597_2: Space = singleton(&v588_28_cursor.path()[(v588_28_origin + 2)..(v588_28_origin + 3)]);
            let v597_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v597_2));
            let v597_4: Space = if map_kernels::has_head(&(v597_3)) { singleton(&[]) } else { Space::new() };
            drop(v597_3);
            let v597_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v597_4));
            drop(v597_4);
            let v597_8: Space = if (&(v597_5)).is_empty() { Space::new() } else {
              let v598_6: Path = concat_path(&(v596_6),&v588_28_cursor.path()[(v588_28_origin + 2)..(v588_28_origin + 3)]);
              let v598_7: Space = routine_44(c, &(v598_6), &(*p1), &v588_28_cursor, &(*s1));
              map_map_kernels::compose(&(v597_5),&(v598_7))
            };
            drop(v597_5);
            let v597_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v597_2));
            drop(v597_2);
            let v597_10: Space = if map_kernels::has_head(&(v597_9)) { singleton(&[]) } else { Space::new() };
            drop(v597_9);
            let v597_12: Space = if (&(v597_10)).is_empty() { Space::new() } else {
              let v599_6: Path = concat_path(&(v596_6),&v588_28_cursor.path()[(v588_28_origin + 2)..(v588_28_origin + 3)]);
              let v599_11: Space = routine_10(c, &(v599_6), &(*p1), &v588_28_cursor, &(*s1));
              drop(v599_6);
              map_map_kernels::compose(&(v597_10),&(v599_11))
            };
            drop(v597_10);
            let v597_13: Space = map_map_kernels::unite(&(v597_8),&(v597_12));
            join_wrapped_into(&mut v596_11_write,&((v597_13).read_zipper()),&[]);
            }
            v588_28_cursor.ascend(1);
          }
          drop(v596_11_write);
          drop(v596_6);
          map_map_kernels::compose(&(v591_10),&(v596_11))
        };
        drop(v591_10);
        let v591_13: Space = map_map_kernels::unite(&(v591_8),&(v591_12));
        join_wrapped_into(&mut v590_7_write,&((v591_13).read_zipper()),&[]);
        }
        v588_28_cursor.ascend(1);
      }
      drop(v590_7_write);
      map_map_kernels::compose(&(v589_5),&(v590_7))
    };
    drop(v589_5);
    let v589_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v589_2));
    drop(v589_2);
    let v589_10: Space = if map_kernels::has_head(&(v589_9)) { singleton(&[]) } else { Space::new() };
    drop(v589_9);
    let v589_13: Space = if (&(v589_10)).is_empty() { Space::new() } else {
      let v600_6: Path = concat_path(&(*p0),&v588_28_cursor.path()[v588_28_origin..(v588_28_origin + 1)]);
      let mut v600_12 = Space::new();
      let mut v600_12_write = v600_12.write_zipper();
      for v600_12_byte in v588_28_cursor.child_mask().iter() {
        v588_28_cursor.descend_to_existing_byte(v600_12_byte);
        {
        let v601_2: Space = singleton(&v588_28_cursor.path()[(v588_28_origin + 1)..(v588_28_origin + 2)]);
        let v601_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v601_2));
        let v601_4: Space = if map_kernels::has_head(&(v601_3)) { singleton(&[]) } else { Space::new() };
        drop(v601_3);
        let v601_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v601_4));
        drop(v601_4);
        let v601_8: Space = if (&(v601_5)).is_empty() { Space::new() } else {
          let v602_6: Path = concat_path(&(v600_6),&v588_28_cursor.path()[(v588_28_origin + 1)..(v588_28_origin + 2)]);
          let mut v602_7 = Space::new();
          let mut v602_7_write = v602_7.write_zipper();
          for v602_7_byte in v588_28_cursor.child_mask().iter() {
            v588_28_cursor.descend_to_existing_byte(v602_7_byte);
            {
            let v603_2: Space = singleton(&v588_28_cursor.path()[(v588_28_origin + 2)..(v588_28_origin + 3)]);
            let v603_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v603_2));
            let v603_4: Space = if map_kernels::has_head(&(v603_3)) { singleton(&[]) } else { Space::new() };
            drop(v603_3);
            let v603_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v603_4));
            drop(v603_4);
            let v603_8: Space = if (&(v603_5)).is_empty() { Space::new() } else {
              let v604_6: Path = concat_path(&(v602_6),&v588_28_cursor.path()[(v588_28_origin + 2)..(v588_28_origin + 3)]);
              let v604_7: Space = routine_44(c, &(v604_6), &(*p1), &v588_28_cursor, &(*s1));
              map_map_kernels::compose(&(v603_5),&(v604_7))
            };
            drop(v603_5);
            let v603_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v603_2));
            drop(v603_2);
            let v603_10: Space = if map_kernels::has_head(&(v603_9)) { singleton(&[]) } else { Space::new() };
            drop(v603_9);
            let v603_12: Space = if (&(v603_10)).is_empty() { Space::new() } else {
              let v605_6: Path = concat_path(&(v602_6),&v588_28_cursor.path()[(v588_28_origin + 2)..(v588_28_origin + 3)]);
              let v605_11: Space = routine_45(c, &(v605_6), &(*p1), &v588_28_cursor, &(*s1));
              drop(v605_6);
              map_map_kernels::compose(&(v603_10),&(v605_11))
            };
            drop(v603_10);
            let v603_13: Space = map_map_kernels::unite(&(v603_8),&(v603_12));
            join_wrapped_into(&mut v602_7_write,&((v603_13).read_zipper()),&[]);
            }
            v588_28_cursor.ascend(1);
          }
          drop(v602_7_write);
          drop(v602_6);
          map_map_kernels::compose(&(v601_5),&(v602_7))
        };
        drop(v601_5);
        let v601_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v601_2));
        drop(v601_2);
        let v601_10: Space = if map_kernels::has_head(&(v601_9)) { singleton(&[]) } else { Space::new() };
        drop(v601_9);
        let v601_13: Space = if (&(v601_10)).is_empty() { Space::new() } else {
          let mut v606_12 = Space::new();
          let mut v606_12_write = v606_12.write_zipper();
          let mut v606_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v588_28_cursor.path()[v588_28_origin..(v588_28_origin + 1)]),&v588_28_cursor.path()[(v588_28_origin + 1)..(v588_28_origin + 2)]);
          let v606_12_origin = v606_12_cursor.path().len();
          for v606_12_byte in v606_12_cursor.child_mask().iter() {
            v606_12_cursor.descend_to_existing_byte(v606_12_byte);
            {
            let v607_2: Space = singleton(&v606_12_cursor.path()[v606_12_origin..(v606_12_origin + 1)]);
            let v607_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v607_2));
            let v607_4: Space = if map_kernels::has_head(&(v607_3)) { singleton(&[]) } else { Space::new() };
            drop(v607_3);
            let v607_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v607_4));
            drop(v607_4);
            let v607_7: Space = if (&(v607_5)).is_empty() { Space::new() } else {
              let v608_6: Space = routine_13(c, &v606_12_cursor.path()[v606_12_origin..(v606_12_origin + 1)], &(*p1), &v606_12_cursor);
              map_map_kernels::compose(&(v607_5),&(v608_6))
            };
            drop(v607_5);
            let v607_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v607_2));
            drop(v607_2);
            let v607_9: Space = if map_kernels::has_head(&(v607_8)) { singleton(&[]) } else { Space::new() };
            drop(v607_8);
            let v607_11: Space = if (&(v607_9)).is_empty() { Space::new() } else {
              let v609_10: Space = routine_14(c, &v606_12_cursor.path()[v606_12_origin..(v606_12_origin + 1)], &(*p1), &v606_12_cursor);
              map_map_kernels::compose(&(v607_9),&(v609_10))
            };
            drop(v607_9);
            let v607_12: Space = map_map_kernels::unite(&(v607_7),&(v607_11));
            join_wrapped_into(&mut v606_12_write,&((v607_12).read_zipper()),&[]);
            }
            v606_12_cursor.ascend(1);
          }
          drop(v606_12_cursor);
          drop(v606_12_write);
          map_map_kernels::compose(&(v601_10),&(v606_12))
        };
        drop(v601_10);
        let v601_14: Space = map_map_kernels::unite(&(v601_8),&(v601_13));
        join_wrapped_into(&mut v600_12_write,&((v601_14).read_zipper()),&[]);
        }
        v588_28_cursor.ascend(1);
      }
      drop(v600_12_write);
      drop(v600_6);
      map_map_kernels::compose(&(v589_10),&(v600_12))
    };
    drop(v589_10);
    let v589_14: Space = map_map_kernels::unite(&(v589_8),&(v589_13));
    join_wrapped_into(&mut v588_28_write,&((v589_14).read_zipper()),&[]);
    }
    v588_28_cursor.ascend(1);
  }
  drop(v588_28_cursor);
  drop(v588_28_write);
  (v588_28).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v610_28 = Space::new();
  let mut v610_28_write = v610_28.write_zipper();
  let mut v610_28_cursor = (*s0).read_zipper();
  let v610_28_origin = v610_28_cursor.path().len();
  for v610_28_byte in v610_28_cursor.child_mask().iter() {
    v610_28_cursor.descend_to_existing_byte(v610_28_byte);
    {
    let v611_2: Space = singleton(&v610_28_cursor.path()[v610_28_origin..(v610_28_origin + 1)]);
    let v611_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v611_2));
    let v611_4: Space = if map_kernels::has_head(&(v611_3)) { singleton(&[]) } else { Space::new() };
    drop(v611_3);
    let v611_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v611_4));
    drop(v611_4);
    let v611_8: Space = if (&(v611_5)).is_empty() { Space::new() } else {
      let v612_6: Path = concat_path(&(*p0),&v610_28_cursor.path()[v610_28_origin..(v610_28_origin + 1)]);
      let mut v612_7 = Space::new();
      let mut v612_7_write = v612_7.write_zipper();
      for v612_7_byte in v610_28_cursor.child_mask().iter() {
        v610_28_cursor.descend_to_existing_byte(v612_7_byte);
        {
        let v613_2: Space = singleton(&v610_28_cursor.path()[(v610_28_origin + 1)..(v610_28_origin + 2)]);
        let v613_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v613_2));
        let v613_4: Space = if map_kernels::has_head(&(v613_3)) { singleton(&[]) } else { Space::new() };
        drop(v613_3);
        let v613_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v613_4));
        drop(v613_4);
        let v613_8: Space = if (&(v613_5)).is_empty() { Space::new() } else {
          let v614_6: Path = concat_path(&(v612_6),&v610_28_cursor.path()[(v610_28_origin + 1)..(v610_28_origin + 2)]);
          let mut v614_7 = Space::new();
          let mut v614_7_write = v614_7.write_zipper();
          for v614_7_byte in v610_28_cursor.child_mask().iter() {
            v610_28_cursor.descend_to_existing_byte(v614_7_byte);
            {
            let v615_2: Space = singleton(&v610_28_cursor.path()[(v610_28_origin + 2)..(v610_28_origin + 3)]);
            let v615_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v615_2));
            let v615_4: Space = if map_kernels::has_head(&(v615_3)) { singleton(&[]) } else { Space::new() };
            drop(v615_3);
            let v615_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v615_4));
            drop(v615_4);
            let v615_8: Space = if (&(v615_5)).is_empty() { Space::new() } else {
              let v616_6: Path = concat_path(&(v614_6),&v610_28_cursor.path()[(v610_28_origin + 2)..(v610_28_origin + 3)]);
              let v616_7: Space = routine_44(c, &(v616_6), &(*p1), &v610_28_cursor, &(*s1));
              map_map_kernels::compose(&(v615_5),&(v616_7))
            };
            drop(v615_5);
            let v615_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v615_2));
            drop(v615_2);
            let v615_10: Space = if map_kernels::has_head(&(v615_9)) { singleton(&[]) } else { Space::new() };
            drop(v615_9);
            let v615_12: Space = if (&(v615_10)).is_empty() { Space::new() } else {
              let v617_6: Path = concat_path(&(v614_6),&v610_28_cursor.path()[(v610_28_origin + 2)..(v610_28_origin + 3)]);
              let v617_11: Space = routine_45(c, &(v617_6), &(*p1), &v610_28_cursor, &(*s1));
              drop(v617_6);
              map_map_kernels::compose(&(v615_10),&(v617_11))
            };
            drop(v615_10);
            let v615_13: Space = map_map_kernels::unite(&(v615_8),&(v615_12));
            join_wrapped_into(&mut v614_7_write,&((v615_13).read_zipper()),&[]);
            }
            v610_28_cursor.ascend(1);
          }
          drop(v614_7_write);
          map_map_kernels::compose(&(v613_5),&(v614_7))
        };
        drop(v613_5);
        let v613_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v613_2));
        drop(v613_2);
        let v613_10: Space = if map_kernels::has_head(&(v613_9)) { singleton(&[]) } else { Space::new() };
        drop(v613_9);
        let v613_12: Space = if (&(v613_10)).is_empty() { Space::new() } else {
          let v618_6: Path = concat_path(&(v612_6),&v610_28_cursor.path()[(v610_28_origin + 1)..(v610_28_origin + 2)]);
          let mut v618_11 = Space::new();
          let mut v618_11_write = v618_11.write_zipper();
          for v618_11_byte in v610_28_cursor.child_mask().iter() {
            v610_28_cursor.descend_to_existing_byte(v618_11_byte);
            {
            let v619_2: Space = singleton(&v610_28_cursor.path()[(v610_28_origin + 2)..(v610_28_origin + 3)]);
            let v619_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v619_2));
            let v619_4: Space = if map_kernels::has_head(&(v619_3)) { singleton(&[]) } else { Space::new() };
            drop(v619_3);
            let v619_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v619_4));
            drop(v619_4);
            let v619_8: Space = if (&(v619_5)).is_empty() { Space::new() } else {
              let v620_6: Path = concat_path(&(v618_6),&v610_28_cursor.path()[(v610_28_origin + 2)..(v610_28_origin + 3)]);
              let v620_7: Space = routine_44(c, &(v620_6), &(*p1), &v610_28_cursor, &(*s1));
              map_map_kernels::compose(&(v619_5),&(v620_7))
            };
            drop(v619_5);
            let v619_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v619_2));
            drop(v619_2);
            let v619_10: Space = if map_kernels::has_head(&(v619_9)) { singleton(&[]) } else { Space::new() };
            drop(v619_9);
            let v619_12: Space = if (&(v619_10)).is_empty() { Space::new() } else {
              let v621_6: Path = concat_path(&(v618_6),&v610_28_cursor.path()[(v610_28_origin + 2)..(v610_28_origin + 3)]);
              let v621_11: Space = routine_10(c, &(v621_6), &(*p1), &v610_28_cursor, &(*s1));
              drop(v621_6);
              map_map_kernels::compose(&(v619_10),&(v621_11))
            };
            drop(v619_10);
            let v619_13: Space = map_map_kernels::unite(&(v619_8),&(v619_12));
            join_wrapped_into(&mut v618_11_write,&((v619_13).read_zipper()),&[]);
            }
            v610_28_cursor.ascend(1);
          }
          drop(v618_11_write);
          drop(v618_6);
          map_map_kernels::compose(&(v613_10),&(v618_11))
        };
        drop(v613_10);
        let v613_13: Space = map_map_kernels::unite(&(v613_8),&(v613_12));
        join_wrapped_into(&mut v612_7_write,&((v613_13).read_zipper()),&[]);
        }
        v610_28_cursor.ascend(1);
      }
      drop(v612_7_write);
      drop(v612_6);
      map_map_kernels::compose(&(v611_5),&(v612_7))
    };
    drop(v611_5);
    let v611_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v611_2));
    drop(v611_2);
    let v611_10: Space = if map_kernels::has_head(&(v611_9)) { singleton(&[]) } else { Space::new() };
    drop(v611_9);
    let v611_13: Space = if (&(v611_10)).is_empty() { Space::new() } else {
      let mut v622_12 = Space::new();
      let mut v622_12_write = v622_12.write_zipper();
      let mut v622_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v610_28_cursor.path()[v610_28_origin..(v610_28_origin + 1)]);
      let v622_12_origin = v622_12_cursor.path().len();
      for v622_12_byte in v622_12_cursor.child_mask().iter() {
        v622_12_cursor.descend_to_existing_byte(v622_12_byte);
        {
        let v623_2: Space = singleton(&v622_12_cursor.path()[v622_12_origin..(v622_12_origin + 1)]);
        let v623_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v623_2));
        let v623_4: Space = if map_kernels::has_head(&(v623_3)) { singleton(&[]) } else { Space::new() };
        drop(v623_3);
        let v623_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v623_4));
        drop(v623_4);
        let v623_7: Space = if (&(v623_5)).is_empty() { Space::new() } else {
          let mut v624_6 = Space::new();
          let mut v624_6_write = v624_6.write_zipper();
          for v624_6_byte in v622_12_cursor.child_mask().iter() {
            v622_12_cursor.descend_to_existing_byte(v624_6_byte);
            {
            let v625_2: Space = singleton(&v622_12_cursor.path()[(v622_12_origin + 1)..(v622_12_origin + 2)]);
            let v625_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v625_2));
            let v625_4: Space = if map_kernels::has_head(&(v625_3)) { singleton(&[]) } else { Space::new() };
            drop(v625_3);
            let v625_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v625_4));
            drop(v625_4);
            let v625_8: Space = if (&(v625_5)).is_empty() { Space::new() } else {
              let v626_7: Space = routine_17(c, &v622_12_cursor.path()[v622_12_origin..(v622_12_origin + 2)], &(*p1), &v622_12_cursor);
              map_map_kernels::compose(&(v625_5),&(v626_7))
            };
            drop(v625_5);
            let v625_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v625_2));
            drop(v625_2);
            let v625_10: Space = if map_kernels::has_head(&(v625_9)) { singleton(&[]) } else { Space::new() };
            drop(v625_9);
            let v625_12: Space = if (&(v625_10)).is_empty() { Space::new() } else {
              let v627_11: Space = routine_18(c, &v622_12_cursor.path()[v622_12_origin..(v622_12_origin + 2)], &(*p1), &v622_12_cursor);
              map_map_kernels::compose(&(v625_10),&(v627_11))
            };
            drop(v625_10);
            let v625_13: Space = map_map_kernels::unite(&(v625_8),&(v625_12));
            join_wrapped_into(&mut v624_6_write,&((v625_13).read_zipper()),&[]);
            }
            v622_12_cursor.ascend(1);
          }
          drop(v624_6_write);
          map_map_kernels::compose(&(v623_5),&(v624_6))
        };
        drop(v623_5);
        let v623_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v623_2));
        drop(v623_2);
        let v623_9: Space = if map_kernels::has_head(&(v623_8)) { singleton(&[]) } else { Space::new() };
        drop(v623_8);
        let v623_11: Space = if (&(v623_9)).is_empty() { Space::new() } else {
          let mut v628_10 = Space::new();
          let mut v628_10_write = v628_10.write_zipper();
          for v628_10_byte in v622_12_cursor.child_mask().iter() {
            v622_12_cursor.descend_to_existing_byte(v628_10_byte);
            {
            let v629_2: Space = singleton(&v622_12_cursor.path()[(v622_12_origin + 1)..(v622_12_origin + 2)]);
            let v629_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v629_2));
            let v629_4: Space = if map_kernels::has_head(&(v629_3)) { singleton(&[]) } else { Space::new() };
            drop(v629_3);
            let v629_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v629_4));
            drop(v629_4);
            let v629_8: Space = if (&(v629_5)).is_empty() { Space::new() } else {
              let v630_7: Space = routine_17(c, &v622_12_cursor.path()[v622_12_origin..(v622_12_origin + 2)], &(*p1), &v622_12_cursor);
              map_map_kernels::compose(&(v629_5),&(v630_7))
            };
            drop(v629_5);
            let v629_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v629_2));
            drop(v629_2);
            let v629_10: Space = if map_kernels::has_head(&(v629_9)) { singleton(&[]) } else { Space::new() };
            drop(v629_9);
            let v629_12: Space = if (&(v629_10)).is_empty() { Space::new() } else {
              let v631_11: Space = routine_19(c, &v622_12_cursor.path()[v622_12_origin..(v622_12_origin + 2)], &(*p1), &v622_12_cursor);
              map_map_kernels::compose(&(v629_10),&(v631_11))
            };
            drop(v629_10);
            let v629_13: Space = map_map_kernels::unite(&(v629_8),&(v629_12));
            join_wrapped_into(&mut v628_10_write,&((v629_13).read_zipper()),&[]);
            }
            v622_12_cursor.ascend(1);
          }
          drop(v628_10_write);
          map_map_kernels::compose(&(v623_9),&(v628_10))
        };
        drop(v623_9);
        let v623_12: Space = map_map_kernels::unite(&(v623_7),&(v623_11));
        join_wrapped_into(&mut v622_12_write,&((v623_12).read_zipper()),&[]);
        }
        v622_12_cursor.ascend(1);
      }
      drop(v622_12_cursor);
      drop(v622_12_write);
      map_map_kernels::compose(&(v611_10),&(v622_12))
    };
    drop(v611_10);
    let v611_14: Space = map_map_kernels::unite(&(v611_8),&(v611_13));
    join_wrapped_into(&mut v610_28_write,&((v611_14).read_zipper()),&[]);
    }
    v610_28_cursor.ascend(1);
  }
  drop(v610_28_cursor);
  drop(v610_28_write);
  (v610_28).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v632_21 = Space::new();
  let mut v632_21_write = v632_21.write_zipper();
  let mut v632_21_cursor = (*s0).read_zipper();
  let v632_21_origin = v632_21_cursor.path().len();
  for v632_21_byte in v632_21_cursor.child_mask().iter() {
    v632_21_cursor.descend_to_existing_byte(v632_21_byte);
    {
    let v633_2: Space = singleton(&v632_21_cursor.path()[v632_21_origin..(v632_21_origin + 1)]);
    let v633_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v633_2));
    let v633_4: Space = if map_kernels::has_head(&(v633_3)) { singleton(&[]) } else { Space::new() };
    drop(v633_3);
    let v633_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v633_4));
    drop(v633_4);
    let v633_8: Space = if (&(v633_5)).is_empty() { Space::new() } else {
      let v634_6: Path = concat_path(&(*p0),&v632_21_cursor.path()[v632_21_origin..(v632_21_origin + 1)]);
      let mut v634_7 = Space::new();
      let mut v634_7_write = v634_7.write_zipper();
      for v634_7_byte in v632_21_cursor.child_mask().iter() {
        v632_21_cursor.descend_to_existing_byte(v634_7_byte);
        {
        let v635_2: Space = singleton(&v632_21_cursor.path()[(v632_21_origin + 1)..(v632_21_origin + 2)]);
        let v635_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v635_2));
        let v635_4: Space = if map_kernels::has_head(&(v635_3)) { singleton(&[]) } else { Space::new() };
        drop(v635_3);
        let v635_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v635_4));
        drop(v635_4);
        let v635_8: Space = if (&(v635_5)).is_empty() { Space::new() } else {
          let v636_6: Path = concat_path(&(v634_6),&v632_21_cursor.path()[(v632_21_origin + 1)..(v632_21_origin + 2)]);
          let mut v636_7 = Space::new();
          let mut v636_7_write = v636_7.write_zipper();
          for v636_7_byte in v632_21_cursor.child_mask().iter() {
            v632_21_cursor.descend_to_existing_byte(v636_7_byte);
            {
            let v637_2: Space = singleton(&v632_21_cursor.path()[(v632_21_origin + 2)..(v632_21_origin + 3)]);
            let v637_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v637_2));
            let v637_4: Space = if map_kernels::has_head(&(v637_3)) { singleton(&[]) } else { Space::new() };
            drop(v637_3);
            let v637_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v637_4));
            drop(v637_4);
            let v637_8: Space = if (&(v637_5)).is_empty() { Space::new() } else {
              let v638_6: Path = concat_path(&(v636_6),&v632_21_cursor.path()[(v632_21_origin + 2)..(v632_21_origin + 3)]);
              let v638_7: Space = routine_46(c, &(v638_6), &(*p1), &v632_21_cursor);
              map_map_kernels::compose(&(v637_5),&(v638_7))
            };
            drop(v637_5);
            let v637_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v637_2));
            drop(v637_2);
            let v637_10: Space = if map_kernels::has_head(&(v637_9)) { singleton(&[]) } else { Space::new() };
            drop(v637_9);
            let v637_12: Space = if (&(v637_10)).is_empty() { Space::new() } else {
              let v639_6: Path = concat_path(&(v636_6),&v632_21_cursor.path()[(v632_21_origin + 2)..(v632_21_origin + 3)]);
              let v639_11: Space = routine_47(c, &(v639_6), &(*p1), &v632_21_cursor);
              drop(v639_6);
              map_map_kernels::compose(&(v637_10),&(v639_11))
            };
            drop(v637_10);
            let v637_13: Space = map_map_kernels::unite(&(v637_8),&(v637_12));
            join_wrapped_into(&mut v636_7_write,&((v637_13).read_zipper()),&[]);
            }
            v632_21_cursor.ascend(1);
          }
          drop(v636_7_write);
          map_map_kernels::compose(&(v635_5),&(v636_7))
        };
        drop(v635_5);
        let v635_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v635_2));
        drop(v635_2);
        let v635_10: Space = if map_kernels::has_head(&(v635_9)) { singleton(&[]) } else { Space::new() };
        drop(v635_9);
        let v635_12: Space = if (&(v635_10)).is_empty() { Space::new() } else {
          let v640_6: Path = concat_path(&(v634_6),&v632_21_cursor.path()[(v632_21_origin + 1)..(v632_21_origin + 2)]);
          let mut v640_11 = Space::new();
          let mut v640_11_write = v640_11.write_zipper();
          for v640_11_byte in v632_21_cursor.child_mask().iter() {
            v632_21_cursor.descend_to_existing_byte(v640_11_byte);
            {
            let v641_2: Space = singleton(&v632_21_cursor.path()[(v632_21_origin + 2)..(v632_21_origin + 3)]);
            let v641_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v641_2));
            let v641_4: Space = if map_kernels::has_head(&(v641_3)) { singleton(&[]) } else { Space::new() };
            drop(v641_3);
            let v641_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v641_4));
            drop(v641_4);
            let v641_8: Space = if (&(v641_5)).is_empty() { Space::new() } else {
              let v642_6: Path = concat_path(&(v640_6),&v632_21_cursor.path()[(v632_21_origin + 2)..(v632_21_origin + 3)]);
              let v642_7: Space = routine_46(c, &(v642_6), &(*p1), &v632_21_cursor);
              map_map_kernels::compose(&(v641_5),&(v642_7))
            };
            drop(v641_5);
            let v641_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v641_2));
            drop(v641_2);
            let v641_10: Space = if map_kernels::has_head(&(v641_9)) { singleton(&[]) } else { Space::new() };
            drop(v641_9);
            let v641_12: Space = if (&(v641_10)).is_empty() { Space::new() } else {
              let v643_6: Path = concat_path(&(v640_6),&v632_21_cursor.path()[(v632_21_origin + 2)..(v632_21_origin + 3)]);
              let v643_11: Space = routine_19(c, &(v643_6), &(*p1), &v632_21_cursor);
              drop(v643_6);
              map_map_kernels::compose(&(v641_10),&(v643_11))
            };
            drop(v641_10);
            let v641_13: Space = map_map_kernels::unite(&(v641_8),&(v641_12));
            join_wrapped_into(&mut v640_11_write,&((v641_13).read_zipper()),&[]);
            }
            v632_21_cursor.ascend(1);
          }
          drop(v640_11_write);
          drop(v640_6);
          map_map_kernels::compose(&(v635_10),&(v640_11))
        };
        drop(v635_10);
        let v635_13: Space = map_map_kernels::unite(&(v635_8),&(v635_12));
        join_wrapped_into(&mut v634_7_write,&((v635_13).read_zipper()),&[]);
        }
        v632_21_cursor.ascend(1);
      }
      drop(v634_7_write);
      map_map_kernels::compose(&(v633_5),&(v634_7))
    };
    drop(v633_5);
    let v633_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v633_2));
    drop(v633_2);
    let v633_10: Space = if map_kernels::has_head(&(v633_9)) { singleton(&[]) } else { Space::new() };
    drop(v633_9);
    let v633_12: Space = if (&(v633_10)).is_empty() { Space::new() } else {
      let v644_6: Path = concat_path(&(*p0),&v632_21_cursor.path()[v632_21_origin..(v632_21_origin + 1)]);
      let mut v644_11 = Space::new();
      let mut v644_11_write = v644_11.write_zipper();
      for v644_11_byte in v632_21_cursor.child_mask().iter() {
        v632_21_cursor.descend_to_existing_byte(v644_11_byte);
        {
        let v645_2: Space = singleton(&v632_21_cursor.path()[(v632_21_origin + 1)..(v632_21_origin + 2)]);
        let v645_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v645_2));
        let v645_4: Space = if map_kernels::has_head(&(v645_3)) { singleton(&[]) } else { Space::new() };
        drop(v645_3);
        let v645_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v645_4));
        drop(v645_4);
        let v645_8: Space = if (&(v645_5)).is_empty() { Space::new() } else {
          let v646_6: Path = concat_path(&(v644_6),&v632_21_cursor.path()[(v632_21_origin + 1)..(v632_21_origin + 2)]);
          let mut v646_7 = Space::new();
          let mut v646_7_write = v646_7.write_zipper();
          for v646_7_byte in v632_21_cursor.child_mask().iter() {
            v632_21_cursor.descend_to_existing_byte(v646_7_byte);
            {
            let v647_2: Space = singleton(&v632_21_cursor.path()[(v632_21_origin + 2)..(v632_21_origin + 3)]);
            let v647_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v647_2));
            let v647_4: Space = if map_kernels::has_head(&(v647_3)) { singleton(&[]) } else { Space::new() };
            drop(v647_3);
            let v647_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v647_4));
            drop(v647_4);
            let v647_8: Space = if (&(v647_5)).is_empty() { Space::new() } else {
              let v648_6: Path = concat_path(&(v646_6),&v632_21_cursor.path()[(v632_21_origin + 2)..(v632_21_origin + 3)]);
              let v648_7: Space = routine_46(c, &(v648_6), &(*p1), &v632_21_cursor);
              map_map_kernels::compose(&(v647_5),&(v648_7))
            };
            drop(v647_5);
            let v647_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v647_2));
            drop(v647_2);
            let v647_10: Space = if map_kernels::has_head(&(v647_9)) { singleton(&[]) } else { Space::new() };
            drop(v647_9);
            let v647_12: Space = if (&(v647_10)).is_empty() { Space::new() } else {
              let v649_6: Path = concat_path(&(v646_6),&v632_21_cursor.path()[(v632_21_origin + 2)..(v632_21_origin + 3)]);
              let v649_11: Space = routine_47(c, &(v649_6), &(*p1), &v632_21_cursor);
              drop(v649_6);
              map_map_kernels::compose(&(v647_10),&(v649_11))
            };
            drop(v647_10);
            let v647_13: Space = map_map_kernels::unite(&(v647_8),&(v647_12));
            join_wrapped_into(&mut v646_7_write,&((v647_13).read_zipper()),&[]);
            }
            v632_21_cursor.ascend(1);
          }
          drop(v646_7_write);
          map_map_kernels::compose(&(v645_5),&(v646_7))
        };
        drop(v645_5);
        let v645_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v645_2));
        drop(v645_2);
        let v645_10: Space = if map_kernels::has_head(&(v645_9)) { singleton(&[]) } else { Space::new() };
        drop(v645_9);
        let v645_11: Space = map_view_kernels::compose(&(v645_10),&v632_21_cursor);
        drop(v645_10);
        let v650_6: Path = concat_path(&(v644_6),&v632_21_cursor.path()[(v632_21_origin + 1)..(v632_21_origin + 2)]);
        let v645_12: Space = map_kernels::wrap(&(v645_11),&(v650_6));
        drop(v645_11);
        let v645_13: Space = map_kernels::wrap(&(v645_12),&(*p1));
        drop(v645_12);
        let v645_14: Space = map_map_kernels::unite(&(v645_8),&(v645_13));
        drop(v645_13);
        join_wrapped_into(&mut v644_11_write,&((v645_14).read_zipper()),&[]);
        }
        v632_21_cursor.ascend(1);
      }
      drop(v644_11_write);
      drop(v644_6);
      map_map_kernels::compose(&(v633_10),&(v644_11))
    };
    drop(v633_10);
    let v633_13: Space = map_map_kernels::unite(&(v633_8),&(v633_12));
    join_wrapped_into(&mut v632_21_write,&((v633_13).read_zipper()),&[]);
    }
    v632_21_cursor.ascend(1);
  }
  drop(v632_21_cursor);
  drop(v632_21_write);
  (v632_21).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v651_15 = Space::new();
  let mut v651_15_write = v651_15.write_zipper();
  let mut v651_15_cursor = (*s0).read_zipper();
  let v651_15_origin = v651_15_cursor.path().len();
  for v651_15_byte in v651_15_cursor.child_mask().iter() {
    v651_15_cursor.descend_to_existing_byte(v651_15_byte);
    {
    let v652_2: Space = singleton(&v651_15_cursor.path()[v651_15_origin..(v651_15_origin + 1)]);
    let v652_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v652_2));
    let v652_4: Space = if map_kernels::has_head(&(v652_3)) { singleton(&[]) } else { Space::new() };
    drop(v652_3);
    let v652_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v652_4));
    drop(v652_4);
    let v652_8: Space = if (&(v652_5)).is_empty() { Space::new() } else {
      let v653_6: Path = concat_path(&(*p0),&v651_15_cursor.path()[v651_15_origin..(v651_15_origin + 1)]);
      let mut v653_7 = Space::new();
      let mut v653_7_write = v653_7.write_zipper();
      for v653_7_byte in v651_15_cursor.child_mask().iter() {
        v651_15_cursor.descend_to_existing_byte(v653_7_byte);
        {
        let v654_2: Space = singleton(&v651_15_cursor.path()[(v651_15_origin + 1)..(v651_15_origin + 2)]);
        let v654_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v654_2));
        let v654_4: Space = if map_kernels::has_head(&(v654_3)) { singleton(&[]) } else { Space::new() };
        drop(v654_3);
        let v654_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v654_4));
        drop(v654_4);
        let v654_8: Space = if (&(v654_5)).is_empty() { Space::new() } else {
          let v655_6: Path = concat_path(&(v653_6),&v651_15_cursor.path()[(v651_15_origin + 1)..(v651_15_origin + 2)]);
          let mut v655_7 = Space::new();
          let mut v655_7_write = v655_7.write_zipper();
          for v655_7_byte in v651_15_cursor.child_mask().iter() {
            v651_15_cursor.descend_to_existing_byte(v655_7_byte);
            {
            let v656_2: Space = singleton(&v651_15_cursor.path()[(v651_15_origin + 2)..(v651_15_origin + 3)]);
            let v656_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v656_2));
            let v656_4: Space = if map_kernels::has_head(&(v656_3)) { singleton(&[]) } else { Space::new() };
            drop(v656_3);
            let v656_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v656_4));
            drop(v656_4);
            let v656_8: Space = if (&(v656_5)).is_empty() { Space::new() } else {
              let v657_6: Path = concat_path(&(v655_6),&v651_15_cursor.path()[(v651_15_origin + 2)..(v651_15_origin + 3)]);
              let v657_7: Space = routine_46(c, &(v657_6), &(*p1), &v651_15_cursor);
              map_map_kernels::compose(&(v656_5),&(v657_7))
            };
            drop(v656_5);
            let v656_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v656_2));
            drop(v656_2);
            let v656_10: Space = if map_kernels::has_head(&(v656_9)) { singleton(&[]) } else { Space::new() };
            drop(v656_9);
            let v656_12: Space = if (&(v656_10)).is_empty() { Space::new() } else {
              let v658_6: Path = concat_path(&(v655_6),&v651_15_cursor.path()[(v651_15_origin + 2)..(v651_15_origin + 3)]);
              let v658_11: Space = routine_47(c, &(v658_6), &(*p1), &v651_15_cursor);
              drop(v658_6);
              map_map_kernels::compose(&(v656_10),&(v658_11))
            };
            drop(v656_10);
            let v656_13: Space = map_map_kernels::unite(&(v656_8),&(v656_12));
            join_wrapped_into(&mut v655_7_write,&((v656_13).read_zipper()),&[]);
            }
            v651_15_cursor.ascend(1);
          }
          drop(v655_7_write);
          map_map_kernels::compose(&(v654_5),&(v655_7))
        };
        drop(v654_5);
        let v654_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v654_2));
        drop(v654_2);
        let v654_10: Space = if map_kernels::has_head(&(v654_9)) { singleton(&[]) } else { Space::new() };
        drop(v654_9);
        let v654_12: Space = if (&(v654_10)).is_empty() { Space::new() } else {
          let v659_6: Path = concat_path(&(v653_6),&v651_15_cursor.path()[(v651_15_origin + 1)..(v651_15_origin + 2)]);
          let mut v659_11 = Space::new();
          let mut v659_11_write = v659_11.write_zipper();
          for v659_11_byte in v651_15_cursor.child_mask().iter() {
            v651_15_cursor.descend_to_existing_byte(v659_11_byte);
            {
            let v660_2: Space = singleton(&v651_15_cursor.path()[(v651_15_origin + 2)..(v651_15_origin + 3)]);
            let v660_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v660_2));
            let v660_4: Space = if map_kernels::has_head(&(v660_3)) { singleton(&[]) } else { Space::new() };
            drop(v660_3);
            let v660_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v660_4));
            drop(v660_4);
            let v660_8: Space = if (&(v660_5)).is_empty() { Space::new() } else {
              let v661_6: Path = concat_path(&(v659_6),&v651_15_cursor.path()[(v651_15_origin + 2)..(v651_15_origin + 3)]);
              let v661_7: Space = routine_46(c, &(v661_6), &(*p1), &v651_15_cursor);
              map_map_kernels::compose(&(v660_5),&(v661_7))
            };
            drop(v660_5);
            let v660_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v660_2));
            drop(v660_2);
            let v660_10: Space = if map_kernels::has_head(&(v660_9)) { singleton(&[]) } else { Space::new() };
            drop(v660_9);
            let v660_12: Space = if (&(v660_10)).is_empty() { Space::new() } else {
              let v662_6: Path = concat_path(&(v659_6),&v651_15_cursor.path()[(v651_15_origin + 2)..(v651_15_origin + 3)]);
              let v662_11: Space = routine_19(c, &(v662_6), &(*p1), &v651_15_cursor);
              drop(v662_6);
              map_map_kernels::compose(&(v660_10),&(v662_11))
            };
            drop(v660_10);
            let v660_13: Space = map_map_kernels::unite(&(v660_8),&(v660_12));
            join_wrapped_into(&mut v659_11_write,&((v660_13).read_zipper()),&[]);
            }
            v651_15_cursor.ascend(1);
          }
          drop(v659_11_write);
          drop(v659_6);
          map_map_kernels::compose(&(v654_10),&(v659_11))
        };
        drop(v654_10);
        let v654_13: Space = map_map_kernels::unite(&(v654_8),&(v654_12));
        join_wrapped_into(&mut v653_7_write,&((v654_13).read_zipper()),&[]);
        }
        v651_15_cursor.ascend(1);
      }
      drop(v653_7_write);
      map_map_kernels::compose(&(v652_5),&(v653_7))
    };
    drop(v652_5);
    let v652_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v652_2));
    drop(v652_2);
    let v652_10: Space = if map_kernels::has_head(&(v652_9)) { singleton(&[]) } else { Space::new() };
    drop(v652_9);
    let v652_11: Space = map_view_kernels::compose(&(v652_10),&v651_15_cursor);
    drop(v652_10);
    let v663_6: Path = concat_path(&(*p0),&v651_15_cursor.path()[v651_15_origin..(v651_15_origin + 1)]);
    let v652_12: Space = map_kernels::wrap(&(v652_11),&(v663_6));
    drop(v652_11);
    let v652_13: Space = map_kernels::wrap(&(v652_12),&(*p1));
    drop(v652_12);
    let v652_14: Space = map_map_kernels::unite(&(v652_8),&(v652_13));
    drop(v652_13);
    join_wrapped_into(&mut v651_15_write,&((v652_14).read_zipper()),&[]);
    }
    v651_15_cursor.ascend(1);
  }
  drop(v651_15_cursor);
  drop(v651_15_write);
  (v651_15).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v664_3: Space = Space::new();
  (v664_3).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v665_13 = Space::new();
  let mut v665_13_write = v665_13.write_zipper();
  let mut v665_13_cursor = (*s0).read_zipper();
  let v665_13_origin = v665_13_cursor.path().len();
  for v665_13_byte in v665_13_cursor.child_mask().iter() {
    v665_13_cursor.descend_to_existing_byte(v665_13_byte);
    {
    let v666_2: Space = singleton(&v665_13_cursor.path()[v665_13_origin..(v665_13_origin + 1)]);
    let v666_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v666_2));
    drop(v666_2);
    let v666_4: Space = if map_kernels::has_head(&(v666_3)) { singleton(&[]) } else { Space::new() };
    drop(v666_3);
    let v666_7: Space = if (&(v666_4)).is_empty() { Space::new() } else {
      let v667_5: Path = concat_path(&(*p0),&v665_13_cursor.path()[v665_13_origin..(v665_13_origin + 1)]);
      let mut v667_6 = Space::new();
      let mut v667_6_write = v667_6.write_zipper();
      for v667_6_byte in v665_13_cursor.child_mask().iter() {
        v665_13_cursor.descend_to_existing_byte(v667_6_byte);
        {
        let v668_2: Space = singleton(&v665_13_cursor.path()[(v665_13_origin + 1)..(v665_13_origin + 2)]);
        let v668_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v668_2));
        let v668_4: Space = if map_kernels::has_head(&(v668_3)) { singleton(&[]) } else { Space::new() };
        drop(v668_3);
        let v668_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v668_4));
        drop(v668_4);
        let v668_7: Space = if (&(v668_5)).is_empty() { Space::new() } else {
          let mut v669_6 = Space::new();
          let mut v669_6_write = v669_6.write_zipper();
          for v669_6_byte in v665_13_cursor.child_mask().iter() {
            v665_13_cursor.descend_to_existing_byte(v669_6_byte);
            {
            let v670_2: Space = singleton(&v665_13_cursor.path()[(v665_13_origin + 2)..(v665_13_origin + 3)]);
            let v670_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v670_2));
            let v670_4: Space = if map_kernels::has_head(&(v670_3)) { singleton(&[]) } else { Space::new() };
            drop(v670_3);
            let v670_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v670_4));
            drop(v670_4);
            let v670_8: Space = if (&(v670_5)).is_empty() { Space::new() } else {
              let v671_7: Space = routine_8(c, &v665_13_cursor.path()[(v665_13_origin + 1)..(v665_13_origin + 3)], &(v667_5), &v665_13_cursor, &(*s1));
              map_map_kernels::compose(&(v670_5),&(v671_7))
            };
            drop(v670_5);
            let v670_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v670_2));
            drop(v670_2);
            let v670_10: Space = if map_kernels::has_head(&(v670_9)) { singleton(&[]) } else { Space::new() };
            drop(v670_9);
            let v670_12: Space = if (&(v670_10)).is_empty() { Space::new() } else {
              let v672_11: Space = routine_9(c, &v665_13_cursor.path()[(v665_13_origin + 1)..(v665_13_origin + 3)], &(v667_5), &v665_13_cursor, &(*s1));
              map_map_kernels::compose(&(v670_10),&(v672_11))
            };
            drop(v670_10);
            let v670_13: Space = map_map_kernels::unite(&(v670_8),&(v670_12));
            join_wrapped_into(&mut v669_6_write,&((v670_13).read_zipper()),&[]);
            }
            v665_13_cursor.ascend(1);
          }
          drop(v669_6_write);
          map_map_kernels::compose(&(v668_5),&(v669_6))
        };
        drop(v668_5);
        let v668_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v668_2));
        drop(v668_2);
        let v668_9: Space = if map_kernels::has_head(&(v668_8)) { singleton(&[]) } else { Space::new() };
        drop(v668_8);
        let v668_11: Space = if (&(v668_9)).is_empty() { Space::new() } else {
          let mut v673_10 = Space::new();
          let mut v673_10_write = v673_10.write_zipper();
          for v673_10_byte in v665_13_cursor.child_mask().iter() {
            v665_13_cursor.descend_to_existing_byte(v673_10_byte);
            {
            let v674_2: Space = singleton(&v665_13_cursor.path()[(v665_13_origin + 2)..(v665_13_origin + 3)]);
            let v674_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v674_2));
            let v674_4: Space = if map_kernels::has_head(&(v674_3)) { singleton(&[]) } else { Space::new() };
            drop(v674_3);
            let v674_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v674_4));
            drop(v674_4);
            let v674_8: Space = if (&(v674_5)).is_empty() { Space::new() } else {
              let v675_7: Space = routine_8(c, &v665_13_cursor.path()[(v665_13_origin + 1)..(v665_13_origin + 3)], &(v667_5), &v665_13_cursor, &(*s1));
              map_map_kernels::compose(&(v674_5),&(v675_7))
            };
            drop(v674_5);
            let v674_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v674_2));
            drop(v674_2);
            let v674_10: Space = if map_kernels::has_head(&(v674_9)) { singleton(&[]) } else { Space::new() };
            drop(v674_9);
            let v674_12: Space = if (&(v674_10)).is_empty() { Space::new() } else {
              let v676_11: Space = routine_10(c, &v665_13_cursor.path()[(v665_13_origin + 1)..(v665_13_origin + 3)], &(v667_5), &v665_13_cursor, &(*s1));
              map_map_kernels::compose(&(v674_10),&(v676_11))
            };
            drop(v674_10);
            let v674_13: Space = map_map_kernels::unite(&(v674_8),&(v674_12));
            join_wrapped_into(&mut v673_10_write,&((v674_13).read_zipper()),&[]);
            }
            v665_13_cursor.ascend(1);
          }
          drop(v673_10_write);
          map_map_kernels::compose(&(v668_9),&(v673_10))
        };
        drop(v668_9);
        let v668_12: Space = map_map_kernels::unite(&(v668_7),&(v668_11));
        join_wrapped_into(&mut v667_6_write,&((v668_12).read_zipper()),&[]);
        }
        v665_13_cursor.ascend(1);
      }
      drop(v667_6_write);
      drop(v667_5);
      map_map_kernels::compose(&(v666_4),&(v667_6))
    };
    drop(v666_4);
    join_wrapped_into(&mut v665_13_write,&((v666_7).read_zipper()),&[]);
    }
    v665_13_cursor.ascend(1);
  }
  drop(v665_13_cursor);
  drop(v665_13_write);
  (v665_13).clone()
}

fn routine_36(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v677_28 = Space::new();
  let mut v677_28_write = v677_28.write_zipper();
  let mut v677_28_cursor = (*s0).read_zipper();
  let v677_28_origin = v677_28_cursor.path().len();
  for v677_28_byte in v677_28_cursor.child_mask().iter() {
    v677_28_cursor.descend_to_existing_byte(v677_28_byte);
    {
    let v678_2: Space = singleton(&v677_28_cursor.path()[v677_28_origin..(v677_28_origin + 1)]);
    let v678_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v678_2));
    let v678_4: Space = if map_kernels::has_head(&(v678_3)) { singleton(&[]) } else { Space::new() };
    drop(v678_3);
    let v678_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v678_4));
    drop(v678_4);
    let v678_8: Space = if (&(v678_5)).is_empty() { Space::new() } else {
      let v679_6: Path = concat_path(&(*p0),&v677_28_cursor.path()[v677_28_origin..(v677_28_origin + 1)]);
      let mut v679_7 = Space::new();
      let mut v679_7_write = v679_7.write_zipper();
      for v679_7_byte in v677_28_cursor.child_mask().iter() {
        v677_28_cursor.descend_to_existing_byte(v679_7_byte);
        {
        let v680_2: Space = singleton(&v677_28_cursor.path()[(v677_28_origin + 1)..(v677_28_origin + 2)]);
        let v680_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v680_2));
        let v680_4: Space = if map_kernels::has_head(&(v680_3)) { singleton(&[]) } else { Space::new() };
        drop(v680_3);
        let v680_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v680_4));
        drop(v680_4);
        let v680_8: Space = if (&(v680_5)).is_empty() { Space::new() } else {
          let v681_6: Path = concat_path(&(v679_6),&v677_28_cursor.path()[(v677_28_origin + 1)..(v677_28_origin + 2)]);
          let mut v681_7 = Space::new();
          let mut v681_7_write = v681_7.write_zipper();
          for v681_7_byte in v677_28_cursor.child_mask().iter() {
            v677_28_cursor.descend_to_existing_byte(v681_7_byte);
            {
            let v682_2: Space = singleton(&v677_28_cursor.path()[(v677_28_origin + 2)..(v677_28_origin + 3)]);
            let v682_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v682_2));
            let v682_4: Space = if map_kernels::has_head(&(v682_3)) { singleton(&[]) } else { Space::new() };
            drop(v682_3);
            let v682_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v682_4));
            drop(v682_4);
            let v682_8: Space = if (&(v682_5)).is_empty() { Space::new() } else {
              let v683_6: Path = concat_path(&(v681_6),&v677_28_cursor.path()[(v677_28_origin + 2)..(v677_28_origin + 3)]);
              let v683_7: Space = routine_48(c, &(v683_6), &(*p1), &v677_28_cursor, &(*s1));
              map_map_kernels::compose(&(v682_5),&(v683_7))
            };
            drop(v682_5);
            let v682_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v682_2));
            drop(v682_2);
            let v682_10: Space = if map_kernels::has_head(&(v682_9)) { singleton(&[]) } else { Space::new() };
            drop(v682_9);
            let v682_12: Space = if (&(v682_10)).is_empty() { Space::new() } else {
              let v684_6: Path = concat_path(&(v681_6),&v677_28_cursor.path()[(v677_28_origin + 2)..(v677_28_origin + 3)]);
              let v684_11: Space = routine_49(c, &(v684_6), &(*p1), &v677_28_cursor, &(*s1));
              drop(v684_6);
              map_map_kernels::compose(&(v682_10),&(v684_11))
            };
            drop(v682_10);
            let v682_13: Space = map_map_kernels::unite(&(v682_8),&(v682_12));
            join_wrapped_into(&mut v681_7_write,&((v682_13).read_zipper()),&[]);
            }
            v677_28_cursor.ascend(1);
          }
          drop(v681_7_write);
          map_map_kernels::compose(&(v680_5),&(v681_7))
        };
        drop(v680_5);
        let v680_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v680_2));
        drop(v680_2);
        let v680_10: Space = if map_kernels::has_head(&(v680_9)) { singleton(&[]) } else { Space::new() };
        drop(v680_9);
        let v680_12: Space = if (&(v680_10)).is_empty() { Space::new() } else {
          let v685_6: Path = concat_path(&(v679_6),&v677_28_cursor.path()[(v677_28_origin + 1)..(v677_28_origin + 2)]);
          let mut v685_11 = Space::new();
          let mut v685_11_write = v685_11.write_zipper();
          for v685_11_byte in v677_28_cursor.child_mask().iter() {
            v677_28_cursor.descend_to_existing_byte(v685_11_byte);
            {
            let v686_2: Space = singleton(&v677_28_cursor.path()[(v677_28_origin + 2)..(v677_28_origin + 3)]);
            let v686_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v686_2));
            let v686_4: Space = if map_kernels::has_head(&(v686_3)) { singleton(&[]) } else { Space::new() };
            drop(v686_3);
            let v686_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v686_4));
            drop(v686_4);
            let v686_8: Space = if (&(v686_5)).is_empty() { Space::new() } else {
              let v687_6: Path = concat_path(&(v685_6),&v677_28_cursor.path()[(v677_28_origin + 2)..(v677_28_origin + 3)]);
              let v687_7: Space = routine_48(c, &(v687_6), &(*p1), &v677_28_cursor, &(*s1));
              map_map_kernels::compose(&(v686_5),&(v687_7))
            };
            drop(v686_5);
            let v686_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v686_2));
            drop(v686_2);
            let v686_10: Space = if map_kernels::has_head(&(v686_9)) { singleton(&[]) } else { Space::new() };
            drop(v686_9);
            let v686_12: Space = if (&(v686_10)).is_empty() { Space::new() } else {
              let v688_6: Path = concat_path(&(v685_6),&v677_28_cursor.path()[(v677_28_origin + 2)..(v677_28_origin + 3)]);
              let v688_11: Space = routine_10(c, &(v688_6), &(*p1), &v677_28_cursor, &(*s1));
              drop(v688_6);
              map_map_kernels::compose(&(v686_10),&(v688_11))
            };
            drop(v686_10);
            let v686_13: Space = map_map_kernels::unite(&(v686_8),&(v686_12));
            join_wrapped_into(&mut v685_11_write,&((v686_13).read_zipper()),&[]);
            }
            v677_28_cursor.ascend(1);
          }
          drop(v685_11_write);
          drop(v685_6);
          map_map_kernels::compose(&(v680_10),&(v685_11))
        };
        drop(v680_10);
        let v680_13: Space = map_map_kernels::unite(&(v680_8),&(v680_12));
        join_wrapped_into(&mut v679_7_write,&((v680_13).read_zipper()),&[]);
        }
        v677_28_cursor.ascend(1);
      }
      drop(v679_7_write);
      map_map_kernels::compose(&(v678_5),&(v679_7))
    };
    drop(v678_5);
    let v678_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v678_2));
    drop(v678_2);
    let v678_10: Space = if map_kernels::has_head(&(v678_9)) { singleton(&[]) } else { Space::new() };
    drop(v678_9);
    let v678_13: Space = if (&(v678_10)).is_empty() { Space::new() } else {
      let v689_6: Path = concat_path(&(*p0),&v677_28_cursor.path()[v677_28_origin..(v677_28_origin + 1)]);
      let mut v689_12 = Space::new();
      let mut v689_12_write = v689_12.write_zipper();
      for v689_12_byte in v677_28_cursor.child_mask().iter() {
        v677_28_cursor.descend_to_existing_byte(v689_12_byte);
        {
        let v690_2: Space = singleton(&v677_28_cursor.path()[(v677_28_origin + 1)..(v677_28_origin + 2)]);
        let v690_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v690_2));
        let v690_4: Space = if map_kernels::has_head(&(v690_3)) { singleton(&[]) } else { Space::new() };
        drop(v690_3);
        let v690_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v690_4));
        drop(v690_4);
        let v690_8: Space = if (&(v690_5)).is_empty() { Space::new() } else {
          let v691_6: Path = concat_path(&(v689_6),&v677_28_cursor.path()[(v677_28_origin + 1)..(v677_28_origin + 2)]);
          let mut v691_7 = Space::new();
          let mut v691_7_write = v691_7.write_zipper();
          for v691_7_byte in v677_28_cursor.child_mask().iter() {
            v677_28_cursor.descend_to_existing_byte(v691_7_byte);
            {
            let v692_2: Space = singleton(&v677_28_cursor.path()[(v677_28_origin + 2)..(v677_28_origin + 3)]);
            let v692_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v692_2));
            let v692_4: Space = if map_kernels::has_head(&(v692_3)) { singleton(&[]) } else { Space::new() };
            drop(v692_3);
            let v692_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v692_4));
            drop(v692_4);
            let v692_8: Space = if (&(v692_5)).is_empty() { Space::new() } else {
              let v693_6: Path = concat_path(&(v691_6),&v677_28_cursor.path()[(v677_28_origin + 2)..(v677_28_origin + 3)]);
              let v693_7: Space = routine_48(c, &(v693_6), &(*p1), &v677_28_cursor, &(*s1));
              map_map_kernels::compose(&(v692_5),&(v693_7))
            };
            drop(v692_5);
            let v692_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v692_2));
            drop(v692_2);
            let v692_10: Space = if map_kernels::has_head(&(v692_9)) { singleton(&[]) } else { Space::new() };
            drop(v692_9);
            let v692_12: Space = if (&(v692_10)).is_empty() { Space::new() } else {
              let v694_6: Path = concat_path(&(v691_6),&v677_28_cursor.path()[(v677_28_origin + 2)..(v677_28_origin + 3)]);
              let v694_11: Space = routine_49(c, &(v694_6), &(*p1), &v677_28_cursor, &(*s1));
              drop(v694_6);
              map_map_kernels::compose(&(v692_10),&(v694_11))
            };
            drop(v692_10);
            let v692_13: Space = map_map_kernels::unite(&(v692_8),&(v692_12));
            join_wrapped_into(&mut v691_7_write,&((v692_13).read_zipper()),&[]);
            }
            v677_28_cursor.ascend(1);
          }
          drop(v691_7_write);
          drop(v691_6);
          map_map_kernels::compose(&(v690_5),&(v691_7))
        };
        drop(v690_5);
        let v690_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v690_2));
        drop(v690_2);
        let v690_10: Space = if map_kernels::has_head(&(v690_9)) { singleton(&[]) } else { Space::new() };
        drop(v690_9);
        let v690_13: Space = if (&(v690_10)).is_empty() { Space::new() } else {
          let mut v695_12 = Space::new();
          let mut v695_12_write = v695_12.write_zipper();
          let mut v695_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v677_28_cursor.path()[v677_28_origin..(v677_28_origin + 1)]),&v677_28_cursor.path()[(v677_28_origin + 1)..(v677_28_origin + 2)]);
          let v695_12_origin = v695_12_cursor.path().len();
          for v695_12_byte in v695_12_cursor.child_mask().iter() {
            v695_12_cursor.descend_to_existing_byte(v695_12_byte);
            {
            let v696_2: Space = singleton(&v695_12_cursor.path()[v695_12_origin..(v695_12_origin + 1)]);
            let v696_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v696_2));
            let v696_4: Space = if map_kernels::has_head(&(v696_3)) { singleton(&[]) } else { Space::new() };
            drop(v696_3);
            let v696_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v696_4));
            drop(v696_4);
            let v696_7: Space = if (&(v696_5)).is_empty() { Space::new() } else {
              let v697_6: Space = routine_13(c, &v695_12_cursor.path()[v695_12_origin..(v695_12_origin + 1)], &(*p1), &v695_12_cursor);
              map_map_kernels::compose(&(v696_5),&(v697_6))
            };
            drop(v696_5);
            let v696_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v696_2));
            drop(v696_2);
            let v696_9: Space = if map_kernels::has_head(&(v696_8)) { singleton(&[]) } else { Space::new() };
            drop(v696_8);
            let v696_11: Space = if (&(v696_9)).is_empty() { Space::new() } else {
              let v698_10: Space = routine_14(c, &v695_12_cursor.path()[v695_12_origin..(v695_12_origin + 1)], &(*p1), &v695_12_cursor);
              map_map_kernels::compose(&(v696_9),&(v698_10))
            };
            drop(v696_9);
            let v696_12: Space = map_map_kernels::unite(&(v696_7),&(v696_11));
            join_wrapped_into(&mut v695_12_write,&((v696_12).read_zipper()),&[]);
            }
            v695_12_cursor.ascend(1);
          }
          drop(v695_12_cursor);
          drop(v695_12_write);
          map_map_kernels::compose(&(v690_10),&(v695_12))
        };
        drop(v690_10);
        let v690_14: Space = map_map_kernels::unite(&(v690_8),&(v690_13));
        join_wrapped_into(&mut v689_12_write,&((v690_14).read_zipper()),&[]);
        }
        v677_28_cursor.ascend(1);
      }
      drop(v689_12_write);
      drop(v689_6);
      map_map_kernels::compose(&(v678_10),&(v689_12))
    };
    drop(v678_10);
    let v678_14: Space = map_map_kernels::unite(&(v678_8),&(v678_13));
    join_wrapped_into(&mut v677_28_write,&((v678_14).read_zipper()),&[]);
    }
    v677_28_cursor.ascend(1);
  }
  drop(v677_28_cursor);
  drop(v677_28_write);
  (v677_28).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v699_28 = Space::new();
  let mut v699_28_write = v699_28.write_zipper();
  let mut v699_28_cursor = (*s0).read_zipper();
  let v699_28_origin = v699_28_cursor.path().len();
  for v699_28_byte in v699_28_cursor.child_mask().iter() {
    v699_28_cursor.descend_to_existing_byte(v699_28_byte);
    {
    let v700_2: Space = singleton(&v699_28_cursor.path()[v699_28_origin..(v699_28_origin + 1)]);
    let v700_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v700_2));
    let v700_4: Space = if map_kernels::has_head(&(v700_3)) { singleton(&[]) } else { Space::new() };
    drop(v700_3);
    let v700_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v700_4));
    drop(v700_4);
    let v700_8: Space = if (&(v700_5)).is_empty() { Space::new() } else {
      let v701_6: Path = concat_path(&(*p0),&v699_28_cursor.path()[v699_28_origin..(v699_28_origin + 1)]);
      let mut v701_7 = Space::new();
      let mut v701_7_write = v701_7.write_zipper();
      for v701_7_byte in v699_28_cursor.child_mask().iter() {
        v699_28_cursor.descend_to_existing_byte(v701_7_byte);
        {
        let v702_2: Space = singleton(&v699_28_cursor.path()[(v699_28_origin + 1)..(v699_28_origin + 2)]);
        let v702_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v702_2));
        let v702_4: Space = if map_kernels::has_head(&(v702_3)) { singleton(&[]) } else { Space::new() };
        drop(v702_3);
        let v702_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v702_4));
        drop(v702_4);
        let v702_8: Space = if (&(v702_5)).is_empty() { Space::new() } else {
          let v703_6: Path = concat_path(&(v701_6),&v699_28_cursor.path()[(v699_28_origin + 1)..(v699_28_origin + 2)]);
          let mut v703_7 = Space::new();
          let mut v703_7_write = v703_7.write_zipper();
          for v703_7_byte in v699_28_cursor.child_mask().iter() {
            v699_28_cursor.descend_to_existing_byte(v703_7_byte);
            {
            let v704_2: Space = singleton(&v699_28_cursor.path()[(v699_28_origin + 2)..(v699_28_origin + 3)]);
            let v704_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v704_2));
            let v704_4: Space = if map_kernels::has_head(&(v704_3)) { singleton(&[]) } else { Space::new() };
            drop(v704_3);
            let v704_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v704_4));
            drop(v704_4);
            let v704_8: Space = if (&(v704_5)).is_empty() { Space::new() } else {
              let v705_6: Path = concat_path(&(v703_6),&v699_28_cursor.path()[(v699_28_origin + 2)..(v699_28_origin + 3)]);
              let v705_7: Space = routine_48(c, &(v705_6), &(*p1), &v699_28_cursor, &(*s1));
              map_map_kernels::compose(&(v704_5),&(v705_7))
            };
            drop(v704_5);
            let v704_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v704_2));
            drop(v704_2);
            let v704_10: Space = if map_kernels::has_head(&(v704_9)) { singleton(&[]) } else { Space::new() };
            drop(v704_9);
            let v704_12: Space = if (&(v704_10)).is_empty() { Space::new() } else {
              let v706_6: Path = concat_path(&(v703_6),&v699_28_cursor.path()[(v699_28_origin + 2)..(v699_28_origin + 3)]);
              let v706_11: Space = routine_49(c, &(v706_6), &(*p1), &v699_28_cursor, &(*s1));
              drop(v706_6);
              map_map_kernels::compose(&(v704_10),&(v706_11))
            };
            drop(v704_10);
            let v704_13: Space = map_map_kernels::unite(&(v704_8),&(v704_12));
            join_wrapped_into(&mut v703_7_write,&((v704_13).read_zipper()),&[]);
            }
            v699_28_cursor.ascend(1);
          }
          drop(v703_7_write);
          map_map_kernels::compose(&(v702_5),&(v703_7))
        };
        drop(v702_5);
        let v702_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v702_2));
        drop(v702_2);
        let v702_10: Space = if map_kernels::has_head(&(v702_9)) { singleton(&[]) } else { Space::new() };
        drop(v702_9);
        let v702_12: Space = if (&(v702_10)).is_empty() { Space::new() } else {
          let v707_6: Path = concat_path(&(v701_6),&v699_28_cursor.path()[(v699_28_origin + 1)..(v699_28_origin + 2)]);
          let mut v707_11 = Space::new();
          let mut v707_11_write = v707_11.write_zipper();
          for v707_11_byte in v699_28_cursor.child_mask().iter() {
            v699_28_cursor.descend_to_existing_byte(v707_11_byte);
            {
            let v708_2: Space = singleton(&v699_28_cursor.path()[(v699_28_origin + 2)..(v699_28_origin + 3)]);
            let v708_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v708_2));
            let v708_4: Space = if map_kernels::has_head(&(v708_3)) { singleton(&[]) } else { Space::new() };
            drop(v708_3);
            let v708_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v708_4));
            drop(v708_4);
            let v708_8: Space = if (&(v708_5)).is_empty() { Space::new() } else {
              let v709_6: Path = concat_path(&(v707_6),&v699_28_cursor.path()[(v699_28_origin + 2)..(v699_28_origin + 3)]);
              let v709_7: Space = routine_48(c, &(v709_6), &(*p1), &v699_28_cursor, &(*s1));
              map_map_kernels::compose(&(v708_5),&(v709_7))
            };
            drop(v708_5);
            let v708_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v708_2));
            drop(v708_2);
            let v708_10: Space = if map_kernels::has_head(&(v708_9)) { singleton(&[]) } else { Space::new() };
            drop(v708_9);
            let v708_12: Space = if (&(v708_10)).is_empty() { Space::new() } else {
              let v710_6: Path = concat_path(&(v707_6),&v699_28_cursor.path()[(v699_28_origin + 2)..(v699_28_origin + 3)]);
              let v710_11: Space = routine_10(c, &(v710_6), &(*p1), &v699_28_cursor, &(*s1));
              drop(v710_6);
              map_map_kernels::compose(&(v708_10),&(v710_11))
            };
            drop(v708_10);
            let v708_13: Space = map_map_kernels::unite(&(v708_8),&(v708_12));
            join_wrapped_into(&mut v707_11_write,&((v708_13).read_zipper()),&[]);
            }
            v699_28_cursor.ascend(1);
          }
          drop(v707_11_write);
          drop(v707_6);
          map_map_kernels::compose(&(v702_10),&(v707_11))
        };
        drop(v702_10);
        let v702_13: Space = map_map_kernels::unite(&(v702_8),&(v702_12));
        join_wrapped_into(&mut v701_7_write,&((v702_13).read_zipper()),&[]);
        }
        v699_28_cursor.ascend(1);
      }
      drop(v701_7_write);
      drop(v701_6);
      map_map_kernels::compose(&(v700_5),&(v701_7))
    };
    drop(v700_5);
    let v700_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v700_2));
    drop(v700_2);
    let v700_10: Space = if map_kernels::has_head(&(v700_9)) { singleton(&[]) } else { Space::new() };
    drop(v700_9);
    let v700_13: Space = if (&(v700_10)).is_empty() { Space::new() } else {
      let mut v711_12 = Space::new();
      let mut v711_12_write = v711_12.write_zipper();
      let mut v711_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v699_28_cursor.path()[v699_28_origin..(v699_28_origin + 1)]);
      let v711_12_origin = v711_12_cursor.path().len();
      for v711_12_byte in v711_12_cursor.child_mask().iter() {
        v711_12_cursor.descend_to_existing_byte(v711_12_byte);
        {
        let v712_2: Space = singleton(&v711_12_cursor.path()[v711_12_origin..(v711_12_origin + 1)]);
        let v712_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v712_2));
        let v712_4: Space = if map_kernels::has_head(&(v712_3)) { singleton(&[]) } else { Space::new() };
        drop(v712_3);
        let v712_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v712_4));
        drop(v712_4);
        let v712_7: Space = if (&(v712_5)).is_empty() { Space::new() } else {
          let mut v713_6 = Space::new();
          let mut v713_6_write = v713_6.write_zipper();
          for v713_6_byte in v711_12_cursor.child_mask().iter() {
            v711_12_cursor.descend_to_existing_byte(v713_6_byte);
            {
            let v714_2: Space = singleton(&v711_12_cursor.path()[(v711_12_origin + 1)..(v711_12_origin + 2)]);
            let v714_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v714_2));
            let v714_4: Space = if map_kernels::has_head(&(v714_3)) { singleton(&[]) } else { Space::new() };
            drop(v714_3);
            let v714_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v714_4));
            drop(v714_4);
            let v714_8: Space = if (&(v714_5)).is_empty() { Space::new() } else {
              let v715_7: Space = routine_17(c, &v711_12_cursor.path()[v711_12_origin..(v711_12_origin + 2)], &(*p1), &v711_12_cursor);
              map_map_kernels::compose(&(v714_5),&(v715_7))
            };
            drop(v714_5);
            let v714_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v714_2));
            drop(v714_2);
            let v714_10: Space = if map_kernels::has_head(&(v714_9)) { singleton(&[]) } else { Space::new() };
            drop(v714_9);
            let v714_12: Space = if (&(v714_10)).is_empty() { Space::new() } else {
              let v716_11: Space = routine_18(c, &v711_12_cursor.path()[v711_12_origin..(v711_12_origin + 2)], &(*p1), &v711_12_cursor);
              map_map_kernels::compose(&(v714_10),&(v716_11))
            };
            drop(v714_10);
            let v714_13: Space = map_map_kernels::unite(&(v714_8),&(v714_12));
            join_wrapped_into(&mut v713_6_write,&((v714_13).read_zipper()),&[]);
            }
            v711_12_cursor.ascend(1);
          }
          drop(v713_6_write);
          map_map_kernels::compose(&(v712_5),&(v713_6))
        };
        drop(v712_5);
        let v712_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v712_2));
        drop(v712_2);
        let v712_9: Space = if map_kernels::has_head(&(v712_8)) { singleton(&[]) } else { Space::new() };
        drop(v712_8);
        let v712_11: Space = if (&(v712_9)).is_empty() { Space::new() } else {
          let mut v717_10 = Space::new();
          let mut v717_10_write = v717_10.write_zipper();
          for v717_10_byte in v711_12_cursor.child_mask().iter() {
            v711_12_cursor.descend_to_existing_byte(v717_10_byte);
            {
            let v718_2: Space = singleton(&v711_12_cursor.path()[(v711_12_origin + 1)..(v711_12_origin + 2)]);
            let v718_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v718_2));
            let v718_4: Space = if map_kernels::has_head(&(v718_3)) { singleton(&[]) } else { Space::new() };
            drop(v718_3);
            let v718_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v718_4));
            drop(v718_4);
            let v718_8: Space = if (&(v718_5)).is_empty() { Space::new() } else {
              let v719_7: Space = routine_17(c, &v711_12_cursor.path()[v711_12_origin..(v711_12_origin + 2)], &(*p1), &v711_12_cursor);
              map_map_kernels::compose(&(v718_5),&(v719_7))
            };
            drop(v718_5);
            let v718_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v718_2));
            drop(v718_2);
            let v718_10: Space = if map_kernels::has_head(&(v718_9)) { singleton(&[]) } else { Space::new() };
            drop(v718_9);
            let v718_12: Space = if (&(v718_10)).is_empty() { Space::new() } else {
              let v720_11: Space = routine_19(c, &v711_12_cursor.path()[v711_12_origin..(v711_12_origin + 2)], &(*p1), &v711_12_cursor);
              map_map_kernels::compose(&(v718_10),&(v720_11))
            };
            drop(v718_10);
            let v718_13: Space = map_map_kernels::unite(&(v718_8),&(v718_12));
            join_wrapped_into(&mut v717_10_write,&((v718_13).read_zipper()),&[]);
            }
            v711_12_cursor.ascend(1);
          }
          drop(v717_10_write);
          map_map_kernels::compose(&(v712_9),&(v717_10))
        };
        drop(v712_9);
        let v712_12: Space = map_map_kernels::unite(&(v712_7),&(v712_11));
        join_wrapped_into(&mut v711_12_write,&((v712_12).read_zipper()),&[]);
        }
        v711_12_cursor.ascend(1);
      }
      drop(v711_12_cursor);
      drop(v711_12_write);
      map_map_kernels::compose(&(v700_10),&(v711_12))
    };
    drop(v700_10);
    let v700_14: Space = map_map_kernels::unite(&(v700_8),&(v700_13));
    join_wrapped_into(&mut v699_28_write,&((v700_14).read_zipper()),&[]);
    }
    v699_28_cursor.ascend(1);
  }
  drop(v699_28_cursor);
  drop(v699_28_write);
  (v699_28).clone()
}

fn routine_38(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v721_21 = Space::new();
  let mut v721_21_write = v721_21.write_zipper();
  let mut v721_21_cursor = (*s0).read_zipper();
  let v721_21_origin = v721_21_cursor.path().len();
  for v721_21_byte in v721_21_cursor.child_mask().iter() {
    v721_21_cursor.descend_to_existing_byte(v721_21_byte);
    {
    let v722_2: Space = singleton(&v721_21_cursor.path()[v721_21_origin..(v721_21_origin + 1)]);
    let v722_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v722_2));
    let v722_4: Space = if map_kernels::has_head(&(v722_3)) { singleton(&[]) } else { Space::new() };
    drop(v722_3);
    let v722_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v722_4));
    drop(v722_4);
    let v722_8: Space = if (&(v722_5)).is_empty() { Space::new() } else {
      let v723_6: Path = concat_path(&(*p0),&v721_21_cursor.path()[v721_21_origin..(v721_21_origin + 1)]);
      let mut v723_7 = Space::new();
      let mut v723_7_write = v723_7.write_zipper();
      for v723_7_byte in v721_21_cursor.child_mask().iter() {
        v721_21_cursor.descend_to_existing_byte(v723_7_byte);
        {
        let v724_2: Space = singleton(&v721_21_cursor.path()[(v721_21_origin + 1)..(v721_21_origin + 2)]);
        let v724_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v724_2));
        let v724_4: Space = if map_kernels::has_head(&(v724_3)) { singleton(&[]) } else { Space::new() };
        drop(v724_3);
        let v724_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v724_4));
        drop(v724_4);
        let v724_8: Space = if (&(v724_5)).is_empty() { Space::new() } else {
          let v725_6: Path = concat_path(&(v723_6),&v721_21_cursor.path()[(v721_21_origin + 1)..(v721_21_origin + 2)]);
          let mut v725_7 = Space::new();
          let mut v725_7_write = v725_7.write_zipper();
          for v725_7_byte in v721_21_cursor.child_mask().iter() {
            v721_21_cursor.descend_to_existing_byte(v725_7_byte);
            {
            let v726_2: Space = singleton(&v721_21_cursor.path()[(v721_21_origin + 2)..(v721_21_origin + 3)]);
            let v726_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v726_2));
            let v726_4: Space = if map_kernels::has_head(&(v726_3)) { singleton(&[]) } else { Space::new() };
            drop(v726_3);
            let v726_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v726_4));
            drop(v726_4);
            let v726_8: Space = if (&(v726_5)).is_empty() { Space::new() } else {
              let v727_6: Path = concat_path(&(v725_6),&v721_21_cursor.path()[(v721_21_origin + 2)..(v721_21_origin + 3)]);
              let v727_7: Space = routine_50(c, &(v727_6), &(*p1), &v721_21_cursor);
              map_map_kernels::compose(&(v726_5),&(v727_7))
            };
            drop(v726_5);
            let v726_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v726_2));
            drop(v726_2);
            let v726_10: Space = if map_kernels::has_head(&(v726_9)) { singleton(&[]) } else { Space::new() };
            drop(v726_9);
            let v726_12: Space = if (&(v726_10)).is_empty() { Space::new() } else {
              let v728_6: Path = concat_path(&(v725_6),&v721_21_cursor.path()[(v721_21_origin + 2)..(v721_21_origin + 3)]);
              let v728_11: Space = routine_51(c, &(v728_6), &(*p1), &v721_21_cursor);
              drop(v728_6);
              map_map_kernels::compose(&(v726_10),&(v728_11))
            };
            drop(v726_10);
            let v726_13: Space = map_map_kernels::unite(&(v726_8),&(v726_12));
            join_wrapped_into(&mut v725_7_write,&((v726_13).read_zipper()),&[]);
            }
            v721_21_cursor.ascend(1);
          }
          drop(v725_7_write);
          map_map_kernels::compose(&(v724_5),&(v725_7))
        };
        drop(v724_5);
        let v724_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v724_2));
        drop(v724_2);
        let v724_10: Space = if map_kernels::has_head(&(v724_9)) { singleton(&[]) } else { Space::new() };
        drop(v724_9);
        let v724_12: Space = if (&(v724_10)).is_empty() { Space::new() } else {
          let v729_6: Path = concat_path(&(v723_6),&v721_21_cursor.path()[(v721_21_origin + 1)..(v721_21_origin + 2)]);
          let mut v729_11 = Space::new();
          let mut v729_11_write = v729_11.write_zipper();
          for v729_11_byte in v721_21_cursor.child_mask().iter() {
            v721_21_cursor.descend_to_existing_byte(v729_11_byte);
            {
            let v730_2: Space = singleton(&v721_21_cursor.path()[(v721_21_origin + 2)..(v721_21_origin + 3)]);
            let v730_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v730_2));
            let v730_4: Space = if map_kernels::has_head(&(v730_3)) { singleton(&[]) } else { Space::new() };
            drop(v730_3);
            let v730_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v730_4));
            drop(v730_4);
            let v730_8: Space = if (&(v730_5)).is_empty() { Space::new() } else {
              let v731_6: Path = concat_path(&(v729_6),&v721_21_cursor.path()[(v721_21_origin + 2)..(v721_21_origin + 3)]);
              let v731_7: Space = routine_50(c, &(v731_6), &(*p1), &v721_21_cursor);
              map_map_kernels::compose(&(v730_5),&(v731_7))
            };
            drop(v730_5);
            let v730_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v730_2));
            drop(v730_2);
            let v730_10: Space = if map_kernels::has_head(&(v730_9)) { singleton(&[]) } else { Space::new() };
            drop(v730_9);
            let v730_12: Space = if (&(v730_10)).is_empty() { Space::new() } else {
              let v732_6: Path = concat_path(&(v729_6),&v721_21_cursor.path()[(v721_21_origin + 2)..(v721_21_origin + 3)]);
              let v732_11: Space = routine_19(c, &(v732_6), &(*p1), &v721_21_cursor);
              drop(v732_6);
              map_map_kernels::compose(&(v730_10),&(v732_11))
            };
            drop(v730_10);
            let v730_13: Space = map_map_kernels::unite(&(v730_8),&(v730_12));
            join_wrapped_into(&mut v729_11_write,&((v730_13).read_zipper()),&[]);
            }
            v721_21_cursor.ascend(1);
          }
          drop(v729_11_write);
          drop(v729_6);
          map_map_kernels::compose(&(v724_10),&(v729_11))
        };
        drop(v724_10);
        let v724_13: Space = map_map_kernels::unite(&(v724_8),&(v724_12));
        join_wrapped_into(&mut v723_7_write,&((v724_13).read_zipper()),&[]);
        }
        v721_21_cursor.ascend(1);
      }
      drop(v723_7_write);
      map_map_kernels::compose(&(v722_5),&(v723_7))
    };
    drop(v722_5);
    let v722_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v722_2));
    drop(v722_2);
    let v722_10: Space = if map_kernels::has_head(&(v722_9)) { singleton(&[]) } else { Space::new() };
    drop(v722_9);
    let v722_12: Space = if (&(v722_10)).is_empty() { Space::new() } else {
      let v733_6: Path = concat_path(&(*p0),&v721_21_cursor.path()[v721_21_origin..(v721_21_origin + 1)]);
      let mut v733_11 = Space::new();
      let mut v733_11_write = v733_11.write_zipper();
      for v733_11_byte in v721_21_cursor.child_mask().iter() {
        v721_21_cursor.descend_to_existing_byte(v733_11_byte);
        {
        let v734_2: Space = singleton(&v721_21_cursor.path()[(v721_21_origin + 1)..(v721_21_origin + 2)]);
        let v734_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v734_2));
        let v734_4: Space = if map_kernels::has_head(&(v734_3)) { singleton(&[]) } else { Space::new() };
        drop(v734_3);
        let v734_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v734_4));
        drop(v734_4);
        let v734_8: Space = if (&(v734_5)).is_empty() { Space::new() } else {
          let v735_6: Path = concat_path(&(v733_6),&v721_21_cursor.path()[(v721_21_origin + 1)..(v721_21_origin + 2)]);
          let mut v735_7 = Space::new();
          let mut v735_7_write = v735_7.write_zipper();
          for v735_7_byte in v721_21_cursor.child_mask().iter() {
            v721_21_cursor.descend_to_existing_byte(v735_7_byte);
            {
            let v736_2: Space = singleton(&v721_21_cursor.path()[(v721_21_origin + 2)..(v721_21_origin + 3)]);
            let v736_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v736_2));
            let v736_4: Space = if map_kernels::has_head(&(v736_3)) { singleton(&[]) } else { Space::new() };
            drop(v736_3);
            let v736_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v736_4));
            drop(v736_4);
            let v736_8: Space = if (&(v736_5)).is_empty() { Space::new() } else {
              let v737_6: Path = concat_path(&(v735_6),&v721_21_cursor.path()[(v721_21_origin + 2)..(v721_21_origin + 3)]);
              let v737_7: Space = routine_50(c, &(v737_6), &(*p1), &v721_21_cursor);
              map_map_kernels::compose(&(v736_5),&(v737_7))
            };
            drop(v736_5);
            let v736_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v736_2));
            drop(v736_2);
            let v736_10: Space = if map_kernels::has_head(&(v736_9)) { singleton(&[]) } else { Space::new() };
            drop(v736_9);
            let v736_12: Space = if (&(v736_10)).is_empty() { Space::new() } else {
              let v738_6: Path = concat_path(&(v735_6),&v721_21_cursor.path()[(v721_21_origin + 2)..(v721_21_origin + 3)]);
              let v738_11: Space = routine_51(c, &(v738_6), &(*p1), &v721_21_cursor);
              drop(v738_6);
              map_map_kernels::compose(&(v736_10),&(v738_11))
            };
            drop(v736_10);
            let v736_13: Space = map_map_kernels::unite(&(v736_8),&(v736_12));
            join_wrapped_into(&mut v735_7_write,&((v736_13).read_zipper()),&[]);
            }
            v721_21_cursor.ascend(1);
          }
          drop(v735_7_write);
          map_map_kernels::compose(&(v734_5),&(v735_7))
        };
        drop(v734_5);
        let v734_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v734_2));
        drop(v734_2);
        let v734_10: Space = if map_kernels::has_head(&(v734_9)) { singleton(&[]) } else { Space::new() };
        drop(v734_9);
        let v734_11: Space = map_view_kernels::compose(&(v734_10),&v721_21_cursor);
        drop(v734_10);
        let v739_6: Path = concat_path(&(v733_6),&v721_21_cursor.path()[(v721_21_origin + 1)..(v721_21_origin + 2)]);
        let v734_12: Space = map_kernels::wrap(&(v734_11),&(v739_6));
        drop(v734_11);
        let v734_13: Space = map_kernels::wrap(&(v734_12),&(*p1));
        drop(v734_12);
        let v734_14: Space = map_map_kernels::unite(&(v734_8),&(v734_13));
        drop(v734_13);
        join_wrapped_into(&mut v733_11_write,&((v734_14).read_zipper()),&[]);
        }
        v721_21_cursor.ascend(1);
      }
      drop(v733_11_write);
      drop(v733_6);
      map_map_kernels::compose(&(v722_10),&(v733_11))
    };
    drop(v722_10);
    let v722_13: Space = map_map_kernels::unite(&(v722_8),&(v722_12));
    join_wrapped_into(&mut v721_21_write,&((v722_13).read_zipper()),&[]);
    }
    v721_21_cursor.ascend(1);
  }
  drop(v721_21_cursor);
  drop(v721_21_write);
  (v721_21).clone()
}

fn routine_39(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v740_15 = Space::new();
  let mut v740_15_write = v740_15.write_zipper();
  let mut v740_15_cursor = (*s0).read_zipper();
  let v740_15_origin = v740_15_cursor.path().len();
  for v740_15_byte in v740_15_cursor.child_mask().iter() {
    v740_15_cursor.descend_to_existing_byte(v740_15_byte);
    {
    let v741_2: Space = singleton(&v740_15_cursor.path()[v740_15_origin..(v740_15_origin + 1)]);
    let v741_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v741_2));
    let v741_4: Space = if map_kernels::has_head(&(v741_3)) { singleton(&[]) } else { Space::new() };
    drop(v741_3);
    let v741_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v741_4));
    drop(v741_4);
    let v741_8: Space = if (&(v741_5)).is_empty() { Space::new() } else {
      let v742_6: Path = concat_path(&(*p0),&v740_15_cursor.path()[v740_15_origin..(v740_15_origin + 1)]);
      let mut v742_7 = Space::new();
      let mut v742_7_write = v742_7.write_zipper();
      for v742_7_byte in v740_15_cursor.child_mask().iter() {
        v740_15_cursor.descend_to_existing_byte(v742_7_byte);
        {
        let v743_2: Space = singleton(&v740_15_cursor.path()[(v740_15_origin + 1)..(v740_15_origin + 2)]);
        let v743_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v743_2));
        let v743_4: Space = if map_kernels::has_head(&(v743_3)) { singleton(&[]) } else { Space::new() };
        drop(v743_3);
        let v743_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v743_4));
        drop(v743_4);
        let v743_8: Space = if (&(v743_5)).is_empty() { Space::new() } else {
          let v744_6: Path = concat_path(&(v742_6),&v740_15_cursor.path()[(v740_15_origin + 1)..(v740_15_origin + 2)]);
          let mut v744_7 = Space::new();
          let mut v744_7_write = v744_7.write_zipper();
          for v744_7_byte in v740_15_cursor.child_mask().iter() {
            v740_15_cursor.descend_to_existing_byte(v744_7_byte);
            {
            let v745_2: Space = singleton(&v740_15_cursor.path()[(v740_15_origin + 2)..(v740_15_origin + 3)]);
            let v745_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v745_2));
            let v745_4: Space = if map_kernels::has_head(&(v745_3)) { singleton(&[]) } else { Space::new() };
            drop(v745_3);
            let v745_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v745_4));
            drop(v745_4);
            let v745_8: Space = if (&(v745_5)).is_empty() { Space::new() } else {
              let v746_6: Path = concat_path(&(v744_6),&v740_15_cursor.path()[(v740_15_origin + 2)..(v740_15_origin + 3)]);
              let v746_7: Space = routine_50(c, &(v746_6), &(*p1), &v740_15_cursor);
              map_map_kernels::compose(&(v745_5),&(v746_7))
            };
            drop(v745_5);
            let v745_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v745_2));
            drop(v745_2);
            let v745_10: Space = if map_kernels::has_head(&(v745_9)) { singleton(&[]) } else { Space::new() };
            drop(v745_9);
            let v745_12: Space = if (&(v745_10)).is_empty() { Space::new() } else {
              let v747_6: Path = concat_path(&(v744_6),&v740_15_cursor.path()[(v740_15_origin + 2)..(v740_15_origin + 3)]);
              let v747_11: Space = routine_51(c, &(v747_6), &(*p1), &v740_15_cursor);
              drop(v747_6);
              map_map_kernels::compose(&(v745_10),&(v747_11))
            };
            drop(v745_10);
            let v745_13: Space = map_map_kernels::unite(&(v745_8),&(v745_12));
            join_wrapped_into(&mut v744_7_write,&((v745_13).read_zipper()),&[]);
            }
            v740_15_cursor.ascend(1);
          }
          drop(v744_7_write);
          map_map_kernels::compose(&(v743_5),&(v744_7))
        };
        drop(v743_5);
        let v743_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v743_2));
        drop(v743_2);
        let v743_10: Space = if map_kernels::has_head(&(v743_9)) { singleton(&[]) } else { Space::new() };
        drop(v743_9);
        let v743_12: Space = if (&(v743_10)).is_empty() { Space::new() } else {
          let v748_6: Path = concat_path(&(v742_6),&v740_15_cursor.path()[(v740_15_origin + 1)..(v740_15_origin + 2)]);
          let mut v748_11 = Space::new();
          let mut v748_11_write = v748_11.write_zipper();
          for v748_11_byte in v740_15_cursor.child_mask().iter() {
            v740_15_cursor.descend_to_existing_byte(v748_11_byte);
            {
            let v749_2: Space = singleton(&v740_15_cursor.path()[(v740_15_origin + 2)..(v740_15_origin + 3)]);
            let v749_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v749_2));
            let v749_4: Space = if map_kernels::has_head(&(v749_3)) { singleton(&[]) } else { Space::new() };
            drop(v749_3);
            let v749_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v749_4));
            drop(v749_4);
            let v749_8: Space = if (&(v749_5)).is_empty() { Space::new() } else {
              let v750_6: Path = concat_path(&(v748_6),&v740_15_cursor.path()[(v740_15_origin + 2)..(v740_15_origin + 3)]);
              let v750_7: Space = routine_50(c, &(v750_6), &(*p1), &v740_15_cursor);
              map_map_kernels::compose(&(v749_5),&(v750_7))
            };
            drop(v749_5);
            let v749_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v749_2));
            drop(v749_2);
            let v749_10: Space = if map_kernels::has_head(&(v749_9)) { singleton(&[]) } else { Space::new() };
            drop(v749_9);
            let v749_12: Space = if (&(v749_10)).is_empty() { Space::new() } else {
              let v751_6: Path = concat_path(&(v748_6),&v740_15_cursor.path()[(v740_15_origin + 2)..(v740_15_origin + 3)]);
              let v751_11: Space = routine_19(c, &(v751_6), &(*p1), &v740_15_cursor);
              drop(v751_6);
              map_map_kernels::compose(&(v749_10),&(v751_11))
            };
            drop(v749_10);
            let v749_13: Space = map_map_kernels::unite(&(v749_8),&(v749_12));
            join_wrapped_into(&mut v748_11_write,&((v749_13).read_zipper()),&[]);
            }
            v740_15_cursor.ascend(1);
          }
          drop(v748_11_write);
          drop(v748_6);
          map_map_kernels::compose(&(v743_10),&(v748_11))
        };
        drop(v743_10);
        let v743_13: Space = map_map_kernels::unite(&(v743_8),&(v743_12));
        join_wrapped_into(&mut v742_7_write,&((v743_13).read_zipper()),&[]);
        }
        v740_15_cursor.ascend(1);
      }
      drop(v742_7_write);
      map_map_kernels::compose(&(v741_5),&(v742_7))
    };
    drop(v741_5);
    let v741_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v741_2));
    drop(v741_2);
    let v741_10: Space = if map_kernels::has_head(&(v741_9)) { singleton(&[]) } else { Space::new() };
    drop(v741_9);
    let v741_11: Space = map_view_kernels::compose(&(v741_10),&v740_15_cursor);
    drop(v741_10);
    let v752_6: Path = concat_path(&(*p0),&v740_15_cursor.path()[v740_15_origin..(v740_15_origin + 1)]);
    let v741_12: Space = map_kernels::wrap(&(v741_11),&(v752_6));
    drop(v741_11);
    let v741_13: Space = map_kernels::wrap(&(v741_12),&(*p1));
    drop(v741_12);
    let v741_14: Space = map_map_kernels::unite(&(v741_8),&(v741_13));
    drop(v741_13);
    join_wrapped_into(&mut v740_15_write,&((v741_14).read_zipper()),&[]);
    }
    v740_15_cursor.ascend(1);
  }
  drop(v740_15_cursor);
  drop(v740_15_write);
  (v740_15).clone()
}

fn routine_40(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v753_28 = Space::new();
  let mut v753_28_write = v753_28.write_zipper();
  let mut v753_28_cursor = (*s0).read_zipper();
  let v753_28_origin = v753_28_cursor.path().len();
  for v753_28_byte in v753_28_cursor.child_mask().iter() {
    v753_28_cursor.descend_to_existing_byte(v753_28_byte);
    {
    let v754_2: Space = singleton(&v753_28_cursor.path()[v753_28_origin..(v753_28_origin + 1)]);
    let v754_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v754_2));
    let v754_4: Space = if map_kernels::has_head(&(v754_3)) { singleton(&[]) } else { Space::new() };
    drop(v754_3);
    let v754_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v754_4));
    drop(v754_4);
    let v754_8: Space = if (&(v754_5)).is_empty() { Space::new() } else {
      let v755_6: Path = concat_path(&(*p0),&v753_28_cursor.path()[v753_28_origin..(v753_28_origin + 1)]);
      let mut v755_7 = Space::new();
      let mut v755_7_write = v755_7.write_zipper();
      for v755_7_byte in v753_28_cursor.child_mask().iter() {
        v753_28_cursor.descend_to_existing_byte(v755_7_byte);
        {
        let v756_2: Space = singleton(&v753_28_cursor.path()[(v753_28_origin + 1)..(v753_28_origin + 2)]);
        let v756_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v756_2));
        let v756_4: Space = if map_kernels::has_head(&(v756_3)) { singleton(&[]) } else { Space::new() };
        drop(v756_3);
        let v756_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v756_4));
        drop(v756_4);
        let v756_8: Space = if (&(v756_5)).is_empty() { Space::new() } else {
          let v757_6: Path = concat_path(&(v755_6),&v753_28_cursor.path()[(v753_28_origin + 1)..(v753_28_origin + 2)]);
          let mut v757_7 = Space::new();
          let mut v757_7_write = v757_7.write_zipper();
          for v757_7_byte in v753_28_cursor.child_mask().iter() {
            v753_28_cursor.descend_to_existing_byte(v757_7_byte);
            {
            let v758_2: Space = singleton(&v753_28_cursor.path()[(v753_28_origin + 2)..(v753_28_origin + 3)]);
            let v758_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v758_2));
            let v758_4: Space = if map_kernels::has_head(&(v758_3)) { singleton(&[]) } else { Space::new() };
            drop(v758_3);
            let v758_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v758_4));
            drop(v758_4);
            let v758_8: Space = if (&(v758_5)).is_empty() { Space::new() } else {
              let v759_6: Path = concat_path(&(v757_6),&v753_28_cursor.path()[(v753_28_origin + 2)..(v753_28_origin + 3)]);
              let v759_7: Space = routine_52(c, &(v759_6), &(*p1), &v753_28_cursor, &(*s1));
              map_map_kernels::compose(&(v758_5),&(v759_7))
            };
            drop(v758_5);
            let v758_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v758_2));
            drop(v758_2);
            let v758_10: Space = if map_kernels::has_head(&(v758_9)) { singleton(&[]) } else { Space::new() };
            drop(v758_9);
            let v758_12: Space = if (&(v758_10)).is_empty() { Space::new() } else {
              let v760_6: Path = concat_path(&(v757_6),&v753_28_cursor.path()[(v753_28_origin + 2)..(v753_28_origin + 3)]);
              let v760_11: Space = routine_53(c, &(v760_6), &(*p1), &v753_28_cursor, &(*s1));
              drop(v760_6);
              map_map_kernels::compose(&(v758_10),&(v760_11))
            };
            drop(v758_10);
            let v758_13: Space = map_map_kernels::unite(&(v758_8),&(v758_12));
            join_wrapped_into(&mut v757_7_write,&((v758_13).read_zipper()),&[]);
            }
            v753_28_cursor.ascend(1);
          }
          drop(v757_7_write);
          map_map_kernels::compose(&(v756_5),&(v757_7))
        };
        drop(v756_5);
        let v756_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v756_2));
        drop(v756_2);
        let v756_10: Space = if map_kernels::has_head(&(v756_9)) { singleton(&[]) } else { Space::new() };
        drop(v756_9);
        let v756_12: Space = if (&(v756_10)).is_empty() { Space::new() } else {
          let v761_6: Path = concat_path(&(v755_6),&v753_28_cursor.path()[(v753_28_origin + 1)..(v753_28_origin + 2)]);
          let mut v761_11 = Space::new();
          let mut v761_11_write = v761_11.write_zipper();
          for v761_11_byte in v753_28_cursor.child_mask().iter() {
            v753_28_cursor.descend_to_existing_byte(v761_11_byte);
            {
            let v762_2: Space = singleton(&v753_28_cursor.path()[(v753_28_origin + 2)..(v753_28_origin + 3)]);
            let v762_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v762_2));
            let v762_4: Space = if map_kernels::has_head(&(v762_3)) { singleton(&[]) } else { Space::new() };
            drop(v762_3);
            let v762_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v762_4));
            drop(v762_4);
            let v762_8: Space = if (&(v762_5)).is_empty() { Space::new() } else {
              let v763_6: Path = concat_path(&(v761_6),&v753_28_cursor.path()[(v753_28_origin + 2)..(v753_28_origin + 3)]);
              let v763_7: Space = routine_52(c, &(v763_6), &(*p1), &v753_28_cursor, &(*s1));
              map_map_kernels::compose(&(v762_5),&(v763_7))
            };
            drop(v762_5);
            let v762_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v762_2));
            drop(v762_2);
            let v762_10: Space = if map_kernels::has_head(&(v762_9)) { singleton(&[]) } else { Space::new() };
            drop(v762_9);
            let v762_12: Space = if (&(v762_10)).is_empty() { Space::new() } else {
              let v764_6: Path = concat_path(&(v761_6),&v753_28_cursor.path()[(v753_28_origin + 2)..(v753_28_origin + 3)]);
              let v764_11: Space = routine_10(c, &(v764_6), &(*p1), &v753_28_cursor, &(*s1));
              drop(v764_6);
              map_map_kernels::compose(&(v762_10),&(v764_11))
            };
            drop(v762_10);
            let v762_13: Space = map_map_kernels::unite(&(v762_8),&(v762_12));
            join_wrapped_into(&mut v761_11_write,&((v762_13).read_zipper()),&[]);
            }
            v753_28_cursor.ascend(1);
          }
          drop(v761_11_write);
          drop(v761_6);
          map_map_kernels::compose(&(v756_10),&(v761_11))
        };
        drop(v756_10);
        let v756_13: Space = map_map_kernels::unite(&(v756_8),&(v756_12));
        join_wrapped_into(&mut v755_7_write,&((v756_13).read_zipper()),&[]);
        }
        v753_28_cursor.ascend(1);
      }
      drop(v755_7_write);
      map_map_kernels::compose(&(v754_5),&(v755_7))
    };
    drop(v754_5);
    let v754_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v754_2));
    drop(v754_2);
    let v754_10: Space = if map_kernels::has_head(&(v754_9)) { singleton(&[]) } else { Space::new() };
    drop(v754_9);
    let v754_13: Space = if (&(v754_10)).is_empty() { Space::new() } else {
      let v765_6: Path = concat_path(&(*p0),&v753_28_cursor.path()[v753_28_origin..(v753_28_origin + 1)]);
      let mut v765_12 = Space::new();
      let mut v765_12_write = v765_12.write_zipper();
      for v765_12_byte in v753_28_cursor.child_mask().iter() {
        v753_28_cursor.descend_to_existing_byte(v765_12_byte);
        {
        let v766_2: Space = singleton(&v753_28_cursor.path()[(v753_28_origin + 1)..(v753_28_origin + 2)]);
        let v766_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v766_2));
        let v766_4: Space = if map_kernels::has_head(&(v766_3)) { singleton(&[]) } else { Space::new() };
        drop(v766_3);
        let v766_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v766_4));
        drop(v766_4);
        let v766_8: Space = if (&(v766_5)).is_empty() { Space::new() } else {
          let v767_6: Path = concat_path(&(v765_6),&v753_28_cursor.path()[(v753_28_origin + 1)..(v753_28_origin + 2)]);
          let mut v767_7 = Space::new();
          let mut v767_7_write = v767_7.write_zipper();
          for v767_7_byte in v753_28_cursor.child_mask().iter() {
            v753_28_cursor.descend_to_existing_byte(v767_7_byte);
            {
            let v768_2: Space = singleton(&v753_28_cursor.path()[(v753_28_origin + 2)..(v753_28_origin + 3)]);
            let v768_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v768_2));
            let v768_4: Space = if map_kernels::has_head(&(v768_3)) { singleton(&[]) } else { Space::new() };
            drop(v768_3);
            let v768_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v768_4));
            drop(v768_4);
            let v768_8: Space = if (&(v768_5)).is_empty() { Space::new() } else {
              let v769_6: Path = concat_path(&(v767_6),&v753_28_cursor.path()[(v753_28_origin + 2)..(v753_28_origin + 3)]);
              let v769_7: Space = routine_52(c, &(v769_6), &(*p1), &v753_28_cursor, &(*s1));
              map_map_kernels::compose(&(v768_5),&(v769_7))
            };
            drop(v768_5);
            let v768_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v768_2));
            drop(v768_2);
            let v768_10: Space = if map_kernels::has_head(&(v768_9)) { singleton(&[]) } else { Space::new() };
            drop(v768_9);
            let v768_12: Space = if (&(v768_10)).is_empty() { Space::new() } else {
              let v770_6: Path = concat_path(&(v767_6),&v753_28_cursor.path()[(v753_28_origin + 2)..(v753_28_origin + 3)]);
              let v770_11: Space = routine_53(c, &(v770_6), &(*p1), &v753_28_cursor, &(*s1));
              drop(v770_6);
              map_map_kernels::compose(&(v768_10),&(v770_11))
            };
            drop(v768_10);
            let v768_13: Space = map_map_kernels::unite(&(v768_8),&(v768_12));
            join_wrapped_into(&mut v767_7_write,&((v768_13).read_zipper()),&[]);
            }
            v753_28_cursor.ascend(1);
          }
          drop(v767_7_write);
          drop(v767_6);
          map_map_kernels::compose(&(v766_5),&(v767_7))
        };
        drop(v766_5);
        let v766_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v766_2));
        drop(v766_2);
        let v766_10: Space = if map_kernels::has_head(&(v766_9)) { singleton(&[]) } else { Space::new() };
        drop(v766_9);
        let v766_13: Space = if (&(v766_10)).is_empty() { Space::new() } else {
          let mut v771_12 = Space::new();
          let mut v771_12_write = v771_12.write_zipper();
          let mut v771_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v753_28_cursor.path()[v753_28_origin..(v753_28_origin + 1)]),&v753_28_cursor.path()[(v753_28_origin + 1)..(v753_28_origin + 2)]);
          let v771_12_origin = v771_12_cursor.path().len();
          for v771_12_byte in v771_12_cursor.child_mask().iter() {
            v771_12_cursor.descend_to_existing_byte(v771_12_byte);
            {
            let v772_2: Space = singleton(&v771_12_cursor.path()[v771_12_origin..(v771_12_origin + 1)]);
            let v772_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v772_2));
            let v772_4: Space = if map_kernels::has_head(&(v772_3)) { singleton(&[]) } else { Space::new() };
            drop(v772_3);
            let v772_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v772_4));
            drop(v772_4);
            let v772_7: Space = if (&(v772_5)).is_empty() { Space::new() } else {
              let v773_6: Space = routine_13(c, &v771_12_cursor.path()[v771_12_origin..(v771_12_origin + 1)], &(*p1), &v771_12_cursor);
              map_map_kernels::compose(&(v772_5),&(v773_6))
            };
            drop(v772_5);
            let v772_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v772_2));
            drop(v772_2);
            let v772_9: Space = if map_kernels::has_head(&(v772_8)) { singleton(&[]) } else { Space::new() };
            drop(v772_8);
            let v772_11: Space = if (&(v772_9)).is_empty() { Space::new() } else {
              let v774_10: Space = routine_14(c, &v771_12_cursor.path()[v771_12_origin..(v771_12_origin + 1)], &(*p1), &v771_12_cursor);
              map_map_kernels::compose(&(v772_9),&(v774_10))
            };
            drop(v772_9);
            let v772_12: Space = map_map_kernels::unite(&(v772_7),&(v772_11));
            join_wrapped_into(&mut v771_12_write,&((v772_12).read_zipper()),&[]);
            }
            v771_12_cursor.ascend(1);
          }
          drop(v771_12_cursor);
          drop(v771_12_write);
          map_map_kernels::compose(&(v766_10),&(v771_12))
        };
        drop(v766_10);
        let v766_14: Space = map_map_kernels::unite(&(v766_8),&(v766_13));
        join_wrapped_into(&mut v765_12_write,&((v766_14).read_zipper()),&[]);
        }
        v753_28_cursor.ascend(1);
      }
      drop(v765_12_write);
      drop(v765_6);
      map_map_kernels::compose(&(v754_10),&(v765_12))
    };
    drop(v754_10);
    let v754_14: Space = map_map_kernels::unite(&(v754_8),&(v754_13));
    join_wrapped_into(&mut v753_28_write,&((v754_14).read_zipper()),&[]);
    }
    v753_28_cursor.ascend(1);
  }
  drop(v753_28_cursor);
  drop(v753_28_write);
  (v753_28).clone()
}

fn routine_41(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v775_28 = Space::new();
  let mut v775_28_write = v775_28.write_zipper();
  let mut v775_28_cursor = (*s0).read_zipper();
  let v775_28_origin = v775_28_cursor.path().len();
  for v775_28_byte in v775_28_cursor.child_mask().iter() {
    v775_28_cursor.descend_to_existing_byte(v775_28_byte);
    {
    let v776_2: Space = singleton(&v775_28_cursor.path()[v775_28_origin..(v775_28_origin + 1)]);
    let v776_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v776_2));
    let v776_4: Space = if map_kernels::has_head(&(v776_3)) { singleton(&[]) } else { Space::new() };
    drop(v776_3);
    let v776_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v776_4));
    drop(v776_4);
    let v776_8: Space = if (&(v776_5)).is_empty() { Space::new() } else {
      let v777_6: Path = concat_path(&(*p0),&v775_28_cursor.path()[v775_28_origin..(v775_28_origin + 1)]);
      let mut v777_7 = Space::new();
      let mut v777_7_write = v777_7.write_zipper();
      for v777_7_byte in v775_28_cursor.child_mask().iter() {
        v775_28_cursor.descend_to_existing_byte(v777_7_byte);
        {
        let v778_2: Space = singleton(&v775_28_cursor.path()[(v775_28_origin + 1)..(v775_28_origin + 2)]);
        let v778_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v778_2));
        let v778_4: Space = if map_kernels::has_head(&(v778_3)) { singleton(&[]) } else { Space::new() };
        drop(v778_3);
        let v778_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v778_4));
        drop(v778_4);
        let v778_8: Space = if (&(v778_5)).is_empty() { Space::new() } else {
          let v779_6: Path = concat_path(&(v777_6),&v775_28_cursor.path()[(v775_28_origin + 1)..(v775_28_origin + 2)]);
          let mut v779_7 = Space::new();
          let mut v779_7_write = v779_7.write_zipper();
          for v779_7_byte in v775_28_cursor.child_mask().iter() {
            v775_28_cursor.descend_to_existing_byte(v779_7_byte);
            {
            let v780_2: Space = singleton(&v775_28_cursor.path()[(v775_28_origin + 2)..(v775_28_origin + 3)]);
            let v780_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v780_2));
            let v780_4: Space = if map_kernels::has_head(&(v780_3)) { singleton(&[]) } else { Space::new() };
            drop(v780_3);
            let v780_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v780_4));
            drop(v780_4);
            let v780_8: Space = if (&(v780_5)).is_empty() { Space::new() } else {
              let v781_6: Path = concat_path(&(v779_6),&v775_28_cursor.path()[(v775_28_origin + 2)..(v775_28_origin + 3)]);
              let v781_7: Space = routine_52(c, &(v781_6), &(*p1), &v775_28_cursor, &(*s1));
              map_map_kernels::compose(&(v780_5),&(v781_7))
            };
            drop(v780_5);
            let v780_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v780_2));
            drop(v780_2);
            let v780_10: Space = if map_kernels::has_head(&(v780_9)) { singleton(&[]) } else { Space::new() };
            drop(v780_9);
            let v780_12: Space = if (&(v780_10)).is_empty() { Space::new() } else {
              let v782_6: Path = concat_path(&(v779_6),&v775_28_cursor.path()[(v775_28_origin + 2)..(v775_28_origin + 3)]);
              let v782_11: Space = routine_53(c, &(v782_6), &(*p1), &v775_28_cursor, &(*s1));
              drop(v782_6);
              map_map_kernels::compose(&(v780_10),&(v782_11))
            };
            drop(v780_10);
            let v780_13: Space = map_map_kernels::unite(&(v780_8),&(v780_12));
            join_wrapped_into(&mut v779_7_write,&((v780_13).read_zipper()),&[]);
            }
            v775_28_cursor.ascend(1);
          }
          drop(v779_7_write);
          map_map_kernels::compose(&(v778_5),&(v779_7))
        };
        drop(v778_5);
        let v778_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v778_2));
        drop(v778_2);
        let v778_10: Space = if map_kernels::has_head(&(v778_9)) { singleton(&[]) } else { Space::new() };
        drop(v778_9);
        let v778_12: Space = if (&(v778_10)).is_empty() { Space::new() } else {
          let v783_6: Path = concat_path(&(v777_6),&v775_28_cursor.path()[(v775_28_origin + 1)..(v775_28_origin + 2)]);
          let mut v783_11 = Space::new();
          let mut v783_11_write = v783_11.write_zipper();
          for v783_11_byte in v775_28_cursor.child_mask().iter() {
            v775_28_cursor.descend_to_existing_byte(v783_11_byte);
            {
            let v784_2: Space = singleton(&v775_28_cursor.path()[(v775_28_origin + 2)..(v775_28_origin + 3)]);
            let v784_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v784_2));
            let v784_4: Space = if map_kernels::has_head(&(v784_3)) { singleton(&[]) } else { Space::new() };
            drop(v784_3);
            let v784_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v784_4));
            drop(v784_4);
            let v784_8: Space = if (&(v784_5)).is_empty() { Space::new() } else {
              let v785_6: Path = concat_path(&(v783_6),&v775_28_cursor.path()[(v775_28_origin + 2)..(v775_28_origin + 3)]);
              let v785_7: Space = routine_52(c, &(v785_6), &(*p1), &v775_28_cursor, &(*s1));
              map_map_kernels::compose(&(v784_5),&(v785_7))
            };
            drop(v784_5);
            let v784_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v784_2));
            drop(v784_2);
            let v784_10: Space = if map_kernels::has_head(&(v784_9)) { singleton(&[]) } else { Space::new() };
            drop(v784_9);
            let v784_12: Space = if (&(v784_10)).is_empty() { Space::new() } else {
              let v786_6: Path = concat_path(&(v783_6),&v775_28_cursor.path()[(v775_28_origin + 2)..(v775_28_origin + 3)]);
              let v786_11: Space = routine_10(c, &(v786_6), &(*p1), &v775_28_cursor, &(*s1));
              drop(v786_6);
              map_map_kernels::compose(&(v784_10),&(v786_11))
            };
            drop(v784_10);
            let v784_13: Space = map_map_kernels::unite(&(v784_8),&(v784_12));
            join_wrapped_into(&mut v783_11_write,&((v784_13).read_zipper()),&[]);
            }
            v775_28_cursor.ascend(1);
          }
          drop(v783_11_write);
          drop(v783_6);
          map_map_kernels::compose(&(v778_10),&(v783_11))
        };
        drop(v778_10);
        let v778_13: Space = map_map_kernels::unite(&(v778_8),&(v778_12));
        join_wrapped_into(&mut v777_7_write,&((v778_13).read_zipper()),&[]);
        }
        v775_28_cursor.ascend(1);
      }
      drop(v777_7_write);
      drop(v777_6);
      map_map_kernels::compose(&(v776_5),&(v777_7))
    };
    drop(v776_5);
    let v776_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v776_2));
    drop(v776_2);
    let v776_10: Space = if map_kernels::has_head(&(v776_9)) { singleton(&[]) } else { Space::new() };
    drop(v776_9);
    let v776_13: Space = if (&(v776_10)).is_empty() { Space::new() } else {
      let mut v787_12 = Space::new();
      let mut v787_12_write = v787_12.write_zipper();
      let mut v787_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v775_28_cursor.path()[v775_28_origin..(v775_28_origin + 1)]);
      let v787_12_origin = v787_12_cursor.path().len();
      for v787_12_byte in v787_12_cursor.child_mask().iter() {
        v787_12_cursor.descend_to_existing_byte(v787_12_byte);
        {
        let v788_2: Space = singleton(&v787_12_cursor.path()[v787_12_origin..(v787_12_origin + 1)]);
        let v788_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v788_2));
        let v788_4: Space = if map_kernels::has_head(&(v788_3)) { singleton(&[]) } else { Space::new() };
        drop(v788_3);
        let v788_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v788_4));
        drop(v788_4);
        let v788_7: Space = if (&(v788_5)).is_empty() { Space::new() } else {
          let mut v789_6 = Space::new();
          let mut v789_6_write = v789_6.write_zipper();
          for v789_6_byte in v787_12_cursor.child_mask().iter() {
            v787_12_cursor.descend_to_existing_byte(v789_6_byte);
            {
            let v790_2: Space = singleton(&v787_12_cursor.path()[(v787_12_origin + 1)..(v787_12_origin + 2)]);
            let v790_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v790_2));
            let v790_4: Space = if map_kernels::has_head(&(v790_3)) { singleton(&[]) } else { Space::new() };
            drop(v790_3);
            let v790_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v790_4));
            drop(v790_4);
            let v790_8: Space = if (&(v790_5)).is_empty() { Space::new() } else {
              let v791_7: Space = routine_17(c, &v787_12_cursor.path()[v787_12_origin..(v787_12_origin + 2)], &(*p1), &v787_12_cursor);
              map_map_kernels::compose(&(v790_5),&(v791_7))
            };
            drop(v790_5);
            let v790_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v790_2));
            drop(v790_2);
            let v790_10: Space = if map_kernels::has_head(&(v790_9)) { singleton(&[]) } else { Space::new() };
            drop(v790_9);
            let v790_12: Space = if (&(v790_10)).is_empty() { Space::new() } else {
              let v792_11: Space = routine_18(c, &v787_12_cursor.path()[v787_12_origin..(v787_12_origin + 2)], &(*p1), &v787_12_cursor);
              map_map_kernels::compose(&(v790_10),&(v792_11))
            };
            drop(v790_10);
            let v790_13: Space = map_map_kernels::unite(&(v790_8),&(v790_12));
            join_wrapped_into(&mut v789_6_write,&((v790_13).read_zipper()),&[]);
            }
            v787_12_cursor.ascend(1);
          }
          drop(v789_6_write);
          map_map_kernels::compose(&(v788_5),&(v789_6))
        };
        drop(v788_5);
        let v788_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v788_2));
        drop(v788_2);
        let v788_9: Space = if map_kernels::has_head(&(v788_8)) { singleton(&[]) } else { Space::new() };
        drop(v788_8);
        let v788_11: Space = if (&(v788_9)).is_empty() { Space::new() } else {
          let mut v793_10 = Space::new();
          let mut v793_10_write = v793_10.write_zipper();
          for v793_10_byte in v787_12_cursor.child_mask().iter() {
            v787_12_cursor.descend_to_existing_byte(v793_10_byte);
            {
            let v794_2: Space = singleton(&v787_12_cursor.path()[(v787_12_origin + 1)..(v787_12_origin + 2)]);
            let v794_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v794_2));
            let v794_4: Space = if map_kernels::has_head(&(v794_3)) { singleton(&[]) } else { Space::new() };
            drop(v794_3);
            let v794_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v794_4));
            drop(v794_4);
            let v794_8: Space = if (&(v794_5)).is_empty() { Space::new() } else {
              let v795_7: Space = routine_17(c, &v787_12_cursor.path()[v787_12_origin..(v787_12_origin + 2)], &(*p1), &v787_12_cursor);
              map_map_kernels::compose(&(v794_5),&(v795_7))
            };
            drop(v794_5);
            let v794_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v794_2));
            drop(v794_2);
            let v794_10: Space = if map_kernels::has_head(&(v794_9)) { singleton(&[]) } else { Space::new() };
            drop(v794_9);
            let v794_12: Space = if (&(v794_10)).is_empty() { Space::new() } else {
              let v796_11: Space = routine_19(c, &v787_12_cursor.path()[v787_12_origin..(v787_12_origin + 2)], &(*p1), &v787_12_cursor);
              map_map_kernels::compose(&(v794_10),&(v796_11))
            };
            drop(v794_10);
            let v794_13: Space = map_map_kernels::unite(&(v794_8),&(v794_12));
            join_wrapped_into(&mut v793_10_write,&((v794_13).read_zipper()),&[]);
            }
            v787_12_cursor.ascend(1);
          }
          drop(v793_10_write);
          map_map_kernels::compose(&(v788_9),&(v793_10))
        };
        drop(v788_9);
        let v788_12: Space = map_map_kernels::unite(&(v788_7),&(v788_11));
        join_wrapped_into(&mut v787_12_write,&((v788_12).read_zipper()),&[]);
        }
        v787_12_cursor.ascend(1);
      }
      drop(v787_12_cursor);
      drop(v787_12_write);
      map_map_kernels::compose(&(v776_10),&(v787_12))
    };
    drop(v776_10);
    let v776_14: Space = map_map_kernels::unite(&(v776_8),&(v776_13));
    join_wrapped_into(&mut v775_28_write,&((v776_14).read_zipper()),&[]);
    }
    v775_28_cursor.ascend(1);
  }
  drop(v775_28_cursor);
  drop(v775_28_write);
  (v775_28).clone()
}

fn routine_42(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v797_21 = Space::new();
  let mut v797_21_write = v797_21.write_zipper();
  let mut v797_21_cursor = (*s0).read_zipper();
  let v797_21_origin = v797_21_cursor.path().len();
  for v797_21_byte in v797_21_cursor.child_mask().iter() {
    v797_21_cursor.descend_to_existing_byte(v797_21_byte);
    {
    let v798_2: Space = singleton(&v797_21_cursor.path()[v797_21_origin..(v797_21_origin + 1)]);
    let v798_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v798_2));
    let v798_4: Space = if map_kernels::has_head(&(v798_3)) { singleton(&[]) } else { Space::new() };
    drop(v798_3);
    let v798_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v798_4));
    drop(v798_4);
    let v798_8: Space = if (&(v798_5)).is_empty() { Space::new() } else {
      let v799_6: Path = concat_path(&(*p0),&v797_21_cursor.path()[v797_21_origin..(v797_21_origin + 1)]);
      let mut v799_7 = Space::new();
      let mut v799_7_write = v799_7.write_zipper();
      for v799_7_byte in v797_21_cursor.child_mask().iter() {
        v797_21_cursor.descend_to_existing_byte(v799_7_byte);
        {
        let v800_2: Space = singleton(&v797_21_cursor.path()[(v797_21_origin + 1)..(v797_21_origin + 2)]);
        let v800_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v800_2));
        let v800_4: Space = if map_kernels::has_head(&(v800_3)) { singleton(&[]) } else { Space::new() };
        drop(v800_3);
        let v800_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v800_4));
        drop(v800_4);
        let v800_8: Space = if (&(v800_5)).is_empty() { Space::new() } else {
          let v801_6: Path = concat_path(&(v799_6),&v797_21_cursor.path()[(v797_21_origin + 1)..(v797_21_origin + 2)]);
          let mut v801_7 = Space::new();
          let mut v801_7_write = v801_7.write_zipper();
          for v801_7_byte in v797_21_cursor.child_mask().iter() {
            v797_21_cursor.descend_to_existing_byte(v801_7_byte);
            {
            let v802_2: Space = singleton(&v797_21_cursor.path()[(v797_21_origin + 2)..(v797_21_origin + 3)]);
            let v802_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v802_2));
            let v802_4: Space = if map_kernels::has_head(&(v802_3)) { singleton(&[]) } else { Space::new() };
            drop(v802_3);
            let v802_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v802_4));
            drop(v802_4);
            let v802_8: Space = if (&(v802_5)).is_empty() { Space::new() } else {
              let v803_6: Path = concat_path(&(v801_6),&v797_21_cursor.path()[(v797_21_origin + 2)..(v797_21_origin + 3)]);
              let v803_7: Space = routine_54(c, &(v803_6), &(*p1), &v797_21_cursor);
              map_map_kernels::compose(&(v802_5),&(v803_7))
            };
            drop(v802_5);
            let v802_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v802_2));
            drop(v802_2);
            let v802_10: Space = if map_kernels::has_head(&(v802_9)) { singleton(&[]) } else { Space::new() };
            drop(v802_9);
            let v802_12: Space = if (&(v802_10)).is_empty() { Space::new() } else {
              let v804_6: Path = concat_path(&(v801_6),&v797_21_cursor.path()[(v797_21_origin + 2)..(v797_21_origin + 3)]);
              let v804_11: Space = routine_55(c, &(v804_6), &(*p1), &v797_21_cursor);
              drop(v804_6);
              map_map_kernels::compose(&(v802_10),&(v804_11))
            };
            drop(v802_10);
            let v802_13: Space = map_map_kernels::unite(&(v802_8),&(v802_12));
            join_wrapped_into(&mut v801_7_write,&((v802_13).read_zipper()),&[]);
            }
            v797_21_cursor.ascend(1);
          }
          drop(v801_7_write);
          map_map_kernels::compose(&(v800_5),&(v801_7))
        };
        drop(v800_5);
        let v800_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v800_2));
        drop(v800_2);
        let v800_10: Space = if map_kernels::has_head(&(v800_9)) { singleton(&[]) } else { Space::new() };
        drop(v800_9);
        let v800_12: Space = if (&(v800_10)).is_empty() { Space::new() } else {
          let v805_6: Path = concat_path(&(v799_6),&v797_21_cursor.path()[(v797_21_origin + 1)..(v797_21_origin + 2)]);
          let mut v805_11 = Space::new();
          let mut v805_11_write = v805_11.write_zipper();
          for v805_11_byte in v797_21_cursor.child_mask().iter() {
            v797_21_cursor.descend_to_existing_byte(v805_11_byte);
            {
            let v806_2: Space = singleton(&v797_21_cursor.path()[(v797_21_origin + 2)..(v797_21_origin + 3)]);
            let v806_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v806_2));
            let v806_4: Space = if map_kernels::has_head(&(v806_3)) { singleton(&[]) } else { Space::new() };
            drop(v806_3);
            let v806_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v806_4));
            drop(v806_4);
            let v806_8: Space = if (&(v806_5)).is_empty() { Space::new() } else {
              let v807_6: Path = concat_path(&(v805_6),&v797_21_cursor.path()[(v797_21_origin + 2)..(v797_21_origin + 3)]);
              let v807_7: Space = routine_54(c, &(v807_6), &(*p1), &v797_21_cursor);
              map_map_kernels::compose(&(v806_5),&(v807_7))
            };
            drop(v806_5);
            let v806_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v806_2));
            drop(v806_2);
            let v806_10: Space = if map_kernels::has_head(&(v806_9)) { singleton(&[]) } else { Space::new() };
            drop(v806_9);
            let v806_12: Space = if (&(v806_10)).is_empty() { Space::new() } else {
              let v808_6: Path = concat_path(&(v805_6),&v797_21_cursor.path()[(v797_21_origin + 2)..(v797_21_origin + 3)]);
              let v808_11: Space = routine_19(c, &(v808_6), &(*p1), &v797_21_cursor);
              drop(v808_6);
              map_map_kernels::compose(&(v806_10),&(v808_11))
            };
            drop(v806_10);
            let v806_13: Space = map_map_kernels::unite(&(v806_8),&(v806_12));
            join_wrapped_into(&mut v805_11_write,&((v806_13).read_zipper()),&[]);
            }
            v797_21_cursor.ascend(1);
          }
          drop(v805_11_write);
          drop(v805_6);
          map_map_kernels::compose(&(v800_10),&(v805_11))
        };
        drop(v800_10);
        let v800_13: Space = map_map_kernels::unite(&(v800_8),&(v800_12));
        join_wrapped_into(&mut v799_7_write,&((v800_13).read_zipper()),&[]);
        }
        v797_21_cursor.ascend(1);
      }
      drop(v799_7_write);
      map_map_kernels::compose(&(v798_5),&(v799_7))
    };
    drop(v798_5);
    let v798_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v798_2));
    drop(v798_2);
    let v798_10: Space = if map_kernels::has_head(&(v798_9)) { singleton(&[]) } else { Space::new() };
    drop(v798_9);
    let v798_12: Space = if (&(v798_10)).is_empty() { Space::new() } else {
      let v809_6: Path = concat_path(&(*p0),&v797_21_cursor.path()[v797_21_origin..(v797_21_origin + 1)]);
      let mut v809_11 = Space::new();
      let mut v809_11_write = v809_11.write_zipper();
      for v809_11_byte in v797_21_cursor.child_mask().iter() {
        v797_21_cursor.descend_to_existing_byte(v809_11_byte);
        {
        let v810_2: Space = singleton(&v797_21_cursor.path()[(v797_21_origin + 1)..(v797_21_origin + 2)]);
        let v810_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v810_2));
        let v810_4: Space = if map_kernels::has_head(&(v810_3)) { singleton(&[]) } else { Space::new() };
        drop(v810_3);
        let v810_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v810_4));
        drop(v810_4);
        let v810_8: Space = if (&(v810_5)).is_empty() { Space::new() } else {
          let v811_6: Path = concat_path(&(v809_6),&v797_21_cursor.path()[(v797_21_origin + 1)..(v797_21_origin + 2)]);
          let mut v811_7 = Space::new();
          let mut v811_7_write = v811_7.write_zipper();
          for v811_7_byte in v797_21_cursor.child_mask().iter() {
            v797_21_cursor.descend_to_existing_byte(v811_7_byte);
            {
            let v812_2: Space = singleton(&v797_21_cursor.path()[(v797_21_origin + 2)..(v797_21_origin + 3)]);
            let v812_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v812_2));
            let v812_4: Space = if map_kernels::has_head(&(v812_3)) { singleton(&[]) } else { Space::new() };
            drop(v812_3);
            let v812_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v812_4));
            drop(v812_4);
            let v812_8: Space = if (&(v812_5)).is_empty() { Space::new() } else {
              let v813_6: Path = concat_path(&(v811_6),&v797_21_cursor.path()[(v797_21_origin + 2)..(v797_21_origin + 3)]);
              let v813_7: Space = routine_54(c, &(v813_6), &(*p1), &v797_21_cursor);
              map_map_kernels::compose(&(v812_5),&(v813_7))
            };
            drop(v812_5);
            let v812_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v812_2));
            drop(v812_2);
            let v812_10: Space = if map_kernels::has_head(&(v812_9)) { singleton(&[]) } else { Space::new() };
            drop(v812_9);
            let v812_12: Space = if (&(v812_10)).is_empty() { Space::new() } else {
              let v814_6: Path = concat_path(&(v811_6),&v797_21_cursor.path()[(v797_21_origin + 2)..(v797_21_origin + 3)]);
              let v814_11: Space = routine_55(c, &(v814_6), &(*p1), &v797_21_cursor);
              drop(v814_6);
              map_map_kernels::compose(&(v812_10),&(v814_11))
            };
            drop(v812_10);
            let v812_13: Space = map_map_kernels::unite(&(v812_8),&(v812_12));
            join_wrapped_into(&mut v811_7_write,&((v812_13).read_zipper()),&[]);
            }
            v797_21_cursor.ascend(1);
          }
          drop(v811_7_write);
          map_map_kernels::compose(&(v810_5),&(v811_7))
        };
        drop(v810_5);
        let v810_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v810_2));
        drop(v810_2);
        let v810_10: Space = if map_kernels::has_head(&(v810_9)) { singleton(&[]) } else { Space::new() };
        drop(v810_9);
        let v810_11: Space = map_view_kernels::compose(&(v810_10),&v797_21_cursor);
        drop(v810_10);
        let v815_6: Path = concat_path(&(v809_6),&v797_21_cursor.path()[(v797_21_origin + 1)..(v797_21_origin + 2)]);
        let v810_12: Space = map_kernels::wrap(&(v810_11),&(v815_6));
        drop(v810_11);
        let v810_13: Space = map_kernels::wrap(&(v810_12),&(*p1));
        drop(v810_12);
        let v810_14: Space = map_map_kernels::unite(&(v810_8),&(v810_13));
        drop(v810_13);
        join_wrapped_into(&mut v809_11_write,&((v810_14).read_zipper()),&[]);
        }
        v797_21_cursor.ascend(1);
      }
      drop(v809_11_write);
      drop(v809_6);
      map_map_kernels::compose(&(v798_10),&(v809_11))
    };
    drop(v798_10);
    let v798_13: Space = map_map_kernels::unite(&(v798_8),&(v798_12));
    join_wrapped_into(&mut v797_21_write,&((v798_13).read_zipper()),&[]);
    }
    v797_21_cursor.ascend(1);
  }
  drop(v797_21_cursor);
  drop(v797_21_write);
  (v797_21).clone()
}

fn routine_43(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v816_15 = Space::new();
  let mut v816_15_write = v816_15.write_zipper();
  let mut v816_15_cursor = (*s0).read_zipper();
  let v816_15_origin = v816_15_cursor.path().len();
  for v816_15_byte in v816_15_cursor.child_mask().iter() {
    v816_15_cursor.descend_to_existing_byte(v816_15_byte);
    {
    let v817_2: Space = singleton(&v816_15_cursor.path()[v816_15_origin..(v816_15_origin + 1)]);
    let v817_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v817_2));
    let v817_4: Space = if map_kernels::has_head(&(v817_3)) { singleton(&[]) } else { Space::new() };
    drop(v817_3);
    let v817_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v817_4));
    drop(v817_4);
    let v817_8: Space = if (&(v817_5)).is_empty() { Space::new() } else {
      let v818_6: Path = concat_path(&(*p0),&v816_15_cursor.path()[v816_15_origin..(v816_15_origin + 1)]);
      let mut v818_7 = Space::new();
      let mut v818_7_write = v818_7.write_zipper();
      for v818_7_byte in v816_15_cursor.child_mask().iter() {
        v816_15_cursor.descend_to_existing_byte(v818_7_byte);
        {
        let v819_2: Space = singleton(&v816_15_cursor.path()[(v816_15_origin + 1)..(v816_15_origin + 2)]);
        let v819_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v819_2));
        let v819_4: Space = if map_kernels::has_head(&(v819_3)) { singleton(&[]) } else { Space::new() };
        drop(v819_3);
        let v819_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v819_4));
        drop(v819_4);
        let v819_8: Space = if (&(v819_5)).is_empty() { Space::new() } else {
          let v820_6: Path = concat_path(&(v818_6),&v816_15_cursor.path()[(v816_15_origin + 1)..(v816_15_origin + 2)]);
          let mut v820_7 = Space::new();
          let mut v820_7_write = v820_7.write_zipper();
          for v820_7_byte in v816_15_cursor.child_mask().iter() {
            v816_15_cursor.descend_to_existing_byte(v820_7_byte);
            {
            let v821_2: Space = singleton(&v816_15_cursor.path()[(v816_15_origin + 2)..(v816_15_origin + 3)]);
            let v821_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v821_2));
            let v821_4: Space = if map_kernels::has_head(&(v821_3)) { singleton(&[]) } else { Space::new() };
            drop(v821_3);
            let v821_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v821_4));
            drop(v821_4);
            let v821_8: Space = if (&(v821_5)).is_empty() { Space::new() } else {
              let v822_6: Path = concat_path(&(v820_6),&v816_15_cursor.path()[(v816_15_origin + 2)..(v816_15_origin + 3)]);
              let v822_7: Space = routine_54(c, &(v822_6), &(*p1), &v816_15_cursor);
              map_map_kernels::compose(&(v821_5),&(v822_7))
            };
            drop(v821_5);
            let v821_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v821_2));
            drop(v821_2);
            let v821_10: Space = if map_kernels::has_head(&(v821_9)) { singleton(&[]) } else { Space::new() };
            drop(v821_9);
            let v821_12: Space = if (&(v821_10)).is_empty() { Space::new() } else {
              let v823_6: Path = concat_path(&(v820_6),&v816_15_cursor.path()[(v816_15_origin + 2)..(v816_15_origin + 3)]);
              let v823_11: Space = routine_55(c, &(v823_6), &(*p1), &v816_15_cursor);
              drop(v823_6);
              map_map_kernels::compose(&(v821_10),&(v823_11))
            };
            drop(v821_10);
            let v821_13: Space = map_map_kernels::unite(&(v821_8),&(v821_12));
            join_wrapped_into(&mut v820_7_write,&((v821_13).read_zipper()),&[]);
            }
            v816_15_cursor.ascend(1);
          }
          drop(v820_7_write);
          map_map_kernels::compose(&(v819_5),&(v820_7))
        };
        drop(v819_5);
        let v819_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v819_2));
        drop(v819_2);
        let v819_10: Space = if map_kernels::has_head(&(v819_9)) { singleton(&[]) } else { Space::new() };
        drop(v819_9);
        let v819_12: Space = if (&(v819_10)).is_empty() { Space::new() } else {
          let v824_6: Path = concat_path(&(v818_6),&v816_15_cursor.path()[(v816_15_origin + 1)..(v816_15_origin + 2)]);
          let mut v824_11 = Space::new();
          let mut v824_11_write = v824_11.write_zipper();
          for v824_11_byte in v816_15_cursor.child_mask().iter() {
            v816_15_cursor.descend_to_existing_byte(v824_11_byte);
            {
            let v825_2: Space = singleton(&v816_15_cursor.path()[(v816_15_origin + 2)..(v816_15_origin + 3)]);
            let v825_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v825_2));
            let v825_4: Space = if map_kernels::has_head(&(v825_3)) { singleton(&[]) } else { Space::new() };
            drop(v825_3);
            let v825_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v825_4));
            drop(v825_4);
            let v825_8: Space = if (&(v825_5)).is_empty() { Space::new() } else {
              let v826_6: Path = concat_path(&(v824_6),&v816_15_cursor.path()[(v816_15_origin + 2)..(v816_15_origin + 3)]);
              let v826_7: Space = routine_54(c, &(v826_6), &(*p1), &v816_15_cursor);
              map_map_kernels::compose(&(v825_5),&(v826_7))
            };
            drop(v825_5);
            let v825_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v825_2));
            drop(v825_2);
            let v825_10: Space = if map_kernels::has_head(&(v825_9)) { singleton(&[]) } else { Space::new() };
            drop(v825_9);
            let v825_12: Space = if (&(v825_10)).is_empty() { Space::new() } else {
              let v827_6: Path = concat_path(&(v824_6),&v816_15_cursor.path()[(v816_15_origin + 2)..(v816_15_origin + 3)]);
              let v827_11: Space = routine_19(c, &(v827_6), &(*p1), &v816_15_cursor);
              drop(v827_6);
              map_map_kernels::compose(&(v825_10),&(v827_11))
            };
            drop(v825_10);
            let v825_13: Space = map_map_kernels::unite(&(v825_8),&(v825_12));
            join_wrapped_into(&mut v824_11_write,&((v825_13).read_zipper()),&[]);
            }
            v816_15_cursor.ascend(1);
          }
          drop(v824_11_write);
          drop(v824_6);
          map_map_kernels::compose(&(v819_10),&(v824_11))
        };
        drop(v819_10);
        let v819_13: Space = map_map_kernels::unite(&(v819_8),&(v819_12));
        join_wrapped_into(&mut v818_7_write,&((v819_13).read_zipper()),&[]);
        }
        v816_15_cursor.ascend(1);
      }
      drop(v818_7_write);
      map_map_kernels::compose(&(v817_5),&(v818_7))
    };
    drop(v817_5);
    let v817_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v817_2));
    drop(v817_2);
    let v817_10: Space = if map_kernels::has_head(&(v817_9)) { singleton(&[]) } else { Space::new() };
    drop(v817_9);
    let v817_11: Space = map_view_kernels::compose(&(v817_10),&v816_15_cursor);
    drop(v817_10);
    let v828_6: Path = concat_path(&(*p0),&v816_15_cursor.path()[v816_15_origin..(v816_15_origin + 1)]);
    let v817_12: Space = map_kernels::wrap(&(v817_11),&(v828_6));
    drop(v817_11);
    let v817_13: Space = map_kernels::wrap(&(v817_12),&(*p1));
    drop(v817_12);
    let v817_14: Space = map_map_kernels::unite(&(v817_8),&(v817_13));
    drop(v817_13);
    join_wrapped_into(&mut v816_15_write,&((v817_14).read_zipper()),&[]);
    }
    v816_15_cursor.ascend(1);
  }
  drop(v816_15_cursor);
  drop(v816_15_write);
  (v816_15).clone()
}

fn routine_44(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v829_16 = Space::new();
  let mut v829_16_write = v829_16.write_zipper();
  let mut v829_16_cursor = (*s0).read_zipper();
  let v829_16_origin = v829_16_cursor.path().len();
  for v829_16_byte in v829_16_cursor.child_mask().iter() {
    v829_16_cursor.descend_to_existing_byte(v829_16_byte);
    {
    let v830_2: Space = singleton(&v829_16_cursor.path()[v829_16_origin..(v829_16_origin + 1)]);
    let v830_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v830_2));
    let v830_4: Space = if map_kernels::has_head(&(v830_3)) { singleton(&[]) } else { Space::new() };
    drop(v830_3);
    let v830_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v830_4));
    drop(v830_4);
    let v830_8: Space = if (&(v830_5)).is_empty() { Space::new() } else {
      let v831_6: Path = concat_path(&(*p0),&v829_16_cursor.path()[v829_16_origin..(v829_16_origin + 1)]);
      let mut v831_7 = Space::new();
      let mut v831_7_write = v831_7.write_zipper();
      for v831_7_byte in v829_16_cursor.child_mask().iter() {
        v829_16_cursor.descend_to_existing_byte(v831_7_byte);
        {
        let v832_2: Space = singleton(&v829_16_cursor.path()[(v829_16_origin + 1)..(v829_16_origin + 2)]);
        let v832_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v832_2));
        drop(v832_2);
        let v832_4: Space = if map_kernels::has_head(&(v832_3)) { singleton(&[]) } else { Space::new() };
        drop(v832_3);
        let v832_7: Space = if (&(v832_4)).is_empty() { Space::new() } else {
          let v833_5: Path = concat_path(&(v831_6),&v829_16_cursor.path()[(v829_16_origin + 1)..(v829_16_origin + 2)]);
          let mut v833_6 = Space::new();
          let mut v833_6_write = v833_6.write_zipper();
          for v833_6_byte in v829_16_cursor.child_mask().iter() {
            v829_16_cursor.descend_to_existing_byte(v833_6_byte);
            {
            let v834_2: Space = singleton(&v829_16_cursor.path()[(v829_16_origin + 2)..(v829_16_origin + 3)]);
            let v834_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v834_2));
            drop(v834_2);
            let v834_4: Space = if map_kernels::has_head(&(v834_3)) { singleton(&[]) } else { Space::new() };
            drop(v834_3);
            let v834_7: Space = if (&(v834_4)).is_empty() { Space::new() } else {
              let v835_5: Path = concat_path(&(v833_5),&v829_16_cursor.path()[(v829_16_origin + 2)..(v829_16_origin + 3)]);
              let v835_6: Space = routine_10(c, &(v835_5), &(*p1), &v829_16_cursor, &(*s1));
              drop(v835_5);
              map_map_kernels::compose(&(v834_4),&(v835_6))
            };
            drop(v834_4);
            join_wrapped_into(&mut v833_6_write,&((v834_7).read_zipper()),&[]);
            }
            v829_16_cursor.ascend(1);
          }
          drop(v833_6_write);
          drop(v833_5);
          map_map_kernels::compose(&(v832_4),&(v833_6))
        };
        drop(v832_4);
        join_wrapped_into(&mut v831_7_write,&((v832_7).read_zipper()),&[]);
        }
        v829_16_cursor.ascend(1);
      }
      drop(v831_7_write);
      drop(v831_6);
      map_map_kernels::compose(&(v830_5),&(v831_7))
    };
    drop(v830_5);
    let v830_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v830_2));
    drop(v830_2);
    let v830_10: Space = if map_kernels::has_head(&(v830_9)) { singleton(&[]) } else { Space::new() };
    drop(v830_9);
    let v830_13: Space = if (&(v830_10)).is_empty() { Space::new() } else {
      let mut v836_12 = Space::new();
      let mut v836_12_write = v836_12.write_zipper();
      for v836_12_byte in v829_16_cursor.child_mask().iter() {
        v829_16_cursor.descend_to_existing_byte(v836_12_byte);
        {
        let v837_2: Space = singleton(&v829_16_cursor.path()[(v829_16_origin + 1)..(v829_16_origin + 2)]);
        let v837_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v837_2));
        drop(v837_2);
        let v837_4: Space = if map_kernels::has_head(&(v837_3)) { singleton(&[]) } else { Space::new() };
        drop(v837_3);
        let v837_7: Space = if (&(v837_4)).is_empty() { Space::new() } else {
          let mut v838_6 = Space::new();
          let mut v838_6_write = v838_6.write_zipper();
          let mut v838_6_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v829_16_cursor.path()[v829_16_origin..(v829_16_origin + 1)]),&v829_16_cursor.path()[(v829_16_origin + 1)..(v829_16_origin + 2)]);
          let v838_6_origin = v838_6_cursor.path().len();
          for v838_6_byte in v838_6_cursor.child_mask().iter() {
            v838_6_cursor.descend_to_existing_byte(v838_6_byte);
            {
            let v839_2: Space = singleton(&v838_6_cursor.path()[v838_6_origin..(v838_6_origin + 1)]);
            let v839_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v839_2));
            let v839_4: Space = if map_kernels::has_head(&(v839_3)) { singleton(&[]) } else { Space::new() };
            drop(v839_3);
            let v839_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v839_4));
            drop(v839_4);
            let v839_7: Space = if (&(v839_5)).is_empty() { Space::new() } else {
              let v840_6: Space = routine_13(c, &v838_6_cursor.path()[v838_6_origin..(v838_6_origin + 1)], &(*p1), &v838_6_cursor);
              map_map_kernels::compose(&(v839_5),&(v840_6))
            };
            drop(v839_5);
            let v839_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v839_2));
            drop(v839_2);
            let v839_9: Space = if map_kernels::has_head(&(v839_8)) { singleton(&[]) } else { Space::new() };
            drop(v839_8);
            let v839_11: Space = if (&(v839_9)).is_empty() { Space::new() } else {
              let v841_10: Space = routine_14(c, &v838_6_cursor.path()[v838_6_origin..(v838_6_origin + 1)], &(*p1), &v838_6_cursor);
              map_map_kernels::compose(&(v839_9),&(v841_10))
            };
            drop(v839_9);
            let v839_12: Space = map_map_kernels::unite(&(v839_7),&(v839_11));
            join_wrapped_into(&mut v838_6_write,&((v839_12).read_zipper()),&[]);
            }
            v838_6_cursor.ascend(1);
          }
          drop(v838_6_cursor);
          drop(v838_6_write);
          map_map_kernels::compose(&(v837_4),&(v838_6))
        };
        drop(v837_4);
        join_wrapped_into(&mut v836_12_write,&((v837_7).read_zipper()),&[]);
        }
        v829_16_cursor.ascend(1);
      }
      drop(v836_12_write);
      map_map_kernels::compose(&(v830_10),&(v836_12))
    };
    drop(v830_10);
    let v830_14: Space = map_map_kernels::unite(&(v830_8),&(v830_13));
    join_wrapped_into(&mut v829_16_write,&((v830_14).read_zipper()),&[]);
    }
    v829_16_cursor.ascend(1);
  }
  drop(v829_16_cursor);
  drop(v829_16_write);
  (v829_16).clone()
}

fn routine_45(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v842_21 = Space::new();
  let mut v842_21_write = v842_21.write_zipper();
  let mut v842_21_cursor = (*s0).read_zipper();
  let v842_21_origin = v842_21_cursor.path().len();
  for v842_21_byte in v842_21_cursor.child_mask().iter() {
    v842_21_cursor.descend_to_existing_byte(v842_21_byte);
    {
    let v843_2: Space = singleton(&v842_21_cursor.path()[v842_21_origin..(v842_21_origin + 1)]);
    let v843_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v843_2));
    let v843_4: Space = if map_kernels::has_head(&(v843_3)) { singleton(&[]) } else { Space::new() };
    drop(v843_3);
    let v843_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v843_4));
    drop(v843_4);
    let v843_8: Space = if (&(v843_5)).is_empty() { Space::new() } else {
      let v844_6: Path = concat_path(&(*p0),&v842_21_cursor.path()[v842_21_origin..(v842_21_origin + 1)]);
      let mut v844_7 = Space::new();
      let mut v844_7_write = v844_7.write_zipper();
      for v844_7_byte in v842_21_cursor.child_mask().iter() {
        v842_21_cursor.descend_to_existing_byte(v844_7_byte);
        {
        let v845_2: Space = singleton(&v842_21_cursor.path()[(v842_21_origin + 1)..(v842_21_origin + 2)]);
        let v845_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v845_2));
        drop(v845_2);
        let v845_4: Space = if map_kernels::has_head(&(v845_3)) { singleton(&[]) } else { Space::new() };
        drop(v845_3);
        let v845_7: Space = if (&(v845_4)).is_empty() { Space::new() } else {
          let v846_5: Path = concat_path(&(v844_6),&v842_21_cursor.path()[(v842_21_origin + 1)..(v842_21_origin + 2)]);
          let mut v846_6 = Space::new();
          let mut v846_6_write = v846_6.write_zipper();
          for v846_6_byte in v842_21_cursor.child_mask().iter() {
            v842_21_cursor.descend_to_existing_byte(v846_6_byte);
            {
            let v847_2: Space = singleton(&v842_21_cursor.path()[(v842_21_origin + 2)..(v842_21_origin + 3)]);
            let v847_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v847_2));
            drop(v847_2);
            let v847_4: Space = if map_kernels::has_head(&(v847_3)) { singleton(&[]) } else { Space::new() };
            drop(v847_3);
            let v847_7: Space = if (&(v847_4)).is_empty() { Space::new() } else {
              let v848_5: Path = concat_path(&(v846_5),&v842_21_cursor.path()[(v842_21_origin + 2)..(v842_21_origin + 3)]);
              let v848_6: Space = routine_10(c, &(v848_5), &(*p1), &v842_21_cursor, &(*s1));
              drop(v848_5);
              map_map_kernels::compose(&(v847_4),&(v848_6))
            };
            drop(v847_4);
            join_wrapped_into(&mut v846_6_write,&((v847_7).read_zipper()),&[]);
            }
            v842_21_cursor.ascend(1);
          }
          drop(v846_6_write);
          drop(v846_5);
          map_map_kernels::compose(&(v845_4),&(v846_6))
        };
        drop(v845_4);
        join_wrapped_into(&mut v844_7_write,&((v845_7).read_zipper()),&[]);
        }
        v842_21_cursor.ascend(1);
      }
      drop(v844_7_write);
      drop(v844_6);
      map_map_kernels::compose(&(v843_5),&(v844_7))
    };
    drop(v843_5);
    let v843_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v843_2));
    drop(v843_2);
    let v843_10: Space = if map_kernels::has_head(&(v843_9)) { singleton(&[]) } else { Space::new() };
    drop(v843_9);
    let v843_13: Space = if (&(v843_10)).is_empty() { Space::new() } else {
      let mut v849_12 = Space::new();
      let mut v849_12_write = v849_12.write_zipper();
      let mut v849_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v842_21_cursor.path()[v842_21_origin..(v842_21_origin + 1)]);
      let v849_12_origin = v849_12_cursor.path().len();
      for v849_12_byte in v849_12_cursor.child_mask().iter() {
        v849_12_cursor.descend_to_existing_byte(v849_12_byte);
        {
        let v850_2: Space = singleton(&v849_12_cursor.path()[v849_12_origin..(v849_12_origin + 1)]);
        let v850_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v850_2));
        let v850_4: Space = if map_kernels::has_head(&(v850_3)) { singleton(&[]) } else { Space::new() };
        drop(v850_3);
        let v850_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v850_4));
        drop(v850_4);
        let v850_7: Space = if (&(v850_5)).is_empty() { Space::new() } else {
          let mut v851_6 = Space::new();
          let mut v851_6_write = v851_6.write_zipper();
          for v851_6_byte in v849_12_cursor.child_mask().iter() {
            v849_12_cursor.descend_to_existing_byte(v851_6_byte);
            {
            let v852_2: Space = singleton(&v849_12_cursor.path()[(v849_12_origin + 1)..(v849_12_origin + 2)]);
            let v852_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v852_2));
            let v852_4: Space = if map_kernels::has_head(&(v852_3)) { singleton(&[]) } else { Space::new() };
            drop(v852_3);
            let v852_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v852_4));
            drop(v852_4);
            let v852_8: Space = if (&(v852_5)).is_empty() { Space::new() } else {
              let v853_7: Space = routine_17(c, &v849_12_cursor.path()[v849_12_origin..(v849_12_origin + 2)], &(*p1), &v849_12_cursor);
              map_map_kernels::compose(&(v852_5),&(v853_7))
            };
            drop(v852_5);
            let v852_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v852_2));
            drop(v852_2);
            let v852_10: Space = if map_kernels::has_head(&(v852_9)) { singleton(&[]) } else { Space::new() };
            drop(v852_9);
            let v852_12: Space = if (&(v852_10)).is_empty() { Space::new() } else {
              let v854_11: Space = routine_18(c, &v849_12_cursor.path()[v849_12_origin..(v849_12_origin + 2)], &(*p1), &v849_12_cursor);
              map_map_kernels::compose(&(v852_10),&(v854_11))
            };
            drop(v852_10);
            let v852_13: Space = map_map_kernels::unite(&(v852_8),&(v852_12));
            join_wrapped_into(&mut v851_6_write,&((v852_13).read_zipper()),&[]);
            }
            v849_12_cursor.ascend(1);
          }
          drop(v851_6_write);
          map_map_kernels::compose(&(v850_5),&(v851_6))
        };
        drop(v850_5);
        let v850_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v850_2));
        drop(v850_2);
        let v850_9: Space = if map_kernels::has_head(&(v850_8)) { singleton(&[]) } else { Space::new() };
        drop(v850_8);
        let v850_11: Space = if (&(v850_9)).is_empty() { Space::new() } else {
          let mut v855_10 = Space::new();
          let mut v855_10_write = v855_10.write_zipper();
          for v855_10_byte in v849_12_cursor.child_mask().iter() {
            v849_12_cursor.descend_to_existing_byte(v855_10_byte);
            {
            let v856_2: Space = singleton(&v849_12_cursor.path()[(v849_12_origin + 1)..(v849_12_origin + 2)]);
            let v856_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v856_2));
            let v856_4: Space = if map_kernels::has_head(&(v856_3)) { singleton(&[]) } else { Space::new() };
            drop(v856_3);
            let v856_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v856_4));
            drop(v856_4);
            let v856_8: Space = if (&(v856_5)).is_empty() { Space::new() } else {
              let v857_7: Space = routine_17(c, &v849_12_cursor.path()[v849_12_origin..(v849_12_origin + 2)], &(*p1), &v849_12_cursor);
              map_map_kernels::compose(&(v856_5),&(v857_7))
            };
            drop(v856_5);
            let v856_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v856_2));
            drop(v856_2);
            let v856_10: Space = if map_kernels::has_head(&(v856_9)) { singleton(&[]) } else { Space::new() };
            drop(v856_9);
            let v856_12: Space = if (&(v856_10)).is_empty() { Space::new() } else {
              let v858_11: Space = routine_19(c, &v849_12_cursor.path()[v849_12_origin..(v849_12_origin + 2)], &(*p1), &v849_12_cursor);
              map_map_kernels::compose(&(v856_10),&(v858_11))
            };
            drop(v856_10);
            let v856_13: Space = map_map_kernels::unite(&(v856_8),&(v856_12));
            join_wrapped_into(&mut v855_10_write,&((v856_13).read_zipper()),&[]);
            }
            v849_12_cursor.ascend(1);
          }
          drop(v855_10_write);
          map_map_kernels::compose(&(v850_9),&(v855_10))
        };
        drop(v850_9);
        let v850_12: Space = map_map_kernels::unite(&(v850_7),&(v850_11));
        join_wrapped_into(&mut v849_12_write,&((v850_12).read_zipper()),&[]);
        }
        v849_12_cursor.ascend(1);
      }
      drop(v849_12_cursor);
      drop(v849_12_write);
      map_map_kernels::compose(&(v843_10),&(v849_12))
    };
    drop(v843_10);
    let v843_14: Space = map_map_kernels::unite(&(v843_8),&(v843_13));
    join_wrapped_into(&mut v842_21_write,&((v843_14).read_zipper()),&[]);
    }
    v842_21_cursor.ascend(1);
  }
  drop(v842_21_cursor);
  drop(v842_21_write);
  (v842_21).clone()
}

fn routine_46(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v859_21 = Space::new();
  let mut v859_21_write = v859_21.write_zipper();
  let mut v859_21_cursor = (*s0).read_zipper();
  let v859_21_origin = v859_21_cursor.path().len();
  for v859_21_byte in v859_21_cursor.child_mask().iter() {
    v859_21_cursor.descend_to_existing_byte(v859_21_byte);
    {
    let v860_2: Space = singleton(&v859_21_cursor.path()[v859_21_origin..(v859_21_origin + 1)]);
    let v860_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v860_2));
    let v860_4: Space = if map_kernels::has_head(&(v860_3)) { singleton(&[]) } else { Space::new() };
    drop(v860_3);
    let v860_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v860_4));
    drop(v860_4);
    let v860_8: Space = if (&(v860_5)).is_empty() { Space::new() } else {
      let v861_6: Path = concat_path(&(*p0),&v859_21_cursor.path()[v859_21_origin..(v859_21_origin + 1)]);
      let mut v861_7 = Space::new();
      let mut v861_7_write = v861_7.write_zipper();
      for v861_7_byte in v859_21_cursor.child_mask().iter() {
        v859_21_cursor.descend_to_existing_byte(v861_7_byte);
        {
        let v862_2: Space = singleton(&v859_21_cursor.path()[(v859_21_origin + 1)..(v859_21_origin + 2)]);
        let v862_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v862_2));
        let v862_4: Space = if map_kernels::has_head(&(v862_3)) { singleton(&[]) } else { Space::new() };
        drop(v862_3);
        let v862_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v862_4));
        drop(v862_4);
        let v862_8: Space = if (&(v862_5)).is_empty() { Space::new() } else {
          let v863_6: Path = concat_path(&(v861_6),&v859_21_cursor.path()[(v859_21_origin + 1)..(v859_21_origin + 2)]);
          let mut v863_7 = Space::new();
          let mut v863_7_write = v863_7.write_zipper();
          for v863_7_byte in v859_21_cursor.child_mask().iter() {
            v859_21_cursor.descend_to_existing_byte(v863_7_byte);
            {
            let v864_2: Space = singleton(&v859_21_cursor.path()[(v859_21_origin + 2)..(v859_21_origin + 3)]);
            let v864_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v864_2));
            let v864_4: Space = if map_kernels::has_head(&(v864_3)) { singleton(&[]) } else { Space::new() };
            drop(v864_3);
            let v864_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v864_4));
            drop(v864_4);
            let v864_8: Space = if (&(v864_5)).is_empty() { Space::new() } else {
              let v865_6: Path = concat_path(&(v863_6),&v859_21_cursor.path()[(v859_21_origin + 2)..(v859_21_origin + 3)]);
              let v865_7: Space = routine_56(c, &(v865_6), &(*p1), &v859_21_cursor);
              map_map_kernels::compose(&(v864_5),&(v865_7))
            };
            drop(v864_5);
            let v864_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v864_2));
            drop(v864_2);
            let v864_10: Space = if map_kernels::has_head(&(v864_9)) { singleton(&[]) } else { Space::new() };
            drop(v864_9);
            let v864_12: Space = if (&(v864_10)).is_empty() { Space::new() } else {
              let v866_6: Path = concat_path(&(v863_6),&v859_21_cursor.path()[(v859_21_origin + 2)..(v859_21_origin + 3)]);
              let v866_11: Space = routine_57(c, &(v866_6), &(*p1), &v859_21_cursor);
              drop(v866_6);
              map_map_kernels::compose(&(v864_10),&(v866_11))
            };
            drop(v864_10);
            let v864_13: Space = map_map_kernels::unite(&(v864_8),&(v864_12));
            join_wrapped_into(&mut v863_7_write,&((v864_13).read_zipper()),&[]);
            }
            v859_21_cursor.ascend(1);
          }
          drop(v863_7_write);
          map_map_kernels::compose(&(v862_5),&(v863_7))
        };
        drop(v862_5);
        let v862_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v862_2));
        drop(v862_2);
        let v862_10: Space = if map_kernels::has_head(&(v862_9)) { singleton(&[]) } else { Space::new() };
        drop(v862_9);
        let v862_12: Space = if (&(v862_10)).is_empty() { Space::new() } else {
          let v867_6: Path = concat_path(&(v861_6),&v859_21_cursor.path()[(v859_21_origin + 1)..(v859_21_origin + 2)]);
          let mut v867_11 = Space::new();
          let mut v867_11_write = v867_11.write_zipper();
          for v867_11_byte in v859_21_cursor.child_mask().iter() {
            v859_21_cursor.descend_to_existing_byte(v867_11_byte);
            {
            let v868_2: Space = singleton(&v859_21_cursor.path()[(v859_21_origin + 2)..(v859_21_origin + 3)]);
            let v868_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v868_2));
            let v868_4: Space = if map_kernels::has_head(&(v868_3)) { singleton(&[]) } else { Space::new() };
            drop(v868_3);
            let v868_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v868_4));
            drop(v868_4);
            let v868_8: Space = if (&(v868_5)).is_empty() { Space::new() } else {
              let v869_6: Path = concat_path(&(v867_6),&v859_21_cursor.path()[(v859_21_origin + 2)..(v859_21_origin + 3)]);
              let v869_7: Space = routine_56(c, &(v869_6), &(*p1), &v859_21_cursor);
              map_map_kernels::compose(&(v868_5),&(v869_7))
            };
            drop(v868_5);
            let v868_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v868_2));
            drop(v868_2);
            let v868_10: Space = if map_kernels::has_head(&(v868_9)) { singleton(&[]) } else { Space::new() };
            drop(v868_9);
            let v868_12: Space = if (&(v868_10)).is_empty() { Space::new() } else {
              let v870_6: Path = concat_path(&(v867_6),&v859_21_cursor.path()[(v859_21_origin + 2)..(v859_21_origin + 3)]);
              let v870_11: Space = routine_19(c, &(v870_6), &(*p1), &v859_21_cursor);
              drop(v870_6);
              map_map_kernels::compose(&(v868_10),&(v870_11))
            };
            drop(v868_10);
            let v868_13: Space = map_map_kernels::unite(&(v868_8),&(v868_12));
            join_wrapped_into(&mut v867_11_write,&((v868_13).read_zipper()),&[]);
            }
            v859_21_cursor.ascend(1);
          }
          drop(v867_11_write);
          drop(v867_6);
          map_map_kernels::compose(&(v862_10),&(v867_11))
        };
        drop(v862_10);
        let v862_13: Space = map_map_kernels::unite(&(v862_8),&(v862_12));
        join_wrapped_into(&mut v861_7_write,&((v862_13).read_zipper()),&[]);
        }
        v859_21_cursor.ascend(1);
      }
      drop(v861_7_write);
      map_map_kernels::compose(&(v860_5),&(v861_7))
    };
    drop(v860_5);
    let v860_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v860_2));
    drop(v860_2);
    let v860_10: Space = if map_kernels::has_head(&(v860_9)) { singleton(&[]) } else { Space::new() };
    drop(v860_9);
    let v860_12: Space = if (&(v860_10)).is_empty() { Space::new() } else {
      let v871_6: Path = concat_path(&(*p0),&v859_21_cursor.path()[v859_21_origin..(v859_21_origin + 1)]);
      let mut v871_11 = Space::new();
      let mut v871_11_write = v871_11.write_zipper();
      for v871_11_byte in v859_21_cursor.child_mask().iter() {
        v859_21_cursor.descend_to_existing_byte(v871_11_byte);
        {
        let v872_2: Space = singleton(&v859_21_cursor.path()[(v859_21_origin + 1)..(v859_21_origin + 2)]);
        let v872_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v872_2));
        let v872_4: Space = if map_kernels::has_head(&(v872_3)) { singleton(&[]) } else { Space::new() };
        drop(v872_3);
        let v872_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v872_4));
        drop(v872_4);
        let v872_8: Space = if (&(v872_5)).is_empty() { Space::new() } else {
          let v873_6: Path = concat_path(&(v871_6),&v859_21_cursor.path()[(v859_21_origin + 1)..(v859_21_origin + 2)]);
          let mut v873_7 = Space::new();
          let mut v873_7_write = v873_7.write_zipper();
          for v873_7_byte in v859_21_cursor.child_mask().iter() {
            v859_21_cursor.descend_to_existing_byte(v873_7_byte);
            {
            let v874_2: Space = singleton(&v859_21_cursor.path()[(v859_21_origin + 2)..(v859_21_origin + 3)]);
            let v874_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v874_2));
            let v874_4: Space = if map_kernels::has_head(&(v874_3)) { singleton(&[]) } else { Space::new() };
            drop(v874_3);
            let v874_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v874_4));
            drop(v874_4);
            let v874_8: Space = if (&(v874_5)).is_empty() { Space::new() } else {
              let v875_6: Path = concat_path(&(v873_6),&v859_21_cursor.path()[(v859_21_origin + 2)..(v859_21_origin + 3)]);
              let v875_7: Space = routine_56(c, &(v875_6), &(*p1), &v859_21_cursor);
              map_map_kernels::compose(&(v874_5),&(v875_7))
            };
            drop(v874_5);
            let v874_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v874_2));
            drop(v874_2);
            let v874_10: Space = if map_kernels::has_head(&(v874_9)) { singleton(&[]) } else { Space::new() };
            drop(v874_9);
            let v874_12: Space = if (&(v874_10)).is_empty() { Space::new() } else {
              let v876_6: Path = concat_path(&(v873_6),&v859_21_cursor.path()[(v859_21_origin + 2)..(v859_21_origin + 3)]);
              let v876_11: Space = routine_57(c, &(v876_6), &(*p1), &v859_21_cursor);
              drop(v876_6);
              map_map_kernels::compose(&(v874_10),&(v876_11))
            };
            drop(v874_10);
            let v874_13: Space = map_map_kernels::unite(&(v874_8),&(v874_12));
            join_wrapped_into(&mut v873_7_write,&((v874_13).read_zipper()),&[]);
            }
            v859_21_cursor.ascend(1);
          }
          drop(v873_7_write);
          map_map_kernels::compose(&(v872_5),&(v873_7))
        };
        drop(v872_5);
        let v872_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v872_2));
        drop(v872_2);
        let v872_10: Space = if map_kernels::has_head(&(v872_9)) { singleton(&[]) } else { Space::new() };
        drop(v872_9);
        let v872_11: Space = map_view_kernels::compose(&(v872_10),&v859_21_cursor);
        drop(v872_10);
        let v877_6: Path = concat_path(&(v871_6),&v859_21_cursor.path()[(v859_21_origin + 1)..(v859_21_origin + 2)]);
        let v872_12: Space = map_kernels::wrap(&(v872_11),&(v877_6));
        drop(v872_11);
        let v872_13: Space = map_kernels::wrap(&(v872_12),&(*p1));
        drop(v872_12);
        let v872_14: Space = map_map_kernels::unite(&(v872_8),&(v872_13));
        drop(v872_13);
        join_wrapped_into(&mut v871_11_write,&((v872_14).read_zipper()),&[]);
        }
        v859_21_cursor.ascend(1);
      }
      drop(v871_11_write);
      drop(v871_6);
      map_map_kernels::compose(&(v860_10),&(v871_11))
    };
    drop(v860_10);
    let v860_13: Space = map_map_kernels::unite(&(v860_8),&(v860_12));
    join_wrapped_into(&mut v859_21_write,&((v860_13).read_zipper()),&[]);
    }
    v859_21_cursor.ascend(1);
  }
  drop(v859_21_cursor);
  drop(v859_21_write);
  (v859_21).clone()
}

fn routine_47(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v878_15 = Space::new();
  let mut v878_15_write = v878_15.write_zipper();
  let mut v878_15_cursor = (*s0).read_zipper();
  let v878_15_origin = v878_15_cursor.path().len();
  for v878_15_byte in v878_15_cursor.child_mask().iter() {
    v878_15_cursor.descend_to_existing_byte(v878_15_byte);
    {
    let v879_2: Space = singleton(&v878_15_cursor.path()[v878_15_origin..(v878_15_origin + 1)]);
    let v879_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v879_2));
    let v879_4: Space = if map_kernels::has_head(&(v879_3)) { singleton(&[]) } else { Space::new() };
    drop(v879_3);
    let v879_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v879_4));
    drop(v879_4);
    let v879_8: Space = if (&(v879_5)).is_empty() { Space::new() } else {
      let v880_6: Path = concat_path(&(*p0),&v878_15_cursor.path()[v878_15_origin..(v878_15_origin + 1)]);
      let mut v880_7 = Space::new();
      let mut v880_7_write = v880_7.write_zipper();
      for v880_7_byte in v878_15_cursor.child_mask().iter() {
        v878_15_cursor.descend_to_existing_byte(v880_7_byte);
        {
        let v881_2: Space = singleton(&v878_15_cursor.path()[(v878_15_origin + 1)..(v878_15_origin + 2)]);
        let v881_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v881_2));
        let v881_4: Space = if map_kernels::has_head(&(v881_3)) { singleton(&[]) } else { Space::new() };
        drop(v881_3);
        let v881_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v881_4));
        drop(v881_4);
        let v881_8: Space = if (&(v881_5)).is_empty() { Space::new() } else {
          let v882_6: Path = concat_path(&(v880_6),&v878_15_cursor.path()[(v878_15_origin + 1)..(v878_15_origin + 2)]);
          let mut v882_7 = Space::new();
          let mut v882_7_write = v882_7.write_zipper();
          for v882_7_byte in v878_15_cursor.child_mask().iter() {
            v878_15_cursor.descend_to_existing_byte(v882_7_byte);
            {
            let v883_2: Space = singleton(&v878_15_cursor.path()[(v878_15_origin + 2)..(v878_15_origin + 3)]);
            let v883_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v883_2));
            let v883_4: Space = if map_kernels::has_head(&(v883_3)) { singleton(&[]) } else { Space::new() };
            drop(v883_3);
            let v883_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v883_4));
            drop(v883_4);
            let v883_8: Space = if (&(v883_5)).is_empty() { Space::new() } else {
              let v884_6: Path = concat_path(&(v882_6),&v878_15_cursor.path()[(v878_15_origin + 2)..(v878_15_origin + 3)]);
              let v884_7: Space = routine_56(c, &(v884_6), &(*p1), &v878_15_cursor);
              map_map_kernels::compose(&(v883_5),&(v884_7))
            };
            drop(v883_5);
            let v883_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v883_2));
            drop(v883_2);
            let v883_10: Space = if map_kernels::has_head(&(v883_9)) { singleton(&[]) } else { Space::new() };
            drop(v883_9);
            let v883_12: Space = if (&(v883_10)).is_empty() { Space::new() } else {
              let v885_6: Path = concat_path(&(v882_6),&v878_15_cursor.path()[(v878_15_origin + 2)..(v878_15_origin + 3)]);
              let v885_11: Space = routine_57(c, &(v885_6), &(*p1), &v878_15_cursor);
              drop(v885_6);
              map_map_kernels::compose(&(v883_10),&(v885_11))
            };
            drop(v883_10);
            let v883_13: Space = map_map_kernels::unite(&(v883_8),&(v883_12));
            join_wrapped_into(&mut v882_7_write,&((v883_13).read_zipper()),&[]);
            }
            v878_15_cursor.ascend(1);
          }
          drop(v882_7_write);
          map_map_kernels::compose(&(v881_5),&(v882_7))
        };
        drop(v881_5);
        let v881_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v881_2));
        drop(v881_2);
        let v881_10: Space = if map_kernels::has_head(&(v881_9)) { singleton(&[]) } else { Space::new() };
        drop(v881_9);
        let v881_12: Space = if (&(v881_10)).is_empty() { Space::new() } else {
          let v886_6: Path = concat_path(&(v880_6),&v878_15_cursor.path()[(v878_15_origin + 1)..(v878_15_origin + 2)]);
          let mut v886_11 = Space::new();
          let mut v886_11_write = v886_11.write_zipper();
          for v886_11_byte in v878_15_cursor.child_mask().iter() {
            v878_15_cursor.descend_to_existing_byte(v886_11_byte);
            {
            let v887_2: Space = singleton(&v878_15_cursor.path()[(v878_15_origin + 2)..(v878_15_origin + 3)]);
            let v887_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v887_2));
            let v887_4: Space = if map_kernels::has_head(&(v887_3)) { singleton(&[]) } else { Space::new() };
            drop(v887_3);
            let v887_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v887_4));
            drop(v887_4);
            let v887_8: Space = if (&(v887_5)).is_empty() { Space::new() } else {
              let v888_6: Path = concat_path(&(v886_6),&v878_15_cursor.path()[(v878_15_origin + 2)..(v878_15_origin + 3)]);
              let v888_7: Space = routine_56(c, &(v888_6), &(*p1), &v878_15_cursor);
              map_map_kernels::compose(&(v887_5),&(v888_7))
            };
            drop(v887_5);
            let v887_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v887_2));
            drop(v887_2);
            let v887_10: Space = if map_kernels::has_head(&(v887_9)) { singleton(&[]) } else { Space::new() };
            drop(v887_9);
            let v887_12: Space = if (&(v887_10)).is_empty() { Space::new() } else {
              let v889_6: Path = concat_path(&(v886_6),&v878_15_cursor.path()[(v878_15_origin + 2)..(v878_15_origin + 3)]);
              let v889_11: Space = routine_19(c, &(v889_6), &(*p1), &v878_15_cursor);
              drop(v889_6);
              map_map_kernels::compose(&(v887_10),&(v889_11))
            };
            drop(v887_10);
            let v887_13: Space = map_map_kernels::unite(&(v887_8),&(v887_12));
            join_wrapped_into(&mut v886_11_write,&((v887_13).read_zipper()),&[]);
            }
            v878_15_cursor.ascend(1);
          }
          drop(v886_11_write);
          drop(v886_6);
          map_map_kernels::compose(&(v881_10),&(v886_11))
        };
        drop(v881_10);
        let v881_13: Space = map_map_kernels::unite(&(v881_8),&(v881_12));
        join_wrapped_into(&mut v880_7_write,&((v881_13).read_zipper()),&[]);
        }
        v878_15_cursor.ascend(1);
      }
      drop(v880_7_write);
      map_map_kernels::compose(&(v879_5),&(v880_7))
    };
    drop(v879_5);
    let v879_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v879_2));
    drop(v879_2);
    let v879_10: Space = if map_kernels::has_head(&(v879_9)) { singleton(&[]) } else { Space::new() };
    drop(v879_9);
    let v879_11: Space = map_view_kernels::compose(&(v879_10),&v878_15_cursor);
    drop(v879_10);
    let v890_6: Path = concat_path(&(*p0),&v878_15_cursor.path()[v878_15_origin..(v878_15_origin + 1)]);
    let v879_12: Space = map_kernels::wrap(&(v879_11),&(v890_6));
    drop(v879_11);
    let v879_13: Space = map_kernels::wrap(&(v879_12),&(*p1));
    drop(v879_12);
    let v879_14: Space = map_map_kernels::unite(&(v879_8),&(v879_13));
    drop(v879_13);
    join_wrapped_into(&mut v878_15_write,&((v879_14).read_zipper()),&[]);
    }
    v878_15_cursor.ascend(1);
  }
  drop(v878_15_cursor);
  drop(v878_15_write);
  (v878_15).clone()
}

fn routine_48(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v891_12 = Space::new();
  let mut v891_12_write = v891_12.write_zipper();
  let mut v891_12_cursor = (*s0).read_zipper();
  let v891_12_origin = v891_12_cursor.path().len();
  for v891_12_byte in v891_12_cursor.child_mask().iter() {
    v891_12_cursor.descend_to_existing_byte(v891_12_byte);
    {
    let v892_2: Space = singleton(&v891_12_cursor.path()[v891_12_origin..(v891_12_origin + 1)]);
    let v892_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v892_2));
    drop(v892_2);
    let v892_4: Space = if map_kernels::has_head(&(v892_3)) { singleton(&[]) } else { Space::new() };
    drop(v892_3);
    let v892_7: Space = if (&(v892_4)).is_empty() { Space::new() } else {
      let mut v893_6 = Space::new();
      let mut v893_6_write = v893_6.write_zipper();
      for v893_6_byte in v891_12_cursor.child_mask().iter() {
        v891_12_cursor.descend_to_existing_byte(v893_6_byte);
        {
        let v894_2: Space = singleton(&v891_12_cursor.path()[(v891_12_origin + 1)..(v891_12_origin + 2)]);
        let v894_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v894_2));
        drop(v894_2);
        let v894_4: Space = if map_kernels::has_head(&(v894_3)) { singleton(&[]) } else { Space::new() };
        drop(v894_3);
        let v894_7: Space = if (&(v894_4)).is_empty() { Space::new() } else {
          let mut v895_6 = Space::new();
          let mut v895_6_write = v895_6.write_zipper();
          let mut v895_6_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v891_12_cursor.path()[v891_12_origin..(v891_12_origin + 1)]),&v891_12_cursor.path()[(v891_12_origin + 1)..(v891_12_origin + 2)]);
          let v895_6_origin = v895_6_cursor.path().len();
          for v895_6_byte in v895_6_cursor.child_mask().iter() {
            v895_6_cursor.descend_to_existing_byte(v895_6_byte);
            {
            let v896_2: Space = singleton(&v895_6_cursor.path()[v895_6_origin..(v895_6_origin + 1)]);
            let v896_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v896_2));
            let v896_4: Space = if map_kernels::has_head(&(v896_3)) { singleton(&[]) } else { Space::new() };
            drop(v896_3);
            let v896_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v896_4));
            drop(v896_4);
            let v896_7: Space = if (&(v896_5)).is_empty() { Space::new() } else {
              let v897_6: Space = routine_13(c, &v895_6_cursor.path()[v895_6_origin..(v895_6_origin + 1)], &(*p1), &v895_6_cursor);
              map_map_kernels::compose(&(v896_5),&(v897_6))
            };
            drop(v896_5);
            let v896_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v896_2));
            drop(v896_2);
            let v896_9: Space = if map_kernels::has_head(&(v896_8)) { singleton(&[]) } else { Space::new() };
            drop(v896_8);
            let v896_11: Space = if (&(v896_9)).is_empty() { Space::new() } else {
              let v898_10: Space = routine_14(c, &v895_6_cursor.path()[v895_6_origin..(v895_6_origin + 1)], &(*p1), &v895_6_cursor);
              map_map_kernels::compose(&(v896_9),&(v898_10))
            };
            drop(v896_9);
            let v896_12: Space = map_map_kernels::unite(&(v896_7),&(v896_11));
            join_wrapped_into(&mut v895_6_write,&((v896_12).read_zipper()),&[]);
            }
            v895_6_cursor.ascend(1);
          }
          drop(v895_6_cursor);
          drop(v895_6_write);
          map_map_kernels::compose(&(v894_4),&(v895_6))
        };
        drop(v894_4);
        join_wrapped_into(&mut v893_6_write,&((v894_7).read_zipper()),&[]);
        }
        v891_12_cursor.ascend(1);
      }
      drop(v893_6_write);
      map_map_kernels::compose(&(v892_4),&(v893_6))
    };
    drop(v892_4);
    join_wrapped_into(&mut v891_12_write,&((v892_7).read_zipper()),&[]);
    }
    v891_12_cursor.ascend(1);
  }
  drop(v891_12_cursor);
  drop(v891_12_write);
  (v891_12).clone()
}

fn routine_49(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v899_17 = Space::new();
  let mut v899_17_write = v899_17.write_zipper();
  let mut v899_17_cursor = (*s0).read_zipper();
  let v899_17_origin = v899_17_cursor.path().len();
  for v899_17_byte in v899_17_cursor.child_mask().iter() {
    v899_17_cursor.descend_to_existing_byte(v899_17_byte);
    {
    let v900_2: Space = singleton(&v899_17_cursor.path()[v899_17_origin..(v899_17_origin + 1)]);
    let v900_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v900_2));
    drop(v900_2);
    let v900_4: Space = if map_kernels::has_head(&(v900_3)) { singleton(&[]) } else { Space::new() };
    drop(v900_3);
    let v900_7: Space = if (&(v900_4)).is_empty() { Space::new() } else {
      let mut v901_6 = Space::new();
      let mut v901_6_write = v901_6.write_zipper();
      let mut v901_6_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v899_17_cursor.path()[v899_17_origin..(v899_17_origin + 1)]);
      let v901_6_origin = v901_6_cursor.path().len();
      for v901_6_byte in v901_6_cursor.child_mask().iter() {
        v901_6_cursor.descend_to_existing_byte(v901_6_byte);
        {
        let v902_2: Space = singleton(&v901_6_cursor.path()[v901_6_origin..(v901_6_origin + 1)]);
        let v902_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v902_2));
        let v902_4: Space = if map_kernels::has_head(&(v902_3)) { singleton(&[]) } else { Space::new() };
        drop(v902_3);
        let v902_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v902_4));
        drop(v902_4);
        let v902_7: Space = if (&(v902_5)).is_empty() { Space::new() } else {
          let mut v903_6 = Space::new();
          let mut v903_6_write = v903_6.write_zipper();
          for v903_6_byte in v901_6_cursor.child_mask().iter() {
            v901_6_cursor.descend_to_existing_byte(v903_6_byte);
            {
            let v904_2: Space = singleton(&v901_6_cursor.path()[(v901_6_origin + 1)..(v901_6_origin + 2)]);
            let v904_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v904_2));
            let v904_4: Space = if map_kernels::has_head(&(v904_3)) { singleton(&[]) } else { Space::new() };
            drop(v904_3);
            let v904_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v904_4));
            drop(v904_4);
            let v904_8: Space = if (&(v904_5)).is_empty() { Space::new() } else {
              let v905_7: Space = routine_17(c, &v901_6_cursor.path()[v901_6_origin..(v901_6_origin + 2)], &(*p1), &v901_6_cursor);
              map_map_kernels::compose(&(v904_5),&(v905_7))
            };
            drop(v904_5);
            let v904_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v904_2));
            drop(v904_2);
            let v904_10: Space = if map_kernels::has_head(&(v904_9)) { singleton(&[]) } else { Space::new() };
            drop(v904_9);
            let v904_12: Space = if (&(v904_10)).is_empty() { Space::new() } else {
              let v906_11: Space = routine_18(c, &v901_6_cursor.path()[v901_6_origin..(v901_6_origin + 2)], &(*p1), &v901_6_cursor);
              map_map_kernels::compose(&(v904_10),&(v906_11))
            };
            drop(v904_10);
            let v904_13: Space = map_map_kernels::unite(&(v904_8),&(v904_12));
            join_wrapped_into(&mut v903_6_write,&((v904_13).read_zipper()),&[]);
            }
            v901_6_cursor.ascend(1);
          }
          drop(v903_6_write);
          map_map_kernels::compose(&(v902_5),&(v903_6))
        };
        drop(v902_5);
        let v902_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v902_2));
        drop(v902_2);
        let v902_9: Space = if map_kernels::has_head(&(v902_8)) { singleton(&[]) } else { Space::new() };
        drop(v902_8);
        let v902_11: Space = if (&(v902_9)).is_empty() { Space::new() } else {
          let mut v907_10 = Space::new();
          let mut v907_10_write = v907_10.write_zipper();
          for v907_10_byte in v901_6_cursor.child_mask().iter() {
            v901_6_cursor.descend_to_existing_byte(v907_10_byte);
            {
            let v908_2: Space = singleton(&v901_6_cursor.path()[(v901_6_origin + 1)..(v901_6_origin + 2)]);
            let v908_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v908_2));
            let v908_4: Space = if map_kernels::has_head(&(v908_3)) { singleton(&[]) } else { Space::new() };
            drop(v908_3);
            let v908_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v908_4));
            drop(v908_4);
            let v908_8: Space = if (&(v908_5)).is_empty() { Space::new() } else {
              let v909_7: Space = routine_17(c, &v901_6_cursor.path()[v901_6_origin..(v901_6_origin + 2)], &(*p1), &v901_6_cursor);
              map_map_kernels::compose(&(v908_5),&(v909_7))
            };
            drop(v908_5);
            let v908_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v908_2));
            drop(v908_2);
            let v908_10: Space = if map_kernels::has_head(&(v908_9)) { singleton(&[]) } else { Space::new() };
            drop(v908_9);
            let v908_12: Space = if (&(v908_10)).is_empty() { Space::new() } else {
              let v910_11: Space = routine_19(c, &v901_6_cursor.path()[v901_6_origin..(v901_6_origin + 2)], &(*p1), &v901_6_cursor);
              map_map_kernels::compose(&(v908_10),&(v910_11))
            };
            drop(v908_10);
            let v908_13: Space = map_map_kernels::unite(&(v908_8),&(v908_12));
            join_wrapped_into(&mut v907_10_write,&((v908_13).read_zipper()),&[]);
            }
            v901_6_cursor.ascend(1);
          }
          drop(v907_10_write);
          map_map_kernels::compose(&(v902_9),&(v907_10))
        };
        drop(v902_9);
        let v902_12: Space = map_map_kernels::unite(&(v902_7),&(v902_11));
        join_wrapped_into(&mut v901_6_write,&((v902_12).read_zipper()),&[]);
        }
        v901_6_cursor.ascend(1);
      }
      drop(v901_6_cursor);
      drop(v901_6_write);
      map_map_kernels::compose(&(v900_4),&(v901_6))
    };
    drop(v900_4);
    join_wrapped_into(&mut v899_17_write,&((v900_7).read_zipper()),&[]);
    }
    v899_17_cursor.ascend(1);
  }
  drop(v899_17_cursor);
  drop(v899_17_write);
  (v899_17).clone()
}

fn routine_50(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v911_21 = Space::new();
  let mut v911_21_write = v911_21.write_zipper();
  let mut v911_21_cursor = (*s0).read_zipper();
  let v911_21_origin = v911_21_cursor.path().len();
  for v911_21_byte in v911_21_cursor.child_mask().iter() {
    v911_21_cursor.descend_to_existing_byte(v911_21_byte);
    {
    let v912_2: Space = singleton(&v911_21_cursor.path()[v911_21_origin..(v911_21_origin + 1)]);
    let v912_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v912_2));
    let v912_4: Space = if map_kernels::has_head(&(v912_3)) { singleton(&[]) } else { Space::new() };
    drop(v912_3);
    let v912_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v912_4));
    drop(v912_4);
    let v912_8: Space = if (&(v912_5)).is_empty() { Space::new() } else {
      let v913_6: Path = concat_path(&(*p0),&v911_21_cursor.path()[v911_21_origin..(v911_21_origin + 1)]);
      let mut v913_7 = Space::new();
      let mut v913_7_write = v913_7.write_zipper();
      for v913_7_byte in v911_21_cursor.child_mask().iter() {
        v911_21_cursor.descend_to_existing_byte(v913_7_byte);
        {
        let v914_2: Space = singleton(&v911_21_cursor.path()[(v911_21_origin + 1)..(v911_21_origin + 2)]);
        let v914_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v914_2));
        let v914_4: Space = if map_kernels::has_head(&(v914_3)) { singleton(&[]) } else { Space::new() };
        drop(v914_3);
        let v914_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v914_4));
        drop(v914_4);
        let v914_8: Space = if (&(v914_5)).is_empty() { Space::new() } else {
          let v915_6: Path = concat_path(&(v913_6),&v911_21_cursor.path()[(v911_21_origin + 1)..(v911_21_origin + 2)]);
          let mut v915_7 = Space::new();
          let mut v915_7_write = v915_7.write_zipper();
          for v915_7_byte in v911_21_cursor.child_mask().iter() {
            v911_21_cursor.descend_to_existing_byte(v915_7_byte);
            {
            let v916_2: Space = singleton(&v911_21_cursor.path()[(v911_21_origin + 2)..(v911_21_origin + 3)]);
            let v916_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v916_2));
            let v916_4: Space = if map_kernels::has_head(&(v916_3)) { singleton(&[]) } else { Space::new() };
            drop(v916_3);
            let v916_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v916_4));
            drop(v916_4);
            let v916_8: Space = if (&(v916_5)).is_empty() { Space::new() } else {
              let v917_6: Path = concat_path(&(v915_6),&v911_21_cursor.path()[(v911_21_origin + 2)..(v911_21_origin + 3)]);
              let v917_7: Space = routine_58(c, &(v917_6), &(*p1), &v911_21_cursor);
              map_map_kernels::compose(&(v916_5),&(v917_7))
            };
            drop(v916_5);
            let v916_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v916_2));
            drop(v916_2);
            let v916_10: Space = if map_kernels::has_head(&(v916_9)) { singleton(&[]) } else { Space::new() };
            drop(v916_9);
            let v916_12: Space = if (&(v916_10)).is_empty() { Space::new() } else {
              let v918_6: Path = concat_path(&(v915_6),&v911_21_cursor.path()[(v911_21_origin + 2)..(v911_21_origin + 3)]);
              let v918_11: Space = routine_59(c, &(v918_6), &(*p1), &v911_21_cursor);
              drop(v918_6);
              map_map_kernels::compose(&(v916_10),&(v918_11))
            };
            drop(v916_10);
            let v916_13: Space = map_map_kernels::unite(&(v916_8),&(v916_12));
            join_wrapped_into(&mut v915_7_write,&((v916_13).read_zipper()),&[]);
            }
            v911_21_cursor.ascend(1);
          }
          drop(v915_7_write);
          map_map_kernels::compose(&(v914_5),&(v915_7))
        };
        drop(v914_5);
        let v914_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v914_2));
        drop(v914_2);
        let v914_10: Space = if map_kernels::has_head(&(v914_9)) { singleton(&[]) } else { Space::new() };
        drop(v914_9);
        let v914_12: Space = if (&(v914_10)).is_empty() { Space::new() } else {
          let v919_6: Path = concat_path(&(v913_6),&v911_21_cursor.path()[(v911_21_origin + 1)..(v911_21_origin + 2)]);
          let mut v919_11 = Space::new();
          let mut v919_11_write = v919_11.write_zipper();
          for v919_11_byte in v911_21_cursor.child_mask().iter() {
            v911_21_cursor.descend_to_existing_byte(v919_11_byte);
            {
            let v920_2: Space = singleton(&v911_21_cursor.path()[(v911_21_origin + 2)..(v911_21_origin + 3)]);
            let v920_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v920_2));
            let v920_4: Space = if map_kernels::has_head(&(v920_3)) { singleton(&[]) } else { Space::new() };
            drop(v920_3);
            let v920_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v920_4));
            drop(v920_4);
            let v920_8: Space = if (&(v920_5)).is_empty() { Space::new() } else {
              let v921_6: Path = concat_path(&(v919_6),&v911_21_cursor.path()[(v911_21_origin + 2)..(v911_21_origin + 3)]);
              let v921_7: Space = routine_58(c, &(v921_6), &(*p1), &v911_21_cursor);
              map_map_kernels::compose(&(v920_5),&(v921_7))
            };
            drop(v920_5);
            let v920_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v920_2));
            drop(v920_2);
            let v920_10: Space = if map_kernels::has_head(&(v920_9)) { singleton(&[]) } else { Space::new() };
            drop(v920_9);
            let v920_12: Space = if (&(v920_10)).is_empty() { Space::new() } else {
              let v922_6: Path = concat_path(&(v919_6),&v911_21_cursor.path()[(v911_21_origin + 2)..(v911_21_origin + 3)]);
              let v922_11: Space = routine_19(c, &(v922_6), &(*p1), &v911_21_cursor);
              drop(v922_6);
              map_map_kernels::compose(&(v920_10),&(v922_11))
            };
            drop(v920_10);
            let v920_13: Space = map_map_kernels::unite(&(v920_8),&(v920_12));
            join_wrapped_into(&mut v919_11_write,&((v920_13).read_zipper()),&[]);
            }
            v911_21_cursor.ascend(1);
          }
          drop(v919_11_write);
          drop(v919_6);
          map_map_kernels::compose(&(v914_10),&(v919_11))
        };
        drop(v914_10);
        let v914_13: Space = map_map_kernels::unite(&(v914_8),&(v914_12));
        join_wrapped_into(&mut v913_7_write,&((v914_13).read_zipper()),&[]);
        }
        v911_21_cursor.ascend(1);
      }
      drop(v913_7_write);
      map_map_kernels::compose(&(v912_5),&(v913_7))
    };
    drop(v912_5);
    let v912_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v912_2));
    drop(v912_2);
    let v912_10: Space = if map_kernels::has_head(&(v912_9)) { singleton(&[]) } else { Space::new() };
    drop(v912_9);
    let v912_12: Space = if (&(v912_10)).is_empty() { Space::new() } else {
      let v923_6: Path = concat_path(&(*p0),&v911_21_cursor.path()[v911_21_origin..(v911_21_origin + 1)]);
      let mut v923_11 = Space::new();
      let mut v923_11_write = v923_11.write_zipper();
      for v923_11_byte in v911_21_cursor.child_mask().iter() {
        v911_21_cursor.descend_to_existing_byte(v923_11_byte);
        {
        let v924_2: Space = singleton(&v911_21_cursor.path()[(v911_21_origin + 1)..(v911_21_origin + 2)]);
        let v924_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v924_2));
        let v924_4: Space = if map_kernels::has_head(&(v924_3)) { singleton(&[]) } else { Space::new() };
        drop(v924_3);
        let v924_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v924_4));
        drop(v924_4);
        let v924_8: Space = if (&(v924_5)).is_empty() { Space::new() } else {
          let v925_6: Path = concat_path(&(v923_6),&v911_21_cursor.path()[(v911_21_origin + 1)..(v911_21_origin + 2)]);
          let mut v925_7 = Space::new();
          let mut v925_7_write = v925_7.write_zipper();
          for v925_7_byte in v911_21_cursor.child_mask().iter() {
            v911_21_cursor.descend_to_existing_byte(v925_7_byte);
            {
            let v926_2: Space = singleton(&v911_21_cursor.path()[(v911_21_origin + 2)..(v911_21_origin + 3)]);
            let v926_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v926_2));
            let v926_4: Space = if map_kernels::has_head(&(v926_3)) { singleton(&[]) } else { Space::new() };
            drop(v926_3);
            let v926_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v926_4));
            drop(v926_4);
            let v926_8: Space = if (&(v926_5)).is_empty() { Space::new() } else {
              let v927_6: Path = concat_path(&(v925_6),&v911_21_cursor.path()[(v911_21_origin + 2)..(v911_21_origin + 3)]);
              let v927_7: Space = routine_58(c, &(v927_6), &(*p1), &v911_21_cursor);
              map_map_kernels::compose(&(v926_5),&(v927_7))
            };
            drop(v926_5);
            let v926_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v926_2));
            drop(v926_2);
            let v926_10: Space = if map_kernels::has_head(&(v926_9)) { singleton(&[]) } else { Space::new() };
            drop(v926_9);
            let v926_12: Space = if (&(v926_10)).is_empty() { Space::new() } else {
              let v928_6: Path = concat_path(&(v925_6),&v911_21_cursor.path()[(v911_21_origin + 2)..(v911_21_origin + 3)]);
              let v928_11: Space = routine_59(c, &(v928_6), &(*p1), &v911_21_cursor);
              drop(v928_6);
              map_map_kernels::compose(&(v926_10),&(v928_11))
            };
            drop(v926_10);
            let v926_13: Space = map_map_kernels::unite(&(v926_8),&(v926_12));
            join_wrapped_into(&mut v925_7_write,&((v926_13).read_zipper()),&[]);
            }
            v911_21_cursor.ascend(1);
          }
          drop(v925_7_write);
          map_map_kernels::compose(&(v924_5),&(v925_7))
        };
        drop(v924_5);
        let v924_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v924_2));
        drop(v924_2);
        let v924_10: Space = if map_kernels::has_head(&(v924_9)) { singleton(&[]) } else { Space::new() };
        drop(v924_9);
        let v924_11: Space = map_view_kernels::compose(&(v924_10),&v911_21_cursor);
        drop(v924_10);
        let v929_6: Path = concat_path(&(v923_6),&v911_21_cursor.path()[(v911_21_origin + 1)..(v911_21_origin + 2)]);
        let v924_12: Space = map_kernels::wrap(&(v924_11),&(v929_6));
        drop(v924_11);
        let v924_13: Space = map_kernels::wrap(&(v924_12),&(*p1));
        drop(v924_12);
        let v924_14: Space = map_map_kernels::unite(&(v924_8),&(v924_13));
        drop(v924_13);
        join_wrapped_into(&mut v923_11_write,&((v924_14).read_zipper()),&[]);
        }
        v911_21_cursor.ascend(1);
      }
      drop(v923_11_write);
      drop(v923_6);
      map_map_kernels::compose(&(v912_10),&(v923_11))
    };
    drop(v912_10);
    let v912_13: Space = map_map_kernels::unite(&(v912_8),&(v912_12));
    join_wrapped_into(&mut v911_21_write,&((v912_13).read_zipper()),&[]);
    }
    v911_21_cursor.ascend(1);
  }
  drop(v911_21_cursor);
  drop(v911_21_write);
  (v911_21).clone()
}

fn routine_51(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v930_15 = Space::new();
  let mut v930_15_write = v930_15.write_zipper();
  let mut v930_15_cursor = (*s0).read_zipper();
  let v930_15_origin = v930_15_cursor.path().len();
  for v930_15_byte in v930_15_cursor.child_mask().iter() {
    v930_15_cursor.descend_to_existing_byte(v930_15_byte);
    {
    let v931_2: Space = singleton(&v930_15_cursor.path()[v930_15_origin..(v930_15_origin + 1)]);
    let v931_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v931_2));
    let v931_4: Space = if map_kernels::has_head(&(v931_3)) { singleton(&[]) } else { Space::new() };
    drop(v931_3);
    let v931_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v931_4));
    drop(v931_4);
    let v931_8: Space = if (&(v931_5)).is_empty() { Space::new() } else {
      let v932_6: Path = concat_path(&(*p0),&v930_15_cursor.path()[v930_15_origin..(v930_15_origin + 1)]);
      let mut v932_7 = Space::new();
      let mut v932_7_write = v932_7.write_zipper();
      for v932_7_byte in v930_15_cursor.child_mask().iter() {
        v930_15_cursor.descend_to_existing_byte(v932_7_byte);
        {
        let v933_2: Space = singleton(&v930_15_cursor.path()[(v930_15_origin + 1)..(v930_15_origin + 2)]);
        let v933_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v933_2));
        let v933_4: Space = if map_kernels::has_head(&(v933_3)) { singleton(&[]) } else { Space::new() };
        drop(v933_3);
        let v933_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v933_4));
        drop(v933_4);
        let v933_8: Space = if (&(v933_5)).is_empty() { Space::new() } else {
          let v934_6: Path = concat_path(&(v932_6),&v930_15_cursor.path()[(v930_15_origin + 1)..(v930_15_origin + 2)]);
          let mut v934_7 = Space::new();
          let mut v934_7_write = v934_7.write_zipper();
          for v934_7_byte in v930_15_cursor.child_mask().iter() {
            v930_15_cursor.descend_to_existing_byte(v934_7_byte);
            {
            let v935_2: Space = singleton(&v930_15_cursor.path()[(v930_15_origin + 2)..(v930_15_origin + 3)]);
            let v935_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v935_2));
            let v935_4: Space = if map_kernels::has_head(&(v935_3)) { singleton(&[]) } else { Space::new() };
            drop(v935_3);
            let v935_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v935_4));
            drop(v935_4);
            let v935_8: Space = if (&(v935_5)).is_empty() { Space::new() } else {
              let v936_6: Path = concat_path(&(v934_6),&v930_15_cursor.path()[(v930_15_origin + 2)..(v930_15_origin + 3)]);
              let v936_7: Space = routine_58(c, &(v936_6), &(*p1), &v930_15_cursor);
              map_map_kernels::compose(&(v935_5),&(v936_7))
            };
            drop(v935_5);
            let v935_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v935_2));
            drop(v935_2);
            let v935_10: Space = if map_kernels::has_head(&(v935_9)) { singleton(&[]) } else { Space::new() };
            drop(v935_9);
            let v935_12: Space = if (&(v935_10)).is_empty() { Space::new() } else {
              let v937_6: Path = concat_path(&(v934_6),&v930_15_cursor.path()[(v930_15_origin + 2)..(v930_15_origin + 3)]);
              let v937_11: Space = routine_59(c, &(v937_6), &(*p1), &v930_15_cursor);
              drop(v937_6);
              map_map_kernels::compose(&(v935_10),&(v937_11))
            };
            drop(v935_10);
            let v935_13: Space = map_map_kernels::unite(&(v935_8),&(v935_12));
            join_wrapped_into(&mut v934_7_write,&((v935_13).read_zipper()),&[]);
            }
            v930_15_cursor.ascend(1);
          }
          drop(v934_7_write);
          map_map_kernels::compose(&(v933_5),&(v934_7))
        };
        drop(v933_5);
        let v933_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v933_2));
        drop(v933_2);
        let v933_10: Space = if map_kernels::has_head(&(v933_9)) { singleton(&[]) } else { Space::new() };
        drop(v933_9);
        let v933_12: Space = if (&(v933_10)).is_empty() { Space::new() } else {
          let v938_6: Path = concat_path(&(v932_6),&v930_15_cursor.path()[(v930_15_origin + 1)..(v930_15_origin + 2)]);
          let mut v938_11 = Space::new();
          let mut v938_11_write = v938_11.write_zipper();
          for v938_11_byte in v930_15_cursor.child_mask().iter() {
            v930_15_cursor.descend_to_existing_byte(v938_11_byte);
            {
            let v939_2: Space = singleton(&v930_15_cursor.path()[(v930_15_origin + 2)..(v930_15_origin + 3)]);
            let v939_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v939_2));
            let v939_4: Space = if map_kernels::has_head(&(v939_3)) { singleton(&[]) } else { Space::new() };
            drop(v939_3);
            let v939_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v939_4));
            drop(v939_4);
            let v939_8: Space = if (&(v939_5)).is_empty() { Space::new() } else {
              let v940_6: Path = concat_path(&(v938_6),&v930_15_cursor.path()[(v930_15_origin + 2)..(v930_15_origin + 3)]);
              let v940_7: Space = routine_58(c, &(v940_6), &(*p1), &v930_15_cursor);
              map_map_kernels::compose(&(v939_5),&(v940_7))
            };
            drop(v939_5);
            let v939_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v939_2));
            drop(v939_2);
            let v939_10: Space = if map_kernels::has_head(&(v939_9)) { singleton(&[]) } else { Space::new() };
            drop(v939_9);
            let v939_12: Space = if (&(v939_10)).is_empty() { Space::new() } else {
              let v941_6: Path = concat_path(&(v938_6),&v930_15_cursor.path()[(v930_15_origin + 2)..(v930_15_origin + 3)]);
              let v941_11: Space = routine_19(c, &(v941_6), &(*p1), &v930_15_cursor);
              drop(v941_6);
              map_map_kernels::compose(&(v939_10),&(v941_11))
            };
            drop(v939_10);
            let v939_13: Space = map_map_kernels::unite(&(v939_8),&(v939_12));
            join_wrapped_into(&mut v938_11_write,&((v939_13).read_zipper()),&[]);
            }
            v930_15_cursor.ascend(1);
          }
          drop(v938_11_write);
          drop(v938_6);
          map_map_kernels::compose(&(v933_10),&(v938_11))
        };
        drop(v933_10);
        let v933_13: Space = map_map_kernels::unite(&(v933_8),&(v933_12));
        join_wrapped_into(&mut v932_7_write,&((v933_13).read_zipper()),&[]);
        }
        v930_15_cursor.ascend(1);
      }
      drop(v932_7_write);
      map_map_kernels::compose(&(v931_5),&(v932_7))
    };
    drop(v931_5);
    let v931_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v931_2));
    drop(v931_2);
    let v931_10: Space = if map_kernels::has_head(&(v931_9)) { singleton(&[]) } else { Space::new() };
    drop(v931_9);
    let v931_11: Space = map_view_kernels::compose(&(v931_10),&v930_15_cursor);
    drop(v931_10);
    let v942_6: Path = concat_path(&(*p0),&v930_15_cursor.path()[v930_15_origin..(v930_15_origin + 1)]);
    let v931_12: Space = map_kernels::wrap(&(v931_11),&(v942_6));
    drop(v931_11);
    let v931_13: Space = map_kernels::wrap(&(v931_12),&(*p1));
    drop(v931_12);
    let v931_14: Space = map_map_kernels::unite(&(v931_8),&(v931_13));
    drop(v931_13);
    join_wrapped_into(&mut v930_15_write,&((v931_14).read_zipper()),&[]);
    }
    v930_15_cursor.ascend(1);
  }
  drop(v930_15_cursor);
  drop(v930_15_write);
  (v930_15).clone()
}

fn routine_52(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v943_4: Space = Space::new();
  (v943_4).clone()
}

fn routine_53(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v944_17 = Space::new();
  let mut v944_17_write = v944_17.write_zipper();
  let mut v944_17_cursor = (*s0).read_zipper();
  let v944_17_origin = v944_17_cursor.path().len();
  for v944_17_byte in v944_17_cursor.child_mask().iter() {
    v944_17_cursor.descend_to_existing_byte(v944_17_byte);
    {
    let v945_2: Space = singleton(&v944_17_cursor.path()[v944_17_origin..(v944_17_origin + 1)]);
    let v945_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v945_2));
    drop(v945_2);
    let v945_4: Space = if map_kernels::has_head(&(v945_3)) { singleton(&[]) } else { Space::new() };
    drop(v945_3);
    let v945_7: Space = if (&(v945_4)).is_empty() { Space::new() } else {
      let mut v946_6 = Space::new();
      let mut v946_6_write = v946_6.write_zipper();
      let mut v946_6_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v944_17_cursor.path()[v944_17_origin..(v944_17_origin + 1)]);
      let v946_6_origin = v946_6_cursor.path().len();
      for v946_6_byte in v946_6_cursor.child_mask().iter() {
        v946_6_cursor.descend_to_existing_byte(v946_6_byte);
        {
        let v947_2: Space = singleton(&v946_6_cursor.path()[v946_6_origin..(v946_6_origin + 1)]);
        let v947_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v947_2));
        let v947_4: Space = if map_kernels::has_head(&(v947_3)) { singleton(&[]) } else { Space::new() };
        drop(v947_3);
        let v947_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v947_4));
        drop(v947_4);
        let v947_7: Space = if (&(v947_5)).is_empty() { Space::new() } else {
          let mut v948_6 = Space::new();
          let mut v948_6_write = v948_6.write_zipper();
          for v948_6_byte in v946_6_cursor.child_mask().iter() {
            v946_6_cursor.descend_to_existing_byte(v948_6_byte);
            {
            let v949_2: Space = singleton(&v946_6_cursor.path()[(v946_6_origin + 1)..(v946_6_origin + 2)]);
            let v949_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v949_2));
            let v949_4: Space = if map_kernels::has_head(&(v949_3)) { singleton(&[]) } else { Space::new() };
            drop(v949_3);
            let v949_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v949_4));
            drop(v949_4);
            let v949_8: Space = if (&(v949_5)).is_empty() { Space::new() } else {
              let v950_7: Space = routine_17(c, &v946_6_cursor.path()[v946_6_origin..(v946_6_origin + 2)], &(*p1), &v946_6_cursor);
              map_map_kernels::compose(&(v949_5),&(v950_7))
            };
            drop(v949_5);
            let v949_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v949_2));
            drop(v949_2);
            let v949_10: Space = if map_kernels::has_head(&(v949_9)) { singleton(&[]) } else { Space::new() };
            drop(v949_9);
            let v949_12: Space = if (&(v949_10)).is_empty() { Space::new() } else {
              let v951_11: Space = routine_18(c, &v946_6_cursor.path()[v946_6_origin..(v946_6_origin + 2)], &(*p1), &v946_6_cursor);
              map_map_kernels::compose(&(v949_10),&(v951_11))
            };
            drop(v949_10);
            let v949_13: Space = map_map_kernels::unite(&(v949_8),&(v949_12));
            join_wrapped_into(&mut v948_6_write,&((v949_13).read_zipper()),&[]);
            }
            v946_6_cursor.ascend(1);
          }
          drop(v948_6_write);
          map_map_kernels::compose(&(v947_5),&(v948_6))
        };
        drop(v947_5);
        let v947_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v947_2));
        drop(v947_2);
        let v947_9: Space = if map_kernels::has_head(&(v947_8)) { singleton(&[]) } else { Space::new() };
        drop(v947_8);
        let v947_11: Space = if (&(v947_9)).is_empty() { Space::new() } else {
          let mut v952_10 = Space::new();
          let mut v952_10_write = v952_10.write_zipper();
          for v952_10_byte in v946_6_cursor.child_mask().iter() {
            v946_6_cursor.descend_to_existing_byte(v952_10_byte);
            {
            let v953_2: Space = singleton(&v946_6_cursor.path()[(v946_6_origin + 1)..(v946_6_origin + 2)]);
            let v953_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v953_2));
            let v953_4: Space = if map_kernels::has_head(&(v953_3)) { singleton(&[]) } else { Space::new() };
            drop(v953_3);
            let v953_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v953_4));
            drop(v953_4);
            let v953_8: Space = if (&(v953_5)).is_empty() { Space::new() } else {
              let v954_7: Space = routine_17(c, &v946_6_cursor.path()[v946_6_origin..(v946_6_origin + 2)], &(*p1), &v946_6_cursor);
              map_map_kernels::compose(&(v953_5),&(v954_7))
            };
            drop(v953_5);
            let v953_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v953_2));
            drop(v953_2);
            let v953_10: Space = if map_kernels::has_head(&(v953_9)) { singleton(&[]) } else { Space::new() };
            drop(v953_9);
            let v953_12: Space = if (&(v953_10)).is_empty() { Space::new() } else {
              let v955_11: Space = routine_19(c, &v946_6_cursor.path()[v946_6_origin..(v946_6_origin + 2)], &(*p1), &v946_6_cursor);
              map_map_kernels::compose(&(v953_10),&(v955_11))
            };
            drop(v953_10);
            let v953_13: Space = map_map_kernels::unite(&(v953_8),&(v953_12));
            join_wrapped_into(&mut v952_10_write,&((v953_13).read_zipper()),&[]);
            }
            v946_6_cursor.ascend(1);
          }
          drop(v952_10_write);
          map_map_kernels::compose(&(v947_9),&(v952_10))
        };
        drop(v947_9);
        let v947_12: Space = map_map_kernels::unite(&(v947_7),&(v947_11));
        join_wrapped_into(&mut v946_6_write,&((v947_12).read_zipper()),&[]);
        }
        v946_6_cursor.ascend(1);
      }
      drop(v946_6_cursor);
      drop(v946_6_write);
      map_map_kernels::compose(&(v945_4),&(v946_6))
    };
    drop(v945_4);
    join_wrapped_into(&mut v944_17_write,&((v945_7).read_zipper()),&[]);
    }
    v944_17_cursor.ascend(1);
  }
  drop(v944_17_cursor);
  drop(v944_17_write);
  (v944_17).clone()
}

fn routine_54(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v956_9 = Space::new();
  let mut v956_9_write = v956_9.write_zipper();
  let mut v956_9_cursor = (*s0).read_zipper();
  let v956_9_origin = v956_9_cursor.path().len();
  for v956_9_byte in v956_9_cursor.child_mask().iter() {
    v956_9_cursor.descend_to_existing_byte(v956_9_byte);
    {
    let v957_2: Space = singleton(&v956_9_cursor.path()[v956_9_origin..(v956_9_origin + 1)]);
    let v957_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v957_2));
    let v957_4: Space = if map_kernels::has_head(&(v957_3)) { singleton(&[]) } else { Space::new() };
    drop(v957_3);
    let v957_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v957_4));
    drop(v957_4);
    let v957_8: Space = if (&(v957_5)).is_empty() { Space::new() } else {
      let v958_6: Path = concat_path(&(*p0),&v956_9_cursor.path()[v956_9_origin..(v956_9_origin + 1)]);
      let mut v958_7 = Space::new();
      let mut v958_7_write = v958_7.write_zipper();
      for v958_7_byte in v956_9_cursor.child_mask().iter() {
        v956_9_cursor.descend_to_existing_byte(v958_7_byte);
        {
        let v959_2: Space = singleton(&v956_9_cursor.path()[(v956_9_origin + 1)..(v956_9_origin + 2)]);
        let v959_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v959_2));
        drop(v959_2);
        let v959_4: Space = if map_kernels::has_head(&(v959_3)) { singleton(&[]) } else { Space::new() };
        drop(v959_3);
        let v959_7: Space = if (&(v959_4)).is_empty() { Space::new() } else {
          let v960_5: Path = concat_path(&(v958_6),&v956_9_cursor.path()[(v956_9_origin + 1)..(v956_9_origin + 2)]);
          let mut v960_6 = Space::new();
          let mut v960_6_write = v960_6.write_zipper();
          for v960_6_byte in v956_9_cursor.child_mask().iter() {
            v956_9_cursor.descend_to_existing_byte(v960_6_byte);
            {
            let v961_2: Space = singleton(&v956_9_cursor.path()[(v956_9_origin + 2)..(v956_9_origin + 3)]);
            let v961_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v961_2));
            drop(v961_2);
            let v961_4: Space = if map_kernels::has_head(&(v961_3)) { singleton(&[]) } else { Space::new() };
            drop(v961_3);
            let v961_7: Space = if (&(v961_4)).is_empty() { Space::new() } else {
              let v962_5: Path = concat_path(&(v960_5),&v956_9_cursor.path()[(v956_9_origin + 2)..(v956_9_origin + 3)]);
              let v962_6: Space = routine_19(c, &(v962_5), &(*p1), &v956_9_cursor);
              drop(v962_5);
              map_map_kernels::compose(&(v961_4),&(v962_6))
            };
            drop(v961_4);
            join_wrapped_into(&mut v960_6_write,&((v961_7).read_zipper()),&[]);
            }
            v956_9_cursor.ascend(1);
          }
          drop(v960_6_write);
          drop(v960_5);
          map_map_kernels::compose(&(v959_4),&(v960_6))
        };
        drop(v959_4);
        join_wrapped_into(&mut v958_7_write,&((v959_7).read_zipper()),&[]);
        }
        v956_9_cursor.ascend(1);
      }
      drop(v958_7_write);
      map_map_kernels::compose(&(v957_5),&(v958_7))
    };
    drop(v957_5);
    let v957_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v957_2));
    drop(v957_2);
    let v957_10: Space = if map_kernels::has_head(&(v957_9)) { singleton(&[]) } else { Space::new() };
    drop(v957_9);
    let v957_12: Space = if (&(v957_10)).is_empty() { Space::new() } else {
      let v963_6: Path = concat_path(&(*p0),&v956_9_cursor.path()[v956_9_origin..(v956_9_origin + 1)]);
      let mut v963_11 = Space::new();
      let mut v963_11_write = v963_11.write_zipper();
      for v963_11_byte in v956_9_cursor.child_mask().iter() {
        v956_9_cursor.descend_to_existing_byte(v963_11_byte);
        {
        let v964_2: Space = singleton(&v956_9_cursor.path()[(v956_9_origin + 1)..(v956_9_origin + 2)]);
        let v964_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v964_2));
        drop(v964_2);
        let v964_4: Space = if map_kernels::has_head(&(v964_3)) { singleton(&[]) } else { Space::new() };
        drop(v964_3);
        let v964_5: Space = map_view_kernels::compose(&(v964_4),&v956_9_cursor);
        drop(v964_4);
        let v964_6: Path = concat_path(&(v963_6),&v956_9_cursor.path()[(v956_9_origin + 1)..(v956_9_origin + 2)]);
        join_wrapped_into(&mut v963_11_write,&((v964_5).read_zipper()),&(v964_6));
        drop(v964_5);
        drop(v964_6);
        }
        v956_9_cursor.ascend(1);
      }
      drop(v963_11_write);
      drop(v963_6);
      map_map_kernels::compose(&(v957_10),&(v963_11))
    };
    drop(v957_10);
    let v957_13: Space = map_kernels::wrap(&(v957_12),&(*p1));
    drop(v957_12);
    let v957_14: Space = map_map_kernels::unite(&(v957_8),&(v957_13));
    drop(v957_13);
    join_wrapped_into(&mut v956_9_write,&((v957_14).read_zipper()),&[]);
    }
    v956_9_cursor.ascend(1);
  }
  drop(v956_9_cursor);
  drop(v956_9_write);
  (v956_9).clone()
}

fn routine_55(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v965_8 = Space::new();
  let mut v965_8_write = v965_8.write_zipper();
  let mut v965_8_cursor = (*s0).read_zipper();
  let v965_8_origin = v965_8_cursor.path().len();
  for v965_8_byte in v965_8_cursor.child_mask().iter() {
    v965_8_cursor.descend_to_existing_byte(v965_8_byte);
    {
    let v966_2: Space = singleton(&v965_8_cursor.path()[v965_8_origin..(v965_8_origin + 1)]);
    let v966_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v966_2));
    let v966_4: Space = if map_kernels::has_head(&(v966_3)) { singleton(&[]) } else { Space::new() };
    drop(v966_3);
    let v966_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v966_4));
    drop(v966_4);
    let v966_8: Space = if (&(v966_5)).is_empty() { Space::new() } else {
      let v967_6: Path = concat_path(&(*p0),&v965_8_cursor.path()[v965_8_origin..(v965_8_origin + 1)]);
      let mut v967_7 = Space::new();
      let mut v967_7_write = v967_7.write_zipper();
      for v967_7_byte in v965_8_cursor.child_mask().iter() {
        v965_8_cursor.descend_to_existing_byte(v967_7_byte);
        {
        let v968_2: Space = singleton(&v965_8_cursor.path()[(v965_8_origin + 1)..(v965_8_origin + 2)]);
        let v968_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v968_2));
        drop(v968_2);
        let v968_4: Space = if map_kernels::has_head(&(v968_3)) { singleton(&[]) } else { Space::new() };
        drop(v968_3);
        let v968_7: Space = if (&(v968_4)).is_empty() { Space::new() } else {
          let v969_5: Path = concat_path(&(v967_6),&v965_8_cursor.path()[(v965_8_origin + 1)..(v965_8_origin + 2)]);
          let mut v969_6 = Space::new();
          let mut v969_6_write = v969_6.write_zipper();
          for v969_6_byte in v965_8_cursor.child_mask().iter() {
            v965_8_cursor.descend_to_existing_byte(v969_6_byte);
            {
            let v970_2: Space = singleton(&v965_8_cursor.path()[(v965_8_origin + 2)..(v965_8_origin + 3)]);
            let v970_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v970_2));
            drop(v970_2);
            let v970_4: Space = if map_kernels::has_head(&(v970_3)) { singleton(&[]) } else { Space::new() };
            drop(v970_3);
            let v970_7: Space = if (&(v970_4)).is_empty() { Space::new() } else {
              let v971_5: Path = concat_path(&(v969_5),&v965_8_cursor.path()[(v965_8_origin + 2)..(v965_8_origin + 3)]);
              let v971_6: Space = routine_19(c, &(v971_5), &(*p1), &v965_8_cursor);
              drop(v971_5);
              map_map_kernels::compose(&(v970_4),&(v971_6))
            };
            drop(v970_4);
            join_wrapped_into(&mut v969_6_write,&((v970_7).read_zipper()),&[]);
            }
            v965_8_cursor.ascend(1);
          }
          drop(v969_6_write);
          drop(v969_5);
          map_map_kernels::compose(&(v968_4),&(v969_6))
        };
        drop(v968_4);
        join_wrapped_into(&mut v967_7_write,&((v968_7).read_zipper()),&[]);
        }
        v965_8_cursor.ascend(1);
      }
      drop(v967_7_write);
      map_map_kernels::compose(&(v966_5),&(v967_7))
    };
    drop(v966_5);
    let v966_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v966_2));
    drop(v966_2);
    let v966_10: Space = if map_kernels::has_head(&(v966_9)) { singleton(&[]) } else { Space::new() };
    drop(v966_9);
    let v966_11: Space = map_view_kernels::compose(&(v966_10),&v965_8_cursor);
    drop(v966_10);
    let v972_6: Path = concat_path(&(*p0),&v965_8_cursor.path()[v965_8_origin..(v965_8_origin + 1)]);
    let v966_12: Space = map_kernels::wrap(&(v966_11),&(v972_6));
    drop(v966_11);
    let v966_13: Space = map_kernels::wrap(&(v966_12),&(*p1));
    drop(v966_12);
    let v966_14: Space = map_map_kernels::unite(&(v966_8),&(v966_13));
    drop(v966_13);
    join_wrapped_into(&mut v965_8_write,&((v966_14).read_zipper()),&[]);
    }
    v965_8_cursor.ascend(1);
  }
  drop(v965_8_cursor);
  drop(v965_8_write);
  (v965_8).clone()
}

fn routine_56(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v973_5 = Space::new();
  let mut v973_5_write = v973_5.write_zipper();
  let mut v973_5_cursor = (*s0).read_zipper();
  let v973_5_origin = v973_5_cursor.path().len();
  for v973_5_byte in v973_5_cursor.child_mask().iter() {
    v973_5_cursor.descend_to_existing_byte(v973_5_byte);
    {
    let v974_2: Space = singleton(&v973_5_cursor.path()[v973_5_origin..(v973_5_origin + 1)]);
    let v974_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v974_2));
    drop(v974_2);
    let v974_4: Space = if map_kernels::has_head(&(v974_3)) { singleton(&[]) } else { Space::new() };
    drop(v974_3);
    let v974_7: Space = if (&(v974_4)).is_empty() { Space::new() } else {
      let v975_5: Path = concat_path(&(*p0),&v973_5_cursor.path()[v973_5_origin..(v973_5_origin + 1)]);
      let mut v975_6 = Space::new();
      let mut v975_6_write = v975_6.write_zipper();
      for v975_6_byte in v973_5_cursor.child_mask().iter() {
        v973_5_cursor.descend_to_existing_byte(v975_6_byte);
        {
        let v976_2: Space = singleton(&v973_5_cursor.path()[(v973_5_origin + 1)..(v973_5_origin + 2)]);
        let v976_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v976_2));
        drop(v976_2);
        let v976_4: Space = if map_kernels::has_head(&(v976_3)) { singleton(&[]) } else { Space::new() };
        drop(v976_3);
        let v976_5: Space = map_view_kernels::compose(&(v976_4),&v973_5_cursor);
        drop(v976_4);
        let v976_6: Path = concat_path(&(v975_5),&v973_5_cursor.path()[(v973_5_origin + 1)..(v973_5_origin + 2)]);
        join_wrapped_into(&mut v975_6_write,&((v976_5).read_zipper()),&(v976_6));
        drop(v976_5);
        drop(v976_6);
        }
        v973_5_cursor.ascend(1);
      }
      drop(v975_6_write);
      drop(v975_5);
      map_map_kernels::compose(&(v974_4),&(v975_6))
    };
    drop(v974_4);
    join_wrapped_into(&mut v973_5_write,&((v974_7).read_zipper()),&[]);
    }
    v973_5_cursor.ascend(1);
  }
  drop(v973_5_cursor);
  drop(v973_5_write);
  let v973_6: Space = map_kernels::wrap(&(v973_5),&(*p1));
  drop(v973_5);
  (v973_6).clone()
}

fn routine_57(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v977_4 = Space::new();
  let mut v977_4_write = v977_4.write_zipper();
  let mut v977_4_cursor = (*s0).read_zipper();
  let v977_4_origin = v977_4_cursor.path().len();
  for v977_4_byte in v977_4_cursor.child_mask().iter() {
    v977_4_cursor.descend_to_existing_byte(v977_4_byte);
    {
    let v978_2: Space = singleton(&v977_4_cursor.path()[v977_4_origin..(v977_4_origin + 1)]);
    let v978_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v978_2));
    drop(v978_2);
    let v978_4: Space = if map_kernels::has_head(&(v978_3)) { singleton(&[]) } else { Space::new() };
    drop(v978_3);
    let v978_5: Space = map_view_kernels::compose(&(v978_4),&v977_4_cursor);
    drop(v978_4);
    let v978_6: Path = concat_path(&(*p0),&v977_4_cursor.path()[v977_4_origin..(v977_4_origin + 1)]);
    join_wrapped_into(&mut v977_4_write,&((v978_5).read_zipper()),&(v978_6));
    drop(v978_5);
    drop(v978_6);
    }
    v977_4_cursor.ascend(1);
  }
  drop(v977_4_cursor);
  drop(v977_4_write);
  let v977_5: Space = map_kernels::wrap(&(v977_4),&(*p1));
  drop(v977_4);
  (v977_5).clone()
}

fn routine_58(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v979_3: Space = Space::new();
  (v979_3).clone()
}

fn routine_59(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v980_4 = Space::new();
  let mut v980_4_write = v980_4.write_zipper();
  let mut v980_4_cursor = (*s0).read_zipper();
  let v980_4_origin = v980_4_cursor.path().len();
  for v980_4_byte in v980_4_cursor.child_mask().iter() {
    v980_4_cursor.descend_to_existing_byte(v980_4_byte);
    {
    let v981_2: Space = singleton(&v980_4_cursor.path()[v980_4_origin..(v980_4_origin + 1)]);
    let v981_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v981_2));
    drop(v981_2);
    let v981_4: Space = if map_kernels::has_head(&(v981_3)) { singleton(&[]) } else { Space::new() };
    drop(v981_3);
    let v981_5: Space = map_view_kernels::compose(&(v981_4),&v980_4_cursor);
    drop(v981_4);
    let v981_6: Path = concat_path(&(*p0),&v980_4_cursor.path()[v980_4_origin..(v980_4_origin + 1)]);
    join_wrapped_into(&mut v980_4_write,&((v981_5).read_zipper()),&(v981_6));
    drop(v981_5);
    drop(v981_6);
    }
    v980_4_cursor.ascend(1);
  }
  drop(v980_4_cursor);
  drop(v980_4_write);
  let v980_5: Space = map_kernels::wrap(&(v980_4),&(*p1));
  drop(v980_4);
  (v980_5).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
