#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4,101,100,103,101]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("255 2 1 0 2 2 1 2 3 2 2 4 3 2 5 4 2 6 5 2 7 6 2 8 7 2 9 8 2 10 9 2 11 10 2 12 11 2 13 12 2 14 13 2 15 14 2 16 15 2 17 16 2 18 17 2 19 18 2 20 19 2 21 20 2 22 21 2 23 22 2 24 23 2 25 24 2 26 25 2 27 26 2 28 27 2 29 28 2 30 29 2 31 30 2 32 31 2 33 32 2 34 33 2 35 34 2 36 35 2 37 36 2 38 37 2 39 38 2 40 39 2 41 40 2 42 41 2 43 42 2 44 43 2 45 44 2 46 45 2 47 46 2 48 47 2 49 48 2 50 49 2 51 50 2 52 51 2 53 52 2 54 53 2 55 54 2 56 55 2 57 56 2 58 57 2 59 58 2 60 59 2 61 60 2 62 61 2 63 62 2 64 63 2 65 64 2 66 65 2 67 66 2 68 67 2 69 68 2 70 69 2 71 70 2 72 71 2 73 72 2 74 73 2 75 74 2 76 75 2 77 76 2 78 77 2 79 78 2 80 79 2 81 80 2 82 81 2 83 82 2 84 83 2 85 84 2 86 85 2 87 86 2 88 87 2 89 88 2 90 89 2 91 90 2 92 91 2 93 92 2 94 93 2 95 94 2 96 95 2 97 96 2 98 97 2 99 98 2 100 99 2 101 100 2 102 101 2 103 102 2 104 103 2 105 104 2 106 105 2 107 106 2 108 107 2 109 108 2 110 109 2 111 110 2 112 111 2 113 112 2 114 113 2 115 114 2 116 115 2 117 116 2 118 117 2 119 118 2 120 119 2 121 120 2 122 121 2 123 122 2 124 123 2 125 124 2 126 125 2 127 126 2 128 127 2 129 128 2 130 129 2 131 130 2 132 131 2 133 132 2 134 133 2 135 134 2 136 135 2 137 136 2 138 137 2 139 138 2 140 139 2 141 140 2 142 141 2 143 142 2 144 143 2 145 144 2 146 145 2 147 146 2 148 147 2 149 148 2 150 149 2 151 150 2 152 151 2 153 152 2 154 153 2 155 154 2 156 155 2 157 156 2 158 157 2 159 158 2 160 159 2 161 160 2 162 161 2 163 162 2 164 163 2 165 164 2 166 165 2 167 166 2 168 167 2 169 168 2 170 169 2 171 170 2 172 171 2 173 172 2 174 173 2 175 174 2 176 175 2 177 176 2 178 177 2 179 178 2 180 179 2 181 180 2 182 181 2 183 182 2 184 183 2 185 184 2 186 185 2 187 186 2 188 187 2 189 188 2 190 189 2 191 190 2 192 191 2 193 192 2 194 193 2 195 194 2 196 195 2 197 196 2 198 197 2 199 198 2 200 199 2 201 200 2 202 201 2 203 202 2 204 203 2 205 204 2 206 205 2 207 206 2 208 207 2 209 208 2 210 209 2 211 210 2 212 211 2 213 212 2 214 213 2 215 214 2 216 215 2 217 216 2 218 217 2 219 218 2 220 219 2 221 220 2 222 221 2 223 222 2 224 223 2 225 224 2 226 225 2 227 226 2 228 227 2 229 228 2 230 229 2 231 230 2 232 231 2 233 232 2 234 233 2 235 234 2 236 235 2 237 236 2 238 237 2 239 238 2 240 239 2 241 240 2 242 241 2 243 242 2 244 243 2 245 244 2 246 245 2 247 246 2 248 247 2 249 248 2 250 249 2 251 250 2 252 251 2 253 252 2 254 253 2 255 254"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[5,100,101,108,116,97]));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[8,99,111,109,112,108,101,116,101]));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4,112,97,116,104]));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[5,100,101,108,116,97,4,112,97,116,104]));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[8,99,111,109,112,108,101,116,101,4,112,97,116,104]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_8 = Space::new();
  let mut v0_8_write = v0_8.write_zipper();
  let mut v0_8_cursor = descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0));
  let v0_8_origin = v0_8_cursor.path().len();
  for v0_8_byte in v0_8_cursor.child_mask().iter() {
    v0_8_cursor.descend_to_existing_byte(v0_8_byte);
    {
    let v1_2: Space = singleton(&v0_8_cursor.path()[v0_8_origin..(v0_8_origin + 1)]);
    let v1_3: Space = intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_8: Space = if (&(v1_5)).is_empty() { Space::new() } else {
      let mut v2_7 = Space::new();
      let mut v2_7_write = v2_7.write_zipper();
      let v2_7_arg_0: &[u8] = &(*CONSTANT_3);
      let v2_7_arg_1: &[u8] = &v0_8_cursor.path()[v0_8_origin..(v0_8_origin + 1)];
      let v2_7_arg_3: &Space = &(&v0_8_cursor).make_map();
      let mut v2_7_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&v0_8_cursor.path()[v0_8_origin..(v0_8_origin + 1)]);
      let v2_7_origin = v2_7_cursor.path().len();
      let mut v2_7_more = v2_7_cursor.is_val() || next_value_within(&mut v2_7_cursor,v2_7_origin);
      while v2_7_more {
        {
        let v2_7_depth = v2_7_cursor.path().len();
        let mut v3_4_cursor = (*v2_7_arg_3).read_zipper();
        let v3_4_origin = v3_4_cursor.path().len();
        for v3_4_byte in v3_4_cursor.child_mask().iter() {
          v3_4_cursor.descend_to_existing_byte(v3_4_byte);
          {
          let v4_2: Path = concat_path(&(*v2_7_arg_1),&v3_4_cursor.path()[v3_4_origin..(v3_4_origin + 1)]);
          let v4_3: Space = routine_1(c, &(v4_2), &v2_7_cursor.path()[v2_7_origin..v2_7_depth], &v3_4_cursor);
          drop(v4_2);
          join_wrapped_into(&mut v2_7_write,&((v4_3).read_zipper()),&[]);
          }
          v3_4_cursor.ascend(1);
        }
        drop(v3_4_cursor);
        }
        v2_7_more = next_value_within(&mut v2_7_cursor,v2_7_origin);
      }
      drop(v2_7_cursor);
      drop(v2_7_write);
      compose(&(v1_5),&(v2_7))
    };
    drop(v1_5);
    let v1_9: Space = intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_10: Space = if has_head(&(v1_9)) { singleton(&[]) } else { Space::new() };
    drop(v1_9);
    let v1_12: Space = if (&(v1_10)).is_empty() { Space::new() } else {
      let mut v5_11 = Space::new();
      let mut v5_11_write = v5_11.write_zipper();
      for v5_11_byte in v0_8_cursor.child_mask().iter() {
        v0_8_cursor.descend_to_existing_byte(v5_11_byte);
        {
        let v6_2: Space = routine_2(c, &v0_8_cursor.path()[(v0_8_origin + 1)..(v0_8_origin + 2)], &v0_8_cursor.path()[(v0_8_origin + 1)..(v0_8_origin + 2)], &v0_8_cursor.path()[v0_8_origin..(v0_8_origin + 1)], &v0_8_cursor);
        join_wrapped_into(&mut v5_11_write,&((v6_2).read_zipper()),&[]);
        }
        v0_8_cursor.ascend(1);
      }
      drop(v5_11_write);
      compose(&(v1_10),&(v5_11))
    };
    drop(v1_10);
    let v1_13: Space = unite(&(v1_8),&(v1_12));
    join_wrapped_into(&mut v0_8_write,&((v1_13).read_zipper()),&[]);
    }
    v0_8_cursor.ascend(1);
  }
  drop(v0_8_cursor);
  drop(v0_8_write);
  let v0_10: Space = wrap(&(v0_8),&(*CONSTANT_5));
  let v0_12: Space = wrap(&(*s0.expect("unbound native input")),&(*CONSTANT_6));
  let v0_13: Space = unite(&(v0_10),&(v0_12));
  drop(v0_12);
  let mut v0_33: Space = (v0_13).clone();
  loop {
    let mut v7_3 = Space::new();
    let mut v7_3_write = v7_3.write_zipper();
    let mut v7_3_cursor = descend_cursor(descend_cursor((v0_33).read_zipper(),&(*CONSTANT_5)),&(*CONSTANT_7));
    let v7_3_origin = v7_3_cursor.path().len();
    for v7_3_byte in v7_3_cursor.child_mask().iter() {
      v7_3_cursor.descend_to_existing_byte(v7_3_byte);
      {
      let v8_2: Space = singleton(&v7_3_cursor.path()[v7_3_origin..(v7_3_origin + 1)]);
      let v8_3: Space = intersect(&(*CONSTANT_2),&(v8_2));
      let v8_4: Space = if has_head(&(v8_3)) { singleton(&[]) } else { Space::new() };
      drop(v8_3);
      let v8_5: Space = subtract(&(*CONSTANT_1),&(v8_4));
      drop(v8_4);
      let v8_8: Space = if (&(v8_5)).is_empty() { Space::new() } else {
        let mut v9_7 = Space::new();
        let mut v9_7_write = v9_7.write_zipper();
        let v9_7_arg_0: &[u8] = &(*CONSTANT_3);
        let v9_7_arg_1: &[u8] = &v7_3_cursor.path()[v7_3_origin..(v7_3_origin + 1)];
        let v9_7_arg_3: &Space = &(&v7_3_cursor).make_map();
        let v9_7_arg_4: &Space = &(v0_33);
        let mut v9_7_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&v7_3_cursor.path()[v7_3_origin..(v7_3_origin + 1)]);
        let v9_7_origin = v9_7_cursor.path().len();
        let mut v9_7_more = v9_7_cursor.is_val() || next_value_within(&mut v9_7_cursor,v9_7_origin);
        while v9_7_more {
          {
          let v9_7_depth = v9_7_cursor.path().len();
          let mut v10_5_cursor = (*v9_7_arg_3).read_zipper();
          let v10_5_origin = v10_5_cursor.path().len();
          for v10_5_byte in v10_5_cursor.child_mask().iter() {
            v10_5_cursor.descend_to_existing_byte(v10_5_byte);
            {
            let v11_2: Path = concat_path(&(*v9_7_arg_1),&v10_5_cursor.path()[v10_5_origin..(v10_5_origin + 1)]);
            let v11_3: Space = routine_3(c, &(v11_2), &v9_7_cursor.path()[v9_7_origin..v9_7_depth], &v10_5_cursor, &((*v9_7_arg_4).read_zipper()));
            drop(v11_2);
            join_wrapped_into(&mut v9_7_write,&((v11_3).read_zipper()),&[]);
            }
            v10_5_cursor.ascend(1);
          }
          drop(v10_5_cursor);
          }
          v9_7_more = next_value_within(&mut v9_7_cursor,v9_7_origin);
        }
        drop(v9_7_cursor);
        drop(v9_7_write);
        compose(&(v8_5),&(v9_7))
      };
      drop(v8_5);
      let v8_9: Space = intersect(&(*CONSTANT_2),&(v8_2));
      drop(v8_2);
      let v8_10: Space = if has_head(&(v8_9)) { singleton(&[]) } else { Space::new() };
      drop(v8_9);
      let v8_12: Space = if (&(v8_10)).is_empty() { Space::new() } else {
        let mut v12_11 = Space::new();
        let mut v12_11_write = v12_11.write_zipper();
        for v12_11_byte in v7_3_cursor.child_mask().iter() {
          v7_3_cursor.descend_to_existing_byte(v12_11_byte);
          {
          let v13_2: Space = routine_4(c, &v7_3_cursor.path()[(v7_3_origin + 1)..(v7_3_origin + 2)], &v7_3_cursor.path()[(v7_3_origin + 1)..(v7_3_origin + 2)], &v7_3_cursor.path()[v7_3_origin..(v7_3_origin + 1)], &v7_3_cursor, &((v0_33).read_zipper()));
          join_wrapped_into(&mut v12_11_write,&((v13_2).read_zipper()),&[]);
          }
          v7_3_cursor.ascend(1);
        }
        drop(v12_11_write);
        compose(&(v8_10),&(v12_11))
      };
      drop(v8_10);
      let v8_13: Space = unite(&(v8_8),&(v8_12));
      join_wrapped_into(&mut v7_3_write,&((v8_13).read_zipper()),&[]);
      }
      v7_3_cursor.ascend(1);
    }
    drop(v7_3_cursor);
    drop(v7_3_write);
    let mut v7_4 = Space::new();
    let mut v7_4_write = v7_4.write_zipper();
    let mut v7_4_cursor = descend_cursor(descend_cursor((v0_33).read_zipper(),&(*CONSTANT_5)),&(*CONSTANT_7));
    let v7_4_origin = v7_4_cursor.path().len();
    for v7_4_byte in v7_4_cursor.child_mask().iter() {
      v7_4_cursor.descend_to_existing_byte(v7_4_byte);
      {
      let v14_2: Space = singleton(&v7_4_cursor.path()[v7_4_origin..(v7_4_origin + 1)]);
      let v14_3: Space = intersect(&(*CONSTANT_2),&(v14_2));
      let v14_4: Space = if has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
      drop(v14_3);
      let v14_5: Space = subtract(&(*CONSTANT_1),&(v14_4));
      drop(v14_4);
      let v14_8: Space = if (&(v14_5)).is_empty() { Space::new() } else {
        let mut v15_7 = Space::new();
        let mut v15_7_write = v15_7.write_zipper();
        let v15_7_arg_0: &[u8] = &(*CONSTANT_3);
        let v15_7_arg_1: &[u8] = &v7_4_cursor.path()[v7_4_origin..(v7_4_origin + 1)];
        let v15_7_arg_3: &Space = &(&v7_4_cursor).make_map();
        let v15_7_arg_4: &Space = &(v0_33);
        let mut v15_7_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&v7_4_cursor.path()[v7_4_origin..(v7_4_origin + 1)]);
        let v15_7_origin = v15_7_cursor.path().len();
        let mut v15_7_more = v15_7_cursor.is_val() || next_value_within(&mut v15_7_cursor,v15_7_origin);
        while v15_7_more {
          {
          let v15_7_depth = v15_7_cursor.path().len();
          let mut v16_5_cursor = (*v15_7_arg_3).read_zipper();
          let v16_5_origin = v16_5_cursor.path().len();
          for v16_5_byte in v16_5_cursor.child_mask().iter() {
            v16_5_cursor.descend_to_existing_byte(v16_5_byte);
            {
            let v17_2: Path = concat_path(&(*v15_7_arg_1),&v16_5_cursor.path()[v16_5_origin..(v16_5_origin + 1)]);
            let v17_3: Space = routine_5(c, &(v17_2), &v15_7_cursor.path()[v15_7_origin..v15_7_depth], &v16_5_cursor, &((*v15_7_arg_4).read_zipper()));
            drop(v17_2);
            join_wrapped_into(&mut v15_7_write,&((v17_3).read_zipper()),&[]);
            }
            v16_5_cursor.ascend(1);
          }
          drop(v16_5_cursor);
          }
          v15_7_more = next_value_within(&mut v15_7_cursor,v15_7_origin);
        }
        drop(v15_7_cursor);
        drop(v15_7_write);
        compose(&(v14_5),&(v15_7))
      };
      drop(v14_5);
      let v14_9: Space = intersect(&(*CONSTANT_2),&(v14_2));
      drop(v14_2);
      let v14_10: Space = if has_head(&(v14_9)) { singleton(&[]) } else { Space::new() };
      drop(v14_9);
      let v14_12: Space = if (&(v14_10)).is_empty() { Space::new() } else {
        let mut v18_11 = Space::new();
        let mut v18_11_write = v18_11.write_zipper();
        for v18_11_byte in v7_4_cursor.child_mask().iter() {
          v7_4_cursor.descend_to_existing_byte(v18_11_byte);
          {
          let v19_2: Space = routine_6(c, &v7_4_cursor.path()[(v7_4_origin + 1)..(v7_4_origin + 2)], &v7_4_cursor.path()[(v7_4_origin + 1)..(v7_4_origin + 2)], &v7_4_cursor.path()[v7_4_origin..(v7_4_origin + 1)], &v7_4_cursor, &((v0_33).read_zipper()));
          join_wrapped_into(&mut v18_11_write,&((v19_2).read_zipper()),&[]);
          }
          v7_4_cursor.ascend(1);
        }
        drop(v18_11_write);
        compose(&(v14_10),&(v18_11))
      };
      drop(v14_10);
      let v14_13: Space = unite(&(v14_8),&(v14_12));
      join_wrapped_into(&mut v7_4_write,&((v14_13).read_zipper()),&[]);
      }
      v7_4_cursor.ascend(1);
    }
    drop(v7_4_cursor);
    drop(v7_4_write);
    let v7_5: Space = unite(&(v7_3),&(v7_4));
    let mut v7_8 = Space::new();
    let mut v7_8_write = v7_8.write_zipper();
    let mut v7_8_cursor = descend_cursor(descend_cursor((v0_33).read_zipper(),&(*CONSTANT_6)),&(*CONSTANT_0));
    let v7_8_origin = v7_8_cursor.path().len();
    for v7_8_byte in v7_8_cursor.child_mask().iter() {
      v7_8_cursor.descend_to_existing_byte(v7_8_byte);
      {
      let v20_2: Space = singleton(&v7_8_cursor.path()[v7_8_origin..(v7_8_origin + 1)]);
      let v20_3: Space = intersect(&(*CONSTANT_2),&(v20_2));
      let v20_4: Space = if has_head(&(v20_3)) { singleton(&[]) } else { Space::new() };
      drop(v20_3);
      let v20_5: Space = subtract(&(*CONSTANT_1),&(v20_4));
      drop(v20_4);
      let v20_8: Space = if (&(v20_5)).is_empty() { Space::new() } else {
        let mut v21_7 = Space::new();
        let mut v21_7_write = v21_7.write_zipper();
        let v21_7_arg_0: &[u8] = &(*CONSTANT_3);
        let v21_7_arg_1: &[u8] = &v7_8_cursor.path()[v7_8_origin..(v7_8_origin + 1)];
        let v21_7_arg_3: &Space = &(&v7_8_cursor).make_map();
        let mut v21_7_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&v7_8_cursor.path()[v7_8_origin..(v7_8_origin + 1)]);
        let v21_7_origin = v21_7_cursor.path().len();
        let mut v21_7_more = v21_7_cursor.is_val() || next_value_within(&mut v21_7_cursor,v21_7_origin);
        while v21_7_more {
          {
          let v21_7_depth = v21_7_cursor.path().len();
          let mut v22_4_cursor = (*v21_7_arg_3).read_zipper();
          let v22_4_origin = v22_4_cursor.path().len();
          for v22_4_byte in v22_4_cursor.child_mask().iter() {
            v22_4_cursor.descend_to_existing_byte(v22_4_byte);
            {
            let v23_2: Path = concat_path(&(*v21_7_arg_1),&v22_4_cursor.path()[v22_4_origin..(v22_4_origin + 1)]);
            let v23_3: Space = routine_7(c, &(v23_2), &v21_7_cursor.path()[v21_7_origin..v21_7_depth], &v22_4_cursor);
            drop(v23_2);
            join_wrapped_into(&mut v21_7_write,&((v23_3).read_zipper()),&[]);
            }
            v22_4_cursor.ascend(1);
          }
          drop(v22_4_cursor);
          }
          v21_7_more = next_value_within(&mut v21_7_cursor,v21_7_origin);
        }
        drop(v21_7_cursor);
        drop(v21_7_write);
        compose(&(v20_5),&(v21_7))
      };
      drop(v20_5);
      let v20_9: Space = intersect(&(*CONSTANT_2),&(v20_2));
      drop(v20_2);
      let v20_10: Space = if has_head(&(v20_9)) { singleton(&[]) } else { Space::new() };
      drop(v20_9);
      let v20_12: Space = if (&(v20_10)).is_empty() { Space::new() } else {
        let mut v24_11 = Space::new();
        let mut v24_11_write = v24_11.write_zipper();
        for v24_11_byte in v7_8_cursor.child_mask().iter() {
          v7_8_cursor.descend_to_existing_byte(v24_11_byte);
          {
          let v25_2: Space = routine_8(c, &v7_8_cursor.path()[(v7_8_origin + 1)..(v7_8_origin + 2)], &v7_8_cursor.path()[(v7_8_origin + 1)..(v7_8_origin + 2)], &v7_8_cursor.path()[v7_8_origin..(v7_8_origin + 1)], &v7_8_cursor);
          join_wrapped_into(&mut v24_11_write,&((v25_2).read_zipper()),&[]);
          }
          v7_8_cursor.ascend(1);
        }
        drop(v24_11_write);
        compose(&(v20_10),&(v24_11))
      };
      drop(v20_10);
      let v20_13: Space = unite(&(v20_8),&(v20_12));
      join_wrapped_into(&mut v7_8_write,&((v20_13).read_zipper()),&[]);
      }
      v7_8_cursor.ascend(1);
    }
    drop(v7_8_cursor);
    drop(v7_8_write);
    let v7_9: Space = unite(&(v7_5),&(v7_8));
    let mut v7_11 = Space::new();
    let mut v7_11_write = v7_11.write_zipper();
    let mut v7_11_cursor = descend_cursor(descend_cursor((v0_33).read_zipper(),&(*CONSTANT_6)),&(*CONSTANT_7));
    let v7_11_origin = v7_11_cursor.path().len();
    for v7_11_byte in v7_11_cursor.child_mask().iter() {
      v7_11_cursor.descend_to_existing_byte(v7_11_byte);
      {
      let v26_2: Space = singleton(&v7_11_cursor.path()[v7_11_origin..(v7_11_origin + 1)]);
      let v26_3: Space = intersect(&(*CONSTANT_2),&(v26_2));
      let v26_4: Space = if has_head(&(v26_3)) { singleton(&[]) } else { Space::new() };
      drop(v26_3);
      let v26_5: Space = subtract(&(*CONSTANT_1),&(v26_4));
      drop(v26_4);
      let v26_8: Space = if (&(v26_5)).is_empty() { Space::new() } else {
        let mut v27_7 = Space::new();
        let mut v27_7_write = v27_7.write_zipper();
        let v27_7_arg_0: &[u8] = &(*CONSTANT_3);
        let v27_7_arg_1: &[u8] = &v7_11_cursor.path()[v7_11_origin..(v7_11_origin + 1)];
        let v27_7_arg_3: &Space = &(&v7_11_cursor).make_map();
        let v27_7_arg_4: &Space = &(v0_33);
        let mut v27_7_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&v7_11_cursor.path()[v7_11_origin..(v7_11_origin + 1)]);
        let v27_7_origin = v27_7_cursor.path().len();
        let mut v27_7_more = v27_7_cursor.is_val() || next_value_within(&mut v27_7_cursor,v27_7_origin);
        while v27_7_more {
          {
          let v27_7_depth = v27_7_cursor.path().len();
          let mut v28_5_cursor = (*v27_7_arg_3).read_zipper();
          let v28_5_origin = v28_5_cursor.path().len();
          for v28_5_byte in v28_5_cursor.child_mask().iter() {
            v28_5_cursor.descend_to_existing_byte(v28_5_byte);
            {
            let v29_2: Path = concat_path(&(*v27_7_arg_1),&v28_5_cursor.path()[v28_5_origin..(v28_5_origin + 1)]);
            let v29_3: Space = routine_9(c, &(v29_2), &v27_7_cursor.path()[v27_7_origin..v27_7_depth], &v28_5_cursor, &((*v27_7_arg_4).read_zipper()));
            drop(v29_2);
            join_wrapped_into(&mut v27_7_write,&((v29_3).read_zipper()),&[]);
            }
            v28_5_cursor.ascend(1);
          }
          drop(v28_5_cursor);
          }
          v27_7_more = next_value_within(&mut v27_7_cursor,v27_7_origin);
        }
        drop(v27_7_cursor);
        drop(v27_7_write);
        compose(&(v26_5),&(v27_7))
      };
      drop(v26_5);
      let v26_9: Space = intersect(&(*CONSTANT_2),&(v26_2));
      drop(v26_2);
      let v26_10: Space = if has_head(&(v26_9)) { singleton(&[]) } else { Space::new() };
      drop(v26_9);
      let v26_12: Space = if (&(v26_10)).is_empty() { Space::new() } else {
        let mut v30_11 = Space::new();
        let mut v30_11_write = v30_11.write_zipper();
        for v30_11_byte in v7_11_cursor.child_mask().iter() {
          v7_11_cursor.descend_to_existing_byte(v30_11_byte);
          {
          let v31_2: Space = routine_10(c, &v7_11_cursor.path()[(v7_11_origin + 1)..(v7_11_origin + 2)], &v7_11_cursor.path()[(v7_11_origin + 1)..(v7_11_origin + 2)], &v7_11_cursor.path()[v7_11_origin..(v7_11_origin + 1)], &v7_11_cursor, &((v0_33).read_zipper()));
          join_wrapped_into(&mut v30_11_write,&((v31_2).read_zipper()),&[]);
          }
          v7_11_cursor.ascend(1);
        }
        drop(v30_11_write);
        compose(&(v26_10),&(v30_11))
      };
      drop(v26_10);
      let v26_13: Space = unite(&(v26_8),&(v26_12));
      join_wrapped_into(&mut v7_11_write,&((v26_13).read_zipper()),&[]);
      }
      v7_11_cursor.ascend(1);
    }
    drop(v7_11_cursor);
    drop(v7_11_write);
    let v7_12: Space = unite(&(v7_9),&(v7_11));
    let v7_14: Space = subtract(&(v7_12),&(descend_cursor((v0_33).read_zipper(),&(*CONSTANT_8))));
    let v7_16: Space = subtract(&(v7_14),&(descend_cursor((v0_33).read_zipper(),&(*CONSTANT_9))));
    let v7_17: Space = wrap(&(v7_16),&(*CONSTANT_8));
    let v7_18: Space = unite(&(descend_cursor((v0_33).read_zipper(),&(*CONSTANT_5))),&(descend_cursor((v0_33).read_zipper(),&(*CONSTANT_6))));
    let v7_19: Space = wrap(&(v7_18),&(*CONSTANT_6));
    drop(v7_18);
    let v7_20: Space = unite(&(v7_17),&(v7_19));
    drop(v7_19);
    let v7_21: Space = unite(&(v7_20),&(v0_33));
    if !v0_33.join_into((v7_21).clone()).is_element() { break; }
  }
  (&(descend_cursor((v0_33).read_zipper(),&(*CONSTANT_9)))).make_map()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v32_5: Space = singleton(&(*p1));
  let v32_6: Space = intersect(&(*CONSTANT_2),&(v32_5));
  let v32_7: Space = if has_head(&(v32_6)) { singleton(&[]) } else { Space::new() };
  drop(v32_6);
  let v32_8: Space = subtract(&(*CONSTANT_1),&(v32_7));
  drop(v32_7);
  let v32_19: Space = if (&(v32_8)).is_empty() { Space::new() } else {
    let v33_11: Space = first_matching(&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p1))),&(*CONSTANT_1),false);
    let v33_14: Space = if (&(v33_11)).is_empty() { Space::new() } else {
      let v34_13: Space = routine_11(c, &(*CONSTANT_3), &(*p0), &(*s0));
      compose(&(v33_11),&(v34_13))
    };
    drop(v33_11);
    let mut v33_17 = Space::new();
    let mut v33_17_write = v33_17.write_zipper();
    let mut v33_17_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p1));
    let v33_17_origin = v33_17_cursor.path().len();
    for v33_17_byte in v33_17_cursor.child_mask().iter() {
      v33_17_cursor.descend_to_existing_byte(v33_17_byte);
      {
      let v35_2_arg_0: &[u8] = &v33_17_cursor.path()[v33_17_origin..(v33_17_origin + 1)];
      let v35_2_arg_1: &[u8] = &(*p0);
      let v35_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v35_2_more = v33_17_cursor.is_val() || next_value_within(&mut v33_17_cursor,(v33_17_origin + 1));
      while v35_2_more {
        {
        let v35_2_depth = v33_17_cursor.path().len();
        let mut v36_4_cursor = (*v35_2_arg_3).read_zipper();
        let v36_4_origin = v36_4_cursor.path().len();
        for v36_4_byte in v36_4_cursor.child_mask().iter() {
          v36_4_cursor.descend_to_existing_byte(v36_4_byte);
          {
          let v37_2: Path = concat_path(&(*v35_2_arg_1),&v36_4_cursor.path()[v36_4_origin..(v36_4_origin + 1)]);
          let v37_3: Space = routine_1(c, &(v37_2), &v33_17_cursor.path()[v33_17_origin..v35_2_depth], &v36_4_cursor);
          drop(v37_2);
          join_wrapped_into(&mut v33_17_write,&((v37_3).read_zipper()),&[]);
          }
          v36_4_cursor.ascend(1);
        }
        drop(v36_4_cursor);
        }
        v35_2_more = next_value_within(&mut v33_17_cursor,(v33_17_origin + 1));
      }
      }
      v33_17_cursor.ascend(1);
    }
    drop(v33_17_cursor);
    drop(v33_17_write);
    let v33_18: Space = unite(&(v33_14),&(v33_17));
    compose(&(v32_8),&(v33_18))
  };
  drop(v32_8);
  let v32_21: Space = intersect(&(*CONSTANT_2),&(v32_5));
  drop(v32_5);
  let v32_22: Space = if has_head(&(v32_21)) { singleton(&[]) } else { Space::new() };
  drop(v32_21);
  let v32_24: Space = if (&(v32_22)).is_empty() { Space::new() } else {
    let mut v38_23 = Space::new();
    let mut v38_23_write = v38_23.write_zipper();
    let mut v38_23_cursor = (*s0).read_zipper();
    let v38_23_origin = v38_23_cursor.path().len();
    for v38_23_byte in v38_23_cursor.child_mask().iter() {
      v38_23_cursor.descend_to_existing_byte(v38_23_byte);
      {
      let v39_2: Space = routine_2(c, &v38_23_cursor.path()[v38_23_origin..(v38_23_origin + 1)], &v38_23_cursor.path()[v38_23_origin..(v38_23_origin + 1)], &(*p0), &v38_23_cursor);
      join_wrapped_into(&mut v38_23_write,&((v39_2).read_zipper()),&[]);
      }
      v38_23_cursor.ascend(1);
    }
    drop(v38_23_cursor);
    drop(v38_23_write);
    compose(&(v32_22),&(v38_23))
  };
  drop(v32_22);
  let v32_25: Space = unite(&(v32_19),&(v32_24));
  (v32_25).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v40_5: Space = singleton(&(*p1));
  let v40_6: Space = intersect(&(*CONSTANT_2),&(v40_5));
  let v40_7: Space = if has_head(&(v40_6)) { singleton(&[]) } else { Space::new() };
  drop(v40_6);
  let v40_8: Space = if (&(v40_7)).is_empty() { Space::new() } else {
    compose(&(v40_7),&(*s0))
  };
  drop(v40_7);
  let v40_9: Space = wrap(&(v40_8),&(*p0));
  drop(v40_8);
  let v40_10: Space = wrap(&(v40_9),&(*p2));
  drop(v40_9);
  let v40_12: Space = wrap(&(v40_10),&(*CONSTANT_7));
  drop(v40_10);
  let v40_15: Space = intersect(&(*CONSTANT_2),&(v40_5));
  drop(v40_5);
  let v40_16: Space = if has_head(&(v40_15)) { singleton(&[]) } else { Space::new() };
  drop(v40_15);
  let v40_17: Space = subtract(&(*CONSTANT_1),&(v40_16));
  drop(v40_16);
  let v40_28: Space = if (&(v40_17)).is_empty() { Space::new() } else {
    let v42_20: Space = first_matching(&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p1))),&(*CONSTANT_1),false);
    let v42_23: Space = if (&(v42_20)).is_empty() { Space::new() } else {
      let v43_22: Space = routine_12(c, &(*CONSTANT_3), &(*p0), &(*p2), &(*s0));
      compose(&(v42_20),&(v43_22))
    };
    drop(v42_20);
    let mut v42_26 = Space::new();
    let mut v42_26_write = v42_26.write_zipper();
    let mut v42_26_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p1));
    let v42_26_origin = v42_26_cursor.path().len();
    for v42_26_byte in v42_26_cursor.child_mask().iter() {
      v42_26_cursor.descend_to_existing_byte(v42_26_byte);
      {
      let v44_2_arg_0: &[u8] = &v42_26_cursor.path()[v42_26_origin..(v42_26_origin + 1)];
      let v44_2_arg_1: &[u8] = &(*p0);
      let v44_2_arg_2: &[u8] = &(*p2);
      let v44_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v44_2_more = v42_26_cursor.is_val() || next_value_within(&mut v42_26_cursor,(v42_26_origin + 1));
      while v44_2_more {
        {
        let v44_2_depth = v42_26_cursor.path().len();
        let mut v45_5_cursor = (*v44_2_arg_4).read_zipper();
        let v45_5_origin = v45_5_cursor.path().len();
        for v45_5_byte in v45_5_cursor.child_mask().iter() {
          v45_5_cursor.descend_to_existing_byte(v45_5_byte);
          {
          let v46_2: Path = concat_path(&(*v44_2_arg_1),&v45_5_cursor.path()[v45_5_origin..(v45_5_origin + 1)]);
          let v46_3: Space = routine_2(c, &(v46_2), &v42_26_cursor.path()[v42_26_origin..v44_2_depth], &(*v44_2_arg_2), &v45_5_cursor);
          drop(v46_2);
          join_wrapped_into(&mut v42_26_write,&((v46_3).read_zipper()),&[]);
          }
          v45_5_cursor.ascend(1);
        }
        drop(v45_5_cursor);
        }
        v44_2_more = next_value_within(&mut v42_26_cursor,(v42_26_origin + 1));
      }
      }
      v42_26_cursor.ascend(1);
    }
    drop(v42_26_cursor);
    drop(v42_26_write);
    let v42_27: Space = unite(&(v42_23),&(v42_26));
    compose(&(v40_17),&(v42_27))
  };
  drop(v40_17);
  let v40_29: Space = unite(&(v40_12),&(v40_28));
  drop(v40_12);
  (v40_29).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v47_6: Space = singleton(&(*p1));
  let v47_7: Space = intersect(&(*CONSTANT_2),&(v47_6));
  let v47_8: Space = if has_head(&(v47_7)) { singleton(&[]) } else { Space::new() };
  drop(v47_7);
  let v47_9: Space = subtract(&(*CONSTANT_1),&(v47_8));
  drop(v47_8);
  let v47_20: Space = if (&(v47_9)).is_empty() { Space::new() } else {
    let v48_12: Space = first_matching(&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p1))),&(*CONSTANT_1),false);
    let v48_15: Space = if (&(v48_12)).is_empty() { Space::new() } else {
      let v49_14: Space = routine_13(c, &(*CONSTANT_3), &(*p0), &(*s0), &(*s1));
      compose(&(v48_12),&(v49_14))
    };
    drop(v48_12);
    let mut v48_18 = Space::new();
    let mut v48_18_write = v48_18.write_zipper();
    let mut v48_18_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p1));
    let v48_18_origin = v48_18_cursor.path().len();
    for v48_18_byte in v48_18_cursor.child_mask().iter() {
      v48_18_cursor.descend_to_existing_byte(v48_18_byte);
      {
      let v50_2_arg_0: &[u8] = &v48_18_cursor.path()[v48_18_origin..(v48_18_origin + 1)];
      let v50_2_arg_1: &[u8] = &(*p0);
      let v50_2_arg_3: &Space = &(&(*s0)).make_map();
      let v50_2_arg_4: &Space = &(&(*s1)).make_map();
      let mut v50_2_more = v48_18_cursor.is_val() || next_value_within(&mut v48_18_cursor,(v48_18_origin + 1));
      while v50_2_more {
        {
        let v50_2_depth = v48_18_cursor.path().len();
        let mut v51_5_cursor = (*v50_2_arg_3).read_zipper();
        let v51_5_origin = v51_5_cursor.path().len();
        for v51_5_byte in v51_5_cursor.child_mask().iter() {
          v51_5_cursor.descend_to_existing_byte(v51_5_byte);
          {
          let v52_2: Path = concat_path(&(*v50_2_arg_1),&v51_5_cursor.path()[v51_5_origin..(v51_5_origin + 1)]);
          let v52_3: Space = routine_3(c, &(v52_2), &v48_18_cursor.path()[v48_18_origin..v50_2_depth], &v51_5_cursor, &((*v50_2_arg_4).read_zipper()));
          drop(v52_2);
          join_wrapped_into(&mut v48_18_write,&((v52_3).read_zipper()),&[]);
          }
          v51_5_cursor.ascend(1);
        }
        drop(v51_5_cursor);
        }
        v50_2_more = next_value_within(&mut v48_18_cursor,(v48_18_origin + 1));
      }
      }
      v48_18_cursor.ascend(1);
    }
    drop(v48_18_cursor);
    drop(v48_18_write);
    let v48_19: Space = unite(&(v48_15),&(v48_18));
    compose(&(v47_9),&(v48_19))
  };
  drop(v47_9);
  let v47_22: Space = intersect(&(*CONSTANT_2),&(v47_6));
  drop(v47_6);
  let v47_23: Space = if has_head(&(v47_22)) { singleton(&[]) } else { Space::new() };
  drop(v47_22);
  let v47_25: Space = if (&(v47_23)).is_empty() { Space::new() } else {
    let mut v53_24 = Space::new();
    let mut v53_24_write = v53_24.write_zipper();
    let mut v53_24_cursor = (*s0).read_zipper();
    let v53_24_origin = v53_24_cursor.path().len();
    for v53_24_byte in v53_24_cursor.child_mask().iter() {
      v53_24_cursor.descend_to_existing_byte(v53_24_byte);
      {
      let v54_2: Space = routine_4(c, &v53_24_cursor.path()[v53_24_origin..(v53_24_origin + 1)], &v53_24_cursor.path()[v53_24_origin..(v53_24_origin + 1)], &(*p0), &v53_24_cursor, &(*s1));
      join_wrapped_into(&mut v53_24_write,&((v54_2).read_zipper()),&[]);
      }
      v53_24_cursor.ascend(1);
    }
    drop(v53_24_cursor);
    drop(v53_24_write);
    compose(&(v47_23),&(v53_24))
  };
  drop(v47_23);
  let v47_26: Space = unite(&(v47_20),&(v47_25));
  (v47_26).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v55_7: Space = singleton(&(*p1));
  let v55_8: Space = intersect(&(*CONSTANT_2),&(v55_7));
  let v55_9: Space = if has_head(&(v55_8)) { singleton(&[]) } else { Space::new() };
  drop(v55_8);
  let v55_10: Space = subtract(&(*CONSTANT_1),&(v55_9));
  drop(v55_9);
  let v55_21: Space = if (&(v55_10)).is_empty() { Space::new() } else {
    let v56_13: Space = first_matching(&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p1))),&(*CONSTANT_1),false);
    let v56_16: Space = if (&(v56_13)).is_empty() { Space::new() } else {
      let v57_15: Space = routine_14(c, &(*CONSTANT_3), &(*p0), &(*p2), &(*s0), &(*s1));
      compose(&(v56_13),&(v57_15))
    };
    drop(v56_13);
    let mut v56_19 = Space::new();
    let mut v56_19_write = v56_19.write_zipper();
    let mut v56_19_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p1));
    let v56_19_origin = v56_19_cursor.path().len();
    for v56_19_byte in v56_19_cursor.child_mask().iter() {
      v56_19_cursor.descend_to_existing_byte(v56_19_byte);
      {
      let v58_2_arg_0: &[u8] = &v56_19_cursor.path()[v56_19_origin..(v56_19_origin + 1)];
      let v58_2_arg_1: &[u8] = &(*p0);
      let v58_2_arg_2: &[u8] = &(*p2);
      let v58_2_arg_4: &Space = &(&(*s0)).make_map();
      let v58_2_arg_5: &Space = &(&(*s1)).make_map();
      let mut v58_2_more = v56_19_cursor.is_val() || next_value_within(&mut v56_19_cursor,(v56_19_origin + 1));
      while v58_2_more {
        {
        let v58_2_depth = v56_19_cursor.path().len();
        let mut v59_6_cursor = (*v58_2_arg_4).read_zipper();
        let v59_6_origin = v59_6_cursor.path().len();
        for v59_6_byte in v59_6_cursor.child_mask().iter() {
          v59_6_cursor.descend_to_existing_byte(v59_6_byte);
          {
          let v60_2: Path = concat_path(&(*v58_2_arg_1),&v59_6_cursor.path()[v59_6_origin..(v59_6_origin + 1)]);
          let v60_3: Space = routine_4(c, &(v60_2), &v56_19_cursor.path()[v56_19_origin..v58_2_depth], &(*v58_2_arg_2), &v59_6_cursor, &((*v58_2_arg_5).read_zipper()));
          drop(v60_2);
          join_wrapped_into(&mut v56_19_write,&((v60_3).read_zipper()),&[]);
          }
          v59_6_cursor.ascend(1);
        }
        drop(v59_6_cursor);
        }
        v58_2_more = next_value_within(&mut v56_19_cursor,(v56_19_origin + 1));
      }
      }
      v56_19_cursor.ascend(1);
    }
    drop(v56_19_cursor);
    drop(v56_19_write);
    let v56_20: Space = unite(&(v56_16),&(v56_19));
    compose(&(v55_10),&(v56_20))
  };
  drop(v55_10);
  let v55_23: Space = intersect(&(*CONSTANT_2),&(v55_7));
  drop(v55_7);
  let v55_24: Space = if has_head(&(v55_23)) { singleton(&[]) } else { Space::new() };
  drop(v55_23);
  let v55_31: Space = if (&(v55_24)).is_empty() { Space::new() } else {
    let mut v61_30 = Space::new();
    let mut v61_30_write = v61_30.write_zipper();
    let mut v61_30_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_6)),&(*CONSTANT_7)),&(*p0));
    let v61_30_origin = v61_30_cursor.path().len();
    for v61_30_byte in v61_30_cursor.child_mask().iter() {
      v61_30_cursor.descend_to_existing_byte(v61_30_byte);
      {
      let v62_2: Space = routine_15(c, &v61_30_cursor.path()[v61_30_origin..(v61_30_origin + 1)], &v61_30_cursor.path()[v61_30_origin..(v61_30_origin + 1)], &(*p2), &v61_30_cursor);
      join_wrapped_into(&mut v61_30_write,&((v62_2).read_zipper()),&[]);
      }
      v61_30_cursor.ascend(1);
    }
    drop(v61_30_cursor);
    drop(v61_30_write);
    compose(&(v55_24),&(v61_30))
  };
  drop(v55_24);
  let v55_32: Space = unite(&(v55_21),&(v55_31));
  (v55_32).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v63_6: Space = singleton(&(*p1));
  let v63_7: Space = intersect(&(*CONSTANT_2),&(v63_6));
  let v63_8: Space = if has_head(&(v63_7)) { singleton(&[]) } else { Space::new() };
  drop(v63_7);
  let v63_9: Space = subtract(&(*CONSTANT_1),&(v63_8));
  drop(v63_8);
  let v63_20: Space = if (&(v63_9)).is_empty() { Space::new() } else {
    let v64_12: Space = first_matching(&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p1))),&(*CONSTANT_1),false);
    let v64_15: Space = if (&(v64_12)).is_empty() { Space::new() } else {
      let v65_14: Space = routine_16(c, &(*CONSTANT_3), &(*p0), &(*s0), &(*s1));
      compose(&(v64_12),&(v65_14))
    };
    drop(v64_12);
    let mut v64_18 = Space::new();
    let mut v64_18_write = v64_18.write_zipper();
    let mut v64_18_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p1));
    let v64_18_origin = v64_18_cursor.path().len();
    for v64_18_byte in v64_18_cursor.child_mask().iter() {
      v64_18_cursor.descend_to_existing_byte(v64_18_byte);
      {
      let v66_2_arg_0: &[u8] = &v64_18_cursor.path()[v64_18_origin..(v64_18_origin + 1)];
      let v66_2_arg_1: &[u8] = &(*p0);
      let v66_2_arg_3: &Space = &(&(*s0)).make_map();
      let v66_2_arg_4: &Space = &(&(*s1)).make_map();
      let mut v66_2_more = v64_18_cursor.is_val() || next_value_within(&mut v64_18_cursor,(v64_18_origin + 1));
      while v66_2_more {
        {
        let v66_2_depth = v64_18_cursor.path().len();
        let mut v67_5_cursor = (*v66_2_arg_3).read_zipper();
        let v67_5_origin = v67_5_cursor.path().len();
        for v67_5_byte in v67_5_cursor.child_mask().iter() {
          v67_5_cursor.descend_to_existing_byte(v67_5_byte);
          {
          let v68_2: Path = concat_path(&(*v66_2_arg_1),&v67_5_cursor.path()[v67_5_origin..(v67_5_origin + 1)]);
          let v68_3: Space = routine_5(c, &(v68_2), &v64_18_cursor.path()[v64_18_origin..v66_2_depth], &v67_5_cursor, &((*v66_2_arg_4).read_zipper()));
          drop(v68_2);
          join_wrapped_into(&mut v64_18_write,&((v68_3).read_zipper()),&[]);
          }
          v67_5_cursor.ascend(1);
        }
        drop(v67_5_cursor);
        }
        v66_2_more = next_value_within(&mut v64_18_cursor,(v64_18_origin + 1));
      }
      }
      v64_18_cursor.ascend(1);
    }
    drop(v64_18_cursor);
    drop(v64_18_write);
    let v64_19: Space = unite(&(v64_15),&(v64_18));
    compose(&(v63_9),&(v64_19))
  };
  drop(v63_9);
  let v63_22: Space = intersect(&(*CONSTANT_2),&(v63_6));
  drop(v63_6);
  let v63_23: Space = if has_head(&(v63_22)) { singleton(&[]) } else { Space::new() };
  drop(v63_22);
  let v63_25: Space = if (&(v63_23)).is_empty() { Space::new() } else {
    let mut v69_24 = Space::new();
    let mut v69_24_write = v69_24.write_zipper();
    let mut v69_24_cursor = (*s0).read_zipper();
    let v69_24_origin = v69_24_cursor.path().len();
    for v69_24_byte in v69_24_cursor.child_mask().iter() {
      v69_24_cursor.descend_to_existing_byte(v69_24_byte);
      {
      let v70_2: Space = routine_6(c, &v69_24_cursor.path()[v69_24_origin..(v69_24_origin + 1)], &v69_24_cursor.path()[v69_24_origin..(v69_24_origin + 1)], &(*p0), &v69_24_cursor, &(*s1));
      join_wrapped_into(&mut v69_24_write,&((v70_2).read_zipper()),&[]);
      }
      v69_24_cursor.ascend(1);
    }
    drop(v69_24_cursor);
    drop(v69_24_write);
    compose(&(v63_23),&(v69_24))
  };
  drop(v63_23);
  let v63_26: Space = unite(&(v63_20),&(v63_25));
  (v63_26).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v71_7: Space = singleton(&(*p1));
  let v71_8: Space = intersect(&(*CONSTANT_2),&(v71_7));
  let v71_9: Space = if has_head(&(v71_8)) { singleton(&[]) } else { Space::new() };
  drop(v71_8);
  let v71_10: Space = subtract(&(*CONSTANT_1),&(v71_9));
  drop(v71_9);
  let v71_21: Space = if (&(v71_10)).is_empty() { Space::new() } else {
    let v72_13: Space = first_matching(&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p1))),&(*CONSTANT_1),false);
    let v72_16: Space = if (&(v72_13)).is_empty() { Space::new() } else {
      let v73_15: Space = routine_17(c, &(*CONSTANT_3), &(*p0), &(*p2), &(*s0), &(*s1));
      compose(&(v72_13),&(v73_15))
    };
    drop(v72_13);
    let mut v72_19 = Space::new();
    let mut v72_19_write = v72_19.write_zipper();
    let mut v72_19_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p1));
    let v72_19_origin = v72_19_cursor.path().len();
    for v72_19_byte in v72_19_cursor.child_mask().iter() {
      v72_19_cursor.descend_to_existing_byte(v72_19_byte);
      {
      let v74_2_arg_0: &[u8] = &v72_19_cursor.path()[v72_19_origin..(v72_19_origin + 1)];
      let v74_2_arg_1: &[u8] = &(*p0);
      let v74_2_arg_2: &[u8] = &(*p2);
      let v74_2_arg_4: &Space = &(&(*s0)).make_map();
      let v74_2_arg_5: &Space = &(&(*s1)).make_map();
      let mut v74_2_more = v72_19_cursor.is_val() || next_value_within(&mut v72_19_cursor,(v72_19_origin + 1));
      while v74_2_more {
        {
        let v74_2_depth = v72_19_cursor.path().len();
        let mut v75_6_cursor = (*v74_2_arg_4).read_zipper();
        let v75_6_origin = v75_6_cursor.path().len();
        for v75_6_byte in v75_6_cursor.child_mask().iter() {
          v75_6_cursor.descend_to_existing_byte(v75_6_byte);
          {
          let v76_2: Path = concat_path(&(*v74_2_arg_1),&v75_6_cursor.path()[v75_6_origin..(v75_6_origin + 1)]);
          let v76_3: Space = routine_6(c, &(v76_2), &v72_19_cursor.path()[v72_19_origin..v74_2_depth], &(*v74_2_arg_2), &v75_6_cursor, &((*v74_2_arg_5).read_zipper()));
          drop(v76_2);
          join_wrapped_into(&mut v72_19_write,&((v76_3).read_zipper()),&[]);
          }
          v75_6_cursor.ascend(1);
        }
        drop(v75_6_cursor);
        }
        v74_2_more = next_value_within(&mut v72_19_cursor,(v72_19_origin + 1));
      }
      }
      v72_19_cursor.ascend(1);
    }
    drop(v72_19_cursor);
    drop(v72_19_write);
    let v72_20: Space = unite(&(v72_16),&(v72_19));
    compose(&(v71_10),&(v72_20))
  };
  drop(v71_10);
  let v71_23: Space = intersect(&(*CONSTANT_2),&(v71_7));
  drop(v71_7);
  let v71_24: Space = if has_head(&(v71_23)) { singleton(&[]) } else { Space::new() };
  drop(v71_23);
  let v71_31: Space = if (&(v71_24)).is_empty() { Space::new() } else {
    let mut v77_30 = Space::new();
    let mut v77_30_write = v77_30.write_zipper();
    let mut v77_30_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5)),&(*CONSTANT_7)),&(*p0));
    let v77_30_origin = v77_30_cursor.path().len();
    for v77_30_byte in v77_30_cursor.child_mask().iter() {
      v77_30_cursor.descend_to_existing_byte(v77_30_byte);
      {
      let v78_2: Space = routine_18(c, &v77_30_cursor.path()[v77_30_origin..(v77_30_origin + 1)], &v77_30_cursor.path()[v77_30_origin..(v77_30_origin + 1)], &(*p2), &v77_30_cursor);
      join_wrapped_into(&mut v77_30_write,&((v78_2).read_zipper()),&[]);
      }
      v77_30_cursor.ascend(1);
    }
    drop(v77_30_cursor);
    drop(v77_30_write);
    compose(&(v71_24),&(v77_30))
  };
  drop(v71_24);
  let v71_32: Space = unite(&(v71_21),&(v71_31));
  (v71_32).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v79_5: Space = singleton(&(*p1));
  let v79_6: Space = intersect(&(*CONSTANT_2),&(v79_5));
  let v79_7: Space = if has_head(&(v79_6)) { singleton(&[]) } else { Space::new() };
  drop(v79_6);
  let v79_8: Space = subtract(&(*CONSTANT_1),&(v79_7));
  drop(v79_7);
  let v79_19: Space = if (&(v79_8)).is_empty() { Space::new() } else {
    let v80_11: Space = first_matching(&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p1))),&(*CONSTANT_1),false);
    let v80_14: Space = if (&(v80_11)).is_empty() { Space::new() } else {
      let v81_13: Space = routine_19(c, &(*CONSTANT_3), &(*p0), &(*s0));
      compose(&(v80_11),&(v81_13))
    };
    drop(v80_11);
    let mut v80_17 = Space::new();
    let mut v80_17_write = v80_17.write_zipper();
    let mut v80_17_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p1));
    let v80_17_origin = v80_17_cursor.path().len();
    for v80_17_byte in v80_17_cursor.child_mask().iter() {
      v80_17_cursor.descend_to_existing_byte(v80_17_byte);
      {
      let v82_2_arg_0: &[u8] = &v80_17_cursor.path()[v80_17_origin..(v80_17_origin + 1)];
      let v82_2_arg_1: &[u8] = &(*p0);
      let v82_2_arg_3: &Space = &(&(*s0)).make_map();
      let mut v82_2_more = v80_17_cursor.is_val() || next_value_within(&mut v80_17_cursor,(v80_17_origin + 1));
      while v82_2_more {
        {
        let v82_2_depth = v80_17_cursor.path().len();
        let mut v83_4_cursor = (*v82_2_arg_3).read_zipper();
        let v83_4_origin = v83_4_cursor.path().len();
        for v83_4_byte in v83_4_cursor.child_mask().iter() {
          v83_4_cursor.descend_to_existing_byte(v83_4_byte);
          {
          let v84_2: Path = concat_path(&(*v82_2_arg_1),&v83_4_cursor.path()[v83_4_origin..(v83_4_origin + 1)]);
          let v84_3: Space = routine_7(c, &(v84_2), &v80_17_cursor.path()[v80_17_origin..v82_2_depth], &v83_4_cursor);
          drop(v84_2);
          join_wrapped_into(&mut v80_17_write,&((v84_3).read_zipper()),&[]);
          }
          v83_4_cursor.ascend(1);
        }
        drop(v83_4_cursor);
        }
        v82_2_more = next_value_within(&mut v80_17_cursor,(v80_17_origin + 1));
      }
      }
      v80_17_cursor.ascend(1);
    }
    drop(v80_17_cursor);
    drop(v80_17_write);
    let v80_18: Space = unite(&(v80_14),&(v80_17));
    compose(&(v79_8),&(v80_18))
  };
  drop(v79_8);
  let v79_21: Space = intersect(&(*CONSTANT_2),&(v79_5));
  drop(v79_5);
  let v79_22: Space = if has_head(&(v79_21)) { singleton(&[]) } else { Space::new() };
  drop(v79_21);
  let v79_24: Space = if (&(v79_22)).is_empty() { Space::new() } else {
    let mut v85_23 = Space::new();
    let mut v85_23_write = v85_23.write_zipper();
    let mut v85_23_cursor = (*s0).read_zipper();
    let v85_23_origin = v85_23_cursor.path().len();
    for v85_23_byte in v85_23_cursor.child_mask().iter() {
      v85_23_cursor.descend_to_existing_byte(v85_23_byte);
      {
      let v86_2: Space = routine_8(c, &v85_23_cursor.path()[v85_23_origin..(v85_23_origin + 1)], &v85_23_cursor.path()[v85_23_origin..(v85_23_origin + 1)], &(*p0), &v85_23_cursor);
      join_wrapped_into(&mut v85_23_write,&((v86_2).read_zipper()),&[]);
      }
      v85_23_cursor.ascend(1);
    }
    drop(v85_23_cursor);
    drop(v85_23_write);
    compose(&(v79_22),&(v85_23))
  };
  drop(v79_22);
  let v79_25: Space = unite(&(v79_19),&(v79_24));
  (v79_25).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v87_6: Space = singleton(&(*p1));
  let v87_7: Space = intersect(&(*CONSTANT_2),&(v87_6));
  let v87_8: Space = if has_head(&(v87_7)) { singleton(&[]) } else { Space::new() };
  drop(v87_7);
  let v87_9: Space = subtract(&(*CONSTANT_1),&(v87_8));
  drop(v87_8);
  let v87_20: Space = if (&(v87_9)).is_empty() { Space::new() } else {
    let v88_12: Space = first_matching(&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p1))),&(*CONSTANT_1),false);
    let v88_15: Space = if (&(v88_12)).is_empty() { Space::new() } else {
      let v89_14: Space = routine_20(c, &(*CONSTANT_3), &(*p0), &(*p2), &(*s0));
      compose(&(v88_12),&(v89_14))
    };
    drop(v88_12);
    let mut v88_18 = Space::new();
    let mut v88_18_write = v88_18.write_zipper();
    let mut v88_18_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p1));
    let v88_18_origin = v88_18_cursor.path().len();
    for v88_18_byte in v88_18_cursor.child_mask().iter() {
      v88_18_cursor.descend_to_existing_byte(v88_18_byte);
      {
      let v90_2_arg_0: &[u8] = &v88_18_cursor.path()[v88_18_origin..(v88_18_origin + 1)];
      let v90_2_arg_1: &[u8] = &(*p0);
      let v90_2_arg_2: &[u8] = &(*p2);
      let v90_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v90_2_more = v88_18_cursor.is_val() || next_value_within(&mut v88_18_cursor,(v88_18_origin + 1));
      while v90_2_more {
        {
        let v90_2_depth = v88_18_cursor.path().len();
        let mut v91_5_cursor = (*v90_2_arg_4).read_zipper();
        let v91_5_origin = v91_5_cursor.path().len();
        for v91_5_byte in v91_5_cursor.child_mask().iter() {
          v91_5_cursor.descend_to_existing_byte(v91_5_byte);
          {
          let v92_2: Path = concat_path(&(*v90_2_arg_1),&v91_5_cursor.path()[v91_5_origin..(v91_5_origin + 1)]);
          let v92_3: Space = routine_8(c, &(v92_2), &v88_18_cursor.path()[v88_18_origin..v90_2_depth], &(*v90_2_arg_2), &v91_5_cursor);
          drop(v92_2);
          join_wrapped_into(&mut v88_18_write,&((v92_3).read_zipper()),&[]);
          }
          v91_5_cursor.ascend(1);
        }
        drop(v91_5_cursor);
        }
        v90_2_more = next_value_within(&mut v88_18_cursor,(v88_18_origin + 1));
      }
      }
      v88_18_cursor.ascend(1);
    }
    drop(v88_18_cursor);
    drop(v88_18_write);
    let v88_19: Space = unite(&(v88_15),&(v88_18));
    compose(&(v87_9),&(v88_19))
  };
  drop(v87_9);
  let v87_22: Space = intersect(&(*CONSTANT_2),&(v87_6));
  drop(v87_6);
  let v87_23: Space = if has_head(&(v87_22)) { singleton(&[]) } else { Space::new() };
  drop(v87_22);
  let v87_24: Space = if (&(v87_23)).is_empty() { Space::new() } else {
    compose(&(v87_23),&(*s0))
  };
  drop(v87_23);
  let v87_25: Space = wrap(&(v87_24),&(*p0));
  drop(v87_24);
  let v87_26: Space = wrap(&(v87_25),&(*p2));
  drop(v87_25);
  let v87_27: Space = unite(&(v87_20),&(v87_26));
  drop(v87_26);
  (v87_27).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v94_6: Space = singleton(&(*p1));
  let v94_7: Space = intersect(&(*CONSTANT_2),&(v94_6));
  let v94_8: Space = if has_head(&(v94_7)) { singleton(&[]) } else { Space::new() };
  drop(v94_7);
  let v94_9: Space = subtract(&(*CONSTANT_1),&(v94_8));
  drop(v94_8);
  let v94_20: Space = if (&(v94_9)).is_empty() { Space::new() } else {
    let v95_12: Space = first_matching(&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p1))),&(*CONSTANT_1),false);
    let v95_15: Space = if (&(v95_12)).is_empty() { Space::new() } else {
      let v96_14: Space = routine_21(c, &(*CONSTANT_3), &(*p0), &(*s0), &(*s1));
      compose(&(v95_12),&(v96_14))
    };
    drop(v95_12);
    let mut v95_18 = Space::new();
    let mut v95_18_write = v95_18.write_zipper();
    let mut v95_18_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p1));
    let v95_18_origin = v95_18_cursor.path().len();
    for v95_18_byte in v95_18_cursor.child_mask().iter() {
      v95_18_cursor.descend_to_existing_byte(v95_18_byte);
      {
      let v97_2_arg_0: &[u8] = &v95_18_cursor.path()[v95_18_origin..(v95_18_origin + 1)];
      let v97_2_arg_1: &[u8] = &(*p0);
      let v97_2_arg_3: &Space = &(&(*s0)).make_map();
      let v97_2_arg_4: &Space = &(&(*s1)).make_map();
      let mut v97_2_more = v95_18_cursor.is_val() || next_value_within(&mut v95_18_cursor,(v95_18_origin + 1));
      while v97_2_more {
        {
        let v97_2_depth = v95_18_cursor.path().len();
        let mut v98_5_cursor = (*v97_2_arg_3).read_zipper();
        let v98_5_origin = v98_5_cursor.path().len();
        for v98_5_byte in v98_5_cursor.child_mask().iter() {
          v98_5_cursor.descend_to_existing_byte(v98_5_byte);
          {
          let v99_2: Path = concat_path(&(*v97_2_arg_1),&v98_5_cursor.path()[v98_5_origin..(v98_5_origin + 1)]);
          let v99_3: Space = routine_9(c, &(v99_2), &v95_18_cursor.path()[v95_18_origin..v97_2_depth], &v98_5_cursor, &((*v97_2_arg_4).read_zipper()));
          drop(v99_2);
          join_wrapped_into(&mut v95_18_write,&((v99_3).read_zipper()),&[]);
          }
          v98_5_cursor.ascend(1);
        }
        drop(v98_5_cursor);
        }
        v97_2_more = next_value_within(&mut v95_18_cursor,(v95_18_origin + 1));
      }
      }
      v95_18_cursor.ascend(1);
    }
    drop(v95_18_cursor);
    drop(v95_18_write);
    let v95_19: Space = unite(&(v95_15),&(v95_18));
    compose(&(v94_9),&(v95_19))
  };
  drop(v94_9);
  let v94_22: Space = intersect(&(*CONSTANT_2),&(v94_6));
  drop(v94_6);
  let v94_23: Space = if has_head(&(v94_22)) { singleton(&[]) } else { Space::new() };
  drop(v94_22);
  let v94_25: Space = if (&(v94_23)).is_empty() { Space::new() } else {
    let mut v100_24 = Space::new();
    let mut v100_24_write = v100_24.write_zipper();
    let mut v100_24_cursor = (*s0).read_zipper();
    let v100_24_origin = v100_24_cursor.path().len();
    for v100_24_byte in v100_24_cursor.child_mask().iter() {
      v100_24_cursor.descend_to_existing_byte(v100_24_byte);
      {
      let v101_2: Space = routine_10(c, &v100_24_cursor.path()[v100_24_origin..(v100_24_origin + 1)], &v100_24_cursor.path()[v100_24_origin..(v100_24_origin + 1)], &(*p0), &v100_24_cursor, &(*s1));
      join_wrapped_into(&mut v100_24_write,&((v101_2).read_zipper()),&[]);
      }
      v100_24_cursor.ascend(1);
    }
    drop(v100_24_cursor);
    drop(v100_24_write);
    compose(&(v94_23),&(v100_24))
  };
  drop(v94_23);
  let v94_26: Space = unite(&(v94_20),&(v94_25));
  (v94_26).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v102_7: Space = singleton(&(*p1));
  let v102_8: Space = intersect(&(*CONSTANT_2),&(v102_7));
  let v102_9: Space = if has_head(&(v102_8)) { singleton(&[]) } else { Space::new() };
  drop(v102_8);
  let v102_10: Space = subtract(&(*CONSTANT_1),&(v102_9));
  drop(v102_9);
  let v102_21: Space = if (&(v102_10)).is_empty() { Space::new() } else {
    let v103_13: Space = first_matching(&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p1))),&(*CONSTANT_1),false);
    let v103_16: Space = if (&(v103_13)).is_empty() { Space::new() } else {
      let v104_15: Space = routine_22(c, &(*CONSTANT_3), &(*p0), &(*p2), &(*s0), &(*s1));
      compose(&(v103_13),&(v104_15))
    };
    drop(v103_13);
    let mut v103_19 = Space::new();
    let mut v103_19_write = v103_19.write_zipper();
    let mut v103_19_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p1));
    let v103_19_origin = v103_19_cursor.path().len();
    for v103_19_byte in v103_19_cursor.child_mask().iter() {
      v103_19_cursor.descend_to_existing_byte(v103_19_byte);
      {
      let v105_2_arg_0: &[u8] = &v103_19_cursor.path()[v103_19_origin..(v103_19_origin + 1)];
      let v105_2_arg_1: &[u8] = &(*p0);
      let v105_2_arg_2: &[u8] = &(*p2);
      let v105_2_arg_4: &Space = &(&(*s0)).make_map();
      let v105_2_arg_5: &Space = &(&(*s1)).make_map();
      let mut v105_2_more = v103_19_cursor.is_val() || next_value_within(&mut v103_19_cursor,(v103_19_origin + 1));
      while v105_2_more {
        {
        let v105_2_depth = v103_19_cursor.path().len();
        let mut v106_6_cursor = (*v105_2_arg_4).read_zipper();
        let v106_6_origin = v106_6_cursor.path().len();
        for v106_6_byte in v106_6_cursor.child_mask().iter() {
          v106_6_cursor.descend_to_existing_byte(v106_6_byte);
          {
          let v107_2: Path = concat_path(&(*v105_2_arg_1),&v106_6_cursor.path()[v106_6_origin..(v106_6_origin + 1)]);
          let v107_3: Space = routine_10(c, &(v107_2), &v103_19_cursor.path()[v103_19_origin..v105_2_depth], &(*v105_2_arg_2), &v106_6_cursor, &((*v105_2_arg_5).read_zipper()));
          drop(v107_2);
          join_wrapped_into(&mut v103_19_write,&((v107_3).read_zipper()),&[]);
          }
          v106_6_cursor.ascend(1);
        }
        drop(v106_6_cursor);
        }
        v105_2_more = next_value_within(&mut v103_19_cursor,(v103_19_origin + 1));
      }
      }
      v103_19_cursor.ascend(1);
    }
    drop(v103_19_cursor);
    drop(v103_19_write);
    let v103_20: Space = unite(&(v103_16),&(v103_19));
    compose(&(v102_10),&(v103_20))
  };
  drop(v102_10);
  let v102_23: Space = intersect(&(*CONSTANT_2),&(v102_7));
  drop(v102_7);
  let v102_24: Space = if has_head(&(v102_23)) { singleton(&[]) } else { Space::new() };
  drop(v102_23);
  let v102_31: Space = if (&(v102_24)).is_empty() { Space::new() } else {
    let mut v108_30 = Space::new();
    let mut v108_30_write = v108_30.write_zipper();
    let mut v108_30_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5)),&(*CONSTANT_7)),&(*p0));
    let v108_30_origin = v108_30_cursor.path().len();
    for v108_30_byte in v108_30_cursor.child_mask().iter() {
      v108_30_cursor.descend_to_existing_byte(v108_30_byte);
      {
      let v109_2: Space = routine_23(c, &v108_30_cursor.path()[v108_30_origin..(v108_30_origin + 1)], &v108_30_cursor.path()[v108_30_origin..(v108_30_origin + 1)], &(*p2), &v108_30_cursor);
      join_wrapped_into(&mut v108_30_write,&((v109_2).read_zipper()),&[]);
      }
      v108_30_cursor.ascend(1);
    }
    drop(v108_30_cursor);
    drop(v108_30_write);
    compose(&(v102_24),&(v108_30))
  };
  drop(v102_24);
  let v102_32: Space = unite(&(v102_21),&(v102_31));
  (v102_32).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v110_5: Space = singleton(&(*p0));
  let v110_6: Space = intersect(&(*CONSTANT_2),&(v110_5));
  let v110_7: Space = if has_head(&(v110_6)) { singleton(&[]) } else { Space::new() };
  drop(v110_6);
  let v110_8: Space = subtract(&(*CONSTANT_1),&(v110_7));
  drop(v110_7);
  let v110_13: Space = intersect(&(*CONSTANT_2),&(v110_5));
  drop(v110_5);
  let v110_14: Space = if has_head(&(v110_13)) { singleton(&[]) } else { Space::new() };
  drop(v110_13);
  let mut v110_15 = Space::new();
  let mut v110_15_write = v110_15.write_zipper();
  let mut v110_15_cursor = (*s0).read_zipper();
  let v110_15_origin = v110_15_cursor.path().len();
  for v110_15_byte in v110_15_cursor.child_mask().iter() {
    v110_15_cursor.descend_to_existing_byte(v110_15_byte);
    {
    let v111_4: Space = if (&(v110_8)).is_empty() { Space::new() } else {
      let v112_2: Path = concat_path(&(*p1),&v110_15_cursor.path()[v110_15_origin..(v110_15_origin + 1)]);
      let mut v112_3 = Space::new();
      let mut v112_3_write = v112_3.write_zipper();
      let v112_3_arg_0: &[u8] = &(*CONSTANT_3);
      let v112_3_arg_1: &[u8] = &(v112_2);
      let v112_3_arg_3: &Space = &(&v110_15_cursor).make_map();
      let mut v112_3_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p0));
      let v112_3_origin = v112_3_cursor.path().len();
      let mut v112_3_more = v112_3_cursor.is_val() || next_value_within(&mut v112_3_cursor,v112_3_origin);
      while v112_3_more {
        {
        let v112_3_depth = v112_3_cursor.path().len();
        let v113_4: Space = routine_11(c, &v112_3_cursor.path()[v112_3_origin..v112_3_depth], &(*v112_3_arg_1), &((*v112_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v112_3_write,&((v113_4).read_zipper()),&[]);
        }
        v112_3_more = next_value_within(&mut v112_3_cursor,v112_3_origin);
      }
      drop(v112_3_cursor);
      drop(v112_3_write);
      compose(&(v110_8),&(v112_3))
    };
    let v111_6: Space = if (&(v110_14)).is_empty() { Space::new() } else {
      let v114_2: Path = concat_path(&(*p1),&v110_15_cursor.path()[v110_15_origin..(v110_15_origin + 1)]);
      let mut v114_5 = Space::new();
      let mut v114_5_write = v114_5.write_zipper();
      for v114_5_byte in v110_15_cursor.child_mask().iter() {
        v110_15_cursor.descend_to_existing_byte(v114_5_byte);
        {
        let v115_2: Space = routine_2(c, &v110_15_cursor.path()[(v110_15_origin + 1)..(v110_15_origin + 2)], &v110_15_cursor.path()[(v110_15_origin + 1)..(v110_15_origin + 2)], &(v114_2), &v110_15_cursor);
        join_wrapped_into(&mut v114_5_write,&((v115_2).read_zipper()),&[]);
        }
        v110_15_cursor.ascend(1);
      }
      drop(v114_5_write);
      drop(v114_2);
      compose(&(v110_14),&(v114_5))
    };
    let v111_7: Space = unite(&(v111_4),&(v111_6));
    join_wrapped_into(&mut v110_15_write,&((v111_7).read_zipper()),&[]);
    }
    v110_15_cursor.ascend(1);
  }
  drop(v110_15_cursor);
  drop(v110_15_write);
  drop(v110_8);
  drop(v110_14);
  (v110_15).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v116_5: Space = singleton(&(*p0));
  let v116_6: Space = intersect(&(*CONSTANT_2),&(v116_5));
  let v116_7: Space = if has_head(&(v116_6)) { singleton(&[]) } else { Space::new() };
  drop(v116_6);
  let v116_11: Space = intersect(&(*CONSTANT_2),&(v116_5));
  drop(v116_5);
  let v116_12: Space = if has_head(&(v116_11)) { singleton(&[]) } else { Space::new() };
  drop(v116_11);
  let v116_13: Space = subtract(&(*CONSTANT_1),&(v116_12));
  drop(v116_12);
  let mut v116_17 = Space::new();
  let mut v116_17_write = v116_17.write_zipper();
  let mut v116_17_cursor = (*s0).read_zipper();
  let v116_17_origin = v116_17_cursor.path().len();
  for v116_17_byte in v116_17_cursor.child_mask().iter() {
    v116_17_cursor.descend_to_existing_byte(v116_17_byte);
    {
    let v117_2: Space = compose(&(v116_7),&v116_17_cursor);
    let v118_3: Path = concat_path(&(*p1),&v116_17_cursor.path()[v116_17_origin..(v116_17_origin + 1)]);
    let v117_4: Space = wrap(&(v117_2),&(v118_3));
    drop(v117_2);
    let v117_5: Space = wrap(&(v117_4),&(*p2));
    drop(v117_4);
    let v117_6: Space = wrap(&(v117_5),&(*CONSTANT_7));
    drop(v117_5);
    let v117_8: Space = if (&(v116_13)).is_empty() { Space::new() } else {
      let mut v119_7 = Space::new();
      let mut v119_7_write = v119_7.write_zipper();
      let v119_7_arg_0: &[u8] = &(*CONSTANT_3);
      let v119_7_arg_1: &[u8] = &(v118_3);
      let v119_7_arg_2: &[u8] = &(*p2);
      let v119_7_arg_4: &Space = &(&v116_17_cursor).make_map();
      let mut v119_7_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p0));
      let v119_7_origin = v119_7_cursor.path().len();
      let mut v119_7_more = v119_7_cursor.is_val() || next_value_within(&mut v119_7_cursor,v119_7_origin);
      while v119_7_more {
        {
        let v119_7_depth = v119_7_cursor.path().len();
        let v120_5: Space = routine_12(c, &v119_7_cursor.path()[v119_7_origin..v119_7_depth], &(*v119_7_arg_1), &(*v119_7_arg_2), &((*v119_7_arg_4).read_zipper()));
        join_wrapped_into(&mut v119_7_write,&((v120_5).read_zipper()),&[]);
        }
        v119_7_more = next_value_within(&mut v119_7_cursor,v119_7_origin);
      }
      drop(v119_7_cursor);
      drop(v119_7_write);
      compose(&(v116_13),&(v119_7))
    };
    let v117_9: Space = unite(&(v117_6),&(v117_8));
    drop(v117_6);
    join_wrapped_into(&mut v116_17_write,&((v117_9).read_zipper()),&[]);
    }
    v116_17_cursor.ascend(1);
  }
  drop(v116_17_cursor);
  drop(v116_17_write);
  drop(v116_7);
  drop(v116_13);
  (v116_17).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v121_6: Space = singleton(&(*p0));
  let v121_7: Space = intersect(&(*CONSTANT_2),&(v121_6));
  let v121_8: Space = if has_head(&(v121_7)) { singleton(&[]) } else { Space::new() };
  drop(v121_7);
  let v121_9: Space = subtract(&(*CONSTANT_1),&(v121_8));
  drop(v121_8);
  let v121_14: Space = intersect(&(*CONSTANT_2),&(v121_6));
  drop(v121_6);
  let v121_15: Space = if has_head(&(v121_14)) { singleton(&[]) } else { Space::new() };
  drop(v121_14);
  let mut v121_16 = Space::new();
  let mut v121_16_write = v121_16.write_zipper();
  let mut v121_16_cursor = (*s0).read_zipper();
  let v121_16_origin = v121_16_cursor.path().len();
  for v121_16_byte in v121_16_cursor.child_mask().iter() {
    v121_16_cursor.descend_to_existing_byte(v121_16_byte);
    {
    let v122_4: Space = if (&(v121_9)).is_empty() { Space::new() } else {
      let v123_2: Path = concat_path(&(*p1),&v121_16_cursor.path()[v121_16_origin..(v121_16_origin + 1)]);
      let mut v123_3 = Space::new();
      let mut v123_3_write = v123_3.write_zipper();
      let v123_3_arg_0: &[u8] = &(*CONSTANT_3);
      let v123_3_arg_1: &[u8] = &(v123_2);
      let v123_3_arg_3: &Space = &(&v121_16_cursor).make_map();
      let v123_3_arg_4: &Space = &(&(*s1)).make_map();
      let mut v123_3_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p0));
      let v123_3_origin = v123_3_cursor.path().len();
      let mut v123_3_more = v123_3_cursor.is_val() || next_value_within(&mut v123_3_cursor,v123_3_origin);
      while v123_3_more {
        {
        let v123_3_depth = v123_3_cursor.path().len();
        let v124_5: Space = routine_13(c, &v123_3_cursor.path()[v123_3_origin..v123_3_depth], &(*v123_3_arg_1), &((*v123_3_arg_3).read_zipper()), &((*v123_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v123_3_write,&((v124_5).read_zipper()),&[]);
        }
        v123_3_more = next_value_within(&mut v123_3_cursor,v123_3_origin);
      }
      drop(v123_3_cursor);
      drop(v123_3_write);
      compose(&(v121_9),&(v123_3))
    };
    let v122_6: Space = if (&(v121_15)).is_empty() { Space::new() } else {
      let v125_2: Path = concat_path(&(*p1),&v121_16_cursor.path()[v121_16_origin..(v121_16_origin + 1)]);
      let mut v125_5 = Space::new();
      let mut v125_5_write = v125_5.write_zipper();
      for v125_5_byte in v121_16_cursor.child_mask().iter() {
        v121_16_cursor.descend_to_existing_byte(v125_5_byte);
        {
        let v126_2: Space = routine_4(c, &v121_16_cursor.path()[(v121_16_origin + 1)..(v121_16_origin + 2)], &v121_16_cursor.path()[(v121_16_origin + 1)..(v121_16_origin + 2)], &(v125_2), &v121_16_cursor, &(*s1));
        join_wrapped_into(&mut v125_5_write,&((v126_2).read_zipper()),&[]);
        }
        v121_16_cursor.ascend(1);
      }
      drop(v125_5_write);
      drop(v125_2);
      compose(&(v121_15),&(v125_5))
    };
    let v122_7: Space = unite(&(v122_4),&(v122_6));
    join_wrapped_into(&mut v121_16_write,&((v122_7).read_zipper()),&[]);
    }
    v121_16_cursor.ascend(1);
  }
  drop(v121_16_cursor);
  drop(v121_16_write);
  drop(v121_9);
  drop(v121_15);
  (v121_16).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v127_7: Space = singleton(&(*p0));
  let v127_8: Space = intersect(&(*CONSTANT_2),&(v127_7));
  let v127_9: Space = if has_head(&(v127_8)) { singleton(&[]) } else { Space::new() };
  drop(v127_8);
  let v127_10: Space = subtract(&(*CONSTANT_1),&(v127_9));
  drop(v127_9);
  let v127_15: Space = intersect(&(*CONSTANT_2),&(v127_7));
  drop(v127_7);
  let v127_16: Space = if has_head(&(v127_15)) { singleton(&[]) } else { Space::new() };
  drop(v127_15);
  let mut v127_22 = Space::new();
  let mut v127_22_write = v127_22.write_zipper();
  let mut v127_22_cursor = (*s0).read_zipper();
  let v127_22_origin = v127_22_cursor.path().len();
  for v127_22_byte in v127_22_cursor.child_mask().iter() {
    v127_22_cursor.descend_to_existing_byte(v127_22_byte);
    {
    let v128_4: Space = if (&(v127_10)).is_empty() { Space::new() } else {
      let v129_2: Path = concat_path(&(*p1),&v127_22_cursor.path()[v127_22_origin..(v127_22_origin + 1)]);
      let mut v129_3 = Space::new();
      let mut v129_3_write = v129_3.write_zipper();
      let v129_3_arg_0: &[u8] = &(*CONSTANT_3);
      let v129_3_arg_1: &[u8] = &(v129_2);
      let v129_3_arg_2: &[u8] = &(*p2);
      let v129_3_arg_4: &Space = &(&v127_22_cursor).make_map();
      let v129_3_arg_5: &Space = &(&(*s1)).make_map();
      let mut v129_3_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p0));
      let v129_3_origin = v129_3_cursor.path().len();
      let mut v129_3_more = v129_3_cursor.is_val() || next_value_within(&mut v129_3_cursor,v129_3_origin);
      while v129_3_more {
        {
        let v129_3_depth = v129_3_cursor.path().len();
        let v130_6: Space = routine_14(c, &v129_3_cursor.path()[v129_3_origin..v129_3_depth], &(*v129_3_arg_1), &(*v129_3_arg_2), &((*v129_3_arg_4).read_zipper()), &((*v129_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v129_3_write,&((v130_6).read_zipper()),&[]);
        }
        v129_3_more = next_value_within(&mut v129_3_cursor,v129_3_origin);
      }
      drop(v129_3_cursor);
      drop(v129_3_write);
      drop(v129_2);
      compose(&(v127_10),&(v129_3))
    };
    let v128_7: Space = if (&(v127_16)).is_empty() { Space::new() } else {
      let mut v131_6 = Space::new();
      let mut v131_6_write = v131_6.write_zipper();
      let mut v131_6_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_6)),&(*CONSTANT_7)),&(*p1)),&v127_22_cursor.path()[v127_22_origin..(v127_22_origin + 1)]);
      let v131_6_origin = v131_6_cursor.path().len();
      for v131_6_byte in v131_6_cursor.child_mask().iter() {
        v131_6_cursor.descend_to_existing_byte(v131_6_byte);
        {
        let v132_2: Space = routine_15(c, &v131_6_cursor.path()[v131_6_origin..(v131_6_origin + 1)], &v131_6_cursor.path()[v131_6_origin..(v131_6_origin + 1)], &(*p2), &v131_6_cursor);
        join_wrapped_into(&mut v131_6_write,&((v132_2).read_zipper()),&[]);
        }
        v131_6_cursor.ascend(1);
      }
      drop(v131_6_cursor);
      drop(v131_6_write);
      compose(&(v127_16),&(v131_6))
    };
    let v128_8: Space = unite(&(v128_4),&(v128_7));
    join_wrapped_into(&mut v127_22_write,&((v128_8).read_zipper()),&[]);
    }
    v127_22_cursor.ascend(1);
  }
  drop(v127_22_cursor);
  drop(v127_22_write);
  drop(v127_10);
  drop(v127_16);
  (v127_22).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v133_6: Space = singleton(&(*p1));
  let v133_7: Space = intersect(&(*CONSTANT_2),&(v133_6));
  let v133_8: Space = if has_head(&(v133_7)) { singleton(&[]) } else { Space::new() };
  drop(v133_7);
  let v133_9: Space = subtract(&(*CONSTANT_1),&(v133_8));
  drop(v133_8);
  let v133_20: Space = if (&(v133_9)).is_empty() { Space::new() } else {
    let v134_12: Space = first_matching(&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p1))),&(*CONSTANT_1),false);
    let v134_15: Space = if (&(v134_12)).is_empty() { Space::new() } else {
      let v135_14: Space = routine_24(c, &(*CONSTANT_3), &(*p0), &(*p2), &(*s0));
      compose(&(v134_12),&(v135_14))
    };
    drop(v134_12);
    let mut v134_18 = Space::new();
    let mut v134_18_write = v134_18.write_zipper();
    let mut v134_18_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p1));
    let v134_18_origin = v134_18_cursor.path().len();
    for v134_18_byte in v134_18_cursor.child_mask().iter() {
      v134_18_cursor.descend_to_existing_byte(v134_18_byte);
      {
      let v136_2_arg_0: &[u8] = &v134_18_cursor.path()[v134_18_origin..(v134_18_origin + 1)];
      let v136_2_arg_1: &[u8] = &(*p0);
      let v136_2_arg_2: &[u8] = &(*p2);
      let v136_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v136_2_more = v134_18_cursor.is_val() || next_value_within(&mut v134_18_cursor,(v134_18_origin + 1));
      while v136_2_more {
        {
        let v136_2_depth = v134_18_cursor.path().len();
        let mut v137_5_cursor = (*v136_2_arg_4).read_zipper();
        let v137_5_origin = v137_5_cursor.path().len();
        for v137_5_byte in v137_5_cursor.child_mask().iter() {
          v137_5_cursor.descend_to_existing_byte(v137_5_byte);
          {
          let v138_2: Path = concat_path(&(*v136_2_arg_1),&v137_5_cursor.path()[v137_5_origin..(v137_5_origin + 1)]);
          let v138_3: Space = routine_15(c, &(v138_2), &v134_18_cursor.path()[v134_18_origin..v136_2_depth], &(*v136_2_arg_2), &v137_5_cursor);
          drop(v138_2);
          join_wrapped_into(&mut v134_18_write,&((v138_3).read_zipper()),&[]);
          }
          v137_5_cursor.ascend(1);
        }
        drop(v137_5_cursor);
        }
        v136_2_more = next_value_within(&mut v134_18_cursor,(v134_18_origin + 1));
      }
      }
      v134_18_cursor.ascend(1);
    }
    drop(v134_18_cursor);
    drop(v134_18_write);
    let v134_19: Space = unite(&(v134_15),&(v134_18));
    compose(&(v133_9),&(v134_19))
  };
  drop(v133_9);
  let v133_22: Space = intersect(&(*CONSTANT_2),&(v133_6));
  drop(v133_6);
  let v133_23: Space = if has_head(&(v133_22)) { singleton(&[]) } else { Space::new() };
  drop(v133_22);
  let v133_24: Space = if (&(v133_23)).is_empty() { Space::new() } else {
    compose(&(v133_23),&(*s0))
  };
  drop(v133_23);
  let v133_25: Space = wrap(&(v133_24),&(*p0));
  drop(v133_24);
  let v133_26: Space = wrap(&(v133_25),&(*p2));
  drop(v133_25);
  let v133_27: Space = unite(&(v133_20),&(v133_26));
  drop(v133_26);
  (v133_27).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v140_6: Space = singleton(&(*p0));
  let v140_7: Space = intersect(&(*CONSTANT_2),&(v140_6));
  let v140_8: Space = if has_head(&(v140_7)) { singleton(&[]) } else { Space::new() };
  drop(v140_7);
  let v140_9: Space = subtract(&(*CONSTANT_1),&(v140_8));
  drop(v140_8);
  let v140_14: Space = intersect(&(*CONSTANT_2),&(v140_6));
  drop(v140_6);
  let v140_15: Space = if has_head(&(v140_14)) { singleton(&[]) } else { Space::new() };
  drop(v140_14);
  let mut v140_16 = Space::new();
  let mut v140_16_write = v140_16.write_zipper();
  let mut v140_16_cursor = (*s0).read_zipper();
  let v140_16_origin = v140_16_cursor.path().len();
  for v140_16_byte in v140_16_cursor.child_mask().iter() {
    v140_16_cursor.descend_to_existing_byte(v140_16_byte);
    {
    let v141_4: Space = if (&(v140_9)).is_empty() { Space::new() } else {
      let v142_2: Path = concat_path(&(*p1),&v140_16_cursor.path()[v140_16_origin..(v140_16_origin + 1)]);
      let mut v142_3 = Space::new();
      let mut v142_3_write = v142_3.write_zipper();
      let v142_3_arg_0: &[u8] = &(*CONSTANT_3);
      let v142_3_arg_1: &[u8] = &(v142_2);
      let v142_3_arg_3: &Space = &(&v140_16_cursor).make_map();
      let v142_3_arg_4: &Space = &(&(*s1)).make_map();
      let mut v142_3_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p0));
      let v142_3_origin = v142_3_cursor.path().len();
      let mut v142_3_more = v142_3_cursor.is_val() || next_value_within(&mut v142_3_cursor,v142_3_origin);
      while v142_3_more {
        {
        let v142_3_depth = v142_3_cursor.path().len();
        let v143_5: Space = routine_16(c, &v142_3_cursor.path()[v142_3_origin..v142_3_depth], &(*v142_3_arg_1), &((*v142_3_arg_3).read_zipper()), &((*v142_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v142_3_write,&((v143_5).read_zipper()),&[]);
        }
        v142_3_more = next_value_within(&mut v142_3_cursor,v142_3_origin);
      }
      drop(v142_3_cursor);
      drop(v142_3_write);
      compose(&(v140_9),&(v142_3))
    };
    let v141_6: Space = if (&(v140_15)).is_empty() { Space::new() } else {
      let v144_2: Path = concat_path(&(*p1),&v140_16_cursor.path()[v140_16_origin..(v140_16_origin + 1)]);
      let mut v144_5 = Space::new();
      let mut v144_5_write = v144_5.write_zipper();
      for v144_5_byte in v140_16_cursor.child_mask().iter() {
        v140_16_cursor.descend_to_existing_byte(v144_5_byte);
        {
        let v145_2: Space = routine_6(c, &v140_16_cursor.path()[(v140_16_origin + 1)..(v140_16_origin + 2)], &v140_16_cursor.path()[(v140_16_origin + 1)..(v140_16_origin + 2)], &(v144_2), &v140_16_cursor, &(*s1));
        join_wrapped_into(&mut v144_5_write,&((v145_2).read_zipper()),&[]);
        }
        v140_16_cursor.ascend(1);
      }
      drop(v144_5_write);
      drop(v144_2);
      compose(&(v140_15),&(v144_5))
    };
    let v141_7: Space = unite(&(v141_4),&(v141_6));
    join_wrapped_into(&mut v140_16_write,&((v141_7).read_zipper()),&[]);
    }
    v140_16_cursor.ascend(1);
  }
  drop(v140_16_cursor);
  drop(v140_16_write);
  drop(v140_9);
  drop(v140_15);
  (v140_16).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v146_7: Space = singleton(&(*p0));
  let v146_8: Space = intersect(&(*CONSTANT_2),&(v146_7));
  let v146_9: Space = if has_head(&(v146_8)) { singleton(&[]) } else { Space::new() };
  drop(v146_8);
  let v146_10: Space = subtract(&(*CONSTANT_1),&(v146_9));
  drop(v146_9);
  let v146_15: Space = intersect(&(*CONSTANT_2),&(v146_7));
  drop(v146_7);
  let v146_16: Space = if has_head(&(v146_15)) { singleton(&[]) } else { Space::new() };
  drop(v146_15);
  let mut v146_22 = Space::new();
  let mut v146_22_write = v146_22.write_zipper();
  let mut v146_22_cursor = (*s0).read_zipper();
  let v146_22_origin = v146_22_cursor.path().len();
  for v146_22_byte in v146_22_cursor.child_mask().iter() {
    v146_22_cursor.descend_to_existing_byte(v146_22_byte);
    {
    let v147_4: Space = if (&(v146_10)).is_empty() { Space::new() } else {
      let v148_2: Path = concat_path(&(*p1),&v146_22_cursor.path()[v146_22_origin..(v146_22_origin + 1)]);
      let mut v148_3 = Space::new();
      let mut v148_3_write = v148_3.write_zipper();
      let v148_3_arg_0: &[u8] = &(*CONSTANT_3);
      let v148_3_arg_1: &[u8] = &(v148_2);
      let v148_3_arg_2: &[u8] = &(*p2);
      let v148_3_arg_4: &Space = &(&v146_22_cursor).make_map();
      let v148_3_arg_5: &Space = &(&(*s1)).make_map();
      let mut v148_3_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p0));
      let v148_3_origin = v148_3_cursor.path().len();
      let mut v148_3_more = v148_3_cursor.is_val() || next_value_within(&mut v148_3_cursor,v148_3_origin);
      while v148_3_more {
        {
        let v148_3_depth = v148_3_cursor.path().len();
        let v149_6: Space = routine_17(c, &v148_3_cursor.path()[v148_3_origin..v148_3_depth], &(*v148_3_arg_1), &(*v148_3_arg_2), &((*v148_3_arg_4).read_zipper()), &((*v148_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v148_3_write,&((v149_6).read_zipper()),&[]);
        }
        v148_3_more = next_value_within(&mut v148_3_cursor,v148_3_origin);
      }
      drop(v148_3_cursor);
      drop(v148_3_write);
      drop(v148_2);
      compose(&(v146_10),&(v148_3))
    };
    let v147_7: Space = if (&(v146_16)).is_empty() { Space::new() } else {
      let mut v150_6 = Space::new();
      let mut v150_6_write = v150_6.write_zipper();
      let mut v150_6_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5)),&(*CONSTANT_7)),&(*p1)),&v146_22_cursor.path()[v146_22_origin..(v146_22_origin + 1)]);
      let v150_6_origin = v150_6_cursor.path().len();
      for v150_6_byte in v150_6_cursor.child_mask().iter() {
        v150_6_cursor.descend_to_existing_byte(v150_6_byte);
        {
        let v151_2: Space = routine_18(c, &v150_6_cursor.path()[v150_6_origin..(v150_6_origin + 1)], &v150_6_cursor.path()[v150_6_origin..(v150_6_origin + 1)], &(*p2), &v150_6_cursor);
        join_wrapped_into(&mut v150_6_write,&((v151_2).read_zipper()),&[]);
        }
        v150_6_cursor.ascend(1);
      }
      drop(v150_6_cursor);
      drop(v150_6_write);
      compose(&(v146_16),&(v150_6))
    };
    let v147_8: Space = unite(&(v147_4),&(v147_7));
    join_wrapped_into(&mut v146_22_write,&((v147_8).read_zipper()),&[]);
    }
    v146_22_cursor.ascend(1);
  }
  drop(v146_22_cursor);
  drop(v146_22_write);
  drop(v146_10);
  drop(v146_16);
  (v146_22).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v152_6: Space = singleton(&(*p1));
  let v152_7: Space = intersect(&(*CONSTANT_2),&(v152_6));
  let v152_8: Space = if has_head(&(v152_7)) { singleton(&[]) } else { Space::new() };
  drop(v152_7);
  let v152_9: Space = subtract(&(*CONSTANT_1),&(v152_8));
  drop(v152_8);
  let v152_20: Space = if (&(v152_9)).is_empty() { Space::new() } else {
    let v153_12: Space = first_matching(&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p1))),&(*CONSTANT_1),false);
    let v153_15: Space = if (&(v153_12)).is_empty() { Space::new() } else {
      let v154_14: Space = routine_25(c, &(*CONSTANT_3), &(*p0), &(*p2), &(*s0));
      compose(&(v153_12),&(v154_14))
    };
    drop(v153_12);
    let mut v153_18 = Space::new();
    let mut v153_18_write = v153_18.write_zipper();
    let mut v153_18_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p1));
    let v153_18_origin = v153_18_cursor.path().len();
    for v153_18_byte in v153_18_cursor.child_mask().iter() {
      v153_18_cursor.descend_to_existing_byte(v153_18_byte);
      {
      let v155_2_arg_0: &[u8] = &v153_18_cursor.path()[v153_18_origin..(v153_18_origin + 1)];
      let v155_2_arg_1: &[u8] = &(*p0);
      let v155_2_arg_2: &[u8] = &(*p2);
      let v155_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v155_2_more = v153_18_cursor.is_val() || next_value_within(&mut v153_18_cursor,(v153_18_origin + 1));
      while v155_2_more {
        {
        let v155_2_depth = v153_18_cursor.path().len();
        let mut v156_5_cursor = (*v155_2_arg_4).read_zipper();
        let v156_5_origin = v156_5_cursor.path().len();
        for v156_5_byte in v156_5_cursor.child_mask().iter() {
          v156_5_cursor.descend_to_existing_byte(v156_5_byte);
          {
          let v157_2: Path = concat_path(&(*v155_2_arg_1),&v156_5_cursor.path()[v156_5_origin..(v156_5_origin + 1)]);
          let v157_3: Space = routine_18(c, &(v157_2), &v153_18_cursor.path()[v153_18_origin..v155_2_depth], &(*v155_2_arg_2), &v156_5_cursor);
          drop(v157_2);
          join_wrapped_into(&mut v153_18_write,&((v157_3).read_zipper()),&[]);
          }
          v156_5_cursor.ascend(1);
        }
        drop(v156_5_cursor);
        }
        v155_2_more = next_value_within(&mut v153_18_cursor,(v153_18_origin + 1));
      }
      }
      v153_18_cursor.ascend(1);
    }
    drop(v153_18_cursor);
    drop(v153_18_write);
    let v153_19: Space = unite(&(v153_15),&(v153_18));
    compose(&(v152_9),&(v153_19))
  };
  drop(v152_9);
  let v152_22: Space = intersect(&(*CONSTANT_2),&(v152_6));
  drop(v152_6);
  let v152_23: Space = if has_head(&(v152_22)) { singleton(&[]) } else { Space::new() };
  drop(v152_22);
  let v152_24: Space = if (&(v152_23)).is_empty() { Space::new() } else {
    compose(&(v152_23),&(*s0))
  };
  drop(v152_23);
  let v152_25: Space = wrap(&(v152_24),&(*p0));
  drop(v152_24);
  let v152_26: Space = wrap(&(v152_25),&(*p2));
  drop(v152_25);
  let v152_27: Space = unite(&(v152_20),&(v152_26));
  drop(v152_26);
  (v152_27).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v159_5: Space = singleton(&(*p0));
  let v159_6: Space = intersect(&(*CONSTANT_2),&(v159_5));
  let v159_7: Space = if has_head(&(v159_6)) { singleton(&[]) } else { Space::new() };
  drop(v159_6);
  let v159_8: Space = subtract(&(*CONSTANT_1),&(v159_7));
  drop(v159_7);
  let v159_13: Space = intersect(&(*CONSTANT_2),&(v159_5));
  drop(v159_5);
  let v159_14: Space = if has_head(&(v159_13)) { singleton(&[]) } else { Space::new() };
  drop(v159_13);
  let mut v159_15 = Space::new();
  let mut v159_15_write = v159_15.write_zipper();
  let mut v159_15_cursor = (*s0).read_zipper();
  let v159_15_origin = v159_15_cursor.path().len();
  for v159_15_byte in v159_15_cursor.child_mask().iter() {
    v159_15_cursor.descend_to_existing_byte(v159_15_byte);
    {
    let v160_4: Space = if (&(v159_8)).is_empty() { Space::new() } else {
      let v161_2: Path = concat_path(&(*p1),&v159_15_cursor.path()[v159_15_origin..(v159_15_origin + 1)]);
      let mut v161_3 = Space::new();
      let mut v161_3_write = v161_3.write_zipper();
      let v161_3_arg_0: &[u8] = &(*CONSTANT_3);
      let v161_3_arg_1: &[u8] = &(v161_2);
      let v161_3_arg_3: &Space = &(&v159_15_cursor).make_map();
      let mut v161_3_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p0));
      let v161_3_origin = v161_3_cursor.path().len();
      let mut v161_3_more = v161_3_cursor.is_val() || next_value_within(&mut v161_3_cursor,v161_3_origin);
      while v161_3_more {
        {
        let v161_3_depth = v161_3_cursor.path().len();
        let v162_4: Space = routine_19(c, &v161_3_cursor.path()[v161_3_origin..v161_3_depth], &(*v161_3_arg_1), &((*v161_3_arg_3).read_zipper()));
        join_wrapped_into(&mut v161_3_write,&((v162_4).read_zipper()),&[]);
        }
        v161_3_more = next_value_within(&mut v161_3_cursor,v161_3_origin);
      }
      drop(v161_3_cursor);
      drop(v161_3_write);
      compose(&(v159_8),&(v161_3))
    };
    let v160_6: Space = if (&(v159_14)).is_empty() { Space::new() } else {
      let v163_2: Path = concat_path(&(*p1),&v159_15_cursor.path()[v159_15_origin..(v159_15_origin + 1)]);
      let mut v163_5 = Space::new();
      let mut v163_5_write = v163_5.write_zipper();
      for v163_5_byte in v159_15_cursor.child_mask().iter() {
        v159_15_cursor.descend_to_existing_byte(v163_5_byte);
        {
        let v164_2: Space = routine_8(c, &v159_15_cursor.path()[(v159_15_origin + 1)..(v159_15_origin + 2)], &v159_15_cursor.path()[(v159_15_origin + 1)..(v159_15_origin + 2)], &(v163_2), &v159_15_cursor);
        join_wrapped_into(&mut v163_5_write,&((v164_2).read_zipper()),&[]);
        }
        v159_15_cursor.ascend(1);
      }
      drop(v163_5_write);
      drop(v163_2);
      compose(&(v159_14),&(v163_5))
    };
    let v160_7: Space = unite(&(v160_4),&(v160_6));
    join_wrapped_into(&mut v159_15_write,&((v160_7).read_zipper()),&[]);
    }
    v159_15_cursor.ascend(1);
  }
  drop(v159_15_cursor);
  drop(v159_15_write);
  drop(v159_8);
  drop(v159_14);
  (v159_15).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v165_6: Space = singleton(&(*p0));
  let v165_7: Space = intersect(&(*CONSTANT_2),&(v165_6));
  let v165_8: Space = if has_head(&(v165_7)) { singleton(&[]) } else { Space::new() };
  drop(v165_7);
  let v165_9: Space = subtract(&(*CONSTANT_1),&(v165_8));
  drop(v165_8);
  let v165_14: Space = intersect(&(*CONSTANT_2),&(v165_6));
  drop(v165_6);
  let v165_15: Space = if has_head(&(v165_14)) { singleton(&[]) } else { Space::new() };
  drop(v165_14);
  let mut v165_16 = Space::new();
  let mut v165_16_write = v165_16.write_zipper();
  let mut v165_16_cursor = (*s0).read_zipper();
  let v165_16_origin = v165_16_cursor.path().len();
  for v165_16_byte in v165_16_cursor.child_mask().iter() {
    v165_16_cursor.descend_to_existing_byte(v165_16_byte);
    {
    let v166_4: Space = if (&(v165_9)).is_empty() { Space::new() } else {
      let v167_2: Path = concat_path(&(*p1),&v165_16_cursor.path()[v165_16_origin..(v165_16_origin + 1)]);
      let mut v167_3 = Space::new();
      let mut v167_3_write = v167_3.write_zipper();
      let v167_3_arg_0: &[u8] = &(*CONSTANT_3);
      let v167_3_arg_1: &[u8] = &(v167_2);
      let v167_3_arg_2: &[u8] = &(*p2);
      let v167_3_arg_4: &Space = &(&v165_16_cursor).make_map();
      let mut v167_3_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p0));
      let v167_3_origin = v167_3_cursor.path().len();
      let mut v167_3_more = v167_3_cursor.is_val() || next_value_within(&mut v167_3_cursor,v167_3_origin);
      while v167_3_more {
        {
        let v167_3_depth = v167_3_cursor.path().len();
        let v168_5: Space = routine_20(c, &v167_3_cursor.path()[v167_3_origin..v167_3_depth], &(*v167_3_arg_1), &(*v167_3_arg_2), &((*v167_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v167_3_write,&((v168_5).read_zipper()),&[]);
        }
        v167_3_more = next_value_within(&mut v167_3_cursor,v167_3_origin);
      }
      drop(v167_3_cursor);
      drop(v167_3_write);
      compose(&(v165_9),&(v167_3))
    };
    let v166_5: Space = compose(&(v165_15),&v165_16_cursor);
    let v169_2: Path = concat_path(&(*p1),&v165_16_cursor.path()[v165_16_origin..(v165_16_origin + 1)]);
    let v166_6: Space = wrap(&(v166_5),&(v169_2));
    drop(v166_5);
    let v166_7: Space = wrap(&(v166_6),&(*p2));
    drop(v166_6);
    let v166_8: Space = unite(&(v166_4),&(v166_7));
    drop(v166_7);
    join_wrapped_into(&mut v165_16_write,&((v166_8).read_zipper()),&[]);
    }
    v165_16_cursor.ascend(1);
  }
  drop(v165_16_cursor);
  drop(v165_16_write);
  drop(v165_9);
  drop(v165_15);
  (v165_16).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v170_6: Space = singleton(&(*p0));
  let v170_7: Space = intersect(&(*CONSTANT_2),&(v170_6));
  let v170_8: Space = if has_head(&(v170_7)) { singleton(&[]) } else { Space::new() };
  drop(v170_7);
  let v170_9: Space = subtract(&(*CONSTANT_1),&(v170_8));
  drop(v170_8);
  let v170_14: Space = intersect(&(*CONSTANT_2),&(v170_6));
  drop(v170_6);
  let v170_15: Space = if has_head(&(v170_14)) { singleton(&[]) } else { Space::new() };
  drop(v170_14);
  let mut v170_16 = Space::new();
  let mut v170_16_write = v170_16.write_zipper();
  let mut v170_16_cursor = (*s0).read_zipper();
  let v170_16_origin = v170_16_cursor.path().len();
  for v170_16_byte in v170_16_cursor.child_mask().iter() {
    v170_16_cursor.descend_to_existing_byte(v170_16_byte);
    {
    let v171_4: Space = if (&(v170_9)).is_empty() { Space::new() } else {
      let v172_2: Path = concat_path(&(*p1),&v170_16_cursor.path()[v170_16_origin..(v170_16_origin + 1)]);
      let mut v172_3 = Space::new();
      let mut v172_3_write = v172_3.write_zipper();
      let v172_3_arg_0: &[u8] = &(*CONSTANT_3);
      let v172_3_arg_1: &[u8] = &(v172_2);
      let v172_3_arg_3: &Space = &(&v170_16_cursor).make_map();
      let v172_3_arg_4: &Space = &(&(*s1)).make_map();
      let mut v172_3_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p0));
      let v172_3_origin = v172_3_cursor.path().len();
      let mut v172_3_more = v172_3_cursor.is_val() || next_value_within(&mut v172_3_cursor,v172_3_origin);
      while v172_3_more {
        {
        let v172_3_depth = v172_3_cursor.path().len();
        let v173_5: Space = routine_21(c, &v172_3_cursor.path()[v172_3_origin..v172_3_depth], &(*v172_3_arg_1), &((*v172_3_arg_3).read_zipper()), &((*v172_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v172_3_write,&((v173_5).read_zipper()),&[]);
        }
        v172_3_more = next_value_within(&mut v172_3_cursor,v172_3_origin);
      }
      drop(v172_3_cursor);
      drop(v172_3_write);
      compose(&(v170_9),&(v172_3))
    };
    let v171_6: Space = if (&(v170_15)).is_empty() { Space::new() } else {
      let v174_2: Path = concat_path(&(*p1),&v170_16_cursor.path()[v170_16_origin..(v170_16_origin + 1)]);
      let mut v174_5 = Space::new();
      let mut v174_5_write = v174_5.write_zipper();
      for v174_5_byte in v170_16_cursor.child_mask().iter() {
        v170_16_cursor.descend_to_existing_byte(v174_5_byte);
        {
        let v175_2: Space = routine_10(c, &v170_16_cursor.path()[(v170_16_origin + 1)..(v170_16_origin + 2)], &v170_16_cursor.path()[(v170_16_origin + 1)..(v170_16_origin + 2)], &(v174_2), &v170_16_cursor, &(*s1));
        join_wrapped_into(&mut v174_5_write,&((v175_2).read_zipper()),&[]);
        }
        v170_16_cursor.ascend(1);
      }
      drop(v174_5_write);
      drop(v174_2);
      compose(&(v170_15),&(v174_5))
    };
    let v171_7: Space = unite(&(v171_4),&(v171_6));
    join_wrapped_into(&mut v170_16_write,&((v171_7).read_zipper()),&[]);
    }
    v170_16_cursor.ascend(1);
  }
  drop(v170_16_cursor);
  drop(v170_16_write);
  drop(v170_9);
  drop(v170_15);
  (v170_16).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v176_7: Space = singleton(&(*p0));
  let v176_8: Space = intersect(&(*CONSTANT_2),&(v176_7));
  let v176_9: Space = if has_head(&(v176_8)) { singleton(&[]) } else { Space::new() };
  drop(v176_8);
  let v176_10: Space = subtract(&(*CONSTANT_1),&(v176_9));
  drop(v176_9);
  let v176_15: Space = intersect(&(*CONSTANT_2),&(v176_7));
  drop(v176_7);
  let v176_16: Space = if has_head(&(v176_15)) { singleton(&[]) } else { Space::new() };
  drop(v176_15);
  let mut v176_22 = Space::new();
  let mut v176_22_write = v176_22.write_zipper();
  let mut v176_22_cursor = (*s0).read_zipper();
  let v176_22_origin = v176_22_cursor.path().len();
  for v176_22_byte in v176_22_cursor.child_mask().iter() {
    v176_22_cursor.descend_to_existing_byte(v176_22_byte);
    {
    let v177_4: Space = if (&(v176_10)).is_empty() { Space::new() } else {
      let v178_2: Path = concat_path(&(*p1),&v176_22_cursor.path()[v176_22_origin..(v176_22_origin + 1)]);
      let mut v178_3 = Space::new();
      let mut v178_3_write = v178_3.write_zipper();
      let v178_3_arg_0: &[u8] = &(*CONSTANT_3);
      let v178_3_arg_1: &[u8] = &(v178_2);
      let v178_3_arg_2: &[u8] = &(*p2);
      let v178_3_arg_4: &Space = &(&v176_22_cursor).make_map();
      let v178_3_arg_5: &Space = &(&(*s1)).make_map();
      let mut v178_3_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p0));
      let v178_3_origin = v178_3_cursor.path().len();
      let mut v178_3_more = v178_3_cursor.is_val() || next_value_within(&mut v178_3_cursor,v178_3_origin);
      while v178_3_more {
        {
        let v178_3_depth = v178_3_cursor.path().len();
        let v179_6: Space = routine_22(c, &v178_3_cursor.path()[v178_3_origin..v178_3_depth], &(*v178_3_arg_1), &(*v178_3_arg_2), &((*v178_3_arg_4).read_zipper()), &((*v178_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v178_3_write,&((v179_6).read_zipper()),&[]);
        }
        v178_3_more = next_value_within(&mut v178_3_cursor,v178_3_origin);
      }
      drop(v178_3_cursor);
      drop(v178_3_write);
      drop(v178_2);
      compose(&(v176_10),&(v178_3))
    };
    let v177_7: Space = if (&(v176_16)).is_empty() { Space::new() } else {
      let mut v180_6 = Space::new();
      let mut v180_6_write = v180_6.write_zipper();
      let mut v180_6_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5)),&(*CONSTANT_7)),&(*p1)),&v176_22_cursor.path()[v176_22_origin..(v176_22_origin + 1)]);
      let v180_6_origin = v180_6_cursor.path().len();
      for v180_6_byte in v180_6_cursor.child_mask().iter() {
        v180_6_cursor.descend_to_existing_byte(v180_6_byte);
        {
        let v181_2: Space = routine_23(c, &v180_6_cursor.path()[v180_6_origin..(v180_6_origin + 1)], &v180_6_cursor.path()[v180_6_origin..(v180_6_origin + 1)], &(*p2), &v180_6_cursor);
        join_wrapped_into(&mut v180_6_write,&((v181_2).read_zipper()),&[]);
        }
        v180_6_cursor.ascend(1);
      }
      drop(v180_6_cursor);
      drop(v180_6_write);
      compose(&(v176_16),&(v180_6))
    };
    let v177_8: Space = unite(&(v177_4),&(v177_7));
    join_wrapped_into(&mut v176_22_write,&((v177_8).read_zipper()),&[]);
    }
    v176_22_cursor.ascend(1);
  }
  drop(v176_22_cursor);
  drop(v176_22_write);
  drop(v176_10);
  drop(v176_16);
  (v176_22).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v182_6: Space = singleton(&(*p1));
  let v182_7: Space = intersect(&(*CONSTANT_2),&(v182_6));
  let v182_8: Space = if has_head(&(v182_7)) { singleton(&[]) } else { Space::new() };
  drop(v182_7);
  let v182_9: Space = subtract(&(*CONSTANT_1),&(v182_8));
  drop(v182_8);
  let v182_20: Space = if (&(v182_9)).is_empty() { Space::new() } else {
    let v183_12: Space = first_matching(&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p1))),&(*CONSTANT_1),false);
    let v183_15: Space = if (&(v183_12)).is_empty() { Space::new() } else {
      let v184_14: Space = routine_26(c, &(*CONSTANT_3), &(*p0), &(*p2), &(*s0));
      compose(&(v183_12),&(v184_14))
    };
    drop(v183_12);
    let mut v183_18 = Space::new();
    let mut v183_18_write = v183_18.write_zipper();
    let mut v183_18_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p1));
    let v183_18_origin = v183_18_cursor.path().len();
    for v183_18_byte in v183_18_cursor.child_mask().iter() {
      v183_18_cursor.descend_to_existing_byte(v183_18_byte);
      {
      let v185_2_arg_0: &[u8] = &v183_18_cursor.path()[v183_18_origin..(v183_18_origin + 1)];
      let v185_2_arg_1: &[u8] = &(*p0);
      let v185_2_arg_2: &[u8] = &(*p2);
      let v185_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v185_2_more = v183_18_cursor.is_val() || next_value_within(&mut v183_18_cursor,(v183_18_origin + 1));
      while v185_2_more {
        {
        let v185_2_depth = v183_18_cursor.path().len();
        let mut v186_5_cursor = (*v185_2_arg_4).read_zipper();
        let v186_5_origin = v186_5_cursor.path().len();
        for v186_5_byte in v186_5_cursor.child_mask().iter() {
          v186_5_cursor.descend_to_existing_byte(v186_5_byte);
          {
          let v187_2: Path = concat_path(&(*v185_2_arg_1),&v186_5_cursor.path()[v186_5_origin..(v186_5_origin + 1)]);
          let v187_3: Space = routine_23(c, &(v187_2), &v183_18_cursor.path()[v183_18_origin..v185_2_depth], &(*v185_2_arg_2), &v186_5_cursor);
          drop(v187_2);
          join_wrapped_into(&mut v183_18_write,&((v187_3).read_zipper()),&[]);
          }
          v186_5_cursor.ascend(1);
        }
        drop(v186_5_cursor);
        }
        v185_2_more = next_value_within(&mut v183_18_cursor,(v183_18_origin + 1));
      }
      }
      v183_18_cursor.ascend(1);
    }
    drop(v183_18_cursor);
    drop(v183_18_write);
    let v183_19: Space = unite(&(v183_15),&(v183_18));
    compose(&(v182_9),&(v183_19))
  };
  drop(v182_9);
  let v182_22: Space = intersect(&(*CONSTANT_2),&(v182_6));
  drop(v182_6);
  let v182_23: Space = if has_head(&(v182_22)) { singleton(&[]) } else { Space::new() };
  drop(v182_22);
  let v182_24: Space = if (&(v182_23)).is_empty() { Space::new() } else {
    compose(&(v182_23),&(*s0))
  };
  drop(v182_23);
  let v182_25: Space = wrap(&(v182_24),&(*p0));
  drop(v182_24);
  let v182_26: Space = wrap(&(v182_25),&(*p2));
  drop(v182_25);
  let v182_27: Space = unite(&(v182_20),&(v182_26));
  drop(v182_26);
  (v182_27).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v189_6: Space = singleton(&(*p0));
  let v189_7: Space = intersect(&(*CONSTANT_2),&(v189_6));
  let v189_8: Space = if has_head(&(v189_7)) { singleton(&[]) } else { Space::new() };
  drop(v189_7);
  let v189_9: Space = subtract(&(*CONSTANT_1),&(v189_8));
  drop(v189_8);
  let v189_14: Space = intersect(&(*CONSTANT_2),&(v189_6));
  drop(v189_6);
  let v189_15: Space = if has_head(&(v189_14)) { singleton(&[]) } else { Space::new() };
  drop(v189_14);
  let mut v189_16 = Space::new();
  let mut v189_16_write = v189_16.write_zipper();
  let mut v189_16_cursor = (*s0).read_zipper();
  let v189_16_origin = v189_16_cursor.path().len();
  for v189_16_byte in v189_16_cursor.child_mask().iter() {
    v189_16_cursor.descend_to_existing_byte(v189_16_byte);
    {
    let v190_4: Space = if (&(v189_9)).is_empty() { Space::new() } else {
      let v191_2: Path = concat_path(&(*p1),&v189_16_cursor.path()[v189_16_origin..(v189_16_origin + 1)]);
      let mut v191_3 = Space::new();
      let mut v191_3_write = v191_3.write_zipper();
      let v191_3_arg_0: &[u8] = &(*CONSTANT_3);
      let v191_3_arg_1: &[u8] = &(v191_2);
      let v191_3_arg_2: &[u8] = &(*p2);
      let v191_3_arg_4: &Space = &(&v189_16_cursor).make_map();
      let mut v191_3_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p0));
      let v191_3_origin = v191_3_cursor.path().len();
      let mut v191_3_more = v191_3_cursor.is_val() || next_value_within(&mut v191_3_cursor,v191_3_origin);
      while v191_3_more {
        {
        let v191_3_depth = v191_3_cursor.path().len();
        let v192_5: Space = routine_24(c, &v191_3_cursor.path()[v191_3_origin..v191_3_depth], &(*v191_3_arg_1), &(*v191_3_arg_2), &((*v191_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v191_3_write,&((v192_5).read_zipper()),&[]);
        }
        v191_3_more = next_value_within(&mut v191_3_cursor,v191_3_origin);
      }
      drop(v191_3_cursor);
      drop(v191_3_write);
      compose(&(v189_9),&(v191_3))
    };
    let v190_5: Space = compose(&(v189_15),&v189_16_cursor);
    let v193_2: Path = concat_path(&(*p1),&v189_16_cursor.path()[v189_16_origin..(v189_16_origin + 1)]);
    let v190_6: Space = wrap(&(v190_5),&(v193_2));
    drop(v190_5);
    let v190_7: Space = wrap(&(v190_6),&(*p2));
    drop(v190_6);
    let v190_8: Space = unite(&(v190_4),&(v190_7));
    drop(v190_7);
    join_wrapped_into(&mut v189_16_write,&((v190_8).read_zipper()),&[]);
    }
    v189_16_cursor.ascend(1);
  }
  drop(v189_16_cursor);
  drop(v189_16_write);
  drop(v189_9);
  drop(v189_15);
  (v189_16).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v194_6: Space = singleton(&(*p0));
  let v194_7: Space = intersect(&(*CONSTANT_2),&(v194_6));
  let v194_8: Space = if has_head(&(v194_7)) { singleton(&[]) } else { Space::new() };
  drop(v194_7);
  let v194_9: Space = subtract(&(*CONSTANT_1),&(v194_8));
  drop(v194_8);
  let v194_14: Space = intersect(&(*CONSTANT_2),&(v194_6));
  drop(v194_6);
  let v194_15: Space = if has_head(&(v194_14)) { singleton(&[]) } else { Space::new() };
  drop(v194_14);
  let mut v194_16 = Space::new();
  let mut v194_16_write = v194_16.write_zipper();
  let mut v194_16_cursor = (*s0).read_zipper();
  let v194_16_origin = v194_16_cursor.path().len();
  for v194_16_byte in v194_16_cursor.child_mask().iter() {
    v194_16_cursor.descend_to_existing_byte(v194_16_byte);
    {
    let v195_4: Space = if (&(v194_9)).is_empty() { Space::new() } else {
      let v196_2: Path = concat_path(&(*p1),&v194_16_cursor.path()[v194_16_origin..(v194_16_origin + 1)]);
      let mut v196_3 = Space::new();
      let mut v196_3_write = v196_3.write_zipper();
      let v196_3_arg_0: &[u8] = &(*CONSTANT_3);
      let v196_3_arg_1: &[u8] = &(v196_2);
      let v196_3_arg_2: &[u8] = &(*p2);
      let v196_3_arg_4: &Space = &(&v194_16_cursor).make_map();
      let mut v196_3_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p0));
      let v196_3_origin = v196_3_cursor.path().len();
      let mut v196_3_more = v196_3_cursor.is_val() || next_value_within(&mut v196_3_cursor,v196_3_origin);
      while v196_3_more {
        {
        let v196_3_depth = v196_3_cursor.path().len();
        let v197_5: Space = routine_25(c, &v196_3_cursor.path()[v196_3_origin..v196_3_depth], &(*v196_3_arg_1), &(*v196_3_arg_2), &((*v196_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v196_3_write,&((v197_5).read_zipper()),&[]);
        }
        v196_3_more = next_value_within(&mut v196_3_cursor,v196_3_origin);
      }
      drop(v196_3_cursor);
      drop(v196_3_write);
      compose(&(v194_9),&(v196_3))
    };
    let v195_5: Space = compose(&(v194_15),&v194_16_cursor);
    let v198_2: Path = concat_path(&(*p1),&v194_16_cursor.path()[v194_16_origin..(v194_16_origin + 1)]);
    let v195_6: Space = wrap(&(v195_5),&(v198_2));
    drop(v195_5);
    let v195_7: Space = wrap(&(v195_6),&(*p2));
    drop(v195_6);
    let v195_8: Space = unite(&(v195_4),&(v195_7));
    drop(v195_7);
    join_wrapped_into(&mut v194_16_write,&((v195_8).read_zipper()),&[]);
    }
    v194_16_cursor.ascend(1);
  }
  drop(v194_16_cursor);
  drop(v194_16_write);
  drop(v194_9);
  drop(v194_15);
  (v194_16).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v199_6: Space = singleton(&(*p0));
  let v199_7: Space = intersect(&(*CONSTANT_2),&(v199_6));
  let v199_8: Space = if has_head(&(v199_7)) { singleton(&[]) } else { Space::new() };
  drop(v199_7);
  let v199_9: Space = subtract(&(*CONSTANT_1),&(v199_8));
  drop(v199_8);
  let v199_14: Space = intersect(&(*CONSTANT_2),&(v199_6));
  drop(v199_6);
  let v199_15: Space = if has_head(&(v199_14)) { singleton(&[]) } else { Space::new() };
  drop(v199_14);
  let mut v199_16 = Space::new();
  let mut v199_16_write = v199_16.write_zipper();
  let mut v199_16_cursor = (*s0).read_zipper();
  let v199_16_origin = v199_16_cursor.path().len();
  for v199_16_byte in v199_16_cursor.child_mask().iter() {
    v199_16_cursor.descend_to_existing_byte(v199_16_byte);
    {
    let v200_4: Space = if (&(v199_9)).is_empty() { Space::new() } else {
      let v201_2: Path = concat_path(&(*p1),&v199_16_cursor.path()[v199_16_origin..(v199_16_origin + 1)]);
      let mut v201_3 = Space::new();
      let mut v201_3_write = v201_3.write_zipper();
      let v201_3_arg_0: &[u8] = &(*CONSTANT_3);
      let v201_3_arg_1: &[u8] = &(v201_2);
      let v201_3_arg_2: &[u8] = &(*p2);
      let v201_3_arg_4: &Space = &(&v199_16_cursor).make_map();
      let mut v201_3_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p0));
      let v201_3_origin = v201_3_cursor.path().len();
      let mut v201_3_more = v201_3_cursor.is_val() || next_value_within(&mut v201_3_cursor,v201_3_origin);
      while v201_3_more {
        {
        let v201_3_depth = v201_3_cursor.path().len();
        let v202_5: Space = routine_26(c, &v201_3_cursor.path()[v201_3_origin..v201_3_depth], &(*v201_3_arg_1), &(*v201_3_arg_2), &((*v201_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v201_3_write,&((v202_5).read_zipper()),&[]);
        }
        v201_3_more = next_value_within(&mut v201_3_cursor,v201_3_origin);
      }
      drop(v201_3_cursor);
      drop(v201_3_write);
      compose(&(v199_9),&(v201_3))
    };
    let v200_5: Space = compose(&(v199_15),&v199_16_cursor);
    let v203_2: Path = concat_path(&(*p1),&v199_16_cursor.path()[v199_16_origin..(v199_16_origin + 1)]);
    let v200_6: Space = wrap(&(v200_5),&(v203_2));
    drop(v200_5);
    let v200_7: Space = wrap(&(v200_6),&(*p2));
    drop(v200_6);
    let v200_8: Space = unite(&(v200_4),&(v200_7));
    drop(v200_7);
    join_wrapped_into(&mut v199_16_write,&((v200_8).read_zipper()),&[]);
    }
    v199_16_cursor.ascend(1);
  }
  drop(v199_16_cursor);
  drop(v199_16_write);
  drop(v199_9);
  drop(v199_15);
  (v199_16).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
