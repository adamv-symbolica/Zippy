#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,43]));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,44]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,42]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,43,0,0,0,42]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,44,0,0,0,42]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_3 = Space::new();
  let mut v0_3_write = v0_3.write_zipper();
  let mut v0_3_cursor = descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0));
  let v0_3_origin = v0_3_cursor.path().len();
  for v0_3_byte in v0_3_cursor.child_mask().iter() {
    v0_3_cursor.descend_to_existing_byte(v0_3_byte);
    {
    for v1_2_byte in v0_3_cursor.child_mask().iter() {
      v0_3_cursor.descend_to_existing_byte(v1_2_byte);
      {
      for v2_3_byte in v0_3_cursor.child_mask().iter() {
        v0_3_cursor.descend_to_existing_byte(v2_3_byte);
        {
        for v3_3_byte in v0_3_cursor.child_mask().iter() {
          v0_3_cursor.descend_to_existing_byte(v3_3_byte);
          {
          for v4_3_byte in v0_3_cursor.child_mask().iter() {
            v0_3_cursor.descend_to_existing_byte(v4_3_byte);
            {
            for v5_2_byte in v0_3_cursor.child_mask().iter() {
              v0_3_cursor.descend_to_existing_byte(v5_2_byte);
              {
              for v6_3_byte in v0_3_cursor.child_mask().iter() {
                v0_3_cursor.descend_to_existing_byte(v6_3_byte);
                {
                for v7_3_byte in v0_3_cursor.child_mask().iter() {
                  v0_3_cursor.descend_to_existing_byte(v7_3_byte);
                  {
                  let v8_3: Space = routine_1(c, &v0_3_cursor.path()[(v0_3_origin + 4)..(v0_3_origin + 8)], &v0_3_cursor.path()[v0_3_origin..(v0_3_origin + 4)], &v0_3_cursor);
                  join_wrapped_into(&mut v0_3_write,&((v8_3).read_zipper()),&[]);
                  }
                  v0_3_cursor.ascend(1);
                }
                }
                v0_3_cursor.ascend(1);
              }
              }
              v0_3_cursor.ascend(1);
            }
            }
            v0_3_cursor.ascend(1);
          }
          }
          v0_3_cursor.ascend(1);
        }
        }
        v0_3_cursor.ascend(1);
      }
      }
      v0_3_cursor.ascend(1);
    }
    }
    v0_3_cursor.ascend(1);
  }
  drop(v0_3_cursor);
  drop(v0_3_write);
  let v0_5: Space = wrap(&(v0_3),&(*CONSTANT_1));
  let v0_7: Space = wrap(&(*s0.expect("unbound native input")),&(*CONSTANT_2));
  let v0_8: Space = unite(&(v0_5),&(v0_7));
  drop(v0_7);
  let mut v0_12: Space = (v0_8).clone();
  loop {
    let mut v9_3 = Space::new();
    let mut v9_3_write = v9_3.write_zipper();
    let mut v9_3_cursor = descend_cursor(descend_cursor((v0_12).read_zipper(),&(*CONSTANT_1)),&(*CONSTANT_3));
    let v9_3_origin = v9_3_cursor.path().len();
    for v9_3_byte in v9_3_cursor.child_mask().iter() {
      v9_3_cursor.descend_to_existing_byte(v9_3_byte);
      {
      for v10_2_byte in v9_3_cursor.child_mask().iter() {
        v9_3_cursor.descend_to_existing_byte(v10_2_byte);
        {
        for v11_3_byte in v9_3_cursor.child_mask().iter() {
          v9_3_cursor.descend_to_existing_byte(v11_3_byte);
          {
          for v12_3_byte in v9_3_cursor.child_mask().iter() {
            v9_3_cursor.descend_to_existing_byte(v12_3_byte);
            {
            for v13_3_byte in v9_3_cursor.child_mask().iter() {
              v9_3_cursor.descend_to_existing_byte(v13_3_byte);
              {
              for v14_2_byte in v9_3_cursor.child_mask().iter() {
                v9_3_cursor.descend_to_existing_byte(v14_2_byte);
                {
                for v15_3_byte in v9_3_cursor.child_mask().iter() {
                  v9_3_cursor.descend_to_existing_byte(v15_3_byte);
                  {
                  for v16_3_byte in v9_3_cursor.child_mask().iter() {
                    v9_3_cursor.descend_to_existing_byte(v16_3_byte);
                    {
                    let v17_3: Space = routine_2(c, &v9_3_cursor.path()[(v9_3_origin + 4)..(v9_3_origin + 8)], &v9_3_cursor.path()[v9_3_origin..(v9_3_origin + 4)], &v9_3_cursor, &((v0_12).read_zipper()));
                    join_wrapped_into(&mut v9_3_write,&((v17_3).read_zipper()),&[]);
                    }
                    v9_3_cursor.ascend(1);
                  }
                  }
                  v9_3_cursor.ascend(1);
                }
                }
                v9_3_cursor.ascend(1);
              }
              }
              v9_3_cursor.ascend(1);
            }
            }
            v9_3_cursor.ascend(1);
          }
          }
          v9_3_cursor.ascend(1);
        }
        }
        v9_3_cursor.ascend(1);
      }
      }
      v9_3_cursor.ascend(1);
    }
    drop(v9_3_cursor);
    drop(v9_3_write);
    let mut v9_4 = Space::new();
    let mut v9_4_write = v9_4.write_zipper();
    let mut v9_4_cursor = descend_cursor(descend_cursor((v0_12).read_zipper(),&(*CONSTANT_1)),&(*CONSTANT_3));
    let v9_4_origin = v9_4_cursor.path().len();
    for v9_4_byte in v9_4_cursor.child_mask().iter() {
      v9_4_cursor.descend_to_existing_byte(v9_4_byte);
      {
      for v18_2_byte in v9_4_cursor.child_mask().iter() {
        v9_4_cursor.descend_to_existing_byte(v18_2_byte);
        {
        for v19_3_byte in v9_4_cursor.child_mask().iter() {
          v9_4_cursor.descend_to_existing_byte(v19_3_byte);
          {
          for v20_3_byte in v9_4_cursor.child_mask().iter() {
            v9_4_cursor.descend_to_existing_byte(v20_3_byte);
            {
            for v21_3_byte in v9_4_cursor.child_mask().iter() {
              v9_4_cursor.descend_to_existing_byte(v21_3_byte);
              {
              for v22_2_byte in v9_4_cursor.child_mask().iter() {
                v9_4_cursor.descend_to_existing_byte(v22_2_byte);
                {
                for v23_3_byte in v9_4_cursor.child_mask().iter() {
                  v9_4_cursor.descend_to_existing_byte(v23_3_byte);
                  {
                  for v24_3_byte in v9_4_cursor.child_mask().iter() {
                    v9_4_cursor.descend_to_existing_byte(v24_3_byte);
                    {
                    let v25_3: Space = routine_3(c, &v9_4_cursor.path()[(v9_4_origin + 4)..(v9_4_origin + 8)], &v9_4_cursor.path()[v9_4_origin..(v9_4_origin + 4)], &v9_4_cursor, &((v0_12).read_zipper()));
                    join_wrapped_into(&mut v9_4_write,&((v25_3).read_zipper()),&[]);
                    }
                    v9_4_cursor.ascend(1);
                  }
                  }
                  v9_4_cursor.ascend(1);
                }
                }
                v9_4_cursor.ascend(1);
              }
              }
              v9_4_cursor.ascend(1);
            }
            }
            v9_4_cursor.ascend(1);
          }
          }
          v9_4_cursor.ascend(1);
        }
        }
        v9_4_cursor.ascend(1);
      }
      }
      v9_4_cursor.ascend(1);
    }
    drop(v9_4_cursor);
    drop(v9_4_write);
    let v9_5: Space = unite(&(v9_3),&(v9_4));
    let mut v9_8 = Space::new();
    let mut v9_8_write = v9_8.write_zipper();
    let mut v9_8_cursor = descend_cursor(descend_cursor((v0_12).read_zipper(),&(*CONSTANT_2)),&(*CONSTANT_0));
    let v9_8_origin = v9_8_cursor.path().len();
    for v9_8_byte in v9_8_cursor.child_mask().iter() {
      v9_8_cursor.descend_to_existing_byte(v9_8_byte);
      {
      for v26_2_byte in v9_8_cursor.child_mask().iter() {
        v9_8_cursor.descend_to_existing_byte(v26_2_byte);
        {
        for v27_3_byte in v9_8_cursor.child_mask().iter() {
          v9_8_cursor.descend_to_existing_byte(v27_3_byte);
          {
          for v28_3_byte in v9_8_cursor.child_mask().iter() {
            v9_8_cursor.descend_to_existing_byte(v28_3_byte);
            {
            for v29_3_byte in v9_8_cursor.child_mask().iter() {
              v9_8_cursor.descend_to_existing_byte(v29_3_byte);
              {
              for v30_2_byte in v9_8_cursor.child_mask().iter() {
                v9_8_cursor.descend_to_existing_byte(v30_2_byte);
                {
                for v31_3_byte in v9_8_cursor.child_mask().iter() {
                  v9_8_cursor.descend_to_existing_byte(v31_3_byte);
                  {
                  for v32_3_byte in v9_8_cursor.child_mask().iter() {
                    v9_8_cursor.descend_to_existing_byte(v32_3_byte);
                    {
                    let v33_3: Space = routine_4(c, &v9_8_cursor.path()[(v9_8_origin + 4)..(v9_8_origin + 8)], &v9_8_cursor.path()[v9_8_origin..(v9_8_origin + 4)], &v9_8_cursor);
                    join_wrapped_into(&mut v9_8_write,&((v33_3).read_zipper()),&[]);
                    }
                    v9_8_cursor.ascend(1);
                  }
                  }
                  v9_8_cursor.ascend(1);
                }
                }
                v9_8_cursor.ascend(1);
              }
              }
              v9_8_cursor.ascend(1);
            }
            }
            v9_8_cursor.ascend(1);
          }
          }
          v9_8_cursor.ascend(1);
        }
        }
        v9_8_cursor.ascend(1);
      }
      }
      v9_8_cursor.ascend(1);
    }
    drop(v9_8_cursor);
    drop(v9_8_write);
    let v9_9: Space = unite(&(v9_5),&(v9_8));
    let mut v9_11 = Space::new();
    let mut v9_11_write = v9_11.write_zipper();
    let mut v9_11_cursor = descend_cursor(descend_cursor((v0_12).read_zipper(),&(*CONSTANT_2)),&(*CONSTANT_3));
    let v9_11_origin = v9_11_cursor.path().len();
    for v9_11_byte in v9_11_cursor.child_mask().iter() {
      v9_11_cursor.descend_to_existing_byte(v9_11_byte);
      {
      for v34_2_byte in v9_11_cursor.child_mask().iter() {
        v9_11_cursor.descend_to_existing_byte(v34_2_byte);
        {
        for v35_3_byte in v9_11_cursor.child_mask().iter() {
          v9_11_cursor.descend_to_existing_byte(v35_3_byte);
          {
          for v36_3_byte in v9_11_cursor.child_mask().iter() {
            v9_11_cursor.descend_to_existing_byte(v36_3_byte);
            {
            for v37_3_byte in v9_11_cursor.child_mask().iter() {
              v9_11_cursor.descend_to_existing_byte(v37_3_byte);
              {
              for v38_2_byte in v9_11_cursor.child_mask().iter() {
                v9_11_cursor.descend_to_existing_byte(v38_2_byte);
                {
                for v39_3_byte in v9_11_cursor.child_mask().iter() {
                  v9_11_cursor.descend_to_existing_byte(v39_3_byte);
                  {
                  for v40_3_byte in v9_11_cursor.child_mask().iter() {
                    v9_11_cursor.descend_to_existing_byte(v40_3_byte);
                    {
                    let v41_3: Space = routine_5(c, &v9_11_cursor.path()[(v9_11_origin + 4)..(v9_11_origin + 8)], &v9_11_cursor.path()[v9_11_origin..(v9_11_origin + 4)], &v9_11_cursor, &((v0_12).read_zipper()));
                    join_wrapped_into(&mut v9_11_write,&((v41_3).read_zipper()),&[]);
                    }
                    v9_11_cursor.ascend(1);
                  }
                  }
                  v9_11_cursor.ascend(1);
                }
                }
                v9_11_cursor.ascend(1);
              }
              }
              v9_11_cursor.ascend(1);
            }
            }
            v9_11_cursor.ascend(1);
          }
          }
          v9_11_cursor.ascend(1);
        }
        }
        v9_11_cursor.ascend(1);
      }
      }
      v9_11_cursor.ascend(1);
    }
    drop(v9_11_cursor);
    drop(v9_11_write);
    let v9_12: Space = unite(&(v9_9),&(v9_11));
    let v9_14: Space = subtract(&(v9_12),&(descend_cursor((v0_12).read_zipper(),&(*CONSTANT_4))));
    let v9_16: Space = subtract(&(v9_14),&(descend_cursor((v0_12).read_zipper(),&(*CONSTANT_5))));
    let v9_17: Space = wrap(&(v9_16),&(*CONSTANT_4));
    let v9_18: Space = unite(&(descend_cursor((v0_12).read_zipper(),&(*CONSTANT_1))),&(descend_cursor((v0_12).read_zipper(),&(*CONSTANT_2))));
    let v9_19: Space = wrap(&(v9_18),&(*CONSTANT_2));
    drop(v9_18);
    let v9_20: Space = unite(&(v9_17),&(v9_19));
    drop(v9_19);
    let v9_21: Space = unite(&(v9_20),&(v0_12));
    if !v0_12.join_into((v9_21).clone()).is_element() { break; }
  }
  (&(descend_cursor((v0_12).read_zipper(),&(*CONSTANT_5)))).make_map()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v42_3: Space = wrap(&(*s0),&(*p0));
  let v42_4: Space = wrap(&(v42_3),&(*p1));
  drop(v42_3);
  let v42_6: Space = wrap(&(v42_4),&(*CONSTANT_3));
  drop(v42_4);
  (v42_6).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v43_10 = Space::new();
  let mut v43_10_write = v43_10.write_zipper();
  let mut v43_10_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_2)),&(*CONSTANT_3)),&(*p0));
  let v43_10_origin = v43_10_cursor.path().len();
  for v43_10_byte in v43_10_cursor.child_mask().iter() {
    v43_10_cursor.descend_to_existing_byte(v43_10_byte);
    {
    for v44_2_byte in v43_10_cursor.child_mask().iter() {
      v43_10_cursor.descend_to_existing_byte(v44_2_byte);
      {
      for v45_3_byte in v43_10_cursor.child_mask().iter() {
        v43_10_cursor.descend_to_existing_byte(v45_3_byte);
        {
        v43_10_write.descend_to(&v43_10_cursor.path()[v43_10_origin..(v43_10_origin + 3)]);
        join_branches(&mut v43_10_write,&mut v43_10_cursor);
        v43_10_write.ascend((&v43_10_cursor.path()[v43_10_origin..(v43_10_origin + 3)]).len());
        }
        v43_10_cursor.ascend(1);
      }
      }
      v43_10_cursor.ascend(1);
    }
    }
    v43_10_cursor.ascend(1);
  }
  drop(v43_10_cursor);
  drop(v43_10_write);
  let v43_11: Space = wrap(&(v43_10),&(*p1));
  drop(v43_10);
  (v43_11).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v47_10 = Space::new();
  let mut v47_10_write = v47_10.write_zipper();
  let mut v47_10_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_1)),&(*CONSTANT_3)),&(*p0));
  let v47_10_origin = v47_10_cursor.path().len();
  for v47_10_byte in v47_10_cursor.child_mask().iter() {
    v47_10_cursor.descend_to_existing_byte(v47_10_byte);
    {
    for v48_2_byte in v47_10_cursor.child_mask().iter() {
      v47_10_cursor.descend_to_existing_byte(v48_2_byte);
      {
      for v49_3_byte in v47_10_cursor.child_mask().iter() {
        v47_10_cursor.descend_to_existing_byte(v49_3_byte);
        {
        v47_10_write.descend_to(&v47_10_cursor.path()[v47_10_origin..(v47_10_origin + 3)]);
        join_branches(&mut v47_10_write,&mut v47_10_cursor);
        v47_10_write.ascend((&v47_10_cursor.path()[v47_10_origin..(v47_10_origin + 3)]).len());
        }
        v47_10_cursor.ascend(1);
      }
      }
      v47_10_cursor.ascend(1);
    }
    }
    v47_10_cursor.ascend(1);
  }
  drop(v47_10_cursor);
  drop(v47_10_write);
  let v47_11: Space = wrap(&(v47_10),&(*p1));
  drop(v47_10);
  (v47_11).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v51_3: Space = wrap(&(*s0),&(*p0));
  let v51_4: Space = wrap(&(v51_3),&(*p1));
  drop(v51_3);
  (v51_4).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v52_10 = Space::new();
  let mut v52_10_write = v52_10.write_zipper();
  let mut v52_10_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_1)),&(*CONSTANT_3)),&(*p0));
  let v52_10_origin = v52_10_cursor.path().len();
  for v52_10_byte in v52_10_cursor.child_mask().iter() {
    v52_10_cursor.descend_to_existing_byte(v52_10_byte);
    {
    for v53_2_byte in v52_10_cursor.child_mask().iter() {
      v52_10_cursor.descend_to_existing_byte(v53_2_byte);
      {
      for v54_3_byte in v52_10_cursor.child_mask().iter() {
        v52_10_cursor.descend_to_existing_byte(v54_3_byte);
        {
        v52_10_write.descend_to(&v52_10_cursor.path()[v52_10_origin..(v52_10_origin + 3)]);
        join_branches(&mut v52_10_write,&mut v52_10_cursor);
        v52_10_write.ascend((&v52_10_cursor.path()[v52_10_origin..(v52_10_origin + 3)]).len());
        }
        v52_10_cursor.ascend(1);
      }
      }
      v52_10_cursor.ascend(1);
    }
    }
    v52_10_cursor.ascend(1);
  }
  drop(v52_10_cursor);
  drop(v52_10_write);
  let v52_11: Space = wrap(&(v52_10),&(*p1));
  drop(v52_10);
  (v52_11).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
